# Decoupling gravitational sources in general relativity: From perfect to anisotropic fluids

Jorge Ovalle\*

Departamento de Física, Universidad Simón Bolívar, AP 89000, Caracas 1080A, Venezuela The Institute for Fundamental Study, Naresuan University, Phitsanulok 65000, Thailand

We show the first simple, systematic and direct approach to decoupling gravitational sources in general relativity. As a direct application, a robust and simple way to generate anisotropic solutions for self-gravitating systems from perfect fluid solutions is presented.

#### INTRODUCTION

As is well known, in most cases solving Einstein field equations is a difficult task. Indeed, it is hard to obtain analytical solutions having some physical relevance, except for some specific situations [1]. One of these particular cases is the spherically symmetric space-time with a perfect fluid  $\hat{T}_{\mu\nu}$  as a gravitational source [2–4]. However, as soon as the perfect fluid is coupled to complex forms of matter-energy to describe more realistic scenarios, namely,

$$T_{\mu\nu} = \hat{T}_{\mu\nu} + \alpha \,\theta_{\mu\nu} \,\,, \tag{1}$$

with  $\alpha$  a coupling constant and  $\theta_{\mu\nu}$  any other form of gravitational source, then the situation changes radically, making it almost impossible to obtain analytical results that can be easily interpreted (for the case of anisotropic sources, see for instance [5, 6]). In this respect, the so-called Minimal Geometric Deformation (MGD), originally proposed [7, 8] in the context of the Randall-Sundrum brane-world [9, 10] and extended to investigate new black hole solutions [11, 12], has been successfully used to generate brane-world configurations from general relativistic perfect fluid solutions. Even exact and physically acceptable solutions for interior stellar distributions, which is a difficult task due to the existence of non-linear terms in the matter fields, were successfully generated [13]. The approach works very well, but the reason for this is, so far, unknown (for some recent applications, see for instance Refs. [14–17]). Nonetheless, we believe there must be a fundamental reason explaining all of this. One of the purposes of this paper is to explain this fundamental reason, as well as to show the potential of the MGD to be exploited in other areas beyond the brane-world. We will show that under the MGD lies a powerful and direct way of dealing with Einstein field equations, as described below.

Let us start with a rhetorical and naive question. Would it not be ideal to solve Einstein field equations by solving the field equations for each gravitational source individually? That is, we could find the metric  $g_{\mu\nu}$ , and both energy-momentum tensors  $\hat{T}_{\mu\nu}$  and  $\theta_{\mu\nu}$ , not by solving

<span id="page-0-0"></span>
$$G_{\mu\nu} = -k^2 \left( \hat{T}_{\mu\nu} + \alpha \,\theta_{\mu\nu} \right) \; ; \quad k^2 = 8\pi \; ,$$
 (2)

but

<span id="page-0-1"></span>
$$\hat{G}_{\mu\nu} = -k^2 \,\hat{T}_{\mu\nu} \,, \text{ to find } \{\hat{g}_{\mu\nu}, \hat{T}_{\mu\nu}\}$$
 (3)

and then

<span id="page-0-2"></span>
$$G_{\mu\nu}^* = -k^2 \theta_{\mu\nu}^*$$
, to find  $\{g_{\mu\nu}^*, \theta_{\mu\nu}^*\}$  (4)

and finally, we could obtain the metric  $g_{\mu\nu}$  in Eq. (2) by a simple combination of the two metrics found by Eqs. (3) and (4), namely,  $\hat{g}_{\mu\nu}$  and  $g^*_{\mu\nu}$ . Obviously, this would be great since it would introduce an unprecedented simplification. However, the consensus has told us for years not only the impossibility of carrying out this alternative but also the absurdity of it, given the highly non-linear and complex structure of Einstein field equations [18]. In this paper, contrary to the general belief that has lasted for years, we will show that the decoupling of the gravitational sources, as suggested in Eqs. (2)-(4), can be done in a simple and direct way, at least for the spherically symmetric and static case, thus opening a range of new possibilities in the search for solutions to Einstein field equations.

#### EINSTEIN EQUATIONS

Let us start from Einstein field equations

<span id="page-0-3"></span>
$$R_{\mu\nu} - \frac{1}{2} R g_{\mu\nu} = -k^2 T_{\mu\nu}^{(\text{tot})} ,$$
 (5)

with

$$T_{\mu\nu}^{(\text{tot})} = T_{\mu\nu}^{(\text{m})} + \alpha \,\theta_{\mu\nu}$$
 (6)

where

<span id="page-0-4"></span>
$$T_{\mu\nu}^{(m)} = (\rho + p) u_{\mu} u_{\nu} - p g_{\mu\nu}$$
 (7)

is the four-dimensional energy-momentum tensor of ordinary matter, described by a perfect fluid with 4-velocity field  $u^{\mu}$ , density  $\rho$  and isotropic pressure p. On the other hand, the term  $\theta_{\mu\nu}$  in Eq. (5) is any additional gravitational source coupled with the perfect fluid by the constant  $\alpha$  [19]. The source  $\theta_{\mu\nu}$  may contain new fields, like scalar, vector and tensor fields. Since the Einstein tensor

is divergence free, the energy-momentum tensor  $T_{\mu\nu}^{({\rm tot})}$  satisfies the conservation equation

<span id="page-1-1"></span>
$$\nabla_{\nu} T^{(\text{tot})\mu\nu} = 0 . \tag{8}$$

In Schwarzschild-like coordinates, the spherically symmetric metric reads  $\,$ 

<span id="page-1-0"></span>
$$ds^{2} = e^{\nu(r)} dt^{2} - e^{\lambda(r)} dr^{2} - r^{2} (d\theta^{2} + \sin^{2}\theta d\phi^{2}) , \quad (9)$$

where  $\nu = \nu(r)$  and  $\lambda = \lambda(r)$  are functions of the areal radius r only, ranging from r=0 (the star's center) to some r=R (the star's surface), and the fluid 4-velocity field is given by  $u^{\mu} = e^{-\nu/2} \, \delta_0^{\mu}$  for  $0 \le r \le R$ . The metric (9) must satisfy the Einstein equations (5), which explicitly read

<span id="page-1-2"></span>
$$-k^{2}\left(\rho + \alpha \,\theta_{0}^{\,0}\right) = -\frac{1}{r^{2}} + e^{-\lambda} \left(\frac{1}{r^{2}} - \frac{\lambda'}{r}\right) , \qquad (10)$$

$$-k^{2}\left(-p+\alpha\,\theta_{1}^{1}\right) = -\frac{1}{r^{2}} + e^{-\lambda}\left(\frac{1}{r^{2}} + \frac{\nu'}{r}\right) , \qquad (11)$$

$$-k^{2}\left(-p+\alpha\,\theta_{2}^{2}\right) = \frac{1}{4}e^{-\lambda}\left[2\,\nu'' + \nu'^{2} - \lambda'\,\nu' + 2\,\frac{\nu' - \lambda'}{r}\right]\,,\tag{12}$$

while the conservation equation (8), which is a linear combination of Eqs. (10)-(12), yields

<span id="page-1-3"></span>
$$-p' - \frac{\nu'}{2}(\rho + p) + \alpha(\theta_1^{1})' - \frac{\nu'}{2}\alpha(\theta_0^{0} - \theta_1^{1}) - \frac{2\alpha}{r}(\theta_2^{2} - \theta_1^{1}) = 0,$$
(13)

where  $f' \equiv \partial_r f$ . We then note that the perfect fluid equations are formally recovered for  $\alpha \to 0$ . By simple inspection of the field equations (10)-(12), we can identify an effective density  $\tilde{\rho} = \rho + \alpha \, \theta_0^0$ , an effective isotropic pressure  $\tilde{p}_r = p - \alpha \, \theta_1^1$ , and an effective tangential pressure  $\tilde{p}_t = p - \alpha \, \theta_2^2$ . This clearly illustrates that the source  $\theta_{\mu\nu}$  generates an anisotropy  $\Pi \equiv \tilde{p}_r - \tilde{p}_t = \alpha \, (\theta_2^2 - \theta_1^1)$  inside the stellar distribution. At this stage the system (10)-(12) can be treated as an anisotropic fluid [20], and therefore, we would deal with five unknown functions, namely, the two metric functions  $\nu(r)$  and  $\lambda(r)$ , and the effective functions  $\tilde{\rho}$ ,  $\tilde{p}_r$  and  $\tilde{p}_t$ . However, we implement an unconventional way, as explained further below.

### MINIMAL GEOMETRIC DEFORMATION

Now let us implement the MGD to solve the system (10)-(13). We will see that under this approach, the system will be transformed in such a way that the equations of motion associated with the source  $\theta_{\mu\nu}$  will satisfy an effective "quasi-Einstein system" [see further Eqs. (21)-(23)]. Let us start by considering a solution to the system (10)-(13) with  $\alpha=0$ , namely, a GR perfect fluid solution  $\{\xi,\mu,\rho,p\}$ , where  $\xi$  and  $\mu$  are the new metric functions in Eq. (9), which now reads

<span id="page-1-5"></span>
$$ds^{2} = e^{\xi(r)} dt^{2} - \mu(r)^{-1} dr^{2} - r^{2} (d\theta^{2} + \sin^{2}\theta d\phi^{2}) , (14)$$

where

<span id="page-1-9"></span>
$$\mu(r) \equiv 1 - \frac{k^2}{r} \int_0^r x^2 \, \rho \, dx = 1 - \frac{2 \, m(r)}{r} \tag{15}$$

is the standard GR solution containing the mass function m. Now let us turn on the parameter  $\alpha$  to consider the effects of the source  $\theta_{\mu\nu}$  on the perfect fluid solution  $\{\xi, \mu \rho, p\}$ . These effects can be encoded in the geometric deformation undergone by the perfect fluid geometry  $\{\xi, \mu\}$  in Eq. (14), namely,

<span id="page-1-6"></span>
$$\xi \to \nu = \xi + \alpha g \,, \tag{16}$$

$$\mu \to e^{-\lambda} = \mu + \alpha f, \tag{17}$$

where f and g are, respectively, the geometric deformations undergone by the radial and temporal metric components. Of all the possibilities contained in Eqs. (16) and (17), there is a specific one, the so-called minimal geometric deformation, for which

$$g \to 0 \tag{18}$$

$$f \to f^*$$
 . (19)

The metric in Eq. (14) is thus minimally deformed by  $\theta_{\mu\nu}$  and its radial metric component becomes

<span id="page-1-7"></span>
$$\mu(r) \to e^{-\lambda(r)} = \mu(r) + \alpha f^*(r) ,$$
 (20)

while the temporal metric component  $e^{\nu}$  remains unchanged [actually,  $\nu(r)$  becomes  $\nu(r,\alpha)$ , after imposing matching conditions]. We want to emphasize that the expression in Eq. (20) is a linear decomposition of the inverse radial metric component  $g^{11}$  in terms of a pure perfect fluid sector plus a contribution from the source  $\theta_{\mu\nu}$ . Now let us plug the decomposition in Eq. (20) into the Einstein equations (10)-(12). The system is thus separated into two sets: (i) one having the standard Einstein field equations for a perfect fluid ( $\alpha=0$ ), whose metric is given by Eq. (14) with  $\xi(r)=\nu(r)$ ; and (ii) one for the source  $\theta_{\mu\nu}$ , which reads

<span id="page-1-4"></span>
$$-k^2 \,\theta_0^{\,0} = \frac{f^*}{r^2} + \frac{f^{*'}}{r} \,\,, \tag{21}$$

$$-k^2 \,\theta_1^{\,1} = f^* \left( \frac{1}{r^2} + \frac{\nu'}{r} \right) , \qquad (22)$$

$$-k^2 \theta_2^2 = \frac{f^*}{4} \left( 2\nu'' + \nu'^2 + 2\frac{\nu'}{r} \right) + \frac{f^{*'}}{4} \left( \nu' + \frac{2}{r} \right) (23)$$

Since the Einstein tensor  $\hat{G}_{\mu\nu}$  associated with the geometry of the perfect fluid, namely,  $(\nu,\mu)$ , must satisfy its respective Bianchi identity, the energy-momentum tensor  $T_{\mu\nu}^{(m)}$  in Eq. (7) is conserved, and as a consequence, the conservation equation in Eq. (8) yields  $\nabla_{\nu} \theta^{\mu\nu} = 0$ , which explicitly reads

<span id="page-1-8"></span>
$$(\theta_1^{\ 1})' - \frac{\nu'}{2}(\theta_0^{\ 0} - \theta_1^{\ 1}) - \frac{2}{r}(\theta_2^{\ 2} - \theta_1^{\ 1}) = 0 \ . \tag{24}$$

Under these conditions, there is no exchange of energy-momentum between the perfect fluid and the source  $\theta_{\mu\nu}$ ; their interaction is purely gravitational.

There are some important features regarding the system (21)-(24). First of all, it looks very similar to the standard spherically symmetric Einstein field equations for an anisotropic system with energy-momentum tensor  $\theta_{\mu\nu}$ ;  $\{\rho=\theta_0^0;\ p_r=-\theta_1^1;\ p_t=-\theta_2^2\}$  and its respective conservation equation. However, it cannot be formally identified as the spherically symmetric Einstein field equations with radial metric component  $f^*$  since the right-hand sides in Eqs. (21) and (22) do not have the standard expression for the Einstein tensor components  $G_0^0$  and  $G_1^1$  [there is a missed  $-1/r^2$  in both right-hand sides in Eqs. (21) and (22)]. Despite the above, the system (21)-(24) may be formally identified as Einstein equations for an anisotropic system with energy-momentum tensor  $\theta_{\mu\nu}^*$  defined as

<span id="page-2-1"></span>
$$k^2\,\theta_\mu^{*\;\nu} = k^2\,\theta_\mu^{\;\nu} + \frac{1}{r^2} \left( \delta_\mu^{\;0}\,\delta_0^{\;\nu} + \delta_\mu^{\;1}\,\delta_1^{\;\nu} \right) \;, \eqno(25)$$

with conservation equation

$$(\theta_1^{*1})' - \frac{\nu'}{2}(\theta_0^{*0} - \theta_1^{*1}) - \frac{2}{r}(\theta_2^{*2} - \theta_1^{*1}) = 0 , \qquad (26)$$

and metric

<span id="page-2-2"></span>
$$ds^{2} = e^{\nu(r)} dt^{2} - \frac{dr^{2}}{f^{*}(r)} - r^{2} \left( d\theta^{2} + \sin^{2}\theta \, d\phi^{2} \right) . \quad (27)$$

We want to mention an additional feature regarding the system (21)-(24). As is well known, the Bianchi identity has trivial information as longer as no constraint has been imposed on the space-time geometry. Since the MGD imposes a kind of constraint through the expression in Eq. (20), we should expect non-trivial information from the Bianchi identity. Indeed, the system (21)-(23) has two equations without the standard Einstein tensor components, and therefore we should anticipate that the conservation equation (24) for the source  $\theta_{\mu\nu}$  is no longer a linear combination of Eqs. (21)-(23). Remarkably, and despite the above, the conservation equation in Eq. (24) still remains a linear combination of the system (21)-(23). As a consequence, under the MGD, we start with the indefinite system (10)-(12) and we end up with the set of equations for a perfect fluid  $\{\nu, \mu, \rho, p\}$  plus a much simpler system of four unknown functions  $\{f^*, \theta_0^0, \theta_1^1, \theta_2^2\}$ satisfying three equations (21)-(23) (at this stage we suppose that we have already found a perfect fluid solution, thus  $\nu$  is determined). In summary, the system (10)-(12) has been successfully decoupled into two systems, as suggested by Eqs. (2)-(4). At this stage, a natural question arises: What happens if we consider an additional source  $\Psi_{\mu\nu}$  in Eq. (2)? Namely, what if

$$G_{\mu\nu} = -k^2 \left( \hat{T}_{\mu\nu} + \alpha \,\theta_{\mu\nu} + \beta \,\Psi_{\mu\nu} \right) , \qquad (28)$$

with  $\beta$  a coupling constant. The reader can easily follow the same scheme to find a successful decoupling by

$$e^{-\lambda(r)} = \mu(r) + \alpha f^*(r) + \beta h^*(r)$$
, (29)

where, in addition to Eqs. (3) and (4), we have

<span id="page-2-0"></span>
$$\tilde{G}_{\mu\nu} = -k^2 \,\tilde{\Psi}_{\mu\nu} \,\,, \quad \text{to find } \{\tilde{g}_{\mu\nu}, \tilde{\Psi}_{\mu\nu}\} \,\,, \tag{30}$$

with the metric  $\tilde{g}_{\mu\nu}$  in Eq. (30) given by

$$ds^{2} = e^{\nu(r)} dt^{2} - \frac{dr^{2}}{h^{*}(r)} - r^{2} \left( d\theta^{2} + \sin^{2}\theta \, d\phi^{2} \right) , \quad (31)$$

with the sources  $\Psi_{\mu\nu}$  and  $\tilde{\Psi}_{\mu\nu}$  related by the same expression as that in Eq. (25) for  $\theta_{\mu\nu}$  and  $\theta^*_{\mu\nu}$ . We can see that this approach represents a *linear scheme* for decoupling gravitational sources. It can be summarized as follows: Given a static spherically symmetric perfect fluid whose energy-momentum tensor  $\hat{T}_{\mu\nu}$  is coupled to n gravitational sources  $T^{(i)}_{\mu\nu}$ , namely,

<span id="page-2-3"></span>
$$T_{\mu\nu} = \sum_{i=0}^{n} \alpha_i T_{\mu\nu}^{(i)} \; ; \; \alpha_0 = 1 \; ; \; T_{\mu\nu}^0 = \hat{T}_{\mu\nu} \; ,$$
 (32)

the diagonal metric  $g_{\mu\nu}$ , the solution of the Einstein equation  $G_{\mu\nu} = -k^2 T_{\mu\nu}$ , will be given by

$$g_{\mu\nu} = \hat{g}_{\mu\nu} = g_{\mu\nu}^{(i)} \; ; \; \mu = \nu \neq 1 \; ,$$
 (33)

$$g^{11} = \hat{g}^{11} + \alpha_1 g^{11(1)} + \dots + \alpha_n g^{11(n)} . \tag{34}$$

This metric  $g_{\mu\nu}$  is found by first solving Einstein field equations for the perfect fluid source  $\hat{T}_{\mu\nu}$ 

$$\hat{G}_{\mu\nu} = -k^2 \,\hat{T}_{\mu\nu} \; ; \quad \nabla_{\nu} \,\hat{T}^{\mu\nu} = 0 \; ,$$
 (35)

and then by solving the remaining n "quasi-Einstein equations" for the sources  $T_{\mu\nu}^{(i)}$ , namely

<span id="page-2-4"></span>
$$\tilde{G}_{\mu\nu}^{(1)} = -k^2 T_{\mu\nu}^{(1)} ; \quad \nabla_{\nu} T^{(1)\mu\nu} = 0 , 
\vdots 
\tilde{G}_{\mu\nu}^{(n)} = -k^2 T_{\mu\nu}^{(n)} ; \quad \nabla_{\nu} T^{(n)\mu\nu} = 0 ,$$
(36)

where the divergence-free "quasi-Einstein" tensor  $\tilde{G}_{\mu\nu}$  and the standard one  $G_{\mu\nu}$  are related by

$$\tilde{G}_{\mu}^{\ \nu} = G_{\mu}^{\ \nu} + \Gamma_{\mu}^{\ \nu}(g) \ , \tag{37}$$

with  $\Gamma_{\mu}^{\ \nu}(g)$  a tensor that depends exclusively on  $g_{\mu\nu}$ . In our spherically symmetric representation it reads

$$\Gamma_{\mu}^{\ \nu} = \frac{1}{r^2} \left( \delta_{\mu}^{\ 0} \, \delta_0^{\ \nu} + \delta_{\mu}^{\ 1} \, \delta_1^{\ \nu} \right) \ . \tag{38}$$

The explicit components of  $\tilde{G}_{\mu}^{\nu}$  in terms of the metric in Eq. (27) are shown in the right-hand side of Eqs. (21)-(23).

## INTERIOR: FROM PERFECT TO ANISOTROPIC FLUIDS

In order to see the robustness of the MGD, let us solve the Einstein field equations in Eqs. (10)-(12) for the interior of a self-gravitating system. The first step is to turn off  $\alpha$  in order to find a solution for the perfect fluid. Instead of really solving this sector, we simply choose an already-known solution with physical relevance, for instance, the well-known Tolman IV solution  $(\nu, \mu, \rho, p)$  for perfect fluids, namely,

<span id="page-3-0"></span>
$$e^{\nu} = B^2 \left( 1 + \frac{r^2}{A^2} \right) ,$$
 (39)

$$\mu = \frac{\left(1 - \frac{r^2}{C^2}\right)\left(1 + \frac{r^2}{A^2}\right)}{1 + \frac{2r^2}{A^2}} , \tag{40}$$

$$\rho(r) = \frac{3A^4 + A^2 \left(3C^2 + 7r^2\right) + 2r^2 \left(C^2 + 3r^2\right)}{k^2 C^2 \left(A^2 + 2r^2\right)^2} , \quad (41)$$

and

<span id="page-3-1"></span>
$$p(r) = \frac{C^2 - A^2 - 3r^2}{k^2 C^2 (A^2 + 2r^2)} . \tag{42}$$

The constants A, B and C in Eqs. (39)-(42) are found by matching conditions, yielding  $A^2/R^2 = \frac{1-3c}{c}$ ;  $B^2 = 1-3c$  and  $C^2/R^2 = c^{-1}$ , with  $c \equiv M_0/R < 4/9$  and  $M_0$  the total mass m(R) in Eq. (15). Now let us turn on  $\alpha$  to find the metric in Eq. (9), which is the solution of Eqs. (10)-(12). The temporal and radial metric components are given by Eqs. (39) and (20), respectively, while the deformation  $f^*(r)$  and the source  $\theta_{\mu\nu}$  are found through Eqs. (21)-(23). Hence, we need to provide additional information to close the system (21)-(23). We have many alternatives, either an equation of state associated with the source  $\theta_{\mu\nu}$  or some physically motivated restriction on  $f^*(r)$ . In any case, we must be careful in keeping the physical acceptability of our solution, which is not a trivial matter. Regarding this, we can take advantage of the structure of the system (21)-(23), namely, the (quasi) Einstein equations for the source  $(\theta_{\mu\nu})$   $\theta_{\mu\nu}^*$ . From Eq. (22) we can see that the following choice for  $f^*(r),$ 

<span id="page-3-2"></span>
$$f^*(r) = -\mu(r) + \frac{1}{1 + r\nu'(r)} \tag{43}$$

vields

$$k^2 \theta_1^1 = -\frac{1}{r^2} + \mu(r) \left( \frac{1}{r^2} + \frac{\nu'}{r} \right) .$$
 (44)

As a consequence, the radial pressure  $\theta_1^1$  in Eq. (22) mimics the (physically acceptable) perfect fluid pressure p(r)

in Eq. (11). Therefore, after imposing the matching conditions  $C^2 = A^2 + 3R^2$ , the effective radial pressure in Eq. (11) reads

$$\tilde{p}_r = \frac{3(1-\alpha)(R^2 - r^2)}{k^2(A^2 + 3R^2)(A^2 + 2r^2)},$$
(45)

thus leading to a physically acceptable anisotropic fluid solution  $\{\tilde{\rho}, \tilde{p}_r, \tilde{p}_t\}$  to Eqs. (10)-(12). The "mimic constraint" in Eq. (43) is the simplest way to extend the physical acceptability of the perfect fluid solution in the anisotropic domain. In this case  $f^*(r) < 0$ ; hence, it strengthens the gravitational field. Many interesting properties of this anisotropic exact solution can be studied. However, a complete and detailed analysis is beyond the objective of this paper. The reader can prove, by following this simple scheme, that any known perfect fluid solution can be consistently extended to generate new anisotropic solutions. In principle, for each perfect fluid solution there will be as many anisotropic solutions as independent constraints can be imposed on the system (21)-(23). We conclude by emphasizing that the approach described here represents an effective and systematic method for decoupling gravitational sources, as shown through Eqs. (32)-(36). In addition to other virtues, it is a robust and direct way to generate anisotropic solutions for self-gravitating systems from perfect fluid solutions. It represents, as far as we know, the first simple, systematic and direct method that shows how to decouple gravitational sources in general relativity, and therefore a good guide to consider more complex scenarios. In this respect, the method can be generalized by also considering a deformation on the temporal metric component, and thus to investigate the impact of different gravitational sources, generically represented here as  $\theta_{\mu\nu}$ : for instance, to consider the Maxwell tensor or the coupling with Klein-Gordon scalar fields, or even both simultaneously. On the other hand, this approach will simplify the analysis of the stability of self-gravitating systems, which can be developed sector by sector under the MGD. In this respect, for instance, we know that finding analytic and physically relevant solutions for the interior of a self-gravitating system minimally coupled to a scalar field  $\psi$  seems an impossible task to carry out. However, under the MGD, we can start with an exact and physically acceptable perfect fluid solution, and then focus solely on the scalar sector represented by  $\psi$ . This obviously represents a great simplification. In addition to all of the above, since the interaction among the sources under the MGD is purely gravitational, it is particularly useful to study the interaction between ordinary matter and the conjectured dark matter. Finally, some questions regarding the MGD and the way it works remain open: for instance, its validity for time-dependent solutions and a possible extension beyond the spherical symmetry, as well as a formal mathematical description, if any, of the decoupling in Eqs. (32)-(36) in terms of Killing vectors.

" Yo amo los mundos sutiles, ingr´avidos y gentiles, como pompas de jab´on " Antonio Machado

#### ∗ [jovalle@usb.ve](mailto:jovalle@usb.ve)

- <span id="page-4-1"></span><span id="page-4-0"></span>[1] Hans Stephani, Dietrich Kramer, Malcolm Maccallum, Cornelius Hoenselaers, Eduard Herlt, Exact Solutions of Einsteins Field Equations(Cambridge University Press, Cambridge, 2003).
- <span id="page-4-2"></span>[2] M. S. R. Delgaty and K. Lake, Comput. Phys. Commun. 115 395 (1998).
- [3] K. Lake, Phys.Rev. D 67 104015 (2003).
- <span id="page-4-3"></span>[4] Petarpa Boonserm, Matt Visser, Silke Weinfurtner, Phys.Rev. D 71 (2005) 124037.
- <span id="page-4-4"></span>[5] K. Lake, Phys.Rev.Lett. 92 (2004) 051101.
- <span id="page-4-5"></span>[6] L. Herrera, J. Ospino and A. Di Prisco, Phys. Rev. D 77, 027502 (2008).
- <span id="page-4-6"></span>[7] J. Ovalle, Mod. Phys. Lett. A, 23, 3247 (2008).
- <span id="page-4-7"></span>[8] J. Ovalle, Braneworld stars: anisotropy minimally projected onto the brane, in Gravitation and Astrophysics

- (ICGA9), edited by J. Luo, (World Scientific, Singapore, 2010), pp. 173- 182.
- <span id="page-4-8"></span>[9] L. Randall and R. Sundrum, Phys. Rev. Lett. 83, 3370 (1999)
- <span id="page-4-9"></span>[10] L. Randall and R. Sundrum, Phys. Rev. Lett 83, 4690 (1999).
- <span id="page-4-10"></span>[11] Roberto Casadio, Jorge Ovalle, Roldao da Rocha, Class. Quantum Grav. 32, 215020 (2015).
- <span id="page-4-11"></span>[12] J Ovalle, Int. J. Mod. Phys. Conf. Ser. 41 1660132 (2016).
- <span id="page-4-12"></span>[13] J. Ovalle, F. Linares, Phys. Rev. D, 88, 104026 (2013).
- <span id="page-4-13"></span>[14] J. Ovalle, L.A. Gergely, R. Casadio, Class. Quantum Grav., 32, 045015 (2015).
- [15] R. Casadio, J. Ovalle, R. da Rocha, Europhys. Lett., 110, 40003 (2015).
- [16] R. T. Cavalcanti, A. Goncalves da Silva, Roldao da Rocha, Class. Quantum Grav. 33, 215007 (2016).
- <span id="page-4-14"></span>[17] Roberto Casadio, Roldao da Rocha, Phys. Lett. B 763, 434 (2016).
- <span id="page-4-15"></span>[18] Some conditions are established by Basilis C. Xanthopoulos, Superposition of solutions in general relativity in Lecture Notes in Physics 239, edited by R. Martini. Springer-Verlag, Berlin, 1985., p.109, under which Einstein equations behave like linear equations.
- <span id="page-4-16"></span>[19] Piyabut Burikham, Tiberiu Harko, Matthew J. Lake, Phys. Rev. D 94, 064070 (2016).
- <span id="page-4-17"></span>[20] L. Herrera, N.O. Santos, Phys.Rept. 286 53 (1997).