# Cosmology from Schwarzschild black hole revisited

Roberto Casadio\* and Alexander Kamenshchik<sup>†</sup>

Dipartimento di Fisica e Astronomia, Alma Mater Università di Bologna, 40126 Bologna, Italy Istituto Nazionale di Fisica Nucleare, I.S. FLaG Sezione di Bologna, 40127 Bologna, Italy

## Jorge Ovalle<sup>‡</sup>

Research Centre for Theoretical Physics and Astrophysics, Institute of Physics, Silesian University in Opava, CZ-746 01 Opava, Czech Republic.

We study cosmological models based on the interior of the revisited Schwarzschild black hole recently reported in [Phys. Rev. D109 (2024) 104032]. We find that these solutions describe a non-trivial Kantowski-Sachs universe, for which we provide an explicit analytical example with all the details and describe some general features of the singularity.

## I. INTRODUCTION

The Schwarzschild metric is the most famous and simplest black hole (BH) solution in general relativity (GR), containing a point-like singularity of ADM mass  $\mathcal{M}$  hidden behind the event horizon or radius  $2\,\mathcal{M}$ . Ref. [1] investigated alternative sources for the exterior region of the Schwarzschild BH in GR, under the conditions that it does not contain any form of exotic matter nor does it depend on any new parameter other than  $\mathcal{M}$ . A large set of new solutions was then found that can describe the inner region before all matter energy contributing to the total mass  $\mathcal{M}$  has collapsed into the singularity in accordance with Penrose's singularity theorem [2].

The most attractive features of these interiors are that the space-time across the horizon is continuous (without additional structures like a thin shell) and tidal forces remain finite everywhere for (integrable [3–5]) singular solutions. The importance of some of these solutions lies in the fact that they might be alternative to the Schwarzschild BH as the final stage of the gravitational collapse and are therefore potentially useful for studying the gravitational collapse of compact astrophysical objects: if we enforce the weak cosmic censorship conjecture [6] to avoid naked singularities, the event horizon must form before the central singularity. This means that (at least) part of the total mass  $\mathcal{M}$  enclosed within the event horizon is still on the way to the final singularity. Such a scenario is precisely described by the (integrable) singular solutions reported in Ref. [1].

Finally, we want to highlight that the existence of such an (incomplete) set of solutions shows very explicitly the broad diversity that is possible in the interior region of the Schwarzschild geometry. This is very attractive if we want to study the appearance of singularities, not only associated with the formation of BHs, but also in the very early Universe. The main goal of this work is

precisely to investigate cosmological consequences that can be derived from the aforementioned solutions.

### II. INSIDE THE BLACK HOLE

We begin by recalling that the most general static and spherically symmetric metric can be written as [7]

$$ds^{2} = -e^{\Phi(r)} f(r) dt^{2} + \frac{dr^{2}}{f(r)} + r^{2} d\Omega^{2} , \qquad (1)$$

where

$$f = 1 - \frac{2m(r)}{r} \ . \tag{2}$$

The Schwarzschild solution [8] is obtained by setting

<span id="page-0-3"></span>
$$\Phi(r) = 0 \tag{3}$$

and the Misner-Sharp mass function

<span id="page-0-4"></span>
$$m(r) = \mathcal{M}$$
, for  $r > 0$ , (4)

where  $\mathcal{M}$  is the ADM mass associated with a point-like singularity at the center r = 0. The coordinate singularity at  $r = 2 \mathcal{M} \equiv h$  indicates the event horizon [9–13].

We are interested in exploring extensions of the Schwarzschild BH which still belong to the Kerr-Schild class [14] and will therefore keep the condition (3) but relax the condition (4) to

$$m(r) = \mathcal{M}$$
, for  $r \ge h$ , (5)

where  $^{1}$ 

<span id="page-0-6"></span>
$$\mathcal{M} \equiv m(h) = h/2 \tag{6}$$

<span id="page-0-0"></span><sup>\*</sup> casadio@bo.infn.it

<span id="page-0-1"></span><sup>†</sup> kamenshchik@bo.infn.it

<span id="page-0-2"></span><sup>&</sup>lt;sup>‡</sup> jorge.ovalle@physics.slu.cz

<span id="page-0-5"></span><sup>&</sup>lt;sup>1</sup> We shall denote  $F(h) \equiv F(r)|_{r=h}$  for any F = F(r). We shall also use units with c = 1 and  $\kappa = 8 \pi G_N$ .

stands for the total mass of the BH and h is again the radius of its event horizon. In summary, the line element for the problem we want to solve is given by

<span id="page-1-0"></span>
$$ds^{2} = \begin{cases} -\left(1 - \frac{2m}{r}\right)dt^{2} + \frac{dr^{2}}{1 - \frac{2m}{r}} + r^{2}d\Omega^{2}, & 0 < r \le h \\ -\left(1 - \frac{2\mathcal{M}}{r}\right)dt^{2} + \frac{dr^{2}}{1 - \frac{2\mathcal{M}}{r}} + r^{2}d\Omega^{2}, & r > h, \end{cases}$$
(7)

where m is the mass function associated with a Lagrangian  $\mathcal{L}_{\mathrm{M}}$  representing ordinary matter only, so that our theory is described by the Einstein-Hilbert action

<span id="page-1-1"></span>
$$S = \int \left(\frac{R}{2\,\kappa} + \mathcal{L}_{\rm M}\right) \sqrt{-g} \, d^4 x \;, \tag{8}$$

with R the scalar curvature. Notice that Eqs. (7) and (8) imply that  $\mathcal{L}_{\mathrm{M}} = 0$  for r > h only, and the Einstein field equations in the interior 0 < r < h yield an energy-momentum tensor

<span id="page-1-2"></span>
$$T^{\mu}_{\ \nu} = \operatorname{diag}\left[p_r, -\epsilon, p_{\theta}, p_{\theta}\right] , \tag{9}$$

such that the energy density  $\epsilon$ , radial pressure  $p_r$  and transverse pressure  $p_{\theta}$  satisfy

<span id="page-1-3"></span>
$$\epsilon = \frac{2 m'}{\kappa r^2}, \quad p_r = -\frac{2 m'}{\kappa r^2}, \quad p_\theta = -\frac{m''}{\kappa r}.$$
(10)

We remark that Eq. (9) takes into account the fact that the radial and temporal coordinates exchange roles for 0 < r < h. Finally, since Eqs. (10) are linear in the mass function m, any two solutions can be linearly combined to produce a new solution, which represents a trivial case of the so-called gravitational decoupling [15, 16].

The contracted Bianchi identities  $\nabla_{\mu} G^{\mu}_{\ \nu} = 0$  leads to  $\nabla_{\mu} T^{\mu\nu} = 0$ , which yields the continuity equation

<span id="page-1-4"></span>
$$\epsilon' = -\frac{2}{r} \left( p_{\theta} - p_r \right) . \tag{11}$$

Since the energy density  $\epsilon$  is expected to decrease monotonically from the origin outwards, that is  $\epsilon' < 0$ , Eq. (11) implies that

$$p_{\theta} > p_r \tag{12}$$

so that the fluid experiences a pull towards the center as a consequence of negative energy gradients  $\epsilon' < 0$  that is canceled by a gravitational repulsion caused by the anisotropic pressure.

We next need to examine the compatibility of the Schwarzschild exterior with the above interior, i.e. the continuity of the metric (7) across the horizon r = h. This clearly implies that the mass function must satisfy the matching conditions

<span id="page-1-5"></span>
$$m(h) = \mathcal{M} , \quad m'(h) = 0 . \tag{13}$$

Finally, we see from Eqs. (10) and (13) that the continuity of the mass function implies the continuity of both density and radial pressure,

$$\epsilon(h) = p_r(h) = 0 . (14)$$

However, the pressure  $p_{\theta}$  can be in general discontinuous.

# III. BLACK HOLES WITH INTEGRABLE SINGULARITIES

BH geometries are usually grouped into two types: (i) singular BH with a physical singularity of some kind, and (ii) regular BH without singularities. The existence of regular BHs is, of course, very attractive but it is well known that they usually display an inner (Cauchy) horizon inside the event horizon, which turns out to give rise to problems such as mass inflation, instability, and eventual loss of causality [17, 18] (see also Refs. [5, 19–26] for recent studies). Between the two aforementioned families we can also find integrable BHs [3], which are characterized by a singularity in the curvature R that occurs at most as

$$R \sim r^{-2} \ , \tag{15}$$

so that their Einstein-Hilbert action is indeed finite. Their main features are that tidal forces remain finite everywhere, the mass function is well-defined and finite, and (in general) there are no Cauchy horizons.

Regarding the last feature, we here review the work in Ref. [1] and start with the scalar curvature for the interior metric (7), which reads

<span id="page-1-6"></span>
$$R = \frac{2r m'' + 4 m'}{r^2} , \quad \text{for } 0 < r \le h .$$
 (16)

In order to have an integrable singularity, we demand [1]

$$R = \sum_{n=0}^{\infty} C_n r^{n-2} , \quad n \in \mathbb{N} , \qquad (17)$$

which, from Eq. (16), yields the mass function

<span id="page-1-7"></span>
$$m = M - \frac{Q^2}{2r} + \frac{1}{2} \sum_{n=0}^{\infty} \frac{C_n r^{n+1}}{(n+1)(n+2)},$$
 (18)

for  $0 < r \le h$ , where M and Q are integration constants that can be identified with the mass of the Schwarzschild solution and a charge for the Reissner-Nordström (RN) geometry, respectively. However, since it is known that the RN geometry contains a Cauchy horizon, we impose Q = 0. This leaves us with the two charges M and M.

Let us notice that the series (18) converges around r=h as soon as we impose the condition (6), but it remains to see if it can represent an analytic function in its whole domain  $0 < r \le h$ . Moreover, the Schwarzschild metric is simply given by the condition in Eq. (4), that is  $M=\mathcal{M} \ne 0$  and  $Q=C_n=0$  for all n in Eq. (18). In Ref. [1], other interior solutions where found with

$$M = Q = 0. (19)$$

which are determined by the total mass  $\mathcal{M}$  and some of the  $C_n \neq 0$ , so that the exterior is still given by the Schwarzschild solution in Eq. (7). From the mass function (10), the energy density and pressures associated

with these interior geometries read

$$\kappa \epsilon = \sum_{n=0}^{\infty} \frac{C_n r^{n-2}}{n+2} = -\kappa p_r \tag{20}$$

$$\kappa p_t = -\frac{1}{2} \sum_{n=0}^{\infty} \frac{n}{n+2} C_n r^{n-2} , \qquad (21)$$

for  $0 < r \le h$ .

The simplest of such solutions was found by imposing the continuity conditions (13) on the mass function (18) [see Ref. [1] for all details], which yields

<span id="page-2-7"></span>
$$m = r - \frac{r^2}{2h} , \qquad (22)$$

corresponding to the interior line element

<span id="page-2-2"></span>
$$ds^{2} = \left(1 - \frac{r}{h}\right) dt^{2} - \frac{dr^{2}}{1 - \frac{r}{h}} + r^{2} d\Omega^{2} , \quad \text{for } 0 < r \le h.$$
(23)

The source is given by

$$\kappa \epsilon = -\kappa p_r = \frac{2}{r^2} \left( 1 - \frac{r}{h} \right) , \quad \kappa p_\theta = \frac{1}{h r} , \qquad (24)$$

generating the curvature

$$R = \frac{4}{r^2} \left( 1 - \frac{3r}{2h} \right) , \text{ for } 0 < r \le h .$$
 (25)

A second solution can be found by imposing a smoother transition between the two regions separated by the horizon, that is

<span id="page-2-6"></span>
$$m''(h) = 0 (26)$$

which yields

<span id="page-2-0"></span>
$$m = r - \frac{r^3}{h^2} + \frac{r^4}{2h^3} \ . \tag{27}$$

The line element is

<span id="page-2-3"></span>
$$ds^{2} = \left(1 - \frac{2r^{2}}{h^{2}} + \frac{r^{3}}{h^{3}}\right) dt^{2} - \frac{dr^{2}}{1 - \frac{2r^{2}}{h^{2}} + \frac{r^{3}}{h^{3}}} + r^{2} d\Omega^{2}, \quad \text{for } 0 < r \le h,$$
(28)

sourced by

$$\kappa \epsilon = -\kappa p_r = \frac{2}{r^2 h^3} (h - r)^2 (h + 2r) ,$$

$$\kappa p_{\theta} = \frac{6}{h^3} (h - r) , \qquad (29)$$

which produces a curvature

$$R = \frac{4}{r^2} \left( 1 + \frac{5r^3}{h^3} - \frac{6r^2}{h^2} \right) , \quad \text{for } 0 < r \le h .$$
 (30)

![](_page_2_Figure_23.jpeg)

![](_page_2_Figure_24.jpeg)

<span id="page-2-5"></span>FIG. 1. Mass function in Eq. (36) (upper panel) and corresponding metric function  $f=1-2\,m/r$  (lower panel) for N=10. The vertical line represents the horizon  $h=2\,\mathcal{M}$  for  $\mathcal{M}=1$  and red (blue) colour is for the interior (exterior).

Finally, it can be proven [1] that the mass function (27) is a particular case of

<span id="page-2-1"></span>
$$m = r + \frac{r}{n^2 - 2n - 1} \left(\frac{r}{h}\right)^n \left[1 - \frac{(n-1)^2}{2} \left(\frac{r}{h}\right)^{\frac{2}{n-1}}\right],$$
(31)

where  $n > 1 \in \mathbb{N}$  includes the polynomial case n = 2 in Eq. (27). The mass function (31) yields the metric function

<span id="page-2-4"></span>
$$f = 1 + \left(\frac{r}{h}\right)^n \frac{\left[2 - (n-1)^2 \left(r/h\right)^{\frac{2}{n-1}}\right]}{n^2 - 2n - 1} \ . \tag{32}$$

It is easy to show that the BHs in Eqs. (23), (28) and (32) have no inner horizon. Indeed, as conjectured in Ref. [1], apart from the Schwarzschild BH, the simplest two single horizon BH solutions, with the total mass  $\mathcal{M}$  as a unique charge, are those displayed in Eqs. (23) and (28) for the region 0 < r < h, which smoothly join the Schwarzschild exterior at the horizon  $r = h = 2 \mathcal{M}$ .

We can obtain more solutions by considering the metric

function in Eq. (18) and truncating the series as  $^2$ 

<span id="page-3-3"></span>
$$m = r + \sum_{i=2}^{N} C_i r^i$$
, (33)

where N > 2 and the (N-1) unknown  $C_i$  can be found by the condition (6) and

<span id="page-3-2"></span>
$$\frac{d^n m}{dr^n}(h) = 0 , (34)$$

for all  $n \leq N - 2$ . A straightforward consequence of the differential constraints (34) is that the energy-momentum tensor is continuous at the horizon for N > 3, that is,

$$T^{\mu}_{\ \nu}(h) = 0$$
 . (35)

For example, the solution with N = 10 is given by

<span id="page-3-0"></span>
$$m = r + \frac{27 r^2}{2 h} - \frac{84 r^3}{h^2} + \frac{231 r^4}{h^3} - \frac{378 r^5}{h^4} + \frac{399 r^6}{h^5} - \frac{276 r^7}{h^6} + \frac{243 r^8}{2 h^7} - \frac{31 r^9}{h^8} + \frac{7 r^{10}}{2 h^9} , \qquad (36)$$

which is displayed in Fig. 1. A simple analysis of the expression for the mass function (33) shows that the strong energy condition is violated for N > 4 ( $p_{\theta} < 0$  for  $r \gtrsim 0$ ). However, the weak energy condition still holds. If we instead consider a polynomial solution of the form

<span id="page-3-4"></span>
$$m = r + A r^{l} + B r^{n} + C r^{p}, \quad p \neq n \neq l > 1,$$
 (37)

where A, B and C are constants to be determined from Eqs. (13) and (26), we generate the solutions displayed in Table I. Indeed, we could go further by including additional terms in (37), or just by relaxing the energy conditions, which are most likely violated at high curvature. Therefore, we can safely conclude that the inner region is much richer than illustrated in Table I. This will be particularly important for the cosmological models, as we will see next.

### IV. COSMOLOGY

All of the interior BH solutions in Table I can be considered as a whole universe [27], which is precisely what we will explore next. Let us start by noticing that for  $0 < r \le h$  the line element has the form

<span id="page-3-5"></span>
$$ds^{2} = F(r) dt^{2} - \frac{dr^{2}}{F(r)} + r^{2} d\Omega^{2} , \qquad (38)$$

where

$$F = 1 - \frac{2\mu(r)}{r} \ge 0 , \qquad (39)$$

and

$$\mu = -(A r^{l} + B r^{n} + C r^{p}) \tag{40}$$

can be read directly from Table I. We can rewrite the metric (38) by making explicit the role of time and radial coordinates as

<span id="page-3-6"></span>
$$ds^{2} = -\frac{dt^{2}}{F(t)} + F(t) dr^{2} + t^{2} d\Omega^{2} , \qquad (41)$$

where

$$F = 1 - \frac{2\mu(t)}{t} \ge 0 \tag{42}$$

is displayed in Table II for each case of Table I, respectively, with  $0 < t < t_0 = h$ .

We can further write the metric (41) in terms of the cosmic (or synchronous) time defined by

$$d\tau = \pm \frac{dt}{\sqrt{F(t)}} \,\,\,(43)$$

which leads to the generic cosmological solution

<span id="page-3-7"></span>
$$ds^{2} = -d\tau^{2} + a^{2}(\tau) dr^{2} + b^{2}(\tau) d\Omega^{2} . \tag{44}$$

The metric (44) represents a Kantowski-Sachs universe [28, 29] with the two scale factors

$$a^{2}(\tau) \equiv F(\tau)$$

$$b^{2}(\tau) \equiv t^{2}(\tau) . \tag{45}$$

This solution in general describes an homogeneous but anisotropic universe, with Einstein tensor

$$G_0^0 = -\left(\frac{1}{b^2} + \frac{2\dot{a}\dot{b}}{ab} + \frac{\dot{b}^2}{b^2}\right)$$
 (46)

$$G_{1}^{1} = -\left(\frac{1}{b^{2}} + \frac{2\ddot{b}}{b} + \frac{\dot{b}^{2}}{b^{2}}\right) \tag{47}$$

$$G_2^2 = -\left(\frac{\dot{a}\,\dot{b}}{a\,b} + \frac{\ddot{a}}{a} + \frac{\ddot{b}}{b}\right) . \tag{48}$$

Let us consider, for instance, the simplest inner BH given by the metric (23), which yields

$$ds^{2} = -\frac{dt^{2}}{1 - t/t_{0}} + \left(1 - \frac{t}{t_{0}}\right)dr^{2} + t^{2} d\Omega^{2} , \qquad (49)$$

for  $0 < t < t_0$ . We have

$$F = 1 - \frac{t}{t_0} \,\,\,\,(50)$$

which leads to the cosmic time

$$\tau(t) = -2t_0 \sqrt{1 - \frac{t}{t_0}} , \text{ for } t < t_0 ,$$
 (51)

<span id="page-3-1"></span><sup>&</sup>lt;sup>2</sup> Expressions in Eqs. (22) and (27) correspond to (33) for N=3 and N=4, respectively.

| $\{l, n, p\}$ | $m(r) = r + A r^l + B r^n + C r^p$                                                                                                                                                        | $\epsilon > 0$         | Energy condition |
|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|------------------|
| $\{2, n, p\}$ | $m(r) = r - \frac{[2-2p+n(p-2)]}{2(n-2)(p-2)} \frac{r^2}{h} + \frac{h}{(n-2)(n-p)} \left(\frac{r}{h}\right)^n + \frac{h}{(p-2)(p-n)} \left(\frac{r}{h}\right)^p$                          | Yes                    | Strong           |
| ${3, 4, p}$   | $m(r) = r - \frac{r^3}{h^2} + \frac{r^4}{2h^3}$                                                                                                                                           | Yes                    | Strong           |
| $\{3, 5, p\}$ | $m(r) = r - \frac{h}{4} \frac{(3p-8)}{(p-3)} \left(\frac{r}{h}\right)^3 + \frac{h}{4} \frac{(p-4)}{(p-5)} \left(\frac{r}{h}\right)^5 - \frac{h/2}{(p-3)(p-5)} \left(\frac{r}{h}\right)^p$ | $Yes (6 \le p \le 16)$ | Strong           |
| ${3, 6, p}$   | $m(r) = r - \frac{h}{3} \frac{(2p-5)}{(p-3)} \left(\frac{r}{h}\right)^3 + \frac{h}{6} \frac{(p-4)}{(p-6)} \left(\frac{r}{h}\right)^6 - \frac{h}{(p-3)(p-6)} \left(\frac{r}{h}\right)^p$   | $Yes (7 \le p \le 10)$ | Strong           |
| ${3, 7, 8}$   | $m(r) = r - \frac{7r^3}{10h^2} + \frac{r^7}{2h^6} - \frac{3r^8}{10h^7}$                                                                                                                   | Yes                    | Strong           |
| $\{4, 5, 6\}$ | $m(r) = r - \frac{5r^4}{2h^3} + \frac{3r^5}{h^4} - \frac{r^6}{h^5}$                                                                                                                       | Yes                    | Strong           |

<span id="page-4-0"></span>TABLE I. Interior geometries with mass function (37) satisfying m'(h) = m''(h) = 0.

<span id="page-4-1"></span>TABLE II. Cosmological form (41) of the geometries in Table I with  $t \le t_0 = h$  where  $\mu'(t_0) = 1$  and  $\mu''(t_0) = 0$ .

| $\{l, n, p\}$ | $F(t) = 1 - \frac{2\mu(t)}{t} \ge 0$ .                                                                                                                                                            | $\epsilon > 0$         | Energy condition |
|---------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|------------------|
| $\{2,n,p\}$   | $F(t) = 1 - \frac{[2-2p+n(p-2)]}{(n-2)(p-2)} \left(\frac{t}{t_0}\right) + \frac{2}{(n-2)(n-p)} \left(\frac{t}{t_0}\right)^{n-1} + \frac{2}{(p-2)(p-n)} \left(\frac{t}{t_0}\right)^{p-1}$          | Yes                    | Strong           |
| $\{3, 4, p\}$ | $F(t) = 1 - 2\left(\frac{t}{t_0}\right)^2 + \left(\frac{t}{t_0}\right)^3$                                                                                                                         | Yes                    | Strong           |
| ${3, 5, p}$   | $F(t) = 1 - \frac{1}{2} \frac{(3p-8)}{(p-3)} \left(\frac{t}{t_0}\right)^2 + \frac{1}{2} \frac{(p-4)}{(p-5)} \left(\frac{t}{t_0}\right)^4 - \frac{1}{(p-3)(p-5)} \left(\frac{t}{t_0}\right)^{p-1}$ | $Yes (6 \le p \le 16)$ | Strong           |
| ${3, 6, p}$   | $F(t) = 1 - \frac{2}{3} \frac{(2p-5)}{(p-3)} \left(\frac{t}{t_0}\right)^2 + \frac{1}{3} \frac{(p-4)}{(p-6)} \left(\frac{t}{t_0}\right)^5 - \frac{2}{(p-3)(p-6)} \left(\frac{t}{t_0}\right)^{p-1}$ | $Yes (7 \le p \le 10)$ | Strong           |
| ${3, 7, 8}$   | $F(t) = 1 - \frac{7}{5} \left(\frac{t}{t_0}\right)^2 + \left(\frac{t}{t_0}\right)^6 - \frac{3}{5} \left(\frac{t}{t_0}\right)^7$                                                                   | Yes                    | Strong           |
| {4, 5, 6}     | $F(t) = 1 - 5\left(\frac{t}{t_0}\right)^3 + 6\left(\frac{t}{t_0}\right)^4 - 2\left(\frac{t}{t_0}\right)^5$                                                                                        | Yes                    | Strong           |

and

<span id="page-4-2"></span>
$$ds^{2} = -d\tau^{2} + \frac{\tau^{2}}{\tau_{0}^{2}}dr^{2} + \frac{\tau_{0}^{2}}{4}\left(\frac{\tau^{2}}{\tau_{0}^{2}} - 1\right)^{2}d\Omega^{2}, \quad (52)$$

where  $\tau_0 \equiv 2 t_0$ . Notice that in this case the scale factors satisfy

$$b^2 = \frac{\tau_0^2}{4} \left( a^2 - 1 \right)^2 . {(53)}$$

The source of the metric (52) is given by

$$\kappa \epsilon = -\kappa p_r = \frac{8\tau^2}{\left(\tau^2 - \tau_0^2\right)^2} \tag{54}$$

$$\kappa p_{\theta} = \frac{4}{\tau_0^2 - \tau^2} , \qquad (55)$$

with curvature

<span id="page-4-3"></span>
$$R = \frac{8 \left(3 \tau^2 - \tau_0^2\right)}{\left(\tau^2 - \tau_0^2\right)^2} \ . \tag{56}$$

The anisotropy for this example is therefore given by

$$\Delta \equiv p_{\theta} - p_{r} = \frac{4}{\kappa} \frac{\tau^{2} + \tau_{0}^{2}}{(\tau^{2} - \tau_{0}^{2})^{2}} . \tag{57}$$

The above example contains a curvature singularity in Eq. (56) for  $\tau \to \tau_0$ . In fact, we can study the behaviour of these universes in the vicinity of the cosmological singularity in general. The curvature scalar of the

metric (41) is given by

<span id="page-4-4"></span>
$$R = F'' + \frac{4F'}{t} + \frac{2F}{t^2} + \frac{2}{t^2} , \qquad (58)$$

where primes stand for derivatives with respect to t. Since all of the functions F in Table II are polynomials in t with the constant term equal to 1, Eq. (58) is singular at t=0. In fact, it is easy to see that the curvature behaves as

<span id="page-4-5"></span>
$$R \approx \frac{4}{t^2} \;, \quad \text{for } t \to 0 \;, \tag{59}$$

for all the functions F.

We can also consider the cosmic time

$$d\tau = \frac{dt}{\sqrt{F(t)}} \ . \tag{60}$$

The function  $F(t) \approx 1$  in the vicinity of the singularity t=0 and, with a convenient choice of the integration constant, we have

$$\tau \approx t$$
 . (61)

Thus, the curvature singularity in Eq. (59) can also be written as

<span id="page-4-6"></span>
$$R \approx \frac{4}{\tau^2}$$
, for  $\tau \to 0$ . (62)

It is interesting to compare this result with the singularities arising in isotropic Friedmann cosmologies. Let us consider a flat Friedmann universe with the metric

$$ds^{2} = -d\tau^{2} + a^{2}(\tau) \left( dr^{2} + r^{2} d\Omega^{2} \right) , \qquad (63)$$

whose scalar curvature is given by

$$R = 6\left(\frac{\ddot{a}}{a} + \frac{\dot{a}^2}{a^2}\right) , \qquad (64)$$

where dots stand for derivatives with respect to τ . For a power law expansion,

<span id="page-5-13"></span>
$$a = a_0 \tau^k , (65)$$

we have

$$R = \frac{6k(2k-1)}{\tau^2} \ . \tag{66}$$

This leads to the same singularity as the one in Eq. [\(62\)](#page-4-6) if 6 k (2 k − 1) = 4, or

<span id="page-5-14"></span>
$$k = \frac{1}{4} \left( 1 + \sqrt{\frac{19}{3}} \right) . {(67)}$$

It is known that a homogeneous and isotropic universe which expands according to the power law [\(65\)](#page-5-13) is filled with a barotropic fluid with equation of state

$$p = w \varepsilon , (68)$$

where the parameter w is constant and

$$k = \frac{2}{3(1+w)} , (69)$$

or

$$w = \frac{2}{3k} - 1 \ . \tag{70}$$

From Eq. [\(67\)](#page-5-14), we then find

$$w = \frac{8}{3\left(1 + \sqrt{19/3}\right)} - 1 \simeq -0.24 \ . \tag{71}$$

This means that our homogeneous but anisotropic universe behaves near the singularity like a homogeneous and isotropic universe driven by a isotropic fluid with negative pressure but equation of state parameter w > −1/3, which is the critical value below which the deceleration would turn into acceleration.

## V. CONCLUSION

Generating cosmological models from BH geometries is a well-known procedure which, in general, allows us to develop solutions beyond the standard (isotropic and homogeneous) cosmological models. On the other hand, a plethora of new BH solutions have been reported in recent years, whose interest is especially due to their interpretation in terms of nonlinear electrodynamics [\[30\]](#page-6-6). This leads to the possibility of constructing a plethora of new cosmological models as well. Obviously, this could become counterproductive if what we seek are cosmological alternatives, beyond the standard model, whose origin is fully justified by first principles.

In this sense, the advantage of our cosmological solutions in Table [II](#page-4-1) is that they are derived from a family of very non-trivial BH geometries. They are solutions that in fact tell us a lot about how complex the interior of the simplest spherically symmetric BHs could be. Therefore, their cosmological versions, as well as possible extensions, are quite attractive, especially if we want to justify processes that are not yet well understood, such as the phenomenology of dark matter and dark energy, and possible explanations based on cosmological models other than the presently dominant one.

### Acknowledgments

R.C. and A.K. are partially supported by the INFN grant FLAG. The work of R.C. has also been carried out in the framework of activities of the National Group of Mathematical Physics (GNFM, INdAM). J.O. is partially supported by ANID FONDECYT Grant No. 1210041.

<span id="page-5-0"></span><sup>[1]</sup> J. Ovalle, Phys. Rev. D 109[, 104032 \(2024\).](https://doi.org/10.1103/PhysRevD.109.104032)

<span id="page-5-1"></span><sup>[2]</sup> R. Penrose, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.14.57) 14, 57 (1965).

<span id="page-5-2"></span><sup>[3]</sup> V. N. Lukash and V. N. Strokov, [Int. J. Mod. Phys. A](https://doi.org/10.1142/S0217751X13500073) 28[, 1350007 \(2013\),](https://doi.org/10.1142/S0217751X13500073) [arXiv:1301.5544 \[gr-qc\].](http://arxiv.org/abs/1301.5544)

<sup>[4]</sup> R. Casadio, [Int. J. Mod. Phys. D](https://doi.org/10.1142/S0218271822501280) 31, 2250128 (2022), [arXiv:2103.00183 \[gr-qc\].](http://arxiv.org/abs/2103.00183)

<span id="page-5-3"></span><sup>[5]</sup> R. Casadio, A. Giusti, and J. Ovalle, [JHEP](https://doi.org/10.1007/JHEP05(2023)118) 05, 118 [\(2023\),](https://doi.org/10.1007/JHEP05(2023)118) [arXiv:2303.02713 \[gr-qc\].](http://arxiv.org/abs/2303.02713)

<span id="page-5-4"></span><sup>[6]</sup> R. Penrose, [Riv. Nuovo Cim.](https://doi.org/10.1023/A:1016578408204) 1, 252 (1969).

<span id="page-5-5"></span><sup>[7]</sup> M. S. Morris and K. S. Thorne, [Am. J. Phys.](https://doi.org/10.1119/1.15620) 56, 395 [\(1988\).](https://doi.org/10.1119/1.15620)

<span id="page-5-6"></span><sup>[8]</sup> K. Schwarzschild, Sitzungsber. Preuss. Akad. Wiss. Berlin (Math. Phys. ) 1916, 189 (1916).

<span id="page-5-7"></span><sup>[9]</sup> A. S. Eddington, Nature 113[, 192 \(1924\).](https://doi.org/10.1038/113192a0)

<sup>[10]</sup> G. Lemaitre, [Annales Soc. Sci. Bruxelles A](https://doi.org/10.1023/A:1018855621348) 53, 51 (1933).

<sup>[11]</sup> D. Finkelstein, Phys. Rev. 110[, 965 \(1958\).](https://doi.org/10.1103/PhysRev.110.965)

<sup>[12]</sup> M. D. Kruskal, Phys. Rev. 119[, 1743 \(1960\).](https://doi.org/10.1103/PhysRev.119.1743)

<span id="page-5-8"></span><sup>[13]</sup> G. Szekeres, Publ. Math. Debrecen 7, 285 (1960).

<span id="page-5-9"></span><sup>[14]</sup> R. P. Kerr and A. Schild, [Proc. Symp. Appl. Math](https://doi.org/10.1007/s10714-009-0857-z) 17, [199 \(1965\).](https://doi.org/10.1007/s10714-009-0857-z)

<span id="page-5-10"></span><sup>[15]</sup> J. Ovalle, Phys. Rev. D95[, 104019 \(2017\),](https://doi.org/10.1103/PhysRevD.95.104019) [arXiv:1704.05899 \[gr-qc\].](http://arxiv.org/abs/1704.05899)

<span id="page-5-11"></span><sup>[16]</sup> J. Ovalle, Phys. Lett. B788[, 213 \(2019\),](https://doi.org/10.1016/j.physletb.2018.11.029) [arXiv:1812.03000 \[gr-qc\].](http://arxiv.org/abs/1812.03000)

<span id="page-5-12"></span><sup>[17]</sup> E. Poisson and W. Israel, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.63.1663) 63, 1663 [\(1989\).](https://doi.org/10.1103/PhysRevLett.63.1663)

- <span id="page-6-0"></span>[18] E. Poisson and W. Israel, Phys. Rev. D 41[, 1796 \(1990\).](https://doi.org/10.1103/PhysRevD.41.1796)
- <span id="page-6-1"></span>[19] A. Ori, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.67.789) 67, 789 (1991).
- [20] R. Carballo-Rubio, F. Di Filippo, S. Liberati, C. Pacilio, and M. Visser, JHEP 07[, 023 \(2018\),](https://doi.org/10.1007/JHEP07(2018)023) [arXiv:1805.02675](http://arxiv.org/abs/1805.02675) [\[gr-qc\].](http://arxiv.org/abs/1805.02675)
- [21] A. Bonanno, A.-P. Khosravi, and F. Saueressig, [Phys.](https://doi.org/10.1103/PhysRevD.103.124027) Rev. D 103[, 124027 \(2021\),](https://doi.org/10.1103/PhysRevD.103.124027) [arXiv:2010.04226 \[gr-qc\].](http://arxiv.org/abs/2010.04226)
- [22] R. Carballo-Rubio, F. Di Filippo, S. Liberati, C. Pacilio, and M. Visser, JHEP 05[, 132 \(2021\),](https://doi.org/10.1007/JHEP05(2021)132) [arXiv:2101.05006](http://arxiv.org/abs/2101.05006) [\[gr-qc\].](http://arxiv.org/abs/2101.05006)
- [23] R. Carballo-Rubio, F. Di Filippo, S. Liberati, C. Pacilio, and M. Visser, JHEP 09[, 118 \(2022\),](https://doi.org/10.1007/JHEP09(2022)118) [arXiv:2205.13556](http://arxiv.org/abs/2205.13556) [\[gr-qc\].](http://arxiv.org/abs/2205.13556)
- [24] E. Franzin, S. Liberati, J. Mazza, and V. Vellucci, [Phys.](https://doi.org/ 10.1103/PhysRevD.106.104060) Rev. D 106[, 104060 \(2022\),](https://doi.org/ 10.1103/PhysRevD.106.104060) [arXiv:2207.08864 \[gr-qc\].](http://arxiv.org/abs/2207.08864)

- [25] R. Casadio, A. Giusti, and J. Ovalle, [Phys. Rev. D](https://doi.org/10.1103/PhysRevD.105.124026) 105, [124026 \(2022\),](https://doi.org/10.1103/PhysRevD.105.124026) [arXiv:2203.03252 \[gr-qc\].](http://arxiv.org/abs/2203.03252)
- <span id="page-6-2"></span>[26] A. Bonanno, A.-P. Khosravi, and F. Saueressig, [Phys.](https://doi.org/10.1103/PhysRevD.107.024005) Rev. D 107[, 024005 \(2023\),](https://doi.org/10.1103/PhysRevD.107.024005) [arXiv:2209.10612 \[gr-qc\].](http://arxiv.org/abs/2209.10612)
- <span id="page-6-3"></span>[27] R. Doran, F. S. N. Lobo, and P. Crawford, [Found. Phys.](https://doi.org/10.1007/s10701-007-9197-6) 38[, 160 \(2008\),](https://doi.org/10.1007/s10701-007-9197-6) [arXiv:gr-qc/0609042.](http://arxiv.org/abs/gr-qc/0609042)
- <span id="page-6-4"></span>[28] R. Kantowski and R. K. Sachs, [J. Math. Phys.](https://doi.org/10.1063/1.1704952) 7, 443 [\(1966\).](https://doi.org/10.1063/1.1704952)
- <span id="page-6-5"></span>[29] R. W. Brehme, [Am. J. Phys.](https://doi.org/10.1119/1.10829) 45, 423 (1977).
- <span id="page-6-6"></span>[30] E. Ayon-Beato and A. Garcia, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.80.5056) 80, 5056 [\(1998\),](https://doi.org/10.1103/PhysRevLett.80.5056) [arXiv:gr-qc/9911046.](http://arxiv.org/abs/gr-qc/9911046)