# <span id="page-0-4"></span>Generalization of Regular Black Holes in General Relativity to f(R) Gravity

Manuel E. Rodrigues<sup>(a,b)</sup>,\* Júlio C. Fabris<sup>(e,f)</sup>,† Ednaldo L. B. Junior<sup>(b,c)</sup>,‡ and Glauber T. Marques<sup>(d)§</sup>

(a) Faculdade de Ciências Exatas e Tecnologia, Universidade Federal do Pará
Campus Universitário de Abaetetuba, CEP 68440-000, Abaetetuba, Pará, Brazil

(b) Faculdade de Física, PPGF, Universidade Federal do Pará, 66075-110, Belém, Pará, Brazil

(c) Faculdade de Engenharia da Computação, Universidade Federal do Pará,
Campus Universitário de Tucuruí, CEP: 68464-000, Tucuruí, Pará, Brazil

(d) Universidade Federal Rural da Amazônia ICIBE - LASIC

Av. Presidente Tancredo Neves 2501 CEP 66077-901 - Belém/PA, Brazil

(e) Universidade Federal do Espírito Santo, CEP 29075-910, Vitória, ES, Brazil and

(f) National Research Nuclear University MEPhI, Kashirskoe sh. 31, Moscow 115409, Russia

In this paper, we determine regular black hole solutions using a very general f(R) theory, coupled to a non-linear electromagnetic field given by a Lagrangian  $\mathcal{L}_{NED}$ . The functions f(R) and  $\mathcal{L}_{NED}$  are left in principle unspecified. Instead, the model is constructed through a choice of the mass function M(r) presented in the metric coefficients. Solutions which have a regular behaviour of the geometric invariants are found. These solutions have two horizons, the event horizon and the Cauchy horizon. All energy conditions are satisfied in the whole space-time, except the strong energy condition (SEC) which is violated near the Cauchy horizon.

PACS numbers: 04.50.Kd

#### I. INTRODUCTION

The present stage of accelerate expansion of the universe seems to be well established from the analysis of observational data. Besides the supernova Ia data [1], the data from the observation of the anisotropy of the cosmic microwave background radiation (CMB) [2], the baryonic acoustic oscillations (BAO) [3], large scale structures [4], weak lensing [5], the differential age of old galaxies (H(z0) [6], give strong evidences for the present accelerated expansion phase. Since gravity is attractive, the cosmic accelerate expansion requires some new form of exotic matter that leads to violation of the Strong Energy Condition (SEC) [7, 8], as far as the General Relativity (GR) theory is considered. This exotic component is dubbed dark energy.

The most popular, and most simple, candidate for dark energy is the cosmological constant. Interpreted as a manifestation of the quantum vacuum energy, the cosmological constant faces however a huge discrepancy between the observed value and the predicted one. The exact value of this discrepancy depends on many details, but in general it mounts to many dozen orders of magnitude [9].

The incertitude about the dynamical origin of the observed accelerated expansion led to many speculations about possible extensions of the General Relativity (GR) theory in such way that the accelerated expansion could be obtained without the introduction of dark energy. In this sense, one of these possible extensions is to generalise the Einstein-Hilbert action including non-linear geometric terms. One of this proposal is the f(R) theories [10, 11], where the non-linear terms are combinations of the Ricci scalar R. Such theories may give very good results at cosmological scales but must be complemented with a screening mechanism in order not to spoil the achievements of the GR theory at scales of the solar system [12]. There are a long list of other possible, and generally more complex, modifications of the GR theory [13–19]

Another problem concerning the applications of the GR theory to concrete problems is the presence of singularities, as that predicted in the primordial universe and in the end of the life of some massive stars. The presence of such singularities seems to point to the limit of application of the GR theory, requiring perhaps to consider quantum effects in the strong gravitational regime. Some other possibility to cure this singularity problem, yet in the context of a classical theory, is to consider as source of the gravitational equations matter fields that may lead to violation of at least some of the energy conditions. Examples are given by non-linear gauge fields, like the electromagnetic field.

<span id="page-0-0"></span> $<sup>{\</sup>rm *Electronic~address:~esialg@gmail.com}$ 

<span id="page-0-1"></span><sup>&</sup>lt;sup>†</sup>Electronic address: fabris@pq.cnpq.br

<span id="page-0-2"></span><sup>&</sup>lt;sup>‡</sup>Electronic address: ednaldobarrosjr@gmail.com

<span id="page-0-3"></span><sup>§</sup>Electronic address: gtadaiesky@hotmail.com

Non linear electromagnetism [23] has been conceived originally to cure singularity problems in the Maxwell theory. In gravity theories, the electromagnetic field appears as one of the sources of of the structure of the space-time. In such a context, some success to avoid singularities has been obtained in implementing such extension of the classical Maxwell field [24–28].

In the Ref. [20] both proposals of extension of the usual gravitational and gauge field theories were considered. In that paper, the emphasis was in the study of black hole configurations. A very general form of the this theory mixing the f(R) theory and the non-linear electromagnetic Lagrangian  $\mathcal{L}_{NED}$  has been considered. A static, spherically symmetric space-time has been used. Particular, solutions with horizon (thus, candidates to represent a black hole) were found, but without the singularity existing in the usual black hole solutions of the GR theory. This singularity-free black hole solutions imply the violation of the SEC only in certain regions of the space-time. However, the other energy conditions are generally satisfied. We remember that the energy conditions are directly connected with the existence of singularities in GR theory [7, 8].

In the present paper, we revisit the problem treated in the Ref. [20], and we show that new non-singular solutions are possible. This new solutions emerge from a specific, but very appealing, choice of the mass function M(r), which will be properly defined later. The mass function we will use was constructed in Ref. [21], with GR theory coupled to non-linear electromagnetic field, in other to satisfy some requirements, like to avoid violation of the Weak Energy Condition (WEC) and to have the Reissner-Nordström asymptotic limit: the mass function M(r) given in Ref. [21] is the most general functional form satisfying the WEC in GR. As it was found for other mass functions in Ref. [20], the employment of the mass function of Ref. [21] in our general context implies that the violation of SEC occurs only in a limited region of the space-time, the other energy conditions being satisfied in the entire space-time.

This paper is organised as follows. In the next section, the equations of motion are written down. In section III, we determine the new non-singular solutions and analyse the fate of the energy conditions for these solutions. The final conclusions are presented in section IV. In the appendix, it is shown explicitly that the solutions found here are asymptotically regular.

## II. THE EQUATIONS OF MOTION IN f(R) GRAVITY

The f(R) gravity is defined by the action,

<span id="page-1-0"></span>
$$S_{f(R)} = \int d^4x \sqrt{-g} \left[ f(R) + 2\kappa^2 \mathcal{L}_m \right] , \qquad (1)$$

where g stands for the determinant of the metric  $g_{\mu\nu}$ , f(R) is a given function of the Ricci scalar R,  $\mathcal{L}_m$  represents the Lagrangian density of the matter and other fields, and  $\kappa^2 = 8\pi G/c^4$ , with G and c being the Newton's gravitational constant and the speed of light, respectively.

There are two main approaches for this theory, the first one supposing the the dynamical fields are the metric and the matter field, known as metric formalism, and the second one, called Palatini formalism, for which the dynamical fields are the metric, the matter field, but with the Levi-Civita connection independent of the metric. In what follows we will use the first approach.

Applying the variational principle in terms of the metric to the action (1), we find the following field equations:

<span id="page-1-1"></span>
$$f_R R^{\mu}_{\ \nu} - \frac{1}{2} \delta^{\mu}_{\nu} f + \left( \delta^{\mu}_{\nu} \Box - g^{\mu\beta} \nabla_{\beta} \nabla_{\nu} \right) f_R = \kappa^2 \Theta^{\mu}_{\ \nu} , \qquad (2)$$

where  $f_R \equiv df(R)/dR$ ,  $R^{\mu}_{\nu}$  is the Ricci tensor,  $\nabla_{\nu}$  stands for the covariant derivative,  $\Box \equiv g^{\alpha\beta}\nabla_{\alpha}\nabla_{\beta}$  is the d'Alembertian, and  $\Theta_{\mu\nu}$  is the matter energy-momentum tensor.

In the present work, we will analyse the coupling of the f(R) gravity with a Non-linear electrodynamic theory (NED), given by,  $\mathcal{L}_m \equiv \mathcal{L}_{NED}(F)$ , where  $F = (1/4)F^{\mu\nu}F_{\mu\nu}$ , and with  $F_{\mu\nu}$  being the Maxwell tensor, and  $\mathcal{L}_{NED}(F)$  is an arbitrary function of F. A similar structure was exploited in Ref. [20]. We will first review the methodology employed in that reference, which will be applied in the present paper in order to find new regular black hole solutions. Considering the NED coupling, the energy-momentum tensor for matter in (2) is given by,

<span id="page-1-2"></span>
$$\Theta^{\mu}_{\ \nu} = \delta^{\mu}_{\nu} \mathcal{L}_{NED} - \frac{\partial \mathcal{L}_{NED}(F)}{\partial F} F^{\mu\alpha} F_{\nu\alpha} \ . \tag{3}$$

In the particular case of the Maxwell Lagrangian  $\mathcal{L}_{NED} \equiv F$ , the energy-momentum tensor of the linear Maxwell electrodynamics is reobtained.

Defining the Maxwell tensor in terms of the four-potential  $F_{\mu\nu} = \partial_{\mu}A_{\nu} - \partial_{\nu}A_{\mu}$ , the variation of the functional (1) with respect to the potential can be performed, leading to the generalised Maxwell equation,

<span id="page-2-0"></span>
$$\nabla_{\mu} \left[ F^{\mu\nu} \mathcal{L}_F \right] \equiv \partial_{\mu} \left[ \sqrt{-g} F^{\mu\nu} \mathcal{L}_F \right] = 0 , \qquad (4)$$

where  $\mathcal{L}_F = \partial \mathcal{L}_{NED} / \partial F$ .

We then consider a spherically symmetric and static space-time, whose element line, in Schwarzschild coordinates, reads

<span id="page-2-1"></span>
$$ds^{2} = e^{a(r)}dt^{2} - e^{b(r)}dr^{2} - r^{2}\left[d\theta^{2} + \sin^{2}\theta d\phi^{2}\right], \qquad (5)$$

where a(r) and b(r) are arbitrary functions of the radial coordinate r. We will consider the particular case where there is only electric field, the components connected with the magnetic field of the Maxwell tensor  $F_{\mu\nu}$  being zero. Imposing spherical symmetry, through the Killing vectors and the equation  $\mathcal{L}_{\zeta^{\mu}}F^{\alpha\beta}(t,r,\theta,\phi)\equiv 0$ , we can show that only non-null component of the Maxwell tensor is  $F^{10}(r)$  [29]. The generalised Maxwell equation (4) for  $\nu=0$  is

<span id="page-2-2"></span>
$$F^{10}(r) = \frac{q}{r^2} e^{-[a(r)+b(r)]/2} \mathcal{L}_F^{-1}(r) , \qquad (6)$$

where  $q \in \Re$  is an integration constant representing the electric charge of the source.

The equations of motion for the f(R) Gravity coupled to a NED are then found by using the line element (5), the energy-momentum (3), with the only non-null component given by (6), and the field equations (2):

<span id="page-2-3"></span>
$$\frac{e^{-b}}{4r} \left\{ 4r \frac{d^2 f_R}{dr^2} + 2\left[4 - rb'\right] \frac{df_R}{dr} + \left[ra'b' - 2ra'' - r(a')^2 - 4a'\right] f_R + 2re^b f \right\} = -\kappa^2 \left[ \mathcal{L}_{NED} + \frac{q^2}{r^4} \mathcal{L}_F^{-1} \right], \quad (7)$$

$$\frac{e^{-b}}{4r} \left\{ 2 \left[ 4 + ra' \right] \frac{df_R}{dr} + \left[ (4 + ra')b' - 2ra'' - r(a')^2 \right] f_R + 2re^b f \right\} = -\kappa^2 \left[ \mathcal{L}_{NED} + \frac{q^2}{r^4} \mathcal{L}_F^{-1} \right], \tag{8}$$

$$\frac{e^{-b}}{2r^2} \left\{ 2r^2 \frac{d^2 f_R}{dr^2} + \left[ r^2 (a' - b') + 2r \right] \frac{df_R}{dr} + \left[ r(b' - a') + 2(e^b - 1) \right] f_R + r^2 e^b f \right\} = -\kappa^2 \mathcal{L}_{NED}, \tag{9}$$

where the prime (') stands for the total derivative with respect to the radial coordinate r.

In the next section, we will use an algebraic methodology to solve these equations and to obtain new regular solutions.

# III. NEW GENERALIZATIONS FOR REGULAR BLACK HOLES ON GENERAL RELATIVITY TO f(R) GRAVITY

Fixed the spherical coordinates, it is possible to impose the quasi-global condition by choosing a radial coordinate:

<span id="page-2-5"></span>
$$b(r) = -a(r) . (10)$$

This is an additional requirement to the metric functions since the coordinate system has already been fixed. However, the fact that the functions f(R) and  $\mathcal{L}_{NED}$  are, for the moment, arbitrary assures the possibility to impose such new condition, as it will be verified later.

Imposing the quasi-global coordinate condition, and combining equations (8) and (7), we obtain,

$$e^{-b}\frac{d^2f_R}{dr^2} = 0. (11)$$

Integrating this expression, it results,

<span id="page-2-4"></span>
$$f_R(r) = c_1 r + c_0 (12)$$

where it appears the integration constants  $c_0, c_1 \in \Re$ . Here, we must make the following observations. First, for the particular case  $c_1 \equiv 0, c_0 = 1$ , GR is recovered, since the integration of (12) with respect to R leads to f(R) = R. Second, if the line element (5) is considered, the Ricci scalar becomes,

<span id="page-2-6"></span>
$$R = e^{-b} \left[ a'' + (a' - b') \left( \frac{a'}{2} + \frac{2}{r} \right) + \frac{2}{r^2} \right] - \frac{2}{r^2}$$
$$= e^a \left[ a'' + 2a' \left( \frac{a'}{2} + \frac{2}{r} \right) + \frac{2}{r^2} \right] - \frac{2}{r^2} . \tag{13}$$

The regularity of the solution (12) at the spatial infinity is discussed in the appendix.

In order to have a better description of the new regular black hole solutions, it is useful to define,

<span id="page-3-0"></span>
$$e^{a(r)} = 1 - \frac{2M(r)}{r} \,, (14)$$

where M(r) is the mass function, which for the regular solutions satisfies the condition  $\lim_{r\to 0} [M(r)/r] \equiv 0$ . The mass function M(r) must coincide with the ADM mass m in the spatial infinity limit, where the radial coordinate r goes to infinity.

Inserting (14) and (10) in (13), the curvature scalar can be rewritten as,

<span id="page-3-1"></span>
$$R(r) = -\frac{2}{r^2} [rM''(r) + 2M'(r)], \qquad (15)$$

which, for a given M(r) model, may allow to invert equation (15), to obtain r(R). After integration of (12) it leads to,

<span id="page-3-6"></span>
$$f(R) = c_0 R + c_1 \int r(R) dR . \tag{16}$$

It is also possible to obtain f(R) from the expression  $f_R = (df/dr)(dR/dr)^{-1}$ . After integration and using (15) we obtain,

<span id="page-3-2"></span>
$$f(r) = \int f_R(r) \frac{dR(r)}{dr} dr . ag{17}$$

Now, we use the methodology presented in [20] to solve the equations of motion. Taking the relations (10), (14), (12) and (17), we can solve the equations (7)-(9) to obtain  $\mathcal{L}_{NED}$  and  $\mathcal{L}_F$  as,

<span id="page-3-3"></span>
$$\mathcal{L}_{NED} = -\frac{1}{2\kappa^2 r^2} \left[ r^2 f(r) + 4c_0 M'(r) + 2c_1 r \right] , \qquad (18)$$

$$\mathcal{L}_F = -\kappa^2 \frac{q^2}{r^2} \left[ (c_1 r + c_0) r M''(r) - (2c_0 + c_1 r) M'(r) - 3c_1 M(r) + c_1 r \right]^{-1}. \tag{19}$$

The solution above satisfies the equations of motion. However, its consistency can be verified through the Lagrangian density  $\mathcal{L}_{NED}$  and its derivative with respect to F,  $\mathcal{L}_{F}$ . By definition, we have

<span id="page-3-5"></span>
$$\mathcal{L}_F = \frac{\partial \mathcal{L}_{NED}}{\partial F} = \frac{\partial \mathcal{L}_{NED}}{\partial r} \frac{\partial r}{\partial F} = \frac{\partial \mathcal{L}_{NED}}{\partial r} \left(\frac{\partial F}{\partial r}\right)^{-1}.$$
 (20)

To perform such verification we must remember that  $F = (1/4)F^{\mu\nu}F_{\mu\nu} = -(1/2)e^{a+b}[F^{10}(r)]^2$ , and that the only non-null component of the Maxwell's tensor, for this symmetry, is obtained from equations (10), (14) and (19), which considering (6), leads to

<span id="page-3-4"></span>
$$F^{10}(r) = \frac{1}{a\kappa^2} \left\{ 3c_1 M(r) + (2c_0 + c_1 r)M'(r) - r[c_1 + (c_0 + c_1 r)M''(r)] \right\}. \tag{21}$$

Now, using equations (10), (12), (14), (15), (17)-(19) and (21), it is possible to verify that the constraint (20) is satisfied. Hence, the solution is consistent.

In order to perform an analysis of the physical properties of this class of solution, we must take into account the energy condition relations for the f(R) theory. Following the results of Refs. [30, 31], equation (2) is rewritten as,

$$R_{\mu\nu} - \frac{1}{2}g_{\mu\nu}R = f_R^{-1} \left[ \kappa^2 \Theta_{\mu\nu} + \frac{1}{2}g_{\mu\nu} \left( f - Rf_R \right) - \left( g_{\mu\nu} \Box - \nabla_{\mu} \nabla_{\nu} \right) f_R \right] = \kappa^2 \mathcal{T}_{\mu\nu}^{(eff)} , \qquad (22)$$

where  $\mathcal{T}_{\mu\nu}^{(eff)}$  is the effect if energy-momentum tensor, and the perfect fluid content is identified by the relations  $\mathcal{T}_0^{0(eff)} = \rho^{(eff)}$ ,  $\mathcal{T}_1^{1(eff)} = -p_r^{(eff)}$ ,  $\mathcal{T}_2^{2(eff)} = \mathcal{T}_3^{3(eff)} = -p_t^{(eff)}$ , where  $\rho^{(eff)}$ ,  $p_r^{(eff)}$  e  $p_t^{(eff)}$  are the energy density, radial and tangential pressures, respectively. The explicit expressions for the energy-momentum tensor can be found in Ref.[20]. With these expressions, the energy conditions for the f(R) theory can be written as,

$$NEC_{1,2}(r) = \rho^{(eff)} + p_{r,t}^{(eff)} \ge 0$$
, (23)

$$SEC(r) = \rho_{(eff)} + p_r^{(eff)} + 2p_t^{(eff)} \ge 0,$$
 (24)

$$WEC_{1,2}(r) = \rho^{(eff)} + p_{r,t}^{(eff)} \ge 0, \qquad (25)$$

$$DEC_1(r) = \rho^{(eff)} \ge 0, \tag{26}$$

$$DEC_{2,3}(r) = \rho^{(eff)} - p_{r,t}^{(eff)} \ge 0 , \qquad (27)$$

where, in view of the identity  $WEC_3(r) \equiv DEC_1(r)$ , one of the conditions was not written.

In the next sub-section, we will use a specific model for the general mass function M(r), coming from GR, in order to obtain a generalisation of this class of solutions.

### A. New regular black hole solutions

As it has been shown in reference [20], it is not any model for the mass function M(r) that leads to a generalisation of a solution of GR to the f(R) gravity theory, with a function f(R) containing non-linear terms. Here, we will use a model obtained by integration of the general mass function satisfying the WEC given by [21], which reads,

<span id="page-4-2"></span>
$$M(r) = \frac{6^3 m^4 r^3}{q^6} \frac{\Gamma^3(4/a_1)\Gamma(b_1/a_1)}{\Gamma^3(a_1^{-1})\Gamma[(b_1 - 3)/a_1]} {}_{2}F_{1} \left[ \frac{3}{a_1}; \frac{b_1}{a_1}; \frac{a_1 + 3}{a_1}; -\left( \frac{6\Gamma(4/a_1)}{\Gamma(a_1^{-1})\Gamma[(a_1 + 3)/a_1]} \frac{m}{q^2} r \right)^{a_1} \right], \tag{28}$$

where  ${}_{2}F_{1}[k_{1};k_{2};k_{3};z]$  is the Gauss hypergeometric function.

This model is, in general, very complicated. It is possible to express the solutions in terms of integrals, which can be or not analytical. It is more instructive to work with some particular cases. Let us first take the case where  $a_1 = 2$  and  $b_1 = 4$ , for which the metric functions (10) and (14) are given by,

<span id="page-4-3"></span>
$$e^{a} = e^{-b} = 1 + \frac{32m^{2}q^{2}}{\pi^{2}q^{4} + 64m^{2}r^{2}} - \frac{4m}{\pi r} \arctan\left[\frac{8mr}{\pi q^{2}}\right].$$
 (29)

This solution represents a charged, regular black hole, asymptotically flat, with two horizons:  $r_H$  (an event horizon) and  $r_-$  (inner or Cauchy horizon). It is possible to verify that this solution is regular in all space-time by inspecting the Ricci and Kretschmann scalar, which read,

<span id="page-4-0"></span>
$$R = -\frac{16384m^4\pi^2q^6}{(\pi^2q^4 + 64m^2r^2)^3} \,, (30)$$

$$\mathcal{K} = R^{\alpha\beta\mu\nu}R_{\alpha\beta\mu\nu} = \frac{64m^2}{r^6} \left\{ \frac{64m^2q^4r^2}{(\pi^2q^4 + 64m^2r^2)^6} (3\pi^4q^8 + 256\pi^2m^2q^4r^2 + 20480m^4r^4)(\pi^4q^8 + 256\pi^2m^2q^4r^2 + 28672m^4r^4) \right\}$$

$$+\frac{1}{\pi^2}\arctan\left(\frac{8mr}{\pi q^2}\right)\left[3\arctan\left(\frac{8mr}{\pi q^2}\right) - \frac{16m\pi q^2r}{(\pi^2 q^4 + 64m^2r^2)^3}(3\pi^4 q^8 + 512m^2\pi^2 q^4r^2 + 36864m^4r^4)\right]\right\}. \tag{31}$$

These scalars are finite in all space-time. The limits in the origin of the radial coordinate and in the spatial infinity are given by  $\lim_{r\to 0} \{R, \mathcal{K}\} = \{-(16384m^4)/(\pi^4q^6), (134217728m^8)/(3\pi^8q^{12})\}$  and  $\lim_{r\to \infty} \{R, \mathcal{K}\} = \{0, 0\}$ .

The expression (30) implies,

<span id="page-4-1"></span>
$$r(R) = \frac{q}{8m} \sqrt{-\pi^2 q^2 + \frac{16(2\pi m^2)^{2/3}}{(-R)^{1/3}}} \ . \tag{32}$$

From (30) it can be verified that  $R \leq 0$ , what must be taken into account in order to define correctly (32) in the usual limit  $0 \leq r \leq +\infty$ .

Now, the function f(R) can be obtained inserting (32) in (16), leading to,

$$f(R) = c_0 R + \frac{c_1}{8mq^3 \pi^{8/3}} \sqrt{-\pi^2 q^2 + \frac{16(2\pi m^2)^{2/3}}{(-R)^{1/3}}} \left[ 192(2m^8)^{1/3} (-R)^{1/3} + 4(4\pi^4 m^4)^{1/3} (-R)^{2/3} - \pi^{8/3} q^4 (-R) \right] + \frac{768c_1 m^3}{\pi^3 q^4} \arctan^{-1} \left\{ \pi q \left[ -\pi^2 q^2 + \frac{16(2\pi m^2)^{2/3}}{(-R)^{1/3}} \right]^{-1/2} \right\}$$
(33)

We can now see clearly that the last two terms that multiply the constant  $c_1$  generalize the GR solution to the f(R) gravity, including non-linear terms in the Ricci scalar R. In the particular case where  $c_1 = 0$ , GR is recovered.

It is not possible to obtain analytically a functional relation between the scalar F and the Lagrangian density  $\mathcal{L}_{NED}$ . Hence, using (21), with (28), we obtain

$$F^{10}(r) = \frac{1}{\pi q \kappa^2 (\pi^2 q^4 + 64 m^2 r^2)^3} \left\{ -\pi r \left[ -524288 c_0 m^6 q^2 r^3 + c_1 \left( \pi^6 q^{12} + 4096 m^4 \pi^2 q^4 r^2 (2q^2 + 3r^2) + 65536 m^6 r^4 \times (2q^2 + 3r^2) \right] \right\} \right\} = \frac{1}{\pi q \kappa^2 (\pi^2 q^4 + 64 m^2 r^2)^3} \left\{ -\pi r \left[ -524288 c_0 m^6 q^2 r^3 + c_1 \left( \pi^6 q^{12} + 4096 m^4 \pi^2 q^4 r^2 (2q^2 + 3r^2) + 65536 m^6 r^4 \times (2q^2 + 3r^2) \right] \right\} \right\} = \frac{1}{\pi q \kappa^2 (\pi^2 q^4 + 64 m^2 r^2)^3} \left\{ -\pi r \left[ -524288 c_0 m^6 q^2 r^3 + c_1 \left( \pi^6 q^{12} + 4096 m^4 \pi^2 q^4 r^2 (2q^2 + 3r^2) + 65536 m^6 r^4 \times (2q^2 + 3r^2) + 65536 m^6 r^4 \right) \right\} \right\}$$

$$\times (-3q^2 + 4r^2) + 48m^2\pi^4q^8(q^2 + 4r^2)\Big] + 6c_1m(\pi^2q^4 + 64m^2r^2)^3 \arctan\left(\frac{8mr}{\pi q^2}\right)$$
(34)

Now,  $\mathcal{L}_{NED}$  can be obtained through (18):

$$\mathcal{L}_{NED}(r) = -\frac{1}{\kappa^2} \left\{ \frac{c_1}{r} - \frac{8192m^4\pi^2q^6}{(\pi^2q^4 + 64m^2r^2)^3} (c_0 + c_1r) + \frac{2048m^4q^2}{(\pi^2q^4 + 64m^2r^2)^2} (2c_0 + c_1r) + \frac{3072c_1m^4r}{\pi^2q^2(\pi^2q^4 + 64m^2r^2)} + \frac{384c_1m^3}{\pi^3q^4} \arctan\left(\frac{8mr}{\pi q^2}\right) \right\}$$
(35)

It is possible to represent parametrically a graphic  $\mathcal{L}_{NED}(F) \times F$ , where  $F = (1/4)F^{\mu\nu}F_{\mu\nu}$ . This behaviour is displayed in figure 1.

![](_page_5_Figure_4.jpeg)

<span id="page-5-0"></span>Figure 1: Parametric representation  $\{\mathcal{L}_{NED}, F\}$  of the solution (29), with  $q = 10, m = 80, c_0 = 1, c_1 = 2, \kappa^2 = 8\pi$ .

The energy conditions can now be verified. Taking explicitly the effective density and pressure [20] for our particular case (29), we find the following expressions for the energy conditions:

<span id="page-5-1"></span>
$$NEC_1(r) = WEC_1(r) = 0, NEC_2(r) = WEC_2(r) = \frac{524288m^6q^2r^2}{\kappa^2(\pi^2q^4 + 64m^2r^2)^3},$$
(36)

$$DEC_1(r) = \frac{1}{2}DEC_2(r) = \frac{4096m^4q^2}{\kappa^2(\pi^2q^4 + 64m^2r^2)^2}, DEC_3(r) = \frac{8192m^4\pi^2q^6}{\kappa^2(\pi^2q^4 + 64m^2r^2)^3}$$
(37)

$$SEC(r) = \frac{8192m^4q^2[(8mr)^2 - \pi^2q^4]}{\kappa^2(\pi^2q^4 + 64m^2r^2)^3}$$
(38)

The energy conditions NEC, WEC and DEC are satisfied in all space-time. However, the SEC energy condition (38), is violated for  $r < [\pi q^2/(8m)]$  which, for the values m = 8q, q = 10, represents a region very near the Cauchy horizon  $(\pi q^2/(8m) = 0.490874, r_{Cauchy} = 0.0419174, r_H = 159.373)$ .

Let us show a second analytical example for the general mass (28). For the values  $a_1 = 3$  and  $b_1 = 4$ , using the same procedure as before, the following functions characterise the solutions:

<span id="page-5-2"></span>
$$e^{a(r)} = e^{-b(r)} = 1 - \frac{2m}{r} \left[ 1 - \frac{q^2}{(q^6 + 8m^3r^3)^{1/3}} \right], R(r) = -\frac{64m^4q^8}{(q^6 + 8m^3r^3)^{7/3}}$$
(39)

$$F^{10}(r) = \frac{256c_0m^7q^2r^5}{\kappa^2q(q^6 + 8m^3r^3)^{7/3}} + \frac{c_1}{\kappa^2q} \left[ 3m - r + \frac{256m^7q^2r^6}{(q^6 + 8m^3r^3)^{7/3}} - \frac{8m^4q^2r^3}{(q^6 + 8m^3r^3)^{4/3}} - \frac{3mq^2}{(q^6 + 8m^3r^3)^{1/3}} \right]$$
(40)

$$\mathcal{K} = \frac{16m^2}{r^6(q^6 + 8m^3r^3)^{14/3}} \Big[ 3q^{28} + 112m^3q^{22}r^3 + 1856m^6q^{16}r^6 + 14336m^9q^{10}r^9 + 57344m^{12}q^4r^{12} - (q^6 + 8m^3r^3)^{1/3} \times 10^{12} + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10^{12}r^2 + 10$$

$$\times \left(6q^{26} + 208m^3q^{20}r^3 + 2944m^6q^{14}r^6 + 19456m^9q^8r^9 + 49152m^{12}q^2r^{12}\right) + (q^6 + 8m^3r^3)^{2/3}\Big(3q^{24} + 96m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19456m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 19466m^3q^{18}r^3 + 1$$

$$+1152m^{6}q^{12}r^{6} + 6144m^{9}q^{6}r^{9} + 12288m^{12}r^{12}$$

$$f(R) = c_0 R + \frac{c_1}{2mq^{12}(mq^2)^{16/3}} (-R)^{16/21} \left[4 \times 2^{4/7} (mq^2)^{12/7} - q^6 (-R)^{3/7}\right]^{4/3} \left[3 \times 2^{4/7} (mq^2)^{12/7} (-R)^{4/7} - q^6 R\right].$$
(42)

In the spatial infinity, we have  $\lim_{r\to+\infty} \{e^{a(r)}, e^{b(r)}\} = \{1,1\}$  and  $\lim_{r\to+\infty} \{R(r), \mathcal{K}\} = \{0,0\}$ , showing the regularity in the asymptotical region. When the radial coordinate goes to zero it is necessary to perform an expansion

around r = 0 to analyse the behaviour of the solution in this limit. Taking  $e^{a(r)}$  and R(r), (39), K inserting in(41), we find the following expansions around r = 0:

$$e^{a(r)} \sim 1 - \frac{16m^4}{3q^6}r^2 + O(r^3), R(r) \sim -\frac{64m^4}{q^6} + O(r^3), \mathcal{K} \sim \frac{2048m^8}{3q^{12}} + O(r^3)$$
 (43)

When r goes to zero, we have  $\lim_{r\to 0} \{e^{a(r)}, e^{b(r)}\} = \{1,1\}$  e  $\lim_{r\to 0} \{R(r), \mathcal{K}\} = \{-64m^4/q^6, 2048m^8/q^{12}\}$ , showing the regularity in the origin of the radial coordinate. Hence, we have shown that the solution (39) corresponds to a regular black hole in all space-time. This black hole has spherical symmetry, and it is charged and asymptotically flat.

Let us verify now the energy conditions for this case. They read,

<span id="page-6-0"></span>
$$NEC_1(r) = WEC_1(r) = 0, NEC_2(r) = WEC_2(r) = \frac{256m^7q^2r^3}{\kappa^2(q^6 + 8m^3r^3)^{7/3}},$$
(44)

$$DEC_1(r) = \frac{1}{2}DEC_2(r) = \frac{16m^4q^2}{\kappa^2(q^6 + 8m^3r^3)^{4/3}}, DEC_3(r) = \frac{32m^4q^8}{\kappa^2(q^6 + 8m^3r^3)^{7/3}}$$
(45)

$$SEC(r) = \frac{32m^4q^2(8m^3r^3 - q^6)}{\kappa^2(q^6 + 8m^3r^3)^{7/3}}$$
(46)

The conditions NEC, WEC and DEC are satisfied in all space-time. However, the SEC condition, given by (46), is violated for  $r < q^2/(2m)$ . For the values m = 8q, q = 10, this violation occurs in region very near the Cauchy horizon  $(q^2/(2m) = 0.625, r_{Cauchy} = 0.0676869, r_H = 159.373)$ .

To complete our analysis, we display in figure 2 the graphics for the density, the radial and tangential effective pressures for the solutions (29) and (39). We show also the graphics for the relative fractions of these quantities,  $\omega_r = p_r^{(eff)}/\rho^{(eff)}, \omega_t = p_t^{(eff)}/\rho^{(eff)}, \omega_{eff} = (p_r^{(eff)} + 2p_r^{(eff)})/\rho^{(eff)}$  and  $p_r^{(eff)}/p_t^{(eff)}$ . It can be seen from figure

![](_page_6_Figure_10.jpeg)

<span id="page-6-1"></span>Figure 2: Parametric representation of the density and effective pressures of the solution (29) (left up panel) and of the solution (39) (right up panel). It is also displayed the factions  $\omega_r = p_r^{(eff)}/\rho^{(eff)}, \omega_t = p_t^{(eff)}/\rho^{(eff)}, \omega_{eff} = (p_r^{(eff)}+2p_r^{(eff)})/\rho^{(eff)}$  and  $p_r^{(eff)}/p_t^{(eff)}$ . We used  $q=10, m=80, c_0=1, c_1=2, \kappa^2=8\pi$ .

2 that the radial pressure reveals always the relation  $p_r^{(eff)} = -\rho^{(eff)}$  for both solutions. The tangential pressure has this behaviour only very near the origin of the radial co-ordinate. For both solutions, there is a small difference

between these two pressures that grows as r increases. This fact reveals the anisotropy of the effective matter content for the theory.

### IV. CONCLUSION

In this paper, we have investigated the existence of regular black hole structures for a general f(R) theory, sourced by non-linear electromagnetic terms expressed by the Lagrangian  $\mathcal{L}_{NED}$ . Our approach follows very closely that one employed in Ref. [20]: instead of choosing specific forms for the the f(R) and  $\mathcal{L}_{NED}$  functions, the approach consists in expressing the metric in terms of a mass function M(r) and to choose a mass function that satisfies some requirements. Specifically, we have used the mass function determined in Ref. [21]. Such mass function was constructed, in the context of GR theory coupled to non-linear electromagnetic field, in order to satisfy the WEC and to have an asymptotic Reissner-Nordström limit. In fact, the chosen mass function M(r) is the most general functional form satisfying the WEC in GR.

Applied to the case of a general f(R) and  $\mathcal{L}_{NED}$  functions, that mass function of Ref. [21] leads to regular black hole solutions which contain two horizons, the event horizon and the Cauchy horizon. We worked out completely two specific cases of that mass function, by choosing specific values for the free parameters in the model developed in Ref. [21]. The regular character of the solutions is attested by the regular behaviour of the geometric invariants, like the Ricci scalar and the Kretschmann scalar. Asymptotically, as expected, the metric functions reproduces the Reissner-Nordström solution of the GR theory.

The energy conditions are satisfied for the two specific cases studied here, except for the case of the Strong Energy Condition (SEC) which is violated in the vicinity of the Cauchy horizon. Of course, a violation of at least some of the energy conditions must occur if regular solution must be extracted from the original theory. In this case, the violation is quite mild since it is only the energy condition connected with the convergence of the geodesics that is violated (SEC), and even though in a quite restricted region of the whole space-time.

Evidently, there are many open issues related to the problem treated here, like the complete determination of the  $\mathcal{L}_{NED}$  function corresponding to the configurations found, and the stability problem. We postpone such new analysis to future works.

**Acknowledgement**: MER thanks UFPA, Edital 04/2014 PROPESP, and CNPq, Edital MCTI/CNPQ/Universal 14/2014, for partial financial support. JCF thanks CNPq (Brazil) and FAPES (Brazil) for financial support.

### Appendix: Asymptotic analysis of the new solutions

Let us analyse the regularity of the solutions in the limit  $r \to \infty$ . The radial coordinate is redefined as x = 1/r. Hence,  $r \to \infty$  implies  $x \to 0$ . The metric function  $e^{a(r)}$ , for the solution (29), behaves in this limit as,

$$e^{a(r)} \sim 1 - 2mx + q^2x^2 + O(x^3).$$
 (47)

From this behaviour, it is possible to verify that the metric behaves, up to second order, as in the Reissner-Nordström solution. In this limit we have,

$$f(R) \sim \frac{1}{\pi^2 q^2} \left[ 38c_1 \frac{m^3}{q^4} + O(x^5) \right].$$
 (48)

Hence, the function f(R) becomes asymptotically a constant, which depends on  $c_1$ , that can not be made zero. The Lagrangian density  $\mathcal{L}_{NED}$  becomes also a constant. We can verify this by using the expression (18) for the model (28) which becomes,

$$\mathcal{L}_{NED} \sim -\frac{192c_1 m^3}{\pi^2 q^4 \kappa^2} - \frac{c_1 x}{\kappa^2} + O(x^3). \tag{49}$$

From this expression, it is possible to certify that the Lagrangian density becomes also a constant, which is multiplied, in the action, by  $2\kappa^2$ : it is zero in this limit, what is normal for solutions asymptotically flat. Performing the same analysis for the Lagrangian density given by (19), we find

$$\mathcal{L}_F \sim -\frac{q^2 \kappa^2}{C_1} x^3 + O(x^4).$$
 (50)

The component  $F^{10}$  of the electric field (21) approximates to,

$$F^{10} \sim \frac{3m}{\kappa^2 q} c_1 - \frac{c_1}{\kappa^2 q x} + \frac{2c_0 q}{\kappa^2} x^2 + O(x^3).$$
 (51)

Remark that there is a divergence. But this divergence does not affect the physical quantities neither the equations of motion for this solution. In order to verify this, we will evaluate the electric energy density. Hence, let us turn the attention to other physical quantities like the electrical energy density (right side to Eq. (7)), which becomes,

$$\rho \sim \frac{192m^3}{\pi^2 q^2} c_1 + 2c_1 x + O(x^2). \tag{52}$$

The electrical energy density goes to a constant in the limit  $r \to +\infty$ . On the other hand, the effective electric energy density is given, in this limit, by

$$\rho_{eff} \sim \frac{q^2}{\kappa^2} x^4 + O(x^5),\tag{53}$$

which goes asymptotically to zero.

For the solution (29) the left side for first equation of motion, in the limit  $r \to +\infty$ , leads to,

$$192c_1\frac{m^3}{\pi^2q^4} + 2c_1x - 3c_1mx^2 + O(x^3). (54)$$

This result shows that the infinite quantity coming from  $f_R(r) = c_0 + c_1 r$  does not affect the equations of motion. The same happens for the second equation of motion. For the third equation of motion, we find

$$192c_1\frac{m^3}{\pi^2q^4} + c_1x + O(x^3). (55)$$

Hence, the equations of motion are regular in the limit  $r \to +\infty$ : the equations are consistent since the infinity coming from  $f_R(r) = c_0 + c_1 r$  is compensated by other terms.

Now, we perform a similar asymptotical analysis  $(r \to +\infty)$ , with x = 1/r for the second solution given by (39). In this case,

$$e^{a(r)} \sim 1 - 2mx + q^2x^2 + O(x^3),$$
 (56)

showing the asymptotically the metric coincides with the Reissner-Nordström.

The function f(R) for this solution reads,

$$f(R) \sim 24c_1 \frac{m^3}{q^4} + O(x^5).$$
 (57)

Again, the function f(R) becomes asymptotically a constant which depends on  $c_1$ , which can not be made zero. Inspecting the action, we have that  $f(R) \sim cte$  or  $f(R) \sim -2\Lambda$ . On the other hand, the component  $F^{10}$  becomes,

$$F^{10} \sim -\frac{c_1}{q\kappa^2 x} + \frac{3c_1 m}{q\kappa^2} + \frac{2c_0 q}{\kappa^2} x^2 + O(x^3), \tag{58}$$

Hence, the component  $F^{10}$  diverges in the limit  $r \to +\infty$ . But this does not imply the presence of divergences in quantities like the energy density, among others, neither in the equations of motion. In fact, the Lagrangian  $\mathcal{L}_{NED}$  becomes

$$\mathcal{L}_{NED} \sim -12c_1 \frac{m^3}{a^4 \kappa^2} - \frac{c_1}{\kappa^2} x + O(x^3),$$
 (59)

leading to,

$$\mathcal{L}_F \sim -\frac{q^2 \kappa^2}{c_1} + O(x^4). \tag{60}$$

For the electrical energy density we find

$$\rho \sim 12c_1 \frac{m^3}{q^4} + 2c_1 x - 3c_1 m x^2 + O(x^3), \tag{61}$$

which is a constant in the limit  $r \to +\infty$ . For the effective energy density, we find,

$$\rho_{eff} \sim \frac{3q^6}{4m^2\kappa^2} x^6 + O(x^7),\tag{62}$$

which goes to zero in the limit  $r \to +\infty$ .

Let us now verify how the equations of motion behave. The left hand side of the first one reads in that limit,

$$12c_1\frac{m^3}{q^4} + 2c_1x - 3c_1mx^2 + O(x^3). (63)$$

This shows that the infinity introduced by  $f_R(r) = c_0 + c_1 r = c_0 + c_1 x^{(-1)}$  is cancelled, and does not contribute to the equations of motion. The same happens for the second equation (by symmetry). For the third equation, we find,

$$12c_1\frac{m^3}{q^4} + c_1x + O(x^3). (64)$$

Hence, we confirm that a regular behaviour is also verified for the second solution, since there is no divergence in the physical relevant quantities neither in the equations of motion.

- <span id="page-9-0"></span> A. G. Riess et al., Astron. J. 116, 1009 (1998); S. Perlmutter et al., Nature 391, 51 (1998); S. Perlmutter et al., Astrohpys. J. 517, 565 (1999).
- <span id="page-9-1"></span>[2] P. A. R. Ade et al. (Planck Collaboration), Astron. Astrophys. 571 (2014), arXiv:1303.5062 [astro-ph.CO]; D.N. Spergel et al., Astrophys. J. Suppl. 170, 377 (2007).
- <span id="page-9-2"></span>S. Cole et al., Mon. Not. Roy. Astron. Soc. 362, 505 (2005); D.J. Eisenstein et al., ApJ 633, 560 (2005); W. J. Percival et al., Mon. Not. Roy. Astron. Soc. 401, 2148 (2010); N. Padmanabhan et al., Mon. Not. Roy. Astron. Soc. 427, 2132 (2012); C. Blake et al, Mon. Not. Roy. Astron. Soc. 418, 1707 (2011); L. Anderson et al, Mon. Not. Roy. Astron. Soc. 428, 1036 (2013).
- <span id="page-9-3"></span>[4] E. Hawkins et al., Mon. Not. Roy. Astron. Soc. 346, 78 (2003); M. Tegmark et al., Phys. Rev. D 69, 103501 (2004); S. Cole et al., Mon. Not. Roy. Astron. Soc. 362, 505 (2005).
- <span id="page-9-4"></span>[5] B. Jain and A. Taylor, Phys. Rev. Lett. 91, 141302 (2003).
- <span id="page-9-5"></span>[6] J. Simon, L. Verde and R. Jimenez, Phys. Rev.D 71, 123001 (2005) [astro-ph/0412269]. D. Stern, R. Jimenez, L. Verde, M. Kamionkowski and S. A. Stanford, JCAP 1002, 008 (2010) [arXiv:0907.3149 [astro-ph.CO]]. C. Zhang, H. Zhang, S. Yuan, T. J. Zhang and Y. C. Sun, Res. Astron. Astrophys. 14, 1221 (2014) [arXiv:1207.4541 [astro-ph.CO]]. C. Blake et al., Mon. Not. Roy. Astron. Soc. 418, 1725 (2011) [arXiv:1108.2637 [astro-ph.CO]]. C. H. Chuang and Y. Wang, Mon. Not. Roy. Astron. Soc. 435, 255 (2013) [arXiv:1209.0210 [astro-ph.CO]]. M. Moresco et al., JCAP 1208, 006 (2012) [arXiv:1201.3609 [astro-ph.CO]].
- <span id="page-9-6"></span>[7] R. Penrose, Phys. Rev. Lett. 14, 57 (1965); S. Hawking and R. Penrose, Proc. Roy. Soc. London A 314, 529 (1970).
- <span id="page-9-7"></span>[8] S.W. Hawking and G.F.R. Ellis, **The large scale structure of space-time**, Cambridge university press, Cambridge (1973).
- <span id="page-9-8"></span>[9] S. Weinberg, Rev. Mod. Phys. **61**, 1 (1989).
- <span id="page-9-9"></span>[10] S. Nojiri, S. D. Odintsov, eCONF C0602061, 06, (2006); Int. J. Geom. Meth. Mod. Phys. 4, 115 (2007), hep-th/0601213;
   T. P. Sotiriou, V. Faraoni, Rev. Mod. Phys. 82, 451 (2010), arXiv:0805.1726;
   T. Clifton, P. G. Ferreira, A. Padilla, C. Skordis, Phys. Rep. 513, 1 (2012), arXiv:1106.2476.
- <span id="page-9-10"></span>[11] A. De Felice, S. Tsujikawa, Living Rev. Rel. 13, 3 (2010), arXiv:1002.4928.
- <span id="page-9-11"></span>[12] K. Koyama, Cosmological Tests of Gravity. arXiv:1504.04623[astro-ph.CO].
- <span id="page-9-12"></span>[13] T. Harko, F. S. N. Lobo, S. Nojiri, S. D. Odintsov, Phys. Rev. D84, 024020, (2011), arXiv:1104.2669; M. Jamil, D. Momeni, M. Raza, R. Myrzakulov, Eur. Phys. J. C72 1999 (2012), arXiv:1107.5807; F. G. Alvarenga, A. de la Cruz-Dombriz, M. J. S. Houndjo, M. E. Rodrigues and D. Sáez-Gómez, Phys. Rev. D87, 103526 (2013), Phys. Rev. D87 129905 (2013), arXiv:1302.1866.
- [14] K. Bamba, C.-Q. Geng, S. Nojiri, S. D. Odintsov, Europhys. Lett. 89, 50003 (2010), arXiv:0909.4397; M. J. S. Houndjo,
  M. E. Rodrigues, D. Momeni, R. Myrzakulov, Canadian J. Phys. 92, 1528 (2014), arXiv:1301.4642; M. E. Rodrigues, M. J.
  S. Houndjo, D. Momeni, R. Myrzakulov, Canadian J. Phys. 92, 173 (2014); arXiv:1212.4488; K. Bamba, S. D. Odintsov,
  L. Sebastiani, S. Zerbini, Eur. Phys. J. C67 295, (2010), arXiv:0911.4390; S. Nojiri, S. D. Odintsov, A. Toporensky, P.
  Tretyakov, Gen. Rel. Grav.42, 1997 (2010), arXiv:0912.2488.

- [15] G. Cognola, E. Elizalde, S. Nojiri, S. D. Odintsov, S. Zerbini, Phys. Rev. D73, 084007 (2006), [hep-th/0601008;](http://arxiv.org/abs/hep-th/0601008) E. Elizalde, R. Myrzakulov, V. V. Obukhov, D. S´aez-G´omez, Class. Quant. Grav. 27, 095007 (2010 ), [arXiv:1001.3636;](http://arxiv.org/abs/1001.3636) A. De Felice, T. Suyama, JCAP 0906: 034, (2009), [arXiv:0904.2092;](http://arxiv.org/abs/0904.2092) A. De Felice, Shinji Tsujikawa, Phys. Lett. B675 1-8, (2009), [arXiv:0810.5712;](http://arxiv.org/abs/0810.5712) S. Nojiri, S. D. Odintsov, Phys. Lett. B631:1-6, (2005), [hep-th/0508049;](http://arxiv.org/abs/hep-th/0508049) S. Nojiri, S. D. Odintsov, Phys. Rev. D68:123512, (2003), [hep-th/0307288.](http://arxiv.org/abs/hep-th/0307288)
- [16] R. Aldrovandi, J. G. Pereira, "An Introduction to Teleparallel Gravity", Instituto de F´ısica Te´orica, S˜ao Paulo (2010), [www.ift.unesp.br/users/jpereira/tele.pdf;](#page-0-4) R. Aldrovandi; J. G. Pereira; K. H. Vu, Braz. J. Phys. 34 (2004), [gr-qc/0312008;](http://arxiv.org/abs/gr-qc/0312008) J. W. Maluf, Annalen Phys. 525, 339 (2013), [arXiv:1303.3897;](http://arxiv.org/abs/arXiv:1303.3897) F. W. Hehl, J. D. McCrea, E. W. Mielke, and Y. Ne'eman, Phys. Rep. 258, 1 (1995).
- [17] R. Ferraro and F. Fiorini, Phys. Rev. D75, 084031 (2007), [gr-qc/0610067;](http://arxiv.org/abs/gr-qc/0610067) T. Harko, F. S. N. Lobo, G. Otalora, E.N. Saridakis, Phys. Rev. D 89, 124036 (2014), [arXiv:1404.6212;](http://arxiv.org/abs/arXiv:1404.6212) S. Basilakos, S. Capozziello, M. De Laurentis, A. Paliathanasis, M. Tsamparlis, Phys. Rev. D88, 103526 (2013), [arXiv:1311.2173;](http://arxiv.org/abs/arXiv:1311.2173) K. Bamba, S. D. Odintsov, D. S´ez-G´omez, Phys. Rev. D 88 (2013) 084042, [arXiv:1308.5789;](http://arxiv.org/abs/arXiv:1308.5789) M. E. Rodrigues, M. J. S. Houndjo, D. S´aez-G´omez, F. Rahaman, Phys. Rev. D86, 104059 (2012), [arXiv:1209.4859;](http://arxiv.org/abs/arXiv:1209.4859) C. Xu, E. N. Saridakis, G. Leon, JCAP 1207, 005 (2012), [arXiv:1202.3781;](http://arxiv.org/abs/arXiv:1202.3781) C. G. Boehmer, T. Harko, F. S. N. Lobo, Phys. Rev. D85, 044033 (2012), [arXiv:1110.5756;](http://arxiv.org/abs/arXiv:1110.5756) J. B. Dent, S. Dutta, E. N. Saridakis, JCAP 1101, 009 (2011), [arXiv:1010.2215;](http://arxiv.org/abs/arXiv:1010.2215) B. Li, T. P. Sotiriou, J. D. Barrow, Phys. Rev. D83, 064035 (2011), [arXiv:1010.1041.](http://arxiv.org/abs/arXiv:1010.1041)
- [18] F. Kiani K. Nozari, Phys. Lett. B728, 554 (2014) [arXiv:1309.1948]; T. Harko, F. S. N. Lobo, G. Otalora, E. N. Saridakis, JCAP 12, 021 (2014), [arXiv:1405.0519].
- <span id="page-10-0"></span>[19] G. Kofinas and E. N. Saridakis, Phys. Rev. D90, 084044 (2014), [arXiv:1404.2249 \[gr-qc\].](http://arxiv.org/abs/arXiv:1404.2249)
- <span id="page-10-4"></span>[20] M. E. Rodrigues, E. L. B. Junior, G. T. Marques and V. T. Zanchin, *Regular black holes in* f(R) *gravity*, arXiv:1511.00569.
- <span id="page-10-5"></span>[21] L. Balart and E. C. Vagenas, Phys.Lett. B730, 14 (2014). [arXiv:1401.2136 \[gr-qc\].](http://arxiv.org/abs/arXiv:1401.2136)
- [22] E. L. B. Junior and M. E. Rodrigues, [arXiv:1509.03267 \[gr-qc\].](http://arxiv.org/abs/arXiv:1509.03267)
- <span id="page-10-1"></span>[23] M. Born, L. Infeld, Proc. R. Soc. (London) A 144, 425 (1934), [DOI: 10.1098/rspa.1934.0059.]( http://rspa.royalsocietypublishing.org/content/144/852/425.full.pdf+html)
- <span id="page-10-2"></span>[24] A. Peres, Phys. Rev. 122, 273 (1961), [DOI: 10.1103/PhysRev.122.273.](http://dx.doi.org/10.1103/PhysRev.122.273)
- [25] L. Balart, Mod. Phys. Lett. A24, 2777 (2009), [arXiv:0904.4318;](http://arxiv.org/abs/0904.4318) E. Ay´on-Beato, A. Garc´ıa, Phys. Lett. B464: 25, (1999), [hep-th/9911174;](http://arxiv.org/abs/hep-th/9911174) E. Ay´on-Beato, A. Garc´ıa, Phys. Rev. Lett. 80:, 5056 (1998), [gr-qc/9911046;](http://arxiv.org/abs/gr-qc/9911046) K. A. Bronnikov, Phys. Rev. D63: 044005, (2001), [gr-qc/0006014;](http://arxiv.org/abs/gr-qc/0006014) I. Dymnikova, Class. Quant. Grav .21, 4417 (2004), [gr-qc/0407072;](http://arxiv.org/abs/gr-qc/0407072) A. Garc´ıa, E. Hackmann, C. Lammerzahl, and A. Macias, Phys. Rev. D86, 024037 (2012); G. W. Gibbons, D. A. Rasheed, Phys. Lett. B365 46 (1996), [hep-th/9509141;](http://arxiv.org/abs/hep-th/9509141) F. S. N. Lobo, A. V. B. Arellano, Class. Quant. Grav. 24, 1069(2007), [gr-qc/0611083;](http://arxiv.org/abs/gr-qc/0611083) G. J. Olmo, D. Rubiera-Garcia, Phys. Rev. D84, 124059 (2011), [arXiv:1110.0850;](http://arxiv.org/abs/1110.0850) L. Balart, E. C. Vagenas, Phys. Rev. D90, 124045 (2014), [arXiv:1408.0306;](http://arxiv.org/abs/1408.0306) J. A. R. Cembranos, A. de la Cruz-Dombriz and J. Jarillo, JCAP 02, 042 (2015), [arXiv:1407.4383.](http://arxiv.org/abs/1407.4383)
- [26] J. M. Bardeen, "Non-singular general-relativistic gravitational collapse", in *Proceedings of GR5* (Tbilisi, URSS, 1968).
- [27] E. Ay´on-Beato, A. Garc´ıa, Phys. Lett. B493 (2000) 149-152, [gr-qc/0009077;](http://arxiv.org/abs/gr-qc/0009077) E. Ay´on-Beato and A. Garc´ıa, Phys. Rev. Lett. 80, 5056 (1998); arXiv:gr-qc/9911046; K. A. Bronnikov, Phys. Rev. Lett. 85, 4641 (2000).
- <span id="page-10-3"></span>[28] I. G. Dymnikova, Gen. Rel. Gravit. 24, 235 (1992); I. G. Dymnikova, Phys. Lett. B472, 33 (2000); arXiv:gr-qc/9912116; I. G. Dymnikova, Int. J. Mod. Phys. D 12, 1015 (2003); arXiv:gr-qc/0304110; K. A. Bronnikov and I. Dymnikova, Class. Quant. Grav. 24, 5803 (2007); arXiv:0705.2368 [gr-qc]; M. Azreg-A¨ınou, G. Clment, J. C. Fabris and M. E. Rodrigues, Phys. Rev. D83 124001 (2011); arXiv:1102.4093 [hep-th]. K. A. Bronnikov and J. C. Fabris, Phys. Rev. Lett. 96, 251101 (2006); arXiv:gr-qc/0511109; S. Ansoldi, "Spherical black holes with regular center: a review of existing models including a recent realization with Gaussian sources"; arXiv:0802.0330 [gr-qc] (2008); J. P. S. Lemos, V. T. Zanchin, Phys. Rev. D83, 124005 (2011), arXiv:1104.4790 [gr-qc].
- <span id="page-10-6"></span>[29] J. Wainwright and P. E. A. Yaremovicz, Gen. Rel. Grav. 7, 345 (1976); [DOI: 10.1007/BF00771105;](http://link.springer.com/article/10.1007/BF00771105) Gen. Rel. Grav. 7, 595 (1976), [DOI: 10.1007/BF00763408.](#page-0-4)
- <span id="page-10-7"></span>[30] J. Santos, J. S. Alcaniz, M. J. Rebou¸cas and F. C. Carvalho, Phys. Rev. D76, 083513 (2007), [arXiv:0708.0411 \[astro-ph\].](http://arxiv.org/abs/arXiv:0708.0411)
- <span id="page-10-8"></span>[31] M. Visser, Lorentzian wormholes: from Einstein to Hawking, Springer-Verlag, New York (1996).