## Interior Dynamics of Regular Schwarzschild Black Holes

J. Ovalle\*

Research Centre for Theoretical Physics and Astrophysics, Institute of Physics, Silesian University in Opava, CZ-746 01 Opava, Czech Republic.

We present a purely geometric and exact description of the interior dynamics of a Schwarzschild black hole, formulated without invoking any specific gravitational theory and free of charges beyond its total mass  $\mathcal{M}$ . Its dynamical evolution gives rise to new singularities absent in the static case, whose resolution imposes highly restrictive conditions on gravitational collapse.

Introduction. Among the various strategies for circumventing the celebrated Penrose singularity theorem [1–3], the most commonly explored involves allowing the existence of an inner horizon: one typically constructs a regular black hole (BH) solution [4–8], only to find that it necessarily contains at least one inner horizon, or Cauchy horizon, thereby breaking global hyperbolicity. As expected, given the theorem's generality, it does not specify the dynamics of gravitational collapse, something essential if we aim to develop a physically relevant regularization mechanism that is, as far as possible, independent of spacetime symmetry. Unfortunately, modeling collapse in a simple analytical form, even under maximal symmetry, is notoriously difficult. Despite this, in this work, we achieve it by adopting two reasonable premises:

The event horizon must precede the singularity, as required by weak cosmic censorship [9]. For a finite stage before full collapse, the infalling matter settles into a regular configuration that necessarily develops an inner horizon; in static or stationary cases this inner horizon coincides with a Cauchy horizon, for which extensive evidence shows generic instability [10–14].

Before total collapse occurs, a stage marked by maximal geometric simplicity, we may reasonably expect the internal geometry of the BH to be highly complex. This complexity, however, will be assumed to remain consistent with the absence of primary hair: a single parameter  $\mathcal{M}$  in the static case, and two parameters  $\{\mathcal{M}, a\}$  in the stationary case, representing the total mass and angular momentum of the configuration, respectively. In short, any internal structure should be encoded entirely in secondary hair. This requirement implies one of two possibilities: (i) the system remains within the domain of general relativity, even under extreme curvature, or (ii) if a new theory is invoked, its formulation must remain strictly geometric and refrain from introducing additional charges.

Building on the two premises outlined above, this letter presents a simple analytical description of the final stage of spherically symmetric gravitational collapse, namely the formation of a nonsingular Schwarzschild BH, developed within a purely geometric framework, without assuming any specific gravitational theory. We first identify an infinite family of previously overlooked regular solutions, revealing the remarkable structural richness of the

Schwarzschild interior. By introducing dynamical evolution into these solutions, we uncover potential singularities that arise only in the dynamical case, absent in the static scenario, whose resolution shows that collapse cannot proceed arbitrarily but is instead subject to highly restrictive conditions. We further demonstrate that the region beyond the inner horizon inevitably develops singularities, in full agreement with the strong cosmic censorship conjecture [9, 15–17]. Finally, by exploiting the simplicity of these configurations, we propose a tractable regularization mechanism that provides both an exact analytical account of regular BH formation and a detailed description of the transition between Schwarzschild's singular and regular configurations.

Regular Schwarzschild BHs. We begin with the interior of the Schwarzschild BH [18]. The complete spacetime is described by the line element

<span id="page-0-1"></span>
$$ds^{2} = -f(r) dt^{2} + \frac{dr^{2}}{f(r)} + r^{2} d\Omega^{2} , \qquad (1)$$

where

<span id="page-0-0"></span>
$$f(r) = \begin{cases} 1 - \frac{2 m(r)}{r}, & \text{for } 0 < r \le h \\ 1 - \frac{2 \mathcal{M}}{r}, & \text{for } r > h. \end{cases}$$
 (2)

The function m(r) in (2) stands for the Misner-Sharp mass and

<span id="page-0-3"></span>
$$\mathcal{M} \equiv m(r)|_{r=h} = \frac{h}{2} \tag{3}$$

is the Arnowitt-Deser-Misner mass, where h is the event horizon. Notice that the metric function m(r) remains unknown for r < h. We can see that the Schwarzschild solution [19–25] is given by a particular case of (2), where  $m(r) = \mathcal{M}$  for  $0 < r \leq \infty$ . To ensure the smooth continuity of the metric (1) across the horizon r = h, the mass function m(r) must satisfy

$$m(h) = \mathcal{M} \; ; \quad m'(h) = 0 \; , \tag{4}$$

where  $F(h) \equiv F(r)|_{r=h}$  for any F(r).

Now, consider the mass function of the interior metric in (2), given by

<span id="page-0-2"></span>
$$m = M - \frac{Q^2}{2r} + \frac{1}{2} \sum_{n=2}^{\infty} \frac{C_n r^{n+1}}{(n+1)(n+2)} , \quad n \in \mathbb{N} , \quad (5)$$

where M and Q are integration constants that may eventually be identified with the Schwarzschild mass and the Reissner-Nordström charge, respectively [18]. Nonetheless, to guarantee regularity, we must impose M=Q=0. While the general series solution in (5) is highly effective [26–28], it still depends implicitly on  $h=2\,M$  through the coefficients  $C_n$ . It would be far more useful to derive a general solution that expresses this dependence explicitly. Such a formulation would allow for a clearer and more direct analysis of the Schwarzschild BH interior. To accomplish this, we consider a generic solution expressed as a superposition of N distinct configurations [29, 30], embedded in a de Sitter background with cosmological constant  $\sim C_3$ ,

$$m(r) = C_3 r^3 + \underbrace{C_l r^l + C_n r^n + C_p r^p + \dots}_{N \text{ terms}},$$
 (6)

where the unknown  $C'_s$  can be found by the condition (3) and

<span id="page-1-0"></span>
$$\frac{d^n m}{dr^n}(h) = 0 , (7)$$

for all  $1 \leq n \leq N$ . From (7) it follows that m(r) is N-times differentiable at the event horizon r = h. Consequently, both m(r) in (2) and the metric (1) belong to the class  $\mathcal{C}^N$  for r > 0. Applying this method, the interior Schwarzschild mass function in (2) takes the form

<span id="page-1-6"></span>
$$m(r) = \frac{r}{2} \left[ \left( \frac{r}{h} \right)^2 \prod_{i=1}^N \frac{n_i + 1}{n_i - 2} + 3(-1)^N \sum_{k=1}^N \frac{1}{n_k - 2} \left( \frac{r}{h} \right)^{n_k} \prod_{\substack{i=1\\i \neq k}}^N \frac{n_i + 1}{n_k - n_i} \right] , \quad (8)$$

which yields the corresponding Schwarzschild interior metric function

<span id="page-1-3"></span>
$$f(r) = 1 - \left[ \left( \frac{r}{h} \right)^2 \prod_{i=1}^N \frac{n_i + 1}{n_i - 2} + 3(-1)^N \sum_{k=1}^N \frac{1}{n_k - 2} \left( \frac{r}{h} \right)^{n_k} \prod_{\substack{i=1\\i \neq k}}^N \frac{n_i + 1}{n_k - n_i} \right] , \quad (9)$$

where  $2 < n_i \in \mathbb{N}$ . For each fixed N, the solution is specified by N parameters  $n_i$  (not hairs), parametrizing an infinite family of regular BH geometries. Extending the domain to  $n_i \in [-2,2]$  yields BHs with integrable singularities [31–33]. In particular, if there exists an index i such that  $n_i = -1$ , one recovers the standard Schwarzschild solution. As a concrete illustration, let us consider the simplest case with N=1, which takes the explicit form

<span id="page-1-1"></span>
$$m(r) = \frac{r}{2(n-2)} \left\lceil \frac{r^2}{h^2} (n+1) - 3 \left(\frac{r}{h}\right)^n \right] \; ; \; \; n > 2 \; , \; (10)$$

and the case N=2

<span id="page-1-2"></span>
$$m(r) = \frac{r}{2} \left[ \frac{(n+1)(l+1)}{(n-2)(l-2)} \left( \frac{r}{h} \right)^2 + \frac{3(l+1)}{(n-2)(n-l)} \left( \frac{r}{h} \right)^n + \frac{3(n+1)}{(l-2)(l-n)} \left( \frac{r}{h} \right)^l \right] ; l > n > 2 \in \mathbb{N} . (11)$$

We can see that both regular solutions (10) and (11), originally derived in Ref. [18] and subsequently analyzed in Ref. [28], represent special cases of the solution (9). Regarding the scalar curvature, it takes the form

<span id="page-1-4"></span>
$$R(r) = \frac{3}{h^2} \left[ 4 \prod_{i=1}^{N} \frac{n_i + 1}{n_i - 2} + (-1)^N \sum_{k=1}^{N} \frac{(n_k + 1)(n_k + 2)}{(n_k - 2)} \left( \frac{r}{h} \right)^{n_k - 2} \prod_{\substack{i=1\\i \neq k}}^{N} \frac{n_i + 1}{n_k - n_i} \right]$$

with the property that R(h) = 0 for N > 1. We emphasize that these BHs possess a single inner horizon  $h_c$ . Finally, we highlight two important aspects of the solution (9), namely, (i) it depends only on the mass  $\mathcal{M}$  of the configuration (no hairs) and (ii) despite it contains only a single parameter  $\mathcal{M}$ , the solution has an (quasi) extremal BH with  $h_c \sim h$ . This occurs when  $n_k >> 1 \ \forall k$ , yielding  $m(r) \sim \frac{r^3}{2h^2}$ .

In connection with the latter property, a direct inspection of the metric function in Eq. (9), or equivalently the scalar curvature in Eq. (12), yields the explicit expression for the effective cosmological constant,

$$\Lambda_{eff} = \frac{3}{h^2} \prod_{i=1}^{N} \frac{n_i + 1}{n_i - 2} \ . \tag{13}$$

As n grows large  $h_{\rm c} \sim h$ , implying that the configuration approaches an extremal Schwarzschild BH with a de Sitter interior, i.e.,

<span id="page-1-5"></span>
$$m(r) \rightarrow \frac{r^3}{2h^2}$$
,  $f(r) \rightarrow 1 - \frac{r^2}{h^2}$ ,  $h_c \rightarrow h$  as  $n_i \rightarrow \infty$ , (14)

This result is particularly significant because, unlike all other regular BH solutions where the de Sitter core remains localized near the origin  $r \sim 0$ , here it undergoes unbounded growth  $(n_i \to \infty)$  until occupying the complete interior spacetime  $(0 \le r \le h)$ .

Finally, notice that the surface gravity  $\kappa$  for the metric function (9), given by

$$\kappa = \frac{1}{2}f'(h) = \frac{1}{2h} ,$$
(15)

is completely independent of the parameters  $n_i$ . This result reveals that, regardless of the interior's complexity, the horizon thermodynamics remains purely Schwarzschil-like, entirely governed by h alone. The extremal case in Eq. (14) provides the sole exception to this

result, exhibiting a de Sitter geometry with surface gravity  $\kappa = 1/h$ . Here, while the spacetime remains continuous at the horizon, it fails to be differentiable, a property that directly explains the discontinuous jump in surface gravity from the interior de Sitter value ( $\kappa = 1/h$ ) to the exterior Schwarzschild value ( $\kappa = 1/2h$ ).

The dynamic interior. The existence of regular BH solutions in Eq. (9) presents two fundamental and intimately related challenges for their physical realization:

- Formation Mechanism: What processes could produce these non-singular spacetime geometries?
- Evolutionary Fate: Once formed, does their evolution preserve regularity, or could singularities eventually develop?

To address these questions, while not claiming definitive resolution, we now investigate the dynamical extension of these solutions. We begin by rewriting the metric (1) in Eddington-Finkelstein form by introducing the ingoing null coordinate v, defined through dv = dt + dr/f, which yields

<span id="page-2-0"></span>
$$ds^{2} = -f(r) dv^{2} + 2 dv dr + r^{2} d\Omega^{2} . {16}$$

Next, we generalize the mass function to a fully generic time-dependent form

<span id="page-2-1"></span>
$$m(r) \to m(v,r)$$
 . (17)

The metric (16) with (17) is well-known in the context of general relativity [34, 35] and beyond [36]. In this case the null convergence condition  $R_{\mu\nu}l^{\mu}l^{\nu}\geq 0$ ,  $l^{\mu}l_{\mu}=0$  yields

<span id="page-2-7"></span>
$$\dot{m} \ge 0 \tag{18}$$

where  $\dot{m} \equiv \frac{\partial m}{\partial v}$ . Next, we extend the regular Schwarzschild BHs to time-dependent cases, with particular focus on the emergence and subsequent unbounded decay of their de Sitter core.

Extremal  $\leftrightarrow$  regular black holes. To analyze the dynamical evolution of the nonsingular Schwarzschild geometries in Eq. (9), we first extend these solutions to time-dependent cases. This dynamical generalization requires promoting the mass function in Eq. (8) via the generic prescription given in Eq. (17). However, the requirement that the exterior solution must remain static [as established in Eq. (2)] imposes the crucial boundary condition

<span id="page-2-2"></span>
$$h = 2\mathcal{M} \neq h(v) . \tag{19}$$

The constraint (19) dictates that dynamical evolution must be mediated exclusively through variations of the parameters  $n_i$  in the mass function (8), yielding

$$n_i = n_i(v) , (20)$$

![](_page_2_Figure_16.jpeg)

<span id="page-2-6"></span>FIG. 1. Evolution of the inner horizon  $h_c(v)$  for the dynamical interior (21): Collapse for  $\dot{n}_i < 0$  and expansion for  $\dot{n}_i > 0$ . Horizon  $h = 2\mathcal{M} \neq h(v)$ . Distance r in units of  $\mathcal{M}$ .

which transforms the mass function to its time-dependent form

<span id="page-2-3"></span>
$$m(v,r) = \frac{r}{2} \left[ \left( \frac{r}{h} \right)^2 \prod_{i=1}^N \frac{n_i(v) + 1}{n_i(v) - 2} + 3(-1)^N \times \right]$$
$$\sum_{k=1}^N \frac{1}{n_k(v) - 2} \left( \frac{r}{h} \right)^{n_k(v)} \prod_{\substack{i=1\\i \neq k}}^N \frac{n_i(v) + 1}{n_k(v) - n_i(v)} \right] . (21)$$

A straightforward analysis of Eq. (21) shows that the dynamical extension of Eq. (8) develops singularities whenever  $n_k(v) = n_i(v)$  for any pair of functions. To prevent these singularities, all  $n_i(v)$  must evolve without intersections. This requires an initial ordering at  $v = v_0$ , i.e.,

<span id="page-2-4"></span>
$$n_1(v_0) < n_2(v_0) < \dots < n_N(v_0)$$
, (22)

which must be preserved for all v through the constraint

<span id="page-2-5"></span>
$$\dot{n}_i(v) \le \dot{n}_j(v) , \quad \forall \ i < j \ .$$
 (23)

[The reversed ordering similarly requires  $\dot{n}_i(v) \geq \dot{n}_i(v)$ .] Eqs. (22) and (23) demonstrate that the evolution of the Schwarzschild BH interior is highly constrained: only synchronized parameter evolution yields physically viable configurations. On the other hand, the constraint in Eq. (23) contains both negative and positive slopes  $(\dot{n}_i < 0 \text{ and } \dot{n}_i > 0)$ , which correspond physically to distinct evolutionary regimes: negative slopes drive collapse while positive slopes lead to expansion. When collapse  $(\dot{n}_i < 0)$  dominates, the system evolves from an extremal configuration to a regular BH; conversely, expansion  $(\dot{n}_i > 0)$  dominance produces the reverse transition from regular to extremal configurations [as described for the static case by Eq. (14)]. This formulation reveals that the inner horizon  $h_c$  becomes a dynamical hypersurface  $h_{\rm c} = h_{\rm c}(v)$ , as illustrated in Fig. 1.

Modeling the formation of an extremal configuration emerging from a regular BH is certainly appealing. However, this scenario carries a significant physical limitation: it entails violating the null convergence condition in [\(18\)](#page-2-7). By contrast, in collapse-dominated regimes ( ˙n<sup>i</sup> < 0), Eq. [\(18\)](#page-2-7) is trivially satisfied, indicating that the only physically viable pathway is a transition from an extremal BH. Moreover, the geometric condition Gαβu <sup>α</sup>u <sup>β</sup> ≥ 0 for all future-directed timelike u <sup>α</sup>, which corresponds to the weak energy condition within general relativity, always holds. This persistent collapse inertia drives the formation of a secondary horizon, resulting in a regular BH configuration whose evolution continues until it reaches the critical threshold ni(v) = 2 in Eq. [\(21\)](#page-2-3), the precise condition for singularity formation (where the Kretschmann scalar ∼ [Log(r/h)]<sup>2</sup> for r ∼ 0).

Singularity resolution and final remarks. Our analysis reveals that singularities emerge generically in regular Schwarzschild BHs, as rigorously determined by Eqs. [\(18\)](#page-2-7)-[\(23\)](#page-2-5), where no particular theory was assumed. Avoiding this outcome would require extending these equations with additional, ad hoc constraints. Nevertheless, such modifications may offer valuable insights into mechanisms for singularity resolution. As a concrete example, we propose a saturating transition of the form

<span id="page-3-2"></span>
$$n_i(v) = \frac{\alpha_i e^{-\omega v} + \beta_i e^{\omega v}}{e^{-\omega v} + e^{\omega v}}$$
 (24)

where α<sup>i</sup> ≡ ni(−∞) and β<sup>i</sup> ≡ ni(+∞) characterize the initial and final BH states, respectively, and τ ≡ ω −1 sets the transition timescale. The extremal to regular transition demands

<span id="page-3-1"></span>
$$1 \ll \alpha_i \gg \beta_i > 2 , \quad \forall i . \tag{25}$$

We stress that α<sup>i</sup> are unrestricted: choosing α<sup>i</sup> ≫ 1 allows arbitrarily close approach to the initial extremal configuration

$$m(-\infty, r) \sim \frac{r^3}{2h^2}, \quad f(-\infty, r) \sim 1 - \frac{r^2}{h^2}$$
 (26)

while still preserving horizon differentiability, as illustrated in Fig. [2.](#page-3-0) This model fully captures the transition from quasi-extremal to regular configurations, providing a detailed description of regular BH formation with high resolution. Conversely, the reverse transition, from regular to quasi-extremal, necessarily entails a violation of the null convergence condition [\(18\)](#page-2-7), and can be obtained simply by interchanging α ↔ β in Eq. [\(25\)](#page-3-1). Moreover, the model also reproduces the formation of Schwarzschild's singularity with remarkable clarity, which follow directly by setting β<sup>i</sup> = −1 for some i in Eq. [\(25\)](#page-3-1). Finally, one may introduce a second resolution: avoiding the threshold ni(v) = 2 through a bounce during collapse [\[7\]](#page-4-22), a process that again requires violation of the null convergence condition. This scenario can be modeled by

<span id="page-3-3"></span>
$$n_i(v) = \alpha_i - \beta_i e^{-(\omega v)^2} , \qquad (27)$$

![](_page_3_Figure_10.jpeg)

<span id="page-3-0"></span>FIG. 2. Kretschmann K(v, r) from a quasi extremal to a regular BH for N = 2 in [\(11\)](#page-1-2), where n(v) is given by [\(24\)](#page-3-2) with α = 62, β = 3 and l(v) = 1 + n(v). There is a maximum just below the horizon: K(−∞, h − δ) ∼ (α <sup>2</sup>/h<sup>5</sup> )δ, with δ ≪ 1. We take ω = 0.1.

with α<sup>i</sup> ≳ β<sup>i</sup> ≫ 1. While the first model in Eq. [\(24\)](#page-3-2) circumvent the need for weak cosmic censorship, the second model in [\(27\)](#page-3-3) instead reinterprets the event horizon as a boundary that conceals a transient violation of the null convergence condition, a process essential for realizing a non-singular configuration. Finally, we stress, following Ref. [\[36\]](#page-4-21), that evolving inner horizons need not always coincide with Cauchy horizons. In contrast, our model shows that the inner horizon hc(v), despite its dynamical evolution, is indeed a Cauchy horizon. This conclusion follows directly from the Penrose singularity theorem: since a trapped surface exists at r = h and the null convergence condition holds throughout the kinematical process, the single inner horizon hc(v) must be a Cauchy horizon to evade the theorem. However, it is expected that under generic perturbations the inner horizon becomes unstable [\[37\]](#page-4-23). We wish to conclude by emphasizing that the existence of a regular BH as the final outcome of collapse is only possible if the collapsing configuration successfully avoids singularities throughout its formation. This requirement inevitably constrains the process and, as demonstrated by Eqs. [\(22\)](#page-2-4) and [\(23\)](#page-2-5), may be far more restrictive than anticipated. Exploring how such constraints manifest in more realistic scenarios, such as rotational collapse, could not only clarify the precise conditions for singularity resolution but also shed light on the fundamental interplay between geometry, energy conditions, and cosmic censorship.

## Acknowledgments

JO thanks YITP for all their support during the development of this research work. This work is partially supported by ANID FONDECYT Grant No. 1250227.

- <span id="page-4-0"></span>∗ [jorge.ovalle@physics.slu.cz](mailto:jorge.ovalle@physics.slu.cz)
- <span id="page-4-1"></span>[1] R. Penrose, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.14.57) 14, 57 (1965).
- [2] S. W. Hawking and R. Penrose, [Proc. Roy. Soc. Lond. A](https://doi.org/10.1098/rspa.1970.0021) 314[, 529 \(1970\).](https://doi.org/10.1098/rspa.1970.0021)
- <span id="page-4-2"></span>[3] S. W. Hawking and G. F. R. Ellis, [The Large Scale Struc](https://doi.org/10.1017/CBO9780511524646)[ture of Space-Time](https://doi.org/10.1017/CBO9780511524646), Cambridge Monographs on Mathematical Physics (Cambridge University Press, 2011).
- <span id="page-4-3"></span>[4] J. Bardeen, in Proceedings of the 5th International Conference on Gravitation and the Theory of Relativity (Tbilisi University, 1968) p. 87.
- [5] I. Dymnikova, [Gen. Rel. Grav.](https://doi.org/10.1007/BF00760226) 24, 235 (1992).
- [6] S. A. Hayward, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.96.031103) 96, 031103 (2006).
- <span id="page-4-22"></span>[7] J. Ben Achour, S. Brahma, S. Mukohyama, and J. P. Uzan, JCAP 09[, 020 \(2020\),](https://doi.org/10.1088/1475-7516/2020/09/020) [arXiv:2004.12977 \[gr-qc\].](http://arxiv.org/abs/2004.12977)
- <span id="page-4-4"></span>[8] A. Bonanno, D. Malafarina, and A. Panassiti, [Phys. Rev.](https://doi.org/10.1103/PhysRevLett.132.031401) Lett. 132[, 031401 \(2024\),](https://doi.org/10.1103/PhysRevLett.132.031401) [arXiv:2308.10890 \[gr-qc\].](http://arxiv.org/abs/2308.10890)
- <span id="page-4-5"></span>[9] R. Penrose, [Riv. Nuovo Cim.](https://doi.org/10.1023/A:1016578408204) 1, 252 (1969).
- <span id="page-4-6"></span>[10] R. Penrose, in Battelle Rencontres: 1967 Lectures in Mathematics and Physics (W. A. Benjamin, Inc., New York, 1968) pp. 121–235.
- [11] E. Poisson and W. Israel, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.63.1663) 63, 1663 [\(1989\).](https://doi.org/10.1103/PhysRevLett.63.1663)
- [12] A. Ori, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.67.789) 67, 789 (1991).
- [13] R. Carballo-Rubio, F. Di Filippo, S. Liberati, C. Pacilio, and M. Visser, JHEP 07[, 023 \(2018\).](https://doi.org/10.1007/JHEP07(2018)023)
- <span id="page-4-7"></span>[14] R. Carballo-Rubio, F. Di Filippo, S. Liberati, C. Pacilio, and M. Visser, JHEP 05[, 132 \(2021\).](https://doi.org/10.1007/JHEP05(2021)132)
- <span id="page-4-8"></span>[15] M. Dafermos, [Commun. Pure Appl. Math.](https://doi.org/10.1002/cpa.20071) 58, 0445 [\(2005\),](https://doi.org/10.1002/cpa.20071) [arXiv:gr-qc/0307013.](http://arxiv.org/abs/gr-qc/0307013)
- [16] M. Dafermos and J. Luk, (2017), [arXiv:1710.01722 \[gr](http://arxiv.org/abs/1710.01722)[qc\].](http://arxiv.org/abs/1710.01722)

- <span id="page-4-9"></span>[17] S. Hollands, R. M. Wald, and J. Zahn, [Class. Quant.](https://doi.org/10.1088/1361-6382/ab8052) Grav. 37[, 115009 \(2020\),](https://doi.org/10.1088/1361-6382/ab8052) [arXiv:1912.06047 \[gr-qc\].](http://arxiv.org/abs/1912.06047)
- <span id="page-4-10"></span>[18] J. Ovalle, Phys. Rev. D 109[, 104032 \(2024\).](https://doi.org/10.1103/PhysRevD.109.104032)
- <span id="page-4-11"></span>[19] K. Schwarzschild, Sitzungsber. Preuss. Akad. Wiss., Phys. Math. Kl. 1916, 189 (1916).
- [20] A. S. Eddington, Nature 113[, 192 \(1924\).](https://doi.org/10.1038/113192a0)
- [21] G. Lemaitre, [Annales Soc. Sci. Bruxelles A](https://doi.org/10.1023/A:1018855621348) 53, 51 (1933).
- [22] D. Finkelstein, Phys. Rev. 110[, 965 \(1958\).](https://doi.org/10.1103/PhysRev.110.965)
- [23] M. D. Kruskal, Phys. Rev. 119[, 1743 \(1960\).](https://doi.org/10.1103/PhysRev.119.1743)
- [24] G. Szekeres, Publ. Math. Debrecen 7, 285 (1960).
- <span id="page-4-12"></span>[25] M. Dafermos, G. Holzegel, I. Rodnianski, and M. Taylor, (2021), [arXiv:2104.08222 \[gr-qc\].](http://arxiv.org/abs/2104.08222)
- <span id="page-4-13"></span>[26] R. Casadio, A. Kamenshchik, and J. Ovalle, [Phys. Rev.](https://doi.org/10.1103/PhysRevD.110.044001) D 110[, 044001 \(2024\).](https://doi.org/10.1103/PhysRevD.110.044001)
- [27] S. Aoki and J. Ovalle, Phys. Rev. D 111[, 024037 \(2025\).](https://doi.org/10.1103/PhysRevD.111.024037)
- <span id="page-4-14"></span>[28] R. Casadio, A. Kamenshchik, and J. Ovalle, [Phys. Rev.](https://doi.org/10.1103/PhysRevD.111.064036) D 111[, 064036 \(2025\).](https://doi.org/10.1103/PhysRevD.111.064036)
- <span id="page-4-15"></span>[29] J. Ovalle, Phys. Rev. D95[, 104019 \(2017\).](https://doi.org/10.1103/PhysRevD.95.104019)
- <span id="page-4-16"></span>[30] J. Ovalle, Phys. Lett. B788[, 213 \(2019\).](https://doi.org/10.1016/j.physletb.2018.11.029)
- <span id="page-4-17"></span>[31] V. N. Lukash and V. N. Strokov, [Int. J. Mod. Phys. A](https://doi.org/10.1142/S0217751X13500073) 28[, 1350007 \(2013\),](https://doi.org/10.1142/S0217751X13500073) [arXiv:1301.5544 \[gr-qc\].](http://arxiv.org/abs/1301.5544)
- [32] J. Ovalle, Phys. Rev. D 107[, 104005 \(2023\).](https://doi.org/10.1103/PhysRevD.107.104005)
- <span id="page-4-18"></span>[33] J. Arrechea, S. Liberati, H. Neshat, and V. Vellucci, Phys. Rev. D 112[, 044024 \(2025\).](https://doi.org/ 10.1103/wk7j-yg1t)
- <span id="page-4-19"></span>[34] V. Husain, Phys. Rev. D 53[, 1759 \(1996\).](https://doi.org/10.1103/PhysRevD.53.R1759)
- <span id="page-4-20"></span>[35] A. Wang and Y. Wu, [Gen. Rel. Grav.](https://doi.org/10.1023/A:1018819521971) 31, 107 (1999).
- <span id="page-4-21"></span>[36] J. Borissova, S. Liberati, and M. Visser, [Phys. Rev. D](https://doi.org/10.1103/PhysRevD.111.104054) 111[, 104054 \(2025\),](https://doi.org/10.1103/PhysRevD.111.104054) [arXiv:2502.00548 \[gr-qc\].](http://arxiv.org/abs/2502.00548)
- <span id="page-4-23"></span>[37] R. Carballo-Rubio, F. Di Filippo, S. Liberati, and M. Visser, [Phys. Rev. Lett.](https://doi.org/10.1103/PhysRevLett.133.181402) 133, 181402 (2024).