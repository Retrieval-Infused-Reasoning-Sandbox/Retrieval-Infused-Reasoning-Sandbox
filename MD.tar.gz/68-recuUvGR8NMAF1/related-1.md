# Perturbed Proximal Gradient ADMM for Nonconvex Composite Optimization

Yuan Zhou, Xinli Shi, Senior Member, IEEE, Luyao Guo, Jinde Cao, Fellow, IEEE and Mahmoud Abdel-Aty

Abstract—This paper proposes a Perturbed Proximal Gradient ADMM (PPG-ADMM) framework for solving general nonconvex composite optimization problems, where the objective function consists of a smooth nonconvex term and a nonsmooth weakly convex term for both primal variables. Unlike existing ADMMbased methods which necessitate the function associated with the last updated primal variable to be smooth, the proposed PPG-ADMM removes this restriction by introducing a perturbation mechanism, which also helps reduce oscillations in the primaldual updates, thereby improving convergence stability. By employing a linearization technique for the smooth term and the proximal operator for the nonsmooth and weakly convex term, the subproblems have closed-form solutions, significantly reducing computational complexity. The convergence is established through a technically constructed Lyapunov function, which guarantees sufficient descent and has a well-defined lower bound. With properly chosen parameters, PPG-ADMM converges to an  $\epsilon$ -approximate stationary point at a sublinear convergence rate of  $\mathcal{O}(1/\sqrt{K})$ . Furthermore, by appropriately tuning the perturbation parameter  $\beta$ , it achieves an  $\epsilon$ -stationary point, providing stronger optimality guarantees. We further apply PPG-ADMM to two practical distributed nonconvex composite optimization problems, i.e., the distributed partial consensus problem and the resource allocation problem. The algorithm operates in a fully decentralized manner without a central coordinating node. Finally, numerical experiments validate the effectiveness of PPG-ADMM, demonstrating its improved convergence performance.

Index Terms—ADMM, Nonconvex composite optimization, Distributed optimization, Convergence rate

#### I. Introduction

#### A. Motivation and Contributions

The Alternating Direction Method of Multipliers (ADMM) was first introduced in the 1970s with the aim of integrating the advantages of dual ascent and the method of multipliers [1]. Over the past few decades, ADMM has gained significant attention due to its favorable convergence properties, flexibility, and generality. To enhance its effectiveness, researchers have continuously refined ADMM by incorporating additional

Yuan Zhou is with the School of Cyber Science and Engineering, Southeast University, Nanjing 210096, China (e-mail: zhouxyz@seu.edu.cn).

Xinli Shi is with the School of Cyber Science and Engineering, Southeast University, Nanjing 210096, China, and also with the School of Engineering, RMIT University, Melbourne, VIC 3001, Australia. (e-mail: xinli shi@seu.edu.cn).

Luvao Guo and Jinde Cao are with the School of Mathematics, Southeast University, Nanjing 210096, China (e-mail: ly\_guo@seu.edu.cn; jdcao@seu.edu.cn).

Mahmoud Abdel-Aty is with the Deanship of Graduate Studies and Scientific Research, Ahlia University, Manama 10878, Bahrain, and also with the Mathematics Department, Faculty of Science, Sohag University, Sohag 82524, Egypt (e-mail: mabdelaty@zewailcity.edu.eg).

mechanisms that accelerate convergence, improve subproblem solvability, enhance robustness, and ensure privacy protection, etc [1], [2]. Consequently, numerous variants of ADMM have been developed and applied across diverse fields, including smart grid [3], machine learning [4], image processing [5], etc. While the majority of existing ADMM research concentrates on convex optimization, many practical applications involve nonconvex problems, such as matrix separation [6], sparse principal component analysis [7], distributed clustering [8], and so forth. Moreover, certain nonsmooth terms are often incorporated into objective functions for various purposes, such as utilizing the  $\ell_1$  norm to acquire sparse solutions [9], forming composite optimization problems. These challenges highlight the urgent need to develop ADMM methods tailored for Nonconvex Composite Optimization Problems (NCOPs).

In this paper, we consider the following two-block problem:

<span id="page-0-0"></span>
$$\min_{\mathbf{x}, \mathbf{z}} F(\mathbf{x}) + H(\mathbf{z}), \quad s.t. \ \mathbf{A}\mathbf{x} + \mathbf{B}\mathbf{z} = \mathbf{c}, \tag{1}$$

where  $\mathbf{x} \in \mathbb{R}^n$ ,  $\mathbf{z} \in \mathbb{R}^m$ ,  $\mathbf{A} \in \mathbb{R}^{p \times n}$ ,  $\mathbf{B} \in \mathbb{R}^{p \times m}$  and  $\mathbf{c} \in \mathbb{R}^p$ . Handling the nonconvex and nonsmooth terms F and H simultaneously is extremely challenging, as certain special properties of the functions cannot be leveraged during analysis. Therefore, similar to [10], [11], we decompose  $F = F^0 + F^1$ and  $H = H^0 + H^1$ , where  $F^0 : \mathbb{R}^n \to \mathbb{R}$  and  $H^0 : \mathbb{R}^m \to \mathbb{R}$ are proper, closed and smooth functions (potentially nonconvex),  $F^1: \mathbb{R}^n \to \mathbb{R} \cup \{+\infty\}$  and  $H^1: \mathbb{R}^m \to \mathbb{R} \cup \{+\infty\}$ are proper, lower semi-continuous and weakly convex functions (possibly nonsmooth). This formulation captures various practical problems, such as the sharing problem [1, Section 7.3] and CT imaging reconstruction [10].

One can utilize ADMM to address problem (1):

<span id="page-0-1"></span>
$$\mathbf{x}^{k+1} = \arg\min_{\mathbf{x}} L_{\rho}(\mathbf{x}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}), \tag{2a}$$
$$\mathbf{z}^{k+1} = \arg\min_{\mathbf{z}} L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}, \boldsymbol{\lambda}^{k}), \tag{2b}$$

<span id="page-0-5"></span><span id="page-0-4"></span><span id="page-0-3"></span>
$$\mathbf{z}^{k+1} = \arg\min_{\mathbf{z}} L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}, \boldsymbol{\lambda}^{k}), \tag{2b}$$

<span id="page-0-2"></span>
$$\boldsymbol{\lambda}^{k+1} = \boldsymbol{\lambda}^k - \rho (\mathbf{A} \mathbf{x}^{k+1} + \mathbf{B} \mathbf{z}^{k+1} - \mathbf{c}), \tag{2c}$$

where  $k \ge 0$  denotes the number of iterations,  $\rho >$ the penalty parameter and  $\lambda \in \mathbb{R}^p$  is the dual variable. The augmented Lagrangian in (2) is defined as

$$L_{\rho}(\mathbf{x}, \mathbf{z}, \boldsymbol{\lambda})$$
 (3)

$$=F(\mathbf{x})+H(\mathbf{z})-\langle \boldsymbol{\lambda}, \mathbf{A}\mathbf{x}+\mathbf{B}\mathbf{z}-\mathbf{c}\rangle+\frac{\rho}{2}\|\mathbf{A}\mathbf{x}+\mathbf{B}\mathbf{z}-\mathbf{c}\|^2.$$

Compared to the extensively studied convex optimization algorithms, relatively few algorithms are available for solving NCOPs. Directly applying classic convex optimization methods to nonconvex problems is often infeasible, as certain common analytical techniques, such as variational inequalities, are generally not applicable in the nonconvex setting and thus fail to provide convergence guarantees [12]. In the convergence analysis of some primal-dual algorithms for NCOPs, the crucial step is the construction of a Lyapunov function P [\[12\]](#page-14-11), [\[13\]](#page-14-12), which must be both sufficiently decreasing and bounded from below with respect to the sequence {(x k , z k ,λ k )}k⩾<sup>0</sup> generated by algorithms, i.e.,

$$\mathcal{P}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k+1}) - \mathcal{P}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k})$$

$$\leq -a_{1} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2} - a_{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2} - a_{3} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2},$$

$$\mathcal{P}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}) > -\infty,$$
(4a)

where a1, a<sup>2</sup> and a<sup>3</sup> are nonnegative coefficients. In general, such a Lyapunov function is constructed based on the Lagrangian, as it facilitates establishing a connection between the cluster point of the generated sequence and the stationary solution of the optimization problem in the subsequent analysis [\[13\]](#page-14-12). However, directly employing the (augmented) Lagrangian as a Lyapunov function does not satisfy the requirements of [\(4a\)](#page-1-0). Specifically, for [\(3\)](#page-0-2), we have

$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}) - L_{\rho}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}) \leqslant -a_{1} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2},$$
(5a)  

$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k}) - L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}) \leqslant -a_{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2},$$
(5b)

$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k+1}) - L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k})$$
(5c)  
=  $-\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle \stackrel{\text{(2c)}}{=} \frac{1}{\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2}$ .

The inequalities [\(5a\)](#page-1-1) and [\(5b\)](#page-1-2) follow from the optimality conditions of the primal variable updates, leveraging specific function properties such as smoothness or strong convexity. However, the presence of the constant positive coefficient ρ in [\(5c\)](#page-1-3) contradicts the intention to construct a Lyapunov function satisfying [\(4a\)](#page-1-0), after integrating [\(5a\)](#page-1-1)-[\(5c\)](#page-1-3). Subsequently, establishing a connection between the primal and dual variables through these conditions and appropriately adjusting relevant coefficients enables the construction of a valid Lyapunov function. In consequence, the ADMM for solving NCOPs is typically augmented with two common additional assumptions to bound ∥λ <sup>k</sup>+1 − λ k∥ 2 [\[2\]](#page-14-1), [\[12\]](#page-14-11)–[\[14\]](#page-14-13):

C1: The matrices satisfy Im(A) ∪ {c} ⊆ Im(B).

C2: The update block of the last primal variable (e.g., [\(2b\)](#page-0-4)) is unconstrained and its corresponding term in objective function (e.g., H(z) in [\(1\)](#page-0-0)) is smooth.

A detailed analysis of these conditions can be found in Section [IV.](#page-5-0) However, the smoothness assumption in C2 limits the applicability of ADMM, as it may not hold in certain practical scenarios. For example, Robust Principal Component Analysis (RPCA), widely used in image processing, aims to decompose a given data matrix M into a low-rank component x and a sparse component z. This decomposition is achieved by solving the following principal component pursuit formulation:

<span id="page-1-5"></span>
$$\min_{\mathbf{x}, \mathbf{z}} f(\mathbf{x}) + \kappa \cdot h(\mathbf{z}), \quad s.t. \quad \mathbf{M} = \mathbf{x} + \mathbf{z}, \tag{6}$$

where κ > 0 is set to balance these two components. Suitable choices of f and h are required to enforce low-rankness and sparsity in x and z, respectively. These functions are typically nonsmooth and can even be nonconvex [\[15\]](#page-14-14), [\[16\]](#page-14-15). Consequently, this paper proposes a perturbed proximal gradient ADMM (PPG-ADMM) framework to address the general NCOP [\(1\)](#page-0-0), followed by a convergence analysis and exploration of its decentralized applications. The main contributions of this paper are summarized as follows.

<span id="page-1-0"></span>Scalable ADMM Framework for More General NCOPs: Existing ADMMs for NCOPs typically require the smoothness assumption in C2 holds, which limits their applicability. For instance, in RPCA problem, enforcing C2 often necessitates complex reformulations and the introduction of auxiliary variables. In contrast, the proposed PPG-ADMM can be directly applied even without C2, eliminating the need for such modifications. In summary, compared to existing methods, PPG-ADMM removes the requirement for stringent smoothness assumptions, compact feasibility sets, or full-rank conditions on the constraint matrix, greatly broadening its applicability.

<span id="page-1-4"></span><span id="page-1-3"></span><span id="page-1-2"></span><span id="page-1-1"></span>Convergence Rate Analysis with Perturbation Mechanism: We introduce a novel perturbation mechanism in PPG-ADMM that strikes a balance between the optimality and constraint satisfaction. This mechanism reduces the sensitivity of dual updates, mitigates oscillations, and enhances convergence performance, particularly in ill-conditioned problems or with suboptimal parameter choices, as demonstrated in the RPCA experiment. More importantly, it addresses the fundamental challenge of constructing a valid Lyapunov function when C2 is not satisfied, a critical obstacle in the theoretical analysis of traditional ADMM for more general NCOPs. We show that PPG-ADMM achieves a convergence rate of O(1/ √ K) and iteration complexity of O(1/ϵ<sup>2</sup> ) for reaching an ϵ-AKKT point, matching the lower bound for first-order methods in nonconvex optimization. Furthermore, by setting the perturbation parameter β = O(1/K), PPG-ADMM attains an ϵ-KKT point, providing stronger optimality guarantees.

Decentralized Applications: We extend the PPG-ADMM framework to decentralized settings and propose two decentralized algorithms for solving practical NCOPs, including partial consensus and resource allocation problems. Their implementations operate without a central coordinator or reliance on specific network topology constraints. The first algorithm generalizes distributed consensus problem, while the second allows step size selection independent of the network structure. We conduct numerical experiments to validate the effectiveness and robustness of the proposed algorithms. Given the limited exploration of ADMM in decentralized NCOPs, our work extends its applicability in this domain.

# *B. Related Work*

We summarize the relevant works [\[17\]](#page-14-16)–[\[37\]](#page-14-17) on utilizing ADMM to solve NCOPs in TABLE [I.](#page-2-0) The table also includes the assumptions related to C1 and C2, illustrating that despite differences in problem formulations and algorithms, these works all satisfy these two conditions. The assumptions on the matrices of constraints in [\[17\]](#page-14-16)–[\[24\]](#page-14-18), [\[29\]](#page-14-19)–[\[35\]](#page-14-20), [\[37\]](#page-14-17) represent a specific form of C1. Some works [\[19\]](#page-14-21)–[\[24\]](#page-14-18), [\[30\]](#page-14-22), [\[31\]](#page-14-23), [\[33\]](#page-14-24)– [\[35\]](#page-14-20), [\[37\]](#page-14-17) further require certain matrices to be full rank, which limits the applicability. For example, the mixing matrices commonly used in distributed optimization are typically not full rank. To establish C2, all of these works [\[17\]](#page-14-16)–[\[37\]](#page-14-17) require the term H associated with the final updated primal variable z to be smooth, though they impose no strict conditions on its convexity or the smoothness and convexity of other terms. For

TABLE I: Some Existing ADMMs for Nonconvex Composite Optimization.

<span id="page-2-0"></span>

| Reference      | Objective Function <sup>1</sup>             | Constraint <sup>1</sup> | Smoothness | Assumptions of Matrices <sup>2</sup>                                                                             |  |  |
|----------------|---------------------------------------------|-------------------------|------------|------------------------------------------------------------------------------------------------------------------|--|--|
| [17], [18]     |                                             | x-z=0                   |            |                                                                                                                  |  |  |
| [19]–[21]      |                                             | x - Bz = 0              | Н          | B is full row rank.                                                                                              |  |  |
| [22]           | F(x) + H(z)                                 | Ax + z = c              |            | A is full column rank.                                                                                           |  |  |
| [23], [24]     | F(x) + H(z)                                 | Ax + Bz = c             |            | B is full row or column rank.                                                                                    |  |  |
| [25], [26]     |                                             | Ax + Bz = c             |            | $\operatorname{Im}(A) \cup \{c\} \subseteq \operatorname{Im}(B).$                                                |  |  |
| [27]           |                                             | Ax + Bz = c             |            | $\operatorname{Im}(A) \subset \operatorname{Im}(B)$ and $c \in \operatorname{Im}(B)$ .                           |  |  |
| $[28], [29]^3$ |                                             | x - z = 0               | H          |                                                                                                                  |  |  |
| $[28]^3$       | F(x) + G(x) + H(z)                          | Ax - z = 0              | H          | A is full column rank.                                                                                           |  |  |
| [30]           |                                             | Ax + Bz = c             | H, G       | B is full rank, $Im(A) \subseteq Im(B)$ , $c \in Im(B)$ .                                                        |  |  |
| [31]           | F(x) + G(x, z) + H(z)                       | Ax + Bz = 0             | H, G       | B is full column rank, $\operatorname{Im}(A) \subset \operatorname{Im}(B)$ .                                     |  |  |
| [32]           |                                             | xy - z = 0              |            |                                                                                                                  |  |  |
| [33]           |                                             | $A_1x + A_2y + z = c$   |            | $A_2$ is full column rank.                                                                                       |  |  |
| [34]           | F(x) + G(y) + H(z)                          | $A_1x + A_2y - z = 0$   | H          | $A_1$ and $A_2$ are full column rank.                                                                            |  |  |
| [35]           |                                             | $A_1x + A_2y + Bz = 0$  |            | B is full row rank.                                                                                              |  |  |
| [36]           |                                             | $A_1x + A_2y + Bz = c$  |            | $B \neq \mathbf{O}, \operatorname{Im}(A_1) \cup \operatorname{Im}(A_2) \cup \{c\} \subset \operatorname{Im}(B).$ |  |  |
| [37]           | F(x) + G(y) + H(y, z)                       | x - Bz = 0              | H          | B is full row rank.                                                                                              |  |  |
| This paper     | $F^{0}(x) + F^{1}(x) + H^{0}(z) + H^{1}(z)$ | Ax + Bz = c             | $F^0, H^0$ | $\operatorname{Im}(A) \cup \{c\} \subseteq \operatorname{Im}(B).$                                                |  |  |

<sup>&</sup>lt;sup>1</sup> In this table, z corresponds to the final updated primal variable in these algorithms, while B corresponds to the matrix **B** mentioned in C1. To achieve a more unified representation of optimization problems, separable objective functions are expressed in a compact form, and some symbols used in certain literature have been substituted.

<sup>3</sup> Set constraints of x are replaced with indicator functions G here.

example, H is strongly convex in [36], whereas in [17], [18], [24], [26], [28], [29], [38]–[46], F or G may be convex and nonsmooth, with some of the nonsmooth terms are required to be weakly convex in [46]–[49]. When the proximal operators of these nonsmooth terms are easily computable, closed-form solutions for the subproblems can be obtained; otherwise, overly general assumptions on the objective function may lead to nonconvex and nonsmooth subproblems, making them difficult to solve. When satisfying C1 and C2 simultaneously is infeasible, a two-level algorithm combining ADMM and ALM is proposed in [14]. This method first transforms the original problem into an approximate one via relaxation, then employs an inner ADMM solver, followed by an outer ALM that gradually drives the relaxation coefficient to 0. However, the complex structure and computational demands of this nested-loop structure restrict its practical applicability. In summary, developing a simple and broadly applicable ADMM for general NCOP (1) when C1 and C2 are not satisfied simultaneously remains a valuable research topic.

The works in [17]–[37] share some similarities in their construction and analysis of ADMM for solving NCOPs. Many of these methods enforce strong convexity either by selecting sufficiently large penalty parameters in the augmented Lagrangian [17], [18], [28], [29], or by incorporating additional Bregman distances into the subproblem objective functions. These strong convexity properties [17], [19], [28], [36], along with smoothness assumptions [22], [33], facilitate the construction of monotonically decreasing Lyapunov functions, aiding in the convergence analysis. To further enhance computational efficiency, several works address different aspects of algorithm design. In scenarios involving separable objective functions, [27], [35] a Gauss-Seidel iterative scheme for ADMM, while the algorithms in [17], [28], [31] allow multi-block parallel updates, significantly accelerating computation. To reduce per-iteration complexity, [21], [23]- [26], [30], [31], [37] utilize linear approximations to substitute smooth terms in the objective functions of subproblems, while [19], [35], [36], [50] further integrate Bregman distances. For cases where certain terms in the objective function exhibit convex or concave properties, [32] constructs distinct surrogate functions tailored to these structures. Beyond these structural modifications, many works introduce proximal terms in ADMM subproblems to further improve numerical stability and computational efficiency. Specifically, [20], [21], [23]-[27], [30]-[33], [37] leverage additional proximal terms to avoid matrix inverse computations, reducing overall complexity. In large-scale machine learning applications, stochastic ADMM variants combined with variance reduction techniques, such as SAGA, SVRG, and SPIDER, are explored in [23]-[26], enabling efficient optimization. These methods achieve a sublinear convergence rate of  $\mathcal{O}(1/\sqrt{K})$  to an  $\epsilon$ -stationary point (under Definition 7 provided in this paper) for NCOPs, consistent with the theoretical results in [36]. Moreover, several works provide a refined convergence analysis under the Kurdyka-Łojasiewicz (KL) condition, as demonstrated in [25]–[27], [30], [34], [35], [37], [50], further elucidating the theoretical properties of ADMM in the context of NCOPs.

In addition to ADMM, various other algorithms have been proposed for solving NCOPs. A projected subgradient method for optimization problems with weakly convex objective functions and set constraints is introduced in [47]. The Proximal Gradient Method (PGM) [38]–[40] is another commonly used approach. The algorithm in [38] combines PGM with Polyak's momentum, allowing for inexact solutions in the proximal step. In [39], variance reduction techniques are incorporated into stochastic PGM, achieving linear convergence under the general Polyak-Łojasiewicz (PL) condition. The Proximal Variable Smoothing Gradient (ProxVSG) method in [46] extends the variable smoothing technique of [49], handling nonsmooth weakly convex terms associated with linear opera-

<sup>&</sup>lt;sup>2</sup> For simplicity, only the assumptions related to the matrices in the constraints are retained here.

tors. While [46], [48], [49] employ smooth Moreau envelopes replacing subgradients to approximate these nonsmooth terms, such approximations inevitably introduce inexact solutions. Similar to ADMM, several primal-dual algorithms proposed in [41], [42], [50] are constructed based on Lagrangian, offering flexible update schemes. For example, [50] shares a problem formulation with [31] and also should satisfy both C1 and C2. However, many prior studies [38]–[42], [47], [48] consider relatively simple objective functions with a single primal variable, which limits their applicability to more complex problems. Another class of Proximal Alternating Linearized Minimization (PALM) methods in [51], [52] can also address NCOPs, but they are limited to unconstrained problems.

Most of the aforementioned algorithms for NCOPs are centralized, whereas the algorithms in [17], [18], [28], [29], [40]–[45], [48] support distributed scenarios. The distributed ADMMs in [17], [18], [28], [29] allow nodes to perform asynchronous updates through cyclic or random rules, without waiting for other nodes to complete their updates. However, these methods typically require a star network topology, relying on a central node for control. This dependence introduces the risk of a single point of failure and imposes significant communication and computational burdens on the central node [1]. To address the limitations of centralized coordination, some decentralized optimization methods have been developed. Literature [40] focuses on decentralized PGM in time-varying network scenarios through the introduction of a dynamic mixing matrix. The initial NCOP formulations in [41], [42] only involve terms related to x. However, in constructing these primal-dual algorithms, a proximal term that introduces a new primal variable is incorporated, ensuring strong convexity in the transformed objective functions while facilitating algorithm design and analysis. Literature [43]–[45], [48] investigates decentralized stochastic Proximal Gradient Tracking (PGT) for NCOPs, effectively mitigating the slow convergence rates caused by heterogeneous data distributions. Additionally, the algorithms in [43]–[45] can achieve linear speedup, meaning that increasing the number of agents accelerates the convergence rate. Besides, [42], [48] leverage compression mechanisms to reduce communication within the network. However, these decentralized algorithms [40]-[45] are limited to consensus constraints and assume that the nonsmooth terms in the objective function are convex, without addressing more general cases. Research on decentralized schemes for general NCOPs based on ADMM remains limited.

**Notations:** In this paper, the n-dimensional vector spaces and the  $n \times m$  matrix spaces are symbolized as  $\mathbb{R}^n$  and  $\mathbb{R}^{n \times m}$ , respectively. The  $\ell_1$  norm and  $\ell_2$  norm are represented by  $\|\cdot\|_1$  and  $\|\cdot\|_1$ , respectively. The induced norm associated with a positive semidefinite matrix  $\mathbf{M}$  is denoted as  $\|\cdot\|_{\mathbf{M}} = \sqrt{\langle\cdot,\mathbf{M}\cdot\rangle}$ . The image of matrix  $\mathbf{M}$  is represented as  $\mathrm{Im}(\mathbf{M})$ . The inverse matrix and transpose of  $\mathbf{M}$  are represented by  $\mathbf{M}^{-1}$  and  $\mathbf{M}^{\top}$ , respectively. The null space of  $\mathbf{M}$  is represented by  $\mathrm{Null}(\mathbf{M}) \triangleq \{x \in \mathbb{R}^n | \mathbf{M}x = \mathbf{0}_n\}$ . The linear span of vector v is described as  $\mathrm{Span}(v) \triangleq \{\lambda v | \lambda \in \mathbb{R}\}$ . Additionally,  $\mathbf{M} \succ (\succeq) \mathbf{N}$  indicates that  $\mathbf{M} - \mathbf{N}$  is a positive (semi)-definite matrix. The block diagonal matrix is denoted by  $\mathrm{blkdiag}\{\cdots\}$ . Furthermore,  $\mathbf{0}$  and  $\mathbf{1}$  represent vectors

consisting of all zeros and ones, and  $\mathbf{O}$  and  $\mathbf{I}$  are zero matrix and identity matrix, respectively. The differential operator and subdifferential operator are denoted by  $\nabla$  and  $\partial$ . Besides, define  $\operatorname{dist}(\mathbf{x},\mathcal{C}) = \inf_{\mathbf{y} \in \mathcal{C}} \|\mathbf{x} - \mathbf{y}\|$  for a set  $\mathcal{C} \in \mathbb{R}^n$ .

**Synopsis:** The structure of this paper is outlined below. Firstly, we provide the relevant preliminaries in Section II. Subsequently, we develop PPG-ADMM framework for NCOP (1) in Section III, followed by a detailed convergence analysis in Section IV. In Section V, we solve two practical distributed optimization problems by using PPG-ADMM. The effectiveness of the algorithm is then validated through simulations in Section VI. Finally, our conclusion is presented in Section VII.

#### II. PRELIMINARIES

We provide several definitions and lemmas here which will be utilized in the subsequent analysis.

**Definition 1.** (Weakly Convex): The function  $g: \mathbb{R}^n \to \mathbb{R} \cup \{+\infty\}$  is weakly convex if  $g(\cdot) + \frac{\gamma}{2} \|\cdot\|^2$  is convex with  $\gamma \geqslant 0$ .

Some weakly convex functions can be used as regularization terms in various optimization problems [9], [50]. For instance, the minimax concave penalty (MCP) and the smoothly clipped absolute deviation (SCAD) penalty are often used as alternatives to the  $\ell_1$  norm in machine learning [49] and RPCA [15], as they reduce bias and enhance solution stability. The MCP, which is  $1/\theta$ -weakly convex, is defined as

$$\mathcal{M}_{\eta,\theta}(x) = \begin{cases} \eta |x| - x^2/(2\theta), & |x| \leqslant \theta \eta, \\ \theta \eta^2/2, & \text{otherwise.} \end{cases}$$

The  $1/(\xi - 1)$ -weakly convex SCAD penalty is given by

$$S_{\eta,\xi}(x) = \begin{cases} \eta |x|, & |x| \leq \eta, \\ \frac{2\xi\eta |x| - x^2 - \eta^2}{2(\xi - 1)}, & \eta < |x| \leq \xi\eta, \\ (\xi + 1)\eta^2/2, & |x| > \xi\eta, \end{cases}$$

where  $\theta > 0$ ,  $\xi > 2$  and  $\eta > 0$  are tuning parameters that control the shape of the regularization.

**Definition 2.** (Proximal Operator): Consider a  $\gamma$ -weakly convex function  $g: \mathbb{R}^n \to \mathbb{R} \cup \{+\infty\}$ , for  $x, y \in \mathbb{R}^n$  and  $\tau > \gamma$ , its proximal operator is defined as

$$prox_g^{\tau}(y) = \arg\min_{x} \{g(x) + \frac{\tau}{2} ||x - y||^2\}.$$

The function to be minimized above is strongly convex, ensuring that the corresponding proximal operator is well-defined and unique [46], [49]. The proximal operators of several commonly used nondifferentiable functions are well established. For instance, the proximal operator of  $\ell_1$ -norm corresponds to the soft-thresholding operator, while the proximal operators of MCP and SCAD penalty are given by

$$\mathbf{prox}_{\mathcal{M}_{\eta,\theta}}^{\tau}(x) = \begin{cases} 0, & |x| < \eta/\tau, \\ \frac{\tau\theta x - \mathrm{sign}(x) \cdot \theta\eta}{\tau\theta - 1}, & \eta/\tau \leqslant |x| \leqslant \theta\eta, \\ x, & |x| > \theta\eta, \end{cases}$$

$$\mathbf{prox}_{\mathcal{S}_{\eta,\xi}}^{\tau}(x) = \begin{cases} \operatorname{sign}(x) \cdot (|x| - \eta/\tau)_{+}, & |x| \leqslant (1 + 1/\tau)\eta, \\ \frac{\tau(\xi - 1)x - \operatorname{sign}(x) \cdot \xi\eta}{\tau\xi - \tau - 1}, & (1 + 1/\tau)\eta < |x| \leqslant \xi\eta, \\ x, & |x| > \xi\eta, \end{cases}$$

where  $(|x|-\eta/\tau)_+ = \max\{|x|-\eta/\tau, 0\}$  is the ReLU function.

**Definition 3.** (Subdifferential): For a proper and closed function  $g: \mathbb{R}^n \to \mathbb{R} \cup \{+\infty\}$ . The Fréchet subdifferential  $\hat{\partial}g$  and the limiting subdifferential  $\partial g$  is denoted respectively as

$$\hat{\partial}g(x) = \{v \in \mathbb{R}^n : \lim_{y \to x} \inf_{y \neq x} \frac{g(y) - g(x) - \langle v, y - x \rangle}{\|y - x\|} \geqslant 0\},$$

$$\partial g(x) = \{v \in \mathbb{R}^n : \exists \ x^k \xrightarrow{g} x, v^k \to v \text{ with } v^k \in \hat{\partial}g(x^k)\},$$
where  $x^k \xrightarrow{g} x$  means  $x^k \to x$  and  $g(x^k) \to g(x)$ .

The Fréchet subdifferential set is closed and convex, whereas the limiting subdifferential set is closed [53]. Furthermore, we have  $\hat{\partial}g(x)\subseteq\partial g(x)$ , and if g is convex, then

$$\hat{\partial}g(x) = \partial g(x) = \{v \in \mathbb{R}^n : g(y) - g(x) \geqslant \langle v, y - x \rangle \}.$$

The subdifferential of a convex function is monotone [54], i.e.,

$$\langle v_x - v_y, x - y \rangle \geqslant 0, v_x \in \partial g(x), v_y \in \partial g(y).$$

Further, if g is  $\gamma$ -weakly convex, it further has

<span id="page-4-8"></span>
$$\langle v_x - v_y, x - y \rangle \geqslant -\gamma \|x - y\|^2, v_x \in \partial g(x), v_y \in \partial g(y).$$
 (7) It can be directly deduced by the convexity of  $g(\cdot) + \frac{\gamma}{2} \|\cdot\|^2$ .

**Definition 4.** (Strong Convexity): The function  $g : \mathbb{R}^n \to \mathbb{R}$  is called  $\mu$ -strongly convex with modulus  $\mu > 0$ , for any  $x, y \in \mathbb{R}^n$ , it holds that

$$\langle v_x - v_y, x - y \rangle \geqslant \mu \|x - y\|^2, v_x \in \partial g(x),$$
 (8a)

$$g(x) - g(y) \geqslant \langle v_y, x - y \rangle + \frac{\mu}{2} ||x - y||^2, v_y \in \partial g(y).$$
 (8b)

<span id="page-4-0"></span>**Lemma 1.** [55, Theorem 5.17] The function g is  $\mu$ -strongly convex if and only if  $g(\cdot) - \frac{\mu}{2} \| \cdot \|^2$  is convex.

We can further deduce from Lemma 1 that if f is  $\mu$ -strongly convex and g is  $\gamma$ -weakly convex with  $\mu > \gamma$ , then  $f(\cdot) + g(\cdot) - \frac{\mu - \gamma}{2} \|\cdot\|^2$  will be convex, which implies function f + g is  $(\mu - \gamma)$ -strongly convex.

**Definition 5.** (Coercive Function): The function  $g: \mathbb{R}^n \to \mathbb{R} \cup \{+\infty\}$  is coercive if it satisfies  $\lim_{\|x\|\to +\infty} g(x) = \infty$ .

**Definition 6.** (Smoothness): The function g is differentiable and has gradient Lipschitz continuous with modulus L, i.e.,

$$\|\nabla g(x) - \nabla g(y)\| \le L\|x - y\|, \ \forall x, y \in \mathbb{R}^n.$$

Then, g is called Lipschitz differentiable, or L-smooth.

<span id="page-4-10"></span>**Lemma 2.** [31] Suppose that f(x) is differentiable and g(x) is possibly nondifferentiable. Assume that there exists  $v_1 \in \partial g(x)$ , we have  $v_2 = \nabla f(x) + v_1 \in \partial [f(x) + g(x)]$ .

## III. ALGORITHM DEVELOPMENT

Prior to introducing PPG-ADMM framework for NCOP (1), it is essential to introduce the assumptions made in this paper.

<span id="page-4-1"></span>**Assumption 1.** The matrices in the constraint of (1) satisfy  $Im(\mathbf{A}) \cup \{\mathbf{c}\} \subseteq Im(\mathbf{B})$ .

<span id="page-4-2"></span>**Assumption 2.** The objective function in (1) satisfies:

- <span id="page-4-11"></span>(i) F and H are lower bounded and coercive;
- (ii)  $F^0$  and  $H^0$  are  $L_F$  and  $L_H$ -smooth, respectively;
- (iii)  $F^1$  and  $H^1$  are  $\gamma_F$  and  $\gamma_H$ -weakly convex, respectively, and their proximal operators  $\mathbf{prox}_{F^1}^{\tau}$  and  $\mathbf{prox}_{H^1}^{\tau}$  are easy to obtain for  $\tau > \max\{\gamma_F, \gamma_H\}$ .

Assumption 1 corresponding to C1 is to ensure the feasibility of the optimization problem, and guarantees that when the Gauss-Seidel type algorithm converges to some  $\mathbf{x}^*$  and  $\mathbf{z}^*$ , the constraint  $\mathbf{A}\mathbf{x}^* + \mathbf{B}\mathbf{z}^* = \mathbf{c}$  holds [12], [14], [36]. Assumptions similar to Assumption 2 are commonly found in the relevant literature [12]–[14], [17]–[37], [56], though they may exhibit slight differences. For example, in [12], [31], the coercive function is assumed to be within the feasible set rather than the entire space.

Different from the classical ADMM (2), we propose a perturbed ADMM to handle NCOP (1):

$$\mathbf{x}^{k+1} = \arg\min_{\mathbf{x}} L_{\rho\beta}(\mathbf{x}, \mathbf{z}^k, \boldsymbol{\lambda}^k), \tag{9a}$$

<span id="page-4-6"></span><span id="page-4-5"></span><span id="page-4-3"></span>
$$\mathbf{z}^{k+1} = \arg\min_{\mathbf{z}} L_{\rho\beta}(\mathbf{x}^{k+1}, \mathbf{z}, \boldsymbol{\lambda}^k), \tag{9b}$$

<span id="page-4-4"></span>
$$\lambda^{k+1} = (1 - \rho\beta)\lambda^k - \rho(\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c}), \tag{9c}$$

where  $\beta > 0$  is the perturbation parameter, and satisfies  $\rho\beta \in (0, 1)$ . The perturbed augmented Lagrangian in (9) is

$$L_{\rho\beta}(\mathbf{x}, \mathbf{z}, \boldsymbol{\lambda}) = F(\mathbf{x}) + H(\mathbf{z}) - \langle (1 - \rho\beta)\boldsymbol{\lambda}, \mathbf{A}\mathbf{x} + \mathbf{B}\mathbf{z} - \mathbf{c} \rangle + \frac{\rho}{2} \|\mathbf{A}\mathbf{x} + \mathbf{B}\mathbf{z} - \mathbf{c}\|^2.$$
(10)

We can observe that if  $\beta = 0$ , (9) and (10) reduce to classical ADMM (2) and augmented Lagrangian (3), respectively. However, we set  $\beta > 0$  and its necessity is justified by the subsequent convergence analysis.

<span id="page-4-9"></span><span id="page-4-7"></span>Remark 1. The perturbed dual update (9c) can be interpreted as a dual ascent step derived from a Tikhonov-regularized Lagrangian with  $\beta$ -strong concavity in  $\lambda$  (i.e.,  $L_{\rho}(\mathbf{x}, \mathbf{z}, \lambda) - \frac{\beta}{2} \|\lambda\|^2$ , as in [57], [58]). The negative quadratic term acts as "damping", reducing sensitivity in dual updates and enhancing numerical stability, particularly in ill-conditioned problems or under suboptimal parameter choices. Properly tuning  $\beta$  helps balance the optimality and constraint satisfaction, leading to a smoother convergence, especially when constraints are stringent or the problem structure is complex. To provide a more intuitive illustration, we present a comparative example in Fig. 1, where the inclusion of perturbation term effectively prevents sustained oscillations, leading to faster convergence to a stable solution.

Remark 2. The similar perturbation mechanism also appears in [13], [56]–[59]. As illustrated in [59, Fig.1], such a modification effectively addresses extreme cases where traditional ADMM fails to converge. Specifically, [59] establishes that the perturbed online ADMM achieves linear convergence under strong convexity assumptions, eliminating the differentiability requirement imposed in [60]. While similar perturbation strategies have been employed in primal-dual methods in [13], [56], their formulations are less general than (1) and require the primal variables to be constrained within a compact set.

The ADMM framework is often adapted to suit specific problems and practical requirements. In particular, due to the presence of nonconvex and nonsmooth terms, directly solving subproblems (9a) and (9b) can be challenging. Therefore, transforming these subproblems into more easily solvable forms is crucial to alleviate computational burden.

First, we replace the smooth terms  $F^0(\mathbf{x})$  and  $H^0(\mathbf{z})$  in (9a) and (9b) with their linear approximations, respectively, i.e.,

$$F^{0}(\mathbf{x}) \approx \langle \nabla F^{0}(\hat{\mathbf{x}}^{k}), \mathbf{x} - \mathbf{x}^{k} \rangle + F^{0}(\mathbf{x}^{k}),$$
  

$$H^{0}(\mathbf{z}) \approx \langle \nabla H^{0}(\mathbf{z}^{k}), \mathbf{z} - \mathbf{z}^{k} \rangle + H^{0}(\mathbf{z}^{k}).$$

<span id="page-5-1"></span>![](_page_5_Figure_1.jpeg)

Fig. 1: A simple example demonstrating the impact of  $\beta$  on convergence behavior, where the figure depicts the iteration trajectories of all variable components. In this example, we use (9) to solve the nonsmooth optimization problem  $\min_{\mathbf{x},\mathbf{z}} \|\mathbf{x}\|_1 + \|\mathbf{z}\|_1$ , s.t.  $A\mathbf{x} + B\mathbf{z} = \mathbf{0}$ , where  $\mathbf{x}, \mathbf{z} \in \mathbb{R}^4$ , and  $\mathbf{A}$  and  $\mathbf{B}$  are randomly generated rank-deficient matrices. The optimal solution is  $\mathbf{x}^* = \mathbf{z}^* = \mathbf{0}$ .

A similar strategy is employed in [30], [31], where the penalty terms of the augmented Lagrangian are also replaced with their linear approximations. These approximations can be regarded as special forms of Bregman divergence [61], commonly used in constructing algorithms for both convex and nonconvex optimization.

When solving (9a) and (9b), we can introduce additional proximal terms with respect to  $\mathbf{x}$  and  $\mathbf{z}$ , respectively, i.e.,

 $\frac{1}{2}\|\mathbf{x} - \mathbf{x}^k\|_{\mathbf{P}:=\tau_F\mathbf{I}-\rho\mathbf{A}^\top\mathbf{A}}^2, \quad \frac{1}{2}\|\mathbf{z} - \mathbf{z}^k\|_{\mathbf{Q}:=\tau_H\mathbf{I}-\rho\mathbf{B}^\top\mathbf{B}}^2,$  where  $\mathbf{P}$  and  $\mathbf{Q}$  are both positive definite matrices. These proximal terms help ensure that the updated solutions remain closer to those of the previous iteration, improving numerical stability. Furthermore, they could eliminate the terms  $\frac{\rho}{2}\|\mathbf{A}\mathbf{x}\|^2$  and  $\frac{\rho}{2}\|\mathbf{B}\mathbf{z}\|^2$  in (10), thereby avoiding the potential calculation of  $(\rho\mathbf{A}^\top\mathbf{A})^{-1}$  and  $(\rho\mathbf{B}^\top\mathbf{B})^{-1}$ . This is particularly advantageous when when  $\mathbf{A}^\top\mathbf{A}$  and  $\mathbf{B}^\top\mathbf{B}$  are rank-deficient or of high dimension [17], [20].

**Remark 3.** The design of matrices  $\mathbf{P}$  and  $\mathbf{Q}$  can be more flexible. For instance, following [21], [30], they can be made time-varying to enhance adaptability. Additionally, in decentralized settings, the terms  $\tau_F \mathbf{I}$  and  $\tau_H \mathbf{I}$  can be replaced by positive definite diagonal matrices determined by local agents [3], allowing for greater customization and efficiency.

In fact, the combination of proximal terms with linear approximations can be viewed as an approximate second-order Taylor expansion of  $F^0$  and  $H^0$ . This approach, which involves linearizing the smooth terms and integrating appropriate proximal terms, is commonly referred to as the *Linearization technique* [31], [54]. Then, the updates of primal variables  $\mathbf{x}$  and  $\mathbf{z}$  are transformed as follows:

and 
$$\mathbf{z}$$
 are transformed as follows:  

$$\mathbf{x}^{k+1} = \arg\min_{\mathbf{x}} \left\{ \langle \nabla F^0(\mathbf{x}^k), \mathbf{x} \rangle + F^1(\mathbf{x}) + \frac{\rho}{2} \| \mathbf{A} \mathbf{x} + \mathbf{B} \mathbf{z}^k - \mathbf{c} \|^2 - \langle (1 - \rho \beta) \boldsymbol{\lambda}^k, \mathbf{A} \mathbf{x} + \mathbf{B} \mathbf{z}^k - \mathbf{c} \rangle + \frac{1}{2} \| \mathbf{x} - \mathbf{x}^k \|_{\mathbf{P}}^2 \right\}$$

**Algorithm 1:** PPG-ADMM for (1)

Initialization:  $\mathbf{x}^0$ ,  $\mathbf{z}^0$  and  $\boldsymbol{\lambda}^0$ . Set  $\tau_F \mathbf{I} \succ \rho \mathbf{A}^\top \mathbf{A}$ ,  $\tau_H \mathbf{I} \succ \rho \mathbf{B}^\top \mathbf{B}$ ,  $\tau_F > \gamma_F$ ,  $\tau_H > \gamma_H$  and  $\rho > 0$ ,  $\beta > 0$ ,  $0 < \rho\beta < 1$ . for stopping criteria not satisfied do

Update the primal variable  $\mathbf{x}^{k+1}$  by (13);
Update the primal variable  $\mathbf{z}^{k+1}$  by (14);
Update the dual variable  $\boldsymbol{\lambda}^{k+1}$  by (9c).

end

return  $(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)$ .

<span id="page-5-4"></span>
$$= \arg\min_{\mathbf{x}} \left\{ F^{1}(\mathbf{x}) + \langle \nabla F^{0}(\mathbf{x}^{k}) - \mathbf{P}\mathbf{x}^{k} + \rho \mathbf{A}^{\top} \mathbf{B} \mathbf{z}^{k} \right.$$

$$\left. - \rho \mathbf{A}^{\top} \mathbf{c} - (1 - \rho \beta) \mathbf{A}^{\top} \boldsymbol{\lambda}^{k}, \mathbf{x} \rangle + \frac{\tau_{F}}{2} \|\mathbf{x}\|^{2} \right\}, \qquad (11)$$

$$\mathbf{z}^{k+1} = \arg\min_{\mathbf{z}} \left\{ \langle \nabla H^{0}(\mathbf{z}^{k}), \mathbf{z} \rangle + H^{1}(\mathbf{z}) + \frac{\rho}{2} \|\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z} - \mathbf{c} \|^{2} \right.$$

$$\left. - \langle (1 - \rho \beta) \boldsymbol{\lambda}^{k}, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z} - \mathbf{c} \rangle + \frac{1}{2} \|\mathbf{z} - \mathbf{z}^{k}\|_{\mathbf{Q}}^{2} \right\}$$

$$= \arg\min_{\mathbf{z}} \left\{ H^{1}(\mathbf{z}) + \langle \nabla H^{0}(\mathbf{z}^{k}) + \rho \mathbf{B}^{\top} \mathbf{A}\mathbf{x}^{k+1} - \rho \mathbf{B}^{\top} \mathbf{c} \right.$$

$$\left. - \mathbf{Q}\mathbf{z}^{k} - (1 - \rho \beta) \mathbf{B}^{\top} \boldsymbol{\lambda}^{k}, \mathbf{z} \rangle + \frac{\tau_{H}}{2} \|\mathbf{z}\|^{2} \right\}. \qquad (12)$$

The constant terms related to  $F^0(\mathbf{x}^k)$  and  $H^0(\mathbf{z}^k)$  are omitted above. By introducing the proximal operators, we can further obtain the following updates with closed-form solutions:

<span id="page-5-5"></span><span id="page-5-3"></span><span id="page-5-2"></span>
$$\mathbf{x}^{k+1} = \mathbf{prox}_{F^{1}}^{\tau_{F}} \{ \tau_{F}^{-1} [-\nabla F^{0}(\mathbf{x}^{k}) + (\tau_{F}\mathbf{I} - \rho \mathbf{A}^{\top} \mathbf{A}) \mathbf{x}^{k} - \rho \mathbf{A}^{\top} \mathbf{B} \mathbf{z}^{k} + (1 - \rho \beta) \mathbf{A}^{\top} \boldsymbol{\lambda}^{k} + \rho \mathbf{A}^{\top} \mathbf{c} ] \}, \quad (13)$$

$$\mathbf{z}^{k+1} = \mathbf{prox}_{H^{1}}^{\tau_{H}} \{ \tau_{H}^{-1} [-\nabla H^{0}(\mathbf{z}^{k}) + (\tau_{H}\mathbf{I} - \rho \mathbf{B}^{\top} \mathbf{B}) \mathbf{z}^{k} - \rho \mathbf{B}^{\top} \mathbf{A} \mathbf{x}^{k+1} + (1 - \rho \beta) \mathbf{B}^{\top} \boldsymbol{\lambda}^{k} + \rho \mathbf{B}^{\top} \mathbf{c} ] \}, \quad (14)$$

where  $\tau_F > \gamma_F$  and  $\tau_H > \gamma_H$  should be satisfied. Due to the simultaneous presence of proximal operators and gradient information in (13) and (14), akin to proximal gradient descent method, the algorithm framework presented in this paper is named Perturbed Proximal Gradient ADMM, abbreviated as PPG-ADMM. Further details can be found in Algorithm 1.

**Remark 4.** In [17], [18], [28], [29], the nonsmooth terms are convex, and strong convexity in the subproblems is induced by appropriately tuning the penalty parameters in the augmented Lagrangian. In contrast, in (11) and (12), the strong convexity primarily arises from the added proximal terms.

#### IV. CONVERGENCE ANALYSIS

<span id="page-5-0"></span>In this section, we will analyze the convergence of the proposed PPG-ADMM.

Although the objective problems, constraints, and algorithms differ across existing relevant works [12]–[14], [17]–[37], [56], their convergence analysis frameworks share fundamental similarities. First, a Lyapunov function should be constructed and shown to be both sufficiently decreasing and bounded below. Next, the generated sequence should be proven asymptotically regular and bounded. Finally, it is established that the cluster point of the sequence is (near) the saddle point of the Lagrangian. The key challenge lies in constructing a suitable Lyapunov function, which will be discussed in detail.

Assuming that the term  $H^1 = 0$  in (1), which implies that C2 is satisfied, we analyze (5) to establish (4a). Regarding

the left-hand side (LHS) of (5a), we can directly deduce the following relation by using (2a):

<span id="page-6-3"></span>
$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^k, \boldsymbol{\lambda}^k) - L_{\rho}(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k) \leqslant 0.$$
 (15)

Then, for the LHS of (5b), we can further obtain 
$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k}) - L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}) \tag{16}$$
 
$$= H^{0}(\mathbf{z}^{k+1}) - H^{0}(\mathbf{z}^{k}) - \frac{\rho}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\mathbf{B}^{\top}\mathbf{B}}^{2}$$
 
$$+ \langle \rho \mathbf{B}^{\top}(\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c}) - \mathbf{B}^{\top}\boldsymbol{\lambda}^{k}, \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle$$
 
$$= H^{0}(\mathbf{z}^{k+1}) - H^{0}(\mathbf{z}^{k}) - \langle \nabla H^{0}(\mathbf{z}^{k}), \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle$$
 
$$- \frac{\rho}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\mathbf{B}^{\top}\mathbf{B}}^{2} - \langle \nabla H^{0}(\mathbf{z}^{k+1}) - \nabla H^{0}(\mathbf{z}^{k}), \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle$$
 
$$\leq - \frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\rho \mathbf{B}^{\top}\mathbf{B} - 3L_{H}\mathbf{I}}^{2},$$
 where the last equation is derived from the optimality condi-

<span id="page-6-1"></span>tion of (2b), i.e.,  

$$\nabla H^{0}(\mathbf{z}^{k+1}) = \mathbf{B}^{\top} \boldsymbol{\lambda}^{k} - \rho \mathbf{B}^{\top} (\mathbf{A} \mathbf{x}^{k+1} + \mathbf{B} \mathbf{z}^{k+1} - \mathbf{c})$$

$$\stackrel{(2c)}{=} \mathbf{B}^{\top} \boldsymbol{\lambda}^{k+1}.$$
(17)

while the last inequality relies on the smoothness of  $H^0$ . Subsequently, we demonstrate that both C1 and C2 are related to bounding the term on the right-hand side (RHS) of (5c). In addition to ensuring the feasibility, C1 plays a role in the initial step of bounding  $\|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k\|^2$ . Specifically, through the use of the dual variable update (2c), it can be inferred that  $(\lambda^{k+1} - \lambda^k) \in \text{Im}(\mathbf{B})$ , thereby implying that [12, Lemma 3]

<span id="page-6-0"></span>
$$\|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k\|^2 \leqslant \frac{1}{\sigma_{\mathbf{BB}^\top}^+} \|\mathbf{B}^\top (\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k)\|^2, \tag{18}$$

where  $\sigma_{\mathbf{B}\mathbf{B}^{\top}}^{+}$  denotes the smallest positive eigenvalue of  $\mathbf{B}\mathbf{B}^{\top}$ . Since B may be rank-deficient, it is not necessarily full-rank or an identity matrix. Next, we can use the successive difference of the primal variable z to provide an upper bound for the

$$\|\mathbf{B}^{\top}(\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k})\| \stackrel{\text{(2c)}}{=} \|\rho \mathbf{B}^{\top}(\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c})\|$$

 $\stackrel{(17)}{=} \|\nabla H^0(\mathbf{z}^{k+1}) - \nabla H^0(\mathbf{z}^k)\| \leqslant L_H \|\mathbf{z}^{k+1} - \mathbf{z}^k\|.$ The property of smooth function is used in this inequality. Similar results can be found in [17], [18], [22], [28], [29], [32], [33]. Additionally, as described in [14], as  $k \to \infty$ , the residual  $\|\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c}\|$  may not be eliminated. However, (19) indicates that it can be controlled by  $\|\mathbf{z}^{k+1} - \mathbf{z}^k\|$ , further emphasizing the necessity of C2. Combining (15), (16), (18) and (19), we have

$$L_{\rho}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k+1}) - L_{\rho}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k})$$

$$\leq -\frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\rho \mathbf{B}^{\top} \mathbf{B}}^{2} + (\frac{L_{H}^{2}}{\rho \sigma_{\mathbf{B} \mathbf{B}^{\top}}^{+}} + \frac{3L_{H}}{2}) \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2}.$$

By adjusting  $\rho$ , an appropriate Lyapunov function is obtained. Based on the above analysis, we can infer that if an alternative condition can be established to bound the successive differences of dual variables using the primal variables, C2 can be replaced [13]. Our subsequent analysis reveals that the perturbation mechanism introduced in PPG-ADMM could fulfill this requirement.

Before proceeding with the analysis, we introduce the following function, which incorporates the perturbed augmented Lagrangian (10), two proximal terms from the primal variable updates, and an additional term related to the dual variable:

Similar to (20), the optimality condition for 
$$\mathbf{x}^k$$
 holds:
$$\mathcal{T}(\mathbf{x}, \mathbf{z}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}') = L_{\rho\beta}(\mathbf{x}, \mathbf{z}, \boldsymbol{\lambda}) + \frac{1}{2} \|\mathbf{x} - \mathbf{x}'\|_{\mathbf{P}}^2 + \frac{1}{2} \|\mathbf{z} - \mathbf{z}'\|_{\mathbf{Q}}^2 \quad \text{Similar to (20), the optimality condition for } \mathbf{x}^k \text{ holds:} \\ (\nabla F^0(\mathbf{x}^{k-1}) + \rho \mathbf{A}^\top (\mathbf{A} \mathbf{x}^k + \mathbf{B} \mathbf{z}^{k-1} - \mathbf{c}) - (1 - \rho\beta) \mathbf{A}^\top \boldsymbol{\lambda}^{k-1} \\ - \frac{\beta}{2} (1 - \rho\beta) \|\boldsymbol{\lambda}\|^2. \qquad \qquad + \mathbf{P}(\mathbf{x}^k - \mathbf{x}^{k-1}), \mathbf{x} - \mathbf{x}^k \rangle = -\langle \mathbf{v}_{\mathbf{x}^k}^{F^1}, \mathbf{x} - \mathbf{x}^k \rangle. \tag{24}$$

**Proposition 1.** Function  $\mathcal{T}(\mathbf{x}, \mathbf{z}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}')$  is  $(\tau_F - \gamma_F - L_F)$ strongly convex with respect to **x** and  $(\tau_H - \gamma_H - L_H)$ -strongly convex with respect to z.

<span id="page-6-4"></span>*Proof:* First, we analyze the smooth part of the function  $\mathcal{T}$ with respect to  $\mathbf{x}$ . For any  $\overline{\mathbf{x}}, \underline{\mathbf{x}} \in \mathbb{R}^n$ , it yields the following:

$$\langle \nabla_{\mathbf{x}} [\mathcal{T}(\overline{\mathbf{x}}, \mathbf{z}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}') - F^{1}(\overline{\mathbf{x}})]$$

$$- \nabla_{\mathbf{x}} [\mathcal{T}(\underline{\mathbf{x}}, \mathbf{z}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}') - F^{1}(\underline{\mathbf{x}})], \overline{\mathbf{x}} - \underline{\mathbf{x}} \rangle$$

$$= \langle \nabla F^{0}(\overline{\mathbf{x}}) - \nabla F^{0}(\underline{\mathbf{x}}) + \tau_{F}(\overline{\mathbf{x}} - \underline{\mathbf{x}}), \overline{\mathbf{x}} - \underline{\mathbf{x}} \rangle \geqslant (\tau_{F} - L_{F}) ||\overline{\mathbf{x}} - \underline{\mathbf{x}}||^{2},$$

where  $\mathbf{P} = \tau_F \mathbf{I} - \rho \mathbf{A}^{\top} \mathbf{A}$  is used in the equation, and the last inequality holds due to the assumption that  $F^0$  is  $L_F$ -smooth. By using (8a), it can be inferred that  $\mathcal{T}(\mathbf{x}, \mathbf{z}, \lambda, \mathbf{x}', \mathbf{z}') - F^1(\mathbf{x})$ is  $(\tau_F - L_F)$ -strongly convex with respect to x. Furthermore, since  $F^1(\mathbf{x})$  is  $\gamma_F$ -weakly convex, it follows that  $\mathcal{T}$ is  $(\tau_F - \gamma_F - L_F)$ -strongly convex with respect to x. In a similar manner, we can obtain the result about z:

$$\begin{split} &\langle \nabla_{\mathbf{z}} [\mathcal{T}(\mathbf{x}, \overline{\mathbf{z}}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}') - H^1(\overline{\mathbf{z}})] \\ &- \nabla_{\mathbf{z}} [\mathcal{T}(\mathbf{x}, \underline{\mathbf{z}}, \boldsymbol{\lambda}, \mathbf{x}', \mathbf{z}') - H^1(\underline{\mathbf{z}})], \overline{\mathbf{z}} - \underline{\mathbf{z}} \rangle \\ = &\langle \nabla H^0(\overline{\mathbf{z}}) - \nabla H^0(\underline{\mathbf{z}}) + \tau_H(\overline{\mathbf{z}} - \underline{\mathbf{z}}), \overline{\mathbf{z}} - \underline{\mathbf{z}} \rangle \geqslant (\tau_H - L_H) \|\overline{\mathbf{z}} - \underline{\mathbf{z}}\|^2, \\ \text{where any } \overline{\mathbf{z}}, \underline{\mathbf{z}} \in \mathbb{R}^m. \text{ Similar to the analysis of } \mathbf{x}, \text{ we can deduce that the function } \mathcal{T} \text{ is } (\tau_H - \gamma_H - L_H) \text{-strongly convex with respect to } \mathbf{z}. \end{split}$$

The optimality conditions for (11), (12) are frequently used:

<span id="page-6-5"></span>
$$\nabla F^{0}(\mathbf{x}^{k}) + \mathbf{v}_{\mathbf{x}^{k+1}}^{F^{1}} + \rho \mathbf{A}^{\top} (\mathbf{A} \mathbf{x}^{k+1} + \mathbf{B} \mathbf{z}^{k} - \mathbf{c}) - (1 - \rho \beta) \mathbf{A}^{\top} \lambda^{k} + \mathbf{P} (\mathbf{x}^{k+1} - \mathbf{x}^{k}) = \mathbf{0},$$
(20)

<span id="page-6-9"></span>
$$\nabla H^{0}(\mathbf{z}^{k}) + \mathbf{v}_{\mathbf{z}^{k+1}}^{H^{1}} + \rho \mathbf{B}^{\top} (\mathbf{A} \mathbf{x}^{k+1} + \mathbf{B} \mathbf{z}^{k+1} - \mathbf{c})$$

$$- (1 - \rho \beta) \mathbf{B}^{\top} \boldsymbol{\lambda}^{k} + \mathbf{Q} (\mathbf{z}^{k+1} - \mathbf{z}^{k}) = \mathbf{0},$$
(21)

<span id="page-6-2"></span>where the subgradients  $\mathbf{v}_{\mathbf{x}^{k+1}}^{F^1} \in \partial F^1(\mathbf{x}^{k+1})$  and  $\mathbf{v}_{\mathbf{z}^{k+1}}^{H^1} \in$  $\partial H^1(\mathbf{z}^{k+1})$ . Based on the updates in Algorithm 1, we can derive the following relationship between the successive differences of different variables.

**Proposition 2.** Suppose that Assumptions 1, 2 hold and let sequence  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k \geq 0}$  be the sequence generated by Algorithm 1. For  $k \ge 1$ , the following inequality holds:

<span id="page-6-8"></span>
$$\|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{L_{F}\mathbf{I}+\mathbf{P}}^{2} - \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|_{L_{F}\mathbf{I}+\mathbf{P}}^{2}$$

$$+ \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{L_{H}\mathbf{I}+\mathbf{Q}+2\rho\mathbf{B}^{\top}\mathbf{B}}^{2} - \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{L_{H}\mathbf{I}+\mathbf{Q}+2\rho\mathbf{B}^{\top}\mathbf{B}}^{2}$$

$$+ \frac{1 - \rho\beta}{\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2} - \frac{1 - \rho\beta}{\rho} \|\boldsymbol{\lambda}^{k} - \boldsymbol{\lambda}^{k-1}\|^{2} \qquad (22)$$

$$\leq \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{2(L_{F}+\gamma_{F})\mathbf{I}+\rho\mathbf{A}^{\top}\mathbf{A}}^{2}$$

$$+ \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{2(L_{H}+\gamma_{H})\mathbf{I}+4\rho\mathbf{B}^{\top}\mathbf{B}}^{2} - 2\beta \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2}.$$

$$Proof: \text{ First, the inner product of (20) and } \mathbf{x} - \mathbf{x}^{k+1} \text{ is }$$

$$\langle \nabla F^{0}(\mathbf{x}^{k}) + \rho \mathbf{A}^{\top}(\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k} - \mathbf{c})$$

$$- (1 - \rho\beta)\mathbf{A}^{\top}\boldsymbol{\lambda}^{k} + \mathbf{P}(\mathbf{x}^{k+1} - \mathbf{x}^{k}), \mathbf{x} - \mathbf{x}^{k+1}\rangle$$

$$\stackrel{(9c)}{=} \langle \nabla F^{0}(\mathbf{x}^{k}) - \rho \mathbf{A}^{\top}\mathbf{B}(\mathbf{z}^{k+1} - \mathbf{z}^{k}) + \mathbf{P}(\mathbf{x}^{k+1} - \mathbf{x}^{k})$$

$$- \mathbf{A}^{\top}\boldsymbol{\lambda}^{k+1}, \mathbf{x} - \mathbf{x}^{k+1}\rangle = -\langle \mathbf{v}_{\mathbf{x}^{k+1}}^{F_{1}}, \mathbf{x} - \mathbf{x}^{k+1}\rangle. \tag{23}$$

Similar to (20), the optimality condition for  $x^k$  holds:

<span id="page-6-7"></span><span id="page-6-6"></span>
$$\langle \nabla F^{0}(\mathbf{x}^{k-1}) + \rho \mathbf{A}^{\top} (\mathbf{A} \mathbf{x}^{k} + \mathbf{B} \mathbf{z}^{k-1} - \mathbf{c}) - (1 - \rho \beta) \mathbf{A}^{\top} \boldsymbol{\lambda}^{k-1} + \mathbf{P}(\mathbf{x}^{k} - \mathbf{x}^{k-1}), \mathbf{x} - \mathbf{x}^{k} \rangle = -\langle \mathbf{v}_{\mathbf{x}^{k}}^{F^{1}}, \mathbf{x} - \mathbf{x}^{k} \rangle.$$
(24)

By substituting  $\mathbf{x} = \mathbf{x}^k$  into (23) and  $\mathbf{x} = \mathbf{x}^{k+1}$  into (24), and subsequently adding them together, we obtain

$$\begin{aligned} &\langle \mathbf{x}^k - \mathbf{x}^{k+1}, \nabla F^0(\mathbf{x}^k) - \nabla F^0(\mathbf{x}^{k-1}) \rangle \\ &+ \langle \mathbf{x}^k - \mathbf{x}^{k+1}, -\rho \mathbf{A}^\top \mathbf{B}[(\mathbf{z}^{k+1} - \mathbf{z}^k) - (\mathbf{z}^k - \mathbf{z}^{k-1})] \rangle \\ &+ \langle \mathbf{x}^k - \mathbf{x}^{k+1}, \mathbf{P}[(\mathbf{x}^{k+1} - \mathbf{x}^k) - (\mathbf{x}^k - \mathbf{x}^{k-1})] \rangle \\ &+ \langle \mathbf{x}^k - \mathbf{x}^{k+1}, -\mathbf{A}^\top (\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k) \rangle \end{aligned}$$

 $=\langle \mathbf{v}_{\mathbf{x}^{k+1}}^{F^1} - \mathbf{v}_{\mathbf{x}^k}^{F^1}, \mathbf{x}^{k+1} - \mathbf{x}^k \rangle \stackrel{(7)}{\geqslant} -\gamma_F \|\mathbf{x}^{k+1} - \mathbf{x}^k\|^2$ , (25) where the inequality holds due to the weakly convexity of the function  $F^1$ . Next, we will analyze each term in the LHS of (25) in detail. The first term satisfies

$$\langle \mathbf{x}^{k} - \mathbf{x}^{k+1}, \nabla F^{0}(\mathbf{x}^{k}) - \nabla F^{0}(\mathbf{x}^{k-1}) \rangle$$

$$\leq \frac{L_{F}}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2} + \frac{1}{2L_{F}} \|\nabla F^{0}(\mathbf{x}^{k}) - \nabla F^{0}(\mathbf{x}^{k-1})\|^{2}$$

$$\leq \frac{L_{F}}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2} + \frac{L_{F}}{2} \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|^{2}, \tag{26}$$

where the first inequality holds due to Young's inequality, while the second inequality arises from the smoothness assumption in Assumption 2. Similarly, by applying Young's inequality to the second term of (25), we can deduce that  $\langle \mathbf{x}^k - \mathbf{x}^{k+1}, -\rho \mathbf{A}^{\top} \mathbf{B}[(\mathbf{z}^{k+1} - \mathbf{z}^k) - (\mathbf{z}^k - \mathbf{z}^{k-1})]$  (27)

$$\langle \mathbf{x}^{k} - \mathbf{x}^{k+1}, -\rho \mathbf{A}^{\mathsf{T}} \mathbf{B}[(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})]$$
(27)
$$\leq \frac{1}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{\rho \mathbf{A}^{\mathsf{T}} \mathbf{A}}^{2} + \frac{1}{2} \|(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})\|_{\rho \mathbf{B}^{\mathsf{T}} \mathbf{B}}^{2}$$

$$\leq \frac{1}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{\rho \mathbf{A}^{\mathsf{T}} \mathbf{A}}^{2} + \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\rho \mathbf{B}^{\mathsf{T}} \mathbf{B}}^{2} + \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\rho \mathbf{B}^{\mathsf{T}} \mathbf{B}}^{2}.$$
By using the equation  $\langle -x, x - y \rangle = -\frac{1}{2} (\|x - y\|^{2} + \|x\|^{2} - \|y\|^{2})$ , the third term of (25) can be transformed into  $\langle \mathbf{x}^{k} - \mathbf{x}^{k+1}, \mathbf{P}[(\mathbf{x}^{k+1} - \mathbf{x}^{k}) - (\mathbf{x}^{k} - \mathbf{x}^{k-1})] \rangle$ 

$$= -\frac{1}{2} \| (\mathbf{x}^{k+1} - \mathbf{x}^k) - (\mathbf{x}^k - \mathbf{x}^{k-1}) \|_{\mathbf{P}}^2 - \frac{1}{2} \| \mathbf{x}^{k+1} - \mathbf{x}^k \|_{\mathbf{P}}^2 + \frac{1}{2} \| \mathbf{x}^k - \mathbf{x}^{k-1} \|_{\mathbf{P}}^2.$$
(28)

The last term of (25) will be analyzed together with the subsequent results. We continue the analysis from the optimality conditions with respect to  $\mathbf{z}^{k+1}$  and  $\mathbf{z}^k$ . By following a similar analysis process as (23) and (24), we can obtain

$$\langle \nabla H^{0}(\mathbf{z}^{k}) + \rho \mathbf{B}^{\top}(\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c}) \\ - (1 - \rho\beta)\mathbf{B}^{\top}\boldsymbol{\lambda}^{k} + \mathbf{Q}(\mathbf{z}^{k+1} - \mathbf{z}^{k}), \mathbf{z} - \mathbf{z}^{k+1} \rangle$$

$$\stackrel{(9c)}{=} \langle \nabla H^{0}(\mathbf{z}^{k}) - \mathbf{B}^{\top}\boldsymbol{\lambda}^{k+1} + \mathbf{Q}(\mathbf{z}^{k+1} - \mathbf{z}^{k}), \mathbf{z} - \mathbf{z}^{k+1} \rangle$$

$$= -\langle \mathbf{v}_{\mathbf{z}^{k+1}}^{H^{1}}, \mathbf{z} - \mathbf{z}^{k+1} \rangle, \qquad (29)$$

$$\langle \nabla H^{0}(\mathbf{z}^{k-1}) + \rho \mathbf{B}^{\top}(\mathbf{A}\mathbf{x}^{k} + \mathbf{B}\mathbf{z}^{k} - \mathbf{c}) - (1 - \rho\beta)\mathbf{B}^{\top}\boldsymbol{\lambda}^{k-1}$$

$$+ \mathbf{Q}(\mathbf{z}^{k} - \mathbf{z}^{k-1}), \mathbf{z} - \mathbf{z}^{k} \rangle = -\langle \mathbf{v}_{\mathbf{z}^{k}}^{H^{1}}, \mathbf{z} - \mathbf{z}^{k} \rangle. \qquad (30)$$
Similar to the previous analysis, we can set  $\mathbf{z} = \mathbf{z}^{k}$  and  $\mathbf{z} = \mathbf{z}^{k+1}$  in (29) and (30), respectively, and add them together, which yields a result similar to (25):

which yields a result similar to (25):
$$\langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, \nabla H^{0}(\mathbf{z}^{k}) - \nabla H^{0}(\mathbf{z}^{k-1}) \rangle$$

$$+ \langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, \mathbf{Q}[(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})] \rangle$$

$$+ \langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, \mathbf{Q}[(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})] \rangle$$

$$+ \langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, -\mathbf{B}^{\top} (\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}) \rangle$$

$$= \langle \mathbf{v}_{\mathbf{z}^{k+1}}^{H^{1}} - \mathbf{v}_{\mathbf{z}^{k}}^{H^{1}}, \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle \geqslant -\gamma_{H} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2}. \quad (31)$$
Similar to (26) and (28), we can respectively obtain
$$\langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, \nabla H^{0}(\mathbf{z}^{k}) - \nabla H^{0}(\mathbf{z}^{k-1}) \rangle$$

$$\leq \frac{L_{H}}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2} + \frac{1}{2L_{H}} \|\nabla H^{0}(\mathbf{z}^{k}) - \nabla H^{0}(\mathbf{z}^{k-1})\|^{2}$$

$$\leq \frac{L_{H}}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2} + \frac{L_{H}}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|^{2}, \quad (32)$$

$$\langle \mathbf{z}^{k} - \mathbf{z}^{k+1}, \mathbf{Q}[(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})] \rangle$$

$$= -\frac{1}{2} \|(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})\|_{\mathbf{Q}}^{2} - \frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{\mathbf{Q}}^{2}$$

$$+ \frac{1}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\mathbf{Q}}^{2}.$$
(33)

Combine the last terms on the LHS of (25) and (31), we have

<span id="page-7-0"></span>
$$\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}, (\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1}) - (\mathbf{A}\mathbf{x}^{k} + \mathbf{B}\mathbf{z}^{k}) \rangle$$

$$\stackrel{(9c)}{=} -\frac{1}{\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2} + \frac{1 - \rho\beta}{\rho} \langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}, \boldsymbol{\lambda}^{k} - \boldsymbol{\lambda}^{k-1} \rangle$$

$$= \frac{1 - \rho\beta}{2\rho} \|\boldsymbol{\lambda}^{k} - \boldsymbol{\lambda}^{k-1}\|^{2} - \frac{1 + \rho\beta}{2\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2}$$

$$- \frac{1 - \rho\beta}{2\rho} \|(\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}) - (\boldsymbol{\lambda}^{k} - \boldsymbol{\lambda}^{k-1})\|^{2}. \tag{34}$$

<span id="page-7-6"></span><span id="page-7-3"></span>Finally, by combining (25)-(28), (31)-(34) and omitting the non-positive terms on the RHS, (22) can be obtained.

From the above proof, we can observe that (31) lacks the term corresponding to (27) in (25), despite being constructed in a similar way by using optimality conditions for updating variables  $\mathbf{x}$  and  $\mathbf{z}$ . This discrepancy arises from the sequential updating of the primal variables.

<span id="page-7-7"></span>Next, we obtain the successive difference of function  $\mathcal{T}$  with respect to  $\boldsymbol{\omega}^{k+1} := [\mathbf{x}^{k+1}; \mathbf{z}^{k+1}; \boldsymbol{\lambda}^{k+1}; \mathbf{x}^k; \mathbf{z}^k]$  generated by PPG-ADMM.

**Proposition 3.** Suppose that Assumptions 1, 2 hold and let  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k \geq 0}$  be the sequence generated by Algorithm 1. For  $k \geq 1$ ,  $\mathcal{T}(\boldsymbol{\omega}^{k+1})$  and  $\mathcal{T}(\boldsymbol{\omega}^k)$  have the following relation:

<span id="page-7-10"></span><span id="page-7-4"></span>
$$\mathcal{T}(\boldsymbol{\omega}^{k+1}) - \mathcal{T}(\boldsymbol{\omega}^{k}) \leqslant -\frac{\tau_{F} - \gamma_{F} - 3L_{F}}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2}$$
$$-\frac{1}{2} \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|_{\mathbf{P}}^{2} - \frac{\tau_{H} - \gamma_{H} - 3L_{H}}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|^{2}$$
$$-\frac{1}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\mathbf{Q}}^{2} + \frac{(1 - \rho\beta)(2 - \rho\beta)}{2\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2}. \quad (35)$$

*Proof:* By utilizing the strong convexity with respect to  $\mathbf{x}$  of  $\mathcal{T}$ , we can obtain

<span id="page-7-8"></span><span id="page-7-2"></span><span id="page-7-1"></span>
$$\mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k}) - \mathcal{T}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k})$$
(36)
$$\stackrel{\text{(8b)}}{\leqslant} \langle \mathbf{v}_{\mathbf{x}^{k+1}}^{\mathcal{T}}, \mathbf{x}^{k+1} - \mathbf{x}^{k} \rangle - \frac{\tau_{F} - \gamma_{F} - L_{F}}{2} \| \mathbf{x}^{k+1} - \mathbf{x}^{k} \|^{2}$$

$$= \langle \nabla F^{0}(\mathbf{x}^{k+1}) + \mathbf{v}_{\mathbf{x}^{k+1}}^{F^{1}} - (1 - \rho\beta) \mathbf{A}^{\mathsf{T}} \boldsymbol{\lambda}^{k} + \mathbf{P}(\mathbf{x}^{k+1} - \mathbf{x}^{k})$$

$$+ \rho \mathbf{A}^{\mathsf{T}} (\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k} - \mathbf{c}), \mathbf{x}^{k+1} - \mathbf{x}^{k} \rangle$$

$$- \frac{\tau_{F} - \gamma_{F} - L_{F}}{2} \| \mathbf{x}^{k+1} - \mathbf{x}^{k} \|^{2}$$

$$\stackrel{(20)}{=} \langle \nabla F^{0}(\mathbf{x}^{k+1}) - \nabla F^{0}(\mathbf{x}^{k}), \mathbf{x}^{k+1} - \mathbf{x}^{k} \rangle$$

$$- \frac{\tau_{F} - \gamma_{F} - L_{F}}{2} \| \mathbf{x}^{k+1} - \mathbf{x}^{k} \|^{2} \leqslant - \frac{\tau_{F} - \gamma_{F} - 3L_{F}}{2} \| \mathbf{x}^{k+1} - \mathbf{x}^{k} \|^{2},$$

where  $\mathbf{v}_{\mathbf{x}^{k+1}}^{\mathcal{T}} \in \partial_{\mathbf{x}} \mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k})$ . The first equation in (36) holds due to Lemma 2. Similarly, we can obtain the result for  $\mathbf{z}$ :

<span id="page-7-9"></span><span id="page-7-5"></span>
$$\mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k}) - \mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k}) \tag{37}$$

$$\stackrel{\text{(8b)}}{\leqslant} \langle \mathbf{v}_{\mathbf{z}^{k+1}}^{\mathcal{T}}, \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle - \frac{\tau_{H} - \gamma_{H} - L_{H}}{2} \| \mathbf{z}^{k+1} - \mathbf{z}^{k} \|^{2}$$

$$\stackrel{\text{(21)}}{=} \langle \nabla H^{0}(\mathbf{z}^{k+1}) - \nabla H^{0}(\mathbf{z}^{k}), \mathbf{z}^{k+1} - \mathbf{z}^{k} \rangle$$

$$- \frac{\tau_{H} - \gamma_{H} - L_{H}}{2} \| \mathbf{z}^{k+1} - \mathbf{z}^{k} \|^{2} \leqslant - \frac{\tau_{H} - \gamma_{H} - 3L_{H}}{2} \| \mathbf{z}^{k+1} - \mathbf{z}^{k} \|^{2},$$

where  $\mathbf{v}_{\mathbf{z}^{k+1}}^{\mathcal{T}} \in \partial_{\mathbf{z}} \mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^k, \mathbf{x}^k, \mathbf{z}^k)$ . Next, we focus

on the dual variable 
$$\lambda$$
:
$$\mathcal{T}(\boldsymbol{\omega}^{k+1}) - \mathcal{T}(\mathbf{x}^{k+1}, \mathbf{z}^{k+1}, \boldsymbol{\lambda}^k, \mathbf{x}^k, \mathbf{z}^k)$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$
bounds except for  $-\langle (1 - \rho\beta)\boldsymbol{\lambda}^{k+1}, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$ 

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

$$= -(1 - \rho\beta)[\langle \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} \rangle + \frac{\beta}{2} \|\boldsymbol{\lambda}^{k+1}\|^2$$

The last equation is derived from (9c) and  $\langle x, x-y\rangle=\frac{1}{2}(\|x-y\|^2+\|x\|^2-\|y\|^2)$ . Finally, for the last two parameters of  $\mathcal{T}$ , we have

$$\mathcal{T}(\mathbf{x}^{k}, \mathbf{z}^{k}, \boldsymbol{\lambda}^{k}, \mathbf{x}^{k}, \mathbf{z}^{k}) - \mathcal{T}(\boldsymbol{\omega}^{k})$$

$$= -\frac{1}{2} \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|_{\mathbf{P}}^{2} - \frac{1}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\mathbf{Q}}^{2}.$$
 (39)

A new function  $\mathcal{P}$  is composed of  $\mathcal{T}$  and three terms on the LHS of (22):

$$\mathcal{P}(\boldsymbol{\omega}^{k+1}) = \mathcal{T}(\boldsymbol{\omega}^{k+1}) + d \left[ \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{L_{F}\mathbf{I} + \mathbf{P}}^{2} + \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{L_{H}\mathbf{I} + \mathbf{Q} + 2\rho \mathbf{B}^{T}\mathbf{B}}^{2} + \frac{1 - \rho\beta}{\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2} \right],$$

where d > 0 is an adjustable coefficient. Since both matrices **P** and **Q** are positive definite, and  $\rho, L_F, L_H > 0$ , it follows that  $L_F \mathbf{I} + \mathbf{P}$  and  $L_H \mathbf{I} + \mathbf{Q} + 2\rho \mathbf{B}^{\top} \mathbf{B}$  are also positive definite matrices. We make the following assumption about the coefficients in function  $\mathcal{P}$ .

<span id="page-8-7"></span>**Assumption 3.** The coefficients in the Lyapunov function  $\mathcal{P}$ need to satisfy

$$\tau_F \mathbf{I} \succ 2d\rho \mathbf{A}^{\top} \mathbf{A} + [(4d+3)L_F + (4d+1)\gamma_F]\mathbf{I}, \qquad (40a)$$

$$\tau_H \mathbf{I} \succ 8d\rho \mathbf{B}^{\top} \mathbf{B} + [(4d+3)L_H + (4d+1)\gamma_H]\mathbf{I},$$
 (40b)

$$d > \frac{(1 - \rho\beta)(2 - \rho\beta)}{4\rho\beta} > 0, \tag{40c}$$

$$\rho > 0, \ \beta > 0, \ 0 < \rho\beta < 1,$$
(40d)

$$\tau_F \mathbf{I} \succ \rho \mathbf{A}^{\top} \mathbf{A}, \ \tau_H \mathbf{I} \succ \rho \mathbf{B}^{\top} \mathbf{B}, \ \tau_F > \gamma_F, \ \tau_H > \gamma_H.$$
 (40e)

Note that (40d) and (40e) have already been assumed in the development of algorithm. Since  $\tau_F$ ,  $\tau_H$  and d are optional parameters, (40a), (40b) and (40c) can be easily satisfied.

<span id="page-8-12"></span>**Theorem 1.** Suppose that Assumptions 1, 2, 3 hold and let  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k \geq 0}$  be the sequence generated by Algorithm 1. Then, the function P is

- (i) sufficiently decreasing for {ω<sup>k+1</sup>}<sub>k≥0</sub>;
  (ii) bounded from below, i.e., ∃ <u>P</u>, P(ω<sup>k+1</sup>) > <u>P</u>.

Proof: (i) By combining (22) and (35), we can obtain the following relationship between  $\mathcal{P}(\boldsymbol{\omega}^{k+1})$  and  $\mathcal{P}(\boldsymbol{\omega}^k)$ :

$$\mathcal{P}(\boldsymbol{\omega}^{k+1}) - \mathcal{P}(\boldsymbol{\omega}^{k})$$

$$\leq -\frac{1}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{[\tau_{F} - (4d+1)\gamma_{F} - (4d+3)L_{F}]\mathbf{I} - 2d\rho\mathbf{A}^{T}\mathbf{A}}$$

$$-\frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{[\tau_{H} - (4d+1)\gamma_{H} - (4d+3)L_{H}]\mathbf{I} - 8d\rho\mathbf{B}^{T}\mathbf{B}}$$

$$-\frac{1}{2} \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|_{\mathbf{P}}^{2} - \frac{1}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\mathbf{Q}}^{2}$$

$$-\left[2d\beta - \frac{(1 - \rho\beta)(2 - \rho\beta)}{2\rho}\right] \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2}. \tag{41}$$

Note that the conditions (40a), (40b) and (40c) in Assumption 3 are used to ensure that all terms on the RHS of (41) are negative. Therefore, (i) is proved.

<span id="page-8-0"></span>(ii) By Assumption 2 (i), all terms in  $\mathcal{P}(\boldsymbol{\omega}^{k+1})$  have lower bounds except for  $-\langle (1-\rho\beta)\lambda^{k+1}, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} + \mathbf{c} \rangle$  $\frac{\beta}{2}\lambda^{k+1}$ , whose lower bound will be shown in the remaining

<span id="page-8-9"></span>
$$-\langle (1-\rho\beta)\boldsymbol{\lambda}^{k+1}, \mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c} + \frac{\beta}{2}\boldsymbol{\lambda}^{k+1} \rangle$$

$$\stackrel{(9c)}{=} \frac{(1-\rho\beta)^{2}}{\rho} \langle \boldsymbol{\lambda}^{k+1}, \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k} \rangle + \frac{\beta(1-\rho\beta)}{2} \|\boldsymbol{\lambda}^{k+1}\|^{2}$$

$$= \frac{(1-\rho\beta)^{2}}{2\rho} \left[ \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2} + \|\boldsymbol{\lambda}^{k+1}\|^{2} - \|\boldsymbol{\lambda}^{k}\|^{2} \right]$$

$$+ \frac{\beta(1-\rho\beta)}{2} \|\boldsymbol{\lambda}^{k+1}\|^{2}. \tag{42}$$

<span id="page-8-1"></span>The last equation holds by using  $\langle x, x - y \rangle = \frac{1}{2} (\|x - y\|^2 + \|x - y\|^2)$  $\|x\|^2 - \|y\|^2$ ). Summing  $\mathcal{P}(\omega^{k+1})$  over K iterations and substituting (42), we have

<span id="page-8-10"></span>
$$\sum_{k=0}^{K} \mathcal{P}(\boldsymbol{\omega}^{k+1}) \geqslant \sum_{k=0}^{K} F(\mathbf{x}^{k}) + \sum_{k=0}^{K} H(\mathbf{z}^{k}) - \frac{(1-\rho\beta)^{2}}{2\rho} \|\boldsymbol{\lambda}^{0}\|^{2}.$$
(43)

The positive terms in the right side have been omitted in (43). Since Assumption 2 (i) states that both F and H have lower bounds, and  $\lambda^0$  is an adjustable initial value, it follows that (43) is lower bounded by a finite value. Therefore, we can infer that  $\mathcal{P}$  is bounded from below.

<span id="page-8-6"></span><span id="page-8-5"></span><span id="page-8-4"></span>The condition  $\beta \neq 0$  is emphasized again by (41). Specifically, if  $\beta = 0$ , the coefficient in front of the last term on the RHS of (41) becomes a positive constant  $1/\rho$  (similar to the situation in (5c)). This coefficient cannot be made negative by adjusting d. In this scenario, where C1 and C2 cannot hold simultaneously, it becomes nearly impossible to construct a suitable Lyapunov function without introducing additional assumptions. However, if we relax the assumptions on the objective function to satisfy C2 for PPG-ADMM, the following corollary remains valid even when  $\beta = 0$ .

<span id="page-8-13"></span><span id="page-8-3"></span><span id="page-8-2"></span>**Corollary 1.** Suppose that Assumptions 1, 2 hold,  $H^1 = 0$  in the objective function and the relevant coefficients satisfy

<span id="page-8-11"></span>
$$\tau_F - \gamma_F > 3L_F,\tag{44a}$$

$$(\tau_H - \gamma_H - 3L_H)\rho\sigma_{\mathbf{B}\mathbf{B}^\top}^+\mathbf{I} \succ 4(1-\rho\beta)(2-\rho\beta)\mathbf{Q}^\top\mathbf{Q}, \quad (44b)$$

$$\rho \sigma_{\mathbf{B} \mathbf{B}^{\top}}^{+} \mathbf{Q} \succ 4(1 - \rho \beta)(2 - \rho \beta)(\mathbf{Q}^{\top} \mathbf{Q} + L_{H} \mathbf{I}/2),$$
 (44c)

and (40d), (40e), for the sequence  $\{\omega^{k+1}\}_{k\geqslant 0}$  and any  $\beta\geqslant 0$ , T is sufficiently decreasing and bounded from below.

Proof: By subtracting (29) from (30), we obtain:

$$\begin{split} &\mathbf{B}^{\top}(\boldsymbol{\lambda}^{k+1}-\boldsymbol{\lambda}^{k})\\ = &\nabla H^{0}(\mathbf{z}^{k}) - \nabla H^{0}(\mathbf{z}^{k-1}) + \mathbf{Q}(\mathbf{z}^{k+1}-\mathbf{z}^{k}) - \mathbf{Q}(\mathbf{z}^{k}-\mathbf{z}^{k-1}). \end{split}$$

Further, it can be deduced that

<span id="page-8-8"></span>
$$\begin{split} & \sigma_{\mathbf{B}\mathbf{B}^{\top}}^{+} \| \boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k} \|^{2} \overset{(18)}{\leqslant} \| \mathbf{B}^{\top} (\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}) \|^{2} \\ & \leqslant 2 \| \nabla H^{0}(\mathbf{z}^{k}) - \nabla H^{0}(\mathbf{z}^{k-1}) \|^{2} + 2 \| \mathbf{Q} [(\mathbf{z}^{k+1} - \mathbf{z}^{k}) - (\mathbf{z}^{k} - \mathbf{z}^{k-1})] \|^{2} \\ & \leqslant 4 \| \mathbf{z}^{k+1} - \mathbf{z}^{k} \|_{\mathbf{Q}^{\top}\mathbf{Q}}^{2} + 4 \| \mathbf{z}^{k} - \mathbf{z}^{k-1} \|_{\mathbf{Q}^{\top}\mathbf{Q} + L_{H}\mathbf{I}/2}^{2}. \end{split}$$

The derivation of these two equations is similar to that of the previous (17)-(19). Substituting them into (35), we can obtain another relationship involving the function  $\mathcal{T}$ :

Lyapunov function, and  $\beta$  can be set to 0.

$$\mathcal{T}(\boldsymbol{\omega}^{k+1}) - \mathcal{T}(\boldsymbol{\omega}^{k}) \tag{45}$$

$$\leq -\frac{\tau_{F} - \gamma_{F} - 3L_{F}}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|^{2} - \frac{1}{2} \|\mathbf{x}^{k} - \mathbf{x}^{k-1}\|_{\mathbf{P}}^{2}$$

$$-\frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{(\tau_{H} - \gamma_{H} - 3L_{H})\mathbf{I} - 4(1-\rho\beta)(2-\rho\beta)\mathbf{Q}^{\top}\mathbf{Q}/(\rho\sigma_{\mathbf{BB}^{\top}}^{+})}^{+}$$

$$-\frac{1}{2} \|\mathbf{z}^{k} - \mathbf{z}^{k-1}\|_{\mathbf{Q} - 4(1-\rho\beta)(2-\rho\beta)(\mathbf{Q}^{\top}\mathbf{Q} + L_{H}\mathbf{I}/2)/(\rho\sigma_{\mathbf{BB}^{\top}}^{+})}^{+}.$$
Following the analysis of (42) and (43),  $\mathcal{T}$  also has a lower bound. In this case, if (44) holds,  $\mathcal{T}$  serves as a suitable

Subsequently, we need to demonstrate that the sequence generated by Algorithm 1 is bounded. It is worth noting that the subsequent analysis is based on Theorem 1, and the relevant results also apply to  $\mathcal T$  in Corollary 1.

<span id="page-9-7"></span>**Proposition 4.** Suppose that Assumptions 1, 2 and 3 hold. The sequence  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k\geqslant 0}$  generated by Algorithm 1 is bounded. Moreover,  $\|\mathbf{x}^{k+1} - \mathbf{x}^k\| \to 0$ ,  $\|\mathbf{z}^{k+1} - \mathbf{z}^k\| \to 0$ ,  $\|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^k\| \to 0$ , as  $k \to +\infty$ .

*Proof:* First, we shall demonstrate that  $\{\lambda^k\}_{k\geqslant 0}$  is bounded. According to Theorem 1,  $\mathcal P$  decreases with respect to the sequence  $\{\omega^{k+1}\}_{k\geqslant 0}$ . Therefore, we can deduce

$$\mathcal{P}(\boldsymbol{\omega}^{k+1}) \leqslant \mathcal{P}(\boldsymbol{\omega}^1),$$

which also implies that  $\mathcal{P}(\boldsymbol{\omega}^{k+1})$  has an upper bound. For  $\forall k \geq 0$ , since functions  $F(\mathbf{x}^{k+1})$ ,  $H(\mathbf{z}^{k+1})$  are bounded from below and other terms are positive, there exists a constant  $\hat{\mathcal{P}}$  associated with  $\mathcal{P}(\boldsymbol{\omega}^1)$  satisfying

<span id="page-9-1"></span>
$$\hat{\mathcal{P}} \geqslant -\langle (1 - \rho \beta) \boldsymbol{\lambda}^{k+1}, \mathbf{A} \mathbf{x}^{k+1} + \mathbf{B} \mathbf{z}^{k+1} - \mathbf{c} + \frac{\beta}{2} \boldsymbol{\lambda}^{k+1} \rangle.$$
(46)

Next, we will use the method of induction. Assume that  $\hat{P}$  is chosen such that

$$\frac{\beta(1-\rho\beta)}{2}\|\boldsymbol{\lambda}^k\|^2 \leqslant \hat{\mathcal{P}}, \text{ for } k \leqslant K.$$

Combining (42) and (46), we have

<span id="page-9-2"></span>
$$\hat{\mathcal{P}} \geqslant \frac{(1 - \rho \beta)^2}{2\rho} \left[ \| \boldsymbol{\lambda}^{k+1} \|^2 - \| \boldsymbol{\lambda}^k \|^2 \right] + \frac{\beta (1 - \rho \beta)}{2} \| \boldsymbol{\lambda}^{k+1} \|^2.$$
 (47)

If  $\|\boldsymbol{\lambda}^{K+1}\| \geqslant \|\boldsymbol{\lambda}^{K}\|$ , by (47), it has

$$\hat{\mathcal{P}} \geqslant \frac{(1 - \rho \beta)^2}{2\rho} \left[ \left\| \boldsymbol{\lambda}^{K+1} \right\|^2 - \left\| \boldsymbol{\lambda}^K \right\|^2 \right] + \frac{\beta(1 - \rho \beta)}{2} \left\| \boldsymbol{\lambda}^{K+1} \right\|^2$$

$$\beta(1 - \rho \beta) = K + 1 \cdot r^2$$

$$\geqslant \frac{\beta(1-\rho\beta)}{2} \|\boldsymbol{\lambda}^{K+1}\|^2.$$

If  $\|\boldsymbol{\lambda}^{K+1}\|^2 < \|\boldsymbol{\lambda}^K\|$ , it can be directly inferred that  $\frac{\beta(1-\rho\beta)}{2}\|\boldsymbol{\lambda}^{K+1}\|^2 < \frac{\beta(1-\rho\beta)}{2}\|\boldsymbol{\lambda}^K\|^2 \leqslant \hat{\mathcal{P}}.$ 

Therefore,  $\{\lambda^k\}_{k\geqslant 0}$  is bounded. Combining (42) with the definition of the function  $\mathcal{P}$ , for  $k\geqslant 0$ , we have  $F(\mathbf{x}^{k+1})+H(\mathbf{z}^{k+1})+\frac{1}{2}\|\mathbf{x}^{k+1}-\mathbf{x}^k\|_{2dL_F\mathbf{I}+(2d+1)\mathbf{P}}^2$ 

$$F(\mathbf{x}^{k+1}) + H(\mathbf{z}^{k+1}) + \frac{1}{2} \|\mathbf{x}^{k+1} - \mathbf{x}^{k}\|_{2dL_{F}\mathbf{I} + (2d+1)\mathbf{P}}^{2}$$

$$+ \frac{1}{2} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{2dL_{H}\mathbf{I} + 4d\rho\mathbf{B}^{T}\mathbf{B} + (2d+1)\mathbf{Q}}^{2}$$

$$+ \frac{\rho}{2} \|\mathbf{A}\mathbf{x}^{k+1} + \mathbf{B}\mathbf{z}^{k+1} - \mathbf{c}\|^{2}$$

$$+ \frac{(2d+2-\rho\beta)(1-\rho\beta)}{2\rho} \|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\|^{2} < +\infty,$$

where the terms related to  $\|\lambda\|^2$  is omitted because of its boundness. Based on the coefficient settings in Assumption 3, it can be inferred that the coefficients are all positive,

<span id="page-9-10"></span>and the coefficient matrices are positive definite. As a result, it follows that  $\{\|\mathbf{x}^{k+1}-\mathbf{x}^k\|\}_{k\geqslant 0}$ ,  $\{\|\mathbf{z}^{k+1}-\mathbf{z}^k\|\}_{k\geqslant 0}$  and  $\{\|\boldsymbol{\lambda}^{k+1}-\boldsymbol{\lambda}^k\|\}_{k\geqslant 0}$  are bounded, and  $F(\mathbf{x}^{k+1})<+\infty$ ,  $H(\mathbf{z}^{k+1})<+\infty$ . Moreover, by Assumption 2 (i), as both F and H are coercive, it can be directly deduced that  $\{\mathbf{x}^k\}_{k\geqslant 0}$  and  $\{\mathbf{z}^k\}_{k\geqslant 0}$  are bounded. Since the function  $\mathcal P$  is sufficiently decreasing and bounded from below with respect to  $\{\boldsymbol{\omega}^{k+1}\}_{k\geqslant 0}$ , with (41), we can infer  $\|\mathbf{x}^{k+1}-\mathbf{x}^k\|\to 0$ ,  $\|\mathbf{z}^{k+1}-\mathbf{z}^k\|\to 0$ ,  $\|\boldsymbol{\lambda}^{k+1}-\boldsymbol{\lambda}^k\|\to 0$ , as  $k\to +\infty$ .

Subsequently, we provide the definition of (Approximate) Karush–Kuhn–Tucker (AKKT/KKT) point for problem (1). Both KKT point and AKKT point involve (48a) and (48b); the distinction lies in the slight violation of the equality constraint.

<span id="page-9-0"></span>**Definition 7.** Consider the following inequalities with  $\epsilon > 0$ 

$$\operatorname{dist}(\mathbf{0}, \nabla F^{0}(\mathbf{x}^{*}) + \partial F^{1}(\mathbf{x}^{*}) - \mathbf{A}^{\top} \boldsymbol{\lambda}^{*}) \leqslant \epsilon, \tag{48a}$$

<span id="page-9-5"></span><span id="page-9-4"></span><span id="page-9-3"></span>
$$\operatorname{dist}(\mathbf{0}, \nabla H^{0}(\mathbf{z}^{*}) + \partial H^{1}(\mathbf{z}^{*}) - \mathbf{B}^{\top} \boldsymbol{\lambda}^{*}) \leqslant \epsilon, \tag{48b}$$

$$\|\mathbf{A}\mathbf{x}^* + \mathbf{B}\mathbf{z}^* - \mathbf{c} + \beta \lambda^*\| \leqslant \epsilon, \tag{48c}$$

<span id="page-9-6"></span>
$$\|\mathbf{A}\mathbf{x}^* + \mathbf{B}\mathbf{z}^* - \mathbf{c}\| \leqslant \epsilon. \tag{48d}$$

If a point  $(\mathbf{x}^*, \mathbf{z}^*, \boldsymbol{\lambda}^*)$  satisfies (48a), (48b) and (48c), it is referred to as an  $\epsilon$ -AKKT point (or approximate stationary point). It is called an  $\epsilon$ -KKT point if it satisfies (48a), (48b) and (48d). If  $\epsilon = 0$ , the point  $(\mathbf{x}^*, \mathbf{z}^*, \boldsymbol{\lambda}^*)$  is said to satisfy the AKKT/KKT conditions [59] for (1).

**Theorem 2.** Suppose that Assumptions 1, 2 and 3 hold, and the sequence  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k\geqslant 0}$  is generated by Algorithm 1. There exists a point  $(\mathbf{x}^{j+1}, \mathbf{z}^{j+1}, \boldsymbol{\lambda}^{j+1})$  for  $1\leqslant j\leqslant K$ , such that if  $K=\zeta^2/\epsilon^2$  for some positive constant  $\zeta$ , it will be an  $\epsilon$ -AKKT point. Furthermore, if  $\beta=1/K$  and  $K=(\zeta+\sqrt{2\hat{\mathcal{P}}})^2/\epsilon^2+\rho$ , with  $\hat{\mathcal{P}}$  being a finite constant used to bound  $\{\boldsymbol{\lambda}^k\}_{k\geqslant 0}$ , it will be an  $\epsilon$ -KKT point.

*Proof:* By Proposition 4, the sequence  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}_{k \geqslant 0}$  generated by Algorithm 1 is bounded and will converge to a cluster point. Combining (20), (21) and (9c), we have

$$\nabla F^{0}(\mathbf{x}^{k+1}) - \nabla F^{0}(\mathbf{x}^{k}) - \mathbf{P}(\mathbf{x}^{k+1} - \mathbf{x}^{k}) + \rho \mathbf{A}^{\top} \mathbf{B}(\mathbf{z}^{k+1} - \mathbf{z}^{k})$$

$$\in \nabla F^{0}(\mathbf{x}^{k+1}) + \partial F^{1}(\mathbf{x}^{k+1}) - \mathbf{A}^{\top} \boldsymbol{\lambda}^{k+1}, \quad (49)$$

<span id="page-9-9"></span><span id="page-9-8"></span>
$$\nabla H^{0}(\mathbf{z}^{k+1}) - \nabla H^{0}(\mathbf{z}^{k}) - \mathbf{Q}(\mathbf{z}^{k+1} - \mathbf{z}^{k})$$

$$\in \nabla H^{0}(\mathbf{z}^{k+1}) + \partial H^{1}(\mathbf{z}^{k+1}) - \mathbf{B}^{\top} \boldsymbol{\lambda}^{k+1}. \quad (50)$$

Summing (41) over  $k=1,\ldots,K$ , there exists a finite upper bound  $\bar{\mathcal{P}}=2\mathcal{P}(\boldsymbol{\omega}^1)-2\mathcal{P}(\boldsymbol{\omega}^{K+1})+\|\mathbf{x}^{K+1}-\mathbf{x}^K\|_{\mathbf{P}}^2-\|\mathbf{x}^1-\mathbf{x}^0\|_{\mathbf{P}}^2+\|\mathbf{z}^{K+1}-\mathbf{z}^K\|_{\mathbf{Q}}^2-\|\mathbf{z}^1-\mathbf{z}^0\|_{\mathbf{Q}}^2$  that satisfies

$$\bar{\mathcal{P}} \geqslant \sum_{k=1}^{K} \|\mathbf{x}^{k+1} - \mathbf{x}^k\|_{[\tau_F - (4d+1)\gamma_F - (4d+3)L_F]\mathbf{I} - 2d\rho\mathbf{A}^\top\mathbf{A} + \mathbf{P}}^{2}$$

$$+ \sum_{k=1}^{K} \|\mathbf{z}^{k+1} - \mathbf{z}^{k}\|_{[\tau_{H} - (4d+1)\gamma_{H} - (4d+3)L_{H}]\mathbf{I} - 8d\rho\mathbf{B}^{\top}\mathbf{B} + \mathbf{Q}}^{\mathsf{T}}$$

$$+ \left[4d\beta - (1 - \rho\beta)(2 - \rho\beta)/\rho\right] \sum_{k=1}^{K} \left\|\boldsymbol{\lambda}^{k+1} - \boldsymbol{\lambda}^{k}\right\|^{2} \geqslant 0.$$

It means that there exists  $1 \le j \le K$  satisfying

$$\|\mathbf{x}^{j+1} - \mathbf{x}^j\| \leqslant \sqrt{\frac{\bar{\mathcal{P}}}{\sigma_1^{\min} K}}, \ \|\mathbf{z}^{j+1} - \mathbf{z}^j\| \leqslant \sqrt{\frac{\bar{\mathcal{P}}}{\sigma_2^{\min} K}},$$
$$\|\boldsymbol{\lambda}^{j+1} - \boldsymbol{\lambda}^j\| \leqslant \sqrt{\frac{\rho \bar{\mathcal{P}}}{[4d\rho\beta - (1-\rho\beta)(2-\rho\beta)]K}},$$

where  $\sigma_1^{\min}$  and  $\sigma_2^{\min}$  are the smallest eigenvalues of the positive definite matrices  $[\tau_F - (4d+1)\gamma_F - (4d+3)L_F]\mathbf{I} - 2d\rho\mathbf{A}^{\top}\mathbf{A} + \mathbf{P}$  and  $[\tau_H - (4d+1)\gamma_H - (4d+3)L_H]\mathbf{I} - 8d\rho\mathbf{B}^{\top}\mathbf{B} + \mathbf{Q}$ , respectively. Therefore, for the LHS of (49) and (50), it has

$$\|\nabla F^{0}(\mathbf{x}^{j+1}) - \nabla F^{0}(\mathbf{x}^{j}) - \mathbf{P}(\mathbf{x}^{j+1} - \mathbf{x}^{j}) + \rho \mathbf{A}^{\top} \mathbf{B}(\mathbf{z}^{j+1} - \mathbf{z}^{j})\|$$

$$\leq \|\nabla F^{0}(\mathbf{x}^{j+1}) - \nabla F^{0}(\mathbf{x}^{j})\| + \|\mathbf{P}(\mathbf{x}^{j+1} - \mathbf{x}^{j})\|$$

$$+ \rho \|\mathbf{A}^{\top} \mathbf{B}(\mathbf{z}^{j+1} - \mathbf{z}^{j})\|$$

$$\leq (L_{F} + \|\mathbf{P}\|)\|\mathbf{x}^{j+1} - \mathbf{x}^{j}\| + \rho \|\mathbf{A}^{\top} \mathbf{B}\|\|\mathbf{z}^{j+1} - \mathbf{z}^{j}\|$$

$$\leq \frac{\zeta_{1} := (L_{F} + \|\mathbf{P}\|)\sqrt{\overline{P}/\sigma_{1}^{\min}} + \rho \|\mathbf{A}^{\top} \mathbf{B}\|\sqrt{\overline{P}/\sigma_{2}^{\min}}}{\sqrt{K}}, \quad (51)$$

$$\|\nabla H^{0}(\mathbf{z}^{j+1}) - \nabla H^{0}(\mathbf{z}^{j}) - \mathbf{Q}(\mathbf{z}^{j+1} - \mathbf{z}^{j})\|$$

$$\leq \|\nabla H^{0}(\mathbf{z}^{j+1}) - \nabla H^{0}(\mathbf{z}^{j})\| + \|\mathbf{Q}\|\|\mathbf{z}^{j+1} - \mathbf{z}^{j}\|$$

$$\leq \|\nabla H^{0}(\mathbf{z}^{j+1}) - \nabla H^{0}(\mathbf{z}^{j})\| + \|\mathbf{Q}\|\|\mathbf{z}^{j+1} - \mathbf{z}^{j}\|$$

$$\leq \frac{\zeta_{2} := (L_{H} + \|\mathbf{Q}\|)\sqrt{\overline{P}/\sigma_{2}^{\min}}}{\sqrt{K}}. \quad (52)$$

Moreover, by using (9c), it also has

$$\|\mathbf{A}\mathbf{x}^{j+1} + \mathbf{B}\mathbf{z}^{j+1} - \mathbf{c} + \beta \boldsymbol{\lambda}^{j+1}\| = \frac{1 + \rho\beta}{\rho} \|\boldsymbol{\lambda}^{j+1} - \boldsymbol{\lambda}^{j}\|$$

$$\leq \frac{\zeta_{3} := (1 + \rho\beta)\sqrt{\bar{P}/[4d\rho^{2}\beta - \rho(1 - \rho\beta)(2 - \rho\beta)]}}{\sqrt{K}}. (53)$$

Set  $\zeta := \max\{\zeta_1, \zeta_2, \zeta_3\}/\sqrt{K} = \epsilon$ , we can deduce  $K = \zeta/\epsilon^2$ . Therefore, based on (51), (52), and (53), the point  $(\mathbf{x}^{j+1}, \mathbf{z}^{j+1}, \boldsymbol{\lambda}^{j+1})$  satisfies the definition of  $\epsilon$ -AKKT point.

The main distinction between the AKKT point and the KKT point of Problem (1) is the equality constraint. Based on (53), we further have

$$\|\mathbf{A}\mathbf{x}^{j+1} + \mathbf{B}\mathbf{z}^{j+1} - \mathbf{c}\|$$

$$\leq \|\mathbf{A}\mathbf{x}^{j+1} + \mathbf{B}\mathbf{z}^{j+1} - \mathbf{c} + \beta \boldsymbol{\lambda}^{j+1}\| + \beta \|\boldsymbol{\lambda}^{j+1}\|$$

$$= \frac{1 + \rho\beta}{\rho} \|\boldsymbol{\lambda}^{j+1} - \boldsymbol{\lambda}^{j}\| + \beta \|\boldsymbol{\lambda}^{j+1}\| \leq \frac{\zeta}{\sqrt{K}} + \sqrt{\frac{2\beta\hat{\mathcal{P}}}{1 - \rho\beta}},$$
(54)

where the constant  $\hat{\mathcal{P}}$  appears in the proof of Proposition 4 and is used to bound  $\{\boldsymbol{\lambda}^k\}_{k\geqslant 0}$ . The above equation indicates that the points generated by PPG-ADMM have an error bound determined by  $\beta$  with respect to the equality constraint. Setting  $\beta=1/K$ , it further has

$$\frac{\zeta}{\sqrt{K}} + \sqrt{\frac{2\beta\hat{\mathcal{P}}}{1 - \rho\beta}} = \frac{\zeta}{\sqrt{K}} + \sqrt{\frac{2\hat{\mathcal{P}}}{K - \rho}} \leqslant \frac{\zeta + \sqrt{2\hat{\mathcal{P}}}}{\sqrt{K - \rho}} = \epsilon.$$

Therefore, we can set  $K = (\zeta + \sqrt{2\hat{\mathcal{P}}})^2/\epsilon^2 + \rho$ . Combining (51), (52), and (54), the point  $(\mathbf{x}^{j+1}, \mathbf{z}^{j+1}, \boldsymbol{\lambda}^{j+1})$  satisfies the definition of  $\epsilon$ -KKT point.

Theorem 2 establishes that PPG-ADMM exhibits a sublinear convergence rate of  $\mathcal{O}(1/\sqrt{K})$  and an iteration complexity of  $\mathcal{O}(1/\epsilon^2)$ , which represents the lower bound for the iteration complexity in solving nonconvex optimization problems [42].

**Remark 5.** When  $\beta = 0$  and  $H^1 \neq 0$ , Algorithm 1 may still converge, albeit without theoretical guarantees. Fig. 2 illustrates this scenario with a simple test case. As observed, a larger  $\beta$  facilitates faster convergence to a stationary point but results in greater constraint violations, whereas a smaller  $\beta$  achieves the opposite. This highlights an inherent trade-off.

<span id="page-10-4"></span>![](_page_10_Figure_13.jpeg)

<span id="page-10-1"></span><span id="page-10-0"></span>Fig. 2: A simple case to evaluate the performance of PPG-ADMM. The objective function is  $x^3 + 2(x-1)^2 + \phi(x) + z^3 + 2(z-1)^2 + \mathcal{M}_{1,1}(z)$ , subject to x+z=0, where  $\phi$  is the indicator function onto the set  $\mathcal{C}=\{x\in\mathbb{R}|-2\leqslant x\leqslant 2\}$ ,  $\mathcal{M}_{1,1}(z)$  is 1-weakly convex MCP. The optimal solution of this optimization problem is  $x^*=z^*=0$ .

#### V. DISTRIBUTED APPLICATIONS

<span id="page-10-2"></span>In this section, we will apply PPG-ADMM to two practical distributed optimization problems: the partial consensus problem and the resource allocation problem.

Distributed optimization relies on the collaboration of agents in the network to achieve the global objective. To describe the distributed network structure, we utilize the undirected graph as  $\mathcal{G} = \{\mathcal{V}, \mathcal{E}\}$ , where  $\mathcal{V}$  is the set of agents, and  $\mathcal{E} \subseteq \mathcal{V} \times \mathcal{V}$  represents the set of undirected edges connecting agents within  $\mathcal{V}$ . For instance,  $(i,j) \in \mathcal{E}$  indicates a direct connection between agents i and j. The neighbor set of  $i \in \mathcal{V}$  is represented by  $\mathcal{N}_i = \{j \in \mathcal{V} | (i,j) \in \mathcal{E}, i \neq j\}$ .

# <span id="page-10-7"></span><span id="page-10-3"></span>A. Partial Consensus Problem

Considering the following problem on the network G:

<span id="page-10-5"></span>
$$\min \sum_{i=1}^{N} f_i(x_i) = \sum_{i=1}^{N} f_i^0(x_i) + \sum_{i=1}^{N} f_i^1(x_i),$$

$$s.t. \quad A_{ij}x_i + A_{ji}x_j \in \mathcal{C}_{(i,j)}, \ (i,j) \in \mathcal{E},$$

$$(55)$$

where  $x_i \in \mathbb{R}^{n_i}$ ,  $x_j \in \mathbb{R}^{n_j}$  and  $A_{ij} \in \mathbb{R}^{l_{(i,j)} \times n_i}$ ,  $A_{ji} \in \mathbb{R}^{l_{(i,j)} \times n_j}$ ,  $\mathcal{C}_{(i,j)}$  is a convex set. For each agent i, all assumptions regarding the local functions  $f_i^0$  and  $f_i^1$  are consistent with those imposed on  $F^0$  and  $F^1$  in (1), respectively. Problems of the form (55) have also been investigated in convex optimization [62]–[64], and are referred to as the partial consensus problem [56], [64]. However, we consider a more general NCOP setting. In practical applications, enforcing strict consensus constraints can be challenging. As a compromise, it may be feasible to allow the constraint to be satisfied within a tolerable range [64], which corresponds to the constrain in (55). If we set

$$A_{ij} = \left\{ \begin{array}{l} \mathbf{I}, & \text{if } i < j, \\ -\mathbf{I}, & \text{if } i \geqslant j, \end{array} \right., \ \mathcal{C}_{(i,j)} = \{x | x = \mathbf{0}_{l_{(i,j)}}\},$$

it reduces to the standard consensus optimization problem.

The problem (55) can be reformulate as a more general and compact form, which can be represented as

<span id="page-10-6"></span>min 
$$F(\mathbf{x}) + H(\mathbf{z})$$
, s.t.  $\mathbf{N}\mathbf{x} + \mathbf{z} = \mathbf{0}$ , (56)

#### **Algorithm 2:** Distributed PPG-ADMM for (56)

For  $\forall i \in \mathcal{V}$ , initialize  $x_i^0, z_{(i,j),i}^0$  and  $\lambda_{(i,j),i}^0$ .

Transmit  $A_{ij}x_i^0$  to and collect  $A_{ji}x_j^0$  from all neighbors  $\forall j \in \mathcal{N}_i$ . Set  $\tau_F \mathbf{I} \succ \rho \mathbf{N}^\top \mathbf{N}, \tau_F > \gamma_F,$   $\tau_H > \rho > 0, \ \beta > 0, \ 0 < \rho \beta < 1.$ while stopping criteria is not satisfied, for  $\forall i \in \mathcal{V}$  do

Update the primal variable  $x_i^{k+1}$  by (58a);

Transmit  $A_{ij}x_i^{k+1}$  to and collect  $A_{ji}x_j^{k+1}$  from all neighbors  $\forall j \in \mathcal{N}_i$ ;

Update the primal variable  $z_{(i,j),i}^{k+1}$  by (58b);

Update the dual variable  $\lambda_{(i,j),i}^{k+1}$  by (58c).

end

return  $\{(\mathbf{x}^k, \mathbf{z}^k, \lambda^k)\}$ .

where  $\mathbf{x} = [x_1; \cdots; x_N] \in \mathbb{R}^{\sum_{i=1}^N n_i}$ ,  $F(\mathbf{x}) = F^0(\mathbf{x}) + F^1(\mathbf{x}) = \sum_{i=1}^N f_i(x_i)$ ,  $\mathbf{N} \in \mathbb{R}^{\sum_{(i,j) \in \mathcal{E}} l_{(i,j)} \times \sum_{i=1}^N n_i}$  is stacked by  $N_{(i,j)} : \mathbf{x} \to A_{ij}x_i + A_{ji}x_j$ ,  $\mathbf{z} \in \mathbb{R}^{\sum_{(i,j) \in \mathcal{E}} l_{(i,j)}}$ ,  $H(\mathbf{z}) = \sum_{(i,j) \in \mathcal{E}} h_{(i,j)}(z_{(i,j)})$ . The local function  $h_{(i,j)}(z_{(i,j)})$  represents an indicator function onto the set  $C_{(i,j)}$ . In other cases, the term  $H(\mathbf{z})$  may serve as a regularization term or penalty term, taking the form of a smooth  $\ell_2$ -norm, a nonsmooth  $\ell_1$ -norm, or a weakly convex MCP.

Due to the presence of the possibly nonsmooth term H, (56) does not satisfy both C1 and C2 simultaneously, unlike the problems analyzed in [17]–[37]. However, by setting  $\mathbf{A} = \mathbf{N}$  and  $\mathbf{B} = \mathbf{I}$ , (56) can be captured by (1), allowing the use of PPG-ADMM. The updates are as follows:

$$\mathbf{x}^{k+1} = \mathbf{prox}_{F^{1}}^{\tau_{F}} \{ \tau_{F}^{-1} [-\nabla F^{0}(\mathbf{x}^{k}) + (\tau_{F} - \rho \mathbf{N}^{\top} \mathbf{N}) \mathbf{x}^{k} - \rho \mathbf{N}^{\top} \mathbf{z}^{k} + (1 - \rho \beta) \mathbf{N}^{\top} \boldsymbol{\lambda}^{k} ] \},$$
(57a)  
$$\mathbf{z}^{k+1} = \delta_{\mathcal{C}} \{ \tau_{H}^{-1} [(\tau_{H} - \rho) \mathbf{z}^{k} - \rho \mathbf{N} \mathbf{x}^{k+1} + (1 - \rho \beta) \boldsymbol{\lambda}^{k} ] \},$$
(57b)  
$$\boldsymbol{\lambda}^{k+1} = (1 - \rho \beta) \boldsymbol{\lambda}^{k} - \rho (\mathbf{N} \mathbf{x}^{k+1} + \mathbf{z}^{k+1}).$$
(57c)

The symbol  $\delta_{\mathcal{C}}$  denotes the projection operator onto set  $\mathcal{C}$ , which is stacked by  $\mathcal{C}_{(i,j)}$ . The variables  $\mathbf{z}$  and  $\boldsymbol{\lambda} \in \mathbb{R}^{\sum_{(i,j) \in \mathcal{E}} l_{(i,j)}}$  are associated with the edges, with each component corresponds to an edge in  $\mathcal{E}$ . According to the previous definition, we deduce

$$\mathbf{N}^{\top}\mathbf{z} = \left[\sum_{j \in \mathcal{N}_1} A_{1j}^{\top} z_{(1,j)}; \cdots; \sum_{j \in \mathcal{N}_N} A_{Nj}^{\top} z_{(N,j)}\right] \in \mathbb{R}^{\sum_{i=1}^N n_i},$$

$$\mathbf{N}^{\top} \boldsymbol{\lambda} = \left[ \sum_{j \in \mathcal{N}_1} A_{1j}^{\top} \lambda_{(1,j)}; \cdots; \sum_{j \in \mathcal{N}_N} A_{Nj}^{\top} \lambda_{(N,j)} \right] \in \mathbb{R}^{\sum_{i=1}^{N} n_i},$$

$$\mathbf{N}^{\top}\mathbf{N}_{ij} = \left\{ \begin{array}{ll} \sum_{k \in \mathcal{N}_i} A_{ik}^{\top} A_{ik}, & \text{if } i = j, \\ A_{ij}^{\top} A_{ji}, & \text{if } (i,j) \in \mathcal{E} \text{ and } i \neq j, \\ \mathbf{O}, & \text{if } (i,j) \notin \mathcal{E}. \end{array} \right.$$

The matrix  $\mathbf{N}^{\top}\mathbf{N} \in \mathbb{R}^{\sum_{i=1}^{N} n_i \times \sum_{i=1}^{N} n_i}$  directly embodies the actual structure of the distributed network. In the distributed implementation of (57), the update of edge variables can be achieved by the two connected agents. For example,  $z_{(i,j)}$  has two copies  $z_{(i,j),i}$  and  $z_{(i,j),j}$  kept in agents i and j,

## Algorithm 3: Distributed PPG-ADMM for (60)

For  $\forall i \in \mathcal{V}$ , initialize  $x_i^0$ ,  $\bar{z}_i^0 = \mathbf{0}$  and  $\lambda_i^0$ . Set  $\tau_F \mathbf{I} \succ \rho \widehat{\mathbf{A}}^\top \widehat{\mathbf{A}}$ ,  $\tau_F > \gamma_F$ ,  $\tau_H > \rho > 0$ ,  $\beta > 0$ ,  $0 < \rho \beta < 1$ . **while** stopping criteria is not satisfied, for  $\forall i \in \mathcal{V}$  **do**Update the primal variable  $x_i^{k+1}$  by (62a);
Transmit  $\bar{\lambda}_i^{k+1} = (1-\rho\beta)\lambda_i^k - \rho(\mathbf{A}_i x_i^{k+1} + \bar{z}_i^k - \mathbf{c}_i)$  to and collect  $\bar{\lambda}_j^{k+1}$  from all neighbors  $\forall j \in \mathcal{N}_i$ ;
Update the primal variable  $\bar{z}_i^{k+1}$  by (62b);
Update the dual variable  $\lambda_i^{k+1}$  by (62c); **end return**  $\{(\mathbf{x}^k, \mathbf{z}^k, \boldsymbol{\lambda}^k)\}$ .

respectively. The local updates for agent  $i \in \mathcal{V}$  are as follows:

<span id="page-11-0"></span>
$$x_{i}^{k+1} = \mathbf{prox}_{f_{i}^{1}}^{\tau_{F}} \{ \tau_{1}^{-1} [-\nabla f_{i}^{0}(x_{i}^{k}) + (\tau_{F} - \rho \sum_{j \in \mathcal{N}_{i}} A_{ij}^{\top} A_{ij}) x_{i}^{k} - \rho \sum_{j \in \mathcal{N}_{i}} A_{ij}^{\top} A_{ji} x_{j}^{k} - \rho \sum_{j \in \mathcal{N}_{i}} A_{ij}^{\top} z_{(i,j),i}^{k} + (1 - \rho \beta) \sum_{j \in \mathcal{N}_{i}} A_{ij}^{\top} \lambda_{(i,j),i}^{k} ] \},$$
 (58a)
$$z_{(i,j),i}^{k+1} = \delta_{\mathcal{C}_{(i,j)}} \{ \tau_{H}^{-1} [(\tau_{H} - \rho) z_{(i,j),i}^{k} - \rho (A_{ij} x_{i}^{k+1} + A_{ji} x_{j}^{k+1}) + (1 - \rho \beta) \lambda_{(i,j),i}^{k} ] \}, \quad \forall j \in \mathcal{N}_{i},$$
 (58b)
$$\lambda_{(i,j),i}^{k+1} = (1 - \rho \beta) \lambda_{(i,j),i}^{k} - \rho (A_{ij} x_{i}^{k+1} + A_{ji} x_{j}^{k+1} + z_{(i,j),i}^{k+1}),$$

<span id="page-11-3"></span><span id="page-11-2"></span><span id="page-11-1"></span>The details of the distributed algorithm for solving (56) are provided in Algorithm 2. Notably, this algorithm achieves convergence solely through the exchange of  $A_{ij}x_i$  between agents and their neighbors, without relying on a central agent.

# <span id="page-11-6"></span>B. Resource Allocation Problem

The resource allocation problem is concerned in fields such as smart grid and other related domains [3]. It can be formulated as the following problem on the network G:

<span id="page-11-5"></span>min 
$$\sum_{i=1}^{N} f_i(x_i) = \sum_{i=1}^{N} f_i^0(x_i) + \sum_{i=1}^{N} f_i^1(x_i),$$

$$s.t. \quad \sum_{i=1}^{N} \mathbf{A}_i x_i = \sum_{i=1}^{N} \mathbf{c}_i = \mathbf{c},$$
(59)

where  $x_i \in \mathbb{R}^{n_i}$ ,  $\mathbf{A}_i \in \mathbb{R}^{p \times n_i}$  and  $\mathbf{c}_i$ ,  $\mathbf{c} \in \mathbb{R}^p$ . The assumptions about the objective function are the same as in the previous subsection. To facilitate the construction and implementation of distributed algorithms, according to [65], [66], the problem (59) can be transformed into:

<span id="page-11-4"></span>
$$\min \ F(\mathbf{x}), \quad s.t. \ \widehat{\mathbf{A}}\mathbf{x} + \sqrt{\mathbf{I} - \mathbf{W}}\mathbf{z} = \widehat{\mathbf{c}}, \qquad (60)$$
 where  $\widehat{\mathbf{A}} = \operatorname{blkdiag}\{\mathbf{A}_1, \cdots, \mathbf{A}_N\} \in \mathbb{R}^{Np \times \sum_{i=1}^N n_i}, \ \mathbf{x} = [x_1; \cdots; x_N] \in \mathbb{R}^{\sum_{i=1}^N n_i}, \ \widehat{\mathbf{c}} = [\mathbf{c}_1; \cdots; \mathbf{c}_N] \in \mathbb{R}^{Np}$  and  $F(\mathbf{x}) = F^0(\mathbf{x}) + F^1(\mathbf{x}) = \sum_{i=1}^N f_i(x_i)$ . To address the problem in a distributed manner, each agent  $i$  should maintain a local copy  $z_i \in \mathbb{R}^p$ . These local copies can be stacked together and denoted as  $\mathbf{z} = [z_1; \cdots; z_N] \in \mathbb{R}^{Np}$ . Followed by the introduction of the mixing matrix  $W \in \mathbb{R}^{N \times N}$  in  $\mathbf{I} - \mathbf{W} = (\mathbf{I}_N - W) \otimes \mathbf{I}_p \in \mathbb{R}^{Np \times Np}$ . Further details regarding this mixing matrix can be found in Assumption 4.

<span id="page-12-3"></span>**Assumption 4.** For the mixing matrix W:

- <span id="page-12-4"></span>(i) It is symmetric and doubly stochastic, meaning that  $W\mathbf{1}_N = W^{\top}\mathbf{1}_N = \mathbf{1}_N$ .
- <span id="page-12-5"></span>(ii) It can be utilized to represent the graph structure of  $\mathcal{G}$ . Specifically, when  $i \neq j$  and  $j \notin \mathcal{N}_i$ , the weight  $w_{ij} = 0$ ; otherwise,  $w_{ij} > 0$ .
- (iii) It is positive semidefinite, i.e.,  $W \succeq \mathbf{O}$ .

By Assumption 4, the null space of  $\mathbf{I}_N - W$  is the linear span of 1, i.e.,  $\mathbf{Null}(\mathbf{I}_N - W) = \mathbf{Span}(\mathbf{1})$ . Therefore, this matrix frequently appears in the decentralized consensus constraint. The largest and unique eigenvalue of W is 1, and it satisfies the condition that  $1 = \lambda_1 > \max\{\lambda_2, \cdots, \lambda_N\}$ , where  $\lambda_i$  denotes the i-th largest eigenvalue. A simple way to obtain a positive semidefinite matrix satisfying Assumption 4 is to set W = (W' + I)/2, where W' is a matrix that satisfies Assumption 4 (i) and (ii) [67].

By applying the proposed PPG-ADMM to solve (60), we obtain the following updates:

$$\begin{split} \mathbf{x}^{k+1} = & \mathbf{prox}_{F}^{\tau_{F}} \{ -\tau_{F}^{-1} [\nabla F^{0}(\mathbf{x}^{k}) + (\tau_{F}\mathbf{I} - \rho \widehat{\mathbf{A}}^{\top} \widehat{\mathbf{A}}) \mathbf{x}^{k} \quad \text{(61a)} \\ & -\rho \widehat{\mathbf{A}}^{\top} \sqrt{\mathbf{I} - \mathbf{W}} \mathbf{z}^{k} + (1 - \rho \beta) \widehat{\mathbf{A}}^{\top} \boldsymbol{\lambda}^{k} + \rho \widehat{\mathbf{A}}^{\top} \widehat{\mathbf{c}} ] \}, \\ \mathbf{z}^{k+1} = & \mathbf{z}^{k} + \tau_{H}^{-1} [-\rho (\mathbf{I} - \mathbf{W}) \mathbf{z}^{k} - \rho \sqrt{\mathbf{I} - \mathbf{W}} \widehat{\mathbf{A}} \mathbf{x}^{k+1} \\ & + (1 - \rho \beta) \sqrt{\mathbf{I} - \mathbf{W}} \boldsymbol{\lambda}^{k} + \rho \sqrt{\mathbf{I} - \mathbf{W}} \widehat{\mathbf{c}} \ ], \\ \boldsymbol{\lambda}^{k+1} = & (1 - \rho \beta) \boldsymbol{\lambda}^{k} - \rho (\widehat{\mathbf{A}} \mathbf{x}^{k+1} + \sqrt{\mathbf{I} - \mathbf{W}} \mathbf{z}^{k+1} - \widehat{\mathbf{c}}). \end{aligned} \tag{61b}$$

According to the previous analysis, since there is no non-smooth term in (61b),  $\beta=0$  can be used, signifying that the problem in this case can be exactly solved. However, in (61), the terms related to  $\sqrt{\mathbf{I}-\mathbf{W}}$  still hinder the distributed implementation. Therefore, we can introduce  $\bar{\mathbf{z}}=\sqrt{\mathbf{I}-\mathbf{W}}\mathbf{z}$ . For each agent  $i\in\mathcal{V}$ , its local updates are as follows:

$$x_{i}^{k+1} = \mathbf{prox}_{f_{i}^{T}}^{\tau_{F}} \{ \tau_{1}^{-1} [-\nabla f_{i}^{0}(x_{i}^{k}) + (\tau_{F} - \rho \mathbf{A}_{i}^{\top} \mathbf{A}_{i}) x_{i}^{k} - \rho \mathbf{A}_{i}^{\top} (\bar{z}_{i}^{k} - \mathbf{c}_{i}) + (1 - \rho \beta) \mathbf{A}_{i}^{\top} \lambda_{i}^{k} ] \}, \qquad (62a)$$

$$\bar{z}_{i}^{k+1} = \bar{z}_{i}^{k} + \tau_{H}^{-1} (\bar{\lambda}_{i}^{k+1} - \sum_{j \in \mathcal{V}_{i} \cup \{i\}} W_{ij} \bar{\lambda}_{j}^{k+1}), \qquad (62b)$$

$$\lambda_{i}^{k+1} = (1 - \rho \beta) \lambda_{i}^{k} - \rho (\mathbf{A}_{i} x_{i}^{k+1} + \bar{z}_{i}^{k+1} - \mathbf{c}_{i}), \qquad (62c)$$

where  $\bar{\lambda}_i^{k+1} = (1-\rho\beta)\lambda_i^k - \rho(\mathbf{A}_ix_i^{k+1} + \bar{z}_i^k - \mathbf{c}_i)$ . The details of the distributed algorithm for solving (60) can be found in Algorithm 3. The selection of parameters for this algorithm can be made independent of the network structure. Specifically, since W is positive semidefinite, it is possible to set  $\tau_H > \rho$  rather than requiring  $\tau_H \mathbf{I} \succ \rho(\mathbf{I} - \mathbf{W})$  ((40e) in Assumption 3).

#### VI. NUMERICAL EXPERIMENTS

In this section, the effectiveness of the proposed PPG-ADMM will be validated through three studies. All simulations are conducted using MATLAB R2023a on a computer equipped with the Windows 11 operating system, 16 GB memory and an Intel i5-12600KF CPU.

#### A. Case 1: Robust Principal Component Analysis

In the first case, we consider the RPCA optimization problem (6), where the regularization parameter is set to  $\kappa = 0.35$  to balance the low-rank component  ${\bf x}$  and the sparse component  ${\bf z}$ . The nuclear norm  $\|\cdot\|_*$  is employed as

the low-rank regularization term f, while the SCAD penalty serves as the sparsity-inducing term h. The observed matrix  $\mathbf{M} \in \mathbb{R}^{40 \times 40}$  is generated as the sum of a low-rank matrix  $\mathbf{L}$  and a sparse noise matrix  $\mathbf{S}$ , where  $\mathbf{L}$  is constructed as the product of two randomly initialized low-dimensional matrices, and  $\mathbf{S}$  is generated with element-wise sparsity following a Bernoulli-Gaussian distribution. In this RPCA formulation,  $\mathbf{x} + \mathbf{z}$  approximates  $\mathbf{M}$ , with  $\mathbf{x}$  and  $\mathbf{z}$  serving as estimates of the underlying  $\mathbf{L}$  and  $\mathbf{S}$ , respectively.

We apply Algorithm 1 to solve this problem and evaluate the impact of different perturbation parameters  $\beta = 0, 0.4, 1$ on algorithm performance while keeping all other settings unchanged. The ADMM from [15] is used as a baseline for comparison. This method incorporates the estimation error  $\|\mathbf{x} + \mathbf{z} - \mathbf{M}\|^2$  as an additional penalty term in the objective function and forms an inexact formulation. The results, presented in Fig. 3, depict the objective function value and the estimation error. As observed, the standard ADMM ( $\beta = 0$ ) exhibits oscillations when solving this optimization problem (6) composed entirely of nonsmooth terms. The ADMM in [15] demonstrates lower accuracy, primarily due to the penalty term. In contrast, a larger  $\beta$  in Algorithm 1 leads to a lower final objective function value, possibly because the constraints become more relaxed. In this setting,  $\beta$  has a relatively limited impact on accuracy but enhances convergence stability. These results validate the effectiveness of PPG-ADMM in solving RPCA problem and highlight the benefits of carefully selecting the perturbation parameter to achieve robust and efficient convergence.

## <span id="page-12-7"></span><span id="page-12-6"></span>B. Case 2: Decentralized Machine Learning

<span id="page-12-1"></span><span id="page-12-0"></span>In this case, we focus on a binary classification problem. Assume that there are N=5 distributed agents participating in the model training, forming a circular network  $\mathcal{G}$ . We select the '0' and '8' handwritten digit images from the MNIST dataset as training samples, and distribute them among the agents. Each agent i holds its own local training samples  $(M_{(i,j)}, l_{(i,j)})_{j=1}^{N_i}$ , where  $M_{(i,j)} \in \mathbb{R}^n$  represents the feature vector and  $l_{(i,j)} \in \{-1,+1\}$  denotes the corresponding label. The empirical loss optimization problem follows the formulation of (55), where

<span id="page-12-2"></span>formulation of (55), where  $\sum_{i=1}^{N} f_i^0(x_i) = \frac{\sum_{i=1}^{N} \sum_{j=1}^{N_i} \sigma(l_{(i,j)} M_{(i,j)}^{\top} x_i)}{\sum_{i=1}^{N} N_i},$ 

with  $\sigma(l_{(i,j)}M_{(i,j)}^{\top}x_i)=1/(1+\exp(l_{(i,j)}M_{(i,j)}^{\top}x_i))$  being the smooth and nonconvex sigmoid function, commonly used as an activation function in neural networks. Besides, the regularization term is given by  $\sum_{i=1}^{N}f_i^1(x_i)=0.1\times\sum_{i=1}^{N}\mathcal{M}_{0.01,1}(x_i)$ . For the parameters in the partial consensus constraint, they are set to be close to  $\mathbf{I}$  and  $-\mathbf{I}$ . Using Algorithm 2 to solve this decentralized optimization problem, the Lyapunov function  $\mathcal{P}$  demonstrates a decreasing trajectory, as illustrated in the left subfigure of Fig. 4.

Furthermore, for the purpose of comparison with existing algorithms, we focus on the decentralized machine learning problem with only consensus constraint, which serves as a special case of (55) (for more details, refer to the previous Section V-A). We utilize Algorithm 2, Proximal Primal-Dual Algorithm with Momentum (PPDM) in [41], Distributed

<span id="page-13-0"></span>![](_page_13_Figure_1.jpeg)

Fig. 3: The iteration results of objective function (Left) and the estimation error (Right).

<span id="page-13-1"></span>![](_page_13_Figure_3.jpeg)

<span id="page-13-3"></span>Fig. 4: The trajectory of  $\mathcal{P}(\omega^k)$  and  $\mathcal{P}(\omega^k) - \mathcal{P}(\omega^{k-1})$  (Left) obtained by Algorithm 2, as well as the iteration results of objective function and the consensus residuals (Right).

![](_page_13_Figure_5.jpeg)

Fig. 5: The iteration results of the overall operating costs and the residuals of constraint under different  $\beta$  (Left), as well as the trajectory of  $\mathcal{T}(\omega^k)$  and  $\mathcal{T}(\omega^k) - \mathcal{T}(\omega^{k-1})$  (Right) obtained by Algorithm 3.

Primal-Dual Algorithm (DPDA) in [42], Decentralized Proximal Stochastic Gradient Tracking (DProxSGT) in [48] and Proximal Decentralized Averaged Stochastic Approximation (Prox-DASA) in [45] to solve it. It is worth noting that in this context, the stochastic algorithms in [45], [48] utilize deterministic gradients. The trajectories of the iteration results and the consensus residuals of the primal-dual algorithms are shown in the right subfigure of Fig. 4. It can be observed that our proposed algorithm achieves relatively accurate convergence with a small perturbation parameter ( $\beta = 10^{-8}$ ), demonstrating comparable performance to exact algorithms.

#### C. Case 3: Nonconvex Resource Allocation Problem

In this case, we consider a network with N=8 agents, each having its own operating cost function:  $f_i^0(x_i)=-e^{-x_i}+a_ix_i^3-b_i(x_i+b_i)^2+d_i,\ 0\leqslant x_i\leqslant 200.$  The objective is to minimize the overall operational cost, given by  $F^0(\mathbf{x})=\sum_{i=1}^N f_i^0(x_i)$ , while satisfying the following two

TABLE II: Local parameters in Case 3.

<span id="page-13-2"></span>

| Agent    | 1    | 2    | 3    | 4    | 5    | 6    | 7    | 8    |
|----------|------|------|------|------|------|------|------|------|
| $a_i$    | 0.05 | 0.05 | 0.05 | 0.08 | 0.08 | 0.08 | 0.10 | 0.10 |
| $b_i$    | 2    | 3    | 1    | 5    | 4    | 3    | 5    | 3    |
| $d_i$    | 4000 | 2000 | 4000 | 3000 | 3500 | 3500 | 2000 | 3000 |
| $A_{1i}$ | 1.3  | 1.1  | 1.2  | 0.9  | 1.2  | 0    | 0    | 0    |
| $A_{2i}$ | 0    | 0    | 0    | 0    | 0.9  | 1.1  | 1.1  | 0.9  |

equality constraints, denoted as

$$\sum_{i=1}^{N} A_{1i} x_i = c_1 = 208, \ \sum_{i=1}^{N} A_{2i} x_i = c_2 = 113.$$

The values of relevant parameters are provided in Table II. One can address the local constraints as indicator functions  $f_i^1(x_i)$ , which makes the problem conform to the form of (59). Following the analysis in Section V-B, the problem can be further reformulated into the form of (60), which can be solved by using Algorithm 3. The iteration results of the overall operating costs and the residuals of equality constraints under

different choices of β are presented in the left subfigure of Fig. [5.](#page-13-3) As illustrated, larger values of β affect the accuracy. Note that the overall operating costs may be somewhat reduced in this scenario, as the equality constraints are not adequately satisfied and the feasible set is enlarged. Additionally, by choosing the parameters to satisfy [\(44\)](#page-8-11), the function T is also a sufficiently decreasing function with respect to the sequence generated by Algorithm 3 (as shown in [\(45\)](#page-9-10)), and its trajectory is depicted in the right subfigure of Fig. [5.](#page-13-3)

## VII. CONCLUSION

This paper proposes the PPG-ADMM framework for solving NCOPs. The framework relaxes the conventional smoothness assumption on the objective function, thereby broadening the applicability of ADMM. The incorporated perturbation mechanism enhances convergence performance to some extent, as validated by experimental results. The proposed algorithm achieves convergence to an ϵ-approximate stationary point with a sublinear convergence rate of O(1/ √ K) and an iteration complexity of O(1/ϵ<sup>2</sup> ). Moreover, by selecting a sufficiently small perturbation parameter, PPG-ADMM can attain an ϵ-stationary point, ensuring stronger optimality guarantees. The framework is further extended to solve two practical decentralized optimization problems. Our future research will explore its applications in smart grid optimization and other large-scale networked systems.

## REFERENCES

- <span id="page-14-0"></span>[1] S. Boyd, N. Parikh, E. Chu, B. Peleato, J. Eckstein *et al.*, "Distributed optimization and statistical learning via the alternating direction method of multipliers," *Foundations and Trends® in Machine learning*, vol. 3, no. 1, pp. 1–122, 2011.
- <span id="page-14-1"></span>[2] Y. Yang, X. Guan, Q.-S. Jia, L. Yu, B. Xu, and C. J. Spanos, "A survey of ADMM variants for distributed optimization: Problems, algorithms and features," *arXiv preprint arXiv:2208.03700*, 2022.
- <span id="page-14-2"></span>[3] Y. Zhou, X. Shi, L. Guo, G. Wen, and J. Cao, "A proximal ADMMbased distributed optimal energy management approach for smart grid with stochastic wind power," *IEEE Trans. Circuits Syst. I Reg. Papers*, 2023.
- <span id="page-14-3"></span>[4] X. Li, L. Xie, and N. Li, "A survey of decentralized online learning," *arXiv preprint arXiv:2205.00473*, 2022.
- <span id="page-14-4"></span>[5] A. Chambolle and T. Pock, "An introduction to continuous optimization for imaging," *Acta Numer.*, vol. 25, pp. 161–319, 2016.
- <span id="page-14-5"></span>[6] Y. Shen, Z. Wen, and Y. Zhang, "Augmented lagrangian alternating direction method for matrix separation based on low-rank factorization," *Optim. Methods Softw.*, vol. 29, no. 2, pp. 239–263, 2014.
- <span id="page-14-6"></span>[7] D. Hajinezhad and M. Hong, "Nonconvex alternating direction method of multipliers for distributed sparse principal component analysis," in *Proc. GlobalSIP*. IEEE, 2015, pp. 255–259.
- <span id="page-14-7"></span>[8] P. A. Forero, A. Cano, and G. B. Giannakis, "Distributed clustering using wireless sensor networks," *IEEE J. Sel. Topics Signal Process.*, vol. 5, no. 4, pp. 707–724, 2011.
- <span id="page-14-8"></span>[9] D. Hajinezhad, M. Hong, T. Zhao, and Z. Wang, "NESTT: A nonconvex primal-dual splitting method for distributed and stochastic optimization," *Proc. Int. Conf. Neural Inf. Process. Syst.*, vol. 29, 2016.
- <span id="page-14-9"></span>[10] R. F. Barber and E. Y. Sidky, "Convergence for nonconvex ADMM, with applications to CT imaging," *J. Mach. Learn. Res.*, vol. 25, no. 38, pp. 1–46, 2024.
- <span id="page-14-10"></span>[11] D. Han, D. Sun, and L. Zhang, "Linear rate convergence of the alternating direction method of multipliers for convex composite programming," *Math. Oper. Res.*, vol. 43, no. 2, pp. 622–637, 2018.
- <span id="page-14-11"></span>[12] Y. Wang, W. Yin, and J. Zeng, "Global convergence of ADMM in nonconvex nonsmooth optimization," *Comput. J. Sci. comput.*, vol. 78, pp. 29–63, 2019.
- <span id="page-14-12"></span>[13] Y. Yang, Q.-S. Jia, Z. Xu, X. Guan, and C. J. Spanos, "Proximal ADMM for nonconvex and nonsmooth optimization," *Automatica*, vol. 146, p. 110551, 2022.

- <span id="page-14-13"></span>[14] K. Sun and X. A. Sun, "A two-level distributed algorithm for general constrained non-convex optimization with global convergence," *arXiv preprint arXiv:1902.07654*, 2019.
- <span id="page-14-14"></span>[15] F. Wen, R. Ying, P. Liu, and R. C. Qiu, "Robust PCA using generalized nonconvex regularization," *IEEE Trans. Circuits Syst. Video Technol.*, vol. 30, no. 6, pp. 1497–1510, 2019.
- <span id="page-14-15"></span>[16] L. Feng, Y. Liu, Z. Liu, and C. Zhu, "Online nonconvex robust tensor principal component analysis," *IEEE Trans. Neural Netw. Learn. Syst.*, pp. 1–15, 2024, doi:10.1109/TNNLS.2024.3519213.
- <span id="page-14-16"></span>[17] X. Wang, J. Yan, B. Jin, and W. Li, "Distributed and parallel ADMM for structured nonconvex optimization problem," *IEEE Trans. Cybern.*, vol. 51, no. 9, pp. 4540–4552, 2019.
- <span id="page-14-25"></span>[18] T.-H. Chang, M. Hong, W.-C. Liao, and X. Wang, "Asynchronous distributed ADMM for large-scale optimization—part I: Algorithm and convergence analysis," *IEEE Trans. Signal Process.*, vol. 64, no. 12, pp. 3118–3130, 2016.
- <span id="page-14-21"></span>[19] G. Li and T. K. Pong, "Global convergence of splitting methods for nonconvex composite optimization," *SIAM J. Optim.*, vol. 25, no. 4, pp. 2434–2460, 2015.
- <span id="page-14-37"></span>[20] F. Bian, J. Liang, and X. Zhang, "A stochastic alternating direction method of multipliers for non-smooth and non-convex optimization," *Inverse Problems*, vol. 37, no. 7, p. 075009, 2021.
- <span id="page-14-26"></span>[21] R. I. Bot¸ and D.-K. Nguyen, "The proximal alternating direction method of multipliers in the nonconvex setting: Convergence analysis and rates," *Math. Operations Res.*, vol. 45, no. 2, pp. 682–712, 2020.
- <span id="page-14-27"></span>[22] K. Guo, D. Han, and T.-T. Wu, "Convergence of alternating direction method for minimizing sum of two nonconvex functions with linear constraints," *Int. J. Comput. Math.*, vol. 94, no. 8, pp. 1653–1669, 2017.
- <span id="page-14-28"></span>[23] F. Huang and S. Chen, "Mini-batch stochastic ADMMs for nonconvex nonsmooth optimization," *arXiv preprint arXiv:1802.03284*, 2018.
- <span id="page-14-18"></span>[24] F. Huang, S. Chen, and H. Huang, "Faster stochastic alternating direction method of multipliers for nonconvex optimization," in *ICML*. PMLR, 2019, pp. 2839–2848.
- <span id="page-14-29"></span>[25] Y. Zeng, J. Bai, S. Wang, and Z. Wang, "A unified inexact stochastic ADMM for composite nonconvex and nonsmooth optimization," *arXiv preprint arXiv:2403.02015*, 2024.
- <span id="page-14-30"></span>[26] Y. Zeng, Z. Wang, J. Bai, and X. Shen, "An accelerated stochastic ADMM for nonconvex and nonsmooth finite-sum optimization," *Automatica*, vol. 163, p. 111554, 2024.
- <span id="page-14-31"></span>[27] M. Yashtini, "Multi-block nonconvex nonsmooth proximal ADMM: Convergence and rates under Kurdyka–Łojasiewicz property," *J. Optimiz. Theory Appl.*, vol. 190, no. 3, pp. 966–998, 2021.
- <span id="page-14-32"></span>[28] M. Hong, Z.-Q. Luo, and M. Razaviyayn, "Convergence analysis of alternating direction method of multipliers for a family of nonconvex problems," *SIAM J. Optim.*, vol. 26, no. 1, pp. 337–364, 2016.
- <span id="page-14-19"></span>[29] M. Hong, "A distributed, asynchronous, and incremental algorithm for nonconvex optimization: An ADMM approach," *IEEE Trans. Control Netw. Syst.*, vol. 5, no. 3, pp. 935–945, 2017.
- <span id="page-14-22"></span>[30] M. Yashtini, "Convergence and rate analysis of a proximal linearized ADMM for nonconvex nonsmooth optimization," *J. Global Optim.*, vol. 84, no. 4, pp. 913–939, 2022.
- <span id="page-14-23"></span>[31] Q. Liu, X. Shen, and Y. Gu, "Linearized ADMM for nonconvex nonsmooth optimization with convergence analysis," *IEEE Access*, vol. 7, pp. 76 131–76 144, 2019.
- <span id="page-14-33"></span>[32] D. Hajinezhad and Q. Shi, "Alternating direction method of multipliers for a class of nonconvex bilinear optimization: Convergence analysis and applications," *J. Global Optim.*, vol. 70, pp. 261–288, 2018.
- <span id="page-14-24"></span>[33] C. Zhang, Y. Song, X. Cai, and D. Han, "An extended proximal ADMM algorithm for three-block nonconvex optimization problems," *J. Comput. Appl. Math.*, vol. 398, p. 113681, 2021.
- <span id="page-14-34"></span>[34] L. Yang, T. K. Pong, and X. Chen, "Alternating direction method of multipliers for a class of nonconvex and nonsmooth problems with applications to background/foreground extraction," *SIAM J. Imag. Sci.*, vol. 10, no. 1, pp. 74–110, 2017.
- <span id="page-14-20"></span>[35] F. Wang, W. Cao, and Z. Xu, "Convergence of multi-block bregman ADMM for nonconvex composite problems," *Sci. China Inf. Sci.*, vol. 61, pp. 1–12, 2018.
- <span id="page-14-35"></span>[36] J. G. Melo and R. Monteiro, "Iteration-complexity of a linearized proximal multiblock ADMM class for linearly constrained nonconvex optimization problems," *Available on: http://www. optimization-online. org*, 2017.
- <span id="page-14-17"></span>[37] R. I. Bot, E. R. Csetnek, and D.-K. Nguyen, "A proximal minimization algorithm for structured nonconvex and nonsmooth problems," *SIAM J. Optim.*, vol. 29, no. 2, pp. 1300–1328, 2019.
- <span id="page-14-36"></span>[38] Y. Gao, A. Rodomanov, and S. U. Stich, "Non-Convex stochastic composite optimization with Polyak momentum," *arXiv preprint arXiv:2403.02967*, 2024.

- <span id="page-15-5"></span>[39] Z. Li and J. Li, "A simple proximal stochastic gradient method for nonsmooth nonconvex optimization," *Proc. 32nd Int. Conf. Neural Inf. Process. Syst.*, vol. 31, 2018.
- <span id="page-15-4"></span>[40] X. Jiang, X. Zeng, J. Sun, and J. Chen, "Distributed proximal gradient algorithm for nonconvex optimization over time-varying networks," *IEEE Trans. Control Netw. Syst.*, vol. 10, no. 2, pp. 1005–1017, 2022.
- <span id="page-15-7"></span>[41] Z. Wang, J. Zhang, T.-H. Chang, J. Li, and Z.-Q. Luo, "Distributed stochastic consensus optimization with momentum for nonconvex nonsmooth problems," *IEEE Trans. Signal Process.*, vol. 69, pp. 4486–4501, 2021.
- <span id="page-15-8"></span>[42] C. Chen, J. Zhang, L. Shen, P. Zhao, and Z. Luo, "Communication efficient primal-dual algorithm for nonconvex nonsmooth distributed optimization," in *Proc. Int. Conf. Artif. Intell. Statist. (ICAIS)*. PMLR, 2021, pp. 1594–1602.
- <span id="page-15-12"></span>[43] R. Xin, S. Das, U. A. Khan, and S. Kar, "A stochastic proximal gradient framework for decentralized non-convex composite optimization: Topology-independent sample complexity and communication efficiency," *arXiv preprint arXiv:2110.01594*, 2021.
- [44] G. Mancino-Ball, S. Miao, Y. Xu, and J. Chen, "Proximal stochastic recursive momentum methods for nonconvex composite decentralized optimization," in *AAAI*, vol. 37, no. 7, 2023, pp. 9055–9063.
- <span id="page-15-11"></span>[45] T. Xiao, X. Chen, K. Balasubramanian, and S. Ghadimi, "A one-sample decentralized proximal algorithm for non-convex stochastic composite optimization," in *Proc. Uncertainty Artif. Intell. Conf.* PMLR, 2023, pp. 2324–2334.
- <span id="page-15-0"></span>[46] Y. Liu and F. Xia, "Proximal variable smoothing method for threecomposite nonconvex nonsmooth minimization with a linear operator," *Numer. Algorithms*, pp. 1–30, 2023.
- <span id="page-15-3"></span>[47] S. Chen, A. Garcia, and S. Shahrampour, "On distributed nonconvex optimization: Projected subgradient method for weakly convex problems in networks," *IEEE Trans. Control Syst. Technol.*, vol. 67, no. 2, pp. 662–675, 2021.
- <span id="page-15-6"></span>[48] Y. Yan, J. Chen, P.-Y. Chen, X. Cui, S. Lu, and Y. Xu, "Compressed decentralized proximal stochastic gradient method for nonconvex composite problems with heterogeneous data," in *ICML*. PMLR, 2023, pp. 39 035–39 061.
- <span id="page-15-1"></span>[49] A. Bohm and S. J. Wright, "Variable smoothing for weakly convex ¨ composite functions," *J. Optim. Theory Appl.*, vol. 188, pp. 628–649, 2021.
- <span id="page-15-2"></span>[50] D. Zhu, L. Zhao, and S. Zhang, "A first-order primal-dual method for nonconvex constrained optimization based on the augmented Lagrangian," *Math. Oper. Res.*, vol. 49, no. 1, pp. 125–150, 2024.
- <span id="page-15-9"></span>[51] Q. Wang and D. Han, "A generalized inertial proximal alternating linearized minimization method for nonconvex nonsmooth problems," *Appl. Numer. Math.*, vol. 189, pp. 66–87, 2023.
- <span id="page-15-10"></span>[52] T. Pock and S. Sabach, "Inertial proximal alternating linearized minimization (iPALM) for nonconvex and nonsmooth problems," *SIAM J. Imag. Sci.*, vol. 9, no. 4, pp. 1756–1787, 2016.
- <span id="page-15-13"></span>[53] R. T. Rockafellar and R. J.-B. Wets, *Variational analysis*. Springer Science & Business Media, 2009, vol. 317.
- <span id="page-15-14"></span>[54] E. K. Ryu and W. Yin, *Large-scale convex optimization: algorithms & analyses via monotone operators*. Cambridge University Press, 2022.
- <span id="page-15-15"></span>[55] A. Beck, *First-order methods in optimization*. SIAM, 2017.
- <span id="page-15-16"></span>[56] D. Hajinezhad and M. Hong, "Perturbed proximal primal–dual algorithm for nonconvex nonsmooth optimization," *Math. Program.*, vol. 176, no. 1-2, pp. 207–245, 2019.
- <span id="page-15-17"></span>[57] A. Bernstein, E. Dall'Anese, and A. Simonetto, "Online primal-dual methods with measurement feedback for time-varying convex optimization," *IEEE Trans. Signal Process.*, vol. 67, no. 8, pp. 1978–1991, 2019.
- <span id="page-15-18"></span>[58] J. Koshal, A. Nedic, and U. V. Shanbhag, " ´ Multiuser optimization: Distributed algorithms and error analysis," *SIAM J. Optim.*, vol. 21, no. 3, pp. 1046–1081, 2011.
- <span id="page-15-19"></span>[59] Y. Zhang, E. Dall'Anese, and M. Hong, "Online proximal-ADMM for time-varying constrained convex optimization," *IEEE Trans. Signal Inf. Process. Netw.*, vol. 7, pp. 144–155, 2021.
- <span id="page-15-20"></span>[60] W. Deng and W. Yin, "On the global and linear convergence of the generalized alternating direction method of multipliers," *Comput. J. Sci. comput.*, vol. 66, pp. 889–916, 2016.
- <span id="page-15-21"></span>[61] H. Wang and A. Banerjee, "Bregman alternating direction method of multipliers," *Proc. Adv. Neural Inf. Process. Syst.*, vol. 27, 2014.
- <span id="page-15-22"></span>[62] P. Latafat, N. M. Freris, and P. Patrinos, "A new randomized blockcoordinate primal-dual proximal algorithm for distributed optimization," *IEEE Trans. Autom. Control*, vol. 64, no. 10, pp. 4050–4065, 2019.
- [63] H. Li, X. Wu, Z. Wang, and T. Huang, "Distributed primal-dual splitting algorithm for multiblock separable optimization problems," *IEEE Trans. Autom. Control*, vol. 67, no. 8, pp. 4264–4271, 2021.

- <span id="page-15-23"></span>[64] A. Koppel, B. M. Sadler, and A. Ribeiro, "Proximity without consensus in online multiagent optimization," *IEEE Trans. Signal Process.*, vol. 65, no. 12, pp. 3062–3077, 2017.
- <span id="page-15-24"></span>[65] X. Shi, X. Xu, J. Cao, and X. Yu, "Finite-time convergent primal–dual gradient dynamics with applications to distributed optimization," *IEEE Trans. Cybern.*, vol. 53, no. 5, pp. 3240–3252, 2022.
- <span id="page-15-25"></span>[66] X. Zeng, S. Liang, Y. Hong, and J. Chen, "Distributed computation of linear matrix equations: An optimization perspective," *IEEE Trans. Autom. Control*, vol. 64, no. 5, pp. 1858–1873, 2018.
- <span id="page-15-26"></span>[67] S. A. Alghunaim, "Local exact-diffusion for decentralized optimization and learning," *IEEE Trans. Autom. Control*, 2024.

Yuan Zhou received the B.S. degree in cyberspace security from Southeast University, Nanjing, China, in 2021. He is currently pursuing the Ph.D. degree in School of Cyber Science and Engineering, Southeast University, Nanjing, China. His current research focuses on distributed optimization and learning.

Xinli Shi (Senior Member) received the B.S. degree in software engineering, the M.S. degree in applied mathematics and the Ph.D. degree in control science and engineering from Southeast University, Nanjing, China, in 2013, 2016 and 2019, respectively. He was the recipient of the Outstanding Ph.D. Degree Thesis Award from Jiangsu Province, China. He is currently an associate professor at Southeast University. He is a recipient of the Australian Research Council Discovery Early Career Researcher Award. His current research interests include distributed optimization, reinforcement learning, and network control systems.

Luyao Guo received the B.S. degree in information and computing science from Shanxi University, Taiyuan, China, in 2020. He is currently pursuing the Ph.D. degree in applied mathematics with the Jiangsu Provincial Key Laboratory of Networked Collective Intelligence, School of Mathematics, Southeast University, Nanjing, China. His current research focuses on distributed optimization and learning.

Jinde Cao (Fellow, IEEE) received the B.S. degree in mathematics from Anhui Normal University, Wuhu, China in 1986, the M.S. degree from Yunnan University, Kunming, China, and the Ph.D. degree from Sichuan University, Chengdu, China, both in applied mathematics, 1989, and 1998, respectively. He was a Postdoctoral Research Fellow at the Department of Automation and Computer-Aided Engineering, Chinese University of Hong Kong, Hong Kong, China from 2001 to 2002.

Professor Cao is an Endowed Chair Professor, the Dean of Science Department and the Director of the Research Center for Complex Systems and Network Sciences at Southeast University (SEU). He is also the Director of the National Center for Applied Mathematics at SEU-Jiangsu of China and the Director of the Jiangsu Provincial Key Laboratory of Networked Collective Intelligence of China. He is also Honorable Professor of Institute of Mathematics and Mathematical Modeling, Almaty, Kazakhstan.

Prof. Cao was a recipient of the National Innovation Award of China, IETI Annual Scientific Award, Obada Prize and the Highly Cited Researcher Award in Engineering, Computer Science, and Mathematics by Clarivate Analytics. He is elected as a member of Russian Academy of Sciences, a member of the Academia Europaea (Academy of Europe), a member of Russian Academy of Engineering, a member of the European Academy of Sciences and Arts, a member of the Lithuanian Academy of Sciences, a fellow of African Academy of Sciences, and a fellow of Pakistan Academy of Sciences.

Mahmoud Abdel-Aty received the Ph.D. degree in quantum optics from the Max Planck Institute of Quantum Optics, Munich, Germany, in 1999, and the D.Sc. degree in 2007. He is currently the Director of the International Relations Center, Sohag University, Egypt, and the former Vice President of the African Academy of Sciences and the Dean of Research and Graduate Studies at Applied Science University, Kingdom of Bahrain. After his analytical study of quantum phenomena at Flensburg University, Germany, he joined the Quantum Information Group in Egypt. He is especially wellknown for his seminal contributions to theories of quantum measurement, nanomechanical modeling, highly nonclassical light, practical information security, and optical implementations of quantum information tasks. His current research interests include quantum resources and optical and atomic implementations of quantum information tasks and protocols. His research has been widely recognized and he has received several local and international awards. He obtained the Amin Lotfy Award in Mathematics, in 2003, the Mathematics State Award for Encouragement, in 2003, the Shoman Award for Arab Physicists, in 2005, the Third World Academy of Sciences Award in Physics, in 2005, the Fayza Al-Khorafy Award, in 2006, and the State Award for Excellence in Basic Science, in 2009. In 2014, he was elected as the Vice President of the African Academy of Science. In 2016, he was elected as a member of the governor council, GC, of the Egyptian Mathematical Society.