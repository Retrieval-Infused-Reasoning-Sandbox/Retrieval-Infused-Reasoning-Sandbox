# Stochastic Alternating Direction Method of Multipliers with Variance Reduction for Nonconvex Optimizations

Feihu Huang huangfeihu@nuaa.edu.cn

College of Computer Science and Technology

Nanjing University of Aeronautics and Astronautics, Nanjing, 210016, China

Songcan Chen s.chen@nuaa.edu.cn

College of Computer Science and Technology

Nanjing University of Aeronautics and Astronautics, Nanjing, 210016, China

Zhaosong Lu zhaosong@sfu.ca

Department of Mathematics,

Simon Fraser University, Burnaby, BC V5A 1S6, Canada

Editor: The first version is provided in October 9, 2016.

## Abstract

In the paper, we study the stochastic alternating direction method of multipliers (ADMM) for the nonconvex optimizations, and propose three classes of the nonconvex stochastic ADMM with variance reduction, based on different reduced variance stochastic gradients. Specifically, the first class called the nonconvex stochastic variance reduced gradient ADMM (SVRG-ADMM), uses a multi-stage scheme to progressively reduce the variance of stochastic gradients. The second is the nonconvex stochastic average gradient ADMM (SAG-ADMM), which additionally uses the old gradients estimated in the previous iteration. The third called SAGA-ADMM is an extension of the SAG-ADMM method. Moreover, under some mild conditions, we establish the iteration complexity bound of O(1/) of the proposed methods to obtain an -stationary solution of the nonconvex optimizations. In particular, we provide a general framework to analyze the iteration complexity of these nonconvex stochastic ADMM methods with variance reduction. Finally, some numerical experiments demonstrate the effectiveness of our methods.

Keywords: Alternating direction method of multipliers, Variance reduction, Stochastic gradient, Nonconvex optimizations, Robust graph-guided models

## 1. Introduction

Stochastic optimization method is a class of powerful optimization tool for solving large-scale problems in machine learning. For example, the stochastic gradient descent (SGD) [\(Bottou, 2004\)](#page-31-0) is an efficient method for solving the finite-sum optimization problem, which is a fundamental to machine learning. Specifically, the SGD only computes gradient of one sample instead of visiting all samples in each iteration. Though its scalability, due to the variance in the stochastic process, the SGD has slower convergence rate than the batch gradient method. Recently, many accelerated versions of the SGD have successfully been proposed to reduce the variances, and obtain some better convergence rates. For example, the stochastic average gradient (SAG) method [\(Roux et al., 2012\)](#page-33-0) obtains a fast convergence rate by incorporating the old gradients estimated in the previous iterations. The stochastic dual coordinate ascent (SDCA) method [\(Shalev-Shwartz and Zhang, 2013\)](#page-33-1) performs the stochastic coordinate ascent on the dual problems and also obtains a fast convergence rate. Moreover, an accelerated randomized proximal coordinate gradient method (APCG) [\(Lin et al., 2015\)](#page-32-0) accelerates the SDCA method by using the Nesterov's acceleration technique [\(Nesterov, 2004\)](#page-32-1). However, these accelerated methods obtain faster convergence rate than the standard SGD at the cost of

requiring much space to store old gradients or dual variables. To deal with this dilemma, thus, the stochastic variance reduced gradient (SVRG) methods [\(Johnson and Zhang, 2013;](#page-32-2) [Xiao and Zhang,](#page-33-2) [2014\)](#page-33-2) are proposed, and enjoy a fast convergence rate with no extra space to store the intermediate gradients or dual variables. Moreover, [Defazio et al. \(2014\)](#page-33-3) have proposed a novel method called SAGA, which extends the SAG method and enjoys better theoretical convergence rate than both the SAG and SVRG methods.

Though the above gradient-based methods can effectively solve many problems in machine learning, they are still difficultly competent for some complicated problems, such as the graph-guided SVM [\(Ouyang et al., 2013\)](#page-32-3) and the latent variable graphical models [\(Ma et al., 2013\)](#page-32-4). It is well known that the alternating direction method of multipliers (ADMM) [\(Gabay and Mercier, 1976;](#page-31-1) [Boyd et al., 2011\)](#page-31-2) has been advocated as an efficient optimization method in many application fields such as machine learning [\(Danaher et al., 2014\)](#page-31-3) and statistics [\(Fang et al., 2015\)](#page-31-4). However, the offline or batch ADMM need to compute an empirical risk loss function on all training samples at each iteration, which makes it unsuitable for large-scale learning problems. Thus, the online or stochastic versions of ADMM [\(Wang and Banerjee, 2012;](#page-33-4) [Suzuki, 2013;](#page-33-5) [Ouyang et al., 2013\)](#page-32-3) have been developed for the large-scale/stochastic optimizations. Due to the variance in the stochastic process, these initial stochastic ADMM methods also suffer from slow convergence rate. Recently, some accelerated stochastic ADMM methods are proposed to efficiently solve the large-scale learning problems. For example, a fast stochastic ADMM [\(Zhong and Kwok, 2014\)](#page-33-6) is proposed via incorporating the previous estimated gradients. [Azadi and Sra \(2014\)](#page-31-5) has proposed an accelerated stochastic ADMM by using Nesterov's accelerated method [\(Nesterov, 2004\)](#page-32-1). Moreover, an adaptive stochastic ADMM [\(Zhao et al., 2015a\)](#page-33-7) is proposed by using the adaptive stochastic gradients. The stochastic dual coordinate ascent ADMM [\(Suzuki, 2014\)](#page-33-8) obtains a fast convergence rate by solving the dual problems. More recently, the scalable stochastic ADMMs [\(Zhao et al., 2015b;](#page-33-9) [Zheng and](#page-33-10) [Kwok, 2016\)](#page-33-10) are developed, and obtain fast convergence rates with no extra space for the previous gradients or dual variables.

So far, the above study on stochastic optimization methods relies heavily on the strongly convex or convex objective functions. However, there exist many useful nonconvex models in machine learning such as the nonconvex robust empirical risk minimization models [\(Aravkin and Davis, 2016\)](#page-33-11) and deep learning [\(LeCun et al., 2015\)](#page-32-5). Thus, the study of stochastic optimization methods for the nonconvex problems is much needed. Recently, some works focus on studying the stochastic gradient methods for the nonconvex optimizations. For example, [Ghadimi and Lan \(2016\)](#page-32-6) and [Ghadimi et](#page-32-7) [al. \(2016\)](#page-32-7) have established the iteration complexity of O(1/<sup>2</sup> ) for the SGD to obtain an -stationary solution of the nonconvex optimizations. [Allen-Zhu and Hazan \(2016\)](#page-31-6); [Reddi et al. \(2016a,](#page-32-8)[b\)](#page-32-9) have proved that both the nonconvex SVRG and SAGA methods obtain an iteration complexity of O(1/) for the nonconvex optimizations. In particular, [Li et al. \(2016\)](#page-32-10) have studied the stochastic gradient method for nonconvex sparse learning via variance reduction, which reaches an asymptotically linear convergence rate by exploring the properties of the specific problems. Moreover, [Reddi et al. \(2016c\)](#page-32-11); [Aravkin and Davis \(2016\)](#page-33-11) have studied the variance reduced stochastic methods for the nonconvex nonsmooth composite problems, and have proved that they have the iteration complexity of O(1/). At the same time, [Hajinezhad et al. \(2016\)](#page-33-12) have proposed a nonconvex distributed and stochastic primal dual splitting method for the nonconvex nonsmooth problems and prove that it also has the iteration complexity of O(1/) to obtain an -stationary solution.

Similarly, the above nonconvex methods are difficult to be competent to some complicated nonconvex problems, such as the graph-guided regularization risk loss minimizations and tensor decomposition [\(Jiang et al., 2016\)](#page-32-12). Fortunately, it is found that the ADMM method can be well competent to these complicated nonconvex problems, though it may fail to converge sometimes. Recently, some work [\(Wang et al., 2015;](#page-33-13) [Yang et al., 2015;](#page-33-14) [Wang et al., 2015;](#page-33-15) [Hong et al., 2016;](#page-32-13) [Jiang et al., 2016\)](#page-32-12) begin to devote to the study of the ADMM method for the nonconvex optimizations. However, they mainly focus on studying the determinate ADMM for the nonconvex optimizations. Due to computing the empirical loss function on all the training examples at each iteration, these nonconvex ADMMs can not be well competent to the large-scale learning problems. Though Hong (2014) has proposed a distributed, asynchronous and incremental algorithm based on the ADMM method for the large-scale nonconvex problems, the proposed method is still difficult to be competent to these complicated nonconvex problems such as the graph-guided models, and its iteration complexity is not provided. At present, to the best of our knowledge, there still exists few study of the stochastic ADMM for the noncovex optimizations. In the paper, thus, we study the stochastic ADMM methods for solving the nonconvex nonsmooth stochastic optimizations as follows:

$$\min_{x,y} \mathbb{E}_{\xi}[F(x,\xi)] + g(y)$$
s.t.  $Ax + By = c$ , (1)

where  $f(x) = \mathbb{E}_{\xi}[F(x,\xi)]$  is a nonconvex and smooth function;  $\xi$  is a random vector; g(y) is non-smooth and possibly nonconvex;  $x \in R^p$ ,  $y \in R^q$ ,  $A \in R^{d \times p}$ ,  $B \in R^{d \times q}$  and  $c \in R^d$ . The problem (1) is inspired by the structural risk minimization in machine learning (Vapnik, 2013). Here, the random vector  $\xi$  obeys a fixed but unknown distribution, from which we are able to draw a set of i.i.d. samples. In general, it is difficult to evaluate  $\mathbb{E}_{\xi}[F(x,\xi)]$  exactly, so we use the sample average approximation  $\frac{1}{n}\sum_{i=1}^n F(x,\xi_i)$  to approximate it. Throughout the paper, let  $f(x) \doteq \frac{1}{n}\sum_{i=1}^n F(x,\xi_i) = \frac{1}{n}\sum_{i=1}^n f_i(x)$  denote the average sum of many nonconvex and smooth component functions  $f_i(x)$ ,  $\forall i \in \{1,2,\cdots,n\}$ .

Moreover, we propose three classes of nonconvex stochastic ADMM with variance reduction for the problem (1), based on different reduced variance stochastic gradients. Specifically, the first class called SVRG-ADMM uses a multi-stage scheme to progressively reduce the variance of stochastic gradients. The second called SAG-ADMM reduces the variance of stochastic gradient via additionally using the old gradients estimated in previous iteration. The third called SAGA-ADMM is an extension of SAG-ADMM, which uses an unbiased stochastic gradient as the SVRG-ADMM. In summary, our main contributions include three folds as follows:

- 1) We propose three classes of the nonconvex stochastic ADMM with variance reduction, based on different reduced variance stochastic gradients.
- 2) We study the convergence of the proposed methods, and prove that these methods have the iteration complexity bound of  $O(1/\epsilon)$  to obtain an  $\epsilon$ -stationary solution of the nonconvex problems. In particular, we provide a general framework to analyze the iteration complexity of the nonconvex stochastic ADMM with variance reduction.
- 3) Finally, some numerical experiments demonstrate the effectiveness of the proposed methods.

#### 1.1 Organization

The paper is organized as follows: In Section 2, we propose three classes of stochastic ADMM with variance reduction, based on different reduced variance stochastic gradients. In Section 3, we study the convergence and iterative complexity of the proposed methods. Section 4 presents some numerical experiments, whose results back up the effectiveness of our methods. In Section 5, we give some conclusions. Most details of the theoretical analysis and proofs are relegated to the the following Appendices.

#### 1.2 Notations

 $\|\cdot\|$  denotes the Euclidean norm of a vector or the spectral norm of a matrix.  $\partial f$  is subgradient of the function f.  $Q \succ 0$  implies the matrix Q is positive definite. Let  $\|x\|_Q^2 = x^T Q x$ . Let  $A^+$  denote the generalized inverse of matrix A. For a nonempty closed set  $\mathcal{C}$ ,  $\operatorname{dist}(x,\mathcal{C}) = \inf_{y \in \mathcal{C}} \|x - y\|$  denotes the distance from x to  $\mathcal{C}$ .

## 2. Stochastic ADMM methods for the Nonconvex Optimizations

In this section, we study stochastic ADMM methods for solving the nonconvex problem (1). First, we propose a simple nonconvex stochastic ADMM as a baseline, in which the variance of stochastic gradients is free. However, it is difficult to guarantee the convergence of this simple stochastic ADMM, and only obtain a slow convergence rate. Thus, we propose three classes of stochastic ADMM with variance reduction, based on different reduced variance stochastic gradients.

First, we review the standard ADMM for solving the problem (1), when  $\xi$  is deterministic. The augmented Lagrangian function of (1) is defined as

$$\mathcal{L}_{\rho}(x,y,\lambda) = f(x) + g(y) - \langle \lambda, Ax + By - c \rangle + \frac{\rho}{2} ||Ax + By - c||^2, \tag{2}$$

where  $\lambda$  is a Lagrange multiplier, and  $\rho$  is a penalty parameter. At t-th iteration, the ADMM executes the following update:

$$y_{t+1} = \arg\min_{y} \mathcal{L}_{\rho}(x_t, y, \lambda_t)$$
(3)

$$x_{t+1} = \arg\min_{x} \mathcal{L}_{\rho}(x, y_{t+1}, \lambda_t)$$
(4)

$$\lambda_{t+1} = \lambda_t - \rho (Ax_{t+1} + By_{t+1} - c). \tag{5}$$

When  $\xi$  is a random variable, we can still update the variables y and  $\lambda$  by (3) and (5), respectively. However, to update the variable x, we need define an approximated function of the form:

$$\hat{\mathcal{L}}_{\rho}(x, y, \lambda, v, \bar{x}) = f(\bar{x}) + v^{T}(x - \bar{x}) + \frac{\eta}{2} \|x - \bar{x}\|_{Q}^{2} - \langle \lambda, Ax + By - c \rangle + \frac{\rho}{2} \|Ax + By - c\|^{2},$$
 (6)

where  $\mathbb{E}[v] = \nabla f(\bar{x}), \, \eta > 0$  and  $Q \succ 0$ . By minimizing (6) on the variable x, we have

$$x \leftarrow (\eta Q + \rho A^T A)^{-1} \left( \eta Q \bar{x} - v - \rho A^T (By - c - \frac{\lambda}{\rho}) \right).$$

When  $A^TA$  is large, computing inversion of  $\eta Q + \rho A^TA$  is expensive. To avoid it, we can use the inexact Uzawa method (Zhang et al., 2011) to linearize the last term in (6), and choose Q = $(I - \frac{\rho}{r}A^TA)$ . When  $Q = (I - \frac{\rho}{r}A^TA)$ , by minimizing (6) on the variable x, we have

$$x \leftarrow \bar{x} - \frac{1}{\eta} \left( v + \rho A^T (A\bar{x} + By - c - \frac{\lambda}{\rho}) \right).$$

#### **Algorithm 1** S-ADMM for Nonconvex Optimization

- 1: **Input:** T, and  $\rho > 0$ ;
- 2: **Initialize:**  $x_0$ ,  $y_0$  and  $\lambda_0$ ;
- 3: **for**  $t = 0, 1, \dots, T 1$  **do**
- Uniformly randomly pick  $i_t$  from  $\{1, 2, \dots, n\}$ ;
- $y_{t+1} = \arg\min_{y} \mathcal{L}_{\rho}(x_t, y, \lambda_t);$
- $x_{t+1} = \arg\min_{x} \hat{\mathcal{L}}_{\rho}(x, y_{t+1}, \lambda_{t}, \nabla f_{i_{t}}(x_{t}), x_{t}); \\ \lambda_{t+1} = \lambda_{t} \rho(Ax_{t+1} + By_{t+1} c);$

- 9: **Output:** Iterate x and y chosen uniformly random from  $\{x_t, y_t\}_{t=1}^T$ .

Like as the initial stochastic ADMM (Ouvang et al., 2013) for convex problems, we propose a simple stochastic ADMM (S-ADMM) as a baseline for the problem (1). The algorithmic framework of the S-ADMM is given in Algorithm 2. Though  $\mathbb{E}[\nabla f_{i_*}(x)] = \nabla f(x)$ , there exists the variance  $\mathbb{E}\|\nabla f_{i_t}(x) - \nabla f(x)\|^2$  in stochastic process. To guarantee its convergence, we should choose a time-varying stepsize  $1/\eta_t$  in (6), as in (Ouyang et al., 2013). However, as stochastic learning proceeds, the gradual decreasing of the stepsize  $1/\eta_t$  generally leads to a slow convergence rate. In the following, thus, we propose three classes of stochastic ADMM with variance reduction for the problem (1), based on different reduced variance stochastic gradients.

#### 2.1 Nonconvex SVRG-ADMM

#### Algorithm 2 SVRG-ADMM for Nonconvex Optimization

```
1: Input: epoch length m, T, S = [T/m], \rho > 0;

2: Initialize: \tilde{x}^0 = x_m^0, y_m^0 and \lambda_m^0;

3: for s = 0, 1, \dots, S - 1 do

4: x_0^{s+1} = x_m^s, y_0^{s+1} = y_m^s and \lambda_0^{s+1} = \lambda_m^s;

5: \nabla f(\tilde{x}^s) = \frac{1}{n} \sum_{i=1}^n \nabla f_i(\tilde{x}^s);

6: for t = 0, 1, \dots, m-1 do

7: Uniformly randomly pick i_t from \{1, 2, \dots, n\};

8: y_{t+1}^{s+1} = \arg \min_y \mathcal{L}_{\rho}(x_t^{s+1}, y, \lambda_t^{s+1});

9: \hat{\nabla} f(x_t^{s+1}) = \nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s);

10: x_{t+1}^{s+1} = \arg \min_x \hat{\mathcal{L}}_{\rho}(x, y_{t+1}^{s+1}, \lambda_t^{s+1}, \hat{\nabla} f(x_t^{s+1}), x_t^{s+1});

11: \lambda_{t+1}^{s+1} = \lambda_t^{s+1} - \rho(Ax_{t+1}^{s+1} + By_{t+1}^{s+1} - c);

12: end for

13: \tilde{x}^{s+1} = x_m^{s+1};

14: end for

15: Output: Iterate x and y chosen uniformly random from \{(x_t^s, y_t^s)_{t=1}^m\}_{s=1}^S.
```

In the subsection, we propose a nonconvex SVRG-ADMM, via using a multi-stage scheme to progressively reduce the variance of stochastic gradients. The framework of the SVRG-ADMM method is given in Algorithm 1. Specifically, in Algorithm 2, the stochastic gradient  $\hat{\nabla} f(x_t^{s+1})$  is unbiased, i.e.,  $\mathbb{E}[\hat{\nabla} f(x_t^{s+1})] = \nabla f(x_t^{s+1})$ , and its variance is progressively reduced by computing the gradients of all sample one time in each outer loop. In the following, we give an upper bound of the variance of the stochastic gradient  $\hat{\nabla} f(x_t^{s+1})$ .

**Lemma 1** In Algorithm 2, set  $\Delta_t^{s+1} = \hat{\nabla}f(x_t^{s+1}) - \nabla f(x_t^{s+1})$ , where  $\hat{\nabla}f(x_t^{s+1}) = \nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s)$ , then the following inequality holds

$$\mathbb{E}\|\Delta_t^{s+1}\|^2 \le L^2 \|x_t^{s+1} - \tilde{x}^s\|^2, \tag{7}$$

where  $\mathbb{E}\|\Delta_t^{s+1}\|^2$  denotes the variance of stochastic gradient  $\hat{\nabla}f(x_t^{s+1})$ .

A detailed proof of Lemma 1 is provided in Appendix A. Lemma 1 shows that variance of the stochastic gradient  $\hat{\nabla} f(x_t^{s+1})$  has an upper bound  $O(\|x_t^{s+1} - \tilde{x}^s\|^2)$ . Due to  $\tilde{x}^s = x_m^s$ , as number of iterations increases, both  $x_t^{s+1}$  and  $\tilde{x}^s$  approach the same stationary point, thus the variance of stochastic gradient vanishes. Note that the stochastic ADMM for solving the nonconvex problem is difficult to converge to the global solution  $x^*$ , so we bound the variance with  $O(\|x_t^{s+1} - \tilde{x}^s\|^2)$  rather than the popular  $O(\|x - x^*\|^2)$  used in the convex problem.

### 2.2 Nonconvex SAG-ADMM

In the subsection, we propose a nonconvex SAG-ADMM by additionally using the old gradients estimated in the previous iteration. The framework of the SAG-ADMM method is given in Algorithm

## Algorithm 3 SAG-ADMM for Nonconvex Optimization

```
1: Input: x_0 \in R^d, y_0 \in R^q, z_i^0 = x_0 for i \in \{1, 2, \dots, n\}, number of iterations T;

2: Initialize: \psi_0 = \frac{1}{n} \sum_{i=1}^n \nabla f_i(z_i^0);

3: for t = 0, 1, \dots, T - 1 do

4: Uniformly randomly pick i_t, j_t from \{1, 2, \dots, n\};

5: y_{t+1} = \arg \min_y \mathcal{L}_{\rho}(x_t, y, \lambda_t);

6: \hat{\nabla} f(x_t) = \frac{1}{n} (\nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t)) + \psi_t;

7: x_{t+1} = \arg \min_x \hat{\mathcal{L}}_{\rho}(x, y_{t+1}, \lambda_t, \hat{\nabla} f(x_t), x_t);

8: \lambda_{t+1} = \lambda_t - \rho(Ax_{t+1} + By_{t+1} - c);

9: z_{j_t}^{t+1} = x_t and z_j^{t+1} = z_j^t for j \neq j_t;

10: \psi_{t+1} = \psi_t - \frac{1}{n} (\nabla f_{j_t}(z_{j_t}^t) - \nabla f_{j_t}(z_{j_t}^{t+1}));

11: end for

12: Output: Iterate x and y chosen uniformly random from \{x_t, y_t\}_{t=1}^T.
```

<span id="page-5-0"></span>Table 1: Summary of the stochastic gradients used in the proposed methods. Note that  $\nabla f(\tilde{x}^s) = \frac{1}{n} \sum_{i=1}^n f_i(\tilde{x}^s)$  and  $\psi_t = \frac{1}{n} \sum_{i=1}^n f_i(z_i^t)$ .

| Methods   | stochastic gradient                                                                   | upper bound of variance                                          | (un)biased |
|-----------|---------------------------------------------------------------------------------------|------------------------------------------------------------------|------------|
| S-ADMM    | $\nabla f_{i_t}(x_t)$                                                                 | unknown                                                          | unbiased   |
| SVRG-ADMM | $\nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s)$     | $L^2 \ x_t^{s+1} - \tilde{x}^s\ ^2$                              | unbiased   |
| SAG-ADMM  | $\frac{1}{n} \left( \nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t) \right) + \psi_t$ | $(1-\frac{1}{n})^2 \frac{L^2}{n} \sum_{i=1}^n   x_t - z_i^t  ^2$ | biased     |
| SAGA-ADMM | $\nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t) + \psi_t$                            | $\frac{L^2}{n} \sum_{i=1}^n \ x_t - z_i^t\ ^2$                   | unbiased   |

3. In Algorithm 3, though the stochastic gradient  $\hat{\nabla} f(x_t)$  is biased, i.e.,

$$\mathbb{E}[\hat{\nabla}f(x_t)] = \frac{1}{n}\nabla f(x_t) + (1 - \frac{1}{n})\psi_t \neq \nabla f(x_t),$$

its variance is progressively reduced. In the following, we give an upper bound of variance of the stochastic gradient  $\hat{\nabla} f(x_t)$ .

**Lemma 2** In Algorithm 3, set  $\Delta_t = \hat{\nabla} f(x_t) - \nabla f(x_t)$ , where  $\hat{\nabla} f(x_t) = \frac{1}{n} (\nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t)) + \psi_t$ , then the following inequality holds

$$\mathbb{E}\|\Delta_t\|^2 \le \left(1 - \frac{1}{n}\right)^2 \frac{L^2}{n} \sum_{i=1}^n \|x_t - z_i^t\|^2,\tag{8}$$

where  $\psi_t = \frac{1}{n} \sum_{j=1}^n \nabla f_j(z_j^t)$ , and  $\mathbb{E} \|\Delta_t\|^2$  denotes variance of the stochastic gradient  $\hat{\nabla} f(x_t)$ .

A detailed proof of Lemma 2 is provided in Appendix B. Lemma 2 shows that the variance of the stochastic gradient  $\hat{\nabla} f(x_t)$  has an upper bound of  $O((1-\frac{1}{n})^2 \frac{1}{n} \sum_{i=1}^n \|x_t - z_i^t\|^2)$ . As the number of iteration increases, both  $x_t$  and the stored points  $\{z^t\}_{i=1}^n$  approach the same stationary point, so the variance of stochastic gradient progressively reduces.

### 2.3 Nonconvex SAGA-ADMM

In the subsection, we propose a nonconvex SAGA-ADMM, which is an extension of the SAG-ADMM and uses an unbiased stochastic gradients as the SVRG-ADMM. The framework of the SAGA-ADMM method is given in Algorithm 4. In Algorithm 4, the stochastic gradient  $\hat{\nabla} f(x_t)$  is

#### Algorithm 4 SAGA-ADMM for Nonconvex Optimization

```
1: Input: x_0 \in R^d, y_0 \in R^q, z_i^0 = x_0 for i \in \{1, 2, \dots, n\}, number of iterations T;

2: Initialize: \psi_0 = \frac{1}{n} \sum_{i=1}^n \nabla f_i(z_i^0);

3: for t = 0, 1, \dots, T - 1 do

4: Uniformly randomly pick i_t, j_t from \{1, 2, \dots, n\};

5: y_{t+1} = \arg \min_y \mathcal{L}_{\rho}(x_t, y, \lambda_t);

6: \hat{\nabla} f(x_t) = \nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t) + \psi_t;

7: x_{t+1} = \arg \min_x \hat{\mathcal{L}}_{\rho}(x, y_{t+1}, \lambda_t, \hat{\nabla} f(x_t), x_t);

8: \lambda_{t+1} = \lambda_t - \rho(Ax_{t+1} + By_{t+1} - c);

9: z_{j_t}^{t+1} = x_t and z_j^{t+1} = z_j^t for j \neq j_t;

10: \psi_{t+1} = \psi_t - \frac{1}{n}(\nabla f_{j_t}(z_{j_t}^t) - \nabla f_{j_t}(z_{j_t}^{t+1}));

11: end for

12: Output: Iterate x and y chosen uniformly random from \{x_t, y_t\}_{t=1}^T.
```

unbiased, i.e.,  $\mathbb{E}[\hat{\nabla}f(x_t)] = \nabla f(x_t)$ , and its variance is progressively reduced via additionally also using the old gradients in the previous iterations. Similarly, we give an upper bound of the variance of the stochastic gradient  $\hat{\nabla}f(x_t)$ .

**Lemma 3** In Algorithm 4, set  $\Delta_t = \hat{\nabla} f(x_t) - \nabla f(x_t)$ , where  $\hat{\nabla} f(x_t) = \nabla f_{i_t}(x_t) - \nabla f_{i_t}(z_{i_t}^t) + \psi_t$ , then the following inequality holds

$$\mathbb{E}\|\Delta_t\|^2 \le \frac{L^2}{n} \sum_{i=1}^n \|x_t - z_i^t\|^2, \tag{9}$$

where  $\psi_t = \frac{1}{n} \sum_{j=1}^n \nabla f_j(z_j^t)$ , and  $\mathbb{E} \|\Delta_t\|^2$  denotes variance of the stochastic gradient  $\hat{\nabla} f(x_t)$ .

A detailed proof of Lemma 3 is provided in Appendix C. Lemma 3 shows that the variance of the stochastic gradient  $\hat{\nabla} f(x_t)$  has an upper bound  $O(\frac{1}{n}\sum_{i=1}^n \|x_t - z_i^t\|^2)$ . Similarly, both  $x_t$  and the stored points  $\{z^t\}_{i=1}^n$  approach the same stationary point, as the number of iteration increases. Thus, the variance of stochastic gradient progressively reduces. Note that the upper bound (9) loses a coefficient  $(1-\frac{1}{n})^2$  to the upper bound (8), due to using a unbiased stochastic gradient in the SAGA-ADMM.

To further clarify the different of the proposed methods, we summarize the stochastic gradients used in the proposed methods in Table 1. From Table 1, we can find that the SAG-ADMM only uses the biased stochastic gradient, while others use the unbiased stochastic gradient. In particular, the SAG-ADMM can reduce faster the variance of stochastic gradient than the SAGA-ADMM, at the expense of using a biased stochastic gradient.

#### 3. Convergence Analysis

In the section, we analyze the convergence and iteration complexity of the proposed methods. First, we give some mild assumptions regarding problem (1) as follows:

**Assumption 1** For  $\forall i \in \{1, 2, \dots, n\}$ , the gradient of function  $f_i$  is Lipschitz continuous with the constant  $L_i > 0$ , such that

$$\|\nabla f_i(x_1) - \nabla f_i(x_2)\| \le L_i \|x_1 - x_2\| \le L \|x_1 - x_2\|, \ \forall x_1, x_2 \in \mathbb{R}^p, \tag{10}$$

where  $L = \max_{i} L_{i}$ , and this is equivalent to

$$f_i(x_1) \le f_i(x_2) + \nabla f_i(x_2)^T (x_1 - x_2) + \frac{L}{2} ||x_1 - x_2||^2.$$
 (11)

**Assumption 2** f(x) and g(y) are all lower bounded, and denoting  $f^* = \min_x f(x)$  and  $g^* = \min_y g(y)$ .

**Assumption 3** g(y) is a proper lower semi-continuous function.

**Assumption 4** Matrix A has full row rank.

In the Assumption 1, since  $f(x) = \frac{1}{n} \sum_{i=1}^{n} f_i(x)$ , we have  $\|\nabla f(x_1) - \nabla f(x_2)\| \le L\|x_1 - x_2\|$  and  $f(x_1) \le f(x_2) + \nabla f(x_2)^T (x_1 - x_2) + \frac{L}{2} \|x_1 - x_2\|^2$ ,  $\forall x_1, x_2 \in R^p$ . Assumption 1 has been widely used in the convergence analysis of nonconvex algorithms (Allen-Zhu and Hazan, 2016; Reddi et al., 2016a). Assumptions 2-3 have been used in study of ADMM for nonconvex problems (Jiang et al., 2016). Assumption 4 has been used in the convergence analysis of ADMM (Deng and Yin, 2016).

Throughout the paper, let  $\sigma_A$  denote the smallest eigenvalues of matrix  $AA^T$ , and let  $\phi_{\min}$  and  $\phi_{\max}$  denote the smallest and largest eigenvalues of positive matrix Q, respectively. In the following, we define the  $\epsilon$ -stationary point of the nonconvex problem (1):

**Definition 4** For  $\epsilon > 0$ , the point  $(x^*, y^*, \lambda^*)$  is said to be an  $\epsilon$ -stationary point of the problem (1) if it holds that

$$\mathbb{E}\|\nabla f(x^*) - A^T \lambda^*\|^2 \le \epsilon,\tag{12}$$

$$\mathbb{E}\left[\operatorname{dist}(B^T\lambda^*, \partial g(y^*))\right]^2 \le \epsilon,\tag{13}$$

$$\mathbb{E}||Ax^* + By^* - c||^2 \le \epsilon,\tag{14}$$

where  $dist(y_0, \partial g(y)) := \inf\{\|y_0 - z\| : z \in \partial g(y)\}$ . If  $\epsilon = 0$ , the point  $(x^*, y^*, \lambda^*)$  is said to be a stationary point of the problem (1).

Note that combining the above inequalities (13-15) is equivalent to  $\mathbb{E}\left[\operatorname{dist}(0,\partial L(x^*,y^*,\lambda^*))\right]^2 \leq \epsilon$ , where

$$\partial L(x, y, \lambda) = \begin{bmatrix} \partial_x L(x, y, \lambda) \\ \partial_y L(x, y, \lambda) \\ \partial_\lambda L(x, y, \lambda) \end{bmatrix}.$$

Next, based the above assumptions and definition, we study the convergence and iteration complexity of the proposed methods. In particular, we provide a general framework to analyze the convergence and iteration complexity of stochastic ADMM methods with variance reduction. Specifically, the basic procedure is given as follows:

- First, we design a new sequence based on the sequence generated from the algorithm. For example, we design the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  in (15) for the SVRG-ADMM; the sequence  $\{\Phi_t\}_{t=1}^T$  in (21) for the SAG-ADMM; and the sequence  $\{\hat{\Phi}_t\}_{t=1}^T$  in (27) for the SAGA-ADMM.
- Second, we prove that the designed sequence is monotonically decreasing, and has a lower bound.
- Third, we define a **new variable** for the algorithm. For example, we define the variable  $\theta_t^s$  in (19) for the SVRG-ADMM; the variable  $\theta_t$  in (25) for the SAG-ADMM; and the variable  $\hat{\theta}_t$  in (31) for the SAGA-ADMM. Then, we prove the variable has an upper bound, based on the above results.
- Finally, we prove that  $\mathbb{E}[\operatorname{dist}(0,\partial L(x,y,\lambda))]^2$  is bounded by the above defined variable.

#### 3.1 Convergence Analysis of Nonconvex SVRG-ADMM

In the subsection, we study the convergence and iteration complexity of the SVRG-ADMM. First, given the sequence  $\{(x_t^s, y_t^s, \lambda_t^s)_{t=1}^m\}_{s=1}^S$  generated by Algorithm 2, then we define an useful sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  as follows:

$$\Psi_t^s = \mathbb{E}\left[\mathcal{L}_{\rho}(x_t^s, y_t^s, \lambda_t^s) + h_t^s(\|x_t^s - \tilde{x}^{s-1}\|^2 + \|x_{t-1}^s - \tilde{x}^{s-1}\|^2) + \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_{A\rho}} \|x_t^s - x_{t-1}^s\|^2\right], (15)$$

where the positive sequence  $\{(h_t^s)_{t=1}^m\}_{s=1}^S$  satisfies the following formation (16).

Next, we consider three important lemmas: the first gives the upper bound of  $\mathbb{E}\|\lambda_{t+1}^{s+1} - \lambda_t^{s+1}\|^2$ ; the second demonstrates that the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  is monotonically decreasing; then the third give the lower bound of the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$ .

**Lemma 5** Suppose the sequence  $\{(x_t^s, y_t^s, \lambda_t^s)_{t=1}^m\}_{s=1}^S$  is generated by the Algorithm 2. The following inequality holds

$$\begin{split} \mathbb{E} \|\lambda_{t+1}^{s+1} - \lambda_{t}^{s+1}\|^{2} \leq & \frac{5L^{2}}{\sigma_{A}} \mathbb{E} \|x_{t}^{s+1} - \tilde{x}^{s}\|^{2} + \frac{5L^{2}}{\sigma_{A}} \|x_{t-1}^{s+1} - \tilde{x}^{s}\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \mathbb{E} \|x_{t+1}^{s+1} - x_{t}^{s+1}\|^{2} \\ & + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}} \|x_{t}^{s+1} - x_{t-1}^{s+1}\|^{2}, \end{split}$$

where  $\sigma_A$  denotes the smallest eigenvalues of matrix  $AA^T$ , and  $\phi_{max}$  denotes the largest eigenvalues of positive matrix Q.

A detailed proof of Lemma 5 is provided in Appendix D. Lemma 5 shows the upper bound of  $\mathbb{E}\|\lambda_{t+1}^{s+1} - \lambda_t^{s+1}\|^2$ .

**Lemma 6** Suppose that the sequence  $\{(x_t^s, y_t^s, \lambda_t^s)_{t=1}^m\}_{s=1}^S$  is generated by Algorithm 2. Further suppose the positive sequence  $\{(h_t^s)_{t=1}^m\}_{s=1}^S$  satisfies

$$h_t^s = \begin{cases} (2+\beta)h_{t+1}^s + \frac{5L^2}{\sigma_A \rho}, & 1 \le t \le m-1; \\ \frac{10L^2}{\sigma_A \rho}, & t = m, \end{cases}$$
 (16)

for all  $s \in [S]$ . Denoting

$$\Gamma_{t}^{s} = \begin{cases} \eta \phi_{\min} + \frac{\sigma_{A} \rho}{2} - \frac{L}{2} - \frac{5(2\eta^{2} \phi_{\max}^{2} + L^{2})}{\sigma_{A} \rho} - (1 + \frac{1}{\beta}) h_{t+1}^{s}, & 1 \leq t \leq m - 1; \\ \eta \phi_{\min} + \frac{\sigma_{A} \rho}{2} - \frac{L}{2} - \frac{5(2\eta^{2} \phi_{\max}^{2} + L^{2})}{\sigma_{A} \rho} - h_{1}^{s+1}, & t = m \end{cases}$$

$$(17)$$

and letting  $\eta > 0$ ,  $\beta > 0$  and  $\rho > 0$  be chosen such that

$$\Gamma_t^s > 0, \ \forall t \in [m], \ \forall s \in [S],$$

then the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  is monotonically decreasing.

A detailed proof of Lemma 6 is provided in Appendix E. Lemma 6 shows that the sequence  $\{(\Psi^s_t)_{t=1}^m\}_{s=1}^S$  is monotonically decreasing. Next, we further clarify choosing the above parameters. We first define a function  $H(\eta) = \Gamma^s_t = \eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{5(2\eta^2 \phi_{\max}^2 + L^2)}{\sigma_A \rho} - (1 + \frac{1}{\beta}) h_{t+1}^s$ . For the function  $H(\eta)$ , when  $\eta = \frac{\sigma_A \rho \phi_{\min}}{20\phi_{\max}^2}$ , the function  $H(\eta)$  can reach the largest value

$$H_{\text{max}} = \frac{\sigma_A \rho}{40\chi^2} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{5L^2}{\sigma_A \rho} - (1 + \frac{1}{\beta})h_{t+1}^s,$$

where  $\chi = \frac{\phi_{\text{max}}}{\phi_{\text{min}}}$  denotes the conditional number of matrix Q. Since  $H(\eta) = \Gamma_t^s > 0$ , we have  $H_{\text{max}} > 0$ . Considering  $\sigma_A \rho > 1$ , then the parameter  $\rho$  should satisfy the following inequality

$$\rho \ge \frac{40\chi^2}{(1+20\chi^2)\sigma_A} \left[ \frac{L}{2} + 5L^2 + (1+\frac{1}{\beta})h_{t+1}^s \right]. \tag{18}$$

**Lemma 7** Suppose the sequence  $\{(x_t^s, y_t^s, \lambda_t^s)_{t=1}^m\}_{s=1}^S$  is generated by the Algorithm 2, and given the same conditions as in Lemma 6, the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  has a lower bound.

A detailed proof of Lemma 7 is provided in Appendix F. Next, based on the above lemmas, we analyze the convergence and iteration complexity of the SVRG-ADMM in the following. We first defines an useful variable  $\theta_t^s$  as follows:

$$\theta_t^s = \|x_t^s - \tilde{x}^{s-1}\|^2 + \|x_{t-1}^s - \tilde{x}^{s-1}\|^2 + \|x_{t+1}^s - x_t^s\|^2 + \|x_t^s - x_{t-1}^s\|^2. \tag{19}$$

**Theorem 8** Suppose the sequence  $\{(x_t^s, y_t^s, \lambda_t^s)_{t=1}^m\}_{s=1}^S$  is generated by the Algorithm 2. Denote  $\kappa_1 = 3(L^2 + \eta^2 \phi_{\max}^2), \ \kappa_2 = \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A \rho^2}, \ \kappa_3 = \rho^2 \|B\|_2^2 \|A\|_2^2, \ and \ \tau = \min\left\{\gamma, \omega\right\} > 0, \ where \gamma = \min_{t,s} \Gamma_t^s \ and \ \omega = \frac{5L^2}{\sigma_A \rho}.$  Letting

$$mS = T = \frac{\max(\kappa_1, \kappa_2, \kappa_3)}{\tau \epsilon} (\Psi_1^1 - \Psi^*), \tag{20}$$

where  $\Psi^*$  is a lower bound of the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$ , and denoting

$$(\hat{t}, \hat{s}) = \underset{1 \le t \le m, \ 1 \le s \le S}{\arg \min} \theta_t^s,$$

then  $(x_{\hat{t}}^{\hat{s}}, y_{\hat{t}}^{\hat{s}})$  is an  $\epsilon$ -stationary point of the problem (1).

A detailed proof of Theorem 8 is provided in Appendix G. Theorem 8 shows that the SVRG-ADMM is convergent and has the iteration complexity of  $O(1/\epsilon)$  to reach an  $\epsilon$ -stationary point, i.e., obtain a convergence rate  $O(\frac{1}{T})$ . From Theorem 8, we can find that the SVRG-ADMM ensures its convergence by progressively reducing the variance of stochastic gradients.

#### 3.2 Convergence Analysis of Nonconvex SAG-ADMM

In the subsection, we study the convergence and iteration complexity of the SAG-ADMM. First, given the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  generated by the Algorithm 3, then we define an useful sequence  $\{\Phi_t\}_{t=1}^T$  as follows

$$\Phi_{t} = \mathbb{E}\left[\mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \left(1 - \frac{1}{n}\right)^{2} \frac{\alpha_{t}}{n} \sum_{i=1}^{n} (\|x_{t} - z_{i}^{t}\|^{2} + \|x_{t-1} - z_{i}^{t-1}\|^{2}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2}\right],$$
(21)

where the positive sequence  $\{\alpha_t\}_{t=1}^T$  satisfies the equality (22).

Next, we consider three important lemmas: the first gives the upper bound of  $\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2$ ; the second demonstrates that the sequence  $\{\Phi_t\}_{t=1}^T$  is monotonically decreasing; the third gives the lower bound of the sequence  $\{\Phi_t\}_{t=1}^T$ .

**Lemma 9** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 3, then the following inequality holds

$$\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2 \le \left(1 - \frac{1}{n}\right)^2 \frac{5L^2}{\sigma_A n} \sum_{i=1}^n \mathbb{E}\|x_t - z_i^t\|^2 + \left(1 - \frac{1}{n}\right)^2 \frac{5L^2}{\sigma_A n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2 + \frac{5(\eta^2 \phi_{\max}^2)}{\sigma_A} \mathbb{E}\|x_{t+1} - x_t\|^2 + \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A} \|x_t - x_{t-1}\|^2.$$

A detailed proof of Lemma 9 is provided in Appendix H. Lemma 9 shows the upper bound of  $\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2$ . Next, we will prove that the sequence  $\{\Phi_t\}_{t=1}^T$  is monotonically decreasing.

**Lemma 10** Suppose that the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 3, and the positive sequence  $\{\alpha_t\}_{t=1}^T$  satisfies

$$\alpha_t = (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1} + \frac{5L^2}{\sigma_{A}\rho} + \frac{\vartheta L^2}{2}, \quad t = 1, 2, \dots, T.$$
 (22)

Denoting

$$\Gamma_t = \eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta} - \frac{5(2\eta^2 \phi_{\max}^2 + L^2)}{\sigma_A \rho} - \left(1 - \frac{1}{n}\right)^2 \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right) \alpha_{t+1},\tag{23}$$

and Letting  $\eta > 0$ ,  $\beta > 0$ ,  $\vartheta > 0$  and  $\rho > 0$  be chosen such that  $\Gamma_t > 0$  for  $t \ge 1$ , then the sequence  $\{\Phi_t\}_{t=1}^T$  is monotonically decreasing.

A detailed proof of Lemma 10 is provided in Appendix I. Similarly, we further clarify how to choose the above parameters. We first define a function  $H(\eta) = \Gamma_t = \eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta} - \frac{5(2\eta^2\phi_{\max}^2 + L^2)}{\sigma_{A\rho}} - \left(1 - \frac{1}{n}\right)^2 \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right)\alpha_{t+1}$ . For the function  $H(\eta)$ , when  $\eta = \frac{\sigma_A \rho \phi_{\min}}{20\phi_{\max}^2}$ , the function  $H(\eta)$  can reach the largest value

$$H_{\max} = \frac{\sigma_A \rho}{40\chi^2} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta} - \frac{5L^2}{\sigma_A \rho} - \left(1 - \frac{1}{n}\right)^2 \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right) \alpha_{t+1}.$$

Since  $H(\eta) = \Gamma_t > 0$ , we have  $H_{\text{max}} > 0$ . Considering  $\sigma_A \rho > 1$ , then the parameter  $\rho$  should satisfy the following inequality

$$\rho \ge \frac{40\chi^2}{(1+20\chi^2)\sigma_A} \left[ \frac{L}{2} + \frac{1}{2\vartheta} + 5L^2 + \left(1 - \frac{1}{n}\right)^2 \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right)\alpha_1 \right]. \tag{24}$$

**Lemma 11** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 3. Under the same conditions as in Lemma 10, the sequence  $\{\Phi_t\}_{t=1}^T$  has a lower bound.

A detailed proof of Lemma 11 is provided in Appendix J. In the following, we will study the convergence and iteration complexity of the SAG-ADMM based on the above lemmas. First, we defines an useful variable  $\theta_t$  as follows:

$$\theta_t = \|x_{t+1} - x_t\|^2 + \|x_t - x_{t-1}\|^2 + \left(1 - \frac{1}{n}\right)^2 \frac{1}{n} \sum_{i=1}^n \left(\|x_t - z_i^t\|^2 + \|x_{t-1} - z_i^{t-1}\|^2\right). \tag{25}$$

**Theorem 12** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by Algorithm 3. Let  $\kappa_1 = 3(L^2 + \eta^2 \phi_{\max}^2)$ ,  $\kappa_2 = \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A \rho^2}$  and  $\kappa_3 = \rho^2 \|B\|_2^2 \|A\|_2^2$ , and  $\tau = \min\left\{\gamma, \omega\right\} > 0$ , where  $\gamma = \min_t \Gamma_t$  and  $\omega = \min_t \left(1 - \frac{1}{n}\right)^2 \left[\left(2 + \beta - \frac{1 + \beta}{n}\right)\alpha_{t+1} + \frac{\vartheta L^2}{2}\right]$ . Letting

$$T = \frac{\max(\kappa_1, \kappa_2, \kappa_3)}{\epsilon \tau} (\Phi_1 - \Phi^*), \tag{26}$$

where  $\Phi^*$  denotes a lower bound of the sequence  $\{\Phi_t\}_{t=1}^T$ , and denoting

$$\hat{t} = \operatorname*{arg\,min}_{1 < t < T} \theta_t.$$

then  $(x_{\hat{t}}, y_{\hat{t}})$  is an  $\epsilon$ -stationary point of the problem (1).

A detailed proof of Theorem 12 is provided in Appendix K. Theorem 12 shows that the SAG-ADMM method has the iteration complexity of  $O(1/\epsilon)$  to reach an  $\epsilon$ -stationary point, i.e., obtain a convergence rate  $O(\frac{1}{T})$ .

#### 3.3 Convergence Analysis of Nonconvex SAGA-ADMM

In the subsection, we study the convergence and iteration complexity of the SAGA-ADMM. Similarly, we first define an useful sequence  $\{\hat{\Phi}_t\}_{t=1}^T$  as follows:

$$\hat{\Phi}_t = \mathbb{E}\left[\mathcal{L}_{\rho}(x_t, y_t, \lambda_t) + \frac{\alpha_t}{n} \sum_{i=1}^n (\|x_t - z_i^t\|^2 + \|x_{t-1} - z_i^{t-1}\|^2) + \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A \rho} \|x_t - x_{t-1}\|^2\right], (27)$$

where the positive sequence  $\{\alpha_t\}_{t=1}^T$  satisfies the equality (28).

Similarly, we consider three important lemmas: the first gives the upper bound of  $\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2$ ; the second demonstrates that the sequence  $\{\hat{\Phi}_t\}_{t=1}^T$  is monotonically decreasing; the third shows the lower bound of the sequence  $\{\hat{\Phi}_t\}_{t=1}^T$ .

**Lemma 13** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 4. The following inequality holds

$$\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2 \le \frac{5L^2}{\sigma_A n} \sum_{i=1}^n \mathbb{E}\|x_t - z_i^t\|^2 + \frac{5L^2}{\sigma_A n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2 + \frac{5(\eta^2 \phi_{\max}^2)}{\sigma_A} \mathbb{E}\|x_{t+1} - x_t\|^2 + \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A} \|x_t - x_{t-1}\|^2.$$

A detailed proof of lemma 13 is provided in Appendix L. Lemma 13 shows that  $\mathbb{E}\|\lambda_{t+1} - \lambda_t\|^2$  has an upper bound.

**Lemma 14** Suppose that the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 4, and the positive sequence  $\{\alpha_t\}_{t=1}^T$  satisfy

$$\alpha_t = (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1} + \frac{5L^2}{\sigma_A \rho}, \quad t = 1, 2, \dots, T.$$
 (28)

Denoting

$$\Gamma_t = \eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{5(2\eta^2 \phi_{\max}^2 + L^2)}{\sigma_A \rho} - (1 + \frac{1}{\beta} - \frac{1}{n\beta})\alpha_{t+1}, \tag{29}$$

and Letting  $\eta > 0$ ,  $\beta > 0$  and  $\rho > 0$  be chosen such that  $\Gamma_t > 0$  for  $t \ge 1$ , then the sequence  $\{\hat{\Phi}_t\}$  is monotonically decreasing.

A detailed proof of Lemma 14 is provided in Appendix M. Lemma 14 shows that the sequence  $\{\hat{\Phi}_t\}$  is monotonically decreasing. Next, we further clarify how to choose the above parameters used in Lemma 14. First, we define a function  $H(\eta) = \Gamma_t = \eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{5(2\eta^2 \phi_{\max}^2 + L^2)}{\sigma_A \rho} - (1 + \frac{1}{\beta} - \frac{1}{n\beta})\alpha_{t+1}$ . For the function  $H(\eta)$ , when  $\eta = \frac{\sigma_A \rho \phi_{\min}}{20\phi_{\max}^2}$ , the function  $H(\eta)$  can reach the largest value

$$H_{\text{max}} = \frac{\sigma_A \rho}{40\chi^2} + \frac{\sigma_A \rho}{2} - \frac{L}{2} - \frac{5L^2}{\sigma_A \rho} - (1 + \frac{1}{\beta} - \frac{1}{n\beta})\alpha_{t+1}.$$

Since  $H(\eta) = \Gamma_t > 0$ , we have  $H_{\text{max}} > 0$ . Considering  $\sigma_A \rho > 1$ , then the parameter  $\rho$  should satisfy the following inequality

$$\rho \ge \frac{40\chi^2}{(1+20\chi^2)\sigma_A} \left[ \frac{L}{2} + 5L^2 + \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right)\alpha_1 \right]. \tag{30}$$

**Lemma 15** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 4. Under the same conditions as in Lemma 14, the sequence  $\hat{\Phi}_t$  has a lower bound.

The proof of Lemma 15 can follow the proof of Lemma 11. In the following, we will study the convergence and iteration complexity of the SAGA-ADMM based on the above lemmas. First, we defines an useful variable  $\hat{\theta}_t$  as follows:

$$\hat{\theta}_t = \|x_{t+1} - x_t\|^2 + \|x_t - x_{t-1}\|^2 + \frac{1}{n} \sum_{i=1}^n (\|x_t - z_i^t\|^2 + \|x_{t-1} - z_i^{t-1}\|^2). \tag{31}$$

**Theorem 16** Suppose the sequence  $\{x_t, y_t, \lambda_t\}_{t=1}^T$  is generated by the Algorithm 4. Let  $\kappa_1 = 3(L^2 + \eta^2 \phi_{\max}^2)$ ,  $\kappa_2 = \frac{5(L^2 + \eta^2 \phi_{\max}^2)}{\sigma_A \rho^2}$  and  $\kappa_3 = \rho^2 \|B\|_2^2 \|A\|_2^2$ , and  $\tau = \min\left\{\gamma, \omega\right\} > 0$ , where  $\gamma = \min_t \Gamma_t$  and  $\omega = \min_t (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1}$ . Letting

$$T = \frac{\max(\kappa_1, \kappa_2, \kappa_3)}{\epsilon \tau} (\hat{\Phi}_1 - \hat{\Phi}^*), \tag{32}$$

where  $\hat{\Phi}^*$  is a lower bound of the sequence  $\{\hat{\Phi}_t\}_{t=1}^T$ , and denoting

$$\tilde{t} = \operatorname*{arg\,min}_{1 \le t \le T} \hat{\theta}_t,$$

then  $(x_{\tilde{t}}, y_{\tilde{t}})$  is an  $\epsilon$ -stationary point of the problem (1).

A detailed proof of Theorem 16 is provided in Appendix N. Theorem 16 shows that the SAGA-ADMM method has the iteration complexity of  $O(1/\epsilon)$  to reach an  $\epsilon$ -stationary point, i.e., obtain a convergence rate  $O(\frac{1}{T})$ .

#### 3.4 Convergence Analysis for Nonconvex S-ADMM

In the subsection, we will prove that the S-ADMM, in which the variance of stochastic gradients is free, is divergent under some conditions.

**Theorem 17** In Algorithm 1, given a constant stepsize parameter  $\eta$ , and let  $\delta > 0$  denote a constant. Suppose the variance of stochastic gradients satisfy  $\mathbb{E}\|\nabla f_{i_t}(x) - \nabla f(x)\|^2 \ge \delta^2$ . If  $\delta \ge 2(L + \eta \phi_{\max})\epsilon$ , the S-ADMM will be divergent.

A detailed proof of Theorem 17 is provided in Appendix O. Theorem 17 shows that when given a constant parameter  $\eta$ , the S-ADMM may be divergent. In other words, the variance of stochastic algorithms easily leads to the iteration points jumping from the neighbourhood of a stationary point to that of another stationary point of the nonconvex problems. Thus, we should consider controlling variance of the stochastic gradients, when design the stochastic ADMM for the nonconvex optimizations.

#### 4. Experiments

In this section, we will execute some numerical experiments to demonstrate the performances of the proposed methods for the nonconvex optimizations. In the following, all algorithms are implemented in MATLAB, and experiments are performed on a PC with an Intel i7-4770 CPU and 16GB memory.

#### 4.1 Experimental Setups

In the experiments, we focus on the binary classification with incorporating the correlations between features. Given a set of straining samples  $\{(a_i, b_i)\}_{i=1}^n$ , where  $a_i \in \mathbb{R}^d$ ,  $b_i \in \{-1, +1\}$ ,

<span id="page-13-1"></span>Table 2: Summary of data sets and regularization parameters used in our experiments.

| data sets | number of samples | dimensionality | $\lambda_1$ | $\lambda_2$          |
|-----------|-------------------|----------------|-------------|----------------------|
| a9a       | 32,561            | 123            | $10^{-4}$   | $1.2 \times 10^{-4}$ |
| covertype | 581,012           | 54             | $10^{-4}$   | $10^{-6}$            |
| mnist8m   | 1,100,000         | 784            | $10^{-3}$   | $1.2 \times 10^{-3}$ |

 $\forall i \in \{1, 2, \dots, n\}$ , then we solve the following noncovex robust graph-guided models, as the graphguided fused lasso (Kim et al., 2009),

$$\min_{x} \frac{1}{n} \sum_{i=1}^{n} f_i(x) + \lambda_1 ||Ax||_1 + \frac{\lambda_2}{2} ||x||_2^2,$$
(33)

where  $f_i(x) = \frac{1}{1 + \exp(b_i a_i^T x)}$  denotes the sigmoid loss function, which is nonconvex and smooth;  $\lambda_1$ and  $\lambda_2$  are positive regularization parameters. Specifically, let A = [G; I], where the matrix G is obtained by sparse inverse covariance matrix estimation (Friedman et al., 2008; Hsieh et al., 2014). In order to satisfy the ADMM formulation, we can introduce an additional variable y and rewrite the problem (33) as follows:

$$\min_{x,y} f(x) + g(y)$$
  
s.t.  $Ax - y = 0$ ,

s.t. 
$$Ax - y = 0$$

where  $f(x) = \frac{1}{n} \sum_{i=1}^{n} f_i(x) + \frac{\lambda_2}{2} ||x||_2^2$  and  $g(y) = \lambda_1 ||y||_1$ .

In the experiments, we use three publicly available datasets<sup>1</sup>, which are summarized in Table 2. For each dataset, we use half of the samples as training data, while use the rest as testing data. Note that we only consider classifying the first class in the dataset mnist8m. In the algorithms, we choose the initial solution  $x_0 = zeros(d,1)$  and  $\lambda_0 = A^+\nabla f(x_0)$ . At the same time, we fix the parameters  $\eta = 2$  and  $\rho = 6$ , and set Q = I. In particular, we consider two cases in Algorithm 1: the S-ADMM with a time-varying stepsize parameter  $\eta = 2\sqrt{t}$ ; the S-ADMM-F with a fixed parameter  $\eta = 2$ . In Table 2, we also provide some regularization parameters used in our experiments. In the SVRG-ADMM algorithm, we choose m=n. Finally, all experimental results are averaged over 10 repetitions.

![](_page_13_Figure_9.jpeg)

Figure 1: Test loss versus number of effective passes on the nonconvex graph-guided model.

<span id="page-13-0"></span><sup>1.</sup> a9a, covertype, and mnist8m are from the LIBSVM website (www.csie.ntu.edu.tw/ cjlin/libsvmtools/datasets/).

![](_page_14_Figure_0.jpeg)

Figure 2: Test loss *versus* time on the *nonconvex* graph-guided model.

![](_page_14_Figure_2.jpeg)

Figure 3: Objective value versus number of effective passes on the nonconvex graph-guided model.

![](_page_14_Figure_4.jpeg)

Figure 4: Objective value versus time on the nonconvex graph-guided model.

#### 4.2 Experimental Results

Figures 1-2 show that the test losses of both SVRG-ADMM and SAGA-ADMM faster decrease than that of both S-ADMM and S-ADMM-F, as the number of effective passes or time increase, where each effective pass estimates n component gradients. Figures 3-4 show that the objective values of both SVRG-ADMM and SAGA-ADMM also faster decrease than that of both S-ADMM and S-ADMM-F, as the number of effective passes or time increase. In particular, as number of effective passes or time increase, both test loss and objective value of S-ADMM-F are fluctuant. This implies that the S-ADMM-F may be divergent with a constant η. At the same time, though the S-ADMM with time-varying η<sup>t</sup> is convergence, but it only slowly converge to the local optimal solution due to existing of variance of stochastic gradients. In summary, these experimental results demonstrate the effectiveness of the proposed methods.

## 5. Conclusions

In the paper, we proposed three classes of the nonconvex stochastic ADMM methods with variance reduction, based on different reduced variance stochastic gradients. Moreover, we proved that the proposed methods have the iteration complexity bound of O(1/) to obtain an -stationary solution of the nonconvex optimizations. In particular, we provide a general framework to analyze the convergence and iteration complexity of stochastic ADMM methods with variance reduction. Finally, some numerical experiments demonstrate the effectiveness of our methods for solving the nonconvex optimizations. In the future work, we will focus on the study of the convergence and iteration complexity of the simple stochastic ADMM method. In addition, we will use the momentum acceleration technique to further accelerate the proposed stochastic ADMM methods.

# <span id="page-16-0"></span>Appendix A. Proof of Lemma 1

$$\begin{aligned} \mathbf{Proof} & \text{ Since } \hat{\nabla} f(x_t^{s+1}) = \nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s), \text{ we have} \\ & \mathbb{E} \|\Delta_t^{s+1}\|^2 = \mathbb{E} \|\nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s) - \nabla f(x_t^{s+1})\|^2 \\ & \stackrel{(i)}{=} \mathbb{E} \|\nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s)\|^2 - \|\nabla f(x_t^{s+1}) - \nabla f(\tilde{x}^s)\|^2 \\ & \leq \mathbb{E} \|\nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s)\|^2 \\ & = \frac{1}{n} \sum_{i=1}^n \|\nabla f_{i_t}(x_t^{s+1}) - \nabla f_{i_t}(\tilde{x}^s)\|^2 \\ & \stackrel{(ii)}{\leq} L^2 \|x_t^{s+1} - \tilde{x}^s\|^2. \end{aligned}$$

where the equality (i) holds by the equality E(ξ − Eξ) <sup>2</sup> = Eξ <sup>2</sup> − (Eξ) 2 for random variable ξ; the inequality (ii) holds by the Assumption 1.

# <span id="page-16-1"></span>Appendix B. Proof of the Lemma 2

Proof Since ψ<sup>t</sup> = n P<sup>n</sup> <sup>j</sup>=1 ∇f<sup>j</sup> (z t j ), we have

$$\mathbb{E}\|\Delta_{t}\|^{2} = \mathbb{E}\|\frac{1}{n}\left(\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i_{t}}^{t})\right) - \left(\nabla f(x_{t}) - \psi_{t}\right)\|^{2} \\
= \frac{1}{n^{2}}\mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i_{t}}^{t})\|^{2} + (1 - \frac{2}{n})\|\nabla f(x_{t}) - \psi_{t}\|^{2} \\
= \frac{1}{n^{3}}\sum_{i=1}^{n}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i}^{t})\|^{2} + (1 - \frac{2}{n})\frac{1}{n^{2}}\|\sum_{i=1}^{n}\left(\nabla f(x_{i_{t}}) - \nabla f_{i_{t}}(z_{i}^{t})\right)\|^{2} \\
\stackrel{(i)}{\leq} \frac{1}{n^{3}}\sum_{i=1}^{n}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i}^{t})\|^{2} + (1 - \frac{2}{n})\frac{1}{n}\sum_{i=1}^{n}\|\left(\nabla f(x_{i_{t}}) - \nabla f_{i_{t}}(z_{i}^{t})\right)\|^{2} \\
\stackrel{(ii)}{\leq} \left(1 - \frac{1}{n}\right)^{2}\frac{L^{2}}{n}\sum_{i=1}^{n}\|x_{t} - z_{i}^{t}\|^{2}.$$

where the equality (i) holds by the equality (P<sup>n</sup> <sup>i</sup>=1 ai) <sup>2</sup> ≤ n P<sup>n</sup> <sup>i</sup>=1 a 2 i ; the inequality (ii) holds by the Assumption 1.

## <span id="page-16-2"></span>Appendix C. Proof of the Lemma 3

**Proof** Since 
$$\psi_t = \frac{1}{n} \sum_{j=1}^n \nabla f_j(z_j^t)$$
, we have

$$\mathbb{E}\|\Delta_{t}\|^{2} = \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i_{t}}^{t}) + \psi_{t} - \nabla f(x_{t})\|^{2}$$

$$\stackrel{(i)}{=} \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i_{t}}^{t})\|^{2} - \|\nabla f(x_{t}) - \psi_{t}\|^{2}$$

$$\leq \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i_{t}}^{t})\|^{2}$$

$$= \frac{1}{n} \sum_{i=1}^{n} \|\nabla f_{i_{t}}(x_{t}) - \nabla f_{i_{t}}(z_{i}^{t})\|^{2}$$

$$\stackrel{(ii)}{\leq} \frac{L^{2}}{n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2}.$$

where the equality (i) holds by the equality  $\mathbb{E}(\xi - \mathbb{E}\xi)^2 = \mathbb{E}\xi^2 - (\mathbb{E}\xi)^2$  for random variable  $\xi$ , and  $\mathbb{E}[\nabla f_{i_t}(z_{i_t}^t)] = \frac{1}{n} \sum_{j=1}^n \nabla f_j(z_j^t) = \psi_t$ ; the inequality (ii) holds by the Assumption 1.

## <span id="page-17-0"></span>Appendix D. Proof of Lemma 5

**Proof** For notational simplicity, let  $x_t^{s+1} = x_t$ ,  $y_t^{s+1} = y_t$ ,  $\lambda_t^{s+1} = \lambda_t$ , and  $\tilde{x}^s = \tilde{x}$ . By the optimal condition of step 10 in Algorithm 2, we have

$$0 = \hat{\nabla} f(x_t) - A^T \lambda_t + \rho A^T (A x_{t+1} + B y_{t+1} - c) - \eta Q(x_t - x_{t+1})$$
  
=  $\hat{\nabla} f(x_t) - A^T \lambda_{t+1} - \eta Q(x_t - x_{t+1}),$ 

where the second equality is due to step 11 in Algorithm 2. Thus, we have

$$A^{T}\lambda_{t+1} = \hat{\nabla}f(x_t) - \eta Q(x_t - x_{t+1}). \tag{34}$$

By (34), we have

$$\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \sigma_{A}^{-1} \|A^{T} \lambda_{t+1} - A^{T} \lambda_{t}\|^{2}$$

$$\leq \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \hat{\nabla}f(x_{t-1}) - \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$= \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t-1}) + \nabla f(x_{t-1}) - \hat{\nabla}f(x_{t-1}) - \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$\leq \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{t} - x_{t+1}\|^{2}$$

$$+ \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}} \|x_{t-1} - x_{t}\|^{2}, \tag{35}$$

where the inequality (i) holds by the Assumption 1; and  $||Q(x-y)||^2 \le \phi_{\max}^2 ||x-y||^2$ , where  $\phi_{\max}$ denotes the largest eigenvalue of positive matrix Q. Taking expectation conditioned on information  $i_t$  to (35), we have

$$\mathbb{E}\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}}\|x_{t} - x_{t+1}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}}\|x_{t-1} - x_{t}\|^{2}$$

$$\stackrel{(i)}{\leq} \frac{5L^{2}}{\sigma_{A}} \mathbb{E}\|x_{t} - \tilde{x}\|^{2} + \frac{5L^{2}}{\sigma_{A}}\|x_{t-1} - \tilde{x}\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \mathbb{E}\|x_{t} - x_{t+1}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}}\|x_{t-1} - x_{t}\|^{2},$$

where the inequality (i) holds by the Lemma 1.

#### <span id="page-17-1"></span>Appendix E. Proof of Lemma 6

**Proof** This proof includes two parts: First, we will prove that the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$  is monotonically decreases over  $t \in \{1, 2, \dots, m\}$  in each epoch  $s \in \{1, 2, \dots, S\}$ ; Second, we will prove that  $\Psi_m^s \ge \Psi_1^{s+1}$  for any  $s \in \{1, 2, \dots, S\}$ . For notational simplicity, we omit the label s in the first part, i.e., let  $x_t^{s+1} = x_t$ ,  $y_t^{s+1} = y_t$ ,

 $\lambda_t^{s+1} = \lambda_t$ , and  $\tilde{x}^s = \tilde{x}$ . By the step 8 of Algorithm 2, we have

$$\mathcal{L}_{o}(x_{t}, y_{t+1}, \lambda_{t}) \le \mathcal{L}_{o}(x_{t}, y_{t}, \lambda_{t}). \tag{36}$$

By the optimal condition of step 10 in Algorithm 2, we have

$$0 = (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) - A^{T}\lambda_{t} + \rho(Ax_{t+1} + By_{t+1} - c) - \eta Q(x_{t} - x_{t+1})]$$

$$= (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - A^{T}\lambda_{t} + \rho A^{T}(Ax_{t+1} + By_{t+1} - c) - \eta Q(x_{t} - x_{t+1})]$$

$$\stackrel{(i)}{\leq} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T} (Ax_{t} - Ax_{t+1}) + \rho (Ax_{t} - Ax_{t+1})^{T} (Ax_{t+1} + By_{t+1} - c)$$

$$\stackrel{(ii)}{=} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T} (Ax_{t} + By_{t+1} - c) + \lambda_{t}^{T} (Ax_{t+1} + By_{t+1} - c) + \frac{\rho}{2} \|Ax_{t} + By_{t+1} - c\|^{2}$$

$$- \frac{\rho}{2} \|Ax_{t+1} + By_{t+1} - c\|^{2} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$= \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$+ \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$\stackrel{(iii)}{\leq} \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$- (\eta \phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2}) \|x_{t} - x_{t+1}\|^{2}, \tag{37}$$

where the inequality (i) holds by the Assumption 1; the equality (ii) holds by using the equality  $(a-b)^T(b-c) = \frac{1}{2}(\|a-c\|^2 - \|a-b\|^2 - \|b-c\|^2)$  on the term  $\rho(Ax_t - Ax_{t+1})^T(Ax_{t+1} + By_{t+1} - c)$ ; the inequality (iii) holds by using  $-\phi_{\min}\|x_{t+1} - x_t\|^2 \ge -\|x_{t+1} - x_t\|^2$  and  $-\sigma_A\|x_{t+1} - x_t\|^2 \ge -\|Ax_t - Ax_{t+1}\|^2$ . Then taking expectation conditioned on information  $i_t$  to (37), and using  $\mathbb{E}[\hat{\nabla}f(x_t)] = \nabla f(x_t)$ , we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_t)] \le \mathcal{L}_{\rho}(x_t, y_{t+1}, \lambda_t) - (\eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2}) \mathbb{E} \|x_t - x_{t+1}\|^2.$$
 (38)

By the step 11 of Algorithm 2, and taking expectation conditioned on information  $i_t$ , we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t})] = \frac{1}{\rho} \mathbb{E}\|\lambda_{t+1} - \lambda_{t}\|^{2} \\
\stackrel{(i)}{\leq} \frac{5L^{2}}{\sigma_{A}\rho} \mathbb{E}\|x_{t} - \tilde{x}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho} \|x_{t-1} - \tilde{x}\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho} \mathbb{E}\|x_{t+1} - x_{t}\|^{2} \\
+ \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2}, \tag{39}$$

where the inequality (i) holds by the Lemma 5. Combining (36), (38) with (39), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1})] \leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \frac{5L^{2}}{\sigma_{A}\rho} \mathbb{E}\|x_{t} - \tilde{x}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho} \|x_{t-1} - \tilde{x}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2} - (\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho}) \|x_{t+1} - x_{t}\|^{2}.$$

$$(40)$$

Next, considering  $\mathbb{E}||x_{t+1} - \tilde{x}||^2$ , we have

$$\mathbb{E}\|x_{t+1} - \tilde{x}\|^{2} = \mathbb{E}\|x_{t+1} - x_{t} + x_{t} - \tilde{x}\|^{2}$$

$$= \mathbb{E}[\|x_{t+1} - x_{t}\|^{2} + 2(x_{t+1} - x_{t})^{T}(x_{t} - \tilde{x}) + \|x_{t} - \tilde{x}\|^{2}]$$

$$\leq \mathbb{E}[\|x_{t+1} - x_{t}\|^{2} + 2(\frac{1}{2\beta}\|x_{t+1} - x_{t}\|^{2} + \frac{\beta}{2}\|x_{t} - \tilde{x}\|^{2}) + \|x_{t} - \tilde{x}\|^{2}]$$

$$= (1 + \frac{1}{\beta})\|x_{t+1} - x_{t}\|^{2} + (1 + \beta)\|x_{t} - \tilde{x}\|^{2},$$
(41)

where  $\beta > 0$ , and the inequality is due to the Cauchy inequality. Combining the inequalities (40) and (41), we have

$$\mathbb{E}\left[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t+1} - x_{t}\|^{2} + h_{t+1}^{s}(\|x_{t+1} - \tilde{x}\|^{2} + \|x_{t} - \tilde{x}\|^{2})\right] \\
\leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2} + \left[(2 + \beta)h_{t+1}^{s} + \frac{5L^{2}}{\sigma_{A}\rho}\right](\|x_{t} - \tilde{x}\|^{2} + \|x_{t-1} - \tilde{x}\|^{2}) \\
- \left[\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{5(2\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} - (1 + \frac{1}{\beta})h_{t+1}\right] \mathbb{E}\|x_{t+1} - x_{t}\|^{2} - (2 + \beta)h_{t+1}^{s}\|x_{t-1} - \tilde{x}\|^{2}, \\
(42)$$

where  $h_{t+1} > 0$ . Then using the definition of the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$ , (16) and (17) to (42), we have

$$\Psi_{t+1}^{s+1} \le \Psi_{t}^{s+1} - \Gamma_{t}^{s+1} \mathbb{E} \|x_{t+1}^{s+1} - x_{t}^{s+1}\|^{2} - (2+\beta)h_{t+1}^{s+1} \|x_{t-1}^{s+1} - \tilde{x}^{s}\|^{2}, \tag{43}$$

for any  $s \in \{0, 1, \dots, S-1\}$ . Since  $\Gamma_t^s > 0, \ \forall t \in \{1, 2, \dots, m\}$ , we prove the first part.

Next, we will prove the second part. We begin with considering the upper bound of  $\mathbb{E}\|\lambda_0^{s+1} - \lambda_1^{s+1}\|^2$ . Since  $\lambda_0^{s+1} = \lambda_m^s$  and  $x_0^{s+1} = x_m^s = \tilde{x}^s$ , we have

$$\mathbb{E}\|\lambda_{0}^{s+1} - \lambda_{1}^{s+1}\|^{2} = \mathbb{E}\|\lambda_{m}^{s} - \lambda_{1}^{s+1}\|^{2}$$

$$\leq \frac{1}{\sigma_{A}} \mathbb{E}\|A^{T}\lambda_{m}^{s} - A^{T}\lambda_{1}^{s+1}\|^{2}$$

$$\stackrel{(i)}{=} \frac{1}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{m-1}^{s}) - \hat{\nabla}f(x_{0}^{s+1}) - \eta Q(x_{m-1}^{s} - x_{m}^{s}) - \eta Q(x_{0}^{s+1} - x_{1}^{s+1})\|^{2}$$

$$\stackrel{(ii)}{=} \frac{1}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{m-1}^{s}) - \nabla f(x_{m-1}^{s}) + \nabla f(x_{m-1}^{s}) - \nabla f(x_{m}^{s})$$

$$- \eta Q(x_{m-1}^{s} - x_{m}^{s}) - \eta Q(x_{0}^{s+1} - x_{1}^{s+1})\|^{2}$$

$$\leq \frac{5L^{2}}{\sigma_{A}} \|x_{m-1}^{s} - \tilde{x}^{s-1}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}} \|x_{m-1}^{s} - x_{m}^{s}\|^{2}$$

$$+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{0}^{s+1} - x_{1}^{s+1}\|^{2}, \tag{44}$$

where the equality (i) holds by the equality (34), and the equality (ii) holds by the following result:

$$\hat{\nabla}f(x_0^{s+1}) = \nabla f_{i_t}(x_0^{s+1}) - \nabla f_{i_t}(\tilde{x}^s) + \nabla f(\tilde{x}^s)$$

$$= \nabla f_{i_t}(x_m^s) - \nabla f_{i_t}(x_m^s) + \nabla f(x_m^s)$$

$$= \nabla f(x_m^s).$$

By (36), we have

$$\mathcal{L}_{\rho}(x_0^{s+1}, y_1^{s+1}, \lambda_0^{s+1}) \le \mathcal{L}_{\rho}(x_0^{s+1}, y_0^{s+1}, \lambda_0^{s+1}) = \mathcal{L}_{\rho}(x_m^s, y_m^s, \lambda_m^s). \tag{45}$$

Similarly, by (38), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_1^{s+1}, y_1^{s+1}, \lambda_0^{s+1})] \le \mathcal{L}_{\rho}(x_0^{s+1}, y_1^{s+1}, \lambda_0^{s+1}) - (\eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2}) \mathbb{E} \|x_1^{s+1} - x_0^{s+1}\|^2. \tag{46}$$

Using (44), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{1}^{s+1}, y_{1}^{s+1}, \lambda_{1}^{s+1}) - \mathcal{L}_{\rho}(x_{1}^{s+1}, y_{1}^{s+1}, \lambda_{0}^{s+1})] = \frac{1}{\rho} \mathbb{E}\|\lambda_{0}^{s+1} - \lambda_{1}^{s+1}\|^{2}$$

$$\leq \frac{5L^{2}}{\sigma_{A}\rho} \|x_{m-1}^{s} - \tilde{x}^{s-1}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{m-1}^{s} - x_{m}^{s}\|^{2}$$

$$+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho} \|x_{1}^{s+1} - x_{0}^{s+1}\|^{2}.$$
(47)

Since  $\mathcal{L}_{\rho}(x_0^{s+1}, y_0^{s+1}, \lambda_0^{s+1}) = \mathcal{L}_{\rho}(x_m^s, y_m^s, \lambda_m^s)$ , by combining (45), (46) with (47), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{1}^{s+1}, y_{1}^{s+1}, \lambda_{1}^{s+1})] \leq \mathcal{L}_{\rho}(x_{m}^{s}, y_{m}^{s}, \lambda_{m}^{s}) + \frac{5L^{2}}{\sigma_{A}\rho} \|x_{m-1}^{s} - \tilde{x}^{s-1}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{m-1}^{s} - x_{m}^{s}\|^{2} - (\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho}) \mathbb{E}\|x_{1}^{s+1} - x_{0}^{s+1}\|^{2}.$$
(48)

Then using  $h_1^{s+1} = \frac{10L^2}{\sigma_A \rho}$ , we have

$$\mathbb{E}\left[\mathcal{L}_{\rho}(x_{1}^{s+1}, y_{1}^{s+1}, \lambda_{1}^{s+1}) + h_{1}^{s+1}[\|x_{1}^{s+1} - \tilde{x}^{s}\|^{2} + \|x_{0}^{s+1} - \tilde{x}^{s}\|^{2}] + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho}\|x_{1}^{s+1} - x_{0}^{s+1}\|^{2}\right] \\
\leq \mathcal{L}_{\rho}(x_{m}^{s}, y_{m}^{s}, \lambda_{m}^{s}) + \frac{10L^{2}}{\sigma_{A}\rho}[\|x_{m}^{s} - \tilde{x}^{s-1}\|^{2} + \|x_{m-1}^{s} - \tilde{x}^{s-1}\|^{2}] + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho}\|x_{m-1}^{s} - x_{m}^{s}\|^{2} \\
- (\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - h_{1}^{s+1} - \frac{L}{2} - \frac{10\eta^{2}\phi_{\max}^{2} + 5L^{2}}{\sigma_{A}\rho})\mathbb{E}\|x_{0}^{s+1} - x_{1}^{s+1}\|^{2} - \frac{5L^{2}}{\sigma_{A}\rho}\|x_{m-1}^{s} - \tilde{x}^{s-1}\|^{2} \\
- \frac{10L^{2}}{\sigma_{A}\rho}\|x_{m}^{s} - \tilde{x}^{s-1}\|^{2}.$$
(49)

Finally, using the definition of the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$ , (16) and (17) to (49), we have

$$\Psi_1^{s+1} \le \Psi_m^s - \Gamma_m^s \mathbb{E} \|x_0^{s+1} - x_1^{s+1}\|^2 - \frac{5L^2}{\sigma_A \rho} [\|x_{m-1}^s - \tilde{x}^{s-1}\|^2.$$
 (50)

Since  $\Gamma_m^s > 0$ ,  $\forall s \ge 1$ , we can obtain the above result of the second part. Thus, we prove the above conclusion.

## <span id="page-20-0"></span>Appendix F. Proof of Lemma 7

**Proof** By definition of the sequence  $\{(\Psi_t^s)_{t=1}^m\}_{s=1}^S$ , we have

$$\Psi_{t}^{s} \geq \mathbb{E}[\mathcal{L}_{\rho}(x_{t}^{s}, y_{t}^{s}, \lambda_{t}^{s})] 
= f(x_{t}^{s}) + g(y_{t}^{s}) - (\lambda_{t}^{s})^{T} (Ax_{t}^{s} + By_{t}^{s} - c) + \frac{\rho}{2} ||Ax_{t}^{s} + By_{t}^{s} - c||^{2} 
\stackrel{(i)}{=} f(x_{t}^{s}) + g(y_{t}^{s}) - \frac{1}{\rho} (\lambda_{t}^{s})^{T} (\lambda_{t-1}^{s} - \lambda_{t}^{s}) + \frac{1}{2\rho} ||\lambda_{t-1}^{s} - \lambda_{t}^{s}||^{2} 
= f(x_{t}^{s}) + g(y_{t}^{s}) - \frac{1}{2\rho} ||\lambda_{t-1}^{s}||^{2} + \frac{1}{2\rho} ||\lambda_{t}^{s}||^{2} + \frac{1}{\rho} ||\lambda_{t} - \lambda_{t-1}||^{2} 
\stackrel{(ii)}{\geq} f^{*} + g^{*} - \frac{1}{2\rho} ||\lambda_{t-1}^{s}||^{2} + \frac{1}{2\rho} ||\lambda_{t}^{s}||^{2},$$
(51)

where the equality (i) holds by the step 11 of Algorithm 2, and the inequality (ii) holds by Assumption 2.

Summing the inequality (51) over  $t = 1, 2, \dots, m$  and  $s = 1, 2, \dots, S$ , we have

$$\frac{1}{T} \sum_{s=1}^{S} \sum_{t=1}^{m} \Psi_{t}^{s} \ge f^{*} + g^{*} - \frac{1}{2\rho} \|\lambda_{0}^{1}\|^{2}.$$

Therefore, we can obtain the above result.

## <span id="page-21-0"></span>Appendix G. Proof of Theorem 8

**Proof** Using the above inequalities (43) and (50), we have

$$\Psi_{t+1}^{s} \le \Psi_{t}^{s} - \Gamma_{t}^{s} \mathbb{E} \|x_{t+1}^{s} - x_{t}^{s}\|^{2} - (2+\beta)h_{t+1}^{s} \|x_{t-1}^{s} - \tilde{x}^{s-1}\|^{2}, \tag{52}$$

and

$$\Psi_1^{s+1} \le \Psi_m^s - \Gamma_m^s \mathbb{E} \|x_0^{s+1} - x_1^{s+1}\|^2 - \frac{5L^2}{\sigma_A \rho} \|x_m^s - \tilde{x}^{s-1}\|^2.$$
 (53)

for any  $s \in \{1, 2, \dots, S\}$  and  $t \in \{1, 2, \dots, m\}$ . Summing (52) and (53) over  $t = 1, 2, \dots, m$  and  $s = 1, 2, \dots, S$ , we have

$$\Psi_m^S - \Psi_1^1 \le -\gamma \sum_{s=1}^S \sum_{t=1}^m \mathbb{E} \|x_t^s - x_{t-1}^s\|^2 - \omega \sum_{s=1}^S \sum_{t=1}^m \|x_{t-1}^s - \tilde{x}^{s-1}\|^2$$
 (54)

where  $\gamma = \min_{s,t} \Gamma_t^s$ , and  $\omega = \min_{s,t} \{(2+\beta)h_{t+1}^s, \frac{5L^2}{\sigma_{A\rho}}\} = \frac{5L^2}{\sigma_{A\rho}}$ . From Lemma 7, there exists a low bound  $\Psi^*$  of the sequence  $\{\Psi_t^s\}$ , i.e.,  $\Psi_t^s \geq \Psi^*$ . Using (54) and the definition of  $\theta_t^s$ , we have

$$\theta_{\hat{t}}^{\hat{s}} = \min_{s,t} \theta_{t}^{s} \le \frac{1}{\tau T} (\Psi_{1}^{1} - \Psi^{*}), \tag{55}$$

where  $\tau = \min(\gamma, \omega)$ , and T = mS, so  $\theta_{\hat{t}}^{\hat{s}} = O(\frac{1}{T})$ .

Next, we give the upper bounds to the terms in (11-13) by using  $\theta_t^s$ . By (34), we have

$$\mathbb{E}\|A^{T}\lambda_{t}^{s} - \nabla f(x_{t}^{s})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t-1}^{s}) - \nabla f(x_{t}^{s}) - \eta Q(x_{t-1}^{s} - x_{t}^{s})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t-1}^{s}) - \nabla f(x_{t-1}^{s}) + \nabla f(x_{t-1}^{s}) - \nabla f(x_{t}^{s}) - \eta Q(x_{t-1}^{s} - x_{t}^{s})\|^{2}$$

$$\leq 3L^{2}\|x_{t-1}^{s} - \tilde{x}^{s-1}\|^{2} + 3(L^{2} + \eta^{2}\phi_{\max}^{2})\|x_{t-1}^{s} - x_{t}^{s}\|^{2}$$

$$\leq 3(L^{2} + \eta^{2}\phi_{\max}^{2})\theta_{t}^{s}.$$
(56)

By using the step 11 of Algorithm 2 and the Lemma 5, we have

$$\mathbb{E}\|Ax_{t+1}^{s} + By_{t+1}^{s} - c\|^{2} = \frac{1}{\rho^{2}}\|\lambda_{t+1}^{s} - \lambda_{t}^{s}\|^{2}$$

$$\leq \frac{5L^{2}}{\sigma_{A}\rho^{2}}\mathbb{E}\|x_{t}^{s} - \tilde{x}^{s-1}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho^{2}}\|x_{t-1}^{s} - \tilde{x}^{s-1}\|^{2}$$

$$+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho^{2}}\mathbb{E}\|x_{t+1}^{s} - x_{t}^{s}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}}\|x_{t}^{s} - x_{t-1}^{s}\|^{2}$$

$$\leq \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}}\theta_{t}^{s}. \tag{57}$$

By the step 8 of Algorithm 2, there exists a sub-gradient  $\mu \in \partial g(y_t^s)$  such that

$$\begin{split} \mathbb{E} \big[ \mathrm{dist}(B^T \lambda_t^s, \partial g(y_t^s)) \big]^2 &\leq \|\mu - B^T \lambda_t^s\|^2 \\ &= \|B^T \lambda_{t-1}^s - \rho B^T (A x_{t-1}^s + B y_t^s - c) - B^T \lambda_t^s \|^2 \\ &= \|\rho B^T A (x_t^s - x_{t-1}^s) \|^2 \\ &\leq \rho^2 \|B\|_2^2 \|A\|_2^2 \|x_t^s - x_{t-1}^s\|^2 \\ &\leq \rho^2 \|B\|_2^2 \|A\|_2^2 \theta_t^s. \end{split} \tag{58}$$

Finally, using the Definition 4 and (20), we can conclude that the SVRG-ADMM converges an  $\epsilon$ -stationary point of the problem (1).

## <span id="page-22-0"></span>Appendix H. Proof of the Lemma 9

**Proof** By the optimal condition of step 7 in Algorithm 3, we have

$$0 = \hat{\nabla} f(x_t) - A^T \lambda_t + \rho A^T (A x_{t+1} + B y_{t+1} - c) - \eta Q(x_t - x_{t+1})$$
  
=  $\hat{\nabla} f(x_t) - A^T \lambda_{t+1} - \eta Q(x_t - x_{t+1}),$ 

where the second equality is due to step 8 in Algorithm 3. Thus, we have

$$A^{T}\lambda_{t+1} = \hat{\nabla}f(x_t) - \eta Q(x_t - x_{t+1}). \tag{59}$$

By (59), we have

$$\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \sigma_{A}^{-1} \|A^{T}\lambda_{t+1} - A^{T}\lambda_{t}\|^{2}$$

$$\leq \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \hat{\nabla}f(x_{t-1}) - \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$= \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t-1}) + \nabla f(x_{t-1}) - \hat{\nabla}f(x_{t-1})$$

$$- \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$\stackrel{i}{\leq} \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{t} - x_{t+1}\|^{2}$$

$$+ \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}} \|x_{t-1} - x_{t}\|^{2}, \tag{60}$$

where the inequality (i) holds by the Assumption 1.

Taking expectation conditioned on information  $i_t$  to (60), we have

$$\mathbb{E}\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2} 
+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}}\|x_{t} - x_{t+1}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}}\|x_{t-1} - x_{t}\|^{2} 
\stackrel{(i)}{\leq} \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2} + \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2} 
+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}}\|x_{t+1} - x_{t}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}}\|x_{t} - x_{t-1}\|^{2},$$

where the inequality (i) holds by the Lemma 2.

## <span id="page-23-0"></span>Appendix I. Proof of the Lemma 10

**Proof** By the step 5 of Algorithm 3, we have

$$\mathcal{L}_{\rho}(x_t, y_{t+1}, \lambda_t) \le \mathcal{L}_{\rho}(x_t, y_t, \lambda_t). \tag{61}$$

Considering the optimal condition of step 7 in Algorithm 3, we have

$$0 = (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) + \rho A^{T}(Ax_{t+1} + By_{t+1} - c) - A^{T}\lambda_{t} - \eta Q(x_{t} - x_{t+1})]$$

$$= (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - A^{T}\lambda_{t} - \eta Q(x_{t} - x_{t+1}) + \rho A^{T}(Ax_{t+1} + By_{t+1} - c)]$$

$$\stackrel{(i)}{\leq} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T}(Ax_{t+1} - Ax_{t}) + \rho (Ax_{t} - Ax_{t+1})^{T} (Ax_{t+1} + By_{t+1} - c)$$

$$\stackrel{(ii)}{=} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T}(Ax_{t} + By_{t+1} - c) + \lambda_{t}^{T}(Ax_{t+1} + By_{t+1} - c) + \frac{\rho}{2} \|Ax_{t} + By_{t+1} - c\|^{2}$$

$$- \frac{\rho}{2} \|Ax_{t+1} + By_{t+1} - c\|^{2} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$= \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$+ \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$\stackrel{(iii)}{\leq} \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$- (\eta \phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2}) \|x_{t} - x_{t+1}\|^{2}$$

$$\stackrel{(vi)}{\leq} \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + \frac{1}{2\vartheta} \|x_{t} - x_{t+1}\|^{2} + \frac{\vartheta}{2} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2}$$

$$- (\eta \phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2}) \|x_{t} - x_{t+1}\|^{2}$$

$$(62)$$

where the inequality (i) holds by the Assumption 1; the equality (ii) holds by using the equality  $(a-b)^T(b-c) = \frac{1}{2}(\|a-c\|^2 - \|a-b\|^2 - \|b-c\|^2)$  on the term  $\rho(Ax_t - Ax_{t+1})^T(Ax_{t+1} + By_{t+1} - c)$ ; the inequality (iii) holds by using  $-\phi_{\min}\|x_{t+1} - x_t\|^2 \ge -\|x_{t+1} - x_t\|_Q^2$  and  $-\sigma_A\|x_{t+1} - x_t\|^2 \ge -\|Ax_t - Ax_{t+1}\|^2$ ; the inequality (vi) holds by the Cauchy inequality.

Then taking expectation conditioned on information  $i_t$  to (62), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t})] \leq \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - (\eta \phi_{\min} + \frac{\sigma_{A} \rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta}) \|x_{t} - x_{t+1}\|^{2} + \mathbb{E}[\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2}]$$

$$\stackrel{(i)}{\leq} \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - (\eta \phi_{\min} + \frac{\sigma_{A} \rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta}) \|x_{t} - x_{t+1}\|^{2} + (1 - \frac{1}{n})^{2} \frac{\vartheta L^{2}}{2n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2},$$
(63)

where the inequality (i) holds by Lemma 2. By the step 8 of Algorithm 3, and taking expectation conditioned on information it, we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t})] = \frac{1}{\rho} \mathbb{E}[\|\lambda_{t} - \lambda_{t+1}\|^{2}]$$

$$\stackrel{(i)}{\leq} \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2} + \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2}$$

$$+ \frac{5(\eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t+1} - x_{t}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2}, \tag{64}$$

where the inequality (i) holds by the Lemma 9. Combining (61), (63) with (64), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1})] \leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \left(1 - \frac{1}{n}\right)^{2} \left(\frac{5L^{2}}{\sigma_{A}\rho n} + \frac{\vartheta L^{2}}{2n}\right) \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2}$$

$$+ \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2}$$

$$- \left(\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta} - \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho}\right) \|x_{t+1} - x_{t}\|^{2}.$$

$$(65)$$

Next, considering <sup>1</sup> n P<sup>n</sup> <sup>i</sup>=1 <sup>E</sup>kxt+1 <sup>−</sup> <sup>z</sup> t+1 i 2 , we have

$$\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} \|x_{t+1} - z_i^{t+1}\|^2 = \frac{1}{n} \sum_{i=1}^{n} \left[ \frac{1}{n} \mathbb{E} \|x_{t+1} - x_t\|^2 + \frac{n-1}{n} \mathbb{E} \|x_{t+1} - z_i^t\|^2 \right].$$
 (66)

The term Ekxt+1 − z t i 2 in (66) can be bounded as follows:

$$\begin{split} \mathbb{E}\|x_{t+1} - z_i^t\|^2 &= \mathbb{E}\|x_{t+1} - x_t + x_t - z_i^t\|^2 \\ &= \mathbb{E}[\|x_{t+1} - x_t\|^2 + 2(x_{t+1} - x_t)^T (x_t - z_i^t) + \|x_{t-1} - z_i^t\|^2] \\ &\leq \mathbb{E}[\|x_{t+1} - x_t\|^2 + 2(\frac{1}{2\beta} \mathbb{E}\|x_{t+1} - x_t\|^2 + \frac{\beta}{2} \|x_t - z_i^t\|^2) + \|x_t - z_i^t\|^2] \\ &= (1 + \frac{1}{\beta}) \mathbb{E}\|x_{t+1} - x_t\|^2 + (1 + \beta) \|x_t - z_i^t\|^2, \end{split}$$

where β > 0, and the inequality is due to the Cauchy inequality. Then, we have

$$\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} \|x_{t+1} - z_i^{t+1}\|^2 \le \left(1 + \frac{(n-1)}{n\beta}\right) \mathbb{E} \|x_{t+1} - x_t\|^2 + \left(1 + \beta\right) \frac{n-1}{n^2} \sum_{i=1}^{n} \|x_t - z_i^t\|$$
 (67)

Combining (65) with (67), we have

$$\mathbb{E}\left[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t+1} - x_{t}\|^{2} + \left(1 - \frac{1}{n}\right)^{2} \frac{\alpha_{t+1}}{n} \sum_{i=1}^{n} (\|x_{t+1} - z_{i}^{t+1}\|^{2} + \|x_{t} - z_{i}^{t}\|^{2})\right] \\
\leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2} \\
+ \left(1 - \frac{1}{n}\right)^{2} \left[(2 + \beta - \frac{1 + \beta}{n})\alpha_{t+1} + \frac{5L^{2}}{\sigma_{A}\rho} + \frac{\vartheta L^{2}}{2}\right] \frac{1}{n} \sum_{i=1}^{n} \left(\|x_{t} - z_{i}^{t}\|^{2} + \|x_{t-1} - z_{i}^{t-1}\|^{2}\right) \\
- \left[\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{1}{2\vartheta} - \frac{5(2\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} - \left(1 - \frac{1}{n}\right)^{2} \left(1 + \frac{1}{\beta} - \frac{1}{n\beta}\right)\alpha_{t+1}\right] \|x_{t+1} - x_{t}\|^{2} \\
- \left(1 - \frac{1}{n}\right)^{2} \left[(2 + \beta - \frac{1 + \beta}{n})\alpha_{t+1} + \frac{\vartheta L^{2}}{2}\right] \frac{1}{n} \sum_{i=1}^{n} \|x_{t-1} - z_{i}^{t-1}\|^{2}. \tag{68}$$

Finally, using the definition of the sequence {Φt} T <sup>t</sup>=1, (22) and (23), we have

$$\Phi_{t+1} \le \Phi_t - \Gamma_t \|x_{t+1} - x_t\|^2 - \left(1 - \frac{1}{n}\right)^2 \left[ (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1} + \frac{\vartheta L^2}{2} \right] \frac{1}{n} \|x_{t-1} - z_i^{t-1}\|^2.$$
 (69)

Since Γ<sup>t</sup> > 0 for any t ∈ {1, 2, · · · , T}, we can obtain the above result.

# <span id="page-25-0"></span>Appendix J. Proof of the Lemma 11

Proof By the definition of the sequence {Φt} T <sup>t</sup>=1, we have

$$\Phi(x_{t}, y_{t}, \lambda_{t}, z^{t}) \geq \mathbb{E}[\mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t})]$$

$$= f(x_{t}) + g(y_{t}) - \lambda_{t}^{T}(Ax_{t} + By_{t} - c) + \frac{\rho}{2} ||Ax_{t} + By_{t} - c||^{2}$$

$$\stackrel{(i)}{=} f(x_{t}) + g(y_{t}) - \frac{1}{\rho} \lambda_{t}^{T}(\lambda_{t-1} - \lambda_{t}) + \frac{1}{2\rho} ||\lambda_{t-1} - \lambda_{t}||^{2}$$

$$= f(x_{t}) + g(y_{t}) - \frac{1}{2\rho} ||\lambda_{t-1}||^{2} + \frac{1}{2\rho} ||\lambda_{t}||^{2} + \frac{1}{\rho} ||\lambda_{t} - \lambda_{t-1}||^{2}$$

$$\stackrel{(ii)}{\geq} f^{*} + g^{*} - \frac{1}{2\rho} ||\lambda_{t-1}||^{2} + \frac{1}{2\rho} ||\lambda_{t}||^{2}, \tag{70}$$

where the equality (i) holds by the step 8 in Algorithm 3, and the inequality (ii) holds by Assumption 2.

Summing the inequality (70) over t = 1, 1, · · · , T, we have

$$\frac{1}{T} \sum_{t=1}^{T} \Phi_t \ge f^* + g^* - \frac{1}{2\rho} \|\lambda_0\|^2.$$

Therefore, we can obtain the above result.

## <span id="page-25-1"></span>Appendix K. Proof of the Theorem 12

Proof Using (69), we have

$$\Phi_{t+1} \le \Phi_t - \Gamma_{t+1} \|x_{t+1} - x_t\|^2 - \left(1 - \frac{1}{n}\right)^2 \left[ (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1} + \frac{\vartheta L^2}{2} \right] \frac{1}{n} \|x_{t-1} - z_i^{t-1}\|^2, \quad (71)$$

for  $t \in \{1, 2, \dots, T\}$ . Summing the inequality (71) over  $t = 1, 2, \dots, T$ , we have

$$\Phi_T \le \Phi_1 - \gamma \sum_{t=1}^T \mathbb{E} \|x_{t+1} - x_t\|^2 - \omega \sum_{t=1}^T \frac{1}{n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2.$$
 (72)

where  $\gamma = \min_t \Gamma_t$  and  $\omega = \min_t \left(1 - \frac{1}{n}\right)^2 \left[ (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1} + \frac{\vartheta L^2}{2} \right]$ . From Lemma 11, there exists a low bound  $\Phi^*$  of the sequence  $\{\Phi_t\}$ , such that  $\Phi_t \geq \Phi^*$  for  $\forall t \geq 1$ . Then by the definition of  $\theta_t$  and (72), we have

$$\theta_{\hat{t}} = \min_{1 \le t \le T} \theta_t \le \frac{1}{\tau T} (\Phi_1 - \Phi^*), \tag{73}$$

where  $\tau = \min(\gamma, \omega)$ , so  $\theta_{\hat{t}} = O(\frac{1}{T})$ .

Next, we give upper bounds to the terms in (11-13) by using  $\theta_t$ . By (59), we have

$$\mathbb{E}\|A^{T}\lambda_{t+1} - \nabla f(x_{t+1})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|^{2}$$

$$\leq \left(1 - \frac{1}{n}\right)^{2} \frac{3L^{2}}{n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2} + 3(L^{2} + \eta^{2}\phi_{\max}^{2})\|x_{t} - x_{t+1}\|^{2}$$

$$\leq 3(L^{2} + \eta^{2}\phi_{\max}^{2})\theta_{t}. \tag{74}$$

By the step 8 of Algorithm 3 and the Lemma 8, we have

$$\mathbb{E}\|Ax_{t+1} + By_{t+1} - c\|^{2} = \frac{1}{\rho^{2}} \|\lambda_{t+1} - \lambda_{t}\|^{2}$$

$$\leq \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}\rho^{2}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t+1} - z_{i}^{t+1}\|^{2} + \left(1 - \frac{1}{n}\right)^{2} \frac{5L^{2}}{\sigma_{A}\rho^{2}n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2}$$

$$+ \frac{5L^{2}}{\sigma_{A}\rho^{2}} \mathbb{E}\|x_{t+1} - x_{t}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}} \|x_{t} - x_{t-1}\|^{2}$$

$$\leq \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}} \theta_{t}. \tag{75}$$

By the step 5 of Algorithm 3, there exists a subgradient  $\mu \in \partial g(y_{t+1})$  such that

$$\mathbb{E}\left[\operatorname{dist}(B^{T}\lambda_{t+1}, \partial g(y_{t+1}))\right]^{2} \leq \|\mu - B^{T}\lambda_{t+1}\|^{2}$$

$$= \|B^{T}\lambda_{t} - \rho B^{T}(Ax_{t} + By_{t+1} - c) - B^{T}\lambda_{t+1}\|^{2}$$

$$= \|\rho B^{T}A(x_{t+1} - x_{t})\|^{2}$$

$$\leq \rho^{2}\|B\|_{2}^{2}\|A\|_{2}^{2}\|x_{t+1} - x_{t}\|^{2}$$

$$\leq \rho^{2}\|B\|_{2}^{2}\|A\|_{2}^{2}\theta_{t}. \tag{76}$$

Thus, by (26) and the Definition 4, we conclude that the SAG-ADMM can converge an  $\epsilon$ -stationary point of the problem (1).

# <span id="page-27-0"></span>Appendix L. Proof of the Lemma 13

Proof By the optimal condition of step 7 in Algorithm 4, we have

$$0 = \hat{\nabla} f(x_t) - A^T \lambda_t + \rho A^T (A x_{t+1} + B y_{t+1} - c) - \eta Q(x_t - x_{t+1})$$
  
=  $\hat{\nabla} f(x_t) - A^T \lambda_{t+1} - \eta Q(x_t - x_{t+1}),$ 

where the second equality is due to step 8 in Algorithm 4. Thus, we have

$$A^{T}\lambda_{t+1} = \hat{\nabla}f(x_t) - \eta Q(x_t - x_{t+1}). \tag{77}$$

By (77), we have

$$\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \sigma_{A}^{-1} \|A^{T}\lambda_{t+1} - A^{T}\lambda_{t}\|^{2}$$

$$\leq \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \hat{\nabla}f(x_{t-1}) - \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$= \sigma_{A}^{-1} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t-1}) + \nabla f(x_{t-1}) - \hat{\nabla}f(x_{t-1})$$

$$- \eta Q(x_{t} - x_{t+1}) + \eta Q(x_{t-1} - x_{t})\|^{2}$$

$$\stackrel{i}{\leq} \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{t} - x_{t+1}\|^{2}$$

$$+ \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}} \|x_{t-1} - x_{t}\|^{2}, \tag{78}$$

where the inequality (i) holds by the Assumption 1.

Taking expectation conditioned on information i<sup>t</sup> to (78), we have

$$\mathbb{E}\|\lambda_{t+1} - \lambda_{t}\|^{2} \leq \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t})\|^{2} + \frac{5}{\sigma_{A}} \mathbb{E}\|\hat{\nabla}f(x_{t-1}) - \nabla f(x_{t-1})\|^{2}$$

$$+ \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{t} - x_{t+1}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}} \|x_{t-1} - x_{t}\|^{2}$$

$$\stackrel{(i)}{\leq} \frac{5L^{2}}{\sigma_{A}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2} + \frac{5L^{2}}{\sigma_{A}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2} + \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}} \|x_{t+1} - x_{t}\|^{2}$$

$$+ \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}} \|x_{t} - x_{t-1}\|^{2},$$

where the inequality (i) holds by the Lemma 3.

## <span id="page-27-1"></span>Appendix M. Proof of the Lemma 14

Proof By the step 5 of Algorithm 4, we have

$$\mathcal{L}_{\rho}(x_t, y_{t+1}, \lambda_t) \le \mathcal{L}_{\rho}(x_t, y_t, \lambda_t). \tag{79}$$

Next, by the optimal condition of step 7 in Algorithm 4, we have

$$0 = (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) + \rho A^{T}(Ax_{t+1} + By_{t+1} - c) - A^{T}\lambda_{t} - \eta Q(x_{t} - x_{t+1})]$$

$$= (x_{t} - x_{t+1})^{T} [\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - A^{T}\lambda_{t} - \eta Q(x_{t} - x_{t+1}) + \rho A^{T}(Ax_{t+1} + By_{t+1} - c)]$$

$$\stackrel{(i)}{\leq} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T} (Ax_{t+1} - Ax_{t}) + \rho (Ax_{t} - Ax_{t+1})^{T} (Ax_{t+1} + By_{t+1} - c)$$

$$\stackrel{(ii)}{=} f(x_{t}) - f(x_{t+1}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t})) + \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q}$$

$$- \lambda_{t}^{T} (Ax_{t} + By_{t+1} - c) + \lambda_{t}^{T} (Ax_{t+1} + By_{t+1} - c) + \frac{\rho}{2} \|Ax_{t} + By_{t+1} - c\|^{2}$$

$$- \frac{\rho}{2} \|Ax_{t+1} + By_{t+1} - c\|^{2} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$= \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$+ \frac{L}{2} \|x_{t+1} - x_{t}\|^{2} - \eta \|x_{t+1} - x_{t}\|^{2}_{Q} - \frac{\rho}{2} \|Ax_{t} - Ax_{t+1}\|^{2}$$

$$\stackrel{(iii)}{\leq} \mathcal{L}_{\rho}(x_{t}, y_{t+1}, \lambda_{t}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t}) + (x_{t} - x_{t+1})^{T} (\hat{\nabla}f(x_{t}) - \nabla f(x_{t}))$$

$$- (\eta \phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2}) \|x_{t} - x_{t+1}\|^{2}, \tag{80}$$

where the inequality (i) holds by the Assumption 1; the equality (ii) holds by using the equality  $(a-b)^T(b-c) = \frac{1}{2}(\|a-c\|^2 - \|a-b\|^2 - \|b-c\|^2)$  on the term  $\rho(Ax_t - Ax_{t+1})^T(Ax_{t+1} + By_{t+1} - c)$ ; the inequality (iii) holds by using  $-\phi_{\min}\|x_{t+1} - x_t\|^2 \ge -\|x_{t+1} - x_t\|^2_Q$  and  $-\sigma_A\|x_{t+1} - x_t\|^2 \ge -\|Ax_t - Ax_{t+1}\|^2$ . Taking expectation conditioned on information  $i_t$  to (80), and using  $\mathbb{E}[\hat{\nabla}f(x_t)] = \nabla f(x_t)$ , we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_t)] \le \mathcal{L}_{\rho}(x_t, y_{t+1}, \lambda_t) - (\eta \phi_{\min} + \frac{\sigma_A \rho}{2} - \frac{L}{2}) \|x_t - x_{t+1}\|^2.$$
(81)

By the step 8 of Algorithm 4, and taking expectation conditioned on information  $i_t$ , we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) - \mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t})] = \frac{1}{\rho} \mathbb{E}\|\lambda_{t} - \lambda_{t+1}\|^{2} \\
\stackrel{(i)}{\leq} \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2} \\
+ \frac{5(\eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t+1} - x_{t}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2}, \tag{82}$$

where the inequality (i) holds by the Lemma 13. Combining (79), (81) and (82), we have

$$\mathbb{E}[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1})] \leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t} - z_{i}^{t}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho n} \sum_{i=1}^{n} \mathbb{E}\|x_{t-1} - z_{i}^{t-1}\|^{2} + \frac{5(\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2} - (\eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{5\eta^{2}\phi_{\max}^{2}}{\sigma_{A}\rho}) \|x_{t+1} - x_{t}\|^{2}.$$
(83)

Next, considering  $\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} ||x_{t+1} - z_i^{t+1}||^2$ , we have

$$\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} \|x_{t+1} - z_i^{t+1}\|^2 = \frac{1}{n} \sum_{i=1}^{n} \left[ \frac{1}{n} \mathbb{E} \|x_{t+1} - x_t\|^2 + \frac{n-1}{n} \mathbb{E} \|x_{t+1} - z_i^t\|^2 \right]. \tag{84}$$

The term Ekxt+1 − z t i 2 in (84) can be bounded as follows:

$$\mathbb{E}\|x_{t+1} - z_i^t\|^2 = \mathbb{E}\|x_{t+1} - x_t + x_t - z_i^t\|^2$$

$$= \mathbb{E}[\|x_{t+1} - x_t\|^2 + 2(x_{t+1} - x_t)^T (x_t - z_i^t) + \|x_{t-1} - z_i^t\|^2]$$

$$\leq \mathbb{E}[\|x_{t+1} - x_t\|^2 + 2(\frac{1}{2\beta}\mathbb{E}\|x_{t+1} - x_t\|^2 + \frac{\beta}{2}\|x_t - z_i^t\|^2) + \|x_t - z_i^t\|^2]$$

$$= (1 + \frac{1}{\beta})\mathbb{E}\|x_{t+1} - x_t\|^2 + (1 + \beta)\|x_t - z_i^t\|^2,$$

where β > 0, and the inequality is due to the Cauchy inequality. Then, we have

$$\frac{1}{n} \sum_{i=1}^{n} \mathbb{E} \|x_{t+1} - z_i^{t+1}\|^2 \le \left(1 + \frac{(n-1)}{n\beta}\right) \mathbb{E} \|x_{t+1} - x_t\|^2 + \left(1 + \beta\right) \frac{n-1}{n^2} \sum_{i=1}^{n} \|x_t - z_i^t\|$$
 (85)

Combining the inequalities (83) and (85), we have

$$\mathbb{E}\left[\mathcal{L}_{\rho}(x_{t+1}, y_{t+1}, \lambda_{t+1}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t+1} - x_{t}\|^{2} + \frac{\alpha_{t+1}}{n} \sum_{i=1}^{n} (\|x_{t+1} - z_{i}^{t+1}\|^{2} + \|x_{t} - z_{i}^{t}\|^{2})\right] \\
\leq \mathcal{L}_{\rho}(x_{t}, y_{t}, \lambda_{t}) + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho} \|x_{t} - x_{t-1}\|^{2} \\
+ \left[ (2 + \beta - \frac{1 + \beta}{n})\alpha_{t+1} + \frac{5L^{2}}{\sigma_{A}\rho} \right] \frac{1}{n} \sum_{i=1}^{n} (\|x_{t} - z_{i}^{t}\|^{2} + \|x_{t-1} - z_{i}^{t-1}\|^{2}) \\
- \left[ \eta\phi_{\min} + \frac{\sigma_{A}\rho}{2} - \frac{L}{2} - \frac{5(2\eta^{2}\phi_{\max}^{2} + L^{2})}{\sigma_{A}\rho} - (1 + \frac{1}{\beta} - \frac{1}{n\beta})\alpha_{t+1} \right] \|x_{t+1} - x_{t}\|^{2} \\
- (2 + \beta - \frac{1 + \beta}{n}) \frac{\alpha_{t+1}}{n} \sum_{i=1}^{n} \|x_{t-1} - z_{i}^{t-1}\|^{2}. \tag{86}$$

Finally, using the definition of the sequence {Φˆ} T <sup>t</sup>=1, (28) and (29), we have

$$\hat{\Phi}_{t+1} \le \hat{\Phi}_t - \Gamma_t \|x_{t+1} - x_t\|^2 - (2 + \beta - \frac{1+\beta}{n}) \frac{\alpha_{t+1}}{n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2.$$
 (87)

Since Γ<sup>t</sup> > 0, we can obtain the above result.

# <span id="page-29-0"></span>Appendix N. Proof of the Theorem 16

Proof Using the above inequality (87), we have

$$\hat{\Phi}_{t+1} \le \hat{\Phi}_t - \Gamma_{t+1} \|x_{t+1} - x_t\|^2 - (2 + \beta - \frac{1+\beta}{n}) \frac{\alpha_{t+1}}{n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2, \tag{88}$$

for t ∈ {1, 2, · · · , T}. Summing the inequality (88) over t = 1, 2, · · · , T, then we have

$$\hat{\Phi}_T \le \hat{\Phi}_1 - \gamma \sum_{t=1}^T \mathbb{E} \|x_{t+1} - x_t\|^2 - \omega \sum_{t=1}^T \frac{1}{n} \sum_{i=1}^n \|x_{t-1} - z_i^{t-1}\|^2.$$
 (89)

where  $\gamma = \min_t \Gamma_t$  and  $\omega = \min_t (2 + \beta - \frac{1+\beta}{n})\alpha_{t+1}$ . From Lemma 15, there exists a lower bound  $\hat{\Phi}^*$  of the sequence  $\{\hat{\Phi}_t\}$ , i.e.,  $\hat{\Phi}_t \geq \hat{\Phi}^*$  holds for  $\forall t \geq 1$ . By the definition of  $\hat{\theta}_t$  and (89), we have

$$\hat{\theta}_{\tilde{t}} = \min_{1 \le t \le T} \hat{\theta}_t \le \frac{1}{\tau T} (\hat{\Phi}_1 - \hat{\Phi}^*), \tag{90}$$

where  $\tau = \min(\gamma, \omega)$ , so  $\hat{\theta}_{\tilde{t}} = O(\frac{1}{T})$ .

Next, we give upper bounds to the terms in (11-13) by using  $\hat{\theta}_t$ . Using (77), we have

$$\mathbb{E}\|A^{T}\lambda_{t+1} - \nabla f(x_{t+1})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|^{2}$$

$$= \mathbb{E}\|\hat{\nabla}f(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|^{2}$$

$$\leq \frac{3L^{2}}{n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2} + 3(L^{2} + \eta^{2}\phi_{\max}^{2})\|x_{t} - x_{t+1}\|^{2}$$

$$\leq 3(L^{2} + \eta^{2}\phi_{\max}^{2})\theta_{t}. \tag{91}$$

By the step 8 of Algorithm 4 and the Lemma 13, we have

$$\mathbb{E}\|Ax_{t+1} + By_{t+1} - c\|^{2} = \frac{1}{\rho^{2}} \|\lambda_{t+1} - \lambda_{t}\|^{2}$$

$$\leq \frac{5L^{2}}{\sigma_{A}\rho^{2}n} \sum_{i=1}^{n} \mathbb{E}\|x_{t+1} - z_{i}^{t+1}\|^{2} + \frac{5L^{2}}{\sigma_{A}\rho^{2}n} \sum_{i=1}^{n} \|x_{t} - z_{i}^{t}\|^{2}$$

$$+ \frac{5L^{2}}{\sigma_{A}\rho^{2}} \mathbb{E}\|x_{t+1} - x_{t}\|^{2} + \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}} \|x_{t} - x_{t-1}\|^{2}$$

$$\leq \frac{5(L^{2} + \eta^{2}\phi_{\max}^{2})}{\sigma_{A}\rho^{2}} \theta_{t}. \tag{92}$$

By the step 5 of Algorithm 4, there exists a subgradient  $\mu \in \partial g(y_{t+1})$  such that

$$\mathbb{E}\left[\operatorname{dist}(B^{T}\lambda_{t+1}, \partial g(y_{t+1}))\right]^{2} \leq \|\mu - B^{T}\lambda_{t+1}\|^{2}$$

$$= \|B^{T}\lambda_{t} - \rho B^{T}(Ax_{t} + By_{t+1} - c) - B^{T}\lambda_{t+1}\|^{2}$$

$$= \|\rho B^{T}A(x_{t+1} - x_{t})\|^{2}$$

$$\leq \rho^{2}\|B\|_{2}^{2}\|A\|_{2}^{2}\|x_{t+1} - x_{t}\|^{2}$$

$$\leq \rho^{2}\|B\|_{2}^{2}\|A\|_{2}^{2}\theta_{t}. \tag{93}$$

Thus, by (32) and the Definition 4, we conclude that the SAGA-ADMM can converge an  $\epsilon$ -stationary point of the problem (1).

#### <span id="page-30-0"></span>Appendix O. Proof of the Theorem 17

**Proof** By the optimal condition of the step 6 in Algorithm 1, we have

$$0 = \nabla f_{i_t}(x_t) - A^T \lambda_t + \rho A^T (A x_{t+1} + B y_{t+1} - c) - \eta Q(x_t - x_{t+1})$$
  
=  $\nabla f_{i_t}(x_t) - A^T \lambda_{t+1} - \eta Q(x_t - x_{t+1}),$  (94)

where the second equality holds by the step 7 in Algorithm 1. By (94), we have

$$\mathbb{E}\|A^{T}\lambda_{t+1} - \nabla f(x_{t+1})\| = \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|$$

$$= \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f(x_{t}) + \nabla f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|$$

$$\geq \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f(x_{t})\| - \mathbb{E}\|\nabla f(x_{t}) - \nabla f(x_{t+1}) - \eta Q(x_{t} - x_{t+1})\|$$

$$\stackrel{(i)}{\geq} \mathbb{E}\|\nabla f_{i_{t}}(x_{t}) - \nabla f(x_{t})\| - (L + \eta \phi_{\max})\|x_{t} - x_{t+1}\|$$

$$\geq \delta - (L + \eta \phi_{\max})\|x_{t} - x_{t+1}\|$$
(95)

where the equality (i) holds by the Assumption 1. Suppose the sequence  $\{x_t, y_t, \lambda_t\}$  generated by Algorithm 1, and it converges to a stationary point  $(x^*, y^*, \lambda^*)$  of the problem (1). Then  $\exists \epsilon > 0$ , we have

$$||x_{t+1} - x_t|| \le ||x_{t+1} - x^*|| + ||x_t - x^*|| \le \epsilon/2 + \epsilon/2 = \epsilon.$$

If  $\delta \geq 2(L + \eta \phi_{\max})\epsilon$ , we have  $\mathbb{E}||A^T \lambda_{t+1} - \nabla f(x_{t+1})|| \geq (L + \eta \phi_{\max})\epsilon$ . Thus, we obtain the above conclusion by contradiction.

#### References

<span id="page-31-6"></span>Zeyuan Allen-Zhu and Elad Hazan. Variance reduction for faster non-convex optimization. arXiv preprint arXiv:1603.05643, 2016.

<span id="page-31-5"></span>Samaneh Azadi and Suvrit Sra. Towards an optimal stochastic alternating direction method of multipliers. In Proceedings of the 31st International Conference on Machine Learning, pages:620–628, 2014.

<span id="page-31-0"></span>Léon Bottou. Stochastic learning. In Advanced lectures on machine learning, pages:146–168, Springer, 2004.

<span id="page-31-2"></span>Stephen Boyd, Neal Parikh, Eric Chu, Borja Peleato and Jonathan Eckstein. Distributed optimization and statistical learning via the alternating direction method of multipliers. Foundations and Trends® in Machine Learning, 3(1):1–122, 2011.

<span id="page-31-3"></span>Patrick Danaher, Pei Wang and Daniela M Witten. The joint graphical lasso for inverse covariance estimation across multiple classes. Journal of the Royal Statistical Society: Series B (Statistical Methodology), 76(2):373–397, 2014.

<span id="page-31-7"></span>Wei Deng and Wotao Yin. On the global and linear convergence of the generalized alternating direction method of multipliers. Journal of Scientific Computing, 66(3):889–916, 2016.

<span id="page-31-4"></span>Ethan X Fang, Bingsheng He, Han Liu and Xiaoming Yuan. Generalized alternating direction method of multipliers: new theoretical insights and applications. Mathematical Programming Computation, 7(2):149–187, 2015.

<span id="page-31-8"></span>Jerome Friedman, Trevor Hastie and Robert Tibshirani. Sparse inverse covariance estimation with the graphical lasso. Biostatistics, 9(3):432-441,2008.

<span id="page-31-1"></span>Daniel Gabay and Bertrand Mercier. A dual algorithm for the solution of nonlinear variational problems via finite element approximation. Computers and Mathematics with Applications, 2(1):17–40.1976.

- <span id="page-32-6"></span>Saeed Ghadimi and Guanghui Lan. Accelerated gradient methods for nonconvex nonlinear and stochastic programming. Mathematical Programming, 156(1-2):59–99, 2016.
- <span id="page-32-7"></span>Saeed Ghadimi, Guanghui Lan and Hongchao Zhang. Mini-batch stochastic approximation methods for nonconvex stochastic composite optimization. Mathematical Programming, 155(1-2):267–305, 2016.
- <span id="page-32-13"></span>Mingyi Hong, Zhi-Quan Luo and Meisam Razaviyayn. Convergence analysis of alternating direction method of multipliers for a family of nonconvex problems. SIAM Journal on Optimization, 26(1):337–364, 2016.
- <span id="page-32-15"></span>Cho-Jui Hsieh, M´aty´as A Sustik, Inderjit S Dhillon and Pradeep D Ravikumar. QUIC: quadratic approximation for sparse inverse covariance estimation. Journal of Machine Learning Research, 15(1):2911–2947, 2014.
- <span id="page-32-12"></span>Bo Jiang, Tianyi Lin, Shiqian Ma and Shuzhong Zhang. Structured Nonconvex and Nonsmooth Optimization: Algorithms and Iteration Complexity Analysis. arXiv preprint [arXiv:1605.02408,](http://arxiv.org/abs/1605.02408) 2016.
- <span id="page-32-2"></span>Rie Johnson and Tong Zhang. Accelerating stochastic gradient descent using predictive variance reduction. In Advances in Neural Information Processing Systems, pages:315–323, 2013.
- <span id="page-32-14"></span>Seyoung Kim, Kyung-Ah Sohn and Eric P Xing. A multivariate regression approach to association analysis of a quantitative trait network. Bioinformatics, 25(12):i204–i212, 2009.
- <span id="page-32-5"></span>Yann LeCun, Yoshua Bengio and Geoffrey Hinton. Deep learning. Nature, 521(7553):436–444, 2015.
- Guoyin Li and Kei Ting Pong. Global convergence of splitting methods for nonconvex composite optimization. SIAM Journal on Optimization, 25(4): 2434–2460, 2015.
- <span id="page-32-10"></span>Xingguo Li, Tuo Zhao, Raman Arora, Han Liu and Jarvis Haupt. Stochastic Variance Reduced Optimization for Nonconvex Sparse Learning. arXiv preprint [arXiv:1605.02711,](http://arxiv.org/abs/1605.02711) 2016.
- <span id="page-32-0"></span>Qihang Lin, Zhaosong Lu and Lin Xiao. An accelerated randomized proximal coordinate gradient method and its application to regularized empirical risk minimization. SIAM Journal on Optimization, 25(4):2244–2273, 2015.
- <span id="page-32-4"></span>Shiqian Ma, Lingzhou Xue and Hui Zou. Alternating direction methods for latent variable Gaussian graphical model selection. Neural computation, 25(8):2172–2198, 2013.
- <span id="page-32-1"></span>Yurii Nesterov. Introductory Lectures on Convex Programming Volume I: Basic course. Kluwer Boston, 2004.
- <span id="page-32-3"></span>Hua Ouyang, Niao He, Long Tran and Alexander G Gray. Stochastic Alternating Direction Method of Multipliers. In Proceedings of the 30st International Conference on Machine Learning, pages 80–88, 2013.
- <span id="page-32-8"></span>Sashank J Reddi, Ahmed Hefny, Suvrit Sra, Barnab´as P´ocz´os and Alex Smola. Stochastic Variance Reduction for Nonconvex Optimization. arXiv preprint [arXiv:1603.06160,](http://arxiv.org/abs/1603.06160) 2016.
- <span id="page-32-9"></span>Sashank J Reddi, Suvrit Sra, Barnabas Poczos and Alex Smola. Fast Incremental Method for Nonconvex Optimization. arXiv preprint [arXiv:1603.06159,](http://arxiv.org/abs/1603.06159) 2016.
- <span id="page-32-11"></span>Sashank J Reddi, Suvrit Sra, Barnabas Poczos and Alex Smola. Fast Stochastic Methods for Nonsmooth Nonconvex Optimization. arXiv preprint [arXiv:1605.0690,](http://arxiv.org/abs/1605.0690) 2016.

- <span id="page-33-0"></span>Nicolas L Roux, Mark Schmidt and Francis R Bach. A stochastic gradient method with an exponential convergence rate for finite training sets. In Advances in Neural Information Processing Systems, pages:2663–2671, 2012.
- <span id="page-33-1"></span>Shai Shalev-Shwartz and Tong Zhang. Stochastic dual coordinate ascent methods for regularized loss minimization. Journal of Machine Learning Research, 14:567–599, 2013.
- <span id="page-33-8"></span>Taiji Suzuki. Stochastic Dual Coordinate Ascent with Alternating Direction Method of Multipliers. In Proceedings of The 31st International Conference on Machine Learning, pages:736–744, 2014.
- <span id="page-33-5"></span>Taiji Suzuki. Dual Averaging and Proximal Gradient Descent for Online Alternating Direction Multiplier Method. In Proceedings of The 31st International Conference on Machine Learning, pages:392–400, 2013.
- <span id="page-33-13"></span>Fenghui Wang, Wenfei Cao and Zongben Xu. Convergence of multi-block Bregman ADMM for nonconvex composite problems. arXiv preprint [arXiv:1505.03063,](http://arxiv.org/abs/1505.03063) 2015.
- <span id="page-33-4"></span>Huahua Wang and Arindam Banerjee. Online Alternating Direction Method. In Proceedings of the 29th International Conference on Machine Learning, pages: 1119–1126, 2012.
- <span id="page-33-15"></span>Yu Wang, Wotao Yin and Jinshan Zeng. Global convergence of ADMM in nonconvex nonsmooth optimization. arXiv preprint [arXiv:1511.06324,](http://arxiv.org/abs/1511.06324) 2015.
- <span id="page-33-2"></span>Lin Xiao and Tong Zhang. A proximal stochastic gradient method with progressive variance reduction. SIAM Journal on Optimization, 24(4):2057–2075, 2014.
- <span id="page-33-14"></span>Lei Yang, Ting Kei Pong and Xiaojun Chen. Alternating direction method of multipliers for nonconvex background/foreground extraction. arXiv preprint [arXiv:1506.07029,](http://arxiv.org/abs/1506.07029) 2015.
- <span id="page-33-11"></span>Aleksandr Aravkin and Damek Davis. A SMART Stochastic Algorithm for Nonconvex Optimization with Applications to Robust Machine Learning. arXiv preprint [arXiv:1610.01101,](http://arxiv.org/abs/1610.01101) 2016.
- <span id="page-33-18"></span>Xiaoqun Zhang, Martin Burger and Stanley Osher. A unified primal-dual algorithm framework based on Bregman iteration. Journal of Scientific Computing, 46(1):20–46, 2011.
- <span id="page-33-7"></span>Peilin Zhao, Jinwei Yang, Tong Zhang and Ping Li. Adaptive Stochastic Alternating Direction Method of Multipliers. In Proceedings of The 32nd International Conference on Machine Learning, pages:69–77, 2015.
- <span id="page-33-9"></span>Shen-Yi Zhao, Wu-Jun Li and Zhi-Hua Zhou. Scalable Stochastic Alternating Direction Method of Multipliers. arXiv preprint [arXiv:1502.03529,](http://arxiv.org/abs/1502.03529) 2015.
- <span id="page-33-10"></span>Shuai Zheng and James T Kwok. Fast and Light Stochastic ADMM. In Proceedings of The 25th International Joint Conference on Artificial Intelligence, 2016.
- <span id="page-33-6"></span>Leon Wenliang Zhong and James T Kwok. Fast stochastic alternating direction method of multipliers. In Proceedings of The 31nd International Conference on Machine Learning, 2014.
- <span id="page-33-12"></span>Davood Hajinezhad, Mingyi Hong, Tuo Zhao and Zhaoran Wang. NESTT: A Nonconvex Primal-Dual Splitting Method for Distributed and Stochastic Optimization. arXiv preprint [arXiv:1605.07747,](http://arxiv.org/abs/1605.07747) 2016.
- <span id="page-33-16"></span>Mingyi Hong. A distributed, asynchronous and incremental algorithm for nonconvex optimization: An ADMM based approach. arXiv preprint [arXiv:1412.6058,](http://arxiv.org/abs/1412.6058) 2014.
- <span id="page-33-17"></span>Vladimir Vapnik. The nature of statistical learning theory. Springer Science & Business Media, 2013.
- <span id="page-33-3"></span>Aaron Defazio, Francis Bach and Simon Lacoste-Julien. SAGA: A fast incremental gradient method with support for non-strongly convex composite objectives. Advances in Neural Information Processing Systems, pages:1646–1654, 2014.