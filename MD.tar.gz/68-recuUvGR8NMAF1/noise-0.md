![](_page_0_Picture_2.jpeg)

# Linear Convergence and Metric Selection for Douglas-Rachford Splitting and ADMM

Pontus Giselsson and Stephen Boyd, Fellow, IEEE

*Abstract—***Recently, several convergence rate results for Douglas-Rachford splitting and the alternating direction method of multipliers (ADMM) have been presented in the literature. In this paper, we show global linear convergence rate bounds for Douglas-Rachford splitting and ADMM under strong convexity and smoothness assumptions. We further show that the rate bounds are tight for the class of problems under consideration for all feasible algorithm parameters. For problems that satisfy the assumptions, we show how to select step-size and metric for the algorithm that optimize the derived convergence rate bounds. For problems with a similar structure that do not satisfy the assumptions, we present heuristic step-size and metric selection methods.**

*Index Terms—***Alternating direction method of multipliers (ADMM), Douglas-Rachford splitting, linear convergence, optimization algorithms.**

### I. INTRODUCTION

**O**PTIMIZATION problems of the form

$$minimize f(x) + g(x) (1)$$

where x is the variable and f and g are proper closed and convex, arise in numerous applications ranging from compressed sensing [9] and statistical estimation [29] to model predictive control [45] and medical imaging [37].

There exist a variety of operator splitting methods for solving problems of the form (1), see [12], [39]. In this paper, we focus on Douglas-Rachford splitting [17], [41]. Douglas-Rachford splitting is given by the iteration

$$z^{k+1} = ((1 - \alpha)\operatorname{Id} + \alpha R_{\gamma f} R_{\gamma g}) z^k$$
 (2)

where α in general is constrained to satisfy α ∈ (0, 1). Here, Id is the identity operator, Rγf is the reflected proximal operator Rγf = 2proxγf − Id, and proxγf is the proximal operator defined by

$$\operatorname{prox}_{\gamma f}(z) := \underset{x}{\operatorname{arg\,min}} \left\{ \gamma f(x) + \frac{1}{2} \|x - z\|^2 \right\}.$$
 (3)

Manuscript received June 26, 2015; revised November 13, 2015, November 16, 2015, and March 23, 2016; accepted April 7, 2016. Date of publication May 5, 2016; date of current version January 26, 2017. P. Giselsson's work was supported by the Swedish Foundation for Strategic Research. Recommended by Associate Editor A. Nedich.

P. Giselsson is with the Department of Automatic Control, Lund University, 221 00 Lund, Sweden (e-mail: pontusg@control.lth.se).

S. Boyd is with the Department of Electrical Engineering, Stanford University, Stanford, CA 94305 USA (e-mail: boyd@stanford.edu).

Color versions of one or more of the figures in this paper are available online at http://ieeexplore.ieee.org.

Digital Object Identifier 10.1109/TAC.2016.2564160

The variable z<sup>k</sup> in (2) converges to a fixed-point of RγfRγg and the sequence x<sup>k</sup> = proxγgz<sup>k</sup> converges to a solution of (1) (if it exists), see [1, Proposition 25.6].

When (2) is applied to the Fenchel dual problem of (1), this algorithm is equivalent to ADMM, see [6], [21], [28] for ADMM and [18], [20] for the connection to Douglas-Rachford splitting. These methods have long been known to converge for any α ∈ (0, 1) and γ > 0 under mild assumptions, [18], [21], [36]. However, the rate of convergence in the general case has just recently been shown to be O(1/k), [13], [15], [30].

For a restricted class of monotone inclusion problems, Lions and Mercier showed in [36] that the Douglas-Rachford algorithm (with α = 0.5) enjoys a linear convergence rate. To the authors' knowledge, this was the sole linear convergence rate results for a long period of time for these methods. Recently, however, many works have shown linear convergence rates for Douglas-Rachford splitting and ADMM in different settings [2], [5], [14]–[16], [22], [31], [32], [34], [38], [40], [42], [44], [47], [49].

The works in [5], [15], [31], [42], [49] concern local linear convergence under different assumptions. The works in [34], [47] consider distributed formulations and [32] considers multi-block ADMM, while the works in [2], [14], [16], [22], [36], [38], [40], [44] show global linear convergence. Of these, the work in [2] shows linear convergence for Douglas-Rachford splitting when solving a subspace intersection problem and the work in [44] (which appeared online during the submission procedure of this paper) shows linear convergence for equality constrained problems with upper and lower bounds on the variables. The other works that show global linear convergence, [14], [16], [22], [36], [38], [40], show this for Douglas-Rachford splitting or ADMM under strong convexity and smoothness assumptions.

In this paper, we provide explicit linear convergence rate bounds for the case where f in (1) is strongly convex and smooth and we show how to select algorithm parameters to optimize the bounds. We also show that the bounds are tight for the class of problems under consideration for all feasible algorithm parameters γ and α. Our results generalize and/or improve corresponding results in [14], [16], [22], [36], [38], [40]. A detailed comparison to the rate bounds in these works is found in Section V.

We also show that a relaxation factor α ≥ 1 can be used in the algorithm. We provide explicit lower and upper bounds on α where the upper bound depends on the smoothness and strong convexity parameters of the problem. We further show that the bounds are tight, meaning that if an α is chosen that is outside the allowed interval, there exists a problem from the considered class that the algorithm does not solve.

The provided convergence rate bounds for Douglas-Rachford splitting and ADMM depend on the smoothness and strong convexity parameters of the problem to be solved. These parameters depend on the space on which the problem is defined. This space can therefore be chosen by optimizing the convergence rate bound. In this paper, we show how to do this in Euclidean settings. We select a space by choosing a (metric) matrix M that defines an inner-product  $\langle x,y\rangle_M=x^TMy$  and its induced norm  $\|x\|_M=\sqrt{\langle x,x\rangle}_M$ . This matrix M is chosen to optimize the convergence rate bound (typically subject to M being diagonal). Letting the problem and algorithm be defined on this space can considerably improve theoretical and practical convergence.

The metric selection can be interpreted as a preconditioning with the objective to reduce the number of iterations. A similar preconditioning is presented in [22] for ADMM applied to solve quadratic programs with linear inequality constraints. Our results generalize these in several directions, see Section V for a detailed comparison.

Real-world problems rarely have the properties needed to ensure linear convergence of Douglas-Rachford splitting or ADMM. Therefore, we provide heuristic metric and parameter selection methods for such problems. The heuristics cover many problems that arise, e.g., in model predictive control [45], statistical estimation [29], [48], compressed sensing [9], and medical imaging [37]. We provide two numerical examples that show the efficiency of the theoretically justified and heuristic parameter and metric selection methods.

This paper extends and generalizes the conference papers [24], [25].

## A. Notation

We denote by  $\mathbb{R}$  the set of real numbers,  $\mathbb{R}^n$  the set of real column-vectors of length n, and  $\mathbb{R}^{m \times n}$  the set of real matrices with m rows and n columns. Further  $\overline{\mathbb{R}} := \mathbb{R} \cup \{\infty\}$  denotes the extended real line. Throughout this paper  $\mathcal{H}$ ,  $\mathcal{H}_1$ ,  $\mathcal{H}_2$ , and  $\mathcal{K}$ denote real Hilbert spaces. Their inner products are denoted by  $\langle \cdot, \cdot \rangle$ , the induced norm by  $\| \cdot \|$ , and the identity operator by Id. We specifically consider finite-dimensional Hilbert-spaces  $\mathbb{H}_H$ with inner product  $\langle x, y \rangle = x^T H y$  and induced norm ||x|| = $\sqrt{x^T H x}$ . We denote these by  $\langle \cdot, \cdot \rangle_H$  and  $\| \cdot \|_H$ . We also denote the Euclidean inner-product by  $\langle x,y\rangle_2=x^Ty$  and the induced norm by  $\|\cdot\|_2$ . The conjugate function is denoted and defined by  $f^*(y) \stackrel{\Delta}{=} \sup_x \{\langle y, x \rangle - f(x)\}$  and the adjoint operator to a linear operator  $\mathcal{A}:\mathcal{H}\to\mathcal{K}$  is defined as the unique operator  $\mathcal{A}^*: \mathcal{K} \to \mathcal{H}$  that satisfies  $\langle \mathcal{A}x, y \rangle = \langle x, \mathcal{A}^*y \rangle$ . The range and kernel of A are denoted by ran A and ker A respectively. The orthogonal complement of a subspace  $\mathcal{X}$  is denoted by  $\mathcal{X}^{\perp}$ . The power set of a set  $\mathcal{X}$ , i.e., the set of all subsets of  $\mathcal{X}$ , is denoted by  $2^{\mathcal{X}}$ . The graph of an (set-valued) operator  $A: \mathcal{X} \to$  $2^{\mathcal{Y}}$  is defined and denoted by gph  $A = \{(x,y) \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{Y} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} \times \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X} | y \in \mathcal{X$ Ax}. The inverse operator  $A^{-1}$  is defined through its graph by gph  $A^{-1} = \{(y, x) \in \mathcal{Y} \times \mathcal{X} | y \in Ax\}$ . The set of fixedpoints to an operator  $T: \mathcal{H} \to \mathcal{H}$  is denoted and defined as  $\operatorname{fix} T = \{x \in \mathcal{H} | Tx = x\}$ . Finally, the class of closed, proper, and convex functions  $f: \mathcal{H} \to \overline{\mathbb{R}}$  is denoted by  $\Gamma_0(\mathcal{H})$ .

#### II. BACKGROUND

In this section, we introduce some standard definitions that can be found, e.g. in [1], [46].

**Definition 1 (Strong Monotonicity)**: An operator  $A: \mathcal{H} \to 2^{\mathcal{H}}$  is  $\sigma$ -strongly monotone with  $\sigma > 0$  if

$$\langle u - v, x - y \rangle \ge \sigma ||x - y||^2$$

for all  $(x, u) \in gph(A)$  and  $(y, v) \in gph(A)$ .

The definition of *monotonicity* is obtained by setting  $\sigma = 0$  in the above definition.

In the following definitions, we suppose that  $\mathcal{D} \subseteq \mathcal{H}$  is a nonempty subset of  $\mathcal{H}$ .

**Definition 2 (Lipschitz Mappings)**: A mapping  $T: \mathcal{D} \to \mathcal{H}$  is  $\beta$ -Lipschitz continuous with  $\beta \geq 0$  if

$$||Tx - Ty|| \le \beta ||x - y||$$

holds for all  $x, y \in \mathcal{D}$ . If  $\beta = 1$  then T is *nonexpansive* and if  $\beta \in [0, 1)$  then T is  $\beta$ -contractive.

**Definition 3 (Averaged Mappings)**: A mapping  $T: \mathcal{D} \to \mathcal{H}$  is  $\alpha$ -averaged if there exists a nonexpansive mapping  $S: \mathcal{D} \to \mathcal{H}$  and  $\alpha \in (0,1)$  such that  $T=(1-\alpha)\mathrm{Id} + \alpha S$ .

**Definition 4 (Co-coercivity):** A mapping  $T: \mathcal{D} \to \mathcal{H}$  is  $\beta$ -co-coercive with  $\beta > 0$  if  $\beta T$  is 1/2-averaged.

This definition implies that co-coercive mappings  ${\cal T}$  can be expressed as

$$T = \frac{1}{2\beta}(\mathrm{Id} + S) \tag{4}$$

for some nonexpansive operator S.

**Definition 5 (Strong Convexity)**: A function  $f \in \Gamma_0(\mathcal{H})$  is  $\sigma$ -strongly convex with  $\sigma > 0$  if  $f - (\sigma/2) \| \cdot \|^2$  is convex.

A strongly convex function has a minimum curvature that is at least  $\sigma$ . If f is differentiable, strong convexity can equivalently be defined as that

$$f(x) \ge f(y) + \langle \nabla f(y), x - y \rangle + \frac{\sigma}{2} ||x - y||^2$$
 (5)

holds for all  $x, y \in \mathcal{H}$ . Functions with a maximal curvature are called smooth. Next, we present a smoothness definition for convex functions.

**Definition 6 (Smoothness for Convex Functions)**: A function  $f \in \Gamma_0(\mathcal{H})$  is  $\beta$ -smooth with  $\beta \geq 0$  if it is differentiable and  $(\beta/2)\|\cdot\|^2 - f$  is convex, or equivalently that

$$f(x) \le f(y) + \langle \nabla f(y), x - y \rangle + \frac{\beta}{2} ||x - y||^2$$
 (6)

holds for all  $x, y \in \mathcal{H}$ .

**Remark 1**: It can be seen from (5) and (6) that for a function that is  $\sigma$ -strongly convex and  $\beta$ -smooth, we always have  $\beta \geq \sigma$ .

#### III. DOUGLAS-RACHFORD SPLITTING

The Douglas-Rachford algorithm can be applied to solve composite convex optimization problems of the form

minimize 
$$f(x) + g(x)$$
 (7)

where  $f, g \in \Gamma_0(\mathcal{H})$ . The solutions to (7) are characterized by the following optimality conditions, [1, Proposition 25.1]:

$$z = R_{\gamma g} R_{\gamma f} z, \qquad x = \operatorname{prox}_{\gamma f}(z)$$
 (8)

where  $\gamma > 0$ , the prox operator  $\operatorname{prox}_{\gamma f}$  is defined in (3), and the reflected proximal operator  $R_{\gamma f} = 2\operatorname{prox}_{\gamma f} - \operatorname{Id}$ . In other words, a solution to (7) is found by applying the proximal operator on z, where z is a fixed-point to  $R_{\gamma g}R_{\gamma f}$ .

One approach to find a fixed-point to  $R_{\gamma g}R_{\gamma f}$  is to iterate the composition

$$z^{k+1} = R_{\gamma g} R_{\gamma f} z^k.$$

This algorithm is sometimes referred to as Peaceman-Rachford splitting, [41]. However, since  $R_{\gamma f}$  and  $R_{\gamma g}$  are in general nonexpansive, so is their composition, and convergence of this algorithm cannot be guaranteed in the general case.

The Douglas-Rachford splitting algorithm is obtained by iterating the averaged map of the nonexpansive Peaceman-Rachford operator  $R_{\gamma q}R_{\gamma f}$ . That is, it is given by the iteration

$$z^{k+1} = ((1-\alpha)\operatorname{Id} + \alpha R_{\gamma g} R_{\gamma f}) z^k$$
(9)

where  $\alpha \in (0,1)$  to guarantee convergence in the general case, see [19]. (We will, however, see that when additional regularity assumptions are introduced,  $\alpha=1$ , i.e. Peaceman-Rachford splitting, and even some  $\alpha>1$  can be used and convergence can still be guaranteed.)

The Douglas-Rachford algorithm (9) can more explicitly be written as

$$x^k = \operatorname{prox}_{\gamma f}(z^k) \tag{10}$$

$$y^k = \operatorname{prox}_{\gamma q}(2x^k - z^k) \tag{11}$$

$$z^{k+1} = z^k + 2\alpha(y^k - x^k). \tag{12}$$

Note that sometimes, the algorithm obtained by letting  $\alpha=1/2$  is called Douglas-Rachford splitting [18]. Here we use the name Douglas-Rachford splitting for all feasible values of  $\alpha$ .

#### A. Linear Convergence

Under some regularity assumptions, the convergence of the Douglas-Rachford algorithm is linear. We will analyze its convergence under the following set of assumptions:

**Assumption 1**: Suppose that:

- i) f and g are proper, closed, and convex.
- ii) f is  $\sigma$ -strongly convex and  $\beta$ -smooth.

To show linear convergence rates of the Douglas-Rachford algorithm under these regularity assumptions on f, we need to characterize some properties of the proximal and reflected proximal operators to f. Specifically, we will show that the reflected proximal operator of f is contractive (as opposed to nonexpansive in the general case). We will also provide a tight contraction factor.

The key to arriving at this contraction factor is the following, to the authors' knowledge, novel (but straightforward) interpretation of the proximal operator.

**Proposition 1**: Assume that  $f \in \Gamma_0(\mathcal{H})$  and that  $\gamma \in (0, \infty)$  and define  $f_{\gamma}$  as

$$f_{\gamma} := \gamma f + \frac{1}{2} \| \cdot \|^2.$$
 (14)

Then  $\mathrm{prox}_{\gamma f}(y) = \nabla f_{\gamma}^*(y).$ 

*Proof:* Since the proximal operator is the resolvent of  $\gamma \partial f$ , see [1, Example 23.3]], we have  $\operatorname{prox}_{\gamma f}(y) = (\operatorname{Id} + \gamma \partial f)^{-1} y = (\partial f_{\gamma})^{-1} y$ . Since  $f \in \Gamma_0(\mathcal{H})$  and  $\gamma \in (0, \infty)$  also  $f_{\gamma} \in \Gamma_0(\mathcal{H})$ . Therefore [1, Corollary 16.24] implies that  $\operatorname{prox}_{\gamma f}(y) = (\partial f_{\gamma})^{-1} y = \nabla f_{\gamma}^*(y)$ , where differentiability of  $f_{\gamma}^*$  follows from [1, Theorem 18.15], since  $f_{\gamma}$  is 1-strongly convex, and since  $f = (f^*)^*$  for proper, closed, and convex functions, see [1, Theorem 13.32]. This concludes the proof.

This interpretation of the proximal operator is used to prove the following proposition. The proof is found in Appendix B.

**Proposition 2:** Assume that  $f \in \Gamma_0(\mathcal{H})$  is  $\sigma$ -strongly convex and  $\beta$ -smooth and that  $\gamma \in (0,\infty)$ . Then  $\operatorname{prox}_{\gamma f} - (1/1 + \gamma \beta)\operatorname{Id}$  is  $(1/(1/1 + \gamma \sigma) - (1/1 + \gamma \beta))$ -co-coercive if  $\beta > \sigma$  and 0-Lipschitz if  $\beta = \sigma$ .

This result is used to show the following contraction properties of the reflected proximal operator. A proof to this result, which is one of the main results of the paper, is found in Appendix C.

**Theorem 1**: Suppose that  $f \in \Gamma_0(\mathcal{H})$  is  $\sigma$ -strongly convex and  $\beta$ -smooth and that  $\gamma \in (0, \infty)$ . Then  $R_{\gamma f}$  is  $\max((\gamma \beta - 1)/(\gamma \beta + 1), (1 - \gamma \sigma)/(\gamma \sigma + 1))$ -contractive.

For future reference, we let this contraction factor be denoted by  $\delta$ , i.e.,

$$\delta := \max\left(\frac{\gamma\beta - 1}{\gamma\beta + 1}, \frac{1 - \gamma\sigma}{\gamma\sigma + 1}\right). \tag{14}$$

Theorem 1 lays the foundation for the linear convergence rate result in the following theorem, which is proven in Appendix D.

**Theorem 2:** Suppose that Assumption 1 holds, that  $\gamma \in (0, \infty)$ , that  $\alpha \in (0, (2/1+\delta))$  with  $\delta$  in (14). Then the Douglas-Rachford algorithm (9) converges linearly towards a fixed-point  $\bar{z} \in \operatorname{fix}(R_{\gamma g}R_{\gamma f})$  at least with rate  $|1 - \alpha| + \alpha \delta$ , i.e.,

$$||z^{k+1} - \bar{z}|| \le (|1 - \alpha| + \alpha \delta) ||z^k - \bar{z}||.$$

**Remark 2:** Note that  $\alpha>1$  can be used in the Douglas-Rachford algorithm when solving problems that satisfy Assumption 1. (This also holds for general relaxed iteration of a contractive mapping.) That  $\alpha$ -values greater than 1 can be used is reported in [38] for ADMM (i.e., for dual Douglas-Rachford). They solve a small SDP to assess whether ADMM converges with a specific rate, for specific problem parameters  $\beta$  and  $\sigma$ , and specific algorithm parameters  $\alpha$  and  $\gamma$ . This SDP gives an affirmative answer for some problems and some  $\alpha>1$ . As opposed to here, no explicit bounds on  $\alpha$  are provided.

Also the  $x^k$  iterates in (10) converge linearly. The following corollary is proven in Appendix E.

**Corollary 1:** Let  $x^*$  be the (unique) solution to (7). Then the  $x^k$  iterates in (10) satisfy

$$||x^{k+1} - x^*|| \le (|1 - \alpha| + \delta\alpha)^{k+1} \frac{1}{1 + \gamma\sigma} ||z^0 - \bar{z}||.$$
 (15)

**Remark 3**: Note that Corollary 1 and Theorem 2 still hold if the order of  $R_{\gamma g}$  and  $R_{\gamma f}$  is swapped in the Douglas-Rachford algorithm (9).

We can choose the algorithm parameters  $\gamma$  and  $\alpha$  to optimize the bound on the convergence rate in Theorem 2. This is done in the following proposition.

**Proposition 3**: Suppose that Assumption 1 holds. Then the optimal parameters for the Douglas-Rachford algorithm in (9) are  $\alpha = 1$  and  $\gamma = (1/\sqrt{\sigma\beta})$ . Further, the optimal rate is  $((\sqrt{\beta/\sigma} - 1)/(\sqrt{\beta/\sigma} + 1))$ .

*Proof:* Since  $\delta \in [0,1)$ , the rate in Theorem 2,  $|1-\alpha|+\alpha\delta$ , is a decreasing function of  $\alpha$  for  $\alpha \leq 1$  and increasing for  $\alpha \geq 1$ . Therefore the rate factor is optimized by  $\alpha = 1$ . The  $\gamma$  parameter should be chosen to minimize the max-expression  $\max((\gamma\beta-1)/(\gamma\beta+1),(1-\gamma\sigma)/(1+\gamma\sigma))$  defining  $\delta$  in (14). This is done by setting the arguments equal, which gives  $\gamma = 1/\sqrt{\beta\sigma}$ . Inserting these values into the rate factor expression gives  $(\sqrt{\beta/\sigma}-1)/(\sqrt{\beta/\sigma}+1)$ .

**Remark 4**: Note that  $\alpha=1$  is optimal in Proposition 3. So the Peaceman-Rachford algorithm gives the best bound on the convergence rate under Assumption 1, even though it is not guaranteed to converge in the general case. The reason is that  $R_{\gamma f}$  becomes contractive under Assumption 1 (as opposed to nonexpansive in the general case).

### B. Tightness of Bounds

In this section, we show that the linear convergence rate bounds in Theorem 2 are tight. We consider a two dimensional example of the form (7) in a standard Euclidean space to show tightness. Let  $x = (x_1, x_2)$ , then the functions used are

$$f(x) = \frac{1}{2} \left( \beta x_1^2 + \sigma x_2^2 \right)$$
 (16)

$$g_1(x) = 0 \tag{17}$$

$$q_2(x) = \iota_{x=0}(x)$$
 (18)

where  $\beta \ge \sigma > 0$  and  $\iota_{x=0}$  is the indicator function for x=0, i.e.,  $\iota_{x=0}(x)=0$  iff x=0, otherwise  $\infty$ .

The function f is  $\beta$ -smooth since  $(\beta/2)\|x\|_2^2 - f(x) = (\beta - \sigma/2)x_2^2$  is convex. It is  $\sigma$ -strongly convex since  $f(x) - (\sigma/2)\|x\|_2^2 = (\beta - \sigma/2)x_1^2$  is convex. So the function f satisfies Assumption 1(ii).

The proximal operator to f is

$$\operatorname{prox}_{\gamma f}(y) = \underset{x}{\operatorname{arg\,min}} \left\{ \gamma f(x) + \frac{1}{2} \|x - y\|_{2}^{2} \right\}$$

$$= \underset{x}{\operatorname{arg\,min}} \left\{ \frac{1}{2} \left( (\beta \gamma + 1) x_{1}^{2} + (\sigma \gamma + 1) x_{2}^{2} \right) + x_{1} y_{1} + x_{2} y_{2} \right\}$$

$$= \left( \frac{1}{1 + \gamma \beta} y_{1}, \frac{1}{1 + \gamma \sigma} y_{2} \right)$$
(19)

where  $y = (y_1, y_2)$ . The reflected proximal operator is

$$\begin{split} R_{\gamma f}(y) &= 2 \mathrm{prox}_{\gamma f}(y) - y \\ &= 2 \left( \frac{1}{1 + \gamma \beta} y_1, \frac{1}{1 + \gamma \sigma} y_2 \right) - (y_1, y_2) \\ &= \left( \frac{1 - \gamma \beta}{1 + \gamma \beta} y_1, \frac{1 - \gamma \sigma}{1 + \gamma \sigma} y_2 \right). \end{split} \tag{20}$$

The proximal and reflected proximal operators to  $g_1$  in (17) are  $\operatorname{prox}_{\gamma g_1} = R_{\gamma g_1} = \operatorname{Id}$ . The proximal and reflected proximal operators to  $g_2$  in (18) are  $\operatorname{prox}_{\gamma g_2}(x) = 0$  and  $R_{\gamma g_2} = 2\operatorname{prox}_{\gamma g_2} - \operatorname{Id} = -\operatorname{Id}$ .

Next, these results are used to show tightness of the convergence rate bounds in Theorem 2. The tightness result is proven in Appendix F.

**Theorem 3**: The convergence rate bound in Theorem 2 for the Douglas-Rachford splitting algorithm (9) is tight for the class of problems that satisfy Assumption 1 for all algorithm parameters specified in Theorem 2, namely  $\alpha \in (0, (2/1+\delta))$  with  $\delta$  in (14) and  $\gamma \in (0, \infty)$ . If instead  $\alpha \not\in (0, (2/1+\delta))$ , there exist a problem that satisfies Assumption 1 that the Douglas-Rachford algorithm does not solve.

**Remark 5**: This result on tightness can be generalized to any real Hilbert space. This is obtained by considering the same  $g_1$  and  $g_2$  as in (17) and (18) but with

$$f(x) = \sum_{i=1}^{|\mathcal{H}|} \frac{\lambda_i}{2} \langle x, \phi_i \rangle^2.$$

Here  $\{\phi_i\}_{i=1}^{|\mathcal{H}|}$  is an orthonormal basis for  $\mathcal{H}$ ,  $|\mathcal{H}|$  is the dimension of the space  $\mathcal{H}$  (possibly infinite), and  $\lambda_i = \sigma > 0$  or  $\lambda_i = \beta \geq \sigma$  for all i, where at least one  $\lambda_i = \sigma$  and one  $\lambda_i = \beta$ .

#### IV. ADMM

In this section, we apply the results from the previous section to the Fenchel dual problem. Since ADMM applied to the primal problem is equivalent to the Douglas-Rachford algorithm applied to the dual problem, the results obtained in this section hold for ADMM.

We consider solving problems of the form

minimize 
$$f(x) + g(y)$$
  
subject to  $Ax + By = c$  (21)

where  $f \in \Gamma_0(\mathcal{H}_1)$ ,  $g \in \Gamma_0(\mathcal{H}_2)$ ,  $\mathcal{A} : \mathcal{H}_1 \to \mathcal{K}$  and  $\mathcal{B} : \mathcal{H}_2 \to \mathcal{K}$  are bounded linear operators and  $c \in \mathcal{K}$ . In addition, we assume:

### Assumption 2:

- i)  $f \in \Gamma_0(\mathcal{H}_1)$  is  $\beta$ -smooth and  $\sigma$ -strongly convex.
- ii)  $\mathcal{A}:\mathcal{H}_1\to\mathcal{K}$  is surjective.

The assumption that  $\mathcal{A}$  is a surjective bounded linear operator reduces to that  $\mathcal{A}$  is a real matrix with full row rank in the Euclidean case.

Problems of the form (21) cannot be directly efficiently solved using Douglas-Rachford splitting. Therefore, we instead solve the (negative) Fenchel dual problem, which is

minimize 
$$d_1(\mu) + d_2(\mu)$$
 (22)

where  $d_1, d_2 \in \Gamma_0(\mathcal{K})$  are

$$d_1(\mu) := f^*(-\mathcal{A}^*\mu) + \langle c, \mu \rangle, \quad d_2(\mu) = g^*(-\mathcal{B}^*\mu).$$
 (23)

The Douglas-Rachford algorithm when solving the dual problem becomes

$$z^{k+1} = ((1 - \alpha)\text{Id} + \alpha R_{\gamma d_1} R_{\gamma d_2}) z^k.$$
 (24)

This formulation will be used when analyzing ADMM since for  $\alpha = 1/2$  it is equivalent to ADMM and for  $\alpha \in (0, 1/2]$ and  $\alpha \in [1/2,1)$  it is equivalent to under- and over-relaxed ADMM, see [18]-[20]. Note that we only use (24) as an analysis algorithm for ADMM. The algorithm should still be implemented as the standard ADMM algorithm (with overor under-relaxation). Here we state ADMM with scaled dual variables u, see [6]

$$x^{k+1} = \arg\min_{x} \left\{ f(x) + \gamma 2 ||Ax + By^k - c + u^k||_{2q}^2 \right\}$$
 (25)

$$x_A^{k+1} = 2\alpha A x^{k+1} - (1 - 2\alpha)(By^k - c)$$
(26)

$$y^{k+1} = \underset{y}{\arg\min} \left\{ g(y) + \frac{\gamma}{2} \left\| x_A^{k+1} + By - c + u^k \right\|_2^2 \right\}$$
 (27)

$$u^{k+1} = u^k + \left(x_A^{k+1} + By^{k+1} - c\right) \tag{28}$$

where  $z^k$  in (24) satisfies  $z^k = \gamma(u^k - By^k)$ , see [19, Theorem 8] and [27, Appendix B].

#### A. Linear Convergence

To show linear convergence rate results in this dual setting, we need to quantify the strong convexity and smoothness parameters for  $d_1$  in (23). This is done in the following proposition.

**Proposition 4**: Suppose that Assumption 2 holds. Then  $d_1 \in \Gamma_0(\mathcal{K})$  in (23) is  $(\|\mathcal{A}^*\|^2/\sigma)$ -smooth and  $(\theta^2/\beta)$ -strongly convex, where  $\theta > 0$  always exists and satisfies  $\|A^*\mu\| \ge \theta \|\mu\|$ for all  $\mu \in \mathcal{K}$ .

*Proof:* We define  $d(\mu) := f^*(-A^*\mu)$ , so  $d_1(\mu) =$  $d(\mu) + \langle c, \mu \rangle$ . We first note that the linear term  $\langle c, \mu \rangle$  does not affect the strong convexity or smoothness parameters. So, we proceed by showing d is  $(\|A^*\|^2/\sigma)$ -smooth and  $(\theta^2/\beta)$ strongly convex.

Since f is  $\sigma$ -strongly convex, [1, Theorem 18.15] gives that  $f^*$  is  $(1/\sigma)$ -smooth and that  $\nabla f^*$  is  $(1/\sigma)$ -Lipschitz continuous. Therefore,  $\nabla d$  satisfies

$$\begin{split} \|\nabla d(\mu) - \nabla d(\nu)\| &= \|\mathcal{A}\nabla f^*(-\mathcal{A}^*\mu) - \mathcal{A}\nabla f^*(-\mathcal{A}^*\nu)\| \\ &\leq \frac{\|\mathcal{A}\|}{\sigma} \|\mathcal{A}^*(\mu - \nu)\| \leq \frac{\|\mathcal{A}^*\|^2}{\sigma} \|\mu - \nu\| \end{split}$$

since  $\|A\| = \|A^*\|$ . This is equivalent to that d is  $(\|A^*\|^2/\sigma)$ smooth, see [1, Theorem 18.15].

Next, we show the strong convexity result for d. Since fis  $\beta$ -smooth,  $f^*$  is  $(1/\beta)$ -strongly convex, and  $\nabla f^*$  is  $(1/\beta)$ strongly monotone, see [1, Theorem 18.15]. Therefore,  $\nabla d$ satisfies

$$\begin{split} \langle \nabla d(\mu) - \nabla d(\nu), \mu - \nu \rangle \\ &= \langle -\mathcal{A} \left( \nabla f^*(-\mathcal{A}^*\mu) - \nabla f^*(-\mathcal{A}^*\nu) \right), \mu - \nu \rangle \\ &= \langle \nabla f^*(-\mathcal{A}^*\mu) - \nabla f^*(-\mathcal{A}^*\nu), -\mathcal{A}^*\mu + \mathcal{A}^*\nu) \rangle \\ &\geq \frac{1}{\beta} \left\| \mathcal{A}^*(\mu - \nu) \right\|^2 \geq \frac{\theta^2}{\beta} \|\mu - \nu\|^2. \end{split}$$

This, by [1, Theorem 18.15], is equivalent to d being  $(\theta^2/\beta)$ strongly convex. That  $\theta > 0$  follows from [1, Fact 2.18 and Fact 2.19]. Specifically, [1, Fact 2.18]] says that ker  $A^* =$  $(\operatorname{ran} A)^{\perp} = \emptyset$ , since A is surjective. Since  $\operatorname{ran} A = \mathcal{K}$  (again by surjectivity), it is closed. Then [1, Fact 2.19] states that there exists  $\theta > 0$  such that  $\|\mathcal{A}^*\mu\| \ge \theta \|\mu\|$  for all  $\mu \in (\ker \mathcal{A}^*)^{\perp} =$ 

Combining this result with Theorem 1 implies that  $R_{\gamma d_1}$  is  $\delta$ -contractive with

$$\hat{\delta} := \max\left(\frac{\gamma\hat{\beta} - 1}{1 + \gamma\hat{\beta}}, \frac{1 - \gamma\hat{\sigma}}{1 + \gamma\hat{\sigma}}\right) \tag{29}$$

where  $\hat{\beta} = (\|\mathcal{A}^*\|^2/\sigma)$  and  $\hat{\sigma} = (\theta^2/\beta)$ . This gives the following immediate corollary to Theorem 2 and Proposition 3.

**Corollary 2**: Suppose that Assumption 2 holds, that  $\gamma \in$  $(0,\infty)$ , and that  $\alpha \in (0,(2/1+\delta))$  with  $\delta$  in (29). Then algorithm (24) [or equivalently ADMM applied to solve (21)] converges at least with rate  $|1 - \alpha| + \alpha \delta$ , i.e.,

$$||z^{k+1} - \bar{z}|| \le \left(|1 - \alpha| + \alpha\hat{\delta}\right) ||z^k - \bar{z}||$$

where  $\bar{z} \in \text{fix}(R_{\gamma d_1}R_{\gamma d_2})$ .

Further, the algorithm parameters  $\gamma$  and  $\alpha$  that optimize the rate bound are  $\alpha = 1$  and  $\gamma = (1/\sqrt{\hat{\beta}\hat{\sigma}}) = (\sqrt{\beta\sigma}/\|\mathcal{A}^*\|\theta)$ . The optimized linear convergence rate bound factor is  $(\sqrt{\hat{\kappa}} -$ 1)/ $(\sqrt{\hat{\kappa}} + 1)$ , where  $\hat{\kappa} = (\hat{\beta}/\hat{\sigma}) = (\|\mathcal{A}^*\|^2 \beta/\theta^2 \sigma)$ .

**Remark 6**: Similarly to in the primal setting in Corollary 1, R-linear convergence for the  $x^k$  update in (25) can be shown. The proof is more elaborate than the corresponding proof for primal Douglas-Rachford. This result is therefore omitted due to space considerations.

#### B. Tightness of Bounds

Also in this dual setting, the convergence rate estimates are tight. Consider again the functions (16)–(18). Further let c=0,

$$\mathcal{B} = -I, \text{ and } \mathcal{A} := \begin{bmatrix} \theta & 0 \\ 0 & \zeta \end{bmatrix} \text{ with } \zeta \ge \theta > 0.$$
 Since  $f^*(\nu) = 1/2((1/\beta)\nu_1^2 + (1/\sigma)\nu_2^2)$  for  $f$  in (16), we get

$$d_1(\mu) = f^*(-A^T \mu) = \frac{1}{2} \left( \frac{\theta^2}{\beta} \mu_1^2 + \frac{\zeta^2}{\sigma} \mu_2^2 \right).$$

Since  $d_1$  is on the same form as f in Section III-B,  $d_1$  is  $\hat{\sigma} :=$  $(\theta^2/\beta)$ -strongly convex and  $\hat{\beta} := (\zeta^2/\sigma)$ -smooth, or equivalently  $\hat{\beta} := (\|\mathcal{A}^T\|^2/\sigma)$ -smooth since  $\zeta = \|\mathcal{A}\| = \|\mathcal{A}^T\|$ . Further  $d_2(\mu) = g^*(-\mathcal{B}^T \mu) = g^*(\mu)$  where either  $g = g_1$  with  $g_1$ in (17) or  $g = g_2$  with  $g_2$  in (18). The functions  $g_1$  and  $g_2$  in (17) and (18) are each other's conjugates, i.e.,  $g_1^* = g_2$  and  $g_2^* = g_1$ . Therefore, the dual problem

minimize 
$$d_1(\mu) + d_2(\mu)$$

(with  $d_2 = g_1$  or  $d_2 = g_2$ ) is the same as the problem considered in Section III-B but with the smoothness parameter  $\beta$ in Section III-B replaced by  $\hat{\beta} = (\|A^*\|^2/\sigma)$  and the strong convexity modulus  $\sigma$  in Section III-B replaced by  $\hat{\sigma} = (\theta^2/\beta)$ . Therefore, we can state the following immediate corollary to

*Corollary 3:* The convergence rate bound in Corollary 2 for ADMM applied to the primal or, equivalently, the Douglas-Rachford algorithm applied to the dual (24), is tight for the class of problems that satisfy Assumption 2 for all algorithm parameters specified in Corollary 2, namely for  $\alpha \in (0, (2/1 + \hat{\delta}))$  with  $\hat{\delta}$  in (29) and  $\gamma \in (0, \infty)$ . If instead  $\alpha \not\in (0, (2/1 + \hat{\delta}))$ , there exist a problem that satisfies Assumption 2 that the algorithm does not solve.

**Remark 7**: As in the primal Douglas-Rachford case, tightness can be shown in general real Hilbert spaces. This is obtained with the same f,  $g_1$ , and  $g_2$  as in Remark 5 and with  $\mathcal{B} = -\mathrm{Id}$ , c = 0, and

$$\mathcal{A}x = \sum_{i=1}^{|\mathcal{H}|} \nu_i \langle x, \phi_i \rangle \phi_i$$

where  $\nu_i = \theta > 0$  if  $\lambda_i = \beta$  in Remark 5 and  $\nu_i = \zeta \ge \theta$  if  $\lambda_i = \sigma$  in Remark 5.

### V. RELATED WORK

Recently, many works have appeared that show linear convergence rate bounds for Douglas-Rachford splitting and ADMM under different sets of assumptions. In this section, we will discuss and compare some of these linear convergence rate bounds that hold with the assumptions stated in this paper. For simplicity, we will compare the various optimal rates, i.e., rates obtained by using optimal algorithm parameters.

Specifically, we will compare our results in Proposition 3 and Corollary 2 to the previously known linear convergence rate results in [14], [16], [22], [36], [40] and the linear convergence rate [38] that appeared online during the submission procedure of this paper.

Some of these results consider the Douglas-Rachford algorithm while others consider ADMM. A Douglas-Rachford rate result becomes an ADMM rate result by replacing the strong convexity and smoothness parameters  $\sigma$  and  $\beta$  with the dual problem counterparts  $\hat{\sigma}=(\theta^2/\beta)$  and  $\hat{\beta}=(\|\mathcal{A}^*\|^2/\sigma)$ , see Proposition 4. All rate bounds in this comparison that directly analyze ADMM also depend on the dual problem strong convexity and smoothness parameters  $\hat{\sigma}$  and  $\hat{\beta}$ . Therefore, the comparison can be carried out in dual problem parameters  $\hat{\sigma}$  and  $\hat{\beta}$ . Obviously, since our bounds are tight, none of the other bounds can be better. This comparison is merely to show that we improve and/or generalize previous results.

In [36, Proposition 4, Remark 10], the linear convergence rate for Douglas-Rachford splitting with  $\alpha=1/2$  when solving monotone inclusion problems with one operator being  $\hat{\sigma}$ -strongly monotone and  $\hat{\beta}$ -Lipschitz continuous is shown to be  $\sqrt{1-(\hat{\sigma}/2\hat{\beta})}$ . Note that the setting considered in [36] is more general than the setting in this paper. Recently, this bound was improved in [23] where tight estimates are provided.

In [14, Theorem 6], dual Douglas-Rachford splitting with  $\alpha=1$  is shown to converge linearly at least with rate  $\sqrt{1-(\hat{\sigma}/\hat{\beta})}$ . For  $\alpha=1/2$  they recover the bound in [36]. In Fig. 1, the former (better) of these rate bounds is plotted. We see that it is more conservative than the one in Corollary 2.

![](_page_5_Figure_12.jpeg)

Fig. 1. Comparison between linear convergence rate bounds for Douglas-Rachford splitting/ADMM provided in [14], [16], [22], [38], [40] and in Corollary 2.

The optimal convergence rate bound in [16, Corollary 3.6] is  $\sqrt{1/(1+1/\sqrt{\hat{\beta}/\hat{\sigma}})}$  and is analyzed directly in the ADMM setting. Fig. 1 reveals that our rate bound is tighter.

In [40], the authors show that if the  $\gamma$  parameter is small enough and if f is a quadratic function, then Douglas-Rachford splitting is equivalent to a gradient method applied to a smooth convex function named the Douglas-Rachford envelope. Convergence rate estimates then follow from the gradient method rate estimates. Also, accelerated variants of Douglas-Rachford splitting are proposed, based on fast gradient methods. In Fig. 1, we compare to the rate bound of the fast Douglas-Rachford splitting in [40, Theorem 6] when applied to the dual. This rate bound is better than the rate bound for standard Douglas-Rachford splitting in [40, Theorem 4]. We note that Corollary 2 gives better rate bounds.

The convergence rate bound provided in [22] coincides with the bound provided in Corollary 2. The rate bound in [22] holds for ADMM applied to Euclidean quadratic problems with linear inequality constraints. We generalize these results, using a different machinery, to arbitrary real Hilbert spaces (also infinite dimensional), to both Douglas-Rachford splitting and ADMM, to general smooth and strongly convex functions f, and, perhaps most importantly, to any proper, closed, and convex function g.

Finally, we compare our rate bound to the rate bound in [38]. Fig. 1 shows that our bound is tighter. As opposed to all the other rate bounds in this comparison, the rate bound in [38] is not explicit. Rather, a sweep over different rate bound factors is needed. For each guess, a small semi-definite program is solved to assess whether the algorithm is guaranteed to converge with that rate. The quantization level of this sweep is the cause of the steps in the rate curve in Fig. 1.

#### VI. METRIC SELECTION

In this section, we consider problems of the form (21) in an Euclidean setting. We assume  $f \in \Gamma_0(\mathbb{H}_M)$ ,  $g \in \Gamma_0(\mathbb{H}_{\hat{K}})$ ,  $\mathcal{A} : \mathbb{H}_M \to \mathbb{H}_K$ ,  $\mathcal{B} : \mathbb{H}_{\hat{K}} \to \mathbb{H}_K$ ,  $c \in \mathbb{H}_K$  and that:

#### Assumption 3:

- i)  $f \in \Gamma_0(\mathbb{H}_M)$  is 1-strongly convex if defined on  $\mathbb{H}_H$  (i.e., M = H) and 1-smooth if defined on  $\mathbb{H}_L$  (i.e., M = L).
- ii) The bounded linear operator  $\mathcal{A}: \mathbb{H}_M \to \mathbb{H}_K$  is surjective.

We solve (21) by applying Douglas-Rachford splitting on the dual problem (22) (or equivalently by applying ADMM directly on the primal (21)). This algorithm behaves differently depending on which space  $\mathbb{H}_K$  the problem is defined and the algorithm is run. We will show how to select a space  $\mathbb{H}_K$  on which the algorithm rate bound is optimized. To aid in this selection, we show in the following proposition how the strong convexity modulus and smoothness constant of  $d_1 \in \Gamma_0(\mathbb{H}_K)$  depend on the space on which it is defined.

**Proposition 5:** Suppose that Assumption 3 holds, that  $A \in \mathbb{R}^{m \times n}$  satisfies  $Ax = \mathcal{A}x$  for all x, and that  $K = E^T E$ . Then  $d_1 \in \mathbb{H}_K$  in (23) is  $\|EAH^{-1}A^T E^T\|_2$ -smooth and  $\lambda_{\min}(EAL^{-1}A^T E^T)$ -strongly convex, where  $\lambda_{\min}(EAL^{-1}A^T E^T) > 0$ .

*Proof:* First, we note that  $d_1(\mu) = d(\mu) + \langle c, \mu \rangle$  where  $d(\mu) = f^*(-A^*\mu)$  and that a linear function does not change the strong convexity of smoothness parameter of a problem. Therefore, we show the result for d.

First, we relate  $\mathcal{A}^* : \mathbb{H}_K \to \mathbb{H}_M$  to A, M, and K. We have

$$\langle \mathcal{A}x, \mu \rangle_K = \langle Ax, K\mu \rangle_2 = \langle x, A^T K\mu \rangle_2 = \langle x, M^{-1} A^T K\mu \rangle_M$$
$$= \langle M^{-1} A^T K\mu, x \rangle_M = \langle \mathcal{A}^*\mu, x \rangle_M.$$

Thus,  $\mathcal{A}^*\mu = M^{-1}A^TK\mu$  for all  $\mu \in \mathbb{H}_K$ .

Next, we show that the space  $\mathbb{H}_M$  on which f and  $f^*$  are defined does not influence the shape of d. We denote by  $f_H$ ,  $f_L$ , and  $f_e$  the function f defined on  $\mathbb{H}_H$ ,  $\mathbb{H}_L$ , and  $\mathbb{R}^n$  respectively and by  $\mathcal{A}_H^*:\mathbb{H}_K\to\mathbb{H}_H$ ,  $\mathcal{A}_L^*:\mathbb{H}_K\to\mathbb{H}_L$ , and  $A^T:\mathbb{R}^m\to\mathbb{R}^n$  the operator  $\mathcal{A}^*$  defined on the different spaces. Further, let  $d_H:=f_H^*\circ-\mathcal{A}_H^*$ ,  $d_L:=f_L^*\circ-\mathcal{A}_L^*$ , and  $d_e:=f_e^*\circ-A^T$ . With these definitions both  $d_L$  and  $d_H$  are defined on  $\mathbb{H}_K$ , while  $d_e$  is defined on  $\mathbb{R}^m$ . Next we show that  $d_L$  and  $d_H$  are identical for any  $\mu$ 

$$d_{H}(\mu) = f_{H}^{*} (-A_{H}^{*}\mu) = \sup_{x} \{ \langle -A_{H}^{*}\mu, x \rangle_{H} - f_{H}(x) \}$$

$$= \sup_{x} \{ \langle -HH^{-1}A^{T}K\mu, x \rangle_{2} - f_{e}(x) \}$$

$$= \sup_{x} \{ \langle -LL^{-1}A^{T}K\mu, x \rangle_{2} - f_{e}(x) \}$$

$$= \sup_{x} \{ \langle -A_{L}^{*}\mu, x \rangle_{L} - f_{L}(x) \} = d_{L}(\mu)$$

where  $\mathcal{A}_{M}^{*}\mu=M^{-1}A^{T}K\mu$  is used. This implies that we can show properties of  $d\in\mathbb{H}_{K}$  by defining f on any space  $\mathbb{H}_{M}$ . Thus, Proposition 4 gives that 1-strong convexity of f when defined on  $\mathbb{H}_{H}$  implies  $\|\mathcal{A}^{*}\|^{2}$ -smoothness of d, where

$$\begin{split} \|\mathcal{A}^*\| &= \sup_{\mu} \left\{ \|\mathcal{A}^*\mu\|_H |\|\mu\|_K \le 1 \right\} \\ &= \sup_{\mu} \left\{ \|H^{-1}A^TK\mu\|_H |\|\mu\|_K \le 1 \right\} \\ &= \sup_{\mu} \left\{ \|H^{-1/2}A^TE^TE\mu\|_2 |\|E\mu\|_2 \le 1 \right\} \\ &= \sup_{\nu} \left\{ \|H^{-1/2}A^TE^T\nu\|_2 |\|\nu\|_2 \le 1 \right\} \\ &= \|H^{-1/2}A^TE^T\|_2. \end{split}$$

Squaring this gives the smoothness claim. To show the strong-convexity claim, we use that 1-smoothness of f when defined on  $\mathbb{H}_L$  implies  $\theta^2$ -strong convexity of d where  $\theta > 0$  satisfies  $\|\mathcal{A}^*\mu\|_L \ge \theta \|\mu\|_K$  for all  $\mu \in \mathbb{H}_K$ , see Proposition 4. We have

$$\begin{split} \|\mathcal{A}^*\mu\|_L^2 &= \|L^{-1}A^TK\mu\|_L^2 = \|L^{-1/2}A^TE^T(E\mu)\|_2^2 \\ &= \|E\mu\|_{EAL^{-1}A^TE^T}^2 \\ &\geq \lambda_{\min}(EAL^{-1}A^TE^T)\|E\mu\|_2^2 \\ &= \lambda_{\min}(EAL^{-1}A^TE^T)\|\mu\|_K^2 \end{split}$$

i.e.,  $\theta^2 = \lambda_{\min}(EAL^{-1}A^TE^T)$ . The smallest eigenvalue  $\lambda_{\min}(EAL^{-1}A^TE^T) > 0$  since A is surjective, i.e. has full row rank, and E and L are positive definite matrices. This concludes the proof.

This result shows how the smoothness constant and strong convexity modulus of  $d_1 \in \Gamma_0(\mathbb{H}_K)$  change with the space  $\mathbb{H}_K$  on which it is defined. Combining this with Proposition 3, we get that the bound on the convergence rate for Douglas-Rachford splitting applied to the dual problem (22) [or equivalently ADMM applied to the primal (21)] is optimized by choosing  $K = E^T E$  where E is chosen to

minimize 
$$\frac{\lambda_{\max}(EAH^{-1}A^TE^T)}{\lambda_{\min}(EAL^{-1}A^TE^T)}$$
 (30)

and by choosing  $\gamma = (1/\sqrt{\lambda_{\max}(EAH^{-1}A^TE^T)\lambda_{\min}(EAL^{-1}A^TE^T)})$ . Using a non-diagonal K usually gives prohibitively expensive prox-evaluations. Therefore, we propose to select a diagonal  $K = E^TE$  that minimizes (30). The reader is referred to [26, Section 6] for different methods to achieve this exactly and approximately.

**Remark 8:** It can be shown (details are omitted for space considerations) that solving the dual problem on space  $\mathbb{H}_K$  using Douglas-Rachford splitting is equivalent to solving the preconditioned problem

minimize 
$$f(x) + g(y)$$
  
subject to  $E(Ax + By) = Ec$  (31)

using ADMM. Therefore, the metric selection presented here covers the preconditioning suggestion in [22] as a special case.

**Remark 9**: Metric selection and preconditioning is not new for iterative methods. It can be used with the aim to reduce the computational burden within each iteration [7], [8], [11], [33], [43], and/or with the aim to reduce the total number of iterations like in our analysis and in [4], [7], [22], [26], [33]. It is interesting to note that in our paper (if we restrict ourselves to quadratic f with Hessian H) and in [7], [22], [26], [33], different algorithms are analyzed with different methods, but all analyses suggest to make  $AH^{-1}A^{T}$  well conditioned (by choosing a metric or doing preconditioning). The analyzed algorithms are ADMM here and in [22], (fast) dual forward-backward splitting in [26], and Uzawa's method to solve linear systems of the form  $\begin{bmatrix} A^T \\ 0 \end{bmatrix}(x,\mu) = (-q,b)$  in [7], [33]. This linear system is  $\lceil H \rceil$ the KKT-condition for the problem  $\min_{x} \{ f(x) + g(y) | Ax = y \}$ where  $f(x) = 1/2x^T H x + q^T x$  and  $g(y) = \iota_{y=b}(y)$ . The dual functions are  $d_1(\mu) = (q + A^T \mu)^T H^{-1} (A^T \mu + q)$  with Hessian  $AH^{-1}A^T$  and  $d_2(\mu) = g^*(\mu) = b^T\mu$ . The functions

 $d_1$  in the dual problems in all these analyses are the same (if we restrict ourselves to quadratic f with Hessian H in our setting), but the functions  $d_2$  are different. So all the different metric selections (preconditionings) try to make  $d_1$ , and its Hessian  $AH^{-1}A^T$ , well conditioned.

#### A. Heuristic Metric Selection

Many problems do not satisfy all assumptions in Assumption 2, but for many interesting problems a couple of them are typically satisfied. Therefore, we will here discuss metric and parameter selection heuristics for ADMM [Douglas-Rachford applied to the dual (22)] when some of the assumptions are not met. We focus on quadratic problems of the form

minimize 
$$\underbrace{\frac{1}{2}x^{T}Qx + q^{T}x + \hat{f}(x)}_{f(x)} + g(y)$$
subject to 
$$Ax + By = c \tag{32}$$

where  $Q \in \mathbb{R}^{n \times n}$  is positive semi-definite,  $q \in \mathbb{R}^n$ ,  $\hat{f} \in \Gamma_0(\mathbb{R}^n)$ ,  $g \in \Gamma_0(\mathbb{R}^m)$ ,  $A \in \mathbb{R}^{p \times n}$ ,  $B \in \mathbb{R}^{p \times m}$ , and  $c \in \mathbb{R}^p$ .

One set of assumptions that guarantee linear convergence for dual Douglas-Rachford splitting is that Q is positive definite, that  $\hat{f}$  is nonsmooth, and that A has full row rank. By inverting these, we get a set of assumptions that if anyone of these are satisfied, we cannot guarantee linear convergence:

- i) Q is not positive definite, but positive semi-definite.
- ii) f is nonsmooth, e.g., the indicator function of a convex constraint set or a piece-wise affine function
- iii) A does not have full row rank.

In the first case, we loose strong convexity in f and smoothness in the dual  $d_1$ . In the second case, we loose smoothness in f and strong convexity  $d_1$ . In the third case, we loose strong convexity in the dual  $d_1$ .

We directly tackle the case where the assumptions needed to get linear convergence are violated by all points (i), (ii), and (iii). For the dual case we consider, i.e., the ADMM case, we propose to select the metric as if  $\hat{f}\equiv 0$  in (32). To do this, we define the quadratic part of f in (32) to be  $f_{\mathrm pc}(x):=1/2x^TQx+q^Tx$  and introduce the function  $d_{\mathrm pc}:=f_{\mathrm pc}^*\circ -A^T.$  The conjugate function of  $f_{\mathrm pc}$  is given by

$$f_{\text{p}c}^*(y) = \sup_{x} \{ \langle y, x \rangle - f_{\text{p}c}(x) \}$$

$$= \begin{cases} \frac{1}{2} (y - q)^T Q^{\dagger}(y - q) & \text{if } (y - q) \in \mathcal{R}(Q) \\ \infty & \text{else} \end{cases}$$

where  $Q^{\dagger}$  is the pseudo-inverse of Q and  $\mathcal R$  denotes the range space. This gives

$$\begin{aligned} d_{\mathrm{pc}}(\mu) \\ &= \begin{cases} \frac{1}{2} (A^T \mu + q)^T Q^{\dagger} (A^T \mu - q) & \text{if } (A^T \mu + q) \in \mathcal{R}(Q) \\ \infty & \text{else} \end{cases} \end{aligned}$$

with Hessian  $AQ^\dagger A^T$  on its domain. We approximate the dual function  $d_1(\mu)=f^*(-A^T\mu)+c^T\mu$  with  $d_{\rm pc}(\mu)+c^T\mu$ . Then we propose to select a diagonal metric  $K=E^TE$  such that

this approximation is well conditioned in directions where it has curvature. That is, we propose to select a metric  $K=E^TE$  such that the pseudo condition number of  $AQ^\dagger A^T$  is minimized. This is achieved by finding an E to

$$\mbox{minimize} \quad \frac{\lambda_{\max}(EAQ^{\dagger}A^TE^T)}{\lambda_{\min>0}(EAQ^{\dagger}A^TE^T)}$$

where  $\lambda_{\rm min>0}$  denotes the smallest non-zero eigenvalue. (See [26, Section 6] for methods to achieve this exactly and approximately.) This heuristic reduces to the optimal metric choice in the case where linear convergence is achieved. The  $\gamma$ -parameter is also chosen in accordance with the above reasoning and Corollary 2 as  $\gamma = (1/\sqrt{\lambda_{\rm max}(EAQ^{\dagger}A^TE^T)\lambda_{\rm min>0}(EAQ^{\dagger}A^TE^T)})$ .

If instead  $\hat{f}$  in (32) is the indicator function of an affine subspace, i.e.,  $\hat{f} = \iota_{Lx=b}$  and Q is strongly convex on the null-space of L. Then  $d_1(\mu) = 1/2\mu^T A P_{11} A^T \mu + \xi^T \mu + \chi + c^T \mu$  where  $\xi \in \mathbb{R}^n, \chi \in \mathbb{R}$ , and  $\begin{bmatrix} Q & L^T \\ L & 0 \end{bmatrix}^{-1} = \begin{bmatrix} P_{11} & P_{12} \\ P_{21} & P_{22} \end{bmatrix}$ . Then we can choose metric by minimizing the pseudo condition number of  $AP_{11}A^T$  (which is the Hessian of  $d_1$ ) and select  $\gamma$  as  $\gamma = (1/\sqrt{\lambda_{\max}(EAP_{11}A^TE^T)\lambda_{\min>0}(EAP_{11}A^TE^T)})$ .

#### VII. NUMERICAL EXAMPLE

### A. A Problem With Linear Convergence

We consider a weighted Lasso minimization problem formulation with inspiration from [10] of the form

minimize 
$$\frac{1}{2} ||Ax - b||_2^2 + ||Wx||_1$$
 (33)

with  $x \in \mathbb{R}^{200}$ , the data matrix  $A \in \mathbb{R}^{300 \times 200}$  is a sparse with on average 10 nonzero entries per row, and  $b \in \mathbb{R}^{300}$ . Each nonzero element in A and b is drawn from a Gaussian distribution with zero mean and unit variance. Further,  $W \in \mathbb{R}^{200 \times 200}$  is a diagonal matrix with positive diagonal elements drawn from a uniform distribution on the interval [0, 1].

We solve the problem using ADMM in the standard Euclidean setting and in the optimal metric setting according to Section VI. We use the optimal  $\alpha=1$  and different parameters  $\gamma.$  The  $\gamma$  parameter is varied in the range  $[10^{-2}\gamma^\star,10^2\gamma^\star]$  where  $\gamma^\star$  is the theoretically optimal  $\gamma$  in the respective settings (Euclidean and optimal metric). In Fig. 2, the actual number of iterations needed to obtain a specific accuracy (a relative tolerance of  $10^{-5}$ ) as well as the theoretical worst case number of iterations are plotted, both for the Euclidean and optimal metric setting.

Fig. 2 reveals that, for this particular example, the actual numbers of iterations are fairly consistent with the iteration bounds. We also see that there is a lot to gain by running the algorithm with an appropriately chosen metric. Also the optimal parameters  $\gamma^*$  give close to optimal performance in both settings.

#### B. A Problem Without Linear Convergence

Here, we evaluate the heuristic metric and parameter selection method by applying ADMM to the (small-scale) aircraft control problem from [3], [35]. As in [3], the continuous time model from [35] is sampled using zero-order hold every 0.05 s. The system has four states  $x=(x_1,x_2,x_3,x_4)$ , two outputs

![](_page_8_Figure_2.jpeg)

Fig. 2. Theoretical bounds on and actual number of iterations to achieve a prespecified relative accuracy of  $10^{-5}$  when solving (33) using ADMM with  $\alpha=1$  for different  $\gamma$ . We present results with and without preconditioning (metric selection).

 $y = (y_1, y_2)$ , two inputs  $u = (u_1, u_2)$ , and obeys the following

$$x^{+} = \begin{bmatrix} 0.999 & -3.008 & -0.113 & -1.608 \\ -0.000 & 0.986 & 0.048 & 0.000 \\ 0.000 & 2.083 & 1.009 & -0.000 \\ 0.000 & 0.053 & 0.050 & 1.000 \end{bmatrix} x$$

$$+ \begin{bmatrix} -0.080 & -0.635 \\ -0.029 & -0.014 \\ -0.868 & -0.092 \\ -0.022 & -0.002 \end{bmatrix} u$$

$$y = \begin{bmatrix} 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix} x$$

where  $x^+$  denotes the state in the next time step. The system is unstable, the magnitude of the largest eigenvalue of the dynamics matrix is 1.313. The outputs are the attack and pitch angles, while the inputs are the elevator and flaperon angles. The inputs are physically constrained to satisfy  $|u_i| < 25^{\circ}$ , i = 1, 2. The outputs are soft constrained and modeled using the piece-wise linear cost function

$$h(y, l, u, s) = \begin{cases} 0 & \text{if } l \le y \le u \\ s(y - u) & \text{if } y \ge u \\ s(l - y) & \text{if } y \le l. \end{cases}$$

Especially, the first output is penalized using  $h(y_1, -0.5, 0.5,$  $10^{6}$ ) and the second is penalized using  $h(y_{2}, -100, 100, 10^{6})$ . The states and inputs are penalized using

$$\ell(x, u, s) = \frac{1}{2} ((x - x_r)^T Q(x - x_r) + u^T R u)$$

where  $x_r$  is a reference,  $Q = diag(0, 10^2, 0, 10^2)$ , and R = $10^{-2}I$ . Further, the terminal cost is Q, and the control and prediction horizons are N=10. The numerical data in Fig. 3 is obtained by following a reference trajectory on the output. The objective is to change the pitch angle from  $0^{\circ}$  to  $10^{\circ}$  and then back to 0° while the angle of attack satisfies the (soft) output constraints  $-0.5^{\circ} \le y_1 \le 0.5^{\circ}$ . The constraints on the angle of attack limit the rate on how fast the pitch angle can be changed.

![](_page_8_Figure_11.jpeg)

Fig. 3. Average number of iterations for different  $\gamma$ -values, different metrics, and different relaxations  $\alpha$ .

By stacking vectors and forming appropriate matrices, the full optimization problem can be written on the form

$$\min \underbrace{\frac{1}{2}z^TQz + r_t^Tz + I_{Lz=bx_t}(z)}_{f(z)} + \underbrace{\sum_{i=1}^m h(z_i', \underline{d}_i, \overline{d}_i, 10^6)}_{g(z')}$$
s.t.  $Cz = z'$ 

where  $x_t$  and  $r_t$  may change from one sampling instant to the next. This fits the optimization problem formulation discussed in Section VI-A. For this problem all items (i)-(iii) violate the assumptions that guarantee linear convergence.

Since the numerical example treated here is a model predictive control application, we can spend much computational effort offline to compute a metric that will be used in all samples in the online controller. We compute a diagonal metric  $K = E^T E$ , where E minimizes the pseudo condition

number of 
$$ECP_{11}C^TE^T$$
 and  $P_{11}$  is implicitly defined by 
$$\begin{bmatrix} Q & L^T \\ L & 0 \end{bmatrix}^{-1} = \begin{bmatrix} P_{11} & P_{12} \\ P_{21} & P_{22} \end{bmatrix}$$
(as suggested in Section VI-A). This matrix  $K = E^TE$  defines the space  $\mathbb{H}_K$  on which the

algorithm is applied.

In Fig. 3, the performance of ADMM when applied on  $\mathbb{H}_K$ with relaxations  $\alpha = 1/2$  and  $\alpha = 0.99$ , and ADMM applied on  $\mathbb{R}^m$  with  $\alpha = 1/2$  is shown. In this particular example, improvements of about one order of magnitude are achieved when applied on  $\mathbb{H}_K$  compared to when applied on  $\mathbb{R}^m$ . Fig. 3 also shows that ADMM with over-relaxation performs better than standard ADMM. The proposed  $\gamma$ -parameter selection is denoted by  $\gamma^*$  in Fig. 3 (E or C is scaled to get  $\gamma^* = 1$  for all examples). Fig. 3 shows that  $\gamma^*$  does not coincide with the empirically found best  $\gamma$ , but still gives a reasonable choice of  $\gamma$  in all cases.

## VIII. CONCLUSION

We have shown tight global linear convergence rate bounds for Douglas-Rachford splitting and ADMM. Based on these results, we have presented methods to select metric and algorithm parameters for these methods. We have also provided numerical examples to evaluate the proposed metric and parameter selection methods for ADMM.

## APPENDIX A A HELP LEMMA

We state the following lemma that is used in several of the proofs in this appendix.

**Lemma 1**: Let  $\gamma, \beta, \sigma \in (0, \infty)$  and  $\beta \geq \sigma$ . Then

$$\max\left(\frac{1-\gamma\sigma}{1+\gamma\sigma}, \frac{\gamma\beta-1}{1+\gamma\beta}\right) = \begin{cases} \frac{1-\gamma\sigma}{1+\gamma\sigma} & \text{if } \gamma \le \frac{1}{\sqrt{\beta\sigma}} \\ \frac{\gamma\beta-1}{1+\gamma\beta} & \text{if } \gamma \ge \frac{1}{\sqrt{\beta\sigma}} \end{cases}$$
(34)

Further  $\max((1-\gamma\sigma)/(1+\gamma\sigma), (\gamma\beta-1)/(1+\gamma\beta)) \in [0,1)$ .

*Proof:* Let  $\psi(x) = (1-x)/(1+x)$  for  $x \ge 0$ . This implies  $\psi'(x) = (-2/(x+1)^2)$ , i.e.,  $\psi$  is (strictly) monotonically deceasing for  $x \ge 0$ . So for  $x \le 1/y$  and  $x \ge 0$ , we have

$$\psi(x) = \frac{1-x}{1+x} \ge \frac{1-1/y}{1+1/y} = -\frac{1-y}{y+1} = -\psi(y).$$

Similarly if  $x \ge 1/y$  and  $x \ge 0$ , we have

$$\psi(x) = \frac{1-x}{1+x} \le \frac{1-1/y}{1+1/y} = -\frac{1-y}{y+1} = -\psi(y).$$

So for  $x \ge 0$ ,  $\psi(x) \le -\psi(y)$  if and only if  $x \ge 1/y$ . Therefore

$$\max\left(\frac{1-\gamma\sigma}{1+\gamma\sigma}, \frac{\gamma\beta-1}{1+\gamma\beta}\right) = \max\left(\psi(\gamma\sigma)\right), -\psi(\gamma\beta)\right)$$

$$= \begin{cases} \psi(\gamma\sigma) & \text{if } 0 < \gamma \le \frac{1}{\sqrt{\beta\sigma}} \\ -\psi(\gamma\beta) & \text{if } \gamma \ge \frac{1}{\sqrt{\beta\sigma}} \end{cases}$$

$$= \begin{cases} \frac{1-\gamma\sigma}{1+\gamma\sigma} & \text{if } 0 < \gamma \le \frac{1}{\sqrt{\beta\sigma}} \\ \frac{\gamma\beta-1}{1+\gamma\beta} & \text{if } \gamma \ge \frac{1}{\sqrt{\beta\sigma}} \end{cases}$$
(35)

Finally, since  $\psi(0)=1$  and  $\psi(1)=0$ , and  $\psi$  is strictly monotonically decreasing,  $\psi(x)\in[0,1)$  for  $x\in(0,1]$ . Also  $\psi(x)\to -1$  as  $x\to\infty$ , so  $\psi(x)\in(-1,0]$  for  $x\ge 1$ . Therefore, since  $\beta\ge\sigma$ ,  $\psi(\gamma\sigma)\in[0,1)$  if  $0\le\gamma\le(1/\sigma)$  and  $-\psi(\gamma\beta)\in[0,1)$  if  $\gamma\ge(1/\beta)$ . Since  $(1/\beta)\le(1/\sigma)$ , (35) implies that  $\max((1-\gamma\sigma/1+\gamma\sigma),(\gamma\beta-1/1+\gamma\beta))=\max(\psi(\gamma\sigma),-\psi(\gamma\beta))\in[0,1)$ .

## APPENDIX B PROOF TO PROPOSITION 2

*Proof:* Since f is  $\sigma$ -strongly convex and  $\beta$ -smooth and since  $\gamma \in (0, \infty)$ ,  $f_{\gamma}$  is  $(1 + \gamma \sigma)$ -strongly convex and  $(1 + \gamma \beta)$ -smooth. Therefore [1, Theorem 18.15] and [1, Theorem 13.32] directly imply that  $f_{\gamma}^*$  is  $(1/(1 + \gamma \sigma))$ -smooth and  $(1/1 + \gamma \beta)$ -strongly convex. From the smoothness definition in Definition 6, we get that

$$\frac{1}{2(1+\gamma\sigma)} \|\cdot\|^2 - f_{\gamma}^* 
= \left(\frac{1}{2(1+\gamma\sigma)} - \frac{1}{2(1+\gamma\beta)}\right) \|\cdot\|^2 - \left(f_{\gamma}^* - \frac{1}{2(1+\gamma\beta)} \|\cdot\|^2\right)$$
(36)

is convex. Further, Definition 5 implies that  $f_\gamma^* - (1/2(1+\gamma\beta))\|\cdot\|^2$  is convex (since  $f_\gamma^*$  is  $(1/1+\gamma\beta)$ -strongly convex), and therefore (36) is the definition of  $(1/2(1+\gamma\sigma)) - (1/2(1+\gamma\beta))$ -smoothness of  $f_\gamma^* - (1/2(1+\gamma\beta))\|\cdot\|^2$ .

Now, let  $\beta=\sigma$ , then  $f_{\gamma}^*-(1/2(1+\gamma\beta))\|\cdot\|^2$  is 0-smooth, or equivalently by applying [1, Theorem 18.15],  $\nabla f_{\gamma}^*-(1/(1+\gamma\beta))\mathrm{Id}=\mathrm{prox}_{\gamma f}-(1/1+\gamma\beta)\mathrm{Id}$  is 0-Lipschitz. Let  $\beta>\sigma$ , then [1, Theorem 18.15] implies that  $(1/2(1+\gamma\sigma))-(1/2(1+\gamma\beta))$ -smoothness of  $f_{\gamma}^*-(1/2(1+\gamma\beta))\|\cdot\|^2$  is equivalent to  $(1/(1/(1+\gamma\sigma))-(1/(1+\gamma\beta)))$ -co-coercivity of  $\nabla f_{\gamma}^*-(1/(1+\gamma\beta))\mathrm{Id}=\mathrm{prox}_{\gamma f}-(1/(1+\gamma\beta))\mathrm{Id}$ . This concludes the proof.  $\square$ 

## APPENDIX C PROOF TO THEOREM 1

*Proof:* First assume that  $\beta > \sigma$ . By Proposition 2,  $\operatorname{prox}_{\gamma f} - (1/(1+\gamma\beta))\operatorname{Id}$  is  $(1/((1/1+\gamma\sigma)) - (1/(1+\gamma\beta)))$ -co-coercive. Therefore, according to (4)

$$\operatorname{prox}_{\gamma f} - \frac{1}{1 + \gamma \beta} \operatorname{Id} = \frac{1}{2} \left( \frac{1}{1 + \gamma \sigma} - \frac{1}{1 + \gamma \beta} \right) (\operatorname{Id} + C) \quad (37)$$

for some nonexpansive mapping C.

When  $\beta = \sigma$ , Proposition 2 implies that  $\operatorname{prox}_{\gamma f} = (1/(1 + \gamma \beta))$ Id. Therefore, also in this case, it can be represented by (37) (since the right hand side is 0). We get

$$\begin{split} &\|R_{\gamma f}x-R_{\gamma f}y\|=\left\|(2\mathrm{prox}_{\gamma f}-\mathrm{Id})x-(2\mathrm{prox}_{\gamma g}-\mathrm{Id})y\right\|\\ &=\left\|\left(\frac{1}{1+\gamma\sigma}-\frac{1}{1+\gamma\beta}+\frac{2}{1+\gamma\beta}-1\right)(x-y)\right.\\ &\left.+\left(\frac{1}{1+\gamma\sigma}-\frac{1}{1+\gamma\beta}\right)(Cx-Cy)\right\|\\ &=\left\|\left(\frac{1}{1+\gamma\sigma}+\frac{1}{1+\gamma\beta}-1\right)(x-y)\right.\\ &\left.+\left(\frac{1}{1+\gamma\sigma}-\frac{1}{1+\gamma\beta}\right)(Cx-Cy)\right\|\\ &\leq\left(\left|\frac{1}{1+\gamma\sigma}+\frac{1}{1+\gamma\beta}-1\right|+\frac{1}{1+\gamma\sigma}-\frac{1}{1+\gamma\beta}\right)\|x-y\|. \end{split}$$

So  $R_{\gamma f}$  is Lipschitz continuous with constant  $|(1/(1+\gamma\sigma))+(1/(1+\gamma\beta))-1|+(1/(1+\gamma\sigma))-(1/(1+\gamma\beta))$ . The kink in the absolute value term is when

$$0 = \frac{1}{1 + \gamma \sigma} + \frac{1}{1 + \gamma \beta} - 1$$
  

$$\Leftrightarrow 0 = 1 + \gamma \beta + 1 + \gamma \sigma - (1 + \gamma \sigma)(1 + \gamma \beta)$$
  

$$\Leftrightarrow 0 = 1 - \gamma^2 \sigma \beta$$

i.e, when  $\gamma = (1/\sqrt{\beta\sigma})$ . For  $\gamma \in (0, (1/\sqrt{\beta\sigma})]$ , the expression in the absolute value is positive, and the Lipschitz constant is

$$\begin{split} \frac{1}{1+\gamma\sigma} + \frac{1}{1+\gamma\beta} - 1 + \frac{1}{1+\gamma\sigma} - \frac{1}{1+\gamma\beta} \\ &= \frac{2}{1+\gamma\sigma} - 1 = \frac{1-\gamma\sigma}{1+\gamma\sigma}. \end{split}$$

For  $\gamma \in [(1/\sqrt{\beta\sigma}), \infty)$ , the expression in the absolute value is negative, and the Lipschitz constant is

$$1 - \frac{1}{1 + \gamma \sigma} - \frac{1}{1 + \gamma \beta} + \frac{1}{1 + \gamma \sigma} - \frac{1}{1 + \gamma \beta}$$
$$= 1 - \frac{2}{1 + \gamma \beta} = \frac{\gamma \beta - 1}{1 + \gamma \beta}$$

Lemma 1 in Appendix A implies that the Lipschitz constant therefore can be written as

$$\max\left(\frac{1-\gamma\sigma}{1+\gamma\sigma}, \frac{\gamma\beta-1}{\gamma\beta+1}\right)$$

and that  $\max((1-\gamma\sigma)/(1+\gamma\sigma)), ((\gamma\beta-1)/(\gamma\beta+1)) \in [0,1),$  i.e., that  $R_{\gamma f}$  is a contraction. This concludes the proof.

## APPENDIX D PROOF TO THEOREM 2

*Proof*: Since  $\gamma \in (0, \infty)$ , [1, Corollary 23.10] implies that  $R_{\gamma g}$  is nonexpansive and by Theorem 1,  $R_{\gamma f}$  is  $\delta = \max((1-\gamma\sigma)/(1+\gamma\sigma), (\gamma\beta-1)/(\gamma\beta+1))$ -contractive. Therefore the composition  $R_{\gamma g}R_{\gamma f}$  is also  $\delta$ -contractive since

$$||R_{\gamma g}R_{\gamma f}z_1 - R_{\gamma g}R_{\gamma f}z_2|| \le ||R_{\gamma f}z_1 - R_{\gamma f}z_2|| \le \delta ||z_1 - z_2||$$
(38)

for any  $z_1, z_2 \in \mathcal{H}$ . Now, let  $T = (1 - \alpha)I + \alpha R_{\gamma g}R_{\gamma f}$  be the Douglas-Rachford operator in (9). Since  $\bar{z}$  is a fixed-point to  $R_{\gamma g}R_{\gamma f}$  it is also a fixed-point to T, i.e.,  $\bar{z} = T\bar{z}$ . Thus

$$\begin{split} \|z^{k+1} - \bar{z}\| &= \|Tz^k - T\bar{z}\|^2 \\ &= \left\| (1 - \alpha)(z^k - \bar{z}) + \alpha(R_{\gamma g}R_{\gamma f}z^k - R_{\gamma g}R_{\gamma f}\bar{z}) \right\| \\ &\leq |1 - \alpha| \|z^k - \bar{z}\| + \alpha \|R_{\gamma g}R_{\gamma f}z^k - R_{\gamma g}R_{\gamma f}\bar{z}\| \\ &\leq (|1 - \alpha| + \alpha\delta) \, \|z^k - \bar{z}\| \\ &= \left( |1 - \alpha| + \alpha \max\left(\frac{1 - \gamma\sigma}{1 + \gamma\sigma}, \frac{\gamma\beta - 1}{\gamma\beta + 1}\right) \right) \|z^k - \bar{z}\| \end{split}$$

where (38) is used in the second inequality. For any  $\gamma \in (0, \infty)$ , Lemma 1 says that  $\delta = \max((1-\gamma\sigma)/(1+\gamma\sigma), (\gamma\beta-1)/(\gamma\beta+1)) \in [0,1)$  and straightforward manipulations show that the factor

$$|1 - \alpha| + \alpha \delta < 1$$

if and only if  $\alpha \in (0, (2/1 + \delta))$ . This concludes the proof.  $\square$ 

## APPENDIX E PROOF OF COROLLARY 1

*Proof:* Since f is  $\sigma$ -strongly convex,  $f_{\gamma} = \gamma f + (1/2) \| \cdot \|^2$  is  $(1 + \gamma \sigma)$ -strongly convex, and  $\nabla f_{\gamma}^*$  is  $(1/(1 + \gamma \sigma))$ -Lipschitz continuous, see [1, Proposition 18.15].

Now, recall from Proposition 1 that  $\nabla f_{\gamma}^*(z) = \operatorname{prox}_{\gamma f}(z)$ . Further, let  $\bar{z}$  be a fixed-point to  $R_{\gamma g} R_{\gamma f}$ , i.e.,  $\bar{z}$  satisfies  $\bar{z} = R_{\gamma g} R_{\gamma f} \bar{z}$  and  $x^* = \operatorname{prox}_{\gamma f}(\bar{z})$ , see (8). Therefore

$$\begin{split} \|x^{k+1} - x^\star\| &= \left\| \operatorname{prox}_{\gamma f}(z^{k+1}) - \operatorname{prox}_{\gamma f}(\bar{z}) \right\| \\ &\leq \frac{1}{1 + \gamma \sigma} \|z^{k+1} - \bar{z}\| \\ &\leq \frac{1}{1 + \gamma \sigma} \left( |1 - \alpha| + \delta \alpha \right) \|z^k - \bar{z}\| \\ &\leq \frac{1}{1 + \gamma \sigma} \left( |1 - \alpha| + \delta \alpha \right)^{k+1} \|z^0 - \bar{z}\|. \end{split}$$

where the second and third inequalities come from Theorem 2. This concludes the proof.  $\Box$ 

## APPENDIX F PROOF OF THEOREM 3

Let  $z^0 = (1,0)$  or  $z^0 = (0,1)$ . Then separability of  $R_{\gamma f}$  (20) and  $R_{\gamma g_1} = \text{Id implies that the Douglas-Rachford algorithm (9)}$  for minimizing  $f + g_1$  is

$$z^{k+1} = \left( (1 - \alpha) + \alpha \frac{1 - \gamma \lambda_i}{1 + \gamma \lambda_i} \right) z^0 \tag{39}$$

with  $\lambda_i = \beta$  if  $z^0 = (1,0)$  and  $\lambda_i = \sigma$  if  $z^0 = (0,1)$ . The exact rate is

$$\left| 1 - \alpha + \alpha \frac{1 - \gamma \lambda_i}{1 + \gamma \lambda_i} \right|. \tag{40}$$

Similarly, when minimizing  $f+g_2$  we get (since  $R_{\gamma g_2}=-\mathrm{Id}$  and  $R_{\gamma f}$  is linear)

$$z^{k+1} = \left( (1 - \alpha) - \alpha \frac{1 - \gamma \lambda_i}{1 + \gamma \lambda_i} \right) z^0 \tag{41}$$

with exact rate

$$\left| 1 - \alpha - \alpha \frac{1 - \gamma \lambda_i}{1 + \gamma \lambda_i} \right|. \tag{42}$$

Let's consider the following four cases

i) 
$$\alpha \leq 1, \gamma \in (0, (1/\sqrt{\beta\sigma})], g = g_1, z_0 = (0, 1) \Rightarrow \lambda_i = \sigma$$

ii) 
$$\alpha \ge 1, \gamma \ge (1/\sqrt{\beta\sigma}), g = g_1, z_0 = (1,0) \Rightarrow \lambda_i = \beta$$

iii) 
$$\alpha \le 1, \gamma \ge (1/\sqrt{\beta \sigma}), g = g_2, z_0 = (1,0) \Rightarrow \lambda_i = \beta$$

iv) 
$$\alpha \ge 1, \gamma \in (0, (1/\sqrt{\beta\sigma})], g = g_2, z_0 = (0, 1) \Rightarrow \lambda_i = \sigma$$
 where  $\lambda_i$  refers to the  $\lambda_i$  in (39)–(42).

Using Lemma 1 in Appendix A, it is straightforward to verify that the exact rate factors (40) for (i) and (ii) and (42) for (iii) and (iv) equals the upper bound on the rate in Theorem 2 for  $\alpha \in (0, (2/1 + \delta))$  with  $\delta$  in (14).

It is also straightforward to verify that for  $\alpha \notin (0, (2/1 + \delta))$ , the exact rate is greater than or equal to one, so it does not converge.

We show this for the first case, and leave the three other very similar cases for the reader to verify. For case (i) with  $\alpha \in (0,1]$ , Lemma 1 implies that the rate (40) is

$$\begin{vmatrix} 1 - \alpha + \alpha \frac{1 - \gamma \sigma}{1 + \gamma \sigma} \end{vmatrix}$$

$$= 1 - \alpha + \alpha \max \left( \frac{1 - \gamma \sigma}{1 + \gamma \sigma}, \gamma \beta - 11 + \gamma \beta \right)$$

$$= |1 - \alpha| + \alpha \max \left( \frac{1 - \gamma \sigma}{1 + \gamma \sigma}, \frac{\gamma \beta - 1}{1 + \gamma \beta} \right)$$

which is the optimal rate in Theorem 2. If instead  $\alpha \leq 0$ , we get

$$\begin{split} \left| 1 - \alpha + \alpha \frac{1 - \gamma \sigma}{1 + \gamma \sigma} \right| \\ &= 1 + |\alpha| \left( 1 - \max\left( \frac{1 - \gamma \sigma}{1 + \gamma \sigma}, \frac{\gamma \beta - 1}{1 + \gamma \beta} \right) \right) \ge 1 \end{split}$$

since  $\max((1-\gamma\sigma)/(1+\gamma\sigma), (\gamma\beta-1)/(1+\gamma\beta)) \in [0,1)$  by Lemma 1. So it does not converge to the solution.

Repeating similar arguments for the three other cases gives the result.

#### ACKNOWLEDGMENT

The anonymous reviewers are gratefully acknowledged for constructive feedback that has led to significant improvements to the manuscript.

## REFERENCES

- [1] H. H. Bauschke and P. L. Combettes, *Convex Analysis and Monotone Operator Theory in Hilbert Spaces*. Berlin, Germany: Springer-Verlag, 2011.
- [2] H. H. Bauschke, J. Y. B. Cruz, T. T. A. Nghia, H. M. Phan, and X. Wang, "The rate of linear convergence of the Douglas-Rachford algorithm for subspaces is the cosine of the Friedrichs angle," *J. Approx. Theory*, vol. 185, pp. 63–79, 2014.
- [3] A. Bemporad, A. Casavola, and E. Mosca, "Nonlinear control of constrained linear systems via predictive reference management," *IEEE Trans. Automat. Control*, vol. 42, no. 3, pp. 340–349, 1997.
- [4] M. Benzi, "Preconditioning techniques for large linear systems: A survey," *J. Comput. Phys.*, vol. 182, no. 2, pp. 418–477, 2002.
- [5] D. Boley, "Local linear convergence of the alternating direction method of multipliers on quadratic or linear programs," *SIAM J. Optimiz.*, vol. 23, no. 4, pp. 2183–2207, 2013.
- [6] S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, "Distributed optimization and statistical learning via the alternating direction method of multipliers," *Foundations Trends Mach. Learn.*, vol. 3, no. 1, pp. 1–122, 2011.
- [7] J. H. Bramble, J. E. Pasciak, and A. T. Vassilev, "Analysis of the inexact Uzawa algorithm for saddle point problems," *SIAM J. Numer. Anal.*, vol. 34, no. 3, pp. 1072–1092, 1997.
- [8] K. Bredies and H. Sun, "Preconditioned Douglas-Rachford splitting methods for convex-concave saddle-point problems," *SIAM J. Numer. Anal.*, vol. 53, no. 1, pp. 421–444, 2015.
- [9] E. J. Candes, J. Romberg, and T. Tao, "Robust uncertainty principles: Exact signal reconstruction from highly incomplete frequency information," *IEEE Trans. Inform. Theory*, vol. 52, no. 2, pp. 489–509, Feb. 2006.
- [10] E. J. Candes,M. B.Wakin, and S. Boyd, "Enhancing sparsity by reweighted l1 minimization," *J. Fourier Anal. Appl.*, vol. 14, no. 5, pp. 877–905, Dec. 2008, Special issue on sparsity.
- [11] A. Chambolle and T. Pock, "A first-order primal-dual algorithm for convex problems with applications to imaging," *J. Math. Imaging Vision*, vol. 40, no. 1, pp. 120–145, 2011.
- [12] P. L. Combettes and J.-C. Pesquet, "Proximal splitting methods in signal processing," in*Fixed-Point Algorithms for Inverse Problems in Science and Engineering*, H. H. Bauschke, R. S. Burachik, P. L. Combettes, V. Elser, D. R. Luke, and H. Wolkowicz, Eds. New York, NY, USA: Springer-Verlag, 2011, vol. 49, Springer Optimization and Its Applications, pp. 185–212.
- [13] D. Davis and W. Yin, Convergence Rate Analysis of Several Splitting Schemes, Aug. 2014. [Online]. Available: http://arxiv.org/abs/1406.4834
- [14] D. Davis and W. Yin, Faster Convergence Rates of Relaxed Peaceman-Rachford and Admm Under Regularity Assumptions, Jul. 2014. [Online]. Available: http://arxiv.org/abs/1407.5210
- [15] L. Demanet and X. Zhang, Eventual Linear Convergence of the Douglas-Rachford Iteration For Basis Pursuit, May 2013. [Online]. Available: http://arxiv.org/abs/1301.0542
- [16] W. Deng and W. Yin, "On the global and linear convergence of the generalized alternating direction method of multipliers," Rice University, Houston Technical Report CAAM 12–14, 2012.
- [17] J. Douglas and H. H. Rachford, "On the numerical solution of heat conduction problems in two and three space variables," *Trans. Amer. Math. Soc.*, vol. 82, pp. 421–439, 1956.
- [18] J. Eckstein, "Splitting methods for monotone operators with applications to parallel optimization," Ph.D. dissertation, MIT, Cambridge, 1989.
- [19] J. Eckstein and D. P. Bertsekas, "On the Douglas-Rachford splitting method and the proximal point algorithm for maximal monotone operators," *Math. Program.*, vol. 55, no. 1, pp. 293–318, 1992.
- [20] D. Gabay, "Applications of the method of multipliers to variational inequalities," in *Augmented Lagrangian Methods: Applications to the Solution of Boundary-Value Problems*, M. Fortin and R. Glowinski, Eds., Amsterdam, The Netherlands: North Holland, 1983.
- [21] D. Gabay and B. Mercier, "A dual algorithm for the solution of nonlinear variational problems via finite element approximation," *Comput. Math. Appl.*, vol. 2, no. 1, pp. 17–40, 1976.
- [22] E. Ghadimi, A. Teixeira, I. Shames, and M. Johansson, "Optimal parameter selection for the alternating direction method of multipliers (ADMM):

- Quadratic problems," *IEEE Trans. Automat. Control*, vol. 60, no. 3, pp. 644–658, Mar. 2015.
- [23] P. Giselsson, Tight Global Linear Convergence Rate Bounds for Douglas-Rachford Splitting. 2015 Submitted. [Online]. Available: http://arxiv.org/ abs/1506.01556
- [24] P. Giselsson, "Tight linear convergence rate bounds for Douglas-Rachford splitting and ADMM," in *Proc. 54th CDC*, Osaka, Japan, Dec. 2015.
- [25] P. Giselsson and S. Boyd, "Diagonal scaling in Douglas-Rachford splitting and ADMM," in *Proc. CDC*, Los Angeles, CA, USA, Dec. 2014, pp. 5033–5039.
- [26] P. Giselsson and S. Boyd, "Metric selection in fast dual forward-backward splitting," *Automatica*, vol. 62, pp. 1–10, 2015.
- [27] P. Giselsson, M. Fält, and S. Boyd, Line Search for Averaged Operator Iteration, 2016. [Online]. Available: http://arxiv.org/abs/1603.06772
- [28] R. Glowinski and A. Marroco, "Sur l'approximation, par éléments finis d'ordre un, et la résolution, par pénalisation-dualité d'une classe de problémes de dirichlet non linéaires," *ESAIM: Mathematical Modelling and Numerical Analysis-Modélisation Mathématique et Analyse Numérique*, vol. 9, pp. 41–76, 1975.
- [29] T. Hastie, R. Tibshirani, and J. Friedman, *The Elements of Statistical Learning: Data Mining, Inference and Prediction*, 2nd ed. Berlin, Germany: Springer-Verlag, 2009.
- [30] B. He and X. Yuan, "On the o(1/n) convergence rate of the Douglas-Rachford alternating direction method," *SIAM J. Numer. Analysis*, vol. 50, no. 2, pp. 700–709, 2012.
- [31] R. Hesse, D. R. Luke, and P. Neumann, "Alternating projections and Douglas-Rachford for sparse affine feasibility," *IEEE Trans. Signal Process.*, vol. 62, no. 18, pp. 4868–4881, Sep. 2014.
- [32] M. Hong and Z.-Q. Luo, On the Linear Convergence of the Alternating Direction Method of Multipliers, Mar. 2013. [Online]. Available: http:// arxiv.org/abs/1208.3922
- [33] Q. Hu and J. Zou, "Nonlinear inexact Uzawa algorithms for linear and nonlinear saddle-point problems," *SIAM J. Optimiz.*, vol. 16, no. 3, pp. 798–825, 2006.
- [34] F. Iutzeler, P. Bianchi, P. Ciblat, and W. Hachem, Explicit Convergence Rate of a Distributed Alternating Direction Method of Multipliers, Dec. 2013. [Online]. Available: http://arxiv.org/abs/1312.1085
- [35] P. Kapasouris, M. Athans, and G. Stein, "Design of feedback control systems for unstable plants with saturating actuators," in *Proc. IFAC Symp. Nonlinear Control Syst. Design*, 1990, pp. 302–307, Pergamon Press.
- [36] P. L. Lions and B. Mercier, "Splitting algorithms for the sum of two nonlinear operators," *SIAM J. Numer. Anal.*, vol. 16, no. 6, pp. 964–979, 1979.
- [37] M. Lustig, D. Donoho, and J. M. Pauly, "Sparse MRI: The application of compressed sensing for rapid MR imaging," *Magnetic Resonance Medicine*, vol. 58, no. 6, pp. 1182–1195, 2007.
- [38] R. Nishihara, L. Lessard, B. Recht, A. Packard, and M. Jordan, A General Analysis of the Convergence of ADMM, Feb. 2015. [Online]. Available: http://arxiv.org/abs/1502.02009
- [39] N. Parikh and S. Boyd, "Proximal algorithms," *Foundations Trends Optimiz.*, vol. 1, no. 3, pp. 123–231, 2014.
- [40] P. Patrinos, L. Stella, and A. Bemporad, "Douglas–Rachford splitting: Complexity estimates and accelerated variants," in *Proc. CDC*, Los Angeles, CA, USA, Dec. 2014, pp. 4234–4239.
- [41] D. W. Peaceman and H. H. Rachford, "The numerical solution of parabolic and elliptic differential equations," *J. Soc. Industry Appl. Math.*, vol. 3, no. 1, pp. 28–41, 1955.
- [42] H. M. Phan, Linear Convergence of the Douglas-Rachford Method for two Closed Sets, Oct. 2014. [Online]. Available: http://arxiv.org/abs/ 1401.6509
- [43] T. Pock and A. Chambolle, "Diagonal preconditioning for first order primal-dual algorithms in convex optimization," in *Proc. ICCV*, Nov. 2011, pp. 1762–1769.
- [44] A. Raghunathan and S. Di Cairano, ADMM for Convex Quadratic Programs: Linear Convergence and Infeasibility Detection, Nov. 2014. [Online]. Available: http://arxiv.org/abs/1411.7288
- [45] J. B. Rawlings and D. Q. Mayne, *Model Predictive Control: Theory and Design*. Madison, WI, USA: Nob Hill, 2009.
- [46] R. T. Rockafellar and R. J-B. Wets, *Variational Analysis*. Berlin, Germany: Springer-Verlag, 1998.
- [47] W. Shi, Q. Ling, K. Yuan, G. Wu, and W. Yin, "On the linear convergence of the ADMM in decentralized consensus optimization," *IEEE Trans. Signal Process.*, vol. 62, no. 7, pp. 1750–1761, Apr. 2014.
- [48] R. Tibshirani, "Regression shrinkage and selection via the lasso," *J. Royal. Statist. Soc. B.*, vol. 58, no. 1, pp. 267–288, 1996.
- [49] R. Hesse and D. R. Luke, "Nonconvex notions of regularity and convergence of fundamental algorithms for feasibility problems," *SIAM J. Optimization*, vol. 23, no. 4, pp. 2397–2419, 2013.

![](_page_12_Picture_2.jpeg)

**Pontus Giselsson** received the M.Sc. and Ph.D. degrees from Lund University, Lund, Sweden, in 2006, and 2012, respectively.

During 2013 and 2014, he was a Postdoc at Stanford University, Stanford, CA, USA. He is currently an Assistant Professor at the Department of Automatic Control at Lund University. His current research interests include mathematical optimization and its applications in, e.g., control and signal processing.He is also a member of the LCCC Linneaus Center at Lund

University.

Dr. Giselsson received the Young Author Price at an IFAC Symposium in 2012, and in 2013 he was a finalist for the Best Student Paper Award at the American Control Conference. He received the Young Author Price at the IFAC World Congress in 2014, and in 2015, he received the Ingvar Carlsson Award from the Swedish Foundation for Strategic Research.

![](_page_12_Picture_7.jpeg)

**Stephen Boyd** (F'99) received the AB degree in mathematics, (summa cum laude), from Harvard University, Cambridge, MA, USA, in 1980, and the Ph.D. degree in electrical engineering and computer sciences from U. C. Berkeley, Berkeley, CA, USA, in 1985. He holds an honorary Ph.D. degree from the Royal Institute of Technology, Stockholm, Sweden.

He is the Samsung Professor of Engineering in the Information Systems Laboratory, Electrical Engineering Department, Stanford University. He

is a member of the Institute for Mathematical and Computational and Engineering, and holds courtesy appointments in the Department of Computer Science and the Department of Management Science and Engineering. His current interests include convex programming applications in control, signal processing, and circuit design. He is the author of Linear Controller Design: Limits of Performance (with Craig Barratt, 1991), Linear Matrix Inequalities in System and Control Theory (with L. El Ghaoui, E. Feron, and V. Balakrishnan, 1994), and Convex Optimization (with Lieven Vandenberghe, 2004).

Dr. Boyd received an ONR Young Investigator Award, a Presidential Young Investigator Award, the 1992 AACC Donald P. Eckman Award, and the 2013 IEEE Technical Field Award in Control Systems. In 2012, he and former student Michael Grant were awarded the Mathematical Optimization Society Beale-Orchard-Hays award for computational optimization. He has received the Perrin Award for Outstanding Undergraduate Teaching in the School of Engineering, and an ASSU Graduate Teaching Award. In 2003, he received the AACC Ragazzini Education award. He is a Distinguished Lecturer of the IEEE Control Systems Society, and a member of the National Academy of Engineering.