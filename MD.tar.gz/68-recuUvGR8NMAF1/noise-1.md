# Non-convex composite federated learning with heterogeneous data $^*$

Jiaojiao Zhang<sup>a</sup>, Jiang Hu<sup>b</sup>, Mikael Johansson<sup>a</sup>

<sup>a</sup>School of Electrical Engineering and Computer Science, KTH Royal Institute of Technology

<sup>b</sup>Massachusetts General Hospital and Harvard Medical School, Harvard University

#### Abstract

We propose an innovative algorithm for non-convex composite federated learning that decouples the proximal operator evaluation and the communication between server and clients. Moreover, each client uses local updates to communicate less frequently with the server, sends only a single d-dimensional vector per communication round, and overcomes issues with client drift. In the analysis, challenges arise from the use of decoupling strategies and local updates in the algorithm, as well as from the non-convex and non-smooth nature of the problem. We establish sublinear and linear convergence to a bounded residual error under general non-convexity and the proximal Polyak-Lojasiewicz inequality, respectively. In the numerical experiments, we demonstrate the superiority of our algorithm over state-of-the-art methods on both synthetic and real datasets.

Key words: non-convex composite federated learning; heterogeneous data; local update.

#### 1 Introduction

Federated Learning (FL) is a widely used machine learning framework in which a central server coordinates numerous clients to collaboratively train a model without sharing their local data [15]. The appeal of FL lies in its distributed computations and potential for privacy protection, making it attractive in various applications. Notable examples include enhancing the efficiency and resilience of smart grids [1], optimizing data acquisition and processing in wireless sensor networks [9], and reinforcing privacy safeguards in data-sensitive environments [27].

However, compared to conventional distributed learning, FL encounters significant challenges, notably a communication bottleneck at the server and a sensitivity to data heterogeneity among clients [15, 34]. In an effort to improve communication efficiency, McMahan et al. proposed Federated Averaging (FedAvg) [19], where

Email addresses: jiaoz@kth.se (Jiaojiao Zhang), hujiangopt@gmail.com (Jiang Hu), mikaelj@kth.se (Mikael Johansson).

clients execute multiple local updates before transmitting their updated states to the server. In cases where the clients possess similar data sets, implementing local updates is a practical method to enhance communication efficiency [24]. In heterogeneous settings, where data distributions vary across clients, many FL algorithms suffer from *client drift* [13,16]. This phenomenon occurs when individual clients, by performing multiple local updates, move excessively toward minimizing their local loss. This overfitting at the local level causes the global model, which is the average of these local models, to deviate from the optimal solution. A pedagogical illustration of client drift can be found in [13, Figure 2]. To overcome this issue, several solutions have been proposed in the literature [12, 13, 15, 23].

The majority of existing FL algorithms focus on smooth problems. However, real-world applications frequently demand the optimization of non-smooth loss functions, especially when we want to find solutions with specific properties such as sparsity or low-rank [5, 29]. This motives us to consider composite FL problems on the form

$$\underset{\mathbf{x} \in \mathbb{R}^d}{\text{minimize}} F(\mathbf{x}) := f(\mathbf{x}) + g(\mathbf{x}). \tag{1}$$

Here,  $\mathbf{x} \in \mathbb{R}^d$  represents the decision vector, i.e., the model parameters in a machine learning application,  $f(\mathbf{x}) := \frac{1}{n} \sum_{i=1}^{n} f_i(\mathbf{x})$  is the average loss across the n

<sup>\*</sup> This work was supported in part by the funding from Digital Futures and VR under the contract 2019-05319. Corresponding author is Jiaojiao Zhang. Parts of the material in this paper have been published at 2024 IEEE International Conference on Acoustics, Speech and Signal Processing.

clients that is assumed to be smooth but non-convex, and g is a convex but possibly non-smooth regularizer. To make the data dependence explicit, we let  $\mathcal{D}_i = \bigcup_{l=1}^{m_i} \mathcal{D}_{il}$ , where  $\mathcal{D}_{i1}, \ldots, \mathcal{D}_{im_i}$  denote the  $m_i$  data points of client i,  $f_{il}(\mathbf{x}; \mathcal{D}_{il})$  denote the sample loss of client i associated with the data point  $\mathcal{D}_{il}$ , and  $f_i(\mathbf{x}) := \frac{1}{m_i} \sum_{\mathcal{D}_{il} \in \mathcal{D}_i} f_{il}(\mathbf{x}; \mathcal{D}_{il})$ . Notably, no assumptions are made on the similarity among the data sets  $\mathcal{D}_i$ .

Federated learning with non-smooth, non-convex loss functions and heterogeneous data is challenging from both an algorithm design and a convergence analysis perspective. We can glimpse into these challenges through an approach called Federated Mirror Descent (FedMid) [29], which extends the FedAvg by replacing the local stochastic gradient descent (SGD) steps in the local update with proximal SGD [3, 28]. FedMid encounters an issue that the authors call "curse of primal averaging" [29]. To illustrate this phenomenon, consider a setup-up where g is the  $\ell_1$ -norm. Even if each client generates a sparse local model after the local updates, averaging these local models at the server usually leads to a solution that is no longer sparse. Similar to FedAvg, FedMid also encounters the client drift issue. These limitations significantly impair the practical performance of FedMid. In the analysis of FedMid, a key difficulty appears due to the coupling between the proximal operator and communication. If the server averages local models that have been updated using proximal operators during the local updates, it cannot recover the average gradients across all the clients due to the nonlinearity of the proximal operator mapping. This coupling, combined with the non-convex and non-smooth nature of the problem (1), makes the analysis challenging.

## 1.1 Related work

We broadly categorize the related work for solving (1) into algorithms that consider smooth (g = 0) and non-smooth  $(g \neq 0)$  losses.

Smooth FL problems. FedAvg was originally proposed in [19] for federated learning of deep networks, but without convergence analysis. A comprehensive analysis of FedAvg for strongly convex problems was conducted in [24] under the assumption of homogeneous data distribution among clients. However, when data is heterogeneous, the use of local updates in FedAvg leads to the issue of client drift. As highlighted in [35], without strong assumptions on the problem structure, the behavior of FedAvg can become highly erratic due to the impact of client drift. The impact of client drift on FedAvg was theoretically analyzed in [16, 35] under the assumption of bounded data heterogeneity. While [16] focused on strongly convex problems, [35] explored nonconvex problems. Another line of work attempts to reduce or eliminate client drift by modifying FedAvg at the algorithmic level [6, 12, 13, 15, 23]. For example, [15] and [6] penalized the difference between the local models on clients and the global model on the server to ensure that the local models remain close, thereby reducing client drift. Both [15] and [6] established convergence for non-convex problems. Scaffold [13] and Mime [12] tackle client drift by designing control variates to correct the local direction during the local updates, achieving convergence for non-convex problems. A drawback of these approaches is their need to communicate also the control variates, which increases the overall communication cost. In contrast, Fedsplit [23] adopts Peaceman-Rachford splitting [8] to address the client drift through a consensus reformulation of the original problem, exchanging only one local model per communication round for convex problems. None of the methods discussed above handles composite FL problems.

Composite FL problems. Compared to the extensive research on smooth FL problems, composite problems have received significantly less attention. An effort to bridge this gap is the Federated Dual Averaging (FedDA) introduced in [29]. In FedDA, each client employs dual averaging [21] during the local updates, while the server averages the local models in the dual space and applies the proximal step. Convergence was established for convex problems, with the ability to handle general loss functions as long as the gradients are bounded. However, under data heterogeneity, the convergence analysis is limited to quadratic loss functions. The Fast Federated Dual Averaging (Fast-FedDA) algorithm [2] incorporates weighted summation of past gradient and model information during the local updates, but it introduces additional communication overhead. While Fast-FedDA achieves convergence for general loss functions, it still relies on the assumption of bounded heterogeneity and can only handle strongly convex problems. Federated Douglas-Rachford (FedDR) was introduced in [25] and is able to avoid the bounded heterogeneity assumption. A subsequent development, FedADMM [26], utilizes FedDR to solve the dual problem of (1) and was demonstrated to have identical performance to FedDR. For both FedDR and FedADMM, convergence is established for non-convex problems and the local updates implement an inexact evaluation of the proximal operator of the smooth loss with adaptive accuracy. However, to ensure convergence, the accuracy needs to increase by every iteration, resulting in an impractically large number of local updates.

The paper [30] utilizes the mini-batch stochastic proximal point (MSPP) method as the local stochastic optimal oracle for FedProx [15]. The proximal term is used to mitigate client drift, but to guarantee convergence, the local subproblem needs to be solved exactly, which implies a large number of local updates. The paper [30] established convergence for Lipschitz-continuous and weakly convex loss functions. The work [17] investigated differential privacy in non-convex federated learning. It proposed two variance-reduced algorithms for solv-

ing composite problems under the proximal Polyak-Lojasiewicz (PL) inequality and general non-convexity, respectively. However, the algorithms in [17] utilize a single local update, leading to frequent communication between clients and the server, and assume that the smooth part of the composite loss is Lipschitz continuous.

#### 1.2 Contributions

We propose an efficient algorithm with an innovative decoupling of the proximal operator evaluation and communication. This decoupling is achieved by letting each client manipulate two local models, before and after applying the proximal mapping, and sending the preproximal local model to the server. Moreover, each client uses local updates to communicate less frequently with the server, sends only a single d-dimensional vector per communication round, and overcomes the issue of client drift by an appropriately designed correction term. In our analysis, we address challenges arising from decoupling strategies, local updates, and the non-convex, nonsmooth nature of the problem. Using a carefully crafted auxiliary function, we establish sublinear and linear convergence to a residual error when the problem is generally non-convex and satisfies the proximal PL inequality, respectively. The convergence bounds explicitly quantify the impact of problem and algorithm parameters on the convergence rate and accuracy. We verify the superiority of our algorithm over state-of-the-art methods on synthetic and real datasets in numerical experiments.

Notation. We let  $\|\cdot\|$  be  $\ell_2$ -norm and  $\|\cdot\|_1$  be  $\ell_1$ -norm. For positive integers d and n, we let  $\mathbf{I}_d$  be the  $d \times d$  identity matrix,  $\mathbf{1}_n$  ( $\mathbf{0}_n$ ) be the all-one (all-zero) n-dimensional column vector, and  $[n] = \{1, \ldots, n\}$ . We use  $\otimes$  to denote the Kronecker product and let  $\mathbf{W} = \frac{1}{n}\mathbf{1}_n\mathbf{1}_n^T \otimes \mathbf{I}_d$ . For a set  $\mathcal{B}$ , we use  $|\mathcal{B}|$  to denote the cardinality. For a convex function g, we use  $\partial g$  to denote the subdifferential. For a random variable  $\mathbf{v}$ , we use  $\mathbb{E}[\mathbf{v}]$  to denote the expectation and  $\mathbb{E}[\mathbf{v}|\mathcal{F}]$  to denote the expectation given event  $\mathcal{F}$ . For vectors  $\mathbf{x}_1, \ldots, \mathbf{x}_n \in \mathbb{R}^d$ , we let  $\mathbf{X} = \operatorname{col}\{\mathbf{x}_i\}_{i=1}^n = [\mathbf{x}_1; \ldots; \mathbf{x}_n] \in \mathbb{R}^{nd}$ . Specifically, for a vector  $\overline{\mathbf{x}} \in \mathbb{R}^d$ , we let  $\overline{\mathbf{X}} = \operatorname{col}\{\overline{\mathbf{x}}\}_{i=1}^n = [\overline{\mathbf{x}}; \ldots; \overline{\mathbf{x}}] \in \mathbb{R}^{nd}$ . For gradients  $\nabla f_1(\mathbf{x}_1), \ldots, \nabla f_n(\mathbf{x}_n) \in \mathbb{R}^d$ , we let  $\nabla f(\mathbf{X}) = \operatorname{col}\{\nabla f_i(\mathbf{x}_i)\}_{i=1}^n$  and  $\overline{\nabla} f(\mathbf{X}) = \operatorname{col}\{\frac{1}{n}\sum_{i=1}^n \nabla f_i(\mathbf{x}_i)\}_{i=1}^n$ . For a vector  $\mathbf{w}$  and a positive scalar  $\tilde{\eta}$ , we let  $P_{\tilde{\eta}}(\mathbf{w}) = \operatorname{argmin}_{\mathbf{u} \in \mathbb{R}^d} \tilde{\eta} g(\mathbf{u}) + \frac{1}{2} \|\mathbf{w} - \mathbf{u}\|^2$ . Specifically, for  $\operatorname{col}\{\mathbf{w}_i\}_{i=1}^n$ , we let  $P_{\tilde{\eta}}(\operatorname{col}\{\mathbf{w}_i\}_{i=1}^n) = \operatorname{col}\{P_{\tilde{\eta}}(\mathbf{w}_i)\}_{i=1}^n$ .

#### 2 Proposed algorithm

In this section, we describe the implementation of our algorithm from the perspective of a single client. We then highlight the ideas behind the algorithm design through an equivalent compact form of our algorithm.

#### 2.1 Per-client implementation of proposed algorithm

In general, our algorithm comprises communication rounds indexed by r and local updates indexed by t. During each round r, clients execute  $\tau$  local update steps before updating the server. Each client i maintains two models during the local updates, representing the local model state before and after the application of the proximal mapping. We call these models pre-proximal, denoted  $\hat{\mathbf{z}}_{i,t}^r$ , and post-proximal, denoted  $\mathbf{z}_{i,t}^r$ . Local mini-batch stochastic gradients of size b are computed at the post-proximal local model  $\mathbf{z}_{i\,t}^r$ . A client-drift correction term  $\mathbf{c}_{i}^{r}$  is then added to the gradients, as shown on Line 9 in Algorithm 1, to correct the update direction for the pre-proximal local model  $\widehat{\mathbf{z}}_{i,t}^r$ . Although during the current local updates, client i does not have access to the current gradient information of other clients, we can obtain the old gradient information from other clients in the previous communication round and use it to correct the current local gradient direction. Our correction term  $\mathbf{c}_i^r$  is based on this idea. It can be locally constructed using the global model broadcasted by the server, as the global model contains the average gradient information due to the previous communication. At the end of the round, the final pre-proximal model,  $\hat{\mathbf{z}}_{i,\tau}^r$ is transmitted to the server.

At the r-th communication round, the server also manipulates two models: a pre-proximal global model  $\overline{\mathbf{x}}^r$  and a post-proximal global model  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ . The server averages the pre-proximal local models  $\widehat{\mathbf{z}}_{i,\tau}^r$  and utilizes the average information to update the post-proximal global model  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ , ensuring that the server-side algorithm behaves similarly to a centralized proximal SGD method. Finally, the server broadcasts the pre-proximal global model  $\overline{\mathbf{x}}^{r+1}$  to all clients that use it to update their correction terms  $\mathbf{c}_i^{r+1}$ .

The per-client implementation of the algorithm is outlined in Algorithm 1. Fig. 1 illustrates how the pre-proximal local models  $\widehat{\mathbf{z}}_{i,\tau}^r$  are sent by each client i to the server and the pre-proximal global model  $\overline{\mathbf{x}}^{r+1}$  is broadcasted by the server to all clients.

![](_page_2_Figure_10.jpeg)

Fig. 1. Block diagram of Algorithm 1.

## 2.2 The intuition behind the algorithm design

As shown in Appendix A.1, the iterates generated by

## Algorithm 1 Proposed algorithm

```
1: Input: R, \tau, \eta, \eta_a, \overline{\mathbf{x}}^1, and \mathbf{c}_i^1 = \mathbf{0}_d for all i \in [n]
    2: Set \tilde{\eta} = \eta \eta_a \tau
    3: for r = 1, 2, ..., R do
                        Client i
    4:
                        Set \widehat{\mathbf{z}}_{i,0}^r = P_{\widetilde{\eta}}(\overline{\mathbf{x}}^r) and \mathbf{z}_{i,0}^r = P_{\widetilde{\eta}}(\overline{\mathbf{x}}^r) for t = 0, 1, \dots, \tau - 1 do
    5:
    6:
                                 Sample a subset data \mathcal{B}_{i,t}^r \subseteq \mathcal{D}_i with |\mathcal{B}_{i,t}^r| = b
Update \nabla f_i(\mathbf{z}_{i,t}^r; \mathcal{B}_{i,t}^r) = \frac{1}{b} \sum_{\mathcal{D}_{il} \in \mathcal{B}_{i,t}^r} \nabla f_{il}(\mathbf{z}_{i,t}^r; \mathcal{D}_{il})
    7:
    8:
                                  Update \hat{\mathbf{z}}_{i,t+1}^r = \hat{\mathbf{z}}_{i,t}^r - \eta \left( \nabla f_i(\hat{\mathbf{z}}_{i,t}^r; \mathcal{B}_{i,t}^r) + \mathbf{c}_i^r \right)
    9:
                                  Update \mathbf{z}_{i,t+1}^r = P_{(t+1)\eta}(\widehat{\mathbf{z}}_{i,t+1}^r)
 10:
                        end for
 11:
                       Send \widehat{\mathbf{z}}_{i,\tau}^r to the server Server
12:
13:
                        Update \overline{\mathbf{x}}^{r+1} = P_{\tilde{n}}(\overline{\mathbf{x}}^r) + \eta_q \left( \frac{1}{n} \sum_{i=1}^n \widehat{\mathbf{z}}_{i,\tau}^r - P_{\tilde{n}}(\overline{\mathbf{x}}^r) \right)
14:
                        Broadcast \overline{\mathbf{x}}^{r+1} to all the clients
 15:
 16:
                        Receive \overline{\mathbf{x}}^{r+1} from the server
Update \mathbf{c}_i^{r+1} = \frac{1}{\eta_a \eta \tau} (P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \overline{\mathbf{x}}^{r+1}) –
 17:
 18:
\frac{\frac{1}{\tau} \sum_{t=0}^{\tau-1} \nabla f_i(\mathbf{z}_{i,t}^r; \mathcal{B}_{i,t}^r)}{19: \ \mathbf{end for}}
20: Output: P_{\tilde{\eta}}(\overline{\mathbf{x}}^{R+1})
```

Algorithm 1 can be described in compact form

$$\begin{cases} \widehat{\mathbf{Z}}_{t+1}^{r} = \widehat{\mathbf{Z}}_{t}^{r} - \eta \left( \nabla \mathbf{f} \left( \mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r} \right) + \frac{1}{\tau} \sum_{t=0}^{\tau-1} \overline{\nabla \mathbf{f}} \left( \mathbf{Z}_{t}^{r-1}; \mathcal{B}_{t}^{r-1} \right) \right) \\ - \frac{1}{\tau} \sum_{t=0}^{\tau-1} \nabla \mathbf{f} \left( \mathbf{Z}_{t}^{r-1}; \mathcal{B}_{t}^{r-1} \right) \right), \quad \forall t \in [\tau] - 1, \\ \mathbf{Z}_{t+1}^{r} = P_{(t+1)\eta} \left( \widehat{\mathbf{Z}}_{t+1}^{r} \right), \quad \forall t \in [\tau] - 1, \\ \overline{\mathbf{X}}^{r+1} = P_{\tilde{\eta}} (\overline{\mathbf{X}}^{r}) - \eta_{g} \eta \sum_{t=0}^{\tau-1} \overline{\nabla \mathbf{f}} \left( \mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r} \right), \end{cases}$$

where  $\mathbf{Z}_{t}^{r} = \operatorname{col}\{\mathbf{z}_{i,t}^{r}\}_{i=1}^{n}, \ \widehat{\mathbf{Z}}_{t}^{r} = \operatorname{col}\{\widehat{\mathbf{z}}_{i,t}^{r}\}_{i=1}^{n}, \ \overline{\mathbf{X}}^{r} = \operatorname{col}\{\overline{\mathbf{x}}\}_{i=1}^{n}, \ \nabla\mathbf{f}(\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r}) = \operatorname{col}\{\nabla f_{i}(\mathbf{z}_{i,t}^{r}; \mathcal{B}_{i,t}^{r})\}_{i=1}^{n}, \ \operatorname{and} \overline{\nabla\mathbf{f}}(\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r}) = \operatorname{col}\{\frac{1}{n}\sum_{i=1}^{n}\nabla f_{i}(\mathbf{z}_{i,t}^{r}; \mathcal{B}_{i,t}^{r})\}_{i=1}^{n}. \ \operatorname{At} \ r = 1, \ \operatorname{we set} \nabla f_{i}\left(\mathbf{z}_{i,t}^{0}; \mathcal{B}_{i,t}^{0}\right) = \mathbf{0}_{d} \ \operatorname{for all} \ t \in [\tau] - 1 \ \operatorname{so that} \ \frac{1}{\tau}\sum_{t=0}^{\tau-1}\overline{\nabla\mathbf{f}}\left(\mathbf{Z}_{t}^{0}; \mathcal{B}_{t}^{0}\right) - \frac{1}{\tau}\sum_{t=0}^{\tau-1}\nabla\mathbf{f}\left(\mathbf{Z}_{t}^{0}; \mathcal{B}_{t}^{0}\right) = \mathbf{0}_{nd}.$ 

After the last step in (2), the server update satisfies

$$P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) = P_{\tilde{\eta}}\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) - \tilde{\eta}\underbrace{\frac{1}{n\tau}\sum_{t=0}^{\tau-1}\sum_{i=1}^{n}\nabla f_{i}\left(\mathbf{z}_{i,t}^{r};\mathcal{B}_{i,t}^{r}\right)\right)}_{:=\boldsymbol{v}^{r}}.$$

For the sake of clarity, we define a virtual iterate  $\tilde{\mathbf{x}}^{r+1}$  that follows the centralized proximal gradient descent (PGD) update

$$\tilde{\mathbf{x}}^{r+1} := P_{\tilde{\eta}} \left( P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \tilde{\eta} \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \right). \tag{4}$$

The server update (3) is similar to the centralized PGD iterate (4), except that the direction  $\boldsymbol{v}^r$  in our algorithm uses stochastic gradients and is the average across local updates and clients. The server broadcasts the preproximal global model  $\overline{\mathbf{x}}^r$  since the clients need it to construct the correction term (Line 18 in Algorithm 1).

With the algorithm re-written in this compact form, we are now ready to explain its key features.

1) Decoupling prox evaluation and communication. To achieve decoupling, each client i manipulates a pre-proximal local model  $\widehat{\mathbf{z}}_{i,t}^r$  during the  $\tau$  local updates and then transmits  $\widehat{\mathbf{z}}_{i,\tau}^r$  to the server. In the update of  $\widehat{\mathbf{z}}_{i,t}^r$  (the first step of (2)), each client i evaluates the minibatch SGD at the post-proximal local model  $\mathbf{z}_{i,t}^r$  and adds the correction term. Since the average of the correction terms across clients is always zero, the server can obtain the average gradient  $\sum_{t=0}^{\tau-1} \frac{1}{n} \sum_{i=1}^{n} \nabla f_i(\mathbf{z}_{i,t}^r; \mathcal{B}_{i,t}^r)$  at the post-proximal models  $\{\mathbf{z}_{i,t}^r\}_i$  by simply averaging  $\widehat{\mathbf{z}}_{i,\tau}^r$ . In this way, our algorithm is able to convey the average gradient to the server without any distortion.

In contrast, if each client i would naively use proximal SGD with client-drift correction during the local updates, i.e.,

$$\begin{split} \mathbf{z}_{i,t+1}^r &= P_{(t+1)\eta} \Big( \mathbf{z}_{i,t}^r - \eta(\nabla f_i(\mathbf{z}_{i,t}^r; \mathcal{B}_{i,t}^r) \\ &+ \frac{1}{\eta_g \eta \tau} (P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r-1}) - \overline{\mathbf{x}}^r) - \frac{1}{\tau} \sum_{t=0}^{\tau-1} \nabla f_i(\mathbf{z}_{i,t}^{r-1}; \mathcal{B}_{i,t}^{r-1})) \Big) \end{split}$$

and transmit  $\mathbf{z}_{i,\tau}^r$  to the server after  $\tau$  local updates, then the server could no longer extract the average gradient due to the nonlinearity of the proximal operator.

It should be noted that the mismatch in the first step of (2), i.e., updating  $\hat{\mathbf{z}}_{i,t}^r$  with the gradients evaluated at  $\mathbf{z}_{i,t}^r$ , introduces challenges in the analysis. Nevertheless, by the use of novel analytical techniques, we manage to address this issue in Lemma A.1.

- 2) Correcting for client drift. The re-formulation (2) exposes how the correction terms affect the iterates. Effectively, each client i introduces gradient information from other clients via  $\frac{1}{n\tau}\sum_{t=0}^{\tau-1}\sum_{i=1}^{n}\nabla f_{i}(\mathbf{z}_{i,t}^{r-1};\mathcal{B}_{i,t}^{r-1})$  and then replaces its own previous local contribution  $\frac{1}{\tau}\sum_{t=0}^{\tau-1}\nabla f_{i}\left(\mathbf{z}_{i,t}^{r-1};\mathcal{B}_{i,t}^{r-1}\right)$  with the new  $\nabla f_{i}(\mathbf{z}_{i,t}^{r};\mathcal{B}_{i,t}^{r})$ . Intuitively, each local update uses global gradient information to obtain the post-proximal local model  $\mathbf{z}_{i,t+1}^{r}$ , which is a single iterate aimed at minimizing the global loss function  $\frac{1}{n}\sum_{i=1}^{n}f_{i}+g$ , rather than  $f_{i}+g$ . This allows our algorithm to eliminate the client drift.
- **3)** Reduced signalling. Unlike Scaffold [13] and Mime [12], who overcome client drift for smooth problems at

the cost of additional communication for control variates, our algorithm only exchanges one d-dimensional vector per communication round and client. This is made possible by a clever algorithm design that allows each client to reconstruct its own correction term from the broadcasted  $\overline{\mathbf{x}}^T$  without additional communication.

4) Novel parameter selection during local updates. In (2), the updates of the post-proximal local models  $\mathbf{Z}_{t+1}^r$  use the parameter  $(t+1)\eta$  for computing the proximal operator  $P_{(t+1)\eta}(\widehat{\mathbf{Z}}_{t+1}^r)$ . The main idea of using  $(t+1)\eta$  is to make  $\mathbf{z}_{i,t}^r$  evolve similarly as a centralized proximal gradient descent (PGD) method applied to the global model  $P_{\bar{n}}(\overline{\mathbf{x}}^r)$ :

$$P_{\hat{\eta}}\Big(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \hat{\eta}\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\Big). \tag{5}$$

Note that the same step size  $\hat{\eta} > 0$  is used both in the proximal operator and in front of the gradient. Since we perform (t+1) steps of local updates with step size  $\eta$  on  $\hat{\mathbf{z}}_{i,0}^r$  to obtain  $\hat{\mathbf{z}}_{i,t+1}^r$ , the parameter  $\hat{\eta}$  for proximal operator should be set to  $(t+1)\eta$  to match (5).

Specifically, by repeated use of Line 9 in Algorithm 1,

$$\widehat{\mathbf{z}}_{i,t+1}^{r} = \widehat{\mathbf{z}}_{i,0}^{r} - \eta \left( \sum_{\ell=0}^{t} \left( \nabla f_{i} \left( \mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r} \right) + \mathbf{c}_{i}^{r} \right) \right)$$

$$= \widehat{\mathbf{z}}_{i,0}^{r} - (t+1) \eta \left( \frac{1}{t+1} \sum_{\ell=0}^{t} \left( \underbrace{\nabla f_{i} \left( \mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r} \right) + \mathbf{c}_{i}^{r}}_{\approx \nabla f(\mathbf{z}_{i,\ell}^{r})} \right) \right),$$
(6)

where we divide and multiply (t+1) in the second equality of (6). If we disregard that we use stochastic gradients and evaluate the gradient at different iterates  $\mathbf{z}_{i,0}^r, \dots, \mathbf{z}_{i,t}^r, \nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r)$  in the second equality in (6) can be replaced by  $\nabla f_i(\mathbf{z}_{i,0}^r)$  leading to

$$\hat{\mathbf{z}}_{i,t+1}^r = \hat{\mathbf{z}}_{i,0}^r - (t+1)\eta \left(\nabla f_i(\mathbf{z}_{i,0}^r) + \mathbf{c}_i^r\right) \\
\approx P_{\bar{n}}(\overline{\mathbf{x}}^r) - (t+1)\eta \nabla f(P_{\bar{n}}(\overline{\mathbf{x}}^r)), \tag{7}$$

where we substitute  $\hat{\mathbf{z}}_{i,0}^r = P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ . By the definition  $\mathbf{z}_{i,t+1}^r = P_{(t+1)\eta}(\hat{\mathbf{z}}_{i,t+1}^r)$ , we have

$$\mathbf{z}_{i,t+1}^{r} \approx P_{(t+1)\eta} \Big( P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) - (t+1)\eta \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \Big). \quad (8)$$

Comparing with (5), we see that using  $(t+1)\eta$  allows (8) to be close to the centralized PGD.

This parameter  $(t+1)\eta$  significantly improves the practical performance of Algorithm 1, as we will demonstrate in numerical experiments.

#### 3 Analysis

In this section, we establish convergence guarantees for Algorithm 1. To facilitate the analysis, we impose the following assumptions on the loss function.

**Assumption 3.1** The function  $g: \mathbb{R}^d \to \mathbb{R}$  is proper closed convex, but not necessarily smooth. There exists a constant  $0 < B_g < \infty$ , independent of  $\mathbf{x}$ , such that for any  $\mathbf{x} \in \mathbb{R}^d$  and any  $\widetilde{\nabla} g(\mathbf{x}) \in \partial g(\mathbf{x})$ , it holds that  $\|\widetilde{\nabla} g(\mathbf{x})\| \leq B_g$ .

This subgradient boundedness assumption is common in analyses of non-smooth problems, and is satisfied by regularizers such as the  $\ell_1$ -norm, the  $\ell_{\infty}$ -norm, and the ReLU (Rectified Linear Unit), among others [14].

**Assumption 3.2** Each loss function  $f_i : \mathbb{R}^d \to \mathbb{R}$  is L-smooth, i.e., there exists a constant  $0 < L < \infty$  such that

$$f_i(\mathbf{y}) \leq f_i(\mathbf{x}) + \langle \nabla f_i(\mathbf{x}), \mathbf{y} - \mathbf{x} \rangle + \frac{L}{2} \|\mathbf{x} - \mathbf{y}\|^2, \ \forall \mathbf{x}, \mathbf{y} \in \mathbb{R}^d.$$

**Assumption 3.3** The loss function f or F defined in (1) satisfies one of the following conditions

- (1) f is general non-convex.
- (2) F satisfies proximal PL inequality:  $\mu(F(\mathbf{x}) F^*) \leq \frac{1}{2}D_g(\mathbf{x}, \mu)$ , where  $\mu > 0$ ,  $D_g(\mathbf{x}, \mu) := -2\mu \min_{\mathbf{y}} \langle \nabla F(\mathbf{x}), \mathbf{y} \mathbf{x} \rangle + \frac{\mu}{2} ||\mathbf{y} \mathbf{x}||^2 + g(\mathbf{y}) g(\mathbf{x})$ , and  $F^*$  is the optimal value of problem (1) [10, 11].

We will establish separate convergence guarantees for these two cases. The proximal PL inequality extends the PL inequality [4,20] to non-smooth problems and offers a concise proof of linear convergence rates for convex and non-convex composite problems [11]. It applies to various cases such as  $\ell_1$ -regularized least squares problem [11].

To handle the stochasticity caused by random sampling  $\mathcal{B}^r_{i,t}$ , we let  $\mathcal{F}^r_t$  denote the event generated by  $\{\mathcal{B}^{\tilde{r}}_{i,\tilde{t}} \mid i \in [n]; \tilde{r} \in [r]; \tilde{t} \in [t] - 1\}$  and make the following assumptions regarding the stochastic gradients.

**Assumption 3.4** The stochastic gradients of each client i satisfy

$$\mathbb{E}\left[\nabla f_{i}(\mathbf{z}_{i,t}^{r}; \mathcal{B}_{i,t}^{r})|\mathcal{F}_{t}^{r}\right] = \nabla f_{i}(\mathbf{z}_{i,t}^{r}),$$

$$\mathbb{E}\left[\left\|\nabla f_{i}(\mathbf{z}_{i,t}^{r}; \mathcal{B}_{i,t}^{r}) - \nabla f_{i}(\mathbf{z}_{i,t}^{r})\right\|^{2}|\mathcal{F}_{t}^{r}\right] \leq \frac{\sigma^{2}}{b}.$$
(9)

Assumption 3.4 shows that the local stochastic gradients are unbiased estimates of the local full gradients and that the variance is inversely proportional to the batch size b.

With these assumptions in place, we can analyze the general non-convex case using the auxiliary function

$$\Omega^r := F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) - F^* + \frac{1}{n\tilde{\eta}} \|\mathbf{\Lambda}^r - \overline{\mathbf{\Lambda}}^r\|^2, \tag{10}$$

where  $\mathbf{\Lambda}^r := \eta(\tau \nabla \mathbf{f}(P_{\bar{\eta}}(\overline{\mathbf{X}}^r)) + \sum_{t=0}^{\tau-1} \overline{\nabla \mathbf{f}}(\mathbf{Z}_t^{r-1}; \mathcal{B}_t^{r-1}) - \sum_{t=0}^{\tau-1} \nabla \mathbf{f}(\mathbf{Z}_t^{r-1}; \mathcal{B}_t^{r-1}))$ ,  $\overline{\mathbf{\Lambda}}^r := \operatorname{col}\left\{\frac{1}{n}\sum_{i=1}^n \Lambda_i^r\right\}_{i=1}^n$  with  $\Lambda_i^r$  as the i-th block of  $\mathbf{\Lambda}^r$  such that  $\mathbf{\Lambda}^r = \operatorname{col}\left\{\Lambda_i^r\right\}_{i=1}^n$ , and  $F^\star$  is the optimal value of problem (1). The first component of  $\Omega^r$  measures the suboptimality of the global model  $P_{\bar{\eta}}(\overline{\mathbf{x}}^r)$ , while the second component bounds the client-drift error, i.e., how far the local models  $\{\mathbf{z}_{i,\tau}^r\}_i$  are from the common initial point  $P_{\bar{\eta}}(\overline{\mathbf{x}}^r)$  after the local updates. This drift error can be bounded by the inconsistency of the local directions accumulated through the local updates, as characterized by  $\|\mathbf{\Lambda}^r - \overline{\mathbf{\Lambda}}^r\|^2$ .

The convergence proof is based on a descent lemma for the auxiliary function defined in (10). Analogous to using the gradient norm as a descent magnitude in smooth non-convex problems, our analysis measures the descent by the norm of  $\mathcal{G}(P_{\bar{n}}(\overline{\mathbf{x}}^r))$  defined via

$$\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) := \frac{1}{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \tilde{\mathbf{x}}^{r+1}) \tag{11}$$

$$\in \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) + \partial g(\tilde{\mathbf{x}}^{r+1}), \qquad (12)$$

where  $\tilde{\mathbf{x}}^{r+1}$ , defined in (4), is virtual and merely used for analysis. The derivation of (12) is given in Appendix A.3. When g = 0,  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  reduces to  $\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$ .

In the centralized setting,  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  is a commonly used metric to evaluate the first-order optimality for nonconvex composite problems [10]. The intuition of using the norm of  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  as a metric is that  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  can be approximately viewed as an element of the subgradient of f+g, except that  $\nabla f$  and  $\partial g$  are evaluated at two different points. Moreover,  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) = \mathbf{0}_d$  if and only if  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) = \tilde{\mathbf{x}}^{r+1}$  and  $\mathbf{0}_d \in \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) + \partial g(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$ , which means that the global model  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$  satisfies the first-order optimality conditions for (1). With  $\Omega^r$  and  $\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  defined, we can present the following theorem.

Theorem 3.5 (General non-convex case) Under Assumptions 3.1, 3.2, 3.3-(1), 3.4, if the step sizes satisfy

$$\tilde{\eta} := \eta \eta_g \tau \le \frac{1}{10L}, \ \eta_g \ge \max \left\{ 1.5, \sqrt{\frac{n}{8}} \right\}, \tag{13}$$

then the sequence of  $\{\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\}_r$  generated by the iterates of Algorithm 1 satisfies

$$\frac{1}{R} \sum_{r=1}^R \mathbb{E} \|\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\|^2 \leq \frac{\mathbb{E}\left[\Omega^1\right]}{0.3\tilde{\eta}R} + \frac{20\sigma^2}{n\tau b} + \frac{187L^2\tilde{\eta}^2 B_g^2}{\eta_g^2}.$$

Theorem 3.5 demonstrates that Algorithm 1 converges sublinearly to a residual error of order  $\mathcal{O}(\sigma^2/(n\tau b) + L^2\tilde{\eta}^2 B_g^2/\eta_g^2)$ . The first term in the residual is dictated by the stochastic gradient variance  $\sigma^2$  and can be mitigated by employing a large batch size b. If full local gradients are used, then  $\sigma^2 = 0$ , rendering this residual term zero. The second term in the residual stems from the bound of the subgradient  $\partial g$ . As this term is proportional to the square of the step size  $\tilde{\eta}$ , a smaller step size can effectively reduce this residual.

When F satisfies the proximal PL inequality, we can achieve the following stronger convergence guarantee:

Theorem 3.6 (proximal PL inequality case) Under Assumptions 3.1, 3.2, 3.3-(2), and 3.4, if the step sizes satisfy (13), the sequence  $\{\Omega^r\}_r$  generated by the iterates of Algorithm 1 satisfies

$$\mathbb{E}[\Omega^{R+1}] \leq \left(1 - \frac{\mu\tilde{\eta}}{3}\right)^R \mathbb{E}[\Omega^1] + \frac{18\sigma^2}{\mu n \tau b} + \frac{168L^2\tilde{\eta}^2 B_g^2}{\mu \eta_g^2}.$$

Compared to the sublinear rate of Theorem 3.5, Theorem 3.6 establishes linear convergence to a residual error of order  $\mathcal{O}(\sigma^2/(\mu n \tau b) + L^2 \tilde{\eta}^2 B_g^2/(\mu \eta_g^2))$ . The convergence guarantee in Theorem 3.6 is the stronger of the two, because it proves convergence to a neighborhood of the optimal loss value whereas Theorem 3.5 only ensures convergence to a neighborhood of a first-order stationary point. Just like in Theorem 3.5, the first term of the residual error in Theorem 3.6 is associated with the stochastic gradient variance  $\sigma^2$  and can be reduced by increasing the batch size b. The second term of the residual error is related to the bound of the subgradient  $\partial g$  and can be decreased by using a smaller step size  $\tilde{\eta}$ .

Neither Theorems 3.5 or 3.6 imply the convergence of the global model  $P_{\bar{\eta}}(\overline{\mathbf{x}}^r)$  to the optimal solution set  $\mathcal{X}^* := \operatorname{argmin}_{\mathbf{x}} F(\mathbf{x})$ . This is a common issue for non-convex composite optimization with first-order methods [7, 10]. Even if  $\|\mathcal{G}(P_{\bar{\eta}}(\overline{\mathbf{x}}^r))\|^2$  or  $F(P_{\bar{\eta}}(\overline{\mathbf{x}}^r)) - F^*$  is small, the distance of  $P_{\bar{\eta}}(\overline{\mathbf{x}}^r)$  to  $\mathcal{X}^*$  can still be large. To ensure that the distance of  $P_{\bar{\eta}}(\overline{\mathbf{x}}^r)$  to  $\mathcal{X}^*$  is upper bounded by  $\|\mathcal{G}(P_{\bar{\eta}}(\overline{\mathbf{x}}^r))\|^2$  or  $F(P_{\bar{\eta}}(\overline{\mathbf{x}}^r)) - F^*$ , the objective functions typically need to be strongly convex, or satisfy other local error bound conditions [18, 31].

Remark 3.7 In our conference publication [33], we investigated Algorithm 1 for solving problem (1) when  $f(\mathbf{x})$  is  $\mu_{sc}$ -strongly convex where  $\mu_{sc} > 0$  is a parameter. By using an auxiliary function on the form

$$\Omega^r_{sc} := \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \mathbf{x}^\star \right\|^2 + \frac{1}{n} \|\mathbf{\Lambda}^r - \overline{\mathbf{\Lambda}}^r\|^2,$$

where  $\mathbf{x}^*$  is the optimal solution, we proved linear convergence for the point sequence  $\{\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \mathbf{x}^*\|^2\}_r$ . For completeness, we include the main theorem below.

Theorem 3.8 (Strongly convex case [33, Thm. 3.4]) Under Assumptions 3.1, 3.2, 3.4, if  $f(\mathbf{x})$  is  $\mu_{sc}$ -strongly convex and the step sizes satisfy

$$\tilde{\eta} := \eta \eta_g \tau \le \frac{\mu_{sc}}{150L^2}, \ \eta_g = \sqrt{n},$$

then the sequence  $\{\Omega_{sc}^r\}_r$  satisfies

$$\mathbb{E}\left[\Omega_{sc}^{R+1}\right] \leq \left(1 - \frac{\mu_{sc}\tilde{\eta}}{3}\right)^{R}\mathbb{E}[\Omega_{sc}^{1}] + \frac{30\tilde{\eta}\sigma^{2}}{\mu_{sc}n\tau b} + \frac{21\tilde{\eta}B_{g}^{2}}{\mu_{sc}\eta_{q}^{2}}.$$

Although we have also proven linear convergence under the proximal PL inequality without invoking convexity, the convergence of the point sequence  $\{\|P_{\bar{\eta}}(\overline{\mathbf{x}}^r) - \mathbf{x}^\star\|^2\}_r$  is stronger than the convergence of the loss value sequence  $\{F(P_{\bar{\eta}}(\overline{\mathbf{x}}^r)) - F^\star\}_r$ . This stronger convergence in the strongly convex case allows us to get rid of the  $B_g$ -term in the special case that g is an indicator function of a convex set and  $\nabla f(\mathbf{x}^\star) = 0$  [33, Corollary 3.6]. In the non-convex cases considered in this paper, proving convergence of  $\|P_{\bar{\eta}}(\overline{\mathbf{x}}^r) - \mathbf{x}^\star\|$  is challenging and we have not been able to eliminate the  $B_g$ -term. However, in our numerical experiments, we observe that when we eliminate  $\sigma^2$  by use of full gradients, our algorithm converges exactly and is unaffected by  $B_g$  (Fig. 2). This suggests that there is room for improvement in our theoretical analysis.

Next, we proceed to validate the theoretical results in numerical experiments.

#### 4 Numerical experiments

In the numerical experiments, we consider two problems: training of sparse logistic regression on synthetic heterogeneous datasets which satisfies proximal PL inequality [11, Section 4.1] and training of a convolutional neural network classifier on the real heterogeneous dataset MNIST [22] which is general non-convex. We compare our algorithm with the state-of-the-art algorithms Fed-Mid [29], FedDA [29], and Fast-FedDA [2], which all use a fixed number of local updates to solve the composite FL problem.

## 4.1 Sparse logistic regression

Consider the sparse logistic regression problem

$$\underset{\mathbf{x} \in \mathbb{R}^d}{\text{minimize}} \ \vartheta \|\mathbf{x}\|_1 + \frac{1}{n} \sum_{i=1}^n \frac{1}{m_i} \sum_{l=1}^{m_i} \ln \left(1 + \exp\left(-b_{il} \mathbf{a}_{il}^T \mathbf{x}\right)\right),$$

where client i owns  $m_i$  training samples  $(\mathbf{a}_{il}, b_{il}) \in \mathbb{R}^d \times \{-1, +1\}$  with  $l = 1, \dots, m_i$  and  $\vartheta > 0$  is a regularization parameter. We measure the performance by

optimality := 
$$\|\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\|/\|\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^1))\|$$
,

which represents the relative error between  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$  and the first-order stationary points of (1). To generate data, we use the method in [15] which allows us to control the degree of heterogeneity by two parameters  $(\alpha, \beta)$ .

In the first set of experiments, we show that our algorithm can overcome client drift. To eliminate the influence of random sampling noise, we use the full gradients. We set  $(\alpha, \beta) = (50, 50)$ , n = 30, d = 20,  $\vartheta = 0.003$ ,  $m_i = 100$ ,  $\forall i$ . For the proposed algorithm, we use hand-tuned step sizes  $\eta = 4$  and  $\eta_g = 15$ . For FedDA, we use the same step sizes  $\eta = 4$  and  $\eta_g = 15$ . For FedMid, we use  $\eta = 1$  and  $\eta_g = 5$ , based on the observation that smaller step sizes yield better performance. For Fast-FedDA, we use the adaptive step sizes as specified in [2], which are decaying step sizes. We set the number of local updates as  $\tau \in \{1, 10\}$ .

The results are shown in Fig. 2. When  $\tau = 1$ , there are no local updates and hence no client drift. Both FedDA and our algorithm converge to machine precision. The same step size setting ensures that both algorithms converge at exactly the same rate. Although our theoretical results suggest the existence of a residual determined by  $B_q$  (the subgradient bound), our experimental results do not show any such error, indicating that there is the possibility to improve the analysis. FedMid performs the worst because it faces the curse of primal averaging. Fast-FedDA converges slowly due to its decaying step sizes. When  $\tau = 10$ , data heterogeneity and local updates cause client drift. Our algorithm still achieves precise convergence and requires fewer communication rounds (roughly reduced by  $1/\tau$ ) than the others. FedDA, due to client drift, only converges to a neighborhood of the first-order stationary points and can no longer maintain a similar performance as our algorithm. FedDA and Fed-Mid perform even worse due to client drift.

In the second set of experiments, we use stochastic gradients and compare our algorithm with FedDA [29] and Fast-FedDA [2]. We set  $\vartheta=0.0005$ ,  $m_i=2000$ ,  $\forall i,\tau=20,\eta=2,\eta_g=8,b\in\{1,20\}$ . In the (t+1)-th local update of r-th communication round, client i randomly select a subset data  $\mathcal{B}_{i,t}^r$  with size b from 2000 data samples  $\{\mathcal{D}_{il}:=(\mathbf{a}_{il},b_{il})\}_l$ . The mini-batch stochastic gradient is then computed as  $\nabla f_i(\cdot;\mathcal{B}_{i,t}^r)=\frac{1}{b}\sum_{\mathcal{D}_{il}\in\mathcal{B}_{i,t}^r}\nabla f_{il}(\cdot;\mathcal{D}_{il})$ . The other settings are the same as those in Fig. 2. As shown in Fig. 3, when we use stochastic gradients, our algorithm also converges to a neighborhood. This neighborhood is induced by the variance of stochastic gradients. When we increase the batch size from 1 to 20, the convergence precision of our algorithm improves. The other algorithms perform worse due to client drift and/or the use of decaying step sizes.

![](_page_7_Figure_0.jpeg)

Fig. 2. Sparse logistic regression using full gradients with τ = 1 (left) and τ = 10 (right), respectively.

![](_page_7_Figure_2.jpeg)

Fig. 3. Sparse logistic regression using stochastic gradients with b = 1 (left) and b = 20 (right), respectively.

## 4.2 Federeated convolutional neural network training

In the third set of experiments, we tackle the nonconvex and non-smooth problem of training a convolutional neural network (CNN) for classifying the MNIST dataset [32].

The CNN architecture consists of two convolutional layers, each with 32 feature maps and a kernel size of 3x3, followed by a 2x2 max pooling layer. The network is then connected to three fully connected layers with 64, 32, and 10 units, respectively. We use Relu activation functions in the hidden layers and a softmax activation function in the output layer. The total number of parameters is d = 112, 394. The training loss function is cross-entropy with a regularization term defined as g(x) = ϑ∥x∥1.

The MNIST dataset consists of grayscale images of handwritten digits, each with dimensions of 28 × 28 pixels, encompassing 10 classes that represent the digits from 0 to 9. Our training dataset comprises 60,000 samples. To introduce data heterogeneity, we uniformly sample 30,000 samples from the complete training dataset, allocating 3,000 samples to each of the 10 clients. The remaining 3,0000 samples are distributed by assigning the samples of label l to client l + 1. Note that the total number of training samples for each client may differ. We have 10,000 test samples to evaluate the classification accuracy of the global model on the server.

We compare the proposed algorithm with FedDA which performs best among all compared algorithms in previous experiments. For both algorithms, we set ϑ = 10<sup>−</sup><sup>4</sup> , η = 0.005, η<sup>g</sup> = 1, b = 10, and τ ∈ {5, 10}.

![](_page_7_Figure_10.jpeg)

Fig. 4. Classification of MNIST using CNN with τ = 5 and τ = 10.

Fig. 4 shows the test accuracy with respect to communication rounds. When τ = 5 and τ = 10, our algorithm overcomes client-drift issues and achieves higher accuracy with fewer communication rounds than FedDA.

## 5 Conclusions

We have proposed a novel algorithm tailored for federated learning with non-convex composite loss functions and heterogeneous data. The proposed algorithm handles non-smooth regularization by decoupling the proximal operator evaluation and communication. In addition, it reduces the communication frequency through local updates, exchanges only a d-dimensional vector per communication round per client, and effectively addresses the issue of client drift. Without imposing limitations on data similarity, we establish sublinear and linear convergence rates for the cases when the problem is generally non-convex and satisfies the proximal PL inequality, respectively. Our numerical experiments show the superiority of the proposed algorithm over the state-of-the-art on both synthetic and real datasets.

# A Appendix

# A.1 Detailed derivation of Equation (2)

In this section, we will prove that the per-client implementation of Algorithm 1 can be represented in the compact form (2). To this end, we start by writing the updates of Algorithm 1 in compact form using the notation introduced in Section 2.2

$$\begin{cases} \widehat{\mathbf{Z}}_{t+1}^{r} = \widehat{\mathbf{Z}}_{t}^{r} - \eta \left( \nabla \mathbf{f} \left( \mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r} \right) + \mathbf{C}^{r} \right), \\ \mathbf{Z}_{t+1}^{r} = P_{(t+1)\eta} \left( \widehat{\mathbf{Z}}_{t+1}^{r} \right), \\ \overline{\mathbf{X}}^{r+1} = P_{\widetilde{\eta}}(\overline{\mathbf{X}}^{r}) + \eta_{g} \left( \mathbf{W} \widehat{\mathbf{Z}}_{\tau}^{r} - P_{\widetilde{\eta}}(\overline{\mathbf{X}}^{r}) \right), \\ \mathbf{C}^{r+1} = \frac{1}{\eta_{g}\eta\tau} (P_{\widetilde{\eta}}(\overline{\mathbf{X}}^{r}) - \overline{\mathbf{X}}^{r+1}) - \frac{1}{\tau} \sum_{t=0}^{\tau-1} \nabla \mathbf{f} \left( \mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r} \right), \end{cases}$$
where  $t \in [\tau] - 1, r \in [R]$ , and  $\mathbf{C}^{r} := \operatorname{col}\{\mathbf{c}_{i}^{r}\}_{i=1}^{n}$ .

We first establish the fact that  $\mathbf{WC}^{r+1} = \mathbf{0}_{nd}$  for all r. By the initialization  $\mathbf{C}^1 = \mathbf{0}_{nd}$ , this claim holds for r = 0. Moreover, the per-client updates (A.1) imply that

$$\mathbf{WC}^{r+1}$$

$$= \frac{1}{\eta_g \eta \tau} (P_{\tilde{\eta}}(\overline{\mathbf{X}}^r) - \overline{\mathbf{X}}^{r+1}) - \frac{1}{\tau} \sum_{t=1}^{\tau-1} \overline{\nabla} \mathbf{f}(\mathbf{Z}_t^r; \mathcal{B}_t^r) 
= -\frac{1}{\eta \tau} \left( \mathbf{W} \widehat{\mathbf{Z}}_{\tau}^r - P_{\tilde{\eta}}(\overline{\mathbf{X}}^r) \right) - \frac{1}{\tau} \sum_{t=1}^{\tau-1} \overline{\nabla} \mathbf{f}(\mathbf{Z}_t^r; \mathcal{B}_t^r), \tag{A.2}$$

where the first equality follows from the definition of the block-wise averaging matrix  $\mathbf{W}$  and that  $\overline{\mathbf{X}}^r = \operatorname{col}\{\overline{\mathbf{x}}^r\}_{i=1}^n$ , while the second equality uses the third step in (A.1).

By repeating the first step in (A.1), we obtain

$$\widehat{\mathbf{Z}}_{\tau}^{r} = \widehat{\mathbf{Z}}_{0}^{r} - \eta \left( \sum_{t=0}^{\tau-1} \nabla \mathbf{f} \left( \mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r} \right) + \tau \mathbf{C}^{r} \right). \tag{A.3}$$

Using (A.3) and  $\widehat{\mathbf{Z}}_0^r = P_{\widetilde{\eta}}(\overline{\mathbf{X}}^r)$  in (A.2) yields

$$\mathbf{WC}^{r+1} = \mathbf{WC}^r. \tag{A.4}$$

Since  $\mathbf{WC}^1 = \mathbf{0}_{nd}$ , it holds that  $\mathbf{WC}^r = \mathbf{0}_{nd}$  for all  $r \geq 1$ .

Next, to show equivalence between the updates (A.1) and (2), we first note that

$$\begin{split} \mathbf{C}^{r} &= \frac{1}{\eta_{g}\eta\tau}(P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r-1}) - \overline{\mathbf{X}}^{r}) - \frac{1}{\tau}\sum_{t=0}^{\tau-1}\nabla\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}) \\ &= -\frac{1}{\eta\tau}(\mathbf{W}\hat{\mathbf{Z}}_{\tau}^{r-1} - P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r-1})) - \frac{1}{\tau}\sum_{t=1}^{\tau-1}\nabla\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}) \\ &= \frac{1}{\tau}\sum_{t=1}^{\tau-1}\overline{\nabla}\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}) + \mathbf{W}\mathbf{C}^{r-1} - \frac{1}{\tau}\sum_{t=1}^{\tau-1}\nabla\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}) \\ &= \frac{1}{\tau}\sum_{t=0}^{\tau-1}\overline{\nabla}\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}) - \frac{1}{\tau}\sum_{t=0}^{\tau-1}\nabla\mathbf{f}(\mathbf{Z}_{t}^{r-1};\mathcal{B}_{t}^{r-1}). \end{split}$$

Here, we use (A.3) in the third equality and (A.4) in the last equality. Thus, the per-client implementation results in the first update of (2).

Next, we establish the  $\overline{\mathbf{X}}^{r+1}$ -update in (2). The perclient implementation (A.1) yields

$$\begin{split} \overline{\mathbf{X}}^{r+1} &= P_{\tilde{\eta}}(\overline{\mathbf{X}}^r) + \eta_g(\mathbf{W}\widehat{\mathbf{Z}}_{\tau}^r - P_{\tilde{\eta}}(\overline{\mathbf{X}}^r)) \\ &= P_{\tilde{\eta}}(\overline{\mathbf{X}}^r) - \eta\eta_g\mathbf{W}\left(\sum_{t=1}^{\tau-1} \nabla \mathbf{f}(\mathbf{Z}_t^r; \mathcal{B}_t^r) + \tau \mathbf{C}^r\right) \\ &= P_{\tilde{\eta}}(\overline{\mathbf{X}}^r) - \eta\eta_g\sum_{t=1}^{\tau-1} \overline{\nabla} \overline{\mathbf{f}}(\mathbf{Z}_t^r; \mathcal{B}_t^r), \end{split}$$

where the second equality uses (A.3) and the last uses (A.4). We have thus verified the last step in (2).

Since the  $\mathbf{Z}_{t+1}^r$ -update is the same in the two descriptions, we have shown that all updates are equivalent, and that (2) captures the evolution of the per-client implementation.

## A.2 Novel parameter selection during local updates

In Algorithm 1, Line 10 incorporates the parameter  $(t+1)\eta$  in the computation of  $P_{(t+1)\eta}(\widehat{\mathbf{z}}_{i,t+1}^r)$ . This parameter is carefully chosen based on testing our algorithm under a special case: minimize $_{\mathbf{x} \in \mathbb{R}^d} f_1(\mathbf{x}) + g(\mathbf{x})$ , where we set n=1, and use full gradient. Notably, in this case, the correction term is always equal to  $\mathbf{0}_d$  due to n=1. It is known that any first-order stationary point  $\mathbf{x}^*$  satisfies the condition  $\mathbf{x}^* = P_\beta(\mathbf{x}^* - \beta \nabla f_1(\mathbf{x}^*))$  for any positive  $\beta$ . A well-designed algorithm should be able to "stop" at  $\mathbf{x}^*$ . The application of  $(t+1)\eta$  achieves this property as elaborated in Algorithm 2. More precisely, when the local update begins from  $\mathbf{x}^*$ , the initial value of the pre-proximal global model  $\overline{\mathbf{x}}^1$  is  $\mathbf{x}^* - \tilde{\eta} \nabla f_1(\mathbf{x}^*)$ , and the output is always  $\mathbf{x}^*$ .

In the special case where n=1 and we use full gradients, we have shown that employing the parameter  $(t+1)\eta$ 

## Algorithm 2 Proposed algorithm under the special case

```
1: Input: R, \tau, \eta, \eta_g
    2: Set \tilde{\eta} = \tau \eta \eta_g
    3: Set \overline{\mathbf{x}}^1 = \mathbf{x}^* - \tilde{\eta} \nabla f_1(\mathbf{x}^*)
4: for r = 1, 2, \dots, R do
                        Client i
    5:
                        Set \widehat{\mathbf{z}}_{1,0}^r = P_{\widetilde{\eta}}(\overline{\mathbf{x}}^r) = \mathbf{x}^* and \mathbf{z}_{1,0}^r = P_{\widetilde{\eta}}(\overline{\mathbf{x}}^r) = \mathbf{x}^*
    6:
    7:
                        Update \widehat{\mathbf{z}}_{1,1}^r = \widehat{\mathbf{z}}_{1,0}^r - \eta \nabla f_1(\mathbf{z}_{1,0}^r) = x^* - \eta \nabla f_1(\mathbf{x}^*)
    8:
                        Update \mathbf{z}_{1,1}^r = P_{\eta}(\widehat{\mathbf{z}}_{1,1}^r) = \mathbf{x}^*
   9:
10:
                        Update \widehat{\mathbf{z}}_{1,2}^r = \widehat{\mathbf{z}}_{1,1}^r - \eta \nabla f_1(\mathbf{z}_{1,1}^r) = \mathbf{x}^* - 2\eta \nabla f_1(\mathbf{x}^*)
11:
                        Update \mathbf{z}_{1,2}^r = P_{2\eta}(\widehat{\mathbf{z}}_{1,2}^r) = \mathbf{x}^*
12:
13:
                        \mathbf{t} = \tau - 1
14:
                        Update \hat{\mathbf{z}}_{1,\tau}^r = \mathbf{x}^* - \tau \eta \nabla f_1(\mathbf{x}^*)
                        Update \mathbf{z}_{1,\tau}^r = P_{\tau\eta}(\hat{\mathbf{z}}_{1,\tau}^r) = \mathbf{x}^*
Send \hat{\mathbf{z}}_{1,\tau}^r = \mathbf{x}^* - \tau\eta\nabla f_1(\mathbf{x}^*) to the server
16:
17:
18:
            Update \overline{\mathbf{x}}^{r+1} = P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) + \eta_g(\widehat{\mathbf{z}}_{1,\tau}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) = \mathbf{x}^* + \eta_g(\mathbf{x}^* - \tau \eta \nabla f_1(\mathbf{x}^*) - \mathbf{x}^*) = \mathbf{x}^* - \tilde{\eta} \nabla f_1(\mathbf{x}^*)
Broadcast \overline{\mathbf{x}}^{r+1} = \mathbf{x}^* - \tilde{\eta} \nabla f_1(\mathbf{x}^*) to the workers
19:
20:
21:
                        Receive \overline{\mathbf{x}}^{r+1} = \mathbf{x}^* - \tilde{\eta} \nabla f_1(\mathbf{x}^*) from the server
22:
23: end for
24: Output: P_{\tilde{\eta}}(\overline{\mathbf{x}}^{R+1}) = \mathbf{x}^{\star}
```

allows Algorithm 2 to stop at  $\mathbf{x}^{\star}$ . However, this parameter choice is heuristic, as Algorithm 1 is designed for the more general scenario where  $n \geq 2$  and stochastic gradients are used. Our theorems indicate that Algorithm 1 is subject to residual errors due to stochastic gradients and non-smoothness, preventing it from converging exactly to  $\mathbf{x}^{\star}$  and stopping at  $\mathbf{x}^{\star}$ .

Despite the heuristic basis for the  $(t+1)\eta$  parameter, our empirical results demonstrate that this choice enhances the algorithm's performance beyond what our theoretical predictions suggest; cf. Fig. 2 (left). Moreover, our theoretical analysis is established under the use of  $(t+1)\eta$  and shows that the resulting residual error is small. Therefore, while the design of  $(t+1)\eta$  was initially heuristic, both our empirical and theoretical findings validate that this choice is effective and well-justified.

#### A.3 Derivation of (12)

According to (4), we have

$$\tilde{\mathbf{x}}^{r+1} = \operatorname{argmin}_{\mathbf{x}} \ \tilde{\eta} g(\mathbf{x}) + \frac{1}{2} \|\mathbf{x} - \boldsymbol{\omega}^r\|^2, \tag{A.5}$$

where we define  $\boldsymbol{\omega}^r := P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \tilde{\eta} \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  for simplicity. By the optimality condition of  $\tilde{\mathbf{x}}^{r+1}$ , we have

$$\frac{1}{\tilde{\eta}}(\boldsymbol{\omega}^r - \tilde{\mathbf{x}}^{r+1}) \in \partial g(\tilde{\mathbf{x}}^{r+1}). \tag{A.6}$$

Substituting  $\omega^r$  and reorganizing the result we get

$$\frac{1}{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \tilde{\mathbf{x}}^{r+1}) \in \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) + \partial g(\tilde{\mathbf{x}}^{r+1}), \quad (A.7)$$

which is exactly (12).

## A.4 Two preliminary lemmas

As a first step towards proving Theorems 3.5 and 3.6, we establish a bound on the drift error between the local models  $\{\mathbf{z}_{i,t}^r\}$  and their common initial point  $P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ .

**Lemma A.1** Under Assumptions 3.1, 3.2, and 3.4, if  $\tilde{\eta} \leq \eta_q/(\sqrt{20}L)$ , we have

$$\mathbb{E}\left[\sum_{t=0}^{\tau-1} \sum_{i=1}^{n} \left\|\mathbf{z}_{i,t}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2}\right] \\
\leq 5\tau^{3}\eta^{2}n \cdot 4B_{g}^{2} + 5n\tau^{3}\eta^{2}\|\mathcal{G}_{\tilde{\eta}g}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}))\|^{2} \\
+ 5\tau\mathbb{E}\|\mathbf{\Lambda}^{r} - \overline{\mathbf{\Lambda}}^{r}\|^{2} + 10n\tau^{2}\eta^{2}\frac{\sigma^{2}}{b}.$$
(A.8)

**PROOF.** If  $\tau = 1$ , then  $\mathbf{z}_{i,t}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) = \mathbf{0}_d$ . For  $\tau \geq 2$ , repeated application of Line 9 in Algorithm 1 yields

$$\widehat{\mathbf{z}}_{i,t+1}^r = \widehat{\mathbf{z}}_{i,0}^r - \eta \sum_{\ell=0}^t (\nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r).$$

Since  $\widehat{\mathbf{z}}_{i,0}^r = P_{\widetilde{\eta}}(\overline{\mathbf{x}}^r)$  and  $\mathbf{z}_{i,t+1}^r = P_{(t+1)\eta}(\widehat{\mathbf{z}}_{i,t+1}^r)$ , we have

$$\mathbb{E} \left\| \mathbf{z}_{i,t+1}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2}$$

$$= \mathbb{E} \left\| P_{(t+1)\eta} \left( P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) - \eta \sum_{\ell=0}^{t} \left( \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}) + \mathbf{c}_{i}^{r} \right) \right) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2}.$$
(A.9)

The right-hand side of (A.9) can be interpreted as an "inexact" PGD, executed from the starting point  $P_{\bar{\eta}}(\bar{\mathbf{x}}^r)$  using the inexact gradient  $-\eta \sum_{\ell=0}^t \left(\nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r\right)$ . This inspires us to bound (A.9) using the deviation from the exact PGD step with the same initial point

$$\tilde{\mathbf{x}}_{\mathrm{pgd}} := P_{(t+1)\eta} \left( P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - (t+1)\eta \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \right).$$

In this way,

$$\mathbb{E} \left\| \mathbf{z}_{i,t+1}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) \right\|^2 \tag{A.10}$$

$$= \mathbb{E} \| P_{(t+1)\eta} (P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \eta \sum_{\ell=0}^{t} (\nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r)) - \tilde{\mathbf{x}}_{pgd}$$

$$+ \tilde{\mathbf{x}}_{pgd} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) \|^2$$

$$\leq 2\mathbb{E} \| P_{(t+1)\eta} (P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \eta \sum_{\ell=0}^{t} (\nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r)) - \tilde{\mathbf{x}}_{pgd} \|^2$$

$$+ 2\mathbb{E} \| \tilde{\mathbf{x}}_{pgd} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) \|^2,$$
(II)

where the last step follows from  $||a+b||^2 \le 2||a||^2 + 2||b||^2$ .

To bound the term (II) we will use the optimality condition of  $\tilde{\mathbf{x}}_{pgd}$ . By definition of the proximal operator,

$$\begin{split} \tilde{\mathbf{x}}_{\mathrm{pgd}} &= \mathrm{argmin}_{\mathbf{u}} \ \frac{1}{2} \| P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - (t+1) \eta \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) - \mathbf{u} \|^2 \\ &+ (t+1) \eta g(\mathbf{u}), \end{split}$$

so  $\tilde{\mathbf{x}}_{pgd}$  satisfies the optimality condition

$$(t+1)\eta(\tilde{\nabla}g(\tilde{\mathbf{x}}_{\mathrm{pgd}}) + \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))) + \tilde{\mathbf{x}}_{\mathrm{pgd}} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) = \mathbf{0}_d,$$

for some  $\tilde{\nabla} g(\tilde{\mathbf{x}}_{pgd}) \in \partial g(\tilde{\mathbf{x}}_{pgd})$ . This implies that

$$\tilde{\mathbf{x}}_{\mathrm{pgd}} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) = -(t+1)\eta \underbrace{\left(\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) + \tilde{\nabla}g(\tilde{\mathbf{x}}_{\mathrm{pgd}})\right)}_{:=\mathcal{G}_{(t+1)\eta}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))}.$$

Note that the server step-size is  $\tilde{\eta}$  and not  $(t+1)\eta$ . To correct for this, we use the iterate  $\tilde{\mathbf{x}}^{r+1}$  defined in (4), which is the same as  $\tilde{\mathbf{x}}_{pgd}$  except that the step size  $(t+1)\eta$  is replaced by  $\tilde{\eta}$ . Following similar steps as above, the optimality condition for  $\tilde{\mathbf{x}}^{r+1}$  implies that

$$\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) = -\tilde{\eta} \underbrace{\left(\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) + \tilde{\nabla}g(\tilde{\mathbf{x}}^{r+1})\right)}_{:=\mathcal{G}_{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))}, (A.12)$$

for some  $\tilde{\nabla}g(\tilde{\mathbf{x}}^{r+1}) \in \partial g(\tilde{\mathbf{x}}^{r+1})$ . We can now use (A.11) and (A.12) to bound (II) through the following steps

$$(II) = 2\mathbb{E} \| (t+1)\eta \mathcal{G}_{(t+1)\eta}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \|^2$$

$$= 2\mathbb{E} \| (t+1)\eta \left( \mathcal{G}_{(t+1)\eta}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) - \mathcal{G}_{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \right)$$

$$+ (t+1)\eta \mathcal{G}_{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \|^2$$

$$= 2\mathbb{E} \| (t+1)\eta \left( \tilde{\nabla} g(\tilde{\mathbf{x}}_{pgd}) - \tilde{\nabla} g(\tilde{\mathbf{x}}^{r+1}) \right)$$

$$+ (t+1)\eta \mathcal{G}_{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \|^2$$

$$\leq 4\tau^2 \eta^2 \cdot 4B_q^2 + 4\tau^2 \eta^2 \| \mathcal{G}_{\tilde{\eta}}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \|^2 ,$$

where the last step uses Assumption 3.1 and  $t \leq \tau - 1$ .

Let us now turn our attention to bounding the term (I) on the right hand of (A.9). By the definition of  $\tilde{\mathbf{x}}_{pgd}$  and the nonexpansiveness of the proximal operator, we have

$$(I) = 2\mathbb{E} \left\| P_{(t+1)\eta} \left( P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - \eta \sum_{\ell=0}^t \left( \nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r \right) \right) - P_{(t+1)\eta} \left( P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) - (t+1)\eta \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \right) \right\|^2 \quad (A.14)$$

$$\leq 2\mathbb{E} \left\| \eta \sum_{\ell=0}^t \left( \nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r - \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) \right) \right\|^2.$$

The right-hand side of (A.14) measures the difference between the direction  $\nabla f_i(\mathbf{z}_{i,\ell}^r; \mathcal{B}_{i,\ell}^r) + \mathbf{c}_i^r$  used by our algorithm and the exact gradient  $\nabla f(P_{\bar{\eta}}(\overline{\mathbf{x}}^r))$ . To expose how this difference is affected by both the drift error and sampling, we will re-write it in terms of  $\|\Lambda_i^r - \overline{\Lambda}^r\|^2$  where  $\overline{\Lambda}^r = \frac{1}{n} \sum_{i=1}^n \Lambda_i^r$ , used in our auxiliary function, and the sampling variance  $\sigma^2$  given in Assumption 3.4. To this end, we substitute the definition of the correction term  $\mathbf{c}_i^r$  and obtain

$$(I) \leq 2\mathbb{E} \left\| \eta \sum_{\ell=0}^{t} \left( \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}) - \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \right) \right.$$

$$+ \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) + \frac{1}{\tau} \sum_{t=0}^{\tau-1} \frac{1}{n} \sum_{i=1}^{n} \nabla f_{i}(\mathbf{z}_{i,t}^{r-1}; \mathcal{B}_{i,t}^{r-1})$$

$$- \frac{1}{\tau} \sum_{t=0}^{\tau-1} \nabla f_{i}\left(\mathbf{z}_{i,t}^{r-1}; \mathcal{B}_{i,t}^{r-1}\right) - \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \right) \right\|^{2}$$

$$= 2\mathbb{E} \left\| \eta \sum_{\ell=0}^{t} \left( \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}) - \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \right.$$

$$+ \frac{1}{\eta \tau} \left( \Lambda_{i}^{r} - \overline{\Lambda}^{r} \right) \right) \right\|^{2}$$

$$\leq 4\mathbb{E} \left\| \eta \sum_{\ell=0}^{t} \left( \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}) - \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \right) \right\|^{2}$$

$$+ 4\mathbb{E} \left\| \frac{t+1}{\tau} \Lambda_{i}^{r} - \frac{t+1}{\tau} \overline{\Lambda}^{r} \right\|^{2},$$

where we substitute  $\mathbf{c}_i^1 = \mathbf{0}_d$  and  $\nabla f_i(\mathbf{z}_{i,t}^0; \mathcal{B}_{i,t}^0) = \mathbf{0}_d$ . Next, we use Assumption 3.4 to bound the term (III). By adding and subtracting  $\nabla f_i(\mathbf{z}_{i,\ell}^r)$ , we have

$$+8\mathbb{E} \|\eta \sum_{\ell=0}^{t} \left(\nabla f_{i}(\mathbf{z}_{i,\ell}^{r}) - \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}))\right)\|^{2}.$$

The second term on the right hand of (A.16) can be bounded using Assumption 3.2, while the first term can be handled by the fact [22, Corollary C.1] that

$$\mathbb{E} \left\| \frac{1}{t+1} \sum_{\ell=0}^{t} \left( \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}) - \nabla f_{i}(\mathbf{z}_{i,\ell}^{r}) \right) \right\|^{2}$$

$$= \frac{1}{(t+1)^{2}} \sum_{\ell=0}^{t} \mathbb{E} \left[ \mathbb{E} \left[ \left\| \left( \nabla f_{i}\left(\mathbf{z}_{i,\ell}^{r}; \mathcal{B}_{i,\ell}^{r}\right) - \nabla f_{i}\left(\mathbf{z}_{i,\ell}^{r}\right) \right) \right\|^{2} |\mathcal{F}_{t}^{r} \right] \right]$$

$$\leq \frac{1}{t+1} \frac{\sigma^{2}}{h}.$$
(A.17)

Substituting (A.16) and (A.17) into (A.15), we thus have

(I) 
$$\leq 8(t+1)\eta^2 L^2 \sum_{\ell=0}^{t} \mathbb{E} \|\mathbf{z}_{i,\ell}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\|^2$$
 (A.18)  
  $+ 4\left(\frac{t+1}{\tau}\right)^2 \mathbb{E} \|\Lambda_i^r - \overline{\Lambda}^r\|^2 + 8(t+1)\eta^2 \frac{\sigma^2}{b},$ 

where we have used the *L*-smoothness Assumption 3.2. Now, plugging (A.18) and (A.13) into (A.10) yields

$$\mathbb{E}[\|\mathbf{z}_{i,t+1}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\|^2] \qquad (A.19)$$

$$\leq 8(t+1)\eta^2 L^2 \sum_{\ell=0}^t \mathbb{E}\|\mathbf{z}_{i,\ell}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\|^2 + 16\tau^2\eta^2 B_g^2$$

$$+ 4\tau^2\eta^2 \|\mathcal{G}_{\tilde{\eta}g}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\|^2 + 4\mathbb{E}\|\Lambda_i^r - \overline{\Lambda}^r\|^2 + 8\tau\eta^2 \frac{\sigma^2}{h}.$$

To get a recursion for the drift error from (A.19), we let  $A^r$  denote the sum of the last four terms on the right hand of (A.19) and define  $S^r_{i,t} := \sum_{\ell=0}^t \mathbb{E} \|\mathbf{z}^r_{i,\ell} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\|^2$ . In this way,  $\mathbb{E}[\|\mathbf{z}^r_{i,t+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\|^2] = S^r_{i,t+1} - S^r_{i,t}$  and (A.19) implies that

$$S_{i,t+1}^r \le (1 + 1/(8\tau)) S_{i,t}^r + A^r,$$
 (A.20)

since  $8(t+1)\eta^2 L^2 \le 1/(8\tau)$  when  $\tilde{\eta} \le \eta_g/(8L)$ . By repeated application of (A.20), we conclude that

$$S_{i,\tau-1}^r \le A^r \sum_{\ell=0}^{\tau-2} (1 + 1/(8\tau))^\ell \le 1.15\tau A^r,$$
 (A.21)

since  $\sum_{\ell=0}^{\tau-2} (1+1/(8\tau))^{\ell} \leq \sum_{\ell=0}^{\tau-2} \exp\left(\ell/(8\tau)\right) \leq \sum_{\ell=0}^{\tau-2} \exp\left(1/8\right) \leq 1.15\tau$ . Summing (A.21) over all the clients i completes the proof of Lemma A.1.

With the drift error bound in Lemma A.1 at hand, we

are ready to establish a recursion for the second part of our auxiliary function,  $\frac{1}{n}\mathbb{E}\|\mathbf{\Lambda}^{r+1} - \overline{\mathbf{\Lambda}}^{r+1}\|^2$ .

**Lemma A.2** Under Assumptions 3.1, 3.2, and 3.4, if  $\tilde{\eta} \leq \frac{\eta_g}{\sqrt{20}L}$ , we have

$$\begin{split} &\frac{1}{n}\mathbb{E}\|\boldsymbol{\Lambda}^{r+1}-\overline{\boldsymbol{\Lambda}}^{r+1}\|^2-2\eta^2\tau^2L^2\mathbb{E}\left\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})-P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)\right\|^2\\ \leq &\frac{1}{n}4\eta^2\tau L^2\Big(5\tau^3\eta^2n\cdot 4B_g^2+5n\tau^3\eta^2\|\mathcal{G}_{\tilde{\eta}g}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))\|^2\\ &+5\tau\mathbb{E}\|\boldsymbol{\Lambda}^r-\overline{\boldsymbol{\Lambda}}^r\|^2+10n\tau^2\eta^2\frac{\sigma^2}{b}\Big)+\frac{1}{n}4\eta^2n^2\tau^2\frac{\sigma^2}{n\tau b}. \end{split}$$

**PROOF.** By the definition of  $\Lambda^{r+1}$  and  $\overline{\Lambda}^{r+1}$  we have

$$\mathbb{E} \| \boldsymbol{\Lambda}^{r+1} - \overline{\boldsymbol{\Lambda}}^{r+1} \|^{2}$$

$$= \eta^{2} \mathbb{E} \| \tau \nabla \mathbf{f} (P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r+1})) - \sum_{t=0}^{\tau-1} \nabla \mathbf{f} (\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r})$$

$$- \tau \overline{\nabla \mathbf{f}} (P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r+1})) + \sum_{t=0}^{\tau-1} \overline{\nabla \mathbf{f}} (\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r}) \|^{2}$$

$$\leq \eta^{2} \mathbb{E} \| \tau \nabla \mathbf{f} (P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r+1})) - \sum_{t=0}^{\tau-1} \nabla \mathbf{f} (\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r}) \|^{2},$$

where the inequality follows from the fact that  $\|\mathbf{Y} - \mathbf{W}\mathbf{Y}\|^2 = \|\mathbf{Y} - (\frac{1}{n}\mathbf{1}_n\mathbf{1}_n^T\otimes\mathbf{I}_d)\mathbf{Y}\|^2 \leq \|\mathbf{Y}\|^2$  holds for all  $\mathbf{Y}$ . Next, adding and subtracting  $\nabla\mathbf{f}(P_{\tilde{\eta}}(\overline{\mathbf{X}}^r))$  and  $\sum_{t=0}^{\tau-1} \nabla\mathbf{f}(\mathbf{Z}_t^r)$  to the argument of the norm yields

$$\mathbb{E}\|\boldsymbol{\Lambda}^{r+1} - \overline{\boldsymbol{\Lambda}}^{r+1}\|^{2} \qquad (A.23)$$

$$\leq \eta^{2} \mathbb{E} \left\| \tau \nabla \mathbf{f}(P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r+1})) - \tau \nabla \mathbf{f}(P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r})) + \tau \nabla \mathbf{f}(P_{\tilde{\eta}}(\overline{\mathbf{X}}^{r})) - \sum_{t=0}^{\tau-1} \nabla \mathbf{f}(\mathbf{Z}_{t}^{r}) + \sum_{t=0}^{\tau-1} \nabla \mathbf{f}(\mathbf{Z}_{t}^{r}) - \sum_{t=0}^{\tau-1} \nabla \mathbf{f}(\mathbf{Z}_{t}^{r}; \mathcal{B}_{t}^{r}) \right\|^{2}$$

$$\leq 2\eta^{2} \tau^{2} L^{2} n \mathbb{E} \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2}$$

$$+ 4\eta^{2} \tau L^{2} \sum_{t=0}^{\tau-1} \sum_{i=1}^{n} \mathbb{E} \left\| \mathbf{z}_{i,t}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2} + 4\eta^{2} \tau n \frac{\sigma^{2}}{b}.$$

Here, the inequality follows from applying  $||a + b||^2 \le 2||a||^2 + 2||b||^2$  twice, utilizing the *L*-smoothness Assumption 3.2, and employing similar derivations as in (A.17) for  $t + 1 = \tau$ . Reorganizing (A.23), we get

$$\mathbb{E}\|\boldsymbol{\Lambda}^{r+1} - \overline{\boldsymbol{\Lambda}}^{r+1}\|^2 - 2\eta^2 \tau^2 L^2 n \mathbb{E} \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) \right\|^2$$

$$\leq 4\eta^2 \tau L^2 \sum_{t=0}^{\tau-1} \sum_{i=1}^n \mathbb{E} \left\| \mathbf{z}_{i,t}^r - P_{\tilde{\eta}}(\overline{\mathbf{x}}^r) \right\|^2 + 4\eta^2 \tau n \frac{\sigma^2}{b}. \quad (A.24)$$

By substituting the drift error given by (A.8) into (A.24) and then multiplying both sides of the result by 1/n, we arrive at the desired result, and the proof is complete.

## A.5 Proof of Theorem 3.5

In the proofs of Lemmas A.1 and A.2, our focus was on the local update. Starting from this section, we shift our attention to the server-side update. We begin with the following useful fact [10, Lemma 1]:

Fact 1 Let  $\mathbf{x}^+ := P_{\eta}(\mathbf{x} - \eta \mathbf{v})$  where  $\eta > 0$ , then we have

$$\begin{split} &F\left(\mathbf{x}^{+}\right) \leq F(\mathbf{z}) + \left\langle \nabla F(\mathbf{x}) - \boldsymbol{v}, \mathbf{x}^{+} - \mathbf{z} \right\rangle \\ &- \frac{1}{\eta} \left\langle \mathbf{x}^{+} - \mathbf{x}, \mathbf{x}^{+} - \mathbf{z} \right\rangle + \frac{L}{2} \left\| \mathbf{x}^{+} - \mathbf{x} \right\|^{2} + \frac{L}{2} \|\mathbf{z} - \mathbf{x}\|^{2}, \forall \mathbf{z}. \end{split}$$

Here,  $\mathbf{x}^+$  refers to the variable after one update starting from  $\mathbf{x}$ . Fact 1 gives the function-value decrease after an update on the form  $\mathbf{x}^+ := P_{\eta}(\mathbf{x} - \eta \mathbf{v})$ . Our analysis relies on two updates that follow such a pattern: the server-side update (3) and the virtual centralized PGD update (4). We will apply Fact 1 to (4) and (3), respectively.

First, applying Fact 1 to (4) using  $\mathbf{x}^+ = \tilde{\mathbf{x}}^{r+1}$ ,  $\mathbf{z} = P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ ,  $\mathbf{x} = P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ , and  $\mathbf{v} = \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  yields

$$\begin{split} & \mathbb{E}\left[F\left(\tilde{\mathbf{x}}^{r+1}\right)\right] \leq \mathbb{E}\Big[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) \\ & + \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \left\|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2} - \frac{1}{2\tilde{\eta}} \left\|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2}\Big]. \end{split}$$

Next, applying Fact 1 to (3) with  $\mathbf{x}^+ = P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})$ ,  $\mathbf{x} = P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)$ ,  $\mathbf{z} = \tilde{\mathbf{x}}^{r+1}$ , and  $\mathbf{v} = \mathbf{v}^r$  gives

$$\mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})\right)\right] \qquad (A.26)$$

$$\leq \mathbb{E}\left[F(\tilde{\mathbf{x}}^{r+1}) + \left\langle \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) - \boldsymbol{v}^{r}, P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}\right\rangle \right.$$

$$\left. - \frac{1}{\tilde{\eta}} \left\langle P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}), P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}\right\rangle \right.$$

$$\left. + \frac{L}{2} \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2} + \frac{L}{2} \left\| \tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2} \right]$$

$$= \mathbb{E}\left[ F\left(\tilde{\mathbf{x}}^{r+1}\right) + \left\langle \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) - \boldsymbol{v}^{r}, P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1} \right\rangle \right.$$

$$\left. + \left( \frac{L}{2} - \frac{1}{2\tilde{\eta}} \right) \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2}$$

$$+ \left( \frac{L}{2} + \frac{1}{2\tilde{\eta}} \right) \left\| \tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \right\|^{2} - \frac{1}{2\tilde{\eta}} \left\| P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1} \right\|^{2} \right],$$

where the last step uses  $2\langle b, b-a \rangle = ||b-a||^2 + ||b||^2 - ||a||^2$ . We now use (A.25) to eliminate the virtual function value  $F(\tilde{\mathbf{x}}^{r+1})$  in (A.26) and simplify:

$$\mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})\right)\right]$$

$$\leq \mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) + \left(L - \frac{1}{2\tilde{\eta}}\right) \|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2}$$
(A.27)

$$+ \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2} \underbrace{-\frac{1}{2\tilde{\eta}} \left\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}\right\|^{2}}_{(\text{IV})} + \underbrace{\left\langle P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}, \nabla f\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - \boldsymbol{v}^{r}\right\rangle}_{(\text{V})}\right].$$

The term (IV) can be used to eliminate part of the term (V). In particular, since  $||a+b||^2 \le \frac{1}{2\tilde{p}}||a||^2 + \frac{\tilde{p}}{2}||b||^2$ ,

$$\begin{split} &(\mathrm{IV}) + (\mathrm{V}) &(\mathrm{A}.28) \\ \leq &(\mathrm{IV}) + \frac{1}{2\tilde{\eta}} \|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}\|^2 + \frac{\tilde{\eta}}{2} \|\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) - \boldsymbol{v}^r\|^2 \\ = &\frac{\tilde{\eta}}{2} \|\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) - \boldsymbol{v}^r\|^2. \end{split}$$

Recall that  $\nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r)) = \frac{1}{n} \sum_{i=1}^n \nabla f_i(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  $= \frac{1}{n\tau} \sum_{t=0}^{\tau-1} \sum_{i=1}^n \nabla f_i(P_{\tilde{\eta}}(\overline{\mathbf{x}}^r))$  and  $\mathbf{v}^r := \frac{1}{n\tau} \sum_{t=0}^{\tau-1} \sum_{t=0}^{\tau-1} \sum_{t=0}^{\tau-1} (\nabla f_i(\mathbf{z}_{i,t}^r; \mathcal{B}_{i,t}^r))$ . By adding and subtracting  $\nabla f_i(\mathbf{z}_{i,t}^r)$  and following similar derivations as in (A.17),

$$\mathbb{E} \| \boldsymbol{v}^{r} - \nabla f(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \|^{2}$$

$$= \mathbb{E} \| \frac{1}{n\tau} \sum_{t=0}^{\tau-1} \sum_{i=1}^{n} \left( \nabla f_{i} \left( \mathbf{z}_{i,t}^{r}; \mathcal{B}_{i,t}^{r} \right) - \nabla f_{i}(\mathbf{z}_{i,t}^{r}) \right) + \nabla f_{i}(\mathbf{z}_{i,t}^{r}) - \nabla f_{i}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) \right) \|^{2}$$

$$\leq 2L^{2} \frac{1}{n\tau} \sum_{i=1}^{n} \sum_{t=0}^{\tau-1} \mathbb{E} \| \mathbf{z}_{i,t}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}) \|^{2} + \frac{2}{\tau n} \frac{\sigma^{2}}{b},$$
(A.29)

where the inequality follows from L-smoothness Assumption 3.2. Using (A.28) and (A.29) in (A.27) yields

$$\mathbb{E}[F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}))] \qquad (A.30)$$

$$\leq \mathbb{E}\Big[F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) + \left(L - \frac{1}{2\tilde{\eta}}\right) \|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2}$$

$$+ \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2}$$

$$+ \frac{\tilde{\eta}}{2} \left(\frac{2L^{2}}{n\tau} \sum_{i=1}^{n} \sum_{t=0}^{\tau-1} \|\mathbf{z}_{i,t}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2} + \frac{2}{\tau n} \frac{\sigma^{2}}{b}\right)\Big].$$

The final term is the drift-error, which we bounded in Lemma A.1. Using (A.8) in (A.30) gives

$$\mathbb{E}[F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}))] \tag{A.31}$$

$$\leq \mathbb{E}\Big[F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) + \left(L - \frac{1}{2\tilde{\eta}}\right) \|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2}$$

$$+ \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2}$$

$$+ \frac{\tilde{\eta}}{2} \cdot 2L^{2} \frac{1}{n\tau} \cdot 1.15\tau \left(4\tau^{2}\eta^{2}n \cdot 4B_{g}^{2}\right)$$

$$+4n\tau^{2}\eta^{2}\|\mathcal{G}_{\tilde{\eta}g}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}))\|^{2}+4\mathbb{E}\|\mathbf{\Lambda}^{r}-\overline{\mathbf{\Lambda}}^{r}\|^{2}+8n\tau\eta^{2}\frac{\sigma^{2}}{b}\right)$$
$$+\frac{\tilde{\eta}}{2}\cdot2\frac{1}{\tau n}\frac{\sigma^{2}}{b}\right].$$

To quantify the auxiliary function descent, we subtract  $F^*$  from both sides of (A.31) and multiply by  $\tilde{\eta}$ , then sum the resulting inequality with Lemma A.2 to obtain

$$\begin{split} & \mathbb{E}\Big[\tilde{\eta}\left(F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})) - F^{\star}\right) + \frac{1}{n}\|\mathbf{\Lambda}^{r+1} - \overline{\mathbf{\Lambda}}^{r+1}\|^{2}\Big] \\ \leq & \mathbb{E}\Big[\tilde{\eta}\left(F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) - F^{\star}\right) + \frac{1}{n}\|\mathbf{\Lambda}^{r} - \overline{\mathbf{\Lambda}}^{r}\|^{2} + \frac{6\tilde{\eta}^{2}}{n\tau}\frac{\sigma^{2}}{b} \\ & + \frac{2.8 \cdot 20L^{2}\tilde{\eta}^{4}}{\eta_{a}^{2}}B_{g}^{2} - 0.3\tilde{\eta}^{2}\|\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}))\|^{2}\Big], \quad (A.32) \end{split}$$

where the inequality follows after substituting the stepsize condition (13) and performing straightforward algebraic calculations. By the definition of the auxiliary function  $\Omega^r$ , (A.32) implies that

$$\mathbb{E}\left[\Omega^{r+1}\right] \leq \mathbb{E}\left[\Omega^{r}\right] + \frac{6\tilde{\eta}}{n\tau} \frac{\sigma^{2}}{b} + \frac{2.8 \cdot 20L^{2}\tilde{\eta}^{3}}{\eta_{q}^{2}} B_{g}^{2} - 0.3\tilde{\eta}\mathbb{E} \left\|\mathcal{G}(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r}))\right\|^{2}.$$
(A.33)

Telescoping this inequality completes the proof of Theorem 3.5.

#### A.6 Proof of Theorem 3.6

The proximal PL inequality allows us to establish stronger function-value decrease by the virtual centralized PGD iterate (4). Following the procedure in [10, Equation (34)], we obtain

$$\mathbb{E}\left[F\left(\tilde{\mathbf{x}}^{r+1}\right)\right] \leq \mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - \mu\tilde{\eta}\left(F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - F^{\star}\right)\right],$$
(A.34) where we have used that  $\tilde{\eta} \leq 1/(10L)$ . Adding  $2/3 \times (A.25)$  and  $1/3 \times (A.34)$  yields

$$\begin{split} & \mathbb{E}\left[F\left(\tilde{\mathbf{x}}^{r+1}\right)\right] \leq \mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) \\ & + \left(\frac{L}{3} - \frac{2}{3\tilde{\eta}}\right) \left\|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2} - \frac{\mu\tilde{\eta}}{3}\left(F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - F^{\star}\right)\right]. \end{split}$$

Recall that (A.26) describes the function-value decrease of our algorithm at the server-side. Using (A.35) to eliminate the virtual function value  $F(\tilde{\mathbf{x}}^{r+1})$  in (A.26) yields

$$\mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})\right)\right] \tag{A.36}$$

$$\leq \mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) + \left(\frac{5L}{6} - \frac{1}{6\tilde{\eta}}\right) \left\|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2} + \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \left\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2}$$

$$-\frac{\mu\tilde{\eta}}{3}\left(F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - F^{\star}\right) \underbrace{-\frac{1}{2\tilde{\eta}}\left\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}\right\|^{2}}_{(\mathrm{IV})} + \underbrace{\left\langle P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - \tilde{\mathbf{x}}^{r+1}, \nabla f\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - \mathbf{v}^{r}\right\rangle}_{(\mathrm{V})}.$$

We encounter the same terms (IV)+(V) as in (A.27) and proceed similarly. By using (A.28) and (A.29) in (A.36) and then subtracting  $F^*$  from both sides, we find

$$\mathbb{E}\left[F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})\right) - F^{\star}\right] \tag{A.37}$$

$$\leq \mathbb{E}\left[\left(1 - \frac{\mu\tilde{\eta}}{3}\right) \left(F\left(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right) - F^{\star}\right) - \frac{1}{12\tilde{\eta}} \left\|\tilde{\mathbf{x}}^{r+1} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2}$$

$$+ \left(\frac{L}{2} - \frac{1}{2\tilde{\eta}}\right) \left\|P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1}) - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\right\|^{2}$$

$$+ \frac{\tilde{\eta}}{2} \left(\frac{2L^{2}}{n\tau} \sum_{i=1}^{n} \sum_{t=0}^{\tau-1} \|\mathbf{z}_{i,t}^{r} - P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})\|^{2} + \frac{2}{\tau n} \frac{\sigma^{2}}{b}\right)\right],$$

where we have used that  $\frac{5L}{6} - \frac{1}{6\bar{\eta}} \leq \frac{1}{12\bar{\eta}}$ . Since (A.37) and (A.30) only differ in the two first terms of the right-hand side, we can follow similar arguments as we used in deriving (A.32) and use Lemmas A.1 and A.2 to find

$$\mathbb{E}\left[\tilde{\eta}(F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r+1})) - F^{\star}) + \frac{1}{n} \|\mathbf{\Lambda}^{r+1} - \overline{\mathbf{\Lambda}}^{r+1}\|^{2}\right] \\
\leq \left(1 - \frac{\mu\tilde{\eta}}{3}\right) \mathbb{E}\left[\tilde{\eta}\left(F(P_{\tilde{\eta}}(\overline{\mathbf{x}}^{r})) - F^{\star}\right) + \frac{1}{n} \|\mathbf{\Lambda}^{r} - \overline{\mathbf{\Lambda}}^{r}\|^{2}\right] \\
+ 6\tilde{\eta}^{2} \frac{1}{n\tau} \frac{\sigma^{2}}{b} + 2.8 \cdot 20L^{2} \frac{\tilde{\eta}^{4}}{\eta_{g}^{2}} B_{g}^{2}. \tag{A.38}$$

Also in this case, the final term is the result of the stepsize condition (13) and simple algebraic calculations. By dividing both sides of the inequality with  $\tilde{\eta}$  we obtain the following inequality for  $\Omega^r$ 

$$\mathbb{E}[\Omega^{r+1}] \le \left(1 - \frac{\mu\tilde{\eta}}{3}\right) \mathbb{E}[\Omega^r] + \frac{6\tilde{\eta}}{n\tau} \frac{\sigma^2}{b} + 2.8 \cdot 20L^2 \frac{\tilde{\eta}^3}{\eta_g^2} B_g^2.$$

Telescoping this inequality yields the desired result and concludes the proof of Theorem 3.6.

#### References

- Mahmoud M Badr, Mohamed Mahmoud, Yuguang Fang, Mohammed Abdulaal, Abdulah J Aljohani, Waleed Alasmary, and Mohamed I Ibrahem. Privacy-preserving and communication-efficient energy prediction scheme based on federated learning for smart grids. *IEEE Internet of Things Journal*, 10(9):7719-7736, 2023.
- [2] Yajie Bao, Michael Crawshaw, Shan Luo, and Mingrui Liu. Fast composite optimization and statistical recovery in federated learning. In *International Conference on Machine* Learning, pages 1508–1536, 2022.

- [3] Amir Beck and Marc Teboulle. A fast iterative shrinkagethresholding algorithm for linear inverse problems. SIAM Journal on Imaging Sciences, 2(1):183–202, 2009.
- [4] Gianluca Bianchin, Jorge I Poveda, and Emiliano Dall'Anese. Online optimization of switched LTI systems using continuous-time and hybrid accelerated gradient flows. Automatica, 146:110579, 2022.
- [5] Sophie M Fosson, Vito Cerone, and Diego Regruto. Sparse linear regression from perturbed data. Automatica, 122:109284, 2020.
- [6] Alfredo Garcia, Luochao Wang, Jeff Huang, and Lingzhou Hong. Distributed networked real-time learning. IEEE Transactions on Control of Network Systems, 8(1):28–38, 2020.
- [7] Saeed Ghadimi, Guanghui Lan, and Hongchao Zhang. Minibatch stochastic approximation methods for nonconvex stochastic composite optimization. Mathematical Programming, 155(1):267–305, 2016.
- [8] Bingsheng He, Han Liu, Zhaoran Wang, and Xiaoming Yuan. A strictly contractive Peaceman–Rachford splitting method for convex programming. SIAM Journal on Optimization, 24(3):1011–1040, 2014.
- [9] Lingzhou Hong, Alfredo Garcia, and Ceyhun Eksin. Distributed networked learning with correlated data. Automatica, 137:110134, 2022.
- [10] Sashank J Reddi, Suvrit Sra, Barnabas Poczos, and Alexander J Smola. Proximal stochastic methods for nonsmooth nonconvex finite-sum optimization. Advances in Neural Information Processing Systems, 29, 2016.
- [11] Hamed Karimi, Julie Nutini, and Mark Schmidt. Linear convergence of gradient and proximal-gradient methods under the Polyak- Lojasiewicz condition. In Machine Learning and Knowledge Discovery in Databases, pages 795– 811, 2016.
- [12] Sai Praneeth Karimireddy, Martin Jaggi, Satyen Kale, Mehryar Mohri, Sashank J Reddi, Sebastian U Stich, and Ananda Theertha Suresh. Mime: Mimicking centralized stochastic algorithms in federated learning. arXiv preprint arXiv:2008.03606, 2020.
- [13] Sai Praneeth Karimireddy, Satyen Kale, Mehryar Mohri, Sashank Reddi, Sebastian Stich, and Ananda Theertha Suresh. Scaffold: Stochastic controlled averaging for federated learning. In International Conference on Machine Learning, pages 5132–5143, 2020.
- [14] Jiajin Li, Anthony Man-Cho So, and Wing-Kin Ma. Understanding notions of stationarity in nonsmooth optimization: A guided tour of various constructions of subdifferential for nonsmooth functions. IEEE Signal Processing Magazine, 37(5):18–31, 2020.
- [15] Tian Li, Anit Kumar Sahu, Manzil Zaheer, Maziar Sanjabi, Ameet Talwalkar, and Virginia Smith. Federated optimization in heterogeneous networks. Proceedings of Machine Learning and Systems, 2:429–450, 2020.
- [16] Xiang Li, Kaixuan Huang, Wenhao Yang, Shusen Wang, and Zhihua Zhang. On the convergence of FedAvg on non-iid data. In International Conference on Learning Representations, 2019.
- [17] Andrew Lowy, Ali Ghafelebashi, and Meisam Razaviyayn. Private non-convex federated learning without a trusted server. In International Conference on Artificial Intelligence and Statistics, pages 5749–5786, 2023.
- [18] Zhi-Quan Luo and Paul Tseng. Error bounds and convergence analysis of feasible descent methods: a general

- approach. Annals of Operations Research, 46(1):157–178, 1993.
- [19] Brendan McMahan, Eider Moore, Daniel Ramage, Seth Hampson, and Blaise Aguera y Arcas. Communicationefficient learning of deep networks from decentralized data. In Artificial Intelligence and Statistics, pages 1273–1282, 2017.
- [20] Elad Michael, Chris Manzie, Tony A Wood, Daniel Zelazo, and Iman Shames. Gradient free cooperative seeking of a moving source. Automatica, 152:110948, 2023.
- [21] Yurii Nesterov. Primal-dual subgradient methods for convex problems. Mathematical Programming, 120(1):221–259, 2009.
- [22] Maxence Noble, Aur´elien Bellet, and Aymeric Dieuleveut. Differentially private federated learning on heterogeneous data. In International Conference on Artificial Intelligence and Statistics, pages 10110–10145, 2022.
- [23] Reese Pathak and Martin J Wainwright. FedSplit: An algorithmic framework for fast federated optimization. Advances in Neural Information Processing Systems, 33:7057–7066, 2020.
- [24] Sebastian U Stich. Local SGD converges fast and communicates little. In International Conference on Learning Representations, 2018.
- [25] Quoc Tran Dinh, Nhan H Pham, Dzung Phan, and Lam Nguyen. FedDR–randomized Douglas-Rachford splitting algorithms for nonconvex federated composite optimization. Advances in Neural Information Processing Systems, 34:30326–30338, 2021.
- [26] Han Wang, Siddartha Marella, and James Anderson. FedADMM: A federated primal-dual algorithm allowing partial participation. In 2022 IEEE 61st Conference on Decision and Control (CDC), pages 287–294, 2022.
- [27] Yongqiang Wang and Tamer Ba¸sar. Decentralized nonconvex optimization with guaranteed privacy and accuracy. Automatica, 150:110858, 2023.
- [28] Farzad Yousefian, Angelia Nedi´c, and Uday V Shanbhag. On stochastic gradient and subgradient methods with adaptive steplength sequences. Automatica, 48(1):56–67, 2012.
- [29] Honglin Yuan, Manzil Zaheer, and Sashank Reddi. Federated composite optimization. In International Conference on Machine Learning, pages 12253–12266, 2021.
- [30] Xiaotong Yuan and Ping Li. On convergence of FedProx: Local dissimilarity invariant bounds, non-smoothness and beyond. Advances in Neural Information Processing Systems, 35:10752–10765, 2022.
- [31] Man-Chung Yue, Zirui Zhou, and Anthony Man-Cho So. A family of inexact SQA methods for non-smooth convex minimization with provable convergence guarantees based on the Luo–Tseng error bound property. Mathematical Programming, 174(1):327–358, 2019.
- [32] Feng Zhang, Yongjing Zhang, Shan Ji, and Zhaoyang Han. Secure and decentralized federated learning framework with non-iid data based on blockchain. Heliyon, 10(5), 2024.
- [33] Jiaojiao Zhang, Jiang Hu, and Mikael Johansson. Composite federated learning with heterogeneous data. arXiv preprint arXiv:2309.01795, 2023.
- [34] Tuo Zhang, Tiantian Feng, Samiul Alam, Sunwoo Lee, Mi Zhang, Shrikanth S Narayanan, and Salman Avestimehr. Fedaudio: A federated learning benchmark for audio tasks. In IEEE International Conference on Acoustics, Speech and Signal Processing, pages 1–5, 2023.
- [35] Xinwei Zhang, Mingyi Hong, Sairaj Dhople, Wotao Yin, and Yang Liu. FedPD: A federated learning framework with adaptivity to non-iid data. IEEE Transactions on Signal Processing, 69:6055–6070, 2021.