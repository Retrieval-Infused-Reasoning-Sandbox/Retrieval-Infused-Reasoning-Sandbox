#### <span id="page-0-0"></span>[Skip to main content](#page-1-0)

#### Advertisement

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/book/10.1007/978-0-387-70914-7) [Springer Nature Link](https://link.springer.com)

[Menu](#page-9-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-8-0)

![](_page_0_Picture_6.jpeg)

- [Home](file:///) 1.
- Textbook 2.

![](_page_0_Picture_9.jpeg)

# **Functional Analysis, Sobolev Spaces and Partial Differential Equations**

- Textbook •
- © 2011 •
- 1st edition •
- [View latest edition](file:///book/9780387709130) •

[Accessibility Information](#page-6-0)

### <span id="page-1-0"></span>**Overview**

Authors:

- [Haim Brezis](#page-1-1) [0](#page-1-2) •
- Haim Brezis 1.
  - , Department of Mathematics, Rutgers University, Piscataway, USA 1.

<span id="page-1-2"></span><span id="page-1-1"></span>[View author publications](file:///search?dc.creator=Haim+Brezis&sortBy=newestFirst)

Search author on: [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Haim+Brezis) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Haim+Brezis%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

- Major textbook by a well-known and highly regarded author •
- The first single-volume textbook to cover related fields of functional analysis and PDEs •
- Includes supplementary material: [sn.pub/extras](https://extras.springer.com/?query=978-0-387-70913-0) •

Part of the book series: [Universitext](https://link.springer.com/series/223) (UTX)

- 365k Accesses •
- 4288 Citations •
- 109 [Altmetric](https://link.altmetric.com/details/471991) •

 This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-387-70914-7) to check access.

### **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-387-70914-7)

**Softcover Book EUR 69.99** 

Price excludes VAT (China (P.R.))

book

10.1007/978-0-387-70914-7

978-0-387-70913-0

Functional Analysis, Sobolev Spaces and Partial Differential Equations

1d0ea5b465e70eb560fcaf9ea0bbc8b714d4cd2ddb374ee2b62a96bc92d332e4fe6a63c6f58500afff3e5184be6445bdf079cea615ad251eaf8d95f1aed97e14

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

Tax calculation will be finalised at checkout

## **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-0-387-70914-7) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

### **About this book**

This textbook is a completely revised, updated, and expanded English edition of the important Analyse fonctionnelle (1983). In addition, it contains a wealth of problems and exercises (with solutions) to guide the reader. Uniquely, this book presents in a coherent, concise and unified way the main results from functional analysis together with the main results from the theory of partial differential equations (PDEs). Although there are many books on functional analysis and many on PDEs, this is the first to cover both of these closely connected topics. Since the French book was first published, it has been translated into Spanish, Italian, Japanese, Korean, Romanian, Greek and Chinese. The English edition makes a welcome addition to this list.

### **Similar content being viewed by others**

![](_page_3_Picture_1.jpeg)

#### **[Exact Solutions of a Nonclassical Nonlinear Equation of the](https://link.springer.com/10.1134/S1995080220100029?fromPaywallRec=true) [Fourth Order](https://link.springer.com/10.1134/S1995080220100029?fromPaywallRec=true)**

Article 01 October 2020

![](_page_3_Picture_4.jpeg)

#### **[An Overview on Tools from Functional Analysis](https://link.springer.com/10.1007/978-3-319-57181-2_2?fromPaywallRec=true)**

Chapter © 2018

![](_page_3_Picture_7.jpeg)

### **[Exact Solutions of a Model Nonlinear Equation](https://link.springer.com/10.1134/S1995080224602571?fromPaywallRec=true)**

Article 01 May 2024

### **Explore related subjects**

Discover the latest articles, books and news in related subjects.

- [Difference and Functional Equations](file:///subjects/difference-and-functional-equations) •
- [Differential Equations](file:///subjects/differential-equations) •
- [Functional Analysis](file:///subjects/functional-analysis) •

| Search within this book |  |  |  |  |
|-------------------------|--|--|--|--|
|-------------------------|--|--|--|--|

#### Search

| 978-0-387-70914-7 |
|-------------------|
| Chapter           |
| Chapter           |
| true              |

### **Table of contents (11 chapters)**

#### **Front Matter** 1.

Pages 1-1 [Download chapter PDF](file:///content/pdf/bfm:978-0-387-70914-7/1) 

2.

**[The Hahn–Banach Theorems. Introduction to the](file:///chapter/10.1007/978-0-387-70914-7_1) [Theory of Conjugate Convex Functions](file:///chapter/10.1007/978-0-387-70914-7_1)**

Haim Brezis Pages 1-29 ◦

3.

**[The Uniform Boundedness Principle and the Closed](file:///chapter/10.1007/978-0-387-70914-7_2) [Graph Theorem](file:///chapter/10.1007/978-0-387-70914-7_2)**

Haim Brezis Pages 31-54 ◦

4.

**[Weak Topologies. Reflexive Spaces. Separable Spaces.](file:///chapter/10.1007/978-0-387-70914-7_3) [Uniform Convexity](file:///chapter/10.1007/978-0-387-70914-7_3)**

Haim Brezis Pages 55-87 ◦

5.

### **[Lp Spaces](file:///chapter/10.1007/978-0-387-70914-7_4)**

Haim Brezis Pages 89-130 ◦

#### **[Hilbert Spaces](file:///chapter/10.1007/978-0-387-70914-7_5)** 6.

Haim Brezis Pages 131-156 ◦

7.

**[Compact Operators. Spectral Decomposition of Self-](file:///chapter/10.1007/978-0-387-70914-7_6)[Adjoint Compact Operators](file:///chapter/10.1007/978-0-387-70914-7_6)**

Haim Brezis Pages 157-179 ◦

8.

### **[The Hille–Yosida Theorem](file:///chapter/10.1007/978-0-387-70914-7_7)**

Haim Brezis Pages 181-199 ◦

9.

**[Sobolev Spaces and the Variational Formulation of](file:///chapter/10.1007/978-0-387-70914-7_8) [Boundary Value Problems in One Dimension](file:///chapter/10.1007/978-0-387-70914-7_8)**

Haim Brezis Pages 201-261 ◦

10.

**[Sobolev Spaces and the Variational Formulation of](file:///chapter/10.1007/978-0-387-70914-7_9) [Elliptic Boundary Value Problems in N Dimensions](file:///chapter/10.1007/978-0-387-70914-7_9)**

Haim Brezis Pages 263-323 ◦

11.

**[Evolution Problems: The Heat Equation and the Wave](file:///chapter/10.1007/978-0-387-70914-7_10) [Equation](file:///chapter/10.1007/978-0-387-70914-7_10)**

Haim Brezis Pages 325-347 ◦

12.

### **[Miscellaneous Complements](file:///chapter/10.1007/978-0-387-70914-7_11)**

Haim Brezis Pages 349-370 ◦

13.

#### **Back Matter**

Pages 365-365 [Download chapter PDF](file:///content/pdf/bbm:978-0-387-70914-7/1) 

[Back to top](#page-0-0)

## **Reviews**

From the reviews:

"Brezis has intelligently chosen several fundamental concepts of functional analysis, and has build the book around them and their applications. … for a newcomer who intends to become a user of functional analysis this book is an ideal place to start. In fact I would recommend this over any other source to any beginning graduate student. … the book also has all the basic tools for a beginer PDE researcher … . Its a bible for the field of research." (Philosophy, Religion and Science Book Reviews, bookinspections.wordpress.com, October, 2013)

"This textbook has its origin in the French version Analyse fonctionnelle published in 1985, which has become a standard reference and was translated into several languages. … At the end of each chapter the reader will find comments with further information, references, and historic remarks. … In summary, the present textbook provides an excellent basis for a course on functional analysis plus a follow-up course on partial differential equations. It is well-written and I can wholeheartedly recommend it to both students and teachers." (G. Teschl, Monatshefte für Mathematik, Vol. 165 (3-4), March, 2012)

"This book is a tour de force by the author, who is a master of modern nonlinear functional analysis and who has contributed extensively to the development of the theory of partial differential equations. … The writing is lively, the material is diverse and maintains a strong unity. … the book is a very useful contribution to the growing literature on this circle of ideas. I wholeheartedly recommend this book both as a textbook, as well as for independent study." (Vicenţiu Rădulescu, Mathematical Reviews, Issue 2012 a)

"The book is the English translation of an 1983 book published in French: Analyse fonctionnelle :théorie et applications … . It has seen translations into numerous languages and the Springer edition was especially anticipated, as it announced a number of practice exercisesfollowing each chapter. I can honestly say that it was well worth the wait. … The text is a pleasure to read. … I wholeheartedly recommend this book as both a textbook as well as for independent study." (Florin Catrina, The Mathematical Association of America, June, 2011)

### **Authors and Affiliations**

**, Department of Mathematics, Rutgers University, Piscataway, USA**  •

Haim Brezis

### <span id="page-6-0"></span>**Accessibility Information**

Accessibility information for this book is coming soon. We're working to make it available as quickly as possible. Thank you for your patience.

### **Bibliographic Information**

- Book Title: Functional Analysis, Sobolev Spaces and Partial Differential Equations •
- Authors: Haim Brezis •
- Series Title: [Universitext](https://link.springer.com/series/223) •
- DOI: https://doi.org/10.1007/978-0-387-70914-7 •
- Publisher: Springer New York, NY •
- eBook Packages: [Mathematics and Statistics,](file:///search?facet-content-type=%22Book%22&package=11649&facet-start-year=2011&facet-end-year=2011) [Mathematics and Statistics](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2011&facet-end-year=2011) [\(R0\)](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2011&facet-end-year=2011) •
- Copyright Information: Springer Science+Business Media, LLC 2011 •
- Softcover ISBN: 978-0-387-70913-0Published: 10 November 2010 •
- eBook ISBN: 978-0-387-70914-7Published: 02 November 2010 •
- Series ISSN: 0172-5939 •
- Series E-ISSN: 2191-6675 •
- Edition Number: 1 •
- Number of Pages: XIV, 600 •
- Topics: [Functional Analysis,](https://link.springer.com/search?facet-sub-discipline=Functional%20Analysis&facet-content-type=Book) [Partial Differential Equations,](https://link.springer.com/search?facet-sub-discipline=Partial%20Differential%20Equations&facet-content-type=Book) [Difference and](https://link.springer.com/search?facet-sub-discipline=Difference%20and%20Functional%20Equations&facet-content-type=Book) [Functional Equations](https://link.springer.com/search?facet-sub-discipline=Difference%20and%20Functional%20Equations&facet-content-type=Book) •

## **Keywords**

[partial differential equations](file:///search?query=partial%20differential%20equations&facet-discipline=%22Mathematics%22) •

### **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

[Back to top](#page-0-0)

### **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-387-70914-7)

#### **Softcover Book EUR 69.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-0-387-70914-7

978-0-387-70913-0

Functional Analysis, Sobolev Spaces and Partial Differential Equations

1d0ea5b465e70eb560fcaf9ea0bbc8b714d4cd2ddb374ee2b62a96bc92d332e4fe6a63c6f58500afff3e5184be6445bdf079cea615ad251eaf8d95f1aed97e14

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

Tax calculation will be finalised at checkout

## **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-0-387-70914-7) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

## <span id="page-8-0"></span>**Search**

Search by keyword or author

### <span id="page-9-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/) •
- [Publish with us](https://www.springernature.com/gp/authors)  •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature