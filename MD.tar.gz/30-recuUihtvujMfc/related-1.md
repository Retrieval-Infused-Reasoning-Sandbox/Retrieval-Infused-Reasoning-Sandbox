# Green's theorem

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

This article is about the theorem in the plane relating double integrals and line integrals. For Green's theorems relating volume integrals involving the Laplacian to surface integrals, see Green's identities.

Not to be confused with Green's law for waves approaching a shoreline.

In <u>vector calculus</u>, **Green's theorem** relates a <u>line integral</u> around a <u>simple closed</u> <u>curve</u> C to a <u>double integral</u> over the <u>plane</u> region D (surface in

$$\mathbb{R}^2$$

- ) bounded by C. It is the two-dimensional special case of Stokes' theorem (surface in  $\mathbb{R}^3$
- ). In one dimension, it is equivalent to the <u>fundamental theorem of calculus</u>. In two dimensions, it is equivalent to the divergence theorem.

Let C be a positively <u>oriented</u>, <u>piecewise smooth</u>, <u>simple closed curve</u> in a <u>plane</u>, and let D be the region bounded by C. If L and M are functions of (x, y) defined on an <u>open region</u> containing D and have <u>continuous partial derivatives</u> there, then

$$\oint_C (L\,dx + M\,dy) = \iint_D \left(rac{\partial M}{\partial x} - rac{\partial L}{\partial y}
ight) dA$$

where the path of integration along C is counterclockwise.

In physics, Green's theorem finds many applications. One is solving two-dimensional flow integrals, stating that the sum of fluid outflowing from a volume is equal to the total outflow summed about an enclosing area. In <u>plane geometry</u>, and in particular, area <u>surveying</u>, Green's theorem can be used to determine the area and centroid of plane figures solely by integrating over the perimeter.

### Proof when D is a simple region

[edit]

[Image]

![](_page_1_Figure_1.jpeg)

If D is a simple type of region with its boundary consisting of the curves  $C_1$ ,  $C_2$ ,  $C_3$ ,  $C_4$ , half of Green's theorem can be demonstrated.

The following is a proof of half of the theorem for the simplified area D, a type I region where  $C_1$  and  $C_3$  are curves connected by vertical lines (possibly of zero length). A similar proof exists for the other half of the theorem when D is a type II region where  $C_2$  and  $C_4$  are curves connected by horizontal lines (again, possibly of zero length). Putting these two parts together, the theorem is thus proven for regions of type III (defined as regions which are both type I and type II). The general case can then be deduced from this special case by decomposing D into a set of type III regions.

If it can be shown that

$$\oint_C L \, dx = \iint_D \left( -rac{\partial L}{\partial y} 
ight) dA$$

and

$$\oint_C \, M \, dy = \iint_D \left( rac{\partial M}{\partial x} 
ight) dA$$

JU

are true, then Green's theorem follows immediately for the region D. We can prove () easily for regions of type I, and () for regions of type II. Green's theorem then follows for regions of type III.

Assume region D is a type I region and can thus be characterized, as pictured on the right, by

$$D = \{(x, y) \mid a \le x \le b, g_1(x) \le y \le g_2(x)\}$$

where  $g_1$  and  $g_2$  are continuous functions on [a, b]. Compute the double integral in ():

$$egin{align} \iint_D rac{\partial L}{\partial y} \, dA &= \int_a^b \, \int_{g_1(x)}^{g_2(x)} rac{\partial L}{\partial y}(x,y) \, dy \, dx \ &= \int_a^b \, \left[ L(x,g_2(x)) - L(x,g_1(x)) 
ight] \, dx. \ \end{aligned}$$

Now compute the line integral in (). C can be rewritten as the union of four curves:  $C_1$ ,  $C_2$ ,  $C_3$ ,  $C_4$ .

With  $C_1$ , use the parametric equations: x = x,  $y = g_1(x)$ ,  $a \le x \le b$ . Then

$$\int_{C_1} L(x,y)\,dx = \int_a^b L(x,g_1(x))\,dx.$$

With  $C_3$ , use the parametric equations:  $x=x, y=g_2(x), a \le x \le b$ . Then

$$\int_{C_3} L(x,y) \, dx = \int_b^a L(x,y) \, dx = - \int_a^b L(x,g_2(x)) \, dx.$$

The integral over  $C_3$  is negated because it goes in the negative direction from b to a, as C is oriented positively (anticlockwise). On  $C_2$  and  $C_4$ , x remains constant, meaning

$$\int_{C_4} L(x,y) \, dx = \int_{C_2} L(x,y) \, dx = 0.$$

Therefore,

$$egin{aligned} \oint_C L \, dx &= \int_{C_1} L(x,y) \, dx + \int_{C_2} L(x,y) \, dx + \int_{C_3} L(x,y) \, dx + \int_{C_4} L(x,y) \, dx \ &= \int_a^b L(x,g_1(x)) \, dx - \int_a^b L(x,g_2(x)) \, dx. \end{aligned}$$

Combining () with (), we get () for regions of type I. A similar treatment using the same endpoints yields () for regions of type II. Putting the two together, we get the result for regions of type III.

#### --o---- -- -y p - ----

## **Proof for rectifiable Jordan curves**

### [edit]

We are going to prove the following

#### Theorem-Let

Г

be a rectifiable, positively oriented Jordan curve in

 $\mathbb{R}^2$ 

and let

R

denote its inner region. Suppose that

 $A,B:\overline{R} o\mathbb{R}$ 

are continuous functions with the property that

 $\boldsymbol{A}$ 

has second partial derivative at every point of

R

B

has first partial derivative at every point of

R

and that the functions

 $D_1B,D_2A:R o\mathbb{R}$ 

are Riemann-integrable over

R

. Then

$$\int_{\Gamma} (A\,dx + B\,dy) = \int_{R} \left( D_1 B(x,y) - D_2 A(x,y) 
ight)\,d(x,y).$$

We need the following lemmas whose proofs can be found in:

### Lemma 1 (Decomposition Lemma)—Assume

Г

is a rectifiable, positively oriented Jordan curve in the plane and let

R

be its inner region. For every positive real

 $\delta$ 

, let

 $\mathcal{F}(\delta)$ 

denote the collection of squares in the plane bounded by the lines

$$x = m\delta, y = m\delta$$

, where

runs through the set of integers. Then, for this

 $\delta$ 

, there exists a decomposition of

 $\overline{R}$ 

into a finite number of non-overlapping subregions in such a manner that

i. Each one of the subregions contained in

R

, say

 $R_1, R_2, \ldots, R_k$ 

, is a square from

 $\mathcal{F}(\delta)$ 

ii. Each one of the remaining subregions, say

$$R_{k+1},\ldots,R_s$$

, has as boundary a rectifiable Jordan curve formed by a finite number of arcs of  $\_$ 

 $\Gamma$ 

and parts of the sides of some square from

 $\mathcal{F}(\delta)$ 

iii. Each one of the border regions

$$R_{k+1},\ldots,R_s$$

can be enclosed in a square of edge-length

 $2\delta$ 

iv. If

 $\Gamma_i$ 

is the positively oriented boundary curve of

 $R_i$ 

, then

$$\Gamma = \Gamma_1 + \Gamma_2 + \cdots + \Gamma_s$$
.

V. The number

$$s-k$$

of border regions is no greater than

$$4 \Big( rac{\Lambda}{\delta} + 1 \Big)$$

, where

Λ

is the length of

 $\Gamma$ 

.

Lemma 2-Let

Γ

be a rectifiable curve in the plane and let

$$\Delta_{\Gamma}(h)$$

be the set of points in the plane whose distance from (the range of)

 $\Gamma$ 

is at most

h

. The outer Jordan content of this set satisfies

$$ar{c} \; \Delta_{\Gamma}(h) \leq 2h\Lambda + \pi h^2$$

.

### Lemma 3-Let

Γ

be a rectifiable closed curve in

 $\mathbb{R}^2$ 

and let

 $f: \mathrm{range} \ \mathrm{of} \ \Gamma o \mathbb{R}$ 

be a continuous function. Then

$$\left|\int_{\Gamma}f(x,y)\,dy
ight|\leq rac{1}{2}\Lambda\Omega_f,$$

and

$$\left|\int_{\Gamma}f(x,y)\,dx
ight|\leq rac{1}{2}\Lambda\Omega_f,$$

where

 $\Omega_f$ 

is the oscillation of

f

on the range of

 $\Gamma$ 

.

Now we are in position to prove the theorem:

#### Proof of Theorem. Let

ε

be an arbitrary positive real number. By continuity of

 $\boldsymbol{A}$ 

,

B

and compactness of

 $\overline{R}$ 

, given

 $\varepsilon > 0$ 

, there exists

 $0 < \delta < 1$ 

such that whenever two points of

 $\overline{R}$ 

### $2\sqrt{2}\,\delta$

apart, their images under

![](_page_6_Picture_3.jpeg)

are less than

 $\varepsilon$ 

apart. For this

δ

, consider the decomposition given by the previous Lemma. We have

$$\int_{\Gamma} A\,dx + B\,dy = \sum_{i=1}^k \int_{\Gamma_i} A\,dx + B\,dy \quad + \sum_{i=k+1}^s \int_{\Gamma_i} A\,dx + B\,dy.$$

Put

$$\varphi := D_1 B - D_2 A$$

For each

$$i \in \{1, \dots, k\}$$

, the curve

$$\Gamma_i$$

is a positively oriented square, for which Green's formula holds. Hence

$$\sum_{i=1}^k \int_{\Gamma_i} A\, dx + B\, dy = \sum_{i=1}^k \int_{R_i} arphi = \int_{igcup_{i=1}^k R_i} arphi.$$

Every point of a border region is at a distance no greater than

$$2\sqrt{2}\,\delta$$

from

Γ

. Thus, if

is the union of all border regions, then

$$K \subset \Delta_{\Gamma}(2\sqrt{2}\,\delta)$$

; hence

$$c(K) \leq ar{c} \, \Delta_{\Gamma}(2\sqrt{2} \, \delta) \leq 4\sqrt{2} \, \delta + 8\pi \delta^2$$

, by Lemma 2. Notice that

$$\int_R arphi \ - \int_{igcup_{i=1}^k R_i} arphi = \int_K arphi.$$

This yields

$$\left|\sum_{i=1}^k \int_{\Gamma_i} A\, dx + B\, dy 
ight. - \int_R arphi 
ight| \leq M \delta (1 + \pi \sqrt{2}\, \delta) ext{ for some } M > 0.$$

We may as well choose

 $\delta$ 

so that the RHS of the last inequality is

 $< \varepsilon$ .

The remark in the beginning of this proof implies that the oscillations of

 $\boldsymbol{A}$ 

and

B

on every border region is at most

 $\varepsilon$ 

. We have

$$\left|\sum_{i=k+1}^s \int_{\Gamma_i} A\, dx + B\, dy
ight| \leq rac{1}{2} arepsilon \sum_{i=k+1}^s \Lambda_i.$$

By Lemma 1(iii),

$$\sum_{i=k+1}^s \Lambda_i \leq \Lambda + (4\delta)\, 4igg(rac{\Lambda}{\delta} + 1igg) \leq 17\Lambda + 16.$$

Combining these, we finally get

$$\left|\int_{\Gamma} A\,dx + B\,dy \right| - \int_{R} arphi 
ight| < Carepsilon,$$

for some

. Since this is true for every

$$\varepsilon > 0$$

, we are done.

## Validity under different hypotheses

[edit]

The hypothesis of the last theorem are not the only ones under which Green's formula is true. Another common set of conditions is the following:

The functions

$$A,B:\overline{R} o\mathbb{R}$$

are still assumed to be continuous. However, we now require them to be Fréchetdifferentiable at every point of

R

. This implies the existence of all directional derivatives, in particular

$$D_{e_i}A=:D_iA, D_{e_i}B=:D_iB, \ i=1,2$$

, where, as usual,

$$(e_1,e_2)$$

is the canonical ordered basis of

$$\mathbb{R}^2$$

. In addition, we require the function

$$D_1B - D_2A$$

to be Riemann-integrable over

R

.

As a corollary of this, we get the Cauchy Integral Theorem for rectifiable Jordan curves:

### Theorem (Cauchy)-If

 $\Gamma$ 

is a rectifiable Jordan curve in

 $\mathbb{C}$ 

and if

 $f: ext{closure of inner region of }\Gamma o \mathbb{C}$ 

is a continuous mapping holomorphic throughout the inner region of

Τ

, then

$$\int_{\Gamma}f=0,$$

the integral being a complex contour integral.

# **Multiply-connected regions**

[edit]

#### Theorem. Let

$$\Gamma_0,\Gamma_1,\ldots,\Gamma_n$$

be positively oriented rectifiable Jordan curves in

 $\mathbb{R}^2$ 

satisfying

$$\Gamma_i \subset R_0, \qquad \qquad ext{if } 1 \leq i \leq n \ \Gamma_i \subset \mathbb{R}^2 \setminus \overline{R}_j, \qquad ext{if } 1 \leq i, j \leq n ext{ and } i 
eq j,$$

where

 $R_i$ 

is the inner region of

 $\Gamma_i$ 

. Let

$$D=R_0\setminus (\overline{R}_1\cup \overline{R}_2\cup \dots \cup \overline{R}_n).$$

Suppose

$$p:\overline{D} o\mathbb{R}$$

and

$$q:\overline{D} o\mathbb{R}$$

are continuous functions whose restriction to

D

is Fréchet-differentiable. If the function

$$(x,y)\longmapsto rac{\partial q}{\partial e_1}(x,y)-rac{\partial p}{\partial e_2}(x,y)$$

is Riemann-integrable over

D

, then

$$egin{split} &\int_{\Gamma_0} p(x,y) \, dx + q(x,y) \, dy - \sum_{i=1}^n \int_{\Gamma_i} p(x,y) \, dx + q(x,y) \, dy \ &= \int_D \left\{ rac{\partial q}{\partial e_1}(x,y) - rac{\partial p}{\partial e_2}(x,y) 
ight\} \, d(x,y). \end{split}$$

# Relationship to Stokes' theorem

[edit]

Green's theorem is a special case of the <u>Kelvin–Stokes theorem</u>, when applied to a region in the

xy

-plane.

We can augment the two-dimensional field into a three-dimensional field with a z component that is always o. Write **F** for the <u>vector</u>-valued function

![](_page_10_Picture_0.jpeg)

$$\mathbf{F}=(L,M,0)$$

. Start with the left side of Green's theorem:

[Image]

$$\oint_C (L\,dx + M\,dy) = \oint_C (L,M,0)\cdot (dx,dy,dz) = \oint_C \mathbf{F}\cdot d\mathbf{r}.$$

The Kelvin-Stokes theorem:

$$\oint_C \mathbf{F} \cdot d\mathbf{r} = \iint_S 
abla imes \mathbf{\hat{n}} \, dS.$$

The surface

S

is just the region in the plane

D

, with the unit normal

 $\hat{\mathbf{n}}$ 

defined (by convention) to have a positive z component in order to match the "positive orientation" definitions for both theorems.

The expression inside the integral becomes

[Image]

$$abla extbf{x} \cdot \hat{\mathbf{n}} = \left[ \left( rac{\partial 0}{\partial y} - rac{\partial M}{\partial z} 
ight) \mathbf{i} + \left( rac{\partial L}{\partial z} - rac{\partial 0}{\partial x} 
ight) \mathbf{j} + \left( rac{\partial M}{\partial x} - rac{\partial L}{\partial y} 
ight) \mathbf{k} 
ight] \cdot \mathbf{k} = \left( rac{\partial M}{\partial x} - rac{\partial L}{\partial y} 
ight).$$

Thus we get the right side of Green's theorem

$$\iint_S 
abla imes \mathbf{F} \cdot \mathbf{\hat{n}} \, dS = \iint_D \left( rac{\partial M}{\partial x} - rac{\partial L}{\partial y} 
ight) \, dA.$$

Green's theorem is also a straightforward result of the general Stokes' theorem using differential forms and exterior derivatives:

[Image]

$$\oint_C L \, dx + M \, dy = \oint_{\partial D} \omega = \int_D \, d\omega = \int_D \, rac{\partial L}{\partial y} \, dy \wedge \, dx + rac{\partial M}{\partial x} \, dx \wedge \, dy = \iint_D \left( rac{\partial M}{\partial x} - rac{\partial L}{\partial y} 
ight) \, dx \, dy.$$

## Relationship to the divergence theorem

[edit]

Considering only two-dimensional vector fields, Green's theorem is equivalent to the two-dimensional version of the divergence theorem:

$$\iint_D \left( 
abla \cdot \mathbf{F} 
ight) dA = \oint_C \mathbf{F} \cdot \hat{\mathbf{n}} \, ds,$$

where

$$\nabla \cdot \mathbf{F}$$

is the divergence on the two-dimensional vector field

[Image]

 $\mathbf{F}$ 

, and

 $\hat{\mathbf{n}}$ 

is the outward-pointing unit normal vector on the boundary.

To see this, consider the unit normal

 $\hat{\mathbf{n}}$ 

in the right side of the equation. Since in Green's theorem

$$d\mathbf{r} = (dx, dy)$$

is a vector pointing tangential along the curve, and the curve C is the positively oriented (i.e. anticlockwise) curve along the boundary, an outward normal would be a vector which points 90° to the right of this; one choice would be

[Image]

(dy, -dx)

. The length of this vector is

[Image]

 $\sqrt{dx^2+dy^2}=ds.$ 

So

 $(dy, -dx) = \mathbf{\hat{n}} \, ds.$ 

Start with the left side of Green's theorem:

$$\oint_C (L\,dx+M\,dy) = \oint_C (M,-L)\cdot (dy,-dx) = \oint_C (M,-L)\cdot \hat{f n}\,ds.$$

Applying the two-dimensional divergence theorem with

$$\mathbf{F} = (M, -L)$$

, we get the right side of Green's theorem:

$$\oint_C (M,-L) \cdot \hat{\mathbf{n}} \, ds = \iint_D \left( 
abla \cdot (M,-L) 
ight) \, dA = \iint_D \left( rac{\partial M}{\partial x} - rac{\partial L}{\partial y} 
ight) \, dA.$$

Green's theorem can be used to compute area by line integral. The area of a planar region

is given by

 $A = \iint_D dA.$ 

D

Choose

L

and

[Image]  $oldsymbol{M}$ 

such that

$$\frac{\partial M}{\partial x} - \frac{\partial L}{\partial y} = 1$$

, the area is given by

$$A = \oint_C (L\, dx + M\, dy).$$

Possible formulas for the area of

D

include

$$A=\oint_C x\,dy=-\oint_C y\,dx=rac{1}{2}\oint_C (-y\,dx+x\,dy).$$

It is named after George Green, who stated a similar result in an 1828 paper titled <u>An</u> <u>Essay on the Application of Mathematical Analysis to the Theories of Electricity and Magnetism</u>. In 1846, <u>Augustin-Louis Cauchy</u> published a paper stating Green's theorem as the penultimate sentence. This is in fact the first printed version of Green's theorem in the form appearing in modern textbooks. Green did not actually derive the form of "Green's theorem" which appears in this article; rather, he derived a form of the "divergence theorem", which appears on <u>pages 10–12</u> of his *Essay*.

In 1846, the form of "Green's theorem" which appears in this article was first published, without proof, in an article by <u>Augustin Cauchy</u>: A. Cauchy (1846) <u>"Sur les intégrales qui s'étendent à tous les points d'une courbe fermée"</u> (On integrals that extend over all of the points of a closed curve), *Comptes rendus*, **23**: 251-255. (The equation appears at the bottom of page 254, where (S) denotes the line integral of a function k along the curve k that encloses the area k.)

A proof of the theorem was finally provided in 1851 by <u>Bernhard Riemann</u> in his inaugural dissertation: Bernhard Riemann (1851) *Grundlagen für eine allgemeine Theorie der Functionen einer veränderlichen complexen Grösse* (Basis for a general theory of functions of a variable complex quantity), (Göttingen, (Germany): Adalbert Rente, 1867); see pages 8–9.

- <u>Planimeter</u> Tool for measuring area
- <u>Method of image charges</u> A method used in electrostatics that takes advantage of the uniqueness theorem (derived from Green's theorem)
- Shoelace formula A special case of Green's theorem for simple polygons
- <sup>1.</sup> <u>Riley, Kenneth F.</u>; Hobson, Michael P.; Bence, Stephen J. (2010). Mathematical methods for physics and engineering (3rd ed.). Cambridge: <u>Cambridge</u> <u>University Press</u>. <u>ISBN</u> 978-0-521-86153-3.
- 2. <u>Lipschutz, Seymour</u>; <u>Spiegel, Murray R.</u> (2009). Vector analysis and an introduction to tensor analysis. Schaum's outline series (2nd ed.). New York: <u>McGraw Hill Education</u>. <u>ISBN</u> 978-0-07-161545-7. <u>OCLC 244060713</u>.
- <sup>3.</sup> <u>Apostol, Tom</u> (1960). Mathematical Analysis. Reading, Massachusetts, U.S.A.: Addison-Wesley. OCLC 6699164.
- <sup>4.</sup> ^ <u>Stewart, James</u> (1999). Calculus. GWO A Gary W. Ostedt book (4. ed.). Pacific Grove, Calif. London: Brooks/Cole. ISBN 978-0-534-35949-2.
- 5. <u>Katz, Victor J.</u> (2009). "22.3.3: Complex Functions and Line Integrals". A history of mathematics: an introduction (PDF) (3. ed.). Boston, Mass. Munich: <u>Addison-Wesley</u>. pp. 801–5. <u>ISBN</u> 978-0-321-38700-4.
  - Marsden, Jerrold E.; Tromba, Anthony (2003). "The Integral Theorems of Vector

<u>Analysis"</u>. Vector calculus (5th ed.). New York: <u>W.H. Freeman</u>. pp. 518–608. <u>ISBN</u> 978-0-7167-4992-9.

• Green's Theorem on MathWorld