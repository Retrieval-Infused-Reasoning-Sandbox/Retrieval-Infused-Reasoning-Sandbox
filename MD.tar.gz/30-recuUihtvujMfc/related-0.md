**Antoine Henrot** 

# Problems for Eigenvalues of Elliptic Operators

#### **Antoine Henrot**

# Problems for Eigenvalues of Elliptic Operators

#### Author's address:

Antoine Henrot
Institut Elie Cartan Nancy
Nancy-Université – CNRS – INRIA
BP 239 54506 Vandoeuvre-les-Nancy Cedex
France
e-mail: henrot@iecn.u-nancy.fr

2000 Mathematical Subject Classification 35P05, 35P15, 35B37, 35J05, 35J10, 49J20, 49K20, 49Q10

A CIP catalogue record for this book is available from the Library of Congress, Washington D.C., USA

Bibliographic information published by Die Deutsche Bibliothek Die Deutsche Bibliothek lists this publication in the Deutsche Nationalbibliografie; detailed bibliographic data is available in the Internet at <a href="http://dnb.ddb.de">http://dnb.ddb.de</a>>.

#### ISBN 3-7643-7705-4 Birkhäuser Verlag, Basel – Boston – Berlin

This work is subject to copyright. All rights are reserved, whether the whole or part of the material is concerned, specifically the rights of translation, reprinting, re-use of illustrations, recitation, broadcasting, reproduction on microfilms or in other ways, and storage in data banks. For any kind of use permission of the copyright owner must be obtained.

© 2006 Birkhäuser Verlag, P.O. Box 133, CH-4010 Basel, Switzerland Part of Springer Science+Business Media Cover design: Birgit Blohmann, Zürich, Switzerland Printed on acid-free paper produced from chlorine-free pulp. TCF  $\infty$ 

Printed in Germany

ISBN 10: 3-7643-7705-4 e-ISBN: 3-7643-7706-2

ISBN 13: 978-3-7643-7705-2

9 8 7 6 5 4 3 2 1 www.birkhauser.ch

# **Contents**

|   | Preface |                                                                           | ix |
|---|---------|---------------------------------------------------------------------------|----|
| 1 |         | Eigenvalues<br>of<br>elliptic<br>operators                                | 1  |
|   | 1.1     | Notation<br>and<br>prerequisites                                          | 1  |
|   |         | 1.1.1<br>Notation<br>and<br>Sobolev<br>spaces                             | 1  |
|   |         | 1.1.2<br>Partial<br>differential<br>equations                             | 2  |
|   | 1.2     | Eigenvalues<br>and<br>eigenfunctions                                      | 4  |
|   |         | 1.2.1<br>Abstract<br>spectral<br>theory                                   | 4  |
|   |         | 1.2.2<br>Application<br>to<br>elliptic<br>operators                       | 5  |
|   |         | 1.2.3<br>First<br>Properties<br>of<br>eigenvalues                         | 8  |
|   |         | 1.2.4<br>Regularity<br>of<br>eigenfunctions                               | 9  |
|   |         | 1.2.5<br>Some<br>examples                                                 | 9  |
|   |         | 1.2.6<br>Fredholm<br>alternative                                          | 11 |
|   | 1.3     | Min-max<br>principles<br>and<br>applications                              | 12 |
|   |         | 1.3.1<br>Min-max<br>principles                                            | 12 |
|   |         | 1.3.2<br>Monotonicity                                                     | 13 |
|   |         | 1.3.3<br>Nodal<br>domains                                                 | 14 |
|   | 1.4     | Perforated<br>domains                                                     | 15 |
| 2 | Tools   |                                                                           | 17 |
|   | 2.1     | Schwarz<br>rearrangement                                                  | 17 |
|   | 2.2     | Steiner<br>symmetrization                                                 | 18 |
|   |         | 2.2.1<br>Definition                                                       | 18 |
|   |         | 2.2.2<br>Properties                                                       | 20 |
|   |         | 2.2.3<br>Continuous<br>Steiner<br>symmetrization                          | 21 |
|   | 2.3     | Continuity<br>of<br>eigenvalues                                           | 23 |
|   |         | 2.3.1<br>Introduction                                                     | 23 |
|   |         | 2.3.2<br>Continuity<br>with<br>variable<br>coefficients                   | 26 |
|   |         | 2.3.3<br>Continuity<br>with<br>variable<br>domains<br>(Dirichlet<br>case) | 28 |
|   |         | 2.3.4<br>The<br>case<br>of<br>Neumann<br>eigenvalues                      | 33 |
|   | 2.4     | Two<br>general<br>existence<br>theorems                                   | 35 |
|   | 2.5     | Derivatives<br>of<br>eigenvalues                                          | 37 |

vi

|   |      | 2.5.1     | Introduction                                                                    | 37 |
|---|------|-----------|---------------------------------------------------------------------------------|----|
|   |      | 2.5.2     | Derivative with respect to the domain                                           | 38 |
|   |      | 2.5.3     | Case of multiple eigenvalues                                                    | 41 |
|   |      | 2.5.4     | Derivative with respect to coefficients                                         | 43 |
| 3 | The  | first eig | genvalue of the Laplacian-Dirichlet                                             | 45 |
|   | 3.1  |           | uction                                                                          | 45 |
|   | 3.2  |           | aber-Krahn inequality                                                           | 45 |
|   | 3.3  |           | se of polygons                                                                  | 46 |
|   |      | 3.3.1     | An existence result                                                             | 47 |
|   |      | 3.3.2     | The cases $N = 3, 4 \dots \dots \dots \dots \dots$                              | 50 |
|   |      | 3.3.3     | A challenging open problem                                                      | 51 |
|   | 3.4  | Domai     | ns in a box                                                                     | 52 |
|   | 3.5  | Multi-o   | connected domains                                                               | 55 |
| 4 | The  | second    | eigenvalue of the Laplacian-Dirichlet                                           | 61 |
|   | 4.1  |           | izing $\lambda_2$                                                               | 61 |
|   |      | 4.1.1     | The Theorem of Krahn-Szegö                                                      | 61 |
|   |      | 4.1.2     | Case of a connectedness constraint                                              | 63 |
|   | 4.2  | A conv    | vexity constraint                                                               | 63 |
|   |      | 4.2.1     | Optimality conditions                                                           | 64 |
|   |      | 4.2.2     | Geometric properties of the optimal domain                                      | 67 |
|   |      | 4.2.3     | Another regularity result                                                       | 71 |
| 5 | The  |           | Dirichlet eigenvalues                                                           | 73 |
|   | 5.1  | Introdu   | uction                                                                          | 73 |
|   | 5.2  |           | ctedness of minimizers                                                          | 74 |
|   | 5.3  |           | nce of a minimizer for $\lambda_3$                                              | 76 |
|   |      | 5.3.1     | A concentration-compactness result                                              | 76 |
|   |      | 5.3.2     | Existence of a minimizer                                                        | 77 |
|   | 5.4  | Case of   | f higher eigenvalues                                                            | 80 |
| 6 | Func |           | f Dirichlet eigenvalues                                                         | 85 |
|   | 6.1  |           | uction                                                                          | 85 |
|   | 6.2  | Ratio o   | of eigenvalues                                                                  | 86 |
|   |      | 6.2.1     | The Ashbaugh-Benguria Theorem                                                   | 86 |
|   |      | 6.2.2     | Some other ratios                                                               | 90 |
|   |      | 6.2.3     | A collection of open problems                                                   | 92 |
|   | 6.3  | Sums of   | of eigenvalues                                                                  | 93 |
|   |      | 6.3.1     | Sums of eigenvalues                                                             | 93 |
|   |      | 6.3.2     | Sums of inverses                                                                | 94 |
|   | 6.4  |           | al functions of $\lambda_1$ and $\lambda_2$                                     | 95 |
|   |      | 6.4.1     | Description of the set $\mathcal{E} = (\lambda_1, \lambda_2) \dots \dots \dots$ | 95 |
|   |      | 6.4.2     | Existence of minimizers                                                         | 98 |

Contents vii

| 7 | Other |                              | boundary<br>conditions<br>for<br>the<br>Laplacian                                     | 101 |
|---|-------|------------------------------|---------------------------------------------------------------------------------------|-----|
|   | 7.1   | Neumann                      | boundary<br>condition                                                                 | 101 |
|   |       | 7.1.1                        | Introduction                                                                          | 101 |
|   |       | 7.1.2                        | Maximization<br>of<br>the<br>second<br>Neumann<br>eigenvalue                          | 102 |
|   |       | 7.1.3                        | Some<br>other<br>problems                                                             | 104 |
|   | 7.2   | Robin                        | boundary<br>condition                                                                 | 106 |
|   |       | 7.2.1                        | Introduction                                                                          | 106 |
|   |       | 7.2.2                        | The<br>Bossel-Daners<br>Theorem                                                       | 107 |
|   |       | 7.2.3                        | Optimal<br>insulation<br>of<br>conductors                                             | 110 |
|   | 7.3   | Stekloff                     | eigenvalue<br>problem                                                                 | 113 |
| 8 |       | Eigenvalues                  | of<br>Schr¨odinger<br>operators                                                       | 117 |
|   | 8.1   |                              | Introduction                                                                          | 117 |
|   |       | 8.1.1                        | Notation                                                                              | 117 |
|   |       | 8.1.2                        | A<br>general<br>existence<br>result                                                   | 119 |
|   | 8.2   |                              | Maximization<br>or<br>minimization<br>of<br>the<br>first<br>eigenvalue                | 119 |
|   |       | 8.2.1                        | Introduction                                                                          | 119 |
|   |       | 8.2.2                        | The<br>maximization<br>problem                                                        | 119 |
|   |       | 8.2.3                        | The<br>minimization<br>problem                                                        | 123 |
|   | 8.3   |                              | Maximization<br>or<br>minimization<br>of<br>other<br>eigenvalues                      | 125 |
|   | 8.4   |                              | Maximization<br>or<br>minimization<br>of<br>the<br>fundamental<br>gap<br>λ<br>2 − λ   | 127 |
|   |       | 8.4.1                        | 1<br>Introduction                                                                     | 127 |
|   |       | 8.4.2                        | Single-well<br>potentials                                                             | 127 |
|   |       | 8.4.3                        | Minimization<br>or<br>maximization<br>with<br>an<br>L∞ constraint                     | 131 |
|   |       | 8.4.4                        | Lp constraint<br>Minimization<br>or<br>maximization<br>with<br>an                     | 134 |
|   | 8.5   | Maximization<br>of<br>ratios | 136                                                                                   |     |
|   |       | 8.5.1                        | Introduction                                                                          | 136 |
|   |       | 8.5.2                        | Maximization<br>of<br>λ<br>(V<br>)/λ<br>(V<br>)<br>in<br>one<br>dimension             | 136 |
|   |       | 8.5.3                        | 2<br>1<br>Maximization<br>of<br>λn(V<br>)/λ<br>(V<br>)<br>in<br>one<br>dimension<br>1 | 137 |
| 9 |       |                              | Non-homogeneous<br>strings<br>and<br>membranes                                        | 141 |
|   | 9.1   |                              | Introduction                                                                          | 141 |
|   | 9.2   | Existence                    | results                                                                               | 143 |
|   |       | 9.2.1                        | A<br>first<br>general<br>existence<br>result                                          | 143 |
|   |       | 9.2.2                        | A<br>more<br>precise<br>existence<br>result                                           | 143 |
|   |       | 9.2.3                        | Nonlinear<br>constraint                                                               | 146 |
|   | 9.3   | Minimizing                   | or<br>maximizing<br>λk(ρ)<br>in<br>dimension<br>1                                     | 148 |
|   |       | 9.3.1                        | Minimizing<br>λk(ρ)                                                                   | 149 |
|   |       | 9.3.2                        | Maximizing<br>λk(ρ)                                                                   | 150 |
|   | 9.4   | Minimizing                   | or<br>maximizing<br>λk(ρ)<br>in<br>higher<br>dimension                                | 152 |
|   |       | 9.4.1                        | Case<br>of<br>a<br>ball                                                               | 152 |
|   |       | 9.4.2                        | General<br>case                                                                       | 153 |
|   |       | 9.4.3                        | Some<br>extensions                                                                    | 155 |

viii Contents

| 10 | Optimal | conductivity                                                                                   | 159 |
|----|---------|------------------------------------------------------------------------------------------------|-----|
|    | 10.1    | Introduction                                                                                   | 159 |
|    | 10.2    | The<br>one-dimensional<br>case                                                                 | 160 |
|    |         | 10.2.1<br>A<br>general<br>existence<br>result                                                  | 160 |
|    |         | 10.2.2<br>Minimization<br>or<br>maximization<br>of<br>λk(σ)                                    | 161 |
|    |         | 10.2.3<br>Case<br>of<br>Neumann<br>boundary<br>conditions                                      | 163 |
|    | 10.3    | The<br>general<br>case                                                                         | 165 |
|    |         | 10.3.1<br>The<br>maximization<br>problem                                                       | 165 |
|    |         | 10.3.2<br>The<br>minimization<br>problem                                                       | 168 |
| 11 | The     | bi-Laplacian<br>operator                                                                       | 169 |
|    | 11.1    | Introduction                                                                                   | 169 |
|    | 11.2    | The<br>clamped<br>plate                                                                        | 169 |
|    |         | 11.2.1<br>History                                                                              | 169 |
|    |         | 11.2.2<br>Notation<br>and<br>statement<br>of<br>the<br>theorem                                 | 170 |
|    |         | 11.2.3<br>Proof<br>of<br>the<br>Rayleigh<br>conjecture<br>in<br>dimension<br>N<br>=<br>2,<br>3 | 171 |
|    | 11.3    | Buckling<br>of<br>a<br>plate                                                                   | 174 |
|    |         | 11.3.1<br>Introduction                                                                         | 174 |
|    |         | 11.3.2<br>The<br>case<br>of<br>a<br>positive<br>eigenfunction                                  | 175 |
|    |         | 11.3.3<br>An<br>existence<br>result                                                            | 177 |
|    |         | 11.3.4<br>The<br>last<br>step<br>in<br>the<br>proof                                            | 178 |
|    | 11.4    | Some<br>other<br>problems                                                                      | 181 |
|    |         | 11.4.1<br>Non-homogeneous<br>rod<br>and<br>plate                                               | 181 |
|    |         | 11.4.2<br>The<br>optimal<br>shape<br>of<br>a<br>column                                         | 183 |
|    |         | References                                                                                     | 187 |
|    | Index   |                                                                                                | 199 |

# **Preface**

Problems linking the shape of a domain or the coefficients of an elliptic operator to the sequence of its eigenvalues are among the most fascinating of mathematical analysis. One of the reasons which make them so attractive is that they involve different fields of mathematics: spectral theory, partial differential equations, geometry, calculus of variations . . . . Moreover, they are very simple to state and generally hard to solve! In particular, one can find in the next pages more than 30 open problems!

In this book, we focus on extremal problems. For instance, we look for a domain which minimizes or maximizes a given eigenvalue of the Laplace operator with various boundary conditions and various geometric constraints. We also consider the case of functions of eigenvalues. We investigate similar questions for other elliptic operators, like Schr¨odinger, non-homogeneous membranes or composites.

The targeted audience is mainly pure and applied mathematicians, more particularly interested in partial differential equations, calculus of variations, differential geometry, spectral theory. More generally, people interested in properties of eigenvalues in other fields such as acoustics, theoretical physics, quantum mechanics, solid mechanics, could find here some answers to natural questions. For that purpose, I choose to recall basic facts and tools in the two first chapters (with only a few proofs). In chapters 3, 4 and 5, we present known results and open questions for the minimization problem of a given eigenvalue λk(Ω) of the Laplace operator with Dirichlet boundary conditions, where the unknown is here the domain Ω itself. In chapter 6, we investigate various functions of the Dirichlet eigenvalues, while chapter 7 is devoted to eigenvalues of the Laplace operator with other boundary conditions. In chapter 8, we consider the eigenvalues of Schr¨odinger operators: therefore, the unknown is no longer the shape of the domain but the potential V . Chapter 9 is devoted to non-homogeneous membranes and chapter 10 to more general elliptic operators in divergence form. At last, in chapter 11, we are interested in the bi-Laplace operator.

Of course no book can completely cover such a huge field of research. In making personal choices for inclusion of material, I tried to give useful complementary references, in the process certainly neglecting some relevant works. I would be grateful to hear from readers about important missing citations.

x Preface

I would like to thank Benoit Perthame who suggested in September 2004 that I write this book. Many people helped me with the enterprise, answering my questions and queries or suggesting interesting problems: Mark Ashbaugh, Friedemann Brock, Dorin Bucur, Giuseppe Buttazzo, Steve Cox, Pedro Freitas, Antonio Greco, Evans Harrell, Francois Murat, Edouard Oudet, Gerard Philippin, Michel Pierre, Marius Tucsnak. I am pleased to thank them here.

Nancy, March 2006 Antoine Henrot

# **Chapter 1**

# **Eigenvalues of elliptic operators**

#### **1.1 Notation and prerequisites**

In this section, we recall the basic results of the theory of elliptic partial differential equations. The prototype of elliptic operator is the Laplacian, but the results that we state here are also valid for more general (linear) elliptic operators. For the basic facts we recall here, we refer to any textbook on partial differential equations and operator theory. For example, [36], [58], [75], [83] are good standard references.

#### **1.1.1 Notation and Sobolev spaces**

Let Ω be a bounded open set in R<sup>N</sup> . We denote by L2(Ω) the Hilbert space of square summable functions defined on Ω and by H1(Ω) the Sobolev space of functions in L2(Ω) whose partial derivatives (in the sense of distributions) are in L2(Ω):

$$H^1(\Omega) := \{ u \in L^2(\Omega) \text{ such that } \frac{\partial u}{\partial x_i} \in L^2(\Omega), \ i = 1, 2, \dots, N \}.$$

This is a Hilbert space when it is endowed with the scalar product

$$(u,v)_{H^1} := \int_{\Omega} u(x)v(x) dx + \int_{\Omega} \nabla u(x) \cdot \nabla v(x) dx$$

and the corresponding norm:

$$||u||_{H^1} := \left(\int_{\Omega} u(x)^2 dx + \int_{\Omega} |\nabla u(x)|^2 dx\right)^{1/2}.$$

In the case of Dirichlet boundary conditions, we will use the subspace  $H_0^1(\Omega)$  which is defined as the closure of  $C^{\infty}$  functions compactly supported in  $\Omega$  (functions in  $C_0^{\infty}(\Omega)$ ) for the norm  $\| \|_{H^1}$ . It is also a Hilbert space. At last,  $H^{-1}(\Omega)$  denotes the dual space of  $H_0^1(\Omega)$ . For some non-linear problems, for example when we are interested in the p-Laplace operator, it is more convenient to work with the spaces  $L^p, p \geq 1$  instead of  $L^2$ . In this case, the Sobolev spaces, defined exactly in the same way, are denoted by  $W^{1,p}(\Omega)$  and  $W_0^{1,p}(\Omega)$  respectively. These are Banach spaces.

When  $\Omega$  is bounded (or bounded in one direction), we have the Poincaré inequality:

$$\exists C = C(\Omega) \text{ such that } \forall u \in H_0^1(\Omega), \ \int_{\Omega} u(x)^2 \, dx \le C \ \int_{\Omega} |\nabla u(x)|^2 \, dx \,. \tag{1.1}$$

Actually the constant C which appears in (1.1) is closely related to the eigenvalues of the Laplacian since we will see later (cf (1.36)) that the best possible constant C is nothing other than  $1/\lambda_1(\Omega)$  where  $\lambda_1(\Omega)$  is the first eigenvalue of the Laplacian with Dirichlet boundary conditions.

By definition,  $H_0^1(\Omega)$  and  $H^1(\Omega)$  are continuously embedded in  $L^2(\Omega)$ , but we will need later a compact embedding. This is the purpose of the following theorem.

#### Theorem 1.1.1 (Rellich).

- For any bounded open set  $\Omega$ , the embedding  $H_0^1(\Omega) \hookrightarrow L^2(\Omega)$  is compact.
- If  $\Omega$  is a bounded open set with Lipschitz boundary, the embedding  $H^1(\Omega) \hookrightarrow L^2(\Omega)$  is compact.

**Remark 1.1.2.** We can weaken the assumption of Lipschitz boundary but not too much, see e.g. the book [148] for more details.

#### 1.1.2 Partial differential equations

#### Elliptic operator

Let  $a_{ij}(x)$ , i, j = 1, ..., N be bounded functions defined on  $\Omega$  and satisfying the usual ellipticity assumption:

$$\exists \alpha > 0, \text{ such that } \forall \xi = (\xi_1, \xi_2, \dots, \xi_N) \in \mathbb{R}^N, \ \forall x \in \Omega$$
$$\sum_{i,j=1}^N a_{ij}(x)\xi_i\xi_j \ge \alpha |\xi|^2$$
(1.2)

where  $|\xi| = (\xi_1^2 + \xi_2^2 + \dots + \xi_N^2)^{1/2}$  denotes the euclidean norm of the vector  $\xi$ . We will also assume a symmetry assumption for the  $a_{ij}$  namely:

$$\forall x \in \Omega, \forall i, j \quad a_{ij}(x) = a_{ji}(x) . \tag{1.3}$$

Let  $a_0(x)$  be a bounded function defined on  $\Omega$ . We introduce the linear elliptic operator L, defined on  $H^1(\Omega)$  by:

$$Lu := -\sum_{i,j=1}^{N} \frac{\partial}{\partial x_i} \left( a_{ij}(x) \frac{\partial u}{\partial x_j} \right) + a_0(x)u$$
 (1.4)

(derivatives are to be understood in the sense of distributions). The prototype of elliptic operator is the Laplacian:

$$-\Delta u := -\sum_{i=1}^{N} \frac{\partial^2 u}{\partial x_i^2} \tag{1.5}$$

which will be considered in the main part of this book (chapters 3 to 7). In chapter 8, we consider the Schrödinger operator  $L_V u = -\Delta u + V(x)u$  where V (the potential) is a bounded function, while chapters 9 and 10 deal with more general elliptic operators. In that case, we will keep the notation L when we want to consider general operators given by (1.4). At last, in chapter 11, we consider operators of fourth order.

Remark 1.1.3. Let us remark that, since we are only interested in eigenvalue problems, we do not put any sign condition on the function  $a_0(x)$  which appears in (1.4). Indeed, since  $a_0(x)$  is bounded, we can always replace the operator L by  $L + (\|a_0\|_{\infty} + 1)Id$ , i.e. replace the function  $a_0(x)$  by  $a_0(x) + \|a_0\|_{\infty} + 1$  if we need a positive function in the term of order 0 of the operator L. For the eigenvalues, that would just induce a translation of  $\|a_0\|_{\infty} + 1$  to the right.

#### Dirichlet boundary condition

Let f be a function in  $L^2(\Omega)$ . When we call u a solution of the Dirichlet problem

$$Lu = f \text{ in } \Omega, 
 u = 0 \text{ on } \partial\Omega.$$
(1.6)

we actually mean that u is the unique solution of the variational problem

$$\begin{cases} u \in H_0^1(\Omega) \text{ and } \forall v \in H_0^1(\Omega), \\ \sum_{i,j=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial u}{\partial x_i} \frac{\partial v}{\partial x_j} dx + \int_{\Omega} a_0(x) u(x) v(x) dx = \int_{\Omega} f(x) v(x) dx \end{cases}$$
(1.7)

Existence and uniqueness of a solution for problem (1.7) follows from the Lax-Milgram Theorem, the ellipticity assumption (1.2) and the Poincaré inequality (1.1). Note that, according to Remark 1.1.3, we can restrict ourselves to the case  $a_0(x) \geq 0$ . In the sequel, we will denote by  $A_L^D$  (or  $A_L^D(\Omega)$  when we want to emphasize the dependence on the domain  $\Omega$ ) the linear operator defined by:

$$\begin{array}{cccc} A_L^D: L^2(\Omega) & \to & H_0^1(\Omega) \subset L^2(\Omega), \\ f & \mapsto & u \text{ solution of } (1.7). \end{array} \tag{1.8}$$

#### Neumann boundary condition

In the same way, if f is a function in  $L^2(\Omega)$ , we will also consider u a solution of the Neumann problem

$$Lu = f \text{ in } \Omega,$$

$$\sum_{i,j=1}^{N} a_{ij} \frac{\partial u}{\partial x_{i}} n_{i} = 0 \text{ on } \partial\Omega$$
(1.9)

(where n stands for the exterior unit normal vector to  $\partial\Omega$  and  $n_i$  is its ith coordinate). For example, when  $L = -\Delta$ , the boundary condition reads (formally)

$$\frac{\partial u}{\partial n} = 0$$
.

It means that u is the unique solution in  $H^1(\Omega)$  of the variational problem

$$\begin{cases}
 u \in H^1(\Omega) \text{ and } \forall v \in H^1(\Omega), \\
 \sum_{i,j=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial u}{\partial x_i} \frac{\partial v}{\partial x_j} dx + \int_{\Omega} a_0(x) u(x) v(x) dx = \int_{\Omega} f(x) v(x) dx.
\end{cases} (1.10)$$

Existence and uniqueness of a solution for problem (1.10) follows from the Lax-Milgram Theorem, the ellipticity assumption (1.2) and the fact that we can assume that  $a_0(x) \geq 1$  (according to Remark 1.1.3). In the sequel, we will denote by  $A_L^N$  the linear operator defined by:

$$A_L^N: L^2(\Omega) \to H^1(\Omega) \subset L^2(\Omega),$$
  
 $f \mapsto u \text{ solution of } (1.10).$  (1.11)

**Remark 1.1.4.** We will also consider later, for example in chapter 7, other kinds of boundary conditions like Robin or Stekloff boundary conditions.

#### 1.2 Eigenvalues and eigenfunctions

#### 1.2.1 Abstract spectral theory

Let us now give the abstract theorem which provides the existence of a sequence of eigenvalues and eigenfunctions. Let H be a Hilbert space endowed with a scalar product (.,.) and recall that an operator T is a linear continuous map from H into H. We say that:

- T is positive if,  $\forall x \in H, (Tx, x) \ge 0$ ,
- T is self-adjoint, if  $\forall x, y \in H$ , (Tx, y) = (x, Ty),
- T is compact, if the image of any bounded set is relatively compact (i.e. has a compact closure) in H.

**Theorem 1.2.1.** Let H be a separable Hilbert space of infinite dimension and T a self-adjoint, compact and positive operator. Then, there exists a sequence of real positive eigenvalues  $(\nu_n)$ ,  $n \ge 1$  converging to 0 and a sequence of eigenvectors  $(x_n)$ ,  $n \ge 1$  defining a Hilbert basis of H such that  $\forall n$ ,  $T x_n = \nu_n x_n$ .

Of course, this theorem can be seen as a generalization to Hilbert spaces of the classical result in finite dimension for symmetric or normal matrices (existence of real eigenvalues and of an orthonormal basis of eigenvectors).

#### 1.2.2 Application to elliptic operators

#### Dirichlet boundary condition

We apply Theorem 1.2.1 to  $H = L^2(\Omega)$  and the operator  $A_L^D$  defined in (1.8).

•  $A_L^D$  is positive: let  $f \in L^2(\Omega)$  and  $u = A_L^D f$  be the solution of (1.7). We get

$$(f, A_L^D f) = \int_{\omega} f(x)u(x) dx = \sum_{i, i=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial u}{\partial x_i} \frac{\partial u}{\partial x_j} dx + \int_{\Omega} a_0(x)u^2(x) dx.$$

Now, we recall that  $a_0(x)$  can be taken as a positive function and then the ellipticity condition (1.2) yields the desired result. Moreover, we see that  $(f, A_L^D f) > 0$  as soon as  $f \neq 0$  (strict positivity).

•  $A_L^D$  is self-adjoint: let  $f,g\in L^2(\Omega)$  and  $u=A_L^D\,f,\,v=A_L^D\,g.$  We have:

$$(f, A_L^D g) = \int_{\omega} f(x)v(x)dx = \sum_{i,j=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial u}{\partial x_i} \frac{\partial v}{\partial x_j} dx + \int_{\Omega} a_0(x)u(x)v(x)dx.$$
(1.12)

Now, according to the symmetry assumption (1.3) and the equation (1.7) satisfied by v, the right-hand side in (1.12) is equal to  $\int_{\Omega} u(x)g(x) dx = (A_L^D f, g)$ .

As a consequence of Theorem 1.2.1, there exists  $(u_n)$  a Hilbert basis of  $L^2(\Omega)$  and a sequence  $\nu_n \geq 0$ , converging to 0, such that  $A_L^D u_n = \nu_n u_n$ . Actually, the  $\nu_n$  are positive, since the strict positivity of  $A_L^D$  yields  $\nu_n ||u_n||_{L^2} = (u_n, A_L^D u_n) > 0$ .

Coming back to (1.7), we see that  $u_n$  satisfies,  $\forall v \in H_0^1(\Omega)$ :

$$\nu_n \left( \sum_{i,j=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial u_n}{\partial x_i} \frac{\partial v}{\partial x_j} dx + \int_{\Omega} a_0(x) u_n(x) v(x) dx \right) = \int_{\Omega} u_n(x) v(x) dx$$

which means

$$L u_n = \frac{1}{\nu_n} u_n .$$

Setting  $\lambda_n = \frac{1}{\nu_n}$ , we have proved:

**Theorem 1.2.2.** Let  $\Omega$  be a bounded open set in  $\mathbb{R}^N$ . There exists a sequence of positive eigenvalues (going to  $+\infty$ ) and a sequence of corresponding eigenfunctions (defining a Hilbert basis of  $L^2(\Omega)$ ) that we will denote respectively  $0 < \lambda_1^D(L,\Omega) \le \lambda_2^D(L,\Omega) \le \lambda_3^D(L,\Omega) \le \dots$  and  $u_1^D, u_2^D, u_3^D, \dots$  satisfying:

$$\begin{cases} Lu_n^D = \lambda_n^D(L,\Omega) u_n^D & \text{in } \Omega, \\ u_n^D = 0 & \text{on } \partial\Omega. \end{cases}$$
 (1.13)

Remark 1.2.3. For uniformly elliptic operators (those satisfying (1.2)), the compactness of the operator  $A_L^D$  follows simply from Rellich's Theorem 1.1.1. In some other cases, particularly for degenerate operators, one generally needs to use weighted Sobolev spaces. For example, if the operator is  $Lu := -\text{div}(\sigma \nabla u)$  with  $\sigma \geq 0$  allowed to vanish into  $\Omega$ , one needs to introduce the space  $H_{\sigma}^1(\Omega)$  (endowed with the norm  $\|u\|^2 = \int_{\Omega} u^2 dx + \int_{\Omega} \sigma |\nabla u|^2 dx$ ). Then, it happens that the previous theory works as soon as the function  $1/\sigma$  belongs to some  $L^p(\Omega)$  space with p > N/2. We refer e.g. to [155] or [205]. At last, there is an interesting alternative to prove compactness. Thanks to the Green function, one can usually write the operator  $A_L^D$  (or  $A_L^N$ ) with an integral representation. Then, it suffices to prove that it is a Hilbert-Schmidt operator. We will see an example of this strategy in section 10.2.3.

When  $L = -\Delta$  is the Laplacian, we will simply denote the eigenvalues by  $\lambda_n(\Omega)$  (or  $\lambda_n$  when no confusion is possible) and the corresponding eigenfunctions by  $u_n$ .

Since the eigenfunctions are defined up to a constant, we decide to normalize the eigenfunctions by the condition

$$\int_{\Omega} u_n(x)^2 \, dx = 1 \; . \tag{1.14}$$

Of course, it can occur that some eigenvalues are multiple (especially when the domain has symmetries). In this case, the eigenvalues are counted with their multiplicity.

Remark 1.2.4. When  $\Omega$  is non-connected, for example if  $\Omega$  has two connected components  $\Omega = \Omega_1 \cup \Omega_2$ , we obtain the eigenvalues of  $\Omega$  by collecting and reordering the eigenvalues of each connected components

$$\begin{array}{rcl} \lambda_{1}^{D}(L,\Omega) & = & \min(\lambda_{1}^{D}(L,\Omega_{1}),\lambda_{1}^{D}(L,\Omega_{2})), \\ \lambda_{2}^{D}(L,\Omega) & = & \min(\max(\lambda_{1}^{D}(L,\Omega_{1}),\lambda_{1}^{D}(L,\Omega_{2})),\lambda_{2}^{D}(L,\Omega_{1}),\lambda_{2}^{D}(L,\Omega_{2})), \\ & \vdots & & \vdots \end{array}$$

More generally, we can always choose every eigenfunction of a disconnected open set  $\Omega$  to vanish on all but one of the connected components of  $\Omega$ . In particular, when the two connected components are the same, we will have  $\lambda_1^D(L,\Omega) = \lambda_2^D(L,\Omega)$ , i.e.  $\lambda_1$  is a double eigenvalue.

That cannot happen when  $\Omega$  is connected:

**Theorem 1.2.5.** Let us assume that  $\Omega$  is a regular connected open set. Then the first eigenvalue  $\lambda_1^D(L,\Omega)$  is simple and the first eigenfunction  $u_1^D$  has a constant sign on  $\Omega$ . Usually, we choose it to be positive on  $\Omega$ .

Actually, this theorem is a consequence of the Krein-Rutman Theorem which is an abstract result that we recall here (see [181] for a proof).

**Theorem 1.2.6 (Krein-Rutman).** Let E be a Banach space and C be a closed convex cone in E with vertex at O, non-empty interior Int(C) and satisfying  $C \cap (-C) = \{O\}$ . Let T be a compact operator in E which satisfies  $T(C \setminus \{O\}) \subset Int(C)$ ; then the greatest eigenvalue of T is simple, and the corresponding eigenvector is in Int(C) (or in -Int(C)).

To prove Theorem 1.2.5, we apply the Krein-Rutman Theorem with  $E = C^0(\overline{\Omega})$ ,  $T = A_L^D$  and  $C = \{v \in C^0(\overline{\Omega}), \text{ such that } v(x) \geq 0.\}$ . Then, the assumption  $T(C \setminus \{O\}) \subset Int(C)$  comes from the strong maximum principle. The fact that T can be defined as an operator from E to E and the fact that it is compact comes from classical regularity results (if the right-hand side of f is continuous, the solution u of (1.6) is also continuous and even Hölderian (De Giorgi-Stampacchia Theorem, see [36], [94]).

**Remark 1.2.7.** We will see two other proofs of the non-negativity of the first eigenfunction (and simplicity of the first eigenvalue) in section 1.3.3. In particular, no regularity assumptions are actually needed for this result.

#### Neumann boundary condition

In the same way, when  $\Omega$  is a bounded Lipschitzian open set in  $\mathbb{R}^N$ , we can prove the following theorem (the Lipschitz regularity of  $\Omega$  is necessary to have the compact embedding  $H^1(\Omega) \hookrightarrow L^2(\Omega)$ ):

**Theorem 1.2.8.** Let  $\Omega$  be a bounded open Lipschitzian set in  $\mathbb{R}^N$ . There exists a sequence of non-negative eigenvalues (going to  $+\infty$ ) and a sequence of corresponding eigenfunctions (defining a Hilbert basis of  $L^2(\Omega)$ ) that we will denote respectively  $0 \le \mu_1^N(L,\Omega) \le \mu_2^N(L,\Omega) \le \mu_3^N(L,\Omega) \le \cdots$  and  $u_1^N, u_2^N, u_3^N, \ldots$  satisfying:

$$\begin{cases}
Lu_n^N = \mu_n^N(L,\Omega) u_n^N & \text{in } \Omega, \\
\frac{\partial u_n^N}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(1.16)

When  $L = -\Delta$  is the Laplacian, we will simply denote the eigenvalues by  $\mu_n(\Omega)$  (or  $\mu_n$  when no confusion is possible) and the corresponding eigenfunctions by  $u_n$ .

We observe that, for the Laplacian and, more generally in the case  $a_0(x) = 0$ , the first eigenvalue is always  $\mu_1 = 0$  and a corresponding eigenfunction is a non-zero constant (on a connected component of  $\Omega$ ).

In the case of Neumann boundary condition, we also decide to normalize the eigenfunctions by the condition

$$\int_{\Omega} u_n(x)^2 dx = 1. (1.17)$$

At last, when  $\Omega$  is non-connected, we have the same property as described in Remark 1.2.4.

#### 1.2.3 First Properties of eigenvalues

In this section, we only consider the eigenvalues of the Laplacian operator. It is well known that this operator is invariant for translations and rotations. More precisely, let us denote by  $\tau_{x_0}$  the translation of vector  $x_0$ :  $\tau_{x_0}(x) = x + x_0$ . If v is a function defined on a set  $\Omega$ , we define the function  $\tau_{x_0}v$  on  $\tau_{x_0}(\Omega)$  by the formula  $\tau_{x_0}v(x) := v(x - x_0)$ . Then, it is clear that

$$\tau_{x_0} \circ \Delta = \Delta \circ \tau_{x_0}$$

from which we can deduce

$$\lambda_n(\tau_{x_0}(\Omega)) = \lambda_n(\Omega) . \tag{1.18}$$

In the same way, denoting by R any isometry, we have

$$\lambda_n(R(\Omega)) = \lambda_n(\Omega) . \tag{1.19}$$

Let us also look at the effect of homothety. Let k > 0 and  $H_k$  be a homothety of origin O and ratio k:  $H_k(x) = kx$ . If v is a function defined on  $\Omega$ , we define the function  $H_k v$  on  $H_k(\Omega)$  by the formula  $H_k v(x) := v(x/k)$ . Since  $H_k \circ \Delta = k^2 \Delta \circ H_k$ , we deduce

$$\lambda_n(H_k(\Omega)) = \frac{\lambda_n(\Omega)}{k^2} \,. \tag{1.20}$$

An important consequence of (1.20) is the following. In the sequel, we will often consider minimization problems with a volume constraint, such as

$$\min\{\lambda_n(\Omega), |\Omega| = c\}. \tag{1.21}$$

Then, it could be convenient to replace Problem (1.21) by:

$$\min |\Omega|^{2/N} \lambda_n(\Omega) . \tag{1.22}$$

**Proposition 1.2.9.** Problems (1.21) and (1.22) are equivalent.

By equivalent, we just mean that there exists a bijective correspondence between solutions of these two problems. Actually, since the functional  $\Omega \mapsto |\Omega|^{2/N} \lambda_n(\Omega)$  is invariant by homothety (thanks to (1.20)), the correspondence is simply:

- every solution of (1.21) is a solution of (1.22),
- if  $\Omega$  is a solution of (1.22) with volume c', then  $H_k(\Omega)$ , with  $k = (c/c')^{1/N}$ , is a solution of (1.21).

Of course, the result of Proposition 1.2.9 is also true when we add most of the supplementary geometric constraints. For functions of eigenvalues, it will obviously depend on the homogeneity of the function.

#### 1.2.4 Regularity of eigenfunctions

#### Interior regularity

Due to the hypo-ellipticity of the Laplacian, the eigenfunctions of the Laplacian are known to be analytic inside the domain, see e.g. [75], [58]. For more general operators, it depends on the regularity of the coefficients of the operator L. A good reference to handle such cases is [94].

#### Regularity up to the boundary

To have some regularity up to the boundary, we need to assume enough regularity of the domain. Standard results are the following, see [94] or [96]:

**Theorem 1.2.10 (Sobolev regularity).** Let us assume that  $\Omega$  is  $C^{1,1}$  or convex and the coefficients  $a_{ij}$  are  $C^0$  and  $a_0 \in L^{\infty}$ . Then each eigenfunction u of (1.13) belongs to the Sobolev space  $H^2(\Omega)$ .

Remark 1.2.11. One can also get  $L^p$  regularity results. For example, using Theorem 9.15 in [94] together with a bootstrap argument, one can prove that the eigenfunctions are in  $W^{2,p}(\Omega)$  with p > N. In particular, thanks to Sobolev embedding, the eigenfunctions are in  $C^1(\overline{\Omega})$  as soon as the boundary of  $\Omega$  is  $C^{1,1}$ .

**Theorem 1.2.12 (Hölderian regularity).** Let us assume that  $\Omega$  is  $C^{2,\alpha}$  for some  $\alpha > 0$  and the coefficients  $a_{ij}$  are  $C^{1,\alpha}$  and  $a_0$  in  $C^{0,\alpha}$ . Then each eigenfunction u of (1.13) belongs to  $C^{2,\alpha}(\overline{\Omega})$ .

#### 1.2.5 Some examples

In this section, we are interested in the eigenvalues of the Laplacian for some very simple domains. In one dimension, one can also choose explicit eigenvalues of some specific Sturm-Liouville operators. This leads to the huge theory of special functions; we refer e.g. to [3], [139] for examples of such functions.

#### Rectangles

In the 1-D case, i.e. for an interval like  $\Omega = (0, L)$ , it is very easy to solve at hand the differential equation

$$\begin{cases} -u'' = \lambda u, & x \in (0, L), \\ u(0) = u(L) = 0, \end{cases}$$
 (1.23)

and the only non-trivial solutions are

$$\lambda_n = \frac{n^2 \pi^2}{L^2}, \quad u_n(x) = \sin\left(\frac{n\pi x}{L}\right), \quad n \ge 1. \tag{1.24}$$

Now, for rectangles, using the classical trick of separation of variables, we prove

**Proposition 1.2.13.** Let  $\Omega = (0, L) \times (0, l)$  be a plane rectangle; then its eigenvalues and eigenfunctions for the Laplacian with Dirichlet boundary conditions are:

$$\lambda_{m,n} = \pi^2 \left( \frac{m^2}{L^2} + \frac{n^2}{l^2} \right)$$

$$u_{m,n}(x,y) = \frac{2}{\sqrt{Ll}} \sin\left(\frac{m\pi x}{L}\right) \sin\left(\frac{n\pi y}{l}\right)$$

$$m, n \ge 1,$$

$$(1.25)$$

while its eigenvalues and eigenfunctions for the Laplacian with Neumann boundary conditions are:

$$\mu_{m,n} = \pi^2 \left( \frac{m^2}{L^2} + \frac{n^2}{l^2} \right)$$

$$v_{m,n}(x,y) = \frac{2}{\sqrt{Ll}} \cos(\frac{m\pi x}{L}) \cos(\frac{n\pi y}{l})$$

$$m, n \ge 0.$$
(1.26)

It is immediate to check that the pair  $(\lambda_{m,n}, u_{m,n})$  given by (1.25) are eigenvalue and eigenfunction for the Laplacian with Dirichlet boundary condition. Of course, the difficulty is to prove that there are no other possibilities. Actually, it is due to the fact that the functions  $\sin(\frac{m\pi x}{L})\sin(\frac{n\pi y}{l})$   $m, n \ge 1$  form a complete orthogonal system in  $L^2(\Omega)$ , see [58].

#### **Disks**

Let us consider the disk  $B_R$  of radius R centered at O. In polar coordinates  $(r, \theta)$ , looking for an eigenfunction u of D of the kind  $u(r, \theta) = v(r)w(\theta)$  leads us to solve the ordinary differential equations:

$$w''(\theta) + kw(\theta) = 0$$
,  $w 2\pi$ -periodic,

$$v''(r) + \frac{1}{r}v'(r) + (\lambda - \frac{k}{r^2})v(r) = 0, \quad v'(0) = 0, \ v(R) = 0.$$

The periodicity condition for the first one implies that  $k = n^2$  where n is an integer and  $w(\theta) = a_n \cos n\theta + b_n \sin n\theta$ . Then, replacing k by  $n^2$  in the second equation allows us to recognize the classical Bessel differential equation. We can state

**Proposition 1.2.14.** Let  $\Omega = B_R$  be a disk of radius R; then its eigenvalues and eigenfunctions for the Laplacian with Dirichlet boundary conditions are:

$$\lambda_{0,k} = \frac{j_{0,k}^2}{R^2}, \ k \ge 1,$$

$$u_{0,k}(r,\theta) = \sqrt{\frac{1}{\pi}} \frac{1}{R|J_0'(j_{0,k})|} J_0(j_{0,k}r/R), \ k \ge 1,$$

$$\lambda_{n,k} = \frac{j_{n,k}^2}{R^2}, \ n, k \ge 1, \ double \ eigenvalue$$

$$u_{n,k}(r,\theta) = \sqrt{\frac{2}{\pi}} \frac{1}{R|J_n'(j_{n,k})|} J_n(j_{n,k}r/R) \cos n\theta$$

$$\sqrt{\frac{2}{\pi}} \frac{1}{R|J_n'(j_{n,k})|} J_n(j_{n,k}r/R) \sin n\theta , \ n, k \ge 1,$$

$$(1.27)$$

where  $j_{n,k}$  is the k-th zero of the Bessel function  $J_n$ .

For the Laplacian with Neumann boundary conditions, the eigenvalues and eigenfunctions of the disk  $B_R$  are:

$$\mu_{0,k} = \frac{j'_{0,k}^{2}}{R^{2}}, \ k \ge 1,$$

$$v_{0,k}(r,\theta) = \sqrt{\frac{1}{\pi}} \frac{1}{R|J_{0}(j'_{0,k})|} J_{0}(j'_{0,k}r/R), \ k \ge 1,$$

$$\mu_{n,k} = \frac{j'_{n,k}^{2}}{R^{2}}, \ n,k \ge 1, \ double \ eigenvalue$$

$$v_{n,k}(r,\theta) = \sqrt{\frac{2}{\pi}} \frac{j'_{n,k}}{R\sqrt{j'_{n,k}^{2} - n^{2}|J_{n}(j'_{n,k})|}} J_{n}(j'_{n,k}r/R) \cos n\theta$$

$$\sqrt{\frac{2}{\pi}} \frac{j'_{n,k}}{R\sqrt{j'_{n,k}^{2} - n^{2}|J_{n}(j'_{n,k})|}} J_{n}(j'_{n,k}r/R) \sin n\theta$$

$$(1.28)$$

where  $j'_{n,k}$  is the k-th zero of  $J'_n$  (the derivative of the Bessel function  $J_n$ ).

Here is an array of the first values of  $j_{n,k}$  (left) and  $j'_{n,k}$  (right):

| ١, |       |       |        | 4      | ١, |       |       |        |        |
|----|-------|-------|--------|--------|----|-------|-------|--------|--------|
|    |       |       |        | 11.791 |    |       |       | 7.016  |        |
|    |       |       | 10.173 |        | 1  | 1.841 | 5.331 | 8.536  | 11.706 |
| 2  | 5.136 | 8.417 | 11.620 | 14.796 | 2  | 3.054 | 6.706 | 9.969  | 13.170 |
| 3  | 6.380 | 9.761 | 13.015 | 16.223 | 3  | 4.201 | 8.015 | 11.346 | 14.586 |

**Remark 1.2.15.** Similarly, in dimension  $N \geq 3$ , the eigenvalues of the ball  $B_R$  of radius R involve the zeros of the Bessel functions  $J_{N/2-1}, J_{N/2}, \ldots$  For example

$$\lambda_1(B_R) = \frac{j_{N/2-1,1}^2}{R^2}$$
  $\lambda_2(B_R) = \lambda_3(B_R) = \dots = \lambda_{N+1}(B_R) = \frac{j_{N/2,1}^2}{R^2}$ . (1.29)

#### 1.2.6 Fredholm alternative

Let L be an elliptic operator and  $\lambda$  one of its eigenvalues. Then, by definition, the linear operator  $L - \lambda Id$  has a non-trivial kernel. Nevertheless, in some situations, we need to solve an equation like  $(L - \lambda Id)v = f$ . It is remarkable that we have the same result as in finite dimension.

**Theorem 1.2.16 (Fredholm alternative).** Let L be an elliptic operator on a bounded open set  $\Omega$  and  $\lambda$  one of its eigenvalues for Dirichlet boundary conditions. Let  $f \in L^2(\Omega)$ , then the problem

$$\begin{array}{rcl}
Lv - \lambda v & = & f & in \Omega, \\
v & = & 0 & on \partial\Omega
\end{array} \tag{1.30}$$

has a solution if and only if f is orthogonal (for the  $L^2$  scalar product) to any eigenfunction associated to  $\lambda$ .

For the proof, see e.g. [58], [36]. It is clear that if problem (1.30) has a solution  $v_0$ , we obtain all the solutions by adding any eigenfunction associated to  $\lambda$ :  $v_0 + tu$ .

#### 1.3 Min-max principles and applications

#### 1.3.1 Min-max principles

One very useful tool is the following variational characterization of the eigenvalues, known as the Poincaré principle or Courant-Fischer formulae, see [58]. Let us define the **Rayleigh quotient** of the operator L to be:

$$R_L[v] := \frac{\sum_{i,j=1}^N \int_{\Omega} a_{ij}(x) \frac{\partial v}{\partial x_i} \frac{\partial v}{\partial x_j} dx + \int_{\Omega} a_0(x) v^2(x) dx}{\int_{\Omega} v(x)^2 dx} . \tag{1.31}$$

Then, we have

$$\lambda_k^D(L,\Omega) = \min_{\substack{E_k \subset H_0^1(\Omega), \\ \text{subspace of dim } k}} \max_{v \in E_k, v \neq 0} R_L[v] , \qquad (1.32)$$

$$\mu_k^N(L,\Omega) = \min_{\substack{E_k \subset H^1(\Omega), \\ \text{subspace of dim } k}} \max_{v \in E_k, v \neq 0} R_L[v] . \tag{1.33}$$

In formulae (1.32) and (1.33), the minimum is achieved for choosing  $E_k$  the space spanned by the k-th first eigenfunctions. In particular, assuming that we have already computed  $u_1, u_2, \ldots, u_{k-1}$  the k-1-th first eigenfunctions, we also have:

$$\lambda_k^D(L,\Omega) = \min_{\substack{v \in H_0^1(\Omega), \\ v \text{ orthogonal to } u_1, u_2, \dots, u_{k-1}}} R_L[v] . \tag{1.34}$$

For example, in the case of the Laplacian, formulae (1.32) becomes

$$\lambda_k(\Omega) = \min_{\substack{E_k \subset H_0^1(\Omega), \\ \text{subspace of dim } k}} \max_{\substack{v \in E_k, v \neq 0}} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx}$$
(1.35)

and, in particular, for the first Dirichlet eigenvalue, we get

$$\lambda_1(\Omega) = \min_{v \in H_0^1(\Omega), v \neq 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx} , \qquad (1.36)$$

while the first non-zero Neumann eigenvalue for the Laplacian is given by

$$\mu_2(\Omega) = \min_{v \in H^1(\Omega), v \neq 0, \int_{\Omega} v = 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx} . \tag{1.37}$$

In (1.36) and (1.37), the minimum is achieved by the corresponding eigenfunction(s).

There exist also similar variational characterizations for sums of consecutive eigenvalues or sums of inverses of consecutive eigenvalues (see e.g. [19] pp. 98-99 or [110]). We give here the case of the Laplacian with Dirichlet boundary conditions, but any other case can be handled in the same way. Let us denote by  $u_1, u_2, \ldots, u_k$  the k-th first eigenfunctions. Then,

$$\sum_{i=k+1}^{k+n} \lambda_i(\Omega) = \min \left\{ \sum_{i=k+1}^{k+n} \int_{\Omega} |\nabla v_i(x)|^2 dx \right\}, \tag{1.38}$$

where  $(v_i)$  is an orthonormal family in  $L^2(\Omega)$  satisfying  $\int_{\Omega} v_i u_j dx = 0$ , j = 1, 2, ..., k. Similarly

$$\sum_{i=k+1}^{k+n} \frac{1}{\lambda_i(\Omega)} = \max \left\{ \sum_{i=k+1}^{k+n} \int_{\Omega} v_i(x)^2 \, dx \right\}, \tag{1.39}$$

where  $(v_i)$  is a family in  $H_0^1(\Omega)$  satisfying  $\int_{\Omega} \nabla v_i \cdot \nabla v_j dx = \delta_{ij}$  and  $\int_{\Omega} v_i u_j dx = 0, j = 1, 2, ..., k$ .

#### 1.3.2 Monotonicity

Let us consider two open bounded sets such that  $\Omega_1 \subset \Omega_2$ . This inclusion induces a natural embedding  $H_0^1(\Omega_1) \hookrightarrow H_0^1(\Omega_2)$  just by extending by zero functions in  $H_0^1(\Omega_1)$ . In particular, the min-max principle implies the following monotonicity for inclusion of eigenvalues with Dirichlet boundary conditions:

$$\Omega_1 \subset \Omega_2 \implies \lambda_k^D(L, \Omega_1) \ge \lambda_k^D(L, \Omega_2)$$
(1.40)

(since the minimum is taken over a larger class for  $\lambda_k^D(L, \Omega_2)$ ). Moreover, the inequality is strict as soon as  $\Omega_2 \setminus \Omega_1$  contains a set of positive capacity (since the first eigenfunction cannot vanish on such a set).

Let us also remark that this monotonicity formula is not valid in the Neumann case. For example, Figure 1.1 gives an elementary counter-example with rectangles. We use the fact that the first non-zero eigenvalue of a rectangle for the Neumann-Laplacian is given by  $\mu_2(R) = \frac{\pi^2}{L^2}$  where L is the length of the rectangle (see (1.26)).

![](_page_22_Figure_2.jpeg)

Figure 1.1: Here  $\Omega_1 \subset \Omega_2$  but  $\mu_2(\Omega_1) = \frac{\pi^2}{L_1^2} < \mu_2(\Omega_2) = \frac{\pi^2}{L_2^2}$ .

#### 1.3.3 Nodal domains

Let us now have a look at the sign of eigenfunctions. We have already seen in Theorem 1.2.5 that the first eigenfunction  $u_1$  is positive in  $\Omega$  when  $\Omega$  is connected. More generally,  $u_1$  is non-negative (positive on one connected component and it vanishes on the other ones). Actually, we can recover this result thanks to the minimum formulae (1.32) for  $\lambda_1$ . Indeed, using the fact that if  $u \in H_0^1(\Omega)$  we also have  $|u| \in H_0^1(\Omega)$  and  $\frac{\partial |u|}{\partial x_i} = sign(u) \frac{\partial u}{\partial x_i}$ , we see that u and |u| have the same Rayleigh quotient. Therefore,  $|u_1|$  is also a minimizer of the Rayleigh quotient and, therefore, an eigenfunction.

Concerning the other eigenfunctions, since they are all orthogonal to  $u_1$ , they have to change sign in  $\Omega$ .

**Definition 1.3.1.** Let  $u_k$ ,  $k \geq 2$  be an eigenfunction of the elliptic operator L with Dirichlet or Neumann boundary conditions. The connected components of the open sets

$$\Omega_+ = \{x \in \Omega, \, u_k(x) > 0\} \quad and \quad \Omega_- = \{x \in \Omega, \, u_k(x) < 0\}$$

are called the nodal domains of  $u_k$ .

The number of these nodal domains is bounded from above:

**Theorem 1.3.2 (Nodal domains).** Let  $u_k$ ,  $k \geq 2$  be the k-th eigenfunction of the elliptic operator L with Dirichlet or Neumann boundary conditions. Then,  $u_k$  has at most k nodal domains.

The proof consists in assuming that  $u_k$  has more than k nodal domains, then constructing a test function, orthogonal to the (k-1)-th first eigenfunctions, whose Rayleigh quotient has a value strictly less than  $\lambda_k$  to reach a contradiction by applying (1.34), see e.g. [58]. Let us remark that Theorem 1.3.2 is also true for k=1 and that it gives an elementary proof of the non-negativity of the first eigenfunction (see Theorem 1.2.5) without regularity assumptions. Moreover, it

also implies that the first eigenfunction must be simple in the connected case since two non negative and non zero functions cannot be orthogonal.

We will also frequently use the following property of a nodal domain:

**Proposition 1.3.3.** Let  $u_k$ ,  $k \geq 2$  be an eigenfunction of the elliptic operator L with Dirichlet boundary conditions associated with the eigenvalue  $\lambda_k$ . Let  $\omega_k$  be one of its nodal domains. Then

$$\lambda_1(\omega_k) = \lambda_k$$
.

Indeed, since  $u_k$  satisfies  $Lu_k = \lambda_k u_k$  in  $\omega_k$  and vanishes on  $\partial \omega_k$ , it is an eigenfunction for L on  $\omega_k$  with Dirichlet boundary condition. Moreover, since  $u_k$  has a constant sign on  $\omega_k$ , it can only be the first one.

Let us be a little bit more precise for the second Dirichlet-eigenfunction  $u_2$  of the Laplacian. According to Theorem 1.3.2,  $u_2$  has at most two nodal domains. So, it has exactly two nodal domains when  $\Omega$  is connected. The set

$$\mathcal{N} = \{ x \in \Omega, \, u_2(x) = 0 \}$$

is called **the nodal line** of  $u_2$ . When  $\Omega$  is a plane convex domain, this nodal line hits the boundary of  $\Omega$  at exactly two points, see Melas [150], or Alessandrini [2]. For general simply connected plane domains  $\Omega$ , it is still a conjecture, named after Larry Payne, the "Payne conjecture".

#### 1.4 Perforated domains

When a domain minimizes a given function of eigenvalues, we can classically get some optimality conditions by letting the boundary of the domain vary and using domain derivative formulae which will be presented in section 2.5. An alternative way to get optimality conditions *inside* the domain is to use asymptotic expansions of eigenvalues of domains with small holes (it is also related to the so-called *topological derivative*, see e.g. [159]). There is a huge literature on that topic, see e.g. [165], [88], [149] and the references therein. Let us give an example:

**Theorem 1.4.1.** Let  $\Omega$  be an open set in  $\mathbb{R}^N$ ,  $x_0 \in \Omega$  and  $\varepsilon > 0$  a small number. Let us denote  $\Omega_{\varepsilon} = \Omega \setminus B(x_0, \varepsilon)$  (the set where we have removed the ball centered at  $x_0$  of radius  $\varepsilon$ ). Then the eigenvalues of the Laplacian-Dirichlet operator satisfy the following expansion:

$$\lambda_k(\Omega_{\varepsilon}) = \lambda_k(\Omega) + \frac{2\pi}{-\log \varepsilon} u_k^2(x_0) + o(\frac{1}{|\log \varepsilon|}) \quad \text{if } N = 2,$$
  
$$\lambda_k(\Omega_{\varepsilon}) = \lambda_k(\Omega) + \varepsilon^{N-2} S^{N-1} u_k^2(x_0) + o(\varepsilon^{N-2}) \quad \text{if } N \ge 3,$$
 (1.41)

where, in the last formulae,  $S^{N-1}$  is the N-1-dimensional measure of the unit sphere in  $\mathbb{R}^N$ .

The previous formulae can be possibly used to prove *non-existence* of a minimizer for some function of eigenvalues. Let us be more precise. For example, if we want to prove non-existence for a two-dimensional problem like

$$\min_{\Omega \subset \mathbb{R}^2} F(\lambda_1(\Omega), \lambda_2(\Omega), \dots, \lambda_k(\Omega)), \tag{1.42}$$

we can assume that there exists a minimizer, say  $\Omega$ . Let us denote by  $J(\Omega) = F(\lambda_1(\Omega), \lambda_2(\Omega), \dots, \lambda_k(\Omega))$ . Introducing  $\Omega_{\varepsilon}$  as above, we will have the expansion

$$J(\Omega_{\varepsilon}) = J(\Omega) + \frac{2\pi}{-\log \varepsilon} \sum_{i=1}^{k} \frac{\partial F}{\partial x_i}(\lambda_1(\Omega), \lambda_2(\Omega), \dots, \lambda_k(\Omega)) u_i^2(x_0) + o(\frac{1}{|\log \varepsilon|}).$$

Obviously, if we can find a point  $x_0$  in  $\Omega$  where the first order term is negative, it will imply non-existence.

# **Chapter 2**

# **Tools**

#### **2.1 Schwarz rearrangement**

The Schwarz rearrangement is the main tool used by G. Faber and E. Krahn to prove their famous isoperimetric inequality (see Theorem 3.2.1). Let us present briefly this rearrangement. In the next section, we also introduce Steiner symmetrization. The reader interested in other rearrangements and other applications can read for example [19], [97], [122], [152], [174].

**Definition 2.1.1.** For any measurable set ω in R<sup>N</sup> , we denote by ω<sup>∗</sup> **the ball of same volume as** ω. If u is a non-negative measurable function defined on a measurable set Ω and vanishing on its boundary ∂Ω, we denote by Ω(c) = {x ∈ Ω /u(x) ≥ c} its level sets. The Schwarz rearrangement (or spherical decreasing rearrangement) of u is the function u<sup>∗</sup> defined on Ω<sup>∗</sup> by

$$u^*(x) = \sup\{c/x \in \Omega(c)^*\}.$$

In other words, u<sup>∗</sup> is constructed from u by rearranging the level sets of u in balls of the same volume. By construction, the following properties of u<sup>∗</sup> are obvious:

- u<sup>∗</sup> is radially symmetric, non-increasing as a function of |x|,
- supΩ <sup>u</sup> = supΩ <sup>u</sup>∗,
- u and u<sup>∗</sup> are equimeasurable (i.e. their level sets have the same measure).

As an immediate consequence of the last point, we have:

**Theorem 2.1.2.** Let Ω be a measurable set and u be a non-negative measurable function defined on Ω and vanishing on its boundary ∂Ω. Let ψ be any measurable function defined on R<sup>+</sup> with values in R, then

$$\int_{\Omega} \psi(u(x)) dx = \int_{\Omega^*} \psi(u^*(x)) dx. \qquad (2.1)$$

Let us now state a deeper result, sometimes called the Pòlya inequality, which gives a connection between the integrals of the gradients of u and  $u^*$ . Its proof relies on the classical isoperimetric inequality, see the above references.

**Theorem 2.1.3 (Pòlya's inequality).** Let  $\Omega$  be an open set and u a non-negative function belonging to the Sobolev space  $H_0^1(\Omega)$ . Then  $u^* \in H_0^1(\Omega^*)$  and

$$\int_{\Omega} |\nabla u(x)|^2 dx \ge \int_{\Omega^*} |\nabla u^*(x)|^2 dx . \tag{2.2}$$

More generally, let g be a non negative, continuous function defined on  $\mathbb{R}^+$  and F be a non negative, increasing, convex function defined on  $\mathbb{R}^+$  and such that there exist  $p, 1 \leq p < +\infty$  and c > 0 with  $F(x) \leq c(1+x^p)$ . Let u be a non-negative function in the Sobolev space  $W_0^{1,p}(\Omega)$ , then  $u^*$  belongs to  $W_0^{1,p}(\Omega)$  and

$$\int_{\Omega} g(u(x))F(|\nabla u(x)|) \, dx \ge \int_{\Omega^*} g(u^*(x))F(|\nabla u^*(x)|) \, dx \,. \tag{2.3}$$

For the equality cases in inequalities (2.2) and (2.3), we refer e.g. to [122] or [56]. Another useful inequality is due to Hardy and Littlewood.

**Theorem 2.1.4 (Hardy-Littlewood).** Let u and v be two non-negative measurable functions defined on  $\Omega$  and  $u^*$ ,  $v^*$  their respective spherical decreasing rearrangements. Then

$$\int_{\Omega} u(x)v(x)dx \le \int_{\Omega^*} u^*(x)v^*(x)dx.$$
 (2.4)

Let us also give a weighted isoperimetric inequality which will turn out to be useful in section 7.3. It is due to F. Betta, F. Brock, A. Mercaldo and M.R. Posteraro and can be found in [34].

**Lemma 2.1.5.** Let  $\Omega$  be an open set and f be a continuous, non-negative, non-decreasing function defined on  $[0, +\infty)$ . Let us assume moreover that

$$t \mapsto \left( f(t^{1/N}) - f(0) \right) t^{1 - (1/N)} \quad \text{is convex (for } t \ge 0).$$
 (2.5)

Then

$$\int_{\partial\Omega} f(|x|) d\sigma \ge \int_{\partial\Omega^*} f(|x|) d\sigma . \tag{2.6}$$

Let us observe that (2.5) is satisfied for power functions like  $f(t) = t^p$  with  $p \ge 1$ .

#### 2.2 Steiner symmetrization

#### 2.2.1 Definition

We now introduce another kind or rearrangement due to Steiner. It will be useful for the problem of minimizing  $\lambda_1$  among polygons, see section 3.3. For the proofs

and more details, we still refer to [122], [174]. Without loss of generality, we fix the hyperplane of symmetry to be  $x_N = 0$ .

Let  $N \geq 2$  and  $\Omega \subset \mathbb{R}^N$  be a measurable set. We denote by  $\Omega'$  the projection of  $\Omega$  on  $\mathbb{R}^{N-1}$ :

$$\Omega' := \{x' \in \mathbb{R}^{N-1} \text{ such that there exists } x_N \text{ with } (x', x_N) \in \Omega\},$$

and, for  $x' \in \mathbb{R}^{N-1}$ , we denote by  $\Omega(x')$  the intersection of  $\Omega$  with  $\{x'\} \times \mathbb{R}$ :

$$\Omega(x') := \{x_N \in \mathbb{R} \text{ such that } (x', x_N) \in \Omega\}, \ x' \in \Omega'$$
.

Let us remark that if  $\Omega$  is an open set, the sets  $\Omega(x')$  are also open and  $x' \to |\Omega(x')|$  is lower semi-continuous.

**Definition 2.2.1 (Steiner symmetrization of sets).** Let  $\Omega \subset \mathbb{R}^N$  be measurable. Then the set

$$\Omega^{\star} := \left\{ x = (x', x_N) \text{ such that } -\frac{1}{2} |\Omega(x')| < x_N < \frac{1}{2} |\Omega(x')|, \ x' \in \Omega' \right\}$$

is the Steiner symmetrization of  $\Omega$  with respect to the hyperplane  $x_N = 0$ .

Roughly speaking,  $\Omega^*$  is obtained from  $\Omega$  by putting the middle of each segment orthogonal to the hyperplane (when there is only one such segment), on the hyperplane. As a consequence of the definition, we see that  $\Omega^*$  is symmetric with respect to  $x_N=0$  and convex in the  $x_N$  direction. Moreover, it is easy to check that  $\Omega^*$  is an open set as soon as  $\Omega$  is open.

![](_page_27_Picture_12.jpeg)

Figure 2.1: The Steiner symmetrization: a set  $\Omega$  (left), its symmetrization  $\Omega^*$  with respect to the horizontal dashed line (right).

**Definition 2.2.2.** We will say that an open set  $\Omega$  is Steiner symmetric with respect to a hyperplane H if it coincides with its Steiner symmetrization  $\Omega^*$  w.r.t. H, i.e. if it is symmetric w.r.t. H and convex in the orthogonal direction.

Let us now consider a non-negative measurable function u defined on  $\Omega$  which vanishes on  $\partial\Omega$ . We define, as in the case of Schwarz rearrangement, the Steiner symmetrization of u.

**Definition 2.2.3 (Steiner symmetrization of functions).** Let u be a non-negative measurable function defined on  $\Omega$ , which vanishes on  $\partial\Omega$ . We denote by  $\Omega(c) = \{x \in \Omega / u(x) \geq c\}$  its level sets. The Steiner symmetrization of u is the function  $u^*$  defined on  $\Omega^*$  by

$$u^{\star}(x) = \sup\{c / x \in \Omega(c)^{\star}\}\ .$$

We can also define the Steiner symmetrization of u thanks to the function of distribution of u: for a.e.  $x' \in \mathbb{R}^{N-1}$ , this function is defined by  $m_u(x',c) := |\{x_N \in \mathbb{R}; \ u(x',x_N) > c\}|, \ c > 0$ . It is non decreasing and continuous on the right with respect to c. Then, we introduce the function  $y = Y(x',c) := \frac{1}{2} m_u(x',c)$  and its inverse function is nothing else but  $u^*$  and it satisfies

$$c = u^*(x', y) = u^*(x', -y).$$

#### 2.2.2 Properties

20

Let us gather in one theorem the main properties of the Steiner symmetrization that we will use later. These properties are exactly the same as for the Schwarz rearrangement.

**Theorem 2.2.4.** Let  $\Omega \subset \mathbb{R}^N$  be a measurable set, u a non-negative function defined on  $\Omega$  and vanishing on its boundary. Let  $\Omega^*$ ,  $u^*$  be their Steiner symmetrizations. Then:

- (i)  $|\Omega| = |\Omega^{\star}|$ .
- (ii) If  $\psi$  is any measurable function from  $\mathbb{R}_+$  to  $\mathbb{R}$ , then

$$\int_{\Omega} \psi(u(x)) dx = \int_{\Omega^{\star}} \psi(u^{\star}(x)) dx.$$
 (2.7)

(iii) If  $\Omega$  is open and if u belongs to the Sobolev space  $W_0^{1,p}(\Omega)$ , with  $1 \leq p < +\infty$ , then  $u^* \in W_0^{1,p}(\Omega^*)$  and

Pòlya's inequality 
$$\int_{\Omega} |\nabla u(x)|^p dx \ge \int_{\Omega^*} |\nabla u^*(x)|^p dx . \qquad (2.8)$$

(iv) If  $\Omega$  is open and u, v belong to  $L^2(\Omega)$ :

Hardy-Littlewood's inequality 
$$\int_{\Omega}u(x)v(x)dx\leq \int_{\Omega^{\star}}u^{\star}(x)v^{\star}(x)dx\,. \eqno(2.9)$$

#### 2.2.3 Continuous Steiner symmetrization

Instead of putting the middle of each segment orthogonal to the hyperplane directly on the hyperplane, we can move it with a speed which is proportional to its distance to the hyperplane. Of course, the mathematical definition of this construction must be more precise.

In this section we give the definition of continuous symmetrization and some of its properties which were investigated in [39], [40]. Let us denote by  $\mathcal{M}(\mathbb{R}^N)$  the set of measurable sets in  $\mathbb{R}^N$ . Let us begin with the one-dimensional case:

**Definition 2.2.5 (Continuous symmetrization of sets in**  $\mathbb{R}$ ). A family of set transformations

$$E_t: \mathcal{M}(\mathbb{R}) \longrightarrow \mathcal{M}(\mathbb{R}), \qquad 0 \leq t \leq +\infty,$$

satisfying the properties,  $(A, B \in \mathcal{M}(\mathbb{R}), 0 \leq s, t \leq +\infty)$ :

- (i)  $|E_t(A)| = |A|$ , (equimeasurability),
- (ii) If  $A \subset B$ , then  $E_t(A) \subset E_t(B)$ , (monotonicity),
- (iii)  $E_t(E_s(A)) = E_{s+t}(A)$ , (semigroup property),
- (iv) If  $I = [y_1, y_2]$  is a bounded closed interval, then  $E_t(I) = [y_1^t, y_2^t]$ , where:

$$y_1^t = (1/2)(y_1 - y_2 + e^{-t}(y_1 + y_2)), y_2^t = (1/2)(y_2 - y_1 + e^{-t}(y_1 + y_2)),$$
(2.10)

is called a continuous symmetrization.

If  $\Omega$  is any measurable set, we will write  $\Omega^t := E_t(\Omega)$  for the symmetrized sets. The existence, uniqueness and some further properties of the family  $\{E_t\}$ ,  $0 \le t \le +\infty$ , are proved in [40], Theorem 2.1. In particular we have for every  $\Omega \in \mathcal{M}(\mathbb{R})$ .

$$\Omega^0 = \Omega, \quad \Omega^\infty = \Omega^*. \tag{2.11}$$

Definition 2.2.6 (Continuous Steiner symmetrization in  $\mathbb{R}^N$ ).

1) Let  $\Omega \in \mathcal{M}(\mathbb{R}^N)$ . The family of sets

$$\Omega^t := \left\{ x = (x', x_N) : x_N \in \left( \Omega(x') \right)^t, x' \in \Omega' \right\}, 0 \le t \le +\infty,$$
(2.12)

is called the continuous Steiner symmetrization of  $\Omega$ . If  $\Omega$  is open, then  $\Omega^t$  is also open.

2) Let u be a non-negative function in an open set  $\Omega$  vanishing on the boundary  $\partial \Omega$ . The family of functions  $u^t$ ,  $0 \le t \le +\infty$ , defined on  $\Omega^t$  by

$$u^{t}(x) := \sup \left\{ c \text{ such that } x \in \{u > c\}^{t} \right\}, \quad x \in \Omega^{t},$$
 (2.13)

is called the continuous Steiner symmetrization of u with respect to  $x_N = 0$ .

As in (2.11), we can prove that, for every  $\Omega \in \mathcal{M}(\mathbb{R}^N)$  and u as above

$$\Omega^0 = \Omega, \quad \Omega^\infty = \Omega^\star \qquad u^0 = u, \quad u^\infty = u^\star.$$
 (2.14)

Let us summarize some properties of the continuous symmetrization which are proved in [39],[40]. It is actually completely similar to Theorem 2.2.4.

**Theorem 2.2.7.** Let  $\Omega \subset \mathbb{R}^N$  be a measurable set, u be a non-negative function defined on  $\Omega$  and vanishing on its boundary. Let  $\Omega^t$ ,  $u^t$  be their continuous Steiner symmetrizations. Then:

- (i)  $|\Omega| = |\Omega^t|$ .
- (ii) If  $\psi$  is any measurable function from  $\mathbb{R}_+$  to  $\mathbb{R}$ , then

$$\int_{\Omega} \psi(u(x)) dx = \int_{\Omega^t} \psi(u^t(x)) dx.$$
 (2.15)

(iii) If  $\Omega$  is open and if u belongs to the Sobolev space  $W_0^{1,p}(\Omega)$ , with  $1 \leq p < +\infty$ , then  $u^t \in W_0^{1,p}(\Omega^t)$  and

$$\int_{\Omega} |\nabla u(x)|^p dx \ge \int_{\Omega^t} |\nabla u^t(x)|^p dx. \qquad (2.16)$$

In particular, applying (1.36), it is easy to deduce from (2.15), (2.16) that the first eigenvalue of the Laplacian with Dirichlet boundary conditions decreases under the continuous Steiner symmetrization. The behavior of all the remaining eigenvalues under the continuous Steiner symmetrization is less simple! Nevertheless, in [46] we prove:

**Theorem 2.2.8 (Bucur-Henrot).** Let  $k \in \mathbb{N}^*$  be fixed. The map  $t \mapsto \lambda_k(\Omega^t)$  is lower semi-continuous on the left and upper semi-continuous on the right. Moreover, we have the following intermediate value property: if  $\lambda_k(\Omega^t) \geq \lambda_k(\Omega)$  for some t > 0, then, for any  $\lambda \in [\lambda_k(\Omega), \lambda_k(\Omega^t)]$ , there exists  $t_{\lambda} \in [0, t]$  such that  $\lambda_k(\Omega^{t_{\lambda}}) = \lambda$ .

One of the main advantages of the continuous Steiner symmetrization is that it allows us to look at what happens when  $t \to 0$ . It is known that the map  $t \to u^t$  is continuous in  $W^{1,p}(\mathbb{R}^N)$  (we extend the functions by 0 outside  $\Omega^t$ ). But it is also very interesting to look at differentiability properties of functionals like  $t \to \int_{\Omega^t} |\nabla u^t(x)|^p dx$ . Of course, thanks to (2.16), the derivative of such a map must be non-positive. More precisely, let us give now a very nice result explaining what happens if this derivative is zero. For the proof, see [40].

**Theorem 2.2.9 (Brock).** Let  $\Omega$  be a bounded domain,  $u \in C^1(\Omega) \cap C(\overline{\Omega})$ , u > 0 in  $\Omega$  and u = 0 on  $\partial\Omega$ . Furthermore, let G be a positive increasing and strictly convex function on  $[0, +\infty[$  and suppose that

$$\lim_{t \searrow 0} \frac{1}{t} \left( \int_{\Omega^t} G(|\nabla u^t|) \ dx - \int_{\Omega} G(|\nabla u|) \ dx \right) = 0. \tag{2.17}$$

(2.19)

Then we have the decomposition

$$\{0 < u < \sup u\} = \bigcup_{k=1}^{m} \left( B_{R_k}(z_k) \setminus \overline{B_{r_k}(z_k)} \right) \bigcup S, \tag{2.18}$$

where

$$\begin{split} R_k > r_k \geq 0, \ z_k \in \{0 < u < \sup u\}, B_R(z) \text{is the ball of radius $R$ and center $z$} \\ \frac{\partial u}{\partial \rho} < 0 \quad \text{in $B_{R_k}(z_k) \setminus \overline{B_{r_k}(z_k)}$,} \quad (\rho: \text{radial distance from $z_k$}), \\ \min \ \Big\{ u(x): \ x \in B_{r_k}(z_k) \Big\} = \min \ \Big\{ u(x): \ x \in \partial B_{r_k}(z_k) \Big\}, \\ 1 \leq k \leq m, \qquad \text{and $\nabla u = 0$} \quad \text{in $S$}. \end{split}$$

The sets on the right-hand side of (2.18) are disjoint and there can be a countable number of annuli, i.e.  $m = +\infty$ .

We will use this result in section 3.4.

#### 2.3 Continuity of eigenvalues

#### 2.3.1 Introduction

To prove existence of minimizers or maximizers for eigenvalues or functions of eigenvalues, we obviously need continuity of eigenvalues with respect to the variable. We are mainly concerned in this book with eigenvalues depending

- either on the domain
- or on the coefficients of the operator.

Therefore, we are going to study continuity of eigenvalues with respect to these two kinds of variations. The second one is simpler and classical. The first one is less classical and it will be related to the so-called  $\gamma$ -convergence. We will also see that, for domain dependence, the theory is much more precise in the case of Dirichlet boundary conditions. In order to be complete and self-contained, we give the different steps which are useful to prove continuity and some proofs. We also refer to [44], [104] for more details about domain-continuity of eigenvalues and  $\gamma$ -convergence.

Let us begin with an elementary, but basic, result.

**Theorem 2.3.1.** Let  $T_1$  and  $T_2$  be two self-adjoint, compact and positive operators on a separable Hilbert space H. Let  $\mu_k(T_1)$  and  $\mu_k(T_2)$  be their k-th respective eigenvalues. Then

$$|\mu_k(T_1) - \mu_k(T_2)| \le ||T_1 - T_2|| := \sup_{f \in H} \frac{||(T_1 - T_2)(f)||}{||f||}.$$
 (2.20)

*Proof.* We use the min-max formulae which, in this case, can be written

$$\mu_k(T_i) = \min_{\substack{E_k \subset H, \\ \text{subspace of dim } k}} \max_{v \in E_k, v \neq 0} \frac{(T_i f, f)}{\|f\|^2}. \tag{2.21}$$

In formulae (2.21), the minimum is achieved for choosing  $E_k$  the space spanned by the k-th first eigenvectors of  $T_i$ . So, let us fix  $E_k^{(2)} = Span(e_1^{(2)}, e_2^{(2)}, \dots, e_k^{(2)})$  the vector space spanned by the k-th first eigenvectors of  $T_2$ . Therefore, we have

$$\mu_k(T_1) - \mu_k(T_2) \le \max_{v \in E_k^{(2)}, v \ne 0} \frac{(T_1 f, f)}{\|f\|^2} - \max_{v \in E_k^{(2)}, v \ne 0} \frac{(T_2 f, f)}{\|f\|^2}.$$

Now, the first maximum is achieved for some vector  $\hat{f}$ . Then,

$$\mu_k(T_1) - \mu_k(T_2) \le \frac{(T_1\hat{f}, \hat{f})}{\|\hat{f}\|^2} - \frac{(T_2\hat{f}, \hat{f})}{\|\hat{f}\|^2} = \frac{((T_1 - T_2)\hat{f}, \hat{f})}{\|\hat{f}\|^2}$$

which yields the desired result by Cauchy-Schwarz inequality.

An immediate consequence of Theorem 2.3.1 is that strong convergence of operators implies convergence of eigenvalues. We are now going to see that, in our particular context, thanks to compactness properties of embeddings  $H^1 \hookrightarrow L^2$  and  $L^2 \hookrightarrow H^{-1}$ , actually simple convergence of resolvant operators implies convergence of eigenvalues.

We recall that we are concerned in this section with Dirichlet boundary conditions. If L is any elliptic operator given by (1.4), we denote by  $A_L$  (or  $A_L^{\Omega}$  when we want to emphasize dependence on the domain  $\Omega$ ) its resolvant operator, namely the operator from  $L^2(\Omega)$  into  $L^2(\Omega)$  such that  $A_L(f)$  is the solution of the Dirichlet problem  $u \in H_0^1(\Omega)$ , Lu = f. When we consider a sequence of domains  $\Omega_n$  included in a fixed domain D, we decide to extend the operators  $A_L^{\Omega}$  to  $L^2(D)$  by setting

$$A_L^\Omega: \begin{array}{cc} L^2(D) \to L^2(D), \\ f \mapsto \tilde{u}, \end{array}$$

where  $u \in H_0^1(\Omega)$  is the solution of Lu = f and  $\tilde{u}$  is its extension by zero outside  $\Omega$ . For sake of simplicity, we go on denoting by u the extension (instead of  $\tilde{u}$ ).

**Theorem 2.3.2.** Let  $A_n$ , A be a sequence of resolvant operators from  $L^2(D)$  to  $L^2(D)$ , corresponding to a sequence of uniformly elliptic operators with Dirichlet boundary conditions. We assume that, for every  $f \in L^2(D)$ ,  $A_n(f)$  converges to A(f) in  $L^2(D)$ . Then  $A_n$  converges to A strongly (i.e. for the operator norm). In particular, the eigenvalues of  $A_n$  converge to the corresponding eigenvalues of A.

*Proof.* First of all, we remark that the resolvant operators  $A_n$  and A have a bounded norm. Indeed, from (1.7) and uniform ellipticity of  $A_n$ , it follows that (we set  $u = A_n(f)$ )

$$\alpha \int_{D} |\nabla u|^{2} \leq \sum_{i,j=1}^{N} \int_{\Omega} a_{ij}(x) \frac{\partial u}{\partial x_{i}} \frac{\partial u}{\partial x_{j}} dx + \int_{\Omega} c(x) u^{2}(x) dx = \int_{\Omega} f(x) u(x) dx$$

and, thanks to Poincaré inequality (1.1) for the left-hand side and Cauchy-Schwarz inequality for the right-hand side, we have

$$\frac{\alpha}{C} \|u\|_{L^2}^2 \le \|f\|_{L^2} \|u\|_{L^2},$$

which shows that

$$||A_n|| := \sup_{f \in L^2(D)} \frac{||u||_{L^2}}{||f||_{L^2}} \le \frac{C}{\alpha}.$$
 (2.22)

Now, we claim that it is possible (for fixed n) to find  $f^n$  in the unit ball of  $L^2(D)$  achieving the supremum in

$$\sup_{\|f\|_{L^2(D)} \le 1} \|A_n(f) - A(f)\|_{L^2(D)} = \|A_n(f^n) - A(f^n)\|_{L^2(D)}.$$

Indeed, if  $f_k$  is a maximizing sequence, it is possible to extract a subsequence which converges weakly to some  $f^n$  which also belongs to the unit ball of  $L^2(D)$ . Since the embedding from  $L^2(D)$  into  $H^{-1}(D)$  is compact (it is the adjoint of the embedding from  $H_0^1(D)$  into  $L^2(D)$ ), and since  $A_n$  and A are continuous from  $H^{-1}(D)$  to  $H_0^1(D)$ , the previous equality follows when we let k go to infinity.

Now, let us repeat this method with the sequence  $f^n$ : there exists f in the unit ball of  $L^2(D)$  such that  $f^n$  converge weakly in  $L^2(D)$  and strongly in  $H^{-1}(D)$  to f. Let us fix an integer  $n_1$  such that for  $n \geq n_1$ , we have

$$||f^n - f||_{H^{-1}(D)} \le \frac{\varepsilon \alpha}{4C}$$
 and  $||A_n(f) - A(f)||_{L^2(D)} \le \frac{\varepsilon}{2}$ 

the second inequality coming from the assumption on the (simple) convergence of  $A_n$  to A. Then

$$\sup_{\|g\|_{L^{2}(D)} \le 1} \|A_{n}(g) - A(g)\|_{L^{2}(D)} = \|A_{n}(f^{n}) - A(f^{n})\|_{L^{2}(D)}$$

$$\leq \|A_{n}(f) - A(f)\|_{L^{2}(D)} + \|A_{n}(f^{n} - f) - A(f^{n} - f)\|_{L^{2}(D)}$$

$$\leq \frac{\varepsilon}{2} + \|A_{n} - A\|_{\mathcal{L}(H_{0}^{1}, H^{-1})} \frac{\varepsilon \alpha}{4C} \leq \frac{\varepsilon}{2} + \frac{2C}{\alpha} \frac{\varepsilon \alpha}{4C} = \varepsilon,$$

which proves the desired result.

#### 2.3.2 Continuity with variable coefficients

We can now state the continuity result for eigenvalues when the coefficients of the elliptic operator vary. We consider a sequence of elliptic operators  $L_n$  defined by:

$$L_n u := -\sum_{i,j=1}^N \frac{\partial}{\partial x_i} \left( a_{ij}^n(x) \frac{\partial u}{\partial x_j} \right) + a_0^n(x) u \tag{2.23}$$

where the bounded functions  $a_{i,j}^n$  are assumed to satisfy the ellipticity condition (1.2) **uniformly**, i.e. the positive constant  $\alpha$  can be chosen independently of n.

**Theorem 2.3.3.** Let  $L_n$  be a sequence of uniformly elliptic operators defined on an open set D by (2.23). We assume that, for fixed i, j, the sequence  $a_{i,j}^n$  is bounded in  $L^{\infty}$  and converge almost everywhere to a function  $a_{i,j}$ ; we also assume that the sequence  $a_0^n$  is bounded in  $L^{\infty}$  and converges weakly-\* in  $L^{\infty}$  to a function  $a_0$ . Let L be the (elliptic) operator defined on D as in (2.23) by the functions  $a_{i,j}$  and  $a_0$ . Then each eigenvalue of  $L_n$  converges to the corresponding eigenvalue of L.

*Proof.* According to Theorem 2.3.2, it suffices to prove that, for f fixed in  $L^2(D)$ , the solutions  $u_n \in H_0^1(D)$  of  $L_n u_n = f$  converge to  $u \in H_0^1(D)$ , a solution of Lu = f. The variational formulation satisfied by  $u_n$  is written  $\forall v \in H_0^1(D)$ :

$$\sum_{i,j=1}^{N} \int_{D} a_{ij}^{n}(x) \frac{\partial u_{n}}{\partial x_{i}} \frac{\partial v}{\partial x_{j}} dx + \int_{D} a_{0}^{n}(x) u_{n}(x) v(x) dx = \int_{D} f(x) v(x) dx . \quad (2.24)$$

Plugging  $v = u_n$  in (2.24) and using the uniform ellipticity of the operators  $L_n$  yields:

$$\alpha \|u_n\|_{H^1(D)}^2 \le \int_D f(x)u_n(x) \, dx \le \|f\|_{L^2(D)} \|u_n\|_{L^2(D)} \le \|f\|_{L^2(D)} \|u_n\|_{H^1(D)}$$

for which we deduce that the sequence  $u_n$  is bounded in  $H_0^1(D)$ . Therefore, we can extract a subsequence, still denoted  $u_n$ , such that  $u_n$  converges weakly in  $H_0^1(D)$  and strongly in  $L^2(D)$  to some function  $\tilde{u}$  which belongs to  $H_0^1(D)$ . It remains to prove that  $\tilde{u}=u$  (solution of Lu=f in  $H_0^1(D)$ ). For that, we want to pass to the limit in (2.24). But point-wise convergence and uniform boundedness of  $a_{i,j}^n$  implies strong convergence in  $L^2(D)$  of  $a_{ij}^n(x)\frac{\partial v}{\partial x_j}$  to  $a_{ij}(x)\frac{\partial v}{\partial x_j}$  and therefore convergence of the first integral in (2.24). In the same way, strong convergence of  $u_n$  to u in  $L^2(D)$  implies strong convergence of  $u_nv$  to uv in  $L^1(D)$  which, together with weak-\* convergence of  $a_0^n$  to  $a_0$ , implies convergence of the second integral in (2.24). Since the convergence of the right-hand side is obvious, we have proved the desired result. At last, since u is the only accumulation point of the sequence  $u_n$ , the whole sequence converges to u.

**Remark 2.3.4.** The case of Neumann boundary conditions here is handled exactly in the same way (just change  $H_0^1$  into  $H^1$  in the proof).

**Remark 2.3.5.** Instead of assuming uniform ellipticity for the sequence of operators  $L_n$ , we can assume a weaker assumption. Namely, if we assume that the functions  $a_{i,j}$  define an elliptic operator, we can deduce from point-wise convergence of  $a_{i,j}^n$  to  $a_{i,j}$  the uniform ellipticity of  $L_n$ . Indeed, in the inequality

$$\sum_{i,j=1}^{N} a_{ij}^{n}(x)\xi_{i}\xi_{j} \ge \alpha_{n}|\xi|^{2}$$

the ellipticity constant  $\alpha_n$  is actually a lower bound for all the eigenvalues of the symmetric definite positive matrix  $\mathcal{M}_n(x) = (a_{ij}^n(x))_{i,j}$ . Now, if for (almost) all x,  $a_{ij}^n(x)$  converge to  $a_{ij}(x)$ , the eigenvalues  $\lambda_n^1(x) \leq \lambda_n^2(x) \leq \cdots$  of  $\mathcal{M}_n(x)$  will converge to the eigenvalues  $\lambda^1(x) \leq \lambda^2(x) \leq \cdots$  of  $\mathcal{M}(x) = (a_{ij}(x))_{i,j}$ . Since, by assumption, we have  $\lambda^1(x) \geq \alpha$ , we will have  $\lambda_n^1(x) \geq \alpha/2$  for n large enough.

In one dimension, we can prove the same continuity result with weaker assumptions on the convergence of the  $a_{ij} = a_{11} = \sigma(x)$ . Actually weak-\* convergence of the inverse is enough in this case:

**Theorem 2.3.6.** Let  $\Omega = (0, L)$ ,  $0 < \alpha \le \beta$ , and  $\sigma_n(x)$  be a sequence of functions satisfying  $\alpha \le \sigma_n(x) \le \beta$ . We denote by  $\lambda_k(\sigma)$  the eigenvalues of the operator  $-\frac{d}{dx}(\sigma(x)\frac{d}{dx})$ . Then, if  $1/\sigma_n$  converges weak-\* in  $L^{\infty}(\Omega)$  to  $1/\sigma$ , each eigenvalue  $\lambda_k(\sigma_n)$  converges to  $\lambda_k(\sigma)$  and the corresponding eigenfunctions converge weakly in  $H^1(\Omega)$  and strongly in  $L^2(\Omega)$ .

**Remark 2.3.7.** Since  $\alpha \leq \sigma_n(x) \leq \beta$ , we have  $1/\beta \leq 1/\sigma_n(x) \leq 1/\alpha$  and then, there always exists a function  $\sigma(x)$  such that, for a subsequence,  $1/\sigma_{n_k}$  converges weak-\* in  $L^{\infty}(\Omega)$  to  $1/\sigma$ .

*Proof.* We do the proof in the case of Dirichlet boundary conditions. The proof would be exactly the same in the other cases (Neumann or mixed boundary conditions). According to Theorem 2.3.2, it suffices to prove that, for f fixed in  $L^2(\Omega)$ , the solutions  $u_n \in H_0^1(\Omega)$  of  $-\frac{d}{dx}(\sigma_n(x)\frac{du_n}{dx}) = f$  converge to  $u \in H_0^1(\Omega)$ , a solution of  $-\frac{d}{dx}(\sigma(x)\frac{du}{dx}) = f$ . From the variational formulation

$$\forall v \in H_0^1(\Omega), \quad \int_0^L \sigma_n u_n' v' \, dx = \int_0^L f v \, dx \tag{2.25}$$

we see, taking  $v=u_n$  and using  $\sigma_n \geq \alpha$  that  $u_n$  is bounded in  $H^1_0(\Omega)$ . We extract a subsequence, still denoted by  $u_n$ , which converges to a function  $u \in H^1_0(\Omega)$ , weakly in  $H^1(\Omega)$  and strongly in  $L^2(\Omega)$ . Let us introduce the sequence of functions  $\xi_n := \sigma_n u'_n$  which is bounded in  $L^2(\Omega)$ . From  $-\frac{d}{dx}(\sigma_n u'_n) = \lambda_k(\sigma_n)u_n$ , we see that  $\xi'_n$  is also bounded in  $L^2(\Omega)$  and therefore,  $\xi_n$  being bounded in  $H^1(\Omega)$ , we can extract a subsequence which converges strongly to a function  $\xi$  in  $L^2(\Omega)$ . Now, by assumption, the sequence of functions  $\sigma_n^{-1}$  converges in  $L^\infty$  weak-\* to the function  $\mu = \sigma^{-1}$ . It follows that  $\xi_n \sigma_n^{-1} \rightharpoonup \xi \mu$  in  $L^2(\Omega)$ . But  $\xi_n \sigma_n^{-1} = u'_n \rightharpoonup u'$  in  $L^2(\Omega)$ ,

so  $\xi \mu = u'$  or  $\xi = \mu^{-1}u'$ . Passing to the limit in (2.25) yields (thanks to weak convergence of  $\xi_n$  to  $\xi$ , and strong convergence of  $u_n$  to u)

$$\forall v \in H_0^1(\Omega) \quad \int_0^L \xi v' \, dx = \int_0^L \sigma u' v' \, dx = \int_0^L f v \, dx \,. \tag{2.26}$$

This formulation (2.26) shows that u is the solution of  $-\frac{d}{dx}(\sigma(x)\frac{du}{dx}) = f$  in  $H_0^1(\Omega)$ .

Remark 2.3.8. From the min formulae (1.34), we see that  $\sigma \mapsto \lambda_k(\sigma)$  is upper-semi continuous for the weak-\* convergence (as infimum of continuous functions), but the previous theorem shows that it is not continuous in general. More generally, we will use later (even in higher dimension) this kind of result, see Proposition 8.1.3 as an example.

#### 2.3.3 Continuity with variable domains (Dirichlet case)

As seen in Theorem 2.3.2, the convergence of eigenvalues for variable domains is closely related to the continuity of the solution of the Dirichlet problem with respect to the domain (the so-called  $\gamma$ -convergence). This question is now well understood, beginning with the pioneering paper [124] by M. Keldyš and going on with works by G. Dal Maso, U. Mosco, G. Buttazzo and the Italian school, D. Chenais, J.P. Zolesio, D. Bucur and the French school, V. Šverak, D. Daners, W. Arendt,... among others. For a complete study of this topic, we refer to [44], [104].

#### $\gamma$ -convergence

Let us begin with the definition of  $\gamma$ -convergence (for the Laplacian).

**Definition 2.3.9.** Let D be a fixed ball,  $\Omega_n \subset D$  a sequence of open sets and  $\Omega \subset D$  an open set. We say that  $\Omega_n$   $\gamma$ -converges to  $\Omega$  (and we write  $\Omega_n \stackrel{\gamma}{\to} \Omega$ ) if, for every  $f \in L^2(D)$ , the solution  $u_{\Omega_n}^f$  of the Dirichlet problem for the Laplacian (1.6) on  $\Omega_n$  with right-hand side f converges (strongly) in  $L^2(D)$  to  $u_{\Omega}^f$ , the solution on  $\Omega$  (as usual, every function in  $H_0^1(\Omega_n)$  is extended by zero outside  $\Omega_n$ ).

In other words, using the notation of section 1.1.2,  $\Omega_n \stackrel{\gamma}{\to} \Omega$  if,  $\forall f \in L^2(D)$ ,  $A^D_{\Delta}(\Omega_n)(f) \to A^D_{\Delta}(\Omega)(f)$  in  $L^2(D)$ . We gather in the following theorem different characterizations of the  $\gamma$ -convergence. For the proof, we refer to [44], [104].

**Theorem 2.3.10.** The following properties are equivalent.

- (i)  $\Omega_n$   $\gamma$ -converges to  $\Omega$ .
- (ii) Šverak:  $A^D_{\Delta}(\Omega_n)(1) \to A^D_{\Delta}(\Omega)(1)$  in  $L^2(D)$  (i.e. the convergence takes place for f=1).

- (iii) Mosco convergence:  $H_0^1(\Omega_n)$  converges in the sense of Mosco to  $H_0^1(\Omega)$  i.e.
  - (M1) For every  $v \in H_0^1(\Omega)$ , there exists a sequence  $v_n$ ,  $v_n \in H_0^1(\Omega_n)$  such that  $v_n \to v$  (strong convergence in  $H_0^1(D)$ ).
  - (M2) For every sub-sequence  $v_{n_k}$  of functions in  $H^1_0(\Omega_{n_k})$  which converges weakly to a function  $v \in H^1_0(D)$ , then  $v \in H^1_0(\Omega)$ .
- (iv) **Distance to**  $H_0^1$ :  $\forall \varphi \in H_0^1(D)$ ,  $d(\varphi, H_0^1(\Omega)) = \lim_{n \to +\infty} d(\varphi, H_0^1(\Omega_n))$  (where  $d(\varphi, X)$  denotes, as usual, the distance of  $\varphi$  to the convex set X).
- (v) **Projection on**  $H_0^1$ :  $\forall \varphi \in H_0^1(D)$ ,  $\operatorname{proj}_{H_0^1(\Omega)}(\varphi) = \lim_{n \to +\infty} \operatorname{proj}_{H_0^1(\Omega_n)}(\varphi)$  (where  $\operatorname{proj}_X(\varphi)$  denotes the projection of  $\varphi$  on the convex set X).
- (vi)  $\Gamma$ -convergence:  $J_{\Omega_n}$   $\Gamma$ -converge to  $J_{\Omega}$  where, for an open set  $\omega \subset D$ ,  $J_{\omega}$  is defined by

$$J_{\omega}(v) = \frac{1}{2} \int_{D} |\nabla v(x)|^{2} dx - \int_{D} fv(x) dx + \begin{cases} 0 & \text{if } v \in H_{0}^{1}(\omega), \\ +\infty & \text{else,} \end{cases}$$

and the  $\Gamma$ -convergence means:

- (G1)  $\forall v_n \to v \quad J_{\Omega}(v) \leq \liminf J_{\Omega_n}(v_n),$
- (G2)  $\exists v_n \to v \quad J_{\Omega}(v) \ge \limsup J_{\Omega_n}(v_n).$
- (vii) (Strong) Convergence of resolvant operators:  $||A_{\Delta}^{D}(\Omega_{n}) A_{\Delta}^{D}(\Omega)|| \to 0$ . Applying Theorem 2.3.2, we have:

**Corollary 2.3.11.** If any of the above items (i)–(vii) is true, then  $\lambda_k(\Omega_n) \to \lambda_k(\Omega)$ .

**Remark 2.3.12.** Actually, each of the items (M1) and (M2) of the Mosco convergence (see (iii)) ensures semi-continuity for eigenvalues (see [44]). More precisely, we can prove:

$$\begin{cases} \text{ If (M1) holds,} & \limsup_{n \to +\infty} \lambda_k(\Omega_n) \leq \lambda_k(\Omega) \text{ (upper semi-continuity).} \\ \text{ If (M2) holds,} & \liminf_{n \to +\infty} \lambda_k(\Omega_n) \geq \lambda_k(\Omega) \text{ (lower semi-continuity).} \end{cases}$$
 (2.27)

#### Hausdorff distance

Even if Theorem 2.3.10 gives many characterizations of the  $\gamma$ -convergence, and therefore necessary and sufficient conditions for continuity of eigenvalues, none of them is really simple and of practical use. Actually, in practice, we often have sequences of domains defined by geometric means for which it can be hard to decide whether one of above conditions (i)–(vii) is satisfied.

This is the reason why we will give simple sufficient conditions ensuring continuity of eigenvalues. To study the convergence of a sequence of open sets, it is often very convenient to use the Hausdorff distance. Let us recall its definition. **Definition 2.3.13.** Let  $K_1$ ,  $K_2$  be two non-empty compact sets in  $\mathbb{R}^N$ . We set

$$\forall x \in \mathbb{R}^N, \ d(x, K_1) := \inf_{y \in K_1} |y - x|, \\ \rho(K_1, K_2) := \sup_{x \in K_1} d(x, K_2).$$

Then the Hausdorff distance of  $K_1$  and  $K_2$  is defined by

$$d^{H}(K_{1}, K_{2}) := \max(\rho(K_{1}, K_{2}), \rho(K_{2}, K_{1})). \tag{2.28}$$

We also have the two equivalent definitions:

$$d^{H}(K_{1}, K_{2}) = \inf\{\alpha > 0; K_{2} \subset K_{1}^{\alpha} \text{ and } K_{1} \subset K_{2}^{\alpha}\}$$
 (2.29)

where  $K^{\alpha} = \{x \in \mathbb{R}^N ; d(x, K) \leq \alpha\},\$ 

$$d^{H}(K_{1}, K_{2}) = \|d_{K_{1}} - d_{K_{2}}\|_{L^{\infty}(\mathbb{R}^{N})} = \|d_{K_{1}} - d_{K_{2}}\|_{L^{\infty}(K_{1} \cup K_{2})}$$
(2.30)

where, for any compact K, the function  $d_K$  is defined by  $d_K(x) = d(x, K)$ .

![](_page_38_Picture_10.jpeg)

Figure 2.2: Hausdorff distance of two compact sets:  $d^H(K_1, K_2) := \max(\rho(K_1, K_2), \rho(K_2, K_1)).$ 

For open sets, we define the Hausdorff distance through their complementary:

**Definition 2.3.14.** Let  $\Omega_1$ ,  $\Omega_2$  be two open subsets of a (large) compact set B. Then their Hausdorff distance is defined by:

$$d_H(\Omega_1, \Omega_2) := d^H(B \setminus \Omega_1, B \setminus \Omega_2). \tag{2.31}$$

One of the most useful property of the Hausdorff distance is the following compactness property (see [44], [104]):

**Theorem 2.3.15.** Let B be a fixed compact set in  $\mathbb{R}^N$  and  $\Omega_n$  a sequence of open subsets of B. Then, there exists an open set  $\Omega \subset B$  and a subsequence  $\Omega_{n_k}$  which converges for the Hausdorff distance to  $\Omega$ .

Remark 2.3.16. If a sequence of open sets  $\Omega_n$  converges for the Hausdorff distance to  $\Omega$ , then it can be proved that the Mosco condition (M1) (see Theorem 2.3.10) holds, see [44]. In other words, applying Remark 2.3.12, we see that the eigenvalues are upper semi-continuous for the Hausdorff convergence of open sets.

#### Sufficient conditions for continuity

The two first results we state show that there is continuity of eigenvalues for the Hausdorff distance when the domains are *uniformly regular*, see [54] or [104].

**Theorem 2.3.17 (convex case).** Let B be a fixed compact set in  $\mathbb{R}^N$  and  $\Omega_n$  be a sequence of convex open sets in B which converges, for the Hausdorff distance, to a (convex) set  $\Omega$ . Then  $\Omega_n$   $\gamma$ -converge to  $\Omega$  and, in particular, for all k fixed,  $\lambda_k(\Omega_n) \to \lambda_k(\Omega)$ .

**Theorem 2.3.18 (Chenais).** Let B be a fixed compact set in  $\mathbb{R}^N$  and  $\Omega_n$  be a sequence of open subsets of B. Assume that the sets  $\Omega_n$  are **uniformly Lipschitz** (it means that the boundary of  $\Omega_n$  is locally the graph of a Lipschitz function and that we can take a **uniform** Lipschitz constant L for all these Lipschitz functions and for all the sets  $\Omega_n$ ). Assume moreover that  $\Omega_n$  converges, for the Hausdorff distance, to  $\Omega$ . Then  $\Omega_n$   $\gamma$ -converge to  $\Omega$  and, in particular for all k fixed,  $\lambda_k(\Omega_n) \to \lambda_k(\Omega)$ .

In two-dimensions, there is a nice result due to V. Šverak which gives continuity with weaker assumptions, see [194], [104]. Roughly speaking, it says that if the number of holes in the sequence  $\Omega_n$  is uniformly bounded and if  $\Omega_n$  converges for the Hausdorff distance, then there is convergence of eigenvalues. To be more precise, let us introduce, for any open set  $\Omega$  (whose complementary is denoted by  $\Omega^c$ ):

 $\sharp \Omega^c :=$  number of connected components of  $\Omega^c$ .

**Theorem 2.3.19 (Šverak).** Let B be a fixed compact set in  $\mathbb{R}^2$  and  $\Omega_n$  a sequence of open subsets of B. Let p be a given integer and assume that the sets  $\Omega_n$  satisfy  $\sharp \Omega_n^c \leq p$ . Then, if the sets  $\Omega_n$  converge for the Hausdorff distance to a set  $\Omega$ , they  $\gamma$ -converge to  $\Omega$  and, in particular, for all k fixed,  $\lambda_k(\Omega_n) \to \lambda_k(\Omega)$ .

As an example of application, let us now give a continuity result which will be useful in several situations. In particular, it will show that adding a connectedness constraint generally does not change anything in minimization problems.

**Theorem 2.3.20.** Let  $\Omega_1$  and  $\Omega_2$  be two disjoint open sets in  $\mathbb{R}^N$ ,  $N \geq 2$  and let  $\Sigma$  be a segment joining  $\Omega_1$  and  $\Omega_2$ . Let  $\varepsilon$  be a (small) positive number and let us denote by  $\Omega_{\varepsilon}$  the open set

$$\Omega_{\varepsilon} = \bigcup_{x \in \Sigma} B(x, \varepsilon) \cup \Omega_1 \cup \Omega_2$$

obtained by joining the sets  $\Omega_1$  and  $\Omega_2$  by a small tube of width  $\varepsilon$ , see Figure 2.3. Then, for every integer k,

$$\lambda_k(\Omega_{\varepsilon}) \to \lambda_k(\Omega_1 \cup \Omega_2) \quad \text{when } \varepsilon \to 0 \ .$$

*Proof.* First of all, it is clear, coming back to the definition, that  $\Omega_{\varepsilon}$  converge, for the Hausdorff distance to  $\Omega_1 \cup \Omega_2$ . Therefore, the two-dimensional case is an easy

32 Chapter 2. Tools

![](_page_40_Picture_1.jpeg)

Figure 2.3: The eigenvalues of the connected set  $\Omega_{\varepsilon}$  converge to the eigenvalues of  $\Omega_1 \cup \Omega_2$ .

consequence of Šverak Theorem 2.3.19. The N-dimensional case requires more analysis. In particular, it needs some tools related to capacity and fine properties of Sobolev spaces (see also section 2.4). For that reason, we just give a sketch of the proof, referring to [44] and [104] for more details. According to Remark 2.3.16, we see that condition (M1) of the Mosco convergence already holds thanks to the Hausdorff convergence. Therefore, it remains to prove (M2) of Mosco convergence to be able to apply Theorem 2.3.10. Let  $v_{\varepsilon_k}$  be a sequence in  $H^1_0(\Omega_{\varepsilon_k})$  which converges weakly to v in  $H^1_0(D)$  (D being a ball containing all the  $\Omega_{\varepsilon}$ ). According to Mazur's Lemma, there exists a sequence of convex combination of the  $v_{\varepsilon_k}$  which converges strongly to v in  $H^1_0(D)$  and then (up to a subsequence) quasieverywhere. Therefore, since all the functions  $v_{\varepsilon_k}$ ,  $k \geq k_0$  are equal to zero on  $\Omega_{\varepsilon_{k_0}}$ , we first get that v vanishes quasi-everywhere on  $\Omega_{\varepsilon_{k_0}}$  (for all  $k_0$ ) and then on the complementary of  $\Omega_1 \cup \Omega_2 \cup \Sigma$ . But, in dimension  $N \geq 3$ , the segment  $\Sigma$  has zero capacity, therefore v vanishes quasi-everywhere on the complementary of  $\Omega_1 \cup \Omega_2$  which implies, that v belongs to  $H^1_0(\Omega_1 \cup \Omega_2)$  what proves (M2) and the result.  $\square$ 

Remark 2.3.21 (Quantitative estimates). Up to now, we gave qualitative results ensuring convergence of eigenvalues with respect to the domain. In some cases, it could be interesting to get more precise quantitative estimates. Of course, it is harder and generally needs some uniform regularity. For example, let us give here such an estimate due to Cox-Ross for star-shaped domains, see [68]:

**Proposition 2.3.22.** Assume  $\Omega_1$  and  $\Omega_2$  are two open star-shaped domains in  $\mathbb{R}^2$  defined by two radial functions  $f_1$  and  $f_2$  satisfying  $f_1, f_2 \geq \rho > 0$  and  $||f_1 - f_2||_{\infty} \leq \rho$ ; then

$$|\lambda_k(\Omega_1) - \lambda_k(\Omega_2)| \le (3/\rho)\lambda_k(D_\rho)||f_1 - f_2||_{\infty}$$

where  $D_{\rho}$  is a disk of radius  $\rho$ .

For other quantitative estimates, maybe the simpler is to come back to norm of resolvant operators. Therefore, if  $\Omega_1$  and  $\Omega_2$  are two open sets, we have, thanks to (2.20),

$$\left| \frac{1}{\lambda_h^D(L, \Omega_2)} - \frac{1}{\lambda_h^D(L, \Omega_1)} \right| \le \|A_L^D(\Omega_2) - A_L^D(\Omega_1)\|$$

which gives, if we assume moreover that  $\Omega_1$  and  $\Omega_2$  both contain a ball of radius  $\rho$ :

$$\left|\lambda_k^D(L,\Omega_2) - \lambda_k^D(L,\Omega_1)\right| \leq \lambda_k^2(D_\rho) \|A_L^D(\Omega_2) - A_L^D(\Omega_1)\| \ .$$

#### Other operators

It is remarkable that  $\gamma$ -convergence for the Laplacian implies the same kind of convergence for more general elliptic operators. It can be easily shown by using characterization (iii) of Theorem 2.3.10. Actually, Mosco convergence of the underlying spaces is certainly the best concept to extend continuity results for general elliptic operators. We refer as usual to [44], [104] for the following result.

**Theorem 2.3.23.** Let B be a fixed compact set in  $\mathbb{R}^N$  and  $\Omega_n$  a sequence of open subsets of B. Let L be an elliptic operator defined by (1.4). Then, if  $\Omega_n$   $\gamma$ -converges to a set  $\Omega$  (in the sense of Definition 2.3.9 or Theorem 2.3.10), we have convergence of eigenvalues:

for all k fixed 
$$\lambda_k^D(L,\Omega_n) \to \lambda_k^D(L,\Omega)$$
.

We can state the same result for the linear elasticity operator. Let us recall the definition of this operator in  $\mathbb{R}^3$ .

Let  $\Omega$  be an open set, we denote by  $H_0^1(\Omega; \mathbb{R}^3)$  the space of vector functions  $u = (u_1, u_2, u_3)$  such that  $u_i \in H_0^1(\Omega)$  for i = 1, 2, 3. For  $u \in H_0^1(\Omega; \mathbb{R}^3)$ , we set Du the Jacobian matrix of u with entries  $\frac{\partial u_i}{\partial x_j}$  and  $\mathbf{e}(u) = \frac{1}{2}(Du + t^t Du)$ . Then the linear elasticity operator  $\mathcal{E}$  is defined by

$$\mathcal{E}(u) := -\text{div}(A\mathbf{e}(u))$$

where A is the (linear) elasticity tensor defined by

$$A := 2\mu \mathrm{Id}_4 + \lambda \mathrm{Id}_2 \otimes \mathrm{Id}_2$$

where  $\lambda, \mu$  are the Lamé constants of the body  $\Omega$ . Then, we can prove, see [48]:

**Theorem 2.3.24.** Let B be a fixed compact set in  $\mathbb{R}^3$  and  $\Omega_n$  a sequence of open subsets of B. Let  $\mathcal{E}$  be the linear elasticity tensor defined above. Then, if  $\Omega_n$   $\gamma$ -converges to a set  $\Omega$  (in the sense of Definition 2.3.9 or Theorem 2.3.10), we have convergence of the (Dirichlet) eigenvalues of  $\mathcal{E}$ :

for all k fixed 
$$\lambda_k^D(\mathcal{E}, \Omega_n) \to \lambda_k^D(\mathcal{E}, \Omega)$$
.

#### 2.3.4 The case of Neumann eigenvalues

The Neumann case is much more complicated than the Dirichlet case. We can say that it is not completely understood to this day, see nevertheless [49]. The difficulty has several origins. The first one is that small perturbations of the boundary can introduce low eigenvalues which "pollute" the spectrum. As an illustration, let us recall the classical example of Courant-Hilbert, [58], see Figure 2.4. In this

34 Chapter 2. Tools

![](_page_42_Picture_1.jpeg)

Figure 2.4: The Neumann eigenvalues of the set  $\Omega_{\varepsilon}$  do not converge to the eigenvalues of the unit square (although Dirichlet eigenvalues do).

example,  $\Omega$  is the unit square and  $\Omega_{\varepsilon}$  is obtained by joining the unit square to a small square of length  $\varepsilon$  through a thin channel of (fixed) length l > 0 and width  $\varepsilon^3$ . Then, it is clear that  $\Omega_{\varepsilon}$  converges for the Hausdorff distance to  $\Omega$ , but the Neumann eigenvalues do not converge to the corresponding one. Actually, we choose a test function  $\phi_{\varepsilon}$  which is constant on each square, such as

$$\phi_{\varepsilon}(x,y) = \begin{cases} c_1 := \varepsilon^2 + l\varepsilon^3/2 & \text{on the unit square } \Omega = (-1,0) \times (-1,0), \\ \frac{(c_2 - c_1)}{l} x + c_1 & \text{on the channel } (x \in [0,l]), \\ c_2 := -1 - l\varepsilon^3/2 & \text{on the small square.} \end{cases}$$

We have  $\int_{\Omega_{\varepsilon}} \phi_{\varepsilon} = 0$ , then according to (1.37):

$$\mu_2(\Omega_{\varepsilon}) \le \frac{\int_{\Omega_{\varepsilon}} |\nabla \phi_{\varepsilon}|^2}{\int_{\Omega_{\varepsilon}} \phi_{\varepsilon}^2} \le \frac{(c_2 - c_1)^2 \varepsilon^3 / l}{c_1^2 + c_2^2 \varepsilon^2}$$

and the right-hand side tends to 0 when  $\varepsilon \to 0$ . This shows that  $\mu_2(\Omega_{\varepsilon}) \to 0$  while  $\mu_2(\Omega) = \pi^2$  and convergence does not take place.

There are many other examples of the same kind in the literature and, more generally, a study of domains composed of channels and rooms is considered, for example in [101].

The above example shows another big difference with the Dirichlet case. In this example, it can be proved that we would have some kind of  $\gamma$ -convergence of  $\Omega_{\varepsilon}$  to  $\Omega$ , namely that the solutions of the Neumann problem on  $\Omega_{\varepsilon}$  converge to the solution of the Neumann problem on  $\Omega$ , see e.g. [44], [52]. In other terms, the resolvant operators  $A_{\Delta}^{N}(\Omega_{\varepsilon})$  (corresponding to Neumann boundary conditions) converge pointwise to  $A_{\Delta}^{N}(\Omega)$ . But here, this pointwise convergence does not imply convergence in norm as in Theorem 2.3.2.

To conclude this section, let us give some sufficient conditions which ensure continuity or semi-continuity of Neumann eigenvalues. **Theorem 2.3.25 (Chenais).** Let B be a fixed compact set in  $\mathbb{R}^N$  and  $\Omega_n$  a sequence of open subsets of B. Assume that the sets  $\Omega_n$  are **uniformly Lipschitz** (see Theorem 2.3.18). Assume moreover that  $\Omega_n$  converges, for the Hausdorff distance, to  $\Omega$ . Then, for all k fixed,  $\mu_k(\Omega_n) \to \mu_k(\Omega)$ .

Actually, in this "uniform" case, we can prove that pointwise convergence of the resolvant operators implies strong convergence since we have uniformly bounded extension operators from  $H^1(\Omega_n)$  to  $H^1(B)$ , see [54]. Then the proof follows by the same argument as in Theorem 2.3.2.

Let us finish by an upper-semi continuity result in  $\mathbb{R}^2$  for which we refer to [44]. This kind of result could be useful for *maximization* problems which involve Neumann eigenvalues, see chapter 7.

**Theorem 2.3.26.** Let B be a fixed compact set in  $\mathbb{R}^2$  and  $\Omega_n$  a sequence of open subsets of B. Let p be a given integer and assume that the sets  $\Omega_n$  satisfy  $\sharp \Omega_n^c \leq p$  (the number of connected components of  $\Omega_n^c$  is uniformly bounded). Assume moreover that the perimeter of  $\Omega_n$  is uniformly bounded. If the sets  $\Omega_n$  converge for the Hausdorff distance to a set  $\Omega$  and  $|\Omega_n| \to |\Omega|$  (the measure of  $\Omega_n$  converges to the measure of  $\Omega$ ), then

for all k fixed 
$$\limsup_{n \to +\infty} \mu_k(\Omega_n) \le \mu_k(\Omega)$$
.

#### 2.4 Two general existence theorems

Let us come back to minimization problems for eigenvalues of the Dirichlet-Laplacian. In that context, we state two general existence theorems. The first one deals with convex domains, while the second one, due to G. Buttazzo and G. Dal Maso in [50], is more general. Let us begin with the case of convex domains.

**Theorem 2.4.1.** Let c be a positive constant and k any integer. Then there exists a convex domain  $\Omega^*$  such that

$$\lambda_k(\Omega^*) = \min\{\lambda_k(\Omega), \Omega \subset \mathbb{R}^N, \Omega \text{ convex, } |\Omega| = c\}.$$

Proof. We use the classical method of calculus of variations. Let  $\Omega_n$  be a minimizing sequence. First of all, we claim that the diameters of the  $\Omega_n$  are bounded. Indeed, let us define the width of  $\Omega_n$  as the maximum diameter of any section of  $\Omega_n$  with a hyperplane orthogonal to the segment which realizes the diameter. Then, by convexity property and the fact that all the domains  $\Omega_n$  have a given volume, if the diameters of  $\Omega_n$  would not be bounded, the width of  $\Omega_n$  would have to go to zero. Therefore, we could find a sequence of parallelepiped (or cylinders), containing  $\Omega_n$  and with, at least, one dimension going to zero. But for such parallelepiped, the value of  $\lambda_1$  is known (see section 1.2.5) and it goes to  $+\infty$ . Therefore, by the monotonicity property, we would have  $\lambda_k(\Omega_n) \to +\infty$ .

Since the diameters are bounded, we can assume (up to a translation) that the whole sequence is contained in a fixed ball, say B. By Theorem 2.3.15, there exists a convex domain  $\Omega^*$  and a subsequence, still denoted by  $\Omega_n$  such that  $\Omega_n$  converges to  $\Omega^*$  for the Hausdorff metric. Then, by Theorem 2.3.17,  $\lambda_k(\Omega_n) \to \lambda_k(\Omega^*)$ . Moreover, it is easy to see that the characteristic functions of  $\Omega_n$  converge to the characteristic function of  $\Omega^*$  in  $L^1(B)$ . In particular,  $|\Omega_n| \to |\Omega^*|$  and  $|\Omega^*| = c$ . This finishes the proof.

**Remark 2.4.2.** The previous existence theorem extends straightforwardly to functions of eigenvalues like  $F(\lambda_1, \ldots, \lambda_k)$  provided  $F(\lambda_1, \ldots, \lambda_k) \to +\infty$  when each  $\lambda_i \to +\infty$ .

For the previous proof, we can also use the quantitative estimates stated in Proposition 2.3.22. Now, let us consider the general existence Theorem due to G. Buttazzo and G. Dal Maso, see [50], see also [44], [104]. This existence result is not stated in the class of open sets, but in the wider class of *quasi-open* sets. This is a good framework to make a precise study of the Dirichlet problem for elliptic operators of second order. In this textbook, we do not want to enter too much into the details. We just give the main definitions, referring for example to [44], [104] for details, examples and proofs. Let us begin with the definition of the capacity.

**Definition 2.4.3** ( $H^1$ -capacity). Let D be a bounded open set in  $\mathbb{R}^N$ , we define the capacity  $\operatorname{cap}_D(E)$  (relatively to D) of any subset E of D in the following way: For any compact K into D, we set

$$\operatorname{cap}_{D}(K) = \inf \{ \int_{D} |\nabla v|^{2}; \quad v \in C_{0}^{\infty}(D), v \ge 1 \text{ sur } K \} < +\infty.$$
 (2.32)

For  $\omega$  an open subset of D, we set

$$cap_D(\omega) := \sup\{cap_D(K); \quad K \text{ compact }, K \subset \omega\}. \tag{2.33}$$

At last, if E is any subset of D, we set

$$cap_D(E) := \inf\{cap_D(\omega); \quad \omega \text{ open }, E \subset \omega\}. \tag{2.34}$$

Roughly speaking, the capacity plays the same role for the Sobolev space  $H^1$  as the Lebesgue measure for the space  $L^2$ . Let us now give the definition of quasi-open sets.

**Definition 2.4.4.** A subset  $\Omega$  of D is quasi-open if there exists a decreasing sequence of open sets  $\omega_n$  such that

$$\lim_{n \to +\infty} \operatorname{cap}_D(\omega_n) = 0, \quad \forall n \text{ and } \Omega \cup \omega_n \text{ is open.}$$

As a fundamental example, for every  $u \in H^1(D)$  and for every  $\alpha \in \mathbb{R}$ , the set

$$[u > \alpha] := \{x \in D, \ u(x) > \alpha\}$$

is quasi-open. Moreover, the theory of elliptic operators and eigenvalues can be extended to the framework of quasi-open sets.

We can now give the existence result of Buttazzo and Dal Maso. Let us consider a fixed open set D and a positive number c with c < |D|. We will denote by A<sup>c</sup> the class:

$$\mathcal{A}_c = \{ \omega \subset D, \ \omega \text{ quasi-open }, |\omega| = c \}.$$

**Theorem 2.4.5.** Let <sup>p</sup> be an integer and <sup>F</sup> be a function, <sup>F</sup> : <sup>R</sup><sup>p</sup> <sup>→</sup> <sup>R</sup>. We assume

- (i) F is lower semi-continuous,
- (ii) F is non-decreasing with respect to each of its arguments.

Then the problem: find Ω ∈ A<sup>c</sup> which minimizes J defined by

$$J(\omega) := F(\lambda_1(\omega), \lambda_2(\omega), \dots, \lambda_p(\omega))$$
 (2.35)

has a solution.

**Corollary 2.4.6.** Let k be an integer, the problem: find Ω ∈ A<sup>c</sup> such that

$$\lambda_k(\Omega) = \min\{\lambda_k(\omega), \ \omega \in \mathcal{A}_c\}$$
 (2.36)

has a solution.

#### **2.5 Derivatives of eigenvalues**

#### **2.5.1 Introduction**

As soon as we want to write optimality conditions for extremum problems involving eigenvalues, we need formulae for derivatives of eigenvalues. The question of differentiability of eigenvalues depending on a parameter has been widely studied. A classical reference is [121]. A little bit less classical is the case where the parameter is the shape of the domain. Nevertheless, many papers are devoted to that question, see e.g. [182], [190], [191], [193]. We will present the two aspects here, giving classical formulae.

Of course, the differentiability of an eigenvalue (in a classical sense) can only be proved when the eigenvalue is simple. We can easily understand that fact by looking at a very simple finite-dimensional situation. Let A<sup>t</sup> be the 2 × 2 matrix defined by

$$A_t = \left(\begin{array}{cc} 1+t & 0 \\ 0 & 1-t \end{array}\right)$$

The matrix <sup>A</sup>0 <sup>=</sup> <sup>I</sup> has a double eigenvalue. The first eigenvalue of <sup>A</sup><sup>t</sup> (its smallest one) <sup>λ</sup>1 is 1 <sup>−</sup> <sup>t</sup> if <sup>t</sup> <sup>≥</sup> 0 and 1 + <sup>t</sup> if <sup>t</sup> <sup>≤</sup> 0, and then

$$\lambda_1(A_t) = 1 - |t|$$
  $\lambda_2(A_t) = 1 + |t|$ ,

we observe that  $t \to \lambda_1(A_t)$  is not differentiable at t = 0. This cannot happen for a matrix with simple eigenvalues. Actually, when we look closer at the eigenvalues of the matrix  $A_t$ , we see that there exist two "branches" (in this case two segments) crossing at 1 and, on each of these branches, the function  $t \to \lambda_1(A_t)$  is differentiable (and even analytic). In other words, we can re-number the eigenvalues in order to get differentiability. This situation is actually general. We will discuss the case of multiple eigenvalues in subsection 2.5.3. We give now the formulae for the first and second derivatives of eigenvalues. For the proofs, we refer to the above references and also to the more recent book, [104].

#### 2.5.2 Derivative with respect to the domain

Let us begin with the derivative of an eigenvalue with respect to the domain. We consider an open set  $\Omega$  and a family of applications  $\Phi(t)$  satisfying

$$\Phi: t \in [0, T[ \to W^{1,\infty}(\mathbb{R}^N, \mathbb{R}^N)]$$
 differentiable at 0 with  $\Phi(0) = I, \Phi'(0) = V$  (2.37)

where  $W^{1,\infty}(\mathbb{R}^N,\mathbb{R}^N)$  is the set of bounded Lipschitz maps from  $\mathbb{R}^N$  into itself, I is the identity and V a vector field. For t small,  $\Phi(t)$  is a diffeomorphism. For example, it is classical to choose

$$\Phi(t) = I + tV .$$

Let us denote by  $\Omega_t = \Phi(t)(\Omega)$  and by  $\lambda_k(t) = \lambda_k(\Omega_t)$  (resp.  $\mu_k(t)$ ) the k-th eigenvalue of the Laplacian on  $\Omega_t$  with Dirichlet (resp. Neumann) boundary conditions. We assume that  $\lambda_k(t)$  (or  $\mu_k(t)$ ) is simple (for t small) and, since k is fixed in the sequel of this section, we denote by  $u_t$  an associated eigenfunction in  $H_0^1(\Omega_t)$  or in  $H^1(\Omega_t)$  according to the situation, with the normalization

$$\int_{\Omega_t} u_t^2(x) \, dx = 1. \tag{2.38}$$

Then, we have

Theorem 2.5.1 (First derivative of a Dirichlet eigenvalue). Let  $\Omega$  be a bounded open set. We assume that  $\lambda_k(\Omega)$  is simple. Then, the functions  $t \to \lambda_k(t)$ ,  $t \to u_t \in L^2(\mathbb{R}^N)$  are differentiable at t = 0 with

$$\lambda_k'(0) := -\int_{\Omega} div(|\nabla u|^2 V) \, dx \,. \tag{2.39}$$

If, moreover,  $\Omega$  is of class  $C^2$  or if  $\Omega$  is convex, then

$$\lambda_k'(0) := -\int_{\partial\Omega} \left(\frac{\partial u}{\partial n}\right)^2 V.n \, d\sigma \tag{2.40}$$

and the derivative u' of  $u_t$  is the solution of

$$\begin{cases}
-\Delta u' = \lambda_k u' + \lambda'_k u & \text{in } \Omega, \\
u' = -\frac{\partial u}{\partial n} V.n & \text{on } \partial \Omega, \\
\int_{\Omega} u \, u' \, d\sigma = 0.
\end{cases}$$
(2.41)

**Remark 2.5.2.** If the Laplacian is replaced by the more general linear elliptic operator L as defined in (1.4), the formulae for the first derivative becomes:

$$\lambda_k'(0) = -\int_{\partial\Omega} \left( \sum_{i,j=1}^N a_{i,j} \frac{\partial u}{\partial x_j} n_i \right) V.n \, d\sigma . \tag{2.42}$$

In the sequel, we will also use the formulae for the derivative of the volume.

**Theorem 2.5.3 (Derivative of the volume).** Let  $\Omega$  be a bounded open set and  $Vol(t) := |\Omega_t|$  the volume of  $\Omega_t$ . Then, the function  $t \to Vol(t)$  is differentiable at t = 0 with

$$Vol'(0) := \int_{\Omega} div(V) dx. \qquad (2.43)$$

Moreover, if  $\Omega$  is Lipschitz,

$$Vol'(0) := \int_{\partial\Omega} V.n \, d\sigma . \tag{2.44}$$

Corollary 2.5.4. Let  $\Omega$  be a convex or  $C^2$  domain in  $\mathbb{R}^N$  which minimizes an eigenvalue  $\lambda_k$  among all open sets of given volume. Assume that the eigenvalue  $\lambda_k(\Omega)$  is simple. Then, there exists a constant c such that the eigenfunction  $u_k$  satisfies

$$\left| \frac{\partial u_k}{\partial n} \right| = c \quad on \ \partial\Omega \ . \tag{2.45}$$

Indeed, if  $\Omega$  minimizes  $\lambda_k$  under the constraint  $Vol(\Omega) = A$ , there exists a Lagrange multiplier C such that  $\lambda'_k(0) = CVol'(0)$  which reads

$$-\int_{\partial\Omega} \left(\frac{\partial u_k}{\partial n}\right)^2 V.n \, d\sigma = C \int_{\partial\Omega} V.n \, d\sigma$$

for any vector field V in  $W^{1,\infty}(\mathbb{R}^N)$  (we know that the eigenfunction  $u_k$  belongs to the Sobolev space  $H^2(\Omega)$  by classical regularity results, see section 1.2.4). But this implies  $-\left(\frac{\partial u}{\partial n}\right)^2=C$  which gives the desired result with  $c=\sqrt{-C}$ .

**Remark 2.5.5.** It is easy to see that the above constant c cannot be zero (for example using the classical formulae  $\lambda_k = \frac{1}{2} \int_{\partial \Omega} \left( \frac{\partial u}{\partial n} \right)^2 X.n \, d\sigma$ ). Therefore, for a minimizer of  $\lambda_k$ :

• either  $\lambda_k$  is double (see Open problem 1)

• or no nodal line of  $u_k$  hits the boundary (otherwise we would have c=0).

In some situations, we also need the second derivative of an eigenvalue. This is the case, for example, when we want to express that a shape is a true minimum by looking at the positivity of the quadratic form expressing the second derivative with respect to the domain. Conversely, it could be useful to prove that a critical point (i.e. a shape for which the above first derivative vanishes) is not a minimum. We give the formulae for the second derivative in this particular case of a critical point. The general formulae is more complicated, we refer to [182] or [104] for the general case and for proofs.

**Theorem 2.5.6 (Second derivative of a Dirichlet eigenvalue).** Let  $\Omega$  be a bounded open set of class  $C^3$ . We assume that  $\lambda_k(\Omega)$  is simple and that  $\Omega$  is a critical point for  $\lambda_k$ . We denote  $\Omega_t = (I + tV)(\Omega)$  and  $\lambda_k(t) = \lambda_k(\Omega_t)$ . Then, the function  $t \to \lambda_k(t)$ , is twice differentiable at t = 0 with

$$\lambda_k''(0) := \int_{\partial\Omega} 2w(\varphi) \frac{\partial w(\varphi)}{\partial n} + \varphi^2 H \left(\frac{\partial u}{\partial n}\right)^2 d\sigma , \qquad (2.46)$$

where H is the mean curvature of  $\partial\Omega$ ,  $\varphi = V.n$  and  $w(\varphi)$  is the solution of

$$\begin{cases} -\Delta w(\varphi) = \lambda_k w(\varphi) - u \int_{\partial \Omega} \left(\frac{\partial u}{\partial n}\right)^2 \varphi \, d\sigma & \text{in } \Omega, \\ w(\varphi) = -\varphi \frac{\partial u}{\partial n} & \text{on } \partial \Omega, \int_{\Omega} u \, w(\varphi) \, dx = 0. \end{cases}$$

The existence of  $w(\varphi)$  is a consequence of the Fredholm alternative, see section 1.2.6.

Let us now consider the Neumann case. Since the boundary condition is more complicated, we only give the formulae for the first derivative and for the Laplacian operator.

Theorem 2.5.7 (First derivative of a Neumann eigenvalue). Let  $\Omega$  be a bounded open set. We assume that  $\mu_k(\Omega)$  is simple. Then, the functions  $t \to \mu_k(t)$ ,  $t \to u_t \in L^2(\omega)$  with  $\omega$  an open set such that  $\overline{\omega} \subset \Omega$ , are differentiable at t = 0 with

$$\mu_k'(0) := \int_{\Omega} div \left( (|\nabla u|^2 - \mu_k u^2) V \right) dx . \tag{2.47}$$

If, moreover,  $\Omega$  is of class  $C^3$ , then

$$\mu_k'(0) := \int_{\partial\Omega} \left( |\nabla u|^2 - \mu_k u^2 \right) V.n \, d\sigma \tag{2.48}$$

and the derivative u' of  $u_t$  is the solution of

$$\begin{cases}
-\Delta u' = \lambda_k u' + \lambda'_k u & \text{in } \Omega, \\
\frac{\partial u'}{\partial n} = -\frac{\partial^2 u}{\partial n^2} V.n + \nabla u.\nabla_{\Gamma}(V.n) & \text{on } \partial\Omega, \\
2 \int_{\Omega} u u' dx + \int_{\partial\Omega} u^2 V.n d\sigma = 0,
\end{cases} (2.49)$$

where  $\nabla_{\Gamma}$  denotes the tangential gradient.

#### 2.5.3 Case of multiple eigenvalues

As we have seen in the Introduction of this section, a multiple eigenvalue is no longer differentiable in a classical sense. Therefore, two strategies can be considered.

- We use the sub-differential.
- We look at directional derivatives.

The first strategy is explained, for example, in [53], [62] where the sub-differential is computed. We choose here to present the second strategy, since it will be useful in the sequel. The following result is proved in [180] or [153].

**Theorem 2.5.8 (Derivative of a multiple eigenvalue).** Let  $\Omega$  be a bounded open set of class  $C^2$ . Assume that  $\lambda_k(\Omega)$  is a multiple eigenvalue of order  $p \geq 2$ . Let us denote by  $u_{k_1}, u_{k_2}, \ldots, u_{k_p}$  an orthonormal (for the  $L^2$  scalar product) family of eigenfunctions associated to  $\lambda_k$ . Let  $\Phi(t)$  satisfy (2.37) with V fixed and  $\Omega_t = \Phi(t)(\Omega)$ . Then  $t \to \lambda_k(\Omega_t)$  has a (directional) derivative at t = 0 which is one of the eigenvalues of the  $p \times p$  matrix  $\mathcal{M}$  defined by:

$$\mathcal{M} = (m_{i,j}) \quad \text{with } m_{i,j} = -\int_{\partial\Omega} \left( \frac{\partial u_{k_i}}{\partial n} \frac{\partial u_{k_j}}{\partial n} \right) V.n \, d\sigma \quad i, j = 1, \dots, p. \quad (2.50)$$

Of course, this theorem contains the case of a simple eigenvalue, since the matrix  $\mathcal{M}$  has then a single entry which is exactly (2.40). When  $\lambda_k$  is a multiple eigenvalue, the directional derivative depends on the choice of the vector field V: changing V makes a shift from one eigenvalue to the other of the matrix  $\mathcal{M}$ . This means that  $V \mapsto \lambda_k'(0)$  is no longer a linear form which is another way to express the non-differentiability of  $t \to \lambda_k(t)$  at t = 0.

Let us give an important consequence of this theorem concerning the simplicity of eigenvalues for optimal domains. We begin by a lemma.

**Lemma 2.5.9.** Let  $\Omega$  be an open set of class  $C^{1,1}$ . We assume that  $\Omega$  has a multiple eigenvalue of order m:

$$\lambda_{k+1}(\Omega) = \lambda_{k+2}(\Omega) = \dots = \lambda_{k+m}(\Omega) \quad k \ge 1.$$

Then, we can always find a deformation field  $V \in C^{1,1}(\mathbb{R}^N, \mathbb{R}^N)$ , preserving the volume and such that, if we set

$$\Omega_t = (Id + tV)(\Omega),$$

we have, for t > 0 small enough,

$$\lambda_{k+1}(\Omega_t) < \lambda_{k+1}(\Omega) = \lambda_{k+m}(\Omega) < \lambda_{k+m}(\Omega_t)$$
.

*Proof.* We use Theorem 2.5.8. We know that the directional derivatives of  $t \mapsto \lambda_{k+p}(\Omega_t)$  are to be chosen among the eigenvalues of the  $m \times m$  matrix

$$\mathcal{M} = \left(-\int_{\partial\Omega} \frac{\partial u_i}{\partial n} \frac{\partial u_j}{\partial n} V.n \, d\sigma\right)_{k+1 \le i,j \le k+m} \tag{2.51}$$

where  $\frac{\partial u_i}{\partial n}$  denotes the normal derivative of the *i*-th eigenfunction  $u_i$  and V.n is the normal displacement of the boundary induced by the deformation field V.

Let us now choose two points A and B located on  $\partial\Omega$ . Let us consider a deformation field V such that V.n=1 in a small neighborhood of A (on the boundary of  $\Omega$ ) of size  $\varepsilon$ , V.n=-1 in a small neighborhood of B (with the same measure) and V regularized outside in a neighborhood of size  $2\varepsilon$  in such a way that  $|\Omega_t| = |\Omega|$  (it is always possible since the derivative of the volume is given by  $d\text{Vol} = \int_{\partial\Omega} V.n\,d\sigma$  which vanishes with an appropriate choice of the regularization). According to the above-mentioned results about the directional derivatives, the lemma will be proved if we can find two points A, B such that the symmetric matrix  $\mathcal{M}$  has both positive and negative eigenvalues. Now, when  $\varepsilon$  goes to 0, it is clear that the matrix  $\mathcal{M}$  behaves like the  $m \times m$  matrix

$$\mathcal{M}_{A,B} = \left(-\frac{\partial u_i}{\partial n} \left(A\right) \frac{\partial u_j}{\partial n} \left(A\right) + \frac{\partial u_i}{\partial n} \left(B\right) \frac{\partial u_j}{\partial n} \left(B\right)\right)_{k+1 \le i,j \le k+m}.$$
 (2.52)

Let us denote by  $\phi_A$  (resp.  $\phi_B$ ) the vector of components  $\frac{\partial u_i}{\partial n}(A)$ , (resp.  $\frac{\partial u_i}{\partial n}(B)$ ),  $i = k+1, \ldots, k+m$ . A straightforward computation gives, for any vector  $X \in \mathbb{R}^m$ :

$$X^T \mathcal{M}_{A,B} X = (X.\phi_B)^2 - (X.\phi_A)^2.$$

Therefore, the signature of the quadratic form defined by  $\mathcal{M}_{A,B}$  is (1,1) as soon as the vectors  $\phi_A$  and  $\phi_B$  are non-collinear. Now, assuming these two vectors to be collinear for every choice of points A, B would give the existence of a constant c such that, on a part  $\gamma$  of  $\partial\Omega$ :

$$\frac{\partial u_{k+1}}{\partial n} = c \frac{\partial u_{k+2}}{\partial n} .$$

But,  $u_{k+1} - c u_{k+2}$  would satisfy

$$\begin{cases}
-\Delta(u_{k+1} - c u_{k+2}) = \lambda_{k+1}(u_{k+1} - c u_{k+2}) & \text{in } \Omega, \\
u_{k+1} - c u_{k+2} = 0 & \text{on } \partial\Omega \cap \gamma, \\
\frac{\partial(u_{k+1} - c u_{k+2})}{\partial n} = 0 & \text{on } \partial\Omega \cap \gamma.
\end{cases}$$

Now, by the Hölmgren uniqueness theorem, the previous p.d.e. system is solvable only by  $u_{k+1} - c u_{k+2} = 0$  (first in a neighborhood of  $\gamma$  and then in the whole domain by analyticity) which gives the desired contradiction.

The previous result has the following consequence for minimization of eigenvalues:

**Theorem 2.5.10.** Let  $\Omega^*$  be an open set of class  $C^{1,1}$  minimizing the k-th eigenvalue (with a volume constraint) and assume that  $\lambda_k(\Omega^*)$  is not simple; necessarily we have

$$\lambda_{k-1}(\Omega^*) = \lambda_k(\Omega^*). \tag{2.53}$$

Indeed, if  $\lambda_k(\Omega^*)$  is not simple, let us assume that  $\lambda_{k-1}(\Omega^*) < \lambda_k(\Omega^*) = \lambda_{k+1}(\Omega^*)$ . Then, according to Lemma 2.5.9, we can find a perturbation of  $\Omega^*$  which diminishes  $\lambda_k(\Omega^*)$ : a contradiction.

Actually, numerical experiments seem to show that this relation holds in every case, see [164]: the domain which minimizes  $\lambda_k(\Omega)$ ,  $k \geq 2$  (with a volume constraint) always satisfies (2.53).

**Open problem 1.** Let  $k \geq 2$  and  $\Omega^*$  be an open set minimizing the k-th eigenvalue of the Laplacian-Dirichlet (with a volume constraint). Prove that  $\lambda_k(\Omega^*)$  is not simple (and therefore  $\lambda_{k-1}(\Omega^*) = \lambda_k(\Omega^*)$ ).

#### 2.5.4 Derivative with respect to coefficients

Instead of moving the domain, we can change the coefficients. It will be the situation in chapters 8, 9 and 10 where the unknown is no longer the shape of the domain, but the potential  $a_0(x)$  or some coefficients in the equation. Since the result is different in the two cases, we give two statements which take into account each of these situations. We refer e.g. to [121] for the proofs. This formulae can easily be obtained through a formal computation.

**Theorem 2.5.11.** Let  $\Omega$  be a bounded open set in  $\mathbb{R}^N$ , L the second order elliptic operator defined by (1.4) and  $L_t$  the new operator obtained by replacing  $a_0$  by  $a_0 + t\varphi$  in L (where  $\varphi$  is bounded). We assume that  $\lambda_k^D(L,\Omega)$  is simple and we denote by  $\lambda_k(t) := \lambda_k^D(L_t,\Omega)$ . Then,  $t \to \lambda_k(t)$  is derivable at t = 0 and

$$\lambda_k'(0) := \int_{\Omega} \varphi u^2 \, dx \tag{2.54}$$

where u is a normalized eigenfunction associated to  $\lambda_k$ .

**Remark 2.5.12.** In the case of a Neumann boundary condition, formulae (2.54) is still valid.

When the eigenvalue is degenerate, a result similar to Theorem 2.5.8 holds:

**Theorem 2.5.13.** Let  $\Omega$  be a bounded open set in  $\mathbb{R}^N$ , L the second order elliptic operator defined by (1.4) and  $L_t$  the new operator obtained by replacing  $a_0$  by  $a_0 + t\varphi$  in L (where  $\varphi$  is bounded). We assume that  $\lambda_k^D(L,\Omega)$  is degenerate:  $\lambda_k = \lambda_{k+1} = \cdots = \lambda_{k+m-1}$  and we denote by  $u_{k,1}, u_{k,2}, \ldots, u_{k,m}$  a set of orthonormalized eigenfunctions associated to  $\lambda_k$ . Then,  $t \to \lambda_k^D(L_t,\Omega)$  is derivable

at t=0 and its derivative is one of the eigenvalues of the  $m \times m$  matrix  $\mathcal M$  whose entries are

$$\mathcal{M}_{i,j} = \int_{\Omega} \varphi u_{k,i} u_{k,j} \, dx \; .$$

Remark 2.5.14. Another way to see the differentiability of multiple eigenvalues is to look at each branch of the spectrum. Indeed, a degenerate eigenvalue  $\lambda_k$  can split into a cluster of eigenvalues  $\lambda_{k,j}$  which can be considered as a set of differentiable functions near t=0, but those functions do not ordinarily correspond to the ordering of eigenvalues. In that case, another possible expression for the derivative is

$$\frac{d\lambda_k(a_0 + t\varphi)}{dt} = \int_{\Omega} \varphi u_{k,j}^2 dx \text{ at } t = 0$$
 (2.55)

where  $u_{k,j}$  is one of the family  $u_{k,i}$  of orthonormal eigenfunctions chosen so that

$$\int_{\Omega} u_{k,i} \varphi u_{k,j} \, dx = 0 \quad \text{for } i \neq j.$$
 (2.56)

We now consider the case where the variation takes place in the coefficients  $a_{ij}$ :

**Theorem 2.5.15.** Let  $\Omega$  be a bounded open set in  $\mathbb{R}^N$ , L the second order elliptic operator defined by (1.4) and  $L_t$  the new operator obtained by replacing  $a_{i_0j_0}$  by  $a_{i_0j_0} + t\varphi$  in L (where  $\varphi$  is bounded). We assume that  $\lambda_k^D(L, \Omega)$  is simple and we denote it by  $\lambda_k(t) := \lambda_k^D(L_t, \Omega)$ . Then,  $t \to \lambda_k(t)$  is derivable at t = 0 and

$$\lambda_k'(0) := \int_{\Omega} \varphi \frac{\partial u}{\partial x_{i_0}} \frac{\partial u}{\partial x_{j_0}} dx \tag{2.57}$$

where u is a normalized eigenfunction associated to  $\lambda_k$ .

**Remark 2.5.16.** In the particular case  $L = \operatorname{div}(\sigma \nabla u)$  and we look at the differentiability of  $t \mapsto \lambda_k(\sigma + t\varphi)$ , formulae (2.57) is written

$$\lambda_k'(0) := \int_{\Omega} \varphi |\nabla u|^2 dx . \qquad (2.58)$$

# **Chapter 3**

# **The first eigenvalue of the Laplacian-Dirichlet**

#### **3.1 Introduction**

Historically, the minimization of <sup>λ</sup>1 is probably the first such problem which appeared in the scientific literature. Indeed, in his famous book "The theory of sound" (first edition in 1877), Lord Rayleigh, thanks to some explicit computations and physical evidence, claimed that the disk should be the plane domain which minimizes the first eigenvalue of the Laplacian with Dirichlet boundary conditions (among domains of same area). The musical interpretation of this result could be: among all drums of given area, the circular drum is the one which produces the deepest bass note. The proof of this conjecture came almost 30 years later, simultaneously (and independently) by G. Faber and E. Krahn, see section 3.2. Nevertheless, the story of the minimization of <sup>λ</sup>1 is not finished! Later, G. P´olya considered the same problem in the class of polygons with a given number of sides. He obtained easily the expected result for triangles and quadrilaterals, but unfortunately his proof does not work for a larger number of sides, see section 3.3. We will also consider in section 3.4, the problem of minimizing <sup>λ</sup>1 among sets constrained to lie in a box. At last, we will also consider in section 3.5, the case of multi-connected domains: how to place an obstacle to minimize or maximize the first eigenvalue. As we will see, many problems remain open, even in this simple context.

#### **3.2 The Faber-Krahn inequality**

For the first eigenvalue, the basic result is (as conjectured by Lord Rayleigh):

**Theorem 3.2.1 (Faber-Krahn).** Let c be a positive number and B the ball of volume c. Then,

$$\lambda_1(B) = \min\{\lambda_1(\Omega), \ \Omega \ open \ subset \ of \ \mathbb{R}^N, \ |\Omega| = c\}.$$

*Proof.* The classical proof makes use of the Schwarz (spherical decreasing) rearrangement described in section 2.1. Let  $\Omega$  be a bounded open set of measure c and  $\Omega^* = B$  the ball of same volume. Let  $u_1$  denote an eigenfunction associated to  $\lambda_1(\Omega)$  and  $u_1^*$  its (Schwarz) rearrangement. From (2.1) and (2.2), we get

$$\int_{\Omega^*} u_1^*(x)^2 dx = \int_{\Omega} u_1(x)^2 dx \quad \text{and} \quad \int_{\Omega^*} |\nabla u_1^*(x)|^2 dx \le \int_{\Omega} |\nabla u_1(x)|^2 dx . \quad (3.1)$$

Now, according to (1.36), we have

$$\lambda_1(\Omega^*) \le \frac{\int_{\Omega^*} |\nabla u_1^*(x)|^2 dx}{\int_{\Omega^*} u_1^*(x)^2 dx} \quad \text{and} \quad \lambda_1(\Omega) = \frac{\int_{\Omega} |\nabla u_1(x)|^2 dx}{\int_{\Omega} u_1(x)^2 dx} .$$
 (3.2)

Then, (3.1) together with (3.2) yields the desired result.

Remark 3.2.2. We can wonder whether the ball is the unique minimizer of  $\lambda_1$  (up to displacements). Actually no, for example, in  $\mathbb{R}^2$  a disk where we remove a finite number of points has the same  $\lambda_1$ , so is also a minimizer. More generally, since the Sobolev space  $H_0^1(\Omega)$  does not change if we remove from  $\Omega$  a set of zero capacity (see section 2.4), any domain of the kind  $\Omega^* \setminus K$ , with K a set with zero capacity, minimizes  $\lambda_1$ . Actually, if we do not allow these kinds of irregularity, the ball is the unique minimizer. We refer to the discussion in [122] or to the more recent paper [56].

**Remark 3.2.3.** The first eigenvalue of the *p*-Laplace operator is usually defined by:

$$\lambda_1^p(\Omega) := \inf_{v \in W_0^{1,p}(\Omega), v \neq 0} \frac{\int_{\Omega} |\nabla v(x)|^p dx}{\int_{\Omega} v(x)^p dx}$$
(3.3)

where p is a real number  $1 \le p < +\infty$ . Following exactly the same proof (using (2.3) instead of (2.2)) as Faber-Krahn inequality, we have:

$$\forall p \in [1, +\infty[, \quad \lambda_1^p(\Omega^*) \le \lambda_1^p(\Omega). \tag{3.4}$$

In other words the ball minimizes the first eigenvalue of the p-Laplace operator.

#### 3.3 The case of polygons

We can ask the same question of minimizing  $\lambda_1$  in the class of polygons with a given number N of sides. We denote by  $\mathcal{P}_N$  the class of plane polygons with at most N edges.

#### 3.3.1 An existence result

We begin first by an existence result.

**Theorem 3.3.1.** Let a > 0 and  $N \in \mathbb{N}$  be fixed. Then the problem

$$\min\{\lambda_1(\Omega), \ \Omega \in \mathcal{P}_N, \ |\Omega| = a\}$$
 (3.5)

has a solution. This one has exactly N edges. Moreover, if we denote by  $m_N$  the minimum value defined by (3.5), the sequence  $m_N$  is (strictly) decreasing.

Proof. We follow the direct method of calculus of variations. Let  $\Omega_n$  be a minimizing sequence in  $\mathcal{P}_N$  for  $\lambda_1$ . We first prove that we can assume that the diameter  $D(\Omega_n)$  is bounded. Indeed, if it is not the case, we would have some "pick" of length going to  $+\infty$  but with a width, for example at its basis  $A_nB_n$  going to 0 (otherwise the area constraint could not be satisfied). We are going to prove that we get another minimizing sequence  $\widetilde{\Omega}_n$  by cutting the pick at its basis. Let us denote by  $\widetilde{\Omega}_n$  the polygon we obtain by replacing the pick by the segment  $A_nB_n$ . Obviously, we have  $|\widetilde{\Omega}_n| \leq |\Omega_n|$ , so if we prove that  $\lambda_1(\widetilde{\Omega}_n) - \lambda_1(\Omega_n) \to 0$ , it will show that  $\widetilde{\Omega}_n$  is also a minimizing sequence for the product  $|\Omega|\lambda_1(\Omega)$ . Since, the number of possible picks is bounded by N/2, this will prove that we can consider a minimizing sequence with bounded diameter. We denote by  $\eta_n = A_nB_n$  the width of the basis of the pick  $(\eta_n \to 0)$  and  $\omega_n = \Omega_n \cap B(\frac{A_n + B_n}{2}, 3\eta_n)$ . We choose now a cut-off function  $\chi_n$  which satisfies:

- $\chi_n \equiv 1$  outside  $B(\frac{A_n + B_n}{2}, 3\eta_n)$ ,
- $\chi_n = 0$  on the segment  $A_n B_n$ ,
- $\chi_n$  is  $C^1$  on  $\overline{\widetilde{\Omega}}_n$ ,
- $\exists C > 0$  (independent of n) such that  $|\nabla \chi_n| \leq \frac{C}{\eta_n}$ .

Let  $u_n$  be the first (normalized) eigenfunction of  $\Omega_n$ . By construction  $\chi_n u_n \in H_0^1(\widetilde{\Omega}_n)$  and, therefore, is admissible in the min formulae (1.36) defining  $\lambda_1$ . Now, for any  $C^1$  function v, we have

$$|\nabla(vu_n)|^2 = |u_n\nabla v + v\nabla u_n|^2 = u_n^2|\nabla v|^2 + \nabla u_n \cdot \nabla(u_n v^2)$$

or

$$|\nabla(vu_n)|^2 = u_n^2 |\nabla v|^2 + \text{ div } (u_n v^2 \nabla u_n) + \lambda_1(\Omega_n) u_n^2 v^2.$$

Replacing v by  $\chi_n$  and integrating on  $\widetilde{\Omega}_n$  yields

$$\int_{\widetilde{\Omega}_n} |\nabla(\chi_n u_n)|^2 = \int_{\widetilde{\Omega}_n} u_n^2 |\nabla \chi_n|^2 + \lambda_1(\Omega_n) \int_{\widetilde{\Omega}_n} \chi_n^2 u_n^2.$$
 (3.6)

Then, the variational definition of  $\lambda_1(\widetilde{\Omega}_n)$  (1.36) reads:

$$\lambda_1(\widetilde{\Omega}_n) \le \lambda_1(\Omega_n) + \frac{\int_{\widetilde{\Omega}_n} u_n^2 |\nabla \chi_n|^2}{\int_{\widetilde{\Omega}_n} \chi_n^2 u_n^2} \,. \tag{3.7}$$

Now, using  $|\nabla \chi_n| \equiv 0$  outside  $B(\frac{A_n + B_n}{2}, 3\eta_n)$ ,  $|\nabla \chi_n|^2 \leq \frac{C}{\eta_n^2}$  in  $\omega_n$  and  $\int_{\widetilde{\Omega}_n} \chi_n^2 u_n^2 \geq \frac{1}{2}$ , we get from (3.7)

$$\lambda_1(\widetilde{\Omega}_n) \le \lambda_1(\Omega_n) + \frac{2C}{\eta_n^2} \int_{\omega_n} u_n^2 \le \lambda_1(\Omega_n) + C' \sup_{\omega_n} u_n^2.$$

But, since  $\sup_{\omega_n} u_n^2 \to 0$  the result is proved.

Since  $\lambda_1$  is invariant by translation, we can assume that all the domains  $\widetilde{\Omega}_n$  are included in a fixed ball B. By compactness of the Hausdorff convergence (Theorem 2.3.15), there exists an open set  $\Omega$  and a subsequence  $\widetilde{\Omega}_{n_k}$  which converge to  $\Omega$  for the Hausdorff distance. Moreover, since the vertices  $A_n^j$ ,  $j=1\ldots M$ ,  $M\leq N$  of  $\widetilde{\Omega}_n$  stay in B, we can also assume (up to a subsequence still denoted by  $\widetilde{\Omega}_{n_k}$ ) that each  $A_{n_k}^j$  converges to some point  $A^j$  in B. Then, it is easy to verify, thanks to properties of the Hausdorff convergence, that  $\Omega$  is a polygon with vertices  $A^j$ . At last, it is clear that any polygon in the class  $\mathcal{P}_N$  has at most N/3 holes, therefore the Šverak Theorem 2.3.19 applies which proves convergence of  $\lambda_1(\widetilde{\Omega}_{n_k})$  to  $\lambda_1(\Omega)$ . To conclude, we need to prove that  $\Omega$  has exactly N edges. Actually, it will be a consequence of the following lemma which also implies the last claim of the theorem. We recall that it is equivalent to minimize  $\lambda_1(\Omega)$  under an area constraint or to minimize the product  $|\Omega|\lambda_1(\Omega)$  without any constraint (see Proposition 1.2.9).

**Lemma 3.3.2.** Let  $M \in \mathbb{N}$  and  $\Omega$  a polygon with M edges. Then,  $\Omega$  cannot be a (local) minimum for  $|\Omega|\lambda_1(\Omega)$  in the class  $\mathcal{P}_{M+1}$ .

By local, we mean for the Hausdorff distance. In other words, for any  $\varepsilon > 0$ , we can find a polygon  $\Omega_{\varepsilon}$  with M+1 edges and  $d_H(\Omega, \Omega_{\varepsilon}) < \varepsilon$  such that  $|\Omega_{\varepsilon}|\lambda_1(\Omega_{\varepsilon}) < |\Omega|\lambda_1(\Omega)$ .

Proof. Let us consider a vertex  $x_0$  of  $\Omega$  with an angle  $\alpha$  less than  $\pi$ . Without loss of generality, we can assume that  $x_0$  is the origin. We are going to prove that we can decrease the product  $|\Omega|\lambda_1(\Omega)$  by cutting a small cap of size  $\varepsilon$ . Let us introduce the following notation, see Figure 3.1. We denote by  $\eta$  the (normalized) inward bisector,  $C_{\varepsilon}$  is the cap defined as  $C_{\varepsilon} = \{x \in \Omega, x.\eta \leq \varepsilon\}$ ,  $\Omega_{\varepsilon}$  is the polygon that we obtain in removing the cap  $C_{\varepsilon}$ :  $\Omega_{\varepsilon} = \Omega \setminus C_{\varepsilon}$ . We will also need  $B_{\varepsilon} = \{x \in \Omega, \varepsilon < x.\eta \leq 2\varepsilon\}$ ,  $C_{2\varepsilon} = C_{\varepsilon} \cup B_{\varepsilon}$  and  $\Omega_{2\varepsilon} = \Omega_{\varepsilon} \setminus B_{\varepsilon} = \Omega \setminus C_{2\varepsilon}$ . We denote by  $u_1$  the first normalized eigenfunction of  $\Omega$ . The key point is the following: by classical barrier arguments (comparison with the eigenvalue of a circular sector), it is well known that  $u_1$  has a gradient which vanishes at the corner:

$$\lim_{x \to 0, x \in \Omega} |\nabla u_1(x)| = 0.$$
 (3.8)

Let  $\beta > 0$  be a small number (which will be chosen at the end); according to (3.8) and the mean value theorem, we can choose  $\varepsilon$  small enough such that

$$\forall x \in C_{2\varepsilon} \quad |u_1(x)| \le \beta |x| \,. \tag{3.9}$$

![](_page_57_Figure_2.jpeg)

Figure 3.1: Removing a cap.

In particular:

$$\int_{C_{2\varepsilon}} |u_1(x)|^2 dx \le \beta^2 \int_{C_{2\varepsilon}} |x|^2 dx = \frac{8}{3} \tan \frac{\alpha}{2} \left(3 + \tan^2 \frac{\alpha}{2}\right) \beta^2 \varepsilon^4 := c_1 \beta^2 \varepsilon^4. \quad (3.10)$$

We now introduce a  $C^1$  cut-off function  $\chi_{\varepsilon}$  with

$$\begin{cases} \chi_{\varepsilon}(x) = 1 & \text{if } x \in \Omega_{2\varepsilon}, \\ 0 \le \chi_{\varepsilon}(x) \le 1 & \text{if } x \in B_{\varepsilon}, \\ \chi_{\varepsilon}(x) = 0 & \text{if } x \in C_{\varepsilon}, \end{cases}$$

and the function  $u_{\varepsilon}^1 := \chi_{\varepsilon} u_1$  which belongs to the Sobolev space  $H_0^1(\Omega_{\varepsilon})$ . According to formulae (1.36), we have

$$\lambda_1(\Omega_{\varepsilon}) \le \frac{\int_{\Omega_{\varepsilon}} |\nabla u_{\varepsilon}^1|^2 dx}{\int_{\Omega_{\varepsilon}} (u_{\varepsilon}^1)^2 dx}.$$

Now, we have:

$$\int_{\Omega_{\varepsilon}} (u_{\varepsilon}^1)^2 dx \ge \int_{\Omega_{2\varepsilon}} u_1^2 dx = 1 - \int_{C_{2\varepsilon}} u_1^2 dx \ge 1 - c_1 \beta^2 \varepsilon^4$$
 (3.11)

the last inequality coming from (3.10). We estimate now the integral with the gradient:

$$\int_{\Omega_{\varepsilon}} |\nabla u_{\varepsilon}^{1}|^{2} dx \leq \int_{\Omega} |\nabla u_{1}|^{2} dx + \int_{B_{\varepsilon}} |\nabla \chi_{\varepsilon}|^{2} u_{1}^{2} dx.$$

As usual, from the construction of a cut-off function, there exists a constant  $c_2$  such that  $|\nabla \chi_{\varepsilon}|^2 \leq \frac{c_2}{\varepsilon^2}$  and therefore, using one more time (3.10)

$$\int_{\Omega_{\varepsilon}} |\nabla u_{\varepsilon}^{1}|^{2} dx \le \lambda_{1} + c_{1}c_{2}\beta^{2}\varepsilon^{2}.$$
(3.12)

Taking into account (3.11), (3.12), we get

$$\lambda_1(\Omega_{\varepsilon}) \leq \frac{\lambda_1 + \beta^2 \varepsilon^2 c_1 c_2}{1 - c_1 \beta^2 \varepsilon^4} \ .$$

At the same time,  $|\Omega_{\varepsilon}| = |\Omega| - |C_{2\varepsilon}| = |\Omega| - 4\varepsilon^2 \tan(\alpha/2) + o(\varepsilon^2)$  and therefore

$$|\Omega_{\varepsilon}|\lambda_1(\Omega_{\varepsilon}) \le |\Omega|\lambda_1 + \varepsilon^2 \left(\beta^2 c_1 c_2 |\Omega| - 4\lambda_1 \tan(\alpha/2)\right) + o(\varepsilon^2).$$

Then it is clear that, for  $\varepsilon$  small enough, we will have  $|\Omega_{\varepsilon}|\lambda_1(\Omega_{\varepsilon}) < |\Omega|\lambda_1$  as soon as  $\beta^2 < \frac{4\lambda_1 \tan(\alpha/2)}{c_1 c_2 |\Omega|}$  what gives the desired result.

#### **3.3.2** The cases N = 3, 4

After the existence result, we would like to identify the minimizer in  $\mathcal{P}_N$ . According to the Faber-Krahn inequality, it is natural to conjecture that it is the N-regular polygon. Actually, the result is known only for N=3 and N=4:

**Theorem 3.3.3 (Pólya).** The equilateral triangle has the least first eigenvalue among all triangles of given area. The square has the least first eigenvalue among all quadrilaterals of given area.

*Proof.* The proof relies on the same technique as the Faber-Krahn Theorem with the difference that is now used the Steiner symmetrization. Since this symmetrization has the same properties (2.1) and (2.2) as the Schwarz rearrangement, it is clear that any Steiner symmetrization decreases (or at least do not increase) the first eigenvalue. By a sequence of Steiner symmetrization with respect to the mediator of each side, a given triangle converges to an equilateral one. More precisely, let us denote by  $h_n$  and  $a_n$  the height and the length of the basis of the triangle  $T_n$  that we get at step n and  $A_n$  one of the basis angle (see Figure 3.2). Elementary trigonometry yields

$$\frac{h_n}{a_{n+1}} = \sin A_n \; , \quad \frac{h_{n+1}}{a_n} = \sin A_n \; .$$
 (3.13)

Let us denote by  $x_n := \frac{h_n}{a_n}$ . Relation (3.13) reads

$$x_{n+1} = \frac{\sin^2 A_n}{x_n} = \frac{\sin^2(\arctan(2x_n))}{x_n} = \frac{4x_n}{1 + 4x_n^2}$$

Now, an elementary study of the sequence  $x_{n+1} = \frac{4x_n}{1+4x_n^2}$  shows that it converges to the fixed point of  $f(x) = \frac{4x}{1+4x^2}$  which is  $\frac{\sqrt{3}}{2}$  i.e. the value characteristic of equilateral triangles. Moreover, with the same argument as above (Šverak Theorem), the sequence of triangles  $\gamma$ -converges to the equilateral one, say  $\widehat{T}$ , so we have proved, if T denotes the triangle we started with:

$$\lambda_1(\widehat{T}) = \lim \lambda_1(T_n) \le \lambda_1(T)$$
.

![](_page_59_Figure_2.jpeg)

Figure 3.2: The triangle  $T_n$  and its Steiner symmetrization  $T_{n+1}$ .

With a more careful study, we can prove that the above inequality is strict if T is not equilateral.

Curiously, the proof is a little bit simpler for quadrilaterals. Indeed a sequence of three Steiner symmetrizations allows us to transform any quadrilateral into a rectangle, see Figure 3.3. Therefore, it suffices to look at the minimization problem among rectangles. But it is elementary to prove that the square is the best rectangle for  $\lambda_1$ , use section 1.2.5.

#### 3.3.3 A challenging open problem

Unfortunately, for  $N \geq 5$  (pentagons and others), the Steiner symmetrization increases, in general, the number of sides, see Figure 3.4. This prevents us from using the same technique. So a beautiful (and hard) challenge is to solve the

**Open problem 2.** Prove that the regular N-gone has the least first eigenvalue among all the N-gones of given area for  $N \geq 5$ .

This conjecture is supported by the classical isoperimetric inequality linking area and length for regular N-gones, see e.g. Theorem 5.1 in Osserman, [162].

Another kind of result that can be proved on polygons has been stated by J. Hersch in [107]:

**Theorem 3.3.4 (Hersch).** Among all parallelograms with given distances between their opposite sides, the rectangle maximizes  $\lambda_1$ .

![](_page_60_Picture_2.jpeg)

Figure 3.3: A sequence of three Steiner symmetrizations transforms any quadrilateral into a rectangle.

![](_page_60_Picture_4.jpeg)

Figure 3.4: The Steiner symmetrization of a pentagon has, in general, six edges.

#### **3.4 Domains in a box**

Instead of looking at open sets just with a volume constraint, we can consider open sets constrained to lie in a given box D (and also with a given volume). In other words, we could look for the solution of

$$\min\{\lambda_1(\Omega), \ \Omega \subset D, \ |\Omega| = A \ (given)\}.$$
 (3.14)

According to Theorem 2.4.6 of Buttazzo-DalMaso, the problem (3.14) has always a solution in the class of quasi-open sets. Of course, if the constant A is small enough in such a way that there exists a ball of volume A in the box D, it will

provide the solution (since it is the global minimum). Therefore, the interesting case is when the ball of volume A is "too big" to stay in D. Actually, we can prove the following.

**Theorem 3.4.1.** Let <sup>Ω</sup><sup>∗</sup> <sup>⊂</sup> <sup>R</sup><sup>2</sup> be a minimizer for the problem (3.14). Assume that there is no disk of area A in the box D. Then:

- (i) Ω<sup>∗</sup> touches the boundary of D.
- (ii) The free parts of the boundary of Ω<sup>∗</sup> (i.e. those which are inside D) are analytic.
- (iii) The free boundary of Ω<sup>∗</sup> does not contain any arc of the circle.

![](_page_61_Picture_7.jpeg)

Figure 3.5: Ω<sup>∗</sup> solves the problem (3.14): the free components of ∂Ω<sup>∗</sup> are not arcs of circles.

Proof. We will not prove here point (ii) for which we refer to [37]. Let us now prove point (iii) (see also [103]). Let us denote by u the first (normalized) eigenfunction of Ω∗. Let us assume that ∂Ω<sup>∗</sup> contains a piece of circle γ. According to Corollary 2.5.4, Ω<sup>∗</sup> satisfies the optimality condition

$$\frac{\partial u_1}{\partial n} = c \quad \text{on } \gamma . \tag{3.15}$$

We put the origin at the center of the corresponding disk and we introduce the function

$$w(x,y) = x\frac{\partial u}{\partial y} - y\frac{\partial u}{\partial x}.$$

Then, we easily verify that

$$-\Delta w = \lambda_1 w \quad \text{in } \Omega^*,$$

$$w = 0 \quad \text{on } \gamma,$$

$$\frac{\partial w}{\partial n} = 0 \quad \text{on } \gamma.$$

Now we conclude, using the H¨olmgren uniqueness theorem, that w must vanish in a neighborhood of γ, so in the whole domain by analyticity. Now, it is classical that w = 0 implies that u is radially symmetric in  $\Omega^*$ . Indeed, in polar coordinates, w = 0 implies  $\frac{\partial u}{\partial \theta} = 0$ . Therefore  $\Omega^*$  is a disk.

For point (i), let us assume, for a contradiction, that  $\Omega^*$  is strictly included in D. In particular, if we perform any continuous Steiner symmetrization of  $\Omega^*$  (see section 2.2.3), the set  $\Omega_t^*$  will stay in D for t small and, therefore,  $\lambda_1(\Omega^*) \leq \lambda_1(\Omega_t^*)$ . But since, the continuous Steiner symmetrization does not increase the first eigenvalue, we also have  $\lambda_1(\Omega_t^*) \leq \lambda_1(\Omega^*)$ . Therefore,  $\lambda_1(\Omega^*) = \lambda_1(\Omega_t^*)$ . Let us denote by  $u_t$  the continuous Steiner symmetrization of u. From the chain

$$\lambda_1(\Omega^*) = \lambda_1(\Omega_t^*) \le \frac{\int_{\Omega_t^*} |\nabla u_t|^2}{\int_{\Omega_t^*} u_t^2} \le \frac{\int_{\Omega^*} |\nabla u|^2}{\int_{\Omega^*} u^2} = \lambda_1(\Omega^*)$$

we deduce  $\int_{\Omega_t^*} |\nabla u_t|^2 = \int_{\Omega^*} |\nabla u|^2$ . Consequently, Brock's Theorem 2.2.9 applies. But, in the decomposition (2.18), the set S has zero measure since u is analytic. Let  $B_1 = B_{R_1}(z_1)$  be the first ball in (2.18) and  $x_1$  a point of its boundary where u reaches its minimum. According to point (iii), there is another disk, say  $B_2$  touching  $B_1$  at  $x_1$  tangentially (from the exterior). But, if n denotes the exterior normal to  $B_1$ , by Hopf's maximum principle we would have  $\frac{\partial u}{\partial n}(x_1) < 0$  while, looking from  $B_2$  and applying  $(2.19) - \frac{\partial u}{\partial n}(x_1) \le 0$ : a contradiction. More precisely, this argument shows that no disks can touch  $B_1$  on the arc of circle where  $\frac{\partial u}{\partial n} < 0$ , but this would imply that this arc of circle belongs to the boundary of  $\Omega^*$ : a contradiction with point (iii).

Remark 3.4.2. Since we know, according to (ii), that the boundary of  $\Omega^*$  is regular, we can also prove (i) using a different argument. Indeed, the relation (3.15) (which would hold on the entire boundary if this one were included in D) together with the p.d.e. defining u yields a well-known overdetermined problem whose only solution, according to J. Serrin cf [186], is a ball: a contradiction with the assumption.

**Remark 3.4.3.** The previous theorem partly generalizes in higher dimension. Actually, points (i) and (iii) can be proved exactly in the same way. For example, for point (iii) we use the functions

$$w_{i,j} := x_i \frac{\partial u}{\partial x_j} - x_j \frac{\partial u}{\partial x_i}, \ i, j = 1, \dots, N$$

instead of w and we prove that all these functions  $w_{i,j}$  vanish in  $\Omega^*$  which implies that  $\Omega^*$  is a ball. The regularity is not known.

**Open problem 3.** Let  $\Omega^* \subset \mathbb{R}^N$  be a minimizer for the problem (3.14). Prove that  $\Omega^*$  is regular (for example analytic) when  $N \geq 3$ .

We can also consider open questions related to the geometry of the minimizer:

**Open problem 4.** Let  $\Omega^* \subset \mathbb{R}^N$  be a minimizer for the problem (3.14). Prove that D convex (resp. star-shaped) implies that  $\Omega^*$  is convex (resp. star-shaped).

#### 3.5 Multi-connected domains

This section could also be entitled "How to place an obstacle" (see [99]). Let us consider a doubly-connected set  $\Omega$  with one hole. We denote by  $\Gamma_0$  the outer boundary of  $\Omega$  and by  $\Gamma_1$  its inner boundary. We can consider several extremum problems, letting the boundary conditions vary on the outer boundary and/or the hole. Most of the known results were obtained in the sixties by Payne, Weinberger and Hersch, see [171], [105], [106]. Let us begin with a result where a Dirichlet boundary condition is assumed on the outer boundary and a Neumann boundary condition on the inner boundary.

**Theorem 3.5.1 (Payne-Weinberger).** Let  $\mathcal{O}_{L_0,A}$  be the class of doubly-connected plane domains  $\Omega$  of area A with outer boundary  $\Gamma_0$  of length  $L_0$  and inner boundary  $\gamma$ . Let us denote by  $\lambda_1^M$  the first eigenvalue of the mixed problem

$$\begin{cases}
-\Delta u = \lambda_1^M u & \text{in } \Omega, \\
u = 0 & \text{on } \Gamma_0, \\
\frac{\partial u}{\partial n} = 0 & \text{on } \gamma.
\end{cases}$$
(3.16)

Then, the annular ring (with concentric circles) maximizes  $\lambda_1^M$  in the class  $\mathcal{O}_{L_0,A}$ .

*Proof.* The main ingredient of the proof is an upper bound for  $\lambda_1$  which is obtained thanks to the method of interior parallels, see [146], [171]. Let us consider a doubly-connected set  $\Omega$  with outer boundary  $\Gamma$  of length  $L_0$  (and inner boundary  $\gamma$ ). We denote by  $d_{\Gamma}$  the distance function to  $\Gamma$ :  $d_{\Gamma}(x) = d(x, \Gamma) = \inf\{|x - y|, y \in \Gamma\}$ . Now let us define the *interior parallel of*  $\Gamma$  at distance  $\delta > 0$  as

$$\mathcal{L}_{\delta} = \{ x \in \Omega, \ d_{\Gamma}(x) = \delta \}$$

which is the inner boundary of the open set

$$\mathcal{A}_{\delta} = \{x \in \Omega, \ d_{\Gamma}(x) < \delta\} \ .$$

Let us introduce  $a(\delta)$  as the area of  $\mathcal{A}_{\delta}$  and  $l(\delta)$  as the length of  $\mathcal{L}_{\delta}$ . It is known (see e.g. [158], [87]), that  $\delta \mapsto a(\delta)$  is a.e. derivable with  $\frac{d \, a}{d \, \delta} = l(\delta)$ . Moreover, we have the sharp bound

$$l(\delta) \le L_0 - 2\pi\delta \ . \tag{3.17}$$

By integration, we deduce from (3.17) that  $a(\delta) \leq L_0 \delta - \pi \delta^2$  and then

$$l(\delta)^2 \le L_0^2 - 4\pi a(\delta) \ . \tag{3.18}$$

Now, to compute the first eigenvalue  $\lambda_1^M$  we can use, as in section 1.3.1, the min formulae which is written in this case

$$\lambda_1^M = \inf_{v \in H^1(\Omega) \setminus \{0\}, v = 0 \text{ on } \Gamma_0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx} . \tag{3.19}$$

Now, choosing any (regular) function  $\phi : \mathbb{R}_+ \to \mathbb{R}$  satisfying  $\phi(0) = 0$ , we can plug into (3.19) the admissible function  $v(x) = \phi(d_{\Gamma}(x))$  which gives

$$\lambda_1^M \le \frac{\int_{\Omega} |\phi'(\delta_{\Gamma}(x)|^2 |\nabla \delta_{\Gamma}(x)|^2 dx}{\int_{\Omega} \phi(d_{\Gamma}(x))^2 dx} . \tag{3.20}$$

Integrating along the interior parallels and using  $|\nabla \delta_{\Gamma}(x)| = 1$ , estimate (3.20) becomes

$$\lambda_1^M \le \frac{\int_0^{\delta_M} |\phi'(\delta)|^2 \, l(\delta) \, d\delta}{\int_0^{\delta_M} \phi(\delta)^2 \, l(\delta) \, d\delta} \tag{3.21}$$

where  $\delta_M$  denotes the maximum value of  $\delta$ . Now, we know that  $\delta \mapsto a(\delta)$  is one-to-one, so let us introduce  $\hat{\phi}(\alpha) = \phi(a^{-1}(\alpha))$ . The change of variable  $\delta = a^{-1}(\alpha)$  in the right-hand side of (3.21) yields

$$\lambda_1^M \le \frac{\int_0^A l^2(a^{-1}(\alpha))|\hat{\phi}'(\alpha)|^2 d\alpha}{\int_0^A \hat{\phi}(\alpha)^2 d\alpha} \ . \tag{3.22}$$

At last, estimate (3.18) gives

$$\lambda_1^M \le \frac{\int_0^A (L_0^2 - 4\pi\alpha) |\hat{\phi}'(\alpha)|^2 d\alpha}{\int_0^A \hat{\phi}(\alpha)^2 d\alpha} \ . \tag{3.23}$$

This inequality being true for every function  $\hat{\phi}$  satisfying  $\hat{\phi}(0) = 0$ , we can deduce the following upper bound for  $\lambda_1^M$ :

$$\lambda_1^M \le \lambda_{out}(L_0, A) \tag{3.24}$$

where  $\lambda_{out}(L_0, A)$  is the quantity (only depending on  $L_0$  and A) given by

$$\lambda_{out}(L_0, A) = \min_{\varphi/\varphi(0)=0} \frac{\int_0^A (L_0^2 - 4\pi\alpha) |\varphi'(\alpha)|^2 d\alpha}{\int_0^A \varphi(\alpha)^2 d\alpha} . \tag{3.25}$$

Now, let us consider the particular case where  $\Omega^*$  is the (unique) annular ring which belongs to the class  $\mathcal{O}_{L_0,A}$ . The first eigenfunction of  $\Omega^*$  is radial (it is given by a combination of Bessel functions of the first and second kind  $J_0(\omega_1 r)$  and  $Y_0(\omega_1 r)$  with  $\omega_1$  solution of some transcendental equation):  $u_1 = u_1(r)$ . Therefore,  $u_1$  is admissible in the variational definition of  $\lambda_{out}(L_0, A)$ . Moreover, for  $\Omega^*$  the inequality (3.17) is an equality. Then, for  $\Omega^*$ , the equality holds in (3.24):

$$\lambda_1^M(\Omega^*) = \lambda_{out}(L_0, A)$$

which proves the desired result.

In [105], J. Hersch adapts the previous proof to the case with the Dirichlet boundary condition on the inner boundary  $\Gamma_1$  of length  $L_1$  and the Neumann boundary condition on the outer boundary  $\gamma$ . He proves a similar upper bound

$$\lambda_1^M \le \lambda_{in}(A, L_1) \tag{3.26}$$

which turns out to be an equality in the case of an annular ring. This implies:

**Theorem 3.5.2 (Hersch).** Let  $\mathcal{O}_{A,L_1}$  be the class of doubly-connected plane domains  $\Omega$  of area A with inner boundary  $\Gamma_1$  of length  $L_1$  and outer boundary  $\gamma$ . Let us denote by  $\lambda_1^M$  the first eigenvalue of the mixed problem

$$\begin{cases}
-\Delta u = \lambda_1^M u & \text{in } \Omega, \\
\frac{\partial u}{\partial n} = 0 & \text{on } \gamma, \\
u = 0 & \text{on } \Gamma_1.
\end{cases}$$
(3.27)

Then, the annular ring (with concentric circles) maximizes  $\lambda_1^M$  in the class  $\mathcal{O}_{A,L_1}$ .

For similar results for several holes, we refer to [128].

**Open problem 5.** Generalize Theorems 3.5.1 and 3.5.2 to the N-dimensional case.

At last, let us consider the case where Dirichlet boundary conditions are assumed on each boundaries.

**Theorem 3.5.3 (Hersch).** Let  $\mathcal{O}$  be the class of doubly-connected plane domains  $\Omega$  of area A satisfying:

- the outer boundary has length  $L_0$ ,
- the inner boundary has length  $L_1$ ,
- $L_0^2 L_1^2 = 4\pi A$

Then, the annular ring (with concentric circles) maximizes  $\lambda_1$  in the class  $\mathcal{O}$ .

*Proof.* Let  $\Omega$  be fixed in the class  $\mathcal{O}$ . We denote by  $\Gamma_0$  its outer boundary and by  $\Gamma_1$  its inner one. The main ingredient of the proof is the fact, established by H. Weinberger in [208], that we can find a curve  $\gamma$  "between"  $\Gamma_1$  and  $\Gamma_0$  such that the first eigenfunction  $u_1$  of  $\Omega$  satisfies

$$\frac{\partial u_1}{\partial n} = 0 \text{ on } \gamma$$
.

In particular, if we denote by  $\Omega_0$  (resp  $\Omega_1$ ) the open set delimited by  $\Gamma_0$  and  $\gamma$ , of area  $A_0$  (resp  $\gamma$  and  $\Gamma_1$  of area  $A_1$ ), the first Dirichlet eigenvalue  $\lambda_1(\Omega)$  is also the first mixed eigenvalue of  $\Omega_0$  and  $\Omega_1$  in the sense of Theorems 3.5.1 and 3.5.2. Therefore bounds (3.24) and (3.26) provide the following inequalities:

$$\lambda_1(\Omega) = \lambda_1^M(\Omega_0) \le \lambda_{out}(L_0, A_0)$$
 and  $\lambda_1(\Omega) = \lambda_1^M(\Omega_1) \le \lambda_{in}(A_1, L_1)$ .

Consequently

$$\lambda_1(\Omega) \leq \min(\lambda_{out}(L_0, A_0), \lambda_{in}(A_1, L_1))$$

and hence

$$\lambda_{1}(\Omega) \leq \max_{\substack{\hat{A}_{0} \geq 0, \hat{A}_{1} \geq 0 \\ \hat{A}_{0} + \hat{A}_{1} = A}} \min(\lambda_{out}(L_{0}, \hat{A}_{0}), \lambda_{in}(\hat{A}_{1}, L_{1})).$$
(3.28)

Now, each function  $A \mapsto \lambda_{out}(L_0, A)$  and  $A \mapsto \lambda_{in}(A, L_1)$  is decreasing, so the max-min in (3.28) is attained when  $\hat{A}_0$ ,  $\hat{A}_1$  are chosen such that  $\lambda_{out}(L_0, \hat{A}_0) = \lambda_{in}(\hat{A}_1, L_1)$  (otherwise we could decrease the greater one and increase the smaller one in such a way that the maximum increases).

Now, thanks to the assumption  $L_0^2 - L_1^2 = 4\pi A$ , there exists a circular ring  $\Omega^*$  in the class  $\mathcal{O}$ . Moreover, for  $\Omega^*$  the line  $\gamma$  is precisely the circle where the first eigenfunction  $u_1$  is maximum. According to Theorems 3.5.1 and 3.5.2, we have

$$\lambda_1(\Omega^*) = \lambda_1^M(\Omega_0) = \lambda_{out}(L_0, A_0)$$
 and  $\lambda_1(\Omega^*) = \lambda_1^M(\Omega_1) = \lambda_{in}(A_1, L_1)$ 

which shows that we have equality in (3.28) for the annular ring: that is the desired result.

This result implies, in particular, that for a domain  $\Omega$  of the kind  $\Omega = B_1 \setminus B_0$  (difference of two disks of given radii),  $\lambda_1$  is maximal when the disks are concentric. This particular result was rediscovered later and extended to the

![](_page_66_Picture_11.jpeg)

Figure 3.6: Position of the hole which maximizes  $\lambda_1(\Omega \setminus \omega)$  (left); one position which minimizes  $\lambda_1(\Omega \setminus \omega)$  (right).

N-dimensional case by several authors: M. Ashbaugh and T. Chatelain in 1997 (private communication), E. Harrell, P. Kröger and K. Kurata in [99], Kesavan, see [127]. They also proved that  $\lambda_1(B_1 \setminus B_0)$  is minimum when  $B_0$  touches the boundary of  $B_1$ . Actually this result was generalized in [99] in the following way:

**Theorem 3.5.4 (Harrell-Kröger-Kurata).** Let  $\Omega$  be a convex domain in  $\mathbb{R}^N$  and B a ball contained in  $\Omega$ . Assume that  $\Omega$  is symmetric with respect to some hyperplane H. We are interested in the position of B which maximizes or minimizes the first Dirichlet eigenvalue  $\lambda_1(\Omega \setminus B)$ . Then:

- at the minimizing position B touches the boundary of  $\Omega$ ,
- at the maximizing position B is centered on H.

*Proof.* First of all, existence of a minimizing or maximizing position is not difficult to get here. Indeed the only variable is the center of the ball (which stays in a compact set) and the continuity of the eigenvalue w.r.t. the center follows for example from Theorem 2.3.18 (except for the case where the ball touches the boundary for which a more careful analysis is needed).

Let us assume that the ball is not in one of the positions described above: it does not touch the boundary and it is not centered on H. The result will be established if we prove that  $\lambda_1(\Omega \setminus B)$  decreases when B moves away from H. Without loss of generality, we can assume that  $e_1$  is the normal direction to H. If  $B(X_0, \rho)$  is the initial position of the ball, we look at the function

$$t \mapsto \lambda(t) := \lambda_1(\Omega \setminus B(X_0 + te_1, \rho)).$$

Using the results of section 2.5 and more precisely formulae (2.40), we can see that  $t \mapsto \lambda(t)$  is derivable at 0 and

$$\lambda'(0) = -\int_{\partial B} \left(\frac{\partial u}{\partial n}\right)^2 n_1 \tag{3.29}$$

where u is the normalized eigenfunction associated to  $\lambda_1(\Omega \setminus B(X_0, \rho))$  and  $n_1$  the first coordinate of the exterior normal vector. So it suffices to prove that  $\lambda'(0) < 0$ . For that purpose, we use some kind of moving plane method. Let  $T: \{x = x_1\}$ 

![](_page_67_Picture_10.jpeg)

Figure 3.7: The moving plane method applied to prove that the derivative of  $\lambda_1$  is negative.

denote a hyperplane parallel to H passing by  $X_0$  and  $\omega^+ = \{x \in \Omega \setminus B; x > x_1\}$  (see Figure 3.7). By assumption on  $\Omega$ , the reflection of  $\omega^+$  through T is strictly

included in  $\Omega \setminus B$  (this is the crucial point). For any  $X \in \omega^+$ , we denote by X' its reflection through T. We introduce w(X) = u(X) - u(X') defined on  $\omega^+$ . By construction, this function w vanishes on T and on  $\partial B \cap \partial \omega^+$  and w < 0 on  $\partial \Omega \cap \partial \omega^+$ . Moreover,  $-\Delta w = \lambda_1 w$  where  $\lambda_1 = \lambda_1(\Omega \setminus B)$ . Since  $\lambda_1(\Omega \setminus B) < \lambda_1(\omega^*)$  (by the monotonicity property of eigenvalues), the generalized maximum principle applies and w < 0 in  $\omega^+$ . Moreover, since w attained its maximum at  $X \in \partial B \cap \partial \omega^+$  (which is  $C^2$  except at points of  $T \cap \partial B \cap \partial \omega^+$ ), the Hopf boundary point lemma applies and:

$$\frac{\partial w(X)}{\partial n} = \frac{\partial u(X)}{\partial n} - \frac{\partial u(X')}{\partial n} > 0.$$

This property with  $\frac{\partial u(X)}{\partial n} < 0$  on  $\partial B$  implies

$$\left(\frac{\partial u(X)}{\partial n}\right)^2 < \left(\frac{\partial u(X')}{\partial n}\right)^2$$

which gives  $\lambda'(0) < 0$  thanks to (3.29) and a decomposition of the integral in a sum of integrals over the two hemispheres.

With more assumptions and in two dimensions, one can state a more precise result:

**Theorem 3.5.5 (Harrel-Kröger-Kurata).** Let  $\Omega$  be a  $C^2$  convex domain in  $\mathbb{R}^2$ . Assume that  $\Omega$  is symmetric with respect to two perpendicular lines, say Ox and Oy. Assume, moreover, that in each quadrant of the plane, the curvature of the boundary of  $\Omega$  is monotonic as a function of x. Now, let B be a ball of radius  $\rho$  with  $\rho$  less than the maximum of the curvature of  $\partial\Omega$  (attained at a point which is called a vertex of  $\Omega$ ). Then:

- $\lambda_1(\Omega \setminus B)$  is minimum when B is in contact with a vertex,
- $\lambda_1(\Omega \setminus B)$  is maximum when B is centered at the origin. For the proof, see [99].

An interesting open question is to generalize the previous theorems of Harrel-Kröger-Kurata:

**Open problem 6.** Let  $\Omega$  be a fixed domain in  $\mathbb{R}^N$  and  $B_0$  a ball of fixed radius. Prove that  $\lambda_1(\Omega \setminus B_0)$  is minimal when  $B_0$  touches the boundary of  $\Omega$  (where?) and is maximum when  $B_0$  is centered at a particular point of  $\Omega$  (at what point?).

Actually, It seems that the optimal center of  $B_0$  depends on the radius and is not fixed (apart from the case of symmetries). When the radius of  $B_0$  goes to zero, classical asymptotic formulae for eigenvalues of domains with small holes, see (1.41) and the review paper [88], lead one to think that the ball must be located at the maximal point of the first eigenfunction of the domain without holes. Of course, we can state the same question with a non-circular hole of given measure: in such a case, we have to find not only the location but also the shape of the hole in order to minimize or maximize the first eigenvalue.

# Chapter 4

# The second eigenvalue of the Laplacian-Dirichlet

#### 4.1 Minimizing $\lambda_2$

We are now interested in minimizing the second eigenvalue of the Laplacian-Dirichlet among open sets of given volume. As we are going to see, the minimizer is no longer one ball, but two! This result is sometimes attributed to G. Szegö, cf [172], but actually it was already contained (more or less explicitly) in one of Krahn's paper, [132]. Actually, it was also rediscovered independently by a Japanese mathematician, Imsik Hong in the 1950s, see [111] (M. Ashbaugh kindly draws my attention to this reference).

#### 4.1.1 The Theorem of Krahn-Szegö

**Theorem 4.1.1 (Krahn-Szegö).** The minimum of  $\lambda_2(\Omega)$  among bounded open sets of  $\mathbb{R}^N$  with given volume is achieved by the union of two identical balls.

*Proof.* Let  $\Omega$  be any bounded connected open set (if  $\Omega$  is not connected, see below). Let us denote by  $\Omega_+$  and  $\Omega_-$  its nodal domains, see section 1.3.3. We already know (Proposition 1.3.3) that  $\lambda_2(\Omega)$  is the first eigenvalue for  $\Omega_+$  and  $\Omega_-$ :

$$\lambda_1(\Omega_+) = \lambda_1(\Omega_-) = \lambda_2(\Omega) . \tag{4.1}$$

We now introduce  $\Omega_+^*$  and  $\Omega_-^*$ , balls of the same volume as  $\Omega_+$  and  $\Omega_-$  respectively. According to the Faber-Krahn inequality,

$$\lambda_1(\Omega_+^*) \le \lambda_1(\Omega_+), \qquad \lambda_1(\Omega_-^*) \le \lambda_1(\Omega_-).$$
 (4.2)

Let us introduce a new open set  $\Omega$  defined as

$$\tilde{\Omega} = \Omega_+^* \cup \Omega_-^* \, .$$

Since  $\tilde{\Omega}$  is disconnected, we obtain its eigenvalues by gathering and reordering the eigenvalues of  $\Omega_{+}^{*}$  and  $\Omega_{-}^{*}$ . Therefore,

$$\lambda_2(\tilde{\Omega}) \le \max(\lambda_1(\Omega_+^*), \lambda_1(\Omega_-^*))$$
.

According to (4.1), (4.2) we have

$$\lambda_2(\tilde{\Omega}) \le \max(\lambda_1(\Omega_+), \lambda_1(\Omega_-)) = \lambda_2(\Omega).$$

If  $\Omega$  would not be connected at the beginning,  $\Omega = \Omega_1 \cup \Omega_2$ , the proof would be the same by applying the argument to  $\Omega_1$  and  $\Omega_2$  instead of  $\Omega_+$  and  $\Omega_-$ . This shows that, in any case, the minimum of  $\lambda_2$  is to be sought among the union of balls. But, if the two balls would have different radii, we would decrease the second eigenvalue by shrinking the largest one and dilating the smaller one (without changing the total volume). Therefore, the minimum is achieved by the union of two identical balls.

Let us denote by  $\lambda_2^{*,c}$  the minimal value of  $\lambda_2(\Omega)$  for open sets of volume c. For example, in two dimensions, we get according to (1.27)

$$\lambda_2^{*,c} = \frac{2\pi j_{0,1}^2}{c} \ . \tag{4.3}$$

Remark 4.1.2. As we did for the Faber-Krahn inequality, we can wonder whether the union of two identical balls is the unique (up to displacements) minimizer for  $\lambda_2$ . It is a consequence of the proof and Remark 3.2.2, that it is true if we neglect sets of zero capacity.

**Remark 4.1.3.** There are other problems of minimization of eigenvalues whose solution is the union of two identical balls. For example, this is the case for

• the twisted eigenvalue problem: it is defined as

$$\lambda_1^T(\Omega) := \min_{ \begin{array}{c} v \in H_0^1(\Omega), v \neq 0 \\ \int_{\Omega} v \, dx = 0 \end{array}} \frac{\int_{\Omega} |\nabla v(x)|^2 \, dx}{\int_{\Omega} v(x)^2 \, dx} \,,$$

see [25] and [90].

• another eigenvalue problem occurring in nonlinear p.d.e. It is defined as

$$\lambda_1(\Omega) := \min_{ \begin{array}{c} v \in H^1(\Omega), v \neq 0 \\ v = \mathrm{const.} \ \mathrm{on} \ \partial \Omega, \int_{\Omega} v \, dx = 0 \end{array}} \frac{\int_{\Omega} |\nabla v(x)|^2 \, dx}{\int_{\Omega} v(x)^2 \, dx} \ ,$$

see [95].

#### 4.1.2 Case of a connectedness constraint

If we are disappointed with the solution of our minimization problem, since it is not connected, we could think to look at the following problem:

$$\min\{\lambda_2(\Omega), \ \Omega \text{ connected open subset of } \mathbb{R}^N, \ |\Omega| = c\}.$$
 (4.4)

Unfortunately, this problem has no solution:

**Proposition 4.1.4.** The problem (4.4) has no solution. More precisely

$$\inf\{\lambda_2(\Omega), \ \Omega \ connected \ open \ subset \ of \ \mathbb{R}^N, \ |\Omega|=c\}=\lambda_2^{*,c}$$
.

*Proof.* Let us consider the set  $\Omega_{\varepsilon}$  obtained by joining the two identical balls  $B_1 \cup B_2$  (each of volume c/2) by a thin pipe of width  $\varepsilon$  (see Figure 4.1). According to

![](_page_71_Picture_9.jpeg)

Figure 4.1: A minimizing sequence of connected domains for  $\lambda_2$ .

Theorem 2.3.20,  $\lambda_2(\Omega_{\varepsilon}) \to \lambda_2(B_1 \cup B_2)$ . Of course,  $\Omega_{\varepsilon}$  does not satisfy the volume constraint. But, if we remember that it is equivalent to minimizing the product  $\lambda_2(\Omega)|\Omega|^{2/N}$  (see Proposition 1.2.9), it is clear that

$$\lambda_2(\Omega_\varepsilon)|\Omega_\varepsilon|^{2/N} \to \lambda_2(B_1 \cup B_2)|B_1 \cup B_2|^{2/N} = \lambda_2^{*,c} c^{2/N}$$

and therefore,  $\Omega_{\varepsilon}$  is a minimizing sequence. According to Remark 4.1.2, there is no connected open set  $\Omega$  of volume c such that  $\lambda_2(\Omega) = \lambda_2^{*,c}$  and the result is proved.

#### 4.2 A convexity constraint

Now, the problem becomes again interesting if we ask how to find the **convex** domain, of given volume, which minimizes  $\lambda_2$ . Existence of a minimizer  $\Omega^*$  is proved in Theorem 2.4.1. Of course, the difficulty is to find it! For sake of simplicity, we restrict ourselves here to the two-dimensional case.

In a paper of 1973 [204], Troesch did some numerical experiments which led him to conjecture that the solution was a stadium: the convex hull of two identical tangent disks. It is actually the convex domain which is the closest to

the solution without convexity constraint. In [103], we refute this conjecture, see Theorem 4.2.5 below. Nevertheless, the minimizer looks very much like a stadium! In sections 4.2.3 and 4.2.2, we give the following properties of the minimizer:

**Regularity.** The minimizer Ω<sup>∗</sup> is at least C<sup>1</sup> and at most C2.

**Geometry.** If we assume Ω<sup>∗</sup> of class C1,1, then it has two (and only two) straight lines in its boundary and these lines are parallels.

#### **4.2.1 Optimality conditions**

First of all, we claim that Theorem 2.5.10 remains true with a convexity constraint (there are minor changes in the proof, see [103]). A consequence is

**Theorem 4.2.1.** Let <sup>Ω</sup><sup>∗</sup> be a convex domain minimizing the second eigenvalue <sup>λ</sup>2 (among convex domains of given volume). Assume that Ω<sup>∗</sup> is of class C1,1. Then <sup>λ</sup>2(Ω∗) is simple.

Indeed, for a convex domain Ω<sup>∗</sup> minimizing <sup>λ</sup>2, we know that <sup>λ</sup>1(Ω∗) is simple and therefore (2.53) cannot hold.

We want to derive some optimality condition like |∇u2<sup>|</sup> <sup>=</sup> <sup>c</sup> on <sup>∂</sup>Ω<sup>∗</sup> as established in Corollary 2.5.4 for the general case. Now, it is not so obvious here due to the convexity constraint. The difficulty is to take care of the convexity constraint when deforming the original domain Ω<sup>∗</sup> by a vector field V . Indeed, if we perform a small deformation of a strictly convex part of the boundary of Ω∗, this part will not remain necessarily convex, but we can use the fact that the difference between the deformed boundary and its convex hull is so small, that for first order terms, the formulae of the derivative still holds (see below for more details). On the contrary, for segments included in the boundary, it is no longer true. Therefore, we need to make a distinction between the strictly convex parts of the boundary and the segments included in the boundary. Let us mention that the first part of the following theorem holds for any dimension while the second part is strictly two-dimensional.

#### **Theorem 4.2.2.**

• There exists a positive constant α such that the gradient of the eigenfunction u is constant on every strictly convex part of the boundary of Ω∗:

for every 
$$\gamma$$
, strictly convex part of  $\partial\Omega^*$ ,  $\forall x \in \gamma \quad |\nabla u(x)| = \alpha$ . (4.5)

Moreover α is given by

$$\alpha^2 = \frac{\lambda_2}{|\Omega^*|} \ . \tag{4.6}$$

• If Σ is a segment included in the boundary of Ω∗, let t, t ∈ [a, b], a parametrization of the segment (the boundary is assumed to be oriented in the clockwise sense), then there exists a non-negative function w defined on [a,b] with triple roots at a and b, such that

$$|\nabla u(t)|^2 = \alpha^2 + w''(t). \tag{4.7}$$

Proof. We begin by considering  $\gamma$  a strictly convex part of the boundary of  $\Omega^*$ . We assume that  $\gamma$  is parametrized by a strictly convex function  $\varphi$  defined on an interval I. We fix a regular function h compactly supported on a sub-interval J and we denote by  $\Omega_{\varepsilon}$  the domain (not necessarily convex) whose boundary is (locally) bounded by the graph of the function  $\varphi_{\varepsilon} := \varphi + \varepsilon h$ . Let us introduce  $\varphi_{\varepsilon}^{**}$ , the convex regularization of  $\varphi_{\varepsilon}$  (it is the largest convex function less than or equal to  $\varphi_{\varepsilon}$ ) and  $\Omega_{\varepsilon}^{*}$  the convex domain whose boundary is (locally) bounded by the graph of the function  $\varphi_{\varepsilon}^{**}$ . The key point of the following proof is an estimate given in Lemma 2 of [135], when the function  $\varphi$  is strictly convex:

$$\|\varphi_{\varepsilon}^{**} - \varphi_{\varepsilon}\|_{\infty} = o(\varepsilon) \text{ when } \varepsilon \to 0.$$
 (4.8)

We now use the quantitative estimate between eigenvalues given in Proposition 2.3.22:

$$|\lambda_2(\Omega_{\varepsilon}^*) - \lambda_2(\Omega_{\varepsilon})| \le C \|\varphi_{\varepsilon}^{**} - \varphi_{\varepsilon}\|_{\infty} = o(\varepsilon)$$
(4.9)

(with C a positive constant). Moreover, according to Hadamard's formula for simple eigenvalues, see Theorem 2.5.1 and, in particular, (2.40):

$$\lambda_2(\Omega_{\varepsilon}) = \lambda_2(\Omega) - \varepsilon \int_{\gamma} |\nabla u(\sigma)|^2 h(\sigma) n_2(\sigma) d\sigma + o(\varepsilon)$$
 (4.10)

 $(n_2(\sigma))$  is the second component of the exterior unit normal vector). From (4.9), (4.10) we get:

$$\lambda_2(\Omega_{\varepsilon}^*) = \lambda_2(\Omega) - \varepsilon \int_{\gamma} |\nabla u(\sigma)|^2 h(\sigma) n_2(\sigma) d\sigma + o(\varepsilon). \tag{4.11}$$

In the same way,

$$||\Omega_{\varepsilon}^*| - |\Omega_{\varepsilon}|| \le \int_I |\varphi_{\varepsilon}^{**} - \varphi_{\varepsilon}| = o(\varepsilon)$$

while, by Hadamard's formula (2.44) for areas,

$$|\Omega_{\varepsilon}| = |\Omega| + \varepsilon \int_{\gamma} h(\sigma) n_2(\sigma) d\sigma + o(\varepsilon).$$

Therefore, we also have

$$|\Omega_{\varepsilon}^{*}| = |\Omega| + \varepsilon \int_{\gamma} h(\sigma) n_{2}(\sigma) d\sigma + o(\varepsilon).$$
 (4.12)

Finally (4.11), (4.12) give

$$\lambda_2(\Omega_{\varepsilon}^*)|\Omega_{\varepsilon}^*| = \lambda_2(\Omega)|\Omega| + \varepsilon \int_{\gamma} [\lambda_2(\Omega) - |\Omega||\nabla u(\sigma)|^2]h(\sigma)n_2(\sigma) d\sigma + o(\varepsilon).$$

In the previous relation, we can use either h or -h, therefore the minimality of  $\Omega^*$  gives the desired result (4.5), (4.6).

Now, let us consider the case of a segment  $\Sigma$ . We recall that the general formula, for the derivative of the function  $\Omega \mapsto \lambda_2(\Omega)|\Omega|$  at "point"  $\Omega^*$ , according to a perturbation field V is (see Theorem 2.5.1 and (2.40), (2.44))

$$d(\lambda_2(\Omega)|\Omega|), (\Omega^*, V) = \int_{\partial \Omega^*} [\lambda_2(\Omega) - |\Omega| |\nabla u(\sigma)|^2] h(\sigma) n_2(\sigma) d\sigma.$$
 (4.13)

In formula (4.13), the only perturbations V which are allowed are such that the deformed domain  $(Id + \tau V)(\Omega^*)$  is still convex (for small  $\tau$ ). It is the case if and only if  $t \mapsto V.n(t)$  is a concave function on [a,b]. Let us denote by v = V.n such a concave function. Replacing in (4.13) and using (4.5), (4.6) yields on the segment  $\Sigma$ :

$$\int_{a}^{b} \left( \lambda_2 - |\nabla u(\sigma)|^2 A(\Omega^*) \right) v \, dt \ge 0. \tag{4.14}$$

Introducing  $w_2(t) = |\nabla u(t)|^2 - \alpha^2$  it can also be rewritten:

$$\int_{a}^{b} w_2(t)v(t) dt \le 0. (4.15)$$

This relation (4.15) must be true for every (regular) concave function v. In particular, in the case v(t) = 1 and v(t) = t, both functions v and -v are concave, therefore

$$\int_{a}^{b} w_2(t) dt = 0 \qquad \int_{a}^{b} t w_2(t) dt = 0.$$
 (4.16)

Now, let us introduce the functions

$$w_1(t) = \int_a^t w_2(s) ds$$
 and  $w(t) = \int_a^t w_1(s) ds = \int_a^t (t-s)w_2(s) ds$ .

According to (4.16), we have  $w_1(a) = w_1(b) = w(a) = w(b) = 0$ . Integrating twice by parts, it turns out that

$$\int_{a}^{b} w_{2}(t)v(t) dt = \int_{a}^{b} w(t)v''(t) dt;$$

this last integral must be non-positive (according to (4.15)) for every function v concave, i.e. for every function v such that  $v'' \leq 0$ , this yields  $w \geq 0$ . At last a and b are triple roots of w because  $w''(a) = w_2(a) = 0$  by continuity of the gradient  $(|\nabla u|^2 - \alpha^2)$  vanishes identically on the strictly convex parts of  $\partial \Omega^*$ ).

- **Remark 4.2.3.** Actually, using an analyticity argument, we can prove that w is positive, but we will only use later that it is non-negative and cannot vanish identically (at least when the nodal line of u touches the segment, since on such a point  $|\nabla u| = 0$ ).
  - Since  $w \ge 0$  and w(a) = w'(a) = w''(a) = 0, we must have  $w'''(a) \ge 0$  and similarly  $w'''(b) \le 0$ . Therefore,  $|\nabla u|^2 \ge \alpha^2$  near the extremities of the segment.

#### 4.2.2 Geometric properties of the optimal domain

We begin by proving that the minimizer is  $C^1$ : it cannot have a corner. We give the proof for the second eigenvalue, but it is clear that this proof can be extended to the problem of minimizing other eigenvalues with a convex constraint. Indeed, it is a particular case of a more general result as it is shown in [43]. Actually, the proof of the following theorem is just a generalization of the one given in Lemma 3.3.2. We refer to [103] for details.

**Theorem 4.2.4.** The minimizer  $\Omega^*$  is (at least)  $C^1$ .

In the sequel, we need to assume that the minimizer  $\Omega^*$  is a little bit more regular. Let us mention that we will prove below that it is at most  $C^2$ .

(H) We assume the minimizer  $\Omega^*$  to be of class  $C^{1,1}$ .

By classical regularity results, see Remark 1.2.11 or [94], this will imply that the eigenfunction u is  $C^1$  up to the boundary.

Our next result concerns Troesch's conjecture that we stated in the introduction of this section. It was natural to think that a *good candidate* to be the minimizer would be the convex hull of two identical disks (the so-called *stadium*). Actually, we prove thanks to the same argument as in Theorem 3.4.1 that it is not true:

**Theorem 4.2.5 (Henrot-Oudet).** The minimizer  $\Omega^*$  has no arc of a circle in its boundary. In particular, the stadium, convex hull of two identical tangent disks, does not realize the minimum of  $\lambda_2$  among plane convex domains of given area.

*Proof.* Adapt proof of (iii) in Theorem 3.4.1.

**Remark 4.2.6.** The previous result holds in every dimension: the minimizer cannot contain any piece of a sphere. The proof is the same using the functions  $x_i \frac{\partial u}{\partial x_j} - x_j \frac{\partial u}{\partial x_i}$  since u is radially symmetric as soon as all these functions vanish.

Numerical experiments (see E. Oudet's thesis and the following table) show that the minimizer  $\Omega^*$  is very close to a stadium. In particular, we have the following array of numerical values for the second eigenvalue of convex sets of area 1:

| Domain         | exact value             | numerical value |
|----------------|-------------------------|-----------------|
| Square         | $5\pi^2$                | 49.348          |
| Disc           | $j_{1,1}^2\pi \ 4\pi^2$ | 46.124          |
| Best rectangle | $4\pi^2$                | 39.478          |
| Best ellipse   |                         | 39.317          |
| Stadium        |                         | 38.001          |
| Best convex    |                         | 37.980          |

We recall that the value for two disks (optimal domain without constraint) is  $2j_{0.1}^2\pi \simeq 36.336$ .

Actually, the optimal domain is close to the stadium not only from a numerical point of view, but also from a geometrical point of view:

**Theorem 4.2.7.** The minimizer  $\Omega^*$  has two segments in its boundary and these segments are parallels.

*Proof.* At least one segment: otherwise the normal derivative of u would be zero on the whole boundary, because it is constant (by optimality condition (4.5)) and it has to be zero where the nodal line hits the boundary. But this would contradict (4.6).

At least two segments: if there was only one segment, according to the previous argument, the nodal line would have to hit  $\partial\Omega^*$  twice on the same segment. We can now follow step by step the proof of Theorem 3.1 page 258 in Melas [150]. In this theorem, he proves that the nodal line cannot intersect the boundary at only one point. We can use this proof with minor changes.

At most two segments: let us assume that there exists a third segment in  $\partial\Omega^*$ . We consider here the segment  $\Sigma$  which is far from the nodal line of u. We choose the coordinate axes so that the x-axis is on  $\Sigma$  (and  $\Sigma = [-A, A]$ ) and the y-axis is in the direction of the inward normal to  $\partial\Omega^*$ . Without loss of generality, we can assume that u > 0 in a neighborhood of  $\Sigma$ . We define the function  $\varphi(x) = \frac{\partial u}{\partial y}(x)$  on  $\Sigma$ . By classical regularity results u is  $C^{\infty}(\Omega^* \cup \Sigma)$ , so  $\varphi$  is  $C^{\infty}$  on  $\Sigma$ . According to the optimality condition on a segment (4.7) and our construction (see Remark 4.2.3), the function  $\varphi$  satisfies:

- $\varphi$  is positive on [-A, A] (by Hopf's boundary point Lemma).
- $\varphi'(-A) \ge 0$  and  $\varphi'(A) \le 0$ .
- $\varphi$  is not constant (use an analyticity argument: if  $\varphi$  was constant, i.e. if u satisfies  $\frac{\partial u}{\partial y} = \alpha$  on [-A, A] a straightforward computation (compute any term in the series expansion of u) would show that u only depends on the variable y, which is impossible).
- $\varphi' = \frac{\partial^2 u}{\partial u \partial x}$  vanishes (at least) three times on [-A, A] with change of sign.

Let us denote by  $x_1$ ,  $x_2$  and  $x_3$  the three first zeros of  $\varphi'$ . The function  $\varphi'$  is negative on  $(x_1, x_2)$ . We define  $y_1$  as a point in  $(x_1, x_2)$  where  $\varphi'$  is minimum.

Now, for t > 0, we introduce the function

$$v_t = tu + \frac{\partial u}{\partial x} .$$

In particular, if we denote by  $\psi_t$  the restriction at  $\Sigma$  of  $\frac{\partial v_t}{\partial y}$ , i.e.  $\psi_t(x) := \frac{\partial v_t}{\partial y}(x) = t\varphi(x) + \varphi'(x)$ , then  $\psi_t$  satisfies for t > 0 small:

$$\psi_t(-A) > 0,$$
  
 $\psi_t(y_1) = t\varphi(y_1) + \varphi'(y_1) < 0,$ 
  
 $\psi_t(x_2) = t\varphi(x_2) > 0.$ 

Therefore,  $\psi_t$  vanishes at least two times on  $(-A, x_2)$  for t small enough. We introduce

$$t^* = \sup_{T>0} \{ \psi_t \text{ vanishes at least two times on } [-A, x_2] \text{ for all } t \in [0, T[] \}.$$

Obviously  $t^* < +\infty$  since  $\psi_t = t\varphi + \varphi'$  is positive for t large enough on  $\Sigma$ . Now, by construction, the function  $\psi_{t^*}$  has a **double** zero at some point  $x_0 \in \Sigma$ . We can assume, without loss of generality, that  $x_0$  is the origin. Let us expand the function  $v_{t^*}$ , which is analytic up to  $\Sigma$ , in series in a small neighborhood  $\mathcal V$  of 0 contained in the closed upper half-plane. The fact that  $v_{t^*} = 0$  identically on  $\Sigma = \{y = 0\}$  yields:

$$v_{t^*}(x,y) = a_1y + a_2xy + a_3y^2 + V(x,y)$$

with V(x,y) containing only terms of order larger than or equal to 3. Since 0 is a double zero of  $\frac{\partial v_{t^*}}{\partial y}$ , we have  $a_1 = a_2 = 0$ . Now,  $\Delta v_{t^*} = -\lambda_2 v_{t^*}$  in  $\mathcal{V}$  and therefore

- $a_3 = 0$ ,
- V(x,y) = 0 by induction.

Obviously this last point leads to a contradiction since we would have  $v_{t^*} = 0$  in  $\mathcal{V}$  and therefore in  $\Omega^*$  by analyticity.

The two segments are parallels: In this section, we fix coordinates such that the first segment  $\Sigma_1$  is on the horizontal axis and the second one  $\Sigma_2$  makes an angle of  $\beta \geq 0$  with the horizontal. We introduce the numbers  $(0 <)y_1 \leq y_2 < d$  which are respectively the ordinates of the lower point of  $\Sigma_2$ , the upper point of  $\Sigma_2$ , the upper point of  $\Omega^*$ . At last, for each  $y \in [0,d]$ , we will denote by  $x_1(y) \leq x_2(y)$  the abscissas of the intersection of  $\partial\Omega^*$  with the horizontal line of ordinate y.

We recall the classical Rellich-type identity proved in [175]. For every eigenfunction u of  $-\Delta u = \lambda u$  in a domain  $\Omega$  with Dirichlet boundary condition and for every  $C^1$  vector field  $h = (h_1, h_2, \ldots, h_N)$  in  $\mathbb{R}^N$ , we have

$$\frac{1}{2} \int_{\partial \Omega} |\nabla u|^2 h.n \, d\sigma = -\frac{1}{2} \int_{\Omega} (|\nabla u|^2 - \lambda u^2) \, \mathrm{div} h + \sum_{i=1}^N \sum_{j=1}^N \int_{\Omega} \frac{\partial u}{\partial x_j} \, \frac{\partial u}{\partial x_i} \, \frac{\partial h_j}{\partial x_i} \, . \tag{4.17}$$

We apply this identity for the second eigenfunction u of  $\Omega^*$  with a vector field  $h = (h_1(y), 0)$  in  $\mathbb{R}^2$ . It turns out that  $(\operatorname{div} h = 0)$ :

$$\frac{1}{2} \int_{\partial \Omega^*} |\nabla u|^2 h_1 n_1 \, d\sigma = \int_{\Omega^*} h_1'(y) \frac{\partial u}{\partial x} \, \frac{\partial u}{\partial y} \, dx dy \; .$$

Now, we compute the boundary integral thanks to the optimality conditions (4.5), (4.7)  $(h_1n_1 = 0 \text{ on } \Sigma_1 \text{ while } h_1n_1 = -\sin\beta h_1(t\sin\beta) \text{ on } \Sigma_2)$ :

$$\frac{1}{2} \int_{\partial \Omega^*} |\nabla u|^2 h_1 n_1 d\sigma = \frac{1}{2} \int_{\partial \Omega^*} \alpha^2 h_1 n_1 d\sigma - \frac{\sin \beta}{2} \int_{\Sigma_2} w_{\Sigma_2}''(t) h_1(t \sin \beta) dt.$$

Now,

$$\int_{\partial\Omega^*} h_1 n_1 \, d\sigma = \int_{\Omega^*} \frac{\partial h_1}{\partial x} \, dX = 0$$

while, integrating twice by parts and using the fact that  $w_{\Sigma_2}$  and  $w'_{\Sigma_2}$  vanish at the extremities of  $\Sigma_2$ , we get

$$\int_{\Sigma_2} w_{\Sigma_2}''(t) h_1(t\sin\beta) dt = \sin^2\beta \int_{\Sigma_2} w_{\Sigma_2}(t) h_1''(t\sin\beta) dt.$$

Therefore, we finally have

$$-\frac{\sin^3 \beta}{2} \int_{\Sigma_1} w_{\Sigma_2}(t) h_1''(t \sin \beta) dt = \int_{\Omega} h_1'(y) \frac{\partial u}{\partial x} \frac{\partial u}{\partial y} dx dy.$$
 (4.18)

Now, we can choose a function  $h_1$  defined on [0, d] such that

- $h_1'' > 0$  on  $[y_1, y_2]$ ,
- $\int_{\Omega} h_1'(y) \frac{\partial u}{\partial x} \frac{\partial u}{\partial y} dx dy = \int_0^d h_1'(y) \left( \int_{x_1(y)}^{x_2(y)} \frac{\partial u}{\partial x} \frac{\partial u}{\partial y} dx \right) dy = 0$ .

For this function, we have  $\sin^3 \beta \int_{\Sigma_2} w_{\Sigma_2}(t) h_1''(t \sin \beta) dt = 0$  with  $h_1'' > 0$  and  $w_{\Sigma_2}$  non-negative (and not identically 0) by (4.7). Therefore,  $\sin \beta = 0$  which gives the desired result.

**Remark 4.2.8.** In the proof of Theorem 4.2.7, we only use the optimality conditions. In other words, Theorem 4.2.7 is valid for any critical point of the domain functional  $\lambda_2(\Omega)|\Omega|$ .

Of course, we believe that the optimal domain  $\Omega^*$  has more symmetries:

**Open problem 7.** Prove that a plane convex domain  $\Omega^*$  which minimizes  $\lambda_2$  (among convex domains of given area) is  $C^{1,1}$  and has two perpendicular axes of symmetry.

#### 4.2.3 Another regularity result

We recall that we proved in the previous subsection that the minimizer  $\Omega^*$  was at least  $C^1$ . We prove here the counterpart of this regularity result: the minimizer  $\Omega^*$  is at most  $C^2$ !

**Theorem 4.2.9.** The minimizer  $\Omega^*$  cannot be  $C^{2,\varepsilon}$ , for any  $\varepsilon > 0$ .

Here by  $C^{2,\varepsilon}$ , we mean classical Hölder regularity: the second derivative of the local maps would be Hölderian of ratio  $\varepsilon$ .

Proof. Let us assume that  $\Omega^*$  is  $C^{2,\varepsilon}$ , for some  $\varepsilon>0$ . Then, by classical Schauder regularity results for elliptic p.d.e., see Theorem 1.2.12, this will imply that the eigenfunction u is  $C^2$  up to the boundary. We choose the coordinates axes so that the x-axis is parallel to the two segments. Consequently the function  $\frac{\partial u}{\partial x}$  vanishes on the two segments. We want to look more precisely at the nodal lines of  $\frac{\partial u}{\partial x}$ . According to Hopf's Lemma, each boundary point X, located on the segments where  $\frac{\partial^2 u}{\partial x \partial y}$  vanishes, is a starting point of such a nodal line (e.g. if  $\frac{\partial u}{\partial x}>0$  in a neighborhood of X, since  $-\Delta \frac{\partial u}{\partial x} = \lambda_2 \frac{\partial u}{\partial x}>0$ , we have  $\frac{\partial}{\partial n} \left(\frac{\partial u}{\partial x}\right)<0$ ). Now, if u is  $C^2$ ,  $\frac{\partial^2 u}{\partial x \partial y}$  has to vanish at the extremities of the segments by continuity: if A is such an extremity

$$\frac{\partial^{2} u}{\partial x \partial y}(A) = \frac{\partial^{2} u}{\partial \tau \partial n}(A) = \lim_{B \to A} \frac{\partial^{2} u}{\partial \tau \partial n}(B) = 0$$

where B is taken on a strictly convex part of  $\partial\Omega^*$ . Moreover, according to the optimality conditions (4.7),  $\frac{\partial^2 u}{\partial x \partial y} = \frac{\partial}{\partial x} \left( \frac{\partial u}{\partial y} \right)$  has to vanish at least twice inside the segments. Consequently, there are **four** nodal lines of  $\frac{\partial u}{\partial x}$  starting on each segment. Closing these nodal lines, we define at least three nodal domains of  $\frac{\partial u}{\partial x}$  strictly contained in  $\Omega^*$ . Now  $\frac{\partial u}{\partial x}$  being an eigenfunction associated to  $\lambda_2$ , the nodal domains in Theorem 1.3.2 would lead to the fact that  $\lambda_2$  is at least the third eigenvalue of a **strict** subdomain of  $\Omega^*$ , which is a contradiction with the monotonicity of eigenvalues.

## Chapter 5

# The other Dirichlet eigenvalues

#### 5.1 Introduction

The purpose of this chapter is to investigate the existence of a domain which minimizes  $\lambda_k$  over sets of fixed volume in  $\mathbb{R}^N$  for  $k \geq 3$ . We recall that this problem received a partial solution in Corollary 2.4.6, where it is proved that a minimizer exists in the class of quasi-open sets (see the exact definition in section 2.4) of fixed measure contained in a bounded "design region". More precisely, the Buttazzo-Dal Maso Theorem states that, for any bounded open set  $D \subset \mathbb{R}^N$ , the problem

$$\min_{A \subset D, |A| = c} \lambda_k(A) \tag{5.1}$$

has a solution. Of course, the minimizer depends a priori on the choice of the design region D.

In order to prove the existence of a *global* minimizer, the main difficulty is the passage from the bounded set D to  $\mathbb{R}^N$ . The main reason for which the previous result fails if  $D = \mathbb{R}^N$  is the lack of compactness of the injection  $H^1(\mathbb{R}^N) \hookrightarrow L^2(\mathbb{R}^N)$ .

In section 5.3, we prove the existence of a solution for problem (5.1) with  $D = \mathbb{R}^N$ , and k = 3. We follow the scheme of the direct method of the calculus of variations: we consider a minimizing sequence of domains, and construct the optimum as limit in some sense precise below. The main tool we use when studying the behavior of a minimizing sequence is a concentration-compactness result for the  $\gamma$ -convergence proved in [42], see Theorem 5.3.1. Unfortunately, the minimizer is not known. The conjecture is presented in Open problem 8. For  $k \geq 4$ , in section 5.4, we give a result asserting the existence of a minimizer, if for any j = 3, k - 1 a bounded minimizer exists. We also give some conjectures.

Before these existence questions, we present a result (essentially due to Wolff and Keller), about the connectedness of the (possible) minimizers.

#### 5.2 Connectedness of minimizers

In this section, we assume that problem (5.1) has a solution for any eigenvalue and we denote by  $\Omega_n^*$  a (quasi-) open set which minimizes  $\lambda_n$  (among open sets of volume 1) and  $\lambda_n^* = \lambda_n(\Omega_n^*)$  the minimal value of  $\lambda_n$ . We will also denote by  $t\Omega$  the image of  $\Omega$  by a homothety of ratio t. The following result is, in some sense, a generalization of Krahn-Szegö's Theorem 4.1.1. Roughly speaking, it asserts that if a minimizer of  $\lambda_n$  is not connected, each connected component is a minimizer for a lower eigenvalue. These results come from [213].

**Theorem 5.2.1 (Wolf-Keller).** Let us assume that  $\Omega_n^*$  is the union of (at least) two disjoint sets, each of them with positive measure. Then

$$(\lambda_n^*)^{N/2} = (\lambda_i^*)^{N/2} + (\lambda_{n-i}^*)^{N/2} = \min_{1 \le j \le (n-1)/2} ((\lambda_j^*)^{N/2} + (\lambda_{n-j}^*)^{N/2})$$
 (5.2)

where, in the previous equality, i is a value of  $j \leq (n-1)/2$  which minimizes the sum  $(\lambda_j^*)^{N/2} + (\lambda_{n-j}^*)^{N/2}$ . Moreover,

$$\Omega_n^* = \left[ \left( \frac{\lambda_i^*}{\lambda_n^*} \right)^{1/2} \Omega_i^* \right] \bigcup \left[ \left( \frac{\lambda_{n-i}^*}{\lambda_n^*} \right)^{1/2} \Omega_{n-i}^* \right] \qquad (disjoint union).$$
 (5.3)

Proof. Let us write  $\Omega_n^* = \Omega_1 \cup \Omega_2$  (disjoint union) with  $|\Omega_1| > 0$ ,  $|\Omega_2| > 0$  and  $|\Omega_1| + |\Omega_2| = 1$ . Let  $u_n^*$  be an eigenfunction of the Laplacian-Dirichlet on  $\Omega_n^*$ , corresponding to the eigenvalue  $\lambda_n^*$ . Then  $u_n^*$  is not zero on one of the components of  $\Omega_n^*$ , for example  $\Omega_1$ . In particular  $\lambda_n^*$  is an eigenvalue (see (1.15)) of  $\Omega_1$ :  $\lambda_n^* = \lambda_i(\Omega_1)$  for some integer  $i \leq n$  and we denote precisely by i the largest one. If we had i = n, we could decrease  $\lambda_n^*$  by enlarging  $\Omega_1$  contradicting the minimality of  $\lambda_n^*$ , so  $i \leq n - 1$ . Since  $\lambda_n^*$  is the n-th eigenvalue of  $\Omega_n^*$ , we can count at least n - i eigenvalues of  $\Omega_2$  which are smaller than  $\lambda_n^*$ . It means that  $\lambda_{n-i}(\Omega_2) \leq \lambda_n^*$ . Moreover, if we would have  $\lambda_{n-i}(\Omega_2) < \lambda_n^*$ , we could decrease  $\lambda_n^* = \max\{\lambda_i(\Omega_1), \lambda_{n-i}(\Omega_2)\}$  by enlarging  $\Omega_1$  and shrinking  $\Omega_2$  (keeping the total volume equal to 1) which would again contradict the minimality of  $\lambda_n^*$ . So, finally  $\lambda_{n-i}(\Omega_2) = \lambda_i(\Omega_1) = \lambda_n^*$ .

Now, we still get a minimum for  $\lambda_n^*$  by replacing  $\Omega_1$  by  $|\Omega_1|^{1/N}\Omega_i^*$  (which has same volume and better  $\lambda_i$ ) and by replacing  $\Omega_2$  by  $|\Omega_2|^{1/N}\Omega_{n-i}^*$ . Consequently, we have

$$\lambda_i(\Omega_1) = |\Omega_1|^{-2/N} \lambda_i^* = \lambda_n^* = |\Omega_2|^{-2/N} \lambda_{n-i}^* = \lambda_{n-i}(\Omega_2).$$

Finally, the constraint  $|\Omega_1| + |\Omega_2| = 1$  yields  $(\lambda_n^*)^{N/2} = (\lambda_i^*)^{N/2} + (\lambda_{n-i}^*)^{N/2}$ . Let us now consider the set  $\widetilde{\Omega}_j$  defined for  $j = 1, \ldots, n-1$  by

$$\widetilde{\Omega}_{j} = \left[ \left( \frac{\left(\lambda_{j}^{*}\right)^{N/2}}{\left(\lambda_{j}^{*}\right)^{N/2} + \left(\lambda_{n-j}^{*}\right)^{N/2}} \right)^{1/N} \Omega_{j}^{*} \right] \bigcup \left[ \left( \frac{\left(\lambda_{n-j}^{*}\right)^{N/2}}{\left(\lambda_{j}^{*}\right)^{N/2} + \left(\lambda_{n-j}^{*}\right)^{N/2}} \right)^{1/N} \Omega_{n-j}^{*} \right]. \quad (5.4)$$

Each  $\widetilde{\Omega}_j$  has a volume equal to 1, the *j*-th eigenvalue of its first component and the (n-j)-th eigenvalue of its second component are equal to

$$\left(\left(\lambda_{j}^{*}\right)^{N/2}+\left(\lambda_{n-j}^{*}\right)^{N/2}\right)^{2/N}.$$

It follows that  $\lambda_n(\widetilde{\Omega_j})$  is also given by this common value. Since  $\lambda_n^* \leq \lambda_n(\widetilde{\Omega}_j)$  and  $\lambda_n^* = \lambda_n(\widetilde{\Omega}_i)$  for some index i,  $\lambda_n^*$  is the minimum value of  $\lambda_n(\widetilde{\Omega}_j)$ . Moreover,  $\widetilde{\Omega_i}$  is optimal for any index i which realizes the minimum in (5.2). This finishes the proof.

Up to now, the value of  $\lambda_n^*$  is not known unless for n=1 or 2. The previous theorem has an important consequence for the optimal domain  $\Omega_3^*$  in dimension 2 or 3.

Corollary 5.2.2 (Wolff-Keller). Let  $\Omega_3^*$  be an open set minimizing  $\lambda_3$  (i.e. solution of problem (5.1) with c=1) in dimension 2 or 3. Then,  $\Omega_3^*$  is connected.

Proof. Assume that  $\Omega_3^*$  is not connected. Then, according to Theorem 5.2.1, we should have  $\lambda_3^* = \lambda_1^* + \lambda_2^*$  (i = 1 is the only possible value here). Let us make explicit these values first in dimension 2. From Theorem 3.2.1  $\lambda_1^* = \pi j_{0,1}^2 \simeq 18.168$  (we recall that  $j_{0,1}$  is the first zero of the Bessel function  $J_0$  and the radius of the disk of area 1 is  $R_0 = \frac{1}{\sqrt{\pi}}$ , see (1.27)) while, according to Theorem 4.1.1,  $\lambda_2^* = 2\lambda_1^* \simeq 36.336$ . Therefore  $\lambda_1^* + \lambda_2^* \simeq 54.504$ . But since  $\lambda_3^*$  is, by definition, lower than or equal to the third eigenvalue of the unit disk  $\lambda_3(D_1) = \pi j_{1,1}^2 \simeq 46.125$ , we see that it cannot be equal to  $\lambda_1^* + \lambda_2^*$ .

In dimension 3, the situation is exactly the same. We use the values of the eigenvalues for a ball given in (1.29). Since the ball must have volume 1, its radius is here  $R_0 = \left(\frac{3}{4\pi}\right)^{1/3}$ , then

$$\lambda_1^* = \frac{(4\pi)^{2/3} j_{1/2,1}^2}{3^{2/3}} \simeq 25.646 \qquad \lambda_2^* = 2^{2/3} \lambda_1^* \simeq 40.711$$

and

$$(\lambda_3(B_{R_0}))^{3/2} = \left(\frac{j_{N/2,1}^2}{R_0^2}\right)^{3/2} \simeq 380.029 < (\lambda_1^*)^{3/2} + (\lambda_2^*)^{3/2} \simeq 389.636$$

with the same conclusion.

**Remark 5.2.3.** In dimension 4 and higher, this computation does not give anything. For example, we get in dimension 4:

$$R_0 = \frac{2^{1/4}}{\sqrt{\pi}}$$
  $\lambda_1^* = \frac{j_{1,1}^2}{R_0^2} \simeq 32.615$   $\lambda_2^* = \sqrt{2}\lambda_1^* \simeq 46.125$ 

while

$$(\lambda_3(B_{R_0}))^2 = \left(\frac{j_{2,1}^2}{R_0^2}\right)^2 \simeq 3432.67 > (\lambda_1^*)^2 + (\lambda_2^*)^2 \simeq 3191.25$$

which cannot lead to a conclusion. Actually, the conjecture is that in dimension  $N \geq 4$ ,  $\Omega_3^*$  is not connected and, more precisely, that it is given by the union of three balls, see Open problem 8.

**Remark 5.2.4.** In dimension 2, numerical computations show that the optimal domain  $\Omega_n^*$  is sometimes connected (this is the case for n = 1, 3, 5, 6, sometimes not, n = 2, 4, 7, see [164] and Figure 5.1.

#### **5.3** Existence of a minimizer for $\lambda_3$

#### 5.3.1 A concentration-compactness result

As we explain in the introduction of this chapter, the difficulty of proving existence of a minimizer is to take care of minimizing sequences which could go to infinity (more precisely whose diameter could go to infinity since the eigenvalues are invariant under translations). A good tool to take care of this kind of situation is a concentration-compactness argument as introduced by P.L. Lions in [141]. Before stating the theorem introducing the concentration-compactness in our situation, we need to generalize the notion of resolvant operators and eigenvalues introduced in sections 1.1.2 and 1.2.2.

A relaxed domain is a positive Borel measure  $\mu$  which vanishes on sets of zero capacity, see [73, 30] and section 2.4; the family of all these measures is denoted  $\mathcal{M}_0(\mathbb{R}^N)$ . We recall that a property p(x) is said to hold quasi-everywhere on E (shortly q.e. on E) if the set of all points  $x \in E$  for which p(x) does not hold has zero capacity. In this chapter, we are working only with measures  $\mu$ , for which the largest (in the sense of inclusion q.e.) countable union of sets of finite  $\mu$ -measure has its Lebesgue measure less than or equal to c. This set is called the regular set of the measure  $\mu$  and is denoted by  $\Omega_{\mu}$ .

The resolvent operator associated to the measure  $\mu$  is  $A_{\mu}: L^{2}(\mathbb{R}^{N}) \to L^{2}(\mathbb{R}^{N})$  and  $A_{\mu}(f) = u$  where u is the weak variational solution of

$$\begin{cases}
 u \in H^1(\mathbb{R}^N) \cap L^2_{\mu}(\mathbb{R}^N), \\
 \int_{\mathbb{R}^N} \nabla u \cdot \nabla \phi dx + \int_{\mathbb{R}^N} u \phi d\mu = \int_{\mathbb{R}^N} f \phi dx \quad \forall \phi \in H^1(\mathbb{R}^N) \cap L^2_{\mu}(\mathbb{R}^N).
\end{cases} (5.5)$$

Here, by  $H^1(\mathbb{R}^N) \cap L^2_{\mu}(\mathbb{R}^N)$  we denote the set

$$\{u \in H^1(\mathbb{R}^N) : \int_{\mathbb{R}^N} u^2 d\mu < +\infty\}.$$

If  $u \in H^1(\mathbb{R}^N) \cap L^2_{\mu}(\mathbb{R}^N)$  we have u = 0 q.e. on  $\mathbb{R}^N \setminus \Omega_{\mu}$ . Indeed, supposing the contrary, there exists a set of positive capacity  $U \subseteq \mathbb{R}^N \setminus \Omega_{\mu}$  such that  $u \neq 0$  on U, hence there exists  $\varepsilon > 0$  such that

$$cap(U \cap \{|u| > \varepsilon\}) \neq 0.$$

Since  $\mu$  has to be finite on the set  $\{|u| > \varepsilon\}$  we see that

$$cap((\Omega_u \cup \{|u| > \varepsilon\}) \setminus \Omega_u) > 0,$$

which contradicts the maximality of the regular set  $\Omega_{\mu}$ .

If we denote for every  $k \in \mathbb{N}$ ,  $\lambda_k(\mu) = \frac{1}{\lambda_k(A_\mu)}$ , we deduce from the previous embedding  $(H^1(\mathbb{R}^N) \cap L^2_\mu(\mathbb{R}^N) \subset H^1_0(\Omega_\mu))$  and the classical min-max formulae of section 1.3.1, the following inequality between the eigenvalues:

$$\lambda_k(\mu) \ge \lambda_k(\Omega_\mu).$$

We now recall the following theorem from [42] on the concentration-compactness of a sequence of open sets, with respect to the resolvent operators (we follow here the terminology introduced by P.L. Lions in [141]).

**Theorem 5.3.1 (Bucur).** Let  $\{\Omega_n\}_{n\in\mathbb{N}}$  be a sequence of open (or quasi-open) sets such that  $|\Omega_n| \leq c$ . There exists a subsequence still denoted with the same index such that one of the following situations occurs:

**Compactness:** There exists a sequence of vectors  $\{y_n\}_{n\in\mathbb{N}}\subset\mathbb{R}^N$  and a positive Borel measure  $\mu$ , vanishing on sets of zero capacity, such that  $A_{y_n+\Omega_n}$  converges in the uniform operator topology of  $L^2(\mathbb{R}^N)$  to  $A_{\mu}$ . Moreover  $|\Omega_{\mu}| \leq c$ .

**Dichotomy:** There exists a sequence of subsets  $\tilde{\Omega}_n \subset \Omega_n$ , such that

$$||A_{\Omega_n} - A_{\tilde{\Omega}_n}||_2 \to 0$$
, and  $\tilde{\Omega}_n = \Omega_n^1 \cup \Omega_n^2$ 

 $\label{eq:with def} \mbox{with } d(\Omega_n^1,\Omega_n^2) \to \infty \mbox{ and } \liminf_{n \to +\infty} |\Omega_n^i| > 0 \mbox{ for } i=1,2.$ 

#### 5.3.2 Existence of a minimizer

In this section, we want to prove that the problem

$$\min_{\Omega \in \mathcal{A}_c(\mathbb{R}^N)} \lambda_3(\Omega) \tag{5.6}$$

has a solution where, for every open set  $D \subset \mathbb{R}^N$ , and for every c > 0, we denote

$$\mathcal{A}_c(D) = \{ \Omega \subset D : \Omega \text{ quasi-open }, |\Omega| \le c \}.$$

Let us begin with a lemma which generalizes, in some sense, Wolff-Keller's Theorem 5.2.1.

**Lemma 5.3.2.** For  $N \geq 2$ , one of the following situations occurs.

1. If for every  $\varepsilon > 0$ , the following strict inequality holds:

$$\inf\{\lambda_3(\Omega_1 \cup \Omega_2) : |\Omega_1 \cup \Omega_2| = c, |\Omega_1| > \varepsilon, |\Omega_2| > \varepsilon, \operatorname{cap}(\Omega_1 \cap \Omega_2) = 0\}$$

$$> \inf\{\lambda_3(\Omega) : |\Omega| = c\},$$
(5.7)

then if a solution  $\Omega^*$  of (5.6) exists, it is connected.

2. If there exists  $\varepsilon > 0$ , such that

$$\inf\{\lambda_3(\Omega_1 \cup \Omega_2) : |\Omega_1 \cup \Omega_2| = c, |\Omega_1| > \varepsilon, |\Omega_2| > \varepsilon, \operatorname{cap}(\Omega_1 \cap \Omega_2) = 0\}$$
  
=  $\inf\{\lambda_3(\Omega) : |\Omega| = c\},$  (5.8)

then the optimum exists and is the union of three disjoint balls of volume  $\frac{c}{3}$ . Proof. Using the following remark of [45]

if 
$$cap(\Omega_1 \cap \Omega_2) = 0$$
, then  $H_0^1(\Omega_1 \cup \Omega_2) = H_0^1(\Omega_1) \cup H_0^1(\Omega_2)$ ,

the arguments of Wolf and Keller remain valid in the quasi-open frame.

In order to prove the first assertion, suppose that for every  $\varepsilon > 0$  inequality (5.7) holds and that problem (5.6) has a solution  $\Omega^*$ . If  $\Omega^*$  is not connected, we can write  $\Omega^* = \Omega_1 \cup \Omega_2$  with  $\operatorname{cap}(\Omega_1 \cap \Omega^*) > 0$ ,  $\operatorname{cap}(\Omega_2 \cap \Omega^*) > 0$ , and  $\operatorname{cap}(\Omega_1 \cap \Omega_2) = 0$ . Then  $|\Omega_1| > 0$  and  $|\Omega_2| > 0$ , hence choosing  $\varepsilon = \frac{1}{2} \min\{|\Omega_1|, |\Omega_2|\}$  the strict inequality (5.7) fails.

Suppose that equality (5.8) holds for some  $\varepsilon > 0$ . Then we can consider a minimizing sequence for problem (5.6) of the form  $\Omega_n = \Omega_n^1 \cup \Omega_n^2$  with  $|\Omega_n^1| \ge \varepsilon$ ,  $|\Omega_n^2| \ge \varepsilon$ ,  $|\Omega_n^1| + |\Omega_n^2| = c$ ,  $\operatorname{cap}(\Omega_n^1 \cap \Omega_n^2) = 0$ . Then one of the following situations occurs (up to a re-enumeration and for a subsequence still denoted with the index n).

- $\lambda_3(\Omega_n^1 \cup \Omega_n^2) = \lambda_3(\Omega_n^1)$  if  $\lambda_3(\Omega_n^1) \le \lambda_1(\Omega_n^2)$ ,
- $\lambda_3(\Omega_n^1 \cup \Omega_n^2) = \lambda_2(\Omega_n^1)$  if  $\lambda_1(\Omega_n^2) \le \lambda_2(\Omega_n^1) \le \lambda_2(\Omega_n^2)$
- $\lambda_3(\Omega_n^1 \cup \Omega_n^2) = \lambda_1(\Omega_n^1)$  if  $\lambda_2(\Omega_n^2) \le \lambda_1(\Omega_n^1) \le \lambda_3(\Omega_n^2)$ .

In fact, the first situation can not occur. Indeed, since  $|\Omega_n^1| \leq c - \varepsilon$ , we would obtain that  $\inf_{\Omega \in \mathcal{A}_c(\mathbb{R}^N)} \lambda_3(\Omega) = \inf_{\Omega \in \mathcal{A}_{c-\varepsilon}(\mathbb{R}^N)} \lambda_3(\Omega)$ . This is false, since

$$\inf_{\Omega \in \mathcal{A}_c(\mathbb{R}^N)} \lambda_3(\Omega) = \left(\frac{c-\varepsilon}{c}\right)^{2/N} \inf_{\Omega \in \mathcal{A}_{c-\varepsilon}(\mathbb{R}^N)} \lambda_3(\Omega) > 0.$$

If the second situation occurs, then replacing  $\Omega_n^1$  with two disjoint balls of measure  $\frac{|\Omega_1|}{2}$  and  $\Omega_2$  with a ball of measure  $|\Omega_2|$ , the third eigenvalue diminishes. If the third situation occurs, then replacing  $\Omega_1$  with a ball of measure  $|\Omega_1|$  and  $\Omega_2$  with two disjoint balls of measure  $|\Omega_2|/2$ , the third eigenvalue diminishes.

In both these situations, the optimum is clearly attained for a set which is the union of three disjoint balls, one of measure greater than or equal to  $\varepsilon$  and two of measures greater than or equal to  $\varepsilon/2$ . Classical arguments (as in the proof of Theorem 5.2.1) lead to the fact that the minimum for problem (5.6) is attained for three equal balls.

Consequently, we give now the main result of this section.

**Theorem 5.3.3 (Bucur-Henrot).** Problem (5.6) has at least one solution.

*Proof.* Let us consider  $\{\Omega_n\}_{n\in\mathbb{N}}$  a minimizing sequence for problem (5.6). Applying Theorem 5.3.1, two situations may occur for the sequence  $R_{\Omega_n}$ .

If compactness occurs, there exists a measure  $\mu \in \mathcal{M}_0(\mathbb{R}^N)$  such that  $A_{\Omega_{n_k}+y_k}$  converges uniformly in  $L^2(\mathbb{R}^N)$  to  $A_{\mu}$ . Hence  $\lambda_3(\Omega_{n_k}) \to \lambda_3(\mu)$ . Denoting  $\Omega_{\mu}$  the regular set of the measure  $\mu$  we have by monotonicity that  $\lambda_3(\mu) \geq \lambda_3(\Omega_{\mu})$ . Since  $\Omega_{\mu} \in \mathcal{A}_c(\mathbb{R}^N)$  we get that  $\Omega_{\mu}$  is a solution for problem (5.6).

If dichotomy occurs, there exists a subsequence (still denoted with the same index) of  $\{\Omega_n\}_{n\in\mathbb{N}}$  and a sequence of subsets  $\tilde{\Omega}_n\subset\Omega_n$ , such that

$$||A_{\Omega_n} - A_{\tilde{\Omega}_n}||_2 \to 0$$
, and  $\tilde{\Omega}_n = \Omega_n^1 \cup \Omega_n^2$ 

with  $d(\Omega_n^1, \Omega_n^2) \to \infty$  and  $\liminf_{n \to \infty} |\Omega_n^i| > \varepsilon > 0$  for i = 1, 2, and for some  $\varepsilon > 0$ . From (2.20), the following inequality holds:

$$\left|\frac{1}{\lambda_3(\Omega_n)} - \frac{1}{\lambda_3(\tilde{\Omega}_n)}\right| \le \|A_{\Omega_n} - A_{\tilde{\Omega}_n}\|_2.$$

Since for the minimizing sequence  $\{\Omega_n\}_{n\in\mathbb{N}}$ , we have  $\lambda_3(\Omega_n) \to \lambda_3^* = \inf \lambda_3 > 0$  we get that  $\{\tilde{\Omega}_n\}_{n\in\mathbb{N}}$  is also a minimizing sequence. Following the second assertion of Lemma 5.3.2, we get that the minimum is attained for three equal balls of measure c/3.

We previously used inequality  $\lambda_3(\Omega_n) \to \lambda_3^* > 0$  which comes from  $\lambda_3(\Omega_n) \ge \lambda_1(\Omega_n)$  and the fact that the first eigenvalue is minimized for the ball, hence is strictly positive.

From the previous proof, we see that the optimal set  $\Omega_3^*$  is

- 1. either connected,
- 2. or the union of three disjoint balls of volume c/3.

We already know that, in dimension 2 and 3, it is connected, see Corollary 5.2.2. Moreover, in dimension 2, Wolff and Keller have proved in [213] that the disk is a local minimizer for  $\lambda_3$ . They use a perturbation argument. More precisely, they show that the third eigenvalue of a domain  $\Omega_{\varepsilon}$  given in polar coordinates by  $r = R(\theta, \varepsilon)$  where R has an expansion like

$$R(\theta, \varepsilon) = 1 + \varepsilon \sum_{n = -\infty}^{\infty} a_n e^{in\theta} + \varepsilon^2 \sum_{n = -\infty}^{\infty} b_n e^{in\theta} + O(\varepsilon^3)$$
 (5.9)

is given by

$$\lambda_3(\Omega_{\varepsilon}) = \pi j_{1,1}^2 (1 + 2|\varepsilon||a_2|) + O(\varepsilon^2).$$

In the case where  $a_2 \neq 0$ , we immediately get the result. When  $a_2 = 0$  it is necessary to look at the following term in the expansion, but the conclusion is the same

So, it is natural to state the following open problem:

**Open problem 8.** Prove that the optimal domain for  $\lambda_3$  is a ball in dimension 2 and 3 and the union of three identical balls in dimension  $N \geq 4$ .

#### 5.4 Case of higher eigenvalues

In order to investigate the existence of a solution for problem

$$\min_{\Omega \in \mathcal{A}_c(\mathbb{R}^N)} \lambda_k(\Omega) \tag{5.10}$$

for  $k \geq 4$ , one can invoke an induction argument. As in Theorem 5.3.3, the idea is to consider a minimizing sequence to which we apply the concentration-compactness Theorem 5.3.1. If compactness occurs, the existence of a minimizer follows. If dichotomy occurs, the existence of a minimizer is reduced to the study of minimizers for eigenvalues of strictly lower order.

Thus, we formulate the following lemma which gives an extension of Wolff-Keller's Theorem 5.2.1 to minimizing sequences.

**Lemma 5.4.1.** Let us fix  $k \geq 4$ . If  $\Omega_n = \Omega_n^1 \cup \Omega_n^2$  is a minimizing sequence for problem (5.10) such that  $\liminf_{n\to\infty} |\Omega_n^1| > 0$ ,  $\liminf_{n\to\infty} |\Omega_n^2| > 0$ ,  $\exp(\Omega_n^1 \cap \Omega_n^2) = 0$  and  $\Omega_n$  bounded, then there exists  $1 \leq j \leq k-1$  and there exist  $c_1, c_2 > 0$  with  $c_1 + c_2 = c$ , such that for a subsequence (still denoted with the same index) we have

$$\lim_{n \to \infty} \lambda_{k-j}(\Omega_n^1) = \inf_{\Omega \in \mathcal{A}_{c_1}(\mathbb{R}^N)} \lambda_{k-j}(\Omega), \tag{5.11}$$

$$\lim_{n \to \infty} \lambda_j(\Omega_n^2) = \inf_{\Omega \in \mathcal{A}_{co}(\mathbb{R}^N)} \lambda_j(\Omega).$$
 (5.12)

*Proof.* The proof follows the same ideas as Lemma 5.3.2. There exists an index  $1 \le j \le k-1$  such that for a subsequence still denoted with the same index we have

$$\lambda_k(\Omega_n^1 \cup \Omega_n^2) = \lambda_{k-j}(\Omega_n^1) \text{ if } \lambda_j(\Omega_n^2) \leq \lambda_{k-j}(\Omega_n^1) \leq \lambda_{j+1}(\Omega_n^2).$$

There exists  $c_1, c_2 > 0$ ,  $c_1 + c_2 = c$  such that for a subsequence still denoted with the same index we have  $|\Omega_n^1| \to c_1$  and  $|\Omega_n^2| \to c_2$ . Then, if relation (5.11) is not true we can replace  $\{\Omega_n^1\}_{n\in\mathbb{N}}$  by a minimizing sequence for  $\lambda_{k-j}$  in  $\mathcal{A}_{c_1}(\mathbb{R}^N)$  consisting of bounded sets. Suppose that this sequence is denoted by  $\{\Omega_n^{1*}\}_{n\in\mathbb{N}}$ .

Then there exists t > 0 such that choosing the new sequence  $\{t\Omega_n^{1*} \cup \frac{1}{t}\Omega_n^2\}$ , we get that

$$\liminf_{n \to \infty} \lambda_k(t\Omega_n^{1*} \cup \frac{1}{t}\Omega_n^2) < \lim_{n \to \infty} \lambda_k(\Omega_n^1 \cup \Omega_n^2),$$

in contradiction with the choice of  $\{\Omega_n^1 \cup \Omega_n^2\}_{n \in \mathbb{N}}$ . Here  $t\Omega$  denotes the expansion of ratio t of the set  $\Omega$  with respect to the origin. Since  $\Omega_n^{1*}$  and  $\Omega_n^2$  are bounded, one can translate  $\Omega_n^2$  such that  $\Omega_n^{1*} \cap \Omega_n^2 = \emptyset$ .

Relation (5.12) is obtained analogously.

We moreover remark as in Theorem 5.2.1, that  $c_1$  and  $c_2$  are such that

$$\inf_{\Omega \in \mathcal{A}_{c_1}(\mathbb{R}^N)} \lambda_{k-j}(\Omega) = \inf_{\Omega \in \mathcal{A}_{c_2}(\mathbb{R}^N)} \lambda_j(\Omega). \qquad \Box$$

Roughly speaking, Lemma 5.4.1 asserts that a minimizing sequence for  $\lambda_k$ , is either quasi-connected, or if it has more than one connected component, each one is minimizing an eigenvalue of strictly inferior rank over sets of prescribed measure.

**Theorem 5.4.2.** For  $k \geq 3$ , let us suppose that a bounded minimizer exists for  $\lambda_3, ..., \lambda_{k-1}, \lambda_k$  in  $\mathcal{A}_c(\mathbb{R}^N)$ . Then, at least one minimizer (bounded or unbounded) exists for  $\lambda_{k+1}$  in  $\mathcal{A}_c(\mathbb{R}^N)$ .

*Proof.* Let us suppose that a minimizer exists for  $\lambda_3, ..., \lambda_{k-1}, \lambda_k$  in  $\mathcal{A}_c(\mathbb{R}^N)$ . Let us consider a minimizing sequence  $\{\Omega_n\}_{n\in\mathbb{N}}$  for  $\lambda_{k+1}$  in  $\mathcal{A}_c(\mathbb{R}^N)$ . Without restricting the generality, for every  $n\in\mathbb{N}$  the set  $\Omega_n$  can be chosen bounded. Indeed, we can replace  $\Omega_n$  by its intersection with a ball large enough depending on n, such that  $|\lambda_{k+1}(\Omega_n) - \lambda_{k+1}(\Omega_n \cap B_{r_n})| \leq \frac{1}{n}$ . Following Theorem 5.3.1, there are two possibilities.

If compactness occurs, then (for a subsequence still denoted with the same index) we have that  $A_{y_n+\Omega_n}$  converges in the uniform operator topology of  $L^2(\mathbb{R}^N)$  to  $A_{\mu}$ . Then, as in Theorem 5.3.3,  $\Omega_{\mu}$  is a minimizer for  $\lambda_{k+1}$  in  $\mathcal{A}_c(\mathbb{R}^N)$ .

If dichotomy occurs, then the sequence given by Theorem 5.3.1,  $\tilde{\Omega}_n \subseteq \Omega_n$ , such that  $\tilde{\Omega}_n = \Omega_n^1 \cup \Omega_n^2$ , with  $d(\Omega_n^1, \Omega_n^2) \to \infty$  and  $\liminf_{n \to \infty} |\Omega_n^i| > 0$  for i = 1, 2 is also minimizing. Using Lemma 5.4.1, there exists  $1 \le j \le \frac{k}{2}$  and  $c_1^j, c_2^j > 0$ ,  $c_1^j + c_2^j = c$  such that the sequence  $\{\Omega_n^1\}_n$  is minimizing for  $\lambda_j$  in the class  $\mathcal{A}_{c_1^j}(\mathbb{R}^N)$  and  $\{\Omega_n^2\}_n$  is minimizing for  $\lambda_{n-j}$  in the class  $\mathcal{A}_{c_2^j}(\mathbb{R}^N)$ . Using the hypothesis on the existence and boundedness of the optimum for  $\lambda_j$  and  $\lambda_{k+1-j}$  in the corresponding classes, denoted respectively  $\Omega_j^{c_j^1}$  and  $\Omega_{k+1-j}^{c_j^2}$ , the optimum for  $\lambda_{k+1}$  is  $\tau \Omega_j^{c_j^1} \cup \Omega_{k+1-j}^{c_j^2}$ . Since these sets are bounded, we can translate them such that  $\Omega_j^{c_j^1} \cap \Omega_{k+1-j}^{c_j^2} = \emptyset$ , where  $\tau \Omega_j^{c_j^1}$  denotes a translation of  $\Omega_j^{c_j^1}$  such that  $\tau \Omega_j^{c_j^1} \cap \Omega_{k+1-j}^{c_j^2} = \emptyset$ .

**Remark 5.4.3.** Following the previous theorem, if there exists a connected (or quasi-connected) set  $\Omega$  in  $\mathcal{A}_c(\mathbb{R}^N)$  and  $\varepsilon > 0$  such that

$$\lambda_k(\Omega) < \inf\{\lambda_k(\Omega_1 \cup \Omega_2), \operatorname{cap}(\Omega_1 \cap \Omega_2) = 0, |\Omega_1| + |\Omega_2| = c, |\Omega_1| > \varepsilon, |\Omega_2| > \varepsilon\},$$
(5.13)

then problem (5.10) has at least one solution.

Let us take as example  $\lambda_4$ . Either the minimizer exists and is quasi-connected (if inequality (5.13) holds), or it is the union of a minimizer for  $\lambda_3$  with a ball, or it is the union of four balls. If it is the union of a minimizer for  $\lambda_3$  say  $\Omega$  and a ball B, the optimum for  $\lambda_4$  is  $\Omega \cup B$ , provided that  $\operatorname{cap}(\Omega \cap B) = 0$ . If  $\Omega$  is dense in  $\mathbb{R}^N$  it wouldn't be possible to place the ball B such that  $\operatorname{cap}(\Omega \cap B) = 0$ . Thus, a sufficient condition is to suppose that  $\Omega$  is bounded. Intuitively the minimizer for  $\lambda_3$  should be bounded, but the proof of this assertion is not known.

For the fourth eigenvalue, the conjecture is the following:

**Open problem 9.** Prove that the optimal domain for  $\lambda_4$  is the union of two balls whose radii are in the ratio  $\sqrt{j_{0,1}/j_{1,1}}$  in dimension 2, where  $j_{0,1}$  and  $j_{1,1}$  are respectively the two first zeros of the Bessel functions  $J_0$  et  $J_1$ .

Looking at the previous results and conjectures, P. Szegö asked the following question:

Is it true that the minimizer of any eigenvalue of the Laplace-Dirichlet operator is a ball or a union of balls?

The answer to this question is NO. For example, Wolff and Keller in [213] remarked that the thirteenth (!) eigenvalue of a square is lower than the thirteenth eigenvalue of any union of disks of the same area. Actually, it is not necessary to go to the 13th eigenvalue. Numerical experiments, cf [164] and Figure 5.1, show that for the n-th eigenvalue with n larger than or equal to 5 the minimizer is no longer a ball or a union of balls. More precisely, Figure 5.1 obtained by E. Oudet, see [164] shows what are the candidates to be the minimizers for  $\lambda_k$ ,  $3 \le k \le 10$ . Let us remark that, in all cases, the eigenvalue at the optimum is multiple (at least numerically) confirming Open problem 1.

Let us finish this chapter with some other open problems:

**Open problem 10.** Prove that there exists a minimizer for  $\lambda_k(\Omega)$  among open sets  $\Omega$  of given volume (see Theorem 5.4.2).

**Open problem 11.** Assuming existence of such a minimizer, study the regularity and the geometric properties (e.g. symmetries) of such a minimizer.

A generalization of problem 8:

**Open problem 12.** Prove that the N-ball minimizes  $\lambda_{N+1}$  among sets of given volume in  $\mathbb{R}^N$ .

| No | Optimal union of discs |        | Computed shapes |        |
|----|------------------------|--------|-----------------|--------|
| 3  |                        | 46.125 |                 | 46.125 |
| 4  |                        | 64.293 |                 | 64.293 |
| 5  |                        | 82.462 |                 | 78.47  |
| 6  |                        | 92.250 |                 | 88.96  |
| 7  |                        | 110.42 |                 | 107.47 |
| 8  |                        | 127.88 |                 | 119.9  |
| 9  |                        | 138.37 |                 | 133.52 |
| 10 |                        | 154.62 |                 | 143.45 |

Figure 5.1: A table showing, for each eigenvalue λk, 3 ≤ k ≤ 10, the optimal union of disks (left) and the optimal shape (right) this one is obtained numerically.

## Chapter 6

# Functions of Dirichlet eigenvalues

#### 6.1 Introduction

In 1955, L. Payne, G. Pólya and H. Weinberger in [168] considered the problem of bounding ratios of eigenvalues. In particular, they proved that the ratio  $\lambda_2/\lambda_1$  is less than or equal to 3 (in dimension 2). They were led to conjecture that the optimal domain for this ratio is a disk. After many attempts, and improvements of the bound 3, this conjecture was proved 35 years later by M. Ashbaugh and R. Benguria, see [9] for the two-dimensional case and [10] for the N-dimensional case. This proof is explained in section 6.2.1. After this success, M. Ashbaugh and R. Benguria applied this isoperimetric inequality to some other ratios which are considered in section 6.2.2. Nevertheless, many open problems remain for similar ratios. Some of them are presented in section 6.2.3, in particular those stated by Payne, Pólya and Weinberger in [168].

In section 6.3, we investigate some other kinds of functions of eigenvalues, namely sums or sums of inverses. A very few things are known in that context.

At last, section 6.4 is completely devoted to functions of the two first Dirichlet eigenvalues  $\lambda_1$  and  $\lambda_2$ . Thanks to a beautiful description of the range, in the plane  $(\lambda_1, \lambda_2)$ , of the possible values for the two first eigenvalues of a domain of given area, D. Bucur, G. Buttazzo and I. Figueiredo were able to prove a very general existence result, see Theorem 6.4.4 in section 6.4.2

#### 6.2 Ratio of eigenvalues

#### 6.2.1 The Ashbaugh-Benguria Theorem

**Theorem 6.2.1 (Ashbaugh-Benguria).** The ball maximizes the ratio  $\frac{\lambda_2}{\lambda_1}$ .

*Proof.* We give the main ingredients of the proof. We follow, in particular, the presentation of the authors in [9] and [14]. Let  $\Omega$  be any open set in  $\mathbb{R}^N$ ; we denote by  $\lambda_1, \lambda_2$  its two first eigenvalues for the Laplacian with Dirichlet boundary conditions and by  $u_1, u_2$  the corresponding normalized eigenfunctions.

First step: the min principle. We start with the min formula for  $\lambda_2$  (1.34) which is written here

$$\lambda_2 = \min_{\begin{subarray}{l} v \in H_0^1(\Omega), \\ \int_{\Omega} v u_1 \, dx = 0 \end{subarray}} \frac{\int_{\Omega} |\nabla v(x)|^2 \, dx}{\int_{\Omega} v(x)^2 \, dx} \,. \tag{6.1}$$

We apply (6.1) with  $v = Pu_1$  where P is any regular function such that the orthogonality condition

$$\int_{\Omega} Pu_1^2 \, dx = 0 \tag{6.2}$$

is satisfied. This gives

$$\lambda_2 \leq \frac{\int_{\Omega} |\nabla P u_1|^2 \, dx}{\int_{\Omega} P^2 u_1^2 \, dx} = \frac{\int_{\Omega} u_1^2 |\nabla P|^2 \, dx + \int_{\Omega} P^2 |\nabla u_1|^2 \, dx + 2 \int_{\Omega} u_1 P \nabla u_1 . \nabla P \, dx}{\int_{\Omega} P^2 u_1^2 \, dx} \; .$$

Now, multiplying the eigenvalue equation by  $P^2u_1$  and integrating on  $\Omega$  yields

$$\lambda_1 \int_{\Omega} u_1 P^2 u_1 \, dx = -\int_{\Omega} \Delta u_1 P^2 u_1 \, dx = \int_{\Omega} \nabla u_1 \cdot \nabla (P^2 u_1) \, dx$$

and so

$$\lambda_1 \int_{\Omega} P^2 u_1^2 \, dx = 2 \int_{\Omega} u_1 P \nabla u_1 \cdot \nabla P \, dx + \int_{\Omega} P^2 |\nabla u_1|^2 \, dx \,. \tag{6.3}$$

Finally, (6.1) and (6.3) give

$$\lambda_2 - \lambda_1 \le \frac{\int_{\Omega} u_1^2 |\nabla P|^2 dx}{\int_{\Omega} P^2 u_1^2 dx} \tag{6.4}$$

for any  $C^1$  function P satisfying (6.2).

To get the isoperimetric result out of inequality (6.4) we need to make very special choices of the function P, in particular choices for which (6.4) is an equality if  $\Omega$  is a ball. We are going to choose functions  $P_i$  defined by

$$P_i(x) = g(r)\frac{x_i}{r}$$
 where  $r = (x_1^2 + \dots + x_N^2)^{1/2}$  (6.5)

with a non-negative function g(r) which will be chosen later. Of course, the main difficulty is to prove that we can fix the origin in such a way that (6.2) is satisfied for any i. This is due to H. Weinberger in [207] and we give it as an independent Lemma since we will also use it in the next chapter.

Second step: a center of mass result

**Lemma 6.2.2 (Weinberger).** Let  $\Omega \subset \mathbb{R}^N$ ,  $u_1$  a continuous function defined on  $\Omega$  and g a non-negative continuous function be given. Then, we can fix the origin in some point such that  $\int_{\Omega} g(r) \frac{x_i}{r} u_1^2 dx = 0$  for  $i = 1, \ldots, N$ .

*Proof.* Let us consider a (large) ball D, centered at O and which strictly contains  $\Omega$ . We introduce the function  $F:D\to\mathbb{R}^N$  defined by its i-th component  $f_i$  given by

$$f_i(x_1, x_2, \dots, x_N) = \int_{\Omega} g(|Y - X|) \frac{y_i - x_i}{|Y - X|} u_1^2(Y) dY$$
.

F is a continuous function (since the integrand is continuous as a function of X for almost every Y and is bounded on  $\Omega$  which is itself bounded). Moreover, let us take X on the boundary of D. The inward normal at X is given by  $n = -\frac{X}{|X|}$  and we have

$$F(X).n = -\sum_{i=1}^{N} f_i(X) \frac{x_i}{|X|} = \int_{\Omega} g(|Y - X|) \frac{|X|^2 - X.Y}{|X||Y - X|} u_1^2(Y) dY.$$

This means that F points inward on the boundary of D. It follows, by the Brouwer fixed point theorem, that F vanishes at least once within D which gives the desired result.

Third step: a special choice of the functions  $P_i$ . We can now apply (6.4) with  $P_i$  given in (6.5). Summing for i = 1 to N yields

$$\lambda_2 - \lambda_1 \le \frac{\int_{\Omega} u_1^2 \left(\sum_{i=1}^N |\nabla P_i|^2\right) dx}{\int_{\Omega} u_1^2 \left(\sum_{i=1}^N P_i^2\right) dx}.$$

Now, from the definition of  $P_i$ ,

$$\sum_{i=1}^{N} P_i^2 = g(r)^2$$

and

$$\sum_{i=1}^{N} |\nabla P_i|^2 = (g'(r))^2 + (N-1)g(r)^2/r^2.$$

Then, we finally get

$$\lambda_2 - \lambda_1 \le \frac{\int_{\Omega} [g'(r)^2 + (N-1)g(r)^2/r^2] u_1^2 dx}{\int_{\Omega} g(r)^2 u_1^2 dx} \,. \tag{6.6}$$

The idea is now to choose the trial function g in such a way that inequality (6.6) becomes an equality when  $\Omega$  is a ball. This leads to the following choice:

$$q(r) = w(\gamma r)$$

where

$$w(x) := \begin{cases} \frac{J_{n/2}(\beta x)}{J_{n/2-1}(\alpha x)} & \text{for } 0 \le x < 1, \\ w(1) = \lim_{x \to 1^{-}} w(x) & \text{for } x \ge 1, \end{cases}$$
 (6.7)

with  $\alpha = j_{N/2-1,1}$  (the first zero of the Bessel function  $J_{N/2-1}$ ),  $\beta = j_{N/2,1}$  and  $\gamma = \sqrt{\lambda_1}/\alpha$ . Substituting into (6.6), we arrive at

$$\lambda_2 - \lambda_1 \le \frac{\lambda_1 \int_{\Omega} B(\gamma r) u_1^2 dx}{\alpha^2 \int_{\Omega} w(\gamma r)^2 u_1^2 dx}$$

$$(6.8)$$

where

$$B(x) := w'(x)^2 + (N-1)\frac{w(x)^2}{r^2}.$$

The following technical lemma is proved (in two different manners) in [9] and [11]. We omit the proof here.

**Lemma 6.2.3.** • w(x) is increasing for  $x \in [0, 1]$ ,

• B(x) is decreasing for  $x \in [0,1]$ .

Fourth step: spherical rearrangements. We define, in section 2.1, the spherical decreasing rearrangement  $f^*$  (or Schwarz rearrangement) of a function f. Exactly in the same way, we can define its spherical increasing rearrangement  $f_*$  (by  $f_*(x) = \inf\{c/x \in \Omega_-(c)^*\}$ ). Where  $\Omega_-(c) := \{y \in \Omega : f(y) \le c\}$ ). We recall that  $\Omega^*$  denotes the ball (centered at O) of same volume as  $\Omega$ .

Then, the following properties of these rearrangements are well known (see [122], [97]):

- (i) If f is a radially symmetric function (f = f(|x|)) defined on  $\Omega$ , non-negative and decreasing (resp increasing) as a function of r = |x|, then  $f^*(r) \leq f(r)$  (resp  $f_*(r) \geq f(r)$ ) for r between 0 and the radius of  $\Omega^*$ .
- (ii) If f and g are non-negative functions, then

$$\int_{\Omega^*} f_* g^* dx \le \int_{\Omega} fg dx \le \int_{\Omega^*} f^* g^* dx .$$

Applying these two properties to the functions B (decreasing) and w (increasing) gives the inequalities

$$\int_{\Omega} B(\gamma r) u_1^2 \, dx \le \int_{\Omega^*} B(\gamma r)^* u_1^{*2} \, dx \le \int_{\Omega^*} B(\gamma r) u_1^{*2} \, dx \tag{6.9}$$

and

$$\int_{\Omega} w(\gamma r)^2 u_1^2 dx \ge \int_{\Omega^*} w(\gamma r)_*^2 u_1^{*2} dx \ge \int_{\Omega^*} w(\gamma r)^2 u_1^{*2} dx . \tag{6.10}$$

Fifth step: a Chiti's comparison result. We now state a comparison result due to Chiti, see [55]. Let  $B_1$  be the ball of radius  $R_1 = 1/\gamma$ . Its first eigenvalue is (see (1.29))  $j_{N/2-1,1}^2/R_1^2 = \alpha^2\gamma^2 = \lambda_1$  associated to the eigenfunction

$$z(r) = cr^{1-N/2}J_{N/2-1}(\sqrt{\lambda_1}r)$$
 (6.11)

Let us remark that the Faber-Krahn Theorem 3.2.1 implies that  $B_1$  is contained in  $\Omega^*$  (since this last ball has a least eigenvalue), and the inclusion is strict as soon as  $\Omega$  is not a ball.

**Lemma 6.2.4 (Chiti).** Let us assume that the normalization constant c in (6.11) is chosen so that

$$\int_{\Omega} u_1^2 dx = \int_{\Omega^*} u_1^{*2} dx = \int_{B_1} z^2 dx . \tag{6.12}$$

Then, there exists a point  $r_1 \in (0, 1/\gamma)$  such that

$$\begin{cases}
 u_1^*(r) \le z(r) & \text{for } 0 \le r \le r_1, \\
 u_1^*(r) \ge z(r) & \text{for } r_1 \le r \le 1/\gamma.
\end{cases}$$
(6.13)

This lemma follows from the work of G. Talenti, [199] which makes use of rearrangement results, Faber-Krahn inequality and isoperimetric inequality.

Let us take now for f any increasing function and let us denote by  $R^*$  the radius of  $\Omega^*$ . Denoting by  $C_N$  the volume of the unit ball in  $\mathbb{R}^N$  (its surface area is then  $NC_N$ ), we have the following chain of equalities and inequalities:

$$\begin{split} &\int_{B_1} f(r)z^2 dx - \int_{\Omega^*} f(r)u_1^{*2} dx \\ &= NC_N \left[ \int_0^{1/\gamma} f(r)(z^2 - u_1^{*2})r^{N-1} dr - \int_{1/\gamma}^{R^*} f(r)u_1^{*2}r^{N-1} dr \right] \\ &\leq NC_N f(r_1) \left[ \int_0^{1/\gamma} (z^2 - u_1^{*2})r^{N-1} dr - \int_{1/\gamma}^{R^*} u_1^{*2}r^{N-1} dr \right] \\ &= f(r_1) \left[ \int_{B_1} z^2 dx - \int_{\Omega^*} u_1^{*2} dx \right] = 0, \end{split}$$

the last equality coming from (6.12). So, we finally get that, for any increasing function f:

$$\int_{B_1} f(r)z^2 dx \le \int_{\Omega^*} f(r)u_1^{*2} dx . \tag{6.14}$$

In particular, introducing this inequality in (6.9) (with  $f(r) = -B(\gamma r)$ ) and in (6.10) (with  $f(r) = w(\gamma r)^2$ ), we get

$$\int_{\Omega} B(\gamma r) u_1^2 dx \le \int_{B_1} B(\gamma r) z^2 dx \tag{6.15}$$

and

$$\int_{\Omega} w(\gamma r)^2 u_1^2 \, dx \ge \int_{B_1} w(\gamma r)^2 z^2 \, dx \ . \tag{6.16}$$

Combining these two inequalities with (6.8) gives

$$\lambda_{2} - \lambda_{1} \leq \frac{\lambda_{1} \int_{B_{1}} B(\gamma r) z^{2} dx}{\alpha^{2} \int_{B_{1}} w(\gamma r)^{2} z^{2} dx} = \frac{\lambda_{1} \int_{0}^{1} B(r) J_{N/2-1}^{2} (\alpha r) r dr}{\alpha^{2} \int_{0}^{1} w(r)^{2} J_{N/2-1}^{2} (\alpha r) r dr}$$
$$= \frac{\lambda_{1}}{\alpha^{2}} [(\lambda_{2} - \lambda_{1}) \text{ for the ball of radius 1}] = \frac{\lambda_{1}}{\alpha^{2}} (\beta^{2} - \alpha^{2})$$

which immediately gives the desired inequality, namely

$$\frac{\lambda_2}{\lambda_1} \le \frac{\beta^2}{\alpha^2} = \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2} \ .$$

**Remark 6.2.5.** As in previous situations (Theorems 3.2.1 and 4.1.1), it can be proved that the ball is the unique maximizer, up to a set of zero capacity. To see this, we can remark that equality in inequalities (6.6) or (6.15), (6.16) holds only in the case of a ball.

#### 6.2.2 Some other ratios

We can now apply the previous result to another ratio:

**Theorem 6.2.6 (Ashbaugh-Benguria).** The maximum of the ratio  $\lambda_4(\Omega)/\lambda_2(\Omega)$  among bounded open sets of  $\mathbb{R}^N$  is achieved by the union of two identical balls or, more generally, by any set of the kind  $\Omega = B_1 \cup \Omega_2$  (disjoint union) where  $B_1$  is a ball and  $\Omega_2$  is any open set such that  $\lambda_1(\Omega_2) \leq \lambda_1(B_1) \leq \lambda_2(\Omega_2) \leq \lambda_2(B_1) \leq \lambda_3(\Omega_2)$ .

*Proof.* Let us begin with the case  $\Omega$  connected. As in Theorem 4.1.1, we denote by  $\Omega^+$  and  $\Omega^-$  the nodal domains of  $u_2$  the second eigenfunction of  $\Omega$ . We introduce the two first (normalized) eigenfunctions for each nodal domain:  $u_1^+, u_2^+, u_1^-, u_2^-$ . We assume that these functions are extended by 0 outside their natural domain of definition. By construction, these four functions are orthogonal for the  $L^2$ -scalar product on  $\Omega$ .

Let us now consider a trial function v, (nontrivial) linear combination of these four functions:  $v=c_1^+u_1^++c_2^+u_2^++c_1^-u_1^-+c_2^-u_2^-$ . We always can choose the

coefficients in order that v is orthogonal to  $u_1, u_2, u_3$ , the three first eigenfunctions of  $\Omega$ . Then, by min formulae (1.34):

$$\lambda_4(\Omega) \le \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx} = \frac{c_1^{+2} \lambda_1(\Omega^+) + c_2^{+2} \lambda_2(\Omega^+) + c_1^{-2} \lambda_1(\Omega^-) + c_2^{-2} \lambda_2(\Omega^-)}{c_1^{+2} + c_2^{+2} + c_1^{-2} + c_2^{-2}}$$
(6.17)

the last equality coming from the orthogonality of the four functions. Now, let us denote by  $\gamma = j_{N/2,1}^2/j_{N/2-1,1}^2$  the ratio  $\lambda_2/\lambda_1$  for the ball. According to Theorem 6.2.1, we have  $\lambda_2(\Omega^+) \leq \gamma \lambda_1(\Omega^+)$  and obviously  $\lambda_1(\Omega^+) \leq \gamma \lambda_1(\Omega^+)$ , and similarly for  $\Omega^-$ . Therefore, (6.17) becomes:

$$\lambda_4(\Omega) \le \gamma \frac{c_1^{+2} \lambda_1(\Omega^+) + c_2^{+2} \lambda_1(\Omega^+) + c_1^{-2} \lambda_1(\Omega^-) + c_2^{-2} \lambda_1(\Omega^-)}{c_1^{+2} + c_2^{+2} + c_1^{-2} + c_2^{-2}} . \tag{6.18}$$

Now we know (Proposition 1.3.3) that  $\lambda_2(\Omega)$  is the first eigenvalue for  $\Omega^+$  and  $\Omega^-$ :  $\lambda_1(\Omega_+) = \lambda_1(\Omega_-) = \lambda_2(\Omega)$ . Therefore, (6.18) yields  $\lambda_4(\Omega) \leq \gamma \lambda_2(\Omega)$  or

$$\frac{\lambda_4(\Omega)}{\lambda_2(\Omega)} \le \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2}.$$
(6.19)

Looking at the equality case in (6.17), (6.18), we see that it can occur only if  $\Omega^+$  and  $\Omega_-$  are balls, which is impossible for a connected domain. So inequality (6.19) is strict for any connected open set.

Now, if  $\Omega$  has exactly two connected components  $\Omega_1$  and  $\Omega_2$ , we can assume that  $\lambda_1(\Omega_2) \leq \lambda_1(\Omega_1)$ . Now we investigate four different cases.

(i) 
$$\lambda_1(\Omega_2) \leq \lambda_1(\Omega_1) \leq \lambda_2(\Omega_2) \leq \lambda_2(\Omega_1)$$
, then

$$\frac{\lambda_4(\Omega)}{\lambda_2(\Omega)} \le \frac{\lambda_2(\Omega_1)}{\lambda_1(\Omega_1)} \le \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2}$$

with equality if and only if  $\Omega_1$  is a ball which gives the maximum announced in the theorem.

(ii) 
$$\lambda_1(\Omega_2) \leq \lambda_1(\Omega_1) \leq \lambda_2(\Omega_1) \leq \lambda_2(\Omega_2)$$
, then

$$\frac{\lambda_4(\Omega)}{\lambda_2(\Omega)} \le \frac{\lambda_2(\Omega_2)}{\lambda_1(\Omega_1)} \le \frac{\lambda_2(\Omega_2)}{\lambda_1(\Omega_2)} \le \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2}$$

with equality if and only if  $\Omega_2$  is a ball and  $\lambda_1(\Omega_1) = \lambda_1(\Omega_2)$ : so we recover case (i).

(iii) 
$$\lambda_1(\Omega_2) \leq \lambda_2(\Omega_2) \leq \lambda_1(\Omega_1) \leq \lambda_3(\Omega_2)$$
, then

$$\frac{\lambda_4(\Omega)}{\lambda_2(\Omega)} \le \frac{\lambda_3(\Omega_2)}{\lambda_2(\Omega_2)} \le \frac{\lambda_4(\Omega_2)}{\lambda_2(\Omega_2)} < \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2}$$

the last inequality coming from the beginning of the proof.

(iv)  $\lambda_1(\Omega_2) \leq \lambda_2(\Omega_2) \leq \lambda_3(\Omega_2) \leq \lambda_1(\Omega_1)$ , then

$$\frac{\lambda_4(\Omega)}{\lambda_2(\Omega)} \le \frac{\lambda_4(\Omega_2)}{\lambda_2(\Omega_2)} < \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2}$$

the last inequality still coming from the beginning of the proof.

At last, the case of more than two connected components follows thanks to induction.  $\Box$ 

Using the trivial inequalities  $\lambda_2 \le \lambda_3$  and  $\lambda_3 \le \lambda_4$  and looking at the equality cases yields:

Corollary 6.2.7. The maximum of the ratio  $\lambda_3(\Omega)/\lambda_2(\Omega)$  among bounded open sets of  $\mathbb{R}^N$  is achieved by the union of two identical balls or, more generally, by any set of the kind  $\Omega = B_1 \cup \Omega_2$  (disjoint union) where  $B_1$  is a ball and  $\Omega_2$  is any open set such that  $\lambda_1(\Omega_2) \leq \lambda_1(B_1) \leq \lambda_2(\Omega_2) = \lambda_2(B_1) \leq \lambda_3(\Omega_2)$ . The maximum of the ratio  $\lambda_4(\Omega)/\lambda_3(\Omega)$  among bounded open sets of  $\mathbb{R}^N$  is achieved by the union of three identical balls or, more generally, by any set of the kind  $\Omega = B_1 \cup \Omega_2$  (disjoint union) where  $B_1$  is a ball and  $\Omega_2$  is any open set such that  $\lambda_1(\Omega_2) \leq \lambda_1(B_1) = \lambda_2(\Omega_2) \leq \lambda_2(B_1) \leq \lambda_3(\Omega_2)$ .

#### 6.2.3 A collection of open problems

For ratios of eigenvalues, many problems remain open. A good overview and discussion is given in [4]. Below, some of them are listed.

**Open problem 13.** (see [168] and [12] where the following maximization result is proved with some symmetry assumptions) Prove that the disk maximizes the quotient  $\frac{\lambda_2 + \lambda_3}{\lambda_1}$  among plane domains.

Prove that the ball maximizes the quotient  $\frac{\sum_{i=2}^{N+1} \lambda_i}{\lambda_1}$  among domains of  $\mathbb{R}^N$ .

**Open problem 14.** Prove that the disk maximizes the quotient  $\frac{\lambda_4}{\lambda_1}$  among plane domains.

Prove that the ball maximizes the quotient  $\frac{\lambda_{N+2}}{\lambda_1}$  among domains of  $\mathbb{R}^N$ .

Open problem 15. (see [12]) Prove that the disk minimizes the quantity  $\frac{1}{\lambda_2 - \lambda_1} + \frac{1}{\lambda_3 - \lambda_1}$  among plane domains.

Prove that the ball minimizes the quantity  $\frac{1}{\lambda_2 - \lambda_1} + \frac{1}{\lambda_3 - \lambda_1} + \cdots + \frac{1}{\lambda_{N+1} - \lambda_1}$  among domains of  $\mathbb{R}^N$ .

**Open problem 16.** Prove existence of a domain which maximizes the following ratios, study the geometric properties of such maximizers (symmetries,...), if possible identify it:

- $\frac{\lambda_3}{\lambda_1}$  (in the plane this is not the disk, see [140] for numerical studies and conjectures),
- $\frac{\lambda_{m+1}}{\lambda_m}$ ,
- $\frac{\lambda_{2m}}{\lambda_m}$ .

#### 6.3 Sums of eigenvalues

#### **6.3.1** Sums of eigenvalues

Very little is known about sums of eigenvalues. Of course, Theorem 2.4.5 applies, which means that we always have existence of a minimizer in the class  $A_c$  of (quasi-)open sets  $\Omega \subset D$  of given volume ( $|\Omega| \leq c$ ) for any sum of eigenvalues.

In particular, it is natural to state the two following open problems which can be seen as "the next Faber-Krahn" inequality:

**Open problem 17.** • Prove that the disk minimizes  $\lambda_2 + \lambda_3$  among plane domains of given area.

• Prove that the ball minimizes  $\lambda_2 + \lambda_3 + \cdots + \lambda_{N+1}$  among domains in  $\mathbb{R}^N$  with a given volume.

Some support of these conjectures is given by the fact that

the disk is a critical point for the functional  $\Omega \mapsto \lambda_2(\Omega) + \lambda_3(\Omega)$ .

This is not completely obvious since  $\lambda_2 = \lambda_3$  is a double eigenvalue for the disk. Actually, in this situation, we can apply Theorem 2.5.8: for any deformation induced by a mapping  $\Phi(t)$  satisfying (2.37) with V fixed and  $\Omega_t = \Phi(t)(\Omega)$ ,  $t \to \lambda_2(\Omega_t)$  and  $t \to \lambda_3(\Omega_t)$  have (directional) derivatives at t = 0 which are the two eigenvalues of the  $2 \times 2$  matrix  $\mathcal{M}$  defined by:

$$\mathcal{M} = \begin{pmatrix} -\int_{\partial\Omega} \left(\frac{\partial u_2}{\partial n}\right)^2 V.n \, d\sigma & -\int_{\partial\Omega} \left(\frac{\partial u_2}{\partial n} \frac{\partial u_3}{\partial n}\right) V.n \, d\sigma \\ -\int_{\partial\Omega} \left(\frac{\partial u_2}{\partial n} \frac{\partial u_3}{\partial n}\right) V.n \, d\sigma & -\int_{\partial\Omega} \left(\frac{\partial u_2}{\partial n}\right)^2 V.n \, d\sigma \end{pmatrix}. \tag{6.20}$$

In particular,  $t \to \lambda_2(\Omega_t) + \lambda_3(\Omega_t)$  has a derivative which is the trace of the previous matrix i.e.,

$$\frac{d}{dt}(\lambda_2(\Omega_t) + \lambda_3(\Omega_t))|_{t=0} = -\int_{\partial\Omega} \left[ \left( \frac{\partial u_2}{\partial n} \right)^2 + \left( \frac{\partial u_3}{\partial n} \right)^2 \right] V.n \, d\sigma.$$

Now, since we can choose  $u_2$  and  $u_3$  to be respectively (see Proposition 1.2.14)

$$u_2(r,\theta) = \beta J_1(\alpha r) \cos \theta, \quad u_3(r,\theta) = \beta J_1(\alpha r) \sin \theta,$$

(where  $\beta$  is the normalization constant and  $\alpha = j_{1,1}/R$ ), we get  $\left(\frac{\partial u_2}{\partial n}\right)^2 + \left(\frac{\partial u_3}{\partial n}\right)^2 = \alpha^2 \beta^2 J_1'^2(\alpha) = constant$  and it follows that the derivative of  $t \to \lambda_2(\Omega_t) + \lambda_3(\Omega_t)$  is proportional to the derivative of the area which characterizes the critical sets here.

#### 6.3.2 Sums of inverses

Our first result is due to Luttinger, see [143]:

**Theorem 6.3.1 (Luttinger).** The unit disk maximizes the sum  $\sum_{j=1}^{\infty} \frac{1}{\lambda_j(\Omega)}$  among plane open sets of given area.

*Proof.* We only give a sketch of the proof. The main ingredient is the general inequality (6.23) involving the Green function of a domain  $\Omega$ . We will denote by  $G_{\Omega}(x,t;x')$  this Green function defined as the solution of

$$\begin{cases} \frac{\partial G}{\partial t} - \Delta G = 0 & \text{for } t > 0 \text{ and } x \in \Omega, \\ \lim_{t \to 0} G(x, t; x') = \delta_{x - x'} & \text{(the usual Dirac distribution)}. \end{cases}$$
(6.21)

In particular, it is classical that this Green function has the following expansion in the basis of eigenfunctions of  $\Omega$ :

$$G_{\Omega}(x,t;x') = \sum_{j=1}^{\infty} e^{-\lambda_j t} u_j(x) u_j(x')$$
 (6.22)

Now, let us consider two non-negative functions F and f. We denote by  $F^*$  and  $f^*$  their decreasing rearrangement as defined in Definition 2.1.1, and  $\Omega^*$  is the ball of same volume as  $\Omega$ . Then, the inequality is

$$\int_{\Omega \times \Omega} G_{\Omega}(x,t;x') F(x'-x) f(x) dx dx' \le \int_{\Omega^* \times \Omega^*} G_{\Omega^*}(x,t;x') F^*(x'-x) f^*(x) dx dx'.$$

$$(6.23)$$

In particular, choosing  $f \equiv 1$  and letting F(x'-x) approach the Delta function  $\delta_{x-x'}$ , we obtain

$$\int_{\Omega} G_{\Omega}(x,t;x) \, dx dx \le \int_{\Omega^*} G_{\Omega^*}(x,t;x) \, dx dx .$$

Replacing in the above inequality  $G_{\Omega}$  and  $G_{\Omega^*}$  by their expressions given in (6.22) yields, using normalization of the eigenfunctions,

$$\sum_{j=1}^{\infty} e^{-\lambda_j(\Omega)t} \le \sum_{j=1}^{\infty} e^{-\lambda_j(\Omega^*)t}$$
(6.24)

and Theorem 6.3.1 follows by integrating (6.24) between t=0 and  $t=+\infty$ .

**Remark 6.3.2.** By integrating (6.24) several times between t = s and  $t = +\infty$ , we easily get the generalization

$$\forall n \in \mathbb{N}^*, \quad \sum_{j=1}^{\infty} \frac{1}{\lambda_j^n(\Omega)} \le \sum_{j=1}^{\infty} \frac{1}{\lambda_j^n(\Omega^*)}.$$

For our next results (that we give without proofs), we need to work with plane domains conformally equivalent to the unit disk D. For that purpose, let us define the following class of plane open sets:

$$\mathcal{C} := \{\Omega; \ \Omega = f(D) \text{ with } f \text{ a conformal mapping such that } |f'(0)| = 1\}.$$
 (6.25)

This is the class of simply connected domains which are the conformal image of the unit disk through a normalized conformal mapping. In this class, G. Pólya and M. Schiffer proved the result in [173]

**Theorem 6.3.3 (Pólya-Schiffer).** Let n be any integer. The unit disk minimizes the sum  $\sum_{i=1}^{n} \frac{1}{\lambda_{j}(\Omega)}$  in the class C.

Later, R.S. Laugesen and C. Morpurgo in [137] proves the following generalization (see also B. Dittmar [77] for another proof when  $\Phi(x) = x^2$ ). They simply use a majorization result about sums of values of a convex function essentially due to Hardy, Littlewood and Pólya.

**Theorem 6.3.4 (Laugesen-Morpurgo).** Let n be any integer and  $\Phi$  be any function which is convex and increasing on  $\mathbb{R}_+$ , then the unit disk minimizes the sum  $\sum_{j=1}^n \Phi\left(\frac{1}{\lambda_j(\Omega)}\right)$  in the class C.

#### **6.4** General functions of $\lambda_1$ and $\lambda_2$

#### **6.4.1** Description of the set $\mathcal{E} = (\lambda_1, \lambda_2)$

Let D be a (large) ball in  $\mathbb{R}^N$  which is fixed throughout this section. We are interested in describing the set

$$\mathcal{E} = \{(x, y) \in \mathbb{R}^2; \ (x, y) = (\lambda_1(\Omega), \lambda_2(\Omega)), \ \Omega \subset D, |\Omega| \le c\}.$$

This set is represented in Figure 6.1.

Remark 6.4.1. Instead of considering an inequality constraint  $|\Omega| \leq c$ , we could have chosen an equality one  $|\Omega| = c$ . Actually, it will not change the set  $\mathcal{E}$ . Indeed, we have an obvious inclusion between the two sets. On the other hand, let us

![](_page_102_Figure_2.jpeg)

Figure 6.1: Range, in the plane  $(\lambda_1, \lambda_2)$ , of the possible values for the two first eigenvalues of a domain of given area.

consider a set  $\Omega$  with  $|\Omega| \leq c$ , and  $(x,y) = (\lambda_1(\Omega), \lambda_2(\Omega))$ . Now, consider the new set  $\widetilde{\Omega}$  which is the disjoint union of  $\Omega$  with a collection of several (small) balls in order that

- $\lambda_1(\widetilde{\Omega}) = \lambda_1(\Omega)$  and  $\lambda_2(\widetilde{\Omega}) = \lambda_2(\Omega)$  (for that, it suffices that the first eigenvalue of any small ball is larger than  $\lambda_2(\Omega)$ ),
- $|\widetilde{\Omega}| = c$ .

This proves the reverse inclusion.

#### First properties of the set $\mathcal{E}$

- The set  $\mathcal{E}$  obviously lies above the first bisector y = x.
- The set  $\mathcal{E}$  lies on the right of the line  $x = j_{N/2-1,1}^2 \omega_N^{2/N}/c^{2/N}$ , where  $\omega_N$  is the volume of the unit ball. Indeed, the above number is the first eigenvalue of a ball of volume c (point B on the figure), and this property is simply the Faber-Krahn inequality (Theorem 3.2.1).
- The set  $\mathcal{E}$  lies above the line  $y=j_{N/2-1,1}^2(2\omega_N)^{2/N}/c^{2/N}$ . Indeed, the above number is the second eigenvalue of the union of two balls of volume c/2 (point A on the figure), and this property is simply the Krahn-Szegö Theorem 4.1.1.
- The set  $\mathcal{E}$  lies below the line  $y = \frac{j_{N/2,1}^2}{j_{N/2-1,1}^2} x$ : this is the Ashbaugh-Benguria Theorem 6.2.1.

• The set  $\mathcal{E}$  is conical with respect to the origin: if  $(x,y) \in \mathcal{E}$ , then  $(tx,ty) \in \mathcal{E}$  for all  $t \geq 1$ . It follows immediately by considering the image of a set  $\Omega$  corresponding to (x,y) by a homothety of ratio  $1/\sqrt{t}$ .

In the following, we denote by  $\gamma = j_{N/2,1}^2/j_{N/2-1,1}^2$  the value of the ratio  $\lambda_2/\lambda_1$  for a ball.

#### A convexity and closedness property of the set $\mathcal{E}$

In an interesting paper [45], D. Bucur, G. Buttazzo and I. Figueiredo proved the following convexity property of  $\mathcal{E}$  (see Figure 6.1):

#### Theorem 6.4.2 (Bucur, Buttazzo, Figueiredo).

(i) The set  $\mathcal{E}$  is convex in the x-direction, namely:

$$\forall (x,y) \in \mathcal{E}, \ \forall t \in [0,1], \ ((1-t)x+ty,y) \in \mathcal{E}.$$

(ii) The set  $\mathcal{E}$  is convex in the y-direction, namely:

$$\forall (x,y) \in \mathcal{E}, \ \forall t \in [0,1], \ (x,(1-t)y+t\gamma x) \in \mathcal{E}.$$

*Proof.* We just give here the main ideas of the proof, for the details we refer to [45] and [44]. Let  $(x,y) = (\lambda_1(\Omega), \lambda_2(\Omega))$ . For the horizontal convexity, one can construct a decreasing continuous sequence (or homotopy)  $\Omega_1 \subset \Omega_t \subset \Omega$ ,  $t \in [0,1]$  such that

- $\Omega_0 = \Omega$ ,
- $\lambda_2(\Omega_t) = \lambda_2(\Omega)$ .
- $\lambda_1(\Omega_1) = \lambda_2(\Omega_1)$ .

Roughly speaking,  $\Omega_t$  is obtained from  $\Omega$  by removing an increasing portion of the nodal line of  $u_2$  and  $\Omega_1 = \{x \in \Omega, u_2(x) \neq 0\}$  is the open set  $\Omega$  without the whole nodal line for which we already know that  $\lambda_1(\Omega_1) = \lambda_2(\Omega_1) = \lambda_2(\Omega)$  (see Proposition 1.3.3 and (1.15)).

The vertical convexity relies on properties of Steiner symmetrization and continuous Steiner symmetrization introduced in section 2.2.3. We consider a point  $(x,y)=(\lambda_1(\Omega),\lambda_2(\Omega))$  in  $\mathcal{E}$ . We denote by B the ball of volume  $|\Omega|$ . We want to prove that the segment  $(x,(1-s)y+s\gamma x), s\in [0,1]$  is included in  $\mathcal{E}$ . If  $y\geq \lambda_2(B)$  the result is obvious using horizontal convexity, so we can assume  $y<\lambda_2(B)$ . Let us fix  $\alpha\in (\lambda_2(\Omega),\lambda_2(B))$ . We can construct a sequence of Steiner symmetrizations of  $\Omega$ , say  $\Omega_n, n\in \mathbb{N}$  such that  $\Omega_n$  converges to B. Moreover, we assume that we go from  $\Omega_n$  to  $\Omega_{n+1}$  thanks to a continuous Steiner symmetrization. We denote by  $\Omega_t, t\in \mathbb{R}_+$  this family of sets. According to Theorem 2.2.7,  $\lambda_1(\Omega_t)$  decreases

with t. Now, the sequence  $\lambda_2(\Omega_t)$  has possibly discontinuities, but converges to  $\lambda_2(B)$ , therefore there exists  $n_0$  such that  $\lambda_2(\Omega_{n_0}) \geq \alpha$ . We introduce

$$t^* = \sup\{t \in [0, n_0] : \lambda_2(\Omega_t) \le \alpha\}.$$

By Theorem 2.2.8 (lower semi-continuous on the left and upper semi-continuous on the right), we have  $\lambda_2(\Omega_{t^*}) = \alpha$ . We conclude by using one more time the horizontal convexity between the points  $(\lambda_1(\Omega_{t^*}), \alpha)$  and  $(\alpha, \alpha)$  (which belong to  $\mathcal{E}$ ); the point  $(\lambda_1(\Omega), \alpha)$  is on this segment, so belongs to  $\mathcal{E}$ .

As a consequence, they also proved:

**Theorem 6.4.3 (Bucur, Buttazzo, Figueiredo).** The set  $\mathcal{E}$  is closed in  $\mathbb{R}^2$ .

*Proof.* The idea of the proof is the following. Let us consider  $(x,y) \in \overline{\mathcal{E}}$  and a sequence  $\Omega_n$  such that  $\lambda_1(\Omega_n) \to x$  and  $\lambda_2(\Omega_n) \to y$ . Then, we can find a subsequence, still denoted by  $\Omega_n$ , and a set  $\Omega$  such that

$$\lambda_1(\Omega) \le \liminf \lambda_1(\Omega_n) = x$$
 and  $\lambda_2(\Omega) \le \liminf \lambda_2(\Omega_n) = y$ .

This is a consequence of the so-called compactness for the weak  $\gamma$ -convergence, see [45] and [44] for more details.

Let us assume first that  $y \geq \lambda_2(B)$  where B is the ball of volume c. Then, there is a homothetic ball B' of volume smaller than c such that  $y = \lambda_2(B')$ . The horizontal convexity of  $\mathcal{E}$  proved in Theorem 6.4.2 shows that the segment joining the points  $(\lambda_1(B'), \lambda_2(B'))$  and  $(\lambda_2(B'), \lambda_2(B'))$  is contained in  $\mathcal{E}$ . Therefore, (x, y) which belongs to this segment lies in  $\mathcal{E}$ .

Now, if  $y < \lambda_2(B)$ , from the vertical convexity, the segment joining the points  $(\lambda_1(\Omega), \lambda_2(\Omega))$  and  $(\lambda_1(\Omega), \gamma \lambda_1(\Omega))$  is contained in  $\mathcal{E}$  and the point  $(\lambda_1(\Omega), y)$  belongs to this segment. We conclude, as above, by using the horizontal convexity between  $(\lambda_1(\Omega), y)$  and (y, y).

On Figure 6.1 it seems clear that the set  $\mathcal E$  is convex. As of now, it has not been yet proved.

**Open problem 18.** Prove that the set  $\mathcal{E}$  is convex.

#### 6.4.2 Existence of minimizers

We have already mentioned in Theorem 2.4.5 that any function of the kind  $\Omega \mapsto \Phi(\lambda_1(\Omega), \lambda_2(\Omega))$  with  $\Phi$  non-decreasing with respect to each argument, admits a minimizer among (quasi)-open sets of given volume. Using the closedness of the set  $\mathcal{E}$ , we can immediately extend this result.

**Theorem 6.4.4 (Bucur, Buttazzo, Figueiredo).** Let  $\Phi: \overline{\mathbb{R}}^2 \to \mathbb{R}$  be a lower semi-continuous function, D a given set and c a given constant. Then the problem

$$\min\{\Phi(\lambda_1(\Omega), \lambda_2(\Omega)), \ \Omega \subset D, |\Omega| \le c\}$$

has always a solution.

A more precise statement could be: either an optimal domain exists or for the minimizing sequence  $\Omega_n$  we have  $\Phi(\lambda_1(\Omega_n), \lambda_2(\Omega_n)) \to -\infty$ . In this last case, we can choose as a minimizer the empty set. This is the case, for example for the gap function  $\Phi(\lambda_1, \lambda_2) = \lambda_1 - \lambda_2$ . Indeed, if we consider a sequence of domains

$$\Omega_{\epsilon} = B(0, \epsilon) \cup_{i=1}^{N_{\epsilon}} B(x_i, a_{\epsilon} \epsilon)$$

where  $a_{\epsilon} < 1$  and  $N_{\epsilon}$  are chosen such that  $|\Omega_{\epsilon}| = A$  and  $\lambda_i(\Omega_{\epsilon}) = \lambda_i(B(0, \epsilon))$  for i = 1, 2, then

$$\lambda_1(\Omega_{\epsilon}) - \lambda_2(\Omega_{\epsilon}) \to -\infty.$$

Nevertheless, if we add a convexity constraint, the problem becomes again interesting. We must quote that some bounds have been obtained for the gap, in the more general context of Schrödinger operators when  $\Omega$  is assumed to be convex, see e.g. [192], [214] and chapter 8. Therefore, it could be interesting to look at the following open problems.

**Open problem 19.** Prove existence of a convex domain which maximizes the gap  $\lambda_2(\Omega) - \lambda_1(\Omega)$  among convex domains of given volume. If possible, identify it.

The same question for the possible minimizer is not really interesting, neither in the class of open sets (since the "absolute" minimizer is the union of two disjoint identical sets for which  $\lambda_2(\Omega) - \lambda_1(\Omega) = 0$ ), nor in the class of convex sets. Indeed, in this case, the sequence of rectangles  $\Omega_L = (0, L) \times (0, 1/L)$  satisfies  $\lambda_2(\Omega_L) - \lambda_1(\Omega_L) = 3\pi^2/L^2 \to 0$  when  $L \to +\infty$ .

Since there is a conjecture stating that

$$\lambda_2(\Omega) - \lambda_1(\Omega) \ge \frac{3\pi^2}{d^2}$$

for any convex domain, where d is the diameter of  $\Omega$ , the interesting problem consists in minimizing the gap among open convex sets of given diameter. So, the problem could be

**Open problem 20.** Is there existence of a convex domain which minimizes the gap  $\lambda_2(\Omega) - \lambda_1(\Omega)$  among convex domains of given diameter d? If yes, identify it. If no, prove that the sequence of rectangles (in two dimension)  $\Omega_{\varepsilon} = (0, \sqrt{d^2 - \varepsilon^2}) \times (0, \varepsilon)$  is a minimizing sequence (indeed, we have  $\lambda_2(\Omega_{\varepsilon}) - \lambda_1(\Omega_{\varepsilon}) \to 3\pi^2/d^2$ ).

Among various combinations of the two first eigenvalues, we can also consider for example  $\lambda_1 + \lambda_2$ : what is the set which minimizes the sum of the two first eigenvalues? It is not the disk, since it does not satisfy the generalized optimality conditions (see e.g. [62], [53]). More generally, we can ask this question for any convex combination of the two first eigenvalues of the kind  $t\lambda_1 + (1-t)\lambda_2$ . This question has a simple geometric interpretation: the desired minimizer is indeed the first point of  $\mathcal{E}$  we reach when making a line of equation tx + (1-t)y = a approach the set  $\mathcal{E}$  (by increasing a). In particular, for t = 1 the solution is a ball while for t = 0 it is given by two balls. It is proved in [213] that the case t = 0 is the only one for which the optimal set is not connected.

**Open problem 21.** Let  $\Omega_t^*$ , 0 < t < 1 be a plane open set which minimizes  $t\lambda_1 + (1-t)\lambda_2$  among sets of prescribed area.

- (i) Prove that  $\Omega_t^*$  has always two axes of symmetry.
- (ii) Prove that  $\Omega_t^*$  is always simply connected.
- (iii) For what value of t is  $\Omega_t^*$  no longer convex?

# Chapter 7

# Other boundary conditions for the Laplacian

#### 7.1 Neumann boundary condition

#### 7.1.1 Introduction

The eigenvalues of the Laplacian with Neumann boundary conditions are also called the eigenvalues of the *free* membrane (in the case of Dirichlet boundary conditions, we speak about the *fixed* membrane). We recall that we denote it by  $0 = \mu_1(\Omega) \le \mu_2(\Omega) \le \mu_3(\Omega) \le \cdots$  (the first eigenvalue is zero, corresponding to constant functions). They solve (at least in a weak sense when  $\Omega$  is not regular)

$$\begin{cases}
-\Delta u_k = \mu_k(\Omega)u_k & \text{in } \Omega, \\
\frac{\partial u_k}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(7.1)

Minimizing the eigenvalues of the Laplacian with Neumann boundary conditions, with a volume constraint, is a trivial problem. Indeed, if we consider a long thin rectangle like  $(0, L) \times (0, l)$ , its *n*-th eigenvalue will be (for L large enough)  $\mu_n = \frac{(n-1)^2 \pi^2}{L^2}$ . Therefore, letting  $L \to +\infty$ , we see that

$$\inf\{\mu_n(\Omega), |\Omega| = A\} = 0.$$

Moreover, the infimum is attained for any open set which has at least n connected components. This shows that limiting the diameter of  $\Omega$  does not improve the interest of the question! Now, if we assume that the domains must be convex and with a given diameter, then the infimum is not zero, but it is not achieved! For example, L. Payne and H. Weinberger proved in [170] the following inequality for convex domains  $\Omega$  in  $\mathbb{R}^N$  with given diameter d:

$$\mu_2(\Omega) \ge \left(\frac{\pi}{d}\right)^2$$
.

This lower bound is optimal but not attained: any domain shrinking to a one-dimensional segment [0, d] has its second eigenvalue which converges to the lower bound.

If we want to get a really interesting problem for eigenvalues of the Laplacian with Neumann boundary conditions, we must consider the problem of the **maximization** instead of the minimization. Indeed in Proposition 7.1.4, we show that the supremum (among open sets of given volume included in some fixed box) is finite. For the second eigenvalue  $\mu_2$ , it has been conjectured by E.T. Kornhauser and I. Stakgold in [130] that the disk maximizes  $\mu_2$  among plane domains of given area. This result has been proved by P. Szegö in [196]. It has been generalized to any dimension by H. Weinberger in [207]. His proof is presented in section 7.1.2. The last subsection is devoted to some ratios and open problems.

One could also consider mixed boundary conditions: Dirichlet on one part and Neumann on the other part. In that direction, one can read the paper by S. Cox and P. Uhlig, [70] where the problem of minimizing or maximizing the first eigenvalue is studied.

#### 7.1.2 Maximization of the second Neumann eigenvalue

**Theorem 7.1.1 (Szegö, Weinberger).** The ball maximizes the second Neumann eigenvalue among (Lipschitz) open sets of given volume. Moreover, it is the only maximizer in this class.

*Proof.* Let  $\Omega$  be a given Lipschitz domain and  $\Omega^*$  the ball of same volume. Let us denote by R the radius of  $\Omega^*$  and  $\mu_2^*$  its second Neumann eigenvalue. It has multiplicity N and is associated to the N eigenfunctions

$$\frac{g(r)x_i}{r}, \quad i = 1, 2, \dots, N$$
 (7.2)

where g is given by the Bessel function  $J_{N/2}$ :

$$g(r) = J_{N/2}(j'_{N/2,1}r/R)$$
 with  $j'_{N/2,1}$  is the first zero of  $J'_{N/2}$ 

and  $\mu_2^* = \frac{j'_{N/2,1}^2}{R^2}$ . In particular, let us observe that R is the first zero of g'. We will also use the fact that g satisfies the ordinary differential equation

$$g''(r) + \frac{N-1}{r}g'(r) + \left(\mu_2^* - \frac{N-1}{r^2}\right)g(r) = 0.$$
 (7.3)

Let us define the continuous extension of q:

$$G(r) = \begin{cases} g(r) & r \le R, \\ g(R) & r > R. \end{cases}$$
 (7.4)

According to the min principle (1.37),  $\mu_2(\Omega)$  is given by

$$\mu_2(\Omega) = \inf_{v \in H^1(\Omega), v \neq 0, \int_{\Omega} v = 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} v(x)^2 dx} . \tag{7.5}$$

We introduce the functions  $f_i(x) = G(r)x_i/r$  and we use Lemma 6.2.2 (with  $u_1 = 1$ ) to claim that it is possible to fix the origin in such a way that  $\int_{\Omega} G(r) \frac{x_i}{r} dx = 0$  for i = 1, ..., N. In other words, with this choice of the origin, the functions  $f_i$  become admissible in the variational formulation (7.5). From

$$\frac{\partial f_i}{\partial x_j} = \frac{G'(r)x_jx_i}{r^2} - \frac{G(r)x_jx_i}{r^3} + \delta_{ij}\frac{G(r)}{r}$$

(where  $\delta_{ij} = 1$  if i = j, 0 else), we get for i = 1, ..., N:

$$\mu_2(\Omega) \le \frac{\int_{\Omega} [G'^2(r)x_i^2/r^2 + G^2(r)(1 - x_i^2/r^2)/r^2] dx}{\int_{\Omega} [G^2(r)x_i^2/r^2] dx}.$$

Multiplying each of these inequalities by the denominator on the right and summing the resulting inequalities yields

$$\mu_2(\Omega) \le \frac{\int_{\Omega} [G'^2(r) + (N-1)G^2(r)/r^2] dx}{\int_{\Omega} G^2(r) dx}.$$
 (7.6)

Let us now denote by  $\Omega_1$  the intersection of  $\Omega$  with the ball  $\Omega^*$  (of course, we assume that  $\Omega^*$  is centered at the origin which has been chosen above). Since R is the first zero of g', G(r) is non-decreasing for r > 0. Thus,

$$\int_{\Omega} G^2(r) dx = \int_{\Omega_1} G^2(r) dx + \int_{\Omega \setminus \Omega_1} G^2(r) dx \ge \int_{\Omega_1} G^2(r) dx + G^2(R) \int_{\Omega \setminus \Omega_1} dx$$

$$(7.7)$$

and

$$\int_{\Omega^*} G^2(r) \, dx = \int_{\Omega_1} G^2(r) \, dx + \int_{\Omega^* \backslash \Omega_1} G^2(r) \, dx \leq \int_{\Omega_1} G^2(r) \, dx + G^2(R) \int_{\Omega^* \backslash \Omega_1} dx \; . \tag{7.8}$$

Since  $\Omega$  and  $\Omega^*$  have same volume, (7.7) and (7.8) yield

$$\int_{\Omega} G^2(r) \, dx \ge \int_{\Omega^*} G^2(r) \, dx = \int_{\Omega^*} g^2(r) \, dx \,. \tag{7.9}$$

Differentiating the integrand in the numerator of (7.6), we have

$$\frac{d}{dr}\left[G'^{2}(r) + (N-1)\frac{G^{2}(r)}{r^{2}}\right] = 2G'G'' + 2(N-1)(rGG' - G^{2})/r^{3}.$$

For r > R this is clearly negative since G is constant there. For  $r \leq R$  we use the differential equation (7.3) to show that

$$\frac{d}{dr} \left[ G'^2(r) + (N-1) \frac{G^2(r)}{r^2} \right] = -2\mu^* G G' - (N-1)(rG'-G)^2 / r^3 < 0.$$

Thus, the integrand in the numerator is decreasing for r > 0 and we prove in the same way as we proved (7.9) that

$$\int_{\Omega} \left[ G'^{2}(r) + (N-1) \frac{G^{2}(r)}{r^{2}} \right] dx \le \int_{\Omega^{*}} \left[ g'^{2}(r) + (N-1) \frac{g^{2}(r)}{r^{2}} \right] dx . \tag{7.10}$$

The equality holds only if  $\Omega$  is a ball (except for a set of measure zero). Integration by parts yields

$$\int_{\Omega^*} \left[ {g'}^2(r) + (N-1) \frac{g^2(r)}{r^2} \right] dx = \mu_2^* \int_{\Omega^*} g^2 dx.$$

Inserting this together with (7.10) and (7.9) in (7.6) yields  $\mu_2(\Omega) \leq \mu_2^*$  which is the desired inequality. Moreover, we see that equality holds (if  $\Omega$  is Lipschitz) only when  $\Omega$  is a ball.

#### 7.1.3 Some other problems

#### Sums of reciprocals

In his proof of Theorem 7.1.1 in two dimensions, see [196], P. Szegö proved actually a stronger result:

**Theorem 7.1.2 (Szegö).** The disk minimizes the quantity  $\frac{1}{\mu_2} + \frac{1}{\mu_3}$  among simply connected open sets of given volume in  $\mathbb{R}^2$ .

His proof leans heavily upon conformal mapping and hence cannot be extended to higher dimension.

In the same spirit, let us quote some recent results obtained by B. Dittmar for the sum of reciprocal eigenvalues, see [77], [78], [79]. The last result, in particular, is similar to Pólya-Schiffer's Theorem 6.3.3.

**Theorem 7.1.3 (Dittmar).** Let C denote the class of plane open sets defined in (6.25). Then:

- The disk minimizes the quantity  $|\Omega|^2 \sum_{j=2}^{\infty} \frac{1}{\mu_j^2(\Omega)}$  in the class C.
- For any  $n \geq 2$ , the disk minimizes the quantity  $\frac{|\Omega|}{\pi} \sum_{j=2}^{n} \frac{1}{\mu_j(\Omega)}$  in the class C.

#### Some open problems

A general existence result, even in the case of domains included in some ball, does not yet exist. Nevertheless, we are able to prove that the supremum is finite:

**Proposition 7.1.4.** Let D be a regular domain in  $\mathbb{R}^N$  and c a positive constant. Let  $\mathcal{A}_c(D)$  be the class of Lipschitz open subsets of D with volume c. Then, for any k,

$$\sup_{\Omega \in \mathcal{A}_c(D)} \mu_k(\Omega) < +\infty.$$

*Proof.* (This proof has been kindly suggested by D. Bucur). Let  $g_1, g_2, \ldots, g_k$  be k (regular) functions defined on  $\partial D$  that we assume to be linearly independent. Let  $u_i, i = 1, \ldots, k$  be the harmonic functions in D whose trace on  $\partial D$  is  $g_i$ . By construction and properties of harmonic functions, the functions  $u_i, i = 1, \ldots, k$  are also linearly independent on any open subset of D. Therefore, for any  $\Omega \subset D$ , they span a subspace  $E_k$  of  $H^1(\Omega)$  of dimension k. Thanks to min-max formulae (1.33), we have

$$\mu_k(\Omega) \le \max_{v \in E_k, v \ne 0} R[v] = \max_{\substack{\alpha_1, \dots, \alpha_k \\ \alpha_1^2 + \dots + \alpha_k^2 = 1}} \frac{\int_{\Omega} |\alpha_1 \nabla u_1(x) + \dots + \alpha_k \nabla u_k(x)|^2 dx}{\int_{\Omega} (\alpha_1 u_1(x) + \dots + \alpha_k u_k(x))^2 dx}.$$

$$(7.11)$$

Therefore, (7.11) implies

$$\sup_{\Omega \in \mathcal{A}_{c}(D)} \mu_{k}(\Omega) \leq \sup_{\begin{subarray}{c} \Omega \in \mathcal{A}_{c}(D) \\ (\alpha_{1}, \dots, \alpha_{k}) \in \mathbb{R}^{k} \\ \alpha_{1}^{2} + \dots & \alpha_{k}^{2} = 1 \end{subarray}} \frac{\int_{\Omega} |\alpha_{1} \nabla u_{1}(x) + \dots + \alpha_{k} \nabla u_{k}(x)|^{2} dx}{\int_{\Omega} (\alpha_{1} u_{1}(x) + \dots + \alpha_{k} u_{k}(x))^{2} dx}.$$

$$(7.12)$$

Let  $(\Omega_n, \alpha_1^n, \dots, \alpha_k^n)$  be a maximizing sequence for the right-hand side of (7.12). We can extract a subsequence (still denoted with the same indices) such that

- $\chi_{\Omega_n} \rightharpoonup \gamma$  in  $L^{\infty}(D)$  weak-\*,
- $\alpha_i^n \to \alpha_i$  in  $\mathbb{R}$  for  $i = 1, \dots, k$ .

Then, passing to the limit in the right-hand side of (7.12), we get

$$\sup_{\Omega \in \mathcal{A}_c(D)} \mu_k(\Omega) \le \frac{\int_D \gamma |\alpha_1 \nabla u_1(x) + \dots + \alpha_k \nabla u_k(x)|^2 dx}{\int_D \gamma (\alpha_1 u_1(x) + \dots + \alpha_k u_k(x))^2 dx} . \tag{7.13}$$

Now, the right-hand side of (7.13) will be finite if and only if

$$\int_D \gamma (\alpha_1 u_1(x) + \dots + \alpha_k u_k(x))^2 dx \neq 0.$$

Assume that this integral is zero. Since  $|\{x \in D; \gamma(x) > 0\}| \ge c > 0$ , this would imply that the harmonic function  $\alpha_1 u_1(x) + \cdots + \alpha_k u_k(x)$  vanishes on a set of positive measure. Therefore it would vanish everywhere, contradicting the linear independence of the  $u_i$ 's.

About existence of a maximizer, some partial results have been obtained. For example, the existence of a convex domain which maximizes the n-th Neumann eigenvalue  $\mu_n$  (with given volume) has been proved in [69]. In two dimensions, a more general partial result is given in [44]:

**Theorem 7.1.5 (Bucur-Buttazzo).** Let  $D \subset \mathbb{R}^2$  be a fixed ball, c, l, M positive constants, and let us introduce

$$\mathcal{U}_{ad} = \{ \Omega \subset D, \Omega \text{ open}, |\Omega| = c, \sharp \Omega_n^c \leq p, |\partial \Omega| \leq M \}$$

(here  $\sharp \Omega_n^c$  denotes the number of connected components of  $\Omega_n^c$  and  $|\partial \Omega|$  the perimeter of  $\Omega$ ). Let  $F: \mathbb{R}^k \to \mathbb{R}$  be an upper semi-continuous function which is increasing in each variable. Then, the problem

$$\max_{\Omega \in \mathcal{U}_{ad}} F(\mu_1(\Omega), \mu_2(\Omega), \dots, \mu_k(\Omega))$$

has at least one solution.

To prove a general existence result, an idea could be to use Theorem 2.3.26 by studying carefully the behavior of maximizing sequences. This kind of work is still in progress. So, we are also led to the following open problem(s):

**Open problem 22.** Prove that there exists an open set (of given volume) which maximizes the n-th Neumann eigenvalue  $\mu_n$ , for  $n \geq 3$ . If possible, identify this maximizer.

A possible generalization of Szegö's Theorem (see also Theorem 7.3.3):

**Open problem 23.** In N dimensions, prove that

$$\sum_{i=2}^{N+1} \frac{1}{\mu_i(\Omega)}$$

is minimal for the ball among all domains with a given volume.

#### 7.2 Robin boundary condition

#### 7.2.1 Introduction

The eigenvalues of the Laplacian with Robin boundary conditions are called the eigenvalues of the *elastically supported* membrane. We will denote them by  $0 < \nu_1(\alpha, \Omega) \le \nu_2(\alpha, \Omega) \le \nu_3(\alpha, \Omega) \le \cdots$  where  $\alpha$  is a parameter,  $0 < \alpha < 1$ ; (the

cases  $\alpha = 0$  or  $\alpha = 1$  correspond to Neumann or Dirichlet boundary conditions) or possibly a function. The p.d.e. system is

$$\begin{cases}
-\Delta u_k = \nu_k(\alpha, \Omega) u_k & \text{in } \Omega, \\
\alpha u_k + (1 - \alpha) \frac{\partial u_k}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(7.14)

The first eigenvalue is characterized, as usual, by the variational formulation

$$\nu_1(\alpha, \Omega) = \inf_{v \in H^1(\Omega), v \neq 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx + \int_{\partial \Omega} \frac{\alpha}{1 - \alpha} v^2(\sigma) d\sigma}{\int_{\Omega} v(x)^2 dx} . \tag{7.15}$$

We are going to recover the Faber-Krahn inequality: the ball minimizes the first eigenvalue  $\nu_1(\alpha, \Omega)$ . This result has been proved first in two-dimensions by M.H. Bossel in her phD thesis, see [35]. Recently, it has been extended to any dimension by D. Daners in [74]. Previously, the conjecture appeared (and some partial results were obtained) in a paper of M. Bareket, [26]. We present Bossel's proof in section 7.2.2. The proof of Daners relies on the same principle but is more sophisticated. At last, in section 7.2.3, we look at the problem of minimizing  $\lambda_1(\Omega, \alpha)$  with respect to  $\alpha$  which is here a function allowed to vary. This last problem is connected to the question of optimal insulation of conductors.

#### 7.2.2 The Bossel-Daners Theorem

**Theorem 7.2.1 (Bossel-Daners).** The ball minimizes the first eigenvalue of the Robin problem among open sets with a given volume (for every value of  $\alpha \in (0,1]$ ).

*Proof.* The proof uses a new variational method, see [35], [74]. This method is inspired by that of extremal length. We follow the proof of M.H. Bossel valid in dimension 2. We recall that Daners' proof is similar.

Let  $\Omega$  be a bounded plane open set. Let us denote by  $\nu_1 = \nu_1(\alpha, \Omega)$  its first Robin eigenvalue and by u, u > 0 the first corresponding eigenfunction, normalized here by  $\max u = 1$ . We will denote by  $u_m \geq 0$  the minimum of u on  $\overline{\Omega}$ . Since  $\alpha \neq 0$ , we will rewrite the boundary condition in (7.14),

$$\frac{\partial u}{\partial n} + ku = 0 \quad \text{where } k = \frac{1 - \alpha}{\alpha} \,.$$
 (7.16)

For any value  $u_0$  such that  $u_m < u_0 < 1$ , let us denote by  $D_{u_0}$  the level set

$$D_{u_0} := \{ x \in \Omega; \ u(x) > u_0 \}$$

and by  $A_{u_0} = |D_{u_0}|$  its area. The boundary of  $D_{u_0}$  is made of two parts;  $\partial D_{u_0} = \gamma_{u_0} \cup \beta_{u_0}$  with  $\gamma_{u_0} = \Omega \cap \partial D_{u_0}$  is the level line  $\{u = u_0\}$  and  $\beta_{u_0} = \partial \Omega \cap \partial D_{u_0}$ .

A function  $\rho$  defined in  $\Omega$  will be called admissible if  $\rho$  is continuous, nonnegative on  $\Omega$  and satisfies

$$\limsup \rho \le k \quad \text{for every point on } \partial\Omega. \tag{7.17}$$

For such an admissible function, we define the quantity

$$H(u_0, \rho) := \frac{1}{A_{u_0}} \left\{ k |\beta_{u_0}| + \int_{\gamma_{u_0}} \rho \, ds - \int_{D_{u_0}} \rho^2 \, dx \right\}, \tag{7.18}$$

where  $|\beta_{u_0}|$  denotes the length of  $\beta_{u_0}$ . At last, we will denote  $\tilde{\rho} := |\nabla u|/u$  in  $\Omega$ . We now use the following lemma:

**Lemma 7.2.2.** For any admissible function  $\rho$ ,

$$\nu_1 \ge \inf_{u_0} H(u_0, \rho) \ .$$

Let us admit temporarily this lemma and finish the proof of the theorem. Let D be the disk (of radius R) of same area as  $\Omega$ . Its first eigenfunction is radially symmetric:  $v(r) = J_0(\omega_0 r)$  with  $\omega_0^2 = \nu_1(\alpha, D)$  characterized as the first zero of the transcendental equation in t:

$$\alpha t J_0'(tR) + (1 - \alpha)J_0(tR) = 0$$

To each set  $D_{u_0}$ , we associate the disk of same area  $D_{u_0}^*$  which is actually a level set of v, say  $D_{v_0}$ . The line  $\gamma_{v_0}$  is the level line  $v = v_0$ . Now, the function

$$\hat{\rho} = \hat{\rho}(r) := \frac{|\nabla v|}{v} = -\frac{v_r}{r} = \omega_0 \frac{J_1}{J_0}$$

is a non-decreasing function of r in the interval [0, R]. Therefore,  $\hat{\rho}(r)$  is less than its value for r = R, that is k, according to (7.16). In particular,  $\hat{\rho}$  is admissible in D. Then, we can construct an admissible function  $\rho$  in  $\Omega$ , which is equimeasurable to  $\hat{\rho}$  by setting  $\rho \setminus \gamma_{u_0} = \hat{\rho} \setminus \gamma_{v_0}$ . In particular, we have

$$\int_{D_{u_0}} \rho^2 dx = \int_{D_{v_0}} \hat{\rho}^2 dx.$$

Moreover, since the sets  $D_{u_0}$  and  $D_{v_0}$  have the same area, the (classical) isoperimetric inequality yields

$$|\partial D_{u_0}| = |\beta_{u_0}| + |\gamma_{u_0}| \ge |\gamma_{v_0}| = |\partial D_{v_0}|.$$

Therefore

$$k|\beta_{u_0}| + \int_{\gamma_{u_0}} \rho \, ds - \int_{D_{u_0}} \rho^2 \, dx \ge \int_{\gamma_{u_0}} \hat{\rho} \, ds - \int_{D_{u_0}} \hat{\rho}^2 \, dx \ .$$
 (7.19)

Now, since  $-\Delta v = \nu_1(\alpha, D)v$  in D, we have by integration by parts:

$$\nu_1(\alpha, D)|D_{v_0}| = -\int_{D_{v_0}} \frac{\Delta v}{v} dx = \int_{\gamma_{v_0}} \frac{|\nabla v|}{v} ds + \int_{D_{v_0}} \nabla v \cdot \nabla \left(\frac{1}{v}\right)$$

and we recover the right-hand side of (7.19). Finally, (7.19) together with Lemma 7.2.2 yields  $\nu_1 \geq \inf_{u_0} H(u_0, \rho) \geq \nu_1(\alpha, D)$  which is the desired result.

It remains to prove Lemma 7.2.2:

*Proof.* We recall that we have introduced  $\tilde{\rho} = |\nabla u|/u$  in  $\Omega$ . Let us set  $w = \rho - \tilde{\rho}$  (or  $\rho = \tilde{\rho} + w$ ). In particular,

$$k|\beta_{u_0}| + \int_{\gamma_{u_0}} \rho \, ds = k|\beta_{u_0}| + \int_{\gamma_{u_0}} \tilde{\rho} \, ds + \int_{\gamma_{u_0}} w \, ds$$
.

But, since  $k = -\frac{\partial u}{\partial n}/u$  on  $\beta_{u_0}$ ,

$$k|\beta_{u_0}| + \int_{\gamma_{u_0}} \tilde{\rho} \, ds = -\int_{\partial D_{u_0}} \frac{1}{u} \, \frac{\partial u}{\partial n} \, ds = \int_{D_{u_0}} \operatorname{div} \left( -\frac{\nabla u}{u} \right) dx = \nu_1 A_{u_0} + \int_{D_{u_0}} \frac{|\nabla u|^2}{u^2} \, dx.$$

In the same way,

$$\int_{D_{u_0}} \rho^2 \, dx = \int_{D_{u_0}} \tilde{\rho}^2 \, dx + 2 \int_{D_{u_0}} \frac{|\nabla u|}{u} \, w \, dx + \int_{D_{u_0}} w^2 \, dx \, .$$

Integrating on the level lines, the co-area formulae yields (together with the previous computations)

$$A_{u_0}H(u_0,\rho) = \nu_1 A_{u_0} + \int_{\gamma_{u_0}} w \, ds - 2 \int_{t=u_0}^1 \frac{dt}{t} \int_{\gamma_t} w \, ds - \int_{D_{u_0}} w^2 \, dx \,. \tag{7.20}$$

Let us assume, for a contradiction, that

$$A_{u_0}H(u_0,\rho) > \nu_1 A_{u_0}$$
 for every  $u_0 \in [u_m, 1]$ . (7.21)

Then, (7.20), (7.21) provide

$$\int_{\gamma_{u_0}} w \, ds - 2 \int_{t=u_0}^1 \frac{dt}{t} \int_{\gamma_t} w \, ds > \int_{D_{u_0}} w^2 \, dx \quad \forall u_0 \in [u_m, 1] . \tag{7.22}$$

Let us set

$$F(u_0) := \int_{t=u_0}^1 \frac{dt}{t} \int_{\gamma_t} w \, ds \, .$$

From (7.22), we get

$$-\frac{d}{du_0} \left[ u_0^2 F(u_0) \right] = u_0 \left[ \int_{\gamma_{u_0}} w \, ds - 2 \int_{t=u_0}^1 \frac{dt}{t} \int_{\gamma_t} w \, ds \right] > u_0 \int_{D_{u_0}} w^2 \, dx \ge 0.$$

Therefore,  $u_0 \mapsto u_0^2 F(u_0)$  is decreasing, and since it is 0 for  $u_0 = 1$ , it is positive for  $u_0 < 1$ . Consequently, there exists a constant K > 0 such that  $F(u_0) > K$  in a neighborhood of  $u_m^+$  and, by (7.22),  $\int_{\gamma_{u_0}} w \, ds$  has the same property. Let us show

that it leads to a contradiction. We know that  $u = u_m$  only on  $\partial \Omega$ , but on this boundary, according to (7.17):

$$\limsup \rho \leq k = \frac{1}{u} \, \left( -\frac{\partial u}{\partial n} \right) \leq \frac{|\nabla u|}{u} = \tilde{\rho} \,,$$

therefore, when  $u_0 \to u_m$ ,  $\limsup w = \limsup(\rho - \tilde{\rho}) \le 0$ , which is a contradiction.

**Open problem 24.** (see [169]) For what values of  $\alpha$  does the ratio  $\frac{\lambda_2}{\lambda_1}$  achieve its maximum for the disk?

#### 7.2.3 Optimal insulation of conductors

Let us consider a homogeneous conductor filling an open set  $\Omega$  which is assumed to be smooth, bounded and connected. We want to coat this conductor with a thin layer of insulator. To describe the insulated conductor, we consider a (small) positive number  $\varepsilon$  and a non-negative function h defined on the boundary  $\partial\Omega$  and we set (see Figure 7.1)

$$\Omega_{\varepsilon}(h) := \overline{\Omega} \cup \{x + \delta h(x)n(x); x \in \partial\Omega, 0 < \delta < \varepsilon\}.$$

If the conductivity of  $\Omega$  is 1, while that of  $\Omega_{\varepsilon}(h) \setminus \Omega$  is  $\varepsilon$ , then a good measure of

![](_page_116_Picture_10.jpeg)

Figure 7.1: A conductor  $\Omega$  insulated by a thin layer of variable width.

the rate at which  $\Omega_{\varepsilon}(h)$  dissipates heat is given by the first eigenvalue  $\lambda_1(\Omega, \varepsilon, h)$  of the following problem:

$$\begin{cases} -\operatorname{div}\left((\chi_{\Omega} + \varepsilon(1 - \chi_{\Omega}))\nabla u\right) = \lambda u & \text{in } \Omega_{\varepsilon}(h), \\ u = 0 & \text{on } \partial\Omega_{\varepsilon}(h) \end{cases}$$
 (7.23)

where  $\chi_{\Omega}$  denotes the characteristic function of  $\Omega$ . This problem was considered by A. Friedman in [92] where the author proves, in particular, that when  $\varepsilon$  goes to 0,  $\lambda_1(\Omega, \varepsilon, h)$  converges to the first eigenvalue  $\nu_1(h, \Omega)$  of the Robin problem

$$\begin{cases}
-\Delta u_1 = \nu_1(h, \Omega)u_1 & \text{in } \Omega, \\
u_1 + h\frac{\partial u_1}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(7.24)

We can consider that the total amount of insulator is given, which gives a constraint on  $\int_{\partial\Omega} h(\sigma) d\sigma$ . Then, the interesting question becomes: the conductor  $\Omega$  and the total amount of insulator c being given, find the thickness h of the insulator which minimizes  $\nu_1(h,\Omega)$  among all non-negative functions h such that  $\int_{\partial\Omega} h(\sigma) d\sigma = c$ . This question is studied in [63]. More precisely, the authors considered the minimization problem on the class

$$\mathcal{A}_{\delta_0,c} := \{ h \in L^1(\partial\Omega); 0 < \delta_0 \le h(x), \ \int_{\partial\Omega} h(\sigma) \, d\sigma = c \}.$$
 (7.25)

They first prove an existence result:

**Theorem 7.2.3 (Cox-Kawohl-Uhlig).** Let  $\Omega$  be a smooth, bounded and connected open set in  $\mathbb{R}^N$ , then there exists  $h^*$  minimizing the first eigenvalue  $\nu_1(h,\Omega)$  in the class  $\mathcal{A}_{\delta_0,c}$  defined in (7.25).

Proof. The proof follows the classical method of calculus of variations. From (7.15), we obviously have  $\nu_1(h,\Omega) \geq \lambda_1(\Omega)$  (the first eigenvalue of the Laplacian-Dirichlet). Let  $\nu^*$  denote the infimum of  $\nu_1(h,\Omega)$  and  $h_n$  be a minimizing sequence in  $\mathcal{A}_{\delta_0,c}$ . We also introduce  $u_n$ , the first associated eigenfunction normalized by  $\int_{\Omega} u_n^2(x) dx = 1$ . By the pointwise lower bound,  $h_n^{-1}$  is uniformly bounded in  $L^{\infty}(\partial\Omega)$  and then converges, up to a subsequence that we neglect to relabel, to some positive function g in  $L^{\infty}$  weak-\*. We set  $h = g^{-1}$ . Now, the variational characterization (7.15) shows that  $u_n$  is bounded in  $H^1(\Omega)$ . Therefore, there exists a function u in  $H^1(\Omega)$  such that  $u_n$  converges weakly to u in  $H^1(\Omega)$  and strongly in  $L^2(\Omega)$ . Moreover, the traces  $u_n \setminus_{\partial\Omega}$  converge to  $u \setminus_{\partial\Omega}$  strongly in  $L^2(\partial\Omega)$ . So, we can pass to the limit in the variational formulation of the p.d.e. (7.14):

$$\int_{\Omega} \nabla u_n \cdot \nabla v \, dx + \int_{\partial \Omega} h_n^{-1} u_n v \, d\sigma = \nu_1(h_n, \Omega) \int_{\Omega} u_n v \, dx$$

to get

$$\int_{\Omega} \nabla u \cdot \nabla v \, dx + \int_{\partial \Omega} h^{-1} u v \, d\sigma = \nu^* \int_{\Omega} u v \, dx,$$

which shows that  $\nu^*$  is an eigenvalue associated to h. Since u is positive, it is the first eigenvalue. It remains to check that h belongs to the class  $\mathcal{A}_{\delta_0,c}$ . The pointwise lower bound is obvious. For the integral constraint, we observe that the convexity of  $t \mapsto t^{-1}$  allows us to use Theorem 1.1 in [71] which implies

$$\int_{\partial\Omega} h \, d\sigma = \int_{\partial\Omega} g^{-1} \, d\sigma \le \liminf \int_{\partial\Omega} (h_n^{-1})^{-1} \, d\sigma = c.$$

But (7.15) implies clearly the monotonicity of the map  $h \mapsto \nu_1(h,\Omega)$ :  $h_1 \leq h_2 \Longrightarrow \nu_1(h_1,\Omega) \geq \nu_1(h_2,\Omega)$ . Since, it is obviously possible to find a function  $h^*$  in  $\mathcal{A}_{\delta_0,c}$  with  $h \leq h^*$ , the result is proved.

For a general  $\Omega$ , only a numerical approach seems possible to determine the optimal h. For that, the use of optimality conditions given in [63] can be useful. See also a numerical algorithm described in this paper. Nevertheless, there is a special (foreseeable) case where it is possible to give explicitly the minimizer:

**Theorem 7.2.4 (Cox-Kawohl-Uhlig).** If  $\Omega$  is a ball, the minimizer  $h^*$  is constant.

*Proof.* We begin with the following consequence of the Cauchy-Schwarz inequality:

$$\int_{\partial\Omega} h^{-1} u^{2}(\sigma) d\sigma \ge \left( \int_{\partial\Omega} u(\sigma) d\sigma \right)^{2} / \int_{\partial\Omega} h(\sigma) d\sigma \quad . \tag{7.26}$$

Therefore, (7.26) together with (7.15) yields the following lower bound for  $\nu_1$ :

$$\nu_1(h,\Omega) \ge \inf_{v \in H^1(\Omega), v \ne 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx + \frac{1}{c} \left( \int_{\partial \Omega} u(\sigma) d\sigma \right)^2}{\int_{\Omega} v(x)^2 dx} . \tag{7.27}$$

If we denote by  $\xi_1(h,\Omega)$  the value of the infimum in the right-hand side of (7.27), it is easy to see that is actually the first eigenvalue of the non-local problem

$$\begin{cases}
-\Delta v = \xi_1(h,\Omega)v & \text{in } \Omega, \\
c\frac{\partial v}{\partial n} + \int_{\partial\Omega} v(\sigma) d\sigma = 0 & \text{on } \partial\Omega.
\end{cases}$$
(7.28)

Note that the bound (7.27) is valid for any domain. Now, specializing to a ball  $B_a$  of radius a, we can look for all the eigenfunctions of problem (7.28). First of all, every non-radial Neumann eigenfunction of a ball satisfies  $\int_{\partial\Omega}v(\sigma)\,d\sigma=0$  (see (1.28)) and therefore is an eigenfunction for (7.28). Now, if v is an eigenfunction for (7.28) which is not a non-radial Neumann eigenfunction, it is orthogonal to each of these and, hence has to lie in the span of the radial Neumann eigenfunction. Consequently, v is radial. But it is easy to show that every radial eigenfunction is of the kind  $v(r;\zeta)=(\sqrt{\zeta}r)^{1-N/2}J_{N/2-1}(\sqrt{\zeta}r)$  where  $\zeta$  is a zero of the function  $z\mapsto v(a;z)|\partial B_a|+cdv/dr(a;z)$ . Finally, by comparing the first zero of the above function with the least eigenvalue corresponding to a non-radial Neumann eigenfunction, we see that the first eigenfunction of (7.28) is always radial. But, when h is constant, (7.24) and (7.28) have the same radial eigenfunctions. Therefore, when h is constant

$$\nu_1(h, B_a) = \xi_1(h, B_a). \tag{7.29}$$

The result follows immediately by comparison with (7.27).

#### 7.3 Stekloff eigenvalue problem

The Stekloff eigenvalue problem is the following:

$$\begin{cases} \Delta u = 0 & \text{in } \Omega, \\ \frac{\partial u}{\partial n} = pu & \text{on } \partial\Omega, \end{cases}$$
 (7.30)

where  $\Omega$  is a bounded Lipschitz open set. Exactly as in chapter 1, we can prove existence of a sequence of eigenvalues for problem (7.30) and min-max formulae. We will denote the eigenvalues by  $0 = p_1(\Omega) \le p_2(\Omega) \le p_3(\Omega) \le \cdots$  (the first eigenvalue is zero, corresponding to constant functions). For Stekloff eigenvalues, the min formulae (or variational characterization) reads:

$$p_k(\Omega) = \min \left\{ \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\partial \Omega} v(\sigma)^2 d\sigma} ; v \in H^1(\Omega), \int_{\partial \Omega} v u_j d\sigma = 0, j = 1, \dots, k - 1 \right\}.$$
(7.31)

**Remark 7.3.1.** If  $\Omega = B_R$  is a ball of radius R, an easy calculation gives

$$p_2(B_R) = p_3(B_R) = \dots = p_{N+1}(B_R) = \frac{1}{R}$$
 (7.32)

associated to the N eigenfunctions  $x_i, i = 1, 2, ..., N$ .

As in the Neumann case, it is the problem of **maximization** of the eigenvalues which is interesting here. Inspired by Szegö's proof for the free membrane problem in two dimensions (see Theorem 7.1.1), R. Weinstock in 1954 proved that the disk maximizes the second Stekloff eigenvalue, see [209]. It was only about fifty years later that the result was generalized by F. Brock to the N-dimensional case in [41]. We give his proof below.

Theorem 7.3.2 (Weinstock, Brock). The ball maximizes the second Stekloff eigenvalue among open sets of given volume.

Actually, Theorem 7.3.2 will appear as an immediate consequence of the following theorem (also due to Brock in [41]) together with (7.32).

**Theorem 7.3.3 (Brock).** The ball minimizes the following sum of inverse Stekloff eigenvalues:

$$\sum_{i=2}^{N+1} \frac{1}{p_i(\Omega)}$$

among open sets of given volume.

*Proof.* Let  $\Omega \subset \mathbb{R}^N$  be given and  $B_R = \Omega^*$  the ball of same volume. We can always choose the origin such that  $\int_{\partial \Omega} x_i d\sigma = 0$  for i = 1, ..., N. We recall the

variational characterization for sums of inverses of eigenvalues (see (1.39) and [19]; it is also an easy consequence of (7.31)):

$$\sum_{i=k+1}^{k+n} \frac{1}{p_i(\Omega)} = \max \sum_{i=k+1}^{k+n} \int_{\partial \Omega} v_i^2 d\sigma$$
 (7.33)

the above max being taken on the set  $\{v_i \in H^1(\Omega), \int_{\Omega} \nabla v_i \cdot \nabla v_j \, dx = \delta_{ij} \ i, j = k+1, \ldots, k+n, \int_{\Omega} \nabla v_i \cdot \nabla u_m \, dx = 0, \ m=1,2,\ldots,k\}$ . Choosing  $k=1,\ n=N$  and  $v_i(x) = |\Omega|^{-1/2} x_{i-1}, \ i=2,\ldots,N+1$  in (7.33), we get

$$\sum_{i=2}^{N+1} \frac{1}{p_i(\Omega)} \ge \frac{1}{|\Omega|} \int_{\partial \Omega} |x|^2 d\sigma.$$

We now use Lemma 2.1.5 and (2.6) with  $f(x) = x^2$ , which yields

$$\sum_{i=2}^{N+1} \frac{1}{p_i(\Omega)} \ge \frac{1}{|\Omega|} \int_{\partial B_R} |x|^2 d\sigma = \frac{R^2 |\partial B_R|}{|B_R|} = NR = \sum_{i=2}^{N+1} \frac{1}{p_i(B_R)},$$

the last equality coming from (7.32). This gives the desired result.

We must also mention that J. Hersch and L. Payne have already proved the previous Theorem 7.3.3 in two-dimensions in [108] and that they have also proved a sharper result, together with M.M. Schiffer in [109], namely:

**Theorem 7.3.4 (Hersch-Payne-Schiffer).** The disk maximizes the product  $p_2(\Omega)p_3(\Omega)$  among plane open sets of given area.

Proof. Let  $\Omega \subset \mathbb{R}^2$  be a bounded open Lipschitz set and let us denote by L the length of its boundary (and by s the curvilinear abscissa). Let us denote by  $\Omega^* = B_R$  the disk of same area as  $\Omega$ . Let u = u(s) be any function defined on  $\partial\Omega$ . We still denote by u = u(x,y) the harmonic function in  $\Omega$  with the boundary values u(s). Let us introduce  $\tilde{u}$  as its conjugate harmonic function, satisfying  $\int_{\partial\Omega} \tilde{u} \, d\sigma = 0$  (this fixes the choice of the additive constant for  $\tilde{u}$ ). Using Cauchy's relations for holomorphic functions, we get

$$\int_{\Omega} |\nabla u|^2 dx = \int_{\Omega} |\nabla \tilde{u}|^2 dx = \int_{\partial \Omega} \tilde{u} \frac{\partial \tilde{u}}{\partial n} = -\int_{\partial \Omega} \tilde{u} \frac{\partial u}{\partial s},$$

hence by Cauchy-Schwarz's inequality

$$\int_{\Omega} |\nabla u|^2 dx \int_{\Omega} |\nabla \tilde{u}|^2 dx \le \int_{\partial \Omega} \tilde{u}^2 d\sigma \int_{\partial \Omega} {u'}^2 d\sigma. \tag{7.34}$$

Let us denote by R[u] the Rayleigh quotient  $R[u] = \frac{\int_{\Omega} |\nabla u(x)|^2 dx}{\int_{\partial \Omega} u(\sigma)^2 d\sigma}$ . Then (7.34) yields

$$R[u]R[\tilde{u}] \le \frac{\int_{\partial\Omega} u'^2 d\sigma}{\int_{\partial\Omega} u^2 d\sigma} . \tag{7.35}$$

Let us remark that minimizing the right-hand side of (7.35) corresponds to looking for eigenvalues of a periodic string of length L. Now, since we have chosen  $\tilde{u}$  such that  $\int_{\partial\Omega} \tilde{u} \, d\sigma = 0$ , its Rayleigh quotient satisfies (according to (7.31) and the fact that the first eigenfunction is constant)  $R[\tilde{u}] \geq p_2(\Omega)$ . We now choose u to be a combination of cosine and sine functions like  $u(s) = c_1 \cos(\frac{2\pi x}{L}) + c_2 \sin(\frac{2\pi x}{L})$ . Obviously, u is orthogonal (for the  $L^2$  scalar product on  $\partial\Omega$ ) to constant functions. Moreover, it is always possible to choose  $c_1$  and  $c_2$  in such a way that u is orthogonal to  $u_2$ , the second Stekloff eigenfunction. Therefore, according to (7.31), we have  $R[u] \geq p_3(\Omega)$ . Now, this choice of u corresponds to the second eigenfunction of a periodic string of length L. In particular, for this function u, the right-hand side of (7.35) is  $(\frac{2\pi}{L})^2$ . Therefore

$$p_2(\Omega)p_3(\Omega) \le \left(\frac{2\pi}{L}\right)^2 \le \left(\frac{2\pi}{2\pi R}\right)^2,$$

the last inequality being simply the classical isoperimetric inequality. Since, according to (7.32),  $1/R^2 = p_2(\Omega^*)p_3(\Omega^*)$  the result follows.

**Remark 7.3.5.** In two dimensions, Theorem 7.3.4 implies Theorem 7.3.3. Indeed, it follows from the chain of inequalities and equalities:

$$\frac{p_2(\Omega)^{-1} + p_3(\Omega)^{-1}}{2} \ge \sqrt{p_2(\Omega)^{-1} p_3(\Omega)^{-1}} \ge \sqrt{p_2(\Omega^*)^{-1} p_3(\Omega^*)^{-1}}$$
$$\sqrt{p_2(\Omega^*)^{-1} p_3(\Omega^*)^{-1}} = R = \frac{p_2(\Omega^*)^{-1} + p_3(\Omega^*)^{-1}}{2}$$

(the first inequality is the classical inequality relying arithmetic and geometric mean).

**Open problem 25.** Study the maximization problem for other Stekloff eigenvalues.

**Open problem 26.** Prove that the N-ball maximizes the product  $\Pi_{k=2}^{N+1} p_k(\Omega)$  among open sets in  $\mathbb{R}^N$  with given volume.

**Remark 7.3.6.** For a related optimization problem with a Stekloff boundary condition on a part of the boundary and a Neumann one on the remaining part, we refer to a work by B.A. Troesch, [203]. In this paper, the author was interested in the so-called *sloshing problem*, see also section 10.2.3.

# Chapter 8

# Eigenvalues of Schrödinger operators

#### 8.1 Introduction

#### 8.1.1 Notation

A Schrödinger operator is an elliptic differential operator of the form  $L_V = -\hbar \Delta + V(x)$  where  $\hbar$  is the so-called Planck's constant and V(x) a potential which will be our main subject of interest in this chapter. Of course, mathematicians usually decide to scale the Planck's constant and we will do it also here. Another question would consist in examining the behavior of the spectrum when we let  $\hbar \to 0$ . This is the so-called semi-classic limit. Therefore, in this chapter, we are interested in the eigenvalues  $\lambda_k(\Omega, V)$  (or  $\lambda_k(V)$  since  $\Omega$  will be a fixed bounded Lipschitz domain in all this chapter and there is no possible confusion) of the system:

$$\begin{cases}
-\Delta u_k + V(x)u_k = \lambda_k(V)u_k & \text{in } \Omega, \\
u_k = 0 & \text{on } \partial\Omega.
\end{cases}$$
(8.1)

Remark 8.1.1. In quantum mechanics, these eigenvalues correspond to the energy levels, in atomic units, of a quantum particle in the potential energy V imagined as  $+\infty$  outside  $\Omega$ . The first eigenvalue  $\lambda_1(V)$  is generally referred as the ground state, the second  $\lambda_2(V)$  is the first excited state and the difference  $\lambda_2(V) - \lambda_1(V)$  is the fundamental gap. We could also replace the Laplacian by any elliptic operator of the second order of the kind  $\sum_{i,j=1}^{N} \frac{\partial}{\partial x_i} \left( a_{ij}(x) \frac{\partial u}{\partial x_j} \right)$  as in chapter 1. Most of the results that we are going to state in this chapter would remain valid.

The potentials V that we will consider will generally be non-negative, but we recall that it is an assumption which is not really indispensable, see Remark 1.1.3. In this chapter, we are interested in extremum problems involving the eigenvalues

of Schrödinger operators. We will not think in terms of  $\Omega$  but in terms of V here. Of course, it will generally be necessary to put some constraints on the potentials V since, otherwise, the problem would become ill-posed or would have possibly trivial solutions. This is the case, for example, if we want to minimize  $\lambda_1(V)$  among non-negative V. Since, according to (1.32),

$$\lambda_1(V) = \inf_{y \in H_0^1(\Omega), y \neq 0} \frac{\int_{\Omega} |\nabla y(x)|^2 + Vy^2(x) \, dx}{\int_{\Omega} y(x)^2 \, dx}$$
(8.2)

we obviously have  $\lambda_1(V) \geq \lambda_1(0) = \lambda_1(\Omega)$  and therefore, the minimum would be achieved by V = 0. In the sequel, we will consider constraints like

$$a \le V(x) \le b$$
 a.e. and/or  $\int_{\Omega} V^p(x) dx = c$  or  $\le c$ 

for some positive constants a, b, c, p.

In the sequel, we will denote by R[y;V] the Rayleigh quotient which appears in the right-hand side of (8.2). Let us begin with simple properties of the map  $V \mapsto \lambda_k(V)$ :

**Theorem 8.1.2.** The map  $V \mapsto \lambda_k(V)$  is continuous on  $L^{\infty}(\Omega)$  for the weak-\* topology and is concave.

*Proof.* The continuity result follows from Theorem 2.3.3 while the concavity comes from the fact that  $V \mapsto R[y; V]$  is affine and from the minimum formulae (1.34).

For the first eigenvalue, we can also state an upper-semi continuity result.

**Proposition 8.1.3.** Let V be a potential and assume that the first eigenfunction belongs to some  $L^p(\Omega)$  space. Assume that a sequence of potentials  $V_n$  converge weakly to V in  $L^q(\Omega)$ , with q = p/(p-2). Then

$$\lambda_1(V) \ge \limsup \lambda_1(V_n)$$
.

*Proof.* Let us denote by  $u_1$  the first eigenfunction associated to the potential V. Then, by assumption and definition of the weak-convergence  $\int_{\Omega} V_n u_1^2 dx \rightarrow \int_{\Omega} V_n u_1^2 dx$ . Therefore, thanks to (8.2)

$$\lambda_1(V) = R[u_1; V] = \lim_{n \to +\infty} R[u_1; V_n] \ge \limsup \lambda_1(V_n),$$

which is the desired result.

**Remark 8.1.4.** If  $\Omega$  is  $C^{1,1}$ , the first eigenfunction  $u_1$  belongs to  $C^1(\overline{\Omega})$  (see Remark 1.2.11) and therefore to all  $L^p$  spaces.

#### 8.1.2 A general existence result

Let  $0 \le a \le b$  be two given constants and let us introduce the two classes

$$\mathcal{V}_{a,b} := \{ V \in L^{\infty}(\Omega) ; a \le V(x) \le b \text{ a.e.} \}, \quad \mathcal{V}_{a,b,c} := \{ V \in \mathcal{V}_{a,b}, \int_{\Omega} V(x) \, dx = c \}.$$
(8.3)

Then, using compactness of these classes and continuity of the eigenvalues for the weak-\* topology, we have the following existence result.

**Theorem 8.1.5.** Let  $F : \mathbb{R}^k \to \mathbb{R}$  be a continuous function and  $\mathcal{V}$  one of the classes defined in (8.3). Then the problem

$$\min_{V \in \mathcal{V}} F(\lambda_1(V), \lambda_2(V), \dots, \lambda_k(V))$$
(8.4)

has a solution.

# 8.2 Maximization or minimization of the first eigenvalue

#### 8.2.1 Introduction

The problem of maximizing the first eigenvalue of a Schrödinger operator among potentials V of given  $L^p$  norm seems to have its origin in a question posed by A. Ramm in [176]. Then, several authors gave, independently, an answer to this query. Let us quote for example, M. Essen in [84], G. Talenti [201] for the one-dimensional case, E. Harrell and M. Ashbaugh in [98], [17] and H. Egnell in [81] for the N-dimensional case. Later Y. Egorov and S. Karaa in [82], [118] were also interested in the topic. We also refer to C. Bennewitz and E. Veling, see [206], [33] for the case of an unbounded interval. The problem of minimizing eigenvalues of Schrödinger operators on manifolds is considered for example in [85] or [89].

#### 8.2.2 The maximization problem

Let us begin with a general existence and uniqueness result (see [17]).

**Theorem 8.2.1.** Let  $\Omega$  be a  $C^{1,1}$  bounded open set, p > 1 and  $\mathcal{V}$  be a closed bounded convex subset of  $L^p(\Omega)$ . Then, there exists a unique  $V^*$  which maximizes  $\lambda_1(V)$  in the class  $\mathcal{V}$ .

*Proof.* Existence follows immediately from the fact that  $\mathcal{V}$  is compact for the weak convergence (it is closed because it is convex) and  $V \mapsto \lambda_1(V)$  is upper-semi continuous according to Proposition 8.1.3. We will denote by  $\lambda_1^*$  the maximum value.

For the uniqueness, let  $V_1$  and  $V_2$  be two maximizing potentials. According to Theorem 8.1.2, their average  $V_3 = (V_1 + V_2)/2$  is also a maximizer. Let us introduce

 $u_1, u_2$  and  $u_3$  as the corresponding first eigenfunctions. We observe that, unless  $u_1 = u_2 = u_3$ ,

$$\lambda_1^* = \lambda_1(V_3) = R[u_3; V_3] = \frac{1}{2} \left( R[u_3; V_1] + R[u_3; V_2] \right) > \frac{1}{2} \left( \lambda_1(V_1) + \lambda_1(V_2) \right) = \lambda_1^* \ .$$

Therefore,  $u_1 = u_2$ . But, from the equation (8.1) we get  $V_1u_1 = V_2u_2$  a.e. Since the first eigenfunctions are positive in  $\Omega$ , it follows that  $V_1 = V_2$  a.e., which gives uniqueness.

We now look at the more specific case where the class is the unit ball (we could obviously take any other centered ball with only minor changes):

$$V_p = \{ V \in L^p(\Omega), V(x) \ge 0, \int_{\Omega} V^p(x) \, dx \le 1 \}.$$

**Remark 8.2.2.** For the maximization problem, it is equivalent to work with the equality constraint  $\int_{\Omega} V^p(x) dx = 1$  or with the inequality  $\int_{\Omega} V^p(x) dx \leq 1$  because we have the obvious relation (due to (8.2))  $V_1 \leq V_2 \Rightarrow \lambda_1(V_1) \leq \lambda_1(V_2)$ .

The case p > 1

**Theorem 8.2.3.** Let us assume that p > 1 and let us denote by p' its conjugate  $(\frac{1}{p} + \frac{1}{p'} = 1)$ . Then the maximum of  $\lambda_1(V)$  in the class  $\mathcal{V}_p$  is achieved by the function  $V_0 := \|y_0^2\|_{p'}^{1-p'} y_0^{2p'/p}$  where  $y_0$  is the (unique) minimizer in  $H_0^1(\Omega) \cap L^{2p'}(\Omega)$  of

$$J_p(y) := \frac{\int_{\Omega} |\nabla y|^2 \, dx + \left( \int_{\Omega} |y|^{2p'} \, dx \right)^{1/p'}}{\int_{\Omega} y^2 \, dx} \, .$$

The function  $y_0$  can also be characterized as the first eigenfunction of the (non-linear) eigenvalue problem:

$$-\Delta y + \left(\int_{\Omega} |y|^{2p'} dx\right)^{1/p'-1} |y|^{2(p'-1)} y = \mu y \tag{8.5}$$

and  $\mu$ , the first eigenvalue of (8.5) is also the maximal value of  $\lambda_1(V)$  in  $\mathcal{V}_p$ . At last,  $V_0$  is the unique maximizer.

For the proof, we follow mainly the ideas of Talenti and Egnell, see [201], [81]. Another approach would consist in explicit optimality conditions, see e.g. [12].

*Proof.* Hölder's inequality yields, for any  $V \in \mathcal{V}_p$ , and  $y \in H_0^1(\Omega) \cap L^{2p'}(\Omega)$ :

$$\int_{\Omega} V(x)y^2(x) \, dx \leq \left(\int_{\Omega} V^p(x) \, dx\right)^{\frac{1}{p}} \left(\int_{\Omega} (y^2)^{p'}(x) \, dx\right)^{\frac{1}{p'}} \leq \left(\int_{\Omega} |y|^{2p'}(x) \, dx\right)^{\frac{1}{p'}}.$$

Therefore, we have for any  $V \in \mathcal{V}_p$  and  $y \in H_0^1(\Omega) \cap L^{2p'}(\Omega)$ ,

$$\frac{\int_{\Omega} |\nabla y(x)|^2 + Vy^2(x) \, dx}{\int_{\Omega} y(x)^2 \, dx} \le \frac{\int_{\Omega} |\nabla y(x)|^2 \, dx + \left(\int_{\Omega} |y|^{2p'}(x) \, dx\right)^{1/p'}}{\int_{\Omega} y(x)^2 \, dx} = J_p(y) \,. \tag{8.6}$$

Let us remark that if  $y \in H_0^1(\Omega) \setminus L^{2p'}(\Omega)$ , the right-hand side of (8.6) is  $+\infty$  and the inequality still holds. This last inequality implies

$$\lambda_1(V) \le \inf_{y \in H_0^1 \cap L^{2p'}} J_p(y).$$
 (8.7)

Now, it is well-known (by standard compactness arguments) that the above infimum, say  $\mu$ , is finite and attained by the solution  $y_0$  of the (nonlinear) eigenvalue problem

$$-\Delta y + \left(\int_{\Omega} |y|^{2p'} dx\right)^{1/p'-1} |y|^{2(p'-1)} y = \mu y.$$
 (8.8)

Moreover, it is also known that  $y_0$  is non-negative in  $(\Omega)$  (replace  $y_0$  by  $|y_0|$  in G(y)). Then taking the supremum in V in (8.7) one gets

$$M_p := \sup_{V \in \mathcal{V}_p} \lambda_1(V) \le J_p(y_0). \tag{8.9}$$

Now, let us define the potential  $V_0 = \|y_0^2\|_{p'}^{1-p'}y_0^{2(p'-1)}$ . First of all

$$\int_{\Omega} V_0^p(x) \, dx = \left( \int_{\Omega} y_0^{2p/(p-1)} \, dx \right)^{-1} \int_{\Omega} y_0^{2p/(p-1)} \, dx = 1$$

so  $V_0$  is an admissible potential. Moreover, equation (8.8) shows that  $y_0$  is an eigenfunction of the Schrödinger operator  $L_{V_0}$  associated to the eigenvalue  $\mu$ . But, since  $y_0$  is non-negative, it is the first eigenfunction and  $\lambda_1(V_0) = \mu = J_p(y_0)$ . This last equality together with (8.9) shows that the maximum  $M_p$  is achieved by  $V_0$ . At last, uniqueness has been proved in Theorem 8.2.1

#### The case p=1

In this case, the maximum is attained for a bang-bang function.

**Theorem 8.2.4.** The maximum of  $\lambda_1(V)$  in the class  $\mathcal{V}_1$  is achieved by the function  $V_0 := \frac{1}{|\omega|} \chi_{\omega}$  where  $\omega$  is the set  $\omega := \{x \in \Omega; y_0(x) = 1\}$  and  $y_0$  is the (unique up to the sign) minimizer in  $H_0^1(\Omega) \cap L^{\infty}(\Omega)$  of

$$J_1(y) := \frac{\int_{\Omega} |\nabla y|^2 \, dx + ||y||_{\infty}^2}{\int_{\Omega} y^2 \, dx}$$

normalized by  $||y_0||_{\infty} = 1$ . Moreover  $J_1(y_0)$  is also the maximal value of  $\lambda_1(V)$  and it is also equal to  $1/|\omega|$ .

*Proof.* We have immediately, for any  $V \in \mathcal{V}_1$  and  $y \in H_0^1(\Omega) \cap L^{\infty}(\Omega)$ 

$$\frac{\int_{\Omega} |\nabla y(x)|^2 + Vy^2(x) \, dx}{\int_{\Omega} y(x)^2 \, dx} \le \frac{\int_{\Omega} |\nabla y(x)|^2 \, dx + ||y||_{\infty}^2}{\int_{\Omega} y(x)^2 \, dx} = J_1(y). \tag{8.10}$$

Let us remark that if  $y \in H_0^1(\Omega) \setminus L^{\infty}(\Omega)$ , the right-hand side of (8.10) is  $+\infty$  and the inequality still holds. This last inequality implies, for all  $V \in \mathcal{V}_1$ :

$$\lambda_1(V) \le \inf_{y \in H_0^1 \cap L^{\infty}(\Omega)} J_1(y). \tag{8.11}$$

Classical calculus of variations now imply existence of a non-negative minimizer for  $J_1$ . If we normalize it with  $||y_0||_{\infty} = 1$ , this one solves the variational inequality

$$\begin{cases} y \in K := \{ y \in H_0^1(\Omega); \ ||y||_{\infty} \le 1 \} \text{ and } \forall z \in K, \\ \int_{\Omega} \nabla y. \nabla (z - y) \, dx - J_1(y_0) \int_{\Omega} y(z - y) \, dx \ge 0. \end{cases}$$
(8.12)

It is also possible (we refer to [81]) to prove that the solution of (8.12) is in  $H^2(\Omega) \cap C^{1,\alpha}(\overline{\Omega})$ , for some  $\alpha$ , as soon as  $\Omega$  is  $C^2$ . Now, let us define the coincidence set as  $\omega = \{x \in \Omega; y_0(x) = 1\}$ ,  $\omega$  is closed. Outside  $\omega$ , we can perform variations in every direction without changing the infinite norm (I mean that  $||y_0 + tz||_{\infty} = 1$  if z is compactly supported in  $\omega^c$  and t small enough). It means that, outside  $\omega$ ,  $y_0$  satisfies the usual differential equation

$$-\Delta y_0 = \mu y_0$$
 for  $x \notin \omega$ , where  $\mu = J_1(y_0)$ . (8.13)

Now, since  $y_0$  belongs to  $H^2_{loc}(\Omega)$ , its Laplacian vanishes a.e. on the set  $\omega$  where it is constant, see e.g. [104], chap 3. Therefore,  $y_0$  satisfies

$$-\Delta y_0 + \mu y_0 = \mu y_0 \quad \text{for } x \in \omega \,. \tag{8.14}$$

Finally, grouping (8.13) and (8.14), we get that  $y_0$  satisfies

$$-\Delta y_0 + \mu \chi_\omega y_0 = \mu y_0 \quad \text{in } \Omega. \tag{8.15}$$

Now, multiplying by  $y_0$  and integrating on  $\Omega$  yields

$$\int_{\Omega} |\nabla y_0|^2 \, dx + \mu \int_{\omega} y_0^2 \, dx = \mu \int_{\Omega} y_0^2 \, dx$$

or

$$\frac{\int_{\Omega} |\nabla y_0|^2 \, dx + \mu |\omega|}{\int_{\Omega} y_0^2 \, dx} = \mu = J_1(y_0) = \frac{\int_{\Omega} |\nabla y_0|^2 \, dx + 1}{\int_{\Omega} y_0^2 \, dx}$$

so we can deduce that  $\mu = 1/|\omega|$ . Finally, since  $y_0$  is non-negative, according to (8.15) it is the first eigenvalue of the potential  $V_0 = \chi_\omega/|\omega|$  and therefore  $\lambda_1(V_0) = J_1(y_0) = \min J_1$  which gives the desired result together with (8.10). At last, uniqueness can be proved exactly as in Theorem 8.2.1.

It can be interesting to get more information about the set  $\omega$ . For example, it is simple to prove: if  $\Omega$  is Steiner symmetric w.r.t. some hyperplane H (see Definition 2.2.2), then  $\omega$  is also symmetric w.r.t. H. Indeed, for any  $y \in H_0^1(\Omega) \cap L^{\infty}(\Omega)$ , if we introduce its Steiner symmetrization  $y^*$ , we have immediately, thanks to Theorem 2.2.4, that  $J_1(y^*) \leq J_1(y)$ . Therefore,  $y_0 = y_0^*$  and the result follows. We can also deduce such symmetry results from the uniqueness of the maximizer  $V_0$ .

In the one-dimensional case, we can be more precise (see [84], [201] [81]). If  $\Omega = (-L, L)$ , then

$$\lambda_1^* = \left(\frac{\pi}{2L}\right)^2 \left[\frac{1}{2} + \sqrt{\frac{1}{4} + \frac{2L}{\pi^2}}\right]^2$$

and  $\omega = [-\alpha, \alpha]$  with  $\alpha = (2\lambda_1^*)^{-1}$ . It comes easily from the differential equation satisfied by  $y_0$  and the compatibility conditions at  $-\alpha$  and  $\alpha$ . For results when  $\Omega = (0, +\infty)$  or  $\Omega = \mathbb{R}$ , or with other boundary conditions, we refer e.g. to [206], [33], [17].

#### 8.2.3 The minimization problem

For the minimization problem, we need to consider some supplementary constraints. Actually, even in the class  $\mathcal{V}_p = \{V \in L^p(\Omega); \int_{\Omega} V^p \, dx = 1\}$ , the minimum is not achieved. Indeed, since  $\lambda_k(V) \geq \lambda_k(\Omega)$  (thanks to (1.32)), according to Theorem 2.3.3, it suffices to find a sequence in  $\mathcal{V}_p$  which converges weakly-\* to 0 to see that the infimum of  $\lambda_k(V)$  in the class  $\mathcal{V}_p$  is  $\lambda_k(\Omega)$ . Now, it is easy to exhibit such a sequence. For example, this is the case for

- $V_n(X) = n^{1/p} \chi_{B_n}(X)$  where  $\chi_{B_n}$  is the characteristic function of a ball  $B_n$  of volume 1/n, in the case p > 1,
- any oscillating function like  $V_n(x) = \frac{\pi}{2} \sin(\pi x)$  in the case p = 1 (if  $\Omega = (0,1)$ ).

Even if we allow the potential V to become negative and we put a constraint on the  $L^1$  norm of its negative part, the minimum of  $\lambda_1(V)$  is not achieved in this class but in the wider class of Borel measures. Let us quote a result by G. Talenti in this direction, see [201]:

**Theorem 8.2.5 (Talenti).** Let  $\mathcal{B}_A$  denote the class of Borel measures on the interval I = (-L, L) whose negative part is of total mass A. Then the minimum of  $\lambda_1$  in this class is achieved by  $-A\delta$  where  $\delta$  is the Dirac measure at 0.

Obviously, in this case, equation (8.1) is to be understood in the sense of distributions.

Adding one more constraint allows us to get another positive result. Let us state it in one dimension:

**Theorem 8.2.6.** Let I = (-L, L) and  $\mathcal{V}_{A,B}$  be the class

$$\mathcal{V}_{A,B} = \{ V \in L^1(I); \ 0 \le V(t) \le B \ a.e., \int_{-L}^{L} V(t) \, dt = A \}$$
 (8.16)

(with B > A/2L). Then the minimum of  $\lambda_1(V)$  in the class  $\mathcal{V}_{A,B}$  is achieved by the potential

$$V^*(t) = \begin{cases} 0 & \frac{A}{2B} - L < t < L - \frac{A}{2B}, \\ B & -L < t < -L + \frac{A}{2B} \text{ and } L - \frac{A}{2B} < t < L. \end{cases}$$

The situation for the minimizer is therefore exactly in contrast with the one for the maximizer, see Figure 8.1.

Figure 8.1: The potential which maximizes  $\lambda_1(V)$  (left), which minimizes  $\lambda_1(V)$  (right).

*Proof.* First of all, we have existence of a minimizer according to Theorem 8.1.5. The set  $\mathcal{V}_{A,B}$  is convex and its extremal points are exactly B times a characteristic function (it is classical, see e.g. [104] chapter 7). Moreover, we know that  $V \mapsto \lambda_1(V)$  is concave, see Theorem 8.1.2. Therefore, the minimizer has to be an extremal point.

Another key point is that  $\lambda_1(V)$  decreases under increasing rearrangement. Indeed, let V be any potential, u its first eigenfunction, and denote by  $V_*$  and  $u_*$  their increasing rearrangement respectively. We have, thanks to properties of this rearrangement:

$$\lambda_1(V) = \frac{\int_I |\nabla u(x)|^2 + Vu^2(x) \, dx}{\int_I u(x)^2 \, dx} \ge \frac{\int_I |\nabla u_*(x)|^2 + V_*u_*^2(x) \, dx}{\int_I u_*(x)^2 \, dx} \ge \lambda_1(V_*) \, .$$

Since the increasing rearrangement of any characteristic function of a set of total length A/B is the characteristic function of the two intervals  $[-L, -L + A/2B] \cup [L - A/2B, L]$  the result follows.

Remark 8.2.7. In higher dimension, for a domain  $\Omega \subset \mathbb{R}^N$ , we have an analogous result. Actually, the beginning of the above proof is valid in any dimension. So there always exists a minimizer of  $\lambda_1(V)$  in the class  $\mathcal{V}_{A,B}$  (or its generalization) and this minimizer is B times a characteristic function  $\chi_{\omega}$ . Now, it seems probable that  $\omega$  is a neighborhood of  $\partial\Omega$ , but it remains to locate it more precisely. If  $\Omega$  is a ball, the same rearrangement argument shows that  $\omega$  is an annulus touching the boundary of the ball.

#### 8.3 Maximization or minimization of other eigenvalues

When looking at the maximization problem for a higher eigenvalue, say  $\lambda_k(V)$ , the results are less precise. In particular, one needs some compactness and then it gives some restrictions on the exponent p and the dimension N. Let us begin with an existence result with such assumptions as one can find in [17].

**Theorem 8.3.1.** Let  $\Omega$  be a bounded  $C^{1,1}$  domain in  $\mathbb{R}^N$ ,  $N \leq 3$  and  $p > \max(1, \frac{N}{2})$  be fixed. Let S be a closed, bounded convex set in  $L^p(\Omega)$ . Then,  $\lambda_k(V)$  attains its maximum (and its minimum) in S.

Proof. We will use the classical Sobolev-Rellich embedding theorem:  $H_0^1(\Omega) \hookrightarrow L^q(\Omega)$ , with  $q = +\infty$  if N = 1, for any  $q < +\infty$  if N = 2 and for any q < 2N/(N-2) if  $N \ge 3$  and the embedding is compact. From this theorem and Hölder inequality, we deduce that for all  $y \in H_0^1(\Omega)$  and  $V \in L^p(\Omega)$ , then  $\int_{\Omega} V y^2 dx$  is bounded from above by  $||V||_p |||y||_{2p'}^2$ , where p' is the conjugate exponent of p. Indeed, since p' = p/(p-1) and p > N/2, we have 2p' < 2N/(N-2) in dimension  $N \ge 2$  (the case N = 1 is obvious). Now using the min-max formulae, it is easy to see that  $\lambda_k(V)$  is uniformly bounded on S.

Let  $V_n$  be a maximizing sequence (the proof is the same for a minimizing sequence). Let us denote by  $\lambda_n = \lambda_k(V_n)$  and  $u_n$  the sequence of corresponding eigenvalues and eigenfunctions. As usual,  $u_n$  is normalized by  $||u_n||_2 = 1$ . Up to a subsequence, for which we keep the index n, we can assume that

$$V_n \rightharpoonup V_\infty \text{ in } L^p(\Omega), \quad u_n \rightharpoonup u_\infty \text{ in } L^2(\Omega), \quad \lambda_n \to \lambda_\infty.$$

Now, since  $\lambda_n = \int_{\Omega} |\nabla u_n(x)|^2 + V_n u_n^2(x) dx$  is bounded,  $u_n$  is also bounded in  $H_0^1(\Omega)$  and we can assume that  $u_n$  converges weakly to  $u_\infty$  in  $H_0^1(\Omega)$  and strongly in  $L^q(\Omega)$  for all the q allowed by Rellich's theorem. Actually, we can prove that the convergence is uniform. It is obviously true in dimension N=1. In dimension N=2, since  $V_n u_n$  is bounded in some  $L^q$  for q>1, we see, thanks to the equation that  $\Delta u_n$  is also bounded. Classical regularity results imply that  $u_n$  is bounded in  $W^{2,q}(\Omega)$  for some q and the result follows. At last, in dimension N=3, we get by Hölder inequality that  $V_n u_n$  is bounded in  $L^q$  for some  $q>\frac{6}{5}$  and we deduce that  $\Delta u_n$  is bounded in the same space, and therefore  $u_n$  is bounded in some  $W^{2,q}(\Omega)$ . We cannot conclude immediately but a classical "bootstrap" argument will provide the uniform convergence which is needed. This uniform convergence implies that  $V_n u_n - \lambda_n u_n$  converges weakly in  $L^p(\Omega)$  to  $V_\infty u_\infty - \lambda_\infty u_\infty$  and therefore, we can pass to the limit in the equation which shows that  $u_\infty$  is the first eigenfunction associated to the potential  $V_\infty$  and the eigenvalue  $\lambda_\infty$ . Then  $V_\infty$  is the desired maximizer.

We can also look at the more particular case  $S = \mathcal{V}_p = \{V; ||V||_p \leq 1\}$ . It is noticeable that we get the same result as in Theorem 8.2.3 but with a different method.

**Theorem 8.3.2.** Assume that assumptions of Theorem 8.3.1 are fulfilled. Assume moreover that  $\lambda_k$  is simple at the extremum. Let  $y_0$  be a solution of the nonlinear eigenvalue problem

$$\begin{cases}
-\Delta y_0 + |y_0|^{2/(p-1)} y_0 = \lambda_k^* y_0 & \text{in } \Omega, \\
y_0 = 0 & \text{on } \partial \Omega,
\end{cases}$$
(8.17)

where  $\lambda_k^*$  is the maximum value of  $\lambda_k$  on  $\mathcal{V}_p = \{V; \|V\|_p \leq 1\}$ . Then  $V_0 = |y_0|^{2/(p-1)}/\|y_0^{2/(p-1)}\|_p$  is a maximizer of  $\lambda_k$ .

Reciprocally, if  $V_0$  is a maximizer of  $\lambda_k$ , then the corresponding eigenfunction  $y_0$  satisfies

$$y_0^2 = V_0^{p-1} (8.18)$$

and therefore also (8.17).

*Proof.* First, let  $V_0$  be any maximizer as given by Theorem 8.3.1. Let us consider perturbations of the form

$$V_0 + \frac{\tau \chi_{T_1}(x)}{\int_{T_1} V_0^{p-1} dx} - \frac{\tau \chi_{T_2}(x)}{\int_{T_2} V_0^{p-1} dx}$$

where  $T_1$  and  $T_2$  are disjoints subsets of  $\Omega$ . At order 1, it still satisfies the constraint. Using perturbation theory like in Theorem 2.5.11, we get

$$0 = \frac{d\lambda_k}{d\tau} \setminus_{\tau=0} = \frac{\int_{T_1} y_0^2(x) \, dx}{\int_{T_1} V_0^{p-1} \, dx} - \frac{\int_{T_2} y_0^2(x) \, dx}{\int_{T_2} V_0^{p-1} \, dx}$$

for which we get  $y_0^2 = cV_0^{p-1}$ . Actually, it is a necessary condition of optimality. But, since  $y_0$  is defined up to a constant, we can obviously choose c = 1 which yields (8.18). Reciprocally, replacing  $V_0$  by  $|y_0|^{2/(p-1)}$  in the eigenvalue problem satisfied by  $y_0$  gives (8.17).

Note that we have no uniqueness of the maximizer in general. One can find such examples of non-uniqueness in [17] or in [84].

In one dimension, due to the compact embedding  $H_0^1(\Omega) \hookrightarrow L^{\infty}(\Omega)$ , the previous existence results remain valid for p=1. We let the reader adapt the proof. Moreover, we can be more precise by giving the explicit maximizer:

**Theorem 8.3.3 (Essen).** The maximum of  $\lambda_k(V)$  in the class  $\mathcal{V}_B := \{V \in L^1(0,1), V \geq 0, \int_0^1 V(t) dt = B\}$  is achieved by the periodic function  $V_k$  of period 1/k defined by

$$V_k(t) = \begin{cases} \Lambda_k & \eta_k < t < \frac{1}{k} - \eta_k, \\ 0 & 0 < t < \eta_k \text{ and } \frac{1}{k} - \eta_k < t < \frac{1}{k}, \end{cases}$$

where 
$$\Lambda_k = \frac{k^2}{4} \left( \pi + \sqrt{\pi^2 + \frac{4B}{k^2}} \right)^2$$
 is the maximum value of  $\lambda_k(V)$  and  $\eta_k = \pi$ 

$$\frac{\lambda}{2\sqrt{\Lambda_k}}$$

For the proof, we refer to [84]. Let us remark that V<sup>k</sup> restricted to each sub-interval <sup>J</sup> of periodicity of length 1/k is the maximizer of <sup>λ</sup>1(<sup>V</sup> ) on such an interval. Actually, it is the main ingredient in the proof of Theorem 8.3.3: using the fact that an eigenfunction associated to the k-th eigenvalue has exactly k nodal domains in 1 − D, roughly speaking we can look at the situation on each nodal domain separately.

**Remark 8.3.4.** Analogously, we can be interested in minimizing λk(V ) in the class VA,B defined in (8.16). Following the beginning of the proof of Theorem 8.2.6, we obtain existence of a minimizer and this one is B times a characteristic function. Then, using the same idea as above, we are able to prove that the minimizer is the periodic function W<sup>k</sup> such that on [0, 1/k], W<sup>k</sup> = B on [0, A/(2Bk)] ∪ [1/k − A/(2Bk)] and 0 elsewhere.

### **8.4 Maximization or minimization of the fundamental gap** λ<sup>2</sup> − λ<sup>1</sup>

#### **8.4.1 Introduction**

In quantum mechanics, the fundamental gap <sup>λ</sup>2 <sup>−</sup> <sup>λ</sup>1 and, in particular, its size if very important. If it is small enough, it can product the well-known tunnelling effect which has found many applications in modern science and technology. Therefore, the question consisting of minimizing the fundamental gap appears as very pertinent. Below, we will see that the smallest possible gaps are due to doublewell type tunnelling. The maximization problem is certainly less interesting from a physical point of view, but the mathematical question has sense and we will also consider it.

#### **8.4.2 Single-well potentials**

We first consider the one-dimensional case. Without loss of generality, we can choose I = [0, π] as the interval of work. The results that we are going to state remain valid for any other interval by re-scaling. Our first result is due to M. Horv´ath in [112]. He was inspired by a previous paper of M. Ashbaugh and R. Benguria [6] where they assumed a supplementary symmetry that M. Horv´ath succeeded to remove. It deals with single-well potentials:

**Definition 8.4.1.** A bounded function V defined on I = [0, π] is said to be singlewell if there exists c ∈ [0, π] such that V is non-increasing for x ≤ c and is non-decreasing for x ≥ c.

**Theorem 8.4.2 (Horv´ath).** The constant potentials minimize the gap <sup>λ</sup>2(<sup>V</sup> )−λ1(<sup>V</sup> ) in the class of single-well potentials with transition point c = π/2.

Actually, the assumption that the transition point is at the middle seems important since, in the case  $c \neq \pi/2$ , M. Horváth was able to exhibit a potential V with a smaller gap than a constant potential.

We begin with two lemmas. The first one is technical and we refer for the proof to [112].

**Lemma 8.4.3.** Let m > 0 and let us consider the function of one variable  $f(t) = \sqrt{t} \cot(\pi \sqrt{t}/2)$ . Then the first two real solutions of the equation f(t) = -f(t-m) satisfy  $t_2 - t_1 > 3$ .

**Lemma 8.4.4.** Let V be any potential and  $u_1$ ,  $u_2$  be the two normalized eigenfunctions associated to  $\lambda_1(V)$ ,  $\lambda_2(V)$ . Let  $x_0$  be the (unique) point where  $u_2$  vanishes. Then, there exist two points  $x_-, x_+$  such that  $0 \le x_- < x_0 < x_+ \le \pi$  satisfying

$$u_2^2 > u_1^2$$
 on  $(0, x_-) \cup (x_+, \pi)$ ,  $u_2^2 < u_1^2$  on  $(x_-, x_+)$  (8.19)

(and the two above sets are non-empty).

*Proof.* Without loss of generality we can assume  $u_1$  and  $u_2$  positive near 0. Let us begin to prove that the quotient  $u_2/u_1$  is decreasing on  $(0, \pi)$ . For  $0 < x < x_0$ , we have

$$\left(\frac{u_2(x)}{u_1(x)}\right)' = u_1(x)^{-2} [u_2'(x)u_1(x) - u_2(x)u_1'(x)]$$
$$= \frac{1}{u_1^2(x)} \int_0^x (\lambda_1 - \lambda_2)u_1(s)u_2(s) ds < 0.$$

In the same way, for  $x_0 < x < \pi$ , we have

$$\left(\frac{u_2(x)}{u_1(x)}\right)' = -\frac{1}{u_1^2(x)} \int_x^{\pi} (\lambda_1 - \lambda_2) u_1(s) u_2(s) \, ds < 0.$$

Therefore, the function  $u_2^2/u_1^2$  is decreasing from 0 to  $x_0$  and increasing from  $x_0$  to  $\pi$ . The result follows (we use the normalization to prove that each set is non-empty).

Proof of Theorem 8.4.2. For any M > 0, let us introduce the class

$$\mathcal{A}_M = \{V \in L^{\infty}(0,\pi), 0 \leq V \leq M, V \text{ is single-well with transition point at } \pi/2\}.$$

According to Theorem 8.1.5, we know the existence of a minimizer for the gap, say  $V^*$ , in the class  $\mathcal{A}_M$  (it is clear that this class is closed for the weak-\* convergence). We just have to show that  $V^*$  is constant for large M since any single-well potential is in a class  $\mathcal{A}_M$  for some M large enough. We go on denoting by  $u_1$  and  $u_2$  the two first eigenfunctions associated to  $V^*$ . Let us first consider the case:

A)  $x_- \le \pi/2 < x_+$  (the case  $x_+ = \pi/2$  is similar). Let us introduce the potential

$$V_1(x) = \begin{cases} V^*(x_-) & \text{on } (0, \pi/2), \\ V^*(x_+) & \text{on } (\pi/2, \pi), \end{cases}$$

 $V_1$  is in the class  $\mathcal{A}_M$  and

$$V_1 \le V^*$$
 on  $(0, x_-) \cup (x_+, \pi)$ ,  $V_1 \ge V^*$  on  $(x_-, x_+)$ . (8.20)

Let us define the potential  $V_t = tV_1 + (1-t)V^*$  (which also belongs to  $\mathcal{A}_M$ ). Thanks to formulae (2.54), the derivative of  $\lambda_2(V_t) - \lambda_1(V_t)$  at t = 0 is given by

$$\frac{d}{dt}|_{t=0}(\lambda_2(V_t) - \lambda_1(V_t)) = \int_0^{\pi} (V_1 - V^*)(u_2^2 - u_1^2) dx.$$

On the one hand, this derivative must be non-negative by optimality of  $V^*$ . On the other hand, the product under the integral is non-positive by (8.19) and (8.20). Therefore, the only possibility is that the integral is zero and  $V_1 = V^*$ . So, we have proved that in this case A), the minimizer  $V^*$  has to be a step function with the only possible jump at  $\pi/2$ .

B) Let us now consider the second case  $x_- > \pi/2$  (which is similar to  $x_+ < \pi/2$ ) and let us prove that it cannot happen. Introducing the new potential  $V_2$  defined as

$$V_2(x) = \begin{cases} V^*(\pi/2) & \text{on } (0, x_-), \\ V^*(x_+) & \text{on } (x_-, \pi), \end{cases}$$

we can prove exactly as above that  $V_2 = V^*$ . Now, let us consider another candidate:

$$V_3(x) = \begin{cases} 0 & \text{on } (0, x_-), \\ M & \text{on } (x_-, \pi). \end{cases}$$

From the normalization and the definition of  $x_{-}$ , we get

$$\int_0^{x_-} (u_2^2 - u_1^2) \, dx > 0, \qquad \int_{x_-}^{\pi} (u_2^2 - u_1^2) \, dx < 0.$$
 (8.21)

This implies, by optimality of  $V^*$ , that (we also use the fact that  $V^* = V_2$ )

$$0 \le (\lambda_2 - \lambda_1)' = \int_0^{\pi} (V_3 - V^*)(u_2^2 - u_1^2) dx$$
  
=  $-V^*(\frac{\pi}{2}) \int_0^{x_-} (u_2^2 - u_1^2) dx + (M - V^*(x_+) \int_{x_-}^{\pi} (u_2^2 - u_1^2) dx$ .

Now, using (8.21), we see that the previous inequality is only possible if  $V^*(\frac{\pi}{2}) = 0$  and  $M = V^*(x_+)$  (i.e.  $V^* = V_3$ ). But for such a potential, the second eigenfunction is given by

$$u_2(x) = \begin{cases} c \sin(\sqrt{\lambda_2}x) & \text{on } (0, x_-), \\ d \sin(\sqrt{\lambda_2} - M(\pi - x)) & \text{on } (x_-, \pi). \end{cases}$$

We know that the only zero  $x_0$  of  $u_2$  is between  $x_-$  and  $x_+$ , therefore, according to the case B, we would have here  $u_2 \neq 0$  on  $(0, \pi/2)$ . This is only possible when  $\sqrt{\lambda_2}\pi/2 < \pi$  i.e. when  $\lambda_2 < 4$ . Now, for  $M \geq 4$  we would have  $\lambda_2 - M < 0$ 

and then  $0 = u_2(x_0) = d \sin(\sqrt{\lambda_2 - M}(\pi - x_0))$  is impossible. Therefore, the only possible case (for  $M \ge 4$ ) is A) for which the optimal potential  $V^*$  is given by

$$V^*(x) = \begin{cases} 0 & \text{on} \quad (0, \pi/2), \\ m & \text{on} \quad (\pi/2, \pi), \end{cases} \quad \text{or} \quad V^*(x) = \begin{cases} m & \text{on} \quad (0, \pi/2), \\ 0 & \text{on} \quad (\pi/2, \pi) \end{cases}$$

for some  $m \geq 0$  (the proof we did above to get  $V^* = V_3$  is still valid in case A). Since the two potentials have the same eigenvalues, it is enough to consider the first one. In this case, an eigenfunction corresponding to an eigenvalue  $\lambda$  is given by

$$u(x) = \begin{cases} c \sin(\sqrt{\lambda}x) & \text{on } (0, \pi/2), \\ d \sin(\sqrt{\lambda} - m(\pi - x)) & \text{on } (\pi/2, \pi). \end{cases}$$

The constants c and d have to be chosen such that u is  $C^1$  at  $\pi/2$ . This can be done if and only if the quotients u'/u are the same at  $\pi/2$  from both sides, i.e. when

$$\sqrt{\lambda}\cot(\sqrt{\lambda}\pi/2) = -\sqrt{\lambda - m}\cot(\sqrt{\lambda - m}\pi/2). \tag{8.22}$$

So, the eigenvalues are the real solutions of the equation (8.22). But Lemma 8.4.3 states that, in this case,  $\lambda_2 - \lambda_1 > 3$  if  $m \neq 0$ . Hence, since 3 is precisely the value of  $\lambda_2 - \lambda_1$  for a constant potential, the result is proved.

Remark 8.4.5. By changing V to -V, we prove: The constant potentials maximize the gap  $\lambda_2(V) - \lambda_1(V)$  in the class of single-barrier potentials with transition point at  $\pi/2$  (a single-barrier potential is a function which is first non-decreasing, then non-increasing).

**Remark 8.4.6.** For an extension of Theorem 8.4.2 to double-well potentials (i.e. functions V which are non-increasing, then non-decreasing, then non-increasing), we refer to [1].

Let us quote, without proof, another result due to R. Lavine in [138]. The idea of the proof is similar. Let us remark that the following theorem is also valid in the case of a Neumann boundary condition.

**Theorem 8.4.7 (Lavine).** The constant potentials minimize the gap  $\lambda_2(V) - \lambda_1(V)$  in the class of convex potentials.

Let us now give, in the same spirit, a result in the case of a ball. It is due to M. Ashbaugh and R. Benguria. The proof is similar to the previous one, although more technical because of spherical coordinates. We will not give it here, we refer to [6].

**Theorem 8.4.8.** Let B be a ball of radius R and V be the class of radial potentials V which satisfy  $[rV(r)]'' \ge 0$  for 0 < r < R. Then, the constant potentials minimize the gap  $\lambda_2(V) - \lambda_1(V)$  in the class V.

Remark 8.4.9. Theorem 8.4.8 applies in particular to all smooth convex spherically symmetric potentials since such a potential is obviously non-decreasing on lines starting at the origin and satisfies  $V''(r) \ge 0$ . Thus  $[rV(r)]'' = rV''(r) + 2v'(r) \ge 0$  and the assumption is satisfied.

#### 8.4.3 Minimization or maximization with an $L^{\infty}$ constraint

In this section, we work with potentials V in the class

$$\mathcal{V}_{\infty,M} = \{ V \in L^{\infty}(\Omega); 0 \le V \le M \text{ a.e.} \}.$$

We recall that we have proved in Theorem 8.1.5 existence of a minimizer or a maximizer for the gap  $\Gamma(V) := \lambda_2(V) - \lambda_1(V)$  in this class. We are now going to characterize such extrema. The following theorems are due to M. Ashbaugh, E. Harrell and R. Svirsky in [18]. For similar results in the class  $\mathcal{V}_{\infty,p,M,H} = \{V \in L^{\infty}(\Omega); 0 \leq V \leq M \text{ a.e.}; \int_{\Omega} V^p(x) dx = H\}$ , we refer to [119].

**Theorem 8.4.10.** Let  $V_*$  be a minimizer of the gap  $\Gamma(V)$  in the class  $\mathcal{V}_{\infty,M}$ . Then:

- (i)  $\lambda_2(V_*)$  is non-degenerate.
- (ii) There exists a connected subset  $\omega \subset \Omega$  such that  $V_* = M\chi_{\omega}$ .
- (iii) Moreover  $\omega=\{x\in\Omega;u_1^*(x)\geq |u_2^*(x)|\}$  where  $u_1^*$  and  $u_2^*$  are the two first eigenfunctions.

We have a similar result for the maximizer:

**Theorem 8.4.11.** Let  $V^*$  be a maximizer of the gap  $\Gamma(V)$  in the class  $\mathcal{V}_{\infty,M}$ . Then either  $\lambda_2(V^*)$  is degenerate or

- (i) There exists a subset  $\omega \subset \Omega$  such that  $V^* = M\chi_{\omega}$  and  $\omega^c$  is connected.
- (ii) Moreover  $Int(\omega)=\{x\in\Omega;u_1^*(x)<|u_2^*(x)|\}$  where  $u_1^*$  and  $u_2^*$  are the two first eigenfunctions.

We give the proof only for the minimizer. We follow [18]. The case of the maximizer is very similar. For an analogous analysis, but for the problem consisting in minimizing the energy instead of the gap, we refer to [102].

*Proof.* Let us begin with (ii) of Theorem 8.4.10. We consider the set  $T = \{x \in \Omega; 0 < V_*(x) < M\}$  and we want to prove that it has zero measure. We write it  $T = \bigcup_{k=1}^{\infty} T_k$  where

$$T_k = \{x \in \Omega; \frac{1}{k} < V_*(x) < M - \frac{1}{k}\}.$$

Let  $x_0$  be any point in  $T_k$  and  $G_{k,j} \subset T_k$  be any measurable sequence of subsets containing  $x_0$ . Then, perturbations of the form  $P = \chi_{G_{k,j}}$  are admissible (in the

sense that V + tP is still in  $\mathcal{V}_{\infty,M}$  for all sufficiently small t). We recall that, according to Theorem 2.5.11, if  $\lambda_k(V)$  is non-degenerate, then

$$\frac{d\lambda_k(V+tP)}{dt} = \int_{\Omega} Pu_k^2 dx \text{ at } t = 0.$$
 (8.23)

In particular, for the gap functional, we have

$$0 = \frac{d\Gamma(V + tP)}{dt} = \int_{\Omega} P(u_2^2 - u_1^2) \, dx = \int_{G_{b,\delta}} (u_2^2 - u_1^2) \, dx \text{ at } t = 0.$$

Dividing by  $|G_{k,j}|$  and letting  $G_{k,j}$  shrink to  $x_0$  as  $j \to \infty$ , we find by the Lebesgue Density Theorem that

$$u_2^2(x) = u_1^2(x)$$
 on  $T_k$  and therefore on  $T$ . (8.24)

We are going to prove that this can not occur on a set of positive measure. If it would be the case, let us assume that  $T_+ := \{x \in T; u_2(x) > 0\}$  is of positive measure (if it was the set  $T_- := \{x \in T; u_2(x) < 0\}$  we could multiply  $u_2$  by -1). Since  $u_1$  does not vanish in  $\Omega$  and  $u_1^2 = u_2^2$  on T, this implies that  $T = T_+ \cup T_-$ . On  $T_+$ , we have  $u_1 - u_2 = 0$  and since  $(u_1 - u_2) \in H^2(\Omega)$ , the Laplacian  $\Delta(u_1 - u_2)$  vanishes almost everywhere on  $T_+$  (see e.g. [104] chap 3). Substituting into the eigenvalue equation (8.1), we find that  $(\lambda_2 - \lambda_1)u_1 = 0$  a.e. on  $T_+$  which is impossible since  $u_1 > 0$  on  $\Omega$ . Therefore, if we denote by  $\omega$  the support of  $V_*$  (in the sense of distributions), we necessarily have  $V_* = M\chi_{\omega}$ .

We can now prove that  $u_1(x) \ge |u_2(x)|$  on  $\omega$  using the same perturbation argument. Indeed, if  $x \in \omega$  and  $G_j$  is a sequence of sets shrinking to x, we get the result from

$$0 \ge \frac{d\Gamma(V + tP)}{dt} = \int_{G_j} (u_2^2 - u_1^2) dx$$
 at  $t = 0$ 

and the Lebesgue Density Theorem. A similar argument shows that  $u_1^2(x) \leq u_2^2(x)$  on  $\omega^c$ . Moreover, the inequality on  $\omega^c$  must be strict; indeed suppose that  $u_1^2(x_0) = u_2^2(x_0)$  for some  $x_0$  in  $\omega^c$ . Consider a ball B centered at  $x_0$  and contained in  $\omega^c$ . Without loss of generality, we can assume that  $u_2 > 0$  in B. Now, we know that the minimizing potentials  $V_*$  satisfy  $V_* = 0$  on B. The function  $w = u_1 - u_2$  is non-positive on B and attains its maximum at  $x_0$ . But it is subharmonic (since  $\Delta w = \lambda_2 u_2 - \lambda_1 u_1 > 0$  on B) and therefore  $u_2 = u_1$  on B by the maximum principle. This, however, is impossible as for (8.24).

Let us now prove the non-degeneracy of  $\lambda_2(V_*)$ . If  $\lambda_2(V_*)$  were m-fold degenerate, then for any particular admissible perturbation P(x), the cluster of eigenvalues  $\lambda_{2,k}(t)$  into which  $\lambda_2(V_*)$  would split could be arranged to be analytic in t at t=0, and likewise for the associated orthonormalized eigenfunctions  $\{u_{2,k}\}$  depending on P (see Remark 2.5.14). Let us denote  $\Gamma_k = \lambda_{2,k}(V_* + tP) - \lambda_1(V_* + tP)$ . If

$$\frac{d\Gamma_k}{dt} < 0$$
 at  $t = 0$ 

for any k, then we would have  $\Gamma(t_0) \leq \Gamma_k(t_0) < \Gamma(0)$  for some  $t_0 > 0$ , which is impossible since  $\Gamma(0)$  is a minimum. In the same way, we get a contradiction by assuming

$$\frac{d\Gamma_k}{dt} > 0$$
 at  $t = 0$ 

for any k (take now  $t_0 < 0$ ). Therefore

$$\frac{d\Gamma_k}{dt} = \int_{\Omega} P(u_{2,k}^2 - u_1^2) \, dx = 0 \quad \text{at } t = 0$$
 (8.25)

for all admissible perturbations P and for all k. Suppose now u is any normalized vector in the eigenspace for  $\lambda_2$ , so that

$$u = \sum_{j=1}^{m} c_j u_{2,j}, \quad \sum_{j=1}^{m} |c_j|^2 = 1.$$

Because of (2.56),

$$\int_{\Omega} P(x)(u^2 - u_1^2) dx = \int_{\Omega} P(x) \left( \sum_{j=1}^{m} |c_j|^2 u_{2,j}^2 - u_1^2 \right) dx = \sum_{j=1}^{m} |c_j|^2 \int_{\Omega} P(x) (u_{2,j}^2 - u_1^2) dx$$
(8.26)

this last quantity being 0 by (8.25). We may now argue as in the previous steps of the proof, restricting first to sets  $T_k$  to conclude that, for some set  $\omega$ ,  $V_*(x) = M\chi_{\omega}(x)$  a.e. We prove exactly in the same way that,

on 
$$\omega$$
,  $u_1^2(x) \ge u^2(x)$  and on  $\omega^c$ ,  $u^2(x) \ge u_1^2(x)$  (8.27)

as before, and that this holds for each and every normalized vector u in the eigenspace of  $\lambda_2$ .

Suppose, finally, that there are two orthonormal vectors  $u_{2,a}$  and  $u_{2,b}$  in the second eigenspace and that  $x_0$  is a point on  $\partial \omega \cap \Omega$ ; so that we may take  $u_{2,a}(x_0) = u_{2,b}(x_0) = u_1(x_0) \neq 0$ . Then the vector

$$u(x) = \frac{1}{\sqrt{2}} (u_{2,a}(x) - u_{2,b}(x)) = 0$$
 when  $x = x_0$ .

It would follow that  $u_1^2(x) > u^2(x)$  in a neighborhood of  $x_0$ , so in particular on some part of  $\omega^c$ , contradicting (8.27).

It remains to prove that  $\omega$  is connected. Clearly the nodal set  $\{x \in \Omega; u_2(x) = 0\}$  belongs to a connected component of  $\omega$ . The nodal set separates  $\Omega$  into two nodal domains (see section 1.3.3), so suppose that  $\omega$  were to contain two disjoint regions  $\Omega_1$  and  $\Omega_2$ , one of which, say  $\Omega_1$ , includes the nodal set, while  $\Omega_2$  lies within one of the nodal domains. Without loss of generality, we assume that  $u_2 > 0$  on  $\Omega_2$ . We have established that  $u_1 > u_2$  a.e. on  $\Omega_2$  and  $u_1 = u_2$  on  $\partial \Omega_2$ . We use  $u(x) := u_1(x) - u_2(x)$  as a trial function for the Dirichlet eigenvalue problem for

 $-\Delta + V_*$  restricted to  $\Omega_2$ , noting that the lowest eigenvalue of this restriction lies above  $\lambda_2(V_*)$  because  $\Omega_2$  lies within a nodal domain, see Proposition 1.3.3. Hence the min-max variational characterization of eigenvalues would imply that

$$\begin{split} \lambda_2 \int_{\Omega_2} (u_1 - u_2)^2 \, dx &\leq \int_{\Omega_2} (u_1 - u_2) (-\Delta + V_*) (u_1 - u_2) \, dx \\ &= \int_{\Omega_2} (u_1 - u_2) (\lambda_1 u_1 - \lambda_2 u_2) \, dx \\ &= \lambda_1 \int_{\Omega_2} (u_1 - u_2)^2 \, dx - (\lambda_2 - \lambda_1) \int_{\Omega_2} (u_1 - u_2) u_2 \, dx \\ &< \lambda_1 \int_{\Omega_2} (u_1 - u_2)^2 \, dx \,, \end{split}$$

which would contradict  $\lambda_2 > \lambda_1$ .

#### The one-dimensional case

In one dimension, we can be more precise. Let us assume, without loss of generality, that  $\Omega = (-L, L)$ .

**Theorem 8.4.12.** Let  $\Omega = (-L, L)$  and  $V_*$  be a minimizer of the fundamental gap in the class  $\mathcal{V}_{\infty,M}$ . Then,  $V_* = M\chi_{\omega}$  where  $\omega = [-a, a]$  for some  $a \in (0, L)$ .

Actually, we already know that  $V_* = M\chi_{\omega}$  with  $\omega = \{x; |u_2(x)| \leq u_1(x)\}$  which is connected. So, what is left to show is that  $\omega$  is symmetric. We cannot use a rearrangement technique here, nevertheless it can be shown thanks to the Sturm comparison and separation theorem. We suggest that the interested reader consult [18].

#### 8.4.4 Minimization or maximization with an $L^p$ constraint

We also give some results taken from [18]. Let p be a real number such that N/2 when the dimension <math>N satisfies  $N \ge 2$  and  $\mathcal{V}_{p,M}$  denotes the class

$$\mathcal{V}_{p,M} = \{ V \in L^p(\Omega); ||V||_p \le M \}.$$

In dimension 1, we will consider all possible values p > 1 (we could also consider the set of bounded real Borel measures of total mass M).

**Theorem 8.4.13.** There exists a minimizer  $V_*$  of the gap  $\Gamma(V)$  in the class  $\mathcal{V}_{p,M}$ . Moreover, it satisfies

- (i)  $\lambda_2(V_*)$  is non-degenerate.
- (ii)  $supp(V_*) = \overline{\Omega}$  and  $V_*$  and its eigenfunctions  $u_1, u_2$  are related by

$$u_2^2 - u_1^2 = -c|V_*|^{p-2}V_* (8.28)$$

for some constant c > 0. In particular,  $|u_2| \le u_1$  on  $\Omega_+ := supp(V_{*+})$  where  $V_{*+} = \max(V_*, 0)$  and  $|u_2| \ge u_1$  on  $\Omega_- := supp(V_{*-})$ .

(iii)  $\Omega_{+}$  is connected.

(iv)  $V_*$  is continuous and

$$\int_{\Omega} |V_*|^{p-2} V_* \, dx = 0 \,. \tag{8.29}$$

We have a similar result for the maximizer:

**Theorem 8.4.14.** There exists a maximizer  $V^*$  of the gap  $\Gamma(V)$  in the class  $\mathcal{V}_{p,M}$ . Moreover, it satisfies: either  $\lambda_2(V^*)$  is degenerate or

(i)  $supp(V^*) = \overline{\Omega}$  and  $V^*$  and its eigenfunctions  $u_1, u_2$  are related by

$$u_2^2 - u_1^2 = +c|V^*|^{p-2}V^* (8.30)$$

for some constant c > 0. In particular,  $|u_2| \ge u_1$  on  $\Omega_+ := supp(V^*_+)$  and  $|u_2| \le u_1$  on  $\Omega_- := supp(V^*_-)$ .

- (ii)  $\Omega_{+}^{c}$  is connected.
- (iii)  $V^*$  is continuous and

$$\int_{\Omega} |V^*|^{p-2} V^* \, dx = 0. \tag{8.31}$$

Sketch of the proof for the minimizer: (for more details we refer to [18]). The existence of a minimizer follows exactly as in the proof of Theorem 8.3.1. The proof of the non-degeneracy of  $\lambda_2$  is similar to the one given in the case  $p=+\infty$ . It is clear that the minimizing potential satisfies  $||V_*||_p=M$ , as otherwise every bounded perturbation would be admissible, and we would find as in the first step of the proof of Theorem 8.4.10 that  $u_1^2(x)=u_2^2(x)$  throughout  $\Omega$ , which is impossible. In addition, any bounded, measurable perturbation such that

$$supp(P) \subset \Omega \setminus supp(V_*)$$

is admissible, so the same argument implies that  $supp(V_*) = \overline{\Omega}$ . The characterization of the minimizer follows the main lines of the proof of Theorem 8.3.2. The regularity result for  $V_*$  comes directly from the relation (8.28) and the continuity of eigenfunctions. Moreover, relation (8.29) results from integrating (8.28) and using the fact that  $u_1$  and  $u_2$  are normalized. At last connectedness of  $\Omega_+$  is proved as in the  $L^{\infty}$  case.

#### The one-dimensional case

In one dimension, for  $\Omega=(-L,L)$ , it follows from the general result and a careful study that  $\Omega_+:=supp(V_{*+})=[a,b]$  for some  $-L\leq a< b\leq L$ . It can be proved, more precisely, that  $V_*$  is a double-well potential, see [18]: there exists a,b:-L< a< b< L such that  $supp(V_{*-})=[0-L,a]\cup[b,L]$  and  $supp(V_{*+})=[a,b]$ . In other words,  $V_*$  consists of two wells separated by a barrier. For a maximizer, we get the reverse:  $V^*$  consists of two barriers with a single well in between.

Concerning the symmetry of the supports and of the minimizer (i.e. -a = b), it is actually known for p = 2 but unknown for other values of p.

**Open problem 27.** Prove that the minimizer  $V_*$  and the maximizer  $V^*$  are even functions when  $\Omega = (-L, L)$  for any value of p > 1.

#### 8.5 Maximization of ratios

#### 8.5.1 Introduction

The main results in this section are due to M. Ashbaugh and R. Benguria. We are going to study ratios of the kind  $\lambda_n(V)/\lambda_1(V)$ . In subsection 8.5.2, we consider the one-dimensional case and we prove that  $\lambda_2(V)/\lambda_1(V)$  always achieves its maximum for V=0, see [5]. This result has been then generalized by the same authors for any n in [8]. We give their result in subsection 8.5.3 where we also consider more general ratios like  $\lambda_n(V)/\lambda_m(V)$ . At last, in Remark 8.5.7, we consider again the ratio  $\lambda_2(V)/\lambda_1(V)$  in dimension N and we re-introduce the domain  $\Omega$  to show (in the spirit of Theorem 6.2.1) that the maximum of such a ratio is achieved when  $\Omega$  is a ball and V=0. This result appeared in [10].

In all this section, we keep the same notation, the potentials V are assumed to be non-negative and in  $L^1(\Omega)$ .

#### **8.5.2** Maximization of $\lambda_2(V)/\lambda_1(V)$ in one dimension

**Theorem 8.5.1 (Ashbaugh-Benguria).** Let  $\Omega = (a, b)$  be a finite interval. Then the ratio  $\lambda_2(V)/\lambda_1(V)$  achieves its maximum among non-negative potentials in  $L^1(\Omega)$  for V = 0. Moreover, it is the unique maximizer.

This theorem is contained in the next one, but its proof is much simpler and interesting in itself. This is the reason why we give it here.

*Proof.* Let  $u_1$  be the first eigenfunction associated to V. By the commutation formula, see [76], the operators  $L = -\frac{d^2}{dx^2} + V(x)$  and  $\widetilde{L} = -\frac{d^2}{dx^2} + V(x) - 2\left(u_1'/u_1\right)'$  have the same spectrum except for  $\lambda_1$ . Thus we can obtain an upper bound for  $\lambda_2$  by using the min-max formula for  $\widetilde{L}$ . Taking  $u_1^2$  as our trial function, we find

$$\widetilde{L}u_1^2 = -4u_1u_1" + Vu_1^2 = 4\lambda_1u_1^2 - 3Vu_1^2$$
.

Hence

$$\lambda_2 \le 4\lambda_1 - 3 \frac{\int_a^b V u_1^4 \, dx}{\int_a^b u_1^4 \, dx} \,. \tag{8.32}$$

This shows that  $\lambda_2/\lambda_1 \leq 4$  for non-negative potentials, with equality if and only if V = 0 (because  $u_1$  is continuous and positive on [a, b]).

**Remark 8.5.2.** The choice of  $u_1^2$  as the trial function is motivated by the fact that  $u_1^2$  is the first eigenfunction of the operator  $\widetilde{L}$  when V=0.

**Remark 8.5.3.** A classical limiting argument allows us to extend the previous result to an unbounded interval if the potential V is assumed to satisfy  $V(x) \to +\infty$  when  $|x| \to \infty$ , see [5].

#### **8.5.3** Maximization of $\lambda_n(V)/\lambda_1(V)$ in one dimension

**Theorem 8.5.4 (Ashbaugh-Benguria).** Let  $\Omega = (a, b)$  be a finite interval. Then, for any integer n, the ratio  $\lambda_n(V)/\lambda_1(V)$  achieves its maximum among non-negative potentials in  $L^1(\Omega)$  for V = 0. Moreover, it is the unique maximizer.

*Proof.* Without loss of generality, we can assume that  $\Omega=(0,1)$  (use translation and rescaling). Of course, since the eigenvalues when V=0 are given by  $\lambda_k=k^2\pi^2$ , it suffices to prove that  $\lambda_n(V)/\lambda_1(V)\leq n^2$  with equality if and only if V=0. The proof will be by contradiction. Fix n and suppose that  $\lambda_n(V)/\lambda_1(V)>n^2$  for some potential  $V\in L^1(\Omega)$ .

The idea consists in introducing modified Prüfer variables r(x) and  $\theta(x)$  defined by the two relations

$$u(x) = r(x) \sin\left(\sqrt{\lambda}\theta(x)\right),$$
  

$$u'(x) = \sqrt{\lambda}r(x) \cos\left(\sqrt{\lambda}\theta(x)\right)$$
(8.33)

where u denotes one of the two eigenfunctions  $u_1$  or  $u_n$  and  $\lambda$  the corresponding eigenvalue. Of course, if we want the second relation in (8.33) to hold, it implies that

$$r'(x)\sin\left(\sqrt{\lambda}\theta(x)\right) = \sqrt{\lambda}r(x)\cos\left(\sqrt{\lambda}\theta(x)\right)\left(1 - \theta'(x)\right).$$
 (8.34)

Now, we have

$$u''(x) = \sqrt{\lambda}r'(x)\cos\left(\sqrt{\lambda}\theta(x)\right) - \lambda r(x)\theta'(x)\sin\left(\sqrt{\lambda}\theta(x)\right). \tag{8.35}$$

Therefore, replacing r'(x) by its value given in (8.34) and using (8.35) in the eigenvalue equation  $-u'' + V(x)u = \lambda u$  shows that  $\theta$  is a solution of the differential equation

$$\theta'(x) = 1 - \frac{V(x)}{\lambda} \sin^2\left(\sqrt{\lambda}\theta(x)\right) := F(x, \theta, \lambda).$$
 (8.36)

We define  $\theta_1$  (respectively  $\theta_n$ ) to be the solution of equation (8.36) with  $\lambda = \lambda_1$  (respectively,  $\lambda = \lambda_n$ ) and satisfying the initial condition  $\theta(0) = 0$ . Since these solutions correspond to the eigenfunctions  $u_1$  and  $u_n$  which satisfy Dirichlet boundary conditions and which have respectively 1 and n nodal domains, it follows (the function r(x) does not vanish) that

$$\theta_1(1) = \frac{\pi}{\sqrt{\lambda_1}}$$
 and  $\theta_n(1) = \frac{n\pi}{\sqrt{\lambda_n}}$ . (8.37)

Let us now prove that the inequality

$$F(x, \theta, \lambda_n) \ge F(x, \theta, \lambda_1) \tag{8.38}$$

holds for  $(x, \theta) \in [0, 1] \times [0, n\pi/\sqrt{\lambda_n}]$ . Indeed, if (8.38) is true, it will imply by a simple comparison argument for ordinary differential equations that  $\theta_n(t) \geq \theta_1(t)$  for all  $t \in [0, 1]$  and this would contradict the fact that  $\theta_n(1) = n\pi/\sqrt{\lambda_n} < \pi/\sqrt{\lambda_1} = \theta_1(1)$ .

So, it remains to prove (8.38). This is obviously equivalent to showing

$$\frac{\sin^2\left(\sqrt{\lambda_n}\theta\right)}{\lambda_n} \le \frac{\sin^2\left(\sqrt{\lambda_1}\theta\right)}{\lambda_1}$$

for  $\theta \in [0, n\pi/\sqrt{\lambda_n}]$  or, more simply, to showing

$$|\sin ns| \le \sqrt{\frac{\lambda_n}{\lambda_1}} \sin[ns/\sqrt{\lambda_n/\lambda_1}]$$

for  $s \in [0, \pi]$ . This last inequality is easily seen to hold by a straightforward analysis.

Finally, to see that  $\lambda_n/\lambda_1 = n^2$  implies that V must be identically zero we observe that we can make the same comparison argument in this case and the inequality  $\theta_n(x) \geq \theta_1(x)$  will become strict as soon as V is positive on a set of positive measure. But then we would obtain  $\lambda_n/\lambda_1 < n^2$  by evaluating the inequality at x = 1 which gives a contradiction.

**Theorem 8.5.5 (Ashbaugh-Benguria).** Let  $\Omega = (a,b)$  be a finite interval. Let n and m be two integers such that m divides n. Then the ratio  $\lambda_n(V)/\lambda_m(V)$  achieves its maximum among non-negative potentials in  $L^1(\Omega)$  for V = 0. Moreover, it is the unique maximizer (when  $m \neq n$ ).

Proof. Let us write n=km. Then, the proof is by induction on m. For m=1, this is the content of Theorem 8.5.4 above. Suppose now that  $\lambda_{km}/\lambda_m \leq k^2$  (with equality for V=0) and that we want to prove the corresponding inequality for m+1. We let  $u_{m+1}$  and  $u_{k(m+1)}$  denote the eigenfunctions for  $\lambda_{m+1}$  and  $\lambda_{k(m+1)}$  respectively, and let  $w_1$  be the first zero of  $u_{m+1}$  in the interior of the interval  $\Omega$  and  $w_2$  the k-th zero of  $u_{k(m+1)}$ . In addition, with  $u(x,\lambda)$  defined as the solution to

$$-u'' + V(x)u = \lambda u, \quad x \in \Omega$$

obeying the initial conditions

$$u(a,\lambda) = 0, \ u'(a,\lambda) = 1,$$

we let  $z_l(\lambda)$  denote the l-th zero of  $u(x, \lambda)$  in (a, b). It is a well-known fact (see, for example [58], vol.1 pp. 454-455) that  $z_l(\lambda)$ , for each l = 1, 2, 3, ..., is a monotone decreasing function of  $\lambda$  for  $\lambda \geq \lambda_1$ . Clearly,  $w_1 = z_1(\lambda_{m+1})$  and  $w_2 = z_k(\lambda_{k(m+1)})$ .

Now suppose, for a contradiction, that V is a potential for which we have  $\lambda_{k(m+1)}/\lambda_{m+1} > k^2$ . We consider the consequences in the two cases  $w_2 \geq w_1$  and  $w_2 < w_1$  in turn. If  $w_2 \geq w_1$  we consider the Dirichlet problem on the interval  $[a, w_1]$ . Let its eigenvalues be denoted  $\widetilde{\lambda}_n$  (n = 1, 2, 3, ...). Since  $z_k(\lambda)$  is decreasing in  $\lambda$  and  $z_k(\lambda_{k(m+1)}) = w_2 \geq w_1$  it follows that  $\widetilde{\lambda}_k \geq \lambda_{k(m+1)}$ . Because  $\widetilde{\lambda}_1 = \lambda_{m+1}$  this yields a problem for which  $\widetilde{\lambda}_k/\widetilde{\lambda}_1 \geq \lambda_{k(m+1)}/\lambda_{m+1} > k^2$  contradicting Theorem 8.5.4.

If  $w_2 < w_1$  we consider the other part of the interval,  $[w_1, b]$ . By considerations similar to those given above (working now from the initial point x = b) we can arrive at a problem where  $\widetilde{\lambda}_{km}/\widetilde{\lambda}_m > k^2$  contradicting our induction hypothesis.

So the inequality  $\lambda_{km}/\lambda_m \leq k^2$  is proved. To characterize the cases where equality occurs one can make the analogous arguments to those above (now assuming  $\lambda_{km}/\lambda_m = k^2$ ) to see inductively that V = 0 a.e. both in  $[a, w_1]$  and  $[w_1, b]$  and hence in  $\Omega = [a, b]$ . This induction uses the uniqueness of the maximizer given in Theorem 8.5.4.

**Remark 8.5.6.** When m does not divide n, the following inequality holds:

$$\frac{\lambda_n(V)}{\lambda_m(V)} < \left[\frac{n}{m}\right]^2$$

where [x] denotes the least integer greater than or equal to x (the ceiling function), see [8]. The right-hand side is nevertheless the supremum of  $\lambda_n(V)/\lambda_m(V)$ . Therefore, it is a situation where there are no maximizers. The previous inequality has been recently improved for single-well potentials by M. Horváth and M. Kiss in [113]. Namely, they prove that one can replace [n/m] by n/m in the right-hand side. For similar results with Neumann boundary conditions, we refer to [115].

Remark 8.5.7. Let us consider that the domain  $\Omega$  is also allowed to vary, so we denote the eigenvalues of the Schrödinger operator  $\lambda_k(\Omega, V)$ . We are interested in the problem of maximizing the ratio  $\lambda_2(\Omega, V)/\lambda_1(\Omega, V)$ . The following result is proved in [10] in a similar way as Theorem 6.2.1. We will not give the proof here.

**Theorem 8.5.8 (Ashbaugh-Benguria).** Let  $\lambda_k(\Omega, V)$  denote the k-th eigenvalue of the Schrödinger operator  $-\Delta + V(x)$  on the bounded domain  $\Omega \subset \mathbb{R}^N$ . Then the ratio  $\lambda_2(\Omega, V)/\lambda_1(\Omega, V)$  achieves its maximum when  $\Omega$  is a ball and V = 0.

# Chapter 9

# Non-homogeneous strings and membranes

#### 9.1 Introduction

In this chapter, we will study non-homogeneous membranes. So, we consider a membrane  $\Omega$  (in one dimension  $\Omega$  is called a string) which will not vary in this chapter. The non-homogeneity of this membrane is characterized by a density function  $\rho(x)$ . Of course, we will assume  $\rho$  to be non-negative (see below). Then, the eigenvalues  $\lambda_k(\rho)$  and eigenfunctions  $u_k$  we are interested in are solutions of the following problem:

$$\begin{cases}
-\Delta u_k = \lambda_k(\rho)\rho(x)u_k & \text{in } \Omega, \\
u_k = 0 & \text{on } \partial\Omega.
\end{cases}$$
(9.1)

Each eigenvalue can also be characterized by the usual min-max formulae:

$$\lambda_1(\rho) = \inf_{y \in H_0^1(\Omega), y \neq 0} \frac{\int_{\Omega} |\nabla y(x)|^2}{\int_{\Omega} \rho(x) y(x)^2 dx}$$
(9.2)

and

$$\lambda_k(\rho) = \min_{\substack{E_k \subset H_0^1(\Omega), \\ \text{subspace of dim } k}} \max_{v \in E_k, v \neq 0} \frac{\int_{\Omega} |\nabla v(x)|^2 dx}{\int_{\Omega} \rho(x) v(x)^2 dx}.$$
 (9.3)

As usual, we are looking for minimizers or maximizers of a given eigenvalue  $\lambda_k(\rho)$  among density  $\rho$  satisfying some natural constraints. For example, let  $\alpha, \beta$  and c be three real numbers such that  $0 \le \alpha < \beta$  and  $\alpha |\Omega| \le c \le \beta |\Omega|$ . We introduce the class of admissible  $\rho$  defined by

$$\mathcal{A} := \{ \rho \in L^{\infty}(\Omega); \alpha \le \rho(x) \le \beta \text{ a.e. in } \Omega, \ \int_{\Omega} \rho(x) \, dx = c \}. \tag{9.4}$$

If we want to emphasize the dependence of  $\mathcal{A}$  with respect to its parameters, we will denote the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$ . We recall that  $\mathcal{A}$  is a convex subset of  $L^{\infty}(\Omega)$ , that it is compact for the weak-\* convergence and that its extremal points are precisely of the kind  $\beta\chi_{\omega} + \alpha\chi_{\Omega\setminus\omega}$  for some subset  $\omega$  of  $\Omega$  (see e.g. [104], [91], [202]).

In one dimension, the problem of maximizing and minimizing  $\lambda_k(\rho)$  had been completely solved by M.G. Krein in [133]. His results are presented in section 9.3. Before, in section 9.2, we gave some general existence results. They show, in particular, that Krein's results are not specific to the dimension 1. More precisely, we will see that, under mild assumptions, the minimizers of  $\rho \mapsto \lambda_k(\rho)$  are always extremal points of the set  $\mathcal{A}$ . In control theory, such functions are generally called bang-bang controls.

**Remark 9.1.1.** In this chapter, we will only consider the problems  $\max_{\rho} \lambda_k(\rho)$  or  $\min_{\rho} \lambda_k(\rho)$ . We could also consider the problem of maximizing the ratio  $\lambda_2/\lambda_1$ . As in Theorems 6.2.1 and 8.5.8, M. Ashbaugh and R. Benguria have proved in [10] that the maximum of  $\lambda_2(\rho,\Omega)/\lambda_1(\rho,\Omega)$  is achieved when  $\Omega$  is a ball and  $\rho(x)=1$ .

Remark 9.1.2. It is also possible to mix in some sense chapters 8 and 9 by considering eigenvalue problems like  $-\Delta u + V(x)u = \lambda \rho(x)u$ . It is done, for example, in [28] or [118]. Roughly speaking, the results obtained there are natural extensions of those presented here.

We first begin by a continuity result, in the spirit of section 2.3.2. See also [65].

**Theorem 9.1.3.** The map  $\rho \mapsto \lambda_k(\rho)$  is continuous on  $\mathcal{A}$  for the weak-\* convergence. Moreover, the map  $\rho \mapsto 1/\lambda_k(\rho)$  is convex.

Proof. The eigenvalue problem (9.1) is not exactly of the kind considered in chapter 1. Nevertheless, existence of a sequence of eigenvalues and eigenfunctions can be obtained exactly in the same way by considering, instead of  $(-\Delta)^{-1}$ , the operator  $R_{\rho} := (-\Delta)^{-1} M_{\rho}$  where  $M_{\rho}$  is the linear continuous operator from  $L^{2}(\Omega)$ , in itself defined by  $M_{\rho}(u) = \rho u$ . In particular, it is easy to check that  $R_{\rho_{n}}(f)$  converges to  $R_{\rho}(f)$  in  $L^{2}(\Omega)$  as soon as  $\rho_{n}$  converges weak-\* to  $\rho$ . Therefore, the continuity result follows immediately by applying Theorem 2.3.2.

At last, the max formulae for  $\mu_k(\rho) = 1/\lambda_k(\rho)$ :

$$\frac{1}{\lambda_k(\rho)} = \mu_k(\rho) = \max_{\substack{v \in H_0^1(\Omega), \\ v \in [u_1, u_2, \dots, u_{k-1}]^{\perp}}} \frac{\int_{\Omega} \rho(x)v(x)^2 dx}{\int_{\Omega} |\nabla v(x)|^2 dx}$$
(9.5)

implies that the function  $\rho \mapsto 1/\lambda_k(\rho)$  is convex as supremum of linear functions.

9.2. Existence results 143

#### 9.2 Existence results

#### 9.2.1 A first general existence result

The previous continuity result together with the compactness of the set  $\mathcal{A}$  of admissible  $\rho$  for the weak-\* topology immediately yields:

**Theorem 9.2.1.** Let  $F: \mathbb{R}^k \to \mathbb{R}$  be a continuous function. Then the problem

$$\min_{\rho \in \mathcal{A}} F(\lambda_1(\rho), \lambda_2(\rho), \dots, \lambda_k(\rho)) \tag{9.6}$$

where A is defined in (9.4) has a solution. The same result holds for a similar maximization problem.

**Remark 9.2.2.** The same existence result holds true when  $\mathcal{A}$  is replaced by the larger class  $\{\rho \in L^{\infty}(\Omega); \alpha \leq \rho(x) \leq \beta \text{ a.e. in } \Omega\}.$ 

For a functional F, we will be mainly concerned in the sequel (in particular in sections 9.3 and 9.4) with  $F(x_1, \ldots, x_k) = x_k$ , i.e. we will be interested in minimizing (or maximizing)  $\lambda_k(\rho)$ . So an immediate consequence of the convexity of  $\rho \mapsto 1/\lambda_k(\rho)$  is the following. Since a maximizer of  $1/\lambda_k(\rho)$  (i.e. a minimizer of  $\lambda_k(\rho)$ ) is to be sought among extremal points of the convex set A:

**Theorem 9.2.3.** There exists a function  $\rho^*$  minimizing  $\lambda_k(\rho)$  in the class  $\mathcal{A}$  defined in (9.4) and it is of the form  $\rho^* = \beta \chi_\omega + \alpha \chi_{\Omega \setminus \omega}$  for some subset  $\omega$  of  $\Omega$ .

We give a generalization of this result in the next section.

#### 9.2.2 A more precise existence result

When we assume some monotonicity for the function F, one can generalize the previous result by proving that the optimum solutions are always bang-bang. The following Theorem is due to S. Friedland in [91].

**Theorem 9.2.4 (Friedland).** Let  $F : \mathbb{R}^k \to \mathbb{R}$  be a continuous function, increasing with respect to its arguments. Then the problem

$$\min_{\rho \in \mathcal{A}} F(\lambda_1(\rho), \lambda_2(\rho), \dots, \lambda_k(\rho)) \tag{9.7}$$

where A is defined in (9.4) has a solution  $\rho^*$  which is of the kind

$$\rho^* = \beta \chi_\omega + \alpha \chi_{\Omega \setminus \omega} \tag{9.8}$$

where  $\omega$  is some subset of  $\Omega$ .

The same result holds for a maximization problem with a function F decreasing with respect to its arguments.

Remark 9.2.5. For general functionals F, the optimal solution is not necessarily a bang-bang function as in (9.8). For example, as pointed out in [211], if  $\hat{\rho}$  is any function in the class  $\mathcal{A}$  and  $\hat{\lambda}_k = \lambda_k(\hat{\rho})$ , it is clear that a minimizer of the functional  $F(\lambda_1(\rho), \lambda_2(\rho), \dots, \lambda_k(\rho)) := \sum_{i=1}^k (\lambda_i(\rho) - \hat{\lambda}_i)^2$  will be  $\hat{\rho}$ . We refer to [93], [211], [212] for a complete analysis in the one-dimensional case. One of the important technical points which occurs in the variational analysis is the following question: can a linear combination of the squares of the first k eigenfunctions be a constant (zero or non-zero) over some measurable subset which has non-zero measure? Actually, in [145], the authors prove that it can happen. For a similar question, but in a completely different context, we refer to [100].

Nevertheless, it seems that generically, the optimum must be of the kind (9.8). Assuming that the gradient of the functional F does not vanish on the range of possible values for  $(\lambda_1(\rho), \lambda_2(\rho))$ , T. Mahar and B. Willner in [212] (see also [93], [211]) proved that the extremizers  $\rho^*$  have necessarily one of the following form:

$$\rho^*(x) = \alpha \text{ or } \beta, \text{ or } \begin{cases} \alpha \text{ or } \beta & 0 < x < x_0, \\ \beta \text{ or } \alpha & x_0 < x < 1, \end{cases} \text{ or } \begin{cases} \alpha \text{ or } \beta & 0 < x < x_0, \\ \beta \text{ or } \alpha & x_0 < x < x_1, \\ \alpha \text{ or } \beta & x_1 < x < 1. \end{cases}$$

For example, the ratio  $F(\lambda_1, \lambda_2) = \lambda_2/\lambda_1$  has been studied in several papers. In [126], [144], the authors find that the extremizers in the class  $\mathcal{A}$  are of the third kind as above. For more general Sturm-Liouville operators, we refer to [13], [115] and for other constraints on the density, we refer to [114], [112].

For the proof of Theorem 9.2.4, we need a preliminary result, the so-called Convoy Principle, which allows us to compare the eigenvalues of our problem to the eigenvalues of some symmetric matrix, see [91] or [173]. Let us fix the notation. We recall that we denote by  $A_L^D$ , or more simply A, the inverse of the Laplacian defined in (1.8). Then, the eigenvalues  $\lambda_k(\rho)$  satisfy

$$\frac{1}{\lambda_k(\rho)} := \mu_k(\rho) = \max \frac{\int_{\Omega} \rho A(f)^2 dx}{\int_{\Omega} |\nabla A(f)|^2 dx}$$
(9.9)

where the maximum is taken over the functions f orthogonal to the (k-1)-th first eigenfunctions  $u_j$ ,  $j=1,\ldots,k-1$ . Moreover, the maximum is achieved only if f is an eigenfunction corresponding to  $\lambda_k(\rho)$ .

Let us now consider a family of functions  $f_1, f_2, \ldots, f_k$  in  $L^2(\Omega)$  which satisfy

$$\int_{\Omega} \nabla(A(f_i)) \cdot \nabla(A(f_j)) \, dx = \delta_{ij} \tag{9.10}$$

i.e. they are orthonormal for the inner product  $((f,g)) := \int_{\Omega} \nabla(A(f)) \cdot \nabla(A(g)) dx$ . Then, we introduce the  $k \times k$  matrix  $A(\rho, f_1, \dots, f_k)$  whose general term is given by  $\int_{\Omega} \rho A(f_i) A(f_j) dx$ . We denote by  $\lambda_j(\rho, f_1, \dots, f_k)$  and  $\xi^j(\rho, f_1, \dots, f_k)$  its eigenvalues and eigenvectors respectively, assuming

$$\lambda_1(\rho, f_1, \dots, f_k) \ge \dots \ge \lambda_k(\rho, f_1, \dots, f_k)$$
.

Then, we have

**Lemma 9.2.6 (Convoy Principle).** Let  $(f_1, \ldots, f_k)$  be functions in  $L^2(\Omega)$  satisfying (9.10). Then

$$\frac{1}{\lambda_j(\rho)} = \mu_j(\rho) \ge \lambda_j(\rho, f_1, \dots, f_k) \quad j = 1, 2, \dots, k.$$
(9.11)

*Proof.* Let us introduce  $f_a := \sum_{i=1}^k a_i f_i$  where  $a = (a_1, \dots, a_k)$  is chosen such that

$$\sum_{i=1}^{k} a_i(f_i, u_j) = 0, \quad j = 1, \dots, k-1, \quad \sum_{i=1}^{k} a_i^2 = 1$$

(where  $u_j$  are the eigenfunctions associated to  $\lambda_j(\rho)$ ). Thus, according to (9.9),

$$\int_{\Omega} \rho A(f_a)^2 dx \le \mu_k(\rho).$$

Now, the minimal characterization of  $\lambda_k(\rho, f_1, \dots, f_k)$  is

$$\lambda_k(\rho, f_1, \dots, f_k) = \min_{b, \sum_{i=1}^k b_i^2 = 1} \sum_{i,j=1}^k b_i b_j \int_{\Omega} \rho A(f_i) A(f_j) \, dx \,. \tag{9.12}$$

So we have

$$\lambda_k(\rho, f_1, \dots, f_k) \le \int_{\Omega} \rho A(f_a)^2 dx \le \mu_k(\rho). \tag{9.13}$$

This proves (9.11) for j = k. For j < k, we proceed by induction by reducing our case to the k-1 dimensional problem. Let

$$\hat{f}_i = \sum_{j=1}^k \xi_j^i f_j, \ i = 1, \dots, k-1.$$

A straightforward calculation shows that  $\int_{\Omega} \nabla(A(\hat{f}_i)) \cdot \nabla(A(\hat{f}_j)) dx = \delta_{ij}$  and

$$\lambda_j(\rho, \hat{f}_1, \dots, \hat{f}_{k-1}) = \lambda_j(\rho, f_1, \dots, f_k), \quad j = 1, \dots, k-1.$$

In this way, we establish (9.11).

**Remark 9.2.7.** If we choose  $f_j = u_j$  (the eigenfunctions associated to  $\lambda_j(\rho)$ ), the equality sign holds in (9.11). Reciprocally, if the equality holds for some j, then the eigenvectors  $\xi^j$  can be chosen such that

$$\rho A\left(\sum_{i=1}^{k} \xi_i^j f_i\right) = \lambda_j(\rho) \sum_{i=1}^{k} \xi_i^j f_i,$$

see [91] for more details.

Proof of Theorem 9.2.4. First, we consider a function F increasing in each of its arguments, and we are interested in maximizing  $F(\mu_1(\rho), \mu_2(\rho), \dots, \mu_k(\rho))$  in the class A. We already know, according to Theorem 9.2.1, the existence of a maximizer, say  $\varphi$ . Let  $u_1, u_2, \dots, u_k$  be the first eigenfunctions of the operator  $M_{\varphi}A$ , i.e. they satisfy  $\varphi A(u_j) = \mu_j(\varphi) u_j$  associated to the eigenvalues  $\lambda_1(\varphi), \lambda_2(\varphi), \dots, \lambda_k(\varphi)$  or  $\mu_1(\varphi), \mu_2(\varphi), \dots, \mu_k(\varphi)$ . We assume that  $(u_i, u_j) = \delta_{ij}, i, j = 1, \dots, k$ . Let us now introduce the set A' defined by

$$\mathcal{A}' := \{ \rho \in \mathcal{A}; \int_{\Omega} \rho(x) A(u_i)(x) A(u_j)(x) dx = \mu_i(\varphi) \delta_{ij}, \ i, j = 1, \dots, k \}. \quad (9.14)$$

This set  $\mathcal{A}'$  is not empty since it contains  $\varphi$ . Moreover, it is convex. Let  $\rho^*$  be an extreme point in  $\mathcal{A}'$ . It is classical to see that it must satisfy  $\rho^* = \beta \chi_\omega + \alpha \chi_{\Omega \setminus \omega}$  where  $\omega$  is some subset of  $\Omega$ , see [91], [104]. Now, the condition defining the set  $\mathcal{A}'$  in (9.14) means that  $A(\rho^*, u_1, \ldots, u_k)$  is a diagonal matrix  $\operatorname{diag}(\mu_1(\varphi), \ldots, \mu_k(\varphi))$ . So

$$\lambda_j(\rho^*, u_1, \dots, u_k) = \mu_j(\varphi), \quad j = 1, \dots, k.$$

From the Convoy Principle (9.11), we have

$$\mu_j(\rho^*) \ge \mu_j(\varphi) \,. \tag{9.15}$$

Since  $F(x_1, \ldots, x_k)$  is an increasing function of each of its arguments, (9.15) implies that

$$F(\mu_1(\rho^*), \dots, \mu_k(\rho^*)) \ge F(\mu_1(\varphi), \dots, \mu_k(\varphi)). \tag{9.16}$$

Since  $\rho^* \in \mathcal{A}$ , (9.16) shows that  $\rho^*$  is also a maximizer.

Now, let us assume that we want to maximize  $F(\lambda_1(\rho), \ldots, \lambda_k(\rho))$  with F a decreasing function of each of its arguments. By looking at the function  $\widetilde{F}(\mu_1(\rho), \ldots, \mu_k(\rho)) := F(1/\mu_1(\rho), \ldots, 1/\mu_k(\rho))$ , we are led to the same problem, so the same result holds.

Finally, assume that  $F(x_1, \ldots, x_k)$  is a function, increasing in each of its arguments, and we want to minimize  $F(\lambda_1(\rho), \ldots, \lambda_k(\rho))$ . Let us fix a constant a > 0 chosen so that  $F(\lambda_1(\rho), \ldots, \lambda_k(\rho)) + a > 0$  for any  $\rho \in \mathcal{A}$ . Then,

$$[F(\lambda_1(\rho),\ldots,\lambda_k(\rho))+a]^{-1}=[F(\mu_1^{-1}(\rho),\ldots,\mu_k^{-1}(\rho))+a]^{-1}$$

and clearly  $\widetilde{F}(x_1,\ldots,x_k):=[F(x_1^{-1},\ldots,x_k^{-1})+a]^{-1}$  is a continuous function increasing in each of its arguments, so we can apply the first part of the proof to this situation. This finishes the proof.

#### 9.2.3 Nonlinear constraint

Instead of considering the  $L^1$  constraint  $\int_{\Omega} \rho(x) dx = c$  for the density  $\rho$ , one could also consider an  $L^p$  constraint like  $\int_{\Omega} \rho^p(x) dx = c$  (as we did for the potential V in chapter 8). This is interesting, in particular, for the classical problem of the strongest column with simply supported ends, see section 11.4.2. Actually, this case is simpler. For example, let us prove the following result:

**Theorem 9.2.8.** Let  $\Omega$  be a bounded Lipschitz domain in  $\mathbb{R}^N$  and let us fix a real number p>1 in dimension N=1 and p>N/2 in dimension  $N\geq 2$ . Let us introduce  $\mathcal{A}_p$  the class of non-negative measurable functions  $\rho$  defined on  $\Omega$  and satisfying  $\int_{\Omega} \rho^p(x) dx = 1$ . Then, there exists a minimizer  $\rho_p^*$  of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_p$ . Moreover, the minimizer is given by  $\rho_p^* = k_p u_p^{1/(p-1)}$  where u is the minimizer on  $H_0^1(\Omega)$  of the functional G defined by

$$G(y) := \frac{\int_{\Omega} |\nabla y(x)|^2}{\left(\int_{\Omega} y(x)^{\alpha} dx\right)^{2/\alpha}}$$
(9.17)

with  $\alpha=2p/(p-1)$  and the constant  $k_p$  is defined by the integral condition  $\int_{\Omega} \rho_p^{*p}(x) dx = 1$ . We can also characterize  $u_p$  as the solution of the nonlinear p,d,e.

$$\begin{cases}
-\Delta u = \mu \left( \int_{\Omega}, u(x)^{\alpha} dx \right)^{2/\alpha - 1} u^{\alpha - 1} & \text{in } \Omega \\
u = 0 & \text{on } \partial\Omega,
\end{cases}$$
(9.18)

where  $\mu = \inf_{H_0^1(\Omega)} G(y)$ .

*Proof.* The proof of Theorem 9.2.8 looks like the proof of Theorem 8.2.3, but is in some sense simpler. Actually, Hölder inequality yields

$$\int_{\Omega} \rho y^2(x) \, dx \le \left( \int_{\Omega} \rho^p(x) \, dx \right)^{1/p} \left( \int_{\Omega} y^{\alpha}(x) \, dx \right)^{2/\alpha} = \left( \int_{\Omega} y^{\alpha}(x) \, dx \right)^{2/\alpha} \tag{9.19}$$

where  $\alpha = 2p/(p-1)$ . Moreover equality holds in (9.19) if and only if  $\rho^p$  and  $y^{\alpha}$  are proportional. Therefore, we have the inequality

$$\frac{\int_{\Omega} |\nabla y(x)|^2 dx}{\int_{\Omega} \rho(x) y(x)^2 dx} \ge G(y) = \frac{\int_{\Omega} |\nabla y(x)|^2 dx}{\left(\int_{\Omega} y^{\alpha}(x) dx\right)^{2/\alpha}}.$$
(9.20)

Now, it is classical, using standard compactness arguments, to prove that the functional G possesses a minimum on  $H^1_0(\Omega)$ . Indeed, the main point is Rellich's Theorem ensuring compact embedding of  $H^1_0(\Omega)$  into  $L^{\alpha}(\Omega)$  (this is always true in dimension N=1,2 and if  $2p/(p-1)=\alpha<2N/(N-2)$  in dimension  $N\geq 3$  which explains restriction on p in this case). Let  $u_p$  be defined as a minimizer of the functional G on  $H^1_0(\Omega)$ . Therefore, taking the minimum in p in the right-hand side of (9.20) yields

$$\frac{\int_{\Omega} |\nabla y(x)|^2 dx}{\int_{\Omega} \rho(x) y(x)^2 dx} \ge G(u_p) \tag{9.21}$$

with equality for  $\rho$  such that  $\rho^p$  and  $u_p^{\alpha}$  are proportional (or  $\rho = k u_p^{\alpha/p}$ ). Let us consider such a function belonging to the class  $\mathcal{A}_p$ , which is exactly  $\rho_p^*$ . Now, we take the infimum in y in the left-hand side of (9.21), which implies  $\lambda_1(\rho) \geq G(u_p)$  for all  $\rho$ . Moreover, if we choose  $y = u_p$  and  $\rho = \rho_p^*$ , equality holds in (9.21), so variational characterization (9.2) of  $\lambda_1$  yields  $G(u_p) \geq \lambda_1(\rho_p^*)$ . The result follows.

At last, we get the other expression of  $u_p$  in a classical way; this is just the Euler-Lagrange characterization of the minimizer of G.

Remark 9.2.9. In general, there is no maximizer of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_p$  (in the sense that  $\sup_{\mathcal{A}_p} \lambda_1(\rho) = +\infty$ ). Let us prove it, for example, in one dimension for  $\Omega = (0, L)$  (we follow an idea of [83]). We start from the classical Hardy's inequality

$$\int_0^{+\infty} \frac{z^2(x)}{x^2} \, dx \le 4 \int_0^{+\infty} z'^2(x) \, dx,\tag{9.22}$$

valid for every absolutely continuous function z vanishing at 0. Let y be a function in  $H_0^1(0,L)$  and  $\varepsilon > 0$  be given. We extend y by 0 outside (0,L) and we apply (9.22) to  $z(x) := y(x - \varepsilon)$ , then

$$\int_0^{+\infty} \frac{y^2(x-\varepsilon)}{x^2} dx = \int_0^{+\infty} \frac{y^2(t)}{(t+\varepsilon)^2} dt \le 4 \int_0^{+\infty} {y'}^2(x-\varepsilon) dx = 4 \int_0^{+\infty} {y'}^2(t) dt.$$
(9.23)

Now, we consider the function  $\rho_{\varepsilon}$  defined by

$$\rho_{\varepsilon}(x) := \frac{c_{\varepsilon}}{(x+\varepsilon)^2} \quad \text{with } c_{\varepsilon} = \varepsilon^{2-1/p} \left\{ \frac{(2p-1)}{1 - \left(\frac{\varepsilon}{L+\varepsilon}\right)^{2p-1}} \right\}^{1/p}$$

(the constant  $c_{\varepsilon}$  is obviously chosen in order that  $\rho_{\varepsilon}$  belongs to the class  $\mathcal{A}_p$ ). Applying (9.23) to the first eigenfunction associated to  $\rho_{\varepsilon}$ , it follows that

$$\lambda_1(\rho_{\varepsilon}) \ge \frac{1}{4c_{\varepsilon}} \to +\infty \text{ when } \varepsilon \to 0,$$

which shows the claim.

For more precise results in the one-dimensional case (for example, the computation of the constant  $\mu$  and a discussion about other values of p), we refer the interested reader to Theorem 23 in chapter 5 of [83].

#### 9.3 Minimizing or maximizing $\lambda_k(\rho)$ in dimension 1

All the results that we are giving in this section are due to M.G. Krein, [133]. Our presentation is somewhat simpler, because of the tools we have already introduced. Without loss of generality, we consider here the one-dimensional interval  $\Omega = (0, L)$ .

#### **9.3.1** Minimizing $\lambda_k(\rho)$

**Theorem 9.3.1 (Krein).** (i) The (unique) minimizer of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}$  defined in (9.4) is the function  $\rho_1(x)$  defined by

$$\rho_1(x) = \begin{cases}
\alpha & \text{for} \quad x \in (0, \frac{L}{2} - \delta), \\
\beta & \text{for} \quad x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\
\alpha & \text{for} \quad x \in (\frac{L}{2} + \delta, L),
\end{cases}$$
(9.24)

where  $\delta = (c - \alpha L)/2(\beta - \alpha)$ .

(ii) The (unique) minimizer of  $\lambda_k(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}$  is the function  $\rho_k(x)$  which is L/k-periodic and which is defined on each interval

$$(jL/k, (j+1)L/k), \quad j = 0, \dots, k-1$$

by

$$\rho_k(x) = \rho_1 \left( kx - jL \right) .$$

*Proof.* We already know, by Theorem 9.2.3, that the minimizer exists and that it is of the form

$$\rho = \beta \chi_{\omega} + \alpha \chi_{\Omega \setminus \omega} \,. \tag{9.25}$$

Let us begin with k=1. The proof is similar to the one of Faber-Krahn's Theorem 3.2.1. Let  $\rho^*$  be the decreasing rearrangement of  $\rho$  (see section 2.1) with respect to the center of the interval (0, L). Since  $\rho$  is given by (9.25),  $\rho^* = \rho_1$  is the function defined in (9.24). Now, let us denote by  $u_1$  the first (normalized) eigenfunction associated to  $\lambda_1(\rho)$  and by  $u_1^*$  its decreasing rearrangement. According to Pòlya inequality (2.2) and Hardy-Littlewood inequality (2.4)

$$\int_0^L \frac{du^*}{dx}^2 \le \int_0^L \frac{du}{dx}^2, \quad \int_0^L \rho^* u^{*2}(x) \ge \int_0^L \rho u^2(x).$$

The main point in the previous chain of inequality is the fact that  $u^{*2}$  is the decreasing rearrangement of  $u^2$ ; for a more general result in this direction, see e.g. [59], Theorem 1. Plugging these two inequalities into the variational characterization of  $\lambda_1(\rho^*)$  (9.2), we get immediately  $\lambda_1(\rho^*) \leq \lambda_1(\rho)$ . For uniqueness, one can use the analysis of the equality case for example for the Pòlya inequality.

For the proof of the general case k, we just give the main idea. Exactly as in the proof of Theorem 8.3.3, we use that the eigenfunction  $u_k$  has k nodal domains and that  $\lambda_k(\rho)$  is the first eigenfunction of each nodal domain. Therefore, the restriction of  $\rho$  on each nodal domain has to be of the form of  $\rho_1$ . At last, the fact that the eigenvalue is the same on each sub-interval shows that these intervals have to be of the same length. We refer to [133] for the details.

**Remark 9.3.2.** One could be interested in studying what happens when the upper limit  $\beta$  is removed (or goes to  $+\infty$ ). In this case, passing to the limit (in the sense

of measures or distributions), we can prove that the minimum of  $\lambda_k$  is achieved when the string is uniformly loaded with a density  $\alpha$ , and bears in addition k point Dirac masses of magnitude  $(c-\alpha L)/k$  placed as follows: the string is divided into k parts equal in length, and at the center of each part is placed the point mass in question.

#### **9.3.2** Maximizing $\lambda_k(\rho)$

**Theorem 9.3.3 (Krein).** (i) The (unique) maximizer of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}$  defined in (9.4) is the function  $\rho^1(x)$  defined by

$$\rho^{1}(x) = \begin{cases}
\beta & \text{for} \quad x \in (0, \frac{L}{2} - \delta), \\
\alpha & \text{for} \quad x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\
\beta & \text{for} \quad x \in (\frac{L}{2} + \delta, L),
\end{cases}$$
(9.26)

where  $\delta = (\beta L - c)/2(\beta - \alpha)$ .

(ii) If  $\alpha > 0$ , the (unique) maximizer of  $\lambda_k(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  is the function  $\rho^k(x)$  which is L/k-periodic and which is defined on each interval  $(jL/k, (j+1)L/k), j = 0, \ldots, k-1$  by

$$\rho^{k}(x) = \rho^{1} (kx - jL) . \tag{9.27}$$

(iii) If  $\alpha = 0$ , the maximizers of  $\lambda_k(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  are all the functions defined in the following way. Let  $\delta_0 = c/2\beta$  and  $0 = x_0 < x_1 < x_2 < \cdots < x_{k-1} < x_k = L$  be any sequence of points satisfying the conditions  $x_i - x_{i-1} \geq 2\delta_0/k$  (i = 1, 2, ..., k). Then, the maximizers are the functions  $\rho$  defined by:

$$\rho(x) = \begin{cases}
\beta & \text{for} \quad x \in (x_{i-1}, x_{i-1} + \delta_0/k), \\
0 & \text{for} \quad x \in (x_{i-1} + \delta_0/k, x_i - \delta_0/k), \\
\beta & \text{for} \quad x \in (x_i - \delta_0/k, x_i).
\end{cases} (9.28)$$

*Proof.* We begin with the first eigenvalue. First of all, let us prove that we may confine our attention to functions which are symmetric w.r.t. L/2 when looking for a maximizer. Indeed, let  $\rho$  be any function in  $\mathcal{A}_{\alpha,\beta,c}$  and let us denote by

$$\rho_s(x) := \rho(L - x)$$

the function which is symmetric to it. Obviously,

$$\lambda_1(\rho_s) = \lambda_1(\rho)$$

and  $\rho^* := (\rho + \rho_s)/2$  is symmetric w.r.t. L/2. By convexity of  $\rho \mapsto 1/\lambda_1(\rho)$  (see Theorem 9.1.3), we get

$$1/\lambda_1(\rho^*) = 1/\lambda_1((\rho + \rho_s)/2) \le \frac{1}{2}(1/\lambda_1(\rho) + 1/\lambda_1(\rho_s)) = 1/\lambda_1(\rho)$$

or

$$\lambda_1(\rho^*) \ge \lambda_1(\rho). \tag{9.29}$$

Now, let us denote by  $u_1$  the first (positive) eigenfunction associated to the function  $\rho^1$  defined in (9.26). By the equation  $-u_1'' = \lambda_1(\rho^1)u_1$ , we see that  $u_1$  is concave, symmetric w.r.t. L/2 and non-decreasing on (0, L/2). Now, let  $\rho$  be any symmetrical function in the class  $\mathcal{A}_{\alpha,\beta,c}$ . We write

$$\begin{split} & \int_0^L {u_1}^2 \rho \, dx - \int_0^L {u_1}^2 \rho^1 \, dx = 2 \int_0^{L/2} {u_1}^2 (\rho - \rho^1) \, dx \\ & = 2 \int_0^{L/2 - \delta} {u_1}^2 (\rho - \beta) \, dx + 2 \int_{L/2 - \delta}^{L/2} {u_1}^2 (\rho - \alpha) \, dx \\ & \ge 2 {u_1}^2 (L/2 - \delta) \int_0^{L/2 - \delta} (\rho - \beta) \, dx + 2 {u_1}^2 (L/2 - \delta) \int_{L/2 - \delta}^{L/2} (\rho - \alpha) \, dx = 0, \end{split}$$

the last equality coming from  $\int_0^{L/2} \rho \, dx = c/2 = \beta(L/2 - \delta) + \alpha \delta$ . It follows that

$$\int_0^L u_1^2 \rho \, dx \ge \int_0^L u_1^2 \rho^1 \, dx \tag{9.30}$$

and from the variational characterization of  $\lambda_1$ :

$$\frac{1}{\lambda_1(\rho)} \ge \frac{\int_0^L u_1^2 \rho \, dx}{\int_0^L u_1'^2 \, dx} \ge \frac{\int_0^L u_1^2 \rho^1 \, dx}{\int_0^L u_1'^2 \, dx} = \frac{1}{\lambda_1(\rho^1)}$$

which shows that  $\rho^1$  achieves the maximum of  $\lambda_1(\rho)$ . Moreover, the equality sign can hold only if we have equality in the above chain of inequalities. But, this is possible if and only if  $\rho = \beta$  on  $(0, L/2 - \delta)$  and  $\rho = \alpha$  on  $(L/2 - \delta, L/2)$ , i.e. if  $\rho = \rho^1$ .

Now, we look at the case of the k-th eigenvalue. The idea is still the same. As usual, the nodes of the eigenfunction associated to  $\lambda_k(\rho)$  divide the string into k parts. Moreover,  $\lambda_k(\rho)$  will be the first eigenvalue of each nodal domain. In particular, according to the first part of the proof, we must choose  $\rho$  in each nodal domain with the form of  $\rho^1$  if we want to maximize it. This leads to (9.27) when  $\alpha > 0$  (uniqueness comes from the fact that the intervals must have all the same length in this case if we want that first eigenvalue of each nodal domains to coincide). When  $\alpha = 0$ , the length of the unloaded central part of the segment  $(x_{i-1}, x_i)$  has no effect at all on the value of the first frequency. This explains why we get an infinite set of solutions in this case.

Remark 9.3.4. One could be interested in studying what happens when the upper limit  $\beta$  is removed (or goes to  $+\infty$ ). In this case, passing to the limit, we can prove that the maximum is achieved when the string is uniformly loaded with a density  $\alpha$  (assumed to be positive), and the remaining mass  $c - \alpha L$  is placed at the fixed ends of the string.

**Remark 9.3.5.** P. Nowosad in [160] is able to generalize Krein's results with an algebraic approach, see also the work of S. Karlin [120].

**Remark 9.3.6.** Among various works on this topic, let us quote the following. B. Schwarz in [184] has considered the problem of minimizing or maximizing  $\lambda_k(\rho)$ among equimeasurable  $\rho$ . He obtains that the minimum (resp. maximum) is attained (uniquely) for the function which is L/k periodic and which, in each interval, is symmetrically decreasing (resp. increasing). In a series of papers, D.O. Banks see [21], [22], [23] looks at the problem of maximizing or minimizing the first eigenvalue  $\lambda_1(\rho)$  with monotonicity, convexity or Lipschitz constraints on the density ρ. In [27], D.C. Barnes looks at similar problems of minimizing and maximizing  $\lambda_k(\rho)$  when the density  $\rho$  has its average value  $P(x) := \frac{1}{x} \int_0^x \rho(t) dt$  restricted in some manner (he assumes for example P to be decreasing or concave). In [29]. E.R. Barnes considers more general boundary conditions like  $a_1y(0) - b_1y'(0) = 0$ and  $a_2y(L) - b_2y'(L) = 0$  and studies the maximization problem for  $\lambda_1(\rho)$ . He also replaces the mass condition  $\int_0^L \rho(x) dx = c$  by a more general one of the form  $\int_0^L f(x,\rho(x)) dx = c$  where f is a given continuous function. His approach consists in exploiting the optimality conditions. In such a general framework, it is not possible to get an explicit maximizer. Some examples like  $f(x,\rho) = \rho^n$  are considered and detailed (see also [125], [197] for this particular constraint which corresponds to the strongest column problem, see also section 11.4.2). In this case, they found a maximizer which is similar to the one given in (9.26). We refer also to [28] for a similar approach for the more general eigenvalue equation  $-y'' = \lambda q(x, \rho(x))y$ . In this paper, D.C. Barnes looks also for maximizing or minimizing the eigenvalues  $\lambda_k(\rho)$  and gets some explicit solutions for particular choices of the function g.

# 9.4 Minimizing or maximizing $\lambda_k(\rho)$ in higher dimension

#### 9.4.1 Case of a ball

When  $\Omega = B_R$  is a ball of radius R, several arguments that we used in section 9.3 remain valid. In particular, one can prove

**Theorem 9.4.1 (Krein).** Let  $\Omega = B_R$  be a ball of radius R. Then

(i) The minimum of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(B_R)$  defined in (9.4) is attained uniquely for the function  $\rho_1$  given by

$$\rho_1(x) = \begin{cases} \beta & for & |x| \le \delta, \\ \alpha & for & \delta < |x| < R, \end{cases}$$
 (9.31)

where  $\delta$  is defined by the equality  $(\beta - \alpha)|B_{\delta}| + \alpha|B_{R}| = c$ .

(ii) The maximum of  $\lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(B_R)$  is attained uniquely for the function  $\rho^1$  given by

$$\rho^{1}(x) = \begin{cases} \alpha & for & |x| \leq \delta, \\ \beta & for & \delta < |x| < R, \end{cases}$$
 (9.32)

where  $\delta$  is defined by the equality  $(\alpha - \beta)|B_{\delta}| + \beta|B_{R}| = c$ .

The proof is straightforward using the methods and ideas of the proofs of Theorems 9.3.1 and 9.3.3.

#### 9.4.2 General case

also [61] for a synthetic presentation.

Let  $\Omega$  be a bounded Lipschitz open subset of  $\mathbb{R}^N$  which is fixed in all this section. We recall that we already know (thanks to Theorem 9.2.1) that there exists a minimizer (resp. a maximizer) of  $\lambda_k(\rho)$  in the class  $\mathcal{A}$ , say  $\rho_k$  (resp.  $\rho^k$ ). Moreover, according to Theorem 9.2.4 the minimizer is of the kind

$$\rho_k = \beta \chi_\omega + \alpha \chi_{\Omega \setminus \omega} .$$

We want now to give more information about these extrema.

A way to get some information about the minimizer or the maximizer is to write down optimality conditions. Using the techniques of section 2.5.4, we can easily prove that  $\rho \mapsto \lambda_1(\rho)$  is differentiable on  $L^{\infty}(\Omega)$  with its derivative given by

$$\frac{d\lambda_1(\rho + t\xi)}{dt} \setminus_{t=0} = -\lambda_1(\rho) \int_{\Omega} \xi u_1^2 dx$$
 (9.33)

where  $u_1$  is the first eigenfunction associated to  $\lambda_1(\rho)$  normalized by  $\int_{\Omega} \rho u_1^2 dx = 1$ . Now, using the same kind of arguments as in the proof of Theorem 8.4.10, we can prove (we leave the details to the reader) the following theorem. We also refer to [65] for a different approach using Auchmuty's principle and min-max techniques or to section 6 of [198] for another approach using rearrangement, see

**Theorem 9.4.2 (Cox-McLaughlin).** (i) Let  $\rho_1$  be a minimizer of  $\lambda_1(\rho)$  in the class  $\mathcal{A}$  defined in (9.4) and  $u_1$  be the associated first eigenfunction. Then, there exists l > 0 such that, for each  $x \in \Omega$ ,

$$\rho_1(x) = \beta \quad \Rightarrow \quad u_1(x) \ge l, 
\rho_1(x) = \alpha \quad \Rightarrow \quad u_1(x) \le l,$$
(9.34)

and  $\rho_1 = \beta \chi_{\omega} + \alpha \chi_{\Omega \setminus \omega}$  where  $\omega$  is the level set  $\omega = \{x \in \Omega, u_1(x) \ge l\}$ .

(ii) Let  $\rho^1$  be a maximizer of  $\lambda_1(\rho)$  in the class  $\mathcal{A}$  and  $u^1$  be the associated first eigenfunction. Then, there exists l > 0 such that, for each  $x \in \Omega$ ,

$$\rho^{1}(x) = \beta \quad \Rightarrow \quad u_{1}(x) \leq l, 
\rho^{1}(x) = \alpha \quad \Rightarrow \quad u_{1}(x) \geq l,$$
(9.35)

and  $\rho^1 = \beta \chi_{\omega} + \alpha \chi_{\Omega \setminus \omega}$  where  $\omega$  is the level set  $\omega = \{x \in \Omega, u_1(x) \leq l\}$ . Moreover, the maximizer is unique.

Uniqueness of the maximizer comes directly from the fact that  $\rho \mapsto 1/\lambda_1(\rho)$  is convex (see Theorem 9.1.3) and the maximizer has to be an extreme point of the convex  $\mathcal{A}$ . Indeed the only convex set of extreme points is a singleton.

Remark 9.4.3. If uniqueness holds for the maximizer, it seems that it is not the case for the minimizers. Indeed, if we consider a domain  $\Omega$  composed of two disks joined by a long thin rectangle (like Figure 2.3) a limiting argument seems to give at least two minimizers, each of them concentrated on the center of one disk.

Remark 9.4.4. The previous result seems difficult to generalize to other eigenvalues. To write formulae (9.33), we obviously need the fact that the first eigenvalue is simple. It is absolutely not guaranteed for the other eigenvalues (we can even think that they should be multiple at the optimum as in Open problem 1).

Nevertheless, S. Cox and J. McLaughlin in [65] were able to generalize in some sense the result about minimizers of  $\lambda_k$  assuming that the corresponding eigenfunction has exactly k nodal domains. In this case, they obtain that  $\rho_k$  minimizes the first eigenvalue of each of these nodal domains and the minimization of  $\lambda_k$  is reduced to the earlier problem of minimizing  $\lambda_1$ .

Now, we can look at geometric properties of the set  $\omega$  or  $\Omega \setminus \omega$  when the optimum  $\rho$  is given by Theorem 9.4.2. First of all, adapting the beginning of the proof of Theorem 9.3.1, we are able to prove for the minimizer of  $\lambda_1(\rho)$ :

**Theorem 9.4.5.** Let us assume that  $\Omega$  is Steiner symmetric with respect to some hyperplane H (in the sense of Definition 2.2.2). Then, there exists a minimizer  $\rho_1$  of  $\lambda_1(\rho)$  in the class  $\mathcal{A}$  which is symmetric with respect to H. In particular,  $\rho_1 = \beta \chi_{\omega} + \alpha \chi_{\Omega \setminus \omega}$  with  $\omega$  Steiner symmetric w.r.t. H.

For the proof, use Pòlya inequality (2.8) and Hardy-Littlewood inequality (2.9) as in the proof of Theorem 9.3.1.

In the paper [59], using standard regularity theory for free boundary problems together with the optimality conditions, S. Cox was able to get some more precise results about  $\omega$  and its boundary  $\Gamma$ .

**Theorem 9.4.6 (Cox).** Let  $\Omega$  be a bounded connected set in  $\mathbb{R}^2$ .

- If  $\Omega$  is Steiner symmetric with respect to some line L, then  $\Gamma$  is an analytic curve except possibly at those points that it shares with the line L.
- If  $\Omega$  is Steiner symmetric in two distinct directions, then  $\Gamma$  is an analytic Jordan curve.

For the maximizer, it is also possible to get some symmetry and convexity result by using some moving plane method. Writing the eigenvalue equation

$$-\Delta u = \lambda_1 f(u)$$
 with  $f(t) := \beta t H(t) + (\alpha - \beta) t H(t - l)$ 

where l is the number given in Theorem 9.4.2 and H is the standard Heaviside function, S. Cox and J. McLaughlin were able to use classical results by Gidas-Ni-Nirenberg (together with a clever approximate argument since the function f which has been introduced above is not continuous) to get the following:

**Theorem 9.4.7 (Cox-McLaughlin).** Let us assume that  $\Omega$  is convex and symmetric in N orthogonal directions, and let us consider the maximizer  $\rho^1 = \beta \chi_{\omega} + \alpha \chi_{\Omega \setminus \omega}$  given by Theorem 9.4.2. Then the set  $\Omega \setminus \omega$  is convex and symmetric in these directions, and is star-shaped with respect to the center of symmetry.

#### 9.4.3 Some extensions

Instead of looking at the eigenvalue problem  $-\Delta u = \lambda \rho u$  corresponding to a non-homogeneous string, we are interested here in a more general eigenvalue problem containing, in particular, some important applications in mechanics.

Let us consider a bounded Lipschitzian connected open set  $\Omega$  in  $\mathbb{R}^N$  and a function a(x,t) defined on  $\Omega \times \mathbb{R}_+$  satisfying  $a(x,t) \geq a_0 > 0$  for some constant  $a_0$ . We are interested here in the eigenvalue problem:

$$\begin{cases}
-\Delta u = \lambda^{a}(\rho)a(x,\rho(x)) u & \text{in } \Omega, \\
u = 0 & \text{on } \partial\Omega
\end{cases}$$
(9.36)

and, more precisely, in its first eigenvalue  $\lambda_1^a(\rho)$  associated to the eigenfunction  $u_1$ . We want to maximize  $\lambda_1^a(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  defined in (9.4). All the results in this section are due to R. Tahraoui, see [198].

Let us first state an existence and uniqueness result in the case where a does not depend on x: a(x,t) = a(t).

**Theorem 9.4.8 (Tahraoui).** Let us assume that a does not depend on x and that the minimum of a(t) in the interval  $[\alpha, \beta]$  is attained only in one point. Then there exists a unique  $\rho^*$  maximizing  $\lambda_1^a(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$ .

If the function a is convex, then we can prove exactly as in Theorem 9.1.3 that  $\rho \mapsto 1/\lambda_1^a(\rho)$  is convex; then the existence result becomes classical, see for example [117]. Therefore, to prove existence, the strategy of R. Tahraoui consists in introducing the convexification  $a^{**}$  of the function a and to prove that the problem of maximizing the first eigenfunction of system (9.36) with a or  $a^{**}$  are equivalent. For that purpose, he shows, thanks to the optimality condition, that  $a(\rho^{**}(x)) = a^{**}(\rho^{**}(x))$  a.e. on  $\Omega$ , where  $\rho^{**}$  is the maximizer for  $a^{**}$ .

To prove uniqueness, one starts with two distinct maximizers, say  $\rho_1$  and  $\rho_2$ . We use the fact that  $\rho := (\rho_1 + \rho_2)/2$  is still a maximizer for  $a^{**}$ . A technical lemma allows to prove that

$$a^{**}(\rho(x)) < \frac{1}{2} \left( a^{**}(\rho_1(x)) + a^{**}(\rho_2(x)) \right)$$

on the set  $\{x \in \Omega, \rho_1(x) \neq \rho_2(x)\}$  assuming this set to have positive measure. Then, the convexity of  $a^{**}$  and the max formulae (9.5) for  $1/\lambda_1$  yields

$$\frac{1}{\lambda_1(\rho)} < \frac{1}{2} \left( \frac{1}{\lambda_1(\rho_1)} + \frac{1}{\lambda_1(\rho_2)} \right) = \frac{1}{\max \lambda_1}$$

contradicting the optimality of  $\rho_1$  and  $\rho_2$ .

**Remark 9.4.9.** In [198] is also considered in the previous theorem the case where a depends on x. Thanks to a supplementary assumption, the existence result is obtained in a similar way, but uniqueness remains to be proved.

Finally, let us give sufficient conditions ensuring that the maximizer is *bang-bang* as in the simple case a(t) = t described above. For that, we need to introduce some notation. Let  $\nu_1, \nu_2$  be the functions defined on  $\Omega$  by

$$\begin{cases}
\nu_1(x) = \inf a(x,t) & t \in [\alpha, \beta], \\
\nu_2(x) = \sup a(x,t) & t \in [\alpha, \beta]
\end{cases}$$
(9.37)

and  $\lambda_1(\nu_1)$ ,  $\lambda_1(\nu_2)$  denote the first eigenvalues of (9.1) with density  $\nu_1$  and  $\nu_2$  respectively. We also introduce the function  $\theta(x)$  by

$$\theta(x) := \frac{a(x,\beta) - a(x,\alpha)}{\beta - \alpha}.$$
(9.38)

We can now state the result:

**Theorem 9.4.10 (Tahraoui).** Let us suppose that the following assumptions hold true:

There exists a function 
$$s(x)$$
 and a constant  $L_0 > 0$  such that  $\forall (x,t) \in \Omega \times [\alpha,\beta], \quad a(x,t) \ge L(x,t) := \theta(x)t + s(x) \ge L_0,$  (9.39)

$$\forall x \in \Omega, \quad a(x,\alpha) = L(x,\alpha) \text{ and } a(x,\beta) = L(x,\beta),$$
 (9.40)

$$\forall \lambda \in [\lambda_1(\nu_2), \lambda_1(\nu_1)], \forall x \in \Omega \quad \frac{-\Delta(1/\sqrt{\theta(x)})}{1/\sqrt{\theta(x)}} \notin [a(x, \alpha), a(x, \beta)], \tag{9.41}$$

$$\theta(x) \ge 0 \text{ and } |\{x \in \Omega, \theta(x) = 0\}| = 0.$$
 (9.42)

Then, there exists a unique maximizer  $\rho_*^a$  of  $\lambda_1^a(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  defined in (9.4). This maximizer is bang-bang, i.e. there exists a subset  $\omega$  of  $\Omega$  such that

$$\rho_*^a = \alpha \chi_\omega + \beta \chi_{\Omega \setminus \omega} .$$

Moreover, there exists a number  $t_0 > 0$  such that

$$\{x\in\Omega,\theta(x)u_1^2(x)>t_0\}\subseteq\omega\subseteq\{x\in\Omega,\theta(x)u_1^2(x)\geq t_0\}$$

where  $u_1$  is an eigenfunction associated to  $\lambda_1(\rho_*^a)$ .

For the proof, we refer to [198]. It consists in a clever exploitation of the optimality conditions. Let us quote that in this paper, some other generalizations are considered. Instead of assuming  $\alpha \leq \rho(x) \leq \beta$  with two constants, the author was able to handle the case  $\alpha(x) \leq \rho(x) \leq \beta(x)$ . He also discusses the case where the function  $\theta(x)$  is not assumed to be non-negative. He is also able to replace the "mass condition"  $\int_{\Omega} \rho(x) \, dx = c$  by a more general one of the type  $\int_{\Omega} f(\rho(x)) \, dx = c$  with f convex and increasing. At last, he also shows that conditions (9.39) and (9.40) are, in some sense, necessary to get a bang-bang maximizer.

## Chapter 10

# Optimal conductivity

#### 10.1 Introduction

In this chapter, we are interested in an eigenvalue problem of the kind:

$$\begin{cases}
-\operatorname{div}(\sigma(x)\nabla u) = \lambda(\sigma)u & \text{in } \Omega, \\
u = 0 & \text{on } \partial\Omega,
\end{cases}$$
(10.1)

where  $\sigma$  is now the unknown. We assume  $\sigma$  to be positive and bounded in  $\Omega$  (see below for more precise assumptions). The case where  $\sigma$  possibly vanishes is considered in section 10.2.3. Each eigenvalue can also be characterized by the usual min-max formulae:

$$\lambda_1(\sigma) = \min_{y \in H_0^1(\Omega), y \neq 0} \frac{\int_{\Omega} \sigma(x) |\nabla y(x)|^2 dx}{\int_{\Omega} y(x)^2 dx}$$
(10.2)

and

$$\lambda_{k}(\sigma) = \min_{\substack{E_{k} \subset H_{0}^{1}(\Omega), \\ \text{subspace of dim } k}} \max_{y \in E_{k}, y \neq 0} \frac{\int_{\Omega} \sigma(x) |\nabla y(x)|^{2} dx}{\int_{\Omega} y(x)^{2} dx}.$$
 (10.3)

As first easy properties of  $\lambda_k(\sigma)$ , we can state

**Theorem 10.1.1.** The map  $\sigma \mapsto \lambda_k(\sigma)$  is concave, continuous for the convergence a.e. and upper-semi continuous for the weak-\* topology.

*Proof.* Concavity is clear as infimum of affine functions, the continuity result follows from Theorem 2.3.3 and the upper-semi continuity is due to the fact that  $\lambda_k(\sigma)$  is an infimum of functions which are continuous for the weak-\* topology.

Let us remark that  $\sigma \mapsto \lambda_k(\sigma)$  is **not** continuous for the weak-\* topology according to Theorem 2.3.6. It is also obvious that  $\sigma \mapsto \lambda_k(\sigma)$  is increasing:  $\sigma_1 \leq \sigma_2 \Rightarrow \lambda_1(\sigma_1) \leq \lambda_1(\sigma_2)$ . It follows immediately that minimization or maximization problems for  $\lambda_k(\sigma)$  in a class like

$$\mathcal{A} := \{ \sigma \in L^{\infty}(\Omega); \alpha \leq \sigma(x) \leq \beta \text{ a.e. in } \Omega \}$$

has no interest since the obvious solution would be  $\sigma(x) \equiv \alpha$  or  $\sigma(x) \equiv \beta$ . Therefore, we will generally consider here minimization or maximization problems for  $\lambda_k(\sigma)$  in the class

$$\mathcal{A}_{\alpha,\beta,p,c} := \{ \sigma \in L^{\infty}(\Omega); 0 < \alpha \le \sigma(x) \le \beta \text{ a.e. in } \Omega; \int_{\Omega} \sigma^{p}(x) dx = c \} \quad (10.4)$$

where p > 0 and c are given.

In section 10.2, we investigate the one-dimensional case for which we are able to give complete results. One of the tricks is to do a change of variable which allows us to transfer the variable into the lower-order term. Then, we can apply results of chapter 9. In section 10.3, we study the maximization problem of  $\lambda_k$  in general dimension. For a similar analysis, but with the energy instead of the eigenvalues, we refer to [51]. For the minimization problem, existence, in general, does not hold and one must consider the framework of homogenization theory.

#### 10.2 The one-dimensional case

We consider here the one-dimensional interval  $\Omega = (0, L)$  and we are interested in the eigenvalue problem

$$\begin{cases} -\frac{d}{dx}\left(\sigma(x)\frac{du}{dx}\right) = \lambda(\sigma)u \text{ in } \Omega = (0, L), \\ u(0) = u(L) = 0. \end{cases}$$
 (10.5)

#### 10.2.1 A general existence result

In one dimension, one can give a general existence result without dealing with homogenization theory.

**Theorem 10.2.1.** Let  $\Omega = (0, L)$  and  $\mathcal{A}_{\alpha,\beta,p,c}$  be the class of functions defined in (10.4). Let  $F : \mathbb{R}^k \to \mathbb{R}$  be a continuous function, increasing in each of its arguments. Then, the problem

$$\max_{\sigma \in \mathcal{A}_{\alpha,\beta,p,c}} F(\lambda_1(\sigma), \lambda_2(\sigma), \dots, \lambda_k(\sigma))$$

has a solution.

Proof. We use the standard method of calculus of variations. Let  $\sigma_n$  be a maximizing sequence in the class  $\mathcal{A}_{\alpha,\beta,p,c}$ . Since  $1/\sigma_n$  is uniformly bounded in  $L^{\infty}(\Omega)$ , we can extract a subsequence such that  $1/\sigma_n$  converges weakly-\* to some function denoted  $1/\sigma$  and satisfying  $1/\beta \leq 1/\sigma(x) \leq 1/\alpha$ . According to Theorem 2.3.6,  $\lambda_k(\sigma_n) \to \lambda_k(\sigma)$ . It remains to prove that the integral constraint is satisfied by the function  $\sigma$ . For that we use Theorem 1.1 in [71]. Let us consider the convex real function  $f(t) = t^{-p}$ . We have that  $\varphi \mapsto \int_0^L f(\varphi(x)) dx$  is weak-\* lower semi-continuous on  $L^{\infty}(\Omega)$ . Therefore

$$\int_0^L \sigma^p(x) \, dx = \int_0^L f(\sigma^{-1}) \, dx \le \liminf \int_0^L f(\sigma_n^{-1}) \, dx = \int_0^L \sigma_n^p(x) \, dx = c.$$
(10.6)

But since the function  $\sigma \mapsto F(\lambda_1(\sigma), \lambda_2(\sigma), \dots, \lambda_k(\sigma))$  is increasing with respect to  $\sigma$ , we see that we necessarily have equality in (10.6).

#### **10.2.2** Minimization or maximization of $\lambda_k(\sigma)$

We want to look for functions  $\sigma$  which minimize or maximize the first eigenvalue  $\lambda_1(\sigma)$  of (10.5). In the case of Dirichlet boundary conditions, we are able to give the exact minimizers and maximizers, thanks to a change of variable together with Krein's Theorems 9.3.1 and 9.3.3.

**Theorem 10.2.2.** (i) The (unique) minimizer of  $\lambda_1(\sigma)$  in the class  $\mathcal{A}_{\alpha,\beta,p,c}$  defined in (10.4) is the function  $\sigma_1(x)$  defined by

$$\sigma_1(x) = \begin{cases} \alpha & for & x \in (0, \frac{L}{2} - \delta), \\ \beta & for & x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\ \alpha & for & x \in (\frac{L}{2} + \delta, L), \end{cases}$$
(10.7)

where  $\delta = (c - \alpha^p L)/2(\beta^p - \alpha^p)$ .

(ii) The (unique) maximizer of  $\lambda_1(\sigma)$  in the class  $\mathcal{A}_{\alpha,\beta,p,c}(\Omega)$  is the function  $\sigma^1(x)$  defined by

$$\sigma^{1}(x) = \begin{cases} \beta & for & x \in (0, \frac{L}{2} - \delta), \\ \alpha & for & x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\ \beta & for & x \in (\frac{L}{2} + \delta, L), \end{cases}$$
(10.8)

where 
$$\delta = (\beta^p L - c)/2(\beta^p - \alpha^p)$$
.

*Proof.* We follow the same idea as in [64]: a simple change of variable allows us to transfer the variable into the lower-order term. Let  $(u, \lambda)$  be an eigenfunction and an eigenvalue of (10.5) associated to a function  $\sigma$  belonging to the class  $\mathcal{A}_{\alpha,\beta,p,c}(\Omega)$ . Since  $\sigma > 0$  in (0, L), the function  $x \mapsto \int_0^x \frac{dt}{\sigma(t)}$  is increasing. So, we can introduce the change of variable and the new function

$$y = \int_0^x \frac{dt}{\sigma(t)} \quad \text{and} \quad v(y) = u(x).$$
 (10.9)

Let us denote by  $L_1$  the maximum value attained by y:  $L_1 = \int_0^L \frac{dt}{\sigma(t)}$ . We also denote by x(y) the inverse function of  $x \mapsto y(x)$  which is defined on  $[0, L_1]$ . From  $\frac{dy}{dx} = 1/\sigma(x)$ , we immediately obtain that v satisfies

$$\begin{cases} -\frac{d^2}{dy^2} v = \lambda \, \sigma(x(y)) \, v(y) \text{ in } \Omega_1 = (0, L_1), \\ u(0) = u(L_1) = 0. \end{cases}$$
 (10.10)

Let us introduce the function  $\rho(y) = \sigma(x(y))$ . This function satisfies

$$\alpha \le \rho(y) \le \beta \tag{10.11}$$

and the integral condition

$$\int_0^{L_1} \rho(y) \, dy = \int_0^L \frac{\sigma(x) \, dx}{\sigma(x)} = L.$$
 (10.12)

From (10.10), (10.11), (10.12) we see from Theorems 9.3.1 and 9.3.3 that  $\lambda_1$  is minimum (resp. maximum) if  $\rho(y)$  is the step function defined by (9.24) (resp. (9.26)).

We want now to prove that the optimal  $\sigma$  has to be symmetric with respect to L/2. In the case of a maximization problem, we can use the concavity of  $\sigma \mapsto \lambda_1(\sigma)$ . Indeed, let us denote by

$$\sigma_s(x) := \sigma(L - x)$$

the function which is symmetric to it. Obviously,

$$\lambda_1(\sigma_s) = \lambda_1(\sigma)$$

and  $\sigma^* := (\sigma + \sigma_s)/2$  is symmetric w.r.t. L/2. By concavity of  $\sigma \mapsto \lambda_1(\sigma)$ , we get

$$\lambda_1(\sigma^*) = \lambda_1((\sigma + \sigma_s)/2) \ge \frac{1}{2}(\lambda_1(\sigma) + \lambda_1(\sigma_s)) = \lambda_1(\sigma).$$

In the minimization case, we use another argument. Since  $\sigma(x(y)) = \rho(y)$  is the step function defined by (9.24), there exists  $x_1 < x_2$  such that  $\sigma(x) = \alpha$  for  $0 < x < x_1, x_2 < x < L$  and  $\sigma(x) = \beta$  for  $x_1 < x < x_2$ . So, it is easy to deduce from (10.9) that

$$y(x) = \begin{cases} x/\alpha & \text{for } 0 < x < x_1, \\ x_1/\alpha + (x - x_1)/\beta & \text{for } x_1 < x < x_2, \\ x_1/\alpha + (x_2 - x_1)/\beta + (x - x_2)/\alpha & \text{for } x_2 < x < L. \end{cases}$$
(10.13)

Now expressing that  $y(x_1)$  (resp.  $y(x_2)$ ) must coincide with  $(L_1 - \delta_1)/2$  (resp  $(L_1 + \delta_1)/2$ ) which are the two discontinuity points of  $\rho(y)$ , we get immediately  $\delta_1 = (x_2 - x_1)/\beta$  and  $x_1 + x_2 = L$ . This last equality shows that  $\sigma$  has to be symmetric with respect to L/2. At last, expressing the constraint  $\int_0^L \sigma^p(x) dx = c$ , we get formulae (10.7) and (10.8).

One can state exactly the same theorem in the case of the k-th eigenvalue. For example, the minimizer of  $\lambda_k(\sigma)$  in the class  $\mathcal{A}_{\alpha,\beta,p,c}(\Omega)$  will be the function  $\sigma_k(x)$  which is L/k-periodic and which is defined on each interval (jL/k,(j+1)L/k),  $j=0,\ldots,k-1$  by

$$\sigma_k(x) = \sigma_1 (kx - jL)$$

with  $\sigma_1$  defined in (10.7). We leave the details to the reader.

Remark 10.2.3. One cannot completely relax the assumption  $0 < \alpha \le \sigma(x)$ . For example, the minimization and maximization problem is studied in chapter 5 of [83] in the class  $\mathcal{A}_p := \{\sigma \in L^{\infty}(\Omega); 0 < \sigma(x); \int_0^L \sigma^p(x) dx = 1\}$ . For example, their Theorem 25 shows that there are no minimizers in this class.

#### 10.2.3 Case of Neumann boundary conditions

In this section, we study the eigenvalue problem (10.5) but with Neumann boundary conditions. Of course, the first eigenvalue is zero, so we are interested in the second one  $\mu_2(\sigma)$ . This problem has been studied by B.A. Troesch in [203] who was interested in the sloshing of liquids in a container. For that purpose, he considers functions  $\sigma(x)$  satisfying the constraint  $\int_0^L \sigma(x) dx = c$ . He assumes  $\sigma(x) > 0$  inside the interval I = (0, L), but the novelty here is that  $\sigma$  is allowed to vanish at its extremities. Therefore, the operator  $-\frac{d}{dx}(\sigma(x)\frac{du}{dx})$  is not uniformly elliptic and the existence of eigenvalues and eigenfunctions does not follow in a classical way using Theorem 1.2.2 (see Remark 1.2.3). So, let us first give conditions on  $\sigma(x)$  in order that the eigenvalue problem is well posed.

**Theorem 10.2.4.** Let  $I = (0, L) \subset \mathbb{R}$  be a (non-empty) finite interval and  $\sigma(x)$  a function satisfying:

- 1.  $\sigma \in L^{\infty}(0,L)$ ,
- 2. there exists k > 0 and p > 0 such that  $\sigma(x) \ge k (x(L-x))^p$  for a.e. 0 < x < L.

Then, the operator  $-\frac{d}{dx}(\sigma(x)\frac{du}{dx})$  possesses a sequence of eigenvalues and eigenfunctions (as in the classical case) as soon as

- p < 1 in the case of Dirichlet boundary conditions,
- p < 2 in the case of Neumann boundary conditions.

*Proof.* We are going to use an integral representation of the inverse of the operator  $-\frac{d}{dx}\left(\sigma(x)\frac{du}{dx}\right)$  as in [66]. Actually, this integral representation is given thanks to the Green function which can be found explicitly in the one-dimensional case. We begin with the case of Dirichlet boundary conditions: it is easy to check that, in this case, the solution of  $-\frac{d}{dx}\left(\sigma(x)\frac{du}{dx}\right)=f$  is given by

$$u(x) = \int_0^L g(x,y)f(y) dy \quad \text{with } g(x,y) = \frac{\int_0^{\min(x,y)} \frac{dt}{\sigma(t)} \int_{\max(x,y)}^L \frac{dt}{\sigma(t)}}{\int_0^L \frac{dt}{\sigma(t)}}. \quad (10.14)$$

We first observe that the kernel g(x,y) is well defined if  $\sigma(x) \geq k \left(x(L-x)\right)^p$  with p < 1. Moreover, the integral operator defined by (10.14) is a Hilbert-Schmidt operator (and then is compact) if the kernel g(x,y) belongs to  $L^2(I \times I)$ . In this case, Theorem 1.2.1 applies and shows existence of eigenvalues and eigenfunctions. So, to prove the theorem it suffices to show that  $g(x,y) \in L^2(I \times I)$ . We use symmetry of the kernel g:

$$\begin{split} &\int_0^L \int_0^L g(x,y)^2 \, dx dy = 2 \int_0^L \int_0^x g(x,y)^2 \, dx dy \\ &= 2 \int_0^L \left\{ \left( \int_x^L \frac{dt}{\sigma(t)} \right)^2 \int_0^x \left( \int_0^y \frac{dt}{\sigma(t)} \right)^2 \, dy \right\} dx \left/ \left( \int_0^L \frac{dt}{\sigma(t)} \right)^2 \, . \end{split}$$

Now to prove that the previous integral is finite, it is better to write the condition on the function  $\sigma$  slightly differently:

$$\sigma(x) \ge k_1 x^p$$
 for  $x \in (0, L/2)$  and  $\sigma(x) \ge k_2 (L-x)^p$  for  $x \in (L/2, L)$ .

A straightforward computation gives (where c, c', c'' are some constants):

$$\int_0^L \int_0^L g(x,y)^2 dx dy \le c \left( \int_0^{L/2} \left[ \int_{L/2}^L \frac{dt}{\sigma(t)} + \frac{1}{k_1} \left( (L/2)^{1-p} - x^{1-p} \right) \right]^2 x^{3-2p} dx + \int_{L/2}^L (L-x)^{2-2p} \left[ c' + \int_{L/2}^x (c'' + (L-y)^{1-p})^2 dy \right] dx \right).$$

It is easy to convince oneself that the right-hand side of the above inequality is finite if p < 1.

For the Neumann case, the procedure is exactly the same. Now, the inverse of the operator  $-\frac{d}{dx}\left(\sigma(x)\frac{du}{dx}\right)$  with the boundary conditions  $\sigma u'(0)=\sigma u'(L)=0$  is given by the integral representation:

$$u(x) = \int_0^L g(x, y) f(y) \, dy \quad \text{with } g(x, y) = \int_0^{\min(x, y)} \frac{t dt}{\sigma(t)} + \int_{\max(x, y)}^L \frac{(L - t) dt}{\sigma(t)} \, . \tag{10.15}$$

Actually, the map  $f \mapsto u$  is well defined only for those f satisfying  $\int_0^L f(x)dx = 0$ , but it suffices to consider the quotient by constants to get a one-to-one operator. We see on the formula giving the kernel g that it is well defined as soon as p < 2. Finally, a simple calculation also shows that g(x,y) belongs to  $L^2(I \times I)$  under the same condition on p.

**Theorem 10.2.5 (Troesch).** Let I = (0, L),  $c \in \mathbb{R}_+$  and  $A_c$  be the class of functions defined by

$$\mathcal{A}_c := \{ \sigma \in L^{\infty}(\Omega); \ \sigma \ satisfies \ (10.16); \ \int_0^L \sigma(x) \ dx = c \},$$

$$\exists k > 0, \ p < 2 \ such that \ \sigma(x) \ge k (x(L-x))^p \ for \ a.e. \ 0 < x < L \ .$$
 (10.16)

Let  $\mu_2(\sigma)$  denote the second eigenvalue of  $-\frac{d}{dx}(\sigma(x)\frac{du}{dx})$  with Neumann boundary conditions. Then, the function  $\sigma^*(x) := \frac{6c}{L^3}x(L-x)$  is the unique minimizer of  $\mu_2(\sigma)$  in the class  $\mathcal{A}_c$ .

*Proof.* First, observe that the function  $\sigma^*$  belongs to the class  $\mathcal{A}_c$ . Now, let  $\sigma$  be any function in  $\mathcal{A}_c$  and take the test function x - L/2 (which has mean value zero and therefore is admissible) in the variational characterization of  $\mu_2$ :

$$\mu_2(\sigma) = \min_{\begin{subarray}{c} v \in H^1(I), v \neq 0 \\ \int_0^L v(x) \, dx = 0 \end{subarray}} \frac{\int_0^L \sigma(x) v'(x)^2 \, dx}{\int_0^L v(x)^2 \, dx} \le \frac{\int_0^L \sigma(x) \, dx}{\int_0^L (x - L/2)^2 \, dx} = \frac{12c}{L^3}.$$

(10.17)

Moreover, equality holds in (10.17) only if the test function v(x) = x - L/2 is the eigenfunction associated to  $\sigma$ . Now,  $\sigma = \sigma^*$  is precisely the function  $\sigma$  for which the second Neumann eigenfunction is u(x) = x - L/2 (the Neumann boundary conditions are satisfied here since  $\sigma$  vanishes at the extremities of the interval). Therefore, the theorem is proved.

Remark 10.2.6. The previous result has been generalized by C. Bandle in [20] to the nonlinear constraint  $\int_0^L \sigma^p(x) \, dx = c$ ,  $p \ge 1$  and with possible lower and upper bound on  $\sigma$ . Other constraints can also be considered. J.F. Kuzanek in [134] looks at functions  $\sigma$  satisfying  $\int_0^L \sqrt{1 + {\sigma'}^2} \, dx = const$ .

#### 10.3 The general case

#### 10.3.1 The maximization problem

Let us begin with a first existence result. Since the class

$$\mathcal{A} := \{ \sigma \in L^{\infty}(\Omega); 0 < \alpha \le \sigma(x) \le \beta \text{ a.e. in } \Omega; \int_{\Omega} \sigma(x) \, dx = c \}$$
 (10.18)

is compact for the weak-\* topology on  $L^{\infty}(\Omega)$ , an immediate consequence of Theorem 10.1.1 yields

**Theorem 10.3.1.** Let A be the class defined in (10.18); then, for any k, the problem

$$\max_{\sigma \in \mathcal{A}_{\alpha,\beta,1,c}} \lambda_k(\sigma)$$

has a solution.

Let us denote by  $\sigma^*$  a solution of the maximization problem as given by the previous theorem. We want to write down the optimality conditions. For that purpose, let us assume that  $\lambda_k(\sigma^*)$  is simple (this is certainly the case for example for  $\lambda_1$ ). We recall (see Theorem 2.5.15 and Remark 2.5.16) that  $\sigma \mapsto \lambda_k(\sigma)$  is differentiable with its derivative at  $\sigma^*$  given by

$$\langle d\lambda_k(\sigma^*), h \rangle = \int_{\Omega} h(x) |\nabla u_k(x)|^2 dx$$
 (10.19)

where  $u_k$  is the associated eigenfunction normalized by  $\int_{\Omega} u_k(x)^2 dx = 1$ . Let us now introduce the three following subsets of  $\Omega$ :

$$\begin{cases}
\Omega_0 = \{x \in \Omega, \ \sigma^*(x) = \alpha\}, \\
\Omega^* = \{x \in \Omega, \ \alpha < \sigma^*(x) < \beta\}, \\
\Omega_1 = \{x \in \Omega, \ \sigma^*(x) = \beta\}.
\end{cases} (10.20)$$

Of course, these subsets are only defined up to a set of zero measure since  $\sigma^*$  is only in  $L^{\infty}(\Omega)$ . So, the above equalities and inequalities are to be understood a.e. Since we try to write the optimality conditions satisfied by  $\sigma^*$ , we need to characterize the tangent cone  $T'(\sigma^*)$  to  $\mathcal{A}$  at point  $\sigma^*$  in  $L^{\infty}(\Omega)$ . Let us recall that it is defined as follows: an element  $h \in T'(\sigma^*)$  if, for any sequence  $t_n$  decreasing to 0, there exists a sequence  $h_n \in L^{\infty}(\Omega)$  converging (uniformly) to h such that, for any n,  $\sigma^* + t_n h_n \in \mathcal{A}$ .

**Lemma 10.3.2.** The tangent cone  $T'(\sigma^*)$  to the convex set  $\mathcal{A}$  at point  $\sigma^*$  is the set of functions h in  $L^{\infty}(\Omega)$  such that

(i) 
$$\int_{\Omega} h(x) dx = 0$$
,

- (ii)  $\|\chi_{Q_n^{\alpha}}h^-\|_{\infty} \to 0$  when  $n \to \infty$ , where  $Q_n^{\alpha} = \{x \in \Omega, \ \sigma^*(x) \le \alpha + 1/n\}$ ,
- (iii)  $\|\chi_{Q_n^{\beta}}h^+\|_{\infty} \to 0$  when  $n \to \infty$ , where  $Q_n^{\beta} = \{x \in \Omega, \ \sigma^*(x) \ge \beta 1/n\}$ .

For the proof, we refer to [31] or [57]. Let us observe that the condition

$$h(x) \ge 0 \text{ in } \Omega_0 \text{ and } h(x) \le 1 \text{ in } \Omega_1, \ \int_{\Omega} h = 0,$$
 (10.21)

is clearly necessary for an element h to belong to the tangent cone  $T'(\sigma^*)$ , but it is not sufficient, see above references or [104].

Therefore, the optimality condition of the first order is written

$$\forall h \in T'(\sigma^*), < d\lambda_k(\sigma^*), h > = \int_{\Omega} h |\nabla u_k^*|^2 dx \le 0.$$
 (10.22)

Since  $\sigma \mapsto \lambda_k(\sigma)$  is concave, the necessary optimality condition is also a sufficient one and (10.22) is therefore a characterization of the maxima of  $\lambda_k$ . Let us make explicit this characterization in terms of the sets  $\Omega_0$ ,  $\Omega^*$  and  $\Omega_1$  that we have introduced.

**Theorem 10.3.3.** Let  $\sigma^* \in \mathcal{A}$  and let us assume that the eigenvalue  $\lambda_k(\sigma^*)$  is simple. Let  $u_k^*$  be the corresponding (normalized) eigenfunction. Let  $\Omega_0$ ,  $\Omega_1$ ,  $\Omega^*$  be defined in (10.20). Then,  $\sigma^*$  is a maximizer of  $\lambda_k(\sigma)$  if and only if:

- (i)  $|\nabla u_k^*|$  is constant on  $\Omega^*$ .
- (ii)  $\forall (x_0, x^*, x_1) \in \Omega_0 \times \Omega^* \times \Omega_1$ , we have  $|\nabla u_k^*(x_0)| \leq |\nabla u_k^*(x^*)| \leq |\nabla u_k^*(x_1)|$ . In the sequel, we will denote by  $c^*$  the value taken by  $|\nabla u_k^*|$  on  $\Omega^*$ .

*Proof.* Let us first assume that  $\sigma^*$  is a maximizer of  $\lambda_k(\sigma)$  and let us introduce

$$\Omega_n^* = \{ x \in \Omega, \ 1/n \le \sigma^* \le 1 - 1/n \}.$$

We want to show that  $|\nabla u_k^*|$  is constant on  $\Omega_n^*$ . Since  $\Omega^* = \bigcup_{n>0} \Omega_n^*$  it will prove

(i). Let us assume, for a contradiction, that  $|\nabla u_k^*|$  is not constant on  $\Omega_n^*$ . It is therefore possible to find two measurable subsets  $\omega_1$  and  $\omega_2$  in  $\Omega_n^*$  such that

$$|\omega_1| = |\omega_2| \text{ and } \int_{\omega_1} |\nabla u_k^*|^2 dx < \int_{\omega_2} |\nabla u_k^*|^2 dx.$$
 (10.23)

Let us now choose h defined by

$$h(x) = \begin{cases} -1 & \text{in } \omega_1, \\ +1 & \text{in } \omega_2, \\ 0 & \text{elsewhere.} \end{cases}$$

Using Lemma 10.3.2, we see that h belongs to the tangent cone  $T'(\sigma^*)$ , but thanks to (10.23), we have

$$< d\lambda_k(\sigma^*), h> = \int_{\Omega} h |\nabla u_k^*|^2 dx = \int_{\omega_2} |\nabla u_k^*|^2 dx - \int_{\omega_1} |\nabla u_k^*|^2 dx > 0$$

contradicting the optimality condition (10.22).

(ii) is proved in a similar way, assuming that there exists a set of positive measure, say  $\omega_0$  in  $\Omega_0$  such that

$$|\nabla u_k^*|_{/\omega_0} > |\nabla u_k^*|_{/\Omega^*} = c^*.$$

We choose then  $\omega^*$  in  $\Omega_n^*$ , with  $|\omega_0| = |\omega^*|$  and we conclude using a function h which satisfies h = 1 in  $\omega_0$ , h = -1 in  $\omega^*$ .

Conversely, let us assume that the couple  $(\sigma^*, u_k^*)$  satisfies (i) and (ii) of the theorem. Let h be in the tangent cone  $T'(\sigma^*)$ . According to (10.21), h is nonnegative on  $\Omega_0$  and non-positive on  $\Omega_1$ , and so

$$\int_{\Omega} h |\nabla u_k^*|^2 dx = \int_{\Omega_0} h |\nabla u_k^*|^2 dx + \int_{\Omega^*} h |\nabla u_k^*|^2 dx + \int_{\Omega_1} h |\nabla u_k^*|^2 dx$$

$$\leq \int_{\Omega_0} h c^{*2} + \int_{\Omega^*} h c^{*2} + \int_{\Omega_1} h c^{*2} = c^{*2} \int_{\Omega} h = 0.$$

Consequently,  $\sigma^*$  satisfies the optimality condition (10.22) and, by concavity of  $\sigma \mapsto \lambda_k(\sigma)$  it is a maximizer of  $\lambda_k$ .

Remark 10.3.4. In general, we cannot prove uniqueness of the maximizer. Nevertheless, for the first eigenvalue, we can prove uniqueness of the eigenfunction! Indeed, let us denote by  $\lambda_1^*$  the maximum value of  $\lambda_1(\sigma)$  and let us assume that there exist two maximizers  $\sigma_1$  and  $\sigma_2$ . Let us denote by  $u_1$  and  $u_2$  the associated eigenfunctions. It is clear that the function  $\sigma_2 - \sigma_1$  belongs to  $T'(\sigma_1)$ , therefore, according to (10.22),  $\int_{\Omega} \sigma_1 |\nabla u_2|^2 dx \leq \int_{\Omega} \sigma_2 |\nabla u_2|^2 dx$ . Therefore

$$\int_{\Omega} \sigma_{1} |\nabla(u_{1} - u_{2})|^{2} dx = \int_{\Omega} \sigma_{1} |\nabla u_{1}|^{2} dx - 2 \int_{\Omega} \sigma_{1} \nabla u_{1} \cdot \nabla u_{2} dx + \int_{\Omega} \sigma_{1} |\nabla u_{2}|^{2} dx 
\leq \lambda_{1}^{*} \int_{\Omega} u_{1}^{2} dx - 2\lambda_{1}^{*} \int_{\Omega} u_{1} u_{2} dx + \lambda_{1}^{*} \int_{\Omega} u_{2}^{2} dx = \lambda_{1}^{*} \int_{\Omega} (u_{1} - u_{2})^{2} dx,$$

which shows that  $u_1 - u_2$  (and then  $u_2$ ) is an eigenfunction associated to the pair  $(\sigma_1, \lambda_1^*)$ . In particular, since  $\lambda_1^*$  is simple, we get  $u_2 = u_1$ .

#### 10.3.2 The minimization problem

In general, the minimization problem has no solution. One needs to consider a relaxation of the problem to get a solution in a wider class. More precisely, the classical homogenization theory, see for example [154] or [142], tells us that we need to consider the minimization problem on the set

$$\mathcal{A}^* = \{ (\sigma, A^*); \ \sigma \in \mathcal{A}, \ A^* \in M_{\sigma}, \}$$

where

$$M_{\sigma} := \{G - \text{limits of } \sigma_n Id, \text{ with } \sigma_n \stackrel{*}{\rightharpoonup} \sigma\}$$
 (10.24)

and the G-convergence is defined by:

**Definition 10.3.5.** One says that the sequence of conductivity  $\sigma_n$  G-converges to a homogenized conductivity  $A^*$  (which is an  $N \times N$  matrix in general) if, for every  $f \in H^{-1}(\Omega)$ , the solution  $u_n$  of

$$\begin{cases}
-div(\sigma_n \nabla u_n) = f & \text{in } \Omega, \\
u_n = 0 & \text{on } \partial\Omega
\end{cases}$$
(10.25)

converges weakly in  $H_0^1(\Omega)$  to  $u^*$ , solution of

$$\begin{cases}
-div(A^*\nabla u^*) = f & \text{in } \Omega, \\
u^* = 0 & \text{on } \partial\Omega.
\end{cases}$$
(10.26)

In fact, in the set  $\mathcal{A}^*$ , one can prove existence of an optimal pair  $(\sigma^*, A^*)$  thanks to compactness properties of this set and continuity of eigenvalues with respect to G-convergence (this last point follows immediately using the same proof as Theorem 2.3.3). In [64], the authors write the optimality conditions in this framework.

## Chapter 11

# The bi-Laplacian operator

#### 11.1 Introduction

This chapter deals with the so-called *bi-Laplacian* operator  $\Delta^2 = \Delta \circ \Delta$ . This is a model of a fourth-order operator. It appears in various problems of linear elasticity, for example when looking at small displacements of a plate (whereas the Laplacian describes the behavior of a membrane). Let  $\Omega$  be a bounded Lipschitzian open set in  $\mathbb{R}^N$ . The two eigenvalue problems that we are considering here are:

The clamped plate eigenvalue problem:

$$\begin{cases} \Delta^2 u = \lambda(\Omega)u & \text{in } \Omega, \\ u = \frac{\partial u}{\partial n} = 0 & \text{on } \partial\Omega. \end{cases}$$
 (11.1)

The buckled plate eigenvalue problem:

$$\begin{cases}
-\Delta^2 u = \Lambda(\Omega)\Delta u & \text{in } \Omega, \\
u = \frac{\partial u}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(11.2)

In both cases, it has been conjectured that the ball is the domain which minimizes the first eigenvalue of problems (11.1) and (11.2) among open sets with a given volume. In the case of the clamped plate, this conjecture was proved by N. Nadirashvili for N=2 and M. Ashbaugh-R. Benguria for N=3. It is discussed in section 11.2. For the buckling of a plate, the problem is still open; some partial results are given in section 11.3. In the last section, some results about non-homogeneous plates are also discussed.

#### 11.2 The clamped plate

#### **11.2.1** History

For the clamped plate, the conjecture (that the disk minimizes the first eigenvalue) was enunciated by Lord Rayleigh in his book *The theory of sound*, see [179]. A

partial answer was given by P. Szegő in [195] where he proves the conjecture, thanks to a rearrangement argument, provided that the first eigenfunction u is non-negative. Unfortunately, we know nowadays that many domains do not fulfill this assumption, see e.g. [80], [210]. Later, G. Talenti in [200] was able to prove estimates like  $\lambda_1(\Omega) \geq c_N \lambda_1(\Omega^*)$  ( $\Omega^*$  is the ball of same volume as  $\Omega$ ) where  $c_N < 1$  is a constant depending only on the dimension N, for example  $c_2 = 0.978$ . Then, E. Mohr in [151], assuming existence and regularity of a minimizer was able to prove that this one has to be a disk. For that, he used the optimality conditions obtained thanks to domain derivative as described in section 2.5. At last, in 1992, N. Nadirashvili announced in [156] a proof of Rayleigh's conjecture in two dimensions. The full proof appears in [157]. It is based on the previous work of G. Talenti: it relies on a delicate rearrangement argument involving  $\Delta u$ on the sets where u is positive and then negative. Roughly speaking, his method consists in introducing several auxiliary constrained minimization problems like (11.23). Following this work, M. Ashbaugh and R. Benguria were able, in [15], to show another method of proof which generalizes Nadirashvili's result to the three dimensional case. Their technique is also a refinement of Talenti's method. Since it contains both cases N=2 and N=3, we choose to present this proof here.

#### 11.2.2 Notation and statement of the theorem

Let us recall that the first eigenvalue of problem (11.1) is also characterized by the min formulae:

$$\lambda_1(\Omega) = \min_{v \in H_0^2(\Omega), v \neq 0} \frac{\int_{\Omega} (\Delta v(x))^2 dx}{\int_{\Omega} v(x)^2 dx}$$
 (11.3)

where  $H_0^2(\Omega)$  denotes the closure of  $C^{\infty}$  functions compactly supported in  $\Omega$  into the Sobolev space  $H^2(\Omega)$  of functions in  $L^2(\Omega)$  whose first and second derivatives lie in  $L^2(\Omega)$ . In (11.3) the minimum is attained by the first eigenfunction that we will denote by u in all this section. We recall that, for general domains, the first eigenfunction is not necessarily positive. We will denote by  $u_+$  and  $u_-$  the positive and negative parts of u respectively defined by

$$u_{+} = \max(u, 0), \quad u_{-} = \max(-u, 0)$$

and we will call  $\Omega_+$  (resp.  $\Omega_-$ ) the support of  $u_+$  (resp.  $u_-$ ). At last, as in section 2.1, we will introduce,

- for any open set  $\omega$  let  $\omega^*$  be the ball of same volume as  $\omega$ ,
- for any function v defined on  $\omega$ , let  $v^*$  be the spherical decreasing rearrangement or Schwarz rearrangement of v.

Following [200], we will denote by L (resp. a, resp. b) the radius of the ball  $\Omega^*$  (resp.  $\Omega_+^*$ , resp.  $\Omega_-^*$ ). Of course, we have

$$a^N + b^N = L^N. (11.4)$$

As usual,  $B_R$  will denote the ball of radius R centered at the origin. Let us now state the main result of this section.

**Theorem 11.2.1 (Nadirashvili-Ashbaugh-Benguria).** In dimension N=2 and N=3, the ball minimizes the first eigenvalue of the clamped problem (11.1) among open sets of given volume.

#### 11.2.3 Proof of the Rayleigh conjecture in dimension N=2,3

We follow [15] and [200]. The function  $\Delta u$  is not necessarily positive in  $\Omega$ . We denote by  $(\Delta u)_+$  and  $(\Delta u)_-$  the positive and negative parts of  $\Delta u$  respectively. Now any s between 0 and  $|\Omega| = |\Omega^*|$  can be written  $s = C_N r^N$  where  $r \in [0, L]$  and  $C_N = \pi^{N/2}/\Gamma(N/2+1)$  is the volume of the unit ball in  $\mathbb{R}^N$ . We introduce the two radially symmetric functions

for 
$$s = C_N r^N \in [0, |\Omega|], \quad g(s) := (\Delta u)_+^*(r) - (\Delta u)_-^*(L - r),$$
 (11.5)

for 
$$s = C_N r^N \in [0, |\Omega|], \quad f(s) := -g(|\Omega| - s).$$
 (11.6)

Since  $(\Delta u)_+^*$  and  $(\Delta u)_-^*$  are decreasing functions, both functions f and g are decreasing functions of s. Moreover, since  $\int_{\Omega} \Delta u \, dx = \int_{\partial\Omega} \partial u / \partial n \, d\sigma = 0$ , we have that

$$\int_0^{|\Omega|} g(s) \, ds = \int_{\Omega^*} (\Delta u)_+^* \, dx - \int_{\Omega^*} (\Delta u)_-^* \, dx = \int_{\Omega} (\Delta u)_+ \, dx - \int_{\Omega} (\Delta u)_- \, dx = 0.$$
(11.7)

In the same way,  $\int_0^{|\Omega|} f(s) ds = 0$ . This in turn implies that  $\int_0^s g(t) dt \ge 0$  and  $\int_0^s f(t) dt \ge 0$  for all  $s \in [0, |\Omega|]$ .

Finally, let us define the two spherically symmetric functions v and w on  $\Omega^*$ :

$$v(x) := \frac{1}{N^2 C_N^{2/N}} \int_{C_N|x|^N}^{C_N a^N} s^{-2(N-1)/N} \left( \int_0^s f(t) \, dt \right) \, ds \tag{11.8}$$

and

$$w(x) := \frac{1}{N^2 C_N^{2/N}} \int_{C_N|x|^N}^{C_N b^N} s^{-2(N-1)/N} \left( \int_0^s g(t) \, dt \right) \, ds \,. \tag{11.9}$$

From the definition of v and w and the properties of f and g, we have (here r = |x|)

$$\begin{cases} v(x) \ge 0 & \text{for } 0 \le |x| \le a, \\ w(x) \ge 0 & \text{for } 0 \le |x| \le b, \\ v(a) = w(b) = 0, \\ \frac{\partial v}{\partial r}(0) = \frac{\partial v}{\partial r}(L) = 0, \\ \frac{\partial w}{\partial r}(0) = \frac{\partial w}{\partial r}(L) = 0. \end{cases}$$

$$(11.10)$$

Moreover, if we abuse notation and consider v and w as functions of the measure  $s = C_N |x|^N$ , (11.6) becomes

$$v(s) = -w(|\Omega| - s). (11.11)$$

Let us also remark that by computing  $\Delta v = \frac{\partial^2 v}{\partial r^2} + \frac{N-1}{r} \frac{\partial v}{\partial r}$ , we observe that

$$-\Delta v = f(C_N |x|^N) \text{ in } \Omega_+^*,$$
 (11.12)

with v=0 on  $\partial\Omega_+^*$  (i.e. v(a)=0). In the same way, w satisfies

$$-\Delta w = g(C_N|x|^N) \quad \text{in } \Omega_-^*, \tag{11.13}$$

with w=0 on  $\partial\Omega_-^*$  (i.e. w(b)=0). We assume that we extend v for  $|x|\geq a$  and w for  $|x|\geq b$  using (11.11). From equations (11.12), (11.13) and (11.6) it follows that

$$\Delta v(a) + \Delta w(b) = -(f(|\Omega_{+}^{*}|) + g(|\Omega_{-}^{*}|)) = -(f(|\Omega_{+}^{*}|) + g(|\Omega| - |\Omega_{+}^{*}|)) = 0.$$

Now, from  $\int_{0}^{|\Omega|} g(s) ds = 0$  (see (11.7) and (11.6)), we deduce

$$0 = \int_0^{|\Omega_-^*|} g(s) \, ds + \int_{|\Omega^*|}^{|\Omega^*|} g(s) \, ds = \int_0^{|\Omega_-^*|} g(s) \, ds - \int_0^{|\Omega_+^*|} f(s) \, ds$$

or

$$\int_{|x| \le a} f(C_N |x|^N) \, dx = \int_{|x| \le b} g(C_N |x|^N) \, dx$$

which in turn implies together with (11.12), (11.13)

$$\int_{|x| < a} \Delta v \, dx = \int_{|x| < b} \Delta w \, dx \,. \tag{11.14}$$

Green formulae applied to (11.14) finally yields

$$a^{N-1}\frac{\partial v}{\partial r}(a) = b^{N-1}\frac{\partial w}{\partial r}(b). \tag{11.15}$$

In [200], G. Talenti proved the following comparison theorem between the four radial functions  $u_{+}^{*}, v, u_{-}^{*}, w$ :

**Theorem 11.2.2 (Talenti).** Let  $u_+^*, v, u_-^*, w$  be defined as above. Then

$$u_+^* \le v \quad in \ \Omega_+^* \,, \tag{11.16}$$

$$u_{-}^{*} \leq w \quad in \ \Omega_{-}^{*} \,, \tag{11.17}$$

$$\int_{\Omega} (\Delta u)^2 \, dx = \int_{\Omega_+^*} (\Delta v)^2 \, dx + \int_{\Omega_-^*} (\Delta w)^2 \, dx \,, \tag{11.18}$$

$$\int_{\Omega} (\Delta u)^2 \, dx = \int_{|x| \le L} (\Delta v)^2 \, dx = \int_{|x| \le L} (\Delta w)^2 \, dx \,. \tag{11.19}$$

Let us go on to the proof of Theorem 11.2.1. By classical properties of rearrangement, see (2.1), we have

$$\int_{\Omega} u^2 dx = \int_{\Omega_+} u_+^2 dx + \int_{\Omega_-} u_-^2 dx = \int_{\Omega_+^*} (u_+^*)^2 dx + \int_{\Omega_-^*} (u_-^*)^2 dx.$$
 (11.20)

Equation (11.20) together with (11.16), (11.17) yields:

$$\int_{\Omega} u^2 \, dx \le \int_{\Omega_+^*} v^2 \, dx + \int_{\Omega_-^*} w^2 \, dx \tag{11.21}$$

which in turn, with (11.18) gives

$$\lambda_1(\Omega) = \frac{\int_{\Omega} (\Delta u(x))^2}{\int_{\Omega} u(x)^2 dx} \ge \frac{\int_{\Omega_+^*} (\Delta v)^2 dx + \int_{\Omega_-^*} (\Delta w)^2 dx}{\int_{\Omega_+^*} v^2 dx + \int_{\Omega_-^*} w^2 dx} . \tag{11.22}$$

Let us remark that if u has one sign then (11.22) and the variational characterization (11.3) of  $\lambda_1(\Omega^*)$  imply Rayleigh's conjecture. In this sense, as quoted by G. Talenti, this is another proof of P. Szegö's result, [195].

We now introduce a new minimization problem based upon the right-hand side of (11.22). For any fixed pair of numbers  $(\alpha, \beta)$  such that  $0 \le \alpha \le \beta \le L$  and  $\alpha^N + \beta^N = L^N$ , define

$$J_{\alpha,\beta} := \min_{\varphi,\psi} \frac{\int_{|x| \le \alpha} (\Delta\varphi)^2 dx + \int_{|x| \le \beta} (\Delta\psi)^2 dx}{\int_{|x| \le \alpha} \varphi^2 dx + \int_{|x| \le \beta} \psi^2 dx}$$
(11.23)

where the minimum is taken over all pairs of radial functions  $(\varphi, \psi)$ , where  $\varphi \in H^2(B_\alpha) \cap H^1_0(B_\alpha)$  and  $\psi \in H^2(B_\beta) \cap H^1_0(B_\beta)$  are such that

$$\alpha^{N-1} \frac{\partial \varphi}{\partial r} (\alpha) = \beta^{N-1} \frac{\partial \psi}{\partial r} (\beta)$$
 (11.24)

and where  $(\varphi, \psi)$  is non-trivial in the sense that the denominator in (11.23) does not vanish. We now state two lemmas.

**Lemma 11.2.3.** There exists a classical solution  $(\hat{\varphi}, \hat{\psi})$  of the minimization problem (11.23). Moreover, the minimizers satisfy

$$\begin{cases} \Delta^2 \hat{\varphi} = \mu \hat{\varphi} & \text{in } |x| \leq \alpha, \\ \Delta^2 \hat{\psi} = \mu \hat{\psi} & \text{in } |x| \leq \beta, \\ \hat{\varphi}(\alpha) = \hat{\psi}(\beta) = 0, \\ \alpha^{N-1} \frac{\partial \hat{\varphi}}{\partial r}(\alpha) = \beta^{N-1} \frac{\partial \hat{\psi}}{\partial r}(\beta), \\ \Delta \hat{\varphi}(a) + \Delta \hat{\psi}(b) = 0, \end{cases}$$

where the number  $\mu$  is precisely the minimal value  $J_{\alpha,\beta}$ .

**Lemma 11.2.4.** In dimension N=2 and N=3 the minimal value of  $J_{\alpha,\beta}$  (defined in (11.23)) for all pairs  $\alpha, \beta$  satisfying  $0 \le \alpha \le \beta \le L$  and  $\alpha^N + \beta^N = L^N$  is attained for  $\alpha, \beta = (0, L)$ .

From Lemma 11.2.4 and inequality (11.22), we deduce immediately

$$\lambda_1(\Omega) \ge J_{0,L} = \min_{\psi} \frac{\int_{|x| \le L} (\Delta \psi)^2 dx}{\int_{|x| < L} \psi^2 dx} = \lambda_1(\Omega^*)$$

which prove Rayleigh's conjecture.

For the proofs of the two lemmas, we refer the reader to [10]. The proof of Lemma 11.2.3 is easy using the classical method of calculus of variations. The proof of Lemma 11.2.4 is much more technical, it relies on fine properties of Bessel functions. Indeed, it is easy to see that the minimizers given by Lemma 11.2.3 are both of the kind

$$[AJ_{\nu}(kr) + BI_{\nu}(kr)]r^{-\nu}$$

where  $\nu = (N/2) - 1$  and  $k = \mu^{1/4}$ . Then it follows that the number  $k = \mu^{1/4}$  is a zero of the transcendental equation

$$f_{\nu}(ka) + f_{\nu}(kb) = 0$$

where 
$$f_{\nu}(x) := x^{N-1} \left[ \frac{J_{\nu+1}}{J_{\nu}} (x) + \frac{I_{\nu+1}}{I_{\nu}} (x) \right].$$

Remark 11.2.5. The fact that Lemma 11.2.4 holds only for N=2,3 comes from the inequality  $k_{\nu} \leq 2^{1/N} j_{\nu,1}$  (where  $k_{\nu}$  is the first positive zero of  $f_{\nu}$  and  $j_{\nu,1}$  the first positive zero of  $J_{\nu}$ ) which is necessary in the proof.

**Open problem 28.** Prove Rayleigh's conjecture for the first eigenvalue of the clamped problem in dimension  $N \geq 4$ .

#### 11.3 Buckling of a plate

#### 11.3.1 Introduction

Here we consider the eigenvalue problem (11.2) and more particularly its first eigenvalue  $\Lambda_1(\Omega)$ . As usual, this one can be characterized by the variational principle:

$$\Lambda_1(\Omega) = \min_{v \in H_0^2(\Omega), v \neq 0} \frac{\int_{\Omega} (\Delta v(x))^2}{\int_{\Omega} |\nabla v(x)|^2 dx}$$
(11.25)

where the Sobolev space  $H_0^2(\Omega)$  is defined as in (11.3). In (11.25) the minimum is attained by the first eigenfunction that will we denote by u in all this section. The following conjecture is due to G. Pólya and G. Szegő in [174]:

**Open problem 29 (P´olya-Szeg¨o).** Prove that the ball minimizes <sup>Λ</sup>1(Ω) among open sets of given volume.

Only partial results are known about this conjecture. G. Szeg¨o in [195], see also [174], was able to prove it in the case where the first eigenfunction does not change sign. We present, in section 11.3.2, his proof based on a rearrangement technique. Unfortunately, as for the case of the clamped plate, we know that this property of the first eigenfunction does not hold in general. If one cannot use rearrangement techniques, the other approach consists in the following three steps:

- 1. prove existence of a minimizer, say Ω,
- 2. prove that Ω is regular enough (for example C2,α) in order to be able to compute the derivative of the eigenvalue with respect to the domain (in the sense of section 2.5),
- 3. exploit the optimality conditions, which gives in general an overdetermined condition on the boundary of Ω, to prove that this one must be a ball.

Actually, for this problem of buckling of a plate, step 1 can be obtained in the spirit of Buttazzo-Dal Maso's Theorem 2.4.5 together with Theorem 5.3.1, see section 11.3.3 below. For step 3, we present in section 11.3.4 a successful and tricky approach due to N.B. Willms and H.F. Weinberger. They did not publish it, but one can find it in the paper of B. Kawohl in [123]. We reproduce it here since we believe that this piece of proof is very nice and worth being advertised.

Therefore to complete the proof of P´olya-Szeg¨o's conjecture, it remains to prove that the minimizer Ω is regular enough. Of course, it is a difficult question. Nevertheless, let us note that some progress in that type of regularity question for solutions of shape optimization problems have been recently obtained, see e.g. [37], [38].

#### **11.3.2 The case of a positive eigenfunction**

**Theorem 11.3.1 (G. Szeg¨o).** If Ω is a regular domain in R<sup>N</sup> such that the first eigenfunction of (11.2) does not change sign in <sup>Ω</sup>, then <sup>Λ</sup>1(Ω) <sup>≥</sup> <sup>Λ</sup>1(Ω∗) where Ω<sup>∗</sup> is the ball of same volume as Ω.

Proof. The proof follows the same idea as the classical proof of Theorem 3.2.1 by Faber and Krahn. Nevertheless, the rearrangement used is not Schwarz's rearrangement but a new one built for this purpose:

**Lemma 11.3.2.** Let u be a non-negative bounded function defined on Ω which vanishes on ∂Ω. Then, there exists a radially symmetric function u<sup>∗</sup> defined on Ω∗, rearrangement of u and satisfying

$$\int_{\Omega} (\Delta u(x))^2 dx = \int_{\Omega^*} (\Delta u_*(x))^2 dx,$$
(11.26)

$$\int_{\Omega} |\nabla u(x)|^2 \, dx \le \int_{\Omega^*} |\nabla u_*(x)|^2 \, dx,\tag{11.27}$$

$$\int_{\Omega} u(x)^2 dx = \int_{\Omega^*} u_*(x)^2 dx.$$
 (11.28)

Applying this lemma to u, the first eigenfunction of  $\Omega$ , by combining (11.26), (11.27) and the variational characterization of  $\Lambda_1(\Omega)$ , we get

$$\Lambda_1(\Omega) = \frac{\int_{\Omega} (\Delta u(x))^2}{\int_{\Omega} |\nabla u(x)|^2 dx} \ge \frac{\int_{\Omega}^* (\Delta u_*(x))^2}{\int_{\Omega}^* |\nabla u_*(x)|^2 dx} = \Lambda_1(\Omega^*)$$

which gives the desired result.

**Remark 11.3.3.** The construction of  $u_*$  is realized in the following way, see [174] for the two-dimensional case. Without loss of generality, we can assume  $0 \le u \le 1$ . For all  $\rho \in (0,1)$ , we introduce the sets

$$D_{\rho} := \{ x \in \Omega : 0 < u(x) < \rho \} \text{ and } S_{\rho} := \{ x \in \Omega : u(x) = \rho \}.$$

We denote by  $V(\rho) = |\{x \in \Omega : u(x) \ge \rho\}|$  the volume of the set  $\Omega \setminus D_{\rho}$ . The map  $\rho \mapsto V(\rho)$  is continuous, monotonically decreasing, a.e. differentiable.

Then, we set

$$Q(\rho) := \int_{S_{\rho}} (\Delta u)^2 \, d\sigma \,,$$

$$g(\rho) := \frac{|V'(\rho)|}{\gamma_N^2 V(\rho)} \, \int_0^\rho \sqrt{Q(t)|V'(t)|} \, dt$$

where  $\gamma_N$  is the constant, depending on the dimension, which occurs in the classical (geometric) isoperimetric inequality between surface area S and volume  $V: S \ge \gamma_N V^{(N-1)/N}$ . Finally, the rearrangement  $u_*$  is defined as

$$u_*(r) := \int_0^\rho g(t) \, dt$$

where r is the radius of the ball of volume  $V(\rho)$ . For example, if R denotes the radius of the ball  $\Omega^*$  (which corresponds to the volume V(0)), we have  $u_*(R) = 0$ .

**Remark 11.3.4.** As quoted above, using (11.26), (11.28) and the variational characterization of the first eigenvalue of the clamped plate (11.3), G. Szegö was able to prove, in [195], the Rayleigh conjecture under the same assumption about the first eigenfunction.

#### 11.3.3 An existence result

We begin with an existence result proved by M. Ashbaugh and D. Bucur in [16].

**Theorem 11.3.5 (Ashbaugh-Bucur).** There exists an open set  $\Omega^*$  minimizing the first eigenvalue of the buckling problem  $\Lambda_1(\Omega)$  among simply connected open sets of given measure.

For the proof, we refer to [16]. Actually, it has many similarities with the proof of Theorem 5.3.3. Indeed, one of the main arguments is the concentration-compactness property applied to the sequence of eigenfunctions associated to a minimizing sequence. Using this principle, one can prove that compactness must occur. The other important tool in the proof is to introduce a "relaxed" problem. Namely, instead of using the space  $H_0^2(\Omega)$  (which is defined as the closure of  $C^{\infty}$  functions compactly supported in  $\Omega$  into the Sobolev space  $H^2(\Omega)$ ) in the definition (11.25) of  $\Lambda_1(\Omega)$ , one can use the following Sobolev-like space (here D is any ball containing  $\Omega$ )

$$\widetilde{H}_0^2(\Omega) := \{ u \in H^2(D) \text{ such that } u \in H_0^1(\Omega), \frac{\partial u}{\partial x_i} \in H_0^1(\Omega) \}.$$
 (11.29)

When  $\Omega$  is regular (e.g. Lipschitz), this set  $\widetilde{H}_0^2(\Omega)$  coincides with  $H_0^2(\Omega)$ , but in some less regular cases (e.g.,  $\Omega$  is a disk where we remove a finite number of points), they could be different. Then, the "eigenvalue"  $\widetilde{\Lambda}_1(\Omega)$  is defined as in (11.25) with  $\widetilde{H}_0^2(\Omega)$  instead of  $H_0^2(\Omega)$ . The authors begin to prove existence of a minimizer for  $\widetilde{\Lambda}_1(\Omega)$  in the class of (quasi)-open sets of given measure and then come back to the general case for simply-connected open sets of given measure.

Let us also remark that, in this situation, one can also apply the general existence theorem due to G. Buttazzo and G. Dal Maso, see [50] which implies Theorem 2.4.5. Namely a domain functional J which is

- (i) non-increasing with respect to domain inclusion,
- (ii) lower-semi continuous for the  $\gamma$ -convergence (see Definition 2.3.9 and Theorem 2.3.10)

has a minimizer in the class  $\mathcal{A}_c = \{\Omega \subset D, \Omega \text{ quasi-open}, |\Omega| = c\}$ . First, it is clear from formulae (11.25) that  $\Omega \mapsto \widetilde{\Lambda}_1(\Omega)$  is non-increasing with respect to domain inclusion. Point (ii) requires a little more work. The  $\gamma$ -convergence of a sequence of sets  $\Omega_n$  to  $\Omega$  is equivalent to the Mosco convergence of the Sobolev spaces  $H_0^1(\Omega_n)$  to  $H_0^1(\Omega)$  (see Theorem 2.3.10). Now, let us prove that it implies the property (M2) of the Mosco convergence for the pseudo-Sobolev spaces  $\widetilde{H}_0^2(\Omega_n)$  and  $\widetilde{H}_0^2(\Omega)$ . Indeed, let  $v_n$  be a sequence of functions in  $\widetilde{H}_0^2(\Omega_n)$  which converges weakly to a function  $v \in \widetilde{H}_0^2(D)$ . By  $\gamma$ -convergence, (M2) is true for the spaces  $H_0^1$ , hence  $v \in H_0^1(\Omega)$ . In the same way,  $\frac{\partial v_n}{\partial x_i}$  belongs to  $H_0^1(\Omega_n)$  and converges weakly to  $\frac{\partial v}{\partial x_i}$ , therefore  $\frac{\partial v}{\partial x_i} \in H_0^1(\Omega)$ . Hence,  $v \in \widetilde{H}_0^2(\Omega)$ . Finally, according to Remark 2.3.12,

the property (M2) implies lower-semi continuity of the eigenvalues, which allows us to prove lower-semi continuity of  $\Omega \mapsto \widetilde{\Lambda}_1(\Omega)$  for the  $\gamma$ -convergence.

**Remark 11.3.6.** In [123], B. Kawohl gives another existence result, for a more general problem containing this one, but in the class of convex plane domains of prescribed area.

#### 11.3.4 The last step in the proof

**Theorem 11.3.7 (Weinberger-Willms).** Let  $\Omega$  be a minimizer of  $\Lambda_1(\Omega)$  (among plane domains of prescribed area) given by Theorem 11.3.5. Assume that  $\Omega$  is  $C^{2,\alpha}$  for some  $\alpha > 0$ . Then  $\Omega$  is a disk.

For the proof, we first write the optimality conditions. Since  $\Omega$  is regular, we can differentiate  $\Omega \mapsto \Lambda_1(\Omega)$  with respect to the domain in the sense of section 2.5.

**Lemma 11.3.8.** Let  $\Omega$  be a bounded open set of class  $C^{2,\alpha}$ . We denote  $\Omega_t = \Phi(t)(\Omega)$  where  $\Phi$  is a  $C^2$  diffeomorphism defined by (2.37). Then, the function  $t \to \Lambda_1(t) = \Lambda_1(\Omega_t)$  is differentiable at t = 0 with a derivative given by

$$\Lambda_1'(\Omega) = -\int_{\partial\Omega} (\Delta u)^2 \ V.n \, d\sigma \tag{11.30}$$

where u is the first eigenfunction normalized by  $\int_{\Omega} |\nabla u(x)|^2 dx = 1$ .

In particular, if  $\Omega$  is a  $C^{2,\alpha}$  open set which minimizes  $\Lambda_1(\Omega)$  among open sets of prescribed area, its first eigenfunction satisfies

$$\Delta u = constant \ on \ \partial\Omega$$
. (11.31)

*Proof.* Following results of section 2.5, in particular Theorems 2.5.1 and 2.5.7, we can prove that the first eigenfunction is differentiable and that its derivative u' is a solution of (we refer to [104] for proofs, we just do a formal computation here)

$$\begin{cases}
\Delta^{2}u' + \Lambda_{1}\Delta u' + \Lambda'_{1}\Delta u = 0 & \text{in } \Omega, \\
u' = -\frac{\partial u}{\partial n}(V.n) & \text{on } \partial\Omega, \\
\frac{\partial u'}{\partial n} = -\frac{\partial^{2}u}{\partial n^{2}}V.n + \nabla u.\nabla_{\Gamma}(V.n) & \text{on } \partial\Omega.
\end{cases} (11.32)$$

Since the eigenfunction u verifies  $u = |\nabla u| = 0$  on  $\partial \Omega$ , the boundary conditions satisfied by u' are actually

$$u' = 0$$
 and  $\frac{\partial u'}{\partial n} = -\frac{\partial^2 u}{\partial n^2} V.n$  on  $\partial \Omega$ . (11.33)

Multiplying equation (11.32) by u and integrating by parts on  $\Omega$  yields

$$\int_{\Omega} \Delta u' \Delta u \, dx - \Lambda_1 \int_{\Omega} \nabla u' \cdot \nabla u \, dx = \Lambda_1' \int_{\Omega} |\nabla u(x)|^2 \, dx.$$
 (11.34)

In the same way, multiplying the eigenvalue equation (11.2) by u' and integrating by parts on  $\Omega$  yields

$$\int_{\partial\Omega} \left[ u' \frac{\partial(\Delta u)}{\partial n} - \Delta u \frac{\partial u'}{\partial n} \right] d\sigma + \int_{\Omega} \Delta u \Delta u' dx - \Lambda_1 \int_{\Omega} \nabla u \cdot \nabla u' dx = 0. \quad (11.35)$$

By using boundary conditions (11.33) and inserting (11.35) in (11.34), we finally get

$$\Lambda_1' \int_{\Omega} |\nabla u(x)|^2 dx = \int_{\partial \Omega} \Delta u \frac{\partial u'}{\partial n} d\sigma = -\int_{\partial \Omega} \Delta u \frac{\partial^2 u}{\partial n^2} d\sigma.$$
 (11.36)

Now, we use the classical decomposition of the Laplacian (valid on  $\partial\Omega$  for any  $C^2$  function)

$$\Delta u = \Delta_{\partial\Omega} u + H \frac{\partial u}{\partial n} + \frac{\partial^2 u}{\partial n^2}$$

where  $\Delta_{\partial\Omega}$  is the Laplace-Beltrami operator and H the mean curvature. Here, since u=0 and  $\frac{\partial u}{\partial n}=0$  on  $\partial\Omega$ , this relation reduces to  $\Delta u=\frac{\partial^2 u}{\partial n^2}$ . Formulae (11.30) follows immediately from (11.36) and the normalization of u.

Finally, formulae (11.31) comes, exactly as Corollary 2.5.4, from the existence of a Lagrange multiplier connecting the derivative of  $\Lambda_1$  with the derivative of the volume.

Proof of Theorem 11.3.7. We denote by c the constant on the right-hand side of (11.31). We now introduce the function  $z := \Delta u + \Lambda_1 u$ . From the equation (11.2) and the boundary conditions satisfied by u, z is a solution of

$$\Delta z = 0 \text{ in } \Omega, \quad z = c \text{ on } \partial \Omega.$$

so that  $z \equiv c$  by the maximum principle for harmonic functions. We can use the substitution  $v(x) = u(x) - c/\Lambda_1$  so that (11.2) and (11.31) are transformed into the overdetermined boundary value problem

$$\begin{cases}
\Delta v + \Lambda_1 v = 0 & \text{in } \Omega, \\
v = -\frac{c}{\Lambda_1} & \text{on } \partial\Omega, \\
\frac{\partial v}{\partial n} = 0 & \text{on } \partial\Omega.
\end{cases}$$
(11.37)

By translation of  $\Omega$  we can always assume that the origin O is contained in  $\Omega$ , and that v has a critical point at the origin. Then, we follow the same idea as for the proof of (iii) in Theorem 3.4.1 or Theorem 4.2.5 by introducing the function

$$w(x,y) := x \frac{\partial v}{\partial y} - y \frac{\partial v}{\partial x}.$$

This function w satisfies

$$\begin{cases}
\Delta w + \Lambda_1 w = 0 & \text{in } \Omega, \\
w = 0 & \text{on } \partial \Omega,
\end{cases}$$
(11.38)

so, either w = 0 or  $\Lambda_1 = \lambda_k$  is a Dirichlet eigenvalue of the Laplacian for  $\Omega$ . If w = 0, the result is proved since it is well known that it implies that u is radially symmetric in  $\Omega$ . So let us consider that we are in the other case. First w(O) = 0, and since

$$\frac{\partial w}{\partial x} = \frac{\partial v}{\partial y} + x \frac{\partial^2 v}{\partial x \partial y} - y \frac{\partial^2 v}{\partial x^2}$$

we also have  $\frac{\partial w}{\partial x}(O) = 0$  and similarly for  $\frac{\partial w}{\partial y}(O)$ . This implies that

- the origin lies on a nodal line of the eigenfunction w,
- (at least) two nodal lines intersect at the origin.

This is possible only if these nodal lines divide  $\Omega$  into at least three nodal domains. Of course, we can assume that one of these nodal domains, say  $\omega$ , has an area less than or equal to  $|\Omega|/3$ . Therefore, we have

$$\Lambda_1(\Omega) = \lambda_k(\Omega) = \lambda_1(\omega)$$
 (according to Proposition 1.3.3).

Now, by Faber-Krahn inequality,

$$\lambda_1(\omega) \ge \lambda_1(\omega^*).$$

Let us denote by  $D_a$  a disk of area a. By monotonicity of the Dirichlet eigenvalues, we have  $\lambda_1(\omega^*) \geq \lambda_1(D_{|\Omega|/3})$ . By (1.20),  $\lambda_1(D_{|\Omega|/3}) = 3\lambda_1(D_{|\Omega|})$ , so all previous equalities and inequalities give

$$\Lambda_1(\Omega) \ge 3\lambda_1(D_{|\Omega|}).$$

We use now the inequality between zeros of Bessel functions,  $3j_{0,1}^2 > j_{1,1}^2$  which yields  $3\lambda_1(D_{|\Omega|}) > \lambda_2(D_{|\Omega|})$ . At last, the well-known fact that the first eigenvalue  $\Lambda_1$  for a disk of radius R is given by  $j_{1,1}/R^2 = \lambda_2(D_{|\Omega|})$  shows that we finally get  $\Lambda_1(\Omega) > \Lambda_1(D_{|\Omega|})$  which contradicts the minimality of  $\Omega$ , so we were in the first case and the theorem is proved.

Remark 11.3.9. Note the fact that  $3\lambda_1 > \lambda_2$  is not specific to a disk. Actually, it is a consequence of the Ashbaugh-Benguria's Theorem 6.2.1 that the inequality  $2.539\lambda_1 > \lambda_2$  always holds where the number 2.539 is slightly larger than the ratio  $\lambda_2/\lambda_1 = j_{1,1}^2/j_{0,1}^2$  for a disk.

Remark 11.3.10. The over-determined problem (11.37) looks like the well-known Pompeiu problem which is still open. It consists in proving that a domain  $\Omega$  for which the problem

$$\begin{cases}
-\Delta v = \lambda_k v & \text{in } \Omega, \\
v = \text{constant} & \text{on } \partial \Omega, \\
\frac{\partial v}{\partial n} = 0 & \text{on } \partial \Omega
\end{cases}$$

has a solution is necessarily a disk (or a ball in higher dimension). For some references for this problem, see e.g. [215].

#### 11.4 Some other problems

#### 11.4.1 Non-homogeneous rod and plate

As we did in chapter 9 for the Laplacian, we can look at extremum problems for eigenvalues of  $\Delta^2 u = \lambda \rho u$  (with various boundary conditions), where  $\rho$  is a non-negative function subject to some supplementary constraints. Of course, the main known results are in one dimension for the case of a non-homogeneous rod. In that context, we will present here some results by D.O. Banks (see [21], [24]), B. Schwarz (see [185]) which are in some sense a generalization of Krein's Theorems 9.3.1 and 9.3.3. As in chapter 9, for any open set  $\Omega$  in  $\mathbb{R}^N$ , we introduce the class

$$\mathcal{A}_{\alpha,\beta,c}(\Omega) := \{ \rho \in L^{\infty}(\Omega); \alpha \leq \rho(x) \leq \beta \text{ a.e. in } \Omega, \ \int_{\Omega} \rho(x) \, dx = c \}$$
 (11.39)

where  $\alpha, \beta$  and c are three real numbers such that  $0 \le \alpha < \beta$  and  $\alpha |\Omega| \le c \le \beta |\Omega|$ . We begin by the result of minimization and maximization of the first eigenvalue of a clamped rod in dimension 1 ( $\Omega = (0, L)$ ). We also refer to chapter 6 of [83] for similar results with an  $L^p$  constraint on  $\rho$  of the kind  $\int_0^L \rho^p(x) dx = c$ .

**Theorem 11.4.1 (Banks, Beesack, Schwarz).** Let  $\Lambda_1(\rho)$  be the first eigenvalue of the problem

$$\begin{cases} u^{(4)} = \Lambda_1(\rho)\rho(x)u & \text{for } x \in (0, L), \\ u(0) = u'(0) = u(L) = u'(L) = 0. \end{cases}$$
 (11.40)

Then,

(i) the (unique) minimizer of  $\Lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  is the function  $\rho_1(x)$  defined by

$$\rho_1(x) = \begin{cases}
\alpha & for & x \in (0, \frac{L}{2} - \delta), \\
\beta & for & x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\
\alpha & for & x \in (\frac{L}{2} + \delta, L),
\end{cases}$$
(11.41)

where  $\delta = (c - \alpha L)/2(\beta - \alpha)$ .

(ii) The (unique) maximizer of  $\Lambda_1(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  is the function  $\rho^1(x)$  defined by

$$\rho^{1}(x) = \begin{cases} \beta & for & x \in (0, \frac{L}{2} - \delta), \\ \alpha & for & x \in (\frac{L}{2} - \delta, \frac{L}{2} + \delta), \\ \beta & for & x \in (\frac{L}{2} + \delta, L), \end{cases}$$
(11.42)

where  $\delta = (\beta L - c)/2(\beta - \alpha)$ .

The proof consists in two steps:

1. First a simple rearrangement argument together with the variational characterization of the first eigenvalue:

$$\Lambda_1(\rho) = \min_{v \in H_0^2(0,L), v \neq 0} \frac{\int_0^L v''^2 dx}{\int_0^L \rho v^2 dx}$$
(11.43)

implies the double inequality  $\Lambda_1(\rho^*) \leq \Lambda_1(\rho) \leq \Lambda_1(\rho_*)$  where  $\rho^*$  is the symmetric decreasing rearrangement of  $\rho$  (in the sense of section 2.1) while  $\rho_*$  is the symmetric increasing rearrangement of  $\rho$ . See [32] for more details.

2. Then, a comparison theorem can be used. Namely, if  $\rho_1$  and  $\rho_2$  are two symmetric (w.r.t. L/2) functions such that there exists a point a with

$$\rho_2(x) \ge \rho_1(x)$$
 for  $0 \le x \le a$  and  $\rho_2(x) \le \rho_1(x)$  for  $a \le x \le L$ ,

then  $\Lambda_1(\rho_2) \leq \Lambda_1(\rho_1)$ . This inequality is obtained by proving that, under the above assumptions, we have

$$\int_0^L \rho_1 u^2 \, dx \le \int_0^L \rho_2 u^2 \, dx$$

where u is the first eigenfunction associated to  $\rho_1$ , see [185] for more details. Since the functions  $\rho_*$  and  $\rho^*$  satisfy  $\rho^* \leq \rho \leq \rho_*$  for any symmetric function in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$ , the theorem follows with point 1.

In Theorems 9.3.1 and 9.3.3, M.G. Krein was able to extend the minimization and maximization results to the n-th eigenvalue  $\lambda_n$ . The fundamental argument was that, for a string (i.e. for the Laplacian),  $\lambda_n$  is the first eigenvalue of each nodal domain of the corresponding eigenfunction, so we can apply the result for  $\lambda_1$  to each nodal domain. It is generally wrong for the n-th eigenvalue of the clamped problem, which explains why the result is not known for  $\Lambda_n$ , see Open problem 30 below.

Remark 11.4.2. For the analogous problem in higher dimension (i.e. for a clamped plate), if we assume that the first eigenfunction is non-negative, one can easily prove, thanks to the same symmetrization introduced in Lemma 11.3.2, that  $\Lambda_1(\rho,\Omega) \geq \Lambda_1(\rho^*,\Omega^*)$ . In other words, if we want to minimize  $\Lambda_1(\rho,\Omega)$  by letting both  $\rho$  and  $\Omega$  vary (into the class of pairs  $(\rho,\Omega)$  such that the first eigenfunction is non-negative), the solution is given by the ball  $\Omega^*$  and the function  $\rho^*$  is equal to  $\beta$  on a centered ball and  $\alpha$  elsewhere.

D.O. Banks in [24] proves similar results for a non-homogeneous "hinged" rod hold (hinged means here that the bar is supported at its endpoints):

**Theorem 11.4.3 (Banks).** Let  $\lambda_1(\rho)$  be the first eigenvalue of the problem

$$\begin{cases} u^{(4)} = \lambda_1(\rho)\rho(x)u & \text{for } x \in (0, L), \\ u(0) = u''(0) = u(L) = u''(L) = 0. \end{cases}$$
 (11.44)

Then, conclusions of Theorem 11.4.1 about minimization and maximization of  $\lambda_1(\rho)$  hold with the same solutions. Moreover, the (unique) minimizer of  $\lambda_n(\rho)$  in the class  $\mathcal{A}_{\alpha,\beta,c}(\Omega)$  is the periodic function  $\rho_n(x)$  defined by

$$\rho_n(x) = \begin{cases} \rho_1(nx) & \text{for } x \in [0, \frac{L}{n}], \\ \rho_n(x - \frac{kL}{n}) & \text{for } x \in \left[\frac{kL}{n}, \frac{(k+1)L}{n}\right], \end{cases}$$
(11.45)

(k = 1, 2, ..., n - 1) where  $\rho_1$  is defined in (11.41).

Here the proof uses the same symmetrization introduced in Lemma 11.3.2 to prove Szegö's Theorem 11.3.1. Actually, in one dimension, it is classical that the first eigenfunction of such a problem is positive (see e.g. [116], or chapter 6 of [83]).

- **Open problem 30.** (i) Is it true that the minimizer of  $\Lambda_n(\rho)$  (the n-eigenvalue of the clamped problem) in the class  $\mathcal{A}_{\alpha,\beta,c}(0,L)$  is the function  $\rho_n(x)$  defined by (11.45), where  $\rho_1$  is defined in (11.41)?
- (ii) Is it true that the maximizer of  $\Lambda_n(\rho)$  (the n-eigenvalue of the clamped problem) in the class  $\mathcal{A}_{\alpha,\beta,c}(0,L)$  is the function  $\rho^n(x)$  defined as in (11.45), where  $\rho_1$  is replaced by  $\rho^1$  defined in (11.42)?
- (iii) Is it true that the maximizer of  $\lambda_n(\rho)$  (the n-eigenvalue of the hinged problem) in the class  $\mathcal{A}_{\alpha,\beta,c}(0,L)$  is the same function  $\rho^n(x)$  as above?

#### 11.4.2 The optimal shape of a column

This problem has a very long and controversial story starting with J.L. Lagrange in 1773 (see [136]) and produces a huge amount of literature, especially after the famous paper by L. Tadjbakhsh and J.B. Keller, [197] which sparked off the controversy. For review of works on this problem, we refer e.g. to [60], [83], [187], [189]. In terms of extremum eigenvalue problems, searching for the optimal shape of a column consists in looking for a function  $\sigma$  which maximizes the first eigenvalue of the following fourth-order problem

$$\begin{cases} (\sigma y'')'' + \lambda y'' = 0 & \text{for } x \in (0, 1) \\ \text{plus boundary conditions,} \end{cases}$$
 (11.46)

subject to an integral constraint of the kind

$$\int_0^1 \sigma^p(x) \, dx = c \tag{11.47}$$

(the values p = 1/2 or p = 1/3 being the most important in practice). As boundary conditions, one can study

$$\mathbf{clamped\text{-}clamped}\ \ y(0)=y'(0)=y(1)=y'(1)=0,$$

**clamped-hinged** (or clamped-simply supported)  $y(0) = y'(0) = y(1) = \sigma y''(1) = 0$ 

**hinged-hinged** 
$$y(0) = \sigma y''(0) = y(1) = \sigma y''(1) = 0.$$

The "hinged-hinged" problem is simpler, since introducing  $v = \sigma y''$ , we are immediately led to the following second-order eigenvalue problem

$$\begin{cases} -v'' = \lambda \sigma^{-1} v & \text{for } x \in (0,1), \\ v(0) = v(1) = 0, \end{cases}$$
 (11.48)

which comes under chapter 9 (in particular, see Theorem 9.2.8).

The controversial discussion mainly has its origin in the two following (basic) points:

- 1. Is there existence of an optimal  $\sigma$ ?
- 2. Can we simply derive optimality conditions?

Actually, concerning point 1, several authors (among them L. Tadjbakhsh and J.B. Keller) neglected to consider this fundamental question. It seems that one can prove existence of a maximizer only in a smaller class of functions: see V. Komkov in [129] for an argument that the original problem of Lagrange cannot have a solution and S. Cox-M. Overton in [67] for an existence result in a restricted class.

About point 2, optimality conditions can be easily obtained assuming (obviously as well as existence) that the first eigenvalue is simple (as did L. Tadjbakhsh and J.B. Keller). This is the so-called *unimodal* optimal solution. This is correct in the clamped-hinged and hinged-hinged boundary conditions cases, but seems to fail in the clamped-clamped case, see Olhoff-Rasmussen's paper [161]. Therefore, in this case it is necessary to consider a *bimodal* optimal solution and to get optimality conditions taking into account this lack of differentiability of  $\sigma \mapsto \lambda_1(\sigma)$ . This has been done in different papers, thanks to different techniques, see [161], [187], [147], [67].

The controversy seems not completely closed as of now. Another aspect of the debate is the definition of the quantity we want to maximize. Since the "optimal" (unimodal) solution  $\sigma^*$ , found by L. Tadjbakhsh and J.B. Keller and revivified in the book of Y. Egorov and V. Kondratiev, has the property to vanish at two interior points, it is not clear that the eigenvalue problem (11.46) is well posed for  $\sigma = \sigma^*$ ! We are in fact in some degenerate case, as in Theorem 10.2.4 (but it is worse here since the singularities are now inside the domain). Therefore, it seems reasonable to define the first buckling load of the column, which has to be maximized, by its Rayleigh quotient. For example, in the clamped-clamped case, one can take as a definition:

$$\lambda_1(\sigma) := \inf_{y \in H_0^2(\Omega), y \neq 0} \frac{\int_0^1 \sigma(x) y''(x)^2 dx}{\int_0^1 y'(x)^2 dx}.$$
 (11.49)

Now, a natural question occurs: is the above infimum always attained? Obviously, it depends on the way the function  $\sigma$  is allowed to vanish. Exactly as in Theorem 10.2.4, it cannot vanish too strongly. In Lemma 24 (chapter 6) of [83], the authors prove the following result:

**Theorem 11.4.4.** Let  $\sigma(x)$  be a continuous non-negative function defined on (0,1). Assume that  $\sigma$  vanishes only at a finite number of points  $x_1, x_2, \ldots, x_k$  with the following behavior in the neighborhood of these points:

$$\sigma(x) = O(|x - x_i|^{\gamma}) \quad \text{with } \gamma < 2. \tag{11.50}$$

Then, the infimum is achieved in (11.49).

The unimodal solution of Tadjbakhsh-Keller is defined by

$$\sigma^*(x) = 4\sin^2\theta(x)/3$$

where  $\theta(x)$  is the solution of the equation  $\theta - \sin(2\theta)/2 = 2\pi x - \pi/2$ . It satisfies (11.50) with  $\gamma = 4/3$  at points  $x_1 = 1/4$  and  $x_2 = 3/4$ , so it fulfills conditions of this theorem and the infimum is attained in (11.49). In chapter 6 of their book, Y. Egorov and V. Kondratiev, show that this function  $\sigma^*$  provides the maximum possible value of  $\lambda_1(\sigma)$  amongst non-negative functions  $\sigma$  satisfying  $\int_0^1 \sqrt{\sigma(x)} dx =$ 1. So, is the story finished? No! Since this optimal column possesses points of vanishing cross-section (and zero bending moments), many authors think that these points must be treated as internal hinges. This assumption seems reasonable from a mechanical point of view. From a mathematical point of view, it means that, when  $\sigma = \sigma^*$ , the infimum in (11.49) should be taken not on the Sobolev space  $H_0^2(0,1)$ , but on the space of functions in  $H^1(0,1)$  whose restrictions on (0,1/4), (1/4,3/4) and (3/4,1) have second derivatives in  $L^2$ . In other terms, discontinuities of the slope are allowed. Using this rule, A. Seyranian and O. Privalova in [189] were able to prove that the unimodal solution is not optimal. For that purpose, they chose a test function which consists in taking an eigenfunction of the problem clamped-hinged on each segment (0, 1/4) and (3/4, 1) and then linking them by a straight line.

We do not aspire to conclude the debate here. Our purpose was just to give a short introduction and we prefer to refer to the papers and books which are cited above. We also believe that the story is not yet finished.

- [1] S. Abramovich, The gap between the first two eigenvalues of a one-dimensional Schr¨odinger operator with symmetric potential, Proc. Amer. Math. Soc., **111** (1991), no. 2, 451-453.
- [2] G. Alessandrini, Nodal lines of eigenfunctions of the fixed membrane problem in general convex domains, Comment. Math. Helv., **69** (1994), no. 1, 142-154.
- [3] L.C. Andrews, Special functions of mathematics for engineers, Second edition, McGraw-Hill, Inc., New York, 1992.
- [4] M.S. Ashbaugh, Open problems on eigenvalues of the Laplacian, Analytic and Geometric Inequalities and Their Applications, 13–28, Math. Appl., 478, Kluwer Acad. Publ., Dordrecht, 1999.
- [5] M.S. Ashbaugh, R. Benguria, Best constant for the ratio of the first two eigenvalues of one-dimensional Schr¨odinger operators with positive potentials, Proc. Amer. Math. Soc., **99** (1987), no. 3, 598-599.
- [6] M.S. Ashbaugh, R. Benguria, Optimal lower bounds for eigenvalue gaps for Schr¨odinger operators with symmetric single-well potentials and related results, Maximum principles and eigenvalue problems in partial differential equations (Knoxville, TN, 1987), 134-145, Pitman Res. Notes Math. Ser., 175, Longman Sci. Tech., Harlow, 1988.
- [7] M.S. Ashbaugh, R. Benguria, Optimal lower bound for the gap between the first two eigenvalues of one-dimensional Schr¨odinger operators with symmetric singlewell potentials, Proc. Amer. Math. Soc., **105** (1989), no. 2, 419-424.
- [8] M.S. Ashbaugh, R. Benguria, Optimal bounds for ratios of eigenvalues of onedimensional Schr¨odinger operators with Dirichlet boundary conditions and positive potentials, Comm. Math. Phys., **124** (1989), no. 3, 403-415.
- [9] M.S. Ashbaugh, R. Benguria, Proof of the Payne-P´olya-Weinberger conjecture, Bull. Amer. Math. Soc., **25** no. 1 (1991), 19-29.
- [10] M.S. Ashbaugh, R. Benguria, A sharp bound for the ratio of the first two eigenvalues of Dirichlet Laplacians and extensions, Ann. of Math., **135** (1992), no. 3, 601-628.
- [11] M.S. Ashbaugh, R. Benguria, A second proof of the Payne-P´olya-Weinberger conjecture, Comm. Math. Phys., **147** (1992), no. 1, 181-190.

[12] M.S. Ashbaugh, R. Benguria, More bounds on eigenvalue ratios for Dirichlet Laplacians in n dimensions, SIAM J. Math. Anal., **24** (1993), no. 6, 1622-1651.

- [13] M.S. Ashbaugh, R. Benguria, Eigenvalue ratios for Sturm-Liouville operators, J. Differential Equations, **103** (1993), no. 1, 205-219.
- [14] M.S. Ashbaugh, R. Benguria, Isoperimetric inequalities for eigenvalue ratios, Partial differential equations of elliptic type (Cortona, 1992), 1-36, Sympos. Math., XXXV, Cambridge Univ. Press, Cambridge, 1994.
- [15] M.S. Ashbaugh, R. Benguria, On Rayleigh's conjecture for the clamped plate and its generalization to three dimensions, Duke Math. J., **78** (1995), 1-17.
- [16] M.S. Ashbaugh, D. Bucur, On the isoperimetric inequality for the buckling of a clamped plate, Special issue dedicated to Lawrence E. Payne, Z. Angew. Math. Phys., **54** (2003), no. 5, 756-770.
- [17] M.S. Ashbaugh, E.M. Harrell, Maximal and minimal eigenvalues and their associated nonlinear equations, J. Math. Phys., **28** (1987), no. 8, 1770-1786.
- [18] M.S. Ashbaugh, E.M. Harrell, R. Svirsky, On minimal and maximal eigenvalue gaps and their causes, Pacific J. Math., **147** (1991), no. 1, 1-24.
- [19] C. Bandle Isoperimetric inequalities and applications. Monographs and Studies in Mathematics, 7, Pitman, Boston, Mass.-London, 1980.
- [20] C. Bandle, Extremal problems for eigenvalues of the Sturm-Liouville type, General inequalities, 5 (Oberwolfach, 1986), 319-336, Internat. Schriftenreihe Numer. Math., 80, Birkh¨auser, Basel, 1987.
- [21] D.O. Banks, Bounds for the eigenvalues of some vibrating systems, Pacific J. Math., **10** (1960), 439-474.
- [22] D.O. Banks, Upper bounds for the eigenvalues of some vibrating systems, Pacific J. Math., **11** (1961), 1183-1203.
- [23] D.O. Banks, Lower bounds for the eigenvalues of the vibrating string whose density satisfies a Lipschitz condition, Pacific J. Math., **20** (1967), 393-401.
- [24] D.O. Banks, Bounds for the eigenvalues of nonhomogeneous hinged vibrating rods, J. Math. Mech., **16** no 9 (1967), 949-966.
- [25] L. Barbosa, P. B´ erard, Eigenvalue and "twisted" eigenvalue problems, applications to CMC surfaces, J. Math. Pures Appl., **79** (2000), no. 5, 427-450.
- [26] M. Bareket, On an isoperimetric inequality for the first eigenvalue of a boundary value problem, SIAM J. Math. Anal., **8** (1977), no. 2, 280-287.
- [27] D.C. Barnes, Some isoperimetric inequalities for the eigenvalues of vibrating strings, Pacific J. Math., **29** (1969), 43-61.
- [28] D.C. Barnes, Extremal problems for eigenvalues with applications to buckling, vibration and sloshing, SIAM J. Math. Anal., **16** (1985), no. 2, 341-357.
- [29] E.R. Barnes, The shape of the strongest column and some related extremal eigenvalue problems, Quart. Appl. Math., **34** (1976/77), no. 4, 393-409.

[30] J. Baxter, G. Dal Maso, U. Mosco, Stopping times and Γ-convergence, Trans. American Math. Soc., **303**, no 1 (1987), 1-38.

- [31] E. Bednarczuk, M. Pierre, E. Rouy, J. Sokolowski, Tangent sets in some functional spaces, Nonlinear Anal. Ser. A: Theory Methods, **42** (2000), no. 5, 871- 886.
- [32] P.R. Beesack, Isoperimetric inequalities for the non homogeneous clamped rod and plate, J. Math. Mech., **8** (1959), 471-482.
- [33] C. Bennewitz, E.J.M. Veling, Optimal bounds for the spectrum of a onedimensional Schr¨odinger operator, General inequalities, **6** (Oberwolfach, 1990), 257-268, Internat. Ser. Numer. Math., 103, Birkh¨auser, Basel, 1992.
- [34] F. Betta, F. Brock, A. Mercaldo, M.R. Posteraro, A weighted isoperimetric inequality and applications to symmetrization, J. Inequal. Appl., **4** (1999), no. 3, 215-240.
- [35] M.H. Bossel, Membranes ´elastiquement li´ees: extension du th´eor`eme de Rayleigh-Faber-Krahn et de l'in´egalit´e de Cheeger, C. R. Acad. Sci. Paris S´erie I Math., **302** (1986), no. 1, 47-50.
- [36] H. Br´ ezis, Analyse fonctionnelle, Masson, Paris, 1983.
- [37] T. Brianc¸on, Regularity of optimal shapes for the Dirichlet's energy with volume constraint, ESAIM: COCV, **10** (2004), 99-122.
- [38] T. Brianc¸on, M. Hayouni, M. Pierre, Lipschitz Continuity of State Functions in Some Optimal Shaping, Calc. Var. Partial Differential Equations, **23** (2005), no. 1, 13-32.
- [39] F. Brock, Continuous Steiner symmetrization, Math. Nachr., **172** (1995), p.25-48.
- [40] F. Brock, Continuous symmetrization and symmetry of solutions of elliptic problems, Proc. Indian Acad. Sci. Math. Sci., **110** (2000), 157-204.
- [41] F. Brock, An isoperimetric inequality for eigenvalues of the Stekloff problem, Z. Angew. Math. Mech., **81** (2001), no. 1, 69-71.
- [42] D. Bucur, Concentration-compacit´e et γ-convergence, C. R. Acad. Sci. Paris, S´erie I, **327** (1998), p. 255-258.
- [43] D. Bucur, Regularity of optimal convex shapes, J. Convex Anal., **10** (2003), no. 2, 501-516.
- [44] D. Bucur, G. Buttazzo, Variational Methods in Shape Optimization Problems, Progress in Nonlinear Differential Equations and Their Applications, **65** Birkh¨auser, Basel, Boston 2005.
- [45] D. Bucur, G. Buttazzo, I. Figueiredo, On the attainable eigenvalues of the Laplace operator, SIAM J. Math. Anal., **30** (1999), no. 3, 527-536 .
- [46] D. Bucur, A. Henrot, Stability for the Dirichlet problem under continuous Steiner symmetrization, Potential Anal., **13** (2000), no. 2, 127-145.

[47] D. Bucur, A. Henrot, Minimization of the third eigenvalue of the Dirichlet Laplacian, Proc. Roy. Soc. London, **456** (2000), 985-996.

- [48] D. Bucur, A. Henrot, J. Sokolowski, A. Zochowski, Continuity of the elasticity system solutions with respect to the geometrical domain variations, Adv. Math. Sci. Appl., **11** (2001), no. 1, 57-73.
- [49] V.I. Burenkov, E.B. Davies, Spectral stability of the Neumann Laplacian, J. Differential Equations, **186** (2002), no. 2, 485-508.
- [50] G. Buttazzo, G. Dal Maso, An Existence Result for a Class of Shape Optimization Problems, Arch. Rational Mech. Anal., **122** (1993), 183-195.
- [51] J. C´ ea, K. Malanowski, An example of a max-min problem in partial differential equations, SIAM J. Control, **8** (1970), 305-316.
- [52] A. Chambolle, F. Doveri, Continuity of Neumann linear elliptic problems on varying two-dimensional bounded open sets, Comm. Part. Diff. Eq., **22** (1997), 811- 840.
- [53] T. Chatelain, M. Choulli Clarke generalized gradient for eigenvalues, Commun. Appl. Anal., **1** (1997), no. 4, 443-454.
- [54] D. Chenais, On the existence of a solution in a domain identification problem, J. Math. Anal. Appl., **52** (1975), 189-289.
- [55] G. Chiti, A reverse H¨older inequality for the eigenfunctions of linear second order elliptic operators, Z. Angew. Math. Phys., **33** (1982), no. 1, 143-148.
- [56] A. Cianchi, N. Fusco, Functions of bounded variation and rearrangements, Arch. Rational Mech. Anal., **165** (2002), no. 1, 1-40.
- [57] R. Cominetti, J.P. Penot, Tanget Sets to Unilateral Sets, C. R. Acad. Sci. Paris, vol. 321 (1995), s´erie I, 1631-1636.
- [58] R. Courant, D. Hilbert, Methods of Mathematical Physics, vol. 1 et 2, Wiley, New York, 1953 et 1962.
- [59] S.J. Cox, The two phase drum with the deepest bass note, Japan J. Indust. Appl. Math., **8** (1991), no. 3, 345-355.
- [60] S.J. Cox, The shape of the ideal column, Math. Intelligencer, **14** (1992), 16-24.
- [61] S.J. Cox, Extremal eigenvalue problems for the Laplacian, Recent advances in partial differential equations (El Escorial, 1992), 37-53, RAM Res. Appl. Math., 30, Masson, Paris, 1994.
- [62] S.J. Cox, The generalized gradient at a multiple eigenvalue, J. Funct. Anal., **133** (1995), no. 1, 30-40.
- [63] S.J. Cox, B. Kawohl, P.X. Uhlig, On the optimal insulation of conductors, J. Optim. Theory Appl., **100** (1999), no. 2, 253-263.
- [64] S.J. Cox, R. Lipton, Extremal eigenvalue problems for two-phase conductors, Arch. Rational Mech. Anal., **136** (1996), 101-117.

[65] S.J. Cox, J.R. McLaughlin, Extremal eigenvalue problems for composite membranes, I, II, Appl. Math. Optim., **22** (1990), no. 2, 153-167, 169-187.

- [66] S.J. Cox, J.H. Maddocks, On the optimal design of a Nonlinear Elastica, preprint.
- [67] S.J. Cox, M. Overton, On the optimal design of columns against buckling, SIAM J. Math. Anal., **23** no 2 (1992), 287-325.
- [68] S.J. Cox, M. Ross Extremal eigenvalue problems for starlike planar domains, J. Differential Equations, **120** (1995), 174-197.
- [69] S.J. Cox, M. Ross The maximization of Neumann eigenvalues on convex domains, preprint.
- [70] S.J. Cox, P.X. Uhlig, Where best to hold a drum fast, SIAM J. Optim., **9** (1999), no. 4, 948-964.
- [71] B. Dacorogna, Weak continuity and weak lower semicontinuity of nonlinear functionals, Lecture Notes in Mathematics, 922, Springer-Verlag, Berlin-New York, 1982.
- [72] G. Dal Maso, An introduction to Γ-convergence, Birkh¨auser, Boston, 1993.
- [73] G. Dal Maso, U. Mosco, Wiener's criterion and Γ-convergence, Appl. Math. Optim., **15** (1987), 15-63.
- [74] D. Daners, A Faber-Krahn inequality for Robin problems in any space dimension, to appear in Math. Annalen.
- [75] R. Dautray and J. L. Lions (ed), Analyse math´ematique et calcul num´erique, Vol. I and II, Masson, Paris, 1984.
- [76] P.A. Deift, Applications of a commutation formula, Duke J. Math., **45** (1978), 267-310.
- [77] B. Dittmar, Sums of reciprocal eigenvalues of the Laplacian, Math. Nachr., **237** (2002), 45-61.
- [78] B. Dittmar, Sums of reciprocal Stekloff eigenvalues, Math. Nachr., **268** (2004), 44-49.
- [79] B. Dittmar, Sums of free membrane eigenvalues, J. Anal. Math., **95** (2005), 323- 332.
- [80] R.J. Duffin, Nodal lines of a vibrating plate, J. Math and Phys., **31** (1953), 294- 299.
- [81] H. Egnell, Extremal properties of the first eigenvalue of a class of elliptic eigenvalue problems, Ann. Scuola Norm. Sup. Pisa Cl. Sci., (4) **14** (1987), no. 1, 1-48.
- [82] Y. Egorov, S. Karaa, Optimisation de la premi`ere valeur propre de l'op´erateur de Sturm-Liouville, C. R. Acad. Sci. Paris S´erie I Math., **319** (1994), no. 8, 793-798.
- [83] Y. Egorov, V. Kondratiev, On spectral theory of elliptic operators, Oper. Theory Adv. Appl., **89**, Birkh¨auser, Basel, 1996.

[84] M. Essen, On estimating eigenvalues of a second order linear differential operator, General inequalities, **5** (Oberwolfach, 1986), 347-366, Internat. Schriftenreihe Numer. Math., 80, Birkh¨auser, Basel, 1987.

- [85] P. Exner, E.M. Harrell, M. Loss, Optimal eigenvalues for some Laplacians and Schr¨odinger operators depending on curvature, Mathematical results in quantum mechanics (Prague, 1998), 47-58, Oper. Theory Adv. Appl., **108**, Birkh¨auser, Basel, 1999.
- [86] G. Faber, Beweis, dass unter allen homogenen Membranen von gleicher Fl¨ache und gleicher Spannung die kreisf¨ormige den tiefsten Grundton gibt , Sitz. Ber. Bayer. Akad. Wiss. (1923), 169-172.
- [87] H. Federer, Geometric measure theory, Die Grundlehren der mathematischen Wissenschaften, Band 153, Springer-Verlag New York Inc., New York 1969.
- [88] M. Flucher, Approximation of Dirichlet eigenvalues on domains with small holes, J. Math. Anal. Appl., **193** (1995), no. 1, 169-199.
- [89] P. Freitas, On minimal eigenvalues of Schr¨odinger Operators on Manifolds, Commun. Math. Phys., **217** (2001), 375-382.
- [90] P. Freitas, A. Henrot, On the first twisted Dirichlet eigenvalue, Comm. Anal. Geom., **12** (2004), no. 5, 1083-1103.
- [91] S. Friedland, Extremal eigenvalue problems defined for certain classes of functions, Arch. Rational Mech. Anal., **67** (1977), no. 1, 73-81.
- [92] A. Friedman, Reinforcement of the principal eigenvalue of an elliptic operator, Arch. Rational Mech. Anal., **73** (1980), no. 1, 1-17.
- [93] R.D. Gentry, D.O. Banks, Bounds for functions of eigenvalues of vibrating systems, J. Math. Anal. Appl., **51** (1975), 100-128.
- [94] D. Gilbarg, N.S. Trudinger, Elliptic partial differential equations of second order. Reprint of the 1998 edition, Classics in Mathematics. Springer-Verlag, Berlin, 2001.
- [95] A. Greco, M. Lucia Eigenvalues of the Laplacian Acting on Functions of Mean Zero with Constant Boundary Values, preprint no 2, December 2005, 18 pp., National Center for Theoretical Sciences, National Tsing Hua University, Taiwan.
- [96] P. Grisvard, Elliptic problems in non-smooth domains, Pitman, London, 1985.
- [97] G.H. Hardy, J.E. Littlewood, G. Polya ´ , Inequalities, Reprint of the 1952 edition, Cambridge Mathematical Library, Cambridge University Press, Cambridge, 1988.
- [98] E.M. Harrell, Hamiltonian operators with maximal eigenvalues, J. Math. Phys., **25** (1984), no. 1, 48-51 and **27** (1986), no. 1, 419.
- [99] E.M. Harrell, P. Kroger, K. Kurata ¨ , On the placement of an obstacle or a well so as to optimize the fundamental eigenvalue, SIAM J. Math. Anal., **33** (2001), no. 1, 240-259.

[100] P. H´ ebrard, A. Henrot, A spillover phenomenon in the optimal location of actuators, SIAM J. Control Optim., **44** (2005), no. 1, 349-366.

- [101] R. Hempel, L.A. Seco, B. Simon, The essential spectrum of Neumann Laplacians on some bounded singular domains, J. Funct. Anal., **102** (1991), no. 2, 448-483.
- [102] A. Henrot, H. Maillot, Optimization of the shape and the location of the actuators in an internal control problem, Boll. Unione Mat. Ital. Sez. B Artic. Ric. Mat., (8) **4** (2001), no. 3, 737-757.
- [103] A. Henrot, E. Oudet, Minimizing the second eigenvalue of the Laplace operator with Dirichlet boundary conditions, Arch. Rational Mech. Anal., **169** (2003), 73-87.
- [104] A. Henrot, M. Pierre, Variation et optimisation de formes, Math´ematiques et Applications **48**, Springer, 2005.
- [105] J. Hersch, Contribution to the method of interior parallels applied to vibrating membrane, 1962 Studies in mathematical analysis and related topics pp. 132–139 Stanford Univ. Press, Stanford.
- [106] J. Hersch, The method of interior parallels applied to polygonal or multiply connected membranes, Pacific J. Math., **13** (1963), 1229-1238.
- [107] J. Hersch Contraintes rectilignes parall`eles et valeurs propres de membranes vibrantes, Z. Angew. Math. Phys., **17** (1966) 457-460.
- [108] J. Hersch, L.E. Payne, Extremal principles and isoperimetric inequalities for some mixed problems of Stekloff 's type, Z. Angew. Math. Phys., **19** (1968), 802- 817.
- [109] J. Hersch, L.E. Payne, M.M. Schiffer, Some inequalities for Stekloff eigenvalues, Arch. Rational Mech. Anal., **57** (1975), 99-114.
- [110] G.N. Hile, Z.Y. Xu, Inequalities for sums of reciprocals of eigenvalues, J. Math. Anal. Appl., **180** no 2 (1993), 412-430.
- [111] I. Hong, On an inequality concerning the eigenvalue problem of membrane, Kodai Math. Sem. Rep., (1954), 113-114.
- [112] M. Horvath ´ , On the first two eigenvalues of Sturm-Liouville operators, Proc. Amer. Math. Soc., **131** no 4 (2003), 1215-1224.
- [113] M. Horvath, M. Kiss ´ , A bound for ratios of eigenvalues of Schr¨odinger operators with single-well potentials, Proc. Amer. Math. Soc., **134** no 5 (2005), 1425-1434.
- [114] M.J. Huang, On the eigenvalue ratio for vibrating strings, Proc. Amer. Math. Soc., **127** (1999), no. 6, 1805-1813.
- [115] Y.L. Huang, C.K. Law, Eigenvalue ratios for the regular Sturm-Liouville system, Proc. Amer. Math. Soc., **124** (1996), no. 5, 1427-1436.
- [116] S.A. Janczewski, Oscillation Theorems for the differential boundary value problems of the fourth order, Ann. of Math., **29** (1928), 521-542.
- [117] C. Jouron, Sur un probl`eme d'optimisation o`u la contrainte porte sur la fr´equence fondamentale, RAIRO Anal. Num´er., **12** (1978), no. 4, 349-375.

[118] S. Karaa, Sharp estimates for the eigenvalues of some differential equations, SIAM J. Math. Anal., **29** (1998), no. 5, 1279-1300.

- [119] S. Karaa, Extremal eigenvalue gaps for the Schr¨odinger operator with Dirichlet boundary conditions, J. Math. Phys., **39** (1998), no. 4, 2325-2332.
- [120] S. Karlin, Some extremal problems for eigenvalues of certain matrix and integral operators, Adv. in Math., **9** (1972), 93-136.
- [121] T. Kato, Perturbation Theory for Linear Operators, Springer-Verlag, 1966.
- [122] B. Kawohl, Rearrangements and convexity of level sets in PDE, Lecture Notes in Mathematics, 1150. Springer-Verlag, Berlin, 1985.
- [123] B. Kawohl, O. Pironneau, L. Tartar, J.P. Zol´ esio, Optimal shape design, Lecture Notes in Mathematics, 1740. (Lectures given at the Joint C.I.M./C.I.M.E. Summer School held in Tr´oia, June 1-6, 1998, Edited by A. Cellina and A. Ornelas).
- [124] M.V. Keldyˇs, On the solvability and the stability of the Dirichlet problem, Amer. Math. Soc. Trans., **2**-51 (1966), 1-73.
- [125] J.B. Keller, The shape of the strongest column, Arch. Rational Mech. Anal., **5** (1960), 275-285.
- [126] J.B. Keller, The minimum ratio of two eigenvalues, SIAM J. Appl. Math., **31** (1976), no. 3, 485-491.
- [127] S. Kesavan, On two functionals connected to the Laplacian in a class of doubly connected domains, Proc. Roy. Soc. Edinburgh, Sect. A, **133** (2003), no. 3, 617-624.
- [128] T. Kolokolnikov, M.S. Titcombe, M.J. Ward, Optimizing the fundamental Neumann eigenvalue for the Laplacian in a domain with small traps, European J. Appl. Math., **16** (2005), no. 2, 161-200.
- [129] V. Komkov, An optimal design problem. A nonexistence theorem, Arch. Mech. (Arch. Mech. Stos.), **33** (1981), no. 1, 147-151.
- [130] E.T. Kornhauser, I. Stakgold, A variational Theorem for <sup>∇</sup><sup>2</sup><sup>u</sup> <sup>+</sup> λu = 0 and its applications, J. Math. Physics, **31** (1952), 45-54.
- [131] E. Krahn, Uber eine von Rayleigh formulierte Minimaleigenschaft des Kreises ¨ , Math. Ann., **94** (1924), 97-100.
- [132] E. Krahn, Uber Minimaleigenschaften der Kugel in drei un mehr Dimensionen ¨ , Acta Comm. Univ. Dorpat., **A9** (1926), 1-44.
- [133] M.G. Krein, On certain problems on the maximum and minimum of characteristic values and on the Lyapunov zones of stability, Amer. Math. Soc. Transl., (2) **1** (1955), 163-187.
- [134] J.F. Kuzanek, Existence and uniqueness of solutions to a fourth order nonlinear eigenvalue problem, SIAM J. Appl. Math., **27** (1974), 341-354.
- [135] T. Lachand-Robert, M.A. Peletier, An Example of Non-convex Minimization and an Application to Newton's Problem of the Body of Least Resistance, Ann. Inst. H. Poincar´e, Analyse non-lin´eaire, **18** (2001), 179-198.

[136] J.L. Lagrange, Sur la figure des colonnes, in Serret M.J.A. (ed) Oeuvres de Lagrange, vol. 2, 125-170, Gauthier-Villars, Paris, 1868.

- [137] R.S. Laugesen, C. Morpurgo, Extremals for eigenvalues of Laplacians under conformal mapping, J. Funct. Anal., **155** (1998), no. 1, 64-108.
- [138] R. Lavine, The eigenvalue gap for one-dimensional convex potentials, Proc. Amer. Math. Soc., **121** no 3 (1994), 815-821.
- [139] N.N. Lebedev, Special functions and their applications, Dover Publications, Inc., New York, 1972.
- [140] M. Levitin, R. Yagudin, Range of the first three eigenvalues of the planar Dirichlet Laplacian, LMS J. Comput. Math., **6** (2003), 1-17.
- [141] P.L. Lions, The concentration-compactness principle in the calculus of variations, Ann. Inst. H. Poincar´e, Analyse non-lin´eaire, **1** (1984), 109-145.
- [142] K. Lurie, A. Cherkaev, Effective characteristics of composite materials and the optimal design of structural elements, Topics in the mathematical modelling of composite materials, 175-258, Progr. Nonlinear Differential Equations Appl., 31, Birkh¨auser Boston, 1997.
- [143] J.M. Luttinger, Generalized isoperimetric inequalities, J. Mathematical Phys., **14** (1973), 586-593.
- [144] T.J. Mahar, B.E. Willner, An extremal eigenvalue problem, Comm. Pure Appl. Math., **29** (1976), no. 5, 517-529.
- [145] T.J. Mahar, B.E. Willner, Sturm-Liouville eigenvalue problems in which the squares of the eigenfunctions are linearly dependent, Comm. Pure Appl. Math., **33** (1980), no. 4, 567-578.
- [146] E. Makai, Bounds for the principal frequency of a membrane and the torsional rigidity of a beam, Acta Sci. Math. Szeged, **20** (1959), 33-35.
- [147] E. Masur, Optimal structural design under multiple eigenvalue constraints, Internat. J. Solids Structures, **20** (1984), no. 3, 211-231.
- [148] V. Maz'ja, Sobolev spaces, Springer Series in Soviet Mathematics, Springer-Verlag, Berlin, 1985.
- [149] V. Maz'ja, S. Nazarov, B. Plamenevskii, Asymptotische Theorie elliptischer Randwertaufgaben in singul¨ar gest¨orten Gebieten. I., Mathematische Lehrb¨ucher und Monographien, Akademie-Verlag, Berlin, 1991.
- [150] A. Melas, On the nodal line of the second eigenfunction of the Laplacian in R<sup>2</sup>, J. Diff. Geometry, **35** (1992), 255-263.
- [151] E. Mohr, Uber die Rayleighsche Vermutung: unter allen Platten von gegebener ¨ Fl¨ache und konstanter Dichte und Elastizit¨at hat die kreisf¨ormige den tiefsten Grundton, Ann. Mat. Pura Appl., **104** (1975), 85-122 and **107** (1975), 395.
- [152] J. Mossino, In´egalit´es isop´erim´etriques et applications en physique, Travaux en Cours, Hermann, Paris, 1984.

[153] A. Munnier, Thesis of the University of Franche-Comt´e, Besan¸con, 2000.

- [154] F. Murat, L. Tartar, Calcul des variations et homog´en´eisation, Homogenization methods: theory and applications in physics 319–369, Collect. Dir. Etudes Rech. ´ Elec. France, 57, Eyrolles, Paris, 1985.
- [155] M.K.V. Murthy, G. Stampacchia, Boundary value problems for some degenerate-elliptic operators, Ann. Mat. Pura Appl., **80** no 4 (1968), 1-122.
- [156] N.S. Nadirashvili, New isoperimetric inequalities in mathematical physics, Partial differential equations of elliptic type (Cortona, 1992), 197-203, Sympos. Math., XXXV, Cambridge Univ. Press, Cambridge, 1994.
- [157] N.S. Nadirashvili, Rayleigh's conjecture on the principal frequency of the clamped plate, Arch. Rational Mech. Anal., **129** (1995), 1-10.
- [158] B. Sz-Nagy, Uber Parallelmengen nichtkonvexer ebener Bereiche ¨ , Acta Sci. Math. Szeged, **20** (1959), 36-47.
- [159] S.A. Nazarov, J. Sokolowski, Asymptotic analysis of shape functionals, J. Math. Pures Appl., **82** (2003), no. 2, 125-196.
- [160] P. Nowosad, Isometric problems in algebras, Comm. Pure Appl. Math., **21** (1968), 401-465.
- [161] N. Olhoff, S. Rasmussen, On single and bimodal optimum buckling loads of clamped columns, Int. J. Solids Struct., **13** (1977), 605-614.
- [162] R. Osserman, The isoperimetric inequality, Bull. AMS, **84** no 6 (1978), 1182-1238.
- [163] R. Osserman, Isoperimetric inequalities and eigenvalues of the Laplacian, Proceedings of the International Congress of Mathematicians (Helsinki, 1978), pp. 435-442, Acad. Sci. Fennica, Helsinki, 1980.
- [164] E. Oudet, Some numerical results about minimization problems involving eigenvalues, ESAIM COCV, **10** (2004), 315-335.
- [165] S. Ozawa, Singular variation of domains and eigenvalues of the Laplacian, Duke Math. J., **48** (1981), no. 4, 767-778.
- [166] L.E. Payne, Isoperimetric inequalities and their applications, SIAM Rev., **9** (1967), 453-488.
- [167] L.E. Payne, Some comments on the past fifty years of isoperimetric inequalities, Inequalities (Birmingham, 1987), 143-161, Lecture Notes in Pure and Appl. Math., **129**, Dekker, New York, 1991.
- [168] L.E. Payne, G. Polya, H.F. Weinberger ´ , On the ratio of consecutive eigenvalues, J. Math. Phys., **35** (1956), 289-298.
- [169] L.E. Payne, P.W. Schaefer, Eigenvalue and eigenfunction inequalities for the elastically supported membrane, Z. Angew. Math. Phys., **52** (2001), no. 5, 888-895.
- [170] L.E. Payne, H.F. Weinberger, An optimal Poincar´e inequality for convex domains, Arch. Rational Mech. Anal., **5** (1960), 286-292.

[171] L.E. Payne, H.F. Weinberger, Some isoperimetric inequalities for membrane frequencies and torsional rigidity, J. Math. Anal. Appl., **2** (1961), 210-216.

- [172] G. Polya ´ , On the characteristic frequencies of a symmetric membrane, Math. Z., **63** (1955), 331-337.
- [173] G. Polya, M. Schiffer ´ , Convexity of functionals by transplantation, J. Analyse Math., **3** (1954), 245-346.
- [174] G. Polya, G. Szeg ´ o¨, Isoperimetric inequalities in mathematical physics, Ann. Math. Studies, **27**, Princeton Univ. Press, 1951.
- [175] P. Pucci, J. Serrin, A general variational identity, Indiana Univ. Math. J., **35** (1986), no. 3, 681-703.
- [176] A.G. Ramm, Question 5 in Part 2, Notices A.M.S., **29** (1982), 328-329.
- [177] A.G. Ramm, P.N. Shivakumar, Inequalities for the minimal eigenvalue of the Laplacian in an annulus, Math. Inequalities and Appl., **1** (1998), no. 4, 559-563.
- [178] T. Rassias The isoperimetric inequality and eigenvalues of the Laplacian. Constantin Carath´eodory: an international tribute, Vol. I, II, 1146-1163, World Sci. Publishing, Teaneck, NJ, 1991.
- [179] J.W.S. Rayleigh, The theory of sound, Dover Pub. New York, 1945 (republication of the 1894/96 edition).
- [180] B. Rousselet, Shape Design Sensitivity of a Membrane, J. Opt. Theory and Appl., **40** (1983), 595-623.
- [181] H.H. Schaefer, M.P. Wolff, Topological vector spaces. Second edition. Graduate Texts in Mathematics, Springer-Verlag, New York, 1999.
- [182] M. Schiffer, Hadamard's formula and variations of domain functions, Amer. J. Math., Vol. 68 (1946), 417-448.
- [183] R. Schoen, S.-T. Yau, Lectures on differential geometry, Conference Proceedings and Lecture Notes in Geometry and Topology, I. International Press, Cambridge, MA, 1994.
- [184] B. Schwarz, On the extrema of a nonhomogeneous string with equimeasurable density, J. Math. Mech., **10** (1961), 401-422.
- [185] B. Schwarz, Some results on the frequencies of nonhomogeneous rods, J. Math. Anal. Appl., **5** (1962), 169-175.
- [186] J. Serrin, A symmetry problem in potential theory, Arch. Rational Mech. Anal., **43** (1971), 304-318.
- [187] A.P. Seyranian, On a problem of Lagrange, Mech. Solids, 1984, 101-111.
- [188] A.P. Seyranian, The Lagrange problem on optimal column, Moscow State Lomonosov University, Preprint 60.
- [189] A.P. Seyranian, O.G. Privalova, The Lagrange problem on an optimal column: old and new results, Struct. Multidisc. Optim., **25** (2003), 393-410.

[190] N. Shimakura, La premi`ere valeur propre du laplacien pour le probl`eme de Dirichlet, J. Math. Pures Appl., **62** (1983), no. 2, 129-152.

- [191] J.Simon, Differentiation with respect to the domain in boundary value problems, Num. Funct. Anal. Optimz., **2** (1980) 649-687.
- [192] I.M. Singer, B. Wong, S.-T. Yau, S.S.-T. Yau, An estimate of the gap of the first two eigenvalues in the Schr¨odinger operator, Ann. Scuola Norm. Sup. Pisa Cl. Sci., (4) **12** (1985), no. 2, 319-333.
- [193] J. Sokolowski, J.P. Zolesio, Introduction to shape optimization: shape sensitivity analysis, Springer Series in Computational Mathematics, Vol. 10, Springer, Berlin 1992.
- [194] V. Sverak <sup>ˇ</sup> , On optimal shape design, J. Math. Pures Appl., **72-6** (1993), 537-551.
- [195] G. Szego¨, On membranes and plates, Proc. Nat. Acad. Sci., **36** (1950), 210-216.
- [196] G. Szego¨, Inequalities for certain eigenvalues of a membrane of given area, J. Rational Mech. Anal. **3** (1954), 343-356.
- [197] L. Tadjbakhsh, J.B. Keller, Strongest columns and isoperimetric inequalities for eigenvalues, Trans. ASME Ser. E. J. Appl. Mech., **29** (1962), 159-164.
- [198] R. Tahraoui, Quelques remarques sur le contrˆole des valeurs propres, Nonlinear partial differential equations and their applications, Coll`ege de France seminar, Vol. VIII (Paris, 1984-1985), 176-213, Pitman Res. Notes Math. Ser., 166, Longman Sci. Tech., Harlow, 1988.
- [199] G. Talenti, Elliptic equations and rearrangements, Ann. Scuola Norm. Sup. Pisa Cl. Sci., **3** (1976), no. 4, 697-718.
- [200] G. Talenti, On the first eigenvalue of the clamped plate, Ann. Mat. Pura Appl. (Ser. 4), **129** (1981), 265-280.
- [201] G. Talenti, Estimates for eigenvalues of Sturm-Liouville problems, General inequalities, **4** (Oberwolfach, 1983), 341-350, Internat. Schriftenreihe Numer. Math., 71, Birkh¨auser, Basel, 1984.
- [202] L. Tartar, Compensated compactness and applications to partial differential equations, Nonlinear analysis and mechanics: Heriot-Watt Symposium, Vol. IV, 136- 212, Res. Notes in Math., **39**, Pitman, Boston, Mass.-London, 1979.
- [203] B.A. Troesch, An isoperimetric sloshing problem, Comm. Pure Appl. Math., **18** (1965), 319-338.
- [204] B.A. Troesch, Elliptical Membranes with smallest second eigenvalue, Math. of Computation, **27**-124 (1973) 767-772.
- [205] N.S. Trudinger, Linear elliptic operators with measurable coefficients, Ann. Scuola Norm. Sup. Pisa, **27** no 3 (1973), 265-308.
- [206] E.J.M. Veling, Optimal lower bounds for the spectrum of a second order linear differential equation with a p-integrable coefficient, Proc. Roy. Soc. Edinburgh Sect. A, **92** (1982), no. 1-2, 95-101.

[207] H. F. Weinberger, An isoperimetric inequality for the N-dimensional free membrane problem, J. Rational Mech. Anal., **5** (1956), 633-636.

- [208] H. F. Weinberger, An effectless cutting of a vibrating membrane, Pacific J. Math., **13** (1963), 1239-1240.
- [209] R. Weinstock, Inequalities for a classical eigenvalue problem, J. Rational Mech. Anal., **3** (1954), 745-753.
- [210] C. Wieners, A numerical existence proof of nodal lines for the first eigenfunction of the plate equation, Arch. Math., **66** (1996), no. 5, 420-427.
- [211] B.E. Willner, T.J. Mahar, Extrema of functions of eigenvalues, J. Math. Anal. Appl., **72** (1979), no. 2, 730-739.
- [212] B.E. Willner, T.J. Mahar, The two-dimensional eigenvalue range and extremal eigenvalue problems, SIAM J. Math. Anal., **13** (1982), no. 4, 621-631.
- [213] S.A. Wolf, J.B. Keller, Range of the first two eigenvalues of the Laplacian, Proc. R. Soc. London A, **447** (1994), 397-412.
- [214] Q. Yu, J.Q. Zhong, Lower bounds of the gap between the first and second eigenvalues of the Schr¨odinger operator, Trans. Amer. Math. Soc., **294** (1986), no. 1, 341-349.
- [215] L. Zalcman, A bibliographic survey of the Pompeiu problem, Approximation by solutions of partial differential equations (Hanstholm, 1991), 185-194, NATO Adv. Sci. Inst. Ser. C Math. Phys. Sci., 365, Kluwer Acad. Publ., Dordrecht, 1992.

# **Index**

| analyticity,<br>9                                     | convexity<br>constraint,<br>63                       |
|-------------------------------------------------------|------------------------------------------------------|
| arc<br>of<br>circle,<br>53                            | Convoy<br>Principle,<br>145                          |
|                                                       |                                                      |
| bang-bang<br>function,<br>121,<br>142,<br>144,<br>156 | decreasing<br>rearrangement,<br>17                   |
| Bessel<br>functions,<br>11,<br>174                    | degenerate,<br>184                                   |
| bimodal,<br>184                                       | density,<br>141                                      |
| box<br>constraint,<br>52                              | derivative                                           |
| buckled<br>plate,<br>169,<br>174–180                  | (first)<br>of<br>a<br>Dirichlet<br>eigenvalue,<br>38 |
| capacity,<br>36                                       | of<br>a<br>multiple<br>eigenvalue,<br>37,<br>41,     |
| Chiti's<br>Lemma,<br>89                               | 44                                                   |
| clamped<br>plate,<br>169–174                          | of<br>a<br>Neumann<br>eigenvalue,<br>40              |
| column,<br>183                                        | of<br>eigenvalues,<br>44                             |
| commutation<br>formula,<br>136                        | of<br>the<br>volume,<br>39                           |
| concentration-compactness,<br>76,<br>177              | second,<br>40                                        |
| conjecture<br>of<br>P`olya,<br>51                     | with<br>respect<br>to<br>coefficients,<br>43         |
| connected                                             | with<br>respect<br>to<br>the<br>domain,<br>38–       |
| connectedness<br>constraint,<br>31,<br>63             | 43                                                   |
| connectedness<br>of<br>minimizers,<br>74              | derivatives                                          |
| non-connected<br>set,<br>6                            | of<br>eigenvalues,<br>37                             |
| constraint                                            | Dirichlet<br>problem,<br>3                           |
| (box),<br>52                                          | disconnected,<br>6                                   |
| (connectedness),<br>31,<br>63                         | disk,<br>10,<br>79                                   |
| (convex),<br>63                                       | double-well<br>potential,<br>127                     |
| on<br>the<br>volume,<br>8                             |                                                      |
| continuity                                            | elasticity,<br>33,<br>169                            |
| of<br>eigenvalues,<br>23–35,<br>142                   | elliptic<br>operator,<br>3                           |
| of<br>eigenvalues<br>for<br>elasticity,<br>33         | equilateral<br>triangle,<br>50                       |
| of<br>eigenvalues<br>for<br>general<br>opera          | existence<br>of<br>a<br>minimizer                    |
| tors,<br>33                                           | for<br>convex<br>domains,<br>35                      |
| of<br>Neumann<br>eigenvalues,<br>33                   | for<br>general<br>functionals,<br>37,<br>98          |
| with<br>respect<br>to<br>coefficients,<br>26          | for<br>λ<br>,<br>76                                  |
| with<br>respect<br>to<br>the<br>domain,<br>28         | 3<br>extremal<br>point,<br>124,<br>142               |
| continuous<br>Steiner<br>symmetrization,<br>21        |                                                      |
| convex<br>domains,<br>31,<br>35,<br>54                | Faber-Krahn's<br>inequality,<br>45                   |

Index 201

| first<br>derivative<br>of<br>a<br>Dirichlet<br>eigen | domains,<br>14                                                                     |
|------------------------------------------------------|------------------------------------------------------------------------------------|
| value,<br>38                                         | line,<br>15,<br>68                                                                 |
| Fredholm<br>alternative,<br>12                       | normalization,<br>6,<br>8                                                          |
| fundamental<br>gap,<br>117,<br>127–136               | optimal<br>insulation,<br>110                                                      |
| G-convergence,<br>168                                | optimality<br>condition,<br>39,<br>64                                              |
| γ-convergence,<br>23,<br>28,<br>33,<br>177           | over-determined<br>problem,<br>54,<br>180                                          |
| Γ-convergence,<br>29                                 |                                                                                    |
| gap,<br>99,<br>117,<br>127–136                       | perforated<br>domains,<br>15                                                       |
| Green<br>function,<br>163                            | p-Laplace<br>operator,<br>46                                                       |
|                                                      | plate,<br>169                                                                      |
| ground<br>state,<br>117                              | Poincar´e's<br>inequality,<br>2                                                    |
| Hardy-Littlewood's<br>inequality,<br>18,<br>20       | P`olya's<br>inequality,<br>18,<br>20                                               |
| Hausdorff<br>distance,<br>29                         | P`olya's<br>conjecture,<br>51                                                      |
| Hilbert-Schmidt<br>operator,<br>164                  | polygons,<br>46                                                                    |
| homogenization,<br>160,<br>168                       | Pompeiu<br>problem,<br>180                                                         |
| homothety,<br>8                                      | positivity                                                                         |
|                                                      | of<br>the<br>first<br>eigenfunction,<br>7,<br>14                                   |
| increasing<br>rearrangement,<br>124                  | Pr¨ufer<br>variables,<br>137                                                       |
| inequality                                           |                                                                                    |
| of<br>Faber-Krahn,<br>45                             | quantitative<br>estimates,<br>32                                                   |
| of<br>Hardy-Littlewood,<br>18,<br>20                 | quantum<br>mechanics,<br>117                                                       |
| of<br>Poincar´e,<br>2                                | quasi-open<br>set,<br>36                                                           |
| of<br>P`olya,<br>18,<br>20                           |                                                                                    |
| weighted<br>isoperimetric,<br>18                     | ratio<br>of<br>eigenvalues,<br>85–93,<br>136–139                                   |
| interior<br>parallels<br>(method<br>of),<br>55       | Rayleigh<br>quotient,<br>12                                                        |
|                                                      | rectangle,<br>10,<br>13                                                            |
| Lagrange<br>multiplier,<br>39                        | regularity                                                                         |
| Lipschitz<br>(uniform),<br>31                        | for<br>the<br>buckling<br>problem,<br>175<br>of<br>a<br>convex<br>minimizer,<br>67 |
| maximization<br>of<br>Neumann<br>eigenval            | up<br>to<br>the<br>boundary,<br>9                                                  |
| ues,<br>102                                          | Robin<br>boundary<br>condition,<br>106                                             |
| method<br>of<br>interior<br>parallels,<br>55         |                                                                                    |
| min-max<br>formulae,<br>12–13                        | Schwarz<br>rearrangement,<br>17–18,<br>46                                          |
| monotonicity<br>with<br>respect<br>to<br>inclu       | second<br>derivative,<br>40                                                        |
| sion,<br>13                                          | semi-classic<br>limit,<br>117                                                      |
| Mosco<br>convergence,<br>28,<br>177                  | semi-continuity<br>of<br>eigenvalues,<br>29,<br>30,                                |
| moving<br>plane<br>method,<br>59                     | 35,<br>118                                                                         |
| multi-connected<br>domains,<br>55                    | Serrin's<br>Theorem,<br>54                                                         |
|                                                      | simple<br>convergence<br>of<br>resolvants,<br>24,                                  |
| Neumann<br>boundary<br>condition,<br>101             | 34                                                                                 |
| Neumann<br>eigenvalue<br>(derivative<br>of<br>a),    | simplicity                                                                         |
| 40                                                   | of<br>eigenvalues,<br>41                                                           |
| Neumann<br>problem,<br>4                             | of<br>the<br>first<br>eigenvalue,<br>7,<br>15                                      |
| nodal                                                | single-barrier<br>potential,<br>130                                                |

202 Index

| single-well<br>potential,<br>127<br>sloshing,<br>163<br>Sobolev<br>space,<br>1<br>spectral<br>theory,<br>5<br>spherical<br>decreasing<br>rearrangement,<br>17<br>spherical<br>increasing<br>rearrangement,<br>88<br>square,<br>50<br>stadium,<br>63,<br>68<br>star-shaped<br>domains,<br>32,<br>54<br>Steiner<br>symmetric,<br>19,<br>123,<br>154<br>Steiner<br>symmetrization,<br>18–23,<br>50<br>Stekloff<br>eigenvalue<br>problem,<br>113<br>strongest<br>column,<br>146<br>sum<br>of<br>eigenvalues,<br>93<br>sum<br>of<br>inverses,<br>13,<br>94<br>Theorem<br>Ashbaugh-Benguria,<br>85,<br>90,<br>136,<br>138<br>Ashbaugh-Benguria-Nadirashvili,<br>171<br>Ashbaugh-Bucur,<br>177<br>Bossel-Daners,<br>107<br>Brock-Weinstock,<br>113<br>Bucur-Buttazzo-Figueiredo,<br>97,<br>98<br>Bucur-Henrot,<br>79<br>Buttazzo-Dal<br>Maso,<br>37,<br>73,<br>177<br>Chenais,<br>31,<br>35<br>Cox,<br>154<br>Cox-Kawohl-Uhlig,<br>111,<br>112<br>Cox-McLaughlin,<br>153,<br>155<br>Dittmar,<br>104<br>Essen,<br>126<br>Faber-Krahn,<br>45<br>Friedland,<br>143<br>Harrell-Kr¨oger-Kurata,<br>58,<br>60<br>Henrot-Oudet,<br>67<br>Hersch,<br>51,<br>57<br>Hersch-Payne-Schiffer,<br>114<br>Horv´ath,<br>127<br>Krahn-Szeg¨o,<br>61<br>Krein,<br>149,<br>150,<br>152<br>Krein-Rutman,<br>7 | Laugesen-Morpurgo,<br>95<br>Lavine,<br>130<br>Luttinger,<br>94<br>Payne-Weinberger,<br>55<br>P`olya,<br>50<br>P`olya-Schiffer,<br>95<br>Rellich,<br>2,<br>5,<br>6<br>ˇ<br>Sverak,<br>31<br>Szeg¨o,<br>104,<br>175<br>Szeg¨o-Weinberger,<br>102<br>Tahraoui,<br>155,<br>156<br>Talenti,<br>123,<br>172<br>Troesch,<br>164<br>Weinberger-Willms,<br>178<br>Wolff-Keller,<br>74<br>topological<br>derivative,<br>15<br>tunnelling<br>effect,<br>127<br>uniform<br>Lipschitz<br>condition,<br>31<br>unimodal,<br>184<br>union<br>of<br>two<br>balls,<br>62<br>volume<br>constraint,<br>8<br>weighted<br>isoperimetric<br>inequality,<br>18<br>Weinberger's<br>Lemma,<br>87<br>zeros<br>of<br>Bessel<br>functions,<br>11 |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|