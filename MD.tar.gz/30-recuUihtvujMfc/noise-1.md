# <span id="page-0-1"></span>MONOTONICITY OF POSITIVE SOLUTIONS TO SEMILINEAR ELLIPTIC EQUATIONS WITH MIXED BOUNDARY CONDITIONS IN TRIANGLES

#### RUI LI AND RUOFEI YAO

ABSTRACT. This paper investigates semilinear elliptic problems in planar triangles with Dirichlet conditions specified on one side of the boundary and Neumann conditions imposed on the remaining two sides. By employing moving plane method, we establish that the positive solution is monotone in the normal direction of the Dirichlet side when the Neumann vertex is non-obtuse. In the case where the Neumann vertex is obtuse, the positive solution is monotone in the normal direction of the longer Neumann side provided some technical conditions. Furthermore, this monotonicity property extends to the first mixed eigenfunction in triangles through continuity method via domain deformation. It is noteworthy that the maximum of the first positive eigenfunction in a triangle with mixed boundary conditions, consisting of two Neumann sides and one Dirichlet side, is uniquely located on the Neumann side with the greater length. This maximum point coincides with the Neumann vertex if and only if either the Neumann vertex is non-obtuse or the two Neumann sides have equal lengths. This result successfully resolves a specific problem posed within the Polymath project: Polymath7 research thread 1.

#### 1. Introduction

This paper is devoted to study the monotonicity properties of positive solutions for semilinear elliptic problems with mixed boundary conditions:

<span id="page-0-0"></span>
$$\begin{cases} \Delta u + f(u) = 0 & \text{in } \Omega, \\ u = 0 & \text{on } \Gamma_D, \\ \frac{\partial u}{\partial \nu} = 0 & \text{on } \Gamma_N \end{cases}$$
 (1.1)

where  $\Omega$  is a bounded domain in  $\mathbb{R}^n$ ,  $n \geq 2$ ,  $\Gamma_D$  is a closed subset of  $\partial\Omega$  and  $\Gamma_N = \partial\Omega \setminus \Gamma_D$ . Here  $\nu$  stands for the unit outer normal vector along  $\partial\Omega$ .

In the study of differential equations, it is frequently of interest to know whether solutions have symmetry or perhaps monotonicity in some direction. The research of monotonicity properties of the solutions is an important task that sometimes appears in many applications such as blow-up analysis, a-priori estimates and also in the proof of Liouville type theorems. These qualitative properties have been studied by many authors starting with the fundamental work of Alexandroff [1], who introduced the moving plane method, and also by Serrin [38]. The method of moving planes was developed by Gidas, Ni and Nirenberg [25, 26] to obtain a celebrated monotonicity and symmetry result in bounded or unbounded domains – in case the solutions are positive and vanish on the boundary or at infinity. This method was revisited in the influential paper [6, 7, 8] of Berestycki and Nirenberg. In [8], they generalized the method of moving planes and introduced the sliding method to prove the symmetry and monotonicity by a version of the maximum principle in domains of small volume. Qualitative properties of positive solutions were studied in a series

Date: February 1, 2024.

<sup>2010</sup> Mathematics Subject Classification. Primary 35J61, Secondary 35B06, 35M12, 35B50.

Key words and phrases. Semilinear elliptic equations; Monotonicity; Moving plane method; Continuity method.

<span id="page-1-3"></span>of papers due to Berestycki, Caffarelli and Nirenberg [2, 3, 4, 5]. After that, the symmetry and monotonicity of solutions have attracted widely attention in the academic community, see [11, 16, 18, 22, 23, 24, 28, 36] and the references therein.

Qualitative properties have also been studied for mixed boundary conditions. Berestycki and Nirenberg [6, 7] obtained the symmetry and monotonicity results for cylindrical domains. The second author [14] also showed 1-D symmetry results for half-cylindrical domains. Berestycki and Pacella [10] and Zhu [45] established radial symmetry results when the domain is a spherical sector, while radial symmetry results were further derived in [17, 21] when the domain is an infinite sectorial cone. In the fast few years, the authors [13, 15, 43, 44] obtained some symmetry and monotonicity results in mixed boundary problem in various types of bounded domains. In the realm of nonlinear mixed boundary problems, symmetry results have also been explored [19, 20, 40, 41] and the references therein.

The linear case of (1.1) is also very important. In 2012, the polymath project titled "The Hot Spots Conjecture for Acute Triangles" was introduced [37]. Over recent years, the primary objective of this project has been successfully addressed in [35]. Additionally, the second author has comprehensively characterized the properties of the second Neumann eigenfunction in [12]. Within the framework of the project [37], a specific question concerning the linear mixed problems in triangles is presented (e.g., comment 4 of Polymath7 research thread 1).

<span id="page-1-2"></span>**Conjecture 1.1** ([37]). The maximum of the first (positive) non-trivial eigenfunction for a triangle with mixed boundary conditions (two sides Neumann, and one side Dirichlet) occurs at the corner opposite to the Dirichlet side.

In this paper, we explore the monotonicity properties of the positive solution, denoted as u, in the context of the equation (1.1). Here, the nonlinearity term f is typically assumed to be locally Lipschitz continuity in  $\mathbb{R}$  (specifically,  $f \in \operatorname{Lip_{loc}}(\mathbb{R})$ ). We always assume that  $\Omega$  is an open triangle with  $\Gamma_D$  constituting one side of the triangle and  $\Gamma_N$  representing the union of the remaining two sides. Specifically, we denote the triangle as OAB, where the Dirichlet side is AB in the vertical direction. The vertex O serves as the origin and is positioned to the left of the side AB, and

$$\angle OAB = \alpha, \quad \angle OBA = \beta \text{ and } \angle AOB = \gamma = \pi - \alpha - \beta.$$
 (1.2)

See Figure 1 below. Through this paper, the vertex O is referred to as the Neumann vertex, while A stands for the lower mixed vertex, and B stands for the upper mixed vertex.

<span id="page-1-0"></span>**Theorem 1.2.** Let  $f \in \operatorname{Lip_{loc}}(\mathbb{R})$  and let  $\Omega$  and  $\Gamma_D$ ,  $\Gamma_N$  define as above. Let u be a positive solution of (1.1). If the two Neumann sides have equal lengths, then u must be symmetric with respect to the bisector line of  $\Gamma_N$  and monotone in the normal direction of  $\Gamma_D$ .

<span id="page-1-1"></span>**Theorem 1.3.** Under the same assumptions in Theorem 1.2, if the Neumann vertex is acute or right, then u must be monotone in the normal direction of  $\Gamma_D$ .

The above two results were announced in [12]. We now point out some remarks.

- (1) Both Theorem 1.2 and Theorem 1.3 are known to be true when Neumann vertex is right. This is a direct consequence derived from well-known results in [8, 25] via reflection along Neumann boundaries.
- (2) In the linear scenario, Theorem 1.3 holds true when the Dirichlet side forms a right angle with a Neumann side. This finding is rooted in the investigation of the hot spots conjecture for planar domains possessing two axes of symmetry, as detailed in [33, Theorem 1.1].

- <span id="page-2-3"></span>(3) In the linear case, these results can be simplified to the monotonicity property of the first mixed (Dirichlet-Neumann) eigenfunction. This can be obtained by the argument of continuity methods as in [\[33](#page-27-13)] and [\[34](#page-27-14)].
- (4) The qualitative properties, specifically the monotonicity, of the first mixed eigenfunction (which corresponds to the linear version of [Theorem 1.3\)](#page-1-1), can be used to derive certain mixed eigenvalue inequalities in triangles. Notably, the work of the second author [\[12](#page-26-16)] settles Conjecture 1.2 from [\[39\]](#page-27-15). These eigenvalue inequalities play a crucial role in establishing the complete form of the hot spots conjecture on triangles, as investigated in [\[12\]](#page-26-16).

In case of obtuse Neumann vertex, the solution u may not be monotone in the normal direction of ΓD. Nevertheless, it is possible to deduce monotonicity in some other direction.

<span id="page-2-1"></span>Theorem 1.4. *Under the same assumptions in* [Theorem 1.2](#page-1-0)*, if the Neumann vertex is obtuse and the angle* α, β *of two mixed vertices satisfy*

<span id="page-2-0"></span>
$$\max\{\alpha, \beta\} \ge \min\left\{\frac{\pi}{4}, \ 2\alpha + 2\beta - \frac{\pi}{2}\right\},\tag{1.3}$$

*then* u *is monotone in the fixed direction that is perpendicular to the middle side of triangle* Ω*. More precisely, the maximum point of* u *is achieved at the vertex opposite to* Γ<sup>D</sup> *if and only if the obtuse angle* Ω *is isosceles.*

Under the technical condition [\(1.3\)](#page-2-0), the monotonicity result is obtained in [Theorem 1.4.](#page-2-1) While for general range of angles α and β (without [\(1.3\)](#page-2-0)), we do not know whether the monotonicity results hold. However, such monotonicity result is true for the linear case.

<span id="page-2-2"></span>Theorem 1.5. *Let the same assumptions in* [Theorem 1.2](#page-1-0) *hold and let Neumann vertex be obtuse. If* f(u) *is linear, say* f(u) = µu*, then* u *has the following properties:*

- (1) u *is monotone in the normal direction to the middle side of the triangle* Ω*.*
- (2) *The non-vertex critical point of* u *(if exists) is unique and non-degenerate and lies in the interior of the middle side.*
- (3) *The maximum point of* u *lies at the vertex if and only if the obtuse angle* Ω *is isosceles.*

Comparing with [Conjecture 1.1,](#page-1-2) we observe that [Theorem 1.2](#page-1-0) and [Theorem 1.3](#page-1-1) provide a resolution to this conjecture in the semilinear case for a non-obtuse Neumann vertex. Meanwhile, [Theorem 1.4](#page-2-1) offers a partial answer to the correct formulation of this conjecture in the semilinear case for an obtuse Neumann vertex, subject to the additional condition [\(1.3\)](#page-2-0). Ultimately, [Theorem 1.4](#page-2-1) confirms the accurate formulation of this conjecture for an obtuse Neumann vertex. Combining all the aforementioned results, we conclusively settle the correct form of [Conjecture 1.1.](#page-1-2)

Corollary 1.6. *Let* u *be the first (positive) eigenfunction for a triangle with mixed (one side Dirichlet, and two sides Neumann) boundary conditions. Then we have*

- (1) u *is monotone in the normal direction to the middle side of the triangle;*
- (2) *the maximum point of* u *is unique and lies on the longer Neumann (closed) side;*
- (3) *the maximum point occurs at the vertex opposite to the Dirichlet side if and only if either the Neumann vertex is non-obtuse or the two Neumann sides has the same length.*

It is noteworthy that for an obtuse Neumann vertex and a non-isosceles triangle, the maximum of the eigenfunction is uniquely and exclusively located within the interior of the longer Neumann side. Additionally, it is worth mentioning that some properties of the first mixed Laplace eigenfunction are also studied in a recent paper [\[30](#page-27-16)].

<span id="page-3-4"></span>The proof of Theorem 1.2, Theorem 1.3 and Theorem 1.4 relies on the application of moving plane method [25] and certain versions of the maximum principle for mixed boundary problems, as presented in [43, 44]. In the proof of Theorem 1.4, the local behavior [27] and the structure of the nodal line [29, 32] near conical points are involved and serve as pivotal elements. The linear case and the verification of Theorem 1.5 are achieved through the implementation of continuity methods via domain deformation, as outlined in [33].

The paper is structured as follows. In section 2, we state some preliminaries about maximum principle and monotonicity property near the boundary. The detailed proofs are presented in the remaining sections. Specifically, in section 3, we define moving lines and moving domains, crucial components for our proof, and proceed to establish Theorem 1.3. In section 4, we address isosceles triangles and provide the proof for Theorem 1.2, while in section 5, our focus shifts to obtuse triangles, and we present the proof for Theorem 1.4. Finally, in section 6, we employ continuity methods via domain deformation to obtain Theorem 1.5.

#### 2. Some preliminaries

<span id="page-3-0"></span>In this section, we state some preliminaries including maximum principle, and monotonicity property near the boundary.

<span id="page-3-3"></span>**Lemma 2.1.** Assume that  $\Omega \subset \mathbb{R}^n$  is a bounded domain,  $\partial \Omega = \Gamma_0 \cup \Gamma_1$ ,  $\Gamma_0$  is relatively closed subset, and  $\Gamma_1$  is Lipschitz and  $\nu(x)$  is the unit outer normal vector on  $\Gamma_1$ . Suppose that

<span id="page-3-1"></span>
$$\begin{cases} \Delta v + c(x)v \leq 0 & \text{in } \Omega, \\ v \geq 0 & \text{on } \Gamma_0, \\ \frac{\partial v}{\partial \nu} \geq 0 & \text{on } \Gamma_1 \end{cases}$$
 (2.1)

where  $\nu$  is the unit outward normal vector to  $\Gamma_1$ ,  $\sup_{\Omega} |c| < c_0$ . If  $\Omega$  and  $\Gamma_1$  satisfies the following conditions

- (1)  $\Omega \cup \Gamma_1 \subset \{x \in \mathbb{R}^n : 0 < x_1\};$
- (2)  $\nu \cdot e_1 \geq 0$  on  $\Gamma_1$  where  $e_1 = (1, 0, \dots, 0)$  is the unit vector in  $\mathbb{R}^n$ ; (3)  $\Omega \subset \{x : x \cdot e_1 < \eta\}$  where  $\eta = \pi/(2\sqrt{c_0})$ .

Then v > 0 in  $\Omega$ .

*Proof.* We construct a positive upper solution related to (2.1):

$$g(x) = \sin \frac{\pi x_1}{2n}.$$

Then g is positive in  $\overline{\Omega} \setminus \{x_1 = 0\}$  and satisfies

$$\begin{cases} \Delta g + c(x)g < 0 & \text{ in } \Omega, \\ \nabla g \cdot e_1 \ge 0 & \text{ on } \Gamma_1. \end{cases}$$

Now following by Lemma 6 and Lemma 7 in [44], we conclude that v is nonnegative in  $\Omega$ . 

**Remark 2.2.** If the double domain  $\tilde{\Omega}$ , which is obtained by mirroring  $\Omega$  along hyperplane  $\{x_1 =$ 0}, is convex, then  $\Omega$  satisfies  $\nu \cdot e_1 \geq 0$  on  $\Gamma_1$ .

Next, we state two useful lemmas from [25], [10] about the monotonicity near the Dirichlet boundary and Neumann boundary. We consider a solution u(x) of the equation

<span id="page-3-2"></span>
$$\Delta u + f(u) = 0 \text{ in } \Omega, \tag{2.2}$$

where f is a local Lipschitz continuous function and  $\Omega$  is a bounded domain.

<span id="page-4-3"></span><span id="page-4-2"></span>**Lemma 2.3.** Let  $\bar{x} \in \partial \Omega$  and let  $\nu(\bar{x})$  be the outer unit normal vector at the point  $\bar{x} \in \partial \Omega$ . Let  $\gamma$  be a unit vector in  $\mathbb{R}^n$  satisfying  $\nu(\bar{x}) \cdot \gamma > 0$ . For some  $\varepsilon > 0$  assume that u is a  $C^2$  solution in  $\overline{\Omega}_{\varepsilon}$  of (2.2) where  $\Omega_{\varepsilon} = \Omega \cap \{|x - \bar{x}| < \varepsilon\}$ ,

$$u \geq 0$$
,  $u \not\equiv 0$  in  $\Omega_{\varepsilon}$  and  $u = 0$  on  $\Gamma_{\varepsilon} = \partial \Omega \cap \{|x - \bar{x}| < \varepsilon\}$ .

Moreover, suppose that the boundary  $\Gamma_{\varepsilon}$  is  $C^2$ . Then there exists a  $\delta > 0$  such that

$$\frac{\partial u}{\partial \gamma} < 0 \text{ in } \Omega_{\delta} = \Omega \cap \{|x - \bar{x}| < \delta\}.$$

*Proof.* The readers can find the proof in [25, Lemma 2.1].

This is an useful lemma, which shows the monotonicity property of the solution near the Dirichlet boundary. While for the monotonicity property on the Neumann boundary, one can refer to the following result.

<span id="page-4-1"></span>**Lemma 2.4.** Assume that  $\bar{x} = (\bar{x}_1, \dots, \bar{x}_n) \in \partial\Omega$  and  $\Omega_{\varepsilon}(\bar{x}) = B_{\varepsilon}^+(\bar{x})$  for some  $\varepsilon > 0$  where  $\Omega_{\varepsilon}(\bar{x}) = \Omega \cap B_{\varepsilon}(\bar{x})$  and  $B_{\varepsilon}^+(\bar{x}) = B_{\varepsilon}(\bar{x}) \cap \{x_1 > \bar{x}_1\}$ . Suppose that u is a  $C^2$  solution in  $\overline{\Omega}_{\varepsilon}(\bar{x})$  of (2.2) satisfying Neumann boundary condition

$$\partial_{x_1} u = 0 \text{ on } B_{\varepsilon}(\bar{x}) \cap \{x_1 = \bar{x}_1\}$$

and

$$u(x', x_n) < u(x', 2\bar{x}_n - x_n)$$
 for  $x \in \Omega_{\varepsilon}(\bar{x})$  and  $x_n > \bar{x}_n$ .

Then

$$\frac{\partial u}{\partial x_n}(\bar{x}) < 0.$$

<span id="page-4-0"></span>*Proof.* This can be proved by using Serrin's boundary lemma [25, 38]. The readers can find the details in the proof of [10, Theorem 2.4].  $\Box$ 

## 3. The proof of monotonicity for non-obtuse Neumann vertex

In this section, we establish the monotonicity result when the two Neumann boundaries form an acute or right angle. At the beginning of this section, we introduce some notations related to moving lines and moving domains, which will be consistently used throughout the paper.

For simplicity, we always assume that the mixed boundary point is located at the origin (0,0), and the Dirichlet boundary, denoted as  $\Gamma_D$ , is contained in the vertical line  $\{x_1=1\}$ . Let  $\Gamma_N^- = \Gamma_N \cap \{x_2 < 0\}$  and  $\Gamma_N^+ = \Gamma_N \cap \{x_2 > 0\}$  denote the lower Neumann boundary and upper Neumann boundary. The angles formed by the lower and upper Neumann boundaries with the Dirichlet boundary are denoted as  $\angle OAB = \alpha$  and  $\angle OBA = \beta$ , respectively. Denote  $\gamma = \pi - \alpha - \beta$ . Consequently, the lengths of the lower and upper Neumann boundaries are expressed as

$$\Phi_0 = \csc \alpha$$
 and  $\Psi_0 = \csc \beta$ .

Let  $P_{\lambda}=(\lambda \sin \alpha, -\lambda \cos \alpha)$  be a point on the line containing  $\Gamma_N^-$ . Let us define by  $T_{\lambda,\vartheta}$  the moving line that passing through  $P_{\lambda}$  which forms with the lower boundary  $\Gamma_N^-$  an angle  $\vartheta \in [0,\pi]$ , that is,

$$T_{\lambda,\vartheta} = \{ x \in \mathbb{R}^2 : (x - P_\lambda) \cdot e_{\vartheta + \alpha - \pi} = 0 \}$$

(where  $e_{\theta} = (\cos \theta, \sin \theta)$  is the unit vector) or

$$T_{\lambda,\vartheta} = \{ x \in \mathbb{R}^2 : (x_1 - \lambda \sin \alpha) \cos(\vartheta + \alpha) + (x_2 + \lambda \cos \alpha) \sin(\vartheta + \alpha) = 0 \},$$

see Figure 1. The right open cap cut out in  $\Omega$  by  $T_{\lambda,\vartheta}$  will be denoted by  $\Omega_{\lambda,\vartheta}$ , i.e.,  $\Omega_{\lambda,\vartheta}=\{x\in\Omega: (x-P_\lambda)\cdot e_{\vartheta+\alpha}<0\}$ . As usual,  $(\Gamma_N)', (\Gamma_N^-)', (\Gamma_N^+)'$  will be the reflection of  $\Gamma_N, \Gamma_N^-, \Gamma_N^+$  with respect to  $T_{\lambda,\vartheta}$ , respectively. Similarly, we denote  $Q_\lambda=(\lambda\sin\beta,\lambda\cos\beta)$  and  $\hat{T}_{\lambda,\vartheta}$  by the moving line that passing through  $Q_\lambda$  which forms with the upper boundary  $\Gamma_N^+$  an angle  $\vartheta\in[0,\pi]$ , that is,

$$\hat{T}_{\lambda,\vartheta} = \{ x \in \mathbb{R}^2 : (x - Q_\lambda) \cdot e_{\pi - \beta - \vartheta} = 0 \}$$
$$= \{ x \in \mathbb{R}^2 : (x_1 - \lambda \sin \beta) \cos(\vartheta + \beta) - (x_2 - \lambda \cos \beta) \sin(\vartheta + \beta) = 0 \}.$$

The purpose is to show

<span id="page-5-1"></span>
$$\nabla u \cdot e_{\vartheta + \alpha} > 0 \text{ on } \Omega \cap T_{\lambda,\vartheta}, \tag{3.1}$$

<span id="page-5-2"></span>
$$\nabla u \cdot e_{-\vartheta - \beta} > 0 \text{ on } \Omega \cap \hat{T}_{\lambda,\vartheta} \tag{3.2}$$

for  $\lambda > 0$  and suitable  $\vartheta \in (0, \pi)$ . The proofs of (3.1) and (3.2) are analogous; therefore, our attention is primarily directed towards establishing (3.1).

In order to show the monotonicity properties (3.1) and (3.2), we will employ the well-known moving plane methods and use a new moving domain instead of the caps  $\Omega_{\lambda,\vartheta}$ . So for  $\lambda \geq 0$  and  $0 < \vartheta < \pi$ , we consider a family of moving domains  $D_{\lambda,\vartheta}$  as follows

$$D_{\lambda,\vartheta} = \{ x \in \Omega : \ x^{\lambda,\vartheta} \in \Omega \text{ and } (x - P_\lambda) \cdot e_{\vartheta + \alpha} < 0 \}.$$
 (3.3)

where  $x^{\lambda,\vartheta}$  stands for the reflection point of  $x \in \mathbb{R}^2$  with respect to  $T_{\lambda,\vartheta}$ , see  $\vartheta = \pi/2$  in the left picture of Figure 1. The aim is

<span id="page-5-4"></span>
$$w^{\lambda,\vartheta} = u^{\lambda,\vartheta} - u > 0 \text{ in } D_{\lambda,\vartheta} \tag{3.4}$$

where  $u^{\lambda,\vartheta}(x)=u(x^{\lambda,\vartheta})$ . Due to the fact that  $w^{\lambda,\vartheta}$  may not satisfy some a prior boundary conditions on  $\partial D_{\lambda,\vartheta}\cap\Omega$ , we will opt to employ a smaller domain than  $D_{\lambda,\vartheta}$ .

![](_page_5_Picture_13.jpeg)

FIGURE 1. The moving lines  $T_{\lambda,\vartheta}$  and moving domains  $D_{\lambda,\vartheta,\vartheta_1}$ 

For  $\lambda \geq 0$ ,  $\vartheta \in (0, \pi)$ , and  $0 \leq \vartheta_1 < \vartheta_3 \leq \pi$  with  $\vartheta_1 + \vartheta_3 = 2\vartheta$ , we consider a family of moving domains  $D_{\lambda,\vartheta,\vartheta_1}$  instead of the right cap  $\Omega_{\lambda,\vartheta}$  as follows

$$D_{\lambda,\vartheta,\vartheta_1} = \{ x \in \Omega : \ x^{\lambda,\vartheta} \in \Omega \text{ and } (x - P_\lambda) \cdot e_{\vartheta + \alpha} < 0 < (x - P_\lambda) \cdot e_{\vartheta_1 + \alpha} \}$$
 (3.5)

(see Figure 1) and we want to show

<span id="page-5-3"></span><span id="page-5-0"></span>
$$w^{\lambda,\vartheta} = u^{\lambda,\vartheta} - u > 0 \text{ in } D_{\lambda,\vartheta,\vartheta_1}. \tag{3.6}$$

We point out that (i)  $D_{\lambda,\vartheta}\supset D_{\lambda,\vartheta,\vartheta_1}$  and both  $D_{\lambda,\vartheta}$  and  $D_{\lambda,\vartheta,\vartheta_1}$  are subsets of the right cap  $\Omega_{\lambda,\vartheta}$ ; (ii) both  $\partial D_{\lambda,\vartheta}$  and  $\partial D_{\lambda,\vartheta,\vartheta_1}$  contain  $T_{\lambda,\vartheta}\cap\Omega$ ; (iii)  $D_{\lambda,\vartheta}=D_{\lambda,\vartheta,\vartheta_1}$  whenever  $\vartheta_1=\max\{0,2\vartheta-\pi\}$ .

We also denote by  $\nu$  the outward normal to  $D_{\lambda,\vartheta,\vartheta_1}$  on  $\partial D_{\lambda,\vartheta,\vartheta_1}$ . The boundary  $\partial D_{\lambda,\vartheta,\vartheta_1}$  consists of three parts:

- (1)  $\Gamma^0_{\lambda,\vartheta,\vartheta_1} = T_{\lambda,\vartheta} \cap \partial D_{\lambda,\vartheta,\vartheta_1}$ , this is always non-empty when  $D_{\lambda,\vartheta,\vartheta_1}$  is nonempty.
- (2)  $\Gamma_{\lambda,\vartheta,\vartheta_1}^{\Gamma_1} = (\Gamma_D \cup \Gamma_D') \cap (\partial D_{\lambda,\vartheta,\vartheta_1} \setminus T_{\lambda,\vartheta})$ , this is contained in  $\Gamma_D$  since we always assume  $\lambda > 0$ and  $\vartheta \in [\pi/2 - \alpha, \pi)$ .
- (3)  $\Gamma^2_{\lambda,\vartheta,\vartheta_1} = \partial D_{\lambda,\vartheta,\vartheta_1} \setminus (\Gamma^0_{\lambda,\vartheta,\vartheta_1} \cup \Gamma^1_{\lambda,\vartheta,\vartheta_1}).$

 $\Gamma^2_{\lambda,\vartheta,\vartheta_1} \text{ is the boundary related to } \Gamma_N \cup T_{\lambda,\vartheta_1} \text{ and its reflection, and it consists of two parts: } \Gamma^{2A}_{\lambda,\vartheta,\vartheta_1} = \Gamma^2_{\lambda,\vartheta,\vartheta_1} \cap \left(\Gamma^-_N \cup (\Gamma^-_N)' \cup T_{\lambda,\vartheta_1}\right) \text{ and } \Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} = \Gamma^2_{\lambda,\vartheta,\vartheta_1} \cap \left(\Gamma^+_N \cup (\Gamma^+_N)'\right). \text{ Moreover, } \Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} \text{ is a line } \Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} = \Gamma^2_{\lambda,\vartheta,\vartheta_1} \cap \left(\Gamma^-_N \cup (\Gamma^-_N)' \cup T_{\lambda,\vartheta_1}\right)$ segment and is contained in  $T_{\check{\lambda},\check{\vartheta}}=\hat{T}_{\hat{\lambda},\hat{\vartheta}}$ . Here  $T_{\check{\lambda},\check{\vartheta}}=\hat{T}_{\hat{\lambda},\hat{\vartheta}}$  stands for the line related to the reflection of the upper boundary  $\Gamma_N^+$  w.r.t.  $T_{\lambda,\vartheta}$  where  $\check{\vartheta}=2\vartheta-\gamma,\,\hat{\vartheta}=\pi-2\vartheta+2\gamma,\,\hat{\lambda}$  and  $\check{\lambda}$ depend on  $\lambda, \vartheta$ :

$$\hat{\lambda} = \hat{\lambda}(\lambda, \vartheta) = \frac{\lambda \sin \vartheta}{\sin(\vartheta - \gamma)}, \quad \check{\lambda} = \check{\lambda}(\lambda, \vartheta) = \lambda + \frac{\lambda \sin \gamma}{\sin(2\vartheta - \gamma)}.$$
 (3.7)

It is clear that  $D_{\lambda,\vartheta,\vartheta_1}$  is a triangle or quadrilateral,  $D_{\lambda,\vartheta,\vartheta_1}\supset D_{\lambda,\vartheta,\vartheta_1'}$  and  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1}\supset \Gamma^{2B}_{\lambda,\vartheta,\vartheta_1'}$  for  $\lambda \geq 0$  and  $\pi \geq \vartheta > \vartheta_1' > \vartheta_1 \geq 0$ . For simplicity, we omit the subscripts  $\vartheta, \vartheta_1$  and denote these notations by  $\Gamma^{0}_{\lambda}$ ,  $\Gamma^{1}_{\lambda}$ ,  $\Gamma^{2}_{\lambda}$ ,  $\Gamma^{2A}_{\lambda}$ , and  $\Gamma^{2B}_{\lambda}$ . Clearly,  $w^{\lambda,\vartheta}$  satisfies

$$\begin{cases} \Delta w^{\lambda,\vartheta} + c^{\lambda,\vartheta}(x)w^{\lambda,\vartheta} = 0 & \text{ in } D_{\lambda,\vartheta,\vartheta_1}, \\ w^{\lambda,\vartheta} = 0 & \text{ on } \Gamma^0_\lambda, \\ w^{\lambda,\vartheta} > 0 & \text{ on } \Gamma^1_\lambda \text{ when } \vartheta > \pi/2 - \alpha, \\ w^{\lambda,\vartheta} = 0 & \text{ on } \Gamma^1_\lambda \text{ when } \vartheta = \pi/2 - \alpha \end{cases}$$

for  $\lambda > 0$  and

$$\max\{\pi/2 - \alpha, 0\} \le \vartheta < \pi.$$

where

$$c^{\lambda,\vartheta}(x) = \frac{f(u^{\lambda,\vartheta}(x)) - f(u(x))}{u^{\lambda,\vartheta}(x) - u(x)}$$

is a uniformly (w.r.t.  $\lambda, \vartheta$ ) bounded function, say,  $|c^{\lambda,\vartheta}| < c_0$  for some constant  $c_0 > 0$ . It is not easy to find an a prior boundary condition for  $w^{\lambda,\theta}$  on  $\Gamma^2_{\lambda}$ . This is the main difficulty and task in proving the positivity of  $w^{\lambda,\theta}$ .

At a start, we show the moving plane will move forward with an a prior boundary condition for  $w^{\lambda,\theta}$  on  $\Gamma^2_{\lambda}$ .

<span id="page-6-1"></span>**Lemma 3.1.** Let us fix any  $\vartheta \in (0,\pi)$  with  $\vartheta \geq \pi/2 - \alpha$ ,  $\max\{2\vartheta - \pi, 0\} \leq \vartheta_1 < \vartheta$  and  $\Lambda \in (0, \lambda_M(\vartheta))$  where

$$\lambda_M(\vartheta) = \sup\{\lambda \in \mathbb{R} : T_{\lambda,\vartheta} \cap \Omega = \emptyset\}.$$

<span id="page-6-0"></span>Suppose that

$$\Delta w^{\lambda,\vartheta} + c^{\lambda,\vartheta} w^{\lambda,\vartheta} = 0 \text{ in } D_{\lambda,\vartheta,\vartheta_1}$$
(3.8a)

$$w^{\lambda,\vartheta} = 0 \text{ on } \Gamma^0_{\lambda,\vartheta,\vartheta_1}, \tag{3.8b}$$

$$w^{\lambda,\vartheta} \ge 0 \text{ on } \Gamma^1_{\lambda,\vartheta,\vartheta_1},$$
 (3.8c)

$$\nabla w^{\lambda,\vartheta} \cdot \nu \ge 0 \text{ on } \Gamma^2_{\lambda,\vartheta,\vartheta_1}, \tag{3.8d}$$

$$w^{\lambda,\vartheta} \not\equiv 0 \text{ in } D_{\lambda,\vartheta,\vartheta_1}.$$
 (3.8e)

<span id="page-7-2"></span>holds for every  $\lambda > \Lambda$ . Then (3.6) and (3.1) are valid for every  $\lambda > \Lambda$ .

*Proof.* By the definition of moving domain  $D_{\lambda,\vartheta,\vartheta_1}$ , we see that the closure of the union of  $D_{\lambda,\vartheta,\vartheta_1}$  and its reflection  $(D_{\lambda,\vartheta,\vartheta_1})'$  (w.r.t.  $T_{\lambda,\vartheta}$ ) is convex, so the second condition in Lemma 2.1 is obviously satisfied.

Step 1: The start of the moving plane methods. Let  $\eta$  be the small constant that the maximum principle holds for Dirichlet boundary conditions or mixed boundary conditions when the domain width is less than  $\eta$ . From the definition of  $D_{\lambda,\vartheta,\vartheta_1}$ , we see that there exists a  $\varepsilon_1 > 0$  such that for every  $\lambda \in (\lambda_M(\vartheta) - \varepsilon_1, \lambda_M(\vartheta))$ ,

$$D_{\lambda,\vartheta,\vartheta_1} \subset \{x : \operatorname{dist}(x,T_{\lambda,\vartheta}) < \eta\}.$$

Applying the maximum principle with mixed boundary conditions in Lemma 2.1, we deduce the positivity of  $w^{\lambda,\vartheta}$  in  $D_{\lambda,\vartheta,\vartheta_1}$ . Moreover, Applying the Hopf boundary lemma to  $w^{\lambda,\vartheta}$ , one gets (3.1). Therefore, (3.6) and (3.1) hold for  $\lambda_M(\vartheta) - \varepsilon_1 < \lambda < \lambda_M(\vartheta)$ .

Step 2: (3.6) and (3.1) hold for every  $\lambda \geq \Lambda$ . We argue by contradiction and suppose that  $\bar{\lambda} > \Lambda$  where  $\bar{\lambda}$  be

$$\bar{\lambda} = \inf\{\lambda' > 0 : (3.6) \text{ and } (3.1) \text{ hold for every } \lambda \geq \lambda'\}.$$

By continuity, we have  $w^{\bar{\lambda},\vartheta} \geq 0$  in  $D_{\bar{\lambda},\vartheta}$ . By the strong maximum principle and Hopf boundary lemma, we derive the positivity of  $w^{\bar{\lambda},\vartheta}$  in  $D_{\bar{\lambda},\vartheta}$  and on the smooth boundary points of  $\Gamma^2_{\bar{\lambda},\vartheta}$ . Observing that  $\Gamma^2_{\lambda,\vartheta,\vartheta_1}$  may contain non-smooth boundary point, where these points are corners and formed by two lines, one can also check that  $w^{\lambda,\vartheta}$  is also positive at these points (see [43, Remark 1]). Hence, for  $\lambda \geq \Lambda$ ,

<span id="page-7-1"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } \overline{D_{\lambda,\vartheta,\vartheta_1}} \setminus T_{\lambda,\vartheta} \text{ if } \vartheta \in (\pi/2 - \alpha, \pi),$$

$$w^{\lambda,\vartheta} > 0 \text{ in } \overline{D_{\lambda,\vartheta,\vartheta_1}} \setminus (T_{\lambda,\vartheta} \cup \Gamma^1_{\lambda,\vartheta,\vartheta_1}) \text{ if } \vartheta = \pi/2 - \alpha,$$
(3.9)

and

$$\nabla u \cdot e_{\vartheta + \alpha} > 0 \text{ on } T_{\bar{\lambda},\vartheta} \cap \Omega.$$

![](_page_7_Figure_13.jpeg)

<span id="page-7-0"></span>FIGURE 2. The domain  $D_1$ ,  $D_2$  and  $D_3$ 

<span id="page-8-4"></span>We assume that  $\Gamma_D \cap T_{\bar{\lambda},\vartheta}$  (it belongs to  $\partial D_{\bar{\lambda},\vartheta,\vartheta_1}$ ) is non-empty is contained  $\partial D_{\bar{\lambda},\vartheta,\vartheta_1}$ , while it can be considered similarly and easily when  $\Gamma_D \cap T_{\bar{\lambda},\vartheta} = \emptyset$ . Let us denote  $\bar{x} = (\bar{x}_1,\bar{x}_2)$  by the unique point of  $\Gamma_D \cap T_{\bar{\lambda},\vartheta} \subset \partial D_{\bar{\lambda},\vartheta,\vartheta_1}$  and let  $P_{\bar{\lambda}} = (\bar{\lambda}\sin\alpha, -\bar{\lambda}\cos\alpha)$ .

Let us fix any  $\delta_1, \delta_2 \in (0, \eta)$  and  $\delta_3 > 0$  such that  $\delta_2 < \delta_1$  and  $T_{\bar{\lambda}, \vartheta} \cap L_0$  is contained in  $\Omega \cap \{x : -\delta_1 < (x - \bar{x}) \cdot e_0 < -\delta_2\}$  where the line  $L_0 = \{(x - \bar{x}) \cdot e_{\vartheta + \alpha - \pi/2} = -\delta_3\}$  is perpendicular to  $T_{\bar{\lambda}, \vartheta}$ . Since (3.1) is valid for  $\lambda \geq \bar{\lambda}$ , it follows by continuity of  $\nabla u$  that there exists a small constant  $\delta_4 \in (0, \eta/3)$  such that

$$\nabla u \cdot e_{\vartheta + \alpha} > 0 \text{ on } \{x \in L_0 : |(x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha}| \le 3\delta_4 \}$$

and hence

<span id="page-8-0"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } D_{\lambda,\vartheta,\vartheta_1} \cap \{x \in L_0 : |(x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha}| \le \delta_4\} \text{ for } |\lambda - \bar{\lambda}| < \delta_4. \tag{3.10}$$

Set

$$\mathcal{D}_{1} = \left\{ x \in \Omega : \left| (x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha} \right| \leq \delta_{4}, \quad (x - \bar{x}) \cdot e_{\vartheta + \alpha - \pi/2} \leq -\delta_{3} \right\},$$

$$\mathcal{D}_{2} = \left\{ x \in \Omega : \left| (x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha} \leq \delta_{4}, \quad (x - \bar{x}) \cdot e_{0} \geq -\delta_{1} \right\},$$

$$\mathcal{D}_{3} = \left\{ x \in \Omega : \left| (x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha} \leq -\delta_{4}, \quad (x - \bar{x}) \cdot e_{0} \leq -\delta_{2} \right\}.$$

It is clear that  $\mathcal{D}_1 \cup \mathcal{D}_2 \cup \mathcal{D}_3 = \{x \in \Omega : (x - P_{\bar{\lambda}}) \cdot e_{\vartheta + \alpha} \leq \delta_4\}$ ; see Figure 2. From (3.9),  $w^{\bar{\lambda},\vartheta}$  is positive in the compact set  $\overline{\mathcal{D}_3} \cap \overline{D_{\bar{\lambda},\vartheta,\vartheta_1}}$ . It follows by continuity that there exists a small constant  $\varepsilon_2 > 0$  (assuming  $\varepsilon_2 < \delta_4$ ) such that

<span id="page-8-1"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } \overline{D_{\lambda,\vartheta,\vartheta_1}} \cap \overline{\mathcal{D}_3} \text{ if } \lambda \in (\bar{\lambda} - \varepsilon_2, \bar{\lambda}).$$
 (3.11)

Now let  $\lambda \in (\bar{\lambda} - \varepsilon_2, \bar{\lambda})$ . From (3.10) and (3.11),  $w^{\lambda, \vartheta}$  satisfies

<span id="page-8-2"></span>
$$\begin{cases} \Delta w^{\lambda,\vartheta} + c^{\lambda,\vartheta} w^{\lambda,\vartheta} = 0 & \text{in } D_{\lambda,\vartheta,\vartheta_1} \cap \mathcal{D}_j \\ w^{\lambda,\vartheta} \geq \neq 0 & \text{on } \partial(D_{\lambda,\vartheta,\vartheta_1} \cap \mathcal{D}_j) \setminus \Gamma_{\lambda}^2, \\ \nabla w^{\lambda,\vartheta} \cdot \nu \geq 0 & \text{on } \partial(D_{\lambda,\vartheta,\vartheta_1} \cap \mathcal{D}_j) \cap \Gamma_{\lambda}^2 \end{cases}$$
(3.12)

for j = 1. By applying the maximum principle in Lemma 2.1, we derive that

<span id="page-8-3"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } D_{\lambda,\vartheta,\vartheta_1} \cap \mathcal{D}_j \tag{3.13}$$

for j=1. Based on this and (3.10) and (3.11),  $w^{\lambda,\vartheta}$  satisfies (3.12) for j=2. Hence the maximum principle in Lemma 2.1 also implies that (3.13) is valid for j=2. Again Hopf lemma implies that (3.6) and (3.1) are valid for  $\lambda \in (\bar{\lambda} - \varepsilon_2, \bar{\lambda})$ .

We reach a contradiction to the definition of  $\bar{\lambda}$ . Hence  $\bar{\lambda} \leq \Lambda$ , (3.6) and (3.1) hold for every  $\lambda > \Lambda$ . Now from the beginning of the proof of step 2, one deduce that (3.6) and (3.1) hold for  $\lambda = \Lambda$ . The proof is finished.

**Remarks.** The proof of above lemma use maximum principle for narrow domain in Lemma 2.1. One can give a simple argument by using the maximum principle in domains of small volume with two flat Neumann boundaries. Indeed, let  $\eta$  be the small constant in [42, Lemma 2.3]. Let K be a fixed compact set and  $\varepsilon_1 > 0$  such that  $D_{\lambda,\vartheta,\vartheta_1} \supset K$  and  $|D_{\lambda,\vartheta,\vartheta_1} \setminus K| < \eta \gamma$  for  $|\lambda - \bar{\lambda}| < \varepsilon_1$ . From the positivity of  $w^{\bar{\lambda},\vartheta}$ , we get that  $w^{\lambda,\vartheta} > 0$  in K for every  $\lambda \in [\bar{\lambda} - \varepsilon_2, \bar{\lambda} + \varepsilon_2]$  where  $\varepsilon_2 \in (0,\varepsilon_1)$  is a small constant. Now in the rest of the domain  $\mathcal{D} = D_{\lambda,\vartheta,\vartheta_1} \setminus K$ ,  $w^{\lambda,\vartheta}$  satisfies

$$\Delta w^{\lambda,\vartheta} + c^{\lambda,\vartheta} w^{\lambda,\vartheta} = 0 \text{ in } \mathcal{D}, \quad \partial_{\nu} w^{\lambda,\vartheta} \geq 0 \text{ on } \Gamma^2_{\lambda,\vartheta,\vartheta_1} \subset \partial \mathcal{D}, \quad w^{\lambda,\vartheta} \geq 0, \neq 0 \text{ on } \partial \mathcal{D} \setminus \Gamma^2_{\lambda,\vartheta,\vartheta_1}.$$

<span id="page-9-6"></span>The maximum principle in [42, Lemma 2.3] implies that the nonnegativity of  $w^{\lambda,\vartheta}$  in  $\mathcal{D} = D_{\lambda,\vartheta,\vartheta_1} \setminus K$  and hence in  $D_{\lambda,\vartheta,\vartheta_1}$ . Again the strong maximum principle implies that (3.6) and (3.1) valid for  $\lambda \in [\bar{\lambda} - \varepsilon_2, \bar{\lambda}]$ .

<span id="page-9-1"></span>We will use the notation  $Int(\cdot)$  to represent the interior of a domain or a curve.

**Lemma 3.2.** If  $\alpha \in (0, \pi/2)$ , then (3.4), (3.1) and

<span id="page-9-0"></span>
$$\nabla u \cdot e_{\alpha - \pi/2} < 0 \text{ on } Int(\Gamma_N^-) \cap T_{\lambda, \pi/2}$$
(3.14)

hold for  $\lambda \geq \Phi_1$  and  $\vartheta = \pi/2$  where

<span id="page-9-4"></span>
$$\Phi_1 = \max\{\frac{1}{2}\Phi_0, \ \Psi_0 \cos \gamma\}. \tag{3.15}$$

If  $\beta \in (0, \pi/2)$ , then (3.2) and

<span id="page-9-5"></span>
$$\nabla u \cdot e_{\pi/2-\beta} < 0 \text{ on } Int(\Gamma_N^+) \cap \hat{T}_{\lambda,\pi/2}$$
(3.16)

hold for  $\vartheta = \pi/2$  and  $\lambda \geq \Psi_1$  where

$$\Psi_1 = \max\{\frac{1}{2}\Psi_0, \Phi_0 \cos \gamma\}.$$

*Proof.* We restrict our consideration to the first case where  $\alpha \in (0, \pi/2)$ , noting that the second case with  $\beta \in (0, \pi/2)$  follows a similar reasoning.

**Step 1**. The proof of monotonicity of u in interior of  $\Omega$ .

Let  $\vartheta=\pi/2$  and  $\vartheta_1=0$  (see the left picture in Figure 1). By the definition of  $\Phi_1$ , we derive that for  $\lambda\geq\Phi_1$ ,  $\Gamma^2_{\lambda,\vartheta,\vartheta_1}$  and its reflection  $(\Gamma^2_{\lambda,\vartheta,\vartheta_1})'$  (w.r.t.  $T_{\lambda,\vartheta}$ ) is contained in  $\Gamma^-_N$  and  $w^{\lambda,\vartheta}>0$  on  $\Gamma^1_{\lambda,\vartheta,\vartheta_1}$ . That means (3.8) is fulfilled for  $\lambda\geq\Phi_1$ . Applying Lemma 3.1, we conclude that (3.4) and (3.1) hold for  $\vartheta=\pi/2$  and  $\lambda\geq\Phi_1$ .

**Step 2**. The proof of monotonicity of u along the lower Neumann boundary  $\Gamma_N^-$  of  $\Omega$ .

Now note that we have shown the positive function  $w^{\lambda,\pi/2}$ . One can apply Serrin's boundary lemma to the positive function  $w^{\lambda,\pi/2}$  to deduce that the tangential derivative of u along  $\Gamma_N^-$  does not vanish; see Lemma 2.4. Thus, (3.14) is valid whenever  $w^{\lambda,\pi/2}>0$  in  $D_{\lambda,\pi/2}$ . In particular, (3.14) is valid for  $\lambda \geq \Phi_1$ .

For  $\alpha \in (0, \pi/2)$ , it is easy to check that

<span id="page-9-2"></span>
$$\Gamma^{2B}_{\lambda,\vartheta,0} = \emptyset \text{ whenever } \vartheta \in [\pi/2 - \alpha, \alpha_*], \ \lambda \ge \Phi_2,$$
(3.17)

where the constants  $\alpha_*$  and  $\Phi_2$  are given by

$$\alpha_* = \frac{\pi}{2} \text{ for } \alpha \in \left[\frac{\pi}{4}, \frac{\pi}{2}\right), \quad \alpha_* = \frac{3\pi}{4} \text{ for } \alpha \in \left[\frac{\pi}{8}, \frac{\pi}{4}\right), \quad \alpha_* = \pi - 2\alpha \text{ for } \alpha \in (0, \frac{\pi}{8}),$$

$$\Phi_2 = \max \left\{\frac{\sin(\alpha_* - \gamma)}{\sin \alpha_*} \Psi_0, \quad \frac{1}{1 + \sin \gamma} \Phi_0\right\},$$

which satisfy  $\pi - 2\alpha \le \alpha_* < \pi - \alpha$  and  $0 < \Phi_2 < \Phi_0$ . Similarly, for  $\beta \in (0, \pi/2)$ , we define

$$\beta_* = \frac{\pi}{2} \text{ for } \beta \in \left[\frac{\pi}{4}, \frac{\pi}{2}\right), \quad \beta_* = \frac{3\pi}{4} \text{ for } \beta \in \left[\frac{\pi}{8}, \frac{\pi}{4}\right), \quad \beta_* = \pi - 2\beta \text{ for } \beta \in (0, \frac{\pi}{8}),$$

$$\Psi_2 = \max \left\{ \frac{\sin(\beta_* - \gamma)}{\sin \beta_*} \Phi_0, \quad \frac{1}{1 + \sin \gamma} \Psi_0 \right\}.$$

<span id="page-9-3"></span>**Lemma 3.3.** If  $\alpha \in (0, \pi/2)$ , then (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \alpha_*]$  and  $\lambda \ge \Phi_2$ . If  $\beta \in (0, \pi/2)$ , then (3.2) holds for  $\vartheta \in [\pi/2 - \beta, \beta_*]$  and  $\lambda \ge \Psi_2$ .

*Proof.* We concentrate on the case where  $\alpha < \pi/2$ , while the case  $\beta < \pi/2$  can be considered in a similar manner.

Step 1. We claim that (3.1) holds for  $\lambda \geq \Phi_2$  and  $\vartheta = \alpha_*$ . In fact, by Lemma 3.2 and the definition of  $\alpha_*$  and  $\Phi_2$ , this step is valid whenever  $\alpha \in [\pi/4, \pi/2)$ . So we only need to consider the case  $\alpha < \pi/4$ .

Step 1.1. In the case  $\alpha < \pi/4$ , (3.1) holds for  $\lambda \geq \Phi_2$  and  $\vartheta \in [\pi/2, 3\pi/4]$ . In fact, we set  $J_{\infty} = \bigcup_{k=1}^{\infty} J_k$  and

$$J_k = \left\{ \frac{\pi}{2} + \frac{j\pi}{2^{k+1}} : j = 0, 1, 2, \dots, 2^{k-1} \right\}, \quad k = 1, 2, 3, \dots$$

Let  $\lambda \geq \Phi_2$  and  $\vartheta = 3\pi/4$ . We choose  $\vartheta_3 = \pi$  and  $\vartheta_1 = \pi/2$ . Then  $\vartheta_1, \vartheta_3 \in \{\pi/2, \pi\}$ . From Lemma 3.2 and (3.17), we see that  $w^{\lambda,\vartheta}$  satisfies (3.8). Applying Lemma 3.1, we conclude that (3.4) and (3.1) hold for  $\lambda \geq \Phi_2$  and  $\vartheta = 3\pi/4$  and hence for  $\vartheta \in J_1 = \{\pi/2, 3\pi/4\}$ . Suppose that (3.1) is valid for  $\lambda \geq \Phi_2$  and  $\vartheta \in J_k$  for some  $k \geq 1$ . Let  $\vartheta \in J_{k+1} \setminus J_k$ . Then  $\vartheta = \pi/2 + (2j+1)2^{-k-2}\pi$ . Take

$$\vartheta_1 = \frac{\pi}{2} + \frac{j\pi}{2^{k+1}}, \quad \vartheta_3 = \frac{\pi}{2} + \frac{(j+1)\pi}{2^{k+1}}.$$

Then  $\vartheta_1, \vartheta_3 \in J_k$  and  $\vartheta_3 - \vartheta = \vartheta - \vartheta_1 > 0$ . Thus,  $w^{\lambda,\vartheta}$  satisfies (3.8) for  $\lambda \geq \Phi_2$ . Applying Lemma 3.1, we conclude that (3.6) and (3.1) hold for  $\lambda \geq \Phi_2$ . This implies that (3.1) holds for  $\lambda \geq \Phi_2$  and  $\vartheta \in J_{k+1}$ . Hence the mathematical induction gives (3.1) for  $\lambda \geq \Phi_2$  and  $\vartheta \in J_{\infty}$ .

Note that  $J_{\infty}$  is dense in  $[\pi/2, 3\pi/4]$ . By the continuity,

<span id="page-10-1"></span>
$$\nabla u \cdot e_{\vartheta + \alpha} \ge 0 \text{ on } \Omega \cap T_{\lambda,\vartheta} \tag{3.18}$$

for  $\vartheta \in [\pi/2, 3\pi/4]$  and  $\lambda \geq \Phi_2$ . Now let  $\vartheta \in (\pi/2, 3\pi/4)$  be arbitrary fixed. It is easy to find  $\vartheta_1 \in [\pi/4, \pi/2], \vartheta_3 \in J_\infty$  such that  $\vartheta_3 - \vartheta = \vartheta - \vartheta_1 > 0$ . Thus, (3.8) is valid for  $\lambda \geq \Phi_2$ . Lemma 3.1 implies that (3.6) and (3.1) hold for  $\lambda \geq \Phi_2$ . Therefore, (3.1) holds for  $\lambda \geq \Phi_2$  and  $\vartheta \in [\pi/2, 3\pi/4]$ . This gives step 1.1. As a direct consequence, step 1 is valid whenever  $\alpha \in [\pi/8, \pi/4)$ .

Step 1.2. In the case  $\alpha \in (0, \pi/8)$ , (3.1) holds for  $\lambda \geq \Phi_2$  and  $\pi/2 \leq \vartheta \leq \pi - 2\alpha$ . In fact, from step 1.1, we get (3.1) for  $\vartheta \in \tilde{J}_1$  where we set  $\tilde{J}_k = [\pi/2, \pi - 2^{-k-1}\pi] \cap [\pi/2, \pi - 2\alpha]$ . Suppose that (3.1) holds for  $\vartheta \in \tilde{J}_k$  for some  $k \geq 1$ . Let  $\vartheta \in \tilde{J}_{k+1} \setminus \tilde{J}_k$  be arbitrary and  $\vartheta_3 = \pi$ . Then  $\vartheta \in (\pi - 2^{-k-1}\pi, \pi - 2^{-k-2}\pi] \cap [\pi/2, \pi - 2\alpha]$  and  $\vartheta_1 = 2\vartheta - \vartheta_3 \in \tilde{J}_k$ . Thus, (3.8) is valid for  $\lambda \geq \Phi_2$ . Lemma 3.1 implies that (3.4) and (3.1) hold for  $\lambda \geq \Phi_2$ . Hence (3.1) is valid for every  $\lambda \geq \Phi_2$  and  $\vartheta \in \tilde{J}_{k+1}$ . The mathematical induction implies that (3.1) holds for every  $\lambda \geq \Phi_2$  and  $\vartheta \in \tilde{J}_k = [\pi/2, \pi - 2\alpha]$ . This finishes step 1.2 and hence step 1.

**Step 2**. We claim that (3.1) holds for  $\lambda \geq \Phi_2$  and  $\vartheta \in [\pi/2 - \alpha, \alpha_*]$ .

Step 2.1. This step is valid for  $\vartheta = \alpha_*/2$ . We first note that  $\alpha_* \geq \pi - 2\alpha$  and then  $\alpha_*/2 \geq \pi/2 - \alpha$ . Now let  $\vartheta = \alpha_*/2$ ,  $\vartheta_1 = 0$ ,  $\vartheta_3 = \alpha_*$  and  $\lambda \geq \Phi_2$ . From (3.17), we see  $w^{\lambda,\vartheta}$  satisfies (3.8). Applying Lemma 3.1, we conclude that (3.4) and (3.1) hold for  $\vartheta = \alpha_*/2$  and  $\lambda \geq \Phi_2$ .

Step 2.2. This step is valid for  $\vartheta \in [\alpha_*/2, \alpha_*]$ . We omit the proof since it is similar to step 1.1.

Step 2.3. This step is valid for  $\vartheta \in [\pi/2 - \alpha, \alpha_*]$ . The proof is similar to step 1.2, so we omit the details.

It is easy to see that the three lines  $T_{\Upsilon,\vartheta}$ ,  $T_{\phi,\pi/2}$  and  $T_{\Phi_0,\pi-\alpha}=\{x: x_1=1\}$  pass through a common point if and only if

<span id="page-10-0"></span>
$$\Upsilon = \Upsilon_{\phi,\vartheta} = \phi + (\Phi_0 - \phi) \tan \alpha \cot(\pi - \theta). \tag{3.19}$$

<span id="page-11-7"></span>![](_page_11_Picture_2.jpeg)

FIGURE 3. The moving domain  $D_{\Upsilon,\vartheta}$  when the slope of  $T_{\Upsilon,\vartheta}$   $\vartheta$  is positive and large

<span id="page-11-4"></span>**Lemma 3.4.** Let  $\alpha \in (0, \pi/2)$ . Assume that there exists a positive constant  $\Phi \in [\Psi_0 \cos \gamma, \Phi_0)$  such that (3.1) holds for  $\vartheta = \pi/2$  and  $\lambda \geq \Phi$ . Then (3.1) holds for

<span id="page-11-2"></span>
$$\vartheta \in [\pi/2, \pi - \alpha), \quad \lambda \ge \Upsilon_{\Phi, \vartheta}$$

where  $\Upsilon_{\phi,\vartheta}$  is given in (3.19).

*Proof.* The assumption on  $\Phi$  ensures that  $T_{\Phi,\alpha-\pi/2} \cap \Gamma_D \neq \emptyset$ .

**Step 1**. We claim that (3.4) and (3.1) hold for  $\vartheta$  and  $\lambda$  satisfies

<span id="page-11-0"></span>
$$\vartheta \in [\bar{\vartheta}, \pi - \alpha) \text{ and } \lambda \ge \Psi_0 \sin(\vartheta - \gamma) \csc \vartheta$$
 (3.20)

where  $\bar{\vartheta} < \pi - \alpha$  is any fixed number satisfying

<span id="page-11-1"></span>
$$2\bar{\vartheta} - \gamma \ge \pi - \alpha, \quad 2\bar{\vartheta} - \pi \ge \pi/2 - \alpha, \quad \Psi_0 \sin(\bar{\vartheta} - \gamma) \csc \bar{\vartheta} \ge \Phi_2.$$
 (3.21)

Under (3.20) and  $\vartheta_3 = \pi$ , by using the assumption (3.21) for  $\bar{\vartheta}$ , we derive that  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} = \emptyset$  and  $\Gamma^{2A}_{\lambda,\vartheta,\vartheta_1} \subset T_{\lambda,2\vartheta-\pi}$  with

$$2\vartheta - \pi \in [\pi/2 - \alpha, \alpha_*]$$
 and  $\lambda \geq \Phi_2$ .

See Figure 3. Based on Lemma 3.3, one can show that (3.4) and (3.1) hold under (3.20).

**Step 2**. For any fixed  $\phi \in [\Phi, \Phi_0)$  and  $\bar{x} = (\bar{x}_1, \bar{x}_2)$  is the intersection point of  $T_{\bar{\phi}, \pi/2}$  and  $\Gamma_D$ , we claim that

<span id="page-11-3"></span>
$$\nabla u \cdot e_{\vartheta + \alpha} > 0 \text{ on } \Omega \cap \{(x - \bar{x}) \cdot e_{\vartheta + \alpha} = 0\}$$
(3.22)

for every  $\vartheta \in [\pi/2, \bar{\vartheta}]$ . In fact, we use the angular derivative  $R_{\bar{x}}u$  of u about the point  $\bar{x}$ ,

<span id="page-11-5"></span>
$$(R_{\bar{x}}u)(x) = (x_1 - \bar{x}_1)\partial_{x_2}u(x) - (x_2 - \bar{x}_2)\partial_{x_1}u(x)$$
(3.23)

in the domain

$$\mathcal{D} = \{ x \in \Omega : (x - \bar{x}) \cdot e_{\pi/2 + \alpha} < 0, \quad (x - \bar{x}) \cdot e_{\bar{\vartheta} + \alpha} > 0 \}.$$

The function  $R_{\overline{x}}u$  belongs to  $C^1(\overline{\mathcal{D}})$  and satisfies the linear equation

<span id="page-11-6"></span>
$$[\Delta + f'(u)]R_{\bar{x}}u = 0 \text{ in } \mathcal{D} \text{ and } R_{\bar{x}}u \le 1 \neq 0 \text{ on } \partial \mathcal{D}$$
(3.24)

where the boundary condition comes from step 1 and Lemma 3.2. Recalling that

$$[\Delta + f'(u)](\nabla u \cdot e_{\pi/2+\alpha}) = 0 \text{ in } \mathcal{D} \text{ and } (\nabla u \cdot e_{\pi/2+\alpha}) > 0 \text{ in } \overline{\mathcal{D}} \setminus \partial \Omega,$$

we can conclude that  $R_{\bar{x}}u < 0$  in  $\mathcal{D}$  by apply the maximum principle in [9] to  $R_{\bar{x}}u$ -equation. This finishes this step.

<span id="page-12-4"></span>Combining with step 1 and step 2, we know (3.22) holds for any  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\bar{x} \in (\Gamma_D \cap \{\bar{x} \cdot e_{\alpha-\pi/2} \geq \Phi\})$ . Moreover, (3.1) holds for  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda \geq \Upsilon_{\Phi,\vartheta}$ .

<span id="page-12-0"></span>**Lemma 3.5.** *Let*  $\gamma \in (0, \pi/2]$ .

(i) If  $\alpha \in (0, \pi/2)$ , then (3.4) and (3.1) hold for  $\vartheta = \pi/2$  and  $\lambda \geq \Psi_0 \cos \gamma$ . Moreover, (3.2) holds for  $\vartheta \in (\pi - \beta, \pi/2 + \gamma]$  and  $\lambda \geq \Psi_0$ .

(ii) If  $\beta \in (0, \pi/2)$ , then (3.2) holds for  $\vartheta = \pi/2$  and  $\lambda \geq \Phi_0 \cos \gamma$ . Moreover, (3.1) holds for  $\vartheta \in (\pi - \alpha, \pi/2 + \gamma]$  and  $\lambda \geq \Phi_0$ .

*Proof.* We only focus the case  $\alpha < \pi/2$ , while the case  $\beta < \pi/2$  can be considered similarly. Suppose first that  $\gamma \leq \alpha$ . Then  $\Phi_1$ , which is given in (3.15), equals to  $\Psi_0 \cos \gamma$ . Thus, Lemma 3.5 immediately follows from Lemma 3.2 and Lemma 3.4.

In the remain part, we suppose that  $\gamma > \alpha$  and we claim that (3.1) holds for  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda \geq \Upsilon_{\Lambda_j,\vartheta}$  for every  $j \geq 1$  where we denote  $\Lambda_0 = \Phi_0$  and

$$\Lambda_{j+1} = \frac{1}{2} \left( (\Phi_0 - \Lambda_j) \tan \alpha \cot \gamma + \Lambda_j \right) = \frac{1}{2 \cos \alpha \sin \gamma} \left( \cos \gamma + \Lambda_j \sin(\gamma - \alpha) \right)$$

for  $j \in \mathbb{N}$ . It is easy to see that the sequence  $\{\Lambda_j\}$  is strictly decreasing and converges to  $\Lambda_\infty = \Psi_0 \cos \gamma$ . In fact, from Lemma 3.2 and Lemma 3.4, the assertion holds for  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda \geq \Upsilon_{\Lambda_1,\vartheta}$  since  $\Lambda_1 = \Phi_1 = \Lambda_0/2$ . Now we suppose that the assertion holds for  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda \geq \Upsilon_{\Lambda_k,\vartheta}$  for some  $k \geq 1$ . Let

<span id="page-12-1"></span>
$$\vartheta = \pi/2 \text{ and } \lambda > \Lambda_{k+1},$$
 (3.25)

Then  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1}\subset T_{2\lambda,\pi-\gamma}$  with  $\pi-\gamma\in[\pi/2,\pi)$  and  $2\lambda\geq2\Lambda_{k+1}=\Upsilon_{\Lambda_k,\pi-\gamma}$ . It follows that (3.8) is satisfied. According to Lemma 3.1, (3.4) and (3.1) are valid under condition (3.25). Combining this with Lemma 3.4, the assertion is valid for j=k+1. The mathematical induction implies the assertion is valid for every j. So (3.1) holds for  $\vartheta\in[\pi/2,\pi-\alpha)$  and  $\lambda>\Upsilon_{\Lambda_\infty,\vartheta}$ .

In a word, (3.1) holds for  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda > \Psi_0 \csc \vartheta \sin(\vartheta - \gamma)$ . It remains to show the case  $\lambda = \Psi_0 \csc \vartheta \sin(\vartheta - \gamma)$ . By continuity, (3.18) holds  $\vartheta \in [\pi/2, \pi - \alpha)$  and  $\lambda = \Psi_0 \csc \vartheta \sin(\vartheta - \gamma)$ . Let  $R_{\bar{x}}u$  be the angular derivative of u about  $\bar{x} = (1, \cot \beta)$  (see (3.23)) and let  $\mathcal{D} = \{x \in \Omega : (x - \bar{x}) \cdot e_{\pi/2 + \alpha} < 0\}$ . Since  $R_{\bar{x}}u \leq \neq 0$  on  $\mathcal{D}$  and satisfies the linear equation (3.24), the strong maximum principle implies the negativity of  $R_{\bar{x}}u$ , and then (3.1) holds for  $\vartheta \in (\pi/2, \pi - \alpha)$  and  $\lambda = \Psi_0 \csc \vartheta \sin(\vartheta - \gamma)$ . Finally, one can deduce that (3.4) and (3.1) hold for  $\vartheta = \pi/2$  and  $\lambda \geq \Psi_0 \csc \vartheta \sin(\vartheta - \gamma)$ . Thus, the proof is finished.

As a direct consequence, we have

**Corollary 3.6.** Let  $\gamma = \pi - \alpha - \beta = \pi/2$ . Then u is monotone in the horizontal direction. Moreover, (3.1) and (3.2) hold for  $\lambda > 0$  and  $\vartheta \in [\pi/2, \pi)$ .

<span id="page-12-3"></span>**Lemma 3.7.** Let  $\alpha, \beta, \gamma$  be acute angles. Let  $\lambda > 0$  be fixed. Suppose that (3.1) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and (3.4) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$ . Then (3.4) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$ .

*Proof.* Note that  $w^{\lambda,\vartheta}$  does not satisfy the Neumann boundary condition on  $\Gamma^{2B}_{\lambda,\vartheta}$  for some  $\vartheta$  (e.g.,  $\vartheta$  is less and close to  $\pi/2 + \gamma$ ). In order to show

$$w^{\lambda,\vartheta}(x) = u(x^{\lambda,\vartheta}) - u(x) > 0 \text{ for } x \in \overline{D_{\lambda,\vartheta,\vartheta_1}} \setminus T_{\lambda,\vartheta}$$

with  $\theta_1 = \max\{0, 2\theta - \pi\}$ , we will use the same approach in [43, Lemma 13].

The assumption of this lemma implies that

<span id="page-12-2"></span>
$$w^{\lambda,\pi/2+\gamma} > 0 \text{ in } \overline{D_{\lambda,\pi/2+\gamma,2\gamma}} \setminus T_{\lambda,\pi/2+\gamma},$$
 (3.26)

<span id="page-13-1"></span>
$$w^{\lambda,\gamma} > 0 \text{ in } \overline{D_{\lambda,\gamma,0}} \setminus T_{\lambda,\gamma},$$
 (3.27)

and

<span id="page-13-0"></span>u(x) is strictly increasing as the angle of  $\overrightarrow{P_{\lambda}x}$  and  $\overrightarrow{P_{\lambda}O}$  decreases on each arc  $S(P_{\lambda},r)$  (3.28) where  $P_{\lambda}=(\lambda\sin\alpha,-\lambda\cos\alpha)$  and

$$S(P_{\lambda}, r) = \{ x \in \overline{\Omega} : |x - P_{\lambda}| = r, (x - P_{\lambda}) \cdot e_{\pi/2 - \beta} \ge 0 \ge (x - P_{\lambda}) \cdot e_{-\beta} \}.$$

Since  $\gamma \geq \pi/2 - \alpha$  (i.e.,  $\beta \leq \pi/2$ ), we point out that  $S(P_{\lambda}, r)$  is connected and then a piece of sphere.

Now we fix  $\vartheta \in (0, \pi/2 + \gamma)$ . Let x be any fixed point in  $\overline{D_{\lambda, \vartheta, \vartheta_1}} \setminus D_{\lambda, \vartheta}$ . Then  $x \in T_{\lambda, \psi_1}$  and  $x^{\lambda, \vartheta} \in T_{\lambda, \psi_2}$  with  $\psi_1 = 2\vartheta - \psi_2 < \vartheta$ . There are four cases.

Case 1:  $\psi_2, \psi_1 \in [\gamma, \pi/2 + \gamma]$ . In this case, from (3.28),

$$u(x) < u(x^{\lambda,\vartheta}).$$

Case 2:  $\psi_2 \in [\gamma, \pi/2 + \gamma]$  and  $\psi_1 \notin [\gamma, \pi/2 + \gamma]$ . In this case, the refection point  $x^{\lambda, \gamma}$  of x (w.r.t. the line  $T_{\lambda, \gamma}$ ) belongs  $T_{\lambda, \psi_1'}$  with  $\psi_1' = 2\gamma - \psi_1$ . By the definition of  $x^{\lambda, \gamma}$  and the fact  $\gamma \geq \pi/2 - \alpha$ , we see  $x^{\lambda, \gamma} \subset \{x_1 < 1\}$ . Combining this with the fact that  $\psi_1' - \psi_2 = 2(\gamma - \vartheta) < 0$ ,  $\psi_2 \leq \pi/2 + \gamma$ , we know  $x^{\lambda, \gamma} \in \overline{\Omega}$ . From (3.27) and (3.28),

$$u(x) < u(x^{\lambda,\gamma})$$
 and  $u(x^{\lambda,\gamma}) < u(x^{\lambda,\vartheta})$ .

Case 3:  $\psi_2 \notin [\gamma, \pi/2 + \gamma]$  and  $\psi_1 \in [\gamma, \pi/2 + \gamma]$ . In this case, the refection point  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}$  of  $x^{\lambda,\vartheta}$  (w.r.t. the line  $T_{\lambda,\pi/2+\gamma}$ ) belongs  $T_{\lambda,\psi_2'}$  with  $\psi_2' = \pi + 2\gamma - \psi_2$ . By the definition of  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}$ ,  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}$  lies on or below the line containing  $\Gamma_N^+$ . Combining this with the fact that  $\psi_2' - \psi_1 = 2(\pi/2 + \gamma - \vartheta) > 0$ ,  $\psi_1 \geq \pi/2 - \alpha$ , we know  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma} \in \overline{\Omega}$ . From (3.28) and (3.26),

$$u(x) < u((x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma})$$
 and  $u((x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}) < u(x^{\lambda,\vartheta})$ .

Case 4:  $\psi_2, \psi_1 \not\in [\gamma, \pi/2 + \gamma]$ . In this case,  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma} \in T_{\lambda,\psi_2'}$  and  $x^{\lambda,\gamma} \in T_{\lambda,\psi_1'}$ . Since  $0 \le \psi_1 < \psi_2 \le \pi$ , we know  $\psi_1 \ge \max\{2\vartheta - \pi, 0\}$  and hence  $\psi_2' - \psi_1' = 2(\pi/2 + \psi_1 - \vartheta) \ge 0$ . Thus,

$$0 \le \psi_1 < \gamma < \psi_1' \le \psi_2' < \pi/2 + \gamma < \psi_2 \le \pi.$$

It follows that  $x^{\lambda,\gamma}$  and  $(x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}$  belong to  $\overline{\Omega}$ . From (3.27), (3.28) and (3.26),

$$u(x) < u(x^{\lambda,\gamma}), \quad u(x^{\lambda,\gamma}) \leq u((x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}) \text{ and } u((x^{\lambda,\vartheta})^{\lambda,\pi/2+\gamma}) < u(x^{\lambda,\vartheta}).$$

<span id="page-13-2"></span>In all cases we have proved  $u(x) < u(x^{\lambda,\vartheta})$ . This finishes the proof.

**Lemma 3.8.** Let  $\alpha, \beta, \gamma$  be acute angles. Then (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \pi/2 + \gamma]$  and  $\lambda > \Phi_0 - \varepsilon$ , (3.2) holds for  $\vartheta \in [\pi/2 - \beta, \pi/2 + \gamma]$  and  $\lambda > \Psi_0 - \varepsilon$ , where  $\varepsilon > 0$  is a small constant.

*Proof.* We only show (3.1) is valid for  $\vartheta \in [\pi/2 - \alpha, \pi/2 + \gamma]$  and  $0 \le \Phi_0 - \lambda \ll 1$ , while we omit the proof of (3.2) when  $\vartheta \in [\pi/2 - \beta, \pi/2 + \gamma]$  and  $0 \le \Psi_0 - \lambda \ll 1$ .

**Step 1**. (3.1) holds for

$$\lambda \ge \Phi_0 - \varepsilon_1, \quad \pi/2 - \alpha \le \vartheta \le \pi - \alpha$$

where  $\varepsilon_1$  is a positive constant such that

$$\begin{split} \Phi_0 - \varepsilon_1 > \Phi_2, \quad \hat{\lambda}(\Phi_0 - \varepsilon_1, \pi - \alpha) > \Psi_2, \quad \hat{\lambda}(\Phi_0 - \varepsilon_1, \alpha_{**}) > \Psi_0, \\ \alpha_{**} = \max\left\{\frac{\pi - \beta_* + 2\gamma}{2}, \frac{3\pi - 2\alpha}{4}\right\}. \end{split}$$

In fact,  $\alpha < \pi/2$  and  $\beta_* > \pi - 2\beta$  implies that  $\alpha_{**} < \pi - \alpha$ . Let

<span id="page-14-0"></span>
$$\lambda \ge \Phi_0 - \varepsilon_1 \text{ and } \alpha_{**} \le \vartheta \le \pi - \alpha$$
 (3.29)

and  $\vartheta_1 = 2\vartheta - \pi$  and  $\vartheta_3 = \pi$ . Then  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} \subset T_{\hat{\lambda},\hat{\vartheta}}$  and  $\Gamma^{2A}_{\lambda,\vartheta,\vartheta_1} \subset T_{\lambda,\vartheta_1}$  with

$$\hat{\lambda}(\lambda, \vartheta) > \Psi_2, \quad \hat{\vartheta} = \pi - 2\vartheta + 2\gamma \in [\pi/2 - \beta, \beta_*]$$

and  $\vartheta_1 = 2\vartheta - \pi \in [\pi/2 - \alpha, \alpha_*]$ . Following by Lemma 3.3 and Lemma 3.5,  $w^{\lambda,\vartheta}$  satisfies (3.8). Applying Lemma 3.1, we conclude that (3.4) and (3.1) hold under (3.29).

Next we consider the case

<span id="page-14-1"></span>
$$\lambda \ge \Phi_0 - \varepsilon_1 \text{ and } \vartheta \in (\pi/2 - \alpha, \alpha_{**}).$$
 (3.30)

For this case, we will choose  $\pi/2 - \alpha \leq \vartheta_1 < \vartheta_3 \leq \alpha_{**}$  so that  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1} = \emptyset$  since  $\hat{\lambda}(\Phi_0 - \varepsilon_1, \alpha_{**}) > \Psi_0$ . We point out that (3.1) is now valid for  $\lambda \geq \Phi_0 - \varepsilon_1$  and  $\vartheta \in \{\pi/2 - \alpha, \alpha_{**}\}$  by the argument above and Lemma 3.3. Using same process in step 1.1 of Lemma 3.3, we conclude that (3.1) holds under (3.30). This finishes step 1. We remark that this step holds only on  $\alpha < \pi/2$  and  $\beta < \pi/2$ .

**Step 2.** We claim that (3.1) holds for  $\vartheta = \tilde{\vartheta}_*$  and  $0 < \Phi_0 - \lambda \ll 1$ . Here  $\tilde{\vartheta}_* = \tilde{\vartheta}_\kappa$  where  $\tilde{\vartheta}_j = \pi - 2^{-j}\alpha$ ,  $j \in \mathbb{N}$ , and  $\kappa$  is the fixed integer so that  $\tilde{\vartheta}_\kappa \geq 2\gamma > \tilde{\vartheta}_{\kappa-1}$ , i.e.,

$$\tilde{\vartheta}_{\kappa} < \gamma + \pi/2 \le \tilde{\vartheta}_{\kappa+1}.$$

In fact, by step 1, this claim is valid when  $\tilde{\vartheta}_* \leq \pi - \alpha$ , i.e.,  $2\gamma \leq \pi - \alpha$  or  $\gamma \leq \beta$ . Now we assume that  $\gamma > \beta$  (hence  $\gamma > \pi/4$ ). Lemma 3.7 implies that

<span id="page-14-2"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } \overline{D_{\lambda,\vartheta,2\vartheta-\pi}} \setminus T_{\lambda,\vartheta}.$$
 (3.31)

for  $\vartheta \in [\pi - \alpha/2, \pi/2 + \gamma]$  and  $\lambda \ge \Phi_0$ . Based on this and the monotonicity (3.16) on upper Neumann boundary  $\Gamma_N^+$  (see details in Lemma 3.5 and step 2 of Lemma 3.2), it follows by continuity that there exists  $\varepsilon_2 > 0$  (assuming  $\varepsilon_2 < \varepsilon_1$ ) such that

$$w^{\lambda,\vartheta} > 0 \text{ on } \Gamma^{2B}_{\lambda,\vartheta,2\vartheta-\pi} \text{ for } \lambda > \Phi_0 - \varepsilon_2, \ \vartheta \in \{\tilde{\vartheta}_1,\tilde{\vartheta}_2,\ldots,\tilde{\vartheta}_\kappa\}.$$

Let  $\vartheta = \tilde{\vartheta}_1$  and  $\vartheta_1 = 2\vartheta - \pi = \tilde{\vartheta}_0 = \pi - \alpha$ . Then

$$\begin{cases} \Delta w^{\lambda,\vartheta} + c^{\lambda,\vartheta} w^{\lambda,\vartheta} = 0 & \text{in } D_{\lambda,\vartheta}, \\ w^{\lambda,\vartheta} \geq 0 & \text{on } \partial D_{\lambda,\vartheta} \setminus \Gamma_{\lambda,\vartheta}^{2A}, \\ \partial_{\nu} w^{\lambda,\vartheta} \geq \neq 0 & \text{on } \Gamma_{\lambda,\vartheta}^{2A}, \end{cases}$$

which is similar to (3.8). Using the similar proof of Lemma 3.1, one gets that (3.31) and (3.1) hold for  $\lambda > \Phi_0 - \varepsilon_2$  and  $\vartheta = \tilde{\vartheta}_1$ . Similarly, one can get by mathematical induction that (3.31) and (3.1) hold for  $\lambda > \Phi_0 - \varepsilon_2$  and  $\vartheta \in \{\tilde{\vartheta}_1, \tilde{\vartheta}_2, \dots, \tilde{\vartheta}_\kappa\}$ .

**Step 3**. We claim that (3.1) holds for  $\theta \in [\pi/2 + \gamma, \pi/2 - \beta]$  and  $0 < \Phi_0 - \lambda \ll 1$ .

This is similar to step 2 in the proof of Lemma 3.4. For any fixed  $\lambda \in [\Phi_0 - \varepsilon_2, \Phi_0)$  and  $\bar{x} = (\bar{x}_1, \bar{x}_2)$  with  $\bar{x}_1 = \lambda \sin \alpha$ ,  $\bar{x}_2 = -\lambda \cos \alpha$ , we set

$$\mathcal{D} = \{ x \in \Omega : (x - \bar{x}) \cdot e_{\tilde{\vartheta}_* + \alpha} < 0, (x - \bar{x}) \cdot e_0 < 0 \}.$$

Then the angular derivative  $R_{\bar{x}}u$ , defined in (3.23), belongs to  $C^1(\overline{\mathcal{D}})$  and satisfies the linear equation

<span id="page-14-3"></span>
$$[\Delta + f'(u)]R_{\bar{x}}u = 0 \text{ in } \mathcal{D} \text{ and } R_{\bar{x}}u \ge \neq 0 \text{ on } \partial \mathcal{D}$$
(3.32)

by using step 1 and step 2. Recalling that

$$[\Delta + f'(u)](\nabla u \cdot e_{\tilde{\vartheta}_* + \alpha}) = 0 \text{ in } \mathcal{D} \text{ and } (\nabla u \cdot e_{\tilde{\vartheta}_* + \alpha}) < 0 \text{ in } \overline{\mathcal{D}} \setminus \partial \Omega,$$

<span id="page-15-3"></span>we can conclude that  $R_{\bar{x}}u>0$  in  $\mathcal{D}$  by applying the maximum principle in [9] to  $R_{\bar{x}}u$ -equation. In particular, (3.1) holds for  $\vartheta\in[\pi/2-\alpha,\tilde{\vartheta}_*]$  and  $\lambda\geq\Phi_0-\varepsilon_2$ .

Let  $\vartheta=\pi/2+\gamma$ ,  $\vartheta_1=2\vartheta-\pi=2\gamma$  and  $\lambda\geq\Phi_0-\varepsilon_2$ . It is clear that  $\Gamma_{\lambda,\vartheta}^{2B}$  and its reflection  $(\Gamma_{\lambda,\vartheta}^{2B})'$  belongs to  $\Gamma_N^+$ . By the definition of  $\tilde{\vartheta}_*$ , we derive  $2\gamma\in[\pi/2-\alpha,\tilde{\vartheta}_*]$ . Thus,  $w^{\lambda,\vartheta}$  satisfies (3.8). Applying Lemma 3.1, we conclude that (3.4) and (3.1) hold for  $\vartheta=\pi/2+\gamma$ ,  $\vartheta_1=2\vartheta-\pi=2\gamma$  and  $\lambda\geq\Phi_0-\varepsilon_2$ .

Finally, using the same argument at the beginning of this step, one can derive that (3.1) holds for  $\vartheta \in [\pi - \alpha, \pi/2 + \gamma]$  and  $\lambda \ge \Phi_0 - \varepsilon_2$ . This finishes the proof.

<span id="page-15-2"></span>**Theorem 3.9.** Let the assumptions in Theorem 1.2 hold. Suppose that

$$\alpha \in (0, \pi/2), \quad \beta \in (0, \pi/2), \quad \gamma \in (0, \pi/2].$$

Then u is monotone in the horizontal direction. Moreover, (3.1) and (3.2) hold for  $\lambda > 0$  and  $\theta \in [\gamma, \pi)$ ,  $\nabla u \cdot e_{\theta} < 0$  in  $\Omega$  for  $\theta \in [-\beta, \alpha]$ .

*Proof.* The case  $\gamma=\pi/2$  is covered in  $\ref{eq:thm.1}$ ?, and hence we assume  $\gamma<\pi/2$ . Let  $(\bar t,\infty)$  be largest open interval of nonnegative values of t such that (3.1) holds for  $\vartheta\in[\gamma,\pi/2+\gamma]$  and  $\lambda\geq t\Phi_0$ , and (3.2) holds for  $\vartheta\in[\gamma,\pi/2+\gamma]$  and  $\lambda\geq t\Psi_0$ . Following by Lemma 3.8, we know  $\bar t<1$ . In order to show  $\bar t=0$ , we argue by contradiction and suppose that  $\bar t>0$ . Set  $\bar\Phi=\bar t\Phi_0$ .

**Step 1.** (3.1) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{t}\Phi_0$ , and (3.2) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{t}\Psi_0$ .

In fact, by the definition of  $\bar{t}$  and the continuity, the nonstrictly inequality (3.18) is valid for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi} = \bar{t}\Phi_0$ . Set  $\bar{x} = (\bar{x}_1, \bar{x}_2), \bar{x}_1 = \bar{\Phi}\sin\alpha, \bar{x}_2 = -\bar{\Phi}\cos\alpha$ , and

$$\mathcal{D} = \{ x \in \Omega : (x - \bar{x}) \cdot e_{\pi/2 - \beta} > 0, \quad (x - \bar{x}) \cdot e_{-\beta} < 0 \}.$$

Combining this with the monotonicity property near the Dirichlet (see Lemma 2.3), we deduce that the angular derivative  $R_{\bar{x}}u$  (defined in (3.23)) satisfies (3.32). The strong the maximum principle implies the positivity of  $R_{\bar{x}}u$  in  $\mathcal{D}$  and hence (3.1) holds for  $\vartheta \in (\gamma, \pi/2 + \gamma)$  and  $\lambda = \bar{\Phi}$ .

For  $\vartheta = \gamma$  and  $\lambda \geq \bar{\Phi}$ , we see  $\Gamma_{\lambda,\gamma}^{2A} \subset T_{\lambda,0}$ ,  $(\Gamma_{\lambda,\gamma}^{2A})' \subset T_{\lambda,2\gamma}$  with  $2\gamma \in [\gamma, \pi/2 + \gamma]$  and  $\Gamma_{\lambda,\gamma}^{2B} \in T_{2\lambda,\gamma}$ . One deduces that (3.4) and (3.1) hold for  $\vartheta = \gamma$  and  $\lambda \geq \bar{\Phi}$ .

For  $\vartheta = \pi/2 + \gamma$  and  $\lambda \geq \bar{\Phi}$ , we see  $(\Gamma_{\lambda,\pi/2+\gamma}^{2A})' \subset T_{\lambda,\pi}$ ,  $\Gamma_{\lambda,\pi/2+\gamma}^{2A} \subset T_{\lambda,2\gamma}$  with  $2\gamma \in [\gamma,\pi/2+\gamma]$  and  $\Gamma_{\lambda,\gamma}^{2B} \in \Gamma_N^+$ . One deduces that (3.4) and (3.1) hold for  $\vartheta = \pi/2 + \gamma$  and  $\lambda \geq \bar{\Phi}$ . We point out that u is strictly monotone along the upper Neumann boundary  $\Gamma_N^+$ , i.e., (3.16) is still valid for  $\lambda \geq \bar{t}\Phi_0 \cos \gamma$ ; see step 2 of Lemma 3.2.

Thus, (3.1) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi}$  and (3.16) is still valid for  $\lambda \geq \bar{t}\Phi_0 \cos \gamma$ . Similarly, (3.2) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{t}\Psi_0$  and (3.14) is still valid for  $\lambda \geq \bar{t}\Psi_0 \cos \gamma$ .

**Step 2**. (3.1) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $0 < \bar{t}\Phi_0 - \lambda \ll 1$ , and (3.2) holds for  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $0 < \bar{t}\Psi_0 - \lambda \ll 1$ .

Indeed, let  $\bar{\vartheta}$  be the angle such that  $T_{\bar{\Phi},\bar{\vartheta}}$  passes through the upper mixed boundary point. Then  $\bar{\vartheta} \in (\gamma, \pi - \alpha)$ . Now let us fix a small constant  $\delta > 0$  so that

<span id="page-15-0"></span>
$$0 < \delta < \min\left\{\frac{\bar{\vartheta} - \gamma}{3}, \ \frac{\pi/2 + \gamma - \bar{\vartheta}}{5}, \ \frac{\pi/2 + 2\gamma + \beta - 2\bar{\theta}}{2}\right\} \ \text{and} \ \hat{\lambda}(\bar{\Phi}, \bar{\vartheta} + \delta) > \Psi_2. \tag{3.33}$$

Let  $\varepsilon_1 > 0$  be a small constant so that

<span id="page-15-1"></span>
$$\hat{\lambda}(\lambda, \vartheta) > \Psi_2 \text{ and } \check{\lambda}(\lambda, \vartheta) > \bar{\Phi} \text{ for } |\vartheta - \bar{\vartheta}| \le \delta, \ \lambda \ge \bar{\Phi} - \varepsilon_1.$$
 (3.34)

Note that u is monotone along the Neumann boundary (see (3.14) for  $\lambda \geq \bar{\Phi} \cos \gamma$  and (3.16) for  $\lambda \geq \bar{\Phi}$ ) and near the Dirichlet boundary (see Lemma 2.3). By continuity, there exists a small

constant  $\varepsilon_2 > 0$  (assuming  $\varepsilon_2 < \varepsilon_1$ ) such that (3.1) holds for

$$\vartheta \in [\gamma, \bar{\vartheta} - \delta] \cup [\bar{\vartheta} + \delta, \pi/2 + \gamma] \text{ and } \lambda \geq \bar{\Phi} - \varepsilon_2.$$

Now let  $|\vartheta - \bar{\vartheta}| < \delta$  and  $\lambda \ge \bar{\Phi} - \varepsilon_2$ . We choose  $\vartheta_1 = \bar{\vartheta} - 3\delta$  and  $\vartheta_3 = 2\vartheta - \vartheta_1$ . From (3.33),  $\vartheta_1$  and  $\vartheta_3$  belong to  $[\gamma, \bar{\vartheta} - \delta] \cup [\bar{\vartheta} + \delta, \pi/2 + \gamma]$ . This shows  $w^{\lambda,\vartheta}$  satisfies the strictly boundary condition on  $\Gamma^{2A}_{\lambda,\vartheta,\vartheta_1}$ . Note that  $\Gamma^{2B}_{\lambda,\vartheta} \subset \hat{T}_{\hat{\lambda},\hat{\vartheta}}$  with

$$\begin{split} \hat{\lambda} > \Psi_2 \text{ and } \hat{\vartheta} &= \pi - 2\vartheta + 2\gamma \in [\pi/2 - \beta, \pi/2] \text{ if } \vartheta \geq \pi/4 + \gamma, \\ \check{\lambda} > \bar{\Phi} \text{ and } \check{\vartheta} &= 2\vartheta - \gamma \in [\gamma, \pi/2 + \gamma] \text{ if } \vartheta < \pi/4 + \gamma \end{split}$$

where (3.34) is used. Therefore,  $w^{\lambda,\vartheta}$  satisfies the strictly boundary condition on  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1}$ . Thus, (3.8) is satisfied. Following by Lemma 3.1, (3.4) and (3.1) are valid for every  $\vartheta \in [\bar{\vartheta} - \delta, \bar{\vartheta} + \delta]$ ,  $\vartheta_1 = \bar{\vartheta} - 3\delta$  and  $\lambda \geq \bar{\Phi} - \varepsilon_2$ . Therefore, (3.1) holds for for every  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi} - \varepsilon_2$ . Similarly, (3.2) holds for for every  $\vartheta \in [\gamma, \pi/2 + \gamma]$  and  $\bar{t}\Psi_0 - \lambda \ll 1$ .

This yields a contradiction to the definition of  $\bar{t}$ . Thus,  $\bar{t} = 0$  and the proof is finished.

**Theorem 3.10.** Let the assumptions in Theorem 1.2 hold. Suppose that

$$\max\{\alpha, \beta\} \ge \pi/2.$$

Then u is monotone in the horizontal direction. Moreover,  $\nabla u \cdot e_{\theta} < 0$  in  $\Omega$  for  $-\min\{\pi/2, \beta\} \le \theta \le \min\{\pi/2, \alpha\}$ .

*Proof.* Without loss of generality, we assume that  $\alpha \geq \pi/2$ . We argue indirectly and suppose that  $\bar{\Phi} > 0$  where

$$\bar{\Phi} = \inf\{\Phi > 0 : (3.1) \text{ holds for every } \theta \in (0, \pi/2 + \gamma], \ \lambda \geq \Phi\}.$$

We point out that Lemma 3.5 implies that  $\bar{\Phi}$  is well-defined and  $\bar{\Phi} \leq \Phi_0$ . By the same argument in step 1 of Theorem 3.9, one can deduce that (3.1) holds for  $\vartheta \in (0, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi}$ . More precisely, for each  $\lambda \geq \bar{\Phi}$ ,

$$w^{\lambda,\pi/2+\gamma} > 0$$
 in  $\overline{D_{\lambda,\pi/2+\gamma}} \setminus T_{\lambda,\pi/2+\gamma}$ 

and

u is strictly increasing as the angle of  $\overrightarrow{P_{\lambda}x}$  and  $\overrightarrow{P_{\lambda}O}$  decreases on the each arc  $S(P_{\lambda},r)$ 

where

$$S(P_{\lambda}, r) = \{x \in \overline{\Omega} : |x - P_{\lambda}| = r, (x - P_{\lambda}) \cdot e_{\pi/2 - \beta} \ge 0\}$$

is connected and a piece of sphere.

**Step 1**. We show that for  $\vartheta \in (0, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi}$ ,

<span id="page-16-2"></span>
$$w^{\lambda,\vartheta} > 0 \text{ in } \overline{D_{\lambda,\vartheta}} \setminus T_{\lambda,\vartheta}.$$
 (3.35)

We omit the details of proof since it is similar to Lemma 3.7.

**Step 2**. (3.4) and (3.1) hold for  $\vartheta = \pi/2$  and  $\lambda \in (\bar{\Phi} - \varepsilon_1, \bar{\Phi}]$  for some small constant  $\varepsilon_1 > 0$ . This is done by the same process of step 2 in the proof of Lemma 3.8.

**Step 3**. (3.1) holds for

<span id="page-16-1"></span>
$$0 < \vartheta \le \tilde{\vartheta}_0 \text{ and } \lambda \ge \bar{\Phi} - \varepsilon_2$$
 (3.36)

where  $\tilde{\vartheta}_0 = \max\{\pi/4 + \gamma, \bar{\vartheta} + \delta\}$  and  $\bar{\vartheta}$  is the constant so that  $T_{\bar{\Phi},\bar{\vartheta}}$  contains the upper mixed boundary point. Here  $\delta > 0$  and  $\varepsilon_2 > 0$  (assuming  $\varepsilon_2 < \varepsilon_1$ ) are two small constants so that

<span id="page-16-0"></span>
$$\bar{\vartheta} + \delta < \pi/4 + \gamma + \beta/2, \quad \hat{\lambda}(\bar{\Phi} - \varepsilon_2, \bar{\vartheta} + \delta) > \Psi_2, \quad (\bar{\Phi} - \varepsilon_2)(1 + \sin \gamma) > \bar{\Phi}.$$
 (3.37)

For the existence of  $\delta$  and  $\varepsilon_2$  satisfying (3.37), we only note that  $\bar{\vartheta} \leq \pi - \alpha < \pi/4 + \gamma + \beta/2$ . Step 3.1. We check the boundary condition on  $\Gamma_{\lambda,\vartheta}^{2B}$  whenever (3.36). There are three cases:

(1) If  $\vartheta \in (\pi/4 + \gamma, \pi/4 + \gamma + \beta/2]$ , then  $\Gamma^{2B}_{\lambda,\vartheta} \subset \hat{T}_{\hat{\lambda},\hat{\vartheta}}$  with

$$\hat{\vartheta} = \pi - 2\vartheta + 2\gamma \in [\pi/2 - \beta, \pi/2) \text{ and } \hat{\lambda} = \frac{\lambda \sin \vartheta}{\sin(\vartheta - \gamma)} > \Psi_2$$

(2) If  $\vartheta \in (\gamma/2, \pi/4 + \gamma]$ , then  $\Gamma^{2B}_{\lambda,\vartheta} = T_{\check{\lambda},\check{\vartheta}}$  with

$$\check{\vartheta} = 2\vartheta - \gamma \in (0, \pi/2 + \gamma] \text{ and } \check{\lambda} = \lambda + \frac{\lambda \sin \gamma}{\sin(2\vartheta - \gamma)} > \bar{\Phi}.$$

(3) If  $\vartheta \in (0, \gamma/2]$ , then  $\Gamma_{\lambda}^{2B} = \emptyset$  is always valid.

By Lemma 3.3 and the definition of  $\bar{\Phi}$ , we derive that  $w^{\lambda,\vartheta}$  satisfies the boundary condition on  $\Gamma^{2B}_{\lambda,\vartheta}$ .

Step 3.2. (3.35) and (3.1) hold for  $\vartheta \in (0, \pi/4]$  and  $\lambda \geq \bar{\Phi} - \varepsilon_2$ . This follows the same proof of step 1.1 of Lemma 3.3.

Step 3.3. (3.35) and (3.1) hold for  $\vartheta \in (0, \min\{\pi/2, \tilde{\vartheta}_0\}]$  and  $\lambda \geq \bar{\Phi} - \varepsilon_2$ . This follows the same proof of step 1.2 of Lemma 3.3.

Step 3.4. (3.35) and (3.1) hold for  $\vartheta \in (0, \tilde{\vartheta}_0]$  and  $\lambda \geq \bar{\Phi} - \varepsilon_2$ . This follows the same proof of step 1.2 of Lemma 3.3.

Step 4. (3.1) holds for  $\vartheta = \tilde{\vartheta}_*$  and  $\lambda \geq \bar{\Phi} - \varepsilon_3$  for some  $\varepsilon_3 \in (0, \varepsilon_2)$ . Here  $\tilde{\vartheta}_* = \tilde{\vartheta}_\kappa$  where  $\tilde{\vartheta}_0 = \max\{\pi/4 + \gamma, \bar{\vartheta} + \delta\}$ ,  $\tilde{\vartheta}_j = \pi - 2^{-j}(\pi - \tilde{\vartheta}_0)$ ,  $j \in \mathbb{N}$  and  $\kappa$  is the fixed integer so that  $\tilde{\vartheta}_\kappa \geq 2\gamma > \tilde{\vartheta}_{\kappa-1}$ , i.e.,  $\tilde{\vartheta}_\kappa < \gamma + \pi/2 \leq \tilde{\vartheta}_{\kappa+1}$ . The proof is similar to step 2 in Lemma 3.8, so we omit it.

**Step 5**. We conclude that (3.1) holds for  $\vartheta \in (0, \pi/2 + \gamma]$  and  $\lambda \geq \bar{\Phi} - \varepsilon_3$ . This is similar to step 3 in Lemma 3.8, so we omit it.

<span id="page-17-0"></span>Combining these steps, we reach a contradiction to the definition of  $\bar{\Phi}$ . Hence,  $\bar{\Phi}=0$ , and this finishes the proof.

# 4. THE SYMMETRY PROPERTY IN ISOSCELES TRIANGLE

<span id="page-17-1"></span>**Theorem 4.1.** Let the assumptions in Theorem 1.2 hold. Suppose that  $\alpha = \beta$ . Then u is symmetric with respect to the horizontal axis. More precisely,  $\partial_{x_1} u < 0$  in  $\Omega$  and  $x_2 \partial_{x_2} u < 0$  in  $\Omega \cap \{x_2 \neq 0\}$ .

Proof. Let

$$\bar{\Lambda} = \inf\{\Lambda > 0 : (3.1) \text{ and } (3.2) \text{ hold for } \vartheta \in [\gamma/2, \pi/2 + \gamma/2], \ \lambda > \Lambda\}.$$

By step 1 of Lemma 3.8, we see that  $\bar{\Lambda}$  is well-defined and  $\bar{\Lambda} < \Phi_0$ . In order to show the theorem, it suffices to prove  $\bar{\Lambda} = 0$ . We argue by contradiction and suppose that  $\bar{\Lambda} > 0$ .

By continuity,

$$\nabla u \cdot e_{\vartheta+\alpha} \ge 0 \text{ on } \Omega \cap T_{\lambda,\vartheta}, \quad \nabla u \cdot e_{-\vartheta-\beta} \ge 0 \text{ on } \Omega \cap \hat{T}_{\lambda,\vartheta}$$

for  $\vartheta \in [\gamma/2, \pi/2 + \gamma/2]$  and  $\lambda \geq \bar{\Lambda}$ . Moreover,

$$w^{\lambda,\gamma/2} > 0$$
 in  $D_{\lambda,\gamma/2}$  and  $w^{\lambda,\pi/2+\gamma/2} > 0$  in  $D_{\lambda,\pi/2+\gamma/2}$ ,

and (3.1), (3.2) hold for  $\vartheta \in [\gamma/2, \pi/2 + \gamma/2]$  and  $\lambda \geq \bar{\Lambda}$ . Now following by the same process of Lemma 3.7, one proves that for  $\lambda \geq \bar{\Lambda}$ ,

$$w^{\lambda,\pi/2} > 0$$
 in  $\overline{D_{\lambda,\pi/2}} \setminus T_{\lambda,\pi/2}$ .

Let  $\bar{\vartheta}$  be the angle such that  $T_{\bar{\Lambda},\bar{\vartheta}}$  passes through the upper mixed boundary point. Then  $\bar{\vartheta} \in (\gamma, \pi - \alpha)$ . Now let us fix a small constant  $\delta > 0$  so that

<span id="page-18-1"></span>
$$0 < \delta < \min\left\{\frac{\bar{\vartheta} - \gamma}{3}, \frac{\pi + \gamma - 2\bar{\vartheta}}{10}, \frac{2\pi + 3\gamma - 4\bar{\vartheta}}{4}\right\} \tag{4.1}$$

and let  $\varepsilon_1 > 0$  be a small constant so that

<span id="page-18-2"></span>
$$\hat{\lambda}(\lambda, \vartheta) > \bar{\Lambda} \text{ and } \check{\lambda}(\lambda, \vartheta) > \bar{\Lambda} \text{ for } |\vartheta - \bar{\vartheta}| \le \delta, \ \lambda \ge \bar{\Lambda} - \varepsilon_1.$$
 (4.2)

By continuity, there exists a small constant  $\varepsilon_2 > 0$  (assuming  $\varepsilon_2 < \varepsilon_1$ ) such that (3.1) holds for

$$\vartheta \in [\gamma, \bar{\vartheta} - \delta] \cup [\bar{\vartheta} + \delta, \pi/2 + \gamma/2] \text{ and } \lambda \geq \bar{\Lambda} - \varepsilon_2.$$

Following same process in step 2 of  $\ref{eq:condition}$ ?, one deduces that (3.1) holds for  $\vartheta \in [\gamma/2, \gamma]$  and  $\lambda \geq \bar{\Lambda} - \varepsilon_2$ . Now let  $|\vartheta - \bar{\vartheta}| < \delta$  and  $\lambda \geq \bar{\Lambda} - \varepsilon_2$ . We choose  $\vartheta_1 = \bar{\vartheta} - 3\delta$  and  $\vartheta_3 = 2\vartheta - \vartheta_1$ . From (4.1),  $\vartheta_1 \in [\gamma, \bar{\vartheta} - \delta]$ ,  $\vartheta_3 \in [\bar{\vartheta} + \delta, \pi/2 + \gamma/2]$ . Note that  $\Gamma^{2B}_{\lambda,\vartheta} \subset \hat{T}_{\hat{\lambda},\hat{\vartheta}} = T_{\check{\lambda},\check{\vartheta}}$  with

$$\begin{split} \hat{\lambda} > \bar{\Lambda} \text{ and } \hat{\vartheta} &= \pi - 2\vartheta + 2\gamma \in [\gamma/2, \pi/2 + \gamma/2] \text{ if } \vartheta \geq \pi/4 + 3\gamma/4, \\ \check{\lambda} > \bar{\Lambda} \text{ and } \check{\vartheta} &= 2\vartheta - \gamma \in [\gamma/2, \pi/2 + \gamma/2] \text{ if } \vartheta < \pi/4 + 3\gamma/4 \end{split}$$

where (4.2) is used. Therefore,  $w^{\lambda,\vartheta}$  satisfies the strictly boundary condition on  $\Gamma^{2A}_{\lambda,\vartheta,\vartheta_1}$  and  $\Gamma^{2B}_{\lambda,\vartheta,\vartheta_1}$ , and  $w^{\lambda,\vartheta}$  satisfies (3.8). Following by Lemma 3.1, we deduce that (3.6) and (3.1) are valid for every  $\vartheta \in (\bar{\vartheta} - \delta, \bar{\vartheta} + \delta)$ ,  $\vartheta_1 = \bar{\vartheta} - 3\delta$  and  $\lambda \geq \bar{\Lambda} - \varepsilon_2$ .

In a word, (3.1) holds for every  $\vartheta \in [\gamma/2, \pi/2 + \gamma/2]$  and  $\lambda \geq \bar{\Lambda} - \varepsilon_2$ . Similarly, (3.2) holds for for every  $\vartheta \in [\gamma/2, \pi/2 + \gamma/2]$  and  $\bar{\Lambda} - \lambda \ll 1$ . This yields a contradiction to the definition of  $\bar{\Lambda}$ . Hence  $\bar{\Lambda} = 0$ , (3.1) and (3.2) hold for  $\vartheta \in [\gamma/2, \pi/2 + \gamma/2]$  and  $\lambda > 0$ . We also have

$$w^{\lambda,\gamma/2}(x) = u(x_1, -2\lambda \sin(\gamma/2) - x_2) - u(x_1, x_2) > 0 \text{ for } x \in \Omega \text{ with } x_2 < -\lambda \sin(\gamma/2).$$

Similarly,

$$u(x_1, 2\lambda \sin(\gamma/2) - x_2) - u(x_1, x_2) > 0 \text{ for } x \in \Omega \text{ with } x_2 > \lambda \sin(\gamma/2).$$

By letting  $\lambda \to 0^+$ , we get

$$u(x_1, -x_2) - u(x_1, x_2) = 0$$
 for  $x \in \Omega$ .

<span id="page-18-0"></span>This implies that u is symmetric with respect to  $x_2$ .

## 5. The proof of monotonicity for obtuse Neumann vertex

In this section we focus the monotonicity property when the two Neumann boundary forms an obtuse angle.

<span id="page-18-4"></span>**Lemma 5.1.** Let  $\gamma > \pi/2$  and

$$\max\{\alpha, \beta\} \ge \pi/4.$$

Then u is monotone in the fixed direction that is perpendicular to the longer Neumann side, and u has non-zero tangential derivative on the interior of the shortest Neumann boundary.

*Proof.* Without loss of generality, we assume that  $\alpha \geq \beta$  and hence

<span id="page-18-3"></span>
$$\alpha \ge \pi/4. \tag{5.1}$$

**Part 1.** We claim that (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \pi/2]$  and  $\lambda > 0$ . In order to do it, we suppose by contradiction that  $\bar{\Phi} > 0$  where we set

$$\bar{\Phi} = \inf\{\Phi > 0 : (3.1) \text{ holds for } \theta \in [\pi/2 - \alpha, \pi/2] \text{ and } \lambda > \Phi\}.$$

From step 1 of Lemma 3.8,  $\bar{\Phi}$  is well-defined and  $\bar{\Phi} < \Phi_0$ . For  $\vartheta = \pi/2$  and  $\lambda \geq \bar{\Phi}/2$ , we have  $\Gamma_{\lambda}^{2B} \subset T_{2\lambda,\pi-\gamma}$  and  $\pi - \gamma \in [\pi/2 - \alpha,\pi/2]$ . Therefore, (3.4) and (3.1) hold for  $\vartheta = \pi/2$  and  $\lambda \geq \bar{\Phi}/2$ . Note that the condition (5.1) implies  $\pi/4 \geq \pi/2 - \alpha$ . As the same proof of step 1.1 and step 2 in Lemma 3.3, we conclude that (3.1) holds for  $\vartheta \in [\pi/2 - \alpha,\pi/2]$  and  $\lambda \geq \bar{\Phi}/2$ . This yields a contradiction to the definition of  $\bar{\Phi}$ . Thus, we finish this part.

![](_page_19_Picture_3.jpeg)

FIGURE 4. The case for  $\gamma > \pi/2$  and  $\alpha \ge \pi/4$ 

**Part 2**. We claim that (3.1) holds for  $\vartheta = \gamma$  and  $\lambda > 0$ . In fact, we denote by  $\tilde{u}$  the reflection of u along the line  $T_{0,0}$  that contains  $\Gamma_N^-$ :

<span id="page-19-1"></span><span id="page-19-0"></span>
$$\tilde{u}(x) = \begin{cases} u(x), & \text{if } x \in \overline{\Omega}, \\ u(x^{0,0}), & \text{if } x^{0,0} \in \overline{\Omega}, \end{cases}$$
(5.2)

where  $x^{0,0}$  is the reflection point of x with respect to  $\Gamma_N^-$ . Then  $\tilde{u}$  is a positive solution of (1.1) in a double domain  $\tilde{\Omega} = \Omega \cup \Omega' \cup \Gamma_N^-$  with  $\Omega'$  is the reflection domain of  $\Omega$  with respect to  $T_{0,0}$ ; see Figure 4. Note that the assumption  $\gamma > \pi/2$  and  $\alpha \geq \pi/4$  implies that  $\pi - \gamma \in [\pi/2 - \alpha, \pi/2]$ . From part 1, we see

$$\nabla \tilde{u} \cdot e_{\pi-\beta} > 0 \text{ on } \tilde{\Omega} \cap \hat{T}_{0,0}$$

where  $\hat{T}_{0,0}$  is the line that contains  $\Gamma_N^+$ . Hence  $\tilde{u}$  satisfies

$$\begin{cases} \Delta \tilde{u} + f(\tilde{u}) = 0 & \text{in } \tilde{\Omega} \cap \{x \cdot e_{-\beta} > 0\}, \\ \tilde{u} = 0 & \text{on } \partial \tilde{\Omega} \cap \{x \cdot e_{-\beta} > 0\}, \\ \nabla \tilde{u} \cdot e_{-\beta} \le 0 & \text{on } \overline{\tilde{\Omega}} \cap \{x \cdot e_{-\beta} = 0\}. \end{cases}$$

Based on this, following by the argument of moving plane process, one can get that

$$\tilde{u}^{\lambda,\gamma} - \tilde{u} > 0 \text{ in } \tilde{\Omega} \cap \{x \in \mathbb{R}^2: \ \lambda \sin \gamma < x \cdot e_{-\beta} < 2\lambda \sin \gamma \}$$

(where  $\tilde{u}^{\lambda,\gamma}(x)=\tilde{u}(x^{\lambda,\gamma}))$  and

$$\nabla \tilde{u} \cdot e_{-\beta} < 0 \text{ on } \tilde{\Omega} \cap T_{\lambda,\gamma}$$

for every  $\lambda > 0$ . In particular,  $\nabla u \cdot e_{-\beta} < 0$  in  $\Omega$ . We remark that (3.2) holds for  $\vartheta \in [\pi - \beta, \pi]$  and  $\lambda \geq \Psi_0$ .

<span id="page-19-2"></span>**Lemma 5.2.** Let  $\gamma > \pi/2$  and

$$\gamma - \pi/2 \geq \min\{\alpha,\beta\}.$$

<span id="page-20-4"></span>Then u is monotone in the fixed direction that is perpendicular to the longer Neumann side, and u has non-zero tangential derivative on the interior of the shortest Neumann boundary. In particular, the conclusion holds if  $\gamma > 2\pi/3$ .

*Proof.* The isosceles case ( $\alpha = \beta$ ) is covered in Theorem 4.1. Without loss of generality, we assume that  $\alpha > \beta$  and hence

<span id="page-20-0"></span>
$$\gamma \ge \pi/2 + \beta. \tag{5.3}$$

In order to show the result, we set

$$\bar{\Phi} = \inf\{\Phi > 0 : (3.1) \text{ holds for } \theta \in [\pi/2 - \alpha, \gamma] \text{ and } \lambda > \Phi\}.$$

Step 1 in Lemma 3.8 tells us that  $\bar{\Phi}$  is well-defined and  $\bar{\Phi} < \Phi_0$ . We now suppose by contradiction that  $\bar{\Phi} > 0$ .

Part 1. (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \gamma]$  and  $\lambda \geq \bar{\Phi}$ . In fact, by continuity and using the strong maximum principle to angular derivative, one gets that (3.1) holds for  $\vartheta \in (\pi/2 - \alpha, \gamma)$  and  $\lambda \geq \bar{\Phi}$ ; see details in step 1 of Theorem 3.9. For  $\vartheta = \pi/2 - \alpha$ ,  $\vartheta_1 = 0$ ,  $\vartheta_3 = \pi - 2\alpha$  and  $\lambda \geq \bar{\Phi}$ , we have  $\vartheta_3 \in [\pi/2 - \alpha, \gamma]$ ,  $\Gamma^{2B}_{\lambda} = \emptyset$ , and  $w^{\lambda,\vartheta}$  satisfies (3.8). Therefore, (3.4) and (3.1) hold for  $\vartheta = \pi/2 - \alpha$  and  $\lambda \geq \bar{\Phi}$ . For  $\vartheta = \gamma$ ,  $\vartheta_3 = \pi$ ,  $\vartheta_1 = 2\gamma - \pi$  and  $\lambda \geq \bar{\Phi}$ , we have  $\Gamma^{2B}_{\lambda} \subset T_{2\lambda,\gamma}$  and  $\Gamma^{2A}_{\lambda} \subset T_{\lambda,2\gamma-\pi}$ . The condition (5.3) implies  $2\gamma - \pi \in [\pi/2 - \alpha, \gamma]$ , and  $w^{\lambda,\vartheta}$  satisfies (3.8). Therefore, (3.4) and (3.1) hold for  $\vartheta = \gamma$  and  $\lambda \geq \bar{\Phi}$ .

**Part 2**. The tangential derivative along the shortest Neumann boundary of u does not vanish by a new methods:

<span id="page-20-1"></span>
$$\nabla u \cdot e_{\alpha - \pi/2} < 0 \text{ on } \Gamma_N^- \cap T_{\lambda, \pi/2}$$
 (5.4)

for  $\lambda \geq \bar{\Phi}$ .

As usual, in many case (5.4) is obtained by Serrin's boundary lemma to the positive function  $w^{\lambda,\pi/2}$ , however it is difficult to show the positive of  $w^{\lambda,\pi/2}$ . We will use a new method to derive the strictly monotonicity of u on the shortest Neumann boundary. One can use the local analysis in [29] (see details in [42, Lemma 4.6]) to get (5.4). We also put the details here.

Let  $\lambda \in [\bar{\Phi}, \Phi_0)$  and  $\bar{x} = (\bar{x}_1, \bar{x}_2)$  with  $\bar{x}_1 = \lambda \sin \alpha$ ,  $\bar{x}_2 = -\lambda \cos \alpha$ . We see that the angular derivative  $R_{\bar{x}}u$ , defined in (3.23), satisfies  $R_{\bar{x}}u = 0$  on  $\Gamma_N^-$  and

$$\Delta R_{\bar{x}}u + f'(u)R_{\bar{x}}u = 0.$$

From [29], there exists a positive integer l such that

<span id="page-20-2"></span>
$$(R_{\bar{x}}u)(r,\vartheta) = C_0 r^l \sin(l\vartheta) + O(r^{l+1}), \tag{5.5}$$

for some  $C_0 \in \mathbb{R} \setminus \{0\}$  and  $(r, \vartheta)$  is a polar coordinate of  $x = (x_1, x_2)$  around  $\bar{x}$ , Here  $O(r^{l+1})/r^{l+1}$  is bounded as  $r \to 0$ ,  $\vartheta$  is the polar angle from  $\bar{x}P^+$  to  $\bar{x}x$  (so the boundary at  $\bar{x}$  is given by the equation  $\sin \vartheta = 0$ ). Part 1 implies that

$$(R_{\bar{x}}u)(r,\vartheta) > 0 \text{ for } \vartheta \in [\pi/2 - \alpha, \gamma].$$

Combining this with (5.5), we get that

<span id="page-20-3"></span>
$$C_0 \sin(l\vartheta) > 0 \text{ for } \vartheta \in (\pi/2 - \alpha, \gamma).$$
 (5.6)

It follows that the length of interval  $(\pi/2 - \alpha, \gamma)$  is smaller than or equals to  $\pi/l$ , so

$$l \le \frac{\pi}{\gamma - (\pi/2 - \alpha)} = \frac{\pi}{\pi/2 - \beta} < 4$$

since  $\beta < \pi/4$ . Observing the fact that  $\pi/2 \in (\pi/2 - \alpha, \gamma)$ , we deduce from (5.6) that  $C_0 \sin(l\pi/2) > 0$ , and hence l is an odd positive integer.

<span id="page-21-3"></span>Now l=3 is impossible. In fact, if l=3, then (5.6) becomes

$$C_0 \sin(3\vartheta) > 0$$
 for  $\vartheta \in (\pi/2 - \alpha, \gamma)$ .

Noting that  $3(\pi/2 - \alpha) < 3\pi/2$  and  $3\gamma > 3\pi/2$ , we get  $C_0 < 0$  and

$$3(\pi/2 - \alpha) \ge \pi$$
,  $3\gamma \le 2\pi$ ,

which yields a contradiction to  $\gamma > \pi - 2\alpha$  (i.e.,  $\alpha > \beta$ ).

Combining the argument of positive integer l, we conclude l < 4, l is odd,  $l \neq 3$  and thus l must be 1 and  $C_0 > 0$ . Thus, the outward normal derivatives of v at  $\bar{x}$  does not vanish and is negative, say  $\partial_{\nu}v(\bar{x}) < 0$ . Therefore, (5.4) is valid.

**Part 3.** (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \gamma]$  and  $\bar{\Phi} - \lambda \ll 1$ .

Note that u has strictly monotonicity near lower Neumann boundary (see (5.4)) and Dirichlet boundary (see Lemma 2.3) and in the interior of  $\Omega$  (see part 1). It follows by continuity that (3.1) holds for  $\vartheta \in [\pi - 2\alpha, \gamma]$  and  $\lambda \geq \bar{\Phi} - \varepsilon$  for some small constant  $\varepsilon > 0$ . Again following by the same process in step 2 of Lemma 3.3, one deduces that (3.1) holds for  $\vartheta \in [\pi/2 - \alpha, \pi - 2\alpha]$  and  $\lambda \geq \bar{\Phi} - \varepsilon$ .

This contradicts to the definition of  $\bar{\Phi}$ . Thus,  $\bar{\Phi} = 0$  and this completes the proof.

<span id="page-21-2"></span>Now we turn to show that the maximum point may not locate at the vertex of  $\Omega$ .

**Lemma 5.3.** Let  $\gamma > \pi/2$  and  $\alpha > \beta$ . Suppose that

<span id="page-21-0"></span>
$$\nabla u \cdot e_{-\beta} < 0 \text{ in } \Omega. \tag{5.7}$$

Then the global maximum of u does not attain at the vertices of triangle  $\Omega$ .

*Proof.* The proof is divided into two parts.

**Part 1.** We claim that (5.7) implies that (3.1) holds for  $\lambda > 0$  and  $\vartheta \in [\pi/2 - \alpha, \gamma]$  and

<span id="page-21-1"></span>
$$\nabla u \cdot e_{\alpha - \pi/2} < 0 \text{ on } \operatorname{Int}(\Gamma_N^-).$$
 (5.8)

Indeed, we note that  $\alpha>\beta$  guarantees that  $\gamma/2>\pi/2-\alpha$ . For  $\vartheta=\gamma/2$ ,  $\vartheta_1=0$ ,  $\vartheta_3=\gamma$  and  $\lambda\geq 0$ , it follows from (5.7) that  $w^{\lambda,\vartheta}$  satisfies (3.8), and hence (3.6) and (3.1) are valid by applying Lemma 3.1. By the same process of step 1.1 in Lemma 3.3, one can deduce (3.1) for  $\theta\in [\gamma/2,\gamma]$  and  $\lambda\geq 0$ . By the same process of step 1.2 in Lemma 3.3, one can deduce (3.1) for  $\lambda\geq 0$  and  $\theta\in \cup_{k=1}^\infty[\min\{2^{-k}\gamma,\ \pi/2-\alpha\},\ \gamma]$ . In particular,

$$\nabla u \cdot e_{\alpha-\pi/2} < 0 \text{ in } \Omega \cap \{x \cdot e_{\alpha-\pi/2} \ge 0\}$$

and hence

$$\nabla \tilde{u} \cdot e_{\alpha - \pi/2} \le \not\equiv 0 \text{ in } \tilde{\Omega} \cap \{x \cdot e_{\alpha - \pi/2} > 0\},$$

where  $\tilde{u}$  stands for the even expansion and  $\tilde{\Omega}$  is the double domain by reflection along lower Neumann boundary  $\Gamma_N^-$ , see (5.2). Recalling that  $\nabla \tilde{u} \cdot e_{\alpha-\pi/2}$  satisfies the linear equation  $\Delta(\nabla \tilde{u} \cdot e_{\alpha-\pi/2}) + f'(\tilde{u})(\nabla \tilde{u} \cdot e_{\alpha-\pi/2}) = 0$  in  $\tilde{\Omega}$ , the strong maximum principle implies that the positivity of  $\nabla \tilde{u} \cdot e_{\alpha-\pi/2}$  in  $\tilde{\Omega}$ . Hence (5.8) holds.

**Part 2**. We claim that the origin O is not an extremum point of u.

Let  $(r, \theta)$  be the standard polar coordinates. From the regularity of solution in domain with conical points (e.g., Theorem 6.4.2.5 in [27]), one has

$$u(r,\theta) = c_0 - c_1 r^{\omega} \cos(\omega(\theta - \alpha + \pi/2)) - \frac{1}{2}c_2 r^2 + o(r^2)$$

where  $\omega = \pi/\gamma \in (1, 2)$ ,  $c_0 = u(0) > 0$ ,  $c_2 = f(c_0)$ . Let

$$v(x) = x_1 \partial_{x_2} u(x) - x_2 \partial_{x_1} u(x). \tag{5.9}$$

<span id="page-22-4"></span>Thanking to (5.7) and  $\alpha > \beta$ , it follows by the same argument in Lemma 3.2 that (3.1) holds for  $\lambda \geq 0$  and  $\vartheta \in [\pi/2 - \alpha, \gamma]$ . In particular,

<span id="page-22-1"></span>
$$v(x) > 0 \text{ for } 0 \le x_2 < x_1 \cot \beta.$$
 (5.10)

Recall that v satisfies linear equation

$$[\Delta + f'(u)]v = 0$$
 in  $\Omega$  and  $v = 0$  on  $\Gamma_N$ ,

and  $v \not\equiv 0$  in  $\Omega$  and in any neighborhood of x = O. By [29] and [32], there exist an positive integer l and a constant  $c_l \neq 0$  such that

$$v(r,\theta) = l\omega c_l r^{l\omega} \sin(l\omega(\theta - \alpha + \pi/2)) + o(r^{l\omega}).$$

Moreover, the nodal line  $\mathcal{Z}(v) = \overline{\{x \in \Omega : v(x) = 0\}}$  has exactly l+1 branches near O, each branches is tangential to the line

$$x_1 \cos(\frac{j\gamma}{l} + \alpha) + x_2 \cos(\frac{j\gamma}{l} + \alpha) = 0$$

at the origin O,  $j=0,1,\ldots,l$ . Combining this with (5.10), we get  $\gamma/l \geq \pi/2 - \beta$ , so  $l \leq \gamma/(\pi/2 - \beta)$ . Recalling that  $\alpha > \beta$ , we get  $\gamma = \pi - \alpha - \beta < 2(\pi/2 - \beta)$  and then l < 2. Thus, l=1 and v is positive in a neighborhood of x=O. (5.10) now implies  $c_1 > 0$  and

$$v(r,\theta) = c_1 \omega r^{\omega} \sin(\omega(\theta - \alpha + \pi/2)) + o(r^2).$$

In particular, the origin is not an extremum point of u.

<span id="page-22-0"></span>As a direct consequence of Lemma 5.1, Lemma 5.2 and Lemma 5.3, we get Theorem 1.4.

## 6. The eigenfunction with obtuse Neumann vertex

<span id="page-22-3"></span>This section is considered the linear case (1.1).

**Theorem 6.1.** Let  $\mu$  and u be the first eigenpair of the mixed eigenvalue problem

<span id="page-22-2"></span>
$$\Delta u + \mu u = 0 \text{ in } \Omega, \quad u = 0 \text{ on } \Gamma_D, \quad \partial_{\nu} u = 0 \text{ on } \Gamma_N.$$
 (6.1)

Here  $\Omega$  is an obtuse triangle, the Dirichlet boundary  $\Gamma_D$  is the longest side, and Neumann boundary  $\Gamma_N$  is the remain sides.

Then u is monotone along the normal direction of the longer Neumann boundary. Moreover, u has at most one non-vertex critical point, which lies on the interior of the shortest Neumann boundary; the non-vertex critical point of u exists if and only if  $\Omega$  is non-isosceles.

*Proof.* The isosceles triangle case is dealt in Theorem 4.1. Now we only consider the non-isosceles obtuse triangle, without loss of generality, we assume that the triangle  $\Omega$  has three vertices  $z_0(0,0)$ ,  $z_1(1,a)$  and  $z_2(1,b)$ ,  $\Gamma_D$  is the side  $z_1z_2$ ,  $\Gamma_N=\partial\Omega\setminus\Gamma_D$ , and a,b satisfy

$$b > -a > 0$$
 and  $-ab > 1$ .

The proof is based on the continuity methods via domain perturbation as in [12, 33, 34]. We construct a continuous family of triangles  $\Omega^t$  with three vertices

$$z_0(0,0), z_1^t(1,ta) \text{ and } z_2^t(1,tb)$$

for  $t \in [1, +\infty)$ . Similarly, one can denote the following notations  $\Gamma_D^t$ ,  $\Gamma_N^t$ ,  $(\Gamma_N^-)^t = \Gamma_N^t \cap \{x_2 \le 0\}$  and  $(\Gamma_N^+)^t = \Gamma_N^t \cap \{x_2 \ge 0\}$ . We usually denote by  $\gamma^t$  the inner angle of the triangle  $\Omega^t$ 

<span id="page-23-6"></span>at the vertex  $z_0$ ,  $\gamma^t \in (\pi/2, \pi)$ . Let  $\mu^t$  and  $u^t$  be the principal eigenvalue and the corresponding eigenfunction of (6.1) with  $\Omega = \Omega^t$ . For simplicity, we assume  $u^t$  is positive and normalized,

$$\int_{\Omega^t} |u^t|^2 dx = 1.$$

It is clear that  $\mu^t$  is simple, and hence both  $t \in [1, +\infty) \mapsto \mu^t$  and  $t \in [1, +\infty) \mapsto u^t$  are continuous. Following by Lemma 5.2, we have

<span id="page-23-0"></span>
$$(tb, -1) \cdot \nabla u^t < 0 \text{ in } \Omega^t, \quad (1, ta) \cdot \nabla u^t < 0 \text{ on } \operatorname{Int}((\Gamma_N^-)^t)$$
(6.2)

whenever  $\gamma^t \geq 2\pi/3$  (in particular for sufficient large t). Now we denote

$$\tau = \sup\{t \in [1, +\infty) : (6.2) \text{ holds false}\}.$$

**Step 1**. The property of  $u^{\tau}$ . In fact, by the definition of  $\tau$ , (6.2) holds for every  $t > \tau$ . Hence the continuity implies that  $(\tau b, -1) \cdot \nabla u^{\tau} \leq 0$  in  $\Omega^{\tau}$ . Recalling that

$$\Delta(\tau b\partial_{x_1}u^\tau-\partial_{x_2}u^\tau)+\mu^t(\tau b\partial_{x_1}u^\tau-\partial_{x_2}u^\tau)=0 \text{ in } \Omega^\tau,$$

it follows by strong maximum principle and step 1 of Lemma 5.3 that

<span id="page-23-5"></span><span id="page-23-1"></span>
$$(\tau b, -1) \cdot \nabla u^{\tau} < 0 \text{ in } \Omega^{\tau},$$

$$(1, \tau a) \cdot \nabla u^{\tau} < 0 \text{ on } \operatorname{Int}((\Gamma_{N}^{-})^{\tau}).$$

$$(6.3)$$

It immediately follows that the first Dirichlet eigenvalue  $\lambda_1(\Omega^{\tau})$  is strictly larger than  $\mu^{\tau}$ ,  $\lambda_1(\Omega^{\tau}) > \mu^{\tau}$ . From the regularity of solution in domain with conical points (e.g., Theorem 6.4.2.5 in [27]), one has

$$u^{\tau}(r,\theta) = c_0^{\tau} - c_1^{\tau} r^{\omega_{\tau}} \cos(\omega^{\tau}(\theta - \alpha + \pi/2)) + o(r^2),$$

$$\nabla u^{\tau}(r,\theta) = -c_1^{\tau} \nabla (r^{\omega_{\tau}} \cos(\omega^{\tau}(\theta - \alpha + \pi/2))) + o(r),$$
(6.4)

where  $\omega_{\tau} = \pi/\gamma^{\tau} \in (1,2)$ ,  $c_1^{\tau} > 0$  by step 2 of of Lemma 5.3. As a directly consequence of (6.4), one can find a small constant  $\delta_1 \in (0,1)$  (assuming  $\delta_1 < j_{0,1}/\sqrt{\mu^{\tau}}$ ) such that

$$\nabla u^{\tau} \cdot (1, \tau b) > 0 \text{ in } \{x \in \overline{\Omega^{\tau}} : \ 0 < |x| \le \delta_1\},$$

where  $j_{0,1}$  is the first positive zero of the first kind Bessel function  $J_0$  of order 0.

**Step 2**. We prove  $\tau=1$  and the monotonicity property of  $u^t$  holds for every  $t\geq 1$ . In fact, we suppose  $\tau>1$  by contradiction. By continuity, there exists a small constant  $\varepsilon_1>0$  such that for  $|t-\tau|<\varepsilon_1$ ,

<span id="page-23-4"></span><span id="page-23-3"></span>
$$\mu^t < j_{0,1}^2/\delta_1^2, \quad \lambda_1(\Omega^t) > \mu^t,$$
(6.5)

$$u^{t} > 0 \text{ in } \overline{\mathcal{U}_{O}^{t}} \text{ and } \nabla u^{t} \cdot (1, tb) > 0 \text{ on } \Gamma^{t},$$
 (6.6)

where  $\mathcal{U}_O^t = \{x \in \Omega^t : |x| < \delta_1\}$ , and  $\Gamma^t = \{x \in \overline{\Omega^t} : |x| = \delta_1\} \subset \partial \mathcal{U}_O^t$ .

Step 2.1. We prove that

<span id="page-23-2"></span>
$$w^{t} = \nabla u^{t} \cdot (1, tb) / \sqrt{1 + t^{2}b^{2}} > 0 \text{ in } \mathcal{U}_{O}^{t}$$
(6.7)

for any fixed  $t \in (\tau - \varepsilon_1, \tau + \varepsilon_1)$ . In fact, we prove it indirectly and suppose that (6.7) is false. Recalling that the strong maximum principle implies that  $w^t$  is positive if it is nonnegative, so  $w^t$  is negative at some point in  $\mathcal{U}_O^t$ . Now we let D be a connected component of  $\{x \in \mathcal{U}_O^t : w^t(x) < 0\}$ . From (6.6),  $\partial D \cap \Gamma^t = \emptyset$ . Set

$$\phi(x) = \begin{cases} w^t & \text{if } x \in D, \\ 0 & \text{if } x \notin D. \end{cases}$$

<span id="page-24-2"></span>Then  $\phi \in W^{1,2}(\mathcal{U}_O^t)$  and  $\phi = 0$  on  $\Gamma^t$ . Note that  $\phi$  satisfies zero Neumann boundary condition on  $(\Gamma_N^-)^+$ , we have

$$\int_{\mathcal{U}_O^t} |\nabla \phi|^2 dx = \mu^t \int_{\mathcal{U}_O^t} |\phi|^2 dx + \int_{\partial \mathcal{U}_O^t} \phi \cdot \partial_{\nu} \phi ds_x = \mu^t \int_{\mathcal{U}_O^t} |\phi|^2 dx + \int_{\Gamma_*} \phi \cdot \partial_{\nu} \phi ds_x,$$

where  $\Gamma_* = \partial D \cap (\Gamma_N^-)^t$ . Note that the inequality

<span id="page-24-0"></span>
$$\int_{\Gamma_x} \partial_\nu w^t \cdot w^t ds_x \le 0 \tag{6.8}$$

is true when  $\Gamma_*$  has no interior. Now we turn to show (6.8) when  $\Gamma_*$  has non-empty interior by a simple technique follows from Terence Tao [37]. The interior of  $\Gamma_*$  is the union of many segments  $L_i = \overline{P_{2i}P_{2i+1}}, i = 0, \ldots, m \ (m \le \infty)$  where  $P_i$  is on the right of  $P_{i+1}$ , and all points  $P_i$  are distinct. Let us denote the tangential and normal vector of  $(\Gamma_N^-)^t$  by  $e = (1, ta)/\sqrt{1 + t^2a^2}$  and  $e^{\perp} = (-ta, 1)/\sqrt{1 + t^2a^2}$ , respectively. Then

$$\frac{(1,tb)}{\sqrt{1+t^2b^2}} = c_1e + c_2e^{\perp} \text{ and } w^t = c_1\partial_e u^t + c_2\partial_{e^{\perp}}u^t,$$

where  $c_1 = \cos \gamma^t < 0$ ,  $c_2 = \sin \gamma^t > 0$ . By directly computation, we have

$$\int_{\Gamma_*} \phi \partial_{\nu} \phi ds_x = \int_{\Gamma_*} (-c_2(\partial_{e^{\perp}})^2 u^t) \cdot (c_1 \partial_e u^t) ds_x = c_1 c_2 \int_{\Gamma_*} ((\partial_e)^2 u^t + \mu^t u^t) \cdot \partial_e u^t ds_x.$$

Recalling  $w^t < 0$  in D, we have  $\partial_e u^t \ge 0$  on  $\partial D \cap (\Gamma_N^+)^t$ , and

$$\int_{\Gamma_*} u^t \partial_e u^t ds_x \ge 0.$$

It follows by the definition of  $P_i$  that  $w^t(P_i) = 0$  and hence  $|\nabla u^t|(P_i) = 0$ ,

$$\int_{\Gamma_*} (\partial_e)^2 u^t \partial_e u^t ds_x = \frac{1}{2} \int_{\Gamma_*} \partial_e \left( \partial_e u^t \right)^2 ds_x = \frac{1}{2} \sum_{i=0}^m (|\partial_e u^t (P_{2i})|^2 - |\partial_e u^t (P_{2i+1})|^2) = 0.$$

Hence, (6.8) is always valid, and

$$\int_{\mathcal{U}_O^t} |\nabla \phi|^2 dx \le \mu^t \int_{\mathcal{U}_O^t} |\phi|^2 dx,$$

which implies that

$$\lambda_1^{mix}(\mathcal{U}_O^t, \Gamma^t) < \mu^t$$

where  $\lambda_1^{mix}(\mathcal{U}_O^t, \Gamma^t)$  stands for the first mixed eigenvalue of

$$\Delta\varphi + \lambda_1^{mix}\varphi = 0 \text{ in } \mathcal{U}_O^t, \quad \varphi = 0 \text{ on } \Gamma^t, \quad \partial_\nu\varphi = 0 \text{ on } \partial\mathcal{U}_O^t \setminus \Gamma^t.$$

Observing that  $\lambda_1^{mix}(\mathcal{U}_O^t, \Gamma^t)$  equals to the first Dirichlet eigenvalue in ball of radius  $\delta_1$ , we get  $\lambda_1^{mix}(\mathcal{U}_O^t, \Gamma^t) = (j_{0,1}/\delta_1)^2$  and  $(j_{0,1}/\delta_1)^2 \leq \mu^t$ . This yields a contradiction to (6.5). Hence we finish the proof of (6.7).

Step 2.2. We show the monotonicity property of  $u^t$ . Indeed, from Lemma 3.4,  $u^t$  is monotone at least in a neighborhood of the lower mixed boundary point  $z_1^t = (1, ta)$ , and there exist two small constants  $\delta_2 > 0$  and  $\varepsilon_2 > 0$  such that

<span id="page-24-1"></span>
$$\nabla u^t \cdot (-tb, 1) > 0 \text{ in } \mathcal{U}_A^t, \tag{6.9}$$

<span id="page-25-2"></span>for  $|t-\tau|<\varepsilon_2$  where  $\mathcal{U}_A^t=\{x\in\overline{\Omega^t}:\ 0<|x-z_1^t|<\delta_2\}$ . From (6.3), there exists a small constant  $\varepsilon_3>0$  such that

$$(1, \tau a) \cdot \nabla u^t < 0 \text{ on } (\Gamma_N^-)^t \cap \{|x| \ge \delta_1, |x - z_1^t| \ge \delta_2\}.$$

Combining this with (6.7) and (6.9), we get that  $(1, ta) \cdot \nabla u^t \leq 0$  on  $(\Gamma_N^-)^t$  for  $|t - \tau| < \varepsilon = \min\{\varepsilon_1, \varepsilon_2\}$ . Hence

$$\tilde{w} = (tb, -1) \cdot \nabla u^t \le \not\equiv 0 \text{ on } \partial \Omega^t.$$

Suppose that  $\tilde{w}$  is positive in a connected component  $\tilde{D}$  of  $\{x \in \Omega^t : \tilde{w}(x) \neq 0\}$ , then

$$-\Delta \tilde{w} = \mu^t \tilde{w} > 0 \text{ in } \tilde{D}, \ \tilde{w} = 0 \text{ on } \partial \tilde{D}.$$

It follows that  $\lambda_1(\tilde{D}) = \mu^t$ . By variational characterization of eigenvalue, we have  $\lambda_1(\Omega^t) < \lambda_1(\tilde{D})$  and then  $\lambda_1(\Omega^t) < \mu^t$ . This yields a contradiction to (6.5). Thus, we derive the non-positivity of  $\tilde{w}$ , and the strong maximum principle gives the negativity of  $\tilde{w}$ ,

$$(tb, -1) \cdot \nabla u^t < 0 \text{ in } \Omega^t$$

for  $|t-\tau|<\varepsilon$ . This gives a contradiction to the definition of  $\tau$ . Hence  $\tau=1$  and step 2 follows. **Step 3**. The uniqueness of non-vertex critical point.

Now we let  $\Omega = \Omega^1$  and u be in Theorem 6.1. Following by step 1 and step 2, we have show the u is monotone along the normal direction of  $\Gamma_N^+$ , and u has non-zero tangential derivative along the lower Neumann boundary.

Set  $w = \nabla u \cdot (1, b) / \sqrt{1 + b^2}$ . From Lemma 3.4 and (6.4), one has

$$w > 0 \text{ on } \Gamma_N^+ \cap \{0 < |x| \le \delta_4\} \text{ and } w < 0 \text{ on } \Gamma_N^+ \cap \{0 < |x - z_2| \le \delta_4\},$$

for some  $\delta_4 > 0$ . It follows that w = 0 at some interior point of  $\Gamma_N^+$ , and u admits at least one critical point on the interior of  $\Gamma_N^+$ . Recalling that

$$w>0 \text{ on } \operatorname{Int}(\Gamma_N^-), \quad w<0 \text{ on } \operatorname{Int}(\Gamma_D),$$

we denote by  $\mathcal{D}_1$  and  $\mathcal{D}_2$  the two connected components of  $\{x \in \Omega : w(x) \neq 0\}$  such that  $\partial \mathcal{D}_1 \supset \Gamma_N^-$  and  $\partial \mathcal{D}_2 \supset \Gamma_D$ . In order to show  $\mathcal{D}_1$  and  $\mathcal{D}_2$  are all connected components of  $\{x \in \Omega : w(x) \neq 0\}$ , we suppose that  $\{x \in \Omega \setminus (\mathcal{D}_1 \cup \mathcal{D}_2) : w(x) \neq 0\}$  has a non-empty connected component, denoted by  $\mathcal{D}_3$ . Then

$$-\Delta w = \mu w \neq 0 \text{ in } \mathcal{D}_3, \ \partial_{\nu} w = 0 \text{ on } \partial \mathcal{D}_3 \cap \Gamma_N^+, \ w = 0 \text{ on } \partial \mathcal{D}_3 \setminus \Gamma_N^+.$$

It follows that  $\mu = \lambda_1(\mathcal{D}_3, \partial \mathcal{D}_3 \setminus \Gamma_N^+)$ . By variational character of eigenvalue,  $\lambda_1(\mathcal{D}_3, \partial \mathcal{D}_3 \setminus \Gamma_N^+) > \lambda_1(\Omega, \Gamma_D \cup \Gamma_N^-) > \lambda_1(\Omega, \Gamma_D) = \mu$ . This is a contradiction. Hence,  $\mathcal{D}_1$  and  $\mathcal{D}_2$  are all connected components of  $\{x \in \Omega : w(x) \neq 0\}$ . Combining this with the definition of  $\mathcal{D}_1$ ,  $\mathcal{D}_2$ , and the local structure of nodal line and nodal domain of w (see [31]), we conclude that the closure of  $\{x \in \Omega : w(x) = 0\}$  is a smooth curve with two endpoints  $z_1$  and  $\bar{z} \in \text{Int}(\Gamma_N^+)$ ,  $w(\bar{z}) = 0$ , the non-vertex critical point of u is unique and a non-degenerate maximum point.

### REFERENCES

- <span id="page-25-0"></span>[1] A.D. Alexandrov. A characteristic property of spheres. *Ann. Mat. Pura Appl.* (4), 58(1):303–315, 1962. 1
- <span id="page-25-1"></span>[2] Henri Berestycki, Luis Caffarelli, and Louis Nirenberg. Symmetry for elliptic equations in a half space. In *Boundary value problems for partial differential equations and applications*, pages 27–42. 1993. 2

- <span id="page-26-3"></span>[3] Henri Berestycki, Luis Caffarelli, and Louis Nirenberg. Inequalities for second-order elliptic equations with applications to unbounded domains I. *Duke Math. J.*, 81(2):467–494, 1996. [2](#page-1-3)
- <span id="page-26-4"></span>[4] Henri Berestycki, Luis Caffarelli, and Louis Nirenberg. Further qualitative properties for elliptic equations in unbounded domains. *Ann. Scuola Norm. Sup. Pisa Cl. Sci. (4)*, 25(1- 2):69–94, 1997. [2](#page-1-3)
- <span id="page-26-5"></span>[5] Henri Berestycki, Luis Caffarelli, and Louis Nirenberg. Monotonicity for elliptic equations in unbounded Lipschitz domains. *Comm. Pure Appl. Math.*, 50(11):1089–1111, 1997. [2](#page-1-3)
- <span id="page-26-0"></span>[6] Henri Berestycki and Louis Nirenberg. Monotonicity, symmetry and antisymmetry of solutions of semilinear elliptic equations. *J. Geom. Phys.*, 5(2):237–275, 1988. [1,](#page-0-1) [2](#page-1-3)
- <span id="page-26-1"></span>[7] Henri Berestycki and Louis Nirenberg. Some qualitative properties of solutions of semilinear elliptic equations in cylindrical domains. In *Analysis, et cetera*, pages 115–164. Elsevier, 1990. [1,](#page-0-1) [2](#page-1-3)
- <span id="page-26-2"></span>[8] Henri Berestycki and Louis Nirenberg. On the method of moving planes and the sliding method. *Bol. Soc. Brasil. Mat. (N.S.)*, 22(1):1–37, 1991. [1,](#page-0-1) [2](#page-1-3)
- <span id="page-26-17"></span>[9] Henri Berestycki, Louis Nirenberg, and SR Srinivasa Varadhan. The principal eigenvalue and maximum principle for second-order elliptic operators in general domains. *Comm. Pure Appl. Math.*, 47(1):47–92, 1994. [12,](#page-11-7) [16](#page-15-3)
- <span id="page-26-10"></span>[10] Henri Berestycki and Filomena Pacella. Symmetry properties for positive solutions of elliptic equations with mixed boundary conditions. *J. Funct. Anal.*, 87(1):177–211, 1989. [2,](#page-1-3) [4,](#page-3-4) [5](#page-4-3)
- <span id="page-26-6"></span>[11] Luis A Caffarelli, Basilis Gidas, and Joel Spruck. Asymptotic symmetry and local behavior of semilinear elliptic equations with critical Sobolev growth. *Comm. Pure Appl. Math.*, 42(3):271–297, 1989. [2](#page-1-3)
- <span id="page-26-16"></span>[12] Hongbin Chen, Changfeng Gui, and Ruofei Yao. Uniqueness of critical points of the second Neumann eigenfunctions on triangles. *arXiv preprint arXiv:2311.12659*, 2023. [2,](#page-1-3) [3,](#page-2-3) [23](#page-22-4)
- <span id="page-26-12"></span>[13] Hongbin Chen, Rui Li, and Ruofei Yao. Symmetry of positive solutions of elliptic equations with mixed boundary conditions in a sub-spherical sector. *Nonlinearity*, 34(6):3858–3878, 2021. [2](#page-1-3)
- <span id="page-26-9"></span>[14] Hongbin Chen, Ke Wu, and Ruofei Yao. Qualitative properties of nonnegative solutions of some semilinear elliptic equations in cylindrical domains. *Calc. Var. Partial Differential Equations*, 62(6):178, 2023. [2](#page-1-3)
- <span id="page-26-13"></span>[15] Hongbin Chen and Ruofei Yao. Symmetry and monotonicity of positive solution of elliptic equation with mixed boundary condition in a spherical cone. *J. Math. Anal. Appl.*, 461(1):641–656, 2018. [2](#page-1-3)
- <span id="page-26-7"></span>[16] Wenxiong Chen and Congming Li. Classification of solutions of some nonlinear elliptic equations. *Duke Math. J.*, 63(3):615–622, 1991. [2](#page-1-3)
- <span id="page-26-11"></span>[17] Chie-Ping Chu and Hwai-Chiuan Wang. Symmetry properties of positive solutions of elliptic equations in an infinite sectorial cone. *Proc. Roy. Soc. Edinburgh Sect. A*, 122(1-2):137–160, 1992. [2](#page-1-3)
- <span id="page-26-8"></span>[18] Carmen Cort´azar, Manuel Elgueta, and Jorge Garc´ıa-Meli´an. Nonnegative solutions of semilinear elliptic equations in half-spaces. *J. Math. Pures Appl.*, 106(5):866–876, 2016. [2](#page-1-3)
- <span id="page-26-14"></span>[19] Lucio Damascelli and Filomena Pacella. Morse, index and symmetry for elliptic problems with nonlinear mixed boundary conditions. *Proc. Roy. Soc. Edinburgh Sect. A*, 149(2):305– 324, 2019. [2](#page-1-3)
- <span id="page-26-15"></span>[20] Juan D´avila and Julio D. Rossi. Self-similar solutions of the porous medium equation in a half-space with a nonlinear boundary condition: existence and symmetry. *J. Math. Anal. Appl.*, 296(2):634–649, 2004. [2](#page-1-3)

- <span id="page-27-8"></span>[21] Matteo De Cesare and Filomena Pacella. Geometrical properties of positive solutions of semilinear elliptic equations in some unbounded domains. *Boll. Un. Mat. Ital. B* (7), 3(3):691–703, 1989
- <span id="page-27-3"></span>[22] Louis Dupaigne and Alberto Farina. Classification and Liouville-type theorems for semilinear elliptic equations in unbounded domains. *Analysis & PDE*, 15(2):551–566, 2022. 2
- <span id="page-27-4"></span>[23] Alberto Farina. Some results about semilinear elliptic problems on half-spaces. *Math. Eng*, 2(4):709–721, 2020. 2
- <span id="page-27-5"></span>[24] Alberto Farina, Berardino Sciunzi, and Enrico Valdinoci. Bernstein and De Giorgi type problems: new results via a geometric approach. *Ann. Sc. Norm. Super. Pisa Cl. Sci.* (5), 7(4):741–791, 2008. 2
- <span id="page-27-1"></span>[25] Basilis Gidas, Wei-Ming Ni, and Louis Nirenberg. Symmetry and related properties via the maximum principle. *Comm. Math. Phys.*, 68(3):209–243, 1979. 1, 2, 4, 5
- <span id="page-27-2"></span>[26] Basilis Gidas, Wei-Ming Ni, and Louis Nirenberg. Symmetry of positive solutions of nonlinear elliptic equations in  $\mathbb{R}^N$ . *Adv. Math. Suppl. Stud.*, *A*, 7:369–402, 1981. 1
- <span id="page-27-17"></span>[27] Pierre Grisvard. Elliptic problems in nonsmooth domains. SIAM, 2011. 4, 22, 24
- <span id="page-27-6"></span>[28] Changfeng Gui and Amir Moradifam. The sphere covering inequality and its applications. *Invent. Math.*, 214(3):1169–1204, 2018. 2
- <span id="page-27-18"></span>[29] Philip Hartman and Aurel Wintner. On the local behavior of solutions of non-parabolic partial differential equations. *Amer. J. Math.*, 75(3):449–476, 1953. 4, 21, 23
- <span id="page-27-16"></span>[30] Lawford Hatcher. First mixed Laplace eigenfunctions with no hot spots. *arXiv preprint* arXiv:2401.01514, 2024. 3
- <span id="page-27-20"></span>[31] Bernard Helffer, Maria Hoffmann-Ostenhof, Thomas Hoffmann-Ostenhof, and Mark P Owen. Nodal sets for groundstates of Schrödinger operators with zero magnetic field in non-simply connected domains. *Comm. Math. Phys.*, 202(3):629–649, 1999. 26
- <span id="page-27-19"></span>[32] Bernard Helffer, Thomas Hoffmann-Ostenhof, and Susanna Terracini. Nodal domains and spectral minimal partitions. *Ann. Inst. H. Poincaré Anal. Non Linéaire*, 26(1):101–138, 2009. 4, 23
- <span id="page-27-13"></span>[33] David Jerison and Nikolai Nadirashvili. The "hot spots" conjecture for domains with two axes of symmetry. *J. Amer. Math. Soc.*, 13(4):741–772, 2000. 2, 3, 4, 23
- <span id="page-27-14"></span>[34] Chris Judge and Sugata Mondal. Euclidean triangles have no hot spots. *Ann. of Math.* (2), 191(1):167–211, 2020. 3, 23
- <span id="page-27-12"></span>[35] Chris Judge and Sugata Mondal. Erratum: Euclidean triangles have no hot spots. *Ann. of Math.* (2), 195(1):337–362, 2022. 2
- <span id="page-27-7"></span>[36] Yanyan Li and Meijun Zhu. Uniqueness theorems through the method of moving spheres. *Duke Math. J.*, 80(2):383–418, 1995. 2
- <span id="page-27-11"></span>[37] Polymath. Polymath project 7 research thread 5: the hot spots conjecture, June 3, 2012 through August 9, 2013. https://polymathprojects.org/2013/08/09/polymath7-research-thread-5-the-hot-spots-conjecture/. 2, 25
- <span id="page-27-0"></span>[38] James Serrin. A symmetry problem in potential theory. *Arch. Rational Mech. Anal.*, 43(4):304–318, 1971. 1, 5
- <span id="page-27-15"></span>[39] Bartłomiej Andrzej Siudeja. On mixed Dirichlet-Neumann eigenvalues of triangles. *Proc. Amer. Math. Soc.*, 144(6):2479–2493, 2016. 3
- <span id="page-27-9"></span>[40] Susanna Terracini. Symmetry properties of positive solutions to some elliptic equations with nonlinear boundary conditions. *Differential Integral Equations*, 8(8):1911–1922, 1995. 2
- <span id="page-27-10"></span>[41] Weimin Wang and Li Hong. Positive solutions of some semilinear elliptic equations in  $\mathbb{R}^n_+$  with Neumann boundary conditions. *Nonlinear Analysis: Theory, Methods & Applications*,

66(4):936–949, 2007. [2](#page-1-3)

- <span id="page-28-3"></span>[42] Ruofei Yao. Symmetry of positive solutions of elliptic equations in a planar sub-spherical sector with large aparture. *Preprint*, 2023. [9,](#page-8-4) [10,](#page-9-6) [21](#page-20-4)
- <span id="page-28-1"></span>[43] Ruofei Yao, Hongbin Chen, and Changfeng Gui. Symmetry of positive solutions of elliptic equations with mixed boundary conditions in a super-spherical sector. *Calc. Var. Partial Differential Equations*, 60(4):Art. 130, 2021. [2,](#page-1-3) [4,](#page-3-4) [8,](#page-7-2) [13](#page-12-4)
- <span id="page-28-2"></span>[44] Ruofei Yao, Hongbin Chen, and Yi Li. Symmetry and monotonicity of positive solutions of elliptic equations with mixed boundary conditions in a super-spherical cone. *Calc. Var. Partial Differential Equations*, 57(6):154, 2018. [2,](#page-1-3) [4](#page-3-4)
- <span id="page-28-0"></span>[45] Meijun Zhu. Symmetry properties for positive solutions to some elliptic equations in sector domains with large amplitude. *J. Math. Anal. Appl.*, 261(2):733–740, 2001. [2](#page-1-3)

COLLEGE OF BIG DATA AND INTERNET, SHENZHEN TECHNOLOGY UNIVERSITY, SHENZHEN, 518118, P.R. CHINA

*Email address*: lirui@sztu.edu.cn

SCHOOL OF MATHEMATICS, SOUTH CHINA UNIVERSITY OF TECHNOLOGY, GUANGZHOU, 510641, P.R. CHINA

*Email address*: yaoruofei@scut.edu.cn