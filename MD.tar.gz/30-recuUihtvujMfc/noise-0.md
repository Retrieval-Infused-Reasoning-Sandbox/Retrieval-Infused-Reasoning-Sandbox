# ON THE FIRST EIGENVALUE AND EIGENFUNCTION OF THE LAPLACIAN WITH MIXED BOUNDARY CONDITIONS

### NAUSICA ALDEGHI AND JONATHAN ROHLEDER

Abstract. We consider the eigenvalue problem for the Laplacian with mixed Dirichlet and Neumann boundary conditions. For a certain class of bounded, simply connected planar domains we prove monotonicity properties of the first eigenfunction. As a consequence, we establish a variant of the hot spots conjecture for mixed boundary conditions. Moreover, we obtain an inequality between the lowest eigenvalue of this mixed problem and the lowest eigenvalue of the corresponding dual problem where the Dirichlet and Neumann boundary conditions are interchanged. The proofs are based on a novel variational principle, which we establish.

## 1. Introduction

Eigenvalue problems for the Laplacian with mixed boundary conditions have been studied frequently in the last few years from various points of view [\[2,](#page-22-0) [11,](#page-22-1) [14,](#page-22-2) [15,](#page-22-3) [34\]](#page-23-0). They also serve as tools in the investigation of other related topics such as nodal properties of eigenfunctions or the famous hot spots problem [\[10,](#page-22-4) [20\]](#page-22-5).

In this article we are concerned with the lowest eigenvalue and the corresponding eigenfunction of the negative Laplacian with mixed Dirichlet–Neumann boundary conditions. For a bounded planar Lipschitz domain Ω, consider the eigenvalue problem

<span id="page-0-0"></span>
$$\begin{cases}
-\Delta \psi = \lambda \psi & \text{in } \Omega, \\
\nu \cdot \nabla \psi = 0 & \text{on } \Gamma, \\
\psi = 0 & \text{on } \Gamma^c;
\end{cases}$$
(1.1)

here ν is the exterior unit normal vector field on the boundary, defined almost everywhere, and Γ, Γ <sup>c</sup> are relatively open, disjoint subsets of the boundary ∂Ω such that Γ ∪ Γ<sup>c</sup> = ∂Ω. The problem [\(1.1\)](#page-0-0) has a discrete sequence of non-negative eigenvalues unbounded from above; see Section [2](#page-3-0) for more details. Its lowest eigenvalue is positive as soon as Γ<sup>c</sup> is non-empty, which we assume henceforth. The corresponding eigenfunction ψ<sup>1</sup> is unique up to multiplication by a scalar and can be chosen positive in Ω.

The first purpose of this article is connected to a question raised by Ba˜nuelos, Pang and Pascu [\[8\]](#page-22-6), see also [\[7\]](#page-22-7): What conditions must be imposed on Γ and Γ c to ensure that the ground state eigenfunction ψ<sup>1</sup> attains its maximum only on the boundary? This question is inspired by the hot spots conjecture about the minima and maxima of the first non-constant eigenfunction of the Laplacian with Neumann boundary conditions [\[4,](#page-22-8) [6,](#page-22-9) [19,](#page-22-10) [20\]](#page-22-5) and is closely related to the long time behavior of solutions to the corresponding heat equation. Intuitively, one should expect the hot spots property for mixed boundary conditions to be true if the Dirichlet part is "not too large" in an appropriate sense taking into account the geometry of ∂Ω. In [\[8,](#page-22-6) Corollary 1.2] it was shown that ψ<sup>1</sup> takes its maximum exclusively on ∂Ω, i.e.

1

Key words and phrases. Laplacian, mixed boundary conditions, eigenvalue inequalities, eigenfunctions, hot spots, variational principles.

on  $\Gamma$ , if  $\Omega$  is convex,  $\Gamma$  or  $\Gamma^c$  is an arc of a circle, and the angles at which  $\Gamma$  and  $\Gamma^c$  meet are less than  $\pi/2$ ; this extended an earlier result [7] in which  $\Gamma$  was assumed to be a line segment, see also [6, Theorem 4.3] and [28]. Very recently this question has attracted more attention: in the preprint [18] Hatcher shows that the hot spots property for the problem (1.1) is satisfied if  $\Omega$  is a triangle and  $\Gamma$  consists of either one or two sides of it, see also [24], where more general semilinear problems are studied; moreover, Hatcher proves a result for certain domains for which  $\Gamma$  is a line segment.

One of the main results of the present article is the following, where we denote by  $Q_1, \ldots, Q_4$  the first to fourth open quadrants in the plane and by  $e_1 = (1,0)^{\top}$  and  $e_2 = (0,1)^{\top}$  the standard basis vectors.

<span id="page-1-1"></span>**Theorem 1.1.** Assume that  $\Omega$  is a bounded, simply connected Lipschitz domain with piecewise smooth boundary, that  $\Gamma$  is connected, and that the unit normal field  $\nu$  satisfies  $\nu(x) \in \overline{Q_3}$  for almost all  $x \in \Gamma^c$  and  $\nu(x) \in \overline{Q_2} \cup \overline{Q_4}$  for almost all  $x \in \Gamma$ , see Figure 1.1. Furthermore, assume that the interior angles of  $\partial \Omega$  at which  $\Gamma$  and  $\Gamma^c$  meet are strictly less than  $\pi/2$  and that  $\partial \Omega$  has no inward-pointing corners. Then  $\psi_1$  is strictly increasing in  $\Omega$  in the directions of both  $e_1$  and  $e_2$ . In particular,  $\psi_1$  takes its maximum only on  $\Gamma$ .

We point out that the assumptions of Theorem 1.1 have the following implication: if there exist points  $x_1, x_2 \in \Gamma$  with  $\nu(x_1) \in Q_2$  and  $\nu(x_2) \in Q_4$ , then  $\Gamma$  contains at least one corner, a point at which the normal vector jumps between  $Q_2$  and  $Q_4$ . If, in addition,  $\Gamma$  does not contain any axio-parallel piece, then this point is unique and it follows from Theorem 1.1 that this is the unique point in  $\Omega$  at which  $\psi_1$  takes its maximum; see Figure 1.1. This is for instance the case if  $\Omega$  is an acute triangle where  $\Gamma$  consists of two sides and  $\Gamma^c$  is the third. However, in general, under the assumptions of Theorem 1.1 it is also possible that  $\Gamma$  contains a horizontal piece, in which case we cannot conclude uniqueness of the maximum point.

![](_page_1_Picture_6.jpeg)

FIGURE 1.1. Two domains for which Theorem 1.1 holds, rotated as required. The quadrants into which the exterior normal points are indicated. On the domain on the left,  $\psi_1$  takes its unique maximum at P.

<span id="page-1-0"></span>It is worth mentioning that the conditions in Theorem 1.1 on the directions of the exterior normal vectors of  $\Gamma$  and  $\Gamma^c$  are natural and essentially necessary for  $\psi_1$  to be strictly increasing in the directions of both  $e_1$  and  $e_2$ . In fact, a transition between neighboring quadrants within  $\Gamma$  would force one of  $\partial_1\psi_1$  and  $\partial_2\psi_1$  to change sign, due to the Neumann boundary condition; hence all the normals of  $\Gamma$  must belong to two opposite quadrants. A similar reasoning applies to  $\Gamma^c$  and its Dirichlet boundary condition, as the latter implies that the derivative of  $\psi_1$  in tangential direction along  $\Gamma^c$  vanishes. Moreover, the additional assumption that all normals of  $\Gamma$  point into (the closure of)  $Q_3$ , instead of the union of  $Q_1$  and  $Q_3$ ,

is suggested by the example of a rectangle with Dirichlet boundary conditions on two opposite sides and Neumann conditions on the remaining ones, where the first eigenfunction fails to be monotonic in both coordinate directions.

The second purpose of the present article is to prove an inequality for the first eigenvalue of the mixed problem. Associated with the eigenvalue problem (1.1) we consider the dual problem

$$\begin{cases}
-\Delta \varphi = \lambda \varphi & \text{in } \Omega, \\
\varphi = 0 & \text{on } \Gamma, \\
\nu \cdot \nabla \varphi = 0 & \text{on } \Gamma^c,
\end{cases}$$
(1.2)

where the Dirichlet and Neumann boundary conditions have been interchanged. One can ask which of the problems (1.1) and (1.2) possesses the lower ground state eigenvalue. Simultaneously with Theorem 1.1 we prove the following result.

<span id="page-2-1"></span>**Theorem 1.2.** Let the assumptions of Theorem 1.1 be satisfied. Moreover, denote by  $\lambda_1^{\Gamma}$  the lowest eigenvalue of the problem (1.2) and by  $\lambda_1^{\Gamma^c}$  the lowest eigenvalue of (1.1). Then

<span id="page-2-0"></span>
$$\lambda_1^{\Gamma^c} < \lambda_1^{\Gamma}$$

holds.

This result extends and complements our result [3, Theorem 3.1], where certain convex domains and straight  $\Gamma^c$  were considered, see also [1] for some results in higher dimensions. It is also related to recent results for triangles and other domains in [31, 35]. We point out that under the assumptions of Theorem 1.2 the length of  $\Gamma^c$  is less than the length of  $\Gamma$ .

The methods we are using to prove both Theorems 1.1 and 1.2 are variational, yet non-standard. Instead of relying on the classical variational principle for the eigenvalues of the mixed Laplacian, we establish a novel variational principle, where the minimizers are gradients of eigenfunctions. A similar approach was used by the second author to approach the classical hot spots conjecture on the second Neumann Laplacian eigenfunction for a class of domains [32] and extended to higher dimensions in [22]. A special case of what we prove here is the following theorem; cf. Theorems 3.9 and 3.13 below, where the results are stated precisely.

<span id="page-2-4"></span>**Theorem 1.3.** Assume that  $\Omega$  is a bounded, simply connected Lipschitz domain and that  $\Gamma$  is connected. Let  $\eta_1 = \min\{\lambda_1^{\Gamma}, \lambda_1^{\Gamma^c}\}$ . Then

<span id="page-2-3"></span><span id="page-2-2"></span>
$$\eta_{1} = \min_{\substack{u = \binom{u_{1}}{u_{2}} \in \mathcal{H}_{\Gamma} \\ u \neq 0}} \frac{\int_{\Omega} |\operatorname{div} u|^{2} + |\omega(u)|^{2}}{\int_{\Omega} |u|^{2}}, \tag{1.3}$$

where  $\omega(u) = \partial_1 u_2 - \partial_2 u_1$  and  $\mathcal{H}_{\Gamma}$  consists of all sufficiently regular vector fields  $u = (u_1, u_2)^{\top}$  such that  $u \cdot \nu = 0$  on  $\Gamma$  and  $u \cdot \tau = 0$  on  $\Gamma^c$ , where  $\tau$  denotes the unit tangent vector along the boundary.

If, in addition,  $\Omega$  has piecewise smooth boundary without inward-pointing corners and the interior angles of  $\partial\Omega$  at which  $\Gamma$  and  $\Gamma^c$  meet are less than  $\pi/2$ , then

$$\eta_1 = \min_{\substack{u = \binom{u_1}{u_2} \in \mathcal{H}_{\Gamma} \\ u \neq 0}} \frac{\int_{\Omega} \left( |\nabla u_1|^2 + |\nabla u_2|^2 \right) - \int_{\partial \Omega} \kappa |u|^2}{\int_{\Omega} |u|^2}, \tag{1.4}$$

where  $\kappa$  denotes the signed curvature of  $\partial\Omega$ , with the sign chosen such that  $\kappa \leq 0$  if  $\Omega$  is convex.

In both variational principles, the minimizers can be expressed in terms of gradients of eigenfunctions of the problems (1.1) and (1.2) corresponding to their lowest eigenvalues.

For the understanding of the curvature term, it should be mentioned that the vector fields in  $\mathcal{H}_{\Gamma}$  vanish at all corners of  $\partial\Omega$ , in an appropriate weak sense, due to their boundary conditions. Hence the distributional nature of the curvature at corner points need not be taken into account. The first variational principle (1.3) applies to quite general situations, as it in particular does not require that the transition between  $\Gamma$  and  $\Gamma^c$  happens at corners. The second variational problem (1.4) naturally requires more regularity of u, which is ensured by the additional assumptions on  $\partial\Omega$ . It will turn out that under the assumptions of Theorem 1.1 one has  $\eta_1 = \lambda_1^{\Gamma^c}$  and the corresponding minimizer u of (1.3) respectively (1.4) equals  $\nabla\psi_1$ , the gradient of the first eigenfunction of (1.1).

This article is organized as follows. In Section 2 some necessary preliminaries are provided. Section 3 is devoted to the proof of the variational principles of Theorem 1.3. Finally, in Section 4 these principles are applied to monotonicity properties of eigenfunctions and eigenvalue inequalities, that is, Theorems 1.1 and 1.2 are proven.

#### 2. Preliminaries

<span id="page-3-0"></span>In this section we fix some notation and provide some preliminary material.

2.1. Function spaces. Let  $\Omega \subset \mathbb{R}^2$  be a bounded, connected Lipschitz domain, see, e.g. [26, Chapter 3]. By Rademacher's theorem, for almost all  $x \in \partial \Omega$  there exists a uniquely defined exterior unit normal vector  $\nu(x) = (\nu_1(x), \nu_2(x))^{\top}$  and a unit tangent vector  $\tau(x) = (\tau_1(x), \tau_2(x))^{\top} = (-\nu_2(x), \nu_1(x))^{\top}$  in the direction of positive orientation of the boundary. We denote by  $H^s(\Omega)$ , s > 0, the  $L^2$ -based Sobolev space of order s on  $\Omega$ . On the boundary we will make use of the Sobolev space  $H^{1/2}(\partial\Omega)$  and its dual space  $H^{-1/2}(\partial\Omega)$ . Recall that there exists a unique bounded, everywhere defined, surjective trace map from  $H^1(\Omega)$  onto  $H^{1/2}(\partial\Omega)$  which continuously extends the mapping

$$C^{\infty}(\overline{\Omega}) \ni \varphi \mapsto \varphi|_{\partial\Omega};$$

we write  $\varphi|_{\partial\Omega}$  for the trace of  $\varphi \in H^1(\Omega)$  on  $\partial\Omega$ . Moreover, we denote by  $(\cdot,\cdot)_{\partial\Omega}$  the sesquilinear duality between  $H^{-1/2}(\partial\Omega)$  and  $H^{1/2}(\partial\Omega)$ ; in particular,

$$(\varphi, \psi)_{\partial\Omega} = \int_{\partial\Omega} \varphi \, \overline{\psi}, \quad \psi \in H^{1/2}(\partial\Omega),$$

if  $\varphi \in L^2(\partial \Omega) \subset H^{-1/2}(\partial \Omega)$ .

Let us next come to spaces of vector fields. As usual, we denote by  $L^2(\Omega; \mathbb{C}^2)$  the space of square-integrable complex two-component vector fields on  $\Omega$ . For  $u = (u_1, u_2)^{\top} \in L^2(\Omega; \mathbb{C}^2)$  we define its divergence div u and vorticity (or scalar curl)  $\omega(u)$ , respectively, by

$$\operatorname{div} u := \partial_1 u_1 + \partial_2 u_2$$
 and  $\omega(u) := \partial_1 u_2 - \partial_2 u_1$ ,

where the derivatives are taken in the sense of distributions. In order to define the normal trace of a vector field in a weak sense, we consider the space

$$H(\operatorname{div};\Omega) := \left\{ u \in L^2(\Omega; \mathbb{C}^2) : \operatorname{div} u \in L^2(\Omega) \right\}$$

of square-integrable vector fields with square-integrable divergence. It is a Hilbert space when equipped with its natural norm defined by

$$||u||_{H(\operatorname{div};\Omega)}^2 = \int_{\Omega} (|u_1|^2 + |u_2|^2 + |\operatorname{div} u|^2), \quad u \in H(\operatorname{div};\Omega).$$

The mapping

$$C^{\infty}(\overline{\Omega}; \mathbb{C}^2) \ni u \mapsto u|_{\partial\Omega} \cdot \nu$$

where  $\cdot$  denotes the standard inner product in  $\mathbb{C}^2$ , extends continuously to a bounded linear operator from  $H(\operatorname{div};\Omega)$  into  $H^{-1/2}(\partial\Omega)$ ; see [16, Chapter I, Theorem 2.5]. We write  $u|_{\partial\Omega} \cdot \nu$  for the image of  $u \in H(\operatorname{div};\Omega)$  under this mapping and call it the *normal trace* of u. In particular, the integration by parts formula

<span id="page-4-1"></span>
$$\int_{\Omega} u \cdot \nabla \varphi + \int_{\Omega} \operatorname{div} u \, \overline{\varphi} = \left( u|_{\partial \Omega} \cdot \nu, \varphi \right)_{\partial \Omega} \tag{2.1}$$

holds for all  $\varphi \in H^1(\Omega)$  and  $u \in H(\text{div}; \Omega)$ . Analogously, once we equip the space

$$H(\omega;\Omega) := \left\{ u \in L^2(\Omega;\mathbb{C}^2) : \omega(u) \in L^2(\Omega) \right\}$$

with the norm

$$||u||_{H(\omega;\Omega)}^2 = \int_{\Omega} (|u_1|^2 + |u_2|^2 + |\omega(u)|^2), \quad u \in H(\omega;\Omega),$$

the mapping

<span id="page-4-0"></span>
$$C^{\infty}(\overline{\Omega}; \mathbb{C}^2) \ni u \mapsto u|_{\partial\Omega} \cdot \tau$$

extends continuously to a bounded linear operator from  $H(\omega;\Omega)$  into  $H^{-1/2}(\partial\Omega)$ ; we write  $u|_{\partial\Omega} \cdot \tau$  for the image of  $u \in H(\omega;\Omega)$  under this mapping, and call it the tangential trace of u. If we define  $u^{\perp} := (-u_2, u_1)^{\top}$  and  $\nabla^{\perp}\varphi := (\nabla\varphi)^{\perp}$ , then

$$\int_{\Omega} u \cdot \nabla^{\perp} \varphi + \int_{\Omega} \omega(u) \, \overline{\varphi} = -\left(u^{\perp}|_{\partial\Omega} \cdot \nu, \varphi|_{\partial\Omega}\right)_{\partial\Omega} = \left(u|_{\partial\Omega} \cdot \tau, \varphi|_{\partial\Omega}\right)_{\partial\Omega} \tag{2.2}$$

holds for all  $\varphi \in H^1(\Omega)$  and  $u \in H(\omega; \Omega)$ . The identity (2.2) can be deduced from (2.1) by noting that  $\omega(u) = -\operatorname{div} u^{\perp}$  and  $\nu^{\perp} = \tau$ .

It is well known that the space  $L^2(\Omega; \mathbb{C}^2)$  enjoys an orthogonal decomposition into the space  $\nabla H^1(\Omega)$  and the space of divergence-free vector fields u with  $u|_{\partial\Omega} \cdot \nu = 0$ . In this paper we will use a variant of this decomposition which is tailor-made for the treatment of mixed boundary conditions. To this purpose, for any non-empty, relatively open set  $\Sigma \subset \partial\Omega$  we denote by  $H^1_{0,\Sigma}(\Omega)$  the Sobolev space

$$H_{0,\Sigma}^1(\Omega) = \{ \varphi \in H^1(\Omega) : \varphi|_{\Sigma} = 0 \},$$

where  $\varphi|_{\Sigma}$  denotes the restriction of the trace  $\varphi|_{\partial\Omega}$  to  $\Sigma$ . We say that a distribution  $\psi \in H^{-1/2}(\partial\Omega)$  vanishes on  $\Sigma$ , and write  $\psi|_{\Sigma} = 0$ , if

<span id="page-4-2"></span>
$$(\psi, \varphi|_{\partial\Omega})_{\partial\Omega} = 0$$

holds for all  $\varphi \in H^1_{0,\partial\Omega\setminus\overline{\Sigma}}(\Omega)$ . In this sense we write  $u|_{\Sigma} \cdot \nu := (u|_{\partial\Omega} \cdot \nu)|_{\Sigma}$  for  $u \in H(\operatorname{div};\Omega)$  and define analogously  $u|_{\Sigma} \cdot \tau$  for  $u \in H(\omega;\Omega)$ .

From now on let us fix two relatively open, non-empty sets  $\Gamma, \Gamma^c \subset \partial\Omega$  such that

$$\Gamma \cap \Gamma^c = \emptyset$$
 and  $\overline{\Gamma \cup \Gamma^c} = \partial \Omega$ . (2.3)

We define the space

$$H_c := \{ u \in L^2(\Omega; \mathbb{C}^2) : \text{div } u = \omega(u) = 0, u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \} ;$$

note that it depends on  $\Gamma$ . Then  $H_c$  is a closed subspace of  $L^2(\Omega; \mathbb{C}^2)$  and the orthogonal decomposition

<span id="page-4-3"></span>
$$L^{2}(\Omega; \mathbb{C}^{2}) = \nabla H^{1}_{0,\Gamma^{c}}(\Omega) \oplus \nabla^{\perp} H^{1}_{0,\Gamma}(\Omega) \oplus H_{c}$$
 (2.4)

holds. It is a variant of the classical Helmholtz decomposition and can, e.g., be deduced from [9, Theorem 5.2] in the language of differential forms; for the convenience of the reader, we provide an elementary proof for our setting in Appendix A.

2.2. The Laplacian with mixed boundary conditions. Here we briefly recall the definition of the Laplacian with mixed boundary conditions. We assume again that  $\Omega \subset \mathbb{R}^2$  is a bounded, connected Lipschitz domain and that  $\Gamma$  and  $\Gamma^c$  are non-empty, relatively open subsets of its boundary satisfying (2.3). For each  $\psi \in H^1(\Omega)$  such that  $\Delta \psi \in L^2(\Omega)$  distributionally, the gradient vector field  $u := \nabla \psi$  belongs to  $H(\operatorname{div};\Omega) \cap H(\omega;\Omega)$  as  $\operatorname{div} u = \Delta \psi \in L^2(\Omega)$  and  $\omega(u) = 0$ . In particular, the normal derivative and tangential derivative

$$\partial_{\nu}\psi|_{\partial\Omega} := \nabla\psi|_{\partial\Omega} \cdot \nu \quad \text{and} \quad \partial_{\tau}\psi|_{\partial\Omega} := \nabla\psi|_{\partial\Omega} \cdot \tau$$

of  $\psi$  are well-defined in  $H^{-1/2}(\partial\Omega)$  according to the previous section. If  $\psi$  is more regular, say  $\psi \in H^2(\Omega)$ , then the normal and tangential derivatives can alternatively be defined via the ordinary trace map. Hence we can define the negative Laplacian  $-\Delta_{\Gamma}$  subject to a Dirichlet boundary condition on  $\Gamma$  and a Neumann boundary condition on  $\Gamma^c$  as

$$-\Delta_{\Gamma}\psi = -\Delta\psi, \quad \text{dom } (-\Delta_{\Gamma}) = \left\{ \psi \in H^1_{0,\Gamma}(\Omega) : \Delta\psi \in L^2(\Omega), \partial_{\nu}\psi|_{\Gamma^c} = 0 \right\}.$$

The operator  $-\Delta_{\Gamma}$  corresponds to the non-negative, closed quadratic form

$$H^1_{0,\Gamma}(\Omega) \ni \psi \mapsto \int_{\Omega} |\nabla \psi|^2$$

in the sense of [21, Chapter VI, Theorem 2.1]; cf. Proposition 2.3 below. It is self-adjoint in  $L^2(\Omega)$  and its spectrum consists of a discrete sequence of positive eigenvalues with finite multiplicities converging to  $+\infty$ . We point out that the operator  $-\Delta_{\Gamma^c}$  with the dual boundary conditions, i.e. Dirichlet on  $\Gamma^c$  and Neumann on  $\Gamma$ , is defined analogously.

Next we state a little lemma which in particular applies to functions in the domain of  $-\Delta_{\Gamma}$ . Intuitively, for a function being constant on a set  $\Sigma \subset \partial \Omega$ , its tangential derivative must vanish on  $\Sigma$ . We give a short proof to make sure that this statement is true for the weakly defined tangential derivative and does not require any additional regularity of  $\partial \Omega$ .

<span id="page-5-0"></span>**Lemma 2.1.** Assume that  $\Sigma \subset \partial \Omega$  is relatively open and non-empty. Let  $\varphi \in H^1_{0,\Sigma}(\Omega)$  such that  $\Delta \varphi \in L^2(\Omega)$ . Then

$$\partial_{\tau}\varphi|_{\Sigma}=0$$

holds.

*Proof.* By the assumptions on  $\varphi$  we have  $\nabla^{\perp}\varphi \in L^2(\Omega; \mathbb{C}^2)$  and  $\operatorname{div} \nabla^{\perp}\varphi = 0$ . Thus,  $\nabla^{\perp}\varphi \in H(\operatorname{div};\Omega)$ . Since  $\varphi \in H^1_{0,\Sigma}(\Omega)$ , there exists a sequence  $(\varphi_n)_n \subset C^{\infty}(\overline{\Omega}) \cap H^1_{0,\Sigma}(\Omega)$  such that  $\varphi_n \to \varphi$  in  $H^1(\Omega)$ , see, e.g., [12, Theorem 1]. Then  $\nabla^{\perp}\varphi_n \to \nabla^{\perp}\varphi$  in  $H(\operatorname{div};\Omega)$  due to  $\operatorname{div} \nabla^{\perp}\varphi_n = 0$  for all n and  $\operatorname{div} \nabla^{\perp}\varphi = 0$ . In particular,

$$\partial_{\tau}\varphi|_{\Sigma} = -\nabla^{\perp}\varphi|_{\Sigma} \cdot \nu = -\lim_{n \to \infty} \nabla^{\perp}\varphi_{n}|_{\Sigma} \cdot \nu = 0,$$

proving the lemma.

Finally, let us emphasize that in general dom  $(-\Delta_{\Gamma})$  is not contained in  $H^2(\Omega)$ . However, such regularity holds under assumptions on the angles at the corners at which the transition between Dirichlet and Neumann boundary conditions takes place.

<span id="page-5-1"></span>**Proposition 2.2.** If  $\partial\Omega$  is piecewise smooth, contains no inward-pointing corners, and the interior angles at all points at which  $\Gamma$  and  $\Gamma^c$  meet are less or equal  $\pi/2$ , then

dom 
$$(-\Delta_{\Gamma}) \subset H^2(\Omega)$$

holds.

This regularity result for mixed boundary conditions is rather well known. For the case of a polygon the statement follows from [17, Theorem 2.3.7] (see also the discussion below the theorem there). In the more general case,  $H^2$ -regularity of the functions in dom  $(-\Delta_{\Gamma})$  away from the corners where the transition between Dirichlet and Neumann condition takes place is a standard result, see e.g. the survey [23]. The corners at which  $\Gamma$  and  $\Gamma^c$  meet can be locally mapped conformally into a sector of the same angle and the result carries over from the polygonal case, see [5] or [36, Section 5].

Note that the assumptions of the previous proposition imply that the change between Neumann and Dirichlet boundary conditions happens at corners only, not in the interior of a smooth arc. This is not required in the definition of  $-\Delta_{\Gamma}$  above.

2.3. Sesquilinear forms and self-adjoint operators. In this section we review briefly the theory of closed non-negative sesquilinear forms in Hilbert spaces and associated non-negative self-adjoint operators as to be found for instance in [21, Chapter VI] or [30, Section X.3].

Let  $\mathcal{H}$  be a separable Hilbert space with inner product  $(\cdot,\cdot)$  and corresponding norm  $\|\cdot\|$ , and let  $\mathfrak{a}$  be a sesquilinear form in  $\mathcal{H}$  with domain dom  $\mathfrak{a}$ , that is, dom  $\mathfrak{a}$  is a linear subspace of  $\mathcal{H}$  and  $\mathfrak{a}$ : dom  $\mathfrak{a} \times \operatorname{dom} \mathfrak{a} \to \mathbb{C}$  is linear in the first entry and anti-linear in the second. A sesquilinear form  $\mathfrak{a}$  is said to be *symmetric* if the corresponding quadratic form  $\mathfrak{a}[u] \coloneqq \mathfrak{a}[u,u]$  is real for all  $u \in \operatorname{dom} \mathfrak{a}$ , and non-negative if  $\mathfrak{a}[u] \geq 0$  for all  $u \in \operatorname{dom} \mathfrak{a}$ . In this case,

$$(u,v)_{\mathfrak{a}} := \mathfrak{a}[u,v] + (u,v)$$

defines an inner product on dom  $\mathfrak{a}$ , and  $\mathfrak{a}$  is said to be *closed* if dom  $\mathfrak{a}$  equipped with  $(\cdot, \cdot)_{\mathfrak{a}}$  and the associated norm  $\|\cdot\|_{\mathfrak{a}}$  is a Hilbert space. The following correspondence between sesquilinear forms and self-adjoint operators is well known.

<span id="page-6-0"></span>**Proposition 2.3.** Assume that  $\mathfrak{a}$  is a symmetric, non-negative, closed sesquilinear form whose domain dom  $\mathfrak{a}$  is dense in  $\mathcal{H}$ . Then the following assertions hold.

(i) There exists a unique self-adjoint, non-negative operator A in  $\mathcal{H}$  with dom  $A \subset \text{dom } \mathfrak{a}$  such that

$$(Au, v) = \mathfrak{a}[u, v], \quad u \in \text{dom } A, v \in \text{dom } \mathfrak{a}.$$

Moreover,  $u \in \text{dom } \mathfrak{a}$  belongs to dom A if and only if there exists  $w \in \mathcal{H}$  such that  $\mathfrak{a}[u,v]=(w,v)$  holds for all  $v \in \text{dom } \mathfrak{a}$ ; in this case, Au=w.

(ii) If, in addition, dom a is compactly embedded into H then the spectrum of A is purely discrete, i.e. it consists of isolated eigenvalues with finite multiplicities. Upon enumerating these eigenvalues non-decreasingly according to their multiplicities,

$$\eta_1 \leq \eta_2 \leq \dots,$$

the min-max principle

$$\eta_j = \min_{\substack{F \subset \text{dom } \mathfrak{a} \\ \text{dim } F = j}} \max_{u \in F \setminus \{0\}} \frac{\mathfrak{a}[u]}{\|u\|^2}$$

holds. In particular, the lowest eigenvalue  $\eta_1$  of A is given by

<span id="page-6-1"></span>
$$\eta_1 = \min_{\substack{u \in \text{dom } \mathfrak{a} \\ u \neq 0}} \frac{\mathfrak{a}[u]}{\|u\|^2},\tag{2.5}$$

and  $u \in \text{dom } \mathfrak{a}$  with  $u \neq 0$  is an eigenvector of A corresponding to  $\eta_1$  if and only if u minimizes (2.5).

Sometimes it will be useful to work on a slightly smaller space than dom  $\mathfrak{a}$ . Recall that a subspace  $\mathcal{D} \subset \text{dom } \mathfrak{a}$  is called a *core* of  $\mathfrak{a}$  if  $\mathcal{D}$  is dense in dom  $\mathfrak{a}$  with respect to  $\|\cdot\|_{\mathfrak{a}}$ , and that dom A is always a core of  $\mathfrak{a}$ .

<span id="page-7-4"></span>**Lemma 2.4.** Assume that  $\mathfrak{a}$  is a symmetric, non-negative, densely defined, closed sesquilinear form in  $\mathcal{H}$  and that A is the corresponding self-adjoint, non-negative operator of Proposition 2.3. Assume that dom  $\mathfrak{a}$  is compactly embedded into  $\mathcal{H}$  and that  $\mathcal{D} \subset \text{dom } A$  is a subspace such that  $\mathcal{D}$  contains all eigenvectors of A. Then  $\mathcal{D}$  is a core of  $\mathfrak{a}$ .

*Proof.* Let  $(v_j)_j \subset \text{dom } A$  be an orthonormal basis of  $\mathcal{H}$  such that  $Av_j = \eta_j v_j$  holds for all  $j \in \mathbb{N}$ , where  $\eta_j$  are the eigenvalues of A. Let  $u \in \text{dom } A$  and define, for each  $N \in \mathbb{N}$ ,

$$u_N := \sum_{j=1}^{N} (u, v_j) v_j \in \mathcal{D}.$$

By the spectral theorem,  $u_N$  converges to u in  $\mathcal{H}$  and

$$Au_N = \sum_{j=1}^{N} \eta_j(u, v_j) v_j$$

converges to Au in  $\mathcal{H}$ . Hence,

$$||u - u_N||_{\mathfrak{a}}^2 = ||u - u_N||^2 + (A(u - u_N), u - u_N)$$
  
$$\leq ||u - u_N||^2 + ||Au - Au_N|| ||u - u_N|| \to 0$$

П

<span id="page-7-0"></span>as  $N \to \infty$ . Since dom A is a core of  $\mathfrak{a}$ , the claim follows.

# 3. Variational principles for mixed Dirichlet–Neumann Laplacian eigenvalues

In this section we establish two variants of a variational principle for the eigenvalues of the Laplacian with mixed boundary conditions. The first variant does not require any regularity, in addition to Lipschitz, on the boundary of  $\Omega$ . The second one, which will involve the curvature of the boundary, will need some smoothness.

3.1. A div-curl variational principle for mixed boundary conditions. In this subsection we generalize [33, Section 3], where the case of Neumann and Dirichlet, instead of mixed, boundary conditions was considered. Throughout this section we impose the following assumption.

<span id="page-7-1"></span>**Hypothesis 3.1.** The set  $\Omega \subset \mathbb{R}^2$  is a bounded, connected Lipschitz domain and  $\Gamma, \Gamma^c \subset \partial \Omega$  are non-empty, relatively open subsets of the boundary such that

$$\Gamma \cap \Gamma^c = \emptyset$$
 and  $\overline{\Gamma \cup \Gamma^c} = \partial \Omega$ .

We define a sesquilinear form  $\mathfrak{a}$  in  $L^2(\Omega; \mathbb{C}^2)$  by

<span id="page-7-2"></span>
$$\mathfrak{a}[u,v] = \int_{\Omega} \left( \operatorname{div} u \, \overline{\operatorname{div} v} + \omega(u) \, \overline{\omega(v)} \right), \quad u = \begin{pmatrix} u_1 \\ u_2 \end{pmatrix}, v = \begin{pmatrix} v_1 \\ v_2 \end{pmatrix}, \tag{3.1}$$

with domain

$$\operatorname{dom} \mathfrak{a} = \{ u \in L^2(\Omega; \mathbb{C}^2) : \operatorname{div} u, \omega(u) \in L^2(\Omega), u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \}.$$
 (3.2)

Note that the normal and tangential traces are well defined in the sense of Section 2 as dom  $\mathfrak{a} \subset H(\operatorname{div};\Omega) \cap H(\omega;\Omega)$ . Since

<span id="page-7-3"></span>
$$\mathfrak{a}[u] = \int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right) \ge 0,$$

one sees immediately that  $\mathfrak a$  is symmetric and non-negative, so that

$$(u,v)_{\mathfrak{a}} := \mathfrak{a}[u,v] + \int_{\Omega} u \cdot v$$

defines an inner product on the space  $\mathcal{H}_{\Gamma} := \text{dom } \mathfrak{a}$ .

The following proposition ensures that the form  $\mathfrak{a}$  induces a self-adjoint operator A in  $L^2(\Omega; \mathbb{C}^2)$ .

<span id="page-8-0"></span>**Proposition 3.2.** Let Hypothesis 3.1 be satisfied. Then the sesquilinear form  $\mathfrak{a}$  is closed, and dom  $\mathfrak{a}$  is dense in  $L^2(\Omega; \mathbb{C}^2)$ . In particular, there exists a self-adjoint operator A in  $L^2(\Omega; \mathbb{C}^2)$  such that

$$\int_{\Omega} Au \cdot v = \mathfrak{a}[u, v], \quad u \in \text{dom } A, v \in \text{dom } \mathfrak{a}.$$

A vector field  $u \in \text{dom } \mathfrak{a}$  belongs to dom A if and only if there exists  $w \in L^2(\Omega; \mathbb{C}^2)$  such that

$$\mathfrak{a}[u,v] = \int_{\Omega} w \cdot v$$

holds for all  $v \in \text{dom } \mathfrak{a}$ , and in this case, Au = w. Moreover, the spectrum of A is bounded below by 0.

*Proof.* If we prove the mentioned properties of  $\mathfrak{a}$ , the statements about the operator A follow from Proposition 2.3. First, dom  $\mathfrak{a}$  is dense in  $L^2(\Omega; \mathbb{C}^2)$  as  $C_0^{\infty}(\Omega; \mathbb{C}^2) \subset$  dom  $\mathfrak{a}$  and  $C_0^{\infty}(\Omega; \mathbb{C}^2)$  is dense in  $L^2(\Omega; \mathbb{C}^2)$ . To see that  $\mathfrak{a}$  is closed, we need to show that the space  $\mathcal{H}_{\Gamma}$  is complete. For this let  $(u^n)_n$  be a Cauchy sequence in  $\mathcal{H}_{\Gamma}$ , that is,

$$\int_{\Omega} \left( |\operatorname{div} u^{n} - \operatorname{div} u^{m}|^{2} + |\omega(u^{n}) - \omega(u^{m})|^{2} + |u^{n} - u^{m}|^{2} \right) \to 0$$

as  $n, m \to \infty$ . Then there exist  $f, g \in L^2(\Omega)$  and  $u \in L^2(\Omega, \mathbb{C}^2)$  such that

$$\operatorname{div} u^n \to f$$
,  $\omega(u^n) \to g$ ,  $u^n \to u$ 

in  $L^2(\Omega)$  or  $L^2(\Omega, \mathbb{C}^2)$ , respectively. For all  $\psi \in C_0^{\infty}(\Omega)$  it follows by integration by parts (2.1) that

$$\int_{\Omega} \operatorname{div} u \, \overline{\psi} = -\int_{\Omega} u \cdot \nabla \psi = -\lim_{n \to \infty} \int_{\Omega} u^n \cdot \nabla \psi = \lim_{n \to \infty} \int_{\Omega} \operatorname{div} u^n \overline{\psi} = \int_{\Omega} f \, \overline{\psi},$$

that is, div  $u = f \in L^2(\Omega)$ . Analogously, applying (2.2) we get

$$\int_{\Omega} \omega(u) \, \overline{\psi} = -\int_{\Omega} u \cdot \nabla^{\perp} \psi = -\lim_{n \to \infty} \int_{\Omega} u^n \cdot \nabla^{\perp} \psi = \lim_{n \to \infty} \int_{\Omega} \omega(u^n) \overline{\psi} = \int_{\Omega} g \, \overline{\psi}$$

for all  $\psi \in C_0^{\infty}(\Omega)$ , from which  $\omega(u) = g \in L^2(\Omega)$  follows. As for the boundary conditions, we have for all  $\psi \in H^1_{0,\Gamma^c}(\Omega)$ 

$$(u|_{\partial\Omega} \cdot \nu, \psi|_{\partial\Omega})_{\partial\Omega} = \int_{\Omega} u \cdot \nabla \psi + \int_{\Omega} \operatorname{div} u \, \overline{\psi} = \lim_{n \to \infty} \left( \int_{\Omega} u^n \cdot \nabla \psi + \int_{\Omega} \operatorname{div} u^n \overline{\psi} \right)$$
$$= \lim_{n \to \infty} (u^n|_{\partial\Omega} \cdot \nu, \psi|_{\partial\Omega})_{\partial\Omega} = 0,$$

implying that  $u|_{\Gamma} \cdot \nu = 0$ . Furthermore, for all  $\psi \in H^1_{0,\Gamma}(\Omega)$  we have

$$(u|_{\partial\Omega} \cdot \tau, \psi|_{\partial\Omega})_{\partial\Omega} = \int_{\Omega} u \cdot \nabla^{\perp} \psi + \int_{\Omega} \omega(u) \,\overline{\psi} = \lim_{n \to \infty} \left( \int_{\Omega} u^{n} \cdot \nabla^{\perp} \psi + \int_{\Omega} \omega(u^{n}) \overline{\psi} \right)$$
$$= \lim_{n \to \infty} (u^{n}|_{\partial\Omega} \cdot \tau, \psi|_{\partial\Omega})_{\partial\Omega} = 0$$

implying that  $u|_{\Gamma^c} \cdot \tau = 0$ . Therefore,  $u \in \mathcal{H}_{\Gamma}$ , and  $||u^n - u||_{\mathfrak{a}} \to 0$  as  $n \to \infty$ . Thus,  $\mathcal{H}_{\Gamma}$  is complete and, thus,  $\mathfrak{a}$  is closed.

<span id="page-9-1"></span>**Remark 3.3.** The self-adjoint operator A defined in Proposition 3.2 acts componentwise as the negative Laplacian, since for all  $v \in C_0^{\infty}(\Omega; \mathbb{C}^2)$  and  $u \in \text{dom } A$ ,

$$\int_{\Omega} Au \cdot v = \mathfrak{a}[u, v] = -\int_{\Omega} \left( \nabla \operatorname{div} u \cdot v + \nabla^{\perp} \omega(u) \cdot v \right)$$

by the integration by parts formulas (2.1) and (2.2), and  $\Delta u = \nabla \operatorname{div} u + \nabla^{\perp} \omega(u)$ .

Next, we compute the spectrum of A. Recall that  $-\Delta_{\Gamma}$  denotes the Laplacian on  $\Omega$  with a Dirichlet boundary condition on  $\Gamma$  and a Neumann boundary condition on  $\Gamma^c$ , and  $-\Delta_{\Gamma^c}$  is the operator where the two boundary conditions are interchanged. Let us enumerate the eigenvalues of  $-\Delta_{\Gamma^c}$ , counted according to their multiplicities, as

$$0 < \lambda_1^{\Gamma^c} < \lambda_2^{\Gamma^c} \leq \dots$$

and denote by  $\psi_1, \psi_2, \ldots$  an orthonormal basis of  $L^2(\Omega)$  such that

$$-\Delta_{\Gamma^c}\psi_k = \lambda_k^{\Gamma^c}\psi_k, \quad k = 1, 2, \dots$$

Analogously, let the eigenvalues of  $-\Delta_{\Gamma}$  be enumerated as

$$0 < \lambda_1^{\Gamma} < \lambda_2^{\Gamma} \leq \dots$$

and let  $\varphi_1, \varphi_2, \ldots$  be an orthonormal basis of  $L^2(\Omega)$  such that

$$-\Delta_{\Gamma}\varphi_k = \lambda_k^{\Gamma}\varphi_k, \quad k = 1, 2, \dots$$

The following proposition relates the eigenvalues of the aforementioned mixed Laplacians to the spectrum of A. For this it is useful to recall the decomposition

$$L^{2}(\Omega; \mathbb{C}^{2}) = \nabla H^{1}_{0,\Gamma^{c}}(\Omega) \oplus \nabla^{\perp} H^{1}_{0,\Gamma}(\Omega) \oplus H_{c},$$

<span id="page-9-0"></span>see (2.4) above.

**Proposition 3.4.** Assume that Hypothesis 3.1 is satisfied. Let A be the self-adjoint operator in  $L^2(\Omega; \mathbb{C}^2)$  associated with the sesquilinear form  $\mathfrak{a}$  in Proposition 3.2. Then the following hold.

- (i) For each  $k \geq 1$ ,  $\nabla \psi_k$  is non-trivial, belongs to dom A, and satisfies  $A\nabla \psi_k = \lambda_k^{\Gamma^c} \nabla \psi_k$ . Moreover, the functions  $\frac{1}{\sqrt{\lambda_k^{\Gamma^c}}} \nabla \psi_k$  form an orthonormal basis of  $\nabla H^1_{0,\Gamma^c}(\Omega)$ .
- (ii) For each  $k \geq 1$ ,  $\nabla^{\perp} \varphi_k$  is non-trivial, belongs to dom A, and satisfies  $A\nabla^{\perp}\varphi_k = \lambda_k^{\Gamma}\nabla^{\perp}\varphi_k$ . Moreover, the functions  $\frac{1}{\sqrt{\lambda_k^{\Gamma}}}\nabla^{\perp}\varphi_k$  form an orthonormal basis of  $\nabla^{\perp}H_{0,\Gamma}^1(\Omega)$ .
- (iii)  $\ker A = H_c$ .

In particular the spectrum of A coincides with the union of the eigenvalues of  $-\Delta_{\Gamma}$  and  $-\Delta_{\Gamma^c}$ , including multiplicities, and the eigenvalue 0 with multiplicity dim  $H_c$ .

*Proof.* (i) Let first  $\psi$  be any eigenfunction of  $-\Delta_{\Gamma^c}$  corresponding to an eigenvalue  $\lambda$  and consider its gradient  $\nabla \psi$ , which is non-trivial as  $\psi$  is non-constant, and belongs to  $L^2(\Omega; \mathbb{C}^2)$ . The identities

$$\operatorname{div} \nabla \psi = \Delta \psi = -\lambda \psi$$

and

$$\omega(\nabla \psi) = \partial_1 \partial_2 \psi - \partial_2 \partial_1 \psi = 0$$

both hold on  $\Omega$  in the distributional sense, so that  $\operatorname{div} \nabla \psi, \omega(\nabla \psi) \in L^2(\Omega)$ . The Neumann boundary condition to which  $\psi$  is subject on  $\Gamma$  yields

$$\nabla \psi|_{\Gamma} \cdot \nu = \partial_{\nu} \psi|_{\Gamma} = 0,$$

while the Dirichlet boundary condition on  $\Gamma^c$  yields

$$\nabla \psi|_{\Gamma^c} \cdot \tau = \partial_\tau \psi|_{\Gamma^c} = 0;$$

cf. Lemma 2.1. Thus  $\nabla \psi \in \text{dom } \mathfrak{a}$  and, furthermore, for all  $v \in \text{dom } \mathfrak{a}$  we have

$$\mathfrak{a}[\nabla \psi, v] = \int_{\Omega} \Delta \psi \, \overline{\operatorname{div} v} = -\lambda \int_{\Omega} \psi \, \overline{\operatorname{div} v} = \lambda \int_{\Omega} \nabla \psi \cdot v,$$

where we used  $v|_{\Gamma} \cdot \nu = 0$  and  $\psi|_{\Gamma^c} = 0$ . Proposition 3.2 then yields  $\nabla \psi \in \text{dom } A$  and  $A\nabla \psi = \lambda \nabla \psi$ . Consequently, for each k,  $\lambda_k^{\Gamma^c}$  is an eigenvalue of A with corresponding eigenfunction  $\nabla \psi_k$ .

To show the orthonormal basis property, by Green's identity, for all j, k we have

$$\int_{\Omega} \nabla \psi_j \cdot \nabla \psi_k = -\int_{\Omega} \Delta \psi_j \overline{\psi_k} + (\partial_{\nu} \psi_j|_{\partial \Omega}, \psi_k)_{\partial \Omega} = \lambda_j^{\Gamma^c} \int_{\Omega} \psi_j \overline{\psi_k},$$

where the boundary term vanishes as  $\psi_k|_{\Gamma^c} = 0$  and  $\partial_\nu \psi_j|_{\Gamma} = 0$ . The right-hand side integral equals 0 if  $k \neq j$  and  $\lambda_j^{\Gamma^c}$  if k = j as the eigenfunctions  $\psi_k$  form an orthonormal basis in  $L^2(\Omega)$ . Therefore the functions  $\frac{1}{\sqrt{\lambda_k^{\Gamma^c}}} \nabla \psi_k$  form an orthonormal system in  $\nabla H^1_{0,\Gamma^c}(\Omega)$ . To prove that this orthonormal system is an orthonormal basis, assume that  $\psi \in H^1_{0,\Gamma^c}(\Omega)$  is such that  $\nabla \psi$  is orthogonal to all the  $\nabla \psi_k$  in  $L^2(\Omega; \mathbb{C}^2)$ . Then for all k we have

$$0 = \int_{\Omega} \nabla \psi_k \cdot \nabla \psi = -\int_{\Omega} \Delta \psi_k \overline{\psi} + \left( \partial_{\nu} \psi_k |_{\partial \Omega}, \overline{\psi} \right)_{\partial \Omega} = \lambda_k^{\Gamma^c} \int_{\Omega} \psi_k \overline{\psi},$$

where the boundary term vanishes as  $\psi|_{\Gamma^c} = 0$  and  $\partial_{\nu}\psi_k|_{\Gamma} = 0$ . Hence  $\psi$  is orthogonal to all eigenfunctions  $\psi_k$  of  $-\Delta_{\Gamma^c}$ , from which  $\psi = 0$  follows, and the proof of (i) is complete.

(ii) Let now  $\varphi$  be an eigenfunction of  $-\Delta_{\Gamma}$  corresponding to an eigenvalue  $\lambda$  and consider its perpendicular gradient  $\nabla^{\perp}\varphi \in L^2(\Omega; \mathbb{C}^2)$ , which is non-trivial as  $\varphi$  is non-constant. Then

$$\operatorname{div} \nabla^{\perp} \varphi = -\partial_1 \partial_2 \varphi + \partial_2 \partial_1 \varphi = 0$$

and

$$\omega(\nabla^{\perp}\varphi) = \Delta\varphi = -\lambda\varphi$$

on  $\Omega$ , giving div  $\nabla^{\perp}\varphi$ ,  $\omega(\nabla^{\perp}\varphi) \in L^2(\Omega)$ . Since  $\varphi$  is constantly zero along  $\Gamma$  we have

$$\nabla^{\perp} \varphi|_{\Gamma} \cdot \nu = -\nabla \varphi|_{\Gamma} \cdot \tau = -\partial_{\tau} \varphi|_{\Gamma} = 0,$$

where we used  $\nu=-\tau^{\perp}$  and Lemma 2.1. On  $\Gamma^c$ ,  $\varphi$  satisfies a Neumann boundary condition and thus

$$\nabla^{\perp}\varphi|_{\Gamma^c}\cdot\tau = \nabla\varphi|_{\Gamma^c}\cdot\nu = \partial_{\nu}\varphi|_{\Gamma^c} = 0.$$

We have shown  $\nabla^{\perp}\varphi\in\mathrm{dom}\ \mathfrak{a}$ . Furthermore, for each  $v\in\mathrm{dom}\ \mathfrak{a}$  we have

$$\mathfrak{a}\left[\nabla^{\perp}\varphi,v\right] = \int_{\Omega} \Delta\varphi \,\overline{\omega(v)} = -\lambda \int_{\Omega} \varphi \,\overline{\omega(v)} = \lambda \int_{\Omega} \nabla^{\perp}\varphi \cdot v$$

where we used  $\varphi|_{\Gamma} = 0$  and  $v|_{\Gamma^c} \cdot \tau = 0$ . Again this implies that  $\nabla^{\perp} \varphi \in \text{dom } A$  and  $A \nabla^{\perp} \varphi = \lambda \nabla^{\perp} \varphi$ . Hence, for each k,  $\nabla^{\perp} \varphi_k$  is an eigenfunction of A corresponding to the eigenvalue  $\lambda_k^{\Gamma}$ . An argument entirely analogous to the one in (i) proves that the functions  $\frac{1}{\sqrt{\lambda_k^{\Gamma}}} \nabla^{\perp} \varphi_k$  form an orthonormal basis in  $\nabla^{\perp} H_{0,\Gamma}^1(\Omega)$ .

(iii) As the form  $\mathfrak{a}$  is non-negative, each  $u \in \text{dom } \mathfrak{a}$  satisfies

$$\mathfrak{a}[u] = \int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right) \ge 0,$$

with equality if and only if div  $u = \omega(u) = 0$ . Hence ker  $A = H_c$ .

For the remaining assertion on the spectrum of A, observe that in (i)–(iii) we have found a family of eigenfunctions of A which, according to the decomposition (2.4), span all of  $L^2(\Omega; \mathbb{C}^2)$ . As A is self-adjoint, this implies that we have found the entire spectrum of A and it is of the form stated in the proposition.

As a consequence of the previous proposition we get the following variational principle for the eigenvalues of the mixed Laplacians  $-\Delta_{\Gamma}$  and  $-\Delta_{\Gamma^c}$ . Recall that the space  $\mathcal{H}_{\Gamma}$  is given by

$$\mathcal{H}_{\Gamma} = \{ u \in L^2(\Omega; \mathbb{C}^2) : \operatorname{div} u, \omega(u) \in L^2(\Omega), u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \}.$$

<span id="page-11-3"></span>**Theorem 3.5.** Assume that Hypothesis 3.1 is satisfied. Denote by

<span id="page-11-0"></span>
$$\eta_1 \leq \eta_2 \leq \dots$$

the positive eigenvalues of A, i.e. the union of the eigenvalues of  $-\Delta_{\Gamma}$  and  $-\Delta_{\Gamma^c}$ , counted according to their multiplicities; see Proposition 3.4. Then

$$\eta_j = \min_{\substack{U \subset \mathcal{H}_{\Gamma} \\ U \perp H_c \\ \text{dim} U = i}} \max_{\substack{u \in U \\ u \neq 0}} \frac{\int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right)}{\int_{\Omega} |u|^2}.$$

In particular, the first positive eigenvalue  $\eta_1$  of A is given by

$$\eta_1 = \min_{\substack{u \in \mathcal{H}_{\Gamma} \\ u \perp H_{C} \\ u \neq 0}} \frac{\int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right)}{\int_{\Omega} |u|^2}.$$
(3.3)

Moreover,  $u \in \mathcal{H}_{\Gamma}$  with  $u \perp H_c$  and  $u \neq 0$  is a minimizer of (3.3) if and only if  $u = \nabla \psi + \nabla^{\perp} \varphi$  for some  $\psi \in \ker(-\Delta_{\Gamma^c} - \eta_1)$  and  $\varphi \in \ker(-\Delta_{\Gamma} - \eta_1)$ .

*Proof.* By Proposition 3.4, the positive eigenvalues  $\eta_j$  of A are precisely the eigenvalues of the operators  $-\Delta_{\Gamma^c}$  and  $-\Delta_{\Gamma}$ , taking into account multiplicities, and

$$\ker(A - \eta_j) = \nabla \ker(-\Delta_{\Gamma^c} - \eta_j) \oplus \nabla^{\perp} \ker(-\Delta_{\Gamma} - \eta_j)$$
(3.4)

holds for all j. Therefore all statements of the theorem follow from Proposition 2.3 (ii) and the definition of the sesquilinear form  $\mathfrak{a}$  in (3.1)–(3.2).

Next, we specify assumptions under which the kernel of A is empty and, hence, the spectrum of A consists exclusively of the union of the spectra of the two mixed Laplacians.

<span id="page-11-2"></span>**Proposition 3.6.** Assume that Hypothesis 3.1 is satisfied. If, in addition,  $\Omega$  is simply connected and  $\Gamma$  is connected, then

<span id="page-11-4"></span>
$$\ker A = \{0\}.$$

In particular,

<span id="page-11-1"></span>
$$L^{2}(\Omega; \mathbb{C}^{2}) = \nabla H^{1}_{0,\Gamma^{c}}(\Omega) \oplus \nabla^{\perp} H^{1}_{0,\Gamma}(\Omega). \tag{3.5}$$

Proof. By Proposition 3.4 (iii) we have  $\ker A = H_c$ . Let  $u \in H_c$ , i.e.  $u \in L^2(\Omega; \mathbb{C}^2)$ ,  $\operatorname{div} u = \omega(u) = 0$  in  $\Omega$ ,  $u|_{\Gamma} \cdot \nu = 0$  and  $u|_{\Gamma^c} \cdot \tau = 0$ . Since  $\Omega$  is simply connected,  $\omega(u) = 0$  implies that there exists  $f \in H^1(\Omega)$  such that  $u = \nabla f$ , see [16, Chapter I, Theorem 2.9]. As

$$\partial_{\tau} f|_{\Gamma^c} = u|_{\Gamma^c} \cdot \tau = 0$$

and  $\Gamma^c$  is connected due to the assumptions of the proposition, there exists  $c \in \mathbb{C}$  such that  $f|_{\Gamma^c} = c$  identically. However, we may replace f by f - c and therefore assume without loss of generality that  $f \in H^1_{0,\Gamma^c}(\Omega)$ . Using  $\operatorname{div} u = 0$  in  $\Omega$  and  $u|_{\Gamma} \cdot \nu = 0$  we get

$$\int_{\Omega} \lvert u \rvert^2 = \int_{\Omega} u \cdot \nabla f = - \int_{\Omega} \operatorname{div} u \, \overline{f} + (u \rvert_{\partial \Omega} \cdot \nu, f \rvert_{\partial \Omega})_{\partial \Omega} = 0.$$

Hence, u = 0 identically on  $\Omega$ , that is,  $H_c = \{0\}$ . The equality (3.5) now follows immediately from (2.4).

**Remark 3.7.** Note that under the assumptions of Proposition 3.6 the form  $\mathfrak{a}$  is even positive, not only non-negative.

We point out that, in contrast to the case of pure Neumann respectively pure Dirichlet boundary conditions considered in [33],  $\Omega$  being simply connected is not sufficient for ker A to be trivial, as the following simple example shows.

<span id="page-12-3"></span>**Example 3.8.** Consider the case  $\Omega = (0,1) \times (0,1)$  and choose  $\Gamma$  to be the union of the two opposite vertical sides,

$$\Gamma = \{(0, y) : y \in (0, 1)\} \cup \{(1, y) : y \in (0, 1)\},\$$

and  $\Gamma^c$  to be the union of the two horizontal sides; in particular, neither  $\Gamma$  nor  $\Gamma^c$  is connected. Then both the normal vector on  $\Gamma$  and the tangent vector on  $\Gamma^c$  are constantly equal to  $\pm (1,0)^{\top}$  on each connected component of the respective part of  $\partial\Omega$ . In particular, the constant vector field  $u=(0,1)^{\top}$  satisfies  $u|_{\Gamma}\cdot \nu=0$  and  $u|_{\Gamma^c}\cdot \tau=0$ , as well as div  $u=\omega(u)=0$  in  $\Omega$ . Hence we have found a nontrivial element  $u\in H_c$ . The question of the dimension of  $H_c$  is studied further in Proposition A.2 in Appendix A.

Theorem 3.5 together with Proposition 3.6 immediately yields the following.

<span id="page-12-0"></span>**Theorem 3.9.** Assume that Hypothesis 3.1 is satisfied. In addition, assume that  $\Omega$  is simply connected and that  $\Gamma$  is connected. Denote by

<span id="page-12-1"></span>
$$\eta_1 \leq \eta_2 \leq \dots$$

the eigenvalues of A, i.e. the union of the eigenvalues of  $-\Delta_{\Gamma}$  and  $-\Delta_{\Gamma^c}$ , counted according to their multiplicities. Then

$$\eta_j = \min_{\substack{U \subset \mathcal{H}_\Gamma \\ \dim U = j}} \max_{\substack{u \in U \\ u \neq 0}} \frac{\int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right)}{\int_{\Omega} |u|^2}.$$

In particular, the first eigenvalue  $\eta_1$  of A is given by

$$\eta_1 = \min_{\substack{u \in \mathcal{H}_{\Gamma} \\ \omega \neq 0}} \frac{\int_{\Omega} \left( |\operatorname{div} u|^2 + |\omega(u)|^2 \right)}{\int_{\Omega} |u|^2}.$$
 (3.6)

Moreover,  $u \in \mathcal{H}_{\Gamma}$  with  $u \neq 0$  is a minimizer of (3.6) if and only if  $u = \nabla \psi + \nabla^{\perp} \varphi$  for some  $\psi \in \ker(-\Delta_{\Gamma^c} - \eta_1)$  and  $\varphi \in \ker(-\Delta_{\Gamma} - \eta_1)$ .

3.2. A curvature variational principle for mixed boundary conditions. In this subsection we prove an alternative representation of the sesquilinear form  $\mathfrak a$  and, thus, of the variational principle of Theorem 3.9. In order to do this we make the following assumption.

<span id="page-12-2"></span>**Hypothesis 3.10.** The set  $\Omega \subset \mathbb{R}^2$  is a bounded, simply connected Lipschitz domain whose boundary consists of finitely many  $C^{\infty}$ -smooth arcs. Moreover,  $\Gamma, \Gamma^c \subset \partial \Omega$  are non-empty, relatively open, connected subsets of the boundary such that

$$\Gamma \cap \Gamma^c = \emptyset$$
 and  $\overline{\Gamma \cup \Gamma^c} = \partial \Omega$ .

The interior angles at the two points where  $\Gamma$  and  $\Gamma^c$  meet are strictly below  $\pi/2$ , and  $\partial\Omega$  has no inward-pointing corners.

We point out that Proposition 3.6 and Theorem 3.9 apply under Hypothesis 3.10.

Let us first establish additional regularity of the space dom  $\mathfrak{a}=\mathcal{H}_{\Gamma}$  under the above hypothesis.

<span id="page-13-2"></span>**Lemma 3.11.** Assume that Hypothesis 3.10 is satisfied. Then

$$\mathcal{H}_{\Gamma} = \left\{ u \in H^1(\Omega; \mathbb{C}^2) : u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \right\}$$

holds.

*Proof.* It is clear that each  $u \in H^1(\Omega; \mathbb{C}^2)$  which satisfies the desired boundary conditions belongs to  $\mathcal{H}_{\Gamma}$ . Conversely, each  $u \in \mathcal{H}_{\Gamma}$  may, according to Proposition 3.6, be written as  $u = \nabla \psi + \nabla^{\perp} \varphi$  with  $\psi \in H^1_{0,\Gamma^c}(\Omega)$  and  $\varphi \in H^1_{0,\Gamma}(\Omega)$ . Furthermore,

$$\Delta \psi = \operatorname{div} u \in L^2(\Omega) \quad \text{and} \quad \Delta \varphi = \omega(u) \in L^2(\Omega),$$

and on the boundary we have

$$\partial_{\nu}\psi|_{\Gamma} = u|_{\Gamma} \cdot \nu - \nabla^{\perp}\varphi|_{\Gamma} \cdot \nu = 0$$

as well as

$$\partial_{\nu}\varphi|_{\Gamma^{c}} = \nabla^{\perp}\varphi|_{\Gamma^{c}} \cdot \tau = u|_{\Gamma^{c}} \cdot \tau - \nabla\psi|_{\Gamma^{c}} \cdot \tau = 0,$$

see Lemma 2.1. Hence,  $\psi \in \text{dom}(-\Delta_{\Gamma^c})$  and  $\varphi \in \text{dom}(-\Delta_{\Gamma})$  and, in particular,  $\psi, \varphi \in H^2(\Omega)$  by Proposition 2.2. It follows that  $u = \nabla \psi + \nabla^{\perp} \varphi \in H^1(\Omega; \mathbb{C}^2)$ , which completes the proof.

Now we can state an alternative expression for the sesquilinear form  $\mathfrak{a}$ . To this end we denote by  $\kappa$  the signed curvature of  $\partial\Omega$  with respect to the exterior unit normal  $\nu$ , defined at each point of  $\partial\Omega$  except at the corners, see for instance [27, Exercise 8, Section 2.3] or [29, Section 2.2]. That is, the sign is chosen such that  $\kappa \leq 0$  almost everywhere if  $\Omega$  is convex. It can be expressed as

<span id="page-13-0"></span>
$$\kappa = \nu \cdot \tau'$$

where the derivative  $\tau'$  of the unit tangent vector field  $\tau$  is to be understood piecewise via an arclength parametrization of the boundary in positive direction.

<span id="page-13-1"></span>**Proposition 3.12.** Assume that Hypothesis 3.10 is satisfied. Then

$$\mathfrak{a}[u,v] = \int_{\Omega} \left( \nabla u_1 \cdot \nabla v_1 + \nabla u_2 \cdot \nabla v_2 \right) - \int_{\partial \Omega} \kappa \, u \cdot v \tag{3.7}$$

holds for all  $u = (u_1, u_2)^\top, v = (v_1, v_2)^\top \in \mathcal{H}_{\Gamma}$ .

*Proof.* The proof of this proposition will be carried out in two steps.

**Step 1.** Let us denote by  $\mathcal{D}$  the space of all  $u \in \mathcal{H}_{\Gamma}$  such that

- (a)  $u \in C^{\infty}(\Omega; \mathbb{C}^2)$  and for each open set  $U \subset \Omega$  whose closure does not contain any corners of  $\partial\Omega$ ,  $u \in C^{\infty}(\overline{U}; \mathbb{C}^2)$ , and
- (b)  $\Delta u \in L^2(\Omega; \mathbb{C}^2)$ .

In this step we prove that (3.7) holds whenever  $u \in \mathcal{D}$  and  $v \in \mathcal{H}_{\Gamma}$ .

To this end, let  $u \in \mathcal{D}$ . Due to condition (b) we can apply the integration by parts formulas (2.1) and (2.2) to obtain, for all  $v \in \mathcal{H}_{\Gamma}$ ,

$$\mathfrak{a}[u,v] = \int_{\Omega} \left( \operatorname{div} u \, \overline{\operatorname{div} v} + \omega(u) \, \overline{\omega(v)} \right) \\
= -\int_{\Omega} \nabla \operatorname{div} u \cdot v + \left( \operatorname{div} u |_{\partial\Omega}, v |_{\partial\Omega} \cdot \nu \right)_{\partial\Omega} \\
- \int_{\Omega} \nabla^{\perp} \omega(u) \cdot v + \left( \omega(u) |_{\partial\Omega}, v |_{\partial\Omega} \cdot \tau \right)_{\partial\Omega} \\
= -\int_{\Omega} \Delta u_{1} \overline{v_{1}} - \int_{\Omega} \Delta u_{2} \overline{v_{2}} + \left( \operatorname{div} u |_{\partial\Omega}, v |_{\partial\Omega} \cdot \nu \right)_{\partial\Omega} + \left( \omega(u) |_{\partial\Omega}, v |_{\partial\Omega} \cdot \tau \right)_{\partial\Omega};$$

the last equality relies on the identity  $\Delta u = \nabla \operatorname{div} u + \nabla^{\perp} \omega(u)$ . An application of Green's identity then yields

$$\mathfrak{a}[u,v] = \int_{\Omega} \nabla u_1 \cdot \nabla v_1 + \int_{\Omega} \nabla u_2 \cdot \nabla v_2 - (\partial_{\nu} u_1|_{\partial\Omega}, v_1)_{\partial\Omega} - (\partial_{\nu} u_2|_{\partial\Omega}, v_2)_{\partial\Omega} + (\operatorname{div} u|_{\partial\Omega}, v|_{\partial\Omega} \cdot \nu)_{\partial\Omega} + (\omega(u)|_{\partial\Omega}, v|_{\partial\Omega} \cdot \tau)_{\partial\Omega}.$$
(3.8)

It remains to compute the boundary terms. To avoid technicalities at the corners, we perform the computations first for more regular v and extend the result to  $v \in \mathcal{H}_{\Gamma}$  by approximation afterwards.

Let  $\Gamma_1, \ldots, \Gamma_N$  be the smooth arcs which constitute  $\partial\Omega$  and let  $v \in C^{\infty}(\overline{\Omega}; \mathbb{C}^2)$  be such that the support of v does not contain any corner of  $\partial\Omega$ ; note that for the moment we do not require any boundary conditions on v. In this case, due to the assumption (a) on v we may write

<span id="page-14-4"></span><span id="page-14-3"></span><span id="page-14-0"></span>
$$(\partial_{\nu} u_1|_{\partial\Omega}, v_1)_{\partial\Omega} + (\partial_{\nu} u_2|_{\partial\Omega}, v_2)_{\partial\Omega} = \sum_{l=1}^{N} \int_{\Gamma_l} \begin{pmatrix} \nabla u_1 \cdot \nu \\ \nabla u_2 \cdot \nu \end{pmatrix} \cdot v. \tag{3.9}$$

Let us fix some  $l \in \{1, ..., N\}$  and let  $r : [0, L] \to \mathbb{R}^2$  be a  $C^{\infty}$ -smooth arc length parametrization of  $\Gamma_l$ , taken in positive direction. Then at each point x = r(s) with  $s \in (0, L)$ ,

$$\tau(x) = r'(s), \quad \nu(x) = -r'(s)^{\perp}, \quad \text{and} \quad \kappa(x) = \nu(x) \cdot r''(s) = \tau(x) \cdot r''(s)^{\perp}.$$
(3.10)

Therefore for  $x = r(s), s \in (0, L)$ , we have

$$\frac{\mathrm{d}}{\mathrm{d}s}(u_j(r(s))) = (\nabla u_j)(r(s)) \cdot r'(s) = \partial_1 u_j(x)\tau_1(x) + \partial_2 u_j(x)\tau_2(x), \quad j = 1, 2,$$

and thus

<span id="page-14-1"></span>
$$\begin{pmatrix} \partial_1 u(x) \cdot \tau(x) \\ \partial_2 u(x) \cdot \tau(x) \end{pmatrix} \cdot \nu(x) = \frac{\mathrm{d}u(r(s))}{\mathrm{d}s} \cdot \nu(x) + \partial_1 u_2(x) - \partial_2 u_1(x). \tag{3.11}$$

Analogously

$$\begin{pmatrix} \partial_1 u(x) \cdot \nu(x) \\ \partial_2 u(x) \cdot \nu(x) \end{pmatrix} \cdot \nu(x) = -\frac{\mathrm{d}u(r(s))}{\mathrm{d}s} \cdot \tau(x) + \partial_1 u_1(x) + \partial_2 u_2(x). \tag{3.12}$$

Now we distinguish two cases. If  $\Gamma_l \subset \Gamma$  then  $u|_{\Gamma_l} \cdot \nu = 0$  and thus, using (3.10),

<span id="page-14-2"></span>
$$\frac{\mathrm{d}u(r(s))}{\mathrm{d}s} \cdot \nu(x) = \frac{\mathrm{d}}{\mathrm{d}s} (u(r(s)) \cdot \nu(r(s))) - u(x) \cdot \frac{\mathrm{d}\nu(r(s))}{\mathrm{d}s}$$
$$= (u(x) \cdot \tau(x))\tau(x) \cdot r''(s)^{\perp} = \kappa(x)u(x) \cdot \tau(x).$$

Hence, if we decompose v into its tangential and normal components on  $\Gamma_l$ , (3.11) yields

$$\int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot v = \int_{\Gamma_{l}} (\tau \cdot v) \begin{pmatrix} \partial_{1} u \cdot \tau \\ \partial_{2} u \cdot \tau \end{pmatrix} \cdot \nu + \int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot (v \cdot \nu) \nu$$

$$= \int_{\Gamma_{l}} (\kappa u \cdot v + \omega(u) \tau \cdot v) + \int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot (v \cdot \nu) \nu,$$

where we used  $u \cdot v = (u \cdot \tau)(\tau \cdot v)$ . On the other hand, if  $\Gamma_l \subset \Gamma^c$ , then  $u|_{\Gamma_l} \cdot \tau = 0$  and we obtain from (3.10)

$$-\frac{\mathrm{d}u(r(s))}{\mathrm{d}s} \cdot \tau(x) = u(x) \cdot \frac{\mathrm{d}\tau(r(s))}{\mathrm{d}s} = \kappa(x)u(x) \cdot \nu(x)$$

and hence, from (3.12),

$$\int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot v = \int_{\Gamma_{l}} (\nu \cdot v) \begin{pmatrix} \partial_{1} u \cdot \nu \\ \partial_{2} u \cdot \nu \end{pmatrix} \cdot \nu + \int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot (v \cdot \tau) \tau$$

$$= \int_{\Gamma_{l}} (\kappa u \cdot v + \operatorname{div} u \nu \cdot v) + \int_{\Gamma_{l}} \begin{pmatrix} \nabla u_{1} \cdot \nu \\ \nabla u_{2} \cdot \nu \end{pmatrix} \cdot (v \cdot \tau) \tau.$$

Therefore, taking into account (3.9), the boundary terms in (3.8) sum up to

$$-\int_{\partial\Omega} \kappa \, u \cdot v - \sum_{\Gamma_l \subset \Gamma} \int_{\Gamma_l} \begin{pmatrix} \nabla u_1 \cdot \nu \\ \nabla u_2 \cdot \nu \end{pmatrix} \cdot (v \cdot \nu) \nu - \sum_{\Gamma_l \subset \Gamma^c} \int_{\Gamma_l} \begin{pmatrix} \nabla u_1 \cdot \nu \\ \nabla u_2 \cdot \nu \end{pmatrix} \cdot (v \cdot \tau) \tau. \tag{3.13}$$

Let now  $v \in \mathcal{H}_{\Gamma}$ . By [13, Chapter 8, Corollary 6.4] there exists a sequence  $(v^n)_n$  of functions in  $C^{\infty}(\overline{\Omega}; \mathbb{C}^2)$  whose supports do not contain the corners of  $\partial\Omega$  such that  $v^n \to v$  in  $H^1(\Omega; \mathbb{C}^2)$ . Then  $v^n|_{\Gamma_l} \to v|_{\Gamma_l}$  in  $H^{1/2}(\Gamma_l)$  for each l by the continuity of the trace operator from  $H^1(\Omega)$  to  $H^{1/2}(\partial\Omega)$ . In particular,  $v^n|_{\Gamma_l} \cdot \nu \to v|_{\Gamma_l} \cdot \nu$  and  $v^n|_{\Gamma_l} \cdot \tau \to v|_{\Gamma_l} \cdot \tau$  in  $H^{1/2}(\Gamma_l)$ . Hence using the boundary conditions  $v|_{\Gamma} \cdot \nu = 0$  and  $v|_{\Gamma^c} \cdot \tau = 0$ , it follows from (3.13) and (3.8) that

<span id="page-15-2"></span><span id="page-15-1"></span>
$$\mathfrak{a}[u,v] = \int_{\Omega} \nabla u_1 \cdot \nabla v_1 + \int_{\Omega} \nabla u_2 \cdot \nabla v_2 - \int_{\partial \Omega} \kappa \, u \cdot v \tag{3.14}$$

is true for all  $u \in \mathcal{D}$ ,  $v \in \mathcal{H}_{\Gamma}$ .

**Step 2.** In this step we prove the assertion of the proposition; that is, we extend (3.14) to all  $u \in \mathcal{H}_{\Gamma}$ . First of all, note that, for all  $u \in \mathcal{H}_{\Gamma}$ ,

$$\mathfrak{a}[u] = \int_{\Omega} (|\operatorname{div} u|^{2} + |\omega(u)|^{2}) = \int_{\Omega} (|\nabla u_{1}|^{2} + |\nabla u_{2}|^{2} - 2\operatorname{Re} \nabla u_{1} \cdot \nabla^{\perp} u_{2})$$

$$\leq 2 \int_{\Omega} (|\nabla u_{1}|^{2} + |\nabla u_{2}|^{2}) \leq 2||u||_{H^{1}(\Omega;\mathbb{C}^{2})}^{2}.$$

Hence there exists a constant C > 0 such that

$$||u||_{\mathfrak{a}}^2 = \mathfrak{a}[u] + \int_{\Omega} |u|^2 \le C||u||_{H^1(\Omega;\mathbb{C}^2)}^2, \quad u \in \mathcal{H}_{\Gamma}.$$

Since  $\mathcal{H}_{\Gamma}$  is complete with respect to both norms, the open mapping theorem implies that the two norms are equivalent on  $\mathcal{H}_{\Gamma}$ .

Consider the space  $\mathcal{D} \subset \mathcal{H}_{\Gamma}$  defined in Step 1. By elliptic regularity, see, e.g., [26, Theorem 4.18 (ii)],

$$\ker(A - \eta_i) = \nabla \ker(-\Delta_{\Gamma^c} - \eta_i) \oplus \nabla^{\perp} \ker(-\Delta_{\Gamma} - \eta_i) \subset \mathcal{D}$$

holds for each j; cf. Proposition 3.4. It follows from Lemma 2.4 that  $\mathcal{D}$  is a core of  $\mathfrak{a}$ , i.e.,  $\mathcal{D}$  is dense in  $\mathcal{H}_{\Gamma}$  with respect to the norm  $\|\cdot\|_{\mathfrak{a}}$ . By the equivalence of the norms,  $\mathcal{D}$  is also dense in  $\mathcal{H}_{\Gamma}$  with respect to the norm  $\|\cdot\|_{H^1(\Omega;\mathbb{C}^2)}$ . Using the continuity of the trace map  $H^1(\Omega;\mathbb{C}^2) \to H^{1/2}(\partial\Omega;\mathbb{C}^2)$  it follows that (3.14) extends to all  $u, v \in \mathcal{H}_{\Gamma}$ . This completes the proof.

As an immediate consequence of Proposition 3.12 and Theorem 3.9 we obtain the following variational principle. Recall that by Lemma 3.11

$$\mathcal{H}_{\Gamma} = \left\{ u \in H^1(\Omega; \mathbb{C}^2) : u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \right\}$$

<span id="page-15-0"></span>holds as soon as Hypothesis 3.10 is satisfied.

**Theorem 3.13.** Assume that Hypothesis 3.10 is satisfied. Denote by

$$\eta_1 \leq \eta_2 \leq \dots$$

the eigenvalues of A, i.e. the union of the eigenvalues of  $-\Delta_{\Gamma}$  and  $-\Delta_{\Gamma^c}$ , counted according to their multiplicities. Then

$$\eta_{j} = \min_{\substack{U \subset \mathcal{H}_{\Gamma} \\ \dim U = i}} \max_{\substack{u \in U \\ u \neq 0}} \frac{\int_{\Omega} \left( |\nabla u_{1}|^{2} + |\nabla u_{2}|^{2} \right) - \int_{\partial \Omega} \kappa |u|^{2}}{\int_{\Omega} |u|^{2}}.$$

In particular, the first eigenvalue  $\eta_1$  of A is given by

<span id="page-16-1"></span>
$$\eta_1 = \min_{\substack{u \in \mathcal{H}_{\Gamma} \\ u \neq 0}} \frac{\int_{\Omega} \left( |\nabla u_1|^2 + |\nabla u_2|^2 \right) - \int_{\partial \Omega} \kappa |u|^2}{\int_{\Omega} |u|^2}.$$
 (3.15)

Moreover,  $u \in \mathcal{H}_{\Gamma}$  with  $u \neq 0$  is a minimizer of (3.15) if and only if  $u = \nabla \psi + \nabla^{\perp} \varphi$  for some  $\psi \in \ker(-\Delta_{\Gamma^c} - \eta_1)$  and  $\varphi \in \ker(-\Delta_{\Gamma} - \eta_1)$ .

### <span id="page-16-0"></span>4. Eigenvalue inequalities and monotonicity of eigenfunctions

In this section we apply the variational principle of Theorem 3.13 to obtain an inequality between the lowest eigenvalues of two mixed Laplacian eigenvalue problems with boundary conditions dual to each other. At the same time we establish monotonicity of the corresponding eigenfunction. In the following we denote by  $Q_1, \ldots, Q_4$  the open first to fourth quadrants in  $\mathbb{R}^2$ . The proof of the following result is inspired by the proof of [32, Theorem 1.2] and by methods from the proof of Courant's nodal domain theorem. The following theorem comprises Theorems 1.1 and 1.2 in the introduction.

<span id="page-16-5"></span>**Theorem 4.1.** Assume that Hypothesis 3.10 is satisfied. Assume in addition that  $\Omega$  can be rotated such that  $\nu(x) \in \overline{Q_3}$  for almost all  $x \in \Gamma^c$  and  $\nu(x) \in \overline{Q_2} \cup \overline{Q_4}$  for almost all  $x \in \Gamma$ ; cf. Figure 1.1. Then

<span id="page-16-4"></span>
$$\lambda_1^{\Gamma^c} < \lambda_1^{\Gamma} \tag{4.1}$$

holds. Furthermore, the eigenfunction of  $-\Delta_{\Gamma^c}$  corresponding to  $\lambda_1^{\Gamma^c}$ , chosen positive, is strictly increasing in the directions of both  $e_1 = (1,0)^{\top}$  and  $e_2 = (0,1)^{\top}$ , supposed  $\Omega$  is rotated in the above way.

*Proof.* We assume that  $\Omega$  is rotated as stated in the theorem. Let  $u \in \mathcal{H}_{\Gamma}$  be a minimizer of (3.15). Then u satisfies the boundary conditions

<span id="page-16-2"></span>
$$\begin{cases} \nu_1 u_1 + \nu_2 u_2 = 0 & \text{almost everywhere on } \Gamma; \\ \tau_1 u_1 + \tau_2 u_2 = 0 & \text{almost everywhere on } \Gamma^c. \end{cases}$$
(4.2)

Define

$$v = \begin{pmatrix} v_1 \\ v_2 \end{pmatrix} := \begin{pmatrix} |u_1| \\ |u_2| \end{pmatrix}.$$

Our assumptions on the normal directions of  $\Gamma$  and  $\Gamma^c$  imply

<span id="page-16-3"></span>
$$\begin{cases} \nu_1 \nu_2 \le 0 & \text{almost everywhere on } \Gamma, \\ \tau_1 \tau_2 \le 0 & \text{almost everywhere on } \Gamma^c, \end{cases}$$
 (4.3)

for the components of the normal and tangential unit vector fields. From this and (4.2) it follows immediately that v satisfies the same boundary conditions as u, i.e.  $v \in \mathcal{H}_{\Gamma}$ . Moreover, due to

$$\partial_i v_i = \partial_i |u_i| = \operatorname{sign}(u_i) |\partial_i u_i| \le |\partial_i u_i|$$

the quotient

$$\frac{\int_{\Omega} \left( |\nabla v_1|^2 + |\nabla v_2|^2 \right) - \int_{\partial \Omega} \kappa \left( |v_1|^2 + |v_2|^2 \right)}{\int_{\Omega} \left( |v_1|^2 + |v_2|^2 \right)}$$

is less or equal the same term with v replaced by u; however, as u is a minimizer of the Rayleigh quotient in (3.15), it follows that v is a minimizer as well. Then by Theorem 3.13,  $Av = \eta_1 v$ , that is,

$$-\Delta v_j = \eta_1 v_j \ge 0, \quad j = 1, 2,$$

cf. Remark 3.3. Hence, by the maximum principle for subharmonic functions applied to  $-v_j$ , each  $v_j$  is either non-zero everywhere in  $\Omega$  or constantly equal to zero. In particular,  $u_j$  is either non-zero everywhere in  $\Omega$  or identically zero, j = 1, 2.

Next we argue that both components of u must be strictly positive in  $\Omega$ . Assume for a contradiction that, without loss of generality,  $u_1 = 0$  constantly in  $\Omega$ . We prove that this implies that  $\Omega$  is an axioparallel rectangle, which contradicts the assumptions on the angles between  $\Gamma$  and  $\Gamma^c$ . In fact, if  $\Gamma^c$  contains a part which is not axioparallel, then there exists a non-empty, relatively open set  $\Sigma \subset \Gamma^c$  such that  $\tau_2 \neq 0$  almost everywhere on  $\Sigma$  and, hence,  $u|_{\Gamma^c} \cdot \tau = 0$  implies  $u_2|_{\Sigma} = 0$ ; on the other hand, by (3.4), u can be written  $u = \nabla \psi + \nabla^{\perp} \varphi$  for some  $\psi \in$  $\ker(-\Delta_{\Gamma_c} - \eta_1)$  and  $\varphi \in \ker(-\Delta_{\Gamma} - \eta_1)$ ; hence,  $\operatorname{div} u = \Delta \psi = -\eta_1 \psi$  and, thus,  $0 = \operatorname{div} u|_{\Gamma^c} = \partial_2 u_2|_{\Sigma}$ . Since  $e_2$  is non-tangential on  $\Sigma$ , we get  $\partial_{\nu} u_2|_{\Sigma} = 0$ . As  $-\Delta u_2 = \eta_1 u_2$  and  $u_2$  together with its normal derivative vanishes on  $\Sigma$ , a unique continuation argument, see, e.g., [25, Lemma 2.2], gives  $u_2 = 0$  constantly in  $\Omega$ , a contradiction. Analogously, we can use the boundary conditions  $u|_{\Gamma} \cdot \nu = 0$  and  $\omega(u)|_{\Gamma}=0$  to conclude that  $\Gamma$  consists of axioparallel pieces only. Thus  $\Omega$  is a rectangle, a contradiction to the angle assumption in Hypothesis 3.10. Hence we have shown that both  $u_1$  and  $u_2$  are strictly non-zero in  $\Omega$ , and we can conclude further from (4.2) and (4.3) that  $sgn(u_1) = sgn(u_2)$ .

Next, let us show that

<span id="page-17-1"></span>
$$\eta_1 = \lambda_1^{\Gamma^c} < \lambda_1^{\Gamma} \tag{4.4}$$

holds. For a contradiction, assume  $\eta_1 = \lambda_1^{\Gamma}$  and let  $\varphi \in \ker(-\Delta_{\Gamma} - \eta_1)$  be non-trivial. Then by Proposition 3.4,  $u = \nabla^{\perp} \varphi \in \mathcal{H}_{\Gamma}$  is a minimizer of (3.15). Thus, according to what we have just seen, we may choose the sign of  $\varphi$  such that both  $u_1 = -\partial_2 \varphi$  and  $u_2 = \partial_1 \varphi$  are strictly positive in  $\Omega$ ; that is,  $\varphi$  is strictly increasing in the directions of both  $e_1$  and  $-e_2$ . By the assumptions on  $\Omega$ , there exist points  $x_1, x_2 \in \Gamma$  and a path through  $\Omega$  from  $x_1$  to  $x_2$  consisting of axio-parallel line segments each of which points into the direction of either  $e_1$  or  $-e_2$ ; cf. Figure 4.1. In particular,  $\varphi$  is strictly increasing along this path. On the other hand,  $\varphi(x_1) = \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1 + \frac{1}{2} (1$ 

![](_page_17_Picture_9.jpeg)

FIGURE 4.1. The eigenfunction  $\varphi$  would simultaneously be vanishing on  $\Gamma$  and strictly increasing along both pictured paths.

<span id="page-17-0"></span> $0 = \varphi(x_2)$ , a contradiction. Thus we have proven (4.4). In particular, we have shown the inequality (4.1).

To summarize, we have shown that  $u \in \mathcal{H}_{\Gamma}$  is a minimizer of (3.15) if and only if  $u = \nabla \psi$  for some non-trivial  $\psi \in \ker(-\Delta_{\Gamma^c} - \lambda_1^{\Gamma^c})$ , and that in this case both components of  $\nabla \psi$  are strictly positive. Hence, the eigenfunction  $\psi$  is strictly increasing in  $\Omega$  in the directions of both  $e_1$  and  $e_2$ . This completes the proof.  $\square$ 

Eigenvalue inequalities of the form (4.1) for Laplacians with mixed boundary conditions were obtained earlier by the authors of this article in [3] using classical variational principles. Theorem 3.1 in [3] requires the stronger assumptions that  $\Omega$  is convex and  $\Gamma^c$  is a straight line segment. On the other hand, it does not require  $\Gamma$  to contain at least one corner, while the assumption on the exterior unit normals of  $\Gamma$  in Theorem 4.1 forces  $\Gamma$  to contain one corner with interior angle at most  $\pi/2$  at which the exterior normal changes between the second and fourth quadrant.

The next example shows that the inequality (4.1) no longer needs to hold once the interior angles at the end points of  $\Gamma$  are equal to  $\pi/2$ .

**Example 4.2.** Let  $\Omega = (0, \pi) \times (0, \pi)$  and let  $\Gamma$  consist of the sides  $y = \pi$  and  $x = \pi$  while  $\Gamma^c$  consists of the sides y = 0 and x = 0. Then the interior angles of  $\partial\Omega$  at the end points of  $\Gamma$  equal  $\pi/2$  while all further assumptions of Theorem 4.1 are satisfied. However, the eigenvalue inequality (4.1) fails since  $\lambda_1^{\Gamma^c} = \frac{1}{2} = \lambda_1^{\Gamma}$  as one computes easily by separating variables.

The following corollary concerns the hot spots property for the first eigenfunction of the operator  $-\Delta_{\Gamma^c}$ .

<span id="page-18-0"></span>Corollary 4.3. Assume that Hypothesis 3.10 is satisfied. In addition, assume that  $\nu(x) \in \overline{Q_3}$  for almost all  $x \in \Gamma^c$  and  $\nu(x) \in \overline{Q_2} \cup \overline{Q_4}$  for almost all  $x \in \Gamma$ . Then the eigenfunction of  $-\Delta_{\Gamma^c}$  corresponding to its first eigenvalue  $\lambda_1^{\Gamma^c}$ , chosen positive in  $\Omega$ , takes its maximum only on  $\Gamma$ . If  $\Gamma$  does not contain any axioparallel segment, then the point in  $\overline{\Omega}$  at which the eigenfunction takes its maximum is unique and coincides with the corner P at which the normal vector makes a jump between the quadrants  $Q_2$  and  $Q_4$ .

Proof. By Theorem 4.1 the eigenfunction is strictly increasing in  $\Omega$  in the directions of  $e_1$  and  $e_2$ . In particular, as for each point  $x \in \Omega$  the halfline  $\{x + te_1 : t > 0\}$  intersects  $\Gamma$ , it follows that the maximum of the eigenfunction is attained only in  $\Gamma$ . If  $\Gamma$  does not contain any axioparallel line segment, then  $\Gamma$  contains points  $x_1, x_2$  such that  $\nu(x_1) \in Q_2$  and  $\nu(x_2) \in Q_4$ , and there cannot exist more than one corner at which  $\nu$  makes a jump between  $Q_2$  and  $Q_4$ ; otherwise  $\Gamma$  needs to contain an inward-pointing corner. If P denotes the unique corner at which  $\nu$  jumps from  $Q_2$  to  $Q_4$ , for any  $x \in \Gamma$ ,  $x \neq P$ , there exists a path through  $\Omega$  from x to P consisting of axioparallel line segments pointing into the directions of either  $e_1$  or  $e_2$ , and the eigenfunction is strictly increasing along this path. Hence its unique maximum is attained at P.

According to Corollary 4.3, in the case of the first domain in Figure 4.1 the eigenfunction corresponding to  $\lambda_1^{\Gamma^c}$  takes its maximum at the point P only.

Next, we apply Theorem 4.1 and Corollary 4.3 to the recently much studied case of triangles.

**Example 4.4.** Assume that  $\Omega$  is an acute triangle,  $\Gamma^c$  is one of its sides and  $\Gamma$  consists of the remaining two sides. Further, assume that  $\Omega$  is rotated such that  $\Gamma$  and  $\Gamma^c$  satisfy the condition on the normal vectors required in Theorem 4.1 and such that  $\Gamma$  contains no axioparallel part; this is always possible as long as the triangle is acute, see Figure 4.2. Then the first eigenfunction  $\psi_1$  of  $-\Delta_{\Gamma^c}$  is strictly increasing in the directions of  $e_1$  and  $e_2$ , implying that  $\psi_1$ , chosen positive, takes its maximum at a unique point, namely the corner inside the Neumann part  $\Gamma$ ; cf.

![](_page_19_Picture_2.jpeg)

FIGURE 4.2. The first eigenfunction of  $-\Delta_{\Gamma^c}$  takes its maximum at P.

Corollary 4.3. This observation is slightly more general than Theorem 1.3 in the recent preprint [24] and Theorem 1.1 of [18] when applied to the acute case. The statement on the only maximum lying at the Neumann vertex confirms Corollary 1.6 (3) of [24].

### <span id="page-19-1"></span>APPENDIX A. A HELMHOLTZ TYPE DECOMPOSITION

<span id="page-19-0"></span>In this appendix we provide an elementary proof for a Helmholtz type orthogonal decomposition of the space  $L^2(\Omega; \mathbb{C}^2)$  which is suitable for mixed boundary conditions. A proof in the language of differential forms can be found in [9]. Recall the notation

<span id="page-19-3"></span>
$$H^1_{0,\Sigma}(\Omega) = \left\{ \psi \in H^1(\Omega) : u|_{\Sigma} = 0 \right\}$$

for any non-empty, relatively open set  $\Sigma \subset \partial \Omega$ . In the proof of the following theorem we will make use of the Poincaré inequality

$$\int_{\Omega} |\nabla \psi|^2 \ge c \int_{\Omega} |\psi|^2, \quad \psi \in H^1_{0,\Sigma}(\Omega), \tag{A.1}$$

where the optimal constant c equals the eigenvalue  $\lambda_1^{\Sigma}$ .

**Theorem A.1.** Assume that Hypothesis 3.1 is satisfied. Then the orthogonal decomposition

<span id="page-19-2"></span>
$$L^{2}(\Omega; \mathbb{C}^{2}) = \nabla H^{1}_{0,\Gamma^{c}}(\Omega) \oplus \nabla^{\perp} H^{1}_{0,\Gamma}(\Omega) \oplus H_{c}$$
(A.2)

holds, where

$$H_c = \left\{ u \in L^2(\Omega; \mathbb{C}^2) : \operatorname{div} u = \omega(u) = 0, u|_{\Gamma} \cdot \nu = 0, u|_{\Gamma^c} \cdot \tau = 0 \right\}.$$

*Proof.* Let us first show that each of the spaces on the right-hand side of (A.2) is a closed subspace of  $L^2(\Omega; \mathbb{C}^2)$ . We first prove that  $\nabla H^1_{0,\Gamma^c}(\Omega)$  is closed. Let  $\psi_n \in H^1_{0,\Gamma^c}(\Omega)$  such that  $(\nabla \psi_n)_n$  is a Cauchy sequence in  $L^2(\Omega; \mathbb{C}^2)$ , that is,

$$\int_{\Omega} |\nabla \psi_n - \nabla \psi_m|^2 \to 0$$

as  $m, n \to +\infty$ . Then there exists an element  $u \in L^2(\Omega; \mathbb{C}^2)$  such that  $\nabla \psi_n \to u$  in  $L^2(\Omega; \mathbb{C}^2)$ . Moreover, by the Poincaré inequality (A.1),

$$\int_{\Omega} |\psi_n - \psi_m|^2 \le \frac{1}{c} \int_{\Omega} |\nabla \psi_n - \nabla \psi_m|^2 \to 0.$$

Thus there exists  $\psi \in L^2(\Omega)$  such that  $\psi_n \to \psi$  in  $L^2(\Omega)$ . Furthermore, for each  $\varphi \in C_0^{\infty}(\Omega)$  we have

$$\int_{\Omega} \psi \partial_j \varphi = \lim_{n \to \infty} \int_{\Omega} \psi_n \partial_j \varphi = -\lim_{n \to \infty} \int_{\Omega} \partial_j \psi_n \varphi = -\int_{\Omega} u_j \varphi, \quad j = 1, 2,$$

implying  $\psi \in H^1(\Omega)$  and  $\nabla \psi = u$  in  $L^2(\Omega; \mathbb{C}^2)$ . We have therefore  $\psi_n \to \psi$  in  $H^1(\Omega)$ , and as  $H^1_{0,\Gamma^c}(\Omega)$  is complete, it follows  $\psi \in H^1_{0,\Gamma^c}(\Omega)$ . Hence  $\nabla H^1_{0,\Gamma^c}(\Omega)$  is complete. The proof of the completeness of  $\nabla^{\perp} H^1_{0,\Gamma}(\Omega)$  is analogous.

Now consider  $u^n \in H_c$  such that  $(u^n)_n$  is a Cauchy sequence in  $L^2(\Omega; \mathbb{C}^2)$ . Since  $\operatorname{div} u^n = \omega(u^n) = 0$  for all n,  $(u^n)_n$  is a Cauchy sequence in both  $H(\operatorname{div}; \Omega)$  and  $H(\omega; \Omega)$ . Hence there exists some  $u \in H(\operatorname{div}; \Omega) \cap H(\omega; \Omega)$  such that  $(u^n)_n$  converges to u in both  $H(\operatorname{div}; \Omega)$  and  $H(\omega; \Omega)$ . In particular, by continuity,  $\operatorname{div} u = \omega(u) = 0$  follows. Since the tangent and normal traces are continuous mappings from  $H(\omega; \Omega)$  or  $H(\operatorname{div}; \Omega)$ , respectively, into  $H^{-1/2}(\partial \Omega)$ , the identities  $u|_{\Gamma} \cdot \nu = 0$  and  $u|_{\Gamma^c} \cdot \tau = 0$  follow. Hence  $H_c$  is complete.

Let us prove next that the spaces on the right-hand side of (A.2) are mutually orthogonal. For this let first  $\psi \in H^1_{0,\Gamma^c}(\Omega)$  and  $\varphi \in H^1_{0,\Gamma}(\Omega)$ . Integration by parts (2.1) gives

$$\int_{\Omega} u \cdot v = \int_{\Omega} \nabla \psi \cdot \nabla^{\perp} \varphi = -\int_{\Omega} \psi \, \overline{\operatorname{div}} \, \nabla^{\perp} \varphi - (\psi|_{\partial\Omega}, \nabla \varphi|_{\partial\Omega} \cdot \tau)_{\partial\Omega} = 0$$

due to the boundary conditions of  $\psi$  and  $\varphi$ , and div  $\nabla^{\perp}\varphi = 0$ . Now let in addition  $u \in H_c$ . Then

$$\int_{\Omega} u \cdot (\nabla \psi + \nabla^{\perp} \varphi) = -\int_{\Omega} \operatorname{div} u \, \overline{\psi} + (u|_{\partial\Omega} \cdot \nu, \psi|_{\partial\Omega})_{\partial\Omega}$$
$$-\int_{\Omega} \omega(u) \, \overline{\varphi} + (u|_{\partial\Omega} \cdot \tau, \varphi|_{\partial\Omega})_{\partial\Omega} = 0.$$

Thus  $\nabla H^1_{0,\Gamma^c}(\Omega)$  and  $\nabla^{\perp} H^1_{0,\Gamma}(\Omega)$  are orthogonal to each other and both spaces are orthogonal to  $H_c$ .

To establish (A.2) it remains to show that each  $u \in L^2(\Omega; \mathbb{C}^2)$  which is orthogonal to  $\nabla H^1_{0,\Gamma^c}(\Omega) \oplus \nabla^\perp H^1_{0,\Gamma}(\Omega)$  belongs to  $H_c$ . Indeed, for such u we have

$$\int_{\Omega} u \cdot \nabla \psi = 0 = \int_{\Omega} u \cdot \nabla^{\perp} \varphi$$

for all  $\psi, \varphi \in C_0^{\infty}(\Omega)$ , implying div  $u = 0 = \omega(u)$ . In particular,  $u|_{\partial\Omega} \cdot \nu, u|_{\partial\Omega} \cdot \tau \in H^{-1/2}(\partial\Omega)$  are well-defined. Furthermore, for each  $\psi \in H^1_{0,\Gamma^c}(\Omega)$ ,

$$0 = \int_{\Omega} u \cdot \nabla \psi = (u|_{\partial\Omega} \cdot \nu, \psi|_{\partial\Omega})_{\partial\Omega},$$

giving  $u|_{\Gamma} \cdot \nu = 0$ . Analogously,

$$0 = \int_{\Omega} u \cdot \nabla^{\perp} \varphi = (u|_{\partial\Omega} \cdot \tau, \varphi|_{\partial\Omega})_{\partial\Omega}$$

holds for all  $\varphi \in H^1_{0,\Gamma}(\Omega)$ , giving  $u|_{\Gamma^c} \cdot \tau = 0$ . Thus we have shown  $u \in H_c$ . This completes the proof.

We conclude this appendix with an observation on the space  $H_c$ . In Example 3.8 we have seen that  $H_c$  may be non-trivial if  $\Gamma$  is not connected. In fact, the ideas of the proof of Proposition 3.6 may be used to estimate the dimension of  $H_c$  and, hence, the dimension of the kernel of the operator A in Section 3; this is exemplified in the following proposition.

<span id="page-20-0"></span>**Proposition A.2.** Let  $\Omega \subset \mathbb{R}^2$  be a bounded, simply connected Lipschitz domain whose boundary consists of finitely many  $C^{\infty}$ -smooth arcs and has no inward-pointing corners. Let  $\Gamma, \Gamma^c \subset \partial \Omega$  be non-empty, relatively open subsets of the boundary such that  $\Gamma \cap \Gamma^c = \emptyset$  and  $\overline{\Gamma \cup \Gamma^c} = \partial \Omega$ , and such that the interior angles

at all points where  $\Gamma$  and  $\Gamma^c$  meet are strictly below  $\pi/2$ . Assume that  $\Gamma$  consists of two connected components. Then

<span id="page-21-1"></span>
$$\dim H_c < 1$$
.

*Proof.* Let us assume for a contradiction that there exist  $u, v \in H_c$  such that  $\int_{\Omega} |u|^2 = 1 = \int_{\Omega} |v|^2$  and  $\int_{\Omega} u \cdot v = 0$ . Under the assumptions of the proposition we can argue as in the proof of Lemma 3.11 to show that  $u, v \in H^1(\Omega; \mathbb{C}^2)$  and thus  $u|_{\partial\Omega}\cdot\nu, u|_{\partial\Omega}\cdot\tau, v|_{\partial\Omega}\cdot\nu, v|_{\partial\Omega}\cdot\tau\in L^2(\partial\Omega).$  Since  $\Omega$  is simply connected,  $\omega(u)=0$  in  $\Omega$ implies that there exists  $f \in H^2(\Omega)$  such that  $u = \nabla f$ , see [16, Chapter I, Theorem 2.9, and similarly  $\omega(u^{\perp}) = \operatorname{div} u = 0$  in  $\Omega$  implies that there exists  $g \in H^2(\Omega)$  such that  $u^{\perp} = \nabla g$ . Furthermore, we have

$$\partial_{\tau} f|_{\Gamma^c} = u|_{\Gamma^c} \cdot \tau = 0, \quad \text{and} \quad \partial_{\tau} g|_{\Gamma} = u|_{\Gamma} \cdot \nu = 0.$$
 (A.3)

Let us denote by  $\Gamma_1$  and  $\Gamma_3$  the connected components of  $\Gamma$ . Since  $\Omega$  is simply connected,  $\Gamma^c$  also consists of two connected components  $\Gamma_2$  and  $\Gamma_4$ , where the enumeration is chosen following the boundary in positive direction, see Figure A.1. Let us call the end points of  $\Gamma_2$  ordered following positive orientation P and Q. By (A.3), f is constant along  $\Gamma_2$  and along  $\Gamma_4$ , and we can assume without loss of

![](_page_21_Picture_7.jpeg)

FIGURE A.1. Each  $\Gamma_i$  is contained in a level set of the potentials of elements of  $H_c$ .

generality that  $f|_{\Gamma_2}=a_2$  for some constant  $a_2\in\mathbb{C}$  and  $f|_{\Gamma_4}=0$ . Analogously, we may assume that  $g|_{\Gamma_1} = a_1$  for some  $a_1 \in \mathbb{C}$  and  $g|_{\Gamma_3} = 0$ . The same observations hold for v: there exist  $p, q \in H^2(\Omega)$  such that  $v = \nabla p$ ,  $v^{\perp} = \nabla q$ ,  $q|_{\Gamma_1} = b_1$  and  $p|_{\Gamma_2} = b_2$  identically for some  $b_1, b_2 \in \mathbb{C}$ ,  $q|_{\Gamma_3} = 0$  and  $p|_{\Gamma_4} = 0$ . We compute

<span id="page-21-0"></span>
$$0 = \int_{\Omega} u \cdot v = \int_{\Omega} \nabla f \cdot v = -\int_{\Omega} f \, \overline{\operatorname{div}} \, v + \int_{\partial \Omega} f \, \nu \cdot v = \int_{\Gamma^{c}} f \, \overline{\partial_{\tau}} q$$

$$= a_{2} \int_{\Gamma_{2}} \overline{\partial_{\tau}} q = a_{2}(\overline{q}(Q) - \overline{q}(P)) = -a_{2} \overline{b_{1}},$$
(A.4)

where we used the fundamental theorem of calculus. Thus  $a_2 = 0$  or  $b_1 = 0$ . Analogous computations yield

$$\int_{\Omega} |u|^2 = \int_{\Omega} \nabla f \cdot u = -a_2 \overline{a_1}$$

and

and 
$$\int_{\Omega}|v|^2=\int_{\Omega}v\cdot\nabla p=-b_2\overline{b_1},$$
 and it follows  $\int_{\Omega}|u|^2=0$  or  $\int_{\Omega}|v|^2=0$ , a contradiction.

### ACKNOWLEDGEMENTS

The authors gratefully acknowledge financial support by the grants no. 2018-04560 and 2022-03342 of the Swedish Research Council (VR).

### References

- <span id="page-22-15"></span>[1] N. Aldeghi, Inequalities for eigenvalues of Schr¨odinger operators with mixed boundary conditions, preprint, [arXiv:2409.00019.](http://arxiv.org/abs/2409.00019)
- <span id="page-22-0"></span>[2] H. Ammari, O. Bruno, K. Imeri, and N. Nigam, Wave enhancement through optimization of boundary conditions, SIAM J. Sci. Comput. 42 (2020), no.1, B207–B224.
- <span id="page-22-14"></span>[3] N. Aldeghi and J. Rohleder, Inequalities between the lowest eigenvalues of Laplacians with mixed boundary conditions, J. Math. Anal. Appl. 524 (2023), no.1, Paper No. 127078.
- <span id="page-22-8"></span>[4] R. Atar and K. Burdzy, On Neumann eigenfunctions in lip domains, J. Amer. Math. Soc. 17 (2004), no. 2, 243–265.
- <span id="page-22-24"></span>[5] A. Azzam, Smoothness properties of solutions of mixed boundary value problems for elliptic equations in sectionally smooth n-dimensional domains, Ann. Polon. Math. Vol. 1, No. 40 (1981), 81–93.
- <span id="page-22-9"></span>[6] R. Ba˜nuelos and K. Burdzy, On the "hot spots" conjecture of J. Rauch, J. Funct. Anal. 164 (1999), 1–33.
- <span id="page-22-7"></span>[7] R. Ba˜nuelos and M. Pang, An inequality for potentials and the "hot–spots" conjecture, Indiana Univ. Math. J. 53 (2004), no.1, 35–47.
- <span id="page-22-6"></span>[8] R. Ba˜nuelos, M. Pang and M. Pascu, Brownian motion with killing and reflection and the "hot-spots" problem, Probab. Theory Related Fields 130 (2004), no.1, 56–68.
- <span id="page-22-19"></span>[9] S. Bauer, D. Pauly, and M. Schomburg, Weck's selection theorem: the Maxwell compactness property for bounded weak Lipschitz domains with mixed boundary conditions in arbitrary dimensions, Maxwell's equations–analysis and numerics, 77–104, Radon Ser. Comput. Appl. Math. 24, De Gruyter, Berlin, 2019.
- <span id="page-22-4"></span>[10] P. B´erard and B. Helffer, On Courant's nodal domain property for linear combinations of eigenfunctions part II, Schr¨odinger operators, spectral analysis and number theory, Springer Proc. Math. Stat. 348 (2021), 47–88.
- <span id="page-22-1"></span>[11] L. Chesnel, S. A. Nazarov, and J. Taskinen, Spectrum of the Laplacian with mixed boundary conditions in a chamfered quarter of layer, preprint, [arXiv:2303.15345.](http://arxiv.org/abs/2303.15345)
- <span id="page-22-21"></span>[12] P. Doktor and A. Zen´ıˇsek, ˇ The density of infinitely differentiable functions in Sobolev spaces with mixed boundary conditions, Appl. Math. 51 (2006), no.5, 517–547.
- <span id="page-22-27"></span>[13] D.,E. Edmunds and W. D. Evans, Spectral Theory and Differential Operators, Second Edition, Oxford Math. Monogr., Oxford University Press, Oxford, 2018.
- <span id="page-22-2"></span>[14] V. Felli, B. Noris, and R. Ognibene, Eigenvalues of the Laplacian with moving mixed boundary conditions: the case of disappearing Dirichlet region, Calc. Var. Partial Differential Equations 60 (2021), no. 1, Paper No. 12, 33 pp.
- <span id="page-22-3"></span>[15] V. Felli, B. Noris, and R. Ognibene, Eigenvalues of the Laplacian with moving mixed boundary conditions: the case of disappearing Neumann region, J. Differential Equations 320 (2022), 247–315.
- <span id="page-22-18"></span>[16] V. Girault and P. A. Raviart, Finite Element Methods for Navier-Stokes Equations, Theory and Algorithms, Springer Ser. Comput. Math. 5, Springer-Verlag, Berlin, 1986.
- <span id="page-22-22"></span>[17] P. Grisvard, Singularities in Boundary Value Problems, Rech. Math. Appl. 22, Masson, Paris; Springer-Verlag, Berlin, 1992.
- <span id="page-22-12"></span><span id="page-22-10"></span>[18] L. Hatcher, First mixed Laplace eigenfunctions with no hot spots, preprint, [arXiv:2401.01514.](http://arxiv.org/abs/2401.01514)
- [19] D. Jerison and N. Nadirashvili, The "hot spots" conjecture for domains with two axes of symmetry, J. Amer. Math. Soc. 13 (2000), no. 4, 741–772.
- <span id="page-22-20"></span><span id="page-22-5"></span>[20] C. Judge and S. Mondal, Euclidean triangles have no hot spots, Ann. of Math. 191 (2020), 167–211.
- <span id="page-22-16"></span>[21] T. Kato, Perturbation Theory for Linear Operators, Springer-Verlag, Berlin, 1995.
- [22] J. B. Kennedy and J. Rohleder, On the hot spots conjecture in higher dimensions, preprint, [arXiv:2410.00816.](http://arxiv.org/abs/2410.00816)
- <span id="page-22-23"></span>[23] V. A. Kondrat'ev and O. A. Oleinik, Boundary value problems for partial differential equations in nonsmooth domains, Uspekhi Mat. Nauk 38 (1983), no. 2(230), 3–76.
- <span id="page-22-13"></span>[24] R. Li and R. Yao, Monotonicity of positive solutions to semilinear elliptic equations with mixed boundary conditions in triangles, preprint, [arXiv:2401.17912.](http://arxiv.org/abs/2401.17912)
- <span id="page-22-28"></span>[25] V. Lotoreichik and J. Rohleder, Eigenvalue inequalities for the Laplacian with mixed boundary conditions, J. Differential Equations 263 (2017), 491–508.
- <span id="page-22-17"></span>[26] W. McLean, Strongly Elliptic Systems and Boundary Integral Equations, Cambridge University Press, Cambridge, 2000.
- <span id="page-22-25"></span><span id="page-22-11"></span>[27] B. O'Neill, Elementary Differential Geometry, 2nd ed., Academic Press Inc., 2006.
- [28] M. N. Pascu, Scaling coupling of reflecting Brownian motions and the hot spots problem, Trans. Amer. Math. Soc. 354 (2002), no. 11, 4681–4702.
- <span id="page-22-26"></span>[29] A. Pressley, Elementary Differential Geometry, Second edition, Springer Undergrad. Math. Ser. Springer-Verlag London, Ltd., London, 2010.

- <span id="page-23-5"></span>[30] M. Reed and B. Simon, Methods of modern mathematical physics II, Fourier analysis, selfadjointness, Academic Press, New York–London, 1975.
- <span id="page-23-1"></span>[31] J. Rohleder, A remark on the order of mixed Dirichlet–Neumann eigenvalues of polygons, Oper. Theory Adv. Appl. 276, Birkh¨auser/Springer, Cham, 2020, 570–575.
- <span id="page-23-6"></span><span id="page-23-3"></span>[32] J. Rohleder, A new approach to the hot spots conjecture, preprint, [arXiv:2106.05224.](http://arxiv.org/abs/2106.05224)
- [33] J. Rohleder, Inequalities between Neumann and Dirichlet Laplacian eigenvalues on planar domains, preprint, [arXiv:2306.12922.](http://arxiv.org/abs/2306.12922)
- <span id="page-23-0"></span>[34] M. Santacesaria and T. Yachimura, On an inverse Robin spectral problem, Inverse Problems 36 (2020), no.7, 075004.
- <span id="page-23-2"></span>[35] B. Siudeja, On mixed Dirichlet-Neumann eigenvalues of triangles, Proc. Amer. Math. Soc. 144 (2016), 2479–2493.
- <span id="page-23-4"></span>[36] N. M. Wigley, Mixed boundary value problems in plane domains with corners, Math. Z. 115 (1970), 33–52.

Matematiska institutionen, Stockholms universitet, 106 91 Stockholm, Sweden Email address: nausica.aldeghi@math.su.se, jonathan.rohleder@math.su.se