# New Forms of QCD Matter Discovered at RHIC.

# Miklos Gyulassy $^a$ and Larry McLerran $^b$

<sup>a</sup>Physics Department, Columbia UniversityNew York, NY USA <sup>b</sup>Physics Department POB 5000 Brookhaven National Laboratory Upton, NY 11973 USA

#### May 5, 2004

#### Abstract

We discuss two special limiting forms of QCD matter which may be produced at RHIC. We conclude from the available empirical evidence that an equilibrated, but strongly coupled Quark Gluon Plasma has been made in such collisions. We also discuss the growing body of evidence that its source is a Color Glass Condensate.

#### 1 Introduction

Thirty years ago[1], T.D. Lee suggested that it would be interesting to explore new phenomena "by distributing high energy or high nucleon density over a relatively large volume." In this way one could temporarily restore broken symmetries of the physical vacuum and possibly create novel abnormal dense states of nuclear matter[2]. W. Greiner and collaborators pointed out that the required high densities could be achieved via relativistic heavy ion collisions[3]. Concurrently, Collins and Perry and others[4] realized that the asymptotic freedom property of Quantum Chromodynamics (QCD) implies the existence of an ultra-dense form of matter with deconfined quarks and gluons, called later the Quark-Gluon Plasma (QGP)[5]. In 1982 J.D. Bjorken developed a relativistic hydrodynamic theory[6] of the novel "inside-out" evolution of the central low baryon density regions of ultra-relativistic heavy ion collisions. While many signatures of QGP formation were proposed, he suggested that "if the quark-gluon plasma is produced, it will manifest itself in experimental signatures as yet unforeseen. The system is after all a complicated relativistic fluid subject to highly nonlinear forces. . . . . If very interesting and novel phenomena will be seen in ion-ion collisions, theory must develop the capability to interpret them, if not to predict them".

With this theoretical background, the 1983 DOE/NSAC Long Range Plan set in motion plans that led to the construction of the Relativistic Heavy Ion Collider (RHIC) [7] to explore properties of ultra-dense matter above the deconfinement transition point. Now, after its first three years of operation, a vast data base[8] on p + p, D + Au, and Au + Au at  $\sqrt{s} = 20 - 200$  AGeV has been harvested from RHIC. The published data are available through 22 (4 PRL) publications from BRAMHS[9], 92 (15 PRL) from PHENIX[10], 34 (6 PRL) from PHOBOS[11], and 127 (21 PRL) from STAR[12]. This body of data extends and builds upon the knowledge gained about dense hadronic matter measured at the SPS/CERN (publications include 108 NA49/35, 69 NA50/38, 26

CERES/NA45, 79 WA98/80, 32 na57/wa97) at √ s ≤ 20 AGeV The SPS heavy ion data already displayed several signatures that hinted at the onset of QGP formation[[13\]](#page-29-0). Based on the SPS data and theoretical predictions, RHIC with its factor of 10 increase in the center of mass energy to 200 AGeV was assured to create matter well above the deconfinement transition point. The fourth year run of RHIC with Au+Au at 200 AGeV has just concluded with a gain of about another factor ∼ 20 integrated luminosity (∼ 1400/µb). These and future RHIC data with significantly upgraded detectors will provide even higher resolution measurements of the detailed properties of the new forms of matter discovered at RHIC.

While there naturally remain many open questions and unsolved puzzles, a striking set of new phenomena have been conclusively discovered at RHIC. Those phenomena furthermore can now be readily interpreted and predicted from significant advances in theory and from the empirical information gained from the past 30 years from the Bevalac, SIS, AGS, and SPS experiments.

In this report, we discuss[\[14](#page-29-0), [15\]](#page-30-0) the evidence that at least one and possibly two new forms of QCD matter have been discovered at RHIC. We consider the Quark Gluon Plasma, which is a form of matter characterized by a thermal equilibrium density matrix of a system of quarks and gluons. We also consider the Color Glass Condensate (CGC), which is a form of matter characterized by a universal initial density matrix which describes high energy strongly interacting particles including nuclei. The QGP is the incoherent thermal limit of QCD matter at high temperatures while the CGC is the coherent limit of QCD at high energies. Since the QGP has to be created at RHIC from the interaction of initial nuclear enhanced coherent chromo electric magnetic fields, both limiting forms of QCD matter need to be considered at RHIC.

The first 275 published experimental papers from RHIC have of course only barely scratched the surface of the new physics of these forms of matter, but the data are so striking and decisive that several strong physics conclusions can already be drawn. They establish empirically that a special form of strongly coupled QGP (sQGP) exists with remarkable properties. In addition, there is growing evidence that its source is well described by a saturated gluon CGC initial state. These RHIC discoveries and those at the SPS/CERN pave a clear path for future systematic studies of these new forms of matter in the laboratory.

We begin in section 2 by describing the basic ingredients of the QGP hypothesis. The hypothesis concerning the existence and properties of this form of matter has a firm basis in QCD. Much is known about its theoretical properties on the basis of numerical computation within QCD (lattice gauge theory). In section 3 we review the CGC hypothesis, which is newer but is also based firmly in QCD. The CGC hypothesis can be tested in a wide range of experimental environments (HERA, RHIC,LHC,eRHIC) not restricted to heavy ion collisions. It is newer, and because of this, somewhat more tenuous than is the QGP hypothesis.

The scientific method is based on the paradigm that theories are tested by falsification. This is an important concept, since simple models with many adjustable parameters are often used to "fit" heavy ion data. However, one of the most compelling motivations for extending studies of heavy ion physics into the ultra-relativistic RHIC energy frontier √ s ∼ 20 − 200 AGeV, is that predictions, based on the QCD theory itself, of new physics under extreme conditions of temperature and energy can be tested. For RHIC and higher energies controlled QCD theoretic approximations and methods have been developed that are applicable to a wide class of observables.

At lower energies, BEVALAC, SIS, AGS, and SPS, the physics of nuclear collisions is now known to be dominated by the non-equilibrium dynamics of the confined intermediate phase of QCD, known as hadronic resonance matter[[16](#page-30-0)]. Unfortunately, even lattice QCD methods are not yet powerful enough to predict the dynamics or thermodynamics of this intermediate form of matter. For low temperature nuclear matter, effective quantum hadro-dynamic theories (QHD, Chiral Perturbation Theory) have successfully been constructed incorporating the known (Lorentz and Chiral) symmetries of QCD. However, at moderate temperatures where matter is in the hadron resonance excitation region (below the deconfinement temperature) no quantitative theory yet exists. This handicaps the interpretation of data at such lower energies in terms of fundamental QCD properties. Many phenomenological hadronic dynamical models have been advanced to help interpret data at lower energies, but as yet they have not evolved into a consistent effective theory. The existing huge data base from lower energies provides valuable information for further development of such an effective theory. However, RHIC energies provide for the first time the possibility of exploring a qualitatively new kinematic regime where the uncertainties due to our as yet incomplete understanding of the intermediate hadronic resonance phase of QCD may be minimized.

The case that we present in this report, based on the published data from RHIC, about the Quark Gluon Plasma and the Color Glass Condensate is predicated by the firm root of these concepts in first principles in QCD. As such, these concepts must be tested thoroughly through a wide array of observables to see whether they are consistent with available measurements, and that they are robust in their predictions. It was a priori not at all obvious whether any observables exist at RHIC that can be described quantitatively by the QGP or CGC concepts. This is where a healthy bit of experimental "luck" was essential in order to find the "needles in the haystack" that are least distorted by uncertain non-equilibrium hadronic final state dynamics. We make the case in this report that a few sharp needles have been found through three convergent lines of empirical evidence that point to the discovery of a new strongly coupled QGP and its source, the saturated CGC.

It is also important to understand when an approximation to the QCD theory breaks down. Only special limits of QCD can be quantitatively predicted at this time: (1) long wavelength QCD thermodynamics, (2) very short wavelength pQCD, and (3) very high energy CGC coherence. New quark coalescence techniques are being developed to address the intermediate wavelength observables. Any breakdown of a given approximation must be understood for solid reasons. One case in point is applying the QGP hypothesis to observables (such as radial flow) which are strongly influenced by the uncertain late time dynamics of hadronic matter in heavy ion collisions. Another case is at the earliest formation times, when the description changes between the initial coherent CGC and the produced thermal QGP. In the latter case, one needs to determine directly from careful control experiments, which approximation to QCD is better suited to the phenomena under study. In this report we will discuss both the strengths and limitations of the present theoretical understanding of the RHIC discoveries.

# 2 What is the Quark Gluon Plasma?

Quantum Chromodynamics (QCD) predicts the existence of a deconfined form of matter called a Quark Gluon Plasma (QGP), in which the quark and gluon degrees of freedom normally confined within hadrons are mostly liberated[\[4\]](#page-29-0). This transition occurs when the energy density of matter is of the order of that of matter inside a proton. This density is about an order of magnitude larger than the energy density inside of atomic nuclei, that is about 1 <sup>−</sup> <sup>10</sup> GeV /fm<sup>3</sup> .

<span id="page-3-0"></span>To get a more accurate determination of the energy of this transition to a Quark Gluon Plasma, QCD can be numerically studied using numerical methods[17]-[20]. Such computations show that there is a rapid rise of the energy density,  $\epsilon(T)$ , of matter when the temperature reaches  $T \approx T_c \sim 160$  MeV. The energy density changes by about an order of magnitude in a narrow range of temperatures  $\Delta T \sim 10-20$  MeV as can be seen from Fig. 1.

![](_page_3_Figure_1.jpeg)

Figure 1: (a) The energy density as a function of temperature scaled by  $T^4$  from lattice QCD [17]. Various number of species of quarks are considered. The realistic case is for 2+1 flavors. An estimate of the typical temperature reached at SPS and RHIC, and estimated for LHC is included in the figure.(b) The pressure as a function of temperature scaled by  $T^4$ . Note that the pressure is continuous in the region where there is a sharp change in the energy density.

One can understand this transition as a change in the number of degrees of freedom of the system. Far below  $T_c$ , the active hadronic degrees of freedom are limited to three, corresponding to a dilute gas of 3 charge states of pions. Above  $T_c$ , 8 colors of gluons times two helicity degrees of freedom become activated. In addition, there are  $N_f(T) \approx 2-3$  active light flavors of quarks (for T not far above  $T_c$ ). Each flavor has equal number of quarks and antiquarks when the chemical potentials vanish, and each have two spin states and three colors. Therefore, there are  $g_{q\bar{q}}(T) \approx 24-36$  quark degrees of freedom in a QGP. In the quark gluon plasma phase, there are then about 40 - 50 internal degrees of freedom in the temperature range  $(1-3)T_c$ , while the low temperature and vanishing chemical potentials the pion gas has 3. Since the energy density, pressure and entropy are all roughly proportional to the number of degrees of freedom, one understands this rapid change in the energy density over a narrow range of temperature as a change in the degrees of freedom between the confined and deconfined worlds.

The system above  $T_c$  is called a plasma because the degrees of freedom carry the non-Abelian analog of charge as in ordinary plasmas. Just as there are different regimes of ordinary plasmas, the QGP plasma also has weakly coupled and strongly coupled limits. At extremely high temperatures, the asymptotic freedom property of QCD predicts that it will be weakly coupled[4]. For moderate temperatures  $(1-3)T_c$  accessible at RHIC, on the other hand, the plasma is predicted by nonperturbative lattice techniques to be strongly coupled - even though the thermodynamic variables are near the ideal Stefan Boltzmann limit. Thus, nonperturbative correlations beyond

dielectric phenomena persist in the QGP well beyond  $T_c$ .

The transition between the confined hadronic world and the deconfined QGP world may or may not be a phase transition in the strict statistical mechanical sense. Strictly speaking, a phase transition requires a mathematical discontinuity in the energy density or one of its derivatives in the infinite volume limit. The QGP transition may in fact be a "crossover", or rapid change, as is suggested numerical computation and a number of theoretical arguments. Nevertheless, the change as measured in numerical computation is very abrupt as seen in Fig. 1.

We shall refer to matter in the transition region as a "mixed phase". If there were a strict statistical mechanical first order phase transition, then matter in this region would be a mixture of hadronic gas phase and quark gluon plasma domains, as is the case when there is phase coexistence between water and ice. If there is a rapid crossover, then many of the bulk properties of the system, which are determined by the relation between energy density and pressure, are to a good approximation similar to those when there is a strict phase transition.

In the transition region, the energy density changes by roughly an order of magnitude, but the pressure is continuous and varies slowly. The sound velocity,  $c_S^2 = dP/d\epsilon$  must therefore become very small in this range of energy densities[18, 19]. It is very difficult to generate pressure gradients and do mechanical work in the mixed phase region, since as we vary the energy density we generate little change in pressure. We will call a relation between energy density and pressure (an equation of state) stiff when the sound velocity is big ( $c_s$  of order the speed of light) and soft when it is small. The quark gluon plasma equation of state is stiff at high temperature, but becomes soft near  $T_c$ . The sound velocity as a function of temperature as determined by numerical computation is shown in Fig. 2a. It is expected that hadronic matter again becomes stiffer below  $T_c$ , and eventually softens as the temperature tends to zero. Unfortunately, lattice QCD is still not powerful enough to predict accurately the thermodynamic properties of hadronic matter below  $T_c$ . Preliminary results[21] (still with rather large pion mass  $\sim 700$  MeV) are roughly consistent with a heavy hadronic resonance gas equation of state, but the thermodynamics of the confined phase of QCD remains an open problem. This fact again underscores the necessity of concentrating on those (few) observables that are least influenced by the poorly known hadronic phase dynamics.

The relationship between the energy density and pressure determines the evolution of matter from a given initial condition IF local equilibrium is maintained. This then can determine experimentally by measuring "barometric" observables. The softening of the QGP equation of state near  $T_c$  is the key feature that can be looked for in the collective hydrodynamic flow patterns produced when the plasma expands.

Another distinctive feature of the QGP phase diagram is shown in the right panel in Fig.(2). Recent numerical calculations[20] have begun to show evidence that the QGP may have a phase transition in the strict statistical mechanical sense, if one also allows the system to have a high baryon number density as well as high temperature. [22, 23] In the plot on the right hand side of Fig. 2, the possible phases of QCD are shown as a function of both temperature and a measure of the baryon number density,  $\mu_B$ . At low baryon number density, there is probably a rapid crossover from the low density hadronic world to that of the quark gluon plasma. At higher baryon number density, there is quite likely a first order phase transition. The computations on this issue are still work in progress and extrapolation to realistic quark masses are very difficult, so the position of the endpoint of first order phase transitions is still rather uncertain. There is an ongoing program at the SPS concentrating on lower energies to search for possible signatures of high baryon density quark plasma transition.

<span id="page-5-0"></span>![](_page_5_Figure_0.jpeg)

Figure 2: Important features of the QGP equation of state. (a) The speed of sound[18, 19]  $c_s^2 = d\epsilon/dP$  drops below 1/3 for  $T < 2T_c \approx 300$  MeV. (b) Right panel shows a current estimate of the location of the tri-critical point at finite baryon density[20]

The quark gluon plasma has the property that quarks and gluons are no longer confined inside of hadrons. This is unlike zero temperature and baryon number density QCD. The transition between the confined and deconfined world may provide us insights into the nature of confinement.

In the QCD equations of motion the small mass of the "light" u,d quarks can be neglected and the system possesses a special chiral symmetry. This chiral symmetry prevails at high temperature, in spite of the fact that quarks acquire a collective dynamical mass  $\sim gT$  as do gluons. Below  $T_c$ , not only do quarks and gluons become confined into hadrons, but the chiral symmetry of QCD is also broken as manifested by the appearance of the 3 light pion degrees of freedom while the quarks are bound in heavy nucleons.

The Quark Gluon Plasma is important to search for at RHIC because:

- It is the ultimate, primordial form of QCD matter at high temperature or baryon number density (at least up to the electro weak scale at about  $T_{EW} \sim 10^3 T_c$ ).
- It was present during the first few microseconds of the Big Bang according to current cosmology.
- It may occur naturally in supernovae, gamma ray bursts and neutron stars as matter at high baryon number density and relatively low temperature.
- It provides an example of phase transitions which may occur at a variety of higher temperature scales in the early universe.
- It may provide us important information concerning the origin of mass for matter, and how quarks are confined into hadrons.

# 3 What is the Color Glass Condensate?

The ideas for the Color Glass Condensate are motivated by HERA data on the gluon distribution function shown in Fig. 3(a) [24]. The gluon density,  $xG(x,Q^2)$ , rises rapidly as a function

![](_page_6_Figure_2.jpeg)

Figure 3: (a) The HERA data for the gluon distribution function as a function of x for various values of  $Q^2$ . (b) A physical picture of the low x gluon density inside a hadron as a function of energy

of decreasing fractional momentum, x, or increasing resolution, Q. This rise in the gluon density ultimately owes its origin to the non-Abelian nature of QCD and that the gluons carry color charge. At higher and higher energies, smaller x and larger Q become kinematically accessible. The rapid rise with  $\log(1/x)$  was expected in a variety of theoretical works[25]-[27]. Due to the intrinsic non-linearity of QCD, gluon showers generate more gluon showers - producing an exponential avalanche toward small x. The physical consequence of this exponential growth is that the density of gluons per unit area per unit rapidity of any hadron including nuclei must increase rapidly as x decreases [28]. This follows because the transverse size, as seen via the total cross sections, rise more slowly at high energies than the number of gluons. This is illustrated in Fig. 3(b). The non-linearity of gluon interactions, however, led to the conjecture that the transverse density of gluons measured at some fixed  $Q^2$  resolution scale should eventually become limited , that is, there is gluon saturation at sufficiently high energies. [25]-[26], [28]

The low x gluons are closely packed together in the transverse direction, therefore, as in the thermal case at extreme temperatures or chemical potentials, the strong interaction strength must become weak,  $\alpha_S \ll 1$ . Weakly coupled systems should be possible to understand from first principles in QCD [28].

This dense but weakly coupled system is called a Color Glass Condensate for reasons we now enumerate:[29]

- Color The gluons which make up this matter are colored.
- Glass The gluons at small x are generated from gluons at larger values of x. In the infinite momentum frame, these larger momentum gluons travel very fast and their natural time scales are Lorentz time dilated. This time dilated scale is transferred to the low x degrees of freedom which therefore evolve very slowly compared to natural time scales. This is the property of a glass.
- Condensate The dimensionless transverse phase space density

$$\rho = \frac{1}{\pi R^2} \frac{dN}{dud^2 p_T} \tag{1}$$

saturates at a value  $\rho = c/\alpha_S(Q_s)$ , where c is a constant of order unity. Saturation is due to the competition between extra gluon radiation originating from the source current,  $\propto \rho$ , and non-linear gluon fusion,  $\propto -\alpha_S \rho^2$ , that reduces the number of gluons at high density.

Because  $\alpha_S \ll 1$ , this means that the quantum mechanical states of the system associated with the condensate are multiply occupied. They are highly coherent, and share some properties of Bose condensates. The gluon occupation factor is very high, of order  $1/\alpha_S$ , but it is only slowly (logarithmically) increasing when further increasing the energy, or decreasing the transverse momentum. This provides saturation and cures the infrared problem of the traditional BFKL approach [30].

There is a critical momentum scale,  $Q_s(x,A)$ , which controls the occupation number through  $1/\alpha_S(Q_s)$ . This is called the CGC saturation scale. The transverse phase space density,  $\rho$ , is constant only up to  $p_T < Q_s(x,A)$ . For wavelengths,  $1/p_T$ , much smaller than  $1/Q_s$ , the coupling becomes even weaker and perturbative QCD predicts that  $\rho \propto \alpha(p_T)/(R^2p_T^2)$ .

Note that  $Q_s$  plays a role in the CGC form of matter similar to what  $T_c$  plays in the QGP form of matter. Both delineate two different phases of matter. However, in the QGP case, the critical scale,  $T_c \sim \Lambda_{QCD}$ , is small and the matter on both sides of the transition remain in the strong coupling sector of QCD! In the CGC case, on the other hand, it is possible to find kinematic regimes of x that depend on A, where the CGC can be weakly coupled but in nonlinear regime due to high occupation numbers.

The crux of the search for the CGC therefore is to locate those kinematic regimes where the corrections to the weak coupling methods can be controlled. The non-linear dependence of  $Q_s$  on x and A will be discussed further in section 6. We note here only that both as x becomes small and A becomes large,  $Q_s$  grows. The saturation momentum itself does not saturate. The gluon distribution function for resolution scale  $Q \leq Q_s$  grows slowly and saturates, while the gluon distribution function for  $Q \geq Q_s$  grows rapidly. The physics is easy to understand: As more gluons are added to the hadron, they have to go to the unsaturated region since the saturated region is already densely packed.

The Color Glass Condensate is important to search for at RHIC because:

- It represents the universal form of high energy QCD wavefunctions at small x, not only of hadrons but heavy nuclei as well.
- It is a new form of matter because the gluons inside the hadron are separated by distance scales small compared to the hadron size, they evolve on time scales long compared to microphysics time scales, and the CGC itself is specified by a special new density matrix that encodes the non-linear virtual fields of QCD in the high energy limit.

- <span id="page-8-0"></span>• It already begins to become important at  $x \sim 10^{-2}$  in protons at HERA, and and should begin to become important at comparable values of x at RHIC.
- It provides a rigorous QCD theoretical description of the initial state in A + A from which the QGP must evolve.
- It can be tested directly at RHIC via p + A or D + A, where no final state interactions and hence no QGP formation can occur.

# 4 The Space-Time Picture of Ultra-Relativistic Nuclear Collisions

Heavy ion collisions at ultrarelativistic energies are visualized in Fig. 4 as the collision of two sheets of colored glass.[31] The nuclei appear as sheets at ultrarelativistic energies because of Lorentz contraction. The CGC gluons are shown as vectors which represent the polarization of the gluons, and by colors corresponding to the various colors of gluons.

At ultrarelativistic energies, these sheets pass through one another. In their wake is left melting colored glass, which eventually materializes as quarks and gluons. These quarks and gluons would naturally form in their rest frame on some natural microphysics time scale. For the saturated color glass, this proper formation time scale,  $\tau_0$ , is of order the inverse saturation momentum. At RHIC,  $1/Q_s \sim 0.2$  fm/c  $\sim 5 \times 10^{-25}$  sec. Note that 0.2 fm/c is also comparable to the natural crossing time of two 10 fm nuclei, each contracted by a gamma factor 100, in the center of mass frame at RHIC. For particles with a large momentum or rapidity along the beam axis, this time scale is Lorentz dilated. This means that the slow (smaller rapidity) particles are produced first towards the center of the collision regions and the fast (larger rapidity) particles are produced later further away from the collision region.

![](_page_8_Picture_6.jpeg)

Figure 4: The collision of two sheets of colored glass. The arrows represent the polarization vectors for the gluons which live on the sheets, and their colors correspond to the different colors of gluons

This Bjorken "inside-out" correlation[6] between space and momentum is similar to what happens to matter in Hubble expansion in cosmology. The stars which are further away have larger

outward velocities. This means that the matter produced at RHIC, like the universe in cosmology is born expanding. One important difference is that the "mini-bang" at RHIC is born with one dimensional Hubble flow along the collision axis, while the Big-Bang is three dimensional. This is shown in Fig. 5

![](_page_9_Picture_1.jpeg)

Figure 5: Particles being produced after the collision of two nuclei.

As this system expands, it cools. On some time scale  $\tau_{eq} > \tau_0$  the produced quarks and gluons may thermalize. It is by no means obvious that local equilibrium can be reached on the short time scale  $\sim (1-2)R/c \sim 10$  fm/c available in nuclear collisions. IF local equilibrium is reached early with  $\tau_{eq} < 1$  fm/c, then the QGP can develop collective flow according to the laws of hydrodynamics. In any case, when the energy density decreases due to expansion below about 1 GeV/fm<sup>3</sup>, the QGP must begin to hadronize through some mixture of hadrons and quarks and gluons. Eventually, all the quarks and gluons must become confined into hadrons that may still interact as hadronic matter before being detected.

The particle multiplicity as a function of energy has been measured at RHIC[32], as shown in Fig. 6. Combining the multiplicity data together with the measurements of transverse energy or of typical particle transverse momenta, one can determine the energy density of the matter when it decouples.[33] One can then extrapolate backwards in time using 1 dimensional (Bjorken) expansion, since decoupling occurs soon after the matter begins to expands three dimensionally. We can extrapolate backwards only until  $\tau_0$ , when the matter is formed from the "shattered" Color Glass.

To do this extrapolation we use that the proper density of particles falls as  $N/V \sim 1/\tau$  during 1 dimensional expansion. If the particles expand without interaction and work, then the energy per particle remains constant (and  $E/V(\tau_0) \approx (dE_T/dy)/(\tau_0\pi R^2)$  in terms of the final observed transverse energy per unit rapidity). If the particles thermalize, then  $E/N(\tau) \sim 3T(\tau)$ , and the entropy rather than the energy per particle remains constant. For a massless gas, the temperature then falls as  $T \sim \tau^{-1/3}$ . For a gas which is not massless or not in perfect equilibrium, the temperature falls somewhere in the range  $T_o > T(\tau) > T_o(\tau_{eq}/\tau)^{1/3}$  This 1 dimensional expansion

# <span id="page-10-0"></span>| A | PHOBOS 200 GeV | PHOBOS 200 GeV | PHOBOS 200 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOBOS 56 GeV | PHOB

Figure 6: The particle multiplicity as a function of c.m. energy,  $\sqrt{s}$ , per nucleon pair at RHIC[32] and lower AGS and SPS energies.

continues until the system begins to feel the effects of finite size in the transverse direction, and then rapidly cools through three dimensional expansion. We shall take a conservative overestimate of this time to be of order  $t_0 \sim 0.3$  fm/c The extrapolation of the energy density backwards is bounded by  $\epsilon_f(t_f/t) < \epsilon(t) < \epsilon_f(t_f/t)^{4/3}$ . The lower bound is that assuming that the particles do not thermalize and their typical energy is frozen. The upper bound assumes that the system thermalizes as an ideal massless gas. These bounds on the energy density is shown in Fig. 7. On the left axis is the energy density and on the bottom axis is time. The system begins as a coherent Color Glass Condensate, then melts to Quark Gluon Matter which may eventually thermalize to a Quark Gluon Plasma. At a time  $\sim 3fm/c$ , the plasma becomes a mixture of quarks, gluons and hadrons which further expand together.

At a time of about  $10 \ fm/c$ , the system falls apart and decouples. At a time of  $t \sim 1 \ fm/c$ , the estimate we make is identical to the Bjorken energy density estimate, and this provides a lower bound on the energy density achieved in the collision. (All estimates agree that by a time of order  $1 \ fm/c$ , matter has been formed.) The upper bound corresponds to assuming that the system expands as a massless thermal gas from a melting time of .3 fm/c. (If the time was reduced, the upper bound would be increased yet further.) The bounds on the initial energy density are therefore

$$2 - 3 \ GeV/fm^3 \lesssim \epsilon \lesssim 20 - 30 \ GeV/fm^3 \tag{2}$$

where we included a greater range of uncertainty in the upper limit because of the uncertainty associated with the formation time. The energy density of nuclear matter is about  $0.15 \; GeV/fm^3$ ,

<span id="page-11-0"></span>![](_page_11_Figure_0.jpeg)

Figure 7: Bounds on the energy density as a function of time in heavy ion collisions.

and even the lowest energy densities in these collisions is in excess of this. At late times, the energy density is about that of the cores of neutron stars,  $\epsilon \sim 1~GeV/fm^3$ .

We conclude that based on the observed multiplicity at RHIC alone, the initial energy densities achieved in RHIC collisions can be high enough to produce a quark gluon plasma.

# 5 Empirical Evidence for QGP at RHIC

In this section, we discuss RHIC data which show that the matter produced in central collisions in RHIC becomes well thermalized, and behaving in a way consistent with theoretical expectations from QCD.

#### 5.1 Collective Flow

The identification of a new form of "bulk matter" requires the observation of novel and uniquely different collective properties from ones seen before. In heavy ion reactions the flow pattern of thousands of produced hadrons is the primary observable used to look for novel collective

phenomena[3], [34]- [37]. The collective flow properties test two of the conditions necessary for the validity of the QGP hypothesis.

The first is the degree of thermalization. Nothing is yet known from lattice QCD about far off equilibrium dynamics of a QGP. However, the evolution of matter from some initial condition can be computed via the equations of viscous relativistic hydrodynamics if local equilibrium is maintained. These equations can be further approximated by perfect (Euler) fluid equations when the corrections due to viscosity can be neglected. Such viscous corrections can be neglected when scattering mean free paths are small compared to the scale of spatial gradients of the fluid.

The second condition is the validity of the numerically determined equation of state or relationship between energy density and pressure. The required input for perfect fluid hydrodynamical equations is the equation of state. With a specific initial boundary condition, the future evolution of the matter can be then predicted. We shall show that the data on elliptic flow confirms the idea that to a very good approximation, local thermal equilibrium is reached at RHIC energy and that the flow pattern is entirely consistent with numerical determinations of the equation of state from QCD.

The different types of collective flows are conveniently quantified in terms of the first few Fourier components of the azimuthal angle (angle around the beam axis for the collision) distribution. [38, 39],  $v_n(y, p_T, N_p, h)$ , of the centrality selected triple differential inclusive distribution of hadrons, h. The centrality or impact parameter range is usually specified by a range of associated multiplicities, from which the average number of participating nucleons,  $N_p$ , can be deduced. The azimuthal angle of the hadrons are measured relative to a globally determined estimate for the collision reaction plane angle  $\Phi(M)$ . The "directed"  $v_1$  and "elliptic"  $v_2$  flow components [37]-[39], [40]-[47] are readily identified from azimuthal dependence

$$\frac{dN_h(N_p)}{dydp_T^2d\phi} = \frac{dN_h(N_p)}{dydp_T^2} \frac{1}{2\pi} (1 + 2v_1(y, p_T, N_p, h) \cos \phi + 2v_2(y, p_T, N_p, h) \cos 2\phi + \cdots) .$$
(3)

The first term in the above equation also contains information about flow. Produced particles should have their momentum spectrum broadened in heavy ion collisions relative to the case for proton-proton collisions. Because flow is due to a collective velocity, the flow effects should be largest for the most massive particles, and therefore the mass dependence is a powerful diagnostic tool.

Figure (8) shows the striking bulk collectivity elliptic flow signature of QGP formation at RHIC. Unlike at SPS and lower energies, the observed large elliptic deformation  $((1+2v_2)/(1-2v_2) \sim 1.5)$  of the final transverse momentum distribution agrees for the first time with non-viscous hydrodynamic predictions [48]-[60] at least up to about  $p_T \sim 1$  GeV/c. However, the right panel shows that when the local rapidity density per unit area [40, 41] drops below the values achieved at RHIC  $\sim 30/\text{fm}^2$ , then the elliptic flow (scaled by the initial spatial ellipticity,  $\epsilon = \langle (y^2 - x^2)/(y^2 + x^2) \rangle$ ) falls below the perfect fluid hydrodynamic predictions. We will discuss in more detail the origin of the large discrepancy at SPS energies in the next section.

The most impressive feature in Fig.(8) is the agreement of the observed hadron mass dependence of the elliptic flow pattern for all hadron species,  $\pi, K, p, \Lambda$ , with the hydrodynamic predictions below 1 GeV/c. This is the QGP fingerprint that shows that there is a common bulk collective azimuthally asymmetric flow velocity field,  $u^{\mu}(\tau, r, \phi)$ . Such good agreement with the hadron mass dependence of the  $v_2(p_T, m_h)$  data is furthermore only found when the input equation

<span id="page-13-0"></span>![](_page_13_Figure_0.jpeg)

Figure 8: First line of evidence: Bulk collective flow is the barometric signature of QGP production. Left figure combines STAR [43]-[46] and PHENIX [47] measurements of the azimuthal elliptic flow  $(v_2(p_T))$  of  $\pi, K, p, \Lambda$  in Au+Au at 200 AGeV. The predicted hydrodynamic flow pattern from [48]-[52] agrees well with observations in the bulk  $p_T < 1$  GeV domain. Right figure from [41] shows  $v_2$  scaled to the initial elliptic spatial anisotropy,  $\epsilon$ , as a function of the charge particle density per unit transverse area. The bulk hydrodynamic limit is only attained at RHIC.

of state has the characteristic "softest point" near  $T_c$  as predicted by lattice QCD [48]-[60]. When equations of state without the predicted drop of speed of sound near  $T_c$  were used as input, the flow velocity field, especially that of the heavy baryon, was over estimated.

The flow velocity and temperature fields of a perfect (non-viscous) fluid obeys the hydrodynamic equations:

$$\partial_{\mu} \left\{ \left[ \epsilon_{QCD}(T(x)) + P_{QCD}(T(x)) \right] u^{\mu}(x) u^{\nu}(x) - g^{\mu\nu} P_{QCD}(T(x)) \right\} = 0 , \tag{4}$$

where T(x) is the local temperature field,  $P_{QCD}(T)$  is the QGP equation of state, and  $\epsilon_{QCD}(T) = (TdP/dT - P)_{QCD}$  is the local proper energy density. The above equations apply in the rapidity window |y| < 1, where the baryon chemical potential can be neglected. Eq.(4) provides the barometric connection between the observed flow velocity and the theoretical properties of the QGP.

We note that in any hydrodynamic treatment of collective flow there is a tradeoff between the combined effects due to the initial state boundary condition, the equation of state of the matter, and dissipation effects. In order to use the flow pattern to constrain the equation of state the initial condition must be constrained from other measurements and dissipation must be negligible. Here is where the measurements of the global multiplicity systematics [32, 33] are so important. The remarkably weak energy and centrality dependence of the bulk entropy observed via the dNdy plays a pivotal role as perhaps the most convincing test of the CGC initial condition hypothesis

<span id="page-14-0"></span>![](_page_14_Figure_0.jpeg)

Figure 9: Left figure shows the pseudo rapidity dependence of elliptic from PHOBOS [62]. Right figure is CERES[63] data on elliptic flow at SPS. It is well below hydrodynamic predictions with freeze-out  $T_f = 120$  MeV required to reproduce the single inclusive radial flow. Early freeze-out with  $T_f = 160$  MeV, simulating effects of dissipation, is needed to reproduce the data.

at RHIC[61]. Without such an experimental and theoretical constraint on the initial condition no meaningful constraint on the QGP equation of state could have been found.

The study of the interplay between the equation of state and dissipative phenomena is more difficult and can only be untangled through detailed systematics of the flow pattern as a function of beam energy, centrality, and rapidity dependence. Here the detailed systematics from AGS and SPS data have played a pivotal role in helping sorting out the different viscous effects in hadronic and QGP matter as we discuss in the next section.

Why is  $v_2$  more emphasized than  $v_1$  or radial flow as a signature of QGP formation? The primary reason is that elliptic flow is generated mainly during the highest density phase of the evolution before the initial geometric spatial asymmetry of the plasma disappears. It comes from the azimuthal dependence of the pressure gradients, which can be studied by varying the centrality of the events [39]. Detailed parton transport [64] and hydrodynamic [54] calculations show that most of the  $v_2$  at RHIC is produced before 3 fm/c and that elliptic flow is relatively insensitive to the late stage dissipative expansion of the hadronic phase. The reason for the generation of  $v_2$  at relatively early times is that it is very difficult to convert the spatial anisotropy of the matter distribution into a momentum space anisotropy once the system cools into the mixed phase, since in the mixed phase pressure gradients cannot be set up. Actually, it was a surprise how well the observed collective flow agrees with perfect fluid hydrodynamic predictions. Ideal fluid flow requires very strong interactions of the quarks and gluons in the plasma at early times  $\tau \gtrsim \tau_{eq} \approx 0.6$  fm/c.

In contrast, radial flow has been observed at all energies [65] and has been shown to be mainly sensitive to late time "pion wind" radial pressure gradients [16, 66], which continue to blow long after the QGP condenses into hadronic resonances.

#### 5.2 The Breakdown of Bulk Collectivity

It is important to point out that no detailed 3+1D hydrodynamic calculation [\[56](#page-31-0)]-[[60\]](#page-31-0) has yet been able to reproduce the rapid decrease of v2(|η| > 1) observed by PHOBOS in Fig.[\(9\)](#page-14-0). This is most likely due to the increasing role hadronic dissipation effects in the "corona" when the comoving density decreases with increasing y. The volume of the QGP shrinks while the hadronic corona thickens as the rapidity density dN/dy is reduced within a fixed nuclear geometry away from midrapidity. From the right panel of Fig.([8](#page-13-0)), we see that a decrease of the local transverse density from midrapidity RHIC conditions leads to an increasing deviation from the perfect fluid limit. The initial density was also observed to decrease at RHIC as |y| increases [\[67](#page-32-0)]. Therefore, from the known SPS data, we should expect deviations from the perfect fluid limit away from the midrapidity region.

Another set of RHIC data that show deviations from perfect fluid hydrodynamic predictions is the centrality dependence of v2. The observed v2(b) decreases relative to hydrodynamic predictions also when the impact parameter increases toward the more peripheral collisions. This is again due to the fact that the produced multiplicity, dN/dy ∝ Np(b), decreases with increasing b. The hadronization time decreases with b since the QGP is formed with smaller initial density and the hadronic fluid is less efficient in transferring pressure into collective flow.

To elaborate further on this important point, Fig.[9](#page-14-0) shows CERES data[[63\]](#page-32-0) on v2(p<sup>T</sup> ) at SPS energy √ s = 17 AGeV. In agreement with the NA49 data shown in the right panel of Fig.([8](#page-13-0)), the CERES data falls well below the hydrodynamic predictions. At even lower energies, AGS and BEVALAC, the v2 even becomes negative and this "squeeze out" of plane [\[36](#page-30-0)] is now well understood in terms of low energy non-equilibrium nuclear transport theory[[42,](#page-31-0) [68](#page-32-0)].

In order to account for the smallness of v2 at SPS, hydrodynamics has to be frozen out at unphysically high densities and temperatures, T<sup>f</sup> ≈ Tc. However, the observed radial flow rules out this simple fix. The reduction of v2 while maintaining radial flow can be approximately understood in approaches [\[54](#page-31-0)] that combined perfect fluid QGP hydrodynamics with dissipative final state hadronic evolution.

In light of the above discussion on the breakdown of collectivity due to hadronic dissipation at high rapidity and large impact parameters at RHIC and even at midrapidity at SPS and lower energies, the smallness of dissipative corrections in the central regions of RHIC is even more surprising. At mid-rapidities, the lack of substantial dissipation in the QGP phase is in itself a remarkable and unexpected discovery [\[69\]](#page-32-0) at RHIC. Calculations based on parton transport theory [\[64](#page-32-0)] predicted large deviations from the ideal non-viscous hydrodynamic limit even in a QGP. Instead, the data show that the QGP at RHIC is almost a perfect fluid. A Navier Stokes analysis[[55\]](#page-31-0) of the RHIC data also indicates that the viscosity of the QGP must be about ten times smaller than expected if the QGP were a weakly interactive conventional Debye screened plasma. This unexpected feature of the QGP must be due to strong coupling QCD physics that persists to at least 3Tc. (See [\[14](#page-29-0), [69, 70](#page-32-0)] and refs therein for further discussion).

Summarizing this section: Elliptic flow measurements confirm that the quarkgluon matter produced at RHIC is to a very good approximation in local thermal equilibrium up to about 3 fm/c. In addition, the final hadron mass dependence of the flow pattern is remarkably consistent with numerical QCD computations of the equation of state. Viscous corrections furthermore appear to be surprisingly small during this early evolution. The produced Quark Gluon Plasma must therefore be very strongly interacting. Such behavior was not seen at lower energy because the highly dissipative hadronic fluid component masked the QGP flow signals. The perfect fluid behavior is also masked at RHIC at higher rapidities and in more peripheral reactions again due to the increased role of the dissipative hadronic "corona".

#### 5.3 Perturbative QCD and Jet Quenching

In addition to the breakdown of perfect fluid collectivity at high rapidity seen in Fig.(9), Fig.(8) clearly shows that hydrodynamics also breaks down at very short wavelengths and high transverse momenta,  $p_T > 2$  GeV. Instead of continuing to rise with  $p_T$ , the elliptic asymmetry stops growing and the difference between baryon vs meson  $v_2$  even reverses sign. Between  $2 < p_T < 5$  GeV the baryon  $v_2^B(p_T)$  exceeds the meson  $v_2^M(p_T)$  by approximately 3/2. For such short wavelength components of the QGP, local equilibrium simply cannot be maintained due the fundamental asymptotic freedom property of QCD, i.e. the coupling strength becomes too weak.

In this section, we concentrate on the  $p_T > 2$  GeV meson observables that can be readily understood in terms of QGP modified perturbative QCD (pQCD) dynamics [71, 72]. (Baryons at intermediate  $2 \text{ GeV} \leq p_T \leq 5 \text{ GeV}$  are outside the range of a perturbative treatment and several competing mechanisms have been proposed and are under theoretical development [73, 74, 75].)

The quantitative study of short wavelength partonic pQCD dynamics focuses on the rare high  $p_T$  power law tails that extend far beyond the typical (long wavelength) scales  $p < 3T \sim 1$  GeV of the bulk QGP. The second major discovery at RHIC is that the non-equilibrium power law high  $p_T$  jet distributions remain power law like but are strongly quenched [76]-[84]. Furthermore, the quenching pattern has a distinct centrality,  $p_T$ , azimuthal angle, and hadron flavor dependence that can be used to test the underlying dynamics in many independent ways.

Below RHIC energies, there is an enhancement of moderately high  $p_T$  tails that was observed in central Pb + Pb reactions at the SPS. (Very recent reanalysis of the WA98 data shows a somewhat weaker enhancement at SPS [85]) This enhancement was expected as a consequence of the Cronin enhancement: now understood as an initial state effect[86]t which is also seen in pA collisions. Since the Cronin enhancement is an effect of the initial state nuclear wavefunction, it plays a role in the Color Glass Condensate, but we wish to isolate final state effects for our study of the Quark Gluon Plasma. In contrast, at RHIC a large suppression, by a factor of 4-5, was discovered in central Au + Au that extends beyond 10 GeV for  $\pi^0$ .

Jet quenching in A + A was proposed in [87, 88] as a way to study the dense matter produced at RHIC energies. As noted before, the pQCD jet production rates finally become large enough to measure yields up to high  $p_T > 10$  GeV. Order of magnitude suppression effects were predicted based on simple estimates of induced gluon radiative energy loss. Ordinary, elastic energy loss [89] was known by that time to be too small to lead to significant attenuation.

As reviewed in [71, 72] refinements in the theory since then have opened the possibility of using the observed jet quenching pattern as a tomographic tool [90] to probe the parton densities in a QGP. The right panel of Fig.10 shows a recent jet tomographic analysis [91] of the PHENIX  $\pi^0$  data [76, 77] based on the GLV opacity formalism [92]. This analysis concludes that the initial gluon rapidity density required to account for the observed jet quenching pattern must be  $dN_g/dy \sim 1000 \pm 200$ .

This jet tomographic measure of the initial  $dN_q/dy$  is in remarkable agreement with three

<span id="page-17-0"></span>![](_page_17_Figure_0.jpeg)

Figure 10: Jet Quenching at RHIC. Left[[93\]](#page-33-0) shows the jet quenching pattern of π <sup>0</sup> discovered by PHENIX [\[76](#page-32-0), [77](#page-32-0)] at RHIC compared to previous observation of high p<sup>T</sup> enhancement at ISR and SPS energies The nuclear modification factor RAA = dNAA/TAA(b)dσpp measures the deviation of AA spectra from factorized pQCD. Right shows predictions [\[91](#page-33-0)] of the √ s and p<sup>T</sup> dependence from SPS, RHIC, LHC based on the GLV theory [\[92](#page-33-0)] of radiative energy loss.

other independent sources: (1) the initial entropy deduced via the Bjorken formula from the measured multiplicity, (2) the initial condition of the QGP required in hydrodynamics to produce the observed elliptic flow, and (3) the estimate of the maximum gluon rapidity density bound from the CGC gluon saturated initial condition, (which will be described later).

These four independent measures make it possible to estimate the maximal initial energy density in central collisions

$$\epsilon_0 = \epsilon(\tau \sim 1/p_0) \approx \frac{p_0^2}{\pi R^2} \frac{dN_g}{dy} \approx 20 \frac{\text{GeV}}{\text{fm}^3} \sim 100 \times \epsilon_A$$
 (5)

where  $p_0 \approx Q_{sat} \approx 1.0-1.4$  GeV is the mean transverse momentum of the initial produced gluons from the incident saturated virtual nuclear CGC fields[15, 61, 94]. This scale controls the formation time  $\hbar/p_0 \approx 0.2$  fm/c of the initially out-of-equilibrium (mostly gluonic) QGP. The success of the hydrodynamics requires that local equilibrium be achieved on a fast proper time scale  $\tau_{eq} \approx (1-3)/p_0 < 0.6$  fm/c. The temperature at that time is  $T(\tau_{eq}) \approx (\epsilon_0/(1-3) \times 12)^{1/4} \approx 2T_c$ .

In HIJING model[95], the mini-jet cutoff is  $p_0 = 2 - 2.2$  GeV limits the number of mini-jets to well below 1000. The inferred opacity of the QGP is observed to be much higher and consistent with the CGC[61] and EKRT[94] estimates.

#### 5.3.1 $I_{AA}$ and Di-Jet Tomography

Measurements of near side and away side azimuthal angle correlations of di-jet fragments provide the opportunity to probe the evolution of the matter produced at RHIC in even more detail. Fig.(11) show the discovery [81, 82, 83] of mono-jet production [87] in central collisions at RHIC. In peripheral collisions, the distribution  $dN/d\Delta\phi$  of the azimuthal distribution of  $p_T \sim 2$  GeV

![](_page_18_Figure_7.jpeg)

Figure 11: Monojets at RHIC from STAR [82, 83, 81]. Strongly correlated back-to-back di-jet production in pp and peripheral AuAu left side is compared to mono-jet production discovered in central AuAu.

![](_page_19_Figure_0.jpeg)

Figure 12: The **dA** control: PHENIX [96]  $\pi^0$  and STAR [97]  $h^{\pm}$  data compare  $R_{DAu}$  to  $R_{AuAu}$ . These and BRAHMS [98] and PHOBOS [99] data prove that jet quenching in Au + Au must be due to final state interactions. Curves for  $\pi^0$  show predictions from [91] for AuAu and from [103] DAu. The curves for DAu show the interplay between different gluon shadow parameterizations (EKS, none, HIJING) and Cronin enhancement and are similar to predictions in [101, 102, 103]. In lower panel, the unquenching of charged hadrons is also seen in D + Au relative to Au + Au at high  $p_T$ .

hadrons relative to a tagged  $p_T \sim 4$  GeV leading jet fragment shows the same near side and away side back-to-back jetty correlations as measured in p + p. This is strong evidence that the kinematic range studied tests the physics of pQCD binary parton collision processes. For central collisions, on the other hand, away side jet correlations are almost completely suppressed.

The published data are as yet limited to  $y_1 \approx y_2 \approx 0$ , broad  $p_T$  cuts:  $p_{T1} > 4$  GeV and  $p_T \sim 2$  GeV, two bins of  $\phi_1 - \phi_2$ , and of course averaged over  $\Phi_b$ . The measured modification of di-jet correlations is obtained by subtracting out the correlations due to bulk elliptic flow, and this introduces some uncertainty. Analysis of present and future data at higher transverse momenta for a variety of rapidities will allow better tests of the underlying perturbative QCD dynamics.

Only one year ago [100] the interpretation of high  $p_T$  suppression was under intense debate because it was not yet clear how much of the quenching was due to initial state saturation (shadowing) of the gluon distributions and how much due to jet quenching discussed in the previous section. There was only one way to find out - eliminate the QGP final state interactions by substituting a Deuterium beam for one of the two heavy nuclei. In fact, it was long ago anticipated [88] that such a control test would be needed to isolate the unknown nuclear gluon shadowing contribution to the A+A quench pattern. In addition D + Au was required to test predictions of possible initial state Cronin multiple interactions [86, 101, 102, 103, 104]. In contrast, one model of CGC [105] predicted a substantial suppression in D + Au collisions. The data [96, 97, 98, 99] conclusively rule out large initial shadowing as the cause of the  $x_{BJ} > 0.01$  quenching in Au+Au.

The  $I_{DAu}$  measurement from STAR [97] shows clearly how the suppression disappears in D+Au collisions. The return of back-to-back jet correlation in D+Au to the level observed in pp is seen in Fig.13. The data appear to be entirely consistent with jet quenching as a final state effect in

<span id="page-20-0"></span>![](_page_20_Figure_0.jpeg)

Figure 13: The **dA** "Return of the Jeti": Dijet fragment azimuthal correlations from STAR [97] in DAu are unquenched relative to the mono jet correlation observed in central AuAu.

AuAu with little initial state effect in D+Au. These D+Au data support the conclusion [106, 107] that the observed jet quenching in AuAu is due to parton energy loss.

Theoretical analysics of jet quenching confirm the energy density estimates determined from measurements of particle multiplicity. They give large energy losses for jets propagating through the matter produced at RHIC, and strengthen the case for multiple strong interactions of the quark and gluon constituents of the matter made at RHIC.

# 6 Empirical Evidence for the Color Glass Condensate

In this section, the accumulated evidence for the Color Glass Condensate hypothesis is discussed [15]. The evidence rests in a variety of measurements done at different accelerators with different type of particles scattering. The discussion of the results from RHIC will be emphasized here, but it is first important to briefly review the results from HERA involving electron proton scattering.

#### 6.1 Results from Electron-Hadron Scattering

Electron-hadron scattering provide information about the wavefunction of a hadron. The Color Glass Condensate describes the contribution to this wavefunction which have very many gluons in them. These pieces of the wavefunction control the physics at very small x, typically  $x \leq 10^{-2}$ . The various pieces of experimental information which support the CGC hypothesis come largely from ep scattering experiments at HERA:

![](_page_21_Figure_0.jpeg)

Figure 14: The cross section  $\sigma^{\gamma^*p}$  as a function of the scaling variable  $\tau = Q^2/Q_{sat}^2$  [109]

#### • Geometrical Scaling

Geometrical scaling is the observation [108]-[109] that the deep inelastic cross section for virtual photon scattering as a function of  $Q^2$  and x is really only a function of

$$\sigma^{\gamma^* p} \sim F(Q^2 / Q_{sat}^2) \tag{6}$$

where the saturation momentum increases as the fractional momentum, x, of the gluon tends to zero as

$$Q_{sat}^2(x) \sim (x_0/x)^{\lambda} 1 GeV^2 \tag{7}$$

with  $\lambda \sim 0.3$  and  $x_0 \sim 10^{-4}$ . This scaling with  $\tau = Q^2/Q_{sat}^2$  works for  $x \leq 10^{-2}$  and over the available  $Q^2$  range at HERA as shown in Fig. 14.

It is straightforward to understand why this scaling works for the small  $Q^2 \leq Q_{sat}^2$ . This is the region of the CGC, and there is only one dimensionful scale which characterizes the system: the saturation momentum.[110] The surprise is that there is an extended scaling window for  $Q_{sat}^2 \leq Q^2 \leq Q_{sat}^4/\Lambda_{QCD}^2$ .[111] This can be proven analytically. As well, one now has reliable computation of the dependence on x of the saturation momentum, that is, one knows the exponent  $\lambda$  to about 15% accuracy, and it agrees with what is seen from the geometrical scaling curve.[112] What is not determined from the theory of the CGC is the scale  $x_0$ , and this must be found by experiment. This comes from the boundary conditions for the renormalization group equations.

#### <span id="page-22-0"></span>• The Structure Function $F_2$

Using the dipole description of the virtual photon wavefunction, the structure function  $F_2$  can be related to the gluon distribution function which arises from the CGC. The results for the description of the data are remarkably good for  $x \leq 10^{-2}$  and  $Q^2 \leq 45 \ GeV^2$ . One should note that this description includes both the high and low  $Q^2$  data. Descriptions based on DGLAP evolution can describe the large  $Q^2$  points. The CGC description is very economical in the number of parameters which are used [113].

#### • Diffraction and Quasi-Elastic Processes

The CGC provides a description of the underlying structure of gluonic matter inside a hadron. As such, it should be sensitive to probes of the transverse extent of this matter, which can be experimentally studied in diffraction and related quasi-elastic particle production.[114]-[118] Diffractive scattering can be computed in the CGC description for small inclusive masses of produces particles. The CGC agrees both with generic features of the data, and provides a reasonably good quantitative description.

There are additional computations of quasi-elastic  $\rho$  meson production and  $J/\Psi$  production[119]-[120]. Again, up to uncertainties associated with the overall normalization (which arises from imprecise knowledge of hadronic wavefunctions), the CGC hypothesis provides a reasonably good quantitative description.

#### 6.2 Heavy Ion Collisions

The collision of two ultrarelativistic heavy ions can be visualized as the scattering of two sheets of colored glass, as shown in Fig. 4. [121]-[124]

At very early times after the collision the matter is at very high energy density and in the form of a CGC. As time goes on, the matter expands. As it expands the density of gluons decreases, and gluons begin to propagate with little interaction. At later times, the interaction strength increases and there is sufficient time for the matter to thermalize and form a Quark Gluon Plasma. This scenario is shown in Fig. 7, with realistic estimates for energy density and time scales appropriate for the RHIC heavy ion accelerator.

### 6.3 The Multiplicity

The CGC allows for a direct computation of the particle multiplicity in hadronic collisions. If one naively tries to compute jet production, the total multiplicity is infrared divergent. This follows because of the  $1/p_T^4$  nature of the perturbative formula for gluon production

$$\frac{1}{\pi R^2} \frac{dN}{dy d^2 p_T} \sim \frac{1}{\alpha_S} \frac{Q_{sat}^4}{p_T^4} \tag{8}$$

In the CGC, when  $p_T \leq Q_{sat}$ , this divergence is cutoff and the total gluon multiplicity goes as

$$\frac{1}{\pi R^2} \frac{dN}{dy} \sim \frac{1}{\alpha_S} Q_{sat}^2 \tag{9}$$

One can compute the proportionality constant and before the RHIC data appeared, predictions were made for the gluon multiplicity. In Fig. 15 from Ref.[125], the predictions for 200 AGeV to

<span id="page-23-0"></span>![](_page_23_Figure_0.jpeg)

Figure 15: Predictions for the charged hadron rapidity density for central Au + Au at  $\sqrt{s} = 200$  AGeV compiled by Eskola [125] compared to data band (740  $\pm$  50) measured later by all four experiments at RHIC. The CGC prediction is marked McLV.

extrapolations from the first RHIC run at 130 AGeV are shown. The CGC correctly predicted the surprizingly low multiplicity.

Also, the dependence of the multiplicity on the number of participants can also be computed, realizing that the saturation momentum squared should be (for not too small x) proportional  $N_{part}^{1/3}$ . This leads to

$$\frac{1}{N_{part}} \frac{dN}{dy} \sim \frac{1}{\alpha_S(Q_{sat}^2)} \sim \log N_{part}$$
 (10)

so that a very slow logarithmic dependence on the number of participants is predicted in agreement with experiment, as shown in Fig. 16.[126]-[129]

One can go much further [59] and compute the dependence of the multiplicity on rapidity and centrality, and the transverse momentum distribution of produced hadrons by using CGC initial conditions matched together with a hydrodynamic calculation which evolves the matter through the Quark Gluon Plasma [60]. At high  $p_T \gtrsim 2$  GeV, jet quenching of the pQCD power law tails is also taken into account using [92]. This combined hydrodynamic calculation of Nara and Hirano accounts very well for many important features of the data at RHIC. [76],[130]

We emphasize the importance of constraining the QGP hydrodynamics with a QCD theoretic initial condition, the CGC. At SPS energies, the uncertainty about initial conditions together with failure of hydrodynamics to account for the highly dissipative hadronic flow are in remarkable

# dN/dη vs Centrality at η=0

<span id="page-24-0"></span>![](_page_24_Figure_1.jpeg)

Figure 16: The total multiplicity as a function of the number of participants as measured by Phobos and Phenix. [62, 130, 131]

contrast to situation at RHIC. If the initial condition were not well constrained at RHIC, then the conclusion that a QGP was formed could not be sustained. Hydrodynamics is a dynamical mapping of a given given initial condition to final spectra that depends on the equation of state. Only with a known or predicted initial state does that mapping have the power to falsify the QCD equation of state.

In Figs 15 and 16, one can see that several phenomenological models, such as HIJING[95], could also account qualitatively for some of the global multiplicity observables. However, the surprising very weak centrality and beam energy dependence observed[62, 67, 130, 131] is most satisfactory explained and predicted by the CGC as arising from the slow  $1/\alpha_S \sim \log Q_{sat}^2(N_{part}, \sqrt{s})$  in eqs.(9,10). This is one of the strongest lines of empirical evidence from RHIC that the CGC initial state (with its predicted  $N_{part}$  and  $\sqrt{s}$  dependence) is formed and that it is the seed of the QGP that evolves from it.

# 6.4 High $p_T$ Particles

The early results from RHIC on gold-gold collisions revealed that the high  $p_T$  production cross sections were almost an order of magnitude below that expected for jet production arising from incoherent parton-parton scattering.[132] This could be either due to initial state shadowing of the gluon distribution inside the nuclei,[133] or to final state jet quenching.[134] For centrally produced jets, the x of the parton which produces a 5-10 GeV particle is of order  $10^{-1}$ , and this is outside the region where on the basis of the HERA data one expects the effects of the CGC to be

![](_page_25_Figure_0.jpeg)

Figure 17: Results of hydrodynamic calculations [60] with a CGC initial condition. Left is the centrality dependence of the rapidity density from PHOBOS [130]. Right shows the transverse momentum distribution at zero rapidity for different centralities from PHENIX [76]. For  $p_T > 2$  GeV jet quenching [92] through the evolving QGP is also taken into account.

important. Nevertheless, nuclei might be different than protons, so it is not a priori impossible.

The crucial test of these two different mechanisms is the comparison of dA scattering to pp. If there is suppression of jet in dA collisions, then it is an initial state effect. The experiments were performed, and all there is little initial state effect for centrally produced jets.[135] The suppression of centrally produced jets in AA collisions at RHIC is indeed due to final state interactions, that is jet quenching.

This is not in contradiction with the existence of a CGC. The particles which control the multiplicity distribution in the central region are relatively soft, and arise from  $x \sim 10^{-2}$ . To probe such small x degrees of freedom at high transverse momentum at RHIC requires that one go to the forward region.[136]-[137]

If one uses naive Glauber theory to compute the effects of shadowing by multiple scattering, one expects that if one goes into the forward region of the deuteron, the probe propagates through more matter in the nucleus. This is because we probe all of the gluons with x greater than the minimum x of the nucleus which can be seen by the deuteron. Going more forward makes this minimum x smaller. Now multiple scattering will produce more particles at some intermediate value of  $p_T$ . (At very high  $p_T$ , the effects of multiple scattering will disappear.) This is the source of the Cronin peak and it is expected to occur at  $p_T$  of 2-4~GeV. Clearly the height of this peak should increase as one goes more forward on the side of the deuteron, and should increase with

the centrality of the collision.[\[138](#page-35-0)] A result of such a computation is shown in Fig. 18.

![](_page_26_Figure_1.jpeg)

Figure 18: The expectations of classical multiple scattering for the rapidity and p<sup>T</sup> dependence (with and without shadowing) for the p<sup>T</sup> distribution in D +Au collisions from [\[103\]](#page-34-0).

Classical rescattering effects are included in the computation of the properties of the CGC. There is another effect however and that is quantum evolution generated by the renormalization group equations. It was a surprise that when one computed the evolution of the gluon distribution function including both effects, the quantum evolution dominated. This means that the height of the Cronin peak, and the overall magnitude of the gluon distribution decreased as one went from backwards to forward angles.[\[139](#page-35-0)]- [\[141\]](#page-35-0) The results of one such computation are shown in Fig. [19](#page-27-0) It was also a surprise how rapid the effect set in.

The Brahms experiment at RHIC recently presented data[[142\]](#page-35-0) on the ratio of central to peripheral transverse momentum distributions.The ratio RCP is defined in such a way that if the processes were due to incoherent production of jets, then RCP = 1. A value less than one indicates suppression, and a value larger than one indicates a Cronin type enhancement. The results for a variety of forward angles for RCP as a function of p<sup>T</sup> is shown in Fig. [20](#page-28-0) a. There is clearly a decrease in RCP as one goes to forward angles, in distinction from the predictions of classical multiple scattering. The effect is very rapid in rapidity, as was expected from computations of the CGC. In Fig. [20](#page-28-0), the ratio RCP is shown as a function of p<sup>T</sup> for the forward pseudorapidity η ∼ 3 for less central and more central events. The ratio decreases for more central collisions, against the expectation of classical multiple scattering and consistent with the CGC hypothesis.

<span id="page-27-0"></span>![](_page_27_Figure_0.jpeg)

Figure 19: The gluon intrinsic gluon distribution function as a function of  $p_T$  for different pseudo-rapidities [141].

Preliminary data[143]-[145] from all four experiments on the rapidity dependence of the transverse distributions in D + Au suggest striking effects consistent with CGC. This is a very active area of research both theoretically and experimentally at this time.

This data suggest a Cronin enhancement on the gold side and the depletion on the deuteron side, and as well a definite dependence on centrality. When these D + Au data become finalized, they could prove that classical multiple scattering dominates on the gold side (large x > 0.01), but quantum evolution - i.e., deep gluon shadowing- on the deuteron side (small x < 0.01).

By a "happy coincidence", these effects nearly cancel in the mid-rapidity region, making RHIC well suited for studying QGP effects at midrapidity for hard probes.

#### 6.5 The Developing Case for the CGC

In addition to the results described above, the Color Glass Condensate will be the subject of further experimental study at RHIC, LHC and eRHIC. At RHIC, one can study forward backward correlations in the forward direction in analogy with what was done for centrally produced jets. At LHC, in the forward region one measures relatively large  $p_T$  jets at  $x \sim 10^{-6}$ . This provides a direct measurement of the very small x gluon distribution function. Eventually eRHIC would be required to provide precision measurements of quark and gluon distribution functions at small x in a variety of nuclei.

The Color Glass Condensate hypothesis describes remarkably well generic features of *ep* measurements of properties of protons at small x. It also successfully predicted

<span id="page-28-0"></span>![](_page_28_Figure_0.jpeg)

Figure 20: The central to peripheral charged and negative hadron ratios  $R_{CP}$  as a function of  $p_T$  for various forward pseudorapidities in 200 AGeV D + Au from BRAHMS[142].

the the previously unexpected slow growth of multiplicity of produced particles with  $\sqrt{s}$  and centrality at RHIC. The data from Brahms on the forward particle production appear to be qualitatively in accord with prediction of the CGC, and the preliminary data from Phobos, Star and RHIC on this subject await submission for publication. While the CGC hypothesis successfully describes the data from disparate experimental measurements, it can be further tested in a variety of new environments.

#### 7 Conclusions

Our criteria for the discovery of the Quark Gluon Plasma at RHIC are:

- Matter at energy densities so large that the simple degrees of freedom are quarks and gluons. This energy density is that predicted by lattice gauge theory for the existence of a QGP in thermal systems, and is about  $2 \ GeV/fm^3$
- The matter must be to a good approximation thermalized.
- The properties of the matter associated with the matter while it is hot and dense must follow from QCD computations based on hydrodynamics, lattice gauge theory results, and perturbative QCD for hard processes such as jets

All of the above are satisfied from the published data at RHIC. A surprise is the degree to which the computations based on ideal fluid hydrodynamics agree so well with elliptic flow data. This leads us to conclude that the matter produced at RHIC is a strongly coupled Quark Gluon Plasma (sQGP) contrary to original expectations that were based on weakly coupled plasma estimates.

The case for the Color Glass Condensate is rapidly evolving into a compelling case. Much of the exciting new data from RHIC presented at QM2004 has yet to be published. Nevertheless, the data from HERA taken together with the data on particle multiplicities, and the data submitted for publication by Brahms make a strong case, which may become compelling with further reinforcement from results from the other experiments at RHIC, and future experimental tests at LHC and eRHIC. This area continues to evolve rapidly both experimentally and theoretically.

<span id="page-29-0"></span>Although in our opinion, the case for the sQGP at RHIC is now overwhelming, there are of course many important scientific issues not yet addressed in the first three years of data. The experiments have demonstrated that a new form of matter, the sQGP, exists. The harder long term task of mapping out more of its novel properties can now confidently proceed at RHIC.

# 8 Acknowledgments

This work was supported by the Director, Office of Energy Research, Office of High Energy and Nuclear Physics, Division of Nuclear Physics, of the U.S. Department of Energy under Contracts DE-FG-02-93ER-40764 and DE-AC02-98H10886.

# References

- [1] Report of the workshop on BeV/nucleon collisions of heavy ions how and why, Bear Mountain, New York, Nov. 29 – Dec. 1, 1974 (BNL-AUI, 1975); G. Baym, Nucl. Phys. A 698, XXIII (2002)[[arXiv:hep-ph/0104138](http://arxiv.org/abs/hep-ph/0104138)].
- [2] T. D. Lee and G. C. Wick, Phys. Rev. D 9, 2291 (1974).
- [3] J. Hofmann, H. Stocker, W. Scheid and W. Greiner, Bear Mountain Workshop, New York, Dec 1974; H. G. Baumgardt et al., Z. Phys. A 273, 359 (1975).
- [4] J. C. Collins and M. J. Perry, Phys. Rev. Lett. 34, 1353 (1975); G. Baym and S. A. Chin, Phys. Lett. B 62 (1976) 241; B. A. Freedman and L. D. McLerran, Phys. Rev. D 16, 1169 (1977); G. Chapline and M. Nauenberg, Phys. Rev. D 16, 450 (1977).
- [5] E. V. Shuryak, Sov.Phys.JETP 47:212-219,1978, Zh.Eksp.Teor.Fiz.74:408-420,1978; Phys. Lett. B 78, 150 (1978); Phys.Rept.61:71-158,1980; O. K. Kalashnikov and V. V. Klimov, Phys. Lett. B 88, 328 (1979); J. I. Kapusta, Nucl. Phys. B 148 (1979) 461.
- [6] J. D. Bjorken, FERMILAB-CONF-83-070-T; Phys. Rev. D 27, 140 (1983).
- [7] RHIC:<http://www.bnl.gov/rhic/default.htm>
- [8] For a complete list of RHIC publications see QPIRES: <http://www.slac.stanford.edu/spires/hep/> using "find cn brahms or cn phobos or cn star or cn phenix and ps published"
- [9] BRAHMS exp. homepage:<http://www4.rcf.bnl.gov/brahms/WWW/brahms.html>
- [10] PHENIX exp. homepage:<http://www.phenix.bnl.gov/>
- [11] PHOBOS exp. homepage:<http://www.phobos.bnl.gov/>
- [12] STAR exp. homepage:<http://www.star.bnl.gov/>
- [13] CERN symposium, Feb. 10, 2000. See, e.g, CERN Courier 40 (May 2000) 13; B. Schwarzschild, Phys. Today 53 (May 2000) 20.
- [14] M. Gyulassy, Proc. NATO/ASI: Structure and Dynamics of Elementary Matter (Kemer, Turkey, 2003, ed. W. Greiner), [arXiv:nucl-th/0403032.](http://arxiv.org/abs/nucl-th/0403032)

- <span id="page-30-0"></span>[15] L. McLerran, Proc. NATO/ASI: Structure and Dynamics of Elementary Matter (Kemer, Turkey, 2003, ed. W. Greiner), [arXiv:hep-ph/0402137](http://arxiv.org/abs/hep-ph/0402137).
- [16] S. A. Bass, M. Gyulassy, H. Stocker and W. Greiner, J. Phys. G 25, R1 (1999) [\[arXiv:hep](http://arxiv.org/abs/hep-ph/9810281)[ph/9810281\]](http://arxiv.org/abs/hep-ph/9810281).
- [17] C. R. Allton et al, Phys. Rev. D 68, 014507 (2003)[[arXiv:hep-lat/0305007\]](http://arxiv.org/abs/hep-lat/0305007). F. Karsch, E. Laermann and A. Peikert, Phys. Lett. B 478, 447 (2000)[[arXiv:hep-lat/0002003\]](http://arxiv.org/abs/hep-lat/0002003). F. Karsch, Lect. Notes Phys. 583, 209 (2002) [\[arXiv:hep-lat/0106019](http://arxiv.org/abs/hep-lat/0106019)].
- [18] C. W. Bernard et al. [MILC Collaboration], Phys. Rev. D 55, 6861 (1997) [\[arXiv:hep](http://arxiv.org/abs/hep-lat/9612025)[lat/9612025](http://arxiv.org/abs/hep-lat/9612025)].
- [19] S. Gupta, Pramana 61, 877 (2003) [\[arXiv:hep-ph/0303072\]](http://arxiv.org/abs/hep-ph/0303072).
- [20] Z. Fodor and S. D. Katz, [arXiv:hep-lat/0402006.](http://arxiv.org/abs/hep-lat/0402006) F. Csikor et al [arXiv:hep-lat/0401022.](http://arxiv.org/abs/hep-lat/0401022)
- [21] F. Karsch, K. Redlich and A. Tawfik, Phys. Lett. B 571, 67 (2003) [\[arXiv:hep-ph/0306208](http://arxiv.org/abs/hep-ph/0306208)].
- [22] M. A. Halasz et al, Phys. Rev. D 58, 096007 (1998) [\[arXiv:hep-ph/9804290](http://arxiv.org/abs/hep-ph/9804290)]. M. A. Stephanov, K. Rajagopal and E. V. Shuryak, Phys. Rev. Lett. 81, 4816 (1998) [\[arXiv:hep-ph/9806219](http://arxiv.org/abs/hep-ph/9806219)].
- [23] D. H. Rischke, Prog. Part. Nucl. Phys. 52, 197 (2004) [\[arXiv:nucl-th/0305030\]](http://arxiv.org/abs/nucl-th/0305030).
- [24] J. Breitweg et. al. Eur. Phys. J. 67, 609 (1999).
- [25] L. V. Gribov, E. M. Levin and M. G. Ryskin, Phys. Rept. 100, 1 (1983).
- [26] A. H. Mueller and Jian-wei Qiu, Nucl. Phys. B268, 427 (1986); J.-P. Blaizot and A. H. Mueller, Nucl. Phys. B289, 847 (1987).
- [27] L.N. Lipatov, Sov. J. Nucl. Phys. 23 (1976), 338; E.A. Kuraev, L.N. Lipatov and V.S. Fadin, Sov. Phys. JETP 45 (1977), 199; Ya.Ya. Balitsky and L.N. Lipatov, Sov. J. Nucl. Phys. 28 (1978), 822.
- [28] L. D. McLerran and R. Venugopalan, Phys. Rev. D49, 2233(1994); 3352 (1994); D50, 2225 (1994).
- [29] E. Iancu, A. Leonidov and L. D. McLerran, Nucl. Phys. A692, 583 (2001); E. Ferreiro E. Iancu, A. Leonidov and L. D. McLerran, Nucl. Phys. bf A710,373 (2002).
- [30] E. Iancu and L. McLerran, Phys.Lett. B510, 145 (2001).
- [31] A. Kovner, L. D. McLerran and H. Weigert, Phys. Rev. D52, 6231 (1995); 3809 (1995); A. Krasnitz and R. Venugopalan, Phys. Rev. Lett 84, 4309 (2000); Nucl. Phys. B557, 237 (1999); A. Krasnitz, Y. Nara and R. Venugopalan, Phys. Rev. Lett. 87 , 192302 (2001).
- [32] B. B. Back et al. [PHOBOS Collaboration], Phys. Rev. Lett. 88, 022302 (2002) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0108009)[ex/0108009](http://arxiv.org/abs/nucl-ex/0108009)].
- [33] B. B.Back et. al. [PHOBOS], Phys. Rev. Lett. 85, 3100 (2000);
- [34] H. Stocker, J. A. Maruhn and W. Greiner, Z. Phys. A 293, 173 (1979); Phys. Rev. Lett. 44, 725 (1980); L. Csernai and H. Stocker, Phys. Rev. C 25, 3208 (1981).
- [35] H. Stocker et al., Phys. Rev. C 25, 1873 (1982).
- [36] H. Stocker and W. Greiner, Phys. Rept. 137, 277 (1986).

- <span id="page-31-0"></span>[37] W. Reisdorf and H. G. Ritter, Ann. Rev. Nucl. Part. Sci. 47, 663 (1997).
- [38] S. Voloshin and Y. Zhang, Z. Phys. C 70, 665 (1996)[[arXiv:hep-ph/9407282](http://arxiv.org/abs/hep-ph/9407282)].
- [39] J. Y. Ollitrault, Phys. Rev. D 46, 229 (1992).
- [40] S. A. Voloshin and A. M. Poskanzer, Phys. Lett. B 474, 27 (2000) [\[arXiv:nucl-th/9906075\]](http://arxiv.org/abs/nucl-th/9906075).
- [41] C. Alt et al. [NA49 Collaboration], Phys. Rev. C 68, 034903 (2003) [\[arXiv:nucl-ex/0303001\]](http://arxiv.org/abs/nucl-ex/0303001).
- [42] G. Stoicea et al., [arXiv:nucl-ex/0401041.](http://arxiv.org/abs/nucl-ex/0401041)
- [43] J. Adams et al. [STAR Collaboration], [arXiv:nucl-ex/0310029](http://arxiv.org/abs/nucl-ex/0310029), Phys. Rev. Lett. 92 (2004) 062301.
- [44] P. R. Sorensen, hadronization of the bulk partonic matter created in Au + Au collisions at [arXiv:nucl-ex/0309003](http://arxiv.org/abs/nucl-ex/0309003). Ph.D. thesis.
- [45] J. Adams et al. [STAR Collaboration], [arXiv:nucl-ex/0306007](http://arxiv.org/abs/nucl-ex/0306007), Phys. Rev. Lett. 92 (2004) 052302
- [46] C. Adler et al. [STAR Collaboration], Phys. Rev. C 66, 034904 (2002) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0206001)[ex/0206001](http://arxiv.org/abs/nucl-ex/0206001)].
- [47] S. S. Adler et al. [PHENIX Collaboration], Phys. Rev. Lett. 91, 182301 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0305013)[ex/0305013](http://arxiv.org/abs/nucl-ex/0305013)].
- [48] P. F. Kolb, P. Huovinen, U. W. Heinz and H. Heiselberg, Phys. Lett. B 500, 232 (2001).
- [49] P. Huovinen, P. F. Kolb, U. W. Heinz, P. V. Ruuskanen and S. A. Voloshin, Phys. Lett. B 503, 58 (2001).
- [50] P. F. Kolb, U. W. Heinz, P. Huovinen, K. J. Eskola and K. Tuominen, Nucl. Phys. A 696, 197 (2001).
- [51] P. Huovinen, Published in Quark Gluon Plasma 3, editors: R.C. Hwa and X.N. Wang, (World Scientific, Singapore,2004) p.600; [arXiv:nucl-th/0305064](http://arxiv.org/abs/nucl-th/0305064).
- [52] P. F. Kolb and U. Heinz, Published in Quark Gluon Plasma 3, editors: R.C. Hwa and X.N. Wang, (World Scientific, Singapore,2004) p.634; [arXiv:nucl-th/0305084](http://arxiv.org/abs/nucl-th/0305084).
- [53] D. Teaney, J. Lauret and E. V. Shuryak, [nucl-th/0104041](http://arxiv.org/abs/nucl-th/0104041).
- [54] D. Teaney, J. Lauret and E. V. Shuryak, [arXiv:nucl-th/0110037.](http://arxiv.org/abs/nucl-th/0110037)
- [55] D. Teaney, Phys. Rev. C 68, 034913 (2003). D. Teaney, [arXiv:nucl-th/0301099](http://arxiv.org/abs/nucl-th/0301099).
- [56] T. Hirano and Y. Nara, Phys. Rev. Lett. 91, 082301 (2003)[[arXiv:nucl-th/0301042](http://arxiv.org/abs/nucl-th/0301042)].
- [57] T. Hirano and Y. Nara, Phys. Rev. C 68, 064902 (2003) [\[arXiv:nucl-th/0307087\]](http://arxiv.org/abs/nucl-th/0307087).
- [58] T. Hirano and Y. Nara, [arXiv:nucl-th/0307015.](http://arxiv.org/abs/nucl-th/0307015)
- [59] T. Hirano, [arXiv:nucl-th/0403042.](http://arxiv.org/abs/nucl-th/0403042)
- [60] T. Hirano and Y. Nara, [arXiv:nucl-th/0403029.](http://arxiv.org/abs/nucl-th/0403029)
- [61] E. Iancu and R. Venugopalan, [arXiv:hep-ph/0303204](http://arxiv.org/abs/hep-ph/0303204). L. D. McLerran and R. Venugopalan, Phys. Rev. D 49, 2233 (1994)[[arXiv:hep-ph/9309289](http://arxiv.org/abs/hep-ph/9309289)]. D. Kharzeev and E. Levin, Phys. Lett. B 523, 79 (2001)[[arXiv:nucl-th/0108006](http://arxiv.org/abs/nucl-th/0108006)].

- <span id="page-32-0"></span>[62] B. B. Back et al. [PHOBOS collaboration], Nucl. Phys. A 715, 65 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0212009)[ex/0212009](http://arxiv.org/abs/nucl-ex/0212009)].
- [63] G. Agakichiev et al. [CERES/NA45 Collaboration], [arXiv:nucl-ex/0303014](http://arxiv.org/abs/nucl-ex/0303014).
- [64] D. Molnar and M. Gyulassy, Nucl. Phys. A 697, 495 (2002) [Erratum-ibid. A 703, 893 (2002)] [\[arXiv:nucl-th/0104073\]](http://arxiv.org/abs/nucl-th/0104073). B. Zhang, M. Gyulassy and C. M. Ko, Phys. Lett. B 455, 45 (1999)[[arXiv:nucl-th/9902016](http://arxiv.org/abs/nucl-th/9902016)].
- [65] Y. Cheng, F. Liu, Z. Liu, K. Schweda and N. Xu, Phys. Rev. C 68, 034910 (2003). N. Xu et al. [NA44 Collaboration], Nucl. Phys. A 610, 175C (1996).
- [66] S. A. Bass and A. Dumitru, Phys. Rev. C 61, 064909 (2000) [\[arXiv:nucl-th/0001033\]](http://arxiv.org/abs/nucl-th/0001033).
- [67] I. G. Bearden et al. [BRAHMS Collaboration], Phys. Rev. Lett. 88, 202301 (2002) [\[arXiv:nucl-ex/0112001](http://arxiv.org/abs/nucl-ex/0112001)].
- [68] P. Danielewicz, R. Lacey and W. G. Lynch, Science 298, 1592 (2002) [\[arXiv:nucl](http://arxiv.org/abs/nucl-th/0208016)[th/0208016\]](http://arxiv.org/abs/nucl-th/0208016).
- [69] G. Brown et al, [arXiv:hep-ph/0402068;](http://arxiv.org/abs/hep-ph/0402068) E. Shuryak, RBRC report, this volume
- [70] P. Danielewicz and M. Gyulassy, Phys. Rev. D 31 (1985) 53.
- [71] M. Gyulassy, I. Vitev, X. N. Wang and B. W. Zhang, Published in Quark Gluon Plasma 3, editors: R.C. Hwa and X.N. Wang, (World Scientific, Singapore,2004) p.123; [arXiv:nucl](http://arxiv.org/abs/nucl-th/0302077)[th/0302077.](http://arxiv.org/abs/nucl-th/0302077) M. Gyulassy, Lect. Notes Phys. 583, 37 (2002)[[arXiv:nucl-th/0106072](http://arxiv.org/abs/nucl-th/0106072)].
- [72] R. Baier, D. Schiff and B. G. Zakharov, Ann. Rev. Nucl. Part. Sci. 50, 37 (2000) [\[arXiv:hep](http://arxiv.org/abs/hep-ph/0002198)[ph/0002198\]](http://arxiv.org/abs/hep-ph/0002198).
- [73] D. Kharzeev, Phys. Lett. B 378, 238 (1996)[[arXiv:nucl-th/9602027](http://arxiv.org/abs/nucl-th/9602027)]. S. E. Vance et al, Phys. Lett. B 443, 45 (1998) [\[arXiv:nucl-th/9806008\]](http://arxiv.org/abs/nucl-th/9806008). I. Vitev and M. Gyulassy, Phys. Rev. C 65, 041902 (2002)[[arXiv:nucl-th/0104066](http://arxiv.org/abs/nucl-th/0104066)].
- [74] P. Csizmadia, et al J. Phys. G 25, 321 (1999) [\[arXiv:hep-ph/9809456\]](http://arxiv.org/abs/hep-ph/9809456). R. J. Fries, B. Muller, C. Nonaka and S. A. Bass, Phys. Rev. Lett. 90, 202303 (2003) [\[arXiv:nucl-th/0301087\]](http://arxiv.org/abs/nucl-th/0301087). D. Molnar and S. A. Voloshin, Phys. Rev. Lett. 91, 092301 (2003) [\[arXiv:nucl-th/0302014\]](http://arxiv.org/abs/nucl-th/0302014). V. Greco, C. M. Ko and P. Levai, Phys. Rev. C 68, 034904 (2003) [\[arXiv:nucl-th/0305024\]](http://arxiv.org/abs/nucl-th/0305024). Z. W. Lin and D. Molnar, Phys. Rev. C 68, 044901 (2003)[[arXiv:nucl-th/0304045\]](http://arxiv.org/abs/nucl-th/0304045).
- [75] B. Muller, RBRC report, this volume.
- [76] K. Adcox et al., Phys. Rev. Lett. 88, 022301 (2002); P. Levai et al., Nucl. Phys. A 698, 631 (2002).
- [77] K. Adcox et al. [PHENIX Collaboration], Phys. Lett. B 561, 82 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0207009)[ex/0207009](http://arxiv.org/abs/nucl-ex/0207009)].
- [78] S. S. Adler et al. [PHENIX Collaboration], Phys. Rev. Lett. 91, 072301 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0304022)[ex/0304022](http://arxiv.org/abs/nucl-ex/0304022)].
- [79] J. Adams et al. [STAR Collaboration], Phys. Rev. Lett. 91, 172302 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0305015)[ex/0305015](http://arxiv.org/abs/nucl-ex/0305015)].
- [80] C. Adler et al., [STAR Collaboration] Phys. Rev. Lett. 89, 202301 (2002) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0206011)[ex/0206011](http://arxiv.org/abs/nucl-ex/0206011)].

- <span id="page-33-0"></span>[81] P. Jacobs and J. Klay [STAR Collaboration], [arXiv:nucl-ex/0308023.](http://arxiv.org/abs/nucl-ex/0308023)
- [82] C. Adler et al. [STAR Collaboration], Phys. Rev. Lett. 90, 082302 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0210033)[ex/0210033](http://arxiv.org/abs/nucl-ex/0210033)].
- [83] D. Hardtke [The STAR Collaboration], Nucl. Phys. A 715, 272 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0212004)[ex/0212004](http://arxiv.org/abs/nucl-ex/0212004)].
- [84] C. Adler et al. [STAR Collaboration], Phys. Rev. Lett. 90, 032301 (2003).
- [85] D. d'Enterria, [arXiv:nucl-ex/0403055](http://arxiv.org/abs/nucl-ex/0403055).
- [86] A. Accardi, "Cronin effect in pA : A survey of theoretical models," [arXiv:hep-ph/0212148.](http://arxiv.org/abs/hep-ph/0212148)
- [87] M. Gyulassy and M. Plumer, Nucl. Phys. A 527, 641 (1991). M. Gyulassy, M. Plumer, M. Thoma and X. N. Wang, Nucl. Phys. A 538, 37C (1992)
- [88] X. Wang and M. Gyulassy, Phys. Rev. Lett. 68, 1480 (1992).
- [89] J. D. Bjorken, FERMILAB-PUB-82-059-THY and erratum (unpublished); M. H. Thoma and M. Gyulassy, Nucl. Phys. B 351, 491 (1991); E. Braaten and M. H. Thoma, Phys. Rev. D 44, 2625 (1991); M. H. Thoma, J. Phys. G 26, 1507 (2000) [\[arXiv:hep-ph/0003016\]](http://arxiv.org/abs/hep-ph/0003016).
- [90] M. Gyulassy, P. Levai, and I. Vitev, Phys. Lett. B 538, 282 (2002): E. Wang and X.-N. Wang, Phys. Rev. Lett. 89, 162301 (2002); C. A. Salgado and U. A. Wiedemann, Phys. Rev. Lett. 89, 092303 (2002);
- [91] I. Vitev and M. Gyulassy, Phys. Rev. Lett. 89, 252301 (2002) [\[arXiv:hep-ph/0209161\]](http://arxiv.org/abs/hep-ph/0209161).
- [92] M. Gyulassy, P. Levai and I. Vitev, Nucl. Phys. B 594, 371 (2001) [\[arXiv:nucl-th/0006010\]](http://arxiv.org/abs/nucl-th/0006010). Phys. Rev. Lett. 85, 5535 (2000)[[arXiv:nucl-th/0005032](http://arxiv.org/abs/nucl-th/0005032)]; Phys. Rev. D 66, 014005 (2002) [\[arXiv:nucl-th/0201078\]](http://arxiv.org/abs/nucl-th/0201078); Nucl. Phys. B 571, 197 (2000)[[arXiv:hep-ph/9907461](http://arxiv.org/abs/hep-ph/9907461)].
- [93] D. d'Enterria [PHENIX Collaboration], [arXiv:nucl-ex/0401001](http://arxiv.org/abs/nucl-ex/0401001).
- [94] K. J. Eskola, K. Kajantie, P. V. Ruuskanen and K. Tuominen, Phys. Lett. B 543, 208 (2002) [\[arXiv:hep-ph/0204034](http://arxiv.org/abs/hep-ph/0204034)]; Phys. Lett. B 532, 222 (2002)[[arXiv:hep-ph/0201256](http://arxiv.org/abs/hep-ph/0201256)]; Nucl. Phys. B570, 379 (2000); Phys. Lett. B497, 39 (2001).
- [95] V. Topor Pop et al., Phys. Rev. C 68, 054902 (2003) [\[arXiv:nucl-th/0209089\]](http://arxiv.org/abs/nucl-th/0209089). X. N. Wang and M. Gyulassy, Phys. Rev. D 44, 3501 (1991).
- [96] S. S. Adler et al. [PHENIX Collaboration], Phys. Rev. Lett. 91, 072303 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0306021)[ex/0306021](http://arxiv.org/abs/nucl-ex/0306021)].
- [97] J. Adams et al. [STAR Collaboration], Phys. Rev. Lett. 91, 072304 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0306024)[ex/0306024](http://arxiv.org/abs/nucl-ex/0306024)].
- [98] I. Arsene et al. [BRAHMS Collaboration], suppression," Phys. Rev. Lett. 91, 072305 (2003) [\[arXiv:nucl-ex/0307003](http://arxiv.org/abs/nucl-ex/0307003)].
- [99] B. B. Back et al. [PHOBOS Collaboration], Phys. Rev. Lett. 91, 072302 (2003) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0306025)[ex/0306025](http://arxiv.org/abs/nucl-ex/0306025)].
- [100] Transverse Dynamics at RHIC, BNL March 6-8, 2003, "[http://www.phenix.bnl.gov/phenix/WWW/publish/rak/workshop/int/program](http://www.phenix.bnl.gov/phenix/WWW/publish/rak/workshop/int/program_TD.htm) TD.htm"
- [101] X. N. Wang, Phys. Rev. C 61, 064910 (2000) [\[arXiv:nucl-th/9812021\]](http://arxiv.org/abs/nucl-th/9812021).

- <span id="page-34-0"></span>[102] X. N. Wang, Phys. Rept. 280, 287 (1997) [\[arXiv:hep-ph/9605214\]](http://arxiv.org/abs/hep-ph/9605214).
- [103] I. Vitev, Phys. Lett. B 562, 36 (2003)[[arXiv:nucl-th/0302002](http://arxiv.org/abs/nucl-th/0302002)]; X. N. Wang, Phys. Lett. B 565, 116 (2003)[[arXiv:nucl-th/0303004](http://arxiv.org/abs/nucl-th/0303004)]; A. Accardi and M. Gyulassy, [arXiv:nucl](http://arxiv.org/abs/nucl-th/0308029)[th/0308029;](http://arxiv.org/abs/nucl-th/0308029) P. Levai, G. Papp, G. G. Barnafoldi and G. I. Fai, [arXiv:nucl-th/0306019.](http://arxiv.org/abs/nucl-th/0306019)
- [104] J. w. Qiu and I. Vitev, [arXiv:hep-ph/0309094;](http://arxiv.org/abs/hep-ph/0309094) [arXiv:hep-ph/0401062](http://arxiv.org/abs/hep-ph/0401062).
- [105] D. Kharzeev, E. Levin and L. McLerran, Phys. Lett. B 561, 93 (2003) [\[arXiv:hep](http://arxiv.org/abs/hep-ph/0210332)[ph/0210332\]](http://arxiv.org/abs/hep-ph/0210332).
- [106] X. N. Wang, [arXiv:nucl-th/0305010.](http://arxiv.org/abs/nucl-th/0305010)
- [107] X. N. Wang, Phys. Lett. B 579, 299 (2004)[[arXiv:nucl-th/0307036](http://arxiv.org/abs/nucl-th/0307036)].
- [108] D. Schildknecht and Bernd Surrow, Phys. Lett. B499, 116 (2001)
- [109] A. M. Stasto, K. Golec-Biernat and J. Kwiecinski, Phys. Rev. Lett., 86, 596 (2001).
- [110] E. Levin and K. Tuchin, Nucl. Phys. A691, 779 (2001)
- [111] E. Iancu, K. Itakura and L. McLerran, Nucl. Phys. A 708, 327 (2002).
- [112] A. H. Mueller and V. N. Triantafyllopoulos, Nucl.Phys. B640, 331 (2002). D. N. Triantafyllopoulos, Nucl. Phys. B 648, 293 (2003).
- [113] E. Iancu, K. Itakura, and S. Munier, to be published in Phys. Lett. B, [hep-ph/0310338](http://arxiv.org/abs/hep-ph/0310338)
- [114] L. Frankfurt, V. Guzey, M. McDermott, Phys.Rev.Lett. 87, 192301 (2001) L. Frankfurt, M. Strikman and M. Zhalov, Phys.Lett. B537, 51 (2002); T. Rogers, V. Guzey, M. Strikman and Z. Xu, [hep-ph/0309099.](http://arxiv.org/abs/hep-ph/0309099)
- [115] K. Golec-Biernat and M. W¨usthoff, Phys. Rev. D59 (1999), 014017; ibid. D60 (1999), 114023; Eur. Phys. J. C20 (2001) 313.
- [116] W. Buchmuller and A. Hebecker, Nucl.Phys. B476, 203 (1996). W. Buchmuller, T. Gehrmann and A. Hebecker, Nucl.Phys. B537, 477 (1999)
- [117] Y. Kovchegov and L. McLerran, Phys.Rev. D60, 054025 (1999).
- [118] J. Bartels, K. Golec-Biernat and H. Kowalski, Phys.Rev. D66, 014001 (2002);
- [119] A. H. Mueller, S. Munier and A. Stasto Nucl.Phys. B603, 427 (2001)
- [120] H. Kowalski and D. Teaney, Phys. Rev. D68,114005 (2003).
- [121] A. Kovner, L. McLerran and H. Weigert, Phys. Rev D52 3809 (1995); D52 6231 (1995).
- [122] A. Krasnitz and R. Venugopalan, Nucl. Phys. B557 237 (1999); Phys. Rev. Lett. 84 (2000), 4309; Phys. Rev. Lett. 86 (2001).
- [123] T. Lappi, Phys. Rev. C67, 054903 (2003).
- [124] A. Krasnitz, Y. Nara, and R. Venugopalan, Phys. Rev. Lett. 87 (2001) 192302.
- [125] K. J. Eskola, Nucl. Phys. A 698, 78 (2002) [\[arXiv:hep-ph/0104058\]](http://arxiv.org/abs/hep-ph/0104058).
- [126] K. Eskola, K. Kajantie and K. Tuominen, Phys. Lett. B497, 39 (2001).
- [127] D. Kharzeev and M. Nardi, Phys. Lett. B507, 121 (2001); D. Kharzeev, E. Levin, Phys. Lett. B523, 79 (2001).

- <span id="page-35-0"></span>[128] B.B. Back et al [PHOBOS] Phys. Rev. C65, 31901R (2002).
- [129] K. Adcox et. al. Phys. Rev. Lett. 86, 3500 (2001)
- [130] B. B. Back et al. [PHOBOS Collaboration], Phys. Rev. Lett. 85, 3100 (2000) [\[arXiv:hep](http://arxiv.org/abs/hep-ex/0007036)[ex/0007036](http://arxiv.org/abs/hep-ex/0007036)].
- [131] K. Adcox et al. [PHENIX Collaboration], Phys. Rev. Lett. 88, 242301 (2002) [\[arXiv:nucl](http://arxiv.org/abs/nucl-ex/0112006)[ex/0112006](http://arxiv.org/abs/nucl-ex/0112006)]; Phys. Rev. Lett. 86, 3500 (2001) [\[arXiv:nucl-ex/0012008](http://arxiv.org/abs/nucl-ex/0012008)]; Phys. Rev. Lett. 87, 052301 (2001)[[arXiv:nucl-ex/0104015](http://arxiv.org/abs/nucl-ex/0104015)].
- [132] B. Back. et. al. Phys. Lett. B578, 297 (2004); C. Adler et. al. Phys. Rev. Lett. 89 202301, (2002).
- [133] D. Kharzeev, E. Levin and L. McLerran, Phys. Lett. B561, 93 (2003)
- [134] J. D. Bjorken, Fermilab-Pub-82-059-THY; D. Appell, Phys. Rev. D33, 717 (1986);M. Gyulassy and M. Plumer, Phys. Lett. B243, 432 (1990); M. Gyulassy, M. Plumer, M. Thoma and X. N. Wang, Nucl. Phys. A538, 37C (1992);
- [135] I. Arsene et. al. Phys. Rev. Lett. 91, 072305 (2003); B. Back et. al. Phys. Rev. Lett. 91, 072302 (2003); S.S. Adler et al., Phys. Rev. Lett. 91 , 072303 (2003); J. Adams, Phys. Rev. Lett. 91, 072304 (2003); M. Gyulassy, I. Vitev and X. N. Wang, Phys. Rev. Lett. 86, 2537 (2001)
- [136] A. Dumitru and J. Jalilian-Marian, Phys.Lett. B547, 15 (2002); Phys.Rev.Lett.89,022301(2002)
- [137] F. Gelis and J. Jalilian-Marian, Phys.Rev. D67, 074019 (2003).
- [138] I. Vitev and M. Gyulassy, Phys. Rev. Lett. 89, 252 (2002); M. Gyulassy, P. Levai and I. Vitev, Phys. Rev. D66, 014005 (2002); Nucl. Phys. B594, 371 (2001); Nucl. Phys. B571, 197 (2000) I. Vitev, Phys. Lett. B562, 36 (2003).
- [139] D. Kharzeev, Y. Kovchegov and K. Tuchin, Phys.Rev. D68, 094013 (2003).
- [140] R. Baier, A. Kovner and U. Wiedemann, Phys.Rev. D68, 054009 (2003).
- [141] J. Albacete, N. Armesto, A. Kovner, C. Salgado and U. Wiedemann, [hep-ph/0307179](http://arxiv.org/abs/hep-ph/0307179)
- [142] I. Arsene et al. [BRAHMS Collaboration], [arXiv:nucl-ex/0403005](http://arxiv.org/abs/nucl-ex/0403005).
- [143] Zhangbu Xu for the Star Collaboration at Quark Matter 2004.
- [144] Rachid Noucier for the Phobos Collaboration;
- [145] Talks presented at Quark Matter 2004: R. G de Cassagnac for the Phenix Collaboration at Quark Matter 2004, M. X. Liu for the Phenix Collaboration;

![](_page_36_Figure_0.jpeg)