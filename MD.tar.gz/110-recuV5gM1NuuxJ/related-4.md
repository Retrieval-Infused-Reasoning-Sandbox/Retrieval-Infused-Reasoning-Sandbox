## **MOMENTUM SPACE - HARMONIC OSCILLATOR**

Link to: physicspages home page.

To leave a comment or report an error, please use the auxiliary blog and include the title or URL of this post in your comment.

Post date: 25 July 2021.

We've seen that any function g(x) can be expressed in terms of the eigenfunctions  $f_p(x)$  of the momentum operator, in the sense that, for a function g(x) we can write

$$g(x) = \int_{-\infty}^{\infty} c(p) f_p(x) dp$$
 (1)

$$= \frac{1}{\sqrt{2\pi\hbar}} \int_{-\infty}^{\infty} c(p) e^{ipx/\hbar} dp \tag{2}$$

where c(p) is the inverse Fourier transform:

$$c(p) = \frac{1}{\sqrt{2\pi\hbar}} \int_{-\infty}^{\infty} g(x) e^{-ipx/\hbar} dx \tag{3}$$

$$= \langle f_p | g \rangle \tag{4}$$

If g is a wave function  $\Psi(x,t)$ , we can view c(p,t) as the momentumspace wave function, often given the symbol  $\Phi(p,t)$ . That is

$$\Phi(p,t) = \frac{1}{\sqrt{2\pi\hbar}} \int_{-\infty}^{\infty} \Psi(x,t) e^{-ipx/\hbar} dx$$
 (5)

An example is the ground state wave function for the harmonic oscillator:

$$\psi_0(x,t) = \left(\frac{m\omega}{\pi\hbar}\right)^{1/4} e^{-m\omega x^2/2\hbar} e^{-i\omega t/2} \tag{6}$$

Using a couple of shorthand parameters for simplicity:  $\alpha \equiv (m\omega/\pi\hbar)^{1/4}$ ;  $\beta \equiv m\omega/2\hbar$ , we can get the momentum space function:

$$\Phi_0(p,t) = \frac{\alpha e^{-i\omega t/2}}{\sqrt{2\pi\hbar}} \int_{-\infty}^{\infty} e^{-ipx/\hbar} e^{-\beta x^2} dx \tag{7}$$

$$=\frac{e^{-i\omega t/2}}{(\pi m\omega \hbar)^{1/4}}e^{-p^2/2\hbar m\omega} \tag{8}$$

Here we have used Maple to do the integral, and simplified the result by expanding  $\alpha$  and  $\beta$ . Note that although the integrand contains a complex exponential, the result is real. This is because the imaginary part of the integrand is the product of an odd function  $(\sin(px/\hbar))$  and an even function  $(e^{-\beta x^2})$  so it will integrate to zero over any interval symmetric about the origin.

To find the probability that the momentum is outside the classical range, we note that the ground state energy is  $E_0=\hbar\omega/2$ , so the maximum ground state momentum is  $p_0=\sqrt{2mE_0}=\sqrt{m\hbar\omega}$ . The classical momentum thus ranges from  $-\sqrt{m\hbar\omega}$  to  $\sqrt{m\hbar\omega}$ . The probability that the quantum momentum is outside this range is therefore

$$Prob = 2\int_{\sqrt{m\hbar\omega}}^{\infty} |\Phi_0(x,t)|^2 dp \tag{9}$$

$$= \frac{2}{\sqrt{\pi m \hbar \omega}} \int_{\sqrt{m \hbar \omega}}^{\infty} e^{-p^2/m \hbar \omega} dp \tag{10}$$

$$= 1 - \operatorname{erf}(1) \tag{11}$$

$$=0.1573$$
 (12)

The integral and evalution were done using Maple. Here, erf is the error function, defined as:

$$\operatorname{erf}(x) \equiv \frac{2}{\sqrt{\pi}} \int_0^x e^{-t^2} dt \tag{13}$$

You might wonder why the momentum doesn't have a fixed value, since in the ground state, the energy is fixed. The energy, however, is composed of kinetic and potential parts, and the momentum is derived from the kinetic part, which varies as the position of the particle varies. Still, it's quite odd that the quantum momentum has a non-zero probability of being greater than any finite value, no matter how large.

## **PINGBACKS**

Pingback: Hamiltonian matrix elements

Pingback: Infinite square well - momentum space wave functions