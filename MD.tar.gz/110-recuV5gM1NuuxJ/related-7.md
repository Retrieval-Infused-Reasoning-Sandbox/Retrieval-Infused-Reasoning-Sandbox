## Enhanced production of $\psi(2S)$ mesons in heavy ion collisions

Sungtae Cho

Institute of Physics and Applied Physics, Yonsei University, Seoul 120-749, Korea

We study the production of a  $\psi(2S)$  meson in heavy ion collisions. We evaluate Wigner functions for the  $\psi(2S)$  meson using both Gaussian and Coulomb wave functions, and investigate the wave function dependence in the  $\psi(2S)$  meson production by recombination of charm and anti-charm quarks. The enhanced transverse momentum distribution of  $\psi(2S)$  mesons compared to that of  $J/\psi$  mesons, originated from wave function distributions of the  $\psi(2S)$  and  $J/\psi$  meson in momentum space, provides a plausible explanation for the recent measurement of the nuclear modification factor ratio between the  $\psi(2S)$  and  $J/\psi$  meson.

PACS numbers: 14.40.Pq, 25.75.Dw, 25.75.-q

Since  $J/\psi$  suppression was proposed as a possible signature for the formation of a system of deconfined quarks and gluons, the so called quark-gluon plasma (QGP) [1]  $J/\psi$  has been one of standard probes in understanding many aspects of heavy ion collision experiments. Moreover, its excited states as well have become important probes of the QGP since they are expected to melt sequentially in the medium due to their different binding energies, and therefore they can play important roles in investigating the properties of the QGP [2–4].

One of the important measures for the effects of the QGP on the  $J/\psi$  production is a nuclear modification factor  $R_{AA}$ , defined as the ratio of the yield of a hadron in heavy ion collisions to that in p+p collisions scaled by the number of binary collisions. Measurements of the  $J/\psi$   $R_{AA}$  at the Relativistic Heavy Ion Collider (RHIC) show that the  $J/\psi$  production is suppressed significantly in heavy ion collisions, and the  $R_{AA}^{J/\psi}$  decreases with the increasing centrality [5]. Although we still observe the  $J/\psi$  suppression at higher energies, we see the noticeable difference in the  $R_{AA}^{J/\psi}$  dependence on the centrality; the  $R_{AA}$  for  $J/\psi$  mesons measured at the Large Hadron Collider (LHC) is independent of the collision centrality at forward rapidity [6, 7].

The less suppression of  $J/\psi$  mesons at LHC supports possibilities of  $J/\psi$  production from charm quarks in the QGP [8–10]. The larger charm quark density at LHC compared to that at RHIC results in enhanced chances for the formation of  $J/\psi$  from the QGP. Moreover, the strong  $J/\psi$  suppression at high transverse momentum  $p_T$  measured by CMS [11] together with the  $R_{AA}^{J/\psi}$  at low  $p_T$  measured by ALICE [7] and the measurement of  $J/\psi$  elliptic flows at LHC [12] provide solid evidences for the  $J/\psi$  production from charm quarks by recombination.

In addition, the measurement of the  $\psi(2S)$   $R_{AA}$  relative to the  $R_{AA}^{J/\psi}$  at LHC provides chances to investigate the production of charmonium states from the QGP. The less suppression of the  $\psi(2S)$  than in p+p collisions compared to the  $J/\psi$  with the increasing centrality recently measured by CMS [13] has not been clearly understood. In this work we argue that the increased double ratio

 $R_{AA}^{\psi(2S)}/R_{AA}^{J/\psi}$  at central collisions is also due to their production from charm quarks by recombination.

The recombination picture describes the formation of hadrons as the process of coalescing constituent quarks in the QGP into hadrons using phase space density functions of the constituents and of the produced hadron, or the Wigner distribution functions composed of the overlap between wave functions. Attentions paid to the production of hadrons from constituent quarks at low and intermediate  $p_T$  have leaded to the explanation of the quark number scaling of elliptic flows of identified hadrons [14] as well as the enhanced production of baryons at midrapidity [15–18].

In the recombination process, on the other hand, when different hadrons are produced from same constituents, hadron Wigner distributions become important, and play central roles in describing the properties of produced hadrons. The production of charmonium states from same charm quark distributions in the QGP by recombination is such case. We study here the hadron wave function dependence in charmonium production while we investigate the production of  $\psi(2S)$  mesons.

As simple forms of the wave function, the Gaussiantype functions have been used in many literatures. In particular, the Gaussian-type Wigner function made up of simple harmonic oscillator wave functions reflects the hadron size through the oscillator frequency of the wave function  $\omega$ , and takes into account an orbital excitation of the produced hadron by introducing s-, p- [19], and d-wave [20] harmonic oscillator wave functions,

<span id="page-0-0"></span>
$$\begin{split} W_s(\vec{r}, \vec{k}) &= 8e^{-\frac{r^2}{\sigma^2} - k^2 \sigma^2} \\ W_p(\vec{r}, \vec{k}) &= \left(\frac{16}{3} \frac{r^2}{\sigma^2} - 8 + \frac{16}{3} \sigma^2 k^2\right) e^{-\frac{r^2}{\sigma^2} - k^2 \sigma^2} \\ W_d(\vec{r}, \vec{k}) &= \frac{8}{15} \left(4 \frac{r^4}{\sigma^4} - 20 \frac{r^2}{\sigma^2} + 15 - 20 \sigma^2 k^2 + 4 \sigma^4 k^4 + 16 r^2 k^2 - 8 (\vec{r} \cdot \vec{k})^2\right) e^{-\frac{r^2}{\sigma^2} - k^2 \sigma^2}, \end{split}$$
(1)

where  $\sigma^2 = 1/(\mu\omega)$  with the reduced mass  $\mu$ .

We apply here the above Gaussian Wigner function to describe the formation of  $J/\psi$  and  $\chi_c$  mesons. Fur-

thermore, we construct also Wigner functions based on Coulomb wave functions since we expect that the wave function of the charmonium states formed through a color cental potential between charm and anti-charm quarks is closer to the color Coulomb wave function governed by a chromo-electric field rather than the Gaussian wave function based on the simple harmonic oscillator potential. We investigate the formation of charmonium states based on both Gaussian and Coulomb Wigner functions, and explain the enhanced production of the loosely bound charmonium state, the  $\psi(2S)$  compared to the  $J/\psi$  at the most central heavy ion collisions.

Wigner functions based on Coulomb wave functions have been unclear until recently despite the well-known analytic form of Coulomb wave functions. The systematic way of generating Wigner functions for arbitrary states of hydrogen atom has been presented in 2006 [21]. The key idea is to evaluate them in momentum space using the Feynman parametrization. Two joint Coulomb wave functions in momentum space resemble the multiplication of two propagators often met in field theory.

We sketch below the method introduced in Ref. [21], and present explicit 1s and 2s Wigner functions constructed from Coulomb wave functions. We begin with the Wigner function defined as

<span id="page-1-0"></span>
$$W_{\psi}(\vec{r}, \vec{k}) = \int d^{3}\vec{q}\psi^{*}(\vec{r} + \vec{q}/2)e^{i\vec{k}\cdot\vec{q}}\psi(\vec{r} - \vec{q}/2)$$
$$= \int \frac{d^{3}\vec{q}}{(2\pi)^{3}}\tilde{\psi}^{*}(\vec{k} + \vec{q}/2)e^{-i\vec{r}\cdot\vec{q}}\tilde{\psi}(\vec{k} - \vec{q}/2), (2)$$

which has been normalized to satisfy the condition  $\int W_{\psi}(\vec{r}, \vec{k}) d^3 \vec{r} d^3 \vec{k} = (2\pi)^3$ . After plugging the wave func-

tion of the ground state in momentum representation  $\tilde{\psi}_{1S}(\vec{k}) = 8\sqrt{\pi}a_0^{3/2}/(1+k^2a_0^2)^2$  into Eq. (2) we get

$$W_{\psi_{1S}}(\vec{r}, \vec{k}) = \frac{64}{\pi^2 a_0^5} \int d^3 \vec{q}' \frac{e^{-2i\vec{r}\cdot(\vec{q}'-\vec{k})}}{(1/a_0^2 + \vec{q'}^2)^2 (1/a_0^2 + (\vec{q}' - 2\vec{k})^2)^2} (3)$$

With the help of the Feynman parametrization,

$$\frac{1}{A^{\alpha}B^{\beta}} = \frac{\Gamma(\alpha+\beta)}{\Gamma(\alpha)\Gamma(\beta)} \int_0^1 du \frac{u^{\alpha-1}(1-u)^{\beta-1}}{(Au+B(1-u))^{\alpha+\beta}}, \quad (4)$$

we disentangle the denominator and obtain

$$W_{\psi_{1S}}(\vec{r}, \vec{k}) = \frac{64}{\pi^2 a_0^5} \Gamma(4) \int_0^1 du u (1 - u) e^{-2i(1 - 2u)\vec{r} \cdot \vec{k}} \times \int d^3 \vec{s} \frac{e^{-2i\vec{r} \cdot \vec{s}}}{(s^2 + 1/a_0^2 + 4u(1 - u)k^2)^4},$$
 (5)

where the change of a variable from  $\vec{q}'$  to  $\vec{s} = \vec{q}' - 2(1 - u)\vec{k}$  has been made. We carry out the integration over  $\vec{s}$  analytically, and finally get

<span id="page-1-2"></span>
$$W_{\psi_{1S}}(\vec{r}, \vec{k}) = \frac{16}{a_0^5} \int_0^1 du u (1 - u) e^{-2i(1 - 2u)\vec{k} \cdot \vec{r}} e^{-2rC(u)} \times \left(\frac{3}{C(u)^5} + \frac{6}{C(u)^4} r + \frac{4}{C(u)^3} r^2\right), \tag{6}$$

with  $C(u) = (1/a_0^2 + 4u(1-u)k^2)^{1/2}$ . Similarly, with the second excited state wave function in momentum representation,  $\tilde{\psi}_{2S}(\vec{k}) = \sqrt{\pi}(2a_0)^{3/2}(k^2a_0^2 - 1/4)/(k^2a_0^2 + 1/4)^3$  we obtain

<span id="page-1-3"></span>
$$W_{\psi_{2S}}(\vec{r}, \vec{k}) = \frac{1}{32a_0^9} \int_0^1 du u^2 (1-u)^2 e^{-2i(1-2u)\vec{k}\cdot\vec{r}} \left(\frac{105}{D(u)^9} + \frac{210}{D(u)^8} r + \frac{180}{D(u)^7} r^2 + \frac{80}{D(u)^6} r^3 + \frac{16}{D(u)^5} r^4\right) e^{-2rD(u)}$$

$$-\frac{1}{4a_0^7} \int_0^1 du u (1-u) e^{-2i(1-2u)\vec{k}\cdot\vec{r}} \left(\frac{15}{D(u)^7} + \frac{30}{D(u)^6} r + \frac{24}{D(u)^5} r^2 + \frac{8}{D(u)^4} r^3\right) e^{-2rD(u)}$$

$$+\frac{2}{a_0^5} \int_0^1 du u (1-u) e^{-2i(1-2u)\vec{k}\cdot\vec{r}} \left(\frac{3}{D(u)^5} + \frac{6}{D(u)^4} r + \frac{4}{D(u)^3} r^2\right) e^{-2rD(u)}, \tag{7}$$

with 
$$D(u) = (1/(2a_0)^2 + 4u(1-u)k^2)^{1/2}$$
.

We also construct the 2s state Wigner function using a Gaussian wave function. The proper wave function would be  $\psi_{10} = \sqrt{2/3}(1/\pi\sigma^2)^{3/4}e^{-r^2/2\sigma^2}(-r^2/\sigma^2+3/2)$ , where the subscript 10 in  $\psi$  represents the quantum number kl in the 3-dimensional harmonic oscillator satisfying  $E_n = (n+3/2)\hbar\omega = (2k+l+3/2)\hbar\omega$ .  $\psi_{10}$  is the first excited state of the ground state  $\psi_{00}$  with the lowest angular momentum, and therefore can play a role of the wave function for the  $\psi(2S)$  meson. From the definition of the

Wigner function, Eq. (2), we get

<span id="page-1-1"></span>
$$W_{\psi_{10}}(\vec{r}, \vec{k}) = \frac{16}{3} \left( \frac{r^4}{\sigma^4} - 2\frac{r^2}{\sigma^2} + \frac{3}{2} - 2\sigma^2 k^2 + \sigma^4 k^4 - 2r^2 k^2 + 4(\vec{r} \cdot \vec{k})^2 \right) e^{-\frac{r^2}{\sigma^2} - k^2 \sigma^2}.$$
 (8)

The Wigner function for  $\psi_{10}$ , Eq. (8) is very similar in form to  $W_d(\vec{r}, \vec{k})$ , Eq. (1). This must be due to degenerate energy states between the d-wave state (k=0, l=2) and the first excited state of the s-wave state (k=1, l=0)

in the 3-dimensional harmonic oscillator.

Using these Wigner functions we evaluate the transverse mometum distribution of charmonia,  $J/\psi$ ,  $\chi_c$ , and  $\psi(2S)$  mesons produced from charm and anti-charm quarks by recombination. We start with the basic equation in the coalescence model [16],

$$N_{\psi} = g_{\psi} \int p_{c} \cdot d\sigma_{c} p_{\bar{c}} \cdot d\sigma_{\bar{c}} \frac{d^{3} \vec{p}_{c}}{(2\pi)^{3} E_{c}} \frac{d^{3} \vec{p}_{\bar{c}}}{(2\pi)^{3} E_{\bar{c}}} \times f_{c}(r_{c}, p_{c}) f_{\bar{c}}(r_{\bar{c}}, p_{\bar{c}}) W_{\psi}(r_{c}, r_{\bar{c}}; p_{c}, p_{\bar{c}}),$$
(9)

with space-like hypersurface elements  $d\sigma$  and covariant distribution functions for a(n) (anti-)charm quark  $f_{c(\bar{c})}(r,p)$  satisfying the normalization condition  $\int p \cdot d\sigma d^3\vec{p}/((2\pi)^3E)f_{c(\bar{c})}(r,p) = N_{c(\bar{c})}$ , the number of (anti-)charm quarks available in the system. The statistical factor  $g_{\psi}$  accounts for the possibility of forming a charmonium from constituent quarks, e.g.,  $g_{J/\psi} = 3/36$ . When the non-relativistic limit is taken, the above equation is reduced to [15, 16, 22]

<span id="page-2-0"></span>
$$\frac{d^{2}N_{\psi}}{d^{2}\vec{p}_{T}} = \frac{g_{\psi}}{V} \int d^{3}\vec{r}d^{2}\vec{p}_{cT}d^{2}\vec{p}_{\bar{c}T}\delta^{(2)}(\vec{p}_{T} - \vec{p}_{cT} - \vec{p}_{\bar{c}T}) 
\times \frac{d^{2}N_{c}}{d^{2}\vec{p}_{cT}} \frac{d^{2}N_{\bar{c}}}{d^{2}\vec{p}_{\bar{c}T}} W_{\psi}(\vec{r}, \vec{k}),$$
(10)

under the assumption that the longitudinal momentum distributions of (anti-)charm quarks are boost-invariant and they satisfy the Bjorken correlation between spatial and momentum rapidities,  $\eta=y$ . In Eq. (10)  $\vec{r}$  and  $\vec{k}$  are, respectively, the distance and the relative momentum between two charm quarks. We apply here Wigner functions, Eqs. (1), (8), (6), and (7), and carry out the integration over  $\vec{r}$ :

<span id="page-2-1"></span>
$$\int d^{3}\vec{r}W_{\psi}(\vec{r},\vec{k}) 
= \begin{cases}
(2\sqrt{\pi}\sigma)^{3}e^{-k^{2}\sigma^{2}} & \psi_{s}^{G}; J/\psi \\
\frac{2}{3}(2\sqrt{\pi}\sigma)^{3}e^{-k^{2}\sigma^{2}}\sigma^{2}k^{2} & \psi_{p}^{G}; \chi_{c} \\
\frac{2}{3}(2\sqrt{\pi}\sigma)^{3}e^{-k^{2}\sigma^{2}}\left(\sigma^{2}k^{2} - \frac{3}{2}\right)^{2} & \psi_{10}^{G}; \psi(2S) (11) \\
64\pi \frac{a_{0}^{3}}{(a_{0}^{2}k^{2} + 1)^{4}} & \psi_{1S}^{C}; J/\psi \\
8\pi a_{0}^{3}\frac{(a_{0}^{2}k^{2} - 1/4)^{2}}{(a_{0}^{2}k^{2} + 1/4)^{6}} & \psi_{2S}^{C}; \psi(2S)
\end{cases}$$

where the superscript G and C are denoted by, respectively, the Gaussian and Coulomb hadron wave functions used in the Wigner function.

As we clearly see in Eq. (11), we get surprisingly simple results from such complicated Wigner functions, Eqs. (6) and (7). We further notice that the Wigner function for s-wave states becomes, after the analytic integration over  $\vec{r}$ , the absolute value square of each wave function in momentum representation;  $|\tilde{\psi}_s(\vec{k})|^2 = (2\sqrt{\pi}\sigma)^3 e^{-k^2\sigma^2}$ ,  $|\tilde{\psi}_{10}(\vec{k})|^2 = 2/3(2\sqrt{\pi}\sigma)^3 e^{-k^2\sigma^2}(\sigma^2 k^2 - 3/2)^2$ ,  $|\tilde{\psi}_{1S}(\vec{k})|^2 = 64\pi a_0^3/(a_0^2 k^2 + 1)^4$ , and  $|\tilde{\psi}_{2S}(\vec{k})|^2 = 8\pi a_0^3(a_0^2 k^2 - 1/4)^2/(a_0^2 k^2 + 1/4)^6$ . From this we deduce the

general relation  $\int d^3\vec{r}W_{\psi_l}(\vec{r},\vec{k}) = 1/(2l+1)\sum_{-l}^l |\tilde{\psi}_l(\vec{k})|^2$ , which is a new way of evaluating Wigner functions purely from hadron wave functions without resorting to the definition of the Wigner function, Eq. (2) when the integration of the Wigner function over space is necessary.

As has been discussed in Ref. [20], we omit the contribution from the longitudinal momentum in the Wigner function at midrapidities, y=0; the relative momentum between charm quarks becomes,  $\vec{k} = (\vec{p}_{cT}' - \vec{p}_{\bar{c}T}')/2$  with  $\vec{p}_{cT}'$  and  $\vec{p}_{\bar{c}T}'$  being the transverse momenta in the charmonium frame [22, 23]. We suppose that the hadronization volume V is 1000 (2700) fm<sup>3</sup> for central Au+Au (Pb+Pb) collisions at  $\sqrt{s_{NN}}$  =200 GeV (2.76 TeV) at RHIC (LHC), respectively. The oscillator frequency  $\omega$ for the Gaussian Wigner function has been determined for each charmonium from the relation between the mean square distance and  $\sigma$ ;  $\langle r^2 \rangle_{J/\psi} = 3/2\sigma_{J/\psi}^2$ ,  $\langle r^2 \rangle_{\chi_c} = 5/2\sigma_{\chi_c}^2$ , and  $\langle r^2 \rangle_{\psi(2S)} = 7/2\sigma_{\psi(2S)}^2$ . Using the quark separation distances  $r_0=0.50$ , 0.72, and 0.90 fm [2] we obtain oscillator frequencies 311.4, 250.3, and 224.3 MeV, respectively, for  $J/\psi$ ,  $\chi_{c1}$ , and  $\psi(2S)$ . For the Coulomb Wigner functions  $a_0$  has been obtained from the relation between  $\langle r^2 \rangle$  and  $a_0$  for both  $J/\psi$  and  $\psi(2S)$  mesons;  $\langle r^2 \rangle = 3a_0^2$ for  $J/\psi$  and  $42a_0^2$  for  $\psi(2S)$ . Using the same  $r_0$  we get  $a_0^{J/\psi}$  = 0.289 fm, and  $a_0^{\psi(2S)}$  = 0.139 fm.

We use the  $p_T$  spectrum of charm quarks for RHIC  $\sqrt{s_{NN}}$ =200 GeV,  $d^2N_c/d^2\vec{p}_T=19.2(1+p_T^2/36)/(1+p_T/3.7)^{12}/(1+e^{0.9-2p_T})(0.8e^{-p_T/1.2}+0.6e^{-p_T/15})$  [22], obtained from heavy quark  $p_T$  distribution in p+p collisions at the same energy both scaled by number of binary collisions and multiplied by the heavy quark energy loss estimation. Since there is no charm quark  $p_T$  distribution at hadronization available for LHC, we apply the initial charm quark  $p_T$  distribution,  $dN_c/dp_T=p_T/(1+0.379p_T^2)^{5.881}$  [24], obtained from a fit to PYTHIA evaluations for LHC  $\sqrt{s_{NN}}$ =2.76 TeV. The  $p_T$  is in unit of GeV at both distributions. Using these with Eq. (11) we evaluate Eq. (10) produced by recombination without feed-down contributions, and show the results in Fig. 1.

We obtain the  $p_T$  distribution for the p-wave state, the  $\chi_{c1}$  smaller than that of the s-wave state, the  $J/\psi$ . On the other hand, we get the large  $p_T$  distribution of the excited state, the  $\psi(2S)$ , compared to that of the ground state from both Gaussian and Coulomb Wigner functions. The discrepancy is more significant when Coulomb Wigner functions have been applied. We also show in the inset of Fig. 1 the ratio of the  $p_T$  spectrum between the  $\psi(2S)$  and  $J/\psi$  meson after considering prompt  $J/\psi$  mesons,  $d^2N_{\psi(2S)^C(G)}/d^2\vec{p}_T/d^2N_{J/\psi^C(G)}^{\rm prompt}/d^2\vec{p}_T$ , by assuming that the  $p_T$  spectrum of the daughter  $J/\psi$  meson is same as that of the excited states after their decays;  $d^2N_{J/\psi^C(G)}^{\rm prompt}/d^2\vec{p}_T = d^2N_{J/\psi^C(G)}/d^2\vec{p}_T + 0.348 \ d^2N_{\chi_{c1}^G}/d^2\vec{p}_T + 0.198 \ d^2N_{\chi_{c2}^G}/d^2\vec{p}_T + 0.603 \ d^2N_{\psi(2S)^C(G)}/d^2\vec{p}_T$  [25]. We see that the  $p_T$  distribution of the  $\psi(2S)$  are comparable to that of the  $J/\psi$  at both RHIC and LHC.

![](_page_3_Figure_1.jpeg)

![](_page_3_Figure_2.jpeg)

<span id="page-3-8"></span>FIG. 1:  $dN_{\psi}/dp_{T}$  of charmonia produced form charm and anti-charm quarks by recombination for  $\sqrt{s_{NN}}$ =200 GeV at RHIC (a) and for  $\sqrt{s_{NN}}$ =2.76 TeV at LHC (b). The ratio of  $p_{T}$  spectrum between  $\psi(2S)$  and prompt  $J/\psi$  mesons is shown in the inset.

The  $p_T$  spectrum of the  $\psi(2S)$  is expected to be smaller than that of the  $J/\psi$  since the  $\psi(2S)$  is heavier than the  $J/\psi$  by about 600 MeV. We have found that the enhanced  $\psi(2S)$  production compared to the  $J/\psi$  shown in Fig. 1 is attributable to the relative distribution of their wave functions in momentum space. We remind that the wave function of excited states is spread in space more broadly than that of the ground state. In other words, the Coulomb wave function of the  $\psi(2S)$  is more localized around the origin in momentum space than that of the  $J/\psi$ , Eq. (11), leading to the larger  $p_T$  distribution for  $\psi(2S)$  mesons compared to  $J/\psi$  mesons when produced from charm quarks by recombination. On the other hand, Gaussian wave functions in space are again Gaussian in momentum space, and therefore distributions in wave functions of excited states in space are preserved also in momentum space, resulting in the smaller  $p_T$  distribution for the p-wave state  $\chi_{c1}$ . The Gaussian wave function of the  $\psi(2S)$  is spread further in momentum space,

but the part of its wave function localized between the origin and the node in momentum space plays a significant role, contributing to the similar  $p_T$  distribution of the  $\psi(2S)$  compared to that of the  $J/\psi$ .

The real wave functions of charmonium states would be neither Gaussian nor Coulomb wave functions. The harmonic oscillator potential is strongly confining ( $\propto r^2$ ) whereas the Coulomb potential is loosely confining ( $\propto r^{-1}$ ). Two results shown in Fig. 1, therefore, provide references to experimental measurements of the  $p_T$  distribution ratio between  $J/\psi$  and  $\psi(2S)$  mesons resulted from Coulomb and linear potentials between charm quarks. We expect the study of  $p_T$  distributions of charmonium states to provide one way of understanding the potential between charm quarks.

In summary, we have studied the  $\psi(2S)$  meson production by recombination of charm quarks in heavy ion collisions. We have evaluated Wigner functions for the  $\psi(2S)$  meson from both Gaussian and Coulomb wave functions, and have investigated the wave function dependence of the  $p_T$  distribution. We have found that the  $p_T$  spectrum of  $\psi(2S)$  mesons is similar or larger compared to that of  $J/\psi$  mesons due to their intrinsic wave function differences in space. We suggest that the enhanced  $p_T$  spectrum of the  $\psi(2S)$  meson originated from its wave function can present one way of understanding the increased ratio of the  $R_{AA}$  between  $J/\psi$  and  $\psi(2S)$ mesons with centrality, recently measured at  $3 < p_T <$ 30 GeV in 1.6 < |y| < 2.4 by CMS Collaboration [13]. We expect the precise measurements of the same  $R_{AA}$ ratio at midrapidity in the future to confirm the  $\psi(2S)$ production by recombination along with the dependence of charmonia production on their wave functions.

Acknowledgements We are grateful to Su Houng Lee for fruitful discussions. This work was supported by the Korean Ministry of Education through the BK21 PLUS program.

- <span id="page-3-0"></span>[1] T. Matsui and H. Satz, Phys. Lett. B 178, 416 (1986)
- <span id="page-3-1"></span>[2] H. Satz, J. Phys. G **32**, R25 (2006)
- [3] F. Karsch, D. Kharzeev and H. Satz, Phys. Lett. B 637, 75 (2006)
- <span id="page-3-2"></span>[4] A. Mocsy and P. Petreczky, Phys. Rev. Lett. 99, 211602 (2007)
- <span id="page-3-3"></span>[5] A. Adare *et al.* (STAR Collaboration), Phys. Rev. Lett. 98, 232301 (2005).
- <span id="page-3-4"></span>[6] B. Abelev et al. (ALICE Collaboration), Phys. Rev. Lett. 109, 072301 (2012).
- <span id="page-3-5"></span>[7] B. Abelev et al. (ALICE Collaboration), Phys. Lett. B 743, 314 (2014).
- <span id="page-3-6"></span>[8] P. Braun-Munzinger and J. Stachel, Phys. Lett. B 490, 196 (2000).
- [9] R. L. Thews, M. Schroedter and J. Rafelski, Phys. Rev. C 63, 054905 (2001).
- <span id="page-3-7"></span>[10] A. Andronic, P. Braun-Munzinger, K. Redlich and J.

- Stachel, Phys. Lett. B 652, 259 (2007).
- <span id="page-4-0"></span>[11] S. Chatrchyan et al. (CMS Collaboration), JHEP 1205, 063 (2012).
- <span id="page-4-1"></span>[12] E. Abbas  $et\ al.$  (ALICE Collaboration), Phys. Rev. Lett.  ${\bf 111},\ 162301$  (2013).
- <span id="page-4-2"></span>[13] CMS Collaboration, CMS PAS HIN-12-007.
- <span id="page-4-3"></span>[14] D. Molnar and S. A. Voloshin, Phys. Rev. Lett. 91, 092301 (2003).
- <span id="page-4-4"></span>[15] V. Greco, C. M. Ko, and P. Levai, Phys. Rev. Lett. 90, 202302 (2003).
- <span id="page-4-9"></span>[16] V. Greco, C. M. Ko, and P. Levai, Phys. Rev. C 68, 034904 (2003).
- [17] R. J. Fries, B. Muller, C. Nonaka, and S. A. Bass, Phys. Rev. Lett. 90, 202303 (2003).
- <span id="page-4-5"></span>[18] R. J. Fries, B. Muller, C. Nonaka, and S. A. Bass, Phys.

- Rev. C 68, 044902 (2003).
- <span id="page-4-6"></span>[19] A. J. Baltz and C. Dover, Phys. Rev. C 53, 362 (1996).
- <span id="page-4-7"></span>[20] S. Cho et al. (ExHIC Collaboration), Phys. Rev. C 84, 064910 (2011).
- <span id="page-4-8"></span>[21] L. Praxmeyer, J. Mostowski, and K. Wodkiewicz, J. Phys. A: Math. Gen. 39, 14143 (2006).
- <span id="page-4-10"></span>[22] Y. Oh, C. M. Ko, S. H. Lee, and S. Yasui, Phys. Rev. C 79, 044905 (2009).
- <span id="page-4-11"></span>[23] R. Scheibl and U. W. Heinz, Phys. Rev. C 59, 1585 (1999).
- <span id="page-4-12"></span>[24] T. Lang, H. van Hees, J. Steinheimer and M. Bleicher, arXiv:1305.7377 [hep-ph].
- <span id="page-4-13"></span>[25] J. Beringer et al. (Particle Data Group Collaboration), Phys. Rev. D 86, 010001 (2012).