## HARMONIC OSCILLATOR IN 3-D SPHERICAL COORDINATES

Link to: physicspages home page.

To leave a comment or report an error, please use the auxiliary blog and include the title or URL of this post in your comment.

Post date: 12 September 2021.

The 3-d harmonic oscillator can also be solved in spherical coordinates. Since the potential is a function of r only, the angular part of the solution is a spherical harmonic.

To solve the radial equation we substitute the potential  $V(r) = \frac{1}{2}m\omega^2 r^2$ .

$$-\frac{\hbar^2}{2m}\frac{d^2u}{dr^2} + \left(\frac{1}{2}m\omega^2r^2 + \frac{\hbar^2}{2m}\frac{l(l+1)}{r^2}\right)u = Eu\tag{1}$$

Using the treatment of the hydrogen atom as a guide we can proceed as follows. First, define  $\kappa^2 = 2mE/\hbar^2$  (note that E is positive for all states, and  $\kappa$  has dimensions of length<sup>-1</sup>) and divide through to get

$$\frac{1}{\kappa^2} \frac{d^2 u}{dr^2} - \left(\frac{l(l+1)}{(\kappa r)^2} + \frac{m^2 \omega^2}{\hbar^2 \kappa^4} (\kappa r)^2\right) u = -u \tag{2}$$

We now define

$$\rho \equiv \kappa r \tag{3}$$

$$\rho_0 \equiv \frac{m\omega}{\hbar\kappa^2} \tag{4}$$

Note that both  $\rho$  and  $\rho_0$  are dimensionless. With these definitions, we get

<span id="page-0-0"></span>
$$\frac{d^2u}{d\rho^2} = \left(-1 + \frac{l(l+1)}{\rho^2} + \rho_0^2 \rho^2\right)u\tag{5}$$

Now we need to investigate the behaviour of u for  $\rho \to \infty$  and  $\rho \to 0$ . From 5, as  $\rho \to \infty$ , the  $\rho^2$  term dominates and the equation becomes

$$\frac{d^2u}{d\rho^2} \approx \rho_0^2 \rho^2 u \tag{6}$$

We can get the solution to this approximate equation

$$u \approx Ae^{-\rho_0\rho^2/2} + Be^{\rho_0\rho^2/2}$$
 (7)

for some constants A and B. The second term is not normalizable, so we take B = 0.

This works as an approximate solution because

$$\frac{du}{d\rho} = -\rho_0 \rho A e^{-\rho_0 \rho^2/2} \tag{8}$$

$$\frac{d^2u}{d\rho^2} = Ae^{-\rho_0\rho^2/2} \left( -\rho_0 + \rho_0^2 \rho^2 \right) \tag{9}$$

For large ρ, the last term is approximately Aρ<sup>2</sup> 0 ρ 2 e −ρ0ρ <sup>2</sup>/<sup>2</sup> = ρ 2 0 ρ <sup>2</sup>u. For ρ → 0, the ρ −2 term dominates and we get

$$\frac{d^2u}{d\rho^2} \approx \frac{l(l+1)}{\rho^2}u\tag{10}$$

which has the normalizable solution

$$u \approx C\rho^{l+1} + D\rho^{-l} \tag{11}$$

for some constants C and D. Again, we can set D = 0 to prevent the solution from becoming infinite at ρ = 0.

We therefore propose that the exact solution will have the form

<span id="page-1-0"></span>
$$u(\rho) = \rho^{l+1} e^{-\rho_0 \rho^2 / 2} v(\rho) \tag{12}$$

for some function v(ρ).

To proceed, we must substitute [12](#page-1-0) into [5,](#page-0-0) so we need to calculate d <sup>2</sup>u/dρ<sup>2</sup> in terms of v(ρ) and its derivatives.

$$\frac{du}{d\rho} = (l+1)\rho^l e^{-\rho_0 \rho^2/2} v(\rho) - \rho_0 \rho^{l+2} e^{-\rho_0 \rho^2/2} v(\rho) + \rho^{l+1} e^{-\rho_0 \rho^2/2} \frac{dv}{d\rho}$$
(13)

$$= \rho^{l} e^{-\rho_0 \rho^2/2} \left( v(l+1-\rho_0 \rho^2) + \rho \frac{dv}{d\rho} \right)$$
 (14)

$$\frac{d^2u}{d\rho^2} = l\rho^{l-1}e^{-\rho_0\rho^2/2}\left(v(l+1-\rho_0\rho^2) + \rho\frac{dv}{d\rho}\right) -$$
(15)

$$\rho_0 \rho^{l+1} e^{-\rho_0 \rho^2/2} \left( v(l+1-\rho_0 \rho^2) + \rho \frac{dv}{d\rho} \right)$$
 (16)

$$+ \rho^{l} e^{-\rho_{0}\rho^{2}/2} \left( (-2\rho_{0}\rho)v + (l+2-\rho_{0}\rho^{2}) \frac{dv}{d\rho} + \rho \frac{d^{2}v}{d\rho^{2}} \right)$$
 (17)

We can now substitute the second derivative and [12](#page-1-0) into [5](#page-0-0) and collect terms.

$$(l - \rho_0 \rho^2) \left( v(l + 1 - \rho_0 \rho^2) + \rho \frac{dv}{d\rho} \right) +$$

$$\rho \left( (-2\rho_0 \rho)v + (l + 2 - \rho_0 \rho^2) \frac{dv}{d\rho} + \rho \frac{d^2 v}{d\rho^2} \right) = \left( -1 + \frac{l(l+1)}{\rho^2} + \rho_0^2 \rho^2 \right) \rho^2 v$$
(19)

$$\rho^2 \frac{d^2 v}{d\rho^2} + 2((l+1)\rho - \rho_0 \rho^3) \frac{dv}{d\rho} + \rho^2 (1 - \rho_0 (2l+3))v = 0$$
 (20)

$$\rho \frac{d^2 v}{d\rho^2} + 2\left(l + 1 - \rho_0 \rho^2\right) \frac{dv}{d\rho} + \rho(1 - \rho_0(2l + 3))v = 0$$
(21)

We can now seek a solution where v(ρ) = ∑cjρ j as was done for the hydrogen atom. Substituting the series gives

$$\sum_{j} c_{j} j(j-1) \rho^{j-1} + 2(l+1) \sum_{j} c_{j} j \rho^{j-1} - 2\rho_{0} \sum_{j} c_{j} j \rho^{j+1} + (1-\rho_{0}(2l+3)) \sum_{j} c_{j} \rho^{j+1} = 0$$
(22)

We need to equate the coefficient of each power of ρ to zero separately, so we can redefine the index of summation in each case to make all the exponents of ρ the same:

$$\sum_{j} c_{j+1}(j+1)j\rho^{j} + 2(l+1)\sum_{j} c_{j+1}(j+1)\rho^{j} - 2\rho_{0}\sum_{j} c_{j-1}(j-1)\rho^{j} + (1-\rho_{0}(2l+3))\sum_{j} c_{j-1}\rho^{j} = 0$$
(23)

Consider first the term with j = 0. This gives:

$$2(l+1)c_1 + (2\rho_0 + 1 - \rho_0(2l+3))c_{-1} = 0$$
(24)

Since the series starts with the j = 0 term, c−<sup>1</sup> = 0, so we must have c<sup>1</sup> = 0 as well.

Considering the general case gives the recurrence relation:

<span id="page-2-0"></span>
$$c_{j+1} = \frac{\rho_0(2j+2l+1)-1}{(j+1)(j+2(l+1))}c_{j-1}$$
(25)

Since we know that c<sup>1</sup> = 0 this relation tells us that *all* odd powers in the series must be zero: c2k+<sup>1</sup> = 0 for all k = 0,1,2,....

We can alter the recursion relation slightly to make it look more natural by defining a new index variable q ≡ j −1. Substituting this into [25](#page-2-0) gives

<span id="page-2-1"></span>
$$c_{q+2} = \frac{\rho_0(2q+2l+3)-1}{(q+2)(q+2l+3)}c_q \tag{26}$$

where q = 0,2,4,6,.... The coefficient c<sup>0</sup> must of course be determined by normalization, which we won't bother with here.

For large q this has the asymptotic behaviour:

$$c_{q+2} \approx \frac{2\rho_0}{q+2}c_q \tag{27}$$

This is the same sort of asymptotic behaviour considered in the derivation of the radial function for the hydrogen atom, so if the series was infinite, it would lead to an exponential that blows up at infinite values of ρ. Thus we must require the series to terminate at some point, so from [26](#page-2-1) we must have for some qmax:

$$\rho_0 = \frac{1}{2q_{max} + 2l + 3} \tag{28}$$

If we recall the original definitions of ρ<sup>0</sup> and κ this translates into a condition on the energy:

$$E = \hbar\omega \left( q_{max} + l + \frac{3}{2} \right) \tag{29}$$

This is valid for all non-negative values of l but only for even qmax, so we can make the formula a bit more explicit by introducing a new parameter k such that qmax = 2k and k = 0,1,2,3,.... thus we have

$$E = \hbar\omega \left(2k + l + \frac{3}{2}\right) \tag{30}$$

If we define a final quantum number n ≡ 2k + l we get the well-known formula for the energies of the 3-d harmonic oscillator:

$$E_n = \hbar\omega \left( n + \frac{3}{2} \right) \tag{31}$$

Finally, we should check that the degeneracies of E<sup>n</sup> match those for the solution where we solved the system in rectangular coordinates. To do this, we need to calculate how many ways each level n can be formed.

We know that n = 2k +l, and also that the number l relates to the spherical harmonic that is the solution of the angular part of the Schrödinger equation. For each value of l there are 2l +1 spherical harmonics with different values of m. So we need to figure out first, how many combinations of k and l can add up to n = 2k + l and, second, how many states in total does this amount to when we take into consideration the 2l + 1 states for each value of l?

It is easiest to consider these questions for even and odd values of n separately. First, consider the case of n odd. In that case, k = 0,1,2,...(n− 1)/2 and l = 1,3,5,...n are the possible values of k and l. For example, we could have l = 1; k = (n−1)/2 or l = 3; k = (n−1)/2−1 and so on. Thus we can write that l = 2a + 1 where a = 0,1,2,...(n − 1)/2. Since each value of l has a degeneracy of 2l+1 the total degeneracy of level n is:

$$d(n) = \sum_{a=0}^{(n-1)/2} (2(2a+1)+1)$$
(32)

$$=4\left(\frac{1}{2}\frac{(n-1)}{2}\frac{(n+1)}{2}\right)+3\left(\frac{n-1}{2}+1\right) \tag{33}$$

$$=\frac{1}{2}(n+1)(n+2) \tag{34}$$

which agrees with the value of d(n) from our previous solution.

For even n the ranges are k = 0,1,2,...n/2 and l = 0,2,4,...n so we can write l = 2a for a = 0,1,2,3,...n/2. The degeneracy in this case is

$$d(n) = \sum_{a=0}^{n/2} (2(2a) + 1)$$
(35)

$$=4\frac{1}{2}\frac{n}{2}\left(\frac{n}{2}+1\right)+\frac{n}{2}+1\tag{36}$$

$$=\frac{1}{2}(n+1)(n+2) \tag{37}$$

which again agrees with the earlier solution.

PINGBACKS

Pingback: [Virial theorem in 3-d](https://physicspages.com/pdf/Quantum mechanics/Virial theorem in 3-d.pdf)