## Matter in extremis: ultrarelativistic nuclear collisions at RHIC ∗

Peter Jacobs † and Xin-Nian Wang ‡, Nuclear Science Division, Lawrence Berkeley National Laboratory, Berkeley, California 94720

October 22, 2018

#### Abstract

We review the physics of nuclear matter at high energy density and the experimental search for the Quark-Gluon Plasma at the Relativistic Heavy Ion Collider (RHIC). The data obtained in the first three years of the RHIC physics program provide several lines of evidence that a novel state of matter has been created in the most violent, head-on collisions of Au nuclei at √ s = 200 GeV. Jet quenching and global measurements show that the initial energy density of the strongly interacting medium generated in the collision is about two orders of magnitude larger than that of cold nuclear matter, well above the critical density for the deconfinement phase transition predicted by lattice QCD. The observed collective flow patterns imply that the system thermalizes early in its evolution, with the dynamics of its expansion consistent with ideal hydrodynamic flow based on a Quark-Gluon Plasma equation of state.

PACS numbers: 12.38.-t,12.38.Mh,13.87.-a,24.10.-i,25.75.-q

# Contents

| 1 | Introduction                                                       | 2  |  |  |  |  |
|---|--------------------------------------------------------------------|----|--|--|--|--|
| 2 | QCD and the Quark Gluon Plasma                                     |    |  |  |  |  |
|   | 2.1<br>Deconfinement<br>                                           | 4  |  |  |  |  |
|   | 2.2<br>Chiral Symmetry Restoration<br><br>                         | 6  |  |  |  |  |
|   | 2.3<br>Perturbative QCD<br>                                        | 7  |  |  |  |  |
| 3 | The Relativistic Heavy Ion Collider                                | 8  |  |  |  |  |
|   | 3.1<br>The Accelerator                                             | 8  |  |  |  |  |
|   | 3.2<br>The Experiments<br>                                         | 9  |  |  |  |  |
|   | 3.3<br>Geometric Aspects of High Energy Nuclear Collisions<br><br> | 14 |  |  |  |  |

<sup>∗</sup>To be published in Progress in Particle and Nuclear Physics.

<sup>†</sup>pmjacobs@lbl.gov

<sup>‡</sup>xnwang@lbl.gov

| 4 | Bulk Particle Production and Initial Conditions |                                                                      |    |  |  |
|---|-------------------------------------------------|----------------------------------------------------------------------|----|--|--|
|   | 4.1                                             | Particle Production Models<br>                                       | 19 |  |  |
|   | 4.2                                             | Multiparticle Production<br>                                         | 23 |  |  |
|   | 4.3                                             | Pseudo-rapidity Distributions<br><br>                                | 24 |  |  |
|   | 4.4                                             | Rapidity Distributions and Baryon Stopping<br><br>                   | 28 |  |  |
|   | 4.5                                             | Transverse Energy and Energy Density<br><br>                         | 29 |  |  |
| 5 |                                                 | Collective Phenomena                                                 | 31 |  |  |
|   | 5.1                                             | Relativistic Hydrodynamics<br>                                       | 31 |  |  |
|   | 5.2                                             | Transverse Radial Flow                                               | 34 |  |  |
|   | 5.3                                             | Anisotropic Flow<br>                                                 | 37 |  |  |
|   | 5.4                                             | Statistical Distribution of Hadron Yields<br><br>                    | 40 |  |  |
|   | 5.5                                             | Space-time Evolution                                                 | 42 |  |  |
| 6 |                                                 | Hard Probes                                                          | 45 |  |  |
|   | 6.1                                             | Partonic energy loss and modified fragmentation functions<br><br>    | 48 |  |  |
|   | 6.2                                             | Energy loss and jet quenching in a hot medium<br><br>                | 51 |  |  |
|   | 6.3                                             | Cronin Enhancement in<br>p<br>+<br>A<br>Collisions<br>               | 53 |  |  |
|   | 6.4                                             | High<br>pT<br>hadron suppression in<br>A<br>+<br>A<br>collisions<br> | 57 |  |  |
|   | 6.5                                             | Parton Recombination<br>                                             | 60 |  |  |
|   | 6.6                                             | Dihadron Spectra and Jet Quenching<br><br>                           | 63 |  |  |
|   | 6.7                                             | High<br>pT<br>Azimuthal Anisotropy                                   | 67 |  |  |
|   | 6.8                                             | Partonic Energy Loss vs. Hadronic Absorption<br>                     | 70 |  |  |
|   | 6.9                                             | Hard probes: an outlook<br>                                          | 73 |  |  |
| 7 | Summary<br>79                                   |                                                                      |    |  |  |
| 8 |                                                 | Acknowledgements                                                     | 81 |  |  |

# <span id="page-1-0"></span>1 Introduction

Quantum Chromodynamics (QCD) is the fundamental theory underlying the strong interaction between quarks and gluons that dictates the structure of hadrons and nuclei. The non-Abelian nature of the QCD gauge symmetry gives rise to confinement of quarks and gluons, making hadrons the only stable vacuum excitations of the strong interaction. Under extreme conditions of high temperature or baryon density the structure of the vacuum is predicted to change, undergoing a phase transition that restores the broken symmetries [\[1\]](#page-80-1) and frees quarks and gluons from confinement [\[2,](#page-80-2) [3\]](#page-80-3). Numerical calculation of the equation of state (EOS) in lattice QCD theory indeed finds a nearly first-order phase transition at a critical temperature of about 170 MeV [\[4\]](#page-80-4). Such a form of matter, called the Quark-Gluon Plasma (QGP) [\[5,](#page-80-5) [6,](#page-80-6) [7\]](#page-81-0), existed in the early universe a few microseconds after the Big Bang. Quark matter may still exist today in the core of neutron stars, where the baryon density exceeds the critical value of the phase transition [\[8\]](#page-81-1).

Soon after the QGP was identified as the excited phase of the QCD vacuum, it was realized that high energy collisions of heavy nuclei could create large volumes of matter at high energy density [\[9\]](#page-81-2) and that the energy density achievable at current or foreseeable nuclear accelerators might be sufficient to create the QGP in controlled laboratory experiments. Searches for the QGP using heavy-ion collisions have been carried out over the past three decades at successively higher energy facilities, beginning at the Berkeley Bevalac in the early 1980s [\[10\]](#page-81-3) and continuing at the Brookhaven AGS and CERN SPS in the late 1980s [\[11\]](#page-81-4). The Relativistic Heavy Ion Collider (RHIC), the subject of this review, was commissioned in 2000. Future experiments are planned at even higher energies at the CERN LHC [\[12\]](#page-81-5).

Experimental results from the AGS and SPS have revealed a rich set of new phenomena indicating the formation of dense matter [\[13,](#page-81-6) [14\]](#page-81-7), notably the anomalous suppression of charmonium [\[15\]](#page-81-8) and the broadening or mass-shift of vector mesons [\[16\]](#page-81-9). However, it has proven difficult to disentangle hadronic contributions to the observed signals, and no clear consensus has emerged that a long-lived Quark Gluon Plasma has been observed in the fixed target heavy ion experiments at those facilities.

Experiments at RHIC, the world's first heavy ion collider, have initiated a new era in the study of QCD matter under extreme conditions. Nuclear collisions at the highest RHIC energy (nucleon-nucleon CM energy √sNN =200 GeV) not only produce matter at the highest energy density ever achieved, but also provide a number of rare observables that have not been accessible previously. These observables are especially clean probes of the hot and dense matter generated in the collision. The wealth of data collected and analyzed in the first three years of RHIC operation indicates that a dense, equilibrated system is generated in the most violent, headon collisions of heavy nuclei. The initial energy density probed by hard processes and global measurements is estimated to be about two orders of magnitude larger than that of cold nuclear matter, well above the critical density for the deconfinement transition predicted by lattice QCD calculation. The collective behavior of the observed final-state hadrons provides evidence of early thermalization and hydrodynamic flow consistent with a Quark-Gluon Plasma equation of state. The matter is evidently a near-ideal, strongly coupled fluid, and is quite different from the ideal non-interacting gas expected from QCD at asymptotically high temperature.

The first set of experimental runs to survey the RHIC physics landscape has now been completed and it is opportune to pause and examine where things stand. In this review we will outline the RHIC heavy ion scientific program and discuss the main experimental results that support the foregoing conclusions. A large array of data is available, with over 50 Physical Review Letters published by the four RHIC experiments thus far. In limited space we cannot review all of the physics topics under study at RHIC. We therefore concentrate on those topics for which the data are mature and most clearly address the issues of QGP formation. There has also been considerable recent interest in universal properties of high density QCD at low Bjorken xBj [\[17\]](#page-81-10) and we will discuss RHIC data relevant to this physics. There are a number of significant topics that we touch only lightly or omit altogether, among them fluctuations and heavy quark and quarkonium production. These areas are developing rapidly and a review at this time would soon become outdated. Detailed discussions of all aspects of RHIC heavy ion physics can be found in the proceedings of recent Quark Matter conferences [\[18,](#page-81-11) [19\]](#page-81-12).

The review is organized as follows: section 2 presents a theoretical overview of the QCD phase transitions, together with theoretical considerations for analyzing heavy-ion nuclear collisions; section 3 presents the RHIC collider and experiments; section 4 discusses bulk particle production and the constraints it places on the collision dynamics; section 5 presents evidence from collective phenomena that equilibrium is achieved early in the fireball evolution; and section 7 discusses hard probes, concentrating on the theory and measurements of jet quenching. Section 8 presents a summary and outlook.

## <span id="page-3-0"></span>2 QCD and the Quark Gluon Plasma

<span id="page-3-3"></span>Within the Standard Model, the strong interaction between quarks is mediated through non-Abelian gauge gluon fields, as described by a theory called Quantum Chromodynamics (QCD), with

$$\mathcal{L}_{QCD} = \sum_{i=1}^{n_f} \bar{\psi}_i \gamma_{\mu} (i\partial^{\mu} - gA_a^{\mu} \frac{\lambda_a}{2} - m_i) \psi_i - \frac{1}{4} \sum_a F_a^{\mu\nu} F_{a,\mu\nu}, \tag{1}$$

where  $\lambda_a$ 's are Gell-Mann matrices in the fundamental representation of SU(3) and  $F_a^{\mu\nu} = \partial^{\mu}A_a^{\nu} - \partial^{\nu}A_a^{\mu} + igf_{abc}A_b^{\mu}A_c^{\nu}$  are gluon field-strength tensors. The seemingly simple theory is very similar in form to Quantum Electrodynamics (QED) but it possesses much richer structure because of its many symmetries, including the SU(3) gauge symmetry, the approximate chiral symmetry for the light quarks that is spontaneously broken in the QCD vacuum.  $U_A(1)$  symmetry and scale invariance are both broken through quantum interactions, leading to  $U_A(1)$  (or chiral) and scale (or trace) anomalies. These symmetries and their breaking dictate the structure of the vacuum and properties of strongly interacting matter, including the different phases that have been the focus of many theoretical and experimental studies since QCD was established as the theory of strong interactions.

#### <span id="page-3-1"></span>2.1 Deconfinement

Many remarkable features of QCD can be traced to the underlying SU(3) gauge symmetry of the strong interaction between quarks and gluons, which both carry color charges. Because of the non-Abelian self-interaction among gluons, the color charges at short distance are anti-screened due to color diffusion via gluon radiation, leading to a weakening of the coupling constant. This asymptotic freedom of the strong interaction [20, 21] opens the door for perturbative studies of the strong interaction within QCD, including renormalization. The scale dependence of the strong coupling, which at the leading order is given by

$$\alpha_s(Q^2) = \frac{4\pi}{(11 - \frac{2}{3}n_f)\log Q^2/\Lambda_{QCD}^2},$$
(2)

has been successfully tested by many experiments [22]. While the small value of the strong coupling constant implies weak interaction and thus makes it possible to calculate physical processes at short distance, the divergence at small energy scale or long distance signals strong interactions and therefore color confinement. Indeed, non-perturbative calculations of the heavy quark potential in lattice QCD show a linear potential at long distance with a string tension  $\kappa \approx 1$  GeV/fm [23, 24], indicating confinement of quarks to the domain of hadrons in normal vacuum. Since the average inter-particle distance becomes smaller at higher temperature or density, the interaction among quarks and gluons becomes weaker and confinement will eventually disappear, leading to a new phase of matter called the Quark Gluon Plasma (QGP) which is distinctly different from the hadronic phase. The energy density of such non-interacting QGP is

<span id="page-3-2"></span>
$$\epsilon_{SB} \equiv \epsilon_{q+\bar{q}} + \epsilon_g = \left[ 6n_f \frac{7\pi^2}{120} + 16\frac{\pi^2}{30} \right] T^4 \tag{3}$$

with the pressure  $P = \epsilon/3$ . In contrast,  $\epsilon_{\pi} = 3\pi^2 T^4/30$  for a massless pion gas.

Related to confinement, the renormalization of the coupling constant also breaks the scale invariance of QCD, leading to the trace anomaly  $T^{\mu}_{\ \mu} = (\alpha_s/12\pi)F^{\mu\nu}F_{\mu\nu} + m\bar{\psi}\psi$  of the energy-momentum tensor. The non-vanishing value of the vacuum expectation value of the gluon

![](_page_4_Figure_0.jpeg)

<span id="page-4-0"></span>Figure 1: Left: The energy density as a function of temperature from lattice QCD [\[4\]](#page-80-4). Arrows show the ideal gas values ǫSB from Eq. [\(3\)](#page-3-2). Right: Deviation from ideal gas EOS (ǫ − 3P)/T<sup>4</sup> at µB=0, 210, 410 and 530 MeV (bottom to top) as a function of T/T<sup>c</sup> [\[27\]](#page-81-18).

condensate [25], 
$$48B \equiv \langle \frac{\alpha_s}{\pi} F^{\mu\nu} F_{\mu\nu} \rangle \approx 0.02 \text{GeV}^4$$
 (4)

implies positive pressure and energy density in the vacuum that confines the weakly interacting quarks and gluons inside a hadron according to the MIT bag model [\[26\]](#page-81-20). This concept can be extended to the equation of state of a non-interacting QGP and massless pion gas, generating a first-order phase transition at a temperature T<sup>c</sup> ≈ 0.72B<sup>1</sup>/<sup>4</sup> for a baryon-free system. Such a phase transition has indeed been found in numerical simulations of QCD on the lattice. Fig. [1](#page-4-0) shows results from a recent lattice QCD calculation of the energy density as a function of temperature [\[4\]](#page-80-4). The sharp rise of the energy density at T<sup>c</sup> ≈ 170 MeV for two light quark flavors signals an increase of the effective number of degrees of freedom. The transition becomes first order for three light flavors, but the order of the phase transition is still not clear for a realistic value of the strange quark mass. However, a sharp cross-over is clearly present.

Shown as horizontal arrows in Fig. [1](#page-4-0) (left panel) are the energy densities of a non-interacting and massless parton gas as given by Eq. [\(3\)](#page-3-2). Lattice QCD results clearly deviate from these limits, indicating strong interaction among partons even above the phase transition temperature Tc. Higher order corrections to the perturbative calculation in the weak coupling region do not improve agreement with the lattice results. For reasonably small values of coupling constant g or αs, the perturbative expansion series up to order g 4 is found not to converge [\[28\]](#page-81-21). This indicates that massless partons are not a good basis for perturbative expansion because of the contribution of soft modes with momentum k ∼ gT. Resummation of hard thermal loops (HTL)[\[29\]](#page-81-22) leads to a picture of quasi-particle modes dominating the interaction in an interacting QGP. Working on the basis of quasi-particles and solving Dyson's equation in a self-consistent resummation, an equation of state (EOS) is obtained that is very close to that of lattice QCD results at temperatures above but close to the phase transition temperature [\[30\]](#page-81-23).

Since the EOS of an ideal massless QGP is P = ǫ/3, a measure of deviation from an ideal gas EOS is ǫ − 3P. Lattice QCD results [\[27\]](#page-81-18) (Fig. [1,](#page-4-0) right panel) indicate the presence of strong interactions around the phase transition temperature. Since the sound velocity is given by c 2 <sup>s</sup> = ∂P/∂ǫ, the softening of the EOS around the phase transition region would slow down hydrodynamic expansion, with significant consequences for the evolution of the dense matter and the relation of observed transverse energy production to the initial energy density prior to the start of hydrodynamic expansion.

In addition to large energy density, other properties of the quark gluon plasma will be quite different from those of a hadron gas or normal nuclear matter. Hadrons as bound states of quarks and anti-quarks do not exist in the plasma. Lattice studies of the heavy quark potential find that the confining linear potential in vacuum disappears once the temperature is above the phase transition temperature and what is left over is a screened Coulomb potential [31]. This is why heavy quarkonium was proposed as a good probe of the quark gluon plasma formed in high-energy heavy-ion collisions [32], since the quarkonium bound state will be dissolved into an unbound quark-antiquark pair once the binding potential is screened in the plasma. Though various theoretical estimates also predict quarkonium break-up through hadronic interactions [33, 34, 35], thermal gluon exchange screening of potential in a quark gluon plasma remains the most efficient way to suppress quarkonium.

Simulations on the lattice are difficult for a system at finite baryon chemical potential  $\mu_B$ . However, significant progress in this area has been made in recent years. The phase transition is found to change from first-order at high baryon density to a cross over at lower values of  $\mu_B$  [36, 37], though the position of the end-point is still uncertain and depends on the values of quark masses. Such an end-point in the phase diagram of QCD matter could have important effects, for instance increased baryon number fluctuations in heavy-ion collisions at low energy if the end-point is crossed over in the evolution of the fireball.

At high baryon densities and zero or low temperatures, the attractive interaction between quarks in the color-anti-triplet and spin-zero channels could lead to pairing of quarks in iso-singlet spin-zero and color-anti-triplet states on the Fermi surface, thus forming diquark condensates in two flavor quark matter [38, 39]. With three flavors of quarks, the Cooper quark pairs cannot be iso-singlet. The attractive interaction is found to be favored in the channel where colors and flavors are locked [40]. Such color-flavor locking leads to a plethora of new structures in the phases of dense quark matter which may generate novel effects in neutron stars where such high densities could be reached.

## <span id="page-5-0"></span>2.2 Chiral Symmetry Restoration

In addition to the SU(3) local gauge symmetry, the QCD interaction as given by Eq. (1) has the global symmetries of  $SU(3) \times SU_A(3) \times U(1) \times U_A(1)$  in the quark sector. The global U(1) symmetry is responsible for baryon number conservation while chiral symmetry, which is approximate for vanishing quark masses, also leads to many unique properties of QCD.

If the quark fields are decomposed into left and right chirality components,  $\psi_{L,R} = (1 \mp \gamma_5)\psi$ , the QCD Lagrangian with three massless quarks is invariant under the transformation,

$$\psi_{L,R} \to e^{-i\theta_{L,R}^i \lambda^i} \psi_{L,R} \ .$$
 (5)

According to the Noether theorem, this will generate two kinds of conserved currents or their combination, vector and axial-vector currents,

$$V_{i}^{\mu} = \bar{\psi}\gamma^{\mu}\frac{\lambda_{i}}{2}\psi;$$

$$A_{i}^{\mu} = \bar{\psi}\gamma^{\mu}\gamma_{5}\frac{\lambda_{i}}{2}\psi.$$
(6)

Identifying each current with a physical state having the corresponding quantum number results in degeneracy between scalar and pseudoscalar as well as between vector and pseudovector mesons.

The absence of parity doublets led to the discovery of the spontaneous breaking of chiral symmetry by the QCD vacuum, manifested by the non-vanishing of the quark condensate

$$\langle \bar{\psi}\psi \rangle \equiv \langle \bar{\psi}_R \psi_L + \bar{\psi}_L \psi_R \rangle = -(240 \text{MeV})^3 ,$$
 (7)

which is directly related to  $f_{\pi}$ , the pion decay constant. One of the consequences of this spontaneous symmetry breaking is the existence of massless Goldstone bosons. The absence of the ninth Goldstone boson is due to the breaking of  $U_A(1)$  symmetry by quantum correction or an anomaly,

$$\partial_{\mu}A_0^{\mu} = \frac{2n_f}{16\pi}\alpha_s F_a^{\mu\nu}\tilde{F}_{a,\mu\nu},\tag{8}$$

where  $\tilde{F}_{a,\mu\nu} = \epsilon_{\mu\nu\alpha\beta} F_a^{\alpha\beta}$ . The non-vanishing vacuum expectation value of this anomaly is related to what is known as the topological susceptibility of the vacuum.

All of these order parameters, the quark and gluon condensates and the topological susceptibility, are believed to be related to the gluonic structure of the vacuum [41]. They dictate all hadronic properties – their mass spectra, decay widths and constants. The medium modification of these condensates at low temperature and density is calculable within the framework of chiral perturbation theory [42]. At higher temperature and in the quark gluon plasma phase, they are expected to vanish. The quark condensate in lattice QCD calculations [4] is shown to disappear above the QCD phase transition temperature characterized by a sharp cross-over, which coincides with the cross-over of the expectation value of the Polyakov loop, a measure of deconfinement. At these temperatures and densities, chiral symmetry is completely restored and  $U_A(1)$  symmetry is also partially restored. Hadronic properties will be very different from those in vacuum. There will be mixing of vector and axial vector currents and all the chiral multiplets will become degenerate.

There are many consequences of the restoration of chiral and  $U_A(1)$  symmetry in the dense medium. The vanishing value of the topological susceptibility gives rise to a reduction of the ninth Goldstone boson, leading to possible enhancement of  $\eta$  mesons [43, 44]. A rapid cooling of the dense medium initially in a chirally symmetric state could introduce instabilities into the evolution of chiral fields leading to the amplification of soft modes [45], though a realistic treatment of the expansion and cooling of a finite system can prevent the creation of such disoriented chiral condensates (DCC) in large domains [46]. Perhaps the most promising signals of chiral symmetry restoration are modifications of hadron properties in medium, *i.e.* the masses and widths of vector mesons and axial vector mesons via mixing, as manifested in the soft dilepton spectra [47]. The enhanced soft dilepton yield below the  $\rho$  mass region seen by the CERES experiment at SPS [16] may be attributable to the medium modification of the  $\rho$  meson. During the QGP phase, annihilation of thermal quarks and antiquarks could also contribute to the underlying dilepton spectra in the intermediate mass region.

## <span id="page-6-0"></span>2.3 Perturbative QCD

The most important practical consequence of asymptotic freedom for the SU(3) gauge interaction in QCD is the success of perturbative QCD (pQCD) in describing various processes involving strong interactions at short distance. Because of the small coupling constant, it is possible to make a systematic expansion of physical cross sections in the strong coupling constant when the momentum transfer involved is large. Because of color confinement in vacuum, both the initial and final observed particles will be hadrons and therefore will involve strong interaction

at long distance, which is not calculable within the framework of the perturbative expansion. However, it has been proven to at least leading power correction (1/Q<sup>2</sup> ) that the cross section can be factorized into short-distance parts calculable in pQCD and non-perturbative long distance parts [\[48,](#page-82-14) [49,](#page-82-15) [50\]](#page-82-16).

The long distance parts normally involve hadronic wavefunctions, parton distributions, and hadronization. Though they cannot be calculated perturbatively, their matrix element definitions are universal, independent of specific processes. If measured in one process they can be applied to another process; therein lies the predictive power of pQCD. The renormalization of these non-perturbative matrix elements due to initial and final state radiation in pQCD leads to the Dokshitzer-Gribov-Lipatov-Altarelli-Parisi (DGLAP) evolution equations [\[51,](#page-82-17) [52,](#page-82-18) [53\]](#page-82-19). Given the experimental measurements of these distributions at one scale, the DGLAP equations predict their evolution to higher momentum scales. For example, final-state radiation leads to the DGLAP evolution equations for parton fragmentation functions Da→h(zh, Q<sup>2</sup> ),

<span id="page-7-2"></span>
$$\frac{\partial D_{q \to h}(z_h, Q^2)}{\partial \ln Q^2} = \frac{\alpha_s(Q^2)}{2\pi} \int_{z_h}^1 \frac{dz}{z} \left[ \gamma_{q \to qg}(z) D_{q \to h}(z_h/z, Q^2) + \gamma_{q \to gq}(z) D_{g \to h}(z_h/z, Q^2) \right], 
\frac{\partial D_{g \to h}(z_h, Q^2)}{\partial \ln Q^2} = \frac{\alpha_s(Q^2)}{2\pi} \int_{z_h}^1 \frac{dz}{z} \left[ \sum_{q=1}^{2n_f} \gamma_{g \to q\bar{q}}(z) D_{q \to h}(z_h/z, Q^2) + \gamma_{g \to gg}(z) D_{g \to h}(z_h/z, Q^2) \right] (9)$$

where γa→bc(y) are the splitting functions of the corresponding radiative processes [\[53\]](#page-82-19). These evolution equations have been tested extensively against experiment and can now even be used to measure the scale-dependence of the running strong coupling constant [\[22\]](#page-81-15).

The perturbative QCD parton model is based on this factorization picture of hard processes. In this model the cross section of a typical hard process can be expressed as the convolution of initial parton distributions, perturbative parton scattering cross sections and the parton fragmentation function. Since hard processes happen on a short time scale in the very earliest stage of high-energy heavy-ion collisions, they probe of the bulk matter that is formed shortly after the collision. The pQCD parton model serves as a reliable and tested framework for the study of these hard probes. Proposed hard probes in high-energy heavy-ion collisions include Drell-Yan dileptons from quark-antiquark annihilation, direct photons from quark and gluon Compton scattering, heavy quark production, and high p<sup>T</sup> jets from hard parton-parton scattering. In this review, we will focus on the physics of jet propagation in the dense medium.

# <span id="page-7-0"></span>3 The Relativistic Heavy Ion Collider

The Relativistic Heavy Ion Collider (RHIC) [\[54\]](#page-82-20) at Brookhaven National Laboratory is the world's highest energy accelerator of heavy nuclei and the world's first polarized proton collider. In this section we describe the accelerator and the experiments, together with some theoretical considerations important for the analysis of ultrarelativistic heavy ion collisions.

### <span id="page-7-1"></span>3.1 The Accelerator

The collider consists of two independent, concentric acceleration and storage rings, with a circumference of 3.8 km. All storage ring magnets are superconducting, cooled to 4.2 K by a 25 kW helium refrigerator. There are six intersection points, of which four are currently instrumented with experiments. RHIC can store and collide beams with masses ranging from protons to the

|                               | Au+Au                                            | p+p                                                |
|-------------------------------|--------------------------------------------------|----------------------------------------------------|
| Beam energy                   | $30 \rightarrow 100 \text{ GeV per nucleon}$     | $30 \rightarrow 250 \text{ GeV}$                   |
| Mean Luminosity at top energy | $2 \times 10^{26} \text{ cm}^{-2} \text{s}^{-1}$ | $1.4 \times 10^{31} \text{ cm}^{-2} \text{s}^{-1}$ |
| Bunches per ring              | $60 \rightarrow 120$                             | $60 \rightarrow 120$                               |
| Luminosity lifetime           | $\sim 10 \text{ hours}$                          | >10 hours                                          |
| $eta^*$                       | $10 \rightarrow 1 \text{ m}$                     | $10 \rightarrow 1 \text{ m}$                       |

<span id="page-8-1"></span>Table 1: Main design specifications of RHIC for Au+Au and p+p collisions [54].

heaviest stable nuclei. Due to the independence of the rings RHIC has great flexibility to collide beams of unequal masses, such as protons or light ions with Au ions. The top collision energy for the heaviest nuclear beams is  $\sqrt{s_{\scriptscriptstyle {\rm NN}}}$ =200 GeV per nucleon pair, while the top energy for p+p is  $\sqrt{s}$ =500 GeV.

The layout of RHIC is shown in Fig. 2. Heavy ion beams originate in a pulsed sputter source and are accelerated successively by a Tandem van der Graaf accelerator, Booster Synchrotron, and the Alternating Gradient Synchrotron (AGS), where they are accelerated to 10.8 GeV/nucleon, fully stripped of their electrons, and injected into RHIC. Polarized protons originate in a 200 MeV Linac and are accelerated by the Booster and the AGS to 24.3 GeV for injection into RHIC. Polarization of protons is maintained by use of Siberian Snakes [55]. The physics of the RHIC Spin program is beyond the scope of this review; a recent review and status report can be found at [56, 57].

Acceleration and storage in RHIC utilizes two Radio Frequency (RF) systems, one at 28 MHz to capture the AGS bunches and accelerate to top energy, the other at 197 MHz to provide a short collision diamond ( $\sigma_L \sim 25$  cm) for efficient utilization of the luminosity by the experiments. The synchotron phase transition of the RHIC lattice is at  $\gamma_T = 24.7$ , meaning that all ions except protons pass through the beam instability at transition.

The main performance specifications of RHIC are given in Table 1. For light ions (A<100), the luminosity is limited by beam-beam hadronic interactions, whereas for heavier ions the luminosity lifetime is limited by intrabeam (intra-bunch) scattering [58]. Other processes which significantly limit the luminosity for heavier ions result from their intense electromagnetic fields at high energy: Coulomb dissociation and spontaneous electron-positron production followed by electron capture [58]. The luminosity for beams of heavy nuclei scales with beam energy as  $\gamma^2$ .

Table 2 lists the beams, energies and integrated luminosity for the RHIC runs to date. The recently completed runs labelled "2004" have not generated scientific publications as of this writing. While the luminosities accumulated for heavy ion running appear at first sight to be small, nuclear geometric effects amplify hard cross sections approximately as the product of the nuclear masses AB (Sect. 3.3). The rightmost column converts the integrated luminosity for heavy ions to the equivalent for p + p collisions that would generate the same yield for a process whose cross section scales as AB. In the later runs the store-averaged luminosities achieved for Au + Au collisions exceed the RHIC design specifications in Table 1.

## <span id="page-8-0"></span>3.2 The Experiments

The RHIC beams are brought into head-on collision at the intersection regions. The final dipoles of the lattice are approximately  $\pm 10$  m from the collision diamond, with the intervening space free for detectors. Currently four of the six intersection regions are instrumented, with two major detectors (PHENIX, STAR) and two smaller ones (BRAHMS, PHOBOS).

![](_page_9_Figure_0.jpeg)

<span id="page-9-0"></span>Figure 2: The RHIC accelerator complex.

| Beams         | √s<br>NN(GeV) | R<br>Ldt(nb−1<br>) | R<br>(pb−1<br>p<br>p<br>Ldt<br>+<br>equivalent<br>) |
|---------------|---------------|--------------------|-----------------------------------------------------|
| Au+Au         | 20            | small              | small                                               |
| Au+Au         | 130           | 0.02               | 0.8                                                 |
| Au+Au         | 200           | 0.24               | 7.9                                                 |
| ~p<br>+<br>~p | 200           | 1600               | 1.6                                                 |
| d+Au          | 200           | 75                 | 3.0                                                 |
| Au+Au (2004)  | 200           | ∼2                 | 80                                                  |
| Au+Au (2004)  | 62.4          | ∼0.05              | 2                                                   |

<span id="page-9-1"></span>Table 2: Beam and energy combinations run at RHIC to date. R Ldt denotes integrated luminosity delivered to all four experiments. "p + p equivalent" is the luminosity scaled by the number of binary collisions (note change of units between columns 3 and 4). Runs labelled "2004" were recently completed and have not generated physics publications as of this writing.

All four experiments contain identical Zero Degree Calorimeters (ZDC) [59], which are used for triggering, luminosity monitoring, and event characterization. The ZDCs are compact tungsten/fiber hadronic calorimeters situated immediately downstream of the machine dipole magnets that define the interaction region, with acceptance 2.5 mrad centered on the beam direction. The energy flux into this acceptance is dominated in heavy ion collisions by non-interacting spectator neutrons. The ZDC energy resolution is sufficient to discriminate individual beam-velocity neutrons [59]. The luminosity for Au + Au collisions has been measured with 10% precision using a Vernier scan of ZDC coincidence rates [60, 61].

**PHENIX** The PHENIX experiment is designed to make precision measurements of a wide variety of observables, sensitive to multiple time scales in the evolution of heavy ion collisions. Special emphasis is put on rare signals (direct photons, lepton pairs,  $J/\psi$  and  $\Upsilon$  families, jet fragments) that probe the system at the earliest, hot and dense phase. Measurement of lepton pairs at low  $p_T$  is a promising tool for studies of chiral symmetry restoration. Inclusive measurements and correlations of identified hadrons at high  $p_T$  are sensitive to partonic interactions in the medium, and at lower  $p_T$  probe the late, hadronic gas stage of the collision.

The PHENIX detector [62], shown in Fig. 3, consists of four independent spectrometers, two at midrapidity for charged hadrons, electrons, and photons, and two at forward rapidities for muons. Each has an acceptance of  $\sim 1$  steradian. The midrapidity spectrometers have an axial magnetic field, with tracking for momentum measurements supplied by drift and pad chambers. Charged particle identification over a broad momentum range is provided by Time of Flight (TOF), Ring Imaging Cerenkov (RICH), and Time Expansion Chamber (TEC) detectors, giving proton identification up to  $p_T$ =5 GeV/c. Electrons and photons are measured in highly granular lead-scintillator and lead glass calorimeters (EMC). The combination of EMC, RICH and TEC provides a hadron background rejection factor for electron measurements of  $10^4$  over a wide momentum range. The forward muon spectrometers have acceptance for  $J/\psi \to \mu^+\mu^-$  of -2.25 < y < -1.15 and 1.15 < y < 2.44. The muon arms have a radial magnetic field, with tracking based on drift chambers followed by a muon identifier consisting of alternating layers of steel absorber and streamer tubes. Pion contamination of identified muons is  $\sim 3 \times 10^{-3}$ .

STAR The STAR experiment has broad physics reach, covering a wide variety of hadronic and leptonic observables. Large acceptance enables measurement of a large fraction of the thousands of charged hadrons produced in a heavy ion collision, to measure correlations and to search for rare or subtle non-statistical fluctuations indicating new physics. STAR has robust capabilities to trigger and measure high  $p_T$  observables (hadron yields and correlations, electrons, photons, and jets) to investigate partonic interactions in dense matter. Measurements of  $J/\psi$  and  $\Upsilon$  will probe deconfinement directly.

The STAR detector [63] is shown in fig. 4. STAR is based on a warm solenoidal magnet, with radius 260 cm and maximum field strength 0.5 Tesla, surrounding a variety of detector systems. The main tracking device is a solenoidal Time Projection Chamber (TPC) with radius 200 cm and full azimuthal acceptance over  $|\eta|<1.4$ . Additional tracking is provided by inner silicon drift detectors at midrapidity and forward TPCs at  $2.5 < |\eta| < 4$ . Photons and electrons are measured by Barrel and Endcap Electromagnetic Calorimeters (EMC), with full azimuthal acceptance over  $-1.0 < \eta < 2.0$ . Particle identification is carried out using specific ionization (dE/dx) in the TPC gas, time of flight, reconstruction of displaced vertices for weakly decaying particles, and combinatorial invariant mass methods. The identification of strange baryons and mesons has been made up to  $p_T$ =6 GeV/c and of charmed mesons to 10 GeV/c, with the measurements

![](_page_11_Figure_0.jpeg)

PHENIX Detector

<span id="page-11-0"></span>Figure 3: The PHENIX detector.

currently limited by statistics. Fast triggering utilizes the ZDCs, forward scintillators (Beam-Beam counters), a barrel of scintillator slats surrounding the TPC, and the EMC.

BRAHMS The emphasis of the BRAHMS experiment is on high precision inclusive measurements and small-angle correlations of primary hadrons over very broad phase space. BRAHMS indeed has very large coverage, extending for charged pions to rapidity y=4 (Au-beam rapidity is 5.37). The BRAHMS detector [64], shown in fig. 5, consists of two independent charged particle spectrometers: the Forward Spectrometer (FS), with acceptance 0.8 msr measuring momenta  $p_T < 35$  GeV/c for angles relative to the beam  $2.3 < \theta < 30$  degrees, and the Mid-Rapidity Spectrometer (MSR), with acceptance 6.5 msr and angular coverage  $30 < \theta < 95$  degrees. Momentum measurements and particle identification utilize Time Projection Chambers (TPCs) in conjunction with Time of Flight hodoscopes and Threshold and Ring Imaging Cerenkov detectors. Triggering and global even characterization of heavy ion events are carried out using a mid-rapidity multiplicity array, forward scintillator detectors, and the ZDCs.

**PHOBOS** PHOBOS is designed to carry out a very general search for a priori unknown and potentially rare signatures of new physics, requiring a very large acceptance device that detects almost all charged particles in each event for a large fraction of all inelastic collisions. Virtually the entire RHIC phase space is covered by the PHOBOS multiplicity measurement, with the high trigger and recording rate allowing offline searches for unusual events or rare fluctuations. Large-scale phenomena in heavy ion collisions may generate effects at very low  $p_T$ , requiring the spectrometers to measure down to  $p_T \sim 30 \text{ MeV/c}$ . The PHOBOS spectrometers also measure

![](_page_12_Picture_0.jpeg)

Figure 4: The STAR detector.

<span id="page-12-1"></span><span id="page-12-0"></span>![](_page_12_Picture_2.jpeg)

Figure 5: The BRAHMS detector.

at sufficiently high  $p_T$  to be sensitive to jet-related observables.

The PHOBOS experiment [65], shown in fig. 6, is based almost entirely on silicon pad detectors. It consists of a multiplicity array covering 11 units of pseudorapidity, a finely segmented vertex detector, two small-acceptance midrapidity spectrometers, and trigger detectors. The spectrometer arms utilize a warm dipole magnet of strength 1.5 Tesla-m. Particle identification is based on measurements of time of flight and energy loss in the silicon. Special emphasis is put on measurements at very low transverse momentum, requiring a thin beam pipe and minimal material in front of the first tracking planes.

![](_page_13_Picture_2.jpeg)

Figure 6: The PHOBOS detector.

## <span id="page-13-2"></span><span id="page-13-0"></span>3.3 Geometric Aspects of High Energy Nuclear Collisions

In proton-nucleus and nucleus-nucleus collisions, multiple scattering occurs at both the hadronic and the partonic level. Multiple scattering influences many aspects of the dynamics of high energy nuclear collisions, in particular the initial parton scattering responsible for bulk particle production and the spectrum of rare hard processes. It depends on the geometry of the nucleus-nucleus collision, which also dictates the geometry of the produced dense matter. Determination of the collision geometry is a key element in the study of heavy-ion collisions.

#### <span id="page-13-1"></span>Multiple Scattering and the Glauber Model

Current theoretical treatment of multiple scattering is based on the Glauber model [66]. In this model, a hadron-nucleus collision is considered to be a series of multiple hadron-nucleon scatterings. Neglecting the difference between the hadron and its excited states between successive scatterings and utilizing the forward peak of high energy hadron-nucleon elastic scattering, the total cross section of h + A collisions is [66]

$$\sigma_{hA} = \int d^2b \sum_{n=1}^{A} \begin{pmatrix} A \\ n \end{pmatrix} \left[ -\sigma_{hN} t_A(b) \right]^n e^{-\sum_{i=1}^{n} (\Delta q_{zi} R_A/2)^2} , \qquad (10)$$

where  $t_A(b) = T_A(b)/A$  and  $T_A(b)$  is the nuclear thickness function defined as a line integral over the nuclear density  $\rho_A$ ,

$$T_A(\vec{b}) = \int_{-\infty}^{\infty} dz \rho_A(\vec{b}, z). \tag{11}$$

The exponential factor in the above cross section comes from the interference between different scatterings, assuming a Gaussian form of the nuclear density distribution. The longitudinal momentum transfer is related to the transverse momentum transfer  $q_{Ti}$  of each scattering,

$$\Delta q_{zi} \approx (q_{T1}^2 + q_{T2}^2 + \dots + q_{Ti-1}^2)/2E_h,$$
 (12)

and determines the coherence length  $\ell_c = 1/\Delta q_{zi}$ . For high energy scattering with small transverse momentum transfer, the coherence length is much longer than the nuclear size  $R_A$  and hadron-nucleus collisions become coherent. The hadron-nucleus cross section is then given by the familiar Glauber formula,

$$\sigma_{hA} = \int d^2b \left\{ 1 - [1 - \sigma_{hN} t_A(b)]^A \right\} . \tag{13}$$

For large nuclei  $A \gg 1$ , the integrand can be approximated by an exponential  $1-\exp[-\sigma_{hN}T_A(b)]$ . For hadronic scattering with large cross section  $\sigma_{hN}$ , this cross section is mainly determined by the nuclear density distribution and is denoted the geometric cross section. This approach is most relevant for soft processes.

For hard processes with large transverse momentum transfer and small cross section, the coherence length becomes much smaller than the intra-nucleon distance in the nucleus. In this case all interference terms drop out and the cross section results from the incoherent superposition of nucleon-nucleon collisions. The h+A cross section is then directly proportional to that for h+N collisions:

<span id="page-14-1"></span>
$$\sigma_{hA}^{\text{hard}} = \int d^2b T_A(b) \sigma_{hN}^{\text{hard}} = A \sigma_{hN}^{\text{hard}}.$$
 (14)

This expression is proportional to the thickness function, which represents the number of hadronnucleon collisions in a h+A collision. As shown in Fig. 7 (left panel), experimental cross sections of Drell-Yan dilepton production with large invariant mass at the CERN SPS indeed scale linearly with the atomic number to good precision in p+A collisions.

![](_page_14_Figure_8.jpeg)

<span id="page-14-0"></span>Figure 7: Scaling of hard and soft processes in nuclear collisions at the CERN SPS. Left: Drell-Yan production cross section in p+A collisions normalized by atomic mass A (Eq. 14), from NA50 [67]. Right: charged hadron pseudorapidity distribution in central collisions of equal mass nuclei scaled by the number of nucleon participants ( $\sim 2A$ ), from NA49 [68].

This formula can be extended to the case of A + B collisions by replacing the thickness function in h + A collisions with the nuclear overlap function,

$$T_{AB}(\vec{b}) = \int d^2s T_A(\vec{s}) T_B(\vec{b} - \vec{s}), \tag{15}$$

which represents the number of binary nucleon-nucleon collisions per unit cross section,

$$dN_{bin}/d^2b = T_{AB}(b), (16)$$

in A + B collisions at fixed impact parameter b.

Since the hard processes are incoherent, their cross sections in A+B collisions should be proportional to the number of binary collisions  $N_{bin}$ . We will see below that certain hard processes with large momentum transfer  $Q^2$  provide sensitive probes of the matter generated in nuclear collisions through final-state interaction of their reaction products with the medium. Deviation from binary scaling of the cross section therefore indicates novel nuclear effects and provides an experimental observable to quantify such effects. Isolation of final-state from initial-state effects requires comparison of systems in which final state effects are expected to be present or absent. This strategy will play an important role in our discussion of hard processes.

In contrast to hard processes, soft processes typically have large cross section and coherence lengths much larger than the nuclear size. The inclusive cross section and total hadron multiplicity are then expected to scale as the number of participating ("wounded") nucleons (Wounded Nucleon Model [69]). In the Glauber multiple scattering model, the average number of wounded nucleons at a fixed impact-parameter in A+B collisions is

$$N_{part}(b) = \int d^2s T_A(s) \left[ 1 - e^{-\sigma_{NN} T_B(\vec{s} - \vec{b})} \right] + \int d^2s T_B(\vec{s} - \vec{b}) \left[ 1 - e^{-\sigma_{NN} T_A(\vec{s} - \vec{b})} \right]$$
(17)

Fig. 7, right panel, shows the charged particle pseudorapidity distribution in central collisions of equal mass nuclei measured at the CERN SPS, which indeed is seen to scale for massive nuclei as the number of participating nucleons. A particle production model embodying such coherent processes is the string model implemented in HIJING Monte Carlo model [70, 71]. In this model, a wounded nucleon becomes an excited string, with the number of produced hadrons insensitive to the number of scatterings suffered throughout the multiple scattering process. This leads to hadron multiplicity from soft interactions proportional to the number of participant nucleons.

We turn now to application of the Glauber model to data analysis. The impact parameter b is not observable and measurements necessarily integrate over a finite interval of b. Event geometry is tagged by observables correlated with impact parameter, such as charged particle multiplicity, whose distributions are binned into percentiles of the total interaction cross section (Fig. 9). Using the Glauber model, differential cross section distributions  $d\sigma/dN_{bin}$  and  $d\sigma/dN_{part}$  are calculated and the weighted mean values  $\langle N_{bin} \rangle$  and  $\langle N_{part} \rangle$  are found within the same percentile bins of total cross section. The bins of the measured distribution and model calculation are equated, under the assumptions that the event-tagging observable varies on average monotonically (but not necessarily linearly) with impact parameter and that fluctuations generate negligible mixing of the bin populations.

The nuclear density in the calculation is taken to be spherically symmetric, with Woods-Saxon radial dependence:

$$\rho_A(r) = \frac{\rho_0}{1 + e^{(r - r_0)/a}}. (18)$$

Typical parameters for Au nuclei are density  $\rho_0=0.169/\mathrm{fm}^3$  and surface thickness  $a=0.535\pm0.027$  fm, the latter derived from electron scattering data[72]. The charge radius  $r_0=6.38$  fm is usually increased to  $\sim 6.5$  fm to account for the neutron skin thickness.

Two methods are used in the literature to calcuate  $N_{bin}$  and  $N_{part}$ : the *Optical* and *Monte Carlo* Glauber approaches (see Appendix A of [73] and references therein.) The Optical Glauber approach is based on a smooth nuclear matter distribution and numerical evaluation of the analytic Glauber integrals. The Monte Carlo approach is based on the random distribution of nucleons according to the Woods-Saxon density, with nuclear collisions at a given impact parameter modelled by the incoherent interaction of all nucleon pairs. For central Au+Au collisions at RHIC energies the practical difference between these approaches is negligible compared to other uncertainties of the measurements, but for peripheral collisions the differences can be significant. Assessment of this uncertainty must be made when interpreting data that incorporate Glauber calculations.

![](_page_16_Figure_2.jpeg)

<span id="page-16-0"></span>Figure 8: Charged particle multiplicity distributions from 200 GeV d+Au collisions, from STAR [74]. Measurement is for  $-3.8 < \eta < -2.8$  (Au-beam direction). Centrality selection and Glauber calculations (histograms) described in text.

As a gauge of the accuracy of the Glauber model, Figure 8 compares the results of a Monte Carlo Glauber calculation to charged particle multiplicity distributions in 200 GeV d + Au collisions [74]. The measurements are at forward rapidity  $(-3.8 < \eta < -2.8, Au$ -beam direction), both for minimum bias d + Au collisions and for peripheral d + Au collisions which have a beam-rapidity neutron detected in the deuteron beam direction ("ZDC-d"). The calculated multiplicity distributions result from the convolution of the forward charged multiplicity distribution measured in 200 GeV  $\bar{p} + p$  interactions [75] with the  $N_{part}$  distribution from the Glauber model. Both the minimum bias and peripheral multiplicity distribution measurements are well reproduced by the model. In addition, the cross for such peripheral collisions is calculated to be  $(18 \pm 3)\%$  of the minimum bias cross section, in good agreement with the measured fraction  $(19.2 \pm 1.3)\%$ [74]. Figure 8 demonstrates that the Glauber approach provides a sound basis for modelling geometric effects in nuclear collisions at RHIC energies.

### Centrality tagging in Au + Au collisions

Fig. [9,](#page-17-0) left panel, shows the measured correlation in 200 GeV Au + Au collisions between ZDC energy (spectator neutrons) and charged particle multiplicity within 3.1<|η|<3.9, from PHENIX. In the most peripheral (large impact parameter) collisions, the number of forward neutrons and the total multiplicity are both small. Both quantities increase for decreasing impact parameter, while for the most central collisions the number of spectator neutrons is again small while the multiplicity is large. The correlation between these two geometry-sensitive observables is seen to be strong. The figure also illustrates the sorting of events into centrality bins corresponding to percentile intervals of the cross section, with 0-5% indicating the most central collisions.

![](_page_17_Figure_2.jpeg)

<span id="page-17-0"></span>Figure 9: Event centrality characterization. Left: scaled ZDC energy (vertical) vs. forward charged multiplicity (horizontal), from PHENIX [\[76\]](#page-83-17). Right: distribution of charged multiplicity at mid-rapidity, from STAR [\[77\]](#page-83-18). Both plots are for minimum bias Au+Au events at √sNN =200 GeV and show the division into centrality bins corresponding to percentile intervals of the total cross section.

The ZDC energy is small for both the most central and most peripheral collisions, and this ambiguity limits its utility as a centrality tag. For many applications the multiplicity distribution alone suffices as a centrality tag, as shown in Fig. [9,](#page-17-0) right panel. The shape of the distribution is dominated by the nuclear geometry, with the tail at the highest multiplicity governed by multiplicity fluctuations within the finite measurement aperture for the most central collisions.

We conclude this section with a discussion of the impact parameter dependence of Nbin and Npart. Figure [10,](#page-18-2) left panel, shows this dependence for Au + Au collisions at RHIC energies, indicating the strong bias towards central collisions of binary-scaling processes. For an Nbinscaling process, we define the fraction of the its total cross section contained in events with impact parameter b<b<sup>c</sup> as[\[78\]](#page-83-19):

$$f_{AB} = \frac{2\pi}{AB} \int_0^{b_c} bdb \, T_{AB}(\vec{b}). \tag{19}$$

Figure [10,](#page-18-2) right panel, shows fAB as a function of fgeo, the fraction of the total hadronic interaction cross section contained in the same impact parameter interval. The Nbin-scaling cross section weights strongly towards central (small impact parameter) collisions, due purely to nuclear geometry. As a rough rule of thumb for binary-scaling processes in symmetric heavy ion collisions, 40% of the cross section is contained in the 10% most central events.

![](_page_18_Figure_0.jpeg)

<span id="page-18-2"></span>Figure 10: Left:  $N_{bin}$  and  $N_{part}$  vs. impact parameter for Au+Au at RHIC energies [79]. Right: fraction of binary-scaling cross section vs fraction of hadronic interaction cross section; figure from [78]. Central events correspond to small  $f_{geo}$ . The curves are for (upper to lower) Au+Au, Ag+Ag, Cu+Cu, Al+Al, and O+O collisions.

### <span id="page-18-0"></span>4 Bulk Particle Production and Initial Conditions

The formation of a Quark-Gluon Plasma in high-energy heavy-ion collisions depends critically on the initial parton production at the earliest stage of the reaction. A number of proposed signals of the QGP are sensitive to the early conditions and provide direct measurements of the initial density and other properties of the dense matter. Alternatively, global observables based on bulk particle production, such as the rapidity density of hadron multiplicity and transverse energy, provide a coarse-grained view of the early dynamics. These observables may be related to the entropy and energy densities early in the collision evolution, and as such provide meaningful constraints on the initial conditions that complement the measurements via direct probes. They can also provide tests of particle production models and provide a more complete picture of the dynamics. Our first discussion will focus on properties of bulk particle production: multiplicity and transverse energy pseudorapidity  $(\eta)$  densities and net baryon number distributions.

#### <span id="page-18-1"></span>4.1 Particle Production Models

Prior to RHIC startup, theoretical model estimates of the initial conditions and bulk particle production varied over a wide range, due to uncertainties in modeling soft hadron production and the interplay between soft and hard processes [80]. These models included a pure pQCD parton model [81], a pQCD parton model in combination with string model [71, 82], and a classical Yang-Mills field model [83]. The uncertainties were significantly reduced with the first publication of RHIC data on charged hadron multiplicity [84]. New calculations based on the initial state gluon saturation model [85] also describe the energy and centrality dependence well. Here we provide brief descriptions of three typical models before we present the experimental data and discuss their implications.

Two-component model Mini-jet production in a two-component model was proposed long ago to explain the energy dependence of the total cross section [86] and particle production

[87] in high-energy hadron collisions. This approach was incorporated into the HIJING model [70, 71] to describe initial parton production in high-energy heavy-ion collisions. In this two-component model, the nucleon-nucleon cross section at high energy is divided into collisions with or without hard or semi-hard jet production processes. The jet cross section  $\sigma_{\rm jet}$  is assumed to be given by the pQCD parton model. However, the differential jet cross section has an infrared divergence as the transverse momentum of the jet goes to zero. An infrared cut-off scale  $p_0$  is introduced to separate hard processes from soft processes that are not calculable in pQCD. The soft interaction cross section  $\sigma_{\rm soft}$  is a model parameter. The two parameters,  $\sigma_{\rm soft}$  and  $p_0$ , are determined phenomenologically by fitting the experimental data of total  $p + p(\bar{p})$  cross sections within the two-component model [70, 71].

The cut-off scale  $p_0$  separating non-perturbative and pQCD processes could in principle depend on both energy and nuclear size in A+A collisions. Using the Duke-Owens parameterization of parton distributions in the nucleon [88], an energy-independent cut-off scale  $p_0 = 2 \text{ GeV}/c$ , and soft cross section  $\sigma_{\text{soft}}$ , the HIJING model can describe well the experimental data on total cross sections, hadron multiplicity, and other observables from  $p + p(\bar{p})$  collisions [89]. The default HIJING prediction [90] agreed with the first data on  $dN_{ch}/d\eta(|\eta| < 1)$  of central Au + Au collisions at  $\sqrt{s} = 130 \text{ GeV}$  [84].

In applying the two-component model to nuclear collisions, multiple mini-jet production is assumed to be incoherent and thus is proportional to the number of binary collisions  $N_{bin}$ . The soft interaction is however coherent and proportional to the number of participant nucleons  $N_{part}$ , according to the Wounded Nucleon Model [69]. Assuming no final state effects on multiplicity from jet hadronization, the rapidity density of hadron multiplicity in heavy-ion collisions is then

<span id="page-19-0"></span>
$$\frac{dN_{ch}}{d\eta} = \frac{1}{2} \langle N_{part} \rangle \langle n \rangle_s + \langle n \rangle_h \langle N_{bin} \rangle \frac{\sigma_{\text{jet}}^{AA}(s)}{\sigma_{\text{in}}}, \tag{20}$$

where  $\sigma_{\rm jet}^{AA}(s)$  is the averaged inclusive jet cross section per nucleon-nucleon interaction in AA collisions. The average number of participant nucleons and number of binary collisions for a given impact parameter can be estimated via Glauber model simulation. Since the parameters  $\langle n \rangle_s$  and  $\langle n \rangle_h$  are determined from  $p + p(\bar{p})$  collisions, the only uncertainties are due to nuclear effects on  $\sigma_{\rm jet}^{AA}(s)$ , such as parton shadowing.

As an alternative to Eq. (20), a simpler parameterization of the "two-component" model is given by [91]

<span id="page-19-1"></span>
$$\frac{dN_{ch}}{d\eta} = (1 - x)n_{pp}\frac{\langle N_{part}\rangle}{2} + xn_{pp}\langle N_{bin}\rangle,\tag{21}$$

where  $n_{pp}$  is the multiplicity in p + p collisions and x is the fraction of sources scaling as hard collisions, related to  $\sigma_{\text{jet}}^{AA}(s)/\sigma_{\text{in}}$ .

A final-state parton cascade and hadronic rescattering processes can also be introduced into such a pQCD-based model. The AMPT model[92] uses HIJING for the initial conditions and includes parton and hadronic rescattering after-burners. The final-state rescattering is found not to change the bulk particle production significantly.

<span id="page-19-2"></span>Final State Saturation A mini-jet pair with transverse momentum  $p_0$  has intrinsic transverse area of  $\pi/p_0^2$ . In A+A collisions at high energy, independent production could result in multiple mini-jet production within this area, which is quantum mechanically disallowed. This sets the limit on the number of independent mini-jet pairs within a total transverse area  $\pi R_A^2$  as  $N(p_0) = p_0^2 R_A^2$ . The pQCD parton model gives the number of scattered partons above transverse

momentum cutoff  $p_0$  as  $N(p_0) = T_{AA}(b)\sigma_{\rm jet}(p_0)$ . In the final-state saturation model (EKRT [81]), the saturation scale  $p_{sat}$  is then defined by the self-consistent solution of

<span id="page-20-0"></span>
$$T_{AA}(b)\sigma_{\rm jet}(p_{sat}) = p_{sat}^2 R_A^2. \tag{22}$$

Below the saturation scale, jet production is correlated and the divergent mini-jet cross section will be regulated. The EKRT final-state saturation model neglects minijets with  $p_T < p_{sat}$  and assumes that the produced parton density (mostly gluons) and the transverse energy density are dominated by minijets above  $p_{sat}$ .

Numerical calculation [81] of Eq. (22) yields  $p_{sat} = 0.21 A^{0.13} (\sqrt{s})^{0.19}$  GeV/c, with initially produced gluon multiplicity  $N = 1.38 A^{0.92} (\sqrt{s})^{0.38}$ . The calculated ratio of energy density to multiplicity density is found to be very similar to that of an ideal gas of bosons,  $\epsilon/n \simeq 2.70T$ , so that for a wide range of A and  $\sqrt{s}$  the gluon gas is generated in a thermalized distribution in this model.

Assuming boost-invariant adiabatic expansion and proportionality between the produced parton and the observed hadron multiplicities, the charged hadron density in central collisions is given by [81]:

<span id="page-20-1"></span>
$$\frac{dN_{ch}}{d\eta}(b=0) \simeq \frac{2}{3}1.16A^{0.92}(\sqrt{s})^{0.4}.$$
 (23)

While this expression only applies for symmetric geometry, it has been extended to non-central collisions [93] and the centrality dependence may be approximated by replacing A with  $\langle N_{part} \rangle$  in the above equation.

<span id="page-20-2"></span>Initial State Saturation More commonly, parton saturation refers to high density effects in the initial state [94, 95]. For an elementary probe (a virtual photon in deep inelastic scattering, a projectile parton in hadronic collisions) interacting with a nucleus of mass A, the coherence length of the interaction in the rest frame of the nucleus is  $\ell_c \sim 1/(m_N x_{Bj})$ , where  $m_N$  is the nucleon mass and the Bjorken  $x_{Bj}$  is the fractional momentum that the struck parton carries. At sufficiently low  $x_{Bj}$ , the distribution is dominated by gluons and the coherence length  $\ell_c$  will exceed the nuclear diameter  $\sim 2A^{1/3}$ . Modification of parton distributions due to the coherence can be studied within the framework of Glauber multiple scattering in the rest frame of a nucleus [96]. More intuitively, saturation phenomena can be studied as multiple parton interactions in the infinite-momentum frame. For a hard process with momentum transfer Q, all gluons within transverse area  $1/Q^2$  will participate coherently in the interaction. Denoting the nuclear gluon structure function as  $xG_A(x,Q^2)$ , the density of gluons in the transverse plane is

$$\rho_A \simeq A \frac{xG(x, Q^2)}{\pi R_A^2} \sim A^{1/3},$$
(24)

where  $G_A(x,Q^2) \simeq AG(x,Q^2)$  and  $G(x,Q^2)$  is the gluon distribution in a nucleon.

For gluon scattering with cross section  $\sigma \sim \pi \alpha_s/Q^2$ ,  $\sigma \rho_A$  represents the probability of multiple gluon scattering. At high  $Q^2$  or  $\sigma \rho_A \ll 1$ , the system can be considered to be dilute, and the perturbative QCD parton model applies. However, for low  $Q^2$  or  $\sigma \rho_A \gg 1$ , the target looks black to the probe and the saturation regime is reached. The boundary where  $\sigma \rho_A \simeq 1$  defines the saturation scale  $Q_s$ . The physical process that leads to saturation is the nonlinear gluon fusion  $gg \to g$ , which competes with the gluon emission process  $g \to gg$ . The emission process increases the gluon number with rising  $Q^2$  according to the normal DGLAP evolution, while gluon fusion, which is proportional to  $\sigma \rho_A$ , reduces the gluon number. Saturation occurs when

the two processes offset each other and the saturation scale is determined by the self-consistent solution of the equation [95, 91]

<span id="page-21-0"></span>
$$Q_s^2 = \frac{8\pi^2 N_c}{N_c^2 - 1} \alpha_s(Q_s^2) x G(x, Q_s^2) \frac{A}{\pi R_A^2},$$
(25)

where the gluon distribution  $xG(x,Q_s^2)$  is evaluated at  $x=2Q_s/\sqrt{s}$ . In the saturation regime,  $xG_A(x,Q_s^2) \propto 1/\alpha(Q_s^2)$  and  $Q_s^2 \propto A^{1/3}$ . For large enough  $Q_s$ , the strong coupling constant will be small while the density is high, enabling treatment of the non-linear QCD dynamics by classical weak coupling methods. This provides the foundation for semi-classical treatment of the gluon distribution inside large nuclei [83, 97]. Often referred to as Colored Glass Condensate (CGC) model, this approach approximates the gluon distribution in large nuclei as the Weiszacker-Williams distribution from the classical Yang-Mills field of randomly distributed color charges. For a recent review see [17].

The initial saturation phenomenon is generic and is independent of the type of hadrons or nuclei being collided. However, the growth of  $Q_s^2$  as  $A^{1/3}$  suggests that saturation phenomena may occur at higher x (or equivalently, lower  $\sqrt{s}$ ) in collisions of heavy nuclei than in p + p collisions. Deep inelastic scattering data from HERA indicate that  $Q_s$  scales as[98]

<span id="page-21-1"></span>
$$Q_s^2(x) = Q_0^2 \left(\frac{x_0}{x}\right)^{\lambda},\tag{26}$$

with  $\lambda \sim 0.2-0.3$ . The saturation scale in heavy ion collisions at RHIC is estimated to be  ${Q_s}^2 \simeq 2~{\rm GeV}^2$  at  $x \sim 0.02$  [91], roughly the value of  ${Q_s}^2$  at  $x \sim 10^{-4}$  in p+p collisions at the same energy.

In contrast to the EKRT final-state saturation model, the initial-state saturation model assumes that final gluon production is dominated by gluons below the saturation scale [99] and ignores gluons above the saturation scale, whose yield falls as  $1/p_T^4$ . The density of gluons per unit area and unit rapidity produced in the collision is then given by [99]

$$\frac{dN}{d^2bdy} = c \frac{N_c^2 - 1}{4\pi^2 \alpha_s (Q_s^2) N_c} Q_s^2.$$
 (27)

Integrating over the transverse area and further assuming the hadronization coefficient is unity (one produced gluon becomes one final charged hadron), the observed charged hadron multiplicity in the most central Au + Au collisions is fitted to obtain the gluon liberation coefficient  $c = 1.23 \pm 0.20$  [91]. A similar value for c results from numerical calculation of initial parton production within the CGC model [100].

With these ingredients, the classical weak coupling treatment of initial-state saturation gives a prediction for the centrality dependence of the multiplicity density per participant pair[91]:

<span id="page-21-2"></span>
$$\frac{2}{N_{part}} dN/d\eta \simeq 0.82 \log \left(\frac{{Q_s}^2}{\Lambda_{QCD}^2}\right),\tag{28}$$

where  $\Lambda_{QCD}$ =200 MeV. The centrality dependence results from the variation of  $Q_s^2 \sim \rho_{part}$  with the impact parameter according to Eq. (25), where  $2A/\pi R_A^2$  is replaced by  $\rho_{part}$  as the transverse density of participant nucleons at fixed impact-parameter [91].

The collision energy and rapidity dependence of the multiplicity is governed by Eq. (26). Since rapidity  $y \sim \log(1/x)$ , the rapidity dependence of  $Q_s$  at fixed  $\sqrt{s}$  is  $Q_s^2(\pm y) = Q_s^2(y=0)e^{\pm \lambda y}$ .

![](_page_22_Figure_0.jpeg)

<span id="page-22-1"></span>Figure 11:  $\sqrt{s}$ -dependence of charged particle density per participant pair at midrapidity, for central collisions of heavy nuclei ( $A \sim 200$ , open and filled points) and  $\bar{p} + p$  collisions (points joined by line). Figure from PHOBOS [101].

In other words, at forward rapidity one nucleus moves deeper into the saturation regime (larger  $Q_s$ ) while the other moves towards the low density domain. The complete expression for the multiplicity density in the initial state saturation model is [85]

$$\frac{dN}{dy} = cN_{part} \left(\frac{s}{s_0}\right)^{\lambda/2} e^{-\lambda|y|} \left[ \log\left(\frac{Q_s^2}{\Lambda_{QCD}^2}\right) - \lambda|y| \right] \times \left[ 1 + \lambda|y| \left(1 - \frac{Q_s}{\sqrt{s}} e^{(1+\lambda/2)|y|}\right)^4 \right], \quad (29)$$

where  $Q_s^2(s) = Q_s^2(s_0)(s/s_0)^{\lambda/2}$ . This expression contains two free parameters c and  $Q_s^2(s_0)$ , which are fixed at one energy, rapidity and centrality.

## <span id="page-22-0"></span>4.2 Multiparticle Production

Total charged hadron multiplicities were the first published experimental data at RHIC [84]. Fig. 11 shows the energy dependence of the charged particle density at mid-rapidity normalized per participant pair, for collisions of heavy nuclei ( $A \sim 200$ ) and  $\bar{p} + p$ . The nuclear collision data are from the AGS, SPS and RHIC (the three highest energy points are from RHIC). The energy dependence is smooth, with only logarithmic dependence on  $\sqrt{s}$ . The growth for nuclear collisions is nevertheless faster than that in  $\bar{p} + p$  collisions, qualitatively in agreement with the expectation of a larger minijet contribution at higher energy[90].

A more differential view of bulk particle production is given by Fig. 12, which shows the centrality dependence of the multiplicity density per participant pair compared to several model calculations. In the left panel, the two-component fit and initial state saturation model are seen to describe within experimental uncertainties both the centrality dependence and the growth in multiplicity with energy. In the right panel, the EKRT prediction apparently fails to describe the centrality dependence, while the centrality dependence of HIJING is consistent with the data but the normalization is about 10% too low except for p + p collisions. The almost linear centrality dependence of the HIJING result is not characteristic of a two-component model. This effect may be caused by coherent string fragmentation of the minijet hadronization, which could modify the binary scaling of the number of hadrons from jet fragmentation. The two-component minijet model [102], which assumes independent fragmentation, describes the data well (shaded

![](_page_23_Figure_0.jpeg)

<span id="page-23-1"></span>Figure 12: Centrality dependence of the charged hadron central rapidity density per participant nucleon pair for Au + Au collisions from PHOBOS [84, 103] and PHENIX [104]. 200 GeV  $\bar{p} + p$  data (leftmost points) from UA5 [105, 106]. Left: theory calculations from two-component minijet model (shaded bands), two-parameter fit (Eq. (21)) (dot-dashed lines) and parton saturation model (solid lines) [85]. Right: data from 130 GeV collisions; theory calculations from Hijing [70, 71], EKRT saturation (Eq. (23)), and two-parameter fit (Eq. (21)).

bands, left panel). Both the HIJING model and the two-component minijet model have parton shadowing that depends on impact-parameter. Similarly, the saturation models have an impact parameter-dependent saturation scale.

Note, however, that the calculated quantity  $\langle N_{part} \rangle$  appearing in both the ordinate and abscissa in Fig. 12 is derived using the Monte Carlo Glauber model for the data in both panels. The uncertainty inherent in this procedure is demonstrated in Fig. 13, which shows the same STAR data in both panels but with  $\langle N_{part} \rangle$  calculated via the Optical (left) and Monte Carlo (right) approach to the Glauber calculation [73]. With the Optical Glauber approach the logarithmic growth at low  $N_{part}$ , the hallmark of initial state saturation (Eq. 28), is not seen, while the final state saturation model (EKRT) still disagrees with the data, though less significantly than with the Monte Carlo approach. Though other measurements favor the Monte Carlo Glauber (Fig. 8), the saturation model curves in Fig. 12 are calculated using Optical Glauber, obscuring somewhat the direct comparison to data. The centrality dependence of the multiplicity density and its comparison to models therefore requires further clarification, but it is apparent that multiparticle production in central collisions can be well described by a broad range of theoretical approaches, with about 20% uncertainty both in theory and in the measurement of the centrality dependence. All of these models point to initial conditions with high initial gluon density.

## <span id="page-23-0"></span>4.3 Pseudo-rapidity Distributions

Fig. 14, upper panels, show the charged particle pseudorapidity distribution over the full RHIC phase space for Au+Au collisions at several centralities and energies, measured by PHOBOS

![](_page_24_Figure_0.jpeg)

<span id="page-24-0"></span>Figure 13:  $dN_{ch}/d\eta/(\langle N_{part}\rangle/2)$  utilizing Optical (left) and MC (right) Glauber calculations with the same STAR data [73]. The error bars for adjacent data points are highly correlated. Kharzeev-Nardi refers to a two component soft/hard fit [Eq. 21].

[107]. The distributions exhibit two general features: a plateau about midrapidity which broadens with increasing collision energy, and a forward region whose width is approximately invariant. The total charged multiplicity for central collisions at  $\sqrt{s_{_{\mathrm{NN}}}}$ =200 GeV is 5060 ± 250 [107], indicating a qualitatively new regime of accelerator-based experimentation in high energy and nuclear physics.

Figure 14, lower panels, compare the 200 GeV data from BRAHMS [108] to both saturation model [85] and AMPT [92] calculations. AMPT combines the HIJING model with partonic and hadronic final-state rescattering and includes an alternative baryon pair production mechanism. Good agreement with data is found for both model calculations.

Study of bulk particle production in p(d) + A collisions may help to separate initial from final state effects, since a dense medium is not formed in the central rapidity region in such collisions. Figure 15 shows the charged multiplicity density distribution for minimum bias d + Au collisions at  $\sqrt{s}$ =200 GeV [109] (see also BRAHMS [110]). This measurement offers a unique probe of particle production, because of the large projectile asymmetry. All panels show the same data, which are compared to various model calculations. The data indeed exhibit an asymmetry in particle production, with larger multiplicity density towards the direction of the Au beam ( $\eta$ <0). The left panel of the figure compares the data to predictions from the HIJING [70, 71] and AMPT models [92]. The predictions agree with the data except at large negative rapidity, the region of the Au-nucleus fragmentation. Evidently the final state interactions and baryon production mechanisms in AMPT provide a better description of this region.

Using the weak coupling approach to the saturation regime in the initial state saturation model, the rapidity dependence of the charged multiplicity in d + Au collisions is given by [111]

<span id="page-24-1"></span>
$$\frac{dN}{dy} = C \frac{SQ_{s,min}^{2}(y)}{\alpha_{s}(Q_{s,min}^{2}(y))} \left\{ \left(1 - \frac{Q_{s,min}(y)}{\sqrt{s}} e^{y}\right)^{4} + \left[\ln\left(\frac{Q_{s,max}^{2}(y)}{Q_{s,min}^{2}(y)}\right) + 1\right] \left(1 - \frac{Q_{s,max}(y)}{\sqrt{s}} e^{y}\right)^{4} \right\}, (30)$$

where S is the the interaction cross section.  $Q_{s,max}$  and  $Q_{s,min}$  denote the larger and smaller of

![](_page_25_Figure_0.jpeg)

<span id="page-25-0"></span>Figure 14: Charged hadron distributions over the full RHIC phase space for Au + Au collisions. Top: Centrality and  $\sqrt{s_{\rm NN}}$  dependence of  $dN_{ch}/d\eta$  from PHOBOS [107]. Bottom: Centrality dependence of  $dN_{ch}/d\eta$  at  $\sqrt{s} = 200$  GeV, from BRAHMS (circles) [108]. Stars are  $\bar{p} + p$  data scaled by  $N_{part}/2$  [105]. Calculations are saturation model (solid) [85] and AMPT (dashed) [92].

![](_page_26_Figure_0.jpeg)

<span id="page-26-0"></span>Figure 15:  $dN_{ch}/d\eta$  for minimum bias d+Au collisions at  $\sqrt{s}$ =200 GeV, from PHOBOS [109]. All panels show the same data. The left panel compares to model calculations from AMPT [92] and Hijing [70, 71]. The middle and right panels compare to saturation model calculations [111] (Eq. [30]) using Optical (middle) and Monte Carlo (right) Glauber calculations and slightly different proton saturation parameters.

the saturation scales in the deuteron and the Au nucleus, which vary with rapidity  $y \sim \log(1/x)$  as  $e^{\lambda y}$  [Eq. 26].  $Q_s$  is assumed to be the same for the deuteron and proton. Since  $SQ_s^2 \sim N_{part}$  [85],  $dN/dy \sim N_{part}(Au)$  in the Au-fragmentation region and  $dN/dy \sim N_{part}(d)$  in the deuteron-fragmentation region, replicating the scaling of the phenomenological Wounded Nucleon Model [69]. The factor C in Eq. 30 is determined from the midrapidity charged hadron density in 130 GeV Au+Au collisions.

The solid line in the middle panel of Fig. 15 shows Eq.(30) utilizing an Optical Glauber calculation [111]. (We will not discuss the curve labelled "RQMD".) The calculation overestimates the measured distribution in the Au-fragmentation region and underestimates it in the d-fragmentation region. A revised version of the calculation (erratum to [111]) utilizing a Monte Carlo rather than Optical Glauber calculation and a slightly different proton saturation parameter achieves good agreement with the measurement (right panel).

The summary of this section is similar to that of the previous section: both pQCD-based models and models incorporating initial state saturation reproduce the pseudo-rapidity distributions quite well over very broad phase space. The common feature of these models is again that the initial energy density is very high, but evidently these observables are not sufficiently discriminating to distinguish between the rather different production mechanisms of the models.

![](_page_27_Figure_0.jpeg)

<span id="page-27-1"></span>Figure 16: Rapidity dependence of  $p_T$ -integrated particle yields from central Au + Au collisions at 200 GeV, from BRAHMS. Left:  $\pi^{\pm}$ ,  $K^{\pm}$ , p and  $\bar{p}$ [117, 118, 119]. Dashed lines are Gaussian fits. Lower panel shows rapidity dependence of  $\langle p_T \rangle$ . Right: net protons (difference of p and  $\bar{p}$  yields) compared to lower energy collisions [118].

## <span id="page-27-0"></span>4.4 Rapidity Distributions and Baryon Stopping

Some time ago, Bjorken postulated that the rapidity distribution at very high collision energy should develop a plateau in the central rapidity region, which results from a reaction volume that is invariant under longitudinal boost [112]. This assumption leads to considerable simplification of the hydrodynamic equations and is common in theoretical treatments of mid-rapidity observables [113] (Sect. 5.1). The plateau in pseudo-rapidity density seen in Fig. 14 suggests that the fireball near mid-rapidity may indeed be boost-invariant. However, pseudorapidity  $\eta$  only approximates rapidity y. Figure 16, left panel, shows the rapidity dependence of particle production separately for pions, kaons and protons. While the rapidity distributions are indeed broad, no plateau is observed and except for protons they are Gaussian in shape. Less marked but still significant rapidity dependence is also seen for  $\langle p_T \rangle$ . These distributions may nevertheless result from boost-invariant initial conditions of limited extent in rapidity (e.g. [114, 115]). Note that even at LHC energies ( $\sqrt{s_{_{NN}}}$ =5500 GeV) the initial energy density computed from pQCD with saturation scale  $p_{sat}$ =2 GeV is not uniform in rapidity[116], so that a boost-invariant initial condition may in any case not be the correct high energy limit.

Baryon number is conserved in the collision and its rapidity distribution should be very different from that of produced particles. Since rapidity is logarithmic in energy, it is not changed significantly by rescattering. The net baryon rapidity distribution observed in the final state is therefore established to a large extent early in the collision, reflecting the mechanisms of energy transfer from the colliding nuclei to the fireball. In thermodynamic terms, finite net baryon number results in finite baryochemical potential  $\mu_B$  (Sect. 5.4). While the distribution of total baryon number is difficult to access experimentally, it can be deduced from the net proton distribution  $p - \bar{p}$  (Fig. 16, right panel), which is seen to be small but finite at midrapidity. The BRAHMS data indicate a net baryon density  $dN/dy \simeq 10$  for central Au+Au collisions at y = 0 [118], in agreement with other analyses [76, 120].

The mean rapidity loss of leading baryons in lower energy fixed target interactions of protons

with heavy nuclei is  $\langle \Delta y \rangle \sim 2.5$ , in contrast to  $\langle \Delta y \rangle \sim 1$  for proton-hydrogen interactions [121]. The rapidity distribution of net protons in Fig. 16, taken together with conservation of net baryon number, significantly constrains the full net baryon rapidity distribution, resulting in  $\langle \Delta y \rangle \sim 2.0 \pm 0.2$ [118] and a mean energy loss per participating nucleon of  $\Delta E = 72 \pm 6$  GeV in central Au + Au collisions [118]. In other words, for interacting nucleons about 70% of the incoming beam energy of 100 GeV per nucleon is delivered to the fireball. Central collisions have about 350 participants, giving  $\sim 25$  TeV transferred from the incoming projectiles to final particle production. It is notable both that the net baryon density at midrapidity is small for central collisions relative to the  $2 \times 197$  nucleons brought into the collision and that it is finite, indicating transfer of baryon number over 5.5 rapidity units.

The conventional mechanism for baryon transport in hadronic and nuclear collisions is the fragmentation of quark-diquark (q-qq) strings [122]. However, such string fragmentation models underpredict the baryon stopping measured in nuclear collisions both at SPS [123] and at RHIC energies [124]. An alternative scenario considers baryon structure comprising the gauge junction which carries the baryon number of three quarks in their fundamental representation [125, 126]. An implementation of this baryon junction mechanism in HIJING/BB [127] describes well the measured baryon stopping at RHIC [124]. Other modified string fragmentation models [128, 129] and diquark rescattering [130, 131] can also provide stronger baryon stopping power than the conventional string fragmentation. However, it is not clear at this point which of the baryon transport mechanisms are dominant in high energy heavy-ion collisions.

### <span id="page-28-0"></span>4.5 Transverse Energy and Energy Density

Significant transverse energy  $E_T$  can only be generated during the collision, through the initial interactions of partons from the projectiles and the successive interactions among the produced partons and hadrons. Experimentally,  $E_T$  is defined as  $E_T = \sum_i E_i \sin(\theta_i)$ , where i sums over all final state hadrons. The hadron energy  $E_i$  is corrected for conserved baryon number, and  $\theta_i$  is the angle relative to the beam direction. Due to the dynamics of the expansion,  $E_T$  in a limited rapidity interval will evolve through the lifetime of the collision. In the framework of hydrodynamics this dependence is [132, 133]:

$$\frac{E_T(\tau)}{E_T(\tau_0)} = \left(\frac{\tau_0}{\tau}\right)^{\delta},\tag{31}$$

where  $\tau_0$  is the equilibration time. Local thermodynamic equilibrium is characterized by energy density  $\epsilon$ , pressure p, and speed of sound  $c_0^2 = \partial p/\partial \epsilon$ . If equilibrium is established at  $\tau_0$  and maintained throughout the expansion with constant  $c_0^2$ , then  $\delta = c_0^2$  and the observed  $E_T$  is substantially reduced relative to the initially generated  $E_T$  due to the  $p\Delta V$  work performed during the expansion [132]. Alternatively, if the system falls out of equilibrium quickly into a free-streaming gas,  $\delta = 0$  and there will be no  $p\Delta V$  work performed during the evolution, so that  $E_T$  will remain constant throughout the expansion. Final state saturation effects (Sec. 4.1) reduce early pressure, delaying the onset of hydrodynamic behavior and leading to significant reduction in the observed  $E_T$  [133].

It is difficult to disentangle these competing mechanisms based solely consideration of  $E_T$  distributions, but the systematic study of  $E_T$  together with that of other bulk observables may isolate the contribution of longitudinal work. If hydrodynamic flow can be shown to set in early from other considerations, the measured  $E_T$  will provide a lower limit to the initially produced

![](_page_29_Figure_0.jpeg)

<span id="page-29-0"></span>Figure 17: Transverse energy  $E_T$  for Au + Au collisions at  $\sqrt{s_{NN}} = 130$  GeV, from PHENIX [134] compared to Pb + Pb collisions at  $\sqrt{s_{NN}} = 17$  GeV [135]. Left:  $E_T$  per participant. Right:  $E_T$  per charged particle. The Pb + Pb data in both panels have an overall normalization uncertainty of  $\pm 20\%$ , not shown.

transverse energy at the time of equilibration and thus provide an estimate of the initial energy density.

Fig. 17 from PHENIX [134] shows the centrality dependence of  $E_T$  for  $\sqrt{s_{\rm NN}}=130$  GeV Au+Au collisions, compared to Pb+Pb collisions at  $\sqrt{s_{\rm NN}}=17$  GeV [135]. In the left panel,  $E_T$  per participant is seen to increase with increasing  $\sqrt{s}$  for all centralities. As shown in the right panel, however,  $E_T$  per charged particle is largely independent of collision energy, meaning that the dependence of  $E_T$  on energy and centrality closely parallels that of the charged multiplicity in Figs. 12-14. Since the average  $\langle p_T \rangle$  for charged hadrons in  $p+p(\bar{p})$  collisions increases significantly with  $\sqrt{s}$  [136], a constant  $E_T$  per hadron in heavy-ion collisions implies the existence of  $p\Delta V$  work due to hydrodynamic expansion. Indeed, hydrodynamic calculations assuming onset of equilibration at  $\tau_0 < 1$  fm/c are able to reproduce approximately the centrality dependence of  $E_T$  per charged particle [113].

In the Bjorken picture of boost-invariant free-streaming expansion, the initial energy density can be expressed in terms of the observed  $E_T$  [112]:

$$\epsilon_{Bj} = \frac{dE_T}{dy} \frac{1}{\tau_0 \pi R^2}.$$
 (32)

The formation time is taken to be  $\tau_0 \sim 1$  fm/c and initial system size  $R \simeq 1.2 A^{1/3}$ , equal to the nuclear radius. This expression relies on the assumption that no  $p\Delta V$  work is done during the expansion [132] and it therefore represents a lower bound to the initial energy density within the hydrodynamic framework. PHENIX has measured  $dE_T/d\eta \simeq 540$  GeV[134] at midrapidity for central Au + Au collisions at  $\sqrt{s_{\rm NN}} = 130$  GeV, resulting in  $\epsilon_{Bj} = 4.6$  GeV/fm<sup>3</sup>. In comparison, NA49 estimates  $\epsilon_{Bj} \sim 3$  GeV/fm<sup>3</sup> for central Pb + Pb collisions at  $\sqrt{s_{\rm NN}} = 17.2$  GeV[137]. These values are provocative: they lie well above the deconfinement energy density predicted by Lattice QCD calculations (Sect. 2.1). However, the calculation is based on the assumption rather than the demonstration that the onset of hydrodynamic expansion occurs at  $\tau_0 \simeq 1$  fm/c. In

the following sections we will address this question through measurements sensitive to local equilibration at the early, hot and dense phase of the collision, in particular elliptic flow.

# <span id="page-30-0"></span>5 Collective Phenomena

A central question at RHIC is the extent to which the quanta produced in the collision interact and thermalize. Nuclear collisions generate enormous multiplicity and transverse energy, but in what sense does the collision generate matter in local equilibrium which can be characterized by the thermodynamic parameters temperature, pressure, and energy density? Only if thermalization has been established can more detailed questions be asked about the equation of state of the matter.

The initial energy density, whether equilibrated or not, will have strong spatial gradients due to the geometry of the colliding nuclei and the dynamics of the collision. Reinteractions among the fireball constituents will convert these density gradients into pressure gradients, resulting in collective flow of the matter. Collective flow is thus a generic consequence of reinteractions, which also lead to thermalization. It is however not sufficient merely to observe collective flow, which may be generated both early through partonic reinteractions and later through interactions in the dense hadronic gas. It is partonic thermalization and the partonic Equation of State that are of interest, but their signals may be masked by the hadronically generated flow that must be understood and unraveled.

In this section we discuss hadronic observables that are sensitive to collective flow and the degree of thermalization in nuclear collisions at RHIC. Of particular importance is the azimuthal anisotropy of the final hadron spectra in non-central collisions ("elliptic flow") that results from the conversion of the initial coordinate-space asymmetry to momentum space via collective expansion. The particle mass dependence of flow is an especially sensitive observable, since a common velocity distribution for fluid cells radiating particles of different mass will result in a characteristic mass dependence of the momentum spectra.

## <span id="page-30-1"></span>5.1 Relativistic Hydrodynamics

Relativistic hydrodynamics provides the theoretical framework to study collective behavior in high energy collisions, with the first such attempts dating back to Landau [\[138\]](#page-85-24). We sketch here the basic ideas and compare hydrodynamic calculations to a wide range of RHIC data. Generally good agreement is achieved (though with notable exceptions), providing strong evidence that local equilibrium is established early in the evolution of the fireball (τ<1 fm/c) and that the system evolves in accordance with ideal hydrodynamics. Some sensitivity to the equation of state is observed, with preference for a deconfined phase early in the evolution. Detailed reviews of relativistic hydrodynamics with applications to RHIC data can be found in [\[113,](#page-84-26) [139\]](#page-85-25).

We first present a simple estimate to assess whether hydrodynamics is a reasonable approach to modeling the dynamics of a deconfined phase [\[139\]](#page-85-25). Consider a two-flavor QGP at temperature <sup>T</sup> <sup>∼</sup> 200 MeV, which has partonic density <sup>n</sup> <sup>∼</sup> 4 fm<sup>−</sup><sup>3</sup> . Assuming the Debye screening mass µ = gT as the typical momentum transfer in gluon-gluon scattering, the pQCD cross section σgg→gg ∼ 3 mb gives a mean free path λ = 1/σn ∼ 0.8 fm. The time between collisions is therefore an order of magnitude smaller than the expected system lifetime of a few fm/c, so that the multiple reinteractions necessary for thermalization may occur.

Hydrodynamic behavior can set in only at a finite time after the collision, when the produced

quanta have interacted and relaxed into local equilibrium. Hydrodynamics therefore does not address the earliest moments of the fireball evolution, and its initial conditions (density distributions and flow velocities) must be imposed on the basis of other considerations. The initial conditions (entropy, energy, and net baryon number density) are constrained by comparing to experimental data such as hadron multiplicities and transverse energy production.

The hydrodynamic evolution terminates when the system has expanded and cooled to a degree that the mean free path exceeds system size and local equilibration can no longer be maintained ("freezeout"). Generically, two stages of freezeout are expected: chemical freezeout occurs when the mean free path for inelastic collisions exceeds the system size, whereas kinetic freezeout occurs at a later time and a lower temperature, when the elastic mean free path also exceeds the system size. The produced hadrons, dominantly soft, are created continuously at the dilute periphery of the fireball, according to a specific prescription of kinetic freezeout. Though these soft hadrons do not directly transmit signals from the hot and dense early stage of the collision, the systematic study of the transverse momentum and mass dependence of soft hadron production can provide substantial evidence for early pressure build-up and therefore equilibration. Sufficiently detailed and precise comparison of data and calculations will also be able to constrain the initial conditions and the EOS at the early stage.

For ideal, non-dissipative hydrodynamics, the energy-momentum tensor T µν (x) in the global reference frame for a fluid cell at space-time coordinate x is given by [\[113\]](#page-84-26)

$$T^{\mu\nu}(x) = [e(x) + p(x)]u^{\mu}(x)u^{\nu}(x) - p(x)g^{\mu\nu}, \tag{33}$$

where e(x) is the energy density, p(x) is the pressure, and u µ (x) is the four-velocity of the cell. Correction for non-ideal hydrodynamics adds a term that is the product of the shear viscosity η with the thermally averaged gradient of the velocity field [\[140\]](#page-85-26).

The equations of motion result from local conservation of energy and momentum,

<span id="page-31-0"></span>
$$\partial_{\mu}T^{\mu\nu}(x) = 0 \ (\nu = 0, \dots, 3).$$
 (34)

Additional equations result from the conservation of M different charges (net baryon number, net strangeness, electric charge),

<span id="page-31-1"></span>
$$\partial_{\mu} j_i^{\mu}(x) = 0 (i = 1 \dots, M),$$
 (35)

where j µ i (x) = ni(x)u µ (x) is the current density in the global frame and ni(x) is the local charge density.

Expressions [\(34\)](#page-31-0) and [\(35\)](#page-31-1) comprise 4 + M differential equations for 5 + M fields: the three components of the flow velocity, the energy density, the pressure, and the M charge densities. The system of equations is closed by the equation of state (EOS) p(e, ni), which relates the pressure, energy density, and conserved charge densities. Most applications of hydrodynamics to RHIC data use a similar structure for the equation of state [\[139\]](#page-85-25): a plasma phase of massless partons with a bag constant, a hadronic phase consisting of a gas of free hadrons and resonances, and a first order phase transition with a large latent heat connecting the two phases.

The initial conditions at the onset of hydrodynamic expansion must be specified from external input, usually either the entropy or energy density, with distribution in the transverse plane according to that for binary collisions or participants nucleons [\[139\]](#page-85-25). Saturation initial conditions have also been considered [\[141\]](#page-86-0). The conventional implementation of freezeout is via the Cooper-Frye prescription[\[142\]](#page-86-1) which corresponds to an instantaneous transition from zero to infinite

![](_page_32_Figure_0.jpeg)

<span id="page-32-1"></span>Figure 18: Radial dependence of the flow velocity from full hydrodynamic calculations of central Au + Au collisions at RHIC. Left: at various proper times [113]. Right: dependence at hadronization on equation of state [145]. The left panel is most comparable to LH8.

<span id="page-32-0"></span>mean free path, i.e. from ideal hydrodynamics to free streaming. The spectrum of hadron species i at freezeout is given by

$$E\frac{dN_i}{d^3p} = \frac{g_i}{(2\pi)^3} \int_{\Sigma} \frac{1}{\exp((p_{\nu}u^{\nu} - \mu_i)/T) \pm 1} p^{\mu} d^3 \sigma_{\mu}, \tag{36}$$

where the integral is carried out over the hypersurface  $\Sigma(x)$  on which the freezeout conditions are met.  $\mu_i(x)$  is the local chemical potential for species i and T(x) is the local temperature.

Having specified the EOS and initial conditions, the differential equations (34) and (35) are integrated numerically to freezeout, where the stable hadrons and resonances are generated according to Eq. (36). Integration of the full three dimensional hydrodynamic equations is a daunting task [143]. The assumption of longitudinal boost invariance is often made, with the imposed symmetry reducing the number of coupled equations and simplifying the numerical problem considerably [113]. This approach is however only applicable to mid-rapidity observables.

The instantaneous freezeout embodied in the Cooper-Frye prescription is unphysical. A more realistic though calculationally more intensive transition to on-shell hadrons results from coupling the hydrodynamic evolution to a kinetic transport model [144, 145]. However, at present the experimentally accessible observables exhibit no significant variation between this approach and the simpler Cooper-Frye algorithm [113].

Fig. 18 shows the radial profile of the transverse flow velocity  $v_r$  resulting from two different hydrodynamic calculations for central Au + Au collisions at RHIC [113, 145]. The left panel shows the time dependence of  $v_r$  with an EOS incorporating a first order phase transition. In the bulk  $(r < \sim 6 \text{ fm})$ , the buildup of transverse velocity due to pressure is rapid, achieving a roughly linear gradient  $\sim 0.07/fm$  that persists for the lifetime of the fireball. The velocity near the dilute surface varies strongly with radius at early times due to the initialization of matter

![](_page_33_Figure_0.jpeg)

<span id="page-33-1"></span>Figure 19: Identified particle inclusive spectra for centrality-selected Au + Au collisions at  $\sqrt{s_{_{\rm NN}}}$ =200 GeV. Left:  $\pi^{\pm}$ , K<sup>±</sup>, p and  $\bar{p}$  from PHENIX [76]. Right:  $\Lambda + \bar{\Lambda}$  and  $K_s^0$  from STAR [146, 147].

in the mixed phase, which has vanishing pressure gradient, and in the hadronic phase at the largest radii. This surface feature is eventually overtaken by the expanding plasma at higher pressure. The largest system size is achieved at  $\tau \sim 10$  fm/c; by 15 fm/c the freezeout surface is contracting inwards.

The right panel of Fig. 18 shows the transverse rapidity  $y_T = \tanh^{-1} v_r$  for three different equations of state [145]: a hadronic resonance gas (RG), plasma and hadronic phases linked by a mixed phase with latent heat 0.8 GeV/fm³ (LH8), and mixed and hadronic phases only (i.e. infinite latent heat, LH $\infty$ ). The flow profiles are shown for constant energy density e = 0.45 GeV/fm³, where in this calculation the hydrodynamic evolution is terminated and the produced hadrons propagated further using a kinetic transport model. The resonance gas EOS is seen to be quite stiff, generating a higher transverse velocity gradient than those containing a mixed phase. The presence of the plasma phase also provides significant pressure, generating twice the flow velocity at large radius than the case where it is absent (LH8 vs LH $\infty$ ). Similar to the calculations in the left panel, LH8 also produces a radial velocity gradient  $\sim 0.07$ /fm late in the evolution. Note that constant energy density does not correspond to constant proper time in this calculation. The double-valued loop at large radius for LH8 is also due to matter on the dilute surface initially generated in the mixed or hadronic phase, freezing out rapidly after modest radial expansion.

#### <span id="page-33-0"></span>5.2 Transverse Radial Flow

In the hydrodynamic picture just described, the observed final state hadrons freeze out from fluid cells that are in local equilibrium but that have finite transverse velocity relative to the lab frame. Since the thermal sources for all hadron species are boosted with the same *velocity* distribution, the hydrodynamic expansion should result in a characteristic mass dependence of the *transverse momentum* spectra for momenta on the order of the particle mass.

We first look at the systematic features of the data. Fig. 19 shows inclusive transverse

momentum spectra for  $\pi^{\pm}$ ,  $K^{\pm}$ , p and  $\bar{p}$  from PHENIX [76] (left panel) and  $\Lambda + \bar{\Lambda}$  and  $K_s^0$  from STAR [146, 147] (right panel), for centrality-selected Au + Au collisions at  $\sqrt{s_{NN}} = 200$  GeV. The shape of the baryon spectrum changes qualitatively from peripheral to central collisions. Relative to the meson yields, the baryon yields in central collisions are suppressed at low  $p_T$  and enhanced at higher  $p_T$ , with a marked change of slope at 1-2 GeV/c. For  $p_T > 2$  GeV/c, the baryon yields exceed the meson yields (Sect. 6.5).

Fig. 20 compares hydrodynamic calculations [148, 113] to measured  $p_T$  spectra from Au + Au collisions of  $\pi^-$ ,  $K^+$  and  $\bar{p}$  [149, 120, 150] and  $\Omega^-$  [151]. For the upper left, upper right, and lower left panels, the parameters of the calculation were fixed by fitting the  $\pi^+$  and  $\bar{p}$  distributions in central collisions, resulting in an equilibration time  $\tau = 0.6$  fm/c with temperature T = 340 MeV and energy density e = 25 GeV/fm<sup>3</sup> at the core of the fireball. The remaining curves in those panels are then predictions of the model. Overall agreement with the data is good. Deviations are seen at low  $p_T$  for the pions, now understood to be due to the imposition of chemical equilibrium through to kinetic freezeout [113]. More significant disagreements are seen for  $p_T > 2$  GeV/c in the most peripheral collisions. This may delineate the region of applicability of the hydrodynamic approach, since the fireball is smallest for peripheral collisions and high  $p_T$  particles require the greatest number of collisions to thermalize [113].

The lower right panel of Fig. 20 compares the  $p_T$  spectrum of  $\Omega^-$  in central 200 GeV Au + Au collisions to a similar calculation, adjusted for the higher collision energy and with a chemical non-equilibration EOS in the hadronic phase [152]. The steeper set of curves results from decoupling at energy density  $e = 0.45 \text{ GeV/fm}^3$ , corresponding to kinetic freezeout at the onset of the hadronic phase. The shallower set of curves results from decoupling at the same time as the pions at  $e = 0.075 \text{ GeV/fm}^3$ , so that the  $\Omega^-$  receives the full boost from the hadronic phase. (Solid lines are for zero initial flow, dashed lines are for small but finite radial flow at the onset of hydrodynamic behavior [152]). It has been proposed that multistrange baryons decouple from the flow much earlier than non-strange hadrons due to absence of strong resonances with pions [153]. Evidently, purely partonic hydrodynamic flow (lower curves) does not generate sufficient transverse velocity to describe the  $\Omega^-$  spectrum and there is significant contribution from the hadronic phase [113].

The systematic behavior of flow-related observables is extracted by fitting measured spectra to the phenomenological Blast Wave parameterization [154, 155], which results from modeling the system at freezeout as an ensemble of transversely boosted Boltzmann distributions. The transverse velocity distribution is a parameterization of the radial dependence of the fluid cell velocity distribution at freezeout from the full hydrodynamic calculation (Fig. 18):

$$\beta_T(r) = \beta_s \left(\frac{r}{R}\right)^n,\tag{37}$$

where R is the radius at freezeout and  $\beta_s$  is the transverse flow velocity at the surface. n=1 reasonably approximates of the full calculation. Assuming that kinetic freezeout occurs instantaneously at all radii, the hadronic spectra are given by [155]:

$$\frac{dN}{m_T dm_T} \propto \int_0^R r \ dr \ m_T I_0 \left(\frac{p_T \sinh \rho}{T}\right) K_1 \left(\frac{m_T \cosh \rho}{T}\right), \tag{38}$$

where  $m_T = \sqrt{p_T^2 + m^2}$ ,  $\rho(r) = \tanh^{-1} \beta_T(r)$  is the transverse rapidity and T is the local temperature. Non-instantaneous freezeout results in additional terms in the integrand which can change the spectrum shape significantly [155].

![](_page_35_Figure_0.jpeg)

<span id="page-35-0"></span>Figure 20: Transverse momentum spectra of identified hadrons from Au + Au collisions at RHIC, compared to hydrodynamic calculations. Upper left, upper right, and lower left: 130 GeV Au + Au data from PHENIX [149] and STAR [120, 150], calculations from [148]. Lower right: 200 GeV central Au + Au data from STAR [151], calculations from [113].

![](_page_36_Figure_0.jpeg)

<span id="page-36-1"></span>Figure 21: Freezeout temperature Tf o and mean flow velocity hβ<sup>T</sup> i for centrality-selected 130 GeV Au + Au collisions, from PHENIX [\[156\]](#page-86-15). Filled points are Blast Wave fits to data, open boxes are from a full hydrodynamic calculation. The dotted line is for blast wave with centralityindependent Tf o=128 MeV. [\[157\]](#page-86-16).

Figure [21](#page-36-1) shows the collision centrality dependence of the freezeout temperature Tf o and mean flow velocity hβ<sup>T</sup> i for a Blast Wave fit to the measured π, K and p spectra for 130 GeV Au + Au collisions [\[156\]](#page-86-15), and for a full hydrodynamic calculation similar to that in Fig [20](#page-35-0) [\[157\]](#page-86-16). The dashed line shows hβ<sup>T</sup> i for fixed Tf o=128 MeV, the value used in the full calculation, allowing a direct comparison of the parameterization with the theory. The agreement between the Blast Wave parameterization and the full calculation is good for more central collisions, indicating that the Blast Wave formulation contains the essential freezeout features of the hydrodynamic calculation. All approaches show lower Tf o and higher hβ<sup>T</sup> i for more central collisions, indicating a longer expansion time until freezeout. Marked deviations are seen only for the most peripheral collisions, where the region of local thermalization, if any, may be small and short-lived. Figs. [20](#page-35-0) and [21](#page-36-1) suggest that hydrodynamic flow dominates the fireball evolution for all but the most peripheral collisions.

# <span id="page-36-0"></span>5.3 Anisotropic Flow

In non-central nuclear collisions the overlap region is azimuthally anisotropic. Fig. [22,](#page-37-0) left panel, shows the density of binary collisions in the transverse plane, a common basis for calculating the initial energy density, for Au+Au interactions with impact parameter b=7 fm [\[113\]](#page-84-26). For hydrodynamic evolution, the initial spatial anisotropy will generate azimuthally anisotropic pressure gradients that are stronger in the reaction plane (horizontal in the figure) than perpendicular to it. This will result in a spatially anisotropic momentum distribution which is experimentally observable [\[158\]](#page-86-17).

At mid-rapidity the odd harmonics vanish by symmetry and the leading anisotropy is ellip-

![](_page_37_Figure_0.jpeg)

<span id="page-37-0"></span>Figure 22: Azimuthal spatial and momentum anisotropy for non-central (b=7 fm) Au + Au collisions. Left: density of binary collisions in the transverse plane [113]. Right: time evolution of spatial eccentricity  $\epsilon_x$  and momentum anisotropy  $\epsilon_p$  [159]. Solid lines are for EOS with phase transition, dashed line for massless ideal gas at very high temperature.

tical. The initial spatial eccentricity is defined as

<span id="page-37-2"></span>
$$\epsilon_x = \frac{\langle y^2 - x^2 \rangle}{\langle y^2 + x^2 \rangle} \,, \tag{39}$$

where  $\langle ... \rangle$  indicates the average weighted, for instance, by energy density. The corresponding momentum space anisotropy in the hydrodynamic framework is

$$\epsilon_p(\tau) = \frac{\int dx dy (T^{xx} - T^{yy})}{\int dx dy (T^{xx} + T^{yy})}.$$
(40)

This momentum space anisotropy ("elliptic flow") results from interactions within the medium and therefore develops over time as the fireball evolves. Figure 22, right panel, shows the time evolution of both  $\epsilon_x$  and  $\epsilon_p$  for b=7 fm Au + Au collisions. The solid lines are from a hydrodynamic calculation with a first order phase transition, similar to that in Fig. 20 [159]. The spatial eccentricity  $\epsilon_x$  is large at the onset of hydrodynamic flow ( $\sim 0.27$ ) but decreases continuously with time. The pressure is sufficient to drive  $\epsilon_x$  negative prior to freezeout. In contrast,  $\epsilon_p$  grows rapidly but saturates at  $\tau \sim 6$  fm/c due to the low pressure in the mixed phase. A small increase in  $\epsilon_p$  is generated in the hadronic phase, but almost all of the final momentum asymmetry is generated in the partonic phase at early time. The early buildup of momentum anisotropy is seen not only in hydrodynamic calculations but also in kinetic transport models [160, 161]. Elliptic flow is thus a key observable of collective hydrodynamic behavior and thereby thermalization at RHIC. It is predominantly generated early in the evolution and is potentially sensitive to the properties of the partonic stage of the collision.

<span id="page-37-1"></span>Experimentally, flow is measured by fitting the triple differential invariant momentum distribution in a Fourier series in azimuthal angle [158] (see also [162]):

$$E\frac{d^{3}N}{dp^{3}} = \frac{1}{2\pi} \frac{d^{2}N}{p_{T}dp_{T}dy} \left( 1 + \sum_{n=1}^{\infty} 2v_{n}\cos\left[n\left(\phi - \Psi_{r}\right)\right] \right),\tag{41}$$

![](_page_38_Figure_0.jpeg)

<span id="page-38-0"></span>Figure 23: Elliptic flow of charged hadrons from 130 GeV Au + Au collisions, from STAR [\[77\]](#page-83-18). Left: centrality dependence of p<sup>T</sup> -integrated v2. Central events correspond to nch/nmax ∼ 1. Boxes indicate range of expected values from hydrodynamic calculations [\[77\]](#page-83-18). Right: p<sup>T</sup> dependence of v<sup>2</sup> for minimum bias collisions, calculations from [\[157\]](#page-86-16).

where Ψ<sup>r</sup> represents the orientation of the reaction plane in the event. The Fourier coefficient v<sup>n</sup> measures the asymmetry of order n. By symmetry, v<sup>1</sup> = 0 at midrapidity and the leading term is elliptic flow v2. Ψ<sup>r</sup> is of course not directly measurable, but it can be estimated based on the azimuthal distribution of all measured particles in the event. However, since the multiplicity is finite, the resulting flow coefficients ˜v<sup>n</sup> must be corrected for the finite resolution of the estimated reaction plane orientation [\[158\]](#page-86-17).

Fig. [23](#page-38-0) compares v<sup>2</sup> for charged hadrons from 130 GeV Au + Au collisions [\[77\]](#page-83-18) with hydrodynamic calculations. The left panel shows the centrality dependence of v<sup>2</sup> integrated over transverse momentum. Good agreement of the expectations from hydrodynamics with the data is seen for nch/nmax>0.5, corresponding to b< ∼ 7 fm. The right panel shows the p<sup>T</sup> dependence of v<sup>2</sup> for minimum bias collisions. Since multiplicity is largest in central collisions and the anisotropy is largest in peripheral collisions, the greatest contribution to this measurement comes from intermediate impact parameters which have both large v<sup>2</sup> and significant multiplicity. The distribution is compared to hydrodynamic calculations with various equations of state [\[157\]](#page-86-16). The agreement of calculations with data is impressive, though it is notable that expectations for unidentified charged hadron flow are very similar for an EOS with a first order phase transition (EOS Q, Tf o =120 and 140 MeV) and a purely hadronic resonance gas (EOS H). The only calculation that is excluded is the low-density limit (LDL) from a non-hydrodynamic kinetic transport approach [\[157\]](#page-86-16).

Fig. [24](#page-39-1) shows v2(p<sup>T</sup> ) separately for various identified particles from STAR [\[163\]](#page-86-22). Similar to the azimuthally averaged p<sup>T</sup> distributions in Figs. [19](#page-33-1) and [20,](#page-35-0) v2(p<sup>T</sup> ) also exhibits a mass dependence. Below 2 GeV/c, proton v<sup>2</sup> is significantly smaller than pion v<sup>2</sup> for a given value of p<sup>T</sup> . In hydrodynamic terms, the origin of this effect is the same as the flattening of the inclusive p<sup>T</sup> spectrum for higher mass: the velocity boost depletes the low p<sup>T</sup> region in favor of higher p<sup>T</sup> [\[164\]](#page-86-23). This systematic trend is seen explicitly in the right panel, where v<sup>2</sup> for different identified hadrons splits according to the mass, consistent with hydrodynamic predictions [\[164\]](#page-86-23). At higher p<sup>T</sup> , the hadronic species dependence of v<sup>2</sup> changes due to breakdown of the hydrodynamic model

![](_page_39_Figure_0.jpeg)

<span id="page-39-1"></span>Figure 24:  $v_2(p_T)$  for identified hadrons from STAR [163, 146] compared to hydrodynamic calculations from [164]. Left:  $\pi^{\pm}$  and  $p+\bar{p}$  for 130 GeV minimum bias Au+Au, figure from [139]. Right:  $\pi$ , K, p and  $\Lambda$  from 200 GeV minimum bias Au+Au as compiled in [147].

at high  $p_T$ , a point to which we will return later when discussing hard probes.

PHOBOS has reported  $p_T$ -integrated elliptic flow of charged particles over very broad phase space ( $|\eta|<5$ ) [165, 166], showing a rapid decrease in integrated  $v_2$  away from mid-rapidity. A fully three-dimensional hydrodynamic calculation [167] agrees with the measurements at mid-rapidity but disagrees significantly at high  $\eta$ , predicting only weak variation of  $v_2$  out to  $\eta \sim 4$ . Hydrodynamic behaviour is thus limited to low  $p_T$  hadrons ( $< \sim 2 \text{ GeV/c}$ , depending on particle species) at mid-rapidity for more central collisions. Outside of these limits the system size and lifetime may be too small for full thermalization to develop [113]. In contrast, a microscopic calculation based on a string model incorporating string excitations and hadonic rescattering can broadly describe the full phase space distribution of  $p_T$ -integrated elliptic flow [168], though detailed comparison of such an approach to  $p_T$ -differential flow and its mass dependence has not yet been carried out.

The left panels of Fig. 24 also show hydrodynamic calculations for two EOS (H is a hadronic resonance gas, Q contains a first order phase transition) and freezeout temperatures 120 and 140 MeV. Pion  $v_2$  exhibits little sensitivity to the EOS or freezeout temperature, whereas proton  $v_2$  favors EOS Q(120), with a phase transition and the longest evolution. In [145, 113] it was concluded that a hadronic resonance gas cannot reproduce the mass dependence of elliptic flow, which therefore requires a partonic phase. While the difference between the plasma and purely hadronic scenarios in Fig. 24 is modest and clear discrimination cannot be made based on these data, it is nevertheless evident that elliptic flow does have sensitivity to the EOS in the early stage of the collision. Detailed model comparisons to the higher precision data in the right panel and future data, especially multi-strange baryon and D-meson  $v_2$ , will sharpen the arguments considerably and may provide significant constraints on the equation of state.

#### <span id="page-39-0"></span>5.4 Statistical Distribution of Hadron Yields

The previous sections discussed the effect of early equilibration on expansion dynamics and its reflection in the systematic behavior of transverse momentum spectra and their anisotropies. Equilibration of the fireball may also be evident in the  $p_T$ -integrated hadronic yields, which

![](_page_40_Figure_0.jpeg)

<span id="page-40-0"></span>Figure 25: Hadronic yield ratios at midrapidity from central Au + Au collisions at 130 and 200 GeV. Horizontal bars show the statistical distributions resulting from fits to the data [172, 173].

should be statistically distributed according to the thermodynamic conditions at chemical freezeout [169, 170, 171, 172, 173]. Measured yields at midrapidity from nuclear collisions at RHIC are available for a wide variety of hadron species. In this section we compare relative particle abundances to expectations from a statistical model.

The statistical description of a system with many degrees of freedom is formulated using the grand canonical (GC) ensemble, in which conservation laws are enforced on the average via chemical potentials  $\mu$ . The GC partition function for a hadron resonance gas at temperature T in volume V is [173]:

<span id="page-40-1"></span>
$$\log Z(T, V, \vec{\mu}) = \sum_{i} \log Z_i(T, V, \vec{\mu}), \tag{42}$$

where i sums over all hadrons with masses less than  $\sim 2 \text{ GeV/c}^2$  and  $\vec{\mu} = (\mu_B, \mu_S, \mu_Q)$  are the chemical potentials for baryon number, strangeness and charge. For the hadron species carrying baryon number  $B_i$ , strangeness  $S_i$  and charge  $Q_i$ ,

$$Z_i(T, V, \vec{\mu}) = \frac{Vg_i}{2\pi^2} \int_0^\infty \pm p^2 dp \log(1 \pm \lambda_i e^{-\beta \epsilon_i}). \tag{43}$$

Here + is for fermions and - is for bosons,  $g_i$  is the spin-isospin degeneracy,  $\beta = 1/T$ ,  $\epsilon_i = \sqrt{p^2 + m_i^2}$ , and

<span id="page-40-2"></span>
$$\lambda_i(T, \vec{\mu}) = \exp\left(\frac{B_i \mu_B + S_i \mu_S + Q_i \mu_Q}{T}\right). \tag{44}$$

Repulsive interactions between hadrons and the effects of resonance decay are taken into account [171]. The imposition of local strangeness and charge neutrality means that the resulting distributions depend only on the temperature T and baryochemical potential  $\mu_B$ .

Fig. 25 shows the ratios of a wide variety of hadronic yields measured at midrapidity for central Au + Au collisions. The ratios span three orders of magnitude (note the scaling of  $\Omega/\pi^-$ ). Also shown are expectations for a statistically distributed population emitted by an equilibrated medium with T=176 MeV,  $\mu_B=41$  MeV ( $\sqrt{s_{\rm NN}}=130$  GeV, left) or T=177 MeV,  $\mu_B=29$  MeV (200 GeV, right). Agreement between data and model is good: the hadron

population is statistically distributed, consistent with the model sketched in Eqs. (42)-(44). The fitted baryochemical potential  $\mu_B$  is small, indicating low net baryon density in the medium. The chemical freeze-out temperature T appears to be limited (i.e. varies little with  $\sqrt{s}$ ) at a value close to the QCD phase transition temperature from lattice calculations (Sec. 2.1). These phenomena can be accommodated in a picture in which chemical freeze-out occurs in central nuclear collisions at the hadronization boundary of a thermalized, deconfined plasma phase, with the subsequent evolution of the hadronic gas being moderated by (quasi-)elastic collisions [173]. Additional support for this picture is supplied by the systematics of strangeness production, which may indicate that strangeness percolates over a much larger volume in nuclear collisions, as described by a grand canonical ensemble, than in elementary nucleon-nucleon collisions, which require a canonical ensemble description with explicit local strangeness conservation [173].

Does the observation of a statistically distributed population of final state hadrons require a chemically equilibrated source? A statistically distributed population may result simply from phase space dominance [174]. Surprisingly, hadron populations are found to be statistically distributed in  $\bar{p} + p$  and even  $e^+ + e^-$  collisions [175, 176]. For a final state comprising many particles, a multiplicity measurement corresponds to integration over a large phase space volume and details of the matrix element for producing any specific state are unimportant. If the phase space-averaged matrix elements obey general scaling rules and do not exhibit strong correlations or dependence on  $\sqrt{s}$ , then the resulting hadron distributions will populate phase space statistically [174]. Discrimination between phase space dominance, in which T and  $\mu_B$  are simply Lagrange multipliers parameterizing the phase space, and emission from a thermal system, having physical parameters temperature T and chemical potential  $\mu_B$ , may be achievable via multiparticle correlation measurements [174, 177]. Such measurements are only now maturing at RHIC (see [178] for further discussions). The current experimental data are however consistent with a picture of hadronic freeze-out from a chemically equilibrated source.

## <span id="page-41-0"></span>5.5 Space-time Evolution

We have so far concentrated on momentum-space observables to infer the initial conditions, degree of thermalization, and dynamics of the expansion. Direct measurements of the space-time evolution of the fireball provide complementary probes of the system dynamics. For instance, measurement of a long system lifetime may indicate the presence of a low pressure phase which has stalled the expansion, as expected from a first order phase transition with a soft equation of state in the mixed phase [179].

It was recognized long ago that intensity interferometry of pairs of identical particles is sensitive to the geometry of the source, both in astrophysical systems and in elementary particle collisions (Hanbury Brown-Twiss or "HBT" interferometry [180, 181]). For bosons, the wavefunction symmetry results in an enhanced coincidence rate for pairs having small momentum difference, with the momentum range of the enhancement varying inversely with the space-time dimensions of the source. The application of intensity interferometry to high energy nuclear collisions provides a unique probe of the dynamic properties of the fireball [182]. The correlation function of identical pions encodes the system geometry and expansion dynamics at kinetic freezeout, late in the fireball evolution. Its projections relative to the beam direction and to the pair mean momentum reflect various aspects of the expansion dynamics and space-time extent of the source. Fortunately, the large multiplicities generated in nuclear collisions provide the large pair statistics necessary for detailed investigation of the multi-dimensional correlation function [183].

The pair correlation function  $C(\mathbf{q}, \mathbf{K})$  is a function of the pair's relative 4-momentum  $q = p_1 - p_2$  and mean momentum  $K = \frac{1}{2}(p_1 + p_2)$ , and is related to the Wigner density of the emitting source S(x, K)[183]:

$$C(\mathbf{q}, \mathbf{K}) \equiv \frac{d^6 N}{d\mathbf{p}_1^3 d\mathbf{p}_2^3} / \left(\frac{d^3 N}{d\mathbf{p}_1^3} \frac{d^3 N}{d\mathbf{p}_2^3}\right) \approx 1 + \frac{\left|\int d^4 x S(x, K) e^{iq \cdot x}\right|^2}{\left|\int d^4 x S(x, K)\right|^2}.$$
 (45)

S(x, K) can be understood as the probability that the source emits a particle with momentum K from space-time point x. Experimentally,  $C(\mathbf{q}, \mathbf{K})$  is constructed from the ratio of the measured pair distribution to a distribution of mixed pairs drawn from different events [184]. The measured correlation function  $C(\mathbf{q}, \mathbf{K})$  has structure due to Bose-Einstein statistics, resulting in enhanced probability for small  $|\mathbf{q}|$ , and to final state interactions, which mask the BE enhancement and which must be disentangled to extract geometric quantities.

Within a Gaussian approximation to the spatial distribution of S(x, K) [182], the correlation function for central collisions is characterized by its projections onto the orthogonal longitudinal, outward and sideward directions, which are parallel to the beam, parallel to  $K_T$ , and perpendicular to  $K_T$  respectively.  $K_T$  is the pair momentum vector perpendicular to the beam. The conjugate radius parameters are  $R_l$ ,  $R_o$  and  $R_s$  [185, 186, 187]:

$$C(\mathbf{q}, \mathbf{K}) \simeq 1 + \lambda \exp\left(-R_l^2 q_l^2 - R_o^2 q_o^2 - R_s^2 q_s^2\right).$$
 (46)

In high energy nuclear collisions the source expands longitudinally and transversely. In a hydrodynamic picture, a pair of identical pions with small momentum difference are unlikely to be emitted from different fluid elements with significantly differing velocity. The parameters R therefore do not reflect the dimensions of the entire source, but rather the rms widths of the effective source that emits particles with momentum  $K_T$  ("regions of homogeneity") [188]. The systematic dependence of R on pair momentum is a rich source of information about the expansion dynamics of the fireball [182]. For an infinite Bjorken (boost-invariant) source at temperature T the longitudinal radius is [189]

$$R_l^2(K_T) \simeq \tau_0^2 \frac{T}{K_T},\tag{47}$$

though corrections for realistic sources are significant [190]. An extended lifetime of the system may be observable via the combination

$$R_o^2 - R_s^2 \approx \beta_\perp^2 \langle \tilde{t}^2 \rangle,$$
 (48)

which is sensitive to the duration of particle emission. Here,  $\beta_{\perp} = K_T/K_0$  is the transverse velocity of the pair and  $\langle \tilde{t}^2 \rangle = \langle t^2 \rangle - \langle t \rangle^2$  is the variance of the particle emission time. Hydrodynamic calculations [179] indicate that a large value of  $R_o^2 - R_s^2$ , or specifically the ratio  $R_o/R_s \gg 1$ , is a rather generic indication of a very soft equation of state stalling the expansion, which can only arise from the presence of a mixed phase.

Fig. 26 shows the measured HBT parameters for central Au + Au collisions at 130 GeV. The parameters are not large (<8 fm) relative to the radius of a Au-nucleus and exhibit negligible change from measurements with heavy nuclei at much lower  $\sqrt{s}$  [191]. Most significantly, the ratio  $R_o/R_s \leq 1$  in  $0.2 < K_T < 1.2$  GeV/c [191, 192, 193], in contrast to the expectation that  $R_o/R_s \sim 1.5$  for a long-lived source.

The reduction in R with increasing pair  $K_T$  is qualitatively consistent with expectations from a longitudinally and transversely expanding source. However, quantitative comparison of

![](_page_43_Figure_0.jpeg)

<span id="page-43-0"></span>Figure 26: Charged pion HBT parameters for 130 GeV central Au + Au collisions from STAR [\[191\]](#page-87-24) and PHENIX [\[192\]](#page-88-0), compared to hydrodynamic calculations [\[113\]](#page-84-26). Curves are described in text.

the measured radius parameters to the boost-invariant hydrodynamic calculations in the figure reveals significant disagreements [\[113\]](#page-84-26): neither the magnitude nor the K<sup>T</sup> dependence are well described. Modifications to the calculation such as earlier freezeout (dotted line), faster buildup of flow at the partonic stage (short dashed line), or earlier onset of hydrodynamic behavior (long dashed line) either do not fully rectify the disagreements or worsen the agreement with inclusive spectra. Likewise, relieving the boost-invariance condition and imposing a more realistic treatment of freezeout than the instantaneous Cooper-Frye algorithm do not fully resolve the problems. Introduction of finite viscosity generates Ro/R<sup>s</sup> ∼ 1, but at the expense of significant disagreement with v<sup>2</sup> measurements [\[140\]](#page-85-26). A hybrid parton/hadron cascade calculation generates Ro/R<sup>s</sup> ∼ 1 [\[194\]](#page-88-2). However, the freezeout in this calculation occurs earliest at small radii, in contrast to hydrodynamic calculations where the freezeout surface generically propagates inward [\[113\]](#page-84-26).

For non-central collisions, the azimuthal modulation of HBT parameters relative to the reaction plane orientation provides a more detailed view of the geometry and dynamics of the source at freezeout [\[195,](#page-88-3) [196\]](#page-88-4). Recent measurements of the azimuthal dependence of HBT radii [\[197\]](#page-88-5) indicate that the source at freezeout is asymmetric and extends out of the reaction plane (ǫx>0), consistent with a rapid pressure buildup and early freezeout. This picture should be contrasted with the calculations shown in Fig. [22,](#page-37-0) right panel, in which hydrodynamic expansion prior to freezeout lasts long enough to turn the spatial anisotropy slightly negative (ǫx<0, source extended in the reaction plane).

Reconcilation of HBT radius measurements and hydrodynamic calculations has not yet been achieved within the currently available theoretical framework (the "HBT puzzle") [\[113\]](#page-84-26). However, insofar as the HBT correlations are most sensitive to the system properties at kinetic freezeout, this may indicate a lack of understanding of the late expansion stage and ultimate breakup of the system rather than the dynamics at the earliest, hot and dense phase. The effect of the source opacity on the correlation function also remains an open question.

## <span id="page-44-0"></span>6 Hard Probes

The lifetime of the hot and dense matter produced in heavy ion collisions at RHIC is estimated to be on the order of a few fm/c. Its initial transverse radius is about 6 fm and it undergoes rapid longitudinal and transverse expansion. Due to the transient nature of the matter, external probes cannot be used to study its properties. Fortunately, the dynamical processes that produce the bulk medium also produce energetic particles through hard processes. These energetic particles penetrate the bulk matter and reach the detectors as distinct signals. Study of these energetic particles and their interaction with the medium, analogous to the method of computed tomography (CT) in medical science, will yield critical information about the properties of the matter that is impossible to obtain from the soft hadrons produced by hadronization of the bulk medium.

Properties of a medium are conventionally studied using the scattering of particle beams. In deeply inelastic scattering (DIS) experiments, for example, leptons scatter off a nucleon via photon exchange with quarks. The response or correlation function of the electromagnetic currents,

$$W_{\mu\nu}(q) = \frac{1}{4\pi} \int d^4x e^{iq \cdot x} \langle A \mid j_{\mu}^{em}(0) j_{\nu}^{em}(x) \mid A \rangle , \qquad (49)$$

is a direct measurement of the quark distributions in a nucleon or nucleus, where  $j_{\mu}^{em}(x) = \sum_{q} e_q \bar{\psi}_q(x) \gamma_{\mu} \psi_q(x)$  is the hadronic electromagnetic current. Such experiments have provided unique information about the partonic structure of nucleons and nuclei and their QCD evolution[198, 199].

The scattering technique is not applicable to the dynamic systems produced in heavy-ion collisions. However, it has been shown that the thermal average of the above correlation function gives the photon emission rate from the evolving system [200]. The emission rate depends mainly on local temperature or parton density, while the total yield depends on the entire history of the system evolution. The properties and dynamics of a strongly interacting system may therefore be probed via the measurements of photon and dilepton emission. Additional information is encoded in the resonance properties and medium modification of the emitted virtual photons. Screening in a color-deconfined medium leads to dissociation of bound states, resulting in quarkonium suppression [32]. The color screening arises from the strong interaction between quarks and gluons at high density and temperature, which also causes the attenuation of energetic partons propagating through the medium. Such an effect underlies the phenomenon of jet quenching and the application of jet tomography to probe the dense matter generated in high-energy heavy-ion collisions [201, 202].

Charmonium suppression significantly in excess of normal nuclear absorption has indeed been observed in fixed-target heavy-ion collisions at the CERN SPS by NA50 [15], leading to speculation that dense, color deconfined matter has been created in central Pb + Pb collisions at SPS energy. A direct photon excess over hadronic sources has been observed at the SPS [203], and low mass dilepton spectra show signs of medium modifications of hadron properties [16]. Reviews of these results can be found in [47, 204, 205]. At present, however, the experimental investigation of real and virtual photon production at RHIC is just beginning. In this section we concentrate rather on the theory and phenomenology of jet quenching at RHIC, for which a large body of mature data is available.

Theoretical studies of medium-induced partonic energy loss date back to an unpublished paper by Bjorken, who calculated the energy loss due to elastic scattering in a hot medium. A simple estimate is given by the thermally averaged energy transfer  $\nu_{\rm el} \approx q_{\perp}^2/2\omega$  of the jet parton

![](_page_45_Figure_0.jpeg)

<span id="page-45-0"></span>Figure 27: Binary collision-scaled ratio of charged hadron and  $\pi^0$  inclusive spectra from 200 GeV Au + Au and d + Au relative to that from p + p collisions, from BRAHMS[208](upper left), PHENIX[209] (upper right), PHOBOS[210] (lower left) and STAR[74] (lower right). See Sect. 6.4 for details.

to a thermal parton with energy  $\omega$ , where  $q_{\perp}$  is the transverse momentum transfer of the elastic scattering. The resulting elastic energy loss [206],

$$\frac{dE_{\rm el}}{dx} = C_2 \frac{3\pi\alpha_{\rm s}^2}{2} T^2 \log\left(\frac{3ET}{2\mu^2}\right) , \qquad (50)$$

is sensitive to the temperature of the medium but is in general small relative to the radiative energy loss discussed below. Here,  $\mu$  is the Debye screening mass and  $C_2$  is the Casimir factor of the propagating parton in its fundamental representation. Elastic energy loss can also be calculated within finite temperature QCD field theory [207], with similar results.

Radiative partonic energy loss was first estimated using the uncertainty principle [211]. The first theoretical study of QCD radiative partonic energy loss, by Gyulassy and Wang [212, 213], modeled multiple parton scattering using a screened Coulomb potential and found that Landau-Pomeranchuk-Migdal (LPM) interference effects [214, 215] play a crucial role. Baier et al. (BDMPS) [216] later considered gluon rescattering, which was found to dominate the gluon radiation induced by multiple scattering in a dense medium. These initial studies have been followed by many more recent works on the subject, including a path integral formulation

![](_page_46_Figure_0.jpeg)

![](_page_46_Figure_1.jpeg)

<span id="page-46-0"></span>Figure 28: Left: Dihadron azimuthal correlations at high  $p_T$  for p+p, central d+Au and central Au+Au collisions (background subtracted ) from STAR [223, 74]. Right: azimuthal correlation strength with the reaction plane  $(v_2, \text{ Eq. } (41))$  of high  $p_T$  hadrons in non-central Au+Au collisions from STAR [224]. Different symbols correspond to different methods for calculating  $v_2$  (reaction-plane, 2- and 4-particle cumulant; see Sect. 6.7).

[217] and an opacity expansion framework [218, 219, 220] which is suitable for studying multiple parton scattering in a thin plasma. The unique feature of radiative energy loss in QCD is its non-linear dependence on distance, arising from the non-Abelian LPM interference effect in a QCD medium. In this review, we will take the approach of twist-expansion [221, 222], since it connects naturally the discussions of partonic energy loss in a cold nuclear medium and hot quark gluon plasma.

Before continuing with the theoretical discussion of partonic energy loss and its effects in heavy ion collisions at RHIC, it is worthwhile first to gain an impression of the reach of the available data addressing this physics and the magnitude of the effects under discussion. Figures 27 and 28 show the most significant high  $p_T$  measurements made at RHIC thus far. Both figures incorporate measurements of  $\sqrt{s}$ =200 GeV p+p, d+Au and centrality-selected Au+Au collisions at RHIC, with the simpler p+p and d+Au systems providing benchmarks for phenomena seen in the more complex Au+Au collisions.

Figure 27 shows the ratio of inclusive hadron yields in Au + Au and d + Au to p + p, scaled by  $\langle N_{bin} \rangle$  to account for trivial geometric effects. A striking phenomenon is seen: large  $p_T$  hadrons in central Au+Au collisions are suppressed by a factor 5 relative to naive expectations. Conventional nuclear effects, such as nuclear shadowing of the parton distribution functions and initial state multiple scattering, cannot account qualitatively for the suppression. Furthermore, the suppression is not seen in d + Au but is unique to Au + Au collisions, proving experimentally that it results not from nuclear effects in the initial state (in particular, gluon saturation) but from the final state interaction of hard scattered partons or their fragmentation products in the dense medium generated in Au + Au collisions [208, 209, 210, 74].

Figure 28 shows correlations of high  $p_T$  hadrons. The left panel shows the azimuthal distribution of hadrons with  $p_T>2$  GeV/c relative to a trigger hadron with  $p_T^{\rm trig}>4$  GeV/c. A hadron pair drawn from a single jet will generate an enhanced correlation at  $\Delta\phi\sim0$ , as observed for  $p+p,\ d+Au$  and Au+Au, with similar correlation strengths and widths. A hadron pair drawn from back-to-back dijets will generate an enhanced correlation at  $\Delta\phi\sim\pi$ , as observed with somewhat broader width than the near-side correlation peak for p+p and d+Au colli-

sions. However, the back-to-back dihadron correlation is strikingly absent in central Au + Au collisions, and uniquely in central Au + Au collisions. If the correlation is indeed the result of jet fragmentation, this suppression is also due to the final state interaction of hard scattered partons or their fragmentation products in the dense medium generated in Au+Au collisions [74]. Finally, the right panel shows the finite azimuthal correlation strength of high  $p_T$  hadrons with the orientation of the reaction plane in non-central Au+Au collisions, in analogy to the elliptic flow seen at low  $p_T$  (Sect. 5.3) [224]. Since the azimuthal orientation of the initially scattered hard parton is uncorrelated with that of the reaction plane and the bulk deformation of the fireball, this correlation can only arise from final state interactions.

Figures 27 and 28 present compelling evidence that high  $p_T$  hadron production in nuclear collisions at RHIC is profoundly altered by interactions with the medium created in the collision. We will now discuss in some detail the theory of partonic energy loss, which provides a unified description of these phenomena and enables them to be applied as unique, penetrating probes of the medium.

### <span id="page-47-0"></span>6.1 Partonic energy loss and modified fragmentation functions

In contrast to the QED energy loss of electrons in matter, the QCD energy loss of partons cannot be measured directly because partons are not the final, experimentally observed particles. Instead, studies of partonic energy loss must exploit the particle distributions within a jet, in particular the modification of the fragmentation functions  $D_{a\to h}(z,\mu^2)$  which can be directly related to the energy loss of the leading parton.

The first example we will consider is electron-nucleus deep inelastic scattering (DIS) [222, 221, 225]. We study the semi-inclusive process,  $e(L_1)+A(p) \longrightarrow e(L_2)+h(\ell_h)+X$ , where  $L_1$  and  $L_2$  are the four-momenta of the incoming and outgoing leptons, and  $\ell_h$  is the observed hadron momentum. The differential cross section for the semi-inclusive process can be expressed as

$$E_{L_2} E_{\ell_h} \frac{d\sigma_{\text{DIS}}^h}{d^3 L_2 d^3 \ell_h} = \frac{\alpha_{\text{EM}}^2}{2\pi s} \frac{1}{Q^4} L_{\mu\nu} E_{\ell_h} \frac{dW^{\mu\nu}}{d^3 \ell_h} , \qquad (51)$$

where  $p = [p^+, 0, \mathbf{0}_{\perp}]$  is the momentum per nucleon in the nucleus,  $q = L_2 - L_1 = [-Q^2/2q^-, q^-, \mathbf{0}_{\perp}]$  is the momentum transfer,  $s = (p + L_1)^2$  and  $\alpha_{\text{EM}}$  is the electromagnetic (EM) coupling constant.  $L_{\mu\nu}$  is the leptonic tensor, while  $W_{\mu\nu}$  is the semi-inclusive hadronic tensor.

In the collinear factorization approximation to the parton model, the leading-twist contribution to the semi-inclusive cross section can be factorized into a product of parton distributions, parton fragmentation functions and the partonic cross section. Including all leading log radiative corrections, the lowest order contribution  $(\mathcal{O}(\alpha_s^0))$  from a single hard  $\gamma^* + q$  scattering can be written as

$$\frac{dW_{\mu\nu}^S}{dz_h} = \sum_q e_q^2 \int dx f_q^A(x, \mu_I^2) H_{\mu\nu}^{(0)}(x, p, q) D_{q \to h}(z_h, \mu^2); \qquad (52)$$

$$H_{\mu\nu}^{(0)}(x,p,q) = \frac{1}{2} \operatorname{Tr}(\gamma \cdot p \gamma_{\mu} \gamma \cdot (q+xp) \gamma_{\nu}) \frac{2\pi}{2p \cdot q} \delta(x-x_B), \qquad (53)$$

where the momentum fraction carried by the hadron is defined as  $z_h = \ell_h^-/q^-$  and  $x_B = Q^2/2p^+q^-$  is the Bjorken variable.  $\mu_I^2$  and  $\mu^2$  are the factorization scales for the initial quark distributions  $f_q^A(x,\mu_I^2)$  in a nucleus and the fragmentation functions  $D_{q\to h}(z_h,\mu^2)$ , respectively.

The propagating quark in DIS off a nucleus will experience additional scatterings with other partons from the nucleus. The rescatterings induce additional gluon radiation and cause the

leading quark to lose energy. This effectively gives rise to additional terms in the evolution equation, leading to the modification of the fragmentation functions in a medium. These are called higher-twist corrections since they involve higher-twist parton matrix elements and are power-suppressed. We will consider those contributions that involve two-parton correlations from two different nucleons inside the nucleus. Generalized factorization is usually applied to these multiple scattering processes[226, 227, 228]. In this approximation, the radiative correction to the semi-inclusive tensor from double quark-gluon scattering is

$$\frac{W_{\mu\nu}^{D,q}}{dz_h} = \sum_{q} \int dx H_{\mu\nu}^{(0)}(xp,q) \int_{z_h}^{1} \frac{dz}{z} D_{q\to h}(z_h/z) \frac{\alpha_s}{2\pi} C_A \frac{1+z^2}{1-z} \int \frac{d\ell_T^2}{\ell_T^4} \frac{2\pi\alpha_s}{N_c} T_{qg}^A(x,x_L) , \quad (54)$$

where

$$T_{qg}^{A}(x,x_{L}) = \int \frac{dy^{-}}{2\pi} dy_{1}^{-} dy_{2}^{-} (1 - e^{-ix_{L}p^{+}y_{2}^{-}}) (1 - e^{-ix_{L}p^{+}(y^{-} - y_{1}^{-})}) e^{i(x+x_{L})p^{+}y^{-}}$$

$$\times \theta(-y_{2}^{-}) \theta(y^{-} - y_{1}^{-}) \frac{1}{2} \langle A | \bar{\psi}_{q}(0) \gamma^{+} F_{\sigma}^{+}(y_{2}^{-}) F^{+\sigma}(y_{1}^{-}) \psi_{q}(y^{-}) | A \rangle$$
(55)

are twist-four parton matrix elements of the nucleus. The fractional momentum  $x_L = \ell_T^2/2p^+q^-z(1-z)$  and  $x = x_B = Q^2/2p^+q^-$  is the Bjorken scaling variable. The dipole-like structure in the effective twist-four parton matrix results from Landau-Pomeranchuk-Migdal (LPM) interference in gluon bremsstrahlung [214, 215]. After expansion, the first diagonal term corresponds to the so-called hard-soft process where gluon radiation is induced by the hard scattering between the virtual photon and a quark at momentum fraction x. The quark is knocked off-shell by the virtual photon, returning on-shell by radiating a gluon. The on-shell quark or radiated gluon will then have a secondary scattering with another soft gluon from the nucleus. The second diagonal term is due to the double hard process where the quark is on-shell after the first hard scattering with the virtual photon. The gluon radiation is then induced by the scattering of the quark with another gluon that carries finite momentum fraction  $x_L$ . The two off-diagonal terms represent interference between the hard-soft and double hard processes. In the limit of collinear radiation  $(x_L \to 0)$  or when the formation time of the gluon radiation,  $\tau_f \equiv 1/x_L p^+$ , is much larger than the nuclear size, the two processes interfere destructively, leading to the LPM interference effect.

<span id="page-48-0"></span>Including the virtual corrections and the single scattering contribution, we rewrite the semiinclusive tensor in a factorized form with a nuclear modified fragmentation function,

$$\widetilde{D}_{q \to h}(z_h, \mu^2) \equiv D_{q \to h}(z_h, \mu^2) + \int_0^{\mu^2} \frac{d\ell_T^2}{\ell_T^2} \frac{\alpha_s}{2\pi} \int_{z_h}^1 \frac{dz}{z} \\
\times \left[ \Delta \gamma_{q \to qg}(z, x, x_L, \ell_T^2) D_{q \to h}(z_h/z) + \Delta \gamma_{q \to gq}(z, x, x_L, \ell_T^2) D_{g \to h}(z_h/z) \right], (56)$$

where  $D_{q\to h}(z_h, \mu^2)$  and  $D_{g\to h}(z_h, \mu^2)$  are the leading-twist fragmentation functions. The modified splitting functions are

$$\Delta \gamma_{q \to qg}(z, x, x_L, \ell_T^2) = \left[ \frac{1 + z^2}{(1 - z)_+} T_{qg}^A(x, x_L) + \delta(1 - z) \Delta T_{qg}^A(x, \ell_T^2) \right] \frac{2\pi \alpha_s C_A}{\ell_T^2 N_c \tilde{f}_q^A(x, \mu_I^2)}, \quad (57)$$

$$\Delta \gamma_{q \to gq}(z, x, x_L, \ell_T^2) = \Delta \gamma_{q \to qg}(1 - z, x, x_L, \ell_T^2). \tag{58}$$

This medium correction is very similar in form to that caused by gluon bremsstrahlung in vacuum that leads to the DGLAP evolution in Eq. (9).

Using the factorization approximation [227, 229], we can relate the twist-four parton matrix elements of the nucleus to the twist-two parton distributions of nucleons and the nucleus,

$$T_{qg}^{A}(x,x_{L}) = \frac{C}{x_{A}} (1 - e^{-x_{L}^{2}/x_{A}^{2}}) \left[ f_{q}^{A}(x + x_{L}) x_{T} f_{g}^{N}(x_{T}) + f_{q}^{A}(x)(x_{L} + x_{T}) f_{g}^{N}(x_{L} + x_{T}) \right]$$

$$\approx \frac{\tilde{C}}{x_{A}} (1 - e^{-x_{L}^{2}/x_{A}^{2}}) f_{q}^{A}(x), \tag{59}$$

where C is a constant,  $x_T = \langle k_T^2 \rangle / 2p^+q^-z$  is related to the intrinsic transverse momentum of gluons inside the nucleus,  $x_A = 1/m_N R_A$ ,  $f_q^A(x)$  is the quark distribution inside a nucleus, and  $f_g^N(x)$  is the gluon distribution inside a nucleon. The coefficient  $\tilde{C} \equiv 2Cx_T f_g^N(x_T)$  should in principle depend on  $Q^2$  and  $x_T$  but can be approximated as a constant. A Gaussian distribution in light-cone coordinates is assumed for the nuclear distribution,  $\rho(y^-) = n_0 \exp(y^{-2}/2R_A^{-2})$ , where  $R_A^- = \sqrt{2}R_A m_N/p^+$  and  $m_N$  is the nucleon mass. We should emphasize that the twist-four matrix element is proportional to  $1/x_A = R_A m_N$ , i.e. the nuclear size[229].

In the above matrix element,  $1/x_Lp^+ = 2q^-z(1-z)/\mu^2$  is identified as the formation time of the emitted gluons. For formation time that is large relative to the nuclear size the above matrix element vanishes, exhibiting the typical LPM interference effect. This results because the emitted gluon (with long formation time) and the leading quark remain a coherent system while propagating through the nucleus. Additional scattering will not induce more gluon radiation.

The reduction due to LPM interference of the phase space available for gluon radiation is critical for applying the LQS formalism (Luo, Qiu and Sterman [226, 227, 228]) to the problem under consideration. In the original LQS approach, the generalized factorization for processes with large final transverse momentum  $\ell_T^2 \sim Q^2$  leads to consideration of the leading contribution in  $1/Q^2$ , which is enhanced by the nuclear size  $R_A \sim A^{1/3}$ . For large  $Q^2$  and A, the higher-twist contribution from double parton rescattering that is proportional to  $\alpha_s R_A/Q^2$  will then be the leading nuclear correction. Contributions from more than two parton rescattering can be neglected. In deriving the modified fragmentation functions, we however have to take the leading logarithmic approximation in the limit  $\ell_T^2 \ll Q^2$ , where  $\ell_T$  is the transverse momentum of the radiated gluon. Since the LPM interference suppresses gluon radiation whose formation time  $(\tau_f \sim Q^2/\ell_T^2 p^+)$  is larger than the nuclear size  $m_N R_A/p^+$  in our chosen frame,  $\ell_T^2$  should then have a minimum value of  $\ell_T^2 \sim Q^2/m_N R_A \sim Q^2/A^{1/3}$ , where  $m_N$  is the nucleon mass. Therefore, the leading higher-twist contribution proportional to  $\alpha_s R_A/\ell_T^2 \sim \alpha_s R_A^2/Q^2$  from double scattering depends quadratically on the nuclear size  $R_A$ .

With the assumption of the factorized form of the twist-4 nuclear parton matrices, there is only one free parameter  $\tilde{C}(Q^2)$  which represents the quark-gluon correlation strength inside nuclei. Once it is fixed, the z, energy and nuclear dependence of the medium modification of the fragmentation function can be predicted. Shown in Fig. 29 are the calculated nuclear modification factors of the fragmentation functions for  $^{14}N$  and  $^{84}Kr$  targets, compared to recent HERMES data[16, 230]. The predicted shapes of the z- and  $\nu$ -dependence agree well with the data. A remarkable feature of the prediction is the quadratic  $A^{2/3}$  nuclear size dependence, which is verified for the first time by an experiment. By fitting the overall suppression for one nuclear target, one fixes the only free parameter in the calculation,  $\tilde{C}(Q^2) = 0.0060 \; {\rm GeV}^2$  with  $\alpha_{\rm s}(Q^2) = 0.33$  at  $Q^2 \approx 3 \; {\rm GeV}^2$ .

<span id="page-49-0"></span>Modification of the fragmentation can be quantified by the quark energy loss, defined as the momentum fraction carried by the radiated gluon:

$$\langle \Delta z_g \rangle(x_B, \mu^2) = \int_0^{\mu^2} \frac{d\ell_T^2}{\ell_T^2} \int_0^1 dz \frac{\alpha_s}{2\pi} z \, \Delta \gamma_{q \to gq}(z, x_B, x_L, \ell_T^2)$$

![](_page_50_Figure_0.jpeg)

<span id="page-50-1"></span>Figure 29: Measured ratios of hadron distributions from DIS off A and d targets, from HERMES [230, 231]. The curves show the predicted nuclear modification of the jet fragmentation function, described in text. Left: vs. fragmentation fraction z. Right: vs. energy transfer  $\nu$ .

$$= \frac{C_A \alpha_s^2}{N_c} \int_0^{\mu^2} \frac{d\ell_T^2}{\ell_T^4} \int_0^1 dz [1 + (1 - z)^2] \frac{T_{qg}^A(x_B, x_L)}{\tilde{f}_g^A(x_B, \mu_L^2)}$$
(60)

$$= \tilde{C} \frac{C_A \alpha_s^2}{N_c} \frac{x_B}{x_A Q^2} \int_0^1 dz \frac{1 + (1 - z)^2}{z(1 - z)} \int_0^{x_\mu} \frac{dx_L}{x_L^2} (1 - e^{-x_L^2/x_A^2}), \tag{61}$$

where  $x_{\mu} = \mu^2/2p^+q^-z(1-z) = x_B/z(1-z)$  for factorization scale  $\mu^2 = Q^2$ . For  $x_A \ll x_B \ll 1$ , the leading quark energy loss is roughly

$$\langle \Delta z_g \rangle (x_B, \mu^2) \approx \tilde{C} \frac{C_A \alpha_s^2}{N_c} \frac{x_B}{Q^2 x_A^2} 6\sqrt{\pi} \ln \frac{1}{2x_B}.$$
 (62)

Since  $x_A = 1/m_N R_A$ , the energy loss  $\langle \Delta z_g \rangle$  thus depends quadratically on the nuclear size.

In the rest frame of the nucleus,  $p^+ = m_N$ ,  $q^- = \nu$ , and  $x_B \equiv Q^2/2p^+q^- = Q^2/2m_N\nu$ . The average total energy loss is  $\Delta E = \nu \langle \Delta z_g \rangle \approx \tilde{C}(Q^2)\alpha_{\rm s}^2(Q^2)m_NR_A^2(C_A/N_c)3\sqrt{\pi}\ln(1/2x_B)$ . With the value of  $\tilde{C}$  from the fit,  $\langle x_B \rangle \approx 0.124$  in the HERMES kinematics [230, 231] and the average distance  $\langle L_A \rangle = R_A \sqrt{2/\pi}$  for the assumed Gaussian nuclear distribution, the average quark energy loss  $dE/dL \approx 0.5$  GeV/fm in a Au nucleus.

Attenuation of leading hadrons in DIS off nuclear targets has also been studied in hadronic transport and absorption models [232, 233]. In these models, two distinct types of hadronic absorption are assumed: absorption of fully formed physical hadrons, and of "pre-hadrons". Since the hadronic formation time is long, attenuation effects on fully formed hadrons are small and the observed attenuation is attributed to the absorption of pre-hadrons in the nuclear medium. The pre-hadron can be modeled as a quark-antiquark dipole, and the interaction of  $q\bar{q}$  dipoles with the nuclear medium should be equivalent to the picture of multiple parton scattering and induced bremsstrahlung [220].

## <span id="page-50-0"></span>6.2 Energy loss and jet quenching in a hot medium

To extend the study of modified fragmentation functions to jets in heavy-ion collisions, we assume a one-dimensional boost invariant (Bjorken) expansion with transverse gluon density

profile  $\rho(r,\tau) = (\tau_0/\tau)\theta(R_A - r)\rho_0$ , and  $\langle k_T^2 \rangle \approx \mu^2$  (the Debye screening mass). The initial jet production rate is independent of the final gluon density, which is related to the parton-gluon scattering cross section  $\alpha_s x_T G(x_T) \sim \mu^2 \sigma_g$  [234] so that

$$\frac{\alpha_s T_{qg}^A(x_B, x_L)}{f_g^A(x_B)} \sim \mu^2 \int dr \sigma_g \rho(r, \tau) [1 - \cos(r/\tau_f)], \tag{63}$$

where  $\tau_f = 2Ez(1-z)/\ell_T^2$  is the gluon formation time. Assuming partons traveling in the transverse direction at the velocity of light  $(r = \tau - \tau_0)$ , the fractional energy loss from Eq. (61) is [235]

$$\langle \Delta z_g \rangle = \frac{C_A \alpha_s}{\pi} \int_0^1 dz \int_0^{\frac{Q^2}{\mu^2}} du \frac{1 + (1 - z)^2}{u(1 + u)} \int_{\tau_0}^{R_A} d\tau \sigma_g \rho(\tau) \left[ 1 - \cos \left( \frac{(\tau - \tau_0) u \mu^2}{2Ez(1 - z)} \right) \right]. \quad (64)$$

<span id="page-51-0"></span>Keeping only the dominant contribution and assuming  $\sigma_g \approx C_a 2\pi \alpha_s^2/\mu^2$  ( $C_a=1$  for qg, 9/4 for gg), the average energy loss is

$$\langle \frac{dE}{dL} \rangle \approx \frac{\pi C_a C_A \alpha_s^3}{R_A} \int_{\tau_0}^{R_A} d\tau \rho(\tau) (\tau - \tau_0) \ln \frac{2E}{\tau \mu^2}.$$
 (65)

Neglecting the logarithmic dependence on  $\tau$ , the averaged energy loss in a one-dimensional expanding system is  $\langle dE/dL \rangle_{1d} \approx (dE_0/dL)(2\tau_0/R_A)$ , where  $dE_0/dL \propto \rho_0 R_A$  is the energy loss in a static medium with the initial gluon density  $\rho_0$  of the expanding system at time  $\tau_0$ . Because of the expansion, the averaged energy loss  $\langle dE/dL \rangle_{1d}$  is suppressed relative to the static case and does not depend linearly on system size for a fixed value of  $\rho_0$ .

This form of the energy loss has also been derived in the opacity expansion framework [236, 237], based on a model of multiple scattering in a quark-gluon plasma consisting of randomly distributed scattering centers with screened static potential [212]. The magnitude of the momentum transfer is small, limited by the Debye screening mass  $\mu \sim gT$ , and amplitudes for multiple scattering and gluon bremsstrahlung factorize in momentum space. This leads to an algebraic reaction operator formulation of the radiation amplitude induced by multiple scattering, which keeps track of the phase accumulation due to multiple scattering. This approach enables the iterative evaluation of the radiation spectrum induced by a given number of scatterings, corresponding to an expansion in opacity parameter  $\xi = \sigma \rho L$ . However, this approach cannot be applied directly to multiple parton scattering in a cold nuclear medium since the concept of random screened potential is difficult to justify in that case, and multi-parton correlations are also important. The extension of the twist expansion to higher twist to account for multiple parton scattering is also difficult and has yet to be done. To first order in opacity or leading twist, the two approaches give the same result for radiative energy loss in a hot gluon plasma.

<span id="page-51-1"></span>In order to calculate the effects of partonic energy loss on the production of high  $p_T$  hadrons in nuclear collisions, one can apply a simpler effective modified fragmentation function [238, 239],

$$D'_{h/c}(z_c, Q^2, \Delta E_c) = (1 - e^{-\langle \frac{\Delta L}{\lambda} \rangle}) \left[ \frac{z'_c}{z_c} D^0_{h/c}(z'_c, Q^2) + \langle \frac{\Delta L}{\lambda} \rangle \frac{z'_g}{z_c} D^0_{h/g}(z'_g, Q^2) \right] + e^{-\langle \frac{\Delta L}{\lambda} \rangle} D^0_{h/c}(z_c, Q^2),$$
(66)

where  $z'_c, z_g$  are the rescaled momentum fractions. The fragmentation functions in free space  $D_{h/c}^0(z_c, Q^2)$  are given by the BBK parameterization [240]. The first term is the fragmentation

function of the jet c after losing energy ∆Ec(pc, φ) due to medium induced gluon radiation. The second term is the feedback due to the fragmentation of the Ng(pc, φ) = h∆L/λi radiated gluons. This effective model is found to reproduce the pQCD result from Eq.[\(56\)](#page-48-0) very well, but only when ∆z = ∆Ec/E is set to be ∆z ≈ 0.6hzgi. Therefore the actual averaged parton energy loss should be ∆E/E = 1.6∆z with ∆z extracted from the effective model. The factor 1.6 is mainly due to the effect of unitarity correction in the pQCD calculation.

Since gluons are bosons, there should also be stimulated gluon emission and absorption by the propagating parton because of the presence of thermal gluons in the hot medium. The detailed balance is crucial for parton thermalization and should also be important for calculating the energy loss of an energetic parton in a hot medium. Taking into account such detailed balance in gluon emission, the asymptotic behavior of the effective energy loss in the opacity expansion framework is [\[241\]](#page-89-23),

$$\frac{\Delta E}{E} \approx \frac{\alpha_s C_F \mu^2 L^2}{4\lambda_g E} \left[ \ln \frac{2E}{\mu^2 L} - 0.048 \right] - \frac{\pi \alpha_s C_F}{3} \frac{LT^2}{\lambda_g E^2} \left[ \ln \frac{\mu^2 L}{T} - 1 + \gamma_E - \frac{6\zeta'(2)}{\pi^2} \right], \quad (67)$$

where the first term is from the induced bremsstrahlung and the second term is due to gluon absorption in detailed balance, which effectively reduces the total partonic energy loss in the medium.

Fig. [30](#page-53-0) shows numerical calculations of the ratio of radiative energy loss with and without stimulated emission and thermal absorption, as a function of E/µ for L/λ<sup>g</sup> = 3,5 and α<sup>s</sup> = 0.3. The insert shows the energy gain via gluon absorption with and without rescattering. For very high energy partons the effect of the gluon absorption is negligible. However, for intermediate parton energy the thermal absorption reduces the effective parton energy loss by about 30-10%, generating an energy dependence of the effective parton energy loss in the intermediate energy region. This energy dependence is parameterized as

<span id="page-52-1"></span>
$$\langle \frac{dE}{dL} \rangle_{1d} = \epsilon_0 (E/\mu - 1.6)^{1.2} / (7.5 + E/\mu),$$
 (68)

The threshold is the consequence of gluon absorption, which competes with radiation to effectively shut off the energy loss. According to Eq. [\(65\)](#page-51-0), the parton energy loss and therefore the parameter ǫ<sup>0</sup> in the above equation depends linearly on the gluon density of the medium. This is the only property of the medium one can extract from the experimental measurement of parton energy loss.

# <span id="page-52-0"></span>6.3 Cronin Enhancement in p + A Collisions

Tomography relies upon accurate knowledge of the initial flux of radiation in order to measure the density of the intervening matter between the source and the detector. Jet quenching is suitable for tomography since jet production can be calculated reliably in pQCD, in good agreement with experimental measurements in high-energy p + p(¯p) collisions. Perturbative calculations and experimental measurements of jet production cross sections in p + p and p + A collisions effectively calibrate the initial source of the beam of jets.

The simplest observable of jet production in p + p collisions is the high p<sup>T</sup> hadron spectrum resulting from jet fragmentation. In the collinear factorized parton model, the single inclusive hadron spectrum is [\[242\]](#page-89-24)

$$\frac{d\sigma_{pp}^{h}}{dyd^{2}p_{T}} = K \sum_{abcd} \int dx_{a} dx_{b} d^{2}k_{aT} d^{2}k_{bT} g_{p}(k_{aT}, Q^{2}) g_{p}(k_{bT}, Q^{2})$$

![](_page_53_Figure_0.jpeg)

<span id="page-53-0"></span>Figure 30: The ratio of effective parton energy loss with absorption ( $\Delta E = \Delta E_{abs}^{(0)} + \Delta E_{abs}^{(1)} + \Delta E_{abs}^{(1)}$ ) to that without ( $\Delta E_{rad}^{(1)}$ ), as a function of  $E/\mu$ . Insert: energy gain via absorption with rescattering ( $\Delta E_{abs}^{(1)}$ ) and without ( $\Delta E_{abs}^{(0)}$ ).

$$\times f_{a/p}(x_a, Q^2) f_{b/p}(x_b, Q^2) \frac{D_{h/c}^0(z_c, Q^2)}{\pi z_c} \frac{d\sigma}{d\hat{t}} (ab \to cd), \tag{69}$$

where  $f_{a/p}(x)$  is the parton distribution in the proton (we will use MRSD-t) parameterization [243]),  $D_{h/c}^0(z_c, Q^2)$  is the fragmentation function of parton c into hadron t derived from t data [240], and t produced hadron. The t hadron accounts for higher order QCD corrections. At fixed-target energies, NLO calculations with resummation underestimate the measured hadron spectra [244], indicating the importance of higher power corrections. This can be remedied phenomenologically by introducing an intrinsic transverse momentum smearing t has a Gaussian form t t t t t t t t t t

Two nuclear effects must be incorporated into the parton model for an accurate description of hadron production in p + A collisions, both arising as a consequence of multiple scattering: the nuclear modification of the parton distribution functions and nuclear  $k_T$  broadening. These effects must also be taken into account for quantitative study of the change in hadron production due to jet quenching in A + A collisions.

A practical approach to multiple scattering effects calculates the differential cross section for inclusive hadron production as that for a single hard parton-parton scattering, but with larger beam parton  $k_T$  due to multiple soft partonic scattering prior to the hard interaction and parton distributions modified according to DIS measurements off nuclear targets. The single inclusive hadron production cross section in minimum-bias p + A collisions is then

$$\frac{d\sigma_{pA}^{h}}{dyd^{2}p_{T}} = K \sum_{abcd} \int d^{2}bT_{A}(b) \int dx_{a}dx_{b}d^{2}k_{aT}d^{2}k_{bT}g_{A}(k_{aT}, Q^{2}, b)g_{p}(k_{bT}, Q^{2})$$

![](_page_54_Figure_0.jpeg)

<span id="page-54-0"></span>Figure 31: Single particle inclusive spectra at collider energies compared to parton model and NLO calculations. Left: charged hadrons from p + ¯p collisions at √ s = 200, 900, 1800 GeV from UA1 [\[247\]](#page-90-2) and CDF [\[248\]](#page-90-3). Lines indicate parton model calculations with (solid) and without (dot-dashed) intrinsic k<sup>T</sup> . Right: π 0 from p + p collisions at √ s=200 GeV compared to NLO calculations, from PHENIX [\[249\]](#page-90-4).

$$\times f_{a/p}(x_a, Q^2) f_{b/A}(x_b, Q^2, b) \frac{D_{h/c}^0(z_c, Q^2)}{\pi z_c} \frac{d\sigma}{d\hat{t}} (ab \to cd), \tag{70}$$

where TA(b) is the nuclear thickness function normalized to <sup>R</sup> d 2 bTA(b) = A. The parton distribution per nucleon inside the nucleus of mass A and charge Z at impact parameter b,

$$f_{a/A}(x, Q^2, b) = S_{a/A}(x, b) \left[ \frac{Z}{A} f_{a/p}(x, Q^2) + (1 - \frac{Z}{A}) f_{a/n}(x, Q^2) \right],$$
 (71)

is assumed to be factorizable into the parton distribution in a nucleon fa/N (x, Q<sup>2</sup> ) and the nuclear modification factor Sa/A(x, b), parameterized in various ways [\[250,](#page-90-5) [251,](#page-90-6) [102\]](#page-84-15) according to the DIS data.

The initial partonic transverse momentum distribution in a projectile nucleon striking the target nucleus at impact parameter b is still assumed to be Gaussian but with a broadened variance

$$\langle k_T^2 \rangle_A(Q^2) = \langle k_T^2 \rangle_N(Q^2) + \delta^2(Q^2)(\nu_A(b) - 1).$$
 (72)

The broadening is assumed to be proportional to the mean number of scatterings νA(b) the projectile suffers inside the nucleus. The parameters are fitted to existing fixed-target p + A data at energies up to √ s = 40 GeV [\[89\]](#page-84-2)

For quantitative comparison of hadronic spectra from A + B and p + p collisions we define the nuclear modification factor [\[252\]](#page-90-7)

<span id="page-54-1"></span>
$$R_{AB}(p_T) = \frac{d\sigma_{AB}/dyd^2p_T}{\langle N_{bin}\rangle d\sigma_{NN}/dyd^2p_T}.$$
(73)

![](_page_55_Figure_0.jpeg)

<span id="page-55-0"></span>Figure 32:  $R_{AB}(p_T)$  (eq. 73) for midrapidity  $\pi^0$  and charged hadrons from d+Au relative to p+p collisions at 200 GeV, from PHENIX [209] and STAR [74]. Left: data compared to first predictions of the Cronin effect in p+Au collisions at  $\sqrt{s}=200$  GeV [89]. Right: data compared to calculated Cronin effect for  $\pi^0$  from a Glauber-eikonal model of multiple scattering [253]. The solid and dashed lines show variation with intrinsic  $k_T$ , dotted band shows uncertainty due to infrared regulator  $p_0=1.0\pm0.1$ .

 $\langle N_{bin} \rangle$ , the mean number of binary collisions, is discussed in Section 3.3. In the absence of nuclear effects the cross section for a hard process will scale as  $N_{bin}$ , making  $R_{AB}(p_T)$  unity. Nuclear-specific effects are measured by the deviation of  $R_{AB}(p_T)$  from unity. In the following we will also utilize a related quantity  $R_{CP}(p_T)$ , the binary-scaled ratio of central over peripheral spectra from A+A collisions:

<span id="page-55-1"></span>
$$R_{CP}(p_T) = \frac{d^2 N/dp_T d\eta/\langle N_{bin}\rangle (central)}{d^2 N/dp_T d\eta/\langle N_{bin}\rangle (peripheral)}$$
(74)

 $R_{AB}(p_T)$  and  $R_{CP}(p_T)$  contain similar physics, though  $R_{CP}(p_T)$  may at times be preferable from the standpoint of experimental uncertainties.

Fig. 32 shows  $R_{AB}(p_T)$  for  $\pi^0$  and charged hadrons from d+Au collisions at 200 GeV, measured by PHENIX [209] and STAR [74] (see also PHOBOS [210] and BRAHMS [208]). The curves in the left panel show the first prediction of the nuclear modification of hadron spectra in p + A collisions within the parton model [89]. The enhancement at intermediate  $p_T$ , known as the Cronin effect, is due in this calculation to broadening of  $k_T$  from multiple scattering. The enhancement disappears at large  $p_T$ , as do all higher-twist effects. The modest Cronin enhancement predicted for p + A collisions at this energy is confirmed by the measurements. The Cronin effect in A + A collisions at this energy should be of similar magnitude.

The Cronin effect has also been studied in multiple parton scattering models which utilize the eikonal Glauber framework [206, 252, 253]. Interference effects play an important role, for instance the absorption arising from single scattering cancels part of the double scattering contribution, leading to a  $1/p_T^2$  dependence of the yield enhancement due to double scattering

![](_page_56_Figure_0.jpeg)

<span id="page-56-1"></span>Figure 33: High  $p_T$  single inclusive hadron spectra from centrality-selected Au+Au collisions at  $\sqrt{s_{_{\mathrm{NN}}}}$ =200 GeV. Left: charged hadrons from STAR [254]. Right:  $\pi^0$  from PHENIX [255].

[206]. The dominant double scattering contribution occurs when one scattering is soft and most of the jet's  $p_T$  comes from one hard scattering. At lower  $p_T$  the absorptive correction dominates double scattering and the coherence of the interaction suppresses the spectrum relative to binary scaling. The transition between the coherent suppression and Cronin enhancement occurs at a scale  $p_0$ , where parton-nucleon scattering is no longer a power-law like process. Fig. 32, right panel, shows such a calculation [253] compared to data.

## <span id="page-56-0"></span>**6.4** High $p_T$ hadron suppression in A + A collisions

The foregoing analysis of hard scattering and high  $p_T$  hadron production at midrapidity in p+p and p(d)+A collisions demonstrates that the elementary production cross sections and nuclear multiple scattering effects are well understood, providing a foundation for jet tomographic studies in A+A collisions. Within the energy loss picture of multiple parton scattering and induced gluon bremsstrahlung, high  $p_T$  jet fragmentation will be softened and the final hadron spectra suppressed in A+A collisions [202]. The effective partonic energy loss can therefore be deduced from measurements of high  $p_T$  hadron suppression, providing a direct measurement of the initial gluon density. The experimental input for this study is shown in Fig. 33. Charged hadron and  $\pi^0$  single particle inclusive spectra from centrality-selected Au + Au collisions have been measured with high precision over a very broad  $p_T$  range [254, 255].

<span id="page-56-2"></span>The inclusive hadron spectrum in A+A collisions can be calculated using a LO pQCD model [89, 256],

$$\frac{d\sigma_{AA}^{h}}{dyd^{2}p_{T}} = K \sum_{abcd} \int d^{2}bd^{2}r dx_{a} dx_{b} d^{2}k_{aT} d^{2}k_{bT} t_{A}(r) t_{A}(|\mathbf{b} - \mathbf{r}|) g_{A}(k_{aT}, r) g_{A}(k_{bT}, |\mathbf{b} - \mathbf{r}|) 
\times f_{a/A}(x_{a}, Q^{2}, r) f_{b/A}(x_{b}, Q^{2}, |\mathbf{b} - \mathbf{r}|) \frac{D'_{h/c}(z_{c}, Q^{2}, \Delta E_{c})}{\pi z_{c}} \frac{d\sigma}{d\hat{t}} (ab \to cd),$$
(75)

with medium modified fragmentation functions  $D'_{h/c}$  given by Eq. (66).

![](_page_57_Figure_0.jpeg)

<span id="page-57-0"></span>Figure 34: Binary collision-scaled ratios of spectra shown in Fig. [33](#page-56-1) [\[254,](#page-90-9) [255\]](#page-90-10)(see also PHOBOS [\[257,](#page-90-12) [210\]](#page-88-16) and BRAHMS [\[208\]](#page-88-14)). Left: Centrality dependence of RAA(p<sup>T</sup> ) vs. p<sup>T</sup> . Theory curves are from calculations described in text. Boxes at RAA(p<sup>T</sup> )=1 indicate the (multiplicative) uncertainty due to binary collision scaling. The hatched region on the central collision theory curve indicates variation in ǫ<sup>0</sup> of ±0.3 GeV/fm (Eq. [68\)](#page-52-1). Right: RCP (p<sup>T</sup> ) [Eq. [\(74\)](#page-55-1)] for central (0-5%) over peripheral (40-60%, 60-80%) spectra, for charged hadrons from STAR [\[254\]](#page-90-9).

<span id="page-57-1"></span>Assuming one-dimensional longitudinal expansion and gluon density ρg(τ, r) proportional to the transverse density of participant nucleons, the impact parameter and path length dependence of the energy loss is [Eq. [\(65\)](#page-51-0)]

$$\Delta E(b, r, \phi) \approx \langle \frac{dE}{dL} \rangle_{1d} \int_{\tau_0}^{\Delta L} d\tau \frac{\tau - \tau_0}{\tau_0 \rho_0} \rho_g(\tau, b, \vec{r} + \vec{n}\tau), \tag{76}$$

where ∆L(b, ~r, φ) is the path length in matter for a jet produced at ~r and traveling in direction ~n with azimuthal angle φ relative to the reaction plane, in a collision with impact-parameter b. ρ<sup>0</sup> = hρgi(τ0) is the average initial gluon density in central collisions at τ<sup>0</sup> and hdE/dLi1<sup>d</sup> is the average parton energy loss in a one-dimensionally expanding medium with an initial uniform gluon density ρ0. The corresponding energy loss in a static medium with a uniform gluon density ρ<sup>0</sup> within radius R<sup>A</sup> is [\[235\]](#page-89-17) dE0/dL = (RA/2τ0)hdE/dLi1d. We will use the parameterization in Eq. [\(68\)](#page-52-1) for the effective energy dependence.

Fig. [34,](#page-57-0) left panel, shows RAA(p<sup>T</sup> ) derived from the data in Fig. [33,](#page-56-1) with additional charged hadron measurements from PHENIX [\[258\]](#page-90-13). The figure shows comparable charged hadron RAA(p<sup>T</sup> ) from STAR (filled circles) and PHENIX (triangles), which are seen to differ in overall normalization by ∼20%. This difference can be attributed to the ∼20% difference in normalization of the p+p reference spectrum used in the two analyses (denominator of Eq. [73\)](#page-54-1) [\[254,](#page-90-9) [258\]](#page-90-13). The measurements are however consistent within systematic uncertainties and for the purpose of this discussion the difference can be taken as an indication of the precision of the measurements. The figure shows a marked effect: high p<sup>T</sup> hadron production in central Au+Au collisions is suppressed by a factor five relative to binary collision scaling. The suppression has strong centrality dependence, with hadron yield in the most peripheral collisions consistent with binary collision scaling. Similar results have been obtained by PHOBOS [\[257,](#page-90-12) [210\]](#page-88-16) and BRAHMS [\[208\]](#page-88-14). This suppression stands in strong contrast to the enhancement in high p<sup>T</sup> hadron production observed for d + Au collisions in Fig. [27](#page-45-0) and [32.](#page-55-0) The strong yield suppression in central Au+Au contrasted with the enhancement in d+Au collisions clearly demonstrates that the central Au+Au suppression at high p<sup>T</sup> is due to final-state interactions in the fireball generated by the collision.

The solid lines in Fig. [34,](#page-57-0) left panel, are parton model calculations according to Eq. [\(75\)](#page-56-2). The fit to the observed factor of five suppression at large p<sup>T</sup> in the more central collisions results in the parameters ǫ<sup>0</sup> = 1.07 GeV/fm, µ = 1.5 GeV for the effective quark energy loss in Eq. [\(68\)](#page-52-1). The difference between charged hadron and π 0 spectra at intermediate p<sup>T</sup> is attributed to a nonperturbative component of hadron production, which we will return to in the next subsection. To demonstrate the sensitivity to the parameterized partonic energy loss in the intermediate p<sup>T</sup> region, the dashed curves show RAA(p<sup>T</sup> ) for charged hadrons excluding the soft component [\[256\]](#page-90-11). Once these parameters are fixed by fitting to central collisions, the centrality dependence of the suppression is a prediction of the model.

The suppression factor at the highest measured p<sup>T</sup> is shown for charged hadrons in Fig. [34,](#page-57-0) right panel [\[254\]](#page-90-9) (RCP (p<sup>T</sup> ) extends the p<sup>T</sup> reach and reduces the systematic uncertainties relative to RAA(p<sup>T</sup> ) [\[254\]](#page-90-9)). The suppression again is seen to be a factor five, independent of p<sup>T</sup> . This p<sup>T</sup> -(in)dependence is well reproduced by the pQCD calculations incorporating partonic energy loss (pQCD-I [\[256\]](#page-90-11), pQCD-II [\[259\]](#page-90-14)). The p<sup>T</sup> -independence of the suppression is not a trivial effect: it results from the subtle interplay between Cronin enhancement, shadowing of the structure functions, and jet quenching in a parton model with energy loss [\[259\]](#page-90-14).

The suppression for π 0 (left panel) varies only slightly over a very broad p<sup>T</sup> range, down to p<sup>T</sup> ∼1-2 GeV/c. A constant or logarithmic jet energy dependence of the energy loss as in cold nuclear matter generates a suppression factor that slowly rises with p<sup>T</sup> [\[235\]](#page-89-17). Thus, the energy dependence of the partonic energy loss seen in A+A collisions is quite different from that in DIS off cold nuclei. This is an indication of detailed balance at play in a thermal system. Detailed balance also leads to a slight rise in the calculation of RAA(p<sup>T</sup> ) at pT<4 GeV/c, where the fragmentation picture gradually loses its validity and hadron production may be influenced by non-perturbative effects, especially for kaons and baryons. For pT>5 GeV/c, these nonperturbative effects are expected to diminish and indeed the π <sup>0</sup> and charged hadron suppression factors converge in that region.

Partonic energy loss calculations reproduce the centrality dependence of the suppression well. The solid curves in the left panel of Fig. [34](#page-57-0) are calculated using partonic energy loss from Eq. [\(68\)](#page-52-1) with parameters fit to the central collision data for π <sup>0</sup> and charged hadrons. The centrality dependence is determined by the averaged total energy loss [Eq. [\(76\)](#page-57-1)], which results in an effective surface emission of the surviving jets. Jets produced at the core of the overlap region are strongly suppressed, since they lose the largest amount of energy. The centrality dependence of the suppression is found to be dominated by the geometry of the produced dense matter rather than the length dependence of the parton energy loss. The non-Abelian nature of the path length dependence of the energy loss must be tested in other ways, in particular via central A + A collisions with varying nuclear size.

Transverse expansion of the bulk medium can also be considered in the parton model calculation. Since the total energy loss in Eq. [\(65\)](#page-51-0) depends on a path integral of the parton density profile ρ(r, τ ), the transverse expansion will increase the duration of parton propagation in mat-

![](_page_59_Figure_0.jpeg)

<span id="page-59-1"></span>Figure 35: Binary collision-scaled ratio of yields  $R_{CP}(p_T)$  (eq. 74) from central relative to peripheral collisions for identified particles. Left: protons and pions from PHENIX [76]. Right: strange mesons and baryons from STAR [146, 264] compared to charged hadrons from Fig. 34.

ter. However, the expansion will also accelerate the reduction of the parton density along the path. These effects compete and the final total parton energy loss remains approximately the same as in the case without transverse expansion [260].

It was proposed recently that gluon saturation effects (Sect. 4.1) can extend well beyond the saturation momentum scale  $Q_s$ , resulting in hadron suppression relative to binary scaling  $(R_{AB}(p_T)<1)$  for hadron  $p_T \sim 5-10$  GeV/c at RHIC energies [261] as shown by the solid lines in the right panel of Fig. 34. Since this suppression originates in the properties of the incoming nuclear wave-function, hadron production in d+Au collisions should also be suppressed by this mechanism [261]. Experimentally, however, an enhancement in mid-rapidity hadron production in d+Au is seen instead (Figs. 27 and 32 [209, 74, 210, 208]), even in central d+Au collisions [74] where saturation effects should be most pronounced. The observed enhancement is at variance with saturation model expectations [261].

The saturation model calculation has since been developed to include the Cronin effect due to classical elastic scattering [262]. Quantum evolution cancels the Cronin enhancement, however, leading to suppression of high  $p_T$  hadrons at high energies or large rapidities. Suppression at large rapidity might however not be a unique signature of gluon saturation. For instance, limiting fragmentation of valence quark jets could also result in hadron suppression at forward rapidity [263]. Discrimination of these mechanisms may be possible by utilizing di-hadron correlations, which we discuss below.

### <span id="page-59-0"></span>6.5 Parton Recombination

The hadron suppression factor  $R_{AA}(p_T)$  in Fig. 34 is different for charged hadrons and  $\pi^0$  in the intermediate  $p_T \sim 2-5$  GeV region. More detail of this effect is seen in Fig. 35. The left panel shows that  $\pi^0$  are strongly suppressed in central collisions whereas protons are not suppressed in this region. The right panel shows similar systematic behavior for strange meson and baryon yields. It will also be seen that the azimuthal anisotropy  $(v_2)$  depends on hadron flavor at intermediate  $p_T$ , with the anisotropy of baryons larger than that of mesons [146].

In the intermediate  $p_T$  region, where the parton energy loss is strongly influenced by the

medium through absorption of thermal partons, fragmentation or hadronization should also be modified by the presence of other partons. These nonperturbative effects invalidate the picture of independent parton fragmentation in the vacuum. For instance, the leading parton may pick up another parton from the medium before hadronization, a scenario referred to as recombination or coalescence. Such recombination processes were long ago proposed as the dominant mechanism for hadron production in the beam fragmentation region of hadron collisions [265, 266]. Since recombination is a non-perturbative process, hadron wavefunctions should be taken into account along with the initial parton distributions. Alternatively, the recombination processes can be described as higher-twist corrections to the fragmentation functions, since they involve higher-twist matrix elements of the overlap between two- or three-parton operators and the final hadronic state. Such an approach has been applied to D meson production to explain the  $D^+ - D^-$  asymmetry in the forward rapidity region of h + p collisions [267].

To take this effect into account in the simple parton model a nuclear dependent soft component, assumed to be proportional to  $\langle N_{\rm binary} \rangle$ , is added to kaon and baryon fragmentation functions so that in central Au+Au collisions the ratio  $(K+p)/\pi \approx 2$  at  $p_T \sim 3$  GeV/c and the ratio approaches its value for p+p collisions at  $p_T > 5$  GeV/c. The resulting suppression for charged hadrons and its centrality dependence agree well with the STAR data (Fig. 34). The  $h^{\pm}$  and  $\pi^0$  suppression are related via the  $(K+p)/\pi$  ratio:  $R_{AA}^{h^{\pm}} = R_{AA}^{\pi^0}[1+(K+p)/\pi]_{AA}/[1+(K+p)/\pi]_{pp}$ . It is apparent from the data that  $(K+p)/\pi$  converges for Au+Au and p+p collisions at  $p_T > 5$  GeV/c. Since such nonperturbative effects are caused by presence of other produced partons, thermalized or not, a qualitatively similar dependence of the Cronin enhancement on hadron species should be seen in p(d)+A collisions. Such an effect is indeed observed [268], though the enhancement relative to p+p collisions in the ratio of proton to pion yields at intermediate  $p_T$  is markedly smaller in d+Au than in Au+Au collisions.

The observation of the flavor dependence of the suppression factor and, in particular, the flavor dependence of the azimuthal anisotropy (Sect. 6.7) have spurred new developments in the recombination approach to hadron production in heavy-ion collisions [269]. Parton recombination in heavy-ion collisions was first investigated by Hwa and Yang [270, 271] and was later studied in detail in terms of coalescence or recombination models [272, 273, 274, 275]. These models generally assume two components of high  $p_T$  hadron production in heavy-ion collisions. The recombination of partons from the bulk medium dominates the production of low and intermediate  $p_T$  hadrons, while high  $p_T$  hadrons result mainly from the fragmentation of parton jets after propagating through the bulk medium and losing energy. In these models, the number of mesons formed from parton recombination is [275]

$$N_M = g_M \int p_1 \cdot d\sigma_1 p_2 \cdot d\sigma_2 \frac{d^3 p_1}{(2\pi)^3 2E_1} \frac{d^3 p_2}{(2\pi)^3 2E_2} f_q(x_1; p_1) f_{\bar{q}}(x_2; p_2) f_M(x_1, x_2; p_1, p_2), \tag{77}$$

<span id="page-60-0"></span>where  $d\sigma$  denotes the differential element of the space-like hypersurface of hadronization and  $f_M(x_1, x_2; p_1, p_2)$  is the coalescence probability given by the Wigner distribution function of the meson in terms of constituent quarks. The statistical factor  $g_M$  takes into account the number of internal quantum states in forming a colorless meson from a colored quark and antiquark. The formula for baryon production from parton recombination is similar, except that it involves the baryon coalescence probability from three constituent quarks. The quark (or antiquark) distributions should contain both soft and hard components. The soft component arises from a thermalized quark-gluon plasma with collective radial and elliptic flow though the connection between the consituent quarks appearing in Eq. (77) and the massles partons of a chirally restored plasma is not specified at present in the model. The hard component is given by the

![](_page_61_Figure_0.jpeg)

<span id="page-61-0"></span>Figure 36:  $p_T$  dependence of the ratio of baryon to meson yields at  $\sqrt{s_{\rm NN}}$ =200 GeV. Left:  $\bar{p}/\pi^-$  for central Au + Au collisions, from PHENIX [76]. Lines are recombination model calculations [276] with (solid) and without (dashed) soft+hard contributions due to coalescence of minijet partons with thermalized partons. Right:  $\Lambda/K_s^0$  for p + p and centrality-selected Au + Au collisions, from STAR [264].

minijet distribution from a pQCD calculation, with transverse momentum reduced in accordance with the observed partonic energy loss.

In the low and intermediate  $p_T$  regions, the hadron spectra are dominated by recombination of thermal partons. Such a description may be considered as a model for hadronization of the quark gluon plasma. In this region the hadron spectra are determined by the underlying parton spectra and the statistical factors  $g_{M,B}$ . If an exponential form is assumed for the parton spectra, the proton to pion ratio in a simple recombination model will be independent of transverse momentum and is determined only by the ratio of statistical factors  $g_B/g_M$  [274]. If the contribution of  $\Delta$ -decay to the proton yield is included and the contribution of higher resonance decay to pions is excluded,  $p/\pi^- \sim 1$ . Fig. 36, left panel, shows the measured  $p/\pi^-$  ratio for central Au + Au collisions at  $\sqrt{s_{\rm NN}} = 200$  GeV from PHENIX [76] compared to the calculation by Greco, Ko and Levai [276], one of several recombination models [270, 274]. The calculation describes the data well. The  $p/\pi$  ratio indeed reaches a value of about unity, much larger than the value achieved in p + p collisions [268] and in gluon jets from  $e^+e^-$  annihilation [277]. The  $p_T$  dependence at lower  $p_T$  can be attributed to the contribution to the pion spectra from resonance decays, whose importance diminishes at higher  $p_T$ . Recombination models also successfully describe azimuthal asymmetry measurements, as discussed in Sect. 6.7.

At large transverse momentum the underlying parton spectrum is dominated by pQCD minijet production, which has power-law  $p_T$  dependence. The recombination mechanism in this case will always generate higher meson than baryon yields. For increasing  $p_T$ , fragmentation will eventually dominate recombination and the baryon/meson ratio should revert to that of parton fragmentation in vacuum, consistent with the expectation that recombination is a higher-twist process that is suppressed at high  $p_T$ . This  $p_T$ -dependence of the relative yield of mesons and baryons is common to a variety of recombination models [270, 274, 275]. It is in broad agreement with the data in Fig. 36, right panel, which shows a large enhancement of  $\Lambda/K_s^0$  for

more central Au + Au collisions at intermediate p<sup>T</sup> but convergence of the Λ/K<sup>0</sup> s ratio for all Au+Au centralities and p+p collisions at higher p<sup>T</sup> .

The model of Greco, Ko and Levai includes an additional pick-up process by leading hard partons, corresponding to the recombination of a parton from the hard component and a parton from the soft component [\[275\]](#page-91-4). Such soft+hard recombination can be significant at intermediate p<sup>T</sup> as shown by the dashed line in Fig. [36,](#page-61-0) left panel. This process will be critical for addressing the observed two-particle correlation of the same-side jet that will be discussed in the next subsection.

Recently, a jet fragmentation model was proposed [\[278\]](#page-91-7) in which parton recombination is the hadronization mechanism even in vacuum. The medium effect at intermediate p<sup>T</sup> is a natural consequence of the hadronization in medium in this model, which also leads to flavor dependence of the Cronin enhancement in d + Au collisions [\[279,](#page-91-8) [280\]](#page-91-9). Quantitative tests of recombination models and the determination of their parameters are best done using dihadron correlations. These studies are now underway.

As discussed in previous sections, measurements of low p<sup>T</sup> inclusive spectra and elliptic flow can be reproduced well by calculations incorporating ideal hydrodynamics. It is to be expected that such a hydrodynamic picture will break down at high p<sup>T</sup> where partonic cross sections are small and the mean free path is long, meaning that hard partons cannot be brought to thermal equilibrium as readily as soft partons. In this region, pQCD dynamics should dominate. To study the transition between these regimes at intermediate p<sup>T</sup> , hybrid calculations have been carried out that combine hydrodynamics with a pQCD parton model [\[281\]](#page-91-10). Since collective flow gives higher mass hadrons a larger p<sup>T</sup> boost, it is expected that the effects of collective flow will extend to larger p<sup>T</sup> for baryons than for light mesons. Such a two-component approach can indeed describe the observed p/π and Λ/K<sup>0</sup> s enhancements in Au + Au collisions. However, since the effects are purely kinematic it also predicts the same enhancement for heavy mesons. Preliminary data ([\[264,](#page-90-15) [282,](#page-91-11) [283\]](#page-91-12), see also Fig. [35](#page-59-1) right panel) indicate that the enhancement is rather more dependent on whether the hadron is a meson or baryon than on its mass. However, heavier mesons such as the φ may have smaller hadronic cross sections than baryons and not flow effectively with the bulk medium during the hadronic stage. An interesting test will be the measurement of azimuthal anisotropy of φ meson spectra, which may be relatively insensitive to the hadronic dynamics at the late stages of the expansion.

## <span id="page-62-0"></span>6.6 Dihadron Spectra and Jet Quenching

Jets are produced in pairs in leading order pQCD, and high p<sup>T</sup> dihadron correlations in p + p collisions should exhibit the back-to-back jet structure of the underlying hard parton-parton scattering. Jet quenching due to partonic energy loss in nuclear collisions is expected to modify such correlations.

As we have shown in Fig. [28,](#page-46-0) left panel, the relative azimuthal angle distributions of high p<sup>T</sup> hadron pairs in p + p and d + Au collisions exhibit the two-peak feature characteristic of backto-back jet pairs but the away-side correlation vanishes in central Au + Au collisions, consistent with the predicted phenomenon of mono-jet production due to jet quenching [\[284\]](#page-91-13). In these measurements the trigger hadron has p<sup>T</sup> trig>4 GeV/c, with the relative azimuthal angle plotted for all other hadrons having 2<pT<p<sup>T</sup> trig [\[223,](#page-89-0) [74\]](#page-83-15). All particles lie within |η|<0.7. For Au + Au collisions the effects of elliptic flow on the dihadron distribution must be taken into account [\[223\]](#page-89-0). The distributions are normalized to the number of trigger hadrons, thereby measuring the probability to find an associated hadron. The figure shows background-subtracted distributions, where the background is defined as the yield in an azimuthal interval orthogonal to the trigger where the correlated yield in p + p collisions is seen to be small.

The strength and width of the small-angle peak ( $\Delta\phi \sim 0$ ) are similar in all three distributions. The relative probability that the small-angle hadron pair has the same vs. opposite charge sign is similar to that measured in jets from  $e^+ + e^-$  annihilation ("charge ordering" [285, 223]). The contribution of resonances to this peak is estimated to be negligible [223]. This series of evidence leads to the conclusion that the small-angle correlation in all systems from p+p to central Au + Au results dominantly from the fragmentation of jets. The large-angle peak ( $\Delta\phi \sim \pi$ ) has similar strength and width in p+p and d+Au collisions, indicating a hadron pair produced by the fragmentation of a back-to-back jet pair. The large-angle high  $p_T$  dihadron correlation is however markedly suppressed in central Au + Au collisions, suggesting significant suppression of the back-to-back jet yield.

<span id="page-63-0"></span>The strength of the correlation in Au + Au can be quantified by integrating the yield in the correlation peak and comparing to the p + p correlation via [223]

$$I_{AA}(p_T) = \frac{\int_{\Delta\phi_1}^{\Delta\phi_2} d\left(\Delta\phi\right) \left[ C^{AuAu} - B\left(1 + 2v_2^2 \cos\left(2\Delta\phi\right)\right) \right]}{\int_{\Delta\phi_1}^{\Delta\phi_2} d\left(\Delta\phi\right) C^{pp}},\tag{78}$$

where  $C^{AuAu}$  and  $C^{pp}$  are the measured dihadron azimuthal angle distributions in Au + Au and p + p prior to background subtraction. The subtracted background  $B\left(1 + 2v_2^2\cos\left(2\Delta\phi\right)\right)$  results from a fit to the Au + Au distribution in the background interval orthogonal to the trigger direction. The elliptic flow coefficient  $v_2$  is determined by independent measurements [286]. The integration interval  $[\Delta\phi_1, \Delta\phi_2]$  spans either the small-angle or back-to-back peaks in the p + p distribution. Figure 37, left panel, shows the centrality dependence of  $I_{AA}(p_T)$  for both same-side (upper) and back-to-back (lower) dihadron pairs. As is also apparent in Fig. 28, the same-side correlation strength for all Au + Au centralities is similar to p + p. In contrast, the back-to-back correlation, to central collisions where it is negligible [223]. It is compelling to attribute the back-to-back suppression in central collisions to jet quenching.

The population of jets contributing to the near-side and back-to-back correlations may differ for two reasons. First, the requirement of a pair of hadrons above threshold biases the near-side contribution to jets with larger initial energy. Second, if the partonic energy loss in the core of the fireball is large, the trigger will bias towards those jets that are produced near the surface of the reaction volume, heading outward. The jets that generate the same-side correlation would therefore punch through the medium after losing a limited amount of energy and fragment essentially in vacuum, leading to similar near-angle dihadron correlations from p+p to central Au + Au, as observed. The jets recoiling against the trigger will however be biased towards the population heading into the core of the fireball and will be strongly suppressed, as observed. The total energy of the jets, suppressed or not, is of course conserved but it may be redistributed to softer hadrons with much broader angular distributions. In the picture of partonic energy loss due to induced radiation, the emitted gluons could further interact with other partons and dissipate their energy to the medium. The hadronic structure of the jet will thereby be lost, leading to strong suppression of the back-to-back high  $p_T$  dihadron correlation. This picture of trigger bias is also consistent with the suppression of inclusive production at high  $p_T$  relative to binary collision scaling (Fig. 34), since jets will be emitted dominantly from the surface and not the volume of the fireball.

It should be noted, however, that the correlations discussed thus far have  $p_T^{\text{trig}}>4$  GeV/c. While the systematic features of near-angle correlations in central Au + Au are similar to those

![](_page_64_Figure_0.jpeg)

![](_page_64_Figure_1.jpeg)

<span id="page-64-0"></span>Figure 37: High  $p_T$  dihadron distributions from 200 GeV Au + Au and p + p collisions, from STAR. Left: centrality dependence of near-angle and back-to-back dihadron correlation strength in Au + Au relative to p + p ( $I_{AA}(p_T)$ , Eq. [78]) for  $p_T(trig) > 4$  GeV/c [223]. Central collisions correspond to large  $N_{part}$ . Right: dihadron azimuthal distributions for  $p_T(trig) > 6$  GeV for central Au + Au (data points) and for p + p plus a model of the Au + Au background (histogram) [287]. Note the rotation of the horizontal axis relative to Fig. 28, left panel.

from jet fragmentation in  $e^+ + e^-$  annihilation, Fig. 36 shows that the inclusive hadron population in the range of  $p_T^{\rm trig} \sim 4~{\rm GeV}/c$  is significantly different in central Au + Au collisions than in vacuum jet fragmentation. It therefore cannot be excluded that non-perturbative mechanisms contribute to the dihadron phenomenology in Figs. 28 and 37, left panel. Fig. 37, right panel, shows the same dihadron correlation analysis described above but for  $p_T^{\rm trig} > 6~{\rm GeV/c}$  [287]. The points are the measured distribution for central Au + Au, in this case not background subtracted, while the histogram is the sum of the measured p + p correlation plus a model of the central Au + Au background including elliptic flow. The near-angle peaks are again seen to be similar, while the back-to-back correlation strength for central Au + Au is again seen to be strongly suppressed relative to the p + p excess above background. The persistence of the back-to-back suppression to higher  $p_T$  argues that it is indeed due to jet quenching.

In the direction opposite the triggered hadron, the azimuthal angle distribution measures the single inclusive hadron distribution of the away-side jet. The width of the peak in p + p collisions is characteristic of the jet profile and is determined by both the distribution of the intrinsic  $p_T$  perpendicular to the jet axis and the relative transverse momentum between the two back-to-back jets. In d + Au collisions, initial multiple parton scattering may broaden the dijet relative  $p_T$  and thus the back-to-back dihadron correlation, but the integrated correlation strength should remain approximately the same as in p + p collisions since the integrated area under the away-side peak is essentially determined by the fragmentation function of the jet. In central Au + Au collisions, however, partonic energy loss will suppress the leading hadron distribution in a jet, thus leading to the reduction of the away-side jet peak as indeed shown by the experimental data.

For the small-angle pairs, the shape of the correlation in p+p collisions is entirely determined by the intrinsic  $p_T$  perpendicular to the jet axis. The integrated value of the correlation strength is related to the ratio of dihadron and single hadron fragmentation functions [288]. This correlation remains approximately the same in p+p, d+Au and Au+Au collisions, indicating jet fragmentation in all cases. According to the picture of parton energy loss, a parton with reduced energy fragments outside the dense medium, giving rise to a leading dihadron correlation similar to that in the absence of energy loss. The lost energy will be carried by the radiated gluons which in turn will only contribute to soft hadrons along the direction of the triggered hadron.

To study the back-to-back dihadron correlation, one can again apply a LO pQCD parton model. The spectrum of back-to-back dihadrons from the independent fragmentation of back-to-back jets can be calculated as

$$E_{1}E_{2}\frac{d\sigma_{AA}^{h_{1}h_{2}}}{d^{3}p_{1}d^{3}p_{2}} = \frac{K}{2}\sum_{abcd}\int d^{2}bd^{2}rdx_{a}dx_{b}d^{2}k_{aT}d^{2}k_{bT}t_{A}(r)t_{A}(|\mathbf{b}-\mathbf{r}|)g_{A}(k_{aT},r)g_{A}(k_{bT},|\mathbf{b}-\mathbf{r}|)$$

$$\times f_{a/A}(x_{a},Q^{2},r)f_{b/A}(x_{b},Q^{2},|\mathbf{b}-\mathbf{r}|)D_{h/c}(z_{c},Q^{2},\Delta E_{c})D_{h/d}(z_{d},Q^{2},\Delta E_{d})$$

$$\times \frac{\hat{s}}{2\pi z_{c}^{2}z_{d}^{2}}\frac{d\sigma}{d\hat{t}}(ab \to cd)\delta^{4}(p_{a}+p_{b}-p_{c}-p_{d}). \tag{79}$$

Let hadron  $h_1$  be the trigger hadron with  $p_{T1} = p_T^{\text{trig}}$ . We define the hadron-triggered fragmentation function (FF) as the back-to-back correlation with respect to the triggered hadron:

<span id="page-65-0"></span>
$$D^{h_1 h_2}(z_T, \phi, p_T^{\text{trig}}) = \frac{d\sigma_{AA}^{h_1 h_2} / d^2 p_T^{\text{trig}} dp_T d\phi}{d\sigma_{AA}^{h_1} / d^2 p_T^{\text{trig}}},$$
(80)

similar to the direct-photon triggered FF in  $\gamma$ -jet events [238, 239]. Here,  $z_T = p_T/p_T^{\rm trig}$  and integration over  $|y_{1,2}| < \Delta y$  is implied. In a simple parton model the dijets will be precisely backto-back, but the initial parton  $p_T$  distribution will give rise to a Gaussian angular distribution. In addition,  $p_T$  smearing within a jet must be taken into account using a Gaussian distribution with a width of  $\sim 0.6 \text{ GeV}/c$ .

Fig. 38, left panel, shows the calculated back-to-back correlations for charged hadrons in Au + Au collisions compared to the STAR data [223]. The same energy loss that is used to calculate single hadron suppression also describes well the observed back-to-back suppression and its centrality dependence. In central Au + Au collisions, multiple parton scatterings that induce partonic energy loss can also generate smearing in the transverse momentum of the final parton before fragmentation. This can further suppress the back-side correlation at its peak [289]. However, after integration over the azimuthal angle, the smearing due to final state  $p_T$  broadening does not influence significantly the integrated suppression factor of the hadron-triggered FF.

The hadron-triggered fragmentation function is obtained by integrating over  $\phi$ ,  $D^{h_1h_2}(z_T, p_T^{\text{trig}}) = \int_{\pi/2}^{\pi} d\phi D^{h_1h_2}(z_T, \phi, p_T^{\text{trig}})$ . The dihadron suppression factor defined by STAR [223] (Eq. [78]) is

$$I_{AA}(z_T, p_T^{\text{trig}}) \equiv \frac{D_{AA}^{h_1 h_2}(z_T, p_T^{\text{trig}})}{D_{p_m}^{h_1 h_2}(z_T, p_T^{\text{trig}})},$$
 (81)

which is the modification factor of the hadron-triggered FF. Fig. 38, right panel, shows the suppression factors of the hadron-triggered FF's for different values of  $p_T^{\rm trig}$  in central Au + Au collisions, compared to a STAR data point obtained by integrating the observed correlation over  $\pi/2 < |\Delta \phi| < \pi$ . The dashed lines illustrate the small suppression of back-to-back correlations due to the initial nuclear  $k_T$  broadening in d+A collisions. The strong QCD scale dependence of the fragmentation functions on  $p_T^{\rm trig}$  is to a large extent canceled in the suppression factor. The approximately universal shape reflects the weak  $p_T$  dependence of the hadron spectra suppression factor in Figs. 34, due to the unique energy dependence of parton energy loss.

![](_page_66_Figure_0.jpeg)

<span id="page-66-1"></span>Figure 38: Left: Back-to-back dihadron correlations for Au + Au (lower curves) and p + p (upper curves), with  $4 < p_T^{\text{trig}} < 6 \text{ GeV}/c$ ,  $2 < p_T < p_T^{\text{trig}} \text{ GeV}/c$ , and |y| < 0.7, compared to background-subtracted STAR data [223]. Right: The suppression factor for hadron-triggered fragmentation functions in central (0-5%) Au + Au (d+Au) collisions, compared to STAR data [223].

Preliminary studies of back-to-back dihadron distributions with low associated  $p_T$  have revealed a very broad azimuthal distribution at low  $z_T$  for central Au + Au collisions, with no evidence of jet-like azimuthal correlations [290, 291]. The measured distributions are consistent with statistical momentum balance by a large ensemble of recoiling hadrons [292] even for  $p_T^{\text{trig}} > 6.5 \text{ GeV/c}$  [290]. These preliminary results suggest that the soft hadrons in the recoiling jet may be significantly broadened, resulting from thermalization of the emitted gluons and  $p_T$  broadening of the jet in the medium. More extensive studies of the modification of the FF at low  $z_T$  with higher  $p_T^{\text{trig}}$  are needed to elucidate the picture.

The dihadron correlation on the same side also places important constraints on coalescence models. The same-side correlations characteristic of jet structure exclude the recombination of uncorrelated partons from the thermal medium as the dominant mechanism for hadron production at intermediate  $p_T$ . Such a jet structure on the near side rather favors coalescence of a fast parton from the hard scattering with a slower parton from the medium. In the case of hard-soft coalescence, both the shape and strength of the correlation may be different from vacuum fragmentation. In particular, if the thermal medium develops longitudinal flow, coalescence of a leading parton with a thermal parton will lead to broadening of the correlation in rapidity.

## <span id="page-66-0"></span>6.7 High $p_T$ Azimuthal Anisotropy

Non-central collisions generate an initially anisotropic reaction zone (Fig. 22, left panel), with the long axis perpendicular to the reaction plane. In pQCD, the final state partons following a hard scattering have a priori no correlation with the azimuthal orientation of the reaction plane. However, the average path length of parton propagation in the medium will vary with the azimuthal angle relative to the reaction plane, leading to an azimuthal dependence of the

![](_page_67_Figure_0.jpeg)

<span id="page-67-0"></span>Figure 39: Left: azimuthal anisotropy v<sup>2</sup> from 4-particle cumulant analysis of 200 GeV Au + Au collisions from STAR [\[297\]](#page-92-0) compared to parton model calculations incorporating partonic energy loss. Right: p<sup>T</sup> dependence of v<sup>2</sup> for identified particles, with both axes scaled by the number of constituent quarks; data from PHENIX and STAR, figure from [\[298\]](#page-92-1).

total partonic energy loss. Thus, azimuthal anisotropy or "elliptic flow" of high p<sup>T</sup> hadrons relative to the reaction plane is a consequence of partonic energy loss and is insensitive to effects of initial state interactions [\[293,](#page-91-22) [236\]](#page-89-18).

The experimental techniques for studying azimuthal anisotropy at high p<sup>T</sup> are the same as at low p<sup>T</sup> (Sect. [5.3\)](#page-36-0). The strength of the correlation is measured by the second Fourier coefficient v<sup>2</sup> of the azimuthal distribution [Eq. [\(41\)](#page-37-1)]. Special care must be taken to account for so-called "non-flow" effects contributing to v<sup>2</sup> which arise from multiparticle correlations that are unrelated to correlations with the reaction plane [\[158\]](#page-86-17). Non-flow effects may result, for instance, from resonance decays, momentum conservation, and particularly at high p<sup>T</sup> , intra- and inter-jet hadron correlations. The standard method of correlating each high p<sup>T</sup> hadron with the reaction plane is equivalent to a dihadron correlation analysis [\[158\]](#page-86-17). Higher order cumulants have been shown to be markedly less sensitive to non-flow effects than the two-particle correlation methods [\[294,](#page-91-23) [295\]](#page-91-24). It has recently been argued, however, that higher order cumulants are susceptible to fluctuation effects and may thereby underestimate the true correlation strength [\[296\]](#page-91-25). The two-particle and higher order correlation measurements thus may bracket the true flow v<sup>2</sup> and are usually reported together.

Fig. [28,](#page-46-0) right panel, shows the azimuthal anisotropy v<sup>2</sup> in non-central Au + Au collisions at 200 GeV for the reaction plane (circles) and 2- (triangles) and 4-particle (stars) cumulant methods [\[224\]](#page-89-1). The measured v<sup>2</sup> is large, in the sense that its magnitude is similar to the eccentricity due to the initial spatial anisotropy of the collision [Eq. [\(39\)](#page-37-2)] [\[299,](#page-92-2) [272\]](#page-91-1). Since the spatial eccentricity of the fireball is diluted by expansion [\[113,](#page-84-26) [139\]](#page-85-25), such a large v<sup>2</sup> at high p<sup>T</sup> may result from strong partonic energy loss at the earliest, hot and dense phase of the evolution.

In the parton model approach, the azimuthal dependence of the partonic energy loss for non-central heavy-ion collisions is given by Eq. [\(76\)](#page-57-1). The anisotropic energy loss in the effective modified fragmentation functions of the pQCD parton model can be used to obtain the azimuthally anisotropic hadron spectra at high p<sup>T</sup> . Fig. [39,](#page-67-0) left panel, shows v<sup>2</sup> for charged hadrons generated from partonic energy loss (dot-dashed) compared to the measured v<sup>2</sup> from a 4-particle cumulant analysis [\[224,](#page-89-1) [297\]](#page-92-0). The energy loss extracted from high p<sup>T</sup> inclusive suppression can account for the observed azimuthal anisotropy at large  $p_T>6$  GeV/c (dot-dashed line).

The azimuthal anisotropy at high  $p_T$  can also depend on the transverse expansion, which depletes the gluon density more rapidly than one-dimensional expansion and dilutes the initial geometric anisotropy. The depletion in gluon density is however compensated by longer propagation time in the medium, giving rise to roughly the same total energy loss. In realistic calculations the azimuthal anisotropy of partonic energy loss is found to decrease slightly relative to the case of no transverse expansion [260] and quantitative analyses should take this effect into account. Note also that in the current parton model calculations a hard-sphere nuclear distribution is used. A more accurate calculation would employ the more realistic Wood-Saxon distribution which would reduce the high  $p_T$   $v_2$  [300]. However, partonic energy loss occurs mainly at early time due to rapid expansion, making the final result relatively insensitive to the shape of edge of the reaction zone.

The observed  $v_2$  at intermediate  $p_T$  is larger than the simple parton model calculation. This discrepancy may be attributable to effects of parton coalescence. If the difference is due to the flow of kaons and baryons generated by coalescence, they must have  $v_2 \approx 0.23$  for 20-50% collisions and  $v_2 \approx 0.11$  for 0-10% collisions. The total  $v_2$  incorporating this effect is shown by the solid lines in Fig. 39, left panel.

A remarkable phenomenological scaling for particle-identified  $v_2$  is seen in Fig. 39, right panel, where both the horizontal  $(p_T)$  and vertical  $(v_2)$  axes have been scaled by the number of constituent quarks in the hadron  $(n_q = 2 \text{ for mesons}, n_q = 3 \text{ for baryons})$ . The scaled distributions for all hadrons except pions collapse within experimental uncertainties to a universal curve, indicating that constituent quark dynamics may be driving the  $v_2$  of hadrons at intermediate  $p_T$ . Such scaling emerges from a recombination model based an exponential partonic spectrum [301, 269], with the requirement that all partons contribute equally to the hadron's momentum (i.e. the Wigner function of the hadron is a  $\delta$ -function in momentum space). Relaxation of the  $\delta$ -function condition is found however to generate negligible change in  $v_2$  at intermediate  $p_T[301, 269]$ , so that the observed scaling provides robust support for recombination as the mechanism underlying hadronization at intermediate  $p_T$ . Pions are excused from following the scaling because they arise dominantly from  $\rho$ -decay [302].

If hadrons at intermediate  $p_T$  are produced through recombination of a fast parton from a jet and with soft partons from the thermal medium, their azimuthal anisotropy relative to the reaction plane should depend both on the azimuthal dependence of the partonic energy loss and on the elliptic flow of the soft partons. In such models the functional dependence of  $v_2$  on  $p_T$  for soft partons must be specified, with parameters fixed by fitting to the data. The predictive power of the model lies in the flavor dependence. Since baryons receive a larger relative contribution from coalescence, with the effect extending to larger  $p_T$  than for mesons, splitting of  $v_2(p_T)$  for baryons and mesons should be observed. Fig. 40 shows measured  $v_2(p_T)$  for K and  $\Lambda$  compared to two coalescence model calculations [301, 276]. The models reproduce  $v_2$  of all species well up to  $p_T{\sim}4$ -5 GeV/c. As for inclusive spectra, coalescence effects on  $v_2$  diminish for  $p_T > 5$  GeV where  $v_2(p_T)$  for all hadron species should become the same, driven by partonic energy loss.

An additional test of partonic energy loss results from the differential study of high  $p_T$  dihadron correlations relative to the reaction plane orientation. Fig. 41 shows a preliminary study of the high  $p_T$  dihadron correlation for non-central (20-60%) Au + Au collisions, with the trigger hadron situated alternatively in the azimuthal quadrants centered on the reaction plane ("in-plane") or those orthogonal to it ("out-of-plane") [303, 304]. The same-side dihadron correlation in both cases is similar to that in p + p collisions. In contrast, the suppression of the

![](_page_69_Figure_0.jpeg)

<span id="page-69-1"></span>Figure 40:  $v_2$  of K and  $\Lambda$  [146] compared to coalescence model calculations. Left: calculations from [276]. Model predictions for  $\phi$  and  $\Omega$  also shown. Dotted curve is strange quark anisotropy. Right: calculations from [301].

back-to-back correlation depends strongly on the relative angle between the trigger hadron and the reaction plane. This systematic dependence is also consistent with the picture of partonic energy loss: the path length in medium for a dijet oriented out of the reaction plane is longer than in the reaction plane (Fig. 22, left panel), leading to correspondingly larger energy loss.

### <span id="page-69-0"></span>6.8 Partonic Energy Loss vs. Hadronic Absorption

From the analyses within a parton model of single inclusive and dihadron spectra and the azimuthal anisotropy  $v_2(p_T)$ , the average energy loss for a 10 GeV quark propagating through the expanding medium created at initial time  $\tau_0 = 0.2 \text{ fm/}c$  in 200 GeV central Au+Au collisions is  $\langle dE/dL \rangle_{1d} \approx 0.85 \pm 0.24$  GeV/fm. This is equivalent to  $dE_0/dL \approx 13.8 \pm 3.9$  GeV/fm in a static and uniform medium over a distance  $R_A = 6.5$  fm at initial time  $\tau_0 = 0.2$  fm. The value is about 30 times higher than the quark energy loss in cold nuclei, as extracted from HERMES DIS data. Since the partonic energy loss in the thin plasma limit is proportional to the gluon number density, this indicates that the initial gluon density at  $\tau_0 = 0.2$  fm/c reached in central Au + Aucollisions at 200 GeV is about 30 times higher than the gluon density in a cold Au nucleus. This number is consistent with the estimate from the measured rapidity density of charged hadrons [101] using the Bjorken scenario [112], assuming duality between the number of initial gluons and final charged hadrons. Since total parton energy loss is only sensitive to the gluon density of the medium [Eq. (65)], this is the only property that can be extracted from the suppression of single and dihadron spectra. To extract the initial energy density, additional measurements such as jet broadening are required. Alternatively, the energy density can be estimated from global measurements. Given the measured total transverse energy  $dE_T/d\eta \approx 540$  GeV or about 0.8 GeV per charged hadron in central Au + Au collisions at  $\sqrt{s} = 130$  GeV [134], the initial energy density is 50-100 times that in cold nuclear matter (Sec. 4.5).

In the above analyses of RHIC data, the mechanism dominantly responsible for jet quenching is partonic energy loss prior to hadronization of the jet. While this picture is in good accord with the observed high  $p_T$  phenomena, it is essential to ask whether *hadronic* interactions, specifically the interaction of hadronic jet fragments with the medium, can at least in part

![](_page_70_Figure_0.jpeg)

<span id="page-70-0"></span>Figure 41: Background-subtracted high p<sup>T</sup> dihadron correlation for different orientations of the trigger hadron relative to the reaction plane [\[303,](#page-92-6) [304\]](#page-92-7).

generate the observed high p<sup>T</sup> phenomena and contribute substantially to the jet quenching [\[305,](#page-92-8) [306,](#page-92-9) [307\]](#page-92-10). Some simple considerations already argue against this scenario. The formation time of hadrons with energy E<sup>h</sup> and mass m<sup>h</sup> is t<sup>f</sup> = (Eh/mh)τ<sup>f</sup> , where the rest frame formation time τ<sup>f</sup> ∼ 0.5 − 0.8 fm/c. Thus, a 10 GeV/c pion has formation time ∼ 50 fm/c and is unlikely to interact as a fully formed pion in the medium. Since the formation time depends on the boost, the suppression due to hadronic absorption with constant or slowly varying cross section should turn off with rising p<sup>T</sup> , at variance with observations (Fig. [34,](#page-57-0) right panel). A detailed hadronic transport calculation [\[307\]](#page-92-10) leads to a similar conclusion: the absorption of formed hadrons in the medium cannot account by a large factor for the observed suppression, and the suppression is attributed to medium interactions of "pre-hadrons" which have short formation time and constant cross section, in other words properties similar to those of colored partons [\[307\]](#page-92-10). Further consideration of the available high p<sup>T</sup> data [\[308\]](#page-92-11) also supports the conclusion that jet quenching in heavy ion collisions at RHIC is the consequence of partonic energy loss. In particular, large v<sup>2</sup> at high p<sup>T</sup> and the systematics of the small-angle dihadron correlations are difficult to reconcile with the hadronic absorption scenario.

Azimuthal anisotropy of the spectra in non-central collisions arises from the initial spatial eccentricity of the dense medium. The eccentricity decreases rapidly with time due to transverse expansion [\[113,](#page-84-26) [139\]](#page-85-25), so that momentum anisotropy must be generated early, ∼few fm/c. The finite anisotropy observed at high p<sup>T</sup> (Fig. [28,](#page-46-0) right panel) is therefore unlikely to have significant contribution from the absorption of formed hadrons.

As we have shown in Fig. [28,](#page-46-0) left panel, the back-to-back dihadron correlation is suppressed in central Au + Au collisions relative to p + p and d + Au collisions, while the same-side correlations are similar in all three systems. In the framework of jet fragmentation, the same-side correlation measures the conditional distribution of the second leading hadron within a jet in coincidence with the trigger hadron, essentially the ratio of dihadron to single hadron fragmentation functions. Insofar as both hadrons originate from the same fragmenting parton, this ratio will largely be independent of the parton energy. Gluons radiated via energy loss will generate soft hadrons and will enhance the conditional distribution at small z. A recent study of the dihadron fragmentation functions shows that the conditional (or triggered) dihadron distribu-

![](_page_71_Figure_0.jpeg)

<span id="page-71-0"></span>Figure 42: Average transverse energy  $\langle E_T \rangle^{jet}$  of the initial partons that produce a final hadron with  $p_T^{\text{trig}}$  as a function of  $\langle N_{\text{part}} \rangle$  for different values of  $p_T^{\text{trig}}$  (lowest curves for smallest  $p_T$ ).

tion at large z within a jet is quite stable against radiative evolution (or energy loss), while soft secondary hadrons are enhanced [288].

Hadronic absorption, on the other hand, will generally suppress the leading and secondary hadron independently, thereby suppressing the conditional distribution to the same degree as the single particle inclusive yield. This may not be the case if the hadronic absorption is very strong and only jets originating in a thin surface shell generate trigger hadrons which are not suppressed, but we consider this scenario to be unrealistic. Calculations in a parton model with energy loss show that even the trigger-biased jet population generated near the surface loses on average about 2 GeV of energy [308], as seen in Fig. 42. This energy will be carried by soft hadrons correlated with the trigger, and the total jet energy for fixed trigger hadron  $p_T^{\text{trig}}$  should be larger in Au + Au collisions than in p + p collisions by about 2 GeV. We will discuss the prospects for observing the radiated energy carried by soft hadrons using dihadron measurements in section 6.9.

If hadronic absorption suppresses high  $p_T$  hadrons and jets, it should also do so in heavy-ion collisions at SPS energy. Hadronic spectra at this energy vary strongly with  $p_T$  and are very sensitive to initial transverse momentum broadening and parton energy loss [89]. The measured  $\pi^0$  spectrum in central Pb + Pb collisions appears to exhibit only the expected Cronin enhancement relative to a p+p reference, with no suppression observed [309, 310, 311]. However, the  $\pi^0$  yield for central collisions is seen to be suppressed relative to that for peripheral collisions [310]. It has been been pointed out recently [312] that the p+p reference used in this study contains significant uncertainties, and a reassessment also reveals a possible high  $p_T$   $\pi^0$  suppression for central Pb + Pb relative to p+p collisions. Recent analysis of dihadron correlations shows that both same-side and back-to-back jet-like correlations are not suppressed in central collisions at the SPS, though the back-side distribution is broadened [313]. The question of high  $p_T$  hadron suppression at the SPS and its connection to jet quenching therefore remains open. More generally, study of the  $\sqrt{s}$  dependence of the suppression will provide an essential cross-check of our understanding of these phenomena. High  $p_T$  hadron production results from the recently completed 62 GeV Au + Au run at RHIC are now becoming available [314].

We conclude that the data provide no clear support for hadronic absorption as the dominant mechanism underlying the observed high  $p_T$  suppression phenomena. We consider large partonic energy loss in the dense medium formed in central Au + Au collisions at RHIC to be well established. We now discuss future measurements that will exploit this new phenomenon as a precision probe of the medium.

### <span id="page-72-0"></span>6.9 Hard probes: an outlook

The discovery of jet quenching opens a new era in the study of dense QCD matter. Higher precision data extending to larger  $p_T$  will map in detail the modification of the fragmentation functions and the energy dependence of the energy loss. The ultimate measurement of modified FF's in heavy ion collisions will be the direct photon triggered FF. Measurements of charmed mesons will also provide key tests of the parton energy loss scenario of jet quenching; recent theoretical studies reveal features of heavy quark energy loss that are measurably different from those of light quarks and gluons [315, 316, 317, 318]. Dihadron fragmentation and correlations within the same jet will also be important, for instance the broadening of the dihadron angular correlation which probes the average momentum transfer of the interaction with the medium that may be related directly to the energy density [288].

#### Direct Photon Tagged Jet Quenching

The definition of direct photon-triggered fragmentation functions is similar to the hadron-triggered fragmentation function in Eq. (80), replacing the triggered hadron with a direct photon [238, 239]. This corresponds to the measurement of the hadron  $p_T$  distribution in the opposite azimuthal direction to the triggered photon. Since a direct photon in the central rapidity region (y=0) is always accompanied by a jet in the opposite azimuth with roughly equal transverse energy, the  $p_T$  distribution of particles is directly related to the fragmentation function of a jet with known initial energy,  $E_T^{\text{jet}} \approx E_T^{\gamma}$ . By comparing the extracted jet fragmentation function in A + A to that in p + p collisions, the modification of the fragmentation function and thereby the partonic energy loss can be measured directly.

Fig. 43 shows examples of the the suppression factors of the direct photon-tagged jet fragmentation function for average partonic energy loss dE/dx = 1 GeV/fm. They are similar in shape to the hadron-triggered fragmentation function. The presently measured single particle inclusive and dihadron suppression generate an average energy loss of about dE/dx = 0.85 GeV/fm for a 10 GeV quark in central Au + Au collisions at RHIC. According to the parameterized energy dependence in Eq. (68), the average energy loss for a 15 GeV quark should be about 1.26 GeV, slightly larger than that used to generate the curves in the figure. The initial mean free path that fits the inclusive and dihadron data,  $\lambda_0 = 0.3 \text{ fm}$ , is consistent with 1-2 fm used in the calculation after correction for the one-dimensional expansion.

The measurement of direct photon-triggered fragmentation is extremely challenging because of low cross sections and the difficulty of isolating direct photons in the heavy-ion collision environment. However, statistical measurements of the inclusive direct photon yield are now becoming available. Fig. 43, right panel, shows the preliminary measured ratio of the yield of total (direct + decay) photons to expected decay photons, from PHENIX [319]. The measured ratio in p+p collisions is consistent with an NLO calculation of the direct photon yield [319]. The figure compares the ratio in central Au + Au collisions to NLO calculations of the direct photon yield normalized alternatively by a background derived from the binary-scaled  $\pi^0$  yield from p+p

![](_page_73_Figure_0.jpeg)

<span id="page-73-0"></span>Figure 43: Left: Calculated modification factor of the photon-tagged jet fragmentation function in central Au + Au collisions at  $\sqrt{s} = 200$  GeV for fixed  $dE_q/dx = 1$  GeV/fm [239]. Right: Ratio of total to decay photon yield in central Au + Au collisions at 200 GeV, from PHENIX [319]. The lines correspond to direct photon yields from NLO pQCD and decay photons from the measured  $\pi^0$  spectra. Upper curves incorporate Au + Au jet quenching in the background estimate, lower curves are for binary-scaled background.

collisions or by the measured, highly suppressed  $\pi^0$  yield from central Au + Au collisions. The latter normalization is clearly favored, demonstrating unambiguously that the photon excess is not suppressed. This is consistent with the partonic energy loss picture since the photon does not carry color charge. Further isolation of direct photons from the QCD fragmentation background is difficult in heavy ion collisions because standard techniques, in particular isolation cuts, cannot be directly applied. Strong jet suppression may help in this regard, however. This result in any case shows great promise and measurement of the modified fragmentation function of a jet recoiling from a hard photon is on the horizon.

#### Heavy Quark Energy Loss

The current experimental studies of jet quenching have focused on light quark and gluon jets. The energy loss of gluons and light quarks differ by a factor of  $C_A/C_F = 9/4$ , but it is difficult to differentiate quark and gluon jets in practice in p + p and Au + Au collisions. Identified hadron ratios such as  $K^-/K^+$  or  $\bar{p}/p$  may be used to tag contributions from different flavor jets [320, 321] but this does not provide sharp discrimination, due to flavor mixing in the fragmentation of light quark jets. The study of heavy quark jets offers cleaner flavor tagging. Recent studies have revealed observable features of heavy quark energy loss in medium that may provide significant new insight into the partonic energy loss mechanism [315, 316, 317, 318].

The formation time of gluon radiation off a heavy quark, measured with respect to the propagation of the heavy quark inside the medium, is reduced relative to a light quark because of the large quark mass. LPM interference should therefore be reduced significantly for heavy quarks at intermediate energy. In addition, the heavy quark mass suppresses the gluon radiation amplitude at angles smaller than the ratio of the quark mass to its energy [315]. Both mass effects will lead to different energy loss for a heavy relative to a light quark in a dense medium.

The mass dependence of the gluon radiation amplitude comes from the heavy quark prop-

agators. It suppresses the induced gluon spectrum for small angle radiation for a heavy quark relative to that of a light quark by a factor [317]

$$f_{Q/q} = \left[\frac{\ell_T^2}{\ell_T^2 + z^2 M^2}\right]^4 = \left[1 + \frac{\theta_0^2}{\theta^2}\right]^{-4}.$$
 (82)

Here  $\theta = \ell_T/q^-z$  and  $\theta_0 = M/q^-$  represent the radiation angle and the "dead-cone" within which the gluon radiation is suppressed. This suppression leads to a reduced radiative energy loss of a heavy quark. To illustrate the mass suppression of radiative energy loss imposed by the "dead-cone", the ratio  $\langle \Delta z_g^Q \rangle(x_B, Q^2)/\langle \Delta z_g^q \rangle(x_B, Q^2)$  of charm quark and light quark energy loss in DIS off a nucleus is plotted in Fig. 44, left panel, as functions of  $x_B$ .

Within the same framework of DIS off nuclei, the gluon formation time for radiation from a heavy quark

$$\tau_f \equiv \frac{1}{p^+ \tilde{x}_L} = \frac{2z(1-z)q^-}{\ell_T^2 + (1-z)^2 M^2},\tag{83}$$

is shorter than that for gluon radiation from a light quark, with significant consequences for heavy quark energy loss. Because of the quark mass dependence of the formation time relative to the nuclear size in the given frame,  $m_N R_A/\tau_f p^+ \sim x_B M^2/x_A Q^2$ , there are two distinct limiting behaviors of the energy loss for different values of  $x_B/Q^2$  relative to  $x_A/M^2$ . When  $x_B/Q^2 \gg x_A/M^2$  for small quark energy (large  $x_B$ ) or small  $Q^2$ , the formation time of gluon radiation off a heavy quark is smaller than the nuclear size. In this case, there is no destructive LPM interference. The heavy quark energy loss

$$\langle \Delta z_g^Q \rangle \sim C_A \frac{\tilde{C} \alpha_s^2}{N_c} \frac{x_B}{x_A Q^2}$$
 (84)

is linear in nuclear size  $R_A$ . In the opposite limit,  $x_B/Q^2 \ll x_A/M^2$ , for large quark energy (small  $x_B$ ) or large  $Q^2$ , the quark mass becomes negligible. The gluon formation time could still be much larger than the nuclear size. The LPM interference will limit the available phase space for gluon radiation and the heavy quark energy loss

$$\langle \Delta z_g^Q \rangle \sim C_A \frac{\tilde{C}\alpha_s^2}{N_c} \frac{x_B}{x_A^2 Q^2}$$
 (85)

now has a quadratic dependence on the nuclear size, similar to the light quark energy loss. Fig. 44, right panel, shows numerical results for the  $R_A$  dependence of charm quark energy loss rescaled by  $\tilde{C}(Q^2)C_A\alpha_s^2(Q^2)/N_C$ , for different values of  $x_B$  and  $Q^2$ . The  $R_A$  dependence is quadratic for large values of  $Q^2$  or small  $x_B$ , but becomes almost linear for small  $Q^2$  or large  $x_B$ . The charm quark mass is set at M=1.5 GeV in the numerical calculation.

Apparently, energy loss induced by gluon radiation is significantly suppressed for heavy relative to light quarks when the momentum scale Q or the quark initial energy  $q^-$  is not large compared to the quark mass. Only in the limit  $M \ll Q$ ,  $q^-$ , is the mass effect negligible and the heavy quark energy loss approaches that of a light quark. In the kinematic regime accessible at RHIC, the heavy quark energy loss will be much reduced relative to the light quarks and gluons. In addition, the mass effect is likely to reduce the effect of thermal absorption of gluons, whose average energy is much smaller than the heavy quark mass.

Heavy quark physics at top RHIC energy and design luminosity is studied primarily through charm production, due to the relatively low rate of beauty quark production. Several techniques

![](_page_75_Figure_0.jpeg)

<span id="page-75-0"></span>Figure 44: Left: The x<sup>B</sup> dependence of the ratio between charm quark and light quark energy loss in DIS off a heavy nucleus. Right: Dependence of charm quark energy loss on nuclear size RA, for different values of Q<sup>2</sup> and xB.

are available to study charm production directly and indirectly. Fig. [45,](#page-76-0) left panel, shows the spectrum of electrons from the semi-leptonic decay of D mesons in 130 GeV Au + Au collisions from PHENIX [\[322\]](#page-92-25), which provides an indirect measurement of the open charm meson spectrum. Preliminary non-photonic electron spectra from 200 GeV p + p, d + Au and Au + Au collisions have also been reported [\[323\]](#page-93-0). Within the current uncertainties the charm yield in all three systems appears to scale as the number of binary collisions, though the data are also consistent with small suppression at large p<sup>T</sup> in Au + Au.

Single electron spectra resulting from semi-leptonic decays are however rather insensitive to changes in the D-meson spectrum [\[324\]](#page-93-1) and more precise measurements of charm quark energy loss require direct measurement of fully reconstructed D decays into hadrons. STAR recently reported direct reconstruction of D-mesons in d + Au collisions. Fig. [45,](#page-76-0) right panel, shows a preliminary D meson spectrum constructed from various hadronic decay channels [\[325\]](#page-93-2). The spectrum is consistent with the single electron spectrum measured by the same experiment. Such measurements are considerably more demanding in Au + Au collisions but will provide direct study of the open charm production and the effect of heavy quark energy loss.

Parton recombination may also play a role in charm production. Such effects have already been shown to be significant in the forward direction for h+p collisions [\[267\]](#page-90-22). Since fragmentation functions are harder for heavy than light quarks, heavy quarks carry a large fraction of the heavy meson momentum in the wave-function, making it easier for a fast heavy quark (anti-quark) to pick up a slow light anti-quark (quark) to form a heavy meson. The recombination effect is therefore expected to be more significant for D mesons than light quark hadrons. As in the intermediate p<sup>T</sup> region of light hadron spectra, discrimination of the effects of partonic energy loss and parton recombination may be accomplished most clearly via azimuthal anisotropy of the D meson spectra. Some recombination models have predicted small but finite azimuthal anisotropy of the D meson spectra due to recombination with thermal light quarks [\[326\]](#page-93-3). This measurement is however very demanding and most likely requires upgrades to the present RHIC detectors.

![](_page_76_Figure_0.jpeg)

<span id="page-76-0"></span>Figure 45: Left: Non-photonic single electron spectra in Au + Au collisions at 130 GeV, from PHENIX [322]. Right: Spectra of fully reconstructed D meson spectra in d + Au collisions at 200 GeV from STAR [282].

#### Dihadron Fragmentation Functions and Angular Correlations

The suppression of single inclusive hadron spectra or the modification of the single hadron fragmentation function provide direct measurement of the gluon density of the dense medium. Broadening of the jet cone in principle could probe the average transverse momentum transfer to the jet parton, which can be used to directly estimate the energy density rather than the gluon density of the medium [327, 328]. Such a study may be possible using dihadron correlations. Dihadrons can result from the hadronization of a single leading parton or from two independent partons, one leading and the other a radiated gluon. The dihadron fragmentation or correlation function can therefore probe multiple scattering and induced gluon radiation in the medium. The first mechanism dominates when both hadrons carry a large fraction of the initial parton energy. This is likely the case for the same-side correlations measured by STAR (Fig. 28) and may explain why the correlation does not change despite the energy loss expected to be suffered by the leading parton. If the associated (secondary) hadron carries smaller fractional momentum it could come from radiated gluons. In this case the dihadron fragmentation function should be enhanced, as seen by a recent study of its evolution [288]. Due to the transverse momentum transfer from multiple scattering, the angular correlation between the hadrons should be also broadened. This is best seen by looking at the soft hadrons in a jet, though precision measurements of such observables are extremely challenging.

A first attempt to measure the radiated energy from the associated hadrons (Fig. 42) is seen in Fig. 46, left panel, which shows the integrated multiplicity and summed "scalar  $p_T$ " of hadrons within  $0.15 < p_T < 4 \text{ GeV}/c$  correlated with a trigger with  $p_T^{\text{trig}} > 4 \text{ GeV}/c$  [291]. The integration is performed over phase space broader than the normal jet size in vaccum, with "near-side" corresponding to  $|\Delta \phi| < 1.1$  and  $|\Delta \eta| < 1.4$  and "away-side" corresponding to  $|\Delta \phi| > 1.1$  and  $|\eta| < 1.1$ . Background yield is subtracted assuming that the correlated yield is negligible in the region  $0.9 < |\Delta \phi| < 1.3$ . The associated multiplicity and summed  $p_T$  above background show increases from p + p to Au + Au collisions qualitatively similar to the theoretical expectations from partonic energy loss, though the moderate trigger  $p_T$  makes direct comparison with such calculations difficult. Future analyses will increase the trigger  $p_T$  and reduce the systematic uncertainties associated with the background definition. Effects of parton recombination in the

![](_page_77_Figure_0.jpeg)

<span id="page-77-0"></span>Figure 46: Left: charged hadron multiplicity (upper) and total scalar  $p_T$  (lower) of the near and away-side dihadron distributions relative to a trigger hadron, integrated over broad  $(\Delta\eta,\Delta\phi)$  intervals for  $4 < p_T^{trig} < 6 \text{ GeV}/c$  and  $0.15 < p_T < 4 \text{ GeV}/c$  in p+p (open symbols) and Au+Au collisions, from STAR [291]. See text for details. Right: Charged hadron  $j_T$  distributions [Eq. (86)] from fully reconstructed jets in p+p collisions at  $\sqrt{s}$ =200 GeV from STAR [329], compared to simulations based on PYTHIA [330, 331]. The two distributions have different lower bounds on the hadron  $p_T$  relative to the beam axis.

jet structure must also be addressed in order to extract net effect of partonic energy loss.

#### Full jet reconstruction

As we have discussed extensively, the study of correlations among jet fragments on a statistical basis provides key observables for studying hard probes in collisions of heavy nuclei. Event-wise full jet reconstruction with good energy resolution is exceedingly difficult in all but perhaps the most peripheral collisions of heavy nuclei, due to the large multiplicity and the complexity of the underlying event. Standard jet reconstruction techniques can however be applied to collisions of simpler systems such as p + p and d + Au. Fig. [46,](#page-77-0) right panel, shows the preliminary results on the j<sup>T</sup> distribution in fully reconstructed jets in 200 GeV p + p collisions [\[329\]](#page-93-6), where j<sup>T</sup> is the component of hadron momentum perpendicular to the jet thrust axis:

<span id="page-78-1"></span>
$$j_T = \sqrt{p_h^2 - \left(\frac{p_h \cdot p_{jet}}{p_{jet}}\right)^2}. (86)$$

p<sup>h</sup> is the hadron momentum and pjet is the jet momentum. The jets are at mid-rapidity and have measured transverse energy hE<sup>T</sup> i ∼ 11 GeV. The figure shows comparison to PYTHIA-based simulations [\[330\]](#page-93-7) which describe the data well, including variations in the j<sup>T</sup> distribution due to variations of the lower limit of the hadron p<sup>T</sup> relative to the beam axis (the kinematic "seagull effect"). Aside from the importance of jets for studying QCD processes at RHIC energies, jet measurements in simpler systems at RHIC (potentially including the collisions of light nuclei) provide essential data-based calibrations of the more limited multi-hadron correlation observables that are accessible in the collisions of heavy nuclei [\[329\]](#page-93-6).

# <span id="page-78-0"></span>7 Summary

The Relativistic Heavy Ion Collider has initiated a new era in the study of QCD matter under extreme conditions. The RHIC accelerator has unprecedented flexibility for a collider, having generated significant integrated luminosity for Au + Au collisions at several energies as well as for polarized protons and the very important d + Au control experiment. The four RHIC experiments have produced a large body of high quality data. There is considerable overlap in their physics coverage and it is notable that the results are in agreement on all major physics points.

The data collected and analysed in the first three years of RHIC operations indicate that a dense, equilibrated system is generated briefly in the most violent, head-on collisions of heavy nuclei at top RHIC energies. The most economical explanation of the observed phenomena is that a state of matter dominated by colored (partonic) degrees of freedom has been produced, though direct observation of the deconfinement transition awaits further experimental and theoretical developments. For long wavelength excitations (low Q<sup>2</sup> or soft probes) the matter evidently responds as a near-ideal, strongly coupled fluid, while for short wavelength (high Q<sup>2</sup> ) probes it is highly dissipative. The medium is markedly different from the ideal non-interacting gas expected from QCD at asymptotically high temperature.

In this review we have presented only a limited subset of the available results, concentrating on the most mature measurements that directly address new phenomena. The evidence that a novel state of matter has been created is based on several lines of argument (see also [\[332\]](#page-93-9)):

- Collective behaviour: the broad success of hydrodynamic calculations in describing the inclusive spectra and azimuthal anisotropies of soft hadrons indicates that local thermal equilibrium is established at time τ<1 fm/c after the collision and that the matter expands as a near-ideal fluid.
- Partonic energy loss: the strong suppression of inclusive yields and correlations of high p<sup>T</sup> hadrons shows that high energy partons dissipate significant energy in the medium, providing direct evidence of strong interaction among partons that is essential to establish thermalization. The absence of high p<sup>T</sup> suppression in the d + Au control experiment confirms that the suppression is due to final state interactions in dense matter. Hadronic absorption calculations cannot account qualitatively for the systematic behavior of the phenomena, and the suppression agrees with a picture of partonic interactions with a medium having high color charge density.
- Energy density: the independent analyses of transverse energy production, hydrodynamic flow, and partonic energy loss result in a consistent estimate of the energy density early in the collision of 5-10 GeV/fm<sup>3</sup> , well beyond the critical value for transition to a deconfined phase expected from Lattice QCD.

Nevertheless, there remain important open questions. The mechanisms underlying the apparent very rapid thermalization are at present unclear. The role of finite viscosity, especially at the later hadronic stage of the expansion, remains to be fully understood. Most importantly, sensitivity to the Equation of State has not yet been systematically explored. New data are critical for addressing these issues, in particular more precise measurements of the low p<sup>T</sup> spectra and asymmetries of multistrange baryons and charmed mesons. New theoretical developments and systematic studies that are constrained by the broad range of data now available are likewise needed.

In the area of hard probes, striking effects have been observed but precision data in a larger p<sup>T</sup> range are needed to explore the detailed properties of jet quenching and their connection to other properties of the dense matter. The region 2<pT<6 GeV/c has significant contributions from non-perturbative processes, perhaps revealing novel hadronization mechanisms. However, all studies to date of azimuthal anisotropies and correlations of "jets" have by necessity been constrained to this region, with only the inclusive spectra extending well beyond the range where non-perturbative processes are seen to play a role. High statistics data sets for much higher p<sup>T</sup> hadrons are needed to fully exploit azimuthal asymmetries and correlations as measurements of partonic energy loss. Heavy quark suppression is theoretically well controlled, and measurement of it will provide a critical check on our understanding of partonic energy loss. The differential measurement of energy loss through measurement of the emerging away-side jet and the recovery of the energy radiated in soft hadrons is still in its initial phase of study. A complete mapping of the modified fragmentation with larger initial jet energy and with a direct photon trigger will cross check the energy dependence of energy loss extracted from single inclusive hadron suppression. Experiments at different colliding energies are also essential to reveal the onset of critical phenomena, or at the minimum to map the variation of jet quenching with initial energy density and the lifetime of the dense system.

Qualitatively new observables are also on the horizon. With accumulated luminosity increasing each year, measurements of J/ψ suppression in Au + Au collisions will become more quantitative and differential. Together with d+Au results and the open charm measurements it may be possible to disentangle final state suppression, initial state nuclear absorption, and possibly the contribution to J/ψ production from charm quark recombination in the dense medium [\[333,](#page-93-10) [334\]](#page-93-11). These measurements will provide an independent measurement of the initial conditions of the dense medium. Direct thermal photon emission from the plasma at intermediate p<sup>T</sup> could in principle provide direct measurement of the effective temperature or average parton energy of the interacting dense matter. Emission from the hadronic phase and photon production from perturbative hard processes form large backgrounds, however, making the extraction of the thermal photon yield from the QGP phase extremely difficult [\[47,](#page-82-13) [335\]](#page-93-12). Finally, experimental study of dilepton spectra in the low and intermediate mass region will provide vital information on the medium modification of vector mesons due to chiral symmetry restoration, as well as the thermal dilepton emission from the plasma phase.

There has been considerable recent interest in universal properties of QCD at very low Bjorken xBj [\[17\]](#page-81-10). Due to the non-Abelian nature of QCD, the gluon density in hadrons grows rapidly with decreasing xBj . However, the gluon self-interaction must eventually lead the gluon density to saturate. In the saturation region the system is dense but weakly coupled, controlled by the large saturation scale. This is a unique QCD regime, called the Color Glass Condensate (CGC). While arguments supporting the CGC are generic, the momentum scale at which it occurs must be fixed by measurements. CGC effects are expected to be amplified in heavy nuclei and evidence for them has been sought in RHIC data. The question at present is still open, but it is possible that the CGC is the underlying initial coherent state of partons in the nucleus from which the incoherent, thermalized QGP emerges following the collision. It has been suggested [\[262\]](#page-90-18) that measurements in the forward (d direction) region of d + Au collisions could provide a crucial test of saturation phenomena, in particular its spill-over to the large p<sup>T</sup> region, though that region is known to be susceptible to other non-perturbative effects. Measurements in the central rapidity region at LHC energies may provide clearer evidence of saturation phenomena.

# <span id="page-80-0"></span>8 Acknowledgements

We thank many colleagues for stimulating discussions and for providing many of the plots used in this review. We thank C. Gagliardi, R. Hwa, D. Kharzeev, C.-M. Ko, D. Magestro, A. Poskazner, I. Tserruya, R. Venugopalan, I. Vitev, and F.-Q. Wang for comments on the manuscript. This work was supported by the Director, Office of Energy Research, Office of High Energy and Nuclear Physics, Divisions of Nuclear Physics, of the U.S. Department of Energy under Contract No. DE-AC03-76SF00098 and DE-FG03-93ER40792.

# <span id="page-80-2"></span><span id="page-80-1"></span>References

- [1] T. D. Lee and G. C. Wick, Phys. Rev. D9, 2291 (1974).
- <span id="page-80-3"></span>[2] J. C. Collins and M. J. Perry, Phys. Rev. Lett. 34, 1353 (1975).
- <span id="page-80-4"></span>[3] G. Baym and S. A. Chin, Phys. Lett. B62, 241 (1976).
- <span id="page-80-5"></span>[4] F. Karsch, Nucl. Phys. A698, 199 (2002), hep-ph/0103314.
- <span id="page-80-6"></span>[5] E. V. Shuryak, Phys. Lett. B78, 150 (1978).
- [6] O. K. Kalashnikov and V. V. Klimov, Phys. Lett. B88, 328 (1979).

- <span id="page-81-1"></span><span id="page-81-0"></span>[7] J. I. Kapusta, Nucl. Phys. B148, 461 (1979).
- <span id="page-81-2"></span>[8] N. K. Glendenning, Phys. Rept. 342, 393 (2001).
- [9] H. G. Baumgardt et al., Z. Phys. A273, 359 (1975).
- <span id="page-81-4"></span><span id="page-81-3"></span>[10] S. Nagamiya and M. Gyulassy, Adv. Nucl. Phys. 13, 201 (1984).
- <span id="page-81-5"></span>[11] J. W. Harris and B. Muller, Ann. Rev. Nucl. Part. Sci. 46, 71 (1996), hep-ph/9602235.
- <span id="page-81-6"></span>[12] P. Giubellino, Nucl. Phys. A715, 441 (2003).
- <span id="page-81-7"></span>[13] U. W. Heinz and M. Jacob, (2000), nucl-th/0002042.
- <span id="page-81-8"></span>[14] H. Satz, Nucl. Phys. A715, 3 (2003), hep-ph/0209181.
- <span id="page-81-9"></span>[15] T. Alexopoulos et al., Phys. Lett. B528, 43 (2002), hep-ex/0201030.
- <span id="page-81-10"></span>[16] CERES, G. Agakishiev et al., Phys. Rev. Lett. 75, 1272 (1995).
- <span id="page-81-11"></span>[17] E. Iancu and R. Venugopalan, (2003), hep-ph/0303204.
- [18] H. Gutbrod et al., editors, Proceedings of Quark Matter 2002, , Nucl. Phys. No. A715, Elsevier, 2003.
- <span id="page-81-13"></span><span id="page-81-12"></span>[19] H. G. Ritter and X. N. Wang, editors, Proceedings of Quark Matter 2004 (Institute of Physics, 2004).
- <span id="page-81-14"></span>[20] D. J. Gross and F. Wilczek, Phys. Rev. Lett. 30, 1343 (1973).
- <span id="page-81-15"></span>[21] H. D. Politzer, Phys. Rept. 14, 129 (1974).
- <span id="page-81-16"></span>[22] S. Bethke, J. Phys. G26, R27 (2000), hep-ex/0004021.
- <span id="page-81-17"></span>[23] M. Creutz, Phys. Rev. D21, 2308 (1980).
- <span id="page-81-19"></span>[24] S. Necco and R. Sommer, Nucl. Phys. B622, 328 (2002), hep-lat/0108008.
- <span id="page-81-20"></span>[25] M. A. Shifman, A. I. Vainshtein, and V. I. Zakharov, Nucl. Phys. B147, 385 (1979).
- <span id="page-81-18"></span>[26] A. Chodos, R. L. Jaffe, K. Johnson, and C. B. Thorn, Phys. Rev. D10, 2599 (1974).
- <span id="page-81-21"></span>[27] Z. Fodor, Nucl. Phys. A715, 319 (2003), hep-lat/0209101.
- <span id="page-81-22"></span>[28] P. Arnold and C.-X. Zhai, Phys. Rev. D50, 7603 (1994), hep-ph/9408276.
- <span id="page-81-23"></span>[29] E. Braaten and R. D. Pisarski, Nucl. Phys. B337, 569 (1990).
- <span id="page-81-24"></span>[30] J. P. Blaizot, E. Iancu, and A. Rebhan, Phys. Lett. B470, 181 (1999), hep-ph/9910309.
- <span id="page-81-25"></span>[31] F. Karsch, E. Laermann, and A. Peikert, Nucl. Phys. B605, 579 (2001), hep-lat/0012023.
- <span id="page-81-26"></span>[32] T. Matsui and H. Satz, Phys. Lett. B178, 416 (1986).
- [33] S. G. Matinyan and B. Muller, Phys. Rev. C58, 2994 (1998), nucl-th/9806027.

- <span id="page-82-1"></span><span id="page-82-0"></span>[34] K. L. Haglin, Phys. Rev. C61, 031902 (2000), nucl-th/9907034.
- <span id="page-82-2"></span>[35] Z.-W. Lin and C. M. Ko, Phys. Rev. C62, 034903 (2000), nucl-th/9912046.
- <span id="page-82-3"></span>[36] Z. Fodor, S. D. Katz, and K. K. Szabo, Phys. Lett. B568, 73 (2003), hep-lat/0208078.
- <span id="page-82-4"></span>[37] C. R. Allton et al., Phys. Rev. D68, 014507 (2003), hep-lat/0305007.
- [38] M. G. Alford, K. Rajagopal, and F. Wilczek, Phys. Lett. B422, 247 (1998), hepph/9711395.
- <span id="page-82-6"></span><span id="page-82-5"></span>[39] R. Rapp, T. Schafer, E. V. Shuryak, and M. Velkovsky, Phys. Rev. Lett. 81, 53 (1998), hep-ph/9711396.
- [40] M. G. Alford, K. Rajagopal, and F. Wilczek, Nucl. Phys. B537, 443 (1999), hepph/9804403.
- <span id="page-82-8"></span><span id="page-82-7"></span>[41] T. Schafer and E. V. Shuryak, Rev. Mod. Phys. 70, 323 (1998), hep-ph/9610451.
- <span id="page-82-9"></span>[42] J. Gasser and H. Leutwyler, Phys. Lett. B184, 83 (1987).
- <span id="page-82-10"></span>[43] J. Kapusta, D. Kharzeev, and L. D. McLerran, Phys. Rev. D53, 5028 (1996), hepph/9507343.
- <span id="page-82-11"></span>[44] Z. Huang and X.-N. Wang, Phys. Rev. D53, 5034 (1996), hep-ph/9507395.
- <span id="page-82-12"></span>[45] K. Rajagopal and F. Wilczek, Nucl. Phys. B404, 577 (1993), hep-ph/9303281.
- [46] M. Asakawa, Z. Huang, and X.-N. Wang, Phys. Rev. Lett. 74, 3126 (1995), hepph/9408299.
- <span id="page-82-14"></span><span id="page-82-13"></span>[47] R. Rapp and J. Wambach, Adv. Nucl. Phys. 25, 1 (2000), hep-ph/9909229.
- <span id="page-82-15"></span>[48] Y. L. Dokshitzer, D. Diakonov, and S. I. Troian, Phys. Rept. 58, 269 (1980).
- <span id="page-82-16"></span>[49] A. H. Mueller, Phys. Rept. 73, 237 (1981).
- <span id="page-82-17"></span>[50] J. C. Collins, D. E. Soper, and G. Sterman, Nucl. Phys. B261, 104 (1985).
- <span id="page-82-18"></span>[51] V. N. Gribov and L. N. Lipatov, Yad. Fiz. 15, 781 (1972).
- <span id="page-82-19"></span>[52] Y. L. Dokshitzer, Sov. Phys. JETP 46, 641 (1977).
- <span id="page-82-20"></span>[53] G. Altarelli and G. Parisi, Nucl. Phys. B126, 298 (1977).
- <span id="page-82-21"></span>[54] M. Harrison, T. Ludlam, and S. Ozaki, Nucl. Instr. Meth. A499 (2003).
- <span id="page-82-22"></span>[55] Y. S. Derbenev et al., Part. Accel. 8, 115 (1978).
- <span id="page-82-23"></span>[56] J. S. G. Bunce, N. Saito and W. Vogelsang, Ann.Rev.Nucl.Part.Sci. 50 (2000).
- [57] L. C. Bland, in AIP Conf. Proc., edited by A. L. Y. Makdisi and W. MacKay Vol. 675, p. 98, 2003.
- <span id="page-82-24"></span>[58] H. Hahn et al., Nucl. Instr. Meth. A499 (2003).

- <span id="page-83-1"></span><span id="page-83-0"></span>[59] C. Adler et al., Nucl. Instrum. Meth. A470, 488 (2001), nucl-ex/0008005.
- <span id="page-83-2"></span>[60] S. van der Meer, ISR-PO/68-31, KEK68-64.
- <span id="page-83-3"></span>[61] A. Drees and Z. Xu, in Proceedings of PAC2001, Chicago, Illinois, IEEE, 2001.
- <span id="page-83-4"></span>[62] K. Adcox et al., Nucl. Instr. Meth. A499 (2003).
- <span id="page-83-5"></span>[63] K. H. Ackermann et al., Nucl. Instr. Meth. A499 (2003).
- <span id="page-83-6"></span>[64] BRAHMS, M. Adamczyk et al., Nucl. Instr. Meth. A499 (2003).
- <span id="page-83-7"></span>[65] PHOBOS, B. B. Back et al., Nucl. Instr. Meth. A499 (2003).
- <span id="page-83-8"></span>[66] R. J. GlauberLectures in Theoretical Physics Vol. 1 (Interscience, New York, 1959), .
- <span id="page-83-9"></span>[67] NA50, B. Alessandro et al., Phys. Lett. B553, 167 (2003).
- <span id="page-83-10"></span>[68] NA49, H. Appelshauser et al., Phys. Rev. Lett. 82, 2471 (1999), nucl-ex/9810014.
- <span id="page-83-11"></span>[69] A. Bialas, M. Bleszynski, and W. Czyz, Nucl. Phys. B111, 461 (1976).
- <span id="page-83-12"></span>[70] X.-N. Wang and M. Gyulassy, Phys. Rev. D44, 3501 (1991).
- <span id="page-83-13"></span>[71] M. Gyulassy and X.-N. Wang, Comput. Phys. Commun. 83, 307 (1994), nucl-th/9502021.
- <span id="page-83-14"></span>[72] H. d. C. W. deJager and C. deVries, Atomic Data and Nuclear Data Tables 14 (1974).
- <span id="page-83-15"></span>[73] STAR, J. Adams et al., (2003), nucl-ex/0311017.
- <span id="page-83-16"></span>[74] STAR, J. Adams et al., Phys. Rev. Lett. 91, 072304 (2003), nucl-ex/0306024.
- <span id="page-83-17"></span>[75] UA5, R. E. Ansorge et al., Z. Phys. C43, 357 (1989).
- <span id="page-83-18"></span>[76] PHENIX, S. S. Adler et al., Phys. Rev. C69, 034909 (2004), nucl-ex/0307022.
- <span id="page-83-19"></span>[77] STAR, K. H. Ackermann et al., Phys. Rev. Lett. 86, 402 (2001), nucl-ex/0009011.
- <span id="page-83-20"></span>[78] R. Vogt, Heavy Ion Phys. 9, 339 (1999), nucl-th/9903051.
- <span id="page-83-21"></span>[79] R. Snellings, nucl-ex/0310019.
- <span id="page-83-22"></span>[80] S. A. Bass et al., Nucl. Phys. A661, 205 (1999), nucl-th/9907090.
- [81] K. J. Eskola, K. Kajantie, P. V. Ruuskanen, and K. Tuominen, Nucl. Phys. B570, 379 (2000), hep-ph/9909456.
- <span id="page-83-24"></span><span id="page-83-23"></span>[82] K. Geiger and B. Muller, Nucl. Phys. B369, 600 (1992).
- <span id="page-83-25"></span>[83] L. D. McLerran and R. Venugopalan, Phys. Rev. D49, 2233 (1994), hep-ph/9309289.
- <span id="page-83-26"></span>[84] PHOBOS, B. B. Back et al., Phys. Rev. Lett. 85, 3100 (2000), hep-ex/0007036.
- <span id="page-83-27"></span>[85] D. Kharzeev and E. Levin, Phys. Lett. B523, 79 (2001), nucl-th/0108006.
- [86] T. K. Gaisser and F. Halzen, Phys. Rev. Lett. 54, 1754 (1985).

- <span id="page-84-1"></span><span id="page-84-0"></span>[87] X.-N. Wang, Phys. Rev. D43, 104 (1991).
- <span id="page-84-2"></span>[88] D. W. Duke and J. F. Owens, Phys. Rev. D30, 49 (1984).
- <span id="page-84-3"></span>[89] X.-N. Wang, Phys. Rev. C61, 064910 (2000), nucl-th/9812021.
- <span id="page-84-4"></span>[90] X.-N. Wang and M. Gyulassy, Phys. Rev. Lett. 86, 3496 (2001), nucl-th/0008014.
- <span id="page-84-5"></span>[91] D. Kharzeev and M. Nardi, Phys. Lett. B507, 121 (2001), nucl-th/0012025.
- <span id="page-84-6"></span>[92] Z. Lin and C. M. Ko, Phys. Rev. C68, 054904 (2003), nucl-th/0301025.
- [93] K. J. Eskola, K. Kajantie, and K. Tuominen, Phys. Lett. B497, 39 (2001), hepph/0009246.
- <span id="page-84-8"></span><span id="page-84-7"></span>[94] L. V. Gribov, E. M. Levin, and M. G. Ryskin, Phys. Rept. 100, 1 (1983).
- <span id="page-84-9"></span>[95] A. H. Mueller and J. Qiu, Nucl. Phys. B268, 427 (1986).
- <span id="page-84-10"></span>[96] Z. Huang, H. J. Lu, and I. Sarcevic, Nucl. Phys. A637, 79 (1998), hep-ph/9705250.
- <span id="page-84-11"></span>[97] L. D. McLerran and R. Venugopalan, Phys. Rev. D49, 3352 (1994), hep-ph/9311205.
- [98] A. M. Stasto, K. Golec-Biernat, and J. Kwiecinski, Phys. Rev. Lett. 86, 596 (2001), hep-ph/0007192.
- <span id="page-84-12"></span>[99] A. H. Mueller, Nucl. Phys. B572, 227 (2000), hep-ph/9906322.
- <span id="page-84-14"></span><span id="page-84-13"></span>[100] A. Krasnitz and R. Venugopalan, Phys. Rev. Lett. 86, 1717 (2001), hep-ph/0007108.
- <span id="page-84-15"></span>[101] PHOBOS, B. B. Back et al., Phys. Rev. Lett. 88, 022302 (2002), nucl-ex/0108009.
- <span id="page-84-16"></span>[102] S. Li and X.-N. Wang, Phys. Lett. B527, 85 (2002), nucl-th/0110075.
- <span id="page-84-17"></span>[103] PHOBOS, B. B. Back et al., Phys. Rev. C65, 061901 (2002), nucl-ex/0201005.
- <span id="page-84-18"></span>[104] PHENIX, K. Adcox et al., Phys. Rev. Lett. 86, 3500 (2001), nucl-ex/0012008.
- <span id="page-84-19"></span>[105] UA5, G. J. Alner et al., Z. Phys. C33, 1 (1986).
- <span id="page-84-20"></span>[106] W. Thome et al., Nucl. Phys. B129, 365 (1977).
- <span id="page-84-21"></span>[107] PHOBOS, B. B. Back et al., Phys. Rev. Lett. 91, 052303 (2003), nucl-ex/0210015.
- <span id="page-84-22"></span>[108] BRAHMS, I. G. Bearden et al., Phys. Rev. Lett. 88, 202301 (2002), nucl-ex/0112001.
- <span id="page-84-23"></span>[109] PHOBOS, B. B. Back et al., (2003), nucl-ex/0311009.
- <span id="page-84-24"></span>[110] BRAHMS, I. Arsene, (2004), nucl-ex/0401025.
- <span id="page-84-25"></span>[111] D. Kharzeev, E. Levin, and M. Nardi, Nucl. Phys. A730, 448 (2004), hep-ph/0212316.
- <span id="page-84-26"></span>[112] J. D. Bjorken, Phys. Rev. D27, 140 (1983).
- [113] P. F. Kolb and U. Heinz, nucl-th/0305084.

- <span id="page-85-4"></span><span id="page-85-3"></span>[114] K. Morita, S. Muroya, C. Nonaka, and T. Hirano, Phys. Rev. C66, 054904 (2002), nuclth/0205040.
- <span id="page-85-5"></span>[115] J. Sollfrank et al., Phys. Rev. C55, 392 (1997), nucl-th/9607029.
- [116] K. J. Eskola, K. Kajantie, and P. V. Ruuskanen, Eur. Phys. J. C1, 627 (1998), nuclth/9705015.
- <span id="page-85-1"></span><span id="page-85-0"></span>[117] BRAHMS, M. Murray, nucl-ex/0404007.
- <span id="page-85-2"></span>[118] BRAHMS, I. G. Bearden et al., nucl-ex/0312023.
- <span id="page-85-6"></span>[119] BRAHMS, I. G. Bearden, nucl-ex/0403050.
- <span id="page-85-7"></span>[120] STAR, C. Adler et al., Phys. Rev. Lett. 87, 262302 (2001), nucl-ex/0110009.
- <span id="page-85-8"></span>[121] W. Busza and A. S. Goldhaber, Phys. Lett. B139, 235 (1984).
- <span id="page-85-9"></span>[122] B. Andersson, G. Gustafson, and B. Nilsson-Almqvist, Nucl. Phys. B281, 289 (1987).
- <span id="page-85-10"></span>[123] V. Topor Pop et al., Phys. Rev. C52, 1618 (1995), nucl-th/9504003.
- <span id="page-85-11"></span>[124] V. Topor Pop et al., Phys. Rev. C68, 054902 (2003), nucl-th/0209089.
- <span id="page-85-12"></span>[125] D. Kharzeev, Phys. Lett. B378, 238 (1996), nucl-th/9602027.
- <span id="page-85-13"></span>[126] L. Montanet, G. C. Rossi, and G. Veneziano, Phys. Rept. 63, 149 (1980).
- <span id="page-85-14"></span>[127] S. E. Vance, M. Gyulassy, and X. N. Wang, Phys. Lett. B443, 45 (1998), nucl-th/9806008.
- <span id="page-85-15"></span>[128] K. Werner, Phys. Rept. 232, 87 (1993).
- <span id="page-85-16"></span>[129] A. Capella and B. Z. Kopeliovich, Phys. Lett. B381, 325 (1996), hep-ph/9603279.
- <span id="page-85-17"></span>[130] H. Sorge, Phys. Rev. C52, 3291 (1995), nucl-th/9509007.
- <span id="page-85-18"></span>[131] S. A. Bass et al., Prog. Part. Nucl. Phys. 41, 225 (1998), nucl-th/9803035.
- <span id="page-85-19"></span>[132] M. Gyulassy and T. Matsui, Phys. Rev. D29, 419 (1984).
- <span id="page-85-20"></span>[133] A. Dumitru and M. Gyulassy, Phys. Lett. B494, 215 (2000), hep-ph/0006257.
- <span id="page-85-21"></span>[134] PHENIX, K. Adcox et al., Phys. Rev. Lett. 87, 052301 (2001), nucl-ex/0104015.
- <span id="page-85-22"></span>[135] WA98, M. M. Aggarwal et al., Eur. Phys. J. C18, 651 (2001), nucl-ex/0008004.
- <span id="page-85-23"></span>[136] UA1, C. Albajar et al., Nucl. Phys. B335, 261 (1990).
- <span id="page-85-24"></span>[137] NA49, S. Margetis et al., Phys. Rev. Lett. 75, 3814 (1995).
- <span id="page-85-25"></span>[138] S. Z. Belenkij and L. D. Landau, Nuovo Cim. Suppl. 3S10, 15 (1956).
- <span id="page-85-26"></span>[139] P. Huovinen, nucl-th/0305064.
- [140] D. Teaney, Phys. Rev. C68, 034913 (2003).

- <span id="page-86-1"></span><span id="page-86-0"></span>[141] T. Hirano and Y. Nara, nucl-th/0404039.
- <span id="page-86-3"></span>[142] F. Cooper and G. Frye, Phys. Rev. D10, 186 (1974).
- <span id="page-86-4"></span>[143] T. Hirano and K. Tsuda, Phys. Rev. C66, 054905 (2002), nucl-th/0205043.
- <span id="page-86-2"></span>[144] S. A. Bass et al., Phys. Rev. C60, 021902 (1999), nucl-th/9902062.
- <span id="page-86-5"></span>[145] D. Teaney, J. Lauret, and E. V. Shuryak, nucl-th/0110037.
- <span id="page-86-6"></span>[146] STAR, J. Adams et al., Phys. Rev. Lett. 92, 052302 (2004), nucl-ex/0306007.
- <span id="page-86-7"></span>[147] P. R. Sorensen, PhD thesis, UCLA, 2003, nucl-ex/0309003.
- <span id="page-86-8"></span>[148] U. W. Heinz and P. F. Kolb, hep-ph/0204061.
- <span id="page-86-9"></span>[149] PHENIX, K. Adcox et al., Phys. Rev. Lett. 88, 242301 (2002), nucl-ex/0112006.
- <span id="page-86-10"></span>[150] M. Calderon de la Barca Sanchez, PhD thesis, Yale University, 2001, nucl-ex/0111004.
- <span id="page-86-11"></span>[151] STAR, C. Suire, Nucl. Phys. A715, 470 (2003), nucl-ex/0211017.
- <span id="page-86-12"></span>[152] P. F. Kolb and R. Rapp, Phys. Rev. C67, 044903 (2003), hep-ph/0210222.
- <span id="page-86-13"></span>[153] H. van Hecke, H. Sorge, and N. Xu, Phys. Rev. Lett. 81, 5764 (1998), nucl-th/9804035.
- <span id="page-86-14"></span>[154] P. J. Siemens and J. O. Rasmussen, Phys. Rev. Lett. 42, 880 (1979).
- [155] E. Schnedermann, J. Sollfrank, and U. W. Heinz, Phys. Rev. C48, 2462 (1993), nuclth/9307020.
- <span id="page-86-16"></span><span id="page-86-15"></span>[156] PHENIX, K. Adcox et al., Phys. Rev. C69, 024904 (2004), nucl-ex/0307010.
- <span id="page-86-17"></span>[157] P. F. Kolb, P. Huovinen, U. W. Heinz, and H. Heiselberg, Phys. Lett. B500, 232 (2001), hep-ph/0012137.
- <span id="page-86-18"></span>[158] A. M. Poskanzer and S. A. Voloshin, Phys. Rev. C58, 1671 (1998), nucl-ex/9805001.
- <span id="page-86-19"></span>[159] P. F. Kolb and U. Heinz, Nucl. Phys. A715, 653 (2003), nucl-th/0208047.
- <span id="page-86-20"></span>[160] H. Sorge, Phys. Rev. Lett. 78, 2309 (1997), nucl-th/9610026.
- <span id="page-86-21"></span>[161] B. Zhang, M. Gyulassy, and C. M. Ko, Phys. Lett. B455, 45 (1999), nucl-th/9902016.
- <span id="page-86-22"></span>[162] J.-Y. Ollitrault, Phys. Rev. D46, 229 (1992).
- <span id="page-86-23"></span>[163] STAR, C. Adler et al., Phys. Rev. Lett. 87, 182301 (2001), nucl-ex/0107003.
- <span id="page-86-24"></span>[164] P. Huovinen, P. F. Kolb, U. W. Heinz, P. V. Ruuskanen, and S. A. Voloshin, Phys. Lett. B503, 58 (2001), hep-ph/0101136.
- <span id="page-86-25"></span>[165] PHOBOS, B. B. Back et al., Phys. Rev. Lett. 89, 222301 (2002), nucl-ex/0205021.
- [166] PHOBOS, B. B. Back et al., nucl-ex/0406021.

- <span id="page-87-1"></span><span id="page-87-0"></span>[167] T. Hirano, Phys. Rev. C65, 011901 (2002), nucl-th/0108004.
- [168] E. E. Zabrodin, C. Fuchs, L. V. Bravina, and A. Faessler, Phys. Lett. B508, 184 (2001), nucl-th/0104054.
- <span id="page-87-5"></span><span id="page-87-4"></span>[169] F. Becattini, M. Gazdzicki, and J. Sollfrank, Eur. Phys. J. C5, 143 (1998), hepph/9710529.
- [170] F. Becattini, J. Cleymans, A. Keranen, E. Suhonen, and K. Redlich, Phys. Rev. C64, 024901 (2001), hep-ph/0002267.
- <span id="page-87-6"></span><span id="page-87-2"></span>[171] P. Braun-Munzinger, D. Magestro, K. Redlich, and J. Stachel, Phys. Lett. B518, 41 (2001), hep-ph/0105229.
- <span id="page-87-3"></span>[172] D. Magestro, J. Phys. G28, 1745 (2002), hep-ph/0112178.
- <span id="page-87-7"></span>[173] P. Braun-Munzinger, K. Redlich, and J. Stachel, nucl-th/0304013.
- <span id="page-87-8"></span>[174] V. Koch, Nucl. Phys. A715, 108 (2003), nucl-th/0210070.
- <span id="page-87-9"></span>[175] F. Becattini, A. Giovannini, and S. Lupia, Z. Phys. C72, 491 (1996), hep-ph/9511203.
- <span id="page-87-10"></span>[176] F. Becattini and U. W. Heinz, Z. Phys. C76, 269 (1997), hep-ph/9702274.
- <span id="page-87-11"></span>[177] A. Majumder and V. Koch, Phys. Rev. C68, 044903 (2003), nucl-th/0305047.
- <span id="page-87-12"></span>[178] S. Jeon and V. Koch, hep-ph/0304012.
- <span id="page-87-13"></span>[179] D. H. Rischke and M. Gyulassy, Nucl. Phys. A608, 479 (1996), nucl-th/9606039.
- <span id="page-87-14"></span>[180] R. Hanbury Brown and R. Q. Twiss, Nature 178, 1046 (1956).
- <span id="page-87-15"></span>[181] G. Goldhaber, S. Goldhaber, W.-Y. Lee, and A. Pais, Phys. Rev. 120, 300 (1960).
- <span id="page-87-16"></span>[182] U. W. Heinz and B. V. Jacak, Ann. Rev. Nucl. Part. Sci. 49, 529 (1999), nucl-th/9902020.
- <span id="page-87-17"></span>[183] B. Tomasik and U. A. Wiedemann, (2002), hep-ph/0210250.
- <span id="page-87-18"></span>[184] G. I. Kopylov, Phys. Lett. B50, 472 (1974).
- <span id="page-87-19"></span>[185] M. I. Podgoretsky, Sov. J. Nucl. Phys. 37, 272 (1983).
- <span id="page-87-20"></span>[186] S. Pratt, Phys. Rev. Lett. 53, 1219 (1984).
- <span id="page-87-21"></span>[187] G. Bertsch, M. Gong, and M. Tohyama, Phys. Rev. C37, 1896 (1988).
- <span id="page-87-22"></span>[188] S. V. Akkelin and Y. M. Sinyukov, Phys. Lett. B356, 525 (1995).
- <span id="page-87-23"></span>[189] A. N. Makhlin and Y. M. Sinyukov, Z. Phys. C39, 69 (1988).
- [190] U. A. Wiedemann, P. Scotto, and U. W. Heinz, Phys. Rev. C53, 918 (1996), nuclth/9508040.
- <span id="page-87-24"></span>[191] STAR, C. Adler et al., Phys. Rev. Lett. 87, 082301 (2001), nucl-ex/0107008.

- <span id="page-88-1"></span><span id="page-88-0"></span>[192] PHENIX, K. Adcox et al., Phys. Rev. Lett. 88, 192302 (2002), nucl-ex/0201008.
- <span id="page-88-2"></span>[193] PHENIX, S. S. Adler et al., nucl-ex/0401003.
- <span id="page-88-3"></span>[194] Z. W. Lin, C. M. Ko, and S. Pal, Phys. Rev. Lett. 89, 152301 (2002), nucl-th/0204054.
- <span id="page-88-4"></span>[195] U. A. Wiedemann, Phys. Rev. C57, 266 (1998), nucl-th/9707046.
- [196] U. W. Heinz, A. Hummel, M. A. Lisa, and U. A. Wiedemann, Phys. Rev. C66, 044903 (2002), nucl-th/0207003.
- <span id="page-88-6"></span><span id="page-88-5"></span>[197] STAR, J. Adams et al., nucl-ex/0312009.
- <span id="page-88-7"></span>[198] A. D. Martin, R. G. Roberts, W. J. Stirling, and R. S. Thorne, Eur. Phys. J. C23, 73 (2002), hep-ph/0110215.
- <span id="page-88-8"></span>[199] J. Pumplin et al., JHEP 07, 012 (2002), hep-ph/0201195.
- <span id="page-88-9"></span>[200] L. D. McLerran and T. Toimela, Phys. Rev. D31, 545 (1985).
- <span id="page-88-10"></span>[201] M. Gyulassy and M. Plumer, Phys. Lett. B243, 432 (1990).
- <span id="page-88-11"></span>[202] X.-N. Wang and M. Gyulassy, Phys. Rev. Lett. 68, 1480 (1992).
- <span id="page-88-12"></span>[203] WA98, M. M. Aggarwal et al., Phys. Rev. Lett. 85, 3595 (2000), nucl-ex/0006008.
- [204] C. M. Ko, V. Koch, and G.-Q. Li, Ann. Rev. Nucl. Part. Sci. 47, 505 (1997), nuclth/9702016.
- <span id="page-88-17"></span><span id="page-88-13"></span>[205] R. Vogt, Phys. Rept. 310, 197 (1999).
- <span id="page-88-18"></span>[206] X.-N. Wang, Phys. Rept. 280, 287 (1997), hep-ph/9605214.
- <span id="page-88-14"></span>[207] M. H. Thoma and M. Gyulassy, Nucl. Phys. B351, 491 (1991).
- <span id="page-88-15"></span>[208] BRAHMS, I. Arsene et al., Phys. Rev. Lett. 91, 072305 (2003), nucl-ex/0307003.
- <span id="page-88-16"></span>[209] PHENIX, S. S. Adler et al., Phys. Rev. Lett. 91, 072303 (2003), nucl-ex/0306021.
- <span id="page-88-19"></span>[210] PHOBOS, B. B. Back et al., Phys. Rev. Lett. 91, 072302 (2003), nucl-ex/0306025.
- <span id="page-88-20"></span>[211] S. J. Brodsky and P. Hoyer, Phys. Lett. B298, 165 (1993), hep-ph/9210262.
- <span id="page-88-21"></span>[212] M. Gyulassy and X.-N. Wang, Nucl. Phys. B420, 583 (1994), nucl-th/9306003.
- <span id="page-88-22"></span>[213] X.-N. Wang, M. Gyulassy, and M. Plumer, Phys. Rev. D51, 3436 (1995), hep-ph/9408344.
- <span id="page-88-23"></span>[214] L. D. Landau and I. Pomeranchuk, Dokl. Akad. Nauk Ser. Fiz. 92, 535 (1953).
- <span id="page-88-24"></span>[215] A. B. Migdal, Phys. Rev. 103, 1811 (1956).
- [216] R. Baier, Y. L. Dokshitzer, S. Peigne, and D. Schiff, Phys. Lett. B345, 277 (1995), hep-ph/9411409.
- <span id="page-88-25"></span>[217] B. G. Zakharov, JETP Lett. 63, 952 (1996), hep-ph/9607440.

- <span id="page-89-3"></span><span id="page-89-2"></span>[218] M. Gyulassy, P. Levai, and I. Vitev, Phys. Rev. Lett. 85, 5535 (2000), nucl-th/0005032.
- <span id="page-89-4"></span>[219] M. Gyulassy, P. Levai, and I. Vitev, Nucl. Phys. B594, 371 (2001), nucl-th/0006010.
- <span id="page-89-5"></span>[220] U. A. Wiedemann, Nucl. Phys. B588, 303 (2000), hep-ph/0005129.
- <span id="page-89-6"></span>[221] X.-F. Guo and X.-N. Wang, Phys. Rev. Lett. 85, 3591 (2000), hep-ph/0005044.
- <span id="page-89-0"></span>[222] X.-N. Wang and X.-F. Guo, Nucl. Phys. A696, 788 (2001), hep-ph/0102230.
- <span id="page-89-1"></span>[223] STAR, C. Adler et al., Phys. Rev. Lett. 90, 082302 (2003), nucl-ex/0210033.
- <span id="page-89-7"></span>[224] STAR, A. Tang, AIP Conf. Proc. 698, 701 (2004), nucl-ex/0308020.
- <span id="page-89-8"></span>[225] B.-W. Zhang and X.-N. Wang, Nucl. Phys. A720, 429 (2003), hep-ph/0301195.
- <span id="page-89-9"></span>[226] M. Luo, J. Qiu, and G. Sterman, Phys. Lett. B279, 377 (1992).
- <span id="page-89-10"></span>[227] M. Luo, J. Qiu, and G. Sterman, Phys. Rev. D49, 4493 (1994).
- <span id="page-89-11"></span>[228] M. Luo, J. Qiu, and G. Sterman, Phys. Rev. D50, 1951 (1994).
- <span id="page-89-12"></span>[229] J. Osborne and X.-N. Wang, Nucl. Phys. A710, 281 (2002), hep-ph/0204046.
- <span id="page-89-13"></span>[230] HERMES, A. Airapetian et al., Eur. Phys. J. C20, 479 (2001), hep-ex/0012049.
- <span id="page-89-14"></span>[231] HERMES, V. Muccifora, Nucl. Phys. A715, 506 (2003), hep-ex/0106088.
- <span id="page-89-15"></span>[232] B. Z. Kopeliovich, Phys. Lett. B243, 141 (1990).
- <span id="page-89-16"></span>[233] T. Falter, W. Cassing, K. Gallmeister, and U. Mosel, (2003), nucl-th/0303011.
- [234] R. Baier, Y. L. Dokshitzer, A. H. Mueller, S. Peigne, and D. Schiff, Nucl. Phys. B484, 265 (1997), hep-ph/9608322.
- <span id="page-89-18"></span><span id="page-89-17"></span>[235] E. Wang and X.-N. Wang, Phys. Rev. Lett. 89, 162301 (2002), hep-ph/0202105.
- <span id="page-89-19"></span>[236] M. Gyulassy, I. Vitev, and X.-N. Wang, Phys. Rev. Lett. 86, 2537 (2001), nucl-th/0012092.
- <span id="page-89-20"></span>[237] C. A. Salgado and U. A. Wiedemann, Phys. Rev. Lett. 89, 092303 (2002), hep-ph/0204221.
- <span id="page-89-21"></span>[238] X.-N. Wang, Z. Huang, and I. Sarcevic, Phys. Rev. Lett. 77, 231 (1996), hep-ph/9605213.
- <span id="page-89-22"></span>[239] X.-N. Wang and Z. Huang, Phys. Rev. C55, 3047 (1997), hep-ph/9701227.
- <span id="page-89-23"></span>[240] J. Binnewies, B. A. Kniehl, and G. Kramer, Z. Phys. C65, 471 (1995), hep-ph/9407347.
- <span id="page-89-24"></span>[241] E. Wang and X.-N. Wang, Phys. Rev. Lett. 87, 142301 (2001), nucl-th/0106043.
- <span id="page-89-25"></span>[242] J. F. Owens, Rev. Mod. Phys. 59, 465 (1987).
- [243] A. D. Martin, R. G. Roberts, W. J. Stirling, and R. S. Thorne, Eur. Phys. J. C4, 463 (1998), hep-ph/9803445.
- <span id="page-89-26"></span>[244] S. Catani, M. L. Mangano, P. Nason, C. Oleari, and W. Vogelsang, JHEP 03, 025 (1999), hep-ph/9903436.

- <span id="page-90-1"></span><span id="page-90-0"></span>[245] K. J. Eskola and H. Honkanen, Nucl. Phys. A713, 167 (2003), hep-ph/0205048.
- <span id="page-90-2"></span>[246] A. Accardi et al., hep-ph/0310274.
- <span id="page-90-3"></span>[247] UA1, C. Albajar et al., Nucl. Phys. B335, 261 (1990).
- <span id="page-90-4"></span>[248] CDF, F. Abe et al., Phys. Rev. Lett. 61, 1819 (1988).
- <span id="page-90-5"></span>[249] PHENIX, S. S. Adler et al., Phys. Rev. Lett. 91, 241803 (2003), hep-ex/0304038.
- <span id="page-90-6"></span>[250] K. J. Eskola, V. J. Kolhinen, and C. A. Salgado, Eur. Phys. J. C9, 61 (1999), hepph/9807297.
- <span id="page-90-7"></span>[251] M. Hirai, S. Kumano, and M. Miyama, Phys. Rev. D64, 034003 (2001), hep-ph/0103208.
- <span id="page-90-8"></span>[252] E. Wang and X.-N. Wang, Phys. Rev. C64, 034901 (2001), nucl-th/0104031.
- <span id="page-90-9"></span>[253] A. Accardi and M. Gyulassy, Phys. Lett. B586, 244 (2004), nucl-th/0308029.
- <span id="page-90-10"></span>[254] STAR, J. Adams et al., Phys. Rev. Lett. 91, 172302 (2003), nucl-ex/0305015.
- <span id="page-90-11"></span>[255] PHENIX, S. S. Adler et al., Phys. Rev. Lett. 91, 072301 (2003), nucl-ex/0304022.
- <span id="page-90-12"></span>[256] X.-N. Wang, nucl-th/0305010.
- <span id="page-90-13"></span>[257] PHOBOS, B. B. Back et al., Phys. Lett. B578, 297 (2004), nucl-ex/0302015.
- <span id="page-90-14"></span>[258] PHENIX, S. S. Adler et al., Phys. Rev. C69, 034910 (2004), nucl-ex/0308006.
- <span id="page-90-16"></span>[259] I. Vitev and M. Gyulassy, Phys. Rev. Lett. 89, 252301 (2002), hep-ph/0209161.
- <span id="page-90-17"></span>[260] M. Gyulassy, I. Vitev, X.-N. Wang, and P. Huovinen, Phys. Lett. B526, 301 (2002), nucl-th/0109063.
- <span id="page-90-18"></span>[261] D. Kharzeev, E. Levin, and L. McLerran, Phys. Lett. B561, 93 (2003), hep-ph/0210332.
- [262] D. Kharzeev, Y. V. Kovchegov, and K. Tuchin, Phys. Rev. D68, 094013 (2003), hepph/0307037.
- <span id="page-90-19"></span><span id="page-90-15"></span>[263] A. Accardi and M. Gyulassy, nucl-th/0402101.
- <span id="page-90-20"></span>[264] STAR, M. A. C. Lamont, nucl-ex/0403059.
- <span id="page-90-21"></span>[265] K. P. Das and R. C. Hwa, Phys. Lett. B68, 459 (1977).
- <span id="page-90-22"></span>[266] R. C. Hwa, Phys. Rev. D22, 1593 (1980).
- <span id="page-90-23"></span>[267] E. Braaten, Y. Jia, and T. Mehen, Phys. Rev. Lett. 89, 122002 (2002), hep-ph/0205149.
- <span id="page-90-24"></span>[268] STAR, J. Adams et al., nucl-ex/0309012.
- <span id="page-90-25"></span>[269] R. J. Fries, nucl-th/0403036.
- [270] R. C. Hwa and C. B. Yang, Phys. Rev. C66, 025205 (2002), hep-ph/0204289.

- <span id="page-91-1"></span><span id="page-91-0"></span>[271] R. C. Hwa and C. B. Yang, Phys. Rev. C67, 064902 (2003), nucl-th/0302006.
- <span id="page-91-2"></span>[272] S. A. Voloshin, Nucl. Phys. A715, 379 (2003), nucl-ex/0210014.
- <span id="page-91-3"></span>[273] D. Molnar and S. A. Voloshin, Phys. Rev. Lett. 91, 092301 (2003), nucl-th/0302014.
- [274] R. J. Fries, B. Muller, C. Nonaka, and S. A. Bass, Phys. Rev. Lett. 90, 202303 (2003), nucl-th/0301087.
- <span id="page-91-5"></span><span id="page-91-4"></span>[275] V. Greco, C. M. Ko, and P. Levai, Phys. Rev. Lett. 90, 202302 (2003), nucl-th/0301093.
- <span id="page-91-6"></span>[276] V. Greco, C. M. Ko, and P. Levai, Phys. Rev. C68, 034904 (2003), nucl-th/0305024.
- <span id="page-91-7"></span>[277] DELPHI, P. Abreu et al., Eur. Phys. J. C17, 207 (2000), hep-ex/0106063.
- <span id="page-91-8"></span>[278] R. C. Hwa and C. B. Yang, (2003), hep-ph/0312271.
- <span id="page-91-9"></span>[279] R. C. Hwa and C. B. Yang, (2004), nucl-th/0403001.
- <span id="page-91-10"></span>[280] R. C. Hwa and C. B. Yang, (2004), nucl-th/0404066.
- <span id="page-91-11"></span>[281] T. Hirano and Y. Nara, (2003), nucl-th/0307015.
- <span id="page-91-12"></span>[282] STAR, K. Schweda, nucl-ex/0403032.
- <span id="page-91-13"></span>[283] PHENIX, A. D. Frawley, nucl-ex/0404009.
- <span id="page-91-14"></span>[284] M. Pluemer, M. Gyulassy, and X. N. Wang, Nucl. Phys. A590, 511c (1995).
- <span id="page-91-15"></span>[285] DELPHI, P. Abreu et al., Phys. Lett. B407, 174 (1997).
- <span id="page-91-16"></span>[286] STAR, C. Adler et al., Phys. Rev. Lett. 90, 032301 (2003), nucl-ex/0206006.
- <span id="page-91-17"></span>[287] STAR, D. Hardtke, Nucl. Phys. A715, 272 (2003), nucl-ex/0212004.
- <span id="page-91-18"></span>[288] A. Majumder and X.-N. Wang, (2004), hep-ph/0402245.
- <span id="page-91-19"></span>[289] T. Hirano and Y. Nara, Phys. Rev. Lett. 91, 082301 (2003), nucl-th/0301042.
- <span id="page-91-20"></span>[290] STAR, Y. Guo, hep-ex/0403018.
- <span id="page-91-21"></span>[291] STAR, F. Wang, nucl-ex/0404010.
- [292] N. Borghini, P. M. Dinh, and J.-Y. Ollitrault, Phys. Rev. C62, 034902 (2000), nuclth/0004026.
- <span id="page-91-23"></span><span id="page-91-22"></span>[293] X.-N. Wang, Phys. Rev. C63, 054902 (2001), nucl-th/0009019.
- [294] N. Borghini, P. M. Dinh, and J.-Y. Ollitrault, Phys. Rev. C63, 054906 (2001), nuclth/0007063.
- <span id="page-91-24"></span>[295] N. Borghini, P. M. Dinh, and J.-Y. Ollitrault, Phys. Rev. C64, 054901 (2001), nuclth/0105040.
- <span id="page-91-25"></span>[296] M. Miller and R. Snellings, nucl-ex/0312008.

- <span id="page-92-1"></span><span id="page-92-0"></span>[297] STAR, R. Snellings, nucl-ex/0305001.
- <span id="page-92-2"></span>[298] Z.-B. Xu, nucl-ex/0404034.
- <span id="page-92-3"></span>[299] E. V. Shuryak, Phys. Rev. C66, 027902 (2002), nucl-th/0112042.
- <span id="page-92-4"></span>[300] A. Drees, H. Feng, and J. Jia, (2003), nucl-th/0310044.
- [301] R. J. Fries, B. Muller, C. Nonaka, and S. A. Bass, Phys. Rev. C68, 044902 (2003), nucl-th/0306027.
- <span id="page-92-6"></span><span id="page-92-5"></span>[302] V. Greco and C. M. Ko, (2004), nucl-th/0402020.
- <span id="page-92-7"></span>[303] STAR, A. H. Tang, nucl-ex/0403018.
- <span id="page-92-8"></span>[304] K. Filimonov, nucl-ex/0403060.
- <span id="page-92-9"></span>[305] T. Falter and U. Mosel, Phys. Rev. C66, 024608 (2002), nucl-th/0203052.
- <span id="page-92-10"></span>[306] K. Gallmeister, C. Greiner, and Z. Xu, Phys. Rev. C67, 044905 (2003), hep-ph/0212295.
- <span id="page-92-11"></span>[307] W. Cassing, K. Gallmeister, and C. Greiner, Nucl. Phys. A735, 277 (2004), hepph/0311358.
- <span id="page-92-12"></span>[308] X.-N. Wang, Phys. Lett. B579, 299 (2004), nucl-th/0307036.
- <span id="page-92-13"></span>[309] WA98, M. M. Aggarwal et al., Phys. Rev. Lett. 81, 4087 (1998), nucl-ex/9806004.
- <span id="page-92-14"></span>[310] WA98, M. M. Aggarwal et al., Eur. Phys. J. C23, 225 (2002), nucl-ex/0108006.
- <span id="page-92-15"></span>[311] X.-N. Wang, Phys. Rev. Lett. 81, 2655 (1998), hep-ph/9804384.
- <span id="page-92-16"></span>[312] D. d'Enterria, nucl-ex/0403055.
- <span id="page-92-17"></span>[313] CERES/NA45, G. Agakichiev et al., Phys. Rev. Lett. 92, 032301 (2004), nucl-ex/0303014.
- <span id="page-92-18"></span>[314] PHOBOS, B. B. Back et al., nucl-ex/0405003.
- <span id="page-92-19"></span>[315] Y. L. Dokshitzer and D. E. Kharzeev, Phys. Lett. B519, 199 (2001), hep-ph/0106202.
- <span id="page-92-20"></span>[316] M. Djordjevic and M. Gyulassy, Phys. Lett. B560, 37 (2003), nucl-th/0302069.
- <span id="page-92-21"></span>[317] B.-W. Zhang, E. Wang, and X.-N. Wang, (2003), nucl-th/0309040.
- <span id="page-92-22"></span>[318] N. Armesto, C. A. Salgado, and U. A. Wiedemann, (2003), hep-ph/0312106.
- <span id="page-92-23"></span>[319] PHENIX, J. Frantz, nucl-ex/0404006.
- <span id="page-92-24"></span>[320] X.-N. Wang, Phys. Rev. C58, 2321 (1998), hep-ph/9804357.
- [321] Y. Zhang, G. I. Fai, G. Papp, G. G. Barnafoldi, and P. Levai, Phys. Rev. C65, 034903 (2002), hep-ph/0109233.
- <span id="page-92-25"></span>[322] PHENIX, K. Adcox et al., Phys. Rev. Lett. 88, 192303 (2002), nucl-ex/0202002.

- <span id="page-93-1"></span><span id="page-93-0"></span>[323] PHENIX, S. Kelly, nucl-ex/0403057.
- <span id="page-93-2"></span>[324] S. Batsouli, S. Kelly, M. Gyulassy, and J. L. Nagle, Phys. Lett. B557, 26 (2003), nuclth/0212068.
- <span id="page-93-3"></span>[325] STAR, A. Tai, nucl-ex/0404029.
- <span id="page-93-4"></span>[326] Z.-W. Lin and D. Molnar, Phys. Rev. C68, 044901 (2003), nucl-th/0304045.
- <span id="page-93-5"></span>[327] R. Baier, Y. L. Dokshitzer, A. H. Mueller, and D. Schiff, Phys. Rev. C60, 064902 (1999), hep-ph/9907267.
- <span id="page-93-6"></span>[328] C. A. Salgado and U. A. Wiedemann, (2003), hep-ph/0310079.
- <span id="page-93-7"></span>[329] STAR, T. Henry et al., nucl-ex/0403031.
- <span id="page-93-8"></span>[330] T. Sjostrand and M. van Zijl, Phys. Rev. D36, 2019 (1987).
- <span id="page-93-9"></span>[331] T. Sjostrand, L. Lonnblad, and S. Mrenna, (2001), hep-ph/0108264.
- <span id="page-93-10"></span>[332] M. Gyulassy, nucl-th/0403032.
- [333] R. L. Thews, M. Schroedter, and J. Rafelski, Phys. Rev. C63, 054905 (2001), hepph/0007323.
- <span id="page-93-12"></span><span id="page-93-11"></span>[334] L. Grandchamp and R. Rapp, Nucl. Phys. A709, 415 (2002), hep-ph/0205305.
- [335] C. Gale and K. L. Haglin, in Quark-gluon Plasma 3, eds. R.C Hwa and X.-N. Wang (2003), hep-ph/0306098.