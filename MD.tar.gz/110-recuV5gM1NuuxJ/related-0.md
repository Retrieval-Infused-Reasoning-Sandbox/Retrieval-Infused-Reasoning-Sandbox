## Quantum Two Body Problem

Consider the two body problem: Two point-like particles interacting with each other but not subject to any external forces. In quantum mechanics, this 2-body system is described by a Hamiltonian of the form

$$\hat{H} = \frac{\hat{\mathbf{P}}_1^2}{2M_1} + \frac{\hat{\mathbf{P}}_2^2}{2M_2} + V(\hat{\mathbf{X}}_1 - \hat{\mathbf{X}}_2). \tag{1}$$

For simplicity, we assume both particles are spinless. Note that the potential V (Xˆ <sup>1</sup> − Xˆ <sup>2</sup>) depends only on the relative position of the two particles but is invariant under simultaneous translations

$$\mathbf{X}_1 \rightarrow \mathbf{X}_1 + \mathbf{a}, \quad \mathbf{X}_2 \rightarrow \mathbf{X}_2 + \mathbf{a}, \quad \text{same shift } \mathbf{a} \text{ for both particles}, \qquad (2)$$

and that's why the 2 particles interact with each other but are not subject to any external forces.

In quantum mechanics, the translational symmetries (2) are implemented by the unitary translation operators

$$\hat{T}_{\mathbf{a}} = \exp(-i\mathbf{a}\cdot\hat{\mathbf{P}}_{\text{net}}), \qquad \hat{\mathbf{P}}_{\text{net}} = \hat{\mathbf{P}}_1 + \hat{\mathbf{P}}_2$$
 (3)

which act in the coordinate basis as

$$\hat{T}_{\mathbf{a}} | \mathbf{X}_1, \mathbf{X}_2 \rangle = | \mathbf{X}_1 + \mathbf{a}, \mathbf{X}_2 + \mathbf{a} \rangle.$$
 (4)

It is easy to see that the 3 generators Pˆ<sup>i</sup> net (i = x, y, z) of the translation symmetry commute with the Hamiltonian (1). Indeed, all 6 momentum operators Pˆ<sup>i</sup> 1,2 commute with each other, so the Pˆ<sup>i</sup> net commute with all functions of momenta such as the net kinetic energy operator (the first 2 terms in eq. (1)), which leaves with

$$\left[\hat{P}_{\text{net}}^{i}, \hat{H}\right] = \left[\hat{P}_{\text{net}}^{i}, \hat{V}\right]. \tag{5}$$

Furthermore,

$$\begin{bmatrix} \hat{P}_{\text{net}}^{i}, \hat{V} \end{bmatrix} = \begin{bmatrix} \hat{P}_{1}^{i}, \hat{V} \end{bmatrix} + \begin{bmatrix} \hat{P}_{2}^{i}, \hat{V} \end{bmatrix} = -i\hbar \frac{\widehat{\partial V}}{\partial X_{1}^{i}} - i\hbar \frac{\widehat{\partial V}}{\partial X_{2}^{i}} = 0$$
because 
$$\frac{\partial V}{\partial X_{1}^{i}} + \frac{\partial V}{\partial X_{2}^{i}} = 0 \quad \text{for} \quad V(\mathbf{X}_{1} - \mathbf{X}_{2}).$$
(6)

Altogether, we have the 3 generators  $\hat{P}_{\text{net}}^i$  and hence all the translation operators  $\hat{T}_{\mathbf{a}}$  commuting with the Hamiltonian (1). Consequently, in the common eigenbasis of the net momenta operators  $\hat{P}_{\text{net}}^i$ , all the translation operators are diagonal, and the Hamiltonian operator  $\hat{H}$  should be block-diagonal.

To see how this works, we need linear redefinitions of the two particles' positions and momenta. On the position side we trade the  $\hat{\mathbf{X}}_1$  and the  $\hat{\mathbf{X}}_2$  operators for the

center of mass position 
$$\hat{\mathbf{X}}_{cm} = \frac{M_1}{M_1 + M_2} \hat{\mathbf{X}}_1 + \frac{M_2}{M_1 + M_2} \hat{\mathbf{X}}_2$$
  
and relative position  $\hat{\mathbf{X}}_{rel} = \hat{\mathbf{X}}_1 - \hat{\mathbf{X}}_2$ , (7)

while on the momentum side we trade the  $\hat{\mathbf{P}}_1$  and the  $\hat{\mathbf{P}}_2$  operators for the

net momentum 
$$\hat{\mathbf{P}}_{\text{net}} = \hat{\mathbf{P}}_1 + \hat{\mathbf{P}}_2$$
  
and reduced momentum  $\hat{\mathbf{P}}_{\text{red}} = \frac{M_2}{M_1 + M_2} \hat{\mathbf{P}}_1 - \frac{M_1}{M_1 + M_2} \hat{\mathbf{P}}_2$ . (8)

Note that the net momentum is canonically conjugate to the center-of-mass position while the reduced momentum is conjugate to the relative position. In quantum

terms, this means

$$\left[\hat{X}_{\rm cm}^{i}, \hat{P}_{\rm net}^{j}\right] = i\hbar \delta^{ij},\tag{a}$$

and 
$$\left[\hat{X}_{\text{rel}}^{i}, \hat{P}_{\text{red}}^{j}\right] = i\hbar\delta^{ij},$$
 (b)

but 
$$\left[\hat{X}_{\text{rel}}^i, \hat{P}_{\text{net}}^j\right] = 0,$$
 (c)

and 
$$\left[\hat{X}_{\text{cm}}^{i}, \hat{P}_{\text{red}}^{j}\right] = 0.$$
 (d)

Indeed:

$$\begin{bmatrix} \hat{X}_{\text{cm}}^{i}, \hat{P}_{\text{net}}^{j} \end{bmatrix} = \frac{M_{1}}{M_{1} + M_{2}} \left[ \hat{X}_{1}^{i}, \hat{P}_{1}^{j} \right] + \frac{M_{2}}{M_{1} + M_{2}} \left[ \hat{X}_{2}^{i}, \hat{P}_{2}^{j} \right] 
 = \frac{M_{1}}{M_{1} + M_{2}} \times i\hbar \delta^{ij} + \frac{M_{2}}{M_{1} + M_{2}} \times i\hbar \delta^{ij} = 1 \times i\hbar \delta^{ij}, \quad (a)$$

$$\begin{bmatrix} \hat{X}_{\text{rel}}^{i}, \hat{P}_{\text{red}}^{j} \end{bmatrix} = \frac{M_{2}}{M_{1} + M_{2}} \left[ \hat{X}_{1}^{i}, \hat{P}_{1}^{j} \right] + \frac{M_{1}}{M_{1} + M_{2}} \left[ \hat{X}_{2}^{i}, \hat{P}_{2}^{j} \right] 
 = \frac{M_{2}}{M_{1} + M_{2}} \times i\hbar \delta^{ij} + \frac{M_{1}}{M_{1} + M_{2}} \times i\hbar \delta^{ij} = 1 \times i\hbar \delta^{ij},$$
(b)

$$\begin{aligned}
 \left[\hat{X}_{\text{rel}}^{i}, \hat{P}_{\text{net}}^{j}\right] &= +\left[\hat{X}_{1}^{i}, \hat{P}_{1}^{j}\right] - \left[\hat{X}_{2}^{i}, \hat{P}_{2}^{j}\right] \\
 &= +i\hbar\delta^{ij} - i\hbar\delta^{ij} = 0,
\end{aligned} (c)$$

$$\begin{bmatrix} \hat{X}_{cm}^{i}, \hat{P}_{red}^{j} \end{bmatrix} = + \frac{M_{1}M_{2}}{(M_{1} + M_{2})^{2}} \begin{bmatrix} \hat{X}_{1}^{i}, \hat{P}_{1}^{j} \end{bmatrix} - \frac{M_{2}M_{1}}{(M_{1} + M_{2})^{2}} \begin{bmatrix} \hat{X}_{2}^{i}, \hat{P}_{2}^{j} \end{bmatrix} 
 = + \frac{M_{1}M_{2}}{(M_{1} + M_{2})^{2}} \times i\hbar\delta^{ij} - \frac{M_{2}M_{1}}{(M_{1} + M_{2})^{2}} \times i\hbar\delta^{ij} = 0.$$
(d)

Similar to what we have in the homework#3 (problem 4(f)), eqs. (a–d) imply that in the  $|\mathbf{X}_{cm}, \mathbf{X}_{net}\rangle$  coordinate basis, the net and the reduced momentum operators act on the wave-functions as

$$\hat{P}_{\text{net}}^{i}\Psi(\mathbf{X}_{cm},\mathbf{X}_{\text{rel}}) = -i\hbar\frac{\partial\Psi}{\partial X_{\text{cm}}^{i}}, \qquad \hat{P}_{\text{red}}^{i}\Psi(\mathbf{X}_{cm},\mathbf{X}_{\text{rel}}) = -i\hbar\frac{\partial\Psi}{\partial X_{\text{rel}}^{i}}.$$
 (9)

Consequently, the eigenstates of the net momentum operator have wave-function

of the form

$$\Psi(\mathbf{X}_{cm}, \mathbf{X}_{rel}) = \exp(-i\mathbf{P}_{net} \cdot \mathbf{X}_{cm}/\hbar) \times \psi(\mathbf{X}_{rel})$$
 (10)

where ψ(Xrel) is any 1-particle wave-function of the relative position. Thus, we see that all the eigenvalues of the net momentum are infinitely degenerate, and the eigenstate subspace for each eigenvalue is equivalent to the 1-particle Hilbert space.

Now consider the two-particle Hamiltonian operator (1). Since it commutes with the net momenta, it must be block-diagonal the basis of net momentum eigenstates. In terms of the wave functions (10), this means

for 
$$\Psi(\mathbf{X}_{cm}, \mathbf{X}_{rel}) = \exp(-i\mathbf{P}_{net} \cdot \mathbf{X}_{cm}/\hbar) \times \psi(\mathbf{X}_{rel}),$$
  
 $\hat{H}\Psi(\mathbf{X}_{cm}, \mathbf{X}_{rel}) = \exp(-i\mathbf{P}_{net} \cdot \mathbf{X}_{cm}/\hbar) \times \hat{H}(\text{block }\mathbf{P}_{net})\psi(\mathbf{X}_{rel})$ 
(11)

where Hˆ (block Pnet) — the diagonal block of Hˆ for a particular value of the net momentum — acts only on the 1-particle wave function ψ(Xrel), so we may interpret it as some kind of a 1-particle Hamiltonian.

Moreover, all the Hˆ (block Pnet) for different net momenta are completely similar to each other apart from constant terms. To see how this works, let's re-express the net kinetic energy in terms of the net and the reduced momenta:

$$\hat{K}_{\text{net}} = \frac{\hat{\mathbf{P}}_{1}^{2}}{2M_{1}} + \frac{\hat{\mathbf{P}}_{2}^{2}}{2M_{2}} = \frac{\hat{\mathbf{P}}_{\text{net}}^{2}}{2M_{\text{net}}} + \frac{\hat{\mathbf{P}}_{\text{red}}^{2}}{2M_{\text{red}}},$$
 (12)

where

$$M_{\text{net}} = M_1 + M_2 \text{ and } M_{\text{red}} = \frac{M_1 M_2}{M_1 + M_2}.$$
 (13)

Consequently, the net 2-particle Hamiltonian becomes

$$\hat{H} = \frac{\hat{\mathbf{P}}_{\text{net}}^2}{2M_{\text{net}}} + \frac{\hat{\mathbf{P}}_{\text{red}}^2}{2M_{\text{red}}} + V(\hat{\mathbf{X}}_{\text{rel}}), \tag{14}$$

and when we restrict it to an eigenspace of the net momentum, we get

$$\hat{H}(\text{block }\mathbf{P}_{\text{net}}) = \left(\frac{\mathbf{constant}}{2M_{\text{net}}}\right) + \hat{H}_{\text{red}},$$
 (15)

with the same reduced Hamiltonian

$$\hat{H}_{\text{red}} = \frac{\hat{\mathbf{P}}_{\text{red}}^2}{2M_{\text{red}}} + V(\hat{\mathbf{X}}_{\text{rel}})$$
 (16)

for all eigenvalues of the net momentum. This reduced Hamiltonian governs the relative motion of the two particles, which looks like the motion of a single particle of reduced mass  $M_{\text{red}}$  in the external potential  $V(\mathbf{X})$ . In the wave-function language, it acts only on the  $\psi(\mathbf{X}_{\text{rel}})$  factor of the 2-particle wave-function (10) as

$$\hat{H}_{\text{red}}\psi(\mathbf{X}_{\text{rel}}) = -\frac{\hbar^2}{2M_{\text{red}}}\nabla^2\psi(\mathbf{X}_{\text{rel}}) + V(\mathbf{X}_{\text{rel}}) \times \psi(\mathbf{X}_{\text{rel}}). \tag{17}$$

Altogether, we have reduced the 2-particle problem to a 1-particle problem in an external potential. Indeed, once we diagonalize the reduced Hamiltonian (16) and find its eigenvalues  $E_n^{\text{red}}$  and eigenwaves  $\psi_n(\mathbf{X}_{\text{rel}})$ ,

$$\hat{H}_{\text{red}}\psi_n(\mathbf{X}_{\text{rel}}) = E_n^{\text{red}}\psi_n(\mathbf{X}_{\text{rel}}),$$
 (18)

the eigenstates of the net 2-particle Hamiltonian  $\hat{H}$  obtain as  $|\mathbf{P}_{\mathrm{net}};n\rangle$  with wavefunctions

$$\Psi(\mathbf{X}_{cm}, \mathbf{X}_{rel}) = \exp(-i\mathbf{P}_{net} \cdot \mathbf{X}_{cm}/\hbar) \times \psi_n(\mathbf{X}_{rel})$$
(19)

and energies

$$E(\mathbf{P}_{\text{net}}; n) = \frac{\mathbf{P}_{\text{net}}^2}{2M_{\text{net}}} + E_n^{\text{red}}. \tag{20}$$