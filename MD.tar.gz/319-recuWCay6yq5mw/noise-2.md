# Renormalization-group study of the Nagel-Schreckenberg model

Han Kheng Teoh and Ee Hou Yong\*

School of Physical and Mathematical Sciences, Nanyang Technological University, Singapore 637371

![](_page_0_Picture_4.jpeg)

(Received 23 August 2017; revised manuscript received 12 February 2018; published 26 March 2018)

We study the phase transition from free flow to congested phases in the Nagel-Schreckenberg (NS) model by using the dynamically driven renormalization group (DDRG). The breaking probability p that governs the driving strategy is investigated. For the deterministic case p = 0, the dynamics remain invariant in each renormalizationgroup (RG) transformation. Two fully attractive fixed points,  $\rho_c^* = 0$  and 1, and one unstable fixed point,  $\rho_c^* = 0$  $1/(v_{\rm max}+1)$ , are obtained. The critical exponent  $\nu$  which is related to the correlation length is calculated for various  $v_{max}$ . The critical exponent appears to decrease weakly with  $v_{max}$  from v = 1.62 to the asymptotical value of 1.00. For the random case p > 0, the transition rules in the coarse-grained scale are found to be different from the NS specification. To have a qualitative understanding of the effect of stochasticity, the case  $p \to 0$  is studied with simulation, and the RG flow in the  $\rho - p$  plane is obtained. The fixed points p = 0 and 1 that govern the driving strategy of the NS model are found. A short discussion on the extension of the DDRG method to the NS model with the open-boundary condition is outlined.

### DOI: 10.1103/PhysRevE.97.032314

### I. INTRODUCTION

Dynamical phase transition in traffic systems has been subjected to extensive study in the past decades in an attempt to unravel the fundamental structure of transition from free flow to jamming regimes. A confluence of ideas from fluid dynamical theories, kinetic theories, and cellular automata models have been employed [1-3] for the aforementioned purpose.

Cellular automata (CA) in particular have been widely used in traffic modeling due to their ability to capture collective behaviors observed in real traffic with a relatively straightforward implementation. The simplest traffic CA model that exhibits a transition from free flow to congested phases has been proposed by Nagel and Schreckenberg [4]. This model serves as a foundation for more complex and realistic traffic phenomenon study in which several authors have made modifications or extensions to the update rules [5–10]. From the physics viewpoint, the original Nagel-Schreckenberg (NS) model is fundamentally interesting as it is a system in a nonequilibrium state that undergoes a transition whose properties are reminiscent of those of second-order phase transition in equilibrium statistical physics [11,12]. Thus, it is natural to consider applying a renormalization group (RG) to probe the fixed points and RG flows in the parameter space. In the present paper, we examine the transition behavior by using the dynamically driven renormalization-group (DDRG) [13] technique.

DDRG is a technique developed to examine the behavior of nonequilibrium statistical models with critical stationary states. It has been applied to driven diffusive systems with an absorbing state [14] and systems with self-organized critical phenomena such as the sand pile model [15] and the fire forest model [16]. In this approach, a real-space renormalizationgroup scheme is combined with a dynamical steady-state

condition that drives the RG equations through the parameter space. Unlike systems in equilibrium in which their Hamiltonians are well defined and the appropriate RG space is the parameters in the Hamiltonian, our Hamiltonian is not known for a nonequilibrium system and the dynamics of the system are defined by a collection of rules. In this case, the appropriate RG space is the transition probabilities that govern the dynamics of the system. A successive application of RG transformations leads to a trajectory along the parameter space.

This paper is organized as follows. In Sec. II we introduce the NS model. The renormalization scheme, the simulation, and the numerical results are presented in Sec. III. A short discussion on the application of DDRG to the NS model with an open-boundary condition is given in Sec. IV. Finally, in Sec. V we conclude.

# II. THE MODEL

The NS model consists of an array of N sites with the state  $\sigma_i$  which can be either empty or occupied by a vehicle with speed  $v = 0, 1, 2, \dots, v_{\text{max}}$ . The position  $x_i$  and the speed of each vehicle  $v_i$  are updated simultaneously according to the following rules.

- (i) Each vehicle speed of  $v < v_{\text{max}}$  is increased by 1:  $v_i \rightarrow$
- (ii) Each vehicle with a speed greater than its headway is reduced to  $d_i$ :  $v_i \to d_i$ .
- (iii) With probability p, each vehicle will reduce its speed by 1:  $v_i \to \max(v_i - 1, 0)$ .
  - (iv) Each vehicle position is updated:  $x_i \rightarrow x_i + v_i$ .

A periodic-boundary condition is assumed with a random initial distribution of the vehicle position. The system configuration can be described by a master equation which is given by

$$P_{t+1}(\boldsymbol{\sigma}) = \sum_{\{\boldsymbol{\sigma}^{\mathbf{0}}\}} W(\boldsymbol{\sigma}|\boldsymbol{\sigma}^{\mathbf{0}}) P_t(\boldsymbol{\sigma}^{\mathbf{0}}), \tag{1}$$

<sup>\*</sup>Corresponding author: eehou@ntu.edu.sg

<span id="page-1-0"></span>TABLE I. Transition probabilities  $W(\sigma_i|\sigma_{i-1}^0,\sigma_i^0,\sigma_{i+1}^0)$  for  $v_{\text{max}} = 1$ .  $\sigma_i$  can be either 1 or 0, which represents cell occupancy.

| $\overline{w}$ | 000 | 001 | 010   | 011 | 100   | 101   | 110   | 111 |
|----------------|-----|-----|-------|-----|-------|-------|-------|-----|
| 1              | 0   | 0   | p     | 1   | 1 - p | 1 - p | p     | 1   |
| 0              | 1   | 1   | 1 - p | 0   | p     | p     | 1 - p | 0   |

where  $P_{t+1}(\sigma)$  is the probability for state  $\sigma = \{\sigma_0, \ldots, \sigma_{N-1}\}$  at time t+1 and  $W(\sigma|\sigma^0)$  is the transition probability from state  $\sigma^0$  to state  $\sigma$  in one time step. To ease the mean-field calculation in the latter section, one may factorize  $W(\sigma|\sigma^0)$  into local terms:

$$W(\boldsymbol{\sigma}|\boldsymbol{\sigma}^{\mathbf{0}}) = \prod_{i=0}^{N-1} W(\sigma_i | \sigma_{i-v_{\text{max}}}^0, \dots, \sigma_{i+v_{\text{max}}}^0), \tag{2}$$

where  $W(\sigma_i|\sigma_{i-v_{max}}^0,\dots,\sigma_{i+v_{max}}^0)$  is determined from the aforementioned rules. For  $v_{max}=1$ , the transition probabilities are as presented in Table I. In this case, cell occupancy is sufficient to describe the state of the system. For  $v_{max}>1$ , in general, one will need to consider speed state as well. Though Eq. (2) implies a random sequential updated dynamics which is different from our NS model with a parallel update, it was shown that the mean-field ansatz in a random sequential updated NS model yields an exact equilibrium state for the NS model with a parallel update for  $v_{max}=1$  [17,18]. Excellent agreement between analytical approximation and simulation results for  $v_{max}>1$  was obtained as well [18].

When p = 0, the NS model is deterministic and exhibits a second-order phase transition from a free flow to a congested state at the critical density  $\rho_c = 1/(v_{\text{max}} + 1)$ , where  $v_{\text{max}}$  is the maximum speed. The free flow state corresponds to a low-density regime (below  $\rho_c$ ) where each car advances with the same speed  $v_{\text{max}}$  in each time step. In the comoving frame, the vehicles freeze in position with equal spacing and the free flow state can be considered as an ordered state. When the density of vehicles exceeds the critical density  $\rho_c$ , the system is then characterized as a congested state. In the high-density regime, the empty sites are insufficient to allow each vehicle in the system to move at the same maximum speed. Thus, in the congested phase, there exists a nonzero fraction of vehicles moving at a speed less than  $v_{\text{max}}$ . In the comoving frame transversing at the speed  $v_{\text{max}}$ , the motion of vehicles is observed. In this sense, a phase transition has taken place from an ordered phase to a disordered phase. When p > 0, the sharp transition from one phase to another is destroyed. However, one may still perform scaling in the limit  $p \to 0$ . The role of p is analogous to the role of the external field h in ferromagnetism, which serves as a conjugated parameter [19].

# III. RG TRANSFORMATION

The DDRG method is a type of renormalization scheme suited for the study of nonequilibrium systems exhibiting nonstationary critical states. The essential ideas of the DDRG method derive from Kadanoff's block analysis [20] and Suzuki's coarse-graining of time [21]. For irreversible nonequilibrium systems, we can describe the dynamics by

using the following master equation:

$$\frac{\partial P(\sigma, t)}{\partial t} = \mathcal{L}(\mu)P(\sigma, t),\tag{3}$$

where  $P(\sigma,t)$  is the probability distribution function for the configuration of the system  $\sigma$  at time t and  $\mathcal{L}(\mu)$  is the temporal evolution operator characterized by a set of dynamical parameters  $\mu$ . Let Re be the coarse-graining operator that eliminates the degrees of freedom of a cell and rescales both time and space. Application of Re to Eq. (3) yields

$$\operatorname{Re}P(\sigma,t) = \tilde{P}(S,t'),$$
 (4)

where  $\tilde{P}(S,t')$  is the coarse-grained probability distribution. Equation (4) can be written in a more explicit form as

$$\operatorname{Re}P(\sigma,t) = \operatorname{Re}[e^{\mathcal{L}t}P(\sigma,0)] = e^{\mathcal{L}'t'}\tilde{P}(S,0). \tag{5}$$

The scale transformation  $\mathcal{L}t \to \mathcal{L}'t'$  yields the dynamical RG approach while the scale transformation of  $P(\sigma,0)$  corresponds to the usual static RG approach. The following recursion relations are then obtained from the RG scheme:

$$\mu' = f(\mu), \quad t' = g(t, \mu) \cong tg(\mu). \tag{6}$$

It is now possible to calculate the fixed points and the critical exponents of the model. It is worth mentioning that these equations are obtained from the RG procedure which assumes  $\tilde{P}(S,t')$  has the same functional form as  $P(\sigma,t)$ .

For the purpose of this work, we consider a more explicit treatment of Eq. (3). In particular, we focus our attention on the dynamics of discrete modes,  $\sigma = \sigma_i$ , on a lattice which are characterized by the dynamical parameters  $\mu$ :

$$P(\sigma,t) = \sum_{\sigma^0} W_{\mu}(\sigma|\sigma^0) P(\sigma^0,0), \tag{7}$$

where  $W_{\mu}(\sigma|\sigma^0)$  is the discrete version of  $\mathcal{L}$  that represents the transition probabilities from  $\sigma^0$  to  $\sigma$  in a unit time step t. The system is coarse-grained by rescaling lengths and time according to the transformations  $x \to bx$  and  $t \to b^z t$ . The renormalization transformation can be constructed through a renormalization operator,  $\text{Re}(S,\sigma)$ , that introduces the coarse-grained variables set  $S = \{S_i\}$  and rescales the length of the system. However, not every choice of operator Re will lead to meaningful transformation and often it is guided by physical insight. In general Re is a projection operator that satisfies the following properties:

$$\operatorname{Re}(S|\sigma) \ge 0, \quad \sum_{\{S\}} \operatorname{Re}(S|\sigma) = 1.$$
 (8)

These properties preserve the normalization condition of the renormalized distribution. It usually corresponds to a block transformation in which lattice sites are grouped into a supersite by means of the majority or spanning rule.

Suppose the dynamical operator W is applied successively,

$$P(\sigma, N) = \sum_{\{\sigma^0\}} W_{\mu}^{N}(\sigma | \sigma^0) P(\sigma^0, 0), \tag{9}$$

where  $W_{\mu}^{N}$  denotes the application of the  $W_{\mu}$  operator N times. For the coarse-grained probability distribution,

$$\tilde{P}(S,t') = \sum_{\{\sigma\}} \text{Re}(S|\sigma) \sum_{\{\sigma^0\}} W_{\mu}^{b^z}(\sigma|\sigma^0) P(\sigma^0,0), \qquad (10)$$

<span id="page-2-0"></span>where we have applied the operator Re and  $t' = b^z t$ . In order to define the RG transformation more clearly, one can multiply and divide each term by  $\tilde{P}(S^0,0) = \sum_{\{\sigma^0\}} \text{Re}(S^0|\sigma^0) P(\sigma^0,0)$  to yield

$$\tilde{P}(S,t') = \sum_{\{S^0\}} W'_{\mu}(S|S^0)\tilde{P}(S^0,0),\tag{11}$$

where

$$W'_{\mu}(S|S^{0}) = \frac{\sum_{\{\sigma^{0}\}} \sum_{\{\sigma\}} \operatorname{Re}(S^{0}|\sigma^{0}) \operatorname{Re}(S|\sigma) W_{\mu}^{b^{z}}(\sigma|\sigma^{0}) P(\sigma^{0},0)}{\sum_{\{\sigma^{0}\}} \operatorname{Re}(S^{0}|\sigma^{0}) P(\sigma^{0},0)}.$$
(12)

Equation (12) is the basic renormalization equation that defines the transition probabilities for the coarse-grained system from which the desired recursive relations are obtained. By imposing the condition that the renormalized transition probability  $\tilde{W}$  has the same form as W, we then obtain the rescaled parameter set  $\mu' = f(\mu)$ . The transition probabilities in the NS model are governed by breaking probability, the corresponding RG parameter space is thus p. Here we first establish the RG scheme for the deterministic case p = 0 and then subsequently explore the stochastic case p > 0.

#### A. Deterministic case p = 0

After allowing the system to relax for a sufficiently long time, the system will settle down to nonequilibrium steady states. In the steady states, the following equation,

$$P(\boldsymbol{\sigma}) = \sum_{\{\boldsymbol{\sigma}^{\mathbf{0}}\}} W^{t}(\boldsymbol{\sigma}|\boldsymbol{\sigma}^{\mathbf{0}}) P(\boldsymbol{\sigma}^{\mathbf{0}}), \tag{13}$$

holds for any value of t, where  $P(\sigma)$  is the stationary probability. We perform a real-space RG transformation that renormalizes the transition probabilities W. The coarse-graining operator Re takes the form

$$\operatorname{Re}(S_i | \sigma^{(v_{\max}+2)}) = \begin{cases} 1 & \sum_{\sigma} \sigma_i \ge 2, \\ 0 & \text{otherwise.} \end{cases}$$
 (14)

where  $\sigma_i$  is the cell occupancy and the state of site  $S_i$  is the result of coarse-graining  $v_{\text{max}} + 2$  sites. The speed state which is required to fully characterize the system for  $v_{\text{max}} > 1$  is deduced separately by inspecting the spatially coarse-grained system configuration at the coarse-grained time. The coarsegraining operator is constructed such that the steady-state configurations of the system at criticality are preserved. For the case  $v_{\text{max}} = 1$ , Re is the usual three-site majority rule. For the system with  $v_{\text{max}}$  is greater than 1, the steady-state configurations at criticality will be of the form  $(1 \dots 1 \dots 1 \dots)$ where 1 denotes sites occupied with a vehicle and ... denotes empty cells of the length  $v_{\text{max}}$ . A naive majority rule is not able to preserve such patterns of the system. Instead one has to consider a biased majority rule in which a block of b sites will only be transformed to an empty supercell provided the number of empty cells is greater than  $v_{\text{max}}$ .

Temporal coarse-graining  $t \to b^z t$ , where z is the dynamic critical exponent and  $b = v_{\text{max}} + 2$ , is performed on the system. By inspection, z has to be 1 in order to have the

same dynamics in each RG transformation. The value of z obtained from this RG scheme is in exact agreement with numerical simulations reported [22,23]. It should be noted that the exponent z deduced above differs from values obtained by fitting the scaling behavior of the relaxation time defined in Refs. [11,24] with  $\tau \sim L^z$ . With the coarse-graining operator defined as above, the transition probabilities in Table I with p=0 remain invariant; i.e.,  $\tilde{W}=W$  in each step of the RG transformation. This indicates p=0 is a fixed point, the nature of which is discussed later. We make an ansatz that  $P(\sigma)$  can be expressed as a product of one-site stationary probabilities,  $P(\sigma_i)$ , which takes the following form:

$$P(\sigma_i) = \sum_{\sigma^{0(1+2v_{\text{max}})}} W(\sigma_i | \sigma^{0(1+2v_{\text{max}})}) P(\sigma^{0(1+2v_{\text{max}})}).$$
 (15)

Upon coarse-graining, the renormalized one-site stationary probability is

$$\tilde{P}(S_i) = \sum_{\sigma^{(v_{\text{max}}+2)}} \text{Re}(S_i | \sigma^{(v_{\text{max}}+2)}) P(\sigma^{(v_{\text{max}}+2)}), \qquad (16)$$

where  $\tilde{P}(S_i)$  satisfies Eq. (15). With  $P(\sigma^{(v_{\text{max}}+2)})$  made known, Eq. (16) can then be used to find density fixed points. For the case  $v_{\text{max}} = 1$ , the spatial and temporal coarse-graining are performed with b = 3. The majority rule is used to determine the state of the coarse-grained cell. The one-site stationary probability is given by

$$\tilde{P}(1) = P(1,1,1) + P(1,1,0) + P(1,0,1) + P(0,1,1).$$
 (17)

To calculate the three-site stationary probabilities, one may consider a simple mean-field approximation that neglects the correlation among each site,  $P(\sigma_{i-1},\sigma_i,\sigma_{i+1}) = P(\sigma_{i-1})P(\sigma_i)P(\sigma_{i+1})$ . For better approximation, an n-site approximation can be used to express the probabilities. As the model has an inherent translational invariance property, an (n,n-1) cluster approximation is used [25]. Equation (17) can be written as

$$\tilde{P}(1) = \frac{P^2(1,1)}{P(1)} + 2\frac{P(1,1)P(1,0)}{P(1)} + \frac{P^2(1,0)}{P(0)},\tag{18}$$

where

$$P(1,1) = P(1) - P(1,0), (19a)$$

$$P(1,0) = \frac{1 - \sqrt{1 - 4P(1)(1 - P(1))}}{2}.$$
 (19b)

Two stable fixed points,  $P^*(1) = 0$  and 1, and one unstable fixed point,  $P^*(1) = 0.5$ , are obtained. The stable fixed points correspond to the trivial case in which the system is either fully empty or fully occupied by vehicles, respectively. The unstable fixed point is the critical density  $\rho_c$  at which the transition from free flow to the congested phase occurs. The RG flow is as shown in Fig. 5. Starting from any density, repeated RG transformations will drive the initial density towards one of the two stable fixed points. Also, one may obtain the correlation length exponent  $\nu$ . In the vicinity of  $\rho_c$ , the correlation length diverges as

$$\xi \propto |\rho - \rho_c|^{-\nu},\tag{20}$$

where the exponent  $\nu$  can be determined by  $\nu = \log(b)/\log(d\tilde{P}/dP|_{\rho_c})$ .

<span id="page-3-0"></span>![](_page_3_Figure_2.jpeg)

FIG. 1. (a)–(d) Three-site stationary probability distribution for the NS model with  $v_{\rm max}=1$  obtained via (2,1) cluster approximation and simulation data.

v=1 is obtained for  $v_{\rm max}=1$  with the two-cluster approximation. A better approximation can be obtained by using a bigger cluster approximation. Though the accuracy of the approximation improves by increasing the cluster size, this method is only feasible for a small cluster due to the exponential growth of the system of equations to solve; i.e.,  $(v_{\rm max}+2)^n$  is generally

![](_page_3_Figure_5.jpeg)

FIG. 2.  $d\tilde{P}/dP$  obtained via cluster approximation and simulation data. The dashed line and the solid line represent data obtained via cluster approximation and simulation, respectively.

needed for an n-cluster approximation [18]. We consider the usage of simulation data to find the three-site stationary probability distributions. Figures 1(a)–1(d) show the discrepancies between various three-site probability distributions obtained from cluster approximation and simulation results. This in turns leads to different  $d\tilde{P}/dP$  values calculated as shown in Fig. 2 which are needed to calculate the critical exponent  $\nu$ . From simulation results, the  $\nu$  exponent is found to be 1.62.

We now extend the calculations for the case  $v_{\rm max}>1$ . As mentioned previously, the NS model with  $v_{\rm max}>1$  is qualitatively very different from that with  $v_{\rm max}=1$ . Particlehole symmetry is absent and a biased majority rule as outlined in Eq. (14) is needed to preserve the steady-state configurations of the system at criticality. From the  $d\tilde{P}/dP$  values obtained for different  $v_{\rm max}$  values, one can observe that  $d\tilde{P}/dP$  scales

![](_page_3_Figure_9.jpeg)

FIG. 3. Correlation-length critical exponent v for various  $v_{\text{max}}$ . The inset shows  $d\tilde{P}/dP$  for various  $v_{\text{max}}$ . The linear fit  $cv_{\text{max}}+d$  is used with fitting parameters c=1.5(2) and d=0.469(3).

![](_page_4_Figure_2.jpeg)

FIG. 4. (a) Space-time diagram for the NS model with  $v_{\rm max}$  = 1 for density  $\rho = 0.55$  and braking probability p = 0.001. (b)–(d) Dynamics of the NS model after being coarse-grained spatially and temporally for the first to the third time.

linearly with  $v_{\text{max}}$ . A linear fit of the form  $d\tilde{P}/dP = cv_{\text{max}} + d$  is used and the fitting parameters are found to be c = 1.50(2) and d = 0.469(3) as shown in the inset of Fig. 3. The v exponent is calculated and curve fitting of the form  $v = \log(v_{\text{max}} + 2)/\log(av_{\text{max}} + b)$  is chosen, with a and b being the parameters determined previously. From the RG calculation, v appears to decrease with increasing  $v_{\text{max}}$ , changing from v = 1.62 to v = 1.35. In the asymptotic limit  $v_{\text{max}} \to \infty$ , the v exponent tends to 1.00. The  $v_{\text{max}}$  dependence of v is also observed in the limit  $p \to 1$ , where cars tend to decelerate [26].

### B. Stochastic case p > 0

In the present section, we consider a NS model with a nonzero braking probability. The transition probability W is renormalized with the same RG scheme outlined in the previous section. As an example, Fig. 4 shows the spacetime diagram for a system with  $v_{\rm max}=1$  and p=0.001 under several iterations of the RG transformation. The NS simulations are performed for a system of length  $L=10^6$  with the density  $\rho_0$  and the braking probability  $p_0$ . After the system has relaxed for a sufficiently long time ( $t_{\rm relax}=10L$ ), the system is then coarse-grained spatially and temporally. The renormalized density  $\rho_1$  and the braking probability  $p_1$  are then obtained from the coarse-grained system which will then be used for subsequent NS simulation. This procedure is iterated for several times until the system reaches a fixed point. The RG flow in the  $\rho-p$  plane is then plotted.

This scheme assumes the coarse-grained system adheres to the NS dynamics. This assumption was tested with NS simulations of  $v_{\text{max}} = 1$  with track length  $L = 3^{13}$  and simulation time  $t_{\text{sim}} = 3^{13}$ . After the system has relaxed sufficiently, the configurations of the system are used to determine the renormalized density  $\rho_n$  and the transition probability  $W_n$ by successively coarse-graining the system both spatially and temporally. Contrary to the coarse-graining scheme described earlier where feedback of newly obtained renormalized parameters is needed to perform new simulations, this scheme generates a sequence of  $(\rho_n, p_n)$  from a single simulation. It is found that for  $p_0 \to 0$ , the assumption holds. The results of renormalized density and transition probabilities for the NS model with  $v_{\text{max}} = 1$  up to the fourth iteration are shown in Table II. Beyond the fourth iteration, the size of the system is not large enough to provide a good estimate of the transition probabilities. A higher iteration with an accurate calculation of the renormalized density and transition probabilities can be obtained by starting from a larger system size, however the simulation time scales exponentially with the increase of the system size. The braking probabilities obtained are found to be in good agreement with the renormalized braking probability obtained with the other scheme outlined. However, as noticed, with the increase of p, this leads to proliferation of states upon the RG transformation; i.e., the existence of states that violate the NS rules is present. To define a renormalized braking probability that avoids proliferation at each RG iteration, we consider the following form.

For the case  $v_{\text{max}} = 1$ , the renormalized braking probability is calculated via

$$p' = \frac{n(1,0|1,0)}{n(0,1|1,0) + n(1,0|1,0)},$$
(21)

where  $n(\sigma_i^{\tau+1}, \sigma_{i+1}^{\tau+1} | \sigma_i^{\tau}, \sigma_{i+1}^{\tau})$  denotes the number of configuration in state  $(\sigma_i, \sigma_{i+1})$  at time  $\tau+1$  given that it is in state  $(\sigma_i, \sigma_{i+1})$  at time  $\tau$ . This definition ensures no proliferation of states; i.e., states that are not allowed in the NS model are taken into account [13]. The RG flow in the  $\rho-p$  plane as shown in Fig. 5 is obtained by performing the aforementioned coarse-graining process [27]. With a nonzero braking probability as the initial condition and a renormalized braking probability definition that avoids proliferation, the parameters will flow towards the fixed point p=1 for  $\rho$  close to  $\rho_c$ . For  $\rho>0.55$  or  $\rho<0.45$ , the parameters will flow towards the fixed point p=0 instead.

TABLE II. Renormalized density and transition probabilities for the NS model with  $v_{\text{max}} = 1$  at each iteration of the coarse-graining procedure with no feedback. The transition probabilities are in good agreement with the NS rules. The proliferation of states, i.e., states not allowed in the NS models, is present when more coarse-graining iterations are performed.

| Iteration | L        | ρ     | w(0 000) | w(0 001) | w(0 010) | w(1 011) | w(1 100) | w(1 101) | w(0 110) | w(1 111) |
|-----------|----------|-------|----------|----------|----------|----------|----------|----------|----------|----------|
| 0         | 313      | 0.499 | 1        | 1        | 0.9999   | 1        | 0.9999   | 0.9999   | 0.9999   | 1        |
| 1         | $3^{12}$ | 0.497 | 0.9999   | 0.9999   | 0.9991   | 0.9998   | 0.9992   | 0.9991   | 0.9992   | 0.9999   |
| 2         | $3^{11}$ | 0.491 | 0.9991   | 0.9991   | 0.9921   | 0.9973   | 0.9931   | 0.9920   | 0.9931   | 0.9990   |
| 3         | $3^{10}$ | 0.477 | 0.9911   | 0.9911   | 0.9348   | 0.9752   | 0.9416   | 0.9336   | 0.9420   | 0.9898   |
| 4         | $3^{9}$  | 0.446 | 0.9265   | 0.9265   | 0.6589   | 0.8150   | 0.6379   | 0.6352   | 0.6455   | 0.9142   |

<span id="page-5-0"></span>![](_page_5_Figure_2.jpeg)

FIG. 5. RG flow in the  $\rho - p$  plane for the NS model with  $v_{\rm max} = 1$ . Blue arrows indicate the RG flow for the quenched disorder NS model. Yellow arrows indicate the RG flow for the deterministic NS model. Black circles represent the trivial fixed points and the white circle represents the unstable fixed point. Yellow (blue) arrows represent the RG flow with p = 0 (p > 0).

For the case  $v_{\rm max}=2$ , the renormalized braking probability is calculated as

$$p' = \begin{cases} \frac{n(0,1,0|1,0,0)}{n(0,1,0|1,0,0)+n(0,0,1|1,0,0)}, & \rho \leqslant \rho_c, \\ \frac{n(1,0,X|1,0,1)}{n(0,1,X|1,0,1)+n(1,0,X|1,0,1)}, & \rho > \rho_c, \end{cases}$$
(22)

where  $X \in \{1,0\}$ . The need of having different approaches in computing the p' is necessary as both the (1,0,1) and (1,0,0) configurations are density dependent as exemplified in Fig. 6. For a density which is lower than  $\rho_c$ , the existence of (1,0,1) is vanishingly small as the vehicles will tend to keep

![](_page_5_Figure_7.jpeg)

FIG. 6. Fraction of vehicles in the NS model ( $v_{\rm max}=2$ ) with a headway of either one empty site (dashed and dash-dotted lines) or at least two empty sites (solid line) as a function of density for p=0, 0.1, and 0.3.

![](_page_5_Figure_9.jpeg)

FIG. 7. RG flow in the  $\rho-p$  plane for the NS model with  $v_{\rm max}=2$ . Blue arrows indicate the RG flow for the quenched disorder NS model. Yellow arrows indicate the RG flow for the deterministic NS model. Black circles represent the trivial fixed points and the white circle represents the unstable fixed point. Yellow (blue) arrows represent the RG flow with p=0 (p>0).

at least two empty sites with each other. Thus, one will obtain an erroneous result if (1,0,1) is used to determine p'. The renormalized braking probability is determined with (1,0,0) instead. Likewise, for a density that is greater than  $\rho_c$ , (1,0,1) is used to calculate p'.

As observed from the RG flows for Fig. 7, there are two fixed points as well, p = 0 and p = 1 [27]. Unlike the NS model with  $v_{\text{max}} = 1$ , where the fixed points represent the trivial behavior of vehicles, these fixed points lead to distinct driving strategies in the NS model. The NS model with p = 0 can be viewed as the case where the vehicles are dominated by repulsive interaction that tends to align the vehicles at least  $v_{\text{max}}$  empty sites between each other. As discussed in previous sections, the NS model with p = 0shows a continuous phase transition from a free flow state to congested phases. Whereas for the NS model with p = 1, the vehicles are dominated by attractive interactions between vehicles. A slight deviation from metastable configurations will lead to a complete breakdown of the flow in the system. This can be thought as a NS model that adopts an overcautious driving strategy. It was shown to exhibit phase separation and the existence of metastable states and can be regarded as a first-order phase transition. The existence of these fixed points, p = 0 and 1, for a given  $v_{\text{max}}$  from RG calculations agrees with the notion suggested by Schadschneider [28] that the behavior of the NS model is governed by them.

# IV. OPEN-BOUNDARY CONDITION

Most of the works concerning the NS model assume periodic-boundary conditions, with much attention being paid to the question of transition from a free flow state to congested phases. The NS model with an open-boundary condition is no less significant than the model with periodic-boundary <span id="page-6-0"></span>conditions. This is exemplified by the fact that the open-boundary NS model can be used to study situations where multilanes merge to one lane due to road construction or where there is lane diversion caused by accidents and natural disasters. In fact, the open-boundary NS model exhibits more complex behavior. The critical states of the open-boundary NS model are dependent on the boundary condition, i.e., the boundary-induced phase transition [29,30]. Also, by manipulating both the injection rate  $\alpha$  and the extinction rate  $\beta$ , one can observed a first-order phase transition or a second-order phase transition. In this section, we provide a short discussion of how the DDRG method can be extended to an open-boundary system.

In a NS model with periodic-boundary conditions, the car density serves as a tuning parameter. However, in an open-boundary system, the injection rate  $\alpha$  and the extinction rate  $\beta$  are the tuning parameters while the density is a derived parameter. Thus, the corresponding parameter space is  $(\alpha, \beta)$ . The dynamics of vehicles are also dictated by the rules specified for a NS model with periodic-boundary conditions. The only difference is that the boundaries of the system need some special treatments. For example, if  $v_{\text{max}} = 1$ , the transition rates for the left boundary  $W_L(\sigma_0^{t+1}|\sigma_0^t,\sigma_1^t)$  and the right boundary  $W_R(\sigma_N^{t+1}|\sigma_{N-1}^t,\sigma_N^t)$  are as follows:

$$W_L(1|00) = \alpha, \quad W_R(1|00) = 0,$$
 (23)

$$W_L(1|01) = \alpha, \quad W_R(1|01) = 1 - \beta,$$
 (24)

$$W_L(1|10) = p, \quad W_R(1|10) = 1 - p,$$
 (25)

$$W_L(1|11) = 1, \quad W_R(1|11) = 1.$$
 (26)

One may also write down the boundary dynamics in a more explicit manner as follows:

$$\sigma_1^{t+1} = \alpha (1 - \sigma_1^t) + (1 - p)\sigma_1^t (1 - \sigma_2^t) + \sigma_1^t \sigma_2^t,$$
 (27a)

$$\sigma_N^{t+1} = p\sigma_{N-1}^t (1 - \sigma_N^t) + (1 - \beta)\sigma_N^t, \tag{27b}$$

where  $\sigma_i^t$  denotes the state of the *i*th cell at time step *t*. By applying the coarse-graining operator Re defined in Eq. (14) and proceeding with the DDRG procedure, the renormalized transition probabilities  $\tilde{W}_{R/L}$  can be calculated. Recursion relations for parameters  $\alpha$  and  $\beta$  can be then formed to determine the fixed points and critical exponents. For the case  $v_{\text{max}} = 1$ , the NS model is identical to the asymmetric simple exclusion process (ASEP) model with a parallel update which is well studied [18,31,32] and consists of three distinct regimes (free flow, jamming, and maximum current). The transition from the free flow to the jamming phase is first order along the  $\alpha = \beta$  line for  $\alpha, \beta < 1 - \sqrt{p}$ . The transition from the free flow (jamming) to the maximum

current phase is second order and occurs at the injection (extinction) rate  $\alpha_c(\beta_c)$ , with  $\alpha_c = \beta_c = 1 - \sqrt{p}$ . A real-space renormalization group was applied to the ASEP model by Hanney and Stinchcombe [33] to study fixed points and RG flows in the parameter space  $(\alpha/p, \beta/p)$ . In their work, the density and current are assumed to remain invariant under the RG transformation. Several nontrivial fixed points were found, notably  $(\alpha_c, \beta_c)$ , which controls the second-order transition from the free flow (jamming) phase to maximum current, and the flow line, which represents a first-order transition. It is expected that the DDRG approach will lead to similar results. For the NS model with  $v_{\text{max}} > 1$ , detailed studies were performed by Cheybani et al. [34,35]. It was observed that there exists a first-order phase transition between free flow and the jamming phase for the case  $v_{\text{max}} \geq 3$  and  $p < p_c$ . For  $p > p_c$ , an additional maximum-current phase separated by a second-order phase transition which is similar to ASEP. The application of the DDRG to the NS model is expected to answer the fixed points and the RG flow in the  $\alpha - \beta$  plane as well.

### V. CONCLUSION

In this paper, we investigated the dynamical transition from a free flow state to congested phases in the NS model by using the DDRG. For the deterministic case p = 0, two fully attractive fixed points,  $\rho_c^* = 0$  and 1, and one unstable fixed point,  $\rho_c^* = 1/(v_{\text{max}} + 1)$ , were found. The unstable fixed point corresponds to the critical density where the phase transition occurs. The critical exponent  $\nu$  related to the correlation length was obtained for various  $v_{\rm max}$ . The critical exponent appears to decrease weakly with  $v_{\text{max}}$  from v = 1.62 to an asymptotical value of 1.00. For the stochastic case p > 0, the case  $p \to 0$ was studied with simulation, and the renormalized p that prevents the proliferation of states was used. The RG flow in the  $\rho - p$  plane was obtained and fixed points that govern the driving strategy in the NS model were found. A short discussion on the extension of the current calculation to an open-boundary NS model was outlined.

We believe this work shows the possibility of employing the renormalization-group technique in studying traffic models. For simplicity, the simplest traffic model was used in this study to test the feasibility. It is of interest to extend our calculations to more realistic traffic models, in particular, models that are able to describe the spatiotemporal patterns as delineated in Kerner's traffic theory [36]. Moreover, it would be interesting to classify traffic models based on the critical exponents to existing universality classes, whenever possible. These are among the questions we would like to explore in our future work.

## ACKNOWLEDGMENT

We acknowledge support from Nanyang Technological University, Singapore, under Grant No. M4081583.

<sup>[1]</sup> T. Nagatani, Rep. Prog. Phys. 65, 1331 (2002).

<sup>[2]</sup> D. Helbing, Rev. Mod. Phys. **73**, 1067 (2001).

<sup>[3]</sup> D. Chowdhury, L. Santen, and A. Schadschneider, Phys. Rep. 329, 199 (2000).

- <span id="page-7-0"></span>[4] K. Nagel and M. Schreckenberg, [J. Phys. I](https://doi.org/10.1051/jp1:1992277) **[2](https://doi.org/10.1051/jp1:1992277)**, [2221](https://doi.org/10.1051/jp1:1992277) [\(1992\)](https://doi.org/10.1051/jp1:1992277).
- [5] K. Nagel and M. Paczuski, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.51.2909) **[51](https://doi.org/10.1103/PhysRevE.51.2909)**, [2909](https://doi.org/10.1103/PhysRevE.51.2909) [\(1995\)](https://doi.org/10.1103/PhysRevE.51.2909).
- [6] S. Krauss, P. Wagner, and C. Gawron, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.54.3707) **[54](https://doi.org/10.1103/PhysRevE.54.3707)**, [3707](https://doi.org/10.1103/PhysRevE.54.3707) [\(1996\)](https://doi.org/10.1103/PhysRevE.54.3707).
- [7] R. Barlovic, L. Santen, A. Schadschneider, and M. Schreckenberg, [Eur. Phys. J. B](https://doi.org/10.1007/s100510050504) **[5](https://doi.org/10.1007/s100510050504)**, [793](https://doi.org/10.1007/s100510050504) [\(1998\)](https://doi.org/10.1007/s100510050504).
- [8] S. Krauss, P. Wagner, and C. Gawron, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.55.5597) **[55](https://doi.org/10.1103/PhysRevE.55.5597)**, [5597](https://doi.org/10.1103/PhysRevE.55.5597) [\(1997\)](https://doi.org/10.1103/PhysRevE.55.5597).
- [9] X. Li, Q. Wu, and R. Jiang, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.64.066128) **[64](https://doi.org/10.1103/PhysRevE.64.066128)**, [066128](https://doi.org/10.1103/PhysRevE.64.066128) [\(2001\)](https://doi.org/10.1103/PhysRevE.64.066128).
- [10] M. L. L. Iannini and R. Dickman, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.95.022106) **[95](https://doi.org/10.1103/PhysRevE.95.022106)**, [022106](https://doi.org/10.1103/PhysRevE.95.022106) [\(2017\)](https://doi.org/10.1103/PhysRevE.95.022106).
- [11] B. Eisenblätter, L. Santen, A. Schadschneider, and M. Schreckenberg, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.57.1309) **[57](https://doi.org/10.1103/PhysRevE.57.1309)**, [1309](https://doi.org/10.1103/PhysRevE.57.1309) [\(1998\)](https://doi.org/10.1103/PhysRevE.57.1309).
- [12] L. C. Q. Vilar and A. De Souza, [Phys. A \(Amsterdam, Neth.\)](https://doi.org/10.1016/0378-4371(94)90069-8) **[211](https://doi.org/10.1016/0378-4371(94)90069-8)**, [84](https://doi.org/10.1016/0378-4371(94)90069-8) [\(1994\)](https://doi.org/10.1016/0378-4371(94)90069-8).
- [13] A. Vespignani, S. Zapperi, and V. Loreto, [J. Stat. Phys.](https://doi.org/10.1007/BF02508464) **[88](https://doi.org/10.1007/BF02508464)**, [47](https://doi.org/10.1007/BF02508464) [\(1997\)](https://doi.org/10.1007/BF02508464).
- [14] M. J. de Oliveira and J. E. Satulovsky, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.55.6377) **[55](https://doi.org/10.1103/PhysRevE.55.6377)**, [6377](https://doi.org/10.1103/PhysRevE.55.6377) [\(1997\)](https://doi.org/10.1103/PhysRevE.55.6377).
- [15] A. Vespignani, S. Zapperi, and L. Pietronero, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.51.1711) **[51](https://doi.org/10.1103/PhysRevE.51.1711)**, [1711](https://doi.org/10.1103/PhysRevE.51.1711) [\(1995\)](https://doi.org/10.1103/PhysRevE.51.1711).
- [16] V. Loreto, A. Vespignani, and S. Zapperi, [J. Phys. A](https://doi.org/10.1088/0305-4470/29/12/008) **[29](https://doi.org/10.1088/0305-4470/29/12/008)**, [2981](https://doi.org/10.1088/0305-4470/29/12/008) [\(1996\)](https://doi.org/10.1088/0305-4470/29/12/008).
- [17] A. Schadschneider and M. Schreckenberg, [J. Phys. A](https://doi.org/10.1088/0305-4470/26/15/011) **[26](https://doi.org/10.1088/0305-4470/26/15/011)**, [L679](https://doi.org/10.1088/0305-4470/26/15/011) [\(1993\)](https://doi.org/10.1088/0305-4470/26/15/011).
- [18] M. Schreckenberg, A. Schadschneider, K. Nagel, and N. Ito, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.51.2939) **[51](https://doi.org/10.1103/PhysRevE.51.2939)**, [2939](https://doi.org/10.1103/PhysRevE.51.2939) [\(1995\)](https://doi.org/10.1103/PhysRevE.51.2939).

- [19] A. M. C. Souza and L. C. Q. Vilar, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.80.021105) **[80](https://doi.org/10.1103/PhysRevE.80.021105)**, [021105](https://doi.org/10.1103/PhysRevE.80.021105) [\(2009\)](https://doi.org/10.1103/PhysRevE.80.021105).
- [20] L. P. Kadanoff, [Physics](https://doi.org/10.1103/PhysicsPhysiqueFizika.2.263) **[2](https://doi.org/10.1103/PhysicsPhysiqueFizika.2.263)**, [263](https://doi.org/10.1103/PhysicsPhysiqueFizika.2.263) [\(1966\)](https://doi.org/10.1103/PhysicsPhysiqueFizika.2.263).
- [21] M. Suzuki, [Prog. Theor. Phys.](https://doi.org/10.1143/PTP.51.1257) **[51](https://doi.org/10.1143/PTP.51.1257)**, [1257](https://doi.org/10.1143/PTP.51.1257) [\(1974\)](https://doi.org/10.1143/PTP.51.1257).
- [22] K. Nagel and H. J. Herrmann, [Phys. A \(Amsterdam, Neth.\)](https://doi.org/10.1016/0378-4371(93)90006-P) **[199](https://doi.org/10.1016/0378-4371(93)90006-P)**, [254](https://doi.org/10.1016/0378-4371(93)90006-P) [\(1993\)](https://doi.org/10.1016/0378-4371(93)90006-P).
- [23] N. Moussa, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.71.026124) **[71](https://doi.org/10.1103/PhysRevE.71.026124)**, [026124](https://doi.org/10.1103/PhysRevE.71.026124) [\(2005\)](https://doi.org/10.1103/PhysRevE.71.026124).
- [24] G. Csányi and J. Kertész, [J. Phys. A](https://doi.org/10.1088/0305-4470/28/16/002) **[28](https://doi.org/10.1088/0305-4470/28/16/002)**, [L427](https://doi.org/10.1088/0305-4470/28/16/002) [\(1995\)](https://doi.org/10.1088/0305-4470/28/16/002).
- [25] D. ben-Avraham and J. Köhler, [Phys. Rev. A](https://doi.org/10.1103/PhysRevA.45.8358) **[45](https://doi.org/10.1103/PhysRevA.45.8358)**, [8358](https://doi.org/10.1103/PhysRevA.45.8358) [\(1992\)](https://doi.org/10.1103/PhysRevA.45.8358).
- [26] [A. S. de Wijn, D. M. Miedema, B. Nienhuis, and P. Schall,](https://doi.org/10.1103/PhysRevLett.109.228001) Phys. Rev. Lett. **[109](https://doi.org/10.1103/PhysRevLett.109.228001)**, [228001](https://doi.org/10.1103/PhysRevLett.109.228001) [\(2012\)](https://doi.org/10.1103/PhysRevLett.109.228001).
- [27] See Supplemental Material at [http://link.aps.org/supplemental/](http://link.aps.org/supplemental/10.1103/PhysRevE.97.032314) 10.1103/PhysRevE.97.032314 for movies on the RG flow of the NS model with *v*max = 1 and 2.
- [28] A. Schadschneider, [Eur. Phys. J. B](https://doi.org/10.1007/s100510050888) **[10](https://doi.org/10.1007/s100510050888)**, [573](https://doi.org/10.1007/s100510050888) [\(1999\)](https://doi.org/10.1007/s100510050888).
- [29] M. Henkel and G. Schütz, [Phys. A \(Amsterdam, Neth.\)](https://doi.org/10.1016/0378-4371(94)90124-4) **[206](https://doi.org/10.1016/0378-4371(94)90124-4)**, [187](https://doi.org/10.1016/0378-4371(94)90124-4) [\(1994\)](https://doi.org/10.1016/0378-4371(94)90124-4).
- [30] J. Krug, [Phys. Rev. Lett](https://doi.org/10.1103/PhysRevLett.67.1882) **[67](https://doi.org/10.1103/PhysRevLett.67.1882)**, [1882](https://doi.org/10.1103/PhysRevLett.67.1882) [\(1991\)](https://doi.org/10.1103/PhysRevLett.67.1882).
- [31] J. de Gier and B. Nienhuis, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.59.4899) **[59](https://doi.org/10.1103/PhysRevE.59.4899)**, [4899](https://doi.org/10.1103/PhysRevE.59.4899) [\(1999\)](https://doi.org/10.1103/PhysRevE.59.4899).
- [32] L. Tilstra and M. Ernst, [J. Phys. A](https://doi.org/10.1088/0305-4470/31/22/008) **[31](https://doi.org/10.1088/0305-4470/31/22/008)**, [5033](https://doi.org/10.1088/0305-4470/31/22/008) [\(1998\)](https://doi.org/10.1088/0305-4470/31/22/008).
- [33] T. Hanney and R. B. Stinchcombe, [J. Phys. A](https://doi.org/10.1088/0305-4470/39/47/001) **[39](https://doi.org/10.1088/0305-4470/39/47/001)**, [14535](https://doi.org/10.1088/0305-4470/39/47/001) [\(2006\)](https://doi.org/10.1088/0305-4470/39/47/001).
- [34] S. Cheybani, J. Kertész, and M. Schreckenberg, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.63.016107) **[63](https://doi.org/10.1103/PhysRevE.63.016107)**, [016107](https://doi.org/10.1103/PhysRevE.63.016107) [\(2000\)](https://doi.org/10.1103/PhysRevE.63.016107).
- [35] S. Cheybani, J. Kertész, and M. Schreckenberg, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.63.016108) **[63](https://doi.org/10.1103/PhysRevE.63.016108)**, [016108](https://doi.org/10.1103/PhysRevE.63.016108) [\(2000\)](https://doi.org/10.1103/PhysRevE.63.016108).
- [36] B. S. Kerner, *The Physics of Traffic* (Springer, Berlin, 2004).