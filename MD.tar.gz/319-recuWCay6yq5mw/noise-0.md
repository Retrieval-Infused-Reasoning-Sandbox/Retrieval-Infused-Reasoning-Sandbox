# On Cellular Automata Models of Traffic Flow with Look-Ahead Potential

Cory Hauck <sup>∗</sup> Yi Sun † Ilya Timofeyev ‡

#### Abstract

We study the statistical properties of a cellular automata model of traffic flow with the lookahead potential. The model defines stochastic rules for the movement of cars on a lattice. We analyze the underlying statistical assumptions needed for the derivation of the coarse-grained model and demonstrate that it is possible to relax some of them to obtain an improved coarsegrained ODE model. We also demonstrate that spatial correlations play a crucial role in the presence of the look-ahead potential and propose a simple empirical correction to account for the spatial dependence between neighboring cells.

## Contents

| 1 | Introduction                                                 | 2  |
|---|--------------------------------------------------------------|----|
| 2 | Cellular Automata Model                                      | 3  |
| 3 | A New Mesoscopic Model                                       | 5  |
| 4 | Numerical Experiments                                        | 6  |
|   | 4.1<br>The Stochastic Algorithm<br><br>                      | 7  |
|   | 4.2<br>Assumption A1: Expectation of the Exponential<br><br> | 8  |
|   | 4.3<br>Front Tracking<br><br>                                | 9  |
|   | 4.4<br>Assumption A2: Correlations<br><br>                   | 11 |
|   | 4.5<br>Testing the Entire Closure for the New Model<br>      | 14 |
| 5 | Empirical Correction to the Equation for the Density         | 19 |
|   | 5.1<br>Continuum Limits<br><br>                              | 21 |
| 6 | Discussion and Conclusions                                   | 21 |

<sup>∗</sup>Computer Science and Mathematics Division, Oak Ridge National Laboratory, Oak Ridge, TN 37831 USA, (hauckc@ornl.gov). This author's research was sponsored by the Office of Advanced Scientific Computing Research and performed at the Oak Ridge National Laboratory, which is managed by UT-Battelle, LLC under Contract No. DE-AC05-00OR22725.

<sup>†</sup>Department of Mathematics, University of South Carolina, Columbia, SC 29208, (yisun@math.sc.edu).

Ilya Timofeyev Department of Mathematics, University of Houston, Houston, TX 77204-3008, (ilya@math.uh.edu). This author's research was supported in part by the NSF Grant DMS-1109582.

## <span id="page-1-0"></span>1 Introduction

The derivation of coarse-grained descriptions from microscopic dynamics has been an active area of research for many decades and a vast amount of literature exists addressing this issue in various contexts. In this paper we investigate a particular setup relevant for car traffic modeling. Car traffic models can be roughly divided into the following categories (see review papers [\[3,](#page-21-0) [5,](#page-21-1) [8\]](#page-21-2) and references therein): (i) microscopic car-following models that treat cars as particles and postulate ordinary differential equations (possibly with delay) for the car velocity; (ii) microscopic discrete lattice models where a particular cell configuration with values 1 (car is present) and 0 (car is absent) combined with explicit rules for movement between cells are used to represent traffic flow; (iii) macroscopic partial differential equations models that are typically conservation laws relating the car density and flux; (iv) mesoscopic kinetic models for the velocity distribution, the moments of which gives the macroscopic car density and flux.

While car-following models represent a more realistic setup allowing for very detailed interaction rules, lane changing, switching in behavior, etc., lattice models are simpler to implement and are more amenable to analytical investigation. Therefore, lattice models have been widely used to represent various physical phenomena, including car traffic [\[4,](#page-21-3) [17,](#page-22-0) [20\]](#page-22-1). In addition, such cell models are closely related to the Ising-type models and cellular automata models and, therefore, a vast literature exists addressing various analytical and numerical techniques for models of this type.

One possible use of vehicular traffic models is to utilize filtering techniques to predict the future traffic state. In this context, particle filtering and Kalman filtering for microscopic models has been developed (see e.g. [\[16,](#page-22-2) [21,](#page-22-3) [23\]](#page-22-4)). Typically, although very detailed rules of interaction can be implemented for microscopic models, Monte-Carlo simulations are necessary to estimate statistical properties of car traffic using these models. Such simulations can be very costly computationally and using Ensemble Kalman Filtering in conjunction with coarse-grained models is an attractive computational alternative [\[19,](#page-22-5) [24\]](#page-22-6).

Considerable effort has been devoted to provide the justification of the macroscopic description including derivations of macroscopic models for coarse-grained quantities (e.g. car density) from more basic microscopic models. Recently, a novel look-ahead potential was introduced to model long-range interactions in prototype lattice model, which were then coarse-grained to obtain macroscopic descriptions [\[10–](#page-21-4)[12\]](#page-22-7). In particular, in [\[20\]](#page-22-1) the look-ahead potential was used to model the effect of long-range traffic conditions and a new macroscopic PDE model with non-local interactions was formally derived. Extensions to multi-lane traffic have also been developed [\[1,](#page-21-5) [7\]](#page-21-6).

In this paper we examine the statistical behavior of the cellular automata (CA) model introduced in [\[20\]](#page-22-1) and the basic underlying assumptions used in the derivation of the subsequent coarse-grained model. We demonstrate that while some aspects of the derivation can be improved, assumptions about the approximate independence of the neighboring cells does not hold in general. We also propose a modification of the macroscopic description based on the numerical evidence for the statistical behavior of the microscopic dynamics. Although the new modified macroscopic model is empirical, we demonstrate that it can reproduce the results of the stochastic simulations with remarkable accuracy.

The rest of the paper is organized as follows. In section [2,](#page-2-0) we introduce the CA model, discuss the assumptions about its statistical behavior, and following [\[20\]](#page-22-1), outline the derivation of the mesoscopic and macroscopic models. In section [3](#page-4-0) we described an improved mesoscopic model that is derived by replacing one of the assumptions in [\[20\]](#page-22-1) with an exact calculation. In section [4,](#page-5-0) we present detailed numerical experiments to explore the statistical behavior of the microscopic CA model in various parameter regimes, and in section [5,](#page-18-0) we discuss the empirical correction to the coarse-grained macroscopic PDE that accounts for the spatial correlations at the microscopic level.

<span id="page-2-0"></span>Conclusions are are presented in section 6.

### 2 Cellular Automata Model

In this section, we summarize the cellular automata model given in [20]. The model describes a single class of cars that move in one direction along a single-lane highway. Possible multi-lane and multi-class extensions are considered in [1,7]. The modeled is defined over a one-dimensional lattice  $\mathcal{L} = \{1, \ldots, N\}$  of N > 1 evenly spaced cells, and the state of the system is given by a function  $\sigma: \mathcal{L} \times \mathbb{R}^+ \to \{0,1\}^N$ . For  $t \in \mathbb{R}^+$  and  $k \in \mathcal{L}$ ,

$$\sigma_k(t) = \begin{cases} 1, & \text{if cell } k \text{ is occupied at time } t; \\ 0, & \text{if cell } k \text{ is not occupied at time } t. \end{cases}$$
 (1)

Cars are assumed to move from left to right, and only one car is allowed to occupy a cell at a time. Periodic boundary conditions are imposed so that  $\sigma_{mN+k} = \sigma_k$  for any  $k \in \mathcal{L}$  and any integer m.

Transitions in the state of  $\sigma$  are the mechanism for modeling car movement. They obey the rules of an exclusion process [14]: two lattice sites exchange values in each transition and cars may not move into occupied cells. In addition cars are only allowed to move one cell to the right. Thus the only possible configuration changes are of the form

<span id="page-2-1"></span>
$$\{\sigma_k(t) = 1, \sigma_{k+1}(t) = 0\} \to \{\sigma_k(t + \Delta t) = 0, \sigma_{k+1}(t + \Delta t) = 1\}$$
 (2)

In the simplest case, the transition rate  $c_0 > 0$  is a constant. Thus the configuration change in (2) occurs with probability  $c_0 \Delta t + o(\Delta t)$  for small  $\Delta t$ , and in the absence of other forces, cars move with velocity  $v_0 = hc_0$  on average, where h is the cell width. As the car velocity does not depend on the cell width,  $c_0$  must scale with  $h^{-1}$ .

In [20], the transition rate is given by an Arrhenius-type formula [13] with a look-ahead potential  $J_k$  that depends on values of  $\sigma_l$  for l > k. In this case, the transition rates becomes  $c_0 e^{-\beta J_k}$ , where

<span id="page-2-2"></span>
$$J_k(t) = \frac{1}{M} \sum_{i=1}^{M} \sigma_{k+i+1}(t), \tag{3}$$

 $\beta > 0$  is a parameter describing the strength of the look-ahead interactions, and M is the number of cars to the right of cell k which affect velocity of the car in cell k. The term  $e^{-\beta J_k}$  plays the role of a slowdown factor when the forward car density is high, i.e, when the road is congested. It is also possible to introduce weights into (3) so that cars nearby have a more pronounced effect than those that are further away.

The microscopic model described above can be formulated as a continuous-time Markov chain and the generator of this process can be computed explicitly. It is defined as

$$(A\psi)(t) = \lim_{\Delta t \to 0} \frac{\mathbb{E}\psi(\sigma(t + \Delta t)) - \psi(\sigma(t))}{\Delta t}, \tag{4}$$

where  $\psi$  is any test function and the expectation is taken over all possible transitions between time t and  $t + \Delta t$ . For an arbitrary test function  $\psi$ , the generator is given by

<span id="page-2-3"></span>
$$A\psi = \sum_{k \in \mathcal{L}} c_0 e^{-\beta J_k} \sigma_k [1 - \sigma_{k+1}] \left[ \psi(\sigma^{k,k+1}) - \psi(\sigma) \right] , \qquad (5)$$

where  $\sigma^{k,k+1}$  denotes the lattice configuration  $\sigma$  after an exchange between the cells k and k+1:

$$\sigma_l^{k,k+1} = \begin{cases} \sigma_l , & l \neq k, k+1 ,\\ \sigma_{k+1} , & l = k ,\\ \sigma_k , & l = k+1 . \end{cases}$$
 (6)

The terms  $\sigma_k$  and  $[1 - \sigma_{k+1}]$  in (5) ensure that only configuration changes of the form given in (2) contribute to the sum, i.e., that before a transition can occur, there must be a car in cell k and cell k+1 must be empty.

A coarse grain model is derived by first computing the action of the generator on the test function  $\psi(\sigma) = \sigma_l$ . In this case, the only indices that contribute to the sum in (5) are k = l - 1 and k = l. Thus,  $A\sigma_l$  becomes

$$A\sigma_{l} = c_{0}e^{-\beta J_{l-1}}\sigma_{l-1}[1 - \sigma_{l}] \left[\sigma_{l}^{l-1,l} - \sigma_{l}\right] + c_{0}e^{-\beta J_{l}}\sigma_{l}[1 - \sigma_{l+1}] \left[\sigma_{l}^{l,l+1} - \sigma_{l}\right]$$

$$= c_{0}e^{-\beta J_{l-1}}\sigma_{l-1}[1 - \sigma_{l}] - c_{0}e^{-\beta J_{l}}\sigma_{l}[1 - \sigma_{l+1}]. \tag{7}$$

From the definition of the generator,

$$\frac{d}{dt}\mathbb{E}(\psi) = \mathbb{E}(A\psi), \qquad (8)$$

where  $\mathbb{E}$  is the expectation operator with respect to the probability measure associated with the stochastic process. Thus the evolution equation for  $\rho_k := \mathbb{E}(\sigma_k)$  is given by

<span id="page-3-0"></span>
$$\frac{d}{dt}\rho_k = \mathbb{E}\left(c_0 e^{-\beta J_{k-1}} \sigma_{k-1} (1 - \sigma_k) - c_0 e^{-\beta J_k} \sigma_k (1 - \sigma_{k+1})\right). \tag{9}$$

A mesoscopic model for  $\rho = \{\rho_1, \dots, \rho^N\}$  requires a closure that approximates the right-hand side of (9) by a function of  $\rho$ . In [20], a closure was found under two assumptions:

**A1.** The look-ahead interactions are weak so that  $\mathbb{E}e^{-\beta J_k} \approx e^{-\beta \mathbb{E}J_k}$ .

**A2.** The probability measure on  $\sigma$  is approximately a product measure, i.e.,  $f(\sigma_k = \delta_k, \sigma_l = \delta_l) = f(\sigma_k = \delta_k) f(\sigma_l = \delta_l)$ , where f is the probability density.

Note that Assumption A2 implies, among other things, that  $\sigma_k$  and  $\sigma_l$  are uncorrelated, i.e.

$$\mathbb{E}\left(\sigma_k(t)\sigma_l(t)\right) \approx \mathbb{E}(\sigma_k(t))\,\mathbb{E}\left(\sigma_l(t)\right) \equiv \rho_k \rho_l \tag{10}$$

for  $k \neq l$ . While this weaker condition is sufficient for closure without the look-ahead, independence of higher-order moments is needed for closure with the look-ahead.

Based on the assumptions above, the resulting equation for the density is

<span id="page-3-1"></span>
$$\frac{d}{dt}\rho_k = c_0 e^{-\beta I_{k-1}} \rho_{k-1} (1 - \rho_k) - c_0 e^{-\beta I_k} \rho_k (1 - \rho_{k+1}) , \qquad (11)$$

where

$$I_k = \frac{1}{M} \sum_{i=1}^{M} \rho_{k+i+1}$$

and  $\rho_{mN+j} = \rho_l$  for all integers j.

The validity of the two assumptions above depends on the strength of the look-ahead potential. Assumption A1 implies that  $\beta$  is small, in which case the influence of the look-ahead potential  $J_k$  is weak. Assumption A2 means that  $\sigma_k(t)$  and  $\sigma_{k+i}(t)$  are independent for all i, including the nearest neighbors i = 1, 2. This is somewhat unrealistic even without the look-ahead potential, since the exclusion principle couples the neighboring cells. Nevertheless, our simulations show that without the look-ahead potential the coupling is weak in most situations and the approximate independence assumption is quite plausible. On the other hand, in the presence of a strong look-ahead potential the neighboring cells become very highly anti-correlated. This can be understood as follows: If the length of the look-ahead potential is M, then a car in position k is very likely to be trailed by Mzeros since the probability to move for the car in the position k-M-1 is  $c_0e^{-\beta/M}\Delta t \ll c_0\Delta t$  for large  $\beta$ . Therefore, the probability to move is extremely small, and a car in the position k-M-1is very likely to "wait" for the car in the position k to move. Positive correlations may also occur in some situations with and without the look-ahead potential. We discuss such situations in the numerical experiments in section 4. In summary, assumptions A1 and A2 are plausible if the lookahead interactions are weak ( $\beta \ll 1$ ), but are unlikely to hold if the look-ahead interactions are stronger ( $\beta = O(1)$ ).

A first-order PDE model can be formally derived from the mesoscopic model in the limit  $N \to \infty$ . Let the look ahead distance L and domain length D be fixed; set h = D/N and M = [L/D]N. For  $k \in \{1, ..., N\}$ , let  $x_k = (k - 0.5)h$  denote the center of cell k, and let  $\bar{\rho}^N$  be a smooth function of x and t such that  $\bar{\rho}^N(x_k, t) = \rho_k(t)$ . Define

$$F^{N}(x,t) = e^{-\beta \bar{I}^{N}(x,t)} \bar{\rho}^{N}(x-h,t) [1 - \bar{\rho}^{N}(x,t)].$$
(12)

where  $\bar{I}^N$  is a smooth interpolant of  $I_k$ :

$$\bar{I}^{N}(x) = \frac{1}{M} \sum_{i=1}^{M} \bar{\rho}^{N}(x + (i+1)h) = \frac{1}{L} \int_{0}^{L} \bar{\rho}^{N}(x + y, t) dy + O(h).$$
 (13)

Then with a Taylor expansion of  $F^N$  around  $x_k$ , (11) becomes

$$\frac{\partial}{\partial t}\bar{\rho}^N(x_k,t) = c_0(F^N(x_{k-1},t) - F^N(x_k,t)) = v_0\frac{\partial}{\partial x}F^N(x_k,t) + O(h). \tag{14}$$

One can then formally pass to the limit  $N \to \infty$  while L and D remain fixed. For each fixed  $x \in (0, D)$ , let k = [x/h] so that  $x_k \to x$  as  $h \to 0$  and  $\bar{\rho} = \lim_{N \to \infty} \bar{\rho}^N$  satisfies

<span id="page-4-2"></span>
$$\frac{\partial}{\partial t}\bar{\rho}(x,t) + \frac{\partial}{\partial x}\phi(\bar{\rho}) = 0, \qquad (15)$$

where the non-local flux  $\phi$  is given by

$$\phi(\bar{\rho})(x,t) = v_0 e^{-\frac{\beta}{L} \int_0^L \bar{\rho}(x+y,t)dy} \bar{\rho}(x,t) (1 - \bar{\rho}(x,t)) . \tag{16}$$

# <span id="page-4-0"></span>3 A New Mesoscopic Model

In this section we show the expectation of  $e^{-\beta J_k}$  can be computed exactly so that assumption A1 can be removed. This leads to a slightly improved mesoscopic model for the car density. (However, as in the previous mesoscopic model, assumption A2 is still required to close products.) In particular, A2 allows us to approximate

<span id="page-4-1"></span>
$$\mathbb{E}\left(e^{-\beta J_k}\right) = \mathbb{E}\left(\prod_{i=1}^M e^{-\beta'\sigma_{k+i+1}}\right) \simeq \prod_{i=1}^M \mathbb{E}\left(e^{-\beta'\sigma_{k+i+1}}\right). \tag{17}$$

where  $\beta' = \beta/M$ . We then use the fact that for  $1 \leq l \leq N$  and for any positive integer m,  $(\sigma_l)^m = \sigma_l$ . Simple algebra gives

$$e^{-\beta'\sigma_l} = \sum_{m=0}^{\infty} \frac{(-\beta')^m (\sigma_l)^m}{m!} = 1 + \sigma_l \sum_{m=1}^{\infty} \frac{(-\beta')^m}{m!} = 1 + \sigma_l (e^{-\beta'} - 1).$$
 (18)

Thus the expectation of  $e^{-\beta'\sigma_l}$  is

<span id="page-5-1"></span>
$$\mathbb{E}(e^{-\beta\sigma_l}) = 1 + \mathbb{E}(\sigma_l)(e^{-\beta'} - 1) = 1 + \rho_l(e^{-\beta'} - 1). \tag{19}$$

Substituting (19) into the right hand side of (17) gives

$$\mathbb{E}\left(e^{-\beta J_k}\right) = \prod_{i=1}^{M} \left[1 + \rho_{k+i+1}\left(e^{-\beta'} - 1\right)\right] , \qquad (20)$$

This expression can be used to derive a new mesoscopic model for the car density  $\rho_k(t)$ :

$$\frac{d}{dt}\rho_{k} = c_{0}\rho_{k-1}(1-\rho_{k}) \prod_{i=1}^{M} \left[1 + \rho_{k+i} \left(e^{-\beta'} - 1\right)\right] - c_{0}\rho_{k}(1-\rho_{k+1}) \prod_{i=1}^{M} \left[1 + \rho_{k+i+1} \left(e^{-\beta'} - 1\right)\right],$$
(21)

which can be rewritten as

$$\frac{d}{dt}\rho_{k} = c_{0}\rho_{k-1}(1-\rho_{k})e^{\sum_{i=1}^{M}\log\left[1+\rho_{k+i}\left(e^{-\beta'}-1\right)\right]} - c_{0}\rho_{k}(1-\rho_{k+1})e^{\sum_{i=1}^{M}\log\left[1+\rho_{k+i+1}\left(e^{-\beta'}-1\right)\right]}.$$
(22)

One can easily recover the model in (11) by expanding the exponential and logarithm in (22) to leader order in  $\beta'$ . Indeed, simple Taylor expansions give

<span id="page-5-2"></span>
$$\log \left[ 1 + \rho_{k+i+1} \left( e^{-\beta'} - 1 \right) \right] = -\beta' \rho_{k+i+1} + O(\beta'^2)$$
 (23)

In particular, for fixed  $\beta$  and large M,

$$\sum_{i=1}^{M} \log \left[ 1 + \rho_{k+i+1} \left( e^{-\beta'} - 1 \right) \right] = -\beta I_k + O(M^{-1})$$
 (24)

and since  $M^{-1} = O(h)$  as  $N \to \infty$ , the new mesoscopic model has the same PDE limit as the old one.

# <span id="page-5-0"></span>4 Numerical Experiments

In this section we perform a detailed comparison between the stochastic traffic model and the two mesoscopic models (11) and (22) in various parameter regimes. The new mesoscopic model in (22) provides a better front tracking in some regimes. Nevertheless, as discussed earlier, it still suffers from the same limitation as the old model, namely that look-ahead interactions should be weak so that the measure associate with  $\sigma$  is nearly a product measure. When the look-ahead interactions are weak ( $\beta$  is small), both mesoscopic models perform similarly.

#### <span id="page-6-0"></span>4.1 The Stochastic Algorithm

We use the Metropolis algorithm [15] to simulate the stochastic cellular automata model.<sup>1</sup> Given a time-step  $\delta t$ , we advance the configuration of the lattice during each time-step according to the following algorithm. If a car is present at the position k (i.e.  $\sigma_k(t) = 1$ ) and there is no car at the position k + 1 (i.e.  $\sigma_{k+1}(t) = 0$ ), then the car at the position k can advance with probability  $c_0 e^{-\beta J_k} \delta t$ , where  $J_k$  is the look-ahead potential in (3). Simple pseudo-code for a single time step is given below.

#### Algorithm 1 Metropolis Algorithm (one time step)

```
Require: N, M, t, \beta, \delta t, and \sigma_k(t) for k = 1 : N for k = 1 : N do

if \sigma_k(t) == 1 AND \sigma_{k+1}(t) == 0 then

J_k = \frac{1}{M} \sum_{i=1}^{M} \sigma_{k+i+1}(t)
p = \text{unif}(0,1)
if p < C_0 e^{-\beta J_k} \delta t then
\sigma_k(t + \delta t) = 0
\sigma_{k+1}(t + \delta t) = 1
end if
end if
end for
```

The configuration array  $\sigma_k(t + \delta t)$  is stored separately from  $\sigma_k(t)$ . Thus, changes in the configuration in one part of the lattice do not affect the calculation of  $J_k$  for other indexes in the lattice.

All numerical simulations presented in this paper are ensemble Monte-Carlo simulations and expectations plotted in all Figures are ensemble averages. Given the initial conditions (26), we generate n = 5000 different realizations of  $\sigma$  and estimate the density by the formula

$$\rho(k,t) \approx \frac{1}{n} \sum_{p=1}^{n} \sigma_k^{(p)}(t) , \qquad (25)$$

where the integer p is the realization index. During the course of the simulations, various statistics are recorded in order to make the comparisons presented below.

We perform all experiments using the deterministic "red light" initial condition

<span id="page-6-2"></span>
$$\sigma_k(0) = \begin{cases} 1 & 20 \le k \le K, \\ 0 & K < k \le N, \end{cases} \tag{26}$$

with K = 60. This condition allows us to examine the behavior of the leading rarefaction wave. Many other configurations are possible including those which lead to shock waves. Following [20], we set the cell size to 22 feet. Other parameters in the simulation are  $c_0 = 1/0.23 = 4.3478$  (corresponds to approximately 65 miles/hour) and N = 700. The boundary conditions are periodic, but N is set large enough to ensure that they do not affect the simulations.

<span id="page-6-1"></span><sup>&</sup>lt;sup>1</sup> The Metropolis algorithm was cross-validated with a Kinetic Monte-Carlo algorithm [22]. Several comparisons were made to ensure statistically accurate results.

#### <span id="page-7-0"></span>4.2 Assumption A1: Expectation of the Exponential

We first check that the new mesoscopic model removes the error in the closure assumption A1, i.e. that  $\mathbb{E}(e^{-\beta\sigma_k})\approx e^{-\beta\mathbb{E}\sigma_k}$ . Two representative cases are given in Figures 1: one with  $\beta=0.5$  and M=1 and a second with  $\beta=3$  and M=5. For reference, we include the formula in (19), which is used in the new model. As expected, this formula is exact for all values of  $\beta$  and M. The dependence of the results on  $\beta$  is generic: Assumption A1 is nearly valid for values of  $\beta<1$ , since in this case the powers of  $\beta$  quickly decay in the expansion of the exponential. However, the accuracy of the approximation quickly decreases for larger values of  $\beta$ . Many other parameter values have been tested to confirm this. Roughly speaking, the validity of Assumption 1 appears to be largely independent of the size of M.

![](_page_8_Figure_0.jpeg)

<span id="page-8-1"></span>Figure 1: Comparison of  $\mathbb{E}(e^{-\beta\sigma_k})$  with the closure  $\mathbb{E}(e^{-\beta\sigma_k}) \approx e^{-\beta\mathbb{E}\sigma_k}$  the closure in (19). Note that the solid blue and the red line overlap completely.

#### <span id="page-8-0"></span>4.3 Front Tracking

In our next set of experiments, we investigate how well each of the mesoscopic models tracks the rarefaction front. We consider the look-ahead distance M=5 and vary the strength of the look-ahead interaction  $\beta$ . A comparison of the stochastic simulation and both mesoscopic models is given in Figure 2. In all cases, the bulk of the traffic proceeds faster in the stochastic simulation and the trailing front is less steep, with the new model always outperforming the old one. As expected, the difference between the stochastic and mesoscopic models increases as  $\beta$  is increased.

Indeed, for larger values of β, there is a considerable discrepancy between the stochastic simulations and both mesoscopic models. However, front tracking with the new mesoscopic model [\(22\)](#page-5-2) is still considerably better than with the old model [\(11\)](#page-3-1).

![](_page_9_Figure_1.jpeg)

<span id="page-9-0"></span>Figure 2: Comparison of Simulations of the Stochastic and Mesoscopic Models with the initial condition [\(26\)](#page-6-2). Note that for β = 0.5, the numerical results from the mesoscopic models [\(11\)](#page-3-1) and [\(22\)](#page-5-2) overlap in this regime.

### <span id="page-10-0"></span>4.4 Assumption A2: Correlations

To assess the source of the discrepancy between the microscopic model and the new mesoscopic model in [\(22\)](#page-5-2), we investigate numerically the validity of assumption A2—that the measure associated with σ is (nearly) a product measure. To do this, we examine for small i ≥ 1 the size of the sample Pearson correlation coefficient [\[6\]](#page-21-7):[2](#page-10-1)

$$r_{k,k+i}(t) = \frac{1}{n-1} \sum_{p=1}^{n} \left( \frac{\sigma_k^{(p)}(t) - \bar{\sigma}_k(t)}{s_k(t)} \right) \left( \frac{\sigma_{k+i}^{(p)}(t) - \bar{\sigma}_{k+i}^{(p)}(t)}{s_{k+i}^{(p)}(t)} \right)$$

$$= \frac{\sum_{p=1}^{n} (\sigma_k^{(p)}(t) - \bar{\sigma}_k(t)) (\sigma_{k+i}^{(p)}(t) - \bar{\sigma}_{k+i}^{(p)}(t))}{\sqrt{\sum_{p=1}^{n} (\sigma_k^{(p)}(t) - \bar{\sigma}_k(t))^2} \sqrt{\sum_{p=1}^{n} (\sigma_{k+i}^{(p)}(t) - \bar{\sigma}_{k+i}(t))^2}},$$
(27)

where sk(t) is the standard deviation of the stochastic process at cell k and time t, bars denote sample means, and p indexes the samples.

We compute correlation coefficients for 1 ≤ i ≤ 4 using three sets of parameter values

- 1. β = 0 and M = 0, i.e, no look ahead potential (Figure [3\)](#page-11-0);
- 2. β = 3 and M = 1 (Figure [4\)](#page-12-0);
- 3. β = 3 and M = 2 (Figure [5\)](#page-13-1).

The main conclusion are as follows:

- Without the look ahead, the correlations are relatively weak, except at the trailing front, which shows a moderately strong positive correlation (see columns 2–4 of Figure [3\)](#page-11-0). At early time this correlation is stronger for smaller i, but comparable at later times for i > 1. These correlations occur because any car that is slower than the "main pack" (maximum of the density in Monte-Carlo simulations) will cause cars behind it to also slow down. Since it is very likely that more than one car is slower than the main pack, it produces positive correlations at the trailing front.
- When β is nonzero, the correlations rk,k+<sup>i</sup> depend strongly on the value of i relative to M. For i ≤ M, the correlations are large and negative, with the strongest correlation being at the trailing front. This is due to the look-ahead potential which tends to maintain a spacing of M zeros between cars. For i > M, the correlations are similar in the zero-potential case, especially at longer times.

<span id="page-10-1"></span><sup>2</sup>Note that a zero correlation coefficient is a necessary but not sufficient condition to have a product measure.

![](_page_11_Figure_0.jpeg)

<span id="page-11-0"></span>Figure 3: Left scale: correlation coefficients rk,k+p, 1 ≤ p ≤ 4, for β = 0 and M = 0, i.e., no look ahead potential. Right scale: mean car density,

![](_page_12_Figure_0.jpeg)

<span id="page-12-0"></span>Figure 4: Left scale: correlation coefficients rk,k+p, 1 ≤ p ≤ 4, for β = 3 and M = 1. Right scale: mean car density,

![](_page_13_Figure_0.jpeg)

<span id="page-13-1"></span>Figure 5: Left scale: correlation coefficients  $r_{k,k+p}$ ,  $1 \le p \le 4$ , for  $\beta = 3$  and M = 2. Right scale: mean car density,

#### <span id="page-13-0"></span>4.5 Testing the Entire Closure for the New Model

Next, we test the closure for the right-hand side of the mesoscopic model in (9) with the look-ahead dynamics, but just one car in the look-ahead potential. We select parameters M=1 and  $\beta=3$ , and using sample statistics, test the closure

<span id="page-13-2"></span>
$$\mathbb{E}\left[c_{0}e^{-\beta\sigma_{k+1}}\sigma_{k-1}(1-\sigma_{k})-c_{0}e^{-\beta\sigma_{k+2}}\sigma_{k}(1-\sigma_{k+1})\right] \approx$$

$$c_{0}\left[1+\mathbb{E}\sigma_{k+1}(e^{-\beta}-1)\right]\mathbb{E}\sigma_{k-1}(1-\mathbb{E}\sigma_{k})-c_{0}\left[1+\mathbb{E}\sigma_{k+2}(e^{-\beta}-1)\right]\mathbb{E}\sigma_{k}(1-\mathbb{E}\sigma_{k+1}).$$
(28)

We compare these results to the closure which assumes no look-ahead potential, i.e., we test the closure

<span id="page-14-0"></span>
$$\mathbb{E}\left[c_0 e^{-\beta \sigma_{k+1}} \sigma_{k-1} (1 - \sigma_k) - c_0 e^{-\beta \sigma_{k+2}} \sigma_k (1 - \sigma_{k+1})\right] \approx c_0 \mathbb{E} \sigma_{k-1} (1 - \mathbb{E} \sigma_k) - c_0 \mathbb{E} \sigma_k (1 - \mathbb{E} \sigma_{k+1}).$$
(29)

Results from these experiments are given in Figures 6 and 7, where we have averaged the expressions over five cells to reduce the noisy fluctuations due to the stochastic nature of the equations. It is clear in from Figure 6 that the closure in (28) is more accurate near the trailing front. However, a close inspection of the leading front (see Figure (7)) shows that the closure in (29) does a better job at the leading front. Indeed the closure in (29) underestimates the exact value; consequently not enough cars move with the leading front. This difference is quite subtle, but is observable for times well beyond those give here.<sup>3</sup> Moreover, the effect in the density is quite noticeable. From Figure (8), one may observe the general trend that the closure in (29) leads to better results at the leading front, while the (28) performs better near the trailing front.

<span id="page-14-1"></span><sup>&</sup>lt;sup>3</sup>The difference becomes lost in the noise around time t = 100.

![](_page_15_Figure_0.jpeg)

<span id="page-15-0"></span>Figure 6: Comparison of closures from [\(28\)](#page-13-2) (top line) and [\(29\)](#page-14-0) (middle line) during the course of a stochastic simulation. Data is averaged over five cell intervals to remove noise. The bottom line is the density profile, which is provided as a reference for locating the fronts. The look ahead potential is M = 1.

![](_page_16_Figure_0.jpeg)

<span id="page-16-0"></span>Figure 7: Comparison of closures from [\(28\)](#page-13-2) (top line) and [\(29\)](#page-14-0) (middle line) during the course of a stochastic simulation. Here we plot the differences between the exact closure and the two approximate closures. Thus positive values mean and overestimate of the time derivative. Axes are magnified to allow inspection of the leading front. Data is averaged over five cell intervals to remove noise. The look ahead potential is M = 1.

![](_page_17_Figure_0.jpeg)

<span id="page-17-0"></span>Figure 8: Comparison of the car density in the Monte-Carlo simulations of the stochastic model with β = 3, 6 M = 1, 3 and simulations of the new mesoscopic model and the mesoscopic model without β (i.e. β = 0).

### <span id="page-18-0"></span>5 Empirical Correction to the Equation for the Density

As observed in the previous section, the proposed closure in (28) underestimates the right-hand side of (9). This is also evident from the plots in Figure 8 comparing the Monte-Carlo simulations of the stochastic problem with simulations of the mesoscopic equations. In particular, the bulk of cars behind the leading front not propagate fast enough in the mesoscopic model. This means the effect of the look-ahead dynamics in the proposed closure (28) is too strong.

On the other hand, the right-hand side in (29) (equivalent to setting  $\beta = 0$  in the right-hand side) agrees much closure with the microscopic model. We therefore conjecture that the cross-correlations effectively make the look-ahead parameter,  $\beta$ , in the mesoscopic model smaller. For example in Figure 8, the leading front in the solution of the stochastic model is "in between" the two solutions of the mesoscopic model with and without  $\beta$ .

Based on these observations, we compensate for the error in the right-hand side of (9) by introducing a nonlinear look-ahead parameter  $\beta = \beta \rho_k^d$ , where d is an empirical fitting parameter. Since  $0 \le \rho_k \le 1$  the proposed, nonlinear compensation of the look-ahead dynamics leads to the effective reduction of the look-ahead potential. The resulting mesoscopic model is

<span id="page-18-1"></span>
$$\frac{d}{dt}\rho_{k} = c_{0}\rho_{k-1}(1-\rho_{k})\prod_{i=1}^{M} \left[1 + \rho_{k+i}\left(e^{-\beta'\rho_{k+i}^{d}} - 1\right)\right] 
- c_{0}\rho_{k}(1-\rho_{k+1})\prod_{i=1}^{M} \left[1 + \rho_{k+i+1}\left(e^{-\beta'\rho_{k+i+1}^{d}} - 1\right)\right].$$
(30)

Results comparing the Monte-Carlo simulations of the stochastic model and the simulations of the modified mesoscopic model from (30) are depicted in Figure 9 for four different parameter combinations of  $\beta$  and M. As a reference, these results should be compared to those from Figure 8. At this point, d is a tuning parameter. From experiments, we have found that a "good" choice of d is sensitive to the value of M, but rather insensitive to the value  $\beta$ .

![](_page_19_Figure_0.jpeg)

<span id="page-19-0"></span>Figure 9: Comparison of the car density in the Monte-Carlo simulations of the stochastic model (blue line) and simulations of the mesoscopic model in [\(30\)](#page-18-1) (magenta). The exponent d in [\(30\)](#page-18-1) seems to depend strongly on M, but not on β.

#### <span id="page-20-0"></span>5.1 Continuum Limits

Following the arguments from Sections 2 and 3, it is straightforward to show that the continuum limit for the empirical closure takes the form of the conservation law (15), but with a new flux given by

$$\phi(\bar{\rho})(x,t) = v_0 e^{-\frac{\beta}{L} \int_0^L \bar{\rho}^{d+1}(x+y,t)dy} \bar{\rho}(x,t) (1 - \bar{\rho}(x,t)) . \tag{31}$$

As in [20], one may formally expand the integral in the exponential.<sup>4</sup> To second order, we find

$$\frac{1}{L} \int_0^L \bar{\rho}^{d+1}(x+y,t) dy \approx \bar{\rho}^{d+1}(x) + \frac{L}{2} \frac{\partial}{\partial x} \bar{\rho}^{d+1}(x) + \frac{L^2}{6} \frac{\partial^2}{\partial x^2} \bar{\rho}^{d+1}(x)$$
(32)

so that, via Taylor expansion,

$$e^{-\frac{\beta}{L}\int_0^L \bar{\rho}^{d+1}(x+y,t)dy} \approx e^{-\beta\bar{\rho}^{d+1}(x)} \left(1 - \frac{\beta L}{2} \frac{\partial}{\partial x} \bar{\rho}^{d+1}(x) - \frac{\beta L^2}{6} \frac{\partial^2}{\partial x^2} \bar{\rho}^{d+1}(x)\right)$$
(33)

This gives the following local, continuum model

$$\bar{\rho}_t + \left(e^{-\beta\bar{\rho}^{d+1}}\bar{\rho}(1-\bar{\rho})\right)_x = \frac{\beta L}{2} \left(\bar{\rho}(1-\bar{\rho})e^{-\beta\bar{\rho}^{d+1}}(\bar{\rho}^{d+1})_x\right)_x + \frac{\beta L^2}{6} \left(\bar{\rho}(1-\bar{\rho})e^{-\beta\bar{\rho}^{d+1}}(\bar{\rho}^{d+1})_{xx}\right)_x$$
(34)

which introduces an additional layer of nonlinearity to the models presented in [20]. We note, however, that the proceeding derivation is completely formal. In particular, it assumes that solutions are smooth and that the error in the Taylor series expansions are small.

### <span id="page-20-1"></span>6 Discussion and Conclusions

In the paper, we have examined in detail the cellular automata (CA) traffic model introduced in [20], including a host of numerical experiments performed on a rarefaction wave evolving from a "red-light" initial condition. The work in [20] included mesoscopic (ODE) and continuum (PDE) approximations of the cellular automata model. For the mesoscopic model, two assumptions are required. The first of these has been removed in the current paper, leading to an improved model at the ODE level, but with the same PDE in the continuum limit. Since the look-ahead potential conidered here have also been used in other contexts [9,12,18], the improved mesoscopic model can lead to significant improvements in other areas.

The second assumption used in [20] to derive the mesoscopic model is based on the independence of spatial neighbors in the stochastic process defined by the CA model. We have shown numerically, that such an assumption does not hold for strong look-ahead potentials and moreover, that the correlations effectively weaken the effect of the look ahead potential at the macroscopic level. We conjecture that this effect is density dependent and introduce an ad-hoc macroscopic parameter which scales like a power law in the density. The choice of the exponent in the power law was determined experimentally and found to depend strongly on the look ahead distance M. However, for a given M, the exponent behaves quite well for different  $\beta$  and over long time scales. Finally, using this new ad-hoc model, we have derived nonlinear variants of the known, local continuum models derived from the non-local continuum model in [20]. (See also Section 2.)

<span id="page-20-2"></span><sup>&</sup>lt;sup>4</sup> This is done for a general potential in [20]; here we consider only the constant potential  $\beta$ .

We see three avenues for future work. First is the need to explore the generality of the numerical results presented here. Certainly a complete repeat of the experiments in the current paper should be done for a jam—that is, the movement of faster cars at low density into a slower, higher-density regime. For a continuum hyperbolic model, this would correspond to a shock. The second issue to explore is the relationship between the exponent d and the look ahead distance M. While the existence of such a relationship can be inferred by our numerical experiments, a formula would prove quite useful in practice. Finally, for engineering purposes like traffic microscopic models are not computationally practical. A possible alternative is to use filtering [\[2\]](#page-21-9), where the macroscopic or mesoscopic models are corrected in real-time using measurements. Such an approach has already been investigated, for example, in [\[16,](#page-22-2) [21,](#page-22-3) [23\]](#page-22-4).

Acknowledgements. The work presented in this paper emerged as a result of discussions in a working group at the NSF funded Statistical and Applied Mathematical Sciences Institute. I. Timofeyev also acknowledges support from SAMSI as a long-term visitor in the Fall of 2010 and the Fall of 2011.

## <span id="page-21-5"></span>References

- [1] T. Alperovich and A. Sopasakis, Stochastic description of traffic flow, Journal of Statistical Physics, 133 (2008), pp. 1083–1105.
- <span id="page-21-9"></span><span id="page-21-0"></span>[2] B. D. O. Anderson and J. B. Moore, Optimal Filtering, Dover, Mineola, New York, 205.
- [3] N. Bellomo and C. Dogbe, On the modeling of traffic and crowds: A survey of models, speculations, and perspectives, SIAM Review, 53 (2012), pp. 409–463.
- <span id="page-21-3"></span>[4] B. Chopard, P. O. Luthi, and P.-A. Queloz, Cellular automata model of car traffic in a two-dimensional street network, J. Phys. A: Math. Gen., 29(10) (1996), p. 2325.
- <span id="page-21-1"></span>[5] D. Chowdhury, L. Santen, and A. Schadschneider, Statistical physics of vehicular traffic and some related systems, Physics Reports, 329 (2000), pp. 199–329.
- <span id="page-21-7"></span>[6] J. L. Devore, Probability and Statistics for Engineering and the Sciences, Brooks/Cole, Boston, 2011.
- <span id="page-21-6"></span>[7] N. Dundon and A. Sopasakis, Stochastic modeling and simulation of multi-lane traffic, Transportation and Traffic Theory, (2006), pp. 661–691.
- <span id="page-21-8"></span><span id="page-21-2"></span>[8] D. Helbing, Traffic and related self-driven many-particle systems, Rev. Mod. Phys., 73 (2001), pp. 1067–1141.
- [9] E. Kalligiannaki, M. A. Katsoulakis, P. Plechac, and D. G. Vlachos, Multilevel coarse graining and nano-pattern discovery in many particle stochastic systems, Journal of Computational Physics, 231 (2012), pp. 2599 – 2620.
- <span id="page-21-4"></span>[10] M. Katsoulakis, A. Majda, and A. Sopasakis, Multiscale couplings in prototype hybrid deterministic/stochastic systems: Part I, deterministic closures, Comm. Math. Sci., 2 (2004), pp. 255–294.
- [11] , Multiscale couplings in prototype hybrid deterministic/stochastic systems: Part II, stochastic closures, Comm. Math. Sci., 3 (2005), pp. 453–478.

- <span id="page-22-9"></span><span id="page-22-7"></span>[12] B. Khouider, A. J. Majda, and M. A. Katsoulakis, Coarse-grained stochastic models for tropical convection and climate, Proc. Natl. Acad. Sci., 100 (2003), pp. 11941–11946.
- <span id="page-22-8"></span>[13] K. J. Laidler, Chemical Kinetics, Harper Collins Publishers, New York, third ed., 1987.
- <span id="page-22-10"></span>[14] T. D. Liggett, Interacting Particle Systems, Springer, Berlin, 1985.
- [15] N. Metropolis, A. W. Rosenbluth, M. N. Rosenbluth, A. H. Teller, and E. Teller, Equation of State Calculations by Fast Computing Machines, J. Chem. Phys., 21 (1953), pp. 1087–1092.
- <span id="page-22-2"></span>[16] L. Mihaylova and R. Boel, A particle filter for freeway traffic estimation, in Proceedings of the 43th IEEE Conference on Decision and Control, Atlantis, Bahamas, vol. 2, 2004, pp. 2106 – 2111.
- <span id="page-22-12"></span><span id="page-22-0"></span>[17] K. Nagel, D. E. Wolf, P. Wagner, and P. Simon, Two-lane traffic rules for cellular automata: A systematic approach, Physical Review E, 58(2) (1998), pp. 1425–1437.
- <span id="page-22-5"></span>[18] Y. Pantazis and M. Y. Katsoulakis, Controlled-Error Approximations for Surface Diffusion of Interacting Particles with Applications to Pattern Formation, ArXiv e-prints, (2011).
- [19] T. Schreiter, C. van Hinsbergen, F. Zuurbier, H. van Lint, and S. Hoogendoorn, Data-model synchronization in extended Kalman filters for accurate online traffic state estimation, in Proceedings of the Traffic Flow Theory Conference, Annecy, France, 2010.
- <span id="page-22-1"></span>[20] A. Sopasakis and M. A. Katsoulakis, Stochastic modeling and simulation of traffic flow: Asymmetric single exclusion process with arrhenius look-ahead dynamics, SIAM Journal on Applied Mathematics, 66 (2006), pp. 921–944.
- <span id="page-22-3"></span>[21] X. Sun, L. Munoz, and R. Horowitz, Highway traffic state estimation using improved mixture kalman filters for effective ramp metering control, in Proceedings of the 42nd IEEE Conference on Decision and Control, Maui, Hawaii, 2003.
- <span id="page-22-11"></span>[22] A. F. Voter, Introduction to the kinetic monte carlo method, in Radiation Effects in Solids, K. E. Sickafus, E. A. Kotomin, and B. P. Uberuaga, eds., vol. 235 of NATO Science Series, Springer Netherlands, 2007, pp. 1–23.
- <span id="page-22-4"></span>[23] Y. Wang and M. Papageorgiou, Real-time freeway traffic state estimation based on extended Kalman filter: a general approach, Transportation Research Part B: Methodological, 39 (2005), pp. 141 – 167.
- <span id="page-22-6"></span>[24] D. Work, O.-P. Tossavainen, S. Blandin, A. Bayen, T. Iwuchukwu, and K. Tracton, An ensemble Kalman filtering approach to highway traffic estimation using GPS enabled mobile devices, in Proceedings of the 47th IEEE Conference on Decision and Control, Cancun, Mexico, 2008, pp. 5062–5068.