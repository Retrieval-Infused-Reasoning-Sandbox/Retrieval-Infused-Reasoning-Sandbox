# Dynamic Prediction of Vehicle Cluster Distribution in Mixed Traffic: A Statistical Mechanics-Inspired Method

Kshitij Jerath, Member, IEEE, Asok Ray, Fellow, IEEE, Sean Brennan, Member, IEEE, and Vikash V. Gayah

Abstract—The advent of intelligent vehicle technologies holds significant potential to alter the dynamics of traffic flow. Prior work on the effects of such technologies on the formation of selforganized traffic jams has led to analytical solutions and numerical simulations at the mesoscopic scale, which may not yield significant information about the distribution of vehicle cluster size. Since the absence of large clusters could be offset by the presence of several smaller clusters, the distribution of cluster sizes can be as important as the presence or absence of clusters. To obtain a prediction of vehicle cluster distribution, the included work presents a statistical mechanics-inspired method of simulating traffic flow at a microscopic scale via the generalized Ising model. The results of the microscopic simulations indicate that traffic systems dominated by adaptive cruise control (ACC)-enabled vehicles exhibit a higher probability of formation of moderately sized clusters, as compared with the traffic systems dominated by human-driven vehicles; however, the trend is reversed for the formation of large-sized clusters. These qualitative results hold significance for algorithm design and traffic control because it is easier to predict and take countermeasures for fewer large localized clusters as opposed to several smaller clusters spread across different locations on a highway.

Index Terms—Intelligent vehicles, traffic control, road transportation, self-organization, driver behavior, Potts model.

#### I. Introduction

THE appearance of traffic jams in the form of selforganized vehicular clusters on highways has been a topic of significant interest in recent decades. One reason for the continued interest in this field is that the formation of selforganized clusters is a fairly common phenomenon which occurs across a wide range of fields, including nucleation in binary alloys, herding behavior of organisms (such as in a

Manuscript received September 26, 2014; revised December 18, 2014; accepted February 27, 2015. Date of publication March 23, 2015; date of current version September 25, 2015. The Associate Editor for this paper was F.-Y. Wang.

- K. Jerath and A. Ray are with the Department of Mechanical and Nuclear Engineering, The Pennsylvania State University, University Park, PA 16802 USA, and also with the Department of Electrical Engineering, The Pennsylvania State University, University Park, PA 16802 USA (e-mail: kjerath@outlook.com; axr2@psu.edu).
- S. Brennan is with the Department of Mechanical and Nuclear Engineering, The Pennsylvania State University, University Park, PA 16802 USA (e-mail: sbrennan@psu.edu).
- V. V. Gayah is with the Department of Civil and Environmental Engineering, The Pennsylvania State University, University Park, PA 16802 USA (e-mail: gayah@engr.psu.edu).
- Color versions of one or more of the figures in this paper are available online at http://ieeexplore.ieee.org.

Digital Object Identifier 10.1109/TITS.2015.2409798

school of fish), and transport of granular media [1]. However, the primary reason for the continued interest in self-organized vehicle clusters occurring in highway traffic (or simply self-organized traffic jams) is the expected societal impact of alleviating congestion. Recent reports have indicated that there are increasing disparities between highway capacity and vehicular population [2], and that highway congestion is on the rise [3]. Additionally, congestion in the US has associated annual costs in excess of 100 billion dollars (in 2011 dollars) [3]. The study of formation of self-organized vehicle clusters and analysis of strategies that may limit their persistence has the potential to significantly benefit the society.

One potential strategy to tackle congestion has arisen with the advent of intelligent vehicle technologies. Self-organized traffic jams typically form due to imperfections in the reaction of human drivers to medium and high density traffic. Intelligent driver algorithms, such as adaptive cruise control (ACC) systems, that can better govern the movement of individual vehicles in a traffic stream, may have the potential to significantly impact vehicular cluster formation [4]. Traditionally, microscopic numerical simulations have served well to provide some insight into traffic flow dynamics as a function of driver behaviors [5]. These simulation approaches utilize models that represent the driving behavior of humans to varying degrees of accuracy. However, some approaches, such as the cellular automata (CA) or totally asymmetric simple exclusion process (TASEP) models, significantly simplify the driver behavior to rules that are independent of physical interpretation of model parameters [6], [7]. Other approaches, such as those that use detailed car-following models (e.g., General Motors [8] or optimal velocity models [9]), may cause the simulations to be computationally expensive and memory intensive. Consequently, it is desirable to have a simulation approach that is more detailed than CA or TASEP models and builds upon physical principles, while simultaneously being computationally amenable to parametric studies. The generalized Ising model provides such an approach. The included study builds upon work presented in [10], [11] and utilizes the simple, yet immensely popular Ising model and its generalized forms to study traffic flow and vehicle cluster dynamics as a function of ACC penetration.

The remainder of the paper is organized as follows. Section II discusses previous research that has addressed the formation of self-organized traffic jams from a statistical mechanics perspective. This section also describes previous research on the effects of intelligent driver algorithms on traffic dynamics.

Section III sets up the problem with known parameters values typically used to represent the state of highway traffic flow. Section IV presents the bulk of the novel work where traffic flow is modeled as a driven lattice gas using the generalized Ising model. The evolution of self-organized traffic jams is then shown to manifest as a non-equilibrium process in the presence of an external field with repulsive interactions between vehicles. Section V describes the Monte-Carlo simulations as well as the calibration of the generalized Ising model, and Section VI summarizes the results of the study. In the remainder of this work, the term "ACC-enabled" and "computer algorithmdriven" will be used interchangeably.

#### II. LITERATURE REVIEW

While the study of traffic flow dynamics is a rich and vibrant field, statistical mechanics-based approaches to address the problem have received less attention than others. In the following subsections, prior statistical mechanics-based techniques to study traffic flow dynamics are discussed, and some attention is also directed towards existing works that have studied the effect of driver algorithms on traffic flow.

#### *A. Statistical Mechanics-Based Techniques*

One of the earliest attempts to use statistical mechanics to study traffic flow dynamics dates back to the work of Prigogine and Andrews in 1960, who modeled traffic flow using the kinetic theory of gases [12]. For a long period after their work, statistical mechanics was not used within the transportation research community, but recently these approaches have witnessed a resurgence [10], [13]–[15]. However, in the context of analyzing changes in traffic flow dynamics as a consequence of driver behavior, these techniques have primarily been limited to single species environments [4], [11]. The work presented here extends the statistical mechanics-based approach to a multispecies environment that can model both human-driven and ACC-enabled vehicles via the use of the generalized Ising model (or the Potts model). The generalized Ising model presented here provides better simulation fidelity (as compared to CA or TASEP models), while operating with reduced computational complexity (as compared to numerical simulations with carfollowing models).

#### *B. Studies on Effects of Driver Algorithms on Traffic Flow*

On the other hand, the transportation research community has pooled significant resources to evaluate the effects of introducing computer algorithm-driven vehicles into the traffic stream. A considerable portion of these resources have been allocated towards designing algorithms for tightly-controlled vehicle platoons [16], and analyzing the effects of lead vehicle maneuvers on the stability of the platoon [17]. However, as intelligent vehicle technologies such as connected vehicles and adaptive cruise control make their way to mainstream passenger vehicles, the traffic stream of the near future may consist of randomly interspersed human-driven and computer algorithm-driven vehicles. Realizing the importance of such a transition period where the vehicular population undergoes a demographic shift, recent work has begun to focus on randomly mixed traffic systems.

Studies of mixed traffic scenarios in recent times have yielded interesting results. For example, previous work by Jerath indicates that increasing ACC penetration can result in higher critical densities at which vehicle clusters first begin to form [14]. However, this work is limited by the fact that it has been performed for single clusters and consequently does not yield information about cluster distribution. On the other hand, numerical simulations have been performed at microscopic scales using car-following models to suggest that increasing penetration rates can potentially increase capacity [5]. The statistical mechanics-based approach utilized in the presented work seeks to offer alternatives that may have a lower computational burden compared to microscopic simulations with detailed car-following models, while simultaneously providing deeper insights into the statistics of self-organized traffic jams.

#### *C. Limitations of the Ising Model*

The statistical mechanics-based approach proposed by Sopasakis and his colleagues models traffic flow using the Ising model, and as such is limited in its predictive capacity by the limitations of the Ising model itself [10]. Specifically, the possible states σ that a site in the Ising model can assume is limited to two. In other words, in an Ising model formulation, a site on a road can either be empty (σ = 0) or be occupied by a vehicle (σ = 1). However, if additional states are required, such as when studying traffic systems with more than one type of driver algorithm, the Ising model needs to be extended for the analysis. Fortunately, there exist extensions of the Ising model—such as the generalized Ising model in which a site can assume any integer number of states—which can be used to model mixed traffic systems. Details about the two-state Ising model are provided in the Appendix.

#### III. PROBLEM SETUP

This section discusses the problem setup, which is essentially an exercise in establishing variables that describe the physical system, i.e. traffic, and relating them to model parameters in the generalized Ising model.

#### *A. Traffic System Description*

In order to study the effects of driver algorithms on vehicle cluster formation, a traffic system is often idealized as a singlelane closed ring-road without on- or off-ramps. While a road with open boundary conditions, i.e. with on- and off-ramps, may better represent reality, the closed ring-road idealization of the traffic system enforces periodic boundary conditions and greatly simplifies the ensuing analysis and simulations [14]. The closed ring-road is assumed to be of length L and is occupied by M vehicles. The vehicles are assumed to be physically identical with length of d<sup>v</sup> = 5.5 m, and maintain a safe spacing of d<sup>0</sup> = 2.5 m when stationary. Consequently, the spatial extent occupied by each vehicle when it is stationary is given by d<sup>s</sup> = d<sup>v</sup> + d<sup>0</sup> = 8 m. Later, some of these vehicles will be modeled as being driven by humans, whereas other will be modeled as being driven by computer algorithms.

Next, the typical traffic system is described quantitatively by some commonly observed traffic parameters, which are known to be representative of single-lane highways [18]. The free flow velocity (v<sup>f</sup> ), which is the speed of vehicles at low densities, is assumed to be 25 m/s (or 90 km/h). The maximum flow of vehicles in the lane, or lane capacity, (qmax) is assumed to be 1800 veh/h. The backward wave speed (u), which represents the speed at which a wave propagates backwards in the traffic stream, is assumed ot be −6 m/s (or −19.6 km/h). The next subsection discusses the specific prerequisites and model structure needed to analyze the system using the generalized Ising model.

## *B. Space Partitioning and Lattice Structure of Traffic System*

As a first step towards modeling the system, the roadway is partitioned into individual non-overlapping sites, so that the sites span the entire length L of the roadway. This process is known as **space partitioning** and results in the partition S = {s1, s2,...,s<sup>N</sup> } of the road such that

$$\bigcup_{i=1}^{N} s_i = S \text{ and } s_i \bigcap_{i \neq j} s_j = \phi$$
 (1)

where s<sup>i</sup> denotes the ith site on the road, and φ denotes the empty set. In the presented work, the length of each site is assumed to be ds(= d<sup>v</sup> + d0), i.e. the space occupied by a vehicle when it is stationary. Thus, if the roadway is occupied at maximum density, it would result in stationary vehicles parked a distance d<sup>0</sup> away from each other, and occupying a total space of N(d<sup>v</sup> + d0) = L. The maximum density is referred to as *jam density* (kjam) in the traffic flow literature [18]. Other values for the length of an individual site are also possible, but the current value (d<sup>s</sup> = 8 m) is chosen since it makes physical sense and also corresponds directly to the jam density (kjam = 1/ds), a physically observable quantity. The collection of sites on the ring road forms a one-dimensional *lattice structure*, where the terminology is borrowed from studies of various physical systems [19].

The next step in the problem setup addresses a framework for assigning the **system microstate**, so that its evolution can be tracked during numerical simulations. Specifically, this requires assigning a state σ<sup>i</sup> to each individual site s<sup>i</sup> ∈ S. Since the goal of this work is to analyze mixed traffic flow, a specific site s<sup>i</sup> can be in one of three states, i.e., σ<sup>i</sup> ∈ Σ = {0, 1, 2}. It is assumed that σ<sup>i</sup> = 0 represents a site that is vacant, σ<sup>i</sup> = 1 represents a site that is occupied by a human-driven vehicle, and σ<sup>i</sup> = 2 represents a site that is occupied by an ACC-enabled vehicle [4]. A schematic representation of the partitioning of the ring road is included in Fig. 1. The vehicles are assumed to travel in the direction of reducing site numbers, as indicated by the arrow in the figure.

The system microstate then encapsulates the state information of all N sites as a vector *σ* = {σ1, σ2,...,σ<sup>N</sup> }. Given the space partition S = {s1, s2,...,s<sup>N</sup> } of the system and the set of states Σ = {0, 1, 2} that each individual site can assume,

![](_page_2_Figure_10.jpeg)

Fig. 1. Discretized version of traffic system for statistical mechanics-based numerical analysis. Arrow indicates direction of travel. Vehicles travel in direction of reducing site number. Three states, σ<sup>i</sup> ∈ Σ = {0, 1, 2}, are possible for each site in accordance with the generalized Ising model approach.

the total number of possible microstates of the traffic system is given by |Σ| <sup>|</sup>S<sup>|</sup> = 3<sup>N</sup> . The microstate contains complete information of the entire system at any given instant of time. The next section builds upon the microstate and lattice structure discussed here to create a framework for simulating the traffic system.

# IV. GENERALIZED ISING MODEL FORMULATION

In this section, a simulation framework that can mimic the dynamics of a single-lane closed ring-road system is developed. As mentioned earlier in Section II-C, while the Ising model allows for a statistical mechanics-based treatment of the formation of traffic jams, it does not allow for distinguishing between different driver behaviors. In the following work, the use of the generalized Ising model removes this limitation and allows us to conduct a numerical analysis of the effects of different driver behaviors on the formation of self-organized vehicle clusters, or traffic jams. In the following subsections, the model parameters that help distinguish between driver algorithms, as well as the means to simulate the system microstate dynamics, will be discussed in detail.

One of the foundational constructs of the generalized Ising model, and statistical mechanics in general, is the idea of the **Hamiltonian**. The Hamiltonian represents the energy of the system in any given microstate, and consequently can be used to determine system dynamics with appropriate energybased evolution schemes. The expression for the Hamiltonian is given by

$$H(\boldsymbol{\sigma}) = -B \sum_{i=1}^{N} \sigma_i - \sum_{\langle i,j \rangle} J_{ij} \sigma_i \sigma_j$$
 (2)

where  $j \neq i$  and  $i, j \in \{1, 2, ..., N\}$ . In the expression, B represents an external field that is acting on the entire system,  $J_{ij}$  represents the interaction strength between sites i and j, and  $\langle i, j \rangle$  represents a pair of neighboring sites (i.e., j = i - 1 or j = i + 1).

Now, in a traffic system, drivers do not typically interact with every other driver on the road. Drivers, either human or computer algorithms, are often privy to only local information up to a certain 'look-ahead' distance  $(d_l)$  downstream of their location. In the current context of analyzing traffic flow dynamics, this implies that interactions between sites on the road are restricted to a few downstream sites within a defined neighborhood. Mathematically, the forward-looking neighborhood  $\mathcal{N}(s_i)$  can be expressed as

$$\mathcal{N}(s_i) = \{s_j : d(s_i, s_j) \le d_l, j < i\}$$
(3)

where  $d(s_i,s_j)=|(i-j)d_s|$  denotes the distance between sites  $s_i$  and  $s_j$ , and  $d_s$  is the size of an individual site. Note that the neighborhood  $\mathcal{N}(s_i)$  does not include sites upstream from the site  $s_i$ , i.e., sites for which j>i. Also note that due to the closed ring structure, the neighborhood for numbered sites such as  $s_1$  is appropriately re-defined to include forward-looking sites such as  $s_N, s_{N-1}, s_{N-2}$ , and so on. Thus, to reflect our understanding that driver response is localized in nature, the Hamiltonian can be re-framed for the current context to read as

$$H(s_i) = -B\sigma_i - \sum_{s_j \in \mathcal{N}(s_i)} J_{ij}\sigma_i\sigma_j \tag{4}$$

where  $H(s_i)$  denotes the energy associated with a particular site  $s_i$  and is a function of the state of the neighboring "lookahead" sites only. The site-based Hamiltonian  $H(s_i)$  governs the probability of a vehicle moving from one site to another. A key differentiating feature between the TASEP models mentioned in Section I and the statistical mechanics-inspired model presented here is that the latter uses a site-based Hamiltonian determine the system evolution. Specifically, the components of the Hamiltonian such as the external field and interaction strength can be related to physical processes, which helps provide meaning to the probability with which a vehicle moves forward. This is quite unlike the TASEP models which, though simple and useful, make it relatively difficult to relate hopping probabilities to physical processes. The next few subsections discuss details about the Hamiltonian, its individual components (i.e., the external field and interaction strength), and how it can be used to determine system dynamics.

#### A. External Field

The role of the external field in traffic flow dynamics can be understood by drawing parallels between Prigogine's original interpretation of traffic flow based on the kinetic theory of gases and the expression presented in (4). In Prigogine's gas kinetic theory of traffic flow, competing forces are at play that push and repel vehicles [12]. The external field corresponds to Prigogine's "relaxation" term and is the driving force that "pushes" vehicles forward. The stronger the external field, the

greater the tendency of the vehicles to keep moving forward. The external field acts equally on all vehicles, irrespective of whether they are driven by humans or computer algorithms (i.e., ACC enabled). However, the states of sites occupied by human-driven vehicles ( $\sigma_i = 1$ ) and those occupied ACC-enabled vehicles ( $\sigma_i = 2$ ) are different by design. Thus, the expression for the field may be altered slightly as follows:

$$B = \begin{cases} B_0, & \text{if } \sigma_i = 1\\ B_0/2, & \text{if } \sigma_i = 2 \end{cases}$$
 (5)

so that the field component of the Hamiltonian is equal in both cases, i.e.,  $B\sigma_i=B_0>0$ , irrespective of the state  $\sigma_i$  of the site  $s_i$ . Here, the parameter  $B_0$  can be related to the speed limit of the roadway. From a physical perspective, a high value of the external field parameter  $B_0$  corresponds to a larger driving force acting on the system which, in turn, can be said to correspond to a higher speed limit. This relation is made evident when the model is calibrated in Section V-A.

#### B. Interaction Strength

The role of the interaction strength on traffic flow dynamics can also be understood by reviewing Prigogine's gas kinetic theory of traffic flow. Specifically, the interaction strength  $J_{ij}$  is representative of the "collision" term in Prigogine's work and is a measure of "repulsion" faced by vehicles as they approach another vehicle [12]. The greater the magnitude of the interaction term between a vehicle and a preceding vehicle, the slower it will approach that preceding vehicle. To produce a repulsive effect with downstream vehicles, the interaction strength must be negative, i.e.  $J_{ij} < 0$ , for j < i. As interaction with upstream vehicles is not considered, so  $J_{ij} = 0$  for j > i. The precise nature of the interactions is assumed to follow an inverse-square law as follows:

$$J_{ij} = \begin{cases} \frac{J_0}{(d(s_i, s_j))^2}, & \text{if } s_j \in \mathcal{N}(s_i) \\ 0, & \text{otherwise} \end{cases}$$
 (6)

where the interaction coefficient  $J_0$  is a constant, and  $d(s_i, s_j)$  represents the distance between sites as discussed earlier in Section IV. The inverse-square law representation for the interaction strength chosen here is in accordance with prior work [20], which has shown that such interactions produce long range order via a continuous phase transition in the one-dimensional Potts model, similar to the phase transitions observed in traffic flow [21]. Other interaction laws, such as where the interaction strength is inversely proportional to the distance between the sites, yield discontinuous (or first-order) phase transitions, which are uncharacteristic of traffic flow [20], [22].

From a physical perspective, the interaction coefficient  $J_0$  can be related to driver sensitivity or alertness. An alert driver, such as a computer algorithm, may respond sooner to the presence of a cluster downstream, and may correspondingly have a higher magnitude of the interaction coefficient as compared to an inattentive driver, such as a distracted human. In the

![](_page_4_Figure_2.jpeg)

Fig. 2. Interaction coefficients for vehicles determined using differences in local density. Dashed box denotes the neighborhood for the respective vehicles. (a) Difference in local density is negative for a vehicle (circled) entering a cluster. (b) Difference in local density is positive for a vehicle (circled) exiting a cluster.

next subsection, the use of interaction strength to model driver behaviors and algorithms is discussed in more detail.

#### C. Modeling Driver Behavior via Interactions

It is known that the behaviors of vehicles when they are accelerating from rest [23] or decelerating to a stop [24] are quite different. Consequently, the interaction coefficients for vehicles entering or exiting a cluster are designed to be different as well, and are postulated to be

$$J_0 = \begin{cases} J_{\text{in}}, & \text{if } k_i - k_l < 0\\ J_{\text{out}}, & \text{if } k_i - k_l > 0 \end{cases}$$
 (7)

where  $J_{\rm in} < 0$  represents the interaction coefficient for vehicles entering a region of higher local density,  $J_{\rm out} < 0$  represents the interaction coefficient for vehicles exiting a region of higher local density,  $s_l$  is the nearest occupied site within the neighborhood  $\mathcal{N}(s_i)$ , i.e.  $\sigma_l \neq 0$ , and  $k_i$  denotes the dimensionless local density at site  $s_i$ , and is defined as

$$k_i = \frac{1}{|\mathcal{N}(s_i)|} \sum_{s_j \in \mathcal{N}(s_i)} \mathbb{1}_{\mathcal{N}(s_i)}(s_j)$$
 (8)

where  $|\mathcal{N}(s_i)| = \mathcal{N}$  represents the cardinality of the neighborhood set, and  $\mathbb{1}_A(\cdot)$  represents the indicator function for elements belonging to the set A. The use of the local density to determine the interaction coefficient can be better understood by using Fig. 2 as an aid. The dimensionless local density represents the density of vehicles present in the neighborhood of a particular site. In the scenario where the local density  $k_l$  at site  $s_l$  is neither greater nor less than the local density  $k_l$  at site  $s_l$ , the interaction coefficient is chosen randomly with uniform distribution.

Now, the key innovation of the presented work is the ability to model various driver algorithms and behavior, and observe their effects on the formation of vehicle clusters, within a statistical mechanics framework. Different driver behaviors are implemented by changing the manner in which vehicles interact with one another. Consider that a computer algorithm is designed so that it attempts to avoid contributing to the growth of self-organized vehicle clusters whenever possible. Let the interaction coefficient associated with this algorithm be denoted by  $J_0^{ACC}$ , whereas the interaction coefficient associated with a human-driven vehicle be denoted by  $J_0^{\rm H}$ . An appropriately modeled qualitative difference between the coefficients  $J_0^{\mathrm{H}}$  and  $J_0^{\text{ACC}}$  can result in reduced congestion incidents due to formation of self-organized vehicle clusters. For example, an ACCenabled vehicle approaching a vehicular cluster will attempt to avoid contributing to the cluster growth. In the context of the current model, this behavior may be associated with the ACC-enabled vehicles experiencing greater repulsion near the cluster, as compared to human-driven vehicles. Mathematically, the behavior can be realized by the following relation between the interaction coefficients:

$$|J_{\rm in}^{\rm ACC}| > |J_{\rm in}^{\rm H}| \tag{9}$$

where  $J_{\rm in}^{\rm ACC}$  and  $J_{\rm in}^{\rm H}$  denote the interaction coefficient while entering a cluster for an ACC-enabled and a human-driven vehicle, respectively. Similarly, an ACC-enabled vehicle exiting a vehicular cluster will attempt to leave it as quickly as possible so as not to contribute to the cluster growth. In the context of the current model, this behavior may be associated with the ACC-enabled vehicles experiencing less repulsion from vehicles downstream of the cluster, as compared to human-driven vehicles. Mathematically, the behavior can be realized by the following relation between the interaction coefficients:

$$|J_{\text{out}}^{\text{ACC}}| < |J_{\text{out}}^{\text{H}}| \tag{10}$$

where  $J_{\rm out}^{\rm ACC}$  and  $J_{\rm out}^{\rm H}$  denote the interaction coefficient while exiting a cluster for an ACC-enabled and human-driven vehicle, respectively. The next subsection describes how the Hamiltonian can be used to study the evolution of the traffic system.

#### D. Exchange Dynamics

One of the first steps while studying the evolution of the traffic system is to identify the type of dynamics that will govern this evolution. In the statistical mechanics literature, two types of dynamics are popular, viz. the spin flip dynamics and the spin exchange dynamics [25]. In spin flip dynamics, a particular site flips from one state to another, without affecting the remainder of the system. Spin flip dynamics may be useful when modeling vehicles that are entering or leaving the system, such as at on- or off-ramps. For example, the state at the last site on the edge of the system may flip from  $\sigma_N = 1$  at time t to  $\sigma_N = 0$  at time t + 1, to indicate that a vehicle has left the system. However, in the current context, it is evident that the total number of vehicles is conserved on the closed ringroad, i.e., no vehicles are leaving the system. As a result, the sites can only exchange their states to model the forward motion of vehicles, so exchange dynamics are chosen to model system evolution. Specifically, exchange dynamics imply that if a vehicle moves from site  $s_i$  at time t to  $s_{i-1}$  at time t+1,

then the states of these sites are exchanged. For example, if at time t the states are given by  $\{\sigma_i, \sigma_{i-1}\}_t = \{1, 0\}$ , then at time t+1 the states will be  $\{\sigma_i, \sigma_{i-1}\}_{t+1} = \{0, 1\}$ , i.e. the states have exchanged and the vehicle has moved forward. Further, the current implementation of exchange dynamics stipulate that state exchange may only take place with an adjacent and *vacant* downstream site, i.e. the exchange *may* occur if

$$\sigma_i \neq 0$$
 and  $\sigma_{i-1} = 0$ . (11)

With knowledge of the exchange dynamics, the only missing component to begin a study of the system evolution is the rate at which these exchanges take place. The next subsection discusses the development of transition probability rates and their significance in relation to the modeling of non-equilibrium (or far-from equilibrium) processes.

#### E. Transition Probability Rates

Parallels can be drawn between the problem of modeling of traffic dynamics using the Potts model, and the study of driven Ising lattice gases [7], [19]. Systems that are driven by an external field, such as a temperature or concentration gradient, typically operate far-from-equilibrium. Such systems can exhibit steady-state behavior, though such a state may be one of continuous flux. Mathematically, such systems cannot be described by a stationary probability distribution. It is immediately evident that certain traffic behavior, such as formation of self-organized vehicle clusters or "stop-and-go" waves, belong to a class of far-from-equilibrium systems because their microstate probability distributions are non-stationary.

The non-stationary nature of the probability distributions of far-from-equilibrium systems has a direct impact on how the transition probability rates are determined. Far-from-equilibrium systems do not necessarily obey the condition of detailed balance [21]. Consequently, the transition probability rates have to be determined on the basis of observations of specific physical phenomena occurring in the system. For example, since vehicles are not expected to move backward in a traffic system, the associated transition probability rate of a vehicle moving to an adjacent and vacant *upstream* site is assumed to be zero. Such observations allow reasoned estimates to be made about potential transition probability rates. Mathematically, the transition probability rate (w) in this scenario is given by:

$$w(\boldsymbol{\sigma} \to \boldsymbol{\sigma}') = 0$$
where,  $\boldsymbol{\sigma} = \{\sigma_1, \sigma_2, \dots, \sigma_{i-1}, 1, 0, \sigma_{i+2}, \dots, \sigma_N\}$  (12)
$$\boldsymbol{\sigma}' = \{\sigma_1, \sigma_2, \dots, \sigma_{i-1}, 0, 1, \sigma_{i+2}, \dots, \sigma_N\}$$

i.e.,  $\sigma'$  represents a microstate where the vehicle at site  $s_i$  has moved to the upstream site  $s_{i+1}$ , while the states  $\{\sigma_1, \sigma_2, \ldots, \sigma_{i-1}, \sigma_{i+2}, \ldots, \sigma_N\}$  remain unchanged. On the other hand, the microstate transition probability rate for the scenario where a

vehicle at site  $s_i$  moves to the adjacent and vacant downstream site  $s_{i-1}$  is given by

$$w(\boldsymbol{\sigma} \to \boldsymbol{\sigma}') = c_0 \exp\left(-\beta H(s_i)\right)$$

$$= c_0 \exp\left(\beta B \sigma_i + \beta \sum_{s_j \in \mathcal{N}(s_i)} J_{ij} \sigma_i \sigma_j\right)$$
where,  $\boldsymbol{\sigma} = \{\sigma_1, \sigma_2, \dots, \sigma_{i-2}, 0, 1, \sigma_{i+1}, \dots, \sigma_N\}$ 

$$\boldsymbol{\sigma}' = \{\sigma_1, \sigma_2, \dots, \sigma_{i-2}, 1, 0, \sigma_{i+1}, \dots, \sigma_N\}$$

$$c_0 = \text{pre-exponential factor, and}$$

$$\beta = k.$$

$$(13)$$

The expression in (13) is similar to the reaction rate postulated for Arrhenius dynamics [10]. The parameter  $\beta$  is assumed to be proportional to the local density and is conceptually analogous to its interpretation in other physical systems. For example, in a ferromagnet,  $\beta \propto 1/T$ , where T denotes the temperature. Consequently, a high value of  $\beta$  corresponds to a low temperature T, in which case the magnetic moments are forced to align with their neighboring moments. Similarly, in a traffic system, a high value of  $\beta$  corresponds to a high value of local density  $k_i$ , in which case the vehicles are not free to move and are forced to "align" with the slow-moving or stationary states of their neighbors.

The expression for the transition probability rates in (13) can be used to determine the probability with which a randomly selected vehicle will transition from site  $s_i$  to the site  $s_{i-1}$ 

$$P(\boldsymbol{\sigma}_{t+1} = \boldsymbol{\sigma}' | \boldsymbol{\sigma}_t = \boldsymbol{\sigma}) = \min\{1, w(\boldsymbol{\sigma} \to \boldsymbol{\sigma}')\}$$
 (15)

which is similar to the expression for the acceptance probability employed in the Metropolis-Hastings algorithm [26]. The following sections use the statistical-mechanics inspired framework built here to numerically simulate and analyze the effects of driver algorithms of formation of self-organized vehicular clusters.

#### V. MONTE CARLO SIMULATIONS

In order for the developed framework to accurately reflect the evolution of self-organized vehicular clusters, the values of the model parameters must be chosen carefully. The following subsection discusses the model calibration procedure.

# A. Calibration of Parameters

The calibration procedure of the presented model is performed in a traffic scenario whose evolution is theoretically and empirically well known. The traffic system, i.e., the closed ring-road is populated with human-driven vehicles so that they form a queue, such as one that may form at a signalized intersection, to yield a moderate-density scenario with a normalized dimensionless density  $k^* = k/k_{jam}$ . At time t=0, the queue is allowed to dissipate and the system evolution is compared with known results from the Lighthill-Whitham-Richards (LWR) model of traffic flow [27], [28] as well as the representative traffic parameters described in Section III-A. Specifically, as the vehicles begin to exit a queue, they discharge at the maximum flow rate  $(q_{\rm max})$  and attain free flow velocity

![](_page_6_Figure_2.jpeg)

Fig. 3. Calibration of generalized Ising model parameters B and  $c_0$  to match free flow speed on a highway ( $v_f=25\,$  m/s). Contours indicate free flow speeds (m/s) obtained with corresponding set of model parameters. The values are chosen to be B=125 and  $c_0=0.05$ .

 $(v_f)$ . At the same time, a backward wave moving with speed u can be seen to develop, both at the beginning of the queue (due to vehicles leaving the cluster) and at the end of the queue (due to vehicles entering the cluster after traversing the ring-road). The model parameters  $c_0, B, J_{\rm in}^{\rm H}$ , and  $J_{\rm out}^{\rm H}$  should be such that the simulation behavior matches these known representative values of the traffic parameters.

The calibration procedure is performed in two steps. In the first step, the parameters  $c_0$  and B are calibrated to yield the free flow velocity calculated via the speed of the first vehicle exiting the queue. The queued traffic system is simulated several times for different values of  $c_0$  and B and the free flow velocities obtained by exiting vehicles are shown in Fig. 3. Assuming that vehicles are nearly stationary ( $v \approx 0.5 \text{ m/s}$ ) when the external driving field is absent (B=0), and using the representative value of free flow velocity  $v_f=25 \text{ m/s}$  for highways, the calibrated parameters for the traffic system are found to be  $c_0=0.05$  and B=125. Vehicles cannot be assumed to be completely stationary when the external field is absent because in that scenario  $c_0$  evaluates to zero, implying that the transition probability rate is identically zero.

In the second step of the procedure, the calibrated values of B and  $c_0$  are used to evaluate the appropriate values of  $J_{\rm in}^{\rm H}$  and  $J_{\rm out}^{\rm H}$ . The queued traffic system is simulated for a range of interaction coefficients and the resulting backward wave speeds are compared for both vehicles exiting  $(u_{\rm out})$  and entering  $(u_{\rm in})$  a cluster. According to the LWR theory, for a queued traffic system on a closed ring-road populated with human-driven vehicles, the values of  $(u_{\rm out})$  and  $(u_{\rm in})$  should be identical and equal to -6 m/s. Point H in Fig. 4 indicates the parameter values  $(J_{\rm in}^{\rm H}=-0.325\times10^4~{\rm m}^2,J_{\rm out}^{\rm H}=-1.395\times10^5~{\rm m}^2)$  for which the backward wave speed matches empirical observations in traffic systems (see Section III-A).

Finally, the interaction coefficients for ACC-enabled vehicles can also be determined from Fig. 4. As discussed in Section IV-C, ACC-enabled vehicles with appropriately designed algorithms are expected to exit clusters faster so as to avoid contributing to the growth of self-organized clusters. If

![](_page_6_Figure_8.jpeg)

Fig. 4. (a) Backward wave speed  $(u_{\rm out})$  evaluated for vehicles exiting a cluster. (b) Backward wave speed  $(u_{\rm in})$  evaluated for vehicles entering a cluster. Parameters  $J_{\rm in}$  and  $J_{\rm out}$  are calibrated to match backward wave propagation speeds for both human-driven (H) and ACC-enabled (A) vehicles, evaluated using B=125 and  $c_0=0.05$ . Contours indicate backward wave speeds (m/s) obtained with corresponding set of model parameters.

such vehicles exit the cluster faster, the backward wave speed  $(u_{\rm out})$  will have a larger magnitude, implying a higher cluster dissipation rate. Similarly, such vehicles are also expected to enter clusters at a slower rate to avoid increasing cluster size. As a result, the backward wave speed  $(u_{\rm in})$  will have a smaller magnitude, implying a higher cluster dissipation rate. Using the calibration procedure already performed, and the qualitative relationships described in (9) and (10), the values of the backward wave speeds for a traffic system comprising only ACC-enabled vehicles are assumed to be  $u_{\rm out}=-7$  m/s and  $u_{\rm in}=-5$  m/s. Point A in Fig. 4 indicates the calibrated parameter values  $(J_{\rm in}^{\rm ACC}=-1.85\times 10^4~{\rm m}^2,J_{\rm out}^{\rm ACC}=-1.002\times 10^5~{\rm m}^2)$  for the associated backward wave speeds.

These parameters enable us to carry out the Monte Carlo simulations to mimic traffic flow dynamics in a mixed traffic flow. A simulation of the queued traffic system with the calibrated model parameters is shown in Fig. 5. It must be noted that these parameter values for the ACC-enabled vehicles provide us with only a qualitative assessment of the effects of increased ACC

![](_page_7_Figure_2.jpeg)

Fig. 5. Queued traffic system is simulated with  $k^*=0.5$ ,  $c_0=0.05$ , B=125,  $J_{\rm in}^{\rm H}=-0.325\times 10^4$ , and  $J_{\rm out}^{\rm H}=-1.395\times 10^5$ . Use of a queued traffic system helps ensure that calibrated model parameters lead to behavior that mimics real-life and agrees with existing theory (LWR model).

penetration. The pseudo-code for the Monte Carlo algorithm used in the study is included in Algorithm 1.

# **Algorithm 1** Simulating Traffic Flow Dynamics With Markov Chain Monte Carlo Algorithm

```
1: Uniformly distribute M vehicles across N available sites
    to set up initial microstate \sigma
 2: while time < ENDTIME do
     for all sites s_i \in S do
 4:
        if \sigma_i \neq 0 and \sigma_{i+1} = 0 then
 5:
           calculate the site-based Hamiltonian H(s_i)
           calculate transition probability w = \exp(-\beta H(s_i))
 6:
 7:
           select a random number r \sim U(0,1)
 8:
            if r < \min(1, w) then
 9:
               exchange states \sigma_i and \sigma_{i+1}
10:
              accept new microstate
11:
           end if
        end if
12:
     end for
13:
     time \leftarrow time + 1
14.
15: end while
```

#### B. Simulation Results

With the appropriate model parameters, and the transition probability rates developed in Section IV-E, the traffic system was simulated as a closed-ring road with N=500 sites. The number of vehicles populating the ring-road were varied to create scenarios where the normalized density  $k^*=k/k_{jam}$  varies from 0.1 to 0.9 in steps of 0.1. Additionally, the levels of penetration for ACC-enabled vehicles were varied from 0% to 100%, in steps of 10%. The simulation was run for a real-time equivalent of one hour to allow for transients to die off, so that steady state cluster distribution could be observed. The system was updated in a random-parallel fashion, i.e. all sites

![](_page_7_Figure_9.jpeg)

Fig. 6. Probability of a randomly selected vehicle lying in a cluster of size  $r^*$  for varying levels of ACC penetration and densities of interest. Lines of decreasing thickness indicate increasing levels of ACC penetration. Dotted line corresponds to a traffic system consisting entirely of ACC-enabled vehicles. Clusters of size r=1 not shown in the figure.

were updated at each time step, but the order within each time step update was chosen randomly.

The Monte Carlo simulations yield a probability mass function  $f_R(r)$  which denotes the probability that a vehicle cluster of size R=r exists in the traffic system in steady state. Then, the joint probability mass function  $f_{VR}(v,r)$  which denotes the probability that a randomly selected vehicle V=v is in a vehicular cluster of size R=r can be expressed as follows:

$$f_{VR}(v,r) = f_{V|R}(V=v|R=r)f_R(r)$$
 (16)

where  $f_{V|R}(V=v|R=r)$  denotes the probability of selecting a vehicle V that lies in a cluster, given that a cluster of size R exists in the traffic system. The conditional probability is found to be

$$f_{V|R}(V=v|R=r) = \frac{r}{M} = r^*$$
 (17)

where M is the total vehicular population on the closed ringroad, and  $r^*$  denotes the normalized cluster size. The resulting joint probability distribution  $f_{VR}(v,r)$  is plotted for varying values of density for which the Monte Carlo simulations were performed. Extremely high values of density are not usually observed in traffic, and no significant cluster formation trends were observed in the simulations for low values of density  $(k^* \in [0.1, 0.3])$ . Consequently, the probability distribution  $f_{VR}(v,r)$  is plotted in Fig. 6 for the range of density values  $k^* \in [0.4, 0.6]$ , where freely flowing and clustered vehicles coexist in real-world traffic scenarios. The implications of these results and the conclusions that can be drawn from them are discussed in the next section.

# VI. RESULTS AND CONCLUDING REMARKS

The simulation results included in Fig. 6 describe the probability of a randomly selected vehicle being present in a cluster of a particular size. The trends observable in these results, while not definitive, can still be used to draw qualitative conclusions pertaining to the effect of ACC penetration of the formation of clusters and cluster distributions. One trend that is immediately evident is that cluster distributions for predominantly human-driven traffic systems are skewed to the right (towards large-sized clusters), whereas those for predominantly ACC-populated traffic systems are skewed to the left (towards moderately-sized clusters), across all densities shown in the figure. Consequently, the probability that a randomly selected vehicle is present in a large-sized cluster is higher for traffic systems consisting predominantly of human-driven vehicles as opposed to ACC-enabled vehicles. Similarly, the probability that a randomly selected vehicle is present in a moderately-sized cluster is higher for traffic systems consisting predominantly of ACC-enabled vehicles.

## *A. Broader Impacts*

These qualitative results may have significant implications for autonomous vehicle design, traffic control and guiding policy decision-making. Specifically, from a traffic control perspective, it is easier to design and handle highway elements to counter localized bottlenecks that could result in large clusters. On the other hand, having several moderately-sized clusters that may appear at random across a large swathe of highway may require the development of more elaborate traffic control techniques. However, these findings are only applicable to traffic systems operating at medium densities (k<sup>∗</sup> ∈ [0.4, 0.6]). In contrast, our previous research has indicated that ACC penetration is quite advantageous at lower densities (k<sup>∗</sup> ∈ [0, 0.3]) since it raises the critical density at which jams first begin to appear and enables higher flows [14].

The appearance of several moderately-sized clusters at medium densities in mixed human-ACC traffic may have other implications as well. For example, the presence of several spatially-distributed and moderately-sized self-organized vehicle clusters in predominantly ACC-enabled traffic flow may lead to an increase in 'stop-and-go' behavior. Each such stop-and-go maneuver carries with it the risk of collision or disruption of traffic flow, especially from human drivers. It is hypothesized that the acceleration and deceleration maneuvers associated with such stop-and-go traffic may also lead to higher emissions of greenhouse gases as compared to steady traffic flow. Such an impact has not been quantified in this paper.

The statistical mechanics-based method, proposed in this paper, may be expanded in the future to model additional traffic scenarios. For example, this approach could be used to model connected vehicles or incorporate V2X communication technologies, in which case vehicles may receive congestion information from and react to events outside their immediate neighborhood. This methodology may also be used to model adverse weather scenarios, where the model could be recalibrated to account for modified driver behavior in different weather conditions. In conclusion, it was found that the generalized Ising model could satisfactorily simulate the traffic dynamics of mixed traffic flows, and that these simulations reveal interesting effects of driver algorithms on the formation of self-organized vehicular clusters.

# APPENDIX ISING MODEL IN ONE DIMENSION WITH NEAREST-NEIGHBOR INTERACTIONS

Ernst Ising presented a particle interaction model for ferromagnetism in his Ph.D. thesis in 1925, and this model has since come to be known by his name [29]. In this work, Ising modeled a one-dimensional ferromagnet as an infinitely long chain of "magnets," where each site represented a magnetic dipole moment generated by the atomic spin. If the atomic spins are aligned, the magnetic moments add up, resulting in the magnetic nature of a ferromagnetic material. On the other hand, if the spins are not aligned, such as at high temperatures, the magnetic nature is lost. The phase transition between these two behaviors of a ferromagnetic material occurs at the Curie temperature. The goal of Ising's thesis was to study if the interaction between neighboring spins was the underlying mechanism for such behavior of ferromagnetic materials.

*Model Description:* In this model, atomic spins are denoted by σ. The atomic spins can be in one of two states, i.e., σ ∈ {−1, +1}. The actual values of the spins do not hold any physical significance, except for the fact that they simplify some of the following analysis. Specifically, if two adjacent atomic spins are aligned in the same direction, they could be modeled as either {−1, −1} or {+1, +1}, with no change in the ensuing analysis. Similarly, if two adjacent spins are not aligned, they could either be represented by {−1, +1} or {+1, −1}. Now, the state of the magnet is collectively represented by the atomic spins at each site of the one-dimensional chain of N magnets as *σ* = {σ1, σ2,...,σ<sup>N</sup> }, which is known as the system *microstate*, where N is a large positive integer. The energy associated with the microstate *σ* for a one-dimensional Ising model with only nearest-neighbor interactions is given by the Hamiltonian

$$H(\boldsymbol{\sigma}) = -B \sum_{i=1}^{N} \sigma_i - \sum_{\langle i,j \rangle} J_{ij} \sigma_i \sigma_j$$
 (18)

where B represents an external magnetic field, i, j represents a nearest-neighbor site pair (i.e., j = i − 1 or j = i + 1), and Jij = Jji denotes the interaction strength between sites i and j. The interaction strength is assumed to be constant (i.e., Jij = J) in this paper.

In order to further simplify the analysis, the one-dimensional model is assumed to have periodic boundary conditions, so that σ<sup>N</sup>+1 = σ1. While this assumption does not affect the thermodynamic properties of the N-magnet chain in the limit N → ∞, it does allow a symmetric representation of the Hamiltonian as follows:

$$H(\boldsymbol{\sigma}) = -\frac{B}{2} \sum_{i=1}^{N} (\sigma_i + \sigma_{i+1}) - J \sum_{i=1}^{N} \sigma_i \sigma_j.$$
 (19)

Partition Function: The partition function plays a very important role in the field of statistical mechanics and can be used to determine the aggregated properties of a system. It derives its name from the fact that it encodes the probability distribution that partitions microstates into "bins" of equal energy. Specifically, the probability of occurrence of a particular microstate  $\sigma$  is given by

$$P(\boldsymbol{\sigma}) = \frac{1}{Z} e^{-\beta H(\boldsymbol{\sigma})} \tag{20}$$

where Z denotes the partition function that serves as a normalizing constant,  $\beta=1/k_BT$ , where  $k_B$  denotes the Boltzmann constant, and T denotes the temperature. The partition function Z is thus defined as

$$Z = \sum_{\sigma_1 = -1}^{\sigma_1 = +1} \sum_{\sigma_2 = -1}^{\sigma_2 = +1} \cdots \sum_{\sigma_N = -1}^{\sigma_N = +1} e^{-\beta H(\sigma)}$$
(21)

which can be written as

$$Z = \sum_{\sigma_1 = -1}^{\sigma_1 = +1} \cdots \sum_{\sigma_N = -1}^{\sigma_N = +1} \exp\left\{\beta \sum_{i=1}^N \left(\frac{B}{2}(\sigma_i + \sigma_{i+1}) + J\sigma_i\sigma_j\right)\right\}.$$
(22)

Transfer Matrix: In order to evaluate the partition function, Kramers and Wannier suggested the use of transfer matrices [29, pp. 476]. The right-hand side of (22) can be expressed as a product of  $2 \times 2$  matrices as explained below. Consider a situation with only two adjacent sites  $\sigma_i$  and  $\sigma_{i+1}$ . Then, in accordance with (19), the Hamiltonian  $H(\sigma)$  yields

$$e^{-\beta H(\sigma)} = \begin{cases} e^{\beta(B+J)}, & \sigma_i = +1, \sigma_{i+1} = +1 \\ e^{\beta(-B+J)}, & \sigma_i = -1, \sigma_{i+1} = -1 \\ e^{-\beta J}, & \text{otherwise.} \end{cases}$$
(23)

Now, for a vector representation of the spins, let the spins +1 and -1 be denoted as vectors  $q_1 = \begin{bmatrix} 1 & 0 \end{bmatrix}$  and  $q_2 = \begin{bmatrix} 0 & 1 \end{bmatrix}$ , respectively. If the transfer matrix P is given by

$$P = \begin{bmatrix} e^{\beta(B+J)} & e^{-\beta J} \\ e^{-\beta J} & e^{\beta(-B+J)} \end{bmatrix}$$
 (24)

the operation  $(\sigma_i P \sigma_{i+1})$  yields the same results as in (23), i.e.

$$(\sigma_{i}P\sigma_{i+1}) = \begin{cases} e^{\beta(B+J)}, & \sigma_{i} = q_{1}, \sigma_{i+1} = q_{1}^{T} \\ e^{\beta(-B+J)}, & \sigma_{i} = q_{2}, \sigma_{i+1} = q_{2}^{T} \\ e^{-\beta J}, & \text{otherwise.} \end{cases}$$
(25)

Solution of the Partition Function: Using the transfer matrix representation, the partition function is re-written as

$$Z = \sum_{\sigma_1 = -1}^{\sigma_1 = +1} \cdots \sum_{\sigma_N = -1}^{\sigma_N = +1} (\sigma_1 P \sigma_2) (\sigma_2 P \sigma_3) \cdots (\sigma_N P \sigma_1)$$

$$= \sum_{\sigma_1 = -1}^{\sigma_1 = +1} (\sigma_1 P^N \sigma_1) = \operatorname{Tr}(P^N)$$

$$= \lambda_a^N + \lambda_b^N \tag{26}$$

where the eigenvalues of P are represented as  $\lambda_a$  and  $\lambda_b$  in a ordered way (i.e.,  $\lambda_b < \lambda_a$ ). In the absence of an external field (i.e., B = 0), the eigenvalues are found to be

$$\lambda_a = 2\cosh(\beta J) \tag{27}$$

$$\lambda_b = 2\sinh(\beta J) \tag{28}$$

which yield a solution of the partition function. With knowledge of the partition function, several other statistics (e.g., free energy and magnetization per spin) can be evaluated along with their trends as a function of inverse temperature  $\beta$ .

#### REFERENCES

- H. Haken, Information and Self-Organization: A Macroscopic Approach to Complex Systems, ser. Springer Series in Synergetics. New York, NY, USA: Springer-Verlag, 2006.
- [2] "Our nation's highways 2008," Federal Highway Admin., U.S. Dept. Transp., Washington, DC, USA, Tech. Rep., 2008.
- [3] D. Schrank, B. Eisele, and T. Lomax, Proceedings of the 2012 annual urban mobility report. Texas A&M Transportation Institute, College Station, TX, USA, 2012, ch. TTI's 2012 Urban Mobility Report.
- [4] K. Jerath, A. Ray, S. N. Brennan, and V. V. Gayah, "Statistical mechanics-inspired framework for studying the effects of mixed traffic flows on highway congestion," in *Proc. Am. Control Conf.*, Jun. 2014, pp. 5402–5407.
- [5] A. Kesting, M. Treiber, M. Schonhof, F. Kranke, and D. Helbing, Jam-Avoiding Adaptive Cruise Control (ACC) and Its Impact on Traffic Dynamics. Berlin, Germany: Springer-Verlag, 2005, pp. 633–643.
- [6] K. Nagel and M. Schreckenberg, "A cellular automaton model for freeway traffic," J. de Physique I, vol. 2, no. 12, pp. 2221–2229, 1992.
- [7] K. Nagel, "Particle hopping models and traffic flow theory," Phys. Rev. E, vol. 53, no. 5, pp. 4655–4672, May 1996.
- [8] A. D. May, Traffic Flow Fundamentals. Englewood Cliffs, NJ, USA: Prentice-Hall, 1990.
- [9] M. Bando, K. Hasebe, K. Nakanishi, and A. Nakayam, "Analysis of optimal velocity model with explicit delay," *Phys. Rev. E*, vol. 58, no. 5, pp. 5429–5435, Nov. 1998.
- [10] A. Sopsakis, "Stochastic noise approach to traffic flow modeling," Phys. A, Statist. Mech. Appl., vol. 342, no. 3/4, pp. 741–754, Nov. 2004.
- [11] T. Alperovich and A. Sopsakis, "Stochastic description of traffic flow," J. Stat. Phys., vol. 133, no. 6, pp. 1083–1105, Dec. 2008.
- J. Stat. Phys., vol. 133, no. 6, pp. 1083–1105, Dec. 2008.
  [12] I. Prigogine and F. Andrews, "A Boltzmann-like approach for traffic flow," Oper. Res., vol. 8, no. 6, pp. 789–797, 1960.
- [13] R. Mahnke and J. Kaupuzs, "Probabilistic description of traffic flow," in *Networks and Spatial Economics*. Norwell, MA, USA: Kluwer, Mar. 2001, vol. 1, no. 1/2, pp. 103–136.
- [14] K. Jerath and S. N. Brennan, "Analytical prediction of self-organized traffic jams as a function of increasing ACC penetration," *IEEE Trans. Intell. Transp. Syst.*, vol. 13, no. 4, pp. 1782–1791, Dec. 2012.
- [15] H. Suzuki, J. Imura, and K. Aihara, "Chaotic Ising-like dynamics in traffic signals," Sci. Rep., vol. 3, 2013, Art. ID. 1127.
- [16] S. Darbha and K. R. Rajagopal, "Intelligent cruise control systems and traffic flow stability," California Partners for Adv. Transit and Highways, Berkeley, CA, USA, Tech. Rep., 1998.
- [17] A. Bose and P. A. Ioannou, "Analysis of traffic flow with mixed manual and semiautomated vehicles," *IEEE Trans. Intell. Transp. Syst.*, vol. 4, no. 4, pp. 173–188, Dec. 2003.
- [18] C. Daganzo, Fundamentals of Transportation and Traffic Operations. Bingley, U.K.: Emerald Group, 1997.
- [19] A. Kolomeisky, G. Schutz, E. Kolomeisky, and J. Staley, "Phase diagram of one-dimensional driven lattice gases with open boundaries," *J. Phys. A, Math. Gen.*, vol. 31, no. 33, Aug.1998, Art. ID. 6911.
- [20] E. Bayong, H. T. Diep, and V. Dotsenko, "Potts model with long-range interactions in one dimension," *Phys. Rev. Lett.*, vol. 83, no. 1, p. 14, Jul. 1999.
- [21] K. Jerath, "Impact of adaptive cruise control on the formation of selforganizing traffic jams on highways," M.S. thesis, The Pennsylvania State University, State College, PA, USA, 2010.
- [22] B. Eisenblätter, L. Santen, A. Schadschneider, and M. Schreckenberg, "Jamming transition in a cellular automaton model for traffic flow," *Phys. Rev. E*, vol. 57, pp. 1309–1314, Feb. 1998.

- [23] G. Long, "Acceleration characteristics of starting vehicles," *J. Transp. Res. Board*, vol. 1737, pp. 58–70, 2000.
- [24] I. El-Shawarby, H. Rakha, V. W. Inman, and G. W. Davis, "Evaluation of driver deceleration behavior at signalized intersections," *J. Transp. Res. Board*, vol. 2018, pp. 29–35, 2007.
- [25] P. Krapivsky, S. Redner, and E. Ben-Naim, *A Kinetic View of Statistical Physics*. Cambridge, U.K.: Cambridge Univ. Press, 2010.
- [26] S. Chib and E. Greenberg, "Understanding the Metropolis-Hastings algorithm," *Amer. Statist.*, vol. 49, no. 4, pp. 327–335, 1995.
- [27] M. J. Lighthill and G. Whitham, "On kinematic waves. II. A theory of traffic flow on long crowded roads," *Proc. Roy. Soc. A*, vol. 229, no. 1178, pp. 317–345, 1955.
- [28] P. Richards, "Shock waves on the highway," *Oper. Res.*, vol. 4, no. 1, pp. 42–51, Feb. 1956.
- [29] R. K. Pathria, *Statistical Mechanics*, 3rd ed. Amsterdam, The Netherlands: Elsevier, 2011.

![](_page_10_Picture_9.jpeg)

**Kshitij Jerath** (S'11–M'14) received the M.S. and Ph.D. degrees in mechanical engineering and the M.S. degree in electrical engineering from The Pennsylvania State University (Penn State), University Park, PA, USA, in 2014.

He is currently a Postdoctoral Researcher with Penn State. His research interests include dynamics and control of complex systems, networked control systems, intelligent vehicles, and state estimation. His recent work has focused on macroscopic control of multiagent systems such as traffic, and

terrain-based vehicle tracking algorithms for GPS-free and degraded GPS environments.

![](_page_10_Picture_13.jpeg)

**Asok Ray** (SM'83–F'02) received the Ph.D. degree in mechanical engineering from Northeastern University, Boston, MA, USA, and the graduate degrees in the disciplines of electrical engineering, mathematics, and computer science.

He joined The Pennsylvania State University (Penn State), University Park, PA, USA, in July 1985, and is currently a Distinguished Professor of mechanical engineering and mathematics, a Graduate Faculty Member of electrical engineering, and a Graduate Faculty of nuclear engineering.

![](_page_10_Picture_16.jpeg)

**Sean Brennan** (M'03) received the B.S.M.E. and B.S. physics degrees from New Mexico State University, Las Cruces, NM, USA, in 1997, and the M.S. and Ph.D. degrees in mechanical and industrial engineering from the University of Illinois at Urbana-Champaign, Urbana, IL, USA, in 1999 and 2002, respectively.

Since 2003 he has been with The Pennsylvania State University (Penn State), University Park, PA, USA, where he is currently an Associate Professor with the Department of Mechanical and Nuclear

Engineering. His research group is active in the areas of estimation theory, system dynamics, and control with applications focused primarily on mobile ground systems, including passenger vehicles, heavy trucks, and bomb-disposal robots.

Dr. Brennan is currently an Associate Editor of *Journal of Dynamic Systems, Measurement and Control*.

![](_page_10_Picture_21.jpeg)

**Vikash V. Gayah** received the B.S. and M.S. degrees in civil and environmental engineering from University of Central Florida, Orlando, FL, USA, and the Ph.D. degree in civil and environmental engineering from University of California, Berkeley, CA, USA.

He currently serves as an Assistant Professor with the Department of Civil and Environmental Engineering, The Pennsylvania State University (Penn State), University Park, PA, USA. His research interests include macroscopic modeling of urban trans-

portation systems, traffic operations and control, public transportation, and traffic safety.