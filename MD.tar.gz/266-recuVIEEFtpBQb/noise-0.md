#### <span id="page-0-2"></span>[Skip to main content](#page-0-0)

#### Advertisement

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/book/10.1007/978-1-4939-4005-9) [Springer Nature Link](https://link.springer.com)

[Menu](#page-10-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-10-1)

![](_page_0_Picture_6.jpeg)

- [Home](file:///) 1.
- Textbook 2.

#### Birkhäuser

![](_page_0_Picture_10.jpeg)

# **Real Analysis**

- Textbook •
- © 2016 •
- Latest edition •

[Accessibility Information](#page-7-0)

# <span id="page-0-0"></span>**Overview**

#### Authors:

- [Emmanuele DiBenedetto](#page-1-0) [0](#page-0-1) •
- <span id="page-0-1"></span>Emmanuele DiBenedetto 1.
  - Nashville, USA 1.

#### <span id="page-1-0"></span>[View author publications](file:///search?dc.creator=Emmanuele+DiBenedetto&sortBy=newestFirst)

Search author on: [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Emmanuele+DiBenedetto) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Emmanuele+DiBenedetto%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

Includes supplementary material: [sn.pub/extras](https://extras.springer.com/?query=978-1-4939-4003-5) •

Part of the book series: [Birkhäuser Advanced Texts Basler Lehrbücher](https://link.springer.com/series/4842) (BAT)

- 58k Accesses •
- 38 Citations •
- 1 [Altmetric](https://link.altmetric.com/details/19110463) •

 This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-1-4939-4005-9) to check access.

# **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-1-4939-4005-9)

**eBook EUR 67.40** 

Price includes VAT (China (P.R.))

ebook

10.1007/978-1-4939-4005-9

978-1-4939-4005-9

Real Analysis

5372ac675bdcb6c6708dab12da83bbfda8a351fa90fa34a43165c6e803c8ecf20c37a0a990d31535b8cb4f8a9de0b25f8573149ed927a1a6a915bb0caddc1612

- Available as EPUB and PDF
- Read on any device
- Instant download
- Own it forever

Buy eBook

#### **Softcover Book EUR 79.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-1-4939-4005-9

978-1-4939-8151-9

Real Analysis

ee0b3693c89d2d449197b7d1269d409e619e68fd2d14d8d1a23e963fc31a5c1918998648d0c999c8d1a488decbe2b18a7819e57a4f07c118f8e9606a6d8404d9

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

#### **Hardcover Book EUR 79.99**

Price excludes VAT (China (P.R.))

| book                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/978-1-4939-4005-9                                                                                                        |
| 978-1-4939-4003-5                                                                                                                |
| Real Analysis                                                                                                                    |
| 1fc9716216da883cfa8e3e109c8480a9ed83096a6a65a81e0acd42dc112646dde5a1a34ab9d7be8585b81abd64356ef4e26ef5d9d0260e4f8d0da20f409c7d63 |

- Durable hardcover edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Hardcover Book

Tax calculation will be finalised at checkout

# **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-1-4939-4005-9) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# **About this book**

The second edition of this classic textbook presents a rigorous and selfcontained introduction to real analysis with the goal of providing a solid foundation for future coursework and research in applied mathematics. Written in a clear and concise style, it covers all of the necessary subjects as well as those often absent from standard introductory texts. Each chapter features a "Problems and Complements" section that includes additional material that briefly expands on certain topics within the chapter and numerous exercises for practicing the key concepts.

The first eight chapters explore all of the basic topics for training in real analysis, beginning with a review of countable sets before moving on to detailed discussions of measure theory, Lebesgue integration, Banach spaces, functional analysis, and weakly differentiable functions. More topical applications are discussed in the remaining chapters, such as maximal functions, functions of bounded mean oscillation, rearrangements, potential theory, and the theory of Sobolev functions. This second edition has been completely revised and updated and contains a variety of new content and expanded coverage of key topics, such as new exercises on the calculus of distributions, a proof of the Riesz convolution, Steiner symmetrization, and embedding theorems for functions in Sobolev spaces.

Ideal for either classroom use or self-study, Real Analysis is an excellent textbook both for students discovering real analysis for the first time and for mathematicians and researchers looking for a useful resource for reference or review.

Praise for the First Edition:

"[This book] will be extremely useful as a text. There is certainly enough material for a year-long graduate course, but judicious selection would make it possible to use this most appealing book in a one-semester course for wellprepared students."

—Mathematical Reviews

## **Similar content being viewed by others**

![](_page_4_Picture_5.jpeg)

## **[Distribution Theory by Riemann Integrals](https://link.springer.com/10.1007/978-981-15-0928-5_3?fromPaywallRec=true)**

Chapter © 2020

![](_page_4_Picture_8.jpeg)

**[A Class of Analytic Functions Defined by a Second Order](https://link.springer.com/10.1007/s40819-024-01681-0?fromPaywallRec=true) [Differential Inequality and Error Function](https://link.springer.com/10.1007/s40819-024-01681-0?fromPaywallRec=true)** 

Article 10 February 2024

![](_page_4_Picture_11.jpeg)

**[Sobolev Embedding Theorems and Their Generalizations](https://link.springer.com/10.3103/S0027132222010053?fromPaywallRec=true) [for Maps Defined on Topological Spaces with Measures](https://link.springer.com/10.3103/S0027132222010053?fromPaywallRec=true)** 

Article 01 February 2022

## **Explore related subjects**

Discover the latest articles, books and news in related subjects.

- [Applications of Mathematics](file:///subjects/applications-of-mathematics) •
- [Approximations and Expansions](file:///subjects/approximations-and-expansions) •
- [Differential Equations](file:///subjects/differential-equations) •
- [Measure and Integration](file:///subjects/measure-and-integration) •
- [Calculus of Variations and Optimization](file:///subjects/calculus-of-variations-and-optimization) •

| Search within this book |  |  |
|-------------------------|--|--|
|                         |  |  |
|                         |  |  |

#### Search

| 978-1-4939-4005-9 |
|-------------------|
| Chapter           |
| Chapter           |
| true              |

# **Table of contents (11 chapters)**

#### **Front Matter** 1.

Pages i-xxxii [Download chapter PDF](file:///content/pdf/bfm:978-1-4939-4005-9/1) 

2.

### **[Preliminaries](file:///chapter/10.1007/978-1-4939-4005-9_1)**

Emmanuele DiBenedetto Pages 1-15 ◦

3.

## **[Topologies and Metric Spaces](file:///chapter/10.1007/978-1-4939-4005-9_2)**

Emmanuele DiBenedetto Pages 17-66 ◦

4.

## **[Measuring Sets](file:///chapter/10.1007/978-1-4939-4005-9_3)**

Emmanuele DiBenedetto Pages 67-131 ◦

#### **[The Lebesgue Integral](file:///chapter/10.1007/978-1-4939-4005-9_4)** 5.

Emmanuele DiBenedetto Pages 133-191 ◦

6.

## **[Topics on Measurable Functions of Real Variables](file:///chapter/10.1007/978-1-4939-4005-9_5)**

Emmanuele DiBenedetto Pages 193-245 ◦

7.

## **[The \\(L^p\\) Spaces](file:///chapter/10.1007/978-1-4939-4005-9_6)**

Emmanuele DiBenedetto Pages 247-312 ◦

8.

## **[Banach Spaces](file:///chapter/10.1007/978-1-4939-4005-9_7)**

Emmanuele DiBenedetto Pages 313-377 ◦

9.

## **[Spaces of Continuous Functions, Distributions, and](file:///chapter/10.1007/978-1-4939-4005-9_8) [Weak Derivatives](file:///chapter/10.1007/978-1-4939-4005-9_8)**

Emmanuele DiBenedetto Pages 379-429 ◦

10.

## **[Topics on Integrable Functions of Real Variables](file:///chapter/10.1007/978-1-4939-4005-9_9)**

Emmanuele DiBenedetto Pages 431-489 ◦

11.

## **[Embeddings of \\(W^{1,p}\(E\)\\) into \\(L^q\(E\)\\)](file:///chapter/10.1007/978-1-4939-4005-9_10)**

Emmanuele DiBenedetto Pages 491-539 ◦

12.

## **[Topics on Weakly Differentiable Functions](file:///chapter/10.1007/978-1-4939-4005-9_11)**

Emmanuele DiBenedetto Pages 541-578 ◦

13.

## **Back Matter**

Pages 579-596 [Download chapter PDF](file:///content/pdf/bbm:978-1-4939-4005-9/1) 

[Back to top](#page-0-2)

# **Reviews**

"The book is a valuable, comprehensive reference source on real analysis. The first eight chapters cover core material that is part of most courses taught on the subject, followed by a collection of special topics that stay within the framework of real analysis. In addition to the content, what makes the book especially useful as a reference source is its organization. … Summing Up: Recommended. Graduate students and faculty. This work should be used solely as a reference." (M. Bona, Choice, Vol. 54 (9), May, 2017)

"The reader can find many interesting details which serve to illuminate the diamonds of analysis. The list of references contains the main books and articles which form the modern real analysis. The book can be recommended as one of the main readings on real analysis for those who are interested in this subject and its numerous applications." (Sergei V. Rogosin, zbMATH 1353.26001, 2017)

# **Authors and Affiliations**

**Nashville, USA**  •

Emmanuele DiBenedetto

# <span id="page-7-0"></span>**Accessibility Information**

Accessibility information for this book is coming soon. We're working to make it available as quickly as possible. Thank you for your patience.

# **Bibliographic Information**

Book Title: Real Analysis •

Authors: Emmanuele DiBenedetto •

Series Title: [Birkhäuser Advanced Texts Basler Lehrbücher](https://link.springer.com/series/4842) •

DOI: https://doi.org/10.1007/978-1-4939-4005-9 •

Publisher: Birkhäuser New York, NY •

eBook Packages: [Mathematics and Statistics,](file:///search?facet-content-type=%22Book%22&package=11649&facet-start-year=2016&facet-end-year=2016) [Mathematics and Statistics](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2016&facet-end-year=2016) [\(R0\)](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2016&facet-end-year=2016) •

Copyright Information: Springer Science+Business Media New York 2016 •

Hardcover ISBN: 978-1-4939-4003-5Published: 18 September 2016 •

Softcover ISBN: 978-1-4939-8151-9Published: 21 April 2018 •

eBook ISBN: 978-1-4939-4005-9Published: 17 September 2016 •

Series ISSN: 1019-6242 •

Series E-ISSN: 2296-4894 •

Edition Number: 2 •

Number of Pages: XXXII, 596 •

Number of Illustrations: 4 b/w illustrations •

Topics: [Measure and Integration,](https://link.springer.com/search?facet-sub-discipline=Measure%20and%20Integration&facet-content-type=Book) [Calculus of Variations and Optimal](https://link.springer.com/search?facet-sub-discipline=Calculus%20of%20Variations%20and%20Optimal%20Control;%20Optimization&facet-content-type=Book) [Control; Optimization](https://link.springer.com/search?facet-sub-discipline=Calculus%20of%20Variations%20and%20Optimal%20Control;%20Optimization&facet-content-type=Book), [Partial Differential Equations](https://link.springer.com/search?facet-sub-discipline=Partial%20Differential%20Equations&facet-content-type=Book), [Approximations and](https://link.springer.com/search?facet-sub-discipline=Approximations%20and%20Expansions&facet-content-type=Book) [Expansions](https://link.springer.com/search?facet-sub-discipline=Approximations%20and%20Expansions&facet-content-type=Book), [Applications of Mathematics](https://link.springer.com/search?facet-sub-discipline=Applications%20of%20Mathematics&facet-content-type=Book) •

# **Keywords**

- [real analysis](file:///search?query=real%20analysis&facet-discipline=%22Mathematics%22) •
- [measure theory](file:///search?query=measure%20theory&facet-discipline=%22Mathematics%22) •
- [functional analysis](file:///search?query=functional%20analysis&facet-discipline=%22Mathematics%22) •
- [Lebesgue integration](file:///search?query=Lebesgue%20integration&facet-discipline=%22Mathematics%22) •
- [weakly differentiable functions](file:///search?query=weakly%20differentiable%20functions&facet-discipline=%22Mathematics%22) •
- [partial differential equations](file:///search?query=partial%20differential%20equations&facet-discipline=%22Mathematics%22) •

# **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

[Back to top](#page-0-2)

# **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-1-4939-4005-9)

**eBook EUR 67.40** 

Price includes VAT (China (P.R.))

ebook

10.1007/978-1-4939-4005-9

978-1-4939-4005-9

Real Analysis

5372ac675bdcb6c6708dab12da83bbfda8a351fa90fa34a43165c6e803c8ecf20c37a0a990d31535b8cb4f8a9de0b25f8573149ed927a1a6a915bb0caddc1612

- Available as EPUB and PDF
- Read on any device
- Instant download
- Own it forever

Buy eBook

#### **Softcover Book EUR 79.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-1-4939-4005-9

978-1-4939-8151-9

Real Analysis

ee0b3693c89d2d449197b7d1269d409e619e68fd2d14d8d1a23e963fc31a5c1918998648d0c999c8d1a488decbe2b18a7819e57a4f07c118f8e9606a6d8404d9

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

#### **Hardcover Book EUR 79.99**

Price excludes VAT (China (P.R.))

| book                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/978-1-4939-4005-9                                                                                                        |
| 978-1-4939-4003-5                                                                                                                |
| Real Analysis                                                                                                                    |
| 1fc9716216da883cfa8e3e109c8480a9ed83096a6a65a81e0acd42dc112646dde5a1a34ab9d7be8585b81abd64356ef4e26ef5d9d0260e4f8d0da20f409c7d63 |

- Durable hardcover edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Hardcover Book

Tax calculation will be finalised at checkout

# **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-1-4939-4005-9) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# <span id="page-10-1"></span>**Search**

Search by keyword or author

Search

# <span id="page-10-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/) •
- [Publish with us](https://www.springernature.com/gp/authors)  •
- [Track your research](https://link.springernature.com/home/) •

## **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

## **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature