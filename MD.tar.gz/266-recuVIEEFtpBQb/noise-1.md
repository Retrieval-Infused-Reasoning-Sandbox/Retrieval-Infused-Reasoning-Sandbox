#### <span id="page-0-2"></span>[Skip to main content](#page-0-0)

#### Advertisement

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/book/9780387951522) [Springer Nature Link](https://link.springer.com)

[Menu](#page-3-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-3-1)

![](_page_0_Picture_6.jpeg)

- [Home](file:///) 1.
- Textbook 2.

![](_page_0_Picture_9.jpeg)

# **An Introduction to Ergodic Theory**

- Textbook •
- © 1982 •
- Latest edition •

[Accessibility Information](#page-2-0)

## <span id="page-0-0"></span>**Overview**

Authors:

- [Peter Walters](#page-0-1) •
- <span id="page-0-1"></span>Peter Walters [View author publications](file:///search?dc.creator=Peter+Walters&sortBy=newestFirst) 1.

Search author on: [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Peter+Walters) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Peter+Walters%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

Part of the book series: [Graduate Texts in Mathematics](https://link.springer.com/series/136) (GTM, volume 79)

### **Buy print copy**

#### **Softcover Book EUR 55.95**

Price excludes VAT (China (P.R.))

| book |  |
|------|--|
|------|--|

10.1007/978-1-4612-5775-2

978-0-387-95152-2

An Introduction to Ergodic Theory

4f5ce0a1a85ac86638d7225c4f8bf3987215089c714cdc1c19154bf94110050df8cee4b38b5910d69f8b9c922895f1bcc1df5a14f04bb224e4edeccaa6c71026

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

Tax calculation will be finalised at checkout

### **About this book**

This text provides an introduction to ergodic theory suitable for readers knowing basic measure theory. The mathematical prerequisites are summarized in Chapter 0. It is hoped the reader will be ready to tackle research papers after reading the book. The first part of the text is concerned with measure-preserving transformations of probability spaces; recurrence properties, mixing properties, the Birkhoff ergodic theorem, isomorphism and spectral isomorphism, and entropy theory are discussed. Some examples are described and are studied in detail when new properties are presented. The second part of the text focuses on the ergodic theory of continuous transformations of compact metrizable spaces. The family of invariant probability measures for such a transformation is studied and related to properties of the transformation such as topological traitivity, minimality, the size of the non-wandering set, and existence of periodic points. Topological entropy is introduced and related to measure-theoretic entropy. Topological pressure and equilibrium states are discussed, and a proof is given of the

variational principle that relates pressure to measure-theoretic entropies. Several examples are studied in detail. The final chapter outlines significant results and some applications of ergodic theory to other branches of mathematics.

### **Explore related subjects**

Discover the latest articles, books and news in related subjects.

[Analysis](file:///subjects/analysis) •

### <span id="page-2-0"></span>**Accessibility Information**

Accessibility information for this book is coming soon. We're working to make it available as quickly as possible. Thank you for your patience.

### **Bibliographic Information**

Book Title: An Introduction to Ergodic Theory •

Authors: Peter Walters •

Series Title: [Graduate Texts in Mathematics](https://link.springer.com/series/136) •

Publisher: Springer New York, NY •

eBook Packages: [Springer Book Archive](https://metadata.springernature.com/metadata/books) •

Copyright Information: Springer-Verlag New York, Inc. 1982 •

Softcover ISBN: 978-0-387-95152-2Published: 06 October 2000 •

Series ISSN: 0072-5285 •

Series E-ISSN: 2197-5612 •

Edition Number: 1 •

Number of Pages: IX, 250 •

# **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

[Back to top](#page-0-2)

### **Buy print copy**

**Softcover Book EUR 55.95** 

Price excludes VAT (China (P.R.))

book

10.1007/978-1-4612-5775-2

978-0-387-95152-2

An Introduction to Ergodic Theory

4f5ce0a1a85ac86638d7225c4f8bf3987215089c714cdc1c19154bf94110050df8cee4b38b5910d69f8b9c922895f1bcc1df5a14f04bb224e4edeccaa6c71026

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

Tax calculation will be finalised at checkout

# <span id="page-3-1"></span>**Search**

Search by keyword or author

Search

### <span id="page-3-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/) •
- [Publish with us](https://www.springernature.com/gp/authors)  •

[Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature