![](_page_0_Picture_2.jpeg)

**https://doi.org/10.1093/imrn/rnae047** Advance access publication date 25 March 2024

**Article**

# **Neutralized Local Entropy and Dimension bounds for Invariant Measures**

S. Ben Ovadia and F. Rodriguez-Hertz

Department of Mathematics, Pennsylvania State University, State College, PA 16801, USA \*Corresponding author: [Snir.ben.ovadia@gmail.com](
 8157
13076 a 8157 13076 a
 ) Communicated by Prof. Pablo Shmerkin

We introduce a notion of a point-wise entropy of measures (i.e., local entropy) called *neutralized local entropy*, and compare it with the Brin-Katok local entropy. We show that the neutralized local entropy coincides with Brin-Katok local entropy almost everywhere. Neutralized local entropy is computed by measuring open sets with a relatively simple geometric description. Our proof uses a measure density lemma for Bowen balls, and a version of a Besicovitch covering lemma for Bowen balls. As an application, we prove a lower point-wise dimension bound for invariant measures, complementing the previously established bounds for upper point-wise dimension.

# **1 Introduction and Main Results**

One of the most useful tools in studying dynamical systems are dynamical covers and partitions of a measure. That is, given an invariant measure, a cover or a partition modulo the measure, whose elements have a significant structure w.r.t the dynamics. The pursuit for such objects creates a tension between searching for elements with a simple geometric description, with which it is easy to work, and searching for elements with significant dynamical structure, which allows to control their orbits and measure. Two characteristic examples of this tension are geometric balls and Bowen balls.

Geometric balls allow one to utilize strong geometric properties such as the Lebesgue density theorem or the Besicovitch covering lemma. Bowen balls, on the other hand, allow one to estimate their measure in terms of the entropy (see [[2](#page-11-0)]), and control their image under the dynamics for a fixed amount of iterations, while having a possibly very complicated geometric shape.

<span id="page-0-1"></span><span id="page-0-0"></span>Pesin theory allows one to linearize locally the action of the dynamics on typical orbits. However, the size of the neighborhood where the linearization is valid may deteriorate along the orbit, although in a sub-exponential rate. Given an ergodic measure with positive metric entropy, the Ruelle inequality says it must have some positive and some negative Lyapunov exponents [[7](#page-11-1)]. When an orbit admits a central direction, that is, an invariant sub-space of the tangent space corresponding to 0 Lyapunov exponents, the central direction may not be integrable into an invariant manifold. In addition, the differential may contract or expand tangent vectors in the central direction, in a sub-exponential way. These effects make it very hard, and generally not attainable, to get a simple description of the set of points which remain close to the orbit for a fixed amount of steps.

Furthermore, even in the absence of 0 Lyapunov exponents, the decay of the size of the Pesin chart (i.e., neighborhood with a local linearization of the dynamics) does not allow to control the set of points, which remain close to the orbit by a fixed distance (i.e., Bowen balls). Hence, phasing-out subexponential effects such as the central direction or the deterioration of the size of Pesin charts becomes very useful. Removing these effects allows one to treat the action of the dynamics along an orbit as if they were linear and hyperbolic, and so simplifying greatly the geometric description of the set of points, which shadow the orbit (or part of it).

Our goal in this paper is to address exactly this difficulty. Our proof relies on a sub-exponential measure density lemma over Bowen balls (rather than geometric balls as in the Lebesgue density lemma).

In our setup M is a closed Riemannian manifold,  $d = \dim M \ge 2$ , and  $f \in \text{Diff}^{1+\beta}(M)$ ,  $\beta > 0$ . Let  $\mu$  be an f-invariant Borel probability measure. The purpose of this paper is to compute the neutralized local entropy defined by

$$\mathcal{E}_{\mu}(\mathbf{x}) := \lim_{r \to 0} \limsup_{n \to \infty} \frac{-1}{n} \log \mu(\mathbf{B}(\mathbf{x}, n, e^{-rn})), \tag{1}$$

where  $B(x, n, e^{-m}) := \{y \in M : d(f^i(y), f^i(y)(x)) \le e^{-m}, \forall 0 \le i \le n\}$ . One can check the following properties for the neutralized local entropy:

(a) 
$$\mathcal{E}_{\mu}(x) \in [h_{\mu}^{BK}(x), d \cdot \log M_f] \mu\text{-a.e,} \tag{2}$$

where  $M_f := \max_{x \in M} \{\|d_x f\|, \|d_x f^{-1}\|\}$ , and  $h_u^{BK}(x)$  is the local entropy at x given by the Brin-Katok formula [2].  $(h_{\mu}^{BK}(x) = \lim_{\epsilon \to 0} \limsup_{n \to \infty} \frac{-1}{n} \log \mu(B(x, n, \epsilon)) = \lim_{\epsilon \to 0} \liminf_{n \to \infty} \frac{-1}{n} \log \mu(B(x, n, \epsilon))$ , where the limits exist, the equality holds  $\mu$ -a.e, and  $B(x, n, \epsilon) = \{y \in M : d(f^i(x), f^i(y)) \le \epsilon, \forall 0 \le i \le n\}.$  The upper bound is given by the classical lemma, which states that  $\lim_{s\to 0} \frac{\log \mu(B(x,s))}{\log s} \leq d$  for  $\mu$ -a.e x, and by the fact that  $B(x, n, e^{-m}) \supseteq B(x, M_f^{-n})$  for all  $n \ge 0$  and sufficiently small r > 0.

(b)

$$\mathcal{E}_{\mu} \circ f = \mathcal{E}_{\mu} \mu$$
-a.e. (3)

This can be seen by the following two inequalities:

(I) 
$$\mathcal{E}_{\mu}(f(x)) \geq \mathcal{E}_{\mu}(x)$$
: since

$$\mu(B(f^{-1}(x), n, e^{-m})) = \mu(f[B(f^{-1}(x), n, e^{-m})]) \le \mu(B(x, n, M_f e^{-m})),$$

(II) 
$$\mathcal{E}_{\mu}(f(x)) \leq \mathcal{E}_{\mu}(x)$$
: since

$$\mu(B(f^{-1}(x), n, e^{-rn})) \ge \mu(f^{-1}[B(x, n+1, e^{-r\frac{n}{n+1} \cdot (n+1)})]) \ge \mu(B(x, n+1, e^{-r(n+1)})).$$

The significance of the neutralized entropy is that it estimates the asymptotic measure of sets with a distinctive geometric shape. Unlike the sequence  $\{B(x, n, r)\}_{n \ge 0}$ , which can develop a very complicated geometric shape for large n- due to a central direction, or even for a non-uniformly hyperbolic trajectory, the sequence  $\{B(x, n, e^{-rn})\}_{n\geq 0}$  can have a nice description a.e for any r>0, by neutralizing any subexponential effects. Sets with a more explicit geometric description are very useful for the construction of covers (or consequently even partitions), and so controlling the measure of such sets is important.

In fact, one can guess that by the lack of diversity for intrinsic dynamical invariants, the neutralized local entropy must coincide with other notions of local entropy (or the metric entropy in the ergodic case). This paper is dedicated to the proof of this statement for smooth systems.

<span id="page-1-5"></span>Thieullen [11] studied a similar notion to the neutralized local entropy, called  $\alpha$ -entropy, for certain systems on infinite-dimensional systems (see also [10, 12]). Other generalizations of entropy have also been studied in terms of ergodic theory for some systems by [8, 9].

As an application of the neutralized local entropy, in Theorem 4.1 we prove a lower bound for the point-wise dimension of ergodic invariant measures: for almost every point

<span id="page-1-6"></span><span id="page-1-4"></span><span id="page-1-3"></span><span id="page-1-2"></span><span id="page-1-1"></span><span id="page-1-0"></span>
$$\liminf_{r\to 0} \frac{\log \mu(B(x,r))}{\log r} \ge d^{u} + d^{s},$$

where  $d^u$  and  $d^s$  are the point-wise dimension of the conditional measures of  $\mu$  along the unstable and the stable laminations, resp. (see Section 4 for details). This extends the previous result in [1] for hyperbolic measures, and complements the upper bound in [6]. In particular, using the notion of neutralized local entropy, the proof of Theorem 4.1 is relatively elementary as it only uses covers and does not require constructing adapted partitions.

### 2 Covering, Differentation, and Ergodic Theorems

Let M be a closed Riemannian manifold,  $d = \dim M \ge 2$ , and let  $f \in \text{Diff}^{1+\beta}(M)$ ,  $\beta > 0$ . **Notation:** Throughout the paper, given A, B, C > 0, we write  $A = B \cdot e^{\pm C}$  to mean  $Be^{-C} \le A \le Be^{C}$ .

- <span id="page-2-2"></span>**Definition 2.1.** (Pesin blocks). Let  $\mu$  be an f-invariant ergodic probability measure which admits a positive Lyapunov exponent. Denote by  $\chi = \chi(\mu) := (\chi_1, m_1, \dots, \chi_{\ell_r}, m_{\ell_r})$  the positive Lyapunov exponents, and dimensions of the corresponding Oseledec subspaces, of  $\mu$  in a decreasing
  - 1) Let  $0 < \tau \le \tau_{\underline{\chi}} := \frac{1}{100d} \min\{\chi_{\ell_{\underline{\chi}}}, \chi_i \chi_{i+1} : i \le \ell_{\underline{\chi}} 1\}$ , and let  $C_{\underline{\chi},\tau}(\cdot)$  be the Lyapunov change of coordinates for points in  $LR_{\chi} = \{Lyapunov \text{ regular points with an index } \chi \}$  (see [4]).
  - 2) Let  $PR_{\underline{\chi}} = \{x \in LR_{\underline{\chi}} : \limsup_{n \to \pm \infty} \frac{1}{n} \log \|C_{\chi,\tau}^{-1}(f^n(x))\| = 0, \forall 0 < \tau \leq \tau_{\underline{\chi}}\}$ , the set of  $\underline{\chi}$ -Pesin regular points, which carries  $\mu$ . PR :=  $\bigcup_{\chi} PR_{\underline{\chi}}$  is called the set of Pesin regular points.
  - 3) Given  $x \in PR_{\chi}$ , let  $E_{j}(x)$  be the Oseledec subspace of x corresponding to  $\chi_{j}$ .
  - 4) A Pesin block  $\Lambda_{\ell}^{(\underline{\chi},\tau)}$  is a subset of  $\bigcup_{|\underline{\chi}'-\underline{\chi}|_{\infty}<\tau} PR_{\underline{\chi}'}$  which is a level set  $[q_{\tau}\geq\frac{1}{l}]$  of a measurable function  $q_{\tau}: \bigcup_{|\underline{\chi}'-\underline{\chi}|_{\infty}<\tau} PR_{\underline{\chi}'} \to (0,1)$  s.t (a)  $\frac{q_{\tau}\circ f}{q_{\tau}} = e^{\pm \tau}$ , (b)  $q_{\tau}(\cdot) \leq \frac{1}{\|C_{\tau}^{-1}(\cdot)\|^{\frac{d}{p}}}$ . Often we omit the subscript  $\ell$  when the dependence on  $\ell$  is clear from the context.
- <span id="page-2-0"></span>**Lemma 2.2.** (Besicovitch-Bowen covering lemma). Let  $\Lambda^{(\underline{\chi},\tau)}$  (0 <  $\tau \leq \tau_{\gamma}$ ) be a Pesin block, and let  $x_0 \in \Lambda^{(\underline{\chi},\tau)}$ . Let  $B(x_0)$  be the Pesin chart of  $x_0$  for  $\Lambda^{(\underline{\chi},\tau)}$ . Let  $A \subseteq \Lambda^{(\underline{\chi},\tau)} \cap B(x_0)$  be a measurable subset. Then A can be covered by a cover of exponential Bowen balls of points in A (i.e., B(·, n,  $e^{-n\epsilon}$ )), with multiplicity bounded by  $e^{3d\tau n}$ , where n is sufficiently large w.r.t  $\Lambda^{(\underline{\chi},\tau)}$ , and  $\epsilon \geq 2\tau$ .

The idea of the proof follows the principle steps of the proof of the classical Besicovitch covering lemma (see [3, § 18]), using a certain volume doubling property for exponential Bowen balls.

<span id="page-2-1"></span>**Proof.** Let  $n \in \mathbb{N}$  sufficiently large so  $e^{-\epsilon n}$  is smaller than the Pesin chart size for  $\Lambda^{(\underline{\chi},\tau)}$ . Set  $A_1 := A$ , and choose  $x_1 \in A_1$ . Given k, set  $A_{k+1} := A \setminus \bigcup_{i=1}^k B(x_i, n, e^{-n\epsilon})$  and choose  $x_{k+1} \in A_{k+1}$ . Continue in this process as long as A \  $\bigcup_{i=1}^{k} B(x_i, n, e^{-n\epsilon})$  is not empty.

Claim 1:  $\forall k < j$ ,  $B(x_j, n, \frac{1}{3}e^{-n\epsilon}) \cap B(x_k, n, \frac{1}{3}e^{-n\epsilon}) = \emptyset$ .

Proof: Otherwise,  $\forall i \leq n, d(f^i(x_k), f^i(x_i)) \leq \frac{2}{3}e^{-\epsilon n}$ , whence  $x_i \in B(x_k, n, e^{-n\epsilon})$ , in contradiction to the choice of  $\{x_l\}_{l>1}$ .

Claim 2:  $\exists N \in \mathbb{N} \text{ s.t } \bigcup_{k=1}^{N} B(x_k, n, e^{-\epsilon n}) \supseteq A.$ 

Proof: For any  $k \geq 1$ ,  $Vol(B(x_k, n, \frac{1}{3}e^{-\epsilon n})) = C^{\pm 1} \cdot e^{-\underline{x}^u n} \cdot e^{-d_{cs}\epsilon n}e^{\pm d\tau n}$ , where  $e^{-\underline{x}^u n} = \prod_{i \leq \ell_x} e^{-x_i n \cdot m_i}$ ,  $m_i$  is the multiplicity of  $\chi_i$ ,  $d_{CS} := \sum_{i:\gamma_i < 0} \dim E_i$ , and C is a constant depending on M, d, and  $\Lambda^{(\underline{X},\epsilon)}$ . Then  $N \leq 1$ Vol(M)  $\frac{C^{-1} \cdot e^{-\underline{\chi}^{U_{\eta}}} \cdot e^{-d\tau n} \cdot e^{-d_{CS} \epsilon n}}{C^{-1} \cdot e^{-\underline{\chi}^{U_{\eta}}} \cdot e^{-d\tau n} \cdot e^{-d_{CS} \epsilon n}}$ 

Claim 3:  $\bigcup_{k=1}^{N} A_k \supseteq A$ .

Proof: The process continues unless A is covered.

Claim 4:  $\forall k \leq N$ ,  $\#\{j \leq N : B(x_j, n, e^{-n\epsilon}) \cap B(x_k, n, e^{-n\epsilon}) \neq \emptyset\} \leq C_d e^{2dn\tau}$ , where  $C_d$  is a constant depending on M and on  $\Lambda^{(\underline{\chi},\tau)}$ .

Proof: Let  $k \le N$ , and let  $k \ne j \le N$  s.t  $B(x_i, n, e^{-n\epsilon}) \cap B(x_k, n, e^{-n\epsilon}) \ne \emptyset$ . Then,

$$B(x_j, n, \frac{1}{3}e^{-n\epsilon}) \subseteq B(x_j, n, e^{-n\epsilon}) \subseteq B(x_k, n, 3e^{-n\epsilon}).$$

Then,

$$\#\{j \leq N : B(x_j, n, e^{-n\epsilon}) \cap B(x_k, n, e^{-n\epsilon}) \neq \varnothing\} \leq \frac{\max_{k \leq N} Vol(B(x_k, n, 3e^{-n\epsilon}))}{\min_{i < N} Vol(B(x_i, n, \frac{1}{3}e^{-n\epsilon}))} \leq C^2 3^{2d} e^{2d\tau n}.$$

Claim 5: We can divide  $\{x_k\}_{k\leq N}$  into sub-collections  $C_i$ ,  $i=1,\ldots,\lceil C_d e^{2nd\tau}+1\rceil$ , where for any  $i\leq \lceil C_d e^{2dn\tau}+1\rceil$ ,  $\{B(x,n,e^{-\epsilon n}):x\in C_i\}$  is a mutually disjoint collection. In particular, for n sufficiently large,  $\lceil C_d e^{2n\tau}+1\rceil\leq e^{3dn\tau}$ .

Proof: Let  $K_n := \lceil C_d e^{2nd\tau} + 1 \rceil$ . We associate  $x_k$  with  $C_k$  for all  $k \le K_n$ . For each  $k > K_n$ , we allocate it into one of the pre-existing collections in the following way.

Given  $B(x_{K_n+1},n,e^{-\epsilon n})$ , by claim 4, there exists at least one  $i_{K_n+1} \leq K_n$  s.t  $B(x_{K_n+1},n,e^{-\epsilon n}) \cap B(x_{i_{K_n+1}},n,e^{-\epsilon n}) = \emptyset$ ; so allocate  $x_{K_n+1}$  to  $C_{i_{K_n+1}}$ .

Next, consider  $B(x_{K_n+2}, n, e^{-\epsilon n})$ , at least two of the  $K_n+1$ -first balls do not intersect it. If any of the balls  $2, \ldots, K_n$  do not intersect  $B(x_{K_n+2}, n, e^{-\epsilon n})$ , allocate it to the first associated collection as such. If all of the balls of  $1, \ldots, i_{K_n+1}-1, i_{K_n+1}+1, \ldots, K_n$  intersect it, then allocate it to  $\mathcal{C}_{i_{K_n+1}}$ , which now contains three disjoint balls.

We continue by induction. Assume that the balls  $\{B(x_j, n, e^{-\epsilon n})\} \le K_n + l - 1$  have all been allocated into one of the  $K_n$ -many disjoint sub-collections. Consider  $B(x_{K_n+l}, n, e^{-\epsilon n})$ , which is disjoint from at least l balls in  $\{B(x_j, n, e^{-\epsilon n})\} \le K_n + l - 1$ . This implies that least one of the collections  $C_i$ ,  $i \le K_n$ , is disjoint from  $B(x_{K_n+l}, n, e^{-\epsilon n})$ , to which we may allocate it.

<span id="page-3-0"></span>**Lemma 2.3.** (Bowen-Lebesgue density lemma). Let  $\mu$  be an f-invariant probability measure. Let A be a measurable set s.t  $\mu(A) > 0$ . Then for  $\mu$ -a.e  $x \in A$ ,

$$\lim_{r\to 0} \limsup_{n\to \infty} \frac{-1}{n} \log \frac{\mu(B(x, n, e^{-nr}) \cap A)}{\mu(B(x, n, e^{-nr}))} = 0.$$

**Proof.** First, assume that  $\exists \lambda > 0$  s.t (w.l.o.g) for  $\mu$ -a.e  $x \in A$ .

$$\lim_{r\to 0} \limsup \frac{-1}{n} \log \frac{\mu(B(x, n, e^{-rn}) \cap A)}{\mu(B(x, n, e^{-m}))} \ge \lambda.$$

Let  $0 < r < \frac{1}{2d} \frac{\lambda}{4}$  s.t  $\mu(A^{(0)}) > 0$  where

$$A^{(0)} := \{ x \in A : \limsup \frac{-1}{n} \log \frac{\mu(B(x, n, e^{-m}) \cap A)}{\mu(B(x, n, e^{-m}))} \ge \frac{7\lambda}{8} \}.$$

Then it follows that  $\mu(A^{(1)}) > 0$  where  $A^{(1)} := A^{(0)} \cap \Lambda^{(\underline{\chi},\tau)}$  for some index  $\underline{\chi}$  and  $\tau \leq \min\{\frac{r}{2}, \tau_{\underline{\chi}}\}$  (this can be achieved by first dividing the parameter space of  $\underline{\chi}$  by the Oseledec dimensions, then by boxes around each  $\underline{\chi}'$  of size  $\frac{1}{2}\tau_{\chi'}$ , and then further by boxes of size  $\tau := \min\{\frac{r}{2}, \frac{1}{2}\tau_{\chi'}\}$ ; whence  $\frac{1}{2}\tau_{\chi'} \leq \tau_{\chi}$ ).

Let  $N \ge 1$  large and  $x \in A^{(1)}$ , and set

$$n_{x}^{N} := \min\{n \geq N : \frac{-1}{n} \log \frac{\mu(B(x, n, e^{-m}) \cap A)}{\mu(B(x, n, e^{-m}))} \geq \frac{6\lambda}{8}\}.$$

Set for all  $n \ge N$ ,

$$A_n^{(1)} := \{ x \in A^{(1)} : n_n^N = n \}.$$

By Lemma 2.2, we can choose a finite subset  $C_n \subseteq A_n^{(1)}$  s.t  $\bigcup_{x \in C_n} B(x, n, e^{-m}) \supseteq A_n^{(1)}$  while  $\{B(x, n, e^{-m})\}_{x \in C_n}$  has an overlap bound smaller than  $e^{3d\tau n} \le e^{3d\frac{\tau}{2}n} \le e^{\frac{s}{8}n}$  (for all n large enough depending on M and  $\Lambda^{(\underline{\chi}, \tau)}$ ). Then,

$$\begin{split} \mu(A_n^{(1)}) = & \mu\left((\bigcup_{x \in C_n} B(x, n, e^{-m})) \cap A_n^{(1)}\right) \leq \sum_{x \in C_n} \mu(B(x, n, e^{-m}) \cap A_n^{(1)}) \leq \sum_{x \in C_n} \mu(B(x, n, e^{-m}) \cap A) \\ \leq & \sum_{x \in C_n} \mu(B(x, n, e^{-m})) e^{-\frac{6\lambda}{8}n} \leq e^{-\frac{6\lambda}{8}n} e^{\frac{\lambda}{8}n} \mu(\bigcup_{x \in C_n} B(x, n, e^{-m})) \leq e^{-\frac{5\lambda}{8}n}. \end{split}$$

Then,

$$\mu(\mathbf{A}^{(1)}) = \sum_{n > N} \mu(\mathbf{A}_n^{(1)}) \le \sum_{n > N} e^{-\frac{5\lambda}{8}n} \le (\sum_{n > 0} e^{-\frac{5\lambda}{8}n}) \cdot e^{-\frac{5\lambda}{8}N} \xrightarrow{N \to \infty} 0, \text{ a contradiction!}$$

Remark: A possible heuristic way to interpret Lemma 2.3 is the following: we think of belonging to a measurable set as satisfying some property. Then, for almost any point that satisfies a certain property, more and more points that spend a long portion of their orbit close to this point inherit this property as well. That is, a portion of the exponential Bowen ball, with bigger and bigger exponential portion bounds, lies in the measurable set as well.

<span id="page-4-0"></span>**Corollary 2.4.** (log-differentation lemma). Let  $\mu$  be an f-invariant probability measure, and let  $q \in \mathcal{M}(\mu)$  be a measurable function and  $A \in \mathcal{B}$  be a measurable set with  $\mu(A) > 0$ . Then for  $\mu$ -a.e  $x \in A$ ,

$$\lim_{\epsilon \to 0} \limsup_{n \to \infty} \frac{-1}{n} \log \left( \frac{1}{\mu(B(x, n, e^{-n\epsilon}))} \int_{B(x, n, e^{-n\epsilon})} e^{-n|g(y) - g(x)|} \mathscr{W}_{A}(y) d\mu(y) \right) = 0.$$

**Proof.** Let  $\delta > 0$ , and let  $a \in \mathbb{R}$  s.t  $\mu(E) > 0$  where  $E := A \cap q^{-1}[[a - \frac{\delta}{2}, a + \frac{\delta}{2}]]$ . Let  $x \in E$ ,  $n \geq 0$ , and  $\epsilon > 0$ , then

$$\begin{split} \frac{1}{\mu(B(x,n,e^{-\epsilon n}))} \int_{B(x,n,e^{-\epsilon n})} e^{-n|g(y)-g(x)|} \mathscr{U}_{\mathbb{A}}(y) d\mu(y) &\geq \frac{1}{\mu(B(x,n,e^{-\epsilon n}))} \int_{B(x,n,e^{-\epsilon n})\cap E} e^{-n\delta} d\mu(y) \\ &= e^{-n\delta} \frac{\mu(B(x,n,e^{-\epsilon n})\cap E)}{\mu(B(x,n,e^{-\epsilon n}))}. \end{split}$$

Then by Lemma 2.2, for  $\mu$ -a.e  $x \in E$ ,  $\lim_{\epsilon \to 0} \limsup_{n \to \infty} \frac{-1}{n} \log \frac{1}{\mu(B(x,n,e^{-n\epsilon}))} \int\limits_{B(x,n,e^{-n\epsilon})} e^{-n|g(y)-g(x)|} \mathscr{W}_A(y) d\mu(y) \leq \delta.$ Since  $\delta > 0$  was arbitrary (and the limit is independent of a), we are don

**Theorem 2.5.** (Log-Ergodic Theorem). Let  $\mu$  be an f-invariant probability measure, let A be a measurable set s.t  $\mu(A) > 0$ , and let  $q \in L^1(\mu)$ . Then for  $\mu$ -a.e  $x \in A$ ,

$$\lim_{r \to 0} \limsup_{n \to \infty} \frac{-1}{n} \log \frac{1}{\mu(B(x, n, e^{-nr}))} \int_{B(x, n, e^{-nr})} \mathbb{1}_{\mathbb{R}_A(y)} \cdot e^{-|\sum_{j=0}^{n-1} g \circ f^{-j}(y) - \sum_{j=0}^{n-1} g \circ f^{-j}(x)|} d\mu(y) = 0.$$

**Proof.** Let  $\mu = \int \mu_X d\mu(X)$  be the ergodic decomposition of  $\mu$ . Since  $g \in L^1(\mu)$ , for  $\mu$ -a.e  $x, g \in L^1(\mu_X)$ . Then for  $\mu$ -a.e x,  $\lim_{n\to\infty}\frac{1}{n}\sum_{i=0}^{n-1}(g-\int gd\mu_x)\circ f^{-i}(x)=0$ . Let  $\delta>0$ , and let  $n_\delta\geq 0$  s.t  $\mu(A_\delta)\geq e^{-\delta}\mu(A)$  where

$$A_{\delta} := \left\{ y \in A : \forall n \geq n_{\delta}, \left| \sum_{j=0}^{n-1} (g - \int g d\mu_{y}) \circ f^{-j}(y) \right| \leq n\delta \right\}.$$

Let  $x \in A_{\delta}$ , then for all  $n > n_{\delta}$  and r > 0,

$$\begin{split} \int\limits_{B(x,n,e^{-nr})} \mathbb{W}_{A}(y) \cdot e^{-|\sum_{j=0}^{n-1} g \circ f^{-j}(y) - \sum_{j=0}^{n-1} g \circ f^{-j}(x)|} d\mu(y) \\ & \geq \int\limits_{B(x,n,e^{-nr})} \mathbb{W}_{A_{\delta}}(y) \cdot e^{-|\sum_{j=0}^{n-1} (g - \int g d\mu_{y}) \circ f^{-j}(y)| - n|\int g d\mu_{y} - \int g d\mu_{x}| - |\sum_{j=0}^{n-1} (g - \int g d\mu_{x}) \circ f^{-j}(x)|} d\mu(y) \\ & \geq e^{-2\delta n} \int_{B(x,n,e^{-nr})} \mathbb{W}_{A_{\delta}}(y) \cdot e^{-n|G(y) - G(x)|} d\mu(y), \end{split}$$

where  $G(y) := \int g d\mu_y$ . Then by the log-differentiation lemma (Corollary 2.4) for G, and since  $\delta > 0$  was arbitrary, we are done.

## 3 Neutralized Local Entropy is Entropy

<span id="page-5-3"></span>**Lemma 3.1.** Let  $\mu$  be an f-invariant Borel probability, and let  $\mu = \int \mu_x d\mu(x)$  be its ergodic decomposition. Then  $h_{\mu}^{\rm BK}(x) = h_{\mu\nu}(f) \mu$ -a.e.

**Proof.** Let  $E_{\lambda}:=\{x:h_{\mu}^{BK}(x)\geq h_{\mu_{x}}(f)+\lambda\}$ , and assume that there exists  $\lambda>0$  s.t  $\mu(E_{\lambda})>0$  (notice that  $E_{\lambda}$  is f-invariant). Let  $G_{\lambda}:=\{x:\mu_{x}(E_{\lambda})=1\}$  with  $a_{\lambda}:=\mu(G_{\lambda})>0$  (o.w  $\mu(E_{\lambda})=0$ ). Write  $\mu_{\lambda}:=\frac{1}{\mu(G_{\lambda})}\int_{G_{\lambda}}\mu_{x}d\mu(x)$ , and  $\mu_{c}:=\frac{1}{a_{c}}(1-\mu_{\lambda})$  where  $a_{c}:=1-a_{\lambda}$ . Then  $\mu=a_{\lambda}\mu_{\lambda}+a_{c}\mu_{c}$  and for  $\mu_{\lambda}$ -a.e x,

$$h_{\mu_{\lambda}}^{BK}(x) \ge h_{\mu}^{BK}(x) \ge h_{\mu_{X}}(f) + \lambda.$$

However, this is a contradiction, since integrating both sides by  $\mu_{\lambda}$  admits  $h_{\mu_{\lambda}}(f) \geq h_{\mu_{\lambda}}(f) + \lambda$ , a contradiction! Hence,  $h_{\mu}^{BK}(x) \leq h_{\mu_{\lambda}}(f) \mu$ -a.e., but  $\int h_{\mu}^{BK}(x) d\mu(x) = \int h_{\mu_{\lambda}}(f) d\mu(x)$ , hence  $h_{\mu}^{BK}(x) = h_{\mu_{\lambda}}(f) \mu$ -a.e.

<span id="page-5-0"></span>**Lemma 3.2.** Let  $\mu$  be an f-invariant Borel probability, and K be a  $\mu$ -positive measure set, and let  $\delta > 0$ . Assume that  $\exists \Delta > 0$  s.t  $h_{\mu}^{\rm BK}(x) \leq h + \Delta$  for  $\mu$ -a.e  $x \in K$ . Then for all n large enough w.r.t  $\delta$  and K, there exist a measurable subset  $K_{\delta} \subseteq K$  and a subset  $A_{n,\delta}$  and  $0 < \rho \leq \delta$  s.t

- 1)  $\bigcup_{x \in A_{n,\delta}} B(x, n, \rho) \supseteq K_{\delta}$ ,
- 2)  $\frac{\mu(K_{\delta})}{\mu(K)} \geq e^{-\delta}$ ,
- 3)  $\#\mathcal{A}_{n,\delta} \leq e^{n(h+\Delta+\delta)}$ .

**Proof.** For  $\mu$ -a.e  $x \in K$ ,  $\lim_{r\to 0} \limsup \frac{-1}{n} \log \mu(B(x,n,r)) \le h + \Delta$ . Set  $K_{\delta} \subseteq K$  and  $n_{\delta} \in \mathbb{N}$  s.t  $\forall x \in K_{\delta}$ ,  $\forall n \ge n_{\delta}$ ,  $\mu(B(x,n,\frac{\rho}{2})) \ge e^{-n(h+\Delta+\delta)}$ , and  $\mu(K_{\delta}) \ge e^{-\delta}\mu(K)$ , for some  $0 < \rho \le \delta$ .

Let  $n \ge n_\delta$ . Set  $K^1 := K_\delta$ , and let  $x_1 \in K^1$ .  $K^{i+1} := K^i \setminus B(x_i, n, \rho)$ , and choose  $x_{i+1} \in K^{i+1}$ .

For any  $i \neq j$ ,  $B(x_i, n, \frac{\rho}{3}) \cap B(x_j, n, \frac{\rho}{3}) = \emptyset$ , hence we have at most  $e^{n(h+\Delta+\delta)}$ -many elements in  $\{x_i\}_i =: \mathcal{A}_{n,\delta}$ . Moreover, one can check that  $\bigcup_{X \in \mathcal{A}_{n,\delta}} B(x, n, \rho) \supseteq K_{\delta}$ .

<span id="page-5-4"></span>**Corollary 3.3.** Let  $\chi_0 > 0$ ,  $\tau \in (0, \frac{\chi_0}{100d})$ ,  $\epsilon \ge 4\tau$  small (w.r.t  $\chi_0$ ),  $\gamma \ge \sqrt{\epsilon}$ ,  $\ell \in \mathbb{N}$ , and let n' s.t  $\mu(K) > 0$  where

<span id="page-5-2"></span>
$$K \subseteq \left\{ x \text{ Lyap. reg. s.t} \chi_{\min}^{u}(x), \chi_{\min}^{s}(x) \ge \chi_{0} : \right. \tag{4}$$
 
$$\forall n \ge n', x \in \Lambda_{\ell}^{(\underline{\chi}(x),\tau)} \cap \Big( \bigcup_{n(1+\gamma) \le i \le n(1+2\gamma)} f^{-i} [\Lambda_{\ell}^{(\underline{\chi}(x),\tau)}] \Big) \right\}.$$

Assume that  $h_{\mu}^{\mathrm{BK}} \leq h + \Delta$  for  $\mu$ -a.e  $x \in K$ . Then there exists  $K_{\tau} \subseteq K$  s.t  $\mu(K_{\tau}) \geq e^{-\tau}\mu(K)$  and for all n large enough,  $\exists \mathcal{A}_n \subseteq K_{\tau}$  s.t  $\bigcup_{x \in \mathcal{A}} B(x, n, e^{-\epsilon n}) \supseteq K_{\tau}$  and  $\#\mathcal{A}_n \leq e^{n(1+2\gamma)(h+\Delta+3d\epsilon)}$ .

**Proof.** Let  $K_{\tau}$  and  $n_{\tau}$  as in Lemma 3.2, for some  $0 < \rho \le \tau$ .

Let  $n \ge \max\{n_{\tau}, n'\}$ , and let  $C_n$  be a Besicovitch cover of  $K_{\tau}$  by balls of radius  $e^{-2\epsilon n}$ .

For each such ball B, we cover  $K_{\tau} \cap B$  with at most  $e^{n(1+2\gamma)(h+\Delta+\tau)}$ -many Bowen balls of the form  $B(\cdot, \lfloor n(1+2\gamma)\rfloor, \rho)$  by Lemma 3.2. Hence, in total we cover  $K_{\tau}$  with at most  $B_d C_M e^{2d\epsilon n} e^{n(1+2\gamma)(h+\Delta+\tau)}$ -many elements, where  $B_d$  is the Besicovitch constant of M, and  $C_M$  is a constant s.t  $Vol(B(x, e^{-2\epsilon n})) \geq \frac{1}{C_M} e^{-2d\epsilon n}$  for all  $x \in M$  and n large.

<span id="page-5-1"></span>Let  $B \in \mathcal{C}_n$ , and let  $\mathcal{A}_{n,\tau}^B$  as in Lemma 3.2 for  $B \cap K_{\tau}$ . Let  $x \in \mathcal{A}_{n,\tau}^B$ , and notice that for  $j_x \in [\lfloor n(1+\gamma) \rfloor, \lfloor n(1+2\gamma) \rfloor]$ ,

$$B(x, \lfloor n(1+2\gamma) \rfloor, \rho) \cap B \subseteq B(x, j_x, \rho) \cap B(x, 2e^{-2\epsilon n}) \subseteq B(x, n, e^{-\epsilon n}), \tag{5}$$

for all n large enough depending on  $\ell$  and  $\epsilon$  (we prove (5) in the end of this lemma). Thus, in total,  $\{B(x, n, e^{-\epsilon n}) : x \in A_{n, r}^B, B \in C_n\}$  is a cover of  $K_r$  by exponential Bowen balls, of cardinality bounded by  $e^{n(1+2\gamma)(h+\Delta+3d\epsilon)}$  for all n large enough.

To prove (5), we work with Pesin charts, which is where we need the assumption from (4).

Let  $x \in K$ . We wish to show that for all n large enough (depending on  $\ell$ ),  $\forall i \in [1, n]$ ,  $\forall y \in B(x, j_x, \rho) \cap I$  $B(x, 2e^{-2\epsilon n}), f^i(y) \in B(f^i(x), e^{-\epsilon n})$ . Letting  $\psi_i$  be the Pesin chart of  $f^i(x)$ , it is enough to show that  $|\psi_i|^{-1} \circ f^i \circ f^i(x)$  $|\psi_0(v_y)| \le e^{-\frac{5}{4}\epsilon n}$ , where  $v_y := \psi_0^{-1}(y)$ .

Write  $\psi_i^{-1} \circ f^i \circ \psi_0(v_y) = v = v^s + v^c + v^u$ , where  $v^t \in E^t(x)$ ,  $t \in \{s, c, u\}$ . Set  $f_i := \psi_{i+1}^{-1} \circ f \circ \psi_i$ , and  $F_i := f_{i-1} \circ \cdots \circ f_0$ . We assume for the simplicity of presentation that all of the negative Lyapunov exponents of x are equal, and that all of the positive Lyapunov exponents of x are equal, otherwise decompose  $v_s$ and  $v_u$  into corresponding components.

A standard result of Pesin theory tells us that the maps  $f_i$  can be put in the form  $f_i = \sum_{t \in \{s,c,u\}} D_t v_t + D_t v_t$  $h_i^t(\nu), \|h_i^t\|_{C^1} \leq \tau, \text{ and where } D_t \text{ are linear self-maps of } E^t, \text{ and } e^{\chi^s(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq \|D_s^{-1}\|, \|D_s\| \leq e^{-\chi^s(x) + \tau}, e^{-\chi^u(x) + \tau} \geq e^{-\chi^u(x) + \tau}$  $||D_u^{-1}||, ||D_u|| \le e^{\chi^u(x)+\tau}$ , and  $||D_c^{-1}||, ||D_c|| \le e^{\tau}$ .

Therefore, the stable and central components of  $F_n(v_v)$  remain small enough, and we are left to bound  $v^u = (F_n(v_y))^u$ . Since  $f^{j_x}(y) \in B(f^{j_x}(x), \rho)$ , similar contraction estimates hold for  $f^{-1}$ , and we get  $|v_v^u| \le C$  $e^{-(\chi^{u}(x)-2\tau)n(1+\gamma)}$ . Thus,  $|(F_{n}(v))^{u}| < e^{-(\chi^{u}(x)-2\tau)n(1+\gamma)}e^{(\chi^{u}(x)+2\tau)n} < e^{-\gamma n(\chi_{0}-4\tau)} < e^{-\frac{5}{4}\epsilon n}$  for  $\epsilon > 0$  small enough (w.r.t  $\chi_0$ ).

<span id="page-6-0"></span>**Theorem 3.4.** Let  $f \in \text{Diff}^{1+\beta}(M)$ , where M is a closed Riemannian manifold with dim $M = d \ge 2$ . Let  $\mu$  be an f-invariant Borel probability on M. Then

$$\mathcal{E}_{\mu}(\mathbf{x}) = \mathbf{h}_{\mu}^{\mathrm{BK}}(\mathbf{x})\mu$$
-a.e.

**Proof.** We start with a reduction. Let  $\mu = a^+\mu^+ + a^0\mu^0$  where  $\mu^+$  admits a positive Lyapunov exponent a.e, and  $\mu^0$  has all exponent less or equal to 0 a.e. Then  $\mathcal{E}_{\mu} \leq \mathcal{E}_{\mu^+}$ , and for  $\mu^0$ -a.e x,  $\mathcal{E}_{\mu}(x) = 0 = h_{\mu}^{\mathrm{BK}}(x)$  (by dimension bounds). Therefore, we may assume w.l.o.g that  $\mu$  admits a positive Lyapunov exponent a.e. Moreover, write  $\mu = \sum_{i>1} a_i \mu_i$  where for every  $i \ge 1$ ,  $\mu_i$ -a.e, all non-zero Lyapunov exponents are greater than  $\frac{1}{i}$  in absolute value. Thus, if for every  $i \ge 1$  we have  $h_{\mu_i}^{BK} \ge \mathcal{E}_{\mu_i} \mu_i$ -a.e, then by Lemma 3.1,

$$h_{\mu}^{\mathrm{BK}} = h_{\mu_{\mathrm{i}}}^{\mathrm{BK}} \geq \mathcal{E}_{\mu_{\mathrm{i}}} \geq \mathcal{E}_{\mu}, \mu_{\mathrm{i}}$$
-a.e, $\forall \mathrm{i} \geq 1 \Rightarrow h_{\mu}^{\mathrm{BK}} \geq \mathcal{E}_{\mu}, \mu$ -a.e.

Then it is enough to assume that the non-zero Lyapunov exponents of  $\mu$  are uniformly bounded from below in absolute value by a constant  $\chi_0 > 0$ .

It is enough to assume for contradiction that  $\exists \lambda \in (0, \min\{\chi_0^3, \frac{1}{2}\})$  s.t  $\mathcal{E}_{\mu} \geq h_{\mu}^{\text{BK}} + 2\lambda \ \mu$ -a.e, since if  $\mu = a_{\lambda}\mu_{\lambda} + (1 - a_{\lambda})\mu_{\lambda}^{-}$  where  $a_{\lambda} > 0$  and  $\mathcal{E}_{\mu} \ge h_{\mu}^{\rm BK} + 2\lambda \; \mu_{\lambda}$ -a.e, then once more by Lemma 3.1,

$$\mathcal{E}_{\mu_{\lambda}} \geq \mathcal{E}_{\mu} \geq h_{\mu}^{\mathrm{BK}} + 2\lambda = h_{\mu_{\lambda}}^{\mathrm{BK}} + 2\lambda, \mu_{\lambda}$$
-a.e.

Finally, we make the following reduction: let  $G_{(\mathcal{E},h)} := \{x : \mathcal{E}_{\mu}(x) = \mathcal{E} \pm \frac{\lambda}{2}, h_{\mu}^{BK}(x) = h \pm \frac{\lambda}{2}\}$ , then let  $\mu = a_{(\mathcal{E},h)}\mu' + (\mu - a_{(\mathcal{E},h)}\mu')$ , where  $a_{(\mathcal{E},h)} > 0$  and  $\mu'$  is carried by  $G_{(\mathcal{E},h)}$ . Then,  $\mu'$ -a.e

$$\mathcal{E}_{\mu'} \ge \mathcal{E}_{\mu} \ge h_{\mu}^{\text{BK}} + 2\lambda = h_{\mu'}^{\text{BK}} + 2\lambda. \tag{6}$$

Moreover, similarly, we may assume w.l.o.g that  $\mathcal{E}_{\mu}\gg\sqrt{\lambda}$  a.e. Therefore, we may assume for contradiction that  $\mathcal{E}_{\mu}$  and  $h_{\mu}^{\text{BK}}$  are "almost constant" w.r.t to the gap between them, which is uniformly bounded from below.

There exists  $0 < r \le \frac{\min\{1,\chi_0\}}{3d} \frac{\lambda^4}{4}$  s.t  $\mu(A_1) \ge 1 - \lambda^3$  where  $A_1 := \{x \in A : \limsup \frac{-1}{n} \log \mu(B(x,n,e^{-m})) > 1 - \lambda^3 \}$  $h_{\mu}^{\mathrm{BK}}(x) + \frac{7\lambda}{8}$ .

We can then choose  $0 < \tau \le \min\{\frac{\tau}{400}\}$  and  $\ell \in \mathbb{N}$  s.t  $\mu(A_2) \ge 1 - 2\lambda^4$  where

$$A_2 := \{x \in A_1 \text{ Lyapunov reg.} : x \in \Lambda_\ell^{(\underline{\chi}(x),\tau)}\}.$$

Let  $\mu = \int \mu_x d\mu(x)$  be the ergodic decomposition of  $\mu$ . Then by the Markov inequality,  $\mu(\{x:\mu_x(A_2)\geq 1-\sqrt{2\lambda^4}\})\geq 1-\sqrt{2\lambda^4}$ . Then  $\mu(\{x\in A_2:\mu_x(A_2)\geq 1-\sqrt{2\lambda^2}\})\geq 1-2\lambda^2$ . So by the ergodic theorem  $\exists n_0\in\mathbb{N}$  s.t  $\mu(A_3)\geq 1-3\lambda^2$  where

$$A_3 := \{ x \in A_2 : \forall n \ge n_0 \exists j \in [n(1 + 4\lambda^2), n(1 + 8\lambda^2)] \text{ s.tf}^j(x) \in A_2 \}.$$

Let  $K_r \subseteq A_3$  as in Corollary 3.3 s.t  $\mu(K_r) > 0$  (notice, the restrictions on  $K_r$  in Corollary 3.3 are given by Lemma 3.2 that in turn are merely Brin-Katok estimates, which are inherited by subsets). Let  $N \ge n_0$  large, then for all  $x \in K_r$  set

$$n_x^N := \min\{n \ge N : \frac{-1}{n} \log \mu(B(x, n, e^{-rn})) > h + \frac{6\lambda}{8}\}.$$

For all  $n \ge N$ , set  $K_n := \{x \in K_\tau : n_x^N = n\}$ .

By Corollary 3.3, we can cover  $K_n$  with a cover whose cardinality is less or equal to  $e^{n(1+8\lambda^2)(h+\frac{1}{8}+3dr)}$ , of exponential Bowen balls of the form  $B(x,n,e^{-nr})$ ,  $x\in K_n$ . Hence,  $\mu(K_n)\leq e^{n(1+8\lambda^2)(h+\frac{1}{8}+3dr)}\cdot e^{-n(h+\frac{6\lambda}{8})}$ , whence  $0<\mu(K_\tau)\leq \sum_{n>N}e^{-n\frac{1}{8}}\stackrel{N\to\infty}{\longrightarrow} 0$ , a contradiction! Hence,  $h^{\rm BK}_\mu\leq \mathcal{E}_\mu\leq h^{\rm BK}_\mu$   $\mu$ -a.e.

**Remark:** Theorem 3.4 implies that  $\mathcal{E}_{\mu}(x) = \lim_{r \to 0} \lim \inf_{n \to \infty} \frac{-1}{n} \log \mu(B(x, n, e^{-rn}))$  for  $\mu$ -a.e x since

$$h_{\mu}^{\mathrm{BK}}(\mathbf{x}) = \lim_{r \to 0} \liminf_{n \to \infty} \frac{-1}{n} \log \mu(\mathbf{B}(\mathbf{x}, n, r)) \leq \lim_{r \to 0} \liminf_{n \to \infty} \frac{-1}{n} \log \mu(\mathbf{B}(\mathbf{x}, n, e^{-rn})) \leq \mathcal{E}_{\mu}(\mathbf{x}) = h_{\mu}^{\mathrm{BK}}(\mathbf{x}).$$

#### <span id="page-7-0"></span>4 Lower-Dimension Bounds for Invariant Measures

In [6], the authors consider an ergodic f-invariant measure  $\mu$ , where f is a  $C^2$  diffeomorphism of a closed Riemannian manifold M. The authors consider two important partitions- $\xi^u$  and  $\xi^s$  sub-ordinated to the unstable and to the stable laminations, respectively, and consider the conditional measures of  $\mu$  w.r.t to these partitions. The authors then go on and prove that the conditional measures  $\mu_{\xi^u(\cdot)}$  and  $\mu_{\xi^s(\cdot)}$  are exact-dimensional for almost every point, with the dimensions being constant and denoted by  $d^u$  and  $d^s$ , respectively. Moreover, the authors prove that the point-wise upper-dimension of  $\mu$ -a.e point is bounded by

$$\overline{d} < d^u + d^s + d^c$$
.

where  $d^c = d^c(\mu) := \#\{0 \text{ Lyapunov exponent of } \mu\}$ .

In [1], the authors extend the results of [6] by relaxing the regularity assumption of f to  $C^{1+\beta}$  ( $\beta > 0$ ) by proving the Lipschitz property of intermediate foliations; and bound from below the point-wise dimension of ergodic invariant measures under the additional assumption of hyperbolicity:

$$d^{u} + d^{s} < d < \overline{d}$$
.

In particular, it follows as a consequence that a hyperbolic measure is exact-dimensional, since  $d^c = 0$ .

The purpose of this section, is to extend these results, as an application of Theorem 3.4. We give lower bounds to the point-wise dimension of invariant measures, which coincide with the lower bounds from [1] when the measure is hyperbolic. In general, invariant measures with 0 Lyapunov exponents need not be exact-dimensional, and the bounds from [6] are tight. In particular, our proof is aimed to be short and accessible by using the neutralized local entropy instead of adapted partitions.

Given an ergodic f-invariant measure, let  $d^s$  and  $d^u$  be the point-wise dimension of the conditional measures  $\{\mu_{\xi^s(\cdot)}\}$  and  $\{\mu_{\xi^u(\cdot)}\}$ , respectively, which are introduced in [6].

<span id="page-8-0"></span>**Theorem 4.1.** Let  $\mu$  be an f-invariant ergodic measure, where  $f \in \text{Diff}^{1+\beta}(M)$  ( $\beta > 0$  and M a closed Riemannian manifold). Then for  $\mu$ -a.e x,

$$d^{s} + d^{u} \leq \underline{d}(x) := \liminf_{r \to 0} \frac{\log \mu(B(x, r))}{\log r}.$$

**Proof.** We start with two simple reductions. Given r > 0, and  $\chi > 0$ , let  $r' := \max\{e^{-n\chi} : e^{-n\chi} \le r, n \in \mathbb{N}\}$ . Then,

<span id="page-8-2"></span>
$$\begin{split} \frac{\log \mu(B(\mathbf{x},r))}{\log r} &= \frac{\log r'}{\log r} \cdot \frac{\log \mu(B(\mathbf{x},r))}{\log \mu(B(\mathbf{x},r'))} \cdot \frac{\log \mu(B(\mathbf{x},r'))}{\log r'} \\ &\geq & (1 - \frac{\chi}{\log r}) \cdot \frac{\log \mu(B(\mathbf{x},r'))}{\log r'}. \end{split}$$

Then it is enough to prove  $\liminf_{n\to\infty}\frac{\log\mu(B(x,e^{-n\chi}))}{-n\chi}\geq d^u+d^s$ , for some  $\chi>0$ . The second assumption we make is that  $\mu$  admits both positive and negative Lyapunov exponents, since otherwise  $d^s=d^u=0$ , and the statement is trivial. Set  $\chi := \frac{1}{2} \min\{|\chi_i(\mu)| : \chi_i(\mu) \neq 0\} > 0$ . (If there are either no positive or no negative Lyapunov exponents, then by the Ruelle inequality  $h_{\mu}(f) = 0$ . Therefore, by [5, 6] ([1,Appendix] guarantees that our  $C^{1+\beta}$  setup is sufficient),  $h_s(\mu) = h_u(\mu) = 0$  and  $d^u = d^s = 0$ .)

We now can start with the construction for the proof. Assume that  $\mu$  admits positive exponents, and so we prove  $d \ge d^u$ . The case of the negative exponents is treated subsequently, and we improve the

Let  $\delta \in (0, \chi)$ , and let  $\epsilon \in (0, \frac{\delta^2}{8})$  and  $n_{\delta} \in \mathbb{N}$  s.t  $e^{-\chi n_{\delta}} \ll \frac{1}{\ell^3}$  and  $\mu(A_{\delta}) \geq 1 - \delta$  where

$$\begin{split} A_{\delta} &:= \{x \in \Lambda_{\ell_{\delta}}^{(\underline{\chi},\tau)} : \forall n \geq n_{\delta}, \mu_{\xi^{u}(x)}(B^{u}(x,e^{-\chi n})) \leq e^{-\chi d^{u}n + n\delta}, \\ \mu(B(x,-n,e^{-\epsilon n})) &= e^{-n\varepsilon_{\mu} \pm \delta n}, \mu(B(x,n,e^{-\epsilon n})) = e^{-n\varepsilon_{\mu} \pm \delta n}, \\ \mu(B(x,-n,n,2e^{-\epsilon n})) &= e^{-2\varepsilon_{\mu}n \pm \delta n}\}, \end{split}$$

where  $\chi = \chi(\mu)$  and  $\tau \in (0, \frac{\epsilon}{1004})$ , and  $B(\cdot, -n, e^{-\epsilon n})$  denotes an exponential Bowen balls for  $f^{-1}$ , while  $B(\cdot, -n, n, 2e^{-\epsilon n})$  denotes a two-sided exponential Bowen ball.

By Lemma 2.3, there exists  $A'_{\delta} \subseteq A_{\delta}$  and  $m_{\delta} \ge n_{\delta}$  s.t  $\mu(A'_{\delta}) \ge 1 - 2\delta$  where

<span id="page-8-1"></span>
$$A'_{\delta} := \{x \in A_{\delta} : \forall n \ge m_{\delta}, \frac{1}{n} \log \frac{\mu(B(x, n, e^{-\epsilon n}))}{\mu(B(x, n, e^{-\epsilon n}) \cap A_{\delta})} \le 48d\epsilon \}. \tag{7}$$

(While formally Lemma 2.3 is only stated for the limit  $\lim_{r\to 0} \limsup_{n\to\infty} \frac{-1}{n} \log \frac{\mu(B(x,n,e^{-nr})\cap A)}{\mu(B(x,n,e^{-nr}))} = 0$ , the quantitative argument extends as is to the quantitative estimate of (7) whenever  $\epsilon > 0$  is small w.r.t  $\chi$ .) Let  $x \in A_{\delta}'$ , which is a Lebesgue density point s.t  $\mu(B(x, e^{-nx}) \cap A_{\delta}') \ge e^{-\delta}\mu(B(x, e^{-nx}))$  for all  $n \ge n_x \ge m_{\delta}$ , and let  $n \ge n_x$ .

Then cover  $A'_s \cap B(x, e^{-x^n})$  as in Lemma 2.2, by a cover  $C^u$  of balls  $B(\cdot, n, e^{-\epsilon n})$  with multiplicity bounded

**Claim:** For  $\mu$ -a.e  $x \in A'_{\delta}$ , for all n large enough,  $\mu(\bigcup C^u \cap A_{\delta}) \leq e^{-\chi d^u n + 2\sqrt{\delta}n}$ .

**Proof:** For  $x \in A'_{\delta}$ , define

$$S_n(x) := \bigcup_{y \in A'_\delta \cap B(x, e^{-\chi n})} B(y, n, e^{-\epsilon n}) \cap A_\delta.$$

Assume that  $\mu(\{x \in A_s' : \limsup \frac{1}{n} \log \mu(S_n(x)) \le \chi d^n - 2\sqrt{\delta}\}) > 0$ . Then set  $A_n := \{\{x \in A_s' : \limsup \frac{1}{n} \log \mu(S_n(x)) \le \chi d^n - 2\sqrt{\delta}\}\}$  $\frac{-1}{n}\log\mu(S_n(x)) \leq \chi d^u - \sqrt{\delta}$ , and so by the Borel-Cantelli lemma there are infinitely many  $n \in \mathbb{N}$  s.t  $\mu(A_n) \ge e^{-\epsilon}$ . Then there exists  $x \in A'_{\delta}$  s.t  $\mu_{\xi^u(x)}(A_n) \ge e^{-\epsilon n}$ .

Cover  $\xi^{\mu}(x) \cap A_n$  by  $B(\cdot, e^{-x^n}e^{2\epsilon n})$  in a Besicovitch manner, which means we can find a mutually disjoint sub-collection of measure at least  $\frac{1}{C_x}e^{-\epsilon n}$ ,  $\mathcal{F}$ . Let  $B(y, e^{-\chi n + 2\epsilon n})$ ,  $B(y', e^{-\chi n + 2\epsilon n}) \in \mathcal{F}$ , and let  $z \in B(y, e^{-\chi n}) \cap A_x'$  $\text{and }z' \in \mathbb{B}(y', e^{-\chi n}) \cap A_{\delta}' \text{. Let } w \in \mathbb{B}(z, n, e^{-\epsilon n}) \cap \xi^{u}(x) \cap \mathbb{B}(y, e^{-\chi n + \frac{\epsilon}{2}n}) \text{ and } w' \in \mathbb{B}(z', n, e^{-\epsilon n}) \cap \xi^{u}(x) \cap \mathbb{B}(y', e^{-\chi n + \frac{\epsilon}{2}n}).$ 

If  $B(z, n, e^{-\epsilon n}) \cap B(z', n, e^{-\epsilon n}) \neq \emptyset$ , then  $w \in B(w', n, 4e^{-\epsilon n})$ , which is impossible since both w and w' lie on  $\xi^u(x)$  with distance at least  $2 \cdot (e^{-\chi n + 2\epsilon n} - e^{-\chi n + \frac{\epsilon}{2}n}) > e^{-\chi n}$  between them.

Then,  $\forall B, B' \in \mathcal{F}$ , centered at y and y' respectively,  $S_n(y) \cap S_n(y') = \emptyset$ . However,  $\#\mathcal{F} \ge \frac{e^{-\epsilon n}}{a - nd^{10}(y + 3\epsilon) + 3n}$  (since  $B(y, e^{-n(\chi - 2\epsilon)}) \cap \xi^{u}(y) \subseteq B_{\xi^{u}(y)}(y, e^{-n(\chi - 3\epsilon)})$ . Thus,

$$1 \geq \#\mathcal{F} \cdot e^{-\chi d^{u} + n\sqrt{\delta}} \geq \frac{e^{-\epsilon n}}{e^{-nd^{u}(\chi + 3\epsilon) + \delta n}} \cdot e^{-\chi d^{u} + n\sqrt{\delta}} \geq e^{\frac{1}{2}\sqrt{\delta}n},$$

a contradiction!  $\square$ 

It follows that for  $\mu$ -a.e  $x \in K'_{\delta}$ , for all n large enough,

$$e^{-n\chi d^u+\sqrt{\delta}n} \geq \mu(\bigcup C^u \cap A_\delta) \geq e^{-3d\tau n} \cdot \sharp C^u \cdot \min_{B \in C^u} \mu(B \cap A_\delta) \geq e^{-3d\tau n} \cdot \sharp C^u \cdot e^{-n\mathcal{E}_\mu - \delta n} \cdot e^{-48d\epsilon n}.$$

Thus,

$$\#C^{u} \le e^{n(\mathcal{E}_{\mu} - d^{u}\chi + 6\sqrt{\delta})}.$$
(8)

This concludes the bound

$$\mu(B(x, e^{-\chi n})) < e^{\delta} \cdot \mu(B(x, e^{-\chi n}) \cap A') < e^{\delta} \cdot \#C^{u} \cdot e^{-n(\mathcal{E}_{\mu} + \delta)} < e^{\delta} \cdot e^{n(\mathcal{E}_{\mu} - d^{u}\chi + 6\sqrt{\delta})} \cdot e^{-n(\mathcal{E}_{\mu} + \delta)}.$$

Hence,  $d > d^u - 7\sqrt{\delta}$  where  $\delta > 0$  is arbitrary.

For the case of the negative exponents, construct similarly a cover  $C^s$  of  $A_{\lambda}^c \cap B(x, e^{-\chi n})$  by exponential Bowen balls for  $f^{-1}$ , denoted by  $B(\cdot, -n, e^{-\epsilon n})$ . Then similarly one gets that  $\#\mathbb{C}^s \leq e^{n(\mathcal{E}_n - d^s\chi + 6\sqrt{\delta})}$ . We then define the cover  $C := \{B^s \cap B^u : B^s \in C^s, B^u \in C^u, \text{ and } B^s \cap B^u \cap A_s' \neq \emptyset\}$ . It follows immediately that

<span id="page-9-1"></span>
$$\#C \le \#C^u \cdot \#C^s \le e^{n(2\mathcal{E}_\mu - d^s\chi - d^u\chi + 12\sqrt{\delta})}.$$
(9)

Moreover, for every element  $B \in C$ ,  $B \subseteq B(x_B, -n, n, 2e^{-\epsilon n})$  where  $x_B \in A'_{\delta}$  by the triangle inequality. Therefore,

$$\mu(B(x, e^{-\chi n})) \le e^{\delta} \cdot \#C \cdot e^{-n(2\mathcal{E}_{\mu} - \delta)} \le e^{\delta} \cdot e^{-n(d^s + d^u)\chi + 13\sqrt{\delta}n}. \tag{10}$$

Since  $\delta > 0$  was arbitrary, we are done.

Remark: Note that the estimate from above of the measure of a ball in Theorem 4.1 is quite coarse: All elements of  $C^u$  and of  $C^s$  are of size  $e^{-\epsilon n}$  in the central direction, which is much longer than the diameter of the ball  $e^{-\chi n}$ . While this over-shooting may seem wasteful, one may may not expect an invariant measure to be concentrated in the central-direction, and in fact generally an invariant measure may even be atomic in the central direction, thus the estimate is tight for the general case. In some cases where we have more information regarding the central direction, we may say a bit more, as we show below in Corollary 4.2.

<span id="page-9-0"></span>**Corollary 4.2.** Under the assumptions of Theorem 4.1, if  $\mu$  admits a measurable lamination by central leaves almost everywhere, then a.e.

$$\liminf_{r\to 0} \frac{\log \mu(B(x,r))}{\log r} := \underline{d}(\mu) = \underline{d} \ge d^{s} + d^{u} + \underline{d}^{c},$$

where  $d^{c}$  is the lower point-wise dimension of the conditional measures on the lamination by central leaves.

**Proof.** Let  $\xi^c$  be the measurable partition of  $\mu$  into central leaves. Notice that  $d^c$  and d are invariant functions, and are constant a.e.

Let  $\delta > 0$ . We consider the set  $A_{\delta}^{"}$ , which is the set of density points of  $A_{\delta}^{'}$  that also satisfy dimension bounds, where  $A'_{\delta}$  is as in the proof of Theorem 4.1. That is, for all  $x \in A''_{\delta}$ , and all  $n \ge n'_{\delta} \ge n_{\delta}$ ,

$$\mu_{\xi^{c}(x)}(B(x, e^{-\chi n + n\epsilon}) \cap A'_{\delta}) \le e^{-\underline{d}^{c}\chi n + \delta n},$$

$$\mu_{\xi^{c}(x)}(B(x, e^{-2\epsilon n})) \ge e^{-3d\epsilon n}.$$
(11)

Furthermore, by the Borel-Cantelli lemma, there are infinitely many  $n \in \mathbb{N}$  s.t  $\mu(A_n) \ge e^{-\epsilon n}$ , where

<span id="page-10-0"></span>
$$A_n := \{ x \in A_{\delta}'' : \mu(B(x, e^{-\chi n - \epsilon n})) \ge e^{-\chi \underline{d}n - \delta n} \}.$$

If for all  $x \in A_n$ ,  $\frac{\mu(A_n \cap B(x, e^{-\chi n - n\epsilon}))}{\mu(B(x, e^{-\chi n - \epsilon n}))} \le e^{-d\epsilon n}$ , then let  $\mathcal F$  be a Besicovitch cover of  $A_n$  by balls  $B(\cdot, e^{-\chi n - \epsilon n})$ . It follows that,

$$e^{-\epsilon n} \leq \sum_{B \in \mathcal{F}} \mu(B \cap A_n) = \sum_{B \in \mathcal{F}} \frac{\mu(B \cap A_n)}{\mu(B)} \mu(B) \leq e^{-d\epsilon n} \sum_{B \in \mathcal{F}} \mu(B) \leq e^{-d\epsilon n} \cdot C_d,$$

 $\Rightarrow$  a contradiction! Thus, by the definition of  $A_n$ , there exists  $x \in A_n$  with

<span id="page-10-1"></span>
$$\mu(A_n \cap B(x, e^{-\chi n - \epsilon n})) \ge e^{-d\epsilon n} \cdot \mu(B(x, e^{-\chi n - \epsilon n})) \ge e^{-d\epsilon n - n\underline{d}\chi n - \delta n}. \tag{12}$$

Let  $T_n(x) := B(x, e^{-xn+\epsilon n}) \cap B(x, -n, n, 2e^{-\epsilon n})$ , then by (12) and by the bounds from Theorem 4.1, (9),

$$\begin{split} e^{-d\epsilon n - n\underline{d}\chi n - \delta n} &\leq \mu(B(x, e^{-\chi n - \epsilon n}) \cap A_n) \leq \mu(\bigcup C \cap B(x, e^{-\chi n - \epsilon n}) \cap A_n) \\ &\leq \#C \cdot \max_{B \in C: B \cap A_n \neq \varnothing} \mu(B \cap A_n \cap B(x, e^{-\chi n - \epsilon n})) \leq \#C \cdot \max_{B \in C: B \cap A_n \neq \varnothing} \mu(T_n(y_B) \cap A_n) \\ &\leq e^{-n\chi(d^u + d^s) + 12\sqrt{\delta}n + 2n\mathcal{E}_{\mu}} \cdot \max_{B \in C: B \cap A_n \neq \varnothing} \mu(T_n(y_B) \cap A_n), \end{split}$$

$$(13)$$

where  $y_B$  is a point in  $B \cap A_n$ .

We wish to bound the second term on the r.h.s of (13). We use the fact that  $B(\cdot, -n, n, 2e^{-\epsilon n})$  is saturated by central leaves, and get that for all  $B \in C$ ,

<span id="page-10-2"></span>
$$\mu(T_{n}(y_{B}) \cap A_{n}) \leq \mu(\xi^{c}[T_{n}(y_{B}) \cap A_{n}]) = \int_{\xi^{c}[T_{n}(y_{B}) \cap A_{n}]} \mu_{\xi^{c}(z)}(T_{n}(y_{B})) d\mu(z)$$

$$= \int_{\xi^{c}[T_{n}(y_{B}) \cap A_{n}]} \frac{\mu_{\xi^{c}(z)}(T_{n}(y_{B}))}{\mu_{\xi^{c}(z)}(B(y_{B}, e^{-2\epsilon n}))} \mu_{\xi^{c}(y)}(B(y_{B}, e^{-2\epsilon n})) d\mu(z)$$

$$(\because (11)) \leq e^{-x} \underline{d}^{c} n + \delta n + 3d\epsilon n} \int_{\xi^{c}[T_{n}(y_{B}) \cap A_{n}]} \mu_{\xi^{c}(z)}(B(y_{B}, e^{-2\epsilon n})) d\mu(y)$$

$$\leq e^{-x} \underline{d}^{c} n + \delta n + 3d\epsilon n} \mu(B(y_{B}, -n, n, 2e^{-\epsilon n})) \leq e^{-x} \underline{d}^{c} n + \delta n + 3d\epsilon n} e^{-2n\epsilon \varepsilon_{\mu} + \delta n}. \tag{14}$$

Plugging (14) back into (13), we get

$$e^{-d\epsilon n - n}\underline{d}\chi^{n - \delta n} \leq e^{-n\chi(d^u + d^s) + 12\sqrt{\delta}n + 2n\mathcal{E}_\mu} \cdot e^{-\chi}\underline{d}^c^{n + 2\delta n + 3d\epsilon n - 2\mathcal{E}_\mu n}.$$

-

Therefore,

$$\underline{d} \ge d^{\mathrm{s}} + d^{\mathrm{u}} + \underline{d}^{\mathrm{c}} - 19d\sqrt{\delta},$$

which concludes the proof since *δ >* 0 is arbitrary. -

#### **Remarks:**

- 1) Let *d* and *d c* be the upper point-wise dimension of *μ* and of *μξ <sup>c</sup> (*·*)*, resp. One can show similarly to Corollary [4.2](#page-9-0) that *d* ≥ *ds* + *du* + *d c* , by adapting the definitions of the sets *A <sup>δ</sup>* and *An*, while the structure of the proof remains the same.
- 2) In both Theorem [4.1](#page-8-0) and Corollary [4.2,](#page-9-0) the non-ergodic case is treated similarly to the ergodic case, where *A<sup>δ</sup>* restricts further to a subset where the values of *d*, *d*, *dc* , and *d* are almost constant.

**Corollary 4.3.** Assume that *μ* admits a measurable lamination by central leaves *W<sup>c</sup> (*·*)* almost everywhere. Let *ξ <sup>c</sup>* be a measurable partition subordinated to the central lamination, and let *λWc (*·*)* be the induced Riemannian volume on *W<sup>c</sup> (*·*)*. If the conditional measures of *μ* satisfy *μξ <sup>c</sup> (*·*) λWc (*·*)* a.e, then *μ* is exact and *μ*-a.e,

$$d = d^{s} + d^{u} + \dim E^{c},$$

where dim*E<sup>c</sup>* is the dimension of the central Oseledec subspace.

*Proof.* By Corollary [4.2](#page-9-0) and by [[6](#page-11-6), Theorem F], *μ*-a.e,

$$\overline{d} \ge \underline{d} \ge d^{s} + d^{u} + \dim E^{c} \ge \overline{d}.$$

## **References**

- <span id="page-11-5"></span>[1.](#page-1-0) Barreira, L., Y. Pesin, and J. Schmeling. "Dimension and product structure of hyperbolic measures." *Ann. of Math. (2)* **149**, no. 3 (1999): 755–83.
- <span id="page-11-0"></span>[2.](#page-0-0) Brin, M. and A. Katok. On local entropy. In *Geometric Dynamics (Rio de Janeiro, 1981)*, volume **1007** of Lecture Notes in Math., pp. 30–38. Berlin: Springer, 1983, [https://doi.org/10.1007/BFb0061408.](https://doi.org/10.1007/BFb0061408)
- <span id="page-11-8"></span>[3.](#page-2-1) DiBenedetto, E. *Real Analysis.* Birkhäuser Advanced Texts: Basler Lehrbücher. [Birkhäuser Advanced Texts: Basel Textbooks]. Birkhäuser Boston, Inc., 2002.
- <span id="page-11-7"></span>[4.](#page-2-2) Katok, A. and Mendoza, L. *Dynamical Systems with Non-uniformly Hyperbolic Behavior, Supplement to "Introduction to the Modern Theory of Dynamical Systems"*, volume 54 of Encyclopedia of Mathematics and its Applications. Cambridge: Cambridge University Press, 1995, [https://doi.org/10.1017/](https://doi.org/10.1017/CBO9780511809187) [CBO9780511809187](https://doi.org/10.1017/CBO9780511809187).
- <span id="page-11-9"></span>[5.](#page-8-2) Ledrappier, F., and L.-S. Young. "The metric entropy of diffeomorphisms. I. Characterization of measures satisfying Pesin's entropy formula." *Ann. of Math. (2)* **122**, no. 3 (1985): 509–39.
- <span id="page-11-6"></span>[6.](#page-1-1) Ledrappier, F., and L.-S. Young. "The metric entropy of diffeomorphisms. II. Relations between entropy, exponents and dimension." *Ann. of Mathematics. Second Series* **122**, no. 3 (1985): 540–74.
- <span id="page-11-1"></span>[7.](#page-0-1) Ruelle, D. "An inequality for the entropy of differentiable maps." *Bol. Soc. Brasil. Mat.* **9**, no. 1 (1978): 83–7. [https://doi.org/10.1007/BF02584795.](https://doi.org/10.1007/BF02584795)
- <span id="page-11-3"></span>[8.](#page-1-2) Takens, F., and E. Verbitskiy. "Rényi entropies of aperiodic dynamical systems." *Israel J. Math.* **127** (2002): 279–302. [https://doi.org/10.1007/BF02784535.](https://doi.org/10.1007/BF02784535)
- <span id="page-11-4"></span>[9.](#page-1-3) Takens, F., and E. Verbitskiy. "On the variational principle for the topological entropy of certain non-compact sets." *Ergodic Theory Dynam. Syst.* **23**, no. 1 (2003): 317–48. [https://doi.org/10.1017/](https://doi.org/10.1017/S0143385702000913) [S0143385702000913](https://doi.org/10.1017/S0143385702000913).
- <span id="page-11-2"></span>[10.](#page-1-4) Thieullen, P. Généralisation du théorème de Pesin pour l'*α*-entropie. In *Lyapunov exponents (Oberwolfach, 1990)*, volume 1486 of *Lecture Notes in Math*., pp. 232–242. Berlin: Springer, 1991, [https://doi.org/10.1007/](https://doi.org/10.1007/BFb0086673) [BFb0086673.](https://doi.org/10.1007/BFb0086673)

- <span id="page-12-0"></span>[11.](#page-1-5) Thieullen, P. "Entropy and the Hausdorff dimension for infinite-dimensional dynamical systems." *J. Dynam. Differential Equations* **4**, no. 1 (1992): 127–59. <https://doi.org/10.1007/BF01048158>.
- <span id="page-12-1"></span>[12.](#page-1-6) Thieullen, P. "Fibres dynamiques. Entropie et dimension." *Ann. Inst. H. Poincaré C Anal. Non Linéaire* **9**, no. 2 (1992): 119–46. [https://doi.org/10.1016/s0294-1449\(16\)30242-6.](https://doi.org/10.1016/s0294-1449(16)30242-6)