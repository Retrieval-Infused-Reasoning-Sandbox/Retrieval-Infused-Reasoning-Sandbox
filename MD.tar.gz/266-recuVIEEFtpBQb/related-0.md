#### Skip to main content

#### Advertisement

**Springer Nature Link** 

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- 1. <u>Home</u> >
- 2. Geometric Dynamics >
- 3. Conference paper

# On local entropy

- Conference paper
- First Online: 01 January 2006
- pp 30-38
- Cite this conference paper

![](_page_0_Figure_16.jpeg)

- <span id="page-0-0"></span>• <u>M. Brin<sup>1</sup>,2</u> &
- <u>A. Katok<sup>1</sup>,2</u>

Part of the book series: [Lecture Notes in Mathematics](https://link.springer.com/series/304) ((LNM,volume 1007))

- 2779 Accesses •
- 240 Citations •

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2FBFb0061408) to check access.

# **Access this chapter**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2FBFb0061408)

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

### **Preview**

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/BFb0061408)

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/BFb0061408)

### **References**

A. Katok, Lyapunov exponents, entropy and periodic orbits for diffeomorphisms, Publ.Math.I.H.E.S., v.51(1980), 137–173. 1.

[Article](https://link.springer.com/doi/10.1007/BF02684777) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=573822) [MATH](http://www.emis.de/MATH-item?0445.58015) [Google Scholar](https://scholar.google.com/scholar_lookup?&title=Lyapunov%20exponents%2C%20entropy%20and%20periodic%20orbits%20for%20diffeomorphisms&journal=Publ.Math.I.H.E.S.&volume=51&pages=137-173&publication_year=1980&author=Katok%2CA.)

P. Billingsley, Ergodic Theory and Information, New York, John Wiley, 1965. 2.

[MATH](http://www.emis.de/MATH-item?0141.16702) [Google Scholar](https://scholar.google.com/scholar_lookup?&title=Ergodic%20Theory%20and%20Information&publication_year=1965&author=Billingsley%2CP.)

A.Katok, Hyperbolicity in smooth dynamical systems, Ecole d'eté de Physique Theorique, Les Houches, 1981, Proc., to appear. 3.

[Google Scholar](https://scholar.google.com/scholar?&q=A.Katok%2C%20Hyperbolicity%20in%20smooth%20dynamical%20systems%2C%20Ecole%20d%27et%C3%A9%20de%20Physique%20Theorique%2C%20Les%20Houches%2C%201981%2C%20Proc.%2C%20to%20appear.)

[Download references](https://citation-needed.springer.com/v2/references/10.1007/BFb0061408?format=refman&flavour=references)

# **Author information**

#### **Authors and Affiliations**

- <span id="page-2-1"></span>Department of Mathematics, University of Maryland, 20742, College Park, MD, USA 1.
  - M. Brin & A. Katok
- <span id="page-2-2"></span>Instituto de Matemática Pura e Aplicada, Estrada Dona Castorina, 110, 22460, Rio de Janeiro, RJ, Brasil 2.
  - M. Brin & A. Katok

#### Authors

<span id="page-2-0"></span>M. Brin 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=M.%20Brin)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=M.%20Brin) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22M.%20Brin%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-2-3"></span>A. Katok 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=A.%20Katok)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=A.%20Katok) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22A.%20Katok%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Editor information**

J. Palis Jr.

### **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?publisherName=SpringerNature&orderBeanReset=true&orderSource=SpringerLink&title=On%20local%20entropy&author=M.%20Brin%2C%20A.%20Katok&contentID=10.1007%2FBFb0061408©right=Springer-Verlag&publication=eBook&publicationDate=1983&startPage=30&endPage=38&imprint=Springer-Verlag)

# **Copyright information**

© 1983 Springer-Verlag

### **About this paper**

### <span id="page-3-0"></span>**Cite this paper**

Brin, M., Katok, A. (1983). On local entropy. In: Palis, J. (eds) Geometric Dynamics. Lecture Notes in Mathematics, vol 1007. Springer, Berlin, Heidelberg. https://doi.org/ 10.1007/BFb0061408

### **Download citation**

- [.RIS](https://citation-needed.springer.com/v2/references/10.1007/BFb0061408?format=refman&flavour=citation) •
- [.ENW](https://citation-needed.springer.com/v2/references/10.1007/BFb0061408?format=endnote&flavour=citation) •
- [.BIB](https://citation-needed.springer.com/v2/references/10.1007/BFb0061408?format=bibtex&flavour=citation) •
- DOI: https://doi.org/10.1007/BFb0061408 •
- Published: 24 August 2006 •
- Publisher Name: Springer, Berlin, Heidelberg •
- Print ISBN: 978-3-540-12336-1 •
- Online ISBN: 978-3-540-40969-4 •
- eBook Packages: [Springer Book Archive](https://metadata.springernature.com/metadata/books) •

### **Keywords**

- [Lyapunov Exponent](file:///search?query=Lyapunov%20Exponent&facet-discipline=%22Mathematics%22) •
- [Local Entropy](file:///search?query=Local%20Entropy&facet-discipline=%22Mathematics%22) •
- [Conditional Measure](file:///search?query=Conditional%20Measure&facet-discipline=%22Mathematics%22) •
- [Finite Cover](file:///search?query=Finite%20Cover&facet-discipline=%22Mathematics%22) •
- [Measurable Partition](file:///search?query=Measurable%20Partition&facet-discipline=%22Mathematics%22) •

*These keywords were added by machine and not by the authors. This process is experimental and the keywords may be updated as the learning algorithm improves.*

# **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

### **Access this chapter**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2FBFb0061408)

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

### <span id="page-4-1"></span>**Search**

| Search by keyword or author |  |
|-----------------------------|--|
|                             |  |
|                             |  |

Search

# <span id="page-4-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature