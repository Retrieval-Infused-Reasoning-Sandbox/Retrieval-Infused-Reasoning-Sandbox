### Skip to main content [Accessibility help](file:///core/accessibility)

# **Login Alert**

| Cancel<br>Log in<br>×<br>×<br>Discover Content |        |
|------------------------------------------------|--------|
| Products and Services                          |        |
| Register<br>Log In<br>(0) Cart                 |        |
|                                                | Search |
|                                                |        |
| •<br>Browse                                    |        |
| •<br>Services                                  |        |
| •<br>Open research                             |        |
| Institution Login                              |        |
|                                                | Search |
|                                                |        |

#### Menu links

- Browse 1.
  - Subjects 1.
    - Subjects (A-D) 1.
      - [Anthropology](file:///core/browse-subjects/anthropology) 1.
      - [Archaeology](file:///core/browse-subjects/archaeology) 2.
      - [Area Studies](file:///core/browse-subjects/area-studies) 3.
      - [Art](file:///core/browse-subjects/art) 4.

- [Chemistry](file:///core/browse-subjects/chemistry) 5.
- [Classical Studies](file:///core/browse-subjects/classical-studies) 6.
- [Computer Science](file:///core/browse-subjects/computer-science) 7.
- [Drama, Theatre, Performance Studies](file:///core/browse-subjects/drama-and-theatre) 8.
- Subjects (E-K) 9.
  - [Earth and Environmental Science](file:///core/browse-subjects/earth-and-environmental-sciences) 1.
  - [Economics](file:///core/browse-subjects/economics) 2.
  - [Education](file:///core/browse-subjects/education) 3.
  - [Engineering](file:///core/browse-subjects/engineering) 4.
  - [English Language Teaching Resources for Teachers](file:///core/browse-subjects/english-language-teaching-resources-for-teachers) 5.
  - [Film, Media, Mass Communication](file:///core/browse-subjects/film-media-mass-ommunication) 6.
  - [General Science](file:///core/browse-subjects/general-science) 7.
  - [Geography](file:///core/browse-subjects/geography) 8.
  - [History](file:///core/browse-subjects/history) 9.
- Subjects (L-O) 10.
  - [Language and Linguistics](file:///core/browse-subjects/language-and-linguistics) 1.
  - [Law](file:///core/browse-subjects/law) 2.
  - [Life Sciences](file:///core/browse-subjects/life-sciences) 3.
  - [Literature](file:///core/browse-subjects/literature) 4.
  - [Management](file:///core/browse-subjects/management) 5.
  - [Materials Science](file:///core/browse-subjects/materials-science) 6.
  - [Mathematics](file:///core/browse-subjects/mathematics) 7.
  - [Medicine](file:///core/browse-subjects/medicine) 8.
  - [Music](file:///core/browse-subjects/music) 9.
  - [Nutrition](file:///core/browse-subjects/nutrition) 10.
- Subjects (P-Z) 11.
  - [Philosophy](file:///core/browse-subjects/philosophy) 1.
  - [Physics and Astronomy](file:///core/browse-subjects/physics) 2.
  - [Politics and International Relations](file:///core/browse-subjects/politics-and-international-relations) 3.
  - [Psychiatry](file:///core/browse-subjects/psychiatry) 4.
  - [Psychology](file:///core/browse-subjects/psychology) 5.
  - [Religion](file:///core/browse-subjects/religion) 6.
  - [Social Science Research Methods](file:///core/browse-subjects/social-science-research-methods) 7.
  - [Sociology](file:///core/browse-subjects/sociology) 8.
  - [Statistics and Probability](file:///core/browse-subjects/statistics-and-probability) 9.
- Open access 2.
  - All open access publishing 1.
    - [Open access](file:///core/publications/open-access) 1.
    - [Open access journals](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 2.
    - [Research open journals](file:///core/publications/open-access/research-open?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 3.
    - [Journals containing open access](file:///core/publications/open-access/hybrid-open-access-journals?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 4.
    - [Open access articles](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL_ARTICLE) 5.
    - [Open access books](file:///core/publications/open-access/listing?aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 6.
    - [Open access Elements](file:///core/publications/elements/published-elements?aggs%5BopenAccess%5D%5Bfilters%5D=7275BA1E84CA769210167A6A66523B47&aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 7.
- Journals 2.
  - Explore 1.
    - [All journal subjects](file:///core/publications/journals) 1.
    - [Search journals](file:///core/publications/journals) 2.
  - Open access 3.
    - [Open access journals](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 1.
    - [Research open journals](file:///core/publications/open-access/research-open?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 2.
    - [Journals containing open access](file:///core/publications/open-access/hybrid-open-access-journals?aggs[productTypes][filters]=JOURNAL&statuses=PUBLISHED&sort=titleSort:asc) 3.

- [Open access articles](file:///core/publications/open-access/listing?aggs[productTypes][filters]=JOURNAL_ARTICLE) 4.
- Collections 5.
  - [Cambridge Forum](file:///core/publications/collections/cambridge-forum) 1.
  - [Cambridge Law Reports Collection](file:///core/publications/collections/cambridge-law-reports-collection) 2.
  - [Cambridge Prisms](file:///core/publications/collections/cambridge-prisms) 3.
  - [Research Directions](file:///core/publications/collections/research-directions) 4.
- Books 2.
  - Explore 1.
    - [Books](file:///core/publications/books) 1.
    - [Open access books](file:///core/publications/open-access/listing?aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 2.
    - [New books](file:///core/publications/books/listing?aggs[productDate][filters]=Last+3+months&aggs[productTypes][filters]=BOOK&sort=canonical.date:desc) 3.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 4.
  - Collections 5.
    - [Cambridge Companions](file:///core/publications/collections/cambridge-companions) 1.
    - [Cambridge Editions](file:///core/publications/collections/cambridge-editions) 2.
    - [Cambridge Histories](file:///core/publications/collections/cambridge-histories) 3.
    - [Cambridge Library Collection](file:///core/publications/collections/cambridge-library-collection) 4.
    - [Cambridge Shakespeare](file:///core/publications/collections/cambridge-shakespeare) 5.
    - [Cambridge Handbooks](file:///core/publications/collections/cambridgehandbooks) 6.
  - Collections (cont.) 7.
    - [Dispute Settlement Reports Online](file:///core/publications/collections/dispute-settlement-reports-online) 1.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 2.
    - [Hemingway Letters](file:///core/publications/collections/hemingway-letters) 3.
    - [Shakespeare Survey](file:///core/publications/collections/shakespeare-survey) 4.
    - [Stahl Online](file:///core/publications/collections/stahl-online) 5.
    - [The Correspondence of Isaac Newton](file:///core/publications/collections/the-correspondence-of-isaac-newton) 6.
- Elements 2.
  - Explore 1.
    - [About Elements](file:///core/publications/elements) 1.
    - [Elements series](file:///core/publications/elements/cambridge-elements-series) 2.
    - [Open access Elements](file:///core/publications/elements/published-elements?aggs%5BopenAccess%5D%5Bfilters%5D=7275BA1E84CA769210167A6A66523B47&aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 3.
    - [New Elements](file:///core/publications/elements/published-elements?aggs%5BproductTypes%5D%5Bfilters%5D=ELEMENT&aggs%5BproductDate%5D%5Bfilters%5D=Last%203%20months&searchWithinIds=ECFD8F5C64F47F3F5A3D395C15B7C493) 4.
  - Subjects (A-E) 5.
    - [Anthropology](file:///core/elements/subject/Anthropology/2E44A5AF2838E017617A26DD79FAEAEE) 1.
    - [Archaeology](file:///core/elements/subject/Archaeology/63A50B5368A9F97F8AA2D6AB965B5F4C) 2.
    - [Classical Studies](file:///core/elements/subject/Classical%20Studies/DDC63B7F5792FE2A95D1FB15F76E3F42) 3.
    - [Computer Science](file:///core/elements/subject/Computer%20Science/A57E10708F64FB69CE78C81A5C2A6555) 4.
    - [Drama, Theatre, Performance Studies](file:///core/elements/subject/Drama,%20Theatre,%20Performance%20Studies/2825E4E39F2D641B36543EE80FB1DEA3) 5.
    - [Earth and Environmental Sciences](file:///core/elements/subject/Earth%20and%20Environmental%20Sciences/F470FBF5683D93478C7CAE5A30EF9AE8) 6.
    - [Economics](file:///core/elements/subject/Economics/FA44491F1F55F917C43E9832715B9DE7) 7.
    - [Education](file:///core/elements/subject/Education/550D00F8DF590F2598CF7CC0038E24D1) 8.
    - [Engineering](file:///core/elements/subject/Engineering/CCC62FE56DCC1D050CA1340C1CCF46F5) 9.
  - Subjects (F-O) 10.
    - [Film, Media, Mass Communication](file:///core/elements/subject/Film,%20Media,%20Mass%20Communication/4B91F10E834814A90CE718E7831E492F) 1.
    - [History](file:///core/elements/subject/History/66BE42A30172E280FDE64F8EE2F485B0) 2.
    - [Language and Linguistics](file:///core/elements/subject/Language%20and%20Linguistics/140D314098408C26BDF3009F7FF858E9) 3.
    - [Law](file:///core/elements/subject/Law/7C9FB6788DD8D7E6696263BC774F4D5B) 4.
    - [Life Sciences](file:///core/elements/subject/Life%20Sciences/E044EF2F61B601378786E9EDA901B2D5) 5.
    - [Literature](file:///core/elements/subject/Literature/F2434ADC122145767C6C3B988A8E9BD5) 6.
    - [Management](file:///core/elements/subject/Management/0EDCC0540639B06A5669BDEEF50C4CBE) 7.
    - [Mathematics](file:///core/elements/subject/Mathematics/FA1467C44B5BD46BB8AA6E58C2252153) 8.
    - [Medicine](file:///core/elements/subject/Medicine/66FF02B2A4F83D9A645001545197F287) 9.

- [Music](file:///core/elements/subject/Music/A370B5604591CB3C7F9AFD892DDF7BD1) 10.
- Subjects (P-Z) 11.
  - [Philosophy](file:///core/elements/subject/Philosophy/2D1AC3C0E174F1F1A93F8C7DE19E0FAB) 1.
  - [Physics and Astronomy](file:///core/elements/subject/Physics%20and%20Astronomy/DBFB610E9FC5E012C011430C0573CC06) 2.
  - [Politics and International Relations](file:///core/elements/subject/Politics%20and%20International%20Relations/3BF83347E5E456DAC34F3FABFC8BBF4E) 3.
  - [Psychology](file:///core/elements/subject/Psychology/21B42A72BA3E4CB0E3315E5B1B71B07F) 4.
  - [Religion](file:///core/elements/subject/Religion/53E51D24FB488962B9364A2C4B45D1C3) 5.
  - [Sociology](file:///core/elements/subject/Sociology/0E2CD53A93003DF17E52D753F6E90683) 6.
  - [Statistics and Probability](file:///core/elements/subject/Statistics%20and%20Probability/3150B8B0D1B0B4E8DC17EC9EDFD9CA26) 7.
- Textbooks 2.
  - Explore 1.
    - [Cambridge Higher Education](file:///highereducation/) 1.
    - [Title list](file:///highereducation/services/librarians/title-list) 2.
    - [New titles](file:///highereducation/search?sortBy=publication_date&aggs=%24productDate%24Last%25206%2520months%3Atrue%26Last%252012%2520months%3Atrue%26Last%25203%2520years%3Atrue%26Over%25203%2520years%3Atrue%3B%3B&event=SE-AU_PREF) 3.
- Collections 2.
  - Book collections 1.
    - [Cambridge Companions](file:///core/publications/collections/cambridge-companions) 1.
    - [Cambridge Editions](file:///core/publications/collections/cambridge-editions) 2.
    - [Cambridge Histories](file:///core/publications/collections/cambridge-histories) 3.
    - [Cambridge Library Collection](file:///core/publications/collections/cambridge-library-collection) 4.
    - [Cambridge Shakespeare](file:///core/publications/collections/cambridge-shakespeare) 5.
    - [Cambridge Handbooks](file:///core/publications/collections/cambridgehandbooks) 6.
  - Book collections (cont.) 7.
    - [Dispute Settlement Reports Online](file:///core/publications/collections/dispute-settlement-reports-online) 1.
    - [Flip it Open](file:///core/publications/collections/flip-it-open) 2.
    - [Hemingway Letters](file:///core/publications/collections/hemingway-letters) 3.
    - [Shakespeare Survey](file:///core/publications/collections/shakespeare-survey) 4.
    - [Stahl Online](file:///core/publications/collections/stahl-online) 5.
    - [The Correspondence of Isaac Newton](file:///core/publications/collections/the-correspondence-of-isaac-newton) 6.
  - Journal collections 7.
    - [Cambridge Forum](file:///core/publications/collections/cambridge-forum) 1.
    - [Cambridge Law Reports Collection](file:///core/publications/collections/cambridge-law-reports-collection) 2.
    - [Cambridge Materials](file:///core/publications/collections/cambridge-materials) 3.
    - [Cambridge Prisms](file:///core/publications/collections/cambridge-prisms) 4.
  - Series 5.
    - [All series](file:///core/publications/collections/series) 1.
- Partners 2.
  - Partners 1.
    - [Agenda Publishing](file:///core/publications/publishing-partners/agenda-publishing) 1.
    - [Amsterdam University Press](file:///core/publications/publishing-partners/amsterdam-university-press) 2.
    - [Anthem Press](file:///core/publications/publishing-partners/anthem-press) 3.
    - [Boydell & Brewer](file:///core/publications/publishing-partners/boydell-brewer) 4.
    - [Bristol University Press](file:///core/publications/publishing-partners/bristol-university-press) 5.
    - [Edinburgh University Press](file:///core/publications/publishing-partners/edinburgh-university-press) 6.
    - [Emirates Center for Strategic Studies and Research](file:///core/publications/publishing-partners/emirates-center) 7.
    - [Facet Publishing](file:///core/publications/publishing-partners/facet-publishing) 8.
  - Partners (cont.) 9.
    - [Foundation Books](file:///core/publications/publishing-partners/foundation-books) 1.
    - [Intersentia](file:///core/publications/publishing-partners/intersentia) 2.
    - [ISEAS-Yusof Ishak Institute](file:///core/publications/publishing-partners/iseas) 3.
    - [Jagiellonian University Press](file:///core/publications/publishing-partners/jagiellonian-university-press) 4.
    - [Royal Economic Society](file:///core/publications/publishing-partners/royal-economic-society) 5.

- [Unisa Press](file:///core/publications/publishing-partners/unisa-press) 6.
- [The University of Adelaide Press](file:///core/publications/publishing-partners/university-adelaide-press) 7.
- [Wits University Press](file:///core/publications/publishing-partners/wits-university-press) 8.

#### Services 2.

- About 1.
  - About Cambridge Core 1.
    - [About](file:///core/services/about/about) 1.
    - [Accessibility](file:///core/services/about/accessibility) 2.
    - [CrossMark policy](file:///core/services/about/crossmark-policy) 3.
    - [Ethical Standards](file:///core/services/about/ethical-standards) 4.
  - Environment and sustainability 5.
    - [Environment and sustainability](file:///core/services/about/environment-and-sustainability) 1.
    - [Reducing print](file:///core/services/about/reducing-print) 2.
    - [Journals moving to online only](file:///core/services/about/journals-moving-to-online-only) 3.
  - Guides 4.
    - [User guides](file:///core/services/about/user-guides) 1.
    - [User Guides and Videos](file:///core/services/about/user-guides-and-videos) 2.
    - [Support Videos](file:///core/services/about/support-videos) 3.
    - [Training](file:///core/services/about/training) 4.
  - Help 5.
    - [Cambridge Core help](https://corehelp.cambridge.org/) 1.
    - [Contact us](https://corehelp.cambridge.org/hc/en-gb/p/contact-information) 2.
    - [Technical support](https://corehelp.cambridge.org/hc/en-gb/requests/new) 3.
- Agents 2.
  - Services for agents 1.
    - [Services for agents](file:///core/services/agents/services-for-agents) 1.
    - [Journals for agents](file:///core/services/agents/journals-for-agents) 2.
    - [Books for agents](file:///core/services/agents/books-for-agents) 3.
    - [Price list](file:///core/services/agents/price-list) 4.
- Authors 2.
  - Journals 1.
    - [Journals](file:///core/services/authors/journals) 1.
    - [Journal publishing statistics](file:///core/services/authors/journal-publishing-statistics) 2.
    - [Corresponding author](file:///core/services/authors/corresponding-author) 3.
    - [Seeking permission to use copyrighted material](file:///core/services/authors/seeking-permission-to-use-copyrighted-material) 4.
    - [Publishing supplementary material](file:///core/services/authors/publishing-supplementary-material) 5.
    - [Writing an effective abstract](file:///core/services/authors/writing-an-effective-abstract) 6.
    - [Journal production FAQs](file:///core/services/authors/journal-production-faqs) 7.
  - Journals (cont.) 8.
    - [Author affiliations](file:///core/services/authors/author-affiliations) 1.
    - [Co-reviewing policy](file:///core/services/authors/co-reviewing-policy) 2.
    - [Anonymising your manuscript](file:///core/services/authors/anonymising-your-manuscript) 3.
    - [Publishing open access](file:///core/services/authors/publishing-open-access) 4.
    - [Convert your article to Gold Open Access](file:///core/services/authors/convert-your-article-to-open-access) 5.
    - [Publishing Open Access webinars](file:///core/services/authors/publishing-open-access-webinars) 6.
  - Journals (cont.) 7.
    - [Preparing and submitting your paper](file:///core/services/authors/preparing-and-submitting-your-paper) 1.
    - [Publication journey](file:///core/services/authors/publication-journey) 2.
    - [Publishing agreement FAQs for journal authors](file:///core/services/authors/digital-author-publishing-agreement-faqs) 3.
    - [Author Information Form FAQs](file:///core/services/authors/author-information-form-faqs) 4.
    - [Promoting your published paper](file:///core/services/authors/promoting-your-published-paper) 5.
    - [Measuring impact](file:///core/services/authors/measuring-impact) 6.

- [Journals artwork guide](file:///core/services/authors/journals-artwork-guide) 7.
- [Using ORCID](file:///core/services/authors/using-orcid) 8.
- Books 9.
  - [Books](file:///core/services/authors/books) 1.
  - [Marketing your book](file:///core/services/authors/marketing-your-book) 2.
  - [Author guides for Cambridge Elements](file:///core/services/authors/elements-user-guides) 3.
- Corporates 2.
  - Corporates 1.
    - [Commercial reprints](file:///core/services/corporates/commercial-reprints) 1.
    - [Advertising](file:///core/services/corporates/advertising) 2.
    - [Sponsorship](file:///core/services/corporates/sponsorship) 3.
    - [Book special sales](file:///core/services/corporates/book-special-sales) 4.
    - [Contact us](file:///core/services/corporates/contact-us) 5.
- Editors 2.
  - Information 1.
    - [Journal development](file:///core/services/editors/journal-development) 1.
    - [Peer review for editors](file:///core/services/editors/peer-review-for-editors) 2.
    - [Open access for editors](file:///core/services/editors/open-access-for-editors) 3.
    - [Policies and guidelines](file:///core/services/editors/policies-and-guidelines) 4.
  - Resources 5.
    - [The editor's role](file:///core/services/editors/the-editors-role) 1.
    - [Open research for editors](file:///core/services/editors/open-research-for-editors) 2.
    - [Engagement and promotion](file:///core/services/editors/engagement-and-promotion) 3.
    - [Blogging](file:///core/services/editors/blogging) 4.
    - [Social media](file:///core/services/editors/social-media) 5.
- Librarians 2.
  - Information 1.
    - [Open Access for Librarians](file:///core/services/librarians/open-access-for-librarians) 1.
    - [Transformative agreements](https://www.cambridge.org/core/services/open-access-policies/read-and-publish-agreements) 2.
    - [Transformative Agreements FAQs](file:///core/services/librarians/transformative-agreements-faqs) 3.
    - [Evidence based acquisition](file:///core/services/librarians/evidence-based-acquisition) 4.
    - [Cambridge libraries of the world podcast](file:///core/services/librarians/cambridge-libraries-of-the-world-podcast) 5.
    - [Purchasing models](file:///core/services/librarians/purchasing-models) 6.
    - [Journals Publishing Updates](file:///core/services/librarians/journals-publishing-updates) 7.
  - Products 8.
    - [Cambridge frontlist](file:///core/services/librarians/cambridge-frontlist) 1.
    - [Cambridge journals digital archive](file:///core/services/librarians/cambridge-journals-digital-archive) 2.
    - [Hot topics](file:///core/services/librarians/hot-topics) 3.
    - [Other digital products](file:///core/services/librarians/other-digital-products) 4.
    - [Perpetual access products](file:///core/services/librarians/perpetual-access-products) 5.
    - [Price list](file:///core/services/librarians/price-list) 6.
    - [Developing country programme](file:///core/services/librarians/developing-country-programme) 7.
    - [New content](file:///core/services/librarians/new-content) 8.
  - Tools 9.
    - [Eligibility checker](file:///core/eligibility-checker) 1.
    - [Transformative agreements](https://www.cambridge.org/core/services/open-access-policies/read-and-publish-agreements) 2.
    - [KBART](https://www.cambridge.org/core/services/librarians/kbart) 3.
    - [MARC records](https://www.cambridge.org/core/services/librarians/marc-records) 4.
    - [Using MARCEdit for MARC records](file:///core/services/librarians/using-marcedit-for-marc-records) 5.
    - [Inbound OpenURL specifications](file:///core/services/librarians/inbound-openurl-specifications) 6.
    - [COUNTER usage reporting](file:///core/services/librarians/counter-usage-reporting) 7.

#### Resources 8.

- [Catalogues and resources](file:///core/services/librarians/catalogues-and-resources) 1.
- [Making the most of your EBA](file:///core/services/librarians/making-the-most-of-your-eba) 2.
- [Posters](file:///core/services/librarians/posters) 3.
- [Leaflets and brochures](file:///core/services/librarians/leaflets-and-brochures) 4.
- [Additional resources](file:///core/services/librarians/additional-resources) 5.
- [Find my sales contact](file:///core/services/librarians/find-my-sales-contact) 6.
- [Training](file:///core/services/librarians/training) 7.
- [Read and publish resources](file:///core/services/librarians/read-and-publish-resources) 8.

#### Peer review 2.

- Peer review 1.
  - [How to peer review journal articles](file:///core/services/peer-review/how-to-peer-review-journal-articles) 1.
  - [How to peer review book proposals](file:///core/services/peer-review/how-to-peer-review-book-proposals) 2.
  - [How to peer review Registered Reports](file:///core/services/peer-review/how-to-peer-review-registered-reports) 3.
  - [Peer review FAQs](file:///core/services/peer-review/peer-review-faqs) 4.
  - [Ethics in peer review](file:///core/services/peer-review/ethics-in-peer-review) 5.
  - [Online peer review systems](file:///core/services/peer-review/online-peer-review-systems) 6.
  - [A guide to Publons](file:///core/services/peer-review/a-guide-to-publons) 7.

#### Publishing ethics 2.

- Journals 1.
  - [Publishing ethics guidelines for journals](file:///core/services/publishing-ethics/publishing-ethics-guidelines-journals) 1.
  - [Core editorial policies for journals](file:///core/services/publishing-ethics/core-editorial-policies-journals) 2.
  - [Authorship and contributorship for journals](file:///core/services/publishing-ethics/authorship-and-contributorship-journals) 3.
  - [Affiliations for journals](file:///core/services/publishing-ethics/affiliations-journals) 4.
  - [Research ethics for journals](file:///core/services/publishing-ethics/research-ethics-journals) 5.
  - [Competing interests and funding for journals](file:///core/services/publishing-ethics/competing-interests-and-funding-journals) 6.
- Journals (cont.) 7.
  - [Data and supporting evidence for journals](file:///core/services/publishing-ethics/data-and-supporting-evidence-for-journals) 1.
  - [Misconduct for journals](file:///core/services/publishing-ethics/misconduct-journals) 2.
  - [Corrections, retractions and removals for journals](file:///core/services/publishing-ethics/corrections-retractions-and-removals-journals) 3.
  - [Versions and adaptations for journals](file:///core/services/publishing-ethics/versions-and-adaptations-journals) 4.
  - [Libel, defamation and freedom of expression](file:///core/services/publishing-ethics/libel-defamation-and-freedom-of-expression) 5.
  - [Business ethics journals](file:///core/services/publishing-ethics/business-ethics-journals) 6.

#### Books 7.

- [Publishing ethics guidelines for books](file:///core/services/publishing-ethics/publishing-ethics-guidelines-books) 1.
- [Core editorial policies for books](file:///core/services/publishing-ethics/core-editorial-policies-books) 2.
- [Authorship and contributorship for books](file:///core/services/publishing-ethics/authorship-and-contributorship-books) 3.
- [Affiliations for books](file:///core/services/publishing-ethics/affiliations-books) 4.
- [Research ethics for books](file:///core/services/publishing-ethics/research-ethics-books) 5.
- [Competing interests and funding for books](file:///core/services/publishing-ethics/competing-interests-and-funding-books) 6.
- Books (cont.) 7.
  - [Data and supporting evidence for books](file:///core/services/publishing-ethics/data-and-supporting-evidence-books) 1.
  - [Misconduct for books](file:///core/services/publishing-ethics/misconduct-books) 2.
  - [Corrections, retractions and removals for books](file:///core/services/publishing-ethics/corrections-retractions-and-removals-books) 3.
  - [Versions and adaptations for books](file:///core/services/publishing-ethics/versions-and-adaptations-books) 4.
  - [Libel, defamation and freedom of expression](file:///core/services/publishing-ethics/libel-defamation-and-freedom-of-expression) 5.
  - [Business ethics books](file:///core/services/publishing-ethics/business-ethics-books) 6.

#### Publishing partners 2.

- Publishing partners 1.
  - [Publishing partnerships](file:///core/services/publishing-partners/publishing-partnerships) 1.
  - [Partner books](file:///core/services/publishing-partners/partner-books) 2.
  - [eBook publishing partnerships](file:///core/services/publishing-partners/ebook-publishing-partnerships) 3.

- [Journal publishing partnerships](file:///core/services/publishing-partners/journal-publishing-partnerships) 4.
- Publishing partners (cont.) 5.
  - [Journals publishing](file:///core/services/publishing-partners/journals-publishing) 1.
  - [Customer support](file:///core/services/publishing-partners/customer-support) 2.
  - [Membership Services](file:///core/services/publishing-partners/membership-services) 3.
  - [Our Team](file:///core/services/publishing-partners/our-team) 4.
- Open research 2.
  - Open access policies 1.
    - Open access policies 1.
      - [Open research](file:///core/services/open-research-policies/open-research) 1.
      - [Open access policies](file:///core/services/open-research-policies/open-access-policies) 2.
      - [Cambridge University Press and Plan S](file:///core/services/open-research-policies/cambridge-university-press-and-plan-s) 3.
      - [Text and data mining](file:///core/services/open-research-policies/text-and-data-mining) 4.
      - [Preprint policy](file:///core/services/open-research-policies/preprint-policy) 5.
      - [Social sharing](file:///core/services/open-research-policies/social-sharing) 6.
    - Journals 7.
      - [Open access journals](file:///core/services/open-research-policies/open-access-journals) 1.
      - [Gold Open Access journals](file:///core/services/open-research-policies/gold-open-access-journals) 2.
      - [Transformative journals](file:///core/services/open-research-policies/transformative-journals) 3.
      - [Green Open Access policy for journals](file:///core/services/open-research-policies/green-open-access-policy-for-journals) 4.
      - [Transparent pricing policy for journals](file:///core/services/open-research-policies/transparent-pricing-policy-for-journals) 5.
    - Books and Elements 6.
      - [Open access books](file:///core/services/open-research-policies/open-access-books) 1.
      - [Gold open access books](file:///core/services/open-research-policies/gold-open-access-books) 2.
      - [Green Open Access policy for books](file:///core/services/open-research-policies/green-open-access-policy-for-books) 3.
      - [Open access Elements](file:///core/services/open-research-policies/open-access-elements) 4.
  - Open access publishing 2.
    - About open access 1.
      - [Open research](file:///core/services/open-access-publishing/open-research) 1.
      - [Open Access Week](file:///core/services/open-access-publishing/open-access-week) 2.
      - [What is open access?](file:///core/services/open-access-publishing/open-access) 3.
      - [Open access glossary](file:///core/services/open-access-publishing/open-access-glossary) 4.
      - [Open access myths](file:///core/services/open-access-publishing/open-access-myths) 5.
      - [Hybrid Open Access FAQs](file:///core/services/open-access-publishing/hybrid-open-access-faqs) 6.
      - [Eligibility checker](file:///core/eligibility-checker) 7.
    - Open access resources 8.
      - [Open access resources](file:///core/services/open-access-publishing/open-access-resources) 1.
      - [Benefits of open access](file:///core/services/open-access-publishing/benefits-of-open-access) 2.
      - [Creative commons licences](file:///core/services/open-access-publishing/creative-commons-licenses) 3.
      - [Funder policies and mandates](file:///core/services/open-access-publishing/funder-policies-and-mandates) 4.
      - [Article type definitions](file:///core/services/open-access-publishing/article-type-definitions) 5.
      - [Convert your article to Gold Open Access](file:///core/services/open-access-publishing/convert-your-article-to-open-access) 6.
      - [Open access video resources](file:///core/services/open-access-publishing/open-access-video-resources) 7.
  - Open research initiatives 2.
    - Research transparency 1.
      - [Transparency and openness](file:///core/services/open-research-initiatives/transparency-and-openness) 1.
      - [Open Practice Badges](file:///core/services/open-research-initiatives/open-practice-badges) 2.
      - [OA organisations, initiatives & directories](file:///core/services/open-research-initiatives/oa-organisations-initiatives-and-directories) 3.
      - [Registered Reports](file:///core/services/open-research-initiatives/registered-reports) 4.
      - [Annotation for Transparent Inquiry \(ATI\)](file:///core/services/open-research-initiatives/annotation-for-transparent-inquiry-ati) 5.
    - Journal flips 6.
      - [Open access journal flips](file:///core/services/open-research-initiatives/open-access-journal-flips) 1.

- [OA Journal Flip FAQs](file:///core/services/open-research-initiatives/oa-journal-flip-faqs) 2.
- Flip it Open 3.
  - [Flip it Open](file:///core/services/open-research-initiatives/flip-it-open) 1.
  - [Flip it Open FAQs](file:///core/services/open-research-initiatives/flip-it-open-faqs) 2.
- Open access funding 2.
  - Open access funding 1.
    - [Funding open access publication](file:///core/services/open-access-funding/funding-open-access-publication) 1.
    - [Cambridge Open Equity Initiative](file:///core/services/open-access-funding/cambridge-open-equity-initiative) 2.
    - [Completing a RightsLink \(open access\) transaction](file:///core/services/open-access-funding/completing-a-rightslink-open-access-transaction) 3.
- Cambridge Open Engage 2.
  - Cambridge Open Engage 1.
    - [Cambridge Open Engage](file:///core/services/cambridge-open-engage/cambridge-open-engage) 1.
    - [Partner With Us](file:///core/services/cambridge-open-engage/engage-partner-with-us) 2.
    - [Branded Hubs](file:///core/services/cambridge-open-engage/engage-branded-hubs) 3.
    - [Event Workspaces](file:///core/services/cambridge-open-engage/engage-event-workspaces) 4.
    - [Partner Resources](file:///core/services/cambridge-open-engage/engage-partner-resources) 5.
    - [APSA Preprints](file:///core/services/cambridge-open-engage/engage-apsa-preprints) 6.
    - [APSA Preprints FAQs](file:///core/services/cambridge-open-engage/engage-apsa-preprints-faqs) 7.
- [< Back to search results](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Home](file:///core/) 1.
- [Books](file:///core/publications/books) 2.
- Introduction to the Modern Theory of Dynamical Systems 3.

Introduction to the Modern Theory of Dynamical Systems

# **Introduction to the Modern Theory of Dynamical Systems**

| yes                              |  |  |  |  |
|----------------------------------|--|--|--|--|
|                                  |  |  |  |  |
| Search within full text          |  |  |  |  |
| Submit search                    |  |  |  |  |
| 2D6CF65297378C2704A4A56D0F77B503 |  |  |  |  |
| BOOK_PART                        |  |  |  |  |

![](_page_9_Picture_0.jpeg)

- Cited by [1724](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- Cited by •

![](_page_9_Picture_3.jpeg)

Crossref Citations

![](_page_9_Picture_5.jpeg)

**This Book has been cited by the following publications. This list is generated based on data provided by [Crossref.](http://www.crossref.org/citedby/index.html)**

Gutkin, Eugene and Katok, Anatole 1995. Caustics for inner and outer billiards. Communications in Mathematical Physics, Vol. 173, Issue. 1, p. 101.

- [CrossRef](https://doi.org/10.1007/BF02100183) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Caustics+for+inner+and+outer+billiards&author=Gutkin+Eugene&author=Katok+Anatole&publication_year=1995) •

Barreira, Luis M. 1996. A non-additive thermodynamic formalism and applications to dimension theory of hyperbolic dynamical systems. Ergodic Theory and Dynamical Systems, Vol. 16, Issue. 5, p. 871.

- [CrossRef](https://doi.org/10.1017/S0143385700010117) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=A+non-additive+thermodynamic+formalism+and+applications+to+dimension+theory+of+hyperbolic+dynamical+systems&author=Barreira+Luis+M.&publication_year=1996) •

Kourjanski, Mikhail and Varaiya, Pravin 1996. Hybrid Systems III. Vol. 1066, Issue. , p. 413.

- [CrossRef](https://doi.org/10.1007/BFb0020964) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Hybrid+Systems+III&author=Kourjanski+Mikhail&author=Varaiya+Pravin&publication_year=1996) •

Chirikov, B. 1996. Law and Prediction in the Light of Chaos Research. Vol. 473, Issue. , p. 10.

- [CrossRef](https://doi.org/10.1007/BFb0101865) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Law+and+Prediction+in+the+Light+of+Chaos+Research&author=Chirikov+B.&publication_year=1996) •

Gutkin, Eugene 1996. Billiards in polygons: Survey of recent results. Journal of Statistical Physics, Vol. 83, Issue. 1-2, p. 7.

- [CrossRef](https://doi.org/10.1007/BF02183637) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Billiards+in+polygons:+Survey+of+recent+results&author=Gutkin+Eugene&publication_year=1996) •

Pesin, Yakov and Weiss, Howard 1996. On the dimension of deterministic and random Cantor-like sets, symbolic dynamics, and the Eckmann-Ruelle Conjecture. Communications in Mathematical Physics, Vol. 182, Issue. 1, p. 105.

- [CrossRef](https://doi.org/10.1007/BF02506387) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=On+the+dimension+of+deterministic+and+random+Cantor-like+sets+symbolic+dynamics+and+the+Eckmann-Ruelle+Conjecture&author=Pesin+Yakov&author=Weiss+Howard&publication_year=1996) •

Pesin, Yakov and Weiss, Howard 1997. A multifractal analysis of equilibrium measures for conformal expanding maps and Moran-like geometric constructions. Journal of Statistical Physics, Vol. 86, Issue. 1-2, p. 233.

- [CrossRef](https://doi.org/10.1007/BF02180206) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=A+multifractal+analysis+of+equilibrium+measures+for+conformal+expanding+maps+and+Moran-like+geometric+constructions&author=Pesin+Yakov&author=Weiss+Howard&publication_year=1997) •

Gutkin, Eugene 1997. Two Applications of Calculus to Triangular Billiards. The American Mathematical Monthly, Vol. 104, Issue. 7, p. 618.

- [CrossRef](https://doi.org/10.1080/00029890.1997.11990690) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Two+Applications+of+Calculus+to+Triangular+Billiards&author=Gutkin+Eugene&publication_year=1997) •

Vereikina, M. B. and Sharkovskii, A. N. 1997. Tracing of pseudotrajectories of dynamical systems and stability of prolongations of orbits. Ukrainian Mathematical Journal, Vol. 49, Issue. 8, p. 1140.

- [CrossRef](https://doi.org/10.1007/BF02487543) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Tracing+of+pseudotrajectories+of+dynamical+systems+and+stability+of+prolongations+of+orbits&author=Vereikina+M.+B.&author=Sharkovskii+A.+N.&publication_year=1997) •

Pérez-Marco, Ricardo 1997. Fixed points and circle maps. Acta Mathematica, Vol. 179, Issue. 2, p. 243.

- [CrossRef](https://doi.org/10.1007/BF02392745) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Fixed+points+and+circle+maps&author=P%C3%A9rez-Marco+Ricardo&publication_year=1997) •

Hasselblatt, Boris and Wilkinson, Amie 1997. Prevalence of non-Lipschitz Anosov foliations. Electronic Research Announcements of the American Mathematical Society, Vol. 3, Issue. 14, p. 93.

- [CrossRef](https://doi.org/10.1090/S1079-6762-97-00030-9) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Prevalence+of+non-Lipschitz+Anosov+foliations&author=Hasselblatt+Boris&author=Wilkinson+Amie&publication_year=1997) •

Aziz-Alaoui, M.A. Fedorenko, A.D. Lozi, R. and Sharkovsky, A.N. 1997. Recovering trajectories of chaotic piecewise linear dynamical systems. Vol. 2, Issue. , p. 230.

- [CrossRef](https://doi.org/10.1109/COC.1997.631332) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Recovering+trajectories+of+chaotic+piecewise+linear+dynamical+systems&author=Aziz-Alaoui+M.A.&author=Fedorenko+A.D.&author=Lozi+R.&author=Sharkovsky+A.N.&publication_year=1997) •

Paeng, Seong-Hun 1997. Topological entropy for geodesic flows under a Ricci curvature condition. Proceedings of the American Mathematical Society, Vol. 125, Issue. 6, p. 1873.

- [CrossRef](https://doi.org/10.1090/S0002-9939-97-03780-5) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Topological+entropy+for+geodesic+flows+under+a+Ricci+curvature+condition&author=Paeng+Seong-Hun&publication_year=1997) •

Hurt, Norman E. 1997. Quantum Chaos and Mesoscopic Systems. p. 297.

- [CrossRef](https://doi.org/10.1007/978-94-015-8792-1_15) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Quantum+Chaos+and+Mesoscopic+Systems&author=Hurt+Norman+E.&publication_year=1997) •

Adler, Roy 1998. Symbolic dynamics and Markov partitions. Bulletin of the American Mathematical Society, Vol. 35, Issue. 1, p. 1.

- [CrossRef](https://doi.org/10.1090/S0273-0979-98-00737-X) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Symbolic+dynamics+and+Markov+partitions&author=Adler+Roy&publication_year=1998) •

Dorfman, J.R 1998. Deterministic chaos and the foundations of the kinetic theory of gases. Physics Reports, Vol. 301, Issue. 1-3, p. 151.

- [CrossRef](https://doi.org/10.1016/S0370-1573(98)00009-X) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Deterministic+chaos+and+the+foundations+of+the+kinetic+theory+of+gases&author=Dorfman+J.R&publication_year=1998) •

Wirtz, Bruno 1998. Fixed points and entropy for non solvable dynamics onC, O. Boletim da Sociedade Brasileira de Matem�tica, Vol. 29, Issue. 1, p. 53.

- [CrossRef](https://doi.org/10.1007/BF01245868) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Fixed+points+and+entropy+for+non+solvable+dynamics+onC+O&author=Wirtz+Bruno&publication_year=1998) •

Afraimovich, V. and Zaslavsky, G. M. 1998. Chaos, Kinetics and Nonlinear Dynamics in Fluids and Plasmas. Vol. 511, Issue. , p. 59.

- [CrossRef](https://doi.org/10.1007/BFb0106953) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Chaos+Kinetics+and+Nonlinear+Dynamics+in+Fluids+and+Plasmas&author=Afraimovich+V.&author=Zaslavsky+G.+M.&publication_year=1998) •

Bogoyavlenskij, O I 1998. Canonical forms for the invariant tensors andA-B-Ccohomologies of integrable Hamiltonian systems. Sbornik: Mathematics, Vol. 189, Issue. 3, p. 315.

- [CrossRef](https://doi.org/10.1070/SM1998v189n03ABEH000302) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Canonical+forms+for+the+invariant+tensors+andA-B-C-cohomologies+of+integrable+Hamiltonian+systems&author=Bogoyavlenskij+O+I&publication_year=1998) •

Guerre, E. and Maës, J. 1998. Optimal Rate for Nonparametric Estimation in Deterministic Dynamical Systems. Statistical Inference for Stochastic Processes, Vol. 1, Issue. 2, p. 157.

- [CrossRef](https://doi.org/10.1023/A:1009975728919) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?title=Optimal+Rate+for+Nonparametric+Estimation+in+Deterministic+Dynamical+Systems&author=Guerre+E.&author=Ma%C3%ABs+J.&publication_year=1998) •

| Download full list |               |  |
|--------------------|---------------|--|
| ×                  |               |  |
|                    |               |  |
|                    | Icon<br>Cite  |  |
|                    |               |  |
|                    | Icon<br>Share |  |

[Anatole Katok,](file:///core/search?filters%5BauthorTerms%5D=Anatole%20Katok&eventCode=SE-AU) Pennsylvania State University, [Boris Hasselblatt,](file:///core/search?filters%5BauthorTerms%5D=Boris%20Hasselblatt&eventCode=SE-AU) Tufts University, Massachusetts ◦

Show more authors

You may already have access via personal or institutional login

[Check access](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) ◦

> Check if you have access via personal or institutional login [Log in](file:///core/login?ref=/core/books/introduction-to-the-modern-theory-of-dynamical-systems/2D6CF65297378C2704A4A56D0F77B503) [Register](file:///core/register?ref=/core/books/introduction-to-the-modern-theory-of-dynamical-systems/2D6CF65297378C2704A4A56D0F77B503)

Select format Digital US\$94.00 Hardback Unavailable Paperback

Publisher:

Cambridge University Press

Unavailable

Publication date:

June 2012

April 1995

ISBN:

9780511809187 9780521341875 9780521575577

DOI:

<https://doi.org/10.1017/CBO9780511809187>

Dimensions:

(234 x 156 mm)

Weight & Pages:

1.27kg, 824 Pages

Dimensions:

(234 x 156 mm)

Weight & Pages:

1.16kg, 824 Pages

Subjects:

[Mathematics \(general\)](file:///core/browse-subjects/mathematics/mathematics-general), [Mathematics,](file:///core/browse-subjects/mathematics) [Differential and Integral Equations,](file:///core/browse-subjects/mathematics/differential-and-integral-equations-dynamical-systems-and-control-theory) [Dynamical Systems and Control Theory](file:///core/browse-subjects/mathematics/differential-and-integral-equations-dynamical-systems-and-control-theory)

Series:

[Encyclopedia of Mathematics and its Applications](file:///core/series/encyclopedia-of-mathematics-and-its-applications/14161A9F36D6D0C9A650A4F86F74162D) (54)

You may already have access via personal or institutional login

[Check access](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) • •

> Check if you have access via personal or institutional login [Log in](file:///core/login?ref=/core/books/introduction-to-the-modern-theory-of-dynamical-systems/2D6CF65297378C2704A4A56D0F77B503) [Register](file:///core/register?ref=/core/books/introduction-to-the-modern-theory-of-dynamical-systems/2D6CF65297378C2704A4A56D0F77B503)

Selected: Digital

Add to cart [View cart](file:///core/shopping-cart) [Buy from Cambridge.org](https://www.cambridge.org/core_title/gb/109163)

Subjects:

[Mathematics \(general\)](file:///core/browse-subjects/mathematics/mathematics-general), [Mathematics](file:///core/browse-subjects/mathematics), [Differential and Integral Equations,](file:///core/browse-subjects/mathematics/differential-and-integral-equations-dynamical-systems-and-control-theory) [Dynamical Systems and Control Theory](file:///core/browse-subjects/mathematics/differential-and-integral-equations-dynamical-systems-and-control-theory)

Series:

[Encyclopedia of Mathematics and its Applications](file:///core/series/encyclopedia-of-mathematics-and-its-applications/14161A9F36D6D0C9A650A4F86F74162D) (54)

Information [Information](#page-13-0) [Contents](#page-14-0) [Metrics](#page-27-0) [Accessibility](#page-29-0)

## <span id="page-13-0"></span>**Book description**

This book provided the first self-contained comprehensive exposition of the theory of dynamical systems as a core mathematical discipline closely intertwined with most of the main areas of mathematics. The authors introduce and rigorously develop the theory while providing researchers interested in applications with fundamental tools and paradigms. The book begins with a discussion of several elementary but fundamental examples.

These are used to formulate a program for the general study of asymptotic properties and to introduce the principal theoretical concepts and methods. The main theme of the second part of the book is the interplay between local analysis near individual orbits and the global complexity of the orbit structure. The third and fourth parts develop the theories of low-dimensional dynamical systems and hyperbolic dynamical systems in depth. Over 400 systematic exercises are included in the text. The book is aimed at students and researchers in mathematics at all levels from advanced undergraduate up.

### **Reviews**

' … there is no other treatment coming close in terms of comprehensiveness and readability … it is indispensable for anybody working on dynamical systems in almost any context, and even experts will find interesting new proofs, insights and historical references throughout the book.'

Source: Monatshefte für Mathematik

'… contains detailed discussion … presents many recent results … The text is carefully written and is accompanied by many excercises.'

Source: European Mathematical Society Newsletter

'This book provides the first self-contained comprehensive exposition of the theory of dynamical systems as a core mathematical discipline.'

Source: L'Enseignement Mathématique

<span id="page-14-0"></span>

| 2D6CF65297378C2704A4A56D0F77B503                |  |
|-------------------------------------------------|--|
| BOOK_PART                                       |  |
| mtdMetadata.bookPartMetamtdPositionSortable:asc |  |
| 30                                              |  |
| cambridge-core/book/contents/listings           |  |

true

![](_page_15_Picture_2.jpeg)

- Aa Reduce textAa Enlarge text

#### **Refine List**

![](_page_17_Picture_0.jpeg)

![](_page_18_Picture_0.jpeg)

Classifications

K5N2SmEn-FQhFy8jRQbWDu1pwM3eKHH\_Psps

## **Actions for selected content:**

#### [Select all](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) | [Deselect all](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf)

- [View selected items](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Save to my bookmarks](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Export citations](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Download PDF \(zip\)](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Save to Kindle](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Save to Dropbox](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •
- [Save to Google Drive](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf) •

### **Save content to** •

To save content items to your account, please confirm that you agree to abide by our usage policies. If this is the first time you use this feature, you will be asked to authorise Cambridge Core to connect with your account. [Find out more about saving content to](file:///core/help) .

To save content items to your Kindle, first ensure noreply@cambridge.org is added to your Approved Personal Document Email List under your Personal Document Settings on the Manage Your Content and Devices page of your Amazon account. Then enter the 'name' part of your Kindle email address below. [Find out more about](file:///core/help) [saving to your Kindle](file:///core/help).

Note you can select to save to either the @free.kindle.com or @kindle.com variations. '@free.kindle.com' emails are free but can only be saved to your device when it is connected to wi-fi. '@kindle.com' emails can be delivered even when you are not connected to wi-fi, but note that service fees apply.

Find out more about the [Kindle Personal Document Service](https://www.amazon.com/gp/help/customer/display.html/ref=kinw_myk_wl_ln?ie=UTF8&nodeId=200767340#fees).

Please be advised that item(s) you selected are not available.

#### **You are about to save**

| ◦                                                                                                            |                                                                       |
|--------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------|
| Your Kindle email address                                                                                    |                                                                       |
|                                                                                                              |                                                                       |
| @free.kindle.com                                                                                             |                                                                       |
| @kindle.com (service fees apply)                                                                             |                                                                       |
| By using this service, you agree that you will only keep content for<br>Drive or other file sharing services | personal use, and will not openly distribute them via Dropbox, Google |
| pdf                                                                                                          |                                                                       |
| K5N2SmEn-FQhFy8jRQbWDu1pwM3eKHH_Psps                                                                         |                                                                       |
| Cancel                                                                                                       |                                                                       |
| Save                                                                                                         |                                                                       |
| ×                                                                                                            |                                                                       |

K5N2SmEn-FQhFy8jRQbWDu1pwM3eKHH\_Psps

### **Save Search**

| You can save your searches here and later view and run them again in "My saved searches".                                                                |  |  |  |  |  |
|----------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|
| Search Title: required                                                                                                                                   |  |  |  |  |  |
| Please provide a title, maximum of 40 characters.  Cancel                                                                                                |  |  |  |  |  |
| Save                                                                                                                                                     |  |  |  |  |  |
| ×                                                                                                                                                        |  |  |  |  |  |
| Contents                                                                                                                                                 |  |  |  |  |  |
| Page 1 of 2                                                                                                                                              |  |  |  |  |  |
| <ul> <li>First</li> <li>« Prev</li> <li>1</li> <li>2</li> <li>Next »</li> <li>Last</li> </ul>                                                            |  |  |  |  |  |
| Contents Select Frontmatter                                                                                                                              |  |  |  |  |  |
| • Frontmatter pp i-vi                                                                                                                                    |  |  |  |  |  |
| <ul> <li>Get access         Check if you have access via personal or institutional login         Log in Register         Export citation     </li> </ul> |  |  |  |  |  |
| Select Contents                                                                                                                                          |  |  |  |  |  |
| • Contents pp vii-xii                                                                                                                                    |  |  |  |  |  |
| <ul> <li>Get access         Check if you have access via personal or institutional login         Log in Register         Export citation     </li> </ul> |  |  |  |  |  |
| Select PREFACE                                                                                                                                           |  |  |  |  |  |

- PREFACE pp xiii-xviii
- - Export citation

## Select 0 - INTRODUCTION

- <u>0 INTRODUCTION</u> pp 1-12
- - Export citation

Select Part 1 - Examples and fundamental concepts

- Part 1 Examples and fundamental concepts pp 13-14
- - Export citation

## Select 1 - FIRST EXAMPLES

- 1 FIRST EXAMPLES pp 15-56
- - Export citation

Select 2 - EQUIVALENCE, CLASSIFICATION, AND INVARIANTS

- 2 EQUIVALENCE, CLASSIFICATION, AND INVARIANTS pp 57-104
- - Export citation

# Select 3 - PRINCIPAL CLASSES OF ASYMPTOTIC TOPOLOGICAL INVARIANTS • 3 - PRINCIPAL CLASSES OF ASYMPTOTIC TOPOLOGICAL INVARIANTS pp 105-132 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 4 - STATISTICAL BEHAVIOR OF ORBITS AND INTRODUCTION TO **ERGODIC THEORY** • 4 - STATISTICAL BEHAVIOR OF ORBITS AND INTRODUCTION TO ERGODIC THEORY pp 133-182 0 ■ Get access Check if you have access via personal or institutional login Loa in Register Export citation Select 5 - SYSTEMS WITH SMOOTH INVARIANT MEASURES AND MORE **EXAMPLES** • 5 - SYSTEMS WITH SMOOTH INVARIANT MEASURES AND MORE EXAMPLES pp 183-234 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select Part 2 - Local analysis and orbit growth • Part 2 - Local analysis and orbit growth pp 235-236 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 6 - LOCAL HYPERBOLIC THEORY AND ITS APPLICATIONS • 6 - LOCAL HYPERBOLIC THEORY AND ITS APPLICATIONS pp 237-286

Get access

Select 7 - TRANSVERSALITY AND GENERICITY • 7 - TRANSVERSALITY AND GENERICITY pp 287-306 ■ Get access Check if you have access via personal or institutional login Log in Register • Export citation Select 8 - ORBIT GROWTH ARISING FROM TOPOLOGY • 8 - ORBIT GROWTH ARISING FROM TOPOLOGY pp 307-334 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 9 - VARIATIONAL ASPECTS OF DYNAMICS • 9 - VARIATIONAL ASPECTS OF DYNAMICS pp 335-378 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select Part 3 - Low-dimensional phenomena • Part 3 - Low-dimensional phenomena pp 379-380 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation

Select 10 - INTRODUCTION: WHAT IS LOW-DIMENSIONAL DYNAMICS?

Check if you have access via personal or institutional login

Log in Register

• Export citation

- 10 INTRODUCTION: WHAT IS LOW-DIMENSIONAL DYNAMICS? pp 381-386
- ○ Get access
  Check if you have access via personal or institutional login
  Log in Register
  - Export citation

### Select 11 - HOMEOMORPHISMS OF THE CIRCLE

- 11 HOMEOMORPHISMS OF THE CIRCLE pp 387-400
- - Export citation

### Select 12 - CIRCLE DIFFEOMORPHISMS

- 12 CIRCLE DIFFEOMORPHISMS pp 401-422
- - Export citation

### Select 13 - TWIST MAPS

- 13 TWIST MAPS pp 423-450
- ○ Get access

  Check if you have access via personal or institutional login

  Log in Register
  - Export citation

# Select 14 - FLOWS ON SURFACES AND RELATED DYNAMICAL SYSTEMS

- 14 FLOWS ON SURFACES AND RELATED DYNAMICAL SYSTEMS pp 451-488
- Get access
   Check if you have access via personal or institutional login
   Log in Register
  - Export citation

# Select 15 - CONTINUOUS MAPS OF THE INTERVAL • 15 - CONTINUOUS MAPS OF THE INTERVAL pp 489-518 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 16 - SMOOTH MAPS OF THE INTERVAL • 16 - SMOOTH MAPS OF THE INTERVAL pp 519-528 Get access Check if you have access via personal or institutional login Log in Register Export citation Select Part 4 - Hyperbolic dynamical systems • Part 4 - Hyperbolic dynamical systems pp 529-530 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 17 - SURVEY OF EXAMPLES • 17 - SURVEY OF EXAMPLES pp 531-564 ■ Get access Check if you have access via personal or institutional login Loa in Register Export citation Select 18 - TOPOLOGICAL PROPERTIES OF HYPERBOLIC SETS • 18 - TOPOLOGICAL PROPERTIES OF HYPERBOLIC SETS pp 565-596 0 ■ Get access Check if you have access via personal or institutional login

Log in Register

Export citation

# Select 19 - METRIC STRUCTURE OF HYPERBOLIC SETS • 19 - METRIC STRUCTURE OF HYPERBOLIC SETS pp 597-614 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 20 - EQUILIBRIUM STATES AND SMOOTH INVARIANT MEASURES • 20 - EQUILIBRIUM STATES AND SMOOTH INVARIANT MEASURES pp 615-656 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation Select 21 - Supplement: DYNAMICAL SYSTEMS WITH NONUNIFORMLY HYPERBOLIC BEHAVIOR BY ANATOLE KATOK AND LEONARDO MENDOZA • 21 - Supplement: DYNAMICAL SYSTEMS WITH NONUNIFORMLY HYPERBOLIC BEHAVIOR BY ANATOLE KATOK AND LEONARDO MENDOZA pp 657-700 By Leonardo Mendoza Get access Check if you have access via personal or institutional login Log in Register Export citation Select Appendix: BACKGROUND MATERIAL Appendix: BACKGROUND MATERIAL pp 701-740 ■ Get access Check if you have access via personal or institutional login Log in Register Export citation

Page 1 of 2

First

- « Prev •
- [1](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf?pageNum=1) •
- [2](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf?pageNum=2) •
- [Next »](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf?pageNum=2) •
- [Last](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf?pageNum=2) •

# <span id="page-27-0"></span>**Metrics**

## **Altmetric attention score**

## **Full text views**

[Full text views help](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf)

![](_page_27_Picture_9.jpeg)

Full text views reflects the number of PDF downloads, PDFs sent to Google Drive, Dropbox and Kindle and HTML full text views for chapters in this book.

Total number of HTML views: 0 Total number of PDF views: 0 \* Loading metrics...

### **Book summary page views**

[Book summary page views help](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf)

![](_page_28_Picture_4.jpeg)

# [Close Book summary page views help](file:///map-vepfs/shuang/EDR/PDF/266-recuVIEEFtpBQb/related-1.pdf)

Book summary views reflect the number of visits to the book and chapter landing pages.

Total views: 0 \* Loading metrics... \* Views captured on Cambridge Core between #date#. This data will be updated every 24 hours.

Usage data cannot currently be displayed.

### <span id="page-29-0"></span>**Accessibility standard: Unknown**

Accessibility compliance for the PDF of this book is currently unknown and may be updated in the future.

![](_page_29_Picture_4.jpeg)

# **Our Site**

- [Accessibility](file:///core/accessibility) •
- [Contact & Help](file:///core/help/FAQs) •
- [Legal Notices](file:///core/legal-notices/terms) •
- Cookie Settings •

# **Quick Links**

- [Cambridge Core](https://www.cambridge.org/core/) •
- [Cambridge Open Engage](https://www.cambridge.org/engage/coe/public-dashboard) •
- [Cambridge Aspire website](https://www.cambridge.org/highereducation/) •

# **Our Products**

- [Journals](https://www.cambridge.org/core/publications/journals) •
- [Books](https://www.cambridge.org/core/search?aggs%5BproductTypes%5D%5Bfilters%5D=BOOK) •
- [Elements](https://www.cambridge.org/core/publications/elements) •
- [Textbooks](https://www.cambridge.org/highereducation/search?aggs=%24productTypes%24BOOK%3Atrue%3B%3B) •
- [Courseware](https://www.cambridge.org/highereducation/search?aggs=%24productTypes%24COURSEWARE%3Atrue%3B%3B) •

# **Join us online**

| •        |  |  |
|----------|--|--|
| Location |  |  |
| GBR      |  |  |
|          |  |  |

Please choose a valid location.

![](_page_29_Picture_23.jpeg)

- [Rights & Permissions](https://www.cambridge.org/about-us/rights-permissions/) •
- [Copyright](https://www.cambridge.org/about-us/legal-notices/copyright/) •

- Privacy NoticeTerms of UseCookies Policy

Cambridge University Press 2025

Cancel Confirm X