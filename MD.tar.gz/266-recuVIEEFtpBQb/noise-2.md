### <span id="page-0-1"></span>[Skip to main content](#page-0-0)

#### Advertisement

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/book/10.1007/978-0-85729-021-2) [Springer Nature Link](https://link.springer.com)

[Menu](#page-11-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-11-1)

[Cart](https://order.springer.com/public/cart)

- [Home](file:///) 1.
- Textbook 2.

![](_page_0_Picture_9.jpeg)

# **Ergodic Theory**

with a view towards Number Theory

- Textbook •
- © 2011 •

[Accessibility Information](#page-7-0)

# <span id="page-0-0"></span>**Overview**

Authors:

[Manfred Einsiedler](#page-1-0) [0](#page-1-1) , •

- [Thomas Ward](#page-1-2) [1](#page-1-3) •
- <span id="page-1-1"></span>Manfred Einsiedler 1.
  - Departement Mathematik, ETH Zürich Departement Mathematik, Zürich, Switzerland 1.

### <span id="page-1-0"></span>[View author publications](file:///search?dc.creator=Manfred+Einsiedler&sortBy=newestFirst)

Search author on: [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Manfred+Einsiedler) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Manfred+Einsiedler%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

- <span id="page-1-3"></span>Thomas Ward 2.
  - School of Mathematics, University of East Anglia School of Mathematics, Norwich, United Kingdom 1.

#### <span id="page-1-2"></span>[View author publications](file:///search?dc.creator=Thomas+Ward&sortBy=newestFirst)

Search author on: [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Thomas+Ward) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Thomas+Ward%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

- With a rigorous development of basic ergodic theory and homogeneous dynamics, no background in Ergodic theory or Lie theory is assumed Offers both complete and motivated treatments of Weyl and Szemeredi theorems Provides a number of exercises and hints to problems •
- Includes supplementary material: [sn.pub/extras](https://extras.springer.com/?query=978-0-85729-020-5) •

Part of the book series: [Graduate Texts in Mathematics](https://link.springer.com/series/136) (GTM, volume 259)

- 129k Accesses •
- 359 Citations •
- 25 [Altmetric](https://link.altmetric.com/details/12925507) •

 This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-85729-021-2) to check access.

# **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-85729-021-2)

**eBook EUR 50.28** 

Price includes VAT (China (P.R.))

ebook

10.1007/978-0-85729-021-2

978-0-85729-021-2

Ergodic Theory

56fcbf2c684797ffb3ff2cc5260846f223738125d43946a30ea72834ad95c1fcc9064b1662504e0651bcd1a99f18ab22eee6f7fc9876be1df2cccd93276fbad5

- Available as PDF
- Read on any device
- Instant download
- Own it forever

Buy eBook

#### **Softcover Book EUR 64.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-0-85729-021-2

978-1-4471-2591-4

Ergodic Theory

121054691845179a301965dfa5b9ec28f4b76cc193fd954f8a69a4a9a0e8827642cc77711d845c77fa52ecc222c12013b01bd85b53a3294a5924b46e9fcee89a

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

### **Hardcover Book EUR 59.95**

Price excludes VAT (China (P.R.))

| book                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/978-0-85729-021-2                                                                                                        |
| 978-0-85729-020-5                                                                                                                |
| Ergodic Theory                                                                                                                   |
| 0da5a1be07b18ac44ff2b69e1e210bf260cfc2015d5f80c0428f98cd4edcfd16df10cb69cfd53b5346fa2b5be54b6fe2dba0d41fabd9200d8023a2a15793b45c |

- Durable hardcover edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Hardcover Book

Tax calculation will be finalised at checkout

# **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-0-85729-021-2) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# **About this book**

This text is a rigorous introduction to ergodic theory, developing the machinery of conditional measures and expectations, mixing, and recurrence.

Beginning by developing the basics of ergodic theory and progressing to describe some recent applications to number theory, this book goes beyond the standard texts in this topic. Applications include Weyl's polynomial equidistribution theorem, the ergodic proof of Szemeredi's theorem, the connection between the continued fraction map and the modular surface, and a proof of the equidistribution of horocycle orbits.

Ergodic Theory with a view towards Number Theory will appeal to mathematicians with some standard background in measure theory and functional analysis. No background in ergodic theory or Lie theory is assumed, and a number of exercises and hints to problems are included, making this the perfect companion for graduate students and researchers in ergodic theory, homogenous dynamics or number theory.

### **Similar content being viewed by others**

![](_page_4_Picture_1.jpeg)

**[Modern Ergodic Theory: From a Physics Hypothesis to a](https://link.springer.com/10.1007/978-3-319-70658-0_31-1?fromPaywallRec=true) [Mathematical Theory with Transformative Interdisciplinary](https://link.springer.com/10.1007/978-3-319-70658-0_31-1?fromPaywallRec=true) [Impact](https://link.springer.com/10.1007/978-3-319-70658-0_31-1?fromPaywallRec=true)** 

Chapter © 2019

![](_page_4_Picture_4.jpeg)

**[Modern Ergodic Theory: From a Physics Hypothesis to a](https://link.springer.com/10.1007/978-3-319-57072-3_31?fromPaywallRec=true) [Mathematical Theory with Transformative Interdisciplinary](https://link.springer.com/10.1007/978-3-319-57072-3_31?fromPaywallRec=true) [Impact](https://link.springer.com/10.1007/978-3-319-57072-3_31?fromPaywallRec=true)** 

Chapter © 2021

![](_page_4_Picture_7.jpeg)

**[Couplings via Comparison Principle and Exponential](https://link.springer.com/10.1007/s00220-020-03834-w?fromPaywallRec=true) [Ergodicity of SPDEs in the Hypoelliptic Setting](https://link.springer.com/10.1007/s00220-020-03834-w?fromPaywallRec=true)** 

Article Open access 29 September 2020

# **Explore related subjects**

Discover the latest articles, books and news in related subjects.

- [Dynamical Systems](file:///subjects/dynamical-systems) •
- [Measure and Integration](file:///subjects/measure-and-integration) •
- [Number Theory](file:///subjects/number-theory) •

Search within this book

### Search

| 978-0-85729-021-2 |
|-------------------|
| Chapter           |
| Chapter           |
| true              |

# **Table of contents (11 chapters)**

#### **Front Matter** 1.

Pages I-XVII [Download chapter PDF](file:///content/pdf/bfm:978-0-85729-021-2/1) 

2.

### **[Motivation](file:///chapter/10.1007/978-0-85729-021-2_1)**

Manfred Einsiedler, Thomas Ward Pages 1-12 ◦

3.

# **[Ergodicity, Recurrence and Mixing](file:///chapter/10.1007/978-0-85729-021-2_2)**

Manfred Einsiedler, Thomas Ward Pages 13-68 ◦

4.

### **[Continued Fractions](file:///chapter/10.1007/978-0-85729-021-2_3)**

Manfred Einsiedler, Thomas Ward Pages 69-95 ◦

5.

# **[Invariant Measures for Continuous Maps](file:///chapter/10.1007/978-0-85729-021-2_4)**

Manfred Einsiedler, Thomas Ward Pages 97-119 ◦

6.

# **[Conditional Measures and Algebras](file:///chapter/10.1007/978-0-85729-021-2_5)**

Manfred Einsiedler, Thomas Ward Pages 121-151 ◦

#### **[Factors and Joinings](file:///chapter/10.1007/978-0-85729-021-2_6)** 7.

Manfred Einsiedler, Thomas Ward Pages 153-169 ◦

8.

### **[Furstenberg's Proof of Szemerédi's Theorem](file:///chapter/10.1007/978-0-85729-021-2_7)**

Manfred Einsiedler, Thomas Ward Pages 171-230 ◦

9.

### **[Actions of Locally Compact Groups](file:///chapter/10.1007/978-0-85729-021-2_8)**

Manfred Einsiedler, Thomas Ward Pages 231-275 ◦

10.

### **[Geodesic Flow on Quotients of the Hyperbolic Plane](file:///chapter/10.1007/978-0-85729-021-2_9)**

Manfred Einsiedler, Thomas Ward Pages 277-330 ◦

11.

### **[Nilrotation](file:///chapter/10.1007/978-0-85729-021-2_10)**

Manfred Einsiedler, Thomas Ward Pages 331-345 ◦

12.

### **[More Dynamics on Quotients of the Hyperbolic Plane](file:///chapter/10.1007/978-0-85729-021-2_11)**

Manfred Einsiedler, Thomas Ward Pages 347-402 ◦

13.

### **Back Matter**

Pages 403-481 [Download chapter PDF](file:///content/pdf/bbm:978-0-85729-021-2/1) 

[Back to top](#page-0-1)

# **Reviews**

From the reviews:

"The book is an introduction to ergodic theory and dynamical systems. … The book is intended for graduate students and researchers with some background in measure theory and functional analysis. Definitely, it is a book of great interest for researchers in ergodic theory, homogeneous dynamics or number theory." (Antonio Díaz-Cano Ocaña, The European Mathematical Society, January, 2014)

"A book with a wider perspective on ergodic theory, and yet with a focus on the interaction with number theory, remained a glaring need in the overall

context of the development of the subject. … The book under review goes a long way in fulfilling this need. … it covers a good deal of conventional ground in ergodic theory … . a very welcome addition and would no doubt inspire interest in the area among researchers as well as students, and cater to it successfully." (S. G. Dani, Ergodic Theory and Dynamical Systems, Vol. 32 (3), June, 2012)

"The book under review is an introductory textbook on ergodic theory, written with applications to number theory in mind. … it aims both to provide the reader with a solid comprehensive background in the main results of ergodic theory, and of reaching nontrivial applications to number theory. … The book should also be very appealing to more advanced readers already conducting research in representation theory or number theory, who are interested in understanding the basis of the recent interaction with ergodic theory." (Barak Weiss, Jahresbericht der Deutschen Mathematiker-Vereinigung, Vol. 114, 2012)

"This introductory book, which goes beyond the standard texts and allows the reader to get a glimpse of modern developments, is a timely and welcome addition to the existing and ever-growing ergodic literature. … This book is highly recommended to graduate students and indeed to anyone who is interested in acquiring a better understanding of contemporarydevelopments in mathematics." (Vitaly Bergelson, Mathematical Reviews, Issue 2012 d)

"The book contains a presentation of the ergodic theory field, focusing mainly on results applicable to number theory. … of interest for researchers, specialists, professors and students that work within some other areas than precisely the ergodic theory. … 'Ergodic Theory. With a view toward number theory' is now an indispensable reference in the domain and offers important instruments of research for other theoretical fields." (Adrian Atanasiu, Zentralblatt MATH, Vol. 1206, 2011)

# **Authors and Affiliations**

**Departement Mathematik, ETH Zürich Departement Mathematik, Zürich, Switzerland**  •

Manfred Einsiedler

**School of Mathematics, University of East Anglia School of Mathematics, Norwich, United Kingdom**  •

Thomas Ward

# <span id="page-7-0"></span>**Accessibility Information**

Accessibility information for this book is coming soon. We're working to make it available as quickly as possible. Thank you for your patience.

# **Bibliographic Information**

Book Title: Ergodic Theory •

Book Subtitle: with a view towards Number Theory •

Authors: Manfred Einsiedler, Thomas Ward •

Series Title: [Graduate Texts in Mathematics](https://link.springer.com/series/136) •

DOI: https://doi.org/10.1007/978-0-85729-021-2 •

Publisher: Springer London •

eBook Packages: [Mathematics and Statistics,](file:///search?facet-content-type=%22Book%22&package=11649&facet-start-year=2011&facet-end-year=2011) [Mathematics and Statistics](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2011&facet-end-year=2011) [\(R0\)](file:///search?facet-content-type=%22Book%22&package=43713&facet-start-year=2011&facet-end-year=2011) •

Copyright Information: Springer-Verlag London Limited 2011 •

Hardcover ISBN: 978-0-85729-020-5Published: 23 September 2010 •

Softcover ISBN: 978-1-4471-2591-4Published: 05 November 2012 •

eBook ISBN: 978-0-85729-021-2Published: 11 September 2010 •

Series ISSN: 0072-5285 •

Series E-ISSN: 2197-5612 •

Edition Number: 1 •

Number of Pages: XVII, 481 •

Topics: [Dynamical Systems and Ergodic Theory](https://link.springer.com/search?facet-sub-discipline=Dynamical%20Systems%20and%20Ergodic%20Theory&facet-content-type=Book), [Number Theory,](https://link.springer.com/search?facet-sub-discipline=Number%20Theory&facet-content-type=Book) [Measure and Integration](https://link.springer.com/search?facet-sub-discipline=Measure%20and%20Integration&facet-content-type=Book) •

# **Keywords**

- [Ergodic theory](file:///search?query=Ergodic%20theory&facet-discipline=%22Mathematics%22) •
- [Homogenous spaces](file:///search?query=Homogenous%20spaces&facet-discipline=%22Mathematics%22) •
- [Measure rigidity](file:///search?query=Measure%20rigidity&facet-discipline=%22Mathematics%22) •
- [Number theory](file:///search?query=Number%20theory&facet-discipline=%22Mathematics%22) •

# **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

[Back to top](#page-0-1)

# **Access this book**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fbook%2F10.1007%2F978-0-85729-021-2)

**eBook EUR 50.28** 

Price includes VAT (China (P.R.))

ebook

10.1007/978-0-85729-021-2

978-0-85729-021-2

Ergodic Theory

56fcbf2c684797ffb3ff2cc5260846f223738125d43946a30ea72834ad95c1fcc9064b1662504e0651bcd1a99f18ab22eee6f7fc9876be1df2cccd93276fbad5

- Available as PDF
- Read on any device
- Instant download
- Own it forever

Buy eBook

#### **Softcover Book EUR 64.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-0-85729-021-2

978-1-4471-2591-4

Ergodic Theory

121054691845179a301965dfa5b9ec28f4b76cc193fd954f8a69a4a9a0e8827642cc77711d845c77fa52ecc222c12013b01bd85b53a3294a5924b46e9fcee89a

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

### **Hardcover Book EUR 59.95**

Price excludes VAT (China (P.R.))

| book                                                                                                                             |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/978-0-85729-021-2                                                                                                        |
| 978-0-85729-020-5                                                                                                                |
| Ergodic Theory                                                                                                                   |
| 0da5a1be07b18ac44ff2b69e1e210bf260cfc2015d5f80c0428f98cd4edcfd16df10cb69cfd53b5346fa2b5be54b6fe2dba0d41fabd9200d8023a2a15793b45c |

- Durable hardcover edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Hardcover Book

Tax calculation will be finalised at checkout

# **Other ways to access**

[Licence this eBook for your library](https://single-ebooks.springernature.com/search?query=10.1007/978-0-85729-021-2) 

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# <span id="page-11-1"></span>**Search**

Search by keyword or author

Search

# <span id="page-11-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/) •
- [Publish with us](https://www.springernature.com/gp/authors)  •
- [Track your research](https://link.springernature.com/home/) •

### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature