# Complexity of Perfect Zero-Knowledge

Lance Fortnow MIT Math Dept.<sup>y</sup> Cambridge, MA 02139

### Abstract

A Perfect Zero-Know ledge interactive proof system convinces a verier that a string is in a language without revealing any additional knowledge in an information-theoretic sense. We show that for any language that has a perfect zero-knowledge proof system, its complement has a short interactive protocol. This result implies that there are not any perfect zero-knowledge protocols for NP-complete languages unless the polynomial time hierarchy collapses. This paper demonstrates that knowledge complexity can be used to show that a language is easy to prove.

Interactive protocols and zero-knowledge, as described by Goldwasser, Micali and Racko [GMR], have in recent years proven themselves to be important models of computation in both complexity and cryptography.

Interactive proof systems are a randomized extension to NP which give us a greater understanding of what an innitely powerful machine can prove to a probabilistic polynomial one. Recent results about interactive protocols have given us an idea of what languages may be eciently provable in this way.

Zero-knowledge interactive protocols give us a good way to determine which languages can be eciently proven without giving away any details of the proof. This model consists of an innitely powerful prover trying to convince a polynomial time verier that a string is in a certain language. Zero-knowledge requires that the verier not learn any information useful to him as a polytime machine. Goldreich, Micali and Wigderson [GMW] show that if one way functions exist then all languages in NP have zero-knowledge proofs. However, their proof relies on the fact that the verier has limited power and is unable to invert these one-way functions. A stronger notion is that of perfect zero-knowledge (PZK) which requires that the verier not learn any additional information no matter how powerful he may be. There are many languages not known to be in BPP or NP\co-NP, such as graph isomorphism [GMW], which have perfect zero-knowledge proof systems.

Our main theorem says that for any language which has a perfect zero-knowledge protocol, its complement has a single round interactive protocol. Thus PZKco-AM, where AM is the class accepted by one-round Arthur-Merlin games as described by Babai [B]. Our result holds in the weaker case where we only require that the verier which follows the protocol will not learn any additional information.

Combining our main theorem with a result of Boppana, Hastad and Zachos [BHZ], we get that NP-complete languages do not have perfect zero-knowledge proof systems unless the polynomial time hierarchy collapses to the second level. Thus it is unlikely that the result of [GMW] that NP has zero-knowledge proof systems will extend to perfect zero-knowledge.

Our proof makes use of an approximate upper bound protocol that is of independent interest and that may be useful in completely dierent contexts. This is in contrast to an approximate lower bound protocol used in [S, B, GS].

The results in this paper do not depend on any unproven cryptographic assumptions.

The author is supported in part by an Oce of Naval Research fellowship, NSF Grant DCR-8602062 and Air Force Grant AFOSR-86-0078.

yMuch of this work was done while the author was at the University of California at Berkeley.

Let P , the prover, be a probabilistic innite power Turing machine and V , the verier, be a probabilistic polynomial time machine that share the same input and can communicate with each other. Let P\$V denote the interaction between P and V . P\$V (x) accepts if after the interaction, V accepts. V 's view of the conversation between P and V consists of all the messages between P and V and the random coin tosses of V .

P and V form an interactive protocol for a language L if:

- 1. If <sup>x</sup> <sup>2</sup> L then Pr(P\$V (x) accepts) <sup>2</sup>
- 2. If <sup>x</sup> <sup>62</sup> L then 8P Pr(P \$V (x) accepts) <sup>1</sup>

A round of an interactive protocol is a message from the verier to the prover followed by a message from the prover to the verier. AM is the class of languages accepted by bounded round interactive protocols.

Messages in a conversation will be described by

$$\beta_1, \alpha_1, \beta_2, \ldots, \beta_k, \alpha_k$$

where the <sup>i</sup> are messages from the prover to the verier at round i and the i are messages from the verier to the prover.

r will be used for the random coin tosses of the verier.

Formally, we think of P as a function from the input and the conversation so far to a probability distribution of messages. We put no restrictions on the complexity of this function other than requiring the lengths of the messages to be bounded in size by a polynomial in the size of the input. This paper will use the informal term, probabilistic innite power, to describe the complexity of the prover.

Let IP be the class of all languages that are eciently provable, i.e., accepted by an interactive protocol.

P : These are computations performed by the prover that can not be seen by the verier. The prover has probabilistic innite time to make these computations.

P!V : This is a message from the prover to the verier.

The notation for describing protocols follows:

V : These are computations performed by the verier that cannot be seen by the prover. These computations must be performed in probabilistic polynomial time.

V!P : This is a message from the verier to the prover.

Let M be a simulator for a view of the conversation between P and V . M is a probabilistic polynomial time machine that will output a conversation between P and V including the random coin tosses of V . Thus each run of M will produce:

$$r, \beta_1, \alpha_1, \beta_2, \ldots, \beta_k, \alpha_k$$

Let P\$V [x] denote the distribution of views of conversations between P and V . M[x] denotes the distribution of views of conversations created by running M on x.

Let A[x] and B[x] be two distributions of strings. A[x] and B[x] are statistical ly close if for any subset of strings S,

$$\left| \sum_{y \in S} \Pr_{A[x]}(y) - \sum_{y \in S} \Pr_{B[x]}(y) \right| < \frac{1}{q(|x|)}$$

for all polynomials q with jxj large enough. Let J be a probabilistic polynomial time machine that outputs either 0 or 1. A[x] and B[x] are polytime indistinguishable if for any J ,

$$|\Pr(J(A[x]) = 1) - \Pr(J(B[x]) = 1)| < \frac{1}{r(|x|)}$$

for all polynomials <sup>r</sup> with jxj large enough. J (A[x]) is the output of J when run on a string chosen from A[x]. Note that if A[x] and B[x] are statistically close then they are polytime indistinguishable.

P\$V is Zero-Know ledge (ZK) if for any verier V there is a MV such that (8<sup>x</sup> <sup>2</sup> L)P\$V [x] and MV [x] are polytime indistinguishable.

P\$V is Perfect Zero-Know ledge (PZK) if for any verier V there is a MV such that (8<sup>x</sup> <sup>2</sup> L)P\$V [x] = MV [x].

P\$V is Almost Perfect Zero-Know ledge (APZK) if for any verier V there is a MV such that (8<sup>x</sup> <sup>2</sup> L)P\$ V [x] and MV [x] are statistically close.

Interactive Protocols and Zero-Knowledge were introduced in [GMR]. Perfect Zero-Knowledge was described originally in [GMW]. The class AM was introduced by Babai [B] as the class of languages that have one round interactive protocols where V 's message consists exactly of his coin tosses. This was shown to be equivalent to the denition used above by [GS] and [B].

Note that ZKAPZKPZK. The inclusions are not known to be proper but this paper gives good evidence that ZK6=APZK.

The results in this paper only require a weaker version of zero-knowledge: a simulator only need exist for the given P and V and not necessarily for any V . For the rest of this paper we will assume we are in this weaker model and M <sup>=</sup> MV is the simulator for P and V .

Our result shows that for any language L with an almost perfect zero-knowledge protocol, there exists a bounded round interactive protocol for its complement L. We can then apply several earlier results about bounded round interactive protocols.

Goldwasser and Sipser [GS] have shown that for any language that has an interactive protocol in Q rounds, there is an Arthur-Merlin protocol in Q + 2 rounds for that language. Arthur-Merlin protocols are similar to interactive protocols except that the verier's messages are just random coin tosses. Babai [B] showed that any bounded round Arthur-Merlin protocol is equivalent to a one round Arthur-Merlin protocol. This is just the class AM. Babai also shows that AM N P <sup>R</sup> for a random oracle R and also that AM p 2. Sipser pointed out

Boppana, Hastad, and Zachos [BHZ] have shown that if co-NP had bounded round interactive proofs then the whole polynomial time hierarchy would be in AM implying that the polynomial time hierarchy collapses to

Subsequent to our result, Aiello and Hastad [AH] have shown, using similar techniques, that any almost perfect zero-knowledge protocol can be done by a bounded round interactive protocol. This result is a nice complement to our result which describes the complexity of the complement of perfect zero-knowledge languages. Combining the two results we have that any language with a perfect zero-knowledge proof system is in non-uniform NP\co-NP.

Brassard and Crepeau [BC] have shown perfect zero-knowledge for SAT using a dierent model for interactive protocols where the prover is a polynomial time machine that knows a satisfying assignment. Our result about perfect zero-knowledge relies on the ability of the prover to have innite power and thus does not apply to Brassard and Crepeau's model.

# 4 Showing Sets are Large and Small

In this paper, we will need protocols to show sets are large and small. We do both using Carter-Wegman Universal Hash Functions [CW].

Let = f0; 1g. Suppose <sup>S</sup> <sup>N</sup> ; 0<sup>N</sup> 62 S. Let F be a random binary b - <sup>N</sup> matrix. Let f : <sup>N</sup> ! <sup>b</sup> the function dened by f (x) = F x using regular matrix multiplication modulo two. We can think of f in terms of linear algebra over the eld of two elements. f is distributed evenly over all possible linear functions from n-dimensional space to b-dimensional space.

Lemma 1 (Vector Independence) Suppose x1; x2; : : : ; xk <sup>2</sup> <sup>N</sup> are linearly independent vectors over the eld of two elements. Then f (x1 ); f (x2); : : : ; f (xk ) are independently and uniformly distributed over <sup>b</sup>

Proof Since x1; x2; : : : ; xk are linearly independent, we can extend to a basis. Pick bk+1; bk+2; : : : ; bN to complete the basis. Let T be the transformation matrix from this new basis to the canonical basis of <sup>N</sup>

B = F T describes the function from the new basis to the canonical basis of <sup>b</sup> . Since T is an invertible matrix, there is a one-to-one correspondence between B and F . Thus B is distributed uniformly over all possible binary b -<sup>N</sup> matrices. f (xj ) is just the j-th column of B. Thus each f (xj ) is independently distributed over <sup>b</sup>

If jS j 2<sup>b</sup> then fS is likely to be onto most of <sup>b</sup> and most elements of <sup>b</sup> will have many preimages.

If jS j 2<sup>b</sup> then the range of fS is a small subset of <sup>b</sup> and most elements of fS (S) will have only one inverse

If <sup>S</sup> is recognizable in polynomial time we use the following protocol to show <sup>S</sup> is large:

<sup>V</sup> : Pick ` independent random hash functions f1; : : : ; f` : <sup>N</sup> ! <sup>b</sup> and ` points z1; : : : ; z`2 <sup>2</sup> <sup>b</sup>

$$V \rightarrow P: f_1, \ldots, f_\ell, z_1, \ldots, z_{\ell^2}$$

P!V : <sup>x</sup>

V : Accept if <sup>x</sup> 2 S and fi(x) = zj for some i; j, 1 <sup>i</sup> ` and 1 j `

If <sup>S</sup> is much smaller than 2<sup>b</sup> then it is unlikely for there to be any <sup>x</sup> such that fi(x) = zj . However if <sup>S</sup> is large then there are likely to be many <sup>x</sup> so a prover should have no trouble exhibiting such an <sup>x</sup> that V can verify in polynomial time.

Lemma 2 (Lower Bound) [GS] Using the above protocol with a given N; b; d > 0 and ` > maxfb; 8g

- 1. If jS j 2<sup>b</sup> then Pr(P\$V accepts) 1 2 `
- 2. If jS j <sup>2</sup> d then Pr(P \$V accepts) ` d for any P

### Upper Bound Protocol

If V has a random element <sup>s</sup> 2 S that is not known by P then the following protocol is used to show <sup>S</sup> is

V : Pick a random N b matrix F

$$V \rightarrow P \colon F, f(s) = Fs$$

P!V : <sup>s</sup>

If <sup>S</sup> is small then <sup>s</sup> is likely to be the only element of <sup>S</sup> that maps to f (s); thus P can nd s. If <sup>S</sup> is large then many elements of <sup>S</sup> map to f (s), and because <sup>s</sup> is a random element of S, the prover will have no way of determining which element of <sup>S</sup> V has.

Lemma 3 (Upper Bound) Using the above protocol with a given N; b > 0 and d > 7

- 1. If jS j <sup>2</sup><sup>b</sup> d then Pr(P\$V accepts) 1 <sup>1</sup> d
- 2. If jS j <sup>&</sup>gt; 8d2<sup>b</sup> then Pr(P \$V accepts) <sup>1</sup> d for any P

Proof Let A be the random variable equal to the number of <sup>x</sup> 6= <sup>s</sup> in <sup>S</sup> such that f (x) = f (s). Let <sup>S</sup><sup>0</sup> = S fsg. Let Ax be the indicator random variable equal to one if f (x) = f (s), zero otherwise. Then

$$E(A) = E(\sum_{x \in \mathcal{S}'} A_x) = \sum_{x \in \mathcal{S}'} E(A_x) = \sum_{x \in \mathcal{S}'} 2^{-b} = \frac{|\mathcal{S}| - 1}{2^b}$$

If jS j <sup>2</sup> then E(A) <sup>1</sup> d . If f (s) has only <sup>s</sup> as an inverse in jS j then P with his innite power will be able to determine s. Thus Pr(P\$V rejects) Pr(A 1) E(A) <sup>1</sup> d since A is an integral random variable.

Suppose jS j <sup>&</sup>gt; 8d2<sup>b</sup> . We can assume jS j = 8d2<sup>b</sup> + 1 without increasing the probability of acceptance. Then E(A) = 8d. Since P has no idea what s V has, P can only have a <sup>1</sup> A+1 probability of predicting the <sup>s</sup> that <sup>V</sup> has. We will show that there is a high probability that A is large. To show this we look at the variance of A.

Given x; y; s all distinct and y 6= xs then x; y; s are linearly independent. Then by the Vector Independence Lemma f (x); f (y); f (s) are independently distributed over <sup>b</sup> . It then follows that Ax and Ay are independent

The covariance of any two indicator random variables is never greater then the expected value of one of them.

$$VAR(A) = \sum_{x,y \in \mathcal{S}'} COV(A_x, A_y) = \sum_{x \in \mathcal{S}'} (COV(A_x, A_x) + COV(A_x, A_{x \oplus s})) \le \sum_{x \in \mathcal{S}'} 2E(A_x) \le 16d$$

It's possible that <sup>x</sup> <sup>s</sup> 62 S but this would only decrease the variance. Using Chebyshev's inequality we get:

$$\Pr(A < 2d) \le \Pr(|A - 8d| \ge 6d) \le \frac{VAR(A)}{36d^2} \le \frac{16d}{36d^2} \le \frac{1}{2d}$$

So with probability at most <sup>1</sup> 2d <sup>A</sup> is small enough that <sup>P</sup> can determine <sup>s</sup> easily; otherwise P 2d chance of guessing s, so in total P has at most a <sup>1</sup> d chance of determining s. <sup>2</sup>

### Comparison Protocol

Suppose we had two sets S1; S2 <sup>N</sup> and wanted to show that jS1j jS2j. If S1 is polynomial time testable and V has a random element s2 of S2, then the following is a protocol to show jS1j jS2j:

P!V : b N

P!V : Use lower bound protocol on S1 with b <sup>=</sup> b ; ` = 8nN

P!V : Use upper bound protocol on S2 with b <sup>=</sup> b <sup>3</sup>n; s <sup>=</sup> s2

Lemma 4 (Comparison) Using the above protocol

- 1. If jS1j 24n+1jS2j then Pr(P\$V accepts) 1 21n
- 2. If jS1j 2n4 jS2j then Pr(P \$V accepts) n3N3 29<sup>n</sup> for any P

Proof Let d = 2<sup>n</sup>

- 1. Pick b = blog jS1jc. Then each protocol accepts with probability 1 2n , so that both will accept with probability 1 21n by the upper and lower bound lemmas.
- 2. There are two cases depending on what b P chooses
  - (a) If b dlog jS1je <sup>n</sup> then by the lower bound lemma the probability of V accepting is n3N3 29<sup>n</sup>
  - (b) If b <sup>0</sup> <sup>&</sup>lt; dlog jS1je + <sup>n</sup> then by the hypothesis b 3<sup>n</sup> < blog jS2jc <sup>n</sup> 3 and by the upper bound lemma the probability of V accepting is 2n

Using Carter-Wegman Hashing to show a set is large was introduced by Sipser [S] and used extensively in [S, B, GS]. To the author's knowledge this paper is the rst use of an interactive protocol to show a set is small.

We will start with a simple version of the theorem:

Theorem 1 Let L be a language with a perfect zero-know ledge interactive protocol. Then there exists an interactive protocol accepting L.

### 5.1 Structure of Proof

We are given a prover and verier (P and V ) for the language L, and a simulator M that produces views of conversations between P and V and the random coin tosses of V . Note that one can simulate the computation of V in polynomial time, checking, for example, whether or not V accepts. On <sup>x</sup> <sup>2</sup> L, M produces a view of a conversation from exactly the same probability distribution as when P and V run on x. The key idea of the proof of the theorem is to notice what M might do on <sup>x</sup> <sup>62</sup> L. There is no requirement in the denition of perfect zero-knowledge on what M does on <sup>x</sup> <sup>62</sup> L; however there are three possibilities:

- 1. M will produce \garbage", something that clearly is not a randomly selected member of P\$V [x].
- 2. M will produce views of conversations that cause V to reject most of the time.
- 3. M will produce a simulation that looks valid and causes V to accept. It may not be possible in polynomial time to tell this view from one created by P and V when <sup>x</sup> <sup>2</sup> L. However, M must be producing views of conversations from a distribution quite dierent from the distribution of views between P and V , since in the real views V is likely to reject.

We will create a new prover and verier, P <sup>0</sup> and V <sup>0</sup> that will determine if one of the three cases occur. V <sup>0</sup> run M and get a view of a conversation between P and V and r, the random coin tosses of V . V <sup>0</sup> that this view is valid and that V halts accepting. If the view fails this test then it falls in cases 1 or 2 so V <sup>0</sup> knows that <sup>x</sup> <sup>62</sup> L and V <sup>0</sup> accepts. Otherwise V <sup>0</sup> will send to P <sup>0</sup> some initial segment of the conversation. P <sup>0</sup> will then convince V <sup>0</sup> that the conversation came from a bad distribution by \predicting" <sup>r</sup> better than P <sup>0</sup> have done from a good distribution.

## 5.2 An Example: Graph Isomorphism

Graph isomorphism is a well studied problem that is clearly in NP but not known to be in co-NP or BPP. A perfect zero-knowledge proof of graph isomorphism was presented in [GMW]. We will show how our theorem converts this perfect zero-knowledge protocol to an interactive protocol for graph non-isomorphism. This protocol for graph non-isomorphism is identical to the graph non-isomorphism protocol described in [GMW]; our proof, however, shows that the similarity between the two protocols is not coincidental.

Let : f1; : : : ; ng ! f1; : : : ; ng be a permutation of the vertices of a graph. For a graph G = (V; E) let ((v1); (v2)) <sup>2</sup> (E) , (v1; v2) <sup>2</sup> E. Let (G) = (V; (E)).

Two graphs G1 and G2 are isomorphic if there exists <sup>a</sup> permutation such that (G1) <sup>=</sup> G2. <sup>A</sup> perfect zero-knowledge protocol for graph isomorphism suggested by [GMW] works as follows:

P : Generate random permutation and computes G = (G1)

P!V : G

V!P : i = 1 or 2 chosen at random

P!V : 0 chosen at random such that 0 (Gi) = G

If G1 = G2 then G will be a permutation of both G1 and G2 and P will always be able to nd a 0 . If G1 6= G2 then G cannot be a permutation of both G1 and G2, so at least half of the time V will choose an i such that no 0 exists. Thus we have an interactive protocol for graph isomorphism. This protocol also is perfect zero-knowledge.

The simulator M works as follows:

M generates and i at random and computes G = (Gi), then outputs the following view of a conversation:

r: i

P!V : G

V!P : i

P!V :

It is easy to verify that when G1 = G2, M produces exactly the same distribution of views of conversations as P and V . Notice what happens when G1 6= G2. The output of M always causes V to accept. Thus when G1 6= G2, M must produce views of conversations from a very dierent distribution from what P and V produce. In fact whenever G1 6= G2, one can always predict <sup>r</sup> <sup>=</sup> i from the G produced by M. This leads to a new interactive protocol between a new prover and verier, P <sup>0</sup> and V <sup>0</sup> , for graph non-isomorphism as follows:

```
V 0
      : Generate  and i at random and compute G = (Gi)
V 0!P 0
      : G
P 0!V 0
      : i
```

## 5.3 The Protocol for L

We are given a prover and verier, P and V for a language L and a simulator M that exactly simulates views of conversations between P and V when <sup>x</sup> <sup>2</sup> L. Let <sup>n</sup> = jxj and let k be the number of rounds of the protocol which is bounded by a polynomial in n. We can decrease the probability of error in the protocol between P and V to 2nt for any constant t by the standard trick of running the protocol several times in parallel and having V accept if the majority of individual protocols accept. This new protocol is still perfect zero-knowledge|we just run the simulator in parallel. Note that we make use of the fact that we only need a simulator for the real verier V . In general, it is not known whether perfect zero-knowledge protocols remain perfect zero-knowledge when run in parallel.

- 1. If <sup>x</sup> <sup>2</sup> L then Pr(P\$V (x) accepts) 1 26kn
- 2. If <sup>x</sup> <sup>62</sup> L then 8P Pr(P \$V (x) accepts) 26kn

For the sake of the comparison protocol, let us require that V immediately rejects if all its coin tosses are zero. Since this will happen with an exponentially small probability it will not aect the correctness of the protocol. The protocol remains perfect zero-knowledge by having the simulator output no conversation if the verier's

A protocol between a new prover and verier, P <sup>0</sup> and V <sup>0</sup>

V <sup>0</sup> : Run M and get r; 1; 1; : : : ; k; k. V <sup>0</sup> now checks two things:

- 1. Check that the conversation is valid, i.e., that r; 1; : : : ; k will cause V to say 1; : : : ; k.
- 2. Check that the conversation causes V to accept.

If either of these tests fail then V <sup>0</sup> can be very sure that <sup>x</sup> <sup>62</sup> L so V <sup>0</sup> quits now and accepts. Otherwise V <sup>0</sup>

, works as follows:

```
Let j = 1.
```

probability of the comparison protocol accepting.

```
V 0!P 0
        : j ; j
```

P 0!V <sup>0</sup> : Look at the sets R1 and R2 as dened below. If jR1j <sup>2</sup>4n+1jR2j then use the comparison protocol described in section 4 to show jR1j jR2j. Otherwise let j = j + 1. If j k tell V <sup>0</sup> ROUND, otherwise GIVE UP.

R1 can be thought of as all the possible random strings of V after round j of the protocol. R2 are the possible random strings of V generated by M. More formally:

```
Let R be the set of all possible coin tosses of V .
Let R1 = fR 2 RjR and 1; : : : ; j cause V to say 1; : : : ; jg.
Let R2 = fR 2 RjM can output R; 1; 1; : : : ; j ; j part of a valid, accepting conversationg
```

Note that R2 R1 and if <sup>x</sup> <sup>2</sup> L then R2 R1. Also note that R1 is independent of j . R1 is polynomial time testable. If <sup>x</sup> <sup>2</sup> L then M produces the exact distribution between P and V and thus <sup>r</sup> is a random element of R2 which P <sup>0</sup> doesn't know. In that case we have fullled the requirements of the comparison protocol. If <sup>x</sup> <sup>62</sup> L it is possible that <sup>r</sup> is not a random element of R2 but this can only increase the

## 5.4 The Protocol Constitutes an Interactive Protocol for $\bar{L}$

To show that this is an interactive protocol for  $\overline{L}$ , we must show two things:

- 1. If  $(x \in \overline{L})$  then  $P' \leftrightarrow V'(x)$  accepts with probability  $\geq \frac{2}{3}$
- 2. If  $(x \notin \overline{L})$  then  $\forall \hat{P} \ \hat{P} \leftrightarrow V'(x)$  accepts with probability  $\leq \frac{1}{3}$

We will prove the second statement first since it is the easier of the two to prove.

- 2. Suppose  $x \in L$ . Then M will produce views of conversations from exactly the same distribution as P and V. Thus every conversation produced by M will be valid. Assume a prover  $\hat{P}$  is able to convince V' to accept with probability  $\geq \frac{1}{3}$ . There may be an exponentially small chance that V will reject in this conversation and this will cause V' to accept. If  $|\mathcal{R}_1| \leq 2^{n-4} |\mathcal{R}_2|$  on any round then the comparison protocol will accept with a exponentially small probability. Thus we can assume that with probability  $> \frac{1}{4}$  that  $|\mathcal{R}_1| > 2^{n-4} |\mathcal{R}_2|$  for some round j. Since M outputs all possible conversations,  $\mathcal{R}_2$  is just the random coin tosses of V which might cause V to accept in the future. So at round j of the protocol, the probability of V's acceptance  $<\frac{|\mathcal{R}_2|}{|\mathcal{R}_1|} \leq 2^{4-n}$ . Since this happens at least a fourth of the time the probability of V's acceptance in in general is  $\leq \frac{3}{4} + 2^{4-n}$  which contradicts the fact that V will accept with probability greater than  $1 2^{-6kn}$ .
- 1. Suppose to the contrary that  $x \notin L$  and the protocol does not work. If  $|\mathcal{R}_1| < 2^{4n+1}|\mathcal{R}_2|$  then by the comparison lemma the comparison protocol will fail with at most an exponentially small probability. So  $|\mathcal{R}_1| \ge 2^{4n+1}|\mathcal{R}_2|$  at all rounds j with probability at least one fourth. We use this to derive a contradiction by demonstrating that  $P \leftrightarrow V$  is not an interactive proof system for L by presenting a prover  $P^*$  that will convince V (the original verifier) that  $x \in L$  with probability greater than  $2^{-6kn}$ .

At round j suppose the conversation so far has been  $\beta'_1, \alpha'_1, \ldots, \beta'_i$ .  $P^*$  works as follows:

 $P^*$ : Run M which outputs  $r, \beta_1, \alpha_1, \ldots, \beta_k, \alpha_k$ . Check that this is a valid accepting conversation. If not, try again. See if  $\beta_1, \alpha_1, \ldots, \beta_i = \beta'_1, \alpha'_1, \ldots, \beta'_i$ . If not, try again.

$$P^* \rightarrow V : \alpha_j$$

At round j when  $P^*$  has a conversation from M that matches the conversation so far,  $\mathcal{R}_1$  is the set of possible random coin tosses of V. When  $P^*$  says  $\alpha_j$ ,  $\mathcal{R}_2$  is the set of coin tosses of V that will still keep V heading towards an accepting path. Since  $|\mathcal{R}_2| \geq 2^{5n+1} |\mathcal{R}_1|$ , this will happen with probability  $\geq 2^{-(5n+1)}$ . So after k rounds, V will end up accepting with a probability at least  $\frac{1}{4}2^{-(5kn+k)}$  which is higher than the  $2^{-6kn}$  maximum accepting probability we assumed for V and any  $P^*$ , when  $x \notin L$ .  $\square$ 

Note that  $P^*$  may require exponential expected time to complete its part of the protocol but in our model an infinitely powerful  $P^*$  is allowed.

## 6 Extensions and Corollaries

**Theorem 2** Suppose  $P \leftrightarrow V$  is an interactive protocol for a language L and there is a probabilistic polynomial time simulator M such that M[x] is statistically close to  $P \leftrightarrow V[x]$ . Then there is a single round interactive protocol for the complement of L.

**Idea of Proof** This extends the main theorem in two ways. First, we do not require  $M[x] = P \leftrightarrow V[x]$ , just that they be statistically close. One can check the proof in the previous section and notice that, with some minor adjustments to the probabilities, statistically close is good enough.

Second, we would like to get a single round protocol for the complement of L. Notice that in the protocol given above the number of rounds is dependent on when P' decides to say STOP. To get bounded rounds we must make the following change to the protocol:

- V': Run M  $k^3$  times independently and get  $k^3$  views of conversations; check that each conversation is valid and accepting.
- $V' \rightarrow P'$ : For  $1 \leq i \leq k^3$  send the first  $i \mod k$  rounds of the ith conversation.
- $P' \rightarrow V'$ : Pick any conversation j and show  $|\mathcal{R}_1| \gg |\mathcal{R}_2|$  for the view of that conversation.

It is not hard to verify that the above proof still works for this new protocol. Once we have bounded rounds we apply the theorems of [B, GS] which imply that all bounded round protocols can be made into single round protocols.

Corollary 1 If L 2APZK then L 2AM.

Corollary 2 If L has an almost perfect zero-know ledge interactive protocol (possibly with an unbounded number of rounds) then L <sup>2</sup> (NP\co-NP)<sup>R</sup> , where R is a random oracle.

Corollary 3 If any NP-complete language has an almost perfect zero-know ledge interactive protocol then the polynomial time hierarchy col lapses to the second level.

Corollary 4 If there are one-way functions and the polynomial time hierarchy does not col lapse then NPZK; but NP6APZK, so ZK6=APZK.

# 7 Open Problems

There are several interesting problems remaining, including:

What is the relationship between PZK and APZK?

Eric Schwabe and Su-Ming Wu for their useful comments on this paper.

Proc. 17th STOC, 1985, pp. 291-304.

- Are complement of perfect or almost perfect zero-knowledge languages themselves perfect zero-knowledge in any sense?
- Are cryptographic assumptions necessary to show NP has zero-knowledge protocols? Although this paper shows that NP probably doesn't have perfect zero-knowledge proof systems, it is still conceivable that the intractability of SAT is a good enough assumption for a zero-knowledge protocol.

# 8 Acknowledgements

The author would like to express his gratitude to his advisor, Mike Sipser, for his support and encouragement. The author would also like to thank Mike, Silvio Micali, Oded Goldreich, Joan Feigenbaum, Paul Beame,

- [AGH] Aiello, W., S. Goldwasser and J. Hastad, \On the power of Interaction", Proc. 27th FOCS, 1986, pp.368-379.
- [AH] Aiello, W. and J. Hastad, \Statistical Zero-Knowledge Languages can be Recognized in Two Rounds", JCSS, to appear. Extended abstract available in Proc. 28th FOCS, 1987, pp. 439-448.
- [B] Babai, L., \Trading Group Theory for Randomness", Proc. 17th STOC, 1985, pp. 421-429.
- [BHZ] Boppana, R., J. Hastad and S. Zachos, \Does co-NP Have Short Interactive Proofs?", IPL, to appear.
- [BC] Brassard, G. and C. Crepeau, \Non-Transitive Transfer of Condence: A Perfect Zero-Knowledge Interactive Protocol for SAT and Beyond", Proc. 27th FOCS, 1986, pp. 188-195.
- [CW] Carter, J.L. and M.N. Wegman, \Universal Classes of Hash Functions", JCSS <sup>18</sup> 2, 1979, pp.143-154.
- [GMW] Goldreich, O., S. Micali and A. Wigderson, \Proofs that Yield Nothing But their Validity and a Methodology of Cryptographic Protocol Design", Proc. 27th FOCS, 1986, pp. 174-187.
- [GMR] Goldwasser, S., S. Micali and C. Racko, \The Knowledge Complexity of Interactive Proof-Systems",

- [GS] Goldwasser, S. and M. Sipser, \Private Coins versus Public Coins in Interactive Proof Systems". In S. Micali, editor, Randomness and Computation, Volume 5 of Advances in Computing Research, JAI Press, 1987. Extended Abstract available in Proc. 18th STOC, 1986, pp. 59-68.
- [S] Sipser, M., \A Complexity Theoretic Approach to Randomness", Proc. 15th STOC, 1983, pp. 330-335.