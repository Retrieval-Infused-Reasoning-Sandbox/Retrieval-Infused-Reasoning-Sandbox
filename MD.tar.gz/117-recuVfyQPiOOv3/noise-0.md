PRIMES Is in P

Author(s): Manindra Agrawal, Neeraj Kayal and Nitin Saxena

Source: Annals of Mathematics , Sep., 2004, Second Series, Vol. 160, No. 2 (Sep., 2004),

pp. 781-793

Published by: Mathematics Department, Princeton University

Stable URL:<https://www.jstor.org/stable/3597229>

# REFERENCES

Linked references are available on JSTOR for this article: [https://www.jstor.org/stable/3597229?seq=1&cid=pdf](https://www.jstor.org/stable/3597229?seq=1&cid=pdf-reference#references_tab_contents)[reference#references\\_tab\\_contents](https://www.jstor.org/stable/3597229?seq=1&cid=pdf-reference#references_tab_contents) You may need to log in to JSTOR to access the linked references.

JSTOR is a not-for-profit service that helps scholars, researchers, and students discover, use, and build upon a wide range of content in a trusted digital archive. We use information technology and tools to increase productivity and facilitate new forms of scholarship. For more information about JSTOR, please contact support@jstor.org.

Your use of the JSTOR archive indicates your acceptance of the Terms & Conditions of Use, available at https://about.jstor.org/terms

![](_page_0_Picture_10.jpeg)

is collaborating with JSTOR to digitize, preserve and extend access to Annals of Mathematics

# PRIMES is in P

By MANINDRA AGRAWAL, NEERAJ KAYAL, and NITIN SAXENA\*

## Abstract

 We present an unconditional deterministic polynomial-time algorithm that determines whether an input number is prime or composite.

#### 1. Introduction

 Prime numbers are of fundamental importance in mathematics in general, and number theory in particular. So it is of great interest to study different properties of prime numbers. Of special interest are those properties that allow one to determine efficiently if a number is prime. Such efficient tests are also useful in practice: a number of cryptographic protocols need large prime numbers.

 Let PRIMES denote the set of all prime numbers. The definition of prime numbers already gives a way of determining if a number n is in PRIMES: try dividing n by every number m < v/n-if any m divides n then it is compos ite, otherwise it is prime. This test was known since the time of the ancient Greeks-it is a specialization of the Sieve of Eratosthenes (ca. 240 BC) that generates all primes less than n. The test, however, is inefficient: it takes Q(x/n) steps to determine if n is prime. An efficient test should need only a polynomial (in the size of the input = [log ni) number of steps. A property that almost gives an efficient test is Fermat's Little Theorem: for any prime number p, and any number a not divisible by p, aP-1 = 1 (mod p). Given an a and n it can be efficiently checked if an-1 = 1 (mod n) by using repeated squaring to compute the (n - 1)th power of a. However, it is not a correct test since many composites n also satisfy it for some a's (all a's in case of Carmichael numbers [Car]). Nevertheless, Fermat's Little Theorem became the basis for many efficient primality tests.

 Since the beginning of complexity theory in the 1960s-when the notions of complexity were formalized and various complexity classes were defined-

 <sup>\*</sup>The last two authors were partially supported by MHRD grant MHRD-CSE-20010018.

 this problem (referred to as the primality testing problem) has been investi gated intensively. It is trivial to see that the problem is in the class co-NP: if n is not prime it has an easily verifiable short certificate, viz., a nontrivial factor of n. In 1974, Pratt observed that the problem is in the class NP too [Pra] (thus putting it in NP n co-NP).

 In 1975, Miller [Mil] used a property based on Fermat's Little Theorem to obtain a deterministic polynomial-time algorithm for primality testing assum ing the Extended Riemann Hypothesis (ERH). Soon afterwards, his test was modified by Rabin [Rab] to yield an unconditional but randomized polynomial time algorithm. Independently, Solovay and Strassen [SS] obtained, in 1974, a different randomized polynomial-time algorithm using the property that for a prime n, (a) = a 2 (mod n) for every a ((-) is the Jacobi symbol). Their algorithm can also be made deterministic under ERH. Since then, a number of randomized polynomial-time algorithms have been proposed for primality testing, based on many different properties.

 In 1983, Adleman, Pomerance, and Rumely achieved a major break through by giving a deterministic algorithm for primality that runs in (log n)(l1°gl°gl°gn) time (all the previous deterministic algorithms required ex ponential time). Their algorithm was (in a sense) a generalization of Miller's idea and used higher reciprocity laws. In 1986, Goldwasser and Kilian [GK] proposed a randomized algorithm based on elliptic curves running in expected polynomial-time, on almost all inputs (all inputs under a widely believed hy pothesis), that produces an easily verifiable short certificate for primality (un til then, all randomized algorithms produced certificates for compositeness only). Based on their ideas, a similar algorithm was developed by Atkin [Atk]. Adleman and Huang [AH] modified the Goldwasser-Kilian algorithm to obtain a randomized algorithm that runs in expected polynomial-time on all inputs.

 The ultimate goal of this line of research has been, of course, to obtain an unconditional deterministic polynomial-time algorithm for primality testing. Despite the impressive progress made so far, this goal has remained elusive. In this paper, we achieve this. We give a deterministic, O'(log15/2 n) time algorithm for testing if a number is prime. Heuristically, our algorithm does better: under a widely believed conjecture on the density of Sophie Germain primes (primes p such that 2p + 1 is also prime), the algorithm takes only O0 (log6 n) steps. Our algorithm is based on a generalization of Fermat's Little Theorem to polynomial rings over finite fields. Notably, the correctness proof of our algorithm requires only simple tools of algebra (except for appealing to a sieve theory result on the density of primes p with p - 1 having a large prime factor-and even this is not needed for proving a weaker time bound of O (log21/2 n) for the algorithm). In contrast, the correctness proofs of earlier algorithms producing a certificate for primality [APR], [GK], [Atk] are much more complex.

In Section 2, we summarize the basic idea behind our algorithm. In Section 3, we fix the notation used. In Section 4, we state the algorithm and present its proof of correctness. In Section 5, we obtain bounds on the running time of the algorithm. Section 6 discusses some ways of improving the time complexity of the algorithm.

#### 2. The idea

Our test is based on the following identity for prime numbers which is a generalization of Fermat's Little Theorem. This identity was the basis for a randomized polynomial-time algorithm in [AB]:

LEMMA 2.1. Let  $a \in \mathcal{Z}$ ,  $n \in \mathcal{N}$ ,  $n \geq 2$ , and (a, n) = 1. Then n is prime if and only if

$$(1) (X+a)^n = X^n + a \pmod{n}.$$

*Proof.* For 0 < i < n, the coefficient of  $x^i$  in  $((X + a)^n - (X^n + a))$  is  $\binom{n}{i}a^{n-i}$ .

Suppose n is prime. Then  $\binom{n}{i} = 0 \pmod{n}$  and hence all the coefficients are zero.

Suppose n is composite. Consider a prime q that is a factor of n and let  $q^k||n$ . Then  $q^k$  does not divide  $\binom{n}{q}$  and is coprime to  $a^{n-q}$  and hence the coefficient of  $X^q$  is not zero (mod n). Thus  $((X+a)^n-(X^n+a))$  is not identically zero over  $Z_n$ .

The above identity suggests a simple test for primality: given an input n, choose an a and test whether the congruence (1) is satisfied. However, this takes time  $\Omega(n)$  because we need to evaluate n coefficients in the LHS in the worst case. A simple way to reduce the number of coefficients is to evaluate both sides of (1) modulo a polynomial of the form  $X^r - 1$  for an appropriately chosen small r. In other words, test if the following equation is satisfied:

(2) 
$$(X+a)^n = X^n + a \pmod{X^r - 1, n}.$$

From Lemma 2.1 it is immediate that all primes n satisfy the equation (2) for all values of a and r. The problem now is that some composites n may also satisfy the equation for a few values of a and r (and indeed they do). However, we can almost restore the characterization: we show that for appropriately chosen r if the equation (2) is satisfied for several a's then n must be a prime power. The number of a's and the appropriate r are both bounded by a polynomial in  $\log n$  and therefore, we get a deterministic polynomial time algorithm for testing primality.

## 3. Notation and preliminaries

 The class P is the class of sets accepted by deterministic polynomial-time Turing machines [Lee]; see [Lee] for the definitions of classes NP, co-NP, etc.

 Zn denotes the ring of numbers modulo n and Fp denotes the finite field with p elements, where p is prime. Recall that if p is prime and h(X) is a polynomial of degree d and irreducible in Fp, then Fp[X]/(h(X)) is a finite field of order pd. We will use the notation f(X) = g(X) (mod h(X), n) to represent the equation f(X) = g(X) in the ring Zn[X]/(h(X)).

 We use the symbol O-(t(n)) for O(t(n) · poly(logt(n)), where t(n) is any function of n. For example, O(logk n) = 0(logk n \* poly(log log n)) = O(logk+E n) for any e > 0. We use log for base 2 logarithms, and ln for natural logarithms.

 AJ and Z denote the set of natural numbers and integers respectively. Given r c KV, a E Z with (a, r) = 1, the order of a modulo r is the smallest number k such that ak = 1 (mod r). It is denoted as or(a). For r E A, q(r) is Euler's totient function giving the number of numbers less than r that are relatively prime to r. It is easy to see that or(a) I| (r) for any a, (a, r) = 1.

 We will need the following simple fact about the 1cm of the first m numbers (see, e.g., [Nai] for a proof).

 LEMMA 3.1. Let LCM(m) denote the 1cm of the first m numbers. For m>7:

$$LCM(m) \ge 2^m$$
.

#### 4. The algorithm and its correctness

Input: integer n > 1.

- 1. If (n = ab for a E Ar and b > 1), output COMPOSITE.
- 2. Find the smallest r such that Or(n) > log2n.
- 3. If 1 < (a,n) < n for some a < r, output COMPOSITE.
- 4. If n < r, output PRIME.1
- 5. For a= 1 to L /b(r)lognJ do if ((X + a)n y Xn + a (mod Xr - 1, n)), output COMPOSITE;
- 6. Output PRIME.

## Algorithm for Primality Testing

Theorem 4.1. The algorithm above returns PRIME if and only if n is prime.

In the remainder of the section, we establish this theorem through a sequence of lemmas. The following is trivial:

LEMMA 4.2. If n is prime, the algorithm returns PRIME.

*Proof.* If n is prime then steps 1 and 3 can never return COMPOSITE. By Lemma 2.1, the for loop also cannot return COMPOSITE. Therefore the algorithm will identify n as PRIME either in step 4 or in step 6.

The converse of the above lemma requires a little more work. If the algorithm returns PRIME in step 4 then n must be prime since otherwise step 3 would have found a nontrivial factor of n. So the only remaining case is when the algorithm returns PRIME in step 6. For the purpose of subsequent analysis we assume this to be the case.

The algorithm has two main steps (2 and 5): step 2 finds an appropriate r and step 5 verifies the equation (2) for a number of a's. We first bound the magnitude of the appropriate r.

LEMMA 4.3. There exists an  $r \leq \max\{3, \lceil \log^5 n \rceil\}$  such that  $o_r(n) > \log^2 n$ .

*Proof.* This is trivially true when n=2; r=3 satisfies all conditions. So assume that n>2. Then  $\lceil \log^5 n \rceil > 10$  and Lemma 3.1 applies. Let  $r_1, r_2, \ldots, r_t$  be all numbers such that either  $o_{r_i}(n) \leq \log^2 n$  or  $r_i$  divides n. Each of these numbers must divide the product

$$n \cdot \prod_{i=1}^{\lfloor \log^2 n \rfloor} (n^i - 1) < n^{\log^4 n} \le 2^{\log^5 n}.$$

By Lemma 3.1, the lcm of the first  $\lceil \log^5 n \rceil$  numbers is at least  $2^{\lceil \log^5 n \rceil}$  and therefore there must exist a number  $s \leq \lceil \log^5 n \rceil$  such that  $s \notin \{r_1, r_2, \ldots, r_t\}$ . If (s, n) = 1 then  $o_s(n) > \log^2 n$  and we are done. If (s, n) > 1, then since s does not divide n and  $(s, n) \in \{r_1, r_2, \ldots, r_t\}$ ,  $r = \frac{s}{(s, n)} \notin \{r_1, r_2, \ldots, r_t\}$  and so  $o_r(n) > \log^2 n$ .

Since  $o_r(n) > 1$ , there must exist a prime divisor p of n such that  $o_r(p) > 1$ . We have p > r since otherwise either step 3 or step 4 would decide about the primality of n. Since (n,r)=1 (otherwise either step 3 or step 4 will correctly identify n),  $p,n \in \mathbb{Z}_r^*$ . Numbers p and r will be fixed in the remainder of this section. Also, let  $\ell = \lfloor \sqrt{\phi(r)} \log n \rfloor$ .

Lemma 4.3 shows that  $r \leq \lceil \log^5 n \rceil$ , so that Step 4 is relevant only when  $n \leq 5,690,034$ .

 Step 5 of the algorithm verifies £ equations. Since the algorithm does not output COMPOSITE in this step, we have:

$$(X+a)^n = X^n + a \pmod{X^r - 1, n}$$

 for every a, 0 < a < f (the equation for a = 0 is trivially satisfied). This implies:

(3) 
$$(X+a)^n = X^n + a \pmod{X^r - 1, p}$$

for 0 < a < £. By Lemma 2.1, we have:

(4) 
$$(X+a)^p = X^p + a \pmod{X^r - 1, p}$$

for 0 < a < e. From equations 3 and 4 it follows that:

(5) 
$$(X+a)^{\frac{n}{p}} = X^{\frac{n}{p}} + a \pmod{X^r - 1, p}$$

 for 0 < a < e. Thus both n and n behave like prime p in the above equation. We give a name to this property:

 Definition 4.4. For polynomial f(X) and number m E A/, we say that m is introspective for f(X) if

$$[f(X)]^m = f(X^m) \pmod{X^r - 1, p}.$$

 It is clear from equations (5) and (4) that both n and p are introspective for X + a when 0 < a < £.

 The following lemma shows that introspective numbers are closed under multiplication:

 LEMMA 4.5. If m and m' are introspective numbers for f(X) then so is m m'.

Proof. Since m is introspective for f(X) we have:

$$[f(X)]^{m \cdot m'} = [f(X^m)]^{m'} \pmod{X^r - 1, p}.$$

 Also, since m' is introspective for f(X), we have (after replacing X by xm in the introspection equation for m'):

$$\begin{split} [f(X^m)]^{m'} &= f(X^{m \cdot m'}) \pmod{X^{m \cdot r} - 1, p} \\ &= f(X^{m \cdot m'}) \pmod{X^r - 1, p} \pmod{X^r - 1} \text{ divides } X^{m \cdot r} - 1). \end{split}$$

Putting together the above two equations we get:

$$[f(X)]^{m \cdot m'} = f(X^{m \cdot m'}) \pmod{X^r - 1, p}.$$

 For a number m, the set of polynomials for which m is introspective is also closed under multiplication:

 LEMMA 4.6. If m is introspective for f(X) and g(X) then it is also introspective for f(X) . g(X).

Proof. We have:

$$[f(X) \cdot g(X)]^m = [f(X)]^m \cdot [g(X)]^m$$
$$= f(X^m) \cdot g(X^m) \pmod{X^r - 1, p}.$$

 The above two lemmas together imply that every number in the set I = {(ni j pi i,j > 0} is introspective for every polynomial in the set P = {it=0(X + a)ea I ea > 0}. We now define two groups based on these sets that will play a crucial role in the proof.

 The first group is the set of all residues of numbers in I modulo r. This is a subgroup of Zr since, as already observed, (n,r) = (p,r) = 1. Let G be this group and IGI = t. G is generated by n and p modulo r and since or(n) > log2 n, t > log2 n.

 To define the second group, we need some basic facts about cyclotomic polynomials over finite fields. Let Qr(X) be the rth cyclotomic polynomial over Fp. Polynomial Qr(X) divides Xr - 1 and factors into irreducible factors of degree Or(P) [LN]. Let h(X) be one such irreducible factor. Since or(p) > 1, the degree of h(X) is greater than one. The second group is the set of all residues of polynomials in P modulo h(X) and p. Let g be this group which is generated by elements X, X+l, X+2, ..., X+i in the field F = Fp[X]/(h(X)) and is a subgroup of the multiplicative group of F.

 The following lemma proves a lower bound on the size of the group g. It is a slight improvement on a bound shown by Hendrik Lenstra Jr. [Len], which, in turn, improved a bound shown in an earlier version of our paper [AKS].2

LEMMA 4.7 (Hendrik Lenstra Jr.). 
$$|\mathcal{G}| \geq {t+\ell \choose t-1}$$
.

 Proof. First note that since h(X) is a factor of the cyclotomic polynomial Qr(X), X is a primitive rth root of unity in F.

 We now show that any two distinct polynomials of degree less than t in P will map to different elements in 9. Let f(X) and g(X) be two such polynomials in P. Suppose f(X) = g(X) in the field F. Let m e I. We also have [f(X)]m = [g(X)]m in F. Since m is introspective for both f and g, and h(X) divides Xr - 1, we get:

$$f(X^m) = g(X^m)$$

 in F. This implies that Xm is a root of the polynomial Q(Y) = f(Y) - g(Y) for every m E G. Since (m, r) = 1 (G is a subgroup of Zr), each such xm is a

 <sup>2</sup>Macaj [Mac] also proved this lemma independently.

primitive  $r^{\text{th}}$  root of unity. Hence there will be |G| = t distinct roots of Q(Y) in F. However, the degree of Q(Y) is less than t by the choice of f and g. This is a contradiction and therefore,  $f(X) \neq g(X)$  in F.

Note that  $i \neq j$  in  $F_p$  for  $1 \leq i \neq j \leq \ell$  since  $\ell = \lfloor \sqrt{\phi(r)} \log n \rfloor < \sqrt{r} \log n < r$  and p > r. So the elements  $X, X + 1, X + 2, \ldots, X + \ell$  are all distinct in F. Also, since the degree of h is greater than one,  $X + a \neq 0$  in F for every  $a, 0 \leq a \leq \ell$ . So there exist at least  $\ell + 1$  distinct polynomials of degree one in  $\mathcal{G}$ . Therefore, there exist at least  $\binom{t+\ell}{t-1}$  distinct polynomials of degree  $\ell \in \mathcal{G}$  in  $\mathcal{G}$ .

In case n is not a power of p, the size of  $\mathcal{G}$  can also be upper bounded:

LEMMA 4.8. If n is not a power of p then  $|\mathcal{G}| \leq n^{\sqrt{t}}$ .

*Proof.* Consider the following subset of *I*:

$$\hat{I} = \{ (\frac{n}{p})^i \cdot p^j \mid 0 \le i, j \le \lfloor \sqrt{t} \rfloor \}.$$

If n is not a power of p then the set  $\hat{I}$  has  $(\lfloor \sqrt{t} \rfloor + 1)^2 > t$  distinct numbers. Since |G| = t, at least two numbers in  $\hat{I}$  must be equal modulo r. Let these be  $m_1$  and  $m_2$  with  $m_1 > m_2$ . So we have:

$$X^{m_1} = X^{m_2} \pmod{X^r - 1}.$$

Let  $f(X) \in P$ . Then,

$$[f(X)]^{m_1} = f(X^{m_1}) \pmod{X^r - 1, p}$$

$$= f(X^{m_2}) \pmod{X^r - 1, p}$$

$$= [f(X)]^{m_2} \pmod{X^r - 1, p}.$$

This implies

$$[f(X)]^{m_1} = [f(X)]^{m_2}$$

in the field F. Therefore,  $f(X) \in \mathcal{G}$  is a root of the polynomial  $Q'(Y) = Y^{m_1} - Y^{m_2}$  in the field F.<sup>3</sup> As f(X) is an arbitrary element of  $\mathcal{G}$ , the polynomial Q'(Y) has at least  $|\mathcal{G}|$  distinct roots in F. The degree of Q'(Y) is  $m_1 \leq (\frac{n}{p} \cdot p)^{\lfloor \sqrt{t} \rfloor} \leq n^{\sqrt{t}}$ . This shows  $|\mathcal{G}| \leq n^{\sqrt{t}}$ .

Armed with these estimates on the size of  $\mathcal{G}$ , we are now ready to prove the correctness of the algorithm:

LEMMA 4.9. If the algorithm returns PRIME then n is prime.

<sup>&</sup>lt;sup>3</sup>This formulation of the argument is by Adam Kalai, Amit Sahai, and Madhu Sudan [KSS].

*Proof.* Suppose that the algorithm returns PRIME. Lemma 4.7 implies that for t = |G| and  $\ell = |\sqrt{\phi(r)} \log n|$ :

$$\begin{split} |\mathcal{G}| & \geq \binom{t+\ell}{t-1} \\ & \geq \binom{\ell+1+\lfloor \sqrt{t}\log n\rfloor}{\lfloor \sqrt{t}\log n\rfloor} \quad \text{(since } t > \sqrt{t}\log n \text{)} \\ & \geq \binom{2\lfloor \sqrt{t}\log n\rfloor+1}{\lfloor \sqrt{t}\log n\rfloor} \quad \text{(since } \ell = \lfloor \sqrt{\phi(r)}\log n\rfloor \geq \lfloor \sqrt{t}\log n\rfloor \text{)} \\ & > 2^{\lfloor \sqrt{t}\log n\rfloor+1} \quad \text{(since } \lfloor \sqrt{t}\log n\rfloor > \lfloor \log^2 n\rfloor \geq 1 \text{)} \\ & > n^{\sqrt{t}}. \end{split}$$

By Lemma 4.8,  $|\mathcal{G}| \leq n^{\sqrt{t}}$  if n is not a power of p. Therefore,  $n = p^k$  for some k > 0. If k > 1 then the algorithm will return COMPOSITE in step 1. Therefore, n = p.

This completes the proof of Theorem 4.1.

#### 5. Time complexity analysis and improvements

It is straightforward to calculate the time complexity of the algorithm. In these calculations we use the fact that addition, multiplication, and division operations between two m bits numbers can be performed in time  $O^{\sim}(m)$  [vzGG]. Similarly, these operations on two degree d polynomials with coefficients at most m bits in size can be done in time  $O^{\sim}(d \cdot m)$  steps [vzGG].

Theorem 5.1. The asymptotic time complexity of the algorithm is  $O^{\sim}(\log^{21/2} n)$ .

*Proof.* The first step of the algorithm takes asymptotic time  $O^{\sim}(\log^3 n)$  [vzGG].

In step 2, we find an r with  $o_r(n) > \log^2 n$ . This can be done by trying out successive values of r and testing if  $n^k \neq 1 \pmod{r}$  for every  $k \leq \log^2 n$ . For a particular r, this will involve at most  $O(\log^2 n)$  multiplications modulo r and so will take time  $O^{\sim}(\log^2 n \log r)$ . By Lemma 4.3 we know that only  $O(\log^5 n)$  different r's need to be tried. Thus the total time complexity of step 2 is  $O^{\sim}(\log^7 n)$ .

The third step involves computing the gcd of r numbers. Each gcd computation takes time  $O(\log n)$  [vzGG], and therefore, the time complexity of this step is  $O(r \log n) = O(\log^6 n)$ . The time complexity of step 4 is just  $O(\log n)$ .

In step 5, we need to verify  $\lfloor \sqrt{\phi(r)} \log n \rfloor$  equations. Each equation requires  $O(\log n)$  multiplications of degree r polynomials with coefficients of

size  $O(\log n)$ . So each equation can be verified in time  $O^{\sim}(r\log^2 n)$  steps. Thus the time complexity of step 5 is  $O^{\sim}(r\sqrt{\phi(r)}\log^3 n) = O^{\sim}(r^{\frac{3}{2}}\log^3 n) = O^{\sim}(\log^{21/2} n)$ . This time dominates all the others and is therefore the time complexity of the algorithm.

The time complexity of the algorithm can be improved by improving the estimate for r (done in Lemma 4.3). Of course the best possible scenario would be when  $r = O(\log^2 n)$  and in that case the time complexity of the algorithm would be  $O^{\sim}(\log^6 n)$ . In fact, there are two conjectures that support the possibility of such an r (below  $\ln n$  is the natural logarithm):

Artin's Conjecture. Given any number  $n \in \mathcal{N}$  that is not a perfect square, the number of primes  $q \leq m$  for which  $o_q(n) = q - 1$  is asymptotically  $A(n) \cdot \frac{m}{\ln m}$  where A(n) is Artin's constant with A(n) > 0.35.

Sophie-Germain Prime Density Conjecture. The number of primes  $q \leq m$  such that 2q+1 is also a prime is asymptotically  $\frac{2C_2m}{\ln^2 m}$  where  $C_2$  is the twin prime constant (estimated to be approximately 0.66). Primes q with this property are called Sophie-Germain primes.

Artin's conjecture—if it becomes effective for  $m = O(\log^2 n)$ —immediately shows that there is an  $r = O(\log^2 n)$  with the required properties. There has been some progress towards proving Artin's conjecture [GM], [GMM], [HB], and it is also known that this conjecture holds under the Generalized Riemann Hypothesis.

If the second conjecture holds, we can conclude that  $r = O^{\sim}(\log^2 n)$ :

By the density of Sophie-Germain primes, there must exist at least  $\log^2 n$  such primes between  $8\log^2 n$  and  $c\log^2 n(\log\log n)^2$  for a suitable constant c. For any such prime q, either  $o_q(n) \leq 2$  or  $o_q(n) \geq \frac{q-1}{2}$ . Any q for which  $o_q(n) \leq 2$  must divide  $n^2 - 1$  and so the number of such q is bounded by  $O(\log n)$ . This implies that there must exist a prime  $r = O^{\sim}(\log^2 n)$  such that  $o_r(n) > \log^2 n$ . Such an r will yield an algorithm with time complexity  $O^{\sim}(\log^6 n)$ .

There has been progress towards proving this conjecture as well. Let P(m) denote the greatest prime divisor of number m. Goldfeld [Gol] showed that primes q with  $P(q-1) > q^{\frac{1}{2}+c}$ ,  $c \approx \frac{1}{12}$ , occur with positive density. Improving upon this, Fourry has shown:

LEMMA 5.2 ([Fou]). There exist constants c > 0 and  $n_0$  such that, for all  $x \ge n_0$ :

$$|\{q \mid q \text{ is prime, } q \leq x \text{ and } P(q-1) > q^{\frac{2}{3}} \}| \geq c \frac{x}{\ln x}.$$

 The above lemma is now known to hold for exponents up to 0.6683 [BH]. Using the above lemma, we can improve the analysis of our algorithm:

PRIMES IS.IN P

 THEOREM 5.3. The asymptotic time complexity of the algorithm is O (log15/2 n).

 Proof. As argued above, a high density of primes q with P(q - 1) > q3 implies that step 2 of the algorithm will find an r = O(log3 n) with Or(n) > log2 n. This brings the complexity of the algorithm down to O0 (log15/2 n). [1

 Recently, Hendrik Lenstra and Carl Pomerance [LP1] have come up with a modified version of our algorithm whose time complexity is provably O (log6 n).

### 6. Future work

 In our algorithm, the loop in step 5 needs to run for [ /b(r) log nj times to ensure that the size of the group g is large enough. The number of iterations of the loop could be reduced if we could show that a still smaller set of (X + a)'s generates a group of the required size. This seems very likely.

 One can further improve the complexity to O (log3 n) if the following conjecture-given in [BP] and verified for r < 100 and n < 1010 in [KS]-is proved:

CONJECTURE 6.1. If r is a prime number that does not divide n and if

(6) 
$$(X-1)^n = X^n - 1 \pmod{X^r - 1, n},$$

then either n is prime or n2 = 1 (mod r).

 If this conjecture is true, we can modify the algorithm slightly to search first for an r which does not divide n2 - 1. Such an r can assuredly be found in the range [2, 4 log n]. This is because the product of prime numbers less than x is at least ex (see [Apo]). Thereafter we can test whether the congruence (6) holds or not. Verifying the congruence takes time O(r log2 n). This gives a time complexity of Or (log3 n).

 Recently, Hendrik Lenstra and Carl Pomerance [LP2] have given a heuris tic argument which suggests that the above conjecture is false. However, some variant of the conjecture may still be true (for example, if we force r > log n).

 Acknowledgments. We wish to express our gratitude to Hendrik Lenstra Jr. for allowing us to use his observation on improving the lower bound on the size of the group g. This has made the proof completely elementary (an earlier version required the density bound of Lemma 5.2), simplified the proof and improved the time complexity!

 We are also thankful to Adam Kalai, Amit Sahai, and Madhu Sudan for allowing us to use their proof of Lemma 4.8. This has made the proofs of both upper and lower bounds on the size of g similar (both are now based on the number of roots of a polynomial in a field).

 We thank Somenath Biswas, Rajat Bhattacharjee, Jaikumar Radhakrishnan, and V. Vinay for many useful discussions.

 We thank Erich Bach, Abhijit Das, G. Harman, Roger Heath-Brown, Pieter Moree, Richard Pinch, and Carl Pomerance for providing us with useful references.

 Since our preprint appeared, a number of researchers took the trouble of pointing out various omissions in our paper. We are thankful to all of them. We have tried to incorporate their suggestions in the paper and our apologies if we missed out on some.

 Finally, we thank the anonymous referee of the paper whose suggestions and observations have been very useful.

 DEPARTMENT OF COMPUTER SCIENCE & ENGINEERING, INDIAN INSTITUTE OF TECHNOLOGY KANPUR, KANPUR, INDIA E-mail addresses: manindra@cse.iitk.ac.in nitinsa@cse.iitk.ac.in kayaln@cse.iitk.ac.in

#### REFERENCES

- [AH] L. M. ADLEMAN and M.-D. HUANG, Primality Testing and Abelian Varieties over Finite Fields, Lecture Notes in Math. 1512, Springer-Verlag, New York, 1992.
- [APR] L. M. ADLEMAN, C. POMERANCE, and R. S. RUMELY, On distinguishing prime numbers from composite numbers, Ann. of Math. 117 (1983), 173-206.
- [AB] M. AGRAWAL and S. BISWAS, Primality and identity testing via Chinese remaindering, Journal of the ACM 50 (2003), 429-443.
- [AKS] M. AGRAWAL, N. KAYAL, and N. SAXENA, PRIMES is in P, preprint (http://www.cse.iitk.ac.in/news/primality.ps), August 2002.
- [Apo] T. M. APOSTOL, Introduction to Analytic Number Theory, Springer-Verlag, New York, 1997.
- [Atk] A. 0. L. ATKIN, Lecture notes of a conference, Boulder (Colorado), Manuscript, August 1986.
- [BH] R. C. BAKER and G. HARMAN, The Brun-Titchmarsh Theorem on average, in An alytic Number Theory, Volume I (Allerton Park, IL, 1995), Progr. Math. 138, 39-103, Birkhiiuser Boston, Boston, MA, 1996.
- [BP] R. BHATTACHARJEE and P. PANDEY, Primality testing, Technical report, IIT Kanpur, 2001; available at http://www.cse.iitk.ac.in/research/btp2001/primality.html.
- [Car] R. D. CARMICHAEL, Note on a number theory function, Bull. Amer. Math. Soc. 16 (1910), 232-238.
- [Fou] E. FOUVRY, Theoreme de Brun-Titchmarsh; application au theoreme de Fermat, Invent. Math. 79 (1985), 383-407.

- [GK] S. GOLDWASSER and J. KILIAN, Almost all primes can be quickly certified, in Proc. Annual ACM Symposium on the Theory of Computing, 316-329, 1986.
- [GM] R. GUPTA and M. RAM MURTY, A remark on Artin's conjecture, Invent. Math. 78 (1984), 127-130.
- [GMM] R. GUPTA, V. KUMAR MURTY, and M. RAM MURTY, The Euclidian algorithm for S-integers, Number Theory (Montreal, Que., 1985), CMS Conf. Proc. 7 (1987), 189-202.
- [Gol] M. GOLDFELD, On the number of primes p for which p + a has a large prime factor, Mathematika 16 (1969), 23-27.
- [HB] D. R. HEATH-BROWN, Artin's conjecture for primitive roots, Quart. J. Math. Oxford 37 (1986), 27-38.
- [KS] N. KAYAL and N. SAXENA, Towards a deterministic polynomial-time test, Technical report, IIT Kanpur, 2002; available at http://www.cse.iitk.ac.in/ research/btp2002/primality.html.
- [KSS] A. KALAI, A. SAHAI, and M. SUDAN, Notes on primality test and analysis of AKS, Private communication, August 2002.
- [Lee] J. V. LEEUWEN (ed.), Handbook of Theoretical Computer Science, Volume A, MIT Press, Cambridge, MA, 1990.
- [Len] H. W. LENSTRA, JR., Primality testing with cyclotomic rings, unpublished (see http://cr.yp.to/papers.html#aks for an exposition of Lenstra's argument), August 2002.
- [LN] R. LIDL and H. NIEDERREITER, Introduction to Finite Fields and their Applications, Cambridge Univ. Press, Cambridge, 1986.
- [LP1] H. W. LENSTRA, JR. and C. POMERANCE, Primality testing with gaussian periods, Private communication, March 2003.
- [LP2] , Remarks on Agrawal's conjecture, unpublished (http://www.aimath.org/ WWN/ primesinp/articles/html/50a/), March 2003.
- [Mac] M. MACAJ, Some remarks and questions about the AKS algorithm and related con jecture, unpublished (http://thales.doa.fmph.uniba.sk/macaj/aksremarks.pdf), December 2002.
- [Mil] G. L. MILLER, Riemann's hypothesis and tests for primality, J. Comput. Sys. Sci. 13 (1976), 300-317.
- [Nai] M. NAIR, On Chebyshev-type inequalities for primes, Amer. Math. Monthly 89 (1982), 126-129.
- [Pra] V. PRATT, Every prime has a succinct certificate, SIAM Journal on Computing 4 (1975), 214-220.
- [Rab] M. 0. RABIN, Probabilistic algorithm for testing primality, J. Number Theory 12 (1980), 128-138.
- [SS] R. SOLOVAY and V. STRASSEN, A fast Monte-Carlo test for primality, SIAM Journal on Computing 6 (1977), 84-86.
- [vzGG] J. VON ZUR GATHEN and J. GERHARD, Modern Computer Algebra, Cambridge Univ. Press, Cambridge, 1999.

(Received January 24, 2003)