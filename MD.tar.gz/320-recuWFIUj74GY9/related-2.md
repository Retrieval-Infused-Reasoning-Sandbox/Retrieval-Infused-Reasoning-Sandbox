# Covariant formulation of spin optics for electromagnetic waves

Pravin Kumar Dahal<sup>∗</sup> *School of Mathematical & Physical Sciences, Macquarie University* (Dated: December 13, 2022)

We develop geometric optics expansion up to the subleading order for circularly polarized electromagnetic waves on curved spacetime. This subleading order geometric optics expansion, in which the conventional eikonal function is modified by inserting a carefully chosen helicity-dependent correction, is called spin optics. We derive the propagation and polarization equations in the spin optics approximation as electromagnetic waves travel in curved spacetime. Polarization-dependent deviation of the light ray trajectory from the geodesic, describing the gravitational spin Hall effect, is observed. We also establish an analogy with the related phenomena (optical Magnus effect) of condensed matter physics.

# I. INTRODUCTION

Geometric optics is valid in the infinitely large frequency limit [1–3]. In this approximation, electromagnetic waves propagating on the fixed curved background follow a null ray trajectory. At large but finite frequencies, the geometric optics approximation no longer remains valid, as backreaction from the helicity may cause ray trajectory to depart from the geodesics by a significant amount. The gravitational spin Hall effect refers to this helicity dependent phenomenon of the propagation of a light ray in curved spacetime in the subleading order [4–7]. This is similar to the gravitational Faraday effect (or the spin Hall effect for gravitational waves), which is observed for high-frequency polarized gravitational waves propagating in curved spacetimes [9? , 10].

The spin Hall effect is due to the interaction of polarization/spin with the orbital motion of the rays [14–16]. Related phenomena are observed in different areas of physics, including optics, where the polarization-dependent deflection of light was predicted [11–13] and verified experimentally for both electrons [17, 18] and light [19, 20] (also see Ref. [21] for the explanation of these results in terms of classical optics). When an electromagnetic wave propagates in an inhomogeneous medium, the spin Hall effect of light (also known as the optical Magnus effect) is observed. The coupling of spin with the orbital motion comes from the interaction of the polarization of waves with the refractive index gradient of the medium. As a result, electromagnetic waves are deflected transversally in a direction perpendicular to the refractive index gradient. The spin Hall effect can be expressed in terms of Berry curvature [22–24] and provides correction to the geometric optics, which is approximately proportional to the frequency inverse, in the subleading order. This phenomenon of the optical Magnus effect can be extended to general relativity, where spacetime curvature itself acts as an inhomogeneous medium [4, 5, 25–27, 29, 30]. This analogy comes from the fact that the equations for electromagnetic waves propagating in some optical medium and curved spacetime are identical. Thus, the gravitational spin Hall effect is caused by the interaction of polarisation with spacetime curvature, requiring a spin-dependent correction to particle dynamics.

Various approaches can be found in the literature for the calculation of the gravitational spin Hall effect, and they can be broadly classified into three categories: 1) use of the Souriau-Saturnini equations [31, 32], which is a modification of the Mathisson-Papapertou-Dixon equation [33–36] for the motion of massive spinning particles to the massless ones, 2) application of the methods of quantum mechanics, such as using the Foldy-Wouthyusyen transformation on the Bargmann-Wigner equations [30, 37, 38], and 3) spin optics [2–4, 6]. See the review by [25] and the references therein for the detailed discussions of each of these approaches and their comparisons. Here, we focus on spin optics (or modified geometric optics), where the eikonal function is modified by including the spin-dependent term. This correction is of the order ω −1 and thus suppressed in the high-frequency approximation. However, such correction becomes essential for the propagation of polarized rays of high but finite frequencies at large distances (where the ray trajectory could be modified).

Self-dual and anti-self-dual solutions of the Maxwell equations represent electromagnetic fields with right- and left-hand circular polarization, respectively. The use of the Wentzel-Kramers-Brillouin (WKB) ansatz for each of these solutions does not require the same eikonal functions for both types of waves. We instead include the helicity-dependent first-order high-frequency correction in the eikonal function in the spin optics approximation. The development of spin optics for general spacetime has been demonstrated in recent papers by Refs. [26] and [27]. Their results are slightly different from each other and our paper. We will compare these results.

Here, we formulate the theory of spin optics and develop self-consistent ray and transport equations for the propagation of electromagnetic waves in curved spacetime. Electromagnetic waves from astrophysical sources might propagate over cosmological distances before reaching the observer. As a result, they might encounter inhomogeneities in the form of spacetime curvature. These inhomogeneities act as a lensing object, and if their length scale is much larger than the characteristic wavelength of the electromagnetic waves, then the geometric optics approximation is valid. However, there might be a situation, where the characteristic wavelength is small but not negligible compared to the length scale of the variation of spacetime curvature. In such a situation, the necessity of the subleading order correction to the geometric optics arises while studying the gravitational lensing of electromagnetic waves. The standard lensing phenomena likely

<sup>∗</sup> pravin-kumar.dahal@hdr.mq.edu.au

include wave effects, changing the propagation properties of waves [28]. In Sec. II, we write the Maxwell equations in curved spacetime and obtain the equation for electromagnetic waves. To solve the electromagnetic wave equation, we present the WKB ansatz for the vector potential in Sec. III. Next, we show that we can reduce the geometric optics solution to a set of Fermi transported null tetrads and then generalize this (requirement) to the subleading order. We impose more constraints on the subleading order equations considering the solutions to be self-dual and anti-self-dual. These requirements and considerations are sufficient to obtain the propagation and polarization equations up to the subleading order. We do this in Sec. IV. We also obtain the stress-energy tensor of the electromagnetic field up to the subleading order approximation in Sec. V to see the energy flow as the wave propagates. We then compare our results with the literature using the WKB approximation, the same formalism as used here, in Sec. VI. Finally, we discuss our results in Sec. VII.

In this article, we consider the metric  $g_{\mu\nu}$  of signature (-,+,+,+) in a Lorentzian manifold M. The phase space is the cotangent bundle  $T^*M$  and its points are written as (x,p). Similarly, we write  $\tilde{z}$  for the complex conjugate of z and adopt the Einstein summation convention. We use the system of units with G=c=1. A semicolon (;) denote the covariant derivative,  $\lambda$  denotes the parameter of electromagnetic wave curves, and  $\dot{x}=dx/d\lambda$ . We use the sign convention for the curvature adopted in [1].

#### II. MAXWELL EQUATIONS IN CURVED SPACETIMES

In flat spacetime, the Maxwell equations of electrodynamics are

$$\frac{\partial}{\partial x^{\alpha}} F^{\alpha\beta} = -J^{\beta},\tag{1}$$

$$\frac{\partial}{\partial x^{\alpha}}F^{\beta\gamma} + \frac{\partial}{\partial x^{\beta}}F^{\gamma\alpha} + \frac{\partial}{\partial x^{\gamma}}F^{\alpha\beta} = 0, \tag{2}$$

where  $F^{\alpha\beta}$  is the antisymmetric field tensor with components

$$F^{jk} = e^{jkl}B_l, \qquad F^{0j} = E_j. \tag{3}$$

Here,  $e^{jkl}$  is the Levi-Civita symbol in three dimensions, and  $J^{\alpha}$  is the conserved four-current. The principle of general covariance implies that these equations hold in a general curved spacetime if covariant derivatives replace the partial derivatives occurring in the equations. Thus, the Maxwell equations in curved spacetime are

$$F^{\alpha\beta}_{\alpha} = -J^{\beta},\tag{4}$$

$$F_{\alpha\beta;\gamma} + F_{\gamma\alpha;\beta} + F_{\beta\gamma;\alpha} = 0. \tag{5}$$

Eq.(5) allows us to represent the electromagnetic field tensor  $F^{\alpha\beta}$  in terms of the vector potential  $A^{\alpha}$  as

$$F_{\alpha\beta} = A_{\beta;\alpha} - A_{\alpha;\beta}.$$
(6)

We can use available gauge freedom in the Maxwell equations such that the vector  $A^{\alpha}$  satisfies the Lorenz gauge condition,

 $A^{\alpha}_{;\alpha}=0.$  We substitute this into Eq. (4) to obtain the wave equation

$$-A^{\alpha;\beta}_{;\beta} + R^{\alpha}_{\beta}A^{\beta} = J^{\alpha}, \tag{7}$$

where  $R^{\alpha}_{\beta}$  denotes the Ricci tensor.

#### III. WKB APPROXIMATION

Spin optics approximation is valid when the typical wavelength of the wave is very small (but nonnegligible) in comparison with the length scale over which its amplitude and wavelength vary and the radius of curvature of the spacetime on which it propagates. We can locally approximate the wave as a ray propagating on approximately flat spacetime in such a case. Mathematically, we formulate the spin optics approximation using the WKB ansatz as

$$A^{\alpha} = a^{\alpha} e^{i\omega S},\tag{8}$$

where  $a^{\alpha}$  is the complex amplitude that varies slowly, and  $\omega \mathcal{S}$  is the real phase that changes rapidly. Here,  $\omega$  is the characteristic frequency of the problem. The wave vector is the phase gradient, that is,  $l_{\alpha} = \mathcal{S}_{;\alpha}$ . Let us write the square amplitude  $a = (\tilde{a}^{\alpha}a_{\alpha})^{1/2}$  and the polarization vector  $m^{\alpha} = a^{\alpha}/a$ . We can expand the wave vector and polarization vector in powers of  $1/\omega$  as

$$l^{\alpha} = l_0^{\alpha} + \frac{l_1^{\alpha}}{\omega} + \frac{l_2^{\alpha}}{\omega^2} + ..., \tag{9}$$

$$m^{\alpha} = m_0^{\alpha} + \frac{m_1^{\alpha}}{\omega} + \frac{m_2^{\alpha}}{\omega^2} + \dots$$
 (10)

We should mention here that we cannot absorb higher order phase factors like  $\mathcal{S}_1(\lambda)$  into the complex amplitude  $m_0^\alpha$  by transformation  $m^\alpha \to e^{i\mathcal{S}_1(\lambda)/\omega}m^\alpha$ . This is because we will use the Fermi propagated null tetrad in Sec. IV A and two of its components,  $l^\alpha$  and  $m^\alpha$ , give the trajectory and polarization of the waves, respectively. Fermi propagation reduces the freedom in the transformation of the null tetrad  $m^\alpha \to e^{i\mathcal{S}_1(\lambda)/\omega}m^\alpha$  by the condition

$$\frac{dS_1(\lambda)}{d\lambda} = 0. {(11)}$$

This is the reason why we should expand both the wave vector and polarization vector separately in powers of  $\omega$ . Let us substitute this vector potential onto the source free wave equation (Eq. (7) with  $J^{\alpha}=0$ ) and the Lorenz gauge condition. We start from the Lorenz condition, which up to the subleading order in  $\omega$  can be written as

$$l_0^{\alpha} m_{0\alpha} + \frac{1}{\omega} \left( l_0^{\alpha} m_{1\alpha} + l_1^{\alpha} m_{0\alpha} - i \left( \frac{a_{;\alpha}}{a} m_0^{\alpha} + m_{0;\alpha}^{\alpha} \right) \right) = 0.$$

$$(12)$$

Again, we substitute the vector potential into the source-free wave equation, which gives

$$j^{\alpha} =: m_0^{\alpha} l_{0\beta} l_0^{\beta} + \frac{1}{\omega} \left( m_1^{\alpha} l_{0\beta} l_0^{\beta} + 2 m_0^{\alpha} l_{1\beta} l_0^{\beta} - i \left( m_0^{\alpha} l_{0;\beta}^{\beta} + 2 m_{0;\beta}^{\alpha} l_0^{\beta} + 2 \frac{a_{;\beta}}{a} m_0^{\alpha} l_0^{\beta} \right) \right) = 0, \quad (13)$$

up to the subleading order in  $\omega$ . We now calculate  $\tilde{m}_{0\alpha}j^{\alpha} + m_{0\alpha}\tilde{j}^{\alpha}$ , which is the identically vanishing quantity

$$l_{0\beta}l_0^{\beta} + \frac{2}{\omega} (l_{1\beta} - b_{\beta}) l_0^{\beta} = 0.$$
 (14)

This is the generalization of the dispersion relation of geometric optics. Here, we have used  $\tilde{m}_0^{\alpha} m_{0\alpha} = 1$  and substituted

$$\frac{i}{2} \left( \tilde{m}^{\alpha} m_{\alpha;\beta} - m^{\alpha} \tilde{m}_{\alpha;\beta} \right) = i \tilde{m}^{\alpha} m_{\alpha;\beta} := b_{\beta}. \tag{15}$$

#### IV. SPIN OPTICS APPROXIMATION

#### A. Propagation and polarization vector as tetrad components

Let us construct a set of null tetrads  $(l_0^{\alpha}, n_0^{\alpha}, m_0^{\alpha}, \tilde{m}_0^{\alpha})$  satisfying the following orthogonality and completeness relationships

$$l_0^{\alpha} m_{0\alpha} = l_0^{\alpha} l_{0\alpha} = l_0^{\alpha} \tilde{m}_{0\alpha} = 0, \qquad m_0^{\alpha} \tilde{m}_{0\alpha} = 1,$$
 (16)

$$m_0^{\alpha} m_{0\alpha} = \tilde{m}_0^{\alpha} \tilde{m}_{0\alpha} = 0, \tag{17}$$

$$n_0^{\alpha} m_{0\alpha} = n_0^{\alpha} n_{0\alpha} = n_0^{\alpha} \tilde{m}_{0\alpha} = 0, \qquad n_0^{\alpha} l_{0\alpha} = -1.$$
 (18)

Comparison of Eqs. (16) with the equations of geometric optics (see Eqs. (A1)) shows that two components of the tetrad  $l_0^{\alpha}$  and  $m_0^{\alpha}$  could be identified with the wave vector and polarization vector, respectively. Auxiliary null vectors  $n_{0\alpha}$  and  $m_{0\alpha}$  are not unique and can be chosen in such a way that they satisfy Eqs. (17) and (18). We will discuss below in Sec. IV B that the validity of Eqs. (17) determines the state of polarization; specifically, circularly polarized waves satisfy these relations. Moreover, these components of the null tetrad also satisfy

$$l_{0:\beta}^{\alpha} l_0^{\beta} = 0, \qquad m_{0:\beta}^{\alpha} l_0^{\beta} = 0 = \tilde{m}_{0:\beta}^{\alpha} l_0^{\beta},$$
 (19)

$$n_{0\cdot\beta}^{\alpha}l_0^{\beta} = 0, \tag{20}$$

where Eqs. (19) again follows from geometric optics (to obtain the first relation, we have applied  $l_{0\alpha;\beta} = l_{0\beta;\alpha}$ ). We can choose  $n_0^{\alpha}$ , such that it satisfies Eq. (20). We can show that this choice is indeed possible by introducing the Fermi derivative operator  $\mathcal{D}_l$  along the ray  $l^{\alpha}$ , which applied to the vector  $A^{\alpha}$  gives [4]

$$\mathcal{D}_l A^{\alpha} = l_0^{\gamma} A_{;\gamma}^{\alpha} - w_{\gamma} A^{\gamma} n^{\alpha} + A^{\gamma} n_{\gamma} w^{\alpha}, \qquad (21)$$

where  $w^{\alpha}=l_{0}^{\gamma}l_{;\gamma}^{\alpha}$  vanishes identically in geometric optics. We have  $\mathcal{D}_{l}l^{\alpha}=0$  as  $l^{\gamma}l_{\gamma}=0$ . If the Fermi derivative  $\mathcal{D}_{l}A^{\alpha}$  of a vector  $A^{\alpha}$  is zero, then it is said to be Fermi propagated, and we can easily prove that the scalar product of any two Fermi propagated vectors is constant. We can apply this to the set of tetrads  $(l^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$ : they satisfy the orthogonality and completeness relations similar to the one given in Eqs. (16)-(18) everywhere on the ray if they satisfy those relations the at some point on the ray and if they all are Fermi

propagated. As Fermi propagation preserves the scalar product, the set of null tetrad  $(l^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$  satisfies the orthogonality and completeness relations like those in Eqs. (16)-(18) along the ray and obeys

$$l_0^{\beta} n_{\beta}^{\alpha} = w^{\beta} n_{\beta} n^{\alpha}, \tag{22}$$

$$l_0^{\beta} m_{\beta}^{\alpha} = w^{\beta} m_{\beta} n^{\alpha}, \tag{23}$$

$$l_0^{\beta} \tilde{m}_{\beta}^{\alpha} = w^{\beta} \tilde{m}_{\beta} n^{\alpha}. \tag{24}$$

Next, let us take advantage of flexibility in selecting a null tetrad

$$l^{\alpha} \to F l^{\alpha}, n^{\alpha} \to F^{-1} n^{\alpha},$$
 (25)

to fix  $w^{\beta}n_{\beta}=0$ , where F is some real function. This condition defines the parameter  $\lambda$  along the ray up to some rescaling  $\lambda \to F^{-1}\lambda$ , and such a choice is called a canonical parametrization [27]. Therefore, in the canonical parametrization, we have

$$l_0^{\beta} n_{;\beta}^{\alpha} = 0, \qquad l_0^{\beta} m_{;\beta}^{\alpha} = w^{\beta} m_{\beta} n^{\alpha}, \qquad l_0^{\beta} \tilde{m}_{;\beta}^{\alpha} = w^{\beta} \tilde{m}_{\beta} n^{\alpha}. \tag{26}$$

These relations generalize Eqs. (16)-(20) of geometric optics.

# B. Self-dual and anti-self-dual solutions of Maxwell equations

One can define the complex version of the electromagnetic field tensor  $F^{\alpha\beta}$  as

$$\mathcal{F}^s = F + isF^*,\tag{27}$$

where  $s=\pm 1$  and  $F^*=\epsilon_{\alpha\beta\mu\nu}F^{\mu\nu}/2$  is the Hodge dual of  $F^{\alpha\beta}$ . Here,  $\epsilon_{\alpha\beta\mu\nu}$  is the Levi-Civita symbol in four dimensions, and its components in the tetrad basis are  $il\wedge n\wedge m\wedge \tilde{m}$ . As  $(F^*)^*=-F$ , we have  $(\mathcal{F}^s)^*=-is\mathcal{F}^s$ , a feature due to which we call  $\mathcal{F}^s_{\alpha\beta}$  self- (or anti-self-) dual antisymmetric field for s=+1 (or -1). A general self-dual antisymmetric field can be expanded in terms of the self-dual basis

$$(\mathbf{U}, \mathbf{V}, \mathbf{W}) = (\tilde{m} \wedge n, l \wedge m, m \wedge \tilde{m} - l \wedge n), \qquad (28)$$

as

$$\mathcal{F}^{+1} = \Phi_0 \mathbf{U} + \Phi_1 \mathbf{W} + \Phi_2 \mathbf{V}. \tag{29}$$

In the limit of geometric optics,  $\Phi_0 = \Phi_2 = 0$ . Now, the field  $\mathcal{F}_{\alpha\beta}^{+1}$  corresponding to the potential of Eq. (8) is

$$\mathcal{F}_{\alpha\beta}^{+1} = i\omega \mathcal{Z}_{\alpha\beta} e^{i\mathcal{S}},\tag{30}$$

where

$$\mathcal{Z}_{\alpha\beta} = l_{\alpha}a_{\beta} - l_{\beta}a_{\alpha} - \frac{i}{\omega} \left( a_{\beta;\alpha} - a_{\alpha;\beta} \right). \tag{31}$$

Using the condition that the contraction of the self-dual field with the anti-self-dual field vanishes, we obtain

$$\mathcal{Z}_{\alpha\beta}m^{\alpha}n^{\beta} = 0, \tag{32}$$

$$\mathcal{Z}_{\alpha\beta} \left( \tilde{m}^{\alpha} m^{\beta} - l^{\alpha} n^{\beta} \right) = 0, \tag{33}$$

$$\mathcal{Z}_{\alpha\beta}l^{\alpha}\tilde{m}^{\beta} = 0. \tag{34}$$

An anti-self-dual solution can be found by the complex conjugation of the amplitude  $\mathcal{Z}_{\alpha\beta}$  of the self-dual field. Eq. (34) is satisfied identically in the geometric optics approximation, which can be verified easily by substituting the value of  $\mathcal{Z}_{\alpha\beta}$  from Eq. (31). However, Eqs. (32) and (33) gives

$$m_0^{\alpha} m_{0\alpha} = 0 = l_0^{\alpha} m_{0\alpha}.$$
 (35)

These relations are presented in Eqs. (16) and (17) as the orthogonality conditions.

#### C. Equations of spin optics

#### 1. Generalization of the Hamilton-Jacobi equation

The dispersion equation of geometric optics (see Eq. (A1)) could be written as

$$\frac{1}{2}g_{\alpha\beta}l_0^{\alpha}l_0^{\beta} = 0, \tag{36}$$

which is the Hamilton-Jacobi equation for the leading order phase function  $S_0$  defined as  $S_{0;\alpha}=l_{0\alpha}$ . To solve this Hamilton-Jacobi equation, we define a Hamiltonian function on the cotangent bundle  $T^*M$  as

$$H(x,l) = \frac{1}{2}g^{\alpha\beta}l_{0\alpha}l_{0\beta},\tag{37}$$

where  $x^{\alpha}(\lambda)$  is the integral curve of  $l^{\alpha}$ . We obtain the following Hamilton's equations of motion

$$\frac{dx_0^{\mu}}{d\lambda} = \frac{\partial H}{\partial l_{0\mu}} = g^{\mu\nu} l_{0\nu},\tag{38}$$

and

$$\frac{dl_{0\alpha}}{d\lambda} = \frac{\partial H}{\partial x_0^{\alpha}} = -\frac{1}{2}\dot{x}_0^{\mu}\dot{x}_0^{\nu}\frac{\partial g_{\mu\nu}}{\partial x_0^{\alpha}},\tag{39}$$

where Eq. (38) and the relation

$$\frac{\partial g_{\alpha\beta}}{\partial x_{0\mu}} = -g_{\nu\alpha}g_{\rho\beta}\frac{\partial g^{\nu\rho}}{\partial x_{0\mu}},\tag{40}$$

are used in obtaining this. Given a solution of Hamilton's equations of motion, the corresponding solution of the Hamilton-Jacobi equation (36) is obtained from [39]

$$S_0(x,l) = \int_{\Omega} (\dot{x}_0^{\alpha} l_{0\alpha} - H(x,l)) d\lambda. \tag{41}$$

The Euler-Lagrange equation for this action, whose Lagrangian is the Legendre transformation of the Hamiltonian in Eq. (37), is the geodesic equation. Therefore, Eq. (39) describes null geodesics, and further simplification of this equation gives

$$\frac{d\left(g_{\alpha\beta}\dot{x}_0^{\beta}\right)}{d\lambda} - \frac{1}{2}\dot{x}_0^{\mu}\dot{x}_0^{\nu}\frac{\partial g_{\mu\nu}}{\partial x_{0\alpha}} = \frac{D^2x_0^{\alpha}}{D\lambda^2} = 0, \quad (42)$$

where  $D/D\lambda$  denotes the covariant derivative along the curve  $x^{\alpha}(\lambda)$ . The two Eqs. (38) and (42) obtained by solving Hamilton's equations of motion constitute the two equations of geometric optics. We have thus shown that the Hamiltonian defined in Eq. (37) correctly reproduces the equations of geometric optics. Substituting Eqs. (37) and (38) into the action of Eq. (41) gives

$$S_0 = \frac{1}{2} \int \dot{x}_0^{\alpha} \dot{x}_{0\alpha} d\lambda. \tag{43}$$

Now, to evaluate the trajectory equation up to the subleading order, we consider the generalized dispersion Eq. (14) and write it as

$$\frac{1}{2}g_{\alpha\beta}l_0^{\alpha}l_0^{\beta} + \frac{1}{\omega}g_{\alpha\beta}\left(l_1^{\alpha} - b^{\alpha}\right)l_0^{\beta} = 0, \tag{44}$$

which is the Hamilton-Jacobi equation for the subleading order phase function  $\mathcal S$  defined as  $\mathcal S_{;\alpha}=l_{0\alpha}+l_{1\alpha}/\omega$ . The corresponding Hamiltonian function on the cotangent bundle  $T^*M$  is

$$H(x,l) = \frac{1}{2} g^{\alpha\beta} l_{0\alpha} l_{0\beta} + \frac{1}{\omega} g^{\alpha\beta} (l_{1\alpha} - b_{\alpha}) l_{0\beta}$$
$$= \frac{1}{2\omega^2} g^{\alpha\beta} (\omega l_{0\alpha} + l_{1\alpha} - b_{\alpha}) (\omega l_{0\beta} + l_{1\beta} - b_{\beta}). \tag{45}$$

Hamilton's equations of motion are

$$\frac{dx^{\alpha}}{d\lambda} = \frac{\partial H}{\partial l_{\alpha}} = g^{\alpha\beta} \left( l_{\beta} - \frac{b_{\beta}}{\omega} \right), \tag{46}$$

and

$$\frac{dl_{\alpha}}{d\lambda} = -\frac{\partial H}{\partial x^{\alpha}} = \frac{1}{2}\dot{x}^{\mu}\dot{x}^{\nu}\frac{\partial g_{\mu\nu}}{\partial x^{\alpha}} + \frac{1}{\omega}g^{\mu\nu}\dot{x}_{\nu}\frac{\partial b_{\mu}}{\partial x^{\alpha}},\tag{47}$$

where we have used Eqs. (40) and (46) in obtaining this. Thus, the corresponding solution of the Hamilton-Jacobi equation (44) is obtained from [39]

$$S(x,l) = \int_{\lambda} (\dot{x}^{\alpha} l_{\alpha} - H(x,l)) d\lambda$$
$$= \frac{1}{2} \int \dot{x}^{\alpha} \dot{x}_{\alpha} d\lambda + \frac{1}{\omega} \int b_{\alpha} \dot{x}^{\alpha} d\lambda = S_{0} - S_{B}, \quad (48)$$

where Eqs. (45) and (46) are used for simplification. In addition to the scalar phase, photons acquire a polarization-dependent phase  $S_B$ . This is the Berry geometric phase acquired by the circularly polarized modes propagating in curved spacetime [40–42]. This form of action was considered by Refs. [27] and [43] to derive the spin Hall effect of light. The first term is the optical path length and its variation yields

$$\frac{1}{2}\delta \int \dot{x}^{\mu}\dot{x}_{\mu}d\lambda = \int \dot{x}_{\mu}\frac{D\delta x^{\mu}}{D\lambda}d\lambda$$

$$= -\int \frac{D^{2}x_{\mu}}{D\lambda^{2}}\delta x^{\mu}d\lambda. \quad (49)$$

Similarly, the second term resembles the Berry connection of optics (see Sec. IV C 2), and its variation gives

$$\frac{1}{\omega}\delta \int b_{\alpha}\dot{x}^{\alpha}d\lambda = \frac{1}{\omega}\int \delta b_{\alpha}\dot{x}^{\alpha}d\lambda + \frac{1}{\omega}\int b_{\alpha}\frac{D\delta x^{\alpha}}{D\lambda}d\lambda 
= \frac{1}{\omega}\int b_{\alpha;\beta}\dot{x}^{\alpha}\delta x^{\beta}d\lambda - \frac{1}{\omega}\int b_{\beta;\alpha}\delta x^{\beta}\dot{x}^{\alpha}d\lambda.$$
(50)

Thus, the variational principle  $\delta S = 0$  gives

$$\frac{D^2 x_{\mu}}{D\lambda^2} + \frac{1}{\omega} \left( b_{\mu;\nu} - b_{\nu;\mu} \right) \dot{x}^{\nu} = 0.$$
 (51)

One can also show that simplification of Eq. (47) gives this exact same equation [27], as should be the case. In the subleading order geometric optics approximation, the action acquires a new topological term depending on the wave polarization (because the action for the left-handed circularly polarized waves would be the same except for the replacement  $\omega \to -\omega$ ). This term gives the deflection of the ray trajectory in the transverse direction. The resulting phenomenon is called the spin Hall effect because of the coupling of spin with the curved ray trajectory. As could be seen from Eq. (46), the topological term makes velocity and momentum noncollinear, which is also the characteristic of waves travelling in anisotropic media (see, for example, [44]).

#### 2. Propagation equation in the subleading order

To calculate the subleading order terms in the geometric optics approximation, we take the dispersion relation of Eq. (14)

$$\left(l_{0\mu} + \frac{1}{\omega}(l_{1\mu} - b_{\mu})\right) \left(l_{0}^{\mu} + \frac{1}{\omega}(l_{1}^{\mu} - b^{\mu})\right) = \dot{x}_{\mu}\dot{x}^{\mu} = 0,$$
(52)

where we have used Eq. (46). We can see that in the leading order in  $1/\omega$ ,  $\dot{x}^\mu = l_0^\mu$  is the tangent vector. This equation suggests that the electromagnetic wave trajectory is still null in the spin optics approximation. However, it is not a geodesic, as evidenced from the equation

$$\frac{D\dot{x}^{\mu}}{D\lambda} = \frac{1}{\omega} \left( l_{1;\nu}^{\mu} - b_{;\nu}^{\mu} \right) l_{0}^{\nu}. \tag{53}$$

Comparing this with Eq. (51), we get  $l_{1\alpha;\beta} = b_{\beta;\alpha}$ . Further simplification of  $b_{\beta;\alpha} - b_{\alpha;\beta} := k_{\alpha\beta}$  gives

$$k_{\alpha\beta} = -iR_{\alpha\beta\mu\nu}m^{\mu}\tilde{m}^{\nu} + i\left(\tilde{m}^{\nu}_{;\alpha}m_{\nu;\beta} - \tilde{m}^{\nu}_{;\beta}m_{\nu;\alpha}\right). \quad (54)$$

We substitute this back into Eq. (53) to obtain

$$\frac{D^2 x^{\alpha}}{D\lambda^2} = -\frac{i}{\omega} R^{\alpha}_{\beta\mu\nu} m^{\mu} \tilde{m}^{\nu} l_0^{\beta} \approx -\frac{i}{\omega} R^{\alpha}_{\beta\mu\nu} l_0^{\beta} m_0^{\mu} \tilde{m}_0^{\nu}. \tag{55}$$

Thus, in the spin optics approximation, light travels in a null but nongeodesic trajectory. Let us interpret this result by comparing it with the related phenomena in condensed matter physics. The Lagrangian corresponding to the action of Eq. (48) could be written as

$$\mathcal{L} = \mathcal{L}_0 + \mathcal{L}_1; \qquad \mathcal{L}_0 = \frac{1}{2}\dot{x}^{\alpha}\dot{x}_{\alpha},$$

$$\mathcal{L}_1 = \frac{1}{\omega}b_{\alpha}\dot{x}^{\alpha} = -\frac{1}{\omega}\mathscr{A}_{\alpha}\dot{x}^{\alpha}, \quad (56)$$

where  $\mathcal{L}_0$  is the Lagrangian corresponding to the leading order geometric optics and  $\mathcal{L}_1$  gives the spin-orbit coupling. Here,  $\mathscr{A}_{\alpha} = -b_{\alpha} = -i\tilde{m}^{\beta}m_{\beta;\alpha}$  could be identified with the Berry gauge field (this has the same form as the spin-orbit interaction of light in gradient-index medium and spin-orbit interaction of electrons occurring in Dirac equation, see, for example, Refs. 37, 43, 45, and 46). The nonrelativistic version of  $\mathcal{L}_1$  appears in the theory of spinning particles in [43, 47] (also see, for example, [48, 49]).  $\mathcal{L}_1$  introduces an additional polarization-dependent wave phase, which could be explained as the Berry phase. This Berry phase manifests itself dynamically, thereby inducing an additional term in the equation of motion of the ray trajectory that describes the spin Hall effect. Thus, the Berry phase and spin Hall effect together characterize the spin-orbit interaction of electromagnetic waves.

Berry connection  $\mathscr{A}_{\alpha}$  appears in the Lagrangian as an external vector potential affecting the light trajectory. The curvature associated with the Berry connection can be defined as

$$\frac{\partial \mathcal{A}_{\alpha}}{\partial x^{\beta}} - \frac{\partial \mathcal{A}_{\beta}}{\partial x^{\alpha}} = b_{\beta;\alpha} - b_{\alpha;\beta} \equiv k_{\alpha\beta}.$$
 (57)

This quantity is known by the name of Berry curvature and plays the role of a field strength tensor corresponding to the vector potential  $\mathcal{A}_{\alpha}$ .

#### 3. Polarization equation in the subleading order

The polarization vector depends only on the direction of the ray trajectory (or the momentum of photons). The momentum of free particles propagating in curved spacetime is a function of position only. Therefore, the Berry connection determines the evolution of the wave polarization in curved spacetime. Let us substitute  $w^{\alpha} = l_0^{\beta} l_{;\beta}^{\alpha}$  from Eq. (53) into the Eqs. (26) to obtain equations for the evolution of the polarization vector

$$l_{0}^{\beta}n_{;\beta}^{\mu} = 0,$$

$$l_{0}^{\beta}m_{;\beta}^{\mu} = \frac{1}{\omega} \left( l_{1;\alpha}^{\beta} - b_{;\alpha}^{\beta} \right) l_{0}^{\alpha}m_{\beta}n^{\mu}$$

$$= \frac{i}{\omega} R_{\alpha\beta\gamma\delta} l_{0}^{\alpha}m_{0}^{\beta}m_{0}^{\gamma}\tilde{m}_{0}^{\delta}n_{0}^{\mu},$$

$$l_{0}^{\beta}\tilde{m}_{;\beta}^{\mu} = \frac{1}{\omega} \left( l_{1;\alpha}^{\beta} - b_{;\alpha}^{\beta} \right) l_{0}^{\alpha}\tilde{m}_{\beta}n^{\mu}$$

$$= -\frac{i}{\omega} R_{\alpha\beta\gamma\delta} l_{0}^{\alpha}\tilde{m}_{0}^{\beta}\tilde{m}_{0}^{\gamma}m_{0}^{\delta}n_{0}^{\mu}.$$
(60)

These equations assure that, up to the subleading order in  $1/\omega$ , the set of tetrads  $(\dot{x}^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$  satisfies the normalization and orthogonality relations in Eqs. (16)-(18) throughout the ray. To verify this, we first simplify Eq. (59) as

$$l_0^{\beta} m_{;\beta}^{\mu} \approx \frac{1}{\omega} l_0^{\beta} m_{1;\beta}^{\mu} \approx \frac{1}{\omega} l_0^{\beta} (l_1^{\alpha} - b^{\alpha})_{;\beta} m_{0\alpha} n_0^{\mu}.$$
 (61)

We can use the fact that the covariant derivatives of  $m_{0\alpha}$  and  $n_0^{\mu}$  are zero to write

$$m_1^{\mu} = (l_1^{\alpha} - b^{\alpha}) \, m_{0\alpha} n_0^{\mu}. \tag{62}$$

We simplify Eqs. (58) and (60) in a similar way to obtain

$$n_1^{\mu} = 0, \qquad \tilde{m}_1^{\mu} = (l_1^{\alpha} - b^{\alpha}) \, \tilde{m}_{0\alpha} n_0^{\mu}, \tag{63}$$

respectively. Noting that the Fermi propagated tetrad is constructed in Sec. IV A in such a way that it satisfies  $w^{\alpha}l_{0\alpha}=0=w^{\alpha}n_{0\alpha}$ , we can also write the subleading order of its component  $\dot{x}^{\alpha}$  differently. Therefore, we can write  $w^{\alpha}$  as

$$w^{\alpha} \equiv \frac{1}{\omega} l_0^{\beta} (l_1^{\alpha} - b^{\alpha})_{;\beta} = -\tilde{\kappa} m_0^{\alpha} - \kappa \tilde{m}_0^{\alpha},$$

$$\kappa = -\frac{1}{\omega} m_0^{\alpha} l_0^{\beta} (l_{1\alpha} - b_{\alpha})_{;\beta}. \quad (64)$$

This allows one to write

$$(l_1^{\alpha} - b^{\alpha}) = \tilde{m}_0^{\beta} (l_{1\beta} - b_{\beta}) \, m_0^{\alpha} + m_0^{\beta} (l_{1\beta} - b_{\beta}) \, \tilde{m}_0^{\alpha}. \tag{65}$$

We can easily see that the subleading order correction of the tetrad  $(\dot{x}^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$ , explicitly presented in Eqs. (62), (63) and (65) satisfy the scalar products of Eqs. (16), (17) and (18). The leading order terms of this tetrad are obviously the tetrad  $(l_0^{\alpha}, n_0^{\alpha}, m_0^{\alpha}, \tilde{m}_0^{\alpha})$  of Sec. IV A. Moreover, the subleading order terms of the Lorenz condition Eq. (12) gives

$$\frac{a_{;\mu}}{a}m_0^{\mu} = -m_{0;\mu}^{\mu} - ib_{\mu}m_0^{\mu}.$$
 (66)

The field is not self-dual in the subleading order in  $1/\omega$ , since all the polarization Eqs. (32)-(34) are not satisfied in the limit of spin optics (see Appendix B).

### 4. Self-dual solution up to the subleading order

The tetrad  $(\dot{x}^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$ , satisfying the scalar products of Eqs. (16), (17) and (18) is not the self-dual solution of the Maxwell equations. However, a self-dual solution of the Maxwell equations in Eqs. (4) and (5) should exist for  $J^{\alpha}=0$  in the subleading order geometric optics approximation. One can obtain this self-dual solution by first introducing the Fermi-like derivative operator

$$\mathcal{D}'_{l}A^{\alpha} = l_{0}^{\beta}A^{\alpha}_{;\beta} - w_{\beta}A^{\beta}n^{\alpha} + A^{\beta}n_{\beta}w^{\alpha} - \frac{i}{\omega}\left(\lambda_{;\mu}l^{\mu}m_{\beta}A^{\beta}m^{\alpha} - \tilde{\lambda}_{;\mu}l^{\mu}\tilde{m}_{\beta}A^{\beta}\tilde{m}^{\alpha}\right). \tag{67}$$

The vanishing of the Fermi-like derivative  $\mathcal{D}_{1}^{\prime}A^{\alpha}=0$  gives

$$l_0^{\beta} A_{;\beta}^{\alpha} = w_{\beta} A^{\beta} n^{\alpha} - A^{\beta} n_{\beta} w^{\alpha} + \frac{i}{\omega} \left( \lambda_{;\mu} l^{\mu} m_{\beta} A^{\beta} m^{\alpha} - \tilde{\lambda}_{;\mu} l^{\mu} \tilde{m}_{\beta} A^{\beta} \tilde{m}^{\alpha} \right), \quad (68)$$

and this implies that the scalar product of any two tetrad components  $(\dot{x}^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$  is constant except that of  $m^{\alpha}$  with itself and of  $\tilde{m}^{\alpha}$  with itself. To see this, we calculate

$$(a^{\alpha}b_{\alpha})_{;\beta}l_{0}^{\beta} = a^{\alpha}b_{\alpha;\beta}l_{0}^{\beta} + b^{\alpha}a_{\alpha;\beta}l_{0}^{\beta}$$
$$= \frac{2i}{\omega}\left(\lambda_{;\mu}l^{\mu}m_{\beta}a^{\beta}m^{\alpha}b_{\alpha} - \tilde{\lambda}_{;\mu}l^{\mu}\tilde{m}_{\beta}a^{\beta}\tilde{m}^{\alpha}b_{\alpha}\right). \tag{69}$$

This scalar product is nonzero only if  $a^{\alpha}=b^{\alpha}=m^{\alpha}$  or  $a^{\alpha}=b^{\alpha}=\tilde{m}^{\alpha}$ . For tetrads with vanishing Fermi-like derivatives, if they satisfy the following orthogonality and completeness relations at some point on the ray

$$\dot{x}^{\alpha} m_{\alpha} = \dot{x}^{\alpha} \dot{x}_{\alpha} = \dot{x}^{\alpha} \tilde{m}_{\alpha} = 0, \qquad m^{\alpha} \tilde{m}_{\alpha} = 1, \tag{70}$$

$$n^{\alpha}m_{\alpha} = n^{\alpha}n_{\alpha} = n^{\alpha}\tilde{m}_{\alpha} = 0, \qquad n^{\alpha}l_{\alpha} = -1, \qquad (71)$$

then they satisfy these relations everywhere on the ray. However,  $m^{\alpha}m_{\alpha}\neq 0$  and  $\tilde{m}^{\alpha}\tilde{m}_{\alpha}\neq 0$ , in general, along the circularly polarized ray in the subleading order approximation. This means that the polarization vectors are no more null as in the geometric optics limit. In addition to these, the tetrad evolves as

$$l_0^{\beta} n_{\cdot\beta}^{\alpha} = 0, \tag{72}$$

$$l_0^{\beta} m_{;\beta}^{\alpha} = w^{\beta} m_{\beta} n^{\alpha} - \frac{i}{\omega} \tilde{\lambda}_{;\mu} l^{\mu} \tilde{m}^{\alpha}, \tag{73}$$

$$l_0^{\beta} \tilde{m}_{;\beta}^{\alpha} = w^{\beta} \tilde{m}_{\beta} n^{\alpha} + \frac{i}{\omega} \lambda_{;\mu} l^{\mu} m^{\alpha}. \tag{74}$$

As in Eqs. (62) and (63), we can write

$$m_1^{\mu} = (l_1^{\alpha} - b^{\alpha}) m_{0\alpha} n_0^{\mu} - i\tilde{\lambda} \tilde{m}_0^{\mu}, \qquad n_1^{\mu} = 0,$$
 (75)

$$\tilde{m}_{1}^{\mu} = (l_{1}^{\alpha} - b^{\alpha}) \, \tilde{m}_{0\alpha} n_{0}^{\mu} + i\lambda m_{0}^{\mu}. \tag{76}$$

These tetrads components constitute the solution of the Maxwell equation in the Lorenz gauge, and they are self-dual, as they also satisfy the polarization Eqs. (32)-(34). Therefore, they provide a solution for the propagation of right-handed circularly polarized electromagnetic waves in curved spacetime in the spin optics approximation.

#### 5. Constructing a gauge independent Hamiltonian

The gauge properties of the Berry connection and Berry curvature are related to the choice of the comoving frame. One can introduce noncanonical coordinates, such that the gauge-dependent Berry connection term [50] can be removed from the Hamiltonian of Eq. (45). We consider the following transformation relations to the noncanonical coordinates

$$X^{\alpha} = x^{\alpha},\tag{77}$$

$$L_{\alpha} = l_{0\alpha} + \frac{l_{1\alpha} - b_{\alpha}}{\omega}.$$
 (78)

It is shown in [26] that such substitutions could be generated as the linearization of coordinates changes. The Hamiltonian Eq. (45) under this transformation becomes

$$H'(X,L) = H(x,l) \tag{79}$$

$$=H\left(X^{\alpha}, L_{\alpha} - \frac{l_{1\alpha} - b_{\alpha}}{\omega}\right) \tag{80}$$

$$=H(X,L)-\frac{1}{\omega}\frac{\partial H_0}{\partial L_\alpha}(l_{1\alpha}-b_\alpha) \qquad (81)$$

$$=H_0(X,L), (82)$$

where Eq. (45) is used in obtaining the last equality. Therefore, in the new coordinates  $(X^{\alpha}, L_{\alpha})$ , the Hamiltonian reduces to

$$H'(X,L) = \frac{1}{2}g^{\alpha\beta}(X)L_{\alpha}L_{\beta}.$$
 (83)

The corresponding Hamilton's equations of motion are

$$\begin{pmatrix} \dot{X}^{\alpha} \\ \dot{L}_{\alpha} \end{pmatrix} = T' \begin{pmatrix} \frac{\partial H'}{\partial X^{\beta}} \\ \frac{\partial H'}{\partial L_{\beta}} \end{pmatrix}, \tag{84}$$

where T' is the Poisson tensor in (X, L) [51]. The Poisson tensor could be written as

$$T' = \begin{pmatrix} 0 & \delta_{\beta}^{\alpha} \\ -\delta_{\alpha}^{\beta} & \frac{k_{\alpha\beta}}{\omega} \end{pmatrix}, \tag{85}$$

where  $k_{\alpha\beta}$  is defined in Eq. (54) (it is compared with the Berry curvature term of condensed matter physics in Sec. IV C 2). Hamilton's equations of motion in the new variables are

$$\dot{X}^{\alpha} = L^{\alpha},\tag{86}$$

$$\dot{L}_{\alpha} = \Gamma^{\mu}_{\nu\alpha} L_{\mu} L^{\nu} + \frac{1}{\omega} k_{\alpha\beta} L^{\beta}. \tag{87}$$

Covariant differentiation of Eq. (86) gives

$$\frac{D\dot{X}^{\alpha}}{D\lambda} = \frac{DL^{\alpha}}{D\lambda} = \frac{1}{\omega} k_{\beta}^{\alpha} L^{\beta},\tag{88}$$

which is precisely the trajectory equation given in Eq. (55). This shows that although the Hamiltonian of Eq. (45) contains the gauge-dependent term, the trajectory equation obtained from it is gauge invariant. The reason is, as explained in Eq. (11), U(1) gauge transformation freedom of the polarization basis  $m^{\alpha}$  is constrained by the requirement that it should be Fermi propagated along the trajectory.

# V. STRESS-ENERGY TENSOR UP TO THE SUBLEADING ORDER

To see how energy flows as waves propagate, we calculate the stress-energy tensor up to the subleading order approximation using the field tensor, given in Eq. (30). The stress-energy tensor due to the electromagnetic field is given by the relation

$$4\pi T_{\alpha\beta} = F_{\alpha\gamma} F_{\beta}^{\gamma} - \frac{1}{4} g_{\alpha\beta} F_{\mu\nu} F^{\mu\nu} = \frac{1}{2} Re \left[ \mathcal{F}_{\alpha\gamma}^{+1} \tilde{\mathcal{F}}_{\beta}^{+1\gamma} \right], \tag{89}$$

where Re[z] is the real part of z. This equation can be simplified by substituting  $\mathcal{F}_{\alpha\gamma}^{+1}$  from Eq. (30)

$$4\pi T_{\alpha\beta} = \frac{\omega^2}{2} Re \left[ \mathcal{Z}_{\alpha\gamma} \tilde{\mathcal{Z}}_{\beta}^{\gamma} \right]. \tag{90}$$

As  $\mathcal{Z}_{\alpha\gamma}$  is self-dual, it can be expanded as (see Eq. (29))

$$\mathcal{Z} = \Phi_0 \mathbf{U} + \Phi_1 \mathbf{W} + \Phi_2 \mathbf{V}, \tag{91}$$

where

$$\Phi_{0} = \frac{1}{2} \mathcal{Z}_{\alpha\gamma} \left( l^{\alpha} m^{\gamma} - l^{\gamma} m^{\alpha} \right),$$

$$\Phi_{2} = \frac{1}{2} \mathcal{Z}_{\alpha\gamma} \left( \tilde{m}^{\alpha} n^{\gamma} - \tilde{m}^{\gamma} n^{\alpha} \right),$$

$$\Phi_{1} = -\frac{1}{4} \mathcal{Z}_{\alpha\gamma} \left( m^{\alpha} \tilde{m}^{\gamma} - m^{\gamma} \tilde{m}^{\alpha} - l^{\alpha} n^{\gamma} + l^{\gamma} n^{\alpha} \right). \tag{92}$$

Substituting  $\mathcal{Z}_{\alpha\gamma}$  from Eq. (31), we get

$$\Phi_0 = \frac{ia}{\omega}\sigma, \qquad \Phi_1 = \frac{ia}{2\omega} \left(\chi + 2\tau\right), 
\Phi_2 = a - \frac{ia}{\omega} \left(-\frac{a_{,\alpha}}{a} n^{\alpha} - \tilde{\mu} + \frac{\gamma - \tilde{\gamma}}{2}\right), \tag{93}$$

where  $\sigma = -m^{\alpha}l_{\alpha;\beta}m^{\beta}$ ,  $\chi = \tilde{m}^{\beta}m_{\beta;\alpha}m^{\alpha}$ ,  $\tau = l^{\beta}m_{\beta;\alpha}n^{\alpha}$ ,  $\mu = \tilde{m}^{\beta}n_{\beta;\alpha}m^{\alpha}$  and  $\gamma - \tilde{\gamma} = -2\tilde{m}^{\alpha}m_{\alpha;\beta}n^{\beta}$  are Newman-Penrose scalars. Thus, up to the subleading order in  $1/\omega$ ,

$$4\pi T_{\alpha\beta} = \frac{\omega^2}{2} Re \left[ \Phi_0 \tilde{\Phi}_2 U_{\alpha\gamma} \tilde{V}_{\beta}^{\gamma} + \Phi_1 \tilde{\Phi}_2 W_{\alpha\gamma} \tilde{V}_{\beta}^{\gamma} + \Phi_2 \tilde{\Phi}_0 V_{\alpha\gamma} \tilde{V}_{\beta}^{\gamma} + \Phi_2 \tilde{\Phi}_1 V_{\alpha\gamma} \tilde{W}_{\beta}^{\gamma} + \Phi_2 \tilde{\Phi}_2 V_{\alpha\gamma} \tilde{V}_{\beta}^{\gamma} \right]. \tag{94}$$

However, we have

$$U_{\alpha\gamma}\tilde{V}_{\beta}^{\gamma} = \tilde{m}_{\alpha}\tilde{m}_{\beta}, \quad W_{\alpha\gamma}\tilde{V}_{\beta}^{\gamma} = -\tilde{m}_{\alpha}l_{\beta} - \tilde{m}_{\beta}l_{\alpha},$$

$$V_{\alpha\gamma}\tilde{U}_{\beta}^{\gamma} = m_{\alpha}m_{\beta}, \quad V_{\alpha\gamma}\tilde{W}_{\beta}^{\gamma} = -m_{\alpha}l_{\beta} - l_{\alpha}m_{\beta},$$

$$V_{\alpha\gamma}\tilde{V}_{\beta}^{\gamma} = l_{\alpha}l_{\beta}.$$
(95)

Collecting these values, we obtain, up to the subleading order in  $1/\omega$ ,

$$4\pi T_{\alpha\beta} = \frac{\omega^2 a^2}{2} l_{\alpha} l_{\beta} + \frac{i\omega a^2}{4} \left( 2 \left( \sigma \tilde{m}_{\alpha} \tilde{m}_{\beta} - \tilde{\sigma} m_{\alpha} m_{\beta} \right) - 2 \left( \mu - \tilde{\mu} + \gamma - \tilde{\gamma} \right) l_{\alpha} l_{\beta} - \left( \chi + 2\tau \right) \left( \tilde{m}_{\alpha} l_{\beta} + \tilde{m}_{\beta} l_{\alpha} \right) + \left( \tilde{\chi} + 2\tilde{\tau} \right) \left( m_{\alpha} l_{\beta} + m_{\beta} l_{\alpha} \right) \right)$$

$$= \frac{\omega^2 a^2}{2} L_{\alpha} L_{\beta} + \frac{i\omega a^2}{2} \left( \sigma \tilde{m}_{\alpha} \tilde{m}_{\beta} - \tilde{\sigma} m_{\alpha} m_{\beta} \right), \quad (96)$$

where we redefined the wave vector as

$$L_{\alpha} = l_{\alpha} + \frac{i}{2\omega} \Big( -(\mu - \tilde{\mu} + \gamma - \tilde{\gamma}) l_{\alpha} + (\tilde{\chi} + 2\tilde{\tau}) m_{\alpha} - (\chi + 2\tau) \tilde{m}_{\alpha} \Big). \tag{97}$$

The expression shows that the wave carries transverse stress due to the nonvanishing shear  $\sigma$ . The significance of this result is that we have obtained it without using the solution of the Hamilton-Jacobi equation (44). We could thus interpret this result as an independent verification of the spin Hall effect as depicted by the fact that the transverse stress of the wave is frequency-dependent. The energy-momentum tensor is not unique, in the limit of spin optics, in the sense that the tensor

$$\Theta^{\mu\nu} = T^{\mu\nu} + \nabla_{\lambda} A^{\mu\nu\lambda}; \qquad A^{\mu\nu\lambda} = -A^{\mu\lambda\nu} \tag{98}$$

also satisfies the criterion to be the energy-momentum tensor. Thus, it is not a surprise that with the appropriate choice of  $A^{\mu\nu\lambda}$  we could reduce this energy-momentum tensor into the expression given in Ref. [3], which is derived by a similar mathematical formulation. As expected, the direction of energy flow is not along the direction of the wave vector  $l^{\alpha}$ , a characteristic of waves propagating in anisotropic medium.

#### VI. COMPARISON OF RESULTS

Ref. [26] also developed a covariant formulation of the spin Hall effect. Our results differ slightly from theirs, primarily owing to the difference in our eikonal function Eq. (8) with theirs. In their formulation, the amplitude  $a^{\alpha}$  is assumed to be a function of the phase gradient  $l^{\alpha}$ , that is,  $a^{\alpha} = a^{\alpha} (\lambda, l(\lambda))$ . Using the WKB analysis with this form of eikonal function, the following equation for the ray trajectory was obtained:

$$\dot{x}^{\gamma} = \frac{1}{\omega} \left( l^{\gamma} - B^{\gamma} - l_{\mu} \frac{\partial B^{\mu}}{\partial l_{\gamma}} \right), \tag{99}$$

where

$$B_{\beta}(\lambda, l(\lambda)) = \frac{i}{2} \left( \tilde{m}^{\alpha} \overset{h}{\nabla}_{\beta} m_{\alpha} - m^{\alpha} \overset{h}{\nabla}_{\beta} \tilde{m}_{\alpha} \right) = i \tilde{m}^{\alpha} \overset{h}{\nabla}_{\beta} m_{\alpha},$$

$$\overset{h}{\nabla}_{\beta} m_{\alpha} = \nabla_{\beta} m_{\alpha} + \Gamma^{\mu}_{\beta \nu} l_{\mu} \frac{\partial m_{\alpha}}{\partial l}.$$
(100)

Thus, if we start with the WKB expansion whose amplitude does not depend on the phase gradient, that is, if we take

$$a^{\alpha}(\lambda, l(\lambda)) = a^{\alpha}(\lambda). \tag{101}$$

then we could show that the ray trajectory derived by Ref. [26] would be the same as the propagation equation of Eq. (55).

Ref. [27] started with the following form of the WKB expansion for the vector potential:

$$A^{\alpha} = a^{\alpha}(\lambda)e^{i\mathcal{S}},\tag{102}$$

where  $l_{\alpha}=\mathcal{S}_{;\alpha}/\omega$  is the wave vector, and  $\lambda$  is the usual parameter from above. The only difference in this eikonal function from the one given in Eq. (8) is: here, the phase gradient is not expanded in powers of  $1/\omega$ , that is,  $l^{\alpha}=l_{0}^{\alpha}$ . Thus, all of our Eqs. (52)-(66) for spin optics would be the same as Frolov's if  $l_{1}^{\alpha}=0$ . However, as explained above Eq. (11), we could not take  $l_{1}^{\alpha}=0$  as we are using parallel propagated tetrad in the leading order approximation.

#### VII. DISCUSSION AND CONCLUSIONS

We formulated the theory of spin optics using WKB formalism, where we expand both the amplitude and phase in powers of  $1/\omega$ ,  $\omega$  being the characteristic frequency. This expansion in both the amplitude and phase is necessary if we want to simplify the problem by imposing gauge conditions (for example, we needed to use the Fermi propagated tetrad here) that reduce some of the freedom in the transformation of the null tetrad. This novel application of the WKB formalism is used to derive the evolution equations for both the propagation vector and polarization tensor. We are aware of only the evolution equation for the propagation vector derived in the literature. In the geometric optics approximation, polarization and propagation vectors are two of the components of a parallel propagated null tetrad. This requirement of parallel propagation, which is necessary in the subleading order also, restricts some of the freedom in the transformation of the null tetrad, thereby resulting in the observer/ gauge independent spin Hall effect. We have proved that our result is indeed observer independent in Sec. IV C 5 and thus distinguishes itself from the observer/emitter-dependent effects occurring in the geometric optics regime [54]. Such effects are: 1) the special relativistic effect due to the change in polarization direction occurring from the Wigner rotation and 2) the general relativistic effect due to the absence of a global reference direction, making us unable to determine a unique standard polarization triad in curved spacetime. Moreover, we have pointed out in Ref. [55] that the initially divergent trajectories do not reconverge; the separation between the rays of different frequencies increases with increasing distance. We could draw the trajectories from numerical calculations, confirming that the initially divergent trajectories do not reconverge. This is because the gravitational spin Hall effect results from spinorbit interaction, and neither spin nor orbital angular momentum reverses in direction as the particle crosses the distance of the closest approach, causing the effect of spin-orbit interaction to increase, not decrease.

One of the ways to understand the nature of light propagation in curved spacetime is to carry forward an analogy from condensed matter physics, where the phenomena are well understood and experimentally verified [11, 20, 52, 53]. Notably, this analogy is beneficial when several authors have approached this problem with the eikonal formalism itself and obtained slightly different results. The analogy with the optical Magnus effect from condensed matter physics revealed that the Berry phase and spin Hall effect are closely related to the dynamics of the intrinsic angular momentum of the wave. In particular, the spin Hall effect results from the bending of the trajectory of photons with nonzero spin. Moreover, the transverse deflection of the ray trajectory is proportional to the curvature of the ray [20](or equivalently to the curvature of the spacetime, where the ray is propagating Eq.(55)).

The derivation of the spin Hall effect made here is based on classical arguments. However, one can make the quantum mechanical interpretation in the following manner. The geometric optics approximation is valid in the infinite frequency limit, which implies the evolution of the confined wave packet. The

spin Hall effect arises while extending this approximation to waves of finite but large frequency. This effect is due to the interference of multiple partial plane waves constituting the wave packet that propagates in slightly different directions and thus acquires slightly different geometric phases. Therefore, because of the transverse gradient of the Berry phase, which is the phase of the plane wave in the packet, the spin Hall effect is observed.

#### ACKNOWLEDGMENTS

PKD is supported by an International Macquarie University Research Excellence Scholarship.

#### Appendix A: Geometric optics limit

All the results of geometrical optics could be retrieved by taking Eqs. (12)-(14) and substituting  $m_1^{\beta}=0=l_1^{\beta}$ . The Lorenz condition Eq. (12) and the wave equation Eq. (13) in the leading order approximation in  $\omega$  reduces to

$$l_0^{\alpha} m_{0\alpha} = 0 = l_0^{\alpha} l_{0\alpha}. \tag{A1}$$

Next, we calculate  $\tilde{m}_{0\alpha}j^{\alpha}$  from Eq. (13) by taking  $m_1^{\alpha}=0=l_{1\mu}$  as they are subleading order terms in  $\omega$  and thus irrelevant in geometric optics approximation, to obtain

$$l_{0;\beta}^{\beta} + 2\tilde{m}_{0\alpha}m_{0;\beta}^{\alpha}l_0^{\beta} + 2\frac{a_{;\beta}}{a}l_0^{\beta} = 0.$$
 (A2)

Since the term  $\tilde{m}_{0\alpha}m_{0;\beta}^{\alpha}l_0^{\beta}$  is purely imaginary and the remaining terms

$$l_{0;\beta}^{\beta} + 2 \frac{a_{;\beta}}{a} l_0^{\beta},$$

are purely real, they should be separately zero, thereby giving

$$l_{0;\beta}^{\beta} + 2 \frac{a_{;\beta}}{a} l_0^{\beta} = 0, \qquad m_{0;\beta}^{\alpha} l_0^{\beta} = 0.$$
 (A3)

In the geometric optics approximation, these are the entire set of equations for electromagnetic waves in curved spacetime.

#### Appendix B: Checking self-duality

To verify that the tetrad  $(\dot{x}^{\alpha}, n^{\alpha}, m^{\alpha}, \tilde{m}^{\alpha})$ , satisfying Eqs. (62), (63) and (65) in the subleading order, is not a self-dual solution, let us first calculate Eq. (34)

$$\begin{split} \mathcal{Z}_{\alpha\beta}l^{\alpha}\tilde{m}^{\beta} &= \frac{ia}{\omega} \left( -\frac{a_{;\alpha}}{a} l_{0}^{\alpha} + m_{0\alpha;\beta} l_{0}^{\alpha} \tilde{m}_{0}^{\beta} \right) \\ &= \frac{ia}{\omega} \left( \frac{1}{2} l_{0;\alpha}^{\alpha} - m_{0}^{\alpha} l_{0\alpha;\beta} \tilde{m}_{0}^{\beta} \right) = 0, \quad \text{(B1)} \end{split}$$

where Eq. (A3) is used to obtain this identity. Similarly, Eq.(33) gives

$$\mathcal{Z}_{\alpha\beta} \left( \tilde{m}^{\alpha} m^{\beta} - l^{\alpha} n^{\beta} \right) = \frac{i}{\omega} \left( \frac{a_{;\alpha}}{a} m_0^{\alpha} - m_{0\alpha;\beta} l_0^{\alpha} n_0^{\beta} \right)$$
$$= \frac{i}{\omega} \left( -m_{0;\alpha}^{\alpha} - i b_{\alpha} m_0^{\alpha} - m_{0\alpha;\beta} l_0^{\alpha} n_0^{\beta} \right) = 0, \quad (B2)$$

where Eq. (66) is used to arrive at this identity. Finally, Eq. (32) gives

$$\mathcal{Z}_{\alpha\beta}m^{\alpha}n^{\beta} = \frac{i}{\omega} \left( -m_{0\alpha;\beta}m_0^{\beta}n_0^{\alpha} \right)$$
$$= \frac{i}{\omega} \left( m_0^{\alpha}n_{0\alpha;\beta}m_0^{\beta} \right) \equiv \frac{i}{\omega}\tilde{\lambda}, \quad (B3)$$

where  $\lambda$  denotes the Newman-Penrose scalar. Hence Eq. (32) is not satisfied unless  $\tilde{\lambda}=0$ .

- [1] Misner, C. W., Thorne, K. S., & Wheeler, J. A. 1973, San Francisco: W.H. Freeman and Co., 1973
- [2] Dolan, S. R. 2017, Int. J. Mod. Phys. D 27, 1843010.
- [3] Dolan, S. R., arXiv:1801.02273 (2018).
- [4] Frolov, V. P. & Shoom, A. A. 2011, Phys. Rev. D, 84, 044026.
- [5] Yamamoto, N. 2018, Phys. Rev. D, 98, 061701.
- [6] Yoo, C.-M. 2012, Phys. Rev. D, 86, 084005.
- [7] Shoom, A. A. 2021, Phys. Rev. D, 104, 084007.
- [8] Dahal, P. K., Astronomy, 1(3), 271-287 (2022).
- [9] Hou, S., Fan, X.-L., & Zhu, Z.-H. 2019. Phys. Rev. D, 100, 064028.
- [10] Andersson, L., Joudioux, J., Oancea, M. A., et al. 2021, Phys. Rev. D, 103, 044053.
- [11] Dooghin, A. V., Kundikova, N. D., Liberman, V. S., et al. 1992, Phys. Rev. A, 45, 8204.
- [12] Onoda, M., Murakami, S., & Nagaosa, N. 2004, Phys. Rev. Lett., 93, 083901.
- [13] Liberman, V. S. & Zel'dovich, B. Y. 1992, Phys. Rev. A, 46, 5199.

- [14] Mashhoon, B. 1974, Nature (London), 250, 316.
- [15] Mashhoon, B. 1975, Phys. Rev. D, 11, 2679.
- [16] Ling, X., Zhou, X., Huang, K., et al. 2017, Reports on Progress in Physics, 80, 066401.
- [17] Wunderlich, J., Kaestner, B., Sinova, J., et al. 2005, Phys. Rev. Lett., 94, 047204.
- [18] Kato, Y. K., Myers, R. C., Gossard, A. C., et al. 2004, Science, 306, 1910.
- [19] Hosten, O. & Kwiat, P. 2008, Science, 319, 787.
- [20] Bliokh, K. Y., Niv, A., Kleiner, V., et al. 2008, Nature Photonics, 2, 748.
- [21] Aiello, A. & Woerdman, J. P. 2008, Optics Letters, 33, 1437.
- [22] Bliokh, K. Y., Rodríguez-Fortuño, F. J., Nori, F., et al. 2015, Nature Photonics, 9, 796.
- [23] Aiello, A., Banzer, P., Neugebauer, M., et al. 2015, Nature Photonics, 9, 789.
- [24] Sundaram, G. & Niu, Q. 1999, Phys. Rev. B, 59, 14915.
- [25] Oancea, M. A., Paganini, C. F., Joudioux, J., et al., arXiv:1904.09963 (2019).

- [26] Oancea, M. A., Joudioux, J., Dodin, I. Y., et al. 2020, Phys. Rev. D, 102, 024075.
- [27] Frolov, V. P. 2020, Phys. Rev. D, 102, 084013.
- [28] Takahashi, R., Astrophys. J., 835, 103 (2017).
- [29] Harte, A. I. 2019, General Relativity and Gravitation, 51, 14.
- [30] Gosselin, P., B´erard, A., & Mohrbach, H. 2007, Phys. Rev. D, 75, 084035.
- [31] P. Saturnini, Un mod`ele de particule `a spin de masse nulle dans le champ de gravitation, Thesis, Universit´e de Provence (1976).
- [32] J. M. Souriau, Modele de particule a spin dans le champ ´electromagn´etique et gravitationnel, Ann. Inst. Henri Poincar A 20, 315 (1974).
- [33] Mathisson, M. 2010, General Relativity and Gravitation, 42, 1011.
- [34] Papapetrou, A. 1951, Proceedings of the Royal Society of London Series A, 209, 248.
- [35] Corinaldesi, E. & Papapetrou, A. 1951, Proceedings of the Royal Society of London Series A, 209, 259.
- [36] Dixon, W. G. 1964, Il Nuovo Cimento, 34, 317.
- [37] B´erard, A. & Mohrbach, H. 2006, Physics Letters A, 352, 190.
- [38] Gosselin, P., B´erard, A., & Mohrbach, H. 2007, European Physical Journal B, 58, 137.
- [39] Goldstein, H., Poole, C., & Safko, J. 2002, Classical mechanics (3rd ed.) by H. Goldstein, C. Poolo, and J. Safko. San Francisco: Addison-Wesley, 2002.
- [40] Berry, M. V. 1987, Nature (London), 326, 277.
- [41] Zel'dovich, B. Y. & Kundikova, N. D. 1995, Quantum Electronics, 25, 172.

- [42] Vinitski˘ı, S. I., Derbov, V. L., Dubovik, V. M., et al. 1990, Soviet Physics Uspekhi, 33(6), 403.
- [43] Duval, C., Horv´ath, Z., & Horv´athy, P. A. 2006, Phys. Rev. D, 74, 021701.
- [44] Ziman, J. M., Principles of the Theory of Solids. Cambridge, UK: Cambridge University Press, November 1979., 448.
- [45] Bliokh, K. Y., Gorodetski, Y., Kleiner, V., et al. 2008, Phys. Rev. Lett., 101, 030404.
- [46] Spohn, H. 2000, Annals of Physics, 282, 420.
- [47] Y Bliokh, K. 2009, Journal of Optics A: Pure and Applied Optics, 11, 094009.
- [48] Fanelli, R. 1975, Journal of Mathematical Physics, 16, 1729.
- [49] Bhandari, R. 1997, Phys. Rep., 281, 1.
- [50] Littlejohn, R. G. & Flynn, W. G. 1991, Phys. Rev. A, 44, 5239.
- [51] Marsden, J. E. & Ratiu, T. S., Introduction to Mechanics and Symmetry: A Basic Exposition of Classical Mechanical Systems, Vol. 17 (Springer Science & Business Media, 2013).
- [52] Volyar, A. V., Zhilaitis, V. Z., Shvedov, V. G., et al. 1998, Optika Atmosfery i Okeana, 11, 1199.
- [53] Kundikova, N. D., & Chaptsova, G. V. 1999, J. Opt. A: Pure Appl. Opt., 1, 341.
- [54] Dahal, P. K. & Terno, D. R. 2021, Phys. Rev. A, 104, 042610.
- [55] Dahal, P. K. & Terno, D. R. 2021, arXiv:2111.03849.