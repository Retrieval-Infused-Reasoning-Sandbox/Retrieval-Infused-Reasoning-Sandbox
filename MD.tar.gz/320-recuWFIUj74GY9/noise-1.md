# An overview of the gravitational spin Hall effect

Marius A. Oancea,1, <sup>∗</sup> Claudio F. Paganini,2, † J´er´emie Joudioux,1, ‡ and Lars Andersson1, § <sup>1</sup>Max Planck Institute for Gravitational Physics (Albert Einstein Institute), Am M¨uhlenberg 1, D-14476 Potsdam, Germany <sup>2</sup>School of Mathematical Sciences, 9 Rainforest Walk, Monash University, Victoria 3800, Australia

In General Relativity, the propagation of electromagnetic waves is usually described by the vacuum Maxwell's equations on a fixed curved background. In the limit of infinitely high frequencies, electromagnetic waves can be localized as point particles, following null geodesics. However, at finite frequencies, electromagnetic waves can no longer be treated as point particles following null geodesics, and the spin angular momentum of light comes into play, via the spin-curvature coupling. We will refer to this effect as the gravitational spin Hall effect of light. Here, we review a series of theoretical results related to the gravitational spin Hall effect of light, and we compare the predictions of different models. The analogy with the spin Hall effect in Optics is also explored, since in this field the effect is well understood, both theoretically and experimentally.

#### CONTENTS

| Introduction                                                        | 2  |
|---------------------------------------------------------------------|----|
| Spin Hall effects                                                   | 2  |
| Gravitational spin Hall effect                                      | 3  |
| Overview                                                            | 4  |
| 1. SHE-L in Inhomogeneous Optical Media                             | 5  |
| 1.1. Angular Momentum of Light                                      | 5  |
| 1.2. Berry Phase                                                    | 7  |
| 1.3. SHE-L Equations of Motion                                      | 9  |
| 1.4. Treating Curved Spacetime as an Effective Inhomogeneous Medium | 15 |
| 2. Spinning Particles in the Pole-Dipole Approximation              | 15 |
| 2.1. Mathisson–Papapetrou–Dixon–Tulczyjew Equations                 | 16 |
| 2.2. Souriau–Saturnini Equations                                    | 18 |
| 3. G-SHE from Relativistic Quantum Mechanics                        | 20 |
| 3.1. Photons in a Static Gravitational Field                        | 21 |
| 3.2. Predictions of the theory                                      | 22 |

<sup>∗</sup> marius.oancea@aei.mpg.de

claudio.paganini@monash.edu

jeremie.joudioux@aei.mpg.de

lars.andersson@aei.mpg.de

| 4. G-SHE from Geometrical Optics                           | 24 |
|------------------------------------------------------------|----|
| 4.1. Geometrical Optics and Gravitational Faraday Rotation | 25 |
| 4.2. Modified Geometrical Optics                           | 28 |
| 5. Linking the Models                                      | 30 |
| 5.1. MPD – Dirac Equivalence from the Quantum Perspective  | 30 |
| 5.2. MPD – Dirac Equivalence using WKB                     | 33 |
| 6. Discussion                                              | 37 |
| 6.1. Apparent superluminal motion                          | 37 |
| 6.2. Comparison                                            | 38 |
| Acknowledgements                                           | 39 |
| A. Specific Spacetimes                                     | 39 |
| References                                                 | 41 |

#### INTRODUCTION

In General Relativity, the motion of free falling particles is described by causal geodesics. A priori, this motion does not take into account the internal structure of these particles. However, it should be expected that the internal structure, such as the spin degree of freedom, has an influence on the motion, as is the case in other fields, such as Optics and Condensed Matter Physics. In General Relativity, attempts to describe how this internal structure corrects the motion of a body has, for instance, been addressed by Mathisson, Papapetrou, and Dixon, in their celebrated equations. Nonetheless, there exist numerous examples where the spin degree of freedom affects the dynamics of fields and particles. One such important effect is the spin Hall effect.

# Spin Hall effects

In Condensed Matter Physics, the spin Hall effect (SHE) of electrons was first predicted in 1971 [73, 74], and describes the appearance of a spin current, transverse to the electric charge current propagating in a material. The effect was first observed by Bakun et al. in 1984 [12] as the inverse spin Hall effect, and only later on, in 2004, was the direct spin Hall effect observed in semiconductors [108]. The source of this effect is the relativistic spin-orbit coupling between a particle's spin and its center of mass motion inside a potential. Detailed reviews about the SHE of electrons can be found in [72, 176].

A similar effect, called the spin Hall effect of light (SHE-L), is present in the case of electromagnetic waves propagating inside an inhomogeneous optical medium. In this case, the spin-orbit coupling comes from the interaction of the polarization degree of freedom with the gradient of the refractive index of the medium, resulting in a transverse shift of the wave packet motion, in a direction perpendicular to the gradient of the refractive index. The first known forms of a SHE-L are the Goos–H¨anchen effect [89], originally reported in 1947, and the Imbert-–Fedorov effect [81, 103], reported in 1955. These effects involve polarization-dependent transverse shifts of light beams undergoing refraction or total internal reflection. A recent review of these effects can be found in [34]. Later on, polarization-dependent propagation of light inside an inhomogeneous optical medium was reported under the name "optical Magnus effect" [65, 116], in analogy with the Magnus effect experienced by spinning objects moving through a fluid. This was followed by the work of Onoda et al. [137] (who introduced the term "Hall effect of light"), Bliokh et al. [35–37] and Duval et al. [66, 68, 69]. The first experimental observation of the SHE-L came in 2008 [37, 102]. Reviews about the current state of the research can be found in [39, 119].

#### Gravitational spin Hall effect

The purpose of this paper is to review the existing attempts to describe a gravitational spin Hall effect (G-SHE). Considering the dynamics of a localized wave packets or a spinning particle, by G-SHE we mean any spin dependent correction of this dynamics, in comparison to the dynamics of a scalar field or geodesic motion. This should extend to General Relativity the spin Hall effects known from Condensed Matter Physics and Optics. The role of the inhomogeneous medium is now played by spacetime itself, and the spin-orbit coupling is a consequence of the interaction between the spin degree of freedom and the curvature of spacetime. This effect is expected to be present for all spin-fields (some examples are the Dirac field, electromagnetic waves and linear gravitational waves) propagating in a non-trivial, fixed spacetimes. Throughout this review, our main focus will be on the G-SHE of light, since the corresponding effects for other spin-fields are similar, and most of the relevant literature focuses on the propagation of light, and electromagnetic waves in general.

One motivation for studying the G-SHE comes from the fact that electromagnetic waves propagating in curved spacetimes are formally described by the same set of equations as electromagnetic waves propagating inside some optical medium, in flat spacetime. The properties of the optical medium can be related to the components of the metric tensor describing the curved spacetime. The experimental observation of the SHE-L in inhomogeneous optical media, together with the correspondence to curved spacetimes, suggests that this effect might as well play a role for waves propagating in curved spacetimes, in which context it is usually neglected. It is conceivable that the G-SHE might have experimentally observable consequences, for example, in the form of corrections to gravitational lensing.

However, in curved spacetime new conceptual difficulties emerge. For example, in inhomogeneous optical media, the modification of the ray trajectories of light does not present a problem for the theory, as light is slowed down, and a modified trajectory is expected to remain well within the domain permitted by causality. On the other hand, when we are looking at the trajectories of light in curved spacetimes, we are usually talking about null geodesics. If we consider modifications of the null geodesics by the G-SHE, we have to keep in mind that light beams are approximate solutions to Maxwell's equations, and that Maxwell's equations do respect the universal speed limit.

Various approaches have been proposed in the literature to describe the G-SHE. Based on the used methods, they can be grouped as follows:

- The Mathisson–Papapetrou–Dixon (MPD) equations, or their equivalent form for massless particles, the Souriau–Saturnini (SouSa) equations. These are based on a multipole expansion around a trajectory. The discussion will be mainly based on the work of Souriau [179], Saturnini [159], and Duval et al. [70, 71], since these are the main approaches for the massless case.
- What we will refer to as the quantum mechanical approach, which is based on methods adapted from Relativistic Quantum Mechanics, such as the Foldy–Wouthuysen transformation, and semiclassical Hamiltonians with Berry phase terms. We will mainly focus on the results of Gosselin et al. [19, 93].
- The geometrical optics approach, which is based on next to leading order corrections in the WKB expansion<sup>1</sup> . The main focus will be on the modified geometrical optics approach proposed by Frolov et al. [85], and later developed by Yoo [194], and Dolan [62, 63].

However, little has been said about how these different approaches relate to each other, despite the fact that they do not all arrive at the same results. The goal of this paper is to collect these results, and provide a systematic picture of the existing G-SHE theory. Since some of these theoretical models have contradictory predictions, it is important to understand the assumptions and motivation behind each model, as well as their limitations. Even though we are currently far from a complete understanding of the G-SHE, our hope is that this discussion will serve as a starting point, ultimately leading towards a deeper understanding of the effect.

Finally, we would like to emphasize that the effect under consideration here is purely classical. Quantum electrodynamics corrections to the trajectories of photons, such as considered in [46, 47, 55, 114, 165–168], that violate causality [64, 111, 165, 169], will not be the subject of our discussion.

# Overview

We start in section 1 with a discussion about the SHE-L in inhomogeneous optical media, which has been well studied both theoretically and experimentally. In particular, we discuss the different types of angular momentum of light, the Berry phase, and the equivalence between Maxwell's equations in curved spacetimes, and Maxwell's equations inside some optical medium. We also present a derivation of the SHE-L equations of motion, and discuss the existing experimental results. In section 2, we discuss the MPDT and the SouSa equations, and present some of the known theoretical predictions. In section 3, we introduce the quantum mechanical approach. In

<sup>1</sup> We will use the terms WKB approximation, eikonal approximation, geometrical optics approximation, Gaussian beam approximation as more or less synonymous. Some authors differentiate between them based on the number of terms retained or whether the phase function is real or complex. However, to us, these distinctions seem to be inconsistent in the literature and as far as we are aware the preference for one or the other names is just depending on the different communities. Therefore we decided to use them interchangeably.

section 4, we discuss the geometrical optics approximation for Maxwell's equations. In section 5 we present the known equivalence between geometrical optics and the linearized MPDT equations, as well as the equivalence between the quantum mechanical approach and the linearized MPDT equations for massive particles. Finally, in section 6 we will discuss the relation between the different approaches towards the G-SHE.

# 1. SHE-L IN INHOMOGENEOUS OPTICAL MEDIA

In this section, we briefly present some basic features of the SHE-L in inhomogeneous optical media. At first glance this may appear disconnected from our main goal of investigating effects in curved spacetime. However, the concepts and methods described in this section are expected to apply in a General Relativistic context as well. We believe that the development and understanding of the G-SHE will benefit from analogies with Optics and Condensed Matter Physics, where the theory is in a more mature state, and SHEs have been experimentally observed.

We start by discussing the different types of the angular momentum that electromagnetic waves can carry, and how the spin-orbit interactions of light result from the conservation of the total angular momentum. Next, the notion of the Berry phase is introduced, and its relation to the SHE-L is explained. A derivation of the SHE-L equations of motion is presented, based on the work of Ruiz and Dodin [153]. We believe this to be a transparent derivation, showing how the SHE-L arises from Maxwell's equations, without having to introduce any Quantum Mechanical notions. We will close this section by discussing the connection between Maxwell's equations in curved spacetime and Maxwell's equations in flat spacetime, in the presence of an inhomogeneous optical medium. This will serve as one of the main motivations for studying SHEs in curved spacetime. A more extended presentation of the SHE-L can be found in [39, 176] and references therein.

# 1.1. Angular Momentum of Light

It is well known that electromagnetic waves can carry angular momentum [105]. Following classical Maxwell's theory, the angular momentum density is given by the cross product of position vector x with the Poynting vector E × B. The total angular momentum of the electromagnetic field is the space integral of this quantity [105]:

$$\mathbf{J} = \epsilon_0 \int \mathbf{x} \times (\mathbf{E} \times \mathbf{B}) \, dx^3, \tag{1}$$

where <sup>0</sup> is the vacuum permittivity. Furthermore, the total angular momentum can be split into two parts:

$$\mathbf{J} = \mathbf{S} + \mathbf{L} = \epsilon_0 \int (\mathbf{E} \times \mathbf{A}) dx^3 + \epsilon_0 \sum_{i=1}^3 \int E_i (\mathbf{x} \times \nabla) A_i dx^3.$$
 (2)

The first term, S, represents the spin angular momentum, and can be associated with the polarization of the electromagnetic wave. The second term, L, represents the orbital angular momentum, and was mostly ignored until the early 1990s, when it was shown that Laguerre– Gaussian light beams carry well defined spin and orbital angular momentum [2]. Detailed reviews about how the angular momentum of light shaped the last 25 years of developments in the science of light, covering both theoretical and experimental ground, can be found in [6, 18, 38].

When considering the propagation of light in inhomogeneous optical media, it is convenient to adopt the paraxial beam approximation. This means that the considered electromagnetic wave packet does not spread significantly during its propagation, so it can effectively be described by a ray trajectory. Within this approximation, considering a beam with mean wave vector P (and P = |P|), the total angular momentum of light can be split into three distinct components [38, 39]:

• Spin angular momentum (SAM): this corresponds to the first term in equation (2), and it is related to the polarization of electromagnetic waves. The SAM per photon can take values σ = ±~, and in flat spacetime it is aligned with the direction of propagation of the beam:

$$\mathbf{S} = \sigma \frac{\mathbf{P}}{P}.\tag{3}$$

• Intrinsic orbital angular momentum (IOAM): this is characteristic for electromagnetic beams with helical wavefronts, such as Laguerre–Gaussian [2], Bessel [189] or exponential beams [26]. Beams with IOAM are generally described by a topological charge l, which represents the twisting degree of the wavefronts. The IOAM per photon can take any integer value l = 0, ±~, ±2~, ..., and in flat spacetime it is aligned with the direction of propagation of the beam:

$$\mathbf{L_{int}} = \ell \frac{\mathbf{P}}{P}.\tag{4}$$

• Extrinsic orbital angular momentum (EOAM): this is in direct analogy with the mechanical angular momentum for massive particles, and it is present for beams propagating at a distance from the origin of the coordinate system (the origin might correspond to some special point of an applied external potential). The EOAM is given by the cross product of the centroid of the propagating beam, R, and its momentum, P:

$$\mathbf{L_{ext}} = \mathbf{R} \times \mathbf{P}.\tag{5}$$

The second term in equation (2) is the sum of the IOAM and EOAM. Thus, the total angular momentum of paraxial light beams can be written as:

$$\mathbf{J} = \mathbf{S} + \mathbf{L} = \mathbf{S} + \mathbf{L_{int}} + \mathbf{L_{ext}}.$$
 (6)

The conservation of the total angular momentum will induce the spin-orbit interactions of light, resulting in the SHE-L and other related effects. For example, if we consider a system where only SAM and EOAM are present, the conservation of the total angular momentum will induce the SHE-L. Another possible example is a system with IOAM and EOAM, where conservation of the total angular momentum will result in a similar effect, called the orbital Hall effect [32, 39]. In particular, IOAM plays a special role since the topological charge l can take any integer value, thus one can in principle prepare beams that carry significant amounts of angular momentum. Optical beams with IOAM up to 104~ per photon have been reported [83].

Also, the discussion presented here is not limited to electromagnetic waves. The same splitting of the total angular momentum can be considered for any other spin-field, and conservation of the total angular momentum will give raise to the corresponding spin-orbit interactions. In particular, it is worth emphasizing that electrons carrying IOAM are attracting a lot of attention [17, 28, 115, 126, 183], and gravitational waves carrying IOAM have also been theoretically studied in [13, 27, 29, 112].

## 1.2. Berry Phase

The Berry phase plays a central role in the description of SHEs, both in Optics [33, 39, 137], and in Condensed Matter Physics [19, 130, 175, 192]. For example, by considering relativistic wave equations, such as the Dirac equation or Maxwell's equations, the evolution of the spin degree of freedom will be influenced by the Berry phase, while the spin-orbit coupling will imprint the effect of the Berry phase on the corresponding point-particle equations of motions, resulting in a SHE.

As originally described by Michael Berry [20], the adiabatic evolution of a quantum system changes the wavefunction by an additional phase factor, referred to as Berry phase or geometrical phase. The quantum system is considered to remain in some nth eigenstate of the Hamiltonian Hˆ (R):

$$\hat{H}(\mathbf{R}) |\Psi_n(\mathbf{R})\rangle = E_n(\mathbf{R}) |\Psi_n(\mathbf{R})\rangle,$$
 (7)

where R = R(t) represents the set of parameters varying adiabatically. The adiabatic evolution of the parameters is considered in the sense of Kato [107], and it will define a parallel transport of the wavefunction along the path in parameter space [49]. A well known example of such a system is a spin- <sup>1</sup> 2 particle in a slowly changing magnetic field B(t) [49]. In this case, the set of parameters R(t) is identified with the magnetic field B(t), and for magnetic fields of constant magnitude the parameter space will have S 2 topology.

When the parameters R vary along a closed loop C in parameter space, such that R(0) = R(T), the wavefunction acquires an additional Berry phase γn(C):

$$|\Psi_n(\mathbf{R}(T))\rangle = e^{i\gamma_n(C)} e^{-\frac{i}{\hbar} \int_0^T E_n(\mathbf{R}(t))dt} |\Psi_n(\mathbf{R}(0))\rangle, \qquad (8)$$

$$\gamma_n(C) = i \oint_C \langle \Psi_n(\mathbf{R}) | \nabla_{\mathbf{R}} | \Psi_n(\mathbf{R}) \rangle \cdot d\mathbf{R} = \oint_C \mathbf{A}_{\mathbf{R}} \cdot d\mathbf{R}.$$
 (9)

The Berry phase can be expressed in terms of the Berry vector potential, AR, also called the Berry connection. Furthermore, if we consider an arbitrary hypersurface in parameter space, such that ∂Σ = C, and by using Stokes' theorem, we can rewrite the Berry phase as:

$$\gamma_n(C) = \int_{\Sigma} \nabla \times \mathbf{A_R} \cdot d\mathbf{S} = \int_{\Sigma} \mathbf{F_R} \cdot d\mathbf{S}.$$
 (10)

In the above expression F<sup>R</sup> is called the Berry curvature, since it describes the geometrical properties of the parameter space. In analogy with classical electrodynamics, we can think of A<sup>R</sup> as a "magnetic" vector potential, and of F<sup>R</sup> as the corresponding "magnetic" field in the parameter space. Then, one can regard the Berry phase γn(C) as the flux of F<sup>R</sup> through the surface Σ [49].

Shortly after Berry's original paper, an elegant mathematical formulation was introduced by Barry Simon, who represented the geometrical phase factor by the holonomy of a connection on a Hermitian line bundle [172]. Later on, generalizations of the Berry phase were introduced by Wilczek and Zee for systems with degenerate spectra [191], and by Aharonov and Anandan for systems undergoing general cyclic evolution, that is not necessarily adiabatic [1, 4]. Extensions for noncyclic evolution exist as well [128, 142, 158].

From the definition of the Berry phase presented above, one might conclude that this is a purely Quantum Mechanical effect, and it should not be present at the level of classical theories. However, as it can be seen from [3, 88], the Berry phase naturally occurs in classical field theories as well.

Generally, the study of SHEs involves the propagation of localized wave packets inside some inhomogeneous medium. Nevertheless, it is instructive to look at the following basic example. If we consider electromagnetic waves described by classical Maxwell's equations, we can easily see how the Berry phase arises naturally, without considering any Quantum Mechanical effects [25, 43, 87]. The intrinsic topological structure of Maxwell's equations in vacuum is revealed as soon as one performs a plane wave expansion for the electromagnetic waves. Using this description, electromagnetic waves are characterized by a wave vector k and a complex polarization vector e(k), together with the transversality condition k · e(k) = 0. Furthermore, the space of possible wave vectors is constrained by the dispersion relation (also called on-shell condition) |k| <sup>2</sup> = ω 2 (k), which implies that the k-space will have S 2 topology [43]. The polarization vectors e(k) form a 2-dimensional complex vector space, and due to the transversality condition they will lie in a tangent plane to the spherical space of k vectors.

By identifying the parameter space from the standard treatment of the Berry phase with the kspace of electromagnetic waves, one can see how the Berry phase arises at the classical level [98, 99]. Considering an electromagnetic wave that follows a closed loop in k-space, the polarization vector e(k) will be parallel transported around this loop, and, due to the curvature of the k-space, it will get rotated by a geometrical phase factor proportional to the solid angle enclosed by the loop [49] (a visual example of this process is also presented in [87]). This rotation of the polarization vector was already known in 1938, when it was investigated by Rytov [157], followed by the work of Vladimirskii [188] (for this reason, the effect is generally referred to as Rytov or Rytov–Vladimirskii rotation). The effect was experimentally observed for the first time in 1984 by Ross [150], followed by the work of Chiao, Tomita and Wu [48, 181].

Even though it will not be considered in the present review, a similar effect, called the Pancharatnam phase, will also arise if the polarization state space is identified as the parameter space and adiabatic evolution of the polarization vector is considered [21, 140]. This effect was also observed experimentally [22].

However, when it comes to curved spacetime, there are few theoretical studies discussing the Berry phase, and no experimental results. A first study of the Berry phase for waves propagating in a weak gravitational field was presented in [42], and further developed by several authors [5, 11, 40, 41, 50, 82, 138]. In some of the previously mentioned papers the Berry phase goes by the name "Wigner rotation" or "Wigner phase", but this is just a difference in terminology, arising mainly from the connection with Wigner's little group for massless particles [117]. Even though there is no experimental observation of geometric phases in curved spacetime, there is a recent experimental proposal for measuring the Wigner phase of photons in the gravitational field of the Earth, with a predicted phase difference that could in principle be measured with currently available technology [110].

### 1.3. SHE-L Equations of Motion

The SHE-L in inhomogeneous optical media can be viewed as a consequence of the spin-orbit coupling between SAM and EOAM, resulting in the helicity dependence of the ray trajectories. In terms of the Berry phase, the SHE-L can be described by considering k-space as parameter space. Then the Berry curvature of k-space will act as a "Lorentz force" on "charged" particles, where the "charge" will be represented by the helicity of photons. Thus, the SHE-L can be viewed as a consequence of Berry curvature in momentum space [137].

The point-particle equations of motion describing the SHE-L have been obtained by different authors, using different methods. These include postulating an effective ray Lagrangian or Hamiltonian [137], using geometrical optics with a modified eikonal ansatz on Maxwell's equations [35, 36], or considering a mechanical model for photons, as inspired by the description of spinning particles in General Relativity [68].

However, due to the variety of these different methods, the connection between the SHE-L and Maxwell's equations is not always clear. In order to remove any possible source of confusion, in this section we will review the derivation of the SHE-L in inhomogeneous optical media, as presented by Ruiz and Dodin [153]. Their approach is based on a first-principle variational formulation of the geometrical optics approximation for Maxwell's equations, and reproduces the previously known results of Zel'dovich [65, 116], Onoda [137], Bliokh [35, 36] and Duval [68], without postulating ray Lagrangians or introducing ad hoc modifications of the eikonal ansatz. Then, the SHE-L readily follows from Maxwell's equations, and the classical nature of the effect becomes apparent. Notably this method can also be applied to other field equations [60, 61, 152, 154–156].

Ruiz and Dodin start by considering electromagnetic waves propagating in an isotropic dielectric medium (the case of more general dispersive media can be found in [156]). In this case, the electric and magnetic fields are described by the following equations:

$$\partial_t \mathbf{E} = \frac{c}{\varepsilon} \nabla \times \mathbf{H},\tag{11}$$

$$\partial_t \mathbf{H} = -\frac{c}{\mu} \nabla \times \mathbf{E},\tag{12}$$

where c is the speed of light in vacuum,  $\varepsilon = \varepsilon(\mathbf{x})$  is the electric permittivity, and  $\mu = \mu(\mathbf{x})$  is the magnetic permeability. Following [153], we can introduce the normalized fields  $\mathbf{\bar{E}} = \sqrt{\varepsilon}\mathbf{E}$  and  $\mathbf{\bar{H}} = \sqrt{\mu}\mathbf{H}$ , in order to cast the field equations in the form:

$$\partial_t \mathbf{\bar{E}} = \frac{c}{n} \nabla \times \mathbf{\bar{H}} - \frac{c}{n} \nabla (\ln \sqrt{\mu}) \times \mathbf{\bar{H}}, \tag{13}$$

$$\partial_t \mathbf{\bar{H}} = -\frac{c}{n} \nabla \times \mathbf{\bar{E}} - \frac{c}{n} \nabla (\ln \sqrt{\varepsilon}) \times \mathbf{\bar{E}}, \tag{14}$$

where  $n = \sqrt{\varepsilon \mu}$  is the refractive index of the medium. Note that the second terms in the above equations are proportional to the first order derivatives of the medium properties and thereby are small, albeit not negligible.

It is well known that Maxwell's equations can be cast in a Schrödinger form, and various formulations have been proposed by different authors [23, 24, 56, 87, 177]. In the present case, following [153], the above equations can be rewritten in the following way:

$$i\partial_t \psi = H\psi, \tag{15}$$

where the vector wavefunction  $\Psi$  has 6 components:

$$\psi(\mathbf{x},t) = \begin{pmatrix} \mathbf{\bar{E}} \\ \mathbf{\bar{H}} \end{pmatrix},\tag{16}$$

and the Hamiltonian is a  $6 \times 6$  matrix:

$$H(\mathbf{x}, \hat{\mathbf{k}}) = -\frac{c}{n} \lambda \cdot \hat{\mathbf{k}} + \mathcal{A}, \tag{17}$$

where  $\hat{\mathbf{k}} = -i\nabla$  is the momentum operator,  $\lambda$  are  $6 \times 6$  Hermitian matrices:

$$\lambda = \begin{pmatrix} 0 & i\alpha \\ -i\alpha & 0 \end{pmatrix},\tag{18}$$

$$\alpha_x = \begin{pmatrix} 0 & 0 & 0 \\ 0 & 0 & -i \\ 0 & i & 0 \end{pmatrix}, \qquad \alpha_y = \begin{pmatrix} 0 & 0 & i \\ 0 & 0 & 0 \\ -i & 0 & 0 \end{pmatrix}, \qquad \alpha_z = \begin{pmatrix} 0 & -i & 0 \\ i & 0 & 0 \\ 0 & 0 & 0 \end{pmatrix}, \tag{19}$$

and the matrix  $\mathcal{A}$  has the following form:

$$\mathscr{A} = \begin{pmatrix} 0 & -\boldsymbol{\alpha} \cdot \nabla(\ln\sqrt{\mu}) \\ \boldsymbol{\alpha} \cdot \nabla(\ln\sqrt{\varepsilon}) & 0 \end{pmatrix}. \tag{20}$$

As described in [153], equation (15) can be obtained from a variational formulation, with the action:

$$S = \int \mathcal{L}d^4x,\tag{21}$$

where the Lagrangian density,  $\mathcal{L}$ , takes the following Dirac-like form:

$$\mathscr{Z} = \frac{i}{2} [\psi^{\dagger} \gamma^{\mu} (\partial_{\mu} \psi) - (\partial_{\mu} \psi^{\dagger}) \gamma^{\mu} \psi] + \psi^{\dagger} \mathscr{M} \psi. \tag{22}$$

The gamma matrices are defined as  $\gamma^{\mu} = (\mathbb{I}_6, c\lambda/n)$ , and  $\mathcal{M}$  has the following form:

$$\mathcal{M} = \frac{1}{2n} \begin{pmatrix} 0 & \lambda \\ \lambda & 0 \end{pmatrix} \cdot \nabla \ln \sqrt{\frac{\mu}{\varepsilon}}.$$
 (23)

This variational formulation of Maxwell's equations represents the starting point for the geometrical optics approximation, as described by Ruiz and Dodin in [153]. However, it should be stressed out that having the Lagrangian density written in this particular form is just a matter of convenience and not a strict requirement. An extension of the formalism, that does not rely on any particular form of the Lagrangian density, has been presented in [156].

The following eikonal ansatz is considered:

$$\psi(t, \mathbf{x}) = \xi e^{i\theta/\epsilon},\tag{24}$$

where  $\xi$  is a slowly varying complex amplitude,  $\theta$  is a rapid real phase, and  $\epsilon$  is a dimensionless expansion parameter. As usual, the length scale L over which the properties of the medium vary significantly is assumed to be large in comparison to the wavelength of the electromagnetic wave:

$$\epsilon = \frac{1}{|\mathbf{k}|L} \ll 1. \tag{25}$$

The wave vector is defined as  $\mathbf{k} = \nabla \theta$ , and the frequency is  $\omega = -\partial_t \theta$ . The eigenfrequencies and the corresponding eigenmodes are found from the geometrical optics limit of equation (15), where only terms of order  $\epsilon^0$  are retained. This means that we will neglect the  $\mathscr{A}$  term from the Hamiltonian, since this includes first-order derivatives of the medium properties, and therefore is of order  $\epsilon^1$ . We are left with the following eigenvalue problem:

$$H_0(\mathbf{x}, \mathbf{k})\xi = \omega \xi,$$
 (26)

where  $H_0(\mathbf{x}, \mathbf{k}) = c\lambda \cdot \mathbf{k}/n$ . Since  $H_0$  is a  $6 \times 6$  Hermitian matrix, generally there exist six independent eigenvectors  $h_q$ , which form a complete basis. Two of the eigenvectors will correspond to longitudinal modes, and the other four eigenvectors correspond to transverse modes. Here, we will be interested only in the propagation of transverse electromagnetic modes with positive frequencies  $\omega = k/n$ , thus we will only consider the following two orthonormal eigenvectors [153]:

$$h_1(\mathbf{k}) = \frac{1}{\sqrt{2}} \begin{pmatrix} \mathbf{e_1} \\ \mathbf{e_2} \end{pmatrix}, \qquad h_2(\mathbf{k}) = \frac{1}{\sqrt{2}} \begin{pmatrix} \mathbf{e_2} \\ -\mathbf{e_1} \end{pmatrix}.$$
 (27)

Note that the vectors  $h_{1,2}$  have 6 components and determine a linear polarization basis, while the vectors  $\mathbf{e_{1,2}}$  have 3 components and determine a plane normal to  $\mathbf{e_k} = \mathbf{k}/k$ .

By using the six eigenvectors  $h_q$ , we can expand the complex amplitude as  $\xi = h_q \phi^q$ , where  $\phi^q$  are scalar functions. However, since we are only considering transverse modes with positive frequency, the only active modes will be those corresponding to  $h_{1,2}$ , while the other modes can only become exited through the inhomogeneity of the medium. In this case, the active modes  $h_{1,2}$  are of order  $\epsilon^0$ , while the other modes will be of order  $\epsilon^1$  and can be ignored for the purpose of this calculation [153, 154]. The complex amplitude  $\xi$  can now be written in the following way [153]:

$$\xi = h_1 \phi^1 + h_2 \phi^2 + O(\epsilon) = \Xi \phi + O(\epsilon), \tag{28}$$

where  $\phi$  is a 2 × 1 matrix with complex scalar elements:

$$\phi = \phi(t, \mathbf{x}) = \begin{pmatrix} \phi^1 \\ \phi^2 \end{pmatrix}, \tag{29}$$

and  $\Xi$  is a 6 × 2 matrix having  $h_{1,2}$  as columns:

$$\Xi = \frac{1}{\sqrt{2}} \begin{pmatrix} \mathbf{e_1} & \mathbf{e_2} \\ \mathbf{e_2} & -\mathbf{e_1} \end{pmatrix}. \tag{30}$$

At this point, we are using the basis formed by the polarization vectors of linearly polarized modes, but we can easily move to a circular polarization basis by using the following transformation:

$$\phi(t, \mathbf{x}) = Q\eta(t, \mathbf{x}) = \frac{1}{\sqrt{2}} \begin{pmatrix} 1 & 1\\ i & -i \end{pmatrix} \eta(t, \mathbf{x}). \tag{31}$$

As we will see in what follows, the linear polarization basis is useful for investigating the polarization dynamics, while the circular polarization basis has the advantage that the dynamics of right-handed and left-handed circular polarized eigenmodes is decoupled.

The next step is to insert the eikonal ansatz, as defined in equations (24) and (28), into the Lagrangian density. After introducing a particular frame choice for  $\mathbf{e_{1,2}}(\mathbf{k})$  and moving to a circular polarization basis, the Lagrangian density under the geometrical optics approximation becomes [153]:

$$\mathcal{L} = -\eta^{\dagger} (\partial_t \theta + k/n) \eta + \frac{i}{2} [\eta^{\dagger} (d_t \eta) - (d_t \eta^{\dagger}) \eta] - \eta^{\dagger} \sigma_z \Sigma(\mathbf{x}, \mathbf{k}) \eta, \tag{32}$$

where  $\sigma_z$  is the usual Pauli matrix,

$$d_t = \partial_t + \frac{\mathbf{e_k}}{n} \cdot \nabla, \tag{33}$$

$$\Sigma(\mathbf{x}, \mathbf{k}) = \dot{\mathbf{k}} \cdot \mathbf{A}(\mathbf{k}) = \frac{k}{n^2} \mathbf{A}(\mathbf{k}) \cdot \nabla n, \tag{34}$$

$$\mathbf{A}(\mathbf{k}) = \frac{k_z}{k(k_x^2 + k_y^2)} \begin{pmatrix} k_y \\ -k_x \\ 0 \end{pmatrix}. \tag{35}$$

The first term in equation (32) is of order  $\epsilon^0$  and represents the lowest order geometrical optics approximation, while the following two terms are of order  $\epsilon^1$  and represent polarization-dependent corrections. By introducing the reparametrization  $\eta = z\sqrt{I}$ , where  $I = \psi^{\dagger}\psi$  is the intensity of the wave, and z is a unit complex polarization vector ( $z^{\dagger}z = 1$ ), the Lagrangian can be expressed as:

$$\mathcal{L} = -I \left[ \partial_t \theta + \frac{k}{n} - \frac{i}{2} \left( z^{\dagger} (d_t z) - (d_t z^{\dagger}) z \right) + \Sigma(\mathbf{x}, \mathbf{k}) z^{\dagger} \sigma_z z \right]. \tag{36}$$

At this point, the above equation still represents a field Lagrangian, with the dynamical variables given by I,  $\theta$ , z and  $z^{\dagger}$ . However, since the intensity I is an overall factor, there is a clear way of localizing waves into the point-particle limit. This can be achieved by requiring the intensity I to be sharply localized, and in the point-particle limit approximated with a Dirac delta function:

$$I(t, \mathbf{x}) = \delta^3(\mathbf{x} - \mathbf{X}(t)),\tag{37}$$

where  $\mathbf{X}(t)$  will be the location of the point-particle at time t.

Inserting equations (36) and (37) into the expression of the action, and performing the integration over the spatial coordinates  $\mathbf{x}$ , one obtains [153]:

$$S = \int dt d^3x \mathcal{L} = \int dt L, \tag{38}$$

where L is the corresponding point-particle Lagrangian:

$$L = \int d^3x \mathcal{L} = \mathbf{P} \cdot \dot{\mathbf{X}} - \frac{cP}{n} + \frac{i}{2} (Z^{\dagger} \dot{Z} - \dot{Z}^{\dagger} Z) - \Sigma(\mathbf{X}, \mathbf{P}) Z^{\dagger} \sigma_z Z.$$
 (39)

This is a point-particle Lagrangian, describing the ray dynamics, where the independent variables are  $\mathbf{X}(t)$ ,  $\mathbf{P}(t) = \nabla \theta(t, \mathbf{X}(t))$ ,  $Z(t) = z(t, \mathbf{X}(t))$  and  $Z^{\dagger}(t) = z^{\dagger}(t, \mathbf{X}(t))$ . The ray equations are given by the Euler–Lagrange equations:

$$\dot{\mathbf{P}}(t) = \frac{c\mathbf{P}}{nP} + (\partial_{\mathbf{P}}\Sigma)Z^{\dagger}\sigma_{z}Z,\tag{40}$$

$$\dot{\mathbf{X}}(t) = \frac{cP}{n^2} \nabla n - (\partial_{\mathbf{X}} \Sigma) Z^{\dagger} \sigma_z Z, \tag{41}$$

$$\dot{Z}(t) = -i\Sigma \sigma_z Z,\tag{42}$$

$$\dot{Z}^{\dagger}(t) = i\Sigma Z^{\dagger}\sigma_z. \tag{43}$$

Here, the first terms in equations (40) and (41) are of order <sup>0</sup> and represent the lowest order geometrical optics approximation. The other terms are of order 1 , and determined polarizationdependent corrections to the ordinary ray trajectories. These correction terms represent the SHE-L. If one restricts to rays with either right-hand or left-hand circular polarization, then σzZ = ±Z, and the ray Lagrangian becomes [153]:

$$L = \mathbf{P} \cdot \dot{\mathbf{X}} - \frac{cP}{n} \mp \Sigma(\mathbf{X}, \mathbf{P}) \approx \mathbf{P} \cdot \dot{\mathbf{X}} - \frac{cP}{n} \mp \dot{\mathbf{P}} \cdot \mathbf{A}(\mathbf{P}). \tag{44}$$

In this case, the Euler–Lagrange equations will give the following equations for the ray trajectories:

$$\dot{\mathbf{P}} = \frac{cP}{n^2} \nabla n, \qquad \dot{\mathbf{X}} = \frac{c\mathbf{P}}{nP} \pm \frac{\dot{\mathbf{P}} \times \mathbf{P}}{P^3}.$$
 (45)

These equations reproduce the previous results on the SHE-L in inhomogeneous media [32, 35, 37, 39, 68, 116, 137] (in some cases the equations appear in a slightly different form, but this is just due to a rescaling of the momentum and time in equation (45) [153]), and were derived without introducing any extra phase factors into the eikonal ansatz. The Berry phase is already encoded in the polarization dynamics, and can be explicitly calculated as [153],

$$\Theta(t) = \int_0^t \Sigma(\mathbf{X}(t), \mathbf{P}(t)) dt, \tag{46}$$

where Σ = P˙ · A(P) represents the Berry connection.

In equation (45), the second term on the right hand side of X˙ represents the correction term that determines the SHE-L and can be interpreted as a Lorentz force produced by the Berry curvature in momentum space, with the photon helicity acting as a charge [39]. In the limit of very short wavelengths, λ → 0, the SHE-L is suppressed, and we recover the classical equations of motion for photons in a medium with arbitrary refractive index n. The SHE-L becomes more visible as one increases the wavelength, but one should keep in mind that these equations were derived under the assumption that the wavelength is much smaller than the length scale over which the medium properties varies significantly, as presented in equation (25).

The theoretical predictions of equation (45) were first verified in 2008 by Hosten and Kwait [102]. Their experiment used the technique of quantum weak measurements in order to amplify the small transverse shift coming from the SHE-L. This was followed a few months later by the experiment of Bliokh, Niv, Kleiner and Hasman [37]. In this case, the authors managed to amplify the SHE-L by multiple reflections inside a glass cylinder. Afterwards, the effect was detected by several other groups, using different experimental methods [97, 118, 120, 178]. A more detailed account of the experimental results can be found in [39, 176].

#### 1.4. Treating Curved Spacetime as an Effective Inhomogeneous Medium

One of the main motivations for investigating the possibility of a G-SHE of light comes from the fact that electromagnetic waves propagating in a curved spacetime are formally described by the same set of equations as electromagnetic waves in flat spacetime, propagating inside an inhomogeneous optical medium [23, 24, 147]. This type of analogy was first recognized by Eddington, who suggested that the gravitational light bending around the Sun could also be obtained if we consider an appropriate distribution of a refractive material [77]. This was later developed by Gordon [90], and Plebanski [147]. For a more recent discussion see [23, 24].

Following Plebanski [147], a spacetime described by the metric tensor gµν can be viewed as an effective medium with perfect impedance matching, described by a tensorial permittivity ij , a tensorial permeability µij , and a magnetoelectric coupling vector α<sup>i</sup> (here, Latin indices run from 1 to 3):

$$\epsilon_{ij} = \mu_{ij} = -\sqrt{-\det g} \frac{g_{ij}}{g_{00}}, \qquad \alpha_i = -\frac{g_{0i}}{g_{00}}. \tag{47}$$

This correspondence is an example of what is called analogue gravity [15], where certain properties of a curved spacetime are reproduced in laboratories using other physical systems. Based on this correspondence, and since the SHE-L was predicted and experimentally observed in inhomogeneous optical media, we expect the effect to be present in curved spacetime as well. Several examples supporting this statement will be discussed in the following sections.

However, this analogy has its limitations and it should be used with care. The main limitation is that it breaks covariance, and simply writing the metric using different coordinates can result in analog materials with completely different properties [79].

## 2. SPINNING PARTICLES IN THE POLE-DIPOLE APPROXIMATION

In this section we will discuss the spin-curvature interaction in the pole-dipole approximation for extended test bodies. Since the focus of our review is on the G-SHE of light, we will only touch on the vast literature for massive spinning particles where the results seem of interest to us for the case of massless particles. For an overview of the massive case see [59, 180]. A discussion of the conceptual issues involved when deriving a worldline for an extended spinning body can be found in [185] for the massive case, and [9, 10] for the massless case.

# 2.1. Mathisson–Papapetrou–Dixon–Tulczyjew Equations

The equation for the worldline of a spinning test body in the context of the pole-dipole approximation was first derived by Mathisson [125] and Papapetrou [141] by integrating the conservation law of the energy momentum tensor ∇νT µν for a multipole expansion of the energy momentum tensor T µν. A covariant derivation was first given by Tulczyjew [182] and Dixon [57]. The latter containing multipole expansions to any order, for that see also [173]. There are many alternative derivations in the literature [14, 149, 173, 179, 186]. The Hamiltonian formulation for the MPDT equations in [14], and the systematic presentation of the Hamiltonian for different orders of spin in [186] might be interesting, since the SHE-L equations of motion can also be derived from a Hamiltonian formulation. A particularly transparent derivation can be found in section 2 and 3 of [180], and a slightly more general derivation in section V of [59]. A more mathematical derivation including a full discussion of the symplectic structure of the phase space of the dynamic variables can be found in [179], albeit only available in French. For the definition of multipole moments see [58].

The MPDT equations have been subject to extensive research, and we will use them as a reference for other derivations of spin-curvature effects. Recent interest is heavily focused on extreme mass-ratio scenarios as sources for gravitational waves, see for example [100, 109, 148] and sources therein.

The MPD equations are given by:

$$\dot{p}^{\mu} = -\frac{1}{2} R^{\mu}_{\ \nu\kappa\lambda} u^{\nu} S^{\kappa\lambda},\tag{48}$$

$$\dot{S}^{\alpha\beta} = p^{[\alpha} u^{\beta]},\tag{49}$$

where u <sup>µ</sup> denotes the four-velocity of the particle, i.e. the timelike unit tangent vector of the worldline u <sup>µ</sup>u<sup>µ</sup> = −1, while p µ is the total momentum of the particle. Furthermore, S µν is the totally antisymmetric spin tensor. The system (48)-(49) has 10 equations for 13 unknowns (3 for u µ , 4 for p <sup>µ</sup> and 6 for S µν) and is therefore underdetermined. In particular, we are missing an equation that determines u µ . This is usually fixed with so called spin supplementary conditions (SSC). The most commonly used SSCs are the following ones:

- Tulczyjew–Dixon SSC, S µνp<sup>ν</sup> = 0
- Pirani SSC, S µνu<sup>ν</sup> = 0 [146]
- Corinaldesi–Papapetrou SSC, (∂t)µS µα = 0, for stationary spacetimes.

Note that the worldlines obtained from different SSC do not coincide. They are usually interpreted as different gauge choices for the "center of mass" of the extended bodies. According to Dixon [59], the Tulczyjew–Dixon SSC, S µνp<sup>ν</sup> = 0, is the only SSC that fixes a unique world line for an extended body. For a review on the effect of the different SSCs and their physical interpretation, see [52, 53]. For the Tulczyjew–Dixon SSC, m = p <sup>µ</sup>u<sup>µ</sup> can be interpreted as the mass, which is constant along the worldline. For the Pirani SSC, the mass is given by p <sup>µ</sup>p<sup>µ</sup> = ˜m, which is, again, conserved along the worldline. For both SSCs, the magnitude of the spin, s <sup>2</sup> = 1 2 SµνS µν , is constant along the worldlines. It was shown in [51] that various choices are in fact physically equivalent. Therefore, choosing a SSC comes down to practicality and personal preferences. From equation (49) and the Tulczyjew–Dixon SSC, the following relation between the total momentum and the four-velocity can be derived:

$$p^{\mu} = mu^{\mu} + \dot{S}^{\mu\nu}u_{\nu}, \tag{50}$$

which provides us with an equation to determine u µ . For the Tulczyjew–Dixon SSC, we can define the spin vector S µ in the following way:

$$S^{\mu} = \frac{1}{2m} \epsilon^{\mu\nu\kappa\lambda} p_{\nu} S_{\kappa\lambda}, \qquad S^{\mu\nu} = \frac{1}{m} \epsilon^{\mu\nu\kappa\lambda} p_{\kappa} S_{\lambda}, \tag{51}$$

which also satisfies S <sup>µ</sup>S<sup>µ</sup> = −s 2 . Note that s 2 is a constant of motion along the worldline described by the equations (48), independent of the SSC. Here, αβρσ is the totally antisymmetric Levi–Civita tensor, with ε <sup>0123</sup> = 1/ √ − det g.

To linearize the MPDT equations in spin, s is treated as a small parameter in the equations, and all terms quadratic in s are omitted. One generally considers S <sup>µ</sup> ∝ s, or alternatively S µν ∝ s. Linearized in spin, the MPDT equations then have the following form:

$$\dot{p}^{\mu} \approx -\frac{1}{2} R^{\mu}_{\ \nu\kappa\lambda} u^{\nu} S^{\kappa\lambda},\tag{52}$$

$$\dot{S}^{\alpha\beta} \approx 0, \tag{53}$$

and equivalently

$$\dot{S}^{\alpha} \approx 0. \tag{54}$$

This form is sometimes referred to as Mathisson–Papapetrou–Pirani (MPP) equations. In this case, we have:

$$p^{\mu} \approx m u^{\mu}. \tag{55}$$

Therefore, the Tulczyjew–Dixon SSC, S µνp<sup>ν</sup> = 0, and the Pirani SSC, S µνu<sup>ν</sup> = 0, can be satisfied simultaneously. Hence, when the equations are linearized in spin there is less ambiguity with respect to choosing the correct SSC. We will return to the MPP equations in later sections (5.1, 5.2), where we demonstrate that the MPP equations can be derived from field equations, either by a WKB expansion [8, 151], or by a Foldy–Wouthuysen transformation truncated at linear order in ~, in order to derive "quantum" corrections to geodesic motion.

For readers interested in the application of the MPDT equations in the context of the astrophysically relevant spacetimes, such as the rotating Kerr black holes (A5), [96, 113, 124, 162, 174] and sources therein might be a good start. We will omit a deeper discussion at this point, as the case of massive trajectories is not our main focus here. The interested reader could also consult [54] for an extensive collection of sources on the topic.

Other equations for worldlines of interest in the context of massive spinning bodies have been derived in [75, 76, 184, 185] from a Hamiltonian formulation. The authors start by postulating a phase space consisting of the position coordinate  $x^{\mu}$ , the covariant momentum  $\pi_{\mu}$  and the antisymmetric spin tensor  $\Sigma^{\mu\nu}$ . Then, they postulate antisymmetric Poisson brackets that define a symplectic structure over the phase space. Finally, they choose a Hamiltonian that generates the evolution of the system. The worldline obtained this way is characterized by the fact that the spin tensor  $S^{\mu\nu}$  is covariantly constant along the path. At present, it is unclear to us how this approach relates to the Hamiltonian formalism used in [149, 186]. If the equations obtained in this approach are linearized in spin, they correspond to the MPD equations linearized in spin (52). The case of massless particles has not yet been worked out in this model.

#### 2.2. Souriau-Saturnini Equations

In this section we discuss the pole-dipole approximation for massless particles. We note, as a preliminary comment, that it has been argued in the literature [70, 71, 122, 159] that there is a problem with the equations (56) in flat space, where the equations appear to be singular<sup>2</sup>. The equations (56) have no direct connection to Maxwell's equations. Nevertheless, interesting results have been obtained using this model, hence we include a discussion at this point.

The fact that the MPDT equations can be adapted for massless particles was first mentioned by Souriau [179], and then worked out in detail by Saturnini [159] (both references only available in French). They start with the MPDT equations (48), and assume the Tulczyjew-Dixon SSC,  $S^{\mu\nu}p_{\nu}=0, S^{\mu\nu}\neq 0$ , and for the momentum to be null  $p^{\mu}p_{\mu}=0$ . Then, they obtain the following set of equations, to which we will refer to as the Souriau-Saturnini (SouSa) equations:

$$u^{\mu} = p^{\mu} + \frac{2}{R_{\alpha\beta\lambda\nu}S^{\alpha\beta}S^{\lambda\nu}}S^{\alpha\mu}R_{\alpha\beta\lambda\nu}S^{\lambda\nu}p^{\beta},\tag{56}$$

$$u^{\mu} = p^{\mu} + \frac{2}{R_{\alpha\beta\lambda\nu}S^{\alpha\beta}S^{\lambda\nu}}S^{\alpha\mu}R_{\alpha\beta\lambda\nu}S^{\lambda\nu}p^{\beta},$$

$$\dot{p}^{\mu} = s\frac{\sqrt{-g}\epsilon^{\alpha\beta\rho\sigma}R_{\alpha\beta\lambda\nu}S^{\lambda\nu}R_{\rho\sigma\gamma\delta}S^{\gamma\delta}}{8R_{\alpha\beta\lambda\nu}S^{\alpha\beta}S^{\lambda\nu}}p^{\mu},$$

$$(56)$$

$$\dot{S}^{\mu\nu} = p^{[\mu}u^{\nu]},\tag{58}$$

where q is the metric determinant.

One point to note is that, according to [159], the condition  $p^{\mu}p_{\mu}=0$ , together with the equations (56), implies that  $u^{\mu}u_{\mu} > 0$ , and hence the "massless particles" in this model move on spacelike

<sup>&</sup>lt;sup>2</sup> It is not entirely clear to us whether the equations (56) are indeed singular in the limit of flat spacetime. If we make the replacement  $R_{\alpha\beta\lambda\nu} \to \epsilon R_{\alpha\beta\lambda\nu}$ , no terms with negative powers of  $\epsilon$  appear. Similarly, if we look at Schwarzschild spacetimes (A2), all non-zero components of the Riemann tensor are proportional to the mass M

trajectories. We will discuss in section 6 in what limited way such spacelike trajectories can be considered as valid results for particle trajectories that emerge from a causally well behaved field equation.

In the following, we discuss some applications of the SouSa equations and claims attained thereof. In his thesis [159], Saturnini showed that for a certain choice of initial condition for the spin, a radially ingoing null geodesic would satisfy equation (56) and hence he argued, as a first physical result of the model (56), that the observation of redshift would not change for massless particles with spin. He also observed, in numerical simulations, that for certain initial conditions in Schwarzschild spacetimes, the equations (56) with different helicities produce trajectories that are symmetric with respect to the plane of a reference null geodesic with zero spin. However, he deemed the effect to be too small to be observable.

In [66, 69] Duval et al. reproduce the results of Fedorov [81] and Imbert [103] for the polarization dependent reflection of light, using the framework introduced by Souriau and Saturnini.

In [71], Duval and Sch¨ucker studied the SouSa equations in a Robertson Walker spacetime. By numerically integrating (56) with a non-zero orthogonal component in the spin vector, they obtained spacelike spiral trajectories that wind around a reference null geodesics, or equivalently, a reference trajectory for a spinning massless particle with zero orthogonal spin component in the spin vector. They argue that, for "reasonable cosmologies, redshifts, and atomic periods", the physical distance between the spiral and the null geodesic is of the order of the wavelength, even though according to their analysis it is in principle unbounded.

In their more recent work [70], Duval, Marsot, and Sch¨ucker extended the analysis to Schwarzschild spacetimes (A2). For the numerical simulations, they assumed initial conditions at the perihelion, the point of closest approach to the star on the trajectory. From their perturbative analysis, they recover two deflection angles, one between the trajectory and the geodesic plane, given by:

$$\beta \sim -\left(1 - \frac{2GM}{r_0}\right) \frac{\chi \lambda_0}{2\pi r_0},\tag{59}$$

and one between the geodesic plane and the momentum carried by the spinning photon:

$$\gamma \sim \chi \frac{GM\lambda_0}{2\pi r_0^2}. (60)$$

Here, χ = ±1 is the photon helicity. This second deflection angle is proportional to the one presented in (65), derived in [93] from certain approximations applied to field equations, which we discuss further down in section 3.1. It is reassuring that the deflection angle comes out similar with two completely different methods. Despite the previously mentioned shortcomings of the Souriau– Saturnini equations, the authors in [70]<sup>3</sup> seem to be able to reproduce these results from [93]. In contrast to [93], the authors in [70] provide a clear presentation of their perturbative calculations.

<sup>3</sup> Despite this agreement, the workaround for the 'flat space problem' used in [70], namely to simply go to the cosmological setting with positive Λ, to make the problem go away, seems at least on a conceptual level not a very pleasing resolution of the issue.

We now give a short discussion about their results and the underlying assumptions. It strikes us as odd that their momentum perturbation (60), and the trajectory perturbation (59) come out with a different sign. For the far field asymptotics this seems implausible. Additionally, the trajectory perturbation seems to be independent of the mass, and, between the surface of the Sun and the Earth, it is significantly larger than the momentum perturbation [2β ∼ 10−1100, while 2γ ∼ 10−1600].

Considering the trajectories in figure 1, calculated from the equations in section 3.1, that also lead to the same prediction for the deflection angle, one might question whether the assumptions for the perturbative calculations are justified. In figure 1, one sees that the force, in the direction orthogonal to the geodesic plane, originating from the spin-curvature interaction is not monotone. Therefore, a perturbative expansion around the perihelion might not be justified for light coming from a far away source. For real physical observations it also doesn't seem practical to fix the spin initial conditions at the perihelion of the trajectory. For an actual experiment, this would need to be done either at the location of the emitter or the location of the observer.

As a final remark to this section, we would like to point out that the situation changes significantly if one considers the Pirani-SSC instead of the Tulczyjew–Dixon SSC. This issue has also been mentioned in a recent paper by Marsot [122]. It was shown in [9] that the Pirani-SSC can be derived from the pole-dipole approximation, if one assumes the stress energy tensor to be traceless (T µ <sup>µ</sup> = 0), on top of the assumption that it be divergence free. Note that both these assumptions are compatible with the stress energy tensor for Maxwell fields. It was argued before [123] that, under the Pirani-SSC, massless particles with spin follow ordinary null geodesics, and hence no trace of a G-SHE is present. A similar derivation has been carried out in more detail in [9, 10], where it was shown that this is true as long as the assumption ~p·S~ 6= 0 holds, where ~p is the spatial part of the momentum, and S~ := (S1, S2, S3) = (S <sup>23</sup>, S31, S12). Other aspects of the massless MPD equations with the Pirani-SSC have been discussed by several authors [30, 67, 163].

#### 3. G-SHE FROM RELATIVISTIC QUANTUM MECHANICS

The first connection between the motion of spinning particles in curved spacetime and the SHE was introduced by B´erard and Mohrbach in 2006 [19]. The authors studied the adiabatic evolution of a Dirac particle by using the Foldy–Wouthuysen transformation [84] and presented a generalization of this method for arbitrary spin-fields by using the Bargmann–Wigner equations [16], and a generalized version of the Foldy–Wouthuysen transformation [45, 106]. In this way, the position operator of spinning particles acquires an anomalous contribution, related to a non-Abelian Berry connection [19]. Based on this method, Gosselin, B´erard, and Mohrbach studied the G-SHE of electrons [92] (similar results were also presented by Silenko et al. [171], albeit without mentioning the term SHE) and photons [93] in a static gravitational field.

Although not explicitly interested in SHEs, the Foldy–Wouthuysen transformation was also used by Obukhov et al. in order to study the dynamics of Dirac particles in curved spacetime [132–136]. One important claim discussed in [133–136] is that the linearized MPD equations are obtained as an approximation to the Dirac equation. This will be discussed in more detail in section 5.1

In this section, we will briefly review the G-SHE of photons in a static gravitational field,

following the work of Gosselin et al. [93]. We focus on this particular paper because, to our knowledge, it is the only one using techniques adapted from Relativistic Quantum Mechanics in order to describe the propagation of photons in curved spacetime, and the results can easily be compared with the other approaches from sections 2 and 4. The resulting equations of motion are presented and discussed, and connection with the SHE-L in inhomogeneous optical media will be emphasized.

#### 3.1. Photons in a Static Gravitational Field

Here we will consider the G-SHE of photons in a static gravitational field, as described by Gosselin, B´erard and Mohrbach [93]. In this approach, the authors describe electromagnetic waves using the Bargmann–Wigner equations of a massless spin-1 field. In general, the Bargmann–Wigner equations describe massive or massless free spin-j fields, and consist of 2j coupled partial differential equations, each equation having a similar structure as a Dirac equation [16, 94]. Considering the case of a spin-1 field in the curved spacetime described by the metric gµν, the Bargmann–Wigner equations take the following form:

$$(-i\hbar\gamma^{\mu}\nabla_{\mu} + m)_{\alpha_1\alpha_1'}\Psi_{\alpha_1'\alpha_2} = 0, \tag{61}$$

$$(-i\hbar\gamma^{\mu}\nabla_{\mu} + m)_{\alpha_2\alpha_2'}\Psi_{\alpha_1\alpha_2'} = 0, \tag{62}$$

where the field Ψα1α<sup>2</sup> is a completely symmetric 4-spinor of rank 2, the primed indices are contracted, the gamma matrices satisfy {γ µ , γν} = 2g µν, and ∇<sup>µ</sup> = ∂<sup>µ</sup> + ω<sup>µ</sup> is the covariant derivative for spinor fields. When setting m = 0, it can be shown that these equations are equivalent to the homogeneous Maxwell's equations [94].

Since now we have a description of electromagnetic waves in terms of coupled Dirac equations, one can import certain methods that are generally used in the Relativistic Quantum Mechanics of electrons. An example of such a method is the Foldy–Wouthuysen transformation [31, 84], which was originally applied to the massive Dirac equation in order to understand its non-relativistic limit. The Foldy–Wouthuysen transformation consists of a unitary transformation, acting on the basis in which the states and the Dirac Hamiltonian are represented in such a way that the α-matrices are eliminated, and the resulting Hamiltonian is in diagonal form. This is always possible for a free Dirac electron, but, in the presence of other external fields (electromagnetic or gravitational), the transformation might only be performed in a perturbative sense, the resulting Hamiltonian being diagonal only to some order in ~. Generalizations of the Foldy–Wouthuysen transformation to other spin-fields were introduced in [45] for spin-0 and spin-1 fields, and in [106] for arbitrary spin-fields.

In order to obtain the equations of motion describing the G-SHE of photons in a static gravitational field, Gosselin et al. [93] used a generalized Foldy–Wouthuysen transformation, together with their semiclassical diagonalization procedure described in [19, 91]. Even though their results describe a general static spacetime with torsion [93], here we will restrict our attention to the particular case of a Schwarzschild background, with the metric expressed in isotropic coordinates, as given in equation (A3).

In this case, the following equations of motion, describing the G-SHE of photons, were obtained by Gosselin et al. [93]:

$$\dot{\mathbf{p}} = -cp\nabla F, \qquad \dot{\mathbf{x}} = c\frac{\mathbf{p}}{p}F + \sigma\frac{\dot{\mathbf{p}}\times\mathbf{p}}{p^3},$$
 (63)

where  $F = \frac{V}{W}$  (see equations (A3) and (A4) for the definitions of V and W) contains the metric components,  $\sigma = \pm \hbar$  is the photon helicity,  $p = h/\lambda$  is the magnitude of the photon momentum, and the vector notation is  $\mathbf{p} = (p_x, p_y, p_z)$ ,  $\mathbf{x} = (x, y, z)$ .

There is a small difference between the equations of motion presented here in equations (63), and the equations of motion from [93, eq.(24)], where the authors used a wrong formula for F in the last step of their calculation. While this does not seem to affect the final results in a drastic way, the error propagated into other papers as well [139].

The G-SHE is given by the second term in the expression of  $\dot{\mathbf{x}}$ . Clearly, this is a helicity dependent correction, which vanishes when we neglect the helicity of the photon. In this case, the equations of motion reduce to the usual null geodesics, and describe ordinary light bending around a Schwarzschild black hole. Also, the G-SHE correction term is proportional to the wavelength  $\lambda$  of the photon, since  $\dot{\mathbf{p}} \propto p \propto \lambda^{-1}$ ,  $\mathbf{p} \propto \lambda^{-1}$ , and  $p^3 \propto \lambda^{-3}$ . Thus, the G-SHE vanishes in the limit of very short wavelengths or infinitely high frequencies.

#### 3.2. Predictions of the theory

It is important to notice the direction of the G-SHE correction term in equations (63). Given the spherical symmetry of the Schwarzschild black hole,  $\dot{\mathbf{p}}$  is directed along the gradient of the gravitational field, and  $\mathbf{p}$  will correspond to the direction of propagation of the photon. Thus, the G-SHE correction term will be perpendicular to both the gradient of the gravitational field and the direction of propagation of the photon. In the case of radial trajectories, the G-SHE will vanish.

For a Schwarzschild black hole, trapped null geodesics occur only at a fixed radial location, given by  $r = \frac{3GM}{c^2}$ . These null geodesics constitute the photon sphere, and determine the shadow of the black hole (see e.g. [121] for a discussion of black hole shadows). One can consider a notion of effective photon sphere in the context of the G-SHE. By effective photon sphere, we now mean trapped curves associated with the equations of motion (63). Considering any photon initially located on the photon sphere, the G-SHE correction term will be different from zero. However, since  $\dot{\mathbf{p}}$  is directed along a radial direction, and  $\mathbf{p}$  is tangential to the photon sphere, their cross product will also be tangential to the photon sphere. Even though the G-SHE will deflect the photon from its original trajectory, the photon will not leave the photon sphere. This contradicts the findings in [190], where it was predicted that the gravitational spin-orbit coupling induces a helicity-dependent splitting of the photon sphere into two effective photon spheres of different radii. Another argument against the splitting of the photon sphere is that both the Schwarzschild

spacetime and Maxwell's equations are parity invariant, while a splitting of the photon sphere would violate this basic symmetry principle.

Based on the equations of motion (63), Gosselin et al. proposed the following correction to the ordinary light bending deflection angle [93]:

$$\Delta \phi = \frac{4GM}{c^2 r_0} \left( 1 - \frac{\sigma}{\hbar} \frac{\lambda}{2\pi r_0} \right),\tag{64}$$

where r<sup>0</sup> represents the distance of closest approach between the light ray and the center of the gravitational source. The first term in this equation represents the ordinary light bending deflection angle, well known from General Relativity, while the second term represents the polarizationdependent G-SHE correction. However, equation (64) cannot be correct. The additional deflection due to the G-SHE lies in a plane orthogonal to the ordinary light bending plane, thus, one should treat them separately. This statement is justified by the equations of motion (63), where the G-SHE correction term is proportional to x × p (this is because p˙ ∝ ∇F ∝ x). Looking in the plane orthogonal to the ordinary light bending plane, the deflection angle coming from the G-SHE should be:

$$\Delta\phi_{SHE} = \frac{\sigma}{\hbar} \frac{4GM}{c^2 r_0} \frac{\lambda}{2\pi r_0} = \chi \frac{2GM\lambda}{\pi c^2 r_0^2},\tag{65}$$

where χ = ±1. This last formula is proportional to the deflection angle predicted in [70], and discussed here in equation (60). Also, the classical nature of the G-SHE is emphasized here, since the deflection angle does not depend on ~.

One of the main disadvantage of the method used in [93] is that the use of the Bargmann– Wigner equations blurs the connection with Maxwell's equations, while the Foldy–Wouthuysen transformation, and the semiclassical diagonalization procedures unnecessarily introduce Planck's constant, giving the general impression that the G-SHE is of Quantum Mechanical origin. In section 1.3, the SHE-L was directly derived from Maxwell's equations, without the need of using any Quantum Mechanical notions. Similar arguments should apply for the case of Maxwell's equations on a curved background. Another drawback of the approach of Gosselin et al. is that their treatment is limited to static spacetimes, and it is not clear how the method should be extended to more general spacetimes.

An alternative derivation of equations (63) can be obtained by treating the Schwarzschild spacetime as an effective inhomogeneous medium. By using the equivalence between Maxwell's equations in curved spacetime and inside a material in flat spacetime, as discussed in section 1.4, an effective refractive index can be attributed to the Schwarzschild spacetime, n = 1/F, and the same methods as for the SHE-L in inhomogeneous optical media can be applied. For example, equations (63) can be easily obtained by inserting n = 1/F into equations (45).

As discussed in [39], all spin-orbit interactions of light can be understood in terms of couplings between the different forms of angular momentum that light can carry. In the case considered by Gosselin et al. [93], photons only have SAM and EOAM with respect to the black hole, thus the

![](_page_23_Picture_1.jpeg)

FIG. 1: G-SHE of photons around a Schwarzschild black hole. Different viewing angles for the same trajectories are represented. The magnitude of the effect is amplified for visualization purposes. The blue and the red trajectories correspond to photons having opposite helicities, σ = ±~, while the green trajectory represents a null geodesic (σ = 0), undergoing only ordinary light bending.

only possible spin-orbit coupling is between these two forms of angular momentum. Given the spherical symmetry of the Schwarzschild spacetime, one can show that equations (63) possess the following integral of motion:

$$\mathbf{J} = \mathbf{x} \times \mathbf{p} + \sigma \frac{\mathbf{p}}{p}, \qquad \dot{\mathbf{J}} = 0. \tag{66}$$

The same holds true for the SHE-L in spherically-symmetric inhomogeneous optical media [39, 137], and this emphasizes the direct connection between the conservation of the total angular momentum of light and the helicity-dependent corrections to the equations of motion.

In order to provide some intuition about how the G-SHE affects the propagation of light around a Schwarzschild black hole, we numerically integrated equations (63). An example is presented in figure 1, where we start at a common point with three different trajectories. The only difference in the initial conditions is the helicity. One can see that the G-SHE results in a helicity-dependent transverse shift of the trajectories, and the motion is no longer restricted to a plane, as in the case of the null geodesic. The Schwarzschild black hole acts as a Stern–Gerlach magnet for photons of opposite helicity. Other examples of numerically integrated G-SHE trajectories can also be found in [139].

# 4. G-SHE FROM GEOMETRICAL OPTICS

The standard treatment for the propagation of electromagnetic waves in General Relativity is achieved by investigating Maxwell's equations in curved spacetime. Null geodesics can be obtained from Maxwell's equations by considering the lowest order geometrical optics approximation [127, 144, 145]. However, as we saw in the previous sections, at this level of the approximation, there is no influence of the polarization degree of freedom on the trajectories. In order to obtain a theoretical description of the G-SHE, higher order terms should be considered in the geometrical optics approximation.

Starting with Maxwell's equations in curved spacetime, and by considering certain corrections to the standard geometrical optics approximation, several authors obtained polarization-dependent trajectories for light rays in a curved spacetime [62, 63, 85, 86, 194] (see also [101] for a more general discussion). However, some of the predictions presented in these papers are in contradiction with the results discussed in sections 2 and 3. For example, polarization-dependent trajectories were predicted in [85, 194], on a Kerr spacetime. However, this effect disappears in the limit of a Schwarzschild spacetimes, in contrast to what we discussed in the previous sections.

Here, we will review the main features of these approaches, focusing in particular on [85, 194]. We start by reviewing the standard geometrical optics approximation for Maxwell's equations in curved spacetime. In the lowest order expansion, this leads to the well-known results that light rays follow null geodesics, and the polarization vector is parallel-transported along the null geodesic, leading to the gravitational Faraday rotation of the polarization vector. The gravitational Faraday rotation represents the starting point for the modified geometrical optics proposal presented in [62, 63, 85, 86, 194], where a modified eikonal ansatz was proposed.

#### 4.1. Geometrical Optics and Gravitational Faraday Rotation

In this section we will review the main features of the geometrical optics approximation for Maxwell's equations in curved spacetime, which is well known in General Relativity [127]. The general argument is very similar to what we already discussed in section 1.3, but there are a some key differences, which will be emphasized along the way. It is important to compare these two approaches in detail, since there is some disagreement between their predictions for the G-SHE, as we will see in what follows.

We begin by considering a stationary spacetime described by some metric tensor gµν. The propagation of electromagnetic waves within a given spacetime can be described by the vector potential Aµ, satisfying the Lorentz gauge condition

$$\nabla_{\mu}A^{\mu} = 0, \tag{67}$$

and the wave equation

$$\nabla^{\nu}\nabla_{\nu}A_{\mu} - R_{\mu}^{\ \nu}A_{\nu} = 0, \tag{68}$$

where ∇<sup>µ</sup> is the covariant derivative, and Rµν is the Ricci tensor.

The central assumption of the geometrical optics approximation is that the wavelength of light, λ = 2πω−<sup>1</sup> , is much smaller than any other characteristic length scale L of the problem. When considering the propagation of light through a medium, this length scale is given by the distance over which the parameters of the medium change significantly, and in the case of light propagating on a curved spacetime, the length scale is given by the variation scale of the spacetime curvature. Under this assumption, it is expected that the vector potential A<sup>µ</sup> can be split into a slowly varying complex amplitude a<sup>µ</sup> and a fast oscillating real phase S:

$$A_{\mu} = a_{\mu} e^{iS/\epsilon},\tag{69}$$

where is a dimensionless expansion parameter.

This is generally called the eikonal ansatz. The same results are obtained if one uses the eikonal ansatz to expand other quantities, such as the Faraday tensor [62, 63] or the Riemann–Silberstein vector [85]. The geometrical optics equations are obtained by inserting the eikonal ansatz into the Lorentz gauge condition and into the wave equation. Afterwards, the results are examined order by order in the expansion parameter, . From the Lorentz gauge condition, at order −1 , we obtain:

$$a^{\mu}k_{\mu} = 0, \tag{70}$$

where we have defined k<sup>µ</sup> = ∇µS. Thus, the amplitude vector a<sup>µ</sup> is orthogonal to the wave vector kµ. The wave equation at order <sup>−</sup><sup>2</sup> gives:

$$k^{\mu}k_{\mu} = 0. \tag{71}$$

This means that the gradient of the phase is null. Also, since k<sup>µ</sup> is a gradient, it follows that it will satisfy the null geodesic equation:

$$k^{\nu}\nabla_{\nu}k^{\mu} = 0. \tag{72}$$

In this way, the classical result that light rays follow null geodesics is recovered from the wave equation. It is one of the main results of the geometrical optics approximation for Maxwell's equations in curved spacetime.

By examining the wave equation at order −1 , we obtain the following transport equation:

$$k^{\nu}\nabla_{\nu}a^{\mu} + \frac{1}{2}a^{\mu}\nabla_{\nu}k^{\nu} = 0.$$
 (73)

Following [194], we can split the amplitude a<sup>µ</sup> into a real amplitude a and a complex unit vector l µ , which will describe the polarization degree of freedom:

$$a_{\mu} = al_{\mu}, \qquad l^{\mu}\bar{l}_{\mu} = 1. \tag{74}$$

Substituting equation (74) into equation (70), we see that the polarization vector  $l^{\mu}$  is orthogonal to the wave vector  $k_{\mu}$ :

$$k_{\mu}l^{\mu} = 0. \tag{75}$$

By substituting equation (74) into equation (73), we obtain:

$$\nabla_{\mu}(a^2k^{\mu}) = 0, \tag{76}$$

$$k^{\nu}\nabla_{\nu}l^{\mu} = 0. \tag{77}$$

Equation (76) can be interpreted as the conservation of the photon number along the null geodesic, and equation (77) represents the parallel-propagation equation for the polarization vector along the null geodesics. This is the second important result of the geometrical optics approximation for Maxwell's equations in curved spacetime.

Following [194], we can introduce an orthonormal basis  $(u^{\mu}, n^{\mu}, e_1^{\mu}, e_2^{\mu})$ . Since the considered spacetime is stationary, we have the following stationary Killing vector field:

$$\xi = \frac{\partial}{\partial t},\tag{78}$$

and we introduce the notation  $h = -\xi^{\mu}\xi_{\mu}$ . Now, we can define  $u^{\mu}$  and  $n^{\mu}$  as in [194]:

$$u^{\mu} = \frac{\xi^{\mu}}{\sqrt{h}},\tag{79}$$

$$n^{\mu} = \frac{\sqrt{h}}{\omega} k^{\mu} - u^{\mu},\tag{80}$$

where  $\omega = -\xi^{\mu}k_{\mu}$  is the frequency measured by a stationary observer. The other two spacelike unit vector fields,  $e_1^{\mu}$  and  $e_2^{\mu}$ , can be obtained by Fermi–Walker transport along the vector  $n^{\mu}$  [85, 194]. In this case, the vector fields  $e_1^{\mu}$  and  $e_2^{\mu}$  will represent a linear polarization basis, and we can define the circular polarization basis in the following way:

$$m^{\mu} = \frac{1}{\sqrt{2}} (e_1^{\mu} + i\sigma e_2^{\mu}), \tag{81}$$

where  $\sigma = +1$  corresponds to right-handed circular polarization, and  $\sigma = -1$  corresponds to left-handed circular polarization. We will refer to  $\sigma$  as the helicity. Using this circular polarization base vector field  $m^{\mu}$ , we can write the polarization vector  $l^{\mu}$  as in [194]:

$$l^{\mu} = m^{\mu} e^{i\phi}, \tag{82}$$

where  $\phi = \phi(x)$  is a real function of the spacetime coordinates, and the amplitude  $a^{\mu}$  will take the following form:

$$a^{\mu} = al^{\mu} = a(e_1^{\mu} + i\sigma e_2^{\mu})e^{i\phi}.$$
 (83)

This form of the amplitude is very similar to the one considered in section 1.3, with the small difference that here only one circular polarization mode is considered to be active (we have either a right-handed or a left-handed circular polarization mode, depending on the helicity  $\sigma$ ). This should not affect the following calculations, since the polarization dynamics should be decoupled in a circular polarization basis. However, the method presented here, and the method discussed in section 1.3 are quite different, since in section 1.3 the field Lagrangian was projected onto the circular polarization eigenmodes, while here there is no such projection, and the transport equation is already given.

Recalling that  $l^{\mu}$  is parallel-transported along the null geodesic generated by  $k^{\mu}$ , equation (77) becomes:

$$k^{\nu} \nabla_{\nu} l^{\mu} = k^{\nu} \nabla_{\nu} (m^{\mu} e^{i\phi}) = 0.$$
 (84)

Following the derivation in [194], we can write the propagation equation for the phase  $\phi$  along null geodesics generated by  $k^{\mu}$ :

$$k^{\nu}\nabla_{\nu}\phi = \frac{1}{2}\sigma u_{\rho}k_{\lambda}\varepsilon^{\mu\nu\rho\lambda}\nabla_{\nu}u_{\mu},\tag{85}$$

where  $\varepsilon^{\mu\nu\rho\lambda}$  is the Levi–Civita tensor. This equation describes the evolution of the phase function  $\phi$  along the null geodesic generated by  $k^{\mu}$ . This effect is known as the gravitational Faraday rotation [44, 78, 80, 104, 131, 161, 164].

At least in the case considered here, the extra phase variation arising as a consequence of the gravitational Faraday rotation is a phenomenon strictly related to the non-static nature of the spacetime. More explicitly, the extra phase variation is proportional to the  $g_{0i}$  off-diagonal terms in the metric [85, 194] (this is clearly presented in equation (102) from [85]). If we consider a Kerr spacetime in Boyer--Lindquist coordinates, with spin parameter a, then the variation of  $\phi$  along a null geodesic generated by  $k_{\mu}$  would be proportional to a.

#### 4.2. Modified Geometrical Optics

The standard geometrical optics approximation predicts the gravitational Faraday rotation, and the trajectories of light rays are null geodesics, independent of the polarization. In order to take into account the influence of the polarization on the null geodesics, a modified geometrical optics procedure (also called "spinoptics" by some authors) was presented, first by Frolov and Shoom [85], and later on by Yoo [194] and Dolan [62, 63]. The main idea is that the additional phase factor coming from the gravitational Faraday rotation should be interpreted as a correction term

to the original eikonal ansatz, considered in equation (69). By adopting this approach, the eikonal ansatz is modified in the following way:

$$S \to \tilde{S} = S + \phi, \tag{86}$$

$$A_{\mu} = \tilde{a}_{\mu} e^{i\tilde{S}/\epsilon}.\tag{87}$$

This new eikonal ansatz looks somewhat similar to what Bliokh et al. considered in [35], where an extra Berry phase was included in the eikonal ansatz. However, at this point, it is not clear if we can identify the gravitational Faraday rotation with the Berry phase of electromagnetic waves propagating in curved spacetime. The main reason behind this is the fact that the gravitational Faraday rotation, as presented in [85, 194], vanishes in static spacetimes, such as the Schwarzschild spacetime. On the other hand, from the results of Gosselin et al. [93] we clearly see that the Berry phase is non-vanishing and plays a key role for the G-SHE of photons propagating in static spacetimes.

Following the same steps as for the standard geometrical optics approximation, the following equations are obtained [194]:

$$\tilde{a}^{\mu}q_{\mu} = 0, \tag{88}$$

$$q^{\mu}q_{\mu} = 0, \tag{89}$$

$$\nabla_{\mu}(\tilde{a}^2 q^{\mu}) = 0, \tag{90}$$

$$q^{\mu}\nabla_{\mu}\tilde{\phi} = 0, \tag{91}$$

where q<sup>µ</sup> = ∇µS˜ − σφµ, φ<sup>µ</sup> = 1 2 εµνρλu <sup>ν</sup>∇ρu λ , and ˜a <sup>µ</sup> = am˜ µ e iφ˜ . These equations indicate that the trajectories generated by q <sup>µ</sup> are null, the photon number is conserved, and the phase φ˜ is constant along the null trajectories generated by q µ .

However, since the modified wave vector q<sup>µ</sup> is no longer a gradient, the following equation of motion is obtained for light rays in this modified geometrical optics approximation [194]:

$$q^{\nu}\nabla_{\nu}q^{\mu} = \sigma f^{\mu}_{\ \nu}q^{\nu},\tag{92}$$

where fµν = ∇µφ<sup>ν</sup> − ∇νφµ.

This equation is similar to that of the motion of charged particles under the influence of an electromagnetic field. Here, the role of the charge is played by the polarization σ, and the role of the electromagnetic vector potential is played by φµ.

The results of this modified geometrical optics approach can also be obtained by considering an effective metric, as shown by Frolov et al. [85]. Considering the case of a Kerr spacetime in Boyer–Lindquist coordinates, with a representing the black hole spin parameter, the effective metric with modified geometrical optics corrections can be written as:

$$g_{\mu\nu} = \begin{pmatrix} g_{tt} & g_{tr} & g_{t\theta} & g_{t\phi} \\ g_{rt} & g_{rr} & 0 & 0 \\ g_{\theta t} & 0 & g_{\theta\theta} & 0 \\ g_{\phi t} & 0 & 0 & g_{\phi\phi} \end{pmatrix}, \tag{93}$$

where the effective correction terms are:

$$g_{rt} = g_{tr} = \frac{\sigma a}{\omega} f_1(a, M, r, \theta), \tag{94}$$

$$g_{\theta t} = g_{t\theta} = \frac{\sigma a}{\omega} f_2(a, M, r, \theta). \tag{95}$$

The explicit form of the functions f<sup>1</sup> and f<sup>2</sup> can be obtained from [85, eq. (126)]. The key aspect is that the effective correction terms are proportional to a, and vanish when a = 0. Thus, there is no effect in the case of a Schwarzschild spacetime, in contrast to what we discussed in sections 2.2 and 3.1. Also, the effective correction terms go to zero when we neglect the polarization degree of freedom, and in the limit of high frequencies, similarly as for the SHE-L in section 1.3, or for the G-SHE from section 3.1.

The same modified geometrical optics procedure was applied in [194] to study the propagation of gravitational waves, with similar results as presented above. The only difference comes from the fact that gravitational waves are described by a massless spin-2 field, so we have helicity σ = ±2. These claims are in contradiction with the results of Yamamoto [193], which predicted a G-SHE for gravitational waves in Schwarzschild spacetimes.

## 5. LINKING THE MODELS

In the previous sections we saw that several authors obtained various forms of G-SHEs for massless particles, using completely different methods, and sometimes even resulting in predictions that do not agree. As a starting point towards a deeper understanding of the G-SHE, one could try to show that some connections exist between these apparently different methods. At least for the case of the SouSa equations and the method presented in section 3, such a connection could be expected, since the predicted deflection angles seem to agree in Schwarzschild spacetimes. Unfortunately, no such connections have been explored in the literature.

However it is reassuring to see that, at least for the case of massive particles, there exists some work linking the approach in section 3, as well as the geometrical optics approach, to linearized MPDT equations. These will be presented in the following. Our hope is that future developments of the G-SHE for massless particles could benefit from this discussion.

# 5.1. MPD – Dirac Equivalence from the Quantum Perspective

Here we present a sketch of the derivation of the linearized MPDT equations, starting from the massive Dirac equation, as proposed by Obukhov, Silenko, and Teryaev [135, 136]. The central element of their derivation is the application of the Foldy–Wouthuysen transformation, so in this sense it is somewhat similar to the approach presented in section 3. The authors make use of the following representation of a generic metric:

$$ds^{2} = V^{2}dt^{2} - \delta_{\hat{a}\hat{b}}W^{\hat{a}}_{c}W^{\hat{b}}_{d}(dx^{c} - K^{c}dt)(dx^{d} - K^{d}dt), \tag{96}$$

where t stands for a time coordinate, and  $x^a$ , with (a = 1, 2, 3), denote local spatial coordinates. They choose the following tetrad, which satisfies the Schwinger gauge  $e_a^{\hat{0}} = 0$ :

$$e_i^{\hat{0}} = V \delta_i^{\hat{0}}, \qquad e_i^{\hat{a}} = W_b^{\hat{a}} (\delta_i^b - K^b \delta_i^0).$$
 (97)

A particle moves along a worldline  $x^{\mu}(\tau)$ , where  $(\mu=0,1,2,3)$ , and  $\tau$  is the proper time. The four-velocity is then  $u^{\mu}=dx^{\mu}/d\tau$ , and  $u^{\alpha}=e^{\alpha}_{\mu}u^{\mu}$ , with  $(\alpha=0,1,2,3)$  in tetrad components. They use the representation  $u^{\alpha}=(\gamma,\gamma v^{\hat{a}})$ , where  $\gamma^{-1}=\sqrt{1-v^2}$ , and  $v^{\hat{a}}$  are the three spatial components of the velocity. As a consequence, we have:

$$u^0 = \frac{dt}{d\tau} = \frac{\gamma}{V},\tag{98}$$

$$u^a = \frac{dx^a}{d\tau} = \frac{\gamma}{V} (K^a + F^a_{\ b} v^b), \tag{99}$$

where:

$$F^a_{\ b} = VW^a_{\ b}.\tag{100}$$

The authors start with the Dirac equation:

$$\gamma^k \nabla_k \Psi - \frac{\mu}{\hbar} \Psi = 0, \tag{101}$$

where  $\Psi$  is a 4-spinor, and, upon fixing a tetrad,  $\gamma^k$  are the gamma matrices. Equation (101) can be derived from the action  $S = \int d^4x \sqrt{-g} \mathcal{L}$ , with the Lagrangian density:

$$\mathscr{L} = \frac{i\hbar}{2} (\overline{\Psi} \gamma^{\alpha} \nabla_{\alpha} \Psi - \Psi \gamma^{\alpha} \nabla_{\alpha} \overline{\Psi}) - \mu \overline{\Psi} \Psi. \tag{102}$$

To obtain a "Hermitian Hamiltonian" when writing the Dirac equation in Schrödinger form,  $i\hbar \frac{\partial \psi}{\partial t} = \mathcal{H}\psi$ , the authors introduce the following rescaled wavefunction:

$$\psi = (\sqrt{-g}e_{\hat{0}}^0)^{1/2}\Psi. \tag{103}$$

<sup>&</sup>lt;sup>4</sup> In neither paper [135, 136], did the authors mention which scalar product they are considering

Then, the Hamiltonian is given by:

$$\mathcal{H} = \gamma^0 mV + \frac{1}{2} \left( \pi_a F^a_{\ b} \alpha^b + \alpha_a F^a_{\ b} \pi^a + K^a \pi_a + \pi_a K^a + \frac{\hbar}{2} (\Xi_a \Sigma^a - \Upsilon \gamma_5) \right), \tag{104}$$

where π<sup>a</sup> = −i~∂<sup>a</sup> = p<sup>a</sup> 5 , α <sup>a</sup> = γ 0γ a , Σ<sup>1</sup> = iγ2γ 3 , Σ<sup>2</sup> = iγ3γ1, and Σ<sup>3</sup> = iγ1γ 2 . Furthermore, one can introduce a pseudoscalar, Υ, and a three-vector, Ξ:

$$\Upsilon = V \epsilon^{abc} \Gamma_{abc}, \qquad \Xi_a = V \epsilon_{abc} \Gamma_0^{bc}.$$
(105)

With the methods developed in [170], the authors of [135, 136] then proceed to derive the Hamiltonian in the Foldy–Wouthuysen representation [84]. In this step, they linearize in ~, hence only keeping contributions to the Hamiltonian that are of the zeroth or first order in ~. The Hamiltonian is decomposed into pieces that commute and anticommute with γ 0 :

$$\mathcal{H} = \gamma^0 \mathcal{M} + \mathcal{E} + \mathcal{O}, \qquad \gamma^0 \mathcal{M} = \mathcal{M} \gamma^0, \qquad \gamma^0 \mathcal{E} = \mathcal{E} \gamma^0, \qquad \gamma^0 \mathcal{O} = -\mathcal{O} \gamma^0. \tag{106}$$

Hence, the operators M, E are even, and O is odd. The Foldy–Wouthuysen representation is given by:

$$\psi_{FW} = U\psi, \qquad \mathcal{H}_{FW} = U\mathcal{H}U^{-1} - i\hbar U\partial_t U^{-1}. \tag{107}$$

Assuming the notation = √ M<sup>2</sup> + O2, the operator U is given by:

$$U = \frac{\gamma^0 \epsilon + \gamma^0 \mathcal{M} - \mathcal{O}}{\sqrt{(\gamma^0 \epsilon + \gamma^0 \mathcal{M} - \mathcal{O})^2}} \gamma^0, \tag{108}$$

and it is unitary (U <sup>−</sup><sup>1</sup> = U † ) if H = H† .

After introducing the polarization operator Π = γ <sup>0</sup>Σ, the authors of [135, 136] calculate:

$$\frac{d\Pi}{dt} = \frac{i}{\hbar} [\mathcal{H}_{FW}, \Pi] = \Omega_{(1)} \times \Sigma + \Omega_{(2)} \times \Pi, \tag{109}$$

where the three-vectors Ω(1) and Ω(2) are the operators of the angular velocity of spin precession. Then, the authors of [135, 136] obtained the semiclassical equations describing the motion of the average spin vector s by evaluating all anticommutators, and omitting powers of ~ higher than one:

$$\frac{d\mathbf{s}}{dt} = \mathbf{\Omega} \times \mathbf{s} = (\Omega_{(1)} + \Omega_{(2)}) \times \mathbf{s}.$$
 (110)

<sup>5</sup> Note that this choice for the momentum operator is not Hermitian in curved spacetime. If one is only interested in the weak field approximation, this should not be a concern. However, the notion of Hermiticity is dependent on the scalar product, which is not specified in the papers discussed here.

Here, {A × B}<sup>a</sup> = abcAbB<sup>c</sup> is the usual vector product in three dimensions. Substituting the semiclassical limit back into the Foldy–Wouthuysen Hamiltonian, they get:

$$\mathcal{H}_{FW} = \gamma^0 \gamma mV + \frac{1}{2} \left( K^a p_a + p_a K^a \right) + \frac{\hbar}{2} \left( \Pi \cdot \Omega_{(1)} + \Sigma \cdot \Omega_{(2)} \right). \tag{111}$$

From this, the velocity operator is obtained in the following form:

$$u^{a} = \frac{dx^{a}}{dt} = \frac{i}{\hbar} [\mathcal{H}_{FW}, x^{a}] = \gamma^{0} \frac{\partial \gamma mV}{\partial p_{a}} + K^{a}.$$
 (112)

Then, they proceed to show that, with s <sup>α</sup> = (Λ)<sup>α</sup> βS <sup>β</sup> being the physical spin in the rest frame of an observer along the worldline of the spinning particle and hence s <sup>α</sup> = (0, s) being the spin three-vector, equations (110) and (112) are equivalent to the linearized MPDT equations (52). Here, S β is the covariant spin vector defined in (51), and (Λ)<sup>α</sup> β is the Lorentz transformation to the rest frame of the observer along the worldline of the spinning particle.

### 5.2. MPD – Dirac Equivalence using WKB

In this section we will give a quick sketch of the derivation of the linearized MPDT equations (52) from the massive Dirac equation, by using a WKB approximation, along the lines of [8, 151]. We start with the Dirac equation (101):

$$\gamma^k \nabla_k \Psi - \frac{\mu}{\hbar} \Psi = 0, \tag{113}$$

with µ > 0, and decompose the 4-spinor Ψ into 2-spinors:

$$\Psi = \begin{bmatrix} \xi^A \\ \overline{\eta}_{A'} \end{bmatrix}.$$

The gamma matrices are given by:

$$\gamma^a = \sqrt{2} \begin{bmatrix} 0 & -\sigma^{aAB'} \\ \sigma^a_{BA'} & 0 \end{bmatrix},$$

and satisfy γ (aγ <sup>b</sup>) = −g ab1. The σ's are the Infeld–van der Waerden symbols [143], satisfying:

$$\sigma_a{}^A{}_{K'}\sigma_b{}^{BK'} + \sigma_b{}^A{}_{K'}\sigma_a{}^{BK'} = g_{ab}\epsilon^{AB}.$$

Once a tetrad is fixed, they become the gamma and Pauli matrices, up to a constant normalization factor. In the following, we will denote the conjugate transpose of a 4-spinor Ψ by Ψ† , and the Pauli conjugate as:

$$\overline{\Psi} = \begin{bmatrix} \overline{\xi}^{A'} & \eta_A \end{bmatrix} \begin{bmatrix} 0 & \delta_{B'}^{A'} \\ -\delta_B^{A} & 0 \end{bmatrix} = \begin{bmatrix} -\eta_B & \overline{\xi}^{B'} \end{bmatrix}.$$

Note that  $i\overline{\Psi}\Psi$  is real. Then, one starts the derivation with the WKB ansatz:

$$\Psi = \exp\left(-\frac{i}{\hbar}S\right) \sum_{\nu=0}^{\infty} \hbar^{\nu} \psi^{(\nu)}, \tag{114}$$

where S is a scalar field, and the amplitude  $\sum_{\nu=0}^{\infty} \hbar^{\nu} \psi^{(\nu)}$  is a 4-spinor. Plugging the ansatz (114) into equation (101), one gets:

$$(i\gamma^k \nabla_k S + \mu \mathbb{1})\psi^{(0)} = 0 (\nu = 0), (115)$$

$$(i\gamma^k \nabla_k S + \mu \mathbb{1})\psi^{(\nu)} = \gamma^k \nabla_k \psi^{(\nu-1)}$$
  $(\nu > 0).$  (116)

First, we observe that equation (115) has non-zero solution only if  $\det(i\gamma^k\nabla_k S + \mu\mathbb{1}) = 0$ . Using  $\gamma^{(a}\gamma^{b)} = -g^{ab}\mathbb{1}$ , this leads to:

$$\nabla^k S \nabla_k S = \mu^2. \tag{117}$$

From this equation we can see that geodesics are integral curves of  $\frac{1}{\mu}\nabla S$  are. Therefore, up to zero order in  $\hbar$ , geodesics can be considered a good approximation to solutions of (101).

We choose an orthonormal frame  $e_0, e_1, e_2, e_3$ , with  $e_0 = \frac{1}{\mu} \nabla S$ , such that the orthonormal frame field is parallel transported along the integral curves of  $\frac{1}{\mu} \nabla S$ . A spin basis (up to a common sign of o and  $\iota$ ) can now be fixed:

$$o^{A} \overline{o}^{A'} = \frac{1}{\sqrt{2}} \sigma_{k}^{AA'} (e_{0}^{k} + e_{3}^{k}),$$

$$\iota^{A} \overline{\iota}^{A'} = \frac{1}{\sqrt{2}} \sigma_{k}^{AA'} (e_{0}^{k} - e_{3}^{k}),$$

$$o^{A} \overline{\iota}^{A'} = \frac{1}{\sqrt{2}} \sigma_{k}^{AA'} (e_{1}^{k} + ie_{2}^{k}).$$
(118)

One can then define:

$$\Sigma_{1} = \frac{1}{\sqrt{2}} \begin{bmatrix} o^{A} \\ i\overline{\iota}_{A'} \end{bmatrix}, \quad \Sigma_{2} = \frac{1}{\sqrt{2}} \begin{bmatrix} \iota^{A} \\ -i\overline{o}_{A'} \end{bmatrix}, \quad \Sigma_{3} = \frac{1}{\sqrt{2}} \begin{bmatrix} o^{A} \\ -i\overline{\iota}_{A'} \end{bmatrix}, \quad \Sigma_{4} = \frac{1}{\sqrt{2}} \begin{bmatrix} \iota^{A} \\ i\overline{o}_{A'} \end{bmatrix}, \quad (119)$$

and calculate:

$$(i\gamma^k \nabla_k S + \mu \mathbb{1}) \Sigma_\alpha = \begin{cases} 0 & \text{for } \alpha = 1, 2\\ 2\mu \Sigma_\alpha & \text{for } \alpha = 3, 4 \end{cases}$$
 (120)

Now we impose the following solvability condition:

$$\overline{\Sigma}_1 \gamma^k \nabla_k \psi^{(\nu-1)} = 0, \quad \overline{\Sigma}_2 \gamma^k \nabla_k \psi^{(\nu-1)} = 0. \tag{121}$$

If this condition were not satisfied, (120) would prevent any solutions to the equation (116). Then, one can write a general zeroth order solution  $\psi^{(0)}$  of (115) as:

$$\psi^{(0)} = a_1^{(0)} \Sigma_1 + a_2^{(0)} \Sigma_2. \tag{122}$$

A general solution at order  $\nu$  can be given as a sum of the homogeneous solutions as above, and a particular solution  $\Pi^{(\nu)}$ :

$$\psi^{(\nu)} = a_1^{(\nu)} \Sigma_1 + a_2^{(\nu)} \Sigma_2 + \Pi^{(\nu)}. \tag{123}$$

The particular solution can be written as  $\Pi^{(\nu)} = a_3^{(\nu)} \Sigma_3 + a_4^{(\nu)} \Sigma_4$ . Inserting this into (116), using (120) on the left hand side, and then equating the coefficients leads to:

$$\Pi^{(\nu)} = \frac{-i}{2u} \left( (\overline{\Sigma}_3 \gamma^k \nabla_k \psi^{(\nu-1)}) \Sigma_3 + (\overline{\Sigma}_4 \gamma^k \nabla_k \psi^{(\nu-1)}) \Sigma_4 \right). \tag{124}$$

Finally, the solvability conditions (121) fix all  $a_1^{(\nu)}$  and  $a_2^{(\nu)}$ . To obtain the linearized MPDT equations, the authors of [8, 151] used the Gordon decomposition, splitting the four-current  $j^a = \overline{\Psi} \gamma^a \Psi$  into a convectional current and a spin current:

$$j^{a} = \underbrace{\frac{\hbar}{2\mu} \left( (\nabla^{a} \overline{\Psi}) \Psi - \overline{\Psi} \nabla^{a} \Psi \right)}_{=:(j_{\text{conv}})^{a}} + \underbrace{\nabla_{k} \left( \frac{\hbar}{2\mu} \overline{\Psi} \sigma^{ak} \Psi \right)}_{=:(j_{\text{spin}})^{a}}, \tag{125}$$

where the relation  $\sigma^{ab} = \gamma^{[a}\gamma^{b]}$  has been used.

A comparison to the non-relativistic case shows that the three-current can be interpreted as  $j_{\text{conv}}$ , and is related to the translation motion of the Dirac particle. The current  $j_{\text{spin}}$  is similar to the term one would add to describe the interaction of the magnetic moment of the electron and an external magnetic field. The authors plug the zero-order and first-order terms from (114) into the definition of  $j_{\text{conv}}$  to obtain [8, 151]:

$$(j_{\text{conv}})^{a} = \frac{1}{\mu} \left[ i \overline{\psi}^{(0)} \psi^{(0)} \nabla^{a} S + \hbar \left( i \left( \overline{\psi}^{(0)} \psi^{(1)} + \overline{\psi}^{(1)} \psi^{(0)} \right) \right) \nabla^{a} S + \frac{1}{2} \left( \left( \nabla^{a} \overline{\psi}^{(0)} \right) \psi^{(0)} - \overline{\psi}^{(0)} \nabla^{a} \psi^{(0)} \right) + \dots \right]. \quad (126)$$

In the next step, we use the fact that we are concerned with timelike trajectories  $(\mu > 0)$ , in order to normalize the current as  $u^a := (i\overline{\Psi}\Psi)^{-1}(j_{\text{conv}})^a$ . The following definition is introduced:

$$q^{a} = \frac{1}{2} (i\overline{\Psi}\Psi)^{-1} \left[ \left( \nabla^{a} \overline{\psi}^{(0)} \right) \psi^{(0)} - \overline{\psi}^{(0)} \nabla^{a} \psi^{(0)} \right],$$

in order to get

$$u^{a} = \mu^{-1} \nabla^{a} S + \mu^{-1} \hbar q^{a}. \tag{127}$$

Then, one can show that

$$q^k \nabla_k S = 0. (128)$$

The following identity is considered

$$u^k \nabla_k u_a = \frac{1}{2} \nabla_a (u_k u^k) + 2 \nabla_{[k} u_{a]} u^k,$$

and on the right hand side we plug in equation (127). Using (128), the following expression is obtained:

$$\mu(\nabla_k u_a) u^k = \underbrace{\frac{1}{2} \nabla_a \left( (\nabla^k S + \hbar q^k) (\nabla_k S + \hbar q_k) \right)}_{=0} + 2\mu \nabla_{[k} u_{a]} u^k.$$

This can be simplified to:

$$\mu(\nabla_k u_a)u^k = 2\hbar \nabla_{[k} q_{a]} u^k.$$

Now, using ∇[a∇b]Ψ = − 1 <sup>8</sup>Rabklσ klΨ, the authors retrieve equation (52) as follows [8, 151]:

$$\mu(\nabla_k u_a) u^k = -\frac{1}{4} R_{aklm} \underbrace{\hbar(i\overline{\psi}^{(0)}\psi^{(0)})^{-1}\overline{\psi}^{(0)}\sigma^{lm}\psi^{(0)}}_{=2S^{lm}} u^k, \tag{129}$$

$$= -\frac{1}{2}R_{aklm}S^{lm}u^k, (130)$$

and:

$$u^k \nabla_k S^{ab} = 0.$$

Also, using equation (116) and its Pauli conjugate, the Pirani-SSC (which to linear order in spin is identical to the Tulczyjew–Dixon SSC) can be obtained [8, 151]. Note that ~ enters here purely as a small expansion parameter, without intrinsic physical meaning.

![](_page_36_Picture_1.jpeg)

FIG. 2: Sketch of a G-SHE trajectory, together with a reference null geodesic. Because the G-SHE disappears for infinite frequencies, we can not assume a solution exhibiting the G-SHE to have a Delta distribution as initial data. Therefore, the information in the initial data is supported in an open region Σ0. If the G-SHE trajectory traces the motion of the center of energy, then there is no problem with causality, as long as the G-SHE trajectory remains inside the causal future of the set Σ0. This includes the situation where the G-SHE trajectories are spacelike.

#### 6. DISCUSSION

We presented various theoretical models attempting to describe G-SHEs. These rely on completely different methods, and the predictions are not entirely consistent. In this section, we will present a final discussion, in order to summarize and compare the main features, limitations and predictions made by each approach. We start with a few comments on the apparent superluminal motion of photons, when subject to the G-SHE, since this can be a common issue, regardless of the method used for deriving the G-SHE.

#### 6.1. Apparent superluminal motion

Several authors [7, 71, 159] reach the conclusion that photons subjected to the G-SHE can move at superluminal speed, despite the fact that photons are generally considered to obey Maxwell's equations, and solutions to Maxwell's equations are known to obey causality. In the following, we want to clarify in what sense these trajectories might actually be valid, or at least to propose an alternative interpretation of these results.

First of all, results pertaining to the Gaussian beams in [160] only yield a null geodesic with a Dirac delta initial support, in the limit of ω → ∞. However, the G-SHE comes in with a factor of σ/ω, and vanishes in the limit mentioned above.

This suggests that the solution might lie within an old insight, that, in Minkowski spacetime, one can construct a Gaussian wave packed which has an arbitrary group velocity. Hence, the peak can travel as fast as one wishes. This does not violate the relativistic speed limit, because through the nonvanishing tails of the Gaussian envelop, the information is a priori already present in the entire spacetime. It is likely this phenomenon that is at work here too. If we assume the G-SHE to be present, we cannot take the limit of ω → ∞. Hence, we cannot take the initial support of the beam to be arbitrarily small. Parallel transport of the initial data support region, along the original null geodesic to which we consider a modification by the G-SHE gives rise to a tube around the null geodesic. The trajectory calculated for the G-SHE then gives us the path traced out by the center of energy. Within the tube (in fact, within the entire causal future of the support of the initial data), this trajectory can, in principle, be spacelike without any violation of the universal speed limit. A schematic representation can be found in figure 2, where Σ<sup>0</sup> represents the spacelike hypersurface on which the initial data for the electromagnetic wave is supported, and Σ<sup>t</sup> represents the causal development of Σ<sup>0</sup> at time t.

#### 6.2. Comparison

In section 2 we presented the MPDT/SouSa approach towards the G-SHE. Looking at the massless case, the SouSa equations have the advantage that, in principle, one can use them to study the G-SHE on any background spacetime. However, the SouSa equations come with some serious drawbacks. First of all, even though they describe massless spinning particles, it is not clear how the SouSa equations are related to Maxwell's equations. Another issue is that certain massless limits of the MPDT equations predict that massless spinning particles will follow null geodesics [9, 122, 123]. In [70], the authors analyzed the SouSa equations in Schwarzschild spacetimes, and predicted two different deflection angles for photons passing close to the black hole.

In section 3 we discussed the approach of Gosselin, B´erard and Mohrbach [19, 93] towards the G-SHE of light. Here, the authors started with the Bargmann–Wigner equations, and then used the Foldy–Wouthuysen transformation in order to obtain effective equations of motion, describing the G-SHE of photons in a static gravitational field. They predicted a G-SHE for photons travelling in Schwarzschild spacetimes. One important advantage of this method is that the authors started with a field equation, which we consider natural to do when investigating the propagation of light. However, the method is limited to static spacetimes, and it is not clear how one should extend it to more general spacetimes. Also, the physical meaning of the Foldy–Wouthuysen transformation for photons is not clear. When applied to the Dirac equation, the Foldy–Wouthuysen transformation is used to understand the non-relativistic limit. In this sense, it is not clear what a non-relativistic limit of a massless field equation actually means.

In section 4 we presented the modified geometrical optics approach [62, 63, 85, 194]. Starting with Maxwell's equations on a curved background, the authors used the geometrical optics approximation to derive the gravitational Faraday rotation. Then, using the phase shift associated with the gravitational Faraday rotation, the authors proposed a modified eikonal equation. This lead to the prediction of a G-SHE of light in non-static spacetimes, such as the Kerr spacetime. The main advantage of this method is that one starts with Maxwell's equations, and derives an effect by means of a geometrical optics approach, which is a well known method that has been extensively studied in the literature. However, it is not clear to what extent is the modification of eikonal equation justified. Also, another problem of this approach is that it breaks down at the ergosurface<sup>6</sup> [194].

Comparing the predictions described in sections 2.2 and 3.2, we see that the SouSa and the quantum mechanical approach agree to some extend, in the case of a Schwarzschild spacetime. The G-SHE deflection angle predicted by Gosselin et al. [93] is proportional to one of the deflection angles predicted by Duval et al. [70]. Another important aspect is that the equations of motion discussed in 3.1 can also be derived by considering an effective refractive index for the Schwarzschild spacetime, together with the method described in section 1.3. This is encouraging, since the theoretical predictions discussed in section 1.3 have already been tested by several experiments in Optics [37, 39, 102].

However, a striking disagreement is seen when one compares the predictions of the quantum mechanical approach with the predictions of the modified geometrical optics approach. As we saw in section 4.2, the modified geometrical optics approach predicts a G-SHE on Kerr spacetimes, but this effect vanishes in the limit of a Schwarzschild spacetime. This is in contradiction with the predictions presented in sections 2.2 and 3, where the G-SHE is present in Schwarzschild spacetimes. Since the methods used for deriving the G-SHE are very different, it is not clear what is the origin of this disagreement. It is necessary to address this issue in future research, so that the theory can make consistent G-SHE predictions, which might one day be measured in experiments.

#### ACKNOWLEDGEMENTS

While preparing this paper, we discussed the problems at hand with many people to whom we are equally grateful. We will list them here in the alphabetical order. We would like to thank Steffen Acksteiner, Thomas B¨ackdahl, Iwo Bialynicki-Birula, Jiˇr´ı Biˇc´ak, Lukas B¨oke, Ilya Dodin, Sam Dolan, Shane Farnsworth, Abraham Harte, Jan Kohlrus, Miko laj Korzy´nski, Mario Krenn, Andr´as L´aszl´o, Siyuan Ma, Vincent Moncrief, Banibrata Mukhopadhyay, Dennis R¨atzel, Daniel Ruiz, Jan Sbierski, Tomasz Smo lka, Justin Vines, and Liviu Zˆarbo for the many useful discussions we had.

C.F.P. was supported by the Australian Research Council grant DP170100630.

#### Appendix A: Specific Spacetimes

Here, we present some formulas that describe specific spacetimes mentioned in the main text. We omit a discussion of these spacetimes, as it can be found elsewhere (for example, see [95]). The relevant properties are mentioned in the main body, where they matter.

The line element for flat Minkowski spacetime, in Cartesian coordinates, is given by:

$$ds^2 = -dt^2 + dx^2 + dy^2 + dz^2. (A1)$$

<sup>6</sup> For a Kerr black hole, the ergosurface is defined as the region above the outer event horizon where the time translation Killing vector field ξ = ∂/∂<sup>t</sup> becomes null: gµνξ µ ξ <sup>ν</sup> = 0 [187].

In Boyer Lindquist coordinates,  $(t, r, \theta, \phi)$ , the Schwarzschild metric is given by:

$$ds^{2} = -\left(1 - \frac{2M}{r}\right)dt^{2} + \left(1 - \frac{2M}{r}\right)^{-1}dr^{2} + r^{2}d\Omega^{2},\tag{A2}$$

where  $d\Omega^2 = d\theta^2 + \sin^2(\theta)d\phi^2$  describes the metric on a unit two-sphere. This describes a one parameter family of solutions, parametrized by M. It is straightforward to see that we recover the Minkowski spacetime when we set M=0 in this coordinate system. The parameter M is usually interpreted as the mass of the black hole. The Schwarzschild metric is static and asymptotically flat. It can also be expressed in Cartesian isotropic coordinates, (t, x, y, z), in the following way [129]:

$$ds^{2} = V^{2}dt^{2} - W^{2}(dx^{2} + dy^{2} + dz^{2}), \tag{A3}$$

$$V = \frac{1 - \frac{r_s}{4R}}{1 + \frac{r_s}{4R}}, \qquad W = \left(1 + \frac{r_s}{4R}\right)^2, \tag{A4}$$

where  $r_s = \frac{2GM}{c^2}$  is the Schwarzschild radius, and  $R = \sqrt{x^2 + y^2 + z^2}$ .

The Kerr family of spacetimes describes axially symmetric and stationary black hole solutions to the Einstein field equations. We use Boyer-Lindquist coordinates,  $(t, r, \phi, \theta)$ , which have the property that the metric components are independent of  $\phi$  and t. The metric has the following form:

$$ds^{2} = \Sigma \left(\frac{1}{\Delta} dr^{2} + d\theta^{2}\right) + \frac{1}{\Sigma} \left[ (r^{2} + a^{2})^{2} \sin^{2}\theta - \Delta \chi^{2} \right] d\phi^{2}$$

$$- \frac{2}{\Sigma} \left[ \Delta \chi - a(r^{2} + a^{2}) \sin^{2}\theta \right] dt d\phi - \frac{1}{\Sigma} \left( \Delta - a^{2} \sin^{2}\theta \right) dt^{2},$$
(A5)

where:

$$\Sigma = r^2 + a^2 \cos^2 \theta,\tag{A6}$$

$$\chi = a\sin^2(\theta),\tag{A7}$$

$$\Delta(r) = r^2 - 2Mr + a^2. \tag{A8}$$

Here, M is the mass, a is the angular momentum per mass unit.

The spatially-flat Friedmann–Robertson–Walker (FRW) metric is given by:

$$ds^2 = -dt^2 + a(t)^2 d\sigma^2,$$
(A9)

where  $\sigma$  is the flat metric in  $\mathbb{R}^3$ , and a(t) is the scale function.

- [1] Y. Aharonov and J. Anandan, Phase change during a cyclic quantum evolution, Physical Review Letters 58 (1987), 1593–1596.
- [2] L. Allen, M. W. Beijersbergen, R. J. C. Spreeuw, and J. P. Woerdman, Orbital angular momentum of light and the transformation of Laguerre-Gaussian laser modes, Physical Review A 45 (1992), 8185–8189.
- [3] J. Anandan, Comment on geometric phases for classical field theories, Physical Review Letters 60 (1988), 2555–2555.
- [4] , Non-adiabatic non-abelian geometric phase, Physics Letters A 133 (1988), no. 4, 171–175.
- [5] , Topological and geometrical phases due to gravitational field with curvature and torsion, Physics Letters A 195 (1994), no. 5, 284–292.
- [6] D. L. Andrews and M. Babiker, The Angular Momentum of Light, Cambridge University Press, 2012.
- [7] F. A. Asenjo and S. A. Hojman, Do electromagnetic waves always propagate along null geodesics?, Classical and Quantum Gravity 34 (2017), no. 20, 205011.
- [8] J. Audretsch, Trajectories and spin motion of massive spin- <sup>1</sup> 2 particles in gravitational fields, Journal of Physics A: Mathematical and General 14 (1981), 411–422.
- [9] M. Bailyn and S. Ragusa, Pole-dipole model of massless particles, Physical Review D 15 (1977), no. 12, 3543.
- [10] , Pole-dipole model of massless particles. II, Physical Review D 23 (1981), no. 6, 1258.
- [11] K. Bakke, C. Furtado, and J. R. Nascimento, Gravitational geometric phase in the presence of torsion, The European Physical Journal C 60 (2009), no. 3, 501.
- [12] A. A. Bakun, B. P. Zakharchenya, A. A. Rogachev, M. N. Tkachuk, and V. G. Fleˇisher, Observation of a surface photocurrent caused by optical orientation of electrons in a semiconductor, Soviet Journal of Experimental and Theoretical Physics Letters 40 (1984), 1293.
- [13] P. Baral, A. Ray, R. Koley, and P. Majumdar, Gravitational waves with orbital angular momentum, arXiv preprint arXiv:1901.08804 (2019).
- [14] E. Barausse, E. Racine, and A. Buonanno, Hamiltonian of a spinning test particle in curved spacetime, Physical Review D 80 (2009), no. 10, 104025.
- [15] C. Barcel´o, S. Liberati, and M. Visser, Analogue gravity, Living Reviews in Relativity 14 (2011), no. 1, 3.
- [16] V. Bargmann and E. P. Wigner, Group theoretical discussion of relativistic wave equations, Proceedings of the National Academy of Sciences 34 (1948), no. 5, 211–223.
- [17] S. M. Barnett, Relativistic electron vortices, Physical Review Letters 118 (2017), 114802.
- [18] S. M. Barnett, L. Allen, and M. J. Padgett, Optical angular momentum, CRC Press, 2016.
- [19] A. B´erard and H. Mohrbach, Spin Hall effect and Berry phase of spinning particles, Physics Letters A 352 (2006), no. 3, 190–195.
- [20] M. V. Berry, Quantal phase factors accompanying adiabatic changes, Proceedings of the Royal Society of London A: Mathematical, Physical and Engineering Sciences 392 (1984), no. 1802, 45–57.
- [21] , The adiabatic phase and Pancharatnam's phase for polarized light, Journal of Modern Optics 34 (1987), no. 11, 1401–1407.
- [22] R. Bhandari and J. Samuel, Observation of topological phase by use of a laser interferometer, Physical Review Letters 60 (1988), 1211–1213.
- [23] I. Bialynicki-Birula, On the wave function of the photon, Acta Physica Polonica A 86 (1994), no. 1, 97–116 (English).
- [24] , V Photon wave function, Progress in Optics, vol. 36, Elsevier, 1996, pp. 245–294.

- [25] I. Bialynicki-Birula and Z. Bialynicka-Birula, Berry's phase in the relativistic theory of spinning particles, Physical Review D 35 (1987), 2383–2387.
- [26] , Exponential beams of electromagnetic radiation, Journal of Physics B: Atomic, Molecular and Optical Physics 39 (2006), no. 15, S545.
- [27] , Gravitational waves carrying orbital angular momentum, New Journal of Physics 18 (2016), no. 2, 023022.
- [28] , Relativistic electron wave packets carrying angular momentum, Physical Review Letters 118 (2017), 114801.
- [29] I. Bialynicki-Birula and S. Charzy´nski, Trapping and guiding bodies by gravitational waves endowed with angular momentum, Physical Review Letters 121 (2018), 171101.
- [30] D. Bini, C. Cherubini, A. Geralico, and R. T. Jantzen, Massless spinning test particles in algebraically special vacuum space–times, International Journal of Modern Physics D 15 (2006), no. 05, 737–758.
- [31] J. D. Bjorken and S. D. Drell, Relativistic quantum mechanics, McGraw-Hill, 1965.
- [32] K. Y. Bliokh, Geometrical optics of beams with vortices: Berry phase and orbital angular momentum Hall effect, Physical Review Letters 97 (2006), 043901.
- [33] , Geometrodynamics of polarized light: Berry phase and spin Hall effect in a gradient-index medium, Journal of Optics A: Pure and Applied Optics 11 (2009), no. 9, 094009.
- [34] K. Y. Bliokh and A. Aiello, Goos–H¨anchen and Imbert–Fedorov beam shifts: An overview, Journal of Optics 15 (2013), no. 1, 014001.
- [35] K. Y. Bliokh and Y. P. Bliokh, Modified geometrical optics of a smoothly inhomogeneous isotropic medium: The anisotropy, Berry phase, and the optical Magnus effect, Physical Review E 70 (2004), 026605.
- [36] , Topological spin transport of photons: The optical Magnus effect and Berry phase, Physics Letters A 333 (2004), no. 3, 181–186.
- [37] K. Y. Bliokh, A. Niv, V. Kleiner, and E. Hasman, Geometrodynamics of spinning light, Nature Photonics 2 (2008), 748.
- [38] K. Y. Bliokh and F. Nori, Transverse and longitudinal angular momenta of light, Physics Reports 592 (2015), 1–38.
- [39] K. Y. Bliokh, F. J. Rodr´ıguez-Fortu˜no, F. Nori, and A. V. Zayats, Spin-orbit interactions of light, Nature Photonics 9 (2015), no. 12, 796–808.
- [40] A. Brodutch, T. F. Demarie, and D. R. Terno, Photon polarization and geometric phase in general relativity, Physical Review D 84 (2011), 104043.
- [41] A. Brodutch and D. R. Terno, Polarization rotation, reference frames, and Mach's principle, Physical Review D 84 (2011), 121501.
- [42] Y. Q. Cai and G. Papini, Applying Berry's phase to problems involving weak gravitational and inertial fields, Classical and Quantum Gravity 7 (1990), no. 2, 269.
- [43] Y. Q. Cai, G. Papini, and W. R. Wood, Berry's phase for photons and topology in Maxwell's theory, Journal of Mathematical Physics 31 (1990), no. 8, 1942–1946.
- [44] P. Carini, L. L. Feng, M. Li, and R. Ruffini, Phase evolution of the photon in Kerr spacetime, Physical Review D 46 (1992), 5407–5413.
- [45] K. M. Case, Some generalizations of the Foldy-Wouthuysen transformation, Physical Review 95 (1954), 1323–1328.
- [46] S. Chen and J. Jing, Strong gravitational lensing for the photons coupled to Weyl tensor in a Schwarzschild black hole spacetime, Journal of Cosmology and Astroparticle Physics 2015 (2015), no. 10, 002.
- [47] S. Chen, S. Wang, Y. Huang, J. Jing, and S. Wang, Strong gravitational lensing for the photons coupled

- to a Weyl tensor in a Kerr black hole spacetime, Physical Review D 95 (2017), no. 10, 104017.
- [48] R. Y. Chiao and Y.-S. Wu, Manifestations of Berry's topological phase for the photon, Physical Review Letters 57 (1986), 933–936.
- [49] D. Chru´sci´nski and A. Jamio lkowski, Geometric phases in classical and quantum mechanics, vol. 36, Springer Science & Business Media, 2012.
- [50] A. Corichi and M. Pierri, Gravity and geometric phases, Physical Review D 51 (1995), 5870–5875.
- [51] L. F. Costa, C. Herdeiro, J. Nat´ario, and M. Zilhao, Mathisson's helical motions for a spinning particle: Are they unphysical?, Physical Review D 85 (2012), no. 2, 024001.
- [52] L. F. O. Costa, G. Lukes-Gerakopoulos, and O. Semer´ak, Spinning particles in general relativity: Momentum-velocity relation for the Mathisson-Pirani spin condition, Physical Review D 97 (2018), no. 8, 084023.
- [53] L. F. O. Costa and J. Nat´ario, Center of mass, spin supplementary conditions, and the momentum of spinning particles, Equations of Motion in Relativistic Gravity, Springer, 2015, pp. 215–258.
- [54] L. F. O. Costa, J. Nat´ario, and M. Zilh˜ao, Spacetime dynamics of spinning particles: Exact electromagnetic analogies, Physical Review D 93 (2016), no. 10, 104006.
- [55] R. D. Daniels and G. M. Shore, "Faster than light" photons and charged black holes, Nuclear Physics B 425 (1994), no. 3, 634–650.
- [56] G. De Nittis and M. Lein, The Schr¨odinger formalism of electromagnetism and other classical waves — How to make quantum-wave analogies rigorous, Annals of Physics 396 (2018), 579–617.
- [57] W. G. Dixon, A covariant multipole formalism for extended test bodies in general relativity, Il Nuovo Cimento (1955-1965) 34 (1964), no. 2, 317–339.
- [58] , The definition of multipole moments for extended bodies, General Relativity and Gravitation 4 (1973), no. 3, 199–209.
- [59] , The new mechanics of Myron Mathisson and its subsequent development, Equations of Motion in Relativistic Gravity, Springer, 2015, pp. 1–66.
- [60] I. Y. Dodin, Geometric view on noneikonal waves, Physics Letters A 378 (2014), no. 22, 1598–1621.
- [61] I. Y. Dodin, D. E. Ruiz, K. Yanagihara, Y. Zhou, and S. Kubo, Quasioptical modeling of wave beams with and without mode conversion: I. Basic theory, arXiv preprint arXiv:1901.00268 (2019).
- [62] S. R. Dolan, Geometrical optics for scalar, electromagnetic and gravitational waves on curved spacetime, International Journal of Modern Physics D 27 (2018), 1843010.
- [63] , Higher-order geometrical optics for circularly-polarized electromagnetic waves, arXiv preprint arXiv:1801.02273 (2018).
- [64] A. D. Dolgov and I. D. Novikov, Superluminal propagation of light in gravitational field and non-causal signals, Physics Letters B 442 (1998), no. 1–4, 82–89.
- [65] A. V. Dooghin, N. D. Kundikova, V. S. Liberman, and B. Ya. Zel'dovich, Optical Magnus effect, Physical Review A 45 (1992), 8204–8208.
- [66] C. Duval, Polarized spinoptics and symplectic physics, arXiv preprint arXiv:1312.4486 (2013).
- [67] C. Duval and H. H. Fliche, A conformal invariant model of localized spinning test particles, Journal of Mathematical Physics 19 (1978), no. 4, 749–752.
- [68] C. Duval, Z. Horv´ath, and P. A. Horv´athy, Fermat principle for spinning light, Physical Review D 74 (2006), 021701.
- [69] , Geometrical spinoptics and the optical Hall effect, Journal of Geometry and Physics 57 (2007), no. 3, 925–941.
- [70] C. Duval, L. Marsot, and T. Sch¨ucker, Gravitational birefringence of light in Schwarzschild spacetime, arXiv preprint arXiv:1812.03014 (2018).
- [71] C. Duval and T. Sch¨ucker, Gravitational birefringence of light in Robertson-Walker cosmologies, Phys-

- ical Review D 96 (2017), 043517.
- [72] M. I. Dyakonov and A. V. Khaetskii, Spin Hall Effect, pp. 211–243, Springer Berlin Heidelberg, 2008.
- [73] M. I. Dyakonov and V. I. Perel, Current-induced spin orientation of electrons in semiconductors, Physics Letters A 35 (1971), no. 6, 459–460.
- [74] , Possibility of orienting electron spins with current, Soviet Journal of Experimental and Theoretical Physics Letters 13 (1971), 467.
- [75] G. d'Ambrosi, S. Satish Kumar, J. van de Vis, and J. W. van Holten, Spinning bodies in curved spacetime, Physical Review D 93 (2016), no. 4, 044051.
- [76] G. d'Ambrosi, S. Satish Kumar, and J. W. van Holten, Covariant hamiltonian spin dynamics in curved space–time, Physics Letters B 743 (2015), 478–483.
- [77] A. S. Eddington, Space, time and gravitation: An outline of the general relativity theory, Cambridge University Press, 1987.
- [78] A. Farooqui, N. Kamran, and P. Panangaden, An exact expression for photon polarization in Kerr geometry, Advances in Theoretical and Mathematical Physics 18 (2014), no. 3, 659–686.
- [79] M. Fathi and R. T. Thompson, Cartographic distortions make dielectric spacetime analog models imperfect mimickers, Physical Review D 93 (2016), 124026.
- [80] F. Fayos and J. Llosa, Gravitational effects on the polarization plane, General Relativity and Gravitation 14 (1982), no. 10, 865–877.
- [81] F. I. Fedorov, To the theory of total reflection, Journal of Optics 15 (2013), no. 1, 014002.
- [82] L.-L. Feng and W. Lee, Gravitomagnetism and the Berry phase of photon in an rotating gravitational field, International Journal of Modern Physics D 10 (2001), no. 06, 961–969.
- [83] R. Fickler, G. Campbell, B. Buchler, P. K. Lam, and A. Zeilinger, Quantum entanglement of angular momentum states with quantum numbers up to 10,010, Proceedings of the National Academy of Sciences 113 (2016), no. 48, 13642–13647.
- [84] L. L. Foldy and S. A. Wouthuysen, On the Dirac theory of spin 1/2 particles and its non-relativistic limit, Physical Review 78 (1950), 29–36.
- [85] V. P. Frolov and A. A. Shoom, Spinoptics in a stationary spacetime, Physical Review D 84 (2011), 044026.
- [86] , Scattering of circularly polarized light by a rotating black hole, Physical Review D 86 (2012), 024010.
- [87] S. A. H. Gangaraj, M. G. Silveirinha, and G. W. Hanson, Berry phase, Berry connection, and Chern number for a continuum bianisotropic material from a classical electromagnetics perspective, IEEE Journal on Multiscale and Multiphysics Computational Techniques 2 (2017), 3–17.
- [88] J. C. Garrison and R. Y. Chiao, Geometrical phases from global gauge invariance of nonlinear classical field theories, Physical Review Letters 60 (1988), 165–168.
- [89] F. Goos and H. H¨anchen, Ein neuer und fundamentaler versuch zur totalreflexion, Annalen der Physik 436 (1947), no. 7–8, 333–346.
- [90] W. Gordon, Zur lichtfortpflanzung nach der relativit¨atstheorie, Annalen der Physik 377 (1923), no. 22, 421–456.
- [91] P. Gosselin, A. B´erard, and H. Mohrbach, Semiclassical diagonalization of quantum Hamiltonian and equations of motion with Berry phase corrections, The European Physical Journal B 58 (2007), no. 2, 137–148.
- [92] , Semiclassical dynamics of Dirac particles interacting with a static gravitational field, Physics Letters A 368 (2007), no. 5, 356–361.
- [93] , Spin Hall effect of photons in a static gravitational field, Physical Review D 75 (2007), 084035.
- [94] W. Greiner and D.A. Bromley, Relativistic quantum mechanics. Wave equations, Springer, 2000.

- [95] J. B. Griffiths and J. Podolsk`y, Exact space-times in Einstein's general relativity, Cambridge University Press, 2009.
- [96] E. Hackmann, C. L¨ammerzahl, Y. N. Obukhov, D. Puetzfeld, and I. Schaffer, Motion of spinning test bodies in Kerr spacetime, Physical Review D 90 (2014), no. 6, 064035.
- [97] D. Haefner, S. Sukhov, and A. Dogariu, Spin Hall effect of light in spherical geometry, Physical Review Letters 102 (2009), 123903.
- [98] F. D. M. Haldane, Path dependence of the geometric rotation of polarization in optical fibers, Optics Letters 11 (1986), no. 11, 730–732.
- [99] , Comment on "Observation of Berry's topological phase by use of an optical fiber", Physical Review Letters 59 (1987), 1788–1788.
- [100] W.-B. Han, Gravitational radiation from a spinning compact object around a supermassive Kerr black hole in circular orbit, Physical Review D 82 (2010), no. 8, 084013.
- [101] A. I. Harte, Gravitational lensing beyond geometric optics: I. Formalism and observables, General Relativity and Gravitation 51 (2019), no. 1, 14.
- [102] O. Hosten and P. Kwiat, Observation of the spin Hall effect of light via weak measurements, Science 319 (2008), no. 5864, 787–790.
- [103] C. Imbert, Calculation and experimental proof of the transverse shift induced by total internal reflection of a circularly polarized light beam, Physical Review D 5 (1972), no. 4, 787.
- [104] H. Ishihara, M. Takahashi, and A. Tomimatsu, Gravitational Faraday rotation induced by a Kerr black hole, Physical Review D 38 (1988), 472–477.
- [105] J. D. Jackson, Classical electrodynamics, John Wiley & Sons, 2012.
- [106] J. Jayaraman, A note on the recent Foldy-Wouthuysen transformations for particles of arbitrary spin, Journal of Physics A: Mathematical and General 8 (1975), no. 1, L1.
- [107] T. Kato, On the Adiabatic Theorem of Quantum Mechanics, Journal of the Physical Society of Japan 5 (1950), no. 6, 435–439.
- [108] Y. K. Kato, R. C. Myers, A. C. Gossard, and D. D. Awschalom, Observation of the spin Hall effect in semiconductors, Science 306 (2004), no. 5703, 1910–1913.
- [109] I. B. Khriplovich and A. A. Pomeransky, Gravitational interaction of spinning bodies, center-of-mass coordinate and radiation of compact binary systems, Physics Letters A 216 (1996), no. 1, 7–14.
- [110] J. Kohlrus, J. Louko, I. Fuentes, and D. E. Bruschi, Wigner phase of photonic helicity states in the spacetime of the Earth, arXiv preprint arXiv:1810.10502 (2018).
- [111] M. Y. Konstantinov, Superluminal propagation of light in gravitational field and non-causal signals: Some comments, arXiv preprint arXiv:gr-qc/9810019 (1998).
- [112] M. Krenn and A. Zeilinger, On small beams with large topological charge: II. Photons, electrons and gravitational waves, New Journal of Physics 20 (2018), no. 6, 063006.
- [113] K. Kyrian and O. Semer´ak, Spinning test particles in a Kerr field–II, Monthly Notices of the Royal Astronomical Society 382 (2007), no. 4, 1922–1932.
- [114] R. Lafrance and R. C Myers, Gravity's Rainbow: Limits for the applicability of the equivalence principle, Physical Review D 51 (1995), no. 6, 2584.
- [115] H. Larocque, I. Kaminer, V. Grillo, G. Leuchs, M. J. Padgett, R. W. Boyd, M. Segev, and E. Karimi, 'Twisted' electrons, Contemporary Physics 59 (2018), no. 2, 126–144.
- [116] V. S. Liberman and B. Y. Zel'dovich, Spin-orbit interaction of a photon in an inhomogeneous medium, Physical Review A 46 (1992), 5199–5207.
- [117] N. H. Lindner, A. Peres, and D. R. Terno, Wigner's little group and Berry's phase for massless particles, Journal of Physics A: Mathematical and General 36 (2003), no. 29, L449.
- [118] X. Ling, X. Yi, X. Zhou, Y. Liu, W. Shu, H. Luo, and S. Wen, Realization of tunable spin-dependent

- splitting in intrinsic photonic spin Hall effect, Applied Physics Letters 105 (2014), no. 15, 151101.
- [119] X. Ling, X. Zhou, K. Huang, Y. Liu, C.-W. Qiu, H. Luo, and S. Wen, Recent advances in the spin Hall effect of light, Reports on Progress in Physics 80 (2017), no. 6, 066401.
- [120] H. Luo, X. Zhou, W. Shu, S. Wen, and D. Fan, Enhanced and switchable spin Hall effect of light near the Brewster angle on reflection, Physical Review A 84 (2011), 043806.
- [121] M. Mars, C. F. Paganini, and M. A. Oancea, The fingerprints of black holes–shadows and their degeneracies, Classical and Quantum Gravity 35 (2018), no. 2, 025005.
- [122] L. Marsot, How does the photon's spin affect gravitational wave measurements?, arXiv preprint arXiv:1904.09260 (2019).
- [123] B. Mashhoon, Massless spinning test particles in a gravitational field, Annals of Physics 89 (1975), no. 1, 254–257.
- [124] B. Mashhoon and D. Singh, Dynamics of extended spinning masses in a gravitational field, Physical Review D 74 (2006), no. 12, 124006.
- [125] M. Mathisson, Republication of: New mechanics of material systems, General Relativity and Gravitation 42 (2010), no. 4, 1011–1048.
- [126] B. J. McMorran, A. Agrawal, I. M. Anderson, A. A. Herzing, H. J. Lezec, J. J. McClelland, and J. Unguris, Electron vortex beams with high quanta of orbital angular momentum, Science 331 (2011), no. 6014, 192–195.
- [127] C. W. Misner, K. S. Thorne, and J. A. Wheeler, Gravitation, W. H. Freeman San Francisco, 1973.
- [128] N. Mukunda and R. Simon, Quantum Kinematic Approach to the Geometric Phase. I. General Formalism, Annals of Physics 228 (1993), no. 2, 205–268.
- [129] T. M¨uller and F. Grave, Catalogue of spacetimes, arXiv preprint arXiv:0904.4184 (2009).
- [130] S. Murakami, Intrinsic Spin Hall Effect, pp. 197–209, Springer Berlin Heidelberg, 2006.
- [131] M. Nouri-Zonoz, Gravitoelectromagnetic approach to the gravitational Faraday rotation in stationary spacetimes, Physical Review D 60 (1999), 024013.
- [132] Y. N. Obukhov, Spin, gravity, and inertia, Physical Review Letters 86 (2001), 192–195.
- [133] Y. N. Obukhov, A. J. Silenko, and O. V. Teryaev, Spin dynamics in gravitational fields of rotating bodies and the equivalence principle, Physical Review D 80 (2009), 064044.
- [134] , Dirac fermions in strong gravitational fields, Physical Review D 84 (2011), 024025.
- [135] , Spin in an arbitrary gravitational field, Physical Review D 88 (2013), no. 8, 084014.
- [136] , General treatment of quantum and classical spinning particles in external fields, Physical Review D 96 (2017), no. 10, 105005.
- [137] M. Onoda, S. Murakami, and N. Nagaosa, Hall effect of light, Physical Review Letters 93 (2004), 083901.
- [138] M. C. Palmer, M. Takahashi, and H. F. Westman, Localized qubits in curved spacetimes, Annals of Physics 327 (2012), no. 4, 1078–1131.
- [139] D. Pan and H.-X. Xu, Gravitational field around black hole induces photonic spin–orbit interaction that twists light, Frontiers of Physics 12 (2017), no. 5, 128102.
- [140] S. Pancharatnam, Generalized theory of interference, and its applications, Proceedings of the Indian Academy of Sciences - Section A 44 (1956), no. 5, 247–262.
- [141] A. Papapetrou, Spinning test-particles in general relativity. I, Proceedings of the Royal Society of London. Series A, Mathematical and Physical Sciences 209 (1951), no. 1097, 248–258.
- [142] A. K. Pati, Geometric aspects of noncyclic quantum evolutions, Physical Review A 52 (1995), 2576– 2584.
- [143] R. Penrose and W. Rindler, Spinors and space-time: Two-spinor calculus and relativistic fields, vol. 1, Cambridge University Press, 1987.

- [144] V. Perlick, Ray optics, Fermat's principle, and applications to general relativity, vol. 61, Springer Science & Business Media, 2000.
- [145] , Gravitational lensing from a spacetime perspective, Living Reviews in Relativity 7 (2004), no. 1, 9.
- [146] F. A. E. Pirani, Republication of: On the physical significance of the Riemann tensor, General Relativity and Gravitation 41 (2009), no. 5, 1215–1232.
- [147] J. Plebanski, Electromagnetic waves in gravitational fields, Physical Review 118 (1960), 1396–1408.
- [148] R. A. Porto, A. Ross, and I. Z. Rothstein, Spin induced multipole moments for the gravitational wave flux from binary inspirals to third Post-Newtonian order, Journal of Cosmology and Astroparticle Physics 2011 (2011), no. 03, 009.
- [149] W. G. Ram´ırez and A. A. Deriglazov, Lagrangian formulation for Mathisson-Papapetrou-Tulczyjew-Dixon equations, Physical Review D 92 (2015), no. 12, 124017.
- [150] J. N. Ross, The rotation of the polarization in low birefringence monomode optical fibres due to geometric effects, Optical and Quantum Electronics 16 (1984), no. 5, 455–461.
- [151] R. R¨udiger, The Dirac equation and spinning particles in general relativity, Proceedings of the Royal Society of London, Series A, Mathematical and Physical Sciences 377 (1981), 417–424.
- [152] D. E. Ruiz, A geometric theory of waves and its applications to plasma physics, arXiv preprint arXiv:1708.05423 (2017).
- [153] D. E. Ruiz and I. Y. Dodin, First-principles variational formulation of polarization effects in geometrical optics, Physical Review A 92 (2015), 043805.
- [154] , Lagrangian geometrical optics of nonadiabatic vector waves and spin particles, Physics Letters A 379 (2015), no. 38, 2337–2350.
- [155] , On the correspondence between quantum and classical variational principles, Physics Letters A 379 (2015), no. 40, 2623–2630.
- [156] , Extending geometrical optics: A Lagrangian theory for vector waves, Physics of Plasmas 24 (2017), no. 5, 055704.
- [157] S. M. Rytov, On the transition from wave to geometrical optics, Doklady Akademii Nauk SSSR, vol. 18, 1938, pp. 263–267.
- [158] J. Samuel and R. Bhandari, General setting for Berry's phase, Physical Review Letters 60 (1988), 2339–2342.
- [159] P. Saturnini, Un mod`ele de particule `a spin de masse nulle dans le champ de gravitation, Thesis, Universit´e de Provence, 1976.
- [160] J. Sbierski, Characterisation of the energy of Gaussian beams on Lorentzian manifolds: With applications to black hole spacetimes, Analysis & PDE 8 (2015), no. 6, 1379–1420.
- [161] F. Schneiter, D. R¨atzel, and D. Braun, Rotation of polarization in the gravitational field of a laser beam - Faraday effect and optical activity, arXiv preprint arXiv:1812.04505 (2018).
- [162] O. Semer´ak, Spinning test particles in a Kerr field—I, Monthly Notices of the Royal Astronomical Society 308 (1999), no. 3, 863–875.
- [163] , Spinning particles in vacuum spacetimes of different curvature types: Natural reference tetrads and massless particles, Physical Review D 92 (2015), no. 12, 124036.
- [164] M. Sereno, Gravitational Faraday rotation in a weak gravitational field, Physical Review D 69 (2004), 087501.
- [165] G. M. Shore, 'Faster than light' photons in gravitational fields—Causality, anomalies and horizons, Nuclear Physics B 460 (1996), no. 2, 379–394.
- [166] , Accelerating photons with gravitational radiation, Nuclear Physics B 605 (2001), no. 1–3, 455–466.

- [167] , Faster than light photons in gravitational fields II.: Dispersion and vacuum polarisation, Nuclear Physics B 633 (2002), no. 1–2, 271–294.
- [168] , Quantum gravitational optics, Contemporary Physics 44 (2003), no. 6, 503–521.
- [169] , Causality and superluminal light, Time and Matter, World Scientific, 2006, pp. 45–66.
- [170] A. J. Silenko, Foldy-Wouthyusen transformation and semiclassical limit for relativistic particles in strong external fields, Physical Review A 77 (2008), no. 1, 012116.
- [171] A. J. Silenko and O. V. Teryaev, Semiclassical limit for Dirac particles interacting with a gravitational field, Physical Review D 71 (2005), 064016.
- [172] B. Simon, Holonomy, the quantum adiabatic theorem, and Berry's phase, Physical Review Letters 51 (1983), 2167–2170.
- [173] D. Singh, An analytic perturbation approach for classical spinning particle dynamics, General Relativity and Gravitation 40 (2008), no. 6, 1179–1192.
- [174] , Perturbation method for classical spinning particle motion. I. Kerr space-time, Physical Review D 78 (2008), no. 10, 104028.
- [175] N. A. Sinitsyn, Semiclassical theories of the anomalous Hall effect, Journal of Physics: Condensed Matter 20 (2007), no. 2, 023201.
- [176] J. Sinova, S. O. Valenzuela, J. Wunderlich, C. H. Back, and T. Jungwirth, Spin Hall effects, Reviews of Modern Physics 87 (2015), 1213–1260.
- [177] S. Sivasubramanian, G. Castellani, N. Fabiano, A. Widom, J. Swain, Y. N. Srivastava, and G. Vitiello, Non-commutative geometry and measurements of polarized two photon coincidence counts, Annals of Physics 311 (2004), no. 1, 191–203.
- [178] A. P. Slobozhanyuk, A. N. Poddubny, I. S. Sinev, A. K. Samusev, Y. F. Yu, A. I. Kuznetsov, A. E. Miroshnichenko, and Y. S. Kivshar, Enhanced photonic spin Hall effect with subwavelength topological edge states, Laser & Photonics Reviews 10 (2016), no. 4, 656–664.
- [179] J.-M. Souriau, Modele de particulea spin dans le champ ´electromagn´etique et gravitationnel, Annales de l'Institut Henri Poincar´e A 20 (1974), 315–364.
- [180] J. Steinhoff, Spin and quadrupole contributions to the motion of astrophysical binaries, Equations of Motion in Relativistic Gravity, Springer, 2015, pp. 615–649.
- [181] A. Tomita and R. Y. Chiao, Observation of Berry's topological phase by use of an optical fiber, Physical Review Letters 57 (1986), 937–940.
- [182] W. Tulczyjew, Motion of multipole particles in general relativity theory, Acta Physica Polonica 18 (1959), 393.
- [183] M. Uchida and A. Tonomura, Generation of electron beams carrying orbital angular momentum, Nature 464 (2010), 737.
- [184] J. W. van Holten, Spinning bodies in general relativity, International Journal of Geometric Methods in Modern Physics 13 (2016), no. 08, 1640002.
- [185] , World-line perturbation theory, pp. 393–418, Springer International Publishing, Cham, 2019.
- [186] J. Vines, D. Kunst, J. Steinhoff, and T. Hinderer, Canonical Hamiltonian for an extended test body in curved spacetime: To quadratic order in spin, Physical Review D 93 (2016), no. 10, 103008.
- [187] M. Visser, The Kerr spacetime: A brief introduction, arXiv preprint arXiv:0706.0622 (2007).
- [188] V. V. Vladimirskii, The rotation of polarization plane for curved light ray, Doklady Akademii Nauk SSSR, vol. 31, 1941, pp. 222–226.
- [189] K. Volke-Sepulveda, V. Garc´es-Ch´avez, S. Ch´avez-Cerda, J. Arlt, and K. Dholakia, Orbital angular momentum of a high-order Bessel light beam, Journal of Optics B: Quantum and Semiclassical Optics 4 (2002), no. 2, S82.
- [190] Z.-Y. Wang, C.-D. Xiong, Q. Qiu, Y.-X. Wang, and S.-J. Shi, The effect of gravitational spin–orbit

- coupling on the circular photon orbit in the Schwarzschild geometry, Classical and Quantum Gravity 33 (2016), no. 11, 115020.
- [191] F. Wilczek and A. Zee, Appearance of gauge structure in simple dynamical systems, Physical Review Letters 52 (1984), 2111–2114.
- [192] D. Xiao, M.-C. Chang, and Q. Niu, Berry phase effects on electronic properties, Reviews of Modern Physics 82 (2010), 1959–2007.
- [193] N. Yamamoto, Spin Hall effect of gravitational waves, Physical Review D 98 (2018), 061701.
- [194] C.-M. Yoo, Notes on spinoptics in a stationary spacetime, Physical Review D 86 (2012), 084005.