# PROPAGATION OF POLARIZED GRAVITATIONAL WAVES

LARS ANDERSSON, JÉRÉMIE JOUDIOUX, MARIUS A. OANCEA, AND AYUSH RAJ

ABSTRACT. The propagation of high-frequency gravitational waves can be analyzed using the geometrical optics approximation. In the case of large but finite frequencies, the geometrical optics approximation is no longer accurate and polarization-dependent corrections at first order in wavelength modify the propagation of gravitational waves, via a spin-orbit coupling mechanism. We present a covariant derivation from first principles of effective ray equations describing the propagation of polarized gravitational waves, up to first-order terms in wavelength, on arbitrary spacetime backgrounds. The effective ray equations describe a gravitational spin Hall effect for gravitational waves, and are of the same form as those describing the gravitational spin Hall effect of light, derived from Maxwell's equations.

# Introduction

The advent of gravitational wave observations brings a new range of phenomena related to the dynamics of the gravitational field to our attention. Gravitational waves propagate over cosmological distances and carry, in addition to information about their sources, imprints of cosmological expansion and inhomogeneities in the universe. The fact that the important sources of gravitational waves emit in a very broad range of wavelengths [19] makes it essential to include effects beyond geometrical optics on their propagation, when considering lensing of gravitational waves [31, 14].

Spin-orbit couplings play an essential role when analyzing the propagation of spinning particles and fields in inhomogeneous media beyond the geometrical optics and test particle limit [10]. For the spin-1 Maxwell field, the spin Hall effect of light has been verified experimentally. When the wavelength is small in comparison with the inhomogeneity scale of the media, a wave packet undergoes a polarization-dependent deviation of the propagation of light beams from the path predicted by geometrical optics [29, 8]. This can be viewed as a manifestation of spin-orbit coupling via the Berry curvature. In general relativity, the dynamics of spinning particles is described by the Mathisson-Papapetrou-Dixon equations [32, 37, 47, 15, 16], with a suitable closure relation, the so-called spin-supplementary condition.

Polarization-dependent effects for the propagation of Maxwell fields in curved spacetimes have been discussed previously in Refs. [26, 23, 42, 22, 25]. A detailed review and further references can be found in Ref. [36]. Recently, a covariant derivation of the gravitational spin Hall effect of light, based on first principles, has been given in Ref. [35]. Similarly, the effective ray equations for massive spin- $\frac{1}{2}$  Dirac fields, beyond the geometrical optics limit, have been discussed in Refs. [2, 39, 34]. The spin-2 nature of the gravitational field leads one to expect that corrections to geometrical optics, involving the Berry curvature, will be relevant also for gravitational waves [49, 50].

In this paper, we present the first covariant analysis of the spin Hall effect for gravitational waves. Following the strategy developed in Ref. [35] for the Maxwell field, as well as the general theory given in Ref. [30], we provide a derivation from first principles of effective ray equations describing the propagation of gravitational waves, up to first-order terms in

1

wavelength, on arbitrary spacetime backgrounds. The equations of motions are obtained through a higher-order geometrical optics approximation using a Wentzel-Kramers-Brillouin (WKB) ansatz. The dynamics of the polarization is described in terms of the Berry connection, and terms of first order in wavelength in the effective ray equations involve the Berry curvature, manifesting the spin nature of the gravitational field. These corrections to the standard trajectories of geometrical optics, the null geodesics, may be termed as the spin Hall effect of gravitational waves [49]. It can be shown that the equations of motion are of the same nature as the Mathisson-Papapetrou-Dixon equations for massless spinning particles [27, 34], completed by the Corinaldesi-Papapetrou spin supplementary condition (see [13, Section 3.2.1). Our treatment is covariant and applicable to arbitrary curved spacetimes, in contrast to previous work present in the literature. For example, the derivation of the spin Hall effect for gravitational waves given in Ref. [49] is not explicitly covariant, and it is limited to propagation in static spacetimes in the weak-field limit. Our derivation of the effect is obtained from the classical field theory of linearized gravity, in contrast with Ref. [49] where the author argues that the effect is quantum in nature. Another derivation of a spin Hall effect for gravitational waves was proposed in Ref. [50]. While this approach is manifestly covariant, it is limited to stationary spacetimes.

Our starting point is the classical field theory of linearized gravity, governed by a truncated form of the Einstein-Hilbert Lagrangian. A metric perturbation in the form of a WKB ansatz is inserted in the action for linearized gravity, and the resulting expression is truncated after the first order in the inverse of the frequency. This provides a Lagrangian representing the WKB approximation of the linearized gravity field theory. The corresponding Euler-Lagrange equations, with Lorenz gauge imposed, provide the dispersion relation and the transport equation for the amplitude. The dispersion relation is used to define a Hamiltonian for the effective ray equations.

The paper is organized as follows. Sec. 1 contains the general setup. The basic equations for linearized gravity are presented in Sec. 1.1, the gauge choice is discussed in Sec. 1.2, and the WKB Ansatz is introduced in Sec. 1.3. The WKB approximation of the action is made in Sec. 2, and it is shown how the well-known results of geometrical optics can be obtained from the corresponding Euler-Lagrange equations. In Sec. 2.5 we discuss the dynamics of the polarization tensor in terms of the Berry connection. The effective dispersion relation is derived in Sec. 2.6. Finally, the effective ray equations are discussed in Sec. 3. Appendix A contains a discussion on some algebraic property of the symbol. Appendix B presents a self-contained derivation of the equation of linearized gravity. Appendix C contains a basic discussion of the Lorenz gauge.

#### NOTATIONS AND CONVENTIONS

We consider an arbitrary smooth Lorentzian manifold  $(M, g_{\mu\nu})$ , where the metric tensor  $g_{\mu\nu}$  has signature (-+++). The absolute value of the metric determinant is denoted as  $g = |\det g_{\mu\nu}|$ . The phase space is defined as the cotangent bundle  $T^*M$ , and phase space points are denoted as (x,p). The Einstein summation convention is assumed. Greek indices represent space-time indices, and run from 0 to 3. Latin indices, (a,b,c,...), represent tetrad indices and run from 0 to 3. We adopt the curvature conventions of [28].

# 1. The Einstein field equations and linearized gravity

We consider the vacuum Einstein field equations with vanishing cosmological constant

$$R_{\alpha\beta} - \frac{1}{2}Rg_{\alpha\beta} = 0, (1.1)$$

where  $R_{\alpha\beta}$  is the Ricci tensor,  $R = R^{\alpha}_{\alpha}$  is the Ricci scalar. The Einstein field equations can be obtained as the Euler-Lagrange equations of the Einstein-Hilbert action

$$J(g_{\mu\nu}) = \int_{M} d^{4}x \sqrt{g} R(g_{\mu\nu}).$$
 (1.2)

Our goal is to describe the propagation of gravitational waves, treated as a small metric perturbation around a fixed background solution of the vacuum Einstein field equations. For this purpose, in the next section we derive the linearization of the Einstein-Hilbert action and the corresponding equations for the linearized gravitational field.

Note that, we could have treated the case of a non-vanishing cosmological constant since, in the high-frequency analysis, the latter plays no role.

1.1. Linearization of the Einstein-Hilbert action. We remind here the form of the linearized Einstein-Hilbert action, see Ref. [6]. For completeness, the derivation, which is often not presented in detail in the literature, is performed in Appendix B. Let  $g_{\mu\nu}$  be a solution of the Einstein field equations in vacuum

$$R_{\alpha\beta} = 0. ag{1.3}$$

We consider a Lorentzian metric  $\tilde{g}_{\mu\nu}$ , obtained through a small perturbation  $h_{\mu\nu}$  of  $g_{\mu\nu}$ :

$$\tilde{g}_{\mu\nu} = g_{\mu\nu} + h_{\mu\nu}.\tag{1.4}$$

Linearizing the Einstein-Hilbert action near  $g_{\mu\nu}$  as in Ref. [6], we obtain

$$J(\tilde{g}_{\mu\nu}) = J(g_{\mu\nu}) + J_{lin}(h_{\mu\nu}) + \mathcal{O}(|h|^3), \tag{1.5}$$

where

$$J_{lin}(h_{\mu\nu}) = \int_{M} d^{4}x \sqrt{g} \left( -\frac{1}{2} \nabla^{\gamma} h^{\alpha\beta} \nabla_{\gamma} h_{\alpha\beta} + \frac{1}{2} \nabla_{\gamma} h \nabla^{\gamma} h - \nabla_{\alpha} h \nabla_{\beta} h^{\alpha\beta} + \nabla_{\alpha} h_{\gamma\beta} \nabla^{\gamma} h^{\alpha\beta} \right)$$
(1.6)

is the action for the perturbation  $h_{\mu\nu}$ . Index manipulation and covariant derivatives are defined with respect to the background metric  $g_{\alpha\beta}$ , and  $h = h_{\alpha\beta}g^{\alpha\beta}$ . Integrating by parts and neglecting the boundary terms, the linearized action can be written as

$$J_{lin}(h_{\mu\nu}) = \int_{M} d^{4}x \sqrt{g} h^{\alpha\beta} \hat{D}_{\alpha\beta}^{\ \gamma\delta} h_{\gamma\delta}, \qquad (1.7)$$

where  $\hat{D}_{\alpha\beta}^{\phantom{\alpha\beta}\gamma\delta}$  is the differential operator

$$\hat{D}_{\alpha\beta}^{\ \gamma\delta} = \frac{1}{2} \left( \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} \nabla_{\mu} \nabla^{\mu} - g_{\alpha\beta} g^{\gamma\delta} \nabla_{\mu} \nabla^{\mu} + g^{\gamma\delta} \nabla_{\alpha} \nabla_{\beta} + g_{\alpha\beta} \nabla^{\gamma} \nabla^{\delta} - \delta_{\beta}^{\delta} \nabla^{\gamma} \nabla_{\alpha} - \delta_{\alpha}^{\delta} \nabla^{\gamma} \nabla_{\beta} \right). \tag{1.8}$$

The corresponding Euler-Lagrange equations are

$$\hat{D}_{\alpha\beta}^{\ \gamma\delta}h_{\gamma\delta} = 0. \tag{1.9}$$

Introducing the trace-reverse tensor

$$\check{h}_{\alpha\beta} = h_{\alpha\beta} - \frac{1}{2}hg_{\alpha\beta}, \tag{1.10}$$

Eq. (1.9) becomes

$$\nabla_{\alpha} \nabla^{\alpha} \check{h}_{\mu\nu} + \nabla_{\alpha} \nabla_{\beta} \check{h}^{\alpha\beta} g_{\mu\nu} - \nabla^{\alpha} \nabla_{\mu} \check{h}_{\alpha\nu} - \nabla^{\alpha} \nabla_{\nu} \check{h}_{\alpha\mu} = 0. \tag{1.11}$$

Taking the trace of Eq. (1.11) leads to

$$\nabla_{\alpha} \nabla^{\alpha} h = 2 \nabla^{\alpha} \nabla^{\mu} \check{h}_{\alpha \mu}. \tag{1.12}$$

1.2. **The Lorenz gauge.** The Einstein field equations are gauged equations. The gauge freedom can be exploited to reduce the Einstein field equation to a hyperbolic system of equations. A detailed discussion of this reduction in the particular case of the wave gauge can be found in Refs. [38, Section 14.1] or [21, Section 2.4].

A similar reduction can be applied to the linearized equations (1.9). The linearization of the gauge freedom of the Einstein field equations leads to the invariance of Eq. (1.9) by the transformation

$$h_{\mu\nu} \mapsto h_{\mu\nu} - \nabla_{\mu}\xi_{\nu} - \nabla_{\nu}\xi_{\mu},\tag{1.13}$$

where  $\xi_{\mu}$  is a one-form on M. The gauge invariance of the linearized field equations (1.9) can be exploited to make these equations hyperbolic. The linearization of the wave gauge for the Einstein field equations leads to the Lorenz gauge condition for the linearized field equations (1.9):

$$\nabla_{\alpha} \check{h}^{\alpha\beta} = \nabla_{\alpha} \left( h^{\alpha\beta} - \frac{1}{2} h g^{\alpha\beta} \right) = 0. \tag{1.14}$$

The detailed derivation of this equation is presented in Appendix C. Imposing the Lorenz gauge condition, Eq. (1.9) is reduced to the following wave equation:

$$\nabla^{\alpha} \nabla_{\alpha} \check{h}_{\mu\nu} - 2R_{\nu\alpha\sigma\mu} \check{h}^{\alpha\sigma} = 0, \tag{1.15}$$

and Eq. (1.12) for the trace of the perturbations decouples:

$$\nabla_{\alpha} \nabla^{\alpha} h = 0. \tag{1.16}$$

Using the expression of  $\check{h}_{\mu\nu}$  given in Eq. (1.10), and using the fact that  $g_{\mu\nu}$  has vanishing Ricci curvature, we obtain

$$\nabla^{\alpha}\nabla_{\alpha}h_{\mu\nu} - 2R_{\nu\alpha\sigma\mu}h^{\alpha\sigma} = 0. \tag{1.17}$$

1.3. **WKB Ansatz.** We assume that the perturbation metric  $h_{\alpha\beta}$  admits a WKB expansion of the form

$$h_{\alpha\beta}(x) = \operatorname{Re}\left[A_{\alpha\beta}(x, k(x), \epsilon)e^{iS(x)/\epsilon}\right],$$

$$A_{\alpha\beta}(x, k(x), \epsilon) = A_{0\alpha\beta}(x, k(x)) + \epsilon A_{1\alpha\beta}(x, k(x)) + \mathcal{O}(\epsilon^2),$$
(1.18)

where S is a real scalar function,  $A_{\alpha\beta}$  is a complex amplitude, and  $\epsilon$  is a small expansion parameter. The gradient of S is denoted as

$$k_{\mu}(x) = \nabla_{\mu} S(x). \tag{1.19}$$

We are allowing the amplitude  $A_{\alpha\beta}$  to depend on  $k_{\mu}(x)$ . This is justified by the mathematical formulation of the WKB approximation [3, 18], where  $k_{\mu}(x)$  determines a Lagrangian submanifold of  $x \mapsto (x, k(x)) \in T^*M$ , and the amplitude  $A_{\alpha\beta}$  is defined on the Lagrangian submanifold.

1.4. Assumption on the initial data. We consider a Cauchy surface in M, and we make the following assumptions. Firstly, the gauge condition given in Eq. (1.14) is initially satisfied. Secondly, the trace of the perturbation h vanishes initially. Equation (1.16) guarantees that this condition is conserved in the future of  $\Sigma$ . Finally, the gravitational waves have initially circular polarization (see Sec. 2.5).

# 2. The WKB approximation for linearized gravity

The WKB analysis of various field equations is generally performed by inserting the WKB ansatz directly into the field equation, followed by an analysis of the resulting terms at each order in the expansion parameter  $\epsilon$ . However, for the purpose of studying spin Hall effects, we find it more convenient to perform the WKB analysis by inserting the WKB ansatz into the field action. The advantages of such a variational formulation of the WKB approximation are extensively discussed in Ref. [46] (see also Refs. [40, 41]). In particular, a similar approach proved to be effective in the derivation of the gravitational spin Hall effect of light [35].

2.1. Euler-Lagrange equations in the WKB approximation. We insert the WKB ansatz (1.18) into the linearized Einstein-Hilbert action (1.7). Keeping only terms of the lowest two orders in  $\epsilon$ , we obtain

$$2\epsilon^{2}J_{lin} = \int_{M} d^{4}x \sqrt{g} \left[ A^{*\alpha\beta} D_{\alpha\beta}^{\ \gamma\delta} A_{\gamma\delta} - \frac{i\epsilon}{2} \overset{v}{\nabla}^{\mu} D_{\alpha\beta}^{\ \gamma\delta} \left( A^{*\alpha\beta} \nabla_{\mu} A_{\gamma\delta} - A_{\gamma\delta} \nabla_{\mu} A^{*\alpha\beta} \right) \right] + \mathcal{O}(\epsilon^{2}), \tag{2.1}$$

where

$$D_{\alpha\beta}^{\ \gamma\delta} = \frac{1}{2} \left( k_{\mu} k^{\mu} \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} - k_{\mu} k^{\mu} g_{\alpha\beta} g^{\gamma\delta} + k_{\alpha} k_{\beta} g^{\gamma\delta} + k^{\gamma} k^{\delta} g_{\alpha\beta} - k_{\alpha} k^{\gamma} \delta_{\beta}^{\delta} - k_{\beta} k^{\gamma} \delta_{\alpha}^{\delta} \right),$$

$$\overset{v}{\nabla}^{\mu} D_{\alpha\beta}^{\ \gamma\delta} = k^{\mu} \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} - k^{\mu} g_{\alpha\beta} g^{\gamma\delta} + k_{(\alpha} \delta_{\beta)}^{\mu} g^{\gamma\delta} + k^{(\gamma} g^{\delta)\mu} g_{\alpha\beta} - k_{(\alpha} \delta_{\beta)}^{\delta} g^{\gamma\mu} - k^{\gamma} \delta_{(\alpha}^{\mu} \delta_{\beta)}^{\delta},$$

$$\overset{v}{\nabla}^{\mu} \overset{v}{\nabla}^{\nu} D_{\alpha\beta}^{\ \gamma\delta} = g^{\mu\nu} \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} - g^{\mu\nu} g_{\alpha\beta} g^{\gamma\delta} + \delta_{(\alpha}^{\mu} \delta_{\beta)}^{\nu} g^{\gamma\delta} + g^{\mu(\gamma} g^{\delta)\nu} g_{\alpha\beta} - \delta_{(\alpha}^{\mu} \delta_{\beta)}^{\delta} g^{\gamma\nu} - g^{\gamma\mu} \delta_{(\alpha}^{\nu} \delta_{\beta)}^{\delta}$$

$$(2.2)$$

In the above equation,  $D_{\alpha\beta}^{\ \gamma\delta}$  represents the symbol of the operator  $\hat{D}_{\alpha\beta}^{\ \gamma\delta}$ , and  $\overset{v}{\nabla}^{\mu} = \frac{\partial}{\partial k_{\mu}}$  denotes the vertical derivative (see Ref. [35, Appendix A] for the definition of horizontal and vertical derivatives). Formally, up to the expression of the symbol  $D_{\alpha\beta}^{\ \gamma\delta}$ , the effective action (2.1) is of the same form as the effective action obtained in the electromagnetic case [35, Eq. (3.3)].

The effective action (2.1) depends on S(x),  $A_{\alpha\beta}(x, \nabla S)$  and  $A^{*\alpha\beta}(x, \nabla S)$ , and the variation can be performed as in [35, Appendix B]. The resulting Euler–Lagrange equations are

$$D_{\alpha\beta}{}^{\gamma\delta}A_{\gamma\delta} - i\epsilon(\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})\nabla_{\mu}A_{\gamma\delta} - \frac{i\epsilon}{2}(\nabla_{\mu}\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})A_{\gamma\delta} = \mathcal{O}(\epsilon^2) \quad (2.3)$$

$$D_{\alpha\beta}{}^{\gamma\delta}A^{*\alpha\beta} + i\epsilon(\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})\nabla_{\mu}A^{*\alpha\beta} + \frac{i\epsilon}{2}(\nabla_{\mu}\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})A^{*\alpha\beta} = \mathcal{O}(\epsilon^{2}) \quad (2.4)$$

$$\nabla_{\mu} \left[ (\overset{v}{\nabla}{}^{\mu} D_{\alpha\beta}{}^{\gamma\delta}) A^{*\alpha\beta} A_{\gamma\delta} - \frac{i\epsilon}{2} (\overset{v}{\nabla}{}^{\mu} \overset{v}{\nabla}{}^{\nu} D_{\alpha\beta}{}^{\gamma\delta}) \left( A^{*\alpha\beta} \nabla_{\nu} A_{\gamma\delta} - A_{\gamma\delta} \nabla_{\nu} A^{*\alpha\beta} \right) \right] = \mathcal{O}(\epsilon^2) \quad (2.5)$$

In the above equations, the symbol  $D_{\alpha\beta}^{\ \gamma\delta}$  and its vertical derivatives are evaluated at the phase space point (x,p)=(x,k).

2.2. WKB approximation of the Lorenz gauge. In order to remove unwanted pure gauge degrees of freedom, the Euler-Lagrange equations (2.3)-(2.5) should be supplemented with additional equations. For this purpose, we impose the Lorenz gauge condition on the metric perturbation  $h_{\alpha\beta}$ . The WKB approximation of the Lorenz gauge condition is obtained by inserting the WKB ansatz (1.18) into Eq. (1.14). At the lowest order in  $\epsilon$ , we obtain

$$k^{\alpha} A_{0\alpha\mu} = \frac{1}{2} k_{\mu} A_0, \tag{2.6}$$

and at  $\mathcal{O}(\epsilon^0)$  we obtain

$$\nabla^{\alpha} A_{0\alpha\mu} + ik^{\alpha} A_{1\alpha\mu} = \frac{1}{2} (\nabla_{\mu} A_0 + ik_{\mu} A_1), \tag{2.7}$$

where  $A_0 = g^{\alpha\beta} A_{0\alpha\beta}$  and  $A_1 = g^{\alpha\beta} A_{1\alpha\beta}$ . These equations can also be supplemented by the corresponding complex conjugate equations.

2.3. Equations at order  $\epsilon^0$ . Keeping only terms of order  $\epsilon^0$ , Equations (2.3)-(2.5) reduce to

$$D_{\alpha\beta}^{\ \gamma\delta}A_{0\gamma\delta} = 0 \tag{2.8}$$

$$D_{\alpha\beta}^{\ \gamma\delta} A_0^{*\alpha\beta} = 0 \tag{2.9}$$

$$\nabla_{\mu} \left[ (\overset{v}{\nabla}{}^{\mu} D_{\alpha\beta}{}^{\gamma\delta}) A_0^{*\alpha\beta} A_{0\gamma\delta} \right] = 0 \tag{2.10}$$

Since Equations (2.8) and (2.9) are related by complex conjugation, it is enough to analyze only one of them. Using the definition of the symbol  $D_{\alpha\beta}^{\ \ \gamma\delta}$ , Equation (2.8) can be written as

$$\frac{1}{2} \left( k_{\mu} k^{\mu} \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} - k_{\mu} k^{\mu} g_{\alpha\beta} g^{\gamma\delta} + k_{\alpha} k_{\beta} g^{\gamma\delta} + k^{\gamma} k^{\delta} g_{\alpha\beta} - k_{\alpha} k^{\gamma} \delta_{\beta}^{\delta} - k_{\beta} k^{\gamma} \delta_{\alpha}^{\delta} \right) A_{0\gamma\delta} = 0 \qquad (2.11)$$

This equation admits nontrivial solutions if and only if  $A_{0\gamma\delta}$  is in the kernel of the tensor  $D_{\alpha\beta}^{\ \gamma\delta}$ . The kernel of  $D_{\alpha\beta}^{\ \gamma\delta}$  is discussed in detail in Appendix A. By imposing the Lorenz gauge condition (2.6) in Eq. (2.11), we obtain

$$k_{\mu}k^{\mu}\left(A_{0\alpha\beta} - \frac{1}{2}g_{\alpha\beta}A_0\right) = 0 \tag{2.12}$$

This equation can only be satisfied if either  $k_{\mu}k^{\mu} = 0$  or  $A_{0\alpha\beta} - \frac{1}{2}g_{\alpha\beta}A_0 = 0$ . However, taking  $A_{0\alpha\beta} - \frac{1}{2}g_{\alpha\beta}A_0 = 0$  implies that  $A_{0\alpha\beta} = 0$ . Discarding this trivial solution, we are left with the dispersion relation

$$k_{\mu}k^{\mu} = 0, (2.13)$$

which is a well-known result of geometrical optics. Furthermore, since  $k_{\mu}$  is the gradient of a scalar function, it satisfies

$$\nabla_{\mu}k_{\alpha} = \nabla_{\alpha}k_{\mu}.\tag{2.14}$$

Using this property, together with the dispersion relation (2.13), we can derive the geodesic equation for  $k_{\mu}$ :

$$k^{\nu}\nabla_{\nu}k_{\mu} = 0. \tag{2.15}$$

Imposing the Lorenz gauge condition (2.6) in Equation (2.10), we obtain

$$\nabla_{\mu} \left[ k^{\mu} \left( A_0^{*\alpha\beta} A_{0\alpha\beta} - \frac{1}{2} A_0^* A_0 \right) \right] = 0. \tag{2.16}$$

This equation represents a transport equation for the intensity  $\mathcal{I}_0 = A_0^{*\alpha\beta} A_{0\alpha\beta} - \frac{1}{2} A_0^* A_0$ , which is another well-known result of geometrical optics.

2.4. **Equations at order**  $\epsilon^1$ . We continue the WKB analysis by taking equations (2.8) and (2.9) at order  $\epsilon^1$  only:

$$D_{\alpha\beta}{}^{\gamma\delta}A_{1\gamma\delta} - i(\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})\nabla_{\mu}A_{0\gamma\delta} - \frac{i}{2}(\nabla_{\mu}\overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})A_{0\gamma\delta} = 0, \tag{2.17}$$

$$D_{\alpha\beta}{}^{\gamma\delta}A_1{}^{*\alpha\beta} + i(\overset{v}{\nabla}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})\nabla_{\mu}A_0{}^{*\alpha\beta} + \frac{i}{2}(\nabla_{\mu}\overset{v}{\nabla}^{\mu}D_{\alpha\beta}{}^{\gamma\delta})A_0{}^{*\alpha\beta} = 0. \tag{2.18}$$

We can simplify these equations by imposing the Lorenz gauge condition (2.6) and (2.7), and by using equations (2.13) and (2.14). We obtain

$$k^{\mu} \nabla_{\mu} \left( A_{0\alpha\beta} - \frac{1}{2} g_{\alpha\beta} A_0 \right) + \frac{1}{2} \left( A_{0\alpha\beta} - \frac{1}{2} g_{\alpha\beta} A_0 \right) \nabla_{\mu} k^{\mu} = 0, \tag{2.19}$$

$$k^{\mu} \nabla_{\mu} \left( A_0^{*\alpha\beta} - \frac{1}{2} g^{\alpha\beta} A_0^* \right) + \frac{1}{2} \left( A_0^{*\alpha\beta} - \frac{1}{2} g^{\alpha\beta} A_0^* \right) \nabla_{\mu} k^{\mu} = 0.$$
 (2.20)

Furthermore, using the lowest-order intensity  $\mathcal{I}_0$ , we can write the amplitude tensors in the following way:

$$A_{0\alpha\beta} - \frac{1}{2}g_{\alpha\beta}A_0 = \sqrt{J_0}a_{0\alpha\beta}, \qquad A_0^{*\alpha\beta} - \frac{1}{2}g^{\alpha\beta}A_0^* = \sqrt{J_0}a_0^{*\alpha\beta}, \tag{2.21}$$

where  $a_{0\alpha\beta}$  is a complex tensor, describing the polarization of the gravitational wave. Note that, due to the Lorenz gauge condition (2.6), the polarization tensor  $a_{0\alpha\beta}$  satisfies the orthogonality condition

$$k^{\alpha}a_{0\alpha\beta} = 0. (2.22)$$

Using the transport equation (2.16), Eqs. (2.19) and (2.20) reduce to

$$k^{\mu} \nabla_{\mu} a_{0\alpha\beta} = k^{\mu} \nabla_{\mu} a_0^{*\alpha\beta} = 0.$$
 (2.23)

The parallel propagation of the complex polarization tensor  $a_{0\alpha\beta}$  along  $k^{\mu}$  is another well-known result of the geometrical optics approximation.

2.5. The polarization tensor in a null tetrad. The properties of the polarization tensor  $a_{0\alpha\beta}$  become more transparent when expressed in terms of a null tetrad adapted to  $k_{\alpha}$ . Working with the metric signature (-,+,+,+), we establish a set of four complex null vectors  $\{k_{\alpha}, n_{\alpha}, m_{\alpha}, \bar{m}_{\alpha}\}$  at each point in space-time, which satisfy the following orthogonality relations:

$$m_{\alpha}\bar{m}^{\alpha} = 1, \qquad k_{\alpha}n^{\alpha} = -1,$$

$$k_{\alpha}k^{\alpha} = n_{\alpha}n^{\alpha} = m_{\alpha}m^{\alpha} = \bar{m}_{\alpha}\bar{m}^{\alpha} = 0,$$

$$k_{\alpha}m^{\alpha} = k_{\alpha}\bar{m}^{\alpha} = n_{\alpha}m^{\alpha} = n_{\alpha}\bar{m}^{\alpha} = 0.$$
(2.24)

Since the polarization tensor  $a_{0\mu\nu}$  is symmetric, it can have at most ten independent components. However, due to the orthogonality condition (2.22), we are left with only six independent components. Using the null tetrad, we can write the polarization tensor as

$$a_{0\mu\nu} = z_1 m_{\mu} m_{\nu} + z_2 \bar{m}_{\mu} \bar{m}_{\nu} + z_3 m_{(\mu} \bar{m}_{\nu)} + z_4 k_{\mu} k_{\nu} + z_5 k_{(\mu} m_{\nu)} + z_6 k_{(\mu} \bar{m}_{\nu)}, \tag{2.25}$$

where  $z_i$  are complex scalar functions. Inserting this expansion of the polarization tensor into the parallel transport equation (2.23), and making use of the orthogonality relations (2.24), we obtain the following transport equations for the scalar functions  $z_i$ :

$$k^{\alpha}\nabla_{\alpha}z_{1} = -2z_{1}\bar{m}^{\mu}k^{\alpha}\nabla_{\alpha}m_{\mu}, \tag{2.26a}$$

$$k^{\alpha}\nabla_{\alpha}z_{2} = -2z_{2}m^{\mu}k^{\alpha}\nabla_{\alpha}\bar{m}_{\mu}, \tag{2.26b}$$

$$k^{\alpha}\nabla_{\alpha}z_3 = 0, (2.26c)$$

$$k^{\alpha}\nabla_{\alpha}z_4 = -(z_5m^{\mu} + z_6\bar{m}^{\mu})k^{\alpha}\nabla_{\alpha}n_{\mu}, \qquad (2.26d)$$

$$k^{\alpha}\nabla_{\alpha}z_{5} = -(z_{3}\bar{m}^{\mu} + 2z_{1}m^{\mu})k^{\alpha}\nabla_{\alpha}n_{\mu} - z_{5}\bar{m}^{\nu}k^{\alpha}\nabla_{\alpha}m_{\nu}, \qquad (2.26e)$$

$$k^{\alpha}\nabla_{\alpha}z_{6} = -(z_{3}m^{\mu} + 2z_{2}\bar{m}^{\mu})k^{\alpha}\nabla_{\alpha}n_{\mu} - z_{6}m^{\nu}k^{\alpha}\nabla_{\alpha}\bar{m}_{\nu}. \tag{2.26f}$$

The transport equations for  $z_1$ ,  $z_2$  and  $z_3$  are decoupled. Furthermore, the evolution of the trace of  $a_{0\mu\nu}$  is described by  $z_3$ , which is covariantly constant along  $k^{\alpha}$ , and its value will be fixed by the choice of initial conditions. As mentioned in Sec. 1.4, we consider initial data such that the metric perturbation is initially traceless. Thus, we impose  $z_3 = 0$ . The other components,  $z_4$ ,  $z_5$  and  $z_6$ , describe the evolution of pure gauge degrees of freedom, which were not fixed by imposing the Lorenz gauge. It is shown in Appendix A that the components of the metric perturbation proportional to  $z_4$ ,  $z_5$  and  $z_6$  do not contribute, at the lowest order in  $\epsilon$ , to the Riemann tensor. They are in that sense pure gauge.

The non pure-gauge degrees of freedom, describing the polarization of the metric perturbation are represented by the terms proportional to the complex scalar functions  $z_1$  and  $z_2$ . The tensors  $m_{\mu}m_{\nu}$  and  $\bar{m}_{\mu}\bar{m}_{\nu}$  represent a circular polarization basis for linearized metric perturbations, analogue to the circular polarization basis covectors  $m_{\mu}$  and  $\bar{m}_{\mu}$  used in the description of electromagnetic waves (a detailed comparison between the polarization of electromagnetic and gravitational waves can be found in [33, Sec. 35.6]). By picking initial data such that the metric perturbation is initially traceless (which is equivalent to  $z_3 = 0$ ), Eq. (2.21) implies that

$$a_0^{*\mu\nu}a_{0\mu\nu} = z_1^*z_1 + z_2^*z_2 = 1.$$
 (2.27)

This relation restricts  $(z_1, z_2) \in \mathbb{C}^2$  to the unit 3-sphere  $S^3$ . Furthermore,  $(z_1, z_2)$  and  $(e^{i\phi}z_1, e^{i\phi}z_2)$  (for any real  $\phi$ ), represent the same polarization state. Thus, the space of physically distinguishable polarization states is the complex projective line  $\mathbb{C}P^1 = S^3/U(1) = S^2$  (in optics, this is called the Poincare sphere; see Refs [11, Sec. 1.4.2] [4, Sec 5.2]).

The transport equations for  $z_1$  and  $z_2$  have the same form as in the electromagnetic case [35, Eq. (3.36)], the only difference being a factor of 2, which corresponds to the fact that here we are dealing with a spin-2 field, instead of the electromagnetic field, which is a spin-1 field. As in Ref. [35], it is convenient to rewrite the transport equations for  $z_1$  and  $z_2$  in terms of the Berry connection. First, we should remember that the covectors  $m_{\alpha}$  and  $\bar{m}_{\alpha}$  are functions of x and k(x), because of the orthogonality relations given in Eq. (2.24). Thus, we must carefully apply the chain rule when taking covariant derivatives of  $m_{\alpha}$  and  $\bar{m}_{\alpha}$ :

$$k^{\mu}\nabla_{\mu}m_{\alpha} = k^{\mu}\nabla_{\mu}\left[m_{\alpha}(x,k)\right]$$

$$= k^{\mu}\left(\stackrel{h}{\nabla}_{\mu}m_{\alpha}\right)(x,k) + k^{\mu}\left(\nabla_{\mu}k_{\nu}\right)\left(\stackrel{v}{\nabla}^{\nu}m_{\alpha}\right)(x,k)$$

$$= k^{\mu}\stackrel{h}{\nabla}_{\mu}m_{\alpha},$$
(2.28)

where  $\overset{h}{\nabla}_{\mu}$  is the horizontal derivative, defined in Ref. [35, Appendix A]. As in the electromagnetic case, the scalar functions  $z_1$  and  $z_2$  can be encoded in a 2-dimensional unit complex vector, which is analogous to the Jones vector used in optics [20, 7, 40, 41]:

$$z = \begin{pmatrix} z_1 \\ z_2 \end{pmatrix}, \qquad z^{\dagger} = \begin{pmatrix} z_1^* & z_2^* \end{pmatrix}.$$
 (2.29)

The transport equations for  $z_1$  and  $z_2$  can be rewritten as

$$k^{\mu}\nabla_{\mu}z = 2ik^{\mu}B_{\mu}\sigma_3z,\tag{2.30}$$

where  $\sigma_3$  is the third Pauli matrix,

$$\sigma_3 = \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix},\tag{2.31}$$

and  $B_{\mu}$  is the Berry connection

$$B_{\mu}(x,k) = \frac{i}{2} \left( \bar{m}^{\alpha} \nabla_{\mu} m_{\alpha} - m_{\alpha} \nabla_{\mu} \bar{m}^{\alpha} \right) = i \bar{m}^{\alpha} \nabla_{\mu} m_{\alpha}. \tag{2.32}$$

The Berry connection has the same definition as in the electromagnetic case [35]. The Berry phase can be defined by considering a worldline  $x^{\mu}(\tau)$ , with  $\dot{x}^{\mu} = k^{\mu}$ . Then, by restricting z to the worldline  $x^{\mu}(\tau)$ , we obtain

$$\dot{z} = 2ik^{\mu}B_{\mu}\sigma_3 z. \tag{2.33}$$

This equation can be integrated along the worldline  $x^{\mu}(\tau)$  as

$$z(\tau) = \begin{pmatrix} e^{2i\gamma(\tau)} & 0\\ 0 & e^{-2i\gamma(\tau)} \end{pmatrix} z(0), \tag{2.34}$$

and we obtain the Berry phase  $\gamma$  as

$$\gamma(\tau_1) = \int_{\tau_2}^{\tau_1} d\tau k^{\mu} B_{\mu}. \tag{2.35}$$

Using equation (2.33), we can show that the following quantities are conserved along  $k^{\mu}$ :

$$1 = z_1^* z_1 + z_2^* z_2 = z^{\dagger} z,$$
  

$$s = 2(z_1^* z_1 - z_2^* z_2) = 2z^{\dagger} \sigma_3 z.$$
(2.36)

Based on our assumptions on the initial conditions, given in Sec. 1.4, we only consider metric perturbations which are initially circularly polarized. This corresponds to

$$z(0) = \begin{pmatrix} 1 \\ 0 \end{pmatrix}$$
 or  $z(0) = \begin{pmatrix} 0 \\ 1 \end{pmatrix}$ . (2.37)

Thus, we have  $s = \pm 2$ , depending on the choice of the initial polarization state. Here, the parameter s represents the helicity of the metric perturbation.

2.6. Effective dispersion relation. The results derived so far are based on a standard approach to the WKB analysis, by imposing that terms at different orders in  $\epsilon$  in the Euler-Lagrange equations (2.3)-(2.5) vanish separately. With this approach, we derived the well-known geometrical optics results: the dispersion relation (2.13) and the transport equation for the polarization tensor (2.23). While the dynamics of the polarization tensor in Eq. (2.23) depends on  $k_{\mu}$ , and, hence, on the dispersion relation (2.13), there is no backreaction from the dynamics of the polarization tensor onto the dispersion relation (2.23) and onto  $k_{\mu}$ . In other words, the standard geometrical optics approach does not take into account all the possible spin-orbit interactions between the external and internal degrees of freedom, here represented by the wave vector  $k_{\mu}$  and polarization tensor  $a_{0\mu\nu}$ .

In the derivation of the spin Hall effect, as observed in Ref. [35] (see also Ref. [10]), it is essential to gather terms related to geometrical optics and terms involving the polarization. This is the so-called spin-orbit coupling. This can be achieved by collating the separately satisfied Eqs. (2.3)–(2.5) into one quantity depending on powers of  $\epsilon$  at order 0 and 1, and vanishing at order  $O(\epsilon^2)$ .

Starting with Eqs. (2.3)–(2.5), an effective dispersion relation can be derived in the in the following way. We contract Eq. (2.3) with  $A^{*\alpha\beta}$  and Eq. (2.4) with  $A_{\gamma\delta}$ . Adding these equations together, we obtain

$$D_{\alpha\beta}{}^{\gamma\delta}A^{*\alpha\beta}A_{\gamma\delta} - \frac{i\epsilon}{2} \left( \overset{v}{\nabla}{}^{\mu}D_{\alpha\beta}{}^{\gamma\delta} \right) \left( A^{*\alpha\beta}\nabla_{\mu}A_{\gamma\delta} - A_{\gamma\delta}\nabla_{\mu}A^{*\alpha\beta} \right) = \mathcal{O}(\epsilon^2). \tag{2.38}$$

Using  $A_{\alpha\beta} = A_{0\alpha\beta} + \epsilon A_{1\alpha\beta} + \mathcal{O}(\epsilon^2)$ , the Lorenz gauge condition given in Eqs. (2.6) and (2.7), as well as Eq. (2.2), we can rewrite the above equation as

$$\frac{1}{2}k^{\mu}k_{\mu}\left[J_{0} + \epsilon\left(A_{0\alpha\beta}A_{1}^{*\alpha\beta} + A_{0}^{*\alpha\beta}A_{1\alpha\beta} - \frac{1}{2}A_{0}A_{1}^{*} - \frac{1}{2}A_{1}A_{0}^{*}\right)\right] - \frac{i\epsilon}{2}k^{\mu}\left[A_{0}^{*\gamma\delta}\nabla_{\mu}A_{0\gamma\delta} - A_{0\gamma\delta}\nabla_{\mu}A_{0}^{*\gamma\delta} + \frac{1}{2}\left(A_{0}^{*}\nabla_{\mu}A_{0} - A_{0}\nabla_{\mu}A_{0}^{*}\right)\right] = \mathcal{O}(\epsilon)^{2}$$
(2.39)

The above equation can be further simplified by introducing the  $\mathcal{O}(\epsilon)^1$  intensity as

$$\mathfrak{I}_{1} = \left( A_{\alpha\beta} A^{*\alpha\beta} - \frac{1}{2} A A^{*} \right) + \mathfrak{O}(\epsilon)^{2} 
= \mathfrak{I}_{0} + \epsilon \left( A_{0\alpha\beta} A_{1}^{*\alpha\beta} + A_{0}^{*\alpha\beta} A_{1\alpha\beta} - \frac{1}{2} A_{0} A_{1}^{*} - \frac{1}{2} A_{1} A_{0}^{*} \right) + \mathfrak{O}(\epsilon)^{2}.$$
(2.40)

Then, we can rewrite the amplitude as

$$A_{\alpha\beta} = \sqrt{\Im_1} a_{\alpha\beta} = \sqrt{\Im_1} (a_{0\alpha\beta} + \epsilon a_{1\alpha\beta}) + \mathcal{O}(\epsilon)^2, \tag{2.41}$$

and from Eq. (2.39) we obtain

$$\frac{1}{2}k_{\mu}k^{\mu} - \frac{i\epsilon}{2}k^{\mu}\left(a_0^{*\alpha\beta}\nabla_{\mu}a_{0\alpha\beta} - a_{0\alpha\beta}\nabla_{\mu}a_0^{*\alpha\beta}\right) = \mathcal{O}(\epsilon^2). \tag{2.42}$$

This represents an effective dispersion relation, containing  $\mathcal{O}(\epsilon)$  corrections to the geometrical optics equation (2.13). We can also introduce the notation

$$K_{\mu} = k_{\mu} - \frac{i\epsilon}{2} \left( a_0^{*\alpha\beta} \nabla_{\mu} a_{0\alpha\beta} - a_{0\alpha\beta} \nabla_{\mu} a_0^{*\alpha\beta} \right)$$
 (2.43)

and rewrite the effective dispersion relation as

$$\frac{1}{2}K_{\mu}K^{\mu} = \mathcal{O}(\epsilon^2). \tag{2.44}$$

In a similar way, starting with (2.5), and considering  $A_{\alpha\beta} = A_{0\alpha\beta} + \epsilon A_{1\alpha\beta} + \mathcal{O}(\epsilon^2)$ , the Lorenz gauge condition given in Eqs. (2.6) and (2.7), as well as Eq. (2.2), we obtain

$$\nabla_{\mu} \left\{ \Im_{1} \left[ k^{\mu} - \frac{i\epsilon}{2} g^{\mu\nu} \left( a_{0}^{*\alpha\beta} \nabla_{\nu} a_{0\alpha\beta} - a_{0\alpha\beta} \nabla_{\nu} a_{0}^{*\alpha\beta} \right) \right] \right\} = \nabla_{\mu} \left( \Im_{1} K^{\mu} \right) = \mathcal{O}(\epsilon^{2}). \tag{2.45}$$

This is an effective transport equation for the intensity  $\mathcal{I}_1$ , which includes  $\mathcal{O}(\epsilon)$  corrections to the geometrical optics equation (2.16).

# 3. Effective ray equations

The transition from the WKB approximation of a field theory to an effective point-particle description can be realized by treating the dispersion relation as a Hamilton-Jacobi equation for the phase function [1, Sec. 46]. It has also been argued in Refs. [33, Box 25.3] [24, Sec. II] that the physical interpretation of the effective point-particle description provided by solving the Hamilton-Jacobi equation is related to the principle of constructive interference. One can define a localized wave packet by considering a superposition of WKB wave functions with slightly different wave vectors. The peak of intensity of this superposition occurs where the waves interfere constructively and coincides with the ray trajectories given by the effective point-particle description.

At the lowest order in  $\epsilon$ , we obtained in Eq. (2.13) the dispersion relation

$$\frac{1}{2}g^{\mu\nu}k_{\mu}k_{\nu} = 0, (3.1)$$

where  $k_{\mu} = \nabla_{\mu} S$ . This can be viewed as a Hamilton-Jacobi equation, which is a nonlinear first-order partial differential equation for the phase function S. We can solve the Hamilton-Jacobi equation by using the method of characteristics [1, Sec. 46]. This is done by defining a Hamiltonian function H(x, p) on  $T^*M$ , related to the dispersion relation by

$$H(x, \nabla S) = \frac{1}{2} g^{\mu\nu} k_{\mu} k_{\nu} = 0.$$
 (3.2)

In this case, the Hamiltonian function is

$$H(x,p) = \frac{1}{2}g^{\mu\nu}p_{\mu}p_{\nu},\tag{3.3}$$

where  $p_{\mu}$  is a general covector on  $T^*M$ , unlike  $k_{\mu}$ , which is a gradient of a scalar function. The effective point-particle description is given by Hamilton's equations

$$\dot{x}^{\mu} = \frac{\partial H}{\partial p_{\mu}} = g^{\mu\nu} p_{\nu}, \tag{3.4}$$

$$\dot{p}_{\mu} = -\frac{\partial H}{\partial x^{\mu}} = -\frac{1}{2}\partial_{\mu}g^{\alpha\beta}p_{\alpha}p_{\beta}.$$
(3.5)

Given a set of ray trajectories  $\{x^{\mu}(\tau), p_{\mu}(\tau)\}$  representing a solution of Hamilton's equations, we can obtain a solution of the Hamilton–Jacobi equation as [1, Sec. 46]

$$S(x^{\mu}(\tau_1), p_{\mu}(\tau_1)) = \int_{\tau_0}^{\tau_1} d\tau \left[ \dot{x}^{\mu} p_{\mu} - H(x, p) \right] + \text{const.}$$
 (3.6)

Thus, at the lowest order in  $\epsilon$  of the WKB approximation, we have obtained an effective point-particle description in terms of Hamilton's equations (3.4) and (3.5). These are the geodesic equations of the underlying spacetime.

In order to describe spin Hall effects, higher-order terms in the WKB analysis must be taken into account. This can be achieved by considering the effective dispersion relation obtained in Eq. (2.42):

$$\frac{1}{2}k_{\mu}k^{\mu} - \frac{i\epsilon}{2}k^{\mu}\left(a_0^{*\alpha\beta}\nabla_{\mu}a_{0\alpha\beta} - a_{0\alpha\beta}\nabla_{\mu}a_0^{*\alpha\beta}\right) = \mathcal{O}(\epsilon^2). \tag{3.7}$$

Our aim is to treat this relation as an effective Hamilton-Jacobi equation, and to explore the corresponding effective point-particle description. Using the expansion of the polarization tensor  $a_{0\alpha\beta}$ , given in Eq. (2.25), we can rewrite the effective dispersion relation as

$$\frac{1}{2}g^{\mu\nu}k_{\mu}k_{\nu} - \frac{i\epsilon}{2}k^{\mu}\left(z^{\dagger}\partial_{\mu}z - \partial_{\mu}z^{\dagger}z\right) - \epsilon sk^{\mu}B_{\mu} = \mathcal{O}(\epsilon^{2}),\tag{3.8}$$

where  $B_{\mu} = B_{\mu}(x, k)$  is the Berry connection defined in Eq. (2.32), and  $s = \pm 2$ , depending on the initial state of circular polarization. Note that, except for the different value of the constant s, we have obtained the same effective dispersion relation as in the electromagnetic case [35, Eq. (4.12)]. Using Eq. (2.34), we can rewrite the second term in Eq. (3.8) in terms of the Berry phase  $\gamma$ :

$$-\frac{i\epsilon}{2}k^{\mu}\left(z^{\dagger}\partial_{\mu}z - \partial_{\mu}z^{\dagger}z\right) = \epsilon sk^{\mu}\partial_{\mu}\gamma. \tag{3.9}$$

Using the Berry phase, we can define an effective phase function  $\tilde{S} = S + \epsilon s \gamma$  and an effective wave vector  $\nabla_{\mu} \tilde{S} = \tilde{k}_{\mu} = k_{\mu} + \epsilon s \nabla_{\mu} \gamma$ . Then, the effective dispersion relation can be written as

$$\frac{1}{2}g^{\mu\nu}\tilde{k}_{\mu}\tilde{k}_{\nu} - \epsilon s\tilde{k}^{\mu}B_{\mu} = \mathcal{O}(\epsilon^2), \tag{3.10}$$

This equation can be considered as an effective Hamilton-Jacobi equation for the effective phase function  $\tilde{S}$ . Since circularly polarized WKB metric perturbations are of the form

$$h_{\alpha\beta} = \operatorname{Re}\left[\sqrt{\Im}m_{\alpha}m_{\beta}e^{i\gamma}e^{iS(x)/\epsilon}\right] \quad \text{or} \quad h_{\alpha\beta} = \operatorname{Re}\left[\sqrt{\Im}\bar{m}_{\alpha}\bar{m}_{\beta}e^{-i\gamma}e^{iS(x)/\epsilon}\right],$$
 (3.11)

the effective phase function  $\tilde{S}$  represents the overall phase factor of the WKB ansatz, up to order  $\mathcal{O}(\epsilon^2)$ . As in the previous case, we solve the effective Hamilton-Jacobi equation for the unknown  $\tilde{S}$  by using the method of characteristics. We are seeking a Hamiltonian function H(x,p) on  $T^*M$ , related to the effective dispersion relation by

$$H\left(x,\nabla\tilde{S}\right) = \frac{1}{2}g^{\mu\nu}\tilde{k}_{\mu}\tilde{k}_{\nu} - \epsilon s\tilde{k}^{\mu}B_{\mu} = \mathcal{O}(\epsilon^{2}). \tag{3.12}$$

In this case, the Hamiltonian function is

$$H(x,p) = \frac{1}{2}g^{\mu\nu}p_{\mu}p_{\nu} - \epsilon sg^{\mu\nu}p_{\mu}B_{\nu}(x,p), \tag{3.13}$$

and the effective point-particle description is given by Hamilton's equations

$$\dot{x}^{\mu} = \frac{\partial H}{\partial p_{\mu}} = g^{\mu\nu} p_{\nu} - \epsilon s \left( B^{\mu} + p^{\alpha} \nabla^{\mu} B_{\alpha} \right), \tag{3.14}$$

$$\dot{p}_{\mu} = -\frac{\partial H}{\partial x^{\mu}} = -\frac{1}{2}\partial_{\mu}g^{\alpha\beta}p_{\alpha}p_{\beta} + \epsilon sp_{\alpha}\left(\partial_{\mu}g^{\alpha\beta}B_{\beta} + g^{\alpha\beta}\partial_{\mu}B_{\beta}\right). \tag{3.15}$$

These equations describe the spin Hall effect of gravitational waves. The Hamiltonian, as well as Hamilton's equations have the same form as in the electromagnetic case presented in Ref. [35, Eq. (4.15)-(4.17)], except for the value of the constant s. The terms of  $\mathcal{O}(\epsilon^1)$  are expressed in terms of the Berry connection, and they depend on the state of circular polarization through s. In the limit of infinitely-high frequencies, which corresponds to  $\epsilon = 0$ , we recover the geodesic equations, as in Eqs. (3.4) and (3.5).

As observed in Ref. [35], the Hamiltonian (3.13), as well as the effective ray equations (3.14) and (3.15) are not independent of the choice of polarization vectors  $m_{\mu}$  and  $\bar{m}_{\mu}$ . This is because the Berry connection  $B_{\mu}$  is not invariant under spin rotations  $m_{\mu} \mapsto e^{i\phi(x)}m_{\mu}$ . Such transformations can be viewed as a change of gauge for the Berry connection. This is similar to the case of a charged particle moving in an electromagnetic field, and described by the minimally coupled Hamiltonian

$$H = \frac{1}{2}g^{\mu\nu}(p_{\mu} - eA_{\mu})(p_{\nu} - eA_{\nu}), \tag{3.16}$$

which is not invariant under gauge transformations of the electromagnetic vector potential,  $A_{\mu} \mapsto A_{\mu} + \nabla_{\mu} \xi$ . Generally, this issue can be solved by introducing noncanonical coordinates, such that the connection one-form (e.g. the electromagnetic vector potential  $A_{\mu}$  for the case of charged particles, or the Berry connection  $B_{\mu}$  for the case of spinning particles) is eliminated from the Hamiltonian, and the ray equations are expressed in terms of the curvature two-form (e.g. the Faraday tensor  $F_{\mu\nu} = 2\nabla_{[\mu}A_{\nu]}$  for the case of charged particles, or the Berry curvature for the case of spinning particles). This procedure is discussed in Ref. [43] for the case of a charged particle, and in Ref. [30] for Hamiltonians involving the Berry connection. Also, it is generally the case that the effective ray equations describing spin Hall effects in optics or condensed matter physics are usually expressed in terms of the Berry curvature [10, 8, 40, 5, 45, 48].

Noncanonical coordinates for a Hamiltonian of the form given in Eq. (3.13) were introduced in Ref. [35], based on the general proposal of Littlejohn and Flynn [30]. The relation between canonical coordinates  $(x^{\mu}, p_{\mu})$  and noncanonical coordinates  $(X^{\mu}, P_{\mu})$  is

$$X^{\mu} = x^{\mu} + i\epsilon s\bar{m}^{\alpha} \nabla^{\mu} m_{\alpha}, \tag{3.17}$$

$$P_{\mu} = p_{\mu} - i\epsilon s \bar{m}^{\alpha} \nabla_{\mu} m_{\alpha}. \tag{3.18}$$

The coordinate transformation is performed perturbatively with respect to  $\epsilon$ , and terms of  $\mathcal{O}(\epsilon^2)$  are ignored. We refer the reader to Ref. [35] for the details of the calculations. In noncanonical coordinates  $(X^{\mu}, P_{\mu})$ , the Hamiltonian is

$$H(X,P) = \frac{1}{2}g^{\mu\nu}(X)P_{\mu}P_{\nu}, \tag{3.19}$$

and the effective ray equations become

$$\dot{X}^{\mu} = P^{\mu} + \epsilon s P^{\nu} \left( F_{px} \right)_{\nu}^{\mu} + \epsilon s \Gamma^{\alpha}_{\beta\nu} P_{\alpha} P^{\beta} \left( F_{pp} \right)^{\nu\mu}, \tag{3.20}$$

$$\dot{P}_{\mu} = \Gamma^{\alpha}_{\beta\mu} P_{\alpha} P^{\beta} - \epsilon s P^{\nu} (F_{xx})_{\nu\mu} - \epsilon s \Gamma^{\alpha}_{\beta\nu} P_{\alpha} P^{\beta} (F_{xp})^{\nu}_{\mu}. \tag{3.21}$$

In the above equations, we have the components of the Berry curvature, defined as

$$(F_{pp})^{\nu\mu} = i \left( \overset{v}{\nabla}^{\mu} \bar{m}^{\alpha} \overset{v}{\nabla}^{\nu} m_{\alpha} - \overset{v}{\nabla}^{\nu} \bar{m}^{\alpha} \overset{v}{\nabla}^{\mu} m_{\alpha} + \bar{m}^{\alpha} \overset{v}{\nabla}^{[\mu} \overset{v}{\nabla}^{\nu]} m_{\alpha} - m_{\alpha} \overset{v}{\nabla}^{[\mu} \overset{v}{\nabla}^{\nu]} \bar{m}^{\alpha} \right),$$

$$(F_{xx})_{\nu\mu} = i \left( \nabla_{\mu} \bar{m}^{\alpha} \nabla_{\nu} m_{\alpha} - \nabla_{\nu} \bar{m}^{\alpha} \nabla_{\mu} m_{\alpha} + \bar{m}^{\alpha} \nabla_{[\mu} \nabla_{\nu]} m_{\alpha} - m_{\alpha} \nabla_{[\mu} \nabla_{\nu]} \bar{m}^{\alpha} \right),$$

$$(F_{px})_{\nu}^{\ \mu} = - (F_{xp})^{\mu}_{\ \nu} = i \left( \overset{v}{\nabla}^{\mu} \bar{m}^{\alpha} \nabla_{\nu} m_{\alpha} - \nabla_{\nu} \bar{m}^{\alpha} \overset{v}{\nabla}^{\mu} m_{\alpha} \right).$$

$$(3.22)$$

It can easily be verified that these equations are invariant under spin rotations  $m_{\mu} \mapsto e^{i\phi(x)}m_{\mu}$ . However, given a null covector  $P_{\mu}$  the orthogonal plane spanned by  $m_{\mu}$  and  $\bar{m}_{\mu}$  is not uniquely fixed, since one can always perform transformations of the form  $m_{\mu} \mapsto m_{\mu} + cP_{\mu}$ . This orthogonal plane can only be fixed uniquely by introducing additional structure, such as a timelike vector  $t^{\mu}$  or another null vector  $n^{\mu}$ , orthogonal to  $m_{\mu}$  and  $\bar{m}_{\mu}$ . From a physical point of view, this means that the orthogonal plane spanned by  $m_{\mu}$  and  $\bar{m}_{\mu}$  can only be fixed with respect to a timelike observer with 4-velocity  $t^{\mu}$ .

As discussed in Ref. [35], changing the vector field  $t^{\mu}$ , defining a family of observers, corresponds to a change of polarization vectors of the form  $m_{\mu} \mapsto m_{\mu} + cP_{\mu}$ . The effective ray equations (3.20) and (3.21) are not invariant under such transformations. This reflects the well-known fact that the position of a massless spinning particle cannot be defined independent of an observer. In particular, this can be viewed as a manifestation of the relativistic Hall effect [9] and the Wigner translation for massless spinning particles [44, 17] (see also Ref. [12] for a similar discussion in the context of the Mathisson-Papapetrou-Dixon equations). It has been shown in Ref. [35] how Eqs. (3.20) and (3.21) incorporate these effects.

#### 4. Conclusion

We have presented a covariant WKB analysis of gravitational waves, as described by the linearized Einstein equations. By going beyond the standard geometrical optics approach, we obtained effective ray equations containing polarization-dependent terms and describing the spin Hall effect of gravitational waves propagating on arbitrary spacetimes. The effective ray equations have the same form as in the electromagnetic case discussed in Ref. [35], the only difference being a factor of 2, representing the spin-2 nature of the gravitational field. Thus, considering electromagnetic and gravitational waves of the same frequency, the spin Hall effect is twice as large in the case of gravitational waves.

In an ongoing work [27] (see also [34]), the authors prove that the resulting equations can be cast in the form of the Mathisson-Papatreou-Dixon equations for massless particles, with the Corinaldesi-Papapetrou spin supplementary condition. The latter is a consequence of the derivation of the effective equations of motions. Furthermore, with [35], it provides a first systematic covariant derivation of the equations of motions for massless spinning particles.

The spin Hall effect of gravitational waves is expected to play an important role for gravitational waves of finite frequency. Hence, one important perspective is to understand the observable consequences of corrections to geometrical optics. Firstly, the corrections to geometrical optics should lead to measurable frequency-dependent corrections to gravitational lensing, as discussed in [31, 14]. To calculate the effect, an analytic discussion of the effective equations of motions must be performed. Secondly, the effect measured is spin-dependent. The effective equations of motions should lead to different trajectories for electromagnetic and gravitational wave packets. This could lead to different arrival times. These aspects will be investigated in future works.

#### ACKNOWLEDGMENTS

M.A.O. is grateful for support by the International Max Planck Research School for Mathematical and Physical Aspects of Gravitation, Cosmology and Quantum Field Theory.

Appendix A. Properties of the symbol 
$$D_{\alpha\beta}^{\phantom{\alpha\beta}\gamma\delta}$$

The kernel of the symbol  $D_{\alpha\beta}^{\ \gamma\delta}$ , considered as a endormorphism of the space of symmetric two-tensors, is calculated in this section. We first observe that, if  $b_{\delta}$  is any covector, then

$$D_{\alpha\beta}^{\gamma\delta}k_{(\gamma}b_{\delta)} = 0. \tag{A.1}$$

The tensor  $k_{(\gamma}b_{\delta)}$  is always in the kernel of  $D_{\alpha\beta}^{\ \gamma\delta}$ . More generally, if  $S_{\gamma\delta}$  is a symmetric complex 2-tensor in the kernel of  $D_{\alpha\beta}^{\ \gamma\delta}$ , then

$$2D_{\alpha\beta}^{\gamma\delta}S_{\gamma\delta} = k_{\alpha}k_{\beta}S + g_{\alpha\beta}S_{\gamma\delta}k^{\gamma}k^{\delta} - k^{\gamma}S_{\gamma\alpha}k_{\beta} - k^{\gamma}S_{\gamma\beta}k_{\alpha} \tag{A.2}$$

$$=0. (A.3)$$

We consider a Newman-Penrose tetrad  $\{k_{\alpha}, n_{\alpha}, m_{\alpha}, \bar{m}_{\alpha}\}$  satisfying the orthogonality relations given in Eq. (2.24). Considering symmetric tensor products of the Newman-Penrose tetrad elements, the only nontrivial contraction with the right-hand-side of Eq. (A.2) are those with  $m^{\alpha}\bar{m}^{\beta}$ ,  $\bar{m}^{\alpha}m^{\beta}$ ,  $n^{\alpha}m^{\beta}$ ,  $n^{\alpha}\bar{m}^{\beta}$ ,

$$k^{\gamma} m^{\beta} S_{\gamma\beta} = k^{\gamma} \bar{m}^{\beta} S_{\gamma\beta} = k^{\gamma} k^{\beta} S_{\gamma\beta} = 0, \tag{A.4}$$

and  $n^{\alpha}n^{\beta}$ .

$$S - 2n^{\alpha}k^{\beta}S_{\alpha\beta} = 0 = -2S_{\alpha\beta}m^{\alpha}\bar{m}^{\beta}.$$
 (A.5)

A similar argument can be made when  $k^{\mu}$  is not null. Hence, we obtain the following lemma:

**Lemma A.1.** When  $k^{\mu}$  is a null vector, the kernel of the symbol  $D_{\alpha\beta}^{\ \gamma\delta}$  is the vector space of complex symmetric two-tensors generated by

$$k_{\alpha}k_{\beta}, k_{(\alpha}n_{\beta)}, k_{(\alpha}m_{\beta)}, k_{(\alpha}\bar{m}_{\beta)},$$
 (A.6)

$$m_{(\alpha}m_{\beta)}, \bar{m}_{(\alpha}\bar{m}_{\beta)}.$$
 (A.7)

When  $k^{\mu}$  is not a null vector, the elements of the kernel of  $D_{\alpha\beta}^{\ \gamma\delta}$  are traceless symmetric two-tensors satisfying

$$k^{\alpha}S_{\alpha\beta} = 0. \tag{A.8}$$

Using Eq. (A.5), one checks easily that, if  $S_{\gamma\delta}$  is in the kernel of  $D_{\alpha\beta}^{\gamma\delta}$ , then its trace-reverse  $\check{S}_{\gamma\delta}$  satisfies

$$k^{\alpha}\check{S}_{\alpha\beta} = 0, \tag{A.9}$$

which is the form of the polarization tensor given in Eq. (2.25).

Finally, we observe that two-tensors generated by the elements of Eq. (A.6) are pure gauge. The Riemann curvature tensor of the particular perturbed metric tensor  $\tilde{g}_{\alpha\beta} = g_{\alpha\beta} + \text{Re}\left(k_{(\alpha}b_{\beta)}e^{iS/\epsilon}\right)$ , for an arbitrary  $k_{\alpha} = \nabla_{\alpha}S$  and  $b_{\alpha}$  complex covector, is given by,

$$\tilde{R}^{\mu}{}_{\nu\alpha\beta} = R^{\mu}{}_{\nu\alpha\beta} + \nabla_{\alpha}\Gamma(h)^{\mu}{}_{\nu\beta} - \nabla_{\beta}\Gamma(h)^{\mu}{}_{\nu\alpha} \tag{A.10}$$

$$\tilde{R}^{\mu}_{\ \nu\alpha\beta} = R^{\mu}_{\ \nu\alpha\beta} + \mathcal{O}(\epsilon^{-1}),\tag{A.11}$$

instead of the expected

$$\tilde{R}^{\mu}{}_{\nu\alpha\beta} = R^{\mu}{}_{\nu\alpha\beta} + \mathcal{O}(\epsilon^{-2}). \tag{A.12}$$

Hence, a perturbation of the form  $h_{\alpha\beta} = \text{Re}\left(k_{(\alpha}b_{\beta)}e^{iS/\epsilon}\right)$  is pure gauge at the lowest order in  $\epsilon$ .

**Lemma A.2.** The only non pure-gauge solutions of

$$D_{\alpha\beta}^{\ \gamma\delta}S_{\gamma\delta} = 0 \tag{A.13}$$

are generated by

$$m_{(\alpha}m_{\beta)}, \bar{m}_{(\alpha}\bar{m}_{\beta)}.$$
 (A.14)

# APPENDIX B. DERIVATION OF THE LAGRANGIAN FOR LINEARIZED GRAVITY

In this section, we consider the full metric  $\tilde{g}_{\alpha\beta}$ , written as a sum of a background metric  $g_{\alpha\beta}$ , and a small perturbation metric  $h_{\alpha\beta}$ :

$$\tilde{g}_{\alpha\beta} = g_{\alpha\beta} + h_{\alpha\beta}.\tag{B.1}$$

Recall that, with our conventions we have

$$\tilde{g}^{\alpha\beta} = g^{\alpha\beta} - h^{\alpha\beta} + \mathcal{O}(|h|^2). \tag{B.2}$$

The Einstein-Hilbert action is for the full metric  $\tilde{g}_{\alpha\beta}$  is

$$\int_{M} d^{4}x \sqrt{\tilde{g}} \, \widetilde{R}. \tag{B.3}$$

As always, the linearization of the determinant of the metric tensor leads to

$$\sqrt{\tilde{g}} = \sqrt{g} \left( 1 + \frac{1}{2} g^{\alpha \beta} h_{\alpha \beta} \right) + \mathcal{O}(|h|^2). \tag{B.4}$$

We introduce the notation

$$\tilde{\Gamma}^{\alpha}_{\beta\gamma} = \Gamma^{\alpha}_{\beta\gamma} + \Upsilon^{\alpha}_{\beta\gamma}, 
\Upsilon^{\alpha}_{\beta\gamma} = \frac{1}{2} g^{\alpha\sigma} \left( -\nabla_{\sigma} h_{\beta\gamma} + \nabla_{\beta} h_{\sigma\gamma} + \nabla_{\gamma} h_{\beta\sigma} \right) + \mathcal{O}(|h|^2),$$
(B.5)

where the Christoffel symbols  $\Gamma^{\alpha}_{\beta\gamma}$  and the covariant derivative  $\nabla_{\alpha}$  are defined with respect to the background metric  $g_{\alpha\beta}$ . As the difference between two the Christofell symbols of two metrics,  $\Upsilon^{\alpha}_{\beta\gamma}$  is a tensor. Now, we expand the Riemann curvature tensor of  $\tilde{g}_{\alpha\beta}$ ,

$$\tilde{R}^{\mu}_{\ \nu\alpha\beta} = R^{\mu}_{\nu\alpha\beta} + \tilde{\nabla}_{\alpha}\Upsilon^{\mu}_{\nu\beta} - \tilde{\nabla}_{\beta}\Upsilon^{\mu}_{\nu\alpha} + 2\left(\Upsilon^{\mu}_{\sigma\beta}\Upsilon^{\sigma}_{\nu\alpha} - \Upsilon^{\mu}_{\sigma\alpha}\Upsilon^{\sigma}_{\nu\beta}\right),\tag{B.6}$$

where  $\tilde{\nabla}_{\alpha}$  is the covariant derivative defined with respect to  $\tilde{g}_{\alpha\beta}$ . We contract in  $\mu$  and  $\alpha$  to get the Ricci curvature, and with inverse metric tensor  $\tilde{g}^{\nu\beta}$  to get the scalar curvature:

$$\tilde{R}_{\nu\beta} = \tilde{R}^{\mu}_{\nu\mu\beta} = R_{\nu\beta} + \tilde{\nabla}_{\mu}\Upsilon^{\mu}_{\nu\beta} - \tilde{\nabla}_{\beta}\Upsilon^{\mu}_{\nu\mu} + 2\left(\Upsilon^{\mu}_{\sigma\beta}\Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu}\Upsilon^{\sigma}_{\nu\beta}\right),\tag{B.7}$$

$$\widetilde{R} = \widetilde{g}^{\nu\beta}\widetilde{R}_{\nu\beta} = \widetilde{g}^{\nu\beta}R_{\nu\beta} + \widetilde{g}^{\nu\beta}\left(\widetilde{\nabla}_{\mu}\Upsilon^{\mu}_{\nu\beta} - \widetilde{\nabla}_{\beta}\Upsilon^{\mu}_{\nu\mu}\right) + 2\widetilde{g}^{\nu\beta}\left(\Upsilon^{\mu}_{\sigma\beta}\Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu}\Upsilon^{\sigma}_{\nu\beta}\right).$$
(B.8)

We consider now the Einstein-Hilbert action for the metric  $\tilde{g}_{\alpha\beta}$ :

$$\int_{M} d^{4}x \sqrt{\tilde{g}} \, \tilde{R} = \int_{M} d^{4}x \sqrt{\tilde{g}} \, \tilde{g}^{\nu\beta} \left[ R_{\nu\beta} + 2 \left( \Upsilon^{\mu}_{\sigma\beta} \Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu} \Upsilon^{\sigma}_{\nu\beta} \right) \right] 
+ \int_{M} d^{4}x \sqrt{\tilde{g}} \, \tilde{g}^{\nu\beta} \left( \tilde{\nabla}_{\mu} \Upsilon^{\mu}_{\nu\beta} - \tilde{\nabla}_{\beta} \Upsilon^{\mu}_{\nu\mu} \right).$$
(B.9)

In the above equation, the term on the second line is a boundary term, which we drop. In the first line, the second term can be rewritten as

$$\tilde{g}^{\nu\beta} \left( \Upsilon^{\mu}_{\sigma\beta} \Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu} \Upsilon^{\sigma}_{\nu\beta} \right) \sqrt{\tilde{g}} = g^{\nu\beta} \left( \Upsilon^{\mu}_{\sigma\beta} \Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu} \Upsilon^{\sigma}_{\nu\beta} \right) \sqrt{g} + \mathcal{O}(|h|^3). \tag{B.10}$$

Using the expansion of the determinant of the metric tensor, we obtain

$$\tilde{g}^{\nu\beta}\sqrt{\tilde{g}} = \sqrt{g}\left(g^{\nu\beta} - h^{\nu\beta} + \frac{1}{2}hg^{\nu\beta}\right) + \mathcal{O}(|h|^2). \tag{B.11}$$

The expansion of the Einstein-Hilbert action, neglecting terms of order 3 in  $h_{\alpha\beta}$ , takes the preliminary form

$$\int_{M} d^{4}x \sqrt{\tilde{g}} \, \tilde{R} = \int_{M} d^{4}x \sqrt{g} \, R - \int_{M} d^{4}x \sqrt{g} \, \left( R_{\nu\beta} - \frac{1}{2} R g_{\nu\beta} \right) h^{\nu\beta} 
+ \int_{M} d^{4}x \sqrt{g} \, R_{\mu\nu} \mathcal{V}^{\mu\nu} 
+ \int_{M} d^{4}x \sqrt{g} \, 2g^{\nu\beta} \left( \Upsilon^{\mu}_{\sigma\beta} \Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu} \Upsilon^{\sigma}_{\nu\beta} \right) + \mathcal{O}(|h|^{3}).$$
(B.12)

where  $\mathcal{V}^{\mu\nu} = \mathcal{O}(|h|^2)$ . Since we assume that the background metric  $g_{\alpha\beta}$  satisfies the Einstein field equations in vacuum with no cosmological constant, we have

$$\int_{M} d^{4}x \sqrt{\tilde{g}} \, \widetilde{R} = \int_{M} d^{4}x \sqrt{g} \, g^{\nu\beta} \left( \Upsilon^{\mu}_{\sigma\beta} \Upsilon^{\sigma}_{\nu\mu} - \Upsilon^{\mu}_{\sigma\mu} \Upsilon^{\sigma}_{\nu\beta} \right) + \mathcal{O}(|h|^{3}). \tag{B.13}$$

Using the definition of  $\Upsilon^{\alpha}_{\beta\gamma}$ , we can calculate

$$g^{\nu\beta}\Upsilon^{\mu}_{\sigma\beta}\Upsilon^{\sigma}_{\nu\mu} = \frac{1}{4} \left( 2\nabla^{\sigma}h^{\mu\nu}\nabla_{\mu}h_{\sigma\nu} - \nabla^{\sigma}h^{\mu\nu}\nabla_{\sigma}h_{\mu\nu} \right) + \mathcal{O}(|h|^3)$$
 (B.14)

$$g^{\nu\beta}\Upsilon^{\mu}_{\sigma\mu}\Upsilon^{\sigma}_{\nu\beta} = \frac{1}{4} \left( -\nabla_{\sigma}h\nabla^{\sigma}h + 2\nabla^{\sigma}h\nabla^{\mu}h_{\sigma\mu} \right) + \mathcal{O}(|h|^3). \tag{B.15}$$

The linearized Einstein-Hilbert action, neglecting terms of order 3 in  $h_{\alpha\beta}$ , is given by

$$\int_{M} d^{4}x \sqrt{\tilde{g}} \, \widetilde{R} = \int_{M} d^{4}x \sqrt{g} \, L + \mathcal{O}(|h|^{3}), \tag{B.16}$$

where L is the Lagrangian for linearized gravity, defined as

$$L = \nabla^{\sigma} h^{\mu\nu} \nabla_{\mu} h_{\sigma\nu} - \frac{1}{2} \nabla^{\sigma} h^{\mu\nu} \nabla_{\sigma} h_{\mu\nu} + \frac{1}{2} \nabla_{\sigma} h \nabla^{\sigma} h - \nabla^{\sigma} h \nabla^{\mu} h_{\sigma\mu}, \tag{B.17}$$

which agrees with the Lagrangian obtained in Ref. [6, p. 55]. Integrating by parts and neglecting boundary terms, we obtain

$$\int_{M} \widetilde{R} \sqrt{\widetilde{g}} dx = \int_{M} d^{4}x \sqrt{g} h^{\alpha\beta} \widehat{D}_{\alpha\beta}^{\gamma\delta} h_{\gamma\delta}, \tag{B.18}$$

where  $\hat{D}_{\alpha\beta}^{\ \ \gamma\delta}$  is defined as

$$\hat{D}_{\alpha\beta}^{\ \gamma\delta} = \frac{1}{2} \left( \delta_{\alpha}^{\gamma} \delta_{\beta}^{\delta} \nabla_{\mu} \nabla^{\mu} - g_{\alpha\beta} g^{\gamma\delta} \nabla_{\mu} \nabla^{\mu} + g^{\gamma\delta} \nabla_{\alpha} \nabla_{\beta} + g_{\alpha\beta} \nabla^{\gamma} \nabla^{\delta} - \delta_{\beta}^{\delta} \nabla^{\gamma} \nabla_{\alpha} - \delta_{\alpha}^{\delta} \nabla^{\gamma} \nabla_{\beta} \right). \tag{B.19}$$

## APPENDIX C. LORENZ GAUGE

C.1. Linearization of the wave gauge. We start by the standard calculation of the linearization of the wave gauge. Consider a chart  $(U, x^{\alpha})$ , and assume that this chart is harmonic for the metric  $\tilde{g}_{\alpha\beta}$ . That is

$$\tilde{g}^{\alpha\beta}\tilde{\nabla}_{\alpha}\tilde{\nabla}_{\beta}x^{\delta} = F^{\delta},\tag{C.1}$$

where the  $F^{\delta}$  are unknown functions to be chosen wisely. We expand this to get

$$F^{\delta} = \tilde{g}^{\alpha\beta} \tilde{\nabla}_{\alpha} \tilde{\nabla}_{\beta} x^{\delta}$$

$$= \tilde{g}^{\alpha\beta} \partial_{x^{\alpha}} \partial_{x^{\beta}} x^{\delta} + \tilde{g}^{\alpha\beta} \tilde{\Gamma}^{\mu}_{\alpha\beta} \partial_{x^{\mu}} x^{\delta}.$$

$$= \tilde{g}^{\alpha\beta} \tilde{\Gamma}^{\delta}_{\alpha\beta}$$
(C.2)

Using

$$\tilde{\Gamma}^{\alpha}_{\beta\gamma} = \Gamma^{\alpha}_{\beta\gamma} + \frac{1}{2}g^{\alpha\sigma} \left( -\nabla_{\sigma}h_{\beta\gamma} + \nabla_{\beta}h_{\sigma\gamma} + \nabla_{\gamma}h_{\beta\sigma} \right), \tag{C.3}$$

and neglecting the quadratic terms in  $h_{\alpha\beta}$ , we obtain

$$\underbrace{g^{\beta\gamma}\Gamma^{\alpha}_{\beta\gamma}}_{\text{order 0 in }h_{\alpha\beta}} - \underbrace{h^{\beta\gamma}\Gamma^{\alpha}_{\beta\gamma} + \frac{1}{2}\left(2\nabla_{\beta}h^{\beta\alpha} - \nabla^{\alpha}h\right)}_{\text{order 1 in }h_{\alpha\beta}} = F^{\delta} \tag{C.4}$$

$$\nabla_{\beta} \left( h^{\beta \alpha} - \frac{1}{2} h g^{\beta \alpha} \right) = F^{\delta} - \tilde{g}^{\beta \gamma} \Gamma^{\alpha}_{\beta \gamma}. \tag{C.5}$$

For a general background metric, we choose

$$F^{\delta} = \tilde{g}^{\beta\gamma} \Gamma^{\alpha}_{\beta\gamma} \tag{C.6}$$

in order to obtain the Lorenz gauge condition

$$\nabla_{\beta} \left( h^{\beta \alpha} - \frac{1}{2} h g^{\beta \alpha} \right) = 0. \tag{C.7}$$

When  $g_{\alpha\beta}$  is the Minkowski metric, and  $(U, x^{\alpha})$  the Cartesian chart on  $\mathbb{R}^4$ , then  $F^{\delta}$  can be chosen equal to 0.

C.2. **Propagation of the gauge.** In that section, we check that the gauge condition is conserved by the equation for linearized gravity. This is a linearization of the procedure described in Ref. [38, Chapter 14.2]. We introduce

$$\mathcal{G}_{\mu} = \nabla^{\alpha} h_{\alpha\mu} - \frac{1}{2} \nabla_{\mu} h. \tag{C.8}$$

Recall that  $\check{h}_{\alpha\beta}$  is the trace-reversed of  $h_{\alpha\beta}$ . Observe that Eq. (1.9) can be rewritten as

$$-\nabla_{\alpha}\nabla^{\alpha}\check{h}_{\mu\nu} - g_{\mu\nu}\nabla_{\alpha}\nabla_{\beta}\check{h}^{\alpha\beta} + \nabla^{\alpha}\nabla_{\mu}\check{h}_{\alpha\nu} + \nabla^{\alpha}\nabla_{\nu}\check{h}_{\alpha\mu} = 0.$$
 (C.9)

By commuting the covariant derivatives as

$$\nabla^{\alpha}\nabla_{\mu}\check{h}_{\alpha\nu} = \nabla_{\mu}\nabla^{\alpha}\check{h}_{\alpha\nu} + R_{\nu\alpha\sigma\mu}\check{h}^{\sigma\alpha}, \tag{C.10}$$

and using the fact that  $g_{\alpha\beta}$  is Ricci flat, we obtain

$$\nabla_{\alpha} \nabla^{\alpha} \check{h}_{\mu\nu} - 2R_{\nu\alpha\sigma\mu} \check{h}^{\sigma\alpha} = \nabla_{\mu} \mathcal{G}_{\nu} + \nabla_{\nu} \mathcal{G}_{\mu} - g_{\mu\nu} \nabla^{\alpha} \mathcal{G}_{\alpha}. \tag{C.11}$$

Taking the divergence of the right-hand side of the previous equations, we obtain

$$\nabla_{\alpha}\nabla^{\alpha}\mathcal{G}_{\mu} + R_{\mu\alpha}\mathcal{G}^{\alpha} = \nabla^{\mu}\left(\nabla_{\alpha}\nabla^{\alpha}\check{h}_{\mu\nu} - 2R_{\nu\alpha\sigma\mu}\check{h}^{\sigma\alpha}\right). \tag{C.12}$$

Hence, if we consider a solution of the reduced equation

$$\nabla_{\alpha} \nabla^{\alpha} \check{h}_{\mu\nu} - 2R_{\nu\alpha\sigma\mu} \check{h}^{\sigma\alpha} = 0 \tag{C.13}$$

and we assume that, initially,

$$\mathcal{G}_{\mu} = 0 \quad \text{and} \quad \nabla_{\nu} \mathcal{G}_{\mu} = 0,$$
 (C.14)

then  $h_{\alpha\beta}$  solves Eq. (1.9) in the Lorenz gauge. Furthermore, the trace of  $h_{\alpha\beta}$  satisfies the decoupled equation

$$\nabla^{\mu}\nabla_{\mu}h = 0. \tag{C.15}$$

#### References

- [1] V. I. Arnold. Mathematical methods of classical mechanics, volume 60 of Graduate Texts in Mathematics. Springer-Verlag, New York, [1989?]. Translated from the 1974 Russian original by K. Vogtmann and A. Weinstein, Corrected reprint of the second (1989) edition.
- [2] J. Audretsch. Trajectories and spin motion of massive spin- $\frac{1}{2}$  particles in gravitational fields. *Journal of Physics A: Mathematical and General*, 14:411–422, 1981.
- [3] S. Bates and A. Weinstein. Lectures on the Geometry of Quantization, volume 8 of Berkeley Mathematics Lecture Notes. American Mathematical Society, Providence, RI; Berkeley Center for Pure and Applied Mathematics, Berkeley, CA, 1997.
- [4] I. Bengtsson and K. Życzkowski. Geometry of Quantum States: An Introduction to Quantum Entanglement. Cambridge University Press, 2nd edition, 2017.
- [5] A. Bérard and H. Mohrbach. Spin Hall effect and Berry phase of spinning particles. *Physics Letters A*, 352(3):190–195, 2006.
- [6] J. Bičák. Selected topics in the problem of energy and radiation. In C. G. Kuper and A. Peres, editors, Relativity and Gravitation, page 47, Jan. 1971.
- [7] K. Y. Bliokh. Geometrodynamics of polarized light: Berry phase and spin Hall effect in a gradient-index medium. *Journal of Optics A: Pure and Applied Optics*, 11(9):094009, aug 2009.
- [8] K. Y. Bliokh, A. Niv, V. Kleiner, and E. Hasman. Geometrodynamics of spinning light. *Nature Photonics*, 2:748, Nov 2008.
- [9] K. Y. Bliokh and F. Nori. Relativistic Hall Effect. Phys. Rev. Lett., 108:120403, Mar 2012.
- [10] K. Y. Bliokh, F. J. Rodríguez-Fortuño, F. Nori, and A. V. Zayats. Spin-orbit interactions of light. Nature Photonics, 9(12):796–808, 2015.
- [11] M. Born and E. Wolf. Principles of Optics: Electromagnetic Theory of Propagation, Interference and Diffraction of Light (7th Edition). Cambridge University Press, 7th edition, 1999.
- [12] L. F. Costa, C. Herdeiro, J. Natário, and M. Zilhão. Mathisson's helical motions for a spinning particle: Are they unphysical? Phys. Rev. D, 85:024001, Jan 2012.
- [13] L. F. O. Costa and J. Natário. Center of mass, spin supplementary conditions, and the momentum of spinning particles. In Equations of Motion in Relativistic Gravity, pages 215–258. Springer, 2015.
- [14] G. Cusin and M. Lagos. Gravitational wave propagation beyond geometric optics. Phys. Rev. D, 101:044041, Feb 2020.
- [15] W. G. Dixon. A covariant multipole formalism for extended test bodies in general relativity. Il Nuovo Cimento (1955-1965), 34(2):317–339, 1964.

- [16] W. G. Dixon. The new mechanics of Myron Mathisson and its subsequent development. In Equations of Motion in Relativistic Gravity, pages 1–66. Springer, 2015.
- [17] C. Duval, M. Elbistan, P. Horv´athy, and P.-M. Zhang. Wigner–Souriau translations and Lorentz symmetry of chiral fermions. Physics Letters B, 742:322 – 326, 2015.
- [18] C. Emmrich and A. Weinstein. Geometry of the transport equation in multicomponent WKB approximations. Comm. Math. Phys., 176(3):701–711, 1996.
- [19] E. ´ E. Flanagan and S. A. Hughes. The basics of gravitational wav ´ e theory. New Journal of Physics, 7(1):204, Sept. 2005.
- [20] G. R. Fowles. Introduction to Modern Optics. Courier Corporation, 1989.
- [21] H. Friedrich and A. Rendall. The Cauchy problem for the Einstein equations. In Einstein's field equations and their physical implications, volume 540 of Lecture Notes in Phys., pages 127–223. Springer, Berlin, 2000.
- [22] V. P. Frolov. Maxwell equations in a curved spacetime: Spin optics approximation. Phys. Rev. D, 102:084013, Oct 2020.
- [23] V. P. Frolov and A. A. Shoom. Spinoptics in a stationary spacetime. Phys. Rev. D, 84:044026, Aug 2011.
- [24] U. H. Gerlach. Derivation of the ten einstein field equations from the semiclassical approximation to quantum geometrodynamics. Phys. Rev., 177:1929–1941, Jan 1969.
- [25] P. Gosselin, A. B´erard, and H. Mohrbach. Spin Hall effect of photons in a static gravitational field. Physical Review D, 75:084035, Apr 2007.
- [26] A. I. Harte. Gravitational lensing beyond geometric optics: I. Formalism and observables. General Relativity and Gravitation, 51(1):14, Jan 2019.
- [27] A. I. Harte and M. A. Oancea. Trajectories for spinning wavepackets. Ongoing work, 2021.
- [28] S. W. Hawking and G. F. R. Ellis. The large scale structure of space-time. Cambridge University Press, 1973.
- [29] O. Hosten and P. Kwiat. Observation of the spin Hall effect of light via weak measurements. Science, 319(5864):787–790, 2008.
- [30] R. G. Littlejohn and W. G. Flynn. Geometric phases in the asymptotic theory of coupled wave equations. Physical Review A, 44:5239–5256, Oct 1991.
- [31] J. Mar´ıa Ezquiaga, D. E. Holz, W. Hu, M. Lagos, and R. M. Wald. Phase effects from strong gravitational lensing of gravitational waves. arXiv e-prints, page arXiv:2008.12814, Aug. 2020.
- [32] M. Mathisson. Republication of: New mechanics of material systems. General Relativity and Gravitation, 42(4):1011–1048, 2010.
- [33] C. W. Misner, K. S. Thorne, and J. A. Wheeler. Gravitation. W. H. Freeman San Francisco, 1973.
- [34] M. A. Oancea. Spin Hall effects in General Relativity. PhD thesis, University of Potsdam, 2021.
- [35] M. A. Oancea, J. Joudioux, I. Y. Dodin, D. E. Ruiz, C. F. Paganini, and L. Andersson. Gravitational spin hall effect of light. Phys. Rev. D, 102:024075, Jul 2020.
- [36] M. A. Oancea, C. F. Paganini, J. Joudioux, and L. Andersson. An overview of the gravitational spin Hall effect. arXiv preprint arXiv:1904.09963, 2019.
- [37] A. Papapetrou. Spinning test-particles in general relativity. I. Proceedings of the Royal Society of London. Series A, Mathematical and Physical Sciences, 209(1097):248–258, 1951.
- [38] H. Ringstr¨om. The Cauchy problem in general relativity. ESI Lectures in Mathematics and Physics. European Mathematical Society (EMS), Z¨urich, 2009.
- [39] R. R¨udiger. The Dirac equation and spinning particles in general relativity. Proceedings of the Royal Society of London, Series A, Mathematical and Physical Sciences, 377:417–424, 1981.
- [40] D. E. Ruiz and I. Y. Dodin. First-principles variational formulation of polarization effects in geometrical optics. Physical Review A, 92:043805, Oct 2015.
- [41] D. E. Ruiz and I. Y. Dodin. Extending geometrical optics: A Lagrangian theory for vector waves. Physics of Plasmas, 24(5):055704, 2017.
- [42] A. A. Shoom. Gravitational Faraday and Spin-Hall Effects of Light. arXiv preprint arXiv:2006.10077, 2020.
- [43] S. Sternberg. Minimal coupling and the symplectic mechanics of a classical particle in the presence of a Yang-Mills field. Proceedings of the National Academy of Sciences, 74(12):5253–5254, 1977.
- [44] M. Stone, V. Dwivedi, and T. Zhou. Wigner Translations and the Observer Dependence of the Position of Massless Spinning Particles. Phys. Rev. Lett., 114:210402, May 2015.

- [45] G. Sundaram and Q. Niu. Wave-packet dynamics in slowly perturbed crystals: Gradient corrections and Berry-phase effects. Physical Review B, 59:14915–14925, Jun 1999.
- [46] E. R. Tracy, A. J. Brizard, A. S. Richardson, and A. N. Kaufman. Ray Tracing and Beyond: Phase Space Methods in Plasma Wave Theory. Cambridge University Press, 2014.
- [47] W. Tulczyjew. Motion of multipole particles in general relativity theory. Acta Physica Polonica, 18:393, 1959.
- [48] D. Xiao, J. Shi, and Q. Niu. Berry Phase Correction to Electron Density of States in Solids. Physical Review Letters, 95:137204, Sep 2005.
- [49] N. Yamamoto. Spin Hall effect of gravitational waves. Physical Review D, 98:061701, Sep 2018.
- [50] C.-M. Yoo. Notes on spinoptics in a stationary spacetime. Physical Review D, 86:084005, Oct 2012.

Email address: lars.andersson@aei.mpg.de

Max Planck Institute for Gravitational Physics (Albert Einstein Institute), Am Muhlenberg ¨ 1, D-14476 Potsdam, Germany

Email address: jeremie.joudioux@aei.mpg.de

Max Planck Institute for Gravitational Physics (Albert Einstein Institute), Am Muhlenberg ¨ 1, D-14476 Potsdam, Germany

Email address: marius.oancea@aei.mpg.de

Max Planck Institute for Gravitational Physics (Albert Einstein Institute), Am Muhlenberg ¨ 1, D-14476 Potsdam, Germany

Email address: ayush.raj@iitb.ac.in

Department of Physics, Indian Institute of Technology, Powai, Mumbai-400076, India