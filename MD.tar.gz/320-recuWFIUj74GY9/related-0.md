# Maxwell equations in a curved spacetime: Spin optics approximation

Valeri P. Frolov $^{1,*}$ 

<sup>1</sup> Theoretical Physics Institute, University of Alberta, Edmonton, Alberta, Canada T6G 2E1

We study propagation of high-frequency electromagnetic waves in a curved spacetime. We demonstrate how a modification of the standard geometric optics allows one to include the helicity dependent corrections into the equations of motion of circularly polarized beams of radiation. As a result, polarized light rays are still null but not geodesic curves. To achieve these results we construct null frames associated with a set of (non-geodesic) null rays and use these frames for description of the high-frequency wave propagation. We call this approach spin optics approximation. It is completely covariant and it can be used in an arbitrary time-dependent gravitational field.

#### I. INTRODUCTION

Short wave (or high-frequency) approach is a powerful method of construction of approximate solutions of linear differential equations with spatially varying coefficients. In application to the linear partial differential equations it allows one to find their asymptotic solutions by reducing this problem to studying of hamiltonian dynamical systems. This method is widely used in different areas of physics and has different (historically motivated) names. In quantum mechanics this method is known as a quasiclassical or WKB approximation, by initials for Wentzel-Kramers-Brillouin. In wave optics this method is known as a geometric optics approximation. It takes its origin with the paper by Debay in 1911 [1] and was developed in many subsequent publications (see e.g. [2] and references therein).

The main idea of this approach is to search for a solution  $\Phi$  of the wave equation in the form  $\Phi \approx f \exp iS$ , where the phase function S rapidly changes, while the field amplitude f is a slowly varying function. This means that  $\nabla S \sim \omega$ , where  $\omega$  is a characteristic large frequency. Substituting this ansatz into the field equations and keeping the terms of the lowest order in  $1/\omega$  one obtains a first order partial differential equation of the form  $H(\nabla S, x) = 0$  known as an eikonal equation. This equation can be identified with the Hamilton-Jacobi equation. Putting  $P = \nabla S$  one reduces the problem to study of the corresponding dynamical system with Hamiltonian H(P,x). In the application to the standard optics, the equation S = const determines a wavefront and the vectors P orthogonal to the wave front are tangent to the light rays. In the phase space a beam of such null rays forms a Lagrangian submanifold (for details see e.g. a remarkable book [3]).

Geometric optics approximation for obtaining high-frequency asymptotic solutions of Maxwell equations in a curved spacetime has been discussed in a number of publications starting with the papers [4–7]. A remarkable summary of the geometric optics in a curved spacetime can be found in the book [8] (see also more recent papers

[9–11] and references therein). In a curved spacetime in the leading order of the geometric optics approximation, light rays are null geodesics and the wave polarization vector is parallel-propagated along the rays. For a beam of light the square of its amplitude is inverse proportional to the area of the cross-section of the beam. Parallel transport of the polarization vector of the electromagnetic wave results in the gravitational Faraday rotation effect [12–16]. Similar Faraday rotation effect exists also for polarized high-frequency gravitational waves propagating in a curved spacetime [17]. This effect is an analogue of the well-known electromagnetic Faraday effect for light propagating in magneto-active media [18–20].

Gravitational Faraday effect is one of manifestations of action of gravimagnetic forces on a particle with spin or spin-curvature interaction. Its dual is an effect of the helicity dependence of the motion of circularly polarized light beams in the gravitational field of a spinning objects [21–23]. This is an analogue of a so called optical Magnus effect [24, 25], that is polarization-dependence of light propagation in an inhomogeneous optical media. This effect sometime is also called *Hall effect of light* [26]. Comprehensive discussion of this subject and numerous references can be found in recent reviews [27, 28].

There are many publications in which different approaches to the gravitational spin Hall effect were proposed. They can be divided into three main groups. (i) Adaptation of the Mathisson-Papapertou-Dixon equations for the motion of massive particles with spin to the massless case (see e.g. [29–32]); (ii) Using the methods of quantum mechanics, such as Foldy-Wouthuysen transformation and Berry phases [33]; (iii) Spin optics or modified geometric optics [34–37]. In the latter approach the standard geometric optics eikonal function is modified by including into it a specially chosen helicity dependent correction. This correction contains extra factor  $\omega^{-1}$  and hence is suppressed at very high-frequencies. However, at finite frequency and for travel of polarized rays at large distances they can modify the ray propagation and become important. Comprehensive discussion and comparison of different approaches to the gravitational spin Hall effect can be found in a recent review [38].

Let us emphasize that development of the high-frequency approximation for propagation of the field with

<span id="page-0-0"></span><sup>\*</sup> vfrolov@ualberta.ca

spin in a curved background has a well known problem. For a many component field there is an ambiguity: one can make a phase rotation of the multi-component prefactor amplitude and compensate this by the change of the phase function S [39–41]. A similar problem arises in the application of the WKB approximation to an equation for a particle with spin moving in an inhomogeneous magnetic field. Since the spin is proportional to  $\hbar$ , in the WKB limit  $\hbar \to 0$  the spin contribution to the motion formally vanishes [42]. However, in such a version of the Stern-Gerlach experiment an observer registers a deflection of particles with different orientation of the spin by fixing points where the particles struck a detector screen. A key role in the adaptation of the WKB approximation to such a case is understanding that besides the length scale  $\ell$  connected with the inhomogeneity of the magnetic field there is another length parameter, a distance to the screen L, which can be much larger than  $\ell$ . To catch hold of this effect one should first diagonalize the corresponding Pauli equation, and then "enhance" the spin dependent terms by including them into the eikonal [43].

A similar basic idea was used in the spin optics approach [34, 35]. For Maxwell theory it is possible to split the wave solutions into right and left-handed circularly polarized modes. The electromagnetic field with right and left hand polarization can be identified with self and anti-self dual solutions of the Maxwell equations, respectively. In spin optics one uses the WKB ansatz for each of these solutions and does not require that the eikonal functions are the same for both types of waves. Instead of this, one includes into the eikonal the first order high-frequency correction which is sensitive to the helicity. This method, called spin optics approximation, was developed in [34, 35] for polarized light propagation in a stationary spacetime. During some period of time it remained unclear how to spread this approach to a case when the gravitational field is not stationary. Recently this problem was solved. This remarkable breakthrough was achieved in paper [44]. In the present paper we present a slightly different approach to this problem.

We assume that a high-frequency self or anti-self dual solution of the Maxwell equations is associated with the congruence of null rays which, in a general case, is not geodesic. In section II we introduce the notion of Ftransport which allows one to determine a null frame associated with a given set of null rays. In section III we write Maxwell equations by using their high-frequency decomposition and obtain a set of truncated equations by keeping zero and first order terms in this system. We also use the null frames constructed in section II to derive constraints on the field that follow from the property of its self or anti-self-duality. In section IV we reproduce the results of the standard geometric optics approximation for the obtained truncated system of equations. The spin optics approach to the problem of the high-frequency polarized light propagation in a curved spacetime is developed in section V. In this section we derive the corresponding equations of motion for polarized light rays. These equations determine the acceleration of the worldlines of null rays and hence specify the choice of the null ray congruence. The ray equations together with equations for null frame propagation along null rays give a complete self-consistent set of equations. In section VI we discuss an effective action for polarized light rays and compare Lagrangian and Hamiltonian formulations for this problem. Final section VI contains brief summary of the obtained results and their discussion. In this paper we use the signs convention adopted in the book [8]. In particular, the metric has the signature (-, +, +, +). In description of vectors and tensors we use both their coordinate and coordinate-free forms. In the latter case we denote these objects by boldface letters. For example, a scalar product of two vectors  $\boldsymbol{a}$  and  $\boldsymbol{b}$  is  $(\boldsymbol{a}, \boldsymbol{b}) = g_{\mu\nu}a^{\mu}b^{\nu}$ . We also denote  $a^2 = (a, a)$ .

# <span id="page-1-1"></span>II. NULL TETRADS AND POLARIZATION TENSORS

#### <span id="page-1-2"></span>A. Null tetrads

Let us consider a congruence of null curves which later will be identified with trajectories of a massless particle with the spin. Let  $\boldsymbol{l}$  be tangent vectors to these null curves, and we denote

$$w^{\mu} = l^{\nu} l^{\mu}_{:\nu} \,. \tag{1}$$

Since  $l^2 = 0$  one has

$$(\boldsymbol{l}, \boldsymbol{w}) = l_{\mu} w^{\mu} = 0. \tag{2}$$

Let us consider integral lines  $x^{\mu}(\lambda)$  of  $\boldsymbol{l}$ 

$$\frac{dx^{\mu}(\lambda)}{d\lambda} = l^{\mu} \,. \tag{3}$$

We complement the vector field  $\boldsymbol{l}$  by three other null fields  $\boldsymbol{n},\ \boldsymbol{m}$  and  $\bar{\boldsymbol{m}}$  and require that the following normalization conditions are satisfied

<span id="page-1-0"></span>
$$(\boldsymbol{l}, \boldsymbol{n}) = -1, \quad (\boldsymbol{m}, \bar{\boldsymbol{m}}) = 1, \tag{4}$$

while all other scalar products of these vectors vanish. We also assume that this frame has a right-handed orientation. In what follows we shall widely use this (complex) null tetrad  $\{l, m, \bar{m}, n\}$ .

For a fixed congruence of null rays there exist a following freedom in the choice of the vectors of the null tetrad:

1. 
$$\boldsymbol{l} \to A \boldsymbol{l}, \; , \quad \boldsymbol{n} \to A^{-1} \boldsymbol{n} \; ;$$

2. 
$$l \rightarrow l$$
,  $m \rightarrow m + al$ ,  $\bar{m} \rightarrow \bar{m} + \bar{a}l$ ,  $n \rightarrow n + \bar{a}m + a\bar{m} + a\bar{a}l$ ;

3. 
$$m \to e^{i\varphi} m$$
,  $\bar{m} \to e^{-i\varphi} \bar{m}$ .

Here a is a complex function, and A and  $\varphi$  are two real functions. The first of these transformations reflects a freedom of the choice of the parametrization along null rays. Under this transformation, the vector  $\boldsymbol{w}$  changes as follows

<span id="page-2-2"></span>
$$\boldsymbol{w} \to A^2 \boldsymbol{w} + A \nabla_l A \boldsymbol{l}$$
. (5)

The vector  $\boldsymbol{w}$  is invariant under the transformations 2 and 3.

We demonstrate now how one can reduce the freedom of the transformations 1–3 and construct a special null frame associated with a given congruence of null rays. Consider a null ray  $x^{\mu}(\lambda)$  and choose a vector  $\boldsymbol{n}$  on this curve such that at  $\lambda = \lambda_0$  it obeys the relations

<span id="page-2-0"></span>
$$n^2|_{\lambda_0} = 0, \quad (n, l)|_{\lambda_0} = -1.$$
 (6)

We define its transport along the ray by the following equation

$$\nabla_{l} \boldsymbol{n} = (\boldsymbol{w}, \boldsymbol{n}) \boldsymbol{n} \,. \tag{7}$$

Then one has

$$\frac{d}{d\lambda}n^2 = 2(w, n)n^2, \qquad (8)$$

$$\frac{d}{d\lambda}[(\boldsymbol{n},\boldsymbol{l})+1] = (\boldsymbol{w},\boldsymbol{n})[(\boldsymbol{n},\boldsymbol{l})+1]. \tag{9}$$

Both of these equations are of the form  $dz/d\lambda = (\boldsymbol{w}, \boldsymbol{n})z$ . A solution of such an equation which vanishes at  $\lambda_0$  is identically zero along the ray. This means that if one imposes conditions (6) at the initial value  $\lambda = \lambda_0$ , then this vector  $\boldsymbol{n}$  has the property  $\boldsymbol{n}^2 = 0$  and  $(\boldsymbol{n}, \boldsymbol{l}) = -1$  valid everywhere on the ray.

We use this vector to define a following tensor

$$\mathcal{V}^{\mu}_{\ \nu} = w^{\mu} n_{\nu} - n^{\mu} w_{\nu} \,. \tag{10}$$

We introduce operator  $\mathcal{D}$  acting on a tensor field  $A^{\mu}_{\nu}$ ... along the ray by the following relation

$$\mathcal{D}A^{\mu\dots}_{\nu\dots} = \nabla_{l}A^{\mu\dots}_{\nu\dots} + \mathcal{V}^{\mu}_{\lambda}A^{\lambda\dots}_{\nu\dots} + \dots - \mathcal{V}^{\lambda}_{\nu}A^{\mu\dots}_{\lambda\dots} + \dots$$
(11)

Here  $\nabla_{\boldsymbol{l}}$  is a covariant derivative along the vector field  $\boldsymbol{l}$ . The operator  $\mathcal{D}$  when applied to a product of two tensors satisfies the Leibniz rule. It is easy to check that  $\mathcal{D}\boldsymbol{g}=0$  and the scalar product of any two vectors  $\boldsymbol{a}$  and  $\boldsymbol{b}$  is constant along the ray provided  $\mathcal{D}\boldsymbol{a}=\mathcal{D}\boldsymbol{b}=0$ . The operator  $\mathcal{D}$  may be considered as a modification of the Fermi derivative adapted to the case of null curves. We say that a tensor is F-propagated along ray if its  $\mathcal{D}$ -derivative vanishes. In particular, for a F-propagated vector  $\boldsymbol{z}$  one has

$$\nabla_{l} z = (w, z) n - (n, z) w. \tag{12}$$

By construction the vector  $\boldsymbol{l}$  is F-propagated along the ray.

We choose complex null vectors  $\mathbf{m}$  and  $\bar{\mathbf{m}}$  to be Ftransported along the ray and such that at the initial
point of the ray  $\lambda_0$  they obey the relations

$$(\boldsymbol{m}, \boldsymbol{l})|_{\lambda_0} = (\bar{\boldsymbol{m}}, \boldsymbol{l})|_{\lambda_0} = (\boldsymbol{m}, \boldsymbol{n})|_{\lambda_0} = (\bar{\boldsymbol{m}}, \boldsymbol{n})|_{\lambda_0} = 0,$$
  
 $(\boldsymbol{m}, \boldsymbol{m})|_{\lambda_0} = (\bar{\boldsymbol{m}}, \bar{\boldsymbol{m}})|_{\lambda_0} = 0,$   $(\boldsymbol{m}, \bar{\boldsymbol{m}})|_{\lambda_0} = 1.$  (13)

Since F-transport preserves the scalar product a so defined null frame  $(l, m, \bar{m}, n)$  obeys the normalization conditions (4) along the ray and satisfies the equations

<span id="page-2-1"></span>
$$\nabla_{l} \boldsymbol{n} = (\boldsymbol{w}, \boldsymbol{n}) \boldsymbol{n},$$

$$\nabla_{l} \boldsymbol{m} = (\boldsymbol{w}, \boldsymbol{m}) \boldsymbol{n},$$

$$\nabla_{l} \bar{\boldsymbol{m}} = (\boldsymbol{w}, \bar{\boldsymbol{m}}) \boldsymbol{n}.$$
(14)

Let us emphasize that after imposing F-transport requirement on the null frame, the freedom 2 and 3 in its choice is reduced by the conditions  $\nabla_l a = \nabla_l \varphi = 0$ .

Equations (14) can be further simplified. Namely, one can always choose the function A in (5) so that  $(\boldsymbol{w}, \boldsymbol{n}) = 0$ . The only ambiguity which is left in the transformation 1 is A =const along the rays. This condition fixes the choice of the parameter  $\lambda$  along the ray up to its possible rescaling  $\lambda \to A^{-1}\lambda$ , where A is constant. In what follows we always use this parametrization and call it *canonical*. In the canonical parametrization the vector  $\boldsymbol{n}$  is parallel transported along the null rays,  $\nabla_{l}\boldsymbol{n} = 0$ , and the vector  $\boldsymbol{w}$  is of the form

<span id="page-2-5"></span>
$$\mathbf{w} = -\bar{\kappa}\mathbf{m} - \kappa\bar{\mathbf{m}}, \quad \kappa = -m^{\mu}l^{\nu}l_{\mu;\nu}.$$
 (15)

Let us summarize: In the canonical parametrization the F-transported null tetrad vectors obey the equations

<span id="page-2-3"></span>
$$\nabla_{l} \boldsymbol{n} = 0, \ \nabla_{l} \boldsymbol{m} = -\kappa \boldsymbol{n}, \ \nabla_{l} \bar{\boldsymbol{m}} = -\bar{\kappa} \boldsymbol{n},$$
 (16)

and the remaining freedom of the tetrad transformation 1-3 is reduced to such transformations performed on the null tetrad vectors at some initial moment of time. We call a so defined F-propagated tetrad a null frame associated with the congruence of null rays.

#### B. Polarization tensors

We denote by e a unit volume 4-form

$$e = i \; l \wedge m \wedge \bar{m} \wedge n \,. \tag{17}$$

Its coordinate form is  $e_{\mu\nu\lambda\rho}=i4!\ l_{[\mu}m_{\nu}\bar{m}_{\lambda}n_{\rho]}$ . If  $\omega$  is a rank p-form then using this tensor one can define a Hodge dual (4-p)-form  $\star\omega$ . In particular, if a two-form  $\omega$  has coordinates  $\omega_{\mu\nu}$ , then  $(\star\omega)_{\mu\nu}=\frac{1}{2}e_{\mu\nu\lambda\rho}\omega^{\lambda\rho}$ .

We introduce the following three two-forms  $\pi^{(a)}$ , a = 0, 1, 2 by relations

<span id="page-2-4"></span>
$$\boldsymbol{\pi}^{(0)} = \bar{\boldsymbol{m}} \wedge \boldsymbol{n} \,, \; \boldsymbol{\pi}^{(1)} = -(\boldsymbol{l} \wedge \boldsymbol{n} - \boldsymbol{m} \wedge \bar{\boldsymbol{m}}) \,, \; \boldsymbol{\pi}^{(2)} = \boldsymbol{l} \wedge \boldsymbol{m} \,.$$
 (18)

In the coordinate form the components of these twoforms are

$$\pi^{(0)}_{\mu\nu} = 2\bar{m}_{[\mu}n_{\nu]}, \quad \pi^{(2)}_{\mu\nu} = 2l_{[\mu}m_{\nu]}, 
\pi^{(1)}_{\mu\nu} = 2\left(-l_{[\mu}n_{\nu]} + m_{[\mu}\bar{m}_{\nu]}\right). \tag{19}$$

We denote by  $\bar{\pi}^{(a)}$  two-forms obtained from  $\pi^{(a)}$  by their complex conjugation. These forms  $\pi^{(a)}$  and  $\bar{\pi}^{(a)}$  obey the property

$$\star \boldsymbol{\pi}^{(a)} = i \boldsymbol{\pi}^{(a)}, \quad \star \bar{\boldsymbol{\pi}}^{(a)} = -i \bar{\boldsymbol{\pi}}^{(a)}.$$
 (20)

In other words, the forms  $\pi^{(a)}$  are self-dual, while  $\bar{\pi}^{(a)}$  are anti self-dual. We call these objects polarization tensors.

Let z be a vector, then we denote by  $\pi^{(a)} \cdot z$  a vector with components  $\pi^{(a)\mu}_{\phantom{a}\nu}z^{\nu}$ . Then the action of the polarization tensors on the null-tetrad vectors can be written in the form

$$\pi^{(0)} \cdot \begin{pmatrix} l \\ m \\ \bar{m} \\ n \end{pmatrix} = \begin{pmatrix} -\bar{m} \\ -n \\ 0 \\ 0 \end{pmatrix},$$

$$\pi^{(1)} \cdot \begin{pmatrix} l \\ m \\ \bar{m} \\ n \end{pmatrix} = \begin{pmatrix} l \\ m \\ -\bar{m} \\ -n \end{pmatrix}, \qquad (21)$$

$$\pi^{(2)} \cdot \begin{pmatrix} l \\ m \\ \bar{m} \\ n \end{pmatrix} = \begin{pmatrix} 0 \\ 0 \\ l \\ m \end{pmatrix}.$$

We define a contraction  $\boldsymbol{a} \circ \boldsymbol{b}$  of 2 two-forms  $\boldsymbol{a}$  and  $\boldsymbol{b}$  as follows

$$\boldsymbol{a} \circ \boldsymbol{b} = \boldsymbol{b} \circ \boldsymbol{a} = \frac{1}{2} a_{\mu\nu} b^{\mu\nu} \,.$$
 (22)

It is easy to check that

<span id="page-3-0"></span>
$$\bar{\boldsymbol{\pi}}^{(a)} \circ \boldsymbol{\pi}^{(b)} = 0, \tag{23}$$

$$\boldsymbol{\pi}^{(a)} \circ \boldsymbol{\pi}^{(b)} = \bar{\boldsymbol{\pi}}^{(a)} \circ \bar{\boldsymbol{\pi}}^{(b)} = \delta_0^a \delta_2^b + \delta_2^a \delta_0^b - 2\delta_1^a \delta_1^b . (24)$$

It is convenient to combine  $\pi^{(a)}$  and  $\bar{\pi}^{(a)}$  into a unique set of two-forms  $\pi^{s(a)}$  by specifying its components as follows

$$\boldsymbol{\pi}^{+1(a)} = \boldsymbol{\pi}^{(a)}, \quad \boldsymbol{\pi}^{-1(a)} = \bar{\boldsymbol{\pi}}^{(a)}.$$
 (25)

We call  $s=\pm 1$  a helicity parameter. The forms  $\boldsymbol{\pi}^{s(a)}$  form a basis in a six-dimensional linear space of two-forms.

# III. SELF-DUAL AND ANTI-SELF-DUAL SOLUTIONS OF MAXWELL EQUATIONS

### A. Field equations

In the absence of currents the Maxwell equations for the electromagnetic field F have the following standard

form

$$d\mathbf{F} = \delta\mathbf{F} = 0, \qquad (26)$$

where a co-derivative  $\delta$  is defined as  $\delta = \star d\star$ . We denote

$$\mathcal{F}^{s} = \frac{1}{2} [\mathbf{F} - is(\star \mathbf{F})], \qquad (27)$$

where  $s = \pm 1$ . In the four dimensional spacetime with the Lorentz signature the Hodge duality operator has the property  $\star \star \mathbf{F} = -\mathbf{F}$ , so that  $\star \mathbf{F}^s = is \mathbf{F}^s$ . Hence, the field  $\mathbf{F}^{+1}$  is self-dual, while  $\mathbf{F}^{-1}$  is anti-self-dual.

We consider  $\mathcal{F}^s$  as two independent complex fields and identify the parameter s with the helicity of the field. These fields obey the equations

$$d\mathcal{F} = \delta \mathcal{F} = 0. \tag{28}$$

Using relations (23) one can show that the field  $\mathcal{F}^s$  obeys the relations

$$\mathcal{F}^s \circ \boldsymbol{\pi}^{-s(a)} = 0, \tag{29}$$

and it can be presented in the form

$$\mathcal{F}^{s} = \sum_{a=1}^{3} \Phi_{a}^{s} \pi^{s(a)} \,. \tag{30}$$

Using relations (24) one gets

$$\boldsymbol{\pi}^{s(b)} \circ \boldsymbol{\mathcal{F}}^s = \Phi_0^s \delta_2^b + \Phi_2^s \delta_0^b - 2\Phi_1^s \delta_1^b. \tag{31}$$

Hence

$$\Phi_0^s = \boldsymbol{\pi}^{s(2)} \circ \boldsymbol{\mathcal{F}}^s, \quad \Phi_2^s = \boldsymbol{\pi}^{s(0)} \circ \boldsymbol{\mathcal{F}}^s, \quad (32)$$

$$\Phi_1^s = -\frac{1}{2}\boldsymbol{\pi}^{s(1)} \circ \boldsymbol{\mathcal{F}}^s \,. \tag{33}$$

If  $\mathcal{F}$  is a self-dual field then its complex components

$$\Phi_{0} = \mathcal{F}_{\mu\nu} l^{\mu} m^{\nu}, \quad \Phi_{2} = \mathcal{F}_{\mu\nu} \bar{m}^{\mu} n^{\nu}, 
\Phi_{1} = \frac{1}{2} \mathcal{F}_{\mu\nu} (l^{\mu} n^{\nu} + \bar{m}^{\mu} m^{\nu}).$$
(34)

coincide with the standard complex tetrad components of the electromagnetic field introduced by Teukolsky in his paper [45].

We denote by  $\mathcal{A}^s$  a complex vector potential such that

$$\mathcal{F}^s = d\mathcal{A}^s \,. \tag{35}$$

and use the gauge freedom to impose the Lorentz condition

$$\delta \mathcal{A}^s = 0. \tag{36}$$

## <span id="page-4-6"></span>B. High-frequency expansion

We write a complex potential  $\mathcal{A}$  in the form

<span id="page-4-1"></span>
$$\mathbf{A} = \mathbf{a} \exp(iS), \tag{37}$$

To simplify the expressions we skip the helicity index s both in the amplitude a and in the phase function S. We restore this parameter in the final results. We assume that real function S is a "fast changing" phase and write its gradient as follows

$$S_{:\mu} = \omega p_{\mu} \,. \tag{38}$$

Since our goal is to construct asymptotic solutions of the Maxwell equations in the high-frequency approximation we assume that the frequency  $\omega$  is large. In what follows we shall use  $1/\omega$  expansion. In fact, if l is a characteristic scale involved in the problem (such as the curvature of the wave front, the size and duration of the radiation beam and the radius of the spacetime curvature) then the small dimensionless parameter of expansion is  $(\omega l)^{-1}$ .

The amplitude a is a "slowly changing" complex vector. The following gauge transformation

<span id="page-4-2"></span>
$$\tilde{a}_{\mu} = a_{\mu} + \Psi_{,\mu}, \quad \Psi = \frac{1}{\omega} \psi \exp(iS), \quad (39)$$

preserves the form of (37) and one has

<span id="page-4-8"></span>
$$\tilde{a}_{\mu} = a_{\mu} + i p_{\mu} \psi + \frac{1}{\omega} \psi_{,\mu} \,.$$
 (40)

Lorentz gauge condition  $\mathcal{A}_{\mu}^{\;;\mu} = 0$  implies

<span id="page-4-4"></span>
$$p^{\mu}a_{\mu} - \frac{i}{\omega}a_{\mu}^{;\mu} = 0. \tag{41}$$

The gauge transformation (39) preserves this condition provided the following relation is valid

$$-p^{2}\psi + \frac{i}{\omega}[2p_{\mu}^{;\mu}\psi + p^{\mu}\psi_{,\mu}] + \frac{1}{\omega^{2}}\psi_{;\mu}^{;\mu} = 0$$
 (42)

The field strength  $\mathcal{F}$  is

<span id="page-4-3"></span>
$$\mathcal{F}_{\mu\nu} = i\omega \mathcal{Z}_{\mu\nu} e^{iS}, \quad \mathcal{Z}_{\mu\nu} = \mathcal{B}_{\mu\nu} - \frac{i}{\omega} \mathcal{C}_{\mu\nu}, \quad (43)$$

$$\mathcal{B}_{\mu\nu} = p_{\mu}a_{\nu} - p_{\nu}a_{\mu}, \quad \mathcal{C}_{\mu\nu} = a_{\nu:\mu} - a_{\mu:\nu}.$$
 (44)

One can show that

$$\mathcal{F}_{\mu\nu}^{\ ;\nu} = -\omega^2 j_\mu e^{iS} \,, \tag{45}$$

$$j_{\mu} = \mathcal{B}_{\mu\nu} p^{\nu} - \frac{i}{\omega} [\mathcal{B}_{\mu\nu}^{;\nu} + \mathcal{C}_{\mu\nu} p^{\nu}] - \frac{1}{\omega^2} \mathcal{C}_{\mu\nu}^{;\nu}.$$
 (46)

The potential (37) satisfies Maxwell equations if  $j_{\mu} = 0$ .

Finally, let us discuss conditions imposed on the field by the requirement that it is self or anti-self dual. For a self-dual field these conditions are

<span id="page-4-7"></span>
$$\mathcal{Z}_{\mu\nu}m^{\mu}n^{\nu} = 0$$
, for  $a = 0$ , (47)

$$\mathcal{Z}_{\mu\nu}(-l^{\mu}n^{\nu} + \bar{m}^{\mu}m^{\nu}) = 0$$
, for  $a = 1$ , (48)

$$\mathcal{Z}_{\mu\nu}l^{\mu}\bar{m}^{\nu} = 0$$
, for  $a = 2$ . (49)

For anti-self-dual field similar conditions can be obtained from these relations if one changes  $m \leftrightarrow \bar{m}$  keeping  $\mathcal{Z}$  unchanged. In other words, if one found a self-dual solution of the form (43), then by taking a complex conjugation of  $\mathcal{Z}$  in this solution one gets an anti-self-dual solution. Relations (43)–(44) imply that this operation is equivalent to change  $a \leftrightarrow \bar{a}$  and  $\omega \to -\omega$  in relations (43)–(44). In particular, this means that when one uses the high-frequency expansion of the field equations, only the terms of the odd power in  $\omega$  are sensitive to the state of polarization of the field.

#### C. Truncated equations

In what follows we use expansions of different objects in powers of  $1/\omega$ . We use the following notation

$$X \stackrel{n}{=} \tilde{X} \tag{50}$$

to indicate that the quantities X and  $\tilde{X}$  differ only by terms of the order  $O(\omega^{-(n+1)})$ . Suppose that some relation X=0 depends on  $\omega$  and X has a high-frequency expansion

$$X = \sum_{k=0}^{\infty} \frac{X_k}{\omega^k}.$$
 (51)

If we keep the first (n+1)-terms in this expansion

$$X^{(n)} = \sum_{k=0}^{n} \frac{X_k}{\omega^k}, \qquad (52)$$

then  $X^{(n)} \stackrel{n}{=} 0$ . We call this relation a *n*-th order truncated form of the equation X = 0.

Using expressions (44) for  $\mathcal{B}_{\mu\nu}$  and  $\mathcal{C}_{\mu\nu}$ , the Lorentz condition (41) and keeping the terms up to the order  $1/\omega$  one obtains

$$j_{\mu} \stackrel{1}{=} -p^2 a_{\mu} + \frac{i}{\omega} \left( 2a_{\mu;\nu} p^{\nu} + p^{\nu}_{;\nu} a_{\mu} \right) .$$
 (53)

Hence, the truncated field equations take the form

<span id="page-4-5"></span>
$$p^2 a_{\mu} - \frac{2i}{\omega} \left( a_{\mu;\nu} p^{\nu} + \frac{1}{2} p^{\nu}_{;\nu} a_{\mu} \right) \stackrel{1}{=} 0.$$
 (54)

We denote  $f^2 = (\boldsymbol{a}, \bar{\boldsymbol{a}})$  and write the complex amplitude  $\boldsymbol{a}$  in the form

$$a_{\mu} = f z_{\mu}, \quad (\boldsymbol{z}, \bar{\boldsymbol{z}}) = 1. \tag{55}$$

<span id="page-4-0"></span>Detailed discussion of the high-frequency (shot wave length) approximation can be found in [8].

Then the equation (54) takes the form

<span id="page-5-1"></span>
$$p^2 z_{\mu} - \frac{2i}{\omega} [z_{\mu;\nu} p^{\nu} + ((\boldsymbol{q}, \boldsymbol{p}) + \frac{1}{2} p^{\nu}_{;\nu}) z_{\mu}] \stackrel{1}{=} 0.$$
 (56)

We call this relation a first order truncated field equation. It is sufficient for our purpose. However, it is easy to find extra terms of the higher in  $1/\omega$  powers and to obtain a higher order truncated field equations.

The Lorentz gauge condition (41) written in  $\{f, z\}$  variables is

<span id="page-5-3"></span>
$$(\boldsymbol{p}, \boldsymbol{z}) - \frac{i}{\omega} \left[ (\boldsymbol{q}, \boldsymbol{z}) + z^{\mu}_{;\mu} \right] = 0.$$
 (57)

Let us denote

$$J = \frac{1}{2} (\bar{a}_{\mu} j^{\mu} + a_{\mu} \bar{j}^{\mu}). \tag{58}$$

Then one has

<span id="page-5-0"></span>
$$J \stackrel{1}{=} -f^2 [p^2 - \frac{2}{\omega} b_{\mu} p^{\mu}], \qquad (59)$$

$$b_{\mu} = \frac{i}{2} \left( \bar{z}^{\nu} z_{\nu;\mu} - z^{\nu} \bar{z}_{\nu;\mu} \right) . \tag{60}$$

Let us remind that all the above results were obtained for right-handed circularly polarized high-frequency waves. One can easily repeat the calculations for the case of left-handed circularly polarized waves. However, this is not necessary. Instead of this one can use the prescription described at the end of subsection III B. In particular, this means that relation (59) can be used to get a similar relation for the left circular polarization. It is sufficient to take its complex conjugation and change  $\omega \to -\omega$ . Since  $\bar{b}_{\mu} = b_{\mu}$ , the only change is the sign of the second term in the right-hand side of (59). Hence the field equations  $j_{\mu} = 0$  in the both cases,  $s = \pm 1$ , imply

<span id="page-5-2"></span>
$$p^2 - \frac{2s}{\omega} b_{\mu} p^{\mu} \stackrel{1}{=} 0. \tag{61}$$

We call this relation a dispersion equation.

In order to develop both geometric and spin optics approximations we use the first order truncated field and dispersion equations, (56) and (61), and Lorentz condition (57). We also add to them first order truncated polarization equations (47)-(49). In this paper we restrict ourself by studying high-frequency solutions of the Maxwell equations in the first order approximation. However, in both geometric and spin optics approaches one can easily derive equations in the higher order approximation. Let us also remark that in order to obtain the first order truncated polarization equations (47)-(49) it is sufficient to substitute in them instead of the tensor  $\mathcal C$  its zero order approximation.

#### IV. GEOMETRIC OPTICS

A starting point of both, geometric optics and spin optics approximations is the same. Namely, one uses the

first order truncated field equations (56), (61) and the Lorentz gauge condition (57). The difference between these approaches is in the procedure used for solving these equations. We describe the spin optics approach in the next section. In this section we briefly remind the main steps of the standard geometric optics approximation<sup>2</sup>.

#### A. Effective Hamiltonian

We start with the first order truncated equation (61). Equating to zero the lowest order in  $\omega$  term in this equation one gets

<span id="page-5-7"></span>
$$\boldsymbol{p}^2 = 0. \tag{62}$$

This equation shows that  $\boldsymbol{p}$  is a null vector. It also implies that

$$0 = (p_{\nu}p^{\nu})_{\mu} = 2p^{\nu}p_{\nu;\mu} = 2p^{\nu}p_{\mu;\nu}. \tag{63}$$

Here we used the property  $p_{\mu;\nu} = p_{\nu;\mu}$ . Let  $x^{\mu}(\lambda)$  be an integral line of  $p^{\mu}$ :

<span id="page-5-5"></span>
$$\dot{x}^{\mu} \equiv \frac{dx^{\mu}}{d\lambda} = p^{\mu} \,. \tag{64}$$

then

$$\frac{D^2 x^{\mu}}{D\lambda^2} = 0. \tag{65}$$

In other words,  $x^{\mu}$  is a null geodesic and  $\lambda$  is an affine parameter. We identify  $\dot{x}$  with a tangent vector  $\boldsymbol{l}$  of the congruence of null rays. Since the acceleration parameter vanishes,  $\kappa=0$ , the null frame  $(\boldsymbol{l},\boldsymbol{m},\bar{\boldsymbol{m}},\boldsymbol{n})$  associated with these rays is parallel transported along the rays. This frame is uniquely defined provided it is fixed at some initial moment of time.

The above results admit a slightly different but very useful interpretation. The relation  $P_{\mu} = S_{,\mu}$  defines momenta which are canonically conjugated to  $x^{\mu}$ . Let us consider an eight dimensional phase space with canonical coordinates  $(x^{\mu}, P_{\mu})$  and let

$$\mathbf{\Omega} = dP_{\mu} \wedge dx^{\mu} \tag{66}$$

be a canonical symplectic form in it. As usual, a summation over the repeated indices is assumed. Let us write relation (64) in the form

<span id="page-5-6"></span>
$$\frac{dx^{\mu}}{d\lambda} = \frac{1}{\omega} g^{\mu\nu} P_{\nu} \,. \tag{67}$$

<span id="page-5-4"></span><sup>&</sup>lt;sup>2</sup> Additional details of the standard geometric optics approach to the Maxwell field propagating in a curved spacetime can be found [8]

One can introduce a Hamiltonian

$$H = \frac{1}{2\omega} g^{\mu\nu} P_{\mu} P_{\nu} , \qquad (68)$$

then [\(67\)](#page-5-6) is identical with the first set of Hamiltonian equations

$$\frac{dx^{\mu}}{d\lambda} = \frac{\partial H}{\partial P_{\mu}}.$$
 (69)

Using this equation together with the second set of Hamiltonian equations

$$\frac{dP_{\mu}}{d\lambda} = -\frac{\partial H}{\partial x^{\mu}} \tag{70}$$

one obtains[3](#page-6-0)

<span id="page-6-5"></span>
$$\frac{D^2 x^{\mu}}{D\lambda^2} = 0. (71)$$

As expected, this equation correctly reproduces [\(126\)](#page-9-0). The Lagrangian L of this system is

$$L = P_{\mu}\dot{x}^{\mu} - H = \frac{\omega}{2}\dot{x}^2. \tag{72}$$

Both, the Hamiltonian and the Lagrangian do not depend on the polarization state and trajectories of massless particles with spin (photons) in the geometric optics approximation do not depend on their helicity.

#### B. Polarization vector and amplitude

Substituting equation [\(62\)](#page-5-7) into [\(56\)](#page-5-1) one gets

<span id="page-6-1"></span>
$$z_{\mu;\nu}p^{\nu} - [(\boldsymbol{q}, \boldsymbol{p}) + \frac{1}{2}p^{\nu}_{;\nu}]z_{\mu} \stackrel{0}{=} 0.$$
 (73)

Multiplying this equation by ¯z <sup>µ</sup> one gets

$$(q, p) + \frac{1}{2} p^{\nu}_{;\nu} \stackrel{0}{=} \bar{z}^{\mu} z_{\mu;\nu} p^{\nu}.$$
 (74)

The quantity in the right hand side is purely imaginary. Really

$$\Re(\bar{z}^{\mu}z_{\mu;\nu}) = \frac{1}{2}(\bar{z}^{\mu}z_{\mu;\nu} + z^{\mu}\bar{z}_{\mu;\nu}) = \frac{1}{2}(\boldsymbol{z},\bar{\boldsymbol{z}})_{;\nu} = 0. \quad (75)$$

Thus one has

<span id="page-6-2"></span>
$$(q, p) + \frac{1}{2} p^{\nu}_{;\nu} = 0,$$
 (76)

while equation [\(73\)](#page-6-1) gives

$$z_{\mu;\nu}p^{\nu} = 0. (77)$$

The Lorentz condition [\(57\)](#page-5-3) implies

<span id="page-6-3"></span>
$$(\boldsymbol{p}, \boldsymbol{z}) \stackrel{0}{=} 0. \tag{78}$$

We use the following expansions

$$f \stackrel{1}{=} f_0 + \frac{1}{\omega} f_1, \quad z^{\mu} \stackrel{1}{=} z_0^{\mu} + \frac{1}{\omega} z_1^{\mu}.$$
 (79)

Since p = l relations [\(76\)](#page-6-2) –[\(78\)](#page-6-3) imply

<span id="page-6-4"></span>
$$l^{\mu}z_{0\mu} = 0, \qquad (80)$$

$$l^{\nu}z_{0;\nu}^{\mu} = 0, \qquad (81)$$

$$l^{\mu} f_{0;\mu} = -\frac{1}{2} l^{\mu}_{;\mu} f_0.$$
 (82)

This means that the normalized amplitude vector z<sup>0</sup> is parallel transported along the null rays and it is orthogonal to them. Equation [\(82\)](#page-6-4) is a standard transport equation relating the change of the field amplitude with expansion of the null ray congruence. In what follows we shall use a slightly different form of this equation. We denote q0<sup>µ</sup> = ∇<sup>µ</sup> ln(f0). Then [\(82\)](#page-6-4) gives

<span id="page-6-7"></span>
$$(q_0, l) + \frac{1}{2} l^{\mu}_{;\mu} = 0.$$
 (83)

In the leading order polarization equation [\(49\)](#page-4-7) is identically satisfied, while the other two equations, [\(47\)](#page-4-7) and [\(48\)](#page-4-7), give

$$(z_0, m) = (z_0, l) = 0.$$
 (84)

Hence z<sup>0</sup> = c1l + c2m. Since (z0, z¯0) = 1 one has c<sup>2</sup> = e iφ .

Under gauge transformation [\(40\)](#page-4-8) with ψ <sup>0</sup>= ψ<sup>0</sup> the zeroorder term of the complex amplitude changes as follows

$$\tilde{a}_{0\mu} \stackrel{0}{=} a_{0\mu} + i\psi_0 l_{\mu} \,.$$
 (85)

Since p <sup>2</sup> = 0 the gauge transformation [\(39\)](#page-4-2) with arbitrary ψ<sup>0</sup> preserves the Lorentz condition. It can be used to put c<sup>1</sup> = 0. The parameter φ can be absorbed in a redefinition of the phase function. Hence, one can put z<sup>0</sup> = m.

Collecting all the above results one can write

<span id="page-6-6"></span>
$$\mathcal{A}^{+1} = f_0 \boldsymbol{m} e^{iS} \,. \tag{86}$$

Let us emphasize that both the equation for null rays, [\(71\)](#page-6-5) and the transport equations [\(80\)](#page-6-4)-[\(82\)](#page-6-4) do not depend on the frequency ω. This means that in order to obtain an anti-self-dual solution one can simply change m by m¯ in [\(86\)](#page-6-6)

$$\mathcal{A}^{-1} = f_0 \bar{\boldsymbol{m}} e^{iS} \,. \tag{87}$$

Let us emphasize that the phase functions S in both expressions for A±<sup>1</sup> are the same. The fields with s = +1 and s = −1 describe right and left-handed circularly polarized waves, respectively [\[8](#page-12-5)].

<span id="page-6-0"></span><sup>3</sup> For details see discussion in section [VI B.](#page-9-1)

#### V. SPIN-OPTICS

#### A. Effective Hamiltonian

In the spin-optics approximation we use the same ansatz for the complex potential (37) as earlier. However, do not require that the phase functions are the same for both polarizations. We only assume that their difference is small. It is also convenient to present the scalar amplitude f in the form  $f = \exp(q)$ . Our starting point for construction of the spin optics approximation is again a truncated equation (61). But we proceed differently than in the geometric optics case. First we add  $b^2/\omega^2$  term to its left-hand side. It is clear that this operation does not affect the truncated first order equation. Next we define an effective Hamiltonian H by the relation

$$H = \frac{1}{2\omega} (\mathbf{P} - s\mathbf{b})^2. \tag{88}$$

In section VIB we discuss the Hamiltonian equations for this Hamiltonian and show that they are equivalent to the following equations

<span id="page-7-0"></span>
$$\dot{x}^{\mu} = \frac{1}{\omega} (P^{\mu} - sb^{\mu}), \qquad (89)$$

$$\frac{D^2 x^{\mu}}{D\lambda^2} = \frac{s}{\omega} k^{\mu}_{\ \nu} \dot{x}^{\nu} \,, \tag{90}$$

$$k_{\mu\nu} = b_{\nu;\mu} - b_{\mu;\nu} \,. \tag{91}$$

This system of equations is invariant under the transformation

$$b \to -b$$
,  $s \to -s$ ,  $\omega \to -\omega$ ,  $\lambda \to -\lambda$ . (92)

Since  $\mathbf{k}$  is antisymmetric, one has  $d(\dot{\mathbf{x}})^2/d\lambda=0$ . This means that if  $\dot{\mathbf{x}}$  is null at some moment of time it remains null along the whole ray. The value of H restricted to such rays is zero. Equation (90) shows that if  $\mathbf{k} \neq 0$  these null rays are not geodesics. For the congruence of these null rays we write  $l^{\mu}=\dot{x}^{\mu}$  and introduce the associated null frame as it was described in section II. The vectors of this frame are F-transported along the null rays and obey equations (16).

#### B. Polarization vector and amplitude

We consider first the case of a right-handed circular polarization waves. We use relation  $p=l+\frac{1}{\omega}b$  and write q and z in the form

<span id="page-7-5"></span>
$$q \stackrel{1}{=} q_0 + \frac{1}{\alpha} q_1, \quad z \stackrel{1}{=} m + \frac{1}{\alpha} z_1.$$
 (93)

It is easy to see that for this choice all zero order truncated equations (61), (56), (57) and polarization equations (47)-(49) are satisfied. Really, the dispersion relation implies that  $p^2 \stackrel{0}{=} 0$ , so that the leading zero order term in (56) identically vanishes. The same is true for

the Lorentz condition (57) since  $(p, z) \stackrel{0}{=} 0$ . As for zero order truncated polarization equations (47)-(49) it is sufficient to omit the terms containing  $\mathcal{C}$  in them and to use for  $\mathcal{B}$  the following expression

$$\mathcal{B}_{\mu\nu} \stackrel{0}{=} l_{\mu} m_{\nu} - l_{\nu} m_{\mu} \,. \tag{94}$$

This means that in the zero order approximation  $\mathcal{B}$  coincides with the polarization tensor  $\pi^{(2)}$  determined by equation (18), and hence  $\mathcal{B} \circ \bar{\pi}^{(a)} \stackrel{0}{=} 0$ .

We consider now the first order truncated equations. Let us substitute the truncated dispersion equation (61) into (56). The leading term proportional to  $\omega^0$  vanishes, while the first order term gives

<span id="page-7-2"></span>
$$m_{\mu;\nu}l^{\nu} + [(\boldsymbol{q}_0, \boldsymbol{l}) + \frac{1}{2}l^{\mu}_{;\mu} + i(\boldsymbol{l}, \boldsymbol{b}_0)]m_{\mu} \stackrel{0}{=} 0,$$
 (95)

where

$$b_{0\mu} = \frac{i}{2} (\bar{m}^{\nu} m_{\nu;\mu} - m^{\nu} \bar{m}_{\nu;\mu}). \tag{96}$$

Multiplying this equation by  $\bar{m}^{\mu}$  and using the property  $\Re(\bar{m}^{\mu}m_{\mu;\nu}) = 0$  one gets a relation

<span id="page-7-1"></span>
$$(\boldsymbol{q}_0, \boldsymbol{l}) + \frac{1}{2} l^{\mu}_{\;;\mu} = 0,$$
 (97)

which is the same as (83). This is a transport equation which determines the evolution of the scalar amplitude  $f_0$  along the rays. After substituting (97) into (95) one obtains the following relation

$$l^{\nu}m_{\mu;\nu} + i(\boldsymbol{l}, \boldsymbol{b}_0)m_{\mu} \stackrel{0}{=} 0.$$
 (98)

This relation is valid because  $l^{\nu}m_{\mu;\nu} \stackrel{0}{=} 0$ . The last equation directly follows from (15). The above relations show that the first order truncated field equations are satisfied if the dispersion relation is valid, provided the scalar amplitude of the field obeys the transport equation (97).

It is easy to check that in the first order the Lorentz condition (57) is satisfied. Collecting the terms proportional to  $\omega^{-1}$  in this relation one gets

<span id="page-7-3"></span>
$$(z_1, l) + (b_0, m) - i[(q_0, m) + m^{\mu}_{;\mu}] \stackrel{0}{=} 0.$$
 (99)

One can simplify this relation using the property

$$(\boldsymbol{b}_0, \boldsymbol{m}) - i m^{\mu}_{;\mu} \stackrel{0}{=} i l^{\mu} n^{\nu} m_{\mu;\nu}.$$
 (100)

Hence (99) takes the form

<span id="page-7-6"></span>
$$(z_1, l) = i [(q_0, m) - l^{\mu} n^{\nu} m_{\mu;\nu}].$$
 (101)

Let us consider now the truncated polarization equations (47)–(49). As we already mentioned, these equations are identically valid in the zero order approximation. Collecting the first order terms one obtains the following relations

<span id="page-7-4"></span>
$$\mathbf{Q} \circ \bar{\boldsymbol{\pi}}^{(a)} = 0, \qquad (102)$$

where

$$Q_{\mu\nu} = (b_{\mu}m_{\nu} - b_{\nu}m_{\mu}) + (l_{\mu}z_{1\nu} - l_{\nu}z_{1\mu}) - i(m_{\nu;\mu} - m_{\mu;\nu}) - i(q_{\mu}m_{\nu} - q_{\nu}m_{\mu}).$$
(103)

Rather long but straightforward calculations show that for a=1 and a=2 the relations (102) are identically satisfied, while for a=0 one obtains

<span id="page-8-0"></span>
$$(\boldsymbol{z}_1, \boldsymbol{m}) \stackrel{0}{=} i m^{\mu} n^{\nu} m_{\nu;\mu} \,. \tag{104}$$

Let us summarize. The first order truncated equations are satisfied if the scalar amplitude of the wave obeys the same transport equation (97) as in the geometric optics case, while the normalized polarization vector z has the form (93) with a correction term  $z_1$  satisfying equations (101) and (104). These results can be adapted to the left-hand circular polarization case, s = -1. In this case one should put

$$\boldsymbol{z}^{-1} = \bar{\boldsymbol{m}} - \frac{1}{\omega} \bar{\boldsymbol{z}}_1 \,. \tag{105}$$

#### C. Equations of motion

The equation of motion for circularly polarized rays (90) can be further simplified. Let us notice that the right-hand side of this equations contains the factor  $\omega^{-1}$ . Hence keeping the same order one can put there z=m, so that

$$b_{\mu} = i\bar{m}^{\alpha} m_{\alpha \cdot \mu} \,, \tag{106}$$

and one gets

$$k_{\mu\nu} = b_{\nu;\mu} - b_{\mu;\nu} = i\bar{m}^{\alpha}(m_{\alpha;\nu\mu} - m_{\alpha;\mu\nu}) + i(\bar{m}^{\alpha}_{;\mu}m_{\alpha;\nu} - \bar{m}^{\alpha}_{;\nu}m_{\alpha;\mu}).$$
(107)

The term in the first brackets in the right hand side contains the commutator of the covariant derivatives and it is proportional to the curvature

$$m_{\alpha:\nu\mu} - m_{\alpha:\mu\nu} = -R_{\mu\nu\beta\alpha}m^{\beta}. \tag{108}$$

Thus we have

<span id="page-8-1"></span>
$$k_{\mu\nu} = -iR_{\mu\nu\alpha\beta}m^{\alpha}\bar{m}^{\beta} + i(\bar{m}^{\alpha}_{;\mu}m_{\alpha;\nu} - \bar{m}^{\alpha}_{;\nu}m_{\alpha;\mu}). (109)$$

The right-hand side of (90) contains the factor  $k_{\mu\nu}l^{\nu}$ . For the null frame F-transported along the null rays one has  $l^{\nu}m_{\mu;\nu}\stackrel{0}{=}0$ , so that the term in the brackets in (109) can be neglected. Finally, the polarized ray equation (90) takes the following form

<span id="page-8-2"></span>
$$\frac{D^2 x^{\mu}}{D\lambda^2} = -\frac{is}{\omega} \frac{dx^{\nu}}{d\lambda} R^{\mu}_{\ \nu\alpha\beta} m^{\alpha} \bar{m}^{\beta} \,. \tag{110}$$

The left-handed side of this equation is nothing but the null ray acceleration  $w^{\mu}$ . Using relation (15) one can find the acceleration parameter  $\kappa$ 

$$\kappa = -(\boldsymbol{w}, \boldsymbol{m}) = -\frac{is}{\omega} R_{\mu\nu\alpha\beta} l^{\mu} m^{\nu} m^{\alpha} \bar{m}^{\beta} . \tag{111}$$

Let us remind that in the derivation of the ray equation (110) we used the special (F-transported) frame associated with the congruence of null rays, so that the following set of equations should also be satisfied, (16),

<span id="page-8-3"></span>
$$\nabla_{l} \boldsymbol{n} = 0, \quad \nabla_{l} \boldsymbol{m} = -\kappa \boldsymbol{n}, \quad \nabla_{l} \bar{\boldsymbol{m}} = -\bar{\kappa} \boldsymbol{n}, \quad (112)$$

This set of equations guarantees that the proper normalization conditions for the null tetrad vectors are satisfied, provided they are valid at the initial moment. By solving the system of equations (110)-(112) one obtains trajectories of the polarized rays. Let us notice that since the rotation  $m \to \exp(i\varphi)m$  preserves a two form  $m \wedge \bar{m}$ , this transformation also preserves the form of the equation (110). However, this equation is not invariant under the transformation  $m \to m + al$  (see section II A).

In conclusion of this section, let us make a following remark. Let us denote by  $\ell$  the characteristic length of the curvature radius  $\mathbf{R} \sim 1/\ell^2$ . Then one can use this parameter  $\ell$  to introduce dimensionless coordinates  $\tilde{x}^{\mu}$ , affine parameter  $\tilde{\lambda}$  and the curvature  $\tilde{\mathbf{R}}$  as follows

$$\tilde{x}^{\mu} = x^{\mu}/\ell, \quad \tilde{\lambda} = \lambda/\ell, \quad \tilde{R} = \ell^2 R.$$
 (113)

Then the equation (110) written in these dimensionless variables takes the form

$$\frac{D^2 \tilde{x}^{\mu}}{D\tilde{\lambda}^2} = -is\varepsilon \frac{d\tilde{x}^{\nu}}{d\tilde{\lambda}} \tilde{R}^{\mu}_{\ \nu\alpha\beta} m^{\alpha} \bar{m}^{\beta} \,. \tag{114}$$

Here  $\varepsilon = (\omega \ell)^{-1}$ . This is a dimensionless ratio of the wavelength and the characteristic scale of the problem  $\ell$ . Thus the deflection of the rays from null geodesics is small, as it is expected.

#### VI. EFFECTIVE ACTION

#### A. Action and Euler-Lagrange equations

Let  $\boldsymbol{l}$  be a null ray congruence and  $\boldsymbol{m}$  and  $\bar{\boldsymbol{m}}$  be two complex null vectors which are properly normalized and F-transported along the rays. Let us consider the following action

<span id="page-8-4"></span>
$$S = \frac{1}{2}\omega \int \eta \, \dot{\boldsymbol{x}}^2 d\lambda + s \int (\boldsymbol{b}, \dot{\boldsymbol{x}}) d\lambda \,. \tag{115}$$

This is a relativistic version of the action discussed in the paper [46]. The 1-form  $\boldsymbol{b}$  which enters the action (115) is

$$b_{\mu} = \frac{i}{2} (\bar{m}^{\nu} m_{\nu;\mu} - m^{\nu} \bar{m}_{\nu;\mu}). \tag{116}$$

The normalization condition  $(m, \bar{m}) = 1$  allows one to write this quantity in the following equivalent form

$$b_{\mu} = i\bar{m}^{\nu} m_{\nu;\mu} \,. \tag{117}$$

This action is a functional of the world line  $x^{\mu}(\lambda)$  and a Lagrange multiplier  $\eta(\lambda)$ . As earlier we use the notations

$$\dot{x}^{\alpha} = \frac{dx^{\alpha}}{d\lambda}, \quad \dot{x}^{2} = g_{\mu\nu}\dot{x}^{\mu}\dot{x}^{\nu}, \quad (\boldsymbol{b}, \dot{\boldsymbol{x}}) = b_{\mu}\dot{x}^{\mu}. \tag{118}$$

The action (115) is invariant under reparameterization  $\lambda \to \lambda'$  provided  $\eta$  transforms as follows  $\eta' = \frac{d\lambda'}{d\lambda} \eta$ .

A variation of this action with respect to the Lagrange multiplier  $\eta$  gives

<span id="page-9-2"></span>
$$\dot{\boldsymbol{x}}^2 = 0. \tag{119}$$

This condition guarantees that the world lines  $x^{\mu}(\lambda)$  which enter as the argument of the action obey a restriction (119) and hence are null curves.

To obtain equations which arise as a result of variation of the world line  $x^{\mu}(\lambda)$  it is convenient to use the method of covariant variations which is described in the book [47]. Let us perform a local variation of the worldline  $x^{\alpha} \to x^{\alpha} + \delta x^{\alpha}$ . If  $\phi(x)$  is a scalar field then

$$\delta\phi(x) = \phi_{,\alpha}\delta x^{\alpha} \,. \tag{120}$$

One also has  $\dot{\phi} = \phi_{,\alpha} \dot{x}^{\alpha}$ .

Let v be a tensor field and  $v(x(\lambda))$  is its restriction on the ray  $x^{\alpha}(\lambda)$ . Following DeWitt [47] and using his notations we define a covariant variation of tensor v as follows

$$\bar{\delta} \boldsymbol{v} = \boldsymbol{v}_{:\alpha} \delta x^{\alpha} \,. \tag{121}$$

In particular, the covariant variation of the metric tensor vanishes,  $\bar{\delta} g = 0$ . Covariant variations obey the Leibniz rule when applied to factors in a product. Using the relation

$$\bar{\delta}(\dot{\boldsymbol{x}}^2) = 2\dot{x}_\alpha \frac{D\delta x^\alpha}{D\lambda}, \qquad (122)$$

one gets

$$\int \eta \bar{\delta}(\dot{\boldsymbol{x}}^2) d\lambda = -2 \int \frac{D}{D\lambda} \left( \eta \frac{Dx_{\alpha}}{D\lambda} \right) \delta x^{\alpha} d\lambda \,. \tag{123}$$

Let us calculate the covariant variation of the second term of the action (115):

$$\bar{\delta} \int b_{\mu} \dot{x}^{\mu} d\lambda = \int [(\bar{\delta}b_{\mu})\dot{x}^{\mu} + b_{\alpha}\bar{\delta}(\dot{x}^{\alpha})]d\lambda,$$

$$= \int [b_{\mu;\alpha} - b_{\alpha;\mu}]\dot{x}^{\mu} \delta x^{\alpha} d\lambda = \int k_{\alpha\mu}\dot{x}^{\mu} \delta x^{\alpha} d\lambda.$$
(124)

Here we used the properties

$$\bar{\delta}(\dot{x}^{\alpha}) = \frac{d\delta x^{\alpha}}{d\lambda}, \quad \frac{d}{d\lambda}b_{\alpha} = b_{\alpha,\mu}\dot{x}^{\mu}.$$
 (125)

and performed an integration by parts. Combining these results one obtains the equation

<span id="page-9-0"></span>
$$\frac{D}{D\lambda} \left( \eta \frac{Dx^{\mu}}{D\lambda} \right) = \frac{s}{\omega} k^{\mu}_{\ \nu} \dot{x}^{\nu} \,. \tag{126}$$

Using the freedom in the choice of the parameter  $\lambda$ , we can put  $\eta = 1$ . Then  $\lambda$  becomes the canonical parameter and equation (126) coincides with (90).

#### <span id="page-9-1"></span>B. Hamiltonian equations

The Hamiltonian is defined as follows

$$H = \dot{x}^{\mu} P_{\mu} - L \,, \tag{127}$$

where

<span id="page-9-3"></span>
$$P_{\mu} = \frac{\partial L}{\partial \dot{x}^{\mu}} = \omega \dot{x}_{\mu} + s b_{\mu} \,. \tag{128}$$

Thus one has

$$H = \frac{1}{2\omega} (\mathbf{P} - s\mathbf{b})^2 \equiv \frac{1}{2\omega} g^{\alpha\beta} (P_{\alpha} - sb_{\alpha}) (P_{\beta} - sb_{\beta}).$$
 (129)

The Hamiltonian equations are of the form

<span id="page-9-4"></span>
$$\dot{x}^{\mu} = \frac{\partial H}{\partial P_{\mu}} = \frac{1}{\omega} g^{\mu\nu} (P_{\nu} - sb_{\nu}), \qquad (130)$$

$$\dot{\sigma} = \frac{\partial H}{\partial P_{\mu}} = \frac{1}{\omega} g^{\mu\nu} (P_{\nu} - sb_{\nu}), \qquad (130)$$

$$\dot{P}_{\mu} = -\frac{\partial H}{\partial x^{\mu}} = \frac{s}{\omega} (P^{\nu} - sb^{\nu}) \frac{\partial b_{\nu}}{\partial x^{\mu}} - \frac{1}{2\omega} \frac{\partial g^{\alpha\beta}}{\partial x^{\mu}} (P_{\alpha} - sb_{\alpha}) (P_{\beta} - sb_{\beta}).$$
 (131)

Here  $\dot{a}$  means a derivative of a with respect to the parameter  $\lambda$ ,  $\dot{a}=da/d\lambda$ . Let us demonstrate that these equations reproduce the Euler-Lagrange equations (90). Substituting expression (128) for P, into (131) one gets the following relation

<span id="page-9-5"></span>
$$\frac{d}{d\lambda}(\omega g_{\mu\nu}\dot{x}^{\nu} + sb_{\mu}) = \frac{\omega}{2} \frac{\partial g_{\alpha\beta}}{\partial x^{\mu}} \dot{x}^{\alpha} \dot{x}^{\beta} + s \frac{\partial b_{\nu}}{\partial x^{\mu}} \dot{x}^{\nu} . \quad (132)$$

To obtain this relation we used the equality

$$\frac{\partial g^{\alpha\beta}}{\partial x^{\mu}} = -g^{\alpha\lambda}g^{\beta\rho}\frac{\partial g_{\alpha\rho}}{\partial x^{\mu}}.$$
 (133)

Let us note that

$$\frac{dg_{\mu\nu}}{d\lambda} = \frac{\partial g_{\mu\nu}}{\partial x^{\alpha}} \dot{x}^{\alpha}, \quad \frac{db_{\mu}}{d\lambda} = \frac{\partial b_{\mu}}{\partial x^{\alpha}} \dot{x}^{\alpha}. \tag{134}$$

Using these relations and collecting terms with factors  $\omega$  and s in (132) one gets

<span id="page-9-6"></span>
$$\omega g_{\mu\nu} \left( \frac{d\dot{x}^{\nu}}{d\lambda} + \Gamma^{\nu}_{\alpha\beta} \dot{x}^{\alpha} \dot{x}^{\beta} \right) = s k_{\mu\nu} \dot{x}^{\nu} , \qquad (135)$$

where

$$\Gamma^{\nu}_{\alpha\beta} = \frac{1}{2} g^{\nu\gamma} \left( g_{\alpha\gamma,\beta} + g_{\beta\gamma,\alpha} - g_{\alpha\beta,\gamma} \right) . \tag{136}$$

The equation (135) can be written in the form

$$\frac{D^2 x^{\mu}}{D\lambda^2} = \frac{s}{\omega} k^{\mu}_{\ \nu} \dot{x}^{\nu} \,, \tag{137}$$

$$k_{\mu\nu} = b_{\nu;\mu} - b_{\mu;\nu} \,. \tag{138}$$

It is easy to see that this equation correctly reproduces the polarized rays equation (90) with k defined in (109).

The phase function S(x) which enters the field ansatz (37) can be found as a solution of the Hamilton-Jacobi equation

$$H(\nabla S, x) = \frac{1}{2\omega} g^{\mu\nu} (S_{,\mu} - sb_{\mu}) (S_{,\nu} - sb_{\nu}) = 0. \quad (139)$$

The above described results can be presented in a slightly different form. Let us instead of the canonical momenta  $P_{\mu}$  introduce a generalized momenta

$$\Pi_{\mu} = P_{\mu} - sb_{\mu} \,, \tag{140}$$

and define new Poisson brackets as follows

<span id="page-10-0"></span>
$$\{x^{\mu}, x^{\nu}\} = 0, \ \{x^{\mu}, P_{\nu}\} = \delta^{\mu}_{\nu}, \ \{\Pi_{\mu}, \Pi_{\mu}\} = sk_{\mu\nu}.$$
 (141)

Then it is possible to show that the Hamiltonian equations for

$$H = \frac{1}{\omega} g^{\mu\nu} \Pi_{\mu} \Pi_{\nu} \tag{142}$$

with a modified symplectic form defined by relations (141) are equivalent to the original Hamiltonian equations (130)-(131)<sup>4</sup>.

#### C. Initial conditions

In order to solve the system of equations (110)–(112) for polarized null rays one needs to complement this system with initial conditions, that is to make a choice of the null frame  $(l, m, \bar{m}, n)$  at some initial moment of time. Let us discuss this point.

We denote by  $\Sigma$  a spacelike surface and let  $\boldsymbol{u}$  be a timelike unit vector orthogonal to it. In the vicinity of  $\Sigma$  we introduce synchronous (Gaussian normal) coordinates  $(\tau,y^i)$  in which  $\tau=0$  is an equation of  $\Sigma$  and the metric is of the form

$$ds^2 = -d\tau^2 + g_{ij}(\tau, y^i)dy^idy^j, \quad i, j = 1, 2, 3.$$
 (143)

We denote by  $h_{ij}(y^i) = g_{ij}(\tau = 0, y^i)$  a 3-metric on surface  $\Sigma$  induced by its embedding into the four-dimensional spacetime.

Our ansatz for a high-frequency approximate solution for a polarized beam of light is

$$\mathbf{A} = f \mathbf{m} \exp(iS). \tag{144}$$

Here f and S are functions of coordinates  $x^{\mu}$  in the four-dimensional spacetime. Let us denote by  $f^0$  and  $S^0$  the value of these quantities on  $\Sigma$ 

$$f^{0}(y^{i}) = f(\tau = 0, y^{i}), \quad S^{0}(y^{i}) = S(\tau = 0, y^{i}).$$
 (145)

For a beam of light which has finite size and finite duration in time the function  $f^0$  vanishes outside some finite domain on  $\Sigma$ . We focus on the initial conditions which has this property.

Equation  $S^0 = C$  with some constant C defines a twodimensional surface on  $\Sigma$  which can be identified with a wavefront for the light beam (see e.g. discussion in [8]). A set of these wavefronts for different values of Cfoliates  $\Sigma$ . A three vector  $\vec{P}$ ,  $P_i = S^0_{,i}$ , is orthogonal to the wavefront. It coincides with the direction of the wave front propagation.

For a local observer  $\boldsymbol{u}$  we define a two-dimensional plane which is orthogonal to both  $\boldsymbol{u}$  and  $\vec{P}$ . Denote by  $\boldsymbol{e}_1$  and  $\boldsymbol{e}_2$  two unit mutually orthogonal vectors tangent to this plane such that the set of vectors  $(\boldsymbol{e}_1, \boldsymbol{e}_2, \vec{P})$  is right-handed. Denote  $\boldsymbol{m}^0 = (\boldsymbol{e}_1 + i\boldsymbol{e}_2)/\sqrt{2}$ . We assume that  $\boldsymbol{m}^0(y^i)$  coincides with the initial value of the normalized polarization vector  $\boldsymbol{m}$  on  $\Sigma$ , that is

$$m_{\mu}|_{\Sigma} = (0, m_i^0).$$
 (146)

The vector  $\boldsymbol{b}$  is defined as follows

$$b_{\mu} = i\bar{m}^{\nu} m_{\mu;\mu} = i\bar{m}^{\nu} (m_{\nu,\mu} - \Gamma_{\nu\mu\rho} m^{\rho}),$$
 (147)

where  $\Gamma_{\nu\mu\rho}$  are four-dimensional Christoffel symbols for the metric  $g_{\mu\nu}$ . Since the time component of  $\boldsymbol{m}$  vanishes at  $\Sigma$ , it is easy to check that the spatial components of the vector  $\boldsymbol{b}$  on  $\Sigma$  can be written in the form

$$b_i = i\bar{m}^j (m_{j,i} - \gamma_{kij} m^k), \qquad (148)$$

where

$$\gamma_{kij} = \frac{1}{2} \left( \frac{\partial h_{ik}}{\partial y^j} + \frac{\partial h_{kj}}{\partial y^i} - \frac{\partial h_{ij}}{\partial y^k} \right)$$
 (149)

are three-dimensional Christoffel symbols calculated for the metric  $\boldsymbol{h}$ .

Let us denote

$$\nu_{\mu} = (0, \nu_i), \quad \nu_i = S_{,i}^0 + sb_i,$$
 (150)

$$l_{\mu} = u_{\mu} + \frac{1}{(\nu^2)^{1/2}} \nu_{\mu}, \quad n_{\mu} = u_{\mu} - \frac{1}{2} l_{\mu}.$$
 (151)

The four-dimensional vectors  $\boldsymbol{l}$  and  $\boldsymbol{n}$  are null and obey the condition  $(\boldsymbol{l},\boldsymbol{n})=-1$ . They, as well as the complex null vectors  $\boldsymbol{m}$  and  $\bar{\boldsymbol{m}}$ , are defined on  $\Sigma$ . Thus for a given value of the phase function  $S^0$  on  $\Sigma$  we constructed a null frame on this initial surface. We use this choice as the initial conditions for the set of equations (110), (112). We also choose the canonical parameter  $\lambda$  for the null ray to vanish at the initial time (on  $\Sigma$ ). Since  $S_{,\mu}=\omega l_{\mu}+sb_{\mu}$  one has

<span id="page-10-2"></span>
$$\omega = -u^{\mu} S_{,\mu} \,. \tag{152}$$

That is, the parameter  $\omega$  is nothing but the frequency of the wave as measured by the observer  $\boldsymbol{u}$  at the initial moment of time. Let us remind that the canonical parameter  $\lambda$  is defined up to its rescaling  $\lambda \to C\lambda$  where

<span id="page-10-1"></span><sup>&</sup>lt;sup>4</sup> For discussion of this subject and further references see e.g. [48, 49]

C =const along the ray. The condition (152) fixes this ambiguity.

There is still freedom connected with an ambiguity of choice of the vector  $\mathbf{m}$  at the initial moment of time,  $m_{\mu} \to e^{i\varphi(y^i)}m_{\mu}$ . This transformation generates the following change of three-vector  $b_i \to b_i - \varphi_{,i}$ , and it can be absorbed in the redefinition of the initial phase of the beam  $S^0 \to S^0 + s\varphi$ . As we already mentioned, the equation (110) is invariant under this transformation.

Let us finally find the phase function  $S(x^{\mu})$  which enters the high-frequency field ansatz (37). One has

$$\frac{dS}{d\lambda} \equiv \frac{dS(x^{\mu}(\lambda))}{d\lambda} = S_{,\mu}\dot{x}^{\mu} \,. \tag{153}$$

Since  $S_{,\mu} = P_{\mu}$  one can use (128) and write

<span id="page-11-0"></span>
$$\frac{dS}{d\lambda} = \omega \dot{\boldsymbol{x}}^2 + s(\boldsymbol{b}, \dot{\boldsymbol{x}}). \tag{154}$$

Along the null ray  $\dot{x}^2=0$ . Using the equations of F-transport (16) one can also conclude that  $l^{\mu}\bar{m}^{\nu}m_{\nu;\mu}=0$ , so that the second term in the right-hand side of (154) vanishes as well. Thus  $dS/d\lambda=0$ . This means that the phase function  $S(x^{\mu})$  is constant along null ray trajectories. By solving the ray equations one can find coordinates  $x^{\mu}$  of a point on the trajectory which starts at a point  $y^i$  on  $\Sigma$  and reaches  $x^{\mu}$  at the value of the canonical parameter equal to  $\lambda$ ,  $x^{\mu}=x^{\mu}(\lambda,y^i)$ . Taking the inverse of these relations one gets

$$\lambda = \lambda(x^{\mu}), \quad y^i = y^i(x^{\mu}). \tag{155}$$

Since S is constant along the rays one obtains

$$S(x^{\mu}) = S^{0}(y^{i}(x^{\mu})). \tag{156}$$

This means that after the integration of the polarized ray equations one can restore the phase function in the field ansatz (37) by using its initial value  $S^0$ , and hence to obtain a required high-frequency approximate solution of the Maxwell equations in a curved spacetime.

# VII. DISCUSSION

Let us summarize the obtained results. In order to describe propagation of high-frequency monochromatic beam of circularly polarized light in a curved spacetime one needs first to find a solution of the set of ordinary differential equations (110)–(112). A choice of a beam is specified by imposing initial conditions on the null rays at some moment of time. After fixing a null frame associated with this beam at the initial time its propagation along the null rays is determined by equations (112). Equation (110) shows that in the presence of curvature the motion of a circularly polarized photons is non-geodesic. A trajectory of such a photon depends both on its helicity and frequency. A linearly polarized light can be presented as a superposition of the right and

left-handed circularly polarized states with equal amplitudes. This means that a beam of light which is initially linearly polarized during its propagation in the gravitational field can split into two spatially separated circularly polarized beams with the opposite states of the helicity.

Another consequence of the equation (110) is the following. Suppose a distant observer registers time when burst of a circularly polarized light emitted at some point reaches the point of the observation. In the limit  $\omega \to \infty$ the motion of such photons is geodesic. However, if the frequency  $\omega$  is finite this is not anymore true. At the same time polarized photons still propagate with the speed of light. It is well known that it takes longer time for such photons to reach the point of observation. This statement is known as a generalized Fermat principle [50–53]. This effect of a time delay for circularly polarized photons in a gravitational field is another important consequence of the spin optics equation (110). Let us emphasize that this time delay depends both on their frequency and helicity. This opens an interesting principal opportunity for the observation of this effect.

The equation (110) is obtained in the spin optics approximation for the propagation of the high-frequency electromagnetic waves in the curved spacetime so that the helicity parameter s which enters it has values  $\pm 1$ . However, the form of this equation suggests that it should be valid for other massless fields with spin, in particular, for propagation of the gravitational waves. It is interesting to develop the spin optics approach to this case.

It should be emphasized that we often refer to spin optics in application to the polarized *light* propagation. But certainly this approach is applicable to all kinds of the electromagnetic waves including radio waves. The only limitation is that the corresponding wavelength is much smaller that characteristic length scale of the problem. It is interesting to search for possible observable polarization depended effects for electromagnetic and gravitational waves propagation in the cosmological and black hole backgrounds. In particular, it is well known that geodesic equations in the Kerr geometry are completely integrable. Is the same property valid for the polarized light equation (110)? If the presence of the curvature violates the complete integrability of this equation then the motion of polarized photons in the Kerr geometry may become chaotic. In particular, this may affect the properties of a shadow of black holes.

#### ACKNOWLEDGMENTS

The author thanks the Natural Sciences and Engineering Research Council of Canada and the Killam Trust for their financial support. He is also grateful to Andrei Frolov for many stimulating discussions.

- <span id="page-12-0"></span>[1] P. Debay, Ann. Phys. (Leopzig) 35, 277 (1911).
- <span id="page-12-1"></span>[2] M. Born and E. Wolf, Principles of Optics: Electromagnetic Theory of Propagation, Interference and Diffraction of Light (Cambridge University Press, 2000).
- <span id="page-12-2"></span>[3] I. Arnold, Mathematical methods of classical mechanics (Springer, 1989).
- <span id="page-12-3"></span>[4] R. Sachs, Proc. Roy. Soc. Lond. A A264, 309 (1961).
- [5] I. Robinson, Journal of Mathematical Physics 2, 290 (1961).
- [6] J. Kristian and R. K. Sachs, Astrophys. J. 143, 379 (1966).
- <span id="page-12-4"></span>[7] J. Ehlers, Zeitschrift Naturforschung Teil A 22, 1328 (1967).
- <span id="page-12-5"></span>[8] C. W. Misner, K. Thorne, and J. Wheeler, Gravitation (W.H. Freeman and Co., San Francisco, 1974).
- <span id="page-12-6"></span>[9] S. Seitz, P. Schneider, and J. Ehlers, Class. Quant. Grav. 11, 2345 (1994).
- [10] S. R. Dolan, International Journal of Modern Physics D 27, 1843010 (2018).
- <span id="page-12-7"></span>[11] S. R. Dolan, (2018), [arXiv:1801.02273 \[gr-qc\].](http://arxiv.org/abs/1801.02273)
- <span id="page-12-8"></span>[12] J. Plebanski, Phys. Rev. 118, 1396 (1960).
- [13] T. Piran and P. N. Safier, Nature (London) 318, 271 (1985).
- [14] H. Ishihara, M. Takahashi, and A. Tomimatsu, Phys. Rev. D 38, 472 (1988).
- [15] M. Nouri-Zonoz, Physical Review D 60, 024013 (1999).
- <span id="page-12-9"></span>[16] M. Sereno, Phys. Rev. D 69, 087501 (2004).
- <span id="page-12-10"></span>[17] S. Hou, X.-L. Fan, and Z.-H. Zhu, Phys. Rev. D 100, 064028 (2019).
- <span id="page-12-11"></span>[18] S. Rytov, Dokl. Akad. Nauk SSSR 18, 263 (1938).
- [19] P. S. Pershan, Journal of Applied Physics 38, 1482 (1967).
- <span id="page-12-12"></span>[20] Y. A. Kravtsov and Y. I. Orlov, Geometrical Optics of Inhomogeneous Media (Berlin, GR: Springer-Verlag, 1990).
- <span id="page-12-13"></span>[21] B. Mashhoon, Nature (London) 250, 316 (1974).
- [22] B. Mashhoon, Phys. Rev. D 11, 2679 (1975).
- <span id="page-12-14"></span>[23] B. Mashhoon, Acta Phys. Polon. Supp. 1, 113 (2008).
- <span id="page-12-15"></span>[24] A. V. Dooghin, N. D. Kundikova, V. S. Liberman, and B. Y.Zel'dovich, Phys Rev A. 45, 8204 (1992).
- <span id="page-12-16"></span>[25] K. Y. Bliokh and Y. P. Bliokh, JETP Letters 79, 519 (2004).
- <span id="page-12-17"></span>[26] M. Onoda, S. Murakami, and N. Nagaosa, Phys. Rev. Lett. 93, 083901 (2004).
- <span id="page-12-18"></span>[27] K. Y. Bliokh, F. J. Rodr´ıguez-Fortu˜no, F. Nori, and A. V. Zayats, Nature Photonics 9, 796 (2015).

- <span id="page-12-19"></span>[28] X. Ling, X. Zhou, K. Huang, Y. Liu, C.-W. Qiu, H. Luo, and S. Wen, Reports on Progress in Physics 80, 066401 (2017).
- <span id="page-12-20"></span>[29] J.-M. Souriau, Annales de l'I.H.P. Physique th´eorique 20, 315 (1974).
- [30] P. Saturnini, A model of massless spinning particle in the gravitational field, Theses, Universit´e de Provence (1976).
- [31] C. Duval, Comm. Math. Phys. 283, 701 (2008).
- <span id="page-12-21"></span>[32] C. Duval, L. Marsot, and T. Sch¨ucker, Phys. Rev. D 99, 124037 (2019).
- <span id="page-12-22"></span>[33] P. Gosselin, A. Berard, and H. Mohrbach, Physical Review D 75, 084035 (2007).
- <span id="page-12-23"></span>[34] V. P. Frolov and A. A. Shoom, Phys. Rev. D 84, 044026 (2011).
- <span id="page-12-30"></span>[35] V. P. Frolov and A. A. Shoom, Phys. Rev. D 86, 024010 (2012).
- [36] C.-M. Yoo, Phys. Rev. D 86, 084005 (2012).
- <span id="page-12-24"></span>[37] A. A. Shoom, (2020), [arXiv:2006.10077 \[gr-qc\].](http://arxiv.org/abs/2006.10077)
- <span id="page-12-25"></span>[38] M. A. Oancea, C. F. Paganini, J. Joudioux, and L. Andersson, (2019), [arXiv:1904.09963 \[gr-qc\].](http://arxiv.org/abs/1904.09963)
- <span id="page-12-26"></span>[39] S. Weinberg, Phys. Rev. 126, 1899 (1962).
- [40] J. D. Bjorken and H. S. Orbach, Phys. Rev. D 23, 2243 (1981).
- <span id="page-12-27"></span>[41] Y. A. Kravtsov, O. N. Naida, and A. A. Fuk, Soviet Physics Uspekhi 166, 141 (1996).
- <span id="page-12-28"></span>[42] W. Pauli, Helv. Phys. Acta 5, 179 (1932).
- <span id="page-12-29"></span>[43] B. C. Hsu, M. Berrondo, and J.-F. S. van Huele, Phys. Rev. A 83, 012109 (2011).
- <span id="page-12-31"></span>[44] M. A. Oancea, J. Joudioux, I. Dodin, D. Ruiz, C. F. Paganini, and L. Andersson, (2020), [arXiv:2003.04553 \[gr-qc\].](http://arxiv.org/abs/2003.04553)
- <span id="page-12-32"></span>[45] S. A. Teukolsky, Astrophys. J. 185, 635 (1973).
- <span id="page-12-33"></span>[46] C. Duval, Z. Horvath, and P. Horvathy, Phys. Rev. D 74, 021701 (2006).
- <span id="page-12-34"></span>[47] B. DeWitt, Bryce DeWitt's Lectures on Gravitation, edited by S. M. Christensen, Vol. 826 (Springer, 2011).
- <span id="page-12-35"></span>[48] J. W. van Holten, Phys. Rev. D 75, 025027 (2007).
- <span id="page-12-36"></span>[49] G. d'Ambrosi, S. Satish Kumar, and J. W. van Holten, Physics Letters B 743, 478 (2015).
- <span id="page-12-37"></span>[50] V. Perlick, Classical and Quantum Gravity 7, 1319 (1990).
- [51] V. Perlick, Ray Optics, Fermat's Principle, and Applications to General Relativity (Springer-Verlag Berlin Heidelberg, 2000).
- [52] V. Perlick, General Relativity and Gravitation 38, 365 (2006).
- <span id="page-12-38"></span>[53] V. P. Frolov, Phys. Rev. D88, 064039 (2013).