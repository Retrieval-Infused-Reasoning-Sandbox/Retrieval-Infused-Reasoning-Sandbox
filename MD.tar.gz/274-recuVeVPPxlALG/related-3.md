# Proof of Brooks' Theorem

Yinan Rao

July 2024

## 1 Brooks' Theorem

Brooks' Theorem states that for any connected graph G, if G is neither a complete graph nor an odd cycle, then the chromatic number χ(G) is at most the maximum degree ∆(G).

## 2 Proof

We will consider two cases in the proof of Brooks' Theorem: one for general connected graphs and another for k-regular graphs.[1]

#### 2.1 Case 1: General Connected Graphs

If G is a connected graph other than a complete graph or an odd cycle, then χ(G) ≤ ∆(G).

Proof. Let G be a connected graph and let k = ∆(G). We may assume k ≥ 3, since G is a complete graph when k ≤ 1, and G is bipartite when k = 2, in which case the bound holds.

Our aim is to order the vertices so that each has at most k −1 lower-indexed neighbors; greedy coloring for such an ordering yields the bound.

When G is not k-regular, we can choose a vertex of degree less than k as vn. Since G is connected, we can grow a spanning tree of G from vn, assigning indices in decreasing order as we reach vertices. Each vertex other than v<sup>n</sup> in the resulting ordering v1, . . . , v<sup>n</sup> has a higher-indexed neighbor along the path to v<sup>n</sup> in the tree. Hence each vertex has at most k − 1 lower-indexed neighbors, and the greedy coloring uses at most k colors.

![](_page_0_Picture_12.jpeg)

Figure 1: case 1

![](_page_1_Figure_0.jpeg)

Figure 2: case 2

### 2.2 Case 2: k-Regular Graphs

If G is a connected k-regular graph with k ≥ 3, then χ(G) ≤ k.

Proof. In the remaining case, G is k-regular. Suppose first that G has a cutvertex x, and let G′ be a subgraph consisting of a component of G − x together with its edges to x. The degree of x in G′ is less than k, so the method above provides a proper k-coloring of G′ . By permuting the names of colors in the subgraphs resulting in this way from components of G − x, we can make the colorings agree on x to complete a proper k-coloring of G.

We may thus assume that G is 2-connected. In every vertex ordering, the last vertex has k earlier neighbors. The greedy coloring idea may still work if we arrange that two neighbors of v<sup>n</sup> get the same color.

In particular, suppose that some vertex v<sup>n</sup> has neighbors v1, v<sup>2</sup> such that v<sup>1</sup> ̸= v<sup>2</sup> and G − {v1, v2} is connected. In this case, we index the vertices of a spanning tree of G− {v1, v2} using 3, . . . , n such that labels increase along paths to the root vn. As before, each vertex before v<sup>n</sup> has at most k −1 lower-indexed neighbors. The greedy coloring also uses at most k − 1 colors on neighbors of vn, since v<sup>1</sup> and v<sup>2</sup> receive the same color.

Hence it suffices to show that every 2-connected k-regular graph with k ≥ 3 has such a triple v1, v2, vn. Let's denote the vertex connectivity of a graph G by κ(G). Choose a vertex x. If κ(G − x) ≥ 2, let v<sup>1</sup> be x and let v<sup>2</sup> be a vertex with distance 2 from x. Such a vertex v<sup>2</sup> exists because G is regular and is not a complete graph; let v<sup>n</sup> be a common neighbor of v<sup>1</sup> and v2.

If κ(G − x) = 1, let v<sup>n</sup> = x. Since G has no cut-vertex, x has a neighbor in every leaf block of G − x. Neighbors v1, v<sup>2</sup> of x in two such blocks are nonadjacent. Also, G−{x, v1, v2} is connected, since blocks have no cut-vertices. Since k ≥ 3, vertex x has another neighbor, and G − {v1, v2} is connected.

## References

[1] Cheng, J. (2024). Graph Theory & Algorithms. Tsinghua University Press.