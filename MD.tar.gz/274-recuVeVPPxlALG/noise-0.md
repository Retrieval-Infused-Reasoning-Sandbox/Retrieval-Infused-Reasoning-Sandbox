![](_page_0_Picture_0.jpeg)

A determinacy approach to Borel combinatorics

Author(s): Andrew S. Marks

Source: Journal of the American Mathematical Society , April 2016, Vol. 29, No. 2 (April

2016), pp. 579-600

Published by: American Mathematical Society

Stable URL:<https://www.jstor.org/stable/10.2307/jamermathsoci.29.2.579>

# REFERENCES

Linked references are available on JSTOR for this article: [https://www.jstor.org/stable/10.2307/jamermathsoci.29.2.579?seq=1&cid=pdf](https://www.jstor.org/stable/10.2307/jamermathsoci.29.2.579?seq=1&cid=pdf-reference#references_tab_contents)[reference#references\\_tab\\_contents](https://www.jstor.org/stable/10.2307/jamermathsoci.29.2.579?seq=1&cid=pdf-reference#references_tab_contents) You may need to log in to JSTOR to access the linked references.

JSTOR is a not-for-profit service that helps scholars, researchers, and students discover, use, and build upon a wide range of content in a trusted digital archive. We use information technology and tools to increase productivity and facilitate new forms of scholarship. For more information about JSTOR, please contact support@jstor.org.

Your use of the JSTOR archive indicates your acceptance of the Terms & Conditions of Use, available at https://about.jstor.org/terms

![](_page_0_Picture_11.jpeg)

American Mathematical Society is collaborating with JSTOR to digitize, preserve and extend access to Journal of the American Mathematical Society

### **A DETERMINACY APPROACH TO BOREL COMBINATORICS**

### ANDREW S. MARKS

# 1. Introduction

A Borel graph on a standard Borel space X is a symmetric irreflexive relation G on X that is Borel as a subset of X × X. We call elements of X vertices, and if x, y ∈ X and xGy, then we say that x and y are neighbors, or are adjacent. The degree of a vertex is its number of neighbors, and a graph is said to have degree ≤ n if each of its vertices has degree ≤ n. A graph is said to be regular if all of its vertices have the same number of neighbors and is n-regular if this number is n.

Graph coloring is a typical problem studied in the field of Borel combinatorics, where a Borel coloring of a Borel graph G on X is a Borel function c : X → Y from the vertices of G to a standard Borel space Y such that if xGy, then c(x) = c(y). The Borel chromatic number χB(G) of G is the least cardinality of a standard Borel space Y such that G has a Borel coloring with codomain Y . The first systematic study of Borel chromatic numbers was done by Kechris, Solecki, and Todorcevic [\[16\]](#page-21-0). Since then, fruitful connections have been found between the study of Borel chromatic numbers and other areas of mathematics such as ergodic theory and dynamics [\[3,](#page-21-1) [4\]](#page-21-2), and dichotomies in descriptive set theory [\[23\]](#page-22-0).

If G is a Borel graph, then it is clear that χ(G) ≤ χB(G), where χ(G) is the usual chromatic number of G. However, χ(G) and χB(G) may differ quite wildly. For instance, Kechris, Solecki, and Todorcevic [\[16\]](#page-21-0) show the existence of an acyclic Borel graph G<sup>0</sup> (so χ(G0) = 2) for which χB(G0)=2ℵ<sup>0</sup> . Nevertheless, in some respects the Borel chromatic number of a graph is quite similar to the usual chromatic number. For example, we have the following analogue of an obvious classical fact.

<span id="page-1-0"></span>**Theorem 1.1** (Kechris, Solecki, and Todorcevic [\[16\]](#page-21-0))**.** If G is a Borel graph of degree ≤ n, then χB(G) ≤ n + 1.

We will be interested in Borel graphs that arise from free Borel actions of countable marked groups. Recall that a marked group is a group with a specified set of generators. We assume throughout this paper that the set of generators of a group does not include the identity. Let Γ be a countable discrete group and X be a standard Borel space. We endow the space X<sup>Γ</sup> of functions from Γ to X with the usual product Borel structure (arising from the product topology) so that

c 2015 American Mathematical Society

Received by the editors April 12, 2013 and, in revised form, April 29, 2015.

<sup>2010</sup> Mathematics Subject Classification. Primary 03E15; Secondary 05C15, 05C70, 37A15.

The author is partially supported by the National Science Foundation under grant DMS-1204907 and the John Templeton foundation under Award No. 15619.

The author would also like to thank the Institute for Mathematical Sciences and the Department of Mathematics of the National University of Singapore and the John Templeton Foundation for their support to attend the 2012 summer school in logic, where the main lemma of this paper was conceived.

 $X^{\Gamma}$  is also a standard Borel space. The *left shift action* of  $\Gamma$  on  $X^{\Gamma}$  is defined by  $\alpha \cdot y(\beta) = y(\alpha^{-1}\beta)$  for  $y \in X^{\Gamma}$  and  $\alpha, \beta \in \Gamma$ . The *free part* of this action, denoted Free( $X^{\Gamma}$ ), is the set of  $y \in X^{\Gamma}$  such that  $\gamma \cdot y \neq y$  for all nonidentity  $\gamma \in \Gamma$ . Now we define  $G(\Gamma, X)$  to be the Borel graph on Free( $X^{\Gamma}$ ) where for  $x, y \in \operatorname{Free}(X^{\Gamma})$ , we have  $x G(\Gamma, X)$  y if there is a generator  $\gamma \in \Gamma$  such that  $\gamma \cdot x = y$  or  $\gamma \cdot y = x$ . Hence, each connected component of  $G(\Gamma, X)$  is an isomorphic copy of the Cayley graph of  $\Gamma$ . We will only be interested in  $G(\Gamma, X)$  when  $\Gamma$  is finitely generated; an easy Baire category argument shows that if  $\Gamma$  has infinitely many generators, then  $\chi_B(G(\Gamma, 2)) = 2^{\aleph_0}$  (see [16]).

If  $\Gamma$  is a marked countable group, then  $G(\Gamma, \mathbb{N})$  attains the maximum Borel chromatic number of all graphs generated by a free Borel action of  $\Gamma$ . That is, suppose we have any free Borel action of  $\Gamma$  on a standard Borel space X, to which we associate the Borel graph  $G_{\Gamma}^X$  on X where x  $G_{\Gamma}^X$  y if there is a generator  $\gamma$  of  $\Gamma$  such that  $\gamma \cdot x = y$  or  $\gamma \cdot y = x$ . Then  $\chi_B(G_{\Gamma}^X) \leq \chi_B(G(\Gamma, \mathbb{N}))$ . This is trivial when  $\Gamma$  is finite. When  $\Gamma$  is infinite, it follows from [15, Theorem 5.4]; since the action of  $\Gamma$  on X is free, the function constructed there will an injective equivariant function from X into Free( $\mathbb{N}^{\Gamma}$ ). Recall that if  $\Gamma$  acts on the spaces X and Y, then a function  $f: X \to Y$  is said to be equivariant if for all  $\gamma \in \Gamma$  we have that  $\gamma \cdot f(x) = f(\gamma \cdot x)$ .

Our first result is a theorem describing how the Borel chromatic number of  $G(\Gamma, \mathbb{N})$  behaves with respect to free products (see 3.1). We stipulate that if  $\Gamma$  and  $\Delta$  are marked groups, then their free product  $\Gamma * \Delta$  is the marked group generated by the union of the generators of  $\Gamma$  and  $\Delta$ .

<span id="page-2-0"></span>**Theorem 1.2.** If  $\Gamma$  and  $\Delta$  are finitely generated marked groups, then

$$\chi_B(G(\Gamma * \Delta, \mathbb{N})) \ge \chi_B(G(\Gamma, \mathbb{N})) + \chi_B(G(\Delta, \mathbb{N})) - 1.$$

It has been an open question what Borel chromatic numbers can be attained by an n-regular acyclic Borel graph, and whether the upper bound given by Theorem 1.1 is optimal for such graphs. Several prior results exist along these lines. For 2-regular acyclic graphs, we have that  $\chi_B(G(\mathbb{Z},2))=3$  by [16]. More recently, Conley and Kechris [3] have shown that for the free group on n generators,  $\chi_B(G(\mathbb{F}_n,2))\geq \frac{n+2\sqrt{n-1}}{2\sqrt{n-1}}$ , and Lyons and Nazarov [20] have pointed out that results of Frieze and Luczak [12] imply that  $\chi_B(G(\mathbb{F}_n,2))\geq \frac{n}{\log 2n}$  for sufficiently large n.

Using Theorem 1.2, we answer this question and show that for every n there exists an n-regular acyclic Borel graph with Borel chromatic number equal to n+1. Indeed, if  $(\mathbb{Z}/2\mathbb{Z})^{*n}$  is the free product of n copies of  $\mathbb{Z}/2\mathbb{Z}$ , then  $\chi_B(G((\mathbb{Z}/2\mathbb{Z})^{*n},\mathbb{N})) = n+1$ , since Theorem 1.2 gives a tight lower bound to the upper bound of Theorem 1.1. Similarly, for the free group on n generators, we have  $\chi_B(G(\mathbb{F}_n,\mathbb{N})) = 2n+1$ .

Further, we can give a complete description of the Borel chromatic numbers that can be attained by an n-regular acyclic Borel graph; they are exactly those allowed by Theorem 1.1 (see 3.3).

<span id="page-2-1"></span>**Theorem 1.3.** For every  $n \ge 1$  and every  $m \in \{2, ..., n+1\}$ , there is a n-regular acyclic Borel graph G with  $\chi_B(G) = m$ .

In the theorem above, G may be chosen to arise from a free Borel action of  $(\mathbb{Z}/2\mathbb{Z})^{*n}$ .

Our results above involve graphs of the form  $G(\Gamma, \mathbb{N})$ . Answering a question originally posed in an early version of this paper, Seward and Tucker-Drob [24] have shown that for all marked groups  $\Gamma$ , and all  $n \geq 2$ , we have  $\chi_B(G(\Gamma, \mathbb{N})) = \chi_B(G(\Gamma, n))$ . Hence, our results apply to graphs of the form  $G(\Gamma, 2)$  as well.

Next, we turn to Borel edge colorings. Let G be a Borel graph on a standard Borel space X. If  $x, y \in X$ , then we say the set  $\{x, y\}$  is an edge of G if x G y. The line graph  $\check{G}$  of G is the graph whose vertices are the edges of G, and where distinct  $\{x, y\}$  and  $\{z, w\}$  are adjacent if  $\{x, y\} \cap \{z, w\} \neq \emptyset$ . A Borel edge coloring of G is defined to be a Borel coloring of  $\check{G}$ . The Borel edge chromatic number of a Borel graph G, denoted  $\chi'_{B}(G)$ , is the Borel chromatic number of its line graph.

It is a classical theorem of Vizing (see, e.g., [9, Theorem 5.3.2]) that every n-regular graph has an edge coloring with n+1 colors. Kechris, Solecki, and Todorce-vic have asked if the analogous fact is true for n-regular Borel graphs [16, page 15]. More recently, this question has attracted some interest from the study of graph limits ([11] and [14, Remark 3.8]). We show that this question has a negative answer, and we calculate exactly what Borel edge chromatic numbers can be attained by an n-regular Borel graph. Note that if G is an n-regular Borel graph, then since  $\check{G}$  is 2n-2 regular, we see that  $\chi_B(\check{G}) \leq 2n-1$  by Theorem 1.1. We show that this obvious upper bound can be achieved, even using acyclic and Borel bipartite graphs (see 3.10). Recall that a Borel bipartite graph is a Borel graph G on X for which there is a partition of X into two Borel sets A and B such that if E E E0, then either E1 and E2 and E3 and E3 and E4 and E5 and E5 and E6 and E7.

<span id="page-3-1"></span>**Theorem 1.4.** For every  $n \ge 1$  and every  $m \in \{n, ..., 2n-1\}$ , there is an n-regular acyclic Borel bipartite graph G such that  $\chi'_B(G) = m$ .

A Borel perfect matching of a Borel graph G is a Borel subset M of the edges of G such that every vertex of G is incident to exactly one edge of M. In his 1993 problem list, Miller asked whether there is a Borel analogue of Hall's theorem for matchings [22, 15.10]. Laczkovich [19] showed the existence of a 2-regular Borel bipartite graph with no Borel perfect matching, and this result was extended to give examples of n-regular Borel bipartite graphs with no Borel perfect matchings by Conley and Kechris [3] when n is even. However, the case for odd n > 1 had remained open. We obtain the following (see 3.8).

<span id="page-3-0"></span>**Theorem 1.5.** For every n > 1, there exists an n-regular acyclic Borel bipartite graph with no Borel perfect matching.

Some positive results on measurable matchings have recently been obtained by Lyons and Nazarov [20]. Among their results, they show that the graph we use to prove the case n=3 in Theorem 1.5 has a Borel matching modulo a null set with respect to a natural measure. Further work on matchings in the measurable context has been done by Csoka and Lippner [8]. The measurable analogue of Theorem 1.5 for odd n remains open.

Both Theorems 1.4 and 1.5 are corollaries of the following result on Borel disjoint complete sections (see 3.7). Suppose X is a standard Borel space, and E is an equivalence relation on X. Then a complete section for E is a set  $A \subseteq X$  that meets every equivalence class of E. Now suppose that F is also an equivalence relation on X. Then say that E and F have Borel disjoint complete sections if there exist disjoint Borel sets  $A, B \subseteq X$  such that A is a complete section for E and E is a complete section for E.

<span id="page-4-0"></span>**Theorem 1.6.** Let Γ and Δ be countable groups. Let E<sup>Γ</sup> be the equivalence relation on Free(NΓ∗Δ) where x E<sup>Γ</sup> y if there exists a γ ∈ Γ such that γ · x = y. Define E<sup>Δ</sup> analogously. Then E<sup>Γ</sup> and E<sup>Δ</sup> do not have Borel disjoint complete sections.

Theorems [1.2–](#page-2-0)[1.6](#page-4-0) above all follow from a single lemma which we prove in Section [2.](#page-5-0) Unusually for the subject, this lemma is proved using a direct application of Borel determinacy. Borel determinacy is the theorem, due to Martin [\[21\]](#page-22-4), that there is a winning strategy for one of the players in every infinite two-player game of perfect information with a Borel payoff set. We will use the determinacy of a class of games for constructing functions from free products of countable groups to N. Thus, we are also interested in differences between the results proved using our new technique and what can be shown using more standard tools such as measure theory and Baire category, which have been a mainstay of proofs in Borel combinatorics.

Here, Theorem [1.6](#page-4-0) provides a nice contrast because it is not true in the context of measure or category, except for the single case where Γ = Δ = Z/2Z. Indeed, we have the following more general theorem (see [4.5\)](#page-15-0). Recall that a countable Borel equivalence relation on a standard Borel space X is an equivalence relation on X that is Borel as a subset of X × X and whose equivalence classes are countable. E<sup>Γ</sup> and E<sup>Δ</sup> in Theorem [1.6](#page-4-0) are examples of countable Borel equivalence relations.

**Theorem 1.7.** Suppose E and F are countable Borel equivalence relations on a standard Borel space X such that every equivalence class of E has cardinality ≥ 3 and every equivalence class of F has cardinality ≥ 2. Then E and F have Borel disjoint complete sections modulo a null set or meager set with respect to any Borel probability measure on X or Polish topology realizing the standard Borel structure of X.

As we will see, the idea of disjoint complete sections turns out to be surprisingly robust, as evidenced by a large number of equivalent formulations which we give in Theorems [4.5](#page-15-0) and [4.7](#page-18-0) later in the paper. Using the existence of disjoint complete sections in the context of measure and category, we also show the following, which contrasts nicely with Theorem [1.4](#page-3-1) and demonstrates that it cannot be proved using measure-theoretic or Baire category techniques (see [4.8\)](#page-20-0).

**Theorem 1.8.** Suppose G is a 3-regular Borel bipartite graph on X. Then G has a Borel edge coloring with 4 colors modulo a null set or meager set with respect to any Borel probability measure on X or Polish topology realizing the standard Borel structure of X.

Finally, in recent joint work with Conley and Tucker-Drob [\[7\]](#page-21-10), we have shown that for every n ≥ 3 and every Borel graph G of degree ≤ n on a standard Borel space X, if G does not contain a complete graph on n + 1 vertices, then there is a μ-measurable n-coloring of G with respect to any Borel probability measure μ on X and a Baire measurable n-coloring of G with respect to every compatible Polish topology on X. Hence, Theorem [1.3](#page-2-1) cannot be proved using pure measure theoretic or Baire category arguments, except in the exceptional case n = 2.

1.1. **Notation and conventions.** Our basic reference for descriptive set theory is [\[17\]](#page-21-11). Throughout we will use X, Y , and Z to denote standard Borel spaces, x, y, and z for elements of such spaces, and A, B, and C for subsets of standard Borel spaces (which will generally be Borel). Given a subset A of a standard Borel space, we let  $A^{c}$  denote its complement.

We will use E and F for countable Borel equivalence relations, and G and H for Borel graphs. We will use f, g, and h to denote functions between standard Borel spaces, and c for Borel colorings.  $\Gamma$  and  $\Delta$  will be used to denote countable groups, and  $\alpha$ ,  $\beta$ ,  $\gamma$ , and  $\delta$  will be their elements. We will use e for the identity of a group. By countable group, we will always mean countable discrete group.

If E is a countable Borel equivalence relation on a standard Borel space X, then  $A \subseteq X$  is said to be E-invariant if  $x \in A$  and  $x \in Y$  implies  $y \in A$ . If B is a subset of X, then we will often consider the largest E-invariant subset of B. Precisely, this is the set A of  $x \in X$  such that for all  $y \in X$  where  $y \in X$ , we have  $y \in B$ .

#### 2. The main Lemma

<span id="page-5-0"></span>Let  $\Gamma$  and  $\Delta$  be disjoint countable groups, and let  $\Gamma * \Delta$  be their free product. Each nonidentity element of  $\Gamma * \Delta$  can be uniquely written as a finite product of either the form  $\gamma_{i_0}\delta_{i_1}\gamma_{i_2}\delta_{i_3}\ldots$  or  $\delta_{i_0}\gamma_{i_1}\delta_{i_2}\gamma_{i_3}\ldots$ , where  $\gamma_i \in \Gamma$  and  $\delta_i \in \Delta$  are nonidentity elements for all i. Words of the former form we call  $\Gamma$ -words, and words of the latter form we call  $\Delta$ -words. Our proof will use games for building an element  $y \in \mathbb{N}^{\Gamma * \Delta}$  where player I defines y on  $\Gamma$ -words and player II defines y on  $\Delta$ -words.

The following simple observation will let us combine winning strategies in these games in a useful way. Let  $W_{\Gamma}$  and  $W_{\Delta}$  be the sets of  $\Gamma$ -words and  $\Delta$ -words, respectively. Then for distinct  $\gamma, \gamma' \in \Gamma$  we have that  $\gamma W_{\Delta}$  and  $\gamma' W_{\Delta}$  are disjoint, and the analogous fact is true when the roles of  $\Gamma$  and  $\Delta$  are switched.

We now proceed to our main lemma. Note that both  $\Gamma$  and  $\Delta$  act on Free( $\mathbb{N}^{\Gamma*\Delta}$ ) by restricting the left shift action of  $\Gamma*\Delta$  to these subgroups.

<span id="page-5-1"></span>**Lemma 2.1.** [Main Lemma] Let  $\Gamma, \Delta$  be countable groups. If  $A \subseteq \text{Free}(\mathbb{N}^{\Gamma * \Delta})$  is any Borel set, then at least one of the following holds:

- (1) There is a continuous injective function  $f: \operatorname{Free}(\mathbb{N}^{\Gamma}) \to \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  that is equivariant with respect to the left shift action of  $\Gamma$  on these spaces and such that  $\operatorname{ran}(f) \subseteq A$ .
- (2) There is a continuous injective function  $f : \operatorname{Free}(\mathbb{N}^{\Delta}) \to \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  that is equivariant with respect to the left shift action of  $\Delta$  on these spaces and such that  $\operatorname{ran}(f) \subseteq \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta}) \setminus A$ .

*Proof.* The main difficulty in our proof is arranging that our games produce elements of  $\text{Free}(\mathbb{N}^{\Gamma*\Delta})$ , and not merely elements of  $\mathbb{N}^{\Gamma*\Delta}$ . To begin, we make a definition that will get us halfway there. Let Y be the largest invariant set of  $y \in \mathbb{N}^{\Gamma*\Delta}$  such that for all nonidentity  $\gamma \in \Gamma$  and  $\delta \in \Delta$ , we have  $\gamma \cdot y \neq y$  and  $\delta \cdot y \neq y$ . That is, Y is the set of  $x \in \mathbb{N}^{\Gamma*\Delta}$  such that for all  $\alpha \in \Gamma*\Delta$ , if  $y = \alpha^{-1} \cdot x$ , then y has the property above. Note that Y contains  $\text{Free}(\mathbb{N}^{\Gamma*\Delta})$ .

Next, we give a definition that we will use to organize the turn on which  $y(\alpha)$  is defined in our game for each  $\alpha \in \Gamma * \Delta$ . Fix injective listings  $\gamma_0, \gamma_1, \ldots$  and  $\delta_0, \delta_1, \ldots$  of all the nonidentity elements of  $\Gamma$  and  $\Delta$ , respectively. We define the turn function  $t: \Gamma * \Delta \to \mathbb{N}$  as follows. First, define t(e) = -1. Then, for each nonidentity element  $\alpha \in \Gamma * \Delta$ , there is a unique sequence  $i_0, i_1, \ldots, i_m$  such that  $\alpha = \gamma_{i_0} \delta_{i_1} \gamma_{i_2} \ldots$  or  $\alpha = \delta_{i_0} \gamma_{i_1} \delta_{i_2} \ldots$  We define  $t(\alpha)$  to be the least n such that the associated sequence  $i_0, i_1, \ldots, i_m$  for  $\alpha$  has  $i_j + j \leq n$  for all  $j \leq m$ . The key property of this definition is that if  $i \leq n$ , and  $\alpha$  is a  $\Delta$ -word or the identity, then

 $t(\gamma_i \alpha) \leq n$  if and only if  $t(\alpha) < n$ . Of course, this remains true when the roles of  $\Gamma$  and  $\Delta$  are switched.

Now given a Borel set  $B \subseteq Y$ , and  $k \in \mathbb{N}$ , we define the following game  $G_k^B$  for producing a  $y \in \mathbb{N}^{\Gamma*\Delta}$  such that y(e) = k. Player I goes first, and the players alternate defining y on finitely many nonidentity elements of  $\Gamma*\Delta$  as follows. On the nth turn of the game for  $n \geq 0$ , player I must define  $y(\alpha)$  on all  $\Gamma$ -words  $\alpha$  with  $t(\alpha) = n$ , and then player II must respond by defining  $y(\alpha)$  on all  $\Delta$ -words  $\alpha$  with  $t(\alpha) = n$ . We give an illustration of how the game is played:

$$\begin{matrix} \mathbf{I} & \quad \mathbf{II} \\ y(\gamma_0) & \quad \\ & \quad y(\delta_0) \\ y(\gamma_1) & \quad \\ y(\gamma_0 \delta_0) & \quad \\ y(\gamma_1 \delta_0) & \quad \\ \vdots & \quad \end{matrix}$$

All that remains is to define the winning condition of the game. First, if the y that is produced is in Y, then Player II wins the game if and only if y is in B. If  $y \notin Y$ , then there must be some  $\alpha$  such that there is a nonidentity  $\gamma \in \Gamma$  such that  $\gamma \alpha^{-1} \cdot y = \alpha^{-1} \cdot y$ , or there is a nonidentity  $\delta \in \Delta$  such that  $\delta \alpha^{-1} \cdot y = \alpha^{-1} \cdot y$ . In the former case, say  $(\alpha, \Gamma)$  witnesses  $y \notin Y$ , and in the latter say  $(\alpha, \Delta)$  witnesses  $y \notin Y$ . Say  $\alpha$  witnesses  $y \notin Y$  if either  $(\alpha, \Gamma)$  or  $(\alpha, \Delta)$  witnesses  $y \notin Y$ . Now if  $(e, \Gamma)$  witnesses  $y \notin Y$ , then player I loses. Otherwise, if  $(e, \Delta)$  witnesses  $y \notin Y$ , then player II loses. Finally, if neither of the above happens, then player I wins if and only if there is a  $\Delta$ -word  $\alpha$  witnessing  $y \notin Y$  such that for all  $\Gamma$ -words  $\beta$  with  $t(\beta) \leq t(\alpha)$ , we have that  $\beta$  does not witness  $y \notin Y$ . This finishes the definition of our game.

Next, we associate to our set  $A \subseteq \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  a set  $B_A$  that we will use in the play of our game. Let  $E_{\Gamma}$  be the equivalence relation on Y where  $x \ E_{\Gamma} \ y$  if there is a  $\gamma \in \Gamma$  such that  $\gamma \cdot x = y$ . Define  $E_{\Delta}$  similarly. By Lemma 2.3 which we defer till later, we can find a Borel subset C of  $Y \setminus \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  such that C meets every  $E_{\Delta}$ -class on  $Y \setminus \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  and its complement  $C^c$  meets every  $E_{\Gamma}$ -class on  $Y \setminus \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$ . Let  $B_A = A \cup C$ . Our use of C here will be important at the end of the proof to ensure that we create a function into  $\operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  and not merely into Y.

By Borel determinacy, either player I or player II has a winning strategy in  $G_k^{B_A}$  for each  $k \in \mathbb{N}$ . So by the pigeon-hole principle, either player I wins  $G_k^{B_A}$  for infinitely many k or player II wins  $G_k^{B_A}$  for infinitely many k. Assume the latter case holds, and let S be the set of k such that player II wins  $G_k^{B_A}$ . An analogous argument will work in the case that player I wins for infinitely many k. Since there is a continuous injective equivariant function from  $\operatorname{Free}(\mathbb{N}^{\Gamma})$  to  $\operatorname{Free}(S^{\Gamma})$ , it will suffice to define a continuous injection  $f: \operatorname{Free}(S^{\Gamma}) \to \operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  that is equivariant with respect to the left shift action of  $\Gamma$  on these spaces and such that  $\operatorname{ran}(f) \subseteq A$ . Fix winning strategies in each game  $G_k^{B_A}$  for  $k \in S$ .

We will define f so that for all  $x \in \text{Free}(\mathbb{N}^{\Gamma})$  and all  $\gamma \in \Gamma$ , we have  $f(x)(\gamma) = x(\gamma)$ , and so that for all x, f(x) will be a winning outcome of player II's winning strategy in the game  $G_{x(e)}^{B_A}$ .

We proceed as follows. Fix an x in Free( $\mathbb{N}^{\Gamma}$ ). For each  $\gamma \in \Gamma$  we will play an instance of the game  $G_{x(\gamma^{-1})}^{B_A}$  whose outcome will be  $\gamma \cdot f(x)$ . We play these games for all  $\gamma \in \Gamma$  simultaneously. The moves for player II in these games will be made by the winning strategies that we have fixed. We will specify how to move for player I in these games to satisfy our requirement that f is equivariant and  $f(x)(\gamma) = x(\gamma)$ .

So for each  $\gamma \in \Gamma$ , we are playing an instance of the game  $G_{x(\gamma^{-1})}^{BA}$  to define a  $y \in \mathbb{N}^{\Gamma * \Delta}$  equal to  $\gamma \cdot f(x)$ . To begin, we have  $\gamma \cdot f(x)(e) = x(\gamma^{-1})$  by the definition of the game.

Inductively, suppose  $\gamma \cdot f(x)(\alpha)$  is defined for all  $\gamma \in \Gamma$  and all  $\alpha$  with  $t(\alpha) < n$ . We need to make the nth move for player I in all our games. Suppose  $\beta$  is a  $\Gamma$ -word with  $t(\beta) = n$  so we can write  $\beta = \gamma_i \alpha$  where  $i \leq n$  and  $t(\alpha) < n$ . For all  $\gamma \in \Gamma$ , we now define  $(\gamma \cdot f(x))(\gamma_i \alpha) = (\gamma_i^{-1} \cdot (\gamma \cdot f(x)))(\alpha) = (\gamma_i^{-1} \gamma \cdot f(x))(\alpha)$ , which has already been defined in the game associated to  $\gamma_i^{-1} \gamma$  by assumption. Hence we can make the nth move for player I in all our games using this information. To finish the nth turn, the winning strategies for player II in these games respond with their nth moves, defining  $\gamma \cdot f(x)(\delta_i \alpha)$  for all  $i \leq n$  and all  $\alpha$  such that  $\alpha = e$  or  $\alpha$  is a  $\Delta$ -word with  $t(\alpha) < n$ .

Based on our definition, it is clear that f is injective, continuous,  $\Gamma$ -equivariant, and that f(x) is an outcome of player II's winning strategy in  $G_{x(e)}^{B_A}$ . All that remains is to show  $\operatorname{ran}(f) \subseteq A$ .

First, we argue that for all  $x \in \operatorname{Free}(\mathbb{N}^{\Gamma})$ , we have  $f(x) \in Y$ . Now since  $x \in \operatorname{Free}(\mathbb{N}^{\Gamma})$  and f(x)(e) = x(e), we see that  $(e, \Gamma)$  cannot witness  $f(x) \notin Y$ . Further, since f(x) is a winning outcome of a strategy for player II,  $(e, \Delta)$  cannot witness  $f(x) \notin Y$ . Now we can prove inductively that  $\alpha$  does not witness  $f(x) \notin Y$  for all  $x \in \operatorname{Free}(\mathbb{N}^{\Gamma})$  and all  $\alpha \in \Gamma * \Delta$  with  $t(\alpha) = n$ . For each n we do the case of  $\Gamma$ -words first, and then the case of  $\Delta$ -words. Suppose  $\alpha$  is a  $\Gamma$ -word with  $t(\alpha) = n$ , so  $\alpha = \gamma \beta$  for some  $\gamma \in \Gamma$  and  $\beta$  with  $t(\beta) < t(\alpha)$ . Since  $\alpha^{-1} \cdot f(x) = \beta^{-1} \gamma^{-1} \cdot f(x) = \beta^{-1} \cdot f(\gamma^{-1} \cdot x)$  and  $\beta$  does not witness  $f(\gamma^{-1} \cdot x) \notin Y$  by our induction hypothesis, we must have that  $\alpha$  does not witness  $f(x) \notin Y$ . Now suppose  $\alpha$  is a  $\Delta$ -word with  $t(\alpha) = n$ . We may assume no  $\Gamma$ -word  $\beta$  with  $t(\beta) \leq n$  witnesses  $f(x) \notin Y$ . Hence, we see that player II must ensure  $\alpha$  does not witness  $\alpha \cdot f(x) \notin Y$ ; otherwise, they lose the game  $G_{x(e)}^{B_A}$  used to define f(x).

For all x, since  $f(x) \in Y$ , we have  $f(x) \in B_A$ , since f(x) is a winning outcome for player II in some  $G_{x(e)}^{B_A}$ . Finally, we claim that  $f(x) \in A$  for all x. This is because  $\operatorname{ran}(f)$  and A are  $\Gamma$ -invariant,  $B_A = A \cup C$ , and C does not contain any nonempty  $\Gamma$ -invariant sets by definition.  $\square$ 

To finish establishing Lemma 2.1, we must prove Lemma 2.3 which was used to define the set C above. We will prove a version for countably many equivalence relations instead of merely two, since we will use this more general version in a later paper.

We begin by recalling a useful tool for organizing constructions in Borel combinatorics. Let X be a standard Borel space. We let  $[X]^{<\infty}$  denote the standard Borel space of finite subsets of X. If E is a countable Borel equivalence relation, we let  $[E]^{<\infty}$  be the Borel subset of  $[X]^{<\infty}$  consisting of the  $S \in [X]^{<\infty}$  such that S is a subset of some equivalence class of E. If Y is a Borel subset of  $[X]^{<\infty}$ , then the intersection graph on Y is the graph G where R G S for distinct  $R, S \in Y$  if  $R \cap S \neq \emptyset$ .

<span id="page-8-1"></span>**Lemma 2.2** ([18, Lemma 7.3] [6, Proposition 2]). Suppose E is a countable Borel equivalence relation, and let G be the intersection graph on  $[E]^{<\infty}$ . Then G has a Borel  $\mathbb{N}$ -coloring.

We will often use this lemma in the following way. Suppose E is a countable Borel equivalence relation and A is a Borel subset of  $[E]^{<\infty}$  containing at least one subset of every E-class. Then there is a Borel set  $B \subseteq A$  such that elements of B are pairwise disjoint, and B meets every E-class. To see this, pick some Borel  $\mathbb{N}$ -coloring of the intersection graph of  $[E]^{<\infty}$  using Lemma 2.2, and then let B be the set of  $R \in A$  that are assigned the least color of all elements of A from the same E-class.

We need a couple more definitions. Suppose that  $I \in \{1, 2, ..., \infty\}$  and  $\{E_i\}_{i < I}$  are finitely many or countably many equivalence relations on X. Then the  $E_i$  are said to be nonindependent if there exists a sequence  $x_0, x_1, ..., x_n$  of distinct elements of X, and  $i_0, i_1, ..., i_n \in \mathbb{N}$  with  $n \geq 2$  such that  $i_j \neq i_{j+1}$  for j < n,  $i_n \neq i_0$ , and  $x_0 \in E_{i_0} x_1 \in E_{i_1} x_2 \cdots x_n \in E_{i_n} x_0$ . We say this pair of sequences  $x_0, ..., x_n$  and  $i_0, ..., i_n$  witnesses the nonindependence of the  $E_i$ . The  $E_i$  are said to be independent if they are not nonindependent. The join of the  $E_i$ , denoted  $\bigvee_{i < I} E_i$ , is the smallest equivalence relation containing all the  $E_i$ . Precisely, x and y are  $\bigvee_{i < I} E_i$ -related if there is a sequence  $x_0, x_1, ..., x_n$  of elements in X such that  $x = x_0, y = x_n$ , and for all j < n, we have  $x_j \in x_{j+1}$  for some i < I. Finally, we say that the  $E_i$  are everywhere nonindependent if for every  $\bigvee_{i < I} E_i$  equivalence class  $A \subseteq X$ , the restrictions of the  $E_i$  to A are not independent.

<span id="page-8-0"></span>**Lemma 2.3.** Suppose that  $I \in \{1, 2, ..., \infty\}$  and  $\{E_i\}_{i < I}$  are countable Borel equivalence relations on a standard Borel space X that are everywhere nonindependent. Then there exists a Borel partition  $\{A_i\}_{i < I}$  of X such that for all i < I,  $A_i^c$  meets every  $E_i$ -class.

Proof. Using Lemma 2.2, let  $C \subseteq [\bigvee_{i < I} E_i]^{<\infty}$  be a Borel set containing at least one subset of each equivalence class of  $\bigvee_{i < I} E_i$  such that the elements of C are pairwise disjoint and each set  $\{x_0, x_1, \ldots, x_n\} \in C$  can be assigned an order  $x_0, x_1, \ldots, x_n$  and an associated sequence  $i_0, \ldots, i_n$  of natural numbers such that these sequences witness the failure of the independence of the  $E_i$ . Fix a Borel way of assigning such an order and associated  $i_0, \ldots, i_n$  to each element of C. Define disjoint sets  $\{A_{i,0}\}_{i < I}$  by setting  $x \in A_{i,0}$  if there is an element  $\{x_0, \ldots, x_n\}$  of C with associated sequence  $i_0, \ldots, i_n$  and a  $j \le n$  such that  $x = x_j$  and  $i = i_j$ . Note that for all i < I and for all  $x \in A_{i,0}$ , there is a  $y \in [x]_{E_i}$  and  $j \ne i$  such that  $y \in A_{j,0}$ .

Let  $k_0, k_1, \ldots$  be a sequence containing each number less than I infinitely many times. Given  $\{A_{i,n}\}_{i < I}$  we construct disjoint sets  $\{A_{i,n+1}\}_{i < I}$ , where  $A_{i,n+1} \supseteq A_{i,n}$  as follows. Let  $B_{i,n+1}$  be the set of x such that  $x \in [A_{k_n,n}]_{E_i}$  and for all j < i,  $x \notin [A_{k_n,n}]_{E_j}$ . Then let  $A_{i,n+1} = A_{i,n} \cup (B_{i,n+1} \setminus \bigcup_{j \neq i} A_{j,n})$ . The sets  $A_{i,n}$  are Borel, since every  $E_i$  is generated by the Borel action of a countable group by the Feldman-Moore theorem [18, Theorem 1.3].

It is easy to prove by induction that for all  $x \in A_{i,n}$ , there is a  $y \in [x]_{E_i}$  and a  $j \neq i$  such that  $y \in A_{j,n}$ . Let  $A_i = \bigcup_n A_{i,n}$ , which are disjoint and partition the space.

#### 3. Applications to Borel Chromatic numbers and matchings

We now show how our main lemma can be applied to prove the theorems discussed in the Introduction. Recall that if G and H are Borel graphs on the standard Borel spaces X and Y, respectively, then a Borel homomorphism from G to H is a Borel function  $f: X \to Y$  such that  $x \ G \ y$  implies  $f(x) \ H \ f(y)$ . It is clear that if there is a Borel homomorphism f from G to H, then  $\chi_B(G) \le \chi_B(H)$ ; if c is a Borel coloring of H, then  $c \circ f$  is a Borel coloring of G.

<span id="page-9-0"></span>**Theorem 3.1.** If  $\Gamma$  and  $\Delta$  are finitely generated marked groups, then

$$\chi_B(G(\Gamma * \Delta, \mathbb{N})) \ge \chi_B(G(\Gamma, \mathbb{N})) + \chi_B(G(\Delta, \mathbb{N})) - 1.$$

Proof. Suppose  $\chi_B(G(\Gamma,\mathbb{N}))=n+1$  and  $\chi_B(G(\Delta,\mathbb{N}))=m+1$  so that  $G(\Gamma,\mathbb{N})$  has no Borel n-coloring and  $G(\Delta,\mathbb{N})$  has no Borel m-coloring. Now suppose c: Free( $\mathbb{N}^{\Gamma*\Delta}$ )  $\to \{0,1,\ldots,(n+m-1)\}$  was a Borel n+m-coloring of  $G(\Gamma*\Delta,\mathbb{N})$  and let A be the set of x such that c(x) < n. If f is the continuous equivariant function produced by Lemma 2.1, then  $c \circ f$  gives either a Borel n-coloring of  $G(\Gamma,\mathbb{N})$  or a Borel m-coloring of  $G(\Delta,\mathbb{N})$ , both of which are contradictions.

Let  $\mathcal{C}$  be the class of finitely generated marked groups  $\Gamma$  such that  $G(\Gamma, \mathbb{N})$  is n-regular, and  $\chi_B(G(\Gamma, \mathbb{N})) = n+1$ , so that the upper bound on the Borel chromatic number of  $G(\Gamma, \mathbb{N})$  given by Theorem 1.1 is sharp. Brooks's theorem in finite graph theory (see, e.g., [9, Theorem 5.2.4]) implies that the finite groups included in  $\mathcal{C}$  are exactly those whose Cayley graphs are odd cycles or complete graphs on n vertices. The only prior results giving infinite groups in  $\mathcal{C}$  are from [16] where we have that  $\mathbb{Z}$  and  $\mathbb{Z}/2\mathbb{Z}*\mathbb{Z}/2\mathbb{Z}$  are in  $\mathcal{C}$  when equipped with their usual generators. Conley and Kechris [3, Theorem 0.10] have shown that these are the only two groups with finitely many ends that are in  $\mathcal{C}$ . Theorem 3.1 implies that  $\mathcal{C}$  is closed under free products; if  $G(\Gamma, \mathbb{N})$  is n-regular and  $G(\Delta, \mathbb{N})$  is m-regular, then  $G(\Gamma*\Delta, \mathbb{N})$  is n+m-regular. For example,  $\chi_B(G((\mathbb{Z}/2\mathbb{Z})^{*n}, \mathbb{N})) = n+1$ , and  $\chi_B(G(\mathbb{F}_n, \mathbb{N})) = 2n+1$  for all n.

Next, we will show that the Borel chromatic number of an n-regular acyclic Borel graph can take any of the possible values between 2 and n+1 allowed by Theorem 1.1.

We begin with an easy lemma.

<span id="page-9-1"></span>**Lemma 3.2.** Suppose G and H are acyclic Borel graphs on the standard Borel spaces X and Y, where  $\chi_B(G) \geq 2$ . Suppose also  $f: X \to Y$  is an injective Borel homomorphism from G to H such that  $\forall x, y \in X$ ; if x and y are in different connected components of G, then f(x) and f(y) are in different connected components of H. Then if  $A = [\operatorname{ran}(f)]_H$  is the saturation of the range of f under the connectedness relation of H, then  $\chi_B(G) = \chi_B(H \upharpoonright A)$ .

Proof.  $\chi_B(G) \leq \chi_B(H \upharpoonright A)$  since there is a Borel homomorphism from G to  $H \upharpoonright A$ . It remains to show that  $\chi_B(H \upharpoonright A) \leq \chi_B(G)$ . Suppose  $c \colon X \to Z$  is a Borel coloring of G. Fix two colors  $z_0$  and  $z_1 \in Z$ . Now we construct a Borel coloring  $c' \colon A \to Z$  of  $H \upharpoonright A$  as follows. If  $y \in \operatorname{ran}(f)$ , then let  $c'(y) = c(f^{-1}(y))$ . Otherwise, there is a unique path in H of shortest length l from p to an element  $p' \in \operatorname{ran}(f)$ . If  $c(f^{-1}(p')) = z_0$ , then let  $c(p) = z_1$  if p is odd and p if p is even. If p is even. p if p is even. p

We are ready to proceed.

<span id="page-10-0"></span>**Theorem 3.3.** For every  $n \ge 1$  and every  $m \in \{2, ..., n+1\}$ , there is a n-regular acyclic Borel graph G with  $\chi_B(G) = m$ .

*Proof.* We have shown that for every  $k \geq 2$  we have  $\chi_B(G((\mathbb{Z}/2\mathbb{Z})^{*k}, \mathbb{N})) = k+1$ . Given  $m \in \{2, ..., n+1\}$ , canonically identify  $(\mathbb{Z}/2\mathbb{Z})^{*(m-1)}$  with a subgroup of  $(\mathbb{Z}/2\mathbb{Z})^{*n}$ . Now let  $f \colon \operatorname{Free}(\mathbb{N}^{(\mathbb{Z}/2\mathbb{Z})^{*(m-1)}}) \to \operatorname{Free}(\mathbb{N}^{(\mathbb{Z}/2\mathbb{Z})^{*n}})$  be the function where

$$f(x)(\gamma) = \begin{cases} x(\gamma) & \text{if } \gamma \in (\mathbb{Z}/2\mathbb{Z})^{*(m-1)} \\ 0 & \text{otherwise.} \end{cases}$$

We finish by applying Lemma 3.2 with  $G = G((\mathbb{Z}/2\mathbb{Z})^{*(m-1)}, \mathbb{N}), H = G((\mathbb{Z}/2\mathbb{Z})^{*n}, \mathbb{N})$  and f as above to obtain a Borel set A saturated under the connectedness relation of H so  $H \upharpoonright A$  is n-regular and  $\chi_B(H \upharpoonright A) = m$ .

The only case we know of where Theorem 3.1 gives a sharp lower bound for the chromatic number of  $G(\Gamma * \Delta, \mathbb{N})$  is when  $\Gamma$  and  $\Delta$  are in the class  $\mathcal{C}$  we have discussed above. However, it is open whether the lower bound of Theorem 3.1 can ever be exceeded.

<span id="page-10-2"></span>**Question 3.4.** Are there finitely generated marked groups  $\Gamma$  and  $\Delta$  such that  $\chi_B(G(\Gamma * \Delta, \mathbb{N})) > \chi_B(G(\Gamma, \mathbb{N})) + \chi_B(G(\Delta, \mathbb{N})) - 1$ ?

Now there is another obvious upper bound on the Borel chromatic number of  $G(\Gamma * \Delta, \mathbb{N})$  which is better in some cases than that of Theorem 1.1.

<span id="page-10-4"></span>**Proposition 3.5.** If  $\Gamma$  and  $\Delta$  are finitely generated marked groups, then  $\chi_B(G(\Gamma * \Delta, \mathbb{N})) \leq \chi_B(G(\Gamma, \mathbb{N}))\chi_B(G(\Delta, \mathbb{N}))$ .

*Proof.* We can decompose  $G(\Gamma * \Delta, X)$  as the disjoint union of two Borel graphs  $G_{\Gamma}$  and  $G_{\Delta}$  given by the edges corresponding to generators of  $\Gamma$  and  $\Delta$ , respectively. Since  $G_{\Gamma}$  and  $G_{\Delta}$  are induced by free actions of  $\Gamma$  and  $\Delta$ , their Borel chromatic numbers are less than or equal to  $\chi_B(G(\Gamma, \mathbb{N}))$  and  $\chi_B(G(\Delta, \mathbb{N}))$  and hence we can use pairs of these colors to color  $G(\Gamma * \Delta, \mathbb{N})$ .

It is likewise open whether this upper bound can ever be achieved.

<span id="page-10-3"></span>**Question 3.6.** Are there nontrivial finitely generated marked groups  $\Gamma$  and  $\Delta$  such that  $\chi_B(G(\Gamma * \Delta, \mathbb{N})) = \chi_B(G(\Gamma, \mathbb{N}))\chi_B(G(\Delta, \mathbb{N}))$ ?

A positive answer to this question would also give a positive answer to Question 3.4. It seems natural to believe Question 3.6 has a positive answer in cases where  $G(\Gamma*\Delta,\mathbb{N})$  is n-regular and  $\chi_B(G(\Gamma,\mathbb{N}))\chi_B(G(\Delta,\mathbb{N})) \leq n$ , so that the bound of Proposition 3.5 is better than that of Theorem 1.1. For example, if m>2 is even, and we generate  $\mathbb{Z}/m\mathbb{Z}$  by a single element, then  $G(\mathbb{Z}/m\mathbb{Z}*\mathbb{Z}/m\mathbb{Z},\mathbb{N})$  is 4-regular and has Borel chromatic number  $\leq 4$  by Proposition 3.5. Likewise,  $\mathbb{Z}^n$  is another source of such examples, since  $G(\mathbb{Z}^n,\mathbb{N})$  is a 2n-regular Borel graph with  $\chi_B(G(\mathbb{Z}^n,\mathbb{N})) \leq 4$  by [13].

Next, we turn to matchings and edge colorings. We begin with the following theorem on disjoint complete sections.

<span id="page-10-1"></span>**Theorem 3.7.** Let  $\Gamma$  and  $\Delta$  be countable groups. Let  $E_{\Gamma}$  be the equivalence relation on Free( $\mathbb{N}^{\Gamma*\Delta}$ ) where  $x \ E_{\Gamma}$  y if there exists a  $\gamma \in \Gamma$  such that  $\gamma \cdot x = y$ . Define  $E_{\Delta}$  analogously. Then  $E_{\Gamma}$  and  $E_{\Delta}$  do not have Borel disjoint complete sections.

*Proof.* Let A be any Borel subset of Free( $\mathbb{N}^{\Gamma*\Delta}$ ). Then the range of the f produced by Lemma 2.1 is either an  $E_{\Gamma}$ -invariant set contained in A or an  $E_{\Delta}$ -invariant set contained in the complement of A. Hence, A cannot simultaneously meet every  $E_{\Delta}$  class and have its complement meet every  $E_{\Gamma}$ -class.

We now use this fact to obtain a couple of results on matchings and edge colorings of Borel bipartite graphs.

<span id="page-11-1"></span>**Theorem 3.8.** For every n > 1, there exists an n-regular acyclic Borel bipartite graph with no Borel perfect matching.

*Proof.* Let  $\Gamma = \Delta = \mathbb{Z}/n\mathbb{Z}$  in Theorem 3.7. Let  $Y \subseteq [\operatorname{Free}(\mathbb{N}^{\Gamma * \Delta})]^n$  be the standard Borel space consisting of the equivalence classes of  $E_{\Gamma}$  and  $E_{\Delta}$ . Let G be the intersection graph on Y. This is an n-regular acyclic Borel bipartite graph. If  $M \subseteq Y \times Y$  was a Borel perfect matching for G, then setting

$$A = \{x \in \mathbb{N}^{\Gamma * \Delta} : \exists (R, S) \in M \text{ such that } \{x\} = R \cap S\},\$$

we see that A and the complement of A would be Borel disjoint complete sections for  $E_{\Gamma}$  and  $E_{\Delta}$ , contradicting Theorem 3.7.

The graph used above was suggested as a candidate for a graph with no perfect matching by Conley and Kechris [3]. Lyons and Nazarov [20] have shown that in the case n=3, this graph has a measurable matching with respect to a natural measure.

<span id="page-11-2"></span>**Theorem 3.9.** For every n, there exists an n-regular acyclic Borel bipartite graph with no Borel edge coloring with 2n-2 colors.

*Proof.* We use the same graph as in Theorem 3.8. Suppose for a contradiction that it had a Borel edge coloring with 2n-2 colors. By the pigeonhole principle, each vertex of G must be incident to at least one edge assigned an even color, and at least one edge assigned an odd color. Let A be the set of points x in  $\operatorname{Free}(\mathbb{N}^{\Gamma*\Delta})$  such that  $\{x\} = R \cap S$  where R is an equivalence class of  $E_{\Gamma}$ , S is an equivalence class of  $E_{\Delta}$ , and the edge (R,S) in G is colored with an even color. Then A is a complete section for  $E_{\Gamma}$ , and the complement of A is a complete section for  $E_{\Delta}$ , contradicting Theorem 3.7.

Now we can give an exact characterization of the possible Borel edge chromatic numbers of n-regular acyclic Borel bipartite graphs.

<span id="page-11-0"></span>**Theorem 3.10.** For every  $n \geq 1$  and every  $m \in \{n, \ldots, 2n-1\}$ , there is an n-regular acyclic Borel bipartite graph G such that  $\chi'_B(G) = m$ .

Proof. Let G be an n-regular acyclic Borel graph on X with  $\chi'(G) \geq 2n-1$  by Theorem 3.9. Let m be an element of  $\{n,\ldots,2n-1\}$ . There is an edge coloring of G using 2n-1 colors by Theorem 1.1 and our discussion in the Introduction before Theorem 1.4. Let  $G' \subseteq G$  be the set of edges colored using one of the first m colors. Then clearly the graph G' on X has a Borel edge coloring with m colors. It cannot have a Borel edge coloring with m-1 colors as this would give an edge coloring of G with 2n-2 colors. Now let Y be an uncountable standard Borel space, and let H be an extension of G' to an n-regular Borel bipartite graph H on  $X \sqcup Y$  such that each connected component of  $H \setminus G'$  has at most one point in X. Then  $\chi'_B(H) = m$ .

In the theorems we have proved above, we have mostly worked on spaces of the form  $\operatorname{Free}(\mathbb{N}^{\Gamma})$ . As we described in the Introduction, this is quite natural since the graph  $G(\Gamma,\mathbb{N})$  achieves the maximal chromatic number of all Borel graphs generated by free actions of  $\Gamma$ . However, it is interesting to ask what happens when we change our base space to be finite. For example, it is an open question whether there is a dichotomy characterizing when a pair of countable Borel equivalence relations admits Borel disjoint complete sections, and here we would like to know whether Theorem 3.7 remains true when we change  $\mathbb N$  to be some finite k. As we will see, this is the case when k=3, but it is open for k=2. Likewise, we would like to compute the Borel chromatic number of graphs of the form  $G(\Gamma,k)$  for  $k\geq 2$ . Clearly, if  $k\leq m$  are both at least 2, then  $\chi_B(G(\Gamma,k))\leq \chi_B(G(\Gamma,m))\leq \chi_B(G(\Gamma,\mathbb N))$ . It is open whether these chromatic numbers can ever be different.

**Question 3.11.** Does there exist a finitely generated marked group  $\Gamma$  such that  $\chi_B(G(\Gamma, \mathbb{N})) \neq \chi_B(G(\Gamma, 2))$ ?

Certainly, there are no obvious tools to show such chromatic numbers can be different. One approach to showing that these chromatic numbers are always the same would be to show the existence of a Borel homomorphism from  $G(\Gamma, \mathbb{N})$  to  $G(\Gamma, 2)$ . To do this it would be sufficient to find an equivariant Borel function from  $\operatorname{Free}(\mathbb{N}^{\Gamma})$  to  $\operatorname{Free}(2^{\Gamma})$ . We note that such a function could not be injective in the case when  $\Gamma$  is sofic (which includes all the examples of groups we have discussed). This follows from results of Bowen on sofic entropy, as pointed out by Thomas [25, Theorem 6.11].

In the measurable context, when  $(X,\mu)$  is a standard probability space, we can say a bit more about the  $\mu^{\Gamma}$ -measurable chromatic number of graphs of the form  $G(\Gamma,X)$ , as X and  $\mu$  vary. Recall from [3] that the  $\mu$ -measurable chromatic number of a Borel graph G on a standard probability space  $(X,\mu)$  is the least cardinality of a Polish space Y such that there is a  $\mu$ -measurable coloring  $c:X\to Y$  of G. Now given Borel actions a and b of  $\Gamma$  on the Borel probability spaces  $(X,\mu)$  and  $(Y,\nu)$ , respectively, a factor map from a to b is a  $\mu$ -measurable equivariant function  $f:X\to Y$  such that the pushforward of  $\mu$  under f is  $\nu$ . Bowen [1, Theorem 1.1] has shown that if  $\Gamma$  contains a nonabelian free subgroup, then given any nontrivial probability measures  $\mu$  and  $\nu$  on the standard Borel spaces X and Y, there is a factor map from the left shift action of  $\Gamma$  on  $(X^{\Gamma},\mu^{\Gamma})$  to the left shift action of  $\Gamma$  on  $(Y^{\Gamma},\nu^{\Gamma})$ . Hence, the  $\mu^{\Gamma}$ -measurable chromatic number of  $G(\Gamma,X)$  is equal to the  $\nu^{\Gamma}$ -measurable chromatic number of  $G(\Gamma,X)$  for all such  $(X,\mu)$  and  $(Y,\nu)$ . For some more results of this type for nonamenable groups in general, see [2].

We now return to the pure Borel context and end this section by noting that we have the following variant of Lemma 2.1 for finite base spaces. This lemma can be proved using a nearly identical argument to that of Lemma 2.1 except changing the application of the pigeon-hole principle in the obvious way. From this, one can derive versions of all of the Theorems above for finite base spaces. For example, we have  $\chi_B(G(\Gamma*\Delta,m+n-1)) \geq \chi_B(G(\Gamma,m)) + \chi_B(G(\Delta,n)) - 1$ , and Theorem 3.7 and its corollaries hold using 3 instead of  $\mathbb N$ .

<span id="page-12-0"></span><sup>&</sup>lt;sup>1</sup>Recently, Seward and Tucker-Drob [24] have answered this question in the negative. They show that for every countable group  $\Gamma$ , there is an equivariant Borel function from  $\operatorname{Free}(\mathbb{N}^{\Gamma}) \to \operatorname{Free}(2^{\Gamma})$ .

**Lemma 3.12.** Let Γ, Δ be countable groups and m, n ≥ 2 be finite. If A ⊆ Free((m + n − 1)Γ∗Δ) is any Borel set, then at least one of the following holds:

- (1) There is a continuous injective function f : Free(nΓ) → Free((m+n−1)Γ∗Δ) that is equivariant with respect to the left shift action of Γ on these spaces and such that ran(f) ⊆ A.
- (2) There is a continuous injective function f : Free(mΔ) → Free((m + n − 1)Γ∗Δ) that is equivariant with respect to the left shift action of Δ on these spaces and such that ran(f) ⊆ Ac.

# 4. Disjoint complete sections for measure and category

We turn now to the question of whether Theorem [3.7](#page-10-1) can be proved using purely measure theory or Baire category. In the case when Γ = Δ = Z/2Z, we can prove Theorem [3.7](#page-10-1) using either of these two tools. If the generators of Γ and Δ are α and β, then any nontrivial product probability measure on Free(N(Z/2Z)∗(Z/2Z)) has the property that the map x → αβ·x is ergodic, and the two maps x → α·x and x → β·x are both measure preserving. This is enough to conclude the Theorem [3.7](#page-10-1) in this case. We can similarly give a Baire category argument using generic ergodicity. We will show that Γ = Δ = Z/2Z is the only nontrivial pair of Γ and Δ for which measure or category can prove Theorem [3.7.](#page-10-1)

We begin by showing that Borel disjoint complete sections exist in the measure context for aperiodic countable Borel equivalence relations. Recall that an equivalence relation is said to be aperiodic if all of its equivalence classes are infinite.

<span id="page-13-0"></span>**Lemma 4.1.** Let μ be a Borel probability measure on a standard Borel space X. Then if E and F are aperiodic countable Borel equivalence relations on X, there exist disjoint Borel sets A and B such that A meets μ-a.e. equivalence class of E and B meets μ-a.e. equivalence class of F.

Proof. It follows from the marker lemma [\[18,](#page-21-12) Lemma 6.7] that we can find a decreasing sequence C<sup>0</sup> ⊇ C<sup>1</sup> ⊇ ... of Borel sets that are each complete sections for both E and F and such that their intersection C<sup>i</sup> is empty.

Note that for each n and > 0, there is i>n such that

$$\mu([C_n \setminus C_i]_E) > 1 - \epsilon \text{ and } \mu([C_n \setminus C_i]_F) > 1 - \epsilon.$$

It follows that we can find a strictly increasing sequence (ik)<sup>k</sup> such that

$$\mu([\bigcup_{k\geq 0} (C_{i_{2k}} \setminus C_{i_{2k+1}})]_E) = 1 \text{ and } \mu([\bigcup_{k\geq 0} (C_{i_{2k+1}} \setminus C_{i_{2k+2}})]_F) = 1.$$

Now set 
$$A = \bigcup_{k \geq 0} (C_{i_{2k}} \setminus C_{i_{2k+1}})$$
 and  $B = \bigcup_{k \geq 0} (C_{i_{2k+1}} \setminus C_{i_{2k+2}}).$ 

Our goal is to extend this result to all pairs of countable Borel equivalence relations E and F where every E class has at least 2 elements and every F-class has at least 3 elements. We will do this by reducing it to the case we have already proved above. More precisely, in Theorem [4.5](#page-15-0) we will show that several types of problems are equivalent in a Borel way to the problem of finding Borel disjoint complete sections for pairs of such equivalence relations. That is, to each instance of each type of problem, we will demonstrate how to construct an instance of each of the other types so that a solution to these problems can be transformed in a Borel way into a solution of the original problem. The exact sense in which this is done will be clear in our proof. Of course, the idea of reductions between combinatorial problems has a long history. For an example of recent work with a similar effective flavor, see [\[10\]](#page-21-17).

We first introduce another combinatorial problem. If G is a graph on X, an antimatching of G is a function f : X → X such that for all x ∈ X, we have xGf(x) and f(f(x)) = x. A partial antimatching of G is a partial function f : X → X satisfying these conditions for all x ∈ dom(f).

We have the following lemma constructing antimatchings in the topological context, using a result of Conley and Miller on the existence of Borel matchings in the topological context.

<span id="page-14-0"></span>**Lemma 4.2.** Suppose n ≥ 3 and G is an acyclic Borel bipartite n-regular graph on a Polish space X. Then there exists a Borel antimatching of G modulo a Ginvariant meager set.

Proof. By [\[5\]](#page-21-18), there exists a Borel perfect matching for G restricted to a G-invariant meager set C. Let A be one half of a Borel partition of X witnessing the bipartiteness of G, and let M be the Borel perfect matching of G C. Then we can construct a Borel antimatching f for G C in the following way: if x ∈ A and {x, y} ∈ M, then set f(x) = y. If x /∈ A, then choose some neighbor y of x such that {x, y} ∈/ M and set f(x) = y. -

The following lemma is useful when dealing with Borel antimatchings.

<span id="page-14-1"></span>**Lemma 4.3.** Suppose G is a locally countable Borel graph, and f is a partial Borel antimatching of G such that ran(f) ⊆ dom(f), and every connected component of G contains some x ∈ dom(f). Then f can be extended to a total Borel antimatching f <sup>∗</sup> of G.

Proof. Define f <sup>∗</sup> as follows. Let f <sup>∗</sup>(x) = f(x) if x ∈ dom(f). Otherwise, let f <sup>∗</sup>(x) = y, for some neighbor y of x such that the distance in G from y to an element of dom(f) is as small as possible (using Lusin-Novikov uniformization [\[17,](#page-21-11) 18.10, 18.15] to choose such a y when there is more than one). Then clearly f <sup>∗</sup>(f <sup>∗</sup>(x)) = x since for any x /∈ dom(f), we have that f <sup>∗</sup>(x) is closer to some element of dom(f) than x. -

Throughout this section, we assume that we have a Borel linear order on all our standard Borel spaces. Thus, when we speak of the least element of some finite subset of a standard Borel space, we are referring to the least element with respect to this order. One way of obtaining such a linear order is via a Borel bijection with a standard Borel space equipped with a canonical Borel linear ordering, such as the one on R. These linear orderings are useful when we need to break "ties" in our constructions when we are faced with some irrelevant choice. In cases where we need to choose one of finitely many points, we will generally break ties by choosing the least point according to this ordering. In cases where we need to choose one of countably many options, we can use uniformization as we have above.

<span id="page-14-2"></span>**Lemma 4.4.** If G is an acyclic locally finite Borel graph of degree ≥ 2, then there is a partial Borel antimatching f of G such that G (dom(f))<sup>c</sup> is 2-regular.

Proof. Let G be a locally finite Borel graph of degree ≥ 2 on a standard Borel space X. Using Lemma [2.2,](#page-8-1) let {Ai}i∈<sup>N</sup> be a Borel partition of X such that for all i, for all distinct x, y ∈ Ai, the distance between x and y in G is greater than 2.

Let  $k_0, k_1, \ldots$  be a sequence containing each natural number infinitely many times. We define a sequence  $f_0 \subseteq f_1 \subseteq \ldots$  of partial Borel antimatchings whose union will be the f we desire. These  $f_i$  will all have the property that if  $x \in \operatorname{ran}(f_i)$  and  $x \notin \operatorname{dom}(f_i)$ , then there exist exactly two neighbors y of x such that  $y \notin \operatorname{dom}(f_i)$  or  $f_i(y) \neq x$ .

Let  $f_0 = \emptyset$ . Now we define  $f_{i+1} \supseteq f_i$ . For each  $x \in A_{k_i}$  such that  $x \notin \text{dom}(f_i)$ , do the following: if there exists some neighbor y of x such that  $y \in \text{dom}(f_i)$  and  $f_i(y) \neq x$ , then use uniformization to choose some such y and define  $f_{i+1}(x) = y$ . If there does not exist any such y and  $x \notin \text{ran}(f_i)$ , then choose exactly two neighbors  $y_1$  and  $y_2$  of x and define  $f_{i+1}(y) = x$  for all neighbors y of x that are not equal to  $y_1$  or  $y_2$ .

Let  $f = \bigcup_{i \in \mathbb{N}} f_i$ . Now if  $x \notin \text{dom}(f)$ , there are exactly two neighbors y of x such that  $y \notin \text{dom}(f)$  or  $f(y) \neq x$ . However, if x had a neighbor y such that  $f(y) \neq x$ , then we would have  $x \in \text{dom}(f)$ . Hence, both these two y must not be in dom(f). Thus,  $G \upharpoonright (\text{dom}(f))^c$  is 2-regular.

We are now ready to proceed.

<span id="page-15-0"></span>**Theorem 4.5.** Suppose  $n \geq 3$ . Then the following statements are all false. However, the statements are all true modulo a null set with respect to any Borel probability measure, and true modulo a meager set with respect to any compatible Polish topology.

- (1) Every pair E and F of countable Borel equivalence relations on a standard Borel space X such that the E-classes all have cardinality  $\geq 3$  and the F-classes all have cardinality  $\geq 2$  admits disjoint Borel complete sections.
- (2) Every pair E and F of independent aperiodic countable Borel equivalence relations admits disjoint Borel complete sections.
- (3) Every locally finite Borel graph G having degree at least 3 has a Borel antimatching.
- (4) Every acyclic Borel bipartite n-regular graph G has a Borel antimatching.

*Proof.* (1) is false by Theorem 3.7. (2) is true in the measure-theoretic context by Lemma 4.1. (4) is true in the topological context by Lemma 4.2.

We will finish the proof of the theorem by showing  $(1) \Rightarrow (2) \Rightarrow (3) \Rightarrow (1)$ , and  $(3) \Rightarrow (4) \Rightarrow (2)$ . Further, each of these implications will be done in a "local" way so that these implications also yield the truth of these statements in the measure and category contexts. We will discuss this more in what follows.

- $(1) \Rightarrow (2)$  is obvious.
- $(2)\Rightarrow (3)$ . Let X be a standard Borel space. We will begin by proving the special case where G is a 3-regular acyclic Borel graph on  $\{0,1\}\times X$  where (0,x) G (1,y) if and only if x=y. For  $i\in\{0,1\}$ , let  $F_i$  be the equivalence relation on X such that x  $F_i$  y if and only if (i,x) and (i,y) are in the same connected component of  $G\upharpoonright\{i\}\times X$ . The  $F_i$  are independent because G is acyclic. Let  $B\subseteq X$  be a Borel set such that B is a complete section for  $F_0$  and  $B^c$  is a complete section for  $F_1$ . We can use B to define a Borel antimatching. The rough idea is to direct elements of  $\{0\}\times X$  toward elements of B and direct elements of  $\{1\}\times X$  away from elements of B.

If  $x \in B$ , define f((0,x)) = (1,x). Then let z be a point of  $B^c$  such that (1,z) is closest to (1,x) in  $G \upharpoonright \{1\} \times X$  (breaking ties as usual), and define f((1,x)) = (1,y) where (1,y) is the neighbor of (1,x) along the path from (1,x) to (1,z). Likewise,

if x ∈ Bc, define f((1, x)) = (0, x), let z be a point of B such that (0, z) is closest to (0, x) in G {0} × X, and define f((0, x)) = (0, y) where (0, y) is the neighbor of (0, x) along the path from (0, x) to (0, z).

Now let G be an arbitrary locally finite Borel graph on X having degree at least 3. First, we may assume that G is acyclic. To see this, use Lemma [2.2](#page-8-1) to obtain a Borel set C of pairwise disjoint cycles that contains at least one cycle from each connected component of G containing a cycle. Now define a Borel antimatching f on these connected components as follows. For each cycle x0, x1,...,x<sup>n</sup> = x<sup>0</sup> in C, let f(xi) = xi+1 for i<n, and f(xn) = x0. Now use Lemma [4.3](#page-14-1) to extend f to a total Borel antimatching f <sup>∗</sup> on these connected components.

So assume that G is acyclic. By Lemma [4.4,](#page-14-2) we can find a partial Borel antimatching of G such that G (dom(f))<sup>c</sup> is 2-regular. Let A = (dom(f))<sup>c</sup> . Now take a Borel set of edges of G A that are pairwise disjoint and so that the set contains at least one edge from each connected component of G A. Remove these edges from G to obtain the Borel graph G on X. Now using Lemma [4.4](#page-14-2) on G , we may obtain another set B ⊆ X that is the complement of a partial Borel antimatching on G such that G B is 2-regular. Note that G A and G B do not have any connected components that are equal.

Now these A and B correspond to places where we have failed to construct antimatchings. Hence, without loss of generality, we may assume that each connected component of G meets both A and B. By Lemma [2.2,](#page-8-1) let C be a Borel set of pairwise disjoint finite paths in G from elements of A to elements of B that contains at least one path from every connected component of G. We may assume that if x0,...,x<sup>n</sup> is a path in C, then x<sup>0</sup> is the only point of this path in A, and x<sup>n</sup> is the only point of this path in B. (We allow paths consisting of a single point where A and B intersect.) Thus, each pair of connected components of G A and G B are connected by at most one path in C, since G is acyclic.

Let S ⊆ X consist of the connected components of G A that meet only finitely many paths in C. Since this set has a Borel transversal, we can obtain a Borel antimatching of G S. We can then use Lemma [4.3](#page-14-1) to extend this to a Borel antimatching of the connected components of G that meet S. An identical comment is true for B. Thus, without loss of generality, we can assume that for each connected component of G A and G B, if there is a path in C that meets this connected component, then there are infinitely many.

Let Y be the collection of starting points of paths in C, and Z be the collection of ending points of paths in C, so there is a canonical Borel bijection between Y and Z. Note that Y and Z may have nonempty intersection. Define W = {0} × Y ∪ {1} × Z. Consider the 3-regular Borel graph H on W, defined by the following three conditions. First, (0, x) H (1, y) if and only if there is a path in C from x to y. Second, (0, x) H (0, y) if and only if there is a path from x to y in G A that does not contain any other element of Y . Third, (1, x) H (1, y) if and only if there is a path from x to y in G B that does not contain any other element of Z. H is 3-regular since connected components of G A and G B that are met by paths in C are met by infinitely many such paths.

H is a graph of the type we discussed at the beginning of this proof, and hence we can find a Borel antimatching of H. Let A<sup>∗</sup> ⊆ A be the points that are in the same connected component of G A as some element of Y . Let B<sup>∗</sup> ⊆ B be the points that are in the same connected component of G B as some element of Z. It is clear that we can lift the Borel antimatching of H to a partial Borel antimatching f of G whose domain is A<sup>∗</sup> ∪ B<sup>∗</sup> ∪ {x : ∃p ∈ C(x ∈ p)}, and such that ran(f) ⊆ dom(f). We finish by applying Lemma [4.3.](#page-14-1)

Our proof above has shown that (2) ⇒ (3). We now show that assuming that (2) is true modulo a null set with respect to every Borel probability measure implies that (3) is true modulo a null set with respect to every Borel probability measure.

Assume G is a locally finite Borel graph on X and μ is a Borel probability measure on X. Let E<sup>G</sup> be the connectedness relation for G. We can find a Borel probability measure ν which dominates μ and such that ν is EG-quasi-invariant [\[18,](#page-21-12) Section 8]. Now perform the same process as above to obtain a pair of equivalence relations E and F on some Borel subset Y of X, such that from Borel disjoint complete sections for E and F, we can define a Borel antimatching of G.

Now this transformation of disjoint complete sections for E and F into an antimatching of G is "local" in the sense that inside each connected component C of G, we have a Borel way of transforming disjoint complete sections for E Y ∩ C and F Y ∩ C into an antimatching of G C. Hence, given disjoint Borel sets A and B such that A meets ν-a.e. E-class and B meets ν-.a.e. F-class, we can find a Borel antimatching of G restricted to a Borel ν-conull set, since ν is EG-quasi-invariant.

Throughout the remainder of this proof, the same idea as above can be used to turn pure Borel implications between our four statements into implications in the measure context, and in the Baire category context. We leave it to the reader to perform the rest of these transformations.

(3) ⇒ (1) Let E and F be countable Borel equivalence relations such that every E-class has cardinality ≥ 3 and every F class has cardinality ≥ 2. By [\[18,](#page-21-12) Proposition 7.4], there exist Borel equivalence relations E<sup>∗</sup> ⊆ E and F<sup>∗</sup> ⊆ F such that every E∗-class is finite and has cardinality ≥ 3 and every F∗-class is finite and has cardinality ≥ 2. Hence, we may assume that all the equivalence classes of E and F are finite. Let Y Z be the disjoint union of the equivalence classes of E and the equivalence classes of F, respectively. Let G be the graph on Y Z where R and S are adjacent in G if R ∈ Y , S ∈ Z, and R ∩ S = ∅.

Now let W be an uncountable standard Borel space, and extend G to a locally finite Borel graph G<sup>∗</sup> on Y Z W so that every vertex in Y W has degree ≥ 3 in G∗, so that every vertex in Z has degree ≥ 2 in G∗, and such that R ∈ Y Z is adjacent to an element of W in G<sup>∗</sup> if and only if R ∈ Y , the degree of R is < 3 in G or R ∈ Z, and the degree of R is < 2 in G. Note that for such R there must be S ∈ Y Z distinct from R such that R ∩ S has cardinality ≥ 2.

Now let f be a Borel antimatching of G∗. Of course, G<sup>∗</sup> does not have degree ≥ 3. However, the neighbors of every degree 2 vertex in G<sup>∗</sup> all have degree ≥ 3. Hence, we can contract away vertices of degree 2, find a Borel antimatching of this graph, and then use it in the obvious way to find a Borel antimatching of G∗.

Let A<sup>0</sup> be the set of x ∈ X such that there exists R ∈ Y such that f(R) ∈ Z and R ∩ f(R) = {x}. Let A<sup>1</sup> be the Borel set of x ∈ X such that there exists an R ∈ Y and S ∈ Z such that R ∩ S has cardinality ≥ 2, and x is the least element of R ∩ S. Let A = A<sup>0</sup> ∪ A1. Clearly A meets every equivalence class of E, and A<sup>c</sup> meets every equivalence class of F.

- (3) ⇒ (4) is obvious.
- (4) ⇒ (2). Suppose we have two independent aperiodic countable Borel equivalence relations E and F on a standard Borel space X. By [\[18,](#page-21-12) Proposition 7.4] we

can find  $E^*$  and  $F^*$ , finite Borel subequivalence relations of E and F whose equivalence classes all have cardinality n. The intersection graph of their equivalence classes is Borel bipartite and n-regular. From a Borel antimatching for this graph, we can produce Borel disjoint complete sections for E and F, as in the proof that  $(3) \Rightarrow (1)$ .

Our final goal will be to prove a theorem about edge colorings for 3-regular acyclic Borel bipartite graphs in the context of measure and category. This will follow from several more equivalences extending those of Theorem 4.5 above.

We begin with another definition. Suppose G is a graph on X. A directing of G is a set  $D \subseteq G$  that contains exactly one of (x,y) and (y,x) for every pair of neighbors  $x,y \in X$ . A partial directing of G is a subset of G that contains at most one of (x,y) and (y,x) for every pair of neighbors  $x,y \in X$ . Given a partial directing D of a graph G, say that a point  $x \in X$  is a source if  $(x,y) \in D$  for some y, and  $(y,x) \notin D$  for all y. Similarly, say that a point  $x \in X$  is a sink if  $(y,x) \in D$  for some y, and  $(x,y) \notin D$  for all y. Of course, if f is an antimatching of a graph G and we extend the set  $\{(x,f(x)): x \in X\}$  to a directing D of G, then this directing will have no sinks.

<span id="page-18-1"></span>**Lemma 4.6.** Suppose that G is a locally countable Borel graph such that each vertex of G has degree  $\geq 2$ , and D is a partial Borel directing of G without sources or sinks. Suppose also that every connected component of G contains at least one vertex that is incident to an edge of D. Then D can be extended to a total Borel directing  $D^*$  of G that has no sources or sinks.

*Proof.* Suppose that  $x_0, x_1, \ldots, x_n$  is a path in G such that  $x_0$  and  $x_n$  are both incident to edges already in D. Then we can extend D by adding the edges from  $x_0, x_1, \ldots, x_n$  that do not conflict with edges already in D; add  $(x_i, x_{i+1})$  to D unless  $(x_{i+1}, x_i)$  is already in D. The property that D has no sources or sinks is preserved when we add paths in this way. Similarly, given a cycle, we can extend D using this cycle in the analogous way, while preserving the property that D has no sources or sinks.

Use Lemma 2.2 to partition all the finite paths and cycles of G into countably many Borel sets  $\{P_i\}_{i\in\mathbb{N}}$  such that the elements of each  $P_i$  are pairwise disjoint. Let  $k_0,k_1,\ldots$  be a sequence that contains each element of  $\mathbb{N}$  infinitely many times. Let  $D_0=D$ . Now define  $D_{i+1}$  from  $D_i$  by extending  $D_i$  via all the cycles of  $P_{k_i}$ , and all the paths of  $P_{k_i}$  that start and end at vertices incident to at least one edge in  $D_i$ . Let  $D_{\infty}=\bigcup_{i\in\mathbb{N}}D_i$ .

Let A be the set of vertices that are incident to at least one edge in  $D_{\infty}$ . It is clear that if  $x_0 \in A$  and  $x_0, x_1, \ldots, x_n$  is a path in G, then  $x_n \in A$  implies that  $x_i \in A$  for all  $0 \le i \le n$ .

We finish by extending  $D_{\infty}$  to  $D^*$  by directing the remaining edges of G "away" from  $D_{\infty}$ . More precisely, let x and y be distinct elements of X and suppose that neither (x,y) nor (y,x) are in  $D_{\infty}$ . Then there must be a unique path  $x_0,\ldots,x_n$  such that  $x_0$  is incident to an edge in  $D_{\infty}$ , and the path ends with  $(x_{n-1},x_n)$  equal to (y,x) or (x,y). Extend  $D_{\infty}$  to  $D^*$  by adding all such  $(x_{n-1},x_n)$ .

<span id="page-18-0"></span>**Theorem 4.7.** The fallowing statements are all false in the full Borel context. They are true modulo a null set with respect to any Borel probability measure, and true modulo a meager set with respect to any compatible Polish topology.

- (1) Every pair of countable Borel equivalence relations E and F on a standard Borel space X such that the E-classes all have cardinality  $\geq 3$  and the F-classes all have cardinality  $\geq 2$  admits disjoint Borel complete sections.
- (2) For every pair of aperiodic countable Borel equivalence relations E and F on a standard Borel space X, there exists a Borel set  $B \subseteq X$  such that B and  $B^c$  are complete sections for both E and F.
- (3) Every 3-regular Borel graph has a directing with no sinks or sources.
- (4) Every 3-regular Borel bipartite graph has a Borel edge coloring with 4 colors.
- *Proof.* (1) is false by Theorem 3.7 and true in the measure and category context by Theorem 4.5. We will use the same type of proof as Theorem 4.5.
- $(1) \Rightarrow (2)$ . Since E and F are aperiodic, the argument that  $(3) \Rightarrow (1)$  in Theorem 4.5 produces subequivalence relations  $E^*$  and  $F^*$  of E and F with finite classes, and a Borel set A such that A and  $A^c$  are complete sections for  $E^*$ , and  $A^c$  is a complete section for  $F^*$ . Hence, A meets every E-class, and  $A^c$  meets every E-class and every F-class in infinitely many places. Thus, if we run the same argument on the aperiodic equivalence relations  $E \upharpoonright A^c$  and  $F \upharpoonright A^c$  with their roles reversed, we obtain a Borel set  $A' \subseteq A^c$  such that A' meets every  $F \upharpoonright A^c$ -class, and  $(A')^c$  meets both every  $E \upharpoonright A^c$ -class and every  $F \upharpoonright A^c$ -class. Now let  $B = A \cup A'$ .
  - $(2) \Rightarrow (1)$  follows from Theorem 4.5.
- $(2) \Rightarrow (3)$ . Let G be a 3-regular Borel graph. Using Lemma 4.6, we may assume that G is acyclic, as in the proof of  $(2) \Rightarrow (3)$  for Theorem 4.5.

We begin by letting  $Y \subseteq [X]^2$  be a Borel set of pairwise disjoint edges of G that contains at least one edge from each connected component of G. We define two countable Borel equivalence relations E and F on Y as follows: R and S are related by E if their least points are connected in  $G \setminus Y$ , and related by F if their greatest points are connected in  $G \setminus Y$ . Here we use  $G \setminus Y$  to denote the graph G with the edges from Y removed.

We may assume that all the equivalence classes of E and F are infinite; on the connected components of  $G \setminus Y$  that correspond to equivalence classes of E and F that are finite, we can apply Lemma 4.6 to get a directing of the connected components of G containing points corresponding to finite E-classes or F-classes.

Now let  $B \subseteq Y$  be a Borel set such that both B and  $B^c$  are complete sections for E and F. Let  $D_0 = \{(x,y) : \{x,y\} \in B \text{ and } x \text{ is less than } y\}$ . Each connected component of  $G \setminus Y$  contains infinitely many x such that  $(x,y) \in D_0$  for some y, and infinitely many y such that  $(x,y) \in D_0$  for some x. We will extend  $D_0$  to a total Borel directing of G without sinks or sources.

Consider the set of paths  $x_0, x_1, \ldots, x_n$  in  $G \setminus Y$  such that there exists y and z such that both  $(y, x_0)$  and  $(x_n, z)$  are in  $D_0$ . We may use Lemma 2.2 to partition these paths into countably many Borel sets  $\{P_i\}_{i\in\mathbb{N}}$  such that the elements of each  $P_i$  are pairwise disjoint. Now as in the proof of Lemma 4.6, for each  $i \in \mathbb{N}$ , extend each  $D_i$  to  $D_{i+1}$  by adding the edges from the paths of  $P_i$  which do not conflict with edges already in  $D_i$ . Let  $D_{\infty} = \bigcup_{i\in\mathbb{N}} D_i$ . Then complete  $D_{\infty}$  to a total directing D using Lemma 4.6.

- $(3) \Rightarrow (1)$  follows from Theorem 4.5. It is clear that such a directing can be used to define a Borel antimatching.
- $(3) \Rightarrow (4)$ . Suppose that G is a Borel bipartite 3-regular graph whose bipartiteness is witnessed by the Borel sets A and B. Suppose D is a Borel directing of G without sinks or sources. We can use D to write G as the disjoint union of

two graphs  $H_0$  and  $H_1$  in the following way: the edges of  $H_0$  are those directed by D from A to B, and the edges of  $H_1$  are those directed by D from B to A. The vertices in  $H_0$  and  $H_1$  all have degree 1 or 2. Hence, each connected component of the  $H_i$  is finite, a ray (having exactly one vertex of degree 1), or a line (having no vertices of degree 1).

If all the connected components of  $H_0$  and  $H_1$  were finite or rays, then it would be trivial to construct a Borel edge coloring of G with four colors; we could simply edge color  $H_0$  using the colors  $\{0,1\}$ , edge color  $H_1$  using the colors  $\{2,3\}$ , and then take the union of these colorings. Our problem is that in general, we will need to use 3 colors in an edge coloring of an  $H_i$  containing lines.

Let  $Y \subseteq [X]^2$  be a Borel set of pairwise disjoint edges from  $H_0$  consisting of infinitely many edges from each line in  $H_0$ . Define the countable Borel equivalence relations  $F_0$  and  $F_1$  on  $F_0$  where  $F_0$  and  $F_0$  are  $F_0$ -related if there exist  $F_0$  and  $F_0$  is infinite; however, there may be equivalence classes of  $F_0$  is infinite; however, there may be equivalence classes of  $F_0$  that are finite.

Now take a Borel set  $C \subseteq Y$  that is a complete section for  $F_0$ , so that  $C^c$  meets every infinite equivalence class of  $F_1$ . We can find such a C by letting Z be an uncountable standard Borel space and extending  $F_0$  and  $F_1$  to aperiodic equivalence relations  $F_0^*$  and  $F_1^*$  on  $Y \sqcup Z$  such that if  $x \in Z$  and  $y \in Y$ , then  $x \not F_0^* y$  and  $x F_1^* y$  only if  $[y]_{F_1}$  is finite. Now find disjoint complete sections for  $F_0^*$  and  $F_1^*$ .

Let  $H_0^*$  be the graph  $H_0$  but with the edges from C removed, and let  $H_1^*$  be the graph  $H_1$  but with the edges from C added. Clearly  $H_0^*$  has no lines. Further, all the lines that we have added to  $H_1^*$  must contain rays from  $H_1$ . This is because the elements of C in a new line in  $H_1^*$  must all be  $F_1$ -related, and therefore come from an  $F_1$ -class that is finite. Hence, we can edge color these lines from  $H_1^*$  in a Borel way with 2-colors.

If we perform the same process again with  $H_1^*$  and  $H_0^*$  in lieu of  $H_0$  and  $H_1$ , respectively, then we obtain Borel graphs  $H_0^{**}$  and  $H_1^{**}$  such that  $G = H_0^{**} \cup H_1^{**}$  and both  $H_0^{**}$  and  $H_1^{**}$  have Borel edge colorings with 2 colors.

 $(4) \Rightarrow (1)$ . We use Theorem 4.5 again. Let G be a Borel bipartite 3-regular graph, whose bipartiteness is witnessed by the Borel sets A and B. Suppose that G has a Borel edge coloring with 4 colors. We can use this coloring to define a Borel antimatching of G. First, partition the four colors into the sets  $\{0,1\}$  and  $\{2,3\}$ . Notice that each vertex must be incident to at least one edge of color 0 or 1, and at least one edge of color 2 or 3. Thus, we can define a Borel antimatching by setting f(x) = y if  $x \in A$  and y is the least neighbor of x such that (x, y) is colored 0 or 1, or if  $x \in B$  and y is the least neighbor of x such that (x, y) is colored 2 or 3.  $\square$ 

As a consequence of the above lemma, we obtain the following.

<span id="page-20-0"></span>**Theorem 4.8.** Suppose G is a Borel bipartite 3-regular graph on X. Then G has a Borel edge coloring with 4 colors modulo a null set or meager set with respect to any Borel probability measure on X or Polish topology realizing the standard Borel structure of X.

The full measurable analogue of Vizing's theorem for Borel graphs remains open.

**Question 4.9.** Given any n-regular Borel graph G on a standard Borel probability space  $(X, \mu)$ , must there be a  $\mu$ -measurable edge coloring of G with n + 1 colors?

### Acknowledgments

Section 4 of this paper is taken from the author's thesis, which was written under the excellent direction of Ted Slaman. The author would like to thank Professor Slaman for many years of wise advice. The author would also like to thank Clinton Conley, Alekos Kechris, Benjamin Miller, Anush Tserunyan, Robin Tucker-Drob, and Jay Williams for providing helpful feedback and suggestions throughout the development of this paper. Finally, the author would like to thank the referee for many helpful suggestions.

### References

- <span id="page-21-15"></span>[1] Lewis Bowen, Weak isomorphisms between Bernoulli shifts, Israel J. Math. **183** (2011), 93–102, DOI 10.1007/s11856-011-0043-3. M[R2811154 \(2012k:37008\)](http://www.ams.org/mathscinet-getitem?mr=2811154)
- <span id="page-21-16"></span>[2] Lewis Bowen, Every countably infinite group is almost Ornstein, Dynamical systems and group actions, Contemp. Math., vol. 567, Amer. Math. Soc., Providence, RI, 2012, pp. 67–78, DOI 10.1090/conm/567/11234. M[R2931910](http://www.ams.org/mathscinet-getitem?mr=2931910)
- <span id="page-21-1"></span>[3] Clinton T. Conley and Alexander S. Kechris, Measurable chromatic and independence numbers for ergodic graphs and group actions, Groups Geom. Dyn. **7** (2013), no. 1, 127–180, DOI 10.4171/GGD/179. M[R3019078](http://www.ams.org/mathscinet-getitem?mr=3019078)
- <span id="page-21-2"></span>[4] Clinton T. Conley, Alexander S. Kechris, and Robin D. Tucker-Drob, Ultraproducts of measure preserving actions and graph combinatorics, Ergodic Theory Dynam. Systems **33** (2013), no. 2, 334–374, DOI 10.1017/S0143385711001143. M[R3035288](http://www.ams.org/mathscinet-getitem?mr=3035288)
- <span id="page-21-18"></span>[5] Clinton Conley and Benjamin Miller, Measurable matchings in acyclic countable finite Borel graphs. Preprint.
- <span id="page-21-13"></span>[6] Clinton T. Conley and Benjamin D. Miller, An antibasis result for graphs of infinite Borel chromatic number, Proc. Amer. Math. Soc. **142** (2014), no. 6, 2123–2133, DOI 10.1090/S0002- 9939-2014-11918-6. M[R3182030](http://www.ams.org/mathscinet-getitem?mr=3182030)
- <span id="page-21-10"></span>[7] Clinton T. Conley, Measure-theoretic unfriendly colorings, Fund. Math. **226** (2014), no. 3, 237–244, DOI 10.4064/fm226-3-3. M[R3229757](http://www.ams.org/mathscinet-getitem?mr=3229757)
- <span id="page-21-9"></span>[8] Endre Csoka and Gabor Lippner, Invariant random matchings in Cayley graphs, available at <arXiv:1211.2374>.
- <span id="page-21-5"></span>[9] Reinhard Diestel, Graph theory, 3rd ed., Graduate Texts in Mathematics, vol. 173, Springer-Verlag, Berlin, 2005. M[R2159259 \(2006e:05001\)](http://www.ams.org/mathscinet-getitem?mr=2159259)
- <span id="page-21-17"></span>[10] Fran¸cois G. Dorais, Damir D. Dzhafarov, Jeffry L. Hirst, Joseph R. Mileti, and Paul Shafer, On uniform relationships between combinatorial problems, available at <arXiv:1212.0157>.
- <span id="page-21-6"></span>[11] G´abor Elek and G´abor Lippner, Borel oracles. An analytical approach to constant-time algorithms, Proc. Amer. Math. Soc. **138** (2010), no. 8, 2939–2947, DOI 10.1090/S0002-9939- 10-10291-3. M[R2644905 \(2011g:03117\)](http://www.ams.org/mathscinet-getitem?mr=2644905)
- <span id="page-21-4"></span>[12] A. M. Frieze and T. Luczak, On the independence and chromatic numbers of random regular graphs, J. Combin. Theory Ser. B **54** (1992), no. 1, 123–132, DOI 10.1016/0095- 8956(92)90070-E. M[R1142268 \(92m:05170\)](http://www.ams.org/mathscinet-getitem?mr=1142268)
- <span id="page-21-14"></span>[13] Su Gao and Steve Jackson, Countable abelian group actions and hyperfinite equivalence relations (2012). Preprint.
- <span id="page-21-7"></span>[14] Hamed Hatami, L´aszl´o Lov´asz, and Bal´azs Szegedy, Limits of local-global convergent graph sequences, available at <arXiv:1205.4356>.
- <span id="page-21-3"></span>[15] S. Jackson, A. S. Kechris, and A. Louveau, Countable Borel equivalence relations, J. Math. Log. **2** (2002), no. 1, 1–80, DOI 10.1142/S0219061302000138. M[R1900547 \(2003f:03066\)](http://www.ams.org/mathscinet-getitem?mr=1900547)
- <span id="page-21-0"></span>[16] A. S. Kechris, S. Solecki, and S. Todorcevic, Borel chromatic numbers, Adv. Math. **141** (1999), no. 1, 1–44, DOI 10.1006/aima.1998.1771. M[R1667145 \(2000e:03132\)](http://www.ams.org/mathscinet-getitem?mr=1667145)
- <span id="page-21-11"></span>[17] Alexander S. Kechris, Classical descriptive set theory, Graduate Texts in Mathematics, vol. 156, Springer-Verlag, New York, 1995. M[R1321597 \(96e:03057\)](http://www.ams.org/mathscinet-getitem?mr=1321597)
- <span id="page-21-12"></span>[18] Alexander S. Kechris and Benjamin D. Miller, Topics in orbit equivalence, Lecture Notes in Mathematics, vol. 1852, Springer-Verlag, Berlin, 2004. M[R2095154 \(2005f:37010\)](http://www.ams.org/mathscinet-getitem?mr=2095154)
- <span id="page-21-8"></span>[19] M. Laczkovich, Closed sets without measurable matching, Proc. Amer. Math. Soc. **103** (1988), no. 3, 894–896, DOI 10.2307/2046871. M[R947676 \(89f:28018\)](http://www.ams.org/mathscinet-getitem?mr=947676)

- <span id="page-22-1"></span>[20] Russell Lyons and Fedor Nazarov, Perfect matchings as IID factors on non-amenable groups, European J. Combin. **32** (2011), no. 7, 1115–1125, DOI 10.1016/j.ejc.2011.03.008. M[R2825538 \(2012m:05423\)](http://www.ams.org/mathscinet-getitem?mr=2825538)
- <span id="page-22-4"></span>[21] Donald A. Martin, Borel determinacy, Ann. of Math. (2) **102** (1975), no. 2, 363–371. M[R0403976 \(53 #7785\)](http://www.ams.org/mathscinet-getitem?mr=0403976)
- <span id="page-22-3"></span>[22] Arnold W. Miller, Arnie Miller's problem list, Set theory of the reals (Ramat Gan, 1991), Israel Math. Conf. Proc., vol. 6, Bar-Ilan Univ., Ramat Gan, 1993, pp. 645–654. M[R1234292](http://www.ams.org/mathscinet-getitem?mr=1234292) [\(94m:03073\)](http://www.ams.org/mathscinet-getitem?mr=1234292)
- <span id="page-22-0"></span>[23] Benjamin D. Miller, The graph-theoretic approach to descriptive set theory, Bull. Symbolic Logic **18** (2012), no. 4, 554–575. M[R3053069](http://www.ams.org/mathscinet-getitem?mr=3053069)
- <span id="page-22-2"></span>[24] Brandon Seward and Robin D. Tucker-Drob, Borel structurability on the 2-shift of a countable group, available at <arXiv:1402.4184>.
- <span id="page-22-5"></span>[25] Simon Thomas, Universal Borel actions of countable groups, Groups Geom. Dyn. **6** (2012), no. 2, 389–407, DOI 10.4171/GGD/161. M[R2914864](http://www.ams.org/mathscinet-getitem?mr=2914864)

Department of Mathematics, California Institute of Technology, Pasadena, California 91125

E-mail address: marks@caltech.edu