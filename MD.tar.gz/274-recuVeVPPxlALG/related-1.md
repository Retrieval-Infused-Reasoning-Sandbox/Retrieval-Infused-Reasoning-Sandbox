# Remarks on the vertex and the edge metric dimension of 2-connected graphs

Martin Knor<sup>1</sup> , Jelena Sedlar<sup>2</sup>,<sup>4</sup> , Riste Skrekovski ˇ <sup>3</sup>,<sup>4</sup>

<sup>1</sup> Slovak University of Technology in Bratislava, Bratislava, Slovakia

- <sup>2</sup> University of Split, Faculty of civil engineering, architecture and geodesy, Croatia
  - <sup>3</sup> University of Ljubljana, FMF, 1000 Ljubljana, Slovenia
  - <sup>4</sup> Faculty of Information Studies, 8000 Novo Mesto, Slovenia

March 15, 2022

#### Abstract

The vertex (resp. edge) metric dimension of a graph G is the size of a smallest vertex set in G which distinguishes all pairs of vertices (resp. edges) in G and it is denoted by dim(G) (resp. edim(G)). The upper bounds dim(G) ≤ 2c(G) − 1 and edim(G) ≤ 2c(G) − 1, where c(G) denotes the cyclomatic number of G, were established to hold for cacti without leaves distinct from cycles, and moreover all leafless cacti which attain the bounds were characterized. It was further conjectured that the same bounds hold for general connected graphs without leaves and this conjecture was supported by showing that the problem reduces to 2-connected graphs. In this paper we focus on Θ-graphs, as the most simple 2-connected graphs distinct from cycle, and show that the the upper bound 2c(G) − 1 holds for both metric dimensions of Θ-graphs and we characterize all Θ-graphs for which the bound is attained. We conclude by conjecturing that there are no other extremal graphs for the bound 2c(G) − 1 in the class of leafless graphs besides already known extremal cacti and extremal Θ-graphs mentioned here.

## 1 Introduction

In this paper we assume that all graphs are simple and connected, unless we explicitly say otherwise, and we consider distances in such graphs. Let G be a graph with the set of vertices V (G) and the set of edges E(G). The distance dG(u, v) between vertices u, v ∈ V (G) is the length of a shortest path in G connecting vertices u and v. The distance dG(u, e) between a vertex u ∈ V (G) and an edge e = vw ∈ E(G) is defined by dG(u, e) = min{dG(u, v), dG(u, w)}. When no confusion arises from that, we use abbreviated notation d(u, v) and d(u, e). We say that a pair x and x <sup>0</sup> of vertices from V (G) (resp. of edges from E(G)) is distinguished by a vertex s ∈ V (G) if d(s, x) 6= d(s, x<sup>0</sup> ). A set S is a vertex (resp. an edge) metric generator if every pair x and x <sup>0</sup> of vertices from V (G) (resp. of edges from E(G)) is distinguished by a vertex s ∈ S. The size of a smallest vertex (resp. edge) metric generator in G is called the vertex (resp. the edge) metric dimension of G and it is denoted by dim(G) (resp. edim(G)). The cyclomatic number c(G) of a graph G is defined by c(G) = |E(G)| − |V (G)| + 1. A Θ-graph is any graph G with precisely two vertices of degree 3 and all other vertices of degree 2.

The concept of vertex metric dimension was introduced related to the study of navigation systems [\[7\]](#page-17-0) and the landmarks in networks [\[11\]](#page-17-1). Various aspects of this metric dimension have been studied since it was first introduced [\[1,](#page-16-0) [2,](#page-17-2) [3,](#page-17-3) [4,](#page-17-4) [5,](#page-17-5) [13,](#page-17-6) [16,](#page-17-7) [18\]](#page-18-0). As it was noticed recently in [\[10\]](#page-17-8), there are graphs in which none of the smallest vertex metric generators distinguishes all pairs of edges. This motivated the introduction of a new variant of metric dimension, namely the edge metric dimension. Even though it is newer than the vertex metric dimension, the edge metric dimension also atracted interest [\[6,](#page-17-9) [8,](#page-17-10) [12,](#page-17-11) [14,](#page-17-12) [17,](#page-17-13) [25,](#page-18-1) [26,](#page-18-2) [27\]](#page-18-3).A nice survey of the topic of metric dimension is given in [\[15\]](#page-17-14).

Particularly relevant for this paper is the line of investigation from papers [\[22,](#page-18-4) [23\]](#page-18-5) where graphs with edge disjoint cycles, also called cactus graphs or cacti, were studied. In [\[22\]](#page-18-4) the upper bounds dim(G) ≤ L(G) + 2c(G) and edim(G) ≤ L(G) + 2c(G) are established to hold for all cacti, where L(G) is an invariant that depends on the presence of leaves in G. Moreover, the following conjectures were proposed for general graphs.

Conjecture 1 Let G be a connected graph. Then, dim(G) ≤ L(G) + 2c(G).

Conjecture 2 Let G be a connected graph. Then, edim(G) ≤ L(G) + 2c(G).

Since the attainment of the bound in the class of cactus graphs depends on the presence of leaves, leafless cacti and general graphs without leaves were further investigated in [\[23\]](#page-18-5). It was established that for leafless cacti the upper bound decreases to 2c(G) − 1, and all cacti attaining this bound were characterized. It was further conjectured that the same decreased upper bound holds for all leafless graphs, i.e., the following two conjectures were posed.

<span id="page-1-0"></span>Conjecture 3 Let G 6= C<sup>n</sup> be a graph with minimum degree δ(G) ≥ 2. Then, dim(G) ≤ 2c(G) − 1.

<span id="page-1-1"></span>Conjecture 4 Let G 6= C<sup>n</sup> be a graph with minimum degree δ(G) ≥ 2. Then, edim(G) ≤ 2c(G) − 1.

To support these conjectures, it was established in [\[23\]](#page-18-5) that they hold for all graphs with δ(G) ≥ 3 with the strict inequality. Moreover, additional results for graphs with δ(G) = 2 were also established, but let us first define all involved notions.

A set S ⊆ V (G) is called a vertex cut if G − S is not connected or it is trivial. A vertex v is called a cut vertex, if S = {v} is a vertex cut. The (vertex) connectivity of a graph G is the size of the smallest vertex cut in G and we denote it by κ(G). A graph G is said to be k-connected if κ(G) ≥ k. Any maximal 2-connected subgraph of G is called a block of G. If a block G<sup>i</sup> contains at least three vertices, then G<sup>i</sup> is said to be non-trivial.

In [\[23\]](#page-18-5) it was established that for δ(G) = 2 the problem can be reduced to 2-connected graphs, i.e., it was shown that if Conjecture [3](#page-1-0) (resp. Conjecture [4\)](#page-1-1) holds for 2-connected graphs, then it holds in general. Moreover, considering when the upper bound is attained, the following claim was established.

<span id="page-2-1"></span>Lemma 5 Let G 6= C<sup>n</sup> be a graph with δ(G) ≥ 2. If dim(Gi) < 2c(Gi) − 1 (resp. edim(Gi) < 2c(Gi)−1) for a block G<sup>i</sup> of G distinct from a cycle or there exist two vertexdisjoint non-trivial blocks G<sup>j</sup> and G<sup>k</sup> in G, then dim(G) < 2c(G) − 1 (resp. edim(G) < 2c(G) − 1).

In this paper, we consider 2-connected graphs that attain the bound of Conjectures [3](#page-1-0) and [4.](#page-1-1) In particular, we study Θ-graphs, as they are the simplest 2-connected graphs distinct from cycles. We show that the upper bound 2c(G) − 1 holds for both metric dimensions of Θ-graphs. Since for all Θ-graphs the value of cyclomatic number equals 2, to prove the conjectures it is sufficient to prove that for all such graphs metric dimensions are bounded above by 3. We also characterize all Θ-graphs for which the bounds are attained. The paper is concluded with the conjectures that the already known extremal leafless cacti from [\[23\]](#page-18-5) and the extremal Θ-graphs established in this paper are the only leafless graphs for which the bound 2c(G) − 1 is attained. For these conjectures we also established that they reduce to the same problem on the class of 2-connected graphs. Similar results for yet another variant of metric dimension, so called mixed metric dimension, were already reported in [\[20,](#page-18-6) [21\]](#page-18-7).

# 2 Θ-graphs with metric dimensions equal to 3

So, let us first introduce a necessary notation for Θ-graphs. Let G be a Θ-graph, by u and v we denote the two vertices of degree 3 in G. Notice that there are three distinct paths in G connecting u and v, we will denote them by P<sup>1</sup> = u0u<sup>1</sup> · · · up, P<sup>2</sup> = v0v<sup>1</sup> · · · v<sup>q</sup> and P<sup>3</sup> = w0w<sup>1</sup> · · ·wr, so that u<sup>0</sup> = v<sup>0</sup> = w<sup>0</sup> = u, u<sup>p</sup> = v<sup>q</sup> = w<sup>r</sup> = v and p ≤ q ≤ r. The cycle in G induced by paths P<sup>i</sup> and P<sup>j</sup> will be denoted by Cij . A Θ-graph in which paths P1, P<sup>2</sup> and P<sup>3</sup> are of lengths p, q, and r respectively, is denoted by Θp,q,r.

<span id="page-2-0"></span>Lemma 6 Let G = Θp,p,p or Θp,p,p+2 with p ≥ 2. Then dim(G) ≥ 3.

Proof. Let S ⊆ V (G) be a set of vertices in G such that |S| = 2. It is sufficient to show that S is not a vertex metric generator. First, if S = {u, v}, then u<sup>1</sup> and v<sup>1</sup> are not distinguished by S, so we can assume v 6∈ S. Now, let us consider the case S ⊆ V (Pi) for some i ∈ {1, 2, 3}. Assume first S ⊆ V (P3). Since P<sup>1</sup> and P<sup>2</sup> are of equal length, the distance of u<sup>1</sup> and v<sup>1</sup> to all vertices of P<sup>3</sup> is the same, hence S does not distingush u<sup>1</sup> and v1. Let us now assume S ⊆ V (P1) and let us consider vertices v<sup>1</sup> and w1. Notice that a shortest path from both v<sup>1</sup> and w<sup>1</sup> to all vertices of P<sup>1</sup> leads through u. This implies that the distance from v<sup>1</sup> and w<sup>1</sup> to all the vertices of P<sup>1</sup> is the same, so a set S ⊆ V (P1) would not distinguish v<sup>1</sup> and w1. The same reasoning goes for S ⊆ V (P2), so we may assume that S 6⊆ V (Pi) for every i = 1, 2, 3.

Now, denote by s<sup>1</sup> and s<sup>2</sup> the two elements of S. Then s<sup>1</sup> and s<sup>2</sup> are internal vertices of paths P<sup>i</sup> and P<sup>j</sup> , respectively, where i 6= j. We distinguish two cases.

![](_page_3_Figure_1.jpeg)

<span id="page-3-0"></span>Figure 1: A set S = {s1, s2} in the proof of Lemma [6:](#page-2-0) a) case when s<sup>1</sup> ∈ V (P1) and s<sup>2</sup> ∈ V (P2) with p = 6, d<sup>1</sup> = 1, d<sup>2</sup> = 4, a = 5, b = 7, c = 1 and d = 3 in which u<sup>d</sup> and w<sup>c</sup> are not distinguished by S; b) case when s<sup>1</sup> ∈ V (P1) and s<sup>2</sup> ∈ V (P3) with p = 6, d<sup>1</sup> = 3, d<sup>2</sup> = 2, a = 5, b = 9, c = 2 and d = 8, where u<sup>d</sup> and v<sup>c</sup> are not distinguished by S.

Case 1: s<sup>1</sup> ∈ V (P1) and s<sup>2</sup> ∈ V (P2). Let us denote d<sup>1</sup> = d(s1, u), d<sup>2</sup> = d(s2, u), a = d<sup>1</sup> + d<sup>2</sup> and b = 2p − a. If a = b, then s<sup>1</sup> and s<sup>2</sup> form an antipodal pair on C12, which implies that two neighbours of s<sup>1</sup> are not distinguished by S. So, without loss of generality we may assume a < p and d<sup>1</sup> ≤ d2. Since a + b = 2p, it follows that a and b are of the same parity, hence b − a is a positive even number. Therefore, we can define c = (b − a)/2 and we know that c is a positive integer. Let d = 2d<sup>1</sup> + c. Notice that

$$c < d = 2d_1 + c \le a + c = \frac{a}{2} + \frac{b}{2} = p.$$

So there exist interior vertices u<sup>d</sup> ∈ P<sup>1</sup> and w<sup>c</sup> ∈ P3, see Figure [1](#page-3-0) a).

Now we prove that u<sup>d</sup> and w<sup>c</sup> are not distinguished by S. Notice that d(ud, s1) = d − d<sup>1</sup> = d<sup>1</sup> + c. Since

$$c + d_1 = \frac{b}{2} - \frac{a}{2} + d_1 \le \frac{b}{2} = p - \frac{a}{2} < p,$$

we have d(wc, s1) = c+d1, and so u<sup>d</sup> and w<sup>c</sup> are not distinguished by s1. As for s2, notice that

$$c + d_2 < \frac{b-a}{2} + a = p,$$

so we have d(wc, s2) = c + d2. Also, we have

$$d_2 + d = d_2 + 2d_1 + c = a + d_1 + \frac{b - a}{2} = p + d_1 > p,$$

which implies

$$d(u_d, s_2) = 2p - d - d_2 = 2p - p - d_1 = p - d_1 = p - a + d_2 = c + d_2.$$

We conclude that u<sup>d</sup> and w<sup>c</sup> are not distinguished by s<sup>2</sup> either, so S is not a vertex metric generator.

Case 2: s<sup>1</sup> ∈ V (P1) and s<sup>2</sup> ∈ V (P3). For G = Θp,p,p this case is analogous to the previous one, so let us assume G = Θp,p,p+2. Again, denote d<sup>1</sup> = d(u, s1), d<sup>2</sup> = d(u, s2), a = d<sup>1</sup> + d<sup>2</sup> and b = 2p + 2 − a. If a = b, then s<sup>1</sup> and s<sup>2</sup> are antipodal on C13, so the two neighbors of s<sup>1</sup> are not distinguished by S. Hence, without loss of generality we may assume a < b. Let us denote c = (b − a)/2. Since a + b = 2p + 2 we know that a and b are of the same parity, so b − a is a positive integer. Consequently, also c is a positive integer.

First, since s<sup>1</sup> and s<sup>2</sup> are internal vertices of paths P<sup>1</sup> and P<sup>3</sup> respectively, we have a = d<sup>1</sup> + d<sup>2</sup> ≥ 2. This yields

$$c = \frac{b-a}{2} = \frac{a+b}{2} - a = p+1 - a \le p-1.$$

Hence, there exists an interior vertex v<sup>c</sup> ∈ V (P2), as it is shown in Figure [1](#page-3-0) b). Also, notice that

$$d_1 + c < a + \frac{b-a}{2} = \frac{a+b}{2} = p+1,$$

which implies d(vc, s1) = d<sup>1</sup> + c.

Now, let d = 2d<sup>1</sup> + c. If d ≤ p we consider the vertex u<sup>d</sup> ∈ V (P1), otherwise for the sake of simplicity we denote u<sup>d</sup> = w2p+2−d, see Figure [1](#page-3-0) b). We have already shown d<sup>1</sup> + c < p + 1, which yields

$$d - d_1 = d_1 + c$$

and so d(ud, s1) = d − d<sup>1</sup> = d<sup>1</sup> + c = d(vc, s1). Hence, u<sup>d</sup> and v<sup>c</sup> are not distinguished by s1. It remains to prove that u<sup>d</sup> and v<sup>c</sup> are not distinguished by s<sup>2</sup> either. For that purpose, notice that

$$c + d_2 < c + a = \frac{b - a}{2} + a = \frac{a + b}{2} = p + 1,$$

which implies d(vc, s2) = c + d2. Also, notice that

$$2p + 2 - d - d_2 = a + b - 2d_1 - c - d_2 = a + b - d_1 - \frac{b - a}{2} - (d_1 + d_2)$$
$$= \frac{a + b}{2} - d_1 = p + 1 - d_1$$

which implies

$$d(s_2, u_d) = 2p + 2 - d - d_2 = \frac{a+b}{2} - d_1 = \frac{a+b}{2} - a + a - d_1 = \frac{b-a}{2} + d_2 = c + d_2 = d(v_c, s_2).$$

Therefore, vertices v<sup>c</sup> and u<sup>d</sup> are not distinguished by s<sup>2</sup> either, hence we conclude that S is not a vertex metric generator.

<span id="page-4-0"></span>Now, a subgraph H of a graph G is an isometric subgraph if dH(u, v) = dG(u, v) for every pair of vertices u, v ∈ V (H). Consequently, if a pair of vertices is distinguished by S ∩ V (H) in H, then it is distinguished by S in G too.

Lemma 7 Let G = Θp,p,p or Θp,p,p+2 with p ≥62. Then for any a ∈ V (G), there are b, c ∈ V (G) such that S = {a, b, c} is a vertex metric generator in G.

Proof. First, notice that every cycle Cij of G is an isometric subgraph in G. We say that a set S ⊆ V (G) is nice, if for every cycle Cij of G it holds that S ∩ V (Cij ) contains two vertices which do not form an antipodal pair in Cij . We first show that any nice set S is a vertex metric generator in G. In order to see this, let x and x <sup>0</sup> be a pair of vertices from G. Notice that x and x <sup>0</sup> belong to at least one cycle Cij in G. Since S is nice, S ∩ V (Cij ) contains two vertices which are not antipodal in Cij , which implies that S ∩ V (Cij ) is a vertex metric generator in Cij . Therefore, x and x <sup>0</sup> are distinguished by S ∩V (Cij ) in Cij . Since Cij is an isometric subgraph of G, this further implies that x and x <sup>0</sup> are distinguished by S in G, so S is a vertex metric generator of G. To complete the proof, for every a ∈ V (G) we extend a to a nice set.

Let us assume G = Θp,p,p. If p ≤ 3, the set S = {u, v1, w1} is a nice set in G. Therefore, S is a vertex metric generator, which due to symmetry of G proves the claim. So, let us assume that p ≥ 4. By symmetry, we may assume that a = u<sup>i</sup> , where 0 ≤ i ≤ bp/2c. But then S<sup>i</sup> = {u<sup>i</sup> , v1, w1} is a nice set in G.

Assume now that G = Θp,p,p+2. If p = 2, it is easy to see that sets S = {u, v1, w1} and S = {u, v1, w2} are nice in G, which due to symmetry of G proves the claim. If p > 2, then due to symmetry of G it is sufficient to prove the claim for a = u<sup>i</sup> where 0 ≤ i ≤ bp/2c and for a = w<sup>j</sup> where 1 ≤ j ≤ bp/2c + 1. If a = u<sup>i</sup> for i ≤ bp/2c , then S = {u<sup>i</sup> , v1, w1} is nice in G. On the other hand, if a = w<sup>j</sup> for j ≤ bp/2c + 1, then S = {u1, v1, wj} is nice in G.

By Lemmas [6](#page-2-0) and [7](#page-4-0) the following statement holds.

Theorem 8 For p ≥ 2, it holds that dim(Θp,p,p) = dim(Θp,p,p+2) = 3.

Since in any Θ-graph G it holds that L(G) = 0 and c(G) = 2, the above theorem gives the following corollary.

Corollary 9 We have dim(Θp,p,p) = dim(Θp,p,p+2) = 2c(G) − 1.

Hence, for Θp,p,p and Θp,p,p+2 the bound from Conjecture [3](#page-1-0) holds with equality. Similarly, when considering the edge metric dimension of Θ-graphs, we have the following.

<span id="page-5-0"></span>Lemma 10 Let G = Θ1,2,<sup>2</sup> or Θp,p,q with 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Then for any a ∈ V (G), there are b, c ∈ V (G) such that S = {a, b, c} is an edge metric generator in G.

Proof. As p = 2 or 3 and q ∈ {p, p + 1, p + 2}, the problem is finite. To avoid a tedious proof, the statement was easily verified by a computer by checking all sets S ⊆ V (G) of cardinality 3.

Proposition 11 Let G = Θ1,2,<sup>2</sup> or Θp,p,q with 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Then edim(G) = 3.

Proof. Similarly as before, by a computer we checked easily that there is no edge metric generator of size two. Then the claim follows from Lemma [10.](#page-5-0)

Corollary 12 Let G = Θ1,2,<sup>2</sup> or G = Θp,p,q for 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Then edim(G) = 2c(G) − 1.

#### 3 $\Theta$ -graphs with metric dimensions equal to 2

In this section we show that all remaining  $\Theta$ -graphs, i.e., all  $\Theta$ -graphs not mentioned in the previous section, have the vertex (resp. the edge) metric dimension equal to 2. We first consider the vertex metric dimension. For all remaining  $\Theta$ -graphs we show that there is a set S of cardinality two which is a vertex metric generator, see Figure 2.

<span id="page-6-0"></span>**Lemma 13** Let  $G = \Theta_{p,q,r}$ , where  $p \leq q \leq r$ , and let S be a set of vertices in G, defined in the following way:

- i) if one of p, q, r is odd and at least 3 and one of p, q, r is even, say  $q \ge 3$  is odd and r is even, then  $S = \{v_{(q-1)/2}, w_{r/2}\};$
- ii) if p = 1 and both q and r are even, then  $S = \{u, w_{r/2}\};$
- iii) if all p, q, r are even and  $q \notin \{p, p+2\}$ , then  $S = \{v_1, w_{r/2}\}$ ;
- iv) if all of p, q, r are even,  $q \in \{p, p+2\}$  and  $r \ge p+4$ , then  $S = \{v_{a/2}, w_1\}$ ;
- v) if all p, q, r are even and q = r = p + 2, then  $S = \{v_1, w_1\}$ ;
- vi) if all p, q, r are odd and  $q \notin \{p, p+2\}$ , then  $S = \{v_1, w_{(r-1)/2}\}$ ;
- vii) if all p, q, r are odd,  $q \in \{p, p+2\}$  and  $r \ge p+4$ , then  $S = \{v_{(q-1)/2}, w_1\}$ ;
- viii) if all p, q, r are odd and q = r = p + 2, then  $S = \{v_1, w_1\}$ .

Then S is a vertex metric generator in G.

**Proof.** First we introduce some notation. For a vertex  $a \in V(G)$  we denote by  $\mathcal{P}_a$  the partition of V(G) according to the distances from a. That is, if x, x' are in the same set of  $\mathcal{P}_a$ , then d(a, x) = d(a, x'). To prove that  $S = \{a, b\}$  is a vertex metric generator in G, it suffices to show that  $d(b, x) \neq d(b, x')$  for every pair of vertices x, x' from a common set of  $\mathcal{P}_a$ . Proceeding by way of contradiction, if d(b, x) = d(b, x') then the shortest path from b to x cannot contain a path from b to x' and vice versa. This simplifies our consideration since  $\Theta_{p,q,r}$  contains only two branching vertices (i.e., vertices of degree at least 3). Let us now consider each of the eight cases separately.

i) For the vertex  $w_{r/2} \in S$ , we have

$$\mathcal{P}_{w_{\frac{r}{2}}} = (\{w_{\frac{r}{2}}\}, \{w_i, w_{r-i}\}_{i=0}^{\frac{r}{2}-1}, \{u_i, v_i, u_{p-i}, v_{q-i}\}_{i=1}^{\lfloor \frac{p}{2} \rfloor}, \{v_i, v_{q-i}\}_{i=\lfloor \frac{p}{2} \rfloor+1}^{\lfloor \frac{q}{2} \rfloor}).$$

We have to show that the other vertex of S, i.e.  $v_{(q-1)/2}$ , distinguishes all pairs of vertices from a common set of  $\mathcal{P}_{w_{\frac{r}{2}}}$ . The first type of set in  $\mathcal{P}_{w_{\frac{r}{2}}}$  which contains at least one pair of vertices is  $\{w_i, w_{r-i}\}$ , so we have to show that  $w_i$  and  $w_{r-i}$  are distinguished by  $v_{(q-1)/2}$ , and that follows from

$$d(v_{\frac{q-1}{2}}, w_i) = i + \frac{q-1}{2} < i + \frac{q+1}{2} = d(w_{\frac{q-1}{2}}, w_{r-i}).$$

The next set from  $\mathcal{P}_{w_{\underline{r}}}$  to consider is of the type  $\{u_i, v_i, u_{p-i}, v_{q-i}\}$ , where we have

$$d(v_{\frac{q-1}{2}}, v_i) < d(v_{\frac{q-1}{2}}, v_{q-i}) < d(v_{\frac{q-1}{2}}, u_i) < d(y_{\frac{q-1}{2}}, u_{p-i}),$$

where the last two expressions have place only if  $i \leq \lfloor \frac{p}{2} \rfloor$ . Therefore, all pairs of vertices from that set are distinguished by  $v_{(q-1)/2} \in S$ . Notice that the inequality covers also the last type of set from  $\mathcal{P}_{w_{\frac{r}{2}}}$ . Also observe that we did not use the fact that  $p \leq q \leq r$  here, so the proof covers all cases when one of p, q, r is odd and at least 3 and one of p, q, r is even.

ii) Analogously as in i) we have

$$\mathcal{P}_{w_{\frac{r}{2}}} = (\{w_{\frac{r}{2}}\}, \{w_i, w_{r-i}\}_{i=0}^{\frac{r}{2}-1}, \{v_i, v_{q-i}\}_{i=1}^{\frac{q}{2}-1}, \{v_{\frac{q}{2}}\}).$$

It remains to show that u distinguishes all pairs of vertices which belong to a common set of  $\mathcal{P}_{w_{\underline{r}}}$ . This is seen from  $d(u, w_i) = i < i + 1 = d(u, w_{r-i})$  and  $d(u, v_i) = i < i + 1 = d(u, v_{q-i})$ .

iii) We have

$$\mathcal{P}_{w_{\frac{r}{2}}} = (\{w_{\frac{r}{2}}\}, \{w_i, w_{r-i}\}_{i=0}^{\frac{r}{2}-1}, \{u_i, v_i, u_{p-i}, v_{q-i}\}_{i=1}^{\frac{p}{2}}, \{v_i, v_{q-i}\}_{i=\frac{p}{2}+1}^{\frac{q}{2}}).$$

(Observe that, the third set has just three vertices if i=p/2, and the last set has just one vertex if i=q/2.) We show that  $v_1 \in S$  distinguishes all pairs of vertices from a common set of  $\mathcal{P}_{w_{\frac{r}{2}}}$ . Regarding set  $\{w_i, w_{r-i}\}$ , notice that  $d(v_1, w_i) = i+1 < 1+p+i = d(v_1, w_{r-i})$ . The next sets of  $\mathcal{P}_{w_{\frac{r}{2}}}$  are of the form  $\{u_i, v_i, u_{p-i}, v_{q-i}\}$  where

$$d(v_1, v_i) = i - 1 < i + 1 = d(v_1, u_i),$$

and assuming that  $v_1$  does not distinguish the other possible pairs leads to a contradiction, namely  $d(v_1, u_i) = d(v_1, u_{p-i})$  implies i+1=q-1+i and q=2, a contradiction;  $d(v_1, u_i) = d(v_1, v_{q-i})$  implies i+1=q-i-1 and i=q/2-1, but such  $u_i$  exists only if  $q \le p+2$ , a contradiction;  $d(v_1, v_i) = d(v_1, u_{p-i})$  implies i-1=p-i+1 and i=p/2+1, but such i is over the limit for this set;  $d(v_1, v_i) = d(v_1, v_{q-i})$  implies i-1=1+p+i or simplified p=-2, a contradiction;  $d(v_1, u_{p-i}) = d(v_1, v_{q-i})$  implies 1+p-i=q-i-1 and q=p+2, a contradiction.

For the last set of  $\mathcal{P}_{w_{\frac{r}{2}}}$  we have  $d(v_1, v_i) = i - 1 < q - i - 1 = d(v_1, v_i)$  whenever i < q/2, and for i = q/2 the set is a singleton.

iv) For  $v_{q/2} \in S$  we have

$$\mathcal{P}_{v_{\frac{q}{2}}} = (\{v_{\frac{q}{2}}\}, \{v_i, v_{q-i}\}_{i=0}^{\frac{q}{2}-1}, \{u_i, w_i, u_{p-i}, w_{r-i}\}_{i=1}^{\frac{p}{2}}, \{w_i, w_{r-i}\}_{i=\frac{p}{2}+1}^{\frac{r}{2}}).$$

Now we consider the distances from  $w_1 \in S$ . Assuming  $d(w_1, v_i) = d(w_1, v_{q-i})$  implies i + 1 = p + 1 + i so p = 0, a contradiction.

The next set to consider is of the form  $\{u_i, w_i, u_{p-i}, w_{r-i}\}$ . We have

$$d(w_1, w_i) = i - 1 < \min\{d(w_1, u_i), d(w_1, u_{n-i}), d(w_1, w_{r-i})\},\$$

which resolves three of the six possible pairs of vertices. For all other possible pairs we will assume that they are not distinguished by  $w_1$  and show that it leads to contradiction. Namely,  $d(w_1, u_i) = d(w_1, u_{p-i})$  implies i+1 = 1+q+i or simplified q = 0, a contradiction;  $d(w_1, u_i) = d(w_1, w_{r-i})$  implies i+1 = r-i-1 which reduces to i = r/2 - 1, but such i exceeds the limit for this set since  $r \geq p+4$ ;  $d(w_1, u_{p-i}) = d(w_1, w_{r-i})$  implies 1+p-i=r-i-1 which reduces to r=p+2, a contradiction.

For the last set of  $\mathcal{P}_{v_{\frac{q}{2}}}$  if  $w_i \neq w_{r-i}$  and  $d(w_1, w_i) = d(w_1, w_{r-i})$ , then i - 1 = p + 1 + i and p = -2, a contradiction.

v) Partition for  $v_1 \in S$  is

$$\mathcal{P}_{v_1} = (\{v_1\}, \{u, v_2\}, \{u_i, v_{i+2}, w_i\}_{i=1}^{p-1}, \{v, w_p\}, \{w_{p+1}\}).$$

and for distances from  $w_1 \in S$  we have

$$d(w_1, u) = 1 < 3 = d(w_1, v_2),$$
  

$$d(w_1, w_i) = i - 1 < d(w_1, u_i) = i + 1 < d(w_1, v_{i+2}) = i + 3,$$
  

$$d(w_1, w_p) = p - 1$$

vi) For  $w_{(r-1)/2} \in S$  we have

$$\mathcal{P}_{w_{\frac{r-1}{2}}} = (\{w_{\frac{r-1}{2}}\}, \{w_i, w_{r-i-1}\}_{i=0}^{\frac{r-3}{2}}, \{u_1, v_1, v\}, \{u_i, v_i, u_{p-i+1}, v_{q-i+1}\}_{i=2}^{\frac{p+1}{2}}, \{v_i, v_{q-i+1}\}_{i=\frac{p+3}{2}}^{\frac{q+1}{2}}).$$

Now consider the distances from  $v_1 \in S$ . Assuming  $d(v_1, w_i) = d(v_1, w_{r-i+1})$  implies i+1=p+1+i+1 which reduces to p=-1, a contradiction.

In the next set  $\{u_1, v_1, v\}$  of  $\mathcal{P}_{w_{\frac{r-1}{2}}}$  there are three possible pairs of vertices, for which we have

$$d(v_1, v_1) = 0 < d(v_1, u_1) = 2 < d(v_1, v) = p + 1,$$

where the last inequality holds if p > 1, otherwise  $u_1 = v$  so there is no pair to be distinguished.

The next set from  $\mathcal{P}_{w_{\frac{r-1}{2}}}$  is of the type  $\{u_i,v_i,u_{p-i+1},v_{q-i+1}\}$ , where we first have  $d(v_1,v_i)=i-1< i+1=d(v_1,u_i)$ , so the pair  $u_i,v_i$  is distinguished by  $v_1\in S$ . For all remaining pairs of vertices from that set, we will show that assuming they are not distinguished by  $s_1\in S$  leads to a contradiction. If  $d(v_1,u_i)=d(v_1,u_{p-i+1})$  then i+1=q-1+i-1 and q=3, a contradiction; if  $d(v_1,u_i)=d(v_1,v_{q-i+1})$  then i+1=q-i+1-1 which reduces to i=(q-1)/2, but such i exceeds the limit since q>p+2; if  $d(v_1,v_i)=d(v_1,u_{p-i+1})$  then i-1=1+p-i+1 and therefore i=(p+3)/2, but such i exceeds the limit; if  $d(v_1,v_i)=d(v_1,v_{q-i+1})$  then i-1=1+p+i-1 which reduces to p=-1, a contradiction; finally if  $d(v_1,u_{p-i+1})=d(v_1,v_{q-i+1})$  then 1+p-i+1=q-i+1-1 and therefore q=p+2, a contradiction.

As for the last type of set in  $\mathcal{P}_{w_{\frac{r-1}{2}}}$ , if  $v_i \neq v_{q-i+1}$  and  $d(v_1, v_i) = d(v_1, v_{q-i+1})$  then i-1=1+p+i-1 and so p=-1, a contradiction.

vii) Observe that

$$\mathcal{P}_{v_{\frac{q-1}{2}}} = (\{v_{\frac{q-1}{2}}\}, \{v_i, v_{q-i-1}\}_{i=0}^{\frac{q-3}{2}}, \{u_1, w_1, v\}, \{u_i, w_i, u_{p-i+1}, w_{r-i+1}\}_{i=2}^{\frac{p+1}{2}}, \{w_i, w_{r-i+1}\}_{i=\frac{p+3}{2}}^{\frac{r+1}{2}}).$$

Now we consider the distances from  $w_1 \in S$ . If  $d(w_1, v_i) = d(w_1, v_{q-i-1})$  then i + 1 = p + 1 + i + 1 and p = -1, a contradiction.

As for the set  $\{u_1, w_1, v\} \in \mathcal{P}_{v_{\frac{q-1}{2}}}$ , we have

$$d(w_1, w_1) = 0 < d(w_1, u_1) = 2 < d(w_1, v) = r - 1.$$

So all three pairs of vertices from this set are distinguished by  $w_1$ .

For the next set of  $\mathcal{P}_{v_{q-1}}$  we first have

$$d(w_1, w_i) = i - 1 < \min\{d(w_1, u_i), d(w_1, u_{p-i+1}), d(w_1, w_{r-i+1})\},\$$

so  $w_1$  distinguishes  $w_i$  from all the other vertices in that set. If  $d(w_1, u_i) = d(w_1, u_{p-i+1})$  then i+1=1+q+i-1 and q=1, a contradiction. If  $d(w_1, u_i) = d(w_1, w_{r-i+1})$  then i+1=r-i+1-1 and  $i=(r-1)/2 \ge (p+3)/2$ , but such i exceeds the limit. Finally,  $d(w_1, u_{p-i+1}) = d(w_1, w_{r-i+1})$  implies 1+p-i+1=r-i+1-1 which reduces to r=p+2, a contradiction.

For the last set of  $\mathcal{P}_{v_{\frac{q-1}{2}}}$ , if  $w_i \neq w_{r-i+1}$  and  $d(w_1, w_i) = d(w_1, w_{r-i+1})$  then i-1 = 1 + p + i - 1 and p = -1, a contradiction.

viii) Observe that

$$\mathcal{P}_{v_1} = (\{v_1\}, \{u, v_2\}, \{u_i, v_{i+2}, w_i\}_{i=1}^{p-1}, \{v, w_p\}, \{w_{p+1}\}).$$

Hence  $\mathcal{P}_{v_1}$  (and also  $\mathcal{P}_{w_1}$ ) does not depend on the parity of p. So analogously as in case v) one can show that  $S = \{v_1, w_1\}$  is a vertex metric generator in this case.

Using Lemma 13 we can prove that all  $\Theta$ -graphs not mentioned in the previous section have metric dimension 2.

<span id="page-9-0"></span>**Theorem 14** Let G be a  $\Theta$ -graph such that  $G \neq \Theta_{p,p,p}$  and  $\Theta_{p,p,p+2}$  with  $p \geq 2$ . Then  $\dim(G) = 2$ .

**Proof.** It is sufficient to show that Lemma 13 includes all  $\Theta$ -graphs distinct from  $\Theta_{p,p,p}$  and  $\Theta_{p,p,p+2}$ . Cases iii)-v) of this lemma obviously include all  $\Theta$ -graphs distinct from  $\Theta_{p,p,p}$  and  $\Theta_{p,p,p+2}$  in which all three parameters p, q and r are even. Similarly, cases vi)-viii) of the same lemma include all  $\Theta$ -graphs in which all three parameters are odd. It remains to show that cases i)-ii) cover all  $\Theta$ -graphs in which p, q and r do not have a same parity. In that case at least one of the parameters is odd. If none of the parameters is equal to one, then Lemma 13.i) covers the cases. If there is parameter equal to 1, then p=1 since  $p \leq q \leq r$ . Since  $q \leq r$  has no parallel edges,  $q \geq r$ . Hence if one of  $q \leq r$  and  $r \leq r$  is odd then this parameter is at least 3 and the other parameter is even, which is covered by Lemma 13.i) again. The only remaining case when  $q \leq r$  and both  $q \leq r$  and  $q \leq r$  are even is covered by Lemma 13.ii).

As regards the motivating question for this investigation, Theorem 14 yields the following corollary.

![](_page_10_Picture_0.jpeg)

Figure 2: Vertex metric generators from Lemma [13.](#page-6-0)

<span id="page-10-0"></span>Corollary 15 Let G be a Θ-graph such that G 6= Θp,p,p and G 6= Θp,p,p+2. Then dim(G) < 2c(G) − 1.

Now we consider the edge metric dimension of Θ-graphs. We proceed analogously as in the case of vertex metric dimension. The edge metric generators from the following lemma are illustrated in Figure [3.](#page-14-0)

<span id="page-10-1"></span>Lemma 16 Let G = Θp,q,r, where p ≤ q ≤ r, and let S be a set of vertices in G defined in a following way:

- i) if p < q, r ≥ 3 and p + r is even, then S = {w(r−p)/2, w(r+p)/2};
- ii) if p < q, r ≥ p + 3 and p + r is odd, then S = {w<sup>b</sup>(r−p)/2<sup>c</sup>, w<sup>d</sup>(r+p)/2<sup>e</sup>};
- iii) if p < q, r = p + 1 and (p, q, r) 6= (1, 2, 2), then S = {v1, w1};
- iv) if p = q and p ≥ 4, then S = {u2, v1};
- v) if p = q and r ≥ p + 3, then S = {v1, w1}.

Then S is an edge metric generator in G.

**Proof.** The proof is analogous to the proof of Lemma 13. Let a be a vertex in G. By  $\mathcal{P}_a^e$  we denote the partition of E(G) according to the distances from a. To prove that  $S = \{a, b\}$  is an edge metric generator for G, it suffices to show that  $d(b, e) \neq d(b, f)$  for every pair of edges e, f from a common set of  $\mathcal{P}_a^e$ . Also, to abbreviate the notation, an edge  $u_i u_{i+1}$  will be denoted by  $u_i^+$  or  $u_{i+1}^-$ , and the similar notation will be used for edges  $v_i v_{i+1}$  and  $w_i w_{i+1}$ . We now consider each of the five cases separately.

i) Denote a = (r - p)/2 and b = (r + p)/2. Then for  $w_a \in S$  we have

$$\mathcal{P}^{e}_{w_{a}} = (\{w_{a-i}^{-}, w_{a+i}^{+}\}_{i=0}^{a-1}, \{u_{i}^{+}, v_{i}^{+}, w_{r-p+i}^{+}\}_{i=0}^{p-1}, \{v_{p+i}^{+}, v_{q-i}^{-}\}_{i=0}^{\lfloor \frac{q-p}{2} \rfloor}).$$

In the next we suppose that  $w_b$  has the same distance to a pair of edges from a common set of  $\mathcal{P}_{w_a}^e$  and we always come to a contradiction. Here and in the next cases, the first distance is denoted by  $d_1$  and the second distance is denoted by  $d_2$ .

Let us first consider the set  $\{w_{a-i}^-, w_{a+i}^+\}$  from  $\mathcal{P}_{w_a}^e$ . If  $d(w_b, w_{a-i}^-) = d(w_b, w_{a+i}^+)$  then  $d_1 = d(w_b, w_{a-i})$ . Further  $d_2 = d(w_b, w_{a+i})$  (otherwise  $d_2 < d_1$ ) and so  $d(w_b, w_{a-i}) = d(w_b, w_{a+i})$ . Consequently b - (a-i) = (a+i) - b and therefore a = b which contradicts  $p \ge 1$ .

Let us now consider the set  $\{u_i^+, v_i^+, w_{r-p+i}^+\} \in \mathcal{P}_{w_a}^e$  and the distances from  $w_b$  to the three possible pairs of edges from this set. If  $d(w_b, u_i^+) = d(w_b, v_i^+)$ , then  $d_1 = d(w_b, u_{i+1})$  since  $d_1 < d(w_a, v) = d(w_b, u)$ . Analogously  $d_2 = d(w_b, v_{i+1})$ . Thus p - (i+1) = q - (i+1) and p = q, a contradiction. The next pair is  $u_i^+$  and  $w_{r-p+i}^+$ , where assuming  $d(w_b, u_i^+) = d(w_b, w_{r-p+i}^+)$  yields  $d_1 = d(w_b, u_{i+1})$  and  $d_2 = d(w_b, w_{r-p+i+1})$ . Thus

$$r - \frac{r+p}{2} + p - (i+1) = \frac{r+p}{2} - (r-p+i+1)$$

which reduces to r = p, a contradiction. The last pair is  $v_i^+$  and  $w_{r-p+i}^+$ , in which case  $d(w_b, v_i^+) = d(w_b, w_{r-p+i}^+)$  implies  $d_2 > d(w_b, v) = d(w_a, u)$ , and so  $d_2 = d(w_b, w_{r-p+i+1})$  and  $d_1 = d(w_b, v_{i+1})$ . This gives

$$r - \frac{r+p}{2} + q - (i+1) = \frac{r+p}{2} - (r-p+i+1)$$

and r + q = 2p, a contradiction.

It remains to consider the set  $\{v_{p+i}^+, v_{q-i}^-\} \in \mathcal{P}_{w_a}^e$ . Assuming  $d(w_b, v_{p+i}^+) = d(w_b, v_{q-i}^-)$  yields  $d_2 = d(w_b, v_{q-i}) = d(w_b, v) + d(v, v_{q-i})$ . However,  $d(\{u, v\}, \{v_{p+i}, v_{p+i+1}\}) > d(v, v_{q-i})$  and  $d(\{u, v\}, w_b) \ge d(w_b, v)$ . So  $d_1 > d_2$ , a contradiction.

ii) Since  $r \ge p+3$ , we have  $\lfloor (r-p)/2 \rfloor \ge \lfloor 3/2 \rfloor = 1$ . And since  $p \ge 1$ , we have  $\lfloor (r-p)/2 \rfloor < \lceil (r+p)/2 \rceil$ . Hence  $1 \le \lfloor (r-p)/2 \rfloor < \lfloor r/2 \rfloor$ . Denote  $a = \lfloor (r-p)/2 \rfloor$  and  $b = \lceil (r+p)/2 \rceil$ . Then for  $w_a \in S$  we have

$$\mathcal{P}^{e}_{w_{a}} = (\{w_{a-i}^{-}, w_{a+i}^{+}\}_{i=0}^{a-1}, \{u_{i}^{+}, v_{i}^{+}, w_{2a+i}^{+}\}_{i=0}^{p-1}, \{v_{p}^{+}, v_{q}^{-}, w_{r-1}^{+}\}, \{v_{p+i}^{+}, v_{q-i}^{-}\}_{i=1}^{\lfloor \frac{q-p-1}{2} \rfloor}).$$

For each of the sets from  $\mathcal{P}_{w_a}^e$ , we now show that all possible pairs of edges from that set are distinguished by  $w_b \in S$ . Let us first consider the set  $\{w_{a-i}^-, w_{a+i}^+\}$ . Assuming  $d(w_b, w_{a-i}^-) = d(w_b, w_{a+i}^+)$ , analogously as in i) we get a = b which contradicts  $p \geq 1$ .

Now consider  $\{u_i^+, v_i^+, w_{2a+i}^+\}$ . If  $d(w_b, u_i^+) = d(w_b, v_i^+)$ , then analogously as in i) we get p = q, a contradiction. If  $d(w_b, u_i^+) = d(w_b, w_{2a+i}^+)$ , then  $d_1 = d(w_b, u_{i+1})$  and  $d_2 = d(w_b, w_{2a+i+1})$ . Thus

$$r - \frac{r+p+1}{2} + p - (i+1) = \frac{r+p+1}{2} - (2\frac{r-p-1}{2} + i + 1)$$

which reduces to r = p + 2, a contradiction. Finally, if  $d(w_b, v_i^+) = d(w_b, w_{2a+i}^+)$ , then  $d_1 = d(w_b, v_{i+1})$  and  $d_2 = d(w_b, w_{2a+i+1})$ . Thus

$$r - \frac{r+p+1}{2} + q - (i+1) = \frac{r+p+1}{2} - (2\frac{r-p-1}{2} + i + 1)$$

and hence r + q = 2p + 2, a contradiction.

For edges from  $\{v_p^+, v_q^-, w_{r-1}^+\}$  we have  $d(w_b, w_{r-1}^+) = d(w_b, w_{r-1}) = r - b - 1$  and  $d(w_b, v_q^-) = d(w_b, v) = r - b$ , so that  $d(w_b, w_{r-1}^+) < d(w_b, v_q^-)$ . If  $d(w_b, w_{r-1}^+) = d(w_b, v_p^+)$  then  $d_2 = d(w_b, v_p)$ . So r - b - 1 = b + p and consequently r - p - 1 = 2b = r + p + 1, a contradiction. Finally, if  $d(w_b, v_q^-) = d(w_b, v_p^+)$  then  $d_2 = d(w_b, v_p)$ . So r - b = b + p and consequently r - p = 2b = r + p + 1, a contradiction.

Finally, consider  $\{v_{p+i}^+, v_{q-i}^-\}$ . Assuming  $d(w_b, v_{p+i}^+) = d(w_b, v_{q-i}^-)$  yields

$$d_2 = d(w_b, v_{q-i}) = d(w_b, v) + d(v, v_{q-i})$$

$$< \min\{d(\{u, v\}, \{v_{p+i}, v_{p+i+1}\}) + d(w_b, \{u, v\})\} \le d_1,$$

a contradiction.

iii) Notice that in this case  $G = \Theta_{p,p+1,p+1}$ , where  $p \geq 2$ . For  $v_1 \in S$  the partition is

$$\mathcal{P}^{e}_{v_{1}} = (\{v_{1}^{-}, v_{1}^{+}\}, \{u_{i}^{+}, v_{i+2}^{+}, w_{i}^{+}\}_{i=0}^{p-2}, \{u_{p-1}^{+}, w_{p-1}^{+}, w_{p+1}^{-}\}).$$

First consider the set  $\{v_1^-, v_1^+\}$ . Since  $p \ge 2$ , we have  $d(w_1, v_1^-) = 1 < 2 = d(w_1, v_1^+)$ , so  $v_1^-$  and  $v_1^+$  are distinguished by  $w_1 \in S$ .

Now consider  $\{u_i^+, v_{i+2}^+, w_i^+\}$ . Since

$$d(w_1, w_i^+) \le i < d(w_1, u_i^+) = i + 1 < i + 2 \le d(w_1, v_{i+2}^+),$$

all three pairs are distinguished by  $w_1 \in S$ .

Finally, for  $\{u_{p-1}^+,w_{p-1}^+,w_{p+1}^-\}$  we have

$$d(w_1, w_{p-1}^+) = p - 2 < d(w_1, w_{p+1}^-) = p - 1 < d(w_1, u_{p-1}^+) = p.$$

iv) Observe that

$$\mathcal{P}_{v_1}^e = (\{v_1^-, v_1^+\}, \{u_i^+, v_{i+2}^+, w_i^+\}_{i=0}^{p-3}, \{u_{p-2}^+, u_p^-, w_{p-2}^+, w_r^-\}, \{w_{p-1+i}^+, w_{r-1-i}^-\}_{i=0}^{\lceil \frac{r-p}{2} \rceil}).$$

First, for the unique pair from  $\{v_1^-, v_1^+\}$  it holds that  $d(u_2, v_1^-) = 2 < d(u_2, v_1^+) = 3$  if  $p \ge 4$ , so it is distinguished by  $u_2$ .

Next, consider  $\{u_i^+, v_{i+2}^+, w_i^+\}$ . Suppose that  $d(u_2, u_i^+) = d(u_2, v_{i+2}^+)$ . If  $i \geq 2$  then  $d_1 = i - 2$  and consequently  $d_2 = i + 4$ , a contradiction. Hence  $0 \leq i \leq 2$  and

$$d(u_2, u_i^+) = d(u_2, u_{i+1}) = 1 - i < d(u_2, v_{i+2}^+) = d(u_2, v_{i+3}) = p - 2 + p - (i+3),$$

a contradiction. For the second pair  $u_i^+$  and  $w_i^+$ , since  $i \leq p-3$  we have

$$d(u_2, u_i^+) \le (i-2) + 3 < i+2 = d(u_2, w_i) = d(u_2, w_i^+).$$

For the last pair  $v_{i+2}^+$  and  $w_i^+$ , we assume that  $d(u_2, v_{i+2}^+) = d(u_2, w_i^+)$ . We distinguish three subcases:

- if  $0 \le i \le p-5$  then  $d_1 = d(u_2, v_{i+2}) = i+4 > i+2 = d(u_2, w_i) = d_2$ ;
- if i = p 4 then  $d_1 = d(u_2, v_{i+3}) = p 1 > p 2 = d(u_2, w_i) = d_2$ ;
- if i = p 3 then  $d_1 = d(u_2, v_{i+3}) = p 2 .$

Now we consider the set  $\{u_{p-2}^+, u_p^-, w_{p-2}^+, w_r^-\}$ . We have

$$d(u_2, u_{p-2}^+) = p - 4 < d(u_2, u_p^-) = p - 3 < d(u_2, w_r^-) = p - 2 < d(u_2, w_{p-2}^+) \ge p - 1,$$

where the last inequality is an equality only if r = p.

Finally, for  $\{w_{p-1+i}^+, w_{r-1-i}^-\}$  suppose that  $d(u_2, w_{p-1+i}^+) = d(u_2, w_{r-1-i}^-)$ . Then  $d_2 = d(u_2, w_{r-1-i})$  and so  $d_1 = d(u_2, w_{p-1+i})$ . Thus 2 + p - 1 + i = p - 2 + r - (r - 1 - i) and 1 = -1, a contradiction.

v) Observe that

$$\mathcal{P}^{e}_{v_{1}} = (\{v_{1}^{-}, v_{1}^{+}\}, \{u_{i}^{+}, v_{i+2}^{+}, w_{i}^{+}\}_{i=0}^{p-3}, \{u_{p-2}^{+}, u_{p}^{-}, w_{p-2}^{+}, w_{r}^{-}\}, \{w_{p-1+i}^{+}, w_{r-1-i}^{-}\}_{i=0}^{\lceil \frac{r-p}{2} \rceil}).$$

First, consider the set  $\{v_1^-, v_1^+\}$ . Since  $r \ge 4$ , we have  $d(w_1, v_1^-) = 1 < 2 = d(w_1, v_1^+)$ . Next, consider the set  $\{u_i^+, v_{i+2}^+, w_i^+\}$ . We have

$$d(w_1, v_{i+2}^+) = i + 3 > d(w_1, u_i^+) = i + 1 > d(w_1, w_i^+) \le i,$$

where the last inequality is an equality only if i = 0 and the first equality is a consequence of r > p + 3.

Now consider the set  $\{u_{p-2}^+, u_p^-, w_{p-2}^+, w_r^-\}$ . We have

$$d(w_1, w_{p-2}^+) = p - 3 < d(w_1, u_{p-2}^+) = p - 1 < d(w_1, u_p^-) = p < d(w_1, w_r^-) = p + 1,$$

where the last inequality holds since  $r \ge p + 3$ .

Finally, consider the set  $\{w_{p-1+i}^+, w_{r-1-i}^-\}$ . If  $d(w_1, w_{p-1+i}^+) = d(w_1, w_{r-1-i}^-)$ , then  $d_1 = d(w_1, w_{p-1+i})$  and so  $d_2 = d(w_1, w_{r-1-i})$ . Thus p-1+i-1=1+p+r-(r-1-i) and -2=2, a contradiction. This concludes the proof.

<span id="page-13-0"></span>The following statement is a consequence of Lemma 16.

![](_page_14_Picture_0.jpeg)

Figure 3: Edge metric generators from Lemma [16.](#page-10-1)

<span id="page-14-0"></span>Theorem 17 Let G be a Θ-graph such that G 6= Θ1,2,<sup>2</sup> and Θp,p,q for 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Then edim(G) = 2.

Proof. First suppose that p < q. If p + r is even then r ≥ 3, so Lemma [16.](#page-10-1)i) covers this case. On the other hand if p+r is odd then r ≥ p+ 1, so Lemma [16.](#page-10-1)ii) and Lemma [16.](#page-10-1)iii) cover all cases except Θ1,2,2.

Now suppose that p = q. Then Lemma [16.](#page-10-1)v) covers all cases except Θp,p,p, Θp,p,p+1 and Θp,p,p+2. These remaining cases are covered by Lemma [16.](#page-10-1)iv) when p ≥ 4. Hence, uncovered cases are Θ2,2,2, Θ2,2,3, Θ2,2,4, Θ3,3,3, Θ3,3,<sup>4</sup> and Θ3,3,5.

Supporting our motivation, Theorem [17](#page-13-0) yields the following corollary.

Corollary 18 Let G be a Θ-graph such that G 6= Θ1,2,<sup>2</sup> and Θp,p,q for 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Then edim(G) < 2c(G) − 1.

## 4 Further work

In this paper we investigated Conjecture [3](#page-1-0) (resp. Conjecture [4\)](#page-1-1), which states that the vertex (resp. the edge) metric dimension of a graph G 6= C<sup>n</sup> with δ(G) ≥ 2 is bounded above by 2c(G) − 1. It was established in [\[23\]](#page-18-5) that the conjectures hold for cacti without leaves, and that for other leafless graphs the problem reduces to 2-connected graphs, i.e., if the conjectures hold for 2-connected graps distinct from a cycle then they hold in general. In this paper we considered Θ-graphs, since they are the most simple 2-connected graps distinct from cycles. We established that Conjectures [3](#page-1-0) and [4](#page-1-1) hold on this class of graphs and we characterized all Θ-graphs for which the upper bound is attained.

Besides Θ-graphs attaining the upper bound 2c(G) − 1, it was previously established that the same upper bound is also attained by metric dimensions of some leafless cacti. To be more precise, a daisy graph is any graph consisting of at least two cycles which all share the same vertex. A cycle in a daisy graph is also called a petal. Now, it was established that dim(G) attains the bound 2c(G) − 1 if G is a daisy graph without odd petals, and that edim(G) reaches the same bound for any daisy graph G. We expect that these graphs are the only graphs with δ(G) ≥ 2 whose metric dimensions reach the bound. So we conclude the paper by stating the following two conjectures.

<span id="page-15-0"></span>Conjecture 19 Let G be a connected graph with δ(G) ≥ 2. Then dim(G) = 2c(G) − 1 if and only if G is a daisy graph without odd petals, G = Θp,p,p or G = Θp,p,p+2.

<span id="page-15-1"></span>Conjecture 20 Let G be a connected graph with δ(G) ≥ 2. Then edim(G) = 2c(G)−1 if and only if G is a daisy graph, G = Θ1,2,<sup>2</sup> or G = Θp,p,q with 2 ≤ p ≤ 3 and p ≤ q ≤ p+ 2.

Similarly as with Conjectures [3](#page-1-0) and [4,](#page-1-1) we show in the next proposition that the above two conjectures reduce to the same problem on 2-connected graphs. In order to do so we will use a result from [\[23\]](#page-18-5), which states that c(G) = c(G1) + · · · + c(Gq) where G1, . . . , G<sup>q</sup> is the complete list of blocks of G.

Proposition 21 If Conjecture [19](#page-15-0) (resp. Conjecture [20\)](#page-15-1) holds for 2-connected graphs, then it holds in general.

Proof. We say that G is vertex extremal, if G = Θp,p,p or G = Θp,p,p+2. We say G is edge extremal if G = Θ1,2,<sup>2</sup> or G = Θp,p,q for 2 ≤ p ≤ 3 and p ≤ q ≤ p + 2. Now, let G be a graph with δ(G) ≥ 2 which is not 2-connected. According to Lemma [5,](#page-2-1) the equality dim(G) = 2c(G) − 1 (resp. edim(G) = 2c(G) − 1) may hold only when every non-trivial block of G distinct from a cycle is vertex extremal (resp. edge extremal) and all blocks of G share a vertex.

We shall now construct a vertex (resp. an edge) metric generator in such a graph whose size is smaller than 2c(G) − 1, which is sufficient to prove the claim. Let v be a vertex of G shared by all blocks in G. Let us assume G1, . . . , G<sup>q</sup> are all non-trivial blocks in G denoted so that G<sup>i</sup> is a cycle whenever i > p. According to Lemma [7](#page-4-0) (resp. Lemma [10\)](#page-5-0), for 1 ≤ i ≤ p there is a vertex (resp. an edge) metric generator S 0 i in G<sup>i</sup> such that v ∈ S 0 i , and for such i let us denote S<sup>i</sup> = S 0 <sup>i</sup>\{v}. For i > p, let S<sup>i</sup> consist of a single vertex which is a neighbor of v in G<sup>i</sup> . Now, let S = S<sup>1</sup> ∪ · · · ∪ Sq. Observe that the set S distinguishes in G all pairs of vertices (resp. edges) which belong to the same block of G, this follows from the fact that a pair of vertices (resp. edges) which is distinguished by v in G<sup>i</sup> is in G distinguished by every vertex s ∈ S\V (Gi).

By above, a pair of vertices (resp. edges) x and x 0 is not distinguished by S in G only if x belongs to G<sup>i</sup> and x <sup>0</sup> belongs to G<sup>j</sup> , i 6= j. In such a case we say G<sup>i</sup> and G<sup>j</sup> are critically incident. So let G<sup>i</sup> and G<sup>j</sup> are critically incident with x ∈ V (Gi), x <sup>0</sup> ∈ V (G<sup>j</sup> ) such that x and x <sup>0</sup> are not distinguished by S. Let further s ∈ S<sup>i</sup> and s <sup>0</sup> ∈ S<sup>j</sup> . Then d(s,x) = d(s,x') and d(s',x) = d(s',x'). Denote a = d(s,v), b = d(v,x), c = d(s',v) and d = d(v,x'). Then

$$(a+d) + (c+b) = d(s,x') + d(s',x) = d(s,x) + d(s',x')$$
  
$$\leq d(s,v) + d(v,x) + d(s',v) + d(v,x') = a+b+c+d,$$

and so a shortest path from x (resp. x') to every vertex from  $S_i$  (resp.  $S_j$ ) leads through v. Hence b = d and a = c.

If b > 1 then let  $x_1$  (resp.  $x'_1$ ) be a neighbor of x (resp. x') on a shortest path from v to x (resp. x'). Then for every  $s^* \in S_i \cup S_j$  we have  $d(s^*, x_1) = d(s^*, x'_1) = a + b - 1$ , so  $x_1$  and  $x'_1$  are not distinguished by S as well.

Finally, let  $x_2$  and  $x_2'$  be another pair of vertices which is not distinguished by S,  $x_2 \in V(G_i)$  and  $x_2' \in V(G_j)$ , and let  $d(v, x_2) = d(v, x)$ . Then x and  $x_2$  are not distinguished by  $S_i$ , which means that  $x_2 = x$  and analogously  $x_2' = x'$ .

Thus vertices  $y \in V(G_i)$ , for which there exists  $y' \in V(G_j)$  such that y, y' is a pair not distinguished by S, form a path starting at a neighbor of v. Denote this neighbor by z. If there is  $k \neq j$  such that  $G_i$  and  $G_k$  are critically incident as well, then again vertices  $y \in V(G_i)$ , for which there exists  $y^* \in V(G_k)$  such that  $y, y^*$  is a pair not distinguished by S, form a path starting at z. So it is sufficient to add z to  $S_i$  and all pairs of vertices from  $G_i$  and  $G_k$  (as well as from  $G_i$  and  $G_j$ ) will be distinguished.

We conclude that it is sufficient to introduce to S at most q-1 vertices, and all pairs x and x' from distinct blocks will also be distinguished by S. Consequently, since  $|S_i| = \dim(G_i) - 1$  we have

$$\dim(G) \le \sum_{i=1}^{q} (\dim(G_i) - 1) + q - 1 = \sum_{i=1}^{q} \dim(G_i) - 1$$
$$= \sum_{i=1}^{p} (2c(G_i) - 1) + \sum_{i=p+1}^{q} 2c(G_i) - 1 = 2c(G) - p - 1$$

which is obviously smaller than 2c(G) - 1 for  $p \ge 1$ . If p = 0, then G is a cactus graph and for cacti it was already established that the bound is attained only for daisy graphs without odd petals. The proof for  $\operatorname{edim}(G)$  is analogous.

Acknowledgments. The first author aknowledges partial support by Slovak research grants VEGA 1/0567/22, VEGA 1/0206/20, APVV-19-0308, APVV-17-0428. The second author acknowledges the support of Project KK.01.1.1.02.0027, a project co-financed by the Croatian Government and the European Union through the European Regional Development Fund - the Competitiveness and Cohesion Operational Programme. All authors acknowledge partial support of the Slovenian research agency ARRS program P1-0383 and ARRS project J1-1692.

#### References

<span id="page-16-0"></span>[1] P. S. Buczkowski, G. Chartrand, C. Poisson, P. Zhang, On k-dimensional graphs and their bases, *Period. Math. Hungar.* **46(1)** (2003) 9–15.

- <span id="page-17-2"></span>[2] G. Chartrand, L. Eroh, M. A. Johnson, O. R. Oellermann, Resolvability in graphs and the metric dimension of a graph, Discrete Appl. Math. 105 (2000) 99–113.
- <span id="page-17-3"></span>[3] M. Dudenko, B. Oliynyk, On unicyclic graphs of metric dimension 2, Algebra Discrete Math. 23(2) (2017) 216–222.
- <span id="page-17-4"></span>[4] M. Dudenko, B. Oliynyk, On unicyclic graphs of metric dimension 2 with vertices of degree 4, Algebra Discrete Math. 26(2) (2018) 256–269.
- <span id="page-17-5"></span>[5] M. Fehr, S. Gosselin, O. R. Oellermann, The metric dimension of Cayley digraphs, Discrete Math. 306 (2006) 31–41.
- <span id="page-17-9"></span>[6] J. Geneson, Metric dimension and pattern avoidance in graphs, Discrete Appl. Math. 284 (2020) 1–7.
- <span id="page-17-0"></span>[7] F. Harary, R. A. Melter, On the metric dimension of a graph, Ars Combin. 2 (1976) 191–195.
- <span id="page-17-10"></span>[8] Y. Huang, B. Hou, W. Liu, L. Wu, S. Rainwater, S. Gao, On approximation algorithm for the edge metric dimension problem, Theoret. Comput. Sci. (2020), doi:https://doi.org/10.1016/j.tcs.2020.05.005.
- [9] A. Kelenc, D. Kuziak, A. Taranenko, I. G. Yero, Mixed metric dimension of graphs, Appl. Math. Comput. 314(1) (2017) 429–438.
- <span id="page-17-8"></span>[10] A. Kelenc, N. Tratnik, I. G. Yero, Uniquely identifying the edges of a graph: the edge metric dimension, Discrete Appl. Math. 251 (2018) 204–220.
- <span id="page-17-1"></span>[11] S. Khuller, B. Raghavachari, A. Rosenfeld, Landmarks in graphs, Discrete Appl. Math. 70 (1996) 217–229.
- <span id="page-17-11"></span>[12] S. Klavˇzar, M. Tavakoli, Edge metric dimensions via hierarchical product and integer linear programming, Optim. Lett. 15(10) (2021) 1–11.
- <span id="page-17-6"></span>[13] D. J. Klein, E. Yi, A comparison on metric dimension of graphs, line graphs, and line graphs of the subdivision graphs, Eur. J. Pure Appl. Math. 5(3) (2012) 302–316.
- <span id="page-17-12"></span>[14] M. Knor, S. Majstorovi´c, A. T. M. Toshi, R. Skrekovski, I. G. Yero, Graphs with the ˇ edge metric dimension smaller than the metric dimension, Appl. Math. Comput. 401 (2021) 126076.
- <span id="page-17-14"></span>[15] D. Kuziak, I. G. Yero, Metric dimension related parameters in graphs: A survey on combinatorial, computational and applied results, [arXiv:2107.04877,](http://arxiv.org/abs/2107.04877) 2021.
- <span id="page-17-7"></span>[16] R. A. Melter, I. Tomescu, Metric bases in digital geometry, Comput. Vis. Graph. Image Process. 25 (1984) 113–121.
- <span id="page-17-13"></span>[17] I. Peterin, I. G. Yero, Edge metric dimension of some graph operations, Bull. Malays. Math. Sci. Soc. 43 (2020) 2465–2477.

- <span id="page-18-0"></span>[18] C. Poisson, P. Zhang, The metric dimension of unicyclic graphs, J. Combin. Math. Combin. Comput. 40 (2002) 17–32.
- [19] J. Sedlar, R. Skrekovski, Bounds on metric dimensions of graphs with edge disjoint ˇ cycles, Appl. Math. Comput. 396 (2021) 125908.
- <span id="page-18-6"></span>[20] J. Sedlar, R. Skrekovski, Extremal mixed metric dimension with respect to the cy- ˇ clomatic number, Appl. Math. Comput. 404 (2021) 126238.
- <span id="page-18-7"></span>[21] J. Sedlar, R. Skrekovski, Mixed metric dimension of graphs with edge disjoint cycles, ˇ Discrete Appl. Math. 300 (2021) 1–8.
- <span id="page-18-4"></span>[22] J. Sedlar, R. Skrekovski, Vertex and edge metric dimensions of cacti, ˇ [arXiv:2107.01397](http://arxiv.org/abs/2107.01397) [math.CO].
- <span id="page-18-5"></span>[23] J. Sedlar, R. Skrekovski, Metric dimensions vs. cyclomatic number of graphs with ˇ minimum degree at least two, [arXiv:2108.09573](http://arxiv.org/abs/2108.09573) [math.CO].
- [24] J. Sedlar, R. Skrekovski, Vertex and edge metric dimensions of unicyclic graphs, ˇ [arXiv:2104.00577](http://arxiv.org/abs/2104.00577) [math.CO].
- <span id="page-18-1"></span>[25] Y. Zhang, S. Gao, On the edge metric dimension of convex polytopes and its related graphs, J. Comb. Optim. 39(2) (2020) 334–350.
- <span id="page-18-2"></span>[26] E. Zhu, A. Taranenko, Z. Shao, J. Xu, On graphs with the maximum edge metric dimension, Discrete Appl. Math. 257 (2019) 317–324.
- <span id="page-18-3"></span>[27] N. Zubrilina, On the edge dimension of a graph, Discrete Math. 341(7) (2018) 2083– 2088.