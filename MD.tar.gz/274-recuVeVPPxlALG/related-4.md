## The Moore bound for irregular graphs

Noga Alon \* Shlomo Hoory † Nathan Linial ‡
February 22, 2002

## Abstract

What is the largest number of edges in a graph of order n and girth g? For d-regular graphs, essentially the best known answer is provided by the Moore bound. This result is extended here to cover irregular graphs as well, yielding an affirmative answer to an old open problem ([4] p.163, problem 10).

What is the maximal number of edges in a graph with n vertices and girth g? Put differently, what is the least number of vertices n = n(d, g) in a graph of girth g and an average degree  $\geq d$ ?

If d is an integer, it is natural to compare the lower bound on n, to what is known for d-regular graphs. The lower bound for d-regular graphs arises from the fact the ball of radius  $\lfloor \frac{g-1}{2} \rfloor$  around a vertex or an edge (depending on the parity of g) is a tree. This simple argument yields the so-called *Moore bound* denoted by  $n_0(d,g)$  (see [2], p. 180), where:

$$n_0(d, 2r+1) = 1 + d \sum_{i=0}^{r-1} (d-1)^i$$

$$n_0(d, 2r) = 2 \sum_{i=0}^{r-1} (d-1)^i$$

<sup>\*</sup>Mathematics and Computer Science, Sackler Faculty of Exact Sciences, Tel Aviv University, Tel Aviv, Israel. Email: noga@math.tau.ac.il. Supported in part by a US-Israel BSF grant, by a grant from the Israel Science Foundation and by the Hermann Minkowski Minerva Center for Geometry at Tel Aviv University.

 $<sup>^{\</sup>dagger}$ Institute of Computer Science, Hebrew University, Jerusalem 91904 Israel. Email: shlomoh@cs.huji.ac.il

<sup>&</sup>lt;sup>‡</sup>Institute of Computer Science, Hebrew University, Jerusalem 91904 Israel. Email: nati@cs.huji.ac.il. Supported in part by grants from the US-Israel Binational Science Fund and from the Israel Science Foundation.

This simple lower bound is difficult to improve upon. There are graphs that achieve equality, but only for  $g \in \{3, 4, 5, 6, 8, 12\}$ , (see [2] Theorem 23.6, and the survey [7]). Some further improvement (only by +2) was achieved in [1, 3, 6]. In this note we show that the Moore bound holds also for irregular graphs. This result has been conjectured long ago and it appears in Bollobás' "Extremal graph theory" [4], p.163 problem 10.

**Theorem 1** The number of vertices n in a graph of girth g and average degree at least  $d \geq 2$ , satisfies:

$$n(d,g) \ge n_0(d,g)$$
.

Note 1 When d is an integer Theorem 1 is exactly the Moore bound. If d is not an integer, or when the degree sequence of the graph is known, our proof yields a better bound (see the proof for details).

**Note 2** This bound is exponentially bigger (in g) than the previously known lower bound on n given in [5] (the result there is stated as an upper bound on g):

$$n \ge 4\lfloor \frac{d}{2} \rfloor^{\frac{g-2}{2}}.$$

## **Proof:**

Let G be a graph with n vertices, girth g and an average degree  $\overline{d} \geq d$ . Vertices of degree 0 and 1 can be ignored: If we delete all the vertices of degree < 2, the resulting graph G' has  $n' \leq n$  vertices, girth g' = g and an average degree  $\overline{d'} \geq \overline{d} \geq d$ . If we prove the theorem for G', then by monotonicity of  $n_0$ :

$$n \ge n' \ge n_0(\overline{d'}, g') \ge n_0(d, g),$$

proving the theorem for G. Henceforth we assume then w.l.o.g. that all vertex degrees in G are at least 2.

Consider each edge of G as a pair of directed edges, and let A be the  $n\overline{d}\times n\overline{d}$  matrix indexed by directed edges:

$$(A)_{\vec{uv},\vec{wz}} = \begin{cases} 1 & v = w \text{ and } u \neq z \\ 0 & \text{otherwise} \end{cases}$$

Also, let the matrix P be defined by:

$$(P)_{\vec{uv},\vec{wz}} = \begin{cases} \frac{1}{d_v - 1} & v = w \text{ and } u \neq z \\ 0 & \text{otherwise} \end{cases}$$

where  $d_v$  is the degree of the vertex v. The matrix P is the transition matrix of the non-returning random walk. The state space of this walk is the set of directed edges, and if at time t the walk is at the edge  $\vec{uv}$  (we sometime say that the walk is at the vertex v coming from u), then at time t+1 we move to an edge  $v\vec{w}$ , where w is a random neighbor of v that is not u.

Let  $x = \frac{1}{nd}\overline{1}$  be the uniform distribution on the directed edges. It can be easily verified that x is a stationary distribution for the non-returning random walk, i.e., xP = x.

Let  $\Omega_{e,l}$  be the set of all length l non-returning walks starting at the edge e, and let the number of these walks be  $N_{e,l} = |\Omega_{e,l}|$ . Define also,  $N_l$  as:

$$N_l = \sum_{e} x_e N_{e,l} = \langle xA^l, \overline{1} \rangle. \tag{1}$$

For any walk  $\omega = \{e_0 = e, e_1, \dots, e_l\} \in \Omega_{e,l}$ , denote by  $n_f(\omega)$ , the number of occurrences of f among  $e_0, e_1, \dots, e_{l-1}$ . Finally, let  $p(\omega)$  be the probability of the walk  $\omega$ , namely:

$$p(\omega) = \prod_{\vec{uv}} (d_v - 1)^{-n_{\vec{uv}}(\omega)}.$$
 (2)

We can now give a lower bound on  $N_l$ . First we rewrite (1) and then use the inequality of the arithmetic and geometric means:

$$N_l = \sum_e x_e \sum_{\omega \in \Omega_{e,l}} p(\omega) \frac{1}{p(\omega)} \ge \prod_e \prod_{\omega \in \Omega_{e,l}} (\frac{1}{p(\omega)})^{x_e p(\omega)}.$$

Using (2), this becomes:

$$N_l \ge \prod_{\vec{uv}} (d_v - 1)^{\sum_e x_e \sum_{\omega \in \Omega_{e,l}} n_{\vec{uv}}(\omega) p(\omega)}.$$

The sum in the exponent of the rhs is exactly the expected number of visits to the edge  $u\bar{v}$ , made by a non-returning random walk of length l starting with the initial distribution x:

$$N_{l} \geq \prod_{\vec{u}\vec{v}} (d_{v} - 1)^{\sum_{k=0}^{l-1} (xP^{k})_{\vec{u}\vec{v}}} = \prod_{\vec{u}\vec{v}} (d_{v} - 1)^{\sum_{k=0}^{l-1} \frac{1}{n\vec{d}}}$$
$$= \prod_{\vec{u}\vec{v}} (d_{v} - 1)^{\frac{l}{n\vec{d}}} = \left(\prod_{v} (d_{v} - 1)^{\frac{d_{v}}{n\vec{d}}}\right)^{l} = \Lambda^{l}$$

where  $\Lambda = \prod_v (d_v - 1)^{\frac{d_v}{nd}}$ . Since the function  $f(d) = (d-1)^d$  is log convex for  $d \ge 2$ , it implies that  $\Lambda \ge \overline{d} - 1 \ge d - 1$ .

To prove the theorem, we consider two cases:

• If the girth is odd g = 2r + 1, consider the matrix:

$$C = \sum_{i=0}^{r} A^{i} + M \sum_{i=0}^{r-1} A^{i},$$

where M is the  $n\overline{d} \times n\overline{d}$  permutation matrix that matches each edge to its inverse:

$$(M)_{\vec{uv},\vec{wz}} = \begin{cases} 1 & v = w \text{ and } u = z \\ 0 & \text{otherwise} \end{cases}$$

For every  $u\bar{v}$  and z, the number  $\sum_{w:w\sim z} C_{u\bar{v},w\bar{z}}$  is either zero or one. This follows from the fact that  $\sum_{w:w\sim z} \left(\sum_{i=0}^r A^i\right)_{u\bar{v},w\bar{z}}$  is the number of non-returning walks from v to z of length  $\leq r$  whose first move is not  $v\bar{u}$ , and that  $\sum_{w:w\sim z} \left(M\sum_{i=0}^{r-1} A^i\right)_{u\bar{v},w\bar{z}}$  is the number of non-returning walks from v to z of length  $\leq r$  whose first move is  $v\bar{u}$ . Therefore  $\sum_{w:w\sim z} C_{u\bar{v},w\bar{z}}$  is the total number of non-returning walks from v to z of length  $\leq r$ . There is at most one such walk since no cycle of length < g exists in the graph.

Therefore for every edge  $\vec{uv}$ ,

$$n \ge \sum_{\vec{wz}} C_{\vec{uv}, \vec{wz}},$$

and therefore,

$$n \geq \langle xC, \overline{1} \rangle = \sum_{i=0}^{r} N_i + \sum_{i=0}^{r-1} N_i$$
$$\geq \sum_{i=0}^{r} \Lambda^i + \sum_{i=0}^{r-1} \Lambda^i = n_0(\Lambda + 1, g) \geq n_0(d, g).$$

The last inequality follows from our observation that  $\Lambda \geq d-1$  and the monotonicity of  $n_0$ .

• If the girth is even g = 2r, then consider the matrix:

$$D = (I + M) \sum_{i=0}^{r-1} A^{i}.$$

By similar considerations:

$$n \ge \langle xD, \overline{1} \rangle \ge n_0(\Lambda + 1, g) \ge n_0(d, g).$$

**Note 3** The above proof actually shows that  $n \ge n_0(\Lambda + 1, g)$ , where  $\Lambda = \prod_v (d_v - 1)^{\frac{d_v}{nd}}$ . The graph of n/g cycles of length g having a common vertex, demonstrates that this bound is nearly tight.

## References

- [1] E. Bannai and T. Ito. Regular graphs with excess one. Discrete Math., 37(2-3):147– 158, 1981.
- [2] N. Biggs. Algebraic graph theory. Cambridge University Press, Cambridge, second edition, 1993.
- [3] N. Biggs and T. Ito. Graphs with even girth and small excess. Math. Proc. Cambridge Philos. Soc., 88(1):1–10, 1980.
- [4] B. Bollob´as, Extremal graph theory. Academic Press Inc. [Harcourt Brace Jovanovich Publishers], London, 1978.
- [5] R. D. Dutton and R. C. Brigham. Edges in graphs with large girth. Graphs Combin., 7(4):315–321, 1991.
- [6] P. Kov´acs. The nonexistence of certain regular graphs of girth 5. J. Combin. Theory Ser. B, 30(3):282–284, 1981.
- [7] P. K. Wong. Cages—a survey. J. Graph Theory, 6(1):1–22, 1982.