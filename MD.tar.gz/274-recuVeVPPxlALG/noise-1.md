![](_page_0_Picture_0.jpeg)

# Brooks' Theorem in Graph Streams: A Single-Pass Semi-Streaming Algorithm for $\Delta$ -Coloring

Sepehr Assadi\* Rutgers University USA Pankaj Kumar<sup>†</sup> Charles University Czechia Parth Mittal<sup>‡</sup>
Rutgers University
USA

sepehr.assadi@rutgers.edu

pankaj@kam.mff.cuni.cz

parth.mittal@rutgers.edu

#### **ABSTRACT**

Every graph with maximum degree  $\Delta$  can be colored with  $(\Delta + 1)$  colors using a simple greedy algorithm. Remarkably, recent work has shown that one can find such a coloring even in the semi-streaming model: there exists a randomized algorithm that with high probability finds a  $(\Delta + 1)$ -coloring of the input graph in only  $O(n \cdot \text{polylog } n)$  space assuming a single pass over the edges of the graph in any arbitrary order. But, in reality, one almost never needs  $(\Delta + 1)$  colors to properly color a graph. Indeed, the celebrated **Brooks' theorem** states that every (connected) graph beside cliques and odd cycles can be colored with  $\Delta$  colors. Can we find a  $\Delta$ -coloring in the semi-streaming model as well?

We settle this key question in the affirmative by designing a randomized semi-streaming algorithm that given any graph, with high probability, either correctly declares that the graph is not  $\Delta$ -colorable or outputs a  $\Delta$ -coloring of the graph.

The proof of this result starts with a detour. We first (provably) identify the extent to which the previous approaches for streaming coloring fail for  $\Delta$ -coloring: for instance, all these approaches can handle streams with repeated edges and they can run in  $o(n^2)$  time – we prove that neither of these tasks is possible for  $\Delta$ -coloring. These impossibility results however pinpoint exactly what is missing from prior approaches when it comes to  $\Delta$ -coloring.

We then build on these insights to design a semi-streaming algorithm that uses (i) a novel sparse-recovery approach based on sparse-dense decompositions to (partially) recover the "problematic" subgraphs of the input—the ones that form the basis of our impossibility results—and (ii) a new coloring approach for these

Permission to make digital or hard copies of all or part of this work for personal or classroom use is granted without fee provided that copies are not made or distributed for profit or commercial advantage and that copies bear this notice and the full citation on the first page. Copyrights for components of this work owned by others than the author(s) must be honored. Abstracting with credit is permitted. To copy otherwise, or republish, to post on servers or to redistribute to lists, requires prior specific permission and/or a fee. Request permissions from permissions@acm.org.

STOC '22, June 20-24, 2022, Rome, Italy

© 2022 Copyright held by the owner/author(s). Publication rights licensed to ACM. ACM ISBN 978-1-4503-9264-8/22/06... \$15.00

https://doi.org/10.1145/3519935.3520005

#### CCS CONCEPTS

 Theory of computation → Streaming, sublinear and near linear time algorithms; Graph algorithms analysis.

subgraphs that allows for recoloring of other vertices in a controlled way without relying on local explorations or finding "augmenting

paths" that are generally impossible for semi-streaming algorithms.

We believe both these techniques can be of independent interest.

#### **KEYWORDS**

streaming algorithms, graph coloring, brooks' theorem

#### **ACM Reference Format:**

Sepehr Assadi, Pankaj Kumar, and Parth Mittal. 2022. Brooks' Theorem in Graph Streams: A Single-Pass Semi-Streaming Algorithm for Δ-Coloring. In *Proceedings of the 54th Annual ACM SIGACT Symposium on Theory of Computing (STOC '22), June 20–24, 2022, Rome, Italy*. ACM, New York, NY, USA, 14 pages. https://doi.org/10.1145/3519935.3520005

# 1 INTRODUCTION

Graph coloring problems are ubiquitous in graph theory and computer science. Given a graph G=(V,E), a proper c-coloring of G is any assignment of colors from the palette  $\{1,\ldots,c\}$  to the vertices so that no edge receives the same color on both its endpoints. Recent years have witnessed a flurry of results for graph coloring in the graph streaming model [3,5,6,11-14,19,33,52]. In this model, the edges of the input graph arrive one by one in an arbitrarily ordered stream and the algorithm needs to process these edges sequentially using a limited space, much smaller than the input size. Of particular interest are semi-streaming algorithms, introduced by [27], that use only  $\widetilde{O}(n) := O(n \cdot polylog n)$  space  $^1$  on n-vertex graphs which is proportional to the output size. We focus on this model.

One of the simplest forms of graph coloring problems is  $(\Delta+1)$ -coloring of graphs with maximum degree  $\Delta$ . Not only does every graph admits a  $(\Delta+1)$ -coloring, but we can find one quite easily via a greedy algorithm: iterate over the vertices and color each one from any of  $(\Delta+1)$  colors that has not appeared in any of its at most  $\Delta$  colored neighbors. Yet, despite its simplicity, this algorithm does not easily lend itself to a semi-streaming algorithm as the arbitrary arrival of edges prohibits us from coloring vertices one at a time.

 $<sup>^*\</sup>mbox{Research}$  supported in part by the NSF CAREER grant CCF-2047061 and a gift from Google Research.

 $<sup>^\</sup>dagger$  Supported by GAČR grant 19-27871X. Part of this research was carried out while this author was a participant in the 2020 DIMACS REU program, supported by CoSP, a project funded by European Union's Horizon 2020 research and innovation program, grant 823748.

<sup>\*</sup>Research supported in part by the NSF CAREER grant CCF-2047061. Part of this research was carried out while this author was a participant in the 2020 DIMACS REU program, supported by CoSP, a project funded by European Union's Horizon 2020 research and innovation program, grant 823748.

<span id="page-0-0"></span><sup>&</sup>lt;sup>1</sup>Throughout, we use  $\widetilde{O}(f) \coloneqq O(f \cdot \operatorname{poly} \log f)$  to suppress  $\operatorname{poly} \log (f)$  factors.

Nonetheless, a breakthrough of [6] showed that  $(\Delta+1)$  coloring is still possible in the semi-streaming model, albeit via a randomized algorithm that employs a "non-greedy" approach. In particular, [6] proved the following *palette sparsification theorem*: if we sample  $O(\log n)$  colors from  $\{1,\ldots,\Delta+1\}$  for each vertex independently, then with high probability, the entire graph can be colored by coloring each vertex from its own sampled colors. This result leads to a semi-streaming algorithm for  $(\Delta+1)$ -coloring: sample these colors for each vertex and store any edge in the stream that can potentially become monochromatic under any coloring of vertices from their sampled list. A simple probabilistic analysis bounds the number of stored edges by  $O(n\log^2 n)$  with high probability, and the palette sparsification theorem guarantees that one can find a  $(\Delta+1)$ -coloring of the graph at the end of the stream.

Going back to existential results, it is easy to see that there are graphs that do need  $\Delta+1$  colors for proper coloring, for instance  $(\Delta+1)$ -cliques or odd cycles (where  $\Delta=2$ ). The celebrated **Brooks' theorem** [17] states that these two are the only examples: any (connected) graph besides cliques and odd cycles can be colored with  $\Delta$  colors (see also [43] and [41] for other classical proofs of this result by Melnikov and Vizing, and by Lovász, respectively). Unlike existence of  $(\Delta+1)$  colorings which is rather a triviality, Brooks' theorem turned out to be a fundamental result in graph coloring [45, 56] with numerous proofs discovered for it over the years; see, e.g. [22, 50, 51, 56] and references therein. The algorithmic aspects of Brooks' theorem have also been studied extensively in classical algorithms [8, 41, 55], PRAM algorithms [30, 37, 38, 48], or LOCAL algorithms [16, 29, 47].

Given the key role Brooks' theorem plays in graph coloring literature on one hand, and the recent advances on streaming coloring algorithms on the other hand, it is thus quite natural to ask:

Does there exist a "semi-streaming Brooks' theorem", namely, a semi-streaming algorithm that colors any given graph, besides cliques and odd cycles, with  $\Delta$  colors?

This is precisely the question addressed in this paper. We emphasize that our interest in this question is not in "shaving off" a single color from  $(\Delta + 1)$ -coloring to  $\Delta$ -coloring in practice, but rather as a source of insights and ideas (as is the case, say, in graph theory or classical algorithms where  $(\Delta + 1)$ -coloring is just a triviality). In fact,  $\Delta$ -coloring appears to be just beyond the reach of our current techniques. For instance, previous streaming coloring algorithms in [3, 6, 12] can all be obtained via palette sparsification (see [3] for details). Yet, it was already observed in [6] that palette sparsification cannot handle  $\Delta$ -coloring (we elaborate on this later). More generally, while  $(\Delta+1)$ -coloring has a strong "greedy nature", all existential/algorithmic proofs of Δ-coloring are based on "exploring" the graph for certain structures, say cut vertices or certain spanning trees [41], Kempe Chains [43], Rubin's Block Lemma [4, 26], or "augmenting paths" [48] to name a few (we refer the interested reader to [56] for an excellent overview of various proofs of Brooks' theorem). These (local) exploration tasks however are generally impossible in the semi-streaming model<sup>2</sup>.

#### 1.1 Our Contributions

We start with studying the *limitations* of the current approaches in streaming graph coloring for solving  $\Delta$ -coloring. To do so, we focus on two common characteristics of all prior algorithms in [3, 6, 12]: they all also naturally lead to (i) *sublinear-time* algorithms for the corresponding coloring problems that run in  $(n^{3/2+o(1)})$  time, and (ii) semi-streaming algorithms that can handle *repeated-edge* streams wherein the same edge may appear more than once. We prove that obtaining either type of algorithms is provably *impossible* for  $\Delta$ -coloring:

- Sublinear-time algorithms: Any algorithm that, given access to adjacency lists and adjacency matrix of a graph with known maximum degree  $\Delta$ , can output a  $\Delta$ -coloring with large constant probability requires  $\Omega(n\Delta)$  queries to input and time.
- **Repeated-edge streams:** Any algorithm that, given the edges of a graph with known maximum degree  $\Delta$  in a *repeated-edge* stream, can output a  $\Delta$ -coloring with large constant probability requires  $\Omega(n\Delta)$  space.

These impossibility results already demonstrate how different  $\Delta\text{-coloring}$  is compared to prior graph coloring problems studied in the semi-streaming model. But, as we shall elaborate later, these results play a much more important role for us: they pinpoint what is missing from prior approaches when it comes to the  $\Delta\text{-coloring}$  problem and act as an excellent guide for addressing our motivating question. This brings us to the main contribution of our work.

<span id="page-1-1"></span>Theorem 1 (Semi-Streaming Brooks' Theorem). There exists a randomized semi-streaming algorithm that given any connected graph G = (V, E) with maximum degree  $\Delta$ , which is not a clique nor an odd-cycle, with high probability, outputs a  $\Delta$ -coloring of G.

Consequently, despite the fact that prior approaches inherently fail for  $\Delta\text{-coloring}$  in fundamental ways and that  $\Delta\text{-coloring}$  is provably intractable in closely related models, we can still obtain a semi-streaming Brooks' theorem and settle our motivating question in the affirmative. It is also worth mentioning that randomness in Theorem 1 is crucial: a very recent result of [5] shows that deterministic semi-streaming algorithms cannot even find an  $\exp\left(\Delta^{o\,(1)}\right)$ -coloring. Our Theorem 1 thus fully settles the complexity of the  $\Delta\text{-coloring}$  problem in the semi-streaming model.

Theorem 1 can be stated more generally as an algorithm that either decides whether the input graph is  $\Delta$ -colorable or not, and if yes, outputs the coloring. This is because checking whether a graph is  $\Delta$ -colorable can be done by simply storing a spanning forest of the input (see, e.g., [27]) and maintaining the degrees of vertices; this allows us to check whether any of the connected components in the graph is a  $(\Delta+1)$ -clique or an odd-cycle. If not, applying Theorem 1 to each connected component of the graph (in parallel in a single pass) gives us the desired  $\Delta$ -coloring (the algorithm does not even require the prior knowledge of  $\Delta$  using a standard trick observed in [6]; see Remark 4.17). However, we find the statement of Theorem 1 to best capture the most interesting part of the result and thus opted to present it in this form.

<span id="page-1-0"></span><sup>&</sup>lt;sup>2</sup>For instance, while computing all neighbors of a given vertex is trivial via a semistreaming algorithm (by storing edges of the vertex), it is even impossible to discover the two-hop neighborhood of a given vertex [28].

Our Techniques. We shall go over our techniques in detail in the streamlined overview of our approach in Section 2. For now, we only mention the three main technical ingredients of our work:

- i). A thorough understanding of the powers and limitations of the palette sparsification approach of [6] for Δ-coloring via a rough characterization of which (sub)graphs it still applies to:
- ii). An algorithm for *implicitly* identifying and storing "problematic" subgraphs of the input graph—the ones that cannot be handled by palette sparsification approach of previous step—via a novel sparse recovery approach that relies on *algorithmic* use of sparse-dense decompositions (see Section 3.1) in place of their *analytic* use in prior streaming algorithms [3, 6];
- iii). A new coloring procedure that combines simple graph theoretic ideas with probabilistic analysis of palette sparsification using a notion of helper structures; these are simple subgraphs of the input that can be recovered via our semistreaming algorithms from the previous part and does not rely on local exploration steps of prior proofs of Brooks' theorem mentioned earlier.

Other Sublinear Algorithms Models. Prior semi-streaming algorithms for graph coloring also naturally lead to a series of algorithmic results for the respective problems in other models. Our first impossibility result already rules out this possibility for  $\Delta$ -coloring when it comes to sublinear-time algorithms. Nevertheless, our approach in Theorem 1 is still quite flexible and thus allows for extension of this algorithm to many other models. In particular, the algorithm is implemented via a linear sketch (see [42]), which immediately implies the following two results as well:

- **Dynamic streams:** There exists a (single-pass) randomized semi-streaming algorithm for Δ-coloring on the streams that contain insertion and deletion of edges.
- Massively parallel computation (MPC): There exist a oneround randomized MPC algorithm for  $\Delta$ -coloring on machines of memory  $\widetilde{O}(n)$  with only  $\widetilde{O}(n)$  extra global memory.

As this is not the focus of the paper, we omit the definition and details of the models and instead refer the interested to [2, 42] and [10, 39] for each model, respectively.

#### 1.2 Related Work

Similar to the classical setting, it is known that approximating the minimum number of colors for proper coloring, namely, the *chromatic number*, is intractable in the semi-streaming model [1, 21, 34]. Thus, recent work has focused instead on "combinatorially optimal" bounds—termed by [31]—for streaming coloring problems. On this front, we already discussed the  $(\Delta+1)$  coloring result of [6]. Independently and concurrently, [13] obtained a semi-streaming algorithm for  $O(\Delta)$  colorings. These results were followed by semi-streaming algorithms for other coloring problems such as degeneracy coloring [12], coloring locally sparse graphs and  $(\deg +1)$ -coloring [3],

(deg +1)-list coloring [33], adversarially robust coloring [19], edge-coloring (in W-streams)[11], deterministic lower bounds and (multipass) algorithms [5], and coloring verification problems [14]. Moreover, [3] studied various aspects of palette sparsification technique of [6] and showed that other semi-streaming coloring algorithms such as [12, 13] can also be obtained via this technique.

Many of these work on streaming algorithms for graph coloring also extend to other models such as sublinear-time and massively parallel computation (MPC) algorithms. For instance, for  $(\Delta+1)$  coloring, there are randomized sublinear-time algorithms in  $\widetilde{O}(n^{3/2})$  time [6] or deterministic MPC algorithms with O(1) rounds and O(n) per-machine memory [23] (see also [24]).

Numerous beautiful algorithmic results are known for  $\Delta$ -coloring problem in various other models such as classical algorithms [8, 41, 55], PRAM algorithms [30, 37, 38, 48], or LOCAL algorithms [9, 16, 29, 47]. For instance, a remarkable "distributed Brooks' theorem" of [48] proves that any partial  $\Delta$ -coloring of all but one vertex of the graph, can be turned into a proper  $\Delta$ -coloring of the entire graph by recoloring a single "augmenting path" of  $O(\log_{\Delta} n)$  length. Finally, it is worth mentioning that Brooks' theorem is part of a more general phenomenon in graph theory: as the maximum clique size in G moves further away from  $\Delta + 1$ , so does its chromatic number. For instance, [54] proves that for sufficiently large  $\Delta$ , if a graph does not contain a  $\Delta$ -clique, then it is in fact always ( $\Delta - 1$ )-colorable; see, e.g. [15, 40, 45, 46, 53, 54] and references therein for various other examples.

### <span id="page-2-0"></span>2 TECHNICAL OVERVIEW

We now give a streamlined overview of our approach. While Theorem 1 is by far the main contribution of our work, we find it illuminating to first talk about our impossibility results for  $\Delta$ -coloring as they, despite their simplicity, played a crucial role for us in obtaining Theorem 1 and we believe they can shed more light into different components of our final algorithm.

# <span id="page-2-1"></span>2.1 A Detour: Impossibility Results, Barriers, and Lessons Along the Way

**Palette sparsification.** Let us start with a review of the palette sparsification theorem of [6]: if we sample  $O(\log n)$  colors from  $\{1,\ldots,\Delta+1\}$  for each vertex independently, then with high probability, we can still color the graph by coloring each vertex from its sampled palette. The proof of this result in [6] uses a variant of *sparse-dense decomposition* [53] that partitions the graph into "(*locally*) *sparse*" vertices and a collection of "almost-clique" subgraphs that can be turned into  $(\Delta+1)$ -cliques by changing o(1) fraction of their vertices and edges (Figure 1a). The sparse vertices are then colored *one at a time* from their sampled lists using a standard greedy coloring argument originally introduced in [44]. The main part of the proof is to handle almost-cliques by going over them one by one and coloring each one *entirely*, using the sampled lists of *all* its vertices at the same time, even assuming the outside vertices are colored *adversarially*.

As expected, the hard part in extending palette sparsification theorem of [6] to  $\Delta$ -coloring involves the argument for almost-cliques.

<span id="page-3-0"></span>![](_page_3_Figure_2.jpeg)

Figure 1: A graph with maximum degree  $\Delta=4$  and its sparsedense decomposition in (a) (each box denotes an almost-clique and remaining vertices are sparse). Part (b) is an illustration of why palette sparsification fails for  $\Delta$ -coloring: the only way to  $\Delta$ -color this graph is to color the marked vertices the same, which cannot be done with these sampled lists. Part (c) shows a similar construction can be used to prove a query lower bound for  $\Delta$ -coloring. (the actual instance is obtained from  $\Theta(n/\Delta)$  copies of such pairs).

Indeed, this is not just a matter of analysis; as already observed by [6], this theorem fails for  $\Delta$ -coloring (Figure 1b): consider a  $(\Delta+1)$ -clique minus a single edge (u,v); the only way we can find a  $\Delta$ -coloring of this graph is if we color both u and v the same, which requires their sampled lists to intersect; by the birthday paradox this only happens when size of each list is  $\Omega(\sqrt{\Delta})$  which in turn implies that the algorithm has to store  $\Omega(n\Delta)$  edges from the stream – this is effectively the same as storing the input!

Sublinear time (query) algorithms. Consider a graph G which is a collection of  $\Theta(n/\Delta)$  pairs of  $(\Delta+1)$ -cliques. For each pair, randomly pick two vertices  $(u_1,v_1)$  and  $(u_2,v_2)$  from its first and second clique, respectively. Remove the edges  $(u_1,v_1)$  and  $(u_2,v_2)$  and instead include the edges  $(u_1,v_2)$  and  $(u_2,v_1)$  in the graph. See Figure 1c for an illustration. It is easy to see that the only way to  $\Delta$ -color this graph is to find the "switched" edges in each copy and color their endpoints the same inside each (now) almost-clique. Yet, it is an easy exercise to use the linear lower bound on the query complexity of OR function [18] to prove that this requires making  $\Omega(\Delta^2)$  queries to the adjacency lists or matrix of the graph for each pair, and thus  $\Omega(n\Delta)$  queries overall. This lower bound now leaves us with the following lesson.

<span id="page-3-1"></span>**Lesson 1.** Any semi-streaming algorithm for  $\Delta$ -coloring should explicitly *look at* all but a tiny fraction of edges of the graph presented in the stream.

Lesson 1 may sound trivial at first. After all, the semi-streaming model allows all algorithms to look at all edges of the graph. Yet,

<span id="page-3-2"></span>![](_page_3_Picture_8.jpeg)

Figure 2: An illustration of the hard instances for the repeated-edge stream lower bound – the actual instance is obtained from  $\Theta(n/\Delta)$  copies of these graphs. The only possible  $\Delta$ -coloring is to color both endpoints of marked vertices the same.

note that numerous semi-streaming algorithms, say, sampling algorithms, including all prior streaming coloring algorithms in [3, 6, 12, 33], do not use this power – Lesson 1 implies that these algorithms cannot solve  $\Delta$ -coloring.

Semi-streaming algorithms on repeated-edge streams. What if we take Lesson 1 to the extreme and give the algorithm each edge (potentially) multiple times in the stream – this should surely helps us even more? It turns out that this is not really the case.

Suppose that we have a graph G on a collection of  $\Theta(n/\Delta)$  disjoint sets of vertices of size  $\Delta+1$  each. For each set of  $\Delta+1$  vertices U, consider a stream of edges that in the first part, provides a subset  $E_1$  of edges over U and in the second part, provides another subset  $E_2$  – the repeated-edge stream allows these subsets to be overlapping and we shall choose them so that  $E_1 \cup E_2$  leaves precisely one pair of vertices (u,v) among all pairs in U without an edge. See Figure 2 for an illustration. As before, the only way to  $\Delta$ -color this graph is to color vertices u,v in each of the  $\Theta(n/\Delta)$  pieces the same. But, given that the edges between  $E_1$  and  $E_2$  may overlap, one can prove that finding all these pairs requires  $\Omega(n\Delta)$  space. This is by a reduction from communication complexity lower bounds of the Tribes function [36] (a slightly less well-known cousin of the famous set disjointness problem). This brings us to:

<span id="page-3-3"></span>**Lesson 2.** Any semi-streaming algorithm for  $\Delta$ -coloring should crucially use the fact that each edge of the graph arrives *exactly once* in the stream.

Again, while the semi-streaming model only allows for presenting each edge once in the stream, many algorithms are entirely oblivious to this feature. This includes all previous semi-streaming coloring algorithms in [3, 6, 12, 13, 33], as well as various other ones for spanning trees [27], sparsifiers [42], spanners [27, 28] and maximal matchings [27]. Lesson 2 says that any potential  $\Delta$ -coloring algorithm cannot be of this type.

A natural algorithm or a barrier result? Finally, let us conclude this part by considering a natural semi-streaming algorithm for  $\Delta$ -coloring: Sample  $O(n \log n/\Delta)$  vertices S uniformly at random, and partition the input graph into two subgraphs  $G_S$  consisting of all edges incident on S, and  $G_{-S}$  consisting of all remaining edges. We can easily detect, for each arriving edge in the stream, which subgraph it belongs to. Moreover, it is easy to see that  $G_S$  contains  $O(n \log n)$  edges and  $G_{-S}$ , with high probability, has maximum degree  $\Delta - 1$ . We can thus store  $G_S$  explicitly via a semi-streaming

algorithm and run the algorithm of [6] on  $G_{-S}$  to color it with  $(\Delta(G_{-S}) + 1) = \Delta$  colors. So, we have a  $\Delta$ -coloring of  $G_{-S}$  and all edges of  $G_{S}$ .

Surely, now that we know *all* of  $G_S$ , we should be able to extend the  $\Delta$ -coloring of  $G_{-S}$  to  $G_S$ , no? The answer however turns out to be *no*: unlike the case of  $(\Delta+1)$ -coloring, not every partial coloring of a graph can be extended directly to a proper  $\Delta$ -coloring of the entire graph. But perhaps this is only an abstract worry and we should just find the right way of analyzing this algorithm? The answer is yet again *no*: the algorithm we just proposed in fact neglects both Lesson 1 and Lesson 2 and thus is doomed to fail completely<sup>3</sup>. But this also leaves us with the following lesson.

<span id="page-4-1"></span>**Lesson 3.** Any semi-streaming algorithm for  $\Delta$ -coloring that colors the graph by extending a partial coloring, subgraph by subgraph, should either provide a *stronger guarantee* than solely an arbitrary  $\Delta$ -coloring for each subgraph, or allow for *recoloring* of an already colored subgraph.

While perhaps less concrete than our two previous lessons, Lesson 3 has a profound impact in the design of our semi-streaming algorithm that also colors the graph one subgraph at a time; in particular, our algorithm is going to adhere to *both* restrictions imposed by Lesson 3 simultaneously.

# <span id="page-4-2"></span>2.2 The High-Level Overview of Our Algorithm

After this long detour, we are now ready to go over our algorithm in Theorem 1. As stated earlier, the three main ingredients of our algorithm are: (i) a variant of palette sparsification for  $\Delta$ -coloring that can color all but some problematic almost-cliques in the input (such as Figure 1b), (ii) a sparse recovery approach for (partially) recovering these problematic subgraphs, and (iii) a new coloring procedure that allows for extending the partial coloring of part (i) to the remaining subgraphs partially recovered in part (ii) to obtain a proper  $\Delta$ -coloring of the entire graph. We will go over each part separately in the following.

Part I: Powers and Limitations of Palette Sparsification for  $\Delta$ -Coloring. While we already discussed in Section 2.1 that palette sparsification fails for  $\Delta$ -coloring, we are still going to employ its ideas crucially in our work. The goal of this step is to identify to what extent this approach fails for  $\Delta$ -coloring. We develop a **classification of almost-cliques** (Section 4.1) based on the following three criteria:

- Size number of vertices: *small* for  $< \Delta + 1$ , *critical* for  $\Delta + 1$ , and *large* for  $> \Delta + 1$  vertices.
- Inner density number of non-edges inside the almost-clique: holey for  $\Omega(\Delta)$  non-edges (or "holes" in the almost-clique), and unholey otherwise.
- Outer connections a measure of how "tightly" the almostclique is connected to outside; we postpone the technical details of this part to the actual definition in Section 4.1.

Among these, size and inner density are perhaps usual suspects. For instance, we already saw in Section 2.1 that palette sparsification entirely fails for almost-cliques of size  $\Delta$  + 1 with exactly

one non-edge – in our classification, these correspond to critical unholey almost-cliques. The third criterion is more technical and is motivated by Lesson 3; as we are still going to color the graph one almost-clique at a time, we would like to be able to reason about the partial coloring of outside vertices and possibility of its extension to the almost-clique. This is particularly relevant for small almost-cliques which can be actually a true clique inside and hence would definitely be in trouble if the same exact set of colors is "blocked" for all their vertices from outside. See Figure 3.

We then consider palette sparsification (on steroids!) wherein each vertex samples polylog (n) colors from  $\{1, ..., \Delta\}$  and characterize which families of almost-cliques in our classification can still be colored using only the sampled colors. We show that all holey almost-cliques (regardless of their size or outer connections) can be still colored from their sampled colors using a similar argument as in [6]. More interestingly, we show that even unholey small almostcliques that have the "right" type of outside connections can be colored at this step. Our analysis in this part deviates significantly from [6] and in particular crucially establishes certain randomness properties on the coloring of vertices outside of an almost-clique when trying to color the almost-clique itself (recall Lesson 3). Thus, what remains are unholey critical almost-cliques (regardless of their outer connections) and unholey small almost-cliques with "problematic" outside connections. We delegate coloring of these almost-cliques to the next steps of the algorithm.

Let us now briefly discuss the effect of outer connections in coloring a small almost-clique. As stated earlier, the main problem with small almost-cliques occurs when exactly the same set of colors is used to color all outside vertices, thus blocking these colors entirely for the almost-clique. While this event is basically unavoidable for almost-cliques with only a couple of outside neighbors (Figure 3b), it becomes less and less likely as the number of outside neighbors increases (Figure 3a). After all, for a color to be used on all these vertices, it should be sampled by every single one of them in the first place. We will however run into problem again in cases when we have "too many" outside neighbors for every single vertex of the almost-clique (Figure 3c). The almost-cliques of Figure 3c are particularly problematic as we have no knowledge of the neighborhood of their outside vertices (for Figure 3b, we at least know that each of them have many neighbors in the almost-clique - this can be used crucially by our latter algorithms). Thus, we should basically avoid ending up in a situation that we have to color such almost-cliques after having colored their outside neighbors.

Fortunately, the almost-cliques of Figure 3c can only happen for small enough almost-cliques; this in turn makes the neighborhood of these almost-cliques sufficiently sparse. Thus, we can instead handle them similar to sparse vertices by *increasing* the size of sampled palettes for vertices. There is however a subtle issue with this approach. Increasing the size of sampled palettes means that even a fewer number of outside vertices can make a problem for us, hence requiring us to send even more almost-cliques to sparse vertices to handle, leading to a chicken-and-egg problem. A key idea in this part is a way to break this dependency cycle by careful sequencing the order of processing of vertices in a way that ensures sufficient "randomness" exist in the coloring of neighborhood of all small almost-cliques, except for the ones with very few outside

<span id="page-4-0"></span> $<sup>^3\</sup>mathrm{An}$  added bonus of those impossibility results is to allow for quickly checking viability of potential algorithms.

<span id="page-5-0"></span>![](_page_5_Figure_2.jpeg)

![](_page_5_Figure_3.jpeg)

![](_page_5_Figure_4.jpeg)

(a) "random" outside-coloring (b) "adversarial" outside-coloring

(c) "adversarial" outside-coloring

Figure 3: An illustration of three possible types of outer connections on a graph with maximum degree  $\Delta=6$ . The almost-clique in part (a) has a "right" type of outside connection and is going to receive a more "random" coloring on its neighbors, compared to the almost-clique in part (b) with "few" outside neighbors and part (c) with "too many" ones. In particular, the latter almost-cliques now cannot be  $\Delta$ -colored without changing the color of outside vertices as the same colors are blocked for all vertices of the inner (actual) cliques.

neighbors (the type in Figure 3b). We postpone the discussion of this "dependancy-breaking" step to section 5.

All in all, this step effectively establishes that palette sparsification achieves a "weak" streaming Brooks' theorem by  $\Delta$ -coloring graphs that do not contain certain *forbidden* subgraphs such as  $(\Delta+1)$ -cliques minus few edges or  $\Delta$ -cliques that have few neighbors outside (for Brooks' theorem itself, the only forbidden subgraph is a  $(\Delta+1)$ -clique).

Part II: Sparse Recovery for Remaining Almost-Cliques, and Helper Structures. Our next step is a way of finding edges of the almost-cliques left uncolored by the previous step so that we can color them using a different approach. Let us bring up an obvious point here: these left out almost-cliques are precisely the same family of instances that were at the core of our impossibility results in Section 2.1 (and their natural relaxations). Consequently, to handle them, our algorithm needs to take into account the recipe put forward by Lesson 1 and Lesson 2: it should look at all edges of the stream exactly once. This rather uniquely points us toward a canonical technique in the streaming model: sparse recovery (via linear sketching).

Consider an almost-clique which is a  $(\Delta + 1)$ -clique minus an edge (Figure 1b). On the surface, recovering all edges of this almost-clique is problematic as these subgraphs are actually quite *dense*; for instance, if the graph consists of only copies of such almost-cliques, we will need  $\Omega(n\Delta)$  space to store all of them. But what saves us at this stage is the fact that these subgraphs are actually too dense! Informally speaking, this reduces their entropy dramatically conditioned on our knowledge of the sparse-dense decomposition. Thus, we can recover them *implicitly* using a novel sparse recovery approach that uses the sparse-dense decomposition algorithmically and not only analytically <sup>4</sup>.

Although in the examples we discussed, we can hope to recover the entire almost-clique in question implicitly, this will not be the case for all almost-cliques left uncolored by the first part, e.g., for a  $(\Delta + 1)$ -clique minus a  $\sqrt{\Delta}$ -size inner clique (applying this method

to a graph consisting of only such almost-cliques requires  $\Omega(n\sqrt{\Delta})$  space). As a result, our semi-streaming algorithm settles for recovering certain **helper structures** from these almost-cliques instead. These are subgraphs of the input that are sufficiently simple to be recoverable via a combination of sparse recovery, sampling, and some basic graph theory arguments. At the same time, they are structured enough to give us enough flexibility for the final coloring step. Given the technicality of their definitions (Definitions 4.6 and 4.7), we postpone further details to Section 4.1.

We point out that sparse recovery and linear sketching have been a staple of graph streaming algorithms since the seminal work of [2]. But, these tools have been almost exclusively used to handle edge deletions in *dynamic* streams. Their applications for us, on *insertion-only* streams, as a way of (implicitly) sparsifying a graph using outside information (i.e., the sparse-dense decomposition), is quite different and can form a tool of independent interest.

Part III: The Final Coloring Procedure. The final step of our approach is then to color these remaining almost-cliques, given the extra information we recovered for them in the previous step. For intuition, let us consider two inherently different types of almost-cliques left uncolored by the approach in the first part.

<span id="page-5-2"></span>![](_page_5_Figure_17.jpeg)

![](_page_5_Figure_18.jpeg)

(a) a (Δ+1)-clique minus an edge (b) a Δ-clique with few neighbors

Figure 4: Two problematic almost-cliques in a graph with maximum degree  $\Delta=4$ . Both almost-cliques are *hard* for palette sparsification. The only way part (a) can be  $\Delta$ -colored is if the vertices incident on the non-edge have intersecting lists. Part (b) is *not*  $\Delta$ -colorable if the outside (marked) vertices are all colored the same.

<span id="page-5-1"></span><sup>&</sup>lt;sup>4</sup>For the main results in [6] one only needs to know the *existence* of the decomposition and does not need to compute it. That being said, [6] also gave algorithms for finding the decomposition from the stream (which is needed to run their algorithms in polynomial time) – we use an extension of their algorithm by [7] in this paper.

 $(\Delta+1)$ -clique minus an edge (u,v) (Figure 4a): Suppose we know all edges of such an almost-clique. We can color both u and v the same using a color that does not appear in their outside neighbors (which is possible because vertices of almost-cliques have few edges out); the standard greedy algorithm now actually manages to  $\Delta$ -color this almost-clique (recall that we assumed the knowledge of all edges of the almost-clique for now). The argument is simply the following: Pick a common neighbor z of u and v, which will exist in an almost-clique, and greedily color vertices from a color not used in their neighborhood, waiting for z to be colored last; at this point, since two neighbors of z have the same color, there is still a choice for z to be colored with in the algorithm.

 $\Delta$ -clique with few neighbors (Figure 4b): These are more problematic cases if we have ended up coloring all their outside neighbors the same. Even if we know all edges of this almost-clique, there is no way we can color a  $\Delta$ -clique with  $(\Delta - 1)$  colors (the same one color is "blocked" for all vertices). So, the next ingredient of our algorithm is a recoloring step that allows for handling these almost-cliques (again, recall Lesson 3); we show that our strengthened palette sparsification is flexible enough that given the edges of a new almost-clique, it allows for altering some of the past decisions on vertices outside this almost-clique. This step involves reasoning about a probabilistic process (possibility of having a "good" color to change for an outside vertex) after already viewing the outcome of the process (having ended up with a "blocked" color). This requires a careful analysis which is handled by partitioning the randomness of the process into phases and using our classification of almostcliques to limit the amount of "fresh randomness" we need for this step across these phases. We discuss this in more detail in Section 5.

The discussion above oversimplified many details. Most importantly, we actually do not have such a "clean" picture as above for the remaining almost-cliques we need to color. Instead, the algorithm needs to handle almost-cliques that are not fully recoverable by sparse recovery (as they are not sufficiently dense), using their helper structures described earlier<sup>5</sup>. This coloring is thus done via a combination of the greedy arguments of the above type on the helper structures, combined with palette sparsification ideas for the remaining vertices of the almost-clique. This in turns requires using some **out of (sampled) palette coloring** of vertices, which is in conflict with what the palette sparsification does and needs to be handled carefully; see Section 5.

### <span id="page-6-6"></span>3 PRELIMINARIES

Notation. For an integer  $t \geq 1$ , we define  $[t] := \{1,2,\ldots,t\}$ . For a graph G = (V,E) and a vertex  $v \in V$ , we use  $N_G(v)$  to denote the neighbors of v in G, and N(v) when the graph is clear from the context. Further, we define degree of v by  $\deg_G(v) := |N_G(v)|$  (and similarly  $\deg(v)$ ). We refer to a pair (u,v) of vertices in V as a **non-edge** when there is no edge between u and v in G. Similarly, we sometimes say that u is a **non-neighbor** of v and vice versa.

For a graph G = (V, E) and integer  $q \ge 1$ , we refer to any function  $C: V \to [q]$  as a *q*-coloring and call it a *proper* coloring

iff there is no edge (u, v) in G with C(u) = C(v). We further refer to a function  $C: V \to [q] \cup \{\bot\}$  as a **partial** q-coloring and call the vertices  $v \in V$  with  $C(v) = \bot$  as **uncolored** vertices by C. The edges (u, v) in G with  $C(u) = C(v) = \bot$  are *not* considered monochromatic, and thus we consider a partial q-coloring proper iff there is no edge (u, v) in G with  $C(u) = C(v) \neq \bot$ . Finally, for any proper partial q-coloring, and any vertex  $v \in V$ , we define:

- ColNei $_C(v) := \{u \in N(v) \mid C(u) \neq \bot\}$ : the neighbors of v that are assigned a color by C; we further define  $\operatorname{coldeg}_C(v) := |\operatorname{ColNei}_C(v)|$ .
- Avail<sub>C</sub>(v) := {c ∈ [q] | C(u) ≠ c for all u ∈ N(v)}: the colors in [q] that have not been assigned to any neighbor of v by C, i.e., are available to v; we define avail<sub>C</sub>(v) := |Avail<sub>C</sub>(v)|.

Finally, we say that a coloring  $C_1$  is an **extension** of coloring  $C_2$  iff for every  $v \in V$  with  $C_2(v) \neq \bot$ ,  $C_1(v) = C_2(v)$ ; in other words, only uncolored vertices in  $C_2$  may receive a different color in  $C_1$ .

Throughout, we say that an event happens "with high probability", or "w.h.p." for short, to mean that it happens with probability at least 1-1/poly(n) for some large polynomial (the degree can be arbitrarily large without changing the asymptotic performance of the algorithms). Moreover, we pick this degree to be large enough to allow us to do a union bound over the polynomially many events considered and we do not explicitly mention this union bound each time (but in certain places that we need to do a union bound over exponentially many events, we will be more explicit).

# <span id="page-6-0"></span>3.1 A Sparse-Dense Decomposition

We use a simple corollary of known streaming sparse-dense decompositions in [6, 7], which have their origin in the classical work in graph theory [45, 53] and have subsequently been used extensively in distributed algorithms as well [20, 32, 35, 49].

The decomposition is based on partitioning the vertices into "(locally) sparse" vertices with many non-edges among their neighbors and "almost-clique" vertices that are part of a subgraph which is close to being a clique. We formally define these as follows.

<span id="page-6-4"></span>Definition 3.1. For a graph G = (V, E) and parameter  $\varepsilon > 0$ , a vertex  $v \in V$  is  $\varepsilon$ -sparse iff there are at least  $\varepsilon^2 \cdot \Delta^2/2$  non-edges between the neighbors of v.

<span id="page-6-3"></span>DEFINITION 3.2. For a graph G = (V, E) and parameter  $\varepsilon > 0$ , a subset of vertices  $K \subseteq V$  is an  $\varepsilon$ -almost-clique iff K has the following properties:

- i). Size of K satisfies  $(1 5\varepsilon) \cdot \Delta \leq |K| \leq (1 + 5\varepsilon) \cdot \Delta$ .
- *ii*). Every vertex  $v \in K$  has  $\leq 10\varepsilon\Delta$  non-neighbors inside K;
- *iii*). Every vertex  $v \in K$  has ≤  $10\varepsilon\Delta$  neighbors outside K;
- <span id="page-6-2"></span>*iv*). Every vertex  $u \notin K$  has  $\geq 10\varepsilon\Delta$  non-neighbors inside K.

We note that property iv). of Definition 3.2 does not typically appear in the definition of almost-cliques in prior work but it is crucial for our proofs. However, this property follows immediately from the proof of [7]. We have the following sparse-dense decomposition.

<span id="page-6-5"></span>Proposition 3.3 (Sparse-Dense Decomposition; cf. [6, 7, 45]). There is a constant  $\varepsilon_0 > 0$  such that the following holds. For any

<span id="page-6-1"></span><sup>&</sup>lt;sup>5</sup>For a  $(\Delta + 1)$ -clique minus an edge (u, v), the helper structure is the subgraph consisting of vertices u and v, and all edges incident on at least one of them.

 $0 < \varepsilon < \varepsilon_0$ , vertices of any graph G = (V, E) can be partitioned into sparse vertices  $V_{\text{sparse}}$  that are  $\varepsilon$ -sparse (Definition 3.1) and dense vertices partitioned into a collection of disjoint  $\varepsilon$ -almost-cliques  $K_1, \ldots, K_k$  (Definition 3.2).

Moreover, there is an absolute constant  $\gamma > 0$  and an algorithm that given access to only the following information about G, with high probability, computes this decomposition of G:

- Random edge samples: A collection of sets  $N_{\text{sample}}(v)$  of  $(\gamma \cdot \varepsilon^{-2} \cdot \log n)$  neighbors of every vertex  $v \in V$  chosen independently and uniformly at random (with repetition);
- Random vertex samples: A set SAMPLE of vertices wherein
  each v ∈ V is included independently with probability (γ·log n/Δ),
  together with all the neighborhood N(v) of each sampled vertex
  v ∈ SAMPLE.

# <span id="page-7-3"></span>3.2 Sparse Recovery

We also use the following standard variant of sparse recovery in our proofs. We note that the specific recovery matrix below, the Vandermonde matrix, is not necessary for our proofs (i.e., can be replaced with any other standard construction) and is only mentioned explicitly for concreteness.

<span id="page-7-1"></span>Proposition 3.4 (cf. [25]). Let  $n, k \geq 1$  be arbitrary integers and  $p \geq n$  be a prime number. Consider the  $(2k \times n)$ -dimensional Vandermonde matrix  $\Phi^V$  over  $\mathbb{F}_p$  such that:

or for all 
$$i \in [2k]$$
 and  $j \in [n]$ :  $\Phi_{i,j}^{V} = j^{i-1} \mod p$ .

Then, for any k-sparse vector  $x \in \mathbb{F}_p^n$ , one can uniquely recover x from  $\Phi^V \cdot x$  in polynomial time.

In order to safely use sparse recovery (in case when we mistakenly run it on a non-sparse vector), we also need the following standard result that allows us to test whether the output of the recovery is indeed correct or not.

<span id="page-7-2"></span>PROPOSITION 3.5. Let  $n, t \ge 1$  be arbitrary integers and  $p \ge n$  be a prime number. Consider the  $(t \times n)$ -dimensional random matrix  $\Phi^R$  over  $\mathbb{F}_p$  chosen uniformly from all matrices in  $\mathbb{F}_p^{t \times n}$ . Then, for any two different vectors  $x \ne y \in \mathbb{F}_p^n$ , we have,

$$\Pr_{\Phi^{R}} \left( \Phi^{R} \cdot x = \Phi^{R} \cdot y \right) = p^{-t}.$$

We can now combine Proposition 3.4 and Proposition 3.5 to have a "safe" recovery w.h.p. as follows: For the (unknown) vector  $x \in \mathbb{F}_p^n$ , we compute  $\Phi^V \cdot x$  and  $\Phi^R \cdot x$  in parallel. We first use  $\Phi^V \cdot x$  in Proposition 3.4 to recover a vector  $y \in \mathbb{F}_p^n$ ; then, since we know  $\Phi^R$ , we can also compute  $\Phi^R \cdot y$  and use Proposition 3.5 to check whether  $\Phi^R \cdot y = \Phi^R \cdot x$ : if yes, we output y and otherwise output 'fail'. It is easy to see that if x is indeed k-sparse, this scheme always recovers x correctly, and in any other case, w.h.p., it does not recover a wrong vector (but may output 'fail').

#### 4 THE SEMI-STREAMING ALGORITHM

In this section we describe the algorithm that collects necessary information for the  $\Delta$ -coloring from the stream. This will then be used

in our main coloring procedure in Section 5 to prove Theorem 1. The algorithm consists of the following three main parts:

- The palette-sampling algorithm (Algorithm 1): An algorithm, quite similar to palette sparsification approach, that samples polylog (n) potential colors for each vertex and store all possibly monochromatic edges during the stream.
- The find-decomposition algorithm (Algorithm 2): An algorithm that recovers a sparse-dense decomposition of the input graph as specified in Proposition 3.3 plus some extra useful information about the decomposition.
- The sparse-recovery algorithm (Algorithm 3): An algorithm that uses sparse recovery techniques to extract further "helper structures" about the almost-cliques in the decomposition of the previous step.

We elaborate on each of these algorithms and their guarantees in the following subsections. But we shall emphasize that they all run *in parallel* in a single pass over the stream. To continue, we start with setting up some parameters and key definitions.

# <span id="page-7-0"></span>4.1 Parameters, Classification of Almost-Cliques, and Helper Structures

We use the following parameters for the design of our algorithms.

 $\alpha = 10^3$ : a sufficiently large constant used to simplify various concentration inequalities

 $\beta = 100 \cdot \log n$ : used to bound the size of certain palettes in

<span id="page-7-4"></span>palette-sampling

 $\varepsilon = \frac{10^{-8}}{\log n}$ : used as the parameter of sparse-dense decomposition of Proposition 3.3. (1)

We also assume that  $\Delta = \Omega(\log^5 n)$  as otherwise we can simply store the graph entirely and solve the problem offline, using any classical algorithm for Brooks' Theorem.

Recall the notion of almost-cliques in Definition 3.2 used in our sparse-dense decomposition. In the coloring phase of the algorithm, we make further distinctions between almost-cliques based on their sizes as defined below – the coloring algorithm will treat these classes separately and our algorithms in this section provide further information about these different classes.

Classification of almost-cliques. We start with the following simple definition that partitions almost-cliques based on their size.

<span id="page-7-5"></span>DEFINITION 4.1. Let K be an almost-clique in the sparse-dense decomposition. We say that K is **small** iff it has at most  $\Delta$  vertices, **critical** iff it has exactly  $\Delta + 1$  vertices, and **large** otherwise.

We have the following basic observation based on this definition.

<span id="page-7-6"></span>Observation 4.2. (i) Any critical almost-clique contains at least one non-edge, and (ii) any large almost-clique contains at least ( $\Delta$  + 2)/2 non-edges.

A property that fundamentally affects how we color an almostclique is the number of non-edges inside it. Intuitively, if an almostclique is very "clique-like", that is, it has very few non-edges inside, then it is more difficult to color. This motivates the following defi-

<span id="page-8-4"></span>DEFINITION 4.3. Let K be an almost-clique in the sparse-dense decomposition. We say that K is **holey** iff it has at least  $10^7 \cdot \varepsilon \Delta$  non-edges (or "holes") inside it. Otherwise, K is **unholey**.

Another key property that governs our ability to color an almostclique is how it is connected to the outside and in particular, what we can expect from a coloring of its neighbors outside: can we see those colors as being "random" or are they "adversarial"? In the latter case, can we recolor some to make them "less adversarial"? This motivates the following two definitions.

<span id="page-8-3"></span>Definition 4.4. Let K be an almost-clique in the decomposition and v be any vertex outside K that is neighbor to K. We say that:

- v is a **friend** of K iff there are at least  $2\Delta/\beta$  edges from v to K, i.e.,  $|N(v) \cap K| \ge 2\Delta/\beta$ ;
- v is a stranger to K iff there are less than Δ/β edges from v to K,
   i.e., |N(v) ∩ K| < Δ/β;</li>

We emphasize that there is a gap in the criteria between friend and stranger vertices, and hence it is possible that a vertex is neither a friend of nor a stranger to an almost-clique. Based on the notion of friend and stranger vertices, we can further classify almost-cliques into these classes.

DEFINITION 4.5. Let K be an almost-clique in the decomposition. We say that K is:

- friendly iff K has at least one neighbor outside K that is a friend of K.
- **lonely** *iff all neighbors of K outside K are strangers.*
- **social** otherwise; that is, K has at least one neighbor outside K that is not a stranger, but at the same time, it has no friends.

We approach coloring friendly and lonely almost-cliques quite differently, but both approaches can handle social almost-cliques. This will be crucial as we can distinguish between friendly and lonely almost-cliques but our tester may classify social almostcliques in either of these groups.

Helper structures. As stated earlier, unholey almost-cliques are the most difficult to  $\Delta$ -color. Some of these unholey almost-cliques can be handled by a "global" argument that reason about the coloring of their neighbors outside. But for the rest, we may need to consider recoloring some of their neighbors outside and/or using some extra information about the graph. In the following, we define two "helper structures" that provide this extra information for our coloring approach. Our algorithms in this section then show how we can find these subgraphs in the stream.

The first structure we have handles unholey almost-cliques which are critical.

<span id="page-8-0"></span>DEFINITION 4.6. Let K be an unholey almost-clique which is critical. We define a **critical-helper structure** for K as a tuple (u, v, N(v)) with the following properties:

(i) u, v are vertices of the graph and are both in K;

- (ii) u and v are non-neighbor to each other;
- (iii) N(v) is the neighborhood of v in the graph.

At a very high level, if we have a critical-helper structure of K at hand, we can color u and v the same (the crucial knowledge of N(v) allows us to do this) which "buys" us an extra color which will be sufficient for us to color the entire almost-clique also.

The second structure we have handles unholey almost-cliques which are friendly or even social.

<span id="page-8-1"></span>DEFINITION 4.7. Let K be an unholey almost-clique which is either friendly or social. We define a **friendly-helper structure** for K as a tuple (u, v, w, N(v), N(w)) with the following properties:

- (i) u, v, w are vertices of the graph such that  $u \notin K$  and is <u>not</u> a stranger to K and  $v, w \in K$ ;
- (ii) u is neighbor to v and non-neighbor to w, and v and w are themselves neighbors;
- (iii) N(v) and N(w) are the neighborhoods of v and w in the graph, respectively.

Again, at a high level, if we have a friendly-helper structure of K at hand, we will be able to (re)color u and w the same, which "buys" us an extra color for v and gives us the required flexibility for coloring the entire almost-clique (the knowledge of N(v) and N(w) crucially allows us to choose the colors for these vertices without creating a conflict with their neighbors in the graph).

## 4.2 Palette Sampling

One key component of our algorithm is a color sampling procedure in the same spirit as the palette sparsification theorem of [6]. The main difference is that the number of sampled colors per vertex is larger here (polylog (n) as opposed to  $O(\log n)$ ) and that we explicitly partition these samples into multiple lists instead of just one

<span id="page-8-2"></span>**Algorithm 1.** The palette-sampling algorithm.

**Input:** Graph G = (V, E) with known vertices V and streaming edges E.

- (i) For every vertex  $v \in V$ , sample the following lists of colors:
- $L_1(v)$ : Sample a single color chosen uniformly at random from  $[\Delta]$ .
- $L_2(v)$ : Sample each color from  $[\Delta]$  independently with probability  $\frac{\beta}{\Lambda}$ .
- $L_3(v)$ : Sample each color from  $[\Delta]$  independently with probability  $\frac{100 \cdot \alpha \cdot \log n}{\varepsilon^2 \cdot \Delta}$ .
- $L_4(v) := (L_4^*(v) \text{ and } L_{4,i}(v) \colon i \in [\beta])$ : Sample each color from  $[\Lambda]$  with probability  $\frac{\beta}{\Lambda}$  in  $L_4^*(v)$  and with probability  $q := \frac{1}{100\sqrt{\varepsilon}\Lambda}$  in each  $L_{4,i}(v)$  for  $i \in [\beta]$ , all independently.
- $L_5(v)$ : Sample each color from  $[\Delta]$  independently with probability  $\frac{\beta}{\Lambda}$ .
- $L_6(v) := (L_{6,i}(v): i \in [2\beta])$ : Sample each color from  $[\Delta]$  independently with probability  $\beta^2/\Delta$ .

(ii) Let L(v) := ∪<sub>j∈[6]</sub>L<sub>j</sub>(v). Store any incoming edge (u, v) whenever L(u) ∩ L(v) ≠ Ø and let H be the subgraph of G formed by these stored edges, referred to as the conflict graph.

At this point, the choices of the lists  $L_1(v) \dots L_6(v)$  may seem arbitrary<sup>6</sup>: the (very) rough idea is that we will use different lists at different stages of the coloring, and the sizes are chosen to allow each stage to go through without causing too much dependency for the next stage. In the rest of this subsection, we will bound the space complexity of palette-sampling (Algorithm 1).

Recall that in the conflict graph G, we only keep an edge (u,v) if  $L(u) \cap L(v) \neq \emptyset$  – which makes sense, since if we restrict ourselves to coloring a vertices with a color from their lists  $L(\cdot)$ , then these are the only edges that can be monochromatic. We have the following lemma to bound the space used by Algorithm 1.

<span id="page-9-6"></span>Lemma 4.8. With high probability, palette-sampling uses  $O(n \cdot \log^7 n)$  bits of space.

# 4.3 Finding the Decomposition

We also work with the sparse-dense decomposition; unlike [6], not only as an analytical tool but in fact algorithmically (as will become evident from the next subsection). In this subsection, we describe an algorithm for finding the sparse-dense decomposition of Proposition 3.3. In particular, we only need to provide the random edge and vertex samples required by the proposition. But, in addition to the samples required for the decomposition, we will also collect independent random edge samples to allow us to distinguish friend vertices from strangers (Definition 4.4).

<span id="page-9-0"></span>Algorithm 2. The find-decomposition algorithm.

**Input:** Graph G = (V, E) with known vertices V and streaming edges E.

- (i) Let y be the constant from the statement of Proposition 3.3.
- (ii) Pick random vertex samples: For each vertex v, sample v into the set SAMPLE with probability  $(\gamma \cdot \log n/\Delta)$  independently. During the stream, for each vertex v in SAMPLE, store all edges incident on v.
- (iii) Pick random edge samples: For each vertex v, use reservoir sampling over the edges incident on v to pick a sample  $N_{\text{sample}}(v)$  of size  $(\gamma \cdot \varepsilon^{-2} \cdot \log n)$  from its neighborhood.
- (iv) Pick random neighbor samples: For each vertex v, store each neighbor of v in  $I_{\text{sample}}(v)$  with probability  $\beta^2/\Delta$ .

Let us start by bounding the space used by find-decomposition and then present the main properties of the algorithm for our purpose.

<span id="page-9-7"></span>Lemma 4.9. With high probability, find-decomposition uses  $O(n \log^4 n)$  bits of space.

We now establish the main properties we need from find-decomposition.

<span id="page-9-4"></span>Lemma 4.10. We can compute a sparse-dense decomposition (Proposition 3.3) of the input graph G = (V, E) with high probability using the samples collected by find-decomposition.

We show that the independent random edge samples  $I_{\text{sample}}(v)$  are enough for a tester that can distinguish friendly almost-cliques from lonely almost-cliques.

<span id="page-9-5"></span>LEMMA 4.11. There exists an algorithm that given an almost-clique K, and to the random neighbor samples  $I_{\text{sample}}(v)$  for every  $v \in V$ , with high probability can distinguish:

- *K* is a friendly almost-clique;
- K is a lonely almost-clique.

The randomness in this lemma is over  $\{I_{\text{sample}}(v) \mid v \in V\}$ .

# 4.4 Sparse Recovery for Almost-Cliques

Finally, we come to the most novel part of this section. Recall that as discussed earlier, palette sparsification (and thus our own palette-sampling) is doomed to fail for  $\Delta$ -coloring. To bypass this, we rely on the *helper structures* defined in Definitions 4.6 and 4.7, which, combined with the palette sparsification-type approach of palette-sampling, allow us to color the graph.

The first challenge here is that we obviously cannot afford to find the neighborhood of every vertex, and we do not know *during* the stream which vertices will satisfy the properties we need for these structures. We step around this by (crucially) using randomization to sample the "right" vertices. The second and main challenge is that for some almost-cliques (say, a critical almost-clique with only one non-edge), we may actually have to recover neighborhood of *all* vertices in the almost-clique before finding the required helper structure; but doing this naively requires too much space. Instead, we use the sparse recovery matrices of Section 3.2, in conjunction with the decomposition found by find-decomposition, to recover these parts much more efficiently.

<span id="page-9-1"></span>**Algorithm 3.** The sparse-recovery algorithm.

**Input:** Graph G = (V, E) with known vertices V and streaming edges E.

For every  $r \in R = \{2^i \mid 0 \le i \le \lceil \log \Delta \rceil\}$ :

- (i) Sample each vertex  $v \in V$  in a set  $V_r$  independently with probability min $\{1, \frac{\beta}{\varepsilon \cdot r}\}$ .
- (ii) Construct the  $(2r \times n)$  Vandermonde matrix  $\Phi_r^V$  (see Proposition 3.4) and sample an  $(\alpha \times n)$  random matrix  $\Phi_r^R$  (see Proposition 3.5) over the field  $\mathbb{F}_p$  where p is a fixed prime larger than n and smaller than, say,  $n^2$ , and  $\alpha$  is the parameter in Eq (1).

<span id="page-9-2"></span><sup>&</sup>lt;sup>6</sup>And indeed redundant; technically speaking, we could have just sampled a single list of colors of proper size and postponed the partitioning to the analysis (as in fact done in [6]) – however, we find it more transparent to consider these lists explicitly separate from each other due to various dependency issues that this explicitly avoids.

<span id="page-9-3"></span><sup>&</sup>lt;sup>7</sup>Think of r as a fixed sampling rate from a set of rates R.

(iii) For each vertex  $v \in V_r$ , define a vector  $y(v) \in \mathbb{F}_p^{2r}$  and  $z(v) \in \mathbb{F}_p^{\alpha}$  initially set to 0. For any incoming edge  $\{u,v\}$  in the stream, update

$$y(v) \leftarrow y(v) + \Phi_r^{V} \cdot \mathbf{e}_u$$
 and  $z(v) \leftarrow z(v) + \Phi_r^{R} \cdot \mathbf{e}_u$ 

where  $\mathbf{e}_u$  is the *n*-dimensional vector which is 1 on coordinate u and 0 everywhere else.

Let us start by bounding the space of this algorithm.

<span id="page-10-6"></span>LEMMA 4.12. sparse-recovery uses  $O(n \log^4 n)$  bits of space.

Next, we prove the main properties of sparse–recovery for our purpose. Before getting into details however, we state a standard observation about linear transformations (namely,  $\Phi_r^{\rm V}$  and  $\Phi_r^{\rm R}$  in sparse–recovery) over a stream of updates.

Observation 4.13. Fix  $r \in R$  and  $v \in V_r$  in sparse-recovery. At the end of the stream,

$$y(v) = \Phi_r^{\mathrm{V}} \cdot \chi(N(v)) \qquad \text{and} \qquad z(v) = \Phi_r^{\mathrm{R}} \cdot \chi(N(v)),$$

where  $\chi(N(v)) \in \{0, 1\}^V$  is the characteristic vector of N(v).

Recall from Proposition 3.4 that given  $\Phi^V_r \cdot x$  for an r-sparse vector  $x \in \mathbb{F}_p^n$ , we can recover x in polynomial time, and by Proposition 3.5, we can test our recovered vector to make sure with high probability that it is indeed equal to x. We use this idea combined with the fact that at the end of the stream we know a sparse-dense decomposition of the graph to recover one helper structure for each almost-clique (that needs one). We start with the key part that handles the critical-helper structures (Definition 4.6). There will also be a simpler part that handles friendly-helper structures almost-cliques (Definition 4.7).

Finding Critical-Helper Structures. We start by recovering a critical-helper structure for any critical almost-clique as defined in Definition 4.6. Let K be a critical almost-clique and v be a vertex in K. Define the vector  $x(v) := \chi(N(v)) - \chi(K)$ . For any coordinate  $u \in [n]$  in x(v),

$$x(v)_{u} = \begin{cases} 0 & \text{if } u \notin N(v) \cup K \text{ or } u \in N(v) \cap K \\ 1 & \text{if } u \in N(v) \setminus K \\ p - 1 & \text{if } u \in K \setminus N(v) \end{cases} , \qquad (2)$$

as we do the computation over  $\mathbb{F}_p$ . Notice that since v belongs to the almost-clique K, by Definition 3.2, size of both  $N(v) \setminus K$  and  $K \setminus N(v)$  is at most  $10\varepsilon\Delta$ . Thus, x(v) is already considerably sparser than  $\chi(N(v))$ . In the following, we are going to take this idea to the next level to recover a critical-helper structure for K using the vectors computed by sparse-recovery.

<span id="page-10-2"></span>Lemma 4.14. There exists an algorithm that given a critical almost-clique K (Definition 4.1), with high probability, finds a critical-helper structure (v, u, N(v)) of K (Definition 4.6) using the information gathered by sparse-recovery.

<span id="page-10-3"></span>Finding Friendly-Helper Structures. We now switch to finding a friendly-helper structure of Definition 4.7 for each almost-clique *K* that is unholey and *not* lonely.

LEMMA 4.15. There exists an algorithm that given an unholey and not lonely almost-clique K (Definition 4.1) and a vertex  $u \notin K$  which is not a stranger to K, with high probability, finds a friendly-helper structure (u, v, w, N(v), N(w)) of K (Definition 4.7) using the information gathered by sparse-recovery.

# <span id="page-10-7"></span>4.5 Listing the Information Collected by the Algorithm

For the ease of reference in the analysis, we now take stock of what all our algorithms collected about the graph from the stream. In particular, with high probability, we have the following information at the end of the stream:

- A list of sampled colors L(v) for every vertex v ∈ V as specified in Algorithm 1.
  - *Proof:* Follows from the definition of palette-sampling in Algorithm 1.
- 2. The **conflict graph** H consisting of every edge (u, v) in the graph where  $L(u) \cap L(v) \neq \emptyset$ .
  - *Proof*: Follows from the definition of palette-sampling in Algorithm 1.
- <span id="page-10-0"></span>3. A decomposition of *G* into sparse vertices and almost-cliques as specified in Proposition 3.3.
  - *Proof:* Follows from Lemma 4.10 for find-decomposition in Algorithm 2.
- <span id="page-10-1"></span>4. A collection  $\mathcal{K}_{\text{friendly}}$  of almost-cliques that contains *all* friendly almost-cliques and *no* lonely almost-clique, and for each  $K \in \mathcal{K}_{\text{friendly}}$ , one vertex  $u \notin K$  which is <u>not</u> a stranger to K.
  - *Proof:* Follows from Part (3.) and Lemma 4.11 for find-decomposition in Algorithm 2.
- <span id="page-10-8"></span>5. A collection K<sub>lonely</sub> of almost-cliques that contains all lonely almost-cliques and no friendly almost-clique. Moreover, K<sub>friendly</sub> \(\subseteq\) K<sub>lonely</sub> partition all almost-cliques, which also implies that every social almost-clique belongs to exactly one of these two collections.
  - *Proof:* Follows from Parts (3.), (4.), and Lemma 4.11 for find-decomposition in Algorithm 2.
- <span id="page-10-4"></span> A collection K<sub>critical</sub> of critical almost-cliques and for each K ∈ K<sub>critical</sub>, a critical-helper structure (u, v, N(v)) as in Definition 4.6.
  - Proof: Follows from Part (3.) and Lemma 4.14.
- <span id="page-10-5"></span>7. A collection  $\{(u, v, w, N(v), N(w))\}$  of **friendly-helper structures** (Definition 4.7), one for each  $K \in \mathcal{K}_{friendly}$  such that u is the vertex specified for  $K \in \mathcal{K}_{friendly}$  in Part (4.). *Proof*: Follows from Part (4.) and Lemma 4.15.
- The recovery graph H<sup>+</sup> consisting of all edges in the criticalhelper structures of Part (6.) and in the friendly-helper structures of Part (7.).
  - *Proof:* Follows from Parts (6.) and (7.).

We shall note that at this point, we covered all the process that is done by our algorithm *during* the stream and what remains is to prove this information is useful, i.e., we can indeed color the graph in the *post-processing step* using this information. This is the content of the next section.

Before moving on, we should note that, with high probability, the space complexity of (i) palette-sampling is  $O(n\log^7 n)$  bits by Lemma 4.8, (ii) find-decomposition is  $O(n\log^4 n)$  bits by Lemma 4.9, and (iii) sparse-recovery is  $O(n\log^4 n)$  by Lemma 4.12. Thus, our entire streaming algorithm takes  $O(n\log^7 n)$  space. This adhere to the space complexity promised in Theorem 1.

**Remark 4.16.** As stated, the space complexity of our algorithm is bounded with high probability but not in the worst-case. This is standard to fix; simply run the algorithm as it is and whenever it attempted to use more than, say, 100 times, the space guaranteed by its expectation, terminate it and "charge" the failure probability to the error.

<span id="page-11-0"></span>**Remark 4.17** (Removing Prior Knowledge of  $\Delta$ ). We observe that this semi-streaming algorithm does not really need to know  $\Delta$  before the stream begins. In particular, we can run  $O(\log n)$  independent copies of the algorithm, each with a difference "guess" of  $\Delta \in \left\{2^k \mid 2^k \leq 2n\right\}$ . At the same time, we can compute  $\Delta$  at the end of the stream by simply counting for each vertex the number of edges incident to it in  $O(n \log n)$  space.

An overestimate of  $\Delta$  does not hurt us in terms of space usage, but an underestimate can (for example, if we guess  $\Delta = 1$ , and the input includes a clique on n-1 vertices, the algorithm stores the entire graph). Hence, if at any point (for any guess  $\Delta$ ), if a vertex has degree larger than  $2\Delta$ , we stop that run of the algorithm. Now, at the end of the stream we will have:

- The actual maximum degree  $\Delta$ .
- The output of the algorithm for  $\Delta'$  and  $2\Delta'$  such that  $\Delta' \leq \Delta \leq 2\Delta'$ .

But now we can get the desired samples by "resampling" the outputs from Algorithms 1 to 3. In particular, for each vertex  $v \in V$ , and each color  $c \in L(v)$  from the run of Algorithm 1 with guess  $\Delta'$ , we keep c with probability  $\Delta'/\Delta$ . Since we are only dropping colors from the palettes, this process only removes some edges from the conflict graph. The samples of Algorithm 2 are adapted in a similar manner. Finally, the set of sampling rates R in Algorithm 3 for  $2\Delta'$  is a superset of that for a (hypothetical) run with the correct guess of  $\Delta$ , so we can just ignore the vectors corresponding to unused sample rates. <sup>8</sup>

Hence at the end of the stream we know  $\Delta$  and can adapt the samples as required, so the coloring procedure in the next section can proceed as normal.

### <span id="page-11-1"></span>5 THE COLORING PROCEDURE

We now describe the coloring procedure that we use to find a  $\Delta$ -coloring of the graph. This procedure is agnostic to the input graph, in the sense that we run it after processing the stream, and it only uses the information we gathered in the previous section, listed in Section 4.5 (throughout, we condition on the high probability event that the correct information is collected from the stream).

The general framework in our coloring procedure is the following: We will maintain a proper partial  $\Delta$ -coloring  $C\colon V\to [\Delta]\cup\{\bot\}$  (as defined in Section 3). We then go through different **phases** in the coloring algorithm and each phase updates C by coloring certain subsets of vertices, say, (a subset of) sparse vertices, or certain almost-cliques. These new colorings are typically going to be extensions of C but in certain cases, we crucially have to go back and "edit" this partial coloring, i.e., come up with a new proper partial coloring which is no longer an extension the current one. Eventually, we will color all the vertices of the graph and end up with a proper  $\Delta$ -coloring.

In the following, we present the order of the phases of our coloring procedure and the task we expect from each one. Each phase shall use a different list of colors  $L_1(\cdot), \dots, L_6(\cdot)$  computed by palette-sampling (Algorithm 1) when updating the partial coloring. We also note that the order of running these phases is crucial as some of them present further guarantees for subsequent phases, and some of them need to assume certain properties of the current partial coloring which will no longer remain true if we change the order of phases.

On the high level, the coloring procedure is as follows:

- Phase 1 One-Shot Coloring: We use the single color sampled in L<sub>1</sub>(v) for every vertex v ∈ V to color a large fraction of vertices. The effect of this coloring is that it "sparsifies" the graph for sparse vertices. We note that this part is standard and appears in many other coloring results starting from, to our knowledge, [44]; see [6] for more details.
- Phase 2 Lonely (or Social) Small Almost-Cliques: Recall
  that from Part (5.) of Section 4.5, we have a list of K<sub>lonely</sub> of
  almost-cliques that contains all lonely almost-cliques and potentially some social ones. We can easily also identify which
  of these almost-cliques are small (Definition 4.1) based on their
  size.
  - We will color all these small almost-cliques in  $\mathcal{K}_{lonely}$  by colors in  $L_2(\cdot)$ . This requires a novel argument that uses the facts that: (i) these almost-cliques are "loosely connected" to outside (no "high degree" neighbor, formally friend vertices, in their neighborhood), and (ii) the coloring outside only used a limited set of colors, namely, is sampled from  $L_1(\cdot)$  and  $L_2(\cdot)$  so far and is thus not "too adversarial" (recall the discussion we had in Lesson 3 regarding necessity of such arguments). Moreover, the coloring in this phase is an extension of the last one.
- Phase 3 Sparse Vertices: We then conclude the coloring of all sparse vertices using the sampled lists L<sub>3</sub>(v) for every sparse vertex v ∈ V (by Part (3.) of Section 4.5, we know these vertices). This part is also a standard argument as a continuation of Phase 1. But to apply this standard argument, we use the fact that even though we interleaved the standard approach with Phase 2 in the middle, since that coloring was only an extension of Phase 1 (meaning it did not recolor any vertex colored in Phase 1), the argument still easily goes through.

The coloring in this phase is also an extension of the last one. However, now that all sparse vertices are colored, we go ahead and remove the color of any vertex which is not sparse and nor is colored by Phase 2 (these are remnants of one-shot coloring in

<span id="page-11-2"></span> $<sup>^8\</sup>text{Technically},$  there is no need to even run Algorithm 3 separately for different guesses of  $\Lambda$ 

Phase 1 and we no longer need them now that all sparse vertices are colored). This is just to simplify the analysis for later parts. It is worth mentioning that this interleaving of Phase 2 in the middle of Phase 1 and 3 is crucial for our arguments (this is the chicken-and-egg problem mentioned in Section 2.2): the lists  $L_3(\cdot)$  used in Phase 3 are much larger than the rest and thus the "not-too-adversarial" property of coloring of outside vertices in Phase 2 will no longer be guaranteed had we changed the order of Phase 2 and 3; at the same time, changing the order of Phase 1 and 2 will also destroy the "sparsification" guarantee provided by Phase 1 for sparse vertices.

- Phase 4 Holey Almost-Cliques: The next step is to color holey almost-cliques (Definition 4.3), i.e., the ones with Ω(εΔ) non-edges inside them, using colors sampled in L4(·). We note that we actually do not know which almost-cliques are holey and which ones are not<sup>9</sup>. Instead, we simply run this phase over all remaining almost-cliques and argue that all the holey ones (and possibly some other ones) will get fully colored as desired. The proof of this phase is a simple generalization of a similar proof used in the palette sparsification theorem of [6], which even though quite technical, does not involve much novelty from us in this work. The coloring in this phase is an extension of the last one.
- Phase 5 Unholey Critical Almost-Cliques: By Observation 4.2, all large almost-cliques are holey. Thus, the largest remaining almost-cliques at this point are unholey critical almost-cliques. We know these almost-cliques in  $\mathcal{K}_{\text{critical}}$  by Part (6.) of Section 4.5 (the holey ones are already colored and it is possible, yet unlikely, that even some of unholey ones are also colored in Phase 4). We color the remainder of  $\mathcal{K}_{\text{critical}}$  now.

In the previous phases, we solely colored vertices from lists  $L(\cdot)$  sampled in palette-sampling. But we already know that such an approach is just not going to work for unholey critical almost-cliques (recall the example in Figure 1b discussed in Section 2.1). This is the first time we deviate from this approach (and thus deviate from palette sparsification-type arguments).

We now will use the critical-helper structures (Definition 4.6) – which our streaming algorithm collected in Part (6.) of Section 4.5 – and a new "out of palette" coloring argument, wherein we color one of the vertices of the almost-clique using a color not sampled for it, so that *two* vertices of the almost-clique are colored the *same*. We then show that this already buys us enough flexibility to color the remaining vertices using lists  $L_5(\cdot)$  of vertices similar to Phase 4. The coloring in this phase is also an extension of the last one.

• Phase 6 — Unholey Friendly Small Almost-Cliques: It can be verified that the only almost-cliques remained to color are the ones that are unholey, small, and also not lonely. They are perhaps the "most problematic" ones and are handled last<sup>10</sup>. These

almost-cliques also require the "out of palette" coloring argument used in Phase 5, but even this is not enough for them (we already discussed this regarding Figure 4b in Section 2.2). In particular, unlike Phase 4 and 5 that allowed for coloring of the almost-cliques even in the presence of adversarial coloring of outside vertices, this simply cannot be true for this phase (as shown in Figure 4b); at the same time, unlike Phase 2 almost-cliques, we cannot hope for a "random" coloring of outside vertices. To handle these almost-cliques, we rely on our friendly-helper structures (Definition 4.7) combined with a **recoloring step**: in

To handle these almost-cliques, we rely on our friendly-helper structures (Definition 4.7) combined with a **recoloring step**: in particular, we recolor one vertex outside of the almost-clique using the sampled lists  $L_6(\cdot)$  and show that this recoloring, plus another out of palette coloring argument, again buys us enough flexibility to color these almost-cliques also from lists  $L_6(\cdot)$  (we note that this out of palette coloring argument is in fact different from the one used in Phase 5). Finally, due to the recoloring step, the coloring in this phase is no longer an extension of the last one.

After all these phases, we have finished coloring all the vertices. In other words, we now have  $\Delta$ -coloring of the entire graph as desired. This will then conclude the proof of Theorem 1.

#### ACKNOWLEDGEMENTS

Sepehr Assadi would like to thank Soheil Behnezhad, Prantar Ghosh, Amit Chakrabarti, and Merav Parter for helpful conversations. We thank the organizers of DIMACS REU in Summer 2020, and Lazaros Gallos in particular, for initiating this collaboration and all their help and encouragement along the way. We are also thankful to the anonymous reviewers of STOC 2022 for helpful comments and suggestions on the presentation of the paper.

### REFERENCES

- <span id="page-12-6"></span> Amir Abboud, Keren Censor-Hillel, Seri Khoury, and Ami Paz. 2019. Smaller Cuts, Higher Lower Bounds. CoRR abs/1901.01630 (2019).
- <span id="page-12-5"></span>[2] Kook Jin Ahn, Sudipto Guha, and Andrew McGregor. 2012. Analyzing graph structure via linear measurements. In Proceedings of the Twenty-Third Annual ACM-SIAM Symposium on Discrete Algorithms, SODA 2012, Kyoto, Japan, January 17-19. 2012. 459-467.
- <span id="page-12-0"></span>[3] Noga Alon and Sepehr Assadi. 2020. Palette Sparsification Beyond (Δ + 1) Vertex Coloring. In Approximation, Randomization, and Combinatorial Optimization. Algorithms and Techniques, APPROX/RANDOM 2020, August 17-19, 2020, Virtual Conference (LIPIcs, Vol. 176), Jaroslaw Byrka and Raghu Meka (Eds.). Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 6:1-6:22.
- <span id="page-12-4"></span>[4] Noga Alon and Michael Tarsi. 1992. Colorings and orientations of graphs. Combinatorica 12, 2 (1992), 125–134.
- <span id="page-12-1"></span>[5] Sepehr Assadi, Andrew Chen, and Glenn Sun. 2021.. Deterministic Graph Coloring in the Streaming Model. CoRR abs/2109.14891. To appear in STOC 2022 (2021.). arXiv:2109.14891. https://arxiv.org/abs/2109.14891
- <span id="page-12-2"></span>[6] Sepehr Assadi, Yu Chen, and Sanjeev Khanna. 2019. Sublinear Algorithms for (Δ + 1) Vertex Coloring. In Proceedings of the Thirtieth Annual ACM-SIAM Symposium on Discrete Algorithms, SODA 2019, San Diego, California, USA, January 6-9, 2019. 767–786.
- <span id="page-12-8"></span>[7] Sepehr Assadi and Chen Wang. 2021. Sublinear Time and Space Algorithms for Correlation Clustering via Sparse-Dense Decompositions. CoRR abs/2109.14528. To appear in ITCS 2022. (2021). arXiv:2109.14528 https://arxiv.org/abs/2109.14528
- <span id="page-12-3"></span>[8] Bradley Baetz and David R Wood. 2014. Brooks' vertex-colouring theorem in linear time. arXiv preprint arXiv:1401.8023 (2014).
- <span id="page-12-7"></span>[9] Alkida Balliu, Sebastian Brandt, Fabian Kuhn, and Dennis Olivetti. 2021. Distributed Δ-Coloring Plays Hide-and-Seek. CoRR abs/2110.00643. To appear in STOC 2022. (2021).

<span id="page-12-9"></span><sup>&</sup>lt;sup>9</sup>Technically, we could have designed a semi-streaming algorithm that also recovers this information about the decomposition (at least approximately) – however, as we explain next this is not needed.

<span id="page-12-10"></span>explain next, this is not needed.  $^{10}$ It is quite natural to ask if these almost-cliques are the "hardest" to color, why do we wait to color them after everything else, at which time, our hands might be too tied? There are two closely related answers: (i) they may just be connected to each other (or rather the graph can only consists of these types of almost-cliques) and thus we anyway have to deal with at least one of them after having colored the rest of the graph; and (ii) even though they are "hard" to color, they are somewhat "more robust"

also, compared to say Phase 2 almost-cliques, in that we can color them even when their outside neighbors are colored adversarially by using a key recoloring step.

- <span id="page-13-27"></span><span id="page-13-0"></span>[10] Paul Beame, Paraschos Koutris, and Dan Suciu. 2017. Communication Steps for Parallel Query Processing. J. ACM 64, 6 (2017), 40:1–40:58.
- <span id="page-13-1"></span>[11] Soheil Behnezhad, Mahsa Derakhshan, MohammadTaghi Hajiaghayi, Marina Knittel, and Hamed Saleh. 2019. Streaming and Massively Parallel Algorithms for Edge Coloring. In 27th Annual European Symposium on Algorithms, ESA 2019, September 9-11, 2019, Munich/Garching, Germany (LIPIcs, Vol. 144), Michael A. Bender, Ola Svensson, and Grzegorz Herman (Eds.). Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 15:1-15:14.
- <span id="page-13-23"></span>[12] Suman K. Bera, Amit Chakrabarti, and Prantar Ghosh. 2020. Graph Coloring via Degeneracy in Streaming and Other Space-Conscious Models. In 47th International Colloquium on Automata, Languages, and Programming, ICALP 2020, July 8-11, 2020, Saarbrücken, Germany (Virtual Conference). 11:1–11:21.
- <span id="page-13-32"></span>[13] Suman Kalyan Bera and Prantar Ghosh. 2018. Coloring in Graph Streams. CoRR abs/1807.07640 (2018).
- <span id="page-13-2"></span>[14] Anup Bhattacharya, Arijit Bishnu, Gopinath Mishra, and Anannya Upasana. 2021. Even the Easiest(?) Graph Coloring Problem Is Not Easy in Streaming!. In 12th Innovations in Theoretical Computer Science Conference, ITCS 2021, January 6-8, 2021, Virtual Conference (LIPIcs, Vol. 185), James R. Lee (Ed.). Schloss Dagstuhl – Leibniz-Zentrum für Informatik, 15:1–15:19.
- <span id="page-13-36"></span>[15] Oleg V Borodin and Alexandr V Kostochka. 1977. On an upper bound of a graph's chromatic number, depending on the graph's degree and density. *Journal* of Combinatorial Theory, Series B 23, 2-3 (1977), 247–250.
- <span id="page-13-20"></span>[16] Sebastian Brandt, Orr Fischer, Juho Hirvonen, Barbara Keller, Tuomo Lempiäinen, Joel Rybicki, Jukka Suomela, and Jara Uitto. 2016. A lower bound for the distributed Lovász local lemma. In Proceedings of the 48th Annual ACM SIGACT Symposium on Theory of Computing, STOC 2016, Cambridge, MA, USA, June 18-21, 2016. 479-488.
- <span id="page-13-7"></span>[17] Rowland Leonard Brooks. 1941. On colouring the nodes of a network. In Mathematical Proceedings of the Cambridge Philosophical Society, Vol. 37. Cambridge University Press, 194–197.
- <span id="page-13-41"></span>[18] Harry Buhrman and Ronald de Wolf. 2002. Complexity measures and decision tree complexity: a survey. Theor. Comput. Sci. 288, 1 (2002), 21–43.
- <span id="page-13-3"></span>[19] Amit Chakrabarti, Prantar Ghosh, and Manuel Stoeckl. 2021. Adversarially Robust Coloring for Graph Streams. CoRR abs/2109.11130. To appear in ITCS 2022 (2021).
- <span id="page-13-43"></span>[20] Yi-Jun Chang, Wenzheng Li, and Seth Pettie. 2018. An optimal distributed (Δ + 1)-coloring algorithm?. In Proceedings of the 50th Annual ACM SIGACT Symposium on Theory of Computing, STOC 2018, Los Angeles, CA, USA, June 25-29, 2018. 445-456.
- <span id="page-13-29"></span>[21] Graham Cormode, Jacques Dark, and Christian Konrad. 2019. Independent Sets in Vertex-Arrival Streams. In 46th International Colloquium on Automata, Languages, and Programming, ICALP 2019, July 9-12, 2019, Patras, Greece (LIPIcs, Vol. 132), Christel Baier, Ioannis Chatzigiannakis, Paola Flocchini, and Stefano Leonardi (Eds.). Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 45:1–45:14.
- <span id="page-13-12"></span>[22] Daniel W Cranston and Landon Rabern. 2015. Brooks' Theorem and beyond. Journal of Graph Theory 80, 3 (2015), 199–225.
- <span id="page-13-33"></span>[23] Artur Czumaj, Peter Davies, and Merav Parter. 2020. Simple, Deterministic, Constant-Round Coloring in the Congested Clique. In PODC '20: ACM Symposium on Principles of Distributed Computing, Virtual Event, Italy, August 3-7, 2020, Yuval Emek and Christian Cachin (Eds.). ACM, 309–318.
- <span id="page-13-34"></span>[24] Artur Czumaj, Peter Davies, and Merav Parter. 2021. Improved Deterministic (Δ + 1) Coloring in Low-Space MPC. In PODC '21: ACM Symposium on Principles of Distributed Computing, Virtual Event, Italy, July 26-30, 2021, Avery Miller, Keren Censor-Hillel, and Janne H. Korhonen (Eds.). ACM, 469–479.
- <span id="page-13-47"></span>[25] Abhik Kumar Das and Sriram Vishwanath. 2013. On finite alphabet compressive sensing. In 2013 IEEE International Conference on Acoustics, Speech and Signal Processing. IEEE, 5890–5894.
- <span id="page-13-24"></span>[26] Paul Erdos, Arthur L Rubin, and Herbert Taylor. 1979. Choosability in graphs. In Proc. West Coast Conf. on Combinatorics, Graph Theory and Computing, Congressus Numerantium, Vol. 26. 125–157.
- <span id="page-13-6"></span>[27] Joan Feigenbaum, Sampath Kannan, Andrew McGregor, Siddharth Suri, and Jian Zhang. 2005. On graph problems in a semi-streaming model. *Theor. Comput. Sci.* 348, 2-3 (2005), 207–216.
- <span id="page-13-25"></span>[28] Joan Feigenbaum, Sampath Kannan, Andrew McGregor, Siddharth Suri, and Jian Zhang. 2008. Graph Distances in the Data-Stream Model. SIAM J. Comput. 38, 5 (2008), 1709–1727.
- <span id="page-13-21"></span>[29] Mohsen Ghaffari, Juho Hirvonen, Fabian Kuhn, and Yannic Maus. 2018. Improved Distributed Delta-Coloring. In Proceedings of the 2018 ACM Symposium on Principles of Distributed Computing, PODC 2018, Egham, United Kingdom, July 23-27, 2018. 427-436.
- <span id="page-13-16"></span>[30] Péter Hajnal and Endre Szemerédi. 1990. Brooks coloring in parallel. SIAM journal on Discrete Mathematics 3, 1 (1990), 74–80.
- <span id="page-13-31"></span>[31] Bjarni V. Halldórsson, Magnús M. Halldórsson, Elena Losievskaja, and Mario Szegedy. 2016. Streaming Algorithms for Independent Sets in Sparse Hypergraphs.

- Algorithmica 76, 2 (2016), 490-501.
- <span id="page-13-44"></span>[32] Magnús M. Halldórsson, Fabian Kuhn, Yannic Maus, and Tigran Tonoyan. 2021. Efficient randomized distributed coloring in CONGEST. In STOC '21: 53rd Annual ACM SIGACT Symposium on Theory of Computing. Virtual Event, Italy, June 21-25, 2021, Samir Khuller and Virginia Vassilevska Williams (Eds.). ACM, 1180-1193.
- <span id="page-13-4"></span>[33] Magnús M. Halldórsson, Fabian Kuhn, Alexandre Nolin, and Tigran Tonoyan. 2021. Near-Optimal Distributed Degree+1 Coloring. CoRR abs/2112.00604. To appear in STOC 2022. (2021).
- <span id="page-13-30"></span>[34] Magnús M. Halldórsson, Xiaoming Sun, Mario Szegedy, and Chengu Wang. 2012. Streaming and Communication Complexity of Clique Approximation. In Automata, Languages, and Programming - 39th International Colloquium, ICALP 2012, Warwick, UK, July 9-13, 2012, Proceedings, Part I (Lecture Notes in Computer Science, Vol. 7391), Artur Czumaj, Kurt Mehlhorn, Andrew M. Pitts, and Roger Wattenhofer (Eds.). Springer, 449–460.
- <span id="page-13-45"></span>[35] David G Harris, Johannes Schneider, and Hsin-Hao Su. 2016. Distributed (Δ + 1)-coloring in sublogarithmic rounds. In *Proceedings of the forty-eighth annual ACM symposium on Theory of Computing*. ACM, 465–478.
   [36] T. S. Jayram, Ravi Kumar, and D. Sivakumar. 2003. Two applications of informations.
- <span id="page-13-42"></span>[36] T. S. Jayram, Ravi Kumar, and D. Sivakumar. 2003. Two applications of information complexity. In Proceedings of the 35th Annual ACM Symposium on Theory of Computing, June 9-11, 2003, San Diego, CA, USA, Lawrence L. Larmore and Michel X. Goemans (Eds.). ACM, 673-682.
- <span id="page-13-17"></span>[37] Mauricio Karchmer and Joseph Naor. 1988. A fast parallel algorithm to color a graph with  $\Delta$  colors. *Journal of Algorithms* 9, 1 (1988), 83–91.
- <span id="page-13-18"></span>[38] Howard J. Karloff. 1989. An NC Algorithm for Brooks' Theorem. Theor. Comput. Sci. 68, 1 (1989), 89–103.
- <span id="page-13-28"></span>[39] Howard J. Karloff, Siddharth Suri, and Sergei Vassilvitskii. 2010. A Model of Computation for MapReduce. In Proceedings of the Twenty-First Annual ACM-SIAM Symposium on Discrete Algorithms, SODA 2010, Austin, Texas, USA, January 17-19, 2010, Moses Charikar (Ed.). SIAM, 938–948.
- <span id="page-13-37"></span>[40] Alexandr V Kostochka, Landon Rabern, and Michael Stiebitz. 2012. Graphs with chromatic number close to maximum degree. *Discrete Mathematics* 312, 6 (2012), 1273–1281.
- <span id="page-13-9"></span>[41] László Lovász. 1975. Three short proofs in graph theory. Journal of Combinatorial Theory, Series B 19, 3 (1975), 269–271.
- <span id="page-13-26"></span>[42] Andrew McGregor. 2014. Graph stream algorithms: a survey. SIGMOD Rec. 43, 1 (2014), 9–20.
- <span id="page-13-8"></span>[43] LS Melnikov and VG Vizing. 1969. New proof of Brooks' theorem. Journal of Combinatorial Theory 7, 4 (1969), 289–290.
- <span id="page-13-40"></span>[44] Michael Molloy and Bruce Reed. 1997. A bound on the strong chromatic index of a graph. Journal of Combinatorial Theory, Series B 69, 2 (1997), 103–109.
- <span id="page-13-10"></span>[45] Michael Molloy and Bruce Reed. 2013. Graph colouring and the probabilistic method. Vol. 23. Springer Science & Business Media.
- <span id="page-13-38"></span>[46] Michael Molloy and Bruce A. Reed. 2014. Colouring graphs when the number of colours is almost the maximum degree. J. Comb. Theory, Ser. B 109 (2014), 134–195.
- <span id="page-13-22"></span>[47] Alessandro Panconesi and Aravind Srinivasan. 1992. Improved Distributed Algorithms for Coloring and Network Decomposition Problems. In Proceedings of the 24th Annual ACM Symposium on Theory of Computing, May 4-6, 1992, Victoria, British Columbia, Canada. 581–592.
- <span id="page-13-19"></span>[48] Alessandro Panconesi and Aravind Srinivasan. 1995. The local nature of  $\Delta$ -coloring and its algorithmic applications. *Combinatorica* 15, 2 (1995), 255–280.
- <span id="page-13-46"></span>[49] Merav Parter. 2018. (Δ + 1) Coloring in the Congested Clique Model. In 45th International Colloquium on Automata, Languages, and Programming, ICALP 2018, July 9-13, 2018, Prague, Czech Republic (LIPIcs, Vol. 107), Ioannis Chatzigiannakis, Christos Kaklamanis, Dániel Marx, and Donald Sannella (Eds.). Schloss Dagstuhl - Leibniz-Zentrum für Informatik, 160:1–160:14.
- <span id="page-13-13"></span>[50] Landon Rabern. 2012. A different short proof of Brooks' theorem. arXiv preprint arXiv:1205.3253 (2012).
- <span id="page-13-14"></span>[51] Landon Rabern. 2014. Yet another proof of Brooks' theorem. arXiv preprint arXiv:1409.6812 (2014).
- <span id="page-13-5"></span>[52] Jaikumar Radhakrishnan and Saswata Shannigrahi. 2011. Streaming Algorithms for 2-Coloring Uniform Hypergraphs. In Algorithms and Data Structures - 12th International Symposium, WADS 2011, New York, NY, USA, August 15-17, 2011. Proceedings (Lecture Notes in Computer Science, Vol. 6844), Frank Dehne, John Iacono, and Jörg-Rüdiger Sack (Eds.). Springer, 667-678.
- <span id="page-13-39"></span>[53] Bruce A. Reed. 1998.  $\omega$ ,  $\Delta$ , and  $\chi$ . Journal of Graph Theory 27, 4 (1998), 177–212.
- <span id="page-13-35"></span>[54] Bruce A. Reed. 1999. A Strengthening of Brooks' Theorem. J. Comb. Theory, Ser. B 76, 2 (1999), 136–149.
- <span id="page-13-15"></span>[55] San Skulrattanakulchai. 2002. Delta-List Vertex Coloring in Linear Time. In Algorithm Theory - SWAT 2002, 8th Scandinavian Workshop on Algorithm Theory, Turku, Finland, July 3-5, 2002 Proceedings. 240–248.
- <span id="page-13-11"></span>[56] Michael Stiebitz and Bjarne Toft. 2015. Brooks's theorem. Topics in Chromatic Graph Theory 165 (2015), 36-55.