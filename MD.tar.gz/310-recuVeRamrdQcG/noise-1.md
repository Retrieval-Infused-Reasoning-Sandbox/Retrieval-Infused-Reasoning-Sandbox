![](_page_0_Picture_0.jpeg)

# Completeness Theorems for Non-Cryptographic Fault-Tolerant Distributed Computation

(Extended Abstract)

Michael Ben-Or\* Shafi Goldwassert Hebrew University MIT

Avi Wigdemon\* Hebrew University

## Abstract

Every function of n inputs can be efficiently computed by a complete network of n processors in such a way that:

- 1. If no faults occur, no set of size t < n/2 of players gets any additional information (other than the function value),
- 2. Even if Byzantine faults are allowed, no set of size t < n/3 can either disrupt the computation or get additional information.

Furthermore, the above bounds on t are tight!

# Introduction

The rapid development of distributed systems raised the natural question of what tasks can be performed by them (especially when faults occur). A large body of literature over the past ten years addressed this question. There are two approaches to this question, depending on whether a limit on the computational power of processors is assun or not.

The cryptographic approach, inaugurated by Difiie and Hellman [DH], assumes the players are computationally bounded, and further assumes the existence

Permission to copy without fee all or part of this material is granted provided that the copies are not made or distributed for direct commercial advantage. - the ACM copyright notice and the title of the publication and its date appear, a&l notice is given that copying is by permission of the Association for Computing Machinery. TO copy otherwise. or to republish. requires a fee and/or specfk permissiotl.

of certain (one-way) functions, that can be computed but not inverted by the player.

This simple assumption was ppstulated in [DH] in order to achieve the basic task of secure message exchange between two of the processors, but turned out to be universal! In subsequent years ingenious protocols baaed on the same assumption were given for increasingly harder tasks such as contract signing, secret exchange, joint coin flipping, voting and playing Poker. These results culminated, through the definition of zero-knowledge proofs [GMR], their existence for NP-complete problems [GMWl] in completeness theorems for two-party pl] and multi-party [GMW2] cryptographic distributed computation. In particular the results of Goldreich, Micali and Wigdesrson in [GMWB] were the main inspiration to our work. They show, that if (non-uniform) one way functions exist then every (probabilistic) function of n input,s can be computed by n computationally bounded processors in such a way that: (1) If no faults occur, no subset of the players can compute any additional information, and (2) Even if Byzantine faults are allowed, no set of size t < n/2 can either disrupt the computation or compute additional information.

The non-Cryptographic (or information-theoretic) approach does not limit the computational power of the processors. Here, the notion of privacy is much stronger - for a piece of data to be unknown to a set of players it does not suffice that they cannot compute it within a certain time bound from what they know, but simply that it cannot be computed at all!

To facilitate the basic primitive of secret message exchange between a pair of players, we have secure channels. (For an excellent source of results and problems in the case no secure channels exist, see [BL]). Unlike the cryptographic case, very little was known about the capabilities of this model. Two main basic problems were studied and solved (in the synchronous case): Byzantine agreement [LPS,DS,...] and collective coin flipping p2].

<sup>\*</sup>Supported by Alon Fellowship.

tSupported in part by NSF grant 865727~CCR, AR0 grant DAALOWSK-017, and US-Israel BSF grant 8640301, Jerusalem, Israel.

<sup>:</sup>Supported by Alon Fellowship.

This paper provides a full understanding of the: power and limits of this model, by proviug a few completeness theorems. Comparing these results t#o the cryptographic case of [GMW:!], one gets the imprcssion that one-way functions ar'e "more powerful" th:tn secure channels. This should not be surprising, if ale considers the case of n = 2. Clearl,y, here a secure channel is useless, and indeed two (non-faulty) players can compute the OR function of their bits using cryptography, while the reader can convince herself (it will be proven later) that any protocol will leak information in the information-theoretic sense. The lower bounds we provide show that the same phznomenon is true for any value of n. A similar situation arises in the Byzantine case where, using cryptogr,iphy one can allow t < n/2 faulty players, but in tile non-Cryptogra.phic case one must have t < n/3.

As happened in the crypt.ographic case, the protocols are based on a new mc,thod for comput,ing with shared secrets. Our constructions are based on AIgc: hraic Coding Theory, particul;rrly the use of gcnc>ralizcd BCll codes.

It is important to stress here that our main protocols require only a polynomial amount of work from the players. (In fact, they are efficient enough to be practical!). Putting no bound on the computational power serves only to allow the most stringent delinition of privacy and the most liberal definition cf faultiness, both of which we can handle.

Essentially the same results we obtain here were independentIy discovered by Chaum, Crepeau and Darngard [CCD]. We briefly point out the small dif: ferences of this work from OUPS. The simple case of no faults is almost identical. Their solution in the case of Byzantine faults is elementary and requires no error correcting codes. The error correction is achieved using a clever scheme of zero knowledge proofs. 'I'llis has two consequences: They have to allow an exponentially small error probability for both correct, ness and privacy (we can guarantee them with no cr. rors), and the frequent zero knowledge proofs increase! the complexity of their protocols. In the solution of [CCD] the simulation is of Boolean operations while our solution allows direct simula.tion of arithmetic op.. erations in large finite fields. Thus, for example, corm puting the product of two n hit numbers using [CCD: calls for O(log n) communication rounds. This can bc, done in O(1) rounds using our solution.

We mention that the above results already found application in the new, constant expected number 01' rounds protocol for Byzantine agreement of Feldman and Micah [FM].

We proceed to define the model, state the results and prove them. In the full paper we mention gener-

alizations aud cxtc%nsions of our rrsulL+ t.o ol.llc>r Itasks (playing panics ratllcr than comp~ll,inl; fIiII(\*~~iolls), t,o other model param&rs (synchrony, ,:.ollll~lultici~t ion networks) and other complexity meitSnrrs (nu~~hcr of rounds).

# Definitions and Results

For this abstract, we define the model and state the results on an intuitive level. Since even the formal definition of the notions of privacy and resiliency are nontrivial, we give them explicitly in an appendix.

The model of computation is a complete synchronous network of n processors. The pairwise communication channels between players are secure, i.e. they cannot be rrad or t.empered with 1~~ other playcrs. In ow round of co~iiput~at~ioli cwch d 1 Iw play- (xrs ca.n tlo an arbitrary i~~llOlllll~ cd" local wllqwt a1 ion. send a message t.0 each of t.he players, and rc>ad all messages that w(xrc scxnt, to it, at, this round.

We shall be iilt.clrc&4 in t.hc coiilp\il.:ll.icwal p(\w\'llr of this model when imposing privacy and fault. tolerance requirements. For simplicity, we restrict ourselves to the computation of (probabilistic) functions f from R inputs to n, out,puts. We assume t,liat player i holds the i-th input at the start of computation, and should obtain the i-th output at the end, but nothing else.

A protocol for computing a function is a specification of 12 programs, one for each of the players. We distinguish two kinds of faults: "Gossip" and "Byzantine". In the first, faulty processors send messages according to their predetermined programs, but try to learn as much as they can by sharing the information they received. In t,he scrond, thry can WC t.obnlly different, prograins, collal~or:~ting to :icqliirc> morcx iriformation of even sabotage the computa.tion.

A prot,ocol is t-ptivnle if any set of at most 1 players cannot compute aft.cr t,hc protocol more> l.lic~~ t.hy could jointly compute solely from their set of privalc inputs and outputs.

A protocol is t-resilienl if no set of f or less players can influence the correctness of the output,s of t,he remaining players. For this to make sct~se, the function definition should be extended to specify what it is if some players neglect to give their inpnts or are caught cheating (see appendix).

We can now state the main results of this paper.

Theorem 1: For every (probabilistic) fun.clion f ad t < ?a/2 there exists a t-private prolocol.

Thcorcm 2: There are functions for which there we no n/2-private protocols.

Theorem 3: For every probabilistic function and every t < n/3 there exists a protocol that is both tresilient and t-private.

Theorem 4: There are functions for which there is no n/3-resilient protocol.

# Proof of Theorem 1

LetPo,...,P,-l be a set of players, and let n 2 2t+ 1. Let F be the function which this set of players wants to compute t-privately, where each player holds some input variables to the function F. Let E be some fixed finite field E, with [El > n. Without loss of generality we may assume that all inputs are elements from E and that F is some polynomial (in the input variables) over E, and that we are given some arithmetic circuit computing IFI, using the operations +, x and constants from E.

To simplify our explanation we divide the computation int.o three st.ages.

Stage I: 'Hrc: input stage, whcrc each player will ent.cr his input, variables t.0 the computation using a srcrcrl. sharing procedure.

Stage II: The coinput.ation stage, where the players will simulate the circuit computing F, gate by gat,e, keeping the value of each computed gate as secret shared by all players.

Stage III: The final stage, where the secret shares of the final value of F are revealed to one or all of the players.

Stages I and III are very simple and we describe them below, and delay the details of the computation st,age t,o the next section.

## The input stage

I,(4 (k(], . . 1 CY,,-1 be some n disbinct, non zero points iu our lic,l(l E. (This is why we urctl [[:I > n.) Each playc>r holtliug some input s E LS, iutroduccs l,he input i,o t,hc corl~l~~rl.;~~.iotl by selecting t random elcment,s (li E E, for i = l,, . . ,1, setting

$$f(x) = s + a_1 x + \cdots + a_t x^t$$

and sending to each player Pi the value Si = f(ai).

As in Shamir's [Sh] secret sharing scheme, the seqtience (so,. . . , s,,-~) is a sequence of i-wise independent random variables uniformly distributed over E, thus the value of the input is completely independent from the shares (si} that are given to any set of t player that does not include the player holding the secret.

### The final stage

To keep the t-privacy condition, we will make sure that the set of messages received by any set oft players will be completely independent from all the inpubs. During the whole computation each gate which evaluates to some s E E, will be "evaluated" by the players by sharing the secret value of 8 using a completely independent from all the inputs, random polynomial f(t) of degree t, with the only restriction that f(0) = s. In particular at the end of the computation we will have the value of F shared among the players in a similar manner. If we want to let just one player know the output value, all the players send their shares to that particular player. This player can compute the interpolation polynomial f(z) and use its free coefficient as the result.

Note that there is a one-to-one correspondence between the set of all shares and the coefficients of the polynomial f( 2). S ince all the coefficients of f(z), except for its free coeffGent, are uniform random variables lhat are independent of the inputs, the set of all shares does not contain any information about the inputs that does not follow from the value of J(0).

# The Computation Stage

Let Q, b E E be two secrets that are shared using the polynomials f(x),g(r) respectively, and let c E E, c # 0 be some constant. It is enough to show how one can "compute" c. a, a + 6, and a. b.

The two linear operations are simple and for their evaluation we do not need any communication between the players. This is because if f(z) and g(z) encode a and 6, then the polynomials h(z) = c.f(t) and k(l) = fb)+!J( x > encode c.a, a+ b respectively. Thus to compute for example a +b, each player Pi holding /(nil, ad dni) can c0mput.c h(cYi) = f((Yi) + fJ(CYi). Likowise, since c is A known constant F'r can compute h(tri) = c.f(cq). F ur th crmore, h(z) is random if only f(x) was, and k(x) is random if only one of l(z) or S(X) Wm.

As a corollary we immediately have

Lemma: (Linear Functional) For any t, (t 5 n - l), and any linear functional

$$F(x_0,\ldots,x_{n-1})=a_0x_0+\cdots+a_{n-1}x_{n-1}$$

where each Pi has input xi and the ai are known constants, can be computed t-privately.

From the lemma we have

CoroHary: (Matrix Multiplication) Let A be a con-, stant n x TI matrix, and let 'each I\ have an in., put variable xi. Let X = (~0, \_ . . , zn,-l) and define Y = (~1,.-,vn> by

$$Y = X \cdot A$$

then for any t, (t 5 n- l), we can t-privately compute the vector Y such that the only information given tcl Piwillbethevalueof~,fori=O ,..., n-l.

Proof: Matrix multiplication is ,just the evaluation 01' n linear functionals. By the Lemma, we can compute, each linear functional Yi independently, and revea': the outcome only to Pi.

## The multiplication step

The multiplication step is only a bit harder. Let o and b be encoded by f(z) and g(x) as above. We nou' assume that n > 2t + 1. Note thlat the free coefficienl, of the polynom%l h(z) = f(z)g(r) is a. b. There arc two problems with using h(z) to encode the product of a times b. The first, and obvious one, is that the degree of h(z) is 2t instead of t. While this poser, no problem with interpolating 11(z) from its n pieces since n > 2t+l, it is clear that further multiplications, will raise the degree, and once the degree passes n we will not have enough points for the interpolation The second problem is more subtle. h(t) is not a, random polynomial of degree 2t (ignoring of course! the free coefficient). For example, h(z), as a product of two polynomials, cannot be irreducible.

To overcome these two problems we will, in one! step, randomize the coefficients of h(z), and reduce it:, degree while keeping the free coefficient unchanged We first describe the degree reduction procedure and then combine it with the randomization of the coefficients.

#### The degree reduction s.tep

Let

$$h(x) = h_0 + h_1 x + \dots + h_{2t} x^{2t}$$

and let

$$s_i = h(\alpha_i) = f(\alpha_i)g(\alpha_i)$$

for i=O,..., n - 1 be the "shares" of h(z). Each Pi holds an si. Define the truncation of h(z) to be

$$k(x) = h_0 + h_1 x + \dots + h_t x^t$$

and 
$$r_i = k(\alpha_i)$$
 for  $i = 1, ..., n-1$ 

Chim: Let S = (SO,... , b-1 ) and It = (PO,. . . , rn- 1) then there is a constant n x n matrix A such that

$$R = S \cdot A$$

Proof: Let H be the n-vector

$$H=(h_0,\ldots,h_t,\ldots,h_{2t},0,\ldots,0)$$

and let I< be the n-vector

$$K=(h_0,\ldots,h_t,0,\ldots,0).$$

Let B = (bij) be the n x n (Vandermonde) matrix, where bi,j = CX~ for i,j = 0,. . . , n - 1. Furthermore, let P be the linear projection

$$P(x_0,\ldots,x_{n-1})=(x_0,\ldots,x_t,0,\ldots,0).$$

We have

$$H \cdot B = S$$

$$H \cdot P = K$$

and

$$K \cdot B = R.$$

Since B is not singular (because the ai- are distinct) we have

$$S \cdot (B^{-1}PB) = R$$

but A = B-'PB is some fixed constant matrix, proving our claim.

## The randomization step

As noted above the coefficients of the product polynomial are not completely random, and likewise the coefficients of its truncation b(z) may not be completely random. To randomize the coefficients, each player Pi randomly selects a polynomial qi(z) of degree 22 with a zero free coefficient, and dist,ributes its shares among the players. By a simple gencralization of the argument, in Shamir's [Shl scheme. it is easy to see that knowing t values on tl;is polynomial gives no information on the vector of coefficients of the monomials of t, xz, . . . , xt of qi(+).

Thus instead of using h(t) in our reduction we can

use 
$$\tilde{h}(x) = h(x) + \sum_{j=0}^{n-1} q_j(x)$$

which satisfies h(O) = h(O) but the other coefficients of zi, 1 5 i 5 t, are completely random. Since each player can evaluate his point & = h(cyi), we can now apply the truncation procedure using the matrix multiplication lemma to arrive at a completely random polynomial I(z) which satisfies both degi(3:) = I, and k(O) = a . b, and k(z) is properly \*,haretl a.msng all the players.

Thus (omitting many well known tl<>bdls, see [GM W]) we hn.vc proved

Theorem 1: For every (probabilistic) function F and 1 < n/2 lhere exisls a t-private protocol.

#### Remarks:

- (1) The complexity of computing F t-privately is bounded by a polynomial (in n) factor times the complexity of computing F.
- (2) If F can be computed by an arithmetic circuit over some field using unbounded fan-in linear operation and bounded fan-in multiplication, in depth d, then F can be computed t-privately in O(d) rounds of exchange of information.
- (3) In our construction we have to reduce the degree of our polynomial only when its degree is about to pass n-1. Thus if  $t = O(n^{1-\epsilon})$ , for some fixed  $\epsilon > 0$ , and we start with polynomials of degree t, the players can simulate many steps of the computation before the degree comes close to n, by doing the computation each on their own shares, without any communication(!). When the degree does get close to n, we reduce the degree back to t in one radomizing, degree reducing step.

Two simple examples are:

- a. Any Boolean function  $F: \{0,1\}^n \to \{0,1\}$  can be represented as a multilinear polynomial over the field F. Thus if  $t = O(n^{1-\epsilon})$  we can compute t-privately, in parallel, all the monomials of F in O(1) number of rounds and then use a big fan-in addition to evaluate F. This procedure may use exponentially long messages but only constant number of rounds.
- b. The Boolean Majority function has a polynomial size  $O(\log n)$  depth circuit, and thus for  $t = O(n^{1-\epsilon})$ , this function can be computed t-privately using only polynomially long messages in constant number of rounds.

For completeness we state the following simple result

**Theorem 2:** There are functions for which there are no n/2 – private protocols.

*Proof:* It is easy to see that two players, each holding one input bit, cannot compute the OR function of their bits, without one of them leaking some information. This immediately generalizes to prove the theorem.

# Sharing a secret with Cheaters:

Let n = 3t + 1 and let  $P_0, \ldots, P_{n-1}$  be a set of n players among which we want to share a secret such that

- (A) Any set of at most t players does not have any information about the secret and
- (B) It is easy to compute the secret from all its shares even if up to t pieces are wrong or missing.

The following scheme achieves both requirements: Let E be a (finite) field with a primitive n-th root of unity,  $\omega \in E$ ,  $\omega^n = 1$  and for all 1 < j < n,  $\omega^j \neq 1$ . Without loss of generality we can assume that our secret s is in E.

Pick a random polynomial  $f(x) \in E[x]$ , of degree t such that f(0) = s. That is, set  $a_0 = s$  and pick random  $a_i \in E$  for  $i = 1 \dots t$  and set

$$f(x) = a_0 + a_1 x + \dots + a_t x^t.$$

Define the share of  $P_i$ , i = 0...n-1, to be  $s_i = f(\omega^i)$ . As in [Sh], the  $s_i$ -s are t-wise independent random variables that are uniformly distributed over E, and thus our first requirement (A) is met.

Note that setting  $a_i = 0$  for i > t makes our secret shares the Discrete Fourier Transform of the sequence  $(a_0, \ldots, a_{n-1})$ . Let  $\hat{f}(x) = s_0 + s_1 x + \cdots + s_{n-1} x^{n-1}$ . By the well known formula for the inverse transform

$$a_i = \frac{1}{n}\hat{f}(\omega^{-i})$$

and in particular  $\hat{f}(\omega^{-i}) = 0$  for i = t + 1, ..., n - 1. Explicitly the  $s_i$  satisfy the linear equations

$$\sum_{i=0}^{n-1} \omega^{r \cdot i} \cdot s_i = 0 \quad \text{for} \quad r = 1, \dots, 2t.$$

Thus the polynomial  $g(x) = \prod_{i=t+1}^{n-1} (x - \omega^{-i})$  divides the polynomial  $\hat{f}(x)$ , which in the language of Error Correcting Codes says that the vector  $s = (s_0, \ldots, s_{n-1})$  is a codeword in the Cyclic Code of length n generated by g(x). By our choice of g(x), this cyclic code is the well known Generalized Reed-Miller code. Such codes have a simple error correction procedure to correct  $\frac{1}{2} \deg g(x) = t$  errors. See for example [PW, page 283].

# Verifying a secret

Assume that player P has distributed a secret in the manner described above. Before entering this shared secret into a computation we wish to verify that the

secret shares we are holding are shares of a real secret and not some n random numbers. We want to do SC without revealing any informat#ion about the secret or any of its shares. This is easily done using the following Zero Knowledge proof technique, We &ill later show how to verify a secret using a different technique that has absolutely no proba.bility of error. We present this Zero Knowledge technique because it is simpler, and uses fewer roundls of communication.

# Simple verification of a secret

Let fo be the original polynomial. Let fi, . . . , fm, m = 3n be random polynomials of degree t generated by P, and have P send to Pi the values fj(w') for j= l,..., m. Each Pi selectes a random a # 0 from E and sends it to all the other players. After reaching agreement on the set of Q-S ,the dealer broadcasts the set of polynomials f" = cr='=o ak fr; to all players. Each player Pi checks that at the point wi, the shares he received satisfy the required equations, for all the cr-s. If some Pi finds an error he broadcasts his complaint. If 1+ 1 or more player file a complaint, we decide that the dealer is faulty and take some default value, say 0, to be the dealers secret, (and pick 0 for all the needed shares).

Cl&n: Let 7' be a set of good players that did nob complain. Let J\*T be the the interpolation polynomial through the points in T of the original ,polynomial fi. Then with probability at least

$$1 - m2^n/|E|$$

all the polynomials f,T are of degree t.

Proof Omitted.

Keeping in mind the (polynomial) complexity of the players computation, we can certainly allow IEl 2 22". This makes the error probability exponentially small. (The case of small IEJ is similar: Using a somewhat Inrgw in, each player, using a diffcrcnt sc?t of rautlotn polynomials, asks the clealcr to reveal c!it,llc?r li or Jo + fi-)

Note that if n 2 51 + 1, then our srcrct, sharing sclietnc can correc.t 2t errors. If a secrcl, is ilCCPlIl.C'tl then at most t good players may have wrong values. This together with at most 1 more wrong values that may come from the bad players, gives altogether at most 2t errors. Thus in this case the secret is uniquely defined and there is a simple procedure to recover its value using the error correcting procedure.

To handle the case of n = 3t + 1 we must make sure that all the pieces in the hands of the good players lie on a polynomial of degree 1. To achieve this we ask the dealer of the secret to make public all t,he values that were sent to each player who filed a complaint. We now repeat the test, using new random C-Y-S. Each player now checks at his point and at all t.hc poiat,s that were made public, and if there is an error IIC files a complaint. If by now more t,han 1 + 1 pla.yers I~nvc complained we all decide that the sccrc4 is bad i11lci take the default zero polynomial. Otherwise,

Claim: With very high probability, all good players are on a polynomial of degree t.

Proof: Omitted.

Note that if the dealer is correct then no good player's value will become public during the verification process. This together with the fact that all the polynomials that the dealer reveals during this verification procedure are completely independent from the secret polynomial fo, ensures that the bad players will not gain any information about the dealer's secret. (Detailed proof omitted).

## Absolute verification of a secret

The verification procedure describrd above lcnvcs a11 exponent,ially snlall pr0habilit.y of c?rror. 111 this scc-Lion wc dcscribc a srcrct. vcrificntiou proccdurc, 1.11;il. leaves no probability of errorsl.

Instead of just sending the shares {si}, the dealer of the secret selects n random polynomials fo@), . . . , fn-l(x), with

(1) 
$$s_i = f_i(0)$$
 for  $i = 0, ..., n-1$ , and

(2) 
$$\sum_{i=0}^{n-1} \omega^{r \cdot i} f_i(x) = 0$$
 for  $r = 1, \dots, 2t$ 

In other words, the dealer selects a random polynomial f(z, y), of degree t in both variables z and y, with the only restriction that f(O,O) = s (his secret). Then he sends the polynomials fi(z) = f(zlwi) and gi(v) = f(W', W) t.0 playtar Pi, for i = 0,. 1 1) - 1. TtlC ITid stiarcl is jllst. Si = /i(O), l>\lL for I.tlcb l)urlww Of its verification, Lh (l(:ah'r idSO scntls l.lIC I~oiyllc~nliids j;(P) and !/i(u). At. (,liis poitil, C'ZlC11 plirycxr f{ Sc>IldS SiJ = fi(WJ) = f(Wj,W') = gj(Wi) I80 C'ilCIl phycr Pj.

No1.t. L11ilL if t.h tltbnlcr is corrccL, I.~IVII WIICYI ;z good Inlayer I> is looking at Lllo sc'qlrc~llcc' SSj = (SO,j 9 Slj 7 . . ..S.- 1 ,j), then all these points should be on his polynomial gj(2/). Tl iereforc Pj cit.11 coniI>are the incoming values with his own computation and find out which values are wrong. Furthermore it is

<sup>&#</sup>x27;Our original protocol was simpliied by Paul Feldman who independently observed that the verification procedure can be accomplished in a constant number of communication rounds.

ctea.r that in this case no good player will have to correct any vatlIe coining from other good plnycrs.

On the ot,her hand we have

Lenknkn: If110 COrreCt phyfY hS t0 COrrCCt adue given by a correct player, then thcrc is a polynomial of dcgrc%c\* 1. 1.11;11. pass(xs through l,lic~ int~crpoliitioti points of all the corrf~c't players.

## Proof: Simple algebra. Omit.ted.

To make sure t,hat the condition of this lemma is satisfied, each player F'j broadcasts a request to make the coordinates (i,j) he had to correct public. If Pj detects more than t wrong incoming values, or had to correct his own value, the dealer is clearly faulty. In such a case Pj broadcasts a request to make both fj( z ) and gj(y) public. At this point the dealer broadcasts the (supposedly true) values si,j at all these points, and the polynomials that were to be made public. Note that making fj and gj public makes all t.he Sk,j and sj,k public for 0 5 k < n, for that. part.iculat j.

Now if some player Pi observes that some new public si,j tout radicts the polynomials he is holding, or finds 001. I.hr t,lic public informal.ion already contradicts ibsclf, ho brondcasts a rcqncsl. t,o lnnke all his in-Ibrmat.ion public. llerc once more, 1.11~ dnalcr mnkes public all t.llc, rcqucst,ed inforniabion, Fiiially, each I: chc~ks aI1 t.hc public and private inforlnntion he received front the dealer.. If Pi finds any inconsistencies he br0adcast.s a complaint by asking all his private information to be made public.

If at this point t -+ 1 or more players have asked to make their information public, the dealer is clearly faulty and all the players pick the default zero polynomial as the dealer's polynomial. Likewise, if the dealer did not answer all the broadcasted requests he is declared faulty. On the other hand, if t or less players have complaint, then there are at least t + 1 good players who are satisfied. These uniquely define the polynomial f(;c, y) and they conform with all the information that was made public. In this case 1.11~ complainilig players take the public information n.s I.hc\*ir share>.

Not.cb 1.11~1. if (.lrc <lc>alcr has disl.ribut.c~d a correct W- (\*rv(. f.llc,rl 110 (~iwc~ of il~fi~rl~iiJf.ic~ll cjf ally good pIi1yc.r w;is rc975tl(\*d tlrlring 1.lie vc~rification process. If Iiow- ('v(ar (.llc? Cif'illCr was bad, WV do not have to protect the\* privacy of his informat.ion, and the vcrificat,ion procedure ensllrcs us that all the good players values lie on some polynomial of degree 2.

# Some more tools

Before going into the computation stage, we need two mor(h tools

- (1) Generating (and verifying) a random polynonlial of degree 2t, with a zero free coefficient.
- (II) Allowing a dcalcr to clistributc three sccrcts, fr, b, and c, and verifying that c = u . b.

Roth of these are not needed when n 2 4t + 1, but are required to handle the n = 3t + 1 case.

(I) Generating polynomials of degree 2t Let each player Pi distribute t random (including the free coefficient) polynomials gi,k(CC), /z = 1,. . . ,t, of degree t . Define fi (z) by

$$f_{i}(x) = \sum_{k=1}^{t} x^{k} \cdot g_{i,k}$$

and let the players evaluate from their points on the gi,k-s their corresponding point on fi(Z).

After we have verified that indeed deggi,k 5 t, it is clear that degfi(z) 5 2t, and fi(O) = 0. (It is also clear that the vector of coefficients of the monomials ofzi, i= 1,. . , ,t, in /i(z) are uniformly distributed and are completely indcpentlf~nt from the information held by any set of at most 1 players that does not incltlde Pi .)

Finally, as our random polynomial we take

$$f(x) = \sum_{i=0}^{n-1} f_i(x).$$

#### (II) Verifying that c = a. b

Let the player P distribute a and b using the polynomials A(z) and B(r) respectively. We want P to also distribute a random polynomial encoding c = a A b, in such a way that the players can all verify that indeed c = a. b. Let

$$D(x) = A(x) \cdot B(x) = c + c_1 x + \dots + c_{2t} x^{2t}$$

$$D_{t}(x) = r_{t,0} + r_{t,1}x + \dots + r_{t,t-1}x^{t-1} + c_{2t}x^{t}$$

$$D_{t-1}(x) = r_{t-1,0} + \dots + r_{t-1,t-1}x^{t-1} + [c_{2t-1} - r_{t,t-1}]x^{t}$$

$$D_1(x) = r_{1,0} + ... + r_{1,t-1}x^{t-1} + + [c_t - r_{t,1} - r_{t-1,2} - ... - r_{2,t-1}]x$$

where the ri,j are random elements from E. P selects the Di(Z) and distributes their shares to all the players. After verifying that A(X), B(Z) and all the D;(x) are of degree t, define

$$C(x) = D(x) - \sum_{i=1}^{t} x^{i} \cdot D_{i}(x).$$

and verify that C(x) is also of degree 1. From the construction of C(z) it is clear that C(z) is a random polynomial of degree t with the only restriction that C(0) = a. b.

## Proof of Theorem 3

We separate again the compubation to its Input, Computation and Final stages. At the input stage, we let each player enter his inputs to the computation using our secret sharing scheme, while verifying that each secret shared is indeed some polynomial of degree t. The secret verification assures that the inputs of any Byzantine player is well defined, but does not ensure that it is in the domain of our function. For example, in a O-l vote, we must verify that the input is 0 or 1. We defer this type of verification to the computation stage.

The final stage is exactly the satme as in the proof of Theorem 1. When we have simulated the circuit, and the players are holding the pieces of a properly shared secret, encoding the final output, they send all the pieces to one or all the players. As at most t pieces are wrong, each player can use the error correcting procedure and recover the result.

# The computation stage - Byzantine case

Let u and b be properly encoded by f(z) and g(z) respectively, where by "properly encoded" we mean that all the pieces of the good players are on some polynomial of degree 1. Since J(X) and g(z) are properly encoded the polynomials j(a:)+g(z), and c./(z), properly encode a+b, and c.a, for any constant c c E. The same argument of Theorem 1 implies that we can do the computation of any linear operation with no communication at all.

Bere again, the multiplication step is more involved. To repeat the procedure of theorem I, using the degree reduction step, via the Matrix Multiplication Lemma, we must make sure the all the players use, as input to this proce+re, their correct point on the product polynomial h(z) = f(z)g(z). To guarantee that this indeed happens, we use the Error Correcting Codes again.

Let Uj = f(Ui), bi = g(W') and Ci = h(U') = ai . bi be the points of Pi on these polynomials. We ask each

Pi to pick a random polynomial of dcgr,re 1, ,~li(~), such that ni = Ai( and use this polynoriiial 1.0 distribute aj as a secret, to all the players. Similarly, Pi distrihntcs 6; using Bi(z). We atso ~:k /'i t#o tlistribute ci using the polynomial Ci(Z), wl~ilr verifying that Ai( Bi(l), C',(X) are all of degree 2, and that Ci(O) = Ai(O)Bi(O).

We want to verify that the free coefficients of the polynomials Ci(z) are all points on the product polynomial h(z). It is enough to verify that all the free coefficient of the Ai( and Bi(+) are on f(z) and g(z) respectively. We do this as follows.

The free coefficient of the Ai( are a code word with at most t errors. By our assumption, all the Ai are properly distributed. We can therefore use them to compute any linear functional. In particular, using the same Ai(s we can compute the polynomials

$$S_r(x) = \sum_{i=0}^{n-1} \omega^{r \cdot i} A_i(x)$$

for f= l,... ,2t. At this point all the players reveal their points on the polynomials S?(Z), enabling all the players to recover the value of sp := S,.(O), for r = 1,...,2t.

Note that if all the Ai(0) are correct (i.e. on a polynomial of degree 9 then s, = Cl for all r. Thus the computed value of the s, are just a function of the errors introduced by the Byzantine players. In particular, this implies that the value of the s, does not reveal any information that is held in the hands of the good players!

Since at most t of the Ai(0) can be wrong, the value of the s+, the so called Syndrome Vector, is the only information needed by the error correction procedure to detect which coordinates .4i(z) encode a wrong Ai( and give the correct value. Therefore, if some s, # 0, all the players compute the wrong coordinates, the correct value of f(wi), and use the constant polynomial wit,11 this value, instead of Ai(

In asimilar way we can check and correct the B;(Z). We can, therefore, also check (and correct) the Ci(z), so we are sure that all the inputs to the linear computation we have to do in the degree reduc6ion procedure are correct.

Note that much of this is not needed when 71 > 4t + 1, because then we can still correct up to t errors on polynomials of degree 2t. In this case we can do the error correction on the points of h(r) directly.

As in the proof of Theorem 1, we have,

Theorem 3: For every probabilistic function and every t < n/3 there exists a protocol that is both t resilient and t-pn'vate.

For completeness we state,

Theorem 4: There are functions for which there is no n/3 - resilient protocol.

Proof. Follows immediately from the lower bound for Byzantine Agreement in this model. We note that even if we allow broadcast as a primitive operation, theorem 4 remains true. This is because we can exhibit functions for three players that cannot be computed tesilient,ly, when one player is bad. This generalizc%s ir~~n~ctli;rt.cly to n/3.

Remark: All the remarks following the statement of theorem 1 apply also to theorem 3.

# References

- [BL] M. Ben-Or and N. Linial, Collective coin flipping, FOCS86.
- [CCD] D. Chaum, C. Crepeau and I. Damgard, Multiparty unconditionally secure protocols, These proceedings.
- [DH] W. Dime and M. E. Helman, New directions in cryptography, IEEE Trans. Inform. Theory, Vol.IT-22,pp.644-654, 1976.
- IDS] D. Dolev and R. Strong, Polynomial algorithms for multiple processor agreement. STOC82.
- [Fhsl] I'. Fcldn~an and S. Micali, Opt.imaI algorit,hms for Byzantine agreement, These proceedings.
- [GhlWl] 0. Gold riech, S. Micali and A. Wigderson, Proofs that yield nothing but the validity of the assertion, and a methodology of cryptographic protocol design, FOCS86, pp. 174-187.
- [GMW2] 0. G o Id riech, S. Micah and A. Wigderson, How to play any mental game, STOC87, pp. 218-229.
- [GMR] S. G o Id wasser, S. Micali and C. Rackoff, The knowledge complexity of interactive proof systems, STOC85, pp. 291-304.
- [PSL] M. Pease, R. Shostak and L. Lamport, Reaching agreement in the presence of faults, JACM Vol. 27, pp. 228-234, (1980).
- [PW] W. W. Peterson and E. J. Weldon, Error correcting codes, Second Ed., hll'l' Press, (1972).
- [Sh] A. Shamir, How to share a secret, CACM, 22, pp. 612-613, (1979).

- [Yl] A. C. Yao, How to generate and exchange secrets, STOC86.
- [Y2] A. C. Yaq On the succession problem for Byzantine Generals, manuscript, (1983).

# Appendix

## Formal Not at ion

Let F' I)(: a field. Let CJ = P'" denote the standard 7tdimensional vector space over 1" and M,,(F) the ring of 72 x n matrices over F.

Let R be a random variable with distribution D over F. Then Rk (R\*) denotes k (finitely many) independent draws from D.

Comment: Unless otherwise specified, F will be finite, and D the uniform distribution over F.

### The Basic Model:

Fix n > 0 and a field F. Intuitively, an (n, F) network is a complete synchronous network of n probabilistic machines (players) PO, PI, . . . . P,-l. At every round, each player can send one message (element of F) to each other player, receive a message from each other player, and perform arbitrary computation.

If we assume for convenience that players send messages to themselves too, a round of communication is neatly described by a matrix A4 E M,(F), where each Pi sent the ith row of M, and receives the ith column of M. (This formalizes the security of private channels).

Formally, a T round (n, F) - network is a set of players {PO, PI, . . . . P,,-1). Each Pi is a tuple

$$P_i = \langle Q_i, q_i^{(0)}, R_i, \delta_i \rangle,$$

where Qi is a set of states, qj (O) the initial state, Ri is a random variable over F (distributed like R) and

$$\delta_i: [T] \times Q_i \times F^n \times R_i^* \to Q_i \times F^n$$

is a transition function that given a round number, state, previous round input and private coin tosses computes the next state and this round's output.

A protocol is simply 6 =< 60,61,. . . , a,-, >, the transition functions prescribing to each player what to do in each round.

A run M of a protocol 6 is a sequence (Ml, M2, . . , MT), Mj E M,(F) of matrices describing the communication in rounds j = 1,2,. . . ,T. Note that M is a random variable, depending on {qi')}, the initial states, and {R?}, (= R'), the random draws from D.

A (probabilistic) function is. a function f,

$$f: F^n \times R^m \to F^n$$

Intuitively, a protocol cctmpute:: a function UT if for all v E F", if i'i is given Vi E F be:bre round 1, then after round '1' it knows ui, such that 7.4 =< U(),Ul,.'., u,- 1 > is distributed exactly like f(v x R"). For convenience we denote a vector < ~0, ~1, . . . . ~"-1 > by < oi >. Also, let qIj' derote the state of Pi after round i.

To formally define what it means for a protocol to compute a function, we assume fixed input .Pnd output functions, Ii, Oi: Qi .+ F for each player Pi. Now 6 computes f, if for every choice of < qi") >, we have < Oi(qy') >= f(li(qiO') x R"') (as ranc.om variables).

#### Some Intuition

The bad players in our model can completely coordinate their actions. Hence, for a bad set (coalition) c c [n] = {0,1,2 )"., n - l}, the transition functions 6i, i E C are replaced by arbitrary functions 6: that compute the next state and messages of Pi from the joint information of the current states, previously received messages and random choices 01' all (Pi), i E C. We denote any protocol in which a set C is bad (in this sense) by 6~.

We d&tinguish two types of bad behavior. The benign (gossip) kind, in which bad players send messages according to the original protocol 6, but tr:r to learn as much as they can from it by joining their forces. The malign (Byzantine) kind puts no restrictions on the bad players, i.e. the 6: can really be arbitrary.

To formalize the benign kind of bad behavior we need the foliowing definition:

Two protocols 6 and 6' look alike if their runs have the same distribution, i.e. M = M' as random variables, for every fixed initial state c: qi") > of all players.

A bad coalition C is called gossip if the protocol 6~ looks like 6, otherwise it is catted ByranZine.

In the case of gossip, we don't have to worry about the correctness of cotnputing f - this follows from the definition "took alike". Here all we shalt have to prevent, is leakage of information. In case of Byzantine faults, we will have to guarantee also the correct:ress of the computation. We proceed now to define the important notions of Privacy and Correctness.

#### Privacy (preliminary):

Intuitively, a coalition C did not learn anything from a protocol for computing f, if whatever it can compute after the protocol (from its final states), it could compute only from its inputs (initial states) and its components of the function values.

Let QC = ni,, Qi and A be an arbitrary set. Also, ifu=<ue,ur ,..., u,- 1 >, UC denotes the sub-vector of u that contains ui, i E C. Formally, a set. C is ignorant in a protocol 6 (for computing I)\* if for every set of initial states < Jo) > every prot.ocot 6 that looks like d ,nd every fifnct,idn g': Qc c + .4 ttierc exists a funclion d: Qc x Ftct -+ A rrnt,isfying

$$g'(q_C^{(T)}) = g(q_C^{(0)}, f, (\langle l_i(q_i^{(0)}) \rangle)_C)$$
 (\*)

A protocol 6 (for computing f) is t-private if every coalition C with ICI 5 t is ignorant.

#### Correctness:

This issue is problematic, since some of the bad players can obliterate their initial inputs, and the function value is not well defined (a simple example is Byzantine agreement). To ignore bad inputs for every set B C [n], we need a (sub)function off that depends on the input coordinates of only [n] \ B. (a special case is assigning default values to input coordinates in B).

So now by f we mean a family of funct,ions {f~: F n\B x RM - F"}, I3 E [n.], with f+ being the original funct8ion f. Typically, (as in 13yza.ut,iuc, agreement) this exponemiat size fanrity is very succinctly described.

So now, a romput,ation is correct, if all good ptaycrs compute a function fB, where L3 is a subset of the bad players.

More formally, a coalition C is harmless if for every set of initial states < \*i(O) > and every prot.ocol 6~,

$$\{\langle O_i(q_i^{(T)}) \rangle\}_{[n]\setminus C} = f_B(\{\langle I_i(q_i^{(0)}) \rangle\}_{[n]\setminus B})_{[n]\setminus C}$$

for some B C C.

A protocol is l-resilient if ICI 5 1 is harmless. every coalition C with

#### Privacy Revisited:

For the case of Byzantine that 6~ looks like 5 is invalid. faults, the assumption For any harmless coalition C we can remove this assumption from the definition of ignorance, and replace f in (\*) above, by fB, the funct.ion that will actually be computed by the good players.

Now the notion of a protocol ttrat is both t-resilient and l-private is well defined.