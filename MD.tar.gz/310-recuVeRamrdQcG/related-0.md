U.C. Berkeley Handout N11 CS294: PCP and Hardness of Approximation March 1, 2006 Professor Luca Trevisan Scribe: Madhur Tulsiani

## Notes for Lecture 11

In the previous lecture, we claimed it is possible to "combine" a d-regular graph on D vertices and a D-regular graph on n vertices to obtain a d 2 -regular graph on nD vertices which is a good expander if the two starting graphs are. Let the two starting graphs be denoted by H and G respectively. Then, the resulting graph, called the zig-zag product of the two graphs is denoted by G <sup>Z</sup> H.

Using λ(G) to denote the eigenvalue with the second-largest absolute value for a graph G, we claimed that if λ(H) ≤ βd and λ(G) ≤ αD, then λ(G <sup>Z</sup> H) ≤ (α + β + β 2 )d 2 . In this lecture we shall describe the construction for the zig-zag product and prove this claim.

## 1 Replacement product of two graphs

We first describe a simpler product for a "small" d-regular graph on D vertices (denoted by H) and a "large" D-regular graph on n vertices (denoted by G). Assume that for each vertex of G, there is some ordering on its D neighbors. Then we construct the replacement product (Figure 1) G r H as follows:

- Replace each vertex of G with a copy of H (henceforth called a cloud). For i ∈ V (G), j ∈ V (H), let vij denote the j th vertex in the i th cloud.
- Let (i1, i2) ∈ E(G) be such that i<sup>2</sup> is the j th <sup>1</sup> neighbor of i<sup>1</sup> and i<sup>1</sup> is the j th <sup>2</sup> neighbor of i2. Then (vi1j<sup>1</sup> , vi2j<sup>2</sup> ) ∈ E(G <sup>r</sup> H). Also, if (j1, j2) ∈ E(H), then ∀i ∈ V (G) (vij<sup>1</sup> , vij<sup>2</sup> ) ∈ E(G r H).

Note that the replacement product constructed as above has nD vertices and is (d + 1)-regular.

## 2 Zig-zag product of two graphs

Given two graphs G and H as above, the zig-zag product G <sup>Z</sup> H is constructed as follows (Figure 2):

- The vertex set V (G <sup>Z</sup> H) is the same as in the case of the replacement product.
- (vi1j<sup>1</sup> , vi2j<sup>2</sup> ) ∈ E(G <sup>Z</sup> H) if there exist j<sup>3</sup> and j<sup>4</sup> such that (vi1j<sup>1</sup> , vi1j<sup>3</sup> ), (vi1j<sup>3</sup> , vi2j<sup>4</sup> ) and (vi2j<sup>4</sup> , vi2j<sup>2</sup> ) are in E(G <sup>r</sup> H) i.e. vi2j<sup>2</sup> can be reached from vi1j<sup>1</sup> by taking a step in the first cloud, then a step between the clouds and then a step in the second cloud (hence the name!).

It is easy to see that the zig-zag product is a d 2 -regular graph on nD vertices. Let M ∈ R ([n]×[D])×([n]×[D]) be the adjacency matrix of G <sup>Z</sup> H. Using the fact that each edge in G r H is made up of three steps in G r H, we can write M as BAB, where

$$B[v_{i_1j_1}, v_{i_2j_2}] = \begin{cases} 0 & \text{if } i_1 \neq i_2 \\ \#edges \ between \ j_1 \ and \ j_2 \ in \ H & \text{if } i_1 = i_2 \end{cases}$$

![](_page_1_Figure_0.jpeg)

Figure 1: The replacement product of G and H (not all edges shown)

$$A[v_{i_1j_1}, v_{i_2j_2}] = \begin{cases} 1 & if \ i_2 \ is \ the \ j_1^{th} \ neighbor \ of \ i_1 \ and \ i_1 \ is \ the \ j_2^{th} \ neighbor \ of \ i_2 \\ 0 & otherwise \end{cases}$$

Here B is the adjacency matrix of the replacement product after deleting all the edges between clouds and A is the adjacency matrix containing *only* the edges between clouds. Note that A is the adjacency matrix for a matching and is hence a permutation matrix.

## 3 Eigenvalues of the zig-zag graph

Let 1 denote the vector which is 1 in all coordinates and let  $\lambda(G)$  denote the eigenvalue with the second-largest absolute value for the graph G with adjacency matrix M. We prove the following theorem:

**Theorem 1** If G is a D-regular graph on n vertices and H is a d-regular graph on D vertices such that  $\lambda(G) \leq \alpha D$  and  $\lambda(H) \leq \beta d$ , then  $\lambda(G \otimes H) \leq (\alpha + \beta + \beta^2)d^2$ 

We know that

$$\lambda(G) = \max_{x \perp \mathbf{1}, ||x|| = 1} \left| x M x^T \right|$$

![](_page_2_Picture_0.jpeg)

Figure 2: The zig-zag product of G and H and the underlying replacement product (not all edges shown)

Thus, it suffices to obtain a bound on the above expression for  $G \otimes H$  when G and H are good expanders. To provide an intuition for the proof consider two extreme cases for a cut in  $G \otimes H$ . If the cut mostly includes or excludes entire clouds, then it can be viewed as a cut in G the number of edges crossing it are almost the same as for the corresponding cut in G. If the cut splits almost all clouds in two parts, then one may think of it as G cuts in G copies of G. In both these cases then the number of edges crossing the cut will be "large" due the good expansion of G and G respectively. The following proof essentially breaks any vector G into the algebraic analogs of these two extremes.

PROOF: Given any vector  $x \in \mathbb{R}^{nD}$ ,  $x \perp \mathbf{1}$ , one can write it as  $x = x_{\parallel} + x_{\perp}$  where  $x_{\parallel}$  is constant on each cloud and  $x_{\perp}$ , restricted to any cloud is perpendicular to  $\mathbf{1}^{D}$  (the all 1's vector in D dimensions). In particular

$$x_{\parallel}(v_{ij}) = \frac{1}{D} \sum_{k} x(v_{ik})$$
  
 $x_{\perp}(v_{ij}) = x(v_{ij}) - x_{\parallel}(v_{ij})$ 

We have

$$\begin{aligned} \left| xMx^T \right| &= \left| xBABx^T \right| &= \left| (x_{\parallel} + x_{\perp})BAB(x_{\parallel} + x_{\perp}) \right| \\ &\leq \left| x_{\parallel}BABx_{\parallel}^T \right| + 2\left| x_{\parallel}BABx_{\perp}^T \right| + \left| x_{\perp}BABx_{\perp}^T \right| \end{aligned}$$

We now analyze each of these terms separately.

$$|x_{\perp}BABx_{\perp}^{T}| = |x_{\perp}BA(x_{\perp}B)^{T}|$$

$$\leq ||x_{\perp}BA|| \cdot ||x_{\perp}B|| \quad (by \ Cauchy - Schwarz)$$

$$= ||x_{\perp}B|| \cdot ||x_{\perp}B|| \quad (since \ A \ is \ a \ permutation \ matrix)$$

$$\leq \beta d \, ||x_{\perp}|| \cdot \beta d \, ||x_{\perp}||$$

$$\Rightarrow |x_{\perp}BABx_{\perp}^{T}| \leq \beta^{2} d^{2} \, ||x_{\perp}||^{2}$$

$$(1)$$

In the above  $||x_{\perp}B|| \leq \beta d ||x||$  follows from the fact that the restriction of  $x_{\perp}$  to any cloud is perpendicular to  $\mathbf{1}^D$  and that B is a block-diagonal matrix whose action on the restriction is the same as that of the adjacency matrix of H. For the mixed term,

$$\begin{vmatrix} x_{\perp}BABx_{\parallel}^{T} \end{vmatrix} = \begin{vmatrix} x_{\perp}BA(x_{\parallel}B)^{T} \end{vmatrix}$$

$$= 2d \begin{vmatrix} x_{\perp}BAx_{\parallel}^{T} \end{vmatrix} \quad (\because x_{\parallel} \text{ is parallel to } \mathbf{1}^{D} \text{ in each cloud})$$

$$\leq ||x_{\perp}B|| \cdot ||x_{\parallel}||$$

$$\leq 2d \cdot \beta d ||x_{\perp}|| \cdot ||x_{\perp}||$$

$$\leq d^{2}\beta(||x_{\perp}||^{2} + ||x_{\perp}||^{2}) \quad (by \ Cauchy - Schwarz)$$

$$\Rightarrow \begin{vmatrix} x_{\perp}BABx_{\parallel}^{T} \end{vmatrix} \leq \beta d^{2}(||x_{\parallel}||^{2} + ||x_{\perp}||^{2}) = \beta d^{2} ||x||^{2}$$

$$(2)$$

Let  $y \in \mathbb{R}^n$  be the vector defined as  $y(i) = \frac{1}{D} \sum_j x(v_{ij})$  and let C be the adjacency matrix for G. Then

$$\begin{vmatrix} x_{\parallel}BABx_{\parallel}^{T} | &= d^{2} |x_{\parallel}Ax_{\parallel}^{T} | \\
&= d^{2} | \sum_{i_{1},j_{1},i_{2},j_{2}} x_{\parallel}(v_{i_{1}j_{1}})A(v_{i_{1}j_{1}},v_{i_{2}j_{2}})x_{\parallel}(v_{i_{1}j_{1}}) | \\
&= d^{2} | \sum_{i_{1},i_{2}} y(i_{1})y(i_{2})C(i_{1},i_{2}) | \\
&= d^{2} |yCy^{T}| \\
&\leq d^{2} ||yC|| \cdot ||y|| \quad (by \ Cauchy - Schwarz) \\
&\leq d^{2}\alpha D ||y||^{2} = d^{2}\alpha ||x_{\parallel}||^{2} \\
\Rightarrow |x_{\parallel}BABx_{\parallel}^{T}| \leq d^{2}\alpha ||x_{\parallel}||^{2}$$
(3)

Note that  $||yC|| \le \alpha D ||y||$  follows from the bound on  $\lambda(G)$  and the fact that  $y \cdot \mathbf{1} = \sum_i y(i) = \frac{1}{D} \sum_i \sum_j x(v_{ij}) = 0$ . Using equations (1), (2) and (3) gives

$$\begin{aligned} & \left| xBABx^T \right| & \leq & \alpha d^2 \left| \left| x_{\parallel} \right| \right|^2 + \beta^2 d^2 \left| \left| x_{\perp} \right| \right| + \beta d^2 \left| \left| x \right| \right|^2 \\ \Rightarrow & \left| xBABx^T \right| & \leq & d^2 (\alpha + \beta + \beta^2) \left| \left| x \right| \right|^2 \end{aligned}$$

Using the previous characterization of eigenvalues, we have

$$\lambda(G \otimes H) = \max_{x \perp \mathbf{1}, ||x|| = 1} |xBABx^T| \le d^2(\alpha + \beta + \beta^2)$$