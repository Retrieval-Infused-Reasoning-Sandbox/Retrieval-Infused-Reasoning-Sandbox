The Annals of Statistics 2015, Vol. 43, No. 6, 2766–2794 DOI: 10.1214/15-AOS1365 © Institute of Mathematical Statistics, 2015

# ESTIMATING THE SMOOTHNESS OF A GAUSSIAN RANDOM FIELD FROM IRREGULARLY SPACED DATA VIA HIGHER-ORDER QUADRATIC VARIATIONS

### By Wei-Liem Loh

National University of Singapore

Dedicated to Charles M. Stein on his ninety-fifth birthday

This article introduces a method for estimating the smoothness of a stationary, isotropic Gaussian random field from irregularly spaced data. This involves novel constructions of higher-order quadratic variations and the establishment of the corresponding fixed-domain asymptotic theory. In particular, we consider:

- (i) higher-order quadratic variations using nonequispaced line transect data.
- (ii) second-order quadratic variations from a sample of Gaussian random field observations taken along a smooth curve in  $\mathbb{R}^2$ ,
- (iii) second-order quadratic variations based on deformed lattice data on  $\mathbb{R}^2$ .

Smoothness estimators are proposed that are strongly consistent under mild assumptions. Simulations indicate that these estimators perform well for moderate sample sizes.

1. Introduction. In spatial statistics, it is common practice to model the response as a realization of a Gaussian random field; cf. [7, 10, 25] and the references cited therein. Let X be a stationary, isotropic Gaussian random field on  $\mathbb{R}^d$  with mean  $\mu = E\{X(\mathbf{x})\}$  and covariance function

<span id="page-0-0"></span>(1) 
$$K(\mathbf{x}, \mathbf{y}) = \operatorname{Cov}\{X(\mathbf{x}), X(\mathbf{y})\}$$
$$= \sum_{j=0}^{\lfloor \nu \rfloor} \beta_j \|\mathbf{x} - \mathbf{y}\|^{2j} + \beta_{\nu}^* G_{\nu}(\|\mathbf{x} - \mathbf{y}\|) + r(\mathbf{x}, \mathbf{y}) \qquad \forall \mathbf{x}, \mathbf{y} \in \mathbb{R}^d,$$

where:

Received March 2015; revised July 2015.

AMS 2000 subject classifications. Primary 62M30; secondary 62M40.

Key words and phrases. Gaussian random field, higher-order quadratic variation, irregularly spaced data, Matérn covariance, smoothness estimation.

This is an electronic reprint of the original article published by the Institute of Mathematical Statistics in *The Annals of Statistics*, 2015, Vol. 43, No. 6, 2766–2794. This reprint differs from the original in pagination and typographic detail.

(i)  $\nu > 0$ ,  $\beta_{\nu}^* \neq 0$ ,  $\beta_0, \dots, \beta_{\lfloor \nu \rfloor}$  are constants and  $\lfloor \cdot \rfloor$  denotes the greatest integer function,

(ii)  $r(\mathbf{x}, \mathbf{y}) = O(\|\mathbf{x} - \mathbf{y}\|^{2\nu + \tau})$  for some constant  $\tau > 0$  as  $\|\mathbf{x} - \mathbf{y}\| \to 0$ , and  $G_{\nu} : [0, \infty) \to \mathbb{R}$  such that  $G_{\nu}(0) = 0$  and for all s > 0,

<span id="page-1-0"></span>(2) 
$$G_{\nu}(s) = \begin{cases} s^{2\nu}, & \forall \nu \notin \mathbb{Z}, \\ s^{2\nu} \log(s), & \forall \nu \in \mathbb{Z}. \end{cases}$$

Here,  $\|\cdot\|$  denotes the Euclidean norm in  $\mathbb{R}^d$ . This class of covariance functions is very general and it includes, for example, the Matérn model (see Section 2.1) and the exponential family  $\exp(-c\|\mathbf{x}-\mathbf{y}\|^{2\nu})$  for  $\nu \in (0,1)$ . Anderes and Stein [3], page 721, observe that  $\nu$  is a smoothness parameter in that X is j times mean square differentiable if and only if  $j < \nu$ .  $\beta_{\nu}G_{\nu}$  is known as the principal irregular term of the covariance function K; cf. [24, 25].

The aim of this article is to estimate  $\nu$  using n observations from a single realization of X within a compact domain  $\Delta \subset \mathbb{R}^d$ ,  $d \in \{1,2\}$ . The estimation of  $\nu$  has been addressed in the literature under a number of different conditions by various authors. In the case of scattered (possibly nonlattice) data, Anderes and Stein [3] ignore the unknown function r in (1) and use an approximate likelihood method to estimate  $\nu$ . However, the accuracy of the estimate is not addressed there. Im et al. [16] propose a semiparametric method of estimating the spectral density (and hence  $\nu$ ) with irregular observations. These latter two methods have nonnegligible model biases and also appear to be analytically intractable under fixed-domain asymptotics. The latter asymptotics imply that as  $n \to \infty$ , the n sites get to be increasingly dense in  $\Delta$ . Also in the simulations, Im et al. [16] consider 200 independent realizations of a Gaussian random field, whereas this article is concerned with estimating  $\nu$  based on observations from one realization of the underlying Gaussian random field.

In the case of equispaced data on a line transect, Hall and Wood [13] consider a box-counting estimator while Constantine and Hall [9], Kent and Wood [19] study estimators of  $\nu$  based on process increments. References [9, 13, 19] assume that  $\nu \in (0,1)$ . Another example of equally spaced data on a line transect is [17] where higher-order quadratic variations are used to construct a consistent estimate for  $\nu$  assuming that  $\nu \in (D, D+1)$  for some known integer D.

This article proposes a method for estimating  $\nu$  using irregularly spaced data from a possibly differentiable Gaussian random field. The methodology involves novel constructions of higher-order quadratic variations and the establishment of the corresponding fixed-domain asymptotic theory. The history of quadratic variations started with [22]. Since then, this field has grown dramatically; some examples being [1, 5, 8, 12, 20]. Most higher-order

quadratic variations in the literature have been based on observations on a regular grid in  $\mathbb{R}^d$ ; cf. [6, 17] and references cited therein. An exception is [4] that deals with second-order quadratic variations using irregularly spaced Gaussian process observations on a line transect in  $\mathbb{R}$ . However, from definition (3) of [4], we observe that Begyn's second-order quadratic variations are different in that they depend explicitly on the smoothness of the process, and hence cannot be evaluated if  $\nu$  is unknown.

The remainder of this article is organised as follows. Section 2 considers the case d=1. Let  $\varphi:\mathbb{R}\to\mathbb{R}$  be a twice continuously differentiable function satisfying  $\varphi(0) = 0$ ,  $\varphi(1) = 1$  and  $\min_{0 \le s \le 1} \varphi^{(1)}(s) > 0$  where  $\varphi^{(1)}(s) = 0$  $d\varphi(s)/ds$ . Define  $t_i = \varphi((i-1)/(n-1)), i=1,\ldots,n$ . For  $\theta \in \{1,2\}$  and  $\ell \in \mathbb{Z}^+$ , novel  $\ell$ th order quadratic variations  $V_{\theta,\ell}$  based on the observations  $X(t_i), 1 \leq i \leq n$ , are constructed. Here, X is a stationary, isotropic Gaussian random field having covariance function K as in (1) with d=1. Under fixed-domain asymptotics, Theorem 1 proves the strong convergence of  $V_{\theta,\ell}/E(V_{\theta,\ell})$  under mild conditions. It is of interest to note that the asymptotic behavior of  $V_{\theta,\ell}$  is critically dependent on whether the smoothness parameter  $\nu$  is greater or less than the order  $\ell$  of the quadratic variation. In Section 2.1, estimators  $\hat{\nu}_{a,\ell}$ ,  $\hat{\nu}_{a,0}$  and  $\hat{\nu}_a$  for  $\nu$  are proposed. For  $\nu \leq M < \ell \leq 10$ where M is a known constant, Theorem 2 proves that  $\hat{\nu}_{a,\ell}$  is strongly consistent under the assumptions of Theorem 1(a).  $\hat{\nu}_a$  is a refinement of  $\hat{\nu}_{a,0}$ which in turn can be thought of as a refinement of  $\hat{\nu}_{a,\ell}$ . Table 1 summarises the results of a simulation experiment to gauge the accuracy of  $\hat{\nu}_{a,0}$  and  $\hat{\nu}_a$ .

For  $\theta, \ell \in \{1, 2\}$ , Section 3 describes the construction of  $\ell$ th-order quadratic variations  $\tilde{V}_{\theta,\ell}$  from irregularly spaced data taken along a fixed smooth curve  $\gamma$  in  $\mathbb{R}^2$ . Assuming  $\nu \in (0,\ell)$ , Theorem 3 proves the strong convergence of  $\tilde{V}_{\theta,\ell}/E(\tilde{V}_{\theta,\ell})$  under weak conditions. In Section 3.1, the estimators  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$  for  $\nu \in (0,2)$  are proposed. Theorem 4 shows that  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$  are strongly consistent estimators for  $\nu \in (0,2)$  under the assumptions of Theorem 3. Table 2 reports the accuracy of  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$  in a simulation experiment where the data are taken along an arc of the unit circle.

In Section 4, the Gaussian random field on  $\mathbb{R}^2$  is observed at sites  $\mathbf{x}^{i_1,i_2} = \tilde{\varphi}(i_1/n,i_2/n), \ 1 \leq i_1,i_2 \leq n$ , where  $\tilde{\varphi}$  is a smooth diffeomorphism. Second-order quadratic variations  $\bar{V}_{\theta,\ell}, \ \theta,\ell \in \{1,2\}$ , based on the observations  $X(\mathbf{x}^{i_1,i_2}), \ 1 \leq i_1,i_2 \leq n$ , are constructed where X is a stationary, isotropic Gaussian random field having covariance function K as in (1) with d=2. Theorem 5 establishes conditions where  $\bar{V}_{\theta,\ell}/E(\bar{V}_{\theta,\ell}) \to 1$  as  $n \to \infty$  almost surely. Section 4.1 proposes estimators  $\hat{\nu}_{c,1}$  and  $\hat{\nu}_{c,2}$  for  $\nu \in (0,2)$ . Theorem 6 shows that these estimators are strongly consistent under the assumptions of Theorem 5. Finally, Table 3 presents the results of a simulation study on the accuracy of  $\hat{\nu}_{c,1}$  and  $\hat{\nu}_{c,2}$ . Chan and Wood [6] consider smoothness estimation of a nondifferentiable Gaussian random field on  $\mathbb{R}^2$  observed on a regular

grid. However, the estimators proposed in [6] do not work for irregularly spaced observations of a smooth Gaussian random field with  $\nu \ge 1$ .

The Appendix and the supplemental article [23] contain proofs and related technical results needed in this article. If X is a locally isotropic, stationary Gaussian random field, the ideas of this article can still be applied by choosing the compact domain  $\Delta$  suitably small so that X is close to being isotropic, stationary on  $\Delta$ .

Likelihood methods are likely to perform well if the data are relatively sparse and the model is correctly specified. The situation this article is concerned with is when  $r(\cdot,\cdot)$  in (1) may not be completely known, the data are relatively dense and the likelihood is time consuming and difficult (or even impossible) to compute.

Throughout this article,  $a_n \sim b_n$  denotes  $\lim_{n\to\infty} a_n/b_n = 1$  and likewise,  $a_n \approx b_n$  denotes  $0 < \liminf_{n\to\infty} a_n/b_n \le \limsup_{n\to\infty} a_n/b_n < \infty$ .

<span id="page-3-0"></span>**2.** Higher-order quadratic variations using line transect data. In this section, the observations of X are taken on a line transect. Hence, without loss of generality, Section 2 assumes that X is a Gaussian process having covariance function K as in (1) with d=1 and  $X(t_{n,1}),\ldots,X(t_{n,n})$  are the observed data where  $0=t_{n,1}< t_{n,2}<\cdots< t_{n,n-1}< t_{n,n}=1$ . For brevity we write,  $t_{n,i}=t_i$  and  $X(t_i)=X_i,\ i=1,\ldots,n$ . Define for  $\theta\in\{1,2\}$  and  $\ell\in\{1,\ldots,\lfloor(n-1)/\theta\rfloor\}$ 

$$a_{\theta,\ell;i,k} = \frac{\ell!}{\prod_{0 \le j \le \ell, j \ne k} (t_{i+\theta k} - t_{i+\theta j})} \qquad \forall k = 0, \dots, \ell,$$

$$\nabla_{\theta,\ell} X_i = \sum_{k=0}^{\ell} a_{\theta,\ell;i,k} X_{i+\theta k} \qquad \forall i = 1, \dots, n - \theta \ell,$$

and the  $\ell$ th-order quadratic variation based on  $X_1, \ldots, X_n$  to be

<span id="page-3-3"></span>(3) 
$$V_{\theta,\ell} = \sum_{i=1}^{n-\theta\ell} (\nabla_{\theta,\ell} X_i)^2.$$

<span id="page-3-2"></span>LEMMA 1. For  $\theta \in \{1, 2\}$ ,  $\ell \in \{1, \dots, \lfloor (n-1)/\theta \rfloor\}$  and  $i, j \in \{1, \dots, n-\theta\ell\}$ , we have

<span id="page-3-1"></span>
$$\sum_{k=0}^{\ell} a_{\theta,\ell;i,k} t_{i+\theta k}^{q} = \begin{cases} 0, & \forall q = 0, \dots, \ell - 1, \\ \ell!, & \text{if } q = \ell, \end{cases}$$

(4) 
$$\sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} (t_{j+\theta k_2} - t_{i+\theta k_1})^q = \begin{cases} 0, & \forall q = 0, \dots, 2\ell - 1, \\ (-1)^{\ell} (2\ell)!, & \text{if } q = 2\ell, \end{cases}$$

where we use the convention  $0^0 = 1$ .

The properties of  $V_{\theta,\ell}$  rest crucially on the algebraic identity (4). Interestingly, this identity goes way back to [27]; see also Section 1.2.3, problem 33, of [21]. The other result in Lemma 1 is a direct consequence of (4). Lemma 1 is the reason for using the term " $\ell$ th-order" in the description of  $V_{\theta,\ell}$ . Writing

<span id="page-4-4"></span>(5) 
$$Y = \left(\frac{\nabla_{\theta,\ell} X_1}{\sqrt{E(V_{\theta,\ell})}}, \dots, \frac{\nabla_{\theta,\ell} X_{n-\theta\ell}}{\sqrt{E(V_{\theta,\ell})}}\right)',$$
$$\Sigma = (\Sigma_{i,j})_{(n-\theta\ell)\times(n-\theta\ell)} = E(YY'),$$

we obtain  $V_{\theta,\ell}/E(V_{\theta,\ell}) = Y'Y = Z'\Sigma Z$  where  $Z \sim N_{n-\theta\ell}(0,I)$ . It follows from [14] that

<span id="page-4-1"></span>
$$P\left(\left|\frac{V_{\theta,\ell}}{E(V_{\theta,\ell})} - 1\right| \ge \varepsilon\right)$$

$$= P(|Z'\Sigma Z - E(Z'\Sigma Z)| \ge \varepsilon)$$

$$\leq 2\exp\left\{-C\min\left(\frac{\varepsilon}{\|\Sigma_{abs}\|_{2}}, \frac{\varepsilon^{2}}{\|\Sigma_{abs}\|_{F}^{2}}\right)\right\} \qquad \forall \varepsilon > 0,$$

where C > 0 is an absolute constant,  $\Sigma_{\text{abs}}$  is the  $(n - \theta \ell) \times (n - \theta \ell)$  matrix with elements  $|\Sigma_{i,j}|$ ,  $i, j = 1, \ldots, n - \theta \ell$ , and  $||\cdot||_2$ ,  $||\cdot||_F$  are the spectral, Frobenius matrix norms, respectively.

Lemma 1 and (6) are needed in the proof of Theorem 1 below. The latter provides a way for estimating  $\nu$ . It is convenient to write  $\tilde{K}(x-y) = K(x,y)$  for all  $x,y \in \mathbb{R}$  and  $\tilde{K}^{(2\ell)}$  as the  $2\ell$ th derivative of  $\tilde{K}$  if the latter exists.

<span id="page-4-2"></span>CONDITION 1. For  $n \geq 2$ , define  $t_i = \varphi((i-1)/(n-1))$ , i = 1, ..., n, where  $\varphi : \mathbb{R} \to \mathbb{R}$  is a twice continuously differentiable function satisfying  $\varphi(0) = 0$ ,  $\varphi(1) = 1$  and  $\min_{0 \leq s \leq 1} \varphi^{(1)}(s) > 0$ .

We then say that the  $t_i$ 's are generated by  $\varphi$ . It follows from Condition 1 that there exist constants  $C_{1,0}$  and  $C_{1,1}$  such that

$$0 < C_{1,0}/n \le \min_{1 \le i \le n-1} (t_{i+1} - t_i) \le \max_{1 \le i \le n-1} (t_{i+1} - t_i) \le C_{1,1}/n.$$

Writing  $G_{\nu}(\cdot)$  as in (2), for  $\theta \in \{1,2\}$  and  $\ell \in \{1,\ldots,\lfloor (n-1)/\theta \rfloor\}$ , define

<span id="page-4-3"></span><span id="page-4-0"></span>(7) 
$$f_{\theta,\ell}(\nu) = 2\beta_{\nu}^* \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le \ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} G_{\nu}(t_{i+\theta k_2} - t_{i+\theta k_1})$$

$$\forall \nu \in (0,\ell).$$

THEOREM 1. Let  $V_{\theta,\ell}$  be as in (3),  $\theta \in \{1,2\}$  and Condition 1 holds.

(a) Suppose  $\nu \in (0,\ell)$  and  $\ell \in \{1,\ldots,\lfloor (n-1)/\theta \rfloor \land 10\}$ . Then  $E(V_{\theta,\ell}) \sim f_{\theta,\ell}(\nu) \approx n^{2\ell+1-2\nu}$ . In addition, if  $\tilde{K}^{(2\ell)}(\cdot)$  is a continuous function on an open interval containing (0,1] such that  $|\tilde{K}^{(2\ell)}(t)| \leq C_{\ell} t^{2\nu-2\ell}$ ,  $\forall t \in (0,1]$ , for some constant  $C_{\ell}$ , then

$$\operatorname{Var}\{V_{\theta,\ell}/E(V_{\theta,\ell})\} = \begin{cases} O(n^{-1}), & \text{if } \nu < (4\ell - 1)/4, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (4\ell - 1)/4, \\ O(n^{-4\ell + 4\nu}), & \text{if } \nu > (4\ell - 1)/4, \end{cases}$$

and  $V_{\theta,\ell}/E(V_{\theta,\ell}) \to 1$  almost surely as  $n \to \infty$ .

- (b) Suppose  $\nu = \ell$ . Then  $E(V_{\theta,\ell}) \sim (-1)^{\ell+1} \beta_{\ell}^*(2\ell)! n \log(n)$ . In addition, if  $\tilde{K}^{(2\ell)}(\cdot)$  is a continuous function on an open interval containing (0,1] such that  $|\tilde{K}^{(2\ell)}(t)| \leq C_{\ell} \log(2/t)$ ,  $\forall t \in (0,1]$ , for some constant  $C_{\ell}$ , then  $\operatorname{Var}\{V_{\theta,\ell}/E(V_{\theta,\ell})\} = O\{\log^{-2}(n)\}$  as  $n \to \infty$ .
- (c) Suppose  $\nu > \ell$ . Then  $E(V_{\theta,\ell}) \sim (-1)^{\ell} \beta_{\ell}(2\ell)!n$ . In addition, if  $\tilde{K}^{(2\ell)}(\cdot)$  is a continuous and not identically 0 function on an open interval containing (0,1], then

$$\liminf_{n\to\infty} \operatorname{Var}\{V_{\theta,\ell}/E(V_{\theta,\ell})\} > 0.$$

- REMARK 1. In Theorem 1(a), we restrict  $\ell \leq 10$  as we think this will suffice in practical situations. However, if  $V_{\theta,\ell}$  for some  $\ell > 10$  is required, then as in the proof of Lemma 3, one need only use, say, Mathematica, to verify that  $H_{\ell}(\nu) \neq 0$  for all  $0 \leq \nu \leq \ell$ .
- <span id="page-5-0"></span>2.1. Smoothness estimation on a line transect. Suppose  $0 < \nu \le M < \ell \le 10$  for some known constant M. Under the conditions of Theorem 1(a), it is easy to construct a strongly consistent estimator for  $\nu$ . For example, taking  $\theta = 1$ ,  $\{2\ell + 1 - \log(V_{1,\ell})/\log(n)\}/2$  is one such estimator for  $\nu$ . However, the bias is of order  $1/\log(n)$  which makes it unsuitable for use in practice. With the notation of Theorem 1, define  $F_{\ell,n}:[0,M]\to[0,\infty)$  by  $F_{\ell,n}(\nu^*)=f_{2,\ell}(\nu^*)/f_{1,\ell}(\nu^*)$  for  $\nu^*\in(0,M]$  and  $F_{\ell,n}(0)=\lim_{\delta\to 0+}f_{2,\ell}(\delta)/f_{1,\ell}(\delta)$ . The motivation for taking the ratio on the right-hand side is to eliminate the nuisance parameter  $\beta_{\nu^*}^*$ . We observe from Lemma 5 that  $F_{\ell,n}(\cdot)$  is a continuous function. We shall now construct another strongly consistent estimator  $\hat{\nu}_{a,\ell}$  for  $\nu$ . Let  $\hat{\nu}_{a,\ell} \in [0,M]$  satisfy

<span id="page-5-2"></span>(8) 
$$\left\{ \frac{V_{1,\ell} F_{\ell,n}(\hat{\nu}_{a,\ell})}{V_{2,\ell}} - 1 \right\}^2 = \min_{0 \le \nu^* \le M} \left\{ \frac{V_{1,\ell} F_{\ell,n}(\nu^*)}{V_{2,\ell}} - 1 \right\}^2.$$

<span id="page-5-1"></span>THEOREM 2. Let  $0 < \nu \le M < \ell \le 10$ ,  $\hat{\nu}_{a,\ell}$  be as in (8) and that the conditions of Theorem 1(a) are satisfied. Then  $\hat{\nu}_{a,\ell} \to \nu$  as  $n \to \infty$  almost surely.

In practice, the upper bound M is usually conservative and can be significantly larger than the unknown  $\nu$ . Thus,  $\hat{\nu}_{a,\ell}$  may not perform well for small to moderate sample size n. Next, we propose an alternative estimator  $\hat{\nu}_a$  for  $\nu$  that refines on  $\hat{\nu}_{a,\ell}$  by first estimating an interval of unit width which contains  $\nu$ . The algorithm below is motivated by the fact that  $V_{1,l}F_{l,n}(\nu)/V_{2,l} \to 1$  as  $n \to \infty$  almost surely if  $\nu < l$  (cf. Theorem 1).

Step 2.1. For each l = 1, ..., |M| + 2, let  $\tilde{\nu}_{a,l} \in [0, M]$  be such that

$$\left\{\frac{V_{1,l}F_{l,n}(\tilde{\nu}_{a,l})}{V_{2,l}} - 1\right\}^2 = \min_{0 \le \nu^* \le M \land l} \left\{\frac{V_{1,l}F_{l,n}(\nu^*)}{V_{2,l}} - 1\right\}^2.$$

Step 2.2. Let  $\hat{\nu}_{a,0}$  be the value of  $\tilde{\nu}_{a,l}$  that minimises  $(\tilde{\nu}_{a,l} - \tilde{\nu}_{a,l+1})^2$ ,  $l = 1, \ldots, \lfloor M \rfloor + 1$ . The purpose of  $\hat{\nu}_{a,0}$  is to estimate an interval of unit width containing  $\nu$ .

Step 2.3. We improve on  $\hat{\nu}_{a,0}$  by defining the estimator  $\hat{\nu}_a$  for  $\nu$  to be  $\hat{\nu}_a = \tilde{\nu}_{a,l}$  where l is the smallest integer satisfying  $l > \hat{\nu}_{a,0} + 1/4$ .

REMARK 2. The motivation behind step 2.2 is that if  $0 < \nu < l$ , then  $\tilde{\nu}_{a,l} \to \nu$  and  $(\tilde{\nu}_{a,l} - \tilde{\nu}_{a,l+1})^2 \to 0$  as  $n \to \infty$  almost surely. The rationale for step 2.3 is to use  $V_{\theta,l}$ ,  $\theta \in \{1,2\}$  with the smallest integer  $l > \nu + 1/4$  to estimate  $\nu$  since it follows from Theorem 1(a) that  $\text{Var}\{V_{\theta,l}/E(V_{\theta,l})\} = O(n^{-1})$  as  $n \to \infty$ .

As noted by Stein [25], a class of covariance functions which has considerable practical value is the Matérn class:

<span id="page-6-2"></span>(9) 
$$K_{\text{Mat}}(\mathbf{x}, \mathbf{y}) = \frac{\sigma^2(\alpha \|\mathbf{x} - \mathbf{y}\|)^{\nu}}{2^{\nu - 1}\Gamma(\nu)} \mathcal{K}_{\nu}(\alpha \|\mathbf{x} - \mathbf{y}\|) \qquad \forall \mathbf{x}, \mathbf{y} \in \mathbb{R}^d,$$

where  $\nu, \alpha, \sigma$  are strictly positive constants and  $\mathcal{K}_{\nu}$  is the modified Bessel function of the second kind. This implies that if  $\nu$  is not an integer,

<span id="page-6-0"></span>(10) 
$$K_{\text{Mat}}(\mathbf{x}, \mathbf{y}) = \sigma^{2} \sum_{k=0}^{\infty} \frac{\alpha^{2k} \|\mathbf{x} - \mathbf{y}\|^{2k}}{2^{2k} k! \prod_{i=1}^{k} (i - \nu)} - \frac{\pi \sigma^{2}}{\Gamma(\nu) \sin(\nu \pi)} \sum_{k=0}^{\infty} \frac{\alpha^{2k+2\nu} \|\mathbf{x} - \mathbf{y}\|^{2k+2\nu}}{2^{2k+2\nu} k! \Gamma(k+1+\nu)}.$$

On the other hand, if  $\nu \in \{1, 2, \ldots\}$ ,

<span id="page-6-1"></span>
$$K_{\text{Mat}}(\mathbf{x}, \mathbf{y}) = \frac{2\sigma^2}{(\nu - 1)!} \left\{ (-1)^{\nu + 1} \log \left( \frac{\alpha \|\mathbf{x} - \mathbf{y}\|}{2} \right) \sum_{k=0}^{\infty} \frac{(\alpha \|\mathbf{x} - \mathbf{y}\|/2)^{2(\nu + k)}}{k!(\nu + k)!} \right\}$$

$$+ \frac{1}{2} \sum_{k=0}^{\nu - 1} (-1)^k \frac{(\nu - k - 1)!}{k!} \left( \frac{\alpha \|\mathbf{x} - \mathbf{y}\|}{2} \right)^{2k}$$

$$+ \frac{(-1)^{\nu}}{2} \sum_{k=0}^{\infty} [\psi(k+1) + \psi(\nu+k+1)] \frac{(\alpha \|\mathbf{x} - \mathbf{y}\|/2)^{2(\nu+k)}}{k!(\nu+k)!} \bigg\},$$

where  $\psi(\cdot)$  is the digamma function, that is,  $\psi(k) = -\gamma + \sum_{i=1}^{k-1} i^{-1}$ ,  $k = 1, 2, \ldots$ , and  $\gamma = 0.5772\ldots$  is Euler's constant. Equations (10) and (11) indicate that  $K_{\text{Mat}}(\cdot, \cdot)$  can be expressed as in (1). It can be easily shown that  $\tilde{K}_{\text{Mat}}^{(2\ell)}(\cdot)$  satisfies the conditions in Theorem 1 as well.

In order to gauge the finite sample accuracy of  $\hat{\nu}_{a,0}$  and  $\hat{\nu}_a$ , a simulation experiment is conducted. In this experiment, X is a stationary Gaussian process having mean 0 and Matérn covariance function  $K_{\text{Mat}}$  as in (9) with  $\sigma = \alpha = d = 1$ . All computations are performed using the software Mathematica.

<span id="page-7-1"></span>EXPERIMENT 1. Set n=200, M=2.5 and  $\nu=0.1, 0.5, 0.9, 1, 1.1, 1.5, 1.9, 2, 2.1, 2.5. For <math>i=1,\ldots,n, X_i=X(t_i)$  where  $t_i=\varphi((i-1)/(n-1))$  with  $\varphi(s)=s(s+1)/2$  for all  $s\in\mathbb{R}$ . The mean absolute errors of  $\hat{\nu}_{a,0}$  and  $\hat{\nu}_a$  are computed over 100 replications.

The results from Experiment 1 are presented in Table 1. The mean absolute errors of  $\hat{\nu}_{a,0}$  and  $\hat{\nu}_a$  indicate that  $\hat{\nu}_a$  is significantly more accurate than  $\hat{\nu}_{a,0}$  thus vindicating step 2.3.

It is well known that simulating a stationary Gaussian process on [0,1] when n and  $\nu$  are large is a difficult problem; cf. [26,28]. This is especially so if the data are irregularly spaced. This is the reason why we set the upper limit for the true value of  $\nu$  to be 2.5 in Experiment 1. For larger values of  $\nu$ , the *Mathematica* routine MultinormalDistribution $[\cdot,\cdot]$  returns with the error message that the covariance matrix is not sufficiently positive definite

<span id="page-7-0"></span>Table 1 Experiment 1. Simulation results in estimating  $\nu$  using data generated by  $\varphi(s) = s(s+1)/2$  over 100 replications (standard errors within parentheses)

| ν   | $E \hat{ u}_{a,0}- u $ | $E \hat{ u}_a- u $ |  |
|-----|------------------------|--------------------|--|
| 0.1 | 0.109 (0.010)          | 0.061 (0.004)      |  |
| 0.5 | 0.128 (0.013)          | 0.057 (0.005)      |  |
| 0.9 | 0.107 (0.011)          | 0.074 (0.006)      |  |
| 1.0 | $0.108\ (0.009)$       | 0.074(0.006)       |  |
| 1.1 | 0.113 (0.008)          | 0.069 (0.005)      |  |
| 1.5 | $0.093\ (0.008)$       | 0.052 (0.005)      |  |
| 1.9 | 0.077(0.005)           | 0.078(0.005)       |  |
| 2.0 | $0.082\ (0.005)$       | 0.069(0.005)       |  |
| 2.1 | 0.079(0.006)           | 0.063 (0.006)      |  |
| 2.5 | $0.053\ (0.006)$       | 0.049 (0.004)      |  |
|     | ` '                    | , ,                |  |

to complete the Cholesky decomposition to reasonable accuracy. Finally, we have not compared the performance of  $\hat{\nu}_a$  to the estimator proposed in [3] because the latter estimator requires a choice of neighbourhood blocks and there are no formal guidelines given for choosing these blocks.

<span id="page-8-0"></span>3. Second-order quadratic variation along a curve in  $\mathbb{R}^2$  using 3 or more points. In this section, the observations of X are taken along a fixed curve  $\gamma$  in  $\mathbb{R}^2$  where X is a Gaussian random field having covariance function K as in (1) with d=2. More precisely, we assume the following.

<span id="page-8-4"></span>CONDITION 2. There exist strictly positive constants  $\varepsilon, L$  such that  $\gamma: (-\varepsilon, L+\varepsilon) \to \mathbb{R}^2$  is a  $C^2$ -curve parametrised by its arc length. In particular writing  $\gamma(t) = (\gamma_1(t), \gamma_2(t))'$  and its kth derivative by  $\gamma^{(k)}(t) = (\gamma_1^{(k)}(t), \gamma_2^{(k)}(t))'$ , we have (i)  $\gamma^{(2)}(t)$  exists and is continuous, and (ii)  $\|\gamma^{(1)}(t)\| = 1$  for all  $t \in (-\varepsilon, L+\varepsilon)$ .

<span id="page-8-1"></span>CONDITION 3. There exists a constant  $C_3 > 0$  such that

$$\|\gamma(t^*) - \gamma(t)\| \ge C_3|t^* - t| \quad \forall t^*, t \in [0, L].$$

<span id="page-8-5"></span>CONDITION 4. For  $n \geq 2$ ,  $t_{n,i} = \varphi(L(i-1)/(n-1))$ , i = 1, ..., n, where  $\varphi : \mathbb{R} \to \mathbb{R}$  is a twice continuously differentiable function satisfying  $\varphi(0) = 0$ ,  $\varphi(L) = L$  and  $\min_{0 \leq s \leq L} \varphi^{(1)}(s) > 0$ .

Remark 3. Condition 3 ensures that the curve  $\gamma$  is reasonably well behaved, for example,  $\gamma$  does not intersect itself.

In this section, we shall write  $t_i = t_{n,i}$ ,  $X(\gamma(t_i)) = X_i$  and  $d_{i,j} = ||\gamma(t_i) - \gamma(t_j)||$  for all  $1 \le i, j \le n$ .  $X_1, \ldots, X_n$  represent the observations of X that are made on the curve  $\gamma$ . Define for  $\theta, \ell \in \{1, 2\}$ ,

$$b_{\theta,\ell;i,k} = \frac{\ell}{\prod_{0 \le j \le \ell, j \ne k} (d_{i,i+\theta k} - d_{i,i+\theta j})} \qquad \forall k = 0, \dots, \ell,$$

<span id="page-8-3"></span>
$$\tilde{\nabla}_{\theta,\ell} X_i = \sum_{k=0}^{\ell} b_{\theta,\ell;i,k} X_{i+\theta k} \qquad \forall i = 1, \dots, n - \theta \ell,$$

and the  $\ell$ th-order quadratic variation based on  $X_1, \ldots, X_n$  to be

(12) 
$$\tilde{V}_{\theta,\ell} = \sum_{i=1}^{n-\theta\ell} (\tilde{\nabla}_{\theta,\ell} X_i)^2.$$

Then we observe from Lemma 1 that for  $\theta, \ell \in \{1, 2\}$ ,

<span id="page-8-2"></span>(13) 
$$\sum_{k=0}^{\ell} b_{\theta,\ell;i,k} d_{i,i+\theta k}^{q} = \begin{cases} 0, & \text{if } q = 0, \dots, \ell - 1, \\ \ell, & \text{if } q = \ell. \end{cases}$$

Equation (13) is the motivation for calling  $\tilde{V}_{\theta,\ell}$  " $\ell$ th-order". Define  $\tilde{K}(\mathbf{x} - \mathbf{y}) = K(\mathbf{x}, \mathbf{y})$  for all  $\mathbf{x}, \mathbf{y} \in \mathbb{R}^2$ . Letting  $a_1$  and  $a_2$  be nonnegative integers, we write  $\mathbf{x} = (x_1, x_2)'$  and

$$\tilde{K}^{(a_1,a_2)}(\mathbf{x}) = \frac{\partial^{a_1+a_2}}{\partial x_1^{a_1} \partial x_2^{a_2}} \tilde{K}(\mathbf{x}).$$

Let  $\Gamma$  be a compact, convex set in  $\mathbb{R}^2$  such that  $\{\gamma(t): 0 \le t \le L\} \subset \Gamma$ . For  $\theta, \ell \in \{1, 2\}$ , define

<span id="page-9-3"></span>(14) 
$$\tilde{f}_{\theta,\ell}(\nu) = 2\beta_{\nu}^* \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le \ell} b_{\theta,\ell;i,k_1} b_{\theta,\ell;i,k_2} G_{\nu}(d_{i+\theta k_1,i+\theta k_2})$$

$$\forall \nu \in (0,\ell).$$

<span id="page-9-0"></span>THEOREM 3. Let  $\theta, \ell \in \{1, 2\}$ ,  $\nu \in (0, \ell)$  and  $\tilde{V}_{\theta, \ell}$  be as in (12). Suppose Conditions 2, 3 and 4 hold. Then  $E(\tilde{V}_{\theta, \ell}) \sim \tilde{f}_{\theta, \ell}(\nu) \approx n^{2\ell+1-2\nu}$ . In addition, suppose (i)  $\tilde{K}^{(a_1, a_2)}(\cdot)$  is a continuous function on an open set containing  $\{\mathbf{x} - \mathbf{y} : \mathbf{x}, \mathbf{y} \in \Gamma, \mathbf{x} \neq \mathbf{y}\}$  whenever  $a_1, a_2$  are nonnegative integers such that  $a_1 + a_2 = 2\ell$  and (ii) there exists a constant  $C_4$  such that

$$|\tilde{K}^{(a_1,a_2)}(\mathbf{x} - \mathbf{y})| \le C_4 ||\mathbf{x} - \mathbf{y}||^{2\nu - 2\ell}$$
  $\forall 2 \le a_1 + a_2 \le 2\ell$ ,

for all  $\mathbf{x}, \mathbf{y} \in \Gamma$ ,  $\mathbf{x} \neq \mathbf{y}$ . Then  $\tilde{V}_{\theta,\ell}/E(\tilde{V}_{\theta,\ell}) \to 1$  almost surely and

$$\operatorname{Var}\{\tilde{V}_{\theta,\ell}/E(\tilde{V}_{\theta,\ell})\} = \begin{cases} O(n^{-1}), & \text{if } \nu < (4\ell - 1)/4, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (4\ell - 1)/4, \\ O(n^{-4\ell + 4\nu}), & \text{if } \nu > (4\ell - 1)/4, \end{cases} \quad \text{as } n \to \infty.$$

The proof of Theorem 3 is can be found in the supplemental article [23].

<span id="page-9-1"></span>3.1. Estimating  $\nu$  along a smooth curve in  $\mathbb{R}^2$ . Let  $\theta, \ell \in \{1, 2\}$  and  $\tilde{f}_{\theta,\ell}$  be as in (14). Define  $\tilde{F}_{\ell,n}: [0,\ell] \to \mathbb{R}$  by  $\tilde{F}_{\ell,n}(\nu^*) = \tilde{f}_{2,\ell}(\nu^*)/\tilde{f}_{1,\ell}(\nu^*)$   $\forall \nu^* \in (0,\ell), \ \tilde{F}_{\ell,n}(0) = \lim_{\delta \to 0+} \tilde{f}_{2,\ell}(\delta)/\tilde{f}_{1,\ell}(\delta)$  and  $\tilde{F}_{\ell,n}(\ell) = \lim_{\delta \to 0+} \tilde{f}_{2,\ell}(\ell-\delta)/\tilde{f}_{1,\ell}(\ell-\delta)$ . We observe from Lemma 5 that  $\tilde{F}_{\ell,n}(\cdot)$  is a continuous function. Let  $\hat{\nu}_{b,\ell} \in [0,\ell]$  satisfy

<span id="page-9-4"></span>(15) 
$$\left\{ \frac{\tilde{V}_{1,\ell}\tilde{F}_{\ell,n}(\hat{\nu}_{b,\ell})}{\tilde{V}_{2,\ell}} - 1 \right\}^2 = \min_{0 \le \nu^* \le \ell} \left\{ \frac{\tilde{V}_{1,\ell}\tilde{F}_{\ell,n}(\nu^*)}{\tilde{V}_{2,\ell}} - 1 \right\}^2.$$

<span id="page-9-2"></span>THEOREM 4. Let  $\ell \in \{1,2\}$ ,  $\nu \in (0,\ell)$  and  $\hat{\nu}_{b,\ell}$  be as in (15). Suppose the conditions of Theorem 3 are satisfied. Then  $\hat{\nu}_{b,\ell} \to \nu$  as  $n \to \infty$  almost surely.

Using Lemma 7, the proof of Theorem 4 is similar to that of Theorem 2 and will be omitted. Theorem 4 proves that  $\hat{\nu}_{b,2}$  is a strongly consistent estimator for  $\nu \in (0,2)$ . However, if  $\nu$  is close to 0, the upper bound of 2 is conservative and a better estimator for  $\nu$  is  $\hat{\nu}_{b,1}$ . Consequently, we propose the following alternative estimator  $\hat{\nu}_b$  for  $\nu \in (0,2)$ .

Compute  $\hat{\nu}_{b,2}$ . If  $\hat{\nu}_{b,2} > 3/4$ , define  $\hat{\nu}_b = \hat{\nu}_{b,2}$ . If  $\hat{\nu}_{b,2} \leq 3/4$ , compute  $\hat{\nu}_{b,1}$  and define  $\hat{\nu}_b = \hat{\nu}_{b,1}$ . 3/4 is motivated by the last statement of Theorem 3 when  $\ell = 1$ . Under the assumptions of Theorem 4, we observe that  $\hat{\nu}_b$  is also a strongly consistent estimator for  $\nu$ .

<span id="page-10-1"></span>Remark 4. We observe from the definitions of  $\hat{\nu}_{b,2}, \hat{\nu}_b$  that  $\varphi$  need not be explicitly known; only the bijection  $\Phi: \{1, \ldots, n\} \to \{\phi_i = \varphi(L(i-1)/(n-1)) : i=1,\ldots,n\}$  is required. There are 2 feasible bijections, namely  $i \mapsto \varphi(L(i-1)/(n-1))$  and  $i \mapsto \varphi(L(n-i)/(n-1))$ . Either bijection will do. If the curve  $\gamma$  is known, then  $\Phi$  can be recovered from the ordering of the  $\phi_i$ 's along  $\gamma$ . On the other hand if  $\gamma$  is unknown, then  $\Phi$  can be obtained using the fact that "adjacent"  $\phi_i$ 's are closest to each other for sufficiently large n, that is,  $\max_{k=-1,1} \|\phi_{j+k} - \phi_j\| < \min_{i \neq j-1,j,j+1} \|\phi_i - \phi_j\|$ . This greatly increases the utility of  $\hat{\nu}_{b,2}, \hat{\nu}_b$  in applications. The following is an algorithm for determining  $\Phi$  when  $\gamma$  is unknown:

Step 3.1. First, arbitrarily pick an element  $y_0$  from the set  $\{\phi_1, \ldots, \phi_n\}$ . Step 3.2. Let  $y_1$  denote the element of  $\tilde{Y}_0 = \{\phi_1, \ldots, \phi_n\} \setminus \{y_0\}$  such that  $\|y_1 - y_0\| = \min\{\|\phi_i - y_0\| : \phi_i \in \tilde{Y}_0\}$ .

Step 3.3. Given  $Y_{-k,l} = \{y_{-k}, \dots, y_0, \dots, y_l\}$ , let  $y^*, y^{**}$  denote elements of  $\tilde{Y}_{-k,l} = \{\phi_1, \dots, \phi_n\} \setminus Y_{-k,l}$  such that  $\|y^* - y_{-k}\| = \min\{\|\phi_i - y_{-k}\| : \phi_i \in \tilde{Y}_{-k,l}\}$  and  $\|y^{**} - y_l\| = \min\{\|\phi_i - y_l\| : \phi_i \in \tilde{Y}_{-k,l}\}$ . If  $\|y^* - y_{-k}\| \le \|y^{**} - y_l\|$ , define  $y_{-(k+1)} = y^*$  and if  $\|y^* - y_{-k}\| > \|y^{**} - y_l\|$ , define  $y_{l+1} = y^{**}$ .

Step 3.4. Repeat step 3.3 until the cardinality of  $Y_{-k,l}$  is n. The ordering of this  $Y_{-k,l}$ , with cardinality n and l=n-k-1, gives the required bijection  $\Phi(i)=y_{-k+i-1},\ i=1,\ldots,n$ .

A simulation experiment is conducted to gauge the finite sample accuracy of  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$ . In Experiment 2 below:

- (i) X is a stationary Gaussian random field having mean 0 and Matérn covariance function  $K_{\text{Mat}}$  as in (9) with  $\sigma = \alpha = 1$  and d = 2.
- (ii)  $\gamma$  is an arc of the unit circle given by  $\gamma(t) = (\cos(t), \sin(t))'$  for all  $0 \le t \le \pi/2$ .

<span id="page-10-0"></span>EXPERIMENT 2. Set n = 200,  $\nu = 0.1$ , 0.3, 0.5, 0.7, 0.9, 1, 1.3, 1.5, 1.7, 1.9 and let  $\varphi(s) = s(s+1)/(L+1)$ ,  $0 \le s \le L = \pi/2$ . The data  $X_1, \ldots, X_n$  are given by  $X_i = X(\gamma(t_i))$  where  $t_i = \varphi(L(i-1)/(n-1))$ ,  $i = 1, \ldots, n$ . Table 2

<span id="page-11-0"></span>Table 2
Experiment 2. Simulation results in estimating  $\nu$  with nonequispaced data along a curve  $\gamma$  over 100 replications (standard error within parentheses)

| ν   | $E \hat{ u}_{b,2}- u $ | $E \hat{ u}_b- u $ |
|-----|------------------------|--------------------|
| 0.1 | 0.102 (0.007)          | 0.059 (0.004)      |
| 0.3 | 0.133 (0.010)          | $0.058 \ (0.006)$  |
| 0.5 | 0.122 (0.009)          | $0.058 \; (0.007)$ |
| 0.7 | 0.111 (0.008)          | $0.082\ (0.007)$   |
| 0.9 | 0.078 (0.007)          | $0.068 \; (0.005)$ |
| 1.0 | $0.076 \ (0.007)$      | $0.070 \ (0.005)$  |
| 1.3 | 0.059 (0.004)          | 0.059 (0.004)      |
| 1.5 | 0.049 (0.004)          | 0.049 (0.004)      |
| 1.7 | $0.041 \ (0.003)$      | $0.041 \ (0.003)$  |
| 1.9 | $0.072 \ (0.004)$      | $0.072 \ (0.004)$  |

reports the estimated mean absolute errors of  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$  over 100 replications. The mean absolute errors of  $\hat{\nu}_{b,2}$  and  $\hat{\nu}_b$  indicate that  $\hat{\nu}_b$  is indeed more accurate than  $\hat{\nu}_{b,2}$ .

<span id="page-11-1"></span>4. Second-order quadratic variations using 4 or more deformed lattice points in  $\mathbb{R}^2$ . Let  $[0,1]^2 \subset \Omega$  where  $\Omega$  is an open set in  $\mathbb{R}^2$ . A function  $\tilde{\varphi}: \Omega \to \mathbb{R}^2$  is said to be  $C^1(\Omega)$  if all first-order partial derivatives  $\partial \varphi_i(x_1,x_2)/\partial x_j$  exist and are continuous. Here, we write  $\tilde{\varphi} = (\varphi_1, \varphi_2)$  where  $\varphi_1, \varphi_2$  are real-valued functions. The class of  $C^1(\Omega)$  diffeomorphisms is the set of all continuous invertible maps  $\tilde{\varphi}: \Omega \to \mathbb{R}^2$ , such that  $\tilde{\varphi}$  is  $C^1(\Omega)$  and  $\tilde{\varphi}^{-1}$  is  $C^1(\Omega^*)$  where  $\Omega^*$  is the range of  $\tilde{\varphi}$ .

<span id="page-11-2"></span>CONDITION 5.  $\tilde{\varphi}$  is a  $C^2(\Omega)$  diffeomorphism, which is a  $C^1(\Omega)$  diffeomorphism with continuous second-order mixed partial derivatives.

Define  $\mathbf{x}^{i_1,i_2} = (\varphi_1(i_1/n,i_2/n), \varphi_2(i_1/n,i_2/n))^{\prime}$ ,  $1 \leq i_1,i_2 \leq n$ , and denote  $X_{i_1,i_2} = X(\mathbf{x}^{i_1,i_2})$  where X is a stationary, isotropic Gaussian random field on  $\mathbb{R}^2$  having covariance function K as in (1) with d=2. We write  $\varphi_j^{(1,0)}(u,v) = \partial \varphi_j(u,v)/\partial u$  and  $\varphi_j^{(0,1)}(u,v) = \partial \varphi_j(u,v)/\partial v$  for j=1,2. Since  $\tilde{\varphi}$  is a  $C^2(\Omega)$  diffeomorphism, we observe from [2], page 2331,

Since  $\tilde{\varphi}$  is a  $C^2(\Omega)$  diffeomorphism, we observe from [2], page 2331, that there exist constants  $0 < C_{5,0} \le 1 \le C_{5,1}$  such that that for all  $1 \le i_1, i_2, j_1, j_2 \le n$ ,

$$C_{5,0} \left\| \left( \frac{i_1}{n}, \frac{i_2}{n} \right)' - \left( \frac{j_1}{n}, \frac{j_2}{n} \right)' \right\| \le \|\mathbf{x}^{i_1, i_2} - \mathbf{x}^{j_1, j_2}\| \le C_{5,1} \left\| \left( \frac{i_1}{n}, \frac{i_2}{n} \right)' - \left( \frac{j_1}{n}, \frac{j_2}{n} \right)' \right\|.$$

For  $\theta \in \{1, 2\}$  and  $1 \le i_1, i_2 \le n - \theta$ , let

$$\mathbf{x}^{i_1+\theta k_1,i_2+\theta k_2} = (x_1^{i_1+\theta k_1,i_2+\theta k_2}, x_2^{i_1+\theta k_1,i_2+\theta k_2})' \qquad \forall 0 \le k_1, k_2 \le 1,$$

$$\begin{split} A_{\theta;i_1,i_2} &= \begin{pmatrix} x_1^{i_1+\theta,i_2} - x_1^{i_1,i_2} & x_2^{i_1+\theta,i_2} - x_2^{i_1,i_2} \\ x_1^{i_1,i_2+\theta} - x_1^{i_1,i_2} & x_2^{i_1,i_2+\theta} - x_2^{i_1,i_2} \end{pmatrix}, \\ B_{\theta;i_1,i_2} &= \begin{pmatrix} x_1^{i_1+\theta,i_2} - x_1^{i_1+\theta,i_2+\theta} & x_2^{i_1+\theta,i_2} - x_2^{i_1+\theta,i_2+\theta} \\ x_1^{i_1,i_2+\theta} - x_1^{i_1+\theta,i_2+\theta} & x_2^{i_1,i_2+\theta} - x_2^{i_1+\theta,i_2+\theta} \end{pmatrix}. \end{split}$$

We write

<span id="page-12-0"></span>(16) 
$$\begin{pmatrix} X_{i_1+\theta,i_2} - X_{i_1,i_2} \\ X_{i_1,i_2+\theta} - X_{i_1,i_2} \end{pmatrix} = A_{\theta;i_1,i_2} \begin{pmatrix} g_{\theta,1}(i_1,i_2) \\ g_{\theta,2}(i_1,i_2) \end{pmatrix}.$$

The motivation for (16) is that  $g_{\theta,j}(i_1, i_2)$  approximates  $\partial X_{i_1, i_2}/\partial x_j^{i_1, i_2}$ . Since  $\tilde{\varphi}$  is a diffeomorphism, it follows from the inverse function theorem (cf. [23]) that

$$(n/\theta)^{2}|A_{\theta;i_{1},i_{2}}| \to \varphi_{1}^{(1,0)}\left(\frac{i_{1}}{n},\frac{i_{2}}{n}\right)\varphi_{2}^{(0,1)}\left(\frac{i_{1}}{n},\frac{i_{2}}{n}\right) - \varphi_{1}^{(0,1)}\left(\frac{i_{1}}{n},\frac{i_{2}}{n}\right)\varphi_{2}^{(1,0)}\left(\frac{i_{1}}{n},\frac{i_{2}}{n}\right)$$

$$\neq 0,$$

as  $n \to \infty$ . Thus, for sufficiently large n,  $A_{\theta;i_1,i_2}^{-1}$  exists and

$$\begin{split} A_{\theta;i_1,i_2}^{-1} &= |A_{\theta;i_1,i_2}|^{-1} \begin{pmatrix} x_2^{i_1,i_2+\theta} - x_2^{i_1,i_2} & -x_2^{i_1+\theta,i_2} + x_2^{i_1,i_2} \\ -x_1^{i_1,i_2+\theta} + x_1^{i_1,i_2} & x_1^{i_1+\theta,i_2} - x_1^{i_1,i_2} \end{pmatrix} \\ &= (\alpha_{\theta;i_1,i_2}^{j,l})_{j,l=1,2}, \quad \text{say}. \end{split}$$

Hence,

$$\begin{pmatrix} g_{\theta,1}(i_1, i_2) \\ g_{\theta,2}(i_1, i_2) \end{pmatrix} = A_{\theta; i_1, i_2}^{-1} \begin{pmatrix} X_{i_1+\theta, i_2} - X_{i_1, i_2} \\ X_{i_1, i_2+\theta} - X_{i_1, i_2} \end{pmatrix}.$$

In particular choosing the  $\ell$ th coordinate, we obtain

$$g_{\theta,\ell}(i_1,i_2) = \alpha_{\theta;i_1,i_2}^{\ell,1}(X_{i_1+\theta,i_2} - X_{i_1,i_2}) + \alpha_{\theta;i_1,i_2}^{\ell,2}(X_{i_1,i_2+\theta} - X_{i_1,i_2}),$$

$$\ell \in \{1,2\}.$$

In a similar manner, writing

<span id="page-12-1"></span>(17) 
$$\begin{pmatrix} X_{i_1+\theta,i_2} - X_{i_1+\theta,i_2+\theta} \\ X_{i_1,i_2+\theta} - X_{i_1+\theta,i_2+\theta} \end{pmatrix} = B_{\theta;i_1,i_2} \begin{pmatrix} h_{\theta,1}(i_1+\theta,i_2+\theta) \\ h_{\theta,2}(i_1+\theta,i_2+\theta) \end{pmatrix},$$

we have

$$B_{\theta;i_1,i_2}^{-1} = |B_{\theta;i_1,i_2}|^{-1} \begin{pmatrix} x_2^{i_1,i_2+\theta} - x_2^{i_1+\theta,i_2+\theta} & -x_2^{i_1+\theta,i_2} + x_2^{i_1+\theta,i_2+\theta} \\ -x_1^{i_1,i_2+\theta} + x_1^{i_1+\theta,i_2+\theta} & x_1^{i_1+\theta,i_2} - x_1^{i_1+\theta,i_2+\theta} \end{pmatrix}$$

$$= (\beta_{\theta;i_1,i_2}^{j,l})_{i,l=1,2}, \quad \text{say},$$

and hence

$$\begin{pmatrix} h_{\theta,1}(i_1+\theta,i_2+\theta) \\ h_{\theta,2}(i_1+\theta,i_2+\theta) \end{pmatrix} = B_{\theta;i_1,i_2}^{-1} \begin{pmatrix} X_{i_1+\theta,i_2} - X_{i_1+\theta,i_2+\theta} \\ X_{i_1,i_2+\theta} - X_{i_1+\theta,i_2+\theta} \end{pmatrix},$$

$$h_{\theta,\ell}(i_1+\theta,i_2+\theta) = \beta_{\theta;i_1,i_2}^{\ell,1} (X_{i_1+\theta,i_2} - X_{i_1+\theta,i_2+\theta})$$

$$+ \beta_{\theta;i_1,i_2}^{\ell,2} (X_{i_1,i_2+\theta} - X_{i_1+\theta,i_2+\theta}) \qquad \forall \ell \in \{1,2\}.$$

For  $1 \le i_1, i_2 \le n - \theta$  and  $\theta, \ell \in \{1, 2\}$ , we write

<span id="page-13-2"></span>
$$\bar{\nabla}_{\theta,\ell} X_{i_1,i_2} = \beta_{\theta;i_1,i_2}^{\ell,1} (X_{i_1+\theta,i_2} - X_{i_1+\theta,i_2+\theta}) + \beta_{\theta;i_1,i_2}^{\ell,2} (X_{i_1,i_2+\theta} - X_{i_1+\theta,i_2+\theta})$$
(18)
$$- \alpha_{\theta;i_1,i_2}^{\ell,1} (X_{i_1+\theta,i_2} - X_{i_1,i_2}) - \alpha_{\theta;i_1,i_2}^{\ell,2} (X_{i_1,i_2+\theta} - X_{i_1,i_2})$$

$$= \sum_{0 \le k_1,k_2 \le 1} c_{\theta,\ell;i_1,i_2}^{k_1,k_2} X_{i_1+\theta k_1,i_2+\theta k_2}, \quad \text{say}.$$

In this section, second-order quadratic variations based on  $\{X_{i_1,i_2}: 1 \leq i_1, i_2 \leq n\}$  are defined to be

(19) 
$$\bar{V}_{\theta,\ell} = \sum_{1 \le i_1, i_2 \le n - \theta} (\bar{\nabla}_{\theta,\ell} X_{i_1, i_2})^2, \qquad \theta, \ell \in \{1, 2\}.$$

<span id="page-13-3"></span>Lemma 2 below provides the rationale for calling  $\bar{V}_{\theta,\ell}$  "second-order".

<span id="page-13-1"></span>Lemma 2. Let  $c_{\theta,\ell;i_1,i_2}^{k_1,k_2}$ ,  $\theta,\ell\in\{1,2\}$ , be as in (18). Then for all  $1\leq i_1,i_2\leq n-\theta$ , we have

$$\begin{split} \sum_{0 \leq k_1, k_2 \leq 1} c_{\theta, \ell; i_1, i_2}^{k_1, k_2} &= 0, \\ \sum_{0 \leq k_1, k_2 \leq 1} c_{\theta, \ell; i_1, i_2}^{k_1, k_2} x_j^{i_1 + \theta k_1, i_2 + \theta k_2} &= 0 \qquad \forall j = 1, 2. \end{split}$$

<span id="page-13-4"></span>Let  $G_{\nu}(\cdot)$  as in (2). For  $\theta, \ell \in \{1, 2\}$ , define

(20) 
$$\bar{f}_{\theta,\ell}(\nu) = \beta_{\nu}^{*} \sum_{1 \leq i_{1}, i_{2} \leq n - \theta} \sum_{0 \leq k_{1}, l_{1}, k_{2}, l_{2} \leq 1: (k_{1}, k_{2}) \neq (l_{1}, l_{2})} c_{\theta,\ell;i_{1},i_{2}}^{k_{1},k_{2}} c_{\theta,\ell;i_{1},i_{2}}^{l_{1},l_{2}} \\
\times G_{\nu}(\|\mathbf{x}^{i_{1} + \theta k_{1}, i_{2} + \theta k_{2}} - \mathbf{x}^{i_{1} + \theta l_{1}, i_{2} + \theta l_{2}}\|) \quad \forall \nu \in (0, 2).$$

and  $\tilde{K}(\mathbf{x} - \mathbf{y}) = K(\mathbf{x}, \mathbf{y})$  for all  $\mathbf{x}, \mathbf{y} \in \mathbb{R}^2$ . Letting  $a_1, a_2$  to be nonnegative integers, we write

$$\tilde{K}^{(a_1,a_2)}(\mathbf{x}) = \frac{\partial^{a_1+a_2}}{\partial x_1^{a_1} \partial x_2^{a_2}} \tilde{K}(\mathbf{x}) \qquad \forall \mathbf{x} = (x_1, x_2)',$$

<span id="page-13-0"></span>and  $\Delta = \{(\varphi_1(u, v), \varphi_2(u, v))' : 0 \le u, v \le 1\}.$ 

THEOREM 5. Let  $\theta, \ell \in \{1, 2\}$ ,  $\nu \in (0, 2)$  and  $\bar{V}_{\theta,\ell}$  be as in (19). Suppose that Condition 5 holds and that  $\mathcal{J}_{\nu,\ell}(\cdot,\cdot)$ , as in Lemma 8, is not identically 0 on  $[0,1]^2$ . Then  $E(\bar{V}_{\theta,\ell}) \sim \bar{f}_{\theta,\ell}(\nu) \approx n^{4-2\nu}$ . In addition, suppose (i)  $\tilde{K}^{(a_1,a_2)}(\cdot)$  is a continuous function on an open set containing  $\{\mathbf{x} - \mathbf{y} : \mathbf{x}, \mathbf{y} \in \Delta, \mathbf{x} \neq \mathbf{y}\}$  whenever  $a_1, a_2$  are nonnegative integers such that  $a_1 + a_2 = 4$  and (ii) there exists a constant  $\tilde{C}$  such that

$$|\tilde{K}^{(a_1,a_2)}(\mathbf{x}-\mathbf{y})| \leq \tilde{C} ||\mathbf{x}-\mathbf{y}||^{2\nu-4},$$

for all  $a_1 + a_2 = 4$ ,  $\mathbf{x}, \mathbf{y} \in \Delta$  and  $\mathbf{x} \neq \mathbf{y}$ . Then

$$\operatorname{Var}\{\bar{V}_{\theta,\ell}/E(\bar{V}_{\theta,\ell})\} = \begin{cases} O(n^{-2}), & \text{if } \nu \in (0,3/2), \\ O\{n^{-2}\log(n)\}, & \text{if } \nu = 3/2, \\ O(n^{-8+4\nu}), & \text{if } \nu \in (3/2,2), \end{cases}$$

and  $\bar{V}_{\theta,\ell}/E(\bar{V}_{\theta,\ell}) \to 1$  almost surely as  $n \to \infty$ .

<span id="page-14-3"></span>The proof of Theorem 5, which uses Lemmas 8 and 9, is similar to that of Theorem 3 and can be found in [23]. We end this section with the following immediate corollary of Theorem 5.

COROLLARY 1. Suppose  $\nu \in (0,2)$  and  $\theta, \ell \in \{1,2\}$ . Then under the conditions of Theorem 5,  $\hat{\nu}_{\theta,\ell} = \{4 - \log(\bar{V}_{\theta,\ell})/\log(n)\}/2$  is a strongly consistent estimator for  $\nu$ .

We observe that, unfortunately, the bias of  $\hat{\nu}_{\theta,\ell}$  is of order  $1/\log(n)$  and this makes  $\hat{\nu}_{\theta,\ell}$  unsuitable for use in practice.

<span id="page-14-0"></span>4.1. Estimating  $\nu$  using deformed lattice data in  $\mathbb{R}^2$ . Writing  $\bar{f}_{\theta,\ell}(\cdot)$ ,  $\theta, \ell \in \{1, 2\}$ , as in (20), define  $\bar{F}_{\ell,n} : [0, 2] \to [0, \infty)$  by

$$\bar{F}_{\ell,n}(\nu^*) = \bar{f}_{2,\ell}(\nu^*)/\bar{f}_{1,\ell}(\nu^*)$$
 if  $\nu^* \in (0,2)$ ,

 $\bar{F}_{\ell,n}(0) = \lim_{\delta \to 0+} \bar{F}_{\ell,n}(\delta)$  and  $\bar{F}_{\ell,n}(2) = \lim_{\delta \to 0+} \bar{F}_{\ell,n}(2-\delta)$ . We observe from Lemma 5 that  $\bar{F}_{\ell,n}(\cdot)$  is a continuous function on [0, 2]. Let  $\hat{\nu}_{c,\ell} \in [0, 2]$  satisfy

(21) 
$$\left\{ \frac{\bar{V}_{1,\ell}\bar{F}_{\ell,n}(\hat{\nu}_{c,\ell})}{\bar{V}_{2,\ell}} - 1 \right\}^2 = \min_{0 \le \nu^* \le 2} \left\{ \frac{\bar{V}_{1,\ell}\bar{F}_{\ell,n}(\nu^*)}{\bar{V}_{2,\ell}} - 1 \right\}^2.$$

<span id="page-14-2"></span><span id="page-14-1"></span>The following is the main result of this section.

THEOREM 6. Let  $\nu \in (0,2)$ ,  $\ell \in \{1,2\}$  and  $\hat{\nu}_{c,\ell}$  be as in (21). Suppose the conditions of Theorem 5 are satisfied. Then  $\hat{\nu}_{c,\ell} \to \nu$  as  $n \to \infty$  almost surely.

<span id="page-15-0"></span>Using Lemma 9, the proof of Theorem 6 is similar to that of Theorem 2 and can be found in [23].

Remark 5. We observe from the definition of  $\hat{\nu}_{c,\ell}$  that  $\tilde{\varphi}$  need not be explicitly known; only the bijection  $\tilde{\Phi}: \{(i_1,i_2): 1 \leq i_1, i_2 \leq n\} \rightarrow \{\phi_{i_1,i_2} = \tilde{\varphi}(i_1/n,i_2/n): 1 \leq i_1,i_2 \leq n\}$  is required. In many designs of experiments scenarios,  $\tilde{\varphi}$  is known. On the other hand, if  $\tilde{\varphi}$  is unknown, we propose the algorithm below to determine the bijection  $\tilde{\Phi}$ .

Step 4.1. First, divide the set  $\{\phi_{i_1,i_2}, 1 \leq i_1, i_2 \leq n\}$  into n disjoint subsets  $\gamma_1, \ldots, \gamma_n$  where each subset contains n elements. The motivation here is that  $\gamma_i$  corresponds to  $\{\phi_{i,j}: 1 \leq j \leq n\}$ . As in Remark 4, the elements of  $\gamma_i$  are ordered and adjacent elements are connected by straight lines. Thus,  $\gamma_i$  becomes a piecewise linear continuous curve in  $\mathbb{R}^2$ . As curves,  $\gamma_1, \ldots, \gamma_n$  are chosen so that  $\gamma_i$  and  $\gamma_j$  do not intersect if  $i \neq j$  and for each  $1 \leq i \leq n-2$ , the only curve that lies between  $\gamma_i$  and  $\gamma_{i+2}$  is  $\gamma_{i+1}$ .

Step 4.2. For  $\gamma_1$ , we label its elements by  $\mathbf{x}^{1,1}, \dots, \mathbf{x}^{1,n}$  in that the ordering of the second superscript follows the ordering of the elements along the curve  $\gamma_1$ .

Step 4.3. Let  $1 \le k \le n-1$ . Given  $\gamma_l = \{\mathbf{x}^{l,j} : 1 \le j \le n\}$ ,  $1 \le l \le k$ , the elements of  $\gamma_{k+1}$  are ordered as in Remark 4 such that  $\mathbf{x}^{k+1,1}$  is closer to  $\mathbf{x}^{k,1}$  than to  $\mathbf{x}^{k,n}$ .

Step 4.4. Increase k by 1 and repeat step 4.3 until the elements of  $\gamma_n$  have been ordered. The required bijection  $\tilde{\Phi}$  is given as  $\mathbf{x}^{i,j} = \tilde{\varphi}(i/n, j/n)$ ,  $1 \leq i, j \leq n$ .

We note that there is an extensive literature on landmark matching via large deformation diffeomorphisms, for example, [11, 18]. These techniques can be used to compute the diffeomorphism  $\tilde{\varphi}$  in step 4.4 with bijection  $\tilde{\Phi}$  as landmarks.

REMARK 6. The algorithm in Remark 5 assumes that the curves  $\gamma_1, \ldots, \gamma_n$  can be found. A simpler alternative is to select only 1 subset  $\Gamma \subseteq \{\tilde{\varphi}(i_1/n, i_2/n) : 1 \le i_1, i_2 \le n\}$  of cardinality n, say. Treat  $\Gamma$  as points lying on a  $C^2$  curve  $\gamma$  and then apply the methodology of Section 3 to estimate  $\nu$ . For the asymptotics of Theorem 4 to be more effective,  $\Gamma$  should be chosen so that the adjacent points on  $\gamma$  are close to each other and that the curvature of the curve  $\gamma$  is reasonably small.

<span id="page-15-1"></span>A simulation experiment is conducted to gauge the finite sample accuracy of  $\hat{\nu}_{c,1}$  and  $\hat{\nu}_{c,2}$ . In Experiment 3 below, X is a stationary Gaussian random field having mean 0 and Matérn covariance function  $K_{\text{Mat}}$  as in (9) with  $\sigma = \alpha = 1$  and d = 2.

<span id="page-16-0"></span>Table 3
Experiment 3. Simulation results in estimating  $\nu$  using deformed lattice data over 100 replications (standard errors within parentheses)

| ν   | $E \hat{ u}_{c,1}- u $ | $E \hat{ u}_{c,2}- u $ |
|-----|------------------------|------------------------|
| 0.1 | 0.054 (0.003)          | 0.036 (0.003)          |
| 0.3 | 0.042 (0.004)          | 0.034 (0.002)          |
| 0.5 | $0.051 \ (0.003)$      | 0.034 (0.003)          |
| 0.7 | 0.041 (0.003)          | 0.033 (0.002)          |
| 0.9 | $0.040 \ (0.003)$      | $0.029 \ (0.002)$      |
| 1.0 | $0.044 \ (0.003)$      | $0.033 \ (0.002)$      |
| 1.3 | $0.040 \ (0.003)$      | $0.030 \ (0.002)$      |
| 1.5 | $0.036 \ (0.003)$      | $0.034 \ (0.003)$      |
| 1.7 | $0.064 \ (0.005)$      | $0.056 \ (0.004)$      |
| 1.9 | $0.118 \; (0.005)$     | $0.102 \ (0.004)$      |

EXPERIMENT 3. Set n=40 and  $\nu=0.1,\ 0.3,\ 0.5,\ 0.7,\ 0.9,\ 1,\ 1.3,\ 1.5,\ 1.7,\ 1.9.$  Let  $\tilde{\varphi}:\mathbb{C}\to\mathbb{C}$  be given by  $\tilde{\varphi}(z)=z(z+1)/3=\varphi_1(z)+\mathbf{i}\varphi_2(z)$   $\forall z\in\mathbb{C}$  where  $\varphi_i$ 's are real-valued functions and  $\mathbf{i}=\sqrt{-1}$ . We take  $\mathbf{x}^{i_1,i_2}=(\varphi_1(i_1n^{-1}+\mathbf{i}i_2n^{-1}),\varphi_2(i_1n^{-1}+\mathbf{i}i_2n^{-1}))',\ 1\leq i_1,i_2\leq n$ . Table 3 reports the estimated mean absolute errors of  $\hat{\nu}_{c,1}$  and  $\hat{\nu}_{c,2}$  over 100 replications.

#### APPENDIX

<span id="page-16-2"></span><span id="page-16-1"></span>LEMMA 3. Let  $\theta \in \{1, 2\}$  and  $f_{\theta, \ell}(\cdot)$ ,  $F_{\ell, n}(\cdot)$  be as in (7), (8), respectively. Suppose  $0 < \nu \le M < \ell \le 10$  and Condition 1 holds. Then

$$f_{\theta,\ell}(\nu) = 2\beta_{\nu}^* \theta^{2\nu - 2\ell} n^{2\ell + 1 - 2\nu} H_{\ell}(\nu) \int_0^1 \{\varphi^{(1)}(s)\}^{2\nu - 2\ell} ds + O(n^{2\ell - 2\nu})$$
$$\approx n^{2\ell + 1 - 2\nu}.$$

and hence  $F_{\ell,n}(\nu^*) = 2^{2\nu^* - 2\ell} + O(n^{-1})$  as  $n \to \infty$  uniformly over  $0 \le \nu^* \le M$  where

$$H_{\ell}(\nu) = \sum_{0 \le k_1 < k_2 \le \ell} (-1)^{k_1 + k_2} \binom{\ell}{k_1} \binom{\ell}{k_2} G_{\nu}(k_2 - k_1) \qquad \forall \nu \in (0, M].$$

PROOF. Since  $\varphi$  is twice continuously differentiable, we have  $t_{i+\theta k_2} - t_{i+\theta k_1} = \theta(k_2 - k_1)(n-1)^{-1}\varphi^{(1)}((i-1)/(n-1)) + O(n^{-2})$  as  $n \to \infty$  uniformly over  $1 \le i \le n - \theta \ell$ . It follows from (7) that

$$f_{\theta,\ell}(\nu) = 2\beta_{\nu}^* \theta^{2\nu - 2\ell} n^{2\ell - 2\nu} H_{\ell}(\nu) \sum_{i=1}^{n-\theta\ell} \left\{ \varphi^{(1)} \left( \frac{i-1}{n-1} \right) \right\}^{2\nu - 2\ell} + O(n^{2\ell - 2\nu})$$

$$=2\beta_{\nu}^{*}\theta^{2\nu-2\ell}n^{2\ell+1-2\nu}H_{\ell}(\nu)\int_{0}^{1}\left\{\varphi^{(1)}(s)\right\}^{2\nu-2\ell}ds+O(n^{2\ell-2\nu}),$$

as  $n \to \infty$  uniformly over  $0 < \nu \le M$ . For each  $\ell = 1, ..., 10$ , we use *Mathematica* to plot  $H_{\ell}(\nu)$  to verify that  $H_{\ell}(\nu) \ne 0$  for all  $0 \le \nu \le M$ .  $\square$ 

<span id="page-17-0"></span>LEMMA 4. Let  $f: \mathbb{R} \to \mathbb{R}$  and that for some nonnegative integer m,  $f^{(m+1)}$  is continuous on an open interval containing a and x. Then

$$f(x) = \sum_{j=0}^{m} \frac{f^{(j)}(a)}{j!} (x-a)^j + \frac{1}{m!} \int_a^x (x-t)^m f^{(m+1)}(t) dt.$$

PROOF OF THEOREM 1. Without loss of generality, we shall assume that  $E(X_i) = 0$ .

(a) We observe from (1) that

$$K(x,y) = \sum_{j=0}^{\lfloor \nu \rfloor} \beta_j (x-y)^{2j} + \beta_{\nu}^* G_{\nu}(|x-y|) + r(x,y) \qquad \forall x, y \in \mathbb{R}.$$

Since  $\nu \in (0,\ell)$ ,  $f_{\theta,\ell}(\nu) \approx n^{2\ell+1-2\nu}$  (cf. Lemma 3). As  $r(x,y) = O(|x-y|^{2\nu+\tau})$  for some constant  $\tau > 0$  as  $|x-y| \to 0$ , it follows from Lemma 1 that

$$\sum_{i=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2\} = \sum_{i=1}^{n-\theta\ell} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} K(t_{i+\theta k_1}, t_{i+\theta k_2}) \sim f_{\theta,\ell}(\nu).$$

Hence,  $E(V_{\theta,\ell}) \sim f_{\theta,\ell}(\nu)$ . Similarly, we observe from (5) and Lemma 1 that

$$\sum_{j=i-\theta\ell-1}^{i+\theta\ell+1} |\Sigma_{i,j}| 
= \frac{1}{E(V_{\theta,\ell})} \sum_{j=i-\theta\ell-1}^{i+\theta\ell+1} \left| \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \tilde{K}(t_{i+\theta k_1} - t_{j+\theta k_2}) \right| 
= \frac{O(1)}{E(V_{\theta,\ell})} \sum_{j=i-\theta\ell-1}^{i+\theta\ell+1} \left| \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} G_{\nu}(|t_{i+\theta k_1} - t_{j+\theta k_2}|) \right| 
= O(n^{-1}),$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - \theta \ell$ . Here, for brevity, we write  $\sum_{j=i-\theta \ell-1}^{i+\theta \ell+1} = \sum_{j=(i-\theta \ell-1)\vee 1}^{(i+\theta \ell+1)\wedge (n-\theta \ell)} \text{ since } j \in \{1,\dots,n-\theta \ell\}.$  For  $1 \le i,j \le n-\theta \ell$ ,

we observe from Lemmas 1 and 4 that

$$\Sigma_{i,j} = \frac{1}{E(V_{\theta,\ell})} E \left\{ \left( \sum_{k_1=0}^{\ell} a_{\theta,\ell;i,k_1} X_{i+\theta k_1} \right) \left( \sum_{k_2=0}^{\ell} a_{\theta,\ell;j,k_2} X_{j+\theta k_2} \right) \right\}$$

$$= \frac{1}{E(V_{\theta,\ell})} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \tilde{K}(t_{j+\theta k_2} - t_{i+\theta k_1})$$

$$= \frac{1}{(2\ell-1)! E(V_{\theta,\ell})} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2}$$

$$\times \int_{t_i-t_i}^{t_{j+\theta k_2}-t_{i+\theta k_1}} (t_{j+\theta k_2} - t_{i+\theta k_1} - t)^{2\ell-1} \tilde{K}^{(2\ell)}(t) dt,$$

if the right-hand side exists. Since  $|K^{(2\ell)}(t)| \leq C_{\ell} t^{2\nu-2\ell}$ ,  $t \in (0,1]$ , it follows from Condition 1 that

$$\begin{split} \sum_{j=1}^{i-\theta\ell-2} |\Sigma_{i,j}| &= \frac{1}{(2\ell-1)!E(V_{\theta,\ell})} \sum_{j=1}^{i-\theta\ell-2} \left| \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \right. \\ & \times \int_{t_i-t_j}^{t_{i+\theta k_1}-t_{j+\theta k_2}} (t_{i+\theta k_1} - t_{j+\theta k_2} - t)^{2\ell-1} \tilde{K}^{(2\ell)}(t) \, dt \right| \\ & \leq \frac{O(1)}{E(V_{\theta,\ell})} \sum_{j=1}^{i-\theta\ell-2} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} \left\{ (t_{i+\theta k_1} - t_{j+\theta k_2}) \wedge (t_i - t_j) \right\}^{2\nu-2\ell} \\ & \leq \frac{O(1)}{E(V_{\theta,\ell})} \sum_{j=1}^{i-\theta\ell-2} \left( \frac{i-j-\theta\ell}{n} \right)^{2\nu-2\ell} \\ & \leq \frac{O(n)}{E(V_{\theta,\ell})} \int_{1/n}^{1} t^{2\nu-2\ell} \, dt \\ & = \begin{cases} O(n^{-1}), & \text{if } \nu < (2\ell-1)/2, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (2\ell-1)/2, \\ O(n^{-2\ell+2\nu}), & \text{if } \nu > (2\ell-1)/2, \end{cases} \end{split}$$

as  $n \to \infty$  uniformly over  $\theta \ell + 3 \le i \le n - \theta \ell$ . Similarly,

$$\sum_{j=i+\theta\ell+2}^{n-\theta\ell} |\Sigma_{i,j}| = \begin{cases} O(n^{-1}), & \text{if } \nu < (2\ell-1)/2, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (2\ell-1)/2, \\ O(n^{-2\ell+2\nu}), & \text{if } \nu > (2\ell-1)/2, \end{cases}$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - 2\theta \ell - 2$ . Consequently, it follows from [15] that

<span id="page-19-0"></span>
$$\|\Sigma_{\text{abs}}\|_{2} \leq \max_{1 \leq i \leq n - \theta\ell} \left\{ \sum_{j=1}^{i - \theta\ell - 2} |\Sigma_{i,j}| + \sum_{j=i - \theta\ell - 1}^{i + \theta\ell + 1} |\Sigma_{i,j}| + \sum_{j=i + \theta\ell + 2}^{n - \theta\ell} |\Sigma_{i,j}| \right\}$$

$$= \left\{ O(n^{-1}), & \text{if } \nu < (2\ell - 1)/2, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (2\ell - 1)/2, \\ O(n^{-2\ell + 2\nu}), & \text{if } \nu > (2\ell - 1)/2, \end{array} \right.$$

as  $n \to \infty$ . Next, we observe that

$$\sum_{i=1}^{n-\theta\ell} \Sigma_{i,i}^2 + \sum_{j=1}^{\theta\ell+1} \sum_{i=1}^{n-\theta\ell-j} \Sigma_{i,i+j}^2 + \sum_{j=1}^{\theta\ell+1} \sum_{i=1+j}^{n-\theta\ell} \Sigma_{i,i-j}^2 = O(n^{-1}),$$

and

$$\begin{split} &\sum_{i=\theta\ell+3}^{n-\theta\ell} \sum_{j=1}^{i-\theta\ell-2} \Sigma_{i,j}^2 \\ &\leq \frac{1}{\{(2\ell-1)!E(V_{\theta,\ell})\}^2} \sum_{i=\theta\ell+3}^{n-\theta\ell} \sum_{j=1}^{i-\theta\ell-2} \left\{ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \right. \\ & \times \int_{t_i-t_j}^{t_{i+\theta k_1}-t_{j+\theta k_2}} (t_{i+\theta k_1} - t_{j+\theta k_2} - t)^{2\ell-1} K^{(2\ell)}(t) \, dt \right\}^2 \\ &\leq \frac{O(1)}{\{E(V_{\theta,\ell})\}^2} \sum_{i=\theta\ell+3}^{n-\theta\ell} \sum_{j=1}^{i-\theta\ell-2} \left[ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} \{(t_{i+\theta k_1} - t_{j+\theta k_2}) \wedge (t_i - t_j)\}^{2\nu-2\ell} \right]^2 \\ &\leq \frac{O(1)}{\{E(V_{\theta,\ell})\}^2} \sum_{i=\theta\ell+3}^{n-\theta\ell} \sum_{j=1}^{i-\theta\ell-2} \left( \frac{i-j-\theta\ell}{n} \right)^{4\nu-4\ell} \\ &\leq \frac{O(n)}{\{E(V_{\theta,\ell})\}^2} \sum_{i=\theta\ell+3}^{n-\theta\ell} \int_{1/n}^{1} s^{4\nu-4\ell} \, ds \\ &= \begin{cases} O(n^{-1}), & \text{if } \nu < (4\ell-1)/4, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (4\ell-1)/4, \\ O(n^{-4\ell+4\nu}), & \text{if } \nu > (4\ell-1)/4. \end{cases} \end{split}$$

as  $n \to \infty$ . Hence, we conclude that

<span id="page-20-0"></span>(23) 
$$\|\Sigma_{abs}\|_{F}^{2} = \sum_{i=1}^{n-\theta\ell} \Sigma_{i,i}^{2} + \sum_{j=1}^{\theta\ell+1} \sum_{i=1}^{n-\theta\ell-j} \Sigma_{i,i+j}^{2} + \sum_{j=1}^{\theta\ell+1} \sum_{i=1+j}^{n-\theta\ell} \Sigma_{i,i-j}^{2}$$

$$+ \sum_{i=1}^{n-2\theta\ell-2} \sum_{j=i+\theta\ell+2}^{n-\theta\ell} \Sigma_{i,j}^{2} + \sum_{i=\theta\ell+3}^{n-\theta\ell} \sum_{j=1}^{i-\theta\ell-2} \Sigma_{i,j}^{2},$$

$$= \begin{cases} O(n^{-1}), & \text{if } \nu < (4\ell-1)/4, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (4\ell-1)/4, \\ O(n^{-4\ell+4\nu}), & \text{if } \nu > (4\ell-1)/4, \end{cases}$$

as  $n \to \infty$ . It follows from (6), (23), (23) and the Borel–Cantelli lemma that  $V_{\theta,\ell}/E(V_{\theta,\ell}) \to 1$  as  $n \to \infty$  almost surely. Finally, we observe that for  $i, j = 1, \ldots, n - \theta \ell$ ,

$$\begin{split} E\{(\nabla_{\theta,\ell}X_i)^2(\nabla_{\theta,\ell}X_j)^2\} \\ &= E\{(\nabla_{\theta,\ell}X_i)^2\}E\{(\nabla_{\theta,\ell}X_j)^2\} \\ &+ 2\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2, \\ \sum_{i=1}^{n-\theta\ell}\sum_{j=1}^{n-\theta\ell}\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2 \\ &= \sum_{1\leq i < j\leq n-\theta\ell,j-i\geq \theta\ell+2}\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2 \\ &+ \sum_{1\leq j < i\leq n-\theta\ell,i-j\geq \theta\ell+2}\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2 \\ &+ \sum_{1\leq i,j\leq n-\theta\ell,|i-j|\leq \theta\ell+1}\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2, \\ &\sum_{1\leq i,j\leq n-\theta\ell,|i-j|\leq \theta\ell+1}\bigg\{\sum_{k_1=0}^{\ell}\sum_{k_2=0}^{\ell}a_{\theta,\ell;i,k_1}a_{\theta,\ell;j,k_2}K(t_{i+\theta k_1},t_{j+\theta k_2})\bigg\}^2 \\ &= O(n^{4\ell-4\nu+1}), \end{split}$$

$$\begin{split} &\sum_{1 \leq i < j \leq n - \theta\ell, j - i \geq \theta\ell + 2} \left\{ \sum_{k_1 = 0}^{\ell} \sum_{k_2 = 0}^{\ell} a_{\theta, \ell; i, k_1} a_{\theta, \ell; j, k_2} K(t_{j + \theta k_2}, t_{i + \theta k_1}) \right\}^2 \\ &= \sum_{1 \leq i < j \leq n - \theta\ell, j - i \geq \theta\ell + 2} \left\{ \sum_{k_1 = 0}^{\ell} \sum_{k_2 = 0}^{\ell} a_{\theta, \ell; i, k_1} a_{\theta, \ell; j, k_2} \right. \\ &\times \frac{1}{(2\ell - 1)!} \int_{t_j - t_i}^{t_{j + \theta k_2} - t_{i + \theta k_1}} (t_{j + \theta k_2} - t_{i + \theta k_1} - t)^{2\ell - 1} \tilde{K}^{(2\ell)}(t) dt \right\}^2 \\ &= O(1) \sum_{1 \leq i < j \leq n - \theta\ell, j - i \geq \theta\ell + 2} \left( \frac{j - i - \theta\ell}{n} \right)^{4\nu - 4\ell} \\ &\leq O(n^2) \int_{1/n}^{1} s^{4\nu - 4\ell} ds \\ &= \begin{cases} O(n^{2\ell - 4\nu + 1}), & \text{if } \nu < (4\ell - 1)/4, \\ O(n^2), & \text{if } \nu > (4\ell - 1)/4, \\ O(n^2), & \text{if } \nu > (4\ell - 1)/4, \end{cases} \end{split}$$

as  $n \to \infty$ . Thus, we conclude that

$$\frac{E(V_{\theta,\ell}^2) - \{E(V_{\theta,\ell})\}^2}{\{E(V_{\theta,\ell})\}^2} = \begin{cases} O(n^{-1}), & \text{if } \nu < (4\ell - 1)/4, \\ O\{n^{-1}\log(n)\}, & \text{if } \nu = (4\ell - 1)/4, \\ O(n^{-4\ell + 4\nu}), & \text{if } \nu > (4\ell - 1)/4, \end{cases}$$

as  $n \to \infty$ .

(b) Suppose  $\nu = \ell$ . It follows from Lemma 1 that

$$\sum_{i=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2\}$$

$$= \beta_{\ell}^* \sum_{i=1}^{n-\theta\ell} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2}$$

$$\times (t_{i+\theta k_2} - t_{i+\theta k_1})^{2\ell} \log(|t_{i+\theta k_2} - t_{i+\theta k_1}|) \{1 + o(1)\}$$

$$= -\beta_{\ell}^* \sum_{i=1}^{n-\theta\ell} \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} (t_{i+\theta k_2} - t_{i+\theta k_1})^{2\ell} \log(n) \{1 + o(1)\}$$

$$\sim (-1)^{\ell+1} \beta_{\ell}^* (2\ell)! n \log(n).$$

Next, we observe as in (a) that

$$\sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2 (\nabla_{\theta,\ell} X_j)^2\}$$

$$= \sum_{i=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2\} \sum_{j=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_j)^2\}$$

$$+ 2 \sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left\{ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \tilde{K}(t_{i+\theta k_1} - t_{j+\theta k_2}) \right\}^2$$

$$= \sum_{i=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2\} \sum_{j=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_j)^2\} + O(n^2),$$

as  $n \to \infty$ . Consequently, we conclude that  $\operatorname{Var}\{V_{\theta,\ell}/E(V_{\theta,\ell})\} = O\{\log^{-2}(n)\}$  as  $n \to \infty$ .

(c) Suppose  $\nu > \ell$ . Again using Lemma 1, we have

$$\sum_{i=1}^{n-\theta\ell} E\{(\nabla_{\theta,\ell} X_i)^2\} \sim 2\beta_{\ell} \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le \ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} (t_{i+\theta k_1} - t_{i+\theta k_2})^{2\ell}$$
$$= (-1)^{\ell} \beta_{\ell} (2\ell)! (n - \theta\ell).$$

We observe from Lemmas 1 and 4 that

$$\begin{split} &\sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left\{ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{l} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \tilde{K}(t_{i+\theta k_1} - t_{j+\theta k_2}) \right\}^2 \\ &= \sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left[ \frac{\tilde{K}^{(2\ell)}(t_i - t_j)}{(2\ell - 1)!} \right] \\ &\times \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{l} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \int_{0}^{t_{i+\theta k_1} - t_{j+\theta k_2} - t_i + t_j} t^{2\ell - 1} dt \\ &+ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{l} \frac{a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2}}{(2\ell - 1)!} \\ &\times \int_{t_i - t_j}^{t_{i+\theta k_1} - t_{j+\theta k_2}} (t_{i+\theta k_1} - t_{j+\theta k_2} - t)^{2\ell - 1} \{\tilde{K}^{(2\ell)}(t) - \tilde{K}^{(2\ell)}(t_i - t_j)\} dt \right]^2 \end{split}$$

$$= \sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left[ \frac{\tilde{K}^{(2\ell)}(t_i - t_j)}{(2\ell)!} \right]$$

$$\times \left\{ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} (t_{i+\theta k_1} - t_{j+\theta k_2} - t_i + t_j)^{2\ell} \right\} + o(1) \right]^2$$

$$= \sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left[ \left\{ (-1)^{\ell} \tilde{K}^{(2\ell)}(t_i - t_j) \right\}^2 + o(1) \right] > cn^2,$$

for some constant c>0 since  $\tilde{K}^{(2\ell)}(\cdot)$  is a continuous and not identically 0 function on (0,1]. Consequently,  $\liminf_{n\to\infty} \mathrm{Var}\{V_{\theta,\ell}/E(V_{\theta,\ell})\}$  equals

$$\liminf_{n \to \infty} \frac{2}{\{E(V_{\theta,\ell})\}^2} \sum_{i=1}^{n-\theta\ell} \sum_{j=1}^{n-\theta\ell} \left\{ \sum_{k_1=0}^{\ell} \sum_{k_2=0}^{\ell} a_{\theta,\ell;i,k_1} a_{\theta,\ell;j,k_2} \tilde{K}(t_{i+\theta k_1} - t_{j+\theta k_2}) \right\}^2 > 0.$$

This proves Theorem 1.  $\square$ 

<span id="page-23-0"></span>LEMMA 5. Let p > 0 be an integer and  $f_{\theta,\ell}(\cdot)$ ,  $\tilde{f}_{\theta,2}(\cdot)$ ,  $\bar{f}_{\theta,\ell}(\cdot)$  be as in (7), (14), (20), respectively. Then

<span id="page-23-1"></span>(24) 
$$\lim_{\nu^* \to p} \frac{f_{2,\ell}(\nu^*)}{f_{1,\ell}(\nu^*)} = \frac{f_{2,\ell}(p)}{f_{1,\ell}(p)} \qquad \forall \ell > p,$$

$$\lim_{\nu^* \to 1} \frac{\tilde{f}_{2,2}(\nu^*)}{\tilde{f}_{1,2}(\nu^*)} = \frac{\tilde{f}_{2,2}(1)}{\tilde{f}_{1,2}(1)},$$

$$\lim_{\nu^* \to 1} \frac{\bar{f}_{2,\ell}(\nu^*)}{\bar{f}_{1,\ell}(\nu^*)} = \frac{\bar{f}_{2,\ell}(1)}{\bar{f}_{1,\ell}(1)} \qquad \forall \ell \in \{1,2\}.$$

PROOF. Writing  $\nu^* = p + \delta$ , we observe from Lemma 1 that for  $\theta \in \{1, 2\}$ ,

$$\lim_{\delta \to 0} \frac{1}{2\delta} \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le l} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} |t_{i+\theta k_2} - t_{i+\theta k_1}|^{2\nu^*}$$

$$= \lim_{\delta \to 0} \frac{1}{2\delta} \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le l} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} (t_{i+\theta k_2} - t_{i+\theta k_1})^{2p}$$

$$\times \{ e^{2\delta \log(t_{i+\theta k_2} - t_{i+\theta k_1})} - 1 \}$$

$$= \sum_{i=1}^{n-\theta\ell} \sum_{0 \le k_1 < k_2 \le l} a_{\theta,\ell;i,k_1} a_{\theta,\ell;i,k_2} (t_{i+\theta k_2} - t_{i+\theta k_1})^{2p} \log(t_{i+\theta k_2} - t_{i+\theta k_1})$$

and the first statement in (24) follows from the definition of  $f_{\theta,\ell}(\cdot)$ . The proof of the second statement in (24) is similar. Next, writing  $\nu^* = 1 + \delta$  with  $\delta \neq 0$ , we have

$$\lim_{\delta \to 0} \frac{1}{2\delta} \sum_{1 \le i_1, i_2 \le n - \theta} \sum_{0 \le k_1, l_1, k_2, l_2 \le 1: (k_1, k_2) \ne (l_1, l_2)} c_{\theta, \ell; i_1, i_2}^{k_1, k_2} c_{\theta, \ell; i_1, i_2}^{l_1, l_2} \\
\times \|\mathbf{x}^{i_1 + \theta k_1, i_2 + \theta k_2} - \mathbf{x}^{i_1 + \theta l_1, i_2 + \theta l_2}\|^{2 + 2\delta} \\
= \lim_{\delta \to 0} \frac{1}{2\delta} \sum_{1 \le i_1, i_2 \le n - \theta} \sum_{0 \le k_1, l_1, k_2, l_2 \le 1: (k_1, k_2) \ne (l_1, l_2)} c_{\theta, \ell; i_1, i_2}^{k_1, k_2} c_{\theta, \ell; i_1, i_2}^{l_1, l_2} \\
\times \|\mathbf{x}^{i_1 + \theta k_1, i_2 + \theta k_2} - \mathbf{x}^{i_1 + \theta l_1, i_2 + \theta l_2}\|^2 \\
\times \{e^{2\delta \log(\|\mathbf{x}^{i_1 + \theta k_1, i_2 + \theta k_2} - \mathbf{x}^{i_1 + \theta l_1, i_2 + \theta l_2}\|) - 1\} \\
= \sum_{1 \le i_1, i_2 \le n - \theta} \sum_{0 \le k_1, l_1, k_2, l_2 \le 1: (k_1, k_2) \ne (l_1, l_2)} c_{\theta, \ell; i_1, i_2}^{k_1, k_2} c_{\theta, \ell; i_1, i_2}^{l_1, l_2} \\
\times \|\mathbf{x}^{i_1 + \theta k_1, i_2 + \theta k_2} - \mathbf{x}^{i_1 + \theta l_1, i_2 + \theta l_2}\|^2 \\
\times \log(n \|\mathbf{x}^{i_1 + \theta k_1, i_2 + \theta k_2} - \mathbf{x}^{i_1 + \theta l_1, i_2 + \theta l_2}\|).$$

The third statement in (24) now follows from the definition of  $\bar{f}_{\theta,\ell}(\cdot)$ .

PROOF OF THEOREM 2. We observe from Lemma 3 that  $F_{\ell,n}(\nu^*) \to 2^{2\nu^*-2\ell}$  as  $n \to \infty$  uniformly over  $\nu^* \in [0,M]$ . Suppose with probability 1,  $\hat{\nu}_{a,\ell} \to \nu_a \neq \nu$  along a subsequence  $n_i$  of n. Then

$$\left\{ \frac{V_{1,\ell} F_{\ell,n_i}(\hat{\nu}_{a,\ell})}{V_{2,\ell}} - 1 \right\}^2 = \left\{ (1 + o(1)) \frac{F_{\ell,n_i}(\hat{\nu}_{a,\ell})}{F_{\ell,n_i}(\nu)} - 1 \right\}^2 \to \left\{ 2^{2(\nu_a - \nu)} - 1 \right\}^2 > 0,$$

as  $n_i \to \infty$  almost surely. This implies that for sufficiently large  $n_i$ ,

$$\left\{ \frac{V_{1,\ell} F_{\ell,n_i}(\hat{\nu}_{a,\ell})}{V_{2,\ell}} - 1 \right\}^2 > \frac{1}{2} \left\{ 2^{2(\nu_a - \nu)} - 1 \right\}^2 > \left\{ \frac{V_{1,\ell} F_{\ell,n_i}(\nu)}{V_{2,\ell}} - 1 \right\}^2$$

almost surely. This contradicts the definition of  $\hat{\nu}_{a,\ell}$ .  $\square$ 

<span id="page-24-0"></span>Lemma 6. Let  $M \ge 1$  be an arbitrary but fixed integer. Suppose Conditions 2 and 4 hold. Then

$$d_{i+k_1,i+k_2} = d_{i,i+k_2} - d_{i,i+k_1} + O(n^{-3}),$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - k_2$  and  $0 \le k_1 \le k_2 \le M$ .

PROOF. For each  $t \in [0, L]$ , we consider a set of local coordinates of  $\mathbb{R}^2$  in a neighbourhood of the point  $\gamma(t)$  where the origin (0,0) of the local coordinates is the point  $\gamma(t)$  and the x-axis of the local coordinates corresponds to

the tangent to the curve  $\gamma$  at  $\gamma(t)$ . In particular, the vector  $\gamma^{(1)}(t)$  becomes (1,0)'. Since  $\gamma$  is a  $C^2$ -curve, we observe that there exists a constant  $\delta>0$  (independent of t), such that under the local coordinates,  $\gamma$  in a neighbourhood of  $\gamma(t)$  can be represented as  $y_t(x)=y_t(0)+y_t^{(1)}(0)x+O(x^2)=O(x^2)$   $\forall 0 \leq x \leq \delta$  uniformly in  $t \in [0,L]$ . Consequently taking  $t=t_i$  and writing  $(x_{i+k},y_{t_i}(x_{i+k}))$  for the point  $\gamma(t_{i+k})$  in the local coordinates, we obtain  $x_i=0=y_{t_i}(0)=y_{t_i}^{(1)}(0)$  and

$$d_{i+k_1,i+k_2} = \sqrt{(x_{i+k_2} - x_{i+k_1})^2 + \{(y_{t_i}(x_{i+k_2}) - y_{t_i}(x_{i+k_1})\}^2}$$

$$= (x_{i+k_2} - x_{i+k_1})\{1 + O(n^{-2})\}$$

$$= d_{i,i+k_2} - d_{i,i+k_1} + O(n^{-3}),$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - k_2$  and  $0 \le k_1 \le k_2 \le M$ .  $\square$ 

<span id="page-25-0"></span>LEMMA 7. Let  $\theta, \ell \in \{1, 2\}$ ,  $\tilde{f}_{\theta, \ell}(\cdot)$  be as in (14) and  $H_{\ell}(\cdot)$  be as in Lemma 3. Suppose Conditions 2, 3 and 4 hold. Then for  $\nu \in (0, \ell)$ ,

$$\tilde{f}_{\theta,\ell}(\nu) = \frac{2\beta_{\nu}^* n^{2\ell+1-2\nu} H_{\ell}(\nu)}{\theta^{2\ell-2\nu} L^{2\ell+1-2\nu}} \int_0^L \|(\gamma \circ \varphi)^{(1)}(t)\|^{2\nu-2\ell} dt + O(n^{2\ell-2\nu}),$$

and hence  $\tilde{F}_{\ell,n}(\nu^*) = 2^{2\nu^*-2\ell} + O(n^{-1})$  as  $n \to \infty$  uniformly over  $0 \le \nu^* \le \ell$  where  $\tilde{F}_{\ell,n}(\cdot)$  is as in (15).

PROOF. We observe that for  $0 \le k \le 4$ .

$$d_{i,i+k} = \left[ \left\{ \gamma_1 \circ \varphi \left( \frac{L(i+k-1)}{n-1} \right) - \gamma_1 \circ \varphi \left( \frac{L(i-1)}{n-1} \right) \right\}^2 + \left\{ \gamma_2 \circ \varphi \left( \frac{L(i+k-1)}{n-1} \right) - \gamma_2 \circ \varphi \left( \frac{L(i-1)}{n-1} \right) \right\}^2 \right]^{1/2}$$
$$= \frac{kL}{n-1} \left\| (\gamma \circ \varphi)^{(1)} \left( \frac{L(i-1)}{n-1} \right) \right\| + O(n^{-2}),$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - k$ . For  $\theta \in \{1, 2\}$  and  $\nu \in (0, 1)$ ,

$$\sum_{i=1}^{n-\theta} b_{\theta,1;i,0} b_{\theta,1;i,1} d_{i,i+\theta}^{2\nu}$$

$$= -\sum_{i=1}^{n-\theta} \left( \frac{\theta L}{n-1} \right)^{2\nu-2} \left\| (\gamma \circ \varphi)^{(1)} \left( \frac{L(i-1)}{n-1} \right) \right\|^{2\nu-2} + O(n^{2-2\nu})$$

$$= -\theta^{2\nu-2} L^{2\nu-3} n^{3-2\nu} \int_0^L \left\| (\gamma \circ \varphi)^{(1)} (t) \right\|^{2\nu-2} dt + O(n^{2-2\nu}),$$

as  $n \to \infty$ . We observe from Lemma 6 that for  $\theta \in \{1, 2\}$  and  $\nu \in (0, 2) \setminus \{1\}$ ,

$$\begin{split} \sum_{0 \leq k_1 < k_2 \leq 2} b_{\theta,2;i,k_1} b_{\theta,2;i,k_2} d_{i+\theta k_1,i+\theta k_2}^{2\nu} \\ &= -\frac{4 d_{i,i+\theta}^{2\nu-2}}{d_{i,i+2\theta} (d_{i,i+2\theta} - d_{i,i+\theta})} + \frac{4 d_{i,i+2\theta}^{2\nu-2}}{d_{i,i+\theta} (d_{i,i+2\theta} - d_{i,i+\theta})} \\ &\quad - \frac{4 \{d_{i,i+2\theta} - d_{i,i+\theta} + O(n^{-3})\}^{2\nu}}{d_{i,i+\theta} d_{i,i+2\theta} (d_{i,i+2\theta} - d_{i,i+\theta})^2} \\ &= -2 \left(\frac{\theta L}{n-1}\right)^{2\nu-4} \left\| (\gamma \circ \varphi)^{(1)} \left(\frac{L(i-1)}{n-1}\right) \right\|^{2\nu-4} \\ &\quad + 2^{2\nu} \left(\frac{\theta L}{n-1}\right)^{2\nu-4} \left\| (\gamma \circ \varphi)^{(1)} \left(\frac{L(i-1)}{n-1}\right) \right\|^{2\nu-4} \\ &\quad - 2 \left(\frac{\theta L}{n-1}\right)^{2\nu-4} \left\| (\gamma \circ \varphi)^{(1)} \left(\frac{L(i-1)}{n-1}\right) \right\|^{2\nu-4} + O(n^{3-2\nu}) \\ &= (2^{2\nu} - 4) \left(\frac{\theta L}{n-1}\right)^{2\nu-4} \left\| (\gamma \circ \varphi)^{(1)} \left(\frac{L(i-1)}{n-1}\right) \right\|^{2\nu-4} + O(n^{3-2\nu}), \end{split}$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - 2\theta$ . Consequently,

$$\sum_{i=1}^{n-2\theta} \sum_{0 \le k_1 < k_2 \le 2} b_{\theta,2;i,k_1} b_{\theta,2;i,k_2} d_{i+\theta k_1,i+\theta k_2}^{2\nu}$$

$$= (2^{2\nu} - 4) \left( \frac{\theta L}{n-1} \right)^{2\nu - 4} \sum_{i=1}^{n-2\theta} \left\| (\gamma \circ \varphi)^{(1)} \left( \frac{L(i-1)}{n-1} \right) \right\|^{2\nu - 4} + O(n^{4-2\nu})$$

$$= (2^{2\nu} - 4) \theta^{2\nu - 4} L^{2\nu - 5} n^{5-2\nu} \int_0^L \left\| (\gamma \circ \varphi)^{(1)} (t) \right\|^{2\nu - 4} dt + O(n^{4-2\nu})$$

as  $n \to \infty$ . We observe from Lemma 6 that for  $\theta \in \{1, 2\}$ ,

$$\sum_{0 \le k_1 < k_2 \le 2} b_{\theta,2;i,k_1} b_{\theta,2;i,k_2} d_{i+\theta k_1,i+\theta k_2}^2 \log(d_{i+\theta k_1,i+\theta k_2})$$

$$= \frac{4d_{i,i+\theta}^2 \log(d_{i,i+\theta})}{(-d_{i,i+\theta})(-d_{i,i+2\theta})d_{i,i+\theta}(d_{i,i+\theta} - d_{i,i+2\theta})}$$

$$+ \frac{4d_{i,i+2\theta}^2 \log(d_{i,i+2\theta})}{(-d_{i,i+\theta})(-d_{i,i+2\theta})d_{i,i+2\theta}(d_{i,i+2\theta} - d_{i,i+\theta})}$$

$$+ \frac{4\{d_{i,i+2\theta} - d_{i,i+\theta} + O(n^{-3})\}^2 \log\{|d_{i,i+2\theta} - d_{i,i+\theta}| + O(n^{-3})\}}{d_{i,i+\theta}(d_{i,i+\theta} - d_{i,i+2\theta})d_{i,i+2\theta}(d_{i,i+2\theta} - d_{i,i+\theta})}$$

$$= \frac{4}{d_{i,i+\theta}^2} \left\{ \left( \frac{d_{i,i+2\theta}}{d_{i,i+\theta}} - 1 \right)^{-1} \log \left( \frac{d_{i,i+2\theta}}{d_{i,i+\theta}} \right) - \frac{d_{i,i+\theta}}{d_{i,i+2\theta}} \log \left( \left| \frac{d_{i,i+2\theta}}{d_{i,i+\theta}} - 1 \right| \right) \right\} + O\{\log(n)\}$$

$$= \frac{4 \log(2)n^2}{\theta^2 L^2} \left\| (\gamma \circ \varphi)^{(1)} \left( \frac{L(i-1)}{n-1} \right) \right\|^{-2} + O(n),$$

as  $n \to \infty$  uniformly over  $1 \le i \le n - 2\theta$ . Consequently,

$$\sum_{i=1}^{n-2\theta} \sum_{0 \le k_1 < k_2 \le 2} b_{\theta,2;i,k_1} b_{\theta,2;i,k_2} d_{i+\theta k_1,i+\theta k_2}^2 \log(d_{i+\theta k_1,i+\theta k_2})$$

$$= \frac{4 \log(2) n^2}{\theta^2 L^2} \sum_{i=1}^{n-2\theta} \left\| (\gamma \circ \varphi)^{(1)} \left( \frac{L(i-1)}{n-1} \right) \right\|^{-2} + O(n^2)$$

$$= \frac{4 \log(2) n^3}{\theta^2 L^3} \int_0^L \left\| (\gamma \circ \varphi)^{(1)} (t) \right\|^{-2} dt + O(n^2),$$

as  $n \to \infty$ . This proves the lemma.  $\square$ 

PROOF OF LEMMA 2. We shall prove the case  $\ell = 1$ . The proof for the case  $\ell = 2$  is similar and is omitted. We observe from (16) and (17) that for  $\theta \in \{1,2\}$ ,

$$\begin{split} \alpha_{\theta;i_1,i_2}^{1,1}(x_1^{i_1+\theta,i_2}-x_1^{i_1,i_2}) + \alpha_{\theta;i_1,i_2}^{1,2}(x_1^{i_1,i_2+\theta}-x_1^{i_1,i_2}) &= 1, \\ \alpha_{\theta;i_1,i_2}^{1,1}(x_2^{i_1+\theta,i_2}-x_2^{i_1,i_2}) + \alpha_{\theta;i_1,i_2}^{1,2}(x_2^{i_1,i_2+\theta}-x_2^{i_1,i_2}) &= 0, \\ \beta_{\theta;i_1,i_2}^{1,1}(x_1^{i_1+\theta,i_2}-x_1^{i_1+\theta,i_2+\theta}) + \beta_{\theta;i_1,i_2}^{1,2}(x_1^{i_1,i_2+\theta}-x_1^{i_1+\theta,i_2+\theta}) &= 1, \\ \beta_{\theta;i_1,i_2}^{1,1}(x_2^{i_1+\theta,i_2}-x_2^{i_1+\theta,i_2+\theta}) + \beta_{\theta;i_1,i_2}^{1,2}(x_2^{i_1,i_2+\theta}-x_2^{i_1+\theta,i_2+\theta}) &= 0. \end{split}$$

Lemma 2 is a consequence of (18) and the above four equalities.  $\square$ 

<span id="page-27-0"></span>LEMMA 8. For  $0 < \nu < 2$  and  $\ell \in \{1, 2\}$ , define  $\mathcal{J}_{\nu,\ell} : [0, 1]^2 \to \mathbb{R}$  by

$$\mathcal{J}_{\nu,\ell}(u,v) = \frac{\{\varphi_{\ell^c}^{(0,1)}(u,v) - \varphi_{\ell^c}^{(1,0)}(u,v)\}^2}{\{\varphi_1^{(1,0)}(u,v)\varphi_2^{(0,1)}(u,v) - \varphi_1^{(0,1)}(u,v)\varphi_2^{(1,0)}(u,v)\}^2} \times \left\{ -2G_{\nu} \left( \left[ \sum_{j=1}^2 \varphi_j^{(0,1)}(u,v)^2 \right]^{1/2} \right) - 2G_{\nu} \left( \left[ \sum_{j=1}^2 \varphi_j^{(1,0)}(u,v)^2 \right]^{1/2} \right) \right\} \right\}$$

$$+ G_{\nu} \left( \left[ \sum_{j=1}^{2} \left\{ \varphi_{j}^{(1,0)}(u,v) + \varphi_{j}^{(0,1)}(u,v) \right\}^{2} \right]^{1/2} \right)$$

$$+ G_{\nu} \left( \left[ \sum_{j=1}^{2} \left\{ \varphi_{j}^{(0,1)}(u,v) - \varphi_{j}^{(1,0)}(u,v) \right\}^{2} \right]^{1/2} \right) \right\},$$

where  $\ell^c = 2$  if  $\ell = 1$  and  $\ell^c = 1$  if  $\ell = 2$ . Then  $\min_{0 \le u,v \le 1} \mathcal{J}_{\nu,\ell}(u,v) \ge 0$  if  $\nu \in [1,2)$ , and  $\max_{0 < u,v < 1} \mathcal{J}_{\nu,\ell}(u,v) \le 0$  if  $\nu \in (0,1)$ .

<span id="page-28-6"></span>LEMMA 9. Let  $\theta, \ell \in \{1, 2\}$  and  $\bar{f}_{\theta,\ell}(\cdot), \bar{F}_{n,\ell}(\cdot)$ , be as in (20), (21), respectively. Suppose Condition 5 holds and that  $\mathcal{J}_{\nu,\ell}(\cdot,\cdot)$ , as in Lemma 8, is not identically 0 on  $[0,1]^2$ . Then

$$\bar{f}_{\theta,\ell}(\nu) = 2\beta_{\nu}^* \theta^{2\nu - 2} n^{4 - 2\nu} \int_0^1 \int_0^1 \mathcal{J}_{\nu,\ell}(u,v) \, du \, dv + O(n^{3 - 2\nu}),$$

and hence  $\bar{F}_{n,\ell}(\nu^*) = 2^{2\nu^*-2} + O(n^{-1})$  as  $n \to \infty$  uniformly over  $0 \le \nu^* \le 2$ .

We refer the reader to [23] for the proofs of Lemmas 8 and 9.

**Acknowledgements.** I would like to thank Professor Runze Li, an Associate Editor and four referees for their comments and suggestions that led to numerous improvements in the initial results of this article.

#### SUPPLEMENTARY MATERIAL

**Proofs and other technical details** (DOI: 10.1214/15-AOS1365SUPP; .pdf). The supplemental article [23] contains the proofs of Theorems 3, 5, 6, Lemmas 8, 9 and Corollary 1.

## REFERENCES

- <span id="page-28-1"></span> ADLER, R. J. and PYKE, R. (1993). Uniform quadratic variation for Gaussian processes. Stochastic Process. Appl. 48 191–209. MR1244542
- <span id="page-28-5"></span>[2] Anderes, E. and Chatterjee, S. (2009). Consistent estimates of deformed isotropic Gaussian random fields on the plane. *Ann. Statist.* **37** 2324–2350. MR2543694
- <span id="page-28-0"></span>[3] Anderes, E. B. and Stein, M. L. (2008). Estimating deformations of isotropic Gaussian random fields on the plane. *Ann. Statist.* **36** 719–741. MR2396813
- <span id="page-28-4"></span>[4] Begyn, A. (2005). Quadratic variations along irregular subdivisions for Gaussian processes. *Electron. J. Probab.* 10 691–717 (electronic). MR2164027
- <span id="page-28-2"></span>[5] Benassi, A., Cohen, S., Istas, J. and Jaffard, S. (1998). Identification of filtered white noises. Stochastic Process. Appl. 75 31–49. MR1629014
- <span id="page-28-3"></span>[6] Chan, G. and Wood, A. T. A. (2000). Increment-based estimators of fractal dimension for two-dimensional surface data. Statist. Sinica 10 343–376. MR1769748

- <span id="page-29-0"></span>[7] Chil`es, J.-P. and Delfiner, P. (1999). *Geostatistics. Modeling Spatial Uncertainty*. Wiley, New York. [MR1679557](http://www.ams.org/mathscinet-getitem?mr=1679557)
- <span id="page-29-10"></span>[8] Cohen, S., Guyon, X., Perrin, O. and Pontier, M. (2006). Singularity functions for fractional processes: Application to the fractional Brownian sheet. *Ann. Inst. Henri Poincar´e Probab. Stat.* 42 187–205. [MR2199797](http://www.ams.org/mathscinet-getitem?mr=2199797)
- <span id="page-29-6"></span>[9] Constantine, A. G. and Hall, P. (1994). Characterizing surface smoothness via estimation of effective fractal dimension. *J. Roy. Statist. Soc. Ser. B* 56 97–113. [MR1257799](http://www.ams.org/mathscinet-getitem?mr=1257799)
- <span id="page-29-1"></span>[10] Cressie, N. A. C. (1991). *Statistics for Spatial Data*. Wiley, New York. [MR1127423](http://www.ams.org/mathscinet-getitem?mr=1127423)
- <span id="page-29-19"></span>[11] Grenander, U. and Miller, M. I. (2007). *Pattern Theory: From Representation to Inference*. Oxford Univ. Press, Oxford. [MR2285439](http://www.ams.org/mathscinet-getitem?mr=2285439)
- <span id="page-29-11"></span>[12] Guyon, X. and Leon, J. ´ (1989). Convergence en loi des H-variations d'un processus gaussien stationnaire sur R. *Ann. Inst. Henri Poincar´e Probab. Stat.* 25 265–282. [MR1023952](http://www.ams.org/mathscinet-getitem?mr=1023952)
- <span id="page-29-5"></span>[13] Hall, P. and Wood, A. (1993). On the performance of box-counting estimators of fractal dimension. *Biometrika* 80 246–252. [MR1225230](http://www.ams.org/mathscinet-getitem?mr=1225230)
- <span id="page-29-16"></span>[14] Hanson, D. L. and Wright, F. T. (1971). A bound on tail probabilities for quadratic forms in independent random variables. *Ann. Math. Statist.* 42 1079– 1083. [MR0279864](http://www.ams.org/mathscinet-getitem?mr=0279864)
- <span id="page-29-21"></span>[15] Horn, R. A. and Johnson, C. R. (1985). *Matrix Analysis*. Cambridge Univ. Press, Cambridge. [MR0832183](http://www.ams.org/mathscinet-getitem?mr=0832183)
- <span id="page-29-4"></span>[16] Im, H. K., Stein, M. L. and Zhu, Z. (2007). Semiparametric estimation of spectral density with irregular observations. *J. Amer. Statist. Assoc.* 102 726–735. [MR2381049](http://www.ams.org/mathscinet-getitem?mr=2381049)
- <span id="page-29-8"></span>[17] Istas, J. and Lang, G. (1997). Quadratic variations and estimation of the local H¨older index of a Gaussian process. *Ann. Inst. Henri Poincar´e Probab. Stat.* 33 407–436. [MR1465796](http://www.ams.org/mathscinet-getitem?mr=1465796)
- <span id="page-29-20"></span>[18] Joshi, S. C. and Miller, M. I. (2000). Landmark matching via large deformation diffeomorphisms. *IEEE Trans. Image Process.* 9 1357–1370. [MR1808275](http://www.ams.org/mathscinet-getitem?mr=1808275)
- <span id="page-29-7"></span>[19] Kent, J. T. and Wood, A. T. A. (1997). Estimating the fractal dimension of a locally self-similar Gaussian process by using increments. *J. Roy. Statist. Soc. Ser. B* 59 679–699. [MR1452033](http://www.ams.org/mathscinet-getitem?mr=1452033)
- <span id="page-29-12"></span>[20] Klein, R. and Gin´e, E. (1975). On quadratic variation of processes with Gaussian increments. *Ann. Probab.* 3 716–721. [MR0378070](http://www.ams.org/mathscinet-getitem?mr=0378070)
- <span id="page-29-15"></span>[21] Knuth, D. E. (1997). *The Art of Computer Programming*, 3rd ed. *Fundamental Algorithms* 1. Addison-Wesley, Reading, MA. [MR3077152](http://www.ams.org/mathscinet-getitem?mr=3077152)
- <span id="page-29-9"></span>[22] L´evy, P. (1940). Le mouvement brownien plan. *Amer. J. Math.* 62 487–550. [MR0002734](http://www.ams.org/mathscinet-getitem?mr=0002734)
- <span id="page-29-13"></span>[23] Loh, W.-L. (2015). Supplement to "Estimating the smoothness of a Gaussian random field from irregularly spaced data via higher-order quadratic variations". DOI[:10.1214/15-AOS1365SUPP.](http://dx.doi.org/10.1214/15-AOS1365SUPP)
- <span id="page-29-3"></span>[24] Matheron, G. (1971). *The Theory of Regionalized Variables and Its Applications*. Ecole des Mines, Fontainebleau.
- <span id="page-29-2"></span>[25] Stein, M. L. (1999). *Interpolation of Spatial Data: Some Theory for Kriging*. Springer, New York. [MR1697409](http://www.ams.org/mathscinet-getitem?mr=1697409)
- <span id="page-29-17"></span>[26] Stein, M. L. (2012). Simulation of Gaussian random fields with one derivative. *J. Comput. Graph. Statist.* 21 155–173. [MR2913361](http://www.ams.org/mathscinet-getitem?mr=2913361)
- <span id="page-29-14"></span>[27] Sylvester, J. J. (1857). On the partition of numbers. *Quart. J. Math.* 1 141–152.
- <span id="page-29-18"></span>[28] Wood, A. T. A. and Chan, G. (1994). Simulation of stationary Gaussian processes in [0, 1]<sup>d</sup> . *J. Comput. Graph. Statist.* 3 409–432. [MR1323050](http://www.ams.org/mathscinet-getitem?mr=1323050)

Department of Statistics and Applied Probability National University of Singapore

Singapore 117546 Republic of Singapore E-mail: [stalohwl@nus.edu.sg](mailto:stalohwl@nus.edu.sg)