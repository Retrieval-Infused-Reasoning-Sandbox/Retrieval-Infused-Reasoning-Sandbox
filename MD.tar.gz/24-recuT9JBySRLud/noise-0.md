# ON IDENTIFIABILITY AND CONSISTENCY OF THE NUGGET IN GAUSSIAN SPATIAL PROCESS MODELS

WENPIN TANG, LU ZHANG, AND SUDIPTO BANERJEE

ABSTRACT. Spatial process models popular in geostatistics often represent the observed data as the sum of a smooth underlying process and white noise. The variation in the white noise is attributed to measurement error, or micro-scale variability, and is called the "nugget". We formally establish results on the identifiability and consistency of the nugget in spatial models based upon the Gaussian process within the framework of in-fill asymptotics, i.e. the sample size increases within a sampling domain that is bounded. Our work extends results in fixed domain asymptotics for spatial models without the nugget. More specifically, we establish the identifiability of parameters in the Matérn covariogram and the consistency of their maximum likelihood estimators in the presence of discontinuities due to the nugget. We also present simulation studies to demonstrate the role of the identifiable quantities in spatial interpolation.

**Keywords.** Asymptotic normality; consistency; interpolation; Matérn covariogram; nugget; spatial statistics.

#### <span id="page-0-0"></span>1. Introduction

The analysis of point-referenced spatial data relies heavily on stationary Gaussian processes for modelling spatial dependence. Let y(s) be the outcome measured at a location  $s \in \mathcal{S} \subset \mathbb{R}^d$ , where  $\mathcal{S}$  is a bounded region within  $\mathbb{R}^d$ . The outcome is customarily modelled as

(1) 
$$y(s) = \mu(s) + w(s) + \epsilon(s), \quad s \in S \subset \mathbb{R}^d,$$

where  $\mu(s)$  models the trend, w(s) is a Gaussian process capturing spatial dependence, and  $\epsilon(s)$  is a white noise process modelling measurement error or micro-scale variation. Matérn [1986] introduced a flexible class of covariance functions for modelling w(s) that has been widely used in spatial modelling ever since it was recommended in Stein [1999]. The finite dimensional realizations of  $\epsilon(s)$  are modelled independently and identically as  $N(0, \tau^2)$  over any finite collection of locations. The variance parameter  $\tau^2$  is called the "nugget".

Our intended contribution in this article is to formally establish the identifiability and consistency of the process parameters in (1) in the presence of an unknown nugget under infill or fixed domain asymptotics, where the sample size increases with increasing numbers of locations within a domain that is fixed and does not expand. This distinguishes the article from existing results on inference for process parameters in Matérn models that have, almost exclusively, been studied without the presence of an unknown nugget. Zhang and Zimmerman [2005] compared infill and expanding domain asymptotic paradigms and elucidate a preference for the former for analysing the limiting distributions of parameters in the Matérn family. Zhang [2004] showed that not all parameters in the Matérn family can be consistently estimated under infill asymptotics, but certain microergodic parameters,

The first and second authors have equal contributions to this paper.

which play a crucial role in the identifiability of Gaussian processes with the Matérn covariogram (see Section 2.1 for further details), are consistently estimable. Du et al. [2009] derived the asymptotic normality of the maximum likelihood estimator for such microergodic parameters. Kaufman and Shaby [2013] extended these asymptotic results to the case of jointly estimating the spatial range and the variance parameters in the Matérn family, and explored the effect of a prefixed range verses a joint estimated range on inference when having relatively small sample size. Recently Bevilacqua et al. [2019] and Ma and Bhadra [2019] considered more general classes of covariance functions outside of the Matérn family and studied the consistency and asymptotic normality of the maximum likelihood estimator for the corresponding microergodic parameters.

These studies have focused upon settings without the presence of a nugget. In practice, modelling the measurement error, or nugget effect, in (1) is prevalent in geostatistical modelling. The main difference between the model without a nugget and that with a nugget hinges on the rate of asymptotic normality of the maximum likelihood estimator of microergodic parameters: the former has a universal rate of  $n^{1/2}$ , while the latter, as shown in Theorem 2.5, has a rate of  $n^{1/(2+4\nu/d)}$  which depends on the model parameters. We also note that deriving the rate of  $n^{1/(2+4\nu/d)}$  for a Matérn model with a nugget effect is not an obvious consequence of any aforementioned results for Matérn or Matérn-like models without a nugget effect. Previous to this work, Zhang and Zimmerman [2005] offered some heuristic arguments for the consistency and asymptotic normality of the maximum likelihood estimators of microergodic parameters in (1). Chen et al. [2000] demonstrated that the presence of measurement error can have a big impact on the parameter estimates for Ornstein-Uhlenbeck processes, i.e., Matérn processes with  $\nu = 1/2$  and d = 1, over bounded intervals. Their proof exploits the Markovian property and the explicit formula for the maximum likelihood estimator of the one-dimensional Ornstein-Uhlenbeck process that are not available in the case of the Matérn model over  $\mathbb{R}^d$  with d > 2.

Returning to (1), it will be sufficient for our subsequent development to assume that  $\mu(s) = 0$ , i.e., the data have been de-trended. We specify  $\{w(s) : s \in \mathcal{S} \subset \mathbb{R}^d\}$  as a zero-centered stationary Gaussian process with isotropic Matérn covariogram,

<span id="page-1-0"></span>(2) 
$$K_w(x; \sigma^2, \phi, \nu) := \frac{\sigma^2(\phi ||x||)^{\nu}}{\Gamma(\nu) 2^{\nu - 1}} K_{\nu}(\phi ||x||), \quad ||x|| \ge 0,$$

where  $\sigma^2 > 0$  is called the partial sill or spatial variance,  $\phi > 0$  is the scale or decay parameter,  $\nu > 0$  is a smoothness parameter,  $\Gamma(\cdot)$  is the Gamma function, and  $K_{\nu}(\cdot)$  is the modified Bessel function of the second kind of order  $\nu$  [Abramowitz and Stegun, 1965, Section 10]. The corresponding spectral density is

(3) 
$$f_{K_w}(u) = C \frac{\sigma^2 \phi^{2\nu}}{(\phi^2 + u^2)^{\nu + d/2}} \quad \text{for some } C > 0.$$

When  $\nu = 1/2$ , the covariogram (2) simplifies to the exponential (Ornstein-Uhlenbeck in one-dimension) kernel

<span id="page-1-1"></span>
$$K_w(x; \sigma^2, \phi) := \sigma^2 \exp(-\phi ||x||).$$

For the measurement error, we assume  $\{\epsilon(s): s \in \mathcal{S} \subset \mathbb{R}^d\}$  is Gaussian white noise with covariogram  $K_{\epsilon}(y; \tau^2) := \tau^2 \delta_0$ , where  $\delta_0$  is the indicator function at 0 and  $\tau^2$  is the nugget. The processes  $\{w(s), s \in D \subset \mathbb{R}^d\}$  and  $\{\epsilon(s), s \in D \subset \mathbb{R}^d\}$  are independent. Hence, a

Matérn model with measurement error is a stationary Gaussian process with covariogram

<span id="page-2-1"></span>(4) 
$$K(x; \tau^2, \sigma^2, \phi, \nu) := K_w(x; \sigma^2, \phi, \nu) + K_{\epsilon}(x; \tau^2).$$

Our approach will depend upon identifying microergodic parameters in the above model. The remainder of the article evolves as follows. We review the discussion in Zhang [2004] for the Matérn model with measurement error, claiming that only  $\theta = \{\sigma^2 \phi^{2\nu}, \tau^2\}$  can have infill consistent estimators when  $d \leq 3$ . Subsequently, we establish that the maximum likelihood estimates for  $\theta$  are consistent and are asymptotically normal. This extends the main results in Chen et al. [2000] to the case with dimension  $d \leq 3$ . The asymptotic properties of interpolation are explored mainly through simulations, and we demonstrate the role of  $\theta$  in interpolation. We conclude with some insights and directions for future work.

#### 2. Asymptotic theory for estimation and prediction

<span id="page-2-3"></span><span id="page-2-0"></span>2.1. Identifiability. Zhang [2004] showed that for the Matérn model without measurement error, when fixing the smoothness parameter  $\nu > 0$  and  $d \le 3$ , there are no (weakly) infill consistent estimators for either the partial sill  $\sigma^2$  or the scale parameter  $\phi$ . Such results rely upon the equivalence and orthogonality of Gaussian measures. Two probability measures  $P_1$  and  $P_2$  on a measurable space  $(\Omega, \mathcal{F})$  are said to be equivalent, denoted  $P_1 \equiv P_2$ , if they are absolutely continuous with respect to each other. Thus,  $P_1 \equiv P_2$  implies that for all  $A \in \mathcal{F}$ ,  $P_1(A) = 0$  if and only if  $P_2(A) = 0$ . On the other hand,  $P_1$  and  $P_2$  are orthogonal, denoted  $P_1 \perp P_2$ , if there exists  $A \in \mathcal{F}$  for which  $P_1(A) = 1$  and  $P_2(A) = 0$ . While measures may be neither equivalent nor orthogonal, Gaussian measures are one or the other. For a Gaussian probability measure  $P_{\theta}$  indexed by a set of parameters  $\theta$ , we say that  $\theta$  is microergodic if  $P_{\theta_1} \equiv P_{\theta_2}$  if and only if  $\theta_1 = \theta_2$ . For further background, see Chapter 6 in Stein [1999] and Zhang [2012]. Furthermore, two Gaussian probability measures defined by Matérn covariograms  $K_w(\cdot; \sigma_1^2, \phi_1, \nu)$  and  $K_w(\cdot; \sigma_2^2, \phi_2, \nu)$  are equivalent if and only if  $\sigma_1^2 \phi_1^{2\nu} = \sigma_2^2 \phi_2^{2\nu}$  [Theorem 2 in Zhang, 2004] and, consequently, one cannot consistently estimate  $\sigma^2$  or  $\phi$  in the Matérn model (2) [Corollary 1 in Zhang, 2004].

We first characterise identifiability for the Matérn model with measurement error, i.e., with covariogram given by (4). Over a closed set  $S \subset \mathbb{R}^d$ , let  $G_S(m, K)$  denote the Gaussian measure of the random field on S with mean function m and covariance function K. Consider two different specifications for w(s) in (1) corresponding to mean  $m_i$  and covariogram  $K_i$  for i = 1, 2. The respective measures on the realizations of w(s) over S will be denoted by  $G_S(m_i, K_i)$  for i = 1, 2. If  $\chi = \{s_1, s_2, \ldots\}$  is a sequence of points in S, then the probability measure for the sequence of outcomes over  $\chi$ , i.e.,  $\{y(s_j) : s_j \in \chi\}$ , is denoted  $G_\chi(m_i, K_i, \tau_i^2)$  under model i. The following lemma is familiar.

<span id="page-2-2"></span>**Lemma 1.** Let S be a closed set, w(s) be a mean square continuous process on S under  $G_S(m_1, K_1)$ , and  $\chi$  be a dense sequence of points in S. Then, (i) if  $\tau_1^2 \neq \tau_2^2$ , then  $G_{\chi}(m_1, K_1, \tau_1^2) \perp G_{\chi}(m_2, K_2, \tau_2^2)$ ; and (ii) if  $\tau_1^2 = \tau_2^2$ , then  $G_{\chi}(m_1, K_1, \tau_1^2) \equiv G_{\chi}(m_2, K_2, \tau_2^2)$  if and only if  $G_S(m_1, K_1) \equiv G_S(m_2, K_2)$ .

*Proof.* See Theorem 6 in Chapter 4 of Stein [1999].

According to Stein [1999, p.121] (or [Ibragimov and Rozanov, 1978, III.4.1]), two Gaussian measures  $G_S(m,K) \equiv G_S(0,K)$  if and only if the mean function  $m(\cdot)$  can be extended to a square-integrable function on  $\mathbb{R}^d$  whose Fourier transform  $\widehat{m}(\omega)$  satisfies  $\int_{\mathbb{R}^d} \frac{|\widehat{m}(\omega)|^2}{f_K(\omega)} d\omega < \infty$ ,

where  $f_K$  denotes the spectral density of the covariance function K. In such a situation, the mean function  $m(\cdot)$  of the Gaussian process is not identifiable. A specific example is the Gaussian measure with  $m(x) = \beta^{\top} x$ , where  $\beta \in \mathbb{R}^d$  and K is the Matérn covariogram. From a practical inferential standpoint, most of the insights obtained from the subsequent theoretical developments will apply to de-trended processes. The following result adapts Lemma 1 to the Matérn model with measurement error and summarizes the identifiability issue with measurement error.

<span id="page-3-0"></span>**Theorem 2.1.** Let  $S \subset \mathbb{R}^d$  be a compact set. For i = 1, 2, let  $P_i$  be the probability measure of the Gaussian process on S with mean zero and covariance  $K(\cdot; \tau_i^2, \sigma_i^2, \phi_i, \nu)$  defined by (4). Then, (i) if  $\tau_1^2 \neq \tau_2^2$ , then  $P_1 \perp P_2$ ; and (ii) if  $\tau_1^2 = \tau_2^2$ , then for  $d \leq 3$ ,  $P_1 \equiv P_2$  if and only if  $\sigma_1^2 \phi_1^{2\nu} = \sigma_2^2 \phi_2^{2\nu}$ , and for  $d \geq 5$ ,  $P_1 \equiv P_2$  if and only if  $(\sigma_1^2, \phi_1) = (\sigma_2^2, \phi_2)$ .

Proof. Denote  $K_i$  for  $K_w(\cdot; \sigma_i^2, \phi_i, \nu)$ . It is easy to see that w(s) is mean square continuous on S under  $G_S(0, K_i)$ . From Lemma 1, we know that if  $\tau_1^2 \neq \tau_2^2$ , for any dense sequence  $\chi$ ,  $G_\chi(0, K_1, \tau_1^2) \perp G_\chi(0, K_2, \tau_2^2)$ . Therefore,  $P_1 \perp P_2$ . This proves (i).

Next, suppose  $\tau_1^2 = \tau_2^2$ . From Theorem 2 in Zhang [2004], we know that for  $d \leq 3$ 

Next, suppose  $\tau_1^2 = \tau_2^2$ . From Theorem 2 in Zhang [2004], we know that for  $d \leq 3$   $G_S(0, K_1) \equiv G_S(0, K_2)$  if and only if  $\sigma_1^2 \phi_1^{2\nu} = \sigma_2^2 \phi_2^{2\nu}$ . Corollary 3 in Anderes [2010] shows that, for  $d \geq 5$ ,  $G_S(0, K_1) \perp G_S(0, K_2)$  if  $\{\sigma_1^2, \phi_1\} \neq \{\sigma_2^2, \phi_2\}$ . A straightforward application of Lemma 1 proves (ii).

Theorem 2.1 characterizes equivalence and orthogonality of Matérn based Gaussian measures in terms of their parameters. Here it is instructive to distinguish between  $d \leq 3$  and  $d \geq 5$ . The results in Zhang [2004] emerge as special cases when  $\tau_1^2 = \tau_2^2 = 0$  and  $\sigma_1^2 \phi_1^{2\nu} = \sigma_2^2 \phi_2^{2\nu}$  for  $d \leq 3$ . Combining Theorem 2.1 with the argument provided in Corollary 1 of Zhang [2004], we can conclude that  $\sigma^2$  and  $\phi$  are not consistently estimable. We provide this as an immediate corollary to Theorem 2.1.

Corollary 1. Let y(s),  $s \in S \subset \mathbb{R}^d$ ,  $d \leq 3$  be a Gaussian process with a covariogram as in (4), and  $S_n$ ,  $n \geq 1$  be an increasing sequence of subsets of S. Given observations of y(s),  $s \in S_n$ , there do not exist estimates  $\widehat{\sigma}_n^2$  and  $\widehat{\phi}_n$  that are consistent.

Consequently, the joint maximum likelihood estimators of  $\{\sigma^2, \phi\}$  are not consistent estimators. In contrast to  $\{\sigma^2, \phi\}$ , we show in Theorem 2.4 that the maximum likelihood estimator of the nugget  $\tau^2$  is consistent.

Turning to  $d \geq 5$ , it follows from Theorem 2.1 that there exist joint estimates  $(\widehat{\tau}_n^2, \widehat{\sigma}_n^2, \widehat{\phi}_n)$  which converge to  $(\tau^2, \sigma^2, \phi)$ . For instance, letting  $t_{i,n} = \frac{i}{n} 1_d$ , where  $1_d$  denotes the vector of 1's in  $\mathbb{R}^d$ , we can take  $\widehat{\tau}_n^2 = \frac{1}{2|\mathcal{I}|} \sum_{i \in \mathcal{I}} (y(t_{i+1,n}) - y(t_{i,n}))^2$ , where  $\mathcal{I} = \{i \in \mathbb{Z} : t_{i+1,n}, t_{i,n} \in S\}$  and  $|\mathcal{I}|$  is the cardinality of  $\mathcal{I}$ . Further, Anderes [2010] constructed consistent estimators of  $(\sigma^2, \phi)$  based on higher order increments of y. However, it is currently unknown whether the joint maximum likelihood estimators of  $(\tau^2, \sigma^2, \phi)$  are consistent. Even for the Matérn model without a nugget  $(\tau^2 = 0)$ , the consistency of the joint maximum likelihood estimators of  $(\sigma^2, \phi)$  remains unresolved.

The characterization of equivalence and orthogonality of  $P_1$  and  $P_2$  is also open in the critical dimension d=4. The balance of this paper focuses on the asymptotic properties of the maximum likelihood estimates and predictions for the Matérn model with nugget when  $d \leq 3$  with additional discussions and results for  $d \geq 5$  in Section 2.5.

<span id="page-3-1"></span>2.2. **Parameter estimation.** Theorem 2.1 implies that if  $\nu$  is fixed in the specification of w(s) in (1), then  $\sigma^2 \phi^{2\nu}$  and the nugget  $\tau^2$  will be identifiable. In view of this, we consider

the estimation of the microergodic parameter  $\kappa := \sigma^2 \phi^{2\nu}$  and the nugget  $\tau^2$  with fixed decay  $\phi$ . Our main results concern the consistency and the asymptotic normality of the maximum likelihood estimators of  $\kappa$  and  $\tau^2$  when the observations are taken from  $y(\cdot)$  modelled by (1).

To proceed further, we need some notations. Let  $\chi_n = \{s_1, \ldots, s_n\}$  be the sampled points in S,  $y_i := y(s_i)$ ,  $i = 1, \ldots, n$  be the corresponding observations, and let  $K_n := \{K_w(s_i - s_j; \sigma^2, \phi, \nu)\}_{1 \le i,j \le n}$  denote the  $n \times n$  Matérn covariance matrix over locations  $\chi_n$ . Let  $\{\lambda_i^{(n)}, i = 1, \ldots, n\}$  be the eigenvalues of  $\frac{1}{\sigma^2}K_n$  in decreasing order. The covariance matrix of the observations  $y = (y_1, \ldots, y_n)^{\top}$  is  $V_n = \tau^2 I_n + K_n$ , the likelihood is denoted by  $\mathcal{L}(\tau^2, \sigma^2, \phi)$ , and the (rescaled) negative log-likelihood is

<span id="page-4-0"></span>(5) 
$$\ell(\tau^2, \sigma^2, \phi) := \log \det V_n + y^{\mathsf{T}} V_n^{-1} y.$$

Let  $\{\sigma_0^2, \phi_0, \tau_0^2\}$  be the true generating values of  $\{\sigma^2, \phi, \tau^2\}$ ,  $\kappa_0 = \sigma_0^2 \phi_0^{2\nu}$ . Assume that the smoothness parameter  $\nu > 0$  is known. For any fixed  $\phi_1 > 0$ , let  $(\widehat{\tau}_n^2(\phi_1), \widehat{\sigma}_n^2(\phi_1))$  be the maximum likelihood estimators of  $\{\tau^2, \sigma^2\}$ . That is,

<span id="page-4-1"></span>(6) 
$$(\widehat{\tau}_n^2(\phi_1), \widehat{\sigma}_n^2(\phi_1)) := \operatorname{argmax}_{(\tau^2, \sigma^2) \in D} \mathcal{L}(\tau^2, \sigma^2, \phi_1) = \operatorname{argmin}_{(\tau^2, \sigma^2) \in D} \ell(\tau^2, \sigma^2, \phi_1)$$

where  $D = [a,b] \times [c,d]$  with  $0 < a < b < \infty$  and  $0 < c < d < \infty$ . To simplify notations, write  $\widehat{\tau}_n^2$ ,  $\widehat{\sigma}_n^2$  for  $\widehat{\tau}_n^2(\phi_1)$ ,  $\widehat{\sigma}_n^2(\phi_1)$ . Unlike the Matérn model (2), there is no explicit formula for  $\widehat{\tau}_n^2$  and  $\widehat{\sigma}_n^2$  in the Matérn model with measurement error. Another difficulty of the analysis is that  $\mathcal{L}$  is not concave, so the (rescaled) negative log-likelihood  $\ell(\tau^2, \sigma^2, \phi_1)$  may have local minima and stationary points. Nevertheless, we are able to establish the theorems regarding the consistency and asymptotic normality at these stationary points under some assumptions of the eigenvalue asymptotics.

2.2.1. Eigenvalue decay. We first give an upper bound for the eigenvalues  $\lambda_i^{(n)}$ , which is of independent interest. The argument we provide below works for a large class of covariograms, including the Matérn model. In the sequel, the symbol  $\simeq$  indicates asymptotically bounded from below and above. We follow closely the presentation of Belkin [2018]. Let  $\Omega$  be a domain of  $\mathbb{R}^d$ , and  $K(\cdot)$  be a positive definite radial basis kernel on  $\mathbb{R}^d$ . Denote  $\mathcal{H}$  to be the Reproducing Kernel Hilbert Space corresponding to the kernel K, which is also the native space associated to the kernel K. Given a probability measure  $\mu$  on  $\Omega$ , define the integral operator  $\mathcal{K}_{\mu}: L^2_{\mu} \to L^2_{\mu}$  by

$$\mathcal{K}_{\mu}f(x) := \int_{\Omega} K(x-z)f(z)\mu(dz).$$

In particular, if  $\mu = \frac{1}{n} \sum_{i=1}^{n} \delta_{s_i}$ ,  $\mathcal{K}_{\mu}$  corresponds to the kernel matrix  $\{\frac{1}{n}K(s_i - s_j)\}_{1 \leq i,j \leq n}$ . It is well known that  $\mathcal{K}_{\mu}f \in \mathcal{H}$  for  $f \in L^2_{\mu}$ , and any function in  $\mathcal{H}$  induces a function in  $L^2_{\mu}$  by restricting it to the support of  $\mu$  (see Section 2 of Belkin [2018]). Call  $\mathcal{R}_{\mu} : \mathcal{H} \to L^2_{\mu}$  the restriction operator.

The key idea of Belkin [2018] is to get a measure-independent upper bound for the eigenvalues of  $\mathcal{K}_{\mu}$  for infinitely smooth kernels, while the argument can carry over to kernels with limited smoothness; that is, the spectral density of K satisfies  $f(u) \approx u^{-\beta-d}$  ( $\beta$ -smooth). By (3), the Matérn covariogram is  $2\nu$ -smooth. Given  $\chi = \{s_1, \ldots, s_n\} \subset \Omega$ , let  $S_{\chi} : \mathcal{H} \to \mathcal{H}$  be the interpolation operator defined by

$$S_{\chi}f(x) = \sum_{i=1}^{n} \alpha_i K(x_i - x),$$

where  $(\alpha_1, \ldots, \alpha_n)^{\top} = K_n^{-1}(f(x_1), \ldots, f(x_n))^{\top}$  with  $K_n = \{K(s_i - s_j)\}_{1 \leq i,j \leq n}$ . By letting  $h = \max_{s \in S} \min_{1 \leq i \leq n} \|s - s_i\|$ , Santin and Schaback [2016, p985] proved that there exists C > 0 (independent of n) such that

(7) 
$$\|\mathcal{R}_{\mu} - S_{\chi}\|_{\mathcal{H} \to L^{2}_{\mu}} \le Ch^{(\beta+d)/2}.$$

Here  $\|\cdot\|_{\mathcal{H}\to L^2_{\mu}}$  denotes the operator norm. So (7) is a limited smoothness version of Belkin [2018, Theorem A]. The following result is adapted from Theorem 1 in Belkin [2018] to the  $\beta$ -smooth kernel.

<span id="page-5-1"></span>**Theorem 2.2.** Suppose  $\mathcal{T}: V \to \mathcal{H}$  is a map from a Banach space V to a Reproducing Kernel Hilbert Space of functions on  $\mathbb{R}^d$ ,  $\mathcal{H}$  corresponding to a  $\beta$ -smooth radial basis kernel. Then there exists a map  $\mathcal{T}_n$  from V to an n-dimensional linear subspace  $\mathcal{H}_n \subset \mathcal{H}$ , such that

<span id="page-5-0"></span>
$$\|\mathcal{T} - \mathcal{T}_n\|_{V \to L^2_u} \le C \|\mathcal{T}\|_{V \to \mathcal{H}} \, n^{-\frac{\beta+d}{d}}$$

for C > 0 independent of  $\mathcal{T}$  and  $\mu$ . Moreover, (1) the subspace  $\mathcal{H}_n$  is independent of  $\mathcal{T}$ ; (2) if  $\mathcal{T}$  is linear operator,  $\mathcal{T}_n$  is also a linear operator.

*Proof.* The proof follows immediately from Theorem 1 in Belkin [2018] by substituting Theorem A therein with the bound in (7).

The following theorem is adapted from Theorem 2 in Belkin [2018] for  $\beta$ -smooth kernels.

<span id="page-5-2"></span>**Theorem 2.3.** Let K be a  $\beta$ -smooth radial basis kernel, and  $\lambda_i(\mathcal{K}_{\mu})$  be the  $i^{th}$  largest eigenvalue of  $\mathcal{K}_{\mu}$ . Then there exists C > 0 such that

$$\lambda_i(\mathcal{K}_\mu) \le Ci^{-\frac{\beta+d}{d}}.$$

*Proof.* The proof follows by combining Theorem 2.2 above with Lemma 1 in Belkin [2018].

Corollary 2. Assume that  $\max_{s \in S} \min_{1 \le i \le n} ||s - s_i|| \le n^{-1/d}$ . There exists C > 0 independent of n such that

(8) 
$$\lambda_i^{(n)} \le Cni^{-2\nu/d-1} \quad \text{for all } i = 1, \dots, n.$$

*Proof.* This follows immediately from applying Theorem 2.3 with  $\mu = \frac{1}{n} \sum_{i=1}^{n} \delta_{s_i}$  and  $\beta = 2\nu$ .

Here, it is natural to enquire about a matching lower-bound for the eigenvalues  $\lambda_i^{(n)}$  under a suitable condition on the sampled point locations. To develop a rigorous framework, we lay down the following assumptions and provide heuristics and numerical evidence to show why these assumptions are expected to be true.

<span id="page-5-4"></span><span id="page-5-3"></span>Assumption 1. Assume that  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \approx n^{-1/d}$ . There exists c > 0 such that (9)  $\lambda_i^{(n)} \ge cni^{-2\nu/d-1}$  for all i = 1, ..., n.

The lower bound (9) holds for the largest eigenvalues. A lesser known result of Schaback [1995] shows that (9) also holds for the smallest eigenvalues with  $i \approx n$ . However, there is no rigorous result for the lower bound of eigenvalues in full generality. Particularly interesting cases are  $i \approx n^{\alpha}$  for  $0 < \alpha < 1$ , which leave the lower bound (9) open. In Figure 1, we plot the values of  $\lambda_i^{(n)}/(ni^{-2\nu-1})$  with sampled points on the regular grid  $[0,1) \cap n^{-1}\mathbb{Z}$  for  $\nu = 0.9, 1.5$ , n ranging from 100 to 3000, and  $i = n^{0.5}$ ,  $n^{0.75}$ ,  $n^{0.9}$ . Consistent with Assumption 1, the

profile plots of  $\lambda_i^{(n)}/(ni^{-2\nu/d-1})$  get flat as n increases. Furthermore, we see that when the points are sampled on  $[0,1)\cap n^{-1}\mathbb{Z}$ , the quantity  $\lambda_i^{(n)}/(ni^{-2\nu-1})$  tends to converge as n,i become large. This observation leads to the following stronger conjecture.

<span id="page-6-0"></span>![](_page_6_Figure_2.jpeg)

FIGURE 1. Trend of  $\lambda_i^{(n)}/(ni^{-2\nu/d-1})$  for  $i=n^{\alpha}$  when the points are sampled on the regular grid  $[0,1)\cap n^{-1}\mathbb{Z}$ . Parameters  $\phi$  and  $\sigma^2$  in Matérn covariogram are set to be 1.0 and 1.0, respectively.

<span id="page-6-1"></span>**Assumption 2.** Let  $\chi_n = [0,1)^d \cap n^{-1/d} \mathbb{Z}^d$  be the regular grid. There exists  $A = A(\phi, \nu, d) > 0$  such that

(10) 
$$\lambda_i^{(n)}/(ni^{-2\nu/d-1}) \to A \quad as \ n, i \to \infty$$

Besides the numerical evidence, let us explain heuristics underlying this assumption from a theoretical viewpoint. First, Assumption 2 has been rigorously proved in Chen et al. [2000] for Ornstein–Uhlenbeck processes, corresponding to the case of  $\nu=1/2$  and d=1. Furthermore, for the regular grid  $\chi_n$ , the scaled covariance matrix  $\frac{1}{n\sigma^2}K_n$  is viewed as the discretization of the integral operator

$$\mathcal{K}f(x) := \int_{[0,1]^d} K_w(s-t;1,\phi,\nu)f(t)dt,$$

where f is a test function. The integral operator  $\mathcal{K}$  has eigenvalues  $\lambda_1 \geq \lambda_2 \geq \cdots > 0$ . Intuitively,  $\lambda_i^{(n)}/n \approx \lambda_i$  which is at least true for fixed i. Santin and Schaback [2016] observed that  $\lambda_i = h_{i-1}^2$ , with  $h_i$  the i-width of the unit Sobolev ball in the  $L^2$  space. Using a differential operator approach, Jerome [1972] showed that  $\lim_{i \to \infty} i^{\frac{2\nu+d}{2d}} h_i = C'$ . The above two results imply that  $\lim_{i \to \infty} i^{2\nu/d+1} \lambda_i = C'^2$ . Thus, we expect that  $\lambda_i^{(n)}/(ni^{-2\nu/d-1}) \approx i^{2\nu/d-1} \lambda_i \approx C'^2$  as  $n, i \to \infty$ , though the error  $|\lambda_i^{(n)}/n - \lambda_i|$  is not easy to estimate.

To proceed further, we need the following lemma which is proved by elementary calculus.

<span id="page-6-2"></span>**Lemma 2.** Assume that  $\max_{s \in S} \min_{1 \le i \le n} ||s - s_i|| \asymp n^{-1/d}$  and  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \asymp n^{-1/d}$ . Let  $a_{ni} = 1/(\widehat{\tau}_n^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)})$ ,  $b_{ni} = \lambda_i^{(n)}/(\tau_0^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)})$ ,  $a_{ni}^0 = 1/(\tau_0^2 + \sigma^2 \lambda_i^{(n)})$ , and  $b_{ni}^0 = \lambda_i^{(n)} a_{ni}^0$ . (1) There exists C > 0 such that

$$\sum_{i=1}^{n} a_{ni}^{2} \approx n \; , \; \sum_{i=1}^{n} \lambda_{i}^{(n)} a_{ni}^{2} \leq C n^{\frac{1}{2\nu/d+1}} \; , \; \sum_{i=1}^{n} b_{ni} \leq C n^{\frac{1}{2\nu/d+1}} \; , \; \sum_{i=1}^{n} b_{ni}^{2} \leq C n^{\frac{1}{2\nu/d+1}} \; .$$

(2) Under Assumption 1.

$$\sum_{i=1}^{n} \lambda_i^{(n)} a_{ni}^2 \asymp n^{\frac{1}{2\nu/d+1}} , \sum_{i=1}^{n} b_{ni} \asymp n^{\frac{1}{2\nu/d+1}} , \sum_{i=1}^{n} b_{ni}^2 \asymp n^{\frac{1}{2\nu/d+1}} .$$

(3) Under Assumption 2, there exist  $c_1(\sigma), c_2(\sigma), c_3(\sigma) > 0$  such that as  $n \to \infty$ ,

$$\frac{1}{n} \sum_{i=1}^{n} (a_{ni}^{0})^{2} \to c_{1}(\sigma), \quad \frac{1}{n} \sum_{i=1}^{n} (a_{ni}^{0})^{4} \to c_{2}(\sigma), \quad \frac{1}{n^{1/(1+2\nu/d)}} \sum_{i=1}^{n} (b_{ni}^{0})^{2} \to c_{3}(\sigma).$$

2.2.2. Consistency of the maximum likelihood estimator. We begin our development of the consistency of the maximum likelihood estimator of the nugget  $\hat{\tau}_n^2$  and the microergodic parameter  $\hat{\sigma}_n^2 \phi_1^{2\nu}$  under Assumption 1. We point out that the consistency of the nugget  $\hat{\tau}_n^2$  is true without Assumption 1 on the lower bound for eigenvalues, and  $\hat{\tau}_n^2$  remains consistent even when  $\sigma^2$  and  $\phi$  are misspecified.

<span id="page-7-0"></span>**Theorem 2.4.** Assume that 
$$(\tau_0^2, \sigma_0^2) \in D$$
,  $\chi_n := \{s_1, \dots, s_n\}$  satisfy  $\max_{s \in S} \min_{1 \le i \le n} ||s - s_i|| \asymp n^{-1/d}$  and  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \asymp n^{-1/d}$ .

Let  $P_0$  be the probability measure of the Matérn model with covariogram  $K(\cdot; \tau_0^2, \sigma_0^2, \phi_0, \nu)$ . Then  $\hat{\tau}_n^2 \to \tau_0^2$  almost surely under  $P_0$ . Further assume that the conditions in Assumption 1 hold. Then  $\hat{\sigma}_n^2 \phi_1^{2\nu} \to \kappa_0$  almost surely under  $P_0$ .

*Proof.* Let  $P_1$  be the probability measure corresponding to  $K(\cdot; \tau_0^2, \sigma_1^2, \phi_1, \nu)$ , where  $\sigma_1^2 := \kappa_0/\phi_1^{2\nu}$ . We first prove that  $\hat{\tau}_n^2 \to \tau_0^2$  almost surely under  $P_0$ . From Theorem 2.1 we know that  $P_0 \equiv P_1$ . Hence, it suffices to prove that  $\hat{\tau}_n^2 \to \tau_0^2$  almost surely under  $P_1$ . Under  $P_1$ , we can rewrite (5) as

(11) 
$$\ell(\tau^2, \widehat{\sigma}_n^2, \phi_1) = \sum_{i=1}^n \frac{\tau_0^2 + \sigma_1^2 \lambda_i^{(n)}}{\tau^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)}} W_i^2 + \sum_{i=1}^n \log(\tau^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)}),$$

where  $W_i \stackrel{iid}{\sim} \mathcal{N}(0,1)$ . The maximum likelihood estimator  $\widehat{\tau}_n^2$  of  $\tau^2$  satisfies

<span id="page-7-2"></span>
$$(12) \qquad (\tau_0^2 - \widehat{\tau}_n^2) \cdot \sum_{i=1}^n W_i^2 a_{ni}^2 = \sum_{i=1}^n \widehat{\tau}_n^2 (1 - W_i^2) a_{ni}^2 + \sum_{i=1}^n (\widehat{\sigma}_n^2 - \sigma_1^2 W_i^2) \lambda_i^{(n)} a_{ni}^2.$$

where  $a_{ni} = 1/(\widehat{\tau}_n^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)})$ . By Lemma 2 (1), we have  $\sum_{i=1}^n a_{ni}^2 \approx n$  and  $\sum_{i=1}^n \lambda_i^{(n)} a_{ni}^2 \leq C n^{1/(2\nu/d+1)}$  for some C > 0. Using the results of Etemadi [2006], we obtain

<span id="page-7-1"></span>
$$(13) \quad \frac{\sum_{i=1}^{n} W_{i}^{2} a_{ni}^{2}}{\sum_{i=1}^{n} a_{ni}^{2}} \to 1, \quad \frac{\sum_{i=1}^{n} \widehat{\tau}_{n}^{2} (1 - W_{i}^{2}) a_{ni}^{2}}{\sum_{i=1}^{n} a_{ni}^{2}} \to 0 \quad \text{and} \quad \frac{\sum_{i=1}^{n} (\widehat{\sigma}_{n}^{2} - \sigma_{1}^{2} W_{i}^{2}) \lambda_{i}^{(n)} a_{ni}^{2}}{\sum_{i=1}^{n} a_{ni}^{2}} \to 0.$$

Here we also give an elementary proof of the last convergence in (13). It is clear that

l.h.s = 
$$\frac{\sum_{i=1}^{n} \widehat{\sigma}_{n}^{2} \lambda_{i}^{(n)} a_{ni}^{2}}{\sum_{i=1}^{n} a_{ni}^{2}} - \sigma_{1}^{2} \frac{\sum_{i=1}^{n} \lambda_{i}^{(n)} a_{ni}^{2} W_{i}^{2}}{\sum_{i=1}^{n} a_{ni}^{2}} := (a) - (b).$$

From (6) we know that  $\widehat{\sigma}_n^2$  is bounded from above. So the term  $(a) \lesssim \frac{\sum_{i=1}^n \lambda_i^{(n)} a_{ni}^2}{\sum_{i=1}^n a_{ni}^2} \to 0$  by Lemma 2 (1). Next

$$Z_{ni} := \lambda_i^{(n)} a_{ni}^2 = \frac{\lambda_i^{(n)}}{(\widehat{\tau}_n^2 + \widehat{\sigma}_n^2 \lambda_i^{(n)})^2} \le \frac{\lambda_i^{(n)}}{4\widehat{\tau}_n^2 \widehat{\sigma}_n^2 \lambda_i^{(n)}} \le C,$$

again, from (6) we note that  $\widehat{\tau}_n^2$  and  $\widehat{\sigma}_n^2$  are bounded away from 0. Moreover, by Lemma 2 (1),  $\sum_{i=1}^n Z_{ni} \lesssim n^{\theta}$  for some  $\theta < 1$  and so  $\sum_{i=1}^n Z_{ni}^2 \lesssim n^{\theta}$  (since  $Z_{ni} \leq C$ ). Let  $S_n := \sum_{i=1}^n \frac{Z_{ni}(W_i^2 - 1)}{n}$ . Fix  $\delta > 0$ . We have

$$\mathbb{P}\left(\sup_{m+1 \le k \le n} |S_k - S_m| \ge \delta\right) \le \mathbb{P}\left(\sup_{m+1 \le k \le n} \left| \sum_{i=1}^m \left( \frac{Z_{ki}}{k} - \frac{Z_{mi}}{m} \right) (W_i^2 - 1) \right| \ge \frac{99}{100} \delta\right) \\
+ \mathbb{P}\left(\sup_{m+1 \le k \le n} \left| \sum_{i=m+1}^k \frac{Z_{ki}}{k} (W_i^2 - 1) \right| > \frac{\delta}{100} \right) := (c) + (d).$$

For the term (c), we get for some C' > 0,

$$(c) \leq \mathbb{P}\left(\left|\sum_{i=1}^{m} \frac{Z_{mi}}{m}(W_{i}^{2} - 1)\right| \geq \frac{99}{200}\delta\right) + \mathbb{P}\left(\sup_{m+1 \leq k \leq n} \left|\sum_{i=1}^{m} \frac{Z_{ki}}{k}(W_{i}^{2} - 1)\right| \geq \frac{99}{200}\delta\right)$$

$$\leq \mathbb{P}\left(\left|\sum_{i=1}^{m} \frac{Z_{mi}}{m}(W_{i}^{2} - 1)\right| \geq \frac{99}{200}\delta\right) + \sum_{k=m+1}^{n} \mathbb{P}\left(\left|\sum_{i=1}^{m} \frac{Z_{ki}}{k}(W_{i}^{2} - 1)\right| \geq \frac{99}{200}\delta\right)$$

$$\lesssim \frac{1}{\delta^{2}m^{2-\theta}} + \sum_{k=m+1}^{n} \frac{1}{\delta^{2}k^{2-\theta}} \leq \frac{C'}{\delta^{2}m^{1-\theta}}.$$

For the term (d), we have for some C'' > 0,

$$(d) \le \sum_{k=m+1}^{n} \mathbb{P}\left( \left| \sum_{i=m+1}^{k} \frac{Z_{ki}}{k} (W_i^2 - 1) \right| > \frac{\delta}{100} \right) \lesssim \sum_{k=m+1}^{n} \frac{1}{\delta^2 k^{2-\theta}} \le \frac{C''}{\delta^2 m^{1-\theta}}.$$

Combining the above estimates and passing  $n \to \infty$  yield  $\mathbb{P}\left(\sup_{n \ge m} |S_n - S_m| \ge \delta\right) \to 0$ as  $m \to \infty$ . It follows that  $S_n$  converges almost surely (see the proof of Theorem 2.5.6 in Durrett [2019]). Since  $\sum_{i=1}^{n} Z_{ni}/n \to 0$  by Lemma 2 (1), we have  $\sum_{i=1}^{n} Z_{ni}W_{i}^{2}/n$  converges almost surely to some  $U \geq 0$  almost surely. By the boundedness of  $Z_{ni}$ , we get  $\sup_{n} \mathbb{E}\left[\left(\sum_{i=1}^{n} Z_{ni}W_{i}^{2}/n\right)^{2}\right] < \infty$  so  $\sum_{i=1}^{n} Z_{ni}W_{i}^{2}/n$  is uniformly integrable. Thus,  $\mathbb{E}U = \sum_{i=1}^{n} Z_{ni}W_{i}^{2}/n$  $\lim_{n\to\infty} \mathbb{E}\left(\sum_{i=1}^n Z_{ni}W_i^2/n\right) = \lim_{n\to\infty} \sum_{i=1}^n Z_{ni}/n = 0. \text{ So } U = 0 \text{ almost surely, and hence}$   $\sum_{i=1}^n Z_{ni}W_i^2/n \to 0 \text{ almost surely. The term } (b) = \frac{\sigma_1^2 \sum_{i=1}^n Z_{ni}W_i^2}{\sum_{i=1}^n a_{ni}^2} \to 0 \text{ since } \sum_{i=1}^n a_{ni}^2 \asymp n.$ Combining the above with (12), we have  $\widehat{\tau}_n^2 \to \tau_0^2$  almost surely under  $P_1$ .

Next, we show that  $\widehat{\sigma}_n^2 \phi_1^{2\nu} \to \kappa_0$  almost surely under  $P_0$ . Since  $\widehat{\tau}_n^2 \to \tau_0^2$  almost surely under  $P_0$  and  $P_0$  and  $P_0$  are  $P_0$  and  $P_0$  and  $P_0$  are  $P_0$  almost surely under  $P_0$  and  $P_0$  and  $P_0$  are  $P_0$  almost surely under  $P_0$  and  $P_0$  are  $P_0$  almost surely under  $P_0$  and  $P_0$  are  $P_0$  almost surely under  $P_0$  and  $P_0$  are  $P_0$  are  $P_0$  and  $P_0$  are  $P_0$  are  $P_0$  and  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  and  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$  are  $P_0$ .

almost surely to  $\sigma_1^2$  under  $P_0$ . Again, since  $P_0 \equiv P_1$ , it suffices to show  $\hat{\sigma}_n^2 \to \sigma_1^2$  almost surely under  $P_1$ . Under  $P_1$ ,

<span id="page-8-0"></span>(14) 
$$\ell(\tau_0^2, \sigma^2, \phi_1) = \sum_{i=1}^n \frac{\tau_0^2 + \sigma_1^2 \lambda_i^{(n)}}{\tau_0^2 + \sigma^2 \lambda_i^{(n)}} W_i^2 + \sum_{i=1}^n \log(\tau_0^2 + \sigma^2 \lambda_i^{(n)}).$$

Taking the derivative of (14) with respect to  $\sigma^2$  and equating to zero, we obtain

<span id="page-8-1"></span>(15) 
$$\sum_{i=1}^{n} b_{ni}(W_i^2 - 1) = (\widehat{\sigma}_n'^2 - \sigma_1^2) \sum_{i=1}^{n} b_{ni}^2 W_i^2.$$

with  $b_{ni} = \lambda_i^{(n)}/(\tau_0^2 + \widehat{\sigma}_n^{'2}\lambda_i^{(n)})$ . It suffices to prove that  $\sum_{i=1}^n b_{ni}(W_i^2 - 1)/\sum_{i=1}^n b_{ni}^2W_i^2$  converges almost surely to 0. Since

$$\frac{\sum_{i=1}^{n} b_{ni}(W_{i}^{2}-1)}{\sum_{i=1}^{n} b_{ni}^{2}W_{i}^{2}} = \frac{\sum_{i=1}^{n} b_{ni}(W_{i}^{2}-1)}{\sum_{i=1}^{n} b_{ni}} \cdot \frac{\sum_{i=1}^{n} b_{ni}}{\sum_{i=1}^{n} b_{ni}^{2}} \cdot \frac{\sum_{i=1}^{n} b_{ni}^{2}}{\sum_{i=1}^{n} b_{ni}^{2}W_{i}^{2}},$$

and  $\sum_{i=1}^{n} b_{ni} \simeq n^{1/(2\nu/d+1)}$ ,  $\sum_{i=1}^{n} b_{ni}^2 \simeq n^{1/(2\nu/d+1)}$  by Lemma 2 (2), we get

$$\frac{\sum_{i=1}^{n} b_{ni}(W_i^2 - 1)}{\sum_{i=1}^{n} b_{ni}} \longrightarrow 0 \quad \text{and} \quad \frac{\sum_{i=1}^{n} b_{ni}^2}{\sum_{i=1}^{n} b_{ni}^2 W_i^2} \longrightarrow 1 \quad a.s.$$

Combining the above estimates with (15), we have  $\hat{\sigma}_n^{\prime 2} \to \sigma_1^2$  almost surely under  $P_1$ .

It is difficult to establish the consistency of the joint maximum likelihood estimates of  $\{\kappa, \tau^2, \phi\}$  (i.e.,  $\phi$  is not fixed). A related result can be found in Theorem 2 of Kaufman and Shaby [2013] without a nugget effect. In the presence of a nugget effect, constructing such a proof becomes difficult due to the analytic intractability of the maximum likelihood estimators for  $\{\kappa, \tau^2, \phi\}$ . Nevertheless, our simulation studies in Section 3.3 seem to support consistent estimation of  $\{\kappa, \tau^2\}$  even when  $\phi$  is not fixed.

2.2.3. Asymptotic normality of the maximum likelihood estimator. Given the consistency of the maximum likelihood estimators, we turn to their asymptotic distributions. For simplicity of presentation, we let  $S = [0,1]^d$  in the following theorem. The asymptotic normality described below holds for any compact set  $S \subset \mathbb{R}^d$ .

<span id="page-9-0"></span>**Theorem 2.5.** Assume that n is the d<sup>th</sup> power of some positive integer,  $\chi_n = [0,1)^d \cap n^{-1/d}\mathbb{Z}^d$ , and the conditions in Assumption 2 hold. Let

<span id="page-9-3"></span><span id="page-9-1"></span>
$$a_{ni}^0 := 1/(\tau_0^2 + \sigma_1^2 \lambda_i^{(n)})$$
 and  $b_{ni}^0 := \lambda_i^{(n)} a_{ni}^0$  for  $1 \le i \le n$ .

There exist constants  $c_1, c_2, c_3 > 0$  such that as  $n \to \infty$ ,

(16) 
$$\frac{1}{n} \sum_{i=1}^{n} (a_{ni}^{0})^{2} \to c_{1}, \quad \frac{1}{n} \sum_{i=1}^{n} (a_{ni}^{0})^{4} \to c_{2}, \quad \frac{1}{n^{1/(1+2\nu/d)}} \sum_{i=1}^{n} (b_{ni}^{0})^{2} \to c_{3}.$$

We have

(17) 
$$\sqrt{n}(\widehat{\tau}_n^2 - \tau_0^2) \xrightarrow{(d)} \mathcal{N}(0, 2\tau_0^4 c_2/c_1^2),$$

and

<span id="page-9-4"></span>(18) 
$$n^{1/(2+4\nu/d)}(\widehat{\sigma}_n^2 \phi_1^{2\nu} - \kappa_0) \xrightarrow{(d)} \mathcal{N}(0, 2\phi_1^{4\nu}/c_3),$$

under  $P_1$  corresponding to the Matérn model with covariogram  $K(\cdot; \tau_0^2, \sigma_1^2, \phi_1, \nu)$ , with  $\sigma_1^2 := \kappa_0/\phi_1^{2\nu}$ .

*Proof.* With Assumption 2, the limits in (16) follow from Lemma 2 (3). By (12) and Theorem 2.4, we have

<span id="page-9-2"></span>
$$(19)\overline{n}(\tau_0^2 - \widehat{\tau}_n^2) = (1 + o(1)) \frac{\tau_0^2 \sqrt{n} \sum_{i=1}^n (1 - W_i^2) (a_{ni}^0)^2 + \sigma_1^2 \sqrt{n} \sum_{i=1}^n (1 - W_i^2) \lambda_i^n (a_{ni}^0)^2}{\sum_{i=1}^n W_i^2 (a_{ni}^0)^2}.$$

We know that  $\sum_{i=1}^n W_i^2(a_{ni}^0)^2 / \sum_{i=1}^n (a_{ni}^0)^2 \longrightarrow 1$ . In addition,

<span id="page-10-0"></span>(20)

$$\frac{\tau_0^2 \sqrt{n} \sum_{i=1}^n (1 - W_i^2)(a_{ni}^0)^2}{\sum_{i=1}^n (a_{ni}^0)^2} = \frac{\sum_{i=1}^n (1 - W_i^2)(a_{ni}^0)^2}{\sqrt{2 \sum_{i=1}^n (a_{ni}^0)^4}} \cdot \frac{\tau_0^2 \sqrt{2n \sum_{i=1}^n (a_{ni}^0)^4}}{\sum_{i=1}^n (a_{ni}^0)^2} \xrightarrow{(d)} \mathcal{N}(0, 2\tau_0^4 c_2/c_1^2),$$

where the first term on the right hand side converges to  $\mathcal{N}(0,1)$  by Lindeberg's central limit theorem, and the second term converges to  $\tau_0^2 \sqrt{2c_2}/c_1$ . Similarly,

<span id="page-10-1"></span>
$$\frac{\sigma_1^2 \sqrt{n} \sum_{i=1}^n (1 - W_i^2) \lambda_i^n (a_{ni}^0)^2}{\sum_{i=1}^n (a_{ni}^0)^2} = \frac{\sum_{i=1}^n (1 - W_i^2) \lambda_i^n (a_{ni}^0)^2}{\sqrt{2 \sum_{i=1}^n (\lambda_i^n)^2 (a_{ni}^0)^4}} \cdot \frac{\sigma_1^2 \sqrt{2n \sum_{i=1}^n (\lambda_i^n)^2 (a_{ni}^0)^4}}{\sum_{i=1}^n (a_{ni}^0)^2} \longrightarrow 0,$$

where the first term on the right hand side converges to  $\mathcal{N}(0,1)$ , and the second term converges to 0 since  $\sum_{i=1}^{n} (\lambda_i^n)^2 (a_{ni}^0)^4 \simeq n^{1/(1+2\nu/d)}$ . Combining (19), (20) and (21) leads to (17).

<span id="page-10-2"></span>By (15) and Theorem 2.4, we get

(22) 
$$n^{1/(2+4\nu/d)}(\widehat{\sigma}_n^2 - \sigma_1^2) = (1 + o(1)) \frac{n^{1/(2+4\nu/d)} \sum_{i=1}^n b_{ni}^0(W_i^2 - 1)}{\sum_{i=1}^n (b_{ni}^0)^2 W_i^2}.$$

Moreover,

$$\frac{n^{1/(2+4\nu/d)} \sum_{i=1}^{n} b_{ni}^{0}(W_{i}^{2}-1)}{\sum_{i=1}^{n} (b_{ni}^{0})^{2} W_{i}^{2}} = \frac{\sum_{i=1}^{n} b_{ni}^{0}(W_{i}^{2}-1)}{\sqrt{2} \sum_{i=1}^{n} (b_{ni}^{0})^{2}} \cdot \frac{\sqrt{2} n^{1/(2+4\nu/d)}}{\sqrt{\sum_{i=1}^{n} (b_{ni}^{0})^{2}}} \cdot \frac{\sum_{i=1}^{n} (b_{ni}^{0})^{2}}{\sum_{i=1}^{n} (b_{ni}^{0})^{2} W_{i}^{2}}$$

$$(23) \qquad \qquad \xrightarrow{(d)} \mathcal{N}(0, 2/c_{3}),$$

<span id="page-10-3"></span>where the first term on the right hand side converges to  $\mathcal{N}(0,1)$ , the second term converges to  $\sqrt{2/c_3}$ , and the third term converges to 1. Combining (22) and (23) yields (18).

Du et al. [2009] showed that for the Matérn model without measurement error, the maximum likelihood estimator  $\hat{\sigma}_n^2$  converges to  $\sigma_1^2$  at a  $\sqrt{n}$ -rate. Theorem 2.5 shows that in the presence of measurement error, the maximum likelihood estimator  $\hat{\tau}_n^2$  has a  $\sqrt{n}$ -rate while  $\hat{\sigma}_n^2$  has a slower  $n^{1/(2+4\nu/d)}$ -rate. This echoes the results of Ying [1991], Chen et al. [2000] with  $\nu = \frac{1}{2}$  and d = 1 for the Ornstein-Uhlenbeck process, where the maximum likelihood estimator  $\hat{\sigma}_n^2$  converges at a  $\sqrt{n}$ -rate without measurement error, but at a  $\sqrt[4]{n}$ -rate in the presence of measurement error.

2.3. Interpolation at new locations. We now turn to predicting the value of the process at unobserved locations. Without the nugget (i.e.,  $\tau = 0$  in (1)), Stein [1988, 1993, 1999] establish that predictions under different measures tend to agree as sample size  $n \to \infty$ . However, in the presence of a nugget effect, the predictive variance of y(s) at an unobserved location may not decrease to zero with increasing sample size. In fact, the squared prediction error for any linear predictor is expected to be at least  $\tau^2$ . For example, let  $\hat{y}_0 = v^{\top}y$  be a linear predictor of  $y_0 = y(s_0)$  at the unobserved location  $s_0, s_0 \notin \chi_n$ . Let  $w = \{w(s_1), \ldots, w(s_n)\}, \ \epsilon = \{\epsilon(s_1), \ldots, \epsilon(s_n)\}, \ w_0 = w(s_0)$  and  $\epsilon_0 = \epsilon(s_0)$ . The expected squared prediction error satisfies

$$\mathbb{E}[(\widehat{y}_0 - y_0)^2] = \mathbb{E}[\{(v^\top w - w_0) + (v^\top \epsilon - \epsilon_0)\}^2] = \mathbb{E}[(v^\top w - w_0)^2] + \mathbb{E}[(v^\top \epsilon - \epsilon_0)^2] > \tau^2.$$

To see whether there can be a consistent linear (unbiased) estimate of the underlying process  $w(\cdot)$  at unobserved locations, consider the universal kriging estimator at an unobserved location  $s_0$  given by

<span id="page-11-0"></span>(24) 
$$\widehat{Z}_n(\tau^2, \sigma^2, \phi) := \gamma_n(\sigma^2, \phi)^{\top} \Gamma_n(\tau^2, \sigma^2, \phi)^{-1} y,$$

where  $\{\gamma_n(\sigma^2,\phi)\}_i := K_w(s_0 - s_i; \sigma^2,\phi,\nu)$ , and  $\{\Gamma_n(\tau^2,\sigma^2,\phi)\}_{ij} := K_w(s_i - s_j; \sigma^2,\phi,\nu) + \tau^2\delta_0(i-j)$  for  $i,j=1,\ldots,n$ . The interpolant  $\widehat{Z}_n(\tau^2,\sigma^2,\phi)$  provides a best linear unbiased estimate of  $w_0$  under the Matérn model with measurement error (4). By letting  $\{K_n(\phi)\}_{ij} := K_w(s_0 - s_i; 1,\phi,\nu)$ , we have the mean squared error of the estimator (24) follows

<span id="page-11-1"></span>(25) 
$$\operatorname{Var}_{\tau_{0}^{2},\sigma_{0}^{2},\phi_{0}} \{ \widehat{Z}_{n}(\tau^{2},\sigma^{2},\phi) - w_{0} \} = \sigma_{0}^{2} \{ 1 - 2\gamma_{n}(\sigma^{2},\phi)^{\top} \Gamma_{n}(\tau^{2},\sigma^{2},\phi)^{-1} \gamma_{n}(\sigma_{0}^{2},\phi_{0}) + \gamma_{n}(\sigma^{2},\phi)^{\top} \Gamma_{n}(\tau^{2},\sigma^{2},\phi)^{-1} K_{n}(\phi_{0}) \Gamma_{n}(\tau^{2},\sigma^{2},\phi)^{-1} \gamma_{n}(\sigma^{2},\phi) \} + \tau_{0}^{2} \gamma_{n}(\sigma^{2},\phi)^{\top} \Gamma_{n}(\tau^{2},\sigma^{2},\phi)^{-2} \gamma_{n}(\sigma^{2},\phi) ,$$

where  $\{\tau_0^2, \sigma_0^2, \phi_0\}$  are the true generating values of  $\{\sigma^2, \phi, \tau^2\}$ . Setting  $(\tau^2, \sigma^2, \phi) = (\tau_0^2, \sigma_0^2, \phi_0)$  in (25) yields

<span id="page-11-3"></span>
$$(26) \operatorname{Var}_{\tau_0^2, \sigma_0^2, \phi_0} \{ \widehat{Z}_n(\tau_0^2, \sigma_0^2, \phi_0) - w_0 \} = \sigma_0^2 \{ 1 - \gamma_n(\sigma_0^2, \phi_0)^{\mathsf{T}} \Gamma_n(\tau_0^2, \sigma_0^2, \phi_0)^{-1} \gamma_n(\sigma_0^2, \phi_0) \}$$

Theorem 8 in Chapter 3 of Stein [1999] characterizes the mean squared error of the best linear unbiased estimate at location 0 as  $\frac{(2\pi c)^{1/\alpha}}{\alpha \sin{(\pi/\alpha)}} \left(\delta \tau^2\right)^{1-1/\alpha}$  with observations at  $\delta j$  for  $j \neq 0$ .

Here  $\alpha := 2\nu + 1$  and  $c := C\sigma^2\phi^{2\nu}$  with C defined in (3). Following the same argument, it is not hard to see that the mean squared error of the best linear unbiased estimate (based on data in  $\mathbb{R}^d$ ) is of order  $\delta^{2\nu/(2\nu+d)}$ . Stein [1999] proved this for observations on the whole line (with a typo in the expression (44) of Stein [1999]). He also conjectured that the above expression for the mean-square error holds for data on any finite interval. We conduct simulations in Section 3.4 with the nugget effect to corroborate this.

2.4. Covariance tapering. Covariance tapering [Furrer et al., 2006, Kaufman et al., 2008, Du et al., 2009] approximates the likelihood by setting certain entries of the covariance matrix to zero to introduce sparsity and, hence, achieve computational benefits. In the presence of a nugget, we explore parameter estimation for the Matérn model (4) with covariance tapering, which, too, have been investigated without the nugget by Wang et al. [2011]. Let  $K_{taper}(x;\gamma)$  be a tapering function, which is an isotropic correlation function such that  $K_{taper}(x;\gamma) = 0$  for  $|x| > \gamma$ . The tapered covariogram of the Matérn model with measurement error is given by

<span id="page-11-2"></span>(27) 
$$\widetilde{K}(x;\tau^2,\sigma^2,\phi,\nu,\gamma) = K(x;\tau^2,\sigma^2,\phi,\nu) K_{taper}(x;\gamma) ,$$

where  $K(x; \tau^2, \sigma^2, \phi, \nu)$  is defined in (4). Recalling the notations from Section 2.2, we obtain the tapered covariance matrix of the observations  $y = (y_1, \dots, y_n)^{\top}$  as

(28) 
$$\widetilde{V}_n = V_n \circ T(\gamma) = \tau^2 I_n + K_n \circ T(\gamma),$$

and the (rescaled) negative log-likelihood is  $\widetilde{\ell}(\tau, \sigma^2, \phi) := \log \det \widetilde{V}_n + y^\top \widetilde{V}_n^{-1} y$ , where  $T(\gamma)$  is the  $n \times n$  matrix with (i, j)-th entry  $K_{taper}(s_i - s_j; \gamma)$  and  $\circ$  denotes the element-wise (Schur or Hadamard) matrix product. For any fixed  $\phi_1 > 0$ , let  $(\widehat{\tau}_{taper,n}^2(\phi_1), \widehat{\sigma}_{taper,n}^2(\phi_1))$  be the maximum likelihood estimators of the tapered Matérn model, i.e.,

(29) 
$$(\widehat{\tau}_{taper,n}^2(\phi_1), \widehat{\sigma}_{taper,n}^2(\phi_1)) = \operatorname{argmin}_{(\tau^2,\sigma^2) \in D} \widetilde{\ell}(\tau^2, \sigma^2, \phi_1).$$

To address the identifiability issue of the tapered Matérn model, we require the following assumption on the tapering function which is due to Kaufman et al. [2008].

<span id="page-12-0"></span>**Assumption 3.** The spectral density  $f_{taper}(u)$  of the tapering function  $K_{taper}(\cdot; \gamma)$  exists, and that there exist  $\varepsilon > \max\{\frac{d}{4}, 1 - \nu\}$  and  $M_{\varepsilon} < \infty$  such that

(30) 
$$f_{taper}(u) \le \frac{M_{\varepsilon}}{(1+u^2)^{\nu+\frac{d}{2}+\varepsilon}}, \quad u \ge 0.$$

<span id="page-12-3"></span>**Theorem 2.6.** For  $d \leq 3$ , let  $S \subset \mathbb{R}^d$  be a compact set. For i=1,2, let  $\widetilde{P}_i$  be the probability measure of the Gaussian process on S with mean zero and covariance  $\widetilde{K}(\cdot; \tau_i^2, \sigma_i^2, \phi_i, \nu, \gamma)$  defined by (27). Under the conditions in Assumption 3, we have the following results: (i) if  $\tau_1^2 \neq \tau_2^2$ , then  $\widetilde{P}_1 \perp \widetilde{P}_2$ ; and (ii) if  $\tau_1^2 = \tau_2^2$ , then  $\widetilde{P}_1 \equiv \widetilde{P}_2$  if and only if  $\sigma_1^2 \phi_1^{2\nu} = \sigma_2^2 \phi_2^{2\nu}$ .

*Proof.* We know [Kaufman et al., 2008, Theorem 1] that  $\widetilde{P}_i \equiv P_i$  for i = 1, 2 under Assumption 3. Therefore, the proof is an immediate consequence of our Theorem 2.1 in Section 2.

To progress further, we recall the crucial role of the eigenvalues of  $\frac{1}{\sigma^2}K_n$  in analyzing the maximum likelihood estimators of the Matérn covariogram parameters with measurement error. With covariance tapering, we need estimates on the eigenvalues of  $\frac{1}{\sigma^2}K_n \circ T(\gamma)$ . Let  $\{\widetilde{\lambda}_i^{(n)}, i=1,\ldots,n\}$  be the eigenvalues of  $\frac{1}{\sigma^2}K_n \circ T(\gamma)$  in decreasing order. Under Assumption 3, the spectral density  $\widetilde{f}$  of the tapered Matérn model with covariogram (27) satisfies  $\widetilde{f}(u) \asymp f(u) \asymp u^{-2\nu-d}$  ((B.1) in Kaufman et al. [2008]). By applying Theorem 2.3, we have for  $\max_{s \in S} \min_{1 \le i \le n} \|s - s_i\| \asymp n^{-1/d}$ ,

(31) 
$$\widetilde{\lambda}_i^{(n)} \le C n i^{-2\nu/d-1} \quad \text{for all } i = 1, \dots, n.$$

In order to further study the maximum likelihood estimates of the tapered Matérn model, we need some assumptions on the eigenvalues  $\{\widetilde{\lambda}_i^{(n)}, i=1,\ldots,n\}$ . The following two assumptions are analogues of Assumptions 1 and 2.

<span id="page-12-1"></span>**Assumption 4.** Assume that  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \asymp n^{-1/d}$ . There exists c > 0 such that

(32) 
$$\widetilde{\lambda}_i^{(n)} \ge cni^{-2\nu/d-1} \quad \text{for all } i = 1, \dots, n.$$

<span id="page-12-2"></span>**Assumption 5.** Let  $\chi_n = [0,1)^d \cap n^{-1/d} \mathbb{Z}^d$  be the regular grid. There exists  $A = A(\phi, \nu, d) > 0$  such that

(33) 
$$\widetilde{\lambda}_i^{(n)}/(ni^{-2\nu/d-1}) \to A \quad as \ n, i \to \infty$$

In Figure 2 we plot the values of  $\widetilde{\lambda}_i^{(n)}/(ni^{-2\nu-1})$  with sampled points on the regular grid  $[0,1)\cap n^{-1}\mathbb{Z}$  for  $\nu=0.9,1.5,\ n$  ranging from 500 to 4000, and  $i=n^{0.7},\ n^{0.8},\ n^{0.9}$ . The tapering function for obtaining  $\widetilde{\lambda}_i^{(n)}$  is a stationary Wendland function  $K_{taper}(x;\gamma)=(1-|x|/\gamma)_+^4(1+4|x|/\gamma)$  where  $\gamma=0.5$  [Wendland, 1995]. Consistent with Assumption 4 & 5, the profile plots of  $\widetilde{\lambda}_i^{(n)}/(ni^{-2\nu/d-1})$  flatten as n increases and the quantity  $\widetilde{\lambda}_i^{(n)}/(ni^{-2\nu-1})$  tends to converge as n,i become large.

Now we state the consistency results for the maximum likelihood estimators of the tapered Matérn model.

**Theorem 2.7.** Assume that 
$$(\tau_0^2, \sigma_0^2) \in D$$
,  $\chi_n := \{s_1, \dots, s_n\}$  satisfy  $\max_{s \in S} \min_{1 \le i \le n} ||s - s_i|| \times n^{-1/d}$  and  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \times n^{-1/d}$ ,

<span id="page-13-0"></span>![](_page_13_Figure_2.jpeg)

FIGURE 2. Trend of  $\widetilde{\lambda}_i^{(n)}/(ni^{-2\nu/d-1})$  for  $i=n^{\alpha}$  when the points are sampled on the regular grid  $[0,1) \cap n^{-1}\mathbb{Z}$ . Parameters  $\phi$  and  $\sigma^2$  in Matérn covariogram are set to be 1.0 and 1.0, respectively.

and the conditions in Assumption 3 hold. Let  $\widetilde{P}_0$  be the probability measure of the tapered Matérn model with covariogram  $\widetilde{K}(\cdot; \tau_0^2, \sigma_0^2, \phi_0, \nu, \gamma)$ .

- (1) We have  $\hat{\tau}_{taper,n}^2 \to \tau_0^2$  almost surely under  $\tilde{P}_0$ .
- (2) Assume that the conditions in Assumption 4 hold. Then  $\widehat{\sigma}_{taper,n}^2 \phi_1^{2\nu} \to \kappa_0$  almost surely under  $\widetilde{P}_0$
- (3) Assume that n is the  $d^{th}$  power of some positive integer,  $\chi_n = [0,1)^d \cap n^{-1/d}\mathbb{Z}^d$ , and the conditions in Assumptions 3 and 5 hold. Let  $\widetilde{a}_{ni}^0 := 1/(\tau_0^2 + \sigma_1^2 \widetilde{\lambda}_i^{(n)})$  and  $\widetilde{b}_{ni}^0 := \widetilde{\lambda}_i^{(n)} a_{ni}^0$  for  $1 \leq i \leq n$ . Then, there exist constants  $\widetilde{c}_1, \widetilde{c}_2, \widetilde{c}_3 > 0$  such that as  $n \to \infty$ ,

(34) 
$$\frac{1}{n} \sum_{i=1}^{n} (\widetilde{a}_{ni}^{0})^{2} \to \widetilde{c}_{1}, \quad \frac{1}{n} \sum_{i=1}^{n} (\widetilde{a}_{ni}^{0})^{4} \to \widetilde{c}_{2}, \quad \frac{1}{n^{1/(1+2\nu/d)}} \sum_{i=1}^{n} (\widetilde{b}_{ni}^{0})^{2} \to \widetilde{c}_{3}.$$

We also have

(35) 
$$\sqrt{n}(\widehat{\tau}_{taper,n}^2 - \tau_0^2) \xrightarrow{(d)} \mathcal{N}(0, 2\tau_0^4 \widetilde{c}_2/\widetilde{c}_1^2),$$
and

(36) 
$$n^{1/(2+4\nu/d)}(\widehat{\sigma}_{taper,n}^2 \phi_1^{2\nu} - \kappa_0) \xrightarrow{(d)} \mathcal{N}(0, 2\phi_1^{4\nu}/\widetilde{c}_3).$$

under  $\widetilde{P}_1$  corresponding to the tapered Matérn model with covariogram  $\widetilde{K}(\cdot; \tau_0^2, \sigma_1^2, \phi_1, \nu, \gamma)$ , with  $\sigma_1^2 := \kappa_0/\phi_1^{2\nu}$ .

*Proof.* From Theorem 2.6, we know that  $\widetilde{P}_0 \equiv \widetilde{P}_1$ . Under  $\widetilde{P}_1$ , the (rescaled) negative log-likelihood is written as

(37) 
$$\ell(\tau^2, \widehat{\tau}_{taper,n}^2, \phi_1) = \sum_{i=1}^n \frac{\tau_0^2 + \sigma_1^2 \widetilde{\lambda}_i^{(n)}}{\tau^2 + \widehat{\sigma}_{taper,n}^2 \widetilde{\lambda}_i^{(n)}} W_i^2 + \sum_{i=1}^n \log(\tau^2 + \widehat{\sigma}_{taper,n}^2 \widetilde{\lambda}_i^{(n)}) ,$$

where  $W_i \stackrel{iid}{\sim} \mathcal{N}(0,1)$ . The remainder of the proof follows analogously to Theorems 2.4 and 2.5 by using Assumptions 4 and 5 instead of Assumptions 1 and 2.

<span id="page-14-0"></span>2.5. Consistency and asymptotic normality for  $d \geq 5$ . In contrast to  $d \leq 3$ , the parameters  $\{\tau^2, \sigma^2, \phi\}$  are consistently estimable for  $d \geq 5$ . It is, therefore, of interest to establish if the maximum likelihood estimators of  $\{\tau^2, \sigma^2, \phi\}$  are consistent in  $d \geq 5$ . Here we consider a slightly weaker version of the problem which should offer sufficient insights into methods for Gaussian processes for  $d \geq 5$ .

Recall the development in Section 2.2. Since the scale parameter  $\phi_0$  is consistently estimable, there exists an estimator  $\widehat{\phi}'_n$  such that  $\widehat{\phi}'_n \to \phi_0$  almost surely  $(\widehat{\phi}'_n)$  can be any consistent estimator of  $\phi_0$ ). Let  $(\widehat{\tau}^2(\widehat{\phi}'_n), \widehat{\sigma}^2_n(\widehat{\phi}'_n))$  be the maximum likelihood estimators based on the estimator  $\widehat{\phi}'_n$ :

(38) 
$$(\widehat{\tau}^2(\widehat{\phi}'_n), \widehat{\sigma}_n^2(\widehat{\phi}'_n)) = \operatorname{argmin}_{(\tau^2, \sigma^2) \in D} \ell(\tau^2, \sigma^2, \widehat{\phi}'_n).$$

The next theorem establishes consistency of the maximum likelihood estimators  $(\widehat{\tau}^2(\widehat{\phi}'_n), \widehat{\sigma}^2_n(\widehat{\phi}'_n))$ .

**Theorem 2.8.** Assume that  $(\tau_0^2, \sigma_0^2) \in D$  and the locations in  $\chi_n := \{s_1, \ldots, s_n\}$  satisfy

$$\max_{s \in S} \min_{1 \le i \le n} ||s - s_i|| \simeq n^{-1/d}$$
 and  $\min_{1 \le i \ne j \le n} ||s_i - s_j|| \simeq n^{-1/d}$ .

Let  $P_0$  be the probability measure of the tapered Matérn model with covariogram  $K(\cdot; \tau_0^2, \sigma_0^2, \phi_0, \nu)$ .

- (1) We have  $\widehat{\tau}^2(\widehat{\phi}'_n) \to \tau_0^2$  almost surely under  $P_0$ .
- (2) Under Assumption 1,  $\widehat{\sigma}_n^2(\widehat{\phi}'_n) \to \sigma_0^2$  almost surely under  $P_0$ .
- (3) Let n be the  $d^{th}$  power of some positive integer,  $\chi_n = [0,1)^d \cap n^{-1/d}\mathbb{Z}^d$ , and suppose Assumption 2 holds. Let  $\overline{a}_{ni}^0 := 1/(\tau_0^2 + \sigma_0^2 \lambda_i^{(n)})$  and  $\overline{b}_{ni}^0 := \lambda_i^{(n)} \overline{a}_{ni}^0$  for  $1 \le i \le n$ . Then, there exist constants  $\overline{c}_1, \overline{c}_2, \overline{c}_3 > 0$  such that as  $n \to \infty$ ,

(39) 
$$\frac{1}{n} \sum_{i=1}^{n} (\overline{a}_{ni}^{0})^{2} \to \overline{c}_{1}, \quad \frac{1}{n} \sum_{i=1}^{n} (\overline{a}_{ni}^{0})^{4} \to \overline{c}_{2}, \quad \frac{1}{n^{1/(1+2\nu/d)}} \sum_{i=1}^{n} (\overline{b}_{ni}^{0})^{2} \to \overline{c}_{3}.$$

We also have

(40) 
$$\sqrt{n}(\widehat{\tau}^2(\widehat{\phi}'_n) - \tau_0^2) \xrightarrow{(d)} \mathcal{N}(0, 2\tau_0^4 \overline{c}_2/\overline{c}_1^2),$$

and

(41) 
$$n^{1/(2+4\nu/d)}(\widehat{\sigma}_n^2(\widehat{\phi}_n') - \sigma_0^2) \xrightarrow{(d)} \mathcal{N}(0, 2/\overline{c}_3).$$

Proof. To study the asymptotic properties of  $(\widehat{\tau}^2(\widehat{\phi}'_n), \widehat{\sigma}^2_n(\widehat{\phi}'_n))$ , it suffices to consider  $(\widehat{\tau}^2(\phi_0), \widehat{\sigma}^2_n(\phi_0)) = \underset{(\tau^2, \sigma^2) \in D}{\operatorname{argmin}}_{(\tau^2, \sigma^2) \in D} \ell(\tau^2, \sigma^2, \phi_0)$ . Recalling that  $P_0$  is the probability measure of the Matérn model with covariogram  $K(\cdot; \tau_0^2, \sigma_0^2, \phi_0, \nu)$ , the (rescaled) negative log-likelihood (5) is written as

(42) 
$$\ell(\tau^2, \sigma^2, \phi_0) = \sum_{i=1}^n \frac{\tau_0^2 + \sigma_0^2 \lambda_i^{(n)}}{\tau^2 + \sigma^2 \lambda_i^{(n)}} W_i^2 + \sum_{i=1}^n \log(\tau^2 + \sigma^2 \lambda_i^{(n)})$$

under  $P_0$ , where  $W_i \stackrel{iid}{\sim} \mathcal{N}(0,1)$ . The reasoning in Theorems 2.4 and 2.5 shows that  $(\widehat{\tau}^2(\phi_0), \widehat{\sigma}_n^2(\phi_0))$  are consistent and are asymptotically normal under various assumptions. As a result, the same holds for  $(\widehat{\tau}^2(\widehat{\phi}'_n), \widehat{\sigma}_n^2(\widehat{\phi}'_n))$ . This completes the proof.

#### 3. Simulations

- <span id="page-15-1"></span>3.1. **Set-up.** The preceding results help explain the behaviour of the inference from (1) as the sample size increases within a fixed domain. Here, we present some simulation experiments to illustrate statistical inference for finite samples. We simulate data sets based on (1) in a unit square setting  $\nu = 1/2$  and  $\sigma^2 = 1$ . We pick three different values of the nugget,  $\tau^2 \in \{0, 0.2, 0.8\}$ , and choose the decay parameter  $\phi$  so that the effective spatial range is 0.15, 0.4 or 1, i.e., the correlation decays to 0.05 at a distance of 0.15, 0.4 or 1 units. Therefore, we consider  $3 \times 3 = 9$  different parameter settings. For each parameter setting, we simulate 1000 realizations of the Gaussian process over n = 1600 observed locations. The observed locations are chosen from a perturbed grid. We construct a  $67 \times 67$  regular grid with coordinates from 0.005 to 0.995 in increments of 0.015 in each dimension. We add a uniform  $[-0.005, 0.005]^2$  perturbation to each grid point to ensure at least 0.005 units separation from its nearest neighbour. We then choose n = 1600 locations out of the perturbed grid. Codes for studies in this Section are available on https://github.com/LuZhangstat/nugget\_consistency.
- 3.2. Likelihood comparisons. Theorem 2.1 suggests that it is difficult to distinguish between the two Matérn models with measurement error when their microergodic parameters  $\{\kappa, \tau^2\}$  are close to each other. This property should be reflected in the behaviour of the likelihood function for a large finite sample. To see this, we plot interpolated maps of the log-likelihood among different grids of parameter values. We consider the three values of  $\tau_0^2$  in Section 3.1 and  $\phi_0 = 7.49$ , which implies an effective spatial range of approximately 0.4 units, and pick n = 900 observations from the first realization generated from (1). This yields three different data sets corresponding to the three values of  $\tau_0^2$ . We map the negative one-half of the log-likelihood in (5).

The interpolated maps of the log-likelihood are provided in Fig. 3 as a function of  $(\tau^2, \phi)$  in the first two rows and of  $(\sigma^2, \phi)$  in the third row. The first column presents cases with  $\tau_0 = 0$ , while the second and the third columns are for  $\tau_0 = 0.2$  and 0.8, respectively. The grid for  $\phi$  ranges from 2.5 to 30 so that the effective spatial ranges between 0.1 and 1.2. We specify the range of  $\tau^2$  and  $\sigma^2$  to be (0.0, 1.0) and (0.2, 4.2), respectively, so that the pattern of the log-likelihood map around the true generating values of parameters can be captured. All the interpolated maps, including the contour lines, are drawn to the same scale.

The first row of Figure 3 corresponds to  $\sigma^2 = \sigma_0^2 = 1$ , the second row corresponds to  $\kappa = \kappa_0$  and the third row corresponds to  $\tau^2 = \tau_0^2$ . In the first row, we observe that similar log-likelihoods are located along parallel lines  $\phi + \tau^2 = Const$ . This suggests that one can identify the maximum with either a fixed  $\phi$  or  $\tau^2$  when  $\sigma^2 = \sigma_0^2$ . In the second row, we find that contours for high log-likelihood values are situated around the actual generating value of the nugget, supporting the identifiability of the nugget as provided in Theorem 2.1. The log-likelihood along the  $\phi$ -axis has a flat tail as  $\phi$  decreases when fixing the nugget, which indicates having the same value of the microergodic parameter  $\kappa = \sigma^2 \phi^{2\nu}$  can result in equivalent probability measures (Theorem 2.1). Finally, the third row reveals that the log-likelihood closely follows the curve  $\sigma^2 \phi = Const$ , thereby corroborating Theorem 2.1.

<span id="page-15-0"></span>3.3. Parameter estimation. We use maximum likelihood estimators to illustrate the asymptotic properties of the parameter estimates. To find the maximum likelihood estimators

of  $\{\sigma^2, \tau^2, \phi, \kappa\}$ , we use the log of the profile likelihood for  $\phi$  and  $\eta = \tau^2/\sigma^2$ , given by

<span id="page-16-1"></span>(43) 
$$\log \{\mathcal{PL}(\phi, \eta)\} \propto -\frac{1}{2} \log \left[\det \{\rho(\phi) + \eta I_n\}\right] - \frac{n}{2}$$
$$-\frac{n}{2} \log \left[\frac{1}{n} y^{\top} \{\rho(\phi) + \eta I_n\}^{-1} y\right]$$

where  $\log\{\mathcal{PL}(\phi,\eta)\} = \log[\sup_{\sigma^2}\{\mathcal{L}(\sigma^2,\phi,\eta)\}]$ ,  $\rho(\phi)$  is the correlation matrix of the underlying process  $w(\cdot)$  over observed locations  $\chi_n$ . We optimize (43) to obtain maximum likelihood estimators  $\widehat{\phi}$  and  $\widehat{\eta}$ . The maximum likelihood estimator for  $\sigma^2$  is  $\widehat{\sigma}_n^2 = y^{\top} \{\rho(\widehat{\phi}) + \widehat{\eta}I_n\}^{-1}y/n$ . Calculations were executed using the R function optimx using the Broyden-Fletcher-Goldfarb-Shanno algorithm [Fletcher, 2013] with  $\phi > 0$  and  $\eta > 0$ , and  $\eta = 0$  for models without a nugget.

We calculate estimators for  $\{\tau^2, \phi, \sigma^2, \kappa\}$  for each realization with sample sizes 400, 900 and 1600. For each parameter setting and sample size, there are 1000 estimators for  $\{\tau^2, \phi, \sigma^2\}$  and  $\kappa$ . Figure 4 depicts the histograms for the maximum likelihood estimators for  $\tau^2$ ,  $\phi$ ,  $\sigma^2$  and  $\kappa$  obtained from simulations with the parameter setting  $\{\phi_0, \tau_0^2\} = \{7.49, 0.2\}$ . There is an obvious shrinkage of the variance of estimators for  $\tau^2$  and  $\kappa$  as we increase the sample size from 400 to 1600. We also observe that their distribution becomes more symmetric with an increasing sample size. In contrast, the variance of the estimators for  $\sigma^2$  and  $\phi$  do not have a significant decrease as sample size increases. This is supported by the infill asymptotic results. The maximum likelihood estimators for  $\tau^2$  and  $\tau^2$  are not consistent and asymptotically normal. The maximum likelihood estimators for  $\tau^2$  and  $\tau^2$  are not consistent and, hence, their variances do not decrease to zero with increasing sample size.

Table 1–4 list percentiles, biases, and sample standard deviations for the estimates of  $\tau^2$ ,  $\phi$ ,  $\sigma^2$  and  $\kappa$  for each of the 9 parameter settings and offer further insights about the finite sample inference. When the spatial correlation is strong ( $\phi$  is small),  $\hat{\tau}^2$  tends to be more precise, while  $\hat{\sigma}^2$  tends to have more variability. Unsurprisingly, the measurement error is easily distinguished from a less variable latent process  $w(\cdot)$ . Highly correlated realizations of  $w(\cdot)$  results in less precise inference for  $\sigma^2$ . If the nugget is larger, then the estimators for  $\phi$ ,  $\sigma^2$  and  $\kappa$  are less precise; the presence of measurement error weakens the precision of the estimates.

<span id="page-16-0"></span>3.4. **Interpolation.** We use the kriging estimator in (24) and its mean squared prediction error (MSPE) in (25) to explore spatial interpolation in the presence of the nugget. We use (24) to predict the underlying process  $w(\cdot)$  over unobserved locations. From Theorem 8 in Chapter 3 of Stein [1999], we expect a clear trend of convergence for d=1. Let  $\nu=1/2$ ,  $\tau_0^2=0.2$ ,  $\sigma_0^2=1.0$  and  $\phi_0=7.49$ . We use (1) to generate observations over 12,000 randomly picked locations in [0,1]. We compute the MSPE using 3 hold-out points  $\{0.25, 0.5, 0.75\} \in [0,1]$  for different subsets of the data with sample sizes ranging from 500 to 12,000. Figure 5(a) shows that the MSPE tends to approach 0 as sample size increases. This corroborates Stein's conjecture that the underlying process  $w(\cdot)$  in (1) can be consistently estimated on a finite interval.

Next, we use the simulated data set with n = 1600 locations over the unit square used in Section 3.3. We calculate the MSPE using (25) and (26) over a  $50 \times 50$  regular grid of locations over  $[0, 1]^2$ . This is repeated for different data sets with sample sizes varying between 400 and 1600. Figure 5(b) shows that the MSPE decreases as sample size increases. This trend

still holds when the predictor is formed under misspecified models, a finding similar to those in Kaufman and Shaby [2013] without the nugget. If  $\nu$  is fixed at the true generating value, then predictions under any parameter setting are consistent and asymptotically efficient with no nugget effect. The proof in Kaufman and Shaby [2013] is based on Stein [1993], hence their results do not carry over to our setting due to the discontinuity in our covariogram at 0. (This technical difficulty was also pointed out by [Yakowitz and Szidarovszky, 1985, p.38]). However, their results suggest empirical studies to explore the asymptotic properties of interpolation.

To compare with results in Kaufman and Shaby [2013, Section 2.3], we examine two ratios

i) 
$$\frac{\operatorname{Var}_{\tau_0^2, \sigma_0^2, \phi_0} \{\widehat{z}_n(\tau_1^2, \sigma_1^2, \phi_1) - w_0\}}{\operatorname{Var}_{\tau_0^2, \sigma_0^2, \phi_0} \{\widehat{z}_n(\tau_0^2, \sigma_0^2, \phi_0) - w_0\}}, \text{ and ii) } \frac{\operatorname{Var}_{\tau_1^2, \sigma_1^2, \phi_1} \{\widehat{z}_n(\tau_0^2, \sigma_1^2, \phi_1) - w_0\}}{\operatorname{Var}_{\tau_0^2, \sigma_0^2, \phi_0} \{\widehat{z}_n(\tau_0^2, \sigma_1^2, \phi_1) - w_0\}}.$$

Figure 5(c) compares the ratio defined by i). This ratio tends to approach 1 only when  $\tau_1^2 = \tau_0^2$  and  $\kappa = \kappa_0$ . Unlike the case with no nugget, asymptotic efficiency is only observed when the estimator is fitted under models with Gaussian measures equivalent to the generating Gaussian measure. Figure 5(d) plots the ratio defined by ii). As in Fig. 5(c), this ratio also tends to approach 1 only when  $\tau_1^2 = \tau_0^2$ ,  $\kappa = \kappa_0$ . Based on our simulation study, we posit that the asymptotic efficiency and asymptotically correct estimation of MSPE hold only when  $\tau_1^2 = \tau_0^2$ ,  $\kappa = \kappa_0$ .

<span id="page-17-0"></span>3.5. Bayesian inference from finite samples. The asymptotic results in the preceding sections imply that a misspecified value of  $\phi$  does not violate the consistency and asymptotic normality of the maximum likelihood estimator of the nugget  $\tau^2$  or of the microergodic parameter  $\kappa = \sigma^2 \phi^{2\nu}$ . In order to assess the extent to which these asymptotic results can guide practical implementation of model fitting for finite samples, we conduct a sensitivity test to check the stability of the inferences of  $\tau^2$  and  $\kappa$  from finite samples under different specifications for  $\phi$ . Here, we present inferences for  $\tau^2$  and  $\kappa$  based on a Bayesian analysis using finite samples.

We generate data over n=1,600 observed locations situated on the perturbed grid described in Section 3.1. We use a zero-centered Matérn model with measurement error to generate the data, where  $\nu=1/2$ ,  $\sigma^2=1$ ,  $\tau^2=0.5$  and  $\phi=9.98$ . We fit the simulated data through a zero-centered Matérn model with measurement error with  $\mathrm{IG}(2,1/2)$  and  $\mathrm{IG}(2,1)$  priors for  $\tau^2$  and  $\sigma^2$ , respectively. When assuming  $\phi$  is unknown, we use a Gamma prior with shape 2 and rate  $2/\phi_0$  for  $\phi$ , where  $\phi_0$  is the true value of  $\phi$  for the simulated data. We specified prior distributions with means equal to the data generating parameter values. We also fit the model with  $\phi$  equal to 0.2, 0.5, 1, 2, and 5 times the value of  $\phi_0$ . We randomly select n=400, 900 and 1,600 samples for model fitting. The posterior inferences are based on 4 MCMC chains, each with 500 iterations for burn-in and 500 iterations for sampling. All models are implemented in cmdstanr [Gabry and Češnovar, 2020]. The reported  $\hat{R}$  (R-hat) values for all parameters are no more than 1.02 and the reported effective sample size for all parameters are greater than 400, showing adequate convergence of all MCMC chains.

Figure 6 illustrates the posterior distributions of  $\tau^2$  and  $\kappa$ . As expected from Theorem 7, the variance of the posterior distributions decrease with increasing values of n. The posterior distributions for  $\kappa$  and  $\tau^2$  approach the truth as n increases, but the inference can be highly biased when  $\phi$  is misspecified. The results for  $\kappa$  are similar to those reported by Kaufman and Shaby [2013] for a zero-centered Matérn model without measurement error. We observe stabler posterior inference of  $\tau^2$  than  $\kappa$  for the cases when  $\phi$  is unknown or fixed at values no

more than φ0. The case when φ = 5φ<sup>0</sup> calls for some additional remarks. Here, the effective spatial range (i.e., the distance beyond which the spatial correlation drops to 0.05) is only about 4% of the maximum inter-site distance in our domain. Hence, the spatial correlation is negligible making it difficult to distinguish the nugget τ 2 from the "partial sill" σ <sup>2</sup> and inference is sensitive to the prior specification. This is a plausible explanation for the poorer estimates of τ <sup>2</sup> when φ = 5φ0.

## 4. Discussion

We have developed insights into inference under infill asymptotics of Gaussian process parameters in the context of spatial or geostatistical analysis in the presence of the nugget effect. Our work can be regarded as an extension of similar investigations without the nugget effect. While geostatistical modelling usually applies to R <sup>d</sup> with d ≤ 3, we have also developed some new insights into d ≥ 5, where consistency of the MLE's for the Mat´ern model remains unresolved even without the nugget.

We have discussed the complications in establishing consistency and asymptotic efficiency in parameter estimation and spatial prediction due to the discontinuity introduced by the nugget. Tools in standard spectral analysis no longer work in this scenario. Understanding the behaviour of such processes will enhance our understanding of identifiability of process parameters. For example, the failure to consistently estimate certain (non-microergodic) parameters can also be useful for Bayesian inference where we can conclude that the effect of the likelihood will never overwhelm the prior when calculating the posterior distribution of non-microergodic parameters. Section [3.5](#page-17-0) presented some insights into the behaviour of Bayesian estimates for the nugget in the presence of a misspecified range parameter. Formal investigations into the consistency of the posterior distributions of Mat´ern covariogram parameters are certainly of interest and can be built upon some of our developments in the current manuscript.

We anticipate further research in variants of geostatistical models with the nugget. For example, one can explore whether some results, such as Theorem 2 in [Kaufman and Shaby](#page-19-3) [\[2013\]](#page-19-3) where φ is estimated, will hold for the Mat´ern model with the nugget. Our simulations also suggest further research in asymptotic efficiency provided in Theorem 3 of [Kaufman and](#page-19-3) [Shaby \[2013\]](#page-19-3) in the presence of the nugget. With recent interest in scalable Gaussian process models, we can investigate asymptotic properties of approximations indicated on the lines of [Vecchia \[1988\]](#page-19-23) and Section 10.5.3 in [Zhang \[2012\]](#page-20-2); [also see [Banerjee, 2017,](#page-19-24) for scalable spatial process models in Bayesian settings]. In Bayesian contexts, understanding posterior consistency for the nugget will offer insights into classes of priors. Finally, we point out that the conditions in Assumptions [1](#page-5-4) and [2](#page-6-1) about eigenvalue estimates are expected and their rigorous proofs will constitute future research, as will further theoretical explorations on Gaussian processes in R d for all values of d.. In particular, a rigorous proof of Assumption [2](#page-6-1) is challenging and will be of interest in general kernel methods and bandit problems.

### Acknowledgements

We thank Robert Schaback for various pointers to the literature and stimulating discussions. We thank the Editor, the Associate Editor, and two anonymous referees for several useful suggestions that have helped improve the manuscript. The work of the authors were supported, in part, by federal grants NSF/DMS 1916349, 2113778 and 2113779; NSF/IIS 1562303; and NIH/NIEHS 1R01ES027027.

#### References

- <span id="page-19-7"></span>[1] Milton Abramowitz and Irene A Stegun. Handbook of Mathematical Functions: with Formulas, Graphs, and Mathematical Tables. Dover, 1965.
- <span id="page-19-9"></span>[2] Ethan Anderes. On the consistent separation of scale and variance for Gaussian random fields. The Annals of Statistics, 38(2):870–893, 2010.
- <span id="page-19-24"></span>[3] Sudipto Banerjee. High-Dimensional Bayesian Geostatistics. Bayesian Analysis, 12(2):583 – 614, 2017. doi: 10.1214/17-BA1056R. URL <https://doi.org/10.1214/17-BA1056R>.
- <span id="page-19-10"></span>[4] Mikhail Belkin. Approximation beats concentration? An approximation view on inference with smooth radial kernels. In Conference On Learning Theory, COLT 2018, pages 1348–1361, 2018.
- <span id="page-19-4"></span>[5] Moreno Bevilacqua, Tarik Faouzi, Reinhard Furrer, and Emilio Porcu. Estimation and prediction using generalized Wendland covariance functions under fixed domain asymptotics. Ann. Statist., 47(2):828–856, 2019.
- <span id="page-19-6"></span>[6] Huann-Sheng Chen, Douglas G. Simpson, and Zhiliang Ying. Infill asymptotics for a stochastic process model with measurement error. Statistica Sinica, pages 141–156, 2000.
- <span id="page-19-2"></span>[7] Juan Du, Hao Zhang, and VS Mandrekar. Fixed-domain asymptotic properties of tapered maximum likelihood estimators. The Annals of Statistics, 37(6A):3330–3361, 2009.
- <span id="page-19-15"></span>[8] Rick Durrett. Probability—theory and examples, volume 49 of Cambridge Series in Statistical and Probabilistic Mathematics. Cambridge University Press, 2019. Fifth edition.
- <span id="page-19-14"></span>[9] Nasrollah Etemadi. Convergence of weighted averages of random variables revisited. Proceedings of the American Mathematical Society, 134(9):2739–2744, 2006.
- <span id="page-19-21"></span>[10] Roger Fletcher. Practical methods of optimization. John Wiley & Sons, 2013.
- <span id="page-19-18"></span>[11] Reinhard Furrer, Marc G Genton, and Douglas Nychka. Covariance tapering for interpolation of large spatial datasets. Journal of Computational and Graphical Statistics, 15:503–523, 2006.
- <span id="page-19-22"></span>[12] Jonah Gabry and Rok Ceˇsnovar. ˇ cmdstanr: R Interface to 'CmdStan', 2020. https://mcstan.org/cmdstanr, https://discourse.mc-stan.org.
- <span id="page-19-8"></span>[13] Ildar Abdulovich Ibragimov and Yurii Antol'evich Rozanov. Gaussian random processes, volume 9 of Applications of Mathematics. Springer-Verlag, New York-Berlin, 1978. Translated from the Russian by A. B. Aries.
- <span id="page-19-13"></span>[14] Joseph W Jerome. Asymptotic estimates of the n-widths in Hilbert space. Proceedings of the American Mathematical Society, 33(2):367–372, 1972.
- <span id="page-19-19"></span>[15] Cari G. Kaufman, Mark J. Schervish, and Douglas W. Nychka. Covariance tapering for likelihoodbased estimation in large spatial data sets. J. Amer. Statist. Assoc., 103(484):1545–1555, 2008.
- <span id="page-19-3"></span>[16] CG Kaufman and Benjamin Adam Shaby. The role of the range parameter for estimation and prediction in geostatistics. Biometrika, 100(2):473–484, 2013.
- <span id="page-19-5"></span>[17] Pulong Ma and Anindya Bhadra. Kriging: Beyond Mat´ern. arXiv preprint arXiv:1911.05865, 2019.
- <span id="page-19-0"></span>[18] Bertil Mat´ern. Spatial Variation. Springer-Verlag, 1986.
- <span id="page-19-11"></span>[19] Gabriele Santin and Robert Schaback. Approximation of eigenfunctions in kernel-based spaces. Advances in Computational Mathematics, 42(4):973–993, 2016.
- <span id="page-19-12"></span>[20] Robert Schaback. Error estimates and condition numbers for radial basis function interpolation. Advances in Computational Mathematics, 3(3):251–264, 1995.
- <span id="page-19-16"></span>[21] Michael L Stein. Asymptotically efficient prediction of a random field with a misspecified covariance function. The Annals of Statistics, pages 55–63, 1988.
- <span id="page-19-17"></span>[22] Michael L Stein. A simple condition for asymptotic optimality of linear predictions of random fields. Statistics & Probability Letters, 17(5):399–404, 1993.
- <span id="page-19-1"></span>[23] Michael L Stein. Interpolation of Spatial Data: Some Theory for Kriging. Springer-Verlag, 1999.
- <span id="page-19-23"></span>[24] Aldo V Vecchia. Estimation and model identification for continuous spatial processes. Journal of the Royal Statistical society, Series B, 50:297–312, 1988.
- <span id="page-19-20"></span>[25] Daqing Wang, Wei-Liem Loh, et al. On fixed-domain asymptotics and covariance tapering in gaussian random field models. Electronic Journal of Statistics, 5:238–269, 2011.

- <span id="page-20-4"></span>[26] Holger Wendland. Piecewise polynomial, positive definite and compactly supported radial functions of minimal degree. Advances in computational Mathematics, 4(1):389–396, 1995.
- <span id="page-20-5"></span>[27] SJ Yakowitz and F Szidarovszky. A comparison of kriging with nonparametric regression methods. Journal of Multivariate Analysis, 16(1):21–53, 1985.
- <span id="page-20-3"></span>[28] Zhiliang Ying. Asymptotic properties of a maximum likelihood estimator with data from a Gaussian process. Journal of Multivariate Analysis, 36(2):280–296, 1991.
- <span id="page-20-1"></span>[29] Hao Zhang. Inconsistent estimation and asymptotically equal interpolations in model-based geostatistics. Journal of the American Statistical Association, 99(465):250–261, 2004.
- <span id="page-20-2"></span>[30] Hao Zhang. Asymptotics and computation for spatial statistics. In Advances and Challenges in Space-time Modelling of Natural Events, pages 239–252. Springer, 2012.
- <span id="page-20-0"></span>[31] Hao Zhang and Dale L Zimmerman. Towards reconciling two asymptotic frameworks in spatial statistics. Biometrika, 92(4):921–936, 2005.

<span id="page-21-0"></span>Table 1. Summary of estimates of τ 2 : percentiles, bias, and sample standard deviations (SD).

| 2<br>τ<br>0 | φ0     | n    | 5%    | 25%   | 50%   | 75%   | 95%   | BIAS   | SD    |
|-------------|--------|------|-------|-------|-------|-------|-------|--------|-------|
| 0.200       | 19.972 | 400  | 0.000 | 0.111 | 0.189 | 0.269 | 0.382 | -0.007 | 0.112 |
|             |        | 900  | 0.102 | 0.159 | 0.197 | 0.235 | 0.289 | -0.004 | 0.056 |
|             |        | 1600 | 0.141 | 0.175 | 0.199 | 0.221 | 0.252 | -0.002 | 0.035 |
|             |        |      |       |       |       |       |       |        |       |
|             | 7.489  | 400  | 0.110 | 0.162 | 0.197 | 0.232 | 0.281 | -0.003 | 0.053 |
|             |        | 900  | 0.157 | 0.181 | 0.198 | 0.216 | 0.238 | -0.002 | 0.025 |
|             |        | 1600 | 0.170 | 0.187 | 0.199 | 0.211 | 0.227 | -0.001 | 0.017 |
|             |        |      |       |       |       |       |       |        |       |
|             | 2.996  | 400  | 0.152 | 0.177 | 0.196 | 0.217 | 0.248 | -0.003 | 0.029 |
|             |        | 900  | 0.173 | 0.188 | 0.199 | 0.212 | 0.227 | 0.000  | 0.017 |
|             |        | 1600 | 0.182 | 0.191 | 0.200 | 0.208 | 0.219 | 0.000  | 0.012 |
|             |        |      |       |       |       |       |       |        |       |
| 0.800       | 19.972 | 400  | 0.321 | 0.619 | 0.777 | 0.903 | 1.090 | -0.047 | 0.229 |
|             |        | 900  | 0.615 | 0.725 | 0.792 | 0.861 | 0.974 | -0.009 | 0.110 |
|             |        | 1600 | 0.682 | 0.746 | 0.795 | 0.841 | 0.910 | -0.006 | 0.069 |
|             |        |      |       |       |       |       |       |        |       |
|             | 7.489  | 400  | 0.582 | 0.714 | 0.789 | 0.859 | 0.974 | -0.015 | 0.114 |
|             |        | 900  | 0.689 | 0.752 | 0.794 | 0.835 | 0.897 | -0.006 | 0.065 |
|             |        | 1600 | 0.725 | 0.768 | 0.799 | 0.826 | 0.869 | -0.003 | 0.044 |
|             |        |      |       |       |       |       |       |        |       |
|             | 2.996  | 400  | 0.662 | 0.738 | 0.789 | 0.845 | 0.931 | -0.007 | 0.081 |
|             |        | 900  | 0.720 | 0.766 | 0.797 | 0.828 | 0.871 | -0.004 | 0.047 |
|             |        | 1600 | 0.737 | 0.775 | 0.799 | 0.823 | 0.856 | -0.002 | 0.036 |

<span id="page-22-0"></span>![](_page_22_Figure_1.jpeg)

![](_page_22_Figure_2.jpeg)

![](_page_22_Figure_3.jpeg)

FIGURE 3. Interpolated maps of the log-likelihood. Darker shades indicate higher values. The first row corresponds to  $\sigma^2 = \sigma_0^2 = 1$ , the second row corresponds to  $\sigma^2 \phi = \phi_0 = 7.49$ , and the third row corresponds to  $\tau_0 = \tau_0^2$ . The columns correspond to  $\tau_0 = 0.0$ ,  $\tau_0 = 0.2$ , and  $\tau_0 = 0.8$ , respectively.

<span id="page-23-0"></span>![](_page_23_Figure_2.jpeg)

Figure 4. Histograms of τ 2 (top row), σ 2 (second row), φ (third row) and κ = σ 2φ 2ν (fourth row) obtained from simulation experiments with φ<sup>0</sup> = 7.49, τ <sup>2</sup> <sup>0</sup> = 0.2.

<span id="page-24-0"></span>![](_page_24_Figure_1.jpeg)

FIGURE 5. The MSPE for  $w(\cdot)$  at (a) unobserved locations with study domain [0,1] (b) a  $50 \times 50$  grid over  $[0,1]^2$ . The ratio of mean square predict error (ratio) for testing asymptotic efficiency (c) and asymptotically correct estimation of MSPE (d)

<span id="page-25-0"></span>![](_page_25_Figure_2.jpeg)

Figure 6. Posterior distributions for (a) τ <sup>2</sup> and (b) κ obtained from the simulation studies in Section [3.5.](#page-17-0) The decay parameter is either estimated via MCMC sampling (unknown), fixed at the true value φ0, or fixed at a multiples of φ0, viz. {0.2φ0, . . . , 5φ0}. The three boxplots in each group correspond to sample sizes of n = 400, 900, and 1, 600 reading from left to right. The dashed line indicates the true value.

Table 2. Summary of estimates of φ: percentiles, bias, and sample standard deviations(SD)

| 2<br>τ<br>0 | φ0     | n    | 5%     | 25%    | 50%    | 75%    | 95%    | BIAS  | SD    |
|-------------|--------|------|--------|--------|--------|--------|--------|-------|-------|
| 0.000       | 19.972 | 400  | 16.151 | 18.355 | 19.992 | 21.798 | 25.003 | 0.223 | 2.708 |
|             |        | 900  | 16.706 | 18.642 | 20.072 | 21.548 | 23.928 | 0.182 | 2.185 |
|             |        | 1600 | 17.077 | 18.800 | 20.041 | 21.403 | 23.557 | 0.144 | 1.968 |
|             |        |      |        |        |        |        |        |       |       |
|             | 7.489  | 400  | 5.237  | 6.680  | 7.643  | 8.830  | 10.792 | 0.324 | 1.672 |
|             |        | 900  | 5.430  | 6.722  | 7.659  | 8.655  | 10.382 | 0.280 | 1.511 |
|             |        | 1600 | 5.520  | 6.730  | 7.664  | 8.687  | 10.245 | 0.255 | 1.450 |
|             |        |      |        |        |        |        |        |       |       |
|             | 2.996  | 400  | 1.584  | 2.489  | 3.297  | 4.315  | 5.859  | 0.479 | 1.339 |
|             |        | 900  | 1.605  | 2.468  | 3.316  | 4.298  | 5.792  | 0.463 | 1.299 |
|             |        | 1600 | 1.624  | 2.490  | 3.259  | 4.279  | 5.613  | 0.448 | 1.281 |
|             |        |      |        |        |        |        |        |       |       |
| 0.200       | 19.972 | 400  | 13.626 | 17.185 | 20.058 | 23.260 | 28.138 | 0.358 | 4.427 |
|             |        | 900  | 15.117 | 17.938 | 20.059 | 22.188 | 26.097 | 0.221 | 3.321 |
|             |        | 1600 | 15.749 | 18.328 | 19.972 | 21.728 | 25.02  | 0.158 | 2.779 |
|             |        |      |        |        |        |        |        |       |       |
|             | 7.489  | 400  | 4.596  | 6.271  | 7.757  | 9.377  | 12.430 | 0.535 | 2.364 |
|             |        | 900  | 5.081  | 6.521  | 7.820  | 9.179  | 11.572 | 0.480 | 1.998 |
|             |        | 1600 | 5.195  | 6.557  | 7.774  | 9.079  | 11.391 | 0.410 | 1.838 |
|             |        |      |        |        |        |        |        |       |       |
|             | 2.996  | 400  | 1.436  | 2.291  | 3.244  | 4.415  | 6.725  | 0.563 | 1.707 |
|             |        | 900  | 1.534  | 2.383  | 3.243  | 4.269  | 6.405  | 0.48  | 1.518 |
|             |        | 1600 | 1.570  | 2.420  | 3.217  | 4.208  | 6.130  | 0.453 | 1.424 |
|             |        |      |        |        |        |        |        |       |       |
| 0.800       | 19.972 | 400  | 11.804 | 16.533 | 20.359 | 24.806 | 33.859 | 1.315 | 6.932 |
|             |        | 900  | 14.650 | 17.405 | 20.077 | 23.065 | 27.831 | 0.490 | 4.175 |
|             |        | 1600 | 15.340 | 17.911 | 20.197 | 22.544 | 26.195 | 0.396 | 3.352 |
|             |        |      |        |        |        |        |        |       |       |
|             | 7.489  | 400  | 3.878  | 6.029  | 7.754  | 9.866  | 14.034 | 0.670 | 3.038 |
|             |        | 900  | 4.468  | 6.266  | 7.745  | 9.317  | 12.249 | 0.475 | 2.402 |
|             |        | 1600 | 4.691  | 6.430  | 7.735  | 9.142  | 11.663 | 0.405 | 2.157 |
|             |        |      |        |        |        |        |        |       |       |
|             | 2.996  | 400  | 1.259  | 2.281  | 3.279  | 4.723  | 7.385  | 0.681 | 1.975 |
|             |        | 900  | 1.443  | 2.364  | 3.249  | 4.38   | 7.199  | 0.603 | 1.771 |
|             |        | 1600 | 1.479  | 2.382  | 3.216  | 4.263  | 6.591  | 0.509 | 1.602 |

Table 3. Summary of estimates of σ 2 : percentiles, bias, and sample standard deviations(SD)

| 2<br>τ<br>0 | φ0     | n      | 5%    | 25%   | 50%   | 75%   | 95%   | BIAS   | SD    |
|-------------|--------|--------|-------|-------|-------|-------|-------|--------|-------|
| 0.000       | 19.972 | 400    | 0.835 | 0.928 | 0.992 | 1.063 | 1.172 | -0.004 | 0.103 |
|             |        | 900    | 0.859 | 0.938 | 0.997 | 1.063 | 1.155 | 0.001  | 0.091 |
|             |        | 1600   | 0.865 | 0.942 | 0.998 | 1.057 | 1.151 | 0.002  | 0.087 |
|             |        |        |       |       |       |       |       |        |       |
|             | 7.489  | 400    | 0.721 | 0.860 | 0.976 | 1.109 | 1.374 | 0.000  | 0.198 |
|             |        | 900    | 0.724 | 0.872 | 0.980 | 1.104 | 1.344 | 0.001  | 0.192 |
|             |        | 1600   | 0.733 | 0.871 | 0.978 | 1.111 | 1.356 | 0.002  | 0.189 |
|             |        |        |       |       |       |       |       |        |       |
|             | 2.996  | 400    | 0.527 | 0.700 | 0.905 | 1.217 | 1.856 | 0.014  | 0.446 |
|             |        | 900    | 0.532 | 0.708 | 0.900 | 1.216 | 1.843 | 0.010  | 0.427 |
|             |        | 1600   | 0.537 | 0.705 | 0.914 | 1.204 | 1.845 | 0.011  | 0.423 |
| 0.200       | 19.972 | 400    | 0.735 | 0.890 | 1.012 | 1.127 | 1.280 | 0.009  | 0.167 |
|             |        | 900    | 0.830 | 0.928 | 1.001 | 1.085 | 1.203 | 0.008  | 0.114 |
|             |        | 1600   | 0.860 | 0.941 | 1.000 | 1.071 | 1.170 | 0.008  | 0.097 |
|             |        |        |       |       |       |       |       |        |       |
|             | 7.489  | 400    | 0.706 | 0.848 | 0.978 | 1.129 | 1.435 | 0.006  | 0.22  |
|             |        | 900    | 0.732 | 0.855 | 0.972 | 1.128 | 1.373 | 0.002  | 0.203 |
|             |        | 1600   | 0.731 | 0.857 | 0.970 | 1.116 | 1.374 | 0.000  | 0.195 |
|             |        |        |       |       |       |       |       |        |       |
|             | 2.996  | 400    | 0.527 | 0.700 | 0.905 | 1.217 | 1.856 | 0.014  | 0.446 |
|             |        | 900    | 0.532 | 0.708 | 0.900 | 1.216 | 1.843 | 0.010  | 0.427 |
|             |        | 1600   | 0.537 | 0.705 | 0.914 | 1.204 | 1.845 | 0.011  | 0.423 |
|             |        |        |       |       |       |       |       |        |       |
| 0.800       | 400    | 19.972 | 0.653 | 0.874 | 1.025 | 1.208 | 1.531 | 0.050  | 0.265 |
|             |        | 900    | 0.761 | 0.911 | 1.014 | 1.110 | 1.257 | 0.011  | 0.149 |
|             |        | 1600   | 0.826 | 0.931 | 1.009 | 1.085 | 1.197 | 0.009  | 0.113 |
|             |        |        |       |       |       |       |       |        |       |
|             | 7.489  | 400    | 0.640 | 0.848 | 1.004 | 1.174 | 1.487 | 0.027  | 0.263 |
|             |        | 900    | 0.701 | 0.862 | 0.990 | 1.146 | 1.421 | 0.016  | 0.225 |
|             |        | 1600   | 0.710 | 0.860 | 0.985 | 1.129 | 1.413 | 0.012  | 0.215 |
|             | 2.996  | 400    | 0.482 | 0.715 | 0.955 | 1.254 | 1.916 | 0.047  | 0.482 |
|             |        | 900    | 0.517 | 0.720 | 0.950 | 1.240 | 1.874 | 0.044  | 0.462 |
|             |        | 1600   | 0.524 | 0.735 | 0.968 | 1.250 | 1.839 | 0.045  | 0.449 |
|             |        |        |       |       |       |       |       |        |       |

<span id="page-28-0"></span>Table 4. Summary of estimates of κ: percentiles, bias, and sample standard deviations(SD)

| 2<br>τ<br>0 | φ0     | n          | 5%             | 25%            | 50%            | 75%            | 95%            | BIAS           | SD             |
|-------------|--------|------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|
| 0.000       | 19.972 | 400        | 17.200         | 18.596         | 19.752         | 21.117         | 23.197         | -0.045         | 1.881          |
|             |        | 900        | 18.098         | 19.221         | 19.957         | 20.798         | 21.974         | 0.035          | 1.177          |
|             |        | 1600       | 18.764         | 19.457         | 19.973         | 20.531         | 21.399         | 0.039          | 0.805          |
|             |        |            |                |                |                |                |                |                |                |
|             | 7.489  | 400        | 6.538          | 7.092          | 7.499          | 7.943          | 8.568          | 0.032          | 0.619          |
|             |        | 900        | 6.903          | 7.236          | 7.500          | 7.784          | 8.146          | 0.018          | 0.387          |
|             |        | 1600       | 7.061          | 7.317          | 7.491          | 7.680          | 7.979          | 0.013          | 0.280          |
|             |        |            |                |                |                |                |                |                |                |
|             | 2.996  | 400        | 2.666          | 2.869          | 3.004          | 3.158          | 3.369          | 0.018          | 0.213          |
|             |        | 900        | 2.780          | 2.915          | 3.001          | 3.103          | 3.254          | 0.012          | 0.142          |
|             |        | 1600       | 2.841          | 2.935          | 3.000          | 3.077          | 3.191          | 0.011          | 0.106          |
|             |        |            |                |                |                |                |                |                |                |
| 0.200       | 19.972 | 400        | 11.760         | 16.227         | 20.111         | 24.691         | 31.242         | 0.677          | 6.052          |
|             |        | 900        | 14.827         | 17.806         | 19.879         | 22.566         | 26.735         | 0.313          | 3.693          |
|             |        | 1600       | 16.421         | 18.434         | 19.943         | 21.624         | 24.404         | 0.186          | 2.528          |
|             | 7.489  | 400        | 5.116          | 6.546          | 7.552          | 8.825          | 11.045         | 0.268          | 1.802          |
|             |        | 900        | 5.999          | 6.843          | 7.605          | 8.404          | 9.645          | 0.177          | 1.110          |
|             |        | 1600       | 6.197          | 7.033          | 7.585          | 8.141          | 9.085          | 0.105          | 0.850          |
|             |        |            |                |                |                |                |                |                |                |
|             | 2.996  | 400        | 2.010          | 2.546          | 3.040          | 3.533          | 4.322          | 0.092          | 0.716          |
|             |        | 900        | 2.282          | 2.706          | 3.028          | 3.343          | 3.900          | 0.055          | 0.493          |
|             |        | 1600       | 2.434          | 2.779          | 3.012          | 3.292          | 3.724          | 0.040          | 0.384          |
|             |        |            |                |                |                |                |                |                |                |
| 0.800       | 19.972 | 400        | 8.846          | 15.161         | 20.858         | 28.202         | 47.108         | 3.314          | 12.319         |
|             |        | 900        | 12.700         | 16.839         | 20.077         | 24.320         | 31.399         | 0.830          | 5.715          |
|             |        | 1600       | 14.846         | 17.751         | 20.215         | 22.941         | 26.997         | 0.530          | 3.888          |
|             |        |            |                |                |                |                |                |                |                |
|             | 7.489  | 400        | 4.080          | 5.980          | 7.677          | 9.679          | 13.537         | 0.591          | 2.929          |
|             |        | 900        | 5.084          | 6.394          | 7.626          | 8.923          | 10.918         | 0.269          | 1.808          |
|             |        | 1600       | 5.598          | 6.675          | 7.622          | 8.546          | 10.030         | 0.169          | 1.361          |
|             |        |            |                |                |                |                |                |                |                |
|             | 2.996  | 400<br>900 | 1.708<br>1.999 | 2.444<br>2.626 | 3.093<br>3.114 | 3.849<br>3.666 | 5.432<br>4.534 | 0.259<br>0.185 | 1.175<br>0.789 |
|             |        | 1600       | 2.210          | 2.712          | 3.086          | 3.478          | 4.210          | 0.129          | 0.618          |
|             |        |            |                |                |                |                |                |                |                |