# MASSACHUSETTS INSTITUTE OF TECHNOLOGY

6.265/15.070J Fall 2013 Lecture 8 9/30/2013

# Quadratic variation property of Brownian motion

# Content.

- 1. Unbounded variation of a Brownian motion.
- 2. Bounded quadratic variation of a Brownian motion.

### 1 Unbounded variation of a Brownian motion

Any sequence of values 0 < t<sup>0</sup> < t<sup>1</sup> < · · · < t<sup>n</sup> < T is called a partition Π = Π(t0, . . . , tn) of an interval [0, T]. Given a continuous function f : [0, T] → R its *total variation* is defined to be

$$LV(f) \triangleq \sup_{\Pi} \sum_{1 \le k \le n} |f(t_k) - f(t_{k-1})|,$$

where the supremum is taken over all possible partitions Π of the interval [0, T] for all n. A function f is defined to have bounded variation if its total variation is finite.

Theorem 1. *Almost surely no path of a Brownian motion has bounded variation for every* T ≥ 0*. Namely, for every* T

$$\mathbb{P}(\omega : LV(B(\omega)) < \infty) = 0.$$

The main tool is to use the following result from real analysis, which we do not prove: if a function f has bounded variation on [0, T] then it is differentiable almost everywhere on [0, T]. We will now show that quite the opposite is true.

Proposition 1. *Brownian motion is almost surely nowhere differentiable. Specifically,* 

$$\mathbb{P}(\forall \ t \geq 0: \limsup_{h \to 0} |\frac{B(t+h) - B(t)}{h}| = \infty) = 1.$$

*Proof.* Fix T > 0, M > 0 and consider  $A(M,T) \subset C[0,\infty)$  – the set of all paths  $\omega \in C[0,\infty)$  such that there exists at least one point  $t \in [0,T]$  such that

$$\limsup_{h \to 0} \left| \frac{B(t+h) - B(t)}{h} \right| \le M.$$

We claim that  $\mathbb{P}(A(M,T))=0$ . This implies  $\mathbb{P}(\cup_{M\geq 1}A(M,T))=0$  which is what we need. Then we take a union of the sets A(M,T) with increasing T and conclude that B is almost surely nowhere differentiable on  $[0,\infty)$ . If  $\omega\in A(M,T)$ , then there exists  $t\in [0,T]$  and n such that  $|B(s)-B(t)|\leq 2M|s-t|$  for all  $s\in (t-\frac{2}{n},t+\frac{2}{n})$ . Now define  $A_n\subset C[0,\infty)$  to be the set of all paths  $\omega$  such that for some  $t\in [0,T]$ 

$$|B(s) - B(t)| \le 2M|s - t|$$

for all  $s \in (t - \frac{2}{n}, t + \frac{2}{n})$ . Then

$$A_n \subset A_{n+1} \tag{1}$$

and

$$A(M,T) \subset \cup_n A_n. \tag{2}$$

Find  $k = \max\{j : \frac{j}{n} \le t\}$ . Define

$$Y_k = \max\{|B(\frac{k+2}{n}) - B(\frac{k+1}{n})|, |B(\frac{k+1}{n}) - B(\frac{k}{n})|, |B(\frac{k}{n}) - B(\frac{k-1}{n})|\}.$$

In other words, consider the maximum increment of the Brownian motion over these three short intervals. We claim that  $Y_k \leq 6M/n$  for every path  $\omega \in A_n$ .

To prove the bound required bound on  $Y_k$  we first consider

$$|B(\frac{k+2}{n}) - B(\frac{k+1}{n})| \le |B(\frac{k+2}{n}) - B(t)| + |B(t) - B(\frac{k+1}{n})|$$

$$\le 2M\frac{2}{n} + 2M\frac{1}{n}$$

$$\le \frac{6M}{n}.$$

The other two differences are analyzed similarly.

Now consider event  $B_n$  which is the set of all paths  $\omega$  such that  $Y_k(\omega) \leq 6M/n$  for some  $0 \leq k \leq Tn$ . We showed that  $A_n \subset B_n$ . We claim that  $\lim_n \mathbb{P}(B_n) =$ 

0. Combining this with (1), we conclude  $\mathbb{P}(A_n) = 0$ . Combining with (2), this will imply that  $\mathbb{P}(A(M,T)) = 0$  and we will be done.

Now to obtain the required bound on  $\mathbb{P}(B_n)$  we note that, since the increments of a Brownian motion are independent and identically distributed, then

$$\mathbb{P}(B_n) \leq \sum_{0 \leq k \leq T_n} \mathbb{P}(Y_k \leq 6M/n) 
\leq Tn \mathbb{P}(\max\{|B(\frac{3}{n}) - B(\frac{2}{n})|, |B(\frac{2}{n}) - B(\frac{1}{n})|, |B(\frac{1}{n}) - B(0)|\} \leq 6M/n) 
= Tn[\mathbb{P}(|B(\frac{1}{n})| \leq 6M/n)]^3.$$
(3)

Finally, we just analyze this probability. We have

$$\mathbb{P}(|B(\frac{1}{n})| \le 6M/n) = \mathbb{P}(|B(1)| \le 6M/\sqrt{n}).$$

Since B(1) which has the standard normal distribution, its density at any point is at most  $1/\sqrt{2\pi}$ , then we have that this probability is at a most  $(2(6M)/\sqrt{2\pi n})$ . We conclude that the expression in (3) is, ignoring constants,  $O(n(1/\sqrt{n})^3) = O(1/\sqrt{n})$  and thus converges to zero as  $n \to \infty$ . We proved  $\lim_n \mathbb{P}(B_n) = 0$ .

### 2 Bounded *quadratic* variation of a Brownian motion

Even though Brownian motion is nowhere differentiable and has unbounded total variation, it turns out that it has bounded *quadratic* variation. This observation is the cornerstone of Ito calculus, which we will study later in this course.

We again start with partitions  $\Pi = \Pi(t_0, \dots, t_n)$  of a fixed interval [0, T], but now consider instead

$$Q(\Pi, B) \triangleq \sum_{1 \le k \le n} (B(t_k) - B(t_{k-1}))^2.$$

where, we make (without loss of generality)  $t_0=0$  and  $t_n=T$ . For every partition  $\Pi$  define

$$\Delta(\Pi) = \max_{1 \le k \le n} |t_k - t_{k-1}|.$$

**Theorem 2.** Consider an arbitrary sequence of partitions  $\Pi_i$ ,  $i=1,2,\ldots$  Suppose  $\lim_{i\to\infty} \Delta(\Pi_i)=0$ . Then

$$\lim_{i \to \infty} \mathbb{E}[(Q(\Pi_i, B) - T)^2] = 0. \tag{4}$$

Suppose in addition  $\lim_{i\to\infty} i^2 \Delta(\Pi_i) = 0$  (that is the resolution  $\Delta(\Pi_i)$  converges to zero faster than  $1/i^2$ ). Then almost surely

$$Q(\Pi_i, B) \to T.$$
 (5)

In words, the standard Brownian motion has almost surely finite quadratic variation which is equal to T.

*Proof.* We will use the following fact. Let Z be a standard Normal random variable. Then  $\mathbb{E}[Z^4]=3$  (cute, isn't it?). The proof can be obtained using Laplace transforms of Normal random variables or integration by parts, and we skip the details.

Let  $\theta_i = (B(t_i) - B(t_{i-1}))^2 - (t_i - t_{i-1})$ . Then, using the independent Gaussian increments property of Brownian motion,  $\theta_i$  is a sequence of independent zero mean random variables. We have

$$Q(\Pi_i) - T = \sum_{1 \le i \le n} \theta_i.$$

Now consider the second moment of this difference

$$\mathbb{E}(Q(\Pi_i) - T)^2 = \sum_{1 \le i \le n} \mathbb{E}(B(t_i) - B(t_{i-1}))^4$$
$$-2\sum_{1 \le i \le n} \mathbb{E}(B(t_i) - B(t_{i-1}))^2 (t_i - t_{i-1}) + \sum_{1 \le i \le n} (t_i - t_{i-1})^2.$$

Using the  $\mathbb{E}[Z^4] = 3$  property, this expression becomes

$$\sum_{1 \le i \le n} 3(t_i - t_{i-1})^2 - 2 \sum_{1 \le i \le n} (t_i - t_{i-1})^2 + \sum_{1 \le i \le n} (t_i - t_{i-1})^2$$

$$= 2 \sum_{1 \le i \le n} (t_i - t_{i-1})^2$$

$$\le 2\Delta(\Pi_i) \sum_{1 \le i \le n} (t_i - t_{i-1})$$

$$= 2\Delta(\Pi_i)T.$$

Now if  $\lim_i \Delta(\Pi_i) = 0$ , then the bound converges to zero as well. This establishes the first part of the theorem.

To prove the second part identify a sequence  $\epsilon_i \to 0$  such that  $\Delta(\Pi_i) = \epsilon_i/i^2$ . By assumption, such a sequence exists. By Markov's inequality, this is

bounded by

$$\mathbb{P}((Q(\Pi_i) - T)^2 > 2\epsilon_i) \le \frac{\mathbb{E}(Q(\Pi_i) - T)^2}{2\epsilon_i} \le \frac{2\Delta(\Pi_i)T}{2\epsilon_i} = \frac{T}{i^2}$$
 (6)

<sup>T</sup> Since <sup>i</sup> <sup>i</sup><sup>2</sup> <sup>&</sup>lt; <sup>∞</sup>, then the sum of probabilities in (6) is finite. Then applying the Borel-Cantelli Lemma, the probability that (Q(Πi) − T)<sup>2</sup> > 2E<sup>i</sup> for infinitely many i is zero. Since E<sup>i</sup> → 0, this exactly means that almost surely, lim<sup>i</sup> Q(Πi) = T.

#### 3 Additional reading materials

• Sections 6.11 and 6.12 of Resnick's [1] chapter 6 in the book.

# References

[1] S. Resnick, *Adventures in stochastic processes*, Birkhuser Boston, Inc., 1992.

# MIT OpenCourseWare <http://ocw.mit.edu>

15.070J / 6.265J Advanced Stochastic Processes Fall 2013

For information about citing these materials or our Terms of Use, visit: <http://ocw.mit.edu/terms>.