# Mean squared error

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

In <u>statistics</u>, the **mean squared error** (MSE) or **mean squared deviation** (MSD) of an <u>estimator</u> (of a procedure for estimating an unobserved quantity) measures the <u>average</u> of the squares of the <u>errors</u>—that is, the average squared difference between the estimated values and the <u>true value</u>. MSE is a <u>risk function</u>, corresponding to the <u>expected value</u> of the <u>squared error loss</u>. The fact that MSE is almost always strictly positive (and not zero) is because of <u>randomness</u> or because the estimator <u>does not account for information</u> that could produce a more accurate estimate. In <u>machine learning</u>, specifically <u>empirical risk minimization</u>, MSE may refer to the <u>empirical risk</u> (the average loss on an observed data set), as an estimate of the true MSE (the true risk: the average loss on the actual population distribution).

The MSE is a measure of the quality of an estimator. As it is derived from the square of Euclidean distance, it is always a positive value that decreases as the error approaches zero.

The MSE is the second <u>moment</u> (about the origin) of the error, and thus incorporates both the <u>variance</u> of the estimator (how widely spread the estimates are from one <u>data sample</u> to another) and its <u>bias</u> (how far off the average estimated value is from the true value). [citation needed] For an <u>unbiased estimator</u>, the MSE is the variance of the estimator. Like the variance, MSE has the same units of measurement as the square of the quantity being estimated. In an analogy to <u>standard deviation</u>, taking the square root of MSE yields the root-mean-square error or <u>root-mean-square deviation</u> (RMSE or RMSD), which has the same units as the quantity being estimated; for an unbiased estimator, the RMSE is the square root of the <u>variance</u>, known as the <u>standard error</u>.

# **Definition and basic properties**

#### [edit]

The MSE either assesses the quality of a <u>predictor</u> (i.e., a function mapping arbitrary inputs to a sample of values of some <u>random variable</u>), or of an <u>estimator</u> (i.e., a <u>mathematical function</u> mapping a <u>sample</u> of data to an estimate of a <u>parameter</u> of the <u>population</u> from which the data is sampled). In the context of prediction, understanding the <u>prediction</u> interval can also be useful as it provides a range within which a future

observation will fall, with a certain probability. The definition of an MSE differs according to whether one is describing a predictor or an estimator.

If a vector of

n predictions is generated from a sample of n

data points on all variables, and

Y

is the vector of observed values of the variable being predicted, with

 $\hat{Y}$ 

being the predicted values (e.g. as from a <u>least-squares fit</u>), then the within-sample MSE of the predictor is computed as

$$ext{MSE} = rac{1}{n} \sum_{i=1}^n \left( Y_i - \hat{Y_i} 
ight)^2$$

In other words, the MSE is the mean

 $\left(\frac{1}{n}\sum_{i=1}^{n}\right)$ 

of the squares of the errors

$$\left(Y_i - \hat{Y_i}
ight)^2$$

. This is an easily computable quantity for a particular sample (and hence is sample-dependent).

In matrix notation,

$$ext{MSE} = rac{1}{n} \sum_{i=1}^n (e_i)^2 = rac{1}{n} \mathbf{e}^\mathsf{T} \mathbf{e}^\mathsf{T}$$

where

 $e_i$ 

is

 $Y_i - \hat{Y_i}$ 

and

 $\mathbf{e}$ 

is a

 $n \times 1$ 

column vector.

The MSE can also be computed on *q* data points that were not used in estimating the model, either because they were held back for this purpose, or because these data have been newly obtained. Within this process, known as <u>cross-validation</u>, the MSE is often called the <u>test MSE</u>, and is computed as

$$ext{MSE} = rac{1}{N} \sum_{i=1}^{n+q} \left(Y_i - \hat{Y_i}
ight)^2$$

$$q \underset{i=n+1}{\smile}$$

The MSE of an estimator

 $\hat{\theta}$ 

with respect to an unknown parameter

 $\theta$ 

is defined as

$$ext{MSE}(\hat{ heta}) = ext{E}_{ heta} \Big[ (\hat{ heta} - heta)^2 \Big].$$

This definition depends on the unknown parameter, therefore the MSE is a *priori* property of an estimator. The MSE could be a function of unknown parameters, in which case any *estimator* of the MSE based on estimates of these parameters would be a function of the data (and thus a random variable). If the estimator

 $\hat{\theta}$ 

is derived as a sample statistic and is used to estimate some population parameter, then the expectation is with respect to the <u>sampling distribution</u> of the sample statistic.

The MSE can be written as the sum of the <u>variance</u> of the estimator and the squared <u>bias</u> of the estimator, providing a useful way to calculate the MSE and implying that in the case of unbiased estimators, the MSE and variance are equivalent.

$$\mathrm{MSE}(\hat{ heta}) = \mathrm{Var}_{ heta}(\hat{ heta}) + \mathrm{Bias}(\hat{ heta}, heta)^2.$$

## Proof of variance and bias relationship

[edit]

$$\begin{split} \operatorname{MSE}(\hat{\theta}) &= \operatorname{E}_{\theta} \Big[ (\hat{\theta} - \theta)^2 \Big] \\ &= \operatorname{E}_{\theta} \Big[ (\hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] + \operatorname{E}_{\theta}[\hat{\theta}] - \theta)^2 \Big] \\ &= \operatorname{E}_{\theta} \Big[ (\hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}])^2 + 2 \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right) \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right) + \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right)^2 \Big] \\ &= \operatorname{E}_{\theta} \Big[ \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right)^2 \Big] + \operatorname{E}_{\theta} \Big[ 2 \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right) \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right) \Big] + \operatorname{E}_{\theta} \Big[ \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right)^2 \Big] \\ &= \operatorname{E}_{\theta} \Big[ \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right)^2 \Big] + 2 \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right) \operatorname{E}_{\theta} \Big[ \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \Big] + \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right)^2 \\ &= \operatorname{E}_{\theta} \Big[ \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right)^2 \Big] + 2 \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right) \left( \operatorname{E}_{\theta}[\hat{\theta}] - \operatorname{E}_{\theta}[\hat{\theta}] \right) + \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right)^2 \\ &= \operatorname{E}_{\theta} \Big[ \left( \hat{\theta} - \operatorname{E}_{\theta}[\hat{\theta}] \right)^2 \Big] + \left( \operatorname{E}_{\theta}[\hat{\theta}] - \theta \right)^2 \\ &= \operatorname{Var}_{\theta}(\hat{\theta}) + \operatorname{Bias}_{\theta}(\hat{\theta}, \theta)^2 \end{split}$$

An even shorter proof can be achieved using the well-known formula that for a random variable

X

 $\mathbb{E}(X^2) = \mathrm{Var}(X) + (\mathbb{E}(X))^2$ 

.[citation needed] By substituting

X

with,

$$\hat{ heta} - heta$$

, we have

$$egin{aligned} ext{MSE}(\hat{ heta}) &= \mathbb{E}[(\hat{ heta} - heta)^2] \ &= ext{Var}(\hat{ heta} - heta) + (\mathbb{E}[\hat{ heta} - heta])^2 \ &= ext{Var}(\hat{ heta}) + ext{Bias}^2(\hat{ heta}, heta) \end{aligned}$$

But in real modeling case, MSE could be described as the addition of model variance, model bias, and irreducible uncertainty (see <u>Bias-variance tradeoff</u>). According to the relationship, the MSE of the estimators could be simply used for the <u>efficiency</u> comparison, which includes the information of estimator variance and bias. This is called MSE criterion.

In <u>regression analysis</u>, plotting is a more natural way to view the overall trend of the whole data. The mean of the distance from each point to the predicted regression model can be calculated, and shown as the mean squared error. The squaring is critical to reduce the complexity with negative signs. To minimize MSE, the model could be more accurate, which would mean the model is closer to actual data. One example of a linear regression using this method is the <u>least squares method</u>—which evaluates appropriateness of linear regression model to model <u>bivariate dataset</u>, but whose limitation is related to known distribution of the data.

The term  $mean\ squared\ error$  is sometimes used to refer to the unbiased estimate of error variance: the <u>residual sum of squares</u> divided by the number of <u>degrees of freedom</u>. This definition for a known, computed quantity differs from the above definition for the computed MSE of a predictor, in that a different denominator is used. The denominator is the sample size reduced by the number of model parameters estimated from the same data, (n-p) for p <u>regressors</u> or (n-p-1) if an intercept is used (see <u>errors</u> and <u>residuals</u> in <u>statistics</u> for more details). Although the MSE (as defined in this article) is not an unbiased estimator of the error variance, it is <u>consistent</u>, given the consistency of the predictor.

In regression analysis, "mean squared error", often referred to as <u>mean squared</u> <u>prediction error</u> or "out-of-sample mean squared error", can also refer to the mean value of the <u>squared deviations</u> of the predictions from the true values, over an out-of-sample <u>test space</u>, generated by a model estimated over a <u>particular sample space</u>. This also is a known, computed quantity, and it varies by sample and by out-of-sample test space.

In the context of gradient descent algorithms, it is common to introduce a factor of

to the MSE for ease of computation after taking the derivative. So a value which is technically half the mean of squared errors may be called the MSE.

Suppose we have a random sample of size

n

from a population,

selection for all

$$X_1, \ldots, X_n$$

. Suppose the sample units were chosen with replacement. That is, the units are selected one at a time, and previously selected units are still eligible for

r

draws. The usual estimator for the population mean

 $\mu$ 

is the sample average

$$\overline{X} = rac{1}{n} \sum_{i=1}^n X_i$$

which has an expected value equal to the true mean

 $\mu$ 

(so it is unbiased) and a mean squared error of

$$ext{MSE}\Big(\overline{X}\Big) = ext{E}igg[\Big(\overline{X} - \mu\Big)^2igg] = \Big(rac{\sigma}{\sqrt{n}}\Big)^2 = rac{\sigma^2}{n}$$

where

 $\sigma^2$ 

is the population variance.

For a <u>Gaussian distribution</u> this is the <u>best unbiased estimator</u> of the population mean, that is the one with the lowest MSE (and hence variance) among all unbiased estimators. One can check that the MSE above equals the inverse of the <u>Fisher information</u> (see <u>Cramér–Rao bound</u>). But the same sample mean is not the best estimator of the population mean, say, for a uniform distribution.

The usual estimator for the variance is the corrected sample variance:

$$S_{n-1}^2=rac{1}{n-1}\sum_{i=1}^n\left(X_i-\overline{X}
ight)^2=rac{1}{n-1}\left(\sum_{i=1}^nX_i^2-n\overline{X}^2
ight).$$

This is unbiased (its expected value is

 $\sigma^2$ 

), hence also called the unbiased sample variance, and its MSE is

$$ext{MSE}(S^2_{n-1}) = rac{1}{n}\left(\mu_4 - rac{n-3}{n-1}\sigma^4
ight) = rac{1}{n}\left(\gamma_2 + rac{2n}{n-1}
ight)\sigma^4,$$

where

$$\mu_4$$

is the fourth central moment of the distribution or population, and

$$\gamma_2 = \mu_4/\sigma^4 - 3$$

is the excess kurtosis.

However, one can use other estimators for

 $\sigma^2$ 

which are proportional to

$$S_{n-1}^2$$

, and an appropriate choice can always give a lower mean squared error. If we define

$$S_a^2 = rac{n-1}{a} S_{n-1}^2 = rac{1}{a} \sum_{i=1}^n \left( X_i - \overline{X} \, 
ight)^2$$

then we calculate:

$$\begin{split} \operatorname{MSE}(S_{a}^{2}) &= \operatorname{E}\left[\left(\frac{n-1}{a}S_{n-1}^{2} - \sigma^{2}\right)^{2}\right] \\ &= \operatorname{E}\left[\frac{(n-1)^{2}}{a^{2}}S_{n-1}^{4} - 2\left(\frac{n-1}{a}S_{n-1}^{2}\right)\sigma^{2} + \sigma^{4}\right] \\ &= \frac{(n-1)^{2}}{a^{2}}\operatorname{E}\left[S_{n-1}^{4}\right] - 2\left(\frac{n-1}{a}\right)\operatorname{E}\left[S_{n-1}^{2}\right]\sigma^{2} + \sigma^{4} \\ &= \frac{(n-1)^{2}}{a^{2}}\operatorname{E}\left[S_{n-1}^{4}\right] - 2\left(\frac{n-1}{a}\right)\sigma^{4} + \sigma^{4} \\ &= \frac{(n-1)^{2}}{a^{2}}\left(\frac{\gamma_{2}}{n} + \frac{n+1}{n-1}\right)\sigma^{4} - 2\left(\frac{n-1}{a}\right)\sigma^{4} + \sigma^{4} \\ &= \frac{n-1}{na^{2}}\left((n-1)\gamma_{2} + n^{2} + n\right)\sigma^{4} - 2\left(\frac{n-1}{a}\right)\sigma^{4} + \sigma^{4} \end{split}$$

$$\begin{split} \operatorname{E}\left[S_{n-1}^{4}\right] &= \operatorname{MSE}(S_{n-1}^{2}) + \sigma^{4} \\ &= \frac{n-1}{na^{2}}\left((n-1)\gamma_{2} + n^{2} + n\right)\sigma^{4} - 2\left(\frac{n-1}{a}\right)\sigma^{4} + \sigma^{4} \end{split}$$

This is minimized when

$$a = rac{(n-1)\gamma_2 + n^2 + n}{n} = n + 1 + rac{n-1}{n}\gamma_2.$$

For a Gaussian distribution, where

$$\gamma_2 = 0$$

, this means that the MSE is minimized when dividing the sum by

$$a = n + 1$$

. The minimum excess kurtosis is

$$\gamma_2 = -2$$

. which is achieved by a Bernoulli distribution with p = 1/2 (a coin flip), and the MSE is

minimized for

$$a = n - 1 + \frac{2}{n}.$$

Hence regardless of the kurtosis, we get a "better" estimate (in the sense of having a lower MSE) by scaling down the unbiased estimator a little bit; this is a simple example of a <a href="mailto:shrinks">shrinkage estimator</a>: one "shrinks" the estimator towards zero (scales down the unbiased estimator).

Further, while the corrected sample variance is the <u>best unbiased estimator</u> (minimum mean squared error among unbiased estimators) of variance for Gaussian distributions, if the distribution is not Gaussian, then even among unbiased estimators, the best unbiased estimator of the variance may not be

$$S_{n-1}^{2}$$
.

#### **Gaussian distribution**

### [edit]

The following table gives several estimators of the true parameters of the population,  $\mu$  and  $\sigma^2$ , for the Gaussian case.

| True<br>value    | Estimator                                                                                                                                     | Mean squared error                                                                |
|------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| $	heta=\mu$      | $\hat{	heta}$ = the unbiased estimator of the population mean, $\overline{X} = rac{1}{n} \sum_{i=1}^n (X_i)$                                 | $	ext{MSE}(\overline{X}) = 	ext{E}[(\overline{X} - \mu)^2] = rac{\sigma^2}{n}$   |
| $	heta=\sigma^2$ | $\hat{	heta}$ = the unbiased estimator of the population variance, $S_{n-1}^2 = rac{1}{n-1} \sum_{i=1}^n \left( X_i - \overline{X}  ight)^2$ | $	ext{MSE}(S_{n-1}^2) = 	ext{E}[(S_{n-1}^2 - \sigma^2)^2] = rac{2}{n-1}\sigma^4$ |
| $	heta=\sigma^2$ | $\hat{	heta}$ = the biased estimator of the population variance, $S_n^2 = rac{1}{n} \sum_{i=1}^n \left( X_i - \overline{X}  ight)^2$         | $	ext{MSE}(S_n^2) = 	ext{E}[(S_n^2 - \sigma^2)^2] = rac{2n-1}{n^2}\sigma^4$      |
|                  |                                                                                                                                               |                                                                                   |

Â

 $heta=\sigma^2 egin{array}{c} = ext{the biased estimator of the} \ heta=\sigma^2 egin{array}{c} = ext{the biased estimator of the} \ heta=\sigma^2 egin{array}{c} ext{population variance,} \ S_{n+1}^2 = rac{1}{n+1} \sum_{i=1}^n \left(X_i - \overline{X}
ight)^2 \ heta=0 \end{array} egin{array}{c} ext{MSE}(S_{n+1}^2) = ext{E}([S_{n+1}^2 - \sigma^2)^2] = rac{2}{n+1} \sigma^4 \ heta=0 \end{array}$ 

An MSE of zero, meaning that the estimator

 $\hat{ heta}$ 

predicts observations of the parameter

θ

with perfect accuracy, is ideal (but typically not possible).

Values of MSE may be used for comparative purposes. Two or more <u>statistical models</u> may be compared using their MSEs—as a measure of how well they explain a given set of observations: An unbiased estimator (estimated from a statistical model) with the smallest variance among all unbiased estimators is the *best unbiased estimator* or MVUE (Minimum-Variance Unbiased Estimator).

Both <u>analysis of variance</u> and <u>linear regression</u> techniques estimate the MSE as part of the analysis and use the estimated MSE to determine the <u>statistical significance</u> of the factors or predictors under study. The goal of <u>experimental design</u> is to construct experiments in such a way that when the observations are analyzed, the MSE is close to zero relative to the magnitude of at least one of the estimated treatment effects.

In <u>one-way analysis of variance</u>, MSE can be calculated by the division of the sum of squared errors and the degree of freedom. Also, the f-value is the ratio of the mean squared treatment and the MSE.

MSE is also used in several <u>stepwise regression</u> techniques as part of the determination as to how many predictors from a candidate set to include in a model for a given set of observations.

Minimizing MSE is a key criterion in selecting estimators; see <u>minimum mean-square</u> <u>error</u>. Among unbiased estimators, minimizing the MSE is equivalent to minimizing the variance, and the estimator that does this is the <u>minimum variance unbiased estimator</u>. However, a biased estimator may have lower MSE; see estimator bias.

In <u>statistical modelling</u> the MSE can represent the difference between the actual observations and the observation values predicted by the model. In this context, it is used to determine the extent to which the model fits the data as well as whether removing some explanatory variables is possible without significantly harming the model's predictive ability.

In forecasting and prediction, the Brier score is a measure of forecast skill based on

MSE.

Squared error loss is one of the most widely used <u>loss functions</u> in statistics, though its widespread use stems more from mathematical convenience than considerations of actual loss in applications. <u>Carl Friedrich Gauss</u>, who introduced the use of mean squared error, was aware of its arbitrariness and was in agreement with objections to it on these grounds. The mathematical benefits of mean squared error are particularly evident in its use at analyzing the performance of <u>linear regression</u>, as it allows one to partition the variation in a dataset into variation explained by the model and variation explained by randomness.

The use of mean squared error without question has been criticized by the <u>decision</u> theorist <u>James Berger</u>. Mean squared error is the negative of the expected value of one specific <u>utility function</u>, the quadratic utility function, which may not be the appropriate utility function to use under a given set of circumstances. There are, however, some scenarios where mean squared error can serve as a good approximation to a loss function occurring naturally in an application.

Like <u>variance</u>, mean squared error has the disadvantage of heavily weighting <u>outliers</u>. This is a result of the squaring of each term, which effectively weights large errors more heavily than small ones. This property, undesirable in many applications, has led researchers to use alternatives such as the <u>mean absolute error</u>, or those based on the median.

- Bias-variance tradeoff
- \* Hodges' estimator
- \* James-Stein estimator
- Mean percentage error
- Mean square quantization error
- \* Reduced chi-squared statistic
- Mean squared displacement
- Mean squared prediction error
- Minimum mean square error
- Overfitting
- \* Peak signal-to-noise ratio
- <sup>1.</sup> This can be proved by <u>Jensen's inequality</u> as follows. The fourth <u>central moment</u> is an upper bound for the square of variance, so that the least value for their ratio is one, therefore, the least value for the <u>excess kurtosis</u> is -2, achieved, for instance, by a Bernoulli with p=1/2.