direct correlation between the clinical presence of CS and mutations that inactivate a second function of XPG, its role in TCR of oxidative damage. Mutations in *CSA* and *CSB* also affect TCR of oxidative damage, further suggesting that this repair defect may relate directly to the clinical outcome. The unusual severity of the syndrome in the XP-G/CS patients, all of whom died in infancy or early childhood, may reflect the additional deficit in global removal of oxidative damage from the genome. The simplest interpretation of our results is that failure to rapidly repair endogenous oxidative base damage in critical active genes, rather than subtle transcription defects, results in the developmental defects of CS.

## **REFERENCES AND NOTES \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_**

- 1. A. Sancar, *Annu. Rev. Biochem.* 65, 43 (1996); R. D. Wood, *ibid*., p. 135.
- 2. I. Mellon, G. Spivak, P. C. Hanawalt, *Cell* 51, 241 (1987); A. van Hoffen *et al*., *Nucleic Acids Res.* 21, 5890 (1993); P. C. Hanawalt, *Science* 266, 1957 (1994); A. R. Lehmann, *Trends Biochem. Sci.* 20, 402 (1995); E. C. Friedberg, *Annu. Rev. Biochem.* 65, 15 (1996).
- 3. J. E. Cleaver and K. H. Kraemer, in *The Metabolic Basis of Inherited Disease*, C. R. Scriver, A. L. Beaudet, W. S. Sly, D. Valle, Eds. (McGraw-Hill, New York, 1989), vol. 2, pp. 2949 –2971; M. A. Nance and S. A. Berry, *Am. J. Med. Genet.* 42, 68 (1992).
- 4. C. Troelstra *et al*., *Cell* 71, 939 (1992); K. A. Henning *et al*., *ibid.* 82, 555 (1995).
- 5. J. H. J. Hoeijmakers, *Eur. J. Cancer* 30A, 1912 (1994); W. Vermeulen *et al*., *Cold Spring Harbor Symp. Quant. Biol.* 59, 317 (1994).
- 6. D. Scherly *et al*., *Nature* 363, 182 (1993).
- 7. A. O'Donovan, A. A. Davies, J. G. Moggs, S. C. West, R. D. Wood, *ibid.* 371, 432 (1994); Y. Habraken, P. Sung, L. Prakash, S. Prakash, *Nucleic Acids Res.* 22, 3312 (1994).
- 8. S. A. Leadon and P. K. Cooper, *Proc. Natl. Acad. Sci. U.S.A.* 90, 10499 (1993).
- 9. P. G. Norris, J. L. M. Hawk, J. A. Avery, F. Giannelli, *Br. J. Dermatol.* 116, 861 (1987).
- 10. T. Nouspikel and S. G. Clarkson, *Hum. Mol. Genet.* 3, 963 (1994).
- 11. T. Nouspikel, P. Lalle, S. A. Leadon, P. K. Cooper, S. G. Clarkson, *Proc. Natl. Acad. Sci. U.S.A.*, in press.
- 12. J. Jaeken *et al*., *Hum. Genet.* 83, 339 (1989); W. Vermeulen, J. Jaeken, N. G. J. Jaspers, D. Bootsma, J. H. J. Hoeijmakers, *Am. J. Hum. Genet.* 53, 185 (1993); B. C. J. Hamel *et al*., *J. Med. Genet.* 33, 607 (1996).
- 13. A. M. Sijbers *et al*., *Cell* 86, 811 (1996); K. W. Brookman *et al.*, *Mol. Cell Biol.* 16, 6553 (1996); C. H. Park, T. Bessho, T. Matsunaga, A. Sancar, *J. Biol. Chem.* 270, 22657 (1995).
- 14. XPG83 extracts in: A. O'Donovan and R. D. Wood, *Nature* 363, 185 (1993); A. O'Donovan, D. Scherly, S. G. Clarkson, R. D. Wood, *J. Biol. Chem.* 269, 15965 (1994).
- 15. J. F. Ward, *Prog. Nucleic Acids Res. Mol. Biol.* 35, 95 (1988); P. A. Riley, *Int. J. Radiat. Biol.* 65, 27 (1994).
- 16. M. F. Laspia and S. S. Wallace, *J. Bacteriol.* 170, 3359 (1988); Y. W. Kow, S. S. Wallace, B. Van Houten, *Mutat. Res.* 235, 147 (1990); Z. Hatahet, A. A. Purmal, S. S. Wallace, *Ann. N.Y. Acad. Sci.* 726, 346 (1994).
- 17. S. A. Leadon, in *DNA Repair: A Laboratory Manual of Research Procedures*, E. C. Friedberg and P. C. Hanawalt, Eds. (Dekker, New York, 1988), vol. 3, pp. 311–326.
- 18. S. A. Leadon and D. A. Lawrence, *J. Biol. Chem.* 267, 23175 (1992). Repair of Tg in either strand of the human *MTIA* gene was determined with RNA probes as described for the immunological assay detecting repair patches in DNA with anti-bromodeoxyuridine (BrdU) (*8*). The fraction of the fragments

- containing Tg (bound by anti-Tg) immediately after treatment was set at 100%.
- 19. M. S. Satoh, C. J. Jones, R. D. Wood, T. Lindahl, *Proc. Natl. Acad. Sci. U.S.A.* 90, 6335 (1993).
- 20. S. S. Wallace, *Environ. Mol. Mutagenesis* 12, 431 (1988); B. Demple and L. Harrison, *Annu. Rev. Biochem.* 63, 915 (1994); E. Seeberg, L. Eide, M. Bjoras, *Trends Biochem. Sci.* 20, 391 (1995).
- 21. L. J. Walker, R. B. Craig, A. L. Harris, I. D. Hickson, *Nucleic Acids Res.* 22, 4884 (1994); D. S. Chen and Z. L. Olkowski, *Ann. N.Y. Acad. Sci.* 726, 306 (1994).
- 22. S. A. Leadon, S. L. Barbee, A.-B. Dunn, *Mutat. Res.* 337, 169 (1995).
- 23. D. Mu, D. S. Hsu, A. Sancar, *J. Biol. Chem.* 271, 8285 (1996).
- 24. D. Mu *et al*., *J. Biol. Chem.* 270, 2415 (1995); N. Iyer, M. S. Reagan, K.-J. Wu, B. Canagarajah, E. C. Friedberg, *Biochemistry* 35, 2157 (1996); Y. Habraken, P. Sung, S. Prakash, L. Prakash, *Proc. Natl. Acad. Sci. U.S.A.* 93, 10718 (1996).
- 25. We thank C. Arlett ( XP125LO) and W. Vermeulen and N. G. J. Jaspers (three XP-G/CS) for cell strains, and E. E. Kwoh, C. Ng, and A. Avrutskaya for technical assistance. Supported by grants from NIH (CA63503) and DOE (through contract DE-AC03- 76SF00098) to P.K.C., from NIH (CA40453) to S.A.L., and from the Swiss National Science Foundation (31-36482.92) to S.G.C.

19 August 1996; accepted 17 December 1996

## **Regulation of Replicon Size in Xenopus Egg Extracts**

Johannes Walter and John W. Newport\*

Once a specific number of cells have been produced in the early *Xenopus laevis* embryo, replicon size during the S phase of the cell cycle increases. Here, it is reported that similar increase in replicon size occurred when the concentration of nuclei in replication-competent *Xenopus* egg extracts exceeded a critical threshold. In this system, the origin recognition complex (ORC) did not become stoichiometrically limiting for initiation, and similar amounts of this complex bound to chromatin regardless of replicon size. These data suggest that in early development, an unidentified factor controls how many preformed ORC-DNA complexes initiate DNA replication.

**I**n organisms such as *Xenopus* and *Drosophila*, the S phase (during which DNA is replicated) lasts only a few minutes in embryonic cells whereas it takes several hours in somatic cells. This difference exists because embryonic replicons are much smaller than somatic replicons (*1, 2*). The transition from small to large replicons probably takes place at about the 12th cell division cycle after fertilization (*3–5*), at the time of the mid-blastula transition (MBT). The mechanism regulating replicon size is not known. One clue is that the MBT occurs after a critical number of nuclei accumulate in the embryo (*3, 4*), suggesting that the nucleo-cytoplasmic ratio might regulate replicon size, perhaps through depletion of an initiation factor (*1, 3, 6*). To study the mechanism controlling replicon size, we used *Xenopus* egg extracts, which assemble *Xenopus* sperm chromatin into nuclei that undergo one complete round of DNA replication (*7*). We attempted to modulate replicon size in vitro by altering the nucleocytoplasmic ratio in these egg extracts.

The time required for nuclei to enter mitosis in *Xenopus* egg extracts increases with increasing concentrations of nuclei, perhaps reflecting an increase in the length of the S phase (*8*). To directly measure the effect of the nuclei concentration on the

Department of Biology, University of California, San Diego, La Jolla, CA 92093– 0347, USA.

length of the S phase, we formed nuclei at 2000 and 10,000 per microliter and synchronized them at the start of S phase with cytosine b-D-arabinofuranoside 59-triphosphate (Ara-C), a deoxycytidine triphosphate (dCTP) analog that blocks elongation through its action on DNA polymerase but does not prevent initiation (*9*) (and see below). After incubating the nuclei for 40 min with Ara-C, we added excess dCTP to reverse the inhibition by Ara-C and measured the time subsequently required for completion of DNA replication. The length of the S phase in reactions with 10,000 nuclei/ml was eight times that in reactions with 2000 nuclei/ml (Fig. 1A). However, the addition of dCTP did not completely reverse the effect of the Ara-C as the rate of polymerization was about 44% the rate in the absence of Ara-C (decreased by a factor of ;2.25) (*10*). Correcting for this, the actual length of the S phase was ;10 min at 2000 nuclei/ml and ;80 min at 10,000 nuclei/ml.

We next measured the length of the S phase over a range of nuclei concentrations and found it was constant at ;10 min between 125 and 2000 nuclei/ml and increased significantly at concentrations greater than 2000 nuclei/ml, reaching 80 min at 10,000 nuclei/ml (Fig. 1B). Similarly, the S phase in developing *Xenopus* embryos is 10 to 15 min during the divisions preceding the MBT, after which it gradually increases (*3, 5*). In the absence of Ara-C, the S phase also lengthens at concentrations of nuclei .2000 per micro-

<sup>\*</sup> To whom correspondence should be addressed.

liter (Fig. 1B). However, although origins of replication initiate synchronously within individual nuclei, asynchrony in the time at which individual nuclei enter S phase in the absence of Ara-C (*11, 12*) led to a 10- to 20-min overestimate of the length of the S phase (Fig. 1B).

To test whether the increase in the length of the S phase was due to a slower rate of elongation by the replication fork, we monitored the movement of replication forks at different concentrations of nuclei by analyzing nascent replication products formed after release from Ara-C arrest (Fig. 2A). The rate of elongation was the same from 125 to 10,000 nuclei/ml (Fig. 2B) (*10*). Similar rates of elongation have been observed in *Xenopus* eggs and somatic cells (*1, 2*).

S phase could lengthen at high nuclei

![](_page_1_Figure_4.jpeg)

**Fig. 1.** (**A**) The rate of replication at two concentrations of nuclei and the effect of the cdk2– cyclin E kinase inhibitor Cip1 on DNA replication. Sperm chromatin was mixed with egg extract in the presence of 200 mM Ara-C (*23*). After 40 min, 1 mM dCTP was added and replication measured at appropriate times. Squares, 2000 nuclei/ml; diamonds, 10,000 nuclei/ml; circles, 10,000 nuclei/ml and 240 nM His-tagged Cip1 (*24*) added 10 min before addition of dCTP; triangles, 10,000 nuclei/ml and 240 nM His-Cip1 added 10 min before addition of the sperm. Density substitution experiments with bromodeoxyuridine triphosphate (*7*) verified that replication at all nuclei concentrations was semiconservative (*10*). (**B**) Titration of nuclei. The length of S phase was defined as the time required for 90 to 95% of the DNA to be replicated, and this value was plotted against nuclei per microliter on a logarithmic scale. Squares, S phase measured in the presence of Ara-C as in (A) and divided by 2.25 to correct for the effect of Ara-C; diamonds, S phase measured in the absence of Ara-C.

concentrations if origins of replication fired in a temporally staggered fashion throughout the S phase, as is the case in somatic cells (*13*). To test this idea, we used Cip1, a protein that blocks initiation by inactivating the cdk2– cyclin E kinase (*14*). When nuclei were synchronized with Ara-C, replication forks moved on average 200 base pairs (bp) from the point of initiation in 40 min (Fig. 2A, lanes 1, 6, and 11). When Cip1 was added at this time, it rapidly entered nuclei and inactivated cdk2–cyclin E (*15*). If origins fire in a staggered fashion during the S phase, then the addition of Cip1 at this time should reduce the total amount of replication observed. Instead, we found that the addition of Cip1 had little effect on the rate and final amount of replication at 1000 and 10,000 nuclei/ml (Fig. 1A) (*10*). Therefore, the longer S phase observed at high concentrations of nuclei is not due to staggered initiation of individual DNA replication origins.

The increase in the length of the S phase could also reflect an increase in the average size of the replicons, and this we found to be the case. In the first 8 min after the release from Ara-C inhibition, replication forks had moved the same average distance in extracts containing 2000 to 10,000 nuclei/ml (Fig. 2). As initiation is not temporally staggered, replicons must be about eight times as large in 10,000-nuclei/ml reactions as in 2000-nuclei/ ml reactions to account for the difference in the time subsequently required to complete replication (Fig. 1B). Given an average polymerization rate of 164 bp/min (*16*), an average replicon would be 7.2 kb at 2000 nuclei/ ml, which is in agreement with the estimated 7- to 12-kb replicons observed in vivo before the MBT (*2, 11*). At 10,000 nuclei/ml, in vitro replicon size averages 59 kb (*16*); replicon size in somatic cells is estimated to be 170 kb (*1*).

If replicon size increases, the number of initiations and thus the number of nascent replication products synthesized after release of Ara-C inhibition should decrease. Accordingly, we found that increasing the concentration of nuclei above 2000 per microliter resulted in a decrease in the number of nascent replication products synthesized per nucleus (Fig. 2A), whereas at concentrations below 2000 nuclei/ml, the number of nascent products per nucleus was con-

**Fig. 2.** (**A**) The rate of fork movement is the same from 2000 to 10,000 nuclei/ml, and fewer initiations occur per nucleus above 2000 nuclei/ml. Replication was performed as in Fig. 1A, and samples were removed at 2-min intervals starting at the time of dCTP addition. DNA from equivalent numbers of nuclei was analyzed on a denaturing agarose gel (*25*). (**B**) The relative amount of radioactivity along a line placed vertically through the middle of lanes 2, 5, 12, and

![](_page_1_Figure_11.jpeg)

![](_page_1_Figure_12.jpeg)

15 of (A) was measured (PhosphorImager) and plotted as a function of molecular size in kilobases. Graphs were adjusted to have similar amplitudes.

**Fig. 3.** About 6% of the ORC in an egg extract is required to replicate 2000 nuclei/ ml. DNA replication of 2000 nuclei/ml was assayed in XORC2-depleted unfractionated egg extracts containing different amounts of mock-depleted extract (*26*): open circles, 0% mock-depleted; shaded circles, 0.5% mock-depleted; shaded squares, 2% mock-depleted; triangles, 6% mock-depleted; open squares, 15% mock-depleted; and diamonds, 100% mock-depleted. Adding back membranefree cytosol to the XORC2-depleted ex-

![](_page_1_Figure_15.jpeg)

tract instead of mock-depleted unfractionated extract gave similar results. (**Inset**) A 1-ml sample of ORC-depleted extract (lane 1), 0.01 ml of undepleted extract (lane 2), 1 ml of undepleted extract (lane 3), and 1 ml of mock-depleted extract (lane 4) were immunoblotted with antiserum to XORC2. Open arrow, XORC2 signal; closed arrow, immunoglobulin G released from the beads used for depletion.

stant (*10*). The concentration of nuclei at which the S phase lengthens in vitro is similar to the concentration of cells in a *Xenopus* embryo at the MBT (*17*), and the changes in replicon size are very similar in vitro and in vivo. These data therefore suggest that, as we observed in vitro, replicon size in vivo increases once a specific nucleocytoplasmic ratio has been achieved. We suggest that replicon size most likely increases as a result of the depletion of an essential initiation factor.

One candidate for such a factor is the highly conserved six-subunit origin recognition complex (ORC), which is involved in determining the sites at which DNA replication initiates (*6, 18, 19*). To investigate whether ORC becomes limiting above 2000 nuclei/ml, we first immunodepleted ;99% of one of the ORC subunits, XORC2, from an egg extract (Fig. 3, inset), a procedure that likely removes the entire ORC complex (*6, 18*). The rate of DNA replication in the ORC-depleted extract was about one-fifth that in the mock-depleted extract, although replication went to completion (Fig. 3). This suggests that the distance between ORC molecules along the chromosome in the ORCdepleted extract was about five times that in the mock-depleted extract and that replicon size was directly affected by the abundance of ORC. Re-addition of increasing amounts of mock-depleted extract to the ORC-depleted extract showed that only 6% of the ORC normally present in the extract was required to replicate 2000 nuclei/ml at the maximum rate (Fig. 3). The undepleted extract thus contained enough ORC to replicate at least 33,000 nuclei/ml at the maximum rate. Therefore, replicon size did not increase above 2000 nuclei/ml because ORC became limiting.

Despite the large excess of ORC, it was important to determine whether the amount of ORC bound to chromatin decreases above

![](_page_2_Figure_5.jpeg)

**Fig. 4.** The amount of MCM3 and XORC2 associated with chromatin per nucleus is the same at different concentrations of nuclei. Reaction mixtures (16.5 ml) containing Ara-C and 0 nuclei/ml (lane 1), 1000 nuclei/ml (lane 2), 3000 nuclei/ml (lane 3), or 10,000 nuclei/ml (lane 4) were incubated for 40 min. Chromatin from 16,500 nuclei from each reaction was isolated (*27*) and analyzed alongside 37.5 ng of recombinant MCM3 (lane 5), 3.8 ng of recombinant XORC2 (lane 6), and 0.2 ml (1.2%) of the reaction before addition of sperm chromatin (lane 7) by protein immunoblotting with antiserum to MCM3 or to XORC2. Signals were detected by enhanced chemiluminescence.

2000 nuclei/ml. Notably, the amount of chromatin-bound XORC2 protein per nucleus was unchanged from 300 to 10,000 nuclei/ml (*10*) (Fig. 4), and only about 10% of the XORC2 protein present in the extract was bound to chromatin at 10,000 nuclei/ml (Fig. 4). We calculated that there were about 3.5 3 105 XORC2 protein molecules bound to chromatin per nucleus (Fig. 4) (or, on average, one ORC complex for every 8 kb of DNA), a distribution that is in close agreement with the 7.2-kb replicon size calculated (*16*). This value suggests that each chromatin-bound ORC complex detected was functional in reactions with ,2000 nuclei/ml. Above this concentration, the number of ORC complexes bound per nucleus remained constant, whereas the number of initiations decreased (Fig. 2). This suggests that replicon size increased because another factor that is required for initiation at preexisting ORC-DNA complexes became limiting above 2000 nuclei/ml.

The MCM complex (*20*), an initiation factor that binds to chromatin only in the presence of ORC (*18, 21*), could be such a factor. However, we found that only a small fraction of the MCM3 in the extract was bound to chromatin at 10,000 nuclei/ml, and that the average quantity of MCM3 bound per nucleus was the same at all concentrations of nuclei tested (Fig. 4). These data raise the possibility that MCM3, and possibly the MCM complex as a whole, does not limit the number of initiations below 10,000 nuclei/ml. The initiation factor Xcdc6 binds to chromatin in the presence of ORC and potentiates binding by MCM3 (*21*). Both the large quantity of Xcdc6 in *Xenopus* eggs (*21*) and our observation that there was no reduction in the amount of MCM3 bound per nucleus up to 10,000 nuclei/ml indicate that Xcdc6 does not limit the number of initiations. Finally, cdk2–cyclin E kinase is also present in excess, because the addition of the active kinase did not accelerate DNA replication in reactions containing 10,000 nuclei/ml (*10*).

This study supports the model (*3, 4*) that the nucleo-cytoplasmic ratio regulates replicon size in early *Xenopus* development. Our data indicate that ORC does not become stoichiometrically limiting for initiation at the MBT and suggest that the number of ORC-DNA complexes remains constant even as the number of initiations decreases. We suggest that replicon size is controlled by an unidentified factor that becomes limiting at the MBT and therefore determines how many preformed ORC-DNA complexes initiate DNA replication.

## **REFERENCES AND NOTES \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_**

1. A. B. Blumenthal, H. J. Kriegstein, D. S. Hogness, *Cold Spring Harbor Symp. Quant. Biol*. 38, 205 (1973); H. G. Callan, *Philos. Trans. R. Soc. Ser. B*.

- 181, 19 (1972).
- 2. H. M. Mahbubani, T. Pauli, J. K. Elder, J. J. Blow, *Nucleic Acids Res*. 20, 1457 (1992).
- 3. J. W. Newport and M. Kirschner, *Cell* 30, 675 (1982). 4. B. A. Edgar, C. P. Kiehle, G. Schubiger, *ibid.* 44, 365 (1986).
- 5. O. Hyrien, C. Maric, M. Me´ chali, *Science* 270, 994 (1996).
- 6. P. B. Carpenter, P. R. Mueller, W. G. Dunphy, *Nature* 379, 357 (1996).
- 7. J. J. Blow and R. A. Laskey, *Cell* 47, 577 (1986); J. W. Newport, *ibid.* 48, 205 (1987).
- 8. M. Dasso and J. W. Newport, *ibid.* 61, 811 (1990).
- 9. N. R. Cozzarelli, *Annu. Rev. Biochem*. 46, 641 (1977).
- 10. J. Walter and J. W. Newport, data not shown.
- 11. O. Hyrien and M. Me´ chali, *EMBO J*. 12, 4511 (1993).
- 12. J. J. Blow and J. V. Watson, *ibid.* 6, 1997 (1987).
- 13. W. L. Fangman and B. J. Brewer, *Cell* 71, 363 (1992).
- 14. U. P. Strausfeld *et al*., *Curr. Biol*. 4, 876 (1994).
- 15. Assays demonstrated that Cip1 inactivated nuclear cdk2– cyclin E histone H1 kinase activity within 10 min of Cip1 addition.
- 16. The average rate of fork movement was calculated from the average size of fragments 2 min (417 bp) and 6 min (1072 bp) after dCTP addition in Fig. 2A. The fork moved on average 655 bp in 4 min, or 164 bp/min. Because two forks move toward each other in each replicon, the average size of the replicon in reactions containing 2000 nuclei/ml is 22 min 3 164 bp/min 3 2 5 7.2 kb; at 10,000 nuclei/ml, it is 180 min 3 164 bp/min 3 2 5 59 kb.
- 17. One egg generates 0.6 ml of extract, so an embryo containing 2000 diploid cells corresponds to a reaction containing 6500 haploid nuclei/ml. Thus, the elongation in S phase occurs at a somewhat lower concentration of nuclei in vitro than in vivo; we ascribe this difference to the fact that the protein concentration in extracts is lower than in embryos.
- 18. A. Roweles *et al*., *Cell* 87, 287 (1996).
- 19. S. P. Bell and B. Stillman, *Nature* 357, 128 (1992).
- 20. P. Romanowski, M. A. Madine, R. A. Laskey, *Proc. Natl. Acad. Sci. U.S.A*. 93, 10189 (1996).
- 21. T. R. Coleman, P. B. Carpenter, W. G. Dunphy, *Cell* 87, 53 (1996).
- 22. C. Smythe and J. W. Newport, *Methods Cell. Biol*. 35, 449 (1991).
- 23. Membrane-free egg cytosol containing cycloheximide was mixed with membranes in a 10:1 ratio (*22*). Extracts also contained an adenosine triphosphate (ATP) regeneration system (*22*); nocodazole (3 mg/ml); the deoxynucleotides dATP, dGTP, and dTTP, each at a concentration of 40 mM; 0.75 mM MgCl2; [a32-P]dATP (0.1 mCi/ml); 200 mM Ara-C; and demembranated sperm chromatin (*22*). Reactions were carried out at 21° to 23°C. Samples (3 ml) were analyzed for replication (*8*) and quantitated (PhosphorImager).
- 24. T. M. Guadagno and J. W. Newport, *Cell* 84, 73 (1996).
- 25. Samples (5 ml) from the replication reaction were mixed with 500 ml of ice-cold buffer A (5 mM EDTA, 20 mM Hepes, pH 7.6, 50 mM NaCl) containing 1 mM spermine and 1 mM spermidine and centrifuged for 5 min in a microfuge at 4°C. Pellets were digested with proteinase K, extracted with phenol and chloroform, ethanol precipitated in the presence of 40 mg of RNA, and separated on a 0.8% alkaline gel.
- 26. To immunodeplete or mock-deplete ORC, we depleted 100 ml of egg extract (*22*) containing nocodazole three times with 20 ml of antiserum to XORC2 or preimmune serum bound to protein A–Sepharose, respectively.
- 27. Reactions were diluted 1: 5 in cold egg lysis buffer (ELB) (*22*) and centrifuged through a 100-ml ELB plus 0.25 M sucrose cushion in Beckman 5 mm by 44 mm microfuge tubes for 15 s. The pellet was resuspended in 150 ml of cold ELB and 0.6% TX-100 and centrifuged through an identical cushion for 2 min.
- 28. We thank Z. Murthy for technical assistance and B. Dunphy for the XORC2 expression vector. Supported by NIH grants RO1GM44656 (to J.N.) and 1F32GM17980-01 (to J.W.).

16 July 1996; accepted 19 December 1996