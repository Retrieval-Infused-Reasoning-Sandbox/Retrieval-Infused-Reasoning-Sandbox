# **Spatial Transcriptomics**

Spatial Transcriptomics is the ability to capture the positional context of transcriptional activity within intact tissue, either for regions or single cells. It defines an array of technologies enabling researchers to locate transcripts, often down to the <u>subcellular</u> level, providing an unbiased map of RNA molecules throughout tissue sections.

These techniques often employ microscopy and next-generation sequencing to empower scientists to measure gene expression within a specific tissue or cellular context.

Traditionally, spatial transcriptomics techniques fused two common approaches to molecular biology, fluorescent microscopy and next-generation sequencing (NGS). Today spatial transcriptomics employs differing combinations of microscopy, gene detection and counting, RNA sequencing, and *in-situ* hybridization. Technologies such as Digital Spatial Profiling can perform highly multiplexed profiling based on the detection readout using nCounter and NGS at the tissue level, whereas a <u>Spatial Molecular Imager</u> can provide quantification of up to 1000 RNAs or up to 100 proteins utilizing a smart cyclic *in situ* hybridization chemistry at the <u>single-cell and sub-cellular resolution</u>.

The CosMx® SMI and decoder probes are not offered and/or delivered to the Federal Republic of Germany for use in the Federal Republic of Germany for the detection of cellular RNA, messenger RNA, microRNA, ribosomal RNA and any combinations thereof in a method used in fluorescence in situ hybridization for detecting a plurality of analytes in a sample without the consent of the President and Fellows of Harvard College (Harvard Corporation) as owner of the German part of EP 2 794 928 B1. The use for the detection of cellular RNA, messenger RNA, microRNA, ribosomal RNA and any combinations thereof is prohibited without the consent of the President and Fellows of Harvard College (Harvard Corporation).

#### Three Platforms. Unlimited Potential.

Whether you're characterizing with standard gene expression or exploring with novel spatial biology approaches, NanoString's platforms and integrated analytics provide robust and reproducible technologies to bring progress to your work.

# **Spatial Transcriptomics Methods**

Our spatial transcriptomics motto is "any target, any region, any sample." There are an

estimated 5 million FFPE slides in countless repositories, each carrying intact morphological and molecular information. The data extracted through spatial transcriptomics may support everything from cancer research to new breakthroughs related to infectious diseases.

Image-based spatial transcriptomics methods provide single-cell resolution using in situ hybridization techniques. Single-cell imagers use sequential cycles of probe hybridization and imaging and offer the potential to combine the benefits of scRNA-seq analysis with added spatial resolution at single-cell or even subcellular resolution.

### Why Single-Cell Resolution Is Important

Cells are the organism's building blocks; their organization in space forms tissues and defines their physiological or morphological function. Since the gene expression pattern is heterogenous even amongst similar cells, each cell has a unique transcriptomics fingerprint.

Analysis at the level of a single cell can provide a comprehensive understanding of the intricate information networks that regulate organism development. To this end, the development of single-cell sequencing and <u>single-cell imaging</u> technologies has enabled a systematic investigation of a wide range of regulatory mechanisms and processes – differentiation, cell fate decisions, tissue heterogeneity, and signaling pathways – critical to understanding cell architecture and function under different conditions.

# How Spatial Transcriptomics Empowers scRNAseq

Since its inception, single-cell RNA sequencing has been a powerful genomic tool. It has allowed RNA detection and quantitative analysis down to the fundamental unit of life: the cell. However, a major drawback is the failure to capture positional information of the RNA transcript, as this requires tissue dissociation and cell isolation.

Spatial context is critical to answering fundamental questions about the heterogeneity of a tissue – what is expressed, by what cell(s), and where. Spatial transcriptomics techniques use intact tissue sections, spatial barcoding, or *in situ* hybridization to retain positional information.

Furthermore, a recently developed platform using hybridization-based single-cell transcriptomic technologies is able to detect about a thousand different RNA targets spatially at a resolution of <50 nm.

understanding of complex biological systems.

## **Frequently Asked Questions**

#### What is spatial gene expression?

Spatial gene expression examines transcriptional dynamics through the lens of location within tissue and/or transcriptional dynamics between unique cells within a tissue. With spatial gene expression, users get additional insights into cellular biology as they can get gene expression information within a given three-dimensional cellular context. Learn more »

#### Why is spatial gene expression important?

Spatial gene expression is the visualization of gene expression patterns in three dimensions within cells that are in their native state. Biology is inherently spatial, and individual cells do not function in isolation but work together, forming a complex network of gene interactions spatially to organize themselves and communicate with their surroundings. <u>Learn more »</u>

#### What does spatial transcriptomics do?

Spatial transcriptomics is a method that enables researchers to spatially localize and quantify gene expression in the form of mRNA transcripts within cells or tissues that are in their native state. Spatial transcriptomics offers an unbiased exploration of mRNA transcripts *in situ* that can be quantified. Learn more »

#### What is single-cell spatial transcriptomics?

· · ----- ---- ----- -----------------

Single-cell spatial transcriptomics is the analysis of mRNA expression profile with spatial context at the level of a single cell. Each cell has a unique transcriptomic fingerprint as gene expression patterns can be heterogeneous even amongst similar cells in both standard and abnormal cell states. Learn more »

#### Learn More in a Webinar

![](_page_3_Picture_3.jpeg)

## **Spatial Transcriptomics Publications**

#### View All

Pancreatic ductal adenocarcinoma (PDAC) is a highly lethal and treatment-refractory cancer. Molecular stratification in pancreatic cancer remains rudimentary and does not yet inform clinical management or therapeutic development.

People with pre-existing lung diseases such as chronic obstructive pulmonary disease (COPD) are more likely to get very sick from SARS-CoV-2 disease 2019 (COVID-19). Still, an interrogation of the immune response to COVID-19 infection, spatially throughout the lung structure, is lacking in patients with COPD.

Cutaneous melanoma is a highly immunogenic malignancy, surgically curable at early stages, but life-threatening when metastatic. Here we integrate high-plex imaging, 3D high-resolution microscopy, and spatially-resolved micro-region transcriptomics to study immune evasion and immunoediting in primary melanoma.

Immune checkpoint inhibitors (ICIs) show limited clinical activity in patients with advanced soft-tissue sarcomas (STSs). Retrospective analysis suggests that intratumoral tertiary lymphoid structures (TLSs) are associated with improved outcome in these patients.

# Want to learn how to advance your research using spatial transcriptomics?