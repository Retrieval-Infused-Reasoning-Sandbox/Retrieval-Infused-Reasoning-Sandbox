# **Beta oxidation**

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

In biochemistry and metabolism, beta oxidation (also  $\beta$ -oxidation) is the catabolic process by which fatty acid molecules are broken down in the cytosol in prokaryotes and in the mitochondria in eukaryotes to generate acetyl-CoA. Acetyl-CoA enters the citric acid cycle, generating NADH and FADH<sub>2</sub>, which are electron carriers used in the electron transport chain. It is named as such because the beta carbon of the fatty acid chain undergoes oxidation and is converted to a carbonyl group to start the cycle all over again. Beta-oxidation is primarily facilitated by the mitochondrial trifunctional protein, an enzyme complex associated with the inner mitochondrial membrane, although very long chain fatty acids are oxidized in peroxisomes.

The overall reaction for one cycle of beta oxidation is:

$$\label{eq:coa} {\rm C}_n\mbox{-acyl-CoA} + {\rm FAD} + {\rm NAD}^+ + {\rm H}_2{\rm O} + {\rm CoA} \rightarrow {\rm C}_{n\mbox{-}2}\mbox{-acyl-CoA} + {\rm FADH}_2 + {\rm NADH} + {\rm H}^+ + {\rm acetyl-CoA}$$

# **Activation and membrane transport**

#### [edit]

Free fatty acids cannot penetrate any biological membrane due to their negative charge. Free fatty acids must cross the cell membrane through specific transport proteins, such as the <u>SLC27</u> family fatty acid transport protein. Once in the <u>cytosol</u>, the following processes bring fatty acids into the mitochondrial matrix so that beta-oxidation can take place.

- 1. <u>Long-chain-fatty-acid—CoA ligase</u> catalyzes the reaction between a fatty acid with <u>ATP</u> to give a fatty acyl adenylate, plus inorganic pyrophosphate, which then reacts with free coenzyme A to give a fatty acyl-CoA ester and AMP.
- <sup>2</sup>· If the fatty acyl-CoA has a long chain, then the <u>carnitine shuttle</u> must be utilized (shown in the table below):
  - ° Acyl-CoA is transferred to the hydroxyl group of carnitine by <u>carnitine</u> <u>palmitoyltransferase I</u>, located on the cytosolic faces of the <u>outer</u> and <u>inner mitochondrial membranes</u>.
  - ° Acyl-carnitine is shuttled inside by a <u>carnitine-acylcarnitine translocase</u>, as a carnitine is shuttled outside.
  - ° Acyl-carnitine is converted back to acyl-CoA by <u>carnitine</u>
    <u>palmitoyltransferase II</u>, located on the interior face of the <u>inner</u>
    <u>mitochondrial membrane</u>. The liberated carnitine is shuttled back to the cytosol, as an acyl-carnitine is shuttled into the matrix.
- 3. If the fatty acyl-CoA contains a short chain, these <u>short-chain fatty acids</u> can simply diffuse through the inner mitochondrial membrane.

![](_page_0_Figure_15.jpeg)

induced by high <u>epinephrine</u> and low <u>insulin</u> levels in the blood.

Epinephrine binds to a <u>beta-adrenergic</u> receptor in the cell wall of the adipocyte, which causes <u>cAMP</u> to be generated inside the cell. The cAMP activates a <u>protein kinase</u>, which phosphorylates and activates a <u>hormone-sensitive lipase</u> in the fat cell. This lipase cleaves free fatty acids from their attachment to glycerol in the adipocyte. The free fatty acids and glycerol are then released into the blood.

A diagrammatic illustration of the transport of <u>free fatty acids</u> in the blood attached to <u>plasma albumin</u>, its diffusion across the cell membrane using a protein transporter, and its activation, using <u>ATP</u>, to form <u>acyl-CoA</u> in the <u>cytosol</u>. The illustration is of a 12 carbon fatty acid.

across the inner mer <u>CoA transferase</u> (CA long. CAT is inhibite first committed step means that fatty aci occur simultaneousl

# General mechanism of beta oxidation

## [edit]

$$\begin{array}{c|c}
R & C & O \\
\hline
S-CoA \\
\hline
PADH2 & Oxidation \\
R & C & O \\
S-CoA \\
\hline
H_2O & Hydration \\
\hline
R & C & O \\
S-CoA \\
\hline
NADH+H & Oxidation \\
\hline
R & C & O \\
S-CoA \\
\hline
Thiolysis \\
\hline
R & C & O \\
S-CoA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
\hline
A & COA \\
A$$

General Mechanism of Beta Oxidation

Once the fatty acid is inside the <u>mitochondrial matrix</u>, beta-oxidation occurs by cleaving two carbons every cycle to form acetyl-CoA. The process consists of 4 steps.

- 1. A long-chain fatty acid is <u>dehydrogenated</u> to create a trans <u>double bond</u> between C2 and C3. This is catalyzed by <u>acyl CoA dehydrogenase</u> to produce trans-delta 2-enoyl CoA. It uses FAD as an electron acceptor and it is reduced to FADH<sub>2</sub>.
- 2. Trans-delta 2-enoyl CoA is hydrated at the double bond to produce L-3-hydroxyacyl CoA by enoyl-CoA hydratase.
- $^{3\cdot}$  L-3-hydroxyacyl CoA is dehydrogenated again to create 3-ketoacyl CoA by 3-hydroxyacyl CoA dehydrogenase. This enzyme uses NAD as an electron acceptor.
- 4. Thiolysis occurs between C2 and C3 (alpha and beta carbons) of 3-ketoacyl CoA. Thiolase enzyme catalyzes the reaction when a new molecule of coenzyme A breaks the bond by nucleophilic attack on C3. This releases the first two carbon units, as acetyl CoA, and a fatty acyl CoA minus two carbons. The process continues until all

of the carbons in the fatty acid are turned into acetyl CoA.

This acetyl-CoA then enters the mitochondrial tricarboxylic acid cycle (TCA cycle). Both the fatty acid beta-oxidation and the TCA cycle produce NADH and  ${\rm FADH_2}$ , which are used by the electron transport chain to generate ATP.

Fatty acids are oxidized by most of the tissues in the body. However, some tissues such as the <u>red blood cells</u> of mammals (which do not contain mitochondria) and cells of the <u>central nervous system</u> do not use fatty acids for their energy requirements, but instead use carbohydrates (red blood cells and neurons) or <u>ketone bodies</u> (neurons only).

Because many fatty acids are not fully saturated or do not have an even number of carbons, several different mechanisms have evolved, described below.

# Even-numbered saturated fatty acids

## [edit]

Once inside the mitochondria, each cycle of  $\beta$ -oxidation, liberating a two carbon unit (acetyl-CoA), occurs in a sequence of four reactions:

| Description                                                                                                                                                                                                                                                                                                                                         |                           | Diagram                                                             |                                               | Enzyme                    | End<br>product                |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|---------------------------------------------------------------------|-----------------------------------------------|---------------------------|-------------------------------|
| Dehydrogenation by FAD: The first step is the oxidation of the fatty acid by Acyl-CoA-Dehydrogenase. The enzyme catalyzes the formation of a trans-double bond between the C-2 and C-3 by selectively remove hydrogen atoms from the β-carbon. The regioselectivity of this step is essential for the subsequent hydration and oxidation reactions. | R CoA Acyl-CoA            | FAD FADH <sub>2</sub> Acyl-CoA- Dehydrogenase                       | R CoA<br>trans-Δ²-Enoyl-CoA                   | acyl CoA<br>dehydrogenase | trans- $\Delta^2$ - enoyl-CoA |
| Hydration: The next step is the hydration of the bond between C-2 and C-3. The reaction is stereospecific, forming only the Lisomer. Hydroxyl group is positioned suitable for the subsequent oxidation reaction by 3-hydroxyacyl-CoA dehydrogenase to create a β-keto                                                                              | CoA<br>trans-Δ²-Enoyl-CoA | + H <sub>2</sub> O<br>- H <sub>2</sub> O<br>Enoyl-CoA-<br>Hydratase | OH O<br>R CoA<br>S CoA<br>L-3-Hydroxyacyl-CoA | enoyl CoA<br>hydratase    | L-β-<br>hydroxyacy<br>CoA     |

| group.                                                                                                                                                               |                                                                                        |                                        |                                                                              |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|----------------------------------------|------------------------------------------------------------------------------|
| Oxidation by  NAD <sup>+</sup> : The third step is the  oxidation of L-β- hydroxyacyl CoA by NAD <sup>+</sup> . This converts the  hydroxyl group into a keto group. | QH O NADH H H T O O O NADH H T O O O O O O O O O O O O O O O O O                       | 3-hydroxyacyl-<br>CoA<br>dehydrogenase | β-ketoacyl<br>CoA                                                            |
| Thiolysis: The final step is the cleavage of β-ketoacyl CoA by the thiol group of another molecule of Coenzyme A. The thiol is inserted between C-2 and C-3.         | R COA + COA-SH Thiolase R COA + H <sub>3</sub> C COA + H <sub>3</sub> C COA Acetyl-CoA | β-ketothiolase                         | An acetyl-CoA molecule, and an acyl-CoA molecule that is two carbons shorter |

This process continues until the entire chain is cleaved into a cetyl CoA units. The final cycle produces two separate acetyl CoAs, instead of one a cyl CoA and one acetyl CoA. For every cycle, the Acyl CoA unit is shortened by two carbon atoms. Concomitantly, one molecule of  ${\rm FADH}_2, {\rm NADH}$  and acetyl CoA are formed.

![](_page_3_Figure_2.jpeg)

![](_page_4_Picture_0.jpeg)

The beta-Oxidation cycle pathway diagram illustrates the metabolic reactions that allow for the breakdown of fatty acids into NADH and ATP, often taught in connection with the electron transport chain and ATP synthase. This is an example of "even-numbered" saturated fatty acid metabolism

# Odd-numbered saturated fatty acids

[edit]

![](_page_4_Figure_4.jpeg)

Propionyl-CoA modification after beta oxidation of odd-chain fatty acid

Fatty acids with an odd number of carbons are found in the lipids of plants and some marine organisms. Many ruminant animals form a large amount of 3-carbon propionate during the fermentation of carbohydrates in the rumen. Long-chain fatty acids with an odd number of carbon atoms are found particularly in ruminant fat and milk.

Chains with an odd-number of <u>carbons</u> are oxidized in the same manner as evennumbered chains, but the final products are <u>propionyl-CoA</u> and acetyl-CoA.

Propionyl-CoA is first carboxylated using a <u>bicarbonate ion</u> into a D-stereoisomer of <u>methylmalonyl-CoA</u>. This reaction involves a <u>biotin co-factor</u>, ATP and the enzyme <u>propionyl-CoA carboxylase</u>. The bicarbonate ion's carbon is added to the middle carbon of propionyl-CoA, forming a D-methylmalonyl-CoA. However, the D-conformation is enzymatically converted into the L-conformation by <u>methylmalonyl-CoA epimerase</u>. It then undergoes intramolecular rearrangement, which is catalyzed by <u>methylmalonyl-CoA mutase</u> (requiring B<sub>12</sub> as a coenzyme) to form succinyl-CoA. The <u>succinyl-CoA</u> formed then enters the citric acid cycle.

However, whereas acetyl-CoA enters the citric acid cycle by condensing with an existing molecule of <u>oxaloacetate</u>, succinyl-CoA enters the cycle as a principal in its own right. Thus, the succinate just adds to the population of circulating molecules in the cycle and undergoes no net metabolization while in it. When this infusion of citric acid cycle intermediates exceeds <u>cataplerotic</u> demand (such as for <u>aspartate</u> or <u>glutamate</u> synthesis), some of them can be extracted to the <u>gluconeogenesis</u> pathway, in the liver and kidneys, through <u>phosphoenolpyruvate carboxykinase</u>, and converted to free glucose.

## **Unsaturated fatty acids**

#### [edit]

β-Oxidation of unsaturated fatty acids poses a problem since the location of a cis-bond

Oxidation as this conformation is ideal for enzyme catalysis. This is handled by additional two enzymes, <u>Enoyl CoA isomerase</u> and <u>2,4 Dienoyl CoA reductase</u>.

Complete beta oxidation of linoleic acid (an unsaturated fatty acid).

 $\beta$ -oxidation occurs normally until the acyl CoA (because of the presence of a double bond) is not an appropriate substrate for <u>acyl CoA dehydrogenase</u>, or <u>enoyl CoA</u> hydratase:

- If the acyl CoA contains a  $cis-\Delta^3$  bond, then  $cis-\Delta^3$ -Enoyl CoA isomerase will convert the bond to a  $trans-\Delta^2$  bond, which is a regular substrate.
- If the acyl CoA contains a  $cis-\Delta^4$  double bond, then its dehydrogenation yields a 2,4-dienoyl intermediate, which is not a substrate for enoyl CoA hydratase. However, the enzyme 2,4 Dienoyl CoA reductase reduces the intermediate, using NADPH, into  $trans-\Delta^3$ -enoyl CoA. This compound is converted into a suitable intermediate by 3,2-Enoyl CoA isomerase and β-Oxidation continues.

## **Peroxisomal beta-oxidation**

### [edit]

Fatty acid oxidation also occurs in <u>peroxisomes</u> when the fatty acid chains are too long to be processed by the mitochondria. The same enzymes are used in peroxisomes as in the mitochondrial matrix and acetyl-CoA is generated. Very long chain (greater than C-22) fatty acids, branched fatty acids, some <u>prostaglandins</u> and <u>leukotrienes</u> undergo initial oxidation in peroxisomes until <u>octanoyl-CoA</u> is formed, at which point it undergoes mitochondrial oxidation.

One significant difference is that oxidation in peroxisomes is not coupled to <u>ATP</u> synthesis. Instead, the high-potential electrons are transferred to O<sub>2</sub>, which yields <u>hydrogen peroxide</u>. The enzyme <u>catalase</u>, found primarily in peroxisomes and the <u>cytosol</u> of <u>erythrocytes</u> (and sometimes in <u>mitochondria</u>), converts the <u>hydrogen peroxide</u> into <u>water</u> and <u>oxygen</u>.

Peroxisomal  $\beta$ -oxidation also requires enzymes specific to the peroxisome and to very long fatty acids. There are four key differences between the enzymes used for mitochondrial and peroxisomal  $\beta$ -oxidation:

- 1. The NADH formed in the third oxidative step cannot be reoxidized in the peroxisome, so reducing equivalents are exported to the cytosol.
- 2. β-oxidation in the peroxisome requires the use of a peroxisomal <u>carnitine</u> <u>acyltransferase</u> (instead of carnitine acyltransferase I and II used by the mitochondria) for transport of the activated acyl group into the mitochondria for further breakdown.
- 3. The first oxidation step in the peroxisome is catalyzed by the enzyme <u>acyl-CoA</u> oxidase.
- <sup>4.</sup> The <u>β-ketothiolase</u> used in peroxisomal β-oxidation has an altered substrate specificity, different from the mitochondrial β-ketothiolase.

Peroxisomal oxidation is induced by a high-fat diet and administration of hypolipidemic drugs like clofibrate.

# Even-numbered saturated fatty acids

Theoretically, the ATP yield for each oxidation cycle where two carbons are broken down at a time is 17, as each NADH produces 3 ATP, FADH $_2$  produces 2 ATP and a full rotation of Acetyl-CoA in citric acid cycle produces 12 ATP. In practice, it is closer to 14 ATP for a full oxidation cycle as 2.5 ATP per NADH molecule is produced, 1.5 ATP per each FADH $_2$  molecule is produced and Acetyl-CoA produces 10 ATP per rotation of the citric acid cycle(according to the  $\underline{P/O\ ratio}$ ). This breakdown is as follows:

| Source              | ATP       | Total                           |
|---------------------|-----------|---------------------------------|
| 1 FADH <sub>2</sub> | x 1.5 ATP | = 1.5 ATP (Theoretically 2 ATP) |
| 1 <u>NADH</u>       | x 2.5 ATP | = 2.5 ATP (Theoretically 3 ATP) |
| 1 Acetyl CoA        | x 10 ATP  | = 10 ATP (Theoretically 12 ATP) |
| 1 Succinyl CoA      | x 4 ATP   | = 4 ATP                         |
| Total               |           | = 14 ATP                        |

For an even-numbered saturated fat ( $C_n$ ), 0.5 \* n - 1 oxidations are necessary, and the final process yields an additional acetyl CoA. In addition, two equivalents of  $\underline{ATP}$  are lost during the activation of the fatty acid. Therefore, the total ATP yield can be stated as:

$$(0.5\times n-1)\times 14+10-2=ATP$$

or

$$7n-6$$

For instance, the ATP yield of palmitate  $(C_{16}, n = 16)$  is:

$$7 \times 16 - 6 = 106ATP$$

Represented in table form:

| Source              | ATP       | Total      |
|---------------------|-----------|------------|
| 7 FADH <sub>2</sub> | x 1.5 ATP | = 10.5 ATP |
| 7 <u>NADH</u>       | x 2.5 ATP | = 17.5 ATP |
| 8 Acetyl CoA        | x 10 ATP  | = 80 ATP   |
| Activation          |           | = -2 ATP   |
| Total               |           | = 106 ATP  |

# Odd-numbered saturated fatty acid

## [edit]

![](_page_6_Figure_12.jpeg)

![](_page_7_Picture_0.jpeg)

Steps in beta-oxidation of odd-numbered saturated fatty acids

For an odd-numbered saturated fat ( $C_n$ ), 0.5 \* n - 1.5 oxidations are necessary, and the final process yields 8 acetyl CoA and 1 propionyl CoA. It is then converted to a succinyl CoA by a carboxylation reaction and generates additional 5 ATP (1 ATP is consumed in carboxylation process generating a net of 4 ATP). In addition, two equivalents of <u>ATP</u> are lost during the activation of the fatty acid. Therefore, the total ATP yield can be stated as:

$$(0.5 \times n - 1.5) \times 14 + 4 - 2 = ATP$$

or

$$7n - 19$$

For instance, the ATP yield of Nonadecylic acid  $(C_{10}, n = 19)$  is:

$$7 \times 19 - 19 = 114ATP$$

Represented in table form:

| Source              | ATP       | Total     |
|---------------------|-----------|-----------|
| 8 FADH <sub>2</sub> | x 1.5 ATP | = 12 ATP  |
| 8 <u>NADH</u>       | x 2.5 ATP | = 20 ATP  |
| 8 Acetyl CoA        | x 10 ATP  | = 80 ATP  |
| 1 Succinyl CoA      | x 4 ATP   | = 4 ATP   |
| Activation          |           | = -2 ATP  |
| Total               |           | = 114 ATP |

# Clinical significance

## [edit]

There are at least 25 enzymes and specific transport proteins in the  $\beta$ -oxidation pathway. Of these, 18 have been associated with human disease as inborn errors of metabolism.

Furthermore, studies indicate that lipid disorders are involved in diverse aspects of tumorigenesis, and fatty acid metabolism makes malignant cells more resistant to a hypoxic environment. Accordingly, cancer cells can display irregular lipid metabolism with regard to both fatty acid synthesis and mitochondrial <u>fatty acid oxidation</u> (FAO) that are involved in diverse aspects of tumorigenesis and cell growth. Several specific  $\beta$ -oxidation disorders have been identified.

# Medium-chain acyl-coenzyme A dehydrogenase (MCAD) deficiency

## [edit]

Medium-chain acyl-coenzyme A dehydrogenase (MCAD) deficiency is the most common fatty acid  $\beta$ -oxidation disorder and a prevalent metabolic congenital error It is often identified through newborn screening. Although children are normal at birth, symptoms usually emerge between three months and two years of age, with some cases appearing

#### in adulthood.

Medium-chain acyl-CoA dehydrogenase (MCAD) plays a crucial role in mitochondrial fatty acid  $\beta$ -oxidation, a process vital for generating energy during extended fasting or high-energy demand periods. This process, especially important when liver glycogen is depleted, supports hepatic ketogenesis. The specific step catalyzed by MCAD involves the dehydrogenation of acyl-CoA. This step converts medium-chain acyl-CoA to trans-2-enoyl-CoA, which is then further metabolized to produce energy in the form of ATP.

### Symptoms

- Affected children, who seem healthy initially, may experience symptoms like low blood sugar without ketones (hypoketotic hypoglycemia) and vomiting
- <sup>e</sup> Can escalate to <u>lethargy</u>, <u>seizures</u> and <u>coma</u>, typically triggered by illness
- \* Acute episodes may also involve enlarged liver (hepatomegaly) and liver issues
- \* Sudden death

### Treatments

- Administering simple carbohydrates
- Avoiding fasting
- Frequent feedings for infants
- For toddlers, a diet with less than 30% of total energy from fat
- \* Administering 2 g/kg of uncooked cornstarch at bedtime for sufficient overnight glucose
- Preventing hypoglycemia, especially due to excessive fasting.
- \* Avoiding infant formulas with medium-chain triglycerides as the main fat source

![](_page_8_Picture_15.jpeg)

tri-functional mitochondial protein

Schematic demonstrating <u>mitochondrial fatty acid</u> <u>beta-oxidation</u> and effects of <u>long-chain 3-hydroxyacyl-coenzyme A dehydrogenase deficiency, LCHAD deficiency</u>

# Long-chain hydroxyacyl-CoA dehydrogenase (LCHAD) deficiency

### [edit]

Long-chain hydroxyacyl-CoA dehydrogenase (LCHAD) deficiency is a mitochondrial effect of impaired enzyme function.

LCHAD performs the dehydrogenation of hydroxyacyl-CoA derivatives, facilitating the removal of hydrogen and the formation of a <u>keto group</u>. This reaction is essential for the subsequent steps in beta oxidation that lead to the production of acetyl-CoA, NADH, and FADH2, which are important for generating ATP, the energy currency of the cell.

Long-chain hydroxyacyl-CoA dehydrogenase (LCHAD) deficiency is a condition that affects mitochondrial function due to enzyme impairments. LCHAD deficiency is specifically caused by a shortfall in the enzyme <a href="long-chain 3-hydroxyacyl-CoA">long-chain 3-hydroxyacyl-CoA</a> dehydrogenase. This leads to the body's inability to transform specific fats into energy, especially during fasting periods.

# Symptoms

\* Severe Phenotype: symptoms appear soon after birth and include <a href="https://hypoglycemia">https://hypoglycemia</a>, henatomegaly brain dysfunction (encephalonathy) and often cardiomyonathy

<u>.....................................</u>

- Intermediate Phenotype: characterized by <u>hypoketotic hypoglycemia</u> and is triggered by infection or fasting during infancy
- Mild (Late-Onset) Phenotype: presents as muscle weakness (<u>myopathy</u>) and nerve disease (<u>neuropathy</u>)
- Long-Term Complications: can include <u>peripheral neuropathy</u> and eye damage (retinopathy)

#### Treatments

- \* Regular feeding to avoid fasting
- Use of <u>medium-chain triglyceride</u> (MCT) or <u>triheptanoin</u> supplements and carnitine supplements
- · Low-fat diet
- Hospitalization with intravenous fluids containing at least 10% dextrose
- \* Bicarbonate therapy for severe metabolic acidosis
- Management of high ammonia levels and muscle breakdown
- \* Cardiomyopathy management
- \* Regular monitoring of nutrition, blood and liver tests with annual fatty acid profile
- Growth, development, heart and neurological assessments and eye evaluations

# Very long-chain acyl-Coenzyme A dehydrogenase (VLCAD) deficiency

#### [edit]

Very long-chain acyl-coenzyme A dehydrogenase deficiency (VLCAD deficiency) is a genetic disorder that affects the body's ability to break down certain fats. In the  $\beta$ -oxidation cycle, VLCAD's role involves the removal of two hydrogen atoms from the acyl-CoA molecule, forming a double bond and converting it into trans-2-enoyl-CoA. This crucial first step in the cycle is essential for the fatty acid to undergo further processing and energy production. When there is a deficiency in VLCAD, the body struggles to effectively break down long-chain fatty acids. This can lead to a buildup of these fats and a shortage of energy, particularly during periods of fasting or increased physical activity.

## Symptoms

- Severe Early-Onset Cardiac and Multiorgan Failure Form: symptoms appear within days of birth and include <u>hypertrophic/dilated cardiomyopathy</u>, fluid around heart (<u>pericardial effusion</u>), heart rhythm problems (<u>arrhythmias</u>), hepatomegaly and occasional intermittent hypoglycemia
- Hepatic or Hypoketotic Hypoglycemic Form: typically appears in early childhood with hypoketotic hypoglycemia
- Later-Onset Episodic Myopathic Form: presents with muscle breakdown after exercise (<u>intermittent rhabdomyolysis</u>), muscle cramps and pain, exercise intolerance and <u>low blood sugar</u>

#### Treatments

- Low-fat diet
- \* Use of medium-chain triglyceride (MCT) supplements
- Regular, frequent feeding, especially for infants and children
- \* Snacks high in complex carbohydrates before bedtime
- Guided and limited exercise for older individuals
- Administration of high-energy fluids intravenously
- Avoiding <u>L-carnitine</u> and IV fats
- \* Plenty of fluids and urine alkalization for muscle breakdown
- \* Fatty acid metabolism
- \* Fatty-acid metabolism disorder
- Lipolysis
- Omega oxidation
- \* Alpha oxidation
- Anderson, Courtney M.; Stahl, Andreas (2013). "SLC27 fatty acid transport proteins". Molecular Aspects of Medicine. 34 (2-3): 516-528.

doi:10.1016/j.mam.2012.07.010. PMC 3602789. PMID 23506886.

- 2. Houten, Sander Michel; Wanders, Ronald J. A. (2010). "A general introduction to the biochemistry of mitochondrial fatty acid β-oxidation". Journal of Inherited Metabolic Disease. 33 (5): 469–477. doi:10.1007/s10545-010-9061-2. ISSN 0141-8955. PMC 2950079. PMID 20195903.
- 3. Talley, Jacob T.; Mohiuddin, Shamim S. (2023), "Biochemistry, Fatty Acid Oxidation", StatPearls, Treasure Island (FL): StatPearls Publishing, PMID 32310462, retrieved 2023-12-03
- <sup>4.</sup> Nelson DL, Cox MM (2005). Lehninger Principles of Biochemistry (4th ed.). New York: W. H. Freeman and Company. pp. 648–649. ISBN 978-0-7167-4339-2.
- 5. Rodwell VW. Harper's Illustrated Biochemistry (31st ed.). McGraw-Hill Publishing Company.
- 6. Schulz, Horst (1991-01-01), Vance, Dennis E.; Vance, Jean E. (eds.), Chapter 3
  Oxidation of fatty acids, New Comprehensive Biochemistry, vol. 20, Elsevier,
  pp. 87–110, doi:10.1016/s0167-7306(08)60331-2, ISBN 978-0-444-89321-5,
  retrieved 2023-12-03
- 7- King M. "Gluconeogenesis: Synthesis of New Glucose". Subsection: "Propionate". themedicalbiochemistrypage.org, LLC. Retrieved 20 March 2013.
- Schulz, Horst (1991-01-28). "Beta oxidation of fatty acids". Biochimica et Biophysica Acta (BBA) - Lipids and Lipid Metabolism. 1081 (2): 109–120. doi:10.1016/0005-2760(91)90015-A. ISSN 0005-2760. PMID 1998729.
- 0 -- ----