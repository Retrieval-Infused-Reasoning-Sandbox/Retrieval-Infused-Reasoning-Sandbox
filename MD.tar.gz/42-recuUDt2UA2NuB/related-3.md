# Fatty acid synthesis

Contributors to Wikimedia projects

In biochemistry, **fatty acid synthesis** is the creation of <u>fatty acids</u> from <u>acetyl-CoA</u> and <u>NADPH</u> through the action of <u>enzymes</u>. Two <u>de novo</u> fatty acid syntheses can be distinguished: <u>cytosolic</u> fatty acid synthesis (FAS/FASI) and <u>mitochondrial fatty acid</u> <u>synthesis</u> (mtFAS/mtFASII). Most of the acetyl-CoA which is converted into fatty acids is derived from <u>carbohydrates</u> via the <u>glycolytic pathway</u>. The glycolytic pathway also provides the <u>glycerol</u> with which three fatty acids can combine (by means of <u>ester bonds</u>) to form <u>triglycerides</u> (also known as "triacylglycerols" – to distinguish them from fatty "acids" – or simply as "fat"), the final product of the <u>lipogenic</u> process. When only two fatty acids combine with <u>glycerol</u> and the third <u>alcohol group</u> is <u>phosphorylated</u> with a group such as <u>phosphatidylcholine</u>, a <u>phospholipid</u> is formed. Phospholipids form the bulk of the <u>lipid bilayers</u> that make up <u>cell membranes</u> and surrounds the <u>organelles</u> within the cells (such as the <u>cell nucleus</u>, <u>mitochondria</u>, <u>endoplasmic reticulum</u>, <u>Golgi apparatus</u>, etc.).

# Straight-chain fatty acids

### [edit]

Straight-chain fatty acids occur in two types: saturated and unsaturated. The latter are produced from the former.

### Saturated straight-chain fatty acids

### [edit]

Synthesis of saturated fatty acids via fatty acid synthase II in E. coli

Straight-chain fatty acid synthesis occurs via the six recurring reactions shown below, until the 16-carbon palmitic acid is produced.

The diagrams presented show how fatty acids are synthesized in microorganisms and list the enzymes found in <u>Escherichia coli</u>. These reactions are performed by <u>fatty acid</u> <u>synthase II</u> (FASII), which in general contain multiple enzymes that act as one complex. FASII is present in <u>prokaryotes</u>, plants, fungi, and parasites, and also in the mitochondria of animals, including humans.

In animals, as well as some fungi such as yeast, *de novo* fatty acid synthesis in the cytosol is carried out by <u>fatty acid synthase I</u> (FASI), a large dimeric protein that has all of the enzymatic activities required to create a fatty acid. FASII is less efficient than FASI; however, it allows for the formation of more molecules, including <u>"medium-chain" fatty acids</u> via early chain termination. The mitochondrial FASII system (also referred to as mtFAS) plays essential roles in mitochondrial function, such as <u>lipoic acid</u> biosynthesis and regulation of <u>respiratory chain</u> activity.

Once formed by FASI, the 16:0 carbon fatty acid can undergo a number of modifications, resulting in desaturation and/or <u>elongation</u>. Elongation to stearate (18:0) mainly occurs in the ER by several membrane-bound enzymes. The steps involved in the elongation process are principally the same as those carried out by FAS, but the four principal successive steps of the elongation are performed by individual proteins, which may be physically associated.

| Step | Enzyme                        | Reaction                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |  |
|------|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|
| (a)  | Acetyl- CoA:ACP transacylase  | $H_3C$ $S$ $S$ $S$ $H_3C$ $S$ $S$ $S$ $S$ $S$ $S$ $S$ $S$ $S$ $S$                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |  |
| (b)  | Malonyl- CoA:ACP transacylase | OOO S $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OOO$ $OO$ |  |

D

Ac

for wi

m

Acomotion Minimum Acomotion Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Acomotion Minimum Minimum Acomotion Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Minimum Mini

| (c)    | 3-ketoacyl-<br>ACP<br>synthase        | HO S-ACP  HS-ACP  HS-ACP  CC)  HS-ACP  S-ACP | Co<br>AC<br>ac;<br>wi<br>ext<br>ma |
|--------|---------------------------------------|----------------------------------------------|------------------------------------|
| (d)    | 3-ketoacyl-<br>ACP<br>reductase       | NADP+ HOH O S—ACP                            | Re<br>3 l                          |
| (e)    | 3-<br>Hydroxyacyl<br>ACP<br>dehydrase | OH O H <sub>2</sub> O O S—ACP                | Eli<br>wa<br>hy                    |
| (f)    | Enoyl-ACP<br>reductase                | NADP+ H  S-ACP  NADP+  NADP+  R  S-ACP       | Re<br>C2<br>bo                     |
| A 1. 1 | 'al'ana ACD                           | A - I                                        | 11                                 |

Abbreviations: ACP – <u>Acyl carrier protein</u>, CoA – <u>Coenzyme A</u>, NADP – <u>Nicotinamide adenine dine</u> phosphate.

In fatty synthesis, the reducing agent is <u>NADPH</u>, whereas <u>NAD</u> is the oxidizing agent in <u>beta-oxidation</u> (the breakdown of fatty acids to acetyl-CoA). This difference exemplifies a general principle that NADPH is consumed during biosynthetic reactions, whereas NADH is generated in energy-yielding reactions. (Thus NADPH is also required for the synthesis of <u>cholesterol</u> from acetyl-CoA; while NADH is generated during <u>glycolysis</u>.) The source of the NADPH is two-fold. When <u>malate</u> is oxidatively decarboxylated by "NADP+-linked malic enzyme" to form <u>pyruvate</u>, CO<sub>2</sub> and NADPH are formed. NADPH is also formed by the <u>pentose phosphate pathway</u> which converts glucose into ribose, which can be used in synthesis of <u>nucleotides</u> and <u>nucleic acids</u>, or it can be catabolized to pyruvate.

### Conversion of carbohydrates into fatty acids

### [edit]

In humans, fatty acids are formed from carbohydrates predominantly in the <u>liver</u> and adipose tissue, as well as in the mammary glands during lactation.

The pyruvate produced by glycolysis is an important intermediary in the conversion of carbohydrates into fatty acids and cholesterol. This occurs via the conversion of pyruvate into acetyl-CoA in the mitochondrion. However, this acetyl-CoA needs to be transported into cytosol where the synthesis of fatty acids and cholesterol occurs. This cannot occur directly. To obtain cytosolic acetyl-CoA, citrate (produced by the condensation of acetyl-CoA with oxaloacetate) is removed from the citric acid cycle and carried across the inner mitochondrial membrane into the cytosol. There it is cleaved by ATP citrate lyase into acetyl-CoA and oxaloacetate. The oxaloacetate can be used for gluconeogenesis (in the liver), or it can be returned into mitochondrion as malate. The cytosolic acetyl-CoA is carboxylated by acetyl-CoA carboxylase into malonyl-CoA, the first committed step in the synthesis of fatty acids.

### Animals cannot resynthesize carbohydrates from fatty acids

### [edit]

The main fuel stored in the bodies of animals is fat. A young adult human's fat stores average between about 15–20 kg (33–44 lb), but varies greatly depending on age, sex, and individual disposition. In contrast, the human body stores only about 400 g (0.9 lb) of glycogen, of which 300 g (0.7 lb) is locked inside the skeletal muscles and is unavailable to the body as a whole. The 100 g (0.2 lb) or so of glycogen stored in the liver is depleted within one day of starvation. Thereafter the glucose that is released into the blood by the liver for general use by the body tissues, has to be synthesized from the glucogenic amino acids and a few other gluconeogenic substrates, which do not include fatty acids.

Fatty acids are broken down to acetyl-CoA by means of <u>beta oxidation</u> inside the mitochondria, whereas fatty acids are synthesized from acetyl-CoA outside the mitochondrion, in the cytosol. The two pathways are distinct, not only in where they occur, but also in the reactions that occur, and the substrates that are used. The two pathways are mutually inhibitory, preventing the acetyl-CoA produced by beta-oxidation from entering the synthetic pathway via the <u>acetyl-CoA carboxylase</u> reaction. It can also not be converted to <u>pyruvate</u> as the <u>pyruvate decarboxylation</u> reaction is irreversible. Instead it condenses with <u>oxaloacetate</u>, to enter the <u>citric acid cycle</u>. During each turn of the cycle, two carbon atoms leave the cycle as CO<sub>2</sub> in the decarboxylation reactions

. . . . . . . . . . . . . . . . . . . .

catalyzed by <u>isocitrate dehydrogenase</u> and <u>alpha-ketoglutarate dehydrogenase</u>. Thus each turn of the citric acid cycle oxidizes an acetyl-CoA unit while regenerating the oxaloacetate molecule with which the acetyl-CoA had originally combined to form <u>citric acid</u>. The decarboxylation reactions occur before <u>malate</u> is formed in the cycle. Malate is the only substance that can be removed from the mitochondrion to enter the <u>gluconeogenic pathway</u> to form glucose or glycogen in the liver or any other tissue. There can therefore be no net conversion of fatty acids into glucose.

Only plants possess the enzymes to <u>convert acetyl-CoA into oxaloacetate</u> from which malate can be formed to ultimately be converted to glucose.

### Regulation

Acetyl-CoA is formed into malonyl-CoA by <u>acetyl-CoA carboxylase</u>, at which point malonyl-CoA is destined to feed into the fatty acid synthesis pathway. Acetyl-CoA carboxylase is the point of regulation in saturated straight-chain fatty acid synthesis, and is subject to both <u>phosphorylation</u> and <u>allosteric regulation</u>. Regulation by phosphorylation occurs mostly in mammals, while allosteric regulation occurs in most organisms. Allosteric control occurs as feedback inhibition by palmitoyl-CoA and activation by citrate. When there are high levels of palmitoyl-CoA, the final product of saturated fatty acid synthesis, it allosterically inactivates acetyl-CoA carboxylase to prevent a build-up of fatty acids in cells. Citrate acts to activate acetyl-CoA carboxylase under high levels, because high levels indicate that there is enough acetyl-CoA to feed into the Krebs cycle and conserve energy.

High plasma levels of <u>insulin</u> in the blood plasma (e.g. after meals) cause the dephosphorylation of acetyl-CoA carboxylase, thus promoting the formation of malonyl-CoA from acetyl-CoA, and consequently the conversion of carbohydrates into fatty acids, while <u>epinephrine</u> and <u>glucagon</u> (released into the blood during starvation and exercise) cause the phosphorylation of this enzyme, inhibiting <u>lipogenesis</u> in favor of fatty acid oxidation via <u>beta-oxidation</u>.

# Unsaturated straight chain fatty acids

[edit]

### **Anaerobic desaturation**

#### [edit]

Many bacteria use the anaerobic pathway for synthesizing unsaturated fatty acids. This pathway does not utilize oxygen and is dependent on enzymes to insert the double bond before elongation utilizing the normal fatty acid synthesis machinery. In *Escherichia* 

oototo ototigusioti usittiitig sito tiottiitut tusej uotu ojitsitooto tituotititotji tit 2001toi toitu

coli, this pathway is well understood.

Synthesis of unsaturated fatty acids via anaerobic desaturation

- FabA is a  $\beta$ -hydroxydecanoyl-ACP dehydrase it is specific for the 10-carbon saturated fatty acid synthesis intermediate ( $\beta$ -hydroxydecanoyl-ACP).
- FabA catalyzes the dehydration of  $\beta$ -hydroxydecanoyl-ACP, causing the release of water and insertion of the double bond between C7 and C8 counting from the methyl end. This creates the trans-2-decenoyl intermediate.
- Either the trans-2-decenoyl intermediate can be shunted to the normal saturated fatty acid synthesis pathway by FabB, where the double bond will be hydrolyzed and the final product will be a saturated fatty acid, or FabA will catalyze the isomerization into the cis-3-decenoyl intermediate.
- $^{\bullet}$  FabB is a  $\beta$ -ketoacyl-ACP synthase that elongates and channels intermediates into the mainstream fatty acid synthesis pathway. When FabB reacts with the cisdecenoyl intermediate, the final product after elongation will be an unsaturated fatty acid.
- The two main unsaturated fatty acids made are Palmitoleoyl-ACP (16:1 $\omega$ 7) and cisvaccenoyl-ACP (18:1 $\omega$ 7).

Most bacteria that undergo anaerobic desaturation contain homologues of FabA and FabB. Clostridia are the main exception: they have a novel enzyme, vet to be identified.

--------------------------------------

that catalyzes the formation of the cis double bond.

### Regulation

This pathway undergoes <u>transcriptional regulation</u> by <u>FadR</u> and FabR. FadR is the more extensively studied protein and has been attributed bifunctional characteristics. It acts as an activator of fabA and fabB transcription and as a <u>repressor</u> for the  $\beta$ -oxidation <u>regulon</u>. In contrast, FabR acts as a repressor for the transcription of fabA and fabB.

#### Aerobic desaturation

### [edit]

Aerobic desaturation is the most widespread pathway for the synthesis of unsaturated fatty acids. It is utilized in all eukaryotes and some prokaryotes. This pathway utilizes desaturases to synthesize unsaturated fatty acids from full-length saturated fatty acid substrates. All desaturases require oxygen and ultimately consume NADH even though desaturation is an oxidative process. Desaturases are specific for the double bond they induce in the substrate. In <u>Bacillus subtilis</u>, the desaturase,  $\Delta^5$ -Des, is specific for inducing a cis-double bond at the  $\Delta^5$  position. <u>Saccharomyces cerevisiae</u> contains one desaturase, Ole1p, which induces the cis-double bond at  $\Delta^9$ .

In mammals the aerobic desaturation is catalyzed by a complex of three membrane-bound enzymes (NADH-cytochrome  $b_5$  reductase, cytochrome  $b_5$ , and a desaturase).

These enzymes allow molecular oxygen, O

 $_{2},$  to interact with the saturated fatty acyl-CoA chain, forming a double bond and two molecules of water, H  $\,$ 

<sub>2</sub>O. Two electrons come from NADH + H<sup>+</sup>

and two from the single bond in the fatty acid chain. These mammalian enzymes are, however, incapable of introducing double bonds at carbon atoms beyond C-9 in the fatty acid chain..) Hence mammals cannot synthesize linoleate or linolenate (which have double bonds at the C-12 (=  $\Delta^{12}$ ), or the C-12 and C-15 (=  $\Delta^{12}$  and  $\Delta^{15}$ ) positions, respectively, as well as at the  $\Delta^{9}$  position), nor the polyunsaturated, 20-carbon arachidonic acid that is derived from linoleate. These are all termed essential fatty acids, meaning that they are required by the organism, but can only be supplied via the diet. (Arachidonic acid is the precursor of prostaglandins which fulfill a wide variety of functions as local hormones.)

### **Odd-chain fatty acids**

### [edit]

Odd-chain fatty acids (OCFAs) are those fatty acids that contain an odd number of carbon atoms. The most common OCFAs are the saturated C15 and C17 derivatives, respectively pentadecanoic acid and heptadecanoic acid. The synthesis of even-chained fatty acid synthesis is done by assembling acetyl-CoA precursors, however, propionyl-CoA instead of acetyl-CoA is used as the primer for the biosynthesis of long-chain fatty acids with an odd number of carbon atoms.

### Regulation

In *B. subtilis*, this pathway is regulated by a <u>two-component system</u>: DesK and DesR. DesK is a membrane-associated kinase and DesR is a transcriptional regulator of the *des* gene. The regulation responds to temperature; when there is a drop in temperature, this gene is upregulated. Unsaturated fatty acids increase the fluidity of the membrane and stabilize it under lower temperatures. DesK is the sensor protein that, when there is a decrease in temperature, will autophosphorylate. DesK-P will transfer its phosphoryl group to DesR. Two DesR-P proteins will dimerize and bind to the DNA promoters of the *des* gene and recruit RNA polymerase to begin transcription.

### Pseudomonas aeruginosa

In general, both anaerobic and aerobic unsaturated fatty acid synthesis will not occur within the same system, however <u>Pseudomonas aeruginosa</u> and <u>Vibrio ABE-1</u> are exceptions. While *P. aeruginosa* undergoes primarily anaerobic desaturation, it also undergoes two aerobic pathways. One pathway utilizes a  $\Delta^9$ -desaturase (DesA) that catalyzes a double bond formation in membrane lipids. Another pathway uses two proteins, DesC and DesB, together to act as a  $\Delta^9$ -desaturase, which inserts a double bond into a saturated fatty acid-CoA molecule. This second pathway is regulated by repressor protein DesT. DesT is also a repressor of *fabAB* expression for anaerobic desaturation when in presence of exogenous unsaturated fatty acids. This functions to coordinate the expression of the two pathways within the organism.

# **Branched-chain fatty acids**

### [edit]

Branched chain fatty acids are usually saturated and are found in two distinct families: the iso-series and anteiso-series. It has been found that <u>Actinomycetales</u> contain unique branch-chain fatty acid synthesis mechanisms, including that which forms tuberculosteric acid.

# Branch-chain fatty acid synthesizing system

[edit]

Iso-branched chain fatty acid (even number of carbon atoms)

Valine primer

Leucine

3-methylbutyryl-CoA

![](_page_9_Figure_3.jpeg)

13-methyl-tetradecanoic acid

Iso-branched chain fatty acid (odd number of carbon atoms)

Leucine primer

![](_page_10_Picture_0.jpeg)

## Anteiso-branced chain fatty acid

### Isoleucine primer

Synthetic pathways of the branched-chain fatty acid synthesizing system given differing primers

The branched-chain fatty acid synthesizing system uses <u>α-keto acids</u> as primers. This system is distinct from the branched-chain fatty acid synthetase that utilizes short-chain acyl-CoA esters as primers. α-Keto acid primers are derived from the <u>transamination</u> and <u>decarboxylation</u> of <u>valine</u>, <u>leucine</u>, and <u>isoleucine</u> to form 2-methylpropanyl-CoA, 3-methylbutyryl-CoA, and 2-methylbutyryl-CoA, respectively. 2-Methylpropanyl-CoA

acids such as 14-methyl-pentadecanoic (isopalmitic) acid, and 3-methylbutyryl-CoA primers from leucine may be used to form odd-numbered iso-series fatty acids such as 13-methyl-tetradecanoic acid. 2-Methylbutyryl-CoA primers from isoleucine are elongated to form anteiso-series fatty acids containing an odd number of carbon atoms such as 12-Methyl tetradecanoic acid. Decarboxylation of the primer precursors occurs through the branched-chain α-keto acid decarboxylase (BCKA) enzyme. Elongation of the fatty acid follows the same biosynthetic pathway in *Escherichia coli* used to produce straight-chain fatty acids where malonyl-CoA is used as a chain extender. The major end products are 12–17 carbon branched-chain fatty acids and their composition tends to be uniform and characteristic for many bacterial species.

### BCKA decarboxylase and relative activities of α-keto acid substrates

The BCKA decarboxylase enzyme is composed of two subunits in a tetrameric structure  $(A_2B_2)$  and is essential for the synthesis of branched-chain fatty acids. It is responsible for the decarboxylation of  $\alpha$ -keto acids formed by the transamination of valine, leucine, and isoleucine and produces the primers used for branched-chain fatty acid synthesis. The activity of this enzyme is much higher with branched-chain  $\alpha$ -keto acid substrates than with straight-chain substrates, and in <u>Bacillus</u> species its specificity is highest for the isoleucine-derived  $\alpha$ -keto- $\beta$ -methylvaleric acid, followed by  $\alpha$ -ketoisocaproate and  $\alpha$ -ketoisovalerate. The enzyme's high affinity toward branched-chain  $\alpha$ -keto acids allows it to function as the primer donating system for branched-chain fatty acid synthetase.

| Substrate                      | BCKA<br>activity | CO <sub>2</sub> Produced (nmol/min mg) | Km<br>(μM) | Vmax<br>(nmol/min<br>mg) |
|--------------------------------|------------------|----------------------------------------|------------|--------------------------|
| L-α-keto-β-methyl-<br>valerate | 100%             | 19.7                                   | <1         | 17.8                     |
| α-Ketoisovalerate              | 63%              | 12.4                                   | <1         | 13.3                     |
| α-Ketoisocaproate              | 38%              | 7.4                                    | <1         | 5.6                      |
| Pyruvate                       | 25%              | 4.9                                    | 51.1       | 15.2                     |

### Factors affecting chain length and pattern distribution

α-Keto acid primers are used to produce branched-chain fatty acids that, in general, are between 12 and 17 carbons in length. The proportions of these branched-chain fatty acids tend to be uniform and consistent among a particular bacterial species but may be altered due to changes in malonyl-CoA concentration, temperature, or heat-stable.

ancreu une lo changes in maionyi-com concentration, temperature, or near-stable

factors (HSF) present. All of these factors may affect chain length, and HSFs have been demonstrated to alter the specificity of BCKA decarboxylase for a particular  $\alpha$ -keto acid substrate, thus shifting the ratio of branched-chain fatty acids produced. An increase in malonyl-CoA concentration has been shown to result in a larger proportion of C17 fatty acids produced, up until the optimal concentration ( $\approx 20 \mu M$ ) of malonyl-CoA is reached. Decreased temperatures also tend to shift the fatty-acid distribution slightly toward C17 fatty-acids in *Bacillus* species.

### Branch-chain fatty acid synthase

### [edit]

This system functions similarly to the branch-chain fatty acid synthesizing system, however it uses short-chain carboxylic acids as primers instead of alpha-keto acids. In general, this method is used by bacteria that do not have the ability to perform the branch-chain fatty acid system using alpha-keto primers. Typical short-chain primers include isovalerate, isobutyrate, and 2-methyl butyrate. In general, the acids needed for these primers are taken up from the environment; this is often seen in ruminal bacteria.

The overall reaction is:

Isobutyryl-CoA + 6 malonyl-CoA +12 NADPH + 
$$12H^+$$
  
 $\rightarrow$  Isopalmitic acid + 6 CO<sub>2</sub> 12 NADP + 5 H<sub>2</sub>O + 7 CoA

The difference between (straight-chain) fatty acid synthase and branch-chain fatty acid synthase is substrate specificity of the enzyme that catalyzes the reaction of acyl-CoA to acyl-ACP.

### Omega-alicyclic fatty acids

[edit]

# 11-cyclohexylundecanoic acid

# Omega-alicyclic fatty acid

Omega-alicyclic fatty acids typically contain an omega-terminal propyl or butyryl cyclic

group and are some of the major membrane fatty acids found in several species of bacteria. The fatty acid synthetase used to produce omega-alicyclic fatty acids is also used to produce membrane branched-chain fatty acids. In bacteria with membranes composed mainly of omega-alicyclic fatty acids, the supply of cyclic carboxylic acid-CoA esters is much greater than that of branched-chain primers. The synthesis of cyclic primers is not well understood but it has been suggested that mechanism involves the conversion of sugars to <a href="shikimic acid">shikimic acid</a> which is then converted to cyclohexylcarboxylic acid-CoA esters that serve as primers for omega-alicyclic fatty acid synthesis

### **Tuberculostearic acid synthesis**

[edit]

Mechanism of the synthesis of tuberculostearic acid

<u>Tuberculostearic acid</u> (D-10-Methylstearic acid) is a saturated fatty acid that is known to be produced by <u>Mycobacterium</u> spp. and two species of <u>Streptomyces</u>. It is formed from the precursor oleic acid (a monounsaturated fatty acid). After oleic acid is esterified to a phospholipid, <u>S-adenosyl-methionine</u> donates a methyl group to the double bond of oleic acid. This methylation reaction forms the intermediate 10-methylene-octadecanoyal.

Successive reduction of the residue, with NADPH as a cofactor, results in 10-methylstearic acid

# Mitochondrial fatty acid synthesis

### [edit]

In addition to fatty acid synthesis in <u>cytosol</u> (FAS/FASI), there is also another <u>de novo</u> fatty acid synthesis in <u>mitochondria</u> (mtFAS/mtFASII) in <u>eukaryotes</u>. This pathway was first described in 1990 in <u>Neurospora crassa</u>. Mitochondrial fatty acid synthesis is essential for <u>cellular respiration</u> and mitochondrial <u>biogenesis</u>. It is also required for respiratory growth in yeast and for embryonic survival in mammals.

![](_page_14_Figure_4.jpeg)

Pathway of mitochondrial fatty acid synthesis

The mtFAS pathway consists of at least six individually present enzymes, all encoded by

separate genes. This sets it apart from cytosofic fatty acid synthesis, where the multifunctional enzyme fatty acid synthase (FASN) contains all enzymatic activities within a single polypeptide chain and is encoded by a single gene. Despite this structural difference, mtFAS and FAS use the same chemistry to build fatty acids.

In mtFAS, mitochondrial <u>acyl carrier protein</u> (ACP) serves as a soluble <u>scaffold protein</u> in the <u>mitochondrial matrix</u>, <u>covalently</u> attaching the growing fatty acyl chains. <u>Malonyl-CoA</u>—formed by <u>mtACC1</u> (a mitochondrial <u>isoform</u> of <u>acetyl-CoA</u> carboxylase <u>1</u>) from <u>acetyl-CoA</u> and by <u>acyl-CoA</u> synthetase family member <u>3</u> (ACSF3) from <u>malonate</u>—serves as the chain-extender unit. However, the precise mitochondrial source of malonyl-CoA remains under debate.

In each round of chain elongation, <u>malonyl-CoA</u> is first transferred to ACP by <u>malonyl-CoA:ACP transacylase</u> (MCAT) to form <u>malonyl-ACP</u>, which then undergoes <u>condensation</u> with the growing acyl-ACP (with acetyl-ACP in the first round) catalyzed by <u>3-oxoacyl-ACP synthase</u> (OXSM), releasing <u>CO</u><sub>2</sub> and extending the chain by two <u>carbons</u>. Next, the newly extended fatty acyl chain on ACP (3-ketoacyl-ACP) undergoes reduction by <u>estradiol-17β-dehydrogenase 8</u> (HSD17B8) and <u>carbonyl reductase 4</u> (CBR4), <u>dehydration</u> by <u>3-hydroxyacyl-ACP dehydratase 2</u> (HTD2), and a final reduction by <u>trans-2-enoyl-CoA reductase</u> (MECR), yielding a <u>saturated fatty acid</u> on ACP (acyl-ACP) once again, which is then available as the substrate for the next elongation round.

These steps repeat until an eight-carbon saturated fatty acid on ACP—known as <a href="https://example.com/octanoyl-ACP">octanoyl-ACP</a> (C8)—is formed. At that point, this <a href="medium-chain fatty acid">medium-chain fatty acid</a> bound to ACP can either exit the mtFAS pathway or remain for further elongation into <a href="long-chain fatty">long-chain fatty</a> <a href="medium-chain fatty acid">acids</a> (C14-C16). Since no mitochondrial <a href="medium-chain fatty acid">thioesterase</a> has been identified in any animal species, the final product of mtFAS remains bound to ACP rather than being released as a free fatty acid.

Mitochondrial fatty acid synthesis plays a crucial role in cellular <u>energy metabolism</u> by generating octanoyl-ACP (C8), which serves as the direct <u>precursor</u> for <u>lipoic acid</u> biosynthesis. Lipoic acid is an essential <u>cofactor covalently</u> attached to specific <u>lysine residues</u> on target enzymes in a process called <u>lipoylation</u>. This <u>post-translational modification</u> is essential for the activity of key mitochondrial enzyme complexes—namely, the <u>pyruvate dehydrogenase complex</u> (PDC), the <u> $\alpha$ -ketoglutarate dehydrogenase complex</u> (OGDC), the <u> $\alpha$ -coxoadipate dehydrogenase complex</u> ( $\alpha$ -CADHC), the <u>branched-chain  $\alpha$ -ketoacid dehydrogenase complex</u> (BCKDC), and the <u>glycine cleavage system</u> (GCS).

In parallel, mtFAS and its acyl-ACP products provide a metabolic feedback mechanism, regulating mitochondrial acetyl-CoA consumption and thereby integrating lipid

synthesis with broader metabolic control.

Beyond octanoyl-ACP, mtFAS also produces longer-chain acyl-ACP species such as myristoyl-ACP (C14) and palmitoyl-ACP (C16), which interact with members of the leucine-tyrosine-arginine motif (LYRM) protein family. These LYRM proteins are vital for the correct assembly and stability of the electron-transport chain (ETC) complexes and for iron-sulfur (Fe-S) cluster biogenesis within mitochondria.

In addition to these enzymatic and structural roles, mtFAS has also been implicated as a mediator of intracellular <u>signal transduction</u>. This is supported by observations that the levels of bioactive lipids—such as <u>lysophospholipids</u> and <u>sphingolipids</u>—correlate with mtFAS activity. For instance, <u>knockdown</u> of ACP reduces <u>ceramide</u> levels, whereas loss of the terminal mtFAS enzyme MECR results in ceramide accumulation.

Importantly, mtFAS function extends to the regulation of <a href="immune cell metabolism">immune cell metabolism</a>. <a href="CRISPR/Cas9">CRISPR/Cas9</a> screens have identified mtFAS genes—especially <a href="maintenance">Mecr</a>, <a href="maintenance">Mecr</a>, <a href="maintenance">maintenance</a>, its loss in <a href="maintenance">activated T cells</a> impairs <a href="maintenance">proliferation</a>, <a href="maintenance">survival</a>, and <a href="maintenance">differentiation</a>. <a href="maintenance">MECR</a> deficiency disrupts <a href="maintenance">mitochondrial respiration</a>, alters <a href="maintenance">TCA cycle</a> activity, and increases <a href="maintenance">ferroptosis</a> sensitivity, ultimately reducing T cell fitness and inflammatory capacity.

Disorders in mtFAS pathway lead to the following metabolic diseases:

- ACSF3: Combined malonic and methylmalonic aciduria (CMAMMA)
- MECR: Mitochondrial enoyl-CoA reductase protein-associated neurodegeneration (MEPAN syndrome)

# Comparison of cytosolic and mitochondrial fatty acid synthesis

### [edit]

In the following, similarities and differences between cytosolic and mitochondrial fatty acid synthesis are shown:

| Feature            | Cytosolic fatty<br>acid synthesis<br>(FAS/FASI) | Mitochondrial fatty acid<br>synthesis (mtFAS/mtFASII) |  |
|--------------------|-------------------------------------------------|-------------------------------------------------------|--|
| Place of synthesis | Cytosol                                         | Mitochondrial matrix                                  |  |

| Enzyme system                |                | FAS type I (multifunctional enzyme)                                                | FAS type II (single enzymes)                                                                                    |  |
|------------------------------|----------------|------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|--|
| Regulation                   | Key<br>enzyme  | Acetyl-CoA<br>carboxylase                                                          | Unknown                                                                                                         |  |
|                              | Activation     | Allosteric: citrate Hormonal: insulin                                              | Unknown                                                                                                         |  |
|                              | Inhibition     | Allosteric: palmitoyl-CoA  Hormonal: glucagon, cortisol, adrenaline, noradrenaline | Unknown                                                                                                         |  |
| Primer  Extender units       |                | Acetyl-CoA (from mitochondria via citrate-malate shuttle)                          | Acetyl-CoA (directly present in the matrix)                                                                     |  |
|                              |                | Malonyl-CoA (from carboxylation of acetyl-CoA)                                     | Malonyl-CoA (mainly from the carboxylation of acetyl-CoA, but also from the thioesterification of malonic acid) |  |
|                              | Reducing agent | <u>NADPH</u>                                                                       | NADPH                                                                                                           |  |
| Cofactors                    | Other          | ATP, biotin (both for conversion to malonyl-CoA)                                   | ATP, biotin (both also for malonyl-CoA)                                                                         |  |
| Thioesterase  End product(s) |                | Available in cytosol                                                               | None known in mitochondria                                                                                      |  |
|                              |                | Mainly palmitate<br>(C16:0)                                                        | Octanoyl-ACP (C8), myristoyl-ACP (C14), palmitoyl-ACP (C16)                                                     |  |

| Function                                          | Lipid storage,<br>energy balance,<br>membrane<br>structure | Precursors for cofactors such as lipoic acid (for PDH complex, aKGDH complex, 2-oxoadipate dehydrogenase complex, BCKDH complex and glycine cleavage system); assembly of the electron transport chain (ETC); iron-sulfur (FeS) cluster biogenesis; role in ceramide metabolism |  |
|---------------------------------------------------|------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|
| Participation in <u>lipid</u><br><u>synthesis</u> | Central role in <i>de</i> novo <u>lipogenesis</u>          | Supplementary role only                                                                                                                                                                                                                                                         |  |
| Phylogenetic similarity                           | Eukaryote-specific                                         | Bacteria-like (evolutionary conserved)                                                                                                                                                                                                                                          |  |

- \* Essential fatty acid
- Fatty acid metabolism
- Fatty acid synthase
- \* ThYme (database) (2010)

![](_page_18_Figure_5.jpeg)

Numbering of carbon atoms

<u>The position of the carbon atoms</u> in a fatty acid can be indicated from the COOH-(or carboxy) end, or from the -CH

 $_3$  (or methyl) end. If indicated from the -COOH end, then the C-1, C-2, C-3,....(etc.) notation is used (blue numerals in the diagram on the right, where C-1 is the – COOH carbon). If the position is counted from the other, -CH  $_3$ , end then the position is indicated by the  $\omega$ -n notation (numerals in red, where  $\omega$ -1 refers to the methyl carbon).

The positions of the double bonds in a fatty acid chain can, therefore, be indicated in two ways, using the C-n or the  $\omega$ -n notation. Thus, in an 18 carbon fatty acid, a double bond between C-12 (or  $\omega$ -7) and C-13 (or  $\omega$ -6) is reported either as  $\Delta^{12}$  if counted from the –COOH end (indicating only the "beginning" of the double bond), or as  $\omega$ -6 (or omega-6) if counting from the -CH  $_3$  end. The " $\Delta$ " is the Greek letter "delta", which translates into "D" (for **D**ouble

bond) in the Roman alphabet. Omega ( $\omega$ ) is the last letter in the Greek alphabet, and is therefore used to indicate the "last" carbon atom in the fatty acid chain. Since the  $\omega$ -n notation is used almost exclusively to indicate the positions of the double bonds close to the -CH  $_3$  end in <u>essential fatty acids</u>, there is no necessity for an equivalent " $\Delta$ "-like notation – the use of the " $\omega$ -n" notation always refers to the position of a double

- <sup>1.</sup> ^ Dijkstra, Albert J.; Hamilton, R. J.; Hamm, Wolf (2008). <u>"§1.4 Fatty Acid</u>
  Biosynthesis". Trans Fatty Acids. Blackwell. p. 12. ISBN 978-0-470-69807-5.
- <sup>2.</sup> "MetaCyc pathway: superpathway of fatty acids biosynthesis (E. coli)". biocyc.org.

bond.

- 3. ^ "Fatty Acids: Straight-chain Saturated, Structure, Occurrence and Biosynthesis". lipidlibrary.aocs.org. Lipid Library, The American Oil Chemists' Society. 30 April 2011. Archived from the original on 21 July 2011.
- 4. ^ Wedan, Riley J.; Longenecker, Jacob Z.; Nowinski, Sara M. (2 January 2024).
  "Mitochondrial fatty acid synthesis is an emergent central regulator of
  mammalian oxidative metabolism". Cell Metabolism. 36 (1): 36–47.
  doi:10.1016/j.cmet.2023.11.017. ISSN 1550-4131. PMC 10843818.
  PMID 38128528.
- 5. "MetaCyc pathway: stearate biosynthesis I (animals)". biocyc.org.
- 6. "MetaCyc pathway: very long chain fatty acid biosynthesis II". biocyc.org.
- <sup>7.</sup> ^ Stryer, Lubert (1995). Biochemistry (Fourth ed.). New York: W.H. Freeman and Company. pp. 559–565, 614–623. <u>ISBN</u> 0-7167-2009-4.
- 8. ^ Ferre, P.; Foufelle, F. (2007). <u>"SREBP-1c Transcription Factor and Lipid Homeostasis: Clinical Perspective"</u>. Hormone Research. **68** (2): 72–82[73]. <u>doi:10.1159/000100426</u>. <u>PMID 17344645</u>. Retrieved 30 August 2010.
- 9. ^ Voet, Donald; Voet, Judith G.; Pratt, Charlotte W. (2006). Fundamentals of Biochemistry (2nd ed.). John Wiley and Sons, Inc. pp. <u>547, 556</u>. <u>ISBN</u> 0-471-21495-7.
- <sup>10.</sup> Sloan, A.W; Koeslag, J.H.; Bredell, G.A.G. (1973). "Body composition work capacity and work efficiency of active and inactive young men". European Journal of Applied Physiology. 32: 17–24. doi:10.1007/bf00422426.
  <u>S2CID</u> 39812342.
- <sup>11.</sup> ^ Stryer, Lubert (1995). Biochemistry (Fourth ed.). New York: W.H. Freeman and Company. pp. 581–602, 613, 775–778. ISBN 0-7167-2009-4.
- <sup>12.</sup> ^ Stryer, Lubert (1995). "Fatty acid metabolism". Biochemistry (Fourth ed.). New York: W.H. Freeman and Company. pp. 603–628. ISBN 0-7167-2009-4.
- <sup>13.</sup> Diwan, Joyce J. (30 April 2011). <u>"Fatty Acid Synthesis"</u>. Rensselaer Polytechnic Institute. Archived from the original on 7 June 2011.

14. . . . . . . . . . . . . . . . . . .

- of bacterial unsaturated fatty acid biosynthesis to its cognate promoters".

  Molecular Microbiology. 80 (1): 195–218. doi:10.1111/j.1365-2958.2011.07564.x.

  PMC 4072462. PMID 21276098.
- <sup>15.</sup> ^ Zhu, Lei; et al. (2009). <u>"Functions of the Clostridium acetobutylicium FabF and FabZ proteins in unsaturated fatty acid biosynthesis"</u>. BMC Microbiology. **9** 119. doi:10.1186/1471-2180-9-119. PMC 2700279. PMID 19493359.
- 16. Wang, Haihong; ECronan, John (2004). <u>"Functional replacement of the FabA"</u> and FabB proteins of Escherichia coli fatty acid synthesis by Enterococcus faecalis FabZ and FabF homologues". Journal of Biological Chemistry. **279** (33): 34489–95. doi:10.1074/jbc.M403874200. PMID 15194690.
- <sup>17.</sup> ^ Mansilla MC, de Mendoza D (May 2005). "The Bacillus subtilis desaturase: a model to understand phospholipid modification and temperature sensing". Arch Microbiol. **183** (4): 229–35. <u>Bibcode</u>:2005ArMic.183..229M. doi:10.1007/s00203-005-0759-8. PMID 15711796. S2CID 26880038.
- 18. Pfeuffer, Maria; Jaudszus, Anke (2016). <u>"Pentadecanoic and Heptadecanoic Acids: Multifaceted Odd-Chain Fatty Acids"</u>. Advances in Nutrition. **7** (4): 730–734. <u>doi:10.3945/an.115.011387</u>. <u>PMC 4942867</u>. <u>PMID 27422507</u>.
- 19. Smith, S. (1994). "The Animal Fatty Acid Synthase: One Gene, One Polypeptide, Seven Enzymes". The FASEB Journal. 8 (15): 1248–1259.

  doi:10.1096/fasebj.8.15.8001737. PMID 8001737. S2CID 22853095.
- 20. Wada M, Fukunaga N, Sasaki S (August 1989). "Mechanism of biosynthesis of unsaturated fatty acids in Pseudomonas sp. strain E-3, a psychrotrophic bacterium". J Bacteriol. 171 (8): 4267–71. doi:10.1128/jb.171.8.4267-4271.1989. PMC 210200. PMID 2753856.
- 21. ^ Subramanian C, Rock CO, Zhang YM (January 2010). "DesT coordinates the expression of anaerobic and aerobic pathways for unsaturated fatty acid biosynthesis in Pseudomonas aeruginosa". J Bacteriol. 192 (1): 280–5. doi:10.1128/JB.00404-09. PMC 2798278. PMID 19880602.
- <sup>22.</sup> Morita N, Gotoh M, Okajima N, Okuyama H, Hayashi H, Higashi S, Murata N (February 1992). "Both the anaerobic pathway and aerobic desaturation are involved in the synthesis of unsaturated fatty acids in Vibrio sp. strain ABE-1". FEBS Lett. **297** (1–2): 9–12. Bibcode:1992FEBSL.297....9M. doi:10.1016/0014-5793(92)80316-9. PMID 1551444. S2CID 38970459.
- <sup>23.</sup> Zhu K, Choi KH, Schweizer HP, Rock CO, Zhang YM (April 2006). <u>"Two aerobic</u>