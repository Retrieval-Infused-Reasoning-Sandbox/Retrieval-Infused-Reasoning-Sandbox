# **Etomoxir**

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

### Etomoxir

### Names

## **IUPAC** name

rac-Ethyl 2-[6-(4-chlorophenoxy)hexyl]oxirane-2-carboxylate

| Identifiers               |                      |
|---------------------------|----------------------|
| CAS Number                | · <u>124083-20-1</u> |
| 3D model ( <u>JSmol</u> ) | • Interactive image  |
| ChEMBL                    | * ChEMBL2051959      |
| ChemSpider                | * <u>8016042</u>     |
| ECHA InfoCard             | 100.225.462          |
| PubChem CID               | • 9840324            |

| UNII                                                                                                                                       | • MSB3DD2XP6  ✓                                  |  |
|--------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------|--|
| CompTox Dashboard (EPA)                                                                                                                    | • DTXSID60869695 DTXSID40720952,  DTXSID60869695 |  |
| <u>InChI</u>                                                                                                                               |                                                  |  |
| <u>SMILES</u>                                                                                                                              |                                                  |  |
| Properties                                                                                                                                 |                                                  |  |
| Chemical formula                                                                                                                           | $\mathrm{C_{17}H_{23}ClO_4}$                     |  |
| Molar mass                                                                                                                                 | 326.82 g·mol <sup>-1</sup>                       |  |
| Melting point                                                                                                                              | 311 K                                            |  |
| Except where otherwise noted, data are given for materials in their <u>standard state</u> (at 25 °C [77 °F], 100 kPa).  Infobox references |                                                  |  |

Etomoxir, or rac-Ethyl 2-[6-(4-chlorophenoxy)hexyl]oxirane-2-carboxylate, in form of the dextrorotatory (R)-(+)- enantiomer, is an irreversible inhibitor of carnitine palmitoyltransferase-1 (CPT-1; EC 2.3.1.21) on the inner face of the outer mitochondrial membrane. The actual inhibitor – (R)-(+)-etomoxir-Coenzyme A ester – is formed in an intracellular process. The mean inhibitor concentration for the inhibition of the CPT-1 in the liver, heart, and muscle mitochondria of rats lies in between 5 and 20 nmol/l (for rac-Etomoxir), depending on the animal's state of metabolism (fed or fasting). (+)-Etomoxir is a colourness solid with a melting point of 38 °C (311 K). The sodium salt of (+)-Etomoxir is water-soluble. The (S)-(-)-enantiomer of Etomoxir does not block CPT-1.

Etomoxir's mechanism prevents the formation of acyl carnitines, a step that is necessary for the transport of fatty acyl chains from the <u>cytosol</u> into the intermembrane space of the <u>mitochondria</u>. This step is essential to the production of <u>ATP</u> from <u>fatty acid</u> <u>oxidation</u>. Etomoxir has also been identified as a direct agonist of <u>PPARα</u>. An off-target effect has been demonstrated at high concentrations of Etomoxir on Coenzyme-A (CoA) metabolism, and on complex I of the electron transport chain.

The influence of Etomoxir on food uptake is a matter of discussion. Contradictory findings were reported.

# Clinical development

#### [edit]

The primary effect of Etomoxir in vivo is a decrease in ketone bodies in the blood, followed by a decrease in blood glucose levels. These pharmacodynamic effects of (+)-Etomoxir can be explained by its mechanism and as a consequence of the inhibition of long-chain fatty acid oxidation. This results in a depression of ketogenesis and gluconeogenesis in the liver, and via disinhibition of the pyruvate dehydrogenase in an activation of glucose oxidation in the muscle. In 1980, this prompted German firm *Byk Gulden Lomberg Chemische Fabrik GmbH* – the patent owner – to initiate drug development for the treatment of type 2 diabetes. Because of the insufficient anti-diabetic efficacy and due to the fact that in the toxicological trials a heart hypertrophy in rats was found, Byk Gulden decided to cease development in 1992, before entering phase III clinical research. The company had found by then a mild anti-diabetic effect and a good safety profile with exception of few cases of transient increases of liver transaminase (GPT). The most promising effect found was the lowering of triglyceride levels in blood.

The results of the first clinical trial with Etomoxir in patients with chronic <u>congestive</u> <u>heart failure</u> were published in 2000. Throughout the following years, it was found that Etomoxir has beneficial effects either in isolated perfused rat hearts or in vivo in animals and humans.

By 1999, the inventor had granted a license to MediGene AG (Martinsried, Germany) for further development as a drug against <u>congestive heart failure</u> and <u>hyperlipidemia</u>. Phase II clinical research started 2001, and in 2002, Medigene AG announced that it had terminated this trial due to adverse side effects, i.e., unacceptable high liver transaminase levels in 4 patents in the treatment group. The 2007 publication of the statistical evaluation, however, indicates that there were no significant differences

between the placebo and treatment groups.

# **Further developments**

#### [edit]

Throughout the late 2000s, and 2010s, experimental evidence has accumulated indicating a broad spectrum of biological effects of Etomoxir. Among the reported effects are reduced disease progression in <a href="multiple sclerosis">multiple sclerosis</a>, resistance to onset of <a href="Parkinson's disease">Parkinson's disease</a>, and a reversal of <a href="autoimmune encephalitis">autoimmune encephalitis</a>. In addition, etomoxir inhibits tumor growth in animal models of <a href="breast cancer">breast cancer</a>, <a href="proprietate-cancer">prostate cancer</a>, <a href="ovarian cancer">ovarian cancer</a>, <a href="bladder">bladder</a> <a href="mailto:cancer">cancer</a>, and <a href="breast-cancer">brain cancer</a>. These anti-cancer effects of etomoxir are not only due to mechanisms within the cancer cells themselves, but also due to a reduction of <a href="mailto:tumor-cancer">tumor-cancer</a> associated macrophages in the pro-inflammatory tumor microenvironment.

The University of Colorado filed a patent in 2005 to use a combination of Etomoxir and an inhibitor of glycolysis as an anti-inflammatory and anti-carcinogenic agent, but this patent has since expired. In 2019, the Danish company 2 N Pharma was founded to develop a drug against amyotrophic lateral sclerosis and Parkinson's disease based on similar chemistry to Etomoxir. Numiera Therapeutics, a US based pharmaceutical company, announced in 2025 that they secured orphan drug designation on etomoxir for treating malignant glioma, and that they are planning clinical trials in neuro oncology.

- <sup>1.</sup> ^ Crilley, Martine M.L.; Edmunds, Andrew J.F.; Eistetter, Klaus; Golding, Bernard T. (1989). "Syntheses of enantiomers of 2-[6-(4-chlorophenoxy)hexyl]-oxirane-2-carboxylic acid". Tetrahedron Letters. 30 (7): 885–888.
  <u>doi:10.1016/S0040-4039(01)80643-2</u>.
- <sup>2.</sup> Kruszynska YT, Sherratt HS (November 1987). "Glucose kinetics during acute and chronic treatment of rats with 2[6(4-chloro-phenoxy)hexyl]oxirane-2-carboxylate, etomoxir". Biochemical Pharmacology. **36** (22): 3917–21. doi:10.1016/0006-2952(87)90458-8. PMID 3689429.
- <sup>3.</sup> Nüsing, Rolf: "Enzyme-kinetic investigations on inhibition of mitochondrial carnitine-palmitoyltransferase I by Etomoxir-CoA." Diploma Thesis (1985-07-12), Faculty of Biology, University of Constance
- 4. Portilla, Didier; Dai, Gonghe; Peters, Jeffrey M.; Gonzalez, Frank J.; Crew, Mark D.; Proia, Alan D. (2000-04-01). "Etomoxir-induced PPARα-modulated enzymes protect during acute renal failure". American Journal of Physiology. Renal Physiology. 278 (4): F667 F675. doi:10.1152/ajprenal.2000.278.4.F667.
  ISSN 1931-857X. PMID 10751229.
- <sup>5</sup>· Divakaruni AS, Hsieh WY, Minarrieta L, Duong TN, Kim KK, Desousa BR,

- Andreyev AY, Bowman CE, Caradonna K, Dranka BP, Ferrick DA, Liesa M, Stiles L, Rogers GW, Braas D, Ciaraldi TP, Wolfgang MJ, Sparwasser T, Berod L, Bensinger SJ, Murphy AN (September 2018). "Etomoxir Inhibits Macrophage Polarization by Disrupting CoA Homeostasis". Cell Metabolism. 28 (3): 490–503.e7. doi:10.1016/j.cmet.2018.06.001. PMC 6125190. PMID 30043752.
- 6. Yao, Cong-Hui; Liu, Gao-Yuan; Wang, Rencheng; Moon, Sung Ho; Gross, Richard W.; Patti, Gary J. (2018-03-29). "Identifying off-target effects of etomoxir reveals that carnitine palmitoyltransferase I is essential for cancer cell proliferation independent of β-oxidation". PLOS Biology. 16 (3) e2003782. doi:10.1371/journal.pbio.2003782. ISSN 1545-7885. PMC 5892939. PMID 29596410.
- <sup>7.</sup> Kahler A, Zimmermann M, Langhans W (1999). "Suppression of hepatic fatty acid oxidation and food intake in men". Nutrition. **15** (11–12): 819–28. doi:10.1016/s0899-9007(99)00212-9. PMID 10575655.
- 8. Gao, Su; Serra, Dolors; Keung, Wendy; Hegardt, Fausto G.; Lopaschuk, Gary D. (2013-08-01). "Important role of ventromedial hypothalamic carnitine palmitoyltransferase-1a in the control of food intake". American Journal of Physiology. Endocrinology and Metabolism. 305 (3): E336 E347. doi:10.1152/ajpendo.00168.2013. hdl:2445/54185. ISSN 0193-1849. PMID 23736540.
- 9. Wolf, H. P., & Engel, D. W. (1985). Decrease of fatty acid oxidation, ketogenesis and gluconeogenesis in isolated perfused rat liver by phenylalkyl oxirane carboxylate (B 807-27) due to inhibition of CPT I (EC 2.3. 1.21). European Journal of Biochemistry, 146(2).
- <sup>10</sup>. EP 0025192B1
- 11. ^ <u>"Etomoxir"</u>. Dr. Wolf Bioscience (in German and English). Retrieved 2024-03-22.
- <sup>12</sup>. EP 0231367B1
- <sup>13.</sup> Ratheiser, K.; Schneeweiß, B.; Waldhäusl, W.; Fasching, P.; Korn, A.; Nowotny, P.; Rohac, M.; Wolf, H.P.O. (1991). "Inhibition by etomoxir of carnitine palmitoyltransferase I reduces hepatic glucose production and plasma lipids in non-insulin-dependent diabetes mellitus". Metabolism. 40 (11): 1185–1190. doi:10.1016/0026-0495(91)90214-H. PMID 1943747.
- <sup>14.</sup> Schmidt-Schweda, Stephan; Holubarsch, Christian (2000-07-01). "First clinical trial with etomoxir in patients with chronic congestive heart failure". Clinical Science. 99 (1): 27–35. doi:10.1042/cs0990027. ISSN 0143-5221. PMID 10887055.
- <sup>15.</sup> Tuunanen, Helena; Knuuti, Juhani (2011-01-01). <u>"Metabolic modulation in dilated cardiomyopathy"</u>. Heart and Metabolism (49). Servier International: 17–19. <u>ISSN 1566-0338</u>.

- <sup>10.</sup> Bristow, Michael (2000). "Etomoxir: a new approach to treatment of chronic heart failure". The Lancet. **356** (9242): 1621–1622. doi:10.1016/S0140-6736(00)03149-4. PMID 11089814.
- 17. Rupp, Heinz; Rupp, Thomas P.; Alter, Peter; Maisch, Bernhard (2006). "Acute Heart Failure—Basic Pathomechanism and New Drug Targets". Herz Kardiovaskuläre Erkrankungen. 31 (8): 727–735. doi:10.1007/s00059-006-2911-x. ISSN 0340-9937. PMID 17149674.
- 18. Holubarsch CJ, Rohrbach M, Karrasch M, Boehm E, Polonski L, Ponikowski P, Rhein S (August 2007). "A double-blind randomized multicentre clinical trial to evaluate the efficacy and safety of two doses of etomoxir in comparison with placebo in patients with moderate congestive heart failure: the ERGO (etomoxir for the recovery of glucose oxidation) study" (PDF). Clinical Science. 113 (4): 205–12. doi:10.1042/CS20060307. PMID 17319797. S2CID 25689289.
- 19. Shriver, Leah P.; Manchester, Marianne (2011-09-01). "Inhibition of fatty acid metabolism ameliorates disease activity in an animal model of multiple sclerosis". Scientific Reports. 1 (1): 79. Bibcode:2011NatSR...1...79S. doi:10.1038/srep00079. ISSN 2045-2322. PMC 3216566. PMID 22355598.
- 20. Trabjerg, Michael Sloth; Andersen, Dennis Christian; Huntjens, Pam; Mørk, Kasper; Warming, Nikolaj; Kullab, Ulla Bismark; Skjønnemand, Marie-Louise Nibelius; Oklinski, Michal Krystian; Oklinski, Kirsten Egelund; Bolther, Luise; Kroese, Lona J.; Pritchard, Colin E. J.; Huijbers, Ivo J.; Corthals, Angelique; Søndergaard, Mads Toft; Kjeldal, Henrik Bech; Pedersen, Cecilie Fjord Morre; Nieland, John Dirk Vestergaard (2023-01-21). "Inhibition of carnitine palmitoyltransferase 1 is a potential target in a mouse model of Parkinson's disease". npj Parkinson's Disease. 9 (1): 6. doi:10.1038/s41531-023-00450-y. ISSN 2373-8057. PMC 9867753. PMID 36681683.
- 21. Mørkholt, Anne Skøttrup; Oklinski, Michal Krystian; Larsen, Agnete; Bockermann, Robert; Issazadeh-Navikas, Shohreh; Nieland, Jette Goller Kloth; Kwon, Tae-Hwan; Corthals, Angelique; Nielsen, Søren; Nieland, John Dirk Vestergaard (2020). "Pharmacological inhibition of carnitine palmitoyl transferase 1 inhibits and reverses experimental autoimmune encephalitis in rodents". PLOS ONE. 15 (6) e0234493. Bibcode: 2020PLoSO..1534493M. doi:10.1371/journal.pone.0234493. ISSN 1932-6203. PMC 7286491. PMID 32520953.
- <sup>22.</sup> Galluzzi L, Kepp O, Vander Heiden MG, Kroemer G (November 2013). "Metabolic targets for cancer therapy". Nature Reviews. Drug Discovery. **12** (11): 829–46. doi:10.1038/nrd4145. PMID 24113830. S2CID 10921547.
- <sup>23.</sup> Flaig, Thomas W.; Salzmann-Sullivan, Maren; Su, Lih-Jen; Zhang, Zhiyong; Joshi, Molishree; Gijón, Miguel A.; Kim, Jihye; Arcaroli, John J.; Van Bokhoven, Adrie; Lucia, M. Scott; La Rosa, Francisco G.; Schlaepfer, Isabel R. (2017-08-22).

- "Lipid catabolism inhibition sensitizes prostate cancer cells to antiandrogen blockade". Oncotarget. **8** (34): 56051–56065. doi:10.18632/oncotarget.17359. ISSN 1949-2553. PMC 5593544. PMID 28915573.
- <sup>24.</sup> Sawyer, Brandon T.; Qamar, Lubna; Yamamoto, Tomomi M.; McMellen, Alexandra; Watson, Zachary L.; Richer, Jennifer K.; Behbakht, Kian; Schlaepfer, Isabel R.; Bitler, Benjamin G. (July 2020). "Targeting Fatty Acid Oxidation to Promote Anoikis and Inhibit Ovarian Cancer Progression". Molecular Cancer Research. 18 (7): 1088–1098. doi:10.1158/1541-7786.MCR-19-1057. ISSN 1557-3125. PMC 7335321. PMID 32198139.
- <sup>25.</sup> Cheng, Songtao; Wang, Gang; Wang, Yejinpeng; Cai, Liwei; Qian, Kaiyu; Ju, Lingao; Liu, Xuefeng; Xiao, Yu; Wang, Xinghuan (2019-08-15). <u>"Fatty acid oxidation inhibitor etomoxir suppresses tumor progression and induces cell cycle arrest via PPARy-mediated pathway in bladder cancer"</u>. Clinical Science. **133** (15): 1745–1758. doi:10.1042/CS20190587. ISSN 1470-8736. PMID 31358595.
- <sup>26.</sup> Lin, Hua; Patel, Shaan; Affleck, Valerie S.; Wilson, Ian; Turnbull, Douglass M.; Joshi, Abhijit R.; Maxwell, Ross; Stoll, Elizabeth A. (January 2017). "Fatty acid oxidation is required for the respiration and proliferation of malignant glioma cells". Neuro-Oncology. 19 (1): 43–54. doi:10.1093/neuonc/now128. ISSN 1523-5866. PMC 5193020. PMID 27365097.
- <sup>27.</sup> Kant, Shiva; Kesarwani, Pravin; Prabhu, Antony; Graham, Stewart F.; Buelow, Katie L.; Nakano, Ichiro; Chinnaiyan, Prakash (2020-04-20). "Enhanced fatty acid oxidation provides glioblastoma cells metabolic plasticity to accommodate to its dynamic nutrient microenvironment". Cell Death & Disease. 11 (4): 253. doi:10.1038/s41419-020-2449-5. ISSN 2041-4889. PMC 7170895. PMID 32312953.
- 28. Shim, Jin-Kyoung; Choi, Seonah; Yoon, Seon-Jin; Choi, Ran Joo; Park, Junseong; Lee, Eun Hee; Cho, Hye Joung; Lee, Suji; Teo, Wan-Yee; Moon, Ju Hyung; Kim, Hyun Sil; Kim, Eui Hyun; Cheong, Jae-Ho; Chang, Jong Hee; Yook, Jong In (2022-10-11). "Etomoxir, a carnitine palmitoyltransferase 1 inhibitor, combined with temozolomide reduces stemness and invasiveness in patient-derived glioblastoma tumorspheres". Cancer Cell International. 22 (1): 309. doi:10.1186/s12935-022-02731-7. ISSN 1475-2867. PMC 9552483. PMID 36221088.
- <sup>29.</sup> ^ Zhang, Qi; Wang, Herui; Mao, Chengyuan; Sun, Mitchell; Dominah, Gifty; Chen, Liyuan; Zhuang, Zhengping (February 2018). <u>"Fatty acid oxidation contributes to IL-1β secretion in M2 macrophages and promotes macrophagemediated tumor cell migration"</u>. Molecular Immunology. **94**: 27–35. doi:10.1016/j.molimm.2017.12.011. <u>ISSN 1872-9142</u>. <u>PMC 5801116</u>. PMID 29248877.
- 30. Newell, Martha K., Evan Newell, and Elizabeth Villobos-Menvey. Etomoxir and a

- <u>2-deoxy-D-glucose Compound; Antimianimatory, Antipromerative,</u>
  <u>Anticarcinogenic and Wound Healing Agents; Drug Resistant Cancers</u>. The
  Regents Of The University Of Colorado, assignee. Patent US7510710 B2. 31 Mar.
  2009.
- 31. Trabjerg, Michael Sloth; Mørkholt, Anne Skøttrup; Lichota, Jacek; Oklinski, Michal Krystian Egelund; Andersen, Dennis Christian; Jønsson, Katrine; Mørk, Kasper; Skjønnemand, Marie-Louise Nibelius; Kroese, Lona John; Pritchard, Colin Eliot Jason; Huijbers, Ivo Johan; Gazerani, Parisa; Corthals, Angelique; Nieland, John Dirk Vestergaard (2020-09-24). "Dysregulation of metabolic pathways by carnitine palmitoyl-transferase 1 plays a key role in central nervous system disorders: experimental evidence based on animal models". Scientific Reports. 10 (1). Springer Science and Business Media LLC: 15583.

  Bibcode:2020NatSR..1015583T. doi:10.1038/s41598-020-72638-8. ISSN 2045-2322. PMC 7519132. PMID 32973137.
- 32. Innosphere (2025-01-10). "Numiera Therapeutics Announces Orphan Drug
  Designation and Matching Funds from the State of Colorado to Advance
  Innovative Brain Cancer Treatment". GlobeNewswire News Room (Press