## **Neutral fat**

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

$$H_2C = 0$$
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 
 $O$ 

Chemical structure of an example triglyceride.

Neutral fats, also known as true fats, are <u>simple lipids</u> formed by the <u>dehydration</u> <u>synthesis</u> of one or more <u>fatty acids</u> with an <u>alcohol</u> such as <u>glycerol</u>. Neutral fats are commonly referred to as <u>triglycerides</u>. These lipids are <u>hydrophobic</u> and dense due to their long <u>hydrocarbon chains</u>, and their main biological function is energy storage as <u>body fat</u>.

Neutral fats can be tightly packed due to the structure of their fatty acid chains. While triglycerides are primarily used for energy storage, they may also contribute to <u>lipid</u> <u>membranes</u>, where they help provide flexibility. Additionally, they can serve as precursors or components of <u>signalling molecules</u>.

A wide variety of neutral fats exist, owing to the diversity of fatty acids that can be incorporated and the multiple bonding arrangements possible with glycerol. An example is a monoglyceride, which has one fatty acid combined with glycerol, a diglyceride, which has two fatty acids combined with glycerol, or a triglyceride, which has three fatty acids combined with glycerol.

Triglycerides are formed from the <u>esterification</u> of three fatty acids with one glycerol molecule, which is a type of alcohol. This process releases three water molecules. The term 'triglyceride' refers to the number of fatty acids esterified to one molecule of glycerol.

Usually, the three <u>types of fatty acids</u> in a triglyceride are different, which classifies them as mixed fats. If all three fatty acids are the same, the result is a simple fat. Examples of simple fats include <u>tripalmitin</u> and <u>tristearin</u>.

Lehmann, Michael (February 2018). "Endocrine and physiological regulation of neutral fat storage in Drosophila". Molecular and Cellular Endocrinology. 461: 165–177. doi:10.1016/j.mce.2017.09.008. ISSN 0303-7207. PMC 5756521. PMID 28893568.

2. 11 (1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

— негет, Unristopn; Kunniem, Konaia Р (2018-12-01). <u>Птасуідіусегої метаронят іп</u> Drosophila melanogaster<u>"</u>. Genetics. **210** (4): 1163—1184. <u>doi:10.1534/genetics.118.301583</u>. <u>ISSN 1943-2631</u>. <u>PMC 6283168</u>. <u>PMID 30523167</u>.