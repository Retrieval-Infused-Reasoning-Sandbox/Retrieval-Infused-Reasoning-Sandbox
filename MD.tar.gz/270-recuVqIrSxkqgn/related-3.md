# **5**

# **THE DISCRETE-TIME FOURIER TRANSFORM**

![](_page_0_Figure_2.jpeg)

#### **5.0 INTRODUCTION**

In Chapter 4, we introduced the continuous-time Fourier transform and developed the many characteristics of that transform which make the methods of Fourier analysis of such great value in analyzing and understanding the properties of continuous-time signals and systems. In the current chapter, we complete our development of the basic tools of Fourier analysis by introducing and examining the discrete-time Fourier transform.

In our discussion of Fourier series in Chapter 3, we saw that there are many similarities and strong parallels in analyzing continuous-time and discrete-time signals. However, there are also important differences. For example, as we saw in Section 3.6, the Fourier series representation of a discrete-time periodic signal is a *.finite* series, as opposed to the infinite series representation required for continuous-time periodic signals. As we will see in this chapter, there are corresponding differences between continuous-time and discretetime Fourier transforms.

In the remainder of the chapter, we take advantage of the similarities between continuous-time and discrete-time Fourier analysis by following a strategy essentially identical to that used in Chapter 4. In particular, we begin by extending the Fourier series description of periodic signals in order to develop a Fourier transform representation for discrete-time aperiodic signals, and we follow with an analysis of the properties and characteristics of the discrete-time Fourier transform that parallels that given in Chapter 4. By doing this, we not only will enhance our understanding of the basic concepts of Fourier analysis that are common to both continuous and discrete time, but also will contrast their differences in order to deepen our understanding of the distinct characteristics of each.

# **5.1 REPRESENTATION OF APERIODIC SIGNALS: THE DISCRETE-TIME FOURIER TRANSFORM**

# **5. 1. 1 Development of the Discrete-Time Fourier Transform**

In Section 4.1 [eq. (4.2) and Figure 4.2], we saw that the Fourier series coefficients for a continuous-time periodic square wave can be viewed as samples of an envelope function and that, as the period of the square wave increases, these samples become more and more finely spaced. This property suggested representing an aperiodic signal *x(t)* by first constructing a periodic signal *x(t)* that equaled *x(t)* over one period. Then, as this period approached infinity, *x(t)* was equal to *x(t)* over larger and larger intervals of time, and the Fourier series representation for *x(t)* converged to the Fourier transform representation for *x(t).* In this section, we apply an analogous procedure to discrete-time signals in order to develop the Fourier transform representation for discrete-time aperiodic sequences.

Consider a general sequence *x[n]* that is of finite duration. That is, for some integers *<sup>N</sup> <sup>1</sup>*andN2,x[n] = Ooutsidetherange *-N1* ::; *n::;* N2.Asignalofthistypeisillustrated in Figure 5.l(a). From this aperiodic signal, we can construct a periodic sequence *x[n]* for which *x[n]* is one period, as illustrated in Figure 5.l(b). As we choose the period *N* to be larger, *x[n]* is identical to *x[n]* over a longer interval, and as *N* oo, *x[n]* = *x[n]* for any finite value of *n.* 

Let us now examine the Fourier series representation of *x[n].* Specifically, from eqs. (3.94) and (3.95), we have

$$\tilde{x}[n] = \sum_{k=\langle N \rangle} a_k e^{jk(2\pi/N)n},\tag{5.1}$$

![](_page_1_Figure_8.jpeg)

**Figure 5.1** (a) Finite-duration signal x[n]; (b) periodic signal x[n] constructed to be equal to x[n] over one period.

$$a_k = \frac{1}{N} \sum_{n = \langle N \rangle} \tilde{x}[n] e^{-jk(2\pi/N)n}. \tag{5.2}$$

Since *x[n]* = *i[n]* over a period that includes the interval *-N1 n N2,* it is convenient to choose the interval of summation in eq. (5.2) to include this interval, so that *i[n]* can be replaced by *x[n]* in the summation. Therefore,

$$a_k = \frac{1}{N} \sum_{n=-N_1}^{N_2} x[n] e^{-jk(2\pi/N)n} = \frac{1}{N} \sum_{n=-\infty}^{+\infty} x[n] e^{-jk(2\pi/N)n},$$
 (5.3)

where in the second equality in eq. (5.3) we have used the fact that *x[n]* is zero outside the interval - *N1 n N2.* Defining the function

$$X(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} x[n]e^{-j\omega n}, \qquad (5.4)$$

we see that the coefficients *ak* are proportional to samples of *X(ejw),* i.e.,

$$a_k = \frac{1}{N} X(e^{jk\omega_0}), (5.5)$$

where *w0* = *21TIN* is the spacing of the samples in the frequency domain. Combining eqs. (5.1) and (5.5) yields

$$\tilde{\mathbf{x}}[n] = \sum_{k=\langle N \rangle} \frac{1}{N} X(e^{jk\omega_0}) e^{jk\omega_0 n}. \tag{5.6}$$

Since *w0*= *21TIN,* or equivalently, *liN* = *w0121T,* eq. (5.6) can be rewritten as

$$\tilde{\mathbf{x}}[n] = \frac{1}{2\pi} \sum_{k = \langle N \rangle} X(e^{jk\omega_0}) e^{jk\omega_0 n} \omega_0. \tag{5.7}$$

As with eq. (4.7), as *N* increases *w0* decreases, and as *N* oo eq. (5.7) passes to an integral. To see this more clearly, consider *X(ejw)ejwn* as sketched in Figure 5.2. From

![](_page_2_Figure_15.jpeg)

**Figure 5.2** Graphical interpretation of eq. (5.7).

eq. (5.4), *X(eiw)* is seen to be periodic in *w* with period *21T,* and so is *eiwn.* Thus, the product *X(eiw)eiwn* will also be periodic. As depicted in the figure, each term in the summation in eq. (5.7) represents the area of a rectangle of height *X(efkwo)eiwon* and width *w <sup>0</sup> .* As *w0* 0, the summation becomes an integral. Furthermore, since the summation is carried out over *N* consecutive intervals of width *w0* = *21TIN,* the total interval of integration will always have a width of *21T.* Therefore, as *N* oo, *x[n]* = *x[n],* and eq. (5.7) becomes

$$x[n] = \frac{1}{2\pi} \int_{2\pi} X(e^{j\omega}) e^{j\omega n} d\omega,$$

where, since *X(eiw)efwn* is periodic with period *21T,* the interval of integration can be taken as *any* interval of length *21T.* Thus, we have the following pair of equations:

$$x[n] = \frac{1}{2\pi} \int_{2\pi} X(e^{j\omega}) e^{j\omega n} d\omega, \qquad (5.8)$$

$$X(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} x[n]e^{-j\omega n}.$$
 (5.9)

Equations (5.8) and (5.9) are the discrete-time counterparts of eqs. (4.8) and (4.9). The function *X(eiw)* is referred to as the *discrete-time Fourier transform* and the pair of equations as the *discrete-time Fourier transform pair.* Equation (5.8) is the *synthesis equation,* eq. (5.9) the *analysis equation.* Our derivation of these equations indicates how an aperiodic sequence can be thought of as a linear combination of complex exponentials. In particular, the synthesis equation is in effect a representation of *x[n]* as a linear combination of complex exponentials infinitesimally close in frequency and with amplitudes *X(eiw)(dwi21T).* For this reason, as in continuous time, the Fourier transform *X(eiw)* will often be referred to as the *spectrum* of *x[n],* because it provides us with the information on how *x[n]* is composed of complex exponentials at different frequencies.

Note also that, as in continuous time, our derivation of the discrete-time Fourier transform provides us with an important relationship between discrete-time Fourier series and transforms. In particular, the Fourier coefficients *ak* of a periodic signal *x[n]* can be expressed in terms of equally spaced *samples* of the Fourier transform of a finite-duration, aperiodic signal *x[n]* that is equal to *x[n]* over one period and is zero otherwise. This fact is of considerable importance in practical signal processing and Fourier analysis, and we look at it further in Problem 5.41.

As our derivation indicates, the discrete-time Fourier transform shares many similarities with the continuous-time case. The major differences between the two are the periodicity of the discrete-time transform *X(eiw)* and the finite interval of integration in the synthesis equation. Both of these stem from a fact that we have noted several times before: Discrete-time complex exponentials that differ in frequency by a multiple of *21T* are identical. In Section 3.6 we saw that, for periodic discrete-time signals, the implications of this statement are that the Fourier series coefficients are periodic and that the Fourier series representation is a finite sum. For aperiodic signals, the analogous implications are that *X(eiw)* is periodic (with period 27T) and that the synthesis equation involves an integration only over a frequency interval that produces distinct complex exponentials (i.e., any interval of length 27T). In Section 1.3.3, we noted one further consequence of the periodicity of  $e^{j\omega n}$  as a function of  $\omega$ :  $\omega = 0$  and  $\omega = 2\pi$  yield the same signal. Signals at frequencies near these values or any other even multiple of  $\pi$  are slowly varying and therefore are all appropriately thought of as low-frequency signals. Similarly, the high frequencies in discrete time are the values of  $\omega$  near odd multiples of  $\pi$ . Thus, the signal  $x_1[n]$  shown in Figure 5.3(a) with Fourier transform depicted in Figure 5.3(b) varies more slowly than the signal  $x_2[n]$  in Figure 5.3(c) whose transform is shown in Figure 5.3(d).

![](_page_4_Figure_4.jpeg)

**Figure 5.3** (a) Discrete-time signal  $x_1[n]$ . (b) Fourier transform of  $x_1[n]$ . Note that  $X_1(e^{i\omega})$  is concentrated near  $\omega=0, \pm 2\pi, \pm 4\pi, \ldots$  (c) Discrete-time signal  $x_2[n]$ . (d) Fourier transform of  $x_2[n]$ . Note that  $X_2(e^{i\omega})$  is concentrated near  $\omega = \pm \pi, \pm 3\pi, \ldots$ 

# **5.1.2 Examples of Discrete-Time Fourier Transforms**

To illustrate the discrete-time Fourier transform, let us consider several examples.

# Example 5.1

Consider the signal

$$x[n] = a^n u[n], \qquad |a| < 1.$$

In this case,

$$X(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} a^n u[n] e^{-j\omega n}$$
$$= \sum_{n=0}^{\infty} (ae^{-j\omega})^n = \frac{1}{1 - ae^{-j\omega}}.$$

The magnitude and phase of  $X(e^{j\omega})$  are shown in Figure 5.4(a) for a > 0 and in Figure 5.4(b) for a < 0. Note that all of these functions are periodic in  $\omega$  with period  $2\pi$ .

![](_page_5_Figure_5.jpeg)

![](_page_5_Figure_6.jpeg)

 $|X(e^{j\omega})|$ 

**Figure 5.4** Magnitude and phase of the Fourier transform of Example 5.1 for (a) a > 0 and (b) a < 0.

# **Example 5.2**

Let

$$x[n] = a^{|n|}, |a| < 1.$$

This signal is sketched for 0 < *a* < 1 in Figure 5.5(a). Its Fourier transform is obtained from eq. (5.9):

$$X(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} a^{|n|} e^{-j\omega n}$$
  
=  $\sum_{n=0}^{\infty} a^n e^{-j\omega n} + \sum_{n=-\infty}^{-1} a^{-n} e^{-j\omega n}$ .

![](_page_6_Figure_8.jpeg)

![](_page_6_Figure_9.jpeg)

**Figure 5.5** (a) Signal x[n] = *alnl* of Example 5.2 and (b) its Fourier transform (0 < *a* < 1 ).

Making the substitution of variables *m* = - *n* in the second summation, we obtain

$$X(e^{j\omega}) = \sum_{n=0}^{\infty} (ae^{-j\omega})^n + \sum_{m=1}^{\infty} (ae^{j\omega})^m.$$

Both of these summations are infinite geometric series that we can evaluate in closed form, yielding

$$X(e^{j\omega}) = \frac{1}{1 - ae^{-j\omega}} + \frac{ae^{j\omega}}{1 - ae^{j\omega}}$$
$$= \frac{1 - a^2}{1 - 2a\cos\omega + a^2}.$$

In this case, *X(eiw)* is real and is illustrated in Figure 5.5(b), again for 0 *<a* < 1.

## **Example 5.3**

Consider the rectangular pulse

$$x[n] = \begin{cases} 1, & |n| \le N_1 \\ 0, & |n| > N_1 \end{cases}, \tag{5.10}$$

which is illustrated in Figure 5.6(a) for N1 = 2. In this case,

$$X(e^{j\omega}) = \sum_{n=-N_1}^{N_1} e^{-j\omega n}.$$
 (5.11)

![](_page_7_Figure_12.jpeg)

![](_page_7_Figure_13.jpeg)

**Figure 5.6** (a) Rectangular pulse signal of Example 5.3 for *N1* = 2 and (b) its Fourier transform.

Using calculations similar to those employed in obtaining eq. (3.104) in Example 3.12, we can write

$$X(e^{j\omega}) = \frac{\sin\omega\left(N_1 + \frac{1}{2}\right)}{\sin(\omega/2)}.$$
 (5.12)

This Fourier transform is sketched in Figure 5.6(b) for N1 = 2. The function in eq. (5.12) is the discrete-time counterpart of the sine function, which appears in the Fourier transform of the continuous-time rectangular pulse (see Example 4.4). An important difference between these two functions is that the function in eq. (5.12) is periodic with period 27T, whereas the sine function is aperiodic.

## **5.1.3 Convergence Issues Associated with the Discrete-Time Fourier Transform**

Although the argument we used to derive the discrete-time Fourier transform in Section 5.1.1 was constructed assuming that *x[n]* was of arbitrary but finite duration, eqs. (5.8) and (5.9) remain valid for an extremely broad class of signals with infinite duration (such as the signals in Examples 5.1 and 5.2). In this case, however, we again must consider the question of convergence of the infinite summation in the analysis equation (5.9). The conditions on *x[n]* that guarantee the convergence of this sum are direct counterparts of the convergence conditions for the continuous-time Fourier transform.' Specifically, eq. (5.9) will converge either if *x[n]* is absolutely summable, that is,

$$\sum_{n=-\infty}^{+\infty} |x[n]| < \infty, \tag{5.13}$$

or if the sequence has finite energy, that is,

$$\sum_{n=-\infty}^{+\infty} |x[n]|^2 < \infty. \tag{5.14}$$

In contrast to the situation for the analysis equation (5.9), there are generally no convergence issues associated with the synthesis equation (5.8), since the integral in this equation is over a finite interval of integration. This is very much the same situation as for the discrete-time Fourier series synthesis equation (3.94), which involves a finite sum and consequently has no issues of convergence associated with it either. In particular, if we approximate an aperiodic signal *x[n]* by an integral of complex exponentials with frequencies taken over the intervallwl :s *W,* i.e.,

$$\hat{x}[n] = \frac{1}{2\pi} \int_{-W}^{W} X(e^{j\omega}) e^{j\omega n} d\omega, \qquad (5.15)$$

<sup>1</sup>For discussions of the convergence issues associated with the discrete-time Fourier transform, see A. V. Oppenheim and R. W. Schafer, *Discrete-Time Signal Processing* (Englewood Cliffs, NJ: Prentice-Hall, Inc., 1989), and L. R. Rabiner and B. Gold, *Theory and Application of Digital Signal Processing* (Englewood Cliffs, NJ: Prentice-Hall, Inc., 1975).

then *x[n]* = *x[n]* for *W* = *1r.* Thus, much as in Figure 3.18, we would expect not to see any behavior like the Gibbs phenomenon in evaluating the discrete-time Fourier transform synthesis equation. This is illustrated in the following example.

# **Example 5.4**

Let *x[ n]* be the unit impulse; that is,

$$x[n] = \delta[n].$$

In this case the analysis equation (5.9) is easily evaluated, yielding

$$X(e^{j\omega}) = 1.$$

In other words, just as in continuous time, the unit impulse has a Fourier transform representation consisting of equal contributions at all frequencies. If we then apply eq. (5.15) to this example, we obtain

$$\hat{x}[n] = \frac{1}{2\pi} \int_{-W}^{W} e^{j\omega n} d\omega = \frac{\sin Wn}{\pi n}.$$
 (5.16)

This is plotted in Figure 5. 7 for several values of *W.* As can be seen, the frequency of the oscillations in the approximation increases as *W* is increased, which is similar to what we observed in the continuous-time case. On the other hand, in contrast to the continuoustime case, the amplitude of these oscillations decreases relative to the magnitude of .X[O] as *W* is increased, and the oscillations disappear entirely for *W* = 7T.

#### **5.2 THE FOURIER TRANSFORM FOR PERIODIC SIGNALS**

As in the continuous-time case, discrete-time periodic signals can be incorporated within the framework of the discrete-time Fourier transform by interpreting the transform of a periodic signal as an impulse train in the frequency domain. To derive the form of this representation, consider the signal

$$x[n] = e^{j\omega_0 n}. (5.17)$$

In continuous time, we saw that the Fourier transform of *eiwot* can be interpreted as an impulse at *w* = *w <sup>0</sup> .* Therefore, we might expect the same type of transform to result for the discrete-time signal of eq. (5.17). However, the discrete-time Fourier transform must be periodic in *w* with period 21r. This then suggests that the Fourier transform of *x[n]* in eq. (5.17) should have impulses at *w0, w <sup>0</sup>*± *21T, w <sup>0</sup>*± *41T,* and so on. In fact, the Fourier transform of *x[n]* is the impulse train

$$X(e^{j\omega}) = \sum_{l=-\infty}^{+\infty} 2\pi \,\delta(\omega - \omega_0 - 2\pi l),\tag{5.18}$$

![](_page_10_Figure_1.jpeg)

**Figure 5.7** Approximation to the unit sample obtained as in eq. (5.16) using complex exponentials with frequencies  $|\omega| \leq W$ : (a)  $W = \pi/4$ ; (b)  $W = 3\pi/8$ ; (c)  $W = \pi/2$ ; (d)  $W = 3\pi/4$ ; (e)  $W = 7\pi/8$ ; (f)  $W = \pi$ . Note that for  $W = \pi$ ,  $\hat{x}[n] = \delta[n]$ .

which is illustrated in Figure 5.8. In order to check the validity of this expression, we must evaluate its inverse transform. Substituting eq. (5.18) into the synthesis equation (5.8), we find that

$$\frac{1}{2\pi}\int_{2\pi}X(e^{j\omega})e^{j\omega n}\,d\omega\,=\,\frac{1}{2\pi}\int_{2\pi}\sum_{l=-\infty}^{+\infty}2\pi\,\delta(\omega-\omega_0-2\pi l)e^{j\omega n}\,d\omega.$$

![](_page_11_Figure_4.jpeg)

*<sup>w</sup>***Figure 5.8** Fourier transform of x[n] = *eiwan.* 

Note that any interval of length 27T includes exactly one impulse in the summation given in eq. (5.18). Therefore, if the interval of integration chosen includes the impulse located at *w0* + *21Tr,* then

$$\frac{1}{2\pi} \int_{2\pi} X(e^{j\omega}) e^{j\omega n} d\omega = e^{j(\omega_0 + 2\pi r)n} = e^{j\omega_0 n}.$$

Now consider a periodic sequence *x[n]* with period Nand with the Fourier series representation

$$x[n] = \sum_{k=\langle N \rangle} a_k e^{jk(2\pi/N)n}.$$
 (5.19)

In this case, the Fourier transform is

$$X(e^{j\omega}) = \sum_{k=-\infty}^{+\infty} 2\pi a_k \,\delta\left(\omega - \frac{2\pi k}{N}\right),\tag{5.20}$$

so that the Fourier transform of a periodic signal can be directly constructed from its Fourier coefficients.

To verify that eq. (5.20) is in fact correct, note that *x[n]* in eq. (5.19) is a linear combination of signals of the form in eq. (5.17), and thus the Fourier transform of *x[n]*  must be a linear combination of transforms of the form of eq. (5.18). In particular, suppose that we choose the interval of summation in eq. (5.19) ask = 0, 1, ... , *N-* 1, so that

$$x[n] = a_0 + a_1 e^{j(2\pi/N)n} + a_2 e^{j2(2\pi/N)n} + \dots + a_{N-1} e^{j(N-1)(2\pi/N)n}.$$
(5.21)

Thus, x[n] is a linear combination of signals, as in eq. (5.17), with  $\omega_0 = 0$ ,  $2\pi/N$ ,  $4\pi/N$ , ...,  $(N-1)2\pi/N$ . The resulting Fourier transform is illustrated in Figure 5.9. In Figure 5.9(a), we have depicted the Fourier transform of the first term on the right-hand side of eq. (5.21): The Fourier transform of the constant signal  $a_0 = a_0 e^{j0 \cdot n}$  is a periodic impulse train, as in eq. (5.18), with  $\omega_0 = 0$  and a scaling of  $2\pi a_0$  on each of the impulses. Moreover, from Chapter 4 we know that the Fourier series coefficients  $a_k$  are periodic with period N, so that  $2\pi a_0 = 2\pi a_N = 2\pi a_{-N}$ . In Figure 5.9(b) we have illustrated the Fourier transform of the second term in eq. (5.21), where we have again used eq. (5.18),

![](_page_12_Figure_4.jpeg)

**Figure 5.9** Fourier transform of a discrete-time periodic signal: (a) Fourier transform of the first term on the right-hand side of eq. (5.21); (b) Fourier transform of the second term in eq. (5.21); (c) Fourier transform of the last term in eq. (5.21); (d) Fourier transform of x[n] in eq (5.21).

in this case for  $a_1e^{j(2\pi/N)n}$ , and the fact that  $2\pi a_1 = 2\pi a_{N+1} = 2\pi a_{-N+1}$ . Similarly, Figure 5.9(c) depicts the final term. Finally, Figure 5.9(d) depicts the entire expression for  $X(e^{j\omega})$ . Note that because of the periodicity of the  $a_k$ ,  $X(e^{j\omega})$  can be interpreted as a train of impulses occurring at multiples of the fundamental frequency  $2\pi/N$ , with the area of the impulse located at  $\omega = 2\pi k/N$  being  $2\pi a_k$ , which is exactly what is stated in eq. (5.20).

#### Example 5.5

Consider the periodic signal

$$x[n] = \cos \omega_0 n = \frac{1}{2} e^{j\omega_0 n} + \frac{1}{2} e^{-j\omega_0 n}, \quad \text{with} \quad \omega_0 = \frac{2\pi}{5}.$$
 (5.22)

From eq. (5.18), we can immediately write

$$X(e^{j\omega}) = \sum_{l=-\infty}^{+\infty} \pi \,\delta\left(\omega - \frac{2\pi}{5} - 2\pi l\right) + \sum_{l=-\infty}^{+\infty} \pi \,\delta\left(\omega + \frac{2\pi}{5} - 2\pi l\right). \tag{5.23}$$

That is,

$$X(e^{j\omega}) = \pi \delta\left(\omega - \frac{2\pi}{5}\right) + \pi \delta\left(\omega + \frac{2\pi}{5}\right), \qquad -\pi \le \omega < \pi,$$
 (5.24)

and  $X(e^{j\omega})$  repeats periodically with a period of  $2\pi$ , as illustrated in Figure 5.10.

![](_page_13_Figure_11.jpeg)

**Figure 5.10** Discrete-time Fourier transform of  $x[n] = \cos \omega_0 n$ .

# Example 5.6

The discrete-time counterpart of the periodic impulse train of Example 4.8 is the sequence

$$x[n] = \sum_{k=-\infty}^{+\infty} \delta[n-kN], \qquad (5.25)$$

as sketched in Figure 5.11(a). The Fourier series coefficients for this signal can be calculated directly from eq. (3.95):

$$a_k = \frac{1}{N} \sum_{n = \langle N \rangle} x[n] e^{-jk(2\pi/N)n}.$$

Choosing the interval of summation as 0 :::; *n* :::; *N-* 1, we have

$$a_k = \frac{1}{N}. (5.26)$$

Using eqs. (5.26) and (5.20), we can then represent the Fourier transform of the signal as

$$X(e^{j\omega}) = \frac{2\pi}{N} \sum_{k=-\infty}^{+\infty} \delta\left(\omega - \frac{2\pi k}{N}\right),\tag{5.27}$$

which is illustrated in Figure 5.1l(b).

![](_page_14_Figure_8.jpeg)

![](_page_14_Figure_9.jpeg)

**Figure 5.11** (a) Discrete-time periodic impulse train; (b) its Fourier transform.

#### **5.3 PROPERTIES OF THE DISCRETE-TIME FOURIER TRANSFORM**

As with the continuous-time Fourier transform, a variety of properties of the discrete-time Fourier transform provide further insight into the transform and, in addition, are often useful in reducing the complexity in the evaluation of transforms and inverse transforms. In this and the following two sections we consider these properties, and in Table 5.1 we present a concise summary of them. By comparing this table with Table 4.1, we can get a clear picture of some of the similarities and differences between continuous-time and discrete-time Fourier transform properties. When the derivation or interpretation of a discrete-time Fourier transform property is essentially identical to its continuous-time counterpart, we will simply state the property. Also, because of the close relationship between the Fourier series and the Fourier transform, many of the transform properties

translate directly into corresponding properties for the discrete-time Fourier series, which we summarized in Table 3.2 and briefly discussed in Section 3.7.

In the following discussions, it will be convenient to adopt notation similar to that used in Section 4.3 to indicate the pairing of a signal and its transform. That is,

$$X(e^{j\omega}) = \mathfrak{F}\{x[n]\},$$
  
 $x[n] = \mathfrak{F}^{-1}\{X(e^{j\omega})\},$   
 $x[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j\omega}).$ 

#### **5.3.1 Periodicity of the Discrete-Time Fourier Transform**

As we discussed in Section 5.1, the discrete-time Fourier transform is *always* periodic in *w* with period 27T; i.e.,

$$X(e^{j(\omega+2\pi)}) = X(e^{j\omega}).$$
 (5.28)

This is in contrast to the continuous-time Fourier transform, which in general is not periodic.

# **5.3.2 Linearity of the Fourier Transform**

If

$$x_1[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X_1(e^{j\omega})$$

and

$$x_2[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X_2(e^{j\omega}),$$

then

$$ax_1[n] + bx_2[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} aX_1(e^{j\omega}) + bX_2(e^{j\omega}). \tag{5.29}$$

# **5.3.3 Time Shifting and Frequency Shifting**

If

$$x[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j\omega}),$$

then

$$x[n-n_0] \stackrel{\mathfrak{F}}{\longleftrightarrow} e^{-j\omega n_0} X(e^{j\omega}) \tag{5.30}$$

and

$$e^{j\omega_0 n} x[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j(\omega - \omega_0)}). \tag{5.31}$$

Equation (5.30) can be obtained by direct substitution of  $x[n-n_0]$  into the analysis equation (5.9), while eq. (5.31) is derived by substituting  $X(e^{j(\omega-\omega_0)})$  into the synthesis equation (5.8).

As a consequence of the periodicity and frequency-shifting properties of the discretetime Fourier transform, there exists a special relationship between ideal lowpass and ideal highpass discrete-time filters. This is illustrated in the next example.

### Example 5.7

In Figure 5.12(a) we have depicted the frequency response  $H_{\rm lp}(e^{j\omega})$  of a lowpass filter with cutoff frequency  $\omega_c$ , while in Figure 5.12(b) we have displayed  $H_{\rm lp}(e^{j(\omega-\pi)})$ —that is, the frequency response  $H_{\rm lp}(e^{j\omega})$  shifted by one-half period, i.e., by  $\pi$ . Since high frequencies in discrete time are concentrated near  $\pi$  (and other odd multiples of  $\pi$ ), the filter in Figure 5.12(b) is an ideal highpass filter with cutoff frequency  $\pi - \omega_c$ . That is,

$$H_{\rm hp}(e^{j\omega}) = H_{\rm lp}(e^{j(\omega-\pi)}). \tag{5.32}$$

As we can see from eq. (3.122), and as we will discuss again in Section 5.4, the frequency response of an LTI system is the Fourier transform of the impulse response of the system. Thus, if  $h_{lp}[n]$  and  $h_{hp}[n]$  respectively denote the impulse responses of

![](_page_16_Figure_11.jpeg)

**Figure 5.12** (a) Frequency response of a lowpass filter; (b) frequency response of a highpass filter obtained by shifting the frequency response in (a) by  $\omega = \pi$  corresponding to one-half period.

Figure 5.12, eq. (5.32) and the frequency-shifting property imply that the lowpass and highpass filters in

$$h_{\rm hp}[n] = e^{j\pi n} h_{\rm lp}[n] \tag{5.33}$$

$$= (-1)^n h_{lp}[n]. (5.34)$$

# **5.3.4 Conjugation and Conjugate Symmetry**

If

$$x[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j\omega}),$$

then

$$x^*[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X^*(e^{-j\omega}).$$
 (5.35)

Also, if *x[n]* is real valued, its transform *X(ejw)* is conjugate symmetric. That is,

$$X(e^{j\omega}) = X^*(e^{-j\omega}) \quad [x[n]\text{real}].$$
 (5.36)

From this, it follows that ffie{X(ejw)} is an even function of *w* and *9m{X(ejw)}* is an odd function of *w.* Similarly, the magnitude of *X(ejw)* is an even function and the phase angle is an odd function. Furthermore,

$$\mathcal{E}v\{x[n]\} \stackrel{\mathcal{F}}{\longleftrightarrow} \Re e\{X(e^{j\omega})\}$$

and

$$\mathfrak{O}d\{x[n]\} \stackrel{\mathfrak{F}}{\longleftrightarrow} j\mathfrak{G}m\{X(e^{j\omega})\},$$

where 8v and *fJd* denote the even and odd parts, respectively, of *x[n].* For example, if *x[n]*  is real and even, its Fourier transform is also real and even. Example 5.2 illustrates this symmetry for *x[n]* = alnl.

# **5.3.5 Differencing and Accumulation**

In this subsection, we consider the discrete-time counterpart of integration-that is, accumulation-and its inverse, first differencing. Let *x[n]* be a signal with Fourier transform *X(ejw).* Then, from the linearity and time-shifting properties, the Fourier transform pair for the first-difference signal *x[n]* - *x[n* - 1] is given by

$$x[n] - x[n-1] \stackrel{\mathfrak{F}}{\longleftrightarrow} (1 - e^{-j\omega})X(e^{j\omega}).$$
 (5.37)

Next, consider the signal

$$y[n] = \sum_{m = -\infty}^{n} x[m].$$
 (5.38)

Since y[n] - y[n-1] = x[n], we might conclude that the transform of y[n] should be related to the transform of x[n] by division by  $(1 - e^{-j\omega})$ . This is partly correct, but as with the continuous-time integration property given by eq. (4.32), there is more involved. The precise relationship is

$$\left| \sum_{m=-\infty}^{n} x[m] \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1}{1 - e^{-j\omega}} X(e^{j\omega}) + \pi X(e^{j0}) \sum_{k=-\infty}^{+\infty} \delta(\omega - 2\pi k). \right|$$
 (5.39)

The impulse train on the right-hand side of eq. (5.39) reflects the dc or average value that can result from summation.

## Example 5.8

Let us derive the Fourier transform  $X(e^{j\omega})$  of the unit step x[n] = u[n] by making use of the accumulation property and the knowledge that

$$g[n] = \delta[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} G(e^{j\omega}) = 1.$$

From Section 1.4.1 we know that the unit step is the running sum of the unit impulse. That is,

$$x[n] = \sum_{m=-\infty}^{n} g[m].$$

Taking the Fourier transform of both sides and using accumulation yields

$$X(e^{j\omega}) = \frac{1}{(1 - e^{-j\omega})} G(e^{j\omega}) + \pi G(e^{j0}) \sum_{k = -\infty}^{\infty} \delta(\omega - 2\pi k)$$
$$= \frac{1}{1 - e^{-j\omega}} + \pi \sum_{k = -\infty}^{\infty} \delta(\omega - 2\pi k).$$

#### 5.3.6 Time Reversal

Let x[n] be a signal with spectrum  $X(e^{j\omega})$ , and consider the transform  $Y(e^{j\omega})$  of y[n] = x[-n]. From eq. (5.9),

$$Y(e^{j\omega}) = \sum_{n = -\infty}^{+\infty} y[n]e^{-j\omega n} = \sum_{n = -\infty}^{+\infty} x[-n]e^{-j\omega n}.$$
 (5.40)

Substituting m = -n into eq. (5.40), we obtain

$$Y(e^{j\omega}) = \sum_{m=-\infty}^{+\infty} x[m]e^{-j(-\omega)m} = X(e^{-j\omega}).$$
 (5.41)

That is,

$$x[-n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{-j\omega}). \tag{5.42}$$

#### 5.3.7 Time Expansion

Because of the discrete nature of the time index for discrete-time signals, the relation between time and frequency scaling in discrete time takes on a somewhat different form from its continuous-time counterpart. Specifically, in Section 4.3.5 we derived the continuous-time property

$$x(at) \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1}{|a|} X \left( \frac{j\omega}{a} \right).$$
 (5.43)

However, if we try to define the signal x[an], we run into difficulties if a is not an integer. Therefore, we cannot slow down the signal by choosing a < 1. On the other hand, if we let a be an integer other than  $\pm 1$ —for example, if we consider x[2n]—we do not merely speed up the original signal. That is, since n can take on only integer values, the signal x[2n] consists of the even samples of x[n] alone.

There is a result that does closely parallel eq. (5.43), however. Let k be a positive integer, and define the signal

$$x_{(k)}[n] = \begin{cases} x[n/k], & \text{if } n \text{ is a multiple of } k \\ 0, & \text{if } n \text{ is not a multiple of } k. \end{cases}$$
 (5.44)

As illustrated in Figure 5.13 for k = 3,  $x_{(k)}[n]$  is obtained from x[n] by placing k-1 zeros between successive values of the original signal. Intuitively, we can think of  $x_{(k)}[n]$  as a slowed-down version of x[n]. Since  $x_{(k)}[n]$  equals 0 unless n is a multiple of k, i.e., unless n = rk, we see that the Fourier transform of  $x_{(k)}[n]$  is given by

$$X_{(k)}(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} x_{(k)}[n]e^{-j\omega n} = \sum_{r=-\infty}^{+\infty} x_{(k)}[rk]e^{-j\omega rk}.$$

![](_page_19_Figure_12.jpeg)

![](_page_19_Figure_13.jpeg)

**Figure 5.13** The signal  $x_{(3)}[n]$  obtained from x[n] by inserting two zeros between successive values of the original signal.

Furthermore, since  $x_{(k)}[rk] = x[r]$ , we find that

$$X_{(k)}(e^{j\omega}) = \sum_{r=-\infty}^{+\infty} x[r]e^{-j(k\omega)r} = X(e^{jk\omega}).$$

That is,

$$x_{(k)}[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{jk\omega}).$$
 (5.45)

Note that as the signal is spread out and slowed down in time by taking k > 1, its Fourier transform is compressed. For example, since  $X(e^{j\omega})$  is periodic with period  $2\pi/K$ . This property is illustrated in Figure 5.14 for a rectangular pulse.

![](_page_20_Figure_8.jpeg)

**Figure 5.14** Inverse relationship between the time and frequency domains: As k increases,  $x_{(k)}[n]$  spreads out while its transform is compressed.

## Example 5.9

As an illustration of the usefulness of the time-expansion property in determining Fourier transforms, let us consider the sequence x[n] displayed in Figure 5.15(a). This sequence can be related to the simpler sequence y[n] depicted in Figure 5.15(b). In particular

$$x[n] = y_{(2)}[n] + 2y_{(2)}[n-1],$$

where

$$y_{(2)}[n] = \begin{cases} y[n/2], & \text{if } n \text{ is even} \\ 0, & \text{if } n \text{ is odd} \end{cases}$$

and  $y_{(2)}[n-1]$  represents  $y_{(2)}[n]$  shifted one unit to the right. The signals  $y_{(2)}[n]$  and  $2y_{(2)}[n-1]$  are depicted in Figures 5.15(c) and (d), respectively.

Next, note that y[n] = g[n-2], where g[n] is a rectangular pulse as considered in Example 5.3 (with  $N_1 = 2$ ) and as depicted in Figure 5.6(a). Consequently, from Example 5.3 and the time-shifting property, we see that

$$Y(e^{j\omega}) = e^{-j2\omega} \frac{\sin(5\omega/2)}{\sin(\omega/2)}.$$

![](_page_21_Figure_10.jpeg)

**Figure 5.15** (a) The signal x[n] in Example 5.9; (b) the signal y[n]; (c) the signal  $y_{(2)}[n]$  obtained by inserting one zero between successive values of y[n]; and (d) the signal  $2y_{(2)}[n-1]$ .

Using the time-expansion property, we then obtain

$$y_{(2)}[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} e^{-j4\omega} \frac{\sin(5\omega)}{\sin(\omega)},$$

and using the linearity and time-shifting properties, we get

$$2y_{(2)}[n-1] \stackrel{\mathfrak{F}}{\longleftrightarrow} 2e^{-j5\omega} \frac{\sin(5\omega)}{\sin(\omega)}.$$

Combining these two results, we have

$$X(e^{j\omega}) = e^{-j4\omega}(1+2e^{-j\omega})\left(\frac{\sin(5\omega)}{\sin(\omega)}\right).$$

#### 5.3.8 Differentiation in Frequency

Again, let

$$x[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j\omega}).$$

If we use the definition of  $X(e^{j\omega})$  in the analysis equation (5.9) and differentiate both sides, we obtain

$$\frac{dX(e^{j\omega})}{d\omega} = \sum_{n=-\infty}^{+\infty} -jnx[n]e^{-j\omega n}.$$

The right-hand side of this equation is the Fourier transform of -jnx[n]. Therefore, multiplying both sides by j, we see that

$$nx[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} j\frac{dX(e^{j\omega})}{d\omega}. \tag{5.46}$$

The usefulness of this property will be illustrated in Example 5.13 in Section 5.4.

#### 5.3.9 Parseval's Relation

If x[n] and  $X(e^{j\omega})$  are a Fourier transform pair, then

$$\sum_{n=-\infty}^{+\infty} |x[n]|^2 = \frac{1}{2\pi} \int_{2\pi} |X(e^{j\omega})|^2 d\omega.$$
 (5.47)

We note that this is similar to eq. (4.43), and the derivation proceeds in a similar manner. The quantity on the left-hand side of eq. (5.47) is the total energy in the signal x[n], and

Parse val's relation states that this energy can also be determined by integrating the energy per unit frequency, *iX(eiw)i 2127T,* over a full27T interval of distinct discrete-time frequencies. In analogy with the continuous-time case, *iX(eiw)i <sup>2</sup>*is referred to as the *energy-density spectrum* of the signal *x[n].* Note also that eq. (5.47) is the counterpart for aperiodic signals of Parseval's relation, eq. (3.110), for periodic signals, which equates the average power in a periodic signal with the sum of the average powers of its individual harmonic components.

Given the Fourier transform of a sequence, it is possible to use Fourier transform properties to determine whether a particular sequence has a number of different properties. To illustrate this idea, we present the following example.

#### **Example 5. 1 0**

Consider the sequence *x[n]* whose Fourier transform *X(eiw)* is depicted for -7r ::::; *w* ::::; 7r in Figure 5.16. We wish to determine whether or not, in the time domain, *x[n]*  is periodic, real, even, and/or of finite energy.

![](_page_23_Figure_6.jpeg)

![](_page_23_Figure_7.jpeg)

**Figure 5. 16** Magnitude and phase of the Fourier transform for Example5.10.

Accordingly, we note first that periodicity in the time domain implies that the Fourier transform is zero, except possibly for impulses located at various integer multiples of the fundamental frequency. This is not true for *X(eiw).* We conclude, then, that *x[n]* is *not* periodic.

Next, from the symmetry properties for Fourier transforms, we know that a realvalued sequence must have a Fourier transform of even magnitude and a phase function that is odd. This is true for the given IX(eiw)l and *1-:X(eiw).* We thus conclude that *x[n]*  is real.

Third, if *x[n]* is an even function, then, by the symmetry properties forreal signals, *X(eiw)* must be real and even. However, since *X(eiw)* = IX(eiw)le-*i <sup>2</sup>w, X(eiw)* is not a real-valued function. Consequently, *x[n]* is not even.

Finally, to test for the finite-energy property, we may use Parseval's relation,

$$\sum_{n=-\infty}^{\infty} |x[n]|^2 = \frac{1}{2\pi} \int_{2\pi} |X(e^{j\omega})|^2 d\omega.$$

It is clear from Figure 5.16 that integrating IX(eiw)l2 from -w to *1r* will yield a finite quantity. We conclude that *x[n]* has finite energy.

In the next few sections, we consider several additional properties. The first two of these are the convolution and multiplication properties, similar to those discussed in Sections 4.4 and 4.5. The third is the property of duality, which is examined in Section 5.7, where we consider not only duality in the discrete-time domain, but also the duality that exists *between* the continuous-time and discrete-time domains.

#### **5.4 THE CONVOLUTION PROPERTY**

In Section 4.4, we discussed the importance of the continuous-time Fourier transform with regard to its effect on the operation of convolution and its use in dealing with continuoustime LTI systems. An identical relation applies in discrete time, and this is one of the principal reasons that the discrete-time Fourier transform is of such great value in representing and analyzing discrete-time LTI systems. Specifically, if *x[n], h[n],* and *y[n]* are the input, impulse response, and output, respectively, of an LTI system, so that

$$y[n] = x[n] * h[n],$$

then

$$Y(e^{j\omega}) = X(e^{j\omega})H(e^{j\omega}), \qquad (5.48)$$

where *X(ejw), H(ejw),* and *Y(ejw)* are the Fourier transforms of *x[n], h[n],* and *y[n],* respectively. Furthermore, comparing eqs. (3.122) and (5.9), we see that the frequency response of a discrete-time LTI system, as first defined in Section 3.8, is the Fourier transform of the impulse response of the system.

The derivation of eq. (5.48) exactly parallels that carried out in Section 4.4. In particular, as in continuous time, the Fourier synthesis equation (5.8) for *x[n]* can be interpreted as a decomposition of x[n] into a linear combination of complex exponentials with infinitesimal amplitudes proportional to  $X(e^{j\omega})$ . Each of these exponentials is an eigenfunction of the system. In Chapter 3, we used this fact to show that the Fourier series coefficients of the response of an LTI system to a periodic input are simply the Fourier coefficients of the input multiplied by the system's frequency response evaluated at the corresponding harmonic frequencies. The convolution property (5.48) represents the extension of this result to aperiodic inputs and outputs by using the Fourier transform rather than the Fourier series.

As in continuous time, eq. (5.48) maps the convolution of two signals to the simple algebraic operation of multiplying their Fourier transforms, a fact that both facilitates the analysis of signals and systems and adds significantly to our understanding of the way in which an LTI system responds to the input signals that are applied to it. In particular, from eq. (5.48), we see that the frequency response  $H(e^{j\omega})$  captures the change in complex amplitude of the Fourier transform of the input at each frequency  $\omega$ . Thus, in frequency-selective filtering, for example, we want  $H(e^{j\omega}) \approx 1$  over the range of frequencies corresponding to the desired passband and  $H(e^{j\omega}) \approx 0$  over the band of frequencies to be eliminated or significantly attenuated.

#### 5.4.1 Examples

To illustrate the convolution property, along with a number of other properties, we consider several examples in this section.

# Example 5.11

Consider an LTI system with impulse response

$$h[n] = \delta[n - n_0].$$

The frequency response is

$$H(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} \delta[n-n_0]e^{-j\omega n} = e^{-j\omega n_0}.$$

Thus, for any input x[n] with Fourier transform  $X(e^{j\omega})$ , the Fourier transform of the output is

$$Y(e^{j\omega}) = e^{-j\omega n_0} X(e^{j\omega}). \tag{5.49}$$

We note that, for this example,  $y[n] = x[n - n_0]$  and eq. (5.49) is consistent with the time-shifting property. Note also that the frequency response  $H(e^{j\omega}) = e^{-j\omega n_0}$  of a pure time shift has unity magnitude at all frequencies and a phase characteristic  $-\omega n_0$  that is linear with frequency.

# Example 5.12

Consider the discrete-time ideal lowpass filter introduced in Section 3.9.2. This system has the frequency response  $H(e^{j\omega})$  illustrated in Figure 5.17(a). Since the impulse

response and frequency response of an LTI system are a Fourier transform pair, we can determine the impulse response of the ideallowpass filter from the frequency response using the Fourier transform synthesis equation (5.8). In particular, using -7r *w* ::::; *1r*  as the interval of integration in that equation, we see from Figure 5.17(a) that

$$h[n] = \frac{1}{2\pi} \int_{-\pi}^{\pi} H(e^{j\omega}) e^{j\omega n} d\omega = \frac{1}{2\pi} \int_{-\omega_c}^{\omega_c} e^{j\omega n} d\omega$$

$$= \frac{\sin \omega_c n}{\pi n},$$
(5.50)

which is shown in Figure 5.17(b).

![](_page_26_Figure_6.jpeg)

![](_page_26_Figure_7.jpeg)

**Figure 5. 17** (a) Frequency response of a discrete-time ideal lowpass filter; (b) impulse response of the ideal lowpass filter.

In Figure 5.17, we come across many of the same issues that surfaced with the continuous-time ideallowpass filter in Example 4.18. First, since *h[n]* is not zero for *n* < 0, the ideallowpass filter is not causal. Second, even if causality is not an important issue, there are other reasons, including ease of implementation and preferable time domain characteristics, that nonideal filters are generally used to perform frequency-selective filtering. In particular, the impulse response of the ideallowpass filter in Figure 5.17 (b) is oscillatory, a characteristic that is undesirable in some applications. In such cases, a tradeoff between frequency-domain objectives such as frequency selectivity and time-domain properties such as nonoscillatory behavior must be made. In Chapter 6, we will discuss these and related ideas in more detail.

As the following example illustrates, the convolution property can also be of value in facilitating the calculation of convolution sums.

# **Example 5. 1 3**

Consider an LTI system with impulse response

$$h[n] = \alpha^n u[n],$$

with Ia I < 1, and suppose that the input to this system is

$$x[n] = \beta^n u[n],$$

with l/31 < 1. Evaluating the Fourier transforms of *h[n]* and *x[n],* we have

$$H(e^{j\omega}) = \frac{1}{1 - \alpha e^{-j\omega}} \tag{5.51}$$

and

$$X(e^{j\omega}) = \frac{1}{1 - \beta e^{-j\omega}},\tag{5.52}$$

so that

$$Y(e^{j\omega}) = H(e^{j\omega})X(e^{j\omega}) = \frac{1}{(1 - \alpha e^{-j\omega})(1 - \beta e^{-j\omega})}.$$
 (5.53)

As with Example 4.19, determining the inverse transform of *Y(ejw)* is most easily done by expanding *Y(ejw)* by the method of partial fractions. Specifically, *Y(ejw)* is a ratio of polynomials in powers of *e-jw,* and we would like to express this as a sum of simpler terms of this type so that we can find the inverse transform of each term by inspection (together, perhaps, with the use of the frequency differentiation property of Section 5.3.8). The general algebraic procedure for rational transforms is described in the appendix. For this example, if *a ¥- f3,* the partial fraction expansion of *Y* ( *ejw)* is of the form

$$Y(e^{j\omega}) = \frac{A}{1 - \alpha e^{-j\omega}} + \frac{B}{1 - \beta e^{-j\omega}}.$$
 (5.54)

Equating the right-hand sides of eqs (5.53) and (5.54), we find that

$$A = \frac{\alpha}{\alpha - \beta}, \quad B = -\frac{\beta}{\alpha - \beta}.$$

Therefore, from Example 5.1 and the linearity property, we can obtain the inverse transform of eq. (5.54) by inspection:

$$y[n] = \frac{\alpha}{\alpha - \beta} \alpha^{n} u[n] - \frac{\beta}{\alpha - \beta} \beta^{n} u[n]$$

$$= \frac{1}{\alpha - \beta} [\alpha^{n+1} u[n] - \beta^{n+1} u[n]].$$
(5.55)

For *a* = *f3,* the partial-fraction expansion in eq. ( 5.54) is not valid. However, in this case,

$$Y(e^{j\omega}) = \left(\frac{1}{1-\alpha e^{-j\omega}}\right)^2,$$

which can be expressed as

$$Y(e^{j\omega}) = \frac{j}{\alpha} e^{j\omega} \frac{d}{d\omega} \left( \frac{1}{1 - \alpha e^{-j\omega}} \right). \tag{5.56}$$

As in Example 4.19, we can use the frequency differentiation property, eq. (5.46), together with the Fourier transform pair

$$\alpha^n u[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1}{1-\alpha e^{-j\omega}},$$

to conclude that

$$n\alpha^n u[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} j \frac{d}{d\omega} \left( \frac{1}{1 - \alpha e^{-j\omega}} \right).$$

To account for the factor  $e^{j\omega}$ , we use the time-shifting property to obtain

$$(n+1)\alpha^{n+1}u[n+1] \stackrel{\mathfrak{F}}{\longleftrightarrow} je^{j\omega}\frac{d}{d\omega}\left(\frac{1}{1-\alpha e^{-j\omega}}\right),$$

and finally, accounting for the factor  $1/\alpha$ , in eq. (5.56), we obtain

$$y[n] = (n+1)\alpha^n u[n+1]. \tag{5.57}$$

It is worth noting that, although the right-hand side is multiplied by a step that begins at n = -1, the sequence  $(n + 1)\alpha^n u[n + 1]$  is still zero prior to n = 0, since the factor n + 1 is zero at n = -1. Thus, we can alternatively express y[n] as

$$y[n] = (n+1)\alpha^{n}u[n]. {(5.58)}$$

As illustrated in the next example, the convolution property, along with other Fourier transform properties, is often useful in analyzing system interconnections.

# Example 5.14

Consider the system shown in Figure 5.18(a) with input x[n] and output y[n]. The LTI systems with frequency response  $H_{lp}(e^{j\omega})$  are ideal lowpass filters with cutoff frequency  $\pi/4$  and unity gain in the passband.

Let us first consider the top path in Figure 5.18(a). The Fourier transform of the signal  $w_1[n]$  can be obtained by noting that  $(-1)^n = e^{j\pi n}$  so that  $w_1[n] = e^{j\pi n}x[n]$ . Using the frequency-shifting property, we then obtain

$$W_1(e^{j\omega}) = X(e^{j(\omega-\pi)}).$$

The convolution property yields

$$W_2(e^{j\omega}) = H_{lp}(e^{j\omega})X(e^{j(\omega-\pi)}).$$

Since  $w_3[n] = e^{j\pi n} w_2[n]$ , we can again apply the frequency-shifting property to obtain

$$W_3(e^{j\omega}) = W_2(e^{j(\omega-\pi)})$$
  
=  $H_{lp}(e^{j(\omega-\pi)})X(e^{j(\omega-2\pi)}).$ 

![](_page_29_Figure_2.jpeg)

![](_page_29_Figure_3.jpeg)

**Figure 5. 18** (a) System interconnection for Example 5.14; (b) the overall frequency response for this system.

Since discrete-time Fourier transforms are always periodic with period 27T,

$$W_3(e^{j\omega}) = H_{ln}(e^{j(\omega-\pi)})X(e^{j\omega}).$$

Applying the convolution property to the lower path, we get

$$W_4(e^{j\omega}) = H_{lp}(e^{j\omega})X(e^{j\omega}).$$

From the linearity property of the Fourier transform, we obtain

$$Y(e^{j\omega}) = W_3(e^{j\omega}) + W_4(e^{j\omega})$$
  
=  $[H_{lp}(e^{j(\omega-\pi)}) + H_{lp}(e^{j\omega})]X(e^{j\omega}).$ 

Consequently, the overall system in Figure 5.18(a) has the frequency response

$$H(e^{j\omega}) = [H_{lp}(e^{j(\omega-\pi)}) + H_{lp}(e^{j\omega})]$$

which is shown in Figure 5.18(b).

As we saw in Example 5.7, *H 1p(ei<w-'TT))* is the frequency response of an ideal highpass filter. Thus, the overall system passes both low and high frequencies and stops frequencies between these two pass bands. That is, the filter has what is often referred to as an *ideal bandstop characteristic,* where the stopband is the region 7T/4 < lwl < 37T/4.

It is important to note that, as in continuous time, not every discrete-time LTI system has a frequency response. For example, the LTI system with impulse response *h[n]* = *2nu[n]* does not have a finite response to sinusoidal inputs, which is reflected in the fact that the Fourier transform analysis equation for h[n] diverges. However, if an LTI system is stable, then, from Section 2.3.7, its impulse response is absolutely summable; that is,

$$\sum_{n=-\infty}^{+\infty} |h[n]| < \infty. \tag{5.59}$$

Therefore, the frequency response always converges for stable systems. In using Fourier methods, we will be restricting ourselves to systems with impulse responses that have well-defined Fourier transforms. In Chapter 10, we will introduce an extension of the Fourier transform referred to as the *z*-transform that will allow us to use transform techniques for LTI systems for which the frequency response does not converge.

#### 5.5 THE MULTIPLICATION PROPERTY

In Section 4.5, we introduced the multiplication property for continuous-time signals and indicated some of its applications through several examples. An analogous property exists for discrete-time signals and plays a similar role in applications. In this section, we derive this result directly and give an example of its use. In Chapters 7 and 8, we will use the multiplication property in the context of our discussions of sampling and communications.

Consider y[n] equal to the product of  $x_1[n]$  and  $x_2[n]$ , with  $Y(e^{j\omega})$ ,  $X_1(e^{j\omega})$ , and  $X_2(e^{j\omega})$  denoting the corresponding Fourier transforms. Then

$$Y(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} y[n]e^{-j\omega n} = \sum_{n=-\infty}^{+\infty} x_1[n]x_2[n]e^{-j\omega n},$$

or since

$$x_1[n] = \frac{1}{2\pi} \int_{2\pi} X_1(e^{j\theta}) e^{j\theta n} d\theta,$$
 (5.60)

it follows that

$$Y(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} x_2[n] \left\{ \frac{1}{2\pi} \int_{2\pi} X_1(e^{j\theta}) e^{j\theta n} d\theta \right\} e^{-j\omega n}.$$
 (5.61)

Interchanging the order of summation and integration, we obtain

$$Y(e^{j\omega}) = \frac{1}{2\pi} \int_{2\pi} X_1(e^{j\theta}) \left[ \sum_{n=-\infty}^{+\infty} x_2[n] e^{-j(\omega-\theta)n} \right] d\theta.$$
 (5.62)

The bracketed summation is  $X_2(e^{j(\omega-\theta)})$ , and consequently, eq. (5.62) becomes

$$Y(e^{j\omega}) = \frac{1}{2\pi} \int_{2\pi} X_1(e^{j\theta}) X_2(e^{j(\omega-\theta)}) d\theta.$$
 (5.63)

Equation (5.63) corresponds to a *periodic* convolution of  $X_1(e^{j\omega})$  and  $X_2(e^{j\omega})$ , and the integral in this equation can be evaluated over any interval of length  $2\pi$ . The usual form of convolution (in which the integral ranges from  $-\infty$  to  $+\infty$ ) is often referred to as aperiodic convolution to distinguish it from periodic convolution. The mechanics of periodic convolution are most easily illustrated through an example.

#### Example 5.15

Consider the problem of finding the Fourier transform  $X(e^{j\omega})$  of a signal x[n] which is the product of two other signals; that is,

$$x[n] = x_1[n]x_2[n],$$

where

$$x_1[n] = \frac{\sin(3\pi n/4)}{\pi n}$$

and

$$x_2[n] = \frac{\sin(\pi n/2)}{\pi n}.$$

From the multiplication property given in eq. (5.63), we know that  $X(e^{j\omega})$  is the periodic convolution of  $X_1(e^{j\omega})$  and  $X_2(e^{j\omega})$ , where the integral in eq. (5.63) can be taken over any interval of length  $2\pi$ . Choosing the interval  $-\pi < \theta \le \pi$ , we obtain

$$X(e^{j\omega}) = \frac{1}{2\pi} \int_{-\pi}^{\pi} X_1(e^{j\theta}) X_2(e^{j(\omega-\theta)}) d\theta.$$
 (5.64)

Equation (5.64) resembles aperiodic convolution, except for the fact that the integration is limited to the interval  $-\pi < \theta \le \pi$ . However, we can convert the equation into an ordinary convolution by defining

$$\hat{X}_1(e^{j\omega}) = \begin{cases} X_1(e^{j\omega}) & \text{for } -\pi < \omega \leq \pi \\ 0 & \text{otherwise} \end{cases}$$
.

Then, replacing  $X_1(e^{j\theta})$  in eq. (5.64) by  $\widehat{X}_1(e^{j\theta})$ , and using the fact that  $\widehat{X}_1(e^{j\theta})$  is zero for  $|\theta| > \pi$ , we see that

$$X(e^{j\omega}) = \frac{1}{2\pi} \int_{-\pi}^{\pi} \widehat{X}_1(e^{j\theta}) X_2(e^{j(\omega-\theta)}) d\theta$$
$$= \frac{1}{2\pi} \int_{-\infty}^{\infty} \widehat{X}_1(e^{j\theta}) X_2(e^{j(\omega-\theta)}) d\theta.$$

Thus,  $X(e^{j\omega})$  is  $1/2\pi$  times the aperiodic convolution of the rectangular pulse  $\hat{X}_1(e^{j\omega})$  and the periodic square wave  $X_2(e^{j\omega})$ , both of which are shown in Figure 5.19. The result of this convolution is the Fourier transform  $X(e^{j\omega})$  shown in Figure 5.20.

![](_page_32_Figure_3.jpeg)

**Figure 5.19**  $\hat{X}_1(e^{j\omega})$  representing one period of  $X_1(e^{j\omega})$ , and  $X_2(e^{j\omega})$ . The linear convolution of  $\hat{X}_1(e^{j\omega})$  and  $X_2(e^{j\omega})$  corresponds to the periodic convolution of  $X_1(e^{j\omega})$  and  $X_2(e^{j\omega})$ .

![](_page_32_Figure_5.jpeg)

Figure 5.20 Result of the periodic convolution in Example 5.15.

# 5.6 TABLES OF FOURIER TRANSFORM PROPERTIES AND BASIC FOURIER TRANSFORM PAIRS

In Table 5.1, we summarize a number of important properties of the discrete-time Fourier transform and indicate the section of the text in which each is discussed. In Table 5.2, we summarize some of the basic and most important discrete-time Fourier transform pairs. Many of these have been derived in examples in the chapter.

#### 5.7 DUALITY

In considering the continuous-time Fourier transform, we observed a symmetry or duality between the analysis equation (4.9) and the synthesis equation (4.8). No corresponding duality exists between the analysis equation (5.9) and the synthesis equation (5.8) for the discrete-time Fourier transform. However, there *is* a duality in the discrete-time Fourier *series* equations (3.94) and (3.95), which we develop in Section 5.7.1. In addition, there is

Sec. 5.7 Duality 391

TABLE 5.1 PROPERTIES OF THE DISCRETE-TIME FOURIER TRANSFORM

| Section | Property                            | Aperiodic Signal                                       |                                                                     | Fourier Transform                                                                                                                                                                                                                                                                                                             |
|---------|-------------------------------------|--------------------------------------------------------|---------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 5.3.2   | Linearity                           | x[n] $y[n]$ $ax[n] + by[n]$                            |                                                                     | $X(e^{j\omega})$ periodic with $Y(e^{j\omega})$ period $2\pi$ $aX(e^{j\omega}) + bY(e^{j\omega})$                                                                                                                                                                                                                             |
| 5.3.3   | Time Shifting                       | $x[n-n_0]$                                             |                                                                     | $e^{-j\omega n_0}X(e^{j\omega})$                                                                                                                                                                                                                                                                                              |
| 5.3.3   | Frequency Shifting                  | $e^{j\omega_0 n}x[n]$                                  |                                                                     | $X(e^{j(\omega-\omega_0)})$                                                                                                                                                                                                                                                                                                   |
| 5.3.4   | Conjugation                         | $x^*[n]$                                               |                                                                     | $X^*(e^{-j\omega})$                                                                                                                                                                                                                                                                                                           |
| 5.3.6   | Time Reversal                       | x[-n]                                                  | if moultiple of h                                                   | $X(e^{-j\omega})$                                                                                                                                                                                                                                                                                                             |
| 5.3.7   | Time Expansion                      | $x_{(k)}[n] = \begin{cases} x[n/k], \\ 0, \end{cases}$ | if $n = \text{multiple of } k$<br>if $n \neq \text{multiple of } k$ | $X(e^{jk\omega})$                                                                                                                                                                                                                                                                                                             |
| 5.4     | Convolution                         | x[n] * y[n]                                            | 1                                                                   | $X(e^{j\omega})Y(e^{j\omega})$                                                                                                                                                                                                                                                                                                |
| 5.5     | Multiplication                      | x[n]y[n]                                               |                                                                     | $\frac{1}{2\pi}\int_{2\pi}X(e^{j\theta})Y(e^{j(\omega-\theta)})d\theta$                                                                                                                                                                                                                                                       |
| 5.3.5   | Differencing in Time                | x[n] - x[n-1]                                          |                                                                     | $(1-e^{-j\omega})X(e^{j\omega})$                                                                                                                                                                                                                                                                                              |
| 5.3.5   | Accumulation                        | $\sum_{k=-\infty}^{n} x[k]$                            |                                                                     | $\frac{1}{1-e^{-j\omega}}X(e^{j\omega})$                                                                                                                                                                                                                                                                                      |
| 5.3.8   | Differentiation in Frequency        | nx[n]                                                  |                                                                     | $+\pi X(e^{j0}) \sum_{k=-\infty}^{+\infty} \delta(\omega - 2\pi k)$ $j \frac{dX(e^{j\omega})}{d\omega}$                                                                                                                                                                                                                       |
| 5.3.4   | Conjugate Symmetry for Real Signals | x[n] real                                              |                                                                     | $egin{array}{l} X(e^{j\omega}) &= X^*(e^{-j\omega}) \ \Re \langle X(e^{j\omega})  angle &= \Re \langle X(e^{-j\omega})  angle \ \Im \langle X(e^{j\omega})  angle &= -\Im \langle X(e^{-j\omega})  angle \  X(e^{j\omega})  &=  X(e^{-j\omega})  \ orall X(e^{j\omega}) &= - \Im \langle X(e^{-j\omega})  angle \end{array}$ |
| 5.3.4   | Symmetry for Real, Even Signals     | x[n] real an even                                      |                                                                     | $X(e^{j\omega})$ real and even                                                                                                                                                                                                                                                                                                |
| 5.3.4   | Symmetry for Real, Odd<br>Signals   | x[n] real and odd                                      |                                                                     | $X(e^{j\omega})$ purely imaginary and odd                                                                                                                                                                                                                                                                                     |
| 5.3.4   | Even-odd Decomposition              | $x_e[n] = \mathcal{E}\nu\{x[n]\}$                      | [x[n]  real]                                                        | $\Re\{X(e^{j\omega})\}$                                                                                                                                                                                                                                                                                                       |
|         | of Real Signals                     | $x_o[n] = \mathfrak{O}d\{x[n]\}$                       | [x[n]  real]                                                        | $j \mathcal{G}m\{X(e^{j\omega})\}$                                                                                                                                                                                                                                                                                            |
| 5.3.9   | Parseval's Re                       | elation for Aperiodic                                  | Signals                                                             |                                                                                                                                                                                                                                                                                                                               |
|         | $\sum_{n=-\infty}^{+\infty}  x[n] $ | $ ^2 = \frac{1}{2\pi} \int_{2\pi}  X(e^{j\omega}) ^2$  | $^{2}d\omega$                                                       |                                                                                                                                                                                                                                                                                                                               |

a duality relationship between the discrete-time Fourier transform and the continuous-time Fourier series. This relation is discussed in Section 5.7.2.

# **5.7.1** Duality in the Discrete-Time Fourier Series

Since the Fourier series coefficients  $a_k$  of a periodic signal x[n] are themselves a periodic sequence, we can expand the sequence  $a_k$  in a Fourier series. The duality property for discrete-time Fourier series implies that the Fourier series coefficients for the periodic sequence  $a_k$  are the values of (1/N)x[-n] (i.e., are proportional to the values of the original

TABLE 5.2 BASIC DISCRETE-TIME FOURIER TRANSFORM PAIRS

| Signal                                                                                                                 | Fourier Transform                                                                                                                             | Fourier Series Coefficients (if periodic)                                                                                                                                                                                                                                        |
|------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| $\sum_{k=\langle N\rangle} a_k e^{jk(2n/N)n}$                                                                          | $2\pi \sum_{k=-\infty}^{+\infty} a_k \delta\left(\omega - \frac{2\pi k}{N}\right)$                                                            | $a_k$                                                                                                                                                                                                                                                                            |
| $e^{j\omega_0 n}$                                                                                                      | $2\pi \sum_{l=-\infty}^{+\infty} \delta(\omega - \omega_0 - 2\pi l)$                                                                          | (a) $\omega_0 = \frac{2\pi m}{N}$ $a_k = \begin{cases} 1, & k = m, m \pm N, m \pm 2N, \dots \\ 0, & \text{otherwise} \end{cases}$ (b) $\frac{\omega_0}{2\pi}$ irrational $\Rightarrow$ The signal is aperiodic                                                                   |
| $\cos \omega_0 n$                                                                                                      | $\pi \sum_{l=-\infty}^{+\infty} \{\delta(\omega - \omega_0 - 2\pi l) + \delta(\omega + \omega_0 - 2\pi l)\}$                                  | (a) $\omega_0 = \frac{2\pi m}{N}$ $a_k = \begin{cases} \frac{1}{2}, & k = \pm m, \pm m \pm N, \pm m \pm 2N, \dots \\ 0, & \text{otherwise} \end{cases}$ (b) $\frac{\omega_0}{2\pi}$ irrational $\Rightarrow$ The signal is aperiodic                                             |
| $\sin \omega_0 n$                                                                                                      | $\frac{\pi}{j} \sum_{l=-\infty}^{+\infty} \left\{ \delta(\omega - \omega_0 - 2\pi l) - \delta(\omega + \omega_0 - 2\pi l) \right\}$           | (a) $\omega_0 = \frac{2\pi r}{N}$ $a_k = \begin{cases} \frac{1}{2j}, & k = r, r \pm N, r \pm 2N, \dots \\ -\frac{1}{2j}, & k = -r, -r \pm N, -r \pm 2N, \dots \\ 0, & \text{otherwise} \end{cases}$ (b) $\frac{\omega_0}{2\pi}$ irrational $\Rightarrow$ The signal is aperiodic |
| x[n] = 1                                                                                                               | $2\pi \sum_{l=-\infty}^{+\infty} \delta(\omega - 2\pi l)$                                                                                     | $a_k = \begin{cases} 1, & k = 0, \pm N, \pm 2N, \dots \\ 0, & \text{otherwise} \end{cases}$                                                                                                                                                                                      |
| Periodic square wave $x[n] = \begin{cases} 1, &  n  \le N_1 \\ 0, & N_1 <  n  \le N/2 \end{cases}$ and $x[n+N] = x[n]$ | $2\pi \sum_{k=-\infty}^{+\infty} a_k \delta\left(\omega - \frac{2\pi k}{N}\right)$                                                            | $a_k = \frac{\sin[(2\pi k/N)(N_1 + \frac{1}{2})]}{N \sin[2\pi k/2N]}, \ k \neq 0, \pm N, \pm 2N, \dots$ $a_k = \frac{2N_1 + 1}{N}, \ k = 0, \pm N, \pm 2N, \dots$                                                                                                                |
| $\sum_{k=-\infty}^{+\infty} \delta[n-kN]$                                                                              | $\frac{2\pi}{N}\sum_{k=-\infty}^{+\infty}\delta\left(\omega-\frac{2\pi k}{N}\right)$                                                          | $a_k = \frac{1}{N}$ for all $k$                                                                                                                                                                                                                                                  |
| $a^n u[n],   a  < 1$                                                                                                   | $\frac{1}{1 - ae^{-j\omega}}$                                                                                                                 | _                                                                                                                                                                                                                                                                                |
| $x[n] \begin{cases} 1, &  n  \le N_1 \\ 0, &  n  > N_1 \end{cases}$                                                    | $\frac{\sin[\omega(N_1+\frac{1}{2})]}{\sin(\omega/2)}$                                                                                        | _                                                                                                                                                                                                                                                                                |
| $\frac{\sin Wn}{\pi n} = \frac{W}{\pi} \operatorname{sinc}\left(\frac{Wn}{\pi}\right)$ $0 < W < \pi$                   | $X(\omega) = \begin{cases} 1, & 0 \le  \omega  \le W \\ 0, & W <  \omega  \le \pi \end{cases}$ $X(\omega) \text{ periodic with period } 2\pi$ | _                                                                                                                                                                                                                                                                                |
| $\delta[n]$                                                                                                            | 1                                                                                                                                             |                                                                                                                                                                                                                                                                                  |
| u[n]                                                                                                                   | $\frac{1}{1-e^{-j\omega}}+\sum_{k=-\infty}^{+\infty}\pi\delta(\omega-2\pi k)$                                                                 | _                                                                                                                                                                                                                                                                                |
| $\delta[n-n_0]$                                                                                                        | $e^{-j\omega n_0}$                                                                                                                            |                                                                                                                                                                                                                                                                                  |
| $(n+1)a^nu[n],   a <1$                                                                                                 | $\frac{1}{(1-ae^{-j\omega})^2}$                                                                                                               | _                                                                                                                                                                                                                                                                                |
| $\frac{(n+r-1)!}{n!(r-1)!}a^nu[n],   a <1$                                                                             | $\frac{1}{(1-ae^{-j\omega})^r}$                                                                                                               | _                                                                                                                                                                                                                                                                                |

Sec. 5.7 Duality **393** 

signal, reversed in time). To see this in more detail, consider two periodic sequences with period *N,* related through the summation

$$f[m] = \frac{1}{N} \sum_{r = \langle N \rangle} g[r] e^{-jr(2\pi/N)m}.$$
 (5.65)

If we let *m* = *k* and *r* = *n,* eq. (5.65) becomes

$$f[k] = \frac{1}{N} \sum_{n = \langle N \rangle} g[n] e^{-jk(2\pi/N)n}.$$

Comparing this with eq. (3.95), we see that the sequence *f[k]* corresponds to the Fourier series coefficients of the signal *g[n].* That is, if we adopt the notation

$$x[n] \stackrel{\mathfrak{F}S}{\longleftrightarrow} a_k$$

introduced in Chapter 3 for a periodic discrete-time signal and its set of Fourier coefficients, the two periodic sequences related through eq. (5.65) satisfy

$$g[n] \stackrel{\mathfrak{F}S}{\longleftrightarrow} f[k].$$
 (5.66)

Alternatively, if we let *m* = nand *r* = - *k,* eq. (5.65) becomes

$$f[n] = \sum_{k=\langle N \rangle} \frac{1}{N} g[-k] e^{jk(2\pi/N)n}.$$

Comparing this with eq. (3.94), we find that (1/N)g[- *k]* corresponds to the sequence of Fourier series coefficients of *f* [ *n].* That is,

$$f[n] \stackrel{\mathfrak{FS}}{\longleftrightarrow} \frac{1}{N}g[-k].$$
 (5.67)

As in continuous time, this duality implies that every property of the discrete-time Fourier series has a dual. For example, referring to Table 3.2, we see that the pair of properties

$$x[n-n_0] \stackrel{\mathfrak{FS}}{\longleftrightarrow} a_k e^{-jk(2\pi/N)n_0} \tag{5.68}$$

and

$$e^{jm(2\pi/N)n}x[n] \stackrel{\mathfrak{FS}}{\longleftrightarrow} a_{k-m} \tag{5.69}$$

are dual. Similarly, from the same table, we can extract another pair of dual properties:

$$\sum_{r=\langle N\rangle} x[r]y[n-r] \stackrel{\mathfrak{FS}}{\longleftrightarrow} Na_k b_k \tag{5.70}$$

and

$$x[n]y[n] \stackrel{\mathfrak{F}S}{\longleftrightarrow} \sum_{l=\langle N \rangle} a_l b_{k-l}. \tag{5.71}$$

In addition to its consequences for the properties of discrete-time Fourier series, duality can often be useful in reducing the complexity of the calculations involved in determining Fourier series representations. This is illustrated in the following example.

#### Example 5.16

Consider the following periodic signal with a period of N = 9:

$$x[n] = \begin{cases} \frac{1}{9} \frac{\sin(5\pi n/9)}{\sin(\pi n/9)}, & n \neq \text{ multiple of } 9\\ \frac{5}{9}, & n = \text{ multiple of } 9 \end{cases}$$
 (5.72)

In Chapter 3, we found that a rectangular square wave has Fourier coefficients in a form much as in eq. (5.72). Duality, then, suggests that the coefficients for x[n] must be in the form of a rectangular square wave. To see this more precisely, let g[n] be a rectangular square wave with period N = 9 such that

$$g[n] = \begin{cases} 1, & |n| \le 2 \\ 0, & 2 < |n| \le 4. \end{cases}$$

The Fourier series coefficients  $b_k$  for g[n] can be determined from Example 3.12 as

$$b_k = \begin{cases} \frac{1}{9} \frac{\sin(5\pi k/9)}{\sin(\pi k/9)}, & k \neq \text{multiple of } 9\\ \frac{5}{9}, & k = \text{multiple of } 9 \end{cases}$$

The Fourier series analysis equation (3.95) for g[n] can now be written as

$$b_k = \frac{1}{9} \sum_{n=-2}^{2} (1) e^{-j2\pi nk/9}.$$

Interchanging the names of the variables k and n and noting that  $x[n] = b_n$ , we find that

$$x[n] = \frac{1}{9} \sum_{k=-2}^{2} (1)e^{-j2\pi nk/9}.$$

Letting k' = -k in the sum on the right side, we obtain

$$x[n] = \frac{1}{9} \sum_{k'=-2}^{2} e^{+j2\pi nk'/9}.$$

Finally, moving the factor 1/9 inside the summation, we see that the right side of this equation has the form of the synthesis equation (3.94) for x[n]. We thus conclude that the Fourier coefficients of x[n] are given by

$$a_k = \begin{cases} 1/9, & |k| \le 2 \\ 0, & 2 < |k| \le 4, \end{cases}$$

and, of course, are periodic with period N = 9.

Sec. 5.7 Duality 395

# 5.7.2 Duality between the Discrete-Time Fourier Transform and the Continuous-Time Fourier Series

In addition to the duality for the discrete Fourier series, there is a duality between the discrete-time Fourier transform and the continuous-time Fourier series. Specifically, let us compare the continuous-time Fourier series equations (3.38) and (3.39) with the discrete-time Fourier transform equations (5.8) and (5.9). We repeat these equations here for convenience:

[eq. (5.8)] 
$$x[n] = \frac{1}{2\pi} \int_{2\pi} X(e^{j\omega}) e^{j\omega n} d\omega, \qquad (5.73)$$

[eq. (5.9)] 
$$X(e^{j\omega}) = \sum_{n=-\infty}^{+\infty} x[n]e^{-j\omega n},$$
 (5.74)

[eq. (3.38)] 
$$x(t) = \sum_{k=-\infty}^{+\infty} a_k e^{jk\omega_0 t}, \qquad (5.75)$$

[eq. (3.39)] 
$$a_k = \frac{1}{T} \int_T x(t)e^{-jk\omega_0 t} dt.$$
 (5.76)

Note that eqs. (5.73) and (5.76) are very similar, as are eqs. (5.74) and (5.75), and in fact, we can interpret eqs. (5.73) and (5.74) as a *Fourier series* representation of the periodic frequency response  $X(e^{j\omega})$ . In particular, since  $X(e^{j\omega})$  is a periodic function of  $\omega$  with period  $2\pi$ , it has a Fourier series representation as a weighted sum of harmonically related periodic exponential functions of  $\omega$ , all of which have the common period of  $2\pi$ . That is,  $X(e^{j\omega})$  can be represented in a Fourier series as a weighted sum of the signals  $e^{j\omega n}$ ,  $n=0,\pm 1,\pm 2,\ldots$  From eq. (5.74), we see that the *n*th Fourier coefficient in this expansion—i.e., the coefficient multiplying  $e^{j\omega n}$ —is x[-n]. Furthermore, since the period of  $X(e^{j\omega})$  is  $2\pi$ , eq. (5.73) can be interpreted as the Fourier series analysis equation for the Fourier series coefficient x[n]—i.e., for the coefficient multiplying  $e^{-j\omega n}$  in the expression for  $X(e^{j\omega})$  in eq. (5.74). The use of this duality relationship is best illustrated with an example.

# Example 5.17

The duality between the discrete-time Fourier transform synthesis equation and the continuous-time Fourier series analysis equation may be exploited to determine the discrete-time Fourier transform of the sequence

$$x[n] = \frac{\sin(\pi n/2)}{\pi n}.$$

To use duality, we first must identify a continuous-time signal g(t) with period  $T=2\pi$  and Fourier coefficients  $a_k=x[k]$ . From Example 3.5, we know that if g(t) is a periodic square wave with period  $2\pi$  (or, equivalently, with fundamental frequency  $\omega_0=1$ ) and with

$$g(t) = \begin{cases} 1, & |t| \leq T_1 \\ 0, & T_1 < |t| \leq \pi \end{cases}$$

then the Fourier series coefficients of g(t) are

$$a_k = \frac{\sin(kT_1)}{k\pi}$$

Consequently, if we take  $T_1 = \pi/2$ , we will have  $a_k = x[k]$ . In this case the analysis equation for g(t) is

$$\frac{\sin(\pi k/2)}{\pi k} = \frac{1}{2\pi} \int_{-\pi/2}^{\pi} g(t)e^{-jkt}dt = \frac{1}{2\pi} \int_{-\pi/2}^{\pi/2} (1)e^{-jkt}dt.$$

Renaming k as n and t as  $\omega$ , we have

$$\frac{\sin(\pi n/2)}{\pi n} = \frac{1}{2\pi} \int_{-\pi/2}^{\pi/2} (1)e^{-jn\omega} d\omega.$$
 (5.77)

Replacing n by -n on both sides of eq. (5.77) and noting that the sinc function is even, we obtain

$$\frac{\sin(\pi n/2)}{\pi n} = \frac{1}{2\pi} \int_{-\pi/2}^{\pi/2} (1)e^{jn\omega} d\omega.$$

The right-hand side of this equation has the form of the Fourier transform synthesis equation for x[n], where

$$X(e^{j\omega}) = \begin{cases} 1 & |\omega| \leq \pi/2 \\ 0 & \pi/2 < |\omega| \leq \pi \end{cases}.$$

In Table 5.3, we present a compact summary of the Fourier series and Fourier transform expressions for both continuous-time and discrete-time signals, and we also indicate the duality relationships that apply in each case.

TABLE 5.3 SUMMARY OF FOURIER SERIES AND TRANSFORM EXPRESSIONS

|                   | Continuous time                                                                   |                                                              | Discrete time                                                    |                                                                      |
|-------------------|-----------------------------------------------------------------------------------|--------------------------------------------------------------|------------------------------------------------------------------|----------------------------------------------------------------------|
|                   | Time domain                                                                       | Frequency domain                                             | Time domain                                                      | Frequency domain                                                     |
| Fourier<br>Series | $x(t) = $ $\sum_{k=-\infty}^{+\infty} a_k e^{jk\omega_0 t}$                       | $a_k = \frac{1}{T_0} \int_{T_0} x(t) e^{-jk\omega_0 t}$      | $x[n] = \sum_{k=\langle N \rangle} a_k e^{jk(2\pi/N)n}$          | $a_k = \frac{1}{N} \sum_{k=\langle N \rangle} x[n] e^{-jk(2\pi/N)n}$ |
|                   | continuous time periodic in time                                                  | discrete frequency aperiodic in frequency                    | discrete time periodic in time                                   | discrete frequency periodic in frequency                             |
| Fourier           | $x(t) = \frac{1}{2\pi} \int_{-\infty}^{+\infty} X(j\omega) e^{j\omega t} d\omega$ | $X(j\omega) = \int_{-\infty}^{+\infty} x(t)e^{-j\omega t}dt$ | $x[n] = \frac{1}{2\pi} \int_{2\pi} X(e^{j\omega}) e^{j\omega n}$ | $X(e^{j\omega)} = \sum_{n=-\infty}^{+\infty} x[n]e^{-j\omega n}$     |
|                   | continuous time aperiodic in time                                                 | continuous frequency aperiodic in frequency                  | discrete time<br>aperiodic in time                               | continuous frequency periodic in frequency                           |

# 5.8 SYSTEMS CHARACTERIZED BY LINEAR CONSTANT-COEFFICIENT DIFFERENCE EQUATIONS

A general linear constant-coefficient difference equation for an LTI system with input x[n] and output y[n] is of the form

$$\sum_{k=0}^{N} a_k y[n-k] = \sum_{k=0}^{M} b_k x[n-k].$$
 (5.78)

The class of systems described by such difference equations is quite an important and useful one. In this section, we take advantage of several of the properties of the discretetime Fourier transform to determine the frequency response *H* ( *ejw)* for an LTI system described by such an equation. The approach we follow closely parallels the discussion in Section 4.7 for continuous-time LTI systems described by linear constant-coefficient differential equations.

There are two related ways in which to determine *H(ejw).* The first of these, which we illustrated in Section 3.11 for several simple difference equations, explicitly uses the fact that complex exponentials are eigenfunctions of LTI systems. Specifically, if *x[n]* = *ejwn* is the input to an LTI system, then the output must be of the form *H(ejw)ejwn.* Substituting these expressions into eq. (5.78) and performing some algebra allows us to solve for *H(ejw).* In this section, we follow a second approach making use of the convolution, linearity, and time-shifting properties of the discrete-time Fourier transform. Let *X* ( *ejw* ), *Y* ( *ejw* ), and *H(ejw)* denote the Fourier transforms of the input *x[n],* output *y[n],* and impulse response *h[n],* respectively. The convolution property, eq. (5.48), of the discrete-time Fourier transform then implies that

$$H(e^{j\omega}) = \frac{Y(e^{j\omega})}{X(e^{j\omega})}. (5.79)$$

Applying the Fourier transform to both sides of eq. (5.78) and using the linearity and time-shifting properties, we obtain the expression

$$\sum_{k=0}^{N} a_k e^{-jk\omega} Y(e^{j\omega}) = \sum_{k=0}^{M} b_k e^{-jk\omega} X(e^{j\omega}),$$

or equivalently,

$$H(e^{j\omega}) = \frac{Y(e^{j\omega})}{X(e^{j\omega})} = \frac{\sum_{k=0}^{M} b_k e^{-jk\omega}}{\sum_{k=0}^{N} a_k e^{-jk\omega}}.$$
 (5.80)

Comparing eq. (5.80) with eq. (4.76), we see that, as in the case of continuous time, *H(ejw)*  is a ratio of polynomials, but in discrete time the polynomials are in the variable *jw.*  The coefficients of the numerator polynomial are the same coefficients as appear on the right side of eq. (5.78), and the coefficients of the denominator polynomial are the same as appear on the left side of that equation. Therefore, the frequency response of the LTI system specified by eq. (5.78) can be written down by inspection.

The difference equation (5.78) is generally referred to as an Nth-order difference equation, as it involves delays in the output *y[n]* of uptoN time steps. Also, the denominator of *H(ejw)* in eq. (5.80) is an Nth-order polynomial in *jw.* 

# **Example 5. 18**

Consider the causal LTI system that is characterized by the difference equation

$$y[n] - ay[n-1] = x[n], (5.81)$$

with *\a\* < 1. From eq. (5.80), the frequency response of this system is

$$H(e^{j\omega}) = \frac{1}{1 - ae^{-j\omega}}. ag{5.82}$$

Comparing this with Example 5.1, we recognize it as the Fourier transform of the sequence *a"u[n].* Thus, the impulse response of the system is

$$h[n] = a^n u[n]. (5.83)$$

# **Example 5. 1 9**

Consider a causal LTI system that is characterized by the difference equation

$$y[n] - \frac{3}{4}y[n-1] + \frac{1}{8}y[n-2] = 2x[n].$$
 (5.84)

From eq. (5.80), the frequency response is

$$H(e^{j\omega}) = \frac{2}{1 - \frac{3}{4}e^{-j\omega} + \frac{1}{8}e^{-j2\omega}}.$$
 (5.85)

As a first step in obtaining the impulse response, we factor the denominator of eq. (5.85):

$$H(e^{j\omega}) = \frac{2}{(1 - \frac{1}{2}e^{-j\omega})(1 - \frac{1}{4}e^{-j\omega})}.$$
 (5.86)

*H(eiw)* can be expanded by the method of partial fractions, as in Example A.3 in the appendix. The result of this expansion is

$$H(e^{j\omega}) = \frac{4}{1 - \frac{1}{2}e^{-j\omega}} - \frac{2}{1 - \frac{1}{4}e^{-j\omega}}.$$
 (5.87)

The inverse transform of each term can be recognized by inspection, with the result that

$$h[n] = 4\left(\frac{1}{2}\right)^n u[n] - 2\left(\frac{1}{4}\right)^n u[n]. \tag{5.88}$$

The procedure followed in Example 5.19 is identical in style to that used in continuous time. Specifically, after expanding *H(e.iw)* by the method of partial fractions, we can find the inverse transform of each term by inspection. The same approach can be applied to the frequency response of any LTI system described by a linear constant-coefficient difference equation in order to determine the system impulse response. Also, as illustrated in the next example, if the Fourier transform X ( *e.iw)* of the input to such a system is a ratio of polynomials in *e-.iw,* then *Y(e.iw)* is as well. In this case, we can use the same technique to find the response *y[n]* to the input *x[n].* 

# **Example 5.20**

Consider the LTI system of Example 5.19, and let the input to this system be

$$x[n] = \left(\frac{1}{4}\right)^n u[n].$$

Then, using eq. (5.80) and Example 5.1 or 5.18, we obtain

$$Y(e^{j\omega}) = H(e^{j\omega})X(e^{j\omega}) = \left[\frac{2}{(1 - \frac{1}{2}e^{-j\omega})(1 - \frac{1}{4}e^{-j\omega})}\right] \left[\frac{1}{1 - \frac{1}{4}e^{-j\omega}}\right]$$

$$= \frac{2}{(1 - \frac{1}{2}e^{-j\omega})(1 - \frac{1}{4}e^{-e\omega})^{2}}.$$
(5.89)

As described in the appendix, the form of the partial-fraction expansion in this case is

$$Y(e^{j\omega}) = \frac{B_{11}}{1 - \frac{1}{4}e^{-j\omega}} + \frac{B_{12}}{(1 - \frac{1}{4}e^{-j\omega})^2} + \frac{B_{21}}{1 - \frac{1}{2}e^{-j\omega}},$$
 (5.90)

where the constants Btt. B12, and B21 can be determined using the techniques described in the appendix. This particular expansion is worked out in detail in Example A.4, and the values obtained are

$$B_{11} = -4$$
,  $B_{12} = -2$ ,  $B_{21} = 8$ ,

so that

$$Y(e^{j\omega}) = -\frac{4}{1 - \frac{1}{4}e^{-j\omega}} - \frac{2}{(1 - \frac{1}{4}e^{-j\omega})^2} + \frac{8}{1 - \frac{1}{2}e^{-j\omega}}.$$
 (5.91)

The first and third terms are of the same type as those encountered in Example 5.19, while the second term is of the same form as one seen in Example 5.13. Either from these examples or from Table 5.2, we can invert each of the terms in eq. (5.91) to obtain the inverse transform

$$y[n] = \left\{ -4\left(\frac{1}{4}\right)^n - 2(n+1)\left(\frac{1}{4}\right)^n + 8\left(\frac{1}{2}\right)^n \right\} u[n]. \tag{5.92}$$

# **5.9 SUMMARY**

In this chapter, we have paralleled Chapter 4 as we developed the Fourier transform for discrete-time signals and examined many of its important properties. Throughout the chapter, we have seen a great many similarities between continuous-time and discrete-time Fourier analysis, and we have also seen some important differences. For example, the relationship between Fourier series and Fourier transforms in discrete time is exactly analogous to that in continuous time. In particular, our derivation of the discrete-time Fourier transform for aperiodic signals from the discrete-time Fourier series representations is very much the same as the corresponding continuous-time derivation. Furthermore, many of the properties of continuous-time transforms have exact discrete-time counterparts. On the other hand, in contrast to the continuous-time case, the discrete-time Fourier transform of an aperiodic signal is always periodic with period 27T. In addition to similarities and differences such as these, we have described the duality relationships among the Fourier representations of continuous-time and discrete-time signals.

The most important similiarities between continuous- and discrete-time Fourier analysis are in their uses in analyzing and representing signals and LTI systems. Specifically, the convolution property provides us with the basis for the frequency-domain analysis of LTI systems. We have already seen some of the utility of this approach in our discussion of filtering in Chapters 3–5 and in our examination of systems described by linear constantcoefficient differential or difference equations, and we will gain a further appreciation for its utility in Chapter 6, in which we examine filtering and time-versus-frequency issues in more detail. In addition, the multiplication properties in continuous and discrete time are essential to our development of sampling in Chapter 7 and communications in Chapter 8.

# Chapter 5 Problems

The first section of problems belongs to the basic category and the answers are provided in the back of the book. The remaining three sections contain problems belonging to the basic, advanced, and extension categories, respectively.

#### BASIC PROBLEMS WITH ANSWERS

**5.1.** Use the Fourier transform analysis equation (5.9) to calculate the Fourier transforms

**(a)** 
$$(\frac{1}{2})^{n-1}u[n-1]$$
 **(b)**  $(\frac{1}{2})^{|n-1|}$ 

Sketch and label one period of the magnitude of each Fourier transform.

**5.2.** Use the Fourier transform analysis equation (5.9) to calculate the Fourier transforms

(a) 
$$\delta[n-1] + \delta[n+1]$$
 (b)  $\delta[n+2] - \delta[n-2]$ 

Sketch and label one period of the magnitude of each Fourier transform.

**5.3.** Determine the Fourier transform for  $-\pi \le \omega < \pi$  in the case of each of the following periodic signals:

(a) 
$$\sin(\frac{\pi}{3}n + \frac{\pi}{4})$$
 (b)  $2 + \cos(\frac{\pi}{6}n + \frac{\pi}{8})$ 

**5.4.** Use the Fourier transform synthesis equation (5.8) to determine the inverse Fourier transforms of:

(a) 
$$X_1(e^{j\omega}) = \sum_{k=-\infty}^{\infty} \{2\pi\delta(\omega - 2\pi k) + \pi\delta(\omega - \frac{\pi}{2} - 2\pi k) + \pi\delta(\omega + \frac{\pi}{2} - 2\pi k)\}$$
  
(b)  $X_2(e^{j\omega}) = \begin{cases} 2j, & 0 < \omega \leq \pi \\ -2j, & -\pi < \omega \leq 0 \end{cases}$ 

**(b)** 
$$X_2(e^{j\omega}) = \begin{cases} 2j, & 0 < \omega \le \pi \\ -2j, & -\pi < \omega \le 0 \end{cases}$$

**5.5.** Use the Fourier transform synthesis equation (5.8) to determine the inverse Fourier transform of  $X(e^{j\omega}) = |X(e^{j\omega})|e^{j \notin X(e^{j\omega})}$ , where

$$|X(e^{j\omega})| = \begin{cases} 1, & 0 \le |\omega| < \frac{\pi}{4} \\ 0, & \frac{\pi}{4} \le |\omega| \le \pi \end{cases} \text{ and } \langle X(e^{j\omega}) = -\frac{3\omega}{2}.$$

Use your answer to determine the values of n for which x[n] = 0.

**5.6.** Given that x[n] has Fourier transform  $X(e^{j\omega})$ , express the Fourier transforms of the following signals in terms of  $X(e^{j\omega})$ . You may use the Fourier transform properties listed in Table 5.1.

(a) 
$$x_1[n] = x[1-n] + x[-1-n]$$
  
(b)  $x_2[n] = \frac{x^*[-n] + x[n]}{2}$ 

**(b)** 
$$x_2[n] = \frac{x^*[-n] + x[n]}{2}$$

(c) 
$$x_3[n] = (n-1)^2 x[n]$$

Chap. 5 Problems 401

**5.7.** For each of the following Fourier transforms, use Fourier transform properties (Table 5.1) to determine whether the corresponding time-domain signal is (i) real, imaginary, or neither and (ii) even, odd, or neither. Do this without evaluating the inverse of any of the given transforms.

- (a)  $X_1(e^{j\omega}) = e^{-j\omega} \sum_{k=1}^{10} (\sin k\omega)$
- **(b)**  $X_2(e^{j\omega}) = j\sin(\omega)\cos(5\omega)$
- (c)  $X_3(e^{j\omega}) = A(\omega) + e^{jB(\omega)}$  where

$$A(\omega) = \begin{cases} 1, & 0 \le |\omega| \le \frac{\pi}{8} \\ 0, & \frac{\pi}{8} < |\omega| \le \pi \end{cases} \text{ and } B(\omega) = -\frac{3\omega}{2} + \pi.$$

**5.8.** Use Tables 5.1 and 5.2 to help determine x[n] when its Fourier transform is

$$X(e^{j\omega}) = \frac{1}{1 - e^{-j\omega}} \left( \frac{\sin \frac{3}{2}\omega}{\sin \frac{\omega}{2}} \right) + 5\pi\delta(\omega), \quad -\pi < \omega \leq \pi$$

- **5.9.** The following four facts are given about a real signal x[n] with Fourier transform  $X(e^{jw})$ :
  - **1.** x[n] = 0 for n > 0.
  - **2.** x[0] > 0.

  - 3.  $\mathfrak{Gm}\{X(e^{j\omega})\}=\sin\omega-\sin2\omega$ . 4.  $\frac{1}{2\pi}\int_{-\pi}^{\pi}|X(e^{j\omega})|^2d\omega=3$ .

Determine x[n].

**5.10.** Use Tables 5.1 and 5.2 in conjunction with the fact that

$$\dot{X}(e^{j0}) = \sum_{n=-\infty}^{\infty} x[n]$$

to determine the numerical value of

$$A = \sum_{n=0}^{\infty} n \left(\frac{1}{2}\right)^n.$$

**5.11.** Consider a signal g[n] with Fourier transform  $G(e^{j\omega})$ . Suppose

$$g[n] = x_{(2)}[n],$$

where the signal x[n] has a Fourier transform  $X(e^{j\omega})$ . Determine a real number  $\alpha$ such that  $0 < \alpha < 2\pi$  and  $G(e^{j\omega}) = G(e^{j(\omega - \alpha)})$ .

**5.12.** Let

$$y[n] = \left(\frac{\sin\frac{\pi}{4}n}{\pi n}\right)^2 * \left(\frac{\sin\omega_c n}{\pi n}\right),$$

where \* denotes convolution and  $|\omega_c| \leq \pi$ . Determine a stricter constraint on  $\omega_c$ 

which ensures that

$$y[n] = \left(\frac{\sin\frac{\pi}{4}n}{\pi n}\right)^2.$$

**5.13.** An LTI system with impulse response  $h_1[n] = (\frac{1}{3})^n u[n]$  is connected in parallel with another causal LTI system with impulse response  $h_2[n]$ . The resulting parallel interconnection has the frequency response

$$H(e^{j\omega}) = \frac{-12 + 5e^{-j\omega}}{12 - 7e^{-j\omega} + e^{-j2\omega}}.$$

Determine  $h_2[n]$ .

- **5.14.** Suppose we are given the following facts about an LTI system S with impulse response h[n] and frequency response  $H(e^{j\omega})$ :
  - 1.  $(\frac{1}{4})^n u[n] \longrightarrow g[n]$ , where g[n] = 0 for  $n \ge 2$  and n < 0.
  - **2.**  $H(e^{j\pi/2}) = 1$ .
  - 3.  $H(e^{j\omega}) = H(e^{j(\omega-\pi)}).$

Determine h[n].

**5.15.** Let the inverse Fourier transform of  $Y(e^{j\omega})$  be

$$y[n] = \left(\frac{\sin \omega_c n}{\pi n}\right)^2,$$

where  $0 < \omega_c < \pi$ . Determine the value of  $\omega_c$  which ensures that

$$Y(e^{j\pi})=\frac{1}{2}.$$

**5.16.** The Fourier transform of a particular signal is

$$X(e^{j\omega}) = \sum_{k=0}^{3} \frac{(1/2)^k}{1 - \frac{1}{4}e^{-j(\omega - \pi/2k)}}.$$

It can be shown that

$$x[n] = g[n]q[n],$$

where g[n] is of the form  $\alpha^n u[n]$  and q[n] is a periodic signal with period N.

- (a) Determine the value of  $\alpha$ .
- (b) Determine the value of N.
- (c) Is x[n] real?
- **5.17.** The signal  $x[n] = (-1)^n$  has a fundamental period of 2 and corresponding Fourier series coefficients  $a_k$ . Use duality to determine the Fourier series coefficients  $b_k$  of the signal  $g[n] = a_n$  with a fundamental period of 2.
- 5.18. Given the fact that

$$a^{|n|} \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1-a^2}{1-2a\cos\omega+a^2}, |a|<1,$$

Chap. 5 Problems 403

use duality to determine the Fourier series coefficients of the following continuoustime signal with period T = 1:

$$x(t) = \frac{1}{5 - 4\cos(2\pi t)}.$$

**5.19.** Consider a causal and stable LTI system S whose input x[n] and output y[n] are related through the second-order difference equation

$$y[n] - \frac{1}{6}y[n-1] - \frac{1}{6}y[n-2] = x[n].$$

- (a) Determine the frequency response  $H(e^{j\omega})$  for the system S.
- (b) Determine the impulse response h[n] for the system S.
- **5.20.** A causal and stable LTI system S has the property that

$$\left(\frac{4}{5}\right)^n u[n] \longrightarrow n\left(\frac{4}{5}\right)^n u[n].$$

- (a) Determine the frequency response  $H(e^{j\omega})$  for the system S.
- (b) Determine a difference equation relating any input x[n] and the corresponding output y[n].

#### BASIC PROBLEMS

**5.21.** Compute the Fourier transform of each of the following signals:

(a) 
$$x[n] = u[n-2] - u[n-6]$$

**(b)** 
$$x[n] = (\frac{1}{2})^{-n}u[-n-1]$$

(c) 
$$x[n] = (\frac{1}{3})^{|n|}u[-n-2]$$

(d) 
$$x[n] = 2^n \sin(\frac{\pi}{4}n)u[-n]$$

(e) 
$$x[n] = (\frac{1}{2})^{|n|} \cos(\frac{\pi}{8}(n-1))$$

(e) 
$$x[n] = (\frac{1}{2})^{|n|} \cos(\frac{\pi}{8}(n-1))$$
  
(f)  $x[n] = \begin{cases} n, & -3 \le n \le 3\\ 0, & \text{otherwise} \end{cases}$ 

(g) 
$$x[n] = \sin(\frac{\pi}{2}n) + \cos(n)$$

**(h)** 
$$x[n] = \sin(\frac{5\pi}{3}n) + \cos(\frac{7\pi}{3}n)$$

(a) 
$$x[n] = \sin(\frac{2}{3}n) + \cos(n)$$
  
(b)  $x[n] = \sin(\frac{5\pi}{3}n) + \cos(\frac{7\pi}{3}n)$   
(i)  $x[n] = x[n-6]$ , and  $x[n] = u[n] - u[n-5]$  for  $0 \le n \le 5$   
(j)  $x[n] = (n-1)(\frac{1}{3})^{|n|}$ 

(j) 
$$x[n] = (n-1)(\frac{1}{3})^{|n|}$$

(k) 
$$x[n] = \left(\frac{\sin(\pi n/5)}{\pi n}\right)\cos(\frac{7\pi}{2}n)$$

**5.22.** The following are the Fourier transforms of discrete-time signals. Determine the signal corresponding to each transform.

(a) 
$$X(e^{j\omega}) = \begin{cases} 1, & \frac{\pi}{4} \le |\omega| \le \frac{3\pi}{4} \\ 0, & \frac{3\pi}{4} \le |\omega| \le \pi, 0 \le |\omega| < \frac{\pi}{4} \end{cases}$$
  
(b)  $X(e^{j\omega}) = 1 + 3e^{-j\omega} + 2e^{-j2\omega} - 4e^{-j3\omega} + e^{-j10\omega}$ 

**(b)** 
$$X(e^{j\omega}) = 1 + 3e^{-j\omega} + 2e^{-j2\omega} - 4e^{-j3\omega} + e^{-j10\omega}$$

(c) 
$$X(e^{j\omega}) = e^{-j\omega/2}$$
 for  $-\pi \le \omega \le \pi$ 

(d) 
$$X(e^{j\omega}) = \cos^2 \omega + \sin^2 3\omega$$

(e) 
$$X(e^{j\omega}) = \sum_{k=-\infty}^{\infty} (-1)^k \delta(\omega - \frac{\pi}{2}k)$$

(f) 
$$X(e^{j\omega}) = \frac{e^{-j\omega} - \frac{1}{5}}{1 - \frac{1}{5}e^{-j\omega}}$$

(g) 
$$X(e^{j\omega}) = \frac{1-\frac{1}{3}e^{-j\omega}}{1-\frac{1}{4}e^{-j\omega}-\frac{1}{8}e^{-2j\omega}}$$

**(h)** 
$$X(e^{j\omega}) = \frac{1-(\frac{1}{3})^6 e^{-j6\omega}}{1-\frac{1}{3}e^{-j\omega}}$$

- **5.23.** Let  $X(e^{j\omega})$  denote the Fourier transform of the signal x[n] depicted in Figure P5.23. Perform the following calculations without explicitly evaluating  $X(e^{j\omega})$ :
  - (a) Evaluate  $X(e^{j0})$ .
  - **(b)** Find  $\angle X(e^{j\omega})$ .
  - (c) Evaluate  $\int_{-\pi}^{\pi} X(e^{j\omega}) d\omega$ .
  - (d) Find  $X(e^{j\pi})$ .
  - (e) Determine and sketch the signal whose Fourier transform is  $\Re e\{x(\omega)\}$ .
  - (f) Evaluate:

(i) 
$$\int_{-\pi}^{\pi} |X(e^{j\omega})|^2 d\omega$$

(ii) 
$$\int_{-\pi}^{\pi} \left| \frac{dX(e^{j\omega})}{d\omega} \right|^2 d\omega$$

![](_page_46_Figure_16.jpeg)

Fig P5.23

- **5.24.** Determine which, if any, of the following signals have Fourier transforms that satisfy each of the following conditions:
  - 1.  $\Re\{X(e^{j\omega})\}=0$ .
  - **2.**  $\mathfrak{Im}\{X(e^{j\omega})\}=0.$
  - **3.** There exists a real  $\alpha$  such that  $e^{j\alpha\omega}X(e^{j\omega})$  is real.
  - $4. \int_{-\pi}^{\pi} X(e^{j\omega})d\omega = 0.$
  - 5.  $X(e^{j\omega})$  periodic.
  - **6.**  $X(e^{j0}) = 0$ .
  - (a) x[n] as in Figure P5.24(a)
  - (b) x[n] as in Figure P5.24(b)
  - (c)  $x[n] = (\frac{1}{2})^n u[n]$
  - **(d)**  $x[n] = (\frac{1}{2})^{|n|}$
  - (e)  $x[n] = \delta[n-1] + \delta[n+2]$
  - **(f)**  $x[n] = \delta[n-1] + \delta[n+3]$
  - (g) x[n] as in Figure P5.24(c)
  - (h) x[n] as in Figure P5.24(d)
  - (i)  $x[n] = \delta[n-1] \delta[n+1]$

Chap. 5 Problems 405

![](_page_47_Figure_1.jpeg)

![](_page_47_Figure_2.jpeg)

Fig P5.24

**5.25.** Consider the signal depicted in Figure P5.25. Let the Fourier transform of this signal be written in rectangular form as

(d)

$$X(e^{j\omega}) = A(\omega) + jB(\omega).$$

Sketch the function of time corresponding to the transform

$$Y(e^{j\omega}) = [B(\omega) + A(\omega)e^{j\omega}].$$

![](_page_48_Figure_3.jpeg)

Fig P5.25

- **5.26.** Let  $x_1[n]$  be the discrete-time signal whose Fourier transform  $X_1(e^{j\omega})$  is depicted in Figure P5.26(a).
  - (a) Consider the signal  $x_2[n]$  with Fourier transform  $X_2(e^{j\omega})$ , as illustrated in Figure P5.26(b). Express  $x_2[n]$  in terms of  $x_1[n]$ . [Hint: First express  $X_2(e^{j\omega})$  in terms of  $X_1(e^{j\omega})$ , and then use properties of the Fourier transform.]
  - (b) Repeat part (a) for  $x_3[n]$  with Fourier transform  $X_3(e^{j\omega})$ , as shown in Figure P5.26(c).
  - (c) Let

$$\alpha = \frac{\sum_{n=-\infty}^{\infty} n x_1[n]}{\sum_{n=-\infty}^{\infty} x_1[n]}.$$

This quantity, which is the center of gravity of the signal  $x_1[n]$ , is usually referred to as the *delay time* of  $x_1[n]$ . Find  $\alpha$ . (You can do this without first determining  $x_1[n]$  explicitly.)

![](_page_48_Figure_11.jpeg)

![](_page_48_Figure_12.jpeg)

(a)

Fiq P5.26a

Chap. 5 Problems 407

![](_page_49_Figure_1.jpeg)

![](_page_49_Figure_2.jpeg)

Fig P5.26b,c

(d) Consider the signal  $x_4[n] = x_1[n] * h[n]$ , where

$$h[n] = \frac{\sin(\pi n/6)}{\pi n}.$$

Sketch  $X_4(e^{j\omega})$ .

**5.27.** (a) Let x[n] be a discrete-time signal with Fourier transform  $X(e^{j\omega})$ , which is illustrated in Figure P5.27. Sketch the Fourier transform of

$$w[n] = x[n]p[n]$$

for each of the following signals p[n]:

- (i)  $p[n] = \cos \pi n$
- (ii)  $p[n] = \cos(\pi n/2)$
- (iii)  $p[n] = \sin(\pi n/2)$

(iv) 
$$p[n] = \sum_{k=-\infty}^{\infty} \delta[n-2k]$$

(v) 
$$p[n] = \sum_{k=-\infty}^{\infty} \delta[n-4k]$$

![](_page_49_Figure_15.jpeg)

Fig P5.27

(b) Suppose that the signal w[n] of part (a) is applied as the input to an LTI system with unit sample response

$$h[n] = \frac{\sin(\pi n/2)}{\pi n}.$$

Determine the output y[n] for each of the choices of p[n] in part (a).

**5.28.** The signals x[n] and g[n] are known to have Fourier transforms  $X(e^{j\omega})$  and  $G(e^{j\omega})$ , respectively. Furthermore,  $X(e^{j\omega})$  and  $G(e^{j\omega})$  are related as follows:

$$\frac{1}{2\pi} \int_{-\pi}^{+\pi} X(e^{j\theta}) G(e^{j(\omega-\theta)}) d\theta = 1 + e^{-j\omega}$$
 (P5.28–1)

- (a) If  $x[n] = (-1)^n$ , determine a sequence g[n] such that its Fourier transform  $G(e^{j\omega})$  satisfies eq. (P5.28–1). Are there other possible solutions for g[n]?
- **(b)** Repeat the previous part for  $x[n] = (\frac{1}{2})^n u[n]$ .
- **5.29.** (a) Consider a discrete-time LTI system with impulse response

$$h[n] = \left(\frac{1}{2}\right)^n u[n].$$

Use Fourier transforms to determine the response to each of the following input signals:

- (i)  $x[n] = (\frac{3}{4})^n u[n]$
- (ii)  $x[n] = (n+1)(\frac{1}{4})^n u[n]$
- **(iii)**  $x[n] = (-1)^n$
- (b) Suppose that

$$h[n] = \left\lceil \left(\frac{1}{2}\right)^n \cos\left(\frac{\pi n}{2}\right) \right\rceil u[n].$$

Use Fourier transforms to determine the response to each of the following inputs:

- (i)  $x[n] = (\frac{1}{2})^n u[n]$
- (ii)  $x[n] = \cos(\pi n/2)$
- (c) Let x[n] and h[n] be signals with the following Fourier transforms:

$$X(e^{j\omega}) = 3e^{j\omega} + 1 - e^{-j\omega} + 2e^{-j3\omega}$$
  

$$H(e^{j\omega}) = -e^{j\omega} + 2e^{-2j\omega} + e^{j4\omega}.$$

Determine y[n] = x[n] \* h[n].

**5.30.** In Chapter 4, we indicated that the continuous-time LTI system with impulse response

$$h(t) = \frac{W}{\pi} \operatorname{sinc}\left(\frac{Wt}{\pi}\right) = \frac{\sin Wt}{\pi t}$$

plays a very important role in LTI system analysis. The same is true of the discretetime LTI system with impulse response

$$h[n] = \frac{W}{\pi} \operatorname{sinc}\left(\frac{Wn}{\pi}\right) = \frac{\sin Wn}{\pi n}.$$

Chap. 5 Problems 409

(a) Determine and sketch the frequency response for the system with impulse response h[n].

(b) Consider the signal

$$x[n] = \sin\left(\frac{\pi n}{8}\right) - 2\cos\left(\frac{\pi n}{4}\right).$$

Suppose that this signal is the input to LTI systems with the following impulse responses. Determine the output in each case.

- (i)  $h[n] = \frac{\sin(\pi n/6)}{\pi n}$
- (ii)  $h[n] = \frac{\sin(\pi n/6)}{\pi n} + \frac{\sin(\pi n/2)}{\pi n}$ (iii)  $h[n] = \frac{\sin(\pi n/6)\sin(\pi n/3)}{\pi^2 n^2}$ (iv)  $h[n] = \frac{\sin(\pi n/6)\sin(\pi n/3)}{\pi n}$

- (c) Consider an LTI system with unit sample response

$$h[n] = \frac{\sin(\pi n/3)}{\pi n}.$$

Determine the output for each of the following inputs:

- x[n] = the square wave depicted in Figure P5.30
- (ii)  $x[n] = \sum_{k=-\infty}^{\infty} \delta[n-8k]$
- (iii)  $x[n] = (-1)^n$  times the square wave depicted in Figure P5.30
- (iv)  $x[n] = \delta[n+1] + \delta[n-1]$

![](_page_51_Figure_16.jpeg)

Fiq P5.30

**5.31.** An LTI system S with impulse response h[n] and frequency response  $H(e^{j\omega})$  is known to have the property that, when  $-\pi \le \omega_0 \le \pi$ ,

$$\cos \omega_0 n \longrightarrow \omega_0 \cos \omega_0 n$$
.

- (a) Determine  $H(e^{j\omega})$ .
- **(b)** Determine h[n].
- **5.32.** Let  $h_1[n]$  and  $h_2[n]$  be the impulse responses of causal LTI systems, and let  $H_1(e^{j\omega})$ and  $H_2(e^{j\omega})$  be the corresponding frequency responses. Under these conditions, is the following equation true in general or not? Justify your answer.

$$\left[\frac{1}{2\pi}\int_{-\pi}^{\pi}H_1(e^{j\omega})d\omega\right]\left[\frac{1}{2\pi}\int_{-\pi}^{\pi}H_2(e^{j\omega})d\omega\right] = \frac{1}{2\pi}\int_{-\pi}^{\pi}H_1(e^{j\omega})H_2(e^{j\omega})d\omega.$$

**5.33.** Consider a causal LTI system described by the difference equation

$$y[n] + \frac{1}{2}y[n-1] = x[n].$$

- (a) Determine the frequency response  $H(e^{j\omega})$  of this system.
- (b) What is the response of the system to the following inputs?

(i) 
$$x[n] = (\frac{1}{2})^n u[n]$$

(ii) 
$$x[n] = (-\frac{1}{2})^n u[n]$$

(iii) 
$$x[n] = \delta[n] + \frac{1}{2}\delta[n-1]$$

(iv) 
$$x[n] = \delta[n] - \frac{1}{2}\delta[n-1]$$

(c) Find the response to the inputs with the following Fourier transforms:

(i) 
$$X(e^{j\omega}) = \frac{1-\frac{1}{4}e^{-j\omega}}{1+\frac{1}{2}e^{-j\omega}}$$

(ii) 
$$X(e^{j\omega}) = \frac{1+\frac{1}{2}e^{-j\omega}}{1-\frac{1}{4}e^{-j\omega}}$$

(ii) 
$$X(e^{j\omega}) = \frac{1 + \frac{1}{2}e^{-j\omega}}{1 - \frac{1}{4}e^{-j\omega}}$$
  
(iii)  $X(e^{j\omega}) = \frac{1}{(1 - \frac{1}{4}e^{-j\omega})(1 + \frac{1}{2}e^{-j\omega})}$ 

(iv) 
$$X(e^{j\omega}) = 1 + 2e^{-3j\omega}$$

**5.34.** Consider a system consisting of the cascade of two LTI systems with frequency responses

$$H_1(e^{j\omega}) = \frac{2 - e^{-j\omega}}{1 + \frac{1}{2}e^{-j\omega}}$$

and

$$H_2(e^{j\omega}) = \frac{1}{1 - \frac{1}{2}e^{-j\omega} + \frac{1}{4}e^{-j2\omega}}.$$

- (a) Find the difference equation describing the overall system.
- **(b)** Determine the impulse response of the overall system.
- **5.35.** A causal LTI system is described by the difference equation

$$v[n] - av[n-1] = bx[n] + x[n-1].$$

where a is real and less than 1 in magnitude.

(a) Find a value of b such that the frequency response of the system satisfies

$$|H(e^{j\omega})| = 1$$
, for all  $\omega$ .

This kind of system is called an *all-pass system*, as it does not attenuate the input  $e^{j\omega n}$  for any value of  $\omega$ . Use the value of b that you have found in the rest of the problem.

- **(b)** Roughly sketch  $\langle H(e^{j\omega}), 0 \leq \omega \leq \pi$ , when  $a = \frac{1}{2}$ .
- (c) Roughly sketch  $\langle H(e^{j\omega}), 0 \leq \omega \leq \pi$ , when  $a = -\frac{1}{2}$ .

Chap. 5 Problems 411

(d) Find and plot the output of this system with  $a = -\frac{1}{2}$  when the input is

$$x[n] = \left(\frac{1}{2}\right)^n u[n].$$

From this example, we see that a nonlinear change in phase can have a significantly different effect on a signal than the time shift that results from a linear phase.

- **5.36.** (a) Let h[n] and g[n] be the impulse responses of two stable discrete-time LTI systems that are inverses of each other. What is the relationship between the frequency responses of these two systems?
  - (b) Consider causal LTI systems described by the following difference equations. In each case, determine the impulse response of the inverse system and the difference equation that characterizes the inverse.
    - (i)  $y[n] = x[n] \frac{1}{4}x[n-1]$
    - (ii)  $y[n] + \frac{1}{2}y[n-1] = x[n]$
    - (iii)  $y[n] + \frac{1}{2}y[n-1] = x[n] \frac{1}{4}x[n-1]$

(iv) 
$$y[n] + \frac{5}{4}y[n-1] - \frac{1}{8}y[n-2] = x[n] - \frac{1}{4}x[n-1] - \frac{1}{8}x[n-2]$$
  
(v)  $y[n] + \frac{5}{4}y[n-1] - \frac{1}{8}y[n-2] = x[n] - \frac{1}{2}x[n-1]$ 

(v) 
$$y[n] + \frac{5}{4}y[n-1] - \frac{1}{8}y[n-2] = x[n] - \frac{1}{2}x[n-1]$$

- (vi)  $y[n] + \frac{5}{4}y[n-1] \frac{1}{8}y[n-2] = x[n]$
- (c) Consider the causal, discrete-time LTI system described by the difference equation

$$y[n] + y[n-1] + \frac{1}{4}y[n-2] = x[n-1] - \frac{1}{2}x[n-2].$$
 (P5.36–1)

What is the inverse of this system? Show that the inverse is not causal. Find another causal LTI system that is an "inverse with delay" of the system described by eq. (P5.36-1). Specifically, find a causal LTI system such that the output w[n] in Figure P5.36 equals x[n-1].

![](_page_53_Figure_15.jpeg)

Fig P5.36

#### ADVANCED PROBLEMS

- **5.37.** Let  $X(e^{j\omega})$  be the Fourier transform of x[n]. Derive expressions in terms of  $X(e^{j\omega})$ for the Fourier transforms of the following signals. (Do not assume that x[n] is real.)
  - (a)  $\Re\{x[n]\}$
  - **(b)**  $x^*[-n]$
  - (c)  $\mathcal{E}_{\nu}\{x[n]\}$

**5.38.** Let  $X(e^{j\omega})$  be the Fourier transform of a real signal x[n]. Show that x[n] can be written as

$$x[n] = \int_0^{\pi} \{B(\omega)\cos\omega + C(\omega)\sin\omega\} d\omega$$

by finding expressions for  $B(\omega)$  and  $C(\omega)$  in terms of  $X(e^{j\omega})$ .

**5.39.** Derive the convolution property

$$x[n] * h[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} X(e^{j\omega})H(e^{j\omega}).$$

**5.40.** Let x[n] and h[n] be two signals, and let y[n] = x[n] \* h[n]. Write two expressions for y[0], one (using the convolution sum directly) in terms of x[n] and h[n], and one (using the convolution property of Fourier transforms) in terms of  $X(e^{j\omega})$  and  $H(e^{j\omega})$ . Then, by a judicious choice of h[n], use these two expressions to derive Parseval's relation—that is,

$$\sum_{n=-\infty}^{+\infty}|x[n]|^2=\frac{1}{2\pi}\int_{-\pi}^{\pi}|X(e^{j\omega})|^2d\omega.$$

In a similar fashion, derive the following generalization of Parseval's relation:

$$\sum_{n-\infty}^{+\infty} x[n]z^*[n] = \frac{1}{2\pi} \int_{-\pi}^{\pi} X(e^{j\omega})Z^*(e^{j\omega})d\omega.$$

**5.41** Let  $\tilde{x}[n]$  be a periodic signal with period N. A finite-duration signal x[n] is related to  $\tilde{x}[n]$  through

$$x[n] = \begin{cases} \tilde{x}[n], & n_0 \le n \le n_0 + N - 1 \\ 0, & \text{otherwise} \end{cases},$$

for some integer  $n_0$ . That is, x[n] is equal to  $\tilde{x}[n]$  over one period and zero elsewhere.

(a) If  $\tilde{x}[n]$  has Fourier series coefficients  $a_k$  and x[n] has Fourier transform  $X(e^{j\omega})$ , show that

$$a_k = \frac{1}{N} X(e^{j2\pi k/N})$$

regardless of the value of  $n_0$ .

(b) Consider the following two signals:

$$x[n] = u[n] - u[n - 5]$$

$$\tilde{x}[n] = \sum_{k=-\infty}^{\infty} x[n - kN]$$

where N is a positive integer. Let  $a_k$  denote the Fourier coefficients of  $\tilde{x}[n]$  and let  $X(e^{j\omega})$  denote the Fourier transform of x[n].

(i) Determine a closed-form expression for  $X(e^{j\omega})$ .

Chap. 5 Problems **413** 

- **(ii)** Using the result of part (i), determine an expression for the Fourier coefficients *ak.*
- **5.42.** In this problem, we derive the frequency-shift property of the discrete-time Fourier transform as a special case of the multiplication property. Let *x[n]* be any discretetime signal with Fourier transform *X(eiw),* and let

$$g[n] = e^{j\omega_0 n} x[n].$$

(a) Determine and sketch the Fourier transform of

$$p[n] = e^{j\omega_0 n}$$
.

**(b)** The multiplication property of the Fourier transform tells us that, since

$$g[n] = p[n]x[n],$$

$$G(e^{j\omega}) = \frac{1}{2\pi} \int_{\langle 2\pi \rangle} X(e^{j\theta}) P(e^{j(\omega-\theta)}) d\theta.$$

Evaluate this integral to show that

$$G(e^{j\omega}) = X(e^{j(\omega-\omega_0)}).$$

**5.43.** Let *x[n]* be a signal with Fourier transform *X(eiw),* and let

$$g[n] = x[2n]$$

be a signal whose Fourier transform is *G(eiw).* In this problem, we derive the relationship between *G(eiw)* and *X(eiw).* 

(a) Let

$$v[n] = \frac{(e^{-j\pi n}x[n]) + x[n]}{2}.$$

Express the Fourier transform *V(eiw)* of *v[n]* in terms of *X(eiw).* 

- **(b)** Noting that *v[n]* = 0 for *n* odd, show that the Fourier transform of *v[2n]* is equal to
- (c) Show that

$$x[2n] = v[2n].$$

It follows that

$$G(e^{j\omega}) = V(e^{j\omega/2}).$$

Now use the result of part (a) to express *G(eiw)* in terms of *X(eiw).* 

**5.44.** (a) Let

$$x_1[n] = \cos\left(\frac{\pi n}{3}\right) + \sin\left(\frac{\pi n}{2}\right)$$

be a signal, and let  $X_1(e^{j\omega})$  denote the Fourier transform of  $x_1[n]$ . Sketch  $x_1[n]$ , together with the signals with the following Fourier transforms:

(i) 
$$X_2(e^{j\omega}) = X_1(e^{j\omega})e^{j\omega}, |\omega| < \pi$$

(i) 
$$X_2(e^{j\omega}) = X_1(e^{j\omega})e^{j\omega}, |\omega| < \pi$$
  
(ii)  $X_3(e^{j\omega}) = X_1(e^{j\omega})e^{-j3\omega/2}, |\omega| < \pi$ 

**(b)** Let

$$w(t) = \cos\left(\frac{\pi t}{3T}\right) + \sin\left(\frac{\pi t}{2T}\right)$$

be a continuous-time signal. Note that  $x_1[n]$  can be regarded as a sequence of evenly spaced samples of w(t); that is,

$$x_1[n] = w(nT).$$

Show that

$$x_2[n] = w(nT - \alpha)$$

and

$$x_3[n] = w(nT - \beta)$$

and specify the values of  $\alpha$  and  $\beta$ . From this result we can conclude that  $x_2[n]$ and  $x_3[n]$  are also evenly spaced samples of w(t).

**5.45.** Consider a discrete-time signal x[n] with Fourier transform as illustrated in Figure P5.45. Provide dimensioned sketches of the following continuous-time signals:

(a) 
$$x_1(t) = \sum_{n=-\infty}^{\infty} x[n]e^{j(2\pi/10)nt}$$

(a) 
$$x_1(t) = \sum_{n=-\infty}^{\infty} x[n]e^{j(2\pi/10)nt}$$
  
(b)  $x_2(t) = \sum_{n=-\infty}^{\infty} x[-n]e^{j(2\pi/10)nt}$ 

![](_page_56_Figure_18.jpeg)

![](_page_56_Figure_19.jpeg)

Fig P5.45

Chap. 5 Problems 415

(c) 
$$x_3(t) = \sum_{n=-\infty}^{\infty} 0d\{x[n]\}e^{j(2\pi/8)nt}$$

(c) 
$$x_3(t) = \sum_{n=-\infty}^{\infty} 0d\{x[n]\} e^{j(2\pi/8)nt}$$
  
(d)  $x_4(t) = \sum_{n=-\infty}^{\infty} \Re\{x[n]\} e^{j(2\pi/6)nt}$ 

**5.46.** In Example 5.1, we showed that for  $|\alpha| < 1$ ,

$$\alpha^n u[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1}{1-\alpha e^{-j\omega}}.$$

(a) Use properties of the Fourier transform to show that

$$(n+1)\alpha^n u[n] \stackrel{\mathfrak{F}}{\longleftrightarrow} \frac{1}{(1-\alpha e^{-j\omega})^2}.$$

**(b)** Show by induction that the inverse Fourier transform of

$$X(e^{j\omega}) = \frac{1}{(1 - \alpha e^{-j\omega})^r}$$

is

$$x[n] = \frac{(n+r-1)!}{n!(r-1)!} \alpha^n u[n].$$

- **5.47.** Determine whether each of the following statements is true or false. Justify your answers. In each statement, the Fourier transform of x[n] is denoted by  $X(e^{j\omega})$ .
  - (a) If  $X(e^{j\omega}) = X(e^{j(\omega-1)})$ , then x[n] = 0 for |n| > 0.
  - **(b)** If  $X(e^{j\omega}) = X(e^{j(\omega \pi)})$ , then x[n] = 0 for |n| > 0.
  - (c) If  $X(e^{j\omega}) = X(e^{j\omega/2})$ , then x[n] = 0 for |n| > 0.
  - (d) If  $X(e^{j\omega}) = X(e^{j2\omega})$ , then x[n] = 0 for |n| > 0.
- **5.48.** We are given a discrete-time, linear, time-invariant, causal system with input denoted by x[n] and output denoted by y[n]. This system is specified by the following pair of difference equations, involving an intermediate signal w[n]:

$$y[n] + \frac{1}{4}y[n-1] + w[n] + \frac{1}{2}w[n-1] = \frac{2}{3}x[n],$$
  
$$y[n] - \frac{5}{4}y[n-1] + 2w[n] - 2w[n-1] = -\frac{5}{3}x[n].$$

- (a) Find the frequency response and unit sample response of the system.
- (b) Find a single difference equation relating x[n] and y[n] for the system.
- **5.49.** (a) A particular discrete-time system has input x[n] and output y[n]. The Fourier transforms of these signals are related by the equation

$$Y(e^{j\omega}) = 2X(e^{j\omega}) + e^{-j\omega}X(e^{j\omega}) - \frac{dX(e^{j\omega})}{d\omega}.$$

- (i) Is the system linear? Clearly justify your answer.
- (ii) Is the system time invariant? Clearly justify your answer.
- (iii) What is y[n] if  $x[n] = \delta[n]$ ?

(b) Consider a discrete-time system for which the transform  $Y(e^{j\omega})$  of the output is related to the transform of the input through the relation

$$Y(e^{j\omega}) = \int_{\omega-\pi/4}^{\omega+\pi/4} X(e^{j\omega}) d\omega.$$

Find an expression for y[n] in terms of x[n].

**5.50.** (a) Suppose we want to design a discrete-time LTI system which has the property that if the input is

$$x[n] = \left(\frac{1}{2}\right)^n u[n] - \frac{1}{4} \left(\frac{1}{2}\right)^{n-1} u[n-1],$$

then the output is

$$y[n] = \left(\frac{1}{3}\right)^n u[n].$$

- (i) Find the impulse response *and* frequency response of a discrete-time LTI system that has the foregoing property.
- (ii) Find a difference equation relating x[n] and y[n] that characterizes the system.
- (b) Suppose that a system has the response  $(1/4)^n u[n]$  to the input  $(n+2)(1/2)^n u[n]$ . If the output of this system is  $\delta[n] (-1/2)^n u[n]$ , what is the input?
- **5.51.** (a) Consider a discrete-time system with unit sample response

$$h[n] = \left(\frac{1}{2}\right)^n u[n] + \frac{1}{2} \left(\frac{1}{4}\right)^n u[n].$$

Determine a linear constant-coefficient difference equation relating the input and output of the system.

- (b) Figure P5.51 depicts a block diagram implementation of a causal LTI system.
  - (i) Find a difference equation relating x[n] and y[n] for this system.
  - (ii) What is the frequency response of the system?
  - (iii) Determine the system's impulse response.

![](_page_58_Figure_20.jpeg)

Fig P5.51

Chap. 5 Problems **417** 

5.52. (a) Let *h[n]* be the impulse response of a real, causal, discrete-time LTI system. Show that the system is completely specified by the real part of its frequency response. *(Hint:* Show how *h[n]* can be recovered from *Sv{h[n]}.* What is the Fourier transform of Sv{ *h[ n]}* ?) This is the discrete-time counterpart of the *realpart sufficiency* property of causal LTI systems considered in Problem 4.47 for continuous-time systems.

**(b)** Let *h[n]* be real and causal. If

$$\Re e\{H(e^{j\omega})\} = 1 + \alpha \cos 2\omega(\alpha \text{ real}),$$

determine *h[n]* and *H(eiw).* 

- (c) Show that *h[n]* can be completely recovered from knowledge of *9m{H(eiw)}*  and *h[O].*
- **(d)** Find two real, causal LTI systems whose frequency responses have imaginary parts equal to sin *w.*

# **EXTENSION PROBLEMS**

5.53. One ofthe reasons for the tremendous growth in the use of discrete-time methods for the analysis and synthesis of signals and systems was the development of exceedingly efficient tools for performing Fourier analysis of discrete-time sequences. At the heart of these methods is a technique that is very closely allied with discrete-time Fourier analysis and that is ideally suited for use on a digital computer or for implementation in digital hardware. This technique is the *discrete Fourier transform (DFT)* for finite-duration signals.

Let *x[n]* be a signal of finite duration; that is, there is an integer N1so that

$$x[n] = 0$$
, outside the interval  $0 \le n \le N_1 - 1$ 

Furthermore, let *X(eiw)* denote the Fourier transform of *x[n].* We can construct a periodic signal *i[n]* that is equal to *x[n]* over one period. Specifically, let *N* 2:: N<sup>1</sup> be a given integer, and let *i[n]* be periodic with period Nand such that

$$\tilde{x}[n] = x[n], \qquad 0 \le n \le N-1$$

The Fourier series coefficients for *i[n]* are given by

$$a_k = \frac{1}{N} \sum_{\langle N \rangle} \tilde{x}[n] e^{-jk(2\pi/N)n}$$

Choosing the interval of summation to be that over which *i[n]* = *x[n],* we obtain

$$a_k = \frac{1}{N} \sum_{n=0}^{N-1} x[n] e^{-jk(2\pi/N)n}$$
 (P5.53–1)

The set of coefficients defined by eq. (P5.53-l) comprise the DFT of *x[n].* Specifically, the DFT of *x[n]* is usually denoted by *X[k],* and is defined as

$$\tilde{X}[k] = a_k = \frac{1}{N} \sum_{n=0}^{N-1} x[n] e^{-jk(2\pi/N)n}, \qquad k = 0, 1, ..., N-1$$
 (P5.53-2)

The importance of the DFT stems from several facts. First note that the original finite duration signal can be recovered from its DFT. Specifically, we have

$$x[n] = \sum_{k=0}^{N-1} \tilde{X}[k]e^{jk(2\pi/N)n}, \qquad n = 0, 1, ..., N-1$$
 (P5.53–3)

Thus, the finite-duration signal can either be thought of as being specified by the finite set of nonzero values it assumes or by the finite set of values of  $\tilde{X}[k]$  in its DFT. A second important feature of the DFT is that there is an extremely fast algorithm, called the *fast Fourier transform (FFT)*, for its calculation (see Problem 5.54 for an introduction to this extremely important technique). Also, because of its close relationship to the discrete-time Fourier series and transform, the DFT inherits some of their important properties.

(a) Assume that  $N \ge N_1$ . Show that

$$\tilde{X}[k] = \frac{1}{N} X \left( e^{j(2\pi k/N)} \right)$$

where  $\tilde{X}[k]$  is the DFT of x[n]. That is, the DFT corresponds to samples of  $X(e^{j\omega})$  taken every  $2\pi/N$ . Equation (P5.53–3) leads us to conclude that x[n] can be uniquely represented by these samples of  $X(e^{j\omega})$ .

(b) Let us consider samples of  $X(e^{j\omega})$  taken every  $2\pi/M$ , where  $M < N_1$ . These samples correspond to more than one sequence of duration  $N_1$ . To illustrate this, consider the two signals  $x_1[n]$  and  $x_2[n]$  depicted in Figure P5.53. Show that if we choose M = 4, we have

$$X_1\left(e^{j(2\pi k/4)}\right) = X_2\left(e^{j(2\pi k/4)}\right)$$

for all values of k.

![](_page_60_Figure_13.jpeg)

Fig P5.53

**5.54.** As indicated in Problem 5.53, there are many problems of practical importance in which one wishes to calculate the discrete Fourier transform (DFT) of discrete-time signals. Often, these signals are of quite long duration, and in such cases it is very

Chap. 5 Problems 419

important to use computationally efficient procedures. One of the reasons for the significant increase in the use of computerized techniques for the analysis of signals was the development of a very efficient technique known as the fast Fourier transform (FFT) algorithm for the calculation of the DFT of finite-duration sequences. In this problem, we develop the principle on which the FFT is based.

Let x[n] be a signal that is 0 outside the interval  $0 \le n \le N_1 - 1$ . For  $N \ge N_1$ , the N-point DFT of x[n] is given by

$$\tilde{X}[k] = \frac{1}{N} \sum_{k=0}^{N-1} x[n] e^{-jk(2\pi/N)n}, \quad k = 0, 1, \dots, N-1.$$
 (P5.54–1)

It is convenient to write eq. (P5.54–1) as

$$\tilde{X}[k] = \frac{1}{N} \sum_{k=0}^{N-1} x[n] W_N^{nk}, \qquad (P5.54-2)$$

where

$$W_N = e^{-j2\pi/N}.$$

- (a) One method for calculating  $\tilde{X}[k]$  is by direct evaluation of eq. (P5.54–2). A useful measure of the complexity of such a computation is the total number of complex multiplications required. Show that the number of complex multiplications required to evaluate eq. (P5.54–2) directly, for k = 0, 1, ..., N 1, is  $N^2$ . Assume that x[n] is complex and that the required values of  $W_N^{nk}$  have been precomputed and stored in a table. For simplicity, do not exploit the fact that, for certain values of n and k,  $W_N^{nk}$  is equal to  $\pm 1$  or  $\pm j$  and hence does not, strictly speaking, require a full complex multiplication.
- (b) Suppose that N is even. Let f[n] = x[2n] represent the even-indexed samples of x[n], and let g[n] = x[2n+1] represent the odd-indexed samples.
  - (i) Show that f[n] and g[n] are zero outside the interval  $0 \le n \le (N/2) 1$ .
  - (ii) Show that the N-point DFT  $\tilde{X}[k]$  of x[n] can be expressed as

$$\tilde{X}[k] = \frac{1}{N} \sum_{n=0}^{(N/2)-1} f[n] W_{N/2}^{nk} + \frac{1}{N} W_N^k \sum_{n=0}^{(N/2)-1} g[n] W_{N/2}^{nk} 
= \frac{1}{2} \tilde{F}[k] + \frac{1}{2} W_N^k \tilde{G}[k], \quad k = 0, 1, ..., N-1, \quad (P5.54-3)$$

where

$$\tilde{F}[k] = \frac{2}{N} \sum_{n=0}^{(N/2)-1} f[n] W_{N/2}^{nk},$$

$$\tilde{G}[k] = \frac{2}{N} \sum_{n=0}^{(N/2)-1} g[n] W_{N/2}^{nk}.$$

**(iii)** Show that, for all *k,* 

$$\tilde{F}\left[k + \frac{N}{2}\right] = \tilde{F}[k],$$

$$\tilde{G}\left[k + \frac{N}{2}\right] = \tilde{G}[k].$$

Note that *F[k], k* = 0, 1, ... , *(N/2)* - 1, and *G[k], k* = 0, 1, ... , *(N/2)-* 1, are the (N/2)-point DFTs of *f[n]* and *g[n],* respectively. Thus, eq. (P5.54-3) indicates that the length-N DFT of *x[n]* can be calculated in terms of two DFTs of length *N/2.* 

- (iv) Determine the number of complex multiplications required to compute *X[k], k* = 0, 1, 2, ... , *N* - 1, from eq. (P5.54-3) by first computing *F[k]*  and *G[k].* [Make the same assumptions about multiplications as in part (a), and ignore the multiplications by the quantity 1/2 in eq. (P5.54-3).]
- (c) If, likeN, *N/2* is even, then *f[n]* and *g[n]* can each be decomposed into sequences of even- and odd-indexed samples, and therefore, their DFTs can be computed using the same process as in eq. (P5.54-3). Furthermore, if *N* is an integer power of 2, we can continue to iterate the process, thus achieving significant savings in computation time. With this procedure, approximately how many complex multiplications are required for *N* = 32, 256, 1,024, and 4,096? Compare this to the direct method of calculation in part (a).
- **5.55.** In this problem we introduce the concept of *windowing,* which is of great importance both in the design of LTI systems and in the spectral analysis of signals. Windowing is the operation of taking a signal *x[ n]* and multiplying it by a finite-duration *window signal w[n].* That is,

$$p[n] = x[n]w[n].$$

Note that *p[n]* is also of finite duration.

The importance of windowing in spectral analysis stems from the fact that in numerous applications one wishes to compute the Fourier transform of a signal that has been measured. Since in practice we can measure a signal *x[n]* only over a finite time interval (the *time window),* the actual signal available for spectral analysis is

$$p[n] = \begin{cases} x[n], & -M \le n \le M \\ 0, & \text{otherwise} \end{cases}$$

where - *M* :::; *n* :::; *M* is the time window. Thus,

$$p[n] = x[n]w[n],$$

where *w[n]* is the *rectangular window;* that is,

$$w[n] = \begin{cases} 1, & -M \le n \le M \\ 0, & \text{otherwise} \end{cases}$$
 (P5.55–1)

Windowing also plays a role in LTI system design. Specifically, for a variety of reasons (such as the potential utility of the FFT algorithm; see Problem P5.54), it is

Chap. 5 Problems **421** 

often advantageous to design a system that has an impulse response of finite duration to achieve some desired signal-processing objective. That is, we often begin with a desired frequency response *H(ejw)* whose inverse transform *h[n]* is an impulse response of infinite (or at least excessively long) duration. What is required then is the construction of an impulse response *g[ n]* of finite duration whose transform *G(ejw)* adequately approximates *H(ejw).* One general approach to choosing *g[n]* is to find a window function *w[n]* such that the transform of *h[n]w[n]* meets the desired specifications for *G(ejw).* 

Clearly, the windowing of a signal has an effect on the resulting spectrum. In this problem, we illustrate that effect.

(a) To gain some understanding of the effect of windowing, consider windowing the signal

$$x[n] = \sum_{k=-\infty}^{\infty} \delta[n-k]$$

using the rectangular window signal given in eq. (P5.55-1).

- (i) What is *X(ejw)?*
- (ii) Sketch the transform of *p[n]* = *x[n]w[n]* when *M* = 1.
- (iii) Do the same *forM* = 10.
- **(b)** Next, consider a signal *x[n]* whose Fourier transform is specified by

$$X(e^{j\omega}) = \left\{ \begin{array}{ll} 1, & |\omega| < \pi/4 \\ 0, & \pi/4 < |\omega| \leq \pi \end{array} \right. .$$

Let *p[n]* = *x[n]w[n],* where *w[n]* is the rectangular window of eq. (P5.55-1). Roughly sketch *P(ejw) forM* = 4, 8, and 16.

(c) One of the problems with the use of a rectangular window is that it introduces ripples in the transform *P(ejw).* (This is in fact directly related to the Gibbs phenomenon.) For that reason, a variety of other window signals have been developed. These signals are tapered; that is, they go from 0 to 1 more gradually than the abrupt transition of the rectangular window. The result is a reduction in the *amplitude* of the ripples in *P( ejw)* at the expense of adding a bit of distortion in terms of further smoothing of *X(ejw).* 

To illustrate the points just made, consider the signal *x[ n]* described in part (b), and let *p[n]* = *x[n]w[n],* where *w[n]* is the *triangular* or *Bartlett window;*  that is,

$$w[n] = \begin{cases} 1 - \frac{|n|}{M+1}, & -M \le n \le M \\ 0, & \text{otherwise} \end{cases}.$$

Roughly sketch the Fourier transform of *p[n]* = *x[n]w[n] forM* = 4, 8, and 16. *[Hint:* Note that the triangular signal can be obtained as a convolution of a rectangular signal with itself. This fact leads to a convenient expression for *W(ejw).]* 

(d) Let *p[n]* = *x[n]w[n],* where *w[n]* is a raised cosine signal known as the *Hanning window;* i.e.,

$$w[n] = \begin{cases} \frac{1}{2}[1 + \cos(\pi n/M)], & -M \le n \le M \\ 0, & \text{otherwise} \end{cases}$$

Roughly sketch *P( eiw)* for *M* = 4, 8, and 16.

5.56. Let *x[m, n]* be a signal that is a function of the two independent, discrete variables *m* and *n.* In analogy with one dimension and with the continuous-time case treated in Problem 4.53, we can define the two-dimensional Fourier transform of *x[m, n]* as

$$X(e^{j\omega_1}, e^{j\omega_2}) = \sum_{n = -\infty}^{\infty} \sum_{m = -\infty}^{\infty} x[m, n] e^{-j(\omega_1 m + \omega_2 n)}.$$
 (P5.56–1)

- (a) Show that eq. (P5.56-1) can be calculated as two successive one-dimensional Fourier transforms, first in *m,* with *n* regarded as fixed, and then inn. Use this result to determine an expression for *x[m, n]* in terms of *X(eiw 1, eiw<sup>2</sup> ).*
- (b) Suppose that

$$x[m,n] = a[m]b[n],$$

where *a[m]* and *b[n]* are each functions of only one independent variable. Let *A(eiw)* and *B(eiw)* denote the Fourier transforms of *a[m]* and *b[n],* respectively. Express *X(eiw 1, eiw<sup>2</sup> )* in terms of *A(eiw)* and *B(eiw).* 

- (c) Determine the two-dimensional Fourier transforms of the following signals:
  - (i) *x[m, n]* = *B[m-* 1]B[n + 4]
  - (ii) *x[m, n]* = *<4Yz-mu[n-* 2]u[ *-m]*
  - (iii) *x[m, n]* = (4)n cos(27Tm/3)u[n]
  - ( . ) [ ] \_ { 1, -2 < *m* < 2 and -4 < *n* < 4 IV *x m, n* - 0, otherwise
  - { 1 -2 + *n* < *m* < 2 + nand -4 < *n* < 4 (v) *x[m, n]* = o' h . , ot erw1se
  - (vi) *x[m, n]* = sin ( +
- (d) Determine the signal *x[m, n]* whose Fourier transform is

$$X(e^{j\omega_1}, e^{j\omega_2}) = \begin{cases} 1, & 0 < |\omega_1| \le \pi/4 \text{ and } 0 < |\omega_2| \le \pi/2 \\ 0, & \pi/4 < |\omega_1| < \pi \text{ or } \pi/2 < |\omega_2| < \pi \end{cases}.$$

- (e) Let *x[m, n]* and *h[m, n]* be two signals whose two-dimensional Fourier transforms are denoted by *X(eiw1, eiw<sup>2</sup> )* and *H(eiw1, eiw<sup>2</sup> ),* respectively. Determine the transforms of the following signals in terms of *X(eiw 1, eiw<sup>2</sup> )* and *H(eiw1, eiwz):* 
  - (i) *x[m, n]eiWJmeJWzn*
  - c·) [ ] { *x[k, r],* if *m* = *2k* and *n* = *2r* <sup>11</sup>*Y m, n* = 0, if *m* is not a multiple of 2 or *n* is not a multiple of 3
  - (iii) *y[m, n]* = *x[m, n]h[m, n]*