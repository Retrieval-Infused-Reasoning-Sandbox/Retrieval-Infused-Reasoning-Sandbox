# NON-EQUILIBRIUM STATISTICAL MECHANICS

by Gunnar Pruessner

Imperial College London Department of Mathematics 180 Queen's Gate London SW7 2AZ United Kingdom

# **Table of Contents**

| 1 |     | Introduction                                      | 7  |
|---|-----|---------------------------------------------------|----|
|   | 1.1 | Probabilities<br>                                 | 7  |
|   | 1.2 | Probability density function<br>                  | 8  |
|   | 1.3 | Moments and cumulants                             | 8  |
|   | 1.4 | Generating functions<br>                          | 9  |
|   |     | 1.4.1<br>Moment generating function of a sum      | 10 |
|   |     | 1.4.2<br>Cumulant generating function<br>         | 11 |
|   | 1.5 | GAUSSians<br>                                     | 11 |
|   | 1.6 | Central Limit Theorem<br>                         | 13 |
|   |     | 1.6.1<br>Stable distribution<br>                  | 15 |
| 2 |     | Stochastic processes                              | 17 |
|   | 2.1 | A POISSON process<br>                             | 17 |
|   | 2.2 | Events in time<br>                                | 20 |
|   | 2.3 | MARKOVian processes<br>                           | 21 |
|   | 2.4 | CHAPMAN-KOLMOGOROV equations<br>                  | 22 |
| 3 |     | Random walks                                      | 25 |
|   | 3.1 | Pedestrian random walk in discrete time           | 25 |
|   | 3.2 | Evolution of the PDF using CHAPMAN-KOLMOGOROV<br> | 26 |
|   | 3.3 | Master equation approach<br>                      | 27 |
|   | 3.4 | FOKKER-PLANCK equation<br>                        | 28 |
| 4 |     | LANGEVIN equations                                | 31 |
|   | 4.1 | Random walk<br>                                   | 31 |
|   | 4.2 | ORNSTEIN-UHLENBECK process<br>                    | 34 |
| 5 |     | Critical dynamics                                 | 37 |
|   | 5.1 | From HAMILTONian to LANGEVIN equation and back    | 38 |
|   | 5.2 | The PDF of η                                      | 39 |
|   | 5.3 | A FOKKER-PLANCK equation approach<br>             | 41 |
|   | 5.4 | The HOHENBERG-HALPERIN models                     | 43 |

This is an attempt to deliver, within a couple of hours, a few key-concepts of nonequilibrium statistical mechanics. The material covered by the notes is sometimes a bit wider in scope and often more detailed than a presentation can be.

The goal is to develop some ideas of contemporary research. I start with some basic methods of statistics as they are used in statistical mechanics. Many of the ideas are illustrated or even introduced by examples. The second chapter is more specialised: First I will present the concept of LANGEVIN equations, before discussing critical dynamics (introducing the notion of relaxation to equilibrium as opposed to far-from-equilibrium) and finally (if time permits) reaction-diffusion processes.

The plan is to spend at least two hours on the first chapter and at the remaining time of up to three hours on the second chapter.

Two main sources have been used to prepare these notes:

van Kampen, N. G., 1992, *Stochastic Processes in Physics and Chemistry* (Elsevier Science B. V., Amsterdam, The Netherlands), third impression 2001, enlarged and revised edition.

Tauber, U. C., 2005, ¨ *Critical dynamics*, preprint available at http://www.phys. vt.edu/˜tauber/utaeuber.html, (unpublished).

## **Chapter 1**

# **Introduction**

This chapter lays the theoretical foundation for the following material. The content is rather general and not restricted to non-equilibrium statistical mechanics, although some observables and techniques are characteristic for this field.

Firstly, I will introduce some basic techniques from statistics, in particular generating functions. The framework of generating functions will then be used to give a simple prove of the central limit theorem. In the last part of this chapter, some basic notions of stochastic processes will be discussed.

### **1.1 Probabilities**

A few reminders regarding probability are in order:

$$P(\neg A) = 1 - P(A) \tag{1.1a}$$

$$P(A \cup B) = P(A) + P(B) - P(A \cap B)$$
 (1.1b)

Here A ∪ B means that A or B occur (not exclusive). On the other hand A ∩ B means that A and B occur simultaneously. If A ∩ B = ∅ then A and B are **mutually exclusive**. If P(A, B) (joint probability) factorises P(A, B) = P(A)P(B) then A and B are said to be **independent**. The conditional probability P(A|B) (pronounced "probability of A given B") is given by BAYES's theorem

$$P(A|B) = \frac{P(A \cap B)}{P(B)} = \frac{P(B|A)P(A)}{P(B)}$$
(1.2)

Note that if P(A), P(B) 6= 0 and A, B are independent, then they cannot be mutually exclusive, because as they are independent P(A ∩ B) = P(A)P(B) 6= 0, but if A ∩ B = ∅ then P(A ∩ B) = 0. That makes a lot of sense: If A excludes B from occurring, than A are obviously not independent.

### **1.2 Probability density function**

We start this section by considering the **probability density function** (PDF) P<sup>a</sup> (x), which, in loose terms, is the probability of the random variable x to have a specific value. More precisely, P<sup>a</sup> (x) dx is the probability that a is in the interval [x, x + dx] and it is very important to realise that P<sup>a</sup> (x) is a *density* (in order to keep the notation simple, I will later use the subscript a for all sorts of purposes). The integral over the density is normalised,

$$\int_{-\infty}^{\infty} dx \, \mathcal{P}_{\alpha}(x) = 1 \tag{1.3}$$

Very often, it is more convenient to consider the **cumulative distribution function** (CDF)

$$F(z) = \int_{-\infty}^{z} dx \, \mathcal{P}_{\alpha}(x) \tag{1.4}$$

which is the probability that <sup>x</sup> is in the interval ]∞, <sup>z</sup>]. This definition is more convenient, because one does not need to introduce the whole notion of probability densities, but can stick with the concept of finite probabilities. Obviously, the lower integration limit in (1.4) should be chosen suitably and might be changed to, say, 0, if the PDF has corresponding support. A PDF is non-negative and therefore the CDF is increasing in z; according to (1.3) limz→<sup>∞</sup> <sup>F</sup>(z) = 1 and from (1.4)

$$\mathcal{P}_{a}(x) = \frac{d}{dz}F(z) \tag{1.5}$$

In the following, we will use the PDF as the starting point for all definitions and derivations.

It is an obvious extension to introduce vector valued random variables **x** or (equivalently) consider the **joint PDF** Pa,<sup>b</sup> (x, y) (where x and y could also be regarded as two components of a vector). In that case one has, quite naturally,

$$\mathcal{P}_{a}(x) = \int_{-\infty}^{\infty} dy \, \mathcal{P}_{a,b}(x,y)$$
 (1.6)

where the integration on the right is also known as **marginalisation** over the **nuisance variable** y. Two random variables are said to be **independent** if the joint PDF factorises, *i.e.* if Pab (x, y) = P<sup>a</sup> (x) P<sup>b</sup> (y).

### **1.3 Moments and cumulants**

The nth moment hx <sup>n</sup><sup>i</sup> is defined as

$$\langle x^{n} \rangle = \int_{-\infty}^{\infty} dx \, x^{n} \mathcal{P}_{a} (x) \tag{1.7}$$

which includes the normalisation (1.3) as the special case n = 0. By the properties of an integral we have hf(x) + g(x)i = hf(x)i + hg(x)i. The extension to joint PDFs is straight forward

$$\langle x^{n}y^{m}\rangle = \int_{-\infty}^{\infty} dx \int_{-\infty}^{\infty} dy \, x^{n}y^{m} \mathcal{P}_{ab}(x,y)$$
 (1.8)

If a and b <sup>1</sup> are independent, the joint probability factorises and <sup>h</sup><sup>x</sup> <sup>n</sup>ym<sup>i</sup> <sup>=</sup> <sup>h</sup><sup>x</sup> <sup>n</sup>i hymi. If hxyi = hxi hyi then x and y are said to be **uncorrelated**. While independence entails that the variables are uncorrelated, the converse does not hold, *i.e.* if two random variables are uncorrelated, they are not necessarily independent (although many authors ignore this fact).

**Cumulants** are *defined* as derivatives of the logarithm of the moment generating function, which will be discussed below. For the time being, we introduce only two cumulants, the **first cumulant**

$$\langle \mathbf{x} \rangle_{\mathbf{c}} = \langle \mathbf{x} \rangle \tag{1.9}$$

and the **second cumulant**

$$\langle x^2 \rangle_{c} = \langle x^2 \rangle - \langle x \rangle^2 = \langle (x - \langle x \rangle)^2 \rangle = \sigma^2(x)$$
 (1.10)

which equals the **variance** of the random variable x. Finally, the **third cumulant** is

$$\left\langle x^{3}\right\rangle _{c}=\left\langle (x-\left\langle x\right\rangle )^{3}\right\rangle =\left\langle x^{3}\right\rangle -3\left\langle x^{2}\right\rangle \left\langle x\right\rangle +2\left\langle x\right\rangle ^{3}\tag{1.11}$$

but the fourth cumulant is (sic!)

$$\langle x^4 \rangle_{c} = \langle (x - \langle x \rangle)^4 \rangle - 3 \langle (x - \langle x \rangle)^2 \rangle^2$$
 (1.12)

It is worth noting that the notation of moments and cumulants is somewhat loose: Comparing hx <sup>n</sup><sup>i</sup> and <sup>h</sup><sup>x</sup> <sup>n</sup>ym<sup>i</sup> in (1.7) and (1.8) respectively, it is not clear whether one has to integrate over both variables, x and y, or only over one, in which case hx <sup>n</sup>ym<sup>i</sup> <sup>=</sup> <sup>y</sup><sup>m</sup> <sup>h</sup><sup>x</sup> <sup>n</sup>i. Similarly, x 2 c is actually an integral over a square, as well as a square of an integral. This ambiguity is usually resolved by the context.

## **1.4 Generating functions**

For many situations, the **moment generating function** (MGF) is more suitable than the "plain" PDF. The moment generating function M<sup>a</sup> (z) is defined as

$$\mathcal{M}_{a}(z) = \sum_{i=0}^{\infty} \frac{z^{n}}{n!} \langle x^{n} \rangle$$
 (1.13)

<sup>1</sup> . . . or equivalently x and y, which are actually the concrete values of the random variable a and b respectively — I will be quite liberal when using the subscript and the argument, but the argument is always where the function is evaluated

if the sum converges. The MGF has the very useful property that

$$\frac{\mathrm{d}^{n}}{\mathrm{d}z^{n}}\Big|_{z=0} \mathcal{M}_{\alpha}(z) = \langle x^{n} \rangle \tag{1.14}$$

By noting that  $\langle \exp{(xz)} \rangle$  has exactly the same property and assuming that  $\mathfrak{M}_{\mathfrak{a}}(z)$  is analytic around z=0, one has

$$\mathcal{M}_{\alpha}(z) = \langle e^{xz} \rangle \tag{1.15}$$

In particular,  $\mathcal{M}_{\alpha}(0) = 1$  by normalisation.

Considering  $\langle \exp(xz) \rangle$  in detail, shows that it is the LAPLACE transform of the PDF, *i.e.* the MGF is the LAPLACE transform of the PDF:

$$\mathcal{M}_{\alpha}(z) = \int_{-\infty}^{\infty} dx \, e^{xz} \mathcal{P}_{\alpha}(x)$$
 (1.16)

Differentiating n times with respect to z and evaluating at z=0 brings down n factors of x, confirming (1.14). Evaluating the MGF for imaginary arguments turns the LAPLACE transform into a Fourier transform, which is also known as the **characteristic function**.

A discretised version of the MGF is easy to write down:

$$\mathcal{M}_{a}(z) = \sum_{x} \mathcal{P}_{a}(x) e^{xz}$$
 (1.17)

although in discrete problems where  $x \in \mathbb{Z}$  the factor  $\exp{(xz)}$  often is replaced by  $z^x$  and the moments are generated by  $\left(z\frac{d}{dz}\right)^n\Big|_{z=1}$ . Note that the coefficient in front of  $\exp{(xz)}$  in Eq. (1.17) are the probabilities of x.

#### 1.4.1 Moment generating function of a sum

The MGF is particularly useful when calculating sums and differences of random variables. We start with the example of two independent random numbers x and y drawn from a (factorising) PDF  $\mathcal{P}_{ab}(x,y) = \mathcal{P}_a(x) \mathcal{P}_b(y)$ . The MGF of the sum of these two random numbers is

$$\mathcal{M}_{a+b}(z) = \int_{-\infty}^{\infty} dx \int_{-\infty}^{\infty} dy \, e^{z(x+y)} \mathcal{P}_{ab}(x,y)$$

$$= \int_{-\infty}^{\infty} dx \, e^{zx} \mathcal{P}_{a}(x) \int_{-\infty}^{\infty} dy \, e^{zy} \mathcal{P}_{b}(y) = \mathcal{M}_{a}(z) \, \mathcal{M}_{b}(z) \quad (1.18)$$

which applies, by the same derivation, to the characteristic function.

The PDF of a multiple of a random variable, say  $y=\alpha x$  can be constructed either by considering the cumulative distribution introduced above, or by using  $\mathcal{P}_x(x)\,dx=\mathcal{P}_y(y)\,dy$ , so that  $\mathcal{P}_y(y)=\mathcal{P}_x(y/\alpha)\,dx/dy=\mathcal{P}_x(x)/\alpha$ . The MGF of the new random variable is

$$\mathcal{M}_{y}(z) = \int_{-\infty}^{\infty} dy \, e^{zy} \mathcal{P}(y) = \int_{-\infty}^{\infty} dx \, e^{z\alpha x} \mathcal{P}(x) = \mathcal{M}_{x}(z\alpha)$$
 (1.19)

1.5. GAUSSIANS

which is not surprising, given that  $\langle y^n \rangle = \alpha^n \langle x^n \rangle$ , *i.e.* every derivative of the MGF must shed a factor  $\alpha$ . In general, the random variable  $\alpha x + \beta y$  has MGF  $\mathcal{M}_x(z\alpha) \mathcal{M}_y(z\beta)$ , which again applies similarly to the characteristic function.

The characteristic function has the immediate advantage that we are more used to FOURIER transforms and can write down its inverse immediately. Such an inverse allows us to derive the PDF from the MGF.

### 1.4.2 Cumulant generating function

Cumulants have been introduces earlier (see Eq. (1.9)-(1.12)), but generally, they are defined as the derivatives of the logarithm of the MGF. Accordingly, the **cumulant generating function** (CGL)  $\mathcal{C}_{x}(z)$  is defined as

$$\mathcal{C}_{x}(z) = \ln \mathcal{M}_{x}(z) . \tag{1.20}$$

so that

$$\frac{\mathrm{d}^{n}}{\mathrm{d}z^{n}}\Big|_{z=0} \mathcal{C}_{a}(z) = \langle x^{n} \rangle_{c}$$
(1.21)

similar to Eq. (1.14).

The zeroth cumulant is  $\mathcal{C}_{x}(0) = \ln 1 = 0$ , the first cumulant is

$$\frac{\mathrm{d}}{\mathrm{d}z}\Big|_{0} \mathcal{C}_{x}(z) = \frac{\frac{\mathrm{d}}{\mathrm{d}z}\Big|_{0} \mathcal{M}_{x}(z)}{\mathcal{M}_{x}(0)} = \langle x \rangle , \qquad (1.22)$$

just the first moment. The second derivative of  $\mathcal{C}_{x}(z)$  in obvious notation is

$$C_{x}(z)'' = \frac{M_{x}(z)''}{M_{x}(z)} - \frac{M_{x}(z)'^{2}}{M_{x}(z)^{2}}$$
 (1.23)

and it gets more and more complicated.

Shifting the observable by  $x_0$  changes the MGF to  $\mathfrak{M}_x(z) \exp(zx_0)$  and therefore the CGF becomes  $\mathfrak{C}_x(z) + zx_0$ , so that only the first cumulant is affected by a shift.

**Exercise 1:** *Check Eq.* (1.9)–(1.12).

#### 1.5 GAUSSians

GAUSSians play a central rôle in all non-equilibrium statistical mechanics and we will see below why this is so. Let's briefly recapitulate some of its properties. We define the GAUSSian

$$\mathcal{G}(x; x_0, \sigma^2) = \frac{1}{\sqrt{2\sigma^2 \pi}} e^{-\frac{(x - x_0)^2}{2\sigma^2}}$$
(1.24)

which is normalised, as one can show by straight forward integration. Its mean is x0:

$$\int_{-\infty}^{\infty} dx \, \mathcal{G}(x; x_0, \sigma^2) x = \int_{-\infty}^{\infty} dx \, \mathcal{G}(x; x_0, \sigma^2) (x - x_0) + \int_{-\infty}^{\infty} dx \, \mathcal{G}(x; x_0, \sigma^2) x_0$$
 (1.25)

but the first integral vanishes by symmetry and the second is just the normalisation times x0. The second moment is slightly harder, see below; we note that generally

$$\int_{-\infty}^{\infty} dx \, \mathcal{G}(x; 0, \sigma^2) x^{2n} = (2n - 1)!! (\sigma^2)^n \tag{1.26}$$

with (2n − 1)!! = 1 · 3 · 5 . . .(2n − 1) is the double factorial. This can be proven, elegantly, using WICK's theorem, which states that the 2n'th moment is (σ 2 ) <sup>n</sup> times the number of unique ways to pair 2n elements. For example 1, 2, 3, 4 has pairs {(1, 2),(3, 4)}, {(1, 3),(2, 4)}, and {(1, 4),(2, 3)}. The general statement can be shown easily: Pick any one of 2n and find a partner, of which there are 2n − 1. Pick any next one, and find a partner again, out of 2n − 3. Repeat until only one is left, so (2n − 1)(2n − 3). . . 3 · 1. Alternatively, take all (2n)! permutations of the numbers 1, 2, . . . , 2n and consider neighbouring numbers as pairs, first and second, third and fourth *etc.*. There are n! permutations for each such "configuration" which leaves the pairs unchanged, and 2<sup>n</sup> possible swaps that leave them unchanged:

$$\frac{(2n)!}{2^n n!} = \frac{1 \cdot 2 \cdot 3 \cdot \dots \cdot (2n)}{2 \cdot 4 \cdot 6 \cdot \dots \cdot (2n)} = (2n - 1)!!$$
 (1.27)

The MGF of a GAUSSian is itself a (non-normalised) GAUSSian, which one can see by completing squares (similarly for the characteristic function),

$$\frac{(x-x_0)^2}{2\sigma^2} - xz = \frac{(x-x_0-z\sigma^2)^2}{2\sigma^2} - \frac{(x_0+z\sigma^2)^2 - x_0^2}{2\sigma^2}$$
(1.28)

so that

$$\int_{-\infty}^{\infty} dx \, \mathcal{G}(x; x_0, \sigma^2) e^{xz} = e^{\frac{(x_0 + z\sigma^2)^2 - x_0^2}{2\sigma^2}}$$
 (1.29)

Taking the logarithm produces the cumulant generating function of a GAUSSian:

$$\mathcal{C}_{\mathcal{G}}(z) = \frac{(x_0 + z\sigma^2)^2 - x_0^2}{2\sigma^2} = zx_0 + \frac{1}{2}z^2\sigma^2$$
 (1.30)

As required, C<sup>G</sup> (0) = 0, the first cumulant is x<sup>0</sup> as expected and the second cumulant (the variance) is just σ 2 . Surprisingly, and crucially, all higher cumulants vanish exactly. One might ask: Is every PDF, all cumulants of which vanish apart from the first and the second, a GAUSSian? Yes, that is indeed the case: Together with C (0) = 0, the first and the second cumulant fix the coefficients in any second order polynomial, so such a PDF will always produce a CGF of the form Eq. (1.30). PDFs all cumulants of which vanish apart from the first can be obtained by taking the limit limσ2→<sup>0</sup> for the GAUSSian, or by taking the inverse LAPLACE transform of exp  $(zx_0)$ , which gives (remember that this procedure is closely related to an inverse FOURIER transform) a DIRAC  $\delta$ -function at  $x_0$ . Finally taking away the first cumulant simply moves the peak to  $x_0 = 0$ .

Another important feature of a GAUSSian is that it solves the diffusion equation (remember that in the context of simple FOKKER-PLANCK equations),

$$\partial_{t} \phi = D \partial_{x}^{2} \phi - \nu \partial_{x} \phi \tag{1.31}$$

on  $x \in \mathbb{R}$ , with diffusion constant D, drift velocity  $\nu$  and initial condition  $\lim_{t\to 0} \phi = \delta(x-x_0)$ . It is solved by  $\phi = \mathcal{G}(x-\nu t; x_0, 2Dt)$ . It is worth remembering that the diffusion constant D gives rise to the variance 2Dt.

#### 1.6 Central Limit Theorem

The **CLT** (central limit theorem) is of fundamental importance in all of statistics and statistical mechanics. Here, it is presented in a somewhat simplified form, but more sophisticated versions exist for correlated variables and with a more detailed analysis of precisely how the PDF of sums of random variables converge to a GAUSSian.

Consider the mean of N independent variables  $x_i$  with i = 1, 2, ..., N, all drawn from the same PDF which is arbitrary, apart from having vanishing mean and finite cumulants<sup>2</sup>:

$$\mathcal{X} \equiv \frac{1}{\sqrt{N}} \sum_{i}^{N} x_{i} \tag{1.32}$$

Notice the somewhat unusual normalisation  $\sqrt{N}^{-1}$ , which is crucial to the argument. We will get back to that point. If the MGF of the underlying PDF<sup>3</sup> is  $\mathcal{M}_{\alpha}(z)$ , then the MGF of the sum is (see Section 1.4.1)  $\mathcal{M}_{\chi}(z) = \mathcal{M}_{\alpha}\left(z/\sqrt{N}\right)^{N}$  and the CGF is

$$\mathcal{C}_{\mathcal{X}}(z) = N\mathcal{C}_{\alpha}\left(z/\sqrt{N}\right)$$
 (1.33)

The first cumulant vanishes (because the first cumulant of x vanishes), as one would expect and the second cumulant is

$$\frac{\mathrm{d}^{2}}{\mathrm{d}z^{2}}\bigg|_{z=0} \mathfrak{C}_{\chi}(z) = \frac{\mathrm{d}^{2}}{\mathrm{d}z^{2}}\bigg|_{z=0} \mathfrak{C}_{\alpha}(z) \tag{1.34}$$

which means that the variance of X is the same as the variance of x itself. This is true for any N. In general, the higher derivatives give

$$\langle \mathcal{X}^{n} \rangle_{c} = N^{1-n/2} \langle x^{n} \rangle_{c} \tag{1.35}$$

<sup>&</sup>lt;sup>2</sup>If the cumulants are not finite, a CGF might still exists, but it cannot be expanded about z = 0.

<sup>&</sup>lt;sup>3</sup>One can obtain the PDF directly through convolutions, the outcome is the same. XXX show that.

and because the cumulants of the underlying PDF are all finite, the cumulants of X vanish for n > 2, <sup>N</sup> <sup>→</sup> <sup>∞</sup>. Because only the second cumulant "survives", the PDF of <sup>X</sup> is a Gaussian, see Section 1.5. This is the CLT: The PDF of X converges to a GAUSSian.

Going through the "proof" above, the extra condition that the average hxi must vanish can be lifted by shifting the x<sup>i</sup> by hxi. One might be tempted to restate the CLT for simple averages like

$$\mathcal{X} \equiv \frac{1}{N} \sum_{i}^{N} x_{i} \tag{1.36}$$

or maybe

$$\mathfrak{X} \equiv \sum_{i}^{N} x_{i} . \tag{1.37}$$

However, both these random variables do *not* produce a GAUSSian. The first one, (1.36), will produce a distribution that converges for <sup>N</sup> <sup>→</sup> <sup>∞</sup> to a DIRAC <sup>δ</sup>-peak at hxi, because with that normalisation all cumulants apart from the first one will vanish, hX <sup>n</sup>i<sup>c</sup> <sup>=</sup> <sup>N</sup>1−<sup>n</sup> <sup>h</sup><sup>x</sup> <sup>n</sup>i<sup>c</sup> . The second cumulant vanishes like N−<sup>1</sup> , but all higher cumulants vanish even faster and therefore the distribution of the average X will look more and more like a Gaussian centered at hxi with ever decreasing width. This observation is what people mean when they say that "averages converge to a Gaussian". Strictly speaking this is wrong, because the distribution of simple averages converges to a DIRAC δ-function, but if one accepts to consider the leading order correction in the approach to the DIRAC δ-function, then the distribution is Gaussian (with corrections in the higher cumulants of order of at least N−<sup>2</sup> ).

The second variation, (1.37) is more disastrous: All cumulants that do not vanish in the underlying PDF diverge with increasing N for the PDF of X, because hX <sup>n</sup>i<sup>c</sup> <sup>=</sup> N hx <sup>n</sup>i<sup>c</sup> . Even the centre of mass (hXi) would run away. The observation hX <sup>n</sup>i<sup>c</sup> <sup>=</sup> <sup>N</sup> <sup>h</sup><sup>x</sup> <sup>n</sup>i<sup>c</sup> looks like clashing with the effect (1.37) has on moments, hX <sup>n</sup><sup>i</sup> <sup>=</sup> <sup>N</sup><sup>n</sup> <sup>h</sup><sup>x</sup> <sup>n</sup><sup>i</sup> <sup>+</sup> . . . where the dots contain lower order terms. So, if hX <sup>n</sup><sup>i</sup> <sup>∝</sup> <sup>N</sup>n, how come <sup>h</sup><sup>X</sup> <sup>n</sup>i<sup>c</sup> <sup>∝</sup> <sup>N</sup>, given that cumulants can be calculated from moments? The answer is in the dots: Calculating the nth cumulant from moments, all terms to power Nn, Nn−<sup>1</sup> , Nn−<sup>2</sup> , . . . , N<sup>2</sup> will cancel and only the terms to order N will remain.

It is often said, that "the sum of random variables looks more and more GAUSSian the more variables are added". That, however, is true only if one rescales the observables appropriately: If P<sup>N</sup> i x<sup>i</sup> is not divided by a sufficiently high power of N, the resulting PDF generally broadens (indicated by increasing variance) and has a centre of mass that will generally continue to change with increasing N. Notice, that the centre of mass is moving like N1/<sup>2</sup> hxi if hxi 6= 0 in the original derivation. If, on the other hand, one divides by too high a power, the distribution collapses to a δ-peak, the position of which might even change with N, depending on the choice of normalisation.

#### **1.6.1 Stable distribution**

If the PDF of the sum of two random variables is exactly identical to the PDF of the individual PDFs (after suitable rescaling), then such a PDF is known as stable. The Gaussian is the *only* stable PDF with finite variance.

## **Chapter 2**

# **Stochastic processes**

Mathematicians have a proper definition of a stochastic process. However, at the present level of rigour, it suffices to say that a stochastic process is a time-dependent observable which depends on some random events that occur in time. It is important to keep in mind that a stochastic process is characterised by an observable and a statement about the process needs to be interpreted as a statement about the observable. The observable marks a point in the **sample space**, the space of all possible outcomes.

### **2.1 A POISSON process**

The POISSON process is a **point process** and can be visualised as an arrangement of s > 0 points on the interval, say, [0, t]. The PDF for having s points at "times" τ1, τ2, . . . , τ<sup>s</sup> is Q(τ1, τ2, . . . , τs). We impose that any permutation of the times corresponds to exactly the same state, so when we impose normalisation, we have to discount for double counting. This can be done either by summing over an ordered set, say τ<sup>1</sup> 6 τ<sup>2</sup> 6 . . . 6 τs, or by double counting and then dividing by the degeneracy:

$$\sum_{s=0}^{\infty} \frac{1}{s!} \int_{0}^{t} d\tau_{1} \dots d\tau_{s} \ Q(\tau_{1}, \dots, \tau_{s}) = 1$$
 (2.1)

By imposing that the Q factorise in the form, Q(τ1, . . . , τs) = e <sup>−</sup>νq(τ1). . . q(τs) one arrives at the POISSON process (in the stationary state, *i.e.* q is constant, also known as **shot noise**). The normalisation then gives exp −ν + Rt 0 dτ q(τ) = 1, so

$$v = \int_0^t d\tau \, q(\tau) \tag{2.2}$$

The MGF for the moments of the number of points is easy to write down, simply multiply by a factor exp (zs) inside the summation Eq. (2.1) and use the POISSON property (factorisation):

$$\mathcal{M}_{P}(z) = e^{-\nu} \sum_{s=0}^{\infty} \frac{1}{s!} e^{zs} \nu^{s} = e^{(\exp(z) - 1)\nu}$$
 (2.3)

and the cumulant generating function is just C<sup>P</sup> (z) = (exp (z)−1)ν, so that all cumulants greater or equal to 1 give ν. In particular, the first moment is ν, so that the MGF is

$$\mathcal{M}_{P}(z) = e^{(\exp(z)-1)\langle s \rangle} = e^{-\langle s \rangle} \sum_{n=0}^{\infty} \frac{\langle s \rangle^{n}}{n!} e^{nz}$$
 (2.4)

On the other hand, the MGF is hexp (nz)i, see Eq. (1.15) (but notice that the averaging is now over the discrete variable s), *i.e.*

$$\mathcal{M}_{P}(z) = \sum_{s=0}^{\infty} \mathcal{P}_{P}(s) e^{sz}$$
 (2.5)

which by comparison of coefficients means that the probability to have n events in the interval [0, t] is given by the POISSON distribution

$$\mathcal{P}_{P}(s) = e^{-\langle s \rangle} \frac{\langle s \rangle^{s}}{s!}$$
 (2.6)

In case of shot noise, the probability that no event takes place within a time interval [t, t+dt] is (1−qdt). The survival probability, *i.e.* the probability that no event takes place within a finite interval of length ∆t, therefore is limdt→0(1 − qdt) ∆t/d<sup>t</sup> = exp (−q∆t). It is important to realise that this is the probability for no event to occur for *at least* ∆t. The probability that such a "streak" is terminated after time ∆t is the survival probability times the probability for an event to occur in the next instance, exp (−q∆t) qdt. This probability density is obviously normalised.

**Exercise 2:** ZERNIKE's "Weglängenparadoxon": Say q is a constant (shot noise) and so the probability that an event takes place is constant. Show that the average time between two events is 1/q (ignore boundary effects, i.e. consider the interval  $]-\infty,\infty[$ . Moreover, show that the average time from any randomly chosen point in time to the preceding event is 1/q and to the (next) following event is 1/q as well. This, however, suggests that the distance between any two events is 2/q.

**Note/Solution:** The probability that time  $\alpha\Delta t$  passes with no event, then one event happens (density q) and then time  $(1-\alpha)\Delta t$  passes is  $\exp(-q\alpha\Delta t)$  q  $\exp(-q(1-\alpha)\Delta t) = q \exp(-q\Delta t)$ . Similarly one might have any number of events n at specific times with any sequence of silences in between with probability  $q^n \exp(-q\Delta t)$ . This is the probability density to have a sequence of n events at certain times over a period of time  $\Delta t$ . The probability of having n events within  $\Delta t$  therefore is

$$\int_{0}^{\Delta t} dt'_{1} \int_{t'_{1}}^{\Delta t} dt'_{2} \dots \int_{t'_{n-1}}^{\Delta t} dt'_{n} q^{n} e^{-q\Delta t} 
= \frac{1}{n!} \int_{0}^{\Delta t} dt'_{1} \int_{0}^{\Delta t} dt'_{2} \dots \int_{0}^{\Delta t} dt'_{n} q^{n} e^{-q\Delta t} 
= \frac{1}{n!} (q\Delta t)^{n} e^{-q\Delta t}$$
(2.7)

which is, after summing over all n, obviously properly normalised. Eq. (2.7) is identical to Eq. (2.6) with  $\langle s \rangle = q \Delta t$  (notice the factorial 1/n! and the additional power  $\Delta t^n$  compared to the probability of a sequence of events at certain times,  $q^n \exp{(-q \Delta t)}$ ). The key insight is that all that matters is the total time of silence, not the precise amount of time for each interval of silence. The state of each point in time (having or not having an event) is independent.

One might conclude that the average distance from a randomly chosen point to the next event can be derived by considering empty intervals that are terminated after time  $\Delta t$  by an event and being pierced by another one at  $\alpha \Delta t$ ,  $\alpha \in [0,1]$ . The two events being independent, all what counts is the quiet stretch up to its termination, which has probability  $q \exp(-q\Delta t)$ , so that the average time between a randomly chosen point in time and the next event is

$$\int_0^1 d\alpha \int_0^\infty d\Delta t (\alpha \Delta t) q e^{-q \Delta t} = \frac{1}{2q}.$$
 (2.8)

This procedure is deceptive, it seems to run over all possible configurations, namely all

 $<sup>^1</sup>$ The 1/n! compensates for ignoring the time-order of the integrals (generally 1/n! compensates for double-counting, as events or particle are considered as indistinguishable and configurations only to be counted once): The first line in Eq. (2.7) means  $t_1' \leqslant t_2' \leqslant \ldots \leqslant t_n'$ . The integrand is invariant under permutations of the  $t_i'$ , in fact, it is even independent of all  $t_i'$ . So, any arbitrary time order, say  $t_4' \leqslant t_7' \leqslant \ldots \leqslant t_2'$  gives the same result and the sum over all time orders gives n! times the desired result. However, the sum over all time orders corresponds to the integral with no time order at all, the second line in Eq. (2.7).

intervals ∆t terminated by an event and all positions α∆t of another event within this interval. This however, turns out to be *half* of the average distance between any pair of events: q exp (−q∆t) is the probability of an empty stretch occuring from some initial point, terminated by an event, but the intermediate event at α∆t has been accounted for. The probability of *two* events occuring within ∆t, one at α∆t < ∆t and one at the end is q 2 exp (−q∆t). The correct normalisation for the (α, ∆t) probability space gives an additional factor ∆t (but note R<sup>∞</sup> 0 d∆t R∆t 0 d∆t′ q 2 exp (−q∆t) = 1), so correcting the arguments above, Eq. (2.8), the average distance between two events across all such events is

$$\int_{0}^{1} d\alpha \int_{0}^{\infty} d\Delta t (\alpha \Delta t) q^{2} \Delta t e^{-q \Delta t} = \frac{1}{q}.$$
 (2.9)

What is actually missing in Eq. (2.8) is the probability density of the second, intermediate event to occur, which was missed because of α being dimensionless.

More directly, the average distance from any randomly chosen point to the next event is given by the first moment of the probability of having a quiet stretch up to time ∆t, terminated by an event

$$\int_0^\infty d\Delta t \, \Delta t q e^{-q\Delta t} = \frac{1}{q} \,. \tag{2.10}$$

This is also the distance between events, averaged over all pairs. If one wants to calculate the average length of an empty stretch chosen randomly by picking a point at random, then one has to take into account that the picking is biased towards longer stretches, which are picked with a probability ∝ t exp (−q∆t). After normalising this probability, the average length of such a stretch is

$$\int_0^\infty d\Delta t \, \Delta t^2 q^2 e^{-q\Delta t} = 2/q \; . \tag{2.11}$$

### **2.2 Events in time**

In the following, I will first derive some general properties of time-dependent PDFs.

Without getting to formal, we now consider the PDF of a series of "events" in the sense that an observable x (could be a high-dimensional observable, describing, for example the positions of all gas molecules in a box) has a certain value at a certain time t, *i.e.* the PDF P<sup>1</sup> (x, t). Note that this PDF is normalised with respect to x, while t parameterises the PDF, so P<sup>1</sup> (x, t) is to be considered as a series of PDFs, each for a specific time t. If P<sup>1</sup> (x, t) is independent of t, then the process is said to be stationary. The index 1 is explained below.

One could consider the joint PDF P<sup>2</sup> (x2, t2; x1, t1), which is the probability to observe x<sup>1</sup> at t<sup>1</sup> and x<sup>2</sup> at t2. The conditional PDF to observe x<sup>2</sup> at t<sup>2</sup> given that one observes x<sup>1</sup> at t<sup>1</sup> is

$$\mathcal{P}_{1|1}\left(x_{2}, t_{2} | x_{1}, t_{1}\right) = \frac{\mathcal{P}_{2}\left(x_{2}, t_{2}; x_{1}, t_{1}\right)}{\mathcal{P}_{1}\left(x_{1}, t_{1}\right)} = \frac{\mathcal{P}_{1|1}\left(x_{1}, t_{1} | x_{2}, t_{2}\right) \mathcal{P}_{1}\left(x_{2}, t_{2}\right)}{\mathcal{P}_{1}\left(x_{1}, t_{1}\right)}.$$
 (2.12)

This procedure can be generalised to any number of observations and the index indicates how many observations the PDF covers and how many are conditions. To ease notation, we will occasionally drop the index and write just n for xn, tn.

Trivially marginalising over the nuisance variable gives

$$\mathcal{P}_{1|1}(3|1) = \int d2 \,\mathcal{P}_{2|1}(2,3|1) \tag{2.13}$$

and because

$$\mathcal{P}_{2|1}\left(2,3|1\right) = \frac{\mathcal{P}_{3}\left(1,2,3\right)}{\mathcal{P}_{1}\left(1\right)} = \frac{\mathcal{P}_{3}\left(1,2,3\right)}{\mathcal{P}_{2}\left(1,2\right)} \frac{\mathcal{P}_{2}\left(1,2\right)}{\mathcal{P}_{1}\left(1\right)} = \mathcal{P}_{1|2}\left(3|1,2\right) \mathcal{P}_{1|1}\left(2|1\right) \tag{2.14}$$

we have

$$\mathcal{P}_{1|1}(3|1) = \int d2 \,\mathcal{P}_{1|2}(3|1,2) \,\mathcal{P}_{1|1}(2|1) \tag{2.15}$$

### **2.3 MARKOVian processes**

The term MARKOVian is heavily overused in the physics literature. It means that the PDF of a sequence of events (a particular observable) with t<sup>1</sup> < t<sup>2</sup> < t<sup>3</sup> < . . . < tn+<sup>1</sup> (for n > 1) has the property

$$\mathcal{P}_{1|n}(n+1|1,2,3,\ldots,n) = \mathcal{P}_{1|1}(n+1|n)$$
 (2.16)

*i.e.* for the probability of an observable to have value x<sup>1</sup> at t1, given that it had values x2, x3, . . . , x<sup>n</sup> earlier, only the most recent time matters (if it matters at all). The MARKOV property can be used to compile a hierarchy. By BAYES

$$\mathcal{P}_{2}(1,2) = \mathcal{P}_{1}(1) \mathcal{P}_{1|1}(2|1)$$
 (2.17a)

$$\mathcal{P}_2(1,2,3) = \mathcal{P}_2(1,2) \mathcal{P}_{1|2}(3|1,2)$$
 (2.17b)

$$\mathcal{P}_2(1,2,3,4) = \mathcal{P}_3(1,2,3) \mathcal{P}_{1|3}(4|1,2,3)$$
 (2.17c)

and therefore

$$\begin{split} \mathcal{P}_{2}\left(1,2,3,4\right) &= \mathcal{P}_{2}\left(1,2\right) \mathcal{P}_{1|2}\left(3|1,2\right) \mathcal{P}_{1|3}\left(4|1,2,3\right) \\ &= \mathcal{P}_{1}\left(1\right) \mathcal{P}_{1|1}\left(2|1\right) \mathcal{P}_{1|2}\left(3|1,2\right) \mathcal{P}_{1|3}\left(4|1,2,3\right) \; . \end{aligned} \tag{2.18}$$

The conditional PDFs on the RHS can be simplified using the MARKOV property Eq. (2.16), and so:

$$\mathcal{P}_{2}(1,2,3,4) = \mathcal{P}_{1}(1) \mathcal{P}_{1|1}(2|1) \mathcal{P}_{1|1}(3|2) \mathcal{P}_{1|1}(4|3) . \tag{2.19}$$

All PDFs are therefore fully determined by the initial distribution P<sup>1</sup> (1) and the transition probability P1|<sup>1</sup> (). The idea is that "all that matters for later times is the state at the system at any earlier point", or rather "history does not matter" (the process does not have any memory). By including enough details (namely *all* it depends on) into the observable, every process can be made MARKOVian, which is why the statement that a process is MARKOVian is an empty one without specifying the observable.<sup>2</sup>

conditional an additio

additional observables might very well change the conditional PDF

Note that the MARKOV property relies on some sort of temporal order. It is always the most recent, the preceding time, that matters, P (n + 1|1, 2, 3, . . . , n) = P (n + 1|n). However, given that property, one can show that P (1|2, . . . , n + 1) = P (1|2), using (2.19):

$$\mathcal{P}_{1|n}(1|2,...,n+1) = \frac{\mathcal{P}_{n+1}(1,2,...,n+1)}{\mathcal{P}_{n}(2,...,n+1)} \\
= \frac{\mathcal{P}_{1}(1)\mathcal{P}_{1|1}(2|1)\mathcal{P}_{1|1}(3|2)...\mathcal{P}_{1|1}(n+1|n)}{\mathcal{P}_{1}(2)\mathcal{P}_{1|1}(3|2)...\mathcal{P}_{1|1}(n+1|n)} = \frac{\mathcal{P}_{1}(1)\mathcal{P}_{1|1}(2|1)}{\mathcal{P}_{1}(2)} = \frac{\mathcal{P}_{2}(1,2)}{\mathcal{P}_{1}(2)} = \mathcal{P}_{1|1}(1|2) ,$$
(2.20)

so the probability to see x<sup>1</sup> at t<sup>1</sup> depends only on what happens at t<sup>2</sup> not on what happens later; there is no preferred direction of time in the MARKOV-property.<sup>3</sup>

## **2.4 CHAPMAN-KOLMOGOROV equations**

The MARKOV has an important integral form. Going back to Eq. (2.15), this expression becomes

$$\mathcal{P}_{1|1}(3|1) = \int d2 \,\mathcal{P}_{1|1}(3|2) \,\mathcal{P}_{1|1}(2|1) \tag{2.21}$$

<sup>2</sup>One needs to be a bit careful with the emphasis here. MARKOVian means adding knowledge about the history does not change the conditional PDFs, such as Eq. (2.19). Starting with a non-MARKOVian process, one can render it MARKOVian by adding additional variables, which carry the information encoded otherwise in the history. In that sense one can translate "no history needed" into "no additional observables needed". However, the conditional (conditional to history) PDF of a MARKOV process might easily be a function of an additional variable, *i.e.* adding that observables renders the process non-MARKOVian (the trivial example is that of a MARKOV process that combined with a non-MARKOVian process is non-MARKOVian). So adding variables might not always improve the situation towards MARKOVian. In any case, MARKOVian or non-MARKOVian is a feature of a process and its observable.

<sup>3</sup>One might wonder: If the time-direction in BOLTZMANN's H-theorem does not have its origin in the MARKOV-property (2.16), where does it come from? If there was no inverse MARKOV-property (2.20), then one would argue that a time direction in the "increase of entropy" of the H-theorem comes from Eq. (2.16) and that the inverse of the transition matrix P1|<sup>1</sup> (2|1), namely P1|<sup>1</sup> (1|2), does not obey a corresponding inverse relation. Now we find out that it does, see Eq. (2.20), which suggests that the H-theorem works backwards for the inverse matrix. The riddle can be resolved by showing that P1|<sup>1</sup> (1|2) is not a MARKOVian matrix (unless P1|<sup>1</sup> (1|2) is effectively deterministic, in which case the entropy does not increase in the original model; just try m = 0 1 1 0 ), by having negative elements, for example. In that case, P1|<sup>1</sup> (1|2) could not be applied to every general "initial" distribution P<sup>1</sup> (2), *i.e.* P<sup>1</sup> (1) = R d2P<sup>1</sup> (2) P1|<sup>1</sup> (1|2) by marginalising over 2.

where P1|<sup>2</sup> (3|1, 2) = P1|<sup>1</sup> (3|2) has been used (compare to Eq. (2.15)) because of the MARKOV property. Multiplying by P<sup>1</sup> (1) and integrating over 1 gives

$$\mathcal{P}_{1}(3) = \int d2 \,\mathcal{P}_{1|1}(3|2) \,\mathcal{P}_{1}(2) \,.$$
 (2.22)

The corresponding integral of Eq. (2.15) gives the more complicated expression

$$\mathcal{P}_{1}(3) = \int d1 \int d2 \,\mathcal{P}_{1|2}(3|1,2) \,\mathcal{P}_{2}(1,2) = \int d1 \int d2 \,\mathcal{P}_{3}(1,2,3) , \qquad (2.23)$$

with the right hand side being a trivial marginalisation.

Eq. (2.21) is known as the CHAPMAN-KOLMOGOROV equation; it says that the PDF at t<sup>3</sup> given the observation at t<sup>1</sup> is the integral over all intermediate values x<sup>2</sup> at time t<sup>2</sup> over the product of the transitions from x<sup>1</sup> to x<sup>2</sup> and from x<sup>2</sup> to x3. It is only that last part that is different from Eq. (2.15): There we had to consider the transition to x<sup>3</sup> given x<sup>2</sup> *and* x1. While Eq. (2.21) looks like the trivial statement that "one has to take an intermediate step 2 to go from 1 to 3", it actually contains the profound statement that for the step from 2 to 3 its previous position at 1 is of no relevance.

The CHAPMAN-KOLMOGOROV equation is a consequence of the MARKOV property.<sup>4</sup>

<sup>4</sup> I don't find it obvious to show that the converse holds.

## **Chapter 3**

# **Random walks**

The random walk, described by the position **x**(t) in d dimensions as a function of time t, is the prime example for a MARKOVIAN stochastic process. The position **x** evolves under a certain transition probability distribution.

In the following, first a discrete version of the random walk is analysed, without making use of the evolution equation of the PDF as given by the CHAPMAN-KOLMOGOROV equation, Eq. (2.21). Next, we will consider those equations, allowing the position of the random walker and the time to be continuous. Finally, the concepts of a master and FOKKER-PLANCK equation are introduced.

### **3.1 Pedestrian random walk in discrete time**

Instead of considering the evolution of the PDF Prw (x), we investigate the MGF of the position. For simplicity, time and space are discretised and space is restricted to one dimension, so <sup>x</sup>(t) = <sup>n</sup>(t) <sup>∈</sup> <sup>Z</sup> and <sup>t</sup> <sup>∈</sup> <sup>N</sup>.

Say the random walker starts at n(t = 0) = n<sup>0</sup> and in every time step, its position increases by 1 with probability p and decreases by 1 (with probability q ≡ 1−p) otherwise. The MGF at t = 0 is just Mrw (z; t = 0) = exp (zn0). In the following time step its position is n<sup>0</sup> + 1 with probability p and n<sup>0</sup> − 1 with probability q, so

$$\mathcal{M}_{rw}(z;t=1) = pe^{z(n_0+1)} + qe^{z(n_0-1)} = \mathcal{M}_{rw}(z;t=0) (pe^z + qe^{-z})$$
 (3.1)

Note that the factor (p exp (z) + q exp (−z)) can be written as

$$pe^z + qe^{-z} = p(\cosh(z) + \sinh(z)) + q(\cosh(z) - \sinh(z)) = \cosh(z) + (p-q)\sinh(z)$$
 (3.2)

In fact, there is a general updating rule of the MGF: The term exp (zn) indicates position n and its coefficient is the probability of the random walker to be at n, see Eq. (1.17). So, by multiplication by p exp (z) each exp (zn) is shifted by one to exp (z(n + 1)), which is the new position, and the probability is p times the probability to be there, which is given by the coefficient. The same can be done for the "down moves" and the collective (*i.e.* summed) coefficient in front of exp (zn′ ) indicates the new probability to be at any n ′ . In other words

$$\mathcal{M}_{rw}(z;t+1) = \mathcal{M}_{rw}(z;t) pe^{z} + \mathcal{M}_{rw}(z;t) qe^{-z}$$
 (3.3)

so that

$$\mathcal{M}_{\text{rw}}(z;t) = \mathcal{M}_{\text{rw}}(z;t=0) \left( pe^{z} + qe^{-z} \right)^{t} = \mathcal{M}_{\text{rw}}(z;t=0) \left( \cosh(z) + (p-q)\sinh(z) \right)^{t}$$
(3.4)

(which might remind one of the one-dimensional ISING model). It is trivial to write down the above result explicitly,

$$\mathcal{M}_{rw}(z;t) = \sum_{i=0}^{t} p^{i} q^{t-i} {t \choose i} e^{z(n_0 + i - (t-i))}$$
(3.5)

where of course n<sup>0</sup> + i − (t − i) = n<sup>0</sup> + 2i − t, which means that parity conserved for even t. Without loss of generality n<sup>0</sup> = 0 and for even t the random walker can only be at an even position n (the coefficients of exp (zn) then vanish for odd n). With n = 2i the PDF is then just p iq t−i t i .

### **3.2 Evolution of the PDF using CHAPMAN-KOLMOGOROV**

Next, the condition that the position is discrete is relaxed. The random walker still evolves in discrete time and, say, Prw (x; t = 0) = δ(x − x0). According to Eq. (2.21) we only need to specify the evolution "matrix"<sup>1</sup> , P1|<sup>1</sup> (2|1). If that expression depends only on the time difference t<sup>2</sup> − t1, the MARKOV process is said to be homogeneous. Sometimes the term "stationary" is used as well, although it should rather be reserved for time independent PDFs.

Say the transition matrix is given by

$$\mathcal{P}_{1|1}(x_2, t_2|x_1, t_1) = \frac{1}{\sqrt{4\pi D(t_2 - t_1)}} e^{-\frac{(x_2 - x_1)^2}{4D(t_2 - t_1)}},$$
(3.6)

which is known as the all-important WIENER process. Because the initial condition is specified as a δ-function, not much work is needed to find

$$\mathcal{P}_{\text{rw}}(x,t) = \frac{1}{\sqrt{4\pi Dt}} e^{-\frac{(x-x_0)^2}{4Dt}}.$$
(3.7)

So that is trivial, but only because P1|<sup>1</sup> (x2, t2|x1, t1) was given for *all* times t<sup>1</sup> < t2. In the previous example, only a single step t<sup>2</sup> − t<sup>1</sup> = 1 was specified. Assuming some

<sup>1</sup> I will call this object a transition matrix in the following, because considering R d2 as a sum over all elements renders Eq. (2.21) a matrix equation.

sort of "conservation of effort", one finds the real work hidden in the statement that P1|<sup>1</sup> (x2, t2|x1, t1) given in Eq. (3.6) obeys the CHAPMAN-KOLMOGOROV equation.

> **Exercise 3:** *Show that Eq. (3.6) obeys the* CHAPMAN*-*KOLMOGOROV *equation Eq. (2.21).*

## **3.3 Master equation approach**

The CHAPMAN-KOLMOGOROV equation is an integral equation that defines how the PDF of the process evolves in time. If the transition matrix P1|<sup>1</sup> (x2, t2|x1, t1) is given for all times, then deriving the distribution for any time is usually straight forward. In Section 3.1 we dealt with the situation that the evolution was only known for a single time step.

In continuum time this corresponds to knowing the transition *rates* at any moment in time. We rewrite Eq. (2.21) for homogeneous processes with T(x2|x1; t<sup>2</sup> − t1) = P1|<sup>1</sup> (x2, t2|x1, t1):

$$T(x_3|x_1;\tau+\tau') = \int dx_2 T(x_3|x_2;\tau')T(x_2|x_1;\tau)$$
(3.8)

where τ = t<sup>2</sup> − t<sup>1</sup> and τ ′ = t<sup>3</sup> − t2. Differentiating with respect to τ ′ and taking the limit τ ′ <sup>→</sup> 0 gives

$$\partial_{\tau} T(x_3 | x_1; \tau) = \int dx_2 \left( -a_0(x_2) \delta(x_3 - x_2) + W(x_3 | x_2) \right) T(x_2 | x_1; \tau) 
= \int dx_2 W(x_3 | x_2) T(x_2 | x_1; \tau) - a_0(x_3) T(x_3 | x_1; \tau) \quad (3.9)$$

where limτ→<sup>0</sup> ∂τT(x3|x2; τ) = −a0(x2)δ(x3−x2)+W(x3|x2) has been used, where W(x3|x2) is thought to not explicitly depend on time (we are dealing with a homogeneous process after all). The choice of that particular form is motivated by the following expansion for small times τ:

$$T(x_3|x_2;\tau) = (1 - a_0(x_2)\tau)\delta(x_3 - x_2) + \tau W(x_3|x_2) + \mathcal{O}(\tau^2)$$
(3.10)

The δ-function is there to account for the rate with which the system remains unchanged. Because it must evolve into something or stay the same, the integral over x<sup>3</sup> of T(x3|x2; τ) must be 1 for all τ. Imposing this property order by order in τ and given that the leading order is R dx<sup>3</sup> δ(x<sup>3</sup> − x2) = 1, means that

$$a_0(x_2) = \int dx_3 W(x_3|x_2)$$
 (3.11)

and therefore produces the so-called **master equation**

$$\partial_{\tau} T(x_3|x_1;\tau) = \int \! dx_2 \, \left( W(x_3|x_2) T(x_2|x_1;\tau) - W(x_2|x_3) T(x_3|x_1;\tau) \right) \, , \tag{3.12}$$

where we used a0(x3) = R dx<sup>2</sup> W(x2|x3) (note that W is time-independent and it does not matter whether x<sup>2</sup> is associated with an earlier time that x3; both are just dummy variables). If the PDF is known at the fixed time t1, one can multiply by P<sup>1</sup> (x1, t1) and integrate over 1:

$$\partial_{\tau} \mathcal{P}_{1}(x_{3}, \tau) = \int dx_{2} \left( W(x_{3}|x_{2}) \mathcal{P}_{1}(x_{2}, \tau) - W(x_{2}|x_{3}) \mathcal{P}_{1}(x_{3}, \tau) \right) , \qquad (3.13)$$

which is slightly misleading, suggesting that the master equation is only about determining the PDF at later times given the PDF at an initial time t1. Instead the master equation is an integro-differential equation for the transition probabilities given *any* initial state.

For discrete states n, the last expression has a particularly appealing form. Write P<sup>n</sup> (t) for the probability to be in n at time t and one has

$$\partial_{t} \mathcal{P}_{n}(t) = \sum_{n'} W(n|n') \mathcal{P}_{n'}(t) - W(n'|n) \mathcal{P}_{n}(t)$$
(3.14)

which are in fact just gain and loss terms for the probability to be in state n. Notice that W(n|n) cancels. Defining the matrix W as

$$W_{nn'} = W(n|n') - \delta_{nn'} \sum_{n''} W(n''|n)$$
 (3.15)

one can rewrite Eq. (3.14) as

$$\partial_t \mathbf{p}(t) = \mathbf{W}_{nn'} \mathbf{p}(t) \tag{3.16}$$

where the vector **p**(t) has entries according to P<sup>n</sup> (t). The formal solution of this expression is just **p**(t) = exp (tWnn′) **p**(0).

### **3.4 FOKKER-PLANCK equation**

The FOKKER-PLANCK equation is a particular type of master equation. As long as one is not concerned with discrete states, the above general master equation Eq. (3.12) and the expansion it is based on Eq. (3.10) might look slightly discomforting. For small time differences, the transition matrix should and indeed does collapse to a δ-function. But for finite time W mixes in and one might wonder what that object actually describes. It is transition rate, so that T is a probability again, but if the transitions take place at that rate in *every* instant, how come the transition ever collapses to a δ-function.

The answer to this is of course the time span τ which must be multiplied on the transition rate. What is, however, really unsettling is the fact that Eq. (3.10) states that for short times, the system might remain at *exactly* the same state with finite probability. How can that be possible in a stochastic process, supposedly operating at every instant in time? It cannot and in fact W(x3|x2) will cancel the term a0(x2)δ(x<sup>3</sup> − x2) (giving rise to the negative term in Eq. (3.12)) as we will see in the following, Eq. (3.19).

In the following we write the transition matrix W(x ′ |x) as w(x, −r) with r = x − x ′ , which gives for Eq. (3.13)

$$\partial_{\tau} \mathcal{P}_{1}(x_{3}, \tau) = \int dx_{2} \left( w(x_{2}, x_{3} - x_{2}) \mathcal{P}_{1}(x_{2}, \tau) - w(x_{3}, x_{2} - x_{3}) \mathcal{P}_{1}(x_{3}, \tau) \right) \\
= \int dr \left( w(x_{3} - r, r) \mathcal{P}_{1}(x_{3} - r, \tau) - w(x_{3}, -r) \mathcal{P}_{1}(x_{3}, \tau) \right) \quad (3.17)$$

where r = x<sup>3</sup> − x2. Next we assume that w(x, r) is sharply peaked around r = 0 and varies only slowly in x and that P<sup>1</sup> (x, τ) is also varying slowly in x. Expanding w(x<sup>3</sup> − r, r)P<sup>1</sup> (x<sup>3</sup> − r, τ) about r = 0 produces

$$w(x_{3} - r, r)\mathcal{P}_{1}(x_{3} - r, \tau) = w(x_{3}, r)\mathcal{P}_{1}(x_{3}, \tau) - r\partial_{x}(w(x_{3}, r)\mathcal{P}_{1}(x_{3}, \tau)) + \frac{1}{2}r^{2}\partial_{x}^{2}(w(x_{3}, r)\mathcal{P}_{1}(x_{3}, \tau)) + \mathcal{O}(r^{3})$$
(3.18)

and keeping only terms up to second order in r then gives

$$\begin{split} \partial_{\tau} \mathcal{P}_{1} \left( x_{3}, \tau \right) &= \int \! dr \, \left( w(x_{3}, r) \mathcal{P}_{1} \left( x_{3}, \tau \right) - r \partial_{x} \left( w(x_{3}, r) \mathcal{P}_{1} \left( x_{3}, \tau \right) \right) \\ &+ \frac{1}{2} r^{2} \partial_{x}^{2} \left( w(x_{3}, r) \mathcal{P}_{1} \left( x_{3}, \tau \right) \right) - w(x_{3}, -r) \mathcal{P}_{1} \left( x_{3}, \tau \right) \bigg) \end{split} \tag{3.19}$$

The first and the last term cancel and the integral runs over r, so that the factors P<sup>1</sup> (x3, τ) can be taken outside the integrals. Defining

$$A(x) = \int dr \, rw(x, r) \tag{3.20a}$$

$$B(x) = \int dr r^2 w(x, r)$$
 (3.20b)

which are, effectively, the first and second moments of the displacement r we arrive at the FOKKER-PLANCK equation:

$$\partial_{\tau} \mathcal{P}_{1}\left(x,\tau\right) = -\partial_{x}\left(A(x)\mathcal{P}_{1}\left(x,\tau\right)\right) + \frac{1}{2}\partial_{x}^{2}\left(B(x)\mathcal{P}_{1}\left(x,\tau\right)\right) , \tag{3.21}$$

which is an equation of motion for the entire PDF of the observable, rather than for the observable itself.

The two unknown functions can be related to the time-evolution of the first and the second cumulant. In particular, we note that R dx ∂τP<sup>1</sup> (x, τ) = 0 as surface terms vanish and

$$\partial_{t}\left\langle x\right\rangle =\partial_{\tau}\int\!\!dx\,x\mathcal{P}_{1}\left(x,\tau\right)=-\int\!\!dx\,x\partial_{x}\left(A(x)\mathcal{P}_{1}\left(x,\tau\right)\right)+\frac{1}{2}\int\!\!dx\,x\partial_{x}^{2}\left(B(x)\mathcal{P}_{1}\left(x,\tau\right)\right)\tag{3.22}$$

where the first integral gives R dx A(x)P<sup>1</sup> (x, τ) = hA(x)i after an integration by parts and the second  $\int\!dx\, \vartheta_x\left(B(x)\mathcal{P}_1\left(x,\tau\right)\right)=0.$  Therefore

$$\partial_{t} \langle \mathbf{x} \rangle = \langle \mathbf{A}(\mathbf{x}) \rangle \tag{3.23}$$

## **Chapter 4**

# **LANGEVIN equations**

It is generally accepted that equilibrium thermodynamics is "solved", while nonequilibrium thermodynamics lacks a central formalism a la M ` AXWELL-BOLTZMANN. To state it so strongly is an exaggeration: Equilibrium thermodynamics still contains many puzzles and the MAXWELL-BOLTZMANN formalism may not always be ideal to address certain issues. While there might be reason to be a bit more pessimistic about the state of affairs in equilibrium, there are certainly many reasons to be a bit more optimistic about non-equilibrium. Many different approaches exist in parallel and it is not always easy to translate between them or formulate the problem in a way that suits any of the methods. But in principle, methods are available ranging from LANGEVIN equations over master equations and FOKKER-PLANCK equations to the JANSSEN-DE DOMINICIS response functional. The following chapters discuss some of these methods.

LANGEVIN equations are stochastic partial differential equations which are in wide use within the physics community. They suffer from a number of mathematical shortcomings, so that there are less popular among mathematicians, who generally prefer integral formulations of the problems. However, in many physical situations, the LANGEVIN equation is the most direct way to describe the phenomenon.

### **4.1 Random walk**

A LANGEVIN equation is an equation of motion, usually first order in time. It describes the time evolution of an observable, rather than the time evolution of a PDF of that observable. The observable can be a function (for example an interface that evolves in time), but for simplicity we consider the scalar situation of a particle under the influence of random displacements, also known as BROWNian motion. If the position at time t is x(t) then its temporal evolution is given by the LANGEVIN equation<sup>1</sup>

$$\dot{\mathbf{x}}(\mathbf{t}) = \mathbf{\eta}(\mathbf{t}) \tag{4.1}$$

where η(t) is a noise and therefore a rather peculiar mathematical object. To define it, h·i is interpreted as averaging over all realisations of that noise, and so the **noise-correlator** is given by

$$\langle \eta(t)\eta(t')\rangle = 2\Gamma^2\delta(t-t')$$
 (4.2)

Since the FOURIER transform of that correlator is a constant, *i.e.* every mode k is present with equal strength, it is known as **white noise**. In many applications, it is completely sufficient to specify only the two point correlator of the noise, rather than its full distribution.

Notice that 2Γ 2 is the amplitude of the δ-function; the noise has *infinite* variance. For many purposes it is enough to specify only the correlator, however, the first moment is virtually always set to 0, while higher correlation functions are usually fixed by declaring that the noise is GAUSSian so that higher correlations are given by WICK's theorem.<sup>2</sup> While any finite integral over η is like the sum over infinitely many random variables and therefore subject to the central limit theorem (*i.e.* the sum is essentially GAUSSian), the noise itself does not need to be GAUSSian, P ([η(t)]) ∝ exp − 4Γ 2 R dt η(t) 2 (see Eq. (5.15)). As a matter of convenience the probability of η at any point should be an exponential, so that the product measure (different point in time are uncorrelated) is an exponential of the sum or rather an integral over different points. For example, P ([η(t)]) ∝ exp − 1 4Γ 2 R dt η(t) 4 works as well, but correlators are now (without WICK) *very* difficult to calculate. It is worth noting that the probability density of a particular realisation of GAUSSian noise depends on the total square displacement, not on its sum or integral. The latter is a sum of independent random variables and therefore always GAUSSian (even when based on η(t) 4 ). In most physical situations, coarse graining amounts to averaging over the noise, which renders any noise GAUSSian.

The position x(t) in the equation of motion Eq. (4.1) is to be considered a functional of η(t). In fact, we can simply integrate<sup>3</sup> and find

$$x(t) = x_0 + \int_{t_0}^{t} dt' \eta(t')$$
 (4.3)

<sup>1</sup>Notice that we traded the deterministic equation of motion for the PDF against a stochastic equation for the observable.

<sup>2</sup> Is it possible to show that a process described by the LANGEVIN equation is non-MARKOVian if the noise is not δ-correlated? Adding observables is not allowed (such as using an O-U process to generate correlated noise and use that to drive another O-U process, and then include both process in a joint observable, which of course would still be MARKOVian, even with the second being subject to correlated noise). Yes! See Nico van Kampen, Braz. J. Phys, **28**, 90 (1998).

<sup>3</sup>Very often it is not that simple and the actual rules of evaluation of the right hand side, in particular if there are terms in x(t) whose instantaneous value depends on the noise at the same instant in time, are crucial.

implying x<sup>0</sup> = x(t0) Although the entire history of x(t) is fixed given η(t) and its value at *any* point in time, one usually sets t<sup>0</sup> = 0 and considers only t > 0. The mean position is

$$\langle \mathbf{x}(\mathbf{t}) \rangle = \langle \mathbf{x}_0 \rangle + \left\langle \int_{\mathbf{t}_0}^{\mathbf{t}} d\mathbf{t}' \eta(\mathbf{t}') \right\rangle = \mathbf{x}_0$$
 (4.4)

where we have used hη(t ′ )i = 0. The correlation function hx(t1)x(t2)i now is

$$\begin{split} \langle x(t_1)x(t_2)\rangle &= x_0^2 + \left\langle \int_{t_0}^{t_1} \! dt_1' \, \int_{t_0}^{t_2} \! dt_2' \, \eta(t_1') \eta(t_2') \right\rangle = x_0^2 + \int_{t_0}^{t_1} \! dt_1' \, \int_{t_0}^{t_2} \! dt_2' \, \left\langle \eta(t_1') \eta(t_2') \right\rangle \\ &= x_0^2 + \int_{t_0}^{t_1} \! dt_1' \, \int_{t_0}^{t_2} \! dt_2' \, 2\Gamma^2 \delta(t_1' - t_2') \quad (4.5) \end{split}$$

To evaluate this integral we specify t<sup>2</sup> > t1, so that the resulting δ-function can be integrated over t ′ 2 and is guaranteed to contribute for all t ′ 1 . Performing the integration the other way around is more complicated because for all t ′ <sup>2</sup> > t<sup>1</sup> the integral over t ′ <sup>1</sup> would not contribute. We therefore have

$$\langle x(t_1)x(t_2)\rangle = x_0^2 + 2\Gamma^2 \min(t_1, t_2)$$
 (4.6)

Choosing t<sup>1</sup> = t<sup>2</sup> we note that the variance increases linearly in time,

$$\langle x(t)^2 \rangle_c = 2\Gamma^2 t$$
 (4.7)

The combination

$$\langle x(t_1)x(t_2)\rangle - \langle x(t_1)\rangle \langle x(t_2)\rangle = \langle (x(t_1) - \langle x(t_1)\rangle) (x(t_2) - \langle x(t_2)\rangle)\rangle \tag{4.8}$$

is known as the **two-time correlation function**, sometimes written just as hx(t1)x(t2)i<sup>c</sup> (notice the subscript c). In the present case

$$\langle x(t_1)x(t_2)\rangle - \langle x(t_1)\rangle \langle x(t_2)\rangle = 2\Gamma^2 \min(t_1, t_2)$$
(4.9)

so that the diffusion constant of the random walk is given by D = Γ 2 (see the remark at the end of Section 1.5.

#### **Exercise 4:** *Verify Eq. (4.8).*

All higher cumulants of the noise vanish (because the noise is GAUSSian) and consequently all higher cumulants of x(t) vanish as well. The GAUSSian noise therefore generates a GAUSSIANian position x(t), but its variance is linearly increasing in time. This is the same feature as in the central limit theorem: The observable y(t) = x(t)/ √ t has a constant variance equal to that of the noise, *i.e.* rescaling space by <sup>√</sup> t keeps a random walker confined.

### **4.2 ORNSTEIN-UHLENBECK process**

The second process to be discussed in terms of a LANGEVIN equation is of fundamental importance: It is the *only* MARKOVian, stationary, GAUSSian process. Or to put it more clearly: Every process, which is MARKOVian, stationary and GAUSSian is (by DOBB's theorem) the ORNSTEIN-UHLENBECK process.

Its stationarity is somehow "enforced" by specifying the right initial distribution. The process converges to the same PDF for any initial condition. By picking this asymptotic PDF as the initial PDF of the process implies that it will not change over time.

The LANGEVIN equation for the ORNSTEIN-UHLENBECK process is (with any initial condition)

$$\dot{x}(t) = \eta(t) - \gamma x(t) \tag{4.10}$$

The new term compared Eq. (4.1) is the "pull-back" term −γx(t). Whenever x(t) strays away too far from the origin, its average velocity points back to the origin if γ > 0, because ˙ <sup>h</sup>xi(t) = −<sup>γ</sup> <sup>h</sup>xi(t), so that

$$\langle \mathbf{x} \rangle (\mathbf{t}; \mathbf{x}_0) = \mathbf{x}_0 e^{-\gamma \mathbf{t}} \tag{4.11}$$

with x<sup>0</sup> = x(t = 0) fixed.<sup>4</sup> The complete ORNSTEIN-UHLENBECK process includes a PDF of those,

$$\mathcal{P}_{\text{OU}}(\mathbf{x}_0) = \sqrt{\frac{\gamma}{2\pi\Gamma^2}} e^{-\frac{\mathbf{x}_0^2 \gamma}{2\Gamma^2}} \tag{4.12}$$

and by including that into the averaging one has immediately (by symmetry) hxi(t) = 0.

To calculate higher moments, it is worthwhile writing down the formal solution of Eq. (4.10):

$$x(t;x_0) = x_0 e^{-\gamma t} + \int_0^t dt' \, \eta(t') e^{-\gamma(t-t')}$$
(4.13)

Taking the ensemble average reproduces Eq. (4.11), while the correlation function becomes

$$\left\langle x(t_1)x(t_2)\right\rangle(x_0) = x_0^2 e^{-\gamma(t_1+t_2)} + 2\Gamma^2 \int_0^{t_1} \! dt_1' \int_0^{t_2} \! dt_2' \, \delta(t_1'-t_2') e^{-\gamma((t_1+t_2)-(t_1'+t_2'))} \quad (4.14)$$

We recognise the first term on the right as x 2 0 exp (−γ(t<sup>1</sup> + t2)) = hxi(t1; x0)hxi(t2; x0).

Again, we choose t<sup>2</sup> > t1, so that the integration over t ′ 2 can be done immediately, leaving essentially only the integral Rt<sup>1</sup> 0 dt ′ 1 exp 2γt′ 1 = (2γ) −1 (exp (2γt1)−1) and there-

<sup>4</sup>Notice the notation: The parameters (t; x0) are outside the average, indicating that the average itself depends on it. The time t could obviously also stand inside the average, because averaging over the position at a certain time, is just the same as the position as a function of time. But we will sometimes average over x<sup>0</sup> as well, so we want to distinguish between the situation where x<sup>0</sup> is a parameter (standing outside) and being averaged over as well (inside). Of course, the meaning of h·i averaging over x<sup>0</sup> or not actually changes in the two situations.

fore

$$\left\langle x(t_1)x(t_2)\right\rangle(x_0) = x_0^2 e^{-\gamma(t_1+t_2)} + \frac{\Gamma^2}{\gamma} \left( e^{-\gamma(t_2-t_1)} - e^{-\gamma(t_2+t_1)} \right) \tag{4.15}$$

so that the two point correlation function for fixed x<sup>0</sup> becomes

$$\left\langle x(t_1)x(t_2)\right\rangle(x_0) - \left\langle x\right\rangle(t_1;x_0)\left\langle x\right\rangle(t_2;x_0) = \frac{\Gamma^2}{\gamma}\left(e^{-\gamma(t_2-t_1)} - e^{-\gamma(t_2+t_1)}\right) \tag{4.16}$$

Choosing again t<sup>1</sup> = t<sup>2</sup> = t gives a variance of the position that increases exponentially slowly in time (compare to Eq. (4.7)), converging to Γ <sup>2</sup>/γ:

$$\langle \mathbf{x}(\mathsf{t}; \mathbf{x}_0) \mathbf{x}(\mathsf{t}; \mathbf{x}_0) \rangle - \langle \mathbf{x} \rangle (\mathsf{t}; \mathbf{x}_0) \langle \mathbf{x} \rangle (\mathsf{t}; \mathbf{x}_0) = \frac{\Gamma^2}{\gamma} \left( 1 - e^{-2\gamma \mathsf{t}} \right) \tag{4.17}$$

Note: If we take the limit γ → 0 of this expression or more generally Eq. (4.16), then we should obtain the two-point correlation function of the random walker studied in Section 4.1. In fact

$$\lim_{\gamma \to 0} \frac{\Gamma^2}{\gamma} \left( e^{-\gamma (t_2 - t_1)} - e^{-\gamma (t_2 + t_1)} \right) = 2\Gamma^2 t_1 \tag{4.18}$$

exactly the same as Eq. (4.9) with t<sup>1</sup> 6 t2.

Averaging over the initial condition is a bit dangerous:<sup>5</sup> Wherever there is a h·i, we could just integrate over x<sup>0</sup> weighted by POU (x0). That way, h·i includes the averaging over x0. However, when we replaced x 2 0 exp (−γ(t<sup>1</sup> + t2)) we used hxi(t; x0) = x<sup>0</sup> exp (−γt). When averaging over x<sup>0</sup> we have hxi(t; x0) = 0 and we cannot make that substitution. So, for the "real ORNSTEIN-UHLENBECK process" (including the averaging over x0), we have hxi(t) = 0 and what remains is the average over Eq. (4.15):

$$\langle x(t_1)x(t_2)\rangle - \langle x\rangle (t_1) \langle x\rangle (t_1) =$$

$$\int dx_0 \mathcal{P}_{OU}(x_0) \left\{ x_0^2 e^{-\gamma(t_1 + t_2)} + \frac{\Gamma^2}{\gamma} \left( e^{-\gamma(t_2 - t_1)} - e^{-\gamma(t_2 + t_1)} \right) \right\}$$
 (4.19)

The only term that is actually affected by that averaging is the first term on the right, proportional to x 2 0 , but from Eq. (4.12) we know it contributes Γ 2γ −1 , so the terms in exp (−γ(t<sup>1</sup> + t2)) cancel and all what is left of the correlation function is

$$\langle \mathbf{x}(\mathsf{t}_1)\mathbf{x}(\mathsf{t}_2)\rangle - \langle \mathbf{x}\rangle \left(\mathsf{t}_1\right) \langle \mathbf{x}\rangle \left(\mathsf{t}_1\right) = \frac{\Gamma^2}{\gamma} e^{-\gamma(\mathsf{t}_2 - \mathsf{t}_1)} \tag{4.20}$$

which is in fact stationary, because it depends only on the relative time, not the absolute. The same applies to higher moments and similar to Section 4.1, all higher cumulants van-

<sup>5</sup>The initial distribution is chosen to be the asymptotic distribution, so the correlation function should depend only on time differences after taking the average over x0. Yet, there is no way to get rid of the exp (−γ(t<sup>2</sup> + t1)) in Eq. (4.16) by averaging over x0. The problem is that we have subtracted the average position x<sup>0</sup> exp (−γt) *before* we have taken the average over x0. If we average na¨ıvely over Eq. (4.16) using POU (x0) we would effectively confuse the average of the square of x<sup>0</sup> with the square of its average.

ish, meaning that the PDF of x(t) is GAUSSian. However, this time the variance remains constant, Γ <sup>2</sup>/γ, and the average vanishes – in fact, the PDF of x(t) equals that of x<sup>0</sup> for all times.

An interesting question to follow up is how LANGEVIN equations with GAUSSian, additive noise can ever produce something non-GAUSSian. The only way to break free from the central limit theorem is through algebraic correlations, which have to be generated in the presence of the noise by the propagator (in the PDE sense, the solution of the LANGEVIN equation without noise, rather than in the field theoretic sense, the solution of the linear part of the LANGEVIN equation).

It will turn out that purely relaxational LANGEVIN equations (with the RHS derived from a HAMILTONian) have a stationary distribution given by the HAMILTONian. These models are "out of equilibrium", not "far from equilibrium". As long as φ is only time dependent (mean field theorey of model A, for instance), the resulting PDF can be read off from the HAMILTONian immediately. By choosing non-linear terms in the LANGEVIN equation, the PDF can be made arbitrarily non-GAUSSIAN. To stress that, such non-GAUSSIAN behaviour derived from a GAUSSIAN noise can only be produced by algebraic correlations.<sup>6</sup>

If φ is space dependent and there is interaction in space (as in model A), then the coupling γ needs to be tuned to a very special value (corresponding to the critical temperature), not necessarily to 0 in order to produce non-GAUSSIAN behaviour in the large time and space limit. Again, the stationary PDF is given by the HAMILTONian, but it is not immediately obvious what long range and time behaviour this HAMILTONian produces. In fact, that latter question is subject of static critical phenomena.

<sup>6</sup> It would be wonderful to find an example for that, an exact solution or so.

## **Chapter 5**

# **Critical dynamics**

Dynamical, *i.e.* time-dependent behaviour can be obtained in equilibrium (*e.g.* the two point correlation function in the ideal gas), in non-equilibrium but near equilibrium (usually meaning relaxation to the equilibrium, *e.g.* model A, maybe best termed "out of equilibrium" or "near equilibrium") or far from equilibrium where a constant flux prevents detailed balance. In this section, some general features of stochastic dynamics and dynamic scaling are presented. Critical dynamics generally are some time-dependent phenomena that display critical behaviour, *i.e.* algebraic decay of correlations at a critical point. The most common and probably the most convenient form to describe these systems is in terms of LANGEVIN equations, as introduced earlier.

Instead of considering the stationary state, one can define an "evolution rule" and ask how the system's features change in time, for example, recover after a change in the external field. The time is a new parameter and enters the above scaling assumption just like any other parameter

$$f(\tau, h, t) = \lambda^{-d} f(\tau \lambda^{y_t}, h \lambda^{y_h}, t \lambda^{-z})$$
(5.1)

Differentiating with respect to h and evaluating at h = 0 and τ = 0 gives

$$m(0,0,t) = \lambda^{y_h - d} m(0,0,t\lambda^{-z})$$
 (5.2)

where we have used ∂hf = −m. Using y<sup>h</sup> − d = −β/ν and tλ−<sup>z</sup> = 1 we have

$$m(0,0,t) = t^{-\frac{\beta}{\nu z}} m(0,0,1)$$
 (5.3)

This is a typical example for dynamical scaling behaviour: At the critical point, after having taken the thermodynamic limit, the system relaxes algebraically. Eq. (5.3) can be used to determine critical exponents. The system is prepared in a configuration away from equilibrium and over time it relaxes back to it. The only subtlety is that the single configuration the system is prepared into says very little about whether or not the system is in equilibrium. One has to repeat the procedure over and over with initial configurations the ensemble of which is not the equilibrium ensemble.

The critical exponent z depends on the choice of the dynamics. In ferromagnetic models, GLAUBER dynamics is a typical choice. The exponent z is the "anomalous dimension" of the time and so the correlation time when simulating a ferromagnetic model diverges like L <sup>z</sup> at the critical point. In order to determine good estimates of static quantities, correlations should be kept to a minimum and therefore evolution strategies are employed which have a dynamical exponent z close to 0. Cluster algorithms (SWENDSEN-WANG or WOLFF) perform particularly well in that respect.

In Section 5.4 various variations of the dynamics for φ<sup>4</sup> theories, such as the ISING model will be discussed, each characterised by its particular dynamical exponent.

### **5.1 From HAMILTONian to LANGEVIN equation and back**

*A priori* a model studied in equilibrium critical phenomena does not have a dynamical updating rule associated with it. Say we are concerned with φ<sup>4</sup> theory, *i.e.* the Hamiltonian is

$$\mathcal{H}[\phi] = \int d^d x \, \frac{1}{2} \left( \nabla \phi \right)^2 + \frac{1}{2} r \phi^2 + \frac{u}{4!} \phi^4 + h(x) \phi(x) \tag{5.4}$$

which is a functional of the order parameter field φ(**x**). The external, local field is represented by h(x). A na¨ıve relaxation of that field minimises that Hamiltonian,

$$\dot{\Phi} = -D \frac{\delta \mathcal{H}}{\delta \Phi} \tag{5.5}$$

where <sup>δ</sup><sup>H</sup> δφ is the functional derivative of the HAMILTONian with respect to the field φ and D is a coefficient effectively setting the time scale, the **relaxation rate**. If φ minimises the HAMILTONian, then a positive perturbation will lead to a positive "slope", so that the response is negative and vice versa. For the φ<sup>4</sup> HAMILTONian the equation of motion therefore is

$$\dot{\Phi} = D(\nabla^2 \Phi - r\Phi + \frac{u}{6}\Phi^3 + h) \tag{5.6}$$

where we have used

$$\frac{\delta}{\delta \phi(\mathbf{x}')} \left( \nabla \phi(\mathbf{x}) \right)^2 = -2\nabla^2 \phi(\mathbf{x}) \delta(\mathbf{x} - \mathbf{x}') . \tag{5.7}$$

Eq. (5.5) describes a deterministic relaxation. To account for the noise present in a thermodynamic system due to the heat-bath (one might wonder where the noise is coming from in the bath), we add a noise term η(**x**, t) and arrive at

$$\dot{\phi}(\mathbf{x},t) = D\left(\nabla^2 \phi(\mathbf{x},t) - r\phi(\mathbf{x},t) + \frac{u}{6}\phi(\mathbf{x},t)^3 + h(\mathbf{x},t)\right) + \eta(\mathbf{x},t)$$
(5.8)

5.2. THE PDF OF  $\eta$  39

This time, the noise has correlator

$$\langle \eta(\mathbf{x}, \mathbf{t}) \eta(\mathbf{x}', \mathbf{t}') \rangle = 2\Gamma^2 \delta(\mathbf{t} - \mathbf{t}') \delta(\mathbf{x} - \mathbf{x}') , \qquad (5.9)$$

compare to Eq. (4.2).

Was it not for the non-linear term  $(u/6)\phi(x,t)^3$ , the formal solution of this LANGEVIN could be written down using a GREEN function approach.

Eq. (5.8) is also known as model A or GLAUBER dynamics and will be discussed in a wider context in Section 5.4. For the remainder of the present section, we discuss the features of LANGEVIN equations constructed as a relaxation process towards equilibrium

$$\dot{\phi}(\mathbf{x}, t) = -D \left. \frac{\delta \mathcal{H}([\psi])}{\delta \psi(\mathbf{x})} \right|_{\phi(\mathbf{x}) = \phi(\mathbf{x}, t)} + \eta(\mathbf{x}, t)$$
 (5.10)

Note that the HAMILTONian is a functional of a field  $\psi(x)$  that depends on space only, but evaluated for one that is time-dependent as well. That is important, because, for example, a harmonic potential would be represented by  $\int d^dx' \, \psi(x')^2$ , not containing any time. Replacing  $\psi(x)$  by  $\phi(x,t)$  and differentiating functionally with respect to the latter gives

$$\frac{\delta}{\delta \phi(\mathbf{x}, t)} \int d^{d}x' \, \phi(\mathbf{x}', t')^{2} = 2\phi(\mathbf{x}, t)\delta(t - t') \tag{5.11}$$

with an undesired extra factor  $\delta(t - t')$  on the right.

**Exercise 5:** Find the formal solution of Eq. (5.8) with u=0 and  $h\equiv 0$ , and determine the correlation function  $\langle \varphi(\mathbf{x},t)\varphi(\mathbf{x}',t')\rangle - \langle \varphi(\mathbf{x},t)\rangle \, \langle \varphi(\mathbf{x}',t')\rangle$  in the limit of large times t,t' as a function of the difference  $t-t'\geqslant 0$ . Consider, in particular, r=0.

### **5.2** The PDF of η

In order to make further progress, we need to specify the PDF of  $\eta$ . We know that it is GAUSSian, has vanishing mean and a  $\delta$ -correlator. To get started, we discretise space, so that the DIRAC  $\delta$  function turn into a KRONECKER divided by the time or volume element. To ease notation, we go through the procedure only for the noise in time, Eq. (4.2), which now reads

$$\left\langle \eta_{i}\eta_{j}\right\rangle =2\Gamma^{2}\delta_{ij}\Delta t^{-1}\tag{5.12}$$

where  $\eta_i$  means  $\eta(t_i)$  at the discrete time  $t_i$ , which ticks in units of  $\Delta t$ . With the  $\eta_i$  mutually independent and having vanishing mean, a product measure seems suitable, and individual  $\eta_i$  are distributed according to

$$\mathcal{P}_{i}(\eta) = \sqrt{\frac{\Delta t}{4\pi\Gamma^{2}}} e^{-\frac{\eta^{2}\Delta t}{4\Gamma^{2}}} \tag{5.13}$$

and so

$$\mathcal{P}(\eta_1, \dots, \eta_n) = \left(\frac{\Delta t}{4\pi\Gamma^2}\right)^{n/2} e^{-\frac{\Delta t \sum_{i=1}^{n} \eta_i^2}{4\Gamma^2}}$$
 (5.14)

In order to take the continuum limit, we have to drop the normalisation,

$$\mathcal{P}\left(\left[\eta(t)\right]\right) \propto e^{-\frac{1}{4\Gamma^2} \int \! dt \, \eta(t)^2} \,. \tag{5.15}$$

Any average ober the noise can now be written as

$$\langle \cdot \rangle = \int \mathcal{D}\eta \mathcal{P}\left( [\eta(t)] \right) \cdot$$
 (5.16)

where  $\mathfrak{D}\eta$  stands for  $\prod d\eta_i$  if time is discretised again. The moment generating function of the noise is  $\langle exp \left( \int dt \, \eta h(t) \right) \rangle$  with h(t) a function of time. Completing the square gives

$$-\frac{1}{4\Gamma^2}\eta(t)^2 + \eta(t)h(t) = -\frac{1}{4\Gamma^2}\left(\eta(t) - 2\Gamma^2h(t)\right)^2 + \Gamma^2h(t)^2$$
 (5.17)

so that  $\langle exp \left( \int dt \, \eta h(t) \right) \rangle = exp \left( \int dt \, \Gamma^2 h(t)^2 \right)$ . Taking the logarithm and differentiating twice (functionally) with respect to h(t) gives the correlator

$$\frac{\delta^2}{\delta h(t)\delta h(t')} \ln \left\langle e^{\int dt \, \eta h(t)} \right\rangle = \frac{\delta^2}{\delta h(t)\delta h(t')} \int dt \, \Gamma^2 h(t)^2 = 2\Gamma^2 \delta(t - t') \tag{5.18}$$

reproducing the correlator Eq. (4.2).

The procedure can be generalised for  $\eta$  that is time and space dependent with

$$\mathcal{P}\left(\left[\eta(\textbf{x},t)\right]\right) \propto e^{-\frac{1}{4\Gamma^2}\int\!\!dtd^dx\,\eta(\textbf{x},t)^2} \tag{5.19}$$

Given a Langevin equation of the form  $\vartheta_t \varphi(x,t) = -\mathcal{F}[\varphi] + \eta(x,t)$  one can now ask for average of functionals of  $\varphi(x,t)$  which are solutions of the Langevin equation, *i.e.* themselves functionals of the noise. Because the determinant of the Jacobian  $\mathcal{D}\varphi/\mathcal{D}\eta$  turns out to be unity<sup>1</sup> one then has

$$\langle \cdot \rangle = \int \mathcal{D}\phi \exp\left(-\frac{1}{4\Gamma^2} \int dt d^d x \left[\partial_t \phi(\mathbf{x}, t) - \mathcal{F}[\phi]\right]^2\right) \cdot \tag{5.20}$$

where we have used  $\eta(\textbf{x},t) = \vartheta_t \varphi(\textbf{x},t) - \mathcal{F}[\varphi]$ . Analysing Eq. (5.10) along these lines, one chooses

$$-\mathcal{F}[\phi(\mathbf{x}, \mathbf{t})] = \left. D \frac{\delta \mathcal{H}([\psi])}{\delta \psi(\mathbf{x})} \right|_{\phi(\mathbf{x}) = \phi(\mathbf{x}, \mathbf{t})} = D \mathcal{H}'([\phi(\mathbf{x}, \mathbf{t})])$$
 (5.21)

<sup>&</sup>lt;sup>1</sup>Rather, it can be chosen to be unity. The choice comes from the fact that LANGEVIN equations with a noise that has infinite variance actually make little sense, and to render them mathematically well-defined one has to make a choice about their interpretation.

and arrives at the ONSAGER-MACHLUP functional

$$\langle \cdot \rangle = \int \mathcal{D} \varphi \exp \left( -\frac{1}{4\Gamma^2} \int \! dt' d^d x' \, \left[ \partial_t \varphi(x',t') + D \mathcal{H}'([\varphi(x',t')]) \right]^2 \right) \cdot \tag{5.22}$$

### **5.3 A FOKKER-PLANCK equation approach**

From Eq. (5.22) one can derive a FOKKER-PLANCK equation (partly from "Quantum Field Theory and Critical Phenomena" by ZINN-JUSTIN). To simplify the derivation, we will first derive the FOKKER-PLANCK equation for a space independent field φ(t). The LANGEVIN equation to be considered is

$$\dot{\phi}(t) = -D \partial_{\psi}|_{\phi(t)} \mathcal{H}(\psi) + \eta(t) , \qquad (5.23)$$

see Eq. (5.10). To ease notation, we write ∂<sup>ψ</sup> <sup>φ</sup>(t) <sup>H</sup>(ψ) = <sup>H</sup>′ (φ).

The probability that φ has the value φ<sup>0</sup> at time t is

$$\mathcal{P}_{\Phi} \left( \phi_0; \mathbf{t} \right) = \left\langle \delta(\phi(\mathbf{t}) - \phi_0) \right\rangle \tag{5.24}$$

To find the time evolution of P<sup>φ</sup> (φ0; t), we differentiate with respect to t, which gives

$$\partial_{t} \mathcal{P}_{\Phi} (\phi_{0}; t) = \partial_{t} \langle \delta(\phi(t) - \phi_{0}) \rangle$$
 (5.25a)

$$= \left\langle \dot{\Phi}(t) \frac{\partial}{\partial \Phi} \delta(\Phi(t) - \Phi_0) \right\rangle \tag{5.25b}$$

If h·i runs over η, the variable φ(t) is, via the LANGEVIN equation, after integration a functional of η. In that case, the LANGEVIN equation is implied whenever φ(t) is considered. If, on the other hand, the path integral runs over φ, one can at any time introduce a new dummy variable η(t) = ∂tφ(**x**) + DH′ ([φ(**x**)]), which produces, as we know, a JACOBian with determinant 1. However we look at it, we can always replace φ˙ (t) in Eq. (5.25b) by the LANGEVIN equation.

The term ∂φδ(φ − φ0) can be replaced by −∂φ<sup>0</sup> δ(φ − φ0), which can be taken out of the average, so that

$$\partial_{t} \mathcal{P}_{\Phi} (\phi_{0}; t) = -\partial_{\phi_{0}} \langle \left( -D\mathcal{H}'(\phi(t)) + \eta(t) \right) \delta(\phi(t) - \phi_{0}) \rangle$$
 (5.26a)

Because of the δ-function H′ can be equally evaluated at φ<sup>0</sup> and taken out of the average as well,

$$\left\langle -D\mathcal{H}'(\varphi(t))\delta(\varphi(t)-\varphi_0)\right\rangle = -D\mathcal{H}'(\varphi_0)\left\langle \delta(\varphi(t)-\varphi_0)\right\rangle = -D\mathcal{H}'(\varphi_0)\mathcal{P}_{\varphi}\left(\varphi_0;t\right) \;. \label{eq:definition} \;. \; (5.27)$$

The other term of Eq. (5.26) to be considered is hη(t)δ(φ(t) − φ0)i. Writing the average

again as a path integral over  $\eta$ , we note that

$$\begin{split} \int \mathcal{D}\eta \frac{\delta}{\delta \eta(t)} \exp\left(-\frac{1}{4\Gamma^2} \int \!\! dt' \, \eta(t')^2\right) = \\ \int \mathcal{D}\eta \left(-\frac{1}{2\Gamma^2} \eta(t)\right) \exp\left(-\frac{1}{4\Gamma^2} \int \!\! dt' \, \eta(t')^2\right) \end{split} \label{eq:delta-eq} \tag{5.28}$$

Using a functional integration by parts, one therefore obtains

$$\begin{split} \langle \eta(t) \delta(\varphi(t) - \varphi_0) \rangle &= -2\Gamma^2 \int \mathcal{D} \eta \delta(\varphi(t) - \varphi_0) \frac{\delta}{\delta \eta(t)} \exp\left(-\frac{1}{4\Gamma^2} \int \! dt' \, \eta(t')^2\right) \\ &= 2\Gamma^2 \int \mathcal{D} \eta \exp\left(-\frac{1}{4\Gamma^2} \int \! dt' \, \eta(t')^2\right) \frac{\delta}{\delta \eta(t)} \delta(\varphi(t) - \varphi_0) \\ &= 2\Gamma^2 \left\langle \frac{\delta}{\delta \eta(t)} \delta(\varphi(t) - \varphi_0) \right\rangle \quad (5.29) \end{split}$$

As mentioned above,  $\varphi(t)$  is a functional of  $\eta$  (more precisely, an integral) and one can choose

$$\frac{\delta}{\delta\eta(t)}\phi(t) = \frac{1}{2} \tag{5.30}$$

so that

$$\left\langle \frac{\delta}{\delta \eta(t)} \delta(\varphi(t) - \varphi_0) \right\rangle = -\frac{1}{2} \partial_{\varphi_0} \left\langle \delta(\varphi(t) - \varphi_0) \right\rangle = -\frac{1}{2} \partial_{\varphi_0} \mathcal{P}_{\varphi} \left( \varphi_0; t \right) \tag{5.31}$$

again turning the derivative with respect to  $\phi(t)$  of the DIRAC  $\delta$  function into a negative one with respect to  $\phi_0$ . Collecting all terms, one has the FOKKER-PLANCK equation

$$\partial_{t} \mathcal{P}_{\Phi} \left( \varphi_{0}; t \right) = \partial_{\Phi_{0}} \left( D \mathcal{H}'(\varphi_{0}) \mathcal{P}_{\Phi} \left( \varphi_{0}; t \right) \right) + \Gamma^{2} \partial_{\Phi_{0}}^{2} \mathcal{P}_{\Phi} \left( \varphi_{0}; t \right) . \tag{5.32}$$

In the stationary state  $\partial_t \mathcal{P}_{\Phi} (\phi_0; t) = 0$  and therefore

$$\partial_{\phi_0} \left( D \mathcal{H}'(\phi_0) \mathcal{P}_{\phi} \left( \phi_0; t \right) + \Gamma^2 \partial_{\phi_0} \mathcal{P}_{\phi} \left( \phi_0; t \right) \right) = 0 \tag{5.33}$$

one solution<sup>2</sup> of which is

$$\mathcal{P}_{\phi;\text{stat}}\left(\phi\right) \propto e^{-\frac{D}{\Gamma^2} \cdot \mathcal{H}\left(\phi\right)}$$
 (5.34)

This result can be extended to space dependent order parameters, so that the stationary PDF becomes the BOLTZMANN-factor

$$\mathcal{P}_{\phi:\text{stat}}\left(\left[\phi(\mathbf{x})\right]\right) \propto e^{-\frac{D}{\Gamma^2}\mathcal{H}(\left[\phi\right])},$$
(5.35)

where  $D/\Gamma^2$  can be identified with the inverse temperature  $1/(k_{\text{B}}T).$ 

 $<sup>\</sup>begin{array}{l} P_{\varphi}\left(\varphi_{0};t\right)=exp\left(-\frac{D}{\Gamma^{2}}\mathcal{H}(\varphi_{0})\right)\left(C_{2}+C_{1}\int_{0}^{\varphi_{0}}\!d\varphi\,\,exp\left(\frac{D}{\Gamma^{2}}\mathcal{H}(\varphi)\right)\right) \end{array}$ 

**Exercise 6:** Find  $\langle \varphi(\mathbf{x},t) \varphi(\mathbf{x}',t') \rangle - \langle \varphi(\mathbf{x},t) \rangle \langle \varphi(\mathbf{x}',t') \rangle$  in the stationary state, using Eq. (5.35) with the Hamiltonian Eq. (5.4) with u=0,  $h\equiv 0$  and t=t' (as we consider the stationary state, t cannot be different from t'—there is no time left). Compare the result to the previous exercise.

### 5.4 The HOHENBERG-HALPERIN models

The way we constructed the relaxational dynamics (5.5) does not prescribe the way the noise enters. That choice was made later, Eq. (5.8). HOHENBERG and HALPERIN introduced (RMP 1977) a now well-established classification of models, which differ in the way the noise is implemented as well as in the general physical features.

One model has been mentioned already, namely **model A**, also known as **GLAUBER dynamics**. It is defined by the Langevin equation

$$\dot{\phi}(\mathbf{x},t) = D\left(\nabla^2 \phi(\mathbf{x},t) - r\phi(\mathbf{x},t) + \frac{u}{6}\phi(\mathbf{x},t)^3 + h(\mathbf{x},t)\right) + \eta(\mathbf{x},t), \quad (5.36)$$

(see Eq. (5.8)) with noise correlator

$$\langle \eta(\mathbf{x}, \mathbf{t}) \eta(\mathbf{x}', \mathbf{t}') \rangle = 2\Gamma^2 \delta(\mathbf{x} - \mathbf{x}') \delta(\mathbf{t} - \mathbf{t}') . \tag{5.37}$$

It is probably the best studied, non-trivial model in non-equilibrium statistical mechanics.

The second most important model is **model B** (also known as **KAWASAKI dynamics**) has **conserved order parameter**,

$$\dot{\phi}(\mathbf{x},t) = -\nabla^2 D\left(\nabla^2 \phi(\mathbf{x},t) - r\phi(\mathbf{x},t) + \frac{u}{6}\phi(\mathbf{x},t)^3 + h(\mathbf{x},t)\right) + \zeta(\mathbf{x},t), \quad (5.38)$$

with noise  $\zeta = \nabla \eta$ , so that the entire right hand side can be written as a gradient. The integral  $\int d^d x \, \dot{\varphi}(\mathbf{x},t) = \partial_t \int d^d x \, \varphi(\mathbf{x},t)$  therefore vanishes (ignoring surface terms).

**Model C and D** introduce a conserved energy density  $\rho$  and combine that with non-conserved order parameter (model C) and conserved order parameter (model D) respectively. If the order parameter is not a scalar but higher dimensional, then its dynamics is described by **model J** and by adding an anisotropy, that turns into **model E**. Finally, model E becomes **model G** by an anti-ferromagnetic coupling constant.