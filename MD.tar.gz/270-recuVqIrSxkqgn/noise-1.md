# Average-Case to (shifted) Worst-Case Reduction for the Trace Reconstruction Problem

Ittai Rubinstein<sup>1, 2</sup>

<sup>1</sup>Blavatnik School of Computer Science, Tel-Aviv University, Tel-Aviv 69978, Israel <sup>2</sup>QEDMA Quantum Computing, Tel-Aviv, Israel

August 15, 2022

### Abstract

The insertion-deletion channel takes as input a binary string  $\mathbf{x} \in \{0,1\}^n$ , and outputs a string  $\tilde{\mathbf{x}}$  where some of the bits have been deleted and others inserted independently at random. In the trace reconstruction problem, one is given many outputs (called traces) of the insertion-deletion channel on the same input message  $\mathbf{x}$ , and asked to recover the input message.

Nazarov and Peres, and De et al [NP17, DOS17] showed that any string  $\mathbf{x}$  can be reconstructed from  $\exp(O(n^{1/3}))$  traces. Holden et al [HPPZ18] adapt the techniques used to prove this upper bound, to an algorithm for the average-case trace reconstruction with a sample complexity of  $\exp(O(\log^{1/3} n))$ . However, it is not clear how to apply their techniques more generally and in particular for the recent worst-case upper bound of  $\exp(\widetilde{O}(n^{1/5}))$  shown by Chase [Cha21b] for the deletion-channel.

We prove a general reduction from the average-case to smaller instances of a problem similar to worst-case. Using this reduction and a generalization of Chase's bound, we construct an improved average-case algorithm with a sample complexity of  $\exp(\widetilde{O}(\log^{1/5} n))$ . Additionally, we show that Chase's upper-bound holds for the insertion-deletion channel as well.

# 1 Introduction

The insertion-deletion channel with parameters  $0 \le q, q' < 1$  takes as input a string  $\mathbf{x} \in \{0, 1\}^n$ . For each j,  $G_j$  random uniform and independent bits are inserted before the jth bit of  $\mathbf{x}$ , where the random variables  $G_j \ge 0$  are i.i.d. geometrically distributed with parameter q'. Then, each bit of the message is deleted independently with probability q. The output string  $\widetilde{\mathbf{x}}$  is called a trace.

The trace reconstruction problem asks the following question: how many traces are necessary to reconstruct an unknown string  $\mathbf{x}$ ?

The main motivation for studying this problem comes from computational biology, where one often tries to align several DNA sequences to a common ancestor. It has been extensively researched since the early 2000's [BKKM04]. Over the past few years, the trace reconstruction problem has received an increased focus, spawning many new versions, such as the coded trace reconstruction [CGMR20], the approximate trace reconstruction [CP21, CDL<sup>+</sup>22] and the population recovery and trace reconstruction problems [BCSS19].

In this paper we will focus on the two main versions introduced by Batu et al [BKKM04], called the worst-case and the average-case<sup>1</sup>. In the worst-case, the message  $\mathbf{x}$  is adversarially chosen, so the method used to reconstruct it must work for all strings  $\mathbf{x} \in \{0,1\}^n$ . In the average-case,  $\mathbf{x}$  is a random string of bits and the reconstruction only needs to succeed with high probability over the choice of  $\mathbf{x}$ .

There appears to be an exponential gap between these cases. Indeed, McGregor et al [MPV14] showed that if h(n) traces are necessary for the worst-case trace reconstruction, then at least  $h(\log n)$  are needed for the average-case (and under some conditions  $h(\log n)\log n$ ). The best known lower bounds on the average-case have followed a similar pattern with Chase proving a lower-bound of  $n^{3/2}/poly(\log n)$  and  $\log^{5/2} n/poly(\log\log n)$  samples for the worst-case and average-case respectively [Cha21a], improving upon the previous bounds of  $n^{5/4}/poly(\log n)$  and  $\log^{9/4} n/poly(\log\log n)$  for the worst-case and average-case respectively by Holden and Lyons [HL20].

The upper bounds have also followed a similar suit. Holenstein et al [HMPW08] established an upper bound of  $\exp(\tilde{O}(n^{1/2}))$  on the sample complexity of the worst-case trace reconstruction problem. This was improved by Nazarov and Peres [NP17], and De, O'Donnell and Servedio [DOS17] who simultaneously proved that  $\exp(O(n^{1/3}))$  traces are sufficient, and later by Chase [Cha21b] who improved the bound to  $\exp(\tilde{O}(n^{1/5}))$  for deletion channels (i.e. with q'=0).

Peres and Zhai [PZ17] adapted the  $\exp(O(n^{1/3}))$  bound to the average-case, constructing an efficient algorithm for the average trace reconstruction with  $\exp(O(\log^{1/2} n))$  samples and with some limitations on the deletion probability  $(q \le 1/2 \text{ and } q' = 0)$ . This was further improved by Holden et al [HPPZ20] who reduced the sample complexity to  $\exp(O(\log^{1/3} n))$  and generalized the algorithm to work for all insertion-deletion channels.

### 1.1 An Overview of Previous Results

Our results are mainly based on an adaptation and a combination of the techniques used in Holden et al and Chase's papers [HPPZ20, Cha21b]. Here, we will give a brief overview of their methods and why it is not trivial to combine them.

#### 1.1.1 An Overview of [HPPZ20]

Holden et al present an algorithm for the average-case trace reconstruction. This algorithm reconstructs the string  $\mathbf{x}$  one bit at a time.

<span id="page-1-0"></span><sup>&</sup>lt;sup>1</sup>Sometimes also called the "random case".

In the kth iteration, an alignment procedure is run with the goal of matching an index k ′ ≈ k − C log n slightly less than k in the original message to an index τ<sup>k</sup> ′ in each of the traces. This alignment is noisy, resulting in a small random shift and occasionally a completely missed alignment.

After this alignment, the bits following each aligned index τ<sup>k</sup> ′ are viewed as a trace of the bits immediately after k ′ in the original string x.

Reconstructing the kth bit from these new traces presents several new difficulties. First, one must deal with spurious matches (cases where the alignment failed completely). Then one must deal with the fact that even in the ideal scenario, the alignments are not precise. Finally, instead of reconstructing a string of some given length log n, we reconstruct the first log n bits of a far longer string.

Holden et al then show that the complex analysis techniques used for the worst-case bounds by [\[NP17\]](#page-26-0) and [\[DOS17\]](#page-25-0) can be adapted to this new problem and to insertion-deletion channels.

Roughly speaking, these techniques work by converting a function of the traces to a polynomial that depends on the original message. This polynomial is then shown to have a sufficiently strong dependence on the kth bit of x, when evaluated at some point where it can be approximated from a sufficiently small number of traces.

# 1.1.2 An Overview of [\[Cha21b\]](#page-25-2)

The exp(O(n 1/3 )) upper-bounds on the sample complexity of the worst-case trace reconstruction and most similar bounds are shown using a mean-based algorithm – an algorithm that considers the distribution of the ith bit of the traces separately for each i [\[NP17,](#page-26-0) [DOS17\]](#page-25-0). However, these same papers also show a matching lower bound for mean-based algorithms.

In order to overcome this, Chase showed that separators which are based on highly non-linear functions of the traces (and are thus not mean-based algorithms), can be used for the worst-case trace reconstruction problem, reducing the sample complexity to exp(Oe(n 1/5 )) [\[Cha21b\]](#page-25-2). Analysing these separators requires an extension of the complex analysis used by Nazarov and Peres and by De et al to the multivariate case.

# 1.1.3 Combining these Results

The first difficulty in combining these results is the need to apply Holden et al's bit recovery procedure in a different context. This bit recovery procedure has many parameters, which were defined in [\[HPPZ20\]](#page-25-10) only for the specific case of their algorithm. While it is not exceptionally difficult to adapt it to other scenarios, it does require a long and technical proof. In order to make these techniques more accessible to future researchers, we convert them into a general reduction.

The next difficulty is that Holden et al's conversion of the bit recovery procedure to a complex analysis problem depends on the fact that they use a mean-based separator. When analysing such separators, many terms relating to the insertions of the channel cancel out. However, the main advantage of Chase's upper bound cannot be obtained using such separators.

Finally, in the complex analysis itself, one obtains a geometric sum related to the traces which can be used to estimate the values of some polynomial related to the original message x. This polynomial and a point in which to evaluate it are carefully chosen so that they will have a strong dependency on x and that the geometric summation will not be too large.

However, in the worst-case analysis, this technique is used when the summation is truncated by the length of the trace, allowing one to compute it at points where it might not converge. Because the bit recovery attempts to reconstruct the prefix of a very long string, it no longer suffices to show that this geometric series grows slowly. In fact, we need to show that it decays rapidly so that it can

be truncated. This requires many changes to the method by which the evaluation point is selected and its analysis.

### 1.2 Our Contribution

Our main contribution is an improvement of Holden et al's algorithm [HPPZ20], with a sample complexity of  $\exp(\widetilde{O}(\log^{1/5} n))$ :

<span id="page-3-1"></span>**Theorem 1.1** (Main Result). For any constant parameters  $q, q' \in [0, 1)$ , there exists M > 0, such that for any  $n \in \mathbb{N}$ , if  $\mathbf{x} \in \{0, 1\}^n$  is a bit-string where the bits are chosen uniformly and independently at random, then we can reconstruct  $\mathbf{x}$  with probability  $1 - o_n(1)$  using  $[\exp(M \log^{1/5} n \log^7 \log n)]$  traces from the insertion-deletion channel with parameters q, q'. Moreover, when q < 1/2 this can be done in  $n^{1+o(1)}$  time and when  $q \ge 1/2$ , this can be done in polynomial time.

To show this, we introduce a new version of the trace reconstruction problem similar to the worst-case, which we call the *shifted trace reconstruction* (see Definition 1). The shifted trace reconstruction problem differs from the worst-case trace reconstruction in three key ways:

First, some (o(1)) fraction of the samples may be "false samples" - adversarially chosen strings mixed into our pool of samples. These false samples arise in our reduction, because we will perform our alignment with very short substrings, so some of our alignments will come from spurious matches. However, we do not expect the addition of a sufficiently small fraction of false samples to have a significant effect on the difficulty of trace reconstruction. This is because the information-theoretically optimal separation between the traces of two possible strings  $\mathbf{x}$  and  $\mathbf{y}$  would be done using a likelihood estimation and this can be easily amended to deal with a small fraction of incorrect entries.

The second difference is that the traces are shifted (owing to the inaccuracy of our alignment procedure), in the sense that there is some  $\mathbb{N}$  valued random variable S (bounded on some interval of length  $\eta$ ), and before applying the channel to produce any single trace we will erase its first S bits. While this could potentially make the reconstruction harder, in practice the complex analysis based reconstruction techniques [NP17, DOS17, Cha21b] which are most commonly used for the worst-case, can be fairly easily adapted.

The final and largest difference is that instead of reconstructing a string  $\mathbf{x}$  of finite length n, in the shifted reconstruction, we are given traces of a very long string (which can be thought of as exponentially or infinitely long), and are asked to reconstruct the first n bits. Dealing with the longer strings requires many changes to the complex analysis techniques used for the worst-case reconstruction. Peres and Zhai and Holden et al make these adaptions to the mean-based analyses in their reconstruction algorithms [PZ17, HPPZ20] but similarly adapting Chase's construction is not trivial.

We adapt Holden et al's methods [HPPZ20], which were originally used for a specific average-case algorithm, to create a general reduction from the average-case trace reconstruction to (a smaller version of) the shifted trace reconstruction. This reduction (Theorem 1.2) can be used in order to convert additional advances on the worst-case trace reconstruction problem into efficient algorithms for the average-case, and indeed we use it to improve Holden et al's algorithm.

<span id="page-3-0"></span>**Theorem 1.2** (Average to Shifted Reduction). For any constant  $q, q' \in [0, 1)$ , and any positive  $C_1 > 0$ , there exists some positive constant  $C_2 > 0$ , such that:

For any monotone function  $\log(n) \leq h(n) \leq \sqrt{n}$  and any algorithm A that solves the shifted trace reconstruction problem with sample complexity  $\sigma(n) \leq \exp(h(n))$ , time complexity t(n), false sample rate  $\varepsilon(n) = \exp(-C_1h(n))$ , shift inaccuracy  $\eta = C_2h(n)$  and failure probability  $\delta(n) < \exp(-n)$ , A

can be transformed into an algorithm A' that solves the average-case trace reconstruction problem with probability  $1 - o_n(1)$ , time complexity  $(\max_{n' \leq C_2 \log n} \{t(n')\} + n^{o(1)})n$  and a sample complexity of  $\exp(C_2 h(C_2 \log n))$ .

**Remark 1.** Note that the assumption that  $\log(n) \leq h(n) \leq \sqrt{n}$  is not very restrictive, since we show an upper bound of  $h(n) \leq \widetilde{O}(n^{1/5})$  and the lower bound by Chase [Cha21a] implies that  $h(n) \geq 3/2 \log n$ .

This theorem also can also have an additional theoretical importance, when compared to Lemma 10 of [MPV14]. In this lemma, McGregor et al show that if f(n) traces are required for the worst-case trace reconstruction, then  $f(\log n)$  traces are required for the average-case trace reconstruction. In some sense Theorem 1.2 indicates that McGregor et al's theorem may be nearly tight, since we show that if f(n) traces suffice for the shifted trace reconstruction then  $\operatorname{poly}(f(\log n))$  traces suffice for the average-case.

Finally, we generalize Chase's upper bound (originally covering only deletion channels [Cha21b]) to the shifted trace reconstruction (Theorem 1.3) and by extension to the insertion-deletion channel. Additionally, when the deletion probability is below 1/2, we show that the worst-case trace reconstruction can be performed in  $\exp(\widetilde{O}(n^{4/5}))$  time. Formally, we show that:

<span id="page-4-0"></span>**Theorem 1.3.** For any constant  $q, q' \in [0, 1)$  and for any  $C_2 > 0$ , there exist some  $C_3 > 0$ ,  $h(n) = C_3 n^{1/5} \log^7 n$  and an algorithm A that solves the shifted trace reconstruction problem with a shift inaccuracy of  $C_2h(n)$ , a sample complexity of  $\exp(h(n))$ , and a false sample rate of  $\exp(-h(n))$ . Furthermore, when q < 1/2, the algorithm A runs in  $\exp(O(n^{4/5} \log n))$  time and if  $q \ge 1/2$ , then A runs in  $\exp(O(n))$  time.

<span id="page-4-1"></span>**Remark 2.** The shifted trace reconstruction is at least as hard as the worst-case trace reconstruction, since one can simply set S = 0 and pad both the original message  $\mathbf{x}$  with 0 bits and the traces with traces of 0 strings.

Theorems 1.2 and 1.3 directly imply Theorem 1.1. Furthermore, combining Theorem 1.3 with Remark 2 shows that  $\exp(\tilde{O}(n^{1/5}))$  samples suffice for the worst-case trace reconstruction problem for insertion-deletion channels as well.

Much of our paper will be devoted to generalizing and combining the results of Holden et al [HPPZ20] and Chase [Cha21b]. For the sake of brevity, we will henceforth refer to these papers as the HPPZ and the Chase constructions respectively. We cite their main results in Section 2.1.

### 1.3 Organization

In Section 2, we give a precise definition of the trace reconstruction and present some notation. We adapt the alignment technique of HPPZ to prove the general reduction in Section 3. Sections 4 and 5 contain the heart of our analysis, where we convert the shifted trace reconstruction problem into a complex analysis one (4) and use complex analysis techniques to solve it (5). Finally, Appendices A, B and C contain some of the more technical proofs required for Sections 3, 4 and 5 (respectively).

## <span id="page-4-2"></span>2 Preliminaries

Let  $\mathbb{N} = \{0, 1, \ldots\}$  and let  $\mathcal{S} = \{0, 1\}^{\mathbb{N}}$  denote the set of infinite sequences of zeros and ones. We denote elements  $\mathbf{x} \in \mathcal{S}$  by  $\mathbf{x} = (x_0, x_1, \ldots)$ , and denote by  $\mathbf{x}(i:j) = \mathbf{x}([i,j]) = (x_i, \ldots x_j)$ .

Fix any deletion probability  $q \in [0,1)$  and any insertion probability  $q' \in [0,1)$ . Let p = 1 - q and p' = 1 - q', and let S be some N valued distribution.

Each trace  $\tilde{\mathbf{x}}$  is constructed from the original message  $\mathbf{x}$  using the following procedure [HPPZ20, CR20]:

First, if we are producing a shifted trace, a shift s is drawn independently from the distribution S, and the string  $\mathbf{x}$  is replaced with its shift  $\theta^s(\mathbf{x}) = \mathbf{x}(s:)$  (for other versions of the problem, we set s = 0 or skip this step). Then, for each  $j \in \mathbb{N}$ , a random variable  $G_j \geq 0$  is drawn from an independent geometric distribution  $\Pr[G_j = \nu] = (q')^{\nu} p'$ . For each j,  $G_j$  independent and uniformly distributed bits are inserted before the jth bit of  $\mathbf{x}$ . Finally, each bit of the resulting message is deleted with probability q.

We will often separate the randomness of the channel which we will denote by  $\omega$  from the randomness generating the original message.

For any index j we denote by  $D_j$  the event that the jth bit  $\mathbf{x}$  was not deleted by the channel. Whenever  $D_j$  occurs, we will denote by f(j) the position within the trace to which this bit was sent (i.e. the number of bits either from  $\mathbf{x}$  or from the insertions before this index that were not deleted). If the jth bit was deleted, we define f(j) to be f(j') for the smallest  $j' \geq j$  for which  $D_{j'}$  holds.

In other words, f(j) is defined to be the index in the trace  $\tilde{\mathbf{x}}$  that corresponds to the  $\geq j$ th index in the original message  $\mathbf{x}$ . We will similarly denote by  $I_j$  the event that the jth bit of the trace originated from the original message and not an insertion, and for such indices we will denote by g(j) the index of the original message from which they are generated, and for indices which were the result of an insertion, we define g(j) by the next non-inserted index in the trace.

We will define the misalignment between the kth bit of the input message and the k'th bit of the trace to be:

$$d(k, k') = \max\{|f(k) - k'|, |g(k') - k|\}$$

<span id="page-5-0"></span>**Definition 1** (Shifted Trace Reconstruction Problem). A shifted trace reconstruction problem has the following parameters:

- Channel parameters q, q'
- Shift inaccuracy  $\eta(n)$
- Sample complexity  $\sigma(n)$
- False sample rate  $\varepsilon(n)$

It is defined as the problem of reconstructing the n+1th bit  $x_n$  of any  $\mathbf{x} \in \{0,1\}^{\mathbb{N}}$ , given  $\mathbf{x}(0:n-1)$ ,  $\sigma(n)$  samples  $\tilde{\mathbf{x}}$ , each of which is independently with probability  $\varepsilon(n)$  selected from some unknown (potentially adversarial) distribution or with probability  $1-\varepsilon(n)$  a trace of  $\theta^S(\mathbf{x})$ , where S is some  $\mathbb{N}$  valued random variable such that  $\mathrm{Supp}(S) \subseteq [a, a+\eta(n)] \subseteq [0, n-1]$  for some a.

### <span id="page-5-1"></span>2.1 The Main Results of HPPZ and Chase

**Theorem 2.1** (Theorem 1 [HPPZ20]). For  $n \in \mathbb{N}$ , let  $\mathbf{x} \in \{0,1\}^n$  be a bit-string where the bits are chosen uniformly and independently at random. Given  $q, q' \in [0,1)$ , there exists M > 0 such that for all n, we can reconstruct  $\mathbf{x}$  with probability  $1 - o_n(1)$  using  $\lceil \exp(M \log^{1/3} n) \rceil$  traces from the insertion-deletion channel with parameters q, q'. Moreover, this can be done in  $n^{1+o(1)}$  time.

**Theorem 2.2** (Theorem 2 [Cha21b]). For any deletion probability  $q \in (0,1)$  and any  $\delta > 0$ , there exists C > 0, such that any unknown string  $\mathbf{x} \in \{0,1\}^n$  can be reconstructed with probability  $1 - \delta$  from  $\exp(Cn^{1/5}\log^5 n)$  independent traces of  $\mathbf{x}$ .

# <span id="page-6-0"></span>3 Proof of Theorem 1.2

In this section, we will prove the reduction from the average trace reconstruction to the shifted trace reconstruction. The construction presented in this section requires only an adaptation of the HPPZ's methods, and our main contribution here is that we show that it can be used as a general reduction. We will cite the main relevant theorems, but where no changes to the proof are necessary, we will refer readers to HPPZ's paper [HPPZ20].

Similar to HPPZ's algorithm, our reduction will be comprised of three main ingredients:

- A Boolean test  $T(\mathbf{w}, \widetilde{\mathbf{w}})$  on pairs of bit-strings  $(\mathbf{w}, \widetilde{\mathbf{w}})$  that returns 1 if  $\widetilde{\mathbf{w}}$  is a plausible match for the output of applying the channel to  $\mathbf{w}$ .
- A two step alignment procedure comprised of a coarse and a fine alignment each of which uses the test T to obtain an estimate  $\tau^k$  for the positions in sufficiently many of the traces corresponding to the kth bit of the original message  $\mathbf{x}$ .
- A bit recovery procedure based on the target of our reduction to produce an estimate of any bit of **x** from sufficiently many aligned traces.

Finally, similar to HPPZ, throughout this section we will perform our analysis when q = q', but all of these results can be similarly generalized for any values of  $q, q' \in [0, 1)$ .

### <span id="page-6-1"></span>3.1 The Boolean Test

The Boolean test T, as defined in [HPPZ20], is designed to answer whether a string  $\tilde{\mathbf{w}}$  is likely to have originated from a trace of some string  $\mathbf{w}$ . It is controlled by two parameters  $\ell, \lambda < \sqrt{\ell}$  and works by separating both strings into subsegments of length  $\lambda$  each and comparing the average of each message on each segment. If in sufficiently many segments the averages of the messages are either both above 1/2 or both below 1/2, the test returns 1. In other words, for any constant c > 0:

$$T_{\ell,\lambda}^{c}\left(\mathbf{w},\widetilde{\mathbf{w}}\right) = \begin{cases} 1 & \text{if } \sum_{1 \leq i \leq \frac{\ell}{\lambda}} \operatorname{sign}\left(s_{i} \cdot \widetilde{s}_{i}\right) \geq c\frac{\ell}{\lambda} \\ 0 & \text{otherwise} \end{cases}$$

Where  $s_i \sum_{(i-1)\lambda < j \leq i\lambda} (2w_i - 1)$ .

HPPZ use this test with two sets of parameters. In both cases  $c = \Theta(1)$  and up to some constant factors,  $\ell, \lambda$  are either  $\Theta(\log^{5/3} n), \Theta(\log^{2/3} n)$  (for the "coarse" alignment) or  $\Theta(\log^{1/3} n), \Theta(1)$  (for the "fine" alignment) respectively.

In the general case, we will set

$$\ell = \Theta(\log^2(n)/h(\Theta(\log(n)))); \qquad \lambda = \Theta(\log(n)/h(\Theta(\log(n))))$$

for the coarse alignment and

$$\ell = \Theta(h(\log(n))); \quad \lambda = \Theta(1)$$

for the fine alignment, where h(n) is the logarithm of the number of traces needed for the target of the reduction. When h(n) is  $n^{1/3}$  (as in HPPZ's paper), we get the same parameters, and for our main result we will apply this theorem with  $h(n) = \Theta(n^{1/5} \log^7(n))$ .

Roughly speaking, the boolean test should maintain two behaviours:

• If  $\widetilde{\mathbf{w}}$  is not a trace of  $\mathbf{w}$ , the probability that T will return 1 (called a *spurious match*) should be at most  $\exp(-\Omega(\ell/\lambda))$ .

• If  $\widetilde{\mathbf{w}}$  is a trace of  $\mathbf{w}$ , the probability that T will pass (called a *true match*) will be at least  $\exp(-O(\ell/\lambda^2))$ .

Under these constraints, the probability of a true match may be very small, but when  $\lambda$  is sufficiently large, it will be much higher than the probability of a spurious match. When conditioning on a match, it will most likely be a true match.

In order to formalize this, HPPZ define a condition for the robustness of this test and a notion for the error in an alignment. They prove that almost any string is robust and that for robust strings there is a sufficiently high probability to have a true match. Furthermore, they prove that for robust and "mismatched" strings the probability of a spurious match is sufficiently low.

More formally the robustness is defined as below, where  $\theta$  is a constant as defined in HPPZ:

<span id="page-7-0"></span>**Definition 2** (Definition 3 of [HPPZ20] - Robustness). Let  $u_2 = u_1 + \lambda$  be two indices in the string x. We define the robust bias of  $x(u_1 + 1 : u_2)$  to be

$$\lambda^{-\frac{1}{2}} \sum_{\substack{t_1, t_2 \in \mathbb{N} \\ |t_1 - u_1| < \lambda/100 \\ |t_2 - u_2| < \lambda/100}} |\sum_{j=t_1}^{t_2} (2x_j - 1)|$$

We will say that  $x(u_1 + 1 : u_2)$  has a clear robust bias if its robust bias is at least 1.

Let  $\mathbf{w}$  be some string of length  $\ell$  (usually a substring of  $\mathbf{x}$ ). We will say that  $\mathbf{w}$  has a clear robust bias at scale  $\lambda$ , if when separating  $\mathbf{w}$  into blocks of length  $\lambda$  (i.e. viewing the substrings  $\mathbf{w}(u_i+1,u_{i+1})$  where  $u_i=i\lambda$ ), at least  $\theta$  fraction of them have a clear robust bias.

**Definition 3** (Definition 7 of [HPPZ20] - Mismatched strings). Let  $\mathbf{w} = \mathbf{x}(a+1:a+\ell)$  be a substring of the input and let  $\widetilde{\mathbf{w}} = \widetilde{\mathbf{x}}(b+1:b+\ell)$  be a substring of the same length taken from the trace. We say that  $\mathbf{w}$  and  $\widetilde{\mathbf{w}}$  are s-mismatched if for any  $0 \le i \le \ell$ , it holds that  $d(a+i,b+i) \ge s$ .

Heuristically, a string w which is robust in the sense of Definition 2 should be matched with any one of its traces with probability  $\exp(-O(\ell/\lambda^2))$ . This is because so long as the number of deletions doesn't drift by more than  $O(\lambda)$  from the number of insertions, we expect the proportion of 0s to 1s in each subsegment of the trace to be strongly correlated with the proportion of 0s to 1s in the parallel subsegment of the input message. HPPZ formalize this statement, proving the following lemmas:

<span id="page-7-2"></span>**Lemma 3.1** (Lemma 4 of [HPPZ20] - Most strings are robust). Let  $\boldsymbol{w}$  be a random string of length  $\ell$ . Then  $\boldsymbol{w}$  has a clear robust bias at scale  $\lambda$  w.p.  $1 - \exp(-\Omega(\ell/\lambda))$ .

<span id="page-7-1"></span>**Lemma 3.2** (Lemma 5 of [HPPZ20] - Robust strings have a true match with sufficiently high probability). For any constant  $q, q' \in [0, 1)$ , there exists some constant c > 0, so that for any  $\mathbf{w} \in \{0, 1\}^{\ell}$  which has a clear robust bias at scale  $\lambda$ , if  $\widetilde{\mathbf{w}}$  is a trace of  $\mathbf{w}$ , then the test  $T_{\ell, \lambda}^{c}(\mathbf{w}, \widetilde{\mathbf{w}}(0 : \ell - 1))$  will pass with probability at least  $\exp(-O(\ell/\lambda^{2}))$ .

HPPZ then prove the first property of the test, namely that it has very few spurious matches.

**Lemma 3.3** (Lemma 8 of [HPPZ20] - False positives are rare). Let x be a random string and suppose we sample the trace  $\tilde{x}$  from the insertion-deletion channel.

Consider two length- $\ell$  substrings  $\mathbf{w} = \mathbf{x}(a+1:a+\ell)$  and  $\widetilde{\mathbf{w}} = \widetilde{\mathbf{x}}(b+1:b+\ell)$ . For any realisation  $\omega_0$  of the randomness of the channel (which determines the map of insertions and deletions), such that  $\mathbf{w}$  and  $\widetilde{\mathbf{w}}$  are  $\lambda$ -mismatched, we have that:

$$\Pr_{\boldsymbol{x}}\left[T_{\ell,\lambda}\left(\boldsymbol{w},\widetilde{\boldsymbol{w}}\right)\mid\omega=\omega_{0}\right]\leq\exp\left(-\Omega\left(\ell/\lambda\right)\right)$$

**Definition 4** (Definition 9 of [HPPZ20] - spurious matches). Let  $\ell$ ,  $\lambda$  be given positive integers. Let  $\boldsymbol{x}$  be an input string, let I be an interval of length  $\ell$  and write  $\boldsymbol{w} = \boldsymbol{x}(I)$ . Let J be another interval (usually containing I).

Let  $\widetilde{\boldsymbol{x}}$  be a trace of  $\boldsymbol{x}$  through the insertion-deletion channel. We say that an (I,J)-spurious match occurs if for some substring of the trace  $\widetilde{\boldsymbol{w}} = \widetilde{\boldsymbol{x}}(i_1:i_2)$ , such that  $g([i_1,i_2]) \subseteq J$  (i.e. whose bits originated from within the interval J), we have  $T_{\ell,\lambda}(\boldsymbol{w},\widetilde{\boldsymbol{w}}) = 1$ , but  $\boldsymbol{w}$  and  $\widetilde{\boldsymbol{w}}$  are  $\lambda$ -mismatched.

We will denote the event that an (I,J)-spurious match occurs by  $\mathcal{Q}_{\ell,\lambda}(I,J)$ .

<span id="page-8-0"></span>**Lemma 3.4** (Lemma 10 of [HPPZ20] - spurious matches are rare within an interval). Let  $\ell$  and  $\lambda$  be given positive integers. Let I be an interval of length  $\ell$  and let  $J \supseteq I$  be an interval containing I. Suppose we have an input string  $\boldsymbol{x}$  all of whose bits are determined except those in J, which are drawn i.i.d. uniformly. Then:

$$\Pr\left(Q_{\ell,\lambda}(I,J)\right) \le |J|e^{-\Omega(\ell/\lambda)} + e^{-\Omega(|J|)}$$

<span id="page-8-1"></span>**Lemma 3.5** (Lemma 11 of [HPPZ20] - spurious matches are rare between different intervals). Let  $\ell$  and  $\lambda$  be given positive integers. Let I be an interval of length  $\ell$  and let J be a disjoint interval whose distance from I is at least |J|. Suppose we have an input string x all of whose bits are determined except those in I, which are drawn i.i.d. uniformly. Then:

$$\Pr\left(Q_{\ell,\lambda}(I,J)\right) \le |J|e^{-\Omega(\ell/\lambda)} + e^{-\Omega(|J|)}$$

We will use these lemmas exactly as proven by HPPZ, so for the sake of brevity, we will not repeat the proofs.

# <span id="page-8-2"></span>3.2 Coarse and Fine Alignments

The next step of both our reduction and HPPZ's algorithm is to perform coarse and fine alignments. In this portion of their construction, HPPZ set their parameters specifically for their  $\exp(O(\log^{1/3} n))$  sample algorithm, so it will require some minor changes for our case.

In this section, we will define the properties we want the string  $\mathbf{x}$  to have in order for each step in our alignment procedure to succeed. In Appendix A we will prove that if  $\mathbf{x}$  is randomly chosen, it maintains these properties with high probability.

Let be C a sufficiently large constant. We define the parameters for the coarse and fine alignments to be:

$$\ell_c = C \frac{\log^2 n}{h(C \log n)}; \qquad \lambda_c = C^{1/2} \frac{\log n}{h(C \log n)}$$
$$\ell_f = C^{2/3} h(C \log n); \qquad \lambda_f = C^{1/12}$$

### 3.2.1 Coarsely Well-Behaved Strings

<span id="page-8-3"></span>**Definition 5** (Coarsely well-behaved strings). Let  $\boldsymbol{x}$  be a string of length n and let  $\ell_c, \lambda_c$  be as defined above. We say that  $\boldsymbol{x}$  is coarsely well-behaved, if for each interval  $I \subseteq [0, n]$  of length  $\ell_c$ , it holds that  $\boldsymbol{x}(I)$  has robust bias at scale  $\lambda_c$  and

$$\Pr_{\omega} \left[ \mathcal{Q}_{\ell_c, \lambda_c}(I, [0, n]) \right] \le n^{-2}$$

(where the probability is taken over the noise of the channel)

<span id="page-8-4"></span>**Lemma 3.6.** Let x be a random string of length n. Then, x is coarsely well-behaved with probability at least  $1 - n^{-2}$ .

### 3.2.2 Finely Well-Behaved Strings

Recall Lemmas 3.4 and 3.5. Let  $c_0$  be such that the constant factors in the  $\Omega(\ell/\lambda)$  and  $\Omega(|J|)$  were at least  $10c_0$ .

<span id="page-9-0"></span>**Definition 6** (Finely well-behaved strings). Let  $\mathbf{x}$  be a string of length n, and let  $\ell = \ell_f, \lambda = \lambda_f$  as defined above. We say that  $\mathbf{x}$  is finely well-behaved if for each interval  $J = [a, a + C \log n] \subseteq [0, n]$  of length  $C \log n$ , there exists a sub-interval  $I \subseteq [a + 1/3C \log n, a + 2/3C \log n]$  of length  $\ell$ , such that  $\mathbf{x}(I)$  exhibits robust bias at scale  $\lambda$  and  $\Pr_{\omega}[\mathcal{Q}_{\ell,\lambda}(I,J)] \leq \exp(-c_0C^{7/12}h(C \log n))$ .

<span id="page-9-2"></span>**Lemma 3.7.** Let x be a random string of length n. Then, x is finely well-behaved with probability at least  $1 - n^{-2}$ .

## 3.3 Using the Oracle

In Section 3.1, we showed that the boolean test T has several very nice properties when the input string  $\mathbf{x}$  is well-behaved, and in Section 3.2, we proved that almost all strings are well-behaved. For the rest of this section, we will denote by  $\Xi_{\text{bad}}$  the case where  $\mathbf{x}$  is not well-behaved (coarsely or finely), and by  $\Xi_{\text{good}}$  the case where the  $\mathbf{x}$  is well-behaved.

For any well-behaved string  $\mathbf{x} \in \Xi_{\text{good}}$  and any integer  $k \in [\ell_c + C \log n, n]$ , we set  $a_1 = k - \ell_c - C \log n$  and  $a_2$  to be such that

$$I = [a_2, a_2 + \ell_f] \subseteq J = [k - 2/3C \log n, k - 1/3C \log n]$$

is the interval promised by our assumption that  $\mathbf{x}$  is finely well-behaved.

For any trace  $\tilde{\mathbf{x}}$ , we set our coarse alignment  $\tau_1^k$  to be the first integer b for which

$$T_{\ell_c,\lambda_c}(\mathbf{x}([a_1,a_1+\ell_c]),\widetilde{\mathbf{x}}([b,b+\ell_c]))=1$$

or  $\infty$  if no such b exists.

For any trace  $\widetilde{\mathbf{x}}$ , if  $\tau_1^k < \infty$ , we set our fine alignment  $\tau_2^k$  to be the first integer

$$b \in [\tau_1^k - \ell_c, \tau_1^k + 2\ell_c + C \log n]$$

such that:

$$T(\mathbf{x}([a_2, a_2 + \ell_f]), \widetilde{\mathbf{x}}([b, b + \ell_f])) = 1$$

If  $\tau_1^k = \infty$  or no such b exists, we set  $\tau_2^k = \infty$ .

From the definitions of Section 3.2 and the lemmas of Section 3.1 it will be easy to show that the following properties hold:

<span id="page-9-1"></span>**Lemma 3.8.** Let  $\mathbf{x} \in \Xi_{good}$  be a well-behaved string and let  $k \in \{\ell_c + C \log n, \ldots, n\}$  be an integer. Then for  $a_1, a_2, \tau_1^k, \tau_2^k$  as defined above, the following properties hold:

- $\Pr\left[\tau_1^k < \infty\right] > \exp(-c_1 C^{1/2} h(C \log n))$
- $\Pr\left[\tau_1^k < \infty \land d(k, \tau_1^k) > \ell_c\right] < n^{-2}$
- $\Pr\left[\tau_2^k < \infty \mid \tau_1^k < \infty\right] \ge \exp(-c_2 C^{1/2} h(C \log n))$
- $\Pr\left[\tau_2^k < \infty \land d(k, \tau_2^k) > \ell_f \mid \tau_1^k < \infty\right] < \exp(-c_3 C^{7/12} h(C \log n))$

Where the probabilities are taken over the randomness of the channel and  $c_1, c_2, c_3, c_4 > 0$  are positive constants that may depend on q, q' but not on C or n and originate from the  $\Omega(\cdot)s$  and  $O(\cdot)s$  of the previous sections.

The first two parts of this claim follow directly from our definition of coarsely well-behaved strings (Definition 5) and Lemma 3.2. The rest of it follows directly from our definition of finely well-behaved strings (Definition 6) and the same lemma.

In order to prove the main claim of our reduction we will need one more lemma which we will prove in the next subsection:

<span id="page-10-0"></span>**Lemma 3.9**  $(\tau_1^k, \tau_2^k \text{ can be computed efficiently})$ . There is an algorithm  $A_{\text{align}}$  such that, for any  $\mathbf{x} \in \Xi_{good}, k \in \{\ell_c + C \log n, \ldots, n\}$  and any trace  $\widetilde{\mathbf{x}}$  of  $\mathbf{x}$  through the channel, given  $k, \mathbf{x}(0:k), (\tau_1^1, \ldots, \tau_1^{k-1}), (\tau_2^1, \ldots, \tau_2^k), A_{\text{align}}$  computes  $\tau_1^k, \tau_2^k, a_2$  in time  $n^{o(1)}$ , with probability  $\geq 1 - n^{-2}$ .

Before proving Lemma 3.9, we will show that the main theorem of our reduction (Theorem 1.2) follows immediately from it.

Proof of Theorem 1.2. Let  $q, q' \in [0, 1)$  be the parameters of the channel, and set C to be a sufficiently large constant<sup>2</sup>:

$$C = (100 \max\{1, 1/c_0, C_1, 1/C_1, 1/c_1, 1/c_2, 1/c_3, c_0, c_1, c_2, c_3, c_4\})^{100}$$

(where  $c_0, c_1, c_2, c_3$  are the constants from the Definition 6 and Lemma 3.9 and  $C_1$  is the constant from Theorem 1.2).

We set the constant  $C_2$  of Theorem 1.2 to be equal to C.

We will prove that given the first  $k \ge \ell_c + C \log n$  bits of  $\mathbf{x}$ , we can reconstruct the rest. We can work under this assumption, by adding  $\ell_c + C \log n$  virtual 0 bits to the start of  $\mathbf{x}$  and adding a trace of  $0^k$  to the beginning of each of the traces  $\tilde{\mathbf{x}}$  before the reconstruction.

Given the first k bits of  $\mathbf{x}$ , we will show that we can reconstruct the k+1th bit of  $\mathbf{x}$  and from there, we can continue this process iteratively. Using the alignment algorithm from Lemma 3.9, we compute  $\tau_1^k$  and  $\tau_2^k$  of each of the traces  $\widetilde{\mathbf{x}}$ .

Given  $a_2, \tau_2^k$ , we run the shifted trace reconstruction algorithm A with parameters n', n'-1, where  $n' = k - a_2 \in [1/3C \log n, 2/3C \log n]$ , on the set:

$$\mathcal{X} = \left\{ \widetilde{\mathbf{x}}(\tau_2^k :) \mid \underset{\tau_2^k(\widetilde{\mathbf{x}}) < \infty}{\widetilde{\mathbf{x}} \text{ is a sample}} \right\}$$

The first and third claims of Lemma 3.8, mean that for each of our  $N = \exp(Ch(C \log n))$  traces, it will have a finite  $\tau_2^k$ , with probability at least

$$\exp(-C^{1/2}(c_1 + c_2)h(C\log n)) \ge \exp(-1/3Ch(C\log n)).$$

Therefore, by Hoeffding's inequality, the probability that we will have at least

$$1/2 \exp(2/3Ch(C\log n)) > \exp(h(2/3C\log n)) \ge \exp(h(k-a_2))$$

traces for which  $\tau_2^k < \infty$  is at least

$$1 - \exp(-\Omega(Ch(C\log n))) = 1 - n^{-\omega(1)}$$

<span id="page-10-1"></span> $<sup>^{2}</sup>$ This choice of C it not meant to be tight.

Lemma 3.8 gives us that the probability that any message for which  $\tau_2^k < \infty$  is the result of a spurious match is at most

$$\varepsilon(n) \le \exp(-(C^{7/12}c_3 - C^{1/2}(c_1 + c_2))h(C\log n)) \le \exp(-C_1h(C\log n))$$

We will make no assumptions about the strings that came from spurious alignments. By definition, any  $\tau_2^k < \infty$  that was not the result of a spurious match, had distance  $d(a_2, \tau_2^k) \le \eta = \lambda_f$ .

Therefore, the samples in  $\mathcal{X}$ , constitute a shifted trace reconstruction problem. Because we assume A solves the shifted trace reconstruction problem with probability  $1 - \exp(-n')$ , and we will be applying A on messages of length  $n' \geq 1/3C \log n$ , it will succeed with probability  $\geq 1 - \exp(-n') > 1 - n^{-2}$ .

Taking a union bound on the values of k, we see that A will succeed in resolving the value of  $x_k$  for all k, w.p.  $\geq 1 - 1/n$ .

# 3.4 Time Complexity (Proof of Lemma 3.9)

All that is left in order to prove the reduction (Theorem 1.2) is to show that  $\tau_1, \tau_2, a_2$  can be computed efficiently and with a high success rate.

For any trace  $\widetilde{\mathbf{x}}$ , given  $\tau_1$  and  $a_2$ , it is easy to compute  $\tau_2$  by setting  $I = [a_2, a_2 + \ell_f]$  and for each integer  $\tau_1 - \ell_c \leq b \leq \tau_1 + 2\ell_c + C \log n$ , we perform the test  $T(\mathbf{x}(I), \widetilde{\mathbf{x}}([b, b + \ell_f]))$ , outputting the first b for which it returns 1. This requires  $O(\ell_c)$  iterations of a test that takes  $O(\ell_f)$  time, for a total of  $n^{o(1)}$ .

 $a_2$  is defined as being some index in  $[k-2/3C \log n, k-1/3C \log n]$  for which two properties hold (whose existence is promised by our assumption that  $\mathbf{x}$  is finely well-behaved). First, the segment  $\mathbf{x}([a_2, a_2 + \ell_f])$  exhibits robust bias at scale  $\lambda_f$ , and this is easy to check in  $\text{poly}(\ell_f)$  time.

The second property is that we want the probability of having a spurious match between I as defined above and any subinterval of  $J = [k - C \log n, k]$  to be lower than some  $\exp(-\Omega(h(C \log n)))$ . In order to check if  $a_2$  maintains this property, we will generate a sufficiently large (but still  $\exp(O(h(C \log n))) = n^{o(1)}$ ) number of traces of  $\mathbf{x}(J)$  and for each possible value of  $a_2$ , we will count the number of sub-intervals of J for which I has a spurious match. Using standard probability bounds, we can show that this process will allow us to approximate  $\mathcal{Q}_{\ell_f,\lambda_f}(I,J)$  to a sufficiently high degree of accuracy with a  $n^{-\omega(1)}$  failure rate and  $n^{o(1)}$  complexity.

This leaves us with the task of computing  $\tau_1^k$  efficiently. To do so, we search for the last finite  $\tau_1^j < \infty$  of this trace. From Hoeffding's inequality, it is easy to see that with probability  $\geq 1 - n^{-\omega(1)}$ , we will have  $j \geq k - 100\ell_c \log^2 n$  and from the Chernoff bound that with a similarly high probability, if  $\tau_1^k$  and  $\tau_2^j$  both resulted from real matches (i.e. not spurious ones) then  $\tau_1^k \leq \log^2 n(k-j) + \tau_2^j$ .

if  $\tau_1^k$  and  $\tau_1^j$  both resulted from real matches (i.e. not spurious ones) then  $\tau_1^k \leq \log^2 n(k-j) + \tau_1^j$ . Combining both of these, it suffices to check  $n^{o(1)}$  options for  $\tau_1^k$ . Since each of these tests takes  $n^{o(1)}$  time, this step also has a complexity of  $n^o(1)$ , proving Lemma 3.9.

# <span id="page-11-0"></span>4 Conversion to Complex Analysis

Like many other results regarding the trace reconstruction problem (such as [NP17, DOS17, PZ17, HPPZ20, Cha21b]), our proof of Theorem 1.3 will rely on a complex analysis based on the results of Borwein and Erdélyi's seminal research on Littlewood polynomials [BE97]. These analyses are typically based on proving that some polynomial related to the input message is equal to the average of a property of the traces.

In this section, we will adapt the "non-linear" complex analysis in Chase's construction (12 4.1) to insertion-deletion channels with random shifts using a generalization of the analysis shown by HPPZ (Lemma 4.2).

<span id="page-12-0"></span>**Proposition 4.1** (Proposition 6.2 of [Cha21b]). For any  $x \in \{0,1\}^n$ ,  $l \ge 1, w \in \{0,1\}^l$ , and  $z_0, \ldots, z_{l-1} \in \mathbb{C}$ , we have

$$\mathbb{E}_{x} \left[ p^{-l} \sum_{j_{0} < \dots < j_{l-1}} \left( \prod_{i=0}^{l-1} 1_{U_{j_{i}} = w_{i}} \right) \left( \frac{z_{0} - q}{p} \right)^{j_{0}} \left( \prod_{i=1}^{l-1} \left( \frac{z_{i} - q}{p} \right)^{j_{i} - j_{i-1} - 1} \right) \right]$$

$$= \sum_{k_{0} < \dots < k_{l-1}} \left( \prod_{i=0}^{l-1} 1_{x_{k_{i}} = w_{i}} \right) z_{0}^{k_{0}} \left( \prod_{i=1}^{l-1} z_{i}^{k_{i} - k_{i-1} - 1} \right).$$

<span id="page-12-1"></span>**Lemma 4.2** (Lemma 22 of [HPPZ20]). Let S be a bounded  $\mathbb{N}$ -valued random variable. Let  $\mathbf{a} = (a_0, a_1, \dots) \in [-1, 1]^{\mathbb{N}}$ , and let  $\widetilde{\mathbf{a}}$  be the output from the insertion-deletion channel with deletion (resp. insertion) probability q (resp. q'), applied to the randomly shifted string  $\theta^S(\mathbf{a})$ . Let  $\phi_1(w) = pw + q$ ,  $\phi_2(w) = \frac{p'w}{1-q'w}$ , and  $\sigma(s) = \Pr[S = s]$  for  $s \in \mathbb{N}$ . Define

$$P(z) := \sum_{s=0}^{d} \sigma(s)z^{s}, \qquad Q(z) := \sum_{j=0}^{\infty} a_{j}z^{j}.$$

Then, for any |w| < 1,

$$\mathbb{E}\left[\sum_{j\geq 0} \widetilde{a}_j w^j\right] = \frac{pp'}{1 - q'\phi_1(w)} \cdot P\left(\frac{1}{\phi_2 \circ \phi_1(w)}\right) \cdot Q(\phi_2 \circ \phi_1(w)). \tag{1}$$

Ideally, we would want to directly combine these theorems. However, Lemma 4.2 works only when the entries inserted by the channel are taken from a centered distribution (i.e. they have a mean of 0). This is not problematic for HPPZ's analysis, since they only apply the lemma to the difference between the messages  $a_j = x_j - y_j$  (where  $\mathbf{x}$  and  $\mathbf{y}$  are the messages between which one is trying to distinguish).

In contrast, for Chase's upper bound, one distinguishes between  $f(\mathbf{x}) = \prod_i (x_{j_i} - w_i)$  and  $f(\mathbf{y})$  (for some  $\mathbf{w} \in \{0,1\}^l$ ). Combining these techniques is not trivial, because  $f(\mathbf{x}) - f(\mathbf{y})$  cannot be written as a function of  $\mathbf{a} = \mathbf{x} - \mathbf{y}$ .

Our goal in this section will be to show that we can overcome this problem. In particular, we will prove the following theorem:

<span id="page-12-2"></span>**Theorem 4.1.** Let  $h(n) = n^{1/5} \log^7 n$ ,  $l \le 2n^{1/5} + 1$  and let  $c_1 > c_2 > 0$  be sufficiently small constants.

Let  $f(x_1, ..., x_l)$  be some function from  $\{0, 1\}^l$  to  $\mathbb{D}$  (in our case  $f(x_1, ..., x_l) = \prod_i (x_i - w_i)$  for some  $\mathbf{w} \in \{0, 1\}^l$ ). We define the polynomial  $g_{\mathbf{x}}^f$  to be the following:

$$g_{\boldsymbol{x}}^{f}(\zeta_0, \zeta_1, \dots, \zeta_l) = \sum_{k_0 < \dots < k_{l-1}} (-1)^{x_{k_0}} f(x_{k_1}, \dots x_{k_l}) \zeta_0^{k_0 - 1} \zeta_1^{k_1 - k_0 - 1} \dots \zeta_{l-1}^{k_l - k_{l-1} - 1}$$

For any point  $z_0, z_1, \ldots, z_l \in \mathbb{C}^{l+1}$ , such that  $z_0 = (1 - n^{-4/5} \log^6 n) e^{i\theta}$ ,  $|\theta| \leq n^{2/5}$  and  $z_1 = z_2 = \cdots = z_l \in [1 - c_1, 1 - c_2]$ , given  $\exp(h(n))$  traces of the shifted trace reconstruction

problem with false-sample rate  $\varepsilon(n) = \exp(-h(n))$  and shift inaccuracy  $\eta = O(h(n))$ , we can compute  $g(z_0, z_1, \ldots, z_l)$  to within an additive error of  $\pm \exp(-\Omega(h(n)))$ , with probability  $1 - \exp(-\omega(n))$  and in time  $\exp(\widetilde{O}(h(n)))$ .

Furthermore, when q < 1/2, this also holds for  $z_1 = z_2 = \cdots = z_l \in [-c_1, c_1]$ .

We separate the proof of Theorem 4.1 into three parts. In the first portion of the proof, we will show that the statement holds for the specific case where  $f(x_1, \ldots, x_l) = \prod_i (-1)^{x_i}$  is a "simple character", even if the equality  $z_1 = \cdots = z_l$  does not hold.

Then we will show that Theorem 4.1 holds for any character  $f(x_1, \ldots, x_l) = \prod_i \omega_i^{x_i} = \chi_{\omega}$  (for any  $\omega \in \{-1, 1\}^l$ ). This step does not trivially follow from the first one, because  $f(x_1, \ldots, x_l)$  can now have "holes" - variables that do not affect its outcome, and this changes the polynomial  $g_{\mathbf{x}}^f$ . We will show that when  $z_1 = \cdots = z_l$ , the  $g_{\mathbf{x}}$  of a general character is a high-order differential of  $g_{\mathbf{x}}$  of a smaller simple character, and that this numerical differentiation does not reduce the accuracy too much.

Finally, because the transformation from f to the polynomial  $g_{\mathbf{x}}^f$  is linear, we can take any  $f:\{0,1\}^l\to\mathbb{D}$  and use its Fourier transformation over  $\mathbb{F}_2^l$  to show that:

<span id="page-13-0"></span>
$$g_{\mathbf{x}}^{f}(\zeta_{0},\zeta_{1},\ldots,\zeta_{l}) = g_{\mathbf{x}}^{\sum_{\omega\in\{-1,1\}^{l}}\hat{f}(\omega)\chi_{\omega}}(\zeta_{0},\zeta_{1},\ldots,\zeta_{l}) = \sum_{\omega\in\{-1,1\}^{l}}\hat{f}(\omega)g_{\mathbf{x}}^{\chi_{\omega}}(\zeta_{0},\zeta_{1},\ldots,\zeta_{l}). \tag{2}$$

Combining equation (2) with the second step will yield Theorem 4.1.

The first step in our analysis will be the following lemma:

<span id="page-13-1"></span>**Lemma 4.3.** Let S be a random variable, such that  $\operatorname{supp}(S) \subseteq \{0, 1, \dots, d\}$  for some finite d. Let  $\mathbf{a} = (a_0, a_1, \dots) \in \{0, 1\}^{\mathbb{N}}$ , and let  $\widetilde{\mathbf{a}}$  be the output from the insertion-deletion channel with deletion probability q and insertion probability q' applied to the randomly shifted string  $\theta^s(\mathbf{a})$ . Let  $\phi_1(z) = pz + q$ ,  $\phi_2(z) = \frac{p'z}{1 - q'z}$ ,  $\phi \stackrel{\text{def}}{=} \phi_2 \circ \phi_1$ ,  $\Psi = \phi^{-1}$ ,  $\overline{\phi}(z) = \frac{pp'}{1 - q'\phi_1(z)} = \frac{p\phi(z)}{\phi_1(z)}$  and  $\sigma(s) = \Pr[S = s]$  for  $s \in \mathbb{N}$ . Define

$$P(z) \stackrel{def}{=} \sum_{s=0}^{d} \sigma(s) z^{s}$$

Then:

$$\mathbb{E}\left[\sum_{r_0 < \dots < r_l} (-1)^{\widetilde{a}_{r_0}} \Psi(z_0)^{r_0 - 1} \left(\prod_{i=1}^l (-1)^{\widetilde{a}_{r_i}} \Psi(z_i)^{r_i - r_{i-1} - 1}\right)\right] \\
= \left(\prod_{0 \le i \le l} \overline{\phi}(\Psi(z_i))\right) P\left(\frac{1}{z_0}\right) \cdot \sum_{k_0 < k_1 < \dots < k_l} (-1)^{a_{k_0}} z_0^{k_0 - 1} \left(\prod_{i=1}^l (-1)^{a_{k_i}} z_i^{k_i - k_{i-1} - 1}\right) \tag{3}$$

This lemma is similar to a combination of Lemma 4.2 and 12 4.1, but avoids the drift caused by the insertions by using a function that has 0 mean when any of the bits is a random insertion.

# 4.1 Proof of Lemma 4.3

We consider both the shifted channel and the original one (i.e. with S=0). For the unshifted channel, let  $A_{k,r}$  denote the event that the first r bits of the trace were produced by the first k bits of the message and that the kth bit of the message was not deleted (i.e. that after the shift, all the

insertions before  $\mathbf{x}_k$  and all the deletions, r bits were left). Similarly, let  $A'_{k,r}$  denote the same event for the shifted channel (when S is as in the lemma). We define:

$$\alpha_{k,r} = \Pr[A_{k,r}]$$

$$\alpha'_{k,r} = \Pr[A'_{k,r}]$$
(4)

Since each of the bits of the message are translated to a geometric number of bits and then each is deleted or not independently of the rest, we can use basic results on generating functions to produce a simple formula for  $\alpha_{k,r}$  and  $\alpha'_{k,r}$ :

$$\forall k \quad P_{\alpha_{k}}(\zeta) \stackrel{def}{=} \sum_{r} \zeta^{r} \alpha_{k,r} = p \left( P_{\text{Geometric}(q')} \left( P_{\text{Bernoulli}(q)}(\zeta) \right) \right)^{k-1} P_{\text{Geometric}(q')-1} \left( P_{\text{Bernoulli}(q)}(\zeta) \right) \zeta$$

$$= \zeta \overline{\phi}(\zeta) \phi(\zeta)^{k-1}$$

$$P_{\alpha'_{k}}(\zeta) \stackrel{def}{=} \sum_{r} \zeta^{r} \alpha'_{k,r} = \sum_{s} \Pr\left[ S = s \right] \sum_{r} \zeta^{r} \alpha'_{k-s,r} = \sum_{s} \sigma(s) \phi(\zeta)^{k-s-1} \zeta \overline{\phi}(\zeta)$$

$$= \zeta P\left( \frac{1}{\phi(z)} \right) \overline{\phi}(\zeta) \phi(\zeta)^{k-1}$$
(5)

Setting  $z = \phi(\zeta)$ , and defining

$$\begin{split} P_{\alpha_k-1}(\zeta) &= \zeta^{-1} P_{\alpha_k}(\zeta) \\ P_{\alpha_k'-1}(\zeta) &= \zeta^{-1} P_{\alpha_k'}(\zeta) \end{split}$$

gives us the formulas:

<span id="page-14-0"></span>
$$P_{\alpha_k-1}(\Psi(z)) = \overline{\phi}(\Psi(z))z^k$$

$$P_{\alpha'_k-1}(\Psi(z)) = \overline{\phi}(\Psi(z))P(1/z)z^k$$
(6)

We denote by  $B_r = \overline{\bigvee_k A_{k,r}}$  the event that the rth bit of the output was an insertion. By our definition of the channel, conditioning on  $B_r$ , the rth bit of the  $\widetilde{a}$  is a Bernoulli( $\frac{1}{2}$ ) random variable independent of the rest of the problem. Therefore, we have

<span id="page-14-1"></span>
$$\mathbb{E}_{\text{conditioned on } B_{r_i}} \left[ \prod_{1 \le j \le l} (-1)^{\widetilde{a}_{r_j}} \right] = 0 \tag{7}$$

Let  $k_0 < k_1 < \cdots < k_l$  be some indices in the input message and let  $r_0 < r_1 < \cdots < r_l$  be some indices in the output message. We consider the events

$$A_{\vec{k},\vec{r}} \stackrel{def}{=} \bigwedge_{i} A_{k_{i},r_{i}}$$

$$A_{\vec{k},\vec{r}} \stackrel{def}{=} \bigwedge_{i} A_{k_{i},r_{i}}$$

$$(8)$$

It is clear from our definition of the channel, that for all sequences of indices  $r_0 < r_1 < \cdots < r_l$  and non-monotone sequences  $k_0, k_1, \ldots, k_l$ , the event  $A'_{\vec{k}, \vec{r}}$  has probability 0. Furthermore, from the independence of the channel it is easy to see that:

<span id="page-14-2"></span>
$$\Pr\left[A'_{\vec{k},\vec{r}}\right] = \alpha'_{k_0,r_0} \prod_{1 \le i \le l} \alpha_{k_i - k_{i-1}, r_i - r_{i-1}}$$
(9)

We combine equations (6), (7) and (9) to get the desired result:

$$\mathbb{E}\left[\sum_{r_{0}<\dots< r_{l}} (-1)^{\widetilde{a}_{r_{0}}} \Psi(z_{0})^{r_{0}-1} \left(\prod_{i=1}^{l} (-1)^{\widetilde{a}_{r_{i}}} \Psi(z_{i})^{r_{i}-r_{i-1}-1}\right)\right] \\
= \sum_{r_{0}<\dots< r_{l}} \sum_{k_{0}<\dots< k_{l}} \Pr\left[A'_{\vec{k},\vec{r}}\right] (-1)^{a_{k_{0}}} \Psi(z_{0})^{r_{0}-1} \left(\prod_{i=1}^{l} (-1)^{a_{k_{i}}} \Psi(z_{i})^{r_{i}-r_{i-1}-1}\right) \\
= \sum_{k_{0}<\dots< k_{l}} \sum_{r_{0}<\dots< r_{l}} \prod_{1\leq i\leq l} \alpha_{k_{i}-k_{i-1},r_{i}-r_{i-1}} (-1)^{a_{k_{0}}} \Psi(z_{0})^{r_{0}-1} \left(\prod_{i=1}^{l} (-1)^{a_{k_{i}}} \Psi(z_{i})^{r_{i}-r_{i-1}-1}\right) \\
= \sum_{k_{0}<\dots< k_{l}} \prod_{1\leq i\leq l} (-1)^{a_{k_{i}}} P_{\alpha_{k_{i}-k_{i-1}}-1} (\Psi(z_{i})) (-1)^{a_{k_{0}}} P_{\alpha'_{k_{0}}-1} (\Psi(z_{0})) \\
= \prod_{0\leq i\leq l} \overline{\phi}(\Psi(z)) P\left(\frac{1}{z_{0}}\right) \cdot \sum_{k_{0}< k_{1}<\dots< k_{l}} (-1)^{a_{k_{0}}} z_{0}^{k_{0}-1} \left(\prod_{i=1}^{l} (-1)^{a_{k_{i}}} z_{i}^{k_{i}-k_{i-1}-1}\right)$$
(10)

# <span id="page-15-1"></span>4.2 Proof of Theorem 4.1 for Simple Characters

In order to complete the proof of Theorem 4.1 for the case when  $f(x_1, \ldots, x_l) = \prod_i (-1)^{x_i}$ , we will use a property of the Möbius transformation  $\Psi$  defined in Lemma 4.3

<span id="page-15-0"></span>**Lemma 4.4.** There are constants  $c_1, c_2 \in (0, 1/20)$ , depending only on q, q', such that for any sufficiently large L, if  $|\arg(z)| \leq c_1/L$  and  $\rho = 1 - 1/L^2$ , then for  $w = \Psi(\rho z)$ ,

$$|w| \le 1 - \frac{c_2}{L^2}$$

Furthermore, for q < 1/2, we have:

$$\Psi(0) = \frac{q}{p} < 1$$

**Remark 3.** For n sufficiently large, Lemma 4.4 implies that for all  $z \in \{(1 - n^{4/5} \log^6 n)e^{i\theta} \mid |\theta| \le n^{2/5}\}$ , it holds that  $|\Psi(z)| \le 1 - c_2 n^{-4/5} \log^6 n$  for some constant  $c_2 > 0$ .

**Remark 4.** For  $\varepsilon > 0$  sufficiently small (but depending only on q, q'), Lemma 4.4 implies that for any  $z \in [1 - 2\varepsilon, 1 - \varepsilon]$ , it holds that  $|\Psi(z)| \le 1 - c_2\varepsilon$  for some constant  $c_2 > 0$ .

Additionally, for q < 1/2, because  $\Psi$  is continuous at 0, for a sufficiently small  $\varepsilon > 0$  depending only on q, q', for any  $z \in \mathbb{D}$  such that  $|z| \leq \varepsilon$ 

$$|\Psi(z)| \le 1 - \varepsilon.$$

Proof of Lemma 4.4. Observe that  $\phi$  is a Möbius transformation mapping  $\mathbb{D}$  to a smaller disk which is contained in  $\overline{\mathbb{D}}$  which is tangent to  $\partial \mathbb{D}$  at 1 and which maps  $\mathbb{R}$  to  $\mathbb{R}$ . In particular, by linearising the map  $\Psi$  at z=1, that  $\Psi(1+\varepsilon)=1+a\varepsilon+O(|\varepsilon|^2)$  for a>1 depending only on q,q'. Writing  $z=e^{i\theta}$ , we have:

$$w = \Psi(\rho e^{i\theta})$$

$$= 1 + a(\rho e^{i\theta} - 1) + O\left(\left|\rho e^{i\theta} - 1\right|^2\right)$$

$$= 1 + a\left((1 - L^{-2})(1 + i\theta) - 1\right) + O\left(\theta^2 + L^{-4}\right)$$

$$= 1 - aL^{-2} + ia(1 - L^{-2})\theta + O\left(\theta^2 + L^{-4}\right)$$
(11)

Therefore, we have  $|w|^2 = (1 - aL^{-2})^2 \pm O(\theta^2 + L^{-4}) \le (1 - c_2L^{-2})^2$  for sufficiently small  $c_1, c_2$ .

The last part of the claim is easy to verify.

*Proof of Theorem* 4.1 for Simple Characters. We now consider a simplification of the formula from Lemma 4.3:

<span id="page-16-0"></span>
$$\mathbb{E}\left[\sum_{r_0 < \dots < r_l} (-1)^{\widetilde{a}_{r_0}} \Psi(z_0)^{r_0 - 1} \left(\prod_{i=1}^l (-1)^{\widetilde{a}_{r_i}} \Psi(z_i)^{r_i - r_{i-1} - 1}\right)\right] \left(\prod_{0 \le i \le l} \overline{\phi}(\Psi(z_i))\right)^{-1} P\left(\frac{1}{z_0}\right)^{-1} \\
= \cdot \sum_{k_0 < k_1 < \dots < k_l} (-1)^{a_{k_0}} z_0^{k_0 - 1} \left(\prod_{i=1}^l (-1)^{a_{k_i}} z_i^{k_i - k_{i-1} - 1}\right) \tag{12}$$

Note that the right-hand-side of equation (12) is the value that we want to compute and the left-hand-side depends only on the traces. By bounding the coefficients of the left-hand-side, we can show that  $\exp(h(n))$  samples suffice to approximate the right-hand-side to within  $\pm \exp(-\Omega(h(n)))$ .

We begin with  $P\left(\frac{1}{z_0}\right)$ . By our assumption of the small shift inaccuracy  $\eta = O(h(n))$ , we have  $\operatorname{Supp}(S) \subseteq [a, a + \eta] = [a, a + O(h(n))]$  for some  $a \le n$ . Therefore

$$P(\zeta) = \zeta^a \widetilde{P}(\zeta)$$

for some polynomial  $\widetilde{P}$  of degree  $\leq \eta$ .

In the setting of Theorem 4.1, we have  $\left|\frac{1}{z_0}-1\right|=O(n^{-2/5})$ , which implies

$$\left| \widetilde{P}\left(\frac{1}{z_0}\right) - 1 \right| = \left| \widetilde{P}\left(\frac{1}{z_0}\right) - \widetilde{P}(1) \right| \le \left| \left(\frac{1}{z_0}\right)^{\eta} - 1 \right| = O(n^{-1/5})$$

Inserting this into the triangle inequality, for sufficiently large n, we get:

$$\widetilde{P}\left(\frac{1}{z_0}\right) \ge 1 - \left|\widetilde{P}\left(\frac{1}{z_0}\right) - 1\right| = 1 - O(n^{-1/5}) \ge \frac{1}{2}$$

Next, we note that from their definitions, it is clear that  $\overline{\phi}(\psi(z)) = p > 0$  for z = 1 and that it is a continuous function near 1. This implies that for sufficiently small  $c_1 > 0$  and for any  $z \in [1-c_1, 1]$ , we have  $\overline{\phi}(\psi(z)) > p/2 > 0$ . Inserting this into the appropriate term in equation (12), we have:

$$\left| \left( \prod_{0 \le i \le l} \overline{\phi}(\Psi(z_i)) \right)^{-1} \right| \le \left( \frac{p}{2} \right)^{l+1} = \exp(O(n^{1/5}))$$

Finally, in Lemma 4.5 we will show that truncating the polynomial on the left-hand-side does has a negligible effect on its value. This allows us to truncate the left-hand-side of equation (12) to at most  $n^{O(l)} = \exp(O(n^{1/5} \log n))$  terms each with a coefficient of absolute value  $\leq 1$ .

Therefore, any false sample will shift the average by at most  $\exp(-\Omega(h(n)))$  and the probability that we will have more than  $n^2$  false samples is  $\exp(-O(n^2)) = \exp(-\omega(n))$ . Furthermore, in the absence of false samples, the distribution of the left-hand-side is bounded by  $\exp(o(h(n)))$ , so from a simple application of Chernoff's bound, averaging over  $\exp(h(n))$  samples will suffice to give us its value to within  $\exp(-\Omega(h(n)))$  with probability  $1 - \exp(-\exp(\Omega(h(n)))) \ge 1 - \exp(-\omega(n))$ .  $\square$ 

<span id="page-17-0"></span>**Lemma 4.5.** Define the polynomial r to be

$$r(\zeta_0, \zeta_1, \dots, \zeta_l) = \mathbb{E}\left[\sum_{r_0 < \dots < r_l} (-1)^{\widetilde{a}_{r_0}} \zeta_0^{r_0 - 1} \left( \prod_{i=1}^l (-1)^{\widetilde{a}_{r_i}} \zeta_i^{r_i - r_{i-1} - 1} \right) \right]$$

and let  $\tilde{r}$  be its truncation to degree at most  $n \log n$  on the first coordinate and degree at most n on the rest Define the polynomial r to be

$$\widetilde{r}(\zeta_0, \zeta_1, \dots, \zeta_l) = \mathbb{E}\left[\sum_{\substack{r_0 < \dots < r_l \\ r_0 - 1 \le n \log n \\ r_i - r_{i-1} - 1 \le n}} (-1)^{\widetilde{a}_{r_0}} \zeta_0^{r_0 - 1} \left(\prod_{i=1}^l (-1)^{\widetilde{a}_{r_i}} \zeta_i^{r_i - r_{i-1} - 1}\right)\right]$$

Then for sufficiently small  $c_1 > c_2 > 0$  and for any  $z_0 \in A$  and  $z_1, \ldots, z_l \in [1 - c_1, 1 - c_2]$  (or q < 1/2 and  $z_1, \ldots, z_l \in [-c_1, c_1]$ ), we have

$$|\widetilde{r}(\Psi(z_0),\ldots,\Psi(z_l))-r(\Psi(z_0),\ldots,\Psi(z_l))| \leq \exp(-\Omega(h(n)))$$

Proof of Lemma 4.5. From Lemma 4.4 and the remarks following, it follows that for some c, c' > 0:

$$|\Psi(z_0)| \le 1 - cn^{-4/5} \log^6 n \quad |\Psi(z_i)| \le 1 - c' \tag{13}$$

Lemma 4.5 follows almost trivially. Consider the set of monomials of the form  $m_{j,\mathbf{d}}(\mathbf{z}) = z_0^j z_1^{d_1} \cdots z_l^{d_l}$  with  $d_1 + \ldots + d_l = d$ . Each of these monomials has norm  $\leq \exp(-\Omega(jn^{-4/5}\log^6 n + d))$  and there are at most  $d^{O(l)}$  such monomials. Each monomial has a coefficient of norm  $\leq 1$ , so their total contribution is at most:

$$\sum_{j>n\log n \lor d>n} \exp(-\Omega(jn^{-4/5}\log^6 n + d))d^{O(l)} \le \exp(-\Omega(n^{1/5}\log^7 n))$$

## <span id="page-17-2"></span>4.3 Proof of Theorem 4.1 for General Characters

Fix some  $\omega \in \{\pm 1\}^l$  and let  $z_0, z_1, \ldots, z_l$  be a point such that  $z_1 = \cdots = z_l$ . Let  $j_0 = 0$  and let  $j_1 < \cdots < j_{l'}$  be the indices for which  $\omega_{j_i} = -1$  (for  $\omega = (1, \ldots, 1)$ , we set l' = 0).

If  $j_{l'} < l$ , then  $f(x_1, \ldots, x_l) = \chi_{\omega}(x_1, \ldots, x_l)$  does not depend on the last  $l - j_{l'}$  coordinates. In this case, setting  $l = j_{l'}$ , we can write:

<span id="page-17-1"></span>
$$g_{\mathbf{x}}^{\chi_{\omega}}(z_{0}, z_{1}, \dots, z_{l}) = \sum_{k_{0} < \dots < k_{l}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \omega_{1}^{x_{k_{1}}} z_{1}^{k_{1}-k_{0}-1} \cdots \omega_{l}^{x_{k_{l}}} z_{l}^{k_{l}-k_{l-1}-1}$$

$$= \left( \sum_{k_{0} < \dots < k_{\tilde{l}}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \omega_{1}^{x_{k_{1}}} z_{1}^{k_{1}-k_{0}-1} \cdots \omega_{\tilde{l}}^{x_{k_{\tilde{l}}}} z_{\tilde{l}}^{k_{\tilde{l}}-k_{\tilde{l}-1}-1} \right)$$

$$\cdot \left( \sum_{k_{\tilde{l}+1} < \dots < k_{l}} z_{\tilde{l}+1}^{k_{\tilde{l}+1}-k_{\tilde{l}}-1} \cdots z_{l}^{k_{l}-k_{l-1}-1} \right)$$

$$= \left( \sum_{k_{0} < \dots < k_{\tilde{l}}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \omega_{1}^{x_{k_{1}}} z_{1}^{k_{1}-k_{0}-1} \cdots \omega_{l}^{x_{k_{l}}} z_{l}^{k_{\tilde{l}}-k_{\tilde{l}-1}-1} \right) \cdot \left( \frac{1}{1-z_{1}} \right)^{l-\tilde{l}}$$

$$(14)$$

Because we assumed that  $z_1 = \cdots = z_l \in [1 - c_1, 1 - c_2]$  (or  $[-c_1, c_1]$ ), the second factor is  $\exp(\Theta(l))$ , and we focus on the first one. For simplicity, we write the rest of our proof for  $\tilde{l} = l$ , but it can be easily generalized to any  $\tilde{l} \leq l$ .

For each i, the polynomial in equation (14) sums over all the possible sequences of  $k_{j_{i-1}} < k_{j_{i-1}+1} \cdots < k_{j_{i-1}} < k_{j_i}$ , despite the fact that they have the same coefficient depending only on  $k_{j_{i-1}}, k_{j_i}$ . Simplifying this summation, we have:

<span id="page-18-0"></span>
$$g_{\mathbf{x}}^{\chi_{\omega}}(z_{0}, z_{1}, \dots, z_{l}) = \sum_{k_{0} < \dots < k_{l}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \omega_{1}^{x_{k_{1}}} z_{1}^{k_{1}-k_{0}-1} \cdots \omega_{l}^{x_{k_{l}}} z_{l}^{k_{l}-k_{l-1}-1}$$

$$= \sum_{k_{0} < k_{j_{1}} \dots < k_{j_{l'}}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \prod_{1 \leq i \leq l'} (-1)^{x_{k_{j_{i}}}} z_{j_{i}}^{k_{j_{i}}-k_{j_{i-1}}-j_{i}+j_{i-1}} \begin{pmatrix} k_{j_{i}} - k_{j_{i-1}} - 1 \\ j_{i} - j_{i-1} - 1 \end{pmatrix}$$

$$(15)$$

Notice that if we were to multiply each member of the product in equation (15) by  $(j_i - j_{i-1} - 1)!$ , we would see that this polynomial is a high-order derivative of a simpler function:

<span id="page-18-1"></span>
$$g_{\mathbf{x}}^{\chi_{\omega}}(\mathbf{z}) = \sum_{k_{0} < k_{j_{1}} \dots < k_{j_{l'}}} (-1)^{x_{k_{0}}} z_{0}^{k_{0}-1} \prod_{1 \leq i \leq l'} (-1)^{x_{k_{j_{i}}}} z_{j_{i}}^{k_{j_{i}}-k_{j_{i-1}}-j_{i}+j_{i-1}} \begin{pmatrix} k_{j_{i}} - k_{j_{i-1}} - 1 \\ j_{i} - j_{i-1} - 1 \end{pmatrix}$$

$$= \frac{\partial^{l-l'}}{\prod_{1 \leq i \leq l'} (j_{i} - j_{i-1} - 1)! \partial \zeta_{j_{i}}^{j_{i}-j_{i-1}-1}}$$

$$\sum_{k_{0} < k_{j_{1}} \dots < k_{j_{l'}}} (-1)^{x_{k_{0}}} \zeta_{0}^{k_{0}-1} \prod_{1 \leq i \leq l'} (-1)^{x_{k_{j_{i}}}} \zeta_{j_{i}}^{k_{j_{i}}-k_{j_{i-1}}-1} \Big|_{\zeta = \mathbf{z}}$$

$$(16)$$

We now note that the function being differentiated is equal to the g for a simple character of length l':

$$\sum_{k_{0} < k_{j_{1}} \dots < k_{j_{l'}}} (-1)^{x_{k_{0}}} \zeta_{0}^{k_{0}-1} \prod_{1 \leq i \leq l'} (-1)^{x_{k_{j_{i}}}} \zeta_{j_{i}}^{k_{j_{i}}-k_{j_{i-1}}-1} \Big|_{\zeta = \mathbf{z}}$$

$$= \sum_{k_{0} < k_{1} \dots < k_{l'}} (-1)^{x_{k_{0}}} \zeta_{0}^{k_{0}-1} \prod_{1 \leq i \leq l'} (-1)^{x_{k_{i}}} \zeta_{j_{i}}^{k_{i}-k_{i-1}-1}$$

$$= g_{\mathbf{x}}^{\prod_{i}(-1)^{x_{i}}} (\zeta_{0}, \zeta_{j_{1}}, \dots, \zeta_{j_{l'}})$$

$$(17)$$

In Section 4.2, we showed that we can compute

$$g_{\mathbf{x}}^{\prod_i(-1)^{x_i}}(\zeta_0,\zeta_{j_1},\ldots,\zeta_{j_{l'}})$$

to a high degree of accuracy in a neighborhood of  $z_0, z_1, \ldots, z_{l'}$ . In order to compute  $g_{\mathbf{x}}^{\chi_{\omega}}(\mathbf{z})$ , we show that we can use a simple interpolation technique to perform the differentiation shown in equation (16) numerically. In particular, we prove the two following lemmas from which the proof of this claim follows immediately.

<span id="page-18-2"></span>**Lemma 4.6.** Let  $c, \delta > 0$  be some real parameters and let P be an oracle that computes for a given point  $z_1, \ldots, z_l \in [-c, c]^l$  the value of some polynomial p of degree at most n at the given point, up to some additive error  $\delta > 0$ . Let  $\mathbf{j} = (j_1, \ldots, j_l)$  be some vector of integers (all smaller than n), define  $m_{\mathbf{j}} = z_1^{j_1} \cdots z_l^{j_l}$  be the  $\mathbf{j}$ th monomial and  $j_{\text{tot}} = \sum_i j_i$ .

Given  $\operatorname{poly}(n, 1/c)^{O(l+j_{\operatorname{tot}})}$  queries to P, we can compute the coefficient of  $m_j$  to within an additive error of  $\operatorname{poly}(n, 1/c)^{O(l+j_{\operatorname{tot}})}\delta$  in time  $\operatorname{poly}(n, 1/c)^{O(l+j_{\operatorname{tot}})}$ .

The proof of Lemma 4.6 is shown in Appendix B.

<span id="page-19-0"></span>**Lemma 4.7.** Define the polynomial r to be

$$r(z_0, \dots, z_l) = \sum_{k_0 < k_1 < \dots < k_l} (-1)^{a_{k_0}} z_0^{k_0 - 1} \left( \prod_{i=1}^l (-1)^{a_{k_i}} z_i^{k_i - k_{i-1} - 1} \right)$$

and let  $\widetilde{r}$  be its truncation to degree  $\leq n$  on the coordinates  $z_1, \ldots, z_l$ :

$$\widetilde{r}(z_0, \dots, z_l) = \sum_{\substack{k_0 < k_1 < \dots < k_l \\ k_i - k_{i-1} - 1 \le n}} (-1)^{a_{k_0}} z_0^{k_0 - 1} \left( \prod_{i=1}^l (-1)^{a_{k_i}} z_i^{k_i - k_{i-1} - 1} \right)$$

Then for  $z_0, z_1, \ldots, z_l$  as defined above, we have

$$|\widetilde{r}(z_0,\ldots,z_l)-r(z_0,\ldots,z_l)| \leq \exp(-\Omega(n))$$

Combining Lemma 4.6, which states that the **j**th derivative of any degree  $\leq n$  can be approximated without a significant increase to the inaccuracy, with Lemma 4.7, which states that  $g_{\mathbf{x}}^{\prod_i (-1)^{x_i}}$  can be approximated to a very high degree of accuracy by a degree  $\leq n$  polynomial and the fact that our target polynomial  $g_{\mathbf{x}}^{\chi_{\omega}}$  is a derivative of  $g_{\mathbf{x}}^{\prod_i (-1)^{x_i}}$  completes our proof.

*Proof of Lemma* 4.7. The proof of Lemma 4.7 is very similar to our proof of Lemma 4.5.

Fix  $z_0$  as in Lemma 4.7, we now view r and  $\tilde{r}$  as polynomials in  $z_1, \ldots, z_l$  whose coefficients were set as functions of  $z_0$ . The absolute value of each of those coefficients is trivially bounded from above by  $\sum_i |z_0|^i < n^{4/5}$ .

Consider the total contribution of the monomials of the form  $z_1^{d_1} \cdots z_l d_l$  of total degree  $\sum_i d_i = d$ . There are  $d^{O(l)}$  such monomials, each has coefficient  $\leq n^{4/5}$  and size  $|z_i|^d = \exp(-\Omega(d))$ . Therefore the total contribution of coefficients of total degree  $d \geq n$  is at most

$$\sum_{d \geq n} d^{O(l)} n^{4/5} \exp(-\Omega(d)) \leq \sum_{d \geq n} \exp(-\Omega(d)) = \exp(-\Omega(n)).$$

### 4.4 Proof of Theorem 4.1 for General Functions

*Proof.* We begin by rewriting  $f(x_1,\ldots,x_l)$  as its Fourier transformation over  $\mathbb{F}_2^l$ :

$$f(\mathbf{x}) = \sum_{\omega \in \{1, -1\}^l} \hat{f}(\omega) \chi_{\omega}(\mathbf{x})$$

where  $\chi_{\omega}(\mathbf{x}) = \prod_{1 \leq i \leq l} \omega_i^{x_i}$ .

We now use the additivity of  $g_{\mathbf{x}}^f$  (as a function of f) to write:

$$g_{\mathbf{x}}^{f}(z_{0}, z_{1}, \dots, z_{l}) = \sum_{\omega \in \{1, -1\}^{l}} \hat{f}(\omega) g_{\mathbf{x}}^{\chi_{\omega}}(z_{0}, z_{1}, \dots, z_{l})$$

In Section 4.3, we showed that we can approximate  $g_{\mathbf{x}}^{\chi_{\omega}}(z_0, z_1, \dots, z_l)$  to within  $\pm \exp(-\Omega(h(n)))$  for any character  $\omega \in \{-1, 1\}^l$ . Parceval's theorem easily bounds the norms of the  $\hat{f}(\omega)$  coefficients to at most  $\exp(O(l)) = \exp(o(h(n)))$ . Therefore, we can combine the results of these approximations to obtain a high accuracy approximation of  $g_{\mathbf{x}}^f(z_0, z_1, \dots, z_l)$  from the traces.

# <span id="page-20-0"></span>5 Proof of Theorem 1.3

In Section 4, we showed that for any function f from  $\{0,1\}^l$  to the unit disk, we can map it into a polynomial related to the input message which can be approximated to a high degree of accuracy from the traces. In this section, we will construct a function f for which our approximation of  $g_{\mathbf{x}}^f$  shown in Theorem 4.1 will suffice to reconstruct the n+1th bit of  $\mathbf{x}$ , proving Theorem 1.3.

For his upper bound, Chase proved used a lemma that members of the class of polynomials defined below reaches non-negligible values on a small subarc. We will prove that a similar polynomial has non-negligible values on a small sub-arc of radius  $1 - \varepsilon$ .

<span id="page-20-1"></span>**Theorem 5.1** (Adaptation of Theorem 5 of [Cha21b]). Let  $\mathcal{P}_n^{\mu}$  denote the set of polynomials of the form  $p(x) = \zeta - \eta x^d + \sum_{n^{\mu} \leq j \leq n} a_j x^j$  where  $\eta \in \{0, 1\}, \zeta \in \partial \mathbb{D}$  and  $|a_j| \leq 1$ .

For any  $\mu \in (0,1)$ , there exists some constant  $C_1 > 0$ , such that for all sufficiently large n, any  $p \in \mathcal{P}_n^{\mu}$ , it holds that for every  $\rho \in [0,1]$ :

$$\max_{|\theta| \le n^{-2\mu}} |p(\rho e^{i\theta})| \ge \exp\left(-C_1 n^{\mu} \log^5 n\right)$$

Theorem 5.1 is a generalization of Theorem 5 in Chase's upper bound (Chase proves this for  $\zeta = \rho = 1$ ). Our proof of the general theorem is similar to Chase's proof and we show it in Appendix C. Throughout the rest of this section, we will prove that Theorem 1.3 follows from Theorem 5.1.

### 5.1 Corollaries of Theorem 5.1

We will use Theorem 5.1 for  $\mu = 1/5$  and with  $\rho = 1 - n^{-4\mu} \log^6 n$ . For the rest of this section, we set  $\rho = 1 - n^{-4/5} \log^6 n$ ,  $l = 2n^{1/5} + 1$ , and  $A = \{\rho e^{i\theta} \mid |\theta| \le n^{2/5}\}$ . A corollary of Theorem 5.1 is the following:

<span id="page-20-2"></span>Corollary 5.1 (Adaptation of Proposition 6.3 from [Cha21b]). For some constant C > 0, let  $x, y \in \{0, 1\}^{\mathbb{N}}$  be binary strings, such that x, y agree on their first n bits but not on their (n + 1)th bit. Then there exist some  $w \in \{0, 1\}^l$  and  $z_0 \in A$  such that

$$\left| \sum_{k} \left[ (-1)^{x_k} 1_{\boldsymbol{x}(k+1:k+l) = \boldsymbol{w}} - (-1) y_k 1_{\boldsymbol{y}(k+1:k+l) = \boldsymbol{w}} \right] z_0^k \right| \ge \exp\left( -n^{1/5} \log^6 n \right) \exp(-C n^{1/5} \log^5 n)$$

Proof of Corollary 5.1. Set  $\mathbf{w}' = \mathbf{x}(n-l:n-1)$ .

Like Chase, we note that Lemmas 1 and 2 of [Rob89] and the fact that either either  $\mathbf{w}'0$  or  $\mathbf{w}'1$  has no period of length  $\leq n^{1/5}$  imply that for the right choice of  $\mathbf{w} \in \{\mathbf{w}'0, \mathbf{w}'1\}$ , the indices k for which  $\mathbf{x}(k:k+l) = \mathbf{w}$  are  $n^{1/5}$  separated.

Define q(z) to be the polynomial

$$q(z) = \sum_{k} \left[ (-1)^{x_k} 1_{\mathbf{x}(k+1:k+l) = \mathbf{w}} - (-1)^{y_k} 1_{\mathbf{y}(k+1:k+l) = \mathbf{w}} \right] z^{k-1}$$

In Chase's construction, the polynomial  $p(z) = q(z)/z^{n-l} \in \mathcal{P}_n^{1/5}$ , is used an input to Theorem 5.1 However, in our case, this sum is infinite, so we cannot directly apply Theorem 5.1 to it. In order to do so, we will consider its truncation

$$\widetilde{p}(z) = \sum_{k \le 2n - l} \left[ (-1)^{x_k} 1_{\mathbf{x}(k+1:k+l) = \mathbf{w}} - (-1)^{y_k} 1_{\mathbf{y}(k+1:k+l) = \mathbf{w}} \right] z^{k-m}$$

(where m = n - l, and clearly  $\widetilde{p} \in \mathcal{P}_n^{1/5}$ )

We will be evaluating  $\widetilde{p}(\cdot)$  at points  $|z_0| = \rho$ , so it is easy to show from the triangle inequality that:

$$|p(z_0)| \ge |\widetilde{p}(z_0)| - \sum_{k \ge n} |z_0^k| \ge |\widetilde{p}(z_0)| - \exp\left(-n^{1/5} \log^6 n\right)$$

Therefore, by Theorem 5.1, there exists some  $\theta \in [-n^{-2/5}, n^{-2/5}]$ , such that for  $z_0 = \rho e^{i\theta}$ :

$$|q(z_0)| = \left| z_0^{n-l} \right| |p(z_0)| \ge \rho^{n-l} \left| \exp(-C_1 n^{1/5} \log^5 n) - \exp(-n^{1/5} \log^6 n) \right|$$

$$\ge \exp(-n^{1/5} \log^6 n) \exp(-C n^{1/5} \log^5 n)$$
(18)

For any string **x** (and where **w** is implied from context), define the polynomial  $g_{\mathbf{x}}(\cdot)$  to be:

$$g_{\mathbf{x}}(\zeta_0, \zeta_1, \dots, \zeta_l) = \sum_{k_0 < \dots < k_{l-1}} (-1)^{x_{k_0}} \prod_{1 \le i \le l} 1_{x_{k_i} = w_i} \zeta_0^{k_0 - 1} \zeta_1^{k_1 - k_0 - 1} \dots \zeta_{l-1}^{k_l - k_{l-1} - 1}$$

For any choice of w, note that the left-hand-side of the claim in Corollary 5.1 is equal to

$$|g_{\mathbf{x}}(z_0, 0, \dots, 0) - g_{\mathbf{v}}(z_0, 0, \dots, 0)|$$

This implies that setting  $z_1, \ldots, z_l$  to 0 would give us a point  $z_0$  on the arc A, where these polynomials differ. Indeed when the deletion probability q is below 1/2, we will separate between these polynomials by using the traces to estimate the evaluation of  $g_{\mathbf{x}}$  at the point  $(z_0, 0, \ldots, 0)$  where  $z_0$  and  $\mathbf{w}$  are as promised in Corollary 5.1. Evaluating at points like this will allow us to reconstruct  $\mathbf{x}$  more efficiently by using the sparsity of the 1-variable polynomial  $f(z_0) = g(z_0, 0, \ldots, 0)$ .

However, as in Chase's construction, this point is difficult to estimate when  $q \ge 1/2$ , so in order to reconstruct  $\mathbf{x}$  from such channels, we will estimate the evaluation of  $g_{\mathbf{x}}(z_0, z_1, \dots, z_l)$  at a point where point  $z_1 = \dots = z_l \in [1 - \varepsilon_1, 1 - \varepsilon_2]$  (for small positive  $\varepsilon_{1,2} > 0$ ).

<span id="page-21-0"></span>Corollary 5.2 (Adaptation of Corollary 6.1 from [Cha21b]). Let  $\varepsilon_1 > \varepsilon_2 > 0$  be some positive constants. For some C' > 0, let  $\mathbf{x}, \mathbf{y} \in \{0, 1\}^{\mathbb{N}}$  be binary strings, such that  $\mathbf{x}, \mathbf{y}$  agree on their first n-1 bits but not on their nth bit. Then there exist some  $\mathbf{w} \in \{0, 1\}^l$ ,  $z_0 \in A$  and  $z_1 = \cdots = z_l \in [1 - \varepsilon_1, 1 - \varepsilon_2]$ , such that

$$\left| \sum_{k_0 < \dots < k_l} \left( (-1)^{x_{k_0}} \prod_{1 \le i \le l} \left[ 1_{x_{k_i} = w_i} \right] - (-1)^{y_{k_0}} \prod_{1 \le i \le l} \left[ 1_{y_{k_i} = w_i} \right] \right) z_0^{k_0 - 1} z_1^{k_1 - k_0 - 1} \dots z_{l-1}^{k_l - k_{l-1} - 1} \right| \\ \ge \exp\left( -C' n^{1/5} \log^6 n \right)$$

*Proof of Corollary 5.2.* The proof of this corollary will follow the same lines as the proof of Corollary 6.1 in [Cha21b].

Let  $\mathbf{w}$  and  $z_0$  be those promised in Corollary 5.1. We define:

$$f(z_1) = (1 - \rho) \binom{n}{l}^{-1} \sum_{k_0 < \dots < k_l} \left( (-1)^{x_{k_0}} \prod_{1 \le i \le l} \left[ 1_{x_{k_i} = w_i} \right] - (-1)^{y_{k_0}} \prod_{1 \le i \le l} \left[ 1_{y_{k_i} = w_i} \right] \right) z_0^{k_0 - 1} \left( (1 - \varepsilon_1) z_1 \right)^{k_l - k_0 - l}$$

As in Chase's proof, f is a polynomial in  $z_1$  we will show that each of its coefficients is upper bounded by 1 in absolute value.

We first note that  $\sum_{k_0} \left| z_0^{k_0} \right| = \frac{1}{1-\rho}$ , so the absolute value of the contribution of the summation over  $k_0$  is bounded.

Denote the power of  $z_1$  by  $n' \ge k_l - k_0 - l$ . When  $n' \le n$  it is trivial that the absolute value of the coefficient of  $z_1^{n'}$  is at most 1, since the normalization factor is at most 1 over the number of sets  $k_1, \ldots, k_l$  maintaining this equality. When n' > n, the number of values of  $k_1, \ldots, k_l$  is  $\exp(O(l \log n'))$  and the  $(1 - \varepsilon_1)^{n'} = \exp(-\Omega(n'))$ , so the coefficient is still bounded.

Furthermore, this shows that when evaluating  $f(z_1)$  at points where  $|z_1| \le 1 - \varepsilon_2$ , the contribution of the terms with power  $n' \ge n$  is exponentially small. Define g to be the truncated version of f:

$$g(z_1) = (1 - \rho) \binom{n}{l}^{-1} \sum_{\substack{k_0 < \dots < k_{l-1} \\ k_{l-1} - k_0 - l + 1 \le n}} \left[ 1_{x_{k_i} = w_i} - 1_{y_{k_i} = w_i} \right] z_0^{k_0 - 1} \left( (1 - \varepsilon_1) z_1 \right)^{k_{l-1} - k_0 - l + 1}$$

Clearly:

<span id="page-22-0"></span>
$$|g(z_1) - f(z_1)| \le \exp(-\Omega(n)) \tag{19}$$

Therefore, applying Theorem 5.1 of [BEK99], we have the following inequality:

<span id="page-22-1"></span>
$$\binom{n}{l} \frac{1}{1-\rho} \max_{z_1 \in [1-\varepsilon,1]} |g(z_1)| \ge \binom{n}{l} \frac{1}{1-\rho} |g(0)|^{c_1/\varepsilon} \exp(-\frac{c_2}{\varepsilon})$$

$$\ge \binom{n}{l} \frac{1}{1-\rho} \left( (1-\rho) \binom{n}{l}^{-1} \exp(-Cn^{1/5} \log^6 n) \right)^{c_1/\varepsilon} \exp(-\frac{c_2}{\varepsilon})$$

$$\ge \exp(-C'/2n^{1/5} \log^6 n)$$
(20)

where C' > 0 is some constant and

$$\varepsilon = 1 - \frac{1 - \varepsilon_2}{1 - \varepsilon_1} > 0$$

Combining equations (19) and (20) yields our claim.

### 5.2 Completing the Proof

We are now ready to complete our proof of Theorem 1.3. Assuming that we know the first n bits of  $\mathbf{x}$ , we will show that one can reconstruct its n + 1th bit from the traces.

Let C > 0 be a sufficiently large constant. We will do this by enumerating over all the pairs of options  $\mathbf{o} \in \{0,1\}^{Cn-n-1}$  of  $\mathbf{x}(n+1:Cn)$ . Let  $\mathbf{o}^0, \mathbf{o}^1$  be such a pair, and consider the strings  $\mathbf{y}^0 = \mathbf{x}(0:n-1)0\mathbf{o}^0, \mathbf{y}^1 = \mathbf{x}(0:n-1)10\mathbf{o}^1$ .

We will then combine Theorem 4.1, which shows that we can approximate  $g_{\mathbf{x}}^f(z_0, z_1, \dots, z_l)$ , and Theorem 5.1 with Corollaries 5.1 and 5.2, which show that  $g_{\mathbf{x}}^f(z_0, z_1, \dots, z_l)$  strongly depends on the n+1th bit of  $\mathbf{x}$ . We use this combination to define a Boolean test  $\tau$  such that if  $\mathbf{y}^b = \mathbf{x}(:Cn)$  (for  $b \in \{0,1\}$ ), then  $\tau$  will return b when run on  $\mathbf{y}^0, \mathbf{y}^1$  (with very high probability).

Repeating this test for each such pair  $\mathbf{y}^0, \mathbf{y}^1$ , for the correct assignment  $\mathbf{y}^b = \mathbf{x}(:Cn)$ , the test  $\tau$  will always return  $b = x_n$ . There can be no assignment  $\mathbf{y}^{1-x_n}$  for which  $\tau$  always returns  $1 - x_n$ , because when matched with  $\mathbf{y}^{x_n} = \mathbf{x}(:Cn)$ , the test will return  $x_n$  by this very property.

Finally, in Section 5.2.2 we will show that when q < 1/2, this enumeration can be carried out more efficiently (in time  $\exp(o(n))$ ).

Let  $\mathbf{y}^0, \mathbf{y}^1$  be some pair of strings as above. If q < 1/2, let  $z_0$  and  $\mathbf{w}$  be those promised by Corollary 5.1 for separating between  $\mathbf{y}^0$  and  $\mathbf{y}^1$  and let  $z_1, \ldots, z_l = 0$ . If  $q \ge 1/2$ , let  $z_0, z_1, \ldots, z_l$  and  $\mathbf{w}$  be those promised by Corollary 5.2 for separating between  $\mathbf{y}^0$  and  $\mathbf{y}^1$ .

Define  $f(x_1, \ldots, x_l) \stackrel{def}{=} \prod_i 1_{x_i = w_i}$ , and define the polynomial:

$$g_{\mathbf{x}}(z_0, z_1, \dots, z_l) = \sum_{k_0 < \dots < k_l} (-1)^{x_{k_0}} f(x_{k_1}, \dots, x_{k_l}) z_0^{k_0 - 1} z_1^{k_1 - k_0 - 1} \dots z_l^{k_l - k_{l-1} - 1}$$

The test  $\tau$  is defined as follows.

First  $\mathbf{w}$  and  $z_0, z_1, \ldots, z_l$  are selected as in Corollary 5.2 (or Corollary 5.1 when q < 1/2), when applied to the strings  $\mathbf{y}^0, \mathbf{y}^1$ . Theorem 5.1 is not constructive, but our choice of  $\mathbf{w}$  was given directly from the first n bits of  $\mathbf{y}^0, \mathbf{y}^1$  and given the polynomial  $g_{\mathbf{y}^0} - g_{\mathbf{y}^1}$ , we can take a grid of values of  $z_0, z_1, \ldots, z_l$  within the allowed region with a sufficiently small  $(\exp(-\widetilde{O}(l)))$  distance between them and choose a point for which  $|g_{\mathbf{y}^0} - g_{\mathbf{y}^1}|$  is sufficiently large  $(\exp(-O(n^{1/5}\log^5 n)))$ .

We know that such a point exists from Corollary 5.2 (or 5.1), and in Section 5.2.1 we will show that truncating  $g_{\mathbf{x}}$  to the Cnth power changes it by at most  $\exp(-\omega(n^{1/5}\log^5 n))$ . Between the points of a grid with jumps  $\exp(-\omega(n^{1/5}\log^5 n))$ , the polynomial  $g_{\mathbf{y}^0} - g_{\mathbf{y}^1}$  cannot change too much which implies that for the grid points closest to the point promised by Corollary 5.2 (or 5.1), the difference between  $g_{\mathbf{y}^0}$  and  $g_{\mathbf{y}^1}$  is also  $\exp(-O(n^{1/5}\log^5 n))$ .

Given this point, we use the algorithm promised in Theorem 4.1 to approximate  $g_{\mathbf{x}}(z_0, z_1, \dots, z_l)$ . The test  $\tau$  outputs the value  $b \in \{0, 1\}$  for which  $g_{\mathbf{y}^b}(z_0, z_1, \dots, z_l)$  is closest to our approximation of  $g_{\mathbf{x}}$  at that point. If  $\mathbf{y}^b = \mathbf{x}(:Cn)$  for some  $b \in \{0, 1\}$ , then we will clearly output b, since our approximation of  $g_{\mathbf{x}}(z_0, z_1, \dots, z_l)$  is at most  $\exp(-\Omega(n^{1/5} \log^7 n))$  from the correct value which is equal to  $g_{\mathbf{y}^b}$  (and far from  $g_{\mathbf{y}^{1-b}}$ ).

### <span id="page-23-0"></span>5.2.1 Truncating $g_x$ Causes only a Small Change

Our estimation method assumes we are somehow able to efficiently perform the test described above for any pair  $\mathbf{y}^0$ ,  $\mathbf{y}^1$  and select the one for which the test passes. However, there is an infinite number of possibilities for  $\mathbf{x}$ , as we assumed it was a string of infinite length.

In this section, we will show that only a short prefix of  $\mathbf{x}$  can have a non-negligible effect on the test. This implies that it is enough to use the value of  $\mathbf{x}$  in only a finite number of indices in order to apply this bit-recovery algorithm in a finite time.

The bound we give here will bound the time-complexity of the bit recovery by  $\exp(O(n))$ , since we will only bound the number of bits of  $\mathbf{x}$  over which we enumerate by Cn, which the average to worst case reduction would translate to a bit recovery with a polynomial complexity of  $\exp(O(\log n))$ . In Section 5.2.2 we will show that when  $q \leq 1/2$ , it is enough to enumerate only over a small part of the entropy of these first Cn bits, resulting in a  $\exp(\widetilde{O}(n^{4/5}))$  complexity.

**Lemma 5.3.** Define  $\widetilde{g}_x$  to be the truncation of  $g_x$  that has only monomials with total degree  $\leq Cn-l$ :

$$\widetilde{g}_{\boldsymbol{x}}(z_0, \zeta_1, \dots, z_l) = \sum_{k_0 < \dots < k_l < n+n \log n} (-1)^{x_{k_0}} f(x_{k_1}, \dots, x_{k_l}) z_0^{k_0 - 1} z_1^{k_1 - k_0 - 1} \cdots z_l^{k_l - k_{l-1} - 1}$$

Let C' be the constant from Corollary 5.2. Then, for sufficiently large C>0

$$|g_{\mathbf{x}}(z_0,\ldots,z_l) - \widetilde{g}_{\mathbf{x}}(z_0,\ldots,z_l)| < \frac{1}{10} \exp(-C'n^{1/5}\log^6 n)$$

*Proof.* This lemma follows trivially from the fact that the norms of the entries  $z_i$  are bounded sufficiently below 1. Indeed, for i > 1, all of the  $z_i$  are of norm  $\leq 1 - \varepsilon$  for some constant  $\varepsilon > 0$ , and  $z_0$  is of norm  $\leq 1 - n^{-4/5} \log^6 n$  For any  $d_0, m$ , limiting ourselves to monomials where  $z_0$  has degree  $d_0$  and the contribution of  $z_1, \ldots, z_l$  to the degree is m (that is, we are looking at the monomials of

the form  $z_0^{d_0} z_1^{d_1} \cdots z_l^{d_l}$  with  $\sum_{i \geq 1} d_i = m$ ), there are  $O((m+l)^l)$  such monomials, but the norm of any such monomial is at most  $(\bar{1} - \varepsilon)^m = \exp(-\Omega(m))$  and its coefficient in  $g_{\mathbf{x}}$  is of norm at most 1. Therefore, their total contribution decays exponentially with m and is easy to see from a summations over this exponential decay, that truncating the ones with m > Cn/2 changes  $g_{\mathbf{x}}(z_0, \ldots, z_l)$  by at most  $\exp(-\Omega(Cn))$ .

Similarly for i=0 we have  $|z_0|=1-n^{-4/5}\log^6 n$ . Therefore, the total contribution of powers  $d_0 \geq Cn/2$  can also be bounded with the triangle inequality and the sum of a geometric series, and we see that their contribution to  $g_{\mathbf{x}}(z_0,\ldots,z_l)$  is at most  $\exp(-\Omega(Cn^{1/5}\log^6 n))$ . Selecting a sufficiently large C, we prove prove the claim.

This gives an algorithm for the shifted trace reconstruction with a complexity of  $\leq \exp(Cn)$  for some constant C.

### <span id="page-24-1"></span>**5.2.2** Efficient Enumeration when q < 1/2

The last portion of our claim that we need to prove is that the enumeration can be performed in time  $\exp(O(n^{4/5}\log n))$ , when q<1/2. To do this, we first note that our separation between  $\mathbf{y}^0$  and  $\mathbf{y}^1$  was based entirely on the values of the polynomial  $P_{\mathbf{y}^0}(z_0)=g_{\mathbf{y}^0}(z_0,0,\ldots,0)$  and  $P_{\mathbf{y}^1}(z_0)=g_{\mathbf{y}^1}(z_0,0,\ldots,0)$ .

This polynomial is sparse and can be written as:

$$P_{\mathbf{y}}(z) = \sum_{k>1} z^{k-1} 1_{\mathbf{y}(k:k+l) = \mathbf{w}}$$

Next, we note that the polynomial  $P_{\mathbf{y}}$  is determined completely by the indices in the string  $\mathbf{y}$  where  $\mathbf{w}$  appears as a consecutive substring. By our very design of  $\mathbf{w}$ , these indices are  $n^{1/5}$ -separated.

Therefore, there are only

$$\binom{Cn}{Cn^{4/5}} = \exp(O(n^{4/5}\log n))$$

options for the truncation of  $P_{\mathbf{y}}$  to its first Cn powers and as we showed in Section 5.2.1, it is enough to determine  $g_{\mathbf{v}}$  only up to its first Cn powers.

Finally, we note that our choice of **w** depended only on the first n-1 bits of **x**, so we did not need to enumerate over any bits to compute it, and our choice of  $z_0, z_1, \ldots, z_l$  depended only on the polynomial  $P_{\mathbf{v}}$  also requiring no additional enumeration.

Therefore it will suffice to enumerate over only  $\exp(O(n^{4/5} \log n)) = \exp(o(n))$  options, proving the complexity bound for q < 1/2.

# Acknowledgements

I would like to thank Aviad Rubinstein and Roni Con for their helpful comments on previous versions of this paper. I would also like to thank Nina Holden, Robin Pemantle, Yuval Peres and Alex Zhai for their help in understanding their paper.

## References

<span id="page-24-0"></span>[BCSS19] Frank Ban, Xi Chen, Rocco A Servedio, and Sandip Sinha. Efficient average-case population recovery in the presence of insertions and deletions. arXiv preprint arXiv:1907.05964, 2019.

- <span id="page-25-12"></span>[BE97] Peter Borwein and Tamás Erdélyi. Littlewood-type problems on subarcs of the unit circle. Indiana University mathematics journal, pages 1323–1346, 1997.
- <span id="page-25-13"></span>[BEK99] Peter Borwein, Tamás Erdélyi, and Géza Kós. Littlewood-type problems on [0, 1]. Proceedings of the London Mathematical Society, 79(1):22–46, 1999.
- <span id="page-25-3"></span>[BKKM04] Tugkan Batu, Sampath Kannan, Sanjeev Khanna, and Andrew McGregor. Reconstructing strings from random traces. In Proceedings of the Fifteenth Annual ACM-SIAM Symposium on Discrete Algorithms, SODA '04, page 910–918, USA, 2004. Society for Industrial and Applied Mathematics.
- <span id="page-25-6"></span>[CDL+22] Xi Chen, Anindya De, Chin Ho Lee, Rocco A Servedio, and Sandip Sinha. Near-optimal average-case approximate trace reconstruction from few traces. In Proceedings of the 2022 Annual ACM-SIAM Symposium on Discrete Algorithms (SODA), pages 779–821. SIAM, 2022.
- <span id="page-25-4"></span>[CGMR20] Mahdi Cheraghchi, Ryan Gabrys, Olgica Milenkovic, and Joao Ribeiro. Coded trace reconstruction. IEEE Transactions on Information Theory, 66(10):6084–6103, 2020.
- <span id="page-25-7"></span>[Cha21a] Zachary Chase. New lower bounds for trace reconstruction. In Annales de l'Institut Henri Poincaré, Probabilités et Statistiques, pages 627–643. Institut Henri Poincaré, 2021.
- <span id="page-25-2"></span>[Cha21b] Zachary Chase. Separating words and trace reconstruction. In Proceedings of the 53rd Annual ACM SIGACT Symposium on Theory of Computing, pages 21–31, 2021.
- <span id="page-25-5"></span>[CP21] Zachary Chase and Yuval Peres. Approximate trace reconstruction of random strings from a constant number of traces. arXiv preprint arXiv:2107.06454, 2021.
- <span id="page-25-11"></span>[CR20] Mahdi Cheraghchi and João Ribeiro. An overview of capacity results for synchronization channels. IEEE Transactions on Information Theory, 67(6):3207–3232, 2020.
- <span id="page-25-0"></span>[DOS17] Anindya De, Ryan O'Donnell, and Rocco A Servedio. Optimal mean-based algorithms for trace reconstruction. In Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing, pages 1047–1056, 2017.
- <span id="page-25-8"></span>[HL20] Nina Holden and Russell Lyons. Lower bounds for trace reconstruction. The Annals of Applied Probability, 30(2):503–525, 2020.
- <span id="page-25-9"></span>[HMPW08] Thomas Holenstein, Michael Mitzenmacher, Rina Panigrahy, and Udi Wieder. Trace reconstruction with constant deletion probability and related results. In Proceedings of the nineteenth annual ACM-SIAM symposium on Discrete algorithms, pages 389–398, 2008.
- <span id="page-25-1"></span>[HPPZ18] Nina Holden, Robin Pemantle, Yuval Peres, and Alex Zhai. Subpolynomial trace reconstruction for random strings and arbitrary deletion probability. In Conference On Learning Theory, pages 1799–1840. PMLR, 2018.
- <span id="page-25-10"></span>[HPPZ20] Nina Holden, Robin Pemantle, Yuval Peres, and Alex Zhai. Subpolynomial trace reconstruction for random strings and arbitrary deletion probability. Mathematical Statistics and Learning, 2(3):275–309, 2020.

- <span id="page-26-1"></span>[MPV14] Andrew McGregor, Eric Price, and Sofya Vorotnikova. Trace reconstruction revisited. In European Symposium on Algorithms, pages 689–700. Springer, 2014.
- <span id="page-26-0"></span>[NP17] Fedor Nazarov and Yuval Peres. Trace reconstruction with exp (o (n1/3)) samples. In Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing, pages 1042–1046, 2017.
- <span id="page-26-2"></span>[PZ17] Yuval Peres and Alex Zhai. Average-case reconstruction for the deletion channel: subpolynomially many traces suffice. In 2017 IEEE 58th Annual Symposium on Foundations of Computer Science (FOCS), pages 228–239. IEEE, 2017.
- <span id="page-26-4"></span>[Rob89] John M Robson. Separating strings with small automata. Information processing letters, 30(4):209-214, 1989.

#### <span id="page-26-3"></span>Proof of Lemmas 3.6 and 3.7 Α

*Proof of Lemma* 3.6. For any interval  $I \subseteq [0, n]$ , by Lemma 3.1, we know that  $\mathbf{x}(I)$  is robust at scale  $\lambda_c$  with probability  $1 - e^{-\Omega(\ell/\lambda)} = 1 - e^{-\Omega(C^{1/2} \log n)} \ge 1 - n^{-4}$  for sufficiently large C. Similarly, from Lemma 3.4 we have that  $\Pr[\mathcal{Q}_{\ell_c,\lambda_c}(I,[0,n])] \le e^{-\Omega(C^{1/2} \log n)} \le n^{-6}$ , where the

probability measure is over both random strings  $\mathbf{x}$  and the randomness of the channel  $\omega$ .

Therefore, using Markov's inequality, we have that

$$\Pr_{\mathbf{x}}[\Pr_{\omega}[\mathcal{Q}_{\ell,\lambda}(I,[0,n]) \ge n^{-2}]] \le n^{-4}$$

Taking a union bound on all O(n) choices of I completes the proof.

*Proof of Lemma* 3.7. Throughout the proof of this claim, we allow the implicit constants in  $\Omega(\cdot)$ and  $O(\cdot)$  to depend on  $c_0$ , but not on C. Fix a particular interval  $J = [a, a + C \log n] \subseteq [0, n]$  of length  $C \log n$ , and let  $\ell = \ell_f, \lambda = \lambda_f$  be as defined above.

Consider the  $m = \frac{1}{3}C^{1/3}\log n/h(C\log n)$  disjoint length  $\ell$  intervals:

$$I_1, \dots, I_m \subset [a + \frac{1}{3}C\log n, a + \frac{2}{3}C\log n]$$

For a given realization of  $\mathbf{x}$ , we say that  $I_i$  is bad if either it does not have a clear robust bias at scale  $\lambda$  or it holds that

<span id="page-26-5"></span>
$$\Pr_{\omega}[\mathcal{Q}_{\ell,\lambda}(I_i,J)] \ge \exp(-c_0 C^{7/12} h(C\log n)) \tag{21}$$

Let  $I_i$  be a bad segment and let  $\ell' = C^{1/6}\ell$ , and define the event:

$$H = \left\{ \begin{array}{c} \text{there exists some } t \text{ such that} \\ g(t), g(t+\ell) \in I_i \text{ and } |g(t) - g(t+\ell)| \ge \ell' \right\} \end{array}$$

, which roughly says that a substring of length  $\ell'$  had so many deletions that only  $\ell$  or fewer bits were left in the output. For C > 1/q, we have  $\Pr(H) \leq \exp(-\Omega(\ell'))$ .

As long as H does not occur, then any spurious match in equation (21) must have come from within an interval J' of length at most  $\ell'$ . In other words

$$\mathcal{Q}_{\ell,\lambda} \subseteq H \cup \left(\bigcup_{\substack{J' \subseteq J \ |J| = \ell'}} \mathcal{Q}_{\ell,\lambda}(I_i,J')\right).$$

Let  $J_i'$  be the subsegment of J of length  $\ell'$ , which maximizes  $\Pr[\mathcal{Q}_{\ell,\lambda}(I_i, J_i')]$ . By the union bound, it is easy to see that:

$$\Pr[\mathcal{Q}_{\ell,\lambda}(I_i,J_i')] \ge \frac{1}{|J|} \Pr\left[ \left( \bigcup_{\substack{J' \subseteq J \\ |J| = \ell'}} \mathcal{Q}_{\ell,\lambda}(I_i,J') \right) \right] \ge \exp(-2c_0 C^{7/12} h(C\log n)).$$

We will want to prove that w.p.  $\geq 1 - n^{-2}$ , at least one of the  $I_i$  segments exhibits a robust bias at scale  $\lambda$  and is not bad. We will say that a pair  $I_i$ ,  $J_i$  is bad, if  $I_i$  does not exhibit robust bias at scale  $\lambda$ , or if  $\Pr[\mathcal{Q}_{\ell,\lambda}(I_i,J_i)] \geq \exp(-2c_0C^{7/12}h(C\log n))$ 

We have shown that for any bad or non-robust segment  $I_i$ , there exists a segment  $J_i$  such that  $(I_i, J_i)$  are bad. We will bound the probability that all the  $I_i$  segments are bad by union bounding over all the options of  $(J_1, \ldots, J_m)$  and the probability that the pairs  $(I_i, J_i)$  are all bad.

We first note that there are  $(C \log n)^m = n^{o(1)}$  options for the assignment of the segments  $J_i$ , and we will prove that for any assignment of  $J_i$ , the probability that all the  $(I_i, J_i)$  pairs are bad is  $\leq n^{-3}$ .

Fix some choice of  $J_1, \ldots, J_m$ . We will show that the probability that  $(I_i, J_i)$  are all bad is very small. If the Bernoulli random variables  $B_i$  determining whether each pair was good or bad were independent of each other, the claim would follow trivially from Lemmas 3.1, 3.4 and 3.5. We will show that for  $r = 0.01C^{1/6} \log n/h(C \log n)$ , there are indices  $i_1, \ldots, i_r$  such that  $B_i$  are in some sense sufficiently close to being independently distributed.

We take  $i_1 = 1$  and for each  $k \ge 1$ , let  $N_k$  be

$$N_k \stackrel{def}{=} \bigcup_{i=1}^k (I_{i_j} \cup J_{i_j}).$$

Then, choose  $i_{k+1}$  such that  $I_{i_{k+1}}$  is distance at least  $2\ell'$  from  $N_k$ . Note that the  $2\ell'$ -neighborhood of  $N_k$  intersects at most  $2k\lceil 5\ell'/\ell \rceil \leq 12C^{1/6}k$  of the  $I_i$ , so such a choice is always possible when  $k \leq r$ .

Let  $\mathcal{G}_k$  be the  $\sigma$ -field generated by the bits of  $\mathbf{x}$  whose positions are in  $N_k$ , and let  $E_k$  denote the event that  $(I_{i_k}, J_{i_k})$  is a bad pair. Note that  $E_k$  is measurable with respect to  $\mathcal{G}_k$ .

First of all, note that whether  $I_{i_k}$  has clear robust bias at scale  $\lambda$  is independent of  $\mathcal{G}_{k-1}$ , so by Lemma 3.1, we have

$$\Pr\left(\begin{smallmatrix} I_{i_k} \text{ does not have clear} \\ \text{robust bias at scale } \lambda \end{smallmatrix} \mid \mathcal{G}_{k-1}\right) \leq e^{-\Omega(\ell/\lambda)} \leq e^{-\Omega(C^{7/12}h(C\log n))}$$

Next, we will estimate  $\Pr(\mathcal{Q}_{\ell,\lambda}(I_{i_k}, J_{i_k}) \mid \mathcal{G}_{k-1})$ . Suppose first that  $I_{i_k}$  and  $J_{i_k}$  are disjoint and distance  $\geq \ell'$  separated. Then, by Lemma 3.5, we have:

$$\Pr\left(\mathcal{Q}_{\ell,\lambda}(I_{i_k}, J_{i_k}) \mid \mathcal{G}_{k-1}\right) \le \ell' e^{-10c_0\ell/\lambda} + e^{-10c_0\ell'} \le e^{-9c_0C^{7/12}h(C\log n)}$$

In the last step, we use our assumption that  $\log n \le h(n) \le n$ , implying that for large enough C

$$h(n) \le \exp(\frac{1}{2}c_0C^{7/12}h(C\log n))$$

If instead  $I_{i_k}$  and  $J_{i_k}$  are within distance  $\ell'$  of each other, then let J be the interval formed by extending  $I_{i_k}$  on both sides by  $2\ell'$ , so that  $J_{i_k} \subseteq J$ . By our construction, it is also guaranteed that

J is disjoint from  $N_{k-1}$ , and so when conditioning on  $\mathcal{G}_{k-1}$ , none of its bits have been determined yet. Then, we may apply Lemma 3.4 to obtain

$$\Pr\left(\mathcal{Q}_{\ell,\lambda}(I_{i_k}, J_{i_k}) \mid \mathcal{G}_{k-1}\right) \le \Pr\left(\mathcal{Q}_{\ell,\lambda}(I_{i_k}, J) \mid \mathcal{G}_{k-1}\right) \le 3\ell' e^{-10c_0\ell/\lambda} + e^{-10c_0\ell'} \le e^{-9c_0C^{7/12}h(C\log n)} \tag{22}$$

Therefore

$$\Pr(E_1 \cap \ldots \cap E_r) \le e^{-\Omega(C^{7/12}h(C\log n))r} \le e^{-\Omega(C^{3/4}\log n)}$$

which is smaller than  $n^{-3}$  for large enough C, proving our claim.

# <span id="page-28-0"></span>B Proof of Lemma 4.6

*Proof.* We will prove the claim by induction on l. The proofs for the step and the base will be identical.

Let  $F(\mathbf{j}, l, n)$  be the maximal factor between the inaccuracy of our estimate of the oracle (i.e.  $\delta$ ) to our estimate of the  $\mathbf{j}$ th monomial.

We will show that the iteration step maintains

$$F(\mathbf{j}, l, n) \le \text{poly}(n, 1/c)^{C(j_l+1)} F(\mathbf{j}(1:l-1), l-1, n)$$

for some global constant C. From this, we can easily derive the bound

$$F(\mathbf{j}, l, n) \le \text{poly}(n, 1/c)^{C(j_l+1)}$$

We view the polynomial p as a polynomial in the last variable  $z_l$  whose coefficients are themselves degree  $\leq n$  polynomials in the first l-1 variables. In other words:

$$p(z_1, \dots, z_l) = p_{z_1, \dots, z_{l-1}}(z_l) = \sum_{0 \le i \le n} a_i(z_1, \dots, z_{l-1}) z_l^i$$

We will show that for any given point  $z_1, \ldots, z_{l-1}$ , we can compute  $a_j(z_1, \ldots, z_{l-1})$  to within an error of at most  $\operatorname{poly}(n, 1/c)^{(j+1)}\delta$ , given n queries to the oracle D. This will prove our claim, because we can use our induction and these queries to  $a_{j_l}(z_1, \ldots, z_{l-1})$  in order to compute the coefficient of its  $\mathbf{j}(1:l-1)$ th monomial.

We compute  $a_j(z_1, \ldots, z_{l-1})$  using Lagrange polynomials. For any  $-n \leq i \leq n$ , we define  $x_i = ic/n \in [-c, c]$ , and we define the Lagrange polynomials:

$$\mathcal{L}_i = \prod_{i' \neq i} \frac{x - x_{i'}}{x_i - x_{i'}}$$

A commonly used fact about these polynomials is that they can be used to interpolate. Indeed, let g(x) be a single-variable polynomial of degree  $\leq 2n$ , and consider the polynomial  $f(x) = \sum_i g(x_i) L_i(x)$ . Clearly, f(x) is a polynomial of degree 2n and because  $L_i(x_{i'}) = \delta_{i,i'}$ , we have that  $f(x_i) = g(x_i)$  at all the points in the interpolation. Since no non-zero polynomial of degree  $\leq 2n$  can have 2n + 1 roots, this implies that f(x) = g(x).

Define  $\lambda_{i,j}$  to be the coefficient of the jth monomial  $x^j$  of  $L_i(x)$ . If we can bound each  $|\lambda_{i,j}|$  from above, then using the triangle inequality, we can also bound our error for estimating  $a_j$ :

$$a_{j}(z_{1},...,z_{l-1}) = \sum_{i} \lambda_{i,j} p(z_{1},...,z_{l-1},x_{i})$$

$$= \sum_{i} (\lambda_{i,j} P(z_{1},...,z_{l-1},x_{i}) \pm \delta)$$

$$= \sum_{i} \lambda_{i,j} P(z_{1},...,z_{l-1},x_{i}) \pm \sum_{i} |\lambda_{i,j}| \delta.$$
(23)

We begin by writing an exact formula for  $\lambda_{i,j}$ :

<span id="page-29-0"></span>
$$\lambda_{i,j} = \sum_{\substack{J \subseteq \{-n, -n+1, \dots, n\} \\ i \notin J \land |J| = j}} \prod_{\substack{i' \neq i \\ i' \notin J}} \frac{-x_{i'}}{x_i - x_{i'}} \prod_{i' \in J} \frac{1}{x_i - x_{i'}}$$
(24)

For any  $-n \le i \ne i' \le n$ , we clearly have:

<span id="page-29-1"></span>
$$\frac{\left|x_{i}-x_{i'}\right|}{\frac{c}{n}}=\left|i-i'\right|\in\left[1,2n\right]$$
(25)

Furthermore, for all  $i \neq 0$ , clearly  $|x_i| \geq \frac{c}{n}$ . Combining (24) and (25), we have:

<span id="page-29-2"></span>
$$|\lambda_{i,j}| \leq \sum_{\substack{J \subseteq \{-n,-n+1,\dots,n\}\\i \notin J \land |J|=j}} \left| \prod_{\substack{i' \neq i\\i' \notin J}} \frac{-x_{i'}}{x_i - x_{i'}} \prod_{i' \in J} \frac{1}{x_i - x_{i'}} \right|$$

$$\leq {2n \choose j} \left(\frac{c}{n}\right)^{-j} \left| \prod_{\substack{-n \leq i' \leq n\\i' \neq 0, i}} \frac{x_{i'}}{x_i - x_{i'}} \right|$$

$$\leq n \left(\frac{2n^2}{c}\right)^j \frac{(n!)^2}{(n+i)!(n-i)!}$$

$$(26)$$

All that remains is to bound the fraction of at the end of equation (26). But it can be easily bounded by 1 with the following inequality that follows from basic Combinatorics. Let  $k = |i| \ge 0$ . Then:

$$\frac{(n+k)!}{n!k!} = \binom{n+k}{k} > \binom{n}{k} = \frac{n!}{(n-k)!k!}$$

This implies that  $|\lambda_{i,j}| \leq (2n)^{2j+1}c^{-j}$ , further implying that

$$F(\mathbf{j}, l, n) \le F(\mathbf{j}(1:l-1), l-1, n)(2n)^{2j+2}c^{-j} \le \dots \le (2n)^{2j_{\text{tot}}+2l}c^{-j_{\text{tot}}}$$

# <span id="page-30-0"></span>C Proof of Theorem 5.1

In this section, we will prove Theorem 5.1. This theorem is based on Theorem 5 of [Cha21b] and we base our proof on Chase's proof.

Let n be sufficiently large, and let  $\rho, \mu$  be as in Theorem 5.1. Let  $p_{\text{base}}$  be a polynomial in  $\mathcal{P}_n^{\mu}$ , and define  $p(z) = p_{\text{base}}(\rho z)$ . Showing that for some  $\theta \in [-n^{-2/5}, n^{-2/5}]$ , we have  $|p(e^{i\theta})| \ge \exp(-Cn^{\mu}\log^5 n)$ , will yield our main claim, so we will try to lower bound the maximum of p on this arc.

Let  $a = n^{-2/5}$  and  $r = a^{-1/2}$ . Let  $r_* \in [r]$  be such that

$$\sum_{j=1}^{r_*} \frac{1}{\log^2(j+3)} - \sum_{j=r_*+1}^r \frac{1}{\log^2(j+3)} \in [20, 21];$$

such an  $r_*$  clearly exists. Let

$$\begin{cases} \epsilon_j = +1 & \text{if } 1 \le j \le r_* \\ \epsilon_j = -1 & \text{if } r_* + 1 \le j \le r \end{cases}.$$

Let  $\lambda_a \in (1,2)$  be such that

$$\sum_{j=1}^{r} \frac{\lambda_a}{j^2 \log^2(j+3)} = 1.$$

Let

$$d_j = \frac{\lambda_a}{j^2 \log^2(j+3)}.$$

Define

$$\widetilde{h}(z) = \widetilde{\lambda}_a \sum_{j=1}^r \epsilon_j d_j z^j,$$

where  $\widetilde{\lambda}_a \in (1,2)$  is such that  $\widetilde{h}(1) = 1$ . Define

$$h(z) = (1 - a^{10})\widetilde{h}(z).$$

Let

$$\alpha = e^{ia}, \beta = e^{-ia},$$

and

$$I_t = \{ z \in \mathbb{C} : \arg(\frac{\alpha - z}{z - \beta}) = t \}$$

for  $t \ge 0$ . Note that  $I_0$  is the line segment connecting  $\alpha$  and  $\beta$  and  $I_a = \{e^{i\theta} : |\theta| \le a\}$  is the set on which we wish to lower bound p at some point. Let

$$G_a = \{z \in \mathbb{C} : \arg(\frac{\alpha - z}{z - \beta}) \in (\frac{a}{2}, a)\}$$

be the open region bounded by  $I_{a/2}$  and  $I_a$ .

We use the same choice of h as [Cha21b]. It is designed to satisfy (i)  $|h(e^{2\pi it})| \le 1 - c|t|$  for  $|t| > a^{1/2}$  (up to logs). In this paper, we need (ii)  $|h(e^{2\pi it})| \ge 1 - Ca^2$  for  $|t| \approx a$ . The following lemmas are proven in Chase's paper:

<span id="page-31-0"></span>**Lemma C.1** (Lemma 3 of [Cha21b]). For any  $t \in [-\pi, \pi]$ ,  $\widetilde{h}(e^{it}) \in \overline{\mathbb{D}}$ .

<span id="page-31-1"></span>**Lemma C.2** (Lemma 4 of [Cha21b]). There are absolute constants  $c_4, c_5, C_6 > 0$  such that the following hold for a > 0 small enough. First,  $h(e^{2\pi it}) \in G_a$  for  $|t| \le c_4 a$ . Second,  $|h(e^{2\pi it})| \le 1 - c_5 \frac{|t|}{\log^2(a^{-1})}$  for  $t \in [\frac{-1}{2}, \frac{1}{2}] \setminus [-C_6 a^{1/2}, C_6 a^{1/2}]$ .

Lemmas C.1 and C.2 are used in the same manner as Chase, so we do not repeat their proofs. However, the next lemmas are slightly adapted to our case, because we will want to evaluate our polynomial at a point z with absolute value strictly lower than 1.

Let 
$$m = c_4^{-1} n^{2/5}$$
,  $J_1 = c_5^{-1} n^{-1/5} m \log^4 n$ , and  $J_2 = m - J_1$ .

<span id="page-31-6"></span>**Lemma C.3.** Suppose  $u(z) = \eta z^d - \zeta$  for some  $\zeta \in \partial \mathbb{D}$ , integer  $1 \leq d \leq a^{1/2}$  and some  $\eta \in [0,1]$ . Then, for any  $\delta \in [0,1)$ , we have  $\prod_{j=J_1}^{J_2-1} |u(h(e^{2\pi i \frac{j+\delta}{m}}))| \leq \exp(Cn^{1/5} \log^5 n)$ .

*Proof.* First note that

<span id="page-31-2"></span>
$$|u(h(e^{2\pi i\theta}))| \ge 1 - \eta |h(e^{2\pi i\theta})|^d \ge 1 - (1 - a^{10})^d \ge a^{10}.$$
(27)

Define  $g(t) = 2 \log |u(h(e^{2\pi i(t + \frac{\delta}{m})}))|$ . For notational ease, we assume  $\delta = 0$ ; the argument about to come works for all  $\delta \in [0, 1)$ . Since (27) implies g is  $C^1$ , by the mean value theorem we have

$$\left| \frac{1}{m} \sum_{j=J_1}^{J_2-1} g\left(\frac{j}{m}\right) - \int_{J_1/m}^{J_2/m} g(t)dt \right| = \left| \sum_{j=J_1}^{J_2-1} \int_{j/m}^{(j+1)/m} \left(g(t) - g\left(\frac{j}{m}\right)\right) dt \right|$$

$$\leq \sum_{j=J_1}^{J_2-1} \int_{j/m}^{(j+1)/m} \left(\max_{\frac{j}{m} \leq y \leq \frac{j+1}{m}} |g'(y)|\right) \frac{1}{m} dt$$

$$\leq \frac{1}{m^2} \sum_{j=J_1}^{J_2-1} \max_{\frac{j}{m} \leq y \leq \frac{j+1}{m}} |g'(y)|. \tag{28}$$

Since  $w \mapsto \log |u(h(w))|$  is harmonic and  $\log |u(h(0))| = \log |u(0)| = 0$ , we have

$$\int_0^1 g(t)dt = 2 \int_0^1 \log|u(h(e^{2\pi it}))|dt = 0,$$

and therefore

<span id="page-31-4"></span>
$$\left| \int_{J_1/m}^{J_2/m} g(t)dt \right| \le \left| \int_0^{J_1/m} g(t)dt \right| + \left| \int_{J_2/m}^1 g(t)dt \right|. \tag{29}$$

Since

<span id="page-31-3"></span>
$$a^{10} \le |u(h(e^{2\pi it}))| \le 2$$

for each t, we have

<span id="page-31-5"></span>
$$\left| \int_0^{J_1/m} g(t)dt \right| + \left| \int_{J_2/m}^1 g(t)dt \right| \le 20 \left( \frac{J_1}{m} + (1 - \frac{J_2}{m}) \right) \log n \le C \frac{\log^5 n}{n^{1/5}}.$$
 (30)

By (28), (29), and (30), we have

$$\left| \frac{1}{m} \sum_{j=J_1}^{J_2-1} g(\frac{j}{m}) \right| \le C \frac{\log^5 n}{n^{1/5}} + \frac{1}{m^2} \sum_{j=J_1}^{J_2-1} \max_{\frac{j}{m} \le t \le \frac{j+1}{m}} |g'(t)|$$

Multiplying through by m, changing C slightly, and exponentiating, we obtain

<span id="page-32-2"></span>
$$\prod_{j=J_1}^{J_2-1} \left| u(h(e^{2\pi i \frac{j}{m}})) \right|^2 \le \exp\left( C n^{1/5} \log^5 n + \frac{1}{m} \sum_{j=J_1}^{J_2-1} \max_{\frac{j}{m} \le t \le \frac{j+1}{m}} |g'(t)| \right). \tag{31}$$

Note

$$g'(t_0) = \frac{\frac{\partial}{\partial t} \left[ |u(h(e^{2\pi it}))|^2 \right] \Big|_{t=t_0}}{|u(h(e^{2\pi it_0}))|^2}.$$

We first show

<span id="page-32-1"></span>
$$\frac{\partial}{\partial t} \left[ |u(h(e^{2\pi it}))|^2 \right] \Big|_{t=t_0} \le 500d \tag{32}$$

for each  $t_0 \in [0,1]$ . Let  $\widetilde{d}_j = d_j$  for  $j \leq r_*$  and  $\widetilde{d}_j = -d_j$  for  $j > r_*$  so that  $h(e^{2\pi it}) = (1 - a^{10}) \sum_{j=1}^r \widetilde{d}_j e^{2\pi itj}$ . Then,

$$\left| u \left( h(e^{2\pi i t}) \right) \right|^{2} = \left| \eta \left( 1 - a^{10} \right)^{d} \left( \sum_{j=1}^{r} \widetilde{d}_{j} e^{2\pi i j t} \right)^{d} - \zeta \right|^{2}$$

$$= \eta \left( 1 - a^{10} \right)^{2d} \left[ \left| \sum_{j=1}^{r} \widetilde{d}_{j} e^{2\pi i j t} \right|^{2} \right]^{d} - 2\eta \operatorname{Re} \left[ \left( 1 - a^{10} \right)^{d} \zeta \left( \sum_{j=1}^{r} \widetilde{d}_{j} e^{2\pi i j t} \right)^{d} \right] + 1.$$
(33)

The derivative of the first term is

<span id="page-32-0"></span>
$$(1-a^{10})^{2d}\eta d \left[ \left| \sum_{j=1}^{r} \widetilde{d}_{j} e^{2\pi i j t} \right|^{2} \right]^{d-1} \sum_{j_{1}, j_{2}=1}^{r} \widetilde{d}_{j_{1}} \widetilde{d}_{j_{2}} 2\pi (j_{1}-j_{2}) e^{2\pi i (j_{1}-j_{2})t}.$$

Since

$$\sum_{i=1}^{r} \left| \widetilde{d}_{j} \right| = \widetilde{\lambda}_{a} \le 1 + 4a^{1/2}$$

and

$$\sum_{j=1}^{r} \left| j\widetilde{d}_{j} \right| \leq 4,$$

we get an upper bound of 250d for the absolute value of the derivative of the first term of (33). The derivative of the second term, if  $\zeta = e^{i\theta}$ , is

$$2(1-a^{10})^{d}\eta \sum_{1 \leq j_{1},\dots,j_{d} \leq r} 2\pi(j_{1}+\dots+j_{d})\widetilde{d}_{j_{1}}\cdots\widetilde{d}_{j_{d}}\sin(2\pi(j_{1}+\dots+j_{d})t+\theta),$$

which is also clearly upper bounded by (crudely) 250d. We've thus shown (32).

Recall  $|u(h(e^{2\pi i\theta}))| \ge 1 - |h(e^{2\pi i\theta})|^d \eta$ . For  $j \in [J_1, J_2] \subseteq [C_6 a^{1/2} m, (1 - C_6 a^{1/2})m]$ , we use (by Lemma C.2)

$$\left| h(e^{2\pi i \frac{j}{m}}) \right| \le 1 - c_5 \frac{\min(\frac{j}{m}, 1 - \frac{j}{m})}{\log^2 n}$$

to obtain

$$g'(t) \le \frac{1}{m} \sum_{j=J_1}^{J_2-1} \max_{\frac{j}{m} \le t \le \frac{j+1}{m}} |g'(t)| \le \frac{1}{m} \sum_{j=J_1}^{J_2-1} \frac{500d}{\left(1 - \eta \left(1 - c_5 \frac{\min(\frac{j}{m}, 1 - \frac{j}{m})}{\log^2 n}\right)^d\right)^2}.$$

Up to a factor of 2, we may deal only with  $j \in [J_1, \frac{m}{2}]$ . Let  $J_* = c_5^{-1} d^{-1} m \log^2 n$ . Note that  $j \leq J_*$  implies  $c_5 \frac{j}{m \log^2 n} \leq d^{-1}$  and  $j \geq J_*$  implies  $c_5 \frac{j}{m \log^2 n} \geq d^{-1}$ . Thus, using  $(1-x)^d \leq 1 - \frac{1}{2}xd$  for  $x \leq \frac{1}{d}$ , we have

<span id="page-33-0"></span>
$$\frac{1}{m} \sum_{j=J_1}^{\min(J_*,m/2)} \frac{500d}{\left(1 - \eta \left(1 - c_5 \frac{j}{m \log^2 n}\right)^d\right)^2} \leq \frac{500d}{m} \sum_{j=J_1}^{\min(J_*,m/2)} \frac{1}{\left(\frac{1}{2}c_5 \left(1 - c_5 \frac{j}{m \log^2 n}\right)^d\right)^2} \\
= \frac{2000m \log^4 n}{c_5^2 d} \sum_{j=J_1}^{\min(J_*,m/2)} \frac{1}{j^2} \\
\leq \frac{2000m \log^4 n}{c_5^2 d} \frac{2}{J_1} \leq Cn^{\mu}.$$
(34)

Finally, since there is some c > 0 such that  $(1 - x)^l \le 1 - c$  for all  $l \in \mathbb{N} \setminus \{0\}$  and  $x \in [l^{-1}, 1]$ , using the notation  $\sum_{i=a}^b x_i = 0$  if a > b, we see that

<span id="page-33-1"></span>
$$\frac{1}{m} \sum_{j=\min(J_*,m/2)}^{m/2} \frac{500d}{\left(1 - \eta \left(1 - c_5 \frac{j}{m \log^2 n}\right)^d\right)^2} \le \frac{500d}{m} \sum_{j=\min(J_*,m/2)}^{m/2} c^{-2}$$

$$\le Cd$$

$$\le Cn^{\mu}.$$
(35)

Combining (34) and (35), we obtain

$$\frac{1}{m} \sum_{j=J_1}^{J_2-1} \max_{\frac{j}{m} \le t \le \frac{j+1}{m}} |g'(t)| \le C n^{\mu}.$$

Plugging this upper bound into (31) yields the desired result.

Let  $Q_n$  denote all polynomials of the form  $(z - \alpha)(z - \beta)p(\eta z)$  for  $p \in \mathcal{P}_n$  and  $\eta \in [0, 1]$ .

<span id="page-33-3"></span>Corollary C.4. For any  $q \in \mathcal{Q}_n$  and  $\delta \in [0,1), \prod_{j \notin \{0,m-1\}} |q(h(e^{2\pi i \frac{j+\delta}{m}}z))| \le \exp(Cn^{1/5}\log^5 n)$ .

*Proof.* Take  $q \in \mathcal{Q}_n$ ; say  $q(z) = (z - \alpha)(z - \beta)p(\eta z)$  for  $p \in \mathcal{P}_n$ . For  $j \in \{1, \ldots, J_1 - 1\}$  and for  $j \in \{J_2, \ldots, m-2\}$ , by Lemma C.1 we can bound  $|q(h(e^{2\pi i \frac{j}{m}}z))| \leq 4n$ , to obtain

<span id="page-33-2"></span>
$$\prod_{\substack{j \notin \{J_1, \dots, J_2 - 1\}}} |q(h(e^{2\pi i \frac{j + \delta}{m}}))| \le (4n)^{J_1 - 1 + m - J_2 - 1} \le e^{Cn^{1/5} \log^5 n}.$$
(36)

By applying Lemma C.3 to  $u(z) := z - \alpha$  and to  $u(z) := z - \beta$  and multiplying the results, we see

<span id="page-34-2"></span>
$$\prod_{j=J_1}^{J_2-1} |\overline{u}(h(e^{2\pi i \frac{j+\delta}{m}}))| \le e^{Cn^{1/5} \log^5 n}, \tag{37}$$

where  $\overline{u}(z) := (z - \alpha)(z - \beta)$ . Let  $\widetilde{p}(z) \in \{1, 1 - z^d\}$  be the truncation of p to terms of degree less than  $n^{1/5}$ . Then, since Lemma C.2 gives

$$|\eta h(e^{2\pi i \frac{j+\delta}{m}})| \le 1 - c_5 \frac{\min\left(\frac{j}{m} + \delta, 1 - (\frac{j}{m} + \delta)\right)}{\log^2 n} \le 1 - c' n^{-1/5} \log^2 n$$

for  $j \in \{J_1, ..., J_2 - 1\}$ , we see

<span id="page-34-0"></span>
$$\left| p \left( \eta h(e^{2\pi i \frac{j+\delta}{m}}) \right) - \widetilde{p} \left( \eta h(e^{2\pi i \frac{j+\delta}{m}}) \right) \right| \le n e^{-c' \log^2 n} \le e^{-c \log^2 n}. \tag{38}$$

Lemma C.2 implies

<span id="page-34-1"></span>
$$\prod_{j=J_1}^{J_2-1} |\widetilde{p}(\eta h(e^{2\pi i \frac{j+\delta}{m}}))| \le e^{Cn^{1/5} \log^5 n}.$$
 (39)

By an easy argument given in [Cha21b], (38) and (39) combine to give

<span id="page-34-3"></span>
$$\prod_{j=J_1}^{J_2-1} |p(\eta h(e^{2\pi i \frac{j+\delta}{m}}))| \le e^{C'n^{1/5} \log^5 n}.$$
 (40)

Combining (36), (37), and (40), the proof is complete.

<span id="page-34-5"></span>**Proposition C.5.** For any  $q \in \mathcal{Q}_n$ , it holds that  $\max_{w \in G_a} |q(w)| \ge \exp(-Cn^{1/5} \log^5 n)$ .

*Proof.* Let  $g(z) = \prod_{j=0}^{m-1} q(h(e^{2\pi i \frac{j}{m}} z))$ . For  $z = e^{2\pi i \theta}$ , with, without loss of generality,  $\theta \in [0, \frac{1}{m})$ , we have by Lemma C.2 and Corollary C.4

$$|g(z)| \leq \left( \max_{w \in G_a} |q(w)| \right)^2 \prod_{j \not \in \{0, m-1\}} |q(h(e^{2\pi i (\frac{j}{m} + \theta)}))| \leq \left( \max_{w \in G_a} |q(w)| \right)^2 \exp(C n^{1/5} \log^5 n).$$

Thus,  $(\max_{w \in G_a} |q(w)|)^2 \exp(Cn^{1/5} \log^5 n) \ge \max_{z \in \partial \mathbb{D}} |g(z)| \ge |g(0)| = 1$ , where the last inequality used the maximum modulus principle (clearly g is analytic).

The following lemma was proven in [BE97].

<span id="page-34-4"></span>**Lemma C.6.** Suppose g is an analytic function in the open region bounded by  $I_0$  and  $I_a$ , and suppose g is continuous on the closed region between  $I_0$  and  $I_a$ . Then,

$$\max_{z \in I_{a/2}} |g(z)| \le \left( \max_{z \in I_0} |g(z)| \right)^{1/2} \left( \max_{z \in I_a} |g(z)| \right)^{1/2}.$$

Proof of Theorem [5](#page-20-1).1. Take f ∈ Pn, and let g(z) = (z−α)(z−β)f(ηz). A straightforward geometric argument yields

$$|g(z)| \le \frac{|(z-\alpha)(z-\beta)|}{1-\eta|z|} \le \frac{2}{\sin(a)} \le 3n^{2/5}$$

for z ∈ I0. Letting L = ||g||I<sup>a</sup> , Lemma [C.6](#page-34-4) then gives

$$\max_{z \in I_{a/2}} |g(z)| \le (3Ln^{2/5})^{1/2}.$$

Since we then have

$$\max_{z \in I_{a/2} \cup I_a} |g(z)| \le \max(L, (3Ln^{2/5})^{1/2}),$$

the maximum modulus principle implies

$$\max_{z \in G_a} |g(z)| \le \max(L, (3Ln^{2/5})^{1/2}).$$

By Proposition [C.5,](#page-34-5) we conclude

$$\exp(-Cn^{1/5}\log^5 n) \le \max(L, (3Ln^{2/5})^{1/2})$$
.

Thus,

$$||f||_{\eta I_a} \ge \frac{1}{4}||g||_{I_a} = \frac{L}{4} \ge \exp(-C'n^{1/5}\log^5 n),$$

as desired.