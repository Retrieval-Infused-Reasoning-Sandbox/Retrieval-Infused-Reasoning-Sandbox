# **AUTOMORPHISM AND COHOMOLOGY II: COMPLETE INTERSECTIONS**

#### XI CHEN† , XUANYU PAN, AND DINGXIN ZHANG

Abstract. We prove that the automorphism group of a general complete intersection *X* in CP*<sup>n</sup>* is trivial with a few well-understood exceptions. We also prove that the automorphism group of a complete intersection *X* acts on the cohomology of *X* faithfully with a few well-understood exceptions.

#### Contents

| 1.         | Introduction                                                             | 1  |
|------------|--------------------------------------------------------------------------|----|
| 2.         | Equivariant Kodaira Spencer Map                                          | 3  |
| 3.         | Equivariant Deformations                                                 | 13 |
| 4.         | Automorphism and Cohomology                                              | 16 |
|            | Appendix A.<br>The infinitesimal Torelli theorem over an arbitrary field | 21 |
| References |                                                                          | 26 |

## 1. Introduction

<span id="page-0-0"></span>In this paper we prove two results concerning automorphisms of complete intersections in projective spaces: one on their "generic triviality" and the other on the faithfulness of their actions on cohomology groups.

The earliest result in the first direction, to the best of our knowledge, is due to H. Matsumura and P. Monsky [\[MM64\]](#page-25-1):

<span id="page-0-1"></span>**Theorem 1.1** (Matsumura and Monsky)**.** *Let X be a smooth hypersurface in* P *n of degree d over a field k. Then*

- Aut(*X*) *is finite if n* ≥ 3*, d* ≥ 3 *and* (*n, d*) 6= (3*,* 4)*;*
- Aut(*X*) = {1} *if X is generic, n* ≥ 3 *and d* ≥ 3 *except the case that* (*n, d*) = (3*,* 4) *and* char(*k*) *>* 0*.*

Naturally, one may ask whether this result generalizes to complete intersections. Let us first make the following definition.

*Date*: October 6, 2019.

<sup>2020</sup> *Mathematics Subject Classification.* Primary 14J50; Secondary 14F20.

*Key words and phrases.* Automorphisms, Complete Intersections, Deformation Theory.

<sup>†</sup> Research partially supported by NSERC 262265.

**Definition 1.2.** Let *k* be a field and *X* be a closed subscheme of P *n k* . The linear automorphism group of *X* with respect to the projective embedding *X* ⊂ P *n k* , denoted by Aut*L*(*X*), is the subgroup of **PGL***n*+1(*k*) whose linear action on P *n k* takes *X* onto *X* itself.

The first part of Theorem [1.1](#page-0-1) was generalized to complete intersections by O. Benoist [\[Ben13\]](#page-25-2). He proved that Aut*L*(*X*) is finite for a smooth complete intersection *X* ⊂ P *<sup>n</sup>* with some well-known exceptions. In this paper we study the automorphism group of a generic complete intersection.

<span id="page-1-0"></span>**Theorem 1.3.** *Let X be a smooth complete intersection in* P *n k of type* (*d*1*, d*2*, . . . , dc*) *over an algebraically closed field k, i.e., X* = *X*<sup>1</sup> ∩ *X*<sup>2</sup> ∩ *. . .* ∩ *X<sup>c</sup> with* deg *X<sup>i</sup>* = *di. If* dim *X* ≥ 2*,* deg *X* ≥ 3 *and* 2 ≤ *d*<sup>1</sup> ≤ *d*<sup>2</sup> ≤ *. . .* ≤ *dc, then*

- (1) Aut*L*(*X*) = {1} *for* char(*k*) = 0 *and* |Aut*L*(*X*)| = (char(*k*))*<sup>r</sup> for* char(*k*) *>* 0 *and some r* ∈ N *when X is a general complete intersection of type* (*d*1*, d*2*, . . . , dc*) 6= (2*,* 2)*, and*
- (2) Aut*L*(*X*) = (Z*/*2Z) *<sup>n</sup> for X general of type* (2*,* 2) *and* char(*k*) 6= 2*.*

*Remark* 1.4*.* Retain the hypotheses and notation of Theorem [1.3](#page-1-0) and suppose that *X* is one of the following smooth complete intersections in CP*<sup>n</sup>*:

- dim *X* ≥ 3, or
- dim *X* ≥ 2 and *ω<sup>X</sup>* 6= O*X*, or
- dim *X* = 2, *ω<sup>X</sup>* ∼= O*<sup>X</sup>* and rank<sup>Z</sup> Pic(*X*) = 1, i.e., *X* is a K3 surface of Picard rank 1.

Then it is known that Aut(*X*) = Aut*L*(*X*). Thus, by Theorem [1.3,](#page-1-0) when *X* is general in its moduli, the automorphism group of *X* is trivial.

The triviality of Aut*L*(*X*) for a general complete intersection *X* ⊂ CP*<sup>n</sup>*, to the best of our knowledge, was only known in some special cases:

- aforementioned hypersurface case [\[MM64\]](#page-25-1);
- 3 ≤ *d*<sup>1</sup> *< d*<sup>2</sup> ≤ *...* ≤ *d<sup>c</sup>* [\[JL17,](#page-25-3) Lemma 2.12];
- (*d*1*, d*2*, ..., dc*) = (2*,* 2*,* 2) [\[JL17,](#page-25-3) Lemma 2.13].

For a very general complete intersection *X* of Calabi-Yau or general type in CP*<sup>n</sup>*, we have a stronger statement: there are no non-trivial dominant rational self maps *σ* : *X* 99K *X* [\[Che13\]](#page-25-4).

Our second result, which is derived from Theorem [1.3](#page-1-0) above and the method in the papers [\[Pan18\]](#page-25-5) and [\[Pan16\]](#page-25-6) of the second author, is about the faithfulness of the action of Aut(*X*) on its étale cohomology group. Questions about this faithfulness was explored for varieties of low dimension, and Burns, Rapoport, Shafarevich, Ogus . . . confirm this question for K3 surfaces. Few high-dimensional varieties are known to have a positive answer to this question.

<span id="page-1-1"></span>**Theorem 1.5.** *Let k be an algebraically closed field and X be a smooth complete intersection in* P *n k of type* (*d*1*, d*2*, . . . , dc*)*. Suppose that* deg *X* ≥ 3 *and* 2 ≤ *d*<sup>1</sup> ≤ *d*<sup>2</sup> ≤ *. . .* ≤ *dc. Let ℓ be a prime different from* char(*k*)*.*

(1) *If* (*d*1*, d*2*, . . . , dc*) = (2*,* 2)*,* char(*k*) 6= 2 *and* dim(*X*) = *m*(*>* 1) *is odd (resp. even), then the kernel of*

$$\operatorname{Aut}(X) \to \operatorname{Aut}(\operatorname{H}^m_{\operatorname{\acute{e}t}}(X, \mathbb{Q}_\ell))$$

is  $(\mathbb{Z}/2\mathbb{Z})^{m+1}$  (resp. trivial) for X general.

<span id="page-2-1"></span>(2) Suppose that X is not an elliptic curve and is not a quadric hypersurface. If  $(d_1, d_2, \ldots, d_c) \neq (2, 2)$ , then the map

$$(1.5.1) \operatorname{Aut}(X) \to \operatorname{Aut}(\operatorname{H}^{m}_{\operatorname{\acute{e}t}}(X, \mathbb{Q}_{\ell}))$$

is injective.

Let us remark that the validity of item 1.5 (2) relies on certain infinitesimal Torelli results for complete intersections, i.e., the injectivity of the cup product map

(1.5.2) 
$$H^1(X, T_X) \to \bigoplus_{p+q=m} \text{Hom}(H^q(X, \Omega_X^p), H^{q+1}(X, \Omega_X^{p-1})).$$

The injectivity indeed holds true for all smooth complete intersections except some trivial cases when the characteristic of the ground field k is zero (result of [Fle86]). In fact, Flenner's idea also generalizes to an algebraically closed field without assuming  $k = \mathbb{C}$ . We include a proof of this result in an appendix to the paper.

Let us briefly describe the structure of this paper.

In Section 2, we prove the generic triviality of  $\operatorname{Aut}_L(X)$  by studying the action of  $\operatorname{Aut}(X)$  on  $\operatorname{H}^1(T_X)$ . In Section 3, we use equivariant deformation theory to derived Theorem 1.5(2) from Theorem 1.3 when  $k=\mathbb{C}$ . The last section proves Theorem 1.5(1) and uses the theory in [Pan16] to finish the proof of Theorem 1.5(2) for an arbitrary field.

Acknowledgments. The second author thanks Prof. Johan de Jong for proposing the questions about automorphism and cohomology in a 2014 summer school at Seattle. We thank A. Javanpeykar and D. Loughran for some email exchange explaining their work to us.

## 2. Equivariant Kodaira Spencer Map

<span id="page-2-0"></span>In this section, we will prove the triviality of  $\operatorname{Aut}_L(X)$  for generic complete intersections  $X \subset \mathbb{P}^n_k$ . This is achieved by studying the natural action  $\operatorname{Aut}(X)$  on  $\operatorname{H}^1(T_X)$ . We make the following simple observation on this action: if  $\sigma \in \operatorname{Aut}(X)$  can be "deformed" as X deforms in a family, then  $\sigma$  preserves the Kodaira-Spencer classes of this family at X.

<span id="page-2-2"></span>**Proposition 2.1.** Let  $\pi: X \to B$  be a flat family of projective varieties over a smooth variety B with  $\pi$  smooth and proper, where X and B are varieties over an algebraically closed field. Then for a very general point  $b \in B$ ,  $\operatorname{Aut}(X_b)$  acts trivially on the image of the Kodaira-Spencer map  $\kappa: T_{B,b} \to \operatorname{H}^1(T_{X_b})$ . If we fix a line bundle L of X relatively ample over B, then for a general point  $b \in B$ ,  $\operatorname{Aut}_L(X_b)$  acts trivially on  $\kappa(T_{B,b})$ .

*Proof.* Note that  $\operatorname{Aut}(X_b)$  is a locally Noetherian scheme. At a very general point b, every  $\sigma_b \in \operatorname{Aut}(X_b)$  can be "deformed" over B. That is, after shrinking B and a base change unramified over b, there exists a  $\sigma \in \operatorname{Aut}(X/B)$  such that  $\sigma_b$  is the restriction of  $\sigma$  to b, where  $\operatorname{Aut}(X/B)$  is the automorphism group of X preserving

B. This gives us the commutative diagram

$$(2.1.1) X \xrightarrow{\sigma} X$$

which leads to the commuting exact sequences

$$(2.1.2) 0 \longrightarrow T_{X_b} \longrightarrow T_X \Big|_{X_b} \longrightarrow N_{X_b/X} \longrightarrow 0$$

$$\downarrow^{\sigma_{b,*}} \qquad \downarrow^{\sigma_*} \qquad \parallel$$

$$0 \longrightarrow T_{X_b} \longrightarrow T_X \Big|_{X_b} \longrightarrow N_{X_b/X} \longrightarrow 0$$

where  $N_{X_b/X} \cong \pi^* T_{B,b}$  is the normal bundle of  $X_b$  in X. Consequently, the resulting Kodaira-Spencer map commutes with the action of  $\sigma_b$ , i.e., the diagram

(2.1.3) 
$$T_{B,b} \xrightarrow{\kappa} H^{1}(T_{X_{b}})$$

$$\downarrow \qquad \qquad \downarrow^{\sigma_{b,*}}$$

$$T_{B,b} \xrightarrow{\kappa} H^{1}(T_{X_{b}})$$

commutes. Therefore, the image of  $\kappa$  is fixed under the action of  $\sigma_b$ .

If we fix a polarization L,  $\operatorname{Aut}_L(X_b)$  is a scheme. Therefore, at a general point b, every  $\sigma_b \in \operatorname{Aut}_L(X_b)$  can be "deformed" over B. Then the above argument shows that  $\kappa(T_{B,b})$  is fixed under the action of  $\sigma_b$ .

As a complete intersection  $X \subset \mathbb{P}^n$  of type  $(d_1, d_2, \ldots, d_c)$  deforms in  $\mathbb{P}^n$ , the image of the Kodaira-Spencer map is exactly the cokernel  $\operatorname{coker}(J_X)$  of  $J_X$  given in the diagram

$$(2.1.4) \qquad \qquad H^{0}(\mathcal{O}_{X}(1))^{\oplus n+1} \xrightarrow{J_{X}} \bigoplus_{i=1}^{c} H^{0}(\mathcal{O}_{X}(d_{i}))$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$0 \longrightarrow H^{0}(T_{X}) \longrightarrow H^{0}(T_{\mathbb{P}^{n}}|_{X}) \longrightarrow H^{0}(N_{X/\mathbb{P}^{n}})$$

where  $H^0(\mathcal{O}_X(1))^{\oplus n+1} \to H^0(X, T_{\mathbb{P}^n})$  is induced by the Euler sequence and  $N_{X/\mathbb{P}^n}$  is the normal bundle of  $X \subset \mathbb{P}^n$ . Thus, by Proposition 2.1,  $\operatorname{Aut}_L(X)$  acts trivially on  $\operatorname{coker}(J_X)$  for X general.

Since Benoist [Ben13] has shown that  $\operatorname{Aut}_L(X)$  is finite under the hypothesis of Theorem 1.3, every  $\sigma \in \operatorname{Aut}_L(X)$  has finite order. Suppose that  $\operatorname{Aut}_L(X) \neq \{1\}$  and  $|\operatorname{Aut}_L(X)| \neq (\operatorname{char}(k))^r$  if  $\operatorname{char}(k) > 0$ . Then there exists  $\sigma \in \operatorname{Aut}_L(X)$  of order p for some prime  $p \neq \operatorname{char}(k)$ . That is,  $\sigma^p = 1$  and  $\sigma \neq 1$ .

Since  $\sigma \in \operatorname{Aut}(\mathbb{P}^n)$ , it has a dual action on  $\mathbb{P}H^0(\mathcal{O}_{\mathbb{P}^n}(1))$  and hence on  $\mathbb{P}H^0(\mathcal{O}_{\mathbb{P}^n}(m))$  for all  $m \in \mathbb{Z}^+$ . Since  $p \neq \operatorname{char}(k)$ , the lifts of  $\sigma$  to  $H^0(\mathcal{O}_{\mathbb{P}^n}(m))$  are diagonalizable.

We may choose a lift of  $\sigma$  to  $H^0(\mathcal{O}_{\mathbb{P}^n}(1))$  such that

(2.1.5) 
$$H^{0}(\mathcal{O}_{\mathbb{P}^{n}}(m)) = \bigoplus E_{m,\xi}$$

where  $E_{m,\xi}$  is the eigenspace of  $\sigma$  acting on  $\mathrm{H}^0(\mathcal{O}_{\mathbb{P}^n}(m))$  corresponding to the eigenvalue  $\xi$  satisfying  $\xi^p = 1$ .

Since  $\sigma \in \operatorname{Aut}_L(X)$ ,  $\sigma \in \operatorname{Aut}_L(X_1 \cap X_2 \cap \ldots \cap X_l)$  for all  $d_l < d_{l+1}$ . Therefore,  $\sigma$  also acts on the subspace  $\operatorname{H}^0(I_{X_1 \cap X_2 \cap \ldots \cap X_l}(m)) \subset \operatorname{H}^0(\mathcal{O}_{\mathbb{P}^n}(m))$  and this action is also diagonalizable, where  $I_{X_1 \cap X_2 \cap \ldots \cap X_l}$  is the ideal sheaf of  $X_1 \cap X_2 \cap \ldots \cap X_l$  in  $\mathbb{P}^n$ . Thus, we can choose the defining equations  $F_1, F_2, \ldots, F_c$  of  $X_1, X_2, \ldots, X_c$  such that

(2.1.6) 
$$\begin{bmatrix} \sigma(F_1) \\ \sigma(F_2) \\ \vdots \\ \sigma(F_c) \end{bmatrix} = \begin{bmatrix} \xi_1 \\ \xi_2 \\ \vdots \\ \xi_c \end{bmatrix} \begin{bmatrix} F_1 \\ F_2 \\ \vdots \\ F_c \end{bmatrix}$$

for some  $\xi_i^p = 1$ . That is,  $F_i \in E_{d_i,\xi_i}$  for i = 1, 2, ..., c. Note that  $J_X$  is explicitly given by

<span id="page-4-0"></span>(2.1.7) 
$$J_X \begin{bmatrix} s_0 \\ s_1 \\ \vdots \\ s_n \end{bmatrix} = \begin{bmatrix} \frac{\partial F_i}{\partial z_j} \end{bmatrix}_{c \times (n+1)} \begin{bmatrix} s_0 \\ s_1 \\ \vdots \\ s_n \end{bmatrix}$$

for  $(z_0, z_1, ..., z_n)$  the homogeneous coordinates of  $\mathbb{P}^n$ .

Under our choice of the defining equations of X, the action of  $\sigma$  on  $\operatorname{coker}(J_X)$  is induced by

(2.1.8) 
$$\begin{bmatrix} G_1 \\ G_2 \\ \vdots \\ G_c \end{bmatrix}^{\sigma} = \begin{bmatrix} \xi_1^{-1} \\ & \xi_2^{-1} \\ & & \ddots \\ & & & \xi_c^{-1} \end{bmatrix} \begin{bmatrix} \sigma(G_1) \\ \sigma(G_2) \\ \vdots \\ \sigma(G_c) \end{bmatrix}$$

for  $G_i \in H^0(\mathcal{O}(d_i))$ . This comes from the observation that  $\sigma$  sends an infinitesimal deformation  $\{F_i + t_i G_i = 0\}$  of X to

$$\{\sigma(F_i + t_i G_i) = 0\} = \{F_i + t_i \xi_i^{-1} \sigma(G_i) = 0\}.$$

The fact that  $\sigma$  acts trivially on  $\operatorname{coker}(J_X)$  is equivalent to saying that

(2.1.9) 
$$\begin{bmatrix} \sigma(G_1) - \xi_1 G_1 \\ \sigma(G_2) - \xi_2 G_2 \\ \vdots \\ \sigma(G_c) - \xi_c G_c \end{bmatrix} \in \operatorname{Im} J_X$$

for all  $G_i \in H^0(\mathcal{O}_{\mathbb{P}^n}(d_i))$ . In other words,

(2.1.10) 
$$\operatorname{Im} J_X + (E_{X,d_1,\xi_1} \oplus E_{X,d_2,\xi_2} \oplus \ldots \oplus E_{X,d_c,\xi_c}) \\ = \operatorname{H}^0(\mathcal{O}_X(d_1)) \oplus \operatorname{H}^0(\mathcal{O}_X(d_2)) \oplus \ldots \oplus \operatorname{H}^0(\mathcal{O}_X(d_c)),$$

where  $\operatorname{Im}(J_X)$  is the image of  $J_X$  and  $E_{X,d,\xi}$  is the restriction of  $E_{d,\xi} \subset \operatorname{H}^0(\mathcal{O}_{\mathbb{P}^n}(d))$  to  $\operatorname{H}^0(\mathcal{O}_X(d))$ . We will show that this cannot hold by a dimension count. That is, we are going to show that

(2.1.11) 
$$\dim \left( \operatorname{Im} J_X + (E_{X,d_1,\xi_1} \oplus E_{X,d_2,\xi_2} \oplus \ldots \oplus E_{X,d_c,\xi_c}) \right) < h^0(\mathcal{O}_X(d_1)) + h^0(\mathcal{O}_X(d_2)) + \ldots + h^0(\mathcal{O}_X(d_c)).$$

<span id="page-5-0"></span>Let

$$(2.1.12) a_j = \dim E_{1,\eta_j}$$

where  $\eta_0, \eta_1, \dots, \eta_{p-1}$  are the *p*-th roots of unit. Note that  $\sum a_j = n+1$  and at least two  $a_j$ 's are positive, i.e.,  $\mu \geq 2$  for

(2.1.13) 
$$\mu = \# \{j : a_j > 0, 0 \le j \le p - 1\}$$

<span id="page-5-1"></span>since  $\sigma \neq 1$ . Our argument for (2.1.11) is based on the following inequalities:

**Lemma 2.2.** Let X,  $J_X$ ,  $\sigma$ ,  $\xi_i$ ,  $E_{X,d_i,\xi_i}$  and  $a_j$  be given as above. Then

$$\dim \operatorname{Im} J_X - \dim \left( \operatorname{Im} J_X \cap \left( E_{X,d_1,\xi_1} \oplus E_{X,d_2,\xi_2} \oplus \ldots \oplus E_{X,d_c,\xi_c} \right) \right)$$

<span id="page-5-2"></span>(2.2.1) 
$$\leq (n+1)^2 - \sum_{j=0}^{p-1} a_j^2.$$

Proof of Lemma 2.2. We choose homogeneous coordinates  $(z_0, z_1, ..., z_n)$  of  $\mathbb{P}^n$  such that  $\sigma(z_i) = \lambda_i z_i$  for each i, where  $\lambda_i \in \{\eta_0, \eta_1, ..., \eta_{p-1}\}$ . We may identify  $H^0(\mathcal{O}_X(1))^{\oplus n+1}$  with the space of  $(n+1) \times (n+1)$  matrices via

$$\begin{bmatrix} b_{st} \end{bmatrix}_{0 \le s, t \le n} \begin{bmatrix} z_0 \\ z_1 \\ \vdots \\ z_n \end{bmatrix} \in \mathrm{H}^0(\mathcal{O}_X(1))^{\oplus n+1}.$$

For each j, let

$$V_j = \{ [b_{st}] : b_{st} = 0 \text{ for } \lambda_s \neq \eta_j \text{ or } \lambda_t \neq \eta_j \} \subset \mathrm{H}^0(\mathcal{O}_X(1))^{\oplus n+1}$$

Then by (2.1.7), we see that

<span id="page-5-4"></span>
$$J_X(V_0 \oplus V_1 \oplus \ldots \oplus V_{p-1}) \subset E_{X,d_1,\xi_1} \oplus E_{X,d_2,\xi_2} \oplus \ldots \oplus E_{X,d_c,\xi_c}.$$

<span id="page-5-3"></span>Combining with the fact that dim  $V_i = a_i^2$ , we arrive at (2.2.1).

**Lemma 2.3.** Let  $\sigma$ ,  $E_{d,\xi}$  and  $a_j$  be given as above. Then

(2.3.1) 
$${n+d \choose d} - \dim E_{d,\xi} > (n+1)^2 - \sum_{j=0}^{p-1} a_j^2$$

if  $d, n \geq 3$  and

<span id="page-5-5"></span>(2.3.2) 
$${n+2 \choose 2} - \dim E_{2,\xi} \ge \frac{(n+1)^2}{2} - \frac{1}{2} \sum_{j=0}^{p-1} a_j^2$$

for all  $\xi$ .

Proof of Lemma 2.3. Without loss of generality, we may assume that  $a_0 \ge a_1 \ge \ldots \ge a_{p-1}$ . We let  $V_j = E_{1,\eta_j}$  and write

$$(2.3.3) \qquad \begin{array}{c} \operatorname{H}^{0}(\mathcal{O}(d)) = \operatorname{Sym}^{d} V_{0} \oplus \sum_{j \neq 0} \operatorname{Sym}^{d-1} V_{0} \otimes V_{j} \\ \oplus \operatorname{Sym}^{d} V_{1} \oplus \sum_{j \neq 1} \operatorname{Sym}^{d-1} V_{1} \otimes V_{j} \\ \oplus \ldots \oplus \operatorname{Sym}^{d} V_{p-1} \oplus \sum_{j \neq p-1} \operatorname{Sym}^{d-1} V_{p-1} \otimes V_{j} \\ \oplus \sum_{i < j < k} \operatorname{Sym}^{d-2} V_{i} \otimes V_{j} \otimes V_{k} \oplus \ldots \end{array}$$

when  $d \geq 3$ . Note that  $\operatorname{Sym}^d V_0$ ,  $\operatorname{Sym}^{d-1} V_0 \otimes V_1$ , ...,  $\operatorname{Sym}^{d-1} V_0 \otimes V_{p-1}$  have different weights under the action of  $\sigma$ . Therefore,

$$\dim E_{d,\xi} \cap \left( \operatorname{Sym}^{d} V_{0} \oplus \sum_{j \neq 0} \operatorname{Sym}^{d-1} V_{0} \otimes V_{j} \right) \\
\leq \max \left( \dim \operatorname{Sym}^{d} V_{0}, \dim \operatorname{Sym}^{d-1} V_{0} \otimes V_{1}, \\
\dots, \dim \operatorname{Sym}^{d-1} V_{0} \otimes V_{p-1} \right) \\
= \max \left( \binom{a_{0} + d - 1}{d}, \binom{a_{0} + d - 2}{d - 1} \binom{a_{1}}{1} \right).$$

In other words,

<span id="page-6-0"></span>
$$\dim \left(\operatorname{Sym}^{d} V_{0} \oplus \sum_{j \neq 0} \operatorname{Sym}^{d-1} V_{0} \otimes V_{j}\right) \\
-\dim E_{d,\xi} \cap \left(\operatorname{Sym}^{d} V_{0} \oplus \sum_{j \neq 0} \operatorname{Sym}^{d-1} V_{0} \otimes V_{j}\right) \\
\geq \binom{a_{0} + d - 1}{d} + \sum_{j \neq 0} \binom{a_{0} + d - 2}{d - 1} \binom{a_{j}}{1} \\
- \max \left(\binom{a_{0} + d - 1}{d}, \binom{a_{0} + d - 2}{d - 1} \binom{a_{1}}{1}\right).$$

By the same argument, we have

<span id="page-6-1"></span>(2.3.6) 
$$\dim \left( \operatorname{Sym}^{d} V_{i} \oplus \sum_{j \neq i} \operatorname{Sym}^{d-1} V_{i} \otimes V_{j} \right)$$

$$- \dim E_{d,\xi} \cap \left( \operatorname{Sym}^{d} V_{i} \oplus \sum_{j \neq i} \operatorname{Sym}^{d-1} V_{i} \otimes V_{j} \right)$$

$$\geq \binom{a_{i} + d - 1}{d} + \sum_{\substack{j \neq i \ j \geq 1}} \binom{a_{i} + d - 2}{d - 1} \binom{a_{j}}{1}$$

for all  $i \geq 1$  and

<span id="page-7-0"></span>(2.3.7) 
$$\dim \left( \operatorname{Sym}^{d-2} V_i \otimes V_j \otimes \sum_{k>j} V_k \right)$$
$$-\dim E_{d,\xi} \cap \left( \operatorname{Sym}^{d-2} V_i \otimes V_j \otimes \sum_{k>j} V_k \right)$$
$$\geq \sum_{k>j+1} \binom{a_i+d-3}{d-2} \binom{a_j}{1} \binom{a_k}{1}$$

for all i < j. Combining (2.3.5), (2.3.6) and (2.3.7), we conclude

$$\binom{n+d}{d} - \dim E_{d,\xi} \ge \sum_{i} \binom{a_{i}+d-1}{d} + \sum_{\substack{i \neq j \\ j \ge 1}} \binom{a_{i}+d-2}{d-1} a_{j}$$

$$- \max\left(\binom{a_{0}+d-1}{d}, \binom{a_{0}+d-2}{d-1} a_{1}\right)$$

$$+ \sum_{i < j < k-1} \binom{a_{i}+d-3}{d-2} a_{j} a_{k}.$$

Note that the right hand side of (2.3.1) is simply  $\sum_{i < j} 2a_i a_j$ . So it suffices to verify the following:

<span id="page-7-2"></span>
$$(2.3.9) \qquad \begin{pmatrix} a_{i}+d-2 \\ d-1 \end{pmatrix} a_{j} + \begin{pmatrix} a_{j}+d-2 \\ d-1 \end{pmatrix} a_{i} \geq 2a_{i}a_{j} \text{ for } 1 \leq i < j$$

$$\begin{pmatrix} a_{0}+d-2 \\ d-1 \end{pmatrix} a_{j} + \begin{pmatrix} a_{j}+d-1 \\ d \end{pmatrix} \geq 2a_{0}a_{j} \text{ for } j \geq 2$$

$$\min \left( \begin{pmatrix} a_{0}+d-1 \\ d \end{pmatrix}, \begin{pmatrix} a_{0}+d-2 \\ d-1 \end{pmatrix} a_{1} \right) + \begin{pmatrix} a_{1}+d-1 \\ d \end{pmatrix} \geq 2a_{0}a_{1}$$

$$\sum_{i \leq j \leq k-1} \begin{pmatrix} a_{i}+d-3 \\ d-2 \end{pmatrix} a_{j}a_{k} \geq 0.$$

Therefore, we conclude

<span id="page-7-1"></span>(2.3.10) 
$$\binom{n+d}{d} - \dim E_{d,\xi} \ge \sum_{i < j} 2a_i a_j = (n+1)^2 - \sum_{j=0}^{p-1} a_j^2.$$

And the equality in (2.3.10) holds only if all equalities hold in (2.3.5), (2.3.6), (2.3.7) and (2.3.9), which cannot happen. So (2.3.1) follows.

<span id="page-7-3"></span>The proof of (2.3.2) is quite straightforward and we leave it to the readers.  $\Box$ 

**Lemma 2.4.** Let  $\sigma$ ,  $E_{d,\xi}$ ,  $a_j$  and  $\mu$  be given as above. Then

<span id="page-7-4"></span>(2.4.1) 
$$\dim E_{d,\xi} \leq \sum_{k=0}^{n+1-\mu} \frac{(\mu-1)^k}{\mu^{k+1}} \binom{n+d-k}{d} + \frac{(\mu-1)^{n+1-\mu}}{\mu^{n+2-\mu}} \binom{d+\mu-1}{d+1}$$

for all  $\xi$ .

Proof of Lemma 2.4. We let  $e(d, a_0, a_1, ..., a_{p-1})$  be the maximum of dim  $E_{d,\xi}$  for all  $\xi$  and all  $\sigma$  such that  $a_j = \dim E_{1,\eta_j}$ .

Let us choose homogeneous coordinates  $(z_0, z_1, \ldots, z_n)$  of  $\mathbb{P}^n$  such that  $\sigma(z_i) = \lambda_i z_0$  and  $\lambda_0, \lambda_1, \ldots, \lambda_{\mu-1}$  are distinct. We observe that for each monomial  $z_0^{b_0} z_1^{b_1} \ldots z_n^{b_n}$  with  $b_0 > 0$ ,  $z_0^{b_0} z_1^{b_1} \ldots z_n^{b_n} (z_i/z_0)$  have different weights under the action of  $\sigma$  for  $i = 0, 1, \ldots, \mu - 1$ . This observation leads to the recursive inequality

<span id="page-8-0"></span>
$$(2.4.2) e(d, a_0, a_1, \dots, a_{p-1}) \le \frac{1}{\mu} {n+d \choose d} + \frac{\mu-1}{\mu} e(d, a_0-1, a_1, \dots, a_{p-1})$$

where we assume that  $a_0 = \max(a_j)$  and  $\lambda_0 = \eta_0$ .

It is easy to check that (2.4.1) follows from (2.4.2) by induction.

Now we are ready to prove Theorem 1.3. By induction, we just have to deal with the following cases:

- $d_1 = d_2 = \cdots = d_c = d \ (d \ge 3 \text{ or } d, c \ge 2)$
- $2 = d_1 = d_2 < d_3 = \cdots = d_c = d$  and
- $2 = d_1 < d_2 = \cdots = d_c = d$ .

We only need to prove (2.1.11) in these cases.

The case  $d_1 = d_2 = \cdots = d_c = d$ . By (2.2.1), we have

$$\dim \left( \operatorname{Im} J_X + \left( E_{X,d,\xi_1} \oplus E_{X,d,\xi_2} \oplus \ldots \oplus E_{X,d,\xi_c} \right) \right)$$

(2.4.3) 
$$\leq (n+1)^2 - \sum_{j=0}^{p-1} a_j^2 + \sum_{i=1}^c \dim E_{X,d,\xi_i}.$$

Thus, in order to prove (2.1.11), it suffices to prove

<span id="page-8-4"></span>
$$(2.4.4) (n+1)^2 - \sum_{i=0}^{p-1} a_j^2 + \sum_{i=1}^c \dim E_{X,d,\xi_i} < ch^0(\mathcal{O}_X(d)) = c\binom{n+d}{d} - c^2.$$

If  $\xi_{i_1}, \xi_{i_2}, \dots, \xi_{i_l}$  are distinct, we observe that

<span id="page-8-1"></span>(2.4.5) 
$$\dim E_{X,d,\xi_{i_1}} + \dim E_{X,d,\xi_{i_2}} + \ldots + \dim E_{X,d,\xi_{i_l}} \le h^0(\mathcal{O}_X(d)).$$

We write  $\{1, 2, ..., c\} = B_1 \sqcup B_2 \sqcup ...$  as a disjoint union of sets  $B_i$  such that  $\xi_l = \xi_m$  if and only if  $\{l, m\} \subset B_i$  for some i. Let  $b_i = |B_i|$ . Note that

$$(2.4.6) \dim E_{d,\xi_l} - \dim E_{X,d,\xi_l} \ge b_i \text{ for } l \in B_i.$$

Suppose that  $b_1 \geq b_2 \geq \ldots$  Combining (2.4.5) and (2.4.6), we derive

<span id="page-8-2"></span>
$$\sum_{i=1}^{c} \dim E_{X,d,\xi_{i}} \leq b_{2}h^{0}(\mathcal{O}_{X}(d)) + \sum_{l \in B} \dim E_{X,d,\xi_{l}}$$
$$\leq b_{2}h^{0}(\mathcal{O}_{X}(d)) + \sum_{l \in B} \dim E_{d,\xi_{l}} - b_{1}(b_{1} - b_{2})$$

for all  $B \subset B_1$  with  $|B| = b_1 - b_2$ . Note that  $b_1 + b_2 \leq c$ . So it comes down to verifying

<span id="page-8-3"></span>
$$(2.4.7) (n+1)^2 - \sum_{j=0}^{p-1} a_j^2 + (b_1 - b_2) \dim E_{d,\xi} + 2b_1 b_2 < b_1 \binom{n+d}{d}$$

for all  $\xi$ ,  $b_1 \geq b_2 \in \mathbb{N}$  and  $b_1 + b_2 = c$ . Here we use  $\mathbb{N}$  for the set of nonnegative integers.

It is easy to check that (2.4.7) follows from (2.3.1) when  $d \ge 3$  for all  $n \ge c+2 \ge 3$  and from (2.3.2) when d=2 for all  $n \ge c+1 \ge 4$ . This proves (2.4.7) and hence (2.4.4).

We are left with the only exceptional case d = c = 2, which is settled by the following proposition.

**Proposition 2.5.** For a general smooth intersection X of two quadrics in  $\mathbb{P}^n_k$ ,  $\operatorname{Aut}(X) = (\mathbb{Z}/2\mathbb{Z})^n$  if  $n \geq 4$  and  $\operatorname{char}(k) \neq 2$ .

*Proof.* Let  $W \subset \mathbb{P}^n \times \mathbb{P}^1$  be a pencil of quadrics whose base locus is X. Since  $\operatorname{Aut}(X)$  acts  $\operatorname{H}^0(I_X(2))$ , every  $\sigma \in \operatorname{Aut}(X)$  induces an automorphism of W with diagram

$$(2.5.1) W \xrightarrow{\sigma} W$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$\stackrel{\mathbb{P}^1}{\longrightarrow} \stackrel{g}{\longrightarrow} \stackrel{\mathbb{P}^1}{\longrightarrow}$$

Let  $D = \{b \in \mathbb{P}^1 : W_b \text{ singular}\}$  be the discriminant locus of the pencil W. Clearly, g(D) = D.

We can make everything explicit. Let  $Q_A$  and  $Q_B$  be two members of the pencil whose defining equations are given by two symmetric matrices A and B. Obviously, we may take A = I and assume that a member of pencil is given by B - tI. Then D consists of exactly the eigenvalues  $\lambda_0, \lambda_1, \ldots, \lambda_n$  of B. By [Rei72, Proposition 2.1], the set  $D = \{\lambda_0, \lambda_1, \ldots, \lambda_n\}$  is a set of  $n+1 \geq 5$  general points on  $\mathbb{P}^1$ . Therefore,  $g \in \operatorname{Aut}(\mathbb{P}^1)$  sending D to D must be the identity map and  $\sigma$  preserves the fiberation  $W/\mathbb{P}^1$ , i.e., it induces an automorphism of  $W_b$  for each b. In particular,  $\sigma$  maps  $W_b$  to  $W_b$  for each  $b \in D$ . Every  $W_b$  has exactly one node, i.e., an ordinary double point  $p_i$  for  $b = \lambda_i$ , which is given by the eigenvector of B corresponding to  $\lambda_i$ . Clearly,  $\sigma$  fixes  $p_0, p_1, \ldots, p_n$ .

The matrix B can always be orthogonally diagonalized (this follows from [Rei72, Proposition 2.1]). Therefore, W is given by

$$(2.5.2) (\lambda_0 z_0^2 + \lambda_1 z_1^2 + \dots + \lambda_n z_n^2) - t(z_0^2 + z_1^2 + \dots + z_n^2) = 0$$

after some action of  $\operatorname{Aut}(\mathbb{P}^n)$ . Since  $\sigma$  fixes  $p_0, p_1, \ldots, p_n$ , it has to be a  $(k^*)^{n+1}$  action on  $(z_0, z_1, \ldots, z_n)$ . And since it preserves the fibers of  $W/\mathbb{P}^1$ , it must be

(2.5.3) 
$$\sigma(z_0, z_1, \dots, z_n) = (\pm z_0, \pm z_1, \dots, \pm z_n)$$

and we then conclude that  $\operatorname{Aut}(X) = (\mathbb{Z}/2\mathbb{Z})^{n+1}/\{\pm 1\} = (\mathbb{Z}/2\mathbb{Z})^n$ .

The case  $2 = d_1 = d_2 < d_3 = \cdots = d_c = d$ . By (2.2.1), it suffices to prove

<span id="page-9-0"></span>(2.5.4) 
$$(n+1)^2 - \sum_{j=0}^{p-1} a_j^2 + \dim E_{X,2,\xi_1} + \dim E_{X,2,\xi_2} + \sum_{i=3}^c \dim E_{X,d,\xi_i}$$
$$< 2h^0(\mathcal{O}_X(2)) + (c-2)h^0(\mathcal{O}_X(d))$$

where

$$h^{0}(\mathcal{O}_{X}(d)) = \binom{n+d}{n} - 2\binom{n+d-2}{n} + \binom{n+d-4}{n} - (c-2).$$

Applying the same argument as before to  $E_{X,d,\xi_i}$  for  $i \geq 3$ , we can further reduce (2.5.4) to

<span id="page-10-0"></span>(2.5.5) 
$$(n+1)^2 - \sum_{j=0}^{p-1} a_j^2 + \sum_{i=1}^2 \dim E_{X,2,\xi_i} + (b_1 - b_2) \dim E_{d,\xi} + 2b_1b_2$$

$$< 2h^0(\mathcal{O}_X(2)) + b_1 \left( \binom{n+d}{n} - 2\binom{n+d-2}{n} + \binom{n+d-4}{n} \right)$$

for all  $\xi$ ,  $b_1 \geq b_2 \in \mathbb{N}$  and  $b_1 + b_2 = c - 2$ .

<span id="page-10-1"></span>For  $E_{X,2,\xi_1}$  and  $E_{X,2,\xi_2}$ , it follows from (2.3.2) that

$$(n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + \sum_{i=1}^{2} \dim E_{X,2,\xi_{i}}$$

$$\leq (n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + \sum_{i=1}^{2} \dim E_{2,\xi_{i}} - 2$$

$$\leq 2 \binom{n+2}{2} - 2 = 2h^{0}(\mathcal{O}_{X}(2)) + 2.$$

<span id="page-10-2"></span>Suppose that  $\mu \geq 3$ . We have

(2.5.7) 
$$\binom{n+d}{d} - \dim E_{d,\xi} \ge \frac{2}{3} \binom{n+d-1}{d-1} + \frac{4}{9} \binom{n+d-2}{d-1}$$

for  $n \geq 3$  by (2.4.1). It is easy to check that

<span id="page-10-3"></span>
$$(2.5.8) \frac{2}{3} \binom{n+d-1}{d-1} + \frac{4}{9} \binom{n+d-2}{d-1} > 2 \binom{n+d-2}{n} + 2$$

for all  $d \ge 3$  and  $n \ge 4$ . Thus, (2.5.5) follows from (2.5.6), (2.5.7) and (2.5.8) for all  $d \ge 3$  and  $n \ge c+1 \ge 4$ .

Suppose that  $\mu = 2$ . If  $\xi_1 \neq \xi_2$ ,

(2.5.9) 
$$\dim E_{X,2,\xi_1} + \dim E_{X,2,\xi_2} \le h^0(\mathcal{O}_X(2))$$

and hence

<span id="page-10-4"></span>
$$(n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + \sum_{i=1}^{2} \dim E_{X,2,\xi_{i}}$$

$$\leq (n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + h^{0}(\mathcal{O}_{X}(2))$$

$$\leq \frac{(n+1)^{2}}{2} + h^{0}(\mathcal{O}_{X}(2)) = 2h^{0}(\mathcal{O}_{X}(2))$$

for  $n \geq 3$ . On the other hand, if  $\xi_1 = \xi_2$ ,

(2.5.11) 
$$\dim E_{X,2,\xi_1} + \dim E_{X,2,\xi_2} \le \dim E_{2,\xi_1} + \dim E_{2,\xi_2} - 4$$
 and (2.5.10) still holds by (2.3.2).

<span id="page-11-0"></span>By (2.4.1), we have

(2.5.12) 
$$\binom{n+d}{d} - \dim E_{d,\xi} \ge \frac{1}{2} \binom{n+d-1}{d-1} + \frac{1}{4} \binom{n+d-2}{d-1} + \frac{1}{8} \binom{n+d-3}{d-1}$$

for  $\mu \geq 2$  and  $n \geq 3$ . It is easy to check that

<span id="page-11-1"></span>
$$(2.5.13) \qquad \frac{1}{2} \binom{n+d-1}{d-1} + \frac{1}{4} \binom{n+d-2}{d-1} + \frac{1}{8} \binom{n+d-3}{d-1} > 2 \binom{n+d-2}{n}$$

for all  $d \ge 3$  and  $n \ge 4$ . Thus, (2.5.5) follows from (2.5.10), (2.5.12) and (2.5.13) for all  $d \ge 3$  and  $n \ge c + 1 \ge 4$ .

The case  $2 = d_1 < d_2 = d_3 = \cdots = d_c = d$ . By (2.2.1), it suffices to prove

(2.5.14) 
$$(n+1)^2 - \sum_{j=0}^{p-1} a_j^2 + \dim E_{X,2,\xi_1} + \sum_{i=2}^c \dim E_{X,d,\xi_i}$$
$$< h^0(\mathcal{O}_X(2)) + (c-1)h^0(\mathcal{O}_X(d))$$

where

<span id="page-11-2"></span>
$$h^{0}(\mathcal{O}_{X}(d)) = \binom{n+d}{n} - \binom{n+d-2}{n} - (c-1).$$

By (2.3.2), we have

$$(n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + \dim E_{X,2,\xi_{1}} - h^{0}(\mathcal{O}_{X}(2))$$

$$\leq (n+1)^{2} - \sum_{j=0}^{p-1} a_{j}^{2} + \dim E_{2,\xi_{1}} - 1 - \left(\binom{n+2}{2} - 1\right)$$

$$\leq \frac{(n+1)^{2}}{2} - \frac{1}{2} \sum_{j=0}^{p-1} a_{j}^{2}.$$

So (2.5.14) holds if

<span id="page-11-3"></span>
$$(2.5.16) \qquad \frac{(n+1)^2}{2} - \frac{1}{2} \sum_{i=0}^{p-1} a_j^2 + \sum_{i=2}^c \dim E_{X,d,\xi_i} < (c-1)h^0(\mathcal{O}_X(d)).$$

Applying the same argument as before to  $E_{X,d,\xi_i}$  for  $i \geq 2$ , we can further reduce (2.5.16) to

<span id="page-11-4"></span>(2.5.17) 
$$\frac{(n+1)^2}{2} - \frac{1}{2} \sum_{j=0}^{p-1} a_j^2 + (b_1 - b_2) \dim E_{d,\xi} + 2b_1 b_2$$

$$< b_1 \left( \binom{n+d}{n} - \binom{n+d-2}{n} \right)$$

for all  $\xi$ ,  $b_1 \geq b_2 \in \mathbb{N}$  and  $b_1 + b_2 = c - 1$ .

By (2.5.12) and (2.5.13), we have

(2.5.18) 
$$\left(b_1 - b_2 - \frac{1}{2}\right) \dim E_{d,\xi} + 2b_1b_2$$

$$< \left(b_1 - \frac{1}{2}\right) \binom{n+d}{n} - b_1 \binom{n+d-2}{n}$$

<span id="page-12-0"></span>for all  $d \ge 3$  and  $n \ge c + 2 \ge 4$ . Combining (2.5.18) with (2.3.1), we obtain (2.5.17). This finishes the proof of Theorem 1.3.

#### <span id="page-12-1"></span>3. Equivariant Deformations

In this section, we shall only consider complex algebraic varieties. We shall use equivariant deformation theory to show that the automorphism group of a complete intersection (except some cases) over  $\mathbb C$  acts on the singular cohomology groups in a faithful fashion.

We begin by recalling some basics about equivariant deformation theory. Ringed spaces with a group action is a particular case of a ringed topos. Therefore the so-called equivariant deformation theory is just a specialization of the theory of cotangent complex for ringed topos as developed by Illusie [Ill72].

**3.1.** Suppose Y is a scheme over  $\mathbb{C}$  with an action

$$G \times Y \to Y$$

by an abstract group G. Then the equivariant cotangent complex  $\mathbb{L}_Y^G$  is a boundedbelow complex of quasi-coherent sheaves on Y with an action of G covering the action of G on Y. The underlying complex of  $\mathbb{L}_Y^G$  is the usual cotangent complex  $\mathbb{L}_Y$ . The G structure induces a Hochschild–Serre spectral sequence with

$$E_2^{i,j} = \mathrm{H}^i(G, \mathrm{Ext}^j_{\mathcal{O}_Y}(\mathbb{L}_Y, \mathcal{O}_Y))$$

abutting to

$$\operatorname{Ext}_{G extsf{-}\mathcal{O}_Y}^{i+j}(\mathbb{L}_Y^G,\mathcal{O}_Y),$$

here we regard  $\mathcal{O}_Y$  as an  $\mathcal{O}_Y$ -module with a trivial action of G.

<span id="page-12-3"></span>**3.2.** When G is *finite*, the Hochschild–Serre spectral sequence degenerates, and the edge map of the spectral sequence

<span id="page-12-2"></span>
$$(3.2.1) \qquad \operatorname{Ext}_{G - \mathcal{O}_Y}^i(\mathbb{L}_Y^G, \mathcal{O}_Y) \to \operatorname{H}^0(G, \operatorname{Ext}_{\mathcal{O}_Y}^i(\mathbb{L}_Y, \mathcal{O}_Y)) = \operatorname{Ext}_{\mathcal{O}_Y}^i(\mathbb{L}_Y, \mathcal{O}_Y)^G.$$

is therefore an isomorphism for all i > 0.

The case when i=1,2 are mostly important for us. Recall that the space of infinitesimal deformations of a G-variety Y is identified with  $\operatorname{Ext}_{G-\mathcal{O}_Y}^1(\mathbb{L}_Y^G,\mathcal{O}_Y)$ . When G is the trivial group, and Y is smooth over  $\mathbb{C}$ , the space of infinitesimal deformations of Y is thus identified with the cohomology group  $\operatorname{H}^1(Y,T_Y)$  of the tangent bundle. When G is finite, and Y is smooth, the above degeneracy tells us that the space of infinitesimal deformations of Y with an action of G is identified with linear subspace  $\operatorname{H}^1(Y,T_T)^G$  of  $\operatorname{Def}(Y)=\operatorname{H}^1(Y,T_Y)$ .

The case i=2 is related to the obstruction theory. Suppose that we have a small extension of Artinian  $\mathbb{C}$ -algebras

$$0 \to \mathbb{C} \to R \to R' \to 0$$
.

and a flat R'-scheme Y' with an action of G, such that  $Y' \otimes_{R'} \mathbb{C} = Y$ , as schemes with G-actions. Just like the usual deformation theory, attached to the above deformation situation, there is an element  $\operatorname{obs}(Y',G) \in \operatorname{Ext}^2_{G-\mathcal{O}_Y}(\mathbb{L}_Y^G,\mathcal{O}_Y)$ , known as the *equivariant obstruction class*, such that the deformation Y' extends to a deformation over R if and only if  $\operatorname{obs}(Y',G) = 0$ .

Under the identification (3.2.1), the equivariant obstruction class is sent to the usual obstruction class. Therefore if the infinitesimal deformations of Y are all unobstructed (i.e., the obstruction class vanishes for any deformation situation), the G-equivariant infinitesimal deformations of Y are all unobstructed as well.

**3.3.** Now we assume that Y is a smooth projective variety of dimension n. For positive integers p, q such that p + q = n. Then the map contraction map

<span id="page-13-0"></span>
$$T_Y \otimes \Omega_Y^p \to \Omega_Y^{p-1}$$

gives rise to a map

(3.3.1) 
$$H^1(Y, T_Y) \to \text{Hom}(H^q(Y, \Omega_Y^p), H^{q+1}(Y, \Omega_Y^{p-1})).$$

We say that the infinitesimal Torelli theorem holds for Y if there exists p, q such that the above arrow is injective.

<span id="page-13-1"></span>**Lemma 3.4.** Let Y be a smooth proper variety of dimension n. Assume that

- (1) the infinitesimal Torelli theorem holds for Y, and
- (2)  $H^n(g) = \text{Id for all } g \in G$ .

Then  $H^{1}(Y, T_{Y}) = H^{1}(Y, T_{Y})^{G}$ .

*Proof.* Choose p and q so that the map (3.3.1) is injective. Consider the following commutative diagram

$$\begin{split} \mathrm{H}^{1}(Y,T_{Y})^{G} & \longrightarrow \mathrm{Hom}(\mathrm{H}^{q}(Y,\Omega_{Y}^{p}),\mathrm{H}^{q+1}(Y,\Omega_{Y}^{p-1}))^{G} \\ \downarrow & \downarrow \\ \mathrm{H}^{1}(Y,T_{Y}) & \longrightarrow \mathrm{Hom}(\mathrm{H}^{q}(Y,\Omega_{Y}^{p}),\mathrm{H}^{q+1}(Y,\Omega_{Y}^{p-1})) \end{split}$$

Since G acts trivially on the cohomology group  $H^n(Y, \mathbb{C})$ , it induces a trivial action on the Hodge groups. Therefore the right vertical arrow in the above diagram is an equality. It follows that the image of any element in  $H^1(Y, T_Y)$  is G-invariant, and therefore the infinitesimal Torelli property implies that it falls in  $H^1(Y, T_Y)^G$ .  $\square$ 

<span id="page-13-2"></span>3.5. Smooth Fano varieties and smooth Calabi–Yau varieties. Assume that Y is a smooth Fano variety. Then the cotangent complex  $\mathbb{L}_Y$  is equal to the sheaf  $\Omega^1_Y$ . The Kodaira vanishing theorem then implies that

$$\operatorname{Ext}^{2}(\mathbb{L}_{Y}, \mathcal{O}_{Y}) = \operatorname{H}^{2}(Y, T_{Y}) = \operatorname{H}^{\dim Y - 2}(Y, \Omega^{1}_{Y} \otimes \omega_{Y}) = 0.$$

Therefore the deformation of Y is unobstructed. When Y is a smooth Calabi–Yau variety, it is well-known theorem (see e.g., [Kaw92] for an algebraic proof based on the work of Ziv Ran [Ran92]) that the deformation of Y is unobstructed as well. In both cases above, according to (3.2), if Y also acquires an action of a finite group G, the equivariant deformation of Y is unobstructed as well.

<span id="page-14-0"></span>**Proposition 3.6.** *Let Y be a smooth complete intersection in* P *r* C *of type* (*d*1*, . . . , dc*)*, d<sup>i</sup>* ≥ 2*. Let n* = *r* − *c. Assume that*

- *Y is not an elliptic curve,*
- *Y is Fano or Calabi–Yau,*
- *the infinitesimal Torelli theorem holds for Y ,*

*Then the map*

$$\operatorname{Aut}(Y) \to \operatorname{H}^n(X, \mathbb{Q})$$

*is injective.*

*Proof.* The proposition is well-known for K3 surfaces. If *Y* is a surface with nontrivial canonical bundle, or the dimension of *Y* is at least 3, then the group of automorphisms of *Y* is the same as the group of linear automorphisms with respect to the projective embedding, thus it suffices to prove the group Aut*L*(*Y* ) of linear automorphisms of *Y* acts faithfully on the H*<sup>n</sup>* (*Y,* Q). Moreover, the condition that *Y* satisfies the infinitesimal Torelli theorem implies that *Y* can not be a quadric or an intersection of two quadrics. Therefore, Theorem [1.3](#page-1-0) can be applied to the present situation.

Let *G* be the kernel of

$$\operatorname{Aut}(Y) \to \operatorname{GL}(\operatorname{H}^n(Y,\mathbb{Q})).$$

We want to show that *G* is trivial. Since *Y* is a smooth Fano variety or a smooth Calabi–Yau variety satisfying the infinitesimal Torelli theorem, we know from [\(3.4\)](#page-13-1) and [\(3.5\)](#page-13-2) that the deformation space of *Y* is smooth and equals the deformation space of *Y* with *G*-action. Therefore the automorphisms *g* in *G* is extendable to any nearby deformation *Y* ′ of *Y* . It follows from Theorem [1.3](#page-1-0) that *g* is a specialization of the identity map. Therefore, *g* is the identity.

<span id="page-14-1"></span>**Proposition 3.7.** *Let Y be a smooth complete intersection in* P *r* C *of dimension n. Assume that Y is of general type. Then the map*

$$\operatorname{Aut}(Y) \to \operatorname{H}^n(X, \mathbb{Q})$$

*is injective.*

*Proof.* Let *g* ∈ *G* is an element acting trivially on the cohomology of *Y* . The induced action of *g* on the ring

$$S_Y = \bigoplus_{n \ge 0} \operatorname{Sym}^d(\mathrm{H}^0(Y, \omega_Y))$$

is trivial. Since *Y* is a complete intersection of general type, *Y* has very ample canonical bundle hence *Y* ⊆ Proj(*S<sup>Y</sup>* ). Since *g* acts trivially on Proj(*S<sup>Y</sup>* ), *g* induces the identity on *Y* .

The case of a cubic surface can be dealt separately, and we can directly prove a version that holds true for any algebraically closed field.

<span id="page-14-2"></span>**Lemma 3.8.** *Let Y be a smooth cubic surface over an algebraically closed field. Let* H<sup>2</sup> (*Y* ) *be*

• *either the singular cohomology* H<sup>2</sup> (*Y,* Q) *if the ambient field is* C*, or*

- *the ℓ-adic cohomology* H<sup>2</sup> ét(*Y,* Q*ℓ*) *if the ambient field has characteristic different from ℓ, or*
- *the crystalline cohomology* H<sup>2</sup> cris(*Y /W*(*k*))[1*/p*] *when k has characteristic p >* 0*.*

*If g is an automorphism of Y such that g* <sup>∗</sup> = Id *on* H<sup>2</sup> (*Y* )*. Then g* = Id*.*

*Proof.* It is a classical theorem (see e.g., [\[Har77,](#page-25-12) Chapter V, Corollary 4.7]) that *Y* is the projective plane blown up six point *p*1*, . . . , p*<sup>6</sup> such that the no three points among the six are colinear and the six points are not contained in a single conic. Let *E*1*, . . . , E*<sup>6</sup> be the exceptional divisors on *Y* corresponding to the six points. Let *g* be an isomorphism of *Y* fixing the cohomology of *Y* . Then *g* ∗ [*E<sup>i</sup>* ] = [*E<sup>i</sup>* ]. For divisors on *Y* , being rationally equivalent is the same as being homologically equivalent. Therefore the divisor *g* <sup>∗</sup>*E<sup>i</sup>* is necessarily equal to *E<sup>i</sup>* . This implies that the automorphism *g* commutes with the blowing up map, and thus descends to an automorphism of P <sup>2</sup> fixing the six points *p*1*, . . . , p*6. Since any three points among the six points are not colinear, there is a projective transformation *g* ′ sending *p*<sup>1</sup> to [1*,* 0*,* 0], sending *p*<sup>2</sup> to [0*,* 1*,* 0], sending *p*<sup>3</sup> to [0*,* 0*,* 1] and *p*<sup>4</sup> to [1*,* 1*,* 1]. On the other hand, the only projective transformation that fixes these four points is the identity. Since the descendent *g* ′ of *g* fixes *p*1*, . . . , p*4, it has to be the identity. It remains to check that *g* induces the identity map on the exceptional divisors. If *x* is a point in *E<sup>i</sup>* ⊂ *Y* lying above *p<sup>i</sup>* . Then there exists a line *L* through *p<sup>i</sup>* such that the proper transform of *L* intersects with *E<sup>i</sup>* at a unique point that is *x*. Since *g* ′ fixes *L*, *g* fixes its proper transform by continuity. Therefore *g* fixes *x*, as desired.

- **3.9.** To summarize, we have shown that if *Y* is any smooth complete intersection of in a projective space P *r* C type (*d*1*, . . . , dc*) with *d<sup>i</sup>* ≥ 2, such that
  - *Y* is not an elliptic curve,
  - *Y* is not a quadric,
  - *Y* is not an intersection of two quadrics,

then the automorphism group of *Y* acts faithfully on the singular cohomology group H*<sup>n</sup>*(*Y,* Q).

Hence Aut(*Y* ) acts faithfully on the singular cohomology with Q*ℓ*-coefficient. Since singular and étale cohomology groups agree for complex algebraic varieties for the coefficient Q*ℓ*, Theorem [1.5\(](#page-1-1)2) holds true for *k* = C.

### 4. Automorphism and Cohomology

<span id="page-15-0"></span>Throughout this section we shall assume that *k* is an algebraically closed field of characteristic *p >* 0. Let *W*(*k*) be the ring of Witt vectors of *k*. Let *ℓ* be a prime number different from *p*. Let *X* be a smooth complete intersection inside a projective space. In this section, we prove that, besides some obvious exceptions, the action of Aut(*X*) on the middle crystalline cohomology, as well as the middle *ℓ*-adic étale cohomology of *X*, is faithful.

**4.1.** Let *X* be a smooth projective variety over *k*. Let *g* ∈ Aut(*X*) be an automorphism. Then *g* acts on both crystalline cohomology and étale cohomology of *X*. By [\[KM74,](#page-25-13) Theorem 2(2)], the characteristic polynomial of H*<sup>i</sup>* cris(*g*) agrees with the

characteristic polynomial of  $H^i_{\text{\'et}}(g, \mathbb{Q}_{\ell})$ . If g has finite order in Aut(X), then both operators above are semisimple, hence

$$\mathrm{H}^{i}_{\mathrm{cris}}(g) = \mathrm{Id}$$
 if and only if  $\mathrm{H}^{i}_{\mathrm{\acute{e}t}}(g, \mathbb{Q}_{\ell}) = \mathrm{Id}$ .

In all the cases that we are interested in, the group  $\operatorname{Aut}(X)$  is finite. So proving the faithfulness of the action  $\operatorname{Aut}(X)$  on étale cohomology is the same as proving the faithfulness of the action of  $\operatorname{Aut}(X)$  on the crystalline cohomology. In the sequel we shall treat only crystalline cohomology.

Our proof of the faithfulness is based on the following theorem of the secondnamed author.

<span id="page-16-0"></span>**Theorem 4.2** ([Pan16], Theorem 1.7). Let  $\pi: \mathcal{X} \to \operatorname{Spec}(W(k))$  be a smooth projective morphism of pure relative dimension n. The special fiber  $\mathcal{X} \times_{W(k)} \operatorname{Spec}(k)$  is denoted by X. Let  $g: X \to X$  be an automorphism of X. Assume that

(1) under the canonical isomorphism

$$H_{\mathrm{cris}}^n(X/W(k)) = H_{\mathrm{dR}}^n(\mathcal{X}/W),$$

 $g^*$  preserves the Hodge filtration;

(2) the infinitesimal Torelli theorem holds for X, i.e., the map

$$\Psi_0: \mathrm{H}^1(X, T_X) \to \bigoplus_{i+j=n} \mathrm{Hom}(\mathrm{H}^j(X, \Omega_X^i), \mathrm{H}^{j+1}(X, \Omega_X^{i-1})).$$

is injective; and

(3) the Hodge-to-de Rham spectral sequence of X is  $E_1$ -degenerate, and the Hodge cohomology groups  $H^i(\mathcal{X}, \Omega^j_{\mathcal{X}/W(k)})$  are free W(k)-modules.

then there exists an automorphism  $\widetilde{g}: \mathcal{X} \to \mathcal{X}$  over  $\operatorname{Spec}(W(k))$ , such that  $\widetilde{g}$  reduces to g modulo p.

This theorem allows us to deduce the faithfulness of the action of  $\operatorname{Aut}(X)$  on  $\operatorname{H}^n_{\operatorname{cris}}(X/W(k))$  from corresponding results in characteristic 0.

<span id="page-16-1"></span>**Proposition 4.3.** Let X be a smooth complete intersection over k satisfying the infinitesimal the Torelli theorem. Assume that X is not a quadric nor an intersection of two quadrics. Then  $\operatorname{Aut}(X)$  acts faithfully on  $\operatorname{H}^n_{\operatorname{cris}}(X/W(k))$ .

*Proof.* Let g be an automorphism that acts trivially on  $\mathrm{H}^n_{\mathrm{cris}}(X/W(k))$ , then for any lift  $\mathcal{X}$ ,  $g^*$  trivially preserves the Hodge filtration on the crystalline cohomology induced by the de Rham cohomology, so the condition (1) above is met. Since we have assumed that X satisfies the infinitesimal Torelli theorem in characteristic p, the condition (2) is met as well. It then follows from Theorem 4.2 that for any lift  $\mathcal{X}$ , there exists an automorphism  $\widetilde{g}$  lifting g. It follows that the map

$$h := \widetilde{g} \otimes_{W(k)} W(k)[1/p] : \mathcal{X} \otimes_{W(k)} W(k)[1/p] \to \mathcal{X} \otimes_{W(k)} W(k)[1/p]$$

induces the identity on the de Rham cohomology  $H^n_{dR}(\mathcal{X}/W(k))[1/p]$ . Choosing an embedding  $\sigma:W(k)[1/p]\to\mathbb{C}$ , and using the comparison between the algebraic de Rham and singular cohomology, we know that the morphism

$$h^{\sigma}: \mathcal{X}^{\sigma} \to \mathcal{X}^{\sigma}$$

induces an isomorphism on the singular cohomology  $\mathrm{H}^n(X,\mathbb{C})$  with  $\mathbb{C}$ -coefficients. It follows that  $\mathrm{H}^n(h^{\sigma},\mathbb{Q})$  induces a map for singular cohomology with  $\mathbb{Q}$ -coefficients. By Proposition 3.6 and Proposition 3.7, we must have  $h^{\sigma}=\mathrm{Id}$ , hence  $h=\mathrm{Id}$ . Taking closure, we conclude that  $\widetilde{g}$ , hence g, is the identity map.  $\square$ 

By Proposition A.9 in the appendix, and the discussion following it, besides cubics, which we have dealt with in Lemma 3.8, cubic fourfolds, which had been considered in [Pan15], the infinitesimal Torelli theorem holds true for all the rest complete intersections except for quadrics and (2,2)-type complete intersections. Thus, Proposition 4.3 concludes the proof of Theorem 1.5(ii).

The rest of this section will be dealing with complete intersections of type (2,2).

<span id="page-17-0"></span>**4.3.** We shall next consider automorphisms of intersections of two quadrics. In the sequel, we shall assume that k is an algebraically closed field whose characteristic is not equal to 2. Let  $\ell$  be a prime number different from the characteristic of k. Let X be a smooth complete intersection of type (2,2) in  $\mathbb{P}^n_k$ . We assume  $m = \dim X = n - 2 \geq 3$ . By [Rei72, Proposition 2.1], X is projectively equivalent to  $Q_1 \cap Q_2$  with

(4.3.1) 
$$Q_1 = V\left(\sum_{i=0}^n X_i^2 = 0\right), \quad Q_2 = V\left(\sum_{i=0}^n \lambda_i X_i^2 = 0\right)$$

where  $\{\lambda_i\}$  are distinct elements in k and  $Q_1$  intersects  $Q_2$  transversely. By Theorem 1.3, we have

$$\operatorname{Aut}(X) \cong (\mathbb{Z}/2\mathbb{Z})^{n+1}/\{\pm 1\} \cong (\mathbb{Z}/2\mathbb{Z})^n.$$

Define  $\sigma_i$  to be the automorphism of X induced by

$$[x_0,\ldots,x_n]\mapsto [x_0,\ldots,x_{i-1},-x_i,x_{i+1},\ldots,x_n].$$

Let  $Aut_{tr}(X)$  be the kernel of

$$\operatorname{Aut}(X) \to \operatorname{Aut}(\operatorname{H}^m_{\acute{e}t}(X,\mathbb{Q}_\ell)).$$

We first consider even dimensional quadrics.

**Lemma 4.4.** If m is even, then  $Aut_{tr}(X) = \{Id\}.$ 

*Proof.* Let m = 2e. Let  $\Sigma$  be the space of e-planes contained in X. Let  $\eta$  be the class in  $\mathrm{H}^m_{\mathrm{\acute{e}t}}(X,\mathbb{Q}_\ell)$  defined by the cohomology class of an intersection of X with a collection of generic hyperplanes. Let F(X) be the free abelian group generated by  $\Sigma$  and  $\eta$ , and let A(X) be the quotient of F(X) modulo the relations

$$\eta - s - s_i - s_j - s_{ij},$$

for  $s \in \Sigma$ . Here,  $s_i = \sigma_i(s)$ , and  $s_{ij} = \sigma_i \sigma_j(s)$ .

Let  $g \in Aut_{tr}(X)$ . By [Rei72, Page 48], we have a commutative diagram

$$A(X) \xrightarrow{\widehat{g}} A(X)$$

$$\downarrow \qquad \qquad \downarrow$$

$$H^m_{\text{\'et}}(X, \mathbb{Q}_\ell) \xrightarrow{g^* = \mathrm{Id}} H^m_{\text{\'et}}(X, \mathbb{Q}_\ell)$$

It follows from the remark [Rei72, Chapter 3, Page 49] that the map

$$A(X) \to \mathrm{H}^m(X)$$

is injective. In particular, we have  $\widehat{g}=\mathrm{Id}.$  By [Rei72, Proposition 3.18], we have an injection

$$\operatorname{Aut}(X) \hookrightarrow \operatorname{Aut}(\Sigma) \hookrightarrow \operatorname{Aut}(A(X)).$$

Therefore, we have g = Id.

<span id="page-18-0"></span>We now deal with odd dimensional quadrics. We first need a lemma.

**Lemma 4.5.** Suppose that X is a smooth complete intersection of type (2,2). If  $\dim(X) = m = 2e + 1$  is odd, then a general point  $p \in X$  is the intersection of two e-planes in X. In particular, p is the intersection of all e-planes containing p.

Proof. Suppose  $T_{X,p}$  is the projective tangent space to X at p. By a remark in [Rei72, Page 65], the intersection  $T_{X,p} \cap X$  is a cone of a nonsingular intersection Y of two quadrics in  $T_{X,p}$  if p is a general point of X. It is clear that  $\dim(Y) = m-3$  is even. By [Rei72, Theorem 3.8], there are two (e-1)-planes s and t in Y such that  $s \cap t$  is empty. Note that the cones  $\operatorname{Cone}(s)$  and  $\operatorname{Cone}(t)$  with vertex p are two e-planes in X containing p. It is clear that the intersection  $\operatorname{Cone}(s) \cap \operatorname{Cone}(t)$  is the point p.

**Lemma 4.6.** Let notation be as in 4.1. Assume that m is odd. Then  $\operatorname{Aut}_{\operatorname{tr}}(X)$  is  $(\mathbb{Z}/2\mathbb{Z})^{m+1}$ . Suppose an automorphism g of X is given by  $\sigma_{i_1} \circ \ldots \circ \sigma_{i_s}$ . Then  $g \in \operatorname{Aut}_{\operatorname{tr}}(X)$  if and only if s is even.

*Proof.* Suppose m=2e+1. Let S be the variety parameterizing e-planes in X. By [Rei72, Chapter 4, Page 55], the variety S is nonsingular of dimension e+1. The incidence subvariety  $T=\{(s,x)|x\in s\}\subset S\times X$ 

![](_page_18_Picture_12.jpeg)

induces an isomorphism  $\mathrm{H}^1_{\mathrm{\acute{e}t}}(S)\cong\mathrm{H}^{2e+1}_{\mathrm{\acute{e}t}}(X)$ , see [Rei72, Theorem 4.14]. Moreover loc. cit. also says that an isomorphism  $g\in\mathrm{Aut}_L(X)$  induces  $\widehat{g}:S\to S$  and a commutative diagram

$$\begin{array}{ccc}
H^{1}_{\text{\'et}}(S, \mathbb{Q}_{\ell}) & \stackrel{\cong}{\longrightarrow} & H^{2e+1}_{\text{\'et}}(X, \mathbb{Q}_{\ell}) \\
& & \downarrow_{\widehat{g}^{*}} & \downarrow_{g^{*}} \\
H_{\text{\'et}}^{1}(S, \mathbb{Q}_{\ell}) & \stackrel{\cong}{\longrightarrow} & H^{2e+1}_{\text{\'et}}(X, \mathbb{Q}_{\ell}).
\end{array}$$

We shall need two claims to complete our argument.

Claim 1. If  $\widehat{g}$  has a fixed point and  $\widehat{g}^* = \operatorname{Id}$ , then  $g = \operatorname{Id}$  on X.

In fact, by [Rei72, Theorem 4.8], we know S is an abelian variety. From the injection

$$\operatorname{End}(S) \hookrightarrow \operatorname{End}(\operatorname{H}^{1}_{\operatorname{\acute{e}t}}(S, \mathbb{Q}_{\ell})),$$

it follows that  $\widehat{g} = \text{Id}$ . On the other hand, by Lemma 4.5, a general point  $p \in X$  is the intersection of e-planes in X which contain p. In other words, we have  $p = \bigcap P_i$  where  $P_i$  runs through all e-planes in X containing p. It follows that

$$g(p) = g\left(\bigcap_{p \in P_i} P_i\right) = \bigcap_{p \in P_i} \widehat{g}(P_i) = \bigcap_{p \in P_i} P_i = p$$

for a general point  $p \in X$ . We conclude that g = Id.

Claim 2. 
$$\sigma_i^* = -\text{Id on } H_{\text{\'et}}^m(X, \mathbb{Q}_\ell) \cong H_{\text{\'et}}^1(S, \mathbb{Q}_\ell).$$

In fact, since the automorphism  $\sigma_i$  fixes  $\{x_i = 0\} \cap X$ , which is a smooth complete intersection of type (2,2) of dimension 2e, it is clear that  $\sigma_i$  fixes all the e-planes in  $\{X_i = 0\} \cap X$ . Let s be a e-plane in  $\{X_i = 0\} \cap X$ . It follows that  $\widehat{\sigma_i}([s]) = [s]$ . Let C be the hyperelliptic curve (cf. [Rei72, Page 56]) given by:

$$z^2 = \prod_{i=0}^{n} (x - \lambda_i y).$$

For the point  $[s] \in S$ , by [Rei72, Proposition 4.2], we have a map

$$\Psi:C\to S$$

whose image is the closure of  $C_s^{1'}=\{t\in S|\dim(s\cap t)=e-1\}$ . Therefore, the automorphism  $\widehat{\sigma_i}:S\to S$  maps  $C_s^{1'}$  to  $C_s^{1'}$ . It induces an automorphism

$$g_i:C\to C$$

such that  $\widehat{\sigma}_i \circ \Psi = \Psi \circ g_i$ , i.e., the following diagram commutes.

$$C \xrightarrow{\Psi} S$$

$$\downarrow g_i \qquad \downarrow \widehat{\sigma_i}$$

$$C \xrightarrow{\Psi} S$$

By [Rei72, Proposition 4.2, Corollary 4.5, Lemma 4.7 and Theorem 4.8], we conclude that the morphism  $\Psi$  induces an isomorphism

$$\Psi^*: \mathrm{H}^1_{\mathrm{\acute{e}t}}(C, \mathbb{Q}_\ell) \to \mathrm{H}^1_{\mathrm{\acute{e}t}}(S, \mathbb{Q}_\ell).$$

By the main theorem of [Poo00], there exist  $\lambda_i$ , i = 0, ..., n such that

$$\operatorname{Aut}(C) = \{1, \iota\}$$

where  $\iota$  is the natural involution. In particular, it follows from the previous claim that  $(\widehat{\sigma_i})^* \neq \operatorname{Id}$ . We conclude  $g_i \neq \operatorname{Id}$ . Therefore, we have  $g_i = \iota$ . It follows that  $\widehat{\sigma_i}^* = -\operatorname{Id}$  on  $\operatorname{H}^1_{\operatorname{\acute{e}t}}(S, \mathbb{Q}_\ell) = \operatorname{H}^m_{\operatorname{\acute{e}t}}(X, \mathbb{Q}_\ell)$ . So we have shown the claim holds for one particular intersection  $X = X_{\{\lambda_i\}}$  of two quadrics which is determined by a certain  $\{\lambda_i\}_{i=0}^n$ .

The general case is handled as follows. We consider the smooth family of complete intersections of two quadrics

$$\begin{array}{cccc} X_{\{\lambda_i\}} & \subseteq & \widehat{X} = \{\sum X_i^2 = 0, \sum \lambda_i X_i^2 = 0\} \\ & & & \downarrow \\ \{\lambda_i\} & & \in & B \end{array}$$

The automorphism  $\sigma_i$  acts on  $\widehat{X}$  fiberwise. Thus  $\sigma_i^* + \operatorname{Id} \in \operatorname{End}(\mathbb{R}^m f_* \mathbb{Q}_{\ell})$ , hence it is a global section of the lisse-étale sheaf  $\operatorname{End}(\mathbb{R}^m f_* \mathbb{Q}_{\ell})$ . Its vanishing at  $X_{\{\lambda_i\}}$  shows that it vanishes everywhere. This proves the claim.

Combining the two claims, we conclude that for an automorphism  $g = \sigma_{i_1} \circ ... \circ \sigma_{i_s}$  of  $X, g \in \operatorname{Aut}_{\operatorname{tr}}(X)$  if and only if s is even.

<span id="page-20-0"></span>APPENDIX A. THE INFINITESIMAL TORELLI THEOREM OVER AN ARBITRARY FIELD

We give an exposition on infinitesimal Torelli theorem of complete intersections, a precise statement is given in Theorem A.7 and Theorem A.9. We present these notes because we need to apply a positive characteristic version of Theorem A.9 to deduce the faithfulness of automorphism actions on cohomology groups of certain complete intersections.

Flenner shows the infinitesimal Torelli theorem holds for certain complex manifolds [Fle86]. His method can also be used to prove infinitesimal Torelli theorems for algebraic varieties over an arbitrary field as long as one takes a bit care with the duality between symmetric powers. Although the proof we exposed in Section A.4 looks slightly different from Flenner's original proof (we find our spectral sequence argument makes the book-keeping less painful), the idea of using the resolutions T, A, B (see Section A.3), certainly goes back to Flenner. Of course, we should not claim any originality here.

**A.1. Divided powers.** Recall that the rth divided power of a locally free sheaf E on a scheme, notation  $D_r(E)$ , is defined to be the dual

$$(A.1.1) D_r(E) = \operatorname{Sym}^r(E^*)^*.$$

If  $e_1, \ldots, e_n$  is a local frame of E, then we write

$$e_1^{(i_1)}\cdots e_n^{(i_n)}$$

to be the element dual to the basis elements

$$(e_1^*)^{i_1}\cdots(e_n^*)^{i_n}.$$

If  $u = \sum u_i e_i$ , one defines

(A.1.2) 
$$u^{(r)} = \sum_{p_1 + \dots p_n = r} u_1^{p_1} \cdots u_n^{p_n} e_1^{(p_1)} \cdots e_n^{(p_n)}.$$

This definition does not depend on the choice of basis. There is a natural pairing between divided power and symmetric power:

(A.1.3) 
$$\operatorname{Sym}^{p+s}(E) \otimes D_s(E^*) \to \operatorname{Sym}^p(E),$$

dual to the algebra structure on  $D_*(E^*)$ .

The bialgebra structure on the symmetric algebra  $\operatorname{Sym}^*(E)$  defines a bialgebra structure on  $D_*(E)$ .

<span id="page-20-1"></span>Situation A.2. Let X be a smooth, proper scheme pure dimension n over a field k. Assume that there exists a short exact sequence of locally free sheaves

$$0 \to \mathcal{G} \to \mathcal{F} \to \Omega^1_X \to 0.$$

Let p be a positive integer no larger than n. We make the following two hypotheses:

(i) the map

$$\mathrm{H}^0(X, D_{n-p}(\mathcal{G}^*) \otimes \omega_X) \otimes \mathrm{H}^0(X, D_{p-1}(\mathcal{G}^*) \otimes \omega_X) \to \mathrm{H}^0(X, D_{n-1}(\mathcal{G}^*) \otimes \omega_X^2)$$

is surjective;

(ii) for all  $0 \le j \le n-2$ , we have

$$H^{j+1}(X, \operatorname{Sym}^{j}(\mathcal{G}) \otimes \bigwedge^{n-1-j}(\mathcal{F}) \otimes \omega_{X}^{-1}) = 0.$$

<span id="page-21-1"></span>We have a long exact sequence of locally free sheaves

$$(A.2.1) 0 \to \operatorname{Sym}^{p-1}(\mathcal{G}) \to \cdots \to \mathcal{G} \otimes \bigwedge^{p-2}(\mathcal{F}) \to \bigwedge^{p-1}(\mathcal{F}) \to \Omega_X^{p-1} \to 0.$$

Dualizing (A.2.1), replacing p by p + 1, we get

<span id="page-21-2"></span>
$$(A.2.2) (\Omega_X^p)^* \to \bigwedge^p(\mathcal{F}^*) \to \mathcal{G}^* \otimes \bigwedge^{p-1}(\mathcal{F}^*) \to \cdots \to D_p(\mathcal{G}^*) \to 0.$$

Since the pairing

$$\Omega_X^p \otimes \Omega_X^{n-p} \to \omega_X$$

is a perfect pairing, tensoring  $\omega_X$  to (A.2.2) and change p by n-p yields

<span id="page-21-3"></span>(A.2.3) 
$$0 \to \Omega_X^p \to \bigwedge^{n-p}(\mathcal{F}^*) \otimes \omega_X \to \cdots \to D_{n-p}(\mathcal{G}^*) \otimes \omega_X \to 0.$$

When p = 1, dualize (A.2.3) yields

$$(A.2.4) 0 \to \omega_X^* \otimes \operatorname{Sym}^{n-1}(\mathcal{G}) \to \cdots \to \omega_X^* \otimes \bigwedge^{n-1} \mathcal{F} \to T_X \to 0.$$

<span id="page-21-0"></span>**A.3. Three resolutions.** Following Flenner, we introduce three complexes T, A and B of locally free sheaves that resolve the sheaves  $T_X$ ,  $\Omega_X^p$  and  $\Omega_X^{p-1}$  respectively. Let notation be as in Situation A.2. Define

(A.3.1) 
$$T_{\bullet} = \{ \omega_X^* \otimes \operatorname{Sym}^{n-1}(\mathcal{G}) \to \cdots \to \omega_X^* \otimes \bigwedge^{n-1} \mathcal{F} \}$$

placed at cohomological degree  $-(n-1), \ldots, -1, 0$ ;

(A.3.2) 
$$A^{\bullet} = \{ \bigwedge^{n-p}(\mathcal{F}^*) \otimes \omega_X \to \cdots \to D_{n-p}(\mathcal{G}^*) \otimes \omega_X \}$$

placed at cohomological degree  $0, 1, \ldots, n-p$ ; and

(A.3.3) 
$$B_{\bullet} = \{ \operatorname{Sym}^{p-1}(\mathcal{G}) \to \cdots \to \mathcal{G} \otimes \bigwedge^{p-2}(\mathcal{F}) \to \bigwedge^{p-1}(\mathcal{F}) \}$$

placed at cohomological degree  $-(p-1), \ldots, -1, 0$ . Then we have quasi-isomorphisms

$$T \to T_X[0], \quad \Omega_X^p[0] \to A, \quad B \to \Omega_X^{p-q}[0].$$

The contraction

<span id="page-21-4"></span>
$$T_X \otimes \Omega_X^p \to \Omega_X^{p-1}$$

thus induces a morphism

$$(A.3.4) \langle \cdot, \cdot \rangle : T \otimes A \to B,$$

in the derived category  $\mathcal{D}^b_{\mathrm{Coh}}(X)$ . The morphism  $\langle .,. \rangle$  has an explicit description: By mulitilinear algebra, there are natural contractions

$$\bigwedge^{s+t}(\mathcal{E}) \otimes \bigwedge^{s}(\mathcal{E}^{*}) \to \bigwedge^{t}(\mathcal{E}), \quad \operatorname{Sym}^{s+t}(\mathcal{E}) \otimes D_{s}(\mathcal{E}^{*}) \to \operatorname{Sym}^{t}(\mathcal{E}).$$

Note that the hypothesis A.2(ii) says precisely that

$$H^{j+1}(X, T_j) = 0, \quad 0 \le j \le n-2.$$

<span id="page-22-0"></span>**A.4. Spectral sequences.** We shall prove the infinitesimal Torelli theorem by an induction argument with the help of certain spectral sequences. There are spectral sequences

$$^{T}E_{1}^{-i,j} = H^{j}(X, T_{i}), ^{A}E_{1}^{i,j} = H^{j}(X, A^{i}), ^{B}E_{1}^{-i,j} = H^{j}(X, B_{i})$$

abutting to  $\mathrm{H}^*(X,T_X)$ ,  $\mathrm{H}^*(X,\Omega_X^p)$  and  $\mathrm{H}^*(X,\Omega_X^{p-1})$  respectively. The map (A.3.4) thus induces a morphism

$$\langle \cdot, \cdot \rangle_m : {}^TE_m^{-i,j} \otimes {}^AE_m^{s,t} \to {}^BE_m^{s-i,j+t}.$$

on the level of spectral sequences (i.e., compatible with differentials). This follows from the construction of the spectral sequences (since the naïve filtration, which is used to define these spectral sequences is preserved under the tensor product).

<span id="page-22-1"></span>Ultimately we are interested in the map

$$(A.4.1) \qquad \langle \cdot, \cdot \rangle : H^1(X, T_X) \otimes H^{n-p}(X, \Omega_X^p) \to H^{n-p+1}(X, \Omega_X^{p-1}).$$

The product structure on the spectral sequences eventually computes the tensor product of assoicated graded vector spaces for the infinitesimal Torelli map.

We wish to prove that (A.4.1) is injective on the first factor, in the sense that if an element  $\xi \in H^1(X, T_X)$  induces the zero linear function, i.e.,  $\langle \xi, \cdot \rangle = 0$ , then  $\xi$  must be zero. The relevant terms in  $^TE_m^{-i,j}$  are those with j-i=1.

must be zero. The relevant terms in  ${}^TE_m^{-i,j}$  are those with j-i=1. Hypothesis A.2(ii) says that  ${}^TE_1^{-i,j}=0$  for all j-i=1 and  $i\neq -(n-1)$ . Since (-(n-1),n) is the left highest edge of the spectral sequence, we infer that  $H^1(X,T_X)={}^TE_\infty^{-(n-1),n}$  and is the intersection

$$\bigcap_{m} \operatorname{Ker}(d_{m}^{-(n-1),n}) \subset {}^{T}E_{1}^{-(n-1),n}.$$

We shall denote by  $V_{n-1-m}$  the subspace  $\operatorname{Ker}(d_m^{-(n-1),n})$  of  $V_{n-1} = {}^TE_1^{-(n-1),n}$ . Then  $V_m \subset V_{m-1}$  and  $\operatorname{H}^1(X,T_X)$  is  $V_0$ . It turns out Flenner's condition (i) of Hypothesis A.2 puts some non-deneneracy on the first stage of the spectral sequences.

**Lemma A.5.** Let notation be as above. The pairing

$$\langle \cdot, \cdot \rangle : V_0 \otimes {}^A E_1^{n-p,0} \to {}^B E_1^{-(p-1),n}$$

is injective on the first factor.

*Proof.* By the definition of the spectral sequence, the pairing is

$$H^n(X, \omega_X^* \otimes \operatorname{Sym}^{n-1}(\mathcal{G})) \otimes H^0(X, D_{n-p}(\mathcal{G}^*) \otimes \omega_X) \to H^n(X, \operatorname{Sym}^{p-1}(\mathcal{G})).$$

But saying the injectivity on the first factor amounts to saying, thanks to the Serre duality, that the pairing in Situation A.2 (i) is surjective. We win.  $\Box$ 

<span id="page-22-2"></span>**Lemma A.6.** For all m > 0, we have

$$V_{n-m} \otimes {}^A E_m^{n-p,0} \to {}^B E_m^{-(p-1),n}$$

is injective on the first factor.

*Proof.* We have the following diagram

$$V_{n-m+1} \otimes {}^{A}E_{m-1}^{n-p,0} \longrightarrow {}^{B}E_{m-1}^{-(p-1),n}$$

$$\uparrow \qquad \qquad \downarrow \qquad \qquad \uparrow$$

$$V_{n-m} \otimes {}^{A}E_{m}^{n-p,0} \longrightarrow {}^{B}E_{m}^{-(p-1),n}$$

The right vertical arrow in injective since the coordinate (-(p-1), n) of the spot forces so (it's the left-most highest spot for  $^BE$ ). By the definition of  $V_{n-m}$ , an element v of it satisfies the property

$$\langle v, d_{m-1}a \rangle = 0.$$

Since  ${}^AE_m^{n-p,0}$  is defined to be the quotient  ${}^AE_{m-1}^{n-p,0}/\mathrm{Im}(d_{m-1})$ , we see the second horizontal pairing is indeed injective on the first fact, by induction on m.

<span id="page-23-1"></span>**Theorem A.7.** Let notation be as in Situation A.2. The pairing

$$\mathrm{H}^1(X,T_X)\otimes\mathrm{H}^{n-p}(X,\Omega_X^p)\to\mathrm{H}^{n-p+1}(X,\Omega_X^{p-1})$$

is injective on the first factor.

*Proof.* Let  $\xi$  be an element in  $E_{\infty}^{-(n-1),n} = V_0 = \mathrm{H}^1(X,T_X)$  that pairs to zero with the second factor. Then it kills all elements in  ${}^AE_{\infty}^{n-p,0}$  (the right lowest edge of the spectral sequence) since this is a subspace of  $\mathrm{H}^{n-p}(X,\Omega_X^p)$ . By Lemma A.6,  $\xi$  is zero. This completes the proof.

**A.8. Applications to complete intersections.** Flenner's theorem has several applications. Most notably is the validity of the infinitesimal Torelli for complete intersections in projective spaces. Using Theorem A.7, Flenner, in his original paper, proves the infinitesimal Torelli theorem for complete intersections by verifying the his conditions (i) and (ii) for them. The proof is about linear algebra of polynomials, and only uses the Bott vanishing theorem for the projective space as an extra input, hence does not depend on the ambient field. The only possible issue is the duality between symmetric power and divided power, but this is readily resolved by noticing the following fact: If  $L_1, \ldots, L_r$  are line bundles on a variety X, then there is an isomorphism of bialgebras

$$D_*(L_1 \oplus \cdots \oplus L_r) \cong \bigoplus L_1^{i_1} \otimes \cdots \otimes L_r^{i_r}.$$

This is true, since the dual algebra of  $D_*$  is the symmetric algebra, and the symmetric algebra version of this isomorphism is well-known.

<span id="page-23-0"></span>**Proposition A.9.** Let k be any algebraically closed field. Let X be a complete intersection of type  $(d_1, \ldots, d_c)$   $(d_i \geq 2)$  in a projective space  $\mathbb{P}^{n+c}$ . Then the conditions (i), (ii) of Hypothesis A.2 are verified for the exact sequence

$$0 \to \bigoplus_{i=1}^{c} \mathcal{O}_X(-d_i) \to \Omega^1_{\mathbb{P}^{n+c}}|_X \to \Omega^1_X \to 0.$$

except the cases listed below. Hence the infinitesimal Torelli theorem holds for all complete intersections except for the ones listed below.

There are a few cases that (i) and (ii) do not verify, these exceptions are:

- (1) (2,2) complete intersections,
- (2) cubic surfaces,
- (3) even dimensional (2,3) complete intersections,
- (4) even dimensional (2,2,2) complete intersections,
- (5) cubic fourfolds,
- (6) quartic K3 surfaces, and
- (7) quadrics.

As is well-known, the infinitesimal Torelli fails for cubics and even dimensional (2,2) complete intersections. For quadrics the infinitesimal Torellis theorem is trivial.

We need the infinitesimal Torelli for a complete intersection over a field of characteristic p>0 in Section 4 to conclude the proof of Theorem 1.5(ii). For cubic fourfolds, the second-named author has verified the validity of Theorem 1.5(ii) in another paper [Pan15]. Thus, to conclude the proof we need, in addition to the cases covered by Proposition A.9, we still need verify the infinitesimal Torelli holds true for (2,2,2)-type complete intersections and (2,3)-type complete intersections of even dimension. Flenner, in his original paper, already proves these cases by other means (modifying his scheme of proofs). But we decide to provide an exposition to these facts for the sake of completeness. Both cases are proven similarly. Flenner treated the case (2,2,2); so we shall illustrate our method by dealing with (2,3) complete intersections in  $\mathbb{P}^{2p+2}$ .

Recall that the Bott vanishing theorem asserts that the cohomology groups

$$\mathrm{H}^b(\mathbb{P}^r,\Omega^a_{\mathbb{P}^r}(\ell))$$

vanish except in the following cases:

- $b = a, \ell = 0,$
- $b = 0, \ell > a$ , or
- b = r,  $\ell < a r$ .

For a smooth (2,3) complete intersection X in  $\mathbb{P} = \mathbb{P}^{2p+2}$ , there might be one extra term in  ${}^{T}E_{1}$  that is nonzero, namely  ${}^{T}E_{1}^{-(p-1),p}$ . This term is

$$H^p(X, \Omega_p^p|_X \otimes \operatorname{Sym}^{p-1}(\mathcal{O}_X(-2) \otimes \mathcal{O}_X(-3)) \otimes \mathcal{O}_X(2p-2)).$$

By the binomial theorem, this cohomology group can be decomposed into a direct sum

$$\bigoplus_{i=0}^{p-1} \mathrm{H}^p(X, \Omega^p_{\mathbb{P}}(-i)|_X)^{\oplus \binom{p-1}{i}}$$

By the Bott vanishing theorem and the spectral sequence associated to the Koszul complex, one sees that the only nontrivial summand in the decomposition is

$$k \cong \mathrm{H}^p(X, \Omega^p_{\mathbb{D}}|_X).$$

If this 1-dimensional space is killed by some differential of  ${}^TE$ , then it won't contribute anything to the eventual infinitesimal Torelli map, and we already win. If the contrary holds, and suppose  $\xi \neq 0$  kills all the space  $\mathrm{H}^p(X,\Omega_X^p)$ . Let's derive a contradiction. Then each element  $\eta \in \mathrm{H}^p(X,\Omega_X^p) = \mathrm{H}^0(X,\Omega_X^p[p])$  induces a homomorphism of spectral sequences

$$\langle \cdot, \eta \rangle : {}^T E_m^{a,b} \to {}^B E_m^{a,b+p}.$$

At the  $E_1$ -stage, by identifying  ${}^BE_1^{-(p-1),2p}$  with  $\mathrm{H}^{2p}(X,\omega_X)$  and  ${}^TE_1^{-(p-1),p}$  with  $\mathrm{H}^p(X,\Omega_p^p|_X)$ , this map is identified with the cup-product map

$$(A.9.1) \qquad \qquad \cup \eta: \mathrm{H}^p(X, \Omega^p_{\mathbb{P}}|_X) \to \mathrm{H}^{2p}(X, \omega_X).$$

Since  ${}^TE_1^{-(p-1),p}={}^TE_\infty^{-(p-1),p}$ , the image of the above map actually falls in  ${}^BE_\infty^{-(p-1),2p}\subset \mathrm{H}^{2p}(X,\omega_X)$ . The map (A.9.1) is not always zero as the pairing

<span id="page-25-16"></span>
$$\mathrm{H}^p(X,\Omega^p_{\mathbb{P}}|_X)\otimes\mathrm{H}^p(X,\Omega^p_X)\to\mathrm{H}^{2p}(X,\omega_X).$$

is not identically zero (which also yields  $H^{2p}(X,\omega_X)$  survives in  $^BE_{\infty}$ ).

#### <span id="page-25-0"></span>References

- <span id="page-25-2"></span>[Ben13] Olivier Benoist. Séparation et propriété de Deligne-Mumford des champs de modules d'intersections complètes lisses. J. Lond. Math. Soc. (2), 87(1):138–156, 2013.
- <span id="page-25-4"></span>[Che13] Xi Chen. Rational self maps of calabi-yau manifolds. In A celebration of algebraic geometry, volume 18 of Clay Math. Proc., pages 171–184. Amer. Math. Soc., Providence, RI, 2013.
- <span id="page-25-7"></span>[Fle86] Hubert Flenner. The infinitesimal Torelli problem for zero sets of sections of vector bundles. Math. Z., 193(2):307–322, 1986.
- <span id="page-25-12"></span>[Har77] Robin Hartshorne. Algebraic geometry. Springer-Verlag, New York-Heidelberg, 1977. Graduate Texts in Mathematics, No. 52.
- <span id="page-25-9"></span>[III72] Luc Illusie. Complexe cotangent et déformations. II. Lecture Notes in Mathematics, Vol. 283. Springer-Verlag, Berlin-New York, 1972.
- <span id="page-25-3"></span>[JL17] Ariyan Javanpeykar and Daniel Loughran. Complete intersections: Moduli, torelli, and good reduction. Math. Ann. 368 (2017), no. 3-4, 1191–1225.
- <span id="page-25-10"></span>[Kaw92] Yujiro Kawamata. Unobstructed deformations. A remark on a paper of Z. Ran: "Deformations of manifolds with torsion or negative canonical bundle" [J. Algebraic Geom. 1 (1992), no. 2, 279–291; MR1144440 (93e:14015)]. J. Algebraic Geom., 1(2):183–190, 1992.
- <span id="page-25-13"></span>[KM74] Nick Katz and William Messing. Some consequences of the riemann hypothesis for varieties over finite fields. Invent. Math., 23:73-77, 1974.
- <span id="page-25-1"></span>[MM64] Hideyuki Matsumura and Paul Monsky. On the automorphisms of hypersurfaces. J. Math. Kyoto Univ., 3:347–361, 1963/1964.
- <span id="page-25-14"></span>[Pan15] Xuanyu Pan. Automorphism and cohomology I: Fano variety of lines and cubic. Preprint. arXiv:1511.05272v3, 2015.
- <span id="page-25-6"></span>[Pan16] Xuanyu Pan. p-adic deformations of graph cycles. Preprint. arXiv:1610.03836, 2016.
- <span id="page-25-5"></span>[Pan18] Xuanyu Pan. Spaces of conics on low degree complete intersections. Trans. Amer. Math. Soc., 370 (2018), no. 8, 5381–5400.
- <span id="page-25-15"></span>[Poo00] Bjorn Poonen. Varieties without extra automorphisms. II. Hyperelliptic curves. Math. Res. Lett., 7(1):77–82, 2000.
- <span id="page-25-11"></span>[Ran92] Ziv Ran. Deformations of manifolds with torsion or negative canonical bundle. J. Algebraic Geom., 1(2):279–291, 1992.
- <span id="page-25-8"></span>[Rei72] Miles Reid. The complete intersection of two or more quadrics. Thesis, 1972.

632 Central Academic Building, University of Alberta, Edmonton, Alberta T6G 2G1, CANADA

Email address: xichen@math.ualberta.ca

Institute of Mathematics, AMSS, Chinese Academy of Sciences, 55 ZhongGuanCun East Road, Beijing 100190, China

Email address: pan@amss.ac.cn

YMSC, TSINGHUA UNIVERSITY, 30 SHUANGQING RD, BEIJING 100190, CHINA  $Email\ address$ : zhangdingxin13@gmail.com