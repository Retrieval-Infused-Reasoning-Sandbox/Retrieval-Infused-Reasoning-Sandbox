# **Twisted Sectors in Calabi-Yau Type Fermat Polynomial Singularities and Automorphic Forms**

# Dingxin Zhang and Jie Zhou

#### **Abstract**

We study one-parameter deformations of Calabi-Yau type Fermat polynomial singularities along degree-one directions. We show that twisted sectors in the vanishing cohomology are components of automorphic forms for certain triangular groups. We prove consequently that genus zero Gromov-Witten generating series of the corresponding Fermat Calabi-Yau varieties are components of automorphic forms. The main tools we use are mixed Hodge structures for quasihomogeneous polynomial singularities, Riemann-Hilbert correspondence, and genus zero mirror symmetry.

# **Contents**

| 1 | Introduction                                                                | 1  |
|---|-----------------------------------------------------------------------------|----|
| 2 | Cohomology bundles and automorphic forms                                    | 6  |
|   | 2.1<br>Twisted sectors for quasi-homogeneous singularities<br>              | 6  |
|   | 2.2<br>Ordinary differential equations for geometric sections<br>           | 9  |
|   | 2.3<br>Automorphic bundles corresponding to D-modules                       | 12 |
|   | 2.4<br>Examples                                                             | 14 |
| 3 | Genus zero GW invariants of Fermat Calabi-Yau varieties                     | 23 |
|   | 3.1<br>I- and J-functions                                                   | 23 |
|   | 3.2<br>Genus zero mirror symmetry<br>                                       | 27 |
|   | Appendix A<br>Basics on singularities                                       | 28 |
|   | Appendix B<br>Elliptic modular forms in Calabi-Yau sector of Fermat quartic | 32 |

# <span id="page-0-0"></span>**1 Introduction**

The interplay between Gromov-Witten (GW) theory (and other enumerative theories) and modular forms (and more generally automorphic forms) has been an interesting topic in the last few decades. On the one hand, the identification between generating series of enumerative invariants and automorphic forms can often reduce computations on the infinite sequences of invariants to finite computations and hence make it much easier for computational purposes. On the other hand, the nice properties of automorphic forms provide useful tools and perspectives to understand these invariants, and to test new ideas and conjectures in enumerative theories.

Our main idea in approaching modularity and automorphicity in the generating series of GW invariants (and other enumerative invariants) is illustrated in Figure [1](#page-1-0) below.

<span id="page-1-0"></span>![](_page_1_Figure_0.jpeg)

**Figure 1:** Automorphic bundles arise in both A-model and B-model. Identification of the corresponding D-modules arising in the two models provides a mirror map.

In the present work, for the A-model we shall study GW invariants of the Calabi-Yau (CY) variety

<span id="page-1-3"></span>
$$M = \{p(x) := \sum_{i=0}^{n} x_i^{n+1} = 0\} \subseteq \mathbb{P}^n, \quad n \ge 2,$$
(1.1)

and certain quotients thereof. The invariants and corresponding genus zero mirror symmetry for the CY variety M have been extensively explored [CdLOGP91, Giv96, Giv98, LLY97, LLY98], our main focus is then the orbifold GW invariants of the quotients of M, see e.g., [LS14, IMRS21] for related studies.

For the B-model, we consider the mixed Hodge structure on the vanishing cohomology of the polynomial singularity

<span id="page-1-1"></span>
$$f_a: \mathbb{C}^{n+1} \to \mathbb{C},$$

$$(z_0, z_1, \cdots, z_n) \mapsto \sum_{i=0}^n z_i^{n+1} - a \prod_{i=0}^n z_i, \quad a \in S,$$

$$(1.2)$$

where  $S := \mathbb{C} - \{a^{n+1} = (n+1)^{n+1}\}$  is contained in the  $\mu$ -constant strata. Closely related is the CY variety

<span id="page-1-2"></span>
$$Q_a = \{ f_a = 0 \} \subseteq \mathbb{P}^n, \quad a \in S.$$
 (1.3)

The corresponding family of singularities or CY varieties will be referred to as the *Dwork family* in this work. The vanishing cohomology of the singularity  $f_a$  contains a subspace  $D_0$  that is identical to the primitive part of  $H^{n-1}(Q_a)$  under the Poincaré residue map (see Section 2.1). This space is mirror to a subspace of  $H^{\text{even}}(M)$  and connects to the genus zero GW theory of the CY space M.

The polynomial (1.2) is quasi-homogeneous with weighted degree  $q_i$  (called polynomial degree in what follows) of  $z_i$  given by  $q_i = 1/(n+1)$  for  $i = 0, 1, \dots, n$ . It is of Calabi-Yau type in the sense that the summation of the individual weighted degrees  $q_i$  is 1:  $\sum_{i=0}^n q_i = 1$ . The quasi-homogeneity leads to great simplifications in the studies of mixed Hodge structures for the singularities as we shall see.

#### Automorphic bundles from vanishing cohomology

"Twisted sectors" attached to a singularity are defined by using the mixed Hodge structure on the vanishing cohomology. They are represented by (leading parts of) geometric sections [AGZV85, AGZV88]. For a family of quasi-homogeneous polynomial singularities, they have very concrete descriptions. See Section 2.1 for their definitions and descriptions.

Consider the Dwork family of singularities (1.2). A direct calculation shows that each geometric section  $s[\mathbf{z^m}\Omega]$  satisfies a simple differential equation. It then gives rise to a flat vector bundle  $D_{\mathbf{m}}$ , over a base  $\mathcal M$  that is related to S by a finite covering map. By the Riemann-Hilbert correspondence (more concretely the monodromy representation), one obtains an orbifold structure  $T_{\mathbf{m}} = \Gamma_{\mathbf{m}} \setminus \mathcal{H}$  on  $\mathcal M$ , where  $\Gamma_{\mathbf{m}} < \mathrm{PSL}_2(\mathbb R)$  is a triangular group that acts on the upper-half plane  $\mathcal H$ . The multi-valued map  $s_{\mathbf{m}}: \mathcal M \to \mathcal H$  is provided by the Schwarzian and will be called the Schwarzian uniformization in this work. Each cohomology sector  $D_{\mathbf{m}}$  then corresponds to a monodromy representation

$$\rho_{\mathbf{m}}: \Gamma_{\mathbf{m}} \cong \pi_1^{\text{orb}}(T_{\mathbf{m}}) \to \text{End}(D_{\mathbf{m}}).$$
(1.4)

The bundle  $D_{\mathbf{m}}$  is an automorphic bundle for the triangular group  $\Gamma_{\mathbf{m}}$  in the sense of the definition below.

<span id="page-2-4"></span>**Definition 1.1.** Let  $\Gamma < \operatorname{PSL}_2(\mathbb{R}) = \operatorname{Aut} \mathcal{H}$  be a Fuchsian group acting on the upper-half plane  $\mathcal{H}$ . Let  $e : \Gamma \times \mathcal{H} \to \operatorname{GL}(\mathbb{V})$  be an automorphy factor, that is,

$$e_{\gamma_2}(\gamma_1 \tau) \circ e_{\gamma_1}(\tau) = e_{\gamma_2 \circ \gamma_1}(\tau)$$
,  $\forall \gamma_1, \gamma_2 \in \Gamma$ ,  $\tau \in \mathcal{H}$ .

The bundle  $\mathcal{V}_e := \mathcal{H} \times_e \mathbb{V}$  over  $\Gamma \setminus \mathcal{H}$  defined by  $e \in H^1(\Gamma, GL(\mathcal{O}(\mathcal{H}) \otimes \mathbb{V}))$  is called an automorphic bundle for  $\Gamma$ . A (vector-valued) automorphic form with automorphy factor e is a meromorphic section of the automorphic bundle  $\mathcal{V}_e$ . Concretely, it is given by a meromorphic function  $\phi : \mathcal{H} \to \mathbb{V}$  satisfying

<span id="page-2-3"></span>
$$\phi(\gamma \tau) = e_{\gamma}(\tau)\phi(\tau), \quad \forall \gamma \in \Gamma, \tau \in \mathcal{H}. \tag{1.5}$$

Similarly, one can define automorphic bundles over the compactification of  $\Gamma \backslash \mathcal{H}$  by specifying meromorphic behaviour at the cusps on  $\Gamma \backslash \mathcal{H}$ .

**Example 1.2.** Taking the automorphy factor e to be a representation  $\rho : \Gamma \to GL(\mathbb{V})$ , then the automorphic bundle  $\mathcal{V}_e$  is a flat bundle. Taking e to be the j-automorphy factor

<span id="page-2-1"></span>
$$j(\gamma,\tau) = (c\tau + d)^k, \quad \forall \gamma = \begin{pmatrix} a & b \\ c & d \end{pmatrix} \in \Gamma, \ k \in 2\mathbb{Z},$$
 (1.6)

then one obtains the notion of automorphic forms of weight k. For a general  $k \in \mathbb{Q}$ ,  $(c\tau + d)^k$  is multi-valued, and needs to be accompanied by a multiplier system to yield an automorphy factor [Sch74, Ran77].

One can furthermore find a triangular group  $\Gamma_{\star} = \Gamma_{n+1,\infty,\infty} < PSL_2(\mathbb{R})$  such that for any **m** there exists a natural homomorphism

$$\rho_{\mathbf{m},\star}: \Gamma_{\star} \to \Gamma_{\mathbf{m}}. \tag{1.7}$$

which respects the semi-simple parts of their monodromy representations. See Section 2.4 for detailed discussions. Then the composition  $\rho_{\mathbf{m}} \circ \rho_{\mathbf{m},\star}$  realizes  $D_{\mathbf{m}}$  as a representation of  $\Gamma_{\star}$ . This tells that all cohomology bundles are in fact automorphic bundles for  $\Gamma_{\star}$ .

<span id="page-2-2"></span>**Theorem 1.3** (Theorem 2.5). Consider the Dwork family of polynomial singularities (1.2). For each  $\mathbf{m}$ , there exists a triple  $\ell(\mathbf{m}) = (\ell_0(\mathbf{m}) = n + 1, \ell_1(\mathbf{m}), \ell_\infty(\mathbf{m}))$ , such that the corresponding flat bundle  $D_{\mathbf{m}}$  over  $\mathcal{M}$  is an automorphic bundle and thus the geometric section  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  is the component of an automorphic form for the triangular group  $\Gamma_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})} < \mathrm{PSL}_2(\mathbb{R})$ . In particular, all of the geometric sections are components of automorphic forms for  $\Gamma_{n+1,\infty,\infty}$ .

<span id="page-2-0"></span> $<sup>^1</sup>$ To be precise, the map to the coarse moduli is  $T_{\mathbf{m}} \to \overline{\mathcal{M}}_{\mathbf{m}}$ , where  $\overline{\mathcal{M}}_{\mathbf{m}}$  is obtained from  $\mathcal{M}$  by filling in the elliptic points (i.e., points with finite-order monodromies). See Section 2.3 for detailed explanation. Here we ignore this subtlety for notational convenience.

By Deligne's canonical extension, the flat bundle  $D_{\mathbf{m}}$  extends to a vector bundle  $\overline{D}_{\mathbf{m}}$  on the compactified orbifold  $\overline{T}_{\mathbf{m}}$ . Both automorphic bundles  $D_{\mathbf{m}}$ ,  $\overline{D}_{\mathbf{m}}$  are equipped with [Sch73] Hodge filtrations  $F^{\bullet}D_{\mathbf{m}}$ ,  $F^{\bullet}\overline{D}_{\mathbf{m}}$  which are induced from the ones defined on the vanishing cohomology bundle H. By definition, sections of  $D_{\mathbf{m}}$ ,  $\overline{D}_{\mathbf{m}}$  and in particular those of the sub-bundles  $F^{p}D_{\mathbf{m}}$ ,  $F^{p}\overline{D}_{\mathbf{m}}$ , are components of automorphic forms with or without boundary conditions imposed at the elliptic points and cusps [SS14, CF17, CF19].

Moreover, for the cases with rank  $D_{\mathbf{m}} \leq 2$ , the automorphy factors for the nontrivial top pieces  $F^{\text{top}}D_{\mathbf{m}}$  turn out to be given by the familiar j-automorphy factor (1.6) by using the Schwarzian uniformization, and the corresponding automorphic forms have weights given by rank  $D_{\mathbf{m}} - 1$ . A frame of any other Hodge sub-bundle can then be obtained by applying the Gauss-Manin connection on that of  $F^{\text{top}}D_{\mathbf{m}}$ . From the resulting frame one can directly read off the automorphy factor for the sub-bundle. Sections of these Hodge sub-bundles are analogues of quasi-modular forms [KZ95]. See Remark 2.7 and Section 2.4 for detailed discussions on these.

#### Automorphicity of genus zero Gromov-Witten generating series

The sector  $D_{\mathbf{m}}$  with  $\mathbf{m} = \mathbf{0}$  plays a distinguished role for the following reasons.

- Consider the CY variety (1.3). As mentioned earlier, the  $D_0$  sector in the vanishing cohomology of  $f_a$  is identified with the primitive part  $H^{n-1}(Q_a)$  via the Poincaré residue map. This establishes the so-called Landau-Ginzburg/Calabi-Yau correspondence [CR10] on the level of state spaces. Under mirror symmetry, it leads the identification of the genus zero Gromov-Witten theory of M in (1.1) and the genus zero Fan-Jarvis-Ruan-Witten (FJRW) theory of  $p:\mathbb{C}^{n+1}\to\mathbb{C}$ .
- Generating series involving other sectors  $D_{\mathbf{m}}$  are often expanded in terms of the Schwarzian  $s_0 \in \mathcal{H}_0$  arising from the sector  $D_0$ , instead of their own Schwarzians  $s_{\mathbf{m}}$  valued in  $\mathcal{H}_{\mathbf{m}}$ . From the perspective of the GW theory of the mirror M, this is due to the divisor axiom. Note that here although both  $\mathcal{H}_0$  and  $\mathcal{H}_{\mathbf{m}}$  are isomorphic to the upper-half plane  $\mathcal{H}$ , the corresponding Schwarzian maps on  $\mathcal{M}$  are not identical.

In the cases of Fermat cubic and quartic, we can in fact show (see Section 2.4 and Appendix B) that the Schwarzian  $s_0$  corresponds to the complex structure modulus  $\tau$  for certain elliptic curve families.

Let us be a little more precise. Consider the genus zero GW theory of the CY variety M. According to genus zero mirror symmetry [Giv96, LLY97] for CY hypersurfaces in projective spaces, it is mirror to the theory of variation of Hodge structures for the degeneration near  $a = \infty$  in the Dwork family  $\{Q_a\}_{a \in S}$  in (1.3).<sup>2</sup> By Theorem 1.3 and the Poincaré residue map mentioned above, we obtain the following result.

**Theorem 1.4** (Theorem 3.1). Consider the genus zero Gromov-Witten invariants for the Calabi-Yau (n-1)-fold M defined by the vanishing locus of the Fermat polynomial  $\sum_{i=0}^{n} x_i^{n+1} = 0$  in  $\mathbb{P}^n$ . Then the I-function, as a generating series of certain one-point GW invariants of M, is a component of an automorphic form valued in  $H^*(M)$  for the triangular group  $\Gamma_{n+1,\infty,\infty}$ . In particular, for the n=2,3 cases, the automorphic form is a vector-valued elliptic modular form (with possibly nontrivial multiplier systems) for certain congruence subgroup in  $\mathrm{PSL}_2(\mathbb{Z})$ .

The D-module  $D_0$  that underlies the variation of Hodge structures on the primitive part of  $H^{n-1}(Q_a)$  captures not only genus zero data but also essential higher genus information [BCOV94, Wit93, Li11, CL12, YY04]. We demonstrate this on the Fermat quintic case which has been regarded

<span id="page-3-0"></span> $<sup>^{2}</sup>$ The family of mirror manifolds of M is in fact the quotient of the Dwork family [Bat94], whose associated variation of Hodge structures is however equivalent to that of the Dwork family itself. See [CK99] and [Gro03] for nice expositions.

as the prototypical example of mirror symmetry since its birth [GP90, CLS90, CdLOGP91]. Consider the Picard-Fuchs operator for the Dwork family  $\{Q_a\}_{a\in S}$  in (1.3)

$$\mathcal{D}_{\text{quintic}} = \theta^4 - z \prod_{k=1}^4 (\theta + \frac{k}{5}), \quad z = 5^{-5} a^{-5}, \quad \theta := z \frac{\partial}{\partial z}.$$
 (1.8)

Taking a basis of solutions near the maximally unipotent monodromy point z=0 and denote them by  $I_0$ ,  $I_1$ ,  $I_2$ ,  $I_3$ , respectively. Set  $T=I_1/I_0$  and define the Yamaguchi-Yau polynomial ring [BCOV94, YY04] to be (see Definition 2.12)

$$\mathcal{F}_{YY} := \mathbb{C}(z) \left[ \frac{I_0'}{I_0}, \frac{I_0''}{I_0}, \frac{I_0'''}{I_0}, \frac{T''}{T'} \right], \quad ' = \partial_z.$$
 (1.9)

A renowned conjecture [BCOV94, YY04] in the studies of higher genus GW theory that has stimulated many progresses in the last few decades is that GW generating series of higher genus invariants of the Fermat quintic are polynomials lying in the Yamaguchi-Yau ring  $\mathcal{F}_{YY}$ . This conjecture is recently proved in a series of works including [Zin09, LP18, CGL18, GJR18], in which properties of the Yamaguchi-Yau polynomial ring plays a central role.

In this work we show the following result regarding the automorphicity of this ring which seems to be of independent interest.

<span id="page-4-0"></span>**Theorem 1.5** (Proposition 2.13, Theorem 2.14). Consider the Dwork family (1.3) with n=4. The Yamaguchi-Yau ring  $\mathcal{F}_{YY}$  is a differential ring under  $\partial_z$ , with generators being components of automorphic forms for  $\Gamma_{\infty,\infty,5}$ . Furthermore, the Yamaguchi-Yau generators are algebraically independent over  $\mathbb{C}(z)$ .

The above result on period integrals can be rephrased as follows. Since S is affine, we may freely pass between sheaves and ordinary modules by taking global sections and localizing. Let  $(H^{n-1}_{\text{prim}}, \mathcal{V}, F^{\bullet}, \nabla, S)$  be the aforementioned variation of Hodge structures associated to the degeneration in the Dwork family (1.3). Consider the fractional field of the coordinate expressions of elements in  $H^0(S, \mathcal{V})$  with respect to the locally constant frame, then the proof of Theorem 1.5, in particular (2.45), gives the set of generators and relations for its differential closure.

Remark 1.6. According to (1.5) in Definition 1.1, analytically automorphic forms are vector-valued functions on  $\mathcal{H}$  that enjoy nice symmetries under the action of  $\Gamma$  specified by the automorphy factors. Once the generating series in enumerative theories are proved to be automorphic forms, one can then use these symmetries to study relations between various enumerative theories defined over  $\mathcal{M}$  such as higher genus GW and FJRW theories [SZ18, LSZ20]. These relations are usually difficult to establish by other methods such as analytical continuation.

Many discussions in this work in fact apply to more general one-parameter deformations and to more general CY type quasi-homogeneous polynomial singularities, than the one given in (1.2), using the results from [BH89, Ste77]. In the latter situation the discussions are certainly more involved due to the possible singularities at infinity. We however have decided to focus only on Fermat polynomials and the one-parameter deformations (1.2), in order to keep the presentation relatively clean. We also remark that for multi-dimensional deformations we do not have a good understanding on the automorphic forms part yet, and wish to study them in a future investigation.

Quite a few results contained in this work are known to experts, especially those on the differential equations governing various sectors that have kept occurring in both GW theory and singularity theory. The main contribution of this work is, through carefully working out the details for several examples, to offer a Hodge-theoretic formulation for some of the problems in the studies of GW theory and its mirror symmetry, and to strengthen the connection between GW generating series and automorphic forms which recently seems to have provided useful perspectives to enumerative geometry.

# Organization of the paper

In Section 2 we study the D-modules underlying various cohomology sectors in the Dwork family, and the corresponding automorphic bundles determined from the Riemann-Hilbert correspondence. We supply some examples in which the computations are carefully worked out. In addition, for the Fermat quintic we use differential Galois theory to study algebraic properties of the Yamaguchi-Yau ring.

In Section 3 we consider genus zero mirror symmetry of Fermat Calabi-Yau varieties. Applying the results in Section 2 we show that genus zero GW generating series are components of automorphic forms. We focus on quotients of the Fermat quartic K3 surface as examples, by showing that twisted sectors in the Chen-Ruan cohomology are matched with twisted sectors of the mirror singularity theory and the corresponding GW generating series are matched with oscillating integrals.

Some preliminaries on singularity theory are collected in Appendix A. Detailed discussions on elliptic modular forms appearing in the Fermat quartic case are carried out in Appendix B.

### Acknowledgement

We thank Todor Milanov, Yongbin Ruan, Yefeng Shen, Hsian-Hua Tseng and Yingchun Zhang for useful conversations and communications.

The work of J. Z. is partially supported by a start-up grant at Tsinghua University, the Young overseas high-level talents introduction plan of China, and national key research and development program of China (NO. 2020YFA0713000).

# <span id="page-5-0"></span>2 Cohomology bundles and automorphic forms

In this section, we first explain the definition of twisted sectors using the mixed Hodge structure on the vanishing cohomology of a quasi-homogeneous singularity. Then we consider special one-parameter families of Calabi-Yau type Fermat polynomial singularities, with an emphasis on the Dwork family (1.2). We compute the D-modules corresponding to the twisted sectors of the latter and conclude that they correspond to automorphic bundles for certain triangular groups. Our main tools are the theory of mixed Hodge structures for quasi-homogeneous polynomial singularities and Riemann-Hilbert correspondence.

We follow closely the notation and expositions in [Kul98]. For completeness, some basics on singularities are collected in Appendix A, following [Sai83, Mat98, Kul98, ST08]. Readers who are unfamiliar with singularity theory are referred there for a quick introduction.

# <span id="page-5-1"></span>2.1 Twisted sectors for quasi-homogeneous singularities

Let  $z=(z_0,z_1,\cdots,z_n)$  be the standard coordinates on  $\mathbb{C}^{n+1}$  and  $f:\mathbb{C}^{n+1}\to\mathbb{C}$  be a quasi-homogeneous polynomial singularity, with the polynomial degree of  $z_i$  given by  $q_i,i=0,1,\cdots,n$ . Consider the one-parameter deformation

<span id="page-5-2"></span>
$$F: X = \mathbb{C}^{n+1} \times S \to \mathbb{C}, \quad (z,a) \mapsto f(z) - ae_1(z),$$
 (2.1)

where

the monomial

<span id="page-5-3"></span>
$$e_1(z) = \prod_{i=0}^{n} z_i^{d_i}, \quad d_i \in \mathbb{N}$$
 (2.2)

is of polynomial degree 1. For example, for the Fermat polynomial  $f = \sum_{i=0}^{n} z_i^{n+1}$ , one can take  $e_1(z) = \prod_{i=0}^{n} z_i$  which then gives the Dwork family (1.2).

• the deformation space is

$$S = \mathbb{C} - \Delta, \tag{2.3}$$

with  $\Delta$  the discriminant locus, such that the projective variety  $Q_a$ ,  $a \in S$  defined as the vanishing locus of  $f_a(z) := f(z) - ae_1(z)$  in the corresponding weighted projective space is nonsingular.

Then one can check that S lies in the  $\mu$ -constant stratum.<sup>3</sup> In particular, the spectrum of  $f_a: X(a) = \mathbb{C}^{n+1} \to \mathbb{C}$  is independent of a.

#### 2.1.1 Mixed Hodge structure on vanishing cohomology

Consider the polynomial singularity  $f_a: X(a) = \mathbb{C}^{n+1} \to \mathbb{C}$ . The vanishing cohomology  $H(a) := H^n(X(a)_\infty, \mathbb{C})$  has an eigenspace decomposition<sup>4</sup>

<span id="page-6-5"></span>
$$H(a) = \bigoplus_{\lambda: |\lambda| = 1} H_{\lambda}(a) \cong \bigoplus_{\alpha: -1 < \alpha \le 0} C_{\alpha}(a), \qquad (2.4)$$

where  $\lambda = e^{-2\pi i\alpha}$  is the eigenvalue of the monodromy  $T = T_{ss}T_u = T_{ss}e^{2\pi iN}$  of the singularity  $f_a$  around its singular fiber  $f_a^{-1}(0)$ , and  $C_\alpha(a) \cong H_\lambda(a)$  is the corresponding generalized eigenspace of the operator  $t\partial_t$ . In particular, one has the following weight filtration, as part of the data of the mixed Hodge structure  $(W_{\bullet}(a), F^{\bullet}(a))$  on H(a)

$$\cdots \subseteq W_{n-1}H(a) = 0 \subseteq W_nH(a) = \bigoplus_{\lambda \neq 1} H_{\lambda}(a) \subseteq W_{n+1}H(a) = H(a) \subseteq \cdots$$

This gives rise to the exact sequence

<span id="page-6-2"></span>
$$0 \to \operatorname{gr}_n^W H(a) = \bigoplus_{\lambda \neq 1} H_{\lambda}(a) \to H(a) \to \operatorname{gr}_{n+1}^W H(a) = \bigoplus_{\lambda = 1} H_{\lambda}(a) \to 0$$
 (2.5)

The projective CY variety  $Q_a$  carries a Hodge structure. It is a standard fact that  $\operatorname{gr}_{n+1}^W H(a)$  is isomorphic to the Hodge structure on the primitive part  $H^{n-1}_{\operatorname{prim}}(Q_a)$  of  $H^{n-1}(Q_a)$  via the Poincaré residue map. In fact, for the current case one has  $H(a) \cong H^n(U_a)$ , where  $U_a$  is the variety given by  $f_a = 1$  in  $\mathbb{C}^{n+1}$ . This variety  $U_a$  can be compactified to a projective variety  $Y_a$ , such that  $U_a = Y_a - Q_a$  is realized as a hypersurface complement. The Gysin sequence then gives a sequence on mixed Hodge structures

<span id="page-6-3"></span>
$$\cdots \to H^n(Y_a) \to H^n(U_a) \xrightarrow{\mathrm{res}} H^{n-1}(Q_a) \otimes \mathbb{C}(-1) \to H^{n+1}(Y_a) \to \cdots, \tag{2.6}$$

where res is the Poincaré residue map and  $\mathbb{C}(-1)$  is the Tate structure of weight 2. Here the weight filtration on  $H^n(U_a)$  is given by

<span id="page-6-4"></span>
$$W_n H^n(U_a) = \operatorname{im} (H^n(Y_a) \to H^n(U_a)) \subseteq W_{n+1} H^n(U_a) = H^n(U_a).$$
 (2.7)

Combining (2.5), (2.6) and (2.7), we obtain

<span id="page-6-6"></span>
$$H(a) \to \operatorname{gr}_{n+1}^W H(a) \xrightarrow{\operatorname{res}} H_{\operatorname{prim}}^{n-1}(Q_a) \otimes \mathbb{C}(-1).$$
 (2.8)

This map provides a realization [Cec91] of the LG/CY correspondence on the level of state spaces using the language of mixed Hodge structures.

<sup>&</sup>lt;sup>3</sup>This ensures that in the setting of Appendix A one has that  $X = \mathbb{C}^{n+1} \times S$  with  $q : X \to S$  and  $\varphi = (F, q) : X \to \mathbb{C} \times S$ , with no need to restrict to smaller neighborhoods. Hence one can focus on polynomials instead of their germs.

<span id="page-6-1"></span><span id="page-6-0"></span><sup>&</sup>lt;sup>4</sup>The last isomorphism is the isomorphism  $\psi(a)$  given in (A.14) in Appendix A, whose notation we omit. Structures defined on  $C_{\alpha}$ , such as the Hodge filtration, are usually transferred to  $H_{\lambda}$  via this isomorphism without explicitly mentioning.

#### 2.1.2 Twisted sectors in vanishing cohomology

Due to the quasi-homogeneity of  $f_a$ , the monodromy T is semi-simple. This makes the mixed Hodge structure  $(W_{\bullet}(a), F^{\bullet}(a))$  on the vanishing cohomology H(a) very concrete.

**Definition 2.1.** Denote  $\mathbf{m} = (m_i)_{i=0}^n$  and  $\mathbf{z}^{\mathbf{m}} = \prod_{i=0}^n z_i^{m_i}$ . Let

$$\beta(\mathbf{m}) = \sum_{i=0}^{n} m_i q_i \,, \tag{2.9}$$

and  $\alpha(\mathbf{m})$  be the unique integral shift of  $\beta(\mathbf{m})$  that is valued in (-1,0].

A basis of  $(f_a)_*\Omega^{n+1}_{X(a)/\mathbb{C}}$  is represented by the differential forms

<span id="page-7-3"></span>
$$\mathbf{z}^{\mathbf{m}}\Omega$$
,  $\Omega := \bigwedge_{i=0}^{n} dz_{i}$ ,  $\mathbf{z}^{\mathbf{m}} \in \operatorname{Jac}(f_{0})$ . (2.10)

The classes  $[\mathbf{z}^{\mathbf{m}}\Omega]$  of these differential forms generate the Brieskorn lattice  $\mathcal{H}^{(0)}(a)$ , which is an extension of the relative de Rham cohomology sheaf  $\mathbb{R}^n f_{a_*} \Omega^{\bullet}_{X(a)/\mathbb{C}}$  (under an isomorphism provided by the map  $df_a \wedge$ ). Their Gelfand-Leray residues, called geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$ , define classes  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  in the vanishing cohomology through their leading parts. These geometric sections are eigenvectors of the operator  $t\partial_t$  with eigenvalue (i.e., spectral number) given by  $\beta = \beta(\mathbf{m})$ . That is,

<span id="page-7-4"></span>
$$(t\partial_t - \beta(\mathbf{m})) \ s[\mathbf{z}^{\mathbf{m}}\Omega] = 0. \tag{2.11}$$

The Hodge filtration  $F^{\bullet}(a)$  on the vanishing cohomology H(a) is conveniently described using the geometric sections as follows. Recall that the Hodge filtration  $F^{\bullet}(a)$  on H(a) is defined individually on each  $H_{\lambda}(a) \cong C_{\alpha}(a)$ . Let

<span id="page-7-0"></span>
$$\beta = n - p + \alpha \,, \tag{2.12}$$

where p is the degree in Hodge filtration and  $\alpha \in (-1,0]$ . Then the space  $F^pH_\lambda(a) \cong F^pC_\alpha(a)$  is generated by the classes  $\zeta[\mathbf{z^m}\Omega]$  obtained from the leading parts of the geometric sections  $s[\mathbf{z^m}\Omega]$  whose  $\beta(\mathbf{m})$  value satisfy (2.12). Due to the quasi-homogeneity, the leading part  $\zeta[\mathbf{z^m}\Omega] \in F^pH_\lambda(a)$  of the geometric section  $s[\mathbf{z^m}\Omega]$  is essentially the geometric section  $s[\mathbf{z^m}\Omega]$  itself. See (A.21) in Appendix A for more detailed explanations.

One then has a decomposition for  $\operatorname{gr}_F^{\bullet}H_{\lambda}(a)$  (recall  $\lambda=e^{-2\pi i\beta}, n+\alpha-\beta=p$ )

<span id="page-7-1"></span>
$$H_{\lambda,\beta}(a) := \operatorname{gr}_F^{n+\alpha-\beta} H_{\lambda}(a) \cong \operatorname{gr}_F^{n+\alpha-\beta} C_{\alpha}(a) , \quad \operatorname{gr}_F^{\bullet} H_{\lambda}(a) = \bigoplus_{\beta : e^{-2\pi i \beta} = \lambda} H_{\lambda,\beta}(a) , \qquad (2.13)$$

where elements in  $H_{\lambda,\beta}(a)$  are given by the classes  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  with  $\beta = \beta(\mathbf{m})$ . For a quasi-homogeneous singularity, the spectrum  $\beta$  together with the dimensions  $n_{\beta} := \dim H_{\lambda,\beta}$  can be easily worked out following the methods in [Kul98].

The structures of the eigenspace decomposition (2.4) and the associated graded of the Hodge filtration (2.13) lead to the notion of twisted sectors.

**Definition 2.2.** For a quasi-homogeneous singularity  $f_a$ , set  $\beta = n - p + \alpha$  with  $\alpha \in (-1,0]$  as in (2.12). An element in  $H_{\lambda,\beta}(a)$  is called a twisted sector.<sup>5</sup> It is called a

- relevant sector, if  $0 \le \beta < 1$ .
- marginal sector, if  $\beta = 1$ .
- irrelevant sector, if  $\beta > 1$ .

<span id="page-7-2"></span><sup>&</sup>lt;sup>5</sup>In the physics literature, usually only sectors with  $\lambda \neq 1$  are called twisted sectors.

The subspace of sectors with  $\lambda = 1$ , that is  $\operatorname{gr}_F^{\bullet}H_1(a)$ , is mapped to the space  $H_{\operatorname{prim}}^{n-1}(Q_a)$  under the Poincaré residue map (2.8) and hence is called the Calabi-Yau sector. In particular, the one with  $\beta = 0$ , which spans  $F^nH_1(a)$ , is mapped to  $F^{n-1}H_{\operatorname{prim}}^{n-1}(Q_a)$  that is the space of Calabi-Yau forms on  $Q_a$ .

As explained above, the classes  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  arising from the leading parts of the geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  provide a basis for the space  $\bigoplus_{\lambda} \operatorname{gr}_F^{\bullet} H_{\lambda}(a)$ . The data  $\mathbf{m}$  itself actually arises from a group action on the ambient space  $\mathbb{C}^{n+1}$  as follows. Introduce the action of  $G = (\mathbb{Z}/(n+1)\mathbb{Z})^{n+1}$  on the coordinate ring  $\mathbb{C}[z_0, z_1, \cdots, z_n]$ 

$$g = (k_0, k_1, \dots, k_n) \in G : (z_0, z_1, \dots, z_n) \mapsto (\xi_{n+1}^{k_0} z_0, \xi_{n+1}^{k_1} z_1, \dots, \xi_{n+1}^{k_n} z_n), \qquad (2.14)$$

with  $\xi_{n+1} := \exp(2\pi i/(n+1))$ . Then the eigenspaces of the *G*-action are exactly given by the monomials  $\mathbf{z}^{\mathbf{m}}$ . It follows that the space  $H_{\lambda,\beta}(a)$  of twisted sectors can be further decomposed into the corresponding *G*-eigenspaces

$$H_{\lambda,\beta}(a) = \bigoplus_{\mathbf{m}:\beta(\mathbf{m})=\beta} H_{\lambda,\beta,\mathbf{m}}(a), \quad \operatorname{gr}_F^{\bullet} H_{\lambda}(a) = \bigoplus_{\beta} \bigoplus_{\mathbf{m}:\beta(\mathbf{m})=\lambda} H_{\lambda,\beta,\mathbf{m}}(a) = \bigoplus_{\mathbf{m}} H_{\lambda,\beta,\mathbf{m}}(a). \tag{2.15}$$

All of the above constructions for  $f_a: X(a) = \mathbb{C}^{n+1} \to \mathbb{C}$  glue to constructions for

$$\varphi = (F, q): X = \mathbb{C}^{n+1} \times S \to \mathbb{C} \times S$$
,

where F is the deformation in (2.1) and  $q: X \to S$  is the projection. In particular, the vanishing cohomology bundle is a local system over S. See [Kul98] and references therein for details. We use the same notation without the '(a)' part to denote the latter, whose restrictions at  $a \in S$  recover the former.

# <span id="page-8-0"></span>2.2 Ordinary differential equations for geometric sections

From now on, we concentrate on the Dwork family (1.2) in the setting of (2.1). The basis in (2.10) is now given by

$$\mathbf{z}^{\mathbf{m}}\Omega$$
,  $\Omega := \bigwedge_{i=0}^{n} dz_{i}$ ,  $0 \le m_{i} \le n-1$ . (2.16)

Our goal is to study differential equations satisfied by the section  $\zeta[\mathbf{z^m}\Omega]$  of the bundle  $H_{\lambda,\beta(\mathbf{m})} \to S$  of twisted sectors. Due to the constancy (2.11) under the  $t\partial_t$ -structure of the geometric sections  $s[\mathbf{z^m}\Omega]$ , this is equivalent to studying the a,  $\partial_a$  actions on the latter—which is easier using the tool of differential forms. For this reason, hereafter we shall not distinguish  $[\mathbf{z^m}\Omega]$  from the geometric section  $s[\mathbf{z^m}\Omega]$  notationally, and properties on them will be transferred to those on the vanishing cohomology classes  $\zeta[\mathbf{z^m}\Omega]$  without explicitly mentioning. For example, the following relation obtained from direct computations [Kul98]

$$\partial_a s[\mathbf{z}^{\mathbf{m}}\Omega] = -\partial_t s[\partial_a F \cdot \mathbf{z}^{\mathbf{m}}\Omega] \tag{2.17}$$

gets translated into a relation<sup>6</sup> on the corresponding leading parts  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  in vanishing cohomology

<span id="page-8-2"></span>
$$\partial_a \zeta[\mathbf{z}^{\mathbf{m}}\Omega] = -\zeta[\partial_a F \cdot \mathbf{z}^{\mathbf{m}}\Omega]. \tag{2.18}$$

For simplicity we have decided to restrict ourselves to the case  $e_1(z) = \prod_{i=0}^n z_i$  in the setting of (2.1). Discussions for the more general cases are similar.

Direct computations following the methods in [Kul98] give the following result.

<span id="page-8-1"></span><sup>&</sup>lt;sup>6</sup>Note the  $\partial_t^{n-p}$  operator part in the definition of  $F^pC_\alpha$  in (A.17) of Appendix A.

<span id="page-9-3"></span>**Lemma 2.3.** Consider the Fermat polynomial  $f = \sum_{i=0}^{n} z_i^{n+1}$ . Along the deformation  $e_1(z) = \prod_{i=0}^{n} z_i$  in (2.2), one has

$$S = \mathbb{C} - \{a^{n+1} - (n+1)^{n+1} = 0\}. \tag{2.19}$$

The geometric section  $s[\boldsymbol{z^m}\Omega] \in \mathcal{H}^{(0)}$  satisfies the differential equation

<span id="page-9-2"></span>
$$\left(\prod_{i=0}^{n} (\theta_a + i - n) - \frac{a^{n+1}}{(n+1)^{n+1}} \prod_{i=0}^{n} (\theta_a + m_i + 1)\right) s[\mathbf{z}^{\mathbf{m}}\Omega] = 0, \quad \theta_a := a \frac{\partial}{\partial a}.$$
 (2.20)

This differential equation can be possibly reduced to a lower order equation obtained by factoring out one with highest possible order from the left, therefore with reduced order

<span id="page-9-5"></span>
$$n+1-\text{cardinality}(\{m_i+1\}_{i=0}^n).$$
 (2.21)

In particular, the differential equation is independent of the  $\mathfrak{S}_{n+1}$  permutations on **m**.

*Proof.* The first assertion about the discriminant locus follows from a direct computation of the possible singularity locus of  $f_a$  by using the Jacobian criterion. In particular, the Milnor number is  $\mu = \dim \operatorname{Jac}(f) = n^{n+1}$ . The assertion regarding the differential operators follow from straightforward but tedious computations following the methods in [Kul98].

To reduce the number of singularities of the differential equations, we introduce a more convenient coordinate

<span id="page-9-4"></span>
$$b = \frac{a^{n+1}}{(n+1)^{n+1}} \in \mathcal{M} = \mathbb{C} - \{0,1\}.$$
 (2.22)

As we shall see later, this change of coordinate will be reflected in the orbifold structure that one puts on  $\mathcal{M}$ . Similar to Meijer's G-function [EMOT81], we introduce the series

$$_{r}G_{s}(\alpha_{1},\cdots,\alpha_{r};\beta_{1},\cdots,\beta_{s};z)=\sum_{k=0}^{\infty}\frac{\prod_{i=1}^{r}(\alpha_{i})_{k}}{\prod_{i=1}^{s}(\beta_{j})_{k}}z^{k},\quad (\alpha)_{k}=\frac{\Gamma(\alpha+k)}{\Gamma(\alpha)}.$$

Besides the obvious relation

$$_{r}G_{s}(\alpha,\cdots;\alpha,\cdots;z)={}_{r-1}G_{s-1}(\cdots;\cdots;z)$$

this series satisfies the differential equation

<span id="page-9-0"></span>
$$\left(\prod_{j=1}^{s}(\theta_z+\beta_j-1)-z\prod_{i=1}^{r}(\theta_z+\alpha_i)\right){}_{r}G_{s}(\alpha_1,\cdots,\alpha_r;\beta_1,\cdots,\beta_s;z)=0\,,\quad \theta_z:=z\frac{\partial}{\partial z}\,. \tag{2.23}$$

We can now see that period integrals of the geometric section  $s[\mathbf{z}^{\mathbf{m}}\Omega]$ , obtained by integrating it on locally constant homology classes in the homological Milnor fibration (see (A.21) in Appendix A), can be expressed in terms of the above  ${}_rG_s$  functions.

**Corollary 2.4.** Consider the Dwork family of polynomial singularities (1.2). Period integrals of the geometric section  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  are  $\mathbb{C}$ -linear combinations of

<span id="page-9-1"></span>
$$a^{\delta} \cdot {}_{n+1}G_{n+1}(\frac{\delta+m_0+1}{n+1}, \cdots, \frac{\delta+m_n+1}{n+1}; \frac{\delta+1}{n+1}, \cdots, \frac{\delta+n+1}{n+1}; b),$$
 (2.24)

where  $\delta \in \{0, 1, \dots, n\}$  is such that  $\delta + m_i + 1 \neq 0 \in \mathbb{Z}/(n+1)\mathbb{Z}$ ,  $\forall i = 0, 1, \dots, n$ .

*Proof.* From (2.23) we see that functions in (2.24) satisfy the differential equations (2.20) in Lemma 2.3. From their asymptotic behaviors near a = 0, we see that these solutions are linearly independent. Hence this set of solutions span a vector space of dimension

cardinality 
$$(\{\delta \mid \delta + m_i + 1 \neq 0 \in \mathbb{Z}/(n+1)\mathbb{Z}, \forall i = 0, 1, \dots, n\})$$
.

This is exactly the order of the differential equation with reduced order given in Lemma 2.3. The desired claim then follows.  $\Box$ 

#### <span id="page-10-3"></span>2.2.1 Real structure and oscillating integrals

Recall that for the cohomology of the twisted de Rham complex  $(\Omega_{X(a)}^{\bullet}, d - df_a \wedge)$  one has

$$\mathbb{H}^{n+1}(\Omega_{X(a)}^{\bullet}, d - df_a \wedge) \cong H^{n+1}(\Gamma(X(a), \Omega_{X(a)}^{\bullet}), d - df_a \wedge).$$

The real structure of the latter is compatible with the one on the homology group of Lefschetz thimbles via a comparison theorem, which in the present case is provided by the oscillating integrals<sup>7</sup>

$$\langle \mathbf{z}^{\mathbf{m}}\Omega, \gamma \rangle := \int_{\gamma} e^{-f_a} \mathbf{z}^{\mathbf{m}}\Omega, \quad \gamma \in H_{n+1}(\mathbb{C}^{n+1}, (\operatorname{Re} f_a)^{-1}(+\infty); \mathbb{Z}).$$

It turns out that the pairing  $\langle -, - \rangle$  defined above gives a perfect pairing. See [Mal74, Pha85, AGZV88] for details, see also [Gro11] for a nice exposition. On the other hand, from the exact sequence for singular homology and cohomology groups with complex coefficients, we have

<span id="page-10-1"></span>
$$H^{n}(X(a)_{\infty}) \cong (H_{n}(X(a)_{\infty}))^{*}$$

$$\cong (H_{n+1}(\mathbb{C}^{n+1}, (\operatorname{Re} f_{a})^{-1}(+\infty); \mathbb{C}))^{*}$$

$$\cong H^{n+1}(\Gamma(X(a), \Omega_{X(a)}^{\bullet}), d - df_{a} \wedge). \tag{2.25}$$

Hence the real structure on the vanishing cohomology  $H^n(X(a)_\infty)$  is compatible with that on the twisted cohomology group. Explicitly, the isomorphism (2.25) maps the class  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega](a) \in F^pH_\lambda(a)$ , arising from the leading part of the geometric section  $s[\mathbf{z}^{\mathbf{m}}\Omega](a) \in \Gamma(X(a),\mathcal{H}^{(0)})$ , to the class  $[\mathbf{z}^{\mathbf{m}}\Omega]$  of  $\mathbf{z}^{\mathbf{m}}\Omega \in \Gamma(X(a),\Omega_{X(a)}^{n+1})$ .

The homology group  $H_{n+1}(\mathbb{C}^{n+1}, (\operatorname{Re} f_a)^{-1}(+\infty); \mathbb{Z})$  has rank  $n^{n+1}$  and is generated by cycle classes of the form

$$\gamma = \gamma_0 \times \cdots \times \gamma_n$$
,  $\gamma_i \in H_1(\mathbb{C}, \operatorname{Re} z_i = +\infty; \mathbb{Z})$ ,  $i = 0, 1, \dots, n$ .

Here

- $c_i$  is the chain connecting  $z_i = 0$  and  $z_i = +\infty$  along the real axis in  $\mathbb{C}$ , and  $\xi_{n+1}c_i$  the one obtained from the action of  $\xi_{n+1} \in \mathbb{C}^*$  on  $c_i$ , with  $\xi_{n+1} = e^{\frac{2\pi i}{n+1}}$ .
- Each  $H_1(\mathbb{C}, \operatorname{Re} z_i = +\infty; \mathbb{Z})$  has rank n and is generated by  $c_i \zeta_{n+1}^{h_i} c_i$  with  $h_i \in \{1, \dots, n\}$ .

Therefore,  $H_{n+1}(\mathbb{C}^{n+1}, (\operatorname{Re} f_a)^{-1}(+\infty); \mathbb{Z})$  is generated by

$$\gamma_{\mathbf{h}} = \prod_{i=0}^{n} (1 - \xi_{n+1}^{h_i}) c_i, \quad \mathbf{h} = (h_0, \dots, h_n) \in \{1, 2, \dots, n\}^{\oplus (n+1)}.$$

The corresponding period integral can then be evaluated directly to be

<span id="page-10-2"></span>
$$\langle \mathbf{z}^{\mathbf{m}}\Omega, \gamma_{\mathbf{h}} \rangle = \int_{\gamma_{\mathbf{h}}} e^{-f_a} \mathbf{z}^{\mathbf{m}} \Omega = \sum_{d > 0} \prod_{i=0}^{n} (1 - \xi_{n+1}^{h_i(d+m_i+1)}) \Gamma(\frac{d+m_i+1}{n+1}) \frac{a^d}{d!}.$$
 (2.26)

Let

$$d=(n+1)\ell+\delta$$
,  $\ell\in\mathbb{N}$ ,  $\delta\in\{0,1,\cdots,n\}$ .

<span id="page-10-0"></span><sup>&</sup>lt;sup>7</sup>The association of oscillating integrals is not canonical. For example, one could have taken the differential to be  $d-\frac{1}{\hbar}df_a\wedge$  and correspondingly considered the oscillating integrals of  $e^{-\frac{1}{\hbar}f_a}\mathbf{z^m}\Omega$ , with  $\hbar\in\mathbb{R}_{>0}$ . This would also change the isomorphism (2.25) below.

In order for the above period integral (2.26) to be nonzero, one must have

$$\delta + m_i + 1 \neq 0 \in \mathbb{Z}/(n+1)\mathbb{Z}$$
,  $\forall i = 0, 1, \dots, n$ .

The resulting expression of (2.26) is then

<span id="page-11-3"></span>
$$\sum_{\delta} \prod_{i=0}^{n} (1 - \zeta_{n+1}^{h_i(\delta + m_i + 1)}) \cdot a^{\delta} \sum_{\ell > 0} \prod_{i=0}^{n} \Gamma(\ell + \frac{\delta + m_i + 1}{n+1}) \frac{a^{(n+1)\ell}}{((n+1)\ell + \delta)!}.$$
 (2.27)

Using the Gauss multiplication formula for Gamma functions, we see that

<span id="page-11-4"></span>
$$\prod_{i=0}^{n} \left(1 - \xi_{n+1}^{h_i(\delta + m_i + 1)}\right) \cdot a^{\delta} \sum_{\ell \ge 0} \prod_{i=0}^{n} \Gamma(\ell + \frac{\delta + m_i + 1}{n+1}) \frac{a^{(n+1)\ell}}{((n+1)\ell + \delta)!}$$
(2.28)

$$= \prod_{i=0}^{n} (1 - \xi_{n+1}^{h_i(\delta + m_i + 1)}) \cdot (2\pi)^{\frac{n}{2}} (n+1)^{-\frac{1}{2} - \delta} \frac{\prod_{i=0}^{n} \Gamma(\frac{\delta + m_i + 1}{n+1})}{\prod_{i=0}^{n} \Gamma(\frac{\delta + i + 1}{n+1})} \cdot \text{expression in (2.24)}.$$

We have therefore identified the real (and even integral) structure on H(a) through computing oscillating integrals (2.26). See Section 2.4 for examples.

### <span id="page-11-0"></span>2.3 Automorphic bundles corresponding to D-modules

For any m, denote

$$\mathbf{m} + \ell \mathbf{1} := (m_0 + \ell, m_1 + \ell, \cdots, m_n + \ell), \quad \ell \in \mathbb{N}.$$

According to Lemma 2.3 in Section 2.2, for each  $\mathbf{m}$  the vanishing cohomology classes  $\{\zeta[\mathbf{z}^{\mathbf{m}+\ell\mathbf{1}}\Omega]\}_{\ell\in\mathbb{N}}$  span a regular holonomic  $D_S$ -module governed by the relation (2.18). We denote the corresponding flat vector bundle over S by  $D_{\mathbf{m}}$ . In particular, the relation (2.18) provides an isomorphism

$$D_{\mathbf{m}} \cong D_{\mathbf{m}+1}. \tag{2.29}$$

To be more concrete, denote the reduced differential operator in Lemma 2.3 by  $\mathcal{D}_m$ , then

<span id="page-11-2"></span>
$$\mathcal{D}_{\mathbf{m}+\mathbf{1}} \circ \partial_a = \frac{1}{a} (\theta_a - n - 1) \circ \mathcal{D}_{\mathbf{m}}. \tag{2.30}$$

The Hodge filtration on  $H_{\lambda}$  induces a filtration on  $D_{\mathbf{m}}$  which we still denote by  $F^{\bullet}$ , with the grading of the filtration conveniently recorded in the value  $\beta(\mathbf{m})$  according to (2.12). As explained at the beginning of Section 2.2, we can and shall regard  $D_{\mathbf{m}}$  as a  $D_S$ -module spanned by the geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$ , as long as only the  $D_S$ -module structure on the vanishing cohomology classes  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  is concerned.

The D-module  $D_{\mathbf{m}}$  descends to  $\mathcal{M} = \mathbb{P}^1 - \{0,1,\infty\}$  along the map  $S \to \mathcal{M}$  given in (2.22). Computationally, the resulting differential operator is obtained by substituting  $\theta_a = (n+1)\theta_b$  in (2.20) in Lemma 2.3

<span id="page-11-1"></span>
$$\left(\prod_{i=0}^{n} (\theta_b + \frac{i-n}{n+1}) - b \prod_{i=0}^{n} (\theta_b + \frac{m_i+1}{n+1})\right) s[\mathbf{z}^{\mathbf{m}}\Omega] = 0, \quad \theta_b := b \frac{\partial}{\partial b}.$$
 (2.31)

We now prove a main result Theorem 2.5 in our work. To proceed, we first recall some notation on orbifold lines. Consider the orbifold

$$T_{\ell_0,\ell_1,\ell_\infty} := \Gamma_{\ell_0,\ell_1,\ell_\infty} \backslash \mathcal{H} \,, \tag{2.32}$$

where  $\mathcal{H}$  is the upper-half plane, and  $\Gamma_{\ell_0,\ell_1,\ell_\infty} < PSL_2(\mathbb{R})$  is the triangular group that admits the following presentations

<span id="page-12-2"></span>
$$\Gamma_{\ell_0,\ell_1,\ell_\infty} = \langle \sigma_0, \sigma_1, \sigma_\infty \rangle / \langle \sigma_0^{\ell_0} = \sigma_1^{\ell_1} = \sigma_\infty^{\ell_\infty} = \sigma_\infty \sigma_1 \sigma_0 = 1 \rangle$$

$$\cong \langle \sigma_0, \sigma_1 \rangle / \langle \sigma_0^{\ell_0} = \sigma_1^{\ell_1} = (\sigma_1 \sigma_0)^{\ell_\infty} = 1 \rangle. \tag{2.33}$$

Here we have used the convention that  $\sigma^{\ell} = 1$  if  $\ell = \infty$ . By tautology one has

$$\pi_1^{\text{orb}}(T_{\ell_0,\ell_1,\ell_\infty}) = \Gamma_{\ell_0,\ell_1,\ell_\infty}.$$
(2.34)

We then have the following result.

<span id="page-12-0"></span>**Theorem 2.5.** Consider the Dwork family of polynomial singularities (1.2), together with the map  $S \to \mathcal{M}$  given in (2.22). For each  $\mathbf{m}$ , there exists a triple  $\ell(\mathbf{m}) = (\ell_0(\mathbf{m}) = n+1, \ell_1(\mathbf{m}), \ell_\infty(\mathbf{m}))$  such that the corresponding flat bundle  $D_{\mathbf{m}}$  over  $\mathcal{M}$  is an automorphic bundle and thus the geometric section  $\mathbf{s}[\mathbf{z}^{\mathbf{m}}\Omega]$  is the component of an automorphic form, for the triangular group  $\Gamma_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})} < \mathrm{PSL}_2(\mathbb{R})$ . In particular, all of the geometric sections are components of automorphic forms for  $\Gamma_{n+1,\infty,\infty}$ .

*Proof.* Let  $\ell_0(\mathbf{m})$ ,  $\ell_1(\mathbf{m})$ ,  $\ell_\infty(\mathbf{m})$  be the orders of the local monodromies of  $D_{\mathbf{m}}$  respectively. It follows that under the Riemann-Hilbert correspondence,  $D_{\mathbf{m}}$  corresponds to a monodromy representation of  $\Gamma_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})}$ . Consider the indicial roots at the singular point b=0 of (2.31). It is direct to check that they are all different, and thus the indicial differences at b=0 are multiples of 1/(n+1). This tells that  $\ell_0(\mathbf{m})$  is a factor of (n+1). By Definition 1.1, the bundle  $D_{\mathbf{m}}$  is an automorphic bundle for the triangular group  $\Gamma_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})}$  and the section  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  is a component of an automorphic form for this group. The last assertion follows from the fact that any representation of  $\Gamma_{\ell_0,\ell_1,\ell_\infty}$  with  $\ell_0 \mid (n+1)$  is a representation of  $\Gamma_{n+1,\infty,\infty}$  that is induced by a quotient homomorphism  $\Gamma_{n+1,\infty,\infty} \to \Gamma_{\ell_0,\ell_1,\ell_\infty}$ .

For each  $\mathbf{m}$ , let  $\overline{\mathcal{M}}_{\mathbf{m}}$  be the orbifold obtained from  $\mathcal{M}$  by filling in the elliptic points (i.e., those with finite-order monodromies). As a consequence of Theorem 2.5, the Riemann-Hilbert correspondence provides  $\overline{\mathcal{M}}_{\mathbf{m}}$  with the orbifold structure  $T_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})}$  with structure map  $\mathcal{H} \to T_{\ell_0(\mathbf{m}),\ell_1(\mathbf{m}),\ell_\infty(\mathbf{m})}$ . The possible multi-valuedness of  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  reflects the fact that it is a section of an orbi-bundle over this orbifold. In the following, to ease the notation we use the same notation  $\mathcal{M}$  for  $\overline{\mathcal{M}}_{\mathbf{m}}$  which should cause no confusion from the surrounding context.

We remark that regarding a representation of  $\Gamma_{\ell_0,\ell_1,\ell_\infty}$  as one for  $\Gamma_{n+1,\infty,\infty}$  can lose significant information of the origin one. Even worse, the classification of representations for  $\Gamma_{n+1,\infty,\infty}$  and explicitly computing analytic expressions for the corresponding automorphic forms can already be nontrivial.

The bundle  $D_{\mathbf{m}}$  comes with a filtration  $F^{\bullet}D_{\mathbf{m}}$  induced from the Hodge filtration on vanishing cohomology. These bundles naturally extend to locally free sheaves over the compactified orbifold  $\overline{T}_{\ell(\mathbf{m})}$  by Schmid's results [Sch73] on limiting Hodge filtrations. We denote the extended bundles by  $\{F^p\overline{D}_{\mathbf{m}}\}_p$ . In particular, the bundle  $\overline{D}_{\mathbf{m}}$  coincides with Deligne's canonical extension in the context of ordinary differential equations with regular singularities. To be more precise, the extension data<sup>8</sup> is given by logarithms of the local monodromies called exponents L such that the real parts of eigenvalues of L lie in [0,1). See [SS14, CF17, CF19] for detailed discussions on extensions.

Once the representations are obtained, then by definition sections of  $\overline{D}_{\mathbf{m}}$ , and in particular those of the sub-bundles  $F^p\overline{D}_{\mathbf{m}}$ , are automorphic forms with boundary conditions imposed at the elliptic points and cusps.

<span id="page-12-1"></span><sup>&</sup>lt;sup>8</sup>Note that in Deligne's canonical extension one uses the convention  $\lambda = e^{-2\pi i \alpha}$  for the eigenvalue of T, while for the exponent L one uses  $T = e^{2\pi i L}$ .

**Remark 2.6.** Note that the Picard group and canonical bundle for both the orbifold and its compactification are uniquely determined by the data of signature and admit very concrete descriptions. For example, consider the compact orbifold line  $C = \overline{T}_{k_0,k_1,k_2}$ , denote by p a generic point on C. Then the Picard group has the presentation

$$\operatorname{Pic}(C) = \langle \mathcal{O}_C(p_i), i = 0, 1, 2 \mid \mathcal{O}_C(p_i)^{\otimes k_i} \cong \mathcal{O}_C(p), i = 0, 1, 2 \rangle.$$

The canonical sheaf, which is isomorphic to the relative dualizing sheaf, is given by

$$\Omega_{C}^{1} = \mathcal{O}_{C}((3-1)p - \sum_{i=0}^{2} p_{i}).$$

Consider as a special case the orbifold  $T_{\ell_0,\ell_1,\ell_\infty} = \Gamma_{\ell_0,\ell_1,\ell_\infty} \setminus \mathcal{H}$  corresponding to the triangular group  $\Gamma_{\ell_0,\ell_1,\ell_\infty}$  arising from Theorem 2.5. The sheaf  $\Omega^1_{T_{\ell_0,\ell_1,\ell_\infty}}$  is not necessarily flat, yet it is an automorphic bundle whose automorphy factor can be easily worked out using the Schwarzian uniformization. This canonical sheaf enters through the connection on the flat vector bundles  $D_{\mathbf{m}}$ 

$$\nabla: D_{\mathbf{m}} \to D_{\mathbf{m}} \otimes \Omega^1_{T_{\ell_0,\ell_1,\ell_\infty}}$$
.

The flatness of  $\nabla$ , which is equivalent to the D-module structure of  $D_{\mathbf{m}}$ , yields a differential structure of automorphic sections of  $D_{\mathbf{m}}$ . The transcendental degree of the differential field is then determined by the dimension of the differential Galois group which is closely related to the monodromy group [BH89]. See Section 2.4.3 for related discussions. The connection  $\nabla$  extends to a meromorphic connection with only logarithmic pole on the extended bundle  $\overline{D}_{\mathbf{m}}$ 

$$\overline{\nabla}:\overline{D}_{\mathbf{m}} o \overline{D}_{\mathbf{m}} \otimes \Omega^1_{\overline{T}_{\ell(\mathbf{m})}}(\log \sum_{p_i} p_i)$$
 ,

where the summation in the logarithmic canonical sheaf is over the loci of cusps.

#### <span id="page-13-0"></span>2.4 Examples

In this section we discuss the details for the n=2,3 cases. We shall work out the automorphy factors for the top pieces  $F^{\rm top}D_{\rm m}$  using the Schwarzian uniformization. This shows that their corresponding sections are automorphic forms with weights given by rank  $D_{\rm m}-1$ . For the  $D_0$  sector, we shall show that these automorphic forms actually reduce to elliptic modular forms. We shall also discuss the n=4 case briefly and mention some interesting results that have shown to be important in the studies of higher genus mirror symmetry for quintic threefolds.

#### 2.4.1 Fermat cubic

<span id="page-13-1"></span>Consider the n = 2 case. The spectrum that encodes the information of the weight filtration and Hodge filtration is given by Table 1 below. As vector spaces one has

**Table 1:** Spectrum of the cubic polynomial singularity  $f_a$ .

| β           | 0 | <u>1</u><br>3 | <u>2</u><br>3 | 1 |
|-------------|---|---------------|---------------|---|
| $n_{\beta}$ | 1 | 3             | 3             | 1 |

$$\begin{array}{lcl} \operatorname{gr}_3^W H(a) & = & H_1(a) = \operatorname{gr}_F^2 H_1(a) \oplus \operatorname{gr}_F^1 H_1(a) \,, \\ \operatorname{gr}_2^W H(a) & = & W_2 H(a) = H_{e^{-\frac{4\pi i}{3}}}(a) \oplus H_{e^{-\frac{2\pi i}{3}}}(a) = \operatorname{gr}_F^1 H_{e^{-\frac{4\pi i}{3}}}(a) \oplus \operatorname{gr}_F^1 H_{e^{-\frac{2\pi i}{3}}}(a) \,. \end{array}$$

The pure Hodge structure on  $gr_3^W H(a)$  is mapped to that on  $H^1(Q_a)$  under the Poincaré residue map (2.8).

*D*-modules for geometric sections Differential equations satisfied by various sectors are given in Lemma 2.3. The results are displayed in Table 2. In particular, the differential operator with  $\mathbf{m} = (1,1,1)$  follows from the one with  $\mathbf{m} = (0,0,0)$  according to (2.30).

<span id="page-14-0"></span>**Table 2:** Differential equations satisfied by the geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$ , and orbifold structures on  $\mathcal{M}$  provided by the corresponding D-modules under the Riemann-Hilbert correspondence.

| m         | differential operator                                 | orbifold structure    |  |  |
|-----------|-------------------------------------------------------|-----------------------|--|--|
| (0,0,0)   | 3                                                     | $T_{3,\infty,\infty}$ |  |  |
| (1,0,0)   | $\theta_a - \frac{a^3}{3^3}(\theta_a + 1)$            | $T_{1,3,3}$           |  |  |
| (1, 1, 0) | $\theta_a - \frac{a^3}{3^3}(\theta_a + 2)$            | $T_{1,3,3}$           |  |  |
| (1,1,1)   | $(\theta_a-2)\theta_a-\tfrac{a^3}{3^3}(\theta_a+2)^2$ | $T_{3,\infty,\infty}$ |  |  |

The  $\mathbf{m} = (0, 0, 0)$  sector. The differential operator is

<span id="page-14-2"></span>
$$\mathcal{D}_{\text{cubic}} := \theta_b(\theta_b - \frac{1}{3}) - b(\theta_b + \frac{1}{3})(\theta_b + \frac{1}{3}), \quad b = \frac{a^3}{3^3}. \tag{2.35}$$

By dimension reasons we have<sup>9</sup>

$$D_0 \cong C_0 = H_1 \cong \operatorname{gr}_W^3 H.$$

The period map is then

$$\mathcal{M} = \mathbb{C} - \{0,1\} \to Gr(1, gr_3^W H(b_*)), \quad b \mapsto F^3 gr_3^W H(b),$$
 (2.36)

where  $b_*$  is a reference point on  $\mathcal{M}$ . The monodromy group can be computed following [EMOT81] or [BH89]. To be explicit, a basis of solution is given by

$$u_3 = {}_2F_1(\frac{1}{3}, \frac{1}{3}; \frac{3}{3}; b), \quad u_4 = b^{\frac{1}{3}} {}_2F_1(\frac{2}{3}, \frac{2}{3}; \frac{4}{3}; b).$$

Then up to conjugacy, the monodromies around  $b = 0, 1, \infty$  are given by the following matrices in  $SL_2(\mathbb{R}) \times U_1(\mathbb{R})$ 

<span id="page-14-3"></span>
$$T_0 = \xi_3^{-1} \otimes \begin{pmatrix} -2 & -1 \\ 3 & 1 \end{pmatrix}, \quad T_1 = \begin{pmatrix} 1 & 0 \\ -3 & 1 \end{pmatrix}, \quad T_\infty = \xi_3 \otimes \begin{pmatrix} 1 & 1 \\ 0 & 1 \end{pmatrix}, \quad T_0 T_1 T_\infty = 1.$$
 (2.37)

The Schwarzian uniformization using solutions to (2.35) then provides the base  $\mathcal{M}$  with the orbifold structure  $T_{3,\infty,\infty} = \Gamma_{3,\infty,\infty} \setminus \mathcal{H}$ . Furthermore, the sub-bundle  $F^1D_0$  is the automorphic bundle with a j-automorphy factor (1.6)

<span id="page-14-4"></span>
$$j: \Gamma_{3,\infty,\infty} \times \mathcal{H} \to \mathrm{GL}_1(\mathbb{C}), \quad \left( \begin{pmatrix} a & b \\ c & d \end{pmatrix}, \tau \right) \mapsto (c\tau + d)^{-1}.$$
 (2.38)

<span id="page-14-1"></span><sup>&</sup>lt;sup>9</sup>Hereafter we shall often identify the flat bundle  $D_{\mathbf{m}}$  on  $\mathcal{M}$  with the corresponding local system and H with  $\operatorname{gr}_{\bullet}^{W}H$ , without explicit mentioning.

The bundle  $D_0 = C_0 = \operatorname{gr}_3^W H$  can be extended to a locally free sheaf  $(\operatorname{gr}_3^W \overline{H}, \overline{\nabla})$  equipped with meromorphic connection on the compactification  $\overline{T}_{3,\infty,\infty}$  of  $\mathcal{M}$ . Deligne's canonical extension gives rise to a connection with only logarithmic pole

$$\overline{
abla}: \operatorname{gr}_3^W \overline{H} o \operatorname{gr}_3^W \overline{H} \otimes \Omega^1_{\overline{T}_{3\infty\infty}}(\log(p_1+p_\infty))$$
 ,

where  $p_0, p_1, p_\infty$  stands for the divisor represented by  $b = 0, 1, \infty$  on the coarse moduli of  $\overline{T}_{3,\infty,\infty}$ , respectively. To be explicit, up to conjugation the corresponding exponent matrices are given by

$$L_0 = \begin{pmatrix} 0 & 0 \\ 0 & \frac{1}{3} \end{pmatrix}$$
 ,  $L_1 = \begin{pmatrix} 0 & 1 \\ 0 & 0 \end{pmatrix}$  ,  $L_{\infty} = \begin{pmatrix} \frac{1}{3} & 1 \\ 0 & \frac{1}{3} \end{pmatrix}$  .

Concretely, this canonical extension is obtained by choosing suitable local solutions as the trivialization. See [SS14, CF17, CF19] for details.

The  $\mathbf{m}=(1,0,0)$  sector. By the  $\mathfrak{S}_3$ -symmetry in Lemma 2.3, among the 3 sectors in  $H_{\lambda,\beta}$ ,  $\lambda=\exp(-\frac{4\pi i}{3})$ ,  $\beta=1/3$ , we only need to consider  $\mathbf{m}=(1,0,0)$ . For this sector (and any of its permutations), the differential operator is

$$\theta_b - b(\theta_b + \frac{1}{3})$$
.

The solution space is spanned by the multi-valued function  $(1-b)^{-\frac{1}{3}}$  on  $\mathcal{M}$ . Under the Riemann-Hilbert correspondence, the differential equation gives a local system

$$D_{\mathbf{m}}\cong C_{-\frac{2}{3}}$$
.

This is an orbifold line bundle on the orbifold  $T_{1,3,3}$  with signature 1, 3, 3 at  $b = 0, 1, \infty$  respectively. The canonical extension defines the following orbifold line bundle on

$$\overline{D}_{\mathbf{m}} \cong \mathcal{O}_{T_{1,3,3}}(p_1) \otimes \mathcal{O}_{T_{1,3,3}}(p_{\infty})^{\otimes -1}$$
.

The  $\mathbf{m} = (1, 1, 0)$  sector. For  $\mathbf{m} = (1, 1, 0)$  and permutations, the differential operator is

$$\theta_b - b(\theta_b + \frac{2}{3})$$
.

The solution space is spanned by  $(1-b)^{-\frac{2}{3}}$ . The same reasonings as in the case  $\mathbf{m}=(1,0,0)$  apply to this case.

**Schwarzian uniformization and elliptic modular forms** For the  $D_0$  sector, applying a twist by  $b^{-\frac{1}{3}}$  to (2.35) leads to the following differential operator

<span id="page-15-0"></span>
$$\mathcal{D}_{\text{elliptic}} := b^{\frac{1}{3}} \circ \mathcal{D}_{\text{cubic}} \circ b^{-\frac{1}{3}} = (\theta_b - \frac{2}{3})(\theta_b - \frac{1}{3}) - b\theta_b^2, \tag{2.39}$$

with unipotent instead of quasi-unipotent monodromies at  $b=1,\infty$ . This differential operator coincides with the familiar Picard-Fuchs operator for the Hesse pencil as it should be the case by the isomorphism of pure Hodge structures provided by the Poincaré residue map (2.8). Unlike the one in (2.37), the monodromy group is now a subgroup of  $SL_2(\mathbb{Z})$ . The canonical extension is determined by the exponent matrices

$$L_0 = \begin{pmatrix} \frac{1}{3} & 0 \\ 0 & \frac{2}{3} \end{pmatrix}$$
 ,  $L_1 = \begin{pmatrix} 0 & 0 \\ -3 & 0 \end{pmatrix}$  ,  $L_\infty = \begin{pmatrix} 0 & 1 \\ 0 & 0 \end{pmatrix}$  .

Using the connection between solutions to (2.39) and modular forms [Mai09], one then identifies the base  ${\cal M}$  with the modular curve

$$\mathcal{M} = \Gamma_0(3) \setminus \mathcal{H}^* - \{0,1,\infty\} \subseteq T_{3,\infty,\infty} \cong \Gamma_0(3) \setminus \mathcal{H} = \Gamma_0(3) \setminus \mathcal{H}^* - \{1,\infty\}, \quad \Gamma_0(3) \cong \Gamma_{3,\infty,\infty}.$$

Note that the twist does not affect the projectivized monodromy group. Under the above identification, the Schwarzian for (2.35) gets identified with the modular parameter  $\tau$  for the elliptic curve family, and the Hauptmodul b is a modular function for the modular group  $\Gamma_0(3)$ .

First order differential equations for the other sectors  $D_{\mathbf{m}}$ ,  $\beta(\mathbf{m}) < 1$ , which have semi-simple monodromies, also correspond to representations of the modular group  $\Gamma_0(3) \cong \Gamma_{3,\infty,\infty}$ . This is also the case for differential equation satisfied by the twist  $b^{-\frac{1}{3}}$  itself, which was used to pass from (2.35) to (2.39) for the  $\mathbf{m} = 0$  sector.

Therefore, when expressed in terms of the Schwarizian for the sector  $D_0$ , all of the twisted sectors are components of (vector-valued) elliptic modular forms for the group  $\Gamma_0(3)$  which arises from the Schwarzian uniformization for the sector  $D_0$ . Similar statement also holds for sections of the extended bundle  $F^0\overline{D}_0$ ,  $F^1\overline{D}_0$ . In fact, the automorphic form  $a=3b^{\frac{1}{3}}$  is an elliptic modular function for the principal congruence subgroup  $\Gamma(3)$ , while those of  $F^1\overline{D}_0 \cong \mathcal{O}_{\overline{T}_{3,\infty,\infty}}(p_0)$  are weight-one modular forms (with multiplier system given by the Dirichlet character  $\chi_{-3}$ ). See [Mai09, Mai11] for details.

<span id="page-16-0"></span>Remark 2.7. One can alternatively regard sections of  $F^0D_0$  as quasi-modular forms. To be more precise, one takes a frame for  $F^1D_0$  from which one sees that the j-automorphy factor is  $(c\tau+d)^{-1}$ , as has been explained in (2.38) by using the Schwarzian uniformization. Then one applies the covariant derivative  $\nabla_{\partial_b}$  to obtain a frame of  $F^0D_0$ . The automorphy factor can then be read off from the resulting frame. Coordinate expressions of sections for  $F^0D_0$  with respect to this frame are then analogues of quasi-modular forms [KZ95], see e.g., [Urb14, RZZ20] for related discussions. The same discussions apply to any rank-2 local system arising from ordinary differential equations with regular singularities.

**Remark 2.8.** While the geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$  are components of automorphic forms, interestingly the coordinate functions  $z_0, z_1, z_2$  themselves can be related to automorphic functions. In fact, the Hesse pencil

$$z_0^3 + z_1^3 + z_2^3 - az_0z_1z_2 = 0$$

can be uniformized [Dol97] by Jacobi theta functions for the modular group  $\Gamma(3)$ . From the moduli point of view, the Hesse pencil is the universal family of elliptic curves equipped with level-3 structure (a frame for the group of 3-torsion points) over the modular curve  $\Gamma(3)\backslash\mathcal{H}$ . The objects  $z_i, i=0,1,2$  are sections of the pushforward of certain theta line bundles of degree 3 over the universal curve, while the Poincaré residue of  $s[\Omega]$  is a section of the Hodge line bundle attached to this elliptic curve family.

**Real structure** The real structure on H in the present case exchanges the two types of summands in  $\operatorname{gr}_2^W H$  with distinct values of  $\beta$ , and also those in  $\operatorname{gr}_3^W H$ . As explained earlier, the real (in fact integral) structure can be identified by making use of the oscillating integrals. The discussions for the  $\operatorname{gr}_3^W H$  piece is identical to those for the Hesse pencil and is therefore omitted here. For the  $\operatorname{gr}_2^W H$  piece, similar to the computations in (2.26), (2.27), (2.28) in Section 2.2.1, we have for  $\mathbf{m} = (1,0,0), (0,1,1)$  and thus their  $\mathfrak{S}_3$ -permutations

$$\int_{\gamma_{\mathbf{h}}} e^{-f_a} \mathbf{z}^{\mathbf{m}} \Omega = \prod_{i=0}^{2} \left(1 - \xi_3^{h_i(m_i+1)}\right) \cdot (2\pi)^{\frac{2}{2}} 3^{-\frac{1}{2}} \frac{\prod_{i=0}^{2} \Gamma\left(\frac{m_i+1}{3}\right)}{\prod_{i=0}^{2} \Gamma\left(\frac{i+1}{3}\right)} \cdot {}_{3}G_{3}\left(\frac{m_0+1}{3}, \frac{m_1+1}{3}, \frac{m_2+1}{3}; \frac{1}{3}, \frac{2}{3}; \frac{3}{3}; b\right).$$

Denote the linear dual of  $\gamma_h$  by  $\check{\gamma}_h$ , we then have

$$\frac{1}{c_{\mathbf{m}}} \cdot [\mathbf{z}^{\mathbf{m}}\Omega] := \frac{(2\pi)^{-1} 3^{\frac{1}{2}} \frac{\prod_{i=0}^{2} \Gamma(\frac{i+1}{3})}{\prod_{i=0}^{2} \Gamma(\frac{m_{i}+1}{3})}}{3G_{3}(\frac{m_{0}+1}{3}, \frac{m_{1}+1}{3}, \frac{m_{2}+1}{3}, \frac{1}{3}, \frac{2}{3}, \frac{3}{3}; b)} \cdot [\mathbf{z}^{\mathbf{m}}\Omega] = \sum_{\mathbf{h} \in \{0,1,2\}^{\oplus 3}} \prod_{i=0}^{2} (1 - \xi_{3}^{h_{i}(m_{i}+1)}) \check{\gamma}_{\mathbf{h}}.$$

Introduce the Dirichlet character  $\chi_{-3}$  that takes the value 0, 1, -1 on 0, 1, 2 modulo 3. Then it is easy to check that

$$(1 - \xi_3^{h_i(m_i+1)}) = \xi_{12}^{-\chi_{-3}(h_i(m_i+1))}$$

and hence

$$\prod_{i=0}^{2} (1 - \xi_3^{h_i(m_i+1)}) = \xi_{12}^{-\chi_{-3}(\mathbf{h}) \cdot \chi_{-3}(\mathbf{m}+1)},$$

where  $\chi_{-3}(\mathbf{m}+\mathbf{1})$  stands for the vector with components  $\chi_{-3}(m_0+1)$ ,  $\chi_{-3}(m_1+1)$ ,  $\chi_{-3}(m_2+1)$  and the notation  $\cdot$  above stands for inner product between two vectors. The property of the Dirichlet character  $\chi_{-3}$  tells that

$$\chi_{-3}(\mathbf{m}+\mathbf{1}) = -\chi_{-3}(\mathbf{1}-\mathbf{m}+\mathbf{1}), \quad \forall \, \mathbf{m} \in \{0,1\}^{\oplus 3}.$$

This immediately tells that

$$c_{1-\mathbf{m}}^{-1} \cdot [\mathbf{z}^{1-\mathbf{m}}\Omega] = \overline{c_{\mathbf{m}}^{-1} \cdot [\mathbf{z}^{\mathbf{m}}\Omega]} \in H \otimes \mathbb{C}.$$

In particular, the real cohomomology classes are spanned over  $\mathbb{R}$  by

$$\mu c_{\mathbf{m}}^{-1} \cdot [\mathbf{z}^{\mathbf{m}} \Omega] + \bar{\mu} c_{\mathbf{1} - \mathbf{m}}^{-1} \cdot [\mathbf{z}^{\mathbf{1} - \mathbf{m}} \Omega] = \sum_{\mathbf{h} \in \{0, 1, 2\}^{\oplus 3}} (\mu \xi_{12}^{-\chi_{-3}(\mathbf{h}) \cdot \chi_{-3}(\mathbf{m} + 1)} + \bar{\mu} \xi_{12}^{\chi_{-3}(\mathbf{h}) \cdot \chi_{-3}(\mathbf{m} + 1)}) \check{\gamma}_{\mathbf{h}},$$

where  $\mu \in \mathbb{C}$ ,  $\mathbf{m} \in \{0,1\}^{\oplus 3}$ . Integral classes can then be obtained by suitably choosing  $\mu$ .

#### 2.4.2 Fermat quartic

<span id="page-17-0"></span>For the n = 3 case, the spectrum is shown in Table 3 below.

**Table 3:** Spectrum of the quartic polynomial singularity  $f_a$ .

| β           | 0 | $\frac{1}{4}$ | $\frac{2}{4}$ | $\frac{3}{4}$ | 1  | $\frac{5}{4}$ | $\frac{6}{4}$ | $\frac{7}{4}$ | 2 |
|-------------|---|---------------|---------------|---------------|----|---------------|---------------|---------------|---|
| $n_{\beta}$ | 1 | 4             | 10            | 16            | 19 | 16            | 10            | 4             | 1 |

**Automorphic bundles** We will be mainly interested in the  $0 \le \beta(\mathbf{m}) < 1$  sectors: the discussions on the other sectors are similar according to (2.30). The equations in Lemma 2.3 are listed in Table 4.

**The**  $D_0$  **sector.** We first consider the sector with  $\mathbf{m} = (0, 0, 0, 0)$  given by

<span id="page-17-1"></span>
$$\mathcal{D}_{\text{quartic}} := \theta_b(\theta_b - \frac{1}{4})(\theta_b - \frac{2}{4}) - b(\theta_b + \frac{1}{4})^3, \qquad (2.40)$$

with the corresponding local system  $D_0$  over  $\mathcal{M}$ . Similar to the cubic case, one can show that sections of  $D_0$  correspond to automorphic forms for the triangular group  $\Gamma_{4,2,\infty} \cong \Gamma_0(2)^+ < \mathrm{PSL}_2(\mathbb{R})$ ,

<span id="page-18-0"></span>**Table 4:** Differential equations satisfied by the geometric sections  $s[\mathbf{z}^{\mathbf{m}}\Omega]$ .

| m            | differential operator                                                    |
|--------------|--------------------------------------------------------------------------|
| (0,0,0,0)    | $(\theta_a - 2)(\theta_a - 1)\theta_a - \frac{a^4}{4^4}(\theta_a + 1)^3$ |
| (1,0,0,0)    | $(\theta_a - 1)\theta_a - \frac{a^4}{4^4}(\theta_a + 1)^2$               |
| (2,0,0,0)    | $(\theta_a - 2)\theta_a - \frac{a^4}{4^4}(\theta_a + 1)^2$               |
| (1, 1, 0, 0) | $(\theta_a - 1)\theta_a - \frac{a^4}{4^4}(\theta_a + 1)(\theta_a + 2)$   |
| (1, 1, 1, 0) | $(\theta_a - 1)\theta_a - \frac{a^4}{4^4}(\theta_a + 2)^2$               |
| (2,1,0,0)    | $\theta_a - \frac{a^4}{4^4}(\theta_a + 1)$                               |

up to a twist by  $b^{-\frac{1}{4}}$  that changes  $\mathcal{D}_{quartic}$  to  $\mathcal{D}_{K3} := b^{\frac{1}{4}} \circ \mathcal{D}_{quartic} \circ b^{-\frac{1}{4}}$ . The twist  $b^{\frac{1}{4}}$  itself can be regarded as a section of a flat bundle and hence an automorphic form for  $\Gamma_{4,2,\infty}$ , by the Riemann-Hilbert correspondence. Furthermore one can show that after a further twist, these sections are related to elliptic modular forms for  $\Gamma_0(2)$ . In order not to interrupt the main stream of the presentation, we have left the detailed discussions to Appendix B.

**Sectors with**  $\beta(\mathbf{m}) = 1/4$ . Again by the  $\mathfrak{S}_4$ -symmetry in Lemma 2.3, we only need to focus on  $\mathbf{m} = (1,0,0,0)$ . Results for the other sectors obtained by  $\mathfrak{S}_4$ -actions are the same. From the results in Table 4, we see that for this sector the differential operator is

$$\theta(\theta - \frac{1}{4}) - b(\theta + \frac{1}{4})^2, \quad \theta := b\frac{\partial}{\partial b}.$$

The corresponding bundle  $D_{\mathbf{m}}$  is a representation of the triangular group  $\Gamma_{4,4,\infty}$  that arises as the projectivized monodromy group. Furthermore, sections of  $F^2D_{\mathbf{m}}$  and  $F^1D_{\mathbf{m}}$  are automorphic forms for this triangular group. In fact, similar to any other rank-2 local system arising from a Fuchsian equation, from the Schwarzian uniformization one can directly read off the automorphy factors for these bundles as explained in Remark 2.7.

Other twisted sectors with  $\beta(\mathbf{m}) < 1$ . The same reasoning gives the triangular groups (essentially determined by the exponent differences) for all the other twisted sectors with  $\beta(\mathbf{m}) < 1$ . Results from straightforward computations complete Table 4 to Table 5 below.

**Remark 2.9.** To demonstrate the analogy between automorphic forms in  $D_{\mathbf{m}}$  and quasi-modular forms, consider the  $\mathbf{m} = \mathbf{0}$  case. According to the computations in Appendix B, the automorphy factor for  $F^3D_0$  is  $(c\tau + d)^{-2}$ , with  $\tau$  being the Schwarzian given in (B.18). Then the automorphy factors for  $F^2D_0$  and  $F^1D_0 = F^0D_0$  are given by

$$\begin{pmatrix} (c\tau+d)^{-2} & -2c(c\tau+d)^{-1} \\ 0 & 1 \end{pmatrix}, \quad \begin{pmatrix} (c\tau+d)^{-2} & -2c(c\tau+d)^{-1} & 2c^2(c\tau+d)^{-2} \\ 0 & 1 & -2c(c\tau+d) \\ 0 & 0 & (c\tau+d)^2 \end{pmatrix},$$

respectively. Coordinate expressions for the corresponding automorphic form then satisfy transformation laws similar to those of quasi-modular forms.

**Remark 2.10.** The triangular groups  $\Gamma_{\ell(\mathbf{m})}$  are regarded as subgroups of  $PSL_2(\mathbb{R})$  arising from the projectivized monodromy groups. However, the presentations of the monodromies (hypergeometric group in the terminology of [BH89] using Levelt's theorem) a priori are only matrices in  $GL_2(\mathbb{C})$ .

Basing on the results in [BH89] on the monodromy groups of hypergeometric equations, up to conjugacy they are actually elements in  $SL_2(\mathbb{R}) \times U_1(\mathbb{R})$ . These monodromy matrices are explicitly worked out and also included in Table 5. The  $U_1(\mathbb{R})$  factors can be cancelled by a suitable twist

<span id="page-19-0"></span>**Table 5:** Triangular groups and monodromy representations corresponding to cohomology sectors. Here  $\xi_k = \exp(2\pi i/k)$ , and  $T_1$  is determined from the relation  $T_\infty T_1 T_0 = 1$ . The symmetric square of the monodromy representation of the row labelled by  $\mathbf{m} = -$  is isomorphic to the one for the  $\mathbf{m} = \mathbf{0}$  case (see Appendix B). The last row with  $\mathbf{m} = \star$  shows an auxiliary differential equation that does nor arise from any sector but has  $\Gamma_{4,\infty,\infty}$  as its projectivized monodromy group.

| m         | differential equation                                                            | group                      | presentations of $T_0$ , $T_\infty$                                                                                                                                                                                                       |
|-----------|----------------------------------------------------------------------------------|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| (0,0,0,0) | $\theta(\theta - \frac{1}{4})(\theta - \frac{2}{4}) - b(\theta + \frac{1}{4})^3$ | $\Gamma_{4,2,\infty}$      | $\begin{bmatrix} \xi_4^{-1} \begin{pmatrix} 0 & 0 & -1 \\ 0 & 1 & 4 \\ -1 & 1 & -2 \end{pmatrix}, \xi_4 \begin{pmatrix} 1 & -1 & 2 \\ 0 & 1 & -4 \\ 0 & 0 & 1 \end{pmatrix}$                                                              |
| (1,0,0,0) | $\theta(\theta - \frac{1}{4}) - b(\theta + \frac{1}{4})^2$                       | $\Gamma_{4,4,\infty}$      | $\xi_8 \frac{1}{\sqrt{2}} \begin{pmatrix} -1 & -5 \\ 1 & 3 \end{pmatrix}$ , $\xi_4 \begin{pmatrix} 1 & -4 \\ 0 & 1 \end{pmatrix}$                                                                                                         |
| (2,0,0,0) | $\theta(\theta - \frac{2}{4}) - b(\theta + \frac{1}{4})^2$                       | $\Gamma_{2,\infty,\infty}$ | $eta_4^{-1} egin{pmatrix} 0 & -1 \ 1 & 0 \end{pmatrix}$ , $eta_4 egin{pmatrix} 0 & -1 \ 1 & 2 \end{pmatrix}$                                                                                                                              |
| (1,1,0,0) | $\theta(\theta - \frac{1}{4}) - b(\theta + \frac{1}{4})(\theta + \frac{2}{4})$   | $\Gamma_{4,\infty,4}$      | $egin{array}{ccc} \xi_8^{-3} egin{pmatrix} -\sqrt{2} & -1 \ 1 & 0 \end{pmatrix}$ , $\xi_8^3 egin{pmatrix} 0 & 1 \ -1 & \sqrt{2} \end{pmatrix}$                                                                                            |
| (1,1,1,0) | $\theta(\theta - \frac{1}{4}) - b(\theta + \frac{2}{4})^2$                       | $\Gamma_{4,4,\infty}$      | $\xi_8 \frac{1}{\sqrt{2}} \begin{pmatrix} -1 & 1 \\ -5 & 3 \end{pmatrix}$ , $\begin{pmatrix} 1 & -2 \\ 2 & -3 \end{pmatrix}$                                                                                                              |
| (2,1,0,0) | $\theta - b(\theta + \frac{1}{4})$                                               | $\Gamma_{1,4,4}$           | $1$ , $\xi_4$                                                                                                                                                                                                                             |
| _         | $\theta(\theta - \frac{1}{4}) - b(\theta + \frac{1}{8})^2$                       | $\Gamma_{4,2,\infty}$      | $ \zeta_8^{-1} \begin{pmatrix} \frac{\sqrt{2}-1}{2} & -\frac{3}{2} \\ \frac{1}{2} & \frac{\sqrt{2}+1}{2} \end{pmatrix}, \zeta_8 \begin{pmatrix} \frac{3}{2} & -\frac{\sqrt{2}+1}{2} \\ \frac{\sqrt{2}-1}{2} & \frac{1}{2} \end{pmatrix} $ |
| *         | $\theta(\theta - \frac{3}{4}) - b(\theta + \frac{1}{8})^2$                       | $\Gamma_{4,\infty,\infty}$ | $\xi_8^{-1} \begin{pmatrix} \sqrt{2} & -1 \\ 1 & 0 \end{pmatrix}$ , $\xi_8 \begin{pmatrix} 0 & 1 \\ -1 & 2 \end{pmatrix}$                                                                                                                 |

which can be multi-valued functions on the quotient  $\Gamma_{\ell(\mathbf{m})} \setminus \mathcal{H}$ . The twist procedure also kills the semi-simple part of the quasi-unipotent monodromies. For example, for the  $\mathbf{m}=(1,0,0,0)$  case, a twist by  $b^{-\frac{1}{8}}(1-b)^{\frac{3}{8}}$  changes the differential operator  $\theta(\theta-\frac{1}{4})-b(\theta+\frac{1}{4})^2$  to

$$b^{-\frac{1}{8}}(1-b)^{\frac{3}{8}}\circ \left(\theta(\theta-\frac{1}{4})-b(\theta+\frac{1}{4})^2\right)\circ (b^{-\frac{1}{8}}(1-b)^{\frac{3}{8}})^{-1}\,.$$

<span id="page-19-1"></span>The latter is a differential operator whose Riemann scheme is given by Table 6. For the m =

**Table 6:** Riemann scheme for the differential equation for the  $\mathbf{m} = (1,0,0,0)$  sector after the twist.

| ь               | 0              | 1        | $\infty$ |
|-----------------|----------------|----------|----------|
| local exponents | $-\frac{1}{8}$ | <u>3</u> | 0        |
|                 | $\frac{1}{8}$  | <u>5</u> | 0        |

(2,0,0,0) case, applying the twist  $b^{-\frac{1}{4}}$ , one arrives at the familiar presentation of  $\Gamma_{2,\infty,\infty}\cong\Gamma_0(2)<\mathrm{PSL}_2(\mathbb{Z})$  in terms of matrices in  $\mathrm{SL}_2(\mathbb{Z})$ .

Unifying triangular groups With the triangular groups  $\Gamma_{\ell(\mathbf{m})}$  determined from the sectors  $D_{\mathbf{m}}$ , the desired quotient homomorphism  $\rho_{\ell(\mathbf{m})}:\Gamma_{4,\infty,\infty}\to\Gamma_{\ell(\mathbf{m})}$  in the proof Theorem 2.5 is in no way unique. We can however construct, once and for all, natural ones by using the fact that they are orbifold fundamental groups. Such homomorphisms can be chosen to respect the semi-simple parts of their monodromy representations. Concretely, to obtain a homomorphism one maps the generators of  $\Gamma_{4,\infty,\infty}$  to suitable powers of those of  $\Gamma_{\ell_0,\ell_1,\ell_\infty}$ . The powers are dictated by the semi-simple parts of the monodromies. For example, using the presentation in (2.33), a homomorphism  $\Gamma_{4,\infty,\infty}\to\Gamma_{2,\infty,\infty}$  can be given by  $\sigma\mapsto\sigma',\tau\mapsto\tau'$ , where  $\sigma,\tau$  are the generators corresponding to the loops at the orbifold point  $p_0$  and the cusp  $p_\infty$ , and similarly  $\sigma',\tau'$  the corresponding generators for  $\Gamma_{2,\infty,\infty}$ . Note that this homomorphism does not descend from a homomorphism on  $\mathrm{PSL}_2(\mathbb{R})$  as the monodromy matrices corresponding to  $\sigma,\tau$  do not generate the full group  $\mathrm{PSL}_2(\mathbb{R})$  but only a subgroup.

#### <span id="page-20-1"></span>2.4.3 Fermat quintic

The discussions for the n=4 case are analogous to the previous cases, except for the lack of connection to elliptic modular forms and the explicit identification of automorphy factors for  $F^{\text{top}}D_{\mathbf{m}}$ . Here we again only focus on the  $D_{\mathbf{0}}$  sector which exhibit particularly interesting properties.

As explained before, via the Poincaré residue map (2.8) the  $D_0$  sector coincides with the variation of Hodge structure for the quintic family  $X \to \mathcal{M} = \mathbb{P}^1 - \{0, 1, \infty\}$  given by

$$\sum_{i=0}^{4} z_i^5 - 5z^{-\frac{1}{5}} \prod_{i=0}^{4} z_i = 0.$$
 (2.41)

The Picard-Fuchs operator is now, up to a twist,

<span id="page-20-2"></span>
$$\mathcal{D}_{\text{quintic}} = \theta^4 - z \prod_{k=1}^4 (\theta + \frac{k}{5}), \quad \theta := z \frac{\partial}{\partial z}.$$
 (2.42)

By examining the indicial differences, the flat vector bundle  $D_0$  corresponds to a representation of  $\Gamma_{\infty,\infty,5}=\pi_1^{\rm orb}(T_{\infty,\infty,5})$ . In particular, sections of the canonical extension  $\overline{D}_0$  are automorphic forms for the triangular group  $\Gamma_{\infty,\infty,5}$ .

Remark 2.11. A crucial difference from the previous cases is that now the automorphy factor for  $F^3D_0$  is not given by a j-automorphy factor (1.6), this is partially due to the lack of a direct relation between the representation  $D_0$  and that for the rank-2 fundamental representation of  $\Gamma_{\infty,\infty,5}$ . By calculating the monodromy representation of  $D_0$  one can see that it does not admit a symmetric cube structure, unlike the Fermat quartic case discussed in Appendix B. This is ultimately related to the nontriviality of genus zero GW invariants for its mirror, see [Zho16] for extended discussions on this.

We now study the differential structure of the periods, namely solutions to the Picard-Fuchs equation (2.42), as promised in Section 2.3. For concreteness, we take a basis of solutions near the maximally unipotent monodromy point z = 0 and denote them by  $I_0$ ,  $I_1$ ,  $I_2$ ,  $I_3$ , respectively. Such a basis can be obtained from the Frobenius method for instance.

#### <span id="page-20-0"></span>**Definition 2.12.** Denote

$$T = I_{1,0} = \frac{I_1}{I_0}, \quad I_{2,0} = \frac{I_2}{I_0}, \quad I_{3,0} = \frac{I_3}{I_0}.$$
 (2.43)

The Yamaguchi-Yau ring [YY04] (see also [BCOV94]) is given by (here  $' = \partial_z$ )

$$\mathcal{F}_{YY} := \mathbb{C}(z) \left[ \frac{I_0'}{I_0}, \frac{I_0''}{I_0}, \frac{I_0'''}{I_0}, \frac{T''}{T'} \right]. \tag{2.44}$$

By using the special geometry relation [Str90, Fre99] satisfied by the Picard-Fuchs equation (2.42) above, we have the following relations [CDF<sup>+</sup>93a, BCOV94, CDF<sup>+</sup>93b, LY96b, YY04] (see also [AZ04, AL07, GKMW07, Hos08, ZZ08])

<span id="page-21-2"></span>
$$I''_{2,0} = -2I_{2,0} + I_{1,0}I_{2,0},$$

$$I''_{2,0} = I'_{2,0}\frac{I''_{1,0}}{I'_{1,0}} + \frac{1}{I_0^2I'_{1,0}}C, \quad C := \frac{5}{1 - 5^5z},$$

$$T''' = T''(-2\frac{I'_0}{I_0} + C) + T'\left(-4\frac{I''_0}{I_0} + 2(\frac{I'_0}{I_0})^2 - C' + 2\frac{I'_0}{I_0}C + C^2 + \frac{7}{5}C\right). \quad (2.45)$$

See Appendix B of the arXiv version of [CGLZ20] and references therein for the geometric explanation for each of the relations above. In particular, the first relation follows from from the fact that the monodromy lies in  $SL_4(\mathbb{C})$ , while the last one from the flatness of the Gauss-Manin connection.

<span id="page-21-0"></span>**Proposition 2.13.** The Yamaguchi-Yau ring  $\mathcal{F}_{YY}$  is a differential ring under  $\partial_z$ , with generators being components of automorphic forms for  $\Gamma_{\infty,\infty,5}$ .

*Proof.* The proof of the first part is contained in [YY04]. It follows from the Picard-Fuchs equation satisfied by  $I_0$  and the last relation in (2.45). The second part follows from Theorem 2.5, the Poincaré residue map (2.8), and the fact that period integrals of  $Q_a$  are coordinate expressions of cohomology classes in  $H^3(Q_a)$  with respect to the locally constant frame of the corresponding local system over  $\mathcal{M}$ .

The differential ring structure of  $\mathcal{F}_{YY}$  has made its frequent appearance in the study of higher genus mirror symmetry for the quintic and related geometries. See [BCOV94, YY04, AL07, GKMW07, Hos08, ZZ08] and the more recent works [ASYZ14, LP18, CGL18, GJR18] for details.

We now prove the following result regarding the algebraic independence over  $\mathbb{C}(z)$  of the generators in the Yamaguchi-Yau ring. This property is of crucial importance in studying higher genus GW theory, such as solving holomorphic anomaly equations [ASYZ14, Zho14, LP18].

<span id="page-21-1"></span>Theorem 2.14. One has

<span id="page-21-4"></span>
$$\operatorname{trdeg}_{\mathbb{C}(z)} \mathbb{C}(z) \left( \frac{I_0'}{I_0}, \frac{I_0''}{I_0}, \frac{I_0'''}{I_0}, \frac{T''}{T'} \right) = 4.$$
 (2.46)

In particular, the Yamaguchi-Yau generators are algebraically independent over  $\mathbb{C}(z)$ .

*Proof.* The proof is a simple application of differential Galois theory. Denote  $\mathcal{F} = \mathbb{C}(z)$  to be the ground differential field, with differential  $\partial = \partial_z$ . Consider the Picard-Vessiot extension  $\mathcal{G}$  for  $\mathcal{D}_{\text{quintic}}$  over  $\mathcal{F}$ . Concretely this is the differential field over  $\mathcal{F}$  obtained by adjoining differentials of the solutions to  $\mathcal{D}_{\text{quintic}}$ . Using the results between the monodromy group and the differential Galois group [BH89], a direct computation on the monodromy group shows that the transcendental degree satisfies

$$\operatorname{trdeg}_{\partial}(\mathcal{G}/\mathcal{F}) = \dim \operatorname{Sp}_{4}(\mathbb{C}) = 10. \tag{2.47}$$

Hence as ordinary fields

<span id="page-21-3"></span>
$$\operatorname{trdeg}(\mathcal{G}/\mathbb{C}(z)) > 10. \tag{2.48}$$

Since the periods satisfy the 4th order Picard-Fuchs equation (2.42), we see that a set of generators of  $\mathcal{G}/\mathcal{F}$  can be taken to be the following 16 elements

$$I_0\,,\,I_0'\,,\,I_0''\,,\,I_0'''\,,\,T\,,\,T'\,,\,T''\,,\,T'''\,,\,I_{2,0}\,,\,I_{2,0}'\,,\,I_{2,0}''\,,\,I_{2,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}'''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,0}''\,,\,I_{3,$$

The relations (2.45) tells that

<span id="page-21-5"></span>
$$\mathcal{G} = \mathcal{F}(I_0, I_0', I_0'', I_0''', T, T', T'', I_{2,0}, I_{2,0}', I_{3,0}) = \mathcal{F}(\frac{I_0'}{I_0}, \frac{I_0''}{I_0}, \frac{I_0'''}{I_0}, \frac{T''}{T'}, I_0, T, T', I_{2,0}, I_{2,0}', I_{3,0}).$$
(2.49)

In particular, one has

<span id="page-22-3"></span>
$$\operatorname{trdeg}(\mathcal{G}/\mathbb{C}(z)) \le 10. \tag{2.50}$$

Combining (2.48), (2.50), we are led to

$$\operatorname{trdeg}(\mathcal{G}/\mathbb{C}(z)) = 10. \tag{2.51}$$

The desired assertion (2.46) now follows immediately.

We remark that a different way of finding the relations is presented in [Mov11], which also leads to the proof of (2.50) and in particular the algebraic independence of the generators exhibited in (2.49).

# <span id="page-22-0"></span>3 Genus zero GW invariants of Fermat Calabi-Yau varieties

We are interested in the genus zero Gromov-Witten invariants corresponding to the part of the quantum cohomology generated by classes pulled back from the ambient space. This ambient part is the part that enters genus zero mirror symmetry [CdLOGP91]. Specializing to our examples, this is the identification [Giv96, Giv98, LLY97, LLY98] of the *I*-functions, which encode the genus zero GW invariants for the Calabi-Yau varieties, with solutions to Picard-Fuchs equations for the mirror [Bat94] Calabi-Yau family given in (1.3). See [CK99] and also [Gro03] for nice expositions.

We now transfer results from singularity theory to results in genus zero GW theory.

<span id="page-22-2"></span>**Theorem 3.1.** Consider the genus zero Gromov-Witten invariants for the Calabi-Yau (n-1)-fold M defined by the vanishing locus of the Fermat polynomial  $\sum_{i=0}^n x_i^{n+1} = 0$  in  $\mathbb{P}^n$ . Then the I-function, as a generating series of certain one-point GW invariants of M, is a component of an automorphic form valued in  $H^*(M)$  for the triangular group  $\Gamma_{n+1,\infty,\infty}$ . In particular, for the n=2,3 cases, the automorphic form is a vector-valued elliptic modular form (with possibly nontrivial multiplier systems) for certain congruence subgroup in  $\mathrm{PSL}_2(\mathbb{Z})$ .

*Proof.* By genus zero mirror symmetry, the *I*-function for M is identical to the holomorphic volume form for the corresponding Dwork family  $\{Q_a\}_{a\in S}$  over S in (1.3). Invoke the fact that the Poincaré residue map in (2.8) respects the  $D_S$ -structures (i.e., Gauss-Manin connections), to prove the holomorphic volume form is a component of an automorphic form it suffices to prove that for the section  $\zeta[\Omega]$  in the  $D_0$  sector, which in turn is equivalent to proving that for the geometric section  $s[\Omega]$  by the quasi-homogeneity. The last statement follows from Theorem 2.5.

The assertions on elliptic modular forms for the n = 2, 3 cases follow from direct computations on the  $D_0$  sectors shown in Section 2.4.

We remark that our strategy in establishing automorphicity is applicable to more general invariants (e.g., higher genus invariants that can be reconstructed from [DZ01, Tel12] or reduced to [FSZ10] genus zero ones) as long as the differential equations can be worked out.

In what follows we only discuss some quotients of quartic K3 surfaces. The orbifold GW invariants and quantum cohomology of an orbifold are defined on the Chen-Ruan cohomology [CR04, ALR07] which carries sophisticated gradings. Elements in the associated graded of the multi-graded Chen-Ruan cohomology are also called twisted sectors. We shall expose the roles played by twisted sectors in Chen-Ruan cohomology and twisted sectors in vanishing cohomology and study their mirror symmetry.

#### <span id="page-22-1"></span>3.1 *I-* and *J-*functions

In the rest of this section, we denote by Q the K3 surface defined by the vanishing locus of  $x^4 + y^4 + z^4 + w^4 = 0$  in  $\mathbb{P}^3$ . We consider the Givental I- and J-functions for several quotients of Q.

#### 3.1.1 Ouartic K3 surface

The *I*-function  $I_O$  is a  $H^*(Q)$ -valued function satisfying the quantum differential equation

<span id="page-23-3"></span>
$$\left(\partial_{\mathfrak{t}}^{3}-4^{3}e^{\mathfrak{t}}\prod_{k=1}^{3}(\partial_{\mathfrak{t}}+\frac{k}{4})\right)I_{Q}(\mathfrak{t},\mathfrak{z};P,\Lambda)=\mathfrak{z}(\frac{P}{\mathfrak{z}})^{3}e^{\mathfrak{t}P/\mathfrak{z}}=0\in\mathfrak{z}H^{*}(Q)[[\mathfrak{z}^{-1},e^{\mathfrak{t}},\Lambda]],\tag{3.1}$$

where P is the hyperplane class of  $\mathbb{P}^3$ ,  $\mathfrak{t}$  is the complexified Kähler parameter with Re  $\mathfrak{t}$  < 0,  $\mathfrak{z}$  is the descendant variable, and  $\Lambda$  is the Novikov variable which can be set to 1 safely. Explicitly it is given by

<span id="page-23-0"></span>
$$I_{Q}(\mathfrak{t},\mathfrak{z};P,\Lambda) = \mathfrak{z}e^{\frac{\mathfrak{t}P}{\mathfrak{z}}} \sum_{d \in \mathbb{Z}_{>0}} \Lambda^{4d} e^{4d\mathfrak{t}} \frac{\prod_{\ell=1}^{4d} (4P + \ell\mathfrak{z})}{\prod_{j=0}^{3} \prod_{\ell=1}^{d} (P + \ell\mathfrak{z})} = \mathfrak{z}F(\mathfrak{t}) + G(\mathfrak{t}) + \mathcal{O}(\mathfrak{z}^{-1}).$$
(3.2)

The  $\mathfrak{z}^{-1}$ -expansion of  $I_Q$  is the same as the one obtained by using the Frobenius method in solving differential equations. In particular, setting  $\Lambda = 1$  one has

<span id="page-23-1"></span>
$$F(\mathfrak{t}) = \sum_{d>0} e^{d\mathfrak{t}} \frac{4d!}{(d!)^4} = {}_{3}F_{2}(\frac{1}{4}, \frac{2}{4}, \frac{3}{4}; 1, 1; 4^4 e^{\mathfrak{t}}).$$
 (3.3)

The small J-function  $J_Q$ , as a cohomology valued generating series of GW one-point functions, is then given by

<span id="page-23-2"></span>
$$J_Q(T,\mathfrak{z}) = \frac{1}{F(\mathfrak{t})} I_Q(\mathfrak{t},\mathfrak{z}), \quad T = \frac{G(\mathfrak{t})}{F(\mathfrak{t})}.$$
 (3.4)

The big *J*-function can be obtained using axioms of GW theory. Expanding it in terms of *P* tells that the genus zero GW invariants are essentially trivial. Computationally this can be seen from the symmetric structure of the above quantum differential equation, see Appendix B for detailed discussions.

#### 3.1.2 Minimal quotient

We consider the quotient of *Q* by the trivial action

$$k \in G_{\min} = \mathbb{Z}/4\mathbb{Z} : [x, y, z, w] \mapsto [e^{\frac{2\pi ik}{4}}x, e^{\frac{2\pi ik}{4}}y, e^{\frac{2\pi ik}{4}}z, e^{\frac{2\pi ik}{4}}w].$$
 (3.5)

The quotient is the stack

$$Y_{\min} = Q \times B\mu_4, \tag{3.6}$$

where  $\mu_4 \cong \mathbb{Z}/4\mathbb{Z}$  is the multiplicative group consisting of 4th roots of unity and  $B\mu_4$  is the corresponding classifying space.

We follow the method in [CCIT19] to obtain the Givental I- and thus J-function by using extended stacky fans. First one takes the stacky fan  $(N, \Sigma, \rho)$  that defines the toric Deligne-Mumford stack  $\mathbb{P}^3 \times B\mu_4$ 

$$\beta: \mathbb{Z}^4 \to N = \mathbb{Z}^3 \oplus (\mathbb{Z}/4\mathbb{Z}), \tag{3.7}$$

with  $\beta$  given by the matrix

$$\begin{pmatrix} -1 & 1 & 0 & 0 \\ -1 & 0 & 1 & 0 \\ -1 & 0 & 0 & 1 \\ \hline 0 & 0 & 0 & 0 \end{pmatrix}.$$

Then one considers the extended stacky fan whose corresponding matrix presentation for  $\beta^S$ :  $\mathbb{Z}^{4\oplus 4}\to N$  is

$$\begin{pmatrix} -1 & 1 & 0 & 0 & 0 & 0 & 0 & 0 \\ -1 & 0 & 1 & 0 & 0 & 0 & 0 & 0 \\ -1 & 0 & 0 & 1 & 0 & 0 & 0 & 0 \\ \hline 0 & 0 & 0 & 0 & 0 & 1 & 2 & 3 \end{pmatrix}.$$

With the twisting data, it follows that the twisted I-function is given by

$$I_{\text{tw}} = \mathfrak{z}^{P\sum_{\rho=0}^{3} \mathfrak{t}_{\rho}/\mathfrak{z}} \sum_{b \in \{0, \frac{1}{4}, \frac{2}{4}, \frac{3}{4}\}} \sum_{\lambda=(d, k_0, k_1, k_2, k_3) \ge 0} \Lambda^{d} e^{d\sum_{\rho=0}^{3} \mathfrak{t}_{\rho}} x_0^{k_0} x_1^{k_1} x_2^{k_2} x_3^{k_3} I_{\lambda, b} M_{\lambda, b} \mathbb{1}_b,$$

$$\langle \frac{k_1 + 2k_p + 3k_3}{2} \rangle = b$$
(3.8)

with

$$I_{\lambda,b} = \frac{1}{\mathfrak{z}^{k_0 + k_1 + k_2 + k_3} k_0! k_1! k_2! k_3!} \prod_{\ell=1}^{d} \frac{1}{(P + \ell \mathfrak{z})^4}, \quad M_{\lambda,b} = \prod_{\ell=1}^{4d} (4P + \ell \mathfrak{z}).$$
 (3.9)

Here

- P is the class of  $c_1(\mathcal{O}_{Y_{\min}}(1))$  in  $H^2(Y_{\min})$ ,  $\mathfrak{t}_{\rho} \in \mathbb{C}$  with  $\operatorname{Re} \mathfrak{t}_{\rho} < 0$ ,  $\rho = 0, 1, 2, 3$ .
- $\Lambda$  is again the Novikov variable, similarly  $x_j$ , j = 0, 1, 2, 3 are formal parameters, and  $\mathfrak{z}$  is the descendant variable.
- b labels different components of the inertia stack  $IY_{min}$  of  $Y_{min}$ ,  $\mathbb{1}_b$  is the fundamental class for the corresponding component.

It is direct to see that the summation in  $I_{tw}$  splits into the product of two, involving d and  $(k_0, k_1, k_2, k_3)$  respectively,

$$I_{\text{tw}} = I_{Q} \cdot \sum_{(k_{0}, k_{1}, k_{2}, k_{3}) \in \mathbb{N}^{4}} \prod_{j=0}^{3} \frac{x_{j}^{k_{j}}}{3^{k_{j}} k_{j}!} \mathbb{1}_{\langle \frac{k_{1} + 2k_{2} + 3k_{3}}{4} \rangle},$$
(3.10)

where  $I_Q$  is the *I*-function for the quartic K3 given in (3.2). This reflects the product structure  $Y_{\min} = \mathbb{P}^3 \times B\mu_4$ . From the quantum Lefschetz principle one can then determine the big *I*-function  $I_{Y_{\min}}$  and the corresponding *J*-function  $J_{Y_{\min}}$ .

#### 3.1.3 Maximal quotient

Consider the action of  $G_{\text{max}} = (\mathbb{Z}/4\mathbb{Z})^4$  on the homogeneous coordinate ring  $\mathbb{C}[x,y,z,w]$  of  $\mathbb{P}^3$ 

$$(k_0, k_1, k_2, k_3) \in G_{\max}: [x, y, z, w] \mapsto \left[e^{\frac{2\pi i k_0}{4}} x, e^{\frac{2\pi i k_1}{4}} y, e^{\frac{2\pi i k_2}{4}} z, e^{\frac{2\pi i k_3}{4}} w\right]. \tag{3.11}$$

We consider the faithful action by  $G = G_{\text{max}}/G_{\text{min}}$ . The quotient  $Y_{\text{max}} = Q/G$  is then a hypersurface in the toric stack  $\mathbb{P}^3/G$ . Denote  $i: Y_{\text{max}} \to \mathbb{P}^3/G$  to be the inclusion and  $IY_{\text{max}}$  the inertia stack of  $Y_{\text{max}}$ .

The number of components for the inertia stack  $IY_{\max}$  is the same as the cardinality of the Abelian group G. These components can also be classified according to the type of fixed locus  $(\mathbb{P}^3)^{(g)}$ . For example, let  $z_0$  be the homogeneous coordinate corresponding to the ray  $u_0$ , then all of the fixed loci for the reduced inertia stack can be chosen to be intersections of coordinate hyperplanes with  $z_0 \neq 0$ . By examining the components  $Y_{\max}^{(g)}$  in the inertia stack  $IY_{\max}$  according to  $g \in G$ , one sees that the coarse moduli are projective spaces and the dimension of  $H_{\text{CR}}^* = H^*(IY_{\max})$  is

<span id="page-24-0"></span>
$$\dim H^*(\mathbb{P}^2) \cdot 1 + \dim H^*(\mathbb{P}^1) \cdot \binom{4}{1} \cdot 3 + \dim H^*(\mathbb{P}^0) \cdot \binom{4}{2} \cdot (6 + \frac{3}{2} \cdot 2) = 81. \tag{3.12}$$

For the stack  $Y_{\max}$ , the big quantum cohomology is defined on the Chen-Ruan cohomology  $H^*_{\operatorname{CR}}(Y_{\max}) = H^*(IY_{\max})$ . According to [CCIT19], the corresponding invariants are encoded in the  $H^*_{\operatorname{CR}}([\mathbb{P}^3/G])$ -valued J-function which we now discuss. First one takes the stacky fan  $(N,\Sigma,\rho)$  that defines the toric Deligne-Mumford stack  $[\mathbb{P}^3/G]$ 

$$\beta: \mathbb{Z}^4 \to N = \mathbb{Z}^3$$

with  $\beta$  given by the matrix of rays in the fan

$$(u_0, u_1, u_2, u_3) = \begin{pmatrix} -4 & 4 & 0 & 0 \\ -4 & 0 & 4 & 0 \\ -4 & 0 & 0 & 4 \end{pmatrix}.$$

Now following the method in [CCIT19], one considers the extended stacky fan and obtain the twisted *I*-function as before. To be explicit, we take the extended fan to be given by  $\beta^S : \mathbb{Z}^{4+4} \to N$  with the extra generators mapped to  $u_i/4 \in \mathbb{Z}/4\mathbb{Z}\{u_0, u_1, u_2, u_3\}, j=0,1,2,3$ . We also take

$$\operatorname{Box}(\Sigma) = \{b = (b_j)_{j=0}^3 \in (\frac{1}{4}\mathbb{Z}/\mathbb{Z})^{\oplus 4} \mid \text{at least one } b_j \text{ is zero}\}.$$

The action of  $G_{\min}$  induces the shift on  $b = (b_0, b_1, b_2, b_3)$  by  $\frac{1}{4}(1, 1, 1, 1)$ . Note that elements in  $\text{Box}(\Sigma)$  are not in one-to-one correspondence with components of  $IY_{\max}$ , but modulo the action by  $G_{\min}$  this is so. It follows that the twisted I-function is given by

<span id="page-25-0"></span>
$$I_{\text{tw}} = 3e^{P\sum_{\rho=0}^{3} t_{\rho}/3} \sum_{b \in \text{Box}(\Sigma)} \sum_{\substack{d, k_{j} \ge 0 \\ k_{j} \in \mathbb{Z} \\ \langle \frac{1}{4}k_{j} - d \rangle = b_{j}}} \Lambda^{d} e^{d\sum_{\rho=0}^{3} t_{\rho}} \prod_{j=0}^{3} x_{j}^{k_{j}} I_{\lambda, b} M_{\lambda, b} \mathbb{1}_{b} , \qquad (3.13)$$

with

$$I_{\lambda,b} = \frac{1}{\prod_{j=0}^{3} \mathfrak{z}^{k_{j}} k_{j}!} \prod_{j=0}^{3} \frac{\prod_{a:\langle a \rangle = \langle d - \frac{1}{4}k_{j} \rangle, a \leq 0} (P + a \mathfrak{z})}{\prod_{a:\langle a \rangle = \langle d - \frac{1}{4}k_{j} \rangle, a \leq d - \frac{1}{4}k_{j}} (P + a \mathfrak{z})},$$

$$M_{\lambda,b} = \prod_{\ell=1}^{4d} (4P + \ell \mathfrak{z}).$$

Here again

- *P* is the class of  $c_1(\mathcal{O}_Y(1))$  in  $H^2(Y)$ ,  $\mathfrak{t}_{\rho} \in \mathbb{C}$  with Re  $\mathfrak{t}_{\rho} < 0$ ,  $\rho = 0, 1, 2, 3$ .
- $\Lambda$  is the Novikov variable which we later set to 1,  $x_j$ , j = 0, 1, 2, 3 are formal parameters which will be collectively denoted by x, and  $\mathfrak{z}$  is the descendant variable.
- b labels different components  $Y_{\max}^{(g)}, g \in G$  of the inertia stack  $IY_{\max}$  of  $Y_{\max}, \mathbb{1}_b$  is the fundamental class for the corresponding component and has degree  $2\sum_{j=0}^3 b_j$  in Chen-Ruan cohomology.

A direct calculation shows that

$$I_{\mathsf{tw}} = \mathfrak{z}F(\mathfrak{t}) + \widetilde{G}(\mathfrak{t}, x) + \mathcal{O}(\mathfrak{z}^{-1}), \tag{3.14}$$

where *F* is the same as the one in (3.3) with the relation  $\mathfrak{t} = \sum_{\rho=0}^{3} \mathfrak{t}_{\rho}$ , and

$$\widetilde{G}(\mathfrak{t},x) = G(\mathfrak{t}) + F(\mathfrak{t}) \sum_{j=0}^{3} x_{j} \mathbb{1}_{(0,\cdots,\frac{1}{4},\cdots,0)}.$$

From the quantum Lefschetz principle one has  $I_{Y_{\text{max}}}(\mathfrak{t}, x, \mathfrak{z}) = i^* I_{\text{tw}}$ . Similar to (3.4), one has the *I*-function

$$T(\mathfrak{t},x) = \frac{\widetilde{G}(\mathfrak{t},x)}{F(\mathfrak{t})}, \quad J_{Y_{\max}}(T,\mathfrak{z}) = \frac{I_{Y_{\max}}(\mathfrak{t},x,\mathfrak{z})}{F(\mathfrak{t})}.$$

### <span id="page-26-0"></span>3.2 Genus zero mirror symmetry

We focus on the one-point functions of orbifold GW invariants with fixed cohomology insertions. They correspond to coefficients of the cohomology-valued J-function  $J_Y = I_Y/F$ , in the Laurent expansion in  $\mathfrak{z}^{-1}$  and with respect to the basis for  $H^*_{\operatorname{CR}}(Y)$ . For Y = Q and  $Y = Q/G_{\min}$ , the identification between Givental I-functions and automorphic forms is immediate since the quantum differential equation (3.1) matches the Picard-Fuchs equation (2.40) for the  $D_0$  sector. We now discuss the maximal quotient  $Y = Y_{\max}$ . Setting  $\mathfrak{t} = \sum_{\rho=0}^3 \mathfrak{t}_\rho, \varepsilon = P/\mathfrak{z}$  and simplifying (3.13), one obtains

<span id="page-26-3"></span>
$$I_{\text{tw}} = \mathfrak{z} \sum_{\mathbf{k} \in \mathbb{N}^4} \prod_{j=0}^3 \frac{(\mathfrak{z}^{\frac{1}{4}} x_j)^{k_j}}{\mathfrak{z}^{k_j} k_j!} \cdot I_{\text{tw},\mathbf{k}}, \quad \mathbf{k} = (k_0, k_1, k_2, k_3),$$
(3.15)

with

<span id="page-26-1"></span>
$$I_{\mathsf{tw},\mathbf{k}}(\mathfrak{t},\varepsilon,\mathfrak{z}) = e^{\varepsilon\mathfrak{t}} \sum_{\substack{d: d \geq 0 \\ \prod_{j=0}^{3} \langle d - \frac{1}{4}k_{j} \rangle = 0}} \left( e^{d\mathfrak{t}} \prod_{j=0}^{3} \frac{\prod_{a: \langle a \rangle = \langle d - \frac{1}{4}k_{j} \rangle, a \leq 0} (\varepsilon + a)}{\prod_{a: \langle a \rangle = \langle d - \frac{1}{4}k_{j} \rangle, a \leq d - \frac{1}{4}k_{j}} (\varepsilon + a)} \prod_{\ell=1}^{4d} (4\varepsilon + \ell) \right)$$
(3.16)

$$\cdot \mathbb{1}_{\langle \frac{1}{4}\mathbf{k} - (d,d,d,d) \rangle} \prod_{j=0}^{3} \mathfrak{z}^{-\langle \frac{1}{4}k_j - d \rangle} \right). \tag{3.17}$$

Due to the constraint  $\prod_{j=0}^{3} \langle d - \frac{1}{4} k_j \rangle = 0$  in the range for d in (3.16),  $I_{\text{tw,k}}$  splits into the sum of 4 series according to the choice of  $j_* \in \{0,1,2,3\}$  such that  $\langle d - \frac{1}{4} k_{j_*} \rangle = 0$ . Within each series the quantity  $\langle d - \frac{1}{4} k_j \rangle$  and thus (3.17) are independent of those d that are subject to this condition. In fact, a closer look gives

<span id="page-26-2"></span>
$$I_{\text{tw},\mathbf{k}}(\mathfrak{t},\varepsilon,\mathfrak{z}) = e^{\varepsilon\mathfrak{t}} \sum_{\substack{d: d \geq 0 \\ \prod_{j=0}^{3} \langle d - \frac{1}{4}k_{j} \rangle = 0}} \left( e^{dt} \frac{\prod_{j=0}^{3} \Gamma(\varepsilon + 1 - \langle \frac{1}{4}k_{j} - d \rangle)}{\Gamma(4\varepsilon + 1)} \frac{\Gamma(4\varepsilon + 4d + 1)}{\prod_{j=0}^{3} \Gamma(\varepsilon + d - \frac{1}{4}k_{j} + 1)} \right)$$

$$\cdot \mathbb{1}_{\langle \frac{1}{4}\mathbf{k} - (d,d,d,d,d) \rangle} \prod_{j=0}^{3} \mathfrak{z}^{-\langle \frac{1}{4}k_{j} - d \rangle} \right).$$
(3.18)

From the perspective of the group action by G, each  $\mathbf{k} = (k_0, k_1, k_2, k_3)$  corresponds to

$$g:=(g_0,g_1,g_2,g_3)=(e^{\frac{2\pi i k_0}{4}},\cdots,e^{\frac{2\pi i k_3}{4}})\in\mu_4^{\oplus 4}\cong G_{\max}.$$

The condition  $\langle d-\frac{1}{4}k_{j_*}\rangle=0$  imposed by the constraint  $\prod_{j=0}^3 \langle d-\frac{1}{4}k_j\rangle=0$  corresponds to applying a transformation in  $G_{\min}$  such that the  $g_{j_*}$ -component of g is gauged to 1. For such a choice of  $j_*$ , similar to the discussion in (3.12), the coarse moduli of the corresponding inertia stack component  $Y^{(g)}$  is a projective space of dimension

$$3 - \text{cardinality}(\{j \in \{0, 1, 2, 3\} \mid k_j - k_{j_*} = 0 \in \mathbb{Z}/4\mathbb{Z}\}).$$

Hence the cohomology ring  $H^*(Y^g)$  of this component  $Y^{(g)}$  gives a subspace of the Chen-Ruan cohomology  $H^*_{CR}(Y) = H^*(IY)$  with dimension

$$N_{\mathbf{k},j_*} := 4 - \text{cardinality}(\{j \in \{0,1,2,3\} \mid k_j - k_{j_*} = 0 \in \mathbb{Z}/4\mathbb{Z}\}).$$
 (3.19)

Specifically, as a ring, its generators are given by the fundamental class  $\mathbb{1}_{\langle \frac{1}{4}\mathbf{k}-(\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*},\frac{1}{4}k_{j_*$ 

<span id="page-27-3"></span>
$$N_{\mathbf{k}} := 4 - \text{cardinality}(\{k_i\}_{i=0}^3).$$
 (3.20)

From the expression in (3.18) one can directly check that  $I_{tw,k}$  satisfies the differential equation

<span id="page-27-1"></span>
$$\left(\prod_{j=0}^{3} (\partial_{\mathfrak{t}} - \frac{1}{4}k_{j}) - 4^{4}e^{\mathfrak{t}} \prod_{i=1}^{4} (\partial_{\mathfrak{t}} + \frac{i}{4})\right) I_{\mathsf{tw},\mathbf{k}} = 0.$$
 (3.21)

Comparing (3.21) with (2.20) in Lemma 2.3, we see that  $I_{\text{tw},\mathbf{k}}$  satisfies the same equation as  $a \cdot \zeta[\mathbf{z}^{\mathbf{m}}\Omega]$ , under the mirror map

<span id="page-27-2"></span>
$$e^{t} = a^{-4}, \quad k_{j} = m_{j}, \ j = 0, 1, 2, 3.$$
 (3.22)

This tells that the I-function  $I_{\mathrm{tw},\mathbf{k}}$  is (component of) a cohomology-valued automorphic form. Under the map (3.22), the dimension (3.20) of the cohomology ring of  $Y^{(g)}$  agrees perfectly with the dimension (2.21) of the space of twisted sectors involved in  $D_{\mathbf{m}}$ . Interestingly, the shift  $\mathbf{k} \mapsto \mathbf{k} + (1,1,1,1)$  on the one hand is induced by the action of  $G_{\min}$  on Y, on the other hand maps the twisted sector  $\zeta[\mathbf{z}^{\mathbf{m}}\Omega]$  to  $\zeta[\mathbf{z}^{\mathbf{m}+1}\Omega]$ . Moreover, under (3.22) we also see that  $I_{\mathrm{tw}}$  in (3.15) satisfies the same differential equation as the geometric section

$$a \cdot \mathfrak{z} \sum_{\mathbf{m} \in \mathbb{N}^4} \prod_{j=0}^3 \frac{(x_j \mathfrak{z}^{\frac{1}{4}})^{m_j}}{\mathfrak{z}^{m_j} m_j!} \cdot s[\mathbf{z}^{\mathbf{m}} \Omega] = a \mathfrak{z} s[e^{\sum_{j=0}^3 \frac{\mathfrak{z}^{\frac{1}{4}} x_j z_j}{\mathfrak{z}}} \Omega].$$
(3.23)

According to the isomorphism in (2.25), this tells that  $I_{tw}$  is mirror to an oscillating integral, with the fundamental class (3.17) recording the data  $\mathbf{k}$  that is mirror to  $\mathbf{m}$ . This matches the general expectations from mirror symmetry, see e.g., [Giv95a, Giv95b, Giv96, LS14, IMRS21].

We therefore conclude that the identification (3.22) provides a map between twisted sectors in Chen-Ruan cohomology and twisted sectors in singularity theory that respects the D-module structures.

# <span id="page-27-0"></span>A Basics on singularities

We review some basics on deformations of singularities and fix some notation, following closely [Sai83, Mat98, Kul98, ST08]. The results reviewed below admit coordinate free descriptions, however for concreteness we phrase them in local coordinates.

Let

$$f: (\mathbb{C}^{n+1}, 0) \to (\mathbb{C}, 0) \tag{A.1}$$

be the germ of a holomorphic function near  $0 \in \mathbb{C}^{n+1}$  with only isolated critical point at  $0 \in \mathbb{C}^{n+1}$  and critical value 0. Let  $z = (z_0, z_1, \dots, z_n)$  be the standard complex coordinates on  $\mathbb{C}^{n+1}$  at the origin, and t the one for the target space  $\mathbb{C}$  near the critical value. Then the Jacobi/Milnor ring

$$Jac(f) = \mathbb{C}\{z_0, \cdots, z_n\} / \langle \partial_{z_0} f, \cdots, \partial_{z_n} f \rangle \tag{A.2}$$

is a finite dimensional vector space whose dimension is given by the Milnor number  $\mu = \mu(f) = \dim H^n(f^{-1}(t)), t \neq 0$ .

Following [Sai83, Mat98, ST08, Kul98], we consider an m-parameter deformation with only isolated critical point at the origin as follows. Taking a subset from the basis of the vector space Jac(f) which are represented by functions  $e_k(z)$ ,  $k = 0, 1, \dots, m-1$ . Consider the function

$$F(z,s) = f(z) + \sum_{k=0}^{m-1} s_k e_k(z)$$
(A.3)

defined around a neighborhood X of (z,s)=(0,0) in  $\mathbb{C}^{n+1}\times\mathbb{C}^m$ , where  $s=(s_0,\cdots,s_{m-1})$  are the standard coordinates of  $\mathbb{C}^m$  at the origin. Then the germ at (z,s)=(0,0) of  $F:X\to\mathbb{C}$  gives a deformation of the germ of the function f. Let

$$q: X \to S \subseteq \mathbb{C}^m$$
,  $\varphi = (F, q): X \to \mathbb{C} \times S$ , (A.4)

and

$$\pi_1: \mathbb{C} \times S \to \mathbb{C}, \quad \pi_2: \mathbb{C} \times S \to S$$
(A.5)

<span id="page-28-0"></span>be the projections. Then one has the commutative diagram shown in Figure 2.

![](_page_28_Figure_7.jpeg)

Figure 2: A deformation of singularity.

Assume further that S lies in the  $\mu$ -constant stratum. Let

$$C = \{(z,s) \in X \mid \operatorname{rank}(d\varphi)_{(z,s)} \le m - 1\}$$
(A.6)

be the critical set of the map  $\varphi$ . This is an analytic subspace of X with structure sheaf

$$\mathcal{O}_{C} = \mathcal{O}_{X} / \langle \partial_{z_{0}} F, \cdots, \partial_{z_{n}} F \rangle. \tag{A.7}$$

which has the usual commutative ring structure  $\circ$  and is regarded as a deformation of Jac(f). By the assumption that f has an isolated singularity, the map  $q|_C:C\to S$  is a proper, finite map of degree  $\mu$  and thus  $q_*\mathcal{O}_C$  is a locally free sheaf of rank  $\mu$  over S.

#### Frobenius structure

The sheaf of relative differentials for the family  $\varphi: X \to \mathbb{C} \times S$  is of central importance in studying the mixed Hodge structure of singularities [Kul98]. Using the fact that q is smooth, one can check that  $\Omega^{n+1}_{X/(\mathbb{C} \times S)}$  is a free  $\mathcal{O}_{\mathbb{C}}$ -module of rank one and hence one has an identification

<span id="page-28-1"></span>
$$\rho_{\xi}: q_*\mathcal{O}_C \to q_*\Omega^{n+1}_{X/(\mathbb{C}\times S)}. \tag{A.8}$$

This identification is not canonical and requires a choice  $\xi \in q_*\Omega_{X/(\mathbb{C} \times S)}^{n+1}$  that is a generator of  $q_*\Omega_{X/(\mathbb{C} \times S)}^{n+1}$  as a free  $q_*\mathcal{O}_{\mathbb{C}}$ -module. When F is the semi-universal deformation (i.e., universal unfolding), a suitable choice of  $\xi$  in (A.8) known as primitive form and some other data including higher residue parings provide a Frobenius algebra structure on  $q_*\mathcal{O}_{\mathbb{C}}$ , as well as a Frobenius manifold structure on S via the Kodaira-Spencer map. See [Sai83, Dub96, ST08, Sat86, Sat93,

Aud97, Sat98, NY98, Man99a, Man99b, Her02, Sab08, Sat10, ST11, Str12]. This structure can be further enhanced to a special Kähler structure [Str90, Fre99]. Interested readers are referred to [Dub96, CV91, Ali17] for details.

#### **Brieskorn lattice**

An essential ingredient in the studies of singularity theory is the Brieskorn lattice  $\mathcal{H}^{(0)}$  in the following set of sheaves

$$\mathcal{H}^{(-2)} := \mathbb{R}^{n} \varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{\bullet} \cong \operatorname{Ker} (\varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{n} \to \varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{n+1}) / d\varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{n-1},$$

$$\mathcal{H}^{(-1)} := \varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{n} / d\varphi_{*} \Omega_{X/(\mathbb{C} \times S)}^{n-1} \cong \varphi_{*} \Omega_{X/S}^{n} / (dF \wedge \varphi_{*} \Omega_{X/S}^{n-1} + d\varphi_{*} \Omega_{X/S}^{n-1}),$$

$$\mathcal{H}^{(0)} := \varphi_{*} \Omega_{X/S}^{n+1} / (dF \wedge d\varphi_{*} \Omega_{X/S}^{n-1})$$

$$(A.9)$$

where the isomorphisms follow from the Stein property of  $\varphi$ . The latter two sheaves are extensions of the relative de Rham cohomology sheaf  $\mathcal{H}^{(-2)}$ . Furthermore, one has

<span id="page-29-1"></span>
$$0 \to \mathcal{H}^{(-1)} \to \mathcal{H}^{(0)} \xrightarrow{r} \varphi_* \Omega^{n+1}_{X/(\mathbb{C} \times S)} \to 0, \tag{A.10}$$

where r is the natural surjection. The Brieskorn lattice  $\mathcal{H}^{(0)}$  is generated by the classes  $[\omega]$  of the forms  $\omega \in \varphi_* \Omega_{X/S}^{n+1}$ . The corresponding Gelfand-Leray residues, called geometric sections  $s[\omega]$ , give rise to classes in  $\mathcal{H}^{(-2)}$ , see [Kul98][Section I.5.1.6] and [AGZV85, AGZV88]. The Brieskorn lattice  $\mathcal{H}^{(0)}$  is part of the Hodge filtration  $\{\mathcal{H}^{(k)}\}_{k>0}$  on the Gauss-Manin differential system  $\mathcal{H}_X$  given by

<span id="page-29-0"></span>
$$\mathcal{H}^{(k)} = F^{n-k}\mathcal{H}_X = \partial_t^k \mathcal{H}^{(0)}, \quad k \le n.$$
(A.11)

In particular, one has an inclusion  $\mathcal{H}^{(0)} \subseteq \mathcal{H}_X$ . The meromorphic connection  $\mathcal{M}_X$  is related to  $\mathcal{H}^{(0)}$ ,  $\mathcal{H}_X$  by localization, that is,  $\mathcal{M}_X = (\mathcal{H}_X)_{(t)} = (\mathcal{H}^{(0)})_{(t)}$ . The D-modules  $\mathcal{H}_X$ ,  $\mathcal{M}_X$  are equipped with the Kashiwara-Malgrange V-filtration  $V^{\bullet}$  which can be defined according the eigenvalues of the action by  $t\partial_t$ . The canonical lattice  $\mathcal{L}$  is then defined by

$$\mathcal{L} := V^{>-1} \mathcal{M}_{X}. \tag{A.12}$$

It is a locally free sheaf that extends the de Rham cohomology sheaf  $\mathcal{H}^{(-2)}$  and lies in the Gauss-Manin differential system  $\mathcal{H}_X$ .

### Mixed Hodge structure and embedding of the Brieskorn lattice

We now consider mixed Hodge structures on the vanishing cohomology, following closely the expositions in [Kul98].

Assume that S lies in the so-called  $\mu$ -constant stratum [AGZV85, AGZV88]. Denote

$$X(s) = X \times_{\mathbb{C} \times S} (\mathbb{C} \times \{s\}),$$

then the restrictions of constructions for  $X \to \mathbb{C} \times S$  to  $X(s) \to \mathbb{C}$  coincide with those for the singularity  $f_s := F|_{X(s)}$ . To avoiding choosing  $t \neq 0 \in \mathbb{C}$  when considering structures on the cohomologies of  $X(s)_t := f_s^{-1}(t), s \in S$ , we take the homotopy fiber  $X(s)_\infty$  and consider the vanishing cohomology  $H^n(X(s)_\infty)$  which can be intrinsically defined in terms of the vanishing cycle functor  $R\Phi_{f_s}$  as

$$H^n(X(s)_{\infty}) = R^n \Gamma \circ R\Phi_{f_s}(\mathbb{C}_{X(s)}).$$

It follows that the vanishing cohomology  $H^n(X(s)_{\infty})$  is isomorphic to the fiber at (0,s) of the canonical lattice

<span id="page-30-3"></span>
$$\mathcal{L}(s) \subseteq \mathcal{H}_{X(s)}$$
. (A.13)

Namely, one has

<span id="page-30-0"></span>
$$\psi(s): H^n(X(s)_\infty) \cong \mathcal{L}(s)/t\mathcal{L}(s)$$
. (A.14)

By analyzing the asymptotic behavior of the sections that generate the Brieskorn lattice  $\mathcal{H}^{(0)}$ , one has the embedding

<span id="page-30-5"></span>
$$\mathcal{H}^{(0)}(s) \subseteq \mathcal{L}(s) \tag{A.15}$$

which respects localization  $(-)_{(t)}$ .

The vanishing cohomology carries a mixed Hodge structure which we now describe. From the monodromy action, one has

<span id="page-30-4"></span>
$$H^{n}(X(s)_{\infty}) = \bigoplus_{\lambda: |\lambda|=1} H^{n}(X(s)_{\infty})_{\lambda} \xrightarrow{\psi(s)} \bigoplus_{-1 < \alpha \le 0} C_{\alpha}(s), \qquad (A.16)$$

where  $H^n(X(s)_\infty)_\lambda$  is the eigenspace of the monodromy  $T=T_{ss}T_u=T_{ss}e^{2\pi iN}$  of the singularity  $f_s:\mathbb{C}^{n+1}\to\mathbb{C}$  around its singular fiber  $f_s^{-1}(0)$  with eigenvalue  $\lambda$ . This eigenspace is the same as the generalized eigenspace  $C_\alpha(s)$  of  $t\partial_t$  with eigenvalue  $\alpha\in(-1,0]$ . The weight filtration is then induced by the Jacobson-Morosov filtration using the unipotent part  $T_u$  of the monodromy T. In particular,  $H^n(X(s)_\infty)_{\lambda=1}$  has weight w=n+1 and  $H^n(X(s)_\infty)_{\lambda\neq 1}$  weight w=n. The Hodge filtration (in the sense of Saito-Scherk-Steenbrink) is induced by the one (A.11) on the Gauss-Manin differential system  $\mathcal{H}_X(s)$  via the inclusion (A.13) and the isomorphism (A.14). It is defined individually on each eigenspace  $H^n(X(s)_\infty)_\lambda$  or equivalently generalized eigenspace  $C_\alpha(s)$  of T as follows. One first defines on the generalized eigenspace  $C_\alpha(s)$  the filtration (recall that spaces in  $\mathcal{H}^{(0)}(s)\subseteq\mathcal{L}(s)\subseteq\mathcal{H}_{X(s)}$  have induced V-filtrations from the one on  $\mathcal{H}_{X(s)}$ )

<span id="page-30-2"></span>
$$F^{p}C_{\alpha}(s) = \partial_{t}^{n-p} \operatorname{gr}_{V}^{n-p+\alpha} \mathcal{H}^{(0)}(s), \qquad (A.17)$$

with  $\operatorname{gr}_V^{n-p+\alpha}\mathcal{H}^{(0)}(s)$  generated by the leading parts of the sections  $[\omega]$ ,  $\omega \in f_{s_*}\Omega^{n+1}_{X(s)/\mathbb{C}}$ . This filtration satisfies (cf. (A.10))

$$\operatorname{gr}_F^p C_\alpha(s) = \partial_t^{n-p} \operatorname{gr}_V^{n-p+\alpha}(\mathcal{H}^{(0)}(s)/\mathcal{H}^{(-1)}(s)). \tag{A.18}$$

Then via (A.16) one declares

$$F^{p}H^{n}(X(s)_{\infty}) \xrightarrow{\stackrel{\varphi(s)}{\longrightarrow}} F^{p}(\mathcal{L}(s)/t\mathcal{L}(s)) = \bigoplus_{-1 < \alpha \le 0} F^{p}C_{\alpha}(s). \tag{A.19}$$

To be more concrete, the period integral of a geometric section  $s[\omega]$  arising from

$$[\omega] \in V^{>(n-p-1)}\mathcal{H}_{X(s)} \cap \mathcal{H}^{(0)}(s) = V^{>(n-p-1)}\mathcal{H}^{(0)}(s)$$

over a homology class  $\gamma$  in the homological Milnor fibration has the asymptotic behavior as  $t \to 0$ 

$$\int_{\gamma} s[\omega] = t^{n-p+\alpha} t^N \omega_{\gamma}(s) + \cdots, \quad \alpha \in (-1,0], \quad \omega_{\gamma}(s) \in \mathbb{C}.$$
(A.20)

Fix a frame  $\mathcal B$  of locally constant homology classes for the homological Milnor fibration. Denote  $\check\gamma$  to be the linear dual of  $\gamma \in \mathcal B$  and

<span id="page-30-1"></span>
$$\zeta[\omega] := \sum_{\gamma \in \mathcal{B}} \omega_{\gamma}(s) \cdot \check{\gamma}. \tag{A.21}$$

The leading part of  $[\omega]$  in  $\operatorname{gr}_V^{n-p+\alpha}\mathcal{H}^{(0)}(s)$  gives rise to a class in  $\operatorname{gr}_F^pC_\alpha(s)$  via the map  $\partial_t^{n-p}$  in (A.17), and thus the class  $\zeta[\omega]$  in  $F^pH^n(X(s)_\infty)_\lambda$  under the further isomorphism  $\psi(s)$  in (A.16). We call  $\zeta[\omega]$  the leading part of the geometric section  $s[\omega]$ . The information of Hodge filtration is conveniently encoded in the spectrum of values  $\beta=n-p+\alpha$  for the singularity.

Since the monodromy operator T is defined over  $\mathbb{R}$ , the real structure on  $H^n(X(s)_{\infty})$  maps  $H^n(X(s)_{\infty})_{\lambda}$  to  $H^n(X(s)_{\infty})_{\bar{\lambda}}$  in (A.16) and can hence mix the spaces  $C_{\alpha}(s)$  with different values of  $\alpha$ . The polarization, the N operator and the Hodge filtration  $F^{\bullet}$  are all compatible with the eigenspace decomposition.

The embedding (A.15) of the Brieskorn lattice therefore contains crucial information of the mixed Hodge structure on the vanishing cohomology. The period mapping that we use in this work is defined using this embedding.

# <span id="page-31-0"></span>B Elliptic modular forms in Calabi-Yau sector of Fermat quartic

We study elliptic modular forms that appear in the  $D_0$  sector of the Fermat quartic.

Under the Poincaré residue map (2.8), the local system  $D_0$  corresponds to the Hodge bundle  $H^2_T(Q,\mathbb{C})$  of the Dwork pencil, where  $H^2_T(Q,\mathbb{C})$  stands for the transcendental part that is the orthogonal to the Neron-Severi lattice under the intersection pairing on  $H^2(Q,\mathbb{Z})$ . The differential operator  $\mathcal{D}_{\text{quartic}}$  in (2.40) then corresponds to the Picard-Fuchs operator for the Dwork family which is a lattice polarized family of K3 surfaces. It turns out that this polarization lattice is  $E_8^{\oplus 2} \oplus U \oplus \langle -4 \rangle$ , where U stands for the rank-2 hyperbolic lattice with signature (1,1). The transcendental lattice is then  $H^2_T(Q,\mathbb{Z}) \cong U \oplus \langle 4 \rangle$ . See [Dol96, Dol13] for details.

### Symmetric square structure and relation to elliptic modular forms

From [Dol96] (see also [Dol13]) one sees that

<span id="page-31-2"></span>
$$H_T^2(Q,\mathbb{C}) \cong \operatorname{Sym}^{\otimes 2} H^1(E,\mathbb{C}),$$
 (B.1)

where *E* is a certain universal elliptic curve family with level structure. To be more precise, the family *E* is the one over the modular curve  $\Gamma_0(2)\backslash \mathcal{H}$  whose Picard-Fuchs operator is given by

<span id="page-31-1"></span>
$$\mathcal{D}_{\text{elliptic}} := \theta_t (\theta_t - \frac{1}{2}) - t(\theta_t + \frac{1}{4})^2, \quad \theta_t = t \frac{\partial}{\partial t}, \tag{B.2}$$

where t is certain Hauptmodul on  $\Gamma_0(2)\backslash \mathcal{H}$ . It is chosen such that the Fricke involution  $W_2: \tau \mapsto -1/(2\tau)$  on  $\mathcal{H}$  induces

$$W_2: t \mapsto \frac{t}{t-1}. \tag{B.3}$$

Solutions to (B.2) are vector-valued elliptic modular forms for  $\Gamma_0(2)$ . See [Mai09, Zho16] for details. The symmetric square structure in (B.1) can also be seen concretely [LY94, LY96a, LY96b] as follows.

• First, by the Clausen identities [EMOT81][Section 4.3], the differential operator (2.40)

<span id="page-31-4"></span>
$$\mathcal{D}_{\text{quartic}} := \theta_b(\theta_b - \frac{1}{4})(\theta_b - \frac{2}{4}) - b(\theta_b + \frac{1}{4})^3, \tag{B.4}$$

is the symmetric square of

<span id="page-31-3"></span>
$$\mathcal{D}_{\text{triangular}} := \theta_b(\theta_b - \frac{1}{4}) - b(\theta_b + \frac{1}{8})^2. \tag{B.5}$$

Consider instead of (B.5) the following operator, which is related to (B.5) by a twist by  $b^{\frac{1}{8}}$  and has unipotent monodromy at  $b = \infty$ ,

<span id="page-32-0"></span>
$$b^{\frac{1}{8}} \circ \mathcal{D}_{\text{triangular}} \circ b^{-\frac{1}{8}} := (\theta_b - \frac{1}{8})(\theta_b - \frac{3}{8}) - b\theta_b^2.$$
 (B.6)

For the differential operator (B.6), uniformization using Schwarzian [EMOT81] equips [Mai09, Dol96, Dol13]  $\mathcal M$  with an orbifold structure

$$\Gamma_0(2)^+ \setminus \mathcal{H}^* - \{0,1,\infty\} \cong \mathcal{M}$$
,

where  $\Gamma_0(2)^+$  is the extension of the modular group  $\Gamma_0(2)$  by the Fricke involution  $W_2$ . The modular orbifold  $T_{4,2,\infty} = \Gamma_0(2)^+ \setminus \mathcal{H}$  has signature  $4,2,\infty$  at  $b=0,1,\infty$  respectively. In particular, up to the twist by  $b^{\frac{1}{8}}$ , solutions to (B.5) and thus to (B.4) are automorphic forms for the group  $\Gamma_0(2)^+$ .

• The relation between solutions to (B.4) and elliptic modular forms for  $\Gamma_0(2)$  is then established by connecting solutions to (B.5) and those to (B.2). This is achieved by making use of following quadratic relation for Gauss hypergeometric series [EMOT81][page 112]

<span id="page-32-1"></span>
$$_{2}F_{1}(\alpha,\beta;2\beta;t) = (1-t)^{-\frac{1}{2}\alpha} {}_{2}F_{1}(\frac{1}{2}\alpha,\beta-\frac{1}{2}\alpha;\beta+\frac{1}{2};\frac{t^{2}}{4t-4}).$$
 (B.7)

To be more precise, identify the  $\Gamma_0(2)^+$ -invariant b with the  $W_2$ -invariant function on  $\Gamma_0(2)\setminus\mathcal{H}$  as

<span id="page-32-4"></span>
$$b = \frac{t^2}{4t - 4} : \Gamma_0(2) \backslash \mathcal{H} \to \Gamma_0(2)^+ \backslash \mathcal{H}. \tag{B.8}$$

Then the two solutions to (B.5) given by

$$_{2}F_{1}(\frac{1}{8},\frac{1}{8};\frac{3}{4};b), \quad b^{\frac{1}{4}}_{2}F_{1}(\frac{3}{8},\frac{3}{8};\frac{5}{4};b),$$

correspond via (B.7) exactly to the  $(1-t)^{\frac{1}{8}}$ -multiple of those to (B.2) given by

$$_{2}F_{1}(\frac{1}{4},\frac{1}{4};\frac{1}{2};t), \quad t^{\frac{1}{2}}_{2}F_{1}(\frac{3}{4},\frac{3}{4};\frac{3}{2};t).$$

• It follows that solutions to (B.4) are automorphic forms for  $\Gamma_{4,2,\infty} \cong \Gamma_0(2)^+$  up to a twist by  $b^{\frac{1}{8}}$  and are vector-valued elliptic modular forms for  $\Gamma(2)$  up to a further twist by  $(1-t)^{\frac{1}{8}}$ .

Either the Hodge-theoretic origin (B.1) or the concrete calculation on hypergeometric functions tells that sections of  $F^3D_0 \cong F^3\operatorname{gr}_W^4H$  are elliptic modular forms of weight two.

# Integral presentation of monodromy group from geometry

Similar to the Fermat cubic case discussed in Section 2.4, using the relation to the Picard-Fuchs equation (B.2) for the corresponding elliptic curve family, one can obtain an integral representation for the monodromy group of (B.4) up to twist and conjugacy. The details are given as follows. In parallel to (B.6), consider the twist of (B.2) given by

<span id="page-32-2"></span>
$$t^{\frac{1}{4}} \circ \mathcal{D}_{\text{elliptic}} \circ t^{-\frac{1}{4}} = (\theta_t - \frac{1}{4})(\theta_t - \frac{3}{4}) - t\theta_t^2.$$
 (B.9)

The latter has unipotent monodromy at  $t = 1, \infty$ . Following [EMOT81], bases of solutions to (B.9) and (B.6) are given by

<span id="page-32-3"></span>
$$u_1 = {}_{2}F_1(\frac{1}{4}, \frac{3}{4}; 1; t^{-1}), \quad u_2 = {}_{2}F_1(\frac{1}{4}, \frac{3}{4}; 1; 1 - t^{-1}).$$
 (B.10)

and

<span id="page-33-1"></span>
$$v_1 = {}_2F_1(\frac{1}{8}, \frac{3}{8}; 1; b^{-1}), \quad v_2 = {}_2F_1(\frac{1}{8}, \frac{3}{8}; \frac{1}{2}; 1 - b^{-1}),$$
 (B.11)

respectively. We also introduce a third solution to (B.6) given by

<span id="page-33-2"></span>
$$v_6 = (1 - b^{-1})^{\frac{1}{2}} {}_2F_1(\frac{7}{8}, \frac{5}{8}; \frac{3}{2}; 1 - b^{-1}).$$
 (B.12)

Identities among analytic continuations of hypergeometric series [EMOT81][page 65] give

$$v_1 = c_1 v_2 + c_2 v_6, \quad c_1 = \frac{\Gamma(\frac{1}{2})}{\Gamma(\frac{5}{8})\Gamma(\frac{7}{8})}, \quad c_2 = \frac{\Gamma(-\frac{1}{2})}{\Gamma(\frac{1}{8})\Gamma(\frac{3}{8})}.$$
 (B.13)

<span id="page-33-0"></span>For readers' sake, we list solutions to various differential equations in Table 7.

Table 7: Solutions to various differential equations.

|           | $t^{rac{1}{4}} \circ \mathcal{D}_{	ext{elliptic}} \circ t^{-rac{1}{4}}$ | $b^{rac{1}{8}} \circ \mathcal{D}_{	ext{triangular}} \circ b^{-rac{1}{8}}$ | $b^{\frac{1}{4}} \circ \mathcal{D}_{	ext{quartic}} \circ b^{-\frac{1}{4}}$ |
|-----------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------|----------------------------------------------------------------------------|
|           | (B.9)                                                                     | (B.6)                                                                       | (B.16)                                                                     |
| solutions | $u_1, u_2$                                                                | $v_1, v_2, v_6$                                                             | _                                                                          |
|           | (B.10)                                                                    | (B.11), (B.12)                                                              |                                                                            |
|           |                                                                           | $e_1, e_2$                                                                  | $e_1^2$ , $e_1e_2$ , $-2e_2^2$                                             |
|           |                                                                           | (B.14)                                                                      | (B.17)                                                                     |

Computations with the aid of modular forms [Mai09] tell that for the elliptic curve family with the Picard-Fuchs operator given by (B.9) one has

$$au = \frac{\kappa_E u_2}{u_1}$$
,  $\kappa_E = \frac{i}{\sqrt{2}}$ .

and the monodromy group for (B.9) with respect to the basis  $(u_1, \kappa u_2)$  is given by

$$T_{0,E} = \begin{pmatrix} -1 & -1 \\ 2 & 1 \end{pmatrix}$$
 ,  $T_{1,E} = \begin{pmatrix} 1 & 0 \\ -2 & 1 \end{pmatrix}$  ,  $T_{\infty,E} = \begin{pmatrix} 1 & 1 \\ 0 & 1 \end{pmatrix}$  ,  $T_{0,E}T_{1,E}T_{\infty,E} = 1$ .

Here the subscript "E" stands for elliptic curve family.

Consider now a new fundamental basis of solutions to  $b^{\frac{1}{8}} \circ \mathcal{D}_{\text{triangular}} \circ b^{-\frac{1}{8}}$  in (B.6)

<span id="page-33-3"></span>
$$e = (e_1, e_2) := (v_1, -\kappa_E v_1 + \kappa v_2) = (c_1 v_2 + c_2 v_6, \kappa_E (c_1 v_2 - c_2 v_6)), \tag{B.14}$$

with  $\kappa = -\frac{1}{2\pi i} \frac{\Gamma(\frac{1}{8})\Gamma(\frac{3}{8})}{\Gamma(\frac{1}{2})} = 2c_1\kappa_E$ . The following Schwarzian has the asymptotic behavior [EMOT81] near  $b = \infty$ 

$$s(0, \frac{1}{4}, \frac{1}{2}; b^{-1}) := \frac{\kappa v_2}{v_1} = \frac{1}{2\pi i} \log(\frac{b^{-1}}{4^4}) + \frac{i}{\sqrt{2}} (1 + \cdots).$$

Hence in the basis e the monodromy for (B.6) around  $b = \infty$  is

$$T_{\infty, \text{triangular}} = \begin{pmatrix} 1 & 1 \\ 0 & 1 \end{pmatrix}$$
.

In fact, near  $b = \infty$ , by lifting to the  $t = \infty$  branch of (B.8), one has

$$(e_1, e_2) = (u_1, \kappa_E u_2).$$

The other branch around t=1 is related to this one by the Fricke involution  $W_2$  that acts by  $t^{-1} \mapsto 1 - t^{-1}$  and exchanges  $u_1, u_2$ . Around b=1, the local monodromy in the basis  $(v_2, v_6)$  is clearly given by the diagonal matrix diag(1, -1). It follows that the monodromies in the basis e in (B.14) are given by

$$T_{1,\text{triangular}} = \begin{pmatrix} 0 & \frac{i}{\sqrt{2}} \\ \frac{\sqrt{2}}{i} & 0 \end{pmatrix}, \quad T_{0,\text{triangular}} = (T_{1,\text{triangular}} T_{\infty,\text{triangular}})^{-1} = \begin{pmatrix} -\frac{\sqrt{2}}{i} & \frac{i}{\sqrt{2}} \\ \frac{\sqrt{2}}{i} & 0 \end{pmatrix}.$$

According to [Dol96, Dol13], the transcendental lattice  $H_T^2(Q,\mathbb{Z})\cong U\oplus \langle 4\rangle$  has the Gram matrix given by

$$G = \begin{pmatrix} 0 & 0 & 1 \\ 0 & 4 & 0 \\ 1 & 0 & 0 \end{pmatrix} . \tag{B.15}$$

The presentation of the monodromy action on the transcendental lattice should be integral and preserve the Gram matrix *G*, which we now check. The relation between the quartic K3 in consideration and the product of two isogeneous elliptic curves from the family *E* above leads to a basis for the corresponding differential operator

<span id="page-34-2"></span>
$$b^{\frac{1}{4}} \circ \mathcal{D}_{\text{quartic}} \circ b^{-\frac{1}{4}} = \operatorname{Sym}^{\otimes 2} \left( b^{\frac{1}{8}} \circ \mathcal{D}_{\text{triangular}} \circ b^{-\frac{1}{8}} \right) = (\theta_b - \frac{1}{4})(\theta_b - \frac{2}{4})(\theta_b - \frac{3}{4}) - b\theta_b^3$$
 (B.16)

given by [Dol96, Dol13] (cf. [NS95, Hat13])

<span id="page-34-3"></span>
$$(e_1^2, e_1e_2, -2e_2^2) = (v_1^2, \kappa v_1v_2 - \kappa_E v_1^2, -2\kappa^2 v_2^2 + 4\kappa\kappa_E v_1v_2 + v_1^2).$$
 (B.17)

Note that in the  $t=\infty$  branch that covers  $b=\infty$ , this basis is lifted to  $(e_1^2,e_1e_2,-2e_2^2)=(u_1^2,\kappa_Eu_1u_2,u_2^2)$  and in particular the lift of the normalized period there satisfies

<span id="page-34-1"></span>
$$s_0 := \frac{e_1 e_2}{e_1^2} = \frac{\kappa_E u_2}{u_1^2} = \tau. \tag{B.18}$$

Then in this basis the monodromies for (B.16) around  $0, 1, \infty$  are given by

$$T_{0,K3} = \begin{pmatrix} -2 & -1 & 1 \\ 4 & 1 & 0 \\ 1 & 0 & 0 \end{pmatrix}, \qquad T_{1,K3} = \begin{pmatrix} 0 & 0 & 1 \\ 0 & 1 & 0 \\ 1 & 0 & 0 \end{pmatrix}, \quad T_{\infty,K3} = \begin{pmatrix} 1 & 1 & -2 \\ 0 & 1 & -4 \\ 0 & 0 & 1 \end{pmatrix}. \tag{B.19}$$

Since  $TGT^t = G$ , they indeed preserve the Gram matrix as desired. Moreover, they have orders  $4,2,\infty$  respectively, as should be the case since (B.16) corresponds to a representation of  $\Gamma_{4,2,\infty} \cong \Gamma_0(2)^+$ .

Another way to obtain integral presentations for the monodromy group is to follow the computations on the hypergeometric group [BH89]. The matrix presentation of the invariant Hermitian form however is not given by the Gram matrix G for the transcendental lattice  $H_T^2(Q, \mathbb{Z}) \cong U \oplus \langle 4 \rangle$  shown above.

# References

<span id="page-34-0"></span>[AGZV85] V. I. Arnold, S. M. Gusein-Zade, and A. N. Varchenko, Singularities of differentiable maps: Volume I: The classification of critical points caustics and wave fronts, Birkhäuser Boston, Boston, MA, 1985.

- <span id="page-35-1"></span>[AGZV88] , *Singularities of differentiable maps: Volume II: monodromy and asymptotic integrals*, Birkhäuser Boston, Boston, MA, 1988.
- <span id="page-35-18"></span>[Ali17] M. Alim, *Algebraic Structure of tt\* Equations for Calabi-Yau Sigma Models*., Commun. Math. Phys. 353, 963–1009 (2017).
- <span id="page-35-12"></span>[AL07] M. Alim and J. D. Länge, *Polynomial Structure of the (Open) Topological String Partition Function*, JHEP **0710** (2007), 045.
- <span id="page-35-15"></span>[ALR07] A. Adem, J. Leida, Y. Ruan, *Orbifolds and stringy topology.* , Cambridge Tracts in Mathematics, 171. Cambridge University Press, Cambridge, 2007.
- <span id="page-35-14"></span>[ASYZ14] M. Alim, E. Scheidegger, S.-T. Yau, and J. Zhou, *Special polynomial rings, quasi modular forms and duality of topological strings*, Adv. Theor. Math. Phys. **18** (2014), no. 2, 401–467.
- <span id="page-35-17"></span>[Aud97] M. Audin, *An introduction to Frobenius manifolds, moduli spaces of stable maps and quantum cohomology*, 1997. hal-00129568.
- <span id="page-35-11"></span>[AZ04] G. Almkvist and W. Zudilin, *Differential equations, mirror maps and zeta values*, In: N. Yui, S. T. Yau, and J. D. Lewis, editors, Mirror symmetry V, volume 38, pages 481–515. Amer. Math. Soc., 2007.
- <span id="page-35-5"></span>[Bat94] V. V. Batyrev, *Dual polyhedra and mirror symmetry for Calabi-Yau hypersurfaces in toric varieties*, J. Alg. Geom. **3** (1994), 493–545.
- <span id="page-35-4"></span>[BCOV94] M. Bershadsky, S. Cecotti, H. Ooguri, and C. Vafa, *Kodaira-Spencer theory of gravity and exact results for quantum string amplitudes*, Commun. Math. Phys. **165** (1994), 311–428.
- <span id="page-35-7"></span>[BH89] F. Beukers and G. Heckman, *Monodromy for the hypergeometric function <sup>n</sup>Fn*−1, Invent. Math. **95** (1989), no. 2, 325–354.
- <span id="page-35-16"></span>[CCIT19] T. Coates, A. Corti, H. Iritani, and H.-H. Tseng, *Some applications of the mirror theorem for toric stacks*, Adv. Theor. Math. Phys. **23** (2019), no. 3, 767–802.
- <span id="page-35-9"></span>[CDF+93a] A. Ceresole, R. D'Auria, S. Ferrara, W. Lerche, and J. Louis, *Picard-Fuchs equations and special geometry*, Int. J. Mod. Phys. **A8** (1993), 79–114.
- <span id="page-35-10"></span>[CDF+93b] A. Ceresole, R. D'Auria, S. Ferrara, W. Lerche, J. Louis, and T. Regge, *Picard-Fuchs equations, special geometry and target space duality*, Contribution to second volume of 'Essays on Mirror Manifolds'. In Mirror symmetry II, pp.281–353.
- <span id="page-35-0"></span>[CdLOGP91] P. Candelas, Xenia C. de La Ossa, P. S. Green, and L. Parkes, *A Pair of Calabi-Yau manifolds as an exactly soluble superconformal theory*, Nucl. Phys. **B359** (1991), 21–74.
- <span id="page-35-8"></span>[Cec91] S. Cecotti, *N = 2 Landau-Ginzburg vs. Calabi-Yau sigma-models: Non-perturbative aspects*, Int. J. Mod. Phys. A Vol. 06, No. 10, 1749–1813 (1991).
- <span id="page-35-2"></span>[CF17] L. Candelori and C. Franc, *Vector-valued modular forms and the modular orbifold of elliptic curves*, Int. J. Number Theory **13** (2017), no. 01, 39–63.
- <span id="page-35-3"></span>[CF19] , *Vector bundles and modular forms for Fuchsian groups of genus zero*, Commun. Number Theory Phys. **13** (2019), no. 03, 487–528.
- <span id="page-35-6"></span>[CGL18] H.-L. Chang, S. Guo, and J. Li, *Polynomial structure of Gromov-Witten potential of quintic* 3*-folds via NMSP*, Ann. Math., Vol. 194, No. 3 (2021), pp. 585–645.
- <span id="page-35-13"></span>[CGLZ20] H.-L. Chang, S. Guo, W.-P. Li, and J. Zhou, *Genus-one Gromov-Witten invariants of quintic three–folds via MSP localization*, Int. Math. Res. Not., Volume 2020, Issue 19 (2020), 6421–6462.

- <span id="page-36-4"></span>[CK99] D. A. Cox and S. Katz, *Mirror symmetry and algebraic geometry*, Mathematical Surveys and Monographs, vol. 68, Amer. Math. Soc., Providence, RI, 1999.
- <span id="page-36-3"></span>[CL12] K. Costello and S. Li, *Quantum BCOV theory on Calabi-Yau manifolds and the higher genus B-model*. [arXiv:1201.4501](http://arxiv.org/abs/1201.4501) [math.QA].
- <span id="page-36-5"></span>[CLS90] P. Candelas, M. Lynker, and R. Schimmrigk, *Calabi-Yau manifolds in weighted* **P**<sup>4</sup> , Nucl. Phys. B **341** (1990), no. 2, 383–402.
- <span id="page-36-11"></span>[CR04] W. Chen and Y. Ruan, *A new cohomology theory of orbifold*, Comm. Math. Phys. 248 (2004), no. 1, 1–31.
- <span id="page-36-2"></span>[CR10] A. Chiodo and Y. Ruan, *Landau–Ginzburg/Calabi–Yau correspondence for quintic threefolds via symplectic transformations*, Invent. Math. **182** (2010), no. 1, 117–165.
- <span id="page-36-15"></span>[CV91] S. Cecotti and C. Vafa, *Topological–anti-topological fusion*, Nucl. Phys. B **367** (1991), no. 2, 359–461.
- <span id="page-36-16"></span>[Dol96] I. V. Dolgachev, *Mirror symmetry for lattice polarized K3 surfaces*, J. Math. Sci. **81** (1996), no. 3, 2599–2630.
- <span id="page-36-7"></span>[Dol97] I. V. Dolgachev, *Lectures on modular forms. Fall 1997/98*. [http://www.math.lsa.umich.edu/](http://www.math.lsa.umich.edu/~idolga/ModularBook.pdf)∼idolga/ModularBook.pdf
- <span id="page-36-17"></span>[Dol13] I. V. Dolgachev, *Lectures on moduli and mirror symmetry of K3 surfaces*. [http://www.math.lsa.umich.edu/](http://www.math.lsa.umich.edu/~idolga/Hamburg14.pdf)∼idolga/Hamburg14.pdf
- <span id="page-36-14"></span>[Dub96] B. Dubrovin, *Geometry of 2d topological field theories*, In: Francaviglia M., Greco S. (eds) Integrable Systems and Quantum Groups. Lecture Notes in Mathematics, vol 1620, 120–348. Springer, Berlin, Heidelberg, 1996.
- <span id="page-36-9"></span>[DZ01] B. Dubrovin and Y. Zhang, *Normal forms of hierarchies of integrable PDEs, Frobenius manifolds and Gromov-Witten invariants*, [arXiv:math/0108160](http://arxiv.org/abs/math/0108160) [math.DG].
- <span id="page-36-6"></span>[EMOT81] A. Erdélyi, W. Magnus, F. Oberhettinger, and F. G. Tricomi, *Higher transcendental functions. Vol. I*, Robert E. Krieger Publishing Co. Inc., Melbourne, Fla., 1981, Based on notes left by Harry Bateman, With a preface by Mina Rees, With a foreword by E. C. Watson, Reprint of the 1953 original.
- <span id="page-36-8"></span>[Fre99] D. S. Freed, *Special Kahler manifolds*, Commun. Math. Phys. **203** (1999), no. 1, 31–52.
- <span id="page-36-10"></span>[FSZ10] C. Faber, S. Shadrin, and D. Zvonkine, *Tautological relations and the r-spin Witten conjecture*, Ann. Sci. Éc. Norm. Supér. (4) 43 (2010), no. 4, 621–658.
- <span id="page-36-12"></span>[Giv95a] A. B. Givental, *Homological geometry I: Projective hypersurfaces*, Sel. Math. New Ser. 1 (1995), No. 2, 325–345.
- <span id="page-36-13"></span>[Giv95b] , *Homological geometry and mirror symmetry*, Proceedings of the International Congress of Mathematicians, 1994, Zürich, Birkhäuser, 1995, 472–480.
- <span id="page-36-0"></span>[Giv96] , *Equivariant Gromov-Witten invariants*, Int. Math. Res. Not. **1996** (1996), no. 13, 613–663.
- <span id="page-36-1"></span>[Giv98] , *A mirror theorem for toric complete intersections*, In: Kashiwara M., Matsuo A., Saito K., Satake I. (eds) Topological Field Theory, Primitive Forms and Related Topics. Progr. Math., vol 160. Birkhäuser, Boston, MA.

- <span id="page-37-9"></span>[GJR18] S. Guo, F. Janda, and Y. Ruan, *Structure of higher genus Gromov-Witten invariants of quintic 3-folds*, [arXiv:1812.11908](http://arxiv.org/abs/1812.11908) [math.AG].
- <span id="page-37-13"></span>[GKMW07] T. W. Grimm, A. Klemm, M. Marino, and M. Weiss, *Direct Integration of the Topological String*, JHEP **0708** (2007), 058.
- <span id="page-37-7"></span>[GP90] B. R. Greene and M. R. Plesser, *Duality in Calabi-Yau moduli space*, Nucl. Phys. **338** (1990), 15–37.
- <span id="page-37-6"></span>[Gro03] M. Gross, *Calabi-Yau manifolds and mirror symmetry*, Calabi-Yau manifolds and related geometries (Nordfjordeid, 2001), Universitext, Springer, Berlin, 2003, pp. 69–159.
- <span id="page-37-12"></span>[Gro11] , *Tropical geometry and mirror symmetry*, CBMS Regional Conference Series in Mathematics, Amer. Math. Soc., Providence, R.I., 2011.
- <span id="page-37-18"></span>[Hat13] H. Hartmann, *Period- and mirror-maps for the quartic K3*, Manuscripta Math. 141, 391– 422 (2013).
- <span id="page-37-15"></span>[Her02] C. Hertling, *Frobenius manifolds and moduli spaces for singularities*, Cambridge Tracts in Mathematics, Cambridge University Press, Cambridge, 2002.
- <span id="page-37-14"></span>[Hos08] S. Hosono, *BCOV ring and holomorphic anomaly equation*. Advanced Studies in Pure Mathematics 59, 2010, New Developments in Algebraic Geometry, Integrable Systems and Mirror Symmetry (Kyoto, 2008) pp. 79–110.
- <span id="page-37-3"></span>[IMRS21] H. Iritani, T. Milanov, Y. Ruan, and Y. Shen, *Gromov-Witten theory of quotients of Fermat Calabi-Yau varieties*, Mem. Amer. Math. Soc. 269 (2021), no. 1310, v+92 pp.
- <span id="page-37-11"></span>[Kul98] V. Kulikov, *Mixed Hodge structures and singularities*, Cambridge Tracts in Mathematics (132), Cambridge University Press, 1998.
- <span id="page-37-4"></span>[KZ95] M. Kaneko and D. Zagier, *A generalized Jacobi theta function and quasimodular forms*, The moduli space of curves (Texel Island, 1994), Progr. Math., vol. 129, Birkhäuser Boston, Boston, MA, 1995, pp. 165–172.
- <span id="page-37-5"></span>[Li11] S. Li, *Calabi-Yau geometry and higher genus mirror symmetry*, Ph.D. thesis, Harvard University, 2011.
- <span id="page-37-0"></span>[LLY97] B. H. Lian, K. Liu, and S.-T. Yau, *Mirror principle I*, Asian J. Math. **1** (1997), no. 4, 729–763.
- <span id="page-37-1"></span>[LLY98] , *Mirror principle II*, Asian J. Math. **3** (1998), no. 1, 109–146.
- <span id="page-37-8"></span>[LP18] H. Lho and R. Pandharipande, *Holomorphic anomaly equations for the formal quintic*, Peking Math. J., volume 2, pages 1–40 (2019).
- <span id="page-37-2"></span>[LS14] Y.-P. Lee and M. Shoemaker, *A mirror theorem for the mirror quintic*, Geom. Topol. 18 (3) 1437–1483, 2014.
- <span id="page-37-10"></span>[LSZ20] J. Li, Y. Shen, and J. Zhou, *Higher genus FJRW invariants of a Fermat cubic*, [arXiv:2001.00343](http://arxiv.org/abs/2001.00343) [math.AG].
- <span id="page-37-16"></span>[LY94] B. H. Lian and S.-T. Yau, *Mirror maps, modular relations and hypergeometric series I*, XIth International Congress of Mathematical Physics (Paris, 1994), Int. Press, Cambridge, MA, 1995, pp. 163–184.
- <span id="page-37-17"></span>[LY96a] , *Mirror maps, modular relations and hypergeometric series II*, Nucl. Phys. B, Proc. Suppl. 46 (1996), 248–262.

- <span id="page-38-8"></span>[LY96b] \_\_\_\_\_, *Arithmetic properties of mirror map and quantum coupling*, Commun. Math. Phys. **176** (1996), 163–192.
- <span id="page-38-5"></span>[Mai09] R. S. Maier, *On rationally parametrized modular equations*, J. Ramanujan Math. Soc. **24** (2009), no. 1, 1–73.
- <span id="page-38-6"></span>[Mai11] \_\_\_\_\_\_, Nonlinear differential equations satisfied by certain classical modular forms, Manuscripta Math. 134, 1–42 (2011).
- <span id="page-38-3"></span>[Mal74] B. Malgrange, *Integrales asymptotiques et monodromie*, Ann. Sci. École Norm. Sup. (4) 7 (1974), 405–430 (1975).
- <span id="page-38-14"></span>[Man99a] Y. I. Manin, Frobenius manifolds, quantum cohomology, and moduli spaces, Colloquium Publications Volume 47, Amer. Math. Soc., Providence, RI, 1999.
- <span id="page-38-15"></span>[Man99b] \_\_\_\_\_, *Three constructions of Frobenius manifolds: A comparative study*, Asian J. Math. **3** (1999), no. 1, 179–220.
- <span id="page-38-2"></span>[Mat98] A. Matsuo, *Summary of the theory of primitive forms*, Topological field theory, primitive forms and related topics (Kyoto, 1996), 337–363, Progr. Math., vol. 160, Birkhäuser Boston, Boston, MA, 1998.
- <span id="page-38-9"></span>[Mov11] H. Movasati, Eisenstein type series for Calabi–Yau varieties, Nucl. Phys. B 847 (2011), issue 2, 460–484.
- <span id="page-38-17"></span>[NS95] M. Nagura and K. Sugiyama, Mirror symmetry of the K3 surface, Int. J. Mod. Phys. A 10 (1995), no. 02, 233–252.
- <span id="page-38-13"></span>[NY98] M. Noumi and Y. Yamada, *Notes on the flat structures associated with simple and simply elliptic singularities*, Integrable systems and algebraic geometry (Kobe/Kyoto, 1997), World Sci. Publ., River Edge, NJ, 1998, pp. 373–383.
- <span id="page-38-4"></span>[Pha85] F. Pham, La descente des cols par les onglets de lefschetz, avec vues sur gauss-manin, Systèmes différentiels et singularités, Astérisque, no. 130, Société mathématique de France, 1985 (fr).
- <span id="page-38-0"></span>[Ran77] R. A. Rankin, *Modular forms and functions*, Cambridge University Press, Cambridge, 1977.
- <span id="page-38-7"></span>[RZZ20] Y. Ruan, Y. Zhang, and J. Zhou, Genus two quasi-Siegel modular forms and Gromov-Witten theory of toric Calabi-Yau threefolds, arXiv:1911.07204 [math.AG].
- <span id="page-38-16"></span>[Sab08] C. Sabbah, *Isomonodromic deformations and Frobenius manifolds: An introduction*, Universitext, Springer London, London, 2008.
- <span id="page-38-1"></span>[Sai83] K. Saito, Period mapping associated to a primitive form, Publ. Res. Inst. Math. Sci. 19 (1983), no. 3, 1231–1264.
- <span id="page-38-10"></span>[Sat86] I. Satake, *The flat coordinates of universal unfoldings of*  $\tilde{E}_6$  *and*  $\tilde{E}_7$ , Bull. College Sci. Univ. Ryukyus No. 42 (1986), 5–10.
- <span id="page-38-11"></span>[Sat93] \_\_\_\_\_, Flat structure for the simple elliptic singularity of type  $\tilde{E}_6$  and Jacobi form, Proc. Japan Acad. Ser. A Math. Sci. 69 (1993), no. 7, 247–251.
- <span id="page-38-12"></span>[Sat98] \_\_\_\_\_, Flat structure and the prepotential for the elliptic root system of type  $D_4^{(1,1)}$ , Topological field theory, primitive forms and related topics (Kyoto, 1996), 427–452, Progr. Math., 160, Birkhäuser Boston, Boston, MA, 1998.

- <span id="page-39-15"></span>[Sat10] , *Frobenius manifolds for elliptic root systems*, Osaka J. Math. 47 (2010), no. 1, 301–330.
- <span id="page-39-1"></span>[Sch73] W. Schmid, *Variation of Hodge structure: the singularities of the period mapping*, Invent. Math. **22** (1973), 211–319.
- <span id="page-39-0"></span>[Sch74] B. Schoeneberg, *Elliptic modular functions: an introduction*, Springer-Verlag, New York-Heidelberg, 1974, Translated from the German by J. R. Smart and E. A. Schwandt, Die Grundlehren der mathematischen Wissenschaften, Band 203.
- <span id="page-39-2"></span>[SS14] H. Saber and A. Sebbar, *Vector-valued automorphic forms and vector bundles*, [arXiv:1312.2992](http://arxiv.org/abs/1312.2992) [math.NT].
- <span id="page-39-8"></span>[ST08] K. Saito and A. Takahashi, *From primitive forms to Frobenius manifolds*. In From Hodge theory to integrability and TQFT tt\*-geometry, 31–48, Proc. Sympos. Pure Math., 78, Amer. Math. Soc., Providence, RI, 2008.
- <span id="page-39-16"></span>[ST11] I. Satake and A. Takahashi, *Gromov-Witten invariants for mirror orbifolds of simple elliptic singularities*, Ann. Inst. Fourier, Grenoble 61, 7 (2011) 2885–2907.
- <span id="page-39-7"></span>[Ste77] J. Steenbrink, *Mixed Hodge Structure on the Vanishing Cohomology* , In: Holm, P., ed. Real and complex singularities (1977), 525–563.
- <span id="page-39-11"></span>[Str90] A. Strominger, *Special geometry*, Commun. Math. Phys. **133** (1990), no. 1, 163–180.
- <span id="page-39-17"></span>[Str12] Ian A. B. Strachan, *Simple Elliptic Singularities: A Note on their G-function*, Asian J. Math. **16** (2012), no. 3, 409–426.
- <span id="page-39-6"></span>[SZ18] Y. Shen and J. Zhou, *LG/CY correspondence for elliptic orbifold curves via modularity*, J. Differ. Geom. **109** (2018), no. 2, 291–336.
- <span id="page-39-14"></span>[Tel12] C. Teleman, *The structure of 2d semi-simple field theories.*, Invent. Math. **188** (2012), no. 3, 525–588.
- <span id="page-39-9"></span>[Urb14] E. Urban, *Nearly overconvergent modular forms*, In: Bouganis T., Venjakob O. (eds) Iwasawa Theory 2012, 401–441. Contributions in Mathematical and Computational Sciences, vol 7. Springer, Berlin, Heidelberg.
- <span id="page-39-3"></span>[Wit93] E. Witten, *Quantum background independence in string theory*. [arXiv:hep-th/9306122.](http://arxiv.org/abs/hep-th/9306122)
- <span id="page-39-4"></span>[YY04] S. Yamaguchi and S.-T. Yau, *Topological string partition functions as polynomials*, JHEP **0407** (2004), 047.
- <span id="page-39-13"></span>[Zho14] J. Zhou, *Arithmetic Properties of Moduli Spaces and Topological String Partition Functions of Some Calabi-Yau Threefolds*, Ph. D. Thesis, Harvard University, 2014.
- <span id="page-39-10"></span>[Zho16] , *Mirror symmetry for plane cubics revisited*. In: Uniformization, Riemann-Hilbert Correspondence, Calabi-Yau Manifolds and Picard-Fuchs Equations. Adv. Lect. Math. (ALM), 42 (2018), 593–619.
- <span id="page-39-5"></span>[Zin09] A. Zinger, *The reduced genus 1 Gromov-Witten invariants of Calabi-Yau hypersurfaces*, J. Amer. Math. Soc. **22** (2009), no. 3, 691–737.
- <span id="page-39-12"></span>[ZZ08] D. Zagier and A. Zinger, *Some properties of hypergeometric series associated with mirror symmetry*, In Modular forms and string duality. June 3–8, 2006, Proceedings of a workshop, Banff, Canada (2008), 163–177.

Yau Mathematical Sciences Center, Tsinghua University, Beijing 100084, P. R. China

Email: dingxin@mail.tsinghua.edu.cn

Yau Mathematical Sciences Center, Tsinghua University, Beijing 100084, P. R. China

Email: jzhou2018@mail.tsinghua.edu.cn