# On sums of Betti numbers of affine varieties

# Dingxin Zhang\*

#### Abstract

We show that if V is a subvariety of the affine N-space defined by polynomials of degree at most d, then the sum of its  $\ell$ -adic Betti numbers does not exceed  $2(N+1)^{2N+1}(d+1)^N$ . This answers a question of N. Katz.

### 1 Introduction

Let V be a finite type, separated scheme over an algebraically closed field k. Katz [Kat01, Theorem 5] proved the existence of a constant M(V/k) such that for any prime  $\ell$  invertible in k, the following inequality holds:

$$B(V)_{(\ell)} := \sum_{i} \dim \mathbf{H}^{i}(V; \mathbf{Q}_{\ell}) \leqslant M(V/k),$$

where  $H^i(V; \mathbf{Q}_{\ell})$  denotes the  $\ell$ -adic cohomology. When k has positive characteristic, it is conjectured that  $B(V)_{(\ell)}$  is independent of  $\ell$ . Katz's theorem shows that  $B(V)_{(\ell)}$  possesses a uniform upper bound as  $\ell$  varies, thus can be interpreted as a weak form of the conjectured independence.

Katz's proof relies on selecting an alteration of V, which leaves the constant M(V/k) implicit. He then posed the following question [Kat01, p. 36], paraphrased here:

**Question** (Katz). If  $V \subset \mathbf{A}_k^N$  is defined by polynomials of degree at most d, can an explicit upper bound for M(V/k) be provided in terms of d and the number of the defining polynomials?

If V is smooth and connected, Katz [Kat01, Corollary 2] proved that

$$B(V)_{(\ell)} \leqslant 3 \times 2^r \times (r+1+rd)^N,$$
 (K)

Thus, the main challenge lies in addressing singular varieties.

When  $k = \mathbb{C}$ , Milnor [Mil64, Corollary 1] proved

$$\sum_{i} \dim \mathcal{H}^{i}(V^{\mathrm{an}}; \mathbf{Q}) \leqslant d(2d-1)^{2N-1}$$
(MOT)

for the singular cohomology of the complex analytic space  $V^{\rm an}$  associated with V. Similar bounds were established by Oleinik [Ole51] and Thom [Tho65]. Since the dimensions of the  $\ell$ -adic cohomology of V and the singular cohomology of  $V^{\rm an}$  coincide, this resolves the question for  $k=\mathbb{C}$ . However, Milnor's proof relies on Morse theory, which does not extend to positive characteristic.

In this brief note, we answer Katz's question with the following theorems:

<sup>\*</sup>Partially supported by the National Key Research and Development Program of China (No. 2022YFA1007100).

<span id="page-0-0"></span><sup>&</sup>lt;sup>1</sup>Katz did not focus on obtaining the most optimal bound, making this inequality somewhat crude. His method actually yields a sharper bound:  $2^r(rd+r+2)^N$ .

<span id="page-1-1"></span>**Theorem 1.** For any algebraically closed field k, any closed subvariety V of  $\mathbf{A}_k^N$  cut out by  $r \ge 1$  polynomials of degree at most d, and any prime  $\ell$  invertible in k, we have

$$B(V)_{(\ell)} \leqslant 2r^r (rd+3)^N.$$

<span id="page-1-0"></span>If we do not want to specify the number r of defining polynomials of V, we have the following:

**Theorem 2.** For any algebraically closed field k, any closed subvariety V of  $\mathbf{A}_k^N$  defined by polynomials of degree at most d, and any prime  $\ell$  invertible in k, we have

$$B(V)_{(\ell)} \le 2(N+1)^{2N+1}(d+1)^N$$
.

In fact, Theorem 2 is a consequence of Theorem 1. We may assume  $N \ge 2$  since when N = 1 we trivially have  $B(V)_{\ell} \le d$ . By a classical theorem of Kronecker (cf. [Per42] or [CRW22, §3]), V can always be set-theoretically cut out by at most N+1 nonzero polynomials of degree  $\le d$ . Hence, by taking r = N+1 in Theorem 1, we get

$$B(V)_{(\ell)} \le 2 \times [(N+1)d+3]^N \times (N+1)^{N+1} \le 2 \times (N+1)^{2N+1} \times (d+1)^N.$$

Remarks. (i) When  $k = \mathbb{C}$ , Theorem 2 sharpens the classical Milnor–Oleinik–Thom upper bound (MOT) if d is large compared to  $N^2$ .

(ii) Consider the number

$$B(N,d) := \sup \left\{ B(V)_{(\ell)} : \begin{array}{l} V = \{ f_1 = \dots = f_r = 0 \} \subset \mathbf{A}_k^N \\ \text{for some } r, \text{ with } \deg f_i \leqslant d \end{array} \right\}.$$

If we treat N as fixed and d as a variable, then Theorem 2 implies that  $B(N,d) \ll_N d^N$ . On the other hand, we have  $B(N,d) \geqslant d^N$ . Indeed, if V is a transverse intersection of N sufficiently general degree d polynomials in N variables, then V is a finite set comprised of  $d^N$  points, and  $B(V)_{(\ell)} = d^N$ . Thus B(N,d) and  $d^N$  have the same asymptotic order as  $d \to \infty$ :  $B(N,d) \approx_N d^N$ .

(iii) Let R be any commutative ring, and let  $\mathcal{Z}$  be a finite type separated scheme over R. For any geometric point  $x \colon \operatorname{Spec} k \to \operatorname{Spec} R$ , Katz showed that

$$B(\mathcal{Z} \otimes_{R,x} k) \leqslant M(\mathcal{Z} \otimes_{R,x} k/k).$$

However, these upper bounds may depend on the specific geometric point x. In contrast, if

$$\mathcal{Z} = \operatorname{Spec} R[x_1, \dots, x_N]/(f_1, \dots, f_r),$$

with deg  $f_i \leq d$ , then the bounds established in Theorems 1 and 2 are given by explicit constants that apply uniformly to every geometric point x of Spec R. Thus, these bounds have the advantage of being uniform in k.

(iv) Although we have established that  $d^N$  is the correct asymptotic order of B(N,d) as  $d \to \infty$ , the coefficient  $2(N+1)^{2N+1}$  of  $d^N$  in Theorem 2 is far from optimal. There should be considerable room for improvement.

<span id="page-1-2"></span>For complete intersections, a slightly sharper bound can be established.

**Theorem 3.** Let k be an algebraically closed field. Suppose  $V \subset \mathbf{A}_k^N$  is the common zero locus of r polynomials of degree at most d. If V has at worst local complete intersection singularities, e.g., if  $\dim V = N - r$ , then

$$B(V)_{(\ell)} \leqslant 2^r (rd + r + 2)^N.$$

# 2 The proofs

In the following, we fix an algebraically closed field k and a prime ℓ invertible in k. All schemes are defined over k. We shall write B(V ) instead of B(V )(ℓ) .

Suppose B(N, r, d) is a positive integer satisfying the following property.

If V is a closed subscheme of A<sup>N</sup> defined by r polynomials f1, . . . , f<sup>r</sup> with deg f<sup>i</sup> 6 d, then B(V ) 6 B(N, r, d).

It is not immediately evident that a finite B(N, r, d) even exists. This does not follow directly from Deligne's theorem on the constructibility of the direct image of constructible sheaves, since the non-proper direct image does not generally commute with base change. Some additional argument is indeed required, though it is not difficult. We will not dwell on this point, as it will follow from the argument presented below.

Suppose E(N, r, d) is a positive integer satisfying the following property:

If V is a subvariety of A<sup>N</sup> defined by nonzero polynomials f1, . . . , f<sup>r</sup> with deg f<sup>i</sup> 6 d, then |χ(V ; Qℓ)| 6 E(N, r, d).

Here χ(V ; Qℓ) is the Euler characteristic χ(V ; Qℓ) = P i (−1)<sup>i</sup> dim H<sup>i</sup> (V ; Qℓ). By [\[Lau81\]](#page-6-4), the Euler characteristic equals the compactly supported Euler characteristic:

$$\chi(V; \mathbf{Q}_{\ell}) = \sum_{i} (-1)^{i} \dim \mathbf{H}_{c}^{i}(V; \mathbf{Q}_{\ell}).$$

Hence, by [\[AS88,](#page-5-2) Theorem 5.27] (and the comment at the beginning of [\[Kat01,](#page-5-0) p. 30]) we can take

$$E(N, r, d) = 2^r \times (r + 1 + rd)^N. \tag{AS}$$

### Upper bound for local complete intersections: Katz's method

Let f1, . . . , f<sup>r</sup> ∈ k[x1, . . . , x<sup>N</sup> ] be polynomials of degree 6 d. Consider the affine scheme

$$V := \operatorname{Spec} k[x_1, \dots, x_N]/(f_1, \dots, f_r).$$

We assume that V is a set-theoretic local complete intersection, meaning there is a closed subscheme W of A<sup>N</sup> that is a local complete intersection, with Wred = V red. This is the case, for example, if dim V = N − r, or if V is smooth. We seek an explicit upper bound for B(V ).

<span id="page-2-0"></span>Proposition 1. In the above situation, we have

$$B(V) \le E(N, r, d) + 2 \sum_{i=1}^{\dim V} E(N - i, r, d).$$

In particular, we can take B(N, 1, d) to be E(N, 1, d) + 2P<sup>N</sup> <sup>i</sup>=1 E(i, 1, d).

The proof of Proposition [1](#page-2-0) closely follows Katz's proof of inequality [\(K\)](#page-3-0). Instead of using the standard weak Lefschetz theorem for smooth varieties as Katz did, we apply the following weak Lefschetz theorem for perverse sheaves, due to Deligne.

Theorem (Deligne [\[Kat93,](#page-5-3) Corollary A.5]). Let π : X → P<sup>N</sup> be a quasi-finite morphism to a projective space. Let P be a perverse sheaf on X. Then for a sufficiently general hyperplane A, the restriction morphism

$$\mathrm{H}^i(X;\mathcal{P}) \to \mathrm{H}^i(\pi^{-1}A;\mathcal{P}|_{\pi^{-1}A})$$

is injective if i = −1, and bijective if i < −1.

We now use Deligne's theorem and Katz's original Euler characteristic argument [\[Kat01,](#page-5-0) p. 33] to prove Proposition [1.](#page-2-0)

Proof of Proposition [1.](#page-2-0) We proceed by induction on the dimension of V . In the base case where dim V = 0, the result is trivial. Now assume dim V > 0. Since V is a set-theoretic local complete intersection, the shifted constant sheaf Qℓ,V [dim V ] is a perverse sheaf on V , see e.g., [\[KW01,](#page-5-4) Lemma III.6.5]. Now apply Deligne's theorem by

- taking X = V ,
- letting π be the composition of the inclusion map V ֒→ A<sup>N</sup> and the standard embedding A<sup>N</sup> ֒→ P<sup>N</sup> , and
- setting P = Qℓ,V [dim V ].

Deligne's theorem then implies that for a general affine hyperplane A ⊂ A<sup>N</sup> , the restriction map

<span id="page-3-0"></span>
$$\mathrm{H}^i(V; \mathbf{Q}_\ell) \to \mathrm{H}^i(A \cap V; \mathbf{Q}_\ell)$$

is injective when i = dim V − 1, and bijective if i < dim V − 1. Ergo,

$$\dim \mathbf{H}^{\dim V}(V; \mathbf{Q}_{\ell})$$

$$= (-1)^{\dim V} \chi(V; \mathbf{Q}_{\ell}) + \dim \mathbf{H}^{\dim V - 1}(V; \mathbf{Q}_{\ell}) - \dim \mathbf{H}^{\dim V - 2}(V; \mathbf{Q}_{\ell}) + \cdots$$

$$\leq (-1)^{\dim V} \chi(V; \mathbf{Q}_{\ell}) + \dim \mathbf{H}^{\dim V - 1}(A \cap V; \mathbf{Q}_{\ell}) - \dim \mathbf{H}^{\dim V - 2}(A \cap V; \mathbf{Q}_{\ell}) + \cdots$$

$$= (-1)^{\dim V} \chi(V; \mathbf{Q}_{\ell}) + (-1)^{\dim V - 1} \chi(A \cap V; \mathbf{Q}_{\ell})$$

$$\leq E(N, r, d) + E(N - 1, r, d). \tag{1}$$

Here we have used the Artin vanishing theorem, which asserts that for a finite type affine scheme V over k, H<sup>i</sup> (V ; Qℓ) = 0 unless 0 6 i 6 dim V .

Note that A ∩ V is a closed subscheme of the (N − 1)-dimensional affine space A, defined by polynomials of degree 6 d. Since A is generic and V is a set-theoretic local complete intersection, it follows that A ∩ V also remains a set-theoretic local complete intersection. By inductive hypothesis, we have

<span id="page-3-1"></span>
$$B(A \cap V) \leqslant E(N-1, r, d) + 2 \sum_{i=1}^{\dim V - 1} E(N-1-i, r, d).$$
 (2)

Therefore,

$$\begin{split} B(V) &\leqslant \dim \mathbf{H}^{\dim V}(V; \mathbf{Q}_{\ell}) + B(A \cap V) \\ &\leqslant E(N, r, d) + E(N - 1, r, d) \\ &+ E(N - 1, r, d) + 2 \sum_{1 \leq i \leq \dim V - 1} E(N - 1 - i, r, d) \\ &= E(N, r, d) + 2 \sum_{i = 1}^{\dim V} E(N - i, r, d). \end{split} \tag{By (1) and (2)}$$

This completes the proof.

Proof of Theorem [3.](#page-1-2) We take E(N, r, d) as in [\(AS\)](#page-3-0). When N = dim V , we have V = A<sup>N</sup> , and the result is trivial. When N = 1, and dim V = 0, the result is equally trivial since we have  $B(V) \leq d$ . Assume now  $N \geq 2$ , and dim V < N. Then by Proposition 1, we have

$$B(V) \leq 2^r \left[ (rd + r + 1)^N + 2 \sum_{i=1}^{\dim V} (rd + r + 1)^{N-i} \right]$$
  
$$\leq 2^r (rd + r + 2)^N$$
 (3)

<span id="page-4-2"></span>

thanks to the binomial theorem. This completes the proof.

# Upper bounds in general

Now suppose we have inductively constructed B(N,1,d), B(N,2,d), ..., up to B(N,r-1,d), and these numbers are all finite. We proceed to deal with varieties defined by r equations.

Suppose  $f_1, \ldots, f_r \in k[x_1, \ldots, x_N]$ , deg  $f_i \leq d$ . Define:

- $F_i := \{f_i = 0\},\$
- $W := \bigcup F_i$ ,
- for each  $J \subset \{1, \ldots, r\}, F_J := \bigcap_{i \in J} F_i$
- $V := \{f_1 = \dots = f_r = 0\} = F_{\{1,\dots,r\}}.$

<span id="page-4-1"></span>We will bound B(V).

**Proposition 2.** In the situation above, we have

$$B(V) \le B(N, 1, rd) + \sum_{i=1}^{r-1} {r \choose i} B(N, i, d).$$

In particular, we can take B(N,r,d) to be  $B(N,1,rd) + \sum_{i=1}^{r-1} {r \choose i} B(N,i,d)$ .

*Proof.* There is a Mayer-Vietoris spectral sequence for the finite closed covering  $\bigcup_{i=1}^r F_i$  of W:

$$E_1^{p,q} = \bigoplus_{\text{Card } J=p+1} \mathrm{H}^q(F_J; \mathbf{Q}_\ell) \Rightarrow \mathrm{H}^{p+q}(W; \mathbf{Q}_\ell).$$

We have  $E_1^{r-1,q} = H^q(V; \mathbf{Q}_\ell)$ . Because  $E_\infty^{r-1,q}$  is a subquotient of  $H^{q+r-1}(W; \mathbf{Q}_\ell)$ , we have

<span id="page-4-0"></span>
$$\sum_{q} \dim E_{\infty}^{r-1,q} \leqslant B(W).$$

For each q and each i,  $E_i^{r-1,q}$  appears at the rightmost column of the  $E_i$ -page of the spectral sequence, i.e.,  $E_i^{p,q}=0$  for  $p\geqslant r$ . Therefore, we have  $E_{i+1}^{r-1,q}=E_i^{r-1,q}/d_i(E_i^{r-1-i,q+i-1})$ , where  $d_i\colon E_i^{p,q}\to E_i^{p+i,q-i+1}$  is the differential of the spectral sequence. It follows that

$$B(W) = \sum_{p,q} \dim E_{\infty}^{p,q} \geqslant \sum_{q} \dim E_{\infty}^{r-1,q}$$

$$= \sum_{q} \dim E_{1}^{r-1,q} - \sum_{q} \sum_{i=1}^{r-1} \dim d_{i} (E_{i}^{r-1-i,q+i-1})$$

$$\geqslant B(V) - \sum_{i=1}^{r-1} \sum_{q} \dim E_{1}^{r-1-i,q+i-1}$$
(4)

The last inequality holds because for any  $i \ge 1$ ,  $E_i^{p,q}$  is a subquotient of  $E_1^{p,q}$ .

For each  $p \ge 0$ ,  $E_1^{p,q}$  is a direct sum of  $H^q(F_J)$  with  $\operatorname{Card} J = p+1$ . There are  $\binom{r}{p+1}$  such summands. Since  $F_J \subset \mathbf{A}^N$  is cut out by p+1 polynomials of degree  $\le d$ , we have

$$\sum_{q} \dim E_{1}^{p,q} = \sum_{q} \bigoplus_{\text{Card } J=p+1} H^{p}(F_{J}; \mathbf{Q}_{\ell})$$

$$\leq {r \choose p+1} B(N, p+1, d).$$

Hence,

<span id="page-5-5"></span>
$$\sum_{i=1}^{r-1} \sum_{q} \dim E_1^{r-1-i,q+i-1} \leqslant \sum_{i=1}^{r-1} \binom{r}{r-i} B(N,r-i,d). \tag{5}$$

Since W is a hypersurface cut out by  $f_1 \cdots f_r$ , a polynomial of degree  $\leq rd$ , we conclude from Proposition 1 that  $B(W) \leq B(N, 1, rd)$ . Thus Equations (4) and (5) imply that

$$B(V) \le B(N, 1, rd) + \sum_{i=1}^{r-1} {r \choose i} B(N, i, d).$$

This completes the proof.

*Proof of Theorem 1.* In view of Proposition 1 and Proposition 2, if the numbers B(N, r, d) are defined inductively as

- $B(N,1,d) = E(N,d) + 2\sum_{i=1}^{N-1} E(i,d),$
- $B(N, r, d) = B(N, 1, rd) + \sum_{i=1}^{r-1} {r \choose i} B(N, i, d),$

where E(N,d) is given by (AS), then  $B(V) \leq B(N,r,d)$ . Let us prove  $B(N,r,d) \leq 2r^r(rd+3)^N$  by induction. For the base case, we invoke Equation (3) with r=1. When r>1, we have

$$B(N,r,d) \leq 2(rd+3)^N + \sum_{i=1}^{r-1} \binom{r}{i} \times 2i^i (id+3)^N \qquad \text{(inductive hypothesis)}$$

$$\leq 2(rd+3)^N \left[ 1 + \sum_{i=1}^{r-1} \binom{r}{i} (r-1)^i \right] \qquad \text{(since } i \leq r-1 < r)$$

$$\leq 2 \times (rd+3)^N \times r^r \qquad \text{(binomial theorem)}.$$

This completes the proof of Theorem 1.

Acknowledgment. To be added.

# References

- <span id="page-5-2"></span>[AS88] Alan Adolphson and Steven Sperber, On the degree of the L-function associated with an exponential sum. Compositio Math. 68 (1988), no.2, 125–159.
- <span id="page-5-1"></span>[CRW22] Qi Cheng, J. Maurice Rojas, and Daqing Wan, Computing zeta functions of large polynomial systems over finite fields. J. Complexity 73 (2022), Paper No. 101681, 10 pp.
- <span id="page-5-3"></span>[Kat93] Nicholas M. Katz, Affine cohomological transforms, perversity, and monodromy. J. Amer. Math. Soc. 6 (1993), no.1, 149–222.
- <span id="page-5-0"></span>[Kat01] Nicholas M. Katz, Sums of Betti numbers in arbitrary characteristic. Dedicated to Professor Chao Ko on the occasion of his 90th birthday. Finite Fields Appl. 7 (2001), no.1, 29–44.
- <span id="page-5-4"></span>[KW01] Reinhardt Kiehl and Rainer Weissauer, Weil conjectures, perverse sheaves and l-adic Fourier transform, vol. 42, Ergebnisse der Mathematik und ihrer Grenzgebiete. 3. Folge. Springer-Verlag, Berlin, 2001, pp. xii+375.

- <span id="page-6-4"></span>[Lau81] G´erard Laumon, Comparaison de caract´eristiques d'Euler-Poincar´e en cohomologie l-adique. C. R. Acad. Sci. Paris S´er. I Math. 292 (1981), no.3, 209–212.
- <span id="page-6-0"></span>[Mil64] John Milnor, On the Betti numbers of real varieties. Proc. Amer. Math. Soc. 15 (1964), 275–280.
- <span id="page-6-1"></span>[Ole51] O. A. Ole˘ınik, Estimates of the Betti numbers of real algebraic hypersurfaces. Mat. Sbornik N.S. 28/70 (1951), 635–640.
- <span id="page-6-3"></span>[Per42] Oskar Perron, Beweis und Versch¨arfung eines Satzes von Kronecker. Math. Ann. 118 (1942), 441–448.
- <span id="page-6-2"></span>[Tho65] Ren´e Thom, Sur l'homologie des vari´et´es alg´ebriques r´eelles. Differential and Combinatorial Topology (A Symposium in Honor of Marston Morse), pp. 255–265 Princeton University Press, Princeton, NJ, 1965.

C629 Shuangqing Complex Building A, Tsinghua University, Beijing, China.

Email: zhangdingxin13@gmail.com