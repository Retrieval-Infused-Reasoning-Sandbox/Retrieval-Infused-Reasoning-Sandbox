# BETTI NUMBER BOUNDS FOR VARIETIES AND EXPONENTIAL SUMS

### DAQING WAN AND DINGXIN ZHANG

Abstract. Using basic properties of perverse sheaves, we give new upper bounds for compactly supported Betti numbers for arbitrary affine varieties in A <sup>n</sup> defined by r polynomial equations of degrees at most d. As arithmetic applications, new total degree bounds are obtained for zeta functions of varieties and L-functions of exponential sums over finite fields, improving the classical results of Bombieri, Katz, and Adolphson–Sperber. In the complete intersection case, our total Betti number bound is asymptotically optimal as a function in d. In general, it remains an open problem to find an asymptotically optimal bound as a function in d.

## 1. Introduction

In this paper, we address the problem of bounding compactly supported Betti numbers for certain families of algebraic varieties and exponential sums. While this is a fundamental question in topology, algebraic geometry, arithmetic geometry and their algorithmic aspects, our motivation is strengthened by the fact that such bounds can lead to improved estimates in analytic number theory over global function fields. Our focus is therefore on obtaining quantitative and explicit estimates that are as sharp as possible.

For "nondegenerate" objects, Betti numbers can often be computed exactly. However, degeneration significantly complicates precise general control. We develop a framework (see §[3\)](#page-12-0) for obtaining estimates and demonstrate that, under suitable hypotheses, the Betti numbers undergo minimal deterioration during degeneration.

Regarding Betti numbers of affine varieties, we improve upon previous results by Katz [\[Kat01\]](#page-42-0). In the most general case, we achieve the correct asymptotic order [\(1.1.2\)](#page-1-0). For the complete intersection case, we obtain asymptotically optimal results [\(1.2.2\)](#page-3-0).

For exponential sums on affine varieties, we extend and refine the results of [\[AS87,](#page-41-0) [Bom78\]](#page-41-1) by lifting their L-function bounds to the cohomological level [\(1.3.6,](#page-6-0) [1.3.7,](#page-6-1) [1.3.8\)](#page-6-2). Our bounds are asymptotically optimal in the complete intersection case. Moreover, our method reveals an upper semicontinuity property for Newton polygons associated with exponential sums [\(1.4.1\)](#page-9-0).

While our approach is applicable in many other contexts, we focus on theorems about Betti numbers of varieties and exponential sums, as these are the objects most frequently encountered in algorithmic arithmetic geometry and analytic number theory over function fields. Another approach for obtaining Betti bounds based on ramification theory has been recently developed by Haoyu Hu and J.-B. Teyssier [\[HT25\]](#page-42-1). Their bounds are expressed in terms of the logarithmic conductors of the sheaf at infinity. We believe readers will find our concrete explicit results and the general theorems of Hu and Teyssier to be mutually enriching.

A detailed summary of our results follows.

1.1. Compactly supported Betti numbers of affine varieties. Let k be an algebraically closed field, and let ℓ be a prime that is different from the characteristic of k. For an algebraic variety V over k, we define

$$B_c(V,\ell) := \sum_1 \dim \mathrm{H}^i_c(V; \overline{\mathbb{Q}}_\ell),$$

where  $\mathrm{H}^i_c(V;\overline{\mathbb{Q}}_\ell)$  denotes the  $i^{\mathrm{th}}$  compactly supported  $\ell$ -adic cohomology group. Note that  $B_c(V,\ell)$  depends solely on the reduced structure of V. The number  $B_c(V,\ell)$  might depend on the choice of the prime  $\ell$ . The conjectural independence of  $B_c(V,\ell)$  on  $\ell$  remains wide open in general for singular or non-proper varieties. In many applications, an explicit good upper bound for  $B_c(V,\ell)$  is already very useful. For instance, a good upper bound for  $B_c(V,\ell)$  gives a good upper bound for the total degree of the zeta function of an algebraic variety over a finite field. By Grothendieck's  $\ell$ -adic trace formula and Deligne's theorem on the Weil conjectures, the quality of the total degree bound is well known to be one of the main factors for point counting estimates. A good total degree bound is also crucial in estimating the complexity of effective algorithms in computing zeta functions in arithmetic geometry, see [LW08, Wan08, Har15].

Let n, r, d be positive integers. The primary purpose of this paper, also our original motivation, is to establish an asymptotically optimal upper bound for  $B_c(V, \ell)$  as V ranges over all Zariski closed subsets of the affine space  $\mathbb{A}^n_k$  defined by r polynomial equations, each of degree at most d, over all algebraically closed field k of characteristic different from  $\ell$ . To report our progress, it is convenient to introduce the quantity

$$B_c(n,r;d) := \sup_{\ell \neq \operatorname{char}(k)} \left\{ B_c(V,\ell) : \begin{array}{l} V = \operatorname{Spec} k[x_1,\ldots,x_n]/(f_1,\ldots,f_r) \\ \deg f_i \leqslant d, \ 1 \leqslant i \leqslant r. \end{array} \right\},$$

where k runs over all algebraically closed fields and  $\ell$  runs over all prime numbers different from the characteristic of k. The number  $B_c(n, r; d)$  clearly depends only on the three parameters n, r, d. By adding redundant equations, if necessary, one sees that the number  $B_c(n, r; d)$  is increasing in r. Namely,

$$(1.1.1) B_c(n,1;d) \leq B_c(n,2;d) \leq \cdots \leq B_c(n,r;d) \leq B_c(n,r+1;d) \leq \cdots.$$

Furthermore, by Kronecker's reduction [Per42], which holds for any infinite field, this sequence in r stabilizes once r reaches n + 1, that is,

<span id="page-1-3"></span>
$$B_c(n, n+1; d) = B_c(n, n+2; d) = B_c(n, n+3; d) = \cdots$$

Thus, without loss of generality, we can always assume that  $r \leq n+1$ .

Our main purpose of this paper is to study the growth of the number  $B_c(n, r; d)$  as a function of d. Our first theorem states:

<span id="page-1-0"></span>**Theorem 1.1.2** (See §5.5). With the above notation, we have

$$(d-1)^n \leqslant B_c(n,r;d) \leqslant 3^r \times \binom{n+r-1}{r-1} \times (2d+1)^n.$$

Previously, the best known bound is due to Katz [Kat01], who showed that

<span id="page-1-1"></span>(K) 
$$B_c(n,r;d) \leqslant 2^r \times 3 \times 2 \times (rd+3)^{n+1}.$$

If we treat n and r as fixed while considering d as a variable, (K) yields the asymptotic behavior  $B_c(n,r;d) \ll_{n,r} d^{n+1}$ . In contrast, Theorem 1.1.2 implies  $B_c(n,r;d) \ll_{n,r} d^n$ , thus improving Katz's estimate (K) by one order. The lower bound  $(d-1)^n \leqslant B_c(n,r;d)$  indicates that there is no further scope for refinement as far as enhancing the order is concerned. As a consequence, we obtain

<span id="page-1-2"></span>Corollary 1.1.3. For any positive integers n, r, d, we have

$$B_c(n,r;d) \simeq_{n,r} d^n$$
.

**Remarks.** (a) Theorem 1.1.2 also immediately implies a "projective Betti bound" for projective varieties in  $\mathbb{P}^n$ . See Corollary 5.5.8.

- (b) The Betti bounds lead to improved total degree bounds for zeta functions, which can be used to speed up algorithms for computing zeta functions of varieties over finite fields and arithmetic schemes, see [LW08, Wan08, Har15]. Theorem 1.1.2 also leads to a new total degree bound for the L-function of a linear representation attached to the Galois group of a finite Galois covering of varieties over finite fields. This new bound improves previous total degree bounds in [BS88, FW03]. One simply replaces the Bombieri bound [Bom78] and the Katz bound [Kat01] by the stronger bound in Theorem 1.1.2 throughout the proofs of [BS88, FW03].
- (c) In some applications, the number of defining polynomials for a variety can be quite large, or even exponentially large, see for instance [CRW22] for an application in theoretical computer science, where one needs to quickly decide if two varieties over finite fields have the same zeta function. In such cases, the Kronecker reduction may not apply for small finite fields, but the following corollary is still useful to bound the total degree of the zeta function.

<span id="page-2-0"></span>**Corollary 1.1.4.** Suppose  $V \subset \mathbb{A}^n_k$  is the zero locus of some polynomials of degree at most d. Then

$$B_c(V,\ell) \le 3^{n+1} \times {2n \choose n} \times (2d+1)^n < 3(24d+12)^n.$$

**Proof.** By Kronecker [Per42], V can be set-theoretically cut out by at most n+1 polynomials of degree at most d. We then apply Theorem 1.1.2 with r = n+1.

(d) Katz's original method only yields a non-optimal bound  $B_c(n,r;d) \ll_{n,r} d^{n+1}$  due to a technical limitation: to apply the weak Lefschetz theorem, he needed to reduce to a nonsingular affine variety. Thus he has to pass from, e.g., a hypersurface in the affine n-space to its complement, which is smooth, then applies the Rabinowitsch trick, which converts this hypersurface complement in dimension n to a nonsingular hypersurface in dimension n+1, thereby increasing the order by one.

In addition to the proof in the main text, we present a shorter, more elementary alternative proof of Corollary 1.1.3 in §5.6. This proof improves upon Katz's method in two ways: we apply Deligne's weak Lefschetz theorem for perverse sheaves (cf. Lemma 2.3.3) to avoid the Rabinowitsch trick, and we utilize an algebraic lemma from our work on Frobenius colevels [WZ22, WZ23] for additional refinements. While these improvements yield a better bound than Katz's original approach, and gives the correct order, the implied constant generally remains weaker than that of Theorem 1.1.2 (see Theorem 5.6.7). However, this elementary approach may provide sharper estimates when specific information about dimension and minimal number of defining equations is available, which justifies its inclusion.

- (e) The sum  $B(V,\ell) := \sum \dim \mathrm{H}^i(V;\overline{\mathbb{Q}}_\ell)$  of the Betti numbers for  $\ell$ -adic cohomology with closed supports is more difficult to estimate than the sum of compactly supported ones, since  $B(V,\ell)$  has more complicated formal properties than  $B_c(V,\ell)$ . Tweaking the method of Katz by computing a spectral sequence backwards, the second author [Zha25] showed that if  $V \subset \mathbb{A}^n_k$  is the zero locus of polynomials  $f_1, \ldots, f_r$  with deg  $f_i \leq d$ , then  $B(V,\ell) \leq 2r^r(rd+3)^n$ .
- 1.2. Compactly supported Betti numbers of affine complete intersections. Having established that the correct order of  $B_c(n,r;d)$  is  $d^n$ , a natural question arises: is there an asymptotic formula for  $B_c(n,r;d)$  as  $d\to\infty$ ? Namely, is there a positive constant  $b_{n,r}$  such that

$$B_c(n, r; d) = b_{n,r}d^n + o_{n,r}(d^n)$$
?

If so, what is the leading constant  $b_{n,r}$ ? While the constant term  $3^r \times \binom{n+r-1}{r-1} \times 2^n$  from Theorem 1.1.2 is certainly not optimal, the correct constant remains unclear. If V is a sufficiently general complete intersection cut out by r polynomials of degree d, it can be shown

that  $B_c(V,\ell) = \binom{n-1}{r-1}d^n + O_{n,r}(d^{n-1})$  (see Lemma 4.2.2). In view of this, the best we could hope would be a positive answer to the following question.

**Question 1.2.1.** Let  $r \leq (n+1)/2$ . Is it true that

$$B_c(n, r; d) = \binom{n-1}{r-1} d^n + o_{n,r}(d^n)?$$

Note that the condition  $r \leq (n+1)/2$  cannot be dropped for the above question to have a positive answer. The reason is that the number  $B_c(n,r;d)$  is an increasing function in r. On the other hand, the binomial coefficient  $\binom{n-1}{r-1}$  is increasing in r only for  $1 \leq r \leq (n+1)/2$  and becomes decreasing in r for  $r \geq (n+1)/2$ . This shows that for the expected asymptotic formula to hold, it is necessary to have  $r \leq (n+1)/2$ . Alternatively, without the condition  $r \leq (n+1)/2$ , one can ask if

$$B_c(n,r;d) = \binom{n-1}{\min\{r-1, \lfloor \frac{n-1}{2} \rfloor\}} d^n + o_{n,r}(d^n)?$$

Instead of tackling the above question in general, we will focus on a class of subvarieties of  $\mathbb{A}^n$ : (set-theoretic) complete intersections. For  $r \leq n$ , we define

$$B_c^{\mathrm{ci}}(n,r;d) := \sup_{\ell \neq \mathrm{char}(k)} \left\{ B_c(V,\ell) : \begin{array}{l} V = \operatorname{Spec} k[x_1,\ldots,x_n]/(f_1,\ldots,f_r), \\ \deg f_i \leqslant d, \text{ and } \dim V = n-r \end{array} \right\},$$

where, again, k runs over all algebraically closed fields and  $\ell$  runs over all prime numbers different from the characteristic of k. Then  $B_c(n,1;d) = B_c^{ci}(n,1;d)$  and, for  $r \ge 1$ ,  $B_c(n,r;d) \ge B_c^{ci}(n,r;d)$ . Our second theorem provides an asymptotically optimal bound for  $B_c^{ci}(n,r;d)$  as  $d \to \infty$ .

<span id="page-3-0"></span>**Theorem 1.2.2** (= 4.2.4). Assuming  $r \leq n$ , we have

$$\binom{n-1}{r-1}(d-1)^n \leqslant B_c^{ci}(n,r;d) \leqslant \binom{n-1}{r-1}(d+1)^n.$$

The lower bound follows from an exact computation of  $B_c(V, \ell)$  (Lemma 4.2.2) for a sufficient general V. As a consequence, we deduce

Corollary 1.2.3. Assuming  $r \leqslant n$ , we have

$$B_c^{\text{ci}}(n,r;d) = \binom{n-1}{r-1} d^n + O_{n,r}(d^{n-1}).$$

**Remarks.** (a) As detailed in Theorem 4.2.1, our method provides estimates for the compactly supported Betti numbers in each individual cohomology degree. Theorem 1.2.2 follows as a straightforward consequence of these bounds. Moreover, these affine bounds naturally extend to projective set-theoretic complete intersections, as shown in Proposition 4.3.1.

(b) In Sawin's recent work [Saw20, Saw21] on function field analytic number theory in short interval, one key step is to estimate the total compact Betti number of affine complete intersections. Theorem 1.2.2, combined with Sawin's results, is thus useful in improving various function field short interval bounds in [Saw20, Saw21]. The improvement comes from replacing Katz's estimate for  $B_c(V, \ell)$  with our sharper bound in Theorem 1.2.2.

For instance, in [Saw21], one needs to estimate  $B_c(V,\ell)$  for the variety  $V \subset \mathbb{A}^n_{\mathbb{F}_q}$  defined by the first r elementary symmetric polynomials in n variables. This variety is a complete intersection in  $\mathbb{A}^n_{\mathbb{F}_q}$  with  $r=d\leqslant n$ . For this case, while Katz's general bound gives either  $2^d\times 6\times (d^2+3)^{n+1}$  or  $3(d+2)^{n+r}$  depending on which bound of Katz one uses, our complete intersection bound in Theorem 1.2.2 yields the better estimate  $\binom{n-1}{d-1}(d+1)^n\leqslant (2d+2)^n$ .

Similarly, in [Saw20], one needs to estimate the total compact Betti number of another more general affine variety

$$Z_{n,\sum_{i=1}^r d_i,\sum_{i=r+1}^{r+\tilde{r}}}/(S_{d_1}\times\cdots\times S_{d_{r+\tilde{r}}})\subset \mathbb{A}^{\sum_{i=1}^{r+\tilde{r}} d_i}$$

defined by n polynomial equations of degree at most  $\max(r, \tilde{r})$ . Precisely, this variety is the moduli space of tuples of monic univariate polynomials  $f_1(t), ..., f_{r+\tilde{r}}(t)$ , with  $f_i(t)$  of degree  $d_i$ , such that the leading n+1 coefficients of  $\prod_{i=1}^r f_i(t)$  and  $\prod_{i=r+1}^{r+\tilde{r}} f_i(t)$  agree. The equality of the leading coefficient is trivial, while the equality of the remaining n coefficients is a system of n polynomial equations of degrees  $\max(r,\tilde{r})$  in  $\sum_{i=1}^{r+\tilde{r}} d_i$  variables. One checks that this affine variety is also a complete intersection. While Sawin's original result uses Katz's bound, applying our Theorem 1.2.2 yields a sharper estimate. Specifically, the upper bound  $4(2 + \max(r,\tilde{r}))^{n+\sum_{i=1}^{r+\tilde{r}} d_i}$  from [Saw20, (2-10)] can be improved to

$$\binom{\sum_{i=1}^{r+\widetilde{r}} d_i - 1}{n-1} (\max(r, \widetilde{r}) + 2)^{\sum_{i=1}^{r+\widetilde{r}} d_i} < (2\max(r, \widetilde{r}) + 4)^{\sum_{i=1}^{r+\widetilde{r}} d_i}.$$

The improved Betti number bounds combined with Sawin's results lead to corresponding improvements in the error terms of various short interval estimates in [Saw20, Saw21]. For example, the constant factor  $3(k+2)^{2n-h}$  in [Saw21, Theorem 1.1] can be replaced by  $(2k+2)^n$ , and similarly the constant factor  $3(n+2)^{2n-h}$  in [Saw21, Theorem 1.2] can be replaced by  $(2n+2)^n$ .

(c) The proofs of Theorem 1.1.2 and Theorem 1.2.2 are quite different, yet both are related to the following specialization principle: when working with a family of perverse sheaves on an affine family of varieties, the dimension of the key cohomology factor decreases upon specialization. The precise statement is provided in Lemma 3.1 and, in mixed characteristics, in Variant 3.5.

Theorem 1.2.2 follows from the aforementioned principle and a Lefschetz-type argument. Specifically, the principle enables us to bound the "middle cohomology" by that of a sufficiently general V, which can be computed exactly. The Lefschetz-type theorem (Lemma 2.3.3) allows us to reduce higher cohomology to the middle cohomology of complete intersections in a smaller affine space, thereby enabling the use of induction.

However, this argument does not imply Theorem 1.1.2. While it provides a bound for  $\dim \mathcal{H}_c^{n-r}$  (which becomes irrelevant if r is too large), the limitations of the Lefschetz-type theorem prevent us from obtaining information about  $\dim \mathcal{H}_c^i$  when i lies between n-r and  $\dim V$ .

We will prove Theorem 1.1.2 by revisiting Adolphson–Sperber's total degree bounds for L-functions of toric exponential sums from the perspective of  $\ell$ -adic cohomology. Instead of relying on Dwork theory, we will use the specialization Lemma 3.1 as our primary tool. This approach allows us to improve their bounds purely through  $\ell$ -adic cohomology. In doing so, we also achieve a cohomological enhancement that leads directly to Theorem 1.1.2 via a toric reduction and a volume computation. Further details on exponential sums and our new bounds are discussed in §1.3 below.

<span id="page-4-0"></span>1.3. Compactly supported Betti numbers of exponential sums. Let q be a power of a prime p. Let U be an algebraic variety over  $\mathbb{F}_q$ , and let  $f: U \to \mathbb{A}^1_{\mathbb{F}_q}$  be a morphism. For each  $m \geq 1$ , the exponential sum in  $\mathbb{F}_{q^m}$  associated to f is

(1.3.1) 
$$S_m(f;\psi) = \sum_{x \in U(\mathbb{F}_{q^m})} \psi(\operatorname{Tr}_{\mathbb{F}_{q^m}/\mathbb{F}_p} f(x)),$$

where  $\psi \colon \mathbb{F}_p \to \mathbb{C}^*$  is a nontrivial additive character. In the sequel we shall fix one such nontrivial  $\psi$ , and we shall simply write  $S_m(f)$  instead of  $S_m(f;\psi)$ .

<span id="page-5-1"></span>Associated to these exponential sums is their L-function

(1.3.2) 
$$L_f(t) = \exp\left\{\sum_{m=1}^{\infty} S_m(f) \frac{t^m}{m}\right\}.$$

By a well-known theorem of Dwork and Grothendieck,  $L_f(t)$  is a rational function expressed as  $L_f(t) = P(t)/Q(t)$ , where  $P, Q \in 1 + t\mathbb{Z}[\zeta_p, t]$ . Here,  $\zeta_p$  is a primitive  $p^{\text{th}}$  root of unity. When P and Q are taken to be coprime, the sum  $\deg P + \deg Q$  is referred to as the *total degree* of the rational function  $L_f(t)$ .

In [AS87], Adolphson and Sperber proved an upper bound for the total degree of  $L_f(t)$  when U is an algebraic torus  $\mathbb{G}_{\mathrm{m}}^n$ , generalizing and refining previous results of Bombieri [Bom78]. Their bound is expressed in terms of a combinatorial invariant of f, called the *Newton polytope* of f with respect to  $\infty$ , denoted by  $\Delta_{\infty}(f)$  (see §5.4 for the definition). This is a convex polytope in  $\mathbb{R}^n$  containing the origin. Adolphson and Sperber [AS87, Theorem 1.8] proved that, among others, if dim  $\Delta_{\infty}(f) = n$ , then

<span id="page-5-0"></span>(AS) Total degree of 
$$L_f(t) \leq 2^n (1 + 2^{\frac{n+1}{n}})^n n! \operatorname{Vol}(\Delta_{\infty}(f))$$
.

We shall prove a cohomologically enhanced improvement of (AS), which yields

<span id="page-5-2"></span>Total degree of 
$$L_f(t) \leq 2^n n! \operatorname{Vol}(\Delta_{\infty}(f))$$
.

Just like the zeta function of a variety, the L-function (1.3.2) also has a cohomological interpretation. The additive character  $\psi$  determines an Artin-Schreier sheaf  $\mathcal{L}_{\psi}$  on  $\mathbb{A}^1_{\mathbb{F}_q}$  (see [Del77, Sommes trig.] for a more systematic introduction). The link between the Artin-Schreier sheaf and exponential sums is provided by the Grothendieck trace formula:

$$(1.3.3) S_m(f) = \sum_{i \in \mathbb{Z}} (-1)^i \operatorname{Tr}(F^m | \mathcal{H}_c^i(U_{\overline{\mathbb{F}}_q}; f^* \mathcal{L}_{\psi})),$$

where  $\overline{\mathbb{F}}_q$  is an algebraic closure of  $\mathbb{F}_q$ ,  $U_{\overline{\mathbb{F}}_q} = U \otimes_{\mathbb{F}_q} \overline{\mathbb{F}}_q$ , and  $F^m$  is the  $m^{\text{th}}$  iteration of the q-power Frobenius F. The multiplicative form of the trace formula (1.3.3) is

<span id="page-5-3"></span>(1.3.3') 
$$L_f(t) = \prod_{i \in \mathbb{Z}} \det(1 - t \cdot F | H_c^i(U_{\overline{\mathbb{F}}_q}; f^* \mathcal{L}_{\psi}))^{(-1)^{i-1}}.$$

The formulae (1.3.3) and (1.3.3') allow us to use the eigenvalues of  $F|\mathcal{H}_c^i(U_{\overline{\mathbb{F}}_q}; f^*\mathcal{L}_{\psi})$  to deduce properties of the exponential sums and their L-function. Contemplating that there might be cancellations of linear factors in (1.3.3'), we have

(1.3.4) Total degree of 
$$L_f(t) \leqslant \sum \dim H_c^i(U_{\overline{\mathbb{F}}_q}; f^*\mathcal{L}_{\psi}).$$

Thus, any upper bound of the compactly supported Betti sum will give an upper bound of the total degree of  $L_f(t)$ , but the converse is only true when

$$P_{\text{even}}(t) = \prod_{i \text{ even}} \det(1 - tF|\mathcal{H}_c^i(U_{\overline{\mathbb{F}_q}}; f^*\mathcal{L}_{\psi}))$$

and

$$P_{\text{odd}}(t) = \prod_{i \text{ odd}} \det(1 - tF | \mathcal{H}_c^i(U_{\overline{\mathbb{F}}_q}; f^* \mathcal{L}_{\psi}))$$

do not share common zeros. This latter condition holds when the Artin–Schreier cohomology spaces of f are pure, but should fail in general.

We shall provide an upper bound for the sum of compactly supported cohomology dimensions of  $f^*\mathcal{L}_{\psi}$ , expressed in terms of Minkowski mixed volumes of polytopes, recalled below.

<span id="page-6-4"></span>**Notation 1.3.5** (Minkowski mixed volume). For a monomial  $m(T_1, T_2, \dots, T_r) = T_1^{a_1} \cdots T_r^{a_r}$ , we set

$$m(\Delta_1, \dots, \Delta_r) = \begin{cases} 0 & \text{if } a_1 + \dots + a_r \neq n, \\ n! V(\Delta_1[a_1], \dots, \Delta_r[a_r]) & \text{if } a_1 + \dots + a_r = n. \end{cases}$$

Here  $V(\Delta_1[a_1], \ldots, \Delta_r[a_r])$  is the *mixed volume* of the convex polytopes  $\Delta_1, \ldots, \Delta_r$  in  $\mathbb{R}^n$  (with indicated repetitions). These numbers can be defined as the coefficients in the expansion of volume of Minkowski sums:

$$\operatorname{Vol}(\lambda_1 \Delta_1 + \dots + \lambda_r \Delta_r) = \sum_{\substack{i_1 + \dots + i_r = n \\ 0 \le i_1 \dots i_r \le n}} \frac{n!}{i_1! \dots i_r!} V(\Delta_1[i_1], \dots, \Delta_r[i_r]) \lambda_1^{i_1} \dots \lambda_r^{i_r}.$$

Thus, for an *n*-dimensional lattice polytope  $\Delta$  in  $\mathbb{R}^n$ , we have  $\Delta^n = n! \operatorname{Vol}(\Delta)$  is the usual normalized volume.

For any formal power series  $u(T_1, \ldots, T_r) \in \mathbb{Z}[T_1, \ldots, T_r], u = \sum b_w T_1^{w_1} \cdots T_r^{w_r}$ , we set  $u(\Delta_1, \ldots, \Delta_r) = \sum b_w \Delta_1^{w_1} \cdots \Delta_r^{w_r}$ .

<span id="page-6-0"></span>The toric case of our main result for exponential sums is

**Theorem 1.3.6** (= 5.4.9). Let  $f: \mathbb{G}_{\mathrm{m}}^n \to \mathbb{A}^1$  be a Laurent polynomial whose Newton polytope  $\Delta = \Delta_{\infty}(f)$  is n-dimensional. Let  $\psi$  be a nontrivial additive character. Then

<span id="page-6-1"></span>
$$\sum_{i} \dim \mathcal{H}_{c}^{i}(\mathbb{G}_{m,\overline{\mathbb{F}}_{q}}^{n}; f^{*}\mathcal{L}_{\psi}) \leqslant \inf_{S} \left\{ \Delta^{n} + \sum_{i=1}^{n} 2^{i-1} \Delta^{n-i} S^{i} \right\}.$$

Here S ranges in the set of all n-dimensional lattice polytopes in  $\mathbb{R}^n$ .

Since S can be chosen arbitrarily in Theorem 1.3.6, we can take  $S = \Delta$ . Then we get

(1.3.7) 
$$\sum_{i} \dim \mathcal{H}_{c}^{i}(\mathbb{G}_{m,\overline{\mathbb{F}}_{q}}^{n}; f^{*}\mathcal{L}_{\psi}) \leqslant 2^{n} \Delta^{n} = 2^{n} n! \operatorname{Vol}(\Delta).$$

This improves the bound of Adolphson–Sperber (AS).

One novelty of Theorem 1.3.6 is that the bounds are obtained at the cohomology level, for compactly supported Betti numbers, rather than merely addressing the total degree of the L-function. This allows us to deduce the Betti sum bound (Theorem 1.1.2) through an elementary counting argument (see §5.5) via a toric reduction and a volume computation.

Taking  $S = \Delta$  is a crude choice in many cases, because the Minkowski mixed volume gets smaller if S is small and more similar to  $\Delta$ . Thus, if we can choose a rational number d > 2 such that  $\Delta = dS$  for some lattice polytope S, then we get

<span id="page-6-2"></span>(1.3.8) 
$$\sum_{i} \dim \mathcal{H}_{c}^{i}(\mathbb{G}_{m,\overline{\mathbb{F}}_{q}}^{n}; f^{*}\mathcal{L}_{\psi}) \leqslant n! \operatorname{Vol}(S) \cdot \left[ d^{n} + \frac{d^{n} - 2^{n}}{d - 2} \right]$$
$$= n! \operatorname{Vol}(\Delta) \cdot \left[ 1 + \frac{1 - (\frac{2}{d})^{n}}{d - 2} \right].$$

If d is large, the upper bound on the right side is at most  $(1 + \frac{1}{d-2})n! \text{Vol}(\Delta)$ , which is close to the optimal number  $n! \text{Vol}(\Delta)$  achieved in the non-degenerate case as shown in [AS89].

For an *n*-dimensional lattice polytope  $\Delta$  in  $\mathbb{R}^n$  containing the origin, define

$$E_c(\Delta) := \sup_{\ell \neq p} \left\{ \sum_i \dim \mathrm{H}^i_c(\mathbb{G}^n_{\mathrm{m},\overline{\mathbb{F}}_p}; f^*\mathcal{L}_{\psi}) : f \in \overline{\mathbb{F}}_p[x_1^{\pm 1}, \cdots, x_n^{\pm 1}], \ \Delta_{\infty}(f) = \Delta \right\},$$

<span id="page-6-3"></span><sup>&</sup>lt;sup>1</sup>if  $\Delta$  is not *n*-dimensional, then we can write  $\mathbb{G}_{\mathrm{m}}^{n} = \mathbb{G}_{\mathrm{m}}^{n'} \times \mathbb{G}_{\mathrm{m}}^{n''}$ , and f factors as  $\mathbb{G}_{\mathrm{m}}^{n} \to \mathbb{G}_{\mathrm{m}}^{n'} \xrightarrow{f'} \mathbb{A}^{1}$ , where the first arrow is the projection to  $\mathbb{G}_{\mathrm{m}}^{n'}$ , and the Newton polytope of f' in  $\mathbb{R}^{n'}$  is of dimension n'. Therefore, it suffices to consider Laurent polynomials whose Newton polytope is n-dimensional.

where p and  $\ell$  run over all prime numbers with  $p \neq \ell$ ,  $\psi$  runs over all non-trivial additive characters of  $\mathbb{F}_p$ . The number  $E_c(\Delta)$  clearly depends only on the lattice polytope  $\Delta$ . Replacing  $\Delta$  by the multiple  $d\Delta$ , the above discussion gives

Corollary 1.3.9. For an n-dimensional lattice polytope  $\Delta$  in  $\mathbb{R}^n$  containing the origin, we have

$$n! \operatorname{Vol}(\Delta) d^n \leqslant E_c(d\Delta) \leqslant n! \operatorname{Vol}(\Delta) d^n \cdot \left[ 1 + \frac{1 - (\frac{2}{d})^n}{d - 2} \right]$$

In particular, as a function in d, we have the asymptotic formula

$$E_c(d\Delta) = n! \operatorname{Vol}(\Delta) \left( d^n + O(d^{n-1}) \right).$$

The toric exponential sums are examples of exponential sums over a nonsingular variety. In applications, however, studying exponential sums over a singular variety is inevitable. Although in principle singular exponential sums can be reduced to nonsingular exponential sums, the estimates coming from the standard reduction procedure are often not optimal. Previously, Katz [Kat99] studied exponential sums over singular affine complete intersections via the weak Lefschetz theorem. Our approach combines the Lefschetz method as well as the aforementioned specialization method. The general abstract result is formulated in §5.3. In this introduction, we are content with stating the following theorem:

<span id="page-7-2"></span><span id="page-7-0"></span>**Theorem 1.3.10.** Let V be a closed subvariety of  $\mathbb{A}^n_{\mathbb{F}_q}$ . Let  $f \in \mathbb{F}_q[x_1, \dots, x_n]$  be a polynomial of degree  $\leq d$ .

(i) (See 5.5) If V is cut out by r polynomials of degree  $\leq d$ , then

$$\sum_{i} \dim \mathcal{H}_{c}^{i}(V_{\overline{\mathbb{F}}_{q}}; f^{*}\mathcal{L}_{\psi}) \leqslant 3^{r} \binom{n+r}{r} (2d+1)^{n}.$$

<span id="page-7-1"></span>(ii) If V is cut out by some polynomials of degree at most d, then

$$\sum_{i} \dim \mathcal{H}_{c}^{i}(V_{\overline{\mathbb{F}}_{q}}; f^{*}\mathcal{L}_{\psi}) \leqslant 3^{n+1} \binom{2n+1}{n+1} (2d+1)^{n}.$$

(iii) (See 5.3.4) If V is cut out by r polynomials of degree  $\leq d$ , and dim V = n - r, then

$$\sum_{i} \dim \mathcal{H}_{c}^{i}(V_{\overline{\mathbb{F}}_{q}}; f^{*}\mathcal{L}_{\psi}) \leqslant \binom{n}{r} (d+1)^{n}.$$

In the context of (i), Bombieri [Bom78] proved a total degree upper bound  $(4d + 5)^{n+r}$ ; while Katz [Kat01] improved this upper bound to  $3(d + 2)^{n+r}$ .

Item (ii) follows from (i) by applying Kronecker's theorem, as in the proof of Corollary 1.1.4. To see how far these bounds from being optimal as d varies, let us introduce

$$E_c(n,r;d) := \sup_{\ell \neq p} \left\{ \sum_i \dim \mathcal{H}_c^i(V_{\overline{\mathbb{F}}_p}; f^* \mathcal{L}_{\psi}) : \begin{array}{l} V = \operatorname{Spec} \overline{\mathbb{F}}_p[x_1, \dots, x_n]/(f_1, \dots, f_r), \\ \deg f_i \leqslant d \end{array} \right\},$$

$$E_c^{\mathrm{ci}}(n,r;d) := \sup_{\ell \neq p} \left\{ \sum_i \dim \mathrm{H}_c^i(V_{\overline{\mathbb{F}_p}}; f^*\mathcal{L}_{\psi}) : \begin{array}{l} V = \mathrm{Spec}\,\overline{\mathbb{F}}_p[x_1,\ldots,x_n]/(f_1,\ldots,f_r), \\ \deg f_i \leqslant d, \text{ and } \dim V = n-r \end{array} \right\},$$

where p and  $\ell$  run over all prime numbers with  $p \neq \ell$ ,  $\psi$  runs over all non-trivial additive characters of  $\mathbb{F}_p$ , and f runs over all polynomials in  $\overline{\mathbb{F}}_p[x_1,\ldots,x_n]$  with  $\deg(f) \leqslant d$ .

By adding redundant equations, if necessary, one sees that the number  $E_c(n, r; d)$  is increasing in r. Namely,

$$E_c(n,1;d) \leqslant E_c(n,2;d) \leqslant \cdots \leqslant E_c(n,r;d) \leqslant E_c(n,r+1;d) \leqslant \cdots$$

Furthermore, by Kronecker's reduction, this sequence in r stabilizes once r reaches n+1. Thus, without loss of generality, we can always assume that  $r \leq n+1$ . In terms of these notations, the above corollary can be restated as

**Corollary 1.3.11.** Let n, r, d be positive integers. Then, we have

$$E_c(n,r;d) \le 3^r \binom{n+r}{r} (2d+1)^n, \quad E_c(n,r;d) \le 3^{n+1} \binom{2n+1}{n+1} (2d+1)^n.$$

For exponential sums over a complete intersection, we have an asymptotic formula.

**Corollary 1.3.12.** Let n, r, d be positive integers with  $r \leq n$ . We have

$$\binom{n}{r}(d-1)^n \leqslant E_c^{\text{ci}}(n,r;d) \leqslant \binom{n}{r}(d+1)^n.$$

In particular  $E_c^{ci}(n,r;d) = \binom{n}{r} d^n + O_{n,r}(d^{n-1}).$ 

**Proof.** When d is coprime to the characteristic of p, we will prove (see Corollary 5.3.4(ii)) that for a sufficiently general pair (V, f), the sum  $\sum_{m} \dim H_c^m(V; f^*\mathcal{L}_{\psi}) \geq \binom{n}{r} (d-1)^n$ . Since  $E_c^{\text{ci}}(n, r; d)$  is a supremum taken over all primes p, this establishes the lower bound.

Since  $E_c(n,r;d) \geqslant E_c^{\text{ci}}(n,r;d)$ , the above two corollaries together imply  $E_c(n,r;d) \asymp_{n,r} d^n$ . Hence, the correct order of  $E_c(n,r;d)$  is  $d^n$ . As before, a natural question arises: is there an asymptotic formula for  $E_c(n,r;d)$  as  $d\to\infty$ ? Namely, is there a positive constant  $e_{n,r}$  such that

$$E_c(n, r; d) = e_{n,r}d^n + o_{n,r}(d^n)$$
?

If so, what is the leading constant  $e_{n,r}$ ?

**Remark.** An expert in Dwork theory understands that the total degree bounds of Bombieri and Adolphson–Sperber (AS) stem from chain-level overcounts. When viewed cohomologically, these bounds can naturally be refined to Betti number bounds for *some* cohomology, such as Berthelot's rigid cohomology. The necessary tools to establish this have been laid out in our previous work [WZ22].

On the other hand, as Dwork theory is fundamentally a p-adic theory, it yields Betti number bounds only for p-adic cohomology. Since the equality between rigid cohomology Betti numbers and  $\ell$ -adic Betti numbers is still conjectural, the Dwork-theoretic method does not establish the  $\ell$ -adic version of (1.3.7).

1.4. Upper semicontinuity of the middle Newton polygon. The other novelty of our approach is that it allows us to extract more information than just Betti numbers. Using the Grothendieck specialization theorem of Newton polygons, we can infer the p-adic information of the Frobenius eigenvalues.

Recall that we can use the Newton polygon to capture p-adic information about the roots of a polynomial. If  $P(t) = a_0 + a_1 t + \cdots + a_n t^n$  is a polynomial with coefficients in  $\overline{\mathbb{Q}}_p$  and  $a_0 \neq 0$ , and if q is a power of p, then the Newton polygon of P with respect to  $\operatorname{ord}_q$  is defined as the convex hull in  $\mathbb{R}^2$  of the points

$$(0, \operatorname{ord}_q(a_0)), (1, \operatorname{ord}_q(a_1)), \dots, (n, \operatorname{ord}_q(a_n)).$$

If L is a side of the Newton polygon of P(t) (i.e., L is a line segment joining two vertices of the Newton polygon) with slope s, and the projection of L onto the horizontal axis has length m, we say that s is a slope of the Newton polygon and m is the multiplicity of s. When s is a slope of the Newton polygon with multiplicity m, there are precisely m roots of P (counting multiplicity)  $r_1, \ldots, r_m$  in  $\overline{\mathbb{Q}}_p$  such that  $\operatorname{ord}_q(r_i^{-1}) = s$ .

Let  $\psi \colon \mathbb{F}_p \to \overline{\mathbb{Q}}_{\ell}^*$  be a nontrivial additive character, and let  $f \colon U \to \mathbb{A}^1$  be a regular function between varieties over  $\mathbb{F}_q$ . We are interested in investigating the Newton polygon of the polynomials

$$\iota \det(1 - tF | \mathcal{H}_c^i(U_{\overline{\mathbb{F}}_q}; f^*\mathcal{L}_{\psi})),$$

where  $\iota$  is an isomorphism between  $\overline{\mathbb{Q}}_{\ell}$  and  $\overline{\mathbb{Q}}_{p}$ . The integrality of the Frobenius eigenvalues (cf. [DK73, XXI, Appendice]) implies that the Newton polygon of  $\iota \det(1 - tF|\mathcal{H}_{c}^{i}(U_{\overline{\mathbb{F}}_{q}}; f^{*}\mathcal{L}_{\psi}))$  is independent of the choice of  $\iota$ .

The Newton polygons associated with a "nondegenerate" toric exponential sum have been thoroughly studied by Adolphson and Sperber [AS89] through Dwork theory, where they establish the "Newton above Hodge" inequality. This inequality is shown to be an equality in many cases, see [Wan93, Wan04]. However, for degenerate exponential sums or those that are not toric in nature, very little is known.

The specialization lemma 3.1 has an arithmetic variant (Variant 3.4). When applied to exponential sums, it yields the following global arithmetic analogue of Steenbrink's lower semicontinuity theorem for Hodge spectra ([Ste85]):

<span id="page-9-0"></span>**Theorem 1.4.1** (Upper semicontinuity of the middle Newton polygon, = 5.1.2). Let  $\Gamma \subset \mathbb{R}^2_{\geq 0}$  be a convex polygon with 0 as one of its vertices. Let  $f: U \times S \to \mathbb{A}^1$  be a morphism of varieties over  $\mathbb{F}_q$ , where S is a smooth, geometrically connected curve, and U is a purely n-dimensional affine variety with at worst local complete intersection singularities. Suppose there is an open dense subset S' of S such that for any closed point s of S', the following holds:

If  $\kappa(s) = \mathbb{F}_{q^m}$ , then the Newton polygon (with respect to the valuation  $\operatorname{ord}_{q^m}$ ) of

$$\det(1 - tF^m | \mathcal{H}^n(U_{\overline{\mathbb{F}}_q} \times \{\overline{s}\}; f^*\mathcal{L}_{\psi}))$$

is on or above  $\Gamma$ , where  $F: U \to U$  is the q-power Frobenius substitution, and  $\overline{s}$  is a  $\overline{\mathbb{F}}_q$ -valued geometric point of S lying above s.

Then the same property holds for all s.

Applying this to  $U = \mathbb{A}^n$ , and utilizing Adolphson–Sperber's bound for nondegenerate polynomials along with the Lefschetz-type theorem 2.3.3, we obtain the following corollary regarding the Newton polygon for exponential sums over the affine space, which does not appear to be known.

**Corollary 1.4.2** (= 5.3.3). Suppose  $f: \mathbb{A}^n_{\mathbb{F}_q} \to \mathbb{A}^1_{\mathbb{F}_q}$  is any polynomial of degree  $\leq d$ . Assume that (q,d) = 1. Then for  $0 \leq j \leq n$ , the Newton polygon of

$$\det(1 - tF|\mathbf{H}_c^{n+j}(\mathbb{A}_{\overline{\mathbb{F}}_q}^n; f^*\mathcal{L}_{\psi}))$$

lies on or above the Newton polygon of

$$\prod_{m=0}^{(n-j)(d-2)} (1 - q^{j + \frac{m+n-j}{d}} t)^{U_{m,n-j}},$$

where  $U_{m,n}$  is the coefficient of  $x^m$  in the expansion of  $(1 + x + \cdots + x^{d-2})^n$ .

The hypothesis that (d,q)=1 is a limitation of the specialization method, as we need to know the information regarding the Newton polygon of a generic member. However, we believe that the corollary should still hold true even when  $(d,q) \neq 1$ .

Organization. The paper is organized as follows. In §2, we fix some notation and recall some basics in sheaf theory. In §3, we prove the specialization lemma mentioned above. §4 is devoted to the proof of Theorem 1.2.2 and related results. In §5 we study exponential sums from a broader context than toric ones. Specifically, we shall explain how to make an exact computation for "well-behaved" functions. Theorem 1.3.6 will then be deduced from a theorem of Khovanskii [Kho78]. In this section, we also use the corollary (1.3.7) of Theorem 1.3.6 to prove Theorem 1.1.2.

**Acknowledgment.** We extend our sincere gratitude to Haoyu Hu for the stimulating conversations and valuable exchange of ideas during our visits to Nanjing in Spring 2024 and Shenzhen in Winter 2024. The second author would like to thank Yongqiang Liu and L. Maxim for the enlightening conversations during his visit to Hefei in Fall 2024.

#### 2. Notation, conventions, and recapitulations

<span id="page-10-0"></span>In the following, k will be a field, and  $\ell$  will be a prime number. When working over a base scheme S, we shall always implicitly assume that  $\ell$  is different from the characteristic of the residue field of any point of S.

2.1. **Perverse sheaves.** We shall use the language of perverse sheaves throughout. In [BBD82], a selfdual perverse t-structure is constructed on the constructible derived category  $D_c^b(X; \overline{\mathbb{Q}}_\ell)$  of  $\overline{\mathbb{Q}}_\ell$ -sheaves on a scheme X over a finite field or an algebraically closed field. We denote this t-structure by  $({}^p\mathcal{D}_X^{\leqslant 0}, {}^p\mathcal{D}_X^{\geqslant 0})$ , and the perverse cohomology of an object  $\mathcal{F} \in D_c^b(X; \overline{\mathbb{Q}}_\ell)$  is denoted by  ${}^p\mathcal{H}^*(\mathcal{F})$ . Objects of  ${}^p\mathcal{D}_X^{\leqslant 0}$  are said to satisfy the support condition, while objects of  ${}^p\mathcal{D}_X^{\geqslant 0}$  are said to satisfy the cosupport condition.

We will freely use basic properties of perverse sheaves documented in the standard references such as [BBD82, KW01]

<span id="page-10-2"></span>Here is a simple lemma that we will need.

**Lemma 2.1.1.** Let Y be an algebraic variety over an algebraically closed field. Let  $\mathcal{F}$  be an object of  ${}^{\mathrm{p}}\mathcal{D}_{Y}^{\geqslant 0}$ . Let X be a closed subvariety of Y, which is locally defined by the vanishing of r regular functions. Let  $i: X \to Y$  be the closed immersion. Then  $i^*[-r]$  is left t-exact, i.e.,  $i^*[-r] ({}^{\mathrm{p}}\mathcal{D}_{Y}^{\geqslant 0}) \subset {}^{\mathrm{p}}\mathcal{D}_{X}^{\geqslant 0}$ .

**Proof.** By induction we may assume r = 1. Let  $j: U \to Y$  be the complement of X in Y. Let  $\mathcal{F}$  be an object of  ${}^{\mathbf{p}}\mathcal{D}_{Y}^{\geqslant 0}$ . Consider the distinguished triangle

$$\mathcal{F}[-1] \to i_* i^* \mathcal{F}[-1] \to j_! j^* \mathcal{F} \xrightarrow{+1} .$$

Since j is both quasi-finite and affine,  $j_!$  is t-exact. Since  $j^*$  is also t-exact, we find  $j_!j^*\mathcal{F}$  still satisfies the cosupport condition. Since  $\mathcal{F}[-1] \in {}^{\mathrm{p}}\mathcal{D}_{Y}^{\geqslant 1}$  trivially satisfies the cosupport condition, we conclude that  $i_*i^*\mathcal{F}[-1]$  satisfies the cosupport condition as well. Since i is a closed immersion,  $i_*$  is fully faithful and t-exact, it follows that  $i^*\mathcal{F}[-1]$  satisfies the cosupport condition. This completes the proof.

2.2. **Newton polygon.** Now we recall some basics about Newton polygons associated with sheaves on varieties. Let k be an algebraic closure of  $\mathbb{F}_p$ , and fix an isomorphism  $\iota$  between  $\overline{\mathbb{Q}}_{\ell}$  and  $\overline{\mathbb{Q}}_p$ .

Suppose  $B_0$  is a scheme over  $\mathbb{F}_q$ , and let  $B = B_0 \otimes_{\mathbb{F}_q} k$ . Let  $\mathcal{F}_0$  be a Weil  $\overline{\mathbb{Q}}_{\ell}$ -sheaf on  $B_0$  (cf. [Del80, Définition 1.1.10]). Each  $\mathbb{F}_{q^m}$ -valued point

<span id="page-10-1"></span>
$$x_0 \colon \operatorname{Spec} \mathbb{F}_{q^m} \to B_0$$

defines a geometric point

$$(2.2.1) x: \operatorname{Spec} k \to \operatorname{Spec} \mathbb{F}_{q^m} \xrightarrow{x_0} B_0$$

and a geometric Frobenius operation

$$F_{x_0} \colon \mathcal{F}_x \xrightarrow{\sim} \mathcal{F}_x.$$

**Definition 2.2.2.** The Newton polygon of  $\mathcal{F}$  at the closed point x of B is defined as

$$NP(\mathcal{F}_x) = Newton polygon of det(1 - tF_{x_0}|\mathcal{F}_x)$$
 with respect to  $ord_{q^m}$ .

As the notation indicates, this is manifestly a geometric notion, independent of the factorization (2.2.1). Indeed, each closed point x of B can be regarded as a geometric point of  $B_0$ . If x factors through an  $\mathbb{F}_{q^m}$ -valued point, it also factors through many  $\mathbb{F}_{q^{ms}}$ -valued points (for any  $s \ge 1$ ):

$$x \colon \operatorname{Spec} k \longrightarrow \operatorname{Spec} \mathbb{F}_{q^{ms}} \longrightarrow \operatorname{Spec} \mathbb{F}_{q^m} \xrightarrow{x_0} B_0$$

Thus, the geometric Frobenius of  $y_0$  satisfies  $F_{y_0} = F_{x_0}^s$ . It follows that the Newton polygon of  $\det(1 - tF_{x_0}|\mathcal{F}_x)$  with respect to  $\operatorname{ord}_{q^m}$  is the same as that of  $\det(1 - tF_{y_0}|\mathcal{F}_x)$  with respect to  $\operatorname{ord}_{q^{ms}}$ .

One extreme case is when  $B_0 = \operatorname{Spec} \mathbb{F}_q$ , and  $\mathcal{F} = \operatorname{H}^i(X; \mathcal{E})$  for some scheme  $X_0$  over  $\mathbb{F}_q$ , and some constructible  $\overline{\mathbb{Q}}_{\ell}$ -sheaf  $\mathcal{E}$  on  $X_0$ . In this case, we shall simply write  $\operatorname{NP}(\operatorname{H}^i(X; \mathcal{E}))$  instead.

Let B be a smooth and connected curve, and let B' be the Zariski open dense subset of B over which  $\mathcal{F}$  restricts to a local system. Essentially by class field theory,  $\det \mathcal{F}|_{B'}$  has a constant Newton polygon on B' (cf. [Del80, (1.3.3)]). Hence, for  $b' \in B'$ ,  $NP(\mathcal{F}_{b'})$  all have the same starting point and endpoint.

For  $b \in B-B'$ , let  $\overline{\eta}_b$  be a geometric generic point of the strict localization of B at b. While the geometric Frobenius action on  $\mathcal{F}_{\overline{\eta}_b}$  depends on some choice, its characteristic polynomial is well-defined ([Del80, Lemme (1.7.4)]). Therefore, we can also define the Newton polygon  $\mathrm{NP}(\mathcal{F}_{\overline{\eta}_b})$  for  $\overline{\eta}_b$ . We have the following  $\ell$ -adic version of Grothendieck's specialization theorem due to Deligne.

<span id="page-11-0"></span>**Proposition 2.2.3** ([Del80, Corollaire (1.10.7)]). Let the notation be as above. Suppose  $\Gamma$  is a convex polygon such that for any closed point  $b' \in B'$ , we have

$$NP(\mathcal{F}_{h'})$$
 lies on or above  $\Gamma$ .

Then for any  $b \in B - B'$ , we have

$$NP(\mathcal{F}_{\overline{\eta}_b})$$
 lies on or above  $\Gamma$ .

Moreover, if  $NP(\mathcal{F}_{b'})$  and  $\Gamma$  have the same starting and endpoint, then  $NP(\mathcal{F}_{\overline{\eta}_b})$  and  $\Gamma$  also have the same starting and endpoint.

**Proof.** While Deligne's proof assumes that  $NP(\mathcal{F}_{b'})$  is constant, a careful examination of the argument reveals that all we need is a collection of inequalities. A uniform lower bound for these  $NP(\mathcal{F}_{b'})$  is sufficient to carry out the proof.

The existence of crystalline companions for  $\ell$ -adic local systems implies that there is an open subset of B' on which the Newton polygon of  $\mathcal{F}_{b'}$  is constant. For our applications, the weaker form stated above suffices.

2.3. Weak Lefschetz theorems. In this subsection, we record some Lefschetz-type theorems that will be used later. We fix an algebraically closed ground field k.

<span id="page-12-3"></span>**Lemma 2.3.1.** Let Y be a projective variety. Assume that  $\mathcal{F}$  is an object of  ${}^{\mathrm{p}}\mathcal{D}_{Y}^{\geqslant 0}$ . Let X be the intersection of r ample Cartier divisors on Y. Then the map

$$H^{j-r}(Y; \mathcal{F}) \to H^{j-r}(X; \mathcal{F})$$

is bijective for j < 0 and injective for j = 0.

**Proof.** We use induction on r. When r=0, there is nothing to prove. For r>1, let  $X=D_1\cap\cdots\cap D_r$ , with  $D_j$  ample. Let Y' be the intersection  $D_2\cap\cdots\cap D_r$ . By Lemma 2.1.1,  $\mathcal{F}|_{Y'}[-r+1]$  satisfies the cosupport condition. Since Y'-X is affine, it follows from Artin's vanishing theorem ([BBD82, Corollaire 4.1.2]) that

$$H_c^j(Y' - X; \mathcal{F}[-r+1]) = 0$$

for j < 0. The result now follows from the long exact sequence

$$\cdots \to \mathrm{H}^m_c(Y' - X; \mathcal{F}) \to \mathrm{H}^m(Y'; \mathcal{F}) \to \mathrm{H}^m(X; \mathcal{F}) \to \cdots$$

<span id="page-12-4"></span>**Theorem 2.3.2** (Deligne). Let  $f: X \to \mathbb{P}^N$  be a quasi-finite morphism to a projective space. Let  $\mathcal{F}$  be an object in  ${}^{\mathrm{p}}\mathcal{D}_X^{\geqslant 0}$ . Then for a sufficiently general hyperplane B, the restriction morphism

$$\mathrm{H}^i(X;\mathcal{F}) \to \mathrm{H}^i(f^{-1}B;\mathcal{F}|_{f^{-1}B})$$

is injective if i = -1, and bijective if i < -1.

**Proof.** This is proved in [Kat93, Corollary A.5]. After going through the proof, we find that only the condition  $\mathcal{F} \in {}^{p}\mathcal{D}_{X}^{\geqslant 0}$  was used (Katz needed only  $\mathbb{D}\mathcal{F}$  to be "semiperverse", i.e.,  $\mathbb{D}\mathcal{F} \in {}^{p}\mathcal{D}_{X}^{\geqslant 0}$ , where  $\mathbb{D}(-)$  is the Verdier duality functor).

<span id="page-12-1"></span>**Lemma 2.3.3.** Let  $f: X \to \mathbb{P}^N$  be a quasi-finite morphism. Let  $\mathcal{F} \in {}^{p}\mathcal{D}_X^{\leqslant 0}$ . Then for a sufficiently general hyperplane B, the purity map

$$\mathrm{H}_{c}^{m-2}(f^{-1}B;\mathcal{F}|_{X\cap B}(-1))\to\mathrm{H}_{c}^{m}(X;\mathcal{F}),$$

is surjective if m = 1, and is bijective if  $m \ge 2$ .

<span id="page-12-0"></span>**Proof.** This is [WZ23, Lemma 3.8].

#### 3. Specialization of Betti numbers and Newton Polygons

Let k be an algebraically closed field, and  $\ell$  a prime number invertible in k. Let B be a connected nonsingular curve over k. Let  $\pi \colon V \to B$  be a morphism of k-schemes. Let  $\mathcal{F}$  be a constructible  $\overline{\mathbb{Q}}_{\ell}$ -complex on V. Since  $R\pi_!\mathcal{F}$  remains constructible, there is an open dense immersion  $j \colon B' \to B$  such that the cohomology sheaves of  $j^*R\pi_!\mathcal{F}$  are local systems on B'.

<span id="page-12-2"></span>**Lemma 3.1** (Lower semicontinuity of the middle Betti number). In the situation above, assume in addition that

- ullet  $\mathcal{F}$  satisfies the cosupport condition, i.e.,  $\mathcal{F} \in {}^{p}\mathcal{D}_{V}^{\geqslant 0}$ , and
- $\pi$  is an affine morphism.

Then for any  $b \in B - B'$ , and any  $b' \in B'$ , we have

$$\dim \mathrm{H}_c^{-1}(\pi^{-1}(b);\mathcal{F}|_{\pi^{-1}(b)}) \leqslant \dim \mathrm{H}_c^{-1}(\pi^{-1}(b');\mathcal{F}|_{\pi^{-1}(b')}).$$

**Proof.** By shrinking B, we may assume that  $B - B' = \{b\}$ . Let  $i : \{b\} \to B$  be the inclusion morphism. Then we have a distinguished triangle

$$i_!i^*(R\pi_!\mathcal{F}) \to R\pi_!\mathcal{F} \to i_*i^*(R\pi_!\mathcal{F}).$$

Since  $\pi$  is affine, Artin's vanishing theorem ([BBD82, Corollaire 4.1.2]) implies that  $R\pi_!\mathcal{F}$  satisfies the cosupport condition as well. In particular, we have  ${}^{p}\mathcal{H}^{-1}(R\pi_!\mathcal{F}) = 0$ . Therefore,

applying the perverse cohomology functors to the above distinguished triangle gives rise to an exact sequence of perverse sheaves

$$0 \to {}^{\mathrm{p}}\mathcal{H}^{-1} i_* i^* (R\pi_! \mathcal{F}) \to {}^{\mathrm{p}}\mathcal{H}^0 j_! j^* (R\pi_! \mathcal{F}) \to {}^{\mathrm{p}}\mathcal{H}^0 (R\pi_! \mathcal{F}).$$

Using the t-exactness of  $j_!$  (since j is an affine, quasi-finite morphism,  $j_!$  is t-exact by [BBD82, Corollaire 4.1.3]), we have

$${}^{\mathbf{p}}\mathcal{H}^{0} j_{!} j^{*}(R\pi_{!}\mathcal{F}) = j_{!} {}^{\mathbf{p}}\mathcal{H}^{0} j^{*}(R\pi_{!}\mathcal{F}).$$

Since the usual cohomology sheaves of  $j^*(R\pi_!\mathcal{F})$  are assumed to be local systems, and since B' is smooth, connected, and one dimensional, we have

$${}^{\mathbf{p}}\mathcal{H}^{0} j^{*}(R\pi_{!}\mathcal{F}) = \mathcal{H}^{-1}(j^{*}(R\pi_{!}\mathcal{F}))[1] = (R^{-1}\pi_{!}\mathcal{F})|_{B'}[1].$$

By proper base change, the rank of the local system  $(R^{-1}\pi_!\mathcal{F})|_{B'}$  equals the dimension of the cohomology space  $H_c^{-1}(\pi^{-1}(b');\mathcal{F}|_{\pi^{-1}(b')})$ , for any  $b' \in B'$ .

On the other hand, since  $i_*$  is t-exact ([KW01, Lemma 4.1]), and since the perverse cohomology and the usual cohomology agree on a point, we have

<span id="page-13-1"></span>(3.2) 
$${}^{\mathbf{p}}\mathcal{H}^{-1}i_{*}i^{*}(R\pi_{!}\mathcal{F}) = i_{*}\mathbf{H}^{-1}(i^{*}(R\pi_{!}\mathcal{F}))$$
 (proper base change) =  $i_{*}\mathbf{H}_{c}^{-1}(\pi^{-1}(b); \mathcal{F}|_{\pi^{-1}(b)}).$ 

<span id="page-13-2"></span>Thus, to prove the lemma, it suffices to apply the following simple claim.

Claim 3.3. Let B, b, i, j be as above. Suppose  $i_*E \to j_!\mathcal{E}[1]$  is an injective morphism between perverse sheaves on B, where E is a  $\overline{\mathbb{Q}}_{\ell}$ -vector space, regarded as a  $\overline{\mathbb{Q}}_{\ell}$ -sheaf on  $\{b\}$ , and  $\mathcal{E}$  is a local system on B', then dim  $E \leq \operatorname{rank} \mathcal{E}$ .

To prove the claim, we apply the unipotent vanishing cycle functor  ${}^{p}\Phi_{t,1} = R\Phi_{t,1}[-1]$  to the injective morphism  $i_*E \to j_!\mathcal{E}[1]$ , where  $t \colon B \to \mathbb{A}^1$  is a regular function on a neighborhood of b defined by a uniformizer of the local ring of  $\mathcal{O}_{B,b}$ . On the one hand, we have  ${}^{p}\Phi_{t,1}(i_*E) = E$ . On the other hand, we have  ${}^{p}\Phi_{t,1}(j_!\mathcal{E}[1]) = {}^{p}\Psi_{t,1}(\mathcal{E}[1])$ , where  ${}^{p}\Psi_{t,1} = R\Psi_{t,1}[-1]$  is the unipotent nearby cycle functor. This can be seen from the distinguished triangle

$$i^*[-1] \to {}^{\mathrm{p}}\Psi_{t,1} \xrightarrow{\mathrm{can}} {}^{\mathrm{p}}\Phi_{t,1}$$

and the fact that  $i^*j_!=0$ . Since  ${}^p\Psi_{t,1}$  is a direct summand of the full nearby cycle functor, we have

$$\dim^{\mathbf{p}}\Phi_{t,1}(j_{!}\mathcal{E}[1]) = \dim^{\mathbf{p}}\Psi_{t,1}(\mathcal{E}[1]) \leqslant \operatorname{rank}\mathcal{E}.$$

Finally, since  ${}^{p}\Phi_{t,1}$  is a t-exact functor,

$$E \to {}^{\mathrm{p}}\Phi_{t,1}(j_!\mathcal{E}[1])$$

remains injective. This concludes the proof of the claim and finishes the proof of the lemma.

To state an arithmetic variant of the lemma incorporating p-adic information, let us assume k is an algebraic closure of  $\mathbb{F}_q$ , where q is a power of a prime p,  $B = B_0 \otimes_{\mathbb{F}_q} k$ ,  $V = V_0 \otimes_{\mathbb{F}_q} k$ , and  $\mathcal{F}$  has a structure of a Weil sheaf on  $V_0$ . Thus  $B' = B'_0 \otimes_{\mathbb{F}_q} k$  for some Zariski open dense subset  $B'_0$  of  $B_0$ , and  $\Sigma_0 = U_0 - B'_0$  defines  $\Sigma$ . Let  $\mathcal{E}_0[1] = {}^p\mathcal{H}^{-1}(R\pi_!\mathcal{F}_0)|_{B'_0}$ . Then  $\mathcal{E}_0$  is a local system on  $B'_0$ . Let  $\mathcal{E}$  be the local system on B' induced by  $\mathcal{E}_0$ .

<span id="page-13-0"></span>Variant 3.4 (Upper semicontinuity of the middle Newton polygon). In the situation above, let  $b \in \Sigma$ . Suppose that  $\Gamma$  is a convex polygon in  $\mathbb{R}^2$  such that for any  $b' \in B'$ ,  $NP(\mathcal{E}_{b'})$  lies on or above  $\Gamma$ . Then for any  $b \in \Sigma$ , the Newton polygon of  $H_c^{-1}(\pi^{-1}(b); \mathcal{F}|_{\pi^{-1}(b)})$  lies on or above  $\Gamma$ .

**Proof.** As we have seen in the proof of Lemma 3.1, especially in (3.2), for  $b \in \Sigma$ , the cohomology space  $H_c^{-1}(\pi^{-1}(b); \mathcal{F}|_{\pi^{-1}(b)})$  corresponds to the vector space E in Claim 3.3. It injects into the unipotent nearby cycle of  $\mathcal{E}$ , which is a direct summand of the full nearby cycle  $\mathcal{E}_{\overline{\eta}_b}$ , where  $\overline{\eta}_b$  is a geometric generic point of the strict localization at b. Now we can apply Proposition 2.2.3.

We will also need the following variant of Lemma 3.1 in mixed characteristic context. We state it in terms of torsion coefficients since the needed prerequisites are only documented for torsion coefficients, and we will only refer to this torsion version.

<span id="page-14-0"></span>Variant 3.5 (Mixed characteristic case). Let S be a strictly henselian trait with special point s and generic point  $\eta$ . Let  $\overline{\eta}$  be a geometric point lying above  $\eta$ . Choose a prime number  $\ell$  invertible on S. Suppose V is a flat, local complete intersection S-scheme of relative dimension n everywhere. Then

$$\dim H_c^n(V_s; \mathbb{F}_{\ell}) \leqslant \dim H_c^n(V_{\overline{\eta}}; \mathbb{F}_{\ell}).$$

**Proof.** By [Ill03, §2], a selfdual perverse t-structure can be defined on the constructible category of étale  $\mathbb{F}_{\ell}$ -sheaves on V (which is amenable to the four functor formalism, see [Del77, Finitude]). The flat and local complete intersection hypotheses imply that the shifted constant sheaf  $\mathcal{F} = \mathbb{F}_{\ell,V}[n+1]$  is a perverse sheaf on V ([Ill03, Corollaire 2.7]). Let  $\pi \colon V \to S$  be the structure morphism. By Gabber's Artin vanishing theorem ([Ill03, Théorème 2.4]),  $R\pi_!\mathcal{F} = R\pi_!(\mathbb{F}_{\ell,V}[n+1])$  has no negative perverse cohomology sheaves. With these ingredients, the argument of Lemma 3.1 goes through.

## 4. Betti numbers of set-theoretic complete intersections

<span id="page-14-1"></span>In this section, k is an algebraically closed field. Our objective is to estimate the compactly supported Betti numbers of set-theoretic complete intersections in ambient spaces via Lemma 3.1. After establishing a slightly more general framework (§4.1), we specialize to set-theoretic complete intersections in an affine space (§4.2), then to those in a projective space (§4.3). Finally, we apply these estimates to derive effective Lang-Weil type bounds.

<span id="page-14-2"></span>4.1. **General upper bounds.** A convenient framework, which is general enough to include many interesting special cases, is as follows.

<span id="page-14-3"></span>Construction 4.1.1. Consider the following data:

- X is a proper variety.
- $D \subset X$  is an effective Cartier divisor.
- U = X D. We assume that U is an affine nonsingular variety.
- $\mathcal{L}_1, \ldots, \mathcal{L}_r$  are invertible sheaves on X. We assume that dim  $H^0(X; \mathcal{L}_i) \geq 1$ .

Each point  $(F_1, \ldots, F_r)$  of the space  $\mathcal{M} = \prod_{i=1}^r \mathbb{P}H^0(X; \mathcal{L}_i)$  determines a closed subvariety  $\{F_1 = \cdots = F_r = 0\}$  of X. We denote the intersection  $U \cap \{F_1 = \cdots = F_r = 0\}$  by  $V^{\circ}(F_1, \ldots, F_r)$ .

We have an incidence correspondence  $\mathcal{V} \subset U \times \mathcal{M}$ : the fiber of  $\mathcal{V} \to \mathcal{M}$  over  $(F_1, \dots, F_r) \in \mathcal{M}$  is  $V^{\circ}(F_1, \dots, F_r)$ . Denote the projection morphism by  $\varpi \colon \mathcal{V} \to \mathcal{M}$ .

Due to the constructibility of  $R^e \varpi_! \overline{\mathbb{Q}}_{\ell}$ , there is a Zariski open dense subset  $\mathcal{U}$  of  $\mathcal{M}$  such that for any e,  $R^e \varpi_! \overline{\mathbb{Q}}_{\ell}|_{\mathcal{U}}$  is a local system on  $\mathcal{U}$ . By the proper base change theorem, if e is fixed and  $(F_1, \ldots, F_r)$  varies in  $\mathcal{U}$ , the number

$$\dim \mathrm{H}_c^e(V^{\circ}(F_1,\ldots,F_r);\overline{\mathbb{Q}}_{\ell})$$

remains constant. We denote this constant by

$$(4.1.2) B_c^e(X, D; \mathcal{L}_1, \dots, \mathcal{L}_r)$$

<span id="page-15-3"></span>or simply  $B_c^e$  when there is no ambiguity.

**Proposition 4.1.3.** In Construction 4.1.1, let  $(F_1, ..., F_r)$  be an arbitrary r-tuple in  $\mathcal{M}$ . Then we have the following inequality:

$$\dim H_c^{n-r}(V^{\circ}(F_1,\ldots,F_r);\overline{\mathbb{Q}}_{\ell}) \leqslant B_c^{n-r}(X,D;\mathcal{L}_1,\ldots,\mathcal{L}_r).$$

**Proof.** Let  $(F_1, \ldots, F_r) \in \mathcal{M}$  be an arbitrary r-tuple, and let  $(F'_1, \ldots, F'_r)$  be an r-tuple contained in  $\mathcal{U}$ . Consider the morphism

$$u: \mathbb{A}^1 \to \mathcal{M}, \quad t \mapsto (1-t) \cdot (F_1, \dots, F_r) + t \cdot (F'_1, \dots, F'_r).$$

Form the fiber product  $V = \mathcal{V} \times_{\mathcal{M}, u} \mathbb{A}^1$ , and let  $\pi$  be the projection to  $\mathbb{A}^1$ . Since  $u(1) \in \mathcal{U}$  by construction,  $u(\mathbb{A}^1) \cap \mathcal{U}$  is nonempty. Thus  $u^{-1}\mathcal{U} = B'$  is an open dense subset of  $\mathbb{A}^1$ . By the proper base change theorem, for any  $b' \in B'$ , we have

$$(4.1.4)$$

Since V is defined in  $U \times \mathbb{A}^1$  by r equations  $(1-t)F_1 + tF'_1, \dots, (1-t)F_r + tF'_r$ , and since  $U \times \mathbb{A}^1$  is nonsingular, we see that  $\overline{\mathbb{Q}}_{\ell,V}[n+1-r]$  satisfies the cosupport condition (Lemma 2.1.1). Applying Lemma 3.1 to  $\pi \colon V \to \mathbb{A}^1$  and combining it with (4.1.4), we get

<span id="page-15-2"></span>
$$\dim \mathcal{H}_c^{n-r}(V^{\circ}(F_1,\ldots,F_r)) \leqslant B_c^{n-r}(X,D;\mathcal{L}_1,\ldots,\mathcal{L}_r),$$

<span id="page-15-1"></span>as desired.  $\Box$ 

4.2. Set-theoretic complete intersections in the affine space. Let  $n \ge r \ge 1$  and  $d_1, \ldots, d_r$  be natural numbers. We define

$$N(n; d_1, \dots, d_r) = d_1 \cdots d_r \cdot \sum_{e=0}^{n-r} (-1)^e \binom{n}{e} \sum_{a_1 + \dots + a_r = n - r - e} d_1^{a_1} \cdots d_r^{a_r},$$

and

$$M(n; d_1, \dots, d_r) = \begin{cases} N(n; d_1, \dots, d_r) - (-1)^{n-r} & \text{if } n > r, \\ N(n; d_1, \dots, d_r) = d_1 \dots d_r, & \text{if } n = r. \end{cases}$$

<span id="page-15-0"></span>In this subsection, we prove the following:

**Theorem 4.2.1.** Consider the affine scheme  $V = \operatorname{Spec} k[x_1, \dots, x_n]/(f_1, \dots, f_r)$ , where  $f_1, \dots, f_r$  satisfy  $\operatorname{deg} f_i \leq d_i$ . Then

(i) We have

$$\dim H_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) \leqslant M(n; d_1, \dots, d_r).$$

(ii) If, in addition, dim V = n - r, then for any  $0 \le j \le n - r$ , we have

$$\dim H_c^{n-r+j}(V; \overline{\mathbb{Q}}_{\ell}) \leqslant M(n-j; d_1, \dots, d_r).$$

Thus, 
$$B_c(V, \ell) \leq \sum_{i=0}^{n-r} M(n-j; d_1, \dots, d_r)$$
.

**Proof.** Let us first prove (i). We apply Construction 4.1.1 to the following situation:

- Let  $X = \mathbb{P}^n$  with homogeneous coordinates  $[x_0, \dots, x_n]$ .
- Let  $D = \{x_0 = 0\} \cong \mathbb{P}^{n-1}$  be the hyperplane at infinity.
- Let  $U = X D = \mathbb{A}^n$  with affine coordinates  $(x_1, \dots, x_n)$ .
- Let  $\mathcal{L}_i = \mathcal{O}_{\mathbb{P}^n}(d_i)$ .

The open set  $\mathcal{U}$  in Construction 4.1.1 can be taken to be the set of r-tuples  $(F_1, \ldots, F_r)$ , where each  $F_i$  is homogeneous of degree  $d_i$ , such that

- $\{F_1 = \cdots = F_r\} \subset \mathbb{P}^n$  is smooth of dimension n r.
- $D \cap \{F_1 = \dots = F_r\} \subset D \cong \mathbb{P}^{n-1}$  is smooth of dimension n-r-1.

The following lemma computes the number  $B_c^e(\mathbb{P}^n, \mathbb{P}^{n-1}; \mathcal{O}_{\mathbb{P}^n}(d_1), \dots, \mathcal{O}_{\mathbb{P}^n}(d_r))$ .

<span id="page-16-0"></span>**Lemma 4.2.2.** Let  $(F_1, \ldots, F_r)$  be an r-tuple in the open set  $\mathcal{U}$  defined above. Then the following holds:

(i) We have

$$\dim \mathbf{H}_c^{n-r}(V^{\circ}(F_1,\ldots,F_r);\overline{\mathbb{Q}}_{\ell})=M(n;d_1,\ldots,d_r).$$

- (ii) If  $n r \ge 1$ , then dim  $H_c^{2n-2r}(V^{\circ}(F_1, \dots, F_r)) = 1$ .
- (iii) If  $e \notin \{n-r, 2n-2r\}$ , then  $H_c^e(V^{\circ}(F_1, \dots, F_r)) = 0$ .
- (iv) In the case  $d_1 = \cdots = d_r = d$ , we have

$$\binom{n-1}{r-1}(d-1)^n \leqslant M(n;d,\cdots,d) \leqslant \binom{n-1}{r-1}d^n.$$

The proof of this lemma is a standard exercise, except perhaps the last part, and we have placed it at the end of the section for the reader's convenience.

The first inequality in Theorem 4.2.1 then follows from Proposition 4.1.3. To prove (ii) of Theorem 4.2.1, we apply Lemma 2.3.3 with  $\mathcal{F} = \mathbb{Q}_{\ell,V}[n-r]$ , X = V, and let f be the inclusion  $V \hookrightarrow \mathbb{A}^n \hookrightarrow \mathbb{P}^n$ . Note that the hypothesis  $\dim V = n-r$  ensures that the shifted constant sheaf  $\mathbb{Q}_{\ell,V}[n-r]$  is an object of  ${}^{\mathrm{p}}\mathcal{D}_{V}^{\leqslant 0}$ .

Thus, for a general hyperplane  $A \subset \mathbb{A}^n$ , we have

$$\dim \mathcal{H}^{n-r+1}_c(V;\overline{\mathbb{Q}}_\ell)\leqslant \dim \mathcal{H}^{n-r-1}_c(A\cap V;\overline{\mathbb{Q}}_\ell).$$

Since A is chosen to be general,  $A \cap V$  is a closed subscheme of an (n-1)-dimensional affine space, defined by r polynomials  $f_1|_A, \ldots, f_r|_A$ , with  $\deg f_i|_A = \deg f_i \leqslant d_i$ , and  $\dim A \cap V = n-1-r$ . Thus, by the first inequality, we obtain

$$\dim \mathbf{H}_c^{n-r-1}(A \cap V; \overline{\mathbb{Q}}_{\ell}) \leqslant M(n-1; d_1, \dots, d_r).$$

Repeating this argument for  $A \cap V$  and its higher-codimensional linear subspace sections, we complete the proof of the second inequality.

**Example 4.2.3.** Consider the case when r=1, i.e., V is a hypersurface in  $\mathbb{A}^n$  defined by a polynomial f of degree  $\leq d$ . In this case, Theorem 4.2.1 specializes to  $\dim H_c^{n-1+j}(V) \leq (d-1)^{n-j}$  for  $0 \leq j \leq n-2$  and  $\dim H_c^{n-1+n-1}(V) \leq d$ . In particular,

$$B_c(V,\ell) = \sum_{j=0}^{n-1} \dim H_c^{n-1+j}(V) \le d + \sum_{j=2}^n (d-1)^j \le d^n.$$

For  $r \ge 2$ , the formula for  $M(n; d_1, \ldots, d_r)$  is a bit messy when the integers  $d_i$ 's are not all the same. In the case  $d_1 = \cdots d_r = d$ , much simpler-looking upper and lower bounds for

$$M(n;d,\ldots,d)$$

<span id="page-16-1"></span>are given in Lemma 4.2.2. As a consequence, we deduce.

Corollary 4.2.4. Let  $1 \le r \le n$  be integers. Suppose  $f_1, \ldots, f_r \in k[x_1, \ldots, x_n]$  are polynomials satisfying deg  $f_i \le d$ . Let  $V = \operatorname{Spec} k[x_1, \ldots, x_n]/(f_1, \ldots, f_r)$ . Then:

(i) We have

$$\dim \mathcal{H}^{n-r}_c(V; \overline{\mathbb{Q}}_{\ell}) \leqslant \binom{n-1}{r-1} d^n.$$

(ii) Assume that dim V = n - r. Then for  $0 \le j \le n - r$ , we have

$$\dim \mathcal{H}_{c}^{n-r+j}(V;\mathbb{Q}_{\ell}) \leqslant \binom{n-j-1}{r-1} d^{n-j}.$$

Therefore,  $B_c(V,\ell) \leqslant \binom{n-1}{r-1}(d+1)^n$ .

<span id="page-17-0"></span>(iii) For  $1 \leq r \leq n$ , we have

$$\binom{n-1}{r-1}(d-1)^n \leqslant M(n; d, \dots, d) \leqslant B_c^{ci}(n, r; d)) \leqslant \binom{n-1}{r-1}(d+1)^n.$$

**Proof of Lemma 4.2.2.** If n = r, then the result follows directly from Bézout's theorem.

We now assume n > r, that is, n - r > 0. Recall the description of  $\mathcal{U}$  in the present situation. Let  $(F_1, \ldots, F_r) \in \mathcal{U}$ ,  $Z = \{F_1 = \cdots = F_r = 0\} \subset \mathbb{P}^n$ ,  $Z' = Z \cap D$ , and  $V = V^{\circ}(F_1, \ldots, F_r) \subset \mathbb{A}^n$ . Then we know that both Z and V are connected, and we have  $(-1)^{n-r}\chi(V) = (-1)^{n-r}(\chi(Z) - \chi(Z'))$ , where  $\chi(Y)$  denotes the Euler characteristic of Y:

$$\chi(Y) = \sum_{e} (-1)^{e} \dim \mathcal{H}_{c}^{e}(Y; \overline{\mathbb{Q}}_{\ell}).$$

We claim that  $H_c^e(V) = 0$  unless e = n - r or e = 2(n - r). If this assertion holds, then

$$(-1)^{n-r}\chi(V) = \dim \mathcal{H}_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) + (-1)^{n-r} \dim \mathcal{H}_c^{2(n-r)}(V; \overline{\mathbb{Q}}_{\ell})$$
$$= \dim \mathcal{H}_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) + (-1)^{n-r},$$

since V is connected. Therefore, once the assertion is confirmed, we need only compute the Euler characteristics to prove the lemma.

Let us prove the claim. If e < n - r, the claim follows from the Artin vanishing theorem since V is smooth. If n - r = 1, the claim is evident. Now, assume  $n - r \ge 2$  and e > n - r. In this case, both Z and Z' are smooth, connected complete intersections in projective spaces. For  $\epsilon \ge 1$ , the restriction map

$$\mathrm{H}^{n-r-1+\epsilon}(Z;\overline{\mathbb{Q}}_{\ell})\to \mathrm{H}^{n-r-1+\epsilon}(Z';\overline{\mathbb{Q}}_{\ell})$$

fits into the following commutative diagram:

$$\begin{array}{ccc}
H^{n-r-1-\epsilon}(Z;\overline{\mathbb{Q}}_{\ell}) & \xrightarrow{\smile h^{\epsilon}} H^{n-r-1+\epsilon}(Z;\overline{\mathbb{Q}}_{\ell}) \\
\downarrow^{\wr} & \downarrow \\
H^{n-r-1-\epsilon}(Z';\overline{\mathbb{Q}}_{\ell}) & \xrightarrow{\smile h^{\epsilon}} H^{n-r-1+\epsilon}(Z';\overline{\mathbb{Q}}_{\ell})
\end{array}$$

In the diagram, h denotes the Chern class of the invertible sheaf  $\mathcal{O}_{\mathbb{P}^n}(1)$ . By the Hard Lefschetz theorem, the lower horizontal arrow is an isomorphism. The weak Lefschetz theorem implies that the left vertical arrow is also an isomorphism. Therefore, the right vertical arrow must be surjective. Consequently, for  $e \ge n - r$ , the restriction maps

$$\operatorname{H}^{e}(Z; \overline{\mathbb{Q}}_{\ell}) \to \operatorname{H}^{e}(Z'; \overline{\mathbb{Q}}_{\ell})$$

are all surjective. Hence we obtain short exact sequences

$$0 \to \mathrm{H}^e_c(V; \overline{\mathbb{Q}}_\ell) \to \mathrm{H}^e(Z; \overline{\mathbb{Q}}_\ell) \to \mathrm{H}^e(Z'; \overline{\mathbb{Q}}_\ell) \to 0.$$

It is well-known that for a smooth complete intersection Z in  $\mathbb{P}^n$ , and for any integer e such that  $e \neq \dim Z$  and  $0 \leqslant e \leqslant 2 \dim Z$ , the cohomology group  $\mathrm{H}^e(Z; \overline{\mathbb{Q}}_\ell)$  is one-dimensional if e is even, and zero if e is odd. Thus, the exact sequence implies that for e > n - r, we have  $\mathrm{H}^e_c(V; \overline{\mathbb{Q}}_\ell) = 0$ , except when e = 2(n-r), in which case it is one-dimensional. This completes the proof of the claim.

Now we turn to computing the Euler characteristic numbers. By a Chern class argument, we find that

$$\dim \mathbf{H}_c^{n-r}(V; \overline{\mathbb{Q}}_\ell) + (-1)^{n-r} = (-1)^{n-r} \chi(V) = (-1)^{n-r} [\chi(Z) - \chi(Z')]$$

is  $(-1)^{n-r}d_1\cdots d_r$  times the coefficient of  $h^{n-r}$  in the power series expansion of

$$\frac{(1+h)^{n+1}}{(1+d_1h)\cdots(1+d_rh)} - \frac{h(1+h)^n}{(1+d_1h)\cdots(1+d_rh)} = \frac{(1+h)^n}{(1+d_1h)\cdots(1+d_rh)}.$$

Equivalently, dim  $H_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) + (-1)^{n-r}$  is the coefficient of  $h^{n-r}$  in the power series expansion

$$\frac{d_1\cdots d_r(1-h)^n}{(1-d_1h)\cdots (1-d_rh)}.$$

This coefficient is exactly  $N(n; d_1, \dots, d_r) = M(n; d_1, \dots, d_r) + (-1)^{n-r}$ . It follows that

$$\dim \mathbf{H}_c^{n-r}(V; \overline{\mathbb{Q}}_\ell) = M(n; d_1, \dots, d_r).$$

In the special case  $d_1 = \cdots = d_r = d$ ,  $M(n; d, \ldots, d) + (-1)^{n-r}$  is the coefficient of  $h^{n-r}$  in the power series expansion of

$$\frac{d^{r}(1-h)^{n}}{(1-dh)^{r}} = \frac{1}{d^{n-r}} \frac{((d-1)+(1-dh))^{n}}{(1-dh)^{r}} = \frac{1}{d^{n-r}} \sum_{i=0}^{n} \binom{n}{i} (d-1)^{n-i} (1-dh)^{i-r}.$$

This coefficient is given by

$$\sum_{i=0}^{n} \binom{n}{i} (d-1)^{n-i} (-1)^{n-r} \binom{i-r}{n-r} = \sum_{i=0}^{r-1} \binom{n}{i} (d-1)^{n-i} \binom{n-i-1}{n-r} + (-1)^{n-r}.$$

It follows that

$$M(n;d,\ldots,d) = \sum_{i=0}^{r-1} \binom{n}{i} (d-1)^{n-i} \binom{n-i-1}{r-i-1} \geqslant \binom{n-1}{r-1} (d-1)^n.$$

This proves the lower bound for M(n; d, ..., d). For the upper bound, one checks that

$$M(n; d, \dots, d) \le \binom{n-1}{n-r} \sum_{i=0}^{r-1} \binom{n}{i} (d-1)^{n-i} \le \binom{n-1}{r-1} d^n.$$

<span id="page-18-1"></span>The upper bound for M(n; d, ..., d) is proved.

4.3. Projective complete intersections. Using Theorem 4.2.1, we can obtain bounds for Betti numbers for a complete intersection in a projective space as well.

<span id="page-18-0"></span>**Proposition 4.3.1.** Let  $F_1, \ldots, F_r \in k[x_0, \ldots, x_n]$  be homogeneous polynomials. Let  $X = k[x_0, \ldots, x_n]$  $\{F_1 = \cdots = F_r = 0\} \subset \mathbb{P}^n$ . Assume that

- $\deg F_i \leqslant d$ , and
- $\dim X = n r \geqslant 1$ .

<span id="page-18-3"></span><span id="page-18-2"></span>Then we have

- (i)  $\dim H^j(X; \overline{\mathbb{Q}}_{\ell}) = \dim H^j(\mathbb{P}^n; \overline{\mathbb{Q}}_{\ell})$  for  $j = 0, 1, \dots, n r 1$ , and (ii)  $\dim H^{n-r+j}(X; \overline{\mathbb{Q}}_{\ell}) \leqslant \binom{n-1-j}{r-1} [d^{n-j} + d^{n-j-1} + \dots + d^r]$ , for  $0 \leqslant j \leqslant n r$ .

**Proof.** Applying Lemma 2.3.1 to the pairs  $(Y, D) = (\mathbb{P}^n, \{F_1 = 0\}), (\{F_1 = 0\}, \{F_1 = F_2 = 0\})$  $\{0\}, \ldots, \text{ and eventually to } (\{F_1 = \cdots = F_{r-1} = 0\}, X), \text{ we get } (i).$ 

We prove (ii) by induction on the dimension of X. The base case occurs when X is a zerodimensional complete intersection, i.e., when n=r. In this case, we have  $H^0(X; \overline{\mathbb{Q}}_{\ell}) \leq d^n$ , which is stronger than (ii).

We now establish the induction step and assume n > r. Let A be a sufficiently general hyperplane in  $\mathbb{P}^n$ . Then  $X \cap A$  is a complete intersection in the projective space A of one dimension lower. The complement  $V = X - (X \cap A)$  is a complete intersection in the affine space  $\mathbb{A}^n = \mathbb{P}^n - A$ . We obtain the following exact sequence:

$$(4.3.2)$$

It follows from Corollary 4.2.4 that dim  $H^{n-r+j}(X; \overline{\mathbb{Q}}_{\ell})$  is

$$\leq \dim \mathbf{H}_c^{n-r+j}(V; \overline{\mathbb{Q}}_\ell) + \dim \mathbf{H}^{(n-1-r)+(j+1)}(X \cap A; \overline{\mathbb{Q}}_\ell)$$

$$\leq \binom{n-1-j}{r-1} d^{n-j} + \binom{n-j-3}{r-1} \left\{ d^{n-1-(j+1)} + \dots + d^r \right\}$$

$$\leq \binom{n-1-j}{r-1} \left\{ d^{n-j} + d^{n-j-1} + \dots + d^r \right\}.$$

This completes the induction.

**Remark.** Maxim, Pănescu, and Tibăr [MPT22, Corollary 1.5] showed that for any complex projective hypersurface X in  $\mathbb{P}^n$  of degree d, we have

$$\dim \mathbf{H}^{n-1}(X;\mathbb{Q}) \leqslant \frac{(d-1)^{n+1} + (-1)^n}{d} + \frac{3(-1)^{n-1} + 1}{2},$$

which provides a more accurate bound than Proposition 4.3.1(ii) when j = 0, r = 1.

4.4. **Application: Lang—Weil type estimates.** The bounds for the compactly supported Betti numbers immediately imply some effective Lang—Weil type estimates. We begin with the affine version.

<span id="page-19-0"></span>**Proposition 4.4.1.** Let V be a geometrically irreducible closed subvariety of  $\mathbb{A}^n_{\mathbb{F}_q}$  defined by r polynomials of degree  $\leq d$ . Assume that  $\dim V = n - r$ . Then

$$|\operatorname{Card} V(\mathbb{F}_q) - q^{n-r}| \leqslant \sum_{j=0}^{n-r-1} {n-j-1 \choose r-1} d^{n-j} q^{\frac{n-r+j}{2}} < {n-1 \choose r-1} (d+1)^n q^{n-r-\frac{1}{2}}.$$

**Proof.** Fix an algebraic closure  $\overline{\mathbb{F}}_q$  of  $\mathbb{F}_q$ . Let  $V_{\overline{\mathbb{F}}_q} = V \otimes_{\mathbb{F}_q} \overline{\mathbb{F}}_q$ . By Grothendieck's trace formula, we have

$$\operatorname{Card} V(\mathbb{F}_q) = \sum_{i=0}^{n-r} (-1)^j \operatorname{Tr}(F|\mathcal{H}_c^{n-r+j}(V_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_{\ell})).$$

Since V is assumed to be geometrically irreducible,  $\mathrm{H}^{2n-2r}_c(V_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell) \simeq \overline{\mathbb{Q}}_\ell(-n+r)$ . Therefore, the trace formula can be written as

$$\operatorname{Card} V(\mathbb{F}_q) - q^{n-r} = \sum_{i=0}^{n-r-1} (-1)^j \operatorname{Tr}(F|\mathcal{H}_c^{n-r+j}(V_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell)).$$

By Deligne's fundamental theorem of weights, the Frobenius eigenvalues of  $H_c^{n-r+j}(V_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell)$  are Weil q-numbers of weight  $\leqslant n-r+j$ . Therefore,

$$|\operatorname{Card} V(\mathbb{F}_q) - q^{n-r}| \leqslant \sum_{j=0}^{n-r-1} |\operatorname{Tr}(F| \mathbb{H}_c^{n-r+j}(V_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell))|.$$

By Corollary 4.2.4, for each j,  $F|_{H_c^{n-r+j}(V;\overline{\mathbb{Q}}_{\ell})}$  has at most  $\binom{n-j-1}{r-1}d^{n-j}$  eigenvalues. The desired estimates then follow.

The estimates for the Betti numbers of a projective complete intersection give the following more refined effective version of the classical Lang-Weil estimate [LW54].

**Proposition 4.4.2.** Let q be a power of p. Let X be the Zariski closed subset in  $\mathbb{P}_{\mathbb{F}_q}^n$  defined by the common zeros of polynomials  $F_1, \ldots, F_r \in \mathbb{F}_q[x_1, \ldots, x_n]$ . Suppose that dim  $X = n - r \geqslant 2$ , X is geometrically irreducible, and deg  $F_i \leqslant d$ . Let  $\epsilon$  be the dimension of the singular locus of X. Then

$$\left| \operatorname{Card} X(\mathbb{F}_q) - \sum_{j=0}^{n-r} q^j \right| < \binom{n-1}{r-1} (d+2)^n q^{\frac{n-r+\epsilon+1}{2}}.$$

If X is nonsingular, we make the convention that  $\epsilon = -1$ .

**Proof.** Since we assumed that dim  $X \ge 2$ , the complete intersection condition ensures that X is normal, so that  $\epsilon \le n - r - 2$ .

Let A be a generic  $(n-\epsilon-1)$ -dimensional linear subspace of  $\mathbb{A}^n_{\overline{\mathbb{F}}_q}$ . By Lemma 2.3.3, applied to the perverse sheaf  $\mathcal{F} = \overline{\mathbb{Q}}_{\ell}[n]$ , we find that the Gysin map

$$\mathrm{H}^{n-r-\epsilon-1+i}(X_{\overline{\mathbb{F}}_q}\cap A;\overline{\mathbb{Q}}_\ell)(-\epsilon-1)\to\mathrm{H}^{n-r+\epsilon+1+i}(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell)$$

is surjective if i = 0, and bijective if i > 0. Similarly, by the weak Lefschetz theorem, for i > 0, the restriction map

$$\mathrm{H}^{n-r-\epsilon-1-i}(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell) \to \mathrm{H}^{n-r-\epsilon-1-i}(X_{\overline{\mathbb{F}}_q}\cap A;\overline{\mathbb{Q}}_\ell)$$

is injective if i=0, and bijective if i>0. Thus, if  $j\in\mathbb{Z}, n-r>|j|>\epsilon+1$ , we have  $\mathrm{H}^{n-r+j}(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell)\simeq\overline{\mathbb{Q}}_\ell(-\frac{n-r+j}{2})$  if n-r+j is even, and zero otherwise. Combining this with the fact that  $\mathrm{H}^0(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell)=\overline{\mathbb{Q}}_\ell$ , that  $\mathrm{H}^{2n-2r}(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell)=\overline{\mathbb{Q}}_\ell(-n-r)$ , and Deligne's theorem asserting that  $\mathrm{H}^i(X_{\overline{\mathbb{F}}_q};\overline{\mathbb{Q}}_\ell)$  has weight  $\leqslant i$ , we find that

$$\left| \operatorname{Card} X(\mathbb{F}_q) - \sum_{j=0}^{n-r} q^j \right| \leqslant \sum_{0 \leqslant |j| \leqslant \epsilon + 1} q^{\frac{n-r+j}{2}} \dim \mathcal{H}^{n-r+j}_{\operatorname{prim}}(X_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_{\ell}).$$

Here,  $H^*_{\mathrm{prim}}(X_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell)$  is defined as the cokernel of the map  $H^*(\mathbb{P}^n; \overline{\mathbb{Q}}_\ell) \to H^*(X_{\overline{\mathbb{F}}_q}; \overline{\mathbb{Q}}_\ell)$ . Since  $H^*_{\mathrm{prim}}$  is a quotient of  $H^*$ , we may conclude by applying Corollary 4.3.1.

This, combined with the excision sequence, gives the following affine version which improves Proposition 4.4.1 if V is not too singular.

**Proposition 4.4.3.** Let V be an affine variety in  $\mathbb{A}^n_{\mathbb{F}_q}$  defined by r polynomials of degree  $\leq d$ . Let  $V_{\infty}$  be the infinite part of V in  $\mathbb{P}^n_{\mathbb{F}_q}$ . Assume that  $\dim V = n - r = \dim V_{\infty} + 1 \geq 2$  (thus, both V and  $V_{\infty}$  are complete intersection), and assume that both V and  $V_{\infty}$  are geometrically irreducible. Let  $\epsilon$  be the dimension for the singular locus of the projective complete intersection  $V \cup V_{\infty}$  in  $\mathbb{P}^n_{\mathbb{F}_q}$ . Then

$$|\operatorname{Card} V(\mathbb{F}_q) - q^{n-r}| \leqslant {n-1 \choose r-1} (d+1)^n q^{\frac{n-r+\epsilon+1}{2}}.$$

#### 5. Bounds for exponential sums

<span id="page-20-0"></span>In this section, k is a fixed algebraic closure of a finite field  $\mathbb{F}_q$ . All varieties are defined over k.

We fix a nontrivial additive character  $\psi \colon \mathbb{F}_p \to \mathbb{C}^*$ . Denote by  $\mathcal{L}_{\psi}$  the Artin–Schreier sheaf on  $\mathbb{A}^1_{\mathbb{F}_n}$  or  $\mathbb{A}^1_k$ .

We will use the specialization lemma (Lemma 3.1) to investigate the "Artin–Schreier cohomology spaces"  $H_c^*(U; f^*\mathcal{L}_{\psi})$  associated with exponential sums. The primary challenge is that, to derive meaningful bounds using the specialization lemma, we must maintain numerical control over the Artin–Schreier cohomology of a generic function. Most of Section 5.1 is dedicated to establishing a framework for determining this generic behavior. The main result, presented in Theorem 5.2.1, shows that within a large family, the generic Artin–Schreier cohomology is nontrivial only in the middle degree, thereby allowing it to be bounded by Euler characteristics. We also provide a precise mathematical definition of what is meant by "large". This result is well-known when the generic member is tamely ramified or under additional hypotheses such as properness or ampleness. However, for our applications, including those involving toric exponential sums, we cannot afford to make such strong assumptions.

Therefore, we have formulated Theorem 5.2.1 as broadly as possible, which justifies the length of this subsection.

The remaining subsections are dedicated to applications of the specialization method and the generic bound. The first application lies within a framework designed by Katz, discussed in Section 5.3, which leads to the proof of Theorem 1.3.10(ii). The second application (Section 5.4) focuses on the toric case, where we prove the cohomological enhancement (Theorem 5.4.8) of the Adolphson–Sperber total degree bound given in equation (AS). Finally, we give the proof of Theorem 1.1.2 in §5.5.

<span id="page-21-0"></span>5.1. **General method.** Our basic setup for studying exponential sums is the following (cf. [KL85,  $\S5$ ]). Let U be an affine variety over k of pure dimension n. Suppose we are given a morphism

$$u: U \to \mathbb{A}^N, \quad x \mapsto (u_1(x), \dots, u_N(x))$$

Then for any  $a = (a_1, \ldots, a_N) \in \check{\mathbb{A}}^N$  (the dual affine space), we can define a regular function

$$f_a: U \to \mathbb{A}^1, \quad x \mapsto \sum_{i=1}^N a_i u_i(x).$$

When a varies in  $\check{\mathbb{A}}^N$ , we get a family of morphisms

$$U \times \check{\mathbb{A}}^N \xrightarrow{f} \mathbb{A}^1$$

$$\downarrow^{\operatorname{pr}_2}$$

$$\check{\mathbb{A}}^N$$

The cohomological counterpart of the variation of the exponential sums defined by  $f_a$  is the  $\ell$ -adic complex  $Rpr_{2!}(f^*\mathcal{L}_{\psi})$ . By proper base change, for any  $b \in \check{\mathbb{A}}^N$ ,

$$R^i \operatorname{pr}_{2!}(f^* \mathcal{L}_{\psi})_b = \operatorname{H}_c^i(U; f_b^* \mathcal{L}_{\psi}).$$

By constructibility, there is a Zariski open dense subset  $\mathcal{U}$  of  $\check{\mathbb{A}}^N$  over which  $R^i \operatorname{pr}_{2!}(f^* \mathcal{L}_{\psi})$  are local systems for all i.

If U is defined over a finite field  $\mathbb{F}_q$ , i.e.,  $U = U_0 \otimes_{\mathbb{F}_q} k$  for some  $\mathbb{F}_q$ -scheme  $U_0$ , then  $b \colon \operatorname{Spec} k \to U \to U_0$  factors through some  $\mathbb{F}_{q^m}$ -valued point of  $U_0$  for some  $m \colon$ 

$$b: \operatorname{Spec} k \to \operatorname{Spec}(\mathbb{F}_{q^m}) \xrightarrow{b_0} U_0.$$

We can then discuss the  $q^m$ -power geometric Frobenius operation on both sides. The Newton polygon of  $\det(1 - tF_{b_0}|\mathbf{H}_c^i(U; f_b^*\mathcal{L}_{\psi}))$  with respect to  $\mathrm{ord}_{q^m}$  is independent of the possible  $\mathbb{F}_{q^m}$ -point  $b_0$  through which b factors.

<span id="page-21-1"></span>**Theorem 5.1.1.** Suppose that U is a purely n-dimensional local complete intersection affine variety. If  $a \in \mathcal{U}$  and  $b \in \mathbb{A}^N$  is arbitrary, then

$$\dim \mathcal{H}_{c}^{n}(U; f_{b}^{*}\mathcal{L}_{\psi}) \leqslant \dim \mathcal{H}_{c}^{n}(U; f_{a}^{*}\mathcal{L}_{\psi}).$$

**Proof.** For an arbitrary  $b \in \mathbb{A}^N$ , we join b and  $a \in \mathcal{U}_{\psi}$  by a smooth curve B in  $\mathbb{A}^N$  (e.g., a straight line). This gives rise to the following commutative diagram

$$U \times B \xrightarrow{\iota'} U \times \check{\mathbb{A}}^N \xrightarrow{f} \mathbb{A}^1$$

$$\downarrow^{\operatorname{pr}_2'} \qquad \downarrow^{\operatorname{pr}_2}$$

$$B \xrightarrow{\iota} \check{\mathbb{A}}^N$$

in which the left square is Cartesian. By proper base change, we have

$$R\operatorname{pr}'_{2!}((f \circ \iota')^* \mathcal{L}_{\psi}) = \iota^* R\operatorname{pr}_{2!}(f^* \mathcal{L}_{\psi}).$$

Since  $B \cap \mathcal{U} \neq \emptyset$ , for any  $a \in B \cap \mathcal{U}$ , and any i, the dimension of  $H_c^i(U; f_a^* \mathcal{L}_{\psi})$  is constant in a. Since  $f^* \mathcal{L}_{\psi}[N+n]$  is a perverse sheaf on  $U \times \check{\mathbb{A}}^N$  (cosupport condition follows from Lemma 2.1.1, the support condition is trivially satisfied), and since  $\operatorname{pr}_2$  is an affine morphism, Lemma 3.1 implies the desired result.

<span id="page-22-0"></span>Variant 5.1.2. Let notation and conventions be as in Theorem 5.1.1. Suppose  $U = U_0 \otimes_{\mathbb{F}_q} k$  is a k-variety defined over  $\mathbb{F}_q$ , and there is a convex polygon  $\Gamma$ , and a Zariski open subset  $\mathcal{U}_{\Gamma} \subset \mathcal{U}$ , such that for all  $a \in \mathcal{U}_{\Gamma}$ , the Newton polygon of  $H^n_c(U; f_a^* \mathcal{L}_{\psi})$  lies on or above  $\Gamma$ . Then for any  $b \in \check{\mathbb{A}}^N$ , the Newton polygon of  $H^n_c(U; f_b^* \mathcal{L}_{\psi})$  lies on or above  $\Gamma$ .

**Proof.** Apply Variant 3.4.

5.2. A variant of the generic vanishing theorem of Katz-Laumon. Theorem 5.1.1 shows that dim  $H_c^n(U; f_b^* \mathcal{L}_{\psi})$  for b generic is an upper bound for dim  $H_c^n(U; f_b^* \mathcal{L}_{\psi})$  for b arbitrary. But how do we determine the former? The following theorem shows that if this  $\check{\mathbb{A}}^N$  is a "large family", in the sense that u is a quasi-finite morphism, then we can use the Euler characteristic to calculate this bound.

<span id="page-22-1"></span>**Theorem 5.2.1.** Let U be a purely n-dimensional local complete intersection affine variety. Suppose that  $u: U \to \mathbb{A}^N$  is quasi-finite. Then there is a Zariski open dense subset  $\mathcal{U}$  of  $\check{\mathbb{A}}^N$  such that for any  $a \in \mathcal{U}$ ,

- <span id="page-22-2"></span>(i)  $\mathrm{H}_c^i(U; f_a^* \mathcal{L}_{\psi}) = \mathrm{H}^i(U; f_a^* \mathcal{L}_{\psi}) = 0$  for any  $i \neq n$ ,
- (ii) dim  $H_c^n(U; f_a^* \mathcal{L}_{\psi}) \leq (-1)^n (\chi(U) \chi(f_a^{-1}(t)))$  for  $t \in \mathbb{A}^1$  sufficiently general.

**Remark.** Theorem 5.2.1(i) is due to Katz and Laumon [KL85, Théorème 5.5.1(ii)] when u is finite and U is smooth and irreducible. If f is tamely ramified at  $\infty$  (for example, when (U, f) arises from a *sufficiently general* mod p reduction of a spread-out of a complex variety), it can be shown that equality holds in the second item.

For our purposes, even when focusing on exponential sums defined on a nonsingular space, we must employ the Lefschetz theorem to address non-middle cohomology degrees. Consequently, we need to investigate the Artin–Schreier cohomology on a singular U. Additionally, even for toric exponential sums, the morphism u may not be finite.

We note that if U is smooth, irreducible and u is finite, then Katz and Laumon also established the purity of the Artin–Schreier cohomology. This purity theorem does not hold in general when u is only assumed to be quasi-finite.

To prove Theorem 5.2.1, we will first establish some general lemmas regarding the cohomology spaces of the Artin–Schreier sheaves. While various forms of these lemmas are well-known to specialists, they have typically been proven only in the tame ramification case, avoiding wild ramification. Our approach will handle both cases uniformly.

<span id="page-22-3"></span>**Lemma 5.2.2.** Let U be a purely n-dimensional affine variety. Let  $f: U \to \mathbb{A}^1$  be a regular function. Assume that the direct images  $R^i f_* \overline{\mathbb{Q}}_{\ell}$  are tamely ramified for  $i \neq n-1$ . Then

$$(-1)^n \chi(U; f^* \mathcal{L}_{\psi}) \leq (-1)^n [\chi(U) - \chi(F)],$$

where F is a general fiber of f.

If  $R^{n-1}f_*\overline{\mathbb{Q}}_\ell$  also exhibits tame ramification at infinity, then the Grothendieck–Ogg–Shafarevich theorem implies that equality holds. The complexity arises from the presence of wild ramification. Fortunately, a general principle applies here: the occurrence of wild ramification will only reduce the dimension of the space of interest.

**Proof.** Since  $\mathcal{L}_{\psi}$  is a local system, the projection formula also works for the direct image functor:

$$Rf_*(f^*\mathcal{L}_{\psi}) = (Rf_*\overline{\mathbb{Q}}_{\ell}) \otimes \mathcal{L}_{\psi}$$

(cf. [FK88, Proposition 8.14, Remark (2)]). This gives us a spectral sequence

$$E_2^{a,b} = \mathrm{H}^a(\mathbb{A}^1; R^b f_* \overline{\mathbb{Q}}_\ell \otimes \mathcal{L}_\psi) \Rightarrow \mathrm{H}^{a+b}(U; f^* \mathcal{L}_\psi),$$

Taking Euler characteristics gives

$$\chi(U; f^* \mathcal{L}_{\psi}) = \sum_{i} (-1)^{n-i} \chi(\mathbb{A}^1; R^i f_* \overline{\mathbb{Q}}_{\ell}).$$

We shall analyze the key factor  $\chi(\mathbb{A}^1; R^{n-1}f_*\overline{\mathbb{Q}}_\ell)$  below. To avoid using overly cumbersome notation, let us introduce a shorthand  $\mathcal{E} = R^{n-1}f_*\overline{\mathbb{Q}}_\ell$ .

By generic base change, the rank of the monodromy representation  $\mathcal{E}_{(\infty)}$  of  $\mathcal{E}$  at infinity of  $\mathbb{A}^1$  equals dim  $\mathrm{H}^{n-1}(F;\overline{\mathbb{Q}}_{\ell})$ . The monodromy representation has a break decomposition (cf. [Kat88, §§1.1–1.10])

$$\mathcal{E}_{(\infty)} = \bigoplus_{s} E_{s},$$

where  $E_s$  is the summand of pure break s. By the Grothendieck-Ogg-Shafarevich formula, using the fact that  $\mathcal{L}_{\psi}$  is unramified at any point of  $\mathbb{A}^1$ , we have

<span id="page-23-0"></span>(5.2.3) 
$$\chi(\mathbb{A}^1; \mathcal{E} \otimes \mathcal{L}_{\psi}) = \chi(\mathbb{A}^1; \mathcal{E}) + \operatorname{Sw}(\mathcal{E}_{(\infty)}) - \operatorname{Sw}(\mathcal{E}_{(\infty)} \otimes \mathcal{L}_{\psi(\infty)}).$$

Since  $\mathcal{L}_{\psi}$  is pure of break one at infinity, for each s < 1,  $E_s \otimes \mathcal{L}_{\psi(\infty)}$  has Swan conductor equal to rank $(E_s)$ . Similarly, for s > 1, the Swan conductor of  $E_s \otimes \mathcal{L}_{\psi(\infty)}$  equals the Swan conductor of  $E_s$ . It might happen that there exists some irreducible subrepresentation G of  $E_1$  where  $G \otimes \mathcal{L}_{\psi(\infty)}$  has break < 1. If so, the Swan conductor of  $E_1 \otimes \mathcal{L}_{\psi(\infty)}$  will become smaller than that of  $E_1$ :

$$\operatorname{Sw}(\mathcal{E}_{(\infty)} \otimes \mathcal{L}_{\psi(\infty)}) - \operatorname{Sw}(\mathcal{E}_{(\infty)}) = \sum_{s < 1} (1 - s) \dim E_s - \left[\operatorname{Sw}(E_1) - \operatorname{Sw}(E_1 \otimes \mathcal{L}_{\psi(\infty)})\right]$$

$$\leqslant \dim \bigoplus_{s < 1} E_s \leqslant \dim \mathcal{E}_{(\infty)} = \dim \operatorname{H}^{n-1}(F; \overline{\mathbb{Q}}_{\ell}),$$

where F is a generic fiber of f. It then follows from (5.2.3) that

<span id="page-23-2"></span>(5.2.4) 
$$-\chi(\mathbb{A}^1; \mathcal{E} \otimes \mathcal{L}_{\psi}) \leqslant \dim \mathcal{H}^{n-1}(F; \overline{\mathbb{Q}}_{\ell}) - \chi(\mathbb{A}^1; \mathcal{E}).$$

On the other hand, since  $R^i f_* \overline{\mathbb{Q}}_{\ell}$  are assumed to be tamely ramified at infinity for  $i \neq n-1$ , the Grothendieck–Ogg–Shafarevich formula implies that

<span id="page-23-1"></span>
$$(5.2.5) \chi(\mathbb{A}^1; R^i f_* \overline{\mathbb{Q}}_{\ell} \otimes \mathcal{L}_{\psi}) = \chi(\mathbb{A}^1; R^i f_* \overline{\mathbb{Q}}_{\ell}) - \dim H^i(F; \overline{\mathbb{Q}}_{\ell}) \text{for any } i \neq n-1.$$

Therefore

$$(-1)^{n}[\chi(U) - \chi(F)] = \sum_{i=0}^{n} (-1)^{n-i} [\chi(\mathbb{A}^{1}; R^{i} f_{*} \overline{\mathbb{Q}}_{\ell}) - \dim \mathcal{H}^{i}(F; \overline{\mathbb{Q}}_{\ell})]$$

$$[\text{by } (5.2.5)] = -\chi(\mathbb{A}^{1}; \mathcal{E}) + \dim \mathcal{H}^{n-1}(F; \overline{\mathbb{Q}}_{\ell}) + \sum_{i \neq n-1} (-1)^{n-i} \chi(\mathbb{A}^{1}; R^{i} f_{*} \overline{\mathbb{Q}}_{\ell} \otimes \mathcal{L}_{\psi})$$

$$[\text{by } (5.2.4)] \geqslant -\chi(\mathbb{A}^{1}; \mathcal{E} \otimes \mathcal{L}_{\psi}) + \sum_{i \neq n-1} (-1)^{n-i} \chi(\mathbb{A}^{1}; R^{i} f_{*} \overline{\mathbb{Q}}_{\ell} \otimes \mathcal{L}_{\psi})$$

$$= (-1)^{n} \chi(U; f^{*} \mathcal{L}_{\psi}).$$

This completes the proof of the lemma.

The second lemma concerns the vanishing of Artin–Schreier cohomology. We shall state it more generally using the language of the perverse t-structure. In our applications, U will be a purely n-dimensional local complete intersection affine variety and  $\mathcal{P}$  will be the shifted constant local system  $\overline{\mathbb{Q}}_{\ell}[n]$ .

<span id="page-24-0"></span>**Lemma 5.2.6.** Let U be a purely n-dimensional affine scheme. Let  $\mathcal{P}$  be a constructible complex on U satisfying the support condition (i.e.,  $\mathcal{P} \in {}^{p}\mathcal{D}_{U}^{\leq 0}$  for the selfdual perversity). Let  $f: U \to \mathbb{A}^{1}$  be a morphism such that the "weak Lefschetz" property holds for general  $t \in \mathbb{A}^{1}$ . This means that for all but finitely many  $t \in \mathbb{A}^{1}$ , the restriction map

$$\mathrm{H}^m(U;\mathcal{P}) \to \mathrm{H}^m(f^{-1}(t);\mathcal{P})$$

is injective for m=-1 and bijective for m<-1. Then for all but finitely many  $\lambda \in k^{\times}$ , we have

$$H^m(U; \mathcal{P} \otimes (\lambda f)^* \mathcal{L}_{\psi}) = 0$$

for any  $m \neq 0$ .

Lemma 5.2.6 is similar to [DL91, Proposition 3.1] and [KL85, Théorème 5.5.1(ii)] when U is smooth and  $\mathcal{P} = \overline{\mathbb{Q}}_{\ell}[n]$ . Since we do not impose any smoothness condition on U, we cannot expect the validity of the "purity" part of these cited theorems.

**Proof.** Since  $\mathcal{P}$  satisfies the support condition, so does  $\mathcal{P} \otimes f^*\mathcal{L}_{\psi}$ . By Artin's vanishing theorem,  $H^m(U; \mathcal{P} \otimes f^*\mathcal{L}_{\psi}) = 0$  for m > 0. We shall now assume that m < 0. Since U is affine, f is an affine morphism. Therefore, by Artin's vanishing theorem,  $Rf_*\mathcal{P}$  satisfies the support condition, i.e., it only has non-positive perverse cohomology sheaves:  ${}^{\mathrm{p}}R^jf_*\mathcal{P} = 0$  for j > 0. We also have  $Rf_*(\mathcal{P} \otimes f^*\mathcal{L}_{\psi}) = (Rf_*\mathcal{P}) \otimes \mathcal{L}_{\psi}$ . Because twisting by a global local system of rank one is a t-exact operation, we have

$${}^{\mathrm{p}}R^{j}f_{*}(\mathcal{P}\otimes f^{*}\mathcal{L}_{\psi})=({}^{\mathrm{p}}R^{j}f_{*}\mathcal{P})\otimes\mathcal{L}_{\psi}.$$

The Leray spectral sequence for  $Rf_*(\mathcal{P} \otimes f^*\mathcal{L}_{\psi})$  reads:

$$E_2^{i,j} = \mathrm{H}^i(\mathbb{A}^1; \mathcal{L}_{\psi} \otimes {}^{\mathrm{p}}R^j f_* \mathcal{P}) \Rightarrow \mathrm{H}^{i+j}(U; \mathcal{P} \otimes f^* \mathcal{L}_{\psi}).$$

By Artin's vanishing theorem, for any perverse sheaf  $\mathcal{Q}$  on  $\mathbb{A}^1$ , we have  $H^i(\mathbb{A}^1; \mathcal{Q}) = 0$  if  $i \neq 0, -1$ . Thus, only possible nonzero terms are  $E^{-1,j}$  and  $E^{0,j}$   $(j \leq 0)$ . The spectral sequence thereby degenerates into a collection of short exact sequences

$$0 \to \mathrm{H}^0(\mathbb{A}^1; \mathcal{L}_{\psi} \otimes {}^{\mathrm{p}}R^m f_* \mathcal{P}) \to \mathrm{H}^m(U; \mathcal{P} \otimes f^* \mathcal{L}_{\psi}) \to \mathrm{H}^{-1}(\mathbb{A}^1; \mathcal{L}_{\psi} \otimes {}^{\mathrm{p}}R^{m+1} f_* \mathcal{P}) \to 0.$$

Similarly, degeneration of the Leray spectral sequence of  $Rf_*\mathcal{P}$  gives exact sequences:

$$(5.2.7) 0 \to \mathrm{H}^0(\mathbb{A}^1; {}^{\mathrm{p}}R^m f_* \mathcal{P}) \to \mathrm{H}^m(U; \mathcal{P}) \xrightarrow{\beta} \mathrm{H}^{-1}(\mathbb{A}^1; {}^{\mathrm{p}}R^{m+1} f_* \mathcal{P}) \to 0.$$

<span id="page-24-2"></span><span id="page-24-1"></span>The lemma will be proved if the following assertions are established:

- <span id="page-24-4"></span>(i) For  $m \leq 0$ ,  $H^{-1}(\mathbb{A}^1; {}^{\mathbf{p}}R^m f_* \mathcal{P} \otimes \mathcal{L}_{\psi}) = 0$ .
- (ii) For  $m \leq -1$ ,  $H^0(\mathbb{A}^1; {}^{\mathrm{p}}R^m f_* \mathcal{P} \otimes \mathcal{L}_{\psi}) = 0$ .

We shall show that (i) is true for any  $m \le -1$ , and when m = 0, (i) is true after scaling f by a generic nonzero number  $\lambda$  in k. The assertion (ii) is true for any  $m \le -1$ .

To simplify the notation, let  $\mathcal{F} = {}^{\mathrm{p}}R^m f_* \mathcal{P}$ . Let  $j \colon V \to \mathbb{A}^1$  be the "ouvert de lissité" of  $\mathcal{F}$ , and let  $a \colon \Sigma \to \mathbb{A}^1$  be the inclusion of the complement of V. Thus  $\mathcal{F}|_V = \mathcal{E}[1]$ , and  $\mathcal{E} = (R^{m-1}f_*\mathcal{P})|_V$  is a local system on V. Then we form the following distinguished triangle

<span id="page-24-3"></span>
$$(5.2.8) \mathcal{F} \to (R^0 j_* \mathcal{E})[1] \to \mathcal{F}_{\Sigma} \xrightarrow{+1},$$

where  $\mathcal{F}_{\Sigma}$  is the cone of  $\mathcal{F} \to (R^0 j_* \mathcal{E})[1]$ . Similarly, we have the following distinguished triangle:

$$(5.2.9) \mathcal{F} \otimes \mathcal{L}_{\psi} \to (R^0 j_* (\mathcal{E} \otimes \mathcal{L}_{\psi}))[1] \to \mathcal{F}_{\Sigma} \xrightarrow{+1}$$

Note that the two triangles (5.2.8) and (5.2.9) have the same cone. This is because for each  $b \in \Sigma$ ,  $\mathcal{L}_{\psi}$  is unramified at b.

<span id="page-25-1"></span>Claim 5.2.10. Assume that  $m \leq 0$ . Then the map  $\alpha \colon \mathrm{H}^{-1}(\mathbb{A}^1; \mathcal{F}) \to \mathrm{H}^0(V; \mathcal{E})$  (induced by (5.2.8)) is injective, and  $\beta \colon \mathrm{H}^{m-1}(U; \overline{\mathbb{Q}}_{\ell}) \to \mathrm{H}^{-1}(\mathbb{A}^1; \mathcal{F})$  is bijective.

**Proof of Claim 5.2.10.** The surjectivity of  $\beta$  is seen from (5.2.7). We have a commutative diagram

<span id="page-25-0"></span>
$$\begin{array}{ccc}
H^{-1}(\mathbb{A}^{1};\mathcal{F}) & \xrightarrow{\alpha} & H^{0}(V;\mathcal{E}|_{V}) \\
\beta \uparrow & & & & \\
H^{m-1}(U;\mathcal{P}) & \longleftrightarrow & H^{m-1}(f^{-1}(t);\mathcal{P})^{\pi_{1}(V)}
\end{array}$$

The right two spaces are identified because V is the ouvert de lissité of  $\mathcal{F}$ . The bottom arrow is injective thanks to the "weak Lefschetz" hypothesis. Since  $\beta \circ \alpha$  is injective and  $\beta$  is surjective, we conclude that  $\alpha$  is injective and  $\beta$  is bijective.

We now turn to the proof of (i). It is clear from the presentation (5.2.8) that  $\mathcal{F}_{\Sigma}$  has possibly nonzero perverse cohomology only in degree -1 and 0. The injectivity of  $\alpha$  proved in Claim 5.2.10 implies that  $H^{-1}(\mathbb{A}^1; \mathcal{F}_{\Sigma}) = 0$ . From (5.2.9) we deduce that  $H^{-1}(\mathbb{A}^1; \mathcal{F} \otimes \mathcal{L}_{\psi})$  is a subspace of  $H^0(V; \mathcal{E} \otimes \mathcal{L}_{\psi})$ . It suffices to prove, therefore, for  $m \leq 0$ ,  $H^0(V; \mathcal{E} \otimes \mathcal{L}_{\psi}) = 0$ . When  $m \leq -1$ , this is immediate: the weak Lefschetz hypothesis implies that  $\mathcal{E}$  is isomorphic to the constant local system  $H^{m-1}(U; \mathcal{P})$ , hence must be tamely ramified; but then  $\mathcal{E} \otimes \mathcal{L}_{\psi}$  will have wild ramification at  $\infty$ , forcing  $\mathcal{E} \otimes \mathcal{L}_{\psi}$  to have no nonzero sections.

When m=0, it might happen that  $\mathcal{E}$  has wild ramification at  $\infty$ . The assertion (i) may not be true for f, so we might have to choose a different scaling factor  $\lambda$ . Let us use  $\mathcal{E}_{(\infty)}$  to denote the representation of the inertia group of  $\infty \in \mathbb{P}^1$  induced by  $\mathcal{E}$ . Then  $\mathcal{E}_{(\infty)}$  admits a break decomposition

$$\mathcal{E}_{(\infty)} = \bigoplus_{s \geqslant 0} E_s,$$

where  $E_s$  is a representation of the inertia which has only one break s (cf. [Kat88, 1.8 below]). Let  $L_{\mu}$  be any rank one nontrivial representation of the inertia at infinity induced by the Artin–Schreier extension

$$k((t^{-1}))[y]/(y^p - y - \mu t)$$
 (t being the coordinate of  $\mathbb{A}^1$ ).

Such a representation has pure break 1. If  $H^0(V; \mathcal{E} \otimes \mathcal{L}_{\psi}) \neq 0$ , then in the break decomposition of  $\mathcal{E}_{(\infty)}$ ,  $E_1$  must contain some copies of  $L_1$  as its subrepresentation. Furthermore,  $E_1$  may contain some other  $L_{\mu}$  as its subrepresentation. But there are only finitely many such  $\mu$ .

Now let us consider the composition

$$X \xrightarrow{f} \mathbb{A}^1 \xrightarrow{\lambda} \mathbb{A}^1$$
.

where we also denote the multiplication-by- $\lambda$  morphism by  $\lambda$ . Let  $\mathcal{F}_{\lambda} = {}^{p}R^{0}(\lambda f)_{*}\mathcal{P} = \lambda_{*}\mathcal{F}$ . Since  $\lambda$  is an isomorphism, we have

$$\lambda^*(\mathcal{F}_{\lambda}\otimes\mathcal{L}_{\psi})=\mathcal{F}\otimes\lambda^*\mathcal{L}_{\psi},$$

Now

$$(\mathcal{F} \otimes \lambda^* \mathcal{L}_{\psi})_{(\infty)} = \mathcal{E}_{(\infty)}[1] \otimes L_{\lambda}.$$

Thus, so long as  $\lambda$  is not equal to  $\mu^{-1}$ , where  $L_{\mu}$  is a subrepresentation of  $E_1$ ,  $\mathcal{E}_{(\infty)} \otimes L_{\lambda}$  has no trivial subrepresentation. Since  $\lambda$ :  $\mathbb{A}^1 \to \mathbb{A}^1$  is an isomorphism, we conclude that  $\mathcal{F}_{\lambda} \otimes \mathcal{L}_{\psi}$  has trivial  $\mathrm{H}^{-1}$  over any open set on which it is lisse. Thus we may use  $\lambda f$  in place of f, and the assertion (i) for m=0 is proved.

Let us now prove (ii) for  $m \leq -1$ . In this situation, the weak Lefschetz hypothesis implies that  $\mathcal{E}$  is a constant local system associated to the vector space  $H^{m-1}(U;\mathcal{P})$ , hence is tamely ramified at  $\infty$ . Using the result of (i), we have  $H^{-1}(\mathbb{A}^1;\mathcal{F}\otimes\mathcal{L}_{\psi})=0$ . Recall that the Grothendieck-Ogg-Shafarevich formula says that

$$\dim H^0(\mathbb{A}^1; \mathcal{F} \otimes \mathcal{L}_{\psi}) - \dim H^{-1}(\mathbb{A}^1; \mathcal{F} \otimes \mathcal{L}_{\psi})$$

equals

$$\dim \mathrm{H}^0(\mathbb{A}^1;\mathcal{F}) - \dim \mathrm{H}^{-1}(\mathbb{A}^1;\mathcal{F}) - \mathrm{Sw}(\mathcal{F}_{(\infty)} \otimes \mathcal{L}_{\psi(\infty)}).$$

Therefore, it suffices to prove the above number is zero. By Claim 5.2.10, the mapping  $\beta$  in (5.2.7) is bijective. This shows that  $H^0(\mathbb{A}^1; \mathcal{F}) = 0$ . Thus  $-\chi(\mathcal{F})$  equals the dimension of  $H^{-1}(\mathbb{A}^1; \mathcal{F}) = H^{m-1}(U; \mathcal{P})$ . Due to the perverse shift, the Swan conductor of  $\mathcal{F} \otimes \mathcal{L}_{\psi}$  is equal to  $-\operatorname{Sw}(\mathcal{E}_{(\infty)} \otimes \mathcal{L}_{\psi(\infty)})$ . Since  $\mathcal{E}$  is tamely ramified, this number is equal to the rank of  $\mathcal{E}$ , which is dim  $H^{m-1}(f^{-1}(t); \mathcal{P})$  for some general t. The desired identity then follows from the weak Lefschetz hypothesis.

<span id="page-26-0"></span>Corollary 5.2.11. Let U be a purely n-dimensional affine scheme. Let  $\mathcal{P}$  be a constructible complex on U satisfying the cosupport condition (i.e.,  $\mathcal{P} \in {}^{\mathbf{p}}\mathcal{D}_{U}^{\geqslant 0}$  for the self-dual perversity). Let  $f: U \to \mathbb{A}^1$  be a morphism such that the "weak Lefschetz" property holds for general  $t \in \mathbb{A}^1$ . More precisely, for all but finitely many  $t \in \mathbb{A}^1$ , the corestriction map ( $\iota$  denotes the closed embedding  $f^{-1}(t) \to U$ )

$$\mathrm{H}_{c}^{m}(f^{-1}(t);\iota^{!}\mathcal{P}) \to \mathrm{H}_{c}^{m}(U;\mathcal{P})$$

is surjective for m=1 and bijective for m>1. Then for all but finitely many  $\lambda \in k^{\times}$ ,

$$H_c^m(U; \mathcal{P} \otimes f^*\mathcal{L}_{\psi}) = 0$$

for any  $m \neq 0$ .

**Proof.** This follows from Lemma 5.2.6 by applying Verdier duality. Since Verdier duality is not compatible with tensor products, some care is needed, although it is not particularly difficult. For completeness, let us spell out the details. Let us first recall that if M, N and L are all R-modules, then there is a natural homomorphism

$$\operatorname{Hom}_R(M,N) \otimes \operatorname{Hom}_R(L,R) \to \operatorname{Hom}_R(M \otimes L,N).$$

It is determined by the assignment sending a pair of linear maps  $(T,\varphi) \in \operatorname{Hom}_R(M,N) \times \operatorname{Hom}(L,R)$  to the bilinear map  $(m,x) \mapsto \varphi(x) \cdot T(m)$ . This is clearly bilinear in both T and  $\varphi$ , thus giving the said homomorphism. When L=R is the trivial R-module, the map is clearly an isomorphism. Now for a local system  $\mathcal L$  on U, denote by  $\mathcal L^{\vee}$  its dual local system. For each constructible complex  $\mathcal F$ , the above construction with  $R=\overline{\mathbb Q}_\ell$  gives rise to a morphism of constructible complexes of  $\overline{\mathbb Q}_\ell$ -vector spaces

$$\mathbb{D}\mathcal{F}\otimes\mathcal{L}^{\vee}=R\mathcal{H}om(\mathcal{F},\omega_X)\otimes R\mathcal{H}om(\mathcal{L},\overline{\mathbb{Q}}_{\ell})\rightarrow R\mathcal{H}om(\mathcal{F}\otimes\mathcal{L},\omega_X)=\mathbb{D}(\mathcal{F}\otimes\mathcal{L})$$

which is an isomorphism if  $\mathcal{L} \simeq \overline{\mathbb{Q}}_{\ell}$  is a constant local system. Here,  $\omega_X$  is Verdier's dualizing complex, and  $\mathbb{D}(-) = R\mathcal{H}om(-,\omega_X)$  is the Verdier duality functor.

Now take  $\mathcal{L} = f^*\mathcal{L}_{\psi}$ . Then the dual local system  $\mathcal{L}^{\vee}$  of  $\mathcal{L}$  is  $f^*\mathcal{L}_{\psi^{-1}}$ . Since  $f^*\mathcal{L}_{\psi}$  is trivialized by the finite étale covering of U defined by  $y^p - y = f(x)$ , and checking whether an arrow is an isomorphism is an étale-local matter, we conclude that

$$\mathbb{D}(\mathcal{F} \otimes f^* \mathcal{L}_{\psi}) \simeq \mathbb{D} \mathcal{F} \otimes f^* \mathcal{L}_{\psi^{-1}}.$$

This completes the proof.

**Proof of Theorem 5.2.1.** Without loss of generality we may assume  $u_1(x) = 1$ . Otherwise we can replace u by  $(1, u) : U \to \mathbb{A}^{N+1}$ . Since u is quasi-finite, the map  $x \mapsto (1, u(x)) \in \mathbb{A}^{N+1}$  is also quasi-finite. Since U is a purely n-dimensional local complete intersection,  $\overline{\mathbb{Q}}_{\ell}[n]$  is a perverse sheaf on U (see [KW01, Lemma III.6.5]). Applying Deligne's weak Lefschetz theorem (Theorem 2.3.2) to  $\overline{\mathbb{Q}}_{\ell}[n]$  and  $\mathbb{D}(\overline{\mathbb{Q}}_{\ell}[n])$ , we find that the hypotheses of Lemma 5.2.6 and Corollary 5.2.11 are satisfied for  $f_a^{-1}(t)$ , where a is sufficiently general in  $\mathbb{A}^N$ . This proves the vanishing of  $H^i(U; f^*\mathcal{L}_{\psi})$  and  $H^i_c(U; f^*\mathcal{L}_{\psi})$  when  $i \neq n$ . The second assertion then follows from these vanishing results and Lemma 5.2.2.

<span id="page-27-0"></span>5.3. **Katz's situation.** Let us offer an immediate application of the theorems above to a framework considered by Katz [Kat80].

Consider the following data:

- Let X be a smooth proper variety over k.
- Let  $D_1, \ldots, D_s$  be effective, nonsingular, irreducible divisors of X, such that for any subset J of  $\{1, \ldots, s\}$ ,

$$D_J = \bigcap_{j \in J} D_j$$

is either empty, or smooth of codimension  $\operatorname{Card} J$  in X.

• Let  $e_1, \ldots, e_s \ge 1$  be natural numbers. Let  $D = \sum_{i=1}^s e_i D_i$ . Thus

$$\mathcal{O}_X(D) = \bigotimes_{i=1}^s \mathcal{O}_X(e_i D_i).$$

We assume that  $\mathcal{O}_X(D)$  is very ample.

- Let  $H = \sum_{j=1}^{l} H_j$  be an auxiliary divisor on X, such that for each  $J \subset \{1, \ldots, s\}$ ,  $K \subset \{1, \ldots, l\}$ ,  $H_K \cap D_J$  is either empty or smooth of codimension  $\operatorname{Card} J + \operatorname{Card} K$  in X. In other words,  $H \cup D_{\operatorname{red}}$  is a divisor with strict normal crossings.
- Let  $\mathcal{L}_1, \ldots, \mathcal{L}_r$  be very ample invertible sheaves on X.
- Let  $U = X (H \cup D_{red})$ .

From these data, we can construct a family of regular functions as follows. Let  $s_1, \ldots, s_N$  be a basis of  $H^0(X; \mathcal{O}_X(D))$ , with  $s_1$  being the section defining the divisor D. Then on the variety U we have a morphism

$$u: U \to \mathbb{A}^N, x \mapsto \left(1, \frac{s_2}{s_1}, \dots, \frac{s_N}{s_1}\right).$$

We are then reduced to the situation considered in §5. Since D is very ample,  $u \colon U \to \mathbb{A}^N$  is a locally closed immersion.

For any r-tuple  $(F_1, \ldots, F_r) \in \prod_{i=1}^r H^0(X; \mathcal{L}_i)$ , we define  $U(F_1, \ldots, F_r)$  to be the intersection of U with the common zero locus of  $F_1, \ldots, F_r$  in X. Set

$$\mathcal{M} = \mathrm{H}^0(X; \mathcal{O}_X(D)) \times \prod_{i=1}^r \mathbb{P}\mathrm{H}^0(X; \mathcal{L}_i).$$

Then for any element  $(s, F_1, \ldots, F_r) \in \mathcal{M}$ , we get a regular function  $f: U(F_1, \ldots, F_r) \to \mathbb{A}^1$ ,  $x \mapsto s(x)/s_1(x)$ .

The following proposition (cf. [Kat80, 172]) follows from a straightforward Chern class computation.

<span id="page-28-1"></span>**Proposition 5.3.1.** Let  $(s, F_1, ..., F_r)$  be a sufficiently general (r + 1)-tuple in  $\mathcal{M}$ . Let  $Z = f^{-1}(0) \cap U(F_1, ..., F_r)$ . Then

$$(-1)^{n-r} [\chi(U(F_1, \dots, F_r)) - \chi(Z)] = \int_X \frac{c(X)c_1(\mathcal{L}_1) \cdots c_1(\mathcal{L}_r)}{(1+D) \cdot \prod_{j=1}^s (1+D_j) \prod_{j=1}^l (1+H_j) \prod_{j=1}^r (1+c_1\mathcal{L}_i)}.$$

<span id="page-28-2"></span>**Theorem 5.3.2.** Let  $(s', F'_1, \ldots, F'_r)$  be a sufficiently general point in  $\mathcal{M}$ , defining a regular function

$$f' \colon U(F'_1, \dots, F'_r) \to \mathbb{A}^1$$
.

Let  $(s, F_1, \ldots, F_r) \in \mathcal{M}$  be arbitrary, defining  $f: U(F_1, \ldots, F_r) \to \mathbb{A}^1$ . Then we have

$$\dim \mathbf{H}_c^{n-r}(U(F_1,\ldots,F_r);f^*\mathcal{L}_{\psi}) \leqslant \dim \mathbf{H}_c^{n-r}(U(F_1',\ldots,F_r');f'^*\mathcal{L}_{\psi}).$$

In particular, we have the following bound:

$$\dim H_c^{n-r}(U(F_1, \dots, F_r); f^* \mathcal{L}_{\psi})$$

$$\leq \int_X \frac{c(X)c_1(\mathcal{L}_1) \cdots c_1(\mathcal{L}_r)}{(1+D) \cdot \prod_{i=1}^s (1+D_j) \prod_{i=1}^r (1+H_j) \prod_{i=1}^r (1+c_1\mathcal{L}_i)}.$$

**Proof.** The result follows from combining Theorem 5.1.1, Theorem 5.2.1, and Proposition 5.3.1.

To get an explicit bound, let us take  $X = \mathbb{P}^n$ ,  $H = \emptyset$ ,  $D = d\mathbb{P}^{n-1}$  a multiple of the infinity hyperplane. Then  $U = \mathbb{A}^n$ .

Let us first suppose that there are no invertible sheaves given (i.e., r = 0). In this case we have the following:

<span id="page-28-0"></span>**Corollary 5.3.3.** Let  $d \ge 2$  be an integer. Suppose the characteristic p of k does not divide d. Let  $f: \mathbb{A}^n \to \mathbb{A}^1$  be a regular function of degree  $\leqslant d$ . Let  $g_i: \mathbb{A}^{n-i} \to \mathbb{A}^1$  be any sufficiently general polynomial of degree d. Then for  $i \ge 0$ , we have

$$\dim \mathcal{H}_{c}^{n+i}(\mathbb{A}^{n}; f^{*}\mathcal{L}_{\psi}) \leqslant \dim \mathcal{H}_{c}^{n-i}(\mathbb{A}^{n-i}; g_{i}^{*}\mathcal{L}_{\psi}(-i)).$$

Therefore, the total number of reciprocal roots and poles of  $L_f(t)$  does not exceed

$$\sum_{m>0} \dim H_c^m(\mathbb{A}^n; f^* \mathcal{L}_{\psi}) \leqslant (d-1)^n + (d-1)^{n-1} + \dots + 1 \leqslant d^n.$$

Moreover, if (d,q)=1, the Newton polygon of  $\det(1-tF|_{H^{n+i}_c(\mathbb{A}^n;f^*\mathcal{L})})$  lies above or on the Newton polygon of

$$\prod_{m=0}^{(n-i)(d-2)} (1 - q^{i + \frac{m+n-i}{d}} t)^{U_{m,n-i}},$$

where  $U_{m,n}$  is the coefficient of  $x^m$  in the expansion of  $(1 + x + \cdots + x^{d-2})^n$ .

**Proof.** The integral in Proposition 5.3.1 can be computed exactly:

$$(-1)^n[\chi(U) - \chi(f^{-1}(0))] = (d-1)^n.$$

Thus we conclude from Theorem 5.3.2 that

$$\dim \mathbf{H}_c^n(\mathbb{A}^n; f^*\mathcal{L}_{\psi}) \leqslant (d-1)^n$$

for any polynomial f of degree  $\leq d$ . Lemma 2.3.3 tells us that we can restrict to a generic affine hyperplane to bound the dimension of higher cohomology spaces. Thus

$$\dim \mathcal{H}_c^{n+j}(\mathbb{A}^n; f^*\mathcal{L}_{\psi}) \leqslant (d-1)^{n-j}.$$

Regarding the generic Newton polygon, we cite [AS00, Theorem 4.3]. Together with Variant 5.1.2, we see that the Newton polygon of  $\det(1 - tF|_{H^n_c(\mathbb{A}^n; f^*\mathcal{L}_{\psi})})$  lies on or above the Newton polygon ("irregular Hodge polygon") of

$$\prod_{m=0}^{n(d-2)} (1 - q^{\frac{m+n}{d}}t)^{U_{m,n}},$$

where  $U_{m,n}$  is the coefficient of  $x^m$  in the expansion of  $(1+x+\cdots+x^{d-2})^n$ . Replacing n by n-j completes the proof.

When there are invertible sheaves present, say we are given  $\mathcal{L}_1 = \cdots = \mathcal{L}_r = \mathcal{O}_{\mathbb{P}^n}(d)$ , the exact generic formula, while attainable, is slightly complicated. Therefore, we resort to an estimate. In this case, we denote  $U(F_1, \ldots, F_r)$  by V, and we denote by  $f_i$  the dehomogenization of  $F_i$ . Then deg  $f_i \leq d$ . Thus

$$V = \{f_1 = \dots = f_r = 0\} \subset \mathbb{A}^n, \deg f_i \leqslant d.$$

<span id="page-29-2"></span><span id="page-29-0"></span>Corollary 5.3.4. In the situation above, assume that  $\dim V = n - r$ .

(i) If the pair (V, f) is sufficiently general, then

$$\sum_{m} \dim \mathcal{H}_{c}^{m}(V; f^{*}\mathcal{L}_{\psi}) = \dim \mathcal{H}_{c}^{n-r}(V; f^{*}\mathcal{L}_{\psi}) \leqslant \binom{n}{r} d^{n}.$$

<span id="page-29-1"></span>(ii) In (i), if d is coprime to the characteristic of k, then

$$\sum_{m} \dim \mathcal{H}_{c}^{m}(V; f^{*}\mathcal{L}_{\psi}) = \dim \mathcal{H}_{c}^{n-r}(V; f^{*}\mathcal{L}_{\psi}) \geqslant \binom{n}{r} (d-1)^{n}.$$

(iii) If V is an arbitrary complete intersection, then

$$\sum_{m} \dim \mathcal{H}_{c}^{m}(V; f^{*}\mathcal{L}_{\psi}) \leqslant \binom{n}{r} (d+1)^{n}$$

**Proof.** Let C(n,r;d) denote the coefficient of  $h^{n-r}$  in the power series expansion of

<span id="page-29-3"></span>
$$(-1)^{n-r}d^r\frac{(1+h)^n}{(1+dh)^{r+1}}.$$

Expanding the Chern class formula, Theorem 5.3.2 gives the following estimate:

(5.3.5) 
$$\dim H_c^{n-r}(V; f^*\mathcal{L}_{\psi}) \leqslant C(n, r; d).$$

Moreover:

- If (V, f) is sufficiently general, by Theorem 5.2.1, we have  $H_c^i(V; f^*\mathcal{L}_{\psi}) = 0$  for all  $i \neq n r$ .
- If (V, f) is sufficiently general and if d is coprime to the characteristic of k, the inequality (5.3.5) is an equality by a theorem of Katz [Kat80].
- For an arbitrary pair (V, f) satisfying the hypotheses, applying Lemma 2.3.3 and (5.3.5) repeatedly gives

$$\sum_{j=0}^{n-r} \dim \mathcal{H}_c^{n-r+j}(V; f^*\mathcal{L}_{\psi}) \leqslant \sum_{j=0}^{n-r} C(n-j, r; d).$$

Therefore, all we need to do is to prove

$$\binom{n}{r}(d-1)^n \leqslant C(n,r;d) \leqslant \binom{n}{r}d^n.$$

П

Replacing h by -h, one sees that C(n,r;d) is the coefficient of  $h^{n-r}$  in the power series expansion of

$$d^{r} \frac{(1-h)^{n}}{(1-dh)^{r+1}} = \frac{d^{r}}{d^{n}} \frac{((d-1)+(1-dh))^{n}}{(1-dh)^{r+1}}$$
$$= \frac{d^{r}}{d^{n}} \sum_{i=0}^{n} \binom{n}{i} (d-1)^{n-i} (1-dh)^{i-r-1}.$$

Therefore, for the lower bound, we have

$$C(n,r;d) = \frac{d^r}{d^n} \sum_{i=0}^n \binom{n}{i} (d-1)^{n-i} (-d)^{n-r} \binom{i-r-1}{n-r}$$
$$= \sum_{i=0}^r \binom{n}{i} (d-1)^{n-i} \binom{n-i}{n-r}$$
$$\geqslant \binom{n}{r} (d-1)^n.$$

For the upper bound, we have

$$C(n,r;d) \leqslant \binom{n}{r} \sum_{i=0}^{n} \binom{n}{i} (d-1)^{n-i}$$
$$= \binom{n}{r} d^{n}.$$

This completes the proof.

For future applications, we record the following case of exponential sums over certain special complete intersection curves.

**Corollary 5.3.6.** Let q be a power of a prime number p. Let  $h(x), g_1(x), \dots, g_n(x) \in \mathbb{F}_q[x]$  be nonzero polynomials in one variable, each has degree d not divisible by p. Then, we have the estimate

$$\left| \sum_{\substack{(x_1, \dots, x_n) \in \mathbb{F}_q^n \\ g_1(x_1) = \dots = g_n(x_n)}} \psi \left( \operatorname{Tr}_{\mathbb{F}_q/\mathbb{F}_p} h(x_1) \right) \right| \leqslant n d^n \sqrt{q}.$$

**Proof.** Let us consider the complete intersection curve V in  $\mathbb{A}^n$  defined by the following n-1 equations

$$g_1(x_1) - g_2(x_2) = g_1(x_1) - g_3(x_3) = \dots = g_1(x_1) - g_n(x_n) = 0,$$

and the regular function  $f: V \to \mathbb{A}^1$  is given by  $f(x_1, \dots, x_n) = h(x_1)$ .

The assumption (d, p) = 1 implies that the map  $V \to \mathbb{A}^1$  defined by  $(x_1, \dots, x_n) \mapsto x_1$  is tamely ramified at  $\infty$ . Indeed, V can be realized as a fiber product

$$V \cong \mathbb{A}^1 \times_{g_1,\mathbb{A}^1,g_2} \mathbb{A}^1 \times_{g_2,\mathbb{A}^1,g_3} \cdots \times_{g_{n-1},\mathbb{A}^1,g_n} \mathbb{A}^1.$$

Let  $K_i := \mathbb{F}_q((x_i))$  be the extension of  $K := \mathbb{F}_q((t^{-1}))$  induced by  $t \mapsto g_i(t)$ . Then the étale K-algebra induced by the morphism  $V \to \mathbb{A}^1$  is therefore  $K_1 \otimes_K K_2 \cdots \otimes_K K_n$ . Since  $K_i$  is tamely ramified over K, the  $K_1$ -algebra  $K_1 \otimes_K K_2 \otimes_K \cdots \otimes_K K_n$  is a tamely ramified étale  $K_1$ -algebra. This implies the  $\overline{\mathbb{Q}}_\ell$ -sheaf

$$\mathcal{F} \coloneqq R^0 \mathrm{pr}_{1*}(\overline{\mathbb{Q}}_{\ell,V})$$
 (where  $\mathrm{pr}_1 \colon V \to \mathbb{A}^1$  is the projection to the first factor)

on  $\mathbb{A}^1$  is tamely ramified at  $\infty$ . Since deg h is coprime to p, the local system  $h^*\mathcal{L}_{\psi}$  on  $\mathbb{A}^1$  is wildly ramified at infinity. Hence the  $\overline{\mathbb{Q}}_{\ell}$ -sheaf  $h^*\mathcal{L}_{\psi} \otimes \mathcal{F}$  is wildly ramified at  $\infty$ . In particular,

$$\mathrm{H}_{c}^{2}(\mathbb{A}^{1}; \mathcal{F} \otimes h^{*}\mathcal{L}_{\psi}) = 0.$$

Since  $\operatorname{pr}_1$  is a finite morphism,  $R^0\operatorname{pr}_{1*}=R\operatorname{pr}_{1*}$ . The projection formula then implies that  $\operatorname{H}^2_c(V; f^*\mathcal{L}_\psi)=0$ . Since  $f^*\mathcal{L}_\psi$  is a local system on V,  $\operatorname{H}^0_c(V; f^*\mathcal{L}_\psi)=0$  as well. By Grothendieck's trace formula (1.3.3) and Weil II [Del80, Théorème 1], we get

$$\left| \sum_{x \in V(\mathbb{F}_q)} \psi(f(x)) \right| = \left| \operatorname{Tr}(F^m | \mathcal{H}_c^1(V; f^* \mathcal{L}_{\psi})) \right|$$

$$\leq \sqrt{q} \cdot \dim \mathcal{H}_c^1(V; f^* \mathcal{L}_{\psi})$$

$$\leq n d^n \sqrt{q}.$$

<span id="page-31-0"></span>In the last step, we applied Corollary 5.3.4. This completes the proof.

5.4. **Toric exponential sums.** In this section we apply the results developed so far to exponential sums on an algebraic torus  $\mathbb{G}_{\mathrm{m}}^n$  and its subvarieties defined by a collection of Laurent polynomials. If A is a ring and we are given a Laurent polynomial  $f \in A[x_1, \ldots, x_n, (x_1 \cdots x_n)^{-1}]$ ,  $f = \sum a_u x^u$ , the Newton polytope  $\Delta_0(f)$  of f is the convex hull, in  $\mathbb{R}^n$ , of

$$\operatorname{Supp}(f) = \{ u \in \mathbb{Z}^n : a_u \neq 0 \}.$$

Its Newton polytope at infinity is

$$\Delta_{\infty}(f) = \Delta_0(f - T)$$

where T is a dummy variable, and we view f-T as a Laurent polynomial with coefficients in the ring A(T). Thus,  $\Delta_{\infty}$  is the convex hull of  $\{0\} \cup \operatorname{Supp}(f)$  in  $\mathbb{R}^n$ . For each lattice polytope  $\Delta$  in  $\mathbb{R}^n$  and any ring A, we define

$$L(\Delta)_A = \{ f \in A[x_1, \dots, x_n, (x_1 \cdots x_n)^{-1}] : \Delta_0(f) \subset \Delta \}.$$

We shall write  $L(\Delta)$  in place of  $L(\Delta)_k$  when A is the ground field k.

When k is a field of characteristic 0, Khovanskii [Kho78, §3, Theorem 2] gives an exact formula for the Euler characteristic of a generic complete intersection in  $\mathbb{G}_{\mathrm{m}}^{n}$  in terms of the Minkowski mixed volume.

<span id="page-31-1"></span>**Theorem 5.4.1.** Suppose k is an algebraically closed field of characteristic 0. Let  $\Delta_1, \ldots, \Delta_r$  be lattice polytopes in  $\mathbb{Z}^n$ . Suppose  $h_i \in L(\Delta_i)$ ,  $i = 1, \ldots, r$  are sufficiently general. Let  $V = \{h_1 = \cdots = h_r = 0\} \subset \mathbb{G}_m^n$ . Then the morphism  $H^i(\mathbb{G}_m^n; \overline{\mathbb{Q}}_\ell) \to H^i(V; \overline{\mathbb{Q}}_\ell)$  is bijective for i < n - r, and

$$\chi(V) = \prod_{i=1}^{r} \frac{\Delta_i}{1 + \Delta_i}.$$

(Recall Notation 1.3.5.)

The original proof of Theorem 5.4.1 uses the Bertini–Sard theorem, so it cannot be directly carried out in positive characteristics. Indeed, if k has positive characteristic, the morphism  $\mathbb{G}_{\mathrm{m}}^n \to \mathbb{A}^N$ ,  $x \mapsto (x^w)_{w \in \Delta \cap \mathbb{Z}^n}$  may not be generically smooth on the target, and all hypersurfaces defined by  $\Delta$  may be singular. Therefore, we should not expect Theorem 5.4.1 to hold in positive characteristics. Nevertheless, by applying Variant 3.5, we can still obtain an upper bound for the Euler characteristic of V.

<span id="page-32-6"></span>**Proposition 5.4.2.** Let k be an algebraically closed field of characteristic p > 0. Let  $\ell$  be a prime different from p. Let  $\Delta_1, \ldots, \Delta_r$  be n-dimensional lattice polytopes in  $\mathbb{Z}^n$ . Suppose  $h_i \in L(\Delta_i)$ ,  $i = 1, \ldots, r$  are sufficiently general. Let  $V = \{h_1 = \cdots = h_r = 0\} \subset \mathbb{G}_m^n$ . Then

$$(-1)^{n-r}\chi(V;\overline{\mathbb{Q}}_{\ell}) \leqslant (-1)^{n-r}\prod_{i=1}^{r}\frac{\Delta_{i}}{1+\Delta_{i}}.$$

**Proof.** The idea is simple: we lift a generic V to characteristic 0 which satisfies Theorem 5.4.1, and then we apply Variant 3.5.

As is well-known, the Euler characteristic of V is independent of  $\ell$  so long as  $\ell$  is not equal to the characteristic of the ground field. To prove the lemma, therefore, it matters not which  $\ell$  we choose, and it suffices to prove it for one particular  $\ell$ . We will later explain which  $\ell$  we shall use.

Let  $\mathcal{O}$  be a characteristic 0 discrete valuation ring with residue field k. Let K be the field of fractions of  $\mathcal{O}$ . For each r-tuple  $(\widetilde{h}_1, \ldots, \widetilde{h}_r)$  of K-points of  $\prod_i \mathbb{P}L(\Delta_i)_K$ , we can scale the coefficients without changing their common zero locus in  $\mathbb{G}^n_{\mathrm{m},K}$ . After scaling, we can assume  $\widetilde{h}_i$  has coefficients in  $\mathcal{O}$ . In this situation, we write  $\mathcal{V}$  to be the  $\mathcal{O}$ -subscheme of  $\mathbb{G}^n_{\mathrm{m},\mathcal{O}}$  defined by the vanishing of  $\widetilde{h}_i$ .

Since the map that sends a Laurent polynomial f to f modulo the maximal ideal is surjective, for any preassigned Zariski open dense subset  $\mathcal{U}$  of the k-scheme  $\prod_{i=1}^r \mathbb{P}L(\Delta_i)_k$ , we can always find  $(\widetilde{h}_1,\ldots,\widetilde{h}_r) \in \prod_i \mathbb{P}L(\Delta_i)_{\mathcal{O}}$  such that the special fiber  $\mathcal{V} \otimes_{\mathcal{O}} k = V$  is defined by an r-tuple  $(h_1,\ldots,h_r)$  in  $\mathcal{U}$ .

Applying Lemma 2.3.3 to  $\overline{\mathbb{Q}}_{\ell,\mathbb{G}_{\mathbb{m}}^n}[n]$ , we can find a Zariski open dense subset  $\mathcal{U}$  of  $\prod_{i=1}^r \mathbb{P}L(\Delta_i)_k$  such that if  $(h_1,\ldots,h_r)\in\mathcal{U}$ , then

<span id="page-32-1"></span>
$$(5.4.3)$$

is bijective for all  $i \ge 1$ . Thus we may choose lifts  $h_1, \ldots, h_r$  of  $h_1, \ldots, h_r$  such that on the one hand  $(\tilde{h}_1, \ldots, \tilde{h}_r)$  satisfies Theorem 5.4.1 (when passed to the algebraic closure of K), and on the other hand (5.4.3) holds for V.

<span id="page-32-5"></span>Fix an algebraic closure  $\overline{K}$  of K. It suffices to show

(5.4.4) 
$$\dim H_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) \leqslant \dim H_c^{n-r}(\mathcal{V}_{\overline{\eta}}; \overline{\mathbb{Q}}_{\ell}).$$

where  $\mathcal{V}_{\overline{\eta}}$  is the geometric generic fiber of  $\mathcal{V}$  valued in  $\overline{K}$ .

Since  $\mathcal{V}_{\overline{\eta}}$  is of finite type over  $\overline{K}$ , there is an algebraically closed subfield K' of  $\overline{K}$  which is isomorphic to  $\mathbb{C}$ , and  $\mathcal{V}_{\overline{\eta}}$  is defined over  $K' \simeq \mathbb{C}$ . Using this isomorphism, the  $\mathbb{Z}_{\ell}$ -cohomology spaces  $H_c^{n-r}(\mathcal{V}_{\overline{\eta}}; \mathbb{Z}_{\ell})$  and  $H_c^{n-r}(\mathcal{V}_{\mathbb{C}}; \mathbb{Z}_{\ell})$  are isomorphic to the Betti cohomology space  $H_c^{n-r}(\mathcal{V}_{\mathbb{C}}^{\mathrm{an}}; \mathbb{Z}_{\ell})$ . We shall now choose  $\ell$  so that the  $\mathbb{Z}_{\ell}$ -Betti cohomology of  $\mathcal{V}^{\mathrm{an}}$  has no  $\ell$ -power torsion in any degree. Hence

<span id="page-32-2"></span>(5.4.5) 
$$\dim \mathcal{H}_{c}^{i}(\mathcal{V}_{\overline{\eta}}; \overline{\mathbb{Q}}_{\ell}) = \dim \mathcal{H}_{c}^{i}(\mathcal{V}_{\overline{\eta}}; \mathbb{F}_{\ell})$$

holds for any i. By Variant 3.5, we have

<span id="page-32-3"></span>(5.4.6) 
$$\dim H_c^{n-r}(V; \mathbb{F}_{\ell}) \leqslant \dim H_c^{n-r}(\mathcal{V}_{\overline{\eta}}; \mathbb{F}_{\ell}).$$

Since the  $\mathbb{Z}_{\ell}$ -cohomology of the variety V may have  $\ell$ -torsion.

<span id="page-32-4"></span>(5.4.7) 
$$\dim H_c^{n-r}(V; \overline{\mathbb{Q}}_{\ell}) \leqslant \dim H_c^{n-r}(V; \mathbb{F}_{\ell}).$$

<span id="page-32-0"></span>Combining (5.4.5), (5.4.6), and (5.4.7) yields (5.4.4), and completes the proof.

**Theorem 5.4.8.** Let  $\Delta_1, \ldots, \Delta_r$  and  $\Delta_{\infty}$  be n-dimensional lattice polytopes in  $\mathbb{R}^n$ . Assume that  $0 \in \Delta_{\infty}$ . Suppose we are given  $h_i \in L(\Delta_i)$   $(i = 1, \ldots, r)$  and  $f \in L(\Delta_{\infty})$ . Let  $V = \{h_1 = \cdots = h_r = 0\} \subset \mathbb{G}_m^n$ . Then:

(i) We have the following bound on cohomology:

$$\dim \mathcal{H}_c^{n-r}(V; f^*\mathcal{L}_{\psi}) \leqslant (-1)^{n-r} \frac{1}{1+\Delta_{\infty}} \prod_{i=1}^r \frac{\Delta_i}{1+\Delta_i}.$$

(ii) If moreover dim V = n - r, then for any  $0 \le j \le n - r$ , we have:

$$\dim \mathcal{H}_c^{n-r+j}(V; f^*\mathcal{L}_{\psi}) \leqslant (-1)^{n-r} \frac{1}{1+\Delta_{\infty}} \prod_{i=1}^r \frac{\Delta_i}{1+\Delta_i} \cdot (-1)^j \left(\frac{S}{1+S}\right)^j$$

where S can be any n-dimensional lattice polytope in  $\mathbb{R}^n$ .

**Proof.** To prove the first assertion, it suffices to assume that V is defined by a sufficiently general r-tuple  $(h_1, \ldots, h_r)$  of  $\prod_{i=1}^r \mathbb{P}L(\Delta_i)$ . Indeed, if  $(h'_1, \ldots, h'_r)$  is a sufficiently general r-tuple defining a complete intersection V' in  $\mathbb{G}_m^n$ , we can form a family

$$\mathcal{V} = \{(x,t) \in \mathbb{A}^1 : (1-t)h_i + th_i' = 0, i = 1, \dots, r\}$$

Then  $\mathcal{V}$  is defined by r equations in  $\mathbb{G}_{\mathrm{m}}^n \times \mathbb{A}^1$ , and  $(f^*\mathcal{L}_{\psi} \boxtimes \overline{\mathbb{Q}}_{\ell})[n+1-r]$  satisfies the cosupport condition by Lemma 2.1.1. By Lemma 3.1, we find that

$$\dim \mathcal{H}_c^{n-r}(V; f^*\mathcal{L}_{\psi}) \leqslant \dim \mathcal{H}_c^{n-r}(V'; f^*\mathcal{L}_{\psi}).$$

Therefore, without loss of generality, we may assume that V is already a sufficiently general complete intersection.

Consider the map  $u \colon \mathbb{G}_{\mathrm{m}}^n \to \mathbb{A}^N$  sending x to  $(x^w)_{w \in \Delta_{\infty} \cap \mathbb{Z}^n}$ . Since  $\Delta_{\infty}$  is n-dimensional, u is a quasi-finite morphism. In particular, the composition  $V \to \mathbb{G}_{\mathrm{m}}^n \to \mathbb{A}^N$  is also quasi-finite. In this case, the affine space attached to  $L(\Delta_{\infty})$  is identified with  $\check{\mathbb{A}}^N$ . By Theorem 5.1.1, there is a Zariski open dense subset  $\mathcal{U}$  of  $\check{\mathbb{A}}^N$ , such that for any  $f' \in \mathcal{U}$  and any  $f \in \check{\mathbb{A}}^N$ , we have

$$\dim \mathbf{H}_{c}^{n-r}(V; f^*\mathcal{L}_{\psi}) \leqslant \dim \mathbf{H}_{c}^{n-r}(V; f'^*\mathcal{L}_{\psi}),$$

and, by Theorem 5.2.1,

$$\dim \mathcal{H}_c^{n-r}(V; f'^* \mathcal{L}_{\psi}) \leqslant (-1)^{n-r} \chi(V) + (-1)^{n-r-1} \chi(f'^{-1}(t) \cap V)$$

for t sufficiently general. Applying Proposition 5.4.2, we conclude that

$$\dim H_c^{n-r}(V; f^* \mathcal{L}_{\psi}) \leqslant (-1)^{n-r} \prod_{i=1}^r \frac{\Delta_i}{1 + \Delta_i} + (-1)^{n-r-1} \frac{\Delta_{\infty}}{1 + \Delta_{\infty}} \prod_{i=1}^r \frac{\Delta_i}{1 + \Delta_i}.$$

This proves the first assertion.

For the second assertion, we use generic elements in  $\mathbb{P}L(S)$  to "cut down" V and apply Lemma 2.3.3. For  $j \geq 0$ , we can choose j sufficiently general functions  $l_1, \ldots, l_j$  whose Newton polytope (with respect to 0) is S. This choice ensures the existence of a surjective map

$$\mathrm{H}^{n-r-j}_c(V\cap L; f^*\mathcal{L}_\psi)(-j) \to \mathrm{H}^{n-r+j}_c(V; f^*\mathcal{L}_\psi),$$

where  $L = \{l_1 = \cdots = l_j = 0\} \subset \mathbb{G}_{\mathrm{m}}^n$ . The second assertion then follows directly from the first one.

Let us work out a more explicit bound when  $V = \mathbb{G}_{\mathrm{m}}^n$ . In this case, we have

$$\sum \dim \mathbf{H}_c^{n+j}(\mathbb{G}_{\mathrm{m}}^n; f^*\mathcal{L}_{\psi}) \leqslant \frac{(-1)^n}{1+\Delta_{\infty}} \sum_{j=0}^{n-r} (-1)^j \left(\frac{S}{1+S}\right)^j.$$

For  $i \ge 1$ , the coefficient before  $\Delta_{\infty}^{n-i}S^i$  is given by

$$(-1)^{i} \sum_{j=0}^{i} (-1)^{j} \binom{-j}{i-j} = \sum_{j=1}^{i} \binom{i-1}{i-j} = 2^{i-1}.$$

Here we have applied the binomial coefficient identity

<span id="page-34-1"></span>
$$(-1)^a \binom{z}{a} = \binom{-z+a-1}{a}.$$

Therefore, the final upper bound is

(5.4.9) 
$$\sum \dim H_c^i(\mathbb{G}_m^n; f^*\mathcal{L}_{\psi}) \leqslant \Delta_{\infty}^n + \sum_{i=1}^n 2^{i-1} \Delta_{\infty}^{n-i} S^i.$$

We also have a variant of the above theorem for Newton polygons of toric exponential sums. Let us recall the Adolphson–Sperber lower bound for nondegenerate Laurent polynomials. Suppose  $\Delta$  is an n-dimensional lattice polytope in  $\mathbb{R}^n$  containing the origin. For each  $u \in \mathbb{Z}^n$ , suppose the half-line from the origin through u intersects  $\Delta$  in a face that does not contain the origin. Let  $\sum_{i=1}^n \epsilon_i x_i = 1$  be the equation of a hyperplane passing through this face. Then the weight of u is defined as  $w(u) = \sum \epsilon_i u_i$ . If the intersection of the open half-line with  $\Delta$  is empty, we set  $w(u) = +\infty$ . The weight of the origin is always zero. Let D be the least common denominator of all the  $\epsilon_i$ 's over all faces of  $\Delta$ . Then clearly  $w(\mathbb{Z}^n) \subset \frac{1}{D}\mathbb{Z}_{\geqslant 0} \cup \{+\infty\}$ .

For the Newton polygon calculation, we define:

$$W(m) = \operatorname{Card}\left\{u \in \mathbb{Z}^n : w(u) = \frac{m}{D}\right\},$$
  
$$W'(m) = \sum_{l \ge 0} (-1)^l \binom{n}{l} W(m - lD).$$

The Hodge polygon  $HP(\Delta)$  of  $\Delta$  is defined as the convex polygon with vertices at the points:

$$\left(\sum_{i=0}^{m} W'(m), \sum_{i=0}^{m} \frac{i}{D} W'(m)\right), \quad m = 0, 1, 2, \dots$$

The theorem of Adolphson and Sperber states that if  $f \in L(\Delta)_{\mathbb{F}_q}$  is nondegenerate with respect to  $\Delta$  (see [AS89, p. 376] for the definition), then the Newton polygon of  $\det(1 - tF|\mathcal{H}_c^n(\mathbb{G}_m^n; f^*\mathcal{L}_{\psi}))$  lies on or above the Hodge polygon  $HP(\Delta)$ , and has the same endpoints.

Variant 5.4.10. Let  $f \in \mathbb{F}_q[x_1, \dots, x_n, (x_1 \cdots x_n)^{-1}]$  be a Laurent polynomial such that  $\Delta_{\infty}(f) \subset \Delta$ . Assume that there exists a nondegenerate Laurent polynomial whose Newton polytope equals  $\Delta$ . Then the Newton polygon of  $\det(1 - tF | H_c^n(\mathbb{G}_m^n; f^*\mathcal{L}_{\psi}))$  lies on or above the Hodge polygon  $HP(\Delta)$ .

Since we do not know what the Hodge lower bound should be for the exponential sum of a general function on a general complete intersection in  $\mathbb{G}_{\mathrm{m}}^n$ , we cannot extract any information about the Newton polygon of  $\mathrm{H}^i_c(\mathbb{G}_{\mathrm{m}}^n; f^*\mathcal{L}_{\psi})$  when i > n.

<span id="page-34-0"></span>5.5. **Proofs of 1.1.2 and 1.3.10(i).** We begin with the proof of Theorem 1.1.2. The lower bound is easy, since by (1.1.1) and Corollary 4.2.4(iii) we have

$$(d-1)^n \leqslant B_c^{ci}(n,1;d) = B_c(n,1;d) \leqslant B_c(n,r;d).$$

So we only need to prove the upper bound.

By a standard argument using Deligne's constructibility theorem (namely, extract the finitely many defining coefficients, spread out over Spec  $\mathbb{Z}$ , find a geometric point lying above a closed point—whose residue field is necessarily a finite field—at which the direct image attains its generic value), it suffices to prove Theorem 1.1.2 over the algebraic closure of a finite field.

Next, we recall a well-known theorem that connects the standard compactly supported Betti numbers with those of Artin–Schreier cohomology. This relationship will be used in our later arguments.

<span id="page-35-4"></span>**Theorem 5.5.1.** Let  $\psi \colon \mathbb{F}_p \to \mathbb{C}^*$  be a nontrivial additive character. Consider a geometric vector bundle  $\pi \colon E \to X$  of rank r and a section  $s \colon X \to E$ . Let  $i \colon V \to X$  be the vanishing scheme of s, and let  $\varpi \colon E^{\vee} \to X$  denote the dual bundle of E. Define the function

$$q: E^{\vee} \xrightarrow{s \circ (\varpi \times \mathrm{Id})} E \times E^{\vee} \xrightarrow{\mathrm{can}} \mathbb{A}^1.$$

Then we have a natural isomorphism:

$$\varpi_*(\varpi^*\mathcal{F}\otimes q^*\mathcal{L}_{\psi})\simeq i_*i^!\mathcal{F}.$$

**Proof.** This theorem follows from the basic properties of the Deligne–Fourier transform, as developed by Laumon [Lau87]. We shall omit the proof here, as the reader can find an essentially identical proof in [BD04], where Baldassarri and D'Agnolo proved a similar theorem for  $\mathcal{D}$ -modules. (Note that the \*-pullback used in [BD04] is a shift of the !-pullback.)

After taking  $\mathcal{F} = \overline{\mathbb{Q}}_{\ell}$ , applying the global section functor  $R\Gamma(X; -)$ , and applying Poincaré duality, we obtain the following consequence. For simplicity, we omit the Tate twists in the statement below.

<span id="page-35-0"></span>Corollary 5.5.2. In the situation above, we have an isomorphism of  $\overline{\mathbb{Q}}_{\ell}$  vector spaces

$$\mathrm{H}_{c}^{j}(V;\overline{\mathbb{Q}}_{\ell})\simeq\mathrm{H}_{c}^{j+2r}(E^{\vee};g^{*}\mathcal{L}_{\psi}).$$

The particular case we will consider is when  $X = \mathbb{A}^n$ ,  $E = X \times \mathbb{A}^r$ , with s defined by r polynomials  $f_1, \ldots, f_r$  of degree at most d. Thus,  $V = \operatorname{Spec} k[x_1, \ldots, x_n]/(f_1, \ldots, f_r)$  represents the common zero locus of the  $f_i$ . The function g is a regular function on  $\mathbb{A}^{n+r}$  in n+r variables, given by:

$$q(x_1, \dots, x_{n+r}) = x_{n+1} f_1(x) + \dots + x_{n+r} f_r(x).$$

For convenience, we introduce the following notation:

<span id="page-35-1"></span>
$$B_c(X; f) = \sum \dim \mathrm{H}_c^i(X; f^* \mathcal{L}_{\psi}).$$

Then by Corollary 5.5.2, Theorem 1.1.2 will follow from the following inequality:

(5.5.3) 
$$B_c(\mathbb{A}^{n+r}; g) \leq 3^r \binom{n+r-1}{r-1} (2d+1)^n.$$

Before we proceed to the proof of (5.5.3), we provide another preliminary remark. Let  $f: X \to \mathbb{A}^1$  be a regular function on a variety X. Let U be a Zariski open subset of X, and let Z be the complement of U. Then we have a long exact sequence:

$$(5.5.4) \cdots \to \mathrm{H}^{i}_{c}(U; (f|_{U})^{*}\mathcal{L}_{\psi}) \to \mathrm{H}^{i}_{c}(X; f^{*}\mathcal{L}_{\psi}) \to \mathrm{H}^{i}_{c}(Z; (f|_{Z})^{*}\mathcal{L}_{\psi}) \to \cdots$$

From this sequence, we obtain the inequality:

$$(5.5.5) B_c(X;f) \leq B_c(U;f|_U) + B_c(Z;f|_Z).$$

We will need the following lemma, which is derived from our earlier work on exponential sums. This lemma will establish the main term of the estimate in (5.5.3). Additionally, it will be clear that the error terms in (5.5.3) can also be obtained from this lemma.

<span id="page-35-3"></span>**Lemma 5.5.6.** Suppose  $f_1, \ldots, f_r \in k[x_1, \ldots, x_n]$  satisfy  $\deg f_i \leqslant d$ . Let  $g = \sum_{j=1}^r x_{n+j} f_j$ . Then

<span id="page-35-2"></span>
$$B_c(\mathbb{G}_{\mathrm{m}}^{n+r};g) \leqslant 2^{n+r} \times \binom{n+r-1}{r-1} \times d^n.$$

**Proof.** Let  $S_d$  be the convex hull of  $0, de_1, \ldots, de_n$  in the Euclidean space  $\prod_{i=1}^n \mathbb{R}e_i$  with the standard orthonormal basis  $\{e_1, \ldots, e_n\}$ . Then Newton polytope  $\Delta$  of g is contained in the convex hull of

$$\{0\} \cup (S_d \times \{e_{n+1}\}) \cup \cdots \cup (S_d \times \{e_{n+r}\}).$$

in the Euclidean space

<span id="page-36-0"></span>
$$\mathbb{R}^{n+r} = \left(\prod_{i=1}^{n} \mathbb{R}e_i\right) \times \left(\prod_{i=1}^{r} \mathbb{R}e_{n+i}\right).$$

with the standard orthonormal basis  $\{e_1, \ldots, e_n, e_{n+1}, \ldots, e_{n+r}\}$ . We claim that

(5.5.7) 
$$\Delta^{n+r} \leqslant \binom{n+r-1}{r-1} d^n.$$

Once this claim is established, the lemma will follow from (1.3.7).

Although the claim is elementary, let us work out the detail for the sake of completeness.

Let T be the convex hull in  $\prod_{i=1}^r \mathbb{R}e_{n+i}$  of the vectors  $e_{n+1}, \ldots, e_{n+r}$ . Then T is an (r-1)-dimensional simplex. Its volume is  $\frac{1}{(r-1)!}$  times volume of the parallelotope spanned by the vectors  $e_{n+1} - e_{n+r}, \ldots, e_{n+r-1} - e_{n+r}$ . If r = 1, this is the Euclidean volume of a single point, which is 1. If r > 1, the volume is given by

$$Vol(T) = \frac{1}{(r-1)!} |\det B|^{\frac{1}{2}}$$

where B is the  $(r-1) \times (r-1)$  Gram matrix, whose (i,j) entry is given by the inner product

$$(e_{n+i} - e_{n+r})^T \cdot (e_{n+i} - e_{n+r}).$$

It is clear that

$$B = \begin{bmatrix} 2 & 1 & \cdots & 1 \\ 1 & 2 & \cdots & 1 \\ \vdots & \vdots & \ddots & \vdots \\ 1 & 1 & \cdots & 2 \end{bmatrix},$$

and a simple computation shows that det B = r. Hence,  $Vol(T) = \frac{\sqrt{r}}{(r-1)!}$ .

By definition, the polytope  $\Delta$  is contained in the pyramid C having  $\dot{S}_d \times T$  as its base, with

$$\mathbf{0} = (\underbrace{0, \dots, 0}_{(n+r) \text{ 0's}}) \in \mathbb{R}^{n+r}$$

serving as the vertex. Since the vector

$$v = \frac{1}{r} \sum_{i=1}^{r} e_{n+i} \in S_d \times T,$$

and since  $||v|| = 1/\sqrt{r}$ , the distance from **0** to the base  $S_d \times T$  is no larger than  $1/\sqrt{r}$ . Therefore, we have

$$(n+r)! \operatorname{Vol}(\Delta) \leqslant (n+r)! \operatorname{Vol}(C)$$

$$\leqslant (n+r)! \times \underbrace{\frac{1}{n+r}}_{\text{scaling factor}} \times \operatorname{Vol}(\underbrace{S_d \times T}) \times \underbrace{\frac{1}{\sqrt{r}}}_{\text{height of } C}$$

$$= (n+r-1)! \times \frac{d^n}{n!} \times \frac{\sqrt{r}}{(r-1)!} \times \frac{1}{\sqrt{r}}$$

$$= \binom{n+r-1}{r-1} d^n.$$

In the third step, we used the Fubini theorem. This completes the proof of the claim.

**Proof of** (5.5.3). For each  $I \subset \{1, 2, \dots, n+r\}$ , define

$$T_I = \{(x_1, \dots, x_{n+r}) \in \mathbb{A}^{n+r} : x_i \neq 0 \text{ if } j \in I, x_i = 0 \text{ if } i \notin I\}$$

Then  $T_I$  is isomorphic to  $\mathbb{G}_{\mathrm{m}}^{|I|}$ , and we have

$$\mathbb{A}^{n+r} = \bigsqcup_{I \subset \{1,2,\dots,n+r\}} T_I.$$

By applying the relative long exact sequence (5.5.5) for compactly supported cohomology several times, we find that

$$B_c(\mathbb{A}^{n+r};g) \leqslant \sum_{I \subset \{1,2,\dots,n+r\}} B_c(T_I;g|_{T_I}).$$

For  $I \subset \{1, ..., n+r\}$ , let  $I' = I \cap \{1, ..., n\}$  and  $I'' = I \cap \{n+1, ..., n+r\}$ . Thus

$$g|_{T_I} = \sum_{j+r \in I''} x_{j+r} f_j(\boldsymbol{x}), \quad \boldsymbol{x} \in \mathbb{G}_{\mathrm{m}}^{I'}.$$

We can now apply Lemma 5.5.6 to  $T_I$  and g, and conclude that

$$B_c(T_I; g) \le 2^{|I|} \times \binom{|I| - 1}{|I''| - 1} \times d^{|I'|}.$$

Hence, by (5.5.5),

$$B_{c}(\mathbb{A}^{n+r};g) \leq \sum_{I'} \left[ \sum_{I''} 2^{|I|} \times \binom{|I|-1}{|I''|-1} \right] \times d^{|I'|}$$

$$\leq \binom{n+r-1}{r-1} \sum_{I'} (2d)^{|I'|} \sum_{I''} 2^{|I''|}$$

$$= (2+1)^{r} \binom{n+r-1}{r-1} (2d+1)^{n}$$

<span id="page-37-0"></span>This completes the proof of (5.5.3), and therefore proves Theorem 1.1.2.

**Corollary 5.5.8.** Let X be a closed subvariety of  $\mathbb{P}^n$  that is the common zero locus of r homogeneous polynomials of degree  $\leq d$ . Then

П

$$\sum_{i} \dim \mathbf{H}^{i}(X_{\overline{k}}; \overline{\mathbb{Q}}_{\ell}) \leqslant 3^{r} \binom{n+r-1}{r-1} (2d+2)^{n}$$

where  $H^i(X_{\overline{k}}; \overline{\mathbb{Q}}_{\ell})$  is the  $\ell$ -adic cohomology of X.

**Proof.** For a proper variety over k, the compactly supported cohomology of X is the same as the usual  $\ell$ -adic cohomology. So we only need to bound  $B_c(X, \ell)$ .

Suppose now  $X \subset \mathbb{P}^n$  is defined by homogeneous polynomials  $F_1, \ldots, F_r$  of degree  $\leq d$ . Then  $X = U \sqcup Z$ , where  $U = X \cap \mathbb{A}^n$ . Here we regard  $\mathbb{A}^n$  as a Zariski open subset of  $\mathbb{P}^n$  in the standard way, and Z denotes the intersection of X with the hyperplane at infinity. The subset  $U \subset \mathbb{A}^n$  is cut out by the dehomogenization of  $F_1, \ldots, F_r$ , while Z is cut out in the hyperplane at infinity by r homogeneous polynomials of degree  $\leq d$ .

Using Theorem 1.1.2 to bound  $B_c(U,\ell)$ , using induction to bound  $B_c(Z,\ell)$ , and applying the inequality above, we obtain:

$$B_c(X,\ell) \leqslant B_c(U,\ell) + B_c(Z,\ell)$$

$$\leqslant 3^r \binom{n+r-1}{r-1} (2d+1)^n + 3^r \binom{n+r-2}{r-1} (2d+2)^{n-1}$$

$$\leqslant 3^r \binom{n+r-1}{r-1} (2d+2)^n.$$

This completes the proof of the corollary.

Although not directly related to our main results, we mention the following consequence of (5.5.7) and the classical theorem of Adolphson and Sperber [AS87] on estimating the Euler characteristic of an affine variety:

<span id="page-38-0"></span>**Corollary 5.5.9.** Let k be an algebraically closed field. Let  $V \subset \mathbb{A}^n_k$  be the zero locus of polynomials  $f_1, \ldots, f_r \in k[x_1, \ldots, x_n]$ . Then for any  $\ell$  invertible in k, we have

$$\left|\chi(V;\overline{\mathbb{Q}}_{\ell})\right| \leqslant 2^r \binom{n+r-1}{r-1} (d+1)^n.$$

**Proof.** Again, by the standard reduction, we can assume k is an algebraic closure of a finite field  $\mathbb{F}_q$ , and  $f_i \in \mathbb{F}_q[x_1, \dots, x_n]$ . Write  $g = \sum_{i=1}^r x_{n+i} f_i$ , and  $\mathbb{A}^{n+r} = \bigsqcup_{I \subset \{1, \dots, n+r\}} T_I$  as in the proof of (5.5.3). Then by [AS87, (1.9)], and (5.5.7), we have

$$0 \leqslant (-1)^{|I|} \chi(T_I; g|_{T_I}^* \mathcal{L}_{\psi}) \leqslant \binom{|I| - 1}{|I''| - 1} d^{|I'|},$$

where I, I', and I'' are defined in the proof of (5.5.3). Hence

$$|\chi(V; \overline{\mathbb{Q}}_{\ell})| = |\chi(\mathbb{A}^{n+r}; g^* \mathcal{L}_{\psi})| \leq \sum_{I} |\chi(T_I; g|_{T_I}^* \mathcal{L}_{\psi})|$$

$$\leq \sum_{I} \binom{|I| - 1}{|I''| - 1} \times d^{|I'|}$$

$$\leq \binom{n + r - 1}{r - 1} \times 2^r \times (d + 1)^n.$$

This completes the proof.

**Proof of Theorem 1.3.10(i).** Suppose  $V = \{f_1 = \cdots = f_r = 0\}$ . In Theorem 5.5.1, we take  $X = \mathbb{A}^n$ ,  $E = \mathbb{A}^{n+r}$ , and  $\mathcal{F} = f^*\mathcal{L}_{\psi}$ . Then by a direct computation,  $g^*\mathcal{L}_{\psi} \otimes \varpi^* f^*\mathcal{L}_{\psi}$  is isomorphic to  $(f+g)^*\mathcal{L}_{\psi}$ . This gives us

$$\mathrm{H}_c^j(V; f^*\mathcal{L}_\psi) \simeq \mathrm{H}_c^{j+2r}(\mathbb{A}^{n+r}; (f+g)^*\mathcal{L}_\psi),$$

where  $g = x_{n+1}f_1 + \cdots + x_{n+r}f_r$ .

To complete the proof, we need to bound  $B_c(\mathbb{A}^{n+r}; f+g)$ . Let  $\Delta$  be the Newton polytope of f+g. We claim that

$$\Delta^{n+r} \leqslant \binom{n+r}{r} d^n.$$

The result follows from the above inequality and an argument similar to the proof of (5.5.3). Again, the proof of the inequality is elementary. Let  $S_d$  be the *n*-dimensional simplex with vertices  $0, de_1, \ldots, de_n$  in the Euclidean space  $\prod_{i=1}^n \mathbb{R}e_i$  with the standard orthonormal basis

$$\Delta \subset \mathbb{R}^{n+r} = \left(\prod_{i=1}^n \mathbb{R}e_i\right) \times \left(\prod_{i=1}^r \mathbb{R}e_{n+i}\right)$$

of f + g is contained in the convex hull of

 $\{e_1,\ldots,e_n\}$ . Then the Newton polytope

$$(S_d \times \{\underbrace{(0,\ldots,0)}_{r \text{ zeros}}\}) \cup (S_d \times \{e_{n+1}\}) \cup \cdots \cup (S_d \times \{e_{n+r}\})$$

in the Euclidean space  $\prod_{i=1}^{n+r} \mathbb{R}e_i$  with the standard orthonormal basis  $\{e_1, \ldots, e_n, e_{n+1}, \ldots, e_{n+r}\}$ . Let T' be the r-dimensional simplex in  $\prod_{i=1}^r \mathbb{R}e_{n+i}$  with vertices  $0, e_{n+1}, \ldots, e_{n+r}$ . Then we have

$$\Delta \subset S_d \times T'$$
.

It follows from Fubini that

$$(n+r)! \operatorname{Vol}(\Delta) \leq (n+r)! \times \operatorname{Vol}(S_d) \times \operatorname{Vol}(T')$$
$$= (n+r)! \times \frac{d^n}{n!} \times \frac{1}{r!}$$
$$= \binom{n+r}{r} d^n.$$

<span id="page-39-0"></span>This completes the proof.

### 5.6. A more elementary approach to 1.1.3.

(a) In this subsection, we give a more elementary proof of Corollary 1.1.3, which avoids using the total Betti number estimate for exponential sums. Instead, we combine the reduction of [WZ23] with Katz's Euler characteristic method. This method needs a good upper bound for the absolute value of Euler characteristics of varieties in  $\mathbb{A}^n_k$ . For this, we use Corollary 5.5.9. Let V be any variety in  $\mathbb{A}^n_k$  defined by r polynomials of degree  $\leq d$ . Then we have:

<span id="page-39-1"></span>
$$|\chi(V; \overline{\mathbb{Q}}_{\ell})| \leqslant 2^r \binom{n+r-1}{r-1} (d+1)^n$$

Note that the proof of (5.6.1) relies on just two ingredients: a volume computation and a classical theorem of Adolphson and Sperber. In [Kat01], Katz used a weaker Euler characteristic upper bound of  $2^r \times (rd+r+1)^n$ . The improved bound (5.6.1) leads to better estimates throughout loc. cit.

(b) The first step of the elementary argument is to obtain an upper bound for the total compactly supported Betti numbers of a complete intersection in  $\mathbb{A}^n_k$ . For this, we have two options: we could use Theorem 1.2.2, which is logically independent of Corollary 1.1.3, or we could employ Katz's more elementary Euler characteristic method [Kat01]. Using the bound (5.6.1) as input, Katz's method yields the estimate

<span id="page-39-3"></span>(5.6.2) 
$$B_c^{ci}(n,r;d) \le 2^r \binom{n+r-1}{r-1} (d+2)^n.$$

(We omit proof of this inequality. In Step (c) a similar argument will be given.)

While (5.6.2) is weaker than Theorem 1.2.2, using this bound instead of Theorem 1.2.2 does not affect the final result, since the difference between them is negligible compared to the losses introduced in subsequent steps.

<span id="page-39-2"></span>(c) Now let  $W \subset \mathbb{A}^n_k$  be the common zero locus of polynomials  $f_1, \ldots, f_s \in k[x_1, \ldots, x_n]$ , where we assume  $\deg f_i \leqslant d$  and  $\dim W = n - s$ . Thus, W is set-theoretically a complete intersection. Let  $g \in k[x_1, \ldots, x_n]$  be any polynomial of degree  $\leqslant e$ . We shall further assume  $e \geqslant d$ , as this will be the case in later steps. Let  $V(g) = W \cap \{g = 0\}$ , and  $W[g^{-1}] = W - V(g)$ . Then a simple computation using (5.6.1) shows that

<span id="page-39-4"></span>
$$|\chi(W[g^{-1}]; \overline{\mathbb{Q}}_{\ell})| = |\chi(W; \overline{\mathbb{Q}}_{\ell}) - \chi(V(g); \overline{\mathbb{Q}}_{\ell})|$$

$$\leq 3 \times 2^{s} \times {n+s \choose s} \times (e+1)^{n}.$$

With the Euler characteristic bound of  $W[g^{-1}]$ , we can now recast Katz's method to get a total compactly supported Betti number bound for  $W[g^{-1}]$  using Deligne's perverse Lefschetz theorem as follows. To begin with, since W is set-theoretically a complete intersection, the shifted constant sheaf  $\overline{\mathbb{Q}}_{\ell,W}[n-s]$  is a perverse sheaf on W (the support condition is trivially satisfied, and the cosupport condition follows from Lemma 2.1.1). Since  $W[g^{-1}]$  is an open subscheme of W,  $\overline{\mathbb{Q}}_{\ell,W[g^{-1}]}[n-s]$  is also perverse on  $W[g^{-1}]$ . We can now apply Lemma 2.3.3 with  $X = W[g^{-1}]$  and f being the inclusion morphism, to conclude that for a general hyperplane B,

$$\dim \mathcal{H}_c^{n-s+1}(W[g^{-1}]; \overline{\mathbb{Q}}_{\ell}) \leqslant \dim \mathcal{H}_c^{n-s-1}((W \cap B)[g^{-1}]; \overline{\mathbb{Q}}_{\ell}),$$

and, for  $j \ge 2$ ,

$$\dim \mathbf{H}_c^{n-s+j}(W[g^{-1}]; \overline{\mathbb{Q}}_{\ell}) = \dim \mathbf{H}_c^{n-s+j-2}((W \cap B)[g^{-1}]; \overline{\mathbb{Q}}_{\ell}).$$

Combining these inequalities with (5.6.3), we get

<span id="page-40-0"></span>
$$\dim \mathcal{H}_{c}^{n-s}(W[g^{-1}]) \leqslant (-1)^{n-s} \chi(W[g^{-1}]; \overline{\mathbb{Q}}_{\ell}) + (-1)^{n-s+1} \chi((W \cap B)[g^{-1}]; \overline{\mathbb{Q}}_{\ell})$$

$$\leq 3 \times 2^{s+1} \times \binom{n+s}{s} \times (e+1)^{n}.$$

Applying (5.6.4) to  $(W \cap B)[g^{-1}]$  yields

$$\dim \mathcal{H}_c^{n-1-s}((W \cap B)[g^{-1}]; \overline{\mathbb{Q}}_\ell) \leqslant 3 \times 2^{s+1} \times \binom{n-1+s}{s} \times (e+1)^{n-1}.$$

Continuing slicing  $W[g^{-1}]$  by hyperplanes and using the weak Lefschetz theorem mentioned above, we conclude that

$$B_c(W[g^{-1}], \ell) \leq 3 \times 2^{s+1} \times \sum_{i=0}^{n-s} {n+s-i \choose s} (e+1)^n$$

$$< 3 \times 2^{s+1} \times {n+s \choose s} \times (e+2)^n.$$

<span id="page-40-1"></span>(d) Now let us consider the general case. Thus let V be the common zero locus of r polynomials  $f_1 = \cdots = f_r = 0$ , satisfying  $\deg f_i \leqslant d$ . Suppose  $\dim V = n - s$ . If s = r, then V is a set-theoretic complete intersection and we have obtained estimates for its total Betti number. In the following, we shall assume  $r - s \geqslant 1$ , namely  $s \leqslant r - 1$ .

By [WZ22, Lemma 5.1], upon choosing a different set of r defining polynomials (without changing V), we can assume  $W = \{f_1 = \cdots = f_s = 0\}$  is a set-theoretic complete intersection, i.e., dim  $W = \dim V = n - s$ . Thus, the remaining r - s polynomials  $f_{s+1}, \ldots, f_r$  will not drop the dimension of W. For each nonempty subset I of  $\{s+1,\ldots,r\}$ , let  $f_I = \prod_{i \in I} f_i$ . Then there is a Mayer-Vietoris spectral sequence

$$E_2^{-p,q} = \bigoplus_{|I|=p+1} \mathrm{H}^q_c(W[f_I^{-1}]; \overline{\mathbb{Q}}_\ell) \Rightarrow \mathrm{H}^{q-p}_c(W - V; \overline{\mathbb{Q}}_\ell).$$

Using the spectral sequence, (5.6.5) implies that

<span id="page-40-2"></span>
$$B_{c}(W - V; \ell) \leqslant \sum_{\substack{I \subset \{s+1, \dots, r\}\\I \neq \emptyset}} B_{c}(W[f_{I}^{-1}], \ell)$$

$$\leqslant 3 \times 2^{s+1} \times \binom{n+s}{s} \times \sum_{\substack{I \subset \{s+1, \dots, r\}\\I \neq \emptyset}} (|I|d + 2)^{n}$$

$$\leqslant 3 \times 2^{s+1} \times \binom{n+s}{s} \times 2^{r-s} \times [(r-s)d + 2]^{n}$$

$$= 3 \times 2^{r+1} \times \binom{n+s}{s} \times [(r-s)d + 2]^{n}.$$

It follows that

$$B_c(V,\ell) \leqslant B_c(W,\ell) + B_c(W - V,\ell)$$
[by (5.6.2) and (5.6.6)]  $\leqslant 2^s \binom{n+s-1}{s-1} (d+2)^n + 3 \cdot 2^{r+1} \binom{n+s}{s} ((r-s)d+2)^n$ 

$$< 7 \times 2^r \times \binom{n+s}{s} \times [(r-s)d+2]^n$$

Therefore, we have arrived at Corollary 1.1.3 once again. This time, the implied constant depends on the dimension n-s of V in  $\mathbb{A}^n$ .

<span id="page-41-6"></span>**Theorem 5.6.7.** Let V be a subvariety of  $\mathbb{A}^n_k$  of codimension s. Suppose V is the common zero locus of r polynomials of degree  $\leq d$ .

- (i) If r = s, then we have  $B_c(V, \ell) \leqslant \binom{n-1}{r-1}(d+1)^n$ .
- (ii) If  $r \ge s + 1$ , then we have

$$B_c(V,\ell) \leqslant 7 \times 2^r \times \binom{n+s}{s} \times [(r-s)d+2]^n$$

Without prior knowledge of the relation between r and s, the inequality (ii) is generally weaker than Theorem 1.1.2. However, when r = s + 1, (ii) can be better than Theorem 1.1.2.

#### References

- <span id="page-41-0"></span>[AS87] Alan Adolphson and Steven Sperber, Newton polyhedra and the degree of the L-function associated to an exponential sum, Invent. Math. 88 (1987), no. 3, 555–569. MR 884800
- <span id="page-41-8"></span>[AS89] \_\_\_\_\_, Exponential sums and Newton polyhedra: cohomology and estimates, Ann. of Math. (2) 130 (1989), no. 2, 367–406. MR 1014928
- <span id="page-41-14"></span>[AS00] \_\_\_\_\_, Exponential sums on A<sup>n</sup>, Israel J. Math. **120** (2000), 3–21. MR 1815368
- <span id="page-41-10"></span>[BBD82] Alexander A. Beilinson, Joseph Bernstein, and Pierre Deligne, Faisceaux pervers, Analysis and topology on singular spaces, I (Luminy, 1981), Astérisque, vol. 100, Soc. Math. France, Paris, 1982, p. 5–171. MR 751966
- <span id="page-41-15"></span>[BD04] Francesco Baldassarri and Andrea D'Agnolo, On Dwork cohomology and algebraic D-modules, Geometric aspects of Dwork theory, Walter de Gruyter, Berlin, 2004, p. 245–253. MR 2023291
- <span id="page-41-1"></span>[Bom78] E. Bombieri, On exponential sums in finite fields. II, Invent. Math. 47 (1978), no. 1, 29–39.
  MR 506272
- <span id="page-41-3"></span>[BS88] Enrico Bombieri and Steven Sperber, On the degree of Artin L-functions in characteristic p, C. R. Acad. Sci. Paris Sér. I Math. **306** (1988), no. 9, 393–398. MR 934603
- <span id="page-41-5"></span>[CRW22] Qi Cheng, J. Maurice Rojas, and Daqing Wan, Computing zeta functions of large polynomial systems over finite fields, J. Complexity 73 (2022), Paper No. 101681, 10. MR 4474656
- <span id="page-41-7"></span>[Del77] Pierre Deligne, Cohomologie étale, Lecture Notes in Mathematics, vol. 569, Springer-Verlag, Berlin, 1977, Séminaire de géométrie algébrique du Bois-Marie (SGA  $4\frac{1}{2}$ ). MR 463174
- <span id="page-41-11"></span>[Del80] \_\_\_\_\_, La conjecture de Weil. II, Inst. Hautes Études Sci. Publ. Math. (1980), no. 52, 137–252. MR 601520 (83c:14017)
- <span id="page-41-9"></span>[DK73] Pierre Deligne and Nichlas M. Katz, Groupes de monodromie en géométrie algébrique. II, Lecture Notes in Mathematics, vol. 340, Springer-Verlag, Berlin-New York, 1973, Séminaire de Géométrie Algébrique du Bois-Marie 1967–1969 (SGA 7 II), Dirigé par P. Deligne et N. Katz. MR 354657
- <span id="page-41-13"></span>[DL91] Jan Denef and François Loeser, Weights of exponential sums, intersection cohomology, and Newton polyhedra, Invent. Math. 106 (1991), no. 2, 275–294. MR 1128216
- <span id="page-41-12"></span>[FK88] Eberhard Freitag and Reinhardt Kiehl, Étale cohomology and the Weil conjecture, Ergebnisse der Mathematik und ihrer Grenzgebiete (3) [Results in Mathematics and Related Areas (3)], vol. 13, Springer-Verlag, Berlin, 1988, Translated from the German by Betty S. Waterhouse and William C. Waterhouse, With an historical introduction by J. A. Dieudonné. MR 926276
- <span id="page-41-4"></span>[FW03] Lei Fu and Daqing Wan, Total degree bounds for Artin L-functions and partial zeta functions, Math. Res. Lett. 10 (2003), no. 1, 33–40. MR 1960121
- <span id="page-41-2"></span>[Har15] David Harvey, Computing zeta functions of arithmetic schemes, Proc. Lond. Math. Soc. (3) 111 (2015), no. 6, 1379–1401. MR 3447797

- <span id="page-42-1"></span>[HT25] Haoyu Hu and J.-B. Teyssier, Estimates for Betti numbers and relative Hermite–Minkowski theorem for perverse sheaves, (to appear) (2025).
- <span id="page-42-17"></span>[Ill03] Luc Illusie, Perversit´e et variation, Manuscripta Math. 112 (2003), no. 3, 271–295. MR 2067039
- <span id="page-42-22"></span>[Kat80] Nicholas M. Katz, Sommes exponentielles, Ast´erisque, vol. 79, Soci´et´e Math´ematique de France, Paris, 1980, Course taught at the University of Paris, Orsay, Fall 1979, With a preface by Luc Illusie, Notes written by G´erard Laumon, With an English summary. MR 617009
- <span id="page-42-21"></span>[Kat88] , Gauss sums, Kloosterman sums, and monodromy groups, Annals of Mathematics Studies, vol. 116, Princeton University Press, Princeton, NJ, 1988. MR 955052
- <span id="page-42-16"></span>[Kat93] , Affine cohomological transforms, perversity, and monodromy, J. Amer. Math. Soc. 6 (1993), no. 1, 149–222. MR 1161307
- <span id="page-42-10"></span>[Kat99] , Estimates for "singular" exponential sums, Internat. Math. Res. Notices (1999), no. 16, 875–899. MR 1715519
- <span id="page-42-0"></span>[Kat01] , Sums of Betti numbers in arbitrary characteristic, Finite Fields Appl. 7 (2001), no. 1, 29–44, Dedicated to Professor Chao Ko on the occasion of his 90th birthday. MR 1803934
- <span id="page-42-14"></span>[Kho78] A. G. Khovanski˘i, Newton polyhedra, and the genus of complete intersections, Funktsional. Anal. i Prilozhen. 12 (1978), no. 1, 51–61. MR 487230
- <span id="page-42-20"></span>[KL85] Nicholas M. Katz and G´erard Laumon, Transformation de Fourier et majoration de sommes exponentielles, Inst. Hautes Etudes Sci. Publ. Math. (1985), no. 62, 361–418. MR 823177 ´
- <span id="page-42-15"></span>[KW01] Reinhardt Kiehl and Rainer Weissauer, Weil conjectures, perverse sheaves and l'adic Fourier transform, Ergebnisse der Mathematik und ihrer Grenzgebiete. 3. Folge. A Series of Modern Surveys in Mathematics [Results in Mathematics and Related Areas. 3rd Series. A Series of Modern Surveys in Mathematics], vol. 42, Springer-Verlag, Berlin, 2001. MR 1855066 (2002k:14026)
- <span id="page-42-23"></span>[Lau87] G´erard Laumon, Transformation de Fourier, constantes d'´equations fonctionnelles et conjecture de Weil, Inst. Hautes Etudes Sci. Publ. Math. (1987), no. 65, 131–210. MR 908218 ´
- <span id="page-42-19"></span>[LW54] Serge Lang and Andr´e Weil, Number of points of varieties in finite fields, Amer. J. Math. 76 (1954), 819–827. MR 65218
- <span id="page-42-2"></span>[LW08] Alan G. B. Lauder and Daqing Wan, Counting points on varieties over finite fields of small characteristic, Algorithmic number theory: lattices, number fields, curves and cryptography, Math. Sci. Res. Inst. Publ., vol. 44, Cambridge Univ. Press, Cambridge, 2008, pp. 579–612. MR 2467558
- <span id="page-42-18"></span>[MPT22] Laurent¸iu G. Maxim, Laurent¸iu P˘aunescu, and Mihai Tib˘ar, Vanishing cohomology and Betti bounds for complex projective hypersurfaces, Ann. Inst. Fourier (Grenoble) 72 (2022), no. 4, 1705–1731. MR 4485837
- <span id="page-42-4"></span>[Per42] Oskar Perron, Beweis und Versch¨arfung eines Satzes von Kronecker, Math. Ann. 118 (1942), 441– 448. MR 10538
- <span id="page-42-8"></span>[Saw20] Will Sawin, A representation theory approach to integral moments of L-functions over function fields, Algebra Number Theory 14 (2020), no. 4, 867–906. MR 4114059
- <span id="page-42-9"></span>[Saw21] , Square-root cancellation for sums of factorization functions over short intervals in function fields, Duke Math. J. 170 (2021), no. 5, 997–1026. MR 4255048
- <span id="page-42-13"></span>[Ste85] Joseph H. M. Steenbrink, Semicontinuity of the singularity spectrum, Invent. Math. 79 (1985), no. 3, 557–565. MR 782235
- <span id="page-42-11"></span>[Wan93] Daqing Wan, Newton polygons of zeta functions and L functions, Ann. of Math. (2) 137 (1993), no. 2, 249–293. MR 1207208
- <span id="page-42-12"></span>[Wan04] , Variation of p-adic Newton polygons for L-functions of exponential sums, Asian J. Math. 8 (2004), no. 3, 427–471. MR 2129244
- <span id="page-42-3"></span>[Wan08] , Algorithmic theory of zeta functions over finite fields, Algorithmic number theory: lattices, number fields, curves and cryptography, Math. Sci. Res. Inst. Publ., vol. 44, Cambridge Univ. Press, Cambridge, 2008, pp. 551–578. MR 2467557
- <span id="page-42-5"></span>[WZ22] Daqing Wan and Dingxin Zhang, Revisiting Dwork cohomology: Visibility and divisibility of frobenius eigenvalues in rigid cohomology, [arXiv:2207.12633](https://arxiv.org/abs/2207.12633) (2022).
- <span id="page-42-6"></span>[WZ23] , Hodge and Frobenius colevels of algebraic varieties, [arXiv:2309.16290](https://arxiv.org/abs/2309.16290) (2023).
- <span id="page-42-7"></span>[Zha25] Dingxin Zhang, On sums of Betti numbers of affine varieties, Finite Fields Appl. 103 (2025), no. 1, Paper No. 102583.

Department of Mathematics, University of California, Irvine, CA 92697-3875 USA.

Email address: dwan@math.uci.edu

Yau Mathematical Sciences Center, Tsinghua University, Beijing 100086 China.

Email address: dingxin@tsinghua.edu.cn