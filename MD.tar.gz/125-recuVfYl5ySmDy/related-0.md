![](_page_0_Picture_3.jpeg)

# Lipase and Metal Chloride Hydrate-Natural Deep Eutectic Solvents Synergistically Catalyze Amidation Reaction via Multiple **Noncovalent Bond Interactions**

Binbin Nian, Chen Cao, and Yuanfa Liu\*

State Key Laboratory of Food Science and Technology, School of Food Science and Technology, National Engineering Research Center for Functional Food, National Engineering Laboratory for Cereal Fermentation Technology, Collaborative Innovation Center of Food Safety and Quality Control in Jiangsu Province, Jiangnan University, 1800 Lihu Road, Wuxi, 214122 Jiangsu, People's Republic of China

Supporting Information

ABSTRACT: With their extreme advantages in high surface activity, bacteriostasis, and low toxicity, lipoamino acids (LAA) attracted widespread academic and industrial interests. In this study, natural deep eutectic solvents (NADESs), were adopted as a medium of enzymatic synthesis of lauroyl glycine (LG). The highest yield of  $50.49 \pm 1.94\%$  was obtained in the C-Gly system. Interestingly, a synergistic effect between CALB and NADESs was found in this section. We proposed that anions play a key role in this process. To explore it, metal chloride hydrates were added into C-Gly. Fortunately, seven kinds of three-constituent NADESs (3c-NADESs) with a low viscosity were successfully formed. All of these new-design solvents were used as a medium of enzymatic of LG, and the highest yield of LG can reach  $85.97 \pm 1.86\%$  after optimization. To explore the mechanism of the synergistic effect between CALB and 3c-NADESs. The results of molecular dynamics studies (MD) showed that there was no significant change of CALB in this process, which indicated that CALB

![](_page_0_Figure_10.jpeg)

may play a secondary role in the synergistic effect. In this context, we studied the molecular interaction between Mg-CGly and lauric acid, and the reaction processes were studied in depth via IRC method. The results suggested that a strong H-bond was formed between Cl- and lauric acid. This interaction may increase the electron-attracting ability of fatty acids and make them more susceptible to be attacked by amino acids and thus to increase the yield of amidation reaction of lauric acid and glycine.

KEYWORDS: Enzymatic synthesis, Lipoamino acids, Green chemistry, Three-consistent NADESs

## **■** INTRODUCTION

As one of the 12 principles of green chemistry, the utilization of renewable feedstock as a succedaneum of the petrochemicalbase has been always a key strategy to make a sustainable and green chemistry process in contemporary industries. Moreover, it is of growing interest to utilize natural starting materials as an alternative to the primary resources which have dwindled and are more costly in food and health-related fields.<sup>2-5</sup> In view of the great advantages of food emulsifiers in maintaining food flavor and morphology, it has become one of the most consumed food additives. 6,7 Therefore, the manufacture of food emulsifiers from renewable, safe, and natural raw materials is of paramount importance.

Lipoamino acids (LAA), also known as N-acyl amino acids, are synthesized by amidation reaction of fatty acids and amino acids. It is considered to be much safer compared with traditional surfactants. In addition, LAA also has a high surface activity, bacteriostasis, and low toxicity, which make it extremely valuable in food, personal care, and biological fields.<sup>8,9</sup> Despite their attractiveness, LAA can hardly be utilized on an industrial scale. In previous studies, LAA were mostly synthesized by organic synthesis, which could cause large amounts of byproducts and environmental problems and can hardly be considered as "green". 10 Given their extreme advantages in selectivity, efficiency, and sustainability, enzymatic reaction is considered as an alternative of classical organic reaction. 11-14 Attracting much academic and industrial interests, enzymatic reactions have also been widespread utilized in food processes and biological engineering. 15,16 In this context, some efforts have been made in the enzymatic synthesis of LAA in previous studies.3,17-19 However, as the polar substrates are almost insoluble in nonpolar enzymefriendly solvents, while polar solvents tend to cause enzyme inactivation, we have to compromise between the high enzyme activity and high solubility of substrate, which are both important to enzymatic synthesis. 20,21 Therefore, the development of novel enzyme-friendly green solvents with good

Received: September 24, 2019 Revised: October 7, 2019 Published: October 11, 2019

substrate solubility has become a key factor in the enzymatic synthesis of LAA. <sup>22</sup>

In this context, some attempts have been made to develop a novel enzyme-friendly green solvents with good substrate solubility. For instance, Kragl and co-workers suggested that ionic liquids offer new possibilities for the application of solvent engineering to biocatalytic reactions. Some other researchers also found that ionic liquids can act as a tool to improve enzymatic organic synthesis. Moreover, supercritical carbon dioxide has also been considered as a potential solvent for enzymatic reactions, which can maintain high enzyme activity. He and co-workers suggested that selenocyanation of activated alkynes can be catalyzed via NADESs and hydrogenbonding interaction may play a key role in this process. Hallett et al. modified the glucosidase in using ionic liquids and the results showed that the thermal stability of glucosidase can be increased up to 137 °C.

However, given the potential toxicity of ionic liquids and the high cost of supercritical carbon dioxide, they can hardly be utilized on an industrial scale. In a previous study of our group, a series of novel solvents which were in full accord with the 12 principles of green chemistry, namely natural deep eutectic solvents (NADESs), have been proved to be a perfect medium of Candida antarctica lipase B (CALB), in which CALB can be activated up to  $156.64 \pm 8.12\%$ . Inspired by this and to develop an efficient and sustainable strategy enzymatic synthesis LAA, in this study, NADESs were applied as the medium of enzymatic synthesis of a typical LAA, namely lauroyl glycine (LG). First, the reaction was performed in traditional solvents and obtained an extremely low yield. Then the reactions were carried out in ten kinds of selected NADESs, and a relatively high yield was obtained. As both NADESs and CALB play a key role in enzymatic synthesis of LG, we proposed that there was a synergistic effect between them, and anions play a key role in this process. To increase anions of this system, MgCl<sub>2</sub>·6H<sub>2</sub>O and FeCl<sub>3</sub>·6H<sub>2</sub>O were added into C-Gly. Finally, MD and quantum calculations were adopted in this study to explore the mechanism of it from an atomic perspective.

### ■ MATERIALS AND METHODS

Chemicals and Reagents. Choline chloride (CAS 67-48-1, ≥98%), glycerol (CAS 56-81-5, ≥98%), glycine (CAS 56-40-6, ≥99.5%), and lauric acid (CAS 143-07-7, ≥98%) were purchased from J & K Chemical Technology Scientific Ltd., (Shanghai, China). Lipase immobilized on acrylic resin from *Candida antarctica* (CALB; 10000 U/g) was purchased from Novozymes (China) Investment Co., Ltd., (Shanghai, China). Other chemicals, purchased from J & K Chemical Technology (Shanghai, China), were of analytical grade unless stated otherwise.

Enzymatic Synthesis of Lauroyl Glycine in Traditional Solvents. As the model of traditional solvents, acetone (hydrophobic solvent), dimethyl sulfoxide (DMSO, hydrophilic solvent), and a classical ionic liquid, 1-butyl-3-methylimidazolium chloride ( $[C_4\text{mim}]Cl$ ) were adopted in this section. Moreover, a type of commercialized lipase, namely CALB, which has been proved to have a great performance in acylation reaction was applied as the catalyst. Each reaction system involved 1 mmol of glycine, 1 mmol of fatty acids, 20 mL of solvents, and 50 mg of CALB. The reaction was carried out in triplicate under the condition of 500 rpm, 333 K, for 48 h. The reaction process was monitored by thin layer chromatography (TLC), and the yield of the reaction was measured by high performance liquid chromatography. The product was characterized by a MALDI SYNAPT ESI-MS (waters, America), an IS10 FT-IR (Nicolet, America) and an Aduance III 400 MHz NMR (RUKER

AXS GMBH, Germany). HPLC analysis was applied to detect the yield of the reaction. The reaction mixture was loaded on a C18 column (4.6  $\times$  250 mm), equilibrated with an acetonitrile/water (60% V/V) solution. The product was eluted with a gradient as follows (acetonitrile/water): 60/40 (V/V) for 0–6 min, 95/5 (V/V) for 6–24 min at a flow rate of 0.6 mL/min and an UV–vis detector were used for the data collection. The standard lauroyl glycine for HPLC analysis was synthesized by Schotten-Baumann reaction.  $^8$ 

**Prepare of NADESs and 3c-NADESs.** NADESs were prepared according to the methods of Choi et al.<sup>26,27</sup> Sixteen NADESs which have been reported as medium of enzymatic reaction were selected as potential solvents in this study. The components of NADESs which have been listed in Table S1 were added into a 100 mL bottle. The mixtures were heated at 353 K and stirred at a speed of 200 rpm for 2 h until a clear transparent liquid was obtained. 3c-NADESs were constructed following the mole ratio as shown in Table S3, and the mixture was heated at 373 K and stirred at 200 rpm for 2 h. All NADESs and 3c-NADESs need to be vacuum-dried to prevent the possible interference of water in the reactions.

Enzymatic Synthesis of Lauroyl Glycine in NADESs and 3c-NADESs. All NADESs that are listed in Table 2 were adopted as the medium of the enzymatic synthesis of LAA. As a typical reaction, LG was synthesized by amidation reaction of lauric acid and glycine. In all cases, the mole ratio of fatty acid (1 mmol) and glycine (1 mmol) was 1:1, the mixture was stirred at a speed of 500 rpm for 120 h, and the reaction temperature was 333 K. Each reaction system contained 50 mg or 0 mg of CALB. In order to maintain the mole ratio of HBD/HBA of NADESs in the reaction, the NADESs mixtures were prepared at an increased factor of 50 (for instance, 50 mol choline chloride and 100 mmol glycerin). The products were characterized by a MALDI SYNAPT ESI-MS (waters, America).

All reactions were performed similar to those described in the section Enzymatic Synthesis of Lauroyl Glycine in NADESs, but the solvents were replaced by seven kinds of 3c-NADESs.

**Optimization Procedure Using the Taguchi Crossed Array Method.** The optimization of enzymatic synthesis of LG was done in the C-Gly system using the Taguchi crossed array method which has been widely used in other studies.<sup>29</sup> As shown in Table S4, four of the most important controllable parameters which effected the yield of LG were list. L9 assays designed by Minitab software version 18 were displayed as Table S5. All reactions involved in this section were carried out in triplicate.

Molecular Interaction between 3c-NADESs and CALB. All simulation involved in this section were performed by Gromacs software version 2019.3,30 and Mg-CGly3 was selected as the model of 3c-NADESs. Gromos force field which has been widespread used in ionic liquids were adopted to represent the interaction potentials of CALB and Mg-CGly3, respectively. 31-33 CALB (PDB ID: 4K5Q) which was obtained from RCSB Protein Data Bank was placed in a 3.0  $\times$  3.0  $\times$  3.0 nm box and then filled with a requisite number of Mg-CGly3. The integration step of the equations of motion was 1 fs.<sup>3</sup> The nonbonded interactions cutoff in real space is set to 1.2 nm. 5000 steps of the steepest descent followed by 5000 steps of conjugate gradients were used in energy minimization. The simulation of CALB was initialized in the canonical ensemble (NVT) for 1000 ps, followed by the introduction of 1000 ps of isobaric-isothermal (NPT) ensemble into the system. The simulations were performed at 333 K for 30 ns in Mg-CGly3.

**Quantum Calculations.** Fifty possible initial geometries of Mg-CGly3 cluster were obtained by Molclus 1.8.7 software package. TB software version 6.2<sup>36</sup> was applied to optimize these initial geometries in a rough level, and Gaussian 16 software<sup>37</sup> was adopted to obtain the precise geometries at a level of M06-2X/6-311++G\*\*. Six of most stable geometries were obtained, and the one with the lowest energy was considered as the most stable geometry of Mg-CGly3. Multiwfn software version 3.7 was applied to analyze the bond-acceptor—donor interactions of these systems. Atom-inmolecules (AIM) theory was used to quantity noncovalent interactions in this system.

<span id="page-2-0"></span>Statistical Analysis. Each experiment involved in this study was carried out in triplicate. The experimental data were analyzed by SPSS  $22.0 \ (P < 0.05).$ 

### ■ RESULTS AND DISCUSSION

**Enzymatic Synthesis of Lauroyl Glycine in Traditional** Solvents. As shown in Table 1 and Figure S1, LG was

Table 1. Yield of LG via Enzymatic Synthesis in Traditional

| S. no. | solvent                           | yield <sup>b</sup> , % | yield <sup>c</sup> , % |
|--------|-----------------------------------|------------------------|------------------------|
| 1      | DMSO                              | N.R.                   | $8.62 \pm 1.61^{c}$    |
| 2      | acetone                           | N.R.                   | $5.16 \pm 0.94^{c}$    |
| 3      | $\lceil C_4 \text{mim} \rceil Cl$ | $2.98 \pm 1.16$        | $11.91 \pm 2.16^{b}$   |

<sup>a</sup>Each reaction system included 1 mmol glycine, 1 mmol lauric acid, 50 mg or 0 mg enzyme and 20 mL solvents. The reactions were carried out at 500 rpm, 333 K for 120 h. bYield: the yield of LG without catalyzation of CALB. 'Yield: the yield of LG with catalyzation of CALB. Lowercase letters in table indicate significant differences within groups (P < 0.05)..

Table 2. Construction of NADESs<sup>a</sup>

| S. no.                                              | HBA              | HBD        | HBA:HBD | abbreviations |
|-----------------------------------------------------|------------------|------------|---------|---------------|
| 1                                                   | choline chloride | glucose    | 5:2     | C-Glu         |
| 2                                                   | choline chloride | xylitol    | 1:1.5   | C-X           |
| 3                                                   | choline chloride | urea       | 1:2     | C-U           |
| 4                                                   | choline chloride | malic acid | 1:1     | C-M           |
| 5                                                   | choline chloride | glycerin   | 1:2     | C-Gly         |
| 6                                                   | betaine          | xylitol    | 1:2     | B-X           |
| 7                                                   | betaine          | urea       | 1:2     | B-U           |
| 8                                                   | betaine          | malic acid | 1:2     | B-M           |
| 9                                                   | betaine          | glycerin   | 1:2     | B-Gly         |
| 10                                                  | malic acid       | glycerin   | 1:1     | M-Gly         |
| <sup>a</sup> HBD and HBA are given in molar ratios. |                  |            |         |               |

successfully synthesized in all three traditional solvents catalyzed by CALB (see Supporting Information). However, in DMSO and acetone systems, LG cannot be synthesized to any appreciable extent, and in [C<sub>4</sub>mim] Cl system, the yield of LG was  $2.98 \pm 1.16\%$  without catalyzation of CALB. The product was characterized by FT-IR, and the results were displayed in Figure S1a, the characteristic peak of the FT-IR of the product was substantially identical to that of LG. Among them, the peaks of 3321.92 cm<sup>-1</sup>, 1704.31 cm<sup>-1</sup>, 1643.87 and

Table 4. Yield of LG in 3c-NADESs with CALB at 333 K

| S. no. | 3c-NADESs | yield, %                    |
|--------|-----------|-----------------------------|
| 1      | Mg-CGly1  | $59.49 \pm 1.62^{e}$        |
| 2      | Mg-CGly2  | $68.62 \pm 1.31^{b}$        |
| 3      | Mg-CGly3  | $75.34 \pm 2.19^{a}$        |
| 4      | Mg-CGly4  | $75.62 \pm 2.08^{a}$        |
| 5      | Mg-CGly5  | $76.31 \pm 1.54^{a}$        |
| 6      | Fe-CGly1  | $54.36 \pm 1.87^{\text{f}}$ |
| 7      | Fe-CGly2  | $55.28 \pm 1.43^{\rm f}$    |

<sup>a</sup>Each reaction system included 1 mmol glycine, 1 mmol lauric acid, 50 mg enzyme and 20 mL 3c-NADESs. The reactions were carried out at 500 rpm, 333 K for 120 h. Lowercase letters in table indicate significant differences within groups (P < 0.05).

Table 5. Controllable Parameters and Yield of L<sub>9</sub> Orthogonal Array for Optimization Procedure

| trail no. | yield (%)                |
|-----------|--------------------------|
| 1         | $56.38 \pm 2.08^{\rm e}$ |
| 2         | $69.54 \pm 1.92^{d}$     |
| 3         | $76.26 \pm 1.84^{\circ}$ |
| 4         | $68.49 \pm 1.66^{d}$     |
| 5         | $76.48 \pm 1.08^{\circ}$ |
| 6         | $83.56 \pm 1.75^{ab}$    |
| 7         | $81.64 \pm 2.07^{b}$     |
| 8         | $73.61 \pm 1.94^{\circ}$ |
| 9         | $85.97 \pm 1.86^{a}$     |
|           |                          |

<sup>a</sup>For detailed description of parameters, A-D and levels 1−3, please refer Table S4, to make the results more reasonable, one L9 assays were adopted. A total number of 27 runs (9 trails\*3repetitions) was needed to arrive at a conclusion.  ${}^{b}$ Significant differences (P < 0.05) between different trials were indicated by lowercase letters.

Table 6. Control Experiments of Enzymatic Synthesis of LG<sup>a</sup>

| entry | catalyst                    | yield (%) of 2b  |
|-------|-----------------------------|------------------|
| 1     | ь                           | $13.62 \pm 1.35$ |
| 2     | empty carrier <sup>c</sup>  | $14.18 \pm 2.06$ |
| 3     | $BSA^d$                     | $13.59 \pm 1.62$ |
| 4     | denatured CALB <sup>e</sup> | $14.31 \pm 2.31$ |

<sup>a</sup>Reaction parameters: 1 mmol lauric acid, 1 mmol glycine, 50 mg catalysts and 20 mL Mg-CGly3 at 333 K for 120 h. bNo catalyst. cacrylic resin. dAlbumin from bovine serum, which is composed of various amino acids. <sup>e</sup>Pretreated by urea at 373 K for 2 h.

Table 3. Yield of LG in NADESs with and without CALB at 333 K

| S. no. | HBA              | HBD        | HBA:HBD | yield <sup>b</sup> , % | yield <sup>c</sup> , %   |
|--------|------------------|------------|---------|------------------------|--------------------------|
| 1      | choline chloride | glucose    | 5:2     | $6.59 \pm 1.31^{cd}$   | $26.65 \pm 1.67^{e}$     |
| 2      | choline chloride | xylitol    | 1:1.5   | $7.94 \pm 0.95^{cd}$   | $41.40 \pm 1.43^{cc}$    |
| 3      | choline chloride | urea       | 1:2     | $6.61 \pm 1.28^{cd}$   | $43.35 \pm 1.66^{\circ}$ |
| 4      | choline chloride | malic acid | 1:1     | $5.42 \pm 1.81^{d}$    | $19.68 \pm 2.08^{\rm f}$ |
| 5      | choline chloride | glycerin   | 1:2     | $11.66 \pm 1.66^b$     | $50.49 \pm 1.94^{b}$     |
| 6      | betaine          | xylitol    | 1:2     | $8.61 \pm 1.93^{cc}$   | $38.97 \pm 1.69^{\circ}$ |
| 7      | betaine          | urea       | 1:2     | $7.66 \pm 2.01^{cd}$   | $31.36 \pm 1.84^{d}$     |
| 8      | betaine          | malic acid | 1:2     | $9.14 \pm 0.76^{b,cc}$ | $15.85 \pm 1.83^{g}$     |
| 9      | betaine          | glycerin   | 1:2     | $10.58 \pm 0.91^{b,c}$ | $43.98 \pm 2.07^{c}$     |
| 10     | malic acid       | glycerin   | 1:1     | $6.61 \pm 0.85^{cd}$   | $19.55 \pm 2.19^{\rm f}$ |

<sup>a</sup>Each reaction system included 1 mmol glycine, 1 mmol lauric acid, 50 mg or 0 mg enzyme and 20 mL NADESs. The reactions were carried out at 500 rpm, 333 K for 120 h. HBA: Hydrogen-bonding acceptors, HBD: hydrogen-bonding donors. <sup>b</sup>Yield: the yield of LG in NADESs without CALB. 'Yield: the yield of LG in NADESs-CALB system. Lowercase letters in table indicate significant differences within groups (P < 0.05).

<span id="page-3-0"></span>![](_page_3_Figure_2.jpeg)

Figure 1. Secondary structure of CALB in Mg-CGly3 and 8 M urea solution at  $333~{\rm K}$  in  $30~{\rm ns}$  simulation.

1558.69 cm $^{-1}$  are attributed to the -NH, -C=O of -COOH; -C=O of -CONH and -C-N- respectively. As shown in Figure S1b, the product showed a characteristic peak with m/z258.1, which was consistent with (LG+H+). The product was also analyzed by <sup>1</sup>HNMR, with tetramethyl silane (TMS) as the internal standard and CD<sub>3</sub>OD as the solvent. The chemical shift values of the peaks and their assignments were shown in Figure S1(c, d). Based on the above results, it can be concluded that LG was successfully synthesized by enzymatic reaction in traditional solvents. It is worth pointing out that the common byproducts (glycylglycine) did not appear in products (Figure S1b), indicating that the reaction has a high selectivity. The yield of LG in this section was measured by HPLC, and the results were expressed in Table 2. Although LG can be successfully synthesized in traditional solvents with the catalyzation of CALB, the highest yield which was obtained in  $[C_4 \text{mim}]$ Cl was 11.91  $\pm$  2.16%, which is significantly lower than that obtained by organic synthesis (above 70%). 3,17-19,39

Construction of NADESs. In view of the extremely low yield of LG in traditional solvents and inspired by the high activity and stability of lipase in NADESs, we were anxious to further explore the potential application of NADESs as enzymatic amidation reactions. As shown in Table S1 (see the Supporting Information), 19 NADESs were successfully constructed, and the fluidity of them at 363 K were measured by visual observation. Eleven kinds of NADESs which have no

![](_page_3_Figure_6.jpeg)

Figure 2. Overall atomic root-mean-square deviation (RMSD, A), root-mean-square fluctuation (RMSF, B), radius of gyration (R(g), C) and hydrophobic solvent accessible surface (D) of CALB were studied via MD studies at 333 K.

<span id="page-4-0"></span>![](_page_4_Figure_2.jpeg)

Figure 3. Center of mass (COM) radial distribution functions (RDF) for 3c-NADESs (A), and COM RDF for Mg-CGly3 components around CALB (B) at 333 K.

Table 7. Combined Free Energy of CALB and Lauric Acid in NADESs and 3c-NADESs Calculated by MM-PBSA

| energy components (kcal mol <sup>-1</sup> ) | C-Gly             | Mg-CGly3          |
|---------------------------------------------|-------------------|-------------------|
| $\Delta E_{ m vdw}$                         | $-25.64 \pm 2.68$ | $-31.28 \pm 3.42$ |
| $\Delta E_{ m ele}$                         | $-6.28 \pm 1.16$  | $-10.95 \pm 5.86$ |
| $\Delta G_{ m polar,sol}$                   | $21.52 \pm 1.84$  | $26.18 \pm 4.19$  |
| $\Delta G_{ m nonpolar, sol}$               | $-4.26 \pm 2.18$  | $-5.94 \pm 2.38$  |
| $\Delta G_{ m sol}$                         | $16.92 \pm 0.34$  | $20.24 \pm 1.81$  |
| $\Delta G_{ m polar}$                       | $19.68 \pm 6.29$  | $21.52 \pm 8.64$  |
| $\Delta G_{ m nonpolar}$                    | $-22.95 \pm 2.12$ | $-32.71 \pm 6.58$ |
| $\Delta G_{ m bind}$                        | $-3.27 \pm 4.17$  | $-11.19 \pm 2.06$ |

fluidity or high viscosity were considered unsuitable for enzymatic reactions. To reduce the viscosity of them, the mole ratios of HBA:HBD were modified as Table S2 (see the Supporting Information). Obviously, the viscosity and fluidity of NADESs were significantly affected by the mole ratio of HBA:HBD, and four kinds of them have fluidity at 363 K. Consideration of the results of Tables S1 and S2, ten kinds of NADES with low viscosity was selected for further study (Table 2).

Enzymatic Synthesis of LG in NADESs and 3c-NADESs. As shown in Table 3, LG can be successfully synthesized in all NADESs with or without the catalyzation of CALB. However, the yield in NADESs without CALB was significantly lower than that in CALB-NADESs systems. For instance, the highest yield which was obtained in C-Gly was  $11.66 \pm 1.66\%$ , which was even much lower than that in CALB-traditional systems. Interestingly, considerable yields were obtained in NADESs-CALB systems. Moreover, malic acid-containing NADESs have the worst performance compared with other NADESs. For instance, the yield of LG in C-M, B-M, and M-Gly was  $19.68 \pm 2.08\%$ ,  $15.85 \pm 1.83\%$ , and  $19.55 \pm 2.19\%$ , respectively. It can be attributed to the strong acidity of malic acid leading to changes in the secondary structure of CALB and resulting in a low enzyme activity. Choline chloride-containing NADESs tended to perform better than betaine-containing NADESs. For instance, the yield of LG in C-U and B-U was 43.35  $\pm$  1.66% and 31.36  $\pm$ 1.84%, respectively. Especially, the highest yield (50.49  $\pm$ 1.94%) was obtained in C-Gly with the catalyzation of CALB, which is  $437.38 \pm 46.09\%$  higher than that in C-Gly without

![](_page_4_Picture_8.jpeg)

**Figure 4.** Optimized geometries of Mg-CGly calculated by quantum calculations at a level of  $M06-2X/6-311++G^{**}$ . The total energy of them were labeled in red (A-F).

CALB. In view of the extremely low yield of LG in traditional solvents and NADESs without CALB, and the considerable yield in NADESs-CALB systems, we proposed that there was a synergistic effect between CALB and NADESs. It is agreement with the previous studies of our study which indicated hydrogen-bonding interaction between NADESs, or more especially anions such as chloride ion and substrates improved CALB activity. Inspired by this, we proposed that anions such as chloride ion enhanced performance of CALB in

<span id="page-5-0"></span>![](_page_5_Figure_2.jpeg)

Figure 5. Noncovalent interaction plots of Mg-CGly3 (A, B) and Mg-CGly3-lauric acid (C, D) systems.

![](_page_5_Figure_4.jpeg)

Figure 6. Reaction barrier of amidation of lauric acid and glycine in Mg-CGly (A) and C-Gly (B). \* Transition state (TS) of reaction was obtained at a level of M06-2X/6-311++G\*\*, and harmonic vibrational frequency calculations suggested there was only one virtual frequency of it. The geometries of the complex of reagents and products were obtained from the intrinsic reaction coordinate (IRC), and optimized at a same level of optimization of TS. To obtain more accurate energy, the single point energy of optimization geometries was calculated at a level of M06−2x/def2-TZVP.

NADESs. In this context, we were anxious to investigate whether we can improve the yield of LG by adding anions to these systems. Moreover, as C-Gly tended to have the best performance in this process, it was selected to further study in the following sections.

As we know, there were four types of DESs have been successfully formed, namely type I DESs (quaternary ammonium salts with metal chloride), type II DESs (quaternary ammonium salts with metal chloride hydrate), type III DESs (quaternary ammonium salts with a hydrogen bond donor), and type IV DESs (metal chloride hydrate with a hydrogen bond donor).[40](#page-10-0) Inspired by the key role of metal chlorides and its hydrates in the formation of DESs, two kinds of metal chloride hydrates, namely MgCl2·6H2O and FeCl3· 6H2O were tested to mix with C-Gly to design new kinds of metal chloride hydrate-NADESs three-consistent NADESs (3c-NADESs) systems. For each metal chloride hydrate, five mole fractions (0.1−0.5) of it were selected to test its potential capacity to design new kinds of 3c-NADESs. Fortunately, as shown in Table S3 and Figure S2 (see the [Supporting](http://pubs.acs.org/doi/suppl/10.1021/acssuschemeng.9b05691/suppl_file/sc9b05691_si_001.pdf) [Information](http://pubs.acs.org/doi/suppl/10.1021/acssuschemeng.9b05691/suppl_file/sc9b05691_si_001.pdf)), 3c-NADESs can be successfully formed in all cases of MgCl2·6H2O, while when mole fraction of FeCl3· 6H2O increased up to 0.3, a large amount of precipitation can be found in solution, which indicated 3c-NADESs cannot be formed. In this context, seven kinds of new-designed NDAESs with high fluidity were successfully formed and applied to enzymatic synthesis of LG as mediums. As shown in [Table 4](#page-2-0), in all 3c-NADESs, a significantly improvement of yield of LG can be obtained. It was agreement with the above proposed mechanism that chloride ion enhanced enzyme performance in NADESs. Moreover, a closer look at these reactions give us some information that  $MgCl_2\cdot 6H_2O$ -containing 3c-NADESs have a good performance than that of  $FeCl_2\cdot 6H_2O$  containing 3c-NADESs. The highest yield of LG was obtained in Mg-CGly3–5 (75.62  $\pm$  2.08% to 76.31  $\pm$  1.54%), which is comparable to the yield obtained by organic synthesis.

Optimization Procedure Using the Taguchi Crossed **Array Method.** In above section, relative high yields of LG were obtained in Mg-CGly3-5 systems with the catalyzation of CALB, to further enhance the yield, the optimization procedure were performed using the Taguchi crossed array method in this section. As Mg-CGly3-5 have the best performance in above sections, and the relative low-cost of Mg-CGly3, it was selected for optimization procedure. The experiment design and data analysis of optimization procedure were carried out by Minitab software (version 18). As Taguchi crossed array method has been proved to have extremely advantages in the optimization of test parameters, it was adopted in this study. 41-43 The experiment parameters were detailed in Table S4 (see the Supporting Information). Obviously, four controllable parameters were involved in this section, a L9 orthogonal array for the optimization of the enzymatic synthesis of LG in Mg-CGly were designed (Table S5, see the Supporting Information). A total number of 27 runs (9 trails  $\times$  3repetitions) were needed to arrive at a conclusion. All reactions in this section were performed according to Table S5 (see the Supporting Information), and the results were displayed in Table 5. As we can see, a significantly improvement of yield of LG can be obtained with the optimization procedure, and the highest yield of 85.97  $\pm$ 1.86% was obtained with the following parameters: 2 mmol of lauric acid, 1 mmol of glycine, 75 mg of CALB and 20 mL of Mg-CGly3, the reactions were carried out at 333 K, 500 rpm for 120 h (entry 9). The lowest yield (56.38  $\pm$  2.08%) were obtained by entry 1 (2 mmol lauric acid, 1 mmol glycine, 50 mg enzyme and reaction performed at 313 K for 72 h).

Investigation of the Synergistic Effect between Enzyme Active Site and 3c-NADESs. Based on above results, an efficient and sustainable strategy for enzymatic synthesis of LG was developed. Interestingly, we found that there was a synergistic effect between CALB and NADESs or 3c-NADESs, and anions may play a key role in this process. However, up to now, the mechanism by which NADESs/3c-NADESs and CALB synergistically catalyzed synthesis of LG is still ambiguous. To explore it, we must figure out which components of the enzyme act as a catalyst in this process. As all of we know, amino acids can also act as catalysts in some cases. To prevent interference of the catalysis of amino acid and empty carrier (acrylic resin), some assays were designed. Four entries of proof-of-principle experiment were designed. As shown in Table 6, entry 1 suggested that the presence of CALB is essential to the synthesis of LG in 3c-NADESs. No significantly difference (P < 0.05) of the yield of LG between entry 1 and entry 2, which indicated that acrylic resin cannot act as a catalyst in this process. Although bovine serum albumin (BSA) is a protein composed of various amino acids, the yield of LG of entry 3 cannot be enhanced to any appreciable extent compared with entry 1, which indicated that the reaction cannot be catalyzed by amino acids. Moreover, the cases of denatured CALB (the active site was destroyed) provide us with some information that the denatured CALB cannot be a catalyst of this process. Considering all of the

results above-mentioned, we concluded that the reaction was catalyzed by CALB active site.

**Secondary Structure of CALB in Mg-CGly3.** As abovementioned, the active site of CALB play a key role in amidation reactions of lauric acid and glycine. To further study the mechanism of the synergistic effect between 3c-NADESs and CALB, changes of the secondary structure of CALB in 3c-NADESs were explored via MD studies.

As we know, CALB is a 317-amino acid globular protein with a molecular weight of 33 kDa and an isoelectric point of 6.0, which belongs to the  $\alpha/\beta$  hydrolase superfamily. Its crystal structure was first reported by Uppenberg et al. in 1994.<sup>44</sup> Similar with many other lipases, the CALB active site include a catalytic triad structure (Ser105-Asp187-His224), an oxygen ion hole (Thr40 and Gln106) for stabilizing enzyme-substrate complex intermediates and the binding pockets, namely medium (Gly39, Thr42, Ser47, Tip104, and Ala225), large (Ala141, Leu144, Val154, Ile285, Pro289, and Lys290) and acyl (Asp134, Thr138, Gln157, Ile189, and Val190) binding pockets. 45 The secondary structure of CALB was also explored by MD studies. As shown in Figure 1, compared to the 8 M urea solution, there was no significantly change of the secondary structure of CALB in Mg-CGly3 in 30 ns simulation, which indicated that CALB remained a high stability in this novel system.

For a more detailed study of the secondary structure of CALB in Mg-CGly3, the overall atomic root-mean-square deviation (RMSD), radius of gyration (R(g)), and the rootmean-square fluctuation (RMSF) of CALB were measured via MD methods. To make the results to be more informative, 8 M urea solution was applied as a control. As shown in Figure 2A, the global secondary structure of CALB was studied at 333 K. Obviously, CALB remains stable in Mg-CGly3, while a violent change can be seen in 8 M urea solution. Moreover, the RMSD value in Mg-CGly3 was significantly lower than that in urea solution, which indicated that CALB was more rigid in Mg-CGly3. This is agreement with the high stability of CALB above-mentioned. It can be attributed to the hydrogenbonding interaction between surface amino residues and Mg-CGly3 which decreased the thermal vibration of the internal group of CALB. To further explore the effects of Mg-CGly3 on CALB secondary structure, the local flexible changes of lipase were analyzed via RMSF analysis. As shown in Figure 2B, RMSF of CALB in urea solution was significantly higher than that in Mg-CGly3 which indicated CALB backbone has a greater flexibility in urea solution. Furthermore, as shown in Figure 2C, CALB becomes relative denser in Mg-CGly3 than that in urea solution at 333 K. It is a satisfactory explanation for the high enzyme stability mentioned above. As shown in Figure 2D, there was no significant change of hydrophobic area of CALB can be found in Mg-CGly3, while a slightly increasing can be found in urea solution system. The increasing of hydrophobic solvent accessible surface in urea may be attributed to the denaturation of CALB.

Molecular Interaction between CALB and 3c-NADESs. As above-mentioned, CALB remain high stable in 3c-NADESs, and there was no significantly change in their secondary structure in 30 ns simulation. It provides us with some information about that "how CALB can be stabilized in 3c-NADESs". However, the mechanism of the synergistic effect between 3c-NADESs and CALB still remains ambiguous. Inspired by previous studies of our group, <sup>15,46</sup> we proposed that molecular interactions between 3c-NADESs and CALB/

substrates may play a key role in these processes. To further explore it, the molecular interaction between CALB and Mg-CGly3 was investigated by molecular dynamics study (MD). The center of mass (COM) radial distribution functions (RDF) for Mg-CGly3 was explored. As displayed in Figure 3A, a strong peak of Cl<sup>-</sup> can been seen around about 0.25 nm of glycerin, which indicated that hydrogen-bonding interaction may be formed between Cl and glycerin (the cutoff radius of hydrogen-bonding is 0.35 nm). Moreover, as this peak was stronger than the peak of choline-Cl-, it indicated that the original hydrogen-bonding interaction of choline chloride was destroyed by new formed glycerin-Cl- hydrogen-bonding interaction. Actually, it is a satisfactory expiation for the low melting point of NADESs and 3c-NADESs. Besides, a strong peak of glycerin-Mg can also be seen in about 0.25 nm, which provide us some information that 3c-NADESs were successfully formed. These results provided us some information that 3c-NADESs can remain stable in the reaction process. Moreover, as shown in Figure 3B, a short peak of Cl<sup>-</sup> can be seen in about 0.25 nm, it indicated that hydrogen-bonding can be formed between CALB amino residues and components of Mg-CGly3, or more especially Cl-. To further investigate which part of CALB plays a key role in this process, the COM RDF of 3c-NADESs components around CALB active site was explored. As shown in Figure S3 (see the Supporting Information), there was no peak can be found in the range of 0.35 nm around CALB catalytic triad, which indicated that hydrogen-bonding can hardly be formed between CALB catalytic triad and 3c-NADESs. In this context, we can conclude that CALB catalytic triad may not involve in the synergistic effect with 3c-NADESs, which is consist with the results of our previous study in traditional NADESs. 46 Similarly, the large and medium substrate binding pockets were not involved in synergistic effect process (Figure S4A, B, see the Supporting Information). Interestingly, as shown in Figure S4C (see the Supporting Information), a strong peak of chloride ions can be seen at 0.25 nm around CALB acyl binding pocket, which indicated that the acyl binding pocket was involved in this process. It is agreement with the previous work of our group. 46 Some previous studies indicated that enhances the size of acyl binding pocket may make the substrate easier to be diffused into it and resulting in an improvement of CALB activity.<sup>47</sup>

Molecular Interaction between CALB and Lauric **Acid.** As shown in Table 7, the combined free energy between CALB and lauric acid was calculated via MM-PBSA methods. Obviously, the  $\Delta G_{\rm bind}$  between CALB and lauric acid in C-Gly was significantly lower than that in Mg-CGly3. It indicated that the complex of CALB-lauric acid in Mg-CGly3 is more stable. Moreover, as polar combined free energy is positive, which indicated an intermolecular repulsion was occurred between polar components of CALB and lauric acid. In contrary, the negative value of the nonpolar combined free energy suggested that the combination of CALB and lauric acid was driven via nonpolar interaction. Furthermore, the combined free energy between CALB substrate-binding pocket and lauric acid was also explored. As shown in Figure S5 (see the Supporting Information), the combined free energy of lauric acid with the large, medium and acyl binding pocket was  $-2.65 \pm 1.62$ ,  $-3.18 \pm 2.16$ , and  $-5.51 \pm 1.13$  kcal mol<sup>-1</sup>, respectively, in C-Gly and was  $-3.61 \pm 1.17$ ,  $+4.07 \pm 2.08$ , and  $-5.98 \pm 1.46$ kcal mol<sup>-1</sup> respectively in Mg-CGly3. It is consistent with the

above results that acyl-binding pocket play a key role in the synergistic effect process.

However, as above-mentioned, the secondary structure of CALB remains stable in 3c-NADESs which indicated that there was no significant change in the size of CALB acylbinding pocket. In the meantime, some other studies suggested that the hydrogen-bonding between substrates and acylbinding pocket play a key role in activity of CALB. Moreover, in cases of organic synthesis of LG, namely Schotten-Baumann reaction, fatty acid chloride was applied as an alternative of fatty acid. The Schotten-Bowman reaction is a condensation reaction of a fatty acid chloride with an amino acid under the action of a basic catalyst and an acid binding agent in an organic solvent/water system.

The reaction process can be detailed in four steps: (1) the formation of fatty acid chloride from fatty acid and SOCl<sub>2</sub> or PCl<sub>3</sub>; (2) the condensation of fatty acid chloride and amino acid; (3) the purification of products via recrystallization method; (4) neutralization of product to obtain sodium lipoamino acid.<sup>50</sup> As we know, the chlorine atom of acyl chlorides has a strong electron-attracting effect, which enhances the electrophilicity of the adjacent carbon, and making the acyl chlorides more susceptible to be attacked by the nucleophile (amino acids).

Investigation of Molecular Interactions between Mg-CGly3 and Fatty Acids. Inspired of above results, we proposed that the molecular interaction increased the electronattracting ability of fatty acids and made them more susceptible to be attacked by amino acids. The geometries of Mg-CGly3 was optimized by density functional theory (DFT) with a level of M06-2X/6-311++G\*\*, which has been widely used in cases of ionic liquids. 51-53 As shown in Figure 4, six of most stable geometries were listed and the total energy of them were labeled in red. Obviously, the total energy in Figure 4A (-8028549.7 kJ/mol) was significantly lower than others, which indicated that it is the most stable geometry of the Mg-CGly3 cluster. To further study the molecular interaction between Mg-CGly3 components, AIM analysis was adopted to quantify the hydrogen-bonding interaction. As Shown in Figure 5, the 2D scatter plot (A, C) suggested that multiple noncovalent interactions were formed in both Mg-CGly3 and Mg-CGly3-lauric acid systems. The 3D noncovalent interactions plot (B, D) provide us with further information that the hydrogen-bonding interaction between Cl and other components play a key role in this process. Besides, as shown in Figure 5D, a strong H-bond was formed between lauric and Cl-. It indicated that electrons of carboxyl carbon atom can be transferred to chloride ions through h-bonds, making it more susceptible to attack by nucleophiles.

Reaction Path of the Amidation Reaction. To further study the effect of chloride ion on the amidation reaction of lauric acid and glycine, the reaction path of these processes in C-Gly and Mg-CGly3 was explored via quantum calculations. As shown in Figure S6 (see the Supporting Information), the Fukui function of lauric acid in C-Gly and Mg-CGly3 was displayed. Obviously, the carboxyl was activated in 3c-NADESs, it is agreement with the results above-mentioned. Transition state (TS) of this reaction was obtained at a level of M06-2X/6-311++G\*\*, and harmonic vibrational frequency calculations suggested there was only one virtual frequency of it (Figure S7, see the Supporting Information). The intrinsic reaction coordinates (IRC) were applied to detail the reaction process and confirm the geometry of TS. As shown in Figure

<span id="page-8-0"></span>Scheme 1. Proposed Mechanism of the Synthetic Effect of CALB and Mg-CGly3

S8 (see the Supporting Information), 80 steps of IRC of the amidation reaction were performed in both C-Gly and Mg-CGly3 systems, and the TS is the minimum point of this process. Moreover, Figure S9 (seee Supporting Information) and S10 (see Supporting Information) provide us more details about the mechanism by which lauric acid was activated via chloride ions. As shown in Figure S9 (see Supporting Information), the hydrogen atom of glycine was attracted by carboxyl of lauric acid directly and following by the formation of the TS (Figure S9E, see the Supporting Information). The TS is not stable, and with the amide bond continues to strengthen, the products were formed (Figure S9H, see Supporting Information). In cases of Mg-CGly3 system, the H-bond between chloride ion and lauric acid enhanced the electron-attracting ability of fatty acids, and then the chloride ion act as a "bridge" between lauric acid and glycine. The hydrogen atom of glycine was strongly attracted by chloride ions, and formed a H···O····H····Cl complex TS (Figure S10E, see the Supporting Information). Evidently, with the transportation of the hydrogen atom of glycine, the reaction is easier to be carried out. Actually, the results of the reaction barrier of these processes give us more evidence about the mechanism of these reactions. As shown in Figure 6, the reaction barrier of reagent complex and TS is 48.2 and 65.8 kcal mol<sup>-1</sup> in Mg-CGly3 and C-Gly, respectively, which indicated that the reaction was easier to be carried out in the former system. These results were agreement with some previous studies. For instance, Lai and co-workers suggested that two model enzymes, penicillium expansum lipase (PEL) and mushroom tyrosinase can be affected by anions of ionic liquids.<sup>54</sup> Our previous work also indicated the addition of water can enhance the activity of CALB in NADESs, which can be attributed to the improvement of the interaction between NADESs and CALB.<sup>15</sup>

### CONCLUSIONS

In this study, an efficient and sustainable strategy for enzymatic synthesis of LG was successfully development in 3c-NADESs. The reaction in three kinds of traditional solvents suggested that these traditional solvents cannot be used as medium of this reaction due to the disadvantages of low-yield and unsustainable. Inspired of our previous study which indicated that NADESs can be a perfect medium for enzymatic reactions, they were applied in this study for enzymatic synthesis of LG. With two screening rounds, ten kinds of NADES with low viscosity was selected for further study. The results showed that the highest yield of LG (50.49  $\pm$  1.94%) was obtained in C-Gly system. Interestingly, although only an extremely low yield of LG can be obtained in traditional solvents and NADESs without CALB systems, a considerable yield can be obtained in NADESs-CALB systems. Therefore, we proposed that there was a synergistic effect between CALB and NADESs. Consideration of our previous study which indicated anions may play a key role in this process, 15 metal chloride hydrate, which were widespread used as a component in other types of DESs, were added into C-Gly to investigate whether we can improve the yield by adding anions. Fortunately, a comparable yield to organic synthesis was obtained in Mg-CGly3-5 systems. To further improve the yield of this reaction, Taguchi crossed array method was applied for optimization produce, and the highest of 85.97  $\pm$  1.86% was obtained with following parameters: 2 mmol lauric acid, 1 mmol glycine, 75 mg CALB and 20 mL Mg-CGly3. To further study the mechanism of the synergistic effect between CALB and NADESs or 3c-NADESs. Molecular dynamics studies were applied to explore the secondary structure change of CALB in Mg-CGly3. The results showed that there was no significant change in structure of CALB, which indicated that CALB not CALB may play a secondary role in this process. Then we proposed that the molecular interaction between 3c-NADESs

<span id="page-9-0"></span>and lauric acid increased the electron-attracting ability of fatty acids and made them more susceptible to be attacked by amino acids. To investigate it, quantum calculations were adopted, and the most stable geometry of Mg-CGly3 was obtained, the AIM method was further applied to quantify the hydrogenbonding interaction between Mg-CGly3 and lauric acid. The results showed that a strong h-bond was formed between Mg-CGly3 and lauric acid. The results of Fukui function suggested lauric acid was activated via chloride ions. The IRC calculation indicated chloride ion act as a "bridge" and make the reaction easier to be carried out. All of these results suggested that the above proposing mechanism was reasonable. The process was displayed in Scheme 1, glycine was combined with oxyanion hole of CALB via hydrogen-bonding interaction and the amino group of it was activated. In the meantime, lauric acid was combined by active triad and 3c-NADESs, as the strong electron-attracting ability of chloride ion and hydroxyl group, the electrons were transferred to them and result in an increasing of electron-attracting ability of carboxy carbon atom. Then an amide bond was formed, and the first transition state was obtained (B). As the first transition state was not stable, a water molecule was easily separated and in the meanwhile the active triad was released (C). Finally, with the enhancement of amide bond, the oxygen atom was occupied and 3c-NADESs was released (D).

#### ASSOCIATED CONTENT

## **S** Supporting Information

The Supporting Information is available free of charge on the ACS Publications website at DOI: 10.1021/acssuschemeng.9b05691.

Characterization of lauroyl glycine, construction of 3c-NADESs, COM RDFs for Mg-CGly3 components around CALB catalytic triad (Ser-His-Asp), COM RDFs for Mg-CGly3 components around CALB binding pocket, combined free energy of CALB substrate-binding pocket and lauric acid in NADESs and 3c-NADESs calculated by MM-PBSA, the effect of chloride ions on the Fukui function of lauric acid, the harmonic vibrational frequency of the amidation reaction of lauric acid and glycine in C-Gly and Mg-CGly3, the intrinsic reaction coordinates (IRC) of the reaction and the reaction path of the amidation reaction in C-Gly and Mg-CGly3 (PDF)

## AUTHOR INFORMATION

#### **Corresponding Author**

\*Tel.: +860510-85876799. Fax: +860510-85876799. E-mail: yfliu@jiangnan.edu.cn.

#### ORCID ®

Yuanfa Liu: 0000-0002-8259-8426

#### Notes

The authors declare no competing financial interest.

#### ACKNOWLEDGMENTS

This work was supported by the State Key Research and Development Plan (No. 2017YFD0400200), National Key R&D Program of China (2016YFD0401404), the Taishan industry leading talents innovation project in Shandong Province (LJNY2015007), Natural Science Foundation of

China (31671786), and 2018 Basic Research Program of Jiangnan University Youth Fund (JUSRP11849).

#### REFERENCES

- (1) Gallezot, P. Conversion of biomass to selected chemical products. Chem. Soc. Rev. 2012, 41 (4), 1538–1558.
- (2) Burstein, S. H. N-Acyl Amino Acids (Elmiric Acids): Endogenous Signaling Molecules with Therapeutic Potential. *Mol. Pharmacol.* **2018**, 93 (3), 228–238.
- (3) Joondan, N.; Jhaumeer-Laulloo, S.; Caumul, P.; Akerman, M. Synthesis, physicochemical, and biological activities of novel N-acyl tyrosine monomeric and Gemini surfactants in single and SDS/CTAB-mixed micellar system. *J. Phys. Org. Chem.* **2017**, *30* (10), e3675.
- (4) Ohta, A.; Toda, K.; Morimoto, Y.; Asakawa, T.; Miyagishi, S. Effect of the side chain of N-acyl amino acid surfactants on micelle formation: An isothermal titration calorimetry study. *Colloids Surf., A* **2008**, *317* (1–3), *316*–322.
- (5) Perinelli, D. R.; Cespi, M.; Casettari, L.; Vllasaliu, D.; Cangiotti, M.; Ottaviani, M. F.; Giorgioni, G.; Bonacucina, G.; Palmieri, G. F. Correlation among chemical structure, surface properties and cytotoxicity of N-acyl alanine and serine surfactants. *Eur. J. Pharm. Biopharm.* **2016**, *109*, 93–102.
- (6) Ozturk, B.; McClements, D. J. Progress in natural emulsifiers for utilization in food emulsions. *Current Opinion in Food Science* **2016**, 7, 1–6.
- (7) Naso, J. N.; Bellesi, F. A.; Ruiz-Henestrosa, V. M. P.; Pilosof, A. M. Studies on the interactions between bile salts and food emulsifiers under in vitro duodenal digestion conditions to evaluate their bile salt binding potential. *Colloids Surf., B* **2019**, *174*, 493–500.
- (8) Bernal, C.; Guzman, F.; Illanes, A.; Wilson, L. Selective and ecofriendly synthesis of lipoaminoacid-based surfactants for food, using immobilized lipase and protease biocatalysts. *Food Chem.* **2018**, 239, 189–195
- (9) Cabana Saavedra, L. C.; Pachon Gomez, E. M.; Oliveira, R. G.; Fernandez, M. A. Aggregation behaviour and solubilization capability of mixed micellar systems formed by a gemini lipoamino acid and a non-ionic surfactant. *Colloids Surf., A* **2017**, 533, 41–47.
- (10) Pérez, L.; Pinazo, A.; I, M. R.; Pons, R. Investigation of the Micellization Process of Single and Gemini Surfactants from Arginine by SAXS, NMR Self-Diffusion, and Light Scattering. *J. Phys. Chem. B* **2007**, *111* (39), 11379–87.
- (11) Brandenberg, O. F.; Prier, C. K.; Chen, K.; Knight, A. M.; Wu, Z.; Arnold, F. H. Stereoselective Enzymatic Synthesis of Heteroatom-Substituted Cyclopropanes. *ACS Catal.* **2018**, 8 (4), 2629–2634.
- (12) Wen, L.; Edmunds, G.; Gibbons, C.; Zhang, J.; Gadi, M. R.; Zhu, H.; Fang, J.; Liu, X.; Kong, Y.; Wang, P. G. Toward Automated Enzymatic Synthesis of Oligosaccharides. *Chem. Rev.* **2018**, *118* (17), 8151–8187.
- (13) Chen, G.; Liu, D.; He, C.; Gannett, T. R.; Lin, W.; Weizmann, Y. Enzymatic Synthesis of Periodic DNA Nanoribbons for Intracellular pH Sensing and Gene Silencing. *J. Am. Chem. Soc.* **2015**, *137* (11), 3844–3851.
- (14) Wen, L.; Huang, K.; Liu, Y.; Wang, P. G. Facile Enzymatic Synthesis of Phosphorylated Ketopentoses. *ACS Catal.* **2016**, 6 (3), 1649–1654.
- (15) Nian, B.; Cao, C.; Liu, Y. Activation and stabilization of Candida antarctica lipase B in choline chloride-glycerol-water binary system via tailoring the hydrogen-bonding interaction. *Int. J. Biol. Macromol.* **2019**, *136*, 1086–1095.
- (16) Cao, S. L.; Deng, X.; Xu, P.; Huang, Z. X.; Zhou, J.; Li, X. H.; Zong, M. H.; Lou, W. Y. Highly Efficient Enzymatic Acylation of Dihydromyricetin by the Immobilized Lipase with Deep Eutectic Solvents as Cosolvent. *J. Agric. Food Chem.* **2017**, *65* (10), 2084–2088.
- (17) Cardoso, A. M.; Morais, C. M.; Cruz, A. R.; Silva, S. G.; do Vale, M. L.; Marques, E. F.; de Lima, M. C.; Jurado, A. S. New serine-derived gemini surfactants as gene delivery systems. *Eur. J. Pharm. Biopharm.* **2015**, *89*, 347–56.

- <span id="page-10-0"></span>(18) Fan, H.; Han, F.; Liu, Z.; Qin, L.; Li, Z.; Liang, D.; Ke, F.; Huang, J.; Fu, H. Active control of surface properties and aggregation behavior in amino acid-based Gemini surfactant systems. J. Colloid Interface Sci. 2008, 321 (1), 227−34.
- (19) Girka, Q.; Hausser, N.; Estrine, B.; Hoffmann, N.; Le Bras, J.; Marinkovic, S.; Muzart, J. ́ β-Amino acid derived gemini surfactants from diformylfuran (DFF) with particularly low critical micelle concentration (CMC). Green Chem. 2017, 19 (17), 4074−4079.
- (20) Azmi, F.; Elliott, A. G.; Marasini, N.; Ramu, S.; Ziora, Z.; Kavanagh, A. M.; Blaskovich, M. A. T.; Cooper, M. A.; Skwarczynski, M.; Toth, I. Short cationic lipopeptides as effective antibacterial agents: Design, physicochemical properties and biological evaluation. Bioorg. Med. Chem. 2016, 24 (10), 2235−2241.
- (21) Mohini, Y.; Prasad, R. B. N.; Karuna, M. S. L.; Poornachandra, Y.; Kumar, C. G. Synthesis and biological evaluation of ricinoleic acidbased lipoamino acid derivatives. Bioorg. Med. Chem. Lett. 2016, 26 (21), 5198−5202.
- (22) Kabir ud, D.; Sharma, G.; Naqvi, A. Z. Studies on Gemini− Conventional Surfactant Mixtures. J. Solution Chem. 2017, 46 (4), 815−830.
- (23) Kragl, U.; Eckstein, M.; Kaftzik, N. Enzyme catalysis in ionic liquids. Curr. Opin. Biotechnol. 2002, 13 (6), 565−571.
- (24) Itoh, T. Ionic Liquids as Tool to Improve Enzymatic Organic Synthesis. Chem. Rev. 2017, 117 (15), 10567−10607.
- (25) Wu, C.; Xiao, H.-J.; Wang, S.-W.; Tang, M.-S.; Tang, Z.-L.; Xia, W.; Li, W.-F.; Cao, Z.; He, W.-M. Natural Deep Eutectic Solvent-Catalyzed Selenocyanation of Activated Alkynes via an Intermolecular H-Bonding Activation Process. ACS Sustainable Chem. Eng. 2019, 7 (2), 2169−2175.
- (26) Choi, Y. H.; Van, S. J.; Dai, Y.; Verberne, M.; Hollmann, F.; Arends, I. W.; Witkamp, G. J.; Verpoorte, R. Are natural deep eutectic solvents the missing link in understanding cellular metabolism and physiology? Plant Physiol. 2011, 156 (4), 1701−5.
- (27) Dai, Y. T.; van Spronsen, J.; Witkamp, G. J.; Verpoorte, R.; Choi, Y. H. Natural deep eutectic solvents as new potential media for green technology. Anal. Chim. Acta 2013, 766, 61−68.
- (28) Ye, H.; Qiu, B.; Lin, Z.; Chen, G. Fluorescence spectrometric study on the interaction of tamibarotene with bovine serum albumin. Luminescence 2011, 26 (5), 336−341.
- (29) Ranganathan, S.; Zeitlhofer, S.; Sieber, V. Development of a lipase-mediated epoxidation process for monoterpenes in choline chloride-based deep eutectic solvents. Green Chem. 2017, 19 (11), 2576−2586.
- (30) Berendsen, H. J. C.; Vanderspoel, D.; Vandrunen, R. GROMACS - A MESSAGE-PASSING PARALLEL MOLECULAR-DYNAMICS IMPLEMENTATION. Comput. Phys. Commun. 1995, 91 (1−3), 43−56.
- (31) Micaelo, N. M.; Baptista, A. M.; Soares, C. M. Parametrization of 1-butyl-3-methylimidazolium hexafluorophosphate/nitrate ionic liquid for the GROMOS force field. J. Phys. Chem. B 2006, 110 (29), 14444−14451.
- (32) Batista, M. L.; Perez-Sanchez, G. n.; Gomes, J. R.; Coutinho, J. o. A.; Maginn, E. J. Evaluation of the GROMOS 56ACARBO force field for the calculation of structural, volumetric, and dynamic properties of aqueous glucose systems. J. Phys. Chem. B 2015, 119 (49), 15310−15319.
- (33) Nuń ̃ez-Rojas, E.; Flores-Ruiz, H. M.; Alejandre, J. Molecular dynamics simulations to separate benzene from hydrocarbons using polar and ionic liquid solvents. J. Mol. Liq. 2018, 249, 591−599.
- (34) Gunsteren, W. F. V.; Berendsen, H. J. C. A Leap-frog Algorithm for Stochastic Dynamics. Mol. Simul. 1988, 1 (3), 13.
- (35) Lu, T. Molclus program; [http://www.keinsci.com/research/](http://www.keinsci.com/research/molclus.html) [molclus.html.](http://www.keinsci.com/research/molclus.html)
- (36) Grimme, S.; Bannwarth, C.; Shushkov, P. A Robust and Accurate Tight-Binding Quantum Chemical Method for Structures, Vibrational Frequencies, and Noncovalent Interactions of Large Molecular Systems Parametrized for All spd-Block Elements (Z = 1− 86). J. Chem. Theory Comput. 2017, 13 (5), 1989−2009.

- (37) Frisch, M.; et al. Gaussian 09, revision A. 01; Gaussian Inc.: Wallingford , CT, 2009..
- (38) Lu, T.; Chen, F. Multiwfn: A multifunctional wavefunction analyzer. J. Comput. Chem. 2012, 33 (5), 580−592.
- (39) Cardoso, A. M.; Morais, C. M.; Cruz, A. R.; Cardoso, A. L.; Silva, S. G.; do Vale, M. L.; Marques, E. F.; Pedroso de Lima, M. C.; Jurado, A. S. Gemini Surfactants Mediate Efficient Mitochondrial Gene Delivery and Expression. Mol. Pharmaceutics 2015, 12 (3), 716−730.
- (40) Cruz, H.; Jordao, N.; Branco, L. C. Deep eutectic solvents (DESs) as low-cost and green electrolytes for electrochromic devices. Green Chem. 2017, 19 (7), 1653−1658.
- (41) Garcia-Castellanos, V.; Hijar-Rivera, H.; Castagliola, P. Efficient computer-generated alternatives to Taguchi's crossed arrays for robust parameter design. Journal of Quality in Maintenance Engineering 2009, 15 (4), 371−382.
- (42) Bai, M. R.; Tung, C. W.; Lee, C. C. Optimal design of loudspeaker arrays for robust cross-talk cancellation using the Taguchi method and the genetic algorithm. J. Acoust. Soc. Am. 2005, 117 (5), 2802−2813.
- (43) Yang, K.; Teo, E. C.; Fuss, F. K. Application of Taguchi method in optimization of cervical ring cage. J. Biomech. 2007, 40 (14), 3251− 3256.
- (44) Uppenberg, J.; Hansen, M. T.; Patkar, S.; Jones, T. A. The sequence, crystal structure determination and refinement of two crystal forms of lipase B from Candida antarctica. Structure 1994, 2 (4), 293−308.
- (45) Kumaresan, J.; Kothai, T.; Lakshmi, B. S. In silico approaches towards understanding CALB using molecular dynamics simulation and docking. Mol. Simul. 2011, 37 (12), 1053−1061.
- (46) Nian, B.; Cao, C.; Liu, Y. How Candida antarctica lipase B can be activated in natural deep eutectic solvents: experimental and molecular dynamics studies. J. Chem. Technol. Biotechnol. in press [DOI: 10.1002/jctb.6209](http://dx.doi.org/10.1002/jctb.6209).
- (47) Magnusson, A. O.; Rotticci-Mulder, J. C.; Santagostino, A.; Hult, K. Creating space for large secondary alcohols by rational redesign of Candida antarctica lipase B. ChemBioChem 2005, 6 (6), 1051−1056.
- (48) Yadav, G. D.; Lathi, P. S. Kinetics and mechanism of synthesis of butyl isobutyrate over immobilised lipases. Biochem. Eng. J. 2003, 16 (3), 245−252.
- (49) Soo, E. L.; Salleh, A. B.; Basri, M.; Rahman, R.; Kamaruddin, K. Response surface methodological study on lipase-catalyzed synthesis of amino acid surfactants. Process Biochem. 2004, 39 (11), 1511− 1518.
- (50) Roy, S.; Dey, J. Effect of urea on self-organization of sodium N- (11-acrylamidoundecanoyl)-L-valinate in water. J. Colloid Interface Sci. 2005, 290 (2), 526−532.
- (51) Fumino, K.; Wulf, A.; Ludwig, R. Strong, Localized, and Directional Hydrogen Bonds Fluidize Ionic Liquids. Angew. Chem., Int. Ed. 2008, 47 (45), 8731−8734.
- (52) Fumino, K.; Wulf, A.; Ludwig, R. The potential role of hydrogen bonding in aprotic and protic ionic liquids. Phys. Chem. Chem. Phys. 2009, 11 (39), 8790−8794.
- (53) Fumino, K.; Peppel, T.; Geppert-Rybczynska, M.; Zaitsau, D. H.; Lehmann, J. K.; Verevkin, S. P.; Koeckerling, M.; Ludwig, R. The influence of hydrogen bonding on the physical properties of ionic liquids. Phys. Chem. Chem. Phys. 2011, 13 (31), 14064−14075.
- (54) Lai, J.-Q.; Li, Z.; Lü, Y.-H.; Yang, Z. Specific ion effects of ionic liquids on enzyme activity and stability. Green Chem. 2011, 13 (7), 1860−1868.