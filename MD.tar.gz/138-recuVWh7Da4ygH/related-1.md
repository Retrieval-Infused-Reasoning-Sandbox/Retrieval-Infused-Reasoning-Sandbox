# STRATA HASSE INVARIANTS, HECKE ALGEBRAS AND GALOIS REPRESENTATIONS

#### WUSHI GOLDRING AND JEAN-STEFAN KOSKIVIRTA

Abstract. We construct group-theoretical generalizations of the Hasse invariant on strata closures of the stacks G-Zipµ. Restricting to zip data of Hodge type, we obtain a group-theoretical Hasse invariant on every Ekedahl-Oort stratum closure of a general Hodge-type Shimura variety. A key tool is the construction of a stack of zip flags G-ZipFlagµ, fibered in flag varieties over G-Zipµ. It provides a simultaneous generalization of the "classical case" homogeneous complex manifolds studied by Griffiths-Schmid and the "flag space" for Siegel varieties studied by Ekedahl-van der Geer.

Four applications are obtained: (1) Pseudo-representations are attached to the coherent cohomology of Hodgetype Shimura varieties modulo a prime power. (2) Galois representations are associated to many automorphic representations with non-degenerate limit of discrete series archimedean component. (3) It is shown that all Ekedahl-Oort strata in the minimal compactification of a Hodge-type Shimura variety are affine, thereby proving a conjecture of Oort. (4) Part of Serre's letter to Tate on mod p modular forms is generalized to general Hodge-type Shimura varieties.

# Contents

| Introduction                                                                           | 1  |
|----------------------------------------------------------------------------------------|----|
| Notation                                                                               | 6  |
|                                                                                        |    |
| Part 1.<br>Group-theoretical Hasse invariants                                          | 8  |
| 1.<br>The stack of G-zips                                                              | 9  |
| 2.<br>The stack of zip flags                                                           | 10 |
| 3.<br>Hasse invariants                                                                 | 13 |
| Part 2.<br>Strata Hasse invariants of Shimura varieties                                | 17 |
| 4.<br>Shimura varieties of Hodge type                                                  | 17 |
| 5.<br>Lifting injective sections for p-nilpotent schemes and the length stratification | 21 |
| 6.<br>Extension of Hasse invariants to compactifications                               | 23 |
| 7.<br>Geometry of Hasse regular sequences                                              | 29 |
| Part 3.<br>Hecke algebras and Galois representations                                   | 31 |
| 8.<br>Construction of Hecke factorizations                                             | 31 |
| 9.<br>Increased regularity via the flag space                                          | 35 |
| 10.<br>Galois representations                                                          | 36 |
| 11.<br>Systems of Hecke eigenvalues on the generalized superpecial locus               | 42 |
| Acknowledgements                                                                       | 45 |
| References                                                                             | 46 |

# <span id="page-0-0"></span>Introduction

<span id="page-0-1"></span>This work takes the first step in a program that connects two areas:

- (A) Automorphic Algebraicity: The inherent algebro-geometric properties of automorphic representations, particularly those conjectured by the Langlands correspondence.
- <span id="page-0-2"></span>(B) G-Zip geometricity: The geometry engendered by the theory of G-Zips, including the Ekedahl-Oort (EO) stratification of Shimura varieties, their flag spaces and Hasse invariants.

In contrast with previous work, one of the novel features of our approach is to consider the two areas above simultaneously. While each has separately undergone significant developments over the past fifteen-twenty years, there has been surprisingly little work relating Automorphic Algebraicity with G-Zip Geometricity. Most of the papers cited above on the Langlands correspondence only used the classical Hasse invariant, but not deeper aspects

1

of the EO stratification. At the same time, the works which developed the theory of the EO stratification – and more recently of G-Zips – rarely studied applications to the Langlands correspondence.

<span id="page-1-0"></span>We were also inspired by the possibility of connections with a third area:

(C) Griffiths-Schmid Algebraicity: Is there an algebro-geometric framework which applies to Griffiths-Schmid manifolds?

Recall that Carayol has pursued a program of relating Automorphic Algebraicity and Griffiths-Schmid Algebraicity over the last twenty years [16, 17, 18, 20, 19]. His program was developed further by Green-Griffiths-Kerr [42].

The common pursuit of (A), (B) and (C) rests on two themes developed by Deligne, Serre and their collaborators. These themes are (i) geometry-by-groups and (ii) characteristic-shifting — back and forth between characteristic 0 and p.

Regarding (i), geometry-by-groups manifests itself in two stages. The first is that geometric objects at the heart of (A), (B), (C) – Shimura varieties, stacks of G-Zips and Griffiths-Schmid manifolds – are all constructed from the same group-theoretic template: A pair  $(G, \mu)$  consisting of a reductive group G and a cocharacter  $\mu$ . The second stage is guided by the more general hypothesis that all objects constructed from reductive groups should admit a close-knit relationship with algebraic geometry. In our setting, two fundamental test-cases are Automorphic Algebraicity and Griffiths-Schmid Algebraicity.

As for (ii), it is well-known that the method of characteristic-shifting applies throughout algebraic geometry; e.g., the characteristic p approach of Deligne-Illusie to Kodaira vanishing and the degeneration of the Hodge-de Rham spectral sequence. Inspired by Deligne-Serre, this paper applies characteristic-shifting in tandem with geometry-by-groups: The most basic application is to G-Zip Geometricity. Joined to the latter, the duo is next applied to Automorphic Algebraicity.

Further elaboration of our program is given in our papers [36, 37] and joint work in progress with B. Stroh and Y. Brunebarbe [13]. Building on the current work, all of these papers compound evidence that G-Zip Geometricity is a "mod p Hodge theory" which interacts with classical Hodge theory via characteristic-shifting. Specifically, our results suggest that stacks of G-Zips are mod p analogues of period domains (and more generally Mumford-Tate domains, of which Griffiths-Schmid manifolds are quotients [41]). An idea along these lines was first put forth for GL(n)-Zips by Moonen-Wedhorn in the introduction of [82]. The work of Griffiths-Schmid on the manifolds which bear their name [44] motivates the flag spaces which play a key role in this work, see Remark 9.1.2.

- I.1. **Group-theoretical Hasse invariants.** The main technical result of this paper is the construction of group-theoretical Hasse invariants on strata closures in the stacks G-Zip $^{\mu}$  (Th. I.1.1). As recalled below, the theory of the EO stratification has evolved in three stages, progressively shifting from a combinatorial viewpoint to a group-theoretic one. Our work develops a fourth stage in this progression.
- I.1.1. The Ekedahl-Oort stratification. Initially, Oort defined a stratification of  $A_g \otimes \mathbf{F}_p$ , the moduli space of principally polarized abelian varieties in characteristic p > 0, by isomorphism classes of the p-torsion [85]. He parametrized strata combinatorially by "elementary sequences". Later on, Moonen used the canonical filtration of a  $BT_1$  with PEL-structure to give a group-theoretical classification of these [81]. He described isomorphism classes of  $BT_1$ 's over an algebraically closed field k of characteristic p as a certain subset  $^IW$  of the Weyl group W of the reductive group attached to the PEL-structure.

In the third stage, in a series of papers, Moonen, Wedhorn, Pink and Ziegler defined the algebraic stack G-Zip $^{\mu}$ , [82, 107, 87, 88], whose k-points parametrize isomorphism classes of  $BT_1$ 's with G-structure over k. Viehmann and Wedhorn showed that the special fiber  $S_{\mathcal{K}}$  of any PEL-type Shimura variety admits a universal G-zip of type  $\mu$ , which gives rise to a faithfully flat morphism of stacks  $\zeta: S_{\mathcal{K}} \to G$ -Zip $^{\mu}$ , [105]. By definition, the fibers of  $\zeta$  are the EO strata of  $S_{\mathcal{K}}$ ; this definition agrees with those of Ekedahl-Oort and Moonen in the Siegel and PEL cases respectively. In his thesis, Zhang constructed a universal G-zip over the special fiber of a general Hodge-type Shimura variety. He proved that the induced map  $\zeta$  is smooth [113] (see also [110]).

I.1.2. Hasse invariants. The theory of Hasse invariants in its modern form goes back to the algebro-geometric pursuit of modular forms modulo p, pioneered by Deligne, Katz, Serre and others in the late 1960's and early 1970's. Since then, many people have studied generalizations and applications of the classical Hasse invariant of an abelian scheme cf. [40, 52, 29].

The work [39] by the first author and Nicole was the first to produce a Hasse invariant on a general class of Shimura varieties – those of PEL-type A – whose classical ordinary locus is often empty. The second author and Wedhorn extended this result to all Shimura varieties of Hodge-type, [62]. Their work was the first to construct a group-theoretical generalization of the Hasse invariant on the stack of G-Zips. A partial group-theoretical result concerning smaller strata was also obtained by the second author [61]. It is used as a starting point for the construction of Hasse invariants in this paper.

One advantage of the G-Zip approach to Hasse invariants is that sections obtained by pull-back from this stack to a Shimura variety are automatically Hecke-equivariant. Another is that geometric properties of such sections can be read off from a root datum of G.

I.1.3. New results on Hasse invariants. Let p be a prime (p=2 allowed). Let G be a connected, reductive  $\mathbf{F}_p$ -group and  $\mu \in X_*(G)$  a cocharacter. The works of Moonen-Wedhorn [82] and Pink-Wedhorn-Ziegler [87, 88] define the stack G-Zip $^{\mu}$  of G-zips of type  $\mu$  (Def. 1.2) and attach to the pair (G,  $\mu$ ) the zip group E (§1.2). This group acts naturally on G and one has G-Zip $^{\mu} \cong [E \setminus G]$ . The E-orbits in G are locally closed subsets  $G_w$ , parametrized by elements  $w \in {}^IW$  (§1.4). Let  $L = \operatorname{Cent}(\mu)$  be the centralizer of  $\mu$  in G. Every character  $\chi \in X^*(L)$  gives rise to a line bundle  $\mathscr{V}(\chi)$  on G-Zip $^{\mu}$  (§N.4.1). It satisfies  $\mathscr{V}(N\chi) = \mathscr{V}(\chi)^N$  for all  $N \geq 1$ .

<span id="page-2-0"></span>**Theorem I.1.1** (Group-theoretical Hasse invariants, Th. 3.2.3). Let  $G_w \subset G$  be an E-orbit;  $\overline{G}_w$  its Zariski closure<sup>1</sup>. Assume  $\chi \in X^*(L)$  is (p, L)-admissible (Def. N.5.3). Then there exists  $N_w \geq 1$  and a section  $h_w \in H^0([E \setminus \overline{G}_w], \mathcal{V}(\chi)^{N_w})$  whose non-vanishing locus is exactly the substack  $[E \setminus G_w]$ .

We call the sections  $h_w$  afforded by Th. I.1.1 group-theoretical Hasse invariants. The space  $H^0([E \backslash G_w], \mathscr{V}(\chi))$  has dimension  $\leq 1$  for any  $\chi \in X^*(L)$ , hence the sections  $h_w$  of Th. I.1.1 are unique up to scalar.

Let  $f:(G_1,\mu_1)\to (G_2,\mu_2)$  be a finite morphism of cocharacter data and  $\widetilde{f}:G_1\text{-}\operatorname{Zip}^{\mu_1}\to G_2\text{-}\operatorname{Zip}^{\mu_2}$  the induced map of stacks (§1.2.1). Put  $L_i=\operatorname{Cent}(\mu_i)$ .

<span id="page-2-2"></span>Corollary I.1.2 (Discrete fibers, Th. 3.3.1). Assume there exists a  $(p, L_2)$ -admissible  $\chi \in X^*(L_2)$ , whose restriction to  $L_1$  is orbitally p-close (Def. N.5.3). Then  $\widetilde{f}$  has discrete fibers on the underlying topological spaces.

<span id="page-2-6"></span>Remark I.1.3. The corollary generalizes [61, Cor. 3] about the  $\mu$ -ordinary locus. In [36, Th. 2], we generalized Cor. I.1.2 above as follows: We proved that if  $f:(G_1,\mu_1)\to (G_2,\mu_2)$  is a morphism with central scheme-theoretic kernel, then  $\tilde{f}$  has discrete fibers. The extra assumption of Cor. I.1.2 is thus unnecessary.

I.2. The EO stratification of Hodge-type Shimura varieties. For the rest of the introduction, assume p > 2. Suppose  $(\mathbf{G}, \mathbf{X})$  is a Shimura datum of Hodge type. Assume  $\mathbf{G}$  is unramified at some prime p and  $\mathcal{K} = \mathcal{K}_p \mathcal{K}^p$  is an open compact subgroup of  $\mathbf{G}(\mathbf{A}_f)$  with  $\mathcal{K}_p \subset \mathbf{G}(\mathbf{Q}_p)$  hyperspecial and  $\mathcal{K}^p \subset \mathbf{G}(\mathbf{A}_f^p)$ . Let  $\mathscr{S}_{\mathcal{K}}$  be the Kisin-Vasiu integral model at p, of level  $\mathcal{K}$ , of the associated Shimura variety  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})$  (§4.1.3). Write  $S_{\mathcal{K}}$  for the special fiber of  $\mathscr{S}_{\mathcal{K}}$  at a a prime  $\mathfrak{p}$  of the reflex field dividing p.

Let  $[\mu]$  be the  $\mathbf{G}(\mathbf{C})$ -conjugacy class of cocharacters deduced from  $\mathbf{X}$ . By Zhang [113], there is a smooth morphism

$$\zeta: S_{\mathcal{K}} \longrightarrow G\text{-}\mathsf{Zip}^{\mu}$$

where  $(G, [\mu])$  is the reduction modulo p of an integral model of  $(\mathbf{G}_{\mathbf{C}}, [\mu])$  (see §§4.1.5,4.2). Let  $S_w := \zeta^{-1}([E \setminus G_w])$  for  $w \in {}^I W$ .

We first describe the key applications of Th. I.1.1 to the EO stratification of  $S_{\mathcal{K}}$  and then discuss extensions to compactifications. In particular, note that the following three corollaries are completely independent of the theory of compactifications.

Let  $\omega$  be the Hodge line bundle on  $S_{\mathcal{K}}$  associated to a symplectic embedding  $\varphi: (\mathbf{G}, \mathbf{X}) \to (GSp(2g), \mathbf{X}_g)$ . Let  $\eta_{\omega}$  be the character of L satisfying  $\omega = \mathscr{V}(\eta_{\omega})$  (§4.1.11). We have shown [38, Th. 1.4.4] that  $\eta_{\omega}$  is quasi-constant (Def. N.5.3(b)). Moreover,  $\eta_{\omega}$  is easily seen to be L-ample (Def. N.5.1). A quasi-constant character is orbitally p-close for all p (Rmk. N.5.4). Since (p, L)-admissible is defined as L-ample and orbitally p-close (Def. N.5.3),  $\eta_{\omega}$  is (p, L)-admissible for all p. Hence:

<span id="page-2-3"></span>Corollary I.2.1 (Cor. 4.3.4). Suppose  $(G, \mu)$  arises by reduction modulo p from a Hodge-type Shimura datum and  $\chi = \eta_{\omega}$ . Then the conclusion of Th. I.1.1 holds for all primes p.

Remark I.2.2. There is another proof of Cor. I.2.1 that does not use the notion of "quasi-constant characters" and the result of [38, Th. 1.4.4]. By [36, Cor. 1], Corollary 4.3.4 holds for a more general class of pairs  $(G, \mu)$ , namely the "maximal" ones (loc. cit., §2.4). The proof is based on the discrete fiber theorem (loc. cit., Th. 2).

Pulling back the sections of Cor. I.2.1 along  $\zeta$ , we obtain Hasse invariants for all EO strata of  $S_{\kappa}$ .

<span id="page-2-4"></span>Corollary I.2.3 (EO Hasse invariants, Cor. 4.3.5). For every EO stratum  $S_w \subset S_K$ , there exists  $N_w \geq 1$  and a section  $h_w \in H^0(\overline{S}_w, \omega^{N_w})$  whose non-vanishing locus is precisely  $S_w$ .

The sections  $h_w$  are also  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant, see Cor. 4.3.5. Since the nonvanishing locus of a section of an ample line bundle on a proper scheme is affine, we deduce:

<span id="page-2-5"></span>Corollary I.2.4 (Affineness, compact case; Cor. 4.3.6). Assume  $(\mathbf{G}, \mathbf{X})$  is a Shimura datum of compact type. Then all EO strata in  $S_K$  are affine.

<span id="page-2-1"></span><sup>&</sup>lt;sup>1</sup>Unless otherwise stated, the Zariski closure is always equipped with the reduced scheme structure.

The following results concern extending the EO stratification and its Hasse invariants to compactifications. Let  $S_{\mathcal{K}}^{\Sigma}$  be one of the proper toroidal compactifications of  $S_{\mathcal{K}}$  constructed by Madapusi-Pera (§6.1.1). In the next theorem, we do not assume  $S_{\mathcal{K}}^{\Sigma}$  is smooth, but we do require a technical log-integrality assumption related to  $\Sigma$ , see §6.1.2, §6.2.

<span id="page-3-0"></span>**Theorem I.2.5** (Th. 6.2.1). One has:

- (a) The map  $\zeta$  admits an extension  $\zeta_{\mathcal{K}}^{\Sigma}: S_{\mathcal{K}}^{\Sigma} \longrightarrow G\text{-}\mathrm{Zip}^{\mu}$ . (b) Let  $G_w \subset G$  be an E-orbit; put  $S_w^{\Sigma} = (\zeta_{\mathcal{K}}^{\Sigma})^{-1}([E \backslash G_w])$  and  $S_w^{\Sigma,*} = (\zeta_{\mathcal{K}}^{\Sigma})^{-1}([E \backslash \overline{G}_w])$ . Then the Hasse invariant  $h_w \in H^0(\overline{S}_w, \omega^{N_w})$ ) of Cor. I.2.3 extends to  $h_w^{\Sigma} \in H^0(S_w^{\Sigma,*}, \omega^{N_w})$  with non-vanishing locus  $S_w^{\Sigma}$ .

Furthermore, the extension  $\zeta_{\mathcal{K}}^{\Sigma}$  is  $\mathbf{G}(\mathbf{A}_{f}^{p})$ -equivariant (6.2.2). Let  $S_{\mathcal{K}}^{\min}$  be the minimal compactification of  $S_{\mathcal{K}}$  (§6.1.6). Define  $S_{w}^{\min}$  as the image of  $S_{w}^{\Sigma}$  by the natural map  $S_{\mathcal{K}}^{\Sigma} \to S_{\mathcal{K}}^{\min}$ . We call  $S_{w}^{\min}$  the extended EO strata in  $S_{\kappa}^{\text{min}}$ . Combining Th. I.2.5 with a Stein factorization argument, we deduce:

<span id="page-3-1"></span>Corollary I.2.6 (Affineness, noncompact case; Prop. 6.3.1). Suppose (G, X) is a Shimura datum of noncompact, Hodge type. Then the extended EO strata  $S_w^{\min}$  are affine for all  $w \in {}^IW$ .

In the Siegel case – for  $\mathcal{A}_q \otimes \mathbf{F}_p$  with a suitable level structure – Cor. I.2.6 was conjectured by Oort almost twenty years ago [85, 14.2]. As far as we know, even this special case of Cor. I.2.6 is new. The affineness of the generic EO stratum for Hodge-type Shimura varieties was proved by the second author and T. Wedhorn ([62, Cor. 2]).

In the restricted special case of Shimura varieties of PEL-type A and C, the thesis of G. Boxer [11, 10] obtained the Corollaries I.2.3, I.2.4, I.2.6 and a variant of Th. I.2.5 simultaneously and independently from us.

# I.3. Applications to the Langlands correspondence.

I.3.1. Galois representations associated to automorphic representations. The Langlands correspondence (for number fields) predicts that the distinguished subclass of automorphic representations having integral infinitesimal character - those termed L-algebraic in [14] - satisfy a number of algebraicity properties; see loc. cit. for some precise conjectures. In particular, if F is a number field, G is a connected, reductive F-group and  $\pi$  is an L-algebraic automorphic representation of G, then it is conjectured that, for every prime p, there exists an associated L-groupvalued, continuous Galois representation

<span id="page-3-2"></span>(Gal) 
$$R_{p,\iota}(\pi) : \operatorname{Gal}(\overline{F}/F) \longrightarrow {}^{L}G(\overline{\mathbf{Q}}_{p}).$$

Following the pioneering works of Deligne and Deligne-Serre on classical modular forms [23, 25], there has been an increasingly sustained effort by a growing number of people to construct the Galois representations (Gal). For a discussion and references concerning previous work on the association (Gal), cf. the first author's earlier papers [32, 33]. Thus far, most works have been limited to the (weaker) construction of  $r \circ R_{p,\iota}(\pi)$ , where  $r: {}^LG \longrightarrow$ GL(n) is some low-dimensional representation of  ${}^LG$ . A notable exception is the recent preprint of Kret-Shin [63]. which constructs GSpin(2q+1)-valued Galois representations for certain  $\pi$  of the split symplectic similitude group GSp(2q).

Most of the work to date on (Gal) has been restricted to cases when the archimedean component  $\pi_{\infty}$  is regular. Prior to this work, the limited number of results which considered irregular  $\pi_{\infty}$  were all in cases when  $\pi_{\infty}$  is a holomorphic limit of discrete series (LDS); this is the mildest possible type of irregularity [101, 54, 32, 39]. For a detailed classification of archimedean components in terms of (Gal), see [34].

I.3.2. Pseudo-representations associated to torsion. Starting with Ash [5], a number of torsion analogues of the Langlands correspondence have been proposed, where automorphic representations are replaced by systems of Hecke eigenvalues appearing in the cohomology (Betti or coherent) of a locally symmetric space with mod  $p^n$  coefficients and the Galois representations (Gal) are replaced by mod  $p^n$ -valued pseudo-representations. The interest in such "torsion Langlands correspondences" has grown considerably due to the pivotal role that they play in the Calegari-Geraghty program of pushing the Taylor-Wiles method beyond the regular case [15].

Scholze achieved a breakthrough in the Betti case, by associating pseudo-representations to the cohomology of the locally symmetric spaces of GL(n) over a CM field, with mod  $p^n$  coefficients [94]. By contrast, much less was known prior to this work concerning the coherent cohomology of Shimura varieties mod  $p^n$ . The only case where pseudo-representations were associated to higher coherent cohomology (i.e.,  $H^i$ , i > 0) was that of Hilbert modular varieties, due to Emerton-Reduzzi-Xiao [29].

I.3.3. New results about the Langlands correspondence. In this paper, we prove general results which associate pseudo-representations to the coherent cohomology of Hodge-type Shimura varieties modulo a prime power. Consequently, we deduce results about the existence of  $r \circ R_{p,\iota}(\pi)$  when G is a Q-group admitting a Hodge-type Shimura variety and  $\pi_{\infty}$  is an arbitrary non-degenerate LDS.

Let  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  be a toroidal compactification of a Hodge type Shimura variety  $\mathscr{S}_{\mathcal{K}}$  as in §I.2. We now add the assumption that  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  is smooth. Write  $\mathscr{S}^{\Sigma,n}_{\mathcal{K}}$  for its reduction mod  $p^n$ , so that  $S^{\Sigma}_{\mathcal{K}} = \mathscr{S}^{\Sigma,1}_{\mathcal{K}}$  is its special fiber. Let  $\mathscr{V}^{\text{sub}}(\eta)$  be

the subcanonical extension to  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  of an automorphic vector bundle  $\mathscr{V}(\eta)$  on  $\mathscr{S}_{\mathcal{K}}$  (§4.1.9). Let  $\mathcal{H}$  denote the (global, unramified, prime-to-p) Hecke algebra of  $\mathbf{G}$  and  $\mathcal{H}^{i,n}(\eta)$  its image in  $\operatorname{End}(H^{i}(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\operatorname{sub}}(\eta)))$  (§8.1).

The following two theorems summarize our results; see Ths. 8.2.1, 10.4.1, 10.5.1 for the precise statements. Unconditional analogues of Th. I.3.2 for unitary groups are given in Ths. 10.4.5, 10.5.3.

<span id="page-4-1"></span>**Theorem I.3.1** (Factorization). Let  $\mathcal{V}(\eta)$  be an automorphic vector bundle on  $\mathcal{S}_{\mathcal{K}}$  and  $i \geq 0$  an integer. Suppose  $\mathrm{Sh}(\mathbf{G},\mathbf{X})$  is either of compact-type, or of PEL-type, or that  $(S_{\mathcal{K}}^{\Sigma},\mathcal{V}(\eta))$  satisfies Conditions 6.4.2, 7.1.2. Then, for every  $\delta \in \mathbf{R}_{>0}$  there exists a  $\delta$ -regular weight  $\eta'$  (Def. N.5.5) such that

$$\mathcal{H} \twoheadrightarrow \mathcal{H}^{i,n}(\eta)$$
 factors through  $\mathcal{H} \twoheadrightarrow \mathcal{H}^{0,n}(\eta')$ .

For Shimura varieties of PEL type A or C, Boxer independently and simultaneously obtained the weaker statement that  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  factors through  $\mathcal{H} \to \mathcal{H}^{0,n}(\eta + a\eta_{\omega})$  for infinitely many a, [11, 10]. In contrast with Th. I.3.1, the weights  $\eta + a\eta_{\omega}$  may all be singular; see also Rmk. 8.2.2.

<span id="page-4-0"></span>**Theorem I.3.2.** Keep the hypotheses of Th. I.3.1 and fix  $\delta \in \mathbf{R}_{\geq 0}$ . Assume  $r : {}^L G \to GL(n)$  satisfies that  $r \circ R_{p,\iota}(\pi')$  exists for all C-algebraic (§10.1.1),  $\delta$ -regular  $\pi'$ . Then

<span id="page-4-2"></span>(a) For every triple  $(i, n, \eta)$ , there exists a continuous Galois pseudo-representation

$$R_{p,\iota}(r;i,n,\eta): \operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \longrightarrow \mathcal{H}^{i,n}(\eta),$$

which for unramified  $v, v \neq p$ , maps  $\operatorname{Frob}_{v}^{j}$  to the Hecke operators  $T_{v}^{(j)}$  defined in §10.2.

(b) Assume  $\pi$  is a cuspidal automorphic representation of  $\mathbf{G}$  with  $\pi_{\infty}$  a non-degenerate, C-algebraic LDS and  $\pi_p$  unramified. Then  $r \circ R_{p,\iota}(\pi)$  exists too.

The case of cohomological degree i>0 reveals genuinely new obstacles (for both Th. I.3.1 and Th. I.3.2). In terms of automorphic representations, i>0 corresponds to the condition that the non-degenerate LDS  $\pi_{\infty}$  is non-holomorphic. When i>0, it is apparent that the original Deligne-Serre method of multiplication by a single mod p automorphic form is insufficient.

Our new idea to overcome this problem is to use not just one mod p automorphic form, but rather a whole family of such viz. the strata Hasse invariants  $h_w$  and their toroidal extensions  $h_w^{\Sigma}$ . These are 'generalized mod p automorphic forms', in that they aren't defined on the whole special fiber of the Shimura variety, but only on EO strata closures. As pullbacks of sections on strata of G-Zip $^{\mu}$ , the  $h_w$ ,  $h_w^{\Sigma}$  are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant (§4.2, Th. 6.2.1). The reduction to the case i=0 is accomplished by studying the long exact sequences in coherent cohomology associated to technical modifications of the  $h_w$ ,  $h_w^{\Sigma}$ .

Results similar to Th. I.3.1 and Th. I.3.2 were obtained simultaneously and independently by Pilloni-Stroh [86]. Their method is completely different: It is based on Scholze's theory of perfectoid Shimura varieties. The analogue of Th. I.3.2(a) in *loc. cit.* concerns the coherent cohomology of Scholze's integral models of Sh(G, X) rather than the modular Kisin-Vasiu models studied here. Boxer also announced applications of his thesis to the construction of Galois representations, but as far as we know, no preprint containing such results has appeared.

I.4. Serre's Letter to Tate on mod p modular forms. Let N be prime to p and let X(N) (resp.  $(X(N)^{ss})$  be the modular curve of full level N (resp. its supersingular locus) in characteristic p. In his letter to Tate [95], Serre first showed that the systems of Hecke eigenvalues which appear in  $\bigoplus_{k\in\mathbb{N}} H^0(X(N),\omega^k)$  are the same as those which appear in  $\bigoplus_{k\in\mathbb{N}} H^0(X(N)^{ss},\omega^k)$ . He went on to show that these systems of Hecke eigenvalues are also precisely those that appear in Gross' algebraic modular forms for the quaternion algebra  $B_{p,\infty}$  ramified at  $\{p,\infty\}$ .

As a further application of group-theoretical Hasse invariants, we generalize Serre's first result to arbitrary Shimura varieties of Hodge type. Let D be the boundary divisor of  $\mathscr{S}_{\mathcal{K}}$  in  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$ . Let  $S_e$  be the (unique) zero-dimensional EO stratum of  $S_{\mathcal{K}}$ .

<span id="page-4-3"></span>**Theorem I.4.1** (see Th. 11.1.1). If  $(\mathbf{G}, \mathbf{X})$  is neither of compact-type, nor of PEL-type, then assume that there exists a a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant Cartier divisor D' such that  $D'_{\mathrm{red}} = D$  and  $\omega^k(-D')$  is ample on  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  for all  $k \gg 0$ . As  $\eta$  ranges over all weights, the systems of Hecke eigenvalues appearing in each of  $\bigoplus_{\eta} H^0(S_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta))$  and  $\bigoplus_{\eta} H^0(S_e, \mathscr{V}(\eta))$  are the same. In particular the number of such systems is finite.

This application lies on the border between (A) Automorphic Algebraicity and (B) G-Zip Geometricity. The existence of such D' is known in the PEL case by Lan [66, Th. 7.3.3.4] (see also Rmk. 11.1.2 below) and it should follow similarly in the general Hodge case from the work of Madapusi-Pera [77]. In future work, we hope to return to Serre's second result in this level of generality. It is likely that it follows from the recent preprint [111], but we have not checked this in detail.

No cases of Th. I.4.1 were previously known where the classical superspecial locus of  $S_{\mathcal{K}}$  is empty<sup>2</sup>. Serre's two results had previously been generalized by Ghitza to Siegel modular varieties [30] and by Reduzzi to a (rather restricted) class of PEL-type Shimura varieties [90]. Unfortunately, these works seem to contain a nontrivial error, see Rmk. 11.2.1. Both were limited to PEL cases where the classical superspecial locus of  $S_{\mathcal{K}}$  is nonempty. Analogous to the distinction between the classical ordinary locus and the  $\mu$ -ordinary locus (=unique open EO stratum), examples of both PEL and Hodge-type abound where the classical superspecial locus is empty. For example, if ( $\mathbf{G}, \mathbf{X}$ ) is of unitary type with reflex field  $E \neq \mathbf{Q}$  and p splits completely in E, then the classical superspecial locus of  $S_{\mathcal{K}}$  is empty.

Using Ths. I.3.1 and Th. I.4.1, we deduce:

Corollary I.4.2 (See Cor. 11.1.3). Make the assumptions of Th. I.3.1. As i varies over all nonnegative integers and  $\eta$  varies over all weights, the number of systems of Hecke eigenvalues appearing in

$$\bigoplus_{i,n} H^i(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta)) \oplus H^i(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{can}}(\eta)) \oplus H^0(S_e, \mathscr{V}(\eta))$$

is finite.

I.5. **Outline.** Following a preliminary  $\S N$  to fix notation, this paper is naturally divided into three parts: The primary goal of Part 1 ( $\S\S1-3$ ) is the construction of group-theoretical Hasse invariants (Th. I.1.1). To this end, we introduce the stack of zip flags ( $\S2$ ). Parts 2 and 3 are concerned with applications. Part 2 contains those applications which are directly concerned with the geometry of the EO stratification of Shimura varieties, but which avoid Hecke operators. By contrast, Part 3 regards three applications involving the Hecke algebra: (i) Factorization of the Hecke algebra action on the coherent cohomology of automorphic vector bundles ( $\S\S8-9$ ), (ii) Association of Galois pseudorepresentations to coherent cohomology modulo  $p^n$  and Galois representations to automorphic representations of non-degenerate LDS-type ( $\S10$ ), (iii) Generalization of Serre's Letter to Tate ( $\S11$ ). We refer to the beginning of each section for a more detailed description of its contents.

#### <span id="page-5-0"></span>NOTATION

# <span id="page-5-4"></span>N.1. Ring theory.

- N.1.1. Throughout, k denotes an algebraically closed field.
- N.1.2. Adeles. The adele ring of **Q** is written **A**, the finite adeles  $\mathbf{A}_f$ . Given a prime p,  $\mathbf{A}_f^p$  denotes the finite adeles with trivial p-adic component.
- N.1.3. *CM fields*. A number field is a finite extension of **Q**. In this paper, 'CM field' means a number field which is either totally real or a totally imaginary quadratic extension of a totally real field.

### <span id="page-5-1"></span>N.2. Scheme theory.

N.2.1. Base Change. If A is a commutative ring with 1, M is an A-module and B an A-algebra, we write  $M_B$  for the B-module  $M \otimes_A B$ .

If S is a scheme,  $f: X \to S$  is an S-scheme and  $g: T \to S$  is a morphism of schemes, write  $X_T$  for the base change  $X \times_S T$ . If  $S = \operatorname{Spec}(A)$  and  $T = \operatorname{Spec}(B)$ , then we also write  $X_B$  in place of  $X_T$ .

- N.2.2. Frobenius twist. Let k be a field of characteristic p, and  $\sigma: k \to k$  the map  $x \mapsto x^p$ . For a k-scheme X, we denote by  $X^{(p)}$  the fiber product  $X^{(p)} := X \otimes_{k,\sigma} k$ .
- <span id="page-5-5"></span>N.2.3. Reduction modulo  $p^n$ . Let p be a prime,  $K/\mathbb{Q}_p$  a finite extension with ring of integers  $\mathcal{O}_K$  and maximal ideal  $\mathfrak{p}$ . If  $\mathcal{X}$  is an  $\mathcal{O}_K$ -scheme, write  $\mathcal{X}^n$  for the base change of  $\mathcal{X}$  along  $\operatorname{Spec} \mathcal{O}_K/\mathfrak{p}^n \to \operatorname{Spec} \mathcal{O}_K$ . In particular,  $\mathcal{X}^1$  is the special fiber of  $\mathcal{X}$ .

Occasionally it will be useful to consider  $\mathcal{X}^n$  for all  $n \in \mathbf{Z}_{\geq 1}$ , as well  $\mathcal{X}$  and its generic fiber  $\mathcal{X} \otimes_{\mathcal{O}_K} K$ . For this purpose we adopt the convention of writing  $\mathcal{X}^+ := \mathcal{X}$  and  $\mathcal{X}^0 := \mathcal{X} \otimes_{\mathcal{O}_K} K$ .

<span id="page-5-6"></span>N.2.4. Sections of line bundles. If X is a scheme,  $\mathcal{L}$  is a line bundle on X and  $s \in H^0(X, \mathcal{L})$ , write Z(s) for the scheme of zeroes of s in X (cf. [51, App. A, C6]) and nonvanish(s) for the open subset  $X \setminus Z(s)$ .

We say  $s \in H^0(X, \mathcal{L})$  is *injective* if the map of sheaves  $\mathcal{O}_X \to \mathcal{L}$  given by multiplication by s is injective.<sup>3</sup> Equivalently s is injective if and only if Z(s) is an effective Cartier divisor in X.

N.2.5. Associated Reduced Scheme. If X is any scheme,  $X_{\rm red}$  will denote the associated reduced subscheme.

<span id="page-5-2"></span><sup>&</sup>lt;sup>2</sup>To avoid confusion, we specify that for us the classical superspecial locus means those points whose underlying abelian scheme is isomorphic to a product of supersingular elliptic curves. Some refer to this locus simply as the "superspecial locus", while others reserve the same term for the zero-dimensional EO stratum. The latter two conventions are jointly incompatible, already in the PEL case.

<span id="page-5-3"></span><sup>&</sup>lt;sup>3</sup>Such a section is sometimes referred to as regular (cf. [99, Def. 11.17]), but we find the term injective less confusing.

# <span id="page-6-7"></span>N.3. Structure Theory and Root data.

<span id="page-6-8"></span>N.3.1. Root data. Let G be an algebraic k-group. Write  $X^*(G)$  (resp.  $X_*(G)$ ) for the group of characters (resp. cocharacters) of G. If T is a k-torus, write  $\langle , \rangle$  for the perfect pairing  $X^*(T) \times X_*(T) \to \mathbf{Z}$ .

For a connected, reductive k-group G and a maximal torus  $T \subset G$ , write  $\Phi := \Phi(G,T)$  for the T-roots in G,  $\Phi^{\vee} := \Phi^{\vee}(G,T)$  for the T-coroots in G and  $\mathcal{RD}(G,T) = (X^*(T),\Phi,X_*(T),\Phi^{\vee})$  for the root datum of T in G. If L is a Levi subgroup of G containing T, set  $\Phi_L := \Phi(L,T)$  (resp.  $\Phi_L^{\vee} := \Phi^{\vee}(L,T)$ ).

<span id="page-6-3"></span>N.3.2. Based root data. If B is a Borel subgroup of G containing T, define the system of positive roots  $\Phi^+ \subset \Phi$  by the condition that  $\alpha \in \Phi^+$  when the root group  $U_{-\alpha} \subset B$ . Put  $\Phi^- := -\Phi^+$ . The subset of simple roots in  $\Phi^+$  is denoted  $\Delta$  and the set of simple coroots is denoted  $\Delta^{\vee}$ . Write  $X_{+}^{*}(T) = \{\chi \in X^{*}(T) | \langle \chi, \alpha^{\vee} \rangle \geq 0 \text{ for all } \alpha \in \Delta \}$  for the cone of  $\Delta$ -dominant characters. Put

(N.3.1) 
$$\rho := \frac{1}{2} \sum_{\alpha \in \Phi^+} \alpha \in X^*(T)_{\mathbf{Q}}.$$

If L is a Levi subgroup of G, set  $\Delta_L := \Delta \cap \Phi_L$ ,  $\Delta_L^{\vee} := \Delta^{\vee} \cap \Phi_L^{\vee}$ . Write  $X_{+,L}^*(T)$  for the cone of  $\Delta_L$ -dominant characters. Similarly, put  $\Phi_L^+ := \Phi^+(L,T)$  and  $\Phi_L^- := \Phi^-(L,T)$ .

<span id="page-6-2"></span>N.3.3. Weyl group. Let W := W(G,T) be the Weyl group of T in G. For  $\alpha \in \Phi$ , let  $s_{\alpha}$  denote the root reflection about  $\alpha^{\vee}$ . Write  $\ell: W \to \mathbb{Z}_{>0}$  for the length function of the Coxeter group  $(W, \{s_{\alpha}\}_{\alpha \in \Delta})$ . The longest element of W is denoted by  $w_0$  and the identity element by e.

If  $L \subset G$  is a Levi subgroup containing T, denote by  $W_L \subset W$  the Weyl group of L. Write  $w_{0,L}$  for the longest element in  $W_L$ . If  $P \subset G$  is a parabolic subgroup, denote its type by  $\operatorname{type}(P) \subset \Delta$ . It is normalized as follows: If P contains B with Levi subgroup L containing T, then  $type(P) := \Delta_L$ .

Given  $I \subset \Delta$ , let  $W_I \subset W$  be the subgroup generated by the elements  $s_\alpha$  for  $\alpha \in I$ . Let  $w_{0,I}$  denote the longest element of  $W_I$ . Define  ${}^IW$  (resp.  $W^I$ ) as the subset of elements  $w \in W$  which are of minimal length in the coset  $W_I w$  (resp.  $wW_I$ ). The set  $W^I$  (resp.  $W^I$ ) is a set of representatives for the quotients  $W_I \setminus W$  (resp.  $W/W_I$ ). The longest element of  ${}^{I}W$  (resp.  $W^{I}$ ) is  $w_{0,I}w_{0}$  (resp.  $w_{0}w_{0,I}$ ). For a Levi subgroup L, one has

<span id="page-6-4"></span>
$$(N.3.2) w_{0,L}\Phi_L^+ \subset \Phi_L^-$$

$$(\mathrm{N}.3.2) \qquad \qquad w_{0,L}\Phi_L^+ \subset \Phi_L^-$$
 
$$(\mathrm{N}.3.3) \qquad \qquad w\left(\Phi^+ \setminus \Phi_L^+\right) \subset \Phi^+ \quad \text{for all } w \in W_L.$$

<span id="page-6-6"></span>N.3.4. Weyl chambers. Write  $\alpha^{\perp}$  for the hyperplane in  $X^*(T)_{\mathbf{R}}$  orthogonal to  $\alpha^{\vee}$ . A Weyl chamber is a connected component C of  $X^*(T)_{\mathbb{R}} \setminus \bigcup_{\alpha \in \Phi} \alpha^{\perp}$ ; thus C is an open cone for the archimedean topology. Write  $\overline{C}$  for the closure of C and  $\partial C := \overline{C} \setminus C$  for its boundary. One says that  $\alpha \in \Phi$  (resp.  $\alpha^{\vee} \in \Phi^{\vee}$ ) is C-positive if  $\langle \chi, \alpha^{\vee} \rangle > 0$  for any (equivalently every)  $\chi \in C$ . The C-positive roots (resp. coroots) form a system of positive roots (resp. coroots).

<span id="page-6-1"></span>N.3.5. Galois action. Now suppose that G,T are  $\kappa$ -groups for some subfield  $\kappa \subset k$ . The root datum and Weyl group of (G,T) are by definition those of  $(G_k,T_k)$ . The group  $\operatorname{Gal}(k/\kappa)$  acts on both W and  $\mathcal{RD}(G,T)$ . The actions of W and  $Gal(k/\kappa)$  on  $X^*(T)$  are related by the formula

$$(N.3.4) \sigma(w\lambda) = {}^{\sigma}w {}^{\sigma}\lambda$$

for all  $w \in W$ ,  $\sigma \in \operatorname{Gal}(k/\kappa)$  and  $\lambda \in X^*(T)$ .

If B is a Borel subgroup of  $G_{\kappa'}$  for some finite extension  $\kappa'/\kappa$ , the based root datum of (G, B, T) is that of the triple  $(G_k, B_k, T_k)$ .

<span id="page-6-5"></span>N.3.6. Ramification. In the notation of §N.3.5, suppose  $\kappa$  is a number field. The set of finite places v of  $\kappa$  where Gramifies, together with all the infinite places is denoted Ram(G). Similarly, if  $\pi$  is an admissible representation of  $G(\mathbf{A}_{\kappa})$  given by a restricted tensor product of components  $\pi_v$ , then  $Ram(\pi)$  denotes the set of places v where  $\pi_v$  is ramified, together with all the archimedean places.

N.4. Quotients. If an algebraic k-group G acts on a k-scheme X, we denote by  $[G \setminus X]$  the associated quotient stack. Denote by  $\pi: X \to [G \setminus X]$  the natural projection. If  $: X \times G \to X$  is a right action, we define [X/G] as  $[G\backslash X]$  for the action  $g\star x:=x\cdot g^{-1}$ .

<span id="page-6-0"></span>N.4.1. Vector bundles on quotient stacks. Let G act on X and  $\rho: G \to GL_{n,k}$  be an n-dimensional k-representation of G. There is an associated vector bundle  $\mathcal{V}(\rho)$  on the quotient stack  $[G \setminus X]$ , such that

$$(\mathrm{N.4.1}) \qquad \qquad H^0\left(\left[G\backslash X\right],\mathscr{V}(\rho)\right) = \{f: X \to \mathbf{A}^n \mid f(g\cdot x) = \rho(g)f(x), \ \forall g \in G, x \in X\}.$$

<span id="page-7-9"></span>N.5. Conditions on characters. Let (G, B, T) as in §N.3.5 and  $L \subset G$  a Levi subgroup containing T. Let  $I \subset \Delta$  be the type of the parabolic P = LB.

**Definition N.5.1.** We say that  $\chi \in X^*(L)$  is L-ample if it satisfies  $\langle \chi, \alpha^{\vee} \rangle < 0$  for all  $\alpha \in \Delta \setminus I$ .

<span id="page-7-6"></span>Remark N.5.2. By [53, II, (4.4)] the following are equivalent:

- (a)  $\chi$  is L-ample.
- (b) The associated line bundle  $\mathcal{L}(\chi)$  is anti-ample on G/P.

<span id="page-7-1"></span>**Definition N.5.3.** Let  $\chi \in X^*(T)$ . For every coroot  $\alpha^{\vee}$  satisfying  $\langle \chi, \alpha^{\vee} \rangle \neq 0$ , put

$$\operatorname{Orb}(\chi, \alpha^{\vee}) = \left\{ \frac{|\langle \chi, \sigma \alpha^{\vee} \rangle|}{|\langle \chi, \alpha^{\vee} \rangle|} \middle| \sigma \in W \rtimes \operatorname{Gal}(k/\kappa) \right\}.$$

<span id="page-7-2"></span>We say that  $\chi$  is

- (a) orbitally p-close if max  $\operatorname{Orb}(\chi, \alpha^{\vee}) \leq p-1$  for all  $\alpha \in \Phi$  with  $\langle \chi, \alpha^{\vee} \rangle \neq 0$ .
- (b) quasi-constant if  $\operatorname{Orb}(\chi, \alpha^{\vee}) \subset \{0, 1\}$  for all  $\alpha \in \Phi$  with  $\langle \chi, \alpha^{\vee} \rangle \neq 0$ .
- <span id="page-7-5"></span>(c) p-small if  $|\langle \chi, \alpha^{\vee} \rangle| \leq p-1$  for all  $\alpha \in \Phi$ .
- (d) (p, L)-admissible if  $\chi$  is orbitally p-close and L-ample.

<span id="page-7-3"></span>Remark N.5.4. Recall that  $\chi \in X^*(T)$  is minuscule if  $\langle \chi, \alpha^{\vee} \rangle \in \{-1, 0, 1\}$  for all  $\alpha \in \Phi$ . The notions introduced in Def. N.5.3 and the minuscule condition satisfy the following relations:

$$\begin{array}{ccc} & \Longrightarrow & (\text{quasi-constant}) \\ & \Longrightarrow & & \Longrightarrow \\ & & \Longrightarrow & \left( \begin{array}{c} \text{orbitally $p$-close} \\ \text{for all $p$} \end{array} \right) \end{array}$$

For more on quasi-constant (co)characters, including a general classification and applications, see [38].

<span id="page-7-4"></span>**Definition N.5.5.** Let  $\delta \in \mathbb{R}_{>0}$ . We say that  $\chi \in X^*(T)$  is  $\delta$ -regular if  $|\langle \chi, \alpha^{\vee} \rangle| > \delta$  for all  $\alpha \in \Phi$ .

The case  $\delta = 0$  gives the usual notion of regularity.

N.6. Hodge structures. Let  $\mathbf{S} := \operatorname{Res}_{\mathbf{C}/\mathbf{R}} \mathbf{G}_{m,\mathbf{C}}$  be the Deligne torus. An **R**-Hodge structure is a morphism of **R**-algebraic groups  $\mathbf{S} \to GL(V_{\mathbf{R}})$ , where  $V_{\mathbf{R}}$  is an **R**-vector space.

<span id="page-7-8"></span>N.6.1. Hodge bigrading convention. An **R**-Hodge structure  $h: \mathbf{S} \to GL(V_{\mathbf{R}})$  induces a bigrading  $V_{\mathbf{C}} = \bigoplus_{a,b \in \mathbf{Z}} V^{a,b}$ . Our convention is that of Deligne [24, 1.1.6]:  $z \in \mathbf{S}(\mathbf{R})$  acts on  $V^{a,b}$  via  $z^{-a}\bar{z}^{-b}$ . In particular, a complex structure on  $V_{\mathbf{R}}$  is an **R**-Hodge structure of type  $\{(0,-1),(-1,0)\}$ .

<span id="page-7-7"></span>N.6.2. Associated cocharacter. There is a natural isomorphism  $\mathbf{S}_{\mathbf{C}} \simeq \prod_{\mathbf{Gal}(\mathbf{C}/\mathbf{R})} \mathbf{G}_{m,\mathbf{C}}$ . Let  $\mu_0 : \mathbf{G}_{m,\mathbf{C}} \to \mathbf{S}_{\mathbf{C}}$  be the natural injection onto the factor corresponding to  $\mathrm{Id} \in \mathrm{Gal}(\mathbf{C}/\mathbf{R})$ . If G is a connected, reductive  $\mathbf{R}$ -group and  $h : \mathbf{S} \to G$  is a morphism of  $\mathbf{R}$ -groups, the cocharacter  $\mu \in X_*(G)$  associated to h is  $\mu := h_{\mathbf{C}} \circ \mu_0$ .

# <span id="page-7-0"></span>Part 1. Group-theoretical Hasse invariants

Part 1 is devoted to group-theoretical objects. Section  $\S1.1$  recalls basic facts about morphisms of quotient stacks, used throughout this part. In  $\S1.2$ , we recall the definition of the stack of G-Zips and introduce the notion of cocharacter data. Those of Hodge-type are singled out in  $\S1.3$ . In  $\S1.4$ , we recall the parametrization and properties of zip strata.

The topic of §2 is the stack of zip flags G-ZipFlag $^{\mu}$ , it is key for constructing Hasse invariants. The definition is given in §2.1. We recall the definition and the properties of the 'Schubert stack' in §2.2. It is used to define a stratification of G-ZipFlag $^{\mu}$  in §2.3. Special strata termed 'minimal' and 'cominimal' are studied in §2.4.

We apply these tools in §3 to construct group-theoretical Hasse invariants. First, §3.1 studies line bundles on these various stacks. The main result of Part 1 is Th. 3.2.3, proved in §3.2. We discuss functoriality and deduce Th. 3.3.1 in §3.3. Finally, we introduce the cone of global sections in §3.4; it will be used later in §9.2.

<span id="page-8-3"></span><span id="page-8-0"></span>1.1. Morphisms of quotient stacks. Let  $f: X \to Y$  be a morphism of schemes and let G, H be group schemes such that G acts on X and H acts on Y. Let  $\alpha: G \times X \to H$  be a map of schemes satisfying

$$(1.1.1) f(g \cdot x) = \alpha(g, x) \cdot f(x), \quad g \in G, \ x \in X$$

and the cocycle condition

$$\alpha(qq',x) = \alpha(q,q'\cdot x)\alpha(q',x) \quad q,q' \in G, \ x \in X.$$

Then  $(f, \alpha)$  induces a morphism between the groupoids attached to (G, X) and (H, Y), which yields in turn a map of stacks  $\tilde{f} : [G \setminus X] \to [H \setminus Y]$ , such that the following diagram commutes:

$$\begin{array}{ccc}
X & \xrightarrow{f} & Y \\
\downarrow & & \downarrow \\
[G\backslash X] & \xrightarrow{\tilde{f}} & [H\backslash Y]
\end{array}$$

where the vertical maps are the natural projections.

# <span id="page-8-1"></span>1.2. The stack of G-zips.

<span id="page-8-2"></span>1.2.1. Cocharacter datum. We denote by k an algebraic closure of  $\mathbf{F}_p$ . A cocharacter datum is a pair  $(G, \mu)$  consisting of a connected reductive  $\mathbf{F}_p$ -group G and a cocharacter  $\mu : \mathbf{G}_{m,k} \to G_k$ . We will denote by  $\varphi : G \to G$  the Frobenius homomorphism.

**Definition 1.2.1.** Let  $(G_1, \mu_1)$  and  $(G_2, \mu_2)$  be two cocharacter data. A morphism  $f: (G_1, \mu_1) \to (G_2, \mu_2)$  is a morphism of groups  $f: G_1 \to G_2$  defined over  $\mathbf{F}_p$ , such that  $\mu_2 = f \circ \mu_1$ .

We say that f is an embedding (resp. finite) if the underlying map  $f: G_1 \to G_2$  is an embedding (resp. finite). Cocharacter data form a category.

A cocharacter datum  $(G, \mu)$  gives rise to a pair of opposite parabolics  $(P^-, P^+)$  in  $G_k$  and a Levi subgroup  $L := P^- \cap P^+ = \text{Cent}(\mu)$ . The set  $P^+(k)$  consists of those elements  $g \in G(k)$  such that the limit

(1.2.1) 
$$\lim_{t \to 0} \mu(t)g\mu(t)^{-1}$$

exists, i.e such that the map  $\mathbf{G}_{m,k} \to G_k$ ,  $t \mapsto \mu(t)g\mu(t)^{-1}$  extends to a morphism of varieties  $\mathbf{A}_k^1 \to G_k$ . The Lie algebra of the parabolic  $P^-$  (resp.  $P^+$ ) is the sum of the non-positive (resp. non-negative) weight spaces of the action of  $\mathbf{G}_{m,k}$  on Lie(G) via  $\mu$ . We set  $P := P^-$ ,  $Q := (P^+)^{(p)}$  and  $M := L^{(p)}$ , so that M is a Levi subgroup of Q. We denote by U and V the unipotent radicals of P and Q, respectively. For a k-scheme S, one defines:

**Definition 1.2.2** ([88, Def. 1.4]). A G-zip of type  $\mu$  over S is a tuple  $\underline{I} = (I, I_P, I_Q, \iota)$  where I is a G-torsor over S,  $I_P \subset I$  is a P-torsor,  $I_Q \subset I$  is a Q-torsor, and  $\iota : (I_P)^{(p)}/U^{(p)} \to I_Q/V$  an isomorphism of M-torsors.

The category of G-zips over S is denoted by G-Zip $^{\mu}(S)$ . This gives rise to a fibered category G-Zip $^{\mu}$  over the category of k-schemes, which is a smooth algebraic stack of dimension 0 ([88, Th. 1.5]).

1.2.2. Representation as a quotient stack. The Frobenius restricts to a map  $\varphi: L \to M$ . The isomorphisms  $L \simeq P/U$  and  $M \simeq Q/V$  yield natural maps  $P \to L$  and  $Q \to M$  which we denote by  $x \mapsto \overline{x}$ . We define the zip group E as:

$$(1.2.2) E := \{(a,b) \in P \times Q \mid \varphi(\overline{a}) = \overline{b}\}.$$

The group  $G \times G$  acts on G by the rule  $(a,b) \cdot g := agb^{-1}$ . By restriction, the groups  $P \times Q$  and E also act on G. By loc. cit. Th. 1.5, there is an isomorphism of stacks:

$$(1.2.3) G-Zip^{\mu} \simeq [E \backslash G].$$

The association  $(G, \mu) \mapsto G\text{-}\mathrm{Zip}^{\mu}$  is functorial: Let  $f: (G_1, \mu_1) \to (G_2, \mu_2)$  be a morphism of cocharacter data and denote by  $E_1$  and  $E_2$  the associated zip groups. Using (1.2.1), one sees that f naturally induces a morphism of stacks  $[E_1 \setminus G_1] \to [E_2 \setminus G_2]$ , and hence a morphism  $G_1\text{-}\mathrm{Zip}^{\mu_1} \to G_2\text{-}\mathrm{Zip}^{\mu_2}$ .

1.2.3. Conjugation. For a cocharacter datum  $(G, \mu)$  and  $g \in G(k)$ , the pair  $(G, {}^g\mu)$  is again a cocharacter datum. Write P', Q', E' for the groups attached to  $(G, {}^g\mu)$  by §1.2.1. One has  $P' = {}^gP := gPg^{-1}$  and  $Q' = {}^{\varphi(g)}Q$ . The maps  $f: G \to G$ ,  $x \mapsto gx\varphi(g)^{-1}$  and  $\alpha: E \to E'$ ,  $(a, b) \mapsto (gag^{-1}, \varphi(g)b\varphi(g)^{-1})$  yield (§1.1) an isomorphism:

$$(1.2.4) G-\mathtt{Zip}^{\mu} \simeq G-\mathtt{Zip}^{g_{\mu}}.$$

It will be convenient to make the following assumption:

<span id="page-9-5"></span>**Assumption 1.2.3.** There exists a Borel pair (B,T) in G defined over  $\mathbf{F}_p$  such that  $B \subset P$ .

If  $(G, \mu)$  is an arbitrary cocharacter datum, we can find  $g \in G(k)$  such that  $(G, {}^g\mu)$  satisfies Assumption 1.2.3. By (1.2.4), it is harmless to assume that it is satisfied.

<span id="page-9-2"></span>1.3. Cocharacter data of Hodge type. Let  $(W, \psi)$  be a non-degenerate symplectic space over  $\mathbf{F}_p$  and  $GSp(W, \psi)$  the symplectic group of  $(W, \psi)$ . Consider a decomposition  $\mathcal{D}: W \otimes k = W_+ \oplus W_-$  where  $W_+$  and  $W_-$  are maximal isotropic subspaces. Define a cocharacter  $\mu_{\mathcal{D}}: \mathbf{G}_{m,k} \to GSp(W, \psi)$  by letting  $x \in \mathbf{G}_{m,k}$  act trivially on  $W_-$  and by multiplication by x on  $W_+$ . The groups attached to the cocharacter datum  $(GSp(W, \psi), \mu_{\mathcal{D}})$  are

$$P_{\mathcal{D}}^+ := \operatorname{Stab}_{GSp(W,\psi)}(W_+), \quad P_{\mathcal{D}} = P_{\mathcal{D}}^- := \operatorname{Stab}_{GSp(W,\psi)}(W_-), \quad Q_{\mathcal{D}} := \left(P_{\mathcal{D}}^+\right)^{(p)}, \quad L_{\mathcal{D}} := P_{\mathcal{D}}^+ \cap P_{\mathcal{D}}^-, \quad M_{\mathcal{D}} := (L_{\mathcal{D}})^{(p)}.$$
  
Since  $GSp(W,\psi)$  acts transitively on the set of all decompositions  $\mathcal{D}$  of  $W$  into maximal isotropic subspaces, all

Since  $GSp(W, \psi)$  acts transitively on the set of all decompositions  $\mathcal{D}$  of W into maximal isotropic subspaces, all cocharacter data obtained in this way are conjugate. We call  $(GSp(W, \psi), \mu_{\mathcal{D}})$  a Siegel-type cocharacter datum. Define the Hodge character  $\eta_{\omega}: L_{\mathcal{D}} \to \mathbf{G}_m$  by  $g \mapsto \det(g|W_+)^{-1}$ .

<span id="page-9-9"></span><span id="page-9-7"></span>**Definition 1.3.1.** Let  $(G, \mu)$  be a cocharacter datum.

- (a) We say that  $(G, \mu)$  is of Hodge-type if there exists a Siegel-type cocharacter datum  $(GSp(W, \psi), \mu_{\mathcal{D}})$  and an embedding  $\iota : (G, \mu) \to (GSp(W, \psi), \mu_{\mathcal{D}})$ .
- <span id="page-9-10"></span>(b) Given an embedding  $\iota$  as in (a), we denote again by  $\eta_{\omega}$  the restriction of  $\eta_{\omega}$  to L, and call it the Hodge character of  $(G, \mu)$  relative to  $\iota$ .

A posteriori, at least when  $\iota$  arises from an embedding of Shimura data, the dependence of  $\eta_{\omega}$  on  $\iota$  is very minimal, see Rmk. 4.1.1.

<span id="page-9-1"></span>1.4. **Stratification.** Let  $(G, \mu)$  be a cocharacter datum, and let P, Q, L, M, E be the attached groups, as defined in §1.2. We assume that there exists a Borel pair (B, T) satisfying Assumption 1.2.3. Denote by  $I, J \subset \Delta$  the type of P, Q respectively (as defined in §N.3.3).

For  $w \in W$ , choose a representative  $\dot{w} \in N_G(T)$ , such that  $(w_1w_2)^{\cdot} = \dot{w}_1\dot{w}_2$  whenever  $\ell(w_1w_2) = \ell(w_1) + \ell(w_2)$  (this is possible by choosing a Chevalley system, see [4], Exp. XXIII, §6). Define  $z := w_0w_{0,J}$ . Then one has:

(1.4.1) 
$${}^{z}B \subset Q \quad \text{and} \quad \varphi(B \cap L) = B \cap M = {}^{z}B \cap M.$$

Note that the triple  $({}^zB, T, \dot{z}^{-1})$  is a frame<sup>4</sup>, as defined in [87, Def. 3.6]. For  $w \in W$ , define  $G_w$  as the *E*-orbit of  $\dot{w}\dot{z}^{-1}$ . The *E*-orbits in *G* form a stratification of *G* by locally closed subsets. By Th. 7.5 and Th. 11.2 in [87], the map  $w \mapsto G_w$  restricts to two bijections:

$$(1.4.2) {W \rightarrow \{E \text{-orbits in } G\}}$$

$$(1.4.3) W^J \to \{E\text{-orbits in } G\}$$

Furthermore, for  $w \in {}^{I}W \cup W^{J}$ , one has

<span id="page-9-0"></span>
$$\dim(G_w) = \ell(w) + \dim(P).$$

<span id="page-9-6"></span><span id="page-9-4"></span>2. The stack of ZIP flags

<span id="page-9-3"></span>2.1. **Definition.** Fix a cocharacter datum  $(G, \mu)$  and a Borel pair (B, T) satisfying Assumption 1.2.3.

**Definition 2.1.1.** A G-zip flag of type  $\mu$  over a k-scheme S is a pair  $\hat{I} = (\underline{I}, J)$  where  $\underline{I} = (I, I_P, I_Q, \iota)$  is a G-zip of type  $\mu$  over S, and  $J \subset I_P$  is a B-torsor.

We denote by G-ZipFlag $^{\mu}(S)$  the category of G-zip flags over S. By similar arguments as for G-zips, we obtain a stack G-ZipFlag $^{\mu}$  over k, which we call the stack of G-zip flags of type  $\mu$ . This stack is (up to isomorphism) independent of the choice of the pair (B,T). There is a natural projection

$$\pi: G\text{-}\mathtt{ZipFlag}^{\mu} \to G\text{-}\mathtt{Zip}^{\mu}\,.$$

Define an action of  $E \times B$  on  $G \times P$  by

$$(2.1.2) ((a,b),c) \cdot (g,r) := (agb^{-1}, arc^{-1})$$

<span id="page-9-8"></span><sup>&</sup>lt;sup>4</sup>Note that contrary to *loc. cit.*, we use the convention  $B \subset P$ . This choice seems more natural from the point of view of Hodge theory and applications to characteristic 0. It slightly modifies the parametrization of the *E*-orbits, and other results are changed accordingly.

for all  $(a,b) \in E$ ,  $c \in B$  and  $(g,r) \in G \times P$ . The first projections  $G \times P \to G$  and  $E \times B \to E$  give rise to a map of quotient stacks  $[(E \times B) \setminus (G \times P)] \to [E \setminus G]$  as explained in §1.1, denote it again by  $\pi$ .

<span id="page-10-3"></span>**Theorem 2.1.2.** There is a commutative diagram, where the vertical maps are isomorphisms:

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

*Proof.* The proof is similar to that of [88, Prop. 3.11]. Let S be a scheme over k. To  $(g,r) \in (G \times P)(S)$ , we attach a "standard" G-zip flag  $\hat{I}_{(g,r)} = (\underline{I}_g, J_{(g,r)})$  over S. Let  $\underline{I}_g$  be the G-zip over S attached to g by Construction 3.4 in *loc. cit.* Define  $J_{(g,r)}$  as the image of  $B \times S \subset P \times S$  under left multiplication by r.

For elements  $(g,r), (g',r') \in (G \times P)(S)$ , define the transporter as

(2.1.3) 
$$\operatorname{Transp}((g,r),(g',r')) := \{ (\epsilon,b) \in (E \times B)(S) \mid (\epsilon,b) \cdot (g,r) = (g',r') \}.$$

This gives a category  $\mathcal{Y}$  fibered in groupoids over the category of k-schemes, such that for any k-scheme S,  $\mathcal{Y}(S)$  is the category whose objects are  $(G \times P)(S)$  and for  $(g,r), (g',r') \in (G \times P)(S)$ , the morphisms  $(g,r) \to (g',r')$  are given by Transp((g,r),(g',r')). This is a prestack, whose stackification is the quotient stack  $[(E \times B) \setminus (G \times P)]$  ([75, 3.4.3]).

We claim that  $(g,r)\mapsto \hat{I}_{(g,r)}$  is then a fully faithful functor  $\mathcal{Y}(S)\to G\text{-}\mathrm{ZipFlag}^\mu(S)$ , i.e. that there is a natural bijection between the set of morphisms  $\phi:\hat{I}_{(g,r)}\to\hat{I}_{(g',r')}$  and  $\mathrm{Transp}((g,r),(g'r'))$ . A morphism  $\phi:\hat{I}_{(g,r)}\to\hat{I}_{(g',r')}$  consists in particular of a morphism  $\varphi:\underline{I}_g\to\underline{I}_{g'}$ . By [88, Lem. 3.10], one can attach to  $\varphi$  a pair  $\epsilon=(p_+,p_-)\in E(S)$ , (using the notation of  $loc.\ cit.$ ). By compatibility, the map  $J_{(g,r)}\to J_{(g',r')}$  must be induced by left multiplication by  $p_+$ . Since  $J_{(g,r)}=r(B\times S)$  and  $J_{(g',r')}=r'(B\times S)$ , we have  $b:=r'^{-1}p_+r\in B(S)$ . We obtain a map  $\phi\mapsto (\epsilon,b)$ , and it is easy to check that it is a bijection.

To show that we obtain an isomorphism  $G\text{-}\mathsf{ZipFlag}^\mu\simeq[(E\times B)\backslash(G\times P)]$ , it remains to prove that any  $G\text{-}\mathsf{zip}$  flag is étale locally of the form  $\hat{I}_{(g,r)}$ . Let  $\hat{I}=(\underline{I},J)$  be a G-zip flag over a k-scheme S, where  $\underline{I}=(I,I_P,I_Q,\iota)$  is a G-zip. By [88, Lem. 3.5], the G-zip  $\underline{I}$  is étale locally of the form  $\underline{I}_g$ . Furthermore, we may choose an étale extension which trivializes the B-torsor J. Since  $J\subset I_P$  by definition, there exists an element  $r\in P(S)$  such that J is the image of  $B\times S$  under left multiplication by r. Thus  $\underline{I}=\hat{I}_{(g,r)}$ . This completes the proof of the isomorphism. From our construction, it is clear that the diagram commutes.

Define a subgroup  $E' \subset E$  by

$$(2.1.4) E' := E \cap (B \times G) = \{(a, b) \in E \mid a \in B\}.$$

It is easy to see that  $E' \subset B \times {}^zB$ . The map  $G \to G \times P$ ,  $g \mapsto (g,1)$  and the inclusion  $E' \subset E$  induce (§1.1) an isomorphism of quotient stacks

$$(2.1.5) [E'\backslash G] \simeq [(E\times B)\backslash (G\times P)].$$

Note that we can also view this stack as the quotient  $[E \setminus (G \times (P/B))]$ , where E acts on the scheme  $G \times (P/B)$  by

<span id="page-10-4"></span>
$$(2.1.6) (a,b) \cdot (g,rB) := (agb^{-1}, arB)$$

for all  $(a, b) \in E$  and  $rB \in P/B$ .

<span id="page-10-0"></span>2.2. **The Schubert stack.** Let  $B \times B$  act on G by  $(a,b) \cdot g := agb^{-1}$  for  $a,b \in B$  and  $g \in G$ . Define the Schubert stack as the quotient stack Sbt  $:= [(B \times B) \setminus G]$ . The group G is the disjoint union of the locally closed Schubert cells

$$(2.2.1) C_w := B\dot{w}B, \quad w \in W.$$

One has  $\dim(C_w) = \dim(B) + \ell(w)$ . Denote by  $\overline{C}_w$  the Zariski closure of  $C_w$  in G, endowed with the reduced structure. Note that  $\overline{C}_w$  is normal by [89, Th. 3]. For each  $w \in W$ , define substacks

(2.2.2) 
$$\operatorname{Sbt}_w := \left[ (B \times B) \backslash C_w \right] \quad \text{and} \quad \overline{\operatorname{Sbt}}_w := \left[ (B \times B) \backslash \overline{C}_w \right].$$

For each pair of characters  $(\lambda, \mu) \in X^*(T) \times X^*(T)$ , we have a line bundle  $\mathcal{L}_{Sbt}(\lambda, \mu)$  on Sbt (§N.4.1). For  $w \in W$ , let  $E_w$  denote the set of roots  $\alpha \in \Phi^+$  such that  $ws_{\alpha} < w$  and  $\ell(ws_{\alpha}) = \ell(w) - 1$ .

<span id="page-10-5"></span><span id="page-10-1"></span>**Theorem 2.2.1.** Let  $w \in W$ . One has the following:

- <span id="page-10-2"></span>(a)  $H^0$  (Sbt<sub>w</sub>,  $\mathcal{L}_{Sbt}(\lambda, \mu)$ )  $\neq 0 \iff \mu = -w^{-1}\lambda$ .
- (b)  $\dim_k H^0\left(\operatorname{Sbt}_w, \mathscr{L}_{\operatorname{Sbt}}(\lambda, -w^{-1}\lambda)\right) = 1.$

<span id="page-11-3"></span><span id="page-11-2"></span>(c) For any nonzero  $f \in H^0\left(\operatorname{Sbt}_w, \mathscr{L}_{\operatorname{Sbt}}(\lambda, -w^{-1}\lambda)\right)$  viewed as a rational function on  $\overline{C}_w$ , one has

(2.2.3) 
$$\operatorname{div}(f) = -\sum_{\alpha \in E_{w}} \langle \lambda, w\alpha^{\vee} \rangle \overline{C}_{ws_{\alpha}}.$$

*Proof.* We prove part (a). Assume  $f \in H^0\left(\mathrm{Sbt}_w, \mathscr{L}_{\mathrm{Sbt}}(\lambda, -w^{-1}\lambda)\right)$  is a nonzero element. Then f identifies with a regular function  $f: C_w \to \mathbf{A}^1$  (necessarily non-vanishing) satisfying the relation

$$(2.2.4) f(bxb') = \lambda(b)\mu(b')^{-1}f(x)$$

for all  $b, b' \in B$  and for all  $x \in C_w$ . In particular, for all  $t \in T$ , we have

<span id="page-11-4"></span>(2.2.5) 
$$f(\dot{w}t) = \mu(t)^{-1} f(\dot{w}) = \lambda(\dot{w}t\dot{w}^{-1}) f(\dot{w})$$

and the result follows (note that  $f(\dot{w}) \neq 0$ ). Part (b) follows by [62, Prop.1.18]. Part (c) is Chevalley's formula, see for example [12, §1, p. 654]. The minus sign in formula (2.2.3) accounts for our convention of positivity of roots (§N.3.2).

<span id="page-11-0"></span>2.3. Schubert stratification of G-ZipFlag $^{\mu}$ . Th. 2.1.2 and (2.1.5) give an isomorphism G-ZipFlag $^{\mu} \simeq [E' \backslash G]$ . It follows from (1.4.1) that  $E' \subset B \times {}^zB$ , so we have a natural projection  $\beta : [E' \backslash G] \to [(B \times {}^zB) \backslash G]$ . The map  $G \to G$ ,  $x \mapsto x\dot{z}$  induces an isomorphism of quotient stacks  $\alpha_z : [(B \times {}^zB) \backslash G] \xrightarrow{\simeq} [(B \times B) \backslash G] = \text{Sbt}$ . We obtain a smooth morphism of stacks

$$(2.3.1) \psi : G\text{-ZipFlag}^{\mu} \longrightarrow \mathrm{Sbt}, \quad \psi := \alpha_z \circ \beta.$$

For  $w \in W$ , define the flag stratum  $\mathcal{X}_w$  by  $\mathcal{X}_w := \psi^{-1}(\operatorname{Sbt}_w)$ , and the closed flag stratum  $\overline{\mathcal{X}}_w := \psi^{-1}(\overline{\operatorname{Sbt}}_w)$ , endowed with the reduced structure. The flag strata  $\mathcal{X}_w$  are smooth and locally closed. For  $w \in W$ , define a corresponding locally closed subvariety of  $G \times (P/B)$  by

$$(2.3.2) H_w := \{ (g, hB) \in G \times (P/B) \mid \widetilde{\psi}(g, h) \in C_w \}$$

where  $\widetilde{\psi}(g,h) := h^{-1}g\varphi(\overline{h})\dot{z}$ . The action of E on  $G \times (P/B)$  defined by (2.1.6) restricts to an E-action on  $H_w$  and one has an identification  $\mathcal{X}_w = [E \setminus H_w]$ .

# <span id="page-11-7"></span>Lemma 2.3.1.

- (a) The closed flag strata are normal and irreducible.
- <span id="page-11-8"></span>(b) The closed flag strata coincide with the closures of the flag strata.
- (c) For all  $w \in W$ , one has  $\dim(H_w) = \ell(w) + \dim(P)$ .

*Proof.* Since  $\overline{C}_w$  is normal and  $\psi$  is smooth,  $\overline{\mathcal{X}}_w$  is normal. The smooth morphism  $\widetilde{\psi}: G \times P \to G$  has all fibers isomorphic to P. Since  $C_w$  is irreducible and  $\widetilde{\psi}$  is open with irreducible fibers,  $\widetilde{\psi}^{-1}(C_w) \subset G \times P$  is irreducible. Hence  $H_w$  is irreducible. Finally, the last two assertions follow from the smoothness of  $\psi$ .

<span id="page-11-1"></span>2.4. **Minimal, cominimal strata.** Denote by  $\tilde{\pi}: G \times P/B \to G$  the first projection. The map  $\tilde{\pi}$  is *E*-equivariant for the action of *E* described in (2.1.6). We have a Cartesian square:

$$\begin{array}{ccc} G\times (P/B) & \stackrel{\tilde{\pi}}{----} & G \\ & & \downarrow & & \downarrow \\ [E\backslash (G\times (P/B))] & \stackrel{\pi}{----} & [E\backslash G] \end{array}$$

We introduce the map  $\tilde{\pi}$  to reduce some proofs to scheme theory. For  $w \in W$ , the irreducible locally closed subset  $\tilde{\pi}(H_w)$  is E-stable, so it is a union of E-orbits in G.

**Lemma 2.4.1.** For all  $w \in W$ ,  $\tilde{\pi}(H_w)$  is the union of E-orbits intersecting  $B\dot{w}\dot{z}^{-1}$ .

*Proof.* It is clear that  $\tilde{\pi}(H_w)$  is the union of E-orbits intersecting  $C_w \dot{z}^{-1}$ . One has  $C_w \dot{z}^{-1} = B(\dot{w}\dot{z}^{-1})^z B$ , so any such E-orbit intersects  $B\dot{w}\dot{z}^{-1}$  and conversely.

**Definition 2.4.2.** We call  ${}^{I}W$  (resp.  ${}^{W}{}^{J}$ ) the set of minimal (resp. cominimal) elements of W (§N.3.3).

Similarly, the flag stratum  $\mathcal{X}_w$  is called minimal (resp. cominimal) if w is minimal (resp. cominimal). Note that the longest minimal (resp. cominimal) element is  $w_{0,I}w_0$  (resp.  $w_0w_{0,J}$ ). The identity element e is both the shortest minimal and cominimal element.

<span id="page-11-9"></span><span id="page-11-5"></span>**Proposition 2.4.3.** Assume  $w \in W$  is either minimal or cominimal. Then:

- <span id="page-11-6"></span>(a) One has  $\tilde{\pi}(H_w) = G_w$  and  $\tilde{\pi}(\overline{H}_w) = \overline{G}_w$ .
- (b) The E-action on  $H_w$  is transitive.

- <span id="page-12-3"></span><span id="page-12-2"></span>(c) The preimage of  $G_w$  by the morphism  $\tilde{\pi}: \overline{H}_w \to \overline{G}_w$  is exactly  $H_w$ .
- (d) The map  $\tilde{\pi}: H_w \to G_w$  is finite.

Proof. The first part of (a) follows from [87, Th. 5.14] for w minimal and from [87, Th. 11.3] for w cominimal (with appropriate modifications due to our choice of frame  $({}^zB,T,\dot{z}^{-1})$ ). The second part follows from the properness of  $\tilde{\pi}$ . To show (b), note that  $\dim(H_w) = \dim(G_w)$  (Lemma 2.3.1(c) and (1.4.4)). Since the map  $\tilde{\pi}: H_w \to G_w$  is E-equivariant and  $G_w$  is an E-orbit, all its fibers are isomorphic. In particular, it is quasi-finite. Hence  $H_w$  contains finitely many E-orbits. But if  $Z \subset H_w$  is an E-orbit, it must map surjectively onto  $G_w$  (as  $G_w$  is an E-orbit). We deduce  $\dim(Z) \ge \dim(G_w) = \dim(H_w)$ . Hence any E-orbit of  $H_w$  has dimension  $\dim(H_w)$ , which clearly shows that  $H_w$  is an E-orbit. To prove (c), assume there exists  $y \in \overline{H}_w \setminus H_w$  such that  $\tilde{\pi}(y) \in G^w$ . Let  $w' \in W$  such that  $y \in H_{w'}$ . Then  $H_{w'} \subset \overline{H}_w$  and  $\pi(\overline{H}_{w'}) = \overline{G}_w$ . But this is impossible since  $\dim H_{w'} < \dim(H_w) = \dim(G_w)$ . Finally, (c) shows that  $\pi: H_w \to G_w$  is proper and quasi-finite, so it is finite, which proves (d).

Remark 2.4.4. It is proved in [60, Prop. 2.2.1(ii)] that the map  $\tilde{\pi}: H_w \to G_w$  is also étale.

<span id="page-12-0"></span>**Corollary 2.4.5.** For all E-orbits  $S \subset G$ , there is a unique minimal stratum H and a unique cominimal stratum H' such that  $\pi(H) = \pi(H') = S$ .

#### 3. Hasse invariants

#### <span id="page-12-1"></span>3.1. Line bundles.

- (1) Identify  $X^*(E) = X^*(P) = X^*(L)$  via the first projection  $E \to P$  and the inclusion  $L \subset P$ . By §N.4.1, a character  $\lambda \in X^*(L)$  gives rise to a line bundle  $\mathscr{V}(\lambda)$  on the quotient stack G-Zip<sup> $\mu$ </sup>  $\simeq [E \setminus G]$ .
- (2) Similarly, identify  $X^*(E') = X^*(B) = X^*(T)$  using the first projection  $E' \to B$  and the inclusion  $T \subset B$ . For a character  $\lambda \in X^*(T)$ , we obtain by §N.4.1 a line bundle  $\mathcal{L}(\lambda)$  on G-ZipFlag $^{\mu} \simeq [E' \setminus G]$ .

We first describe the relation between the line bundles  $\mathscr{L}_{\mathrm{Sbt}}(\lambda,\mu)$ ,  $\mathscr{L}(\lambda)$  (for  $\lambda,\mu\in X^*(T)$ ) and  $\mathscr{V}(\lambda)$  (for  $\lambda\in X^*(L)$ ) via the maps

$$G\text{-}\mathsf{ZipFlag}^{\mu} \xrightarrow{\psi} \mathsf{Sbt}$$

$$\downarrow^{\pi} \qquad \qquad G\text{-}\mathsf{Zip}^{\mu}$$

# <span id="page-12-8"></span><span id="page-12-5"></span><span id="page-12-4"></span>Lemma 3.1.1.

- (a) For all  $\lambda \in X^*(L)$ , one has  $\pi^* \mathscr{V}(\lambda) = \mathscr{L}(\lambda)$ .
- (b) For  $\lambda, \nu \in X^*(T)$ , one has

(3.1.1) 
$$\psi^* \mathcal{L}_{Sht}(\lambda, \nu) = \mathcal{L}(\lambda + p^{\sigma}(z\nu)),$$

where  $\sigma: k \to k$  denotes the inverse of the map  $x \mapsto x^p$ .

Proof. Part (a) is clear as  $\pi$  identifies with the natural projection  $[E'\backslash G] \to [E\backslash G]$ . Hence the pullback of  $\pi^*\mathcal{V}(\lambda)$  is the line bundle attached to the restriction of  $\lambda$  to  $E' \subset E$ , which is  $\mathcal{L}(\lambda)$ . To show part (b), recall (§2.3) that  $\psi$  identifies with the natural projection  $[E'\backslash G] \to [B \times {}^zB\backslash G]$  followed by the isomorphism  $\alpha_z : [B \times {}^zB\backslash G] \to [B \times B\backslash G]$ . Hence  $\psi^*\mathcal{L}_{Sbt}(\lambda,\nu)$  is the line bundle attached to the restriction of  $(\lambda,\nu)$  via the inclusion

$$E' \subset B \times {}^zB \simeq B \times B.$$

This restriction is given by  $(a,b) \mapsto \lambda(a)(z\nu)(b)$  for  $(a,b) \in E'$ . Since (a,b) satisfies  $\varphi(\overline{a}) = \overline{b}$  (where  $\overline{a}, \overline{b} \in T$  are the torus components of a,b), one has  $\lambda(a)(z\nu)(b) = \lambda(\overline{a})(\sigma(z\nu))^p(\overline{a})$ . This shows  $\psi^* \mathscr{L}_{Sbt}(\lambda,\nu) = \mathscr{L}(\lambda+p^{\sigma}(z\nu))$ .

In view of Th. 2.2.1(a), we now restrict ourselves to line bundles of the form  $\mathcal{L}_{Sbt}(\lambda, \nu)$  where  $\nu = -w^{-1}\lambda$  for  $w \in W$ . For  $w \in W$  and  $r \geq 1$ , define  $w^{(0)} = e$  and by induction  $w^{(r)} := {}^{\sigma}(w^{(r-1)}w)$  for all  $r \geq 1$ .

### <span id="page-12-6"></span>Lemma 3.1.2.

- (a) For all  $r, s \ge 1$  and  $w \in W$ , one has  $\sigma^s(w^{(r)})w^{(s)} = w^{(r+s)}$ .
- <span id="page-12-7"></span>(b) The set  $R := \{r \ge 0 \mid w^{(r)} = e\}$  is a non-trivial submonoid of  $\mathbb{Z}_{>0}$ .
- (c) If  $w^{(r)} = e$  for r > 1, then  $w^{(r-1)} = w^{-1}$ .

*Proof.* The first part follows from an easy induction. Hence R is stable under addition. Since W is finite, there exists  $r > s \ge 0$  such that  $w^{(r)} = w^{(s)}$ . By (a), we have  $w^{(r-s)} = e$ . Finally, (c) is clear from the definition.

By Lemma 3.1.1(b), we have  $\psi^* \mathscr{L}_{Sbt}(\lambda, -w^{-1}\lambda) = \mathscr{L}(\lambda - p \, \sigma(zw^{-1}\lambda))$ . In the next section, we will use Th. 2.2.1 to produce sections of certain line bundles  $\mathscr{L}_{Sbt}(\lambda, -w^{-1}\lambda)$  and then pull back these sections along the map  $\psi$ . Hence, we need to understand the map

(3.1.2) 
$$D_w: X^*(T) \to X^*(T), \quad \lambda \mapsto \lambda - p \ \sigma(zw^{-1}\lambda).$$

# <span id="page-13-3"></span><span id="page-13-2"></span><span id="page-13-1"></span>Lemma 3.1.3. Let $w \in W$ .

- (a) The map  $D_w$  induces a **Q**-linear automorphism of  $X^*(T)_{\mathbf{Q}}$ .
- (b) The inverse of  $D_w$  is given as follows: Let  $\chi \in X^*(T)$ . Fix  $r \geq 1$  such that  $(zw^{-1})^{(r)} = e$  and let  $m \geq 1$  such that  $\chi$  is defined over  $\mathbf{F}_{p^m}$ . Then one has  $D_w(\lambda) = \chi$  for the quasi-character

(3.1.3) 
$$\lambda = -\frac{1}{p^{rm} - 1} \sum_{i=0}^{rm-1} p^{i} (zw^{-1})^{(i)} (\sigma^{i} \chi)$$

Furthermore, the summand corresponding to i = rm - 1 is  $wz^{-1}(\sigma^{-1}\chi)$ .

*Proof.* Assertion (a) is clear, as  $D_w$  is the identity modulo p. To show (b), let  $\lambda \in X^*(T)_{\mathbb{Q}}$  be the unique quasi-character such that  $D_w(\lambda) = \chi$ . Then one shows by induction on  $j \geq 1$  that

(3.1.4) 
$$\sum_{i=0}^{j-1} p^{i}(zw^{-1})^{(i)}(\sigma^{i}\chi) = \lambda - p^{j}(zw^{-1})^{(j)}(\sigma^{j}\lambda)$$

<span id="page-13-0"></span>For j = rm, we have  $(zw^{-1})^{(j)} = e$  and  $\sigma^j \lambda = \lambda$ , and the result follows.

3.2. Group-theoretical Hasse invariants. By [62, Prop. 1.18], the space  $H^0([E \setminus G_w], \mathcal{V}(\chi))$  is at most 1-dimensional for all  $\chi \in X^*(L)$  and all  $w \in {}^IW$ . Moreover, [61, Th. 3.1] shows that there exists  $N \geq 1$  such that for all  $w \in {}^IW$  and all  $\chi \in X^*(L)$ , the space  $H^0([E \setminus G_w], \mathcal{V}(N\chi))$  has dimension 1 over k. Fix the following:

- $r \ge 1$  such that  $w^{(r)} = e$  for all  $w \in W$ .
- $m \ge 1$  such that T splits over  $\mathbf{F}_{p^m}$ .
- $N \ge 1$  such that  $\dim_k H^0([E \backslash G_w], \mathscr{V}(N\chi)) = 1$  for all  $w \in {}^I W$  and  $\chi \in X^*(L)$ .
- For  $w \in {}^{I}W$  and  $\chi \in X^{*}(L)$ , let  $h_{w,\chi}$  be a nonzero element of the line  $H^{0}([E \backslash G_{w}], \mathscr{V}(N\chi))$ .
- Similarly, for all  $w \in W$  and  $\lambda \in X^*(T)$ , let  $f_{w,\lambda}$  be a nonzero element of the line  $H^0(\operatorname{Sbt}_w, \mathscr{L}_{\operatorname{Sbt}}(\lambda, -w^{-1}\lambda))$  (see Th. 2.2.1).
- For  $w \in W$  and  $\lambda \in X^*(T)$ , set  $f'_{w,\lambda} := \psi^*(f_{w,\lambda}) \in H^0(\mathcal{X}_w, \psi^*\mathcal{L}_{Sbt})$ .

<span id="page-13-6"></span><span id="page-13-5"></span>**Proposition 3.2.1.** Let  $w \in {}^{I}W \cup W^{J}$  and  $\chi \in X^{*}(L)$ . The following assertions are equivalent:

- <span id="page-13-4"></span>(a) There exists  $d \geq 1$  such that  $h_{w,\chi}^d$  extends to  $[E \setminus \overline{G}_w]$  with non-vanishing locus  $[E \setminus G_w]$ .
- (b) For all  $\alpha \in E_w$ , one has:

(3.2.1) 
$$\sum_{i=0}^{rm-1} \langle (zw^{-1})^{(i)}(\sigma^i \chi), w\alpha^{\vee} \rangle p^i > 0.$$

Proof. Let  $\lambda \in X^*(T)_{\mathbf{Q}}$  given by (3.1.3) of Lemma 3.1.3. Put  $C := p^{rm} - 1$ , so that  $C\lambda \in X^*(T)$ . It satisfies  $\psi^*(\mathscr{L}_{\mathrm{Sbt}}(C\lambda, -w^{-1}C\lambda)) = \mathscr{L}(C\chi)$ , so we have  $f'_{w,C\lambda} \in H^0(\mathcal{X}_w, \mathscr{L}(C\chi))$ . Equation (3.2.1) is equivalent to  $\langle \lambda, w\alpha^\vee \rangle > 0$ . Hence by Th. 2.2.1 (c), Property (b) is satisfied if and only if  $f_{w,C\lambda}$  extends to  $\overline{\mathrm{Sbt}}_w$  with non-vanishing locus  $\mathrm{Sbt}_w$ . Equivalently, it holds if and only if  $f'_{w,C\lambda}$  extends to  $\overline{\mathcal{X}}_w$  with non-vanishing locus  $\mathcal{X}_w$  (by smoothness of  $\psi$ ). By Prop. 2.4.3 (a) combined with [62, Prop. 1.18], we have  $\dim_k H^0(\mathcal{X}_w, \mathscr{L}(dC\chi)) \leq 1$ , so  $\pi^*(h_{w,\chi})^{dC} = (f'_{w,C\lambda})^d$  up to a nonzero scalar. Since  $\overline{\mathcal{X}}_w$  is normal,  $f'_{w,C\lambda}$  extends to  $\overline{\mathcal{X}}_w$  with non-vanishing locus  $\mathcal{X}_w$  if and only if some power of it does, so we deduce that (b) is equivalent to the fact that  $\pi^*(h_{w,\chi})$  extends to  $\overline{\mathcal{X}}_w$  with non-vanishing locus  $\mathcal{X}_w$ . In particular, (a) implies (b). The converse follows from the next lemma.

**Lemma 3.2.2.** Let  $f: X \to Y$  a proper surjective morphism of integral schemes of finite-type over k. Let  $\mathscr L$  be a line bundle on Y. Let  $U \subset Y$  be a normal open subset and  $h \in \mathscr L(U)$  a non-vanishing section over U. Assume that the section  $f^*(h) \in H^0(f^{-1}(U), f^*\mathscr L)$  extends to X with non-vanishing locus  $f^{-1}(U)$ . Then there exists  $d \ge 1$  such that  $h^d$  extends to Y, with non-vanishing locus U.

*Proof.* We will reduce to the case when X, Y are affine,  $\mathcal{L} = \mathcal{O}_Y$  and f is the normalization of Y.

First, after replacing X by its normalization  $\widetilde{X} \to X$ , we may assume that X is normal. In this case, the map f factors through the normalization  $\pi: \widetilde{Y} \to Y$ . Hence there exists  $f': X \to \widetilde{Y}$  such that  $f = \pi \circ f'$ . The map f' is again proper, so it is surjective. Write  $\operatorname{div}(\pi^*(h)) = \sum_{i=1}^r n_i Z_i$  where  $n_i \in \mathbf{Z}$  and  $Z_i \subset \widetilde{Y} \setminus \pi^{-1}(U)$  are codimension one irreducible subvarieties. If  $n_i < 0$  for some i, then  $f^*(h)$  would have a pole (because f' is surjective), hence  $\pi^*(h)$  extends to  $\widetilde{Y}$  with non-vanishing locus  $\pi^{-1}(U)$ . Thus we may assume  $X = \widetilde{Y}$ . Also, we may reduce to the case  $Y = \operatorname{Spec}(A)$ ,  $X = \operatorname{Spec}(B)$  for an integral domain A and B its integral closure, and  $\mathscr{L} = \mathcal{O}_Y$ . Write  $I \subset A$  for the ideal sheaf of  $Z := X \setminus U$ , endowed with the reduced structure. Hence  $U = D(I) = \{\mathfrak{p} \in \operatorname{Spec} A, I \not\subseteq \mathfrak{p}\}$ . Replacing h by a power, we may further assume that  $h \in IB$ .

We claim that for any  $s \in IB$ , there exists  $n \ge 1$  such that  $s^{p^n}$  lies in A. Since k has characteristic p, we may assume that s = gx for some  $g \in I$  and  $x \in B$ , because the  $p^n$  power map is additive. Since U is normal,

 $f^{-1}(U) \to U$  is an isomorphism, so the map  $A_g \to B_g$  is an isomorphism (since  $D(g) \subset U$ ). Hence we can find  $m \geq 1$  such that  $g^m x \in A$ . Since A[x] is generated as an A-module by  $1, x, ..., x^r$  for some  $r \geq 1$ , it follows that we can find m such that  $g^m x^d \in A$  for all  $d \geq 0$ . Increasing m, we may assume that it is a power of p, say  $m = p^n$ . Taking d = m gives  $g^m x^m \in A$ , which proves the claim. We have showed that there exists  $d \geq 1$  such that  $h^d \in A$ . If  $V \subset Y$  is the non-vanishing locus of  $h^d$ , then  $f^{-1}(V) = f^{-1}(U)$ , hence U = V.

Now we come to the main theorem of this part, the existence of group-theoretical Hasse invariants (Th. I.1.1):

<span id="page-14-0"></span>**Theorem 3.2.3.** If  $\chi \in X^*(L)$  is (p, L)-admissible (Def. N.5.3(d)), then there exists  $d \geq 1$  such that for all  $w \in W^J$ , the section  $h_{w,\chi}^d$  extends to  $[E \backslash \overline{G}_w]$  with non-vanishing locus  $[E \backslash G_w]$ .

*Proof.* We show Property (b) of Prop. 3.2.1. This expression has the form  $\sum_{i=0}^{rm-1} \langle \chi, w_i \alpha^{\vee} \rangle p^i$  for some elements  $w_i \in W$ . Using the inequality

$$\sum_{i=0}^{rm-2} (p-1)p^i = p^{rm-1} - 1 < p^{rm-1}$$

and the fact that  $\chi$  is orbitally *p*-close, it suffices to check that the leading term  $p^{rm-1}\langle \chi, w_{rm-1}\alpha^{\vee} \rangle$  is positive. By the second part of Lemma 3.1.3, this term is

$$p^{rm-1}\langle wz^{-1}(\sigma^{-1}\chi), w\alpha^{\vee}\rangle = p^{rm-1}\langle \chi, \sigma(z\alpha^{\vee})\rangle.$$

Since  $w \in W^J$  and  $\alpha \in E_w$ , we must have  $s_{\alpha} \notin W_J$  by definition of  $W^J$ . The parabolic subgroup  $z^{-1}Q$  contains B and has type J and Levi subgroup  $z^{-1}M$ . It follows that  $\alpha$  is not a root of  $z^{-1}M$ . By (N.3.3),  $w_{0,J}\alpha$  is a positive root, hence  $z\alpha = w_0w_{0,J}\alpha$  is negative. We deduce  $z\alpha \in \Phi^- \setminus \Phi(M,T)$ , and finally

$$(3.2.2) \sigma(z\alpha) \in \Phi^- \setminus \Phi(L,T)$$

Since  $\chi$  is ample, we obtain  $\langle \chi, \sigma(z\alpha^{\vee}) \rangle > 0$ , which terminates the proof.

Remark 3.2.4. When  $G_w$  is the open stratum of G, Th. 3.2.3 was proved in [62] for  $\chi$  any L-ample character. The assumption that  $\chi$  is orbitally p-close is superfluous in this case.

**Lemma 3.2.5.** Let  $(G, \mu) = (GSp(W, \psi), \mu_{\mathcal{D}})$  be a cocharacter datum of Siegel-type (§1.3). The Hodge character  $\eta_{\omega}$  is L-ample and quasi-constant. In particular,  $\eta_{\omega}$  is (p, L)-admissible for all p (Def. N.5.3).

*Proof.* We prove first that  $\eta_{\omega}$  is L-ample. Choose a Borel subgroup  $B \subset P_{\mathcal{D}}$  and a maximal torus  $T \subset B$ . Since  $P_{\mathcal{D}}$  is a maximal parabolic subgroup, the set  $\Delta \setminus I$  consists of a single simple root  $\alpha$ . It is then easy to see from the definition of  $\eta_{\omega}$  that  $\langle \eta_{\omega}, \alpha^{\vee} \rangle = -1$ , which shows that  $\eta_{\omega}$  is L-ample.

We now show that  $\eta_{\omega}$  is quasi-constant. For any positive root  $\beta$  not in  $\Phi(L_{\mathcal{D}}, T)$ , one has  $|\langle \eta_{\omega}, \beta^{\vee} \rangle| = 1$  if  $\beta$  is a long root, and  $|\langle \eta_{\omega}, \beta^{\vee} \rangle| = 2$  if  $\beta$  is a short root. Since  $W \rtimes \operatorname{Gal}(k/\mathbf{F}_p)$  preserves the length of roots, we deduce that  $\operatorname{Orb}(\eta_{\omega}, \beta^{\vee}) = \{0, 1\}$  in all cases, which proves the result.

<span id="page-14-3"></span>Corollary 3.2.6. Let  $(G, \mu) = (GSp(W, \psi), \mu_{\mathcal{D}})$  be a cocharacter datum of Siegel-type. There exists  $d \ge 1$  such that for all  $w \in W^J$ , there exists a section  $h_w \in H^0([E \setminus \overline{G}_w], \omega^d)$  with non-vanishing locus  $[E \setminus G_w]$ .

We will explain later in §4.3 that  $\eta_{\omega}$  is (p, L)-admissible for all character data  $(G, \mu)$  of Hodge-type coming from a Shimura datum of Hodge-type. In [36], we have shown the analogue of Cor. 3.2.6 for any  $(G, \mu)$  of Hodge-type (not necessarily attached to a Shimura datum), and also for more general  $(G, \mu)$  (those of maximal type).

<span id="page-14-2"></span>3.3. Functoriality of zip strata. Let  $f:(G_1,\mu_1)\to (G_2,\mu_2)$  be a finite morphism of cocharacter data and  $\widetilde{f}:G_1\text{-}\operatorname{Zip}^{\mu_1}\to G_2\text{-}\operatorname{Zip}^{\mu_2}$  the induced map of stacks. The underlying topological spaces of  $G_1\text{-}\operatorname{Zip}^{\mu_1}$  and  $G_2\text{-}\operatorname{Zip}^{\mu_2}$  are finite, and the map  $\widetilde{f}$  is continuous.

We denote by  $P_1, L_1, E_1$  (resp.  $P_2, L_2, E_2$ ) the subgroups attached to  $\mu_1$  (resp.  $\mu_2$ ), as in §1.2.1. Let  $f^*: X^*(L_2) \to X^*(L_1)$  denote the induced morphism.

<span id="page-14-1"></span>**Theorem 3.3.1** (Discrete Fibers). Assume there exists a  $(p, L_2)$ -admissible character  $\chi \in X^*(L_2)$ , such that  $f^*\chi$  is orbitally p-close. Then the map  $\widetilde{f}$  has discrete fibers on the underlying topological spaces.

Proof. We claim first that  $f: G_1 \to G_2$  induces a finite morphism  $G_1/P_1 \to G_2/P_2$ . It suffices to show that this morphism is quasi-finite. By definition, one has  $P_1 \subset f^{-1}(P_2)$ , so it follows that  $H := f^{-1}(P_2)_{\text{red}}$  is a parabolic subgroup of  $G_1$  containing  $P_1$ . Using (1.2.1), we find also  $R_u(P_1) \subset f^{-1}(R_u(P_2))$  hence  $R_u(P_1) \subset f^{-1}(R_u(P_2))_{\text{red}} = R_u(H)$ . It follows that  $H = P_1$ , so the map  $G_1/P_1 \to G_2/P_2$  is injective on k-points.

In particular, Rmk. N.5.2 shows that the  $L_2$ -ample character  $\chi$  restricts to an  $L_1$ -ample character of  $X^*(L_1)$  which we denote again by  $\chi$ . Hence we may apply Th. 3.2.3 to  $\chi$  on both stacks  $G_1$ -Zip<sup> $\mu_1$ </sup> and  $G_2$ -Zip<sup> $\mu_2$ </sup>. If the statement were false, there would exist two  $E_1$ -orbits  $C_1$  and  $C_1'$  in  $G_1$  such that  $C_1' \subset \overline{C}_1$  and  $f(C_1) \subset C_2$ ,  $f(C_1') \subset C_2$  for some  $E_2$ -orbit  $C_2 \subset G_2$ . There exists an integer  $N \geq 1$  and a section  $h_i \in H^0(\overline{C}_i, \mathcal{V}(\chi)^N)$  (for

i=1,2), whose non-vanishing locus is  $C_i$ . Since  $\dim_k H^0(C_1, \mathscr{V}(\chi)^N)=1$ , one has  $f^*(h_2)=h_1$  (up to nonzero scalar). This contradicts the fact that the non-vanishing locus of  $h_1$  is  $C_1$ .

We will see that Th. 3.3.1 applies in the context of embeddings of Shimura data of Hodge-type (Cor. 4.3.7). As explained in Rmk. I.1.3 of the introduction, the statement remains true without the cumbersome assumption that there exists a  $(p, L_2)$ -admissible character  $\chi \in X^*(L_2)$ , such that  $f^*\chi$  is orbitally p-close. This is proved in [36, Th. 2]. The trick is to replace the Frobenius  $\varphi$  by higher powers of  $\varphi$ .

<span id="page-15-0"></span>3.4. The cone of global sections. We will construct nonzero global sections for certain line bundles  $\mathcal{L}(\lambda)$ . Actually, not all line bundles  $\mathcal{L}(\lambda)$  admit nonzero global sections. In general, it is hard to characterize the set of  $\lambda \in X^*(T)$  which do.

In this section,  $(G, \mu)$  is a cocharacter datum of Hodge-type. Recall that we defined a map  $D_w: X^*(T) \to X^*(T)$  in (3.1.2). Here, we consider the special case  $w = w_0$ . Hence,  $D_{w_0}$  is defined by

$$(3.4.1) D_{w_0}: X^*(T) \to X^*(T), \quad \lambda \mapsto \lambda - p(\sigma(zw_0\lambda)).$$

By Th. 2.2.1(a), the line bundles of the form  $\mathcal{L}_{Sbt}(\lambda, -w_0\lambda)$  are the ones admitting nonzero sections on the open stratum  $Sbt_{w_0} \subset Sbt$ . Among these line bundles, those admitting nonzero sections on Sbt are given by the following lemma:

#### Lemma 3.4.1. One has

<span id="page-15-2"></span>
$$H^0(\operatorname{Sbt}, \mathscr{L}_{\operatorname{Sbt}}(\lambda, -w_0\lambda)) \neq 0 \iff -\lambda \in X_+^*(T).$$

Proof. By Th. 2.2.1(c), the divisor of any nonzero element  $f \in H^0(\operatorname{Sbt}_{w_0}, \mathscr{L}_{\operatorname{Sbt}}(\lambda, -w_0\lambda))$  (viewed as a rational function on G) is a sum of  $B \times B$ -orbits in G with multiplicities  $\langle \lambda, w_0 \alpha^{\vee} \rangle$  with  $\alpha \in E_{w_0}$ . One has  $E_{w_0} = \Delta$ , hence f extends to G if and only if  $\langle \lambda, w_0 \alpha^{\vee} \rangle \geq 0$  for all positive roots  $\alpha$ . Since  $w_0$  maps bijectively the positive roots to the negative ones, this is equivalent to  $-\lambda \in X_+^*(T)$ .

This justifies the introduction of the following subset: Define  $\mathcal{C}_{w_0} \subset X^*(T)$  by:

$$\mathcal{C}_{w_0} := \{ D_{w_0}(\lambda) \mid -\lambda \in X_+^*(T) \}.$$

By Lemma 3.1.1(b), one has

<span id="page-15-3"></span><span id="page-15-1"></span>
$$\psi^*(\mathscr{L}_{\mathrm{Sbt}}(\lambda, -w_0\lambda)) = \mathscr{L}(D_{w_0}(\lambda)).$$

For any  $\lambda \in -X_+^*(T)$ , the pull back by  $\psi : G\text{-}\mathsf{ZipFlag}^{\mu} \to \mathsf{Sbt}$  of a nonzero global section of  $\mathscr{L}_{\mathsf{Sbt}}(\lambda, -w_0\lambda)$  over  $\mathsf{Sbt}$  gives a nonzero global section of  $\mathscr{L}(D_{w_0}(\lambda))$  over  $G\text{-}\mathsf{ZipFlag}^{\mu}$ . Hence any  $\chi \in \mathcal{C}_{w_0}$  satisfies that  $\mathscr{L}(\chi)$  admits a nonzero global section.

**Lemma 3.4.2.** The subset  $C_{w_0} \subset X^*(T)$  is a cone of maximal rank (i.e  $\operatorname{Span}_{\mathbf{Q}}(C_{w_0}) = X^*(T)_{\mathbf{Q}}$ ).

*Proof.* Since  $D_{w_0}$  is linear and  $-X_+^*(T)$  is a cone, it is clear that  $C_{w_0}$  is a cone. It is of maximal rank because  $X_+^*(T)$  is of maximal rank and  $D_{w_0}$  induces an automorphism of  $X^*(T)_{\mathbf{Q}}$  (Lemma 3.1.3(a)).

We assumed that the cocharacter datum  $(G, \mu)$  is of Hodge-type. Choose a symplectic embedding  $\iota: (G, \mu) \to (GSp(W, \psi), \mu_{\mathcal{D}})$ . This embedding yields a Hodge character  $\eta_{\omega} \in X^*(L)$  (Def. 1.3.1(b)). Define a second cone  $\mathcal{C} \subset X^*(T)$  as follows: First, fix an integer  $N \geq 1$  such that  $H^0([E \setminus G_{w_0}], \omega^N) \neq 0$  (as we did in §3.2). Then put:

$$\mathcal{C} := \mathbf{N}(N\eta_{\omega}) + \mathcal{C}_{w_0}$$

the cone generated by  $N\eta_{\omega}$  and  $\mathcal{C}_{w_0}$ . We introduce this cone because of the following proposition:

**Proposition 3.4.3.** For any  $\chi \in \mathcal{C}$ , there exists a nonzero global section  $h_{\chi} \in H^0(G\operatorname{-ZipFlag}^{\mu}, \mathcal{L}(\chi))$ .

*Proof.* We already showed this for  $\chi \in \mathcal{C}_{w_0}$ . Hence it suffices to show it for  $N\eta_{\omega}$ , i.e that  $\omega^N$  admits a nonzero global section. The embedding  $\iota$  induces a map of stacks  $G\text{-}\operatorname{Zip}^{\mu} \to GSp(2g)\text{-}\operatorname{Zip}^{\mu_{\mathcal{D}}}$ . The image of the unique open stratum of  $G\text{-}\operatorname{Zip}^{\mu}$  maps to some stratum  $S \subset GSp(2g)\text{-}\operatorname{Zip}^{\mu_{\mathcal{D}}}$  (not necessarily open). In particular, the image of  $G\text{-}\operatorname{Zip}^{\mu}$  is contained in  $\overline{S}$ , by continuity.

By Cor. 3.2.6, there exists a section  $h_S \in H^0(\overline{S}, \omega^d)$  (some  $d \geq 1$ ) with non-vanishing locus S. The pull-back of  $h_S$  to G-Zip $^\mu$  is then nonzero. This gives a nonzero global section h of  $\omega^d$  over G-Zip $^\mu$ . Now we claim that  $\omega^N$  also admits a section. For this, let  $f \in H^0([E \backslash G_{w_0}], \omega^N) \neq 0$  be nonzero. Then  $f^d$  and  $h^N$  are both sections of  $\omega^{Nd}$  over the open stratum  $[E \backslash G_{w_0}]$ , hence coincide up to a nonzero scalar, as  $\dim_k H^0([E \backslash G_{w_0}], \omega^{Nd}) = 1$ . We deduce that  $f^d$  (viewed as a rational function on G) extends to G. Since G is normal, f extends to G, which shows that  $\omega^N$  also has a nonzero global section over G-Zip $^\mu$ , as claimed. This terminates the proof.

If G is split over  $\mathbf{F}_p$  then one has  $N\eta_{\omega} \in \mathcal{C}_{w_0}$ , hence  $\mathcal{C} = \mathcal{C}_{w_0}$ , but we don't know if this remains true in general. To summarize, the above results provide nonzero global sections for  $\mathcal{L}(\chi)$  for  $\chi$  in a cone  $\mathcal{C} \subset X^*(T)$  of maximal rank, which we tried to make as large as possible. This will be used later in Th. 8.2.1(b).

#### <span id="page-16-0"></span>Part 2. Strata Hasse invariants of Shimura varieties

In Part 2, we apply the general results of Part 1 on group-theoretical Hasse invariants to Hodge-type Shimura varieties and subschemes related to their EO stratification. §4 concerns Hodge-type Shimura varieties. §4.1 introduces notation for integral models of Hodge-type Shimura varieties, to be used throughout Parts 2-3. §4.3 deduces the corollaries of §1.1 about Hasse invariants for the EO stratification.

In §6, we study the extension of the EO stratification to compactifications. In §6.2, we show that the universal G-Zip over  $S_{\mathcal{K}}$  admits an extension to a G-Zip over a toroidal compactification  $S_{\mathcal{K}}^{\Sigma}$ . This is applied to the minimal compactification in §6.3 where we prove the affineness statement of Cor. I.2.6. The notion of length stratification is introduced in §5.2 for a general scheme  $X \to G$ -Zip<sup> $\mu$ </sup>. In §6.4, the general considerations of §5.2 are applied to  $S_{\mathcal{K}}^{\Sigma}$ . The length stratification will play a key role in §8, in the proof of the factorization theorem for Hecke algebras (Th. I.3.1, Th. 8.2.1).

The last two sections of Part 2 record auxiliary results that will be used in Part 3. In §7, we note how vanishing theorems for  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  generalize to strata. §5 describes results about lifting and gluing powers of EO Hasse invariants. A key technical point in our arguments is working with the Cohen-Macaulay property to avoid embedded components.

#### 4. Shimura varieties of Hodge type

### <span id="page-16-3"></span><span id="page-16-1"></span>4.1. Background.

<span id="page-16-5"></span>4.1.1. Rational theory. Let  $(\mathbf{G}, \mathbf{X})$  be a Shimura datum [24, 2.1.1]. Write  $E = E(\mathbf{G}, \mathbf{X})$  for the reflex field of  $(\mathbf{G}, \mathbf{X})$  and  $\mathcal{O}_E$  for its ring of integers. Given an open compact subgroup  $\mathcal{K} \subset \mathbf{G}(\mathbf{A}_f)$ , write  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}}$  for Deligne's canonical model at level  $\mathcal{K}$  over E (see loc. cit.). Every inclusion  $\mathcal{K}' \subset \mathcal{K}$  induces a finite étale projection  $\pi_{\mathcal{K}'/\mathcal{K}} : \mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}'} \to \mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}}$ . Let  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})$  be the resulting tower of E-schemes<sup>5</sup>. It admits a right  $\mathbf{G}(\mathbf{A}_f)$ -action given by a compatible system of isomorphisms  $g : \mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}} \xrightarrow{\sim} \mathrm{Sh}(\mathbf{G}, \mathbf{X})_{g^{-1}\mathcal{K}g}$  for  $g \in \mathbf{G}(\mathbf{A}_f)$ . Define d to be the common dimension of all the  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}}$ .

4.1.2. Symplectic embedding. Let  $g \ge 1$  and let  $(V, \psi)$  be a 2g-dimensional, non-degenerate symplectic space over  $\mathbf{Q}$ . Write  $GSp(2g) = GSp(V, \psi)$  for the group of symplectic similitudes of  $(V, \psi)$ . Write  $\mathbf{X}_g$  for the double Siegel half-space [24, 1.3.1]. The pair  $(GSp(2g), \mathbf{X}_g)$  is the Siegel Shimura datum; it has reflex field  $\mathbf{Q}$ . Recall that  $(\mathbf{G}, \mathbf{X})$  is of Hodge type if there exists an embedding of Shimura data  $\varphi : (\mathbf{G}, \mathbf{X}) \hookrightarrow (GSp(2g), \mathbf{X}_g)$  for some  $g \ge 1$ . Henceforth, assume  $(\mathbf{G}, \mathbf{X})$  is of Hodge-type.

<span id="page-16-2"></span>4.1.3. Integral model. For the rest of this paper, fix a prime  $p \notin \text{Ram}(\mathbf{G}) \cup \{2\}$  (§N.3.6). Let  $\mathcal{G}$  be a reductive,  $\mathbf{Z}_{(p)}$ -model of  $\mathbf{G}$  and  $\mathcal{K}_p := \mathcal{G}(\mathbf{Z}_p) \subset \mathbf{G}(\mathbf{Q}_p)$  the associated hyperspecial subgroup.

Let  $\mathfrak{p}$  be a prime of E above p and let  $\mathcal{O}_{E,\mathfrak{p}}$  be the localization of  $\mathcal{O}_E$  at  $\mathfrak{p}$ . Write  $E_{\mathfrak{p}}$  for the completion of E at  $\mathfrak{p}$  and  $\mathcal{O}_{\mathfrak{p}}$  for its ring of integers. By Vasiu [103, Th. 0] and Kisin [58, Th. 1], as  $\mathcal{K}^p$  ranges over sufficiently small open compact subgroups of  $G(\mathbf{A}_f^p)$ , the sub-tower of E-schemes  $(\operatorname{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}^p\mathcal{K}_p})_{\mathcal{K}^p}$  admits an integral canonical model  $(\mathscr{S}_{\mathcal{K}^p\mathcal{K}_p})_{\mathcal{K}^p}$  with  $\mathbf{G}(\mathbf{A}_f^p)$ -action over  $\mathcal{O}_{E,\mathfrak{p}}$  in the sense of Milne [80].

For short, say that  $\mathcal{K} \subset \mathbf{G}(\mathbf{A}_f)$  is a p-hyperspecial level when  $\mathcal{K}$  is an open, compact subgroup of  $\mathbf{G}(\mathbf{A}_f^p)$  of the form  $\mathcal{K} = \mathcal{K}^p \mathcal{K}_p$  with  $\mathcal{K}_p \subset \mathbf{G}(\mathbf{Q}_p)$  hyperspecial and  $\mathcal{K}^p \subset \mathbf{G}(\mathbf{A}_f^p)$ . The projections between levels  $\pi_{\mathcal{K}'/\mathcal{K}} : \mathscr{S}_{\mathcal{K}'} \to \mathscr{S}_{\mathcal{K}}$  and the right  $\mathbf{G}(\mathbf{A}_f^p)$ -action  $g : \mathscr{S}_{\mathcal{K}} \to \mathscr{S}_{g^{-1}\mathcal{K}g}$  are denoted the same way as for the canonical model (§4.1.1).

<span id="page-16-6"></span>4.1.4. Integral symplectic embedding. Let  $\varphi: (\mathbf{G}, \mathbf{X}) \hookrightarrow (GSp(2g), \mathbf{X}_g)$  be an embedding of Shimura data. By [58, 2.3.1], there is a  $\mathbf{Z}_{(p)}$ -lattice  $\Lambda \subset V$  such that  $\mathbf{G} \to GL(V)$  extends to a closed embedding of  $\mathbf{Z}_{(p)}$ -group schemes  $\mathcal{G} \to GL(\Lambda)$ . By Zarhin's trick, we may assume that  $\psi: \Lambda \times \Lambda \to \mathbf{Q}$  is a perfect pairing with values in  $\mathbf{Z}_{(p)}$  and that  $\varphi$  extends to an embedding of  $\mathbf{Z}_{(p)}$ -group schemes

$$(4.1.1) \varphi: \mathcal{G} \to GSp(\Lambda, \psi).$$

Fix such  $(\varphi, \Lambda)$  for the rest of the paper. Let  $\tilde{\mathcal{K}}_p := GSp(\Lambda, \psi)(\mathbf{Z}_p)$ , a hyperspecial subgroup of  $GSp(V, \psi)(\mathbf{Q}_p)$ . For  $\tilde{\mathcal{K}} = \tilde{\mathcal{K}}_p \tilde{\mathcal{K}}^p$ , write  $\mathscr{S}_{q,\tilde{\mathcal{K}}}$  for the integral canonical model of  $Sh(GSp(2g), \mathbf{X}_g)_{\tilde{\mathcal{K}}}$  over  $\mathbf{Z}_{(p)}$ .

For  $\mathcal{K}^p$  sufficiently small, there exists  $\tilde{\mathcal{K}}^p \subset GSp(2g, \mathbf{A}_f^p)$  open compact such that  $\varphi(\tilde{\mathcal{K}}^p) \subset \tilde{\mathcal{K}}^p$  and there is a finite morphism of  $\mathcal{O}_{E,\mathfrak{p}}$ -schemes:

$$\varphi^{\mathrm{Sh}}: \mathscr{S}_{\mathcal{K}} \to \mathscr{S}_{a,\tilde{\mathcal{K}}} \otimes_{\mathbf{Z}_{(p)}} \mathcal{O}_{E,\mathfrak{p}}.$$

<span id="page-16-4"></span><sup>&</sup>lt;sup>5</sup>Of course  $Sh(\mathbf{G}, \mathbf{X})_{\mathcal{K}}$  will only be a stack for certain  $\mathcal{K}$ ; this does not matter for our purposes

<span id="page-17-0"></span>4.1.5. The cocharacter  $\mu$ . Given  $h \in \mathbf{X}$ , let  $\mu \in X_*(\mathbf{G})$  be the associated minuscule cocharacter, given by  $\mu(z) = h_{\mathbf{C}} \circ \mu_0$  (§N.6.2). The reflex field E of  $(\mathbf{G}, \mathbf{X})$  is the field of definition of the  $\mathbf{G}(\mathbf{C})$ -conjugacy class  $[\mu]$  of  $\mu$ .

For any algebraically closed extension K/E, the conjugacy class  $[\mu]$  defines a unique conjugacy class  $[\mu]_K$  of cocharacters of  $\mathbf{G}_K$  defined over E. In particular, we obtain a conjugacy class  $[\mu]_{\overline{E}_{\mathfrak{p}}}$  for a choice of an algebraic closure  $\overline{E}_{\mathfrak{p}}$  of  $E_{\mathfrak{p}}$ . Since  $\mathbf{G}_{\mathbf{Q}_p}$  is unramified, it is in particular quasi-split. Thus, there exists a representative  $\mu \in X_*(\mathbf{G}_{E_{\mathfrak{p}}})$  of  $[\mu]_{\overline{E}_{\mathfrak{p}}}$  defined over  $E_{\mathfrak{p}}$ .

Define  $h_g \in \mathbf{X}_g$  and  $\mu_g \in X_*(GSp(2g))$  by  $h_g = \varphi \circ h$  and  $\mu_g := \varphi \circ \mu$ . The cocharacters  $\mu, \mu_g$  determine parabolic subgroups, as explained in §1.2.1. Specifically, we get the following subgroups:

- (1) A pair of opposite parabolic subgroups  $(\mathbf{P}^-, \mathbf{P}^+)$  in  $\mathbf{G}_{E_{\mathfrak{p}}}$  attached to  $\mu_{E_{\mathfrak{p}}}$ , and a common Levi subgroup  $\mathbf{L} := \mathbf{P}^- \cap \mathbf{P}^+ = \operatorname{Cent}(\mu_{E_{\mathfrak{p}}})$ . We set  $\mathbf{P} := \mathbf{P}^-$ .
- (2) A pair of opposite parabolic subgroups  $(P_g^-, P_g^+)$  in  $GSp(2g)_{E_{\mathfrak{p}}}$  attached to  $\mu_{g,E_{\mathfrak{p}}}$ , and a common Levi subgroup  $L_g := P_g^- \cap P_g^+ = \operatorname{Cent}(\mu_{g,E_{\mathfrak{p}}})$ . We set  $P_g := P_g^-$ . One has  $\mathbf{P}^{\pm} = P_g^{\pm} \cap \mathbf{G}$  and  $L_g \cap \mathbf{G} = \mathbf{L}$ .

Fix a Borel pair  $(\mathbf{B}, \mathbf{T})$  in  $\mathbf{G}_{\mathbf{Q}_p}$  such that  $\mathbf{B}_{E_p} \subset \mathbf{P}$ . Write  $I \subset \Delta$  for the type of  $\mathbf{P}$ . Set  $\mathbf{B}_{\mathbf{L}} = \mathbf{B} \cap \mathbf{L}$ .

- <span id="page-17-5"></span>4.1.6. Compatibility with the complex theory. In §10, we will fix an isomorphism  $\iota : \overline{\mathbf{Q}}_p \xrightarrow{\sim} \mathbf{C}$ . We choose  $\iota$  compatibly with  $\mathbf{P}$  so that the  $\mathbf{C}$ -parabolic  $\iota \mathbf{P}_{\overline{\mathbf{Q}}_p}$  deduced via  $\iota$  is the stabilizer of the Hodge filtration associated to the  $\mathbf{R}$ -Hodge structure  $\mathrm{Ad} \circ h$ . Consequently, given  $\alpha \in \Phi \setminus \Phi_{\mathbf{L}}$ , one has  $\alpha \in \Phi^+$  if and only if the image of  $\alpha$ -root space of  $\mathrm{Lie}(\mathbf{G})_{\mathbf{C}}$  is non-zero in  $\mathrm{Lie}(\mathbf{G})_{\mathbf{C}}/\mathrm{Lie}(\iota \mathbf{P}_{\overline{\mathbf{Q}}_p})$ , which is also the (-1,1)-part of the Hodge structure  $\mathrm{Ad} \circ h$  (conventions N.3.2, N.6.1).
- <span id="page-17-3"></span>4.1.7. Integral structure theory. Since  $\mathcal{G}_{\mathbf{Z}_p}$  is also quasi-split, we may assume that the representative  $\mu$  of  $[\mu]_{\overline{E}_p}$  extends to a cocharacter  $\mu: \mathbf{G}_{m,\mathcal{O}_p} \to \mathcal{G}_{\mathcal{O}_p}$ . The centralizer of  $\mu$  is a Levi subgroup  $\mathcal{L} \subset \mathcal{G}_{\mathcal{O}_p}$ . Define  $\mu_g: \mathbf{G}_{m,\mathcal{O}_p} \to GSp(\Lambda,\psi)_{\mathcal{O}_p}$  by  $\mu_g:=\varphi\circ\mu$ . Since  $\mathbf{S} \stackrel{h_g}{\to} GSp(V_{\mathbf{R}},\psi) \to GL(V_{\mathbf{R}})$  is an  $\mathbf{R}$ -Hodge structure of type  $\{(0,-1),(-1,0)\}$  (§N.6.1), the cocharacter  $\mu_g$  defines a  $\mathbf{Z}$ -grading  $\Lambda \otimes \mathcal{O}_p = \Lambda_0 \oplus \Lambda_{-1}$  (where  $\mathbf{G}_m$  acts through  $\mu_g$  by  $z \mapsto z^{-i}$  on  $\Lambda_i$  for i=0,-1).

Since  $\mathbf{Z}_p$  and  $\mathcal{O}_p$  are discrete valuation rings, [4, Chap.XXVI, 3.5] and the valuative criterion of properness applied to the schemes of parabolic subgroups of  $\mathcal{G}_{\mathcal{O}_p}$  imply that  $\mathbf{P}$  extends uniquely to a parabolic subgroup  $\mathcal{P} \subset \mathcal{G}_{\mathcal{O}_p}$ . Similarly, there is a unique extension of  $\mathbf{B}$  to a Borel subgroup  $\mathcal{B} \subset \mathcal{G}_{\mathbf{Z}_p}$ . Set  $\mathcal{B}_{\mathcal{L}} := \mathcal{L} \cap \mathcal{B}$ , it is the unique extension of the Borel subgroup  $\mathbf{B}_{\mathbf{L}}$  of  $\mathbf{L}$ .

<span id="page-17-4"></span>4.1.8. Hodge bundles. Let  $\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}$  be the universal abelian scheme over  $\mathscr{S}_{g,\tilde{\mathcal{K}}}$ . Define the Hodge line bundle  $\omega(\varphi)$  on  $S_{\mathcal{K}}$  associated to  $\varphi$  as in [77, Def. 5.1.2]: In the Siegel case, set

$$(4.1.3) \qquad \qquad \Omega_g = \mathrm{Fil}^1 H^1_{\mathrm{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}) \text{ and } \omega_g = \det \Omega_g,$$

where Fil<sup>1</sup> refers to the Hodge filtration. Formation of  $H^1_{dR}(\mathcal{A}_g/\mathscr{S}_g,\tilde{\mathcal{K}})$  and its Hodge filtration  $\Omega_g$  commutes with arbitrary base change, see §6.1.4 where a more difficult version is explained for toroidal compactifications.

In general put  $H^1_{\mathrm{dR}}(\mathcal{A}/\mathscr{S}_{\mathcal{K}}) := \varphi^* H^1_{\mathrm{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}})$ ,  $\Omega = \varphi^* \Omega_g$  and  $\omega = \varphi^* \omega_g$  (since the embedding  $\varphi$  was fixed in §4.1.4, we omit  $\varphi$  from the notation).

- <span id="page-17-2"></span>Remark 4.1.1 (Dependence on  $\varphi$ ). A priori both  $\Omega$  and its determinant  $\omega$  depend on the embedding  $\varphi$ . A posteriori it follows from Th. 4.3.1 below that when  $\mathbf{G}^{\mathrm{ad}}$  is  $\mathbf{Q}$ -simple, the ray generated by  $\omega$  in  $\mathrm{Pic}(\mathscr{S}_{\mathcal{K}})$  is independent of the embedding  $\varphi$ , see [38, Cor. 1.4.5]. However, this independence of  $\varphi$  is not used in this paper. Embeddings of products show that the above invariance is best possible. It remains unclear to us to what extent the Hodge vector bundle  $\Omega$  depends on  $\varphi$ .
- <span id="page-17-1"></span>4.1.9. Torsors and automorphic bundles. Following [58, 77], we recall how the vector bundle  $H^1_{dR}(\mathcal{A}/\mathscr{S}_K)$  yields a  $\mathcal{G}$ -torsor  $I_{\mathcal{G}}$  on  $\mathscr{S}_K$ . We follow [58] in the use of  $H^1_{dR}$ , while [77] uses its dual  $H_{1,dR}$ . This choice seems easier to relate to the universal G-Zip over  $S_K$ , see §6.2. By [58, 1.3.2], the group  $\mathcal{G}$  is the pointwise stabilizer of a finite collection of tensors  $(s_{\alpha}) \subset \Lambda^{\otimes}$ . By 2.3.9 of loc. cit. (see also [77, 5.3.1]), there are associated sections  $(s_{\alpha,dR}) \subset H^0(\mathscr{S}_K, \varphi^* H^1_{dR}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{K}})^{\otimes})$ . Then

$$(4.1.4) I_{\mathcal{G}} := \mathscr{I}som_{\mathscr{S}_{\mathcal{K}}}((H^1_{dR}(\mathcal{A}/\mathscr{S}_{\mathcal{K}}), (s_{\alpha,dR})), (\Lambda, (s_{\alpha})) \otimes \mathscr{S}_{\mathcal{K}})$$

is a  $\mathcal{G}$ -torsor on  $\mathscr{S}_{\mathcal{K}}$ . By 5.3.4 of *loc. cit.*, the subsheaf  $I_{\mathcal{P}} \subset I_{\mathcal{G}}$  consisting of isomorphisms which map the Hodge filtration of  $H^1_{\mathrm{dR}}(\mathcal{A}/\mathscr{S}_{\mathcal{K}})$  to  $\Lambda_0 \otimes \mathscr{S}_{\mathcal{K}}$  is a  $\mathcal{P}$ -torsor. Define an  $\mathcal{L}$ -torsor  $I_{\mathcal{L}}$  on  $\mathscr{S}_{\mathcal{K}}$  as the quotient  $I_{\mathcal{P}}/R_u(\mathcal{P})$  where  $R_u(\cdot)$  denotes the unipotent radical.

Let N be a finite extension of  $E_{\mathfrak{p}}$  with ring of integers  $\mathcal{O}_N$  and prime  $\wp$  lying over  $\mathfrak{p}$ . Since  $I_{\mathcal{P}}/\mathcal{P} \cong \mathscr{S}_{\mathcal{K}}$ , every algebraic representation of  $\mathcal{P}$  on a finite free  $\mathcal{O}_N$ -module W gives rise to a vector bundle on  $\mathscr{S}_{\mathcal{K}}$  as in §N.4.1. By setting  $R_n(\mathcal{P})$  to act trivially, any representation of  $\mathcal{L}$  on W gives rise to one of  $\mathcal{P}$ .

Let  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . Let  $\mathscr{L}(\eta)$  be the associated  $\mathbf{L}_{\overline{\mathbf{Q}}_p}$ -equivariant (or  $\mathbf{L}_{\overline{\mathbf{Q}}_p}$ -linearized) line bundle on the flag variety  $(\mathbf{L}/\mathbf{B}_{\mathbf{L}})_{\overline{\mathbf{Q}}_p}$ . Then there exists an extension N as above such that  $\mathscr{L}(\eta)$  descends to an  $\mathscr{L}$ -equivariant line bundle on  $\mathscr{L}/\mathscr{B}_{\mathscr{L}} \times_{\mathcal{O}_{\mathfrak{p}}} \mathscr{O}_N$  over  $\mathscr{O}_N$ . Continue to call the descended line bundle  $\mathscr{L}(\eta)$ . Let  $V_{\eta}$  be the representation of  $\mathscr{L}$  on  $H^0(\mathscr{L}/\mathscr{B}_{\mathscr{L}} \times_{\mathcal{O}_{\mathfrak{p}}} \mathscr{O}_N, \mathscr{L}(\eta))$ . By the Borel-Weil Theorem,  $V_{\eta} \otimes \overline{\mathbf{Q}}_p$  is irreducible of highest weight  $\eta$ . In general  $V_{\eta}$  is the (possibly reducible) highest weight, induced module denoted  $H^0(\eta)$  in [53].

The automorphic vector bundle of weight  $\eta$  is the vector bundle  $\mathscr{V}(\eta)$  on  $\mathscr{S}_{\mathcal{K}}$  afforded by the torsor  $I_{\mathcal{L}}$  and the representation  $V_{\eta}$ . If different levels are in play, write  $\mathscr{V}_{\mathcal{K}}(\eta)$  to specify the level.

<span id="page-18-2"></span>4.1.10.  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant objects. Recall our convention §N.2.3: Write  $\mathscr{S}_{\mathcal{K}}^+ := \mathscr{S}_{\mathcal{K}}, \mathscr{S}_{\mathcal{K}}^0 = \mathscr{S}_{\mathcal{K}} \otimes_{\mathcal{O}_{E,\mathfrak{p}}} E_{\mathfrak{p}}$  for its generic fiber and  $\mathscr{S}_{\mathcal{K}}^n := \mathscr{S}_{\mathcal{K}} \otimes_{\mathcal{O}_{E,\mathfrak{p}}} \mathcal{O}_{E,\mathfrak{p}}/\mathfrak{p}^n$  for  $n \geq 1$ . Let  $n \in \mathbf{Z}_{\geq 0} \cup \{+\}$ . A  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant sheaf on the tower  $(\mathscr{S}_{\mathcal{K}}^n)_{\mathcal{K}^p}$  is a system of sheaves  $(\mathscr{F}_{\mathcal{K}})_{\mathcal{K}^p}$  such that  $\pi_{\mathcal{K}'/\mathcal{K}}^* \mathscr{F}_{\mathcal{K}} = \mathscr{F}_{\mathcal{K}'}$  and  $g^* \mathscr{F}_{g^{-1}\mathcal{K}g} = \mathscr{F}_{\mathcal{K}}$  for all  $\mathcal{K}'^p \subset \mathcal{K}^p$  and all  $g \in \mathbf{G}(\mathbf{A}_f^p)$ , where  $\mathcal{K}' = \mathcal{K}_p \mathcal{K}'_p$ . Similarly a morphism of  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant sheaves  $(\mathscr{F}_{\mathcal{K}}) \to (\mathscr{G}_{\mathcal{K}})$  consists of a family of morphisms  $\mathscr{F}_{\mathcal{K}} \to \mathscr{G}_{\mathcal{K}}$  which is compatible with  $\pi_{\mathcal{K}'/\mathcal{K}}$  and g. This applies to both étale sheaves (in particular étale torsors) and to (quasi-)coherent  $(\mathcal{O}_{\mathscr{S}_{\mathcal{K}}})_{\mathcal{K}^p}$ -modules. Given a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant sheaf  $(\mathscr{F}_{\mathcal{K}})$ , a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant section t is a system  $(t_{\mathcal{K}} \in H^0(\mathscr{S}_{\mathcal{K}}^n, \mathscr{F}))$  satisfying  $\pi_{\mathcal{K}'/\mathcal{K}}^k t_{\mathcal{K}} = t_{\mathcal{K}'}$  and  $g^* t_{g^{-1}\mathcal{K}g} = t_{\mathcal{K}}$ .

More generally, define a  $\mathbf{G}(\mathbf{A}_f^p)$ -system of schemes as a system of schemes  $(\mathscr{Z}_{\mathcal{K}})_{\mathcal{K}^p}$  such that for every inclusion  $\mathcal{K}'^p \subset \mathcal{K}^p$ , one has a projection  $\mathscr{Z}_{\mathcal{K}'} \to \mathscr{Z}_{\mathcal{K}}$  and for every  $g \in \mathbf{G}(\mathbf{A}_f^p)$  a system of isomorphisms  $g : \mathscr{Z}_{\mathcal{K}} \overset{\sim}{\to} \mathscr{Z}_{g^{-1}\mathcal{K}g}$  (subject to the usual compatibility conditions). A  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant morphism  $\alpha : (\mathscr{Z}_{1,\mathcal{K}}) \to (\mathscr{Z}_{2,\mathcal{K}})$  is a system of morphisms  $\alpha_{\mathcal{K}} : \mathscr{Z}_{1,\mathcal{K}} \to \mathscr{Z}_{2,\mathcal{K}}$  such that  $\mathscr{Z}_{1,\mathcal{K}'} \to \mathscr{Z}_{1,\mathcal{K}}$  (resp.  $g : \mathscr{Z}_{1,\mathcal{K}} \overset{\sim}{\to} \mathscr{Z}_{1,g^{-1}\mathcal{K}g}$ ) is the pullback of  $\mathscr{Z}_{2,\mathcal{K}'} \to \mathscr{Z}_{2,\mathcal{K}}$  (resp.  $g : \mathscr{Z}_{2,\mathcal{K}} \overset{\sim}{\to} \mathscr{Z}_{2,g^{-1}\mathcal{K}g}$ ) along  $\alpha$ . In particular, a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant subscheme of  $(\mathscr{S}_{\mathcal{K}})_{\mathcal{K}^p}$  is a system of subschemes  $(\mathscr{Z}_{\mathcal{K}})_{\mathcal{K}^p}$ , where  $\mathscr{Z}_{\mathcal{K}}$  is a subscheme of  $\mathscr{S}_{\mathcal{K}}^n$  such that  $\pi_{\mathcal{K}'/\mathcal{K}}^{-1}(\mathscr{Z}_{\mathcal{K}}) = \mathscr{Z}_{\mathcal{K}'}$  and  $g^{-1}(\mathscr{Z}_{g^{-1}\mathcal{K}g}) = \mathscr{Z}_{\mathcal{K}}$  (both scheme-theoretically). It follows directly from the definitions that a system of ideal sheaves  $(\mathcal{I}_{\mathcal{K}} \subset \mathcal{O}_{\mathscr{S}_{\mathcal{K}}^n})$  is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant if and only if the corresponding system of zero-schemes is.

By construction the universal abelian scheme  $\mathcal{A} \to \mathscr{S}$ , the vector bundle  $H^1_{\mathrm{dR}}(\mathcal{A}/\mathscr{S})$  and the sections  $s_{\alpha,\mathrm{dR}}$  are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant. It follows that also the bundles  $\mathscr{V}(\eta)$  and the torsors  $I_{\mathcal{G}}, I_{\mathcal{P}}, I_{\mathcal{L}}$  are all  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant.

<span id="page-18-1"></span>4.1.11. Vector bundle dictionary. Let Std:  $GSp(V,\psi)\hookrightarrow GL(V)$  be the forgetful representation; it is an irreducible  $GSp(V,\psi)$ -module. Let  $\eta_{g,\Omega}$  be the highest weight of Std relative to our choice of Borel pair  $(\mathbf{B},\mathbf{T})$  (§4.1.5 in the case  $\mathbf{G}=GSp(V,\psi)$ ) and convention on positive roots (§N.3.2). Using the notation of §4.1.9, put  $\eta_{g,\omega}:=\det V_{\eta_g,\Omega}^\vee$ . Recall that  $\mathscr{V}(\eta_{g,\Omega})^\vee\cong\Omega_g$  and  $\mathscr{V}(\eta_{g,\omega})\cong\omega_g$  cf. [32, Proof of Th. 5.5.1] or [21, p. 257, Ex. (b)-(c)]. (Consider one standard set of choices/coordinates:  $V=\mathbf{Q}^{2g},\ \psi=\begin{pmatrix}0&-I_g\\I_g&0\end{pmatrix}$ ,  $\mathbf{T}$  is the diagonal ( $\mathbf{Q}$ -split) maximal torus, identify  $X^*(\mathbf{T})$  with  $\{(a_1,\ldots a_g;c)\in\mathbf{Z}^{g+1}\mid \sum a_i\equiv c\pmod{2}\}$  via diag $(t_1z,\ldots,t_gz,t_1^{-1}z,\ldots,t_g^{-1}z)\mapsto t_1^{a_1}\cdots t_g^{a_g}z^c,$   $\Delta=\{e_1-e_2,\ldots,e_{g-1}-e_g,2e_g\}$  and  $\Delta_L=\Delta\setminus\{2e_g\}$ . Then  $\eta_{g,\Omega}$  (resp.  $\eta_{g,\omega}$ ) is identified with diag $(0,\ldots,0,-1;-1)$  (resp. diag $(-1,\ldots,-1;-g)$ ), cf. [101, p. 306].)

In general, set  $\eta_{\omega} = \varphi^* \eta_{g,\omega}$ . Then  $\mathscr{V}(\eta_{\omega}) \cong \omega$  as  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant line bundles on  $\mathscr{S}_{\mathcal{K}}$ . We call  $\eta_{\omega}$  the *Hodge character* associated to  $\varphi$ . This 'modular' definition agrees with the group-theoretic one given in Def. 1.3.1(b).

<span id="page-18-0"></span>4.2. Universal G-zip over  $S_{\mathcal{K}}$ . Let  $S_{\mathcal{K}} := \mathscr{S}_{\mathcal{K}}^1$  be the special fiber of  $\mathscr{S}_{\mathcal{K}}$ . We briefly review the construction ([113, Th. 2.4.1] and [110, §5]) of the universal G-zip  $\underline{I} = (I, I_P, I_Q, \iota)$  over  $S_{\mathcal{K}}$ . Denote by  $\kappa := \mathcal{O}_E/\mathfrak{p}$  the residue field of  $\mathfrak{p}$ . Define  $G := \mathcal{G} \otimes \mathbf{F}_p$  and write again  $\mu : \mathbf{G}_{m,\kappa} \to G_{\kappa}$  and  $\mu_g = \mu \circ \varphi$  for the reduction of  $\mu, \mu_g$ . Recall (§4.1.7) that we have  $\Lambda = \Lambda_0 \oplus \Lambda_{-1}$ . Define parabolic subgroups P, Q of  $G_{\kappa}$  as the stabilizers in  $G_{\kappa}$  of  $\mathrm{Fil}_P := \Lambda_{0,\kappa}$  and  $\mathrm{Fil}_Q := {}^{\sigma}\Lambda_{-1,\kappa}$ , respectively.

Denote by  $(\overline{s}_{\alpha})$  the reduction of  $(s_{\alpha})$  to  $\Lambda_{\mathbf{F}_{p}}$  and by  $\overline{s}_{\alpha,\mathrm{dR}}$  the reduction of  $(s_{\alpha,\mathrm{dR}})$  to  $S_{\mathcal{K}}$ . The sheaf  $H^{1}_{\mathrm{dR}}(A/S_{\mathcal{K}}) := H^{1}_{\mathrm{dR}}(A/S_{\mathcal{K}}) \otimes \kappa$  admits a Hodge filtration Fil<sub>H</sub> :=  $\Omega_{A/S_{\mathcal{K}}}$  and a conjugate filtration Fil<sub>conj</sub>. Furthermore, their graded pieces are related by the Cartier isomorphisms:

<span id="page-18-5"></span>
$$(4.2.1) \iota_0 : \operatorname{Fil}_{\mathrm{H}}^{(p)} \simeq H^1_{\mathrm{dR}}(A/S_{\mathcal{K}})/\operatorname{Fil}_{\mathrm{conj}} \quad \text{and} \quad \iota_1 : (H^1_{\mathrm{dR}}(A/S_{\mathcal{K}})/\operatorname{Fil}_{\mathrm{H}})^{(p)} \simeq \operatorname{Fil}_{\mathrm{conj}}.$$

One then defines:

<span id="page-18-3"></span>
$$(4.2.2) I := \mathscr{I}som_{S_{\kappa}}((H^1_{dR}(A/S_{\kappa}), \overline{s}_{dR}), (\Lambda, \overline{s}) \otimes \mathcal{O}_{S_{\kappa}})$$

$$(4.2.3) I_P := \mathscr{I}som_{S_{\kappa}}((H^1_{dR}(A/S_{\kappa}), \overline{s}_{dR}, \operatorname{Fil}_H), (\Lambda, \overline{s}, \operatorname{Fil}_P) \otimes \mathcal{O}_{S_{\kappa}})$$

<span id="page-18-4"></span>
$$(4.2.4) I_Q := \mathscr{I}som_{S_{\mathcal{K}}}((H^1_{dR}(A/S_{\mathcal{K}}), \overline{s}_{dR}, \operatorname{Fil}_{\operatorname{conj}}), (\Lambda, \overline{s}, \operatorname{Fil}_Q) \otimes \mathcal{O}_{S_{\mathcal{K}}})$$

and the isomorphism of  $L^{(p)}$ -torsors is given by  $\iota = (\iota_0, \iota_1)$ . This yields a universal G-zip  $\underline{I} = (I, I_P, I_Q, \iota)$  over  $S_K$ . It gives rise to a morphism of stacks

$$\zeta: S_{\mathcal{K}} \to G\text{-}\mathrm{Zip}^{\mu}$$

which is smooth by [113, Th. 3.1.2]. Recall that  $G\text{-}\operatorname{Zip}^{\mu} \simeq [E \setminus G]$ . For every  $w \in {}^{I}W$ , define the EO-stratum  $S_{w}$  in  $S_{\mathcal{K}}$  by  $S_{w} := \zeta^{-1}([E \setminus G_{w}])$ . Since  $\zeta$  is smooth and  $G_{w}$  is smooth,  $S_{w}$  is a smooth, locally closed subscheme of  $S_{\mathcal{K}}$ .

Since the datum of a G-Zip consists of torsors and isomorphisms between them, one has the notion of  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant G-Zip on  $S_{\mathcal{K}}$  by §4.1.10. By construction,  $\underline{I}$  is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant: Given  $\mathcal{K}'^p \subset \mathcal{K}^p$  and  $g \in \mathbf{G}(\mathbf{A}_f^p)$ , one has commutative triangles

<span id="page-19-7"></span>
$$(4.2.6) \qquad S_{\mathcal{K}'} \xrightarrow{\zeta_{\mathcal{K}'}} G\text{-}\mathrm{Zip}^{\mu} \qquad \text{and} \qquad S_{\mathcal{K}} \xrightarrow{\zeta_{\mathcal{K}}} G\text{-}\mathrm{Zip}^{\mu} \\ S_{\mathcal{K}} \xrightarrow{\zeta_{\mathcal{K}}} G \xrightarrow{\zeta_{\mathcal{K}}} G$$

<span id="page-19-3"></span>4.3. Hasse invariants for Ekedahl-Oort strata. We explain how to apply the general group theoretic Th. 3.2.3 on Hasse invariants to  $S_{\mathcal{K}}$ . We give two ways to deal with the (p, L)-admissible hypothesis of Th. 3.2.3: (i) Show that it is satisfied by the Hodge character  $\eta_{\omega}$  for all primes p, (ii) Show that for Hodge-type Shimura varieties, one can reduce to G = GL(n), for which  $\eta_{\omega}$  is minuscule. Regarding (i), one has:

<span id="page-19-5"></span>**Theorem 4.3.1** ([38], Th. 1.4.4). The Hodge character  $\eta_{\omega}$  of a symplectic embedding  $\varphi': (\mathbf{G}, \mathbf{X}) \hookrightarrow (GSp(2g), \mathbf{X}_g)$  is quasi-constant (Def. N.5.3).

Remark 4.3.2. The theorem is proved using classical Hodge theory, specifically the methods of [24]. In particular, it is valid for any symplectic embedding  $\varphi'$ , not just the special integral ones considered in §4.1.4.

As for (ii): Using Th. 3.2.3 for G = GL(n) and the generalization of the discrete fibers theorem [36, Th. 2] mentioned in Rmk. I.1.3, we proved:

<span id="page-19-6"></span>**Theorem 4.3.3** ([36], Cor. 6.2.2). Let  $(G, \mu)$  be a maximal cocharacter datum ([36, §2.4], we do not assume  $(G, \mu)$  arises by reduction mod p from a Shimura datum). Let  $\chi \in X^*(L)$  be a maximal character (loc. cit., Def. 2.4.3). Then there exists  $N \ge 1$  such that for every  $w \in {}^IW$ , there is a section  $h_w \in H^0([E \setminus \overline{G}_w], \mathscr{V}(N\chi))$  with nonvanish $(h_w) = [E \setminus G_w]$ .

Return to the setting where  $(G, \mu)$  is associated to (G, X) and  $\varphi$  as in §4.2.

<span id="page-19-0"></span>Corollary 4.3.4. There exists  $N \ge 1$  such that for every  $w \in {}^{I}W$ , there exists a section  $h_w \in H^0([E \backslash \overline{G}_w], \mathscr{V}(N\eta_\omega))$  whose non-vanishing locus is precisely  $[E \backslash G_w]$ .

*Proof 1:* Since  $\eta_{\omega}$  is easily seen to be *L*-ample, Th. 4.3.1 shows that it is (p, L)-admissible for all primes p (§N.5). Therefore the desired sections exist by Th. 3.2.3.

*Proof 2:* The forgetful representation  $GSp(V, \psi) \to GL(V)$  exhibits  $(G, \mu)$  as a maximal coharacter datum and  $\eta_{\omega}$  as a maximal character. Thus the corollary is a special case of Th. 4.3.3.

<span id="page-19-1"></span>Corollary 4.3.5 (EO Hasse invariants). For every EO stratum  $S_w \subset S_K$ , the section  $\zeta^*h_w \in H^0(\overline{S}_w, \omega^N)$  is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant and nonvanish $(\zeta^*h_w) = S_w$ .

*Proof.* The section  $\zeta^* h_w$  is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant by (4.2.6) and nonvanish $(\zeta^* h_w) = S_w$  follows from Cor. 4.3.4.

Next we deduce the affineness of strata in the compact case (Cor. I.2.4). The generalization to the noncompact case (Cor. I.2.6) is treated in Prop. 6.3.1.

<span id="page-19-2"></span>Corollary 4.3.6 (Affineness, compact case). Suppose  $S_K$  is proper over k. Then the strata  $S_w$  are affine for all  $w \in {}^IW$ .

*Proof.* The Hodge line bundle  $\omega$  is ample on  $S_{\mathcal{K}}$  [77, 5.2.11(b)]. Since the non-vanishing locus of a section of an ample line bundle on a proper scheme is affine, the result follows from Cor. 4.3.5.

Combining Th. 4.3.1 with Th. 3.3.1 gives a 'discrete fibers' result for symplectic embeddings of Shimura varieties:

<span id="page-19-4"></span>Corollary 4.3.7 (Discrete Fibers). Let  $\varphi': (\mathbf{G}, \mathbf{X}) \hookrightarrow (GSp(2g), \mathbf{X}_g)$  be an arbitrary symplectic embedding of Shimura data. Then the induced morphism of stacks G-Zip $^{\mu} \rightarrow GSp(2g)$ -Zip $^{\mu_g}$  has discrete fibers. In other words, if two EO strata map to the same one under  $\varphi'$ , then there is no closure relation between them.

For example, let  $\varphi'$  be the tautological embedding of a PEL-type Shimura variety in its underlying Siegel variety. The naive stratification of  $S_{\mathcal{K}}$  is defined by taking preimages of Siegel EO strata; it is induced by the isomorphism class of the underlying  $BT_1$  without its additional structure. Cor. 4.3.7 states that a naive EO stratum is topologically a disjoint union of (true) EO strata.

#### <span id="page-20-0"></span>5.1. Gluing sections.

<span id="page-20-7"></span>**Theorem 5.1.1.** Let X be a Noetherian scheme where p is nilpotent. Let  $\mathcal{L}$  be a line bundle on X. Let  $\mathcal{D}$  be a decomposition of  $X_{\text{red}}$ :

$$(5.1.1) X_{\text{red}} = X_1 \cup X_2 \cup \ldots \cup X_r,$$

<span id="page-20-2"></span>where  $X_i \subset X_{\text{red}}$  are closed reduced subschemes. Then

- (a) There exists an integer  $m_0(X, \mathcal{L}, \mathcal{D})$  such that for all integers  $a \geq m_0(X, \mathcal{L}, \mathcal{D})$  and every r-tuple of sections  $s_i \in H^0(X_i, \mathcal{L}), \ 1 \leq i \leq r, \ such \ that \ s_i = s_j \ on \ (X_i \cap X_j)_{red}, \ there \ exists \ a \ unique \ section \ s \in H^0(X, \mathcal{L}^{p^{2a}})$ which is Zariski-locally the  $p^a$ -power of a section s' of  $\mathcal{L}^{p^a}$  which restricts to  $s_i^{p^{2a}}$  on  $X_i$ .
- <span id="page-20-4"></span>(b) If X has no embedded components, then s is injective if and only if  $s_1, \ldots, s_r$  are all injective.

*Proof.* First we consider (a). Since X is Noetherian, it is covered by finitely many open affine subsets  $X = U_1 \cup ... \cup U_d$ such that  $\mathcal{L}|_{U_j} = \mathcal{O}_{U_j}$ . For each j = 1, ..., d, let  $\mathcal{D}_j$  be the decomposition  $(X_i \cap U_{j,\text{red}})_i$  of  $U_{j,\text{red}}$ . If we prove the result for each  $(U_j, \mathcal{L}|_{U_i}, \mathcal{D}_j)$ , then we may take  $m_0 := \sup_i \{m_0(U_i, \mathcal{L}_i, \mathcal{D}_i)\}$ . Thus we may work locally and assume that  $X = \operatorname{Spec}(A)$  with A Noetherian and  $\mathcal{L} = \mathcal{O}_X$ . By induction we reduce to r = 2. Assertion (a) follows from Lemma 5.1.2 below.

For (b), we may also assume  $X = \operatorname{Spec}(A)$  with A Noetherian. The result then follows from the claim that s is injective if and only if  $s|_{X_{red}}$  is injective. This is an immediate consequence of the fact that the set of zero-divisors of A is the union of the associated primes of A ([79, Th. 6.1]).

<span id="page-20-3"></span>**Lemma 5.1.2.** Let A be a Noetherian ring where p is nilpotent. Let  $\mathcal{N}(A)$  be the nilradical and  $I_1, I_2$  two radical ideals of A such that  $I_1 \cap I_2 = \mathcal{N}(A)$ . There exists an integer  $m_0$  such that for all  $n \geq m_0$  and for all  $x_1, x_2 \in A$ such that  $x_1 - x_2 \in \sqrt{I_1 + I_2}$ , there exists a unique  $x \in A$  satisfying:

- <span id="page-20-6"></span><span id="page-20-5"></span>(a)  $x \equiv x_1^{p^{2n}} \pmod{I_1}$  and  $x \equiv x_2^{p^{2n}} \pmod{I_2}$ . (b)  $x = y^{p^n}$  for some  $y \in A$ .

*Proof.* Let  $h, d, m \geq 1$  be integers such that

- (1)  $p^h = 0$  in A, (2)  $(\sqrt{I_1 + I_2})^{p^m} = 0$  in  $A/(I_1 + I_2)$ ,
- (3)  $\mathcal{N}(A)^{p^d} = 0$ .

Set  $m_0 := \sup\{d+h-1, m\}$ . There is an exact sequence:

$$(5.1.2) 0 \longrightarrow A/\mathcal{N}(A) \longrightarrow A/I_1 \oplus A/I_2 \longrightarrow A/(I_1 + I_2) \longrightarrow 0$$

where the second map is  $(g_1, g_2) \mapsto g_1 - g_2$ . Let  $n \geq m_0$  and  $x_1, x_2 \in A$  such that  $x_1 - x_2 \in \sqrt{I_1 + I_2}$ . Then  $x_1^{p^n} - x_2^{p^n} \in I_1 + I_2$  because the ring  $A/(I_1 + I_2)$  has characteristic p. Hence there exists  $z \in A$  such that  $z \equiv x_1^{p^n} \pmod{I_1}$  and  $z \equiv x_2^{p^n} \pmod{I_2}$ . Therefore  $x := z^{p^n}$  satisfies the conditions.

To prove uniqueness, assume that  $x, x' \in A$  satisfy (a) and (b). In particular, we have  $x - x' \in \mathcal{N}(A)$ . Write  $x=y^{p^n}$  and  $x'=y'^{p^n}$  for some  $y,y'\in A$ . The ring  $A/\mathcal{N}(A)$  has characteristic p, so  $x-x'=y^{p^n}-y'^{p^n}=(y-y')^{p^n}=0$ in  $A/\mathcal{N}(A)$ , hence  $y-y' \in \mathcal{N}(A)$ . We deduce  $(y-y')^{p^d}=0$  in A, hence also in A/pA. It follows that  $y^{p^d} \equiv y'^{p^d} \pmod{pA}$ . Thus  $y^{p^{d+m-1}} \equiv y'^{p^{d+m-1}} \pmod{p^mA}$  for all  $m \geq 1$ . Hence  $y^{p^u} = y'^{p^u}$  in A for all  $u \geq d+h-1$ . In particular x = x'.

<span id="page-20-1"></span>5.2. **Length stratification.** Retain the setting of §4.3. In particular, G is a reductive  $\mathbf{F}_p$ -group and  $\mu: \mathbf{G}_{m,k} \to G_k$ is a cocharacter such that the cocharacter datum  $(G, \mu)$  arises from a Shimura datum of Hodge-type (§4.3). By Cor. 4.3.4, there exists an integer  $N \geq 1$  and sections  $h_w \in H^0([E \setminus \overline{G}_w], \omega^N)$  for each  $w \in {}^IW$ , such that the non-vanishing locus of  $h_w$  is exactly the open substack  $[E \backslash G_w]$ .

Let  $d := \ell(w_{0,I}w_0)$ . The length of any element  $w \in {}^IW$  satisfies  $0 \le \ell(w) \le d$ . For an integer  $0 \le j \le d$ , define:

(5.2.1) 
$$G_j = \bigcup_{\ell(w)=j} G_w \text{ and } \overline{G}_j = \bigcup_{\ell(w) \le j} G_w.$$

Endow the locally closed subsets  $G_i, \overline{G}_i$  with the reduced subscheme structure. We call  $G_i$  the jth length stratum

<span id="page-20-8"></span>**Lemma 5.2.1.** One has 
$$\overline{G}_j = \bigcup_{\ell(w)=j} \overline{G}_w$$
.

*Proof.* Recall that the underlying topological space of G-Zip $^{\mu}$  is isomorphic to  $^{I}W$  endowed with the topology induced by the partial order  $\leq$ , which is in general finer than the restriction of the Bruhat order of W ([87, Th. 6.2]).

Let  $w \in {}^{I}W$  and let  $w = s_{\alpha_1} \cdots s_{\alpha_r}$  be a reduced expression. Then  $w' := s_{\alpha_1} \cdots s_{\alpha_{r-1}} \in {}^{I}W$  and  $\ell(w') = r - 1$ . Furthermore,  $w' \preceq w$  because  $\preceq$  is finer than the Bruhat order. Hence any element in  ${}^{I}W$  of length  $r \geq 1$  has an element of  ${}^{I}W$  of length r = 1 in its closure. But since  $w \mapsto w_{0,I}ww_0$  is an order-reversing involution, we deduce similarly that any element of length  $j \in I$  in  ${}^{I}W$  lies in the closure of an element of  ${}^{I}W$  of length  $j \in I$ .

In the next proposition, we prove that the length stratification of G is principally pure, i.e  $G_j$  is the non-vanishing locus of a section over  $\overline{G}_j$ .

<span id="page-21-7"></span>**Proposition 5.2.2.** There exists an integer  $N' \ge 1$  and for each  $0 \le j \le d$ , a section  $h_j \in H^0([E \setminus \overline{G}_j], \omega^{N'})$  such that the non-vanishing locus of  $h_j$  is exactly  $G_j$ .

We call the  $h_i$  length Hasse invariants of G-Zip<sup> $\mu$ </sup>.

Proof. One has the decomposition  $\overline{G}_j = \bigcup_{\ell(w)=j} \overline{G}_w$  and for each w with  $\ell(w) = j$ , the section  $h_w$  afforded by Cor. 4.3.4. We may interpret each  $h_w$  as a regular E-eigenfunction on  $\overline{G}_w$  for the character  $N\eta_\omega$ . Using Th. 5.1.1, we obtain a function  $\overline{G}_j \to \mathbf{A}^1$  which restricts to  $h_w^r$  on  $\overline{G}_w$  for some  $r \geq 1$ . Hence  $h_j$  is an E-eigenfunction for the character  $Nr\eta_\omega$ . It follows that  $h_j$  identifies with an element of  $H^0([E \setminus \overline{G}_j], \omega^{N'})$  for N' = Nr, and the result follows.

Let S be a scheme of finite type over k and  $f: S \to G$ -Zip $^{\mu}$  a morphism of stacks (not assumed smooth). For a character  $\chi \in X^*(L)$ , write  $\mathscr{V}_S(\chi) := f^*(\mathscr{V}(\chi))$ . For  $w \in {}^IW$  and  $j \in \{0, ..., d\}$ , define locally-closed subsets  $S_w$ ,  $S_w^*$ ,  $S_j^*$ ,  $S_j^*$  as the preimages by f of  $[E \backslash \overline{G}_w]$ ,  $[E \backslash \overline{G}_y]$ ,  $[E \backslash \overline{G}_j]$ , respectively. Endow each of them with the reduced subscheme structure. The  $(S_w)_w$  form a locally-closed decomposition of S. It is false in general that  $S_w^*$  is the Zariski closure of  $S_w$  in S, but this holds for example when f is smooth. One has

(5.2.2) 
$$S_j = \bigsqcup_{\ell(w)=j} S_w \text{ and } S_j^* = \bigsqcup_{\ell(w) \le j} S_w.$$

We call  $S_j$  the jth length stratum of S. Set  $S_j = S_j^* = \emptyset$  for all j < 0. Furthermore, by Lemma 5.2.1 we have

(5.2.3) 
$$S_j^* = \bigcup_{\ell(w)=j} S_w^*.$$

<span id="page-21-6"></span><span id="page-21-5"></span><span id="page-21-0"></span>**Proposition 5.2.3.** Assume the following:

- (a) The scheme S is equi-dimensional of dimension d.
- <span id="page-21-1"></span>(b) The stratum  $S_w$  is non-empty for all  $w \in {}^{I}W$ .
- (c) The stratum  $S_e = S_0$  is zero-dimensional.

<span id="page-21-2"></span>Then:

- <span id="page-21-3"></span>(1) The schemes  $S_j$  and  $S_j^*$  are equi-dimensional of dimension j,
- <span id="page-21-4"></span>(2) The sections  $h_i$  are injective (§N.2.4); equivalently  $S_i$  is open dense in  $S_i^*$ .
- (3) For  $w \in {}^{I}W$ ,  $S_w$  is equi-dimensional of dimension  $\ell(w)$ .

Remark 5.2.4. It is not claimed that  $S_w$  is dense in  $S_w^*$ , nor that  $S_w^*$  is equi-dimensional.

*Proof.* Let  $j \geq 1$ . Since  $S_{j-1}^*$  is the set-theoretic vanishing locus  $f^*(h_j)$  in  $S_j^*$ , we deduce that

(5.2.4) 
$$\dim(S_i^*) - 1 \le \dim(S_{i-1}^*) \le \dim(S_i^*).$$

Assumptions (a) and (c) imply that  $\dim(S_j^*) = j$  for all j = 0, ..., d. We prove by decreasing induction on j that  $S_j^*$  is equi-dimensional of dimension j. This is true for j = d by assumption (a). Assume it is true for  $j \geq 1$ . Since  $S_{j-1}^*$  is the set-theoretic vanishing locus of  $f^*(h_j)$  on  $S_j^*$ , which is equi-dimensional of dimension j, all irreducible components of  $S_{j-1}^*$  have codimension  $\leq 1$  in  $S_j^*$ . But  $\dim(S_{j-1}^*) = j - 1$ , so  $S_{j-1}^*$  is equi-dimensional of dimension j - 1. Since  $S_j$  is open in  $S_j^*$ , it is also equi-dimensional of dimension j. This proves (1).

The section  $f^*(h_j)$  does not restrict to zero on any irreducible component of  $S_j^*$ , so  $S_j$  is dense in  $S_j^*$  and  $h_j$  is injective, which shows (2).

Finally, we show (3). If  $w \in {}^IW$  satisfies  $\ell(w) \leq j$  and  $\dim(S_w) = j$ , then  $\ell(w) = j$ . Conversely, let  $w \in W$  be an element of length j. Since  $S_j^*$  is pure of dimension j, there exists  $w' \in {}^IW$  of length j satisfying  $\dim(S_{w'}^*) = j$  such that  $S_w$  intersects  $S_{w'}^*$ . The continuity of f implies that w' = w, so  $\dim(S_w^*) = j$ . Hence  $\dim(S_w) = j$  as well. Let Z be an irreducible component of  $S_w$ , and assume  $\dim(Z) < j$ . Then Z is contained in  $S_{w'}^*$  for an element  $w' \neq w$  of length j, because  $S_j^*$  is pure of dimension j. Again, this contradicts the continuity of f. Hence  $S_w$  is pure of dimension j.

#### 6. Extension of Hasse invariants to compactifications

- <span id="page-22-0"></span>6.1. Compactifications. We review the results of Madapusi-Pera [77] that we shall use about integral models of toroidal and minimal compactifications of Hodge-type Shimura varieties. As recalled below, most of these results rely on the corresponding statements in the Siegel case, which are due to Chai-Faltings [21]. In-between the works of Chai-Faltings and Madapusi-Pera, generalizations to the intermediate PEL case were given in a series of works by Lan [66, 65, 71, 72]. We shall often refer to Lan for precise references in the Siegel case.
- <span id="page-22-1"></span>6.1.1. Toroidal compactifications. Recall the choice of hyperspecial  $\tilde{\mathcal{K}}_p \subset GSp(2g, \mathbf{Q}_p)$  (§4.1.4) and the map  $\varphi^{\mathrm{Sh}}: \mathscr{S}_{\mathcal{K}} \to \mathscr{S}_{g,\tilde{\mathcal{K}}}$  (4.1.2). In the Siegel case, let  $\tilde{\Sigma}$  be a finite, admissible rpcd (rational, polyhedral cone decomposition) for  $(GSp(2g), \mathbf{X}_g, \tilde{\mathcal{K}})$  [77, 2.1.22-2.1.23]. In general, let  $\Sigma$  be a refinement of the finite, admissible rpcd obtained by pullback  $\varphi^*\tilde{\Sigma}$  for  $(\mathbf{G}, \mathbf{X}, \mathcal{K})$ . By [21] (resp. [77, Ths. 1, 4.1.5]) there exists a toroidal compactification  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  of  $\mathscr{S}_{g,\tilde{\mathcal{K}}}$  (resp. toroidal compactifications  $\mathscr{S}_{\mathcal{K}}^{\Sigma}, \mathscr{S}_{\mathcal{K}}^{\varphi^*\tilde{\Sigma}}$  of  $\mathscr{S}_{\mathcal{K}}$ ). The toroidal compactification  $\mathscr{S}_{\mathcal{K}}^{\varphi^*\tilde{\Sigma}}$  is defined as the normalization of the Zariski closure of  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathcal{K}}$  in  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . So one has maps  $\mathscr{S}_{\mathcal{K}}^{\Sigma} \to \mathscr{S}_{\mathcal{K}}^{\varphi^*\tilde{\Sigma}}$  and  $\mathscr{S}_{\mathcal{K}}^{\varphi^*\tilde{\Sigma}} \to \mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . Denote their composite by

(6.1.1) 
$$\varphi^{\Sigma/\tilde{\Sigma}}: \mathscr{S}^{\Sigma}_{\mathcal{K}} \to \mathscr{S}^{\tilde{\Sigma}}_{a,\tilde{\mathcal{K}}}.$$

If in addition  $\tilde{\Sigma}$  is smooth (and such rpcd's do exist), then  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  is smooth; if both  $\tilde{\Sigma}$  and  $\Sigma$  are chosen smooth (and again such choices do exist), then  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  is smooth too.

- <span id="page-22-2"></span>6.1.2. Compactification of the universal semi-abelian scheme. Let  $\tilde{\mathcal{A}}_g$  be the universal semi-abelian scheme over  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . Let  $\beta:\overline{\mathcal{A}}_g\to\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  be one of the compactifications of  $\tilde{\mathcal{A}}_g$  constructed in [21, §6.1] and [65, §2.B]. By [65, Prop. 3.19] (see also [21, Chap. VI, §1, Rmk. 1.4]), after possibly refining  $\tilde{\Sigma}$  (and a corresponding combinatorial datum used in the definition of  $\overline{\mathcal{A}}_g$ ) one can arrange that the structure map  $\beta$  is log integral (by [65, Prop 3.18] this is equivalent to  $\beta$  being equidimensional). In particular, by refining  $\Sigma$  one may ensure that  $\Sigma$  is a refinement of  $\varphi^*\tilde{\Sigma}$  for some  $\tilde{\Sigma}$  which admits a  $\beta$  which is log integral. The log integrality of  $\beta$  will be used to ensure that the Frobenius is well-behaved on the log de Rham cohomology of  $\mathscr{S}_{a,\tilde{K}}^{\tilde{\Sigma}}$ , see the proof of Lemma 6.2.3.
- <span id="page-22-4"></span>6.1.3. Extension of de Rham and Hodge bundles. By [21, Chap. 6, Th. 4.2 & preceding examples] and [65, Th. 2.15(d)],  $H^1_{\text{log-dR}}(\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$  is a rank 2g, locally free extension of  $H^1_{\text{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\mathcal{K}})$ . Let  $H^{1,\text{can}}_{\text{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}})$  be the canonical extension of  $H^1_{\text{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}})$  to  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . By loc. cit.,  $H^{1,\text{can}}_{\text{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}) = H^1_{\text{log-dR}}(\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$ .

By [65, Prop. 6.9(2)] the natural pairing on  $H^1_{\mathrm{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{K}})$  extends (uniquely) to a perfect pairing on  $H^{1,\mathrm{can}}_{\mathrm{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{K}})$ . The canonical extension  $\Omega_g^{\mathrm{can}} \subset H^{1,\mathrm{can}}_{\mathrm{dR}}(\mathcal{A}_g/\mathscr{S}_{g,\tilde{K}})$  is a maximal, totally isotropic, locally direct factor; it is also the pull-back along the identity section of  $\Omega^1_{\tilde{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{K}}}$ .

In the general case, pull back along  $\varphi^{\Sigma/\tilde{\Sigma}}$ : Put  $H^1_{\text{log-dR}}(\overline{\mathcal{A}}/\mathscr{S}_{\mathcal{K}}^{\Sigma}) := \varphi^{\Sigma/\tilde{\Sigma},*}H^1_{\text{log-dR}}(\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$  and  $\Omega^{\text{can}} := \varphi^{\Sigma/\tilde{\Sigma},*}\Omega_g^{\text{can}}$ ; these give locally free extensions of  $H^1_{\text{dR}}(\mathcal{A}_g/\mathscr{S}_{\mathcal{K}})$  and  $\Omega$  respectively, see also [77, 5.1.1]. Since the Hodge line bundle will be used so frequently, we abuse notation and continue to write  $\omega$  for det  $\Omega_g^{\text{can}}$  and  $\omega_g$  for det  $\Omega_g^{\text{can}}$ .

<span id="page-22-3"></span>6.1.4. Degeneration of the Hodge-de Rham spectral sequence and base change: The Siegel case. As in [65, Th. 2.15(3)(a)], lot

$$\overline{\Omega}^{1}_{\overline{\mathcal{A}}_{g}/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}} := \Omega^{1}_{\overline{\mathcal{A}}_{g}/\mathcal{O}_{E,\mathfrak{p}}}(d\log\infty)/\beta^{*}\Omega^{1}_{\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}/\mathcal{O}_{E,\mathfrak{p}}}(d\log\infty).$$

By Th. 2.15(3)(c) of loc. cit., the logarithmic Hodge-de Rham spectral sequence

$$(6.1.2) E_1^{i,j} := R^j \beta_* \overline{\Omega}_{\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}}^i \Rightarrow H^{i+j}_{\text{log-dR}}(\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$$

degenerates at  $E_1$  and the Hodge cohomology sheaves  $R^j \beta_* \overline{\Omega}_{\overline{A}_g/\mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}}}^i$  are locally free. As in *loc. cit.*, it follows that  $H^n_{\text{log-dR}}(\overline{A}_g/\mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}}) = \wedge^n H^1_{\text{log-dR}}(\overline{A}_g/\mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}})$  for all  $n \geq 0$ . Therefore  $H^n_{\text{log-dR}}(\overline{A}_g/\mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}})$  is also locally free for all  $n \geq 0$ . Applying [55, Cor. (8.6)] gives:

<span id="page-22-5"></span>**Lemma 6.1.1.** For all  $n \geq 0$ , formation of  $H^n_{\text{log-dR}}(\overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$  commutes with arbitrary base change.

<span id="page-23-3"></span>6.1.5. Extension of torsors and bundles. By [77, Prop. 5.3.2], the sections  $(s_{\alpha,dR})$  of §4.1.9 extend to  $H^1_{log-dR}(\mathcal{A}/\mathscr{S}_{\mathcal{K}}^{\Sigma})$ . Repeating the definition of  $I_{\mathcal{G}}, I_{\mathcal{P}}$  (§4.1.9) with  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$ , the extended sections and  $H^1_{log-dR}(\mathcal{A}/\mathscr{S}_{\mathcal{K}}^{\Sigma})$  give extensions to torsors  $I_{\mathcal{G}}^{\Sigma}, I_{\mathcal{P}}^{\Sigma}$  on  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$ . Again  $I_{\mathcal{L}}^{\Sigma} := I_{\mathcal{P}}^{\Sigma}/R_u(\mathcal{P})$  gives an  $\mathcal{L}$ -torsor on  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$ . Repeating the construction of §4.1.9 with  $I_{\mathcal{L}}^{\Sigma}$  in place of  $I_{\mathcal{L}}$  associates a vector bundle  $\mathscr{V}^{can}(\eta)$  on  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  with every  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . Let  $D = D_{\mathcal{K}}^{\Sigma}$  be the boundary divisor of  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  relative  $\mathscr{S}_{\mathcal{K}}$ . Set  $\mathscr{V}^{sub}(\eta) := \mathscr{V}^{can}(\eta)(-D)$ . Since D is a relative, effective Cartier divisor in  $\mathscr{S}_{\mathcal{K}}^{\Sigma}/\mathcal{O}_{E,\mathfrak{p}}$ , the sheaf  $\mathscr{V}^{sub}(\eta)$  is again locally free.

<span id="page-23-2"></span>6.1.6. The minimal compactification. Let  $\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\min}$  (resp.  $\mathscr{S}_{\mathcal{K}}^{\min}$ ) be the minimal compactification of  $\mathscr{S}_{g,\tilde{\mathcal{K}}}$  (resp.  $\mathscr{S}_{\mathcal{K}}$ ) constructed in [21, Chap. 5, Th. 2.3] (resp. [77, 5.2.1]). By construction, there are proper maps  $\pi: \mathscr{S}_{\mathcal{K}}^{\Sigma} \to \mathscr{S}_{\mathcal{K}}^{\min}$  and  $\pi_g: \mathscr{S}_{g,\tilde{\mathcal{K}}}^{\Sigma} \to \mathscr{S}_{g,\tilde{\mathcal{K}}}^{\min}$  satisfying  $\pi_*\mathcal{O}_{\mathscr{S}_{\mathcal{K}}^{\Sigma}} = \mathcal{O}_{\mathscr{S}_{\mathcal{K}}^{\min}}^{\min}$  and  $\pi_*\mathcal{O}_{\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\Sigma}} = \mathcal{O}_{\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\min}}^{\min}$ . It is expected that the higher direct images of  $\pi, \pi_g$  vanish in general; this is known in the PEL case, see Condition 7.1.2 and Rmk. 7.1.3. This issue will play an important role in §§7-10.

The Hodge line bundle  $\omega$  on  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  descends to an ample line bundle on  $\mathscr{S}^{\min}_{\mathcal{K}}$  independent of the rpcd  $\Sigma$  and still denoted  $\omega$  [77, 5.1.3, 5.2.1]. Applying the universal property of the minimal compactification [77, Lemma 5.2.2] to  $\mathscr{S}^{\min}_{\mathcal{K}}$ , the morphism  $\pi_g \circ \varphi^{\Sigma/\tilde{\Sigma}} : \mathscr{S}^{\Sigma}_{\mathcal{K}} \to \mathscr{S}^{\min}_{g,\tilde{\mathcal{K}}}$  and the ample line bundle  $\omega_g$  on  $\mathscr{S}^{\min}_{g,\tilde{\mathcal{K}}}$  shows that  $\pi_g \circ \varphi^{\Sigma/\tilde{\Sigma}}$  factors through  $\mathscr{S}^{\min}_{\mathcal{K}}$ . The result is a map

$$\varphi^{\min}: \mathscr{S}_{\mathcal{K}}^{\min} \to \mathscr{S}_{q,\tilde{\mathcal{K}}}^{\min}$$

Since  $\pi_g \circ \varphi^{\Sigma/\tilde{\Sigma}}$  and  $\pi$  are both proper, so is  $\varphi^{\min}$ . Observe that  $(\varphi^{\min})^*\omega_g = \omega$  and both  $\omega_g$  and  $\omega$  are ample (see §4.1.8 and the proof of [77, Th. 5.2.11(2)]). Therefore  $\varphi^{\min}$  is quasi-affine. As it is both quasi-affine and proper,  $\varphi^{\min}$  is finite.

<span id="page-23-4"></span>6.1.7.  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariance for toroidal compactifications. The notions of  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant sheaf, torsor, subscheme, section and G-Zip from §§4.1.10, 4.2 generalize to the (double) tower  $(\mathscr{S}_{\mathcal{K}}^{\Sigma})_{\mathcal{K}^p,\Sigma}$  of toroidal compactifications. Later we shall consider sub-towers consisting of all  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  such that  $\Sigma$  is required to satisfy some property P which is attainable by refinement (and no restriction is imposed on  $\mathcal{K}^p$ ); the examples of P which will occurr are: " $\Sigma$  smooth", " $\Sigma$  a refinement of  $\varphi^*\tilde{\Sigma}$  for some  $\tilde{\Sigma}$  which admits  $\beta$  log-integral" (§6.1.2) and their common intersection. Then  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariance is defined in the same way, except that we restrict to the morphisms  $\pi_{\mathcal{K}'/\mathcal{K}}^{\Sigma'/\Sigma}:\mathscr{S}_{\mathcal{K}'}^{\Sigma'}\to\mathscr{S}_{\mathcal{K}}^{\Sigma}$  and  $g_{\Sigma^g/\Sigma}^{-1}:\mathscr{S}_{g^{-1}\mathcal{K}g}^g\to\mathscr{S}_{\mathcal{K}}^\Sigma$ , where  $\Sigma$  has property P and  $\Sigma'$  (resp.  $\Sigma^g$ ) is a refinement of  $\pi_{\mathcal{K}'/\mathcal{K}}^*$  (resp.  $(g^{-1})^*\Sigma$ )) having property P.

The system of boundary subschemes  $(D_{\mathcal{K}}^{\Sigma})$  is  $\mathbf{G}(\mathbf{A}_{f}^{p})$ -equivariant. The torsors  $I_{\mathcal{G}}^{\Sigma}, I_{\mathcal{D}}^{\Sigma}, I_{\mathcal{L}}^{\Sigma}$  and the automorphic vector bundles  $\mathscr{V}^{\mathrm{can}}(\eta), \mathscr{V}^{\mathrm{sub}}(\eta)$  are all  $\mathbf{G}(\mathbf{A}_{f}^{p})$ -equivariant.

<span id="page-23-0"></span>6.2. Extension of the universal G-Zip. For the rest of §6, we assume that the rpcd  $\Sigma$  for  $(\mathbf{G}, \mathbf{X}, \mathcal{K})$  is a refinement of  $\varphi^*\tilde{\Sigma}$ , where the rpcd  $\tilde{\Sigma}$  for  $(GSp(2g), \mathbf{X}_g, \tilde{\mathcal{K}})$  has been chosen so that  $\beta$  is log integral (§6.1.2). By contrast, the rpcd  $\Sigma$  for  $(\mathbf{G}, \mathbf{X}, \mathcal{K})$  is not assumed to be smooth.

In this section, we prove:

<span id="page-23-1"></span>**Theorem 6.2.1** (Th. I.2.5). The G-zip  $\underline{I}$  (§4.2) extends to a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant G-zip  $\underline{I}^{\Sigma}$  over  $S_{\mathcal{K}}^{\Sigma}$ . In particular,  $\zeta_{\mathcal{K}}: S_{\mathcal{K}} \to G$ -Zip<sup> $\mu$ </sup> extends to

$$\zeta^{\Sigma}_{\mathcal{K}}: S^{\Sigma}_{\mathcal{K}} \to G\text{-}\mathrm{Zip}^{\mu},$$

and (4.2.6) extends to commutative triangles

$$(6.2.2) \qquad S_{\mathcal{K}'}^{\Sigma'} \searrow_{\mathcal{K}'}^{\Sigma'} \qquad S_{\mathcal{K}}^{\Sigma} \searrow_{\mathcal{K}}^{\Sigma} \qquad S_{\mathcal{K}}^{\Sigma} \searrow_{\mathcal{K}}^{\Sigma} \qquad S_{\mathcal{K}}^{\Sigma} \searrow_{\mathcal{K}}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1}\mathcal{K}g}^{\Sigma} \qquad S_{g^{-1}\mathcal{K}g}^{\Sigma} \searrow_{\mathcal{K}g^{-1$$

Define  $S_w^{\Sigma} := (\zeta_K^{\Sigma})^{-1}([E \backslash G_w])$  and  $S_w^{\Sigma,*} := (\zeta_K^{\Sigma})^{-1}([E \backslash \overline{G}_w])$  for all  $w \in {}^IW$ . Before embarking on the proof, note the following immediate, important corollary:

Corollary 6.2.2. The Hasse invariant  $h_w \in H^0(\overline{S}_w, \omega^{N_w})$  of Cor. 4.3.5 extends to a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant section  $h_w^{\Sigma} \in H^0(S_w^{\Sigma,*}, \omega^{N_w})$  with non-vanishing locus precisely  $S_w^{\Sigma}$ .

Let  $A_g/S_{g,\tilde{\mathcal{K}}}$  (resp.  $\tilde{A}_g/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}, \overline{A}_g/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ ) be the special fiber of  $\mathcal{A}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}$  (resp.  $\tilde{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}, \overline{\mathcal{A}}_g/\mathscr{S}_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ ) and similarly for  $H_{\mathrm{dR}}^{1,\mathrm{can}}(A_g/S_{g,\tilde{\mathcal{K}}})$  etc. (§6.1.3).

The Frobenius F and Verschiebung V of  $A_g/S_{g,\tilde{\mathcal{K}}}$  induce maps of  $\mathcal{O}_{S_{g,\tilde{\mathcal{K}}}}$ -modules  $F:(H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}}))^{(p)}\to H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}})$  and  $V:H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}})\to H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}})^{(p)}$ . These satisfy the usual conditions  $\mathrm{Ker}(F)=\mathrm{Im}(V)$ ,  $\mathrm{Ker}(V)=\mathrm{Im}(F)$ . The polarization of  $A_g$  induces perfect pairings on  $H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}})$  and  $H^1_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}})^{(p)}$  under which F,V are transpose to each other.

<span id="page-24-0"></span>**Lemma 6.2.3.** There exist two maps of locally free  $\mathcal{O}_{S_{\alpha,\tilde{\kappa}}}$ -modules

$$(6.2.3) F: H^{1,\operatorname{can}}_{\operatorname{dR}}(A_g/S_{g,\tilde{K}})^{(p)} \to H^{1,\operatorname{can}}_{\operatorname{dR}}(A_g/S_{g,\tilde{K}})$$

$$(6.2.4) V: H^{1,\operatorname{can}}_{\operatorname{dR}}(A_g/S_{g,\tilde{K}}) \to H^{1,\operatorname{can}}_{\operatorname{dR}}(A_g/S_{g,\tilde{K}})^{(p)}$$

<span id="page-24-1"></span>satisfying the following conditions

 $(\Omega_q^{\operatorname{can}})^{(p)} \subset \operatorname{Ker}(F).$ 

- (a) F, V extend the Frobenius and Verschiebung maps on  $H^1_{dR}(A_q/S_{q\tilde{K}})$ .
- <span id="page-24-2"></span>(b) Ker(F) = Im(V) and Ker(V) = Im(F).
- (c)  $\operatorname{Ker}(V)$  and  $\operatorname{Im}(V)$  are rank g locally free and locally direct summands of  $H_{\mathrm{dR}}^{1,\mathrm{can}}(A_g/S_{a,\tilde{K}})$ .

Proof. The Frobenius  $F: \overline{A}_g \to \overline{A}_g^{(p)}$  over  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  induces  $F: H^1_{\mathrm{log-dR}}(\overline{A}_g^{(p)}/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}) \to H^1_{\mathrm{log-dR}}(\overline{A}_g/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$ . Applying Lemma 6.1.1 to F gives  $H^1_{\mathrm{log-dR}}(\overline{A}_g^{(p)}/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}) \cong H^1_{\mathrm{log-dR}}(\overline{A}/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})^{(p)}$ . Together this yields a map as in (6.2.3).

To simplify notation, write  $\overline{\mathcal{M}} = H^1_{\mathrm{log-dR}}(\overline{A}_g/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$ . We have constructed an extension  $F:\overline{\mathcal{M}}^{(p)}\to \overline{\mathcal{M}}$  over  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . Define  $V:\overline{\mathcal{M}}\to \overline{\mathcal{M}}^{(p)}$  as its transpose with respect to the perfect pairings on  $\overline{\mathcal{M}}$  and  $\overline{\mathcal{M}}^{(p)}$ . Clearly, V extends the Verschiebung map on  $S_{g,\tilde{\mathcal{K}}}$ . It remains to check that F,V satisfy conditions (b) and (c) of the lemma. Since the relations FV=0 and VF=0 hold over  $S_{g,\tilde{\mathcal{K}}}$ , which is open dense in  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ , they continue to hold over  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . Hence  $\mathrm{Im}(F)\subset\mathrm{Ker}(V)$  and  $\mathrm{Im}(V)\subset\mathrm{Ker}(F)$ . On the other hand, we claim that  $(\Omega_g^{\mathrm{can}})^{(p)}\subset\mathrm{Ker}(F)$ . Indeed, F induces an injective morphism  $(\Omega_g^{\mathrm{can}})^{(p)}/((\Omega_g^{\mathrm{can}})^{(p)}\cap\mathrm{Ker}(F))\to\overline{\mathcal{M}}$ . Since we know the result over the open subscheme  $S_{g,\tilde{\mathcal{K}}}\subset S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ , the sheaf  $\mathcal{N}:=(\Omega_g^{\mathrm{can}})^{(p)}/((\Omega_g^{\mathrm{can}})^{(p)}\cap\mathrm{Ker}(F))$  restricts to zero on  $S_{g,\tilde{\mathcal{K}}}$ . But  $\mathcal{N}$  is a subsheaf of a locally free sheaf, and since  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  is reduced and  $S_{g,\tilde{\mathcal{K}}}$  is open dense, we deduce  $\mathcal{N}=0$ . Thus

Next, we claim that  $\operatorname{Im}(F)$  is a locally free sheaf on  $S_{g,\tilde{K}}^{\tilde{\Sigma}}$ . It suffices to show  $\dim_{k(x)}(\operatorname{Im}(F)\otimes k(x))=g$  for all  $x\in S_{g,\tilde{K}}^{\tilde{\Sigma}}$ . Since  $(\Omega_g^{\operatorname{can}})^{(p)}$  is locally a direct summand of  $\mathcal{M}^{(p)}$ , we have an injection  $(\Omega_g^{\operatorname{can}})^{(p)}\otimes k(x)\to \mathcal{M}^{(p)}\otimes k(x)$ , which shows  $\dim_{k(x)}(\operatorname{Im}(F)\otimes k(x))\leq g$ . The converse inequality follows simply from Nakayama's lemma because this dimension is g generically on  $S_{g,\tilde{K}}^{\tilde{\Sigma}}$ . This proves that  $\operatorname{Im}(F)$  is locally free of rank g.

For all  $x \in S_{g,\tilde{K}}^{\tilde{\Sigma}}$ , there is a natural surjection  $\operatorname{Im}(F) \otimes k(x) \to \operatorname{Im}(F_x)$ . In particular,  $\operatorname{rk}(F_x) \leq g$ . We claim that  $\operatorname{rk}(F_x) = g$ . To see this, consider  $\mathcal{M} := H^1_{\operatorname{log-crys}}(\overline{A}_g/S_{g,\tilde{K}}^{\tilde{\Sigma}})$ , endowed with its crystalline Frobenius  $\Phi$ . One has  $\mathcal{M} \otimes_{W(k)} k \simeq \overline{\mathcal{M}}$  and  $\Phi \otimes_{W(k)} k = F$  [70, Rmk. 1.5]. Recall that  $\tilde{\Sigma}$  was chosen so that  $\beta : \overline{\mathcal{A}}_g \to \mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}}$  is log integral. Using the log integrality of  $\beta$  it is checked in [70] that  $\mathscr{S}_{g,\tilde{K}}^{\tilde{\Sigma}}$  satisfies the two assumptions of Prop. 1.7 of loc. cit. (see esp. Prop. 1.13, Lemma 7.22 and its proof). In particular, the first implies that the top exterior power  $(\wedge^{2g}\mathcal{M}, \wedge^{2g}\Phi)$  is the  $\Phi$ -span  $\mathcal{O}_{S_{g,\tilde{K}}^{\tilde{\Sigma}}/W(k)}(-g)$  as defined by  $\operatorname{Ogus}^6$  [84, Def. 5.2.1]. This means that the map  $\wedge^{2g}\Phi : \wedge^{2g}\mathcal{M}^{(p)} \to \wedge^{2g}\mathcal{M}$  is Zariski locally on  $S_{g,\tilde{K}}^{\tilde{\Sigma}}$  equal to  $p^g$  times an isomorphism.

In particular, at the point x, the linear map  $\Phi_x: \mathcal{M}_x^{(p)} \to \mathcal{M}_x$  satisfies that  $\wedge^{2g}\Phi_x$  is  $p^g$  times an isomorphism. By the theory of invariant factors, there exist suitable bases of  $\mathcal{M}_x$  in which  $\Phi_x$  is given by the diagonal matrix  $\operatorname{diag}(p^{a_1},\ldots,p^{a_{2g}})$  for some integers  $a_i$  satisfying  $a_1 \geq \cdots \geq a_{2g} \geq 0$ . Since the unique invariant factor of  $\wedge^{2g}\Phi_x$  is  $p^g$ , the only possibility is that  $a_1 = \cdots = a_g = 1$  and  $a_{g+1} = \cdots = a_{2g} = 0$ . Since the reduction modulo p of  $(\mathcal{M}_x,\Phi_x)$  is  $(\mathcal{M}\otimes k(x),F_x)$ , one has  $\operatorname{rk}(F_x)=g$  as claimed.

Since  $F_x$  and  $V_x$  are transpose to each other, they have the same rank, so we deduce  $\operatorname{Ker}(F_x) = \operatorname{Im}(V_x)$  and  $\operatorname{Ker}(V_x) = \operatorname{Im}(F_x)$ . Since  $\operatorname{Im}(F)$  is locally free,  $\operatorname{Ker}(F)$  is locally a direct summand of  $\overline{\mathcal{M}}^{(p)}$ . Hence  $\operatorname{Ker}(F) \otimes k(x) \simeq \operatorname{Ker}(F_x) = \operatorname{Im}(V_x)$  for all  $x \in S_{g,\tilde{K}}^{\tilde{\Sigma}}$ . In particular, the inclusion  $\operatorname{Im}(V) \subset \operatorname{Ker}(F)$  induces a surjective map  $\operatorname{Im}(V) \otimes k(x) \to \operatorname{Ker}(F) \otimes k(x)$ . So  $(\operatorname{Ker}(F)/\operatorname{Im}(V)) \otimes k(x) = 0$ . Hence  $\operatorname{Ker}(F) = \operatorname{Im}(V)$  by Nakayama's lemma. Thus  $\operatorname{Ker}(V)$  is locally a direct factor of  $\mathcal{M}$ . By similar arguments,  $\operatorname{Ker}(V) = \operatorname{Im}(F)$ . This terminates the proof.  $\square$ 

Put  $\mathrm{Fil}_{g,\mathrm{conj}}^{\tilde{\Sigma}} := \mathrm{Ker}(V)$ . By Lemma 6.2.3,  $0 \subset \mathrm{Fil}_{g,\mathrm{conj}}^{\tilde{\Sigma}} \subset H^{1,\mathrm{can}}_{\mathrm{dR}}(A_g/S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}})$  extends the conjugate filtration (§4.2) to  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . Set  $\mathrm{Fil}_{\mathrm{conj}}^{\Sigma} := \varphi^{\Sigma/\tilde{\Sigma},*}\mathrm{Fil}_{g,\mathrm{conj}}$ . Then  $\mathrm{Fil}_{\mathrm{conj}}^{\Sigma}$  provides an extension of the conjugate filtration on

<span id="page-24-3"></span><sup>&</sup>lt;sup>6</sup>Ogus calls his spans F-spans since he uses F for the crystalline Frobenius.

 $H^{1,\mathrm{can}}_{\mathrm{dR}}(A/S_{\mathcal{K}}^{\Sigma})$  which is locally free and locally a direct summand. Replacing  $\mathrm{Fil}_{\mathrm{conj}}$  with  $\mathrm{Fil}_{\mathrm{conj}}^{\Sigma}$  in (4.2.4) gives an étale sheaf  $I_Q^{\Sigma}$  on  $S_{\mathcal{K}}^{\Sigma}$ . Furthermore,  $I_Q^{\Sigma}$  is endowed with a natural Q-action.

# <span id="page-25-4"></span>**Lemma 6.2.4.** The étale sheaf $I_Q^{\Sigma}$ is a Q-torsor on $S_{\mathcal{K}}^{\Sigma}$

Proof. We thank Torsten Wedhorn for his help with this. Choose an étale cover  $U \to S_K^{\Sigma}$  which trivializes the G-torsor  $I^{\Sigma}$ . Hence we have an isomorphism  $I^{\Sigma}|_{U} \simeq G \times U$ . The stabilizer of  $\mathrm{Fil}_{\mathrm{conj}}^{\Sigma}$  is a parabolic subgroup  $\mathcal Q$  of  $G \times U$ , and we need to show that it is étale locally on U isomorphic to Q. To check this, it suffices to show that  $Q \otimes k(x) \simeq Q \otimes k(x)$  at every point x. This follows from the fact that the type of the parabolic  $Q \otimes k(x)$  is a locally constant function, and that the result holds generically (on the open subset  $S_K$ ).

Proof of Th. 6.2.1: By §6.1.5 and Lemma 6.2.4, we have torsors  $I_G^{\Sigma}, I_P^{\Sigma}, I_Q^{\Sigma}$  for G, P, Q extending  $I_G, I_P, I_Q$  respectively. It remains to extend the isomorphisms  $\iota_0$ ,  $\iota_1$  to  $S_{\mathcal{K}}^{\Sigma}$  (§4.2). On  $S_{g,\tilde{\mathcal{K}}}$ , these isomorphisms are naturally induced by the maps F, V. Since these maps extend to  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  by Lemma 6.2.3, so do  $\iota_0$  and  $\iota_1$ . One obtains similar isomorphisms on  $S_{\mathcal{K}}^{\Sigma}$  by pull-back from  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ . This completes the construction of the G-zip  $\underline{I}^{\Sigma}$  over  $S_{\mathcal{K}}^{\Sigma}$ .

<span id="page-25-2"></span>6.3. Affineness in the minimal compactification. Let  $\pi: S_{\mathcal{K}}^{\Sigma} \to S_{\mathcal{K}}^{\min}$  be the natural projection. For  $w \in {}^{I}W$ , define

<span id="page-25-10"></span>
$$(6.3.1) S_w^{\min} := \pi(S_w^{\Sigma})$$

<span id="page-25-0"></span>
$$(6.3.2) S_w^{\min,*} := \pi(S_w^{\Sigma,*}).$$

By (6.2.2) (with  $\mathcal{K}' = \mathcal{K}$ ) the above definitions are invariant under a refinement  $\Sigma_0 \subset \Sigma$  (corresponding again to a  $\beta$  which is log integral (§6.1.2)). Hence  $S_w^{\min}$  and  $S_w^{\min,*}$  are independent of  $\Sigma$ . Part (c) of the following proposition is Cor. I.2.6.

#### <span id="page-25-9"></span><span id="page-25-6"></span><span id="page-25-1"></span>Proposition 6.3.1.

- (a) The  $S_w^{\min}$  are pairwise disjoint and locally closed.
- (b) The Stein factorization of  $\pi: \overline{S}_w^{\Sigma} \to \overline{S}_w^{\min}$  is given by  $\pi = f \circ g$  where  $g: \overline{S}_w^{\Sigma} \to T$  is proper with connected fibers such that  $g_*\mathcal{O}_{\overline{S}_w^{\Sigma}} = \mathcal{O}_T$ , and  $f: T \to \overline{S}_w^{\min}$  is a finite morphism which is a universal homeomorphism.
- <span id="page-25-5"></span>(c) The stratum  $S_w^{\min}$  is affine.

Remark 6.3.2. Prop. 6.3.1(a) affords a decomposition of  $S_{\mathcal{K}}^{\min}$  into disjoint, locally closed subsets:

$$S_{\mathcal{K}}^{\min} = \bigsqcup_{w \in {}^{I}W} S_{w}^{\min}.$$

For Siegel-type Shimura varieties, it follows from [28, §5] that (6.3.3) is a stratification; for PEL Shimura varieties of type A and C this, as well as the fact that  $h_w^{\Sigma}$  descends to  $\overline{S}_w^{\min}$  is proved in [10, Th. 6.1.6, Th. 6.2.3]. In the general Hodge case, these properties should follow from [68].

6.3.1. Comparison with Ekedahl-van der Geer [28]. We shall first prove Prop. 6.3.1(a) in the Siegel case and then reduce the general case to the Siegel one. For the Siegel case, we need to compare the extension of the EO stratification to  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  afforded by Th. 6.2.1 with the extension defined in [28, §5].

Recall that the Weyl group  $W_g$  of GSp(2g) is realized concretely as a subgroup of the symmetric group  $S_{2g}$  via

<span id="page-25-7"></span><span id="page-25-3"></span>
$$W_q = \{ w \in S_{2q} \mid w(j) + w(2g+1-j) = 2g+1 \text{ for all } 1 \le j \le g \}.$$

Let  $\rho_i: W_{g-i} \to W_g$  be the natural embedding, defined for  $w' \in W_{g-i}$  by  $\rho_i(w')(j) = i + w'(j)$  for  $1 \le j \le g - i$  and  $\rho_i(w')(j) = g + j$  for all  $g - i + 1 \le j \le g$ . It satisfies  $\rho_i(W_{g-i}) \cap {}^IW_g = \rho_i({}^IW_{g-i})$ .

Every k-point  $x \in S_{q,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  admits an underlying semi-abelian scheme  $\tilde{A}$ , which is an extension

$$(6.3.4) 1 \to T \to \tilde{A} \to A \to 1$$

of an abelian scheme A by a torus T. Define  $S_{g,\tilde{\mathcal{K}}}^{\langle i\rangle}$  to consist of  $x\in S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  such that the dimension of the torus part is  $i=\dim(T)$ . The EO stratification of  $S_{g,\tilde{\mathcal{K}}}$  is extended to  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$  in [28, §5] by defining the stratum  $S_{g,w}^{\langle i\rangle}\subset S_{g,\tilde{\mathcal{K}}}^{\langle i\rangle}$  corresponding to  $w\in S_{g,\tilde{\mathcal{K}}}^{I}$  to consist of  $x\in S_{g,\tilde{\mathcal{K}}}^{\langle i\rangle}$  such that, if the EO stratum of the abelian part is given by  $w'\in S_{g,w}^{I}$  to be the union of the  $S_{g,w}^{\langle i\rangle}$  over all i.

<span id="page-25-8"></span>**Lemma 6.3.3** (Comparison). Let  $S_{g,w}^{\bar{\Sigma}}$  be the EO strata defined by pulling back the stratification of GSp(2g)-Zip<sup> $\mu_g$ </sup> along  $\zeta_{g,\mathcal{K}}^{\bar{\Sigma}}: S_{g,\mathcal{K}}^{\bar{\Sigma}} \to GSp(2g)$ -Zip<sup> $\mu_g$ </sup>. Then  $'S_{g,w}^{\bar{\Sigma}} = S_{g,w}^{\bar{\Sigma}}$ .

Proof. It suffices to prove that the two extensions of the EO stratifiation agree one boundary stratum at a time, i.e., to show that  $S_{g,w}^{\tilde{\Sigma}} \cap S_{g,\tilde{K}}^{(i)} = S_{g,w}^{\tilde{\Sigma}} \cap S_{g,\tilde{K}}^{(i)}$  for all i. As in [77, 4.3.1], there is a universal, polarized 1-motive over  $S_{g,\tilde{K}}^{(i)}$ ; let  $H_{dR}^{1,(i)}$  denote its (contravariant) de Rham realization (loc. cit., 1.1.3 and [2, 4.3]). It is a locally free sheaf of rank 2g equipped with a non-degenerate symplectic pairing, induced from the polarization of the 1-motive. By the characterization of  $H_{dR}^{1,(i)}$  as a canonical extension in [77, 4.3.1] and the characterization of  $H_{dR}^{1,(a)}(A_g/S_{g,\tilde{K}}) = H_{\log-dR}^{1,(a)}(\overline{A}_g/S_{g,\tilde{K}})$  in [65, Th. 2.15(3)(d)], the restriction of  $H_{\log-dR}^{1}(\overline{A}_g/S_{g,\tilde{K}})$  to  $S_{g,\tilde{K}}^{(i)}$  is  $H_{dR}^{1,(i)}$ . The de Rham realization  $H_{dR}^{1,(i)}$  admits a 3-step weight filtration by locally free sheaves

<span id="page-26-0"></span>
$$(6.3.5) (0) \subset W_0 H_{\mathrm{dR}}^{1,\langle i \rangle} \subset W_1 H_{\mathrm{dR}}^{1,\langle i \rangle} \subset W_2 H_{\mathrm{dR}}^{1,\langle i \rangle} = H_{\mathrm{dR}}^{1,\langle i \rangle}.$$

The weight filtration is symplectic in the sense that the orthogonal  $(W_j H_{\mathrm{dR}}^{1,\langle i \rangle})^{\perp}$  of  $W_j H_{\mathrm{dR}}^{1,\langle i \rangle}$  is  $W_{2-j} H_{\mathrm{dR}}^{1,\langle i \rangle}$ . Let  $\mathrm{Gr}_j^W := \mathrm{Gr}_j^W H_{\mathrm{dR}}^{1,\langle i \rangle}$  denote the associated graded. The symplectic pairing on  $H_{\mathrm{dR}}^{1,\langle i \rangle}$  induces non-degenerate pairings on the complementary graded pieces, i.e.,

<span id="page-26-1"></span>
$$(6.3.6) \qquad \operatorname{Gr}_1^W \times \operatorname{Gr}_1^W \to \mathcal{O}_{S_{g,\bar{\mathcal{K}}}^{\langle i \rangle}} \text{ and } \operatorname{Gr}_0^W \times \operatorname{Gr}_2^W \to \mathcal{O}_{S_{g,\bar{\mathcal{K}}}^{\langle i \rangle}}.$$

The middle graded piece  $\operatorname{Gr}_1^W$  is given by the de Rham cohomology of the abelian part of the universal 1-motive, i.e.,  $\operatorname{Gr}_1^W = H^1_{\operatorname{dR}}(A_{g-i}/S_{g-i,\overline{\mathcal{K}}})$ , where  $\overline{\mathcal{K}} \subset GSp(2(g-i), \mathbf{A}_f)$  is the corresponding level subgroup and as before  $A_{g-i}$  denotes the universal abelian scheme over  $S_{g-i,\overline{\mathcal{K}}}$ . By definition, a polarization of a 1-motive induces one of its abelian part [77, 1.1.1], so the pairing on  $\operatorname{Gr}_1^W = H^1_{\operatorname{dR}}(A_{g-i}/S_{g-i,\overline{\mathcal{K}}})$  induced from  $H^{1,\langle i \rangle}_{\operatorname{dR}}$  agrees with the one induced from the polarization of  $A_{g-i}/S_{g-i,\overline{\mathcal{K}}}$ .

Consider the fiber of (6.3.5) over a k-point  $x \in S_{g,\tilde{K}}^{\langle i \rangle}$  with underlying semi-abelian scheme  $\tilde{A}$  (6.3.4). We get a filtration of k-vector spaces stable by F and V, viewed as  $\sigma$ -linear and  $\sigma^{-1}$ -linear maps respectively. We claim that there is a (non-canonical) splitting which is stable under both F and V. Set  $H_{dR,x}^{1,\langle i \rangle} := H_{dR}^{1,\langle i \rangle} \otimes k(x)$ ,  $W_{j,x} := W_j H_{dR}^{1,\langle i \rangle} \otimes k(x)$  and  $Gr_{j,x}^W := Gr_j^W \otimes k(x)$ . The action of F (resp. V) on  $Gr_{0,x}^W$  (resp.  $Gr_{2,x}^W$ ) is invertible (cf. [2, 4.3]).

Recall the following elementary fact of  $\sigma$ -linear algebra: Assume N is a k-vector space,  $f: N \to N$  is a  $\sigma$ -linear map and N' is a subspace stable by f. If f is invertible on either N' or the quotient N/N', then there is a (noncanonical) f-stable splitting  $N = N' \oplus N/N'$ .

Applying the  $\sigma$ -linear algebra fact with  $N=W_{1,x}$ ,  $N'=W_{0,x}$  and f=F gives an F-stable complement  $\widetilde{\mathrm{Gr}}_{1,x}^W$  to  $W_{0,x}$  in  $W_{1,x}$ . Since the first pairing in (6.3.6) is perfect and also induced from that of  $H^{1,\langle i\rangle}_{\mathrm{dR}}$ , the restriction of the pairing on  $H^{1,\langle i\rangle}_{\mathrm{dR},x}$  to  $\widetilde{\mathrm{Gr}}_{1,x}^W$  is perfect. Therefore one has

<span id="page-26-2"></span>
$$(6.3.7) H^{1,\langle i\rangle}_{\mathrm{dR},x} = \widetilde{\mathrm{Gr}}^{W}_{1,x} \oplus (\widetilde{\mathrm{Gr}}^{W}_{1,x})^{\perp}.$$

We claim that both summands in (6.3.7) are both F-stable and V-stable. Since F, V are transpose to each other, the orthogonal  $(\widetilde{\operatorname{Gr}}_{1,x}^W)^{\perp}$  is V-stable. Further,  $W_{1,x}\cap (\widetilde{\operatorname{Gr}}_{1,x}^W)^{\perp}=W_{0,x}$ , so  $(\widetilde{\operatorname{Gr}}_{1,x}^W)^{\perp}/W_{0,x}=\operatorname{Gr}_{2,x}^W$ . Since V is invertible on  $\operatorname{Gr}_{2,x}^W$ , there exists a V-stable complement  $\widetilde{\operatorname{Gr}}_{2,x}^W$  to  $W_{0,x}$  in  $(\operatorname{Gr}_{1,x}^W)^{\perp}$ . The relation FV=0 on  $H_{\operatorname{dR},x}^{1,(i)}$  implies that F is zero on  $\widetilde{\operatorname{Gr}}_{2,x}^W$ . Since  $W_{0,x}$  is F-stable, we conclude that  $(\widetilde{\operatorname{Gr}}_{1,x}^W)^{\perp}$  is F-stable. Applying the transpose relation again gives that  $\widetilde{\operatorname{Gr}}_{1,x}^W$  is V-stable.

<span id="page-26-3"></span>Therefore the weight filtration (6.3.5) at the point x admits a (noncanonical) splitting

$$(6.3.8) H_{\mathrm{dR}_x}^{1,\langle i\rangle} = \widetilde{\mathrm{Gr}}_{1,x}^W \oplus (W_{0,x} \oplus \widetilde{\mathrm{Gr}}_{2,x}^W)$$

stable by F and V and compatible with the pairing on  $H^{1,\langle i\rangle}_{\mathrm{dR},x}$ . In other words (6.3.8) shows that the symplectic similitude F-Zip  $H^{1,\langle i\rangle}_{\mathrm{dR},x}$  is the sum of the two symplectic similitude F-Zips  $\widetilde{\mathrm{Gr}}^W_{1,x}$  and  $W_{0,x} \oplus \widetilde{\mathrm{Gr}}^W_{2,x} = (\widetilde{\mathrm{Gr}}^W_{1,x})^{\perp}$ . The first  $\widetilde{\mathrm{Gr}}^W_{1,x}$  is isomorphic to the symplectic similitude F-zip attached to the abelian part A and the second  $W_{0,x} \oplus \widetilde{\mathrm{Gr}}^W_{2,x}$  is ordinary. It now follows easily that  $x \in S^{\tilde{\Sigma}}_{g,w}$  if and only if the element  $w' \in {}^IW_{g-i}$  classifying the EO stratum of the abelian part A satisfies  $\rho_i(w') = w$ .

Remark 6.3.4. The proof of Lemma 6.3.3 is similar to [68, Lemmas 3.2.6, 3.4.3] which uses the language of Raynaud extensions instead of 1-motives. Lemma 6.3.3 is also implicit in [28, §5] but it seems to us that the arguments in [28, §5] may be incomplete. We thank the referee for suggesting to us that there might be an issue with [28, §5].

Proof of Prop. 6.3.1: We prove that the  $S_w^{\min}$  are disjoint and locally closed by first explaining why it is true in the Siegel case and then reducing to that case. Since  $\pi$  maps a semi-abelian k-scheme  $\tilde{A}$  to its abelian part A, in view of the definition of the  $S_w^{\tilde{\Sigma}}$  recalled above, the disjointness of the images  $\pi(S_w^{\tilde{\Sigma}})$  is just the injectivity of  $\rho_i:W_{g-i}\to W_g$ . Thus the disjointness of the  $S_w^{\min}$  in the Siegel case follows from the comparison Lemma 6.3.3.

Let  $\mu_q: \mathbf{G}_{m,k} \to GSp(2g)$  denote the cocharacter  $\varphi \circ \mu$  and  $\bar{\varphi}^{\mathrm{zip}}: G\text{-}\mathrm{Zip}^{\mu} \to GSp(2g)\text{-}\mathrm{Zip}^{\mu_g}$  the induced morphism of stacks. Write  $\bar{\varphi}^{Sh}$ ,  $\bar{\varphi}^{\Sigma/\tilde{\Sigma}}$ ,  $\bar{\varphi}^{min}$  for the special fiber of  $\varphi^{Sh}$ ,  $\varphi^{\Sigma/\tilde{\Sigma}}$ ,  $\varphi^{min}$ . Combining §§6.1.1-6.1.6 with Th. 6.2.1 gives rise to the commutative diagram:

![](_page_27_Figure_2.jpeg)

Let  $x \to S_{\mathcal{K}}^{\min}$  be a geometric point, and let  $X := \pi^{-1}(x)$  be its fiber in  $S_{\mathcal{K}}^{\Sigma}$ . Note that X is connected. Combining the disjointness of the strata of  $S_{g,\tilde{\mathcal{K}}}^{\min}$  in the Siegel case with the commutativity of the diagram, this implies that  $\bar{\varphi}^{\Sigma/\tilde{\Sigma}}(X)$  is contained in a single EO stratum of  $S^{\tilde{\Sigma}}_{g,\tilde{\mathcal{K}}}$ . Hence  $\zeta^{\Sigma}_{\mathcal{K}}(X)$  is a connected subset of G-Zip $^{\mu}$  that maps to a single point by  $\bar{\varphi}^{zip}$ . Since  $\bar{\varphi}^{zip}$  has discrete fibers by Th. 3.3.1, we deduce that  $\zeta_{\mathcal{K}}^{\Sigma}(X)$  is a singleton, hence X is contained in a single EO stratum. This shows that

<span id="page-27-1"></span>(6.3.9) 
$$\pi^{-1}(S_w^{\min}) = S_w^{\Sigma} \text{ and } \pi^{-1}(S_w^{\min,*}) = S_w^{\Sigma,*}.$$

In particular, the  $S_w^{\min}$  are pairwise disjoint.

Next we show that the  $S_w^{\min}$  are locally closed. Since  $\zeta_K^{\Sigma}$  is continuous,  $S_w^{\Sigma,*}$  is closed in  $S_K^{\Sigma}$ . The complement of  $S_w^{\Sigma}$  in  $S_w^{\Sigma,*}$  is also closed, as it is the finite union of the  $S_w^{\Sigma,*}$  for all  $w' \preccurlyeq w$  in  ${}^IW$ . Since  $\pi$  is proper, the images  $\pi(S_w^{\Sigma,*})$  and  $\pi(S_w^{\Sigma,*} \setminus S_w^{\Sigma})$  are both closed in  $S_K^{\min}$ . Since the  $S_w^{\min}$  are disjoint,  $\pi(S_w^{\Sigma}) = S_w^{\min}$  is the complement of  $\pi(S_w^{\Sigma,*} \setminus S_w^{\Sigma})$  in  $\pi(S_w^{\Sigma,*})$ . Hence  $\pi(S_w^{\Sigma}) = S_w^{\min}$  is locally closed.

The Stein factorization of the map  $\pi: \overline{S}_w^{\Sigma} \to \overline{S}_w^{\min}$  gives a scheme T with a finite map  $f: T \to \overline{S}_w^{\min}$ , such that  $\pi$  factors through a proper map  $g: \overline{S}_w^{\Sigma} \to T$  with connected fibers, satisfying  $g_*\mathcal{O}_{\overline{S}_w^{\Sigma}} = \mathcal{O}_T$ . By (6.3.9), we see that

 $\pi$  has connected fibers, hence f has connected fibers. It follows that f is a universal homeomorphism. This proves

Finally, we prove (c). Denote again by  $\omega$  the line bundle  $f^*\omega$  on T. Note that  $\omega$  is again ample on T. Since  $g_*\mathcal{O}_{\overline{S}_w^{\Sigma}} = \mathcal{O}_T$ , it follows from the projection formula that  $g_*\omega = \omega$ . In particular, the section  $h_w^{\Sigma}$  descends to a section  $h_T \in H^0(T, \omega^{N_w})$ . The non-vanishing locus  $U \subset T$  of  $h_T$  satisfies  $g^{-1}(U) = S_w^{\Sigma}$ . Using again (6.3.9), we deduce  $U = f^{-1}(S_w^{\min})$ . Since  $\omega$  is ample on T, the open U is affine, and hence  $S_w^{\min} = f(U)$  is affine by a theorem of Chevalley.

<span id="page-27-0"></span>6.4. The length stratification of Hodge-type Shimura varieties. We apply  $\S 5.2$  to  $\zeta_{\mathcal{K}}^{\Sigma}: S_{\mathcal{K}}^{\Sigma} \to G$ -Zip<sup> $\mu$ </sup>. Write  $S_i^{\Sigma}$  and  $S_i^{\Sigma,*}$  for the length strata in  $S_K^{\Sigma}$ .

Assumption (a) of Prop. 5.2.3 follows from [77, Th. 2]. Assumption (b) was proved in the PEL case in [105, Th. 2], and has recently been generalized to general Hodge-type Shimura varieties, see [112, 57, 76]. This also follows from [104] using a different language. As for Assumption (c):

<span id="page-27-2"></span>**Lemma 6.4.1.** Suppose  $\varphi$  (§4.1.4) is a PEL embedding. Then  $S_e^{\Sigma}$  intersects the boundary trivially, i.e.,  $S_e = S_e^{\Sigma}$ . In particular,  $S_e^{\Sigma}$  is zero-dimensional.

*Proof.* The lemma is trivial when  $(\mathbf{G}, \mathbf{X})$  is of compact type, so assume it is not. By [6, Lemma 3.2(b)], this implies that  $\mathbf{G}^{\mathrm{ad}}(\mathbf{R})$  has no compact factors. Since  $S_e \subset S_e^{\Sigma}$ , the latter is nonempty as well. The image  $\varphi^{\Sigma/\tilde{\Sigma}}(S_e^{\Sigma}) \subset S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}}$ is contained in a unique Siegel stratum  $S_{g,w}^{\tilde{\Sigma}}$  (for a unique  $w \in {}^IW_g$ ). So it suffices to show that  $S_{g,w}^{\tilde{\Sigma}}$  does not meet the boundary of  $S_{g,\tilde{K}}^{\tilde{\Sigma}}$ . Recall that the multiplicative rank of a group scheme H of p-power order is  $\operatorname{mult} \operatorname{rk}(H) := \dim \operatorname{Hom}(\mu_p, H)$ . The desired inclusion  $S_{g,w}^{\tilde{\Sigma}} \subset S_{g,\tilde{\mathcal{K}}}$  follows from the following claims:

- <span id="page-28-5"></span><span id="page-28-4"></span>(a) For every boundary point x of  $S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}} \backslash S_{g,\tilde{\mathcal{K}}}$ , the underlying semi-abelian variety  $\tilde{A}$  (6.3.4) has mult  $\operatorname{rk} \tilde{A}[p] > 0$ .
- <span id="page-28-6"></span>(b) The multiplicative rank is constant along the strata  $S_{q,w}^{\Sigma}$  for  $w \in W_q$ .
- (c) The stratum  $S_{g,w}^{\tilde{\Sigma}}$  containing  $S_e^{\Sigma}$  has multiplicative rank 0.

Claim (a) is clear: A boundary point  $x \in S_{g,\tilde{\mathcal{K}}}^{\tilde{\Sigma}} \setminus S_{g,\tilde{\mathcal{K}}}$  necessarily has a nontrivial torus part T; if the torus part has dimension dim T = j > 0, one has mult rk  $\tilde{A} \geq j$ .

Now consider (b). It follows from [83, §15] that  $\operatorname{multrk} \tilde{A}$  is the semisimple rank of  $V: H^0(\tilde{A}, \Omega^1_{\tilde{A}}) \to H^0(\tilde{A}, \Omega^1_{\tilde{A}_x})^{(p)}$ , since V induces an isomorphism on the differentials of the torus part T. In view of the transpose relation between F and V, s is also the semisimple rank of  $F: (\ker V)^{(p)} \to \ker V$ . Since the semisimple rank is equal to the stable rank (i.e., the rank of all sufficiently large powers of F), one sees that s is an invariant of the GSp(2g)-Zip  $I_x^{\Sigma}$  associated to x by Th. 6.2.1.

To prove (c), by (b) it is enough to show that the multiplicative rank of the underlying abelian variety of a point of  $S_e$  is zero, under the assumption that  $\mathbf{G}^{\mathrm{ad}}(\mathbf{R})$  has no compact factors. This can be checked case-by-case using Moonen's "standard objects" [81, §§4.9,5.8]. (Given  $w \in {}^{I}W$ , the associated standard object is an explicit representative of the isomorphism class of the G-Zips of type w.)

It is expected that Lemma 6.4.1 remains true for an arbitrary Shimura variety of Hodge type. For now we single this out as a condition; it will play an important role in §§8,10.

<span id="page-28-1"></span>Condition 6.4.2. The minimal EO stratum  $S_e^{\Sigma}$  has dimension zero.

Remark 6.4.3. As in Lemma 6.4.1, Condition 6.4.2 holds when  $S_e^{\Sigma}$  does not meet the boundary, i.e., when  $S_e = S_e^{\Sigma}$ .

Putting together Props. 5.2.2, 5.2.3 and Lemma 6.4.1 gives the following result on length strata of Hodge-type Shimura varieties and their Hasse invariants:

<span id="page-28-9"></span>Corollary 6.4.4. Assume (G, X) is of PEL-type, or that  $S_K^{\Sigma}$  satisfies Condition 6.4.2. Then:

- (a) The length strata  $S_j^{\Sigma}$  and  $S_j^{\Sigma,*}$  are equi-dimensional of dimension j, and  $S_j^{\Sigma}$  is open dense in  $S_j^{\Sigma,*}$ .
- (b) For  $w \in {}^{I}W$ ,  $S_{w}^{\Sigma}$  is equi-dimensional of dimension  $\ell(w)$ . (c) For every j, there exists  $N_{j} \geq 1$  and a  $\mathbf{G}(\mathbf{A}_{f}^{p})$ -equivariant  $h_{j} \in H^{0}(S_{j}^{\Sigma,*}, \omega^{N_{j}})$  satisfying nonvanish $(h_{j}) = 0$

<span id="page-28-0"></span>We call the  $h_i$  the length Hasse invariants of  $S_K^{\Sigma}$ 

# 7. Geometry of Hasse regular sequences

7.1. Cohomological vanishing on  $\mathscr{S}_{\mathcal{K}}^{\Sigma,n}$ . The following variant of "cohomology and base change" will be used to reduce vanishing statements to the special fiber.

<span id="page-28-8"></span>**Lemma 7.1.1.** Let  $(R,\mathfrak{m})$  be a Noetherian local ring,  $f:X\to\operatorname{Spec} R$  a proper morphism, and  $\mathcal{F}$  a coherent  $\mathcal{O}_X$ -module, flat over R. Denote by x the point  $\mathfrak{m} \in \operatorname{Spec} R$ . Assume that  $H^i(X_x, \mathcal{F}_x) = 0$  for  $i \geq 0$ . Then

In particular,  $H^i(X_n, \mathcal{F}_n) = 0$  for all  $n \geq 1$ , where  $X_n = X \times_R R/\mathfrak{m}^n$  and  $\mathcal{F}_n$  is the pullback of  $\mathcal{F}$  via  $X_n \to X$ .

*Proof.* The base change map  $\varphi^i(x): R^i f_*(\mathcal{F})_x \otimes k(x) \longrightarrow H^i(X_x, \mathcal{F}_x)$  is surjective, because its target is zero by assumption. By "cohomology and base change" (see [51, Th. 12.11(a)] in the projective case and [46, §7] in general). the map  $\varphi^i(x)$  is an isomorphism. Hence  $R^i f_*(\mathcal{F})_x \otimes k(x) = 0$ . Since Spec R is affine,  $R^i f_*(\mathcal{F}) = H^i(X, \mathcal{F})^{\sim}$ , and  $H^{i}(X,\mathcal{F})$  is a finite type R-module since f is proper. So the first statement follows from Nakayama's lemma.

The second part of the lemma follows from the first one applied to the base change  $X_n \to \operatorname{Spec} R/\mathfrak{m}^n$ .

The next condition on the vanishing of higher direct images is key to studying cohomological vanishing on  $\mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  and its subschemes. Recall that  $S_{\mathcal{K}}^{\Sigma} := \mathscr{S}_{\mathcal{K}}^{\Sigma,1}$ . Denote by  $\pi: S_{\mathcal{K}}^{\Sigma} \to S_{\mathcal{K}}^{\min}$  the natural map.

<span id="page-28-2"></span>Condition 7.1.2. Let  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . The pair  $(\mathscr{S}_{\mathcal{K}}^{\Sigma}, \eta)$  satisfies  $R^i \pi_* \mathscr{V}^{\mathrm{sub}}(\eta) = 0$  for all i > 0.

<span id="page-28-3"></span>Remark 7.1.3. In the PEL case, Condition 7.1.2 is a theorem of Lan [72, Theorem 8.2.1.2]. See also [67] for a simpler argument under a mild additional hypothesis on p. In the general Hodge case, 7.1.2 is a theorem of Stroh<sup>7</sup> in [100] when  $\eta \in \mathbf{Q}\eta_{\omega}$ .

Recall the convention regarding notation established in  $\S N.2.3$ :  $\mathscr{S}^{\Sigma,+}_{\mathcal{K}} := \mathscr{S}^{\Sigma}_{\mathcal{K}}$  and  $\mathscr{S}^{\Sigma,0}_{\mathcal{K}}$  is its generic fiber.

<span id="page-28-7"></span><sup>&</sup>lt;sup>7</sup>Stroh's result is unpublished, but it follows directly from the combination of [67] and [69].

<span id="page-29-0"></span>**Lemma 7.1.4.** Assume  $(S_K^{\Sigma}, \eta)$  satisfies Condition 7.1.2. Then there exists  $m_0 = m_0(\eta) \ge 1$  such that, for all  $n \in \mathbb{Z}_{>0} \cup \{+\}$ , all  $m \ge m_0$  and all i > 0, one has

(7.1.1) 
$$H^{i}(\mathscr{S}_{\mathcal{K}}^{\Sigma,n},\mathcal{V}_{n}^{\mathrm{sub}}\otimes\omega^{m})=0.$$

*Proof.* By cohomology and base change (Lemma 7.1.1), it suffices to prove (7.1.1) when n = 1. By Condition 7.1.2 and the projection formula, the Leray spectral sequence degenerates for  $\pi$  and  $\mathscr{V}^{\text{sub}}(\eta) \otimes \omega^m$ . Hence

$$(7.1.2) H^{i}(S_{\mathcal{K}}^{\Sigma}, \mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^{m}) = H^{i}(S_{\mathcal{K}}^{\min}, \pi_{*}(\mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^{m})) = H^{i}(S_{\mathcal{K}}^{\min}, (\pi_{*}\mathcal{V}^{\mathrm{sub}}(\eta)) \otimes \omega^{m}).$$

Since  $\pi$  is proper,  $\pi_* \mathscr{V}^{\mathrm{sub}}(\eta)$  is coherent. Since  $\omega$  is ample on  $\mathscr{S}_{\mathcal{K}}^{\min}$ , (7.1.2) is zero for all sufficiently large m by Serre's cohomological criterion for ampleness.

Corollary 7.1.5. Assume  $(S_K, \eta)$  satisfies Condition 7.1.2. Let  $m_0 = m_0(\eta)$  be as in Lemma 7.1.4. Then

<span id="page-29-9"></span>(7.1.3) 
$$H^{0}(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{m}) \longrightarrow H^{0}(\mathscr{S}^{\Sigma, n}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{m})$$

is surjective for all  $m > m_0$ .

*Proof.* Let  $\varpi \in \mathcal{O}_{\mathfrak{p}}$  be a uniformizer. Multiplication by  $\varpi^n$  yields a short exact sequence

$$(7.1.4) 0 \longrightarrow \mathcal{O}_{\mathfrak{p}} \xrightarrow{\varpi^n} \mathcal{O}_{\mathfrak{p}} \longrightarrow \mathcal{O}_{\mathfrak{p}}/\mathfrak{p}^n \longrightarrow 0$$

and a long exact sequence of cohomology

<span id="page-29-1"></span>
$$(7.1.5) H^0(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^m) \longrightarrow H^0(\mathscr{S}^{\Sigma,n}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^m) \longrightarrow H^1(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^m) .$$

By Lemma 7.1.4, the right-hand term in (7.1.5) is zero when  $m \geq m_0$ .

7.2. Hasse-regular sequences. The next definition singles out those  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant subschemes of a Shimura variety (modulo a prime power) which are obtained as successive zero schemes of length Hasse invariants (§5.2, §6.4). Let  $(\mathscr{S}_{\mathcal{K}}^{\Sigma,n})_{\mathcal{K}^p,\Sigma}$  be the reduction modulo  $\mathfrak{p}^n$  of the tower introduced in §6.1.7.

<span id="page-29-3"></span>**Definition 7.2.1.** A Hasse-regular sequence of length r in  $(\mathscr{S}_{\mathcal{K}}^{\Sigma,n})_{\mathcal{K}^p,\Sigma}$  is the data, for each pair  $(\mathcal{K}^p,\Sigma)$  of a sequence  $(Z_j,a_j,f_j)_{i=0}^r$  satisfying:

- (a) One has  $Z_0 = \mathscr{S}^{\Sigma,n}_{\mathcal{K}}$  and  $(a_j)_{j=0}^r$  is a sequence of positive integers independent of  $\mathcal{K}^p, \Sigma$ .
- (b) For all j > 0,  $Z_j \subset Z_{j-1}$  is a closed subscheme with  $(Z_j)_{\text{red}} = S_{d-j}^{\Sigma,*}$ , the (d-j)th length stratum (§6.4).
- (c) For all  $j, f_j \in H^0(Z_j, \omega^{a_j})$  is a section constructed by applying Th. 5.1.1 to the length Hasse invariant  $h_{d-j}$  (Cor. 6.4.4).
- (d) For all j < r, the zero scheme of  $f_j$  is  $Z_{j+1}$ .

<span id="page-29-5"></span>Remark 7.2.2. Let  $(Z_j, a_j, f_j)_{j=0}^r$  be a Hasse-regular sequence.

- <span id="page-29-8"></span>(a) Given  $0 \le s \le r$ , the truncation  $(Z_j, a_j, f_j)_{i=0}^s$  is a Hasse regular sequence of length s.
- (b) Since the length Hasse invariants  $h_{d-j}$  are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant, it follows inductively from the uniqueness in Th. 5.1.1(a) that the systems of  $Z_j$  and  $f_j$  in a Hasse-regular sequence are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant and compatible with refinement of rpcd  $\Sigma$ .
- <span id="page-29-6"></span>(c) By Cor. 6.4.4, one has dim  $Z_j = d - j$  for all j.
- (d) In §8.1.6, it is shown that the coherent cohomology of  $Z_j$  admits an action of the unramified Hecke algebra  $\mathcal{H}$  (away from p), compatible with the inclusions  $Z_j \hookrightarrow Z_{j-1}$ .
- (e) It is possible (and indeed happens in our arguments) that the last section  $f_r$  is nowhere vanishing.

<span id="page-29-4"></span>**Definition 7.2.3.** A system of subschemes  $Z \subset \mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  is Hasse regular if  $Z = Z_r$  for some Hasse regular sequence  $(Z_j, a_j, f_j)_{j=0}^r$ .

<span id="page-29-2"></span>**Lemma 7.2.4.** Let  $(Z_j, a_j, f_j)_{j=0}^r$  be a Hasse-regular sequence in  $\mathscr{S}_{\mathcal{K}}^{\Sigma, n}$ . Then  $Z_j$  is Cohen-Macaulay for all j.

*Proof.* First note that the scheme  $\mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  is Cohen-Macaulay by [79, Th. 23.9], since the ring  $\mathcal{O}_E/\mathfrak{p}^n$  is Cohen-Macaulay and  $\mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  is smooth over  $\mathcal{O}_E/\mathfrak{p}^n$ . Then the result follows from [79, Th. 17.3], which implies that an effective Cartier divisor in a Cohen-Macaulay scheme is again Cohen-Macaulay.

<span id="page-29-7"></span>Corollary 7.2.5. Let  $(Z_j, a_j, f_j)_{j=0}^r$  be a Hasse-regular sequence in  $\mathscr{S}_{\mathcal{K}}^{\Sigma, n}$ . Then  $f_j$  is injective for all j.

*Proof.* By Macaulay's "Unmixedness Theorem", a Cohen-Macaulay scheme has no embedded components, cf. [27, Cor. 18.14]. In view of Lemma 7.2.4,  $Z_j$  has no embedded components. Then the result follows from Th. 5.1.1(b) and Cor. 6.4.4.

# 7.3. Cohomological vanishing on Hasse-regular subschemes of $\mathscr{S}_{\mathcal{K}}^{\Sigma,n}$ .

**Lemma 7.3.1.** Suppose  $\mathcal{Z} = (Z_j, a_j, f_j)_{j=0}^r$  is a Hasse-regular sequence and  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . Assume  $(S_{\mathcal{K}}, \eta)$  satisfies Condition 7.1.2. Then there exists an integer  $m_0$  such that, for all i > 0,  $m \ge m_0$ , and  $j \in \{0, ..., r\}$ , one has

(7.3.1) 
$$H^{i}(Z_{j}, \mathcal{V}^{\text{sub}}(\eta) \otimes \omega^{m}) = 0.$$

*Proof.* By induction on the length r. The base case r = 0 is given by Lemma 7.1.4. For all  $s \ge 0$ , multiplication by  $f_{r-1}$  and twisting by  $\omega^s$  gives a short exact sequence of sheaves on  $Z_{r-1}$ :

<span id="page-30-4"></span><span id="page-30-3"></span>
$$0 \to \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^s \to \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{a_{r-1}+s} \to \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{a_{r-1}+s}|_{Z_n} \to 0.$$

It induces a long exact sequence in cohomology:

$$(7.3.2) H^{i}(Z_{r-1}, \mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^{a_{r-1}+s}) \to H^{i}(Z_{r}, \mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^{a_{r-1}+s}) \to H^{i+1}(Z_{r-1}, \mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^{s}).$$

By induction, the extremal terms are zero for sufficiently large s, hence so is the middle term.

# <span id="page-30-0"></span>Part 3. Hecke algebras and Galois representations

Part 3 contains our applications of group-theoretical Hasse invariants to the action of the Hecke algebra on coherent cohomology and the existence of 'automorphic' Galois representations. Our most fundamental application to coherent cohomology Hecke algebras is the factorization theorem (Th. 8.2.1, compare Th. I.3.1). §8 is concerned with the statement and the majority of the proof of this result. The flag space of a Hodge-type Shimura variety is introduced in §9.1. It is used to complete the proof of Th. 8.2.1 in §9.2. Our results on Galois representations are contained in §10. The application to 'Serre's letter to Tate' constitutes §11.

# 8. Construction of Hecke factorizations

# <span id="page-30-5"></span><span id="page-30-2"></span><span id="page-30-1"></span>8.1. Hecke algebras.

8.1.1. The abstract Hecke algebra. Fix a prime  $p \notin \text{Ram}(\mathbf{G})$  (§N.3.6). For every  $v \notin \text{Ram}(\mathbf{G}) \cup \{p\}$ , let  $\mathcal{K}_v$  be a hyperspecial subgroup of  $\mathbf{G}(\mathbf{Q}_v)$ . Let  $\mathcal{H}_v = \mathcal{H}_v(\mathbf{G}_v, \mathcal{K}_v; \mathbf{Z}_p)$  be the unramified (or spherical) Hecke algebra of  $\mathbf{G}$  at v, with  $\mathbf{Z}_p$ -coefficients, normalized by the unique Haar measure which assigns the hyperspecial subgroup  $\mathcal{K}_v$  volume 1. Define the unramified, global Hecke algebra by

(8.1.1) 
$$\mathcal{H} = \mathcal{H}(\mathbf{G}) = \bigotimes_{v \notin \text{Ram}(\mathbf{G}) \cup \{p\}} \mathcal{H}_v \qquad \text{(restricted tensor product)}.$$

- 8.1.2. Systems of Hecke eigenvalues. Suppose  $\kappa$  is a field and M is a finite dimensional  $\kappa$ -vector space which is also an  $\mathcal{H}$ -module. Recall that a system of Hecke eigenvalues  $(b_T)_{T\in\mathcal{H}}$  appears in M if there exists a finite extension  $\kappa'/\kappa$  and  $m \in M \otimes \kappa'$  such that  $Tm = b_T m$  in  $M \otimes \kappa'$  for all  $T \in \mathcal{H}$ .
- 8.1.3. Coherent cohomology Hecke algebras. Let  $(\mathbf{G}, \mathbf{X})$  be a Shimura datum of Hodge type. Recall the associated structure theory (§4.1) and the symplectic embedding of toroidal compactifications  $\varphi^{\Sigma/\tilde{\Sigma}}: \mathscr{S}^{\Sigma}_{\mathcal{K}} \to \mathscr{S}^{\tilde{\Sigma}}_{g,\tilde{\mathcal{K}}}$  (6.1.1). We choose  $\tilde{\Sigma}$  and  $\Sigma$  smooth, so that  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  is smooth. Let  $\eta \in X^*_{+,\mathbf{L}}(\mathbf{T})$ . By §§4.1.9, 6.1.5, one has the coherent cohomology modules  $H^i(\mathscr{S}^n_{\mathcal{K}},\mathscr{V}(\eta)), \ H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{can}}(\eta))$  and  $H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{sub}}(\eta))$  for every  $n \in \mathbf{Z}_{\geq 0} \cup \{+\}$  and every  $i \geq 0$  (notation as in §N.2.3). We explain how the Hecke algebra  $\mathcal{H}$  acts on each of these modules. This is standard for  $H^i(\mathscr{S}^n_{\mathcal{K}},\mathscr{V}(\eta))$ , but for  $H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{can}}(\eta))$  and  $H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{sub}}(\eta))$  the definition of the trace maps is less obvious. For  $\mathscr{S}^n_{\mathcal{K}}$ , we also describe an action of  $\mathcal{H}$  on  $H^i(\mathscr{S}^n_{\mathcal{K}},\mathscr{F})$  where  $\mathscr{F}$  is an arbitrary (not necessarily locally free)  $\mathbf{G}(\mathbf{A}^p_f)$ -equivariant coherent sheaf. This will be used in §11 with  $\mathscr{F}$  the ideal sheaf of  $S_e$  in  $\mathscr{S}^1_{\mathcal{K}} = S_{\mathcal{K}}$ .

Let  $g \in \mathbf{G}(\mathbf{Q}_v)$ . For each of the spaces above, we define below an associated Hecke-operator  $T_g$ . Since  $\mathcal{H}_v$  is generated by the characteristic functions of double cosets represented by  $g \in \mathbf{G}(\mathbf{Q}_v)$ , one deduces an action of all of  $\mathcal{H}$ .

<span id="page-30-6"></span>8.1.4. Hecke action I:  $\mathscr{S}_{\mathcal{K}}^n$ . Put  $\mathcal{K}_g = \mathcal{K} \cap g\mathcal{K}g^{-1}$ . Then  $g^{-1}\mathcal{K}_gg = \mathcal{K} \cap g^{-1}\mathcal{K}g$ . Let  $\pi_1 := \pi_{\mathcal{K}_g/\mathcal{K}}$  and  $\pi_2 := \pi_{g^{-1}\mathcal{K}_gg/\mathcal{K}} \circ g$ , where  $g : \mathscr{S}_{\mathcal{K}_g}^n \xrightarrow{\sim} \mathscr{S}_{g^{-1}\mathcal{K}_gg}^n$  (§4.1.3). Then the  $\pi_j : \mathscr{S}_{\mathcal{K}_g}^n \to \mathscr{S}_{\mathcal{K}}^n$  are finite étale projections. Thus there is a trace map

$$\operatorname{tr} \pi_j : \pi_{j,*} \mathcal{O}_{\mathscr{S}_{\mathcal{K}_g}^n} \to \mathcal{O}_{\mathscr{S}_{\mathcal{K}}^n}.$$

Let  $\mathscr{F}$  be a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant coherent sheaf on the tower  $(\mathscr{S}_{\mathcal{K}}^n)_{\mathcal{K}^p}$  (§4.1.10). Then  $\pi_1^*\mathscr{F} = \pi_2^*\mathscr{F}$ . For a finite morphism, the projection formula is valid for arbitrary coherent sheaves since then the direct image is exact. Hence the Hecke operator

$$T_g: H^i(\mathscr{S}^n_{\mathcal{K}}, \mathscr{F}) \to H^i(\mathscr{S}^n_{\mathcal{K}}, \mathscr{F})$$

is defined as usual by push-pull:  $T_g := \operatorname{tr} \pi_2 \circ \pi_1^*$ .

<span id="page-31-1"></span>8.1.5. Hecke action  $II: \mathscr{S}_{\mathcal{K}}^{\Sigma,n}$ . For  $j \in \{1,2\}$ , set  $\Sigma_g^j := \pi_j^* \Sigma$ . Then the  $\Sigma_g^j$  are both admissible, finite rpcd's for  $(\mathbf{G}, \mathbf{X}, \mathcal{K}_g)$ . Let  $\Sigma_g$  be a common, smooth refinement of  $\Sigma_g^1$  and  $\Sigma_g^2$ . Let  $\pi_j' : \mathscr{S}_{\mathcal{K}_g}^{\Sigma_g,n} \to \mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  be the corresponding projections. Each is a composition of a refinement morphism  $r^j : \mathscr{S}_{\mathcal{K}_g}^{\Sigma_g,n} \to \mathscr{S}_{\mathcal{K}_g}^{\Sigma_g,n}$  corresponding to  $\Sigma_g \subset \Sigma_g^j$  and a projection  $\pi_j^0 : \mathscr{S}_{\mathcal{K}_g}^{\Sigma_g,n} \to \mathscr{S}_{\mathcal{K}_g}^{\Sigma_g,n}$ . By [77, Proof of 5.1.3], the  $r^j$  satisfy  $r_*^j \mathcal{O}_{\mathscr{K}_g}^{\Sigma_g,n} = \mathcal{O}_{\mathscr{K}_g}^{\Sigma_g^j,n}$  and  $R^i r_*^j \mathcal{O}_{\mathscr{K}_g}^{\Sigma_g,n} = 0$  for all i > 0. Since  $\mathscr{V}^{\mathrm{can}}(\eta)$  and  $\mathscr{V}^{\mathrm{sub}}(\eta)$  are locally free and  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant (§6.1.7), combining the properties of  $r^j$  with the projection formula gives

(8.1.2) 
$$H^{i}(\mathscr{S}_{\mathcal{K}_{a}}^{\Sigma_{g},n},\mathscr{V}^{?}(\eta)) = H^{i}(\mathscr{S}_{\mathcal{K}_{a}}^{\Sigma_{g}^{j},n},\mathscr{V}^{?}(\eta))$$

for  $? \in \{can, sub\}$ .

The  $\pi_j^0$  are finite and we claim they are also flat (we learned this fact from J. Tilouine [102, §8.1.2, p. 1409] and we thank B. Stroh and D. Rydh for discussions about why it is true). It suffices to check the flatness over  $\mathcal{O}_{E,\mathfrak{p}}/\mathfrak{p}^n$  then follows by base change.

Observe that all of the toroidal compactifications considered here are Cohen-Macaulay over  $\mathcal{O}_{E,\mathfrak{p}}$ ; specifically we need to justify why the  $\mathscr{S}_{K_g}^{j_g}$ , which are associated to potentially non-smooth rpcd, are Cohen-Macaulay. Recall that, given any finite rpcd  $\Sigma'$  and any base scheme S, one has an associated torus embedding  $X_{\Sigma'}(S)$  over S, functorial in  $\Sigma'$ , as described in [21, Chap. IV, Th. 2.5]. By construction, the toroidal compactifications  $\mathscr{S}_{K_g}^{\Sigma_g^j}$  are étale locally torus embeddings of this type over  $\mathcal{O}_{E,\mathfrak{p}}$ . Thus we are reduced to checking that a torus embedding  $X_{\Sigma'}(R)$  over a DVR R is Cohen-Macaulay (the argument which follows works equally well over regular local R). By [56, Chap. 1, §3, Th. 14] a torus embedding over a field is Cohen-Macaulay. Since a torus embedding over R is flat over R, the result follows from [79, Th. 23.9]. Thus  $\mathscr{S}_{K_g}^{\Sigma_g^j}$  is Cohen-Macaulay.

flat over R, the result follows from [79, Th. 23.9]. Thus  $\mathscr{S}_{\mathcal{K}_g}^{\Sigma_g^j}$  is Cohen-Macaulay. Since the target  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  of  $\pi_j^0$  is regular (recall that  $\Sigma$  was assumed smooth), we conclude that  $\pi_j^0$  is flat by [79, Th. 23.1], which implies that a quasi-finite morphism between equi-dimensional, locally Noetherian schemes of the same dimension is flat if the domain is Cohen-Macaulay and the target is regular.

The finite flatness of  $\pi_i^0$  gives a trace map

$$\operatorname{tr} \pi_j^0 : \pi_{j,*}^0 \mathcal{O}_{\mathscr{S}_{\mathcal{K}_a}^{\Sigma_g^j, n}} \to \mathcal{O}_{\mathscr{S}_{\mathcal{K}}^{\Sigma, n}}.$$

The trace gives a map  $H^i(\mathscr{S}^{\Sigma^j_g,n}_{\mathcal{K}_q},\mathscr{V}^?(\eta)) \to H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^?(\eta))$ . Together with (8.1.2), this yields

$$\operatorname{tr} \pi_j': H^i(\mathscr{S}^{\Sigma_g,n}_{\mathcal{K}_q}, \mathscr{V}^?(\eta)) \to H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}}, \mathscr{V}^?(\eta)).$$

Having constructed  $\operatorname{tr} \pi'_j,$  our desired Hecke operators

$$T_g^\Sigma: H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}}, \mathscr{V}^?(\eta)) \to H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}}, \mathscr{V}^?(\eta))$$

are given as before:  $T_g^{\Sigma} := \operatorname{tr} \pi_2' \circ \pi_1'^*$ . It follows again from the properties of the refinement morphisms  $r^j$  that  $T_g^{\Sigma}$  is independent of the choice of  $\Sigma_g$  (given another choice of smooth refinement  $\Sigma_g'$  of both  $\Sigma_g^1$  and  $\Sigma_g^2$ , choose a common, smooth refinement  $\Sigma_g''$  of  $\Sigma_g, \Sigma_g'$ ).

Finally, note that the definition of  $T_g^{\Sigma}$  reduces to that of  $T_g$  away from the boundary. The inclusion  $\mathscr{S}_{\mathcal{K}}^n \to \mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant; it induces an  $\mathcal{H}$ -equivariant restriction map  $H^0(\mathscr{S}_{\mathcal{K}}^{\Sigma,n},\mathscr{V}^{\mathrm{can}}(\eta)) \to H^0(\mathscr{S}_{\mathcal{K}}^n,\mathscr{V}(\eta))$ . The latter is an isomorphism when  $(\mathbf{G},\mathbf{X})$  satisfies the Koecher principle.

<span id="page-31-0"></span>8.1.6. Hecke action III: Hasse-regular subschemes. For  $j \in \{1,2\}$ , let  $r^j$  and  $\pi^0_j$  be as in §8.1.5. Let  $(Z^0_t, a_t, f_{t,0})^r_{t=0}$  (resp.  $(Z_t, a_t, f_t)^r_{t=0}$ ) denote the component of a Hasse regular sequence for  $(\mathcal{K}, \Sigma)$  (resp.  $(\mathcal{K}^g, \Sigma_g)$ ). Even though the  $\Sigma^j_g$  may not be smooth, we may still define a component  $(Z^j_t, a_t, f_{t,j})^r_{t=0}$  of the Hasse regular sequence for  $(\mathcal{K}_g, \Sigma^j_g)$  by pullback: Put  $Z^j_t := (\pi^0_j)^{-1}(Z^0_t)$  and  $f_{t,j} := (\pi^0_j)^* f_{t,0}$ . Then  $(r^j)^{-1}(Z^j_t) = Z_t$  and  $(r^j)^* f_{t,j} = f_t$  are the components for  $\Sigma_g$ . Let  $y^t : Z_t \to \mathscr{S}^{\Sigma_g}_{\mathcal{K}_g}, y^{t,0} : Z^0_t \to \mathscr{S}^\Sigma_{\mathcal{K}}$  and  $y^{t,j} : Z^j_t \to \mathscr{S}^{\Sigma^j_g}_{\mathcal{K}_g}$  denote the inclusions.

<span id="page-31-4"></span><span id="page-31-3"></span>**Lemma 8.1.1.** For all t, one has:

- (a) For all i > 0,  $R^i r_*^j (y_*^t \mathcal{O}_{Z_t}) = 0$  and  $r_*^j (y_*^t \mathcal{O}_{Z_t}) = y_*^{t,j} \mathcal{O}_{Z_t^j}$ .
- <span id="page-31-2"></span>(b) The pullback of  $\pi^0_j$  along the inclusion  $y^{t,0}: Z^0_t \to \mathscr{S}^\Sigma_{\mathcal{K}}$  is a finite flat map  $Z^j_t \to Z^0_t$ .

*Proof.* Part (b) is a direct consequence of the finite flatness of  $\pi_j^0$ . We prove (a) by induction on t: The case t = 0 was done in §8.1.5. Assume the two statements hold up to t and consider them for t + 1. By Def. 7.2.1 and the affineness of  $y^t$ , multiplication by  $f_t$  gives a short exact sequence:

$$(8.1.3) 0 \to y_*^t(\omega^{-a_t}|_{Z_t}) \to y_*^t\mathcal{O}_{Z_t} \to y_*^{t+1}\mathcal{O}_{Z_{t+1}} \to 0.$$

Apply  $r_*^j$  and consider the long exact sequence of higher direct images. By the induction hypothesis,  $R^i r_*^j (y_*^t \mathcal{O}_{Z_t}) = 0$  for all i > 0. Since  $(r^j)^* (y_*^{t,j} \omega^{-a_t}|_{Z_t^j}) = y_*^t \omega^{-a_t}|_{Z_t}$ , the projection formula gives

$$R^{i}r_{*}^{j}(y_{*}^{t}\omega^{-a_{t}}|_{Z_{t}}) = y_{*}^{t,j}\omega^{-a_{t}}|_{Z_{*}^{j}} \otimes R^{i}r_{*}^{j}(y_{*}^{t}\mathcal{O}_{Z_{t}}) = 0$$

for all i > 0. Thus  $R^i r_*^j (y_*^{t+1} \mathcal{O}_{Z_{t+1}}) = 0$  for all i > 0, as it lies between two terms that are zero. Similarly, the induction hypothesis and projection formula also give

$$(8.1.4) 0 \to y_*^{t,j} \omega^{-a_t}|_{Z_*^j} \to y_*^{t,j} \mathcal{O}_{Z_*^j} \to r_*^j y_*^{t+1} \mathcal{O}_{Z_{t+1}} \to 0,$$

since 
$$R^1 r_*^j(y_*^t \omega^{-a_t}|_{Z_t}) = 0$$
. Thus  $r_*^j(y_*^{t+1} \mathcal{O}_{Z_{t+1}}) = y_*^{t+1,j} \mathcal{O}_{Z_{t+1}^j}$ . This proves (a).

Using Lemma 8.1.1, we may apply the method of §8.1.5 to  $Z^0_t$  for every t. This gives a Hecke operator  $T_g^{Z^0_t,\Sigma}: H^i(Z^0_t,\mathcal{V}^?(\eta)) \to H^i(Z^0_t,\mathcal{V}^?(\eta))$  for every t and  $? \in \{\text{can, sub}\}$ . By construction, the Hecke actions on  $Z^0_t$  and  $Z^0_{t-1}$  are compatible: If  $\alpha: Z^0_t \to Z^0_{t-1}$  denotes the inclusion, then the  $\mathbf{G}(\mathbf{A}^p_t)$ -equivariant short exact sequence

$$(8.1.5) 0 \to \omega^{-a_t} \to \mathcal{O}_{Z_*^0} \to \alpha_* \mathcal{O}_{Z_{*+1}^0} \to 0$$

induces an  $\mathcal{H}$ -equivariant long exact sequence in cohomology. By the projection formula, the same is true if we tensor (8.1.5) with either  $\mathcal{V}^{\operatorname{can}}(\eta)$  or  $\mathcal{V}^{\operatorname{sub}}(\eta)$ .

- <span id="page-32-6"></span>8.1.7. Notation for coherent cohomology Hecke algebras. Let  $\mathcal{H}^{i,n}(\eta)$  denote the image of  $\mathcal{H}$  in  $\operatorname{End}(H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}}, \mathscr{V}^{\operatorname{sub}}(\eta)))$ ; we omit  $\mathcal{K}$  and  $\Sigma$  from the notation. If Z is a Hasse regular subscheme (Def. 7.2.3) of  $\mathscr{S}^{\Sigma,n}_{\mathcal{K}}$ , then write  $\mathcal{H}^{i,n}_{Z}(\eta)$  for the image of  $\mathcal{H}$  in  $\operatorname{End}(H^i(Z, \mathscr{V}^{\operatorname{sub}}(\eta)))$ . An arrow  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  or  $\mathcal{H} \to \mathcal{H}^{i,n}_{Z}(\eta)$  will always signify the defining projection.
- <span id="page-32-5"></span>8.2. Statement of the factorization theorem. From now on, in addition to assuming  $\Sigma$  to be smooth, we assume  $\Sigma$  is a refinement of  $\varphi^*\tilde{\Sigma}$  for some  $\tilde{\Sigma}$  which admits  $\beta$  log integral (§6.1.2). Recall that this can always be achieved by refining  $\Sigma$ . Then we may apply Th. 6.2.1 and the results of §6.4, §7 which depend on it.

For every triple  $(i, n, \eta)$  with  $i \in \mathbf{Z}_{\geq 0}$ ,  $n \in \mathbf{Z}_{\geq 1}$  and  $\eta \in X_{+, \mathbf{L}}^*(\mathbf{T})$ , let

$$(8.2.1) F(i,n,\eta) = \{ \eta' \in X_{+,\mathbf{L}}^*(\mathbf{T}) \mid \mathcal{H} \longrightarrow \mathcal{H}^{i,n}(\eta) \text{ factors through } \mathcal{H} \longrightarrow \mathcal{H}^{0,n}(\eta') \}.$$

It is desirable to know that  $F(i, n, \eta)$  is large. This is accomplished by the following "factorization theorem":

<span id="page-32-0"></span>**Theorem 8.2.1** (Reduction to  $H^0$ ). Let  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$  Assume that  $(\mathbf{G},\mathbf{X})$  is either of PEL type, or of compact type, or that  $(S_K^{\Sigma},\eta)$  satisfies Conditions 6.4.2 and 7.1.2. Then

- <span id="page-32-4"></span><span id="page-32-2"></span>(a) There exists an arithmetic progression A such that  $\eta + a\eta_{\omega} \in F(i, n, \eta)$  for all  $a \in A \cap \mathbb{Z}_{>1}$ .
- (b) Let  $C \subset X^*(\mathbf{T})$  be the "global sections cone" defined in (3.4.3). For all  $\nu \in C$  and  $\eta_1 \in F(i, n, \eta)$  there exists  $m = m(\nu, n) \in \mathbf{Z}_{\geq 1}$  such that  $\eta_1 + jm\nu \in F(i, n, \eta)$  for all  $j \in \mathbf{Z}_{\geq 1}$ .
- <span id="page-32-3"></span>(c) For all  $\delta \in \mathbf{R}_{>0}$ ,  $F(i, n, \eta)$  contains a  $\delta$ -regular character (Def. N.5.5).

<span id="page-32-1"></span>Remark 8.2.2 (Concerning our assumptions). We expect it will soon be shown Conditions 6.4.2 and 7.1.2 hold for all Shimura varieties of Hodge type and all  $\eta \in X_{+,L}^*(\mathbf{T})$ . These conditions are vacuous in the compact case and are known to hold in the PEL case and in general when  $\eta$  is a multiple of  $\eta_{\omega}$ ; see Lemma 6.4.1 and Rmk. 7.1.3.

Remark 8.2.3. Th. 8.2.1(c) illustrates merely one of many regularity conditions that follow from (b). Following the proof that (b) implies (c) in §9.2, it should be clear to the reader that " $\delta$ -regular" may be replaced by any regularity condition whose singular locus is a finite union of hyperplanes. In particular, when  $\mathbf{G} = GSp(2g)$ , this applies to the condition "spin-regular" studied in [63].

Remark 8.2.4. For PEL Shimura varieties of type A and C (resp. Scholze's integral models of general Hodge-type Shimura varieties) Part (a) of Th. 8.2.1 was also obtained simultaneously and independently in [11] (resp. [86]). The assumptions 6.4.2, 7.1.2 are not needed in [86]. By contrast, as far as we can tell, parts (b)-(c) do not follow by the methods of [11] and [86].

<span id="page-32-7"></span>Remark 8.2.5 (Reduction to  $H^0$ , modulo p). In the case n=1 (action of the Hecke algebra on the cohomology of the special fiber), a standard argument gives a more elementary statement in terms of systems of Hecke eigenvalues. The set  $F(i,1,\eta)$  consists of all  $\eta'$  such that every system of Hecke eigenvalues that appears in  $H^i(S_K^{\Sigma}, \mathcal{V}^{\text{sub}}(\eta))$  also appears in  $H^0(S_K^{\Sigma}, \mathcal{V}^{\text{sub}}(\eta'))$ .

8.2.1. Strategy of the proof. The proof of Th. 8.2.1(a) naturally breaks down into three steps: (i) "Descent" (Lemma 8.3.2), (ii) "Weight Increase" (Lemma 8.3.3) and (iii) "Ascent" (Lemma 8.3.4). "Descent" shows that  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  factors through  $\mathcal{H} \to \mathcal{H}_Z^{0,n}(\eta + b\eta_\omega)$  for some  $b \in \mathbb{Z}_{\geq 1}$  and some Hecke-equivariant, nilpotent thickening Z of a length stratum. "Weight increase" then shows that the latter factors through  $\mathcal{H} \to \mathcal{H}_Z^{0,n}(\eta + s\eta_\omega)$  for all sufficiently large s in an arithmetic progression containing b. By choosing s large enough, the vanishing lemma 7.3.1 applies. Finally, "Ascent" yields the factorization claimed in (a).

The flag space is introduced in §9.1 to prove (b)-(c). The latter are proved in §9.2 by applying results of §3.4 about G-ZipFlag<sup> $\mu$ </sup> and C.

<span id="page-33-5"></span>8.3. **Descent, Weight increase and going up.** Throughout §8.3, adopt the assumptions of Th. 8.2.1. If  $H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{sub}}(\eta))=0$ , then Th. 8.2.1 is vacuous for  $(i,n,\eta)$ . So assume for the rest of §8 that  $H^i(\mathscr{S}^{\Sigma,n}_{\mathcal{K}},\mathscr{V}^{\mathrm{sub}}(\eta))\neq 0$ . The following linear algebra lemma will be applied repeatedly:

<span id="page-33-7"></span>**Lemma 8.3.1.** Suppose R is a  $\mathbb{Z}_p$ -algebra and  $\epsilon: M' \to M$  is a morphism of  $R\mathcal{H}$ -modules. Write  $\mathcal{H}_M$  (resp.  $\mathcal{H}_{M'}$ ) for the image of  $\mathcal{H}$  in  $\operatorname{End}_R(M)$  (resp.  $\operatorname{End}_R(M')$ ). If  $\epsilon$  is injective (resp. surjective), then the map  $\mathcal{H} \to \mathcal{H}_{M'}$  (resp.  $\mathcal{H} \to \mathcal{H}_M$ ) factors through  $\mathcal{H}_M$  (resp.  $\mathcal{H}_{M'}$ ).

*Proof.* Both factorizations are equivalent to the corresponding inclusions of kernels, which are trivial.  $\Box$ 

<span id="page-33-2"></span>**Lemma 8.3.2** (Descent). Suppose  $(i, n, \eta)$  is a triple as in §8.2. Then there exists  $b \in \mathbf{Z}_{\geq 1}$  and a Hasse-regular sequence  $\mathcal{Z} = (Z_j, a_j, f_j)_{i=0}^i$  such that

(8.3.1) 
$$\mathcal{H} \to \mathcal{H}^{i,n}(\eta) \text{ factors through } \mathcal{H} \to \mathcal{H}^{0,n}_{Z_i}(\eta + b\eta_{\omega}).$$

*Proof.* We prove by induction on J that for every  $0 \le J \le i$  there exists a Hasse-regular sequence  $\mathcal{Z}_J = (Z_j, a_j, f_j)_{j=0}^J$ , an integer  $b_J$  and a factorization

<span id="page-33-0"></span>(8.3.2) 
$$\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$$
 factors through  $\mathcal{H} \to \mathcal{H}^{i-J,n}_{Z_J}(\eta + b_J \eta_\omega)$ .

It suffices to show that a Hasse-regular sequence  $\mathcal{Z}_J$  satisfying (8.3.2) can be extended by some  $(Z_{j+1}, a_{j+1}, f_{j+1})$  and  $b_{J+1} \geq 1$  to a Hasse regular sequence  $\mathcal{Z}_{J+1}$  satisfying

<span id="page-33-8"></span>(8.3.3) 
$$\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$$
 factors through  $\mathcal{H} \to \mathcal{H}^{i-(J+1),n}_{Z_{J+1}}(\eta + b_{J+1}\eta_{\omega})$ .

The factorization (8.3.2) implies that  $H^{i-J}(Z_J, \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{b_J}) \neq 0$ . Recall that dim  $Z_J = d - J$  (Rmk. 7.2.2(c)). By Lemma 7.3.1, there exists  $r \geq 1$  such that

<span id="page-33-6"></span>
$$(8.3.4) H^{i-J}(Z_J, \mathcal{V}^{\text{sub}}(\eta) \otimes \omega^{b_J + ra_J}) = 0.$$

By Cor. 7.2.5,  $f_J \in H^0(Z_J, \omega^{a_J})$  is injective and by Rmk. 7.2.2(b) it is also  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant. Thus multiplication by  $f_J^r$  yields a  $\mathbf{G}(\mathbf{A}_f^p)$ -short exact sequence of sheaves on  $Z_J$ :

<span id="page-33-1"></span>
$$(8.3.5) 0 \to \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{b_J} \to \mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{b_J + ra_J} \to (\mathscr{V}^{\mathrm{sub}}(\eta) \otimes \omega^{b_J + ra_J})|_{Z(f_I^r)} \to 0.$$

Set  $Z_{J+1} = Z(f_J^r)$  and  $b_{J+1} = b_J + ra_J$ . Applying (8.3.4), and Lemma 8.3.1 to the associated long exact sequence in cohomology yields (8.3.3). By Cor. 6.4.4,  $(Z_{J+1})_{\text{red}} = S_{d-(j+1)}^*$ . Applying Th. 5.1.1 to the length Hasse invariant  $h_{d-(J+1)}$  gives  $a_{J+1} \geq 1$  and  $f_{J+1} \in H^0(Z_{J+1}, \omega^{a_{J+1}})$  satisfying the conditions of that theorem. By construction,  $\mathcal{Z}_{J+1} = (Z_j, a_j, f_j)_{j=0}^{J+1}$  is a Hasse regular sequence extending  $\mathcal{Z}_J$ . This completes the induction.

<span id="page-33-9"></span>For the rest of §8.3, fix the notation and the Hasse-regular sequence of Lemma 8.3.2.

<span id="page-33-3"></span>**Lemma 8.3.3** (Weight increase). For all sufficiently large  $s \in b + a_i \mathbb{Z}$ , one has:

(8.3.6) 
$$\mathcal{H} \to \mathcal{H}_{Z_i}^{0,n}(\eta + b\eta_\omega) \text{ factors through } \mathcal{H} \to \mathcal{H}_{Z_i}^{0,n}(\eta + s\eta_\omega)$$

and for all  $0 \le j \le i - 1$ ,

<span id="page-33-10"></span>(8.3.7) 
$$H^1(Z_j, \mathcal{V}^{\text{sub}}(\eta) \otimes \omega^{s-a_j}) = 0.$$

*Proof.* Consider the injective,  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant section  $f_i \in H^0(Z_i, \omega^{a_i})$  pertaining to  $(Z_j, a_j, f_j)_{j=0}^i$ . For all  $r \geq 1$ , multiplication by  $f_i^r$  induces a Hecke-equivariant injection

$$(8.3.8) H^0(Z_i, \mathcal{V}^{\mathrm{sub}}(\eta + b\eta_\omega)) \hookrightarrow H^0(Z_i, \mathcal{V}^{\mathrm{sub}}(\eta + (b + ra_i)\eta_\omega)).$$

Lemma 8.3.1 gives the factorization (8.3.6). It satisfies the vanishing (8.3.7) for  $r \gg 0$  by Lemma 7.3.1.

<span id="page-33-4"></span>**Lemma 8.3.4** (Ascent). Suppose s satisfies (8.3.6) and (8.3.7). Then

(8.3.9) 
$$\mathcal{H} \to \mathcal{H}_{Z_i}^{0,n}(\eta + s\eta_\omega) \text{ factors through } \mathcal{H} \to \mathcal{H}^{0,n}(\eta + s\eta_\omega).$$

*Proof.* We prove by downward induction on J that

<span id="page-34-3"></span>(8.3.10) 
$$\mathcal{H} \to \mathcal{H}_{Z_i}^{0,n}(\eta + s\eta_\omega)$$
 factors through  $\mathcal{H} \to \mathcal{H}_{Z_i}^{0,n}(\eta + s\eta_\omega)$ 

for all  $0 \le J \le i$ . For J = i there is nothing to prove. So we assume (8.3.10) and prove that also

(8.3.11) 
$$\mathcal{H} \to \mathcal{H}_{Z_{I}}^{0,n}(\eta + s\eta_{\omega}) \text{ factors through } \mathcal{H} \to \mathcal{H}_{Z_{I-1}}^{0,n}(\eta + s\eta_{\omega}).$$

Combining the factorizations (8.3.10) and (8.3.11) will then complete the induction.

<span id="page-34-4"></span>Consider the short exact sequence of sheaves on  $Z_{J-1}$  given by multiplication by  $f_{J-1}$ :

$$(8.3.12) 0 \to \mathcal{V}^{\text{sub}}(\eta + (s - a_{J-1})\eta_{\omega}) \to \mathcal{V}^{\text{sub}}(\eta + s\eta_{\omega}) \to \mathcal{V}^{\text{sub}}(\eta + s\eta_{\omega})|_{Z_J} \to 0.$$

The associated long exact sequence gives

<span id="page-34-5"></span>
$$(8.3.13) H^0(Z_{J-1}, \mathcal{V}^{\mathrm{sub}}(\eta + s\eta_{\omega})) \to H^0(Z_J, \mathcal{V}^{\mathrm{sub}}(\eta + s\eta_{\omega})) \to H^1(Z_{J-1}, \mathcal{V}^{\mathrm{sub}}(\eta + (s - a_{J-1})\eta_{\omega})).$$

By (8.3.7), the right-most term in (8.3.13) is zero (given our choice of s). Hence Lemma 8.3.1 gives (8.3.11). 

<span id="page-34-0"></span>Proof of Th. 8.2.1(a): Apply Lemmas 8.3.2, 8.3.3 and 8.3.4 successively.

# <span id="page-34-7"></span><span id="page-34-6"></span>9. Increased regularity via the flag space

<span id="page-34-2"></span>9.1. The flag space. The quotient of the  $\mathcal{P}$ -torsor  $I_{\mathcal{P}}$  on  $\mathscr{S}_{\mathcal{K}}$  by the Borel subgroup  $\mathcal{B}$  is represented by a smooth, projective  $\mathscr{S}_{\mathcal{K}}$ -scheme denoted  $\mathcal{F}l_{\mathcal{K}}$ , which we call the flag space of  $\mathscr{S}_{\mathcal{K}}$ . Similarly, the flag space of  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  is  $\mathcal{F}l_{\mathcal{K}}^{\Sigma} := I_{\mathcal{P}}^{\Sigma}/\mathcal{B}$ . Let  $Fl_{\mathcal{K}}$  (resp.  $Fl_{\mathcal{K}}^{\Sigma}$ ) denote the special fiber of  $\mathcal{F}l_{\mathcal{K}}$  (resp.  $\mathcal{F}l_{\mathcal{K}}^{\Sigma}$ ). There are natural isomorphisms

(9.1.1) 
$$Fl_{\mathcal{K}} \simeq S_{\mathcal{K}} \times_{G\text{-}\mathsf{Zip}^{\mu}} G\text{-}\mathsf{ZipFlag}^{\mu} \text{ and } Fl_{\mathcal{K}}^{\Sigma} \simeq S_{\mathcal{K}}^{\Sigma} \times_{G\text{-}\mathsf{Zip}^{\mu}} G\text{-}\mathsf{ZipFlag}^{\mu}.$$

By construction, the tower  $(\mathcal{F}l_{\mathcal{K}}^{\Sigma})_{\mathcal{K}^{p},\Sigma}$  admits an action of  $\mathbf{G}(\mathbf{A}_{f}^{p})$ . The system of maps  $(\mathcal{F}l_{\mathcal{K}}^{\Sigma} \to \mathscr{S}_{\mathcal{K}}^{\Sigma})$  is  $\mathbf{G}(\mathbf{A}_{f}^{p})$ equivariant. The construction of  $\S N.4.1$  assigns a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant line bundle  $\mathscr{L}(\eta)$  on  $\mathcal{F}l_{\mathcal{K}}^{\Sigma}$  (resp.  $\mathscr{L}^{\mathrm{can}}(\eta)$ on  $\mathcal{F}l_{\mathcal{K}}^{\Sigma}$ ) to every  $\eta \in X^*(\mathbf{T})$ . The restriction of  $\mathcal{L}(\eta)$  (resp.  $\mathcal{L}^{\mathrm{can}}(\eta)$ ) to a fiber is the line bundle previously called  $\mathscr{L}(\eta)$  in §4.1.9. Write  $\pi: \mathcal{F}l^{\Sigma}_{\mathcal{K}} \to \mathscr{S}^{\Sigma}_{\mathcal{K}}$  for the natural projection. For all  $\eta \in X^*_{+,\mathbf{L}}(\mathbf{T})$  one has canonical,  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant identifications

(9.1.2) 
$$\pi_* \mathcal{L}(\eta) = \mathcal{V}(\eta) \text{ and } \pi_* \mathcal{L}^{\operatorname{can}}(\eta) = \mathcal{V}^{\operatorname{can}}(\eta).$$

Remark 9.1.1. Note that the k-fibers of  $\pi$  are flag varieties isomorphic to  $L/B_L$ . If the character  $\eta$  is not in the cone  $X_{+,\mathbf{L}}^*(\mathbf{T})$ , then  $H^0(L/B_L,\mathcal{L}(\eta))=0$ , so we deduce  $\pi_*\mathcal{L}(\eta)=\mathcal{V}(\eta)=0$ . This implies that if  $\mathcal{L}(\eta)$  admits a nonzero global section on  $Fl_{\mathcal{K}}^{\Sigma}$ , then  $\eta \in X_{+,\mathbf{L}}^{*}(\mathbf{T})$ . In particular, one has  $\mathcal{C} \subset X_{+,\mathbf{L}}^{*}(\mathbf{T})$  (§3.4).

Recall (§6.1.5) that D denotes the boundary divisor of the toroidal compactification  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$ . Put  $\mathscr{L}^{\mathrm{sub}}(\eta) :=$  $\mathscr{L}(\eta) \otimes \pi^* \mathcal{O}(-D)$ . Since  $\mathcal{O}(-D)$  is a line bundle, the projection formula and (9.1.2) gives  $\pi_* \mathscr{L}^{\mathrm{sub}}(\eta) = \mathscr{V}^{\mathrm{sub}}(\eta)$ .

<span id="page-34-1"></span>Remark 9.1.2 (Motivation for the flag space). The  $\mathcal{O}_{\mathfrak{p}}$ -scheme  $\mathcal{F}l_{\mathcal{K}}^{\Sigma}$  is a simultaneous generalization of aspects of work of Griffiths-Schmid over C [44] (see also the works Carayol cited in the introduction) and work of Ekedahl-van der Geer [28] in characteristic p > 0. We were inspired by both of these works.

Griffiths-Schmid studied homogenous complex manifolds of the form  $\Gamma \setminus G/T$ , where G is a connected, semisimple, real Lie group, T is a compact Cartan subgroup, G/T is endowed with a complex structure and  $\Gamma$  is an arithmetic subgroup. Carayol termed these Griffiths-Schmid manifolds [16].

Griffiths and his school refer to those complex structures on G/T which fiber holomorphically over a Hermitian symmetric domain as the classical case. In the classical case, the Griffiths-Schmid manifolds  $\Gamma \backslash G/T$  are algebraic. By contrast, it has recently been shown that all Griffiths-Schmid manifolds in the non-classical case are not algebraic |43|

The complex manifolds  $\mathcal{F}l_{\kappa}^{\Sigma}(\mathbf{C})$  are adelic versions of algebraic Griffiths-Schmid manifolds. They provide a moduli interpretation of every algebraic Griffiths-Schmid manifold which lies over a Shimura variety of Hodge-type.

For Siegel modular varieties, Ekedahl-van der Geer defined a flag space  $Fl_g$  over  $\mathbf{F}_p$  by more elementary means than ours, namely in terms of full symplectic flags refining the Hodge filtration in  $H_{\mathrm{dR}}^1$  of an abelian scheme. They went on to define a stratification of  $Fl_g$  and study its relation to the EO stratification of  $\mathscr{S}_{q,\tilde{K}}\otimes \mathbf{F}_p$ . The stratification obtained above via (9.1.1) agrees with that of [28] for Siegel varieties.

Remark 9.1.3 (Comparison of cohomology). Suppose  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T}), n \in \mathbf{Z}_{\geq 0} \cup \{+\}$  and  $\pi : \mathcal{F}l_{\mathcal{K}}^{\Sigma,n} \to \mathscr{S}_{\mathcal{K}}^{\Sigma,n}$  is the natural projection. An application of Kempf's vanishing theorem [53, II, Chap.4] and Lemma 7.1.1 yields  $R^i\pi_*\mathscr{L}^{\mathrm{sub}}(\eta)=0$  for all i>0. Consequently, for all  $i\in\mathbf{Z}_{\geq 0}\cup\{+\}$  there is a Hecke-equivariant isomorphism

<span id="page-34-8"></span>(9.1.3) 
$$H^{i}(\mathcal{F}l_{\mathcal{K}}^{\Sigma,n}, \mathscr{L}^{\mathrm{sub}}(\eta)) \cong H^{i}(\mathscr{L}_{\mathcal{K}}^{\Sigma,n}, \mathscr{V}^{\mathrm{sub}}(\eta)).$$

In this paper (9.1.3) is only used with i = 0, when it follows directly from (9.1.2). However, (9.1.3) illustrates another advantageous property of the flag space, which is useful in other situations cf. the forthcoming work [13].

<span id="page-35-2"></span>9.2. Increased Regularity. The flag space affords additional Hecke factorizations as follows:

Proof of Th. 8.2.1(b): By §3.4, for all  $\nu \in \mathcal{C}$  there exists a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant, injective section  $h_{\nu} \in H^0(Fl_{\mathcal{K}}^{\Sigma}, \mathscr{L}^{\mathrm{can}}(\nu))$ . By Th. 5.1.1, there exists  $m = m(\nu, n) \geq 1$  such that  $h_{\nu}^m$  lifts to an injective,  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant section  $\tilde{h}_{\nu}^m \in H^0(\mathcal{F}l_{\mathcal{K}}^{\Sigma,n}, \mathscr{L}^{\mathrm{can}}(m\nu))$ . For all  $j \geq 1$ , multiplication by  $\tilde{h}_{\nu}^{jm}$  induces a Hecke-equivariant injection

$$H^0(\mathcal{F}l_{\mathcal{K}}^{\Sigma,n},\mathcal{L}^{\mathrm{sub}}(\eta_1)) \hookrightarrow H^0(\mathcal{F}l_{\mathcal{K}}^{\Sigma,n},\mathcal{L}^{\mathrm{sub}}(\eta_1+jm\nu)).$$

If  $\eta_1 \in F(i, n, \eta)$ , then it follows from Lemma 8.3.1 and (9.1.2) that  $\eta_1 + jm\nu \in F(i, n, \eta)$ .

Proof of Th. 8.2.1(c): By §3.4, the cone  $\mathcal{C}$  spans  $X^*(\mathbf{T})_{\mathbf{Q}}$ . On the other hand, the singular locus in  $X^*(\mathbf{T})_{\mathbf{Q}}$  is a finite union of hyperplanes viz. the root hyperplanes  $\alpha^{\perp}$  for  $\alpha \in \Phi(\mathbf{G}, \mathbf{T})$  (§N.3.4). Therefore  $\mathcal{C}$  contains a regular element  $\nu \in X^*_{+,\mathbf{L}}(\mathbf{T})$ .

<span id="page-35-0"></span>By Th. 8.2.1(a),  $F(i, n, \eta)$  is nonempty. So let  $\eta_1 \in F(i, n, \eta)$ . By Th. 8.2.1(b), there exists  $m = m(\nu, n)$  such that  $\eta_1 + jm\nu \in F(i, n, \eta)$  for all  $j \in \mathbf{Z}_{>1}$ ; since  $\nu$  is regular,  $\eta_1 + jm\nu$  is  $\delta$ -regular for all sufficiently large j.

#### 10. Galois representations

This section is devoted to Th. I.3.2 on the association of Galois representations (resp. pseudo-representations) to automorphic representations whose archimedean component is a non-degenerate limit of discrete series (LDS) (resp. coherent cohomology modulo  $p^n$ ). §§10.1-10.2 recall facts and introduce notation regarding archimedean and non-archimedean representations respectively. To simplify the ensuing statements, we formalize the existence of a Galois representation associated to an automorphic representation as a condition in §10.3. Our results are then stated as four theorems in §§10.4-10.5. These theorems are proved in §10.6. We hope that by carefully stating our hypotheses in a general context, it will be easy to apply them as soon as new results are established for cohomological representations (e.g., see Rmk. 10.5.2).

Recall our notation and conventions regarding structure theory of reductive groups, (based) root data and related objects (§N.3) and Shimura varieties of Hodge type §4.1. Fix a Shimura datum of Hodge type ( $\mathbf{G}, \mathbf{X}$ ) together with an integral symplectic embedding  $\varphi$  (4.1.1). Recall from §4.1.5 that associated to ( $\mathbf{G}, \mathbf{X}, \varphi$ ) we have: The conjugacy class of cocharacters  $[\mu]_{\overline{E}_{\mathfrak{p}}}$  over  $\overline{E}_{\mathfrak{p}}$ , a representative  $\mu$  defined over  $E_{\mathfrak{p}}$ , a Borel pair ( $\mathbf{B}, \mathbf{T}$ ) of  $\mathbf{G}_{\mathbf{Q}_{p}}$ , opposite parabolic subgroups  $\mathbf{P}, \mathbf{P}^{+}$  such that  $\mathbf{B}_{E_{\mathfrak{p}}} \subset \mathbf{P}$  and the Levi  $\mathbf{L} = \operatorname{Cent}(\mu) = \mathbf{P} \cap \mathbf{P}^{+}$  over  $E_{\mathfrak{p}}$  containing  $\mathbf{T}_{E_{\mathfrak{p}}}$ .

Throughout §10, fix an isomorphism (of abstract fields)  $\iota : \overline{\mathbf{Q}}_p \xrightarrow{\sim} \mathbf{C}$ . We choose  $\iota$  compatibly with  $\mathbf{P}, \mathbf{P}^-$  and  $\Delta$  as explained in §4.1.6, so that  $\iota \mathbf{P}_{\overline{\mathbf{Q}}_p}$  is the stabilizer of the Hodge filtration for the  $\mathbf{R}$ -Hodge structure  $\mathrm{Ad} \circ h$ , where  $h \in \mathbf{X}$  gives rise to  $\iota \mu_{\overline{\mathbf{Q}}_p}$  via §N.6.2.

<span id="page-35-3"></span>10.1. Archimedean representation theory. We briefly review notation and results about real groups and Lie algebra cohomology needed later in §10.

<span id="page-35-1"></span>10.1.1. Infinitesimal Character. Following Buzzard-Gee [14], we say that  $\chi \in X^*(\mathbf{T})_{\mathbf{C}}$  is L-algebraic (resp. C-algebraic) if  $\chi \in X^*(\mathbf{T})$  (resp.  $\chi \in X^*(\mathbf{T}) + \rho$ ).

Let  $\mathfrak{g}$  (resp.  $\mathfrak{t}$ ) be the complexified Lie algebra of  $\mathbf{G}$  (resp.  $\mathbf{T}$ ) and let  $\mathfrak{z}$  be the center of the universal enveloping algebra of  $\mathfrak{g}$ . Let  $\mathrm{Sym}(\mathfrak{t})$  denote the symmetric algebra of  $\mathfrak{t}$ . We normalize the Harish-Chandra isomorphism

$$\mathfrak{z} \xrightarrow{\sim} (\operatorname{Sym}(\mathfrak{t}))^W$$

in the usual way, meaning that the infinitesimal character of the trivial representation is identified with  $\rho$ .

Let K be a maximal compact subgroup of  $\mathbf{G}(\mathbf{R})$ . Let  $\pi_{\infty}$  be an irreducible Harish-Chandra module i.e., an irreducible  $(\mathfrak{g}, K_{\mathbf{C}})$ -module. Write  $\chi_{\infty}$  for the infinitesimal character of  $\pi_{\infty}$ , identified with an element of  $X^*(\mathbf{T})_{\mathbf{C}}/W$  via (10.1.1).

Given a property  $\mathcal{P}$  of elements of  $X^*(\mathbf{T})_{\mathbf{C}}$  which is stable under the action of W, we say that  $\pi_{\infty}$  has property  $\mathcal{P}$  if  $\chi_{\infty}$  does. We say that an automorphic representation has property  $\mathcal{P}$  if its archimedean component does.

10.1.2. Limits of discrete series. The parametrization of limits of discrete series (LDS) for  $\mathbf{G}(\mathbf{R})$  is complicated by the fact that  $\mathbf{G}(\mathbf{R})$  is often neither semisimple nor connected in the classical topology. For a semisimple real Lie group which is connected in the classical topology, LDS were parametrized in [59, §1]. In the generality considered here, a full parametrization of LDS was given by the first author in both [35] and [34], based on explanations by Schmid and Vogan. Here we restrict attention to C-algebraic LDS, since they are the only LDS considered in this paper.

A C-algebraic LDS Harish-Chandra parameter is a pair  $(\lambda, \mathcal{C})$ , where  $\mathcal{C}$  is a Weyl chamber for the root datum  $\mathcal{RD}(\mathbf{G}, \mathbf{T})$  (see §§N.3.1,N.3.4),  $\lambda \in \partial \mathcal{C} \cap (X^*(\mathbf{T}) + \rho)$  and  $\langle \lambda, \alpha^\vee \rangle \neq 0$  for all  $\mathcal{C}$ -simple  $\alpha \in \Phi_{\mathbf{L}}$ . For every C-algebraic, LDS Harish-Chandra parameter  $(\lambda, \mathcal{C})$ , there exists a C-algebraic LDS Harish-Chandra module  $\pi(\lambda, \mathcal{C})$ . The LDS  $\pi(\lambda, \mathcal{C})$  may be constructed as the image of a discrete series  $\pi_\rho$  by the Zuckerman translation functor Transl<sub>W $\lambda$ </sub> which goes from Harish-Chandra modules of infinitesimal character  $W\rho$  to ones of infinitesimal character  $W\lambda$  (cf. the discussion preceding Th. 2.1 in [98]).

The fundamental dichotomy of non-degenerate versus degenerate was introduced for LDS by Knapp-Zuckerman in their classification of tempered representations [59]. An LDS  $\pi(\lambda, \mathcal{C})$  is degenerate if  $\lambda$  is orthogonal to  $\alpha^{\vee}$  for some  $\alpha \in \Phi_L$  (which is then necessarily not  $\mathcal{C}$ -simple); otherwise, it is called non-degenerate.

Following [32, §2.3], we say that an LDS is **X**-holomorphic if it is isomorphic to some  $\pi(\lambda, \mathcal{C})$  with  $\mathcal{C}$  the  $\Delta$ -dominant chamber (here **X** pertains to the Shimura datum (**G**, **X**)). As noted in *loc. cit.*, every **X**-holomorphic LDS is non-degenerate.

Remark 10.1.1 (Degeneracy via Langlands Parameters). The first author has shown that an equivalent formulation of degeneracy is that the image of the restriction to  $\mathbb{C}^{\times}$  of the Langlands parameter of  $\pi(\lambda, \mathcal{C})$  contains a simple group of rank at least two [34]. In turn, this characterization allows to generalize the non-degenerate/degenerate dichotomy to arbitrary Harish-Chandra modules, ([34, 31]).

10.1.3. Lie algebra cohomology. Let  $\mathfrak{p}$  (resp.  $\mathfrak{l}$ ) be the complexified Lie algebra of  $\mathbf{P}$  (resp.  $\mathbf{L}$ ). For  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ , let  $V_{\eta}$  be the irreducible finite-dimensional representation of  $\mathbf{L}_{\mathbf{C}}$  of highest weight  $\eta$ . Given a Harish-Chandra module  $\pi_{\infty}$  for  $\mathbf{G}(\mathbf{R})$ , write  $H^i(\mathfrak{p},\mathfrak{l},\pi_{\infty}\otimes V_{\eta})$  for the relative Lie algebra cohomology of the pair  $(\mathfrak{p},\mathfrak{l})$  with coefficients in  $\pi_{\infty}\otimes V_{\eta}$  (cf. [106, 47, 9], though note that the latter reference's notation is somewhat different).

Define the *cohomology degree*  $cd(\mathcal{C})$  of a Weyl chamber  $\mathcal{C}$  by

(10.1.2) 
$$\operatorname{cd}(\mathcal{C}) = \operatorname{Card}(\{\alpha \in \Phi^+ | \langle \mathcal{C}, \alpha^{\vee} \rangle < 0\}).$$

We shall need the following result about the  $(\mathfrak{p},\mathfrak{l})$ -cohomology of non-degenerate LDS.

<span id="page-36-1"></span>**Theorem 10.1.2** (Schmid-Williams-Harris). Let  $\pi(\lambda, \mathcal{C})$  be a non-degenerate LDS, normalized by requiring that  $\mathcal{C}$  is  $\Delta_{\mathbf{L}}$ -dominant. Then

(10.1.3) 
$$\dim H^{\operatorname{cd}(\mathcal{C})}(\mathfrak{p}, \mathfrak{l}, \pi(\lambda, \mathcal{C}) \otimes V_{-w_0, \mathfrak{l}, \lambda - \rho}) = 1.$$

Remark 10.1.3. Schmid computed the  $\mathfrak{n}$ -cohomology of discrete series [92]. The computation was generalized to non-degenerate LDS by Williams [109]. Harris translated their results to the setting of  $(\mathfrak{p},\mathfrak{l})$ -cohomology [48, Th. 3.4]. In Th. 3.4 of loc. cit., Harris makes the additional claim that the  $(\mathfrak{p},\mathfrak{l})$ -cohomology of  $\pi(\lambda,\mathcal{C})$  is zero in all degrees other than  $\mathrm{cd}(\mathcal{C})$ . This is false already for  $\mathbf{G} = GL(2)$ . It is true when  $\mathbf{G}(\mathbf{R})$  is semisimple and connected in the classical topology. We shall only use the part of loc. cit. stated in Th. 10.1.2, which is correct.

Following [48, §§2-3], we recall in the next corollary how Th. 10.1.2 leads to embedding the finite part  $\pi_f$  of a cuspidal automorphic representation  $\pi$  of **G** with non-degenerate LDS archimedean component  $\pi_{\infty}$  in the coherent cohomology of the Shimura variety Sh(**G**, **X**). To this end, it seems unfortunately necessary to use the following analogue for coherent cohomology of "interior cohomology" for local systems: Given  $\lambda \in X_{+,\mathbf{L}}^*(\mathbf{T})$ , let

$$(10.1.4) \qquad \qquad \bar{H}^i(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}(\lambda)) := \mathrm{Im}[H^i(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\lambda)) \to H^i(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{can}}(\lambda))],$$

the image of the map induced by the short exact sequence

$$0 \to \mathscr{V}^{\mathrm{sub}}(\lambda) = \mathscr{V}^{\mathrm{can}}(\lambda)(-D) \to \mathscr{V}^{\mathrm{can}}(\lambda) \to \mathscr{V}^{\mathrm{can}}(\lambda)|_D \to 0$$

associated to the boundary divisor D. Write  $\mathscr{S}_{\mathcal{K},\mathbf{C}}^{\Sigma} := \mathscr{S}_{\mathcal{K}}^{\Sigma} \otimes_{\mathcal{O}_{E},\mathfrak{p}} \mathbf{C}$ . By [48, Prop. 2.2], the (double) direct limits

<span id="page-36-3"></span>
$$\varinjlim_{K,\Sigma} H^i(\mathscr{S}^\Sigma_{K,\mathbf{C}},\mathscr{V}^\mathrm{sub}(\lambda)) \ \text{ and } \ \varinjlim_{K,\Sigma} H^i(\mathscr{S}^\Sigma_{K,\mathbf{C}},\mathscr{V}^\mathrm{can}(\lambda))$$

are both admissible  $\mathbf{G}(\mathbf{A}_f)$ -modules and the natural map from the first to the second is  $\mathbf{G}(\mathbf{A}_f)$ -equivariant. Thus  $\varinjlim_{\mathcal{K},\Sigma} \bar{H}^i(\mathscr{S}^{\Sigma}_{\mathcal{K},\mathbf{C}},\mathscr{V}(\lambda))$  is also an admissible  $\mathbf{G}(\mathbf{A}_f)$ -module.

<span id="page-36-2"></span>Corollary 10.1.4. Suppose  $\pi = \pi_f \otimes \pi(\lambda, \mathcal{C})$  is a cuspidal automorphic representation of G, with  $\mathcal{C}$  normalized to be  $\Delta_{\mathbf{L}}$ -dominant. Then there is a  $G(\mathbf{A}_f)$ -equivariant embedding

(10.1.5) 
$$\pi_f \hookrightarrow \varinjlim_{K \Sigma} \bar{H}^{\operatorname{cd}(\mathcal{C})}(\mathscr{S}_{K,\mathbf{C}}^{\Sigma}, \mathscr{V}^{\operatorname{sub}}(-w_{0,\mathbf{L}}\lambda - \rho)).$$

Remark 10.1.5. Though it will not be used in this paper, note that Cor. 10.1.4 is purely a result over  $\mathbf{C}$  and is valid for any Shimura datum, even if not of Hodge type and not known to admit integral models.

<span id="page-36-0"></span><sup>&</sup>lt;sup>8</sup>Our definition implicitly exploits the relationship between  $K_{\mathbf{C}}$  and  $\mathbf{L}_{\mathbf{C}}$  which exists due to  $(\mathbf{G}, \mathbf{X})$  being a Shimura datum. If G is a real group which does not arise as  $\mathbf{G}_{\mathbf{R}}$  for some Shimura datum  $(\mathbf{G}, \mathbf{X})$ , in particular if G admits discrete series but does not admit holomorphic discrete series, then one should define Harish-Chandra parameters differently in terms of roots of  $K_{\mathbf{C}}$ .

Proof of Cor. 10.1.4: This is one of the key upshots of [48, §§2-3] but not explicitly stated there in the above form, so we review the key steps: For every dominant  $\lambda$ , §2.6 of loc. cit. defines a space of harmonic cusp forms  $\mathcal{H}^*_{\text{cusp},\lambda}$ , which is a  $\mathbf{G}(\mathbf{A}_f)$ -module (not to be confused with our notation for Hecke algebras). By Th. 2.7 of loc. cit., there is a  $\mathbf{G}(\mathbf{A}_f)$ -equivariant injection

<span id="page-37-2"></span>
$$\mathcal{H}^*_{\mathrm{cusp},\lambda} \hookrightarrow \lim_{K \to \Sigma} \bar{H}^*(\mathscr{S}^{\Sigma}_{K,\mathbf{C}}, \mathscr{V}(\lambda)).$$

On the other hand, let  $\mathcal{A}_{\text{cusp}}(\mathbf{G})$  be the space of cuspidal automorphic forms of  $\mathbf{G}$ . Then (3.0.1) of *loc. cit.* states that

<span id="page-37-1"></span>(10.1.7) 
$$\mathcal{H}_{\text{cusp},\lambda}^* \cong H^*(\mathfrak{p},\mathfrak{l},\mathcal{A}_{\text{cusp}}(\mathbf{G}) \otimes V_{\lambda})$$

By a theorem of Gelfand and Piatetski-Shapiro, the space  $\mathcal{A}_{\text{cusp}}(\mathbf{G})$  is a semisimple, admissible  $\mathbf{G}(\mathbf{A}_f) \times (\mathfrak{g}, \mathbf{L}_{\mathbf{C}})$ module. Since  $(\mathfrak{p}, \mathfrak{l})$  acts trivially on the finite parts of automorphic representations, decomposing inside the righthand side of (10.1.7) yields a sum over all cuspidal automorphic representations  $\pi := \pi_f \otimes \pi_{\infty}$ :

<span id="page-37-3"></span>(10.1.8) 
$$H^*(\mathfrak{p}, \mathfrak{l}, \mathcal{A}_{\text{cusp}}(\mathbf{G}) \otimes V_{\lambda}) = \bigoplus_{\pi} m_{\text{cusp}}(\pi) \pi_f \otimes H^*(\mathfrak{p}, \mathfrak{l}, \pi_{\infty} \otimes V_{\lambda}),$$

where  $m_{\text{cusp}}(\pi)$  is the finite multiplicity with which  $\pi$  occurs in  $\mathcal{A}_{\text{cusp}}(\mathbf{G})$ . Putting together (10.1.6), (10.1.7), (10.1.8) and Th. 10.1.2 yields the desired embedding (10.1.5).

<span id="page-37-0"></span>10.2. **Applications of the Satake isomorphism.** Let v be a non-archimedean place of  $\mathbf{Q}$ . Assume  $v \notin \operatorname{Ram}(\mathbf{G}) \cup \{p\}$  and let  $\operatorname{Frob}_v$  be a geometric Frobenius at v. Recall  $\iota : \overline{\mathbf{Q}}_p \xrightarrow{\sim} \mathbf{C}$  and write  $\mathcal{H}_{v,\mathbf{C}} := \mathcal{H}_v \otimes_{\mathbf{Z}_p,\iota} \mathbf{C}$ .

Let  ${}^L\mathbf{G}^{\circ}$  be the dual group of  $\mathbf{G}$  over  $\mathbf{C}$ , i.e., the connected, reductive  $\mathbf{C}$ -group whose root datum is dual to  $\mathcal{RD}(\mathbf{G},\mathbf{T})$  (§N.3.1). Let  ${}^L\mathbf{G} = {}^L\mathbf{G}^{\circ} \rtimes \mathrm{Gal}(\overline{\mathbf{Q}}/\mathbf{Q})$  (resp.  ${}^L\mathbf{G}_v = {}^L\mathbf{G}_v^{\circ} \rtimes \mathrm{Gal}(\overline{\mathbf{Q}}_v/\mathbf{Q}_v)$ ) denote the Galois form of the L-group of  $\mathbf{G}$  (resp.  $\mathbf{G}_v$ ), cf. [7, §2]. Similar to [14, §2.1], we view  ${}^L\mathbf{G}$  and  ${}^L\mathbf{G}_v$  as group schemes over  $\mathbf{C}$  with component groups  $\mathrm{Gal}(\overline{\mathbf{Q}}/\mathbf{Q})$  and  $\mathrm{Gal}(\overline{\mathbf{Q}}_v/\mathbf{Q}_v)$ , respectively. A representation of  ${}^L\mathbf{G}$  will always mean a morphism of  $\mathbf{C}$ -group schemes  $r: {}^L\mathbf{G} \to GL(m)$  for some  $m \geq 1$ , which factors through  ${}^L\mathbf{G}^{\circ} \rtimes \mathrm{Gal}(F/\mathbf{Q})$  for some finite, Galois extension F over which  $\mathbf{G}$  splits; representations of  ${}^L\mathbf{G}_v$  are defined analogously (cf. [7, 2.6]). Given a representation  $r: {}^L\mathbf{G} \to GL(m)$  of  ${}^L\mathbf{G}$ , we denote by  $r_v: {}^L\mathbf{G}_v \to GL(m)$  the representation of  ${}^L\mathbf{G}_v$  obtained by restriction.

Let  $R_{\mathrm{fd}}(^L\mathbf{G}_v)$  denote the subalgebra of the group algebra  $\mathbf{Z}_p[^L\mathbf{G}_v]$  generated by the characters representations of  $^L\mathbf{G}_v$  (as just defined). Let  $R_{\mathrm{fd}}^{\mathrm{ss}}(^L\mathbf{G}_v)$  be the algebra obtained by considering elements of  $R_{\mathrm{fd}}(^L\mathbf{G}_v)$  as functions on the set of  $^L\mathbf{G}_v^{\circ}(\mathbf{C})$ -conjugacy classes in the coset  $^L\mathbf{G}_v^{\circ} \times \mathrm{Frob}_v$  and then restricting to the subset of semisimple  $^L\mathbf{G}_v^{\circ}(\mathbf{C})$ -conjugacy classes. As explained in [7, §§6-7], composing the Satake isomorphism with the isomorphism of Prop. 6.7 of *loc. cit.* gives a canonical identification 10

(10.2.1) 
$$\mathcal{H}_v[\sqrt{v}] \xrightarrow{\sim} R_{\mathrm{fd}}^{\mathrm{ss}}(^L \mathbf{G}_v)[\sqrt{v}].$$

We state two immediate, well-known consequences of (10.2.1) which will play a crucial role in characterizing the Galois (pseudo-)representations we shall construct.

First, there is a canonical bijection between the set of (complex) characters of  $\mathcal{H}_{v,\mathbf{C}}$  and the set of  ${}^L\mathbf{G}_v^{\circ}(\mathbf{C})$ conjugacy classes of semisimple elements in  ${}^L\mathbf{G}_v^{\circ} \times \mathrm{Frob}_v$ . Since the former set is in bijection with the set of
unramified, admissible, complex representations of  $\mathbf{G}(\mathbf{Q}_v)$ , so is the latter. If  $\pi_v$  is an unramified, admissible,
complex representation of  $\mathbf{G}(\mathbf{Q}_v)$ , we denote by  $\mathrm{Class}(\pi_v)$  the corresponding  ${}^L\mathbf{G}_v^{\circ}(\mathbf{C})$ -conjugacy class. Recall that
the correspondence  $\pi_v \leftrightarrow \mathrm{Class}(\pi_v)$  is given as follows: The Hecke algebra  $\mathcal{H}_{v,\mathbf{C}}$  acts on the line  $\pi_v^{\mathcal{K}_v}$  by a character  $\chi(\pi_v): \mathcal{H}_{v,\mathbf{C}} \to \mathbf{C}$ . Then  $\mathrm{Class}(\pi_v)$  is characterized as the unique  ${}^L\mathbf{G}_v^{\circ}(\mathbf{C})$ -conjugacy class such that the character
of  $R_{\mathrm{fd}}^{\mathrm{sc}}(^L\mathbf{G}_v)$  corresponding to  $\chi(\pi_v)$  via (10.2.1) is given by evaluation at  $\mathrm{Class}(\pi_v)$ .

In addition, for  $r: {}^L\mathbf{G} \to GL(m)$  as above, let  $\mathrm{Class}(\pi_v, r_v)$  be the conjugacy class in  $GL(m, \mathbf{C})$  generated by the image  $r_v(\mathrm{Class}(\pi_v))$ . Let  $\mathrm{Class}_{p,\iota}(\pi_v, r_v)$  denote the conjugacy class in  $GL(m, \overline{\mathbf{Q}}_p)$  obtained from  $\mathrm{Class}(\pi_v, r_v)$  via  $\iota$ .

For all  $j \geq 1$ , the function  $\operatorname{tr}^{j}(r) : {}^{L}\mathbf{G}_{v}(\mathbf{C}) \to \mathbf{C}$  defined by  $\tilde{g} \mapsto \operatorname{tr}(r(\tilde{g})^{j})$  lies in  $R_{\operatorname{fd}}^{\operatorname{ss}}({}^{L}\mathbf{G}_{v})$ .

**Definition 10.2.1.** Denote by  $T_v^{(j)}(r) \in \mathcal{H}_v[\sqrt{v}]$  the Hecke operator associated to  $\operatorname{tr}^j(r)$  by (10.2.1). Write  $T_v^{(j)}(r;i,n,\eta)$  for the image of  $T_v^{(j)}(r)$  in the coherent cohomology Hecke algebra  $\mathcal{H}^{i,n}(\eta)$  (§8.1.7).

<span id="page-37-6"></span>Remark 10.2.2. By definition, if  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  factors through  $\mathcal{H} \to \mathcal{H}^{i',n'}(\eta')$ , then  $T_v^{(j)}(r;i',n',\eta')$  maps to  $T_v^{(j)}(r;i,n,\eta)$  via the induced map  $\mathcal{H}^{i',n'}(\eta') \to \mathcal{H}^{i,n}(\eta)$ .

<sup>&</sup>lt;sup>9</sup>The group denoted  ${}^{L}\mathbf{G}$  in [7] is the topological group we denote  ${}^{L}\mathbf{G}(\mathbf{C})$ .

<span id="page-37-5"></span><span id="page-37-4"></span><sup>&</sup>lt;sup>10</sup>The isomorphism from *loc. cit.* is with **C**-coefficients, i.e.,  $\mathcal{H}_{v,\mathbf{C}} \stackrel{\sim}{\to} R^{\mathrm{ss}}_{\mathrm{fd}}(^L\mathbf{G}_v)_{\mathbf{C}}$ . However the integral version (10.2.1) holds because the Satake transform is defined over  $\mathbf{Z}_p[\sqrt{v}]$ , *cf.* [94, Proof of Lemma V.1.6].

<span id="page-38-1"></span>10.3. Existence of automorphic Galois representations. Let  $\pi$  be an automorphic representation of **G**. Fix a prime  $p \notin \text{Ram}(\pi)$  (§N.3.6). Let  $r: {}^L\mathbf{G} \longrightarrow GL(m)$  be a representation as defined in §10.2.

It will be convenient to introduce a condition which says that the pair  $(\pi, r)$  admits a p-adic Galois representation with weak local-global compatibility. If X is a conjugacy class in  $GL(m, \overline{\mathbb{Q}}_p)$ , then write  $X^{ss}$  for its semi-simplification i.e.,  $X^{ss}$  is the unique semisimple conjugacy class with the same characteristic polynomial as X.

Condition 10.3.1 (GalRep-p). The pair  $(\pi, r)$  satisfies (GalRep-p) if there exists a (necessarily unique) continuous, semisimple Galois representation

(10.3.1) 
$$R_{p,\iota}(\pi,r): \operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \longrightarrow GL(m,\overline{\mathbf{Q}}_p)$$

such that, for every  $v \notin \operatorname{Ram}(\pi) \cup \{p\}$ , one has  $R_{p,\iota}(\pi,r)(\operatorname{Frob}_v)^{\operatorname{ss}} = \operatorname{Class}_{p,\iota}(\pi_v,r_v)$  as  $GL(m,\overline{\mathbf{Q}}_p)$ -conjugacy classes

<span id="page-38-3"></span>Remark 10.3.2. Our formulation of the Langlands correspondence in Condition 10.3.1 is compatible with the L-algebraic conjecture of Buzzard-Gee [14, 3.2.1] as follows (see also [94, Rmk. V.1.5]):

- (a) Suppose  $\pi$  is L-algebraic. Assume that, as predicted by Langlands and Buzzard-Gee (and mentioned in §I.3.1) there exists  $R_{p,\iota}(\pi)$ :  $\operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \to {}^L\mathbf{G}(\overline{\mathbf{Q}}_p)$  such that for every  $v \notin \operatorname{Ram}(\pi) \cup \{p\}$ , one has  $R_{p,\iota}(\pi)(\operatorname{Frob}_v)^{\operatorname{ss}} = \operatorname{Class}_{p,\iota}(\pi_v)$  as  ${}^L\mathbf{G}^{\circ}(\overline{\mathbf{Q}}_p)$ -conjugacy classes in  ${}^L\mathbf{G}^{\circ}(\overline{\mathbf{Q}}_p) \rtimes \operatorname{Frob}_v$ . Then  $R_{p,\iota}(\pi,r) = r \circ R_{p,\iota}(\pi)$ .
- <span id="page-38-4"></span>(b) Assume (weak) Langlands functoriality holds for  $(\pi, r)$  as in [14, Conj. 6.1.1], i.e., that there exists an automorphic representation  $r_*\pi$  of GL(m) which is a transfer of  $\pi$  at infinity and at all unramified places. If  $(\pi, r)$  satisfies Condition 10.3.1, then  $R_{p,\iota}(\pi, r) = R_{p,\iota}(r_*\pi)$ .
- <span id="page-38-2"></span>10.4. Galois pseudo-representations associated to coherent cohomology modulo a prime power. Retain the notation of §10.3 for the rest of §10.

<span id="page-38-5"></span>10.4.1. The general Hodge-type case. Let  $(\mathbf{G}, \mathbf{X})$  be a Hodge-type Shimura datum  $(\mathbf{G}, \mathbf{X})$  and  $p \notin \operatorname{Ram}(\mathbf{G}) \cup \{2\}$ . Fix an integral model  $\mathscr{S}_{\mathcal{K}}$  over  $\mathcal{O}_{E,\mathfrak{p}}$  as in §4.1.4 and a toroidal compactification  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  as in §6.1.1. We assume that  $\Sigma$  (hence also  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$ ) is smooth, so that we have the action of the Hecke algebra  $\mathcal{H}^{i,n}(\eta)$  on  $H^{i}(\mathscr{S}_{\mathcal{K}}^{\Sigma}, \mathscr{V}^{\operatorname{sub}}(\eta))$  as defined in §8.1.5. Recall the notion of a  $\delta$ -regular character (Def. N.5.5).

Let  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . If  $(\mathbf{G},\mathbf{X})$  is neither of PEL-type nor of compact type, assume  $S_{\mathcal{K}}^{\Sigma}$  satisfies Condition 6.4.2 and  $(S_{\mathcal{K}}^{\Sigma},\eta)$  satisfies Condition 7.1.2.

<span id="page-38-0"></span>**Theorem 10.4.1** (Torsion, general case). Let  $\delta \in \mathbf{R}_{\geq 0}$  and  $r : {}^L\mathbf{G} \to GL(m)$  a representation (§10.2). Suppose that, for every  $\delta$ -regular, cuspidal, C-algebraic automorphic representation  $\pi$  with  $\pi_{\infty}$  discrete series, the pair  $(\pi, r)$  satisfies Condition 10.3.1 (GalRep-p). Then, associated to every triple  $(i, n, \eta)$ , with  $i \geq 0$  and  $n \geq 1$ , there is a unique, continuous pseudo-representation

(10.4.1) 
$$R_{p,\iota}(r;i,n,\eta): \operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \to \mathcal{H}^{i,n}(\eta),$$

satisfying, for all  $j \ge 1$  and all  $v \notin \text{Ram}(\mathbf{G}) \cup \{p\}$ ,

(10.4.2) 
$$R_{p,t}(r; i, n, \eta)(\text{Frob}_{v}^{j}) = T_{v}^{(j)}(r; i, n, \eta).$$

Upon consulting the proof of Th. 10.4.1, it should be clear to the reader that the proof can easily be adapted to treat several variants.

<span id="page-38-6"></span>Remark 10.4.2 (Variant I: Twisting). Under additional assumptions, one can introduce twisting between L-algebraic and C-algebraic in several ways, e.g., on the "domain"  $\mathbf{G}$  or on the "target" GL(m).

On the domain: Assume **G** admits a twisting element  $\theta$  as in [14, Def. 5.2.1]; for simplicity assume **G** is **Q**-split and that the restriction of r to  ${}^L$ **G**° is irreducible of highest weight  $\chi \in X^*(\mathbf{T})$ . Let  $T_v^{(j),C}(r) := v^{\langle \chi, \rho - \theta \rangle} T_v^{(j)}(r)$  be the twists of our old Hecke operators (the Tate normalization in [45, §8]). Mimicking the proof of Th. 10.4.1, one can prove the twisted variant where we assume instead that for all  $(\pi, r)$  as in the theorem,  $(\pi \otimes |\cdot|^{\rho-\theta}, r)$  satisfies Condition 10.3.1 and in the conclusion we replace the Hecke operators  $T_v^{(j)(r)}$  with the twists  $T_v^{(j),C}(r)$ .

On the target: Assume a weak transfer  $r_*\pi$  exists for all C-algebraic, discrete series and non-degenerate LDS (Rmk. 10.3.2(b)), and suppose that  $r_*$  maps C-algebraic to C-algebraic. Then one may again adapt the proof of Th. 10.4.1 to show that, if for all  $(\pi, r)$  as in the theorem Condition 10.3.1 holds for  $(r_*\pi \otimes |\cdot|^{(1-m)/2}, \mathrm{Id})$ , then the conclusion holds where we now replace  $T_v^{(j)}(r)$  with  $v^{(1-m)/2}T_v^{(j)}(r)$ .

In terms of twisting, the optimal generalization of Th. 10.4.1 may be one formulated in terms of a z-extension of G which admits a twisting element, following [14, §5] (and what Buzzard-Gee call the "C-group" of G). However, it seems this may require extending some of our results on Shimura varieties to z-extension of G and we have not attempted to carry this out.

Remark 10.4.3 (Variant II:  $\operatorname{Gal}(\overline{F}/F)$ ). Another notable variant is to replace  $\operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q})$  by  $\operatorname{Gal}(\overline{F}/F)$  for some number field F which plays a special role for the Shimura variety  $\operatorname{Sh}(\mathbf{G}, \mathbf{X})$ . An example which incorporates both variants for unitary similitude groups is given by Th. 10.4.5 below. In the Hilbert case, taking F to be the totally real field recovers the main result of [29].

<span id="page-39-4"></span>Remark 10.4.4. In the special case where  $\mathbf{G} = GSp(4)$  and r is the 'standard' four-dimensional representation (which coincides with the spin representation since g = 2), both twisted variants of Th. 10.4.1 apply unconditionally (a twisting element exists and C-algebraic is mapped to C-algebraic). The hypothesis holds with  $\delta = 0$ . This can be deduced in two ways: By using the work of Arthur [3] to transfer to GL(4) and then applying Shin's result [96], or by the work of Weissauer [108] and Laumon [73, 74]. (The Conditions 6.4.2, 7.1.2 hold because  $(\mathbf{G}, \mathbf{X})$  is of PEL-type.)

<span id="page-39-5"></span>10.4.2. Unitary similitude groups. Let  $(\mathbf{G}, \mathbf{X})$  be an arbitrary Shimura datum of PEL type A. Then  $\mathbf{G}$  is an inner form of the quasi-split unitary group associated to a quadratic extension of an imaginary CM field F over its totally real subfield  $F^+$ .

Given  $v \notin \text{Ram}(\mathbf{G}) \cup \{p\}$ , a prime w of F above v and  $j \geq 1$ , let  $T_w^{(j),U}$  be the Hecke operator defined between Lemma 6.1 and Lemma 6.2 of [50] and denoted  $T_v^{(i)}$  there. Let  $T_w^{(j),U}(i,n,\eta)$  be the image of  $T_w^{(j),U}$  in  $\mathcal{H}^{i,n}(\eta)$ .

<span id="page-39-1"></span>**Theorem 10.4.5** (Torsion, unitary case). For every triple  $(i, n, \eta)$ , with  $i \in \mathbf{Z}_{\geq 0}$ ,  $n \in \mathbf{Z}_{\geq 1}$  and  $\eta \in X_{+, \mathbf{L}}^*(\mathbf{T})$ , there exists a unique pseudo-representation

(10.4.3) 
$$R_{p,\iota}(i,n,\eta): \operatorname{Gal}(\overline{F}/F) \to \mathcal{H}^{i,n}(\eta),$$

satisfying, for all  $j \ge 1$  and all w above some  $v \notin \text{Ram}(\mathbf{G}) \cup \{p\}$ ,

<span id="page-39-7"></span>(10.4.4) 
$$R_{p,\iota}(i, n, \eta)(\text{Frob}_w^j) = T_w^{(j),U}(i, n, \eta).$$

#### <span id="page-39-2"></span>10.5. Galois representations associated to non-degenerate LDS.

10.5.1. The Hodge-type case. Return to the setting of §10.4.1. If  $(\mathbf{G}, \mathbf{X})$  is neither of PEL-type nor of compact type, assume  $S_K^{\Sigma}$  satisfies Condition 6.4.2 for all sufficiently small  $\mathcal{K}^p$ .

<span id="page-39-0"></span>**Theorem 10.5.1** (LDS, Hodge case). Suppose there exists  $\delta \in \mathbf{R}_{\geq 0}$  and  $r : {}^L\mathbf{G} \to GL(m)$  such that, for every  $\delta$ -regular, cuspidal, C-algebraic automorphic representation  $\pi'$  with  $\pi'_{\infty}$  discrete series, the pair  $(\pi', r)$  satisfies Condition 10.3.1 (GalRep-p). Let  $\pi$  be a cuspidal automorphic representation of  $\mathbf{G}$  with  $\pi_{\infty} = \pi(\lambda, \mathcal{C})$  a C-algebraic, non-degenerate LDS. If  $p \notin \text{Ram}(\pi)$  and  $(S_{\mathcal{K}}^{\Sigma}, -w_{0,\mathbf{L}}\lambda - \rho)$  satisfies Condition 7.1.2, then the pair  $(\pi, r)$  satisfies (GalRep-p).

As in Rmks. 10.4.2-10.4.4, one has variants with twisting between L and C-algebraic, replacing  $\operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q})$  with  $\operatorname{Gal}(\overline{F}/F)$  for suitable F related to  $(\mathbf{G}, \mathbf{X})$  and one deduces an unconditional result for  $\mathbf{G} = GSp(4)$ , r the 'standard' four-dimensional representation.

<span id="page-39-3"></span>Remark 10.5.2. It is interesting whether Th. 10.5.1 may be used to extend [63] to produce GSpin(2g+1)-valued Galois representations for non-degenerate LDS.

10.5.2. Unitary Similitude Groups. Return to the setting of §10.4.2:  $(\mathbf{G}, \mathbf{X})$  is of PEL-type A associated to a CM extension  $F/F^+$ .

We have found useful the description of local base change from unitary similitude groups to GL(m) at unramified primes in [50, §1.3]. <sup>11</sup> Let  $\pi$  be a cuspidal automorphic representation of G. For every  $v \notin \text{Ram}(\pi)$  and w a place of F above v, define the base change of  $\pi_v$ , denoted  $BC(\pi_v)$ , and its w-part  $BC(\pi_v)_w$  as in [50, §1.3]. Write  $\text{rec}_{F_w}$  for the local Langlands correspondence, normalized as in [49]. Let  $W_{F_w}$  be the Weil group of  $F_w$ . A superscript  $(-)^{\text{ss}}$  will denote semi-simplification.

**Theorem 10.5.3** (LDS, unitary case). Suppose  $\pi$  is a cuspidal, C-algebraic automorphic representation of  $\mathbf{G}$ , such that  $\pi_{\infty}$  is a non-degenerate LDS. Then, for all  $p \notin \text{Ram}(\pi)$ , there exists a unique continuous, semisimple Galois representation

(10.5.1) 
$$R_{n,l}(\pi) : \operatorname{Gal}(\overline{F}/F) \longrightarrow GL(m, \overline{\mathbb{Q}}_n)$$

such that, for all primes w of F which lie over some prime  $v \notin \text{Ram}(\pi)$ , the representation  $R_{p,\iota}(\pi)$  is unramified at w and there is an isomorphism of Weil-Deligne representations

$$(10.5.2) (R_{p,\iota}(\pi)|_{W_{F_w}})^{\operatorname{ss}} \cong \iota^{-1} \operatorname{rec}_{F_w} \left( \operatorname{BC}(\pi_v)_w \otimes |\cdot|_w^{\frac{1-m}{2}} \right).$$

<span id="page-39-6"></span><sup>&</sup>lt;sup>11</sup>This seems to be one of many things that has been potentially "well-known to experts" for a long time, but difficult to extract from the literature prior to [50].

10.5.3. Remarks about Hodge-Tate weights. Let  $\pi$  be as in Th. 10.5.1 or Th. 10.5.3. Assume  $\pi$  is L-algebraic. The Hodge-Tate cocharacter of  $R_{p,\iota}(\pi)$  is conjectured to be the infinitesimal character  $\chi_{\infty}$  of  $\pi_{\infty}$ , when viewed as a cocharacter of  ${}^L\mathbf{G}^{\circ}$ , [14, Rmk. 3.2.3]. When  $\pi$  is C-algebraic but not L-algebraic, after possibly passing to a z-extension of  $\mathbf{G}$ , one must apply twisting to reduce to the L-algebraic case, as explained in loc. cit.

By the first author's work [34], the condition " $\pi_{\infty}$  is a non-degenerate LDS" is equivalent to the following condition on the Hodge-Tate cocharacter: The adjoint group of  $\operatorname{Cent}_{\mathbf{G}^{\circ}}(\chi_{\infty})$  is a product of copies of PGL(2).

Concretely, assume that  $\mathbf{G}$  is a form of GL(n) (resp. SO(2n), SO(2n+1), Sp(2n)) and that r is the 'standard' representation of  ${}^L\mathbf{G}$  of dimension n (resp. 2n, 2n, 2n, 2n+1). Then " $\pi_{\infty}$  non-degenerate LDS" conjecturally means that every Hodge-Tate weight of  $R_{p,\iota}(\pi,r)$  has multiplicity  $\leq 2$ , except that for  $\mathbf{G}_{\mathbf{C}} = Sp(2n)$  (resp.  $\mathbf{G}_{\mathbf{C}} = SO(2n)$ ) the weight 0 may have multiplicity 3 (resp. 4). Recall that, by the standard dictionary between Hodge-Tate weights and Hodge numbers, this means that if  $R_{p,\iota}(\pi,r)$  is the p-adic realization of a Motive M, then the Hodge numbers  $h^{p,q}$  of the Betti realization of M are all  $\leq 2$  (with the same exceptions for Sp(2n) and SO(2n) as before).

By contrast, in the same examples, the condition " $\pi_{\infty}$  is a holomorphic LDS" conjecturally corresponds to the stricter restriction that all Hodge-Tate weights have multiplicity 1, except possibly for one weight of multiplicity 2 if  $\mathbf{G}_{\mathbf{C}} = GL(n)$ , the weight 0 with multiplicity 3 if  $\mathbf{G}_{\mathbf{C}} = Sp(2n)$  and two weights of multiplicity 2 if  $\mathbf{G}_{\mathbf{C}} = SO(2n+1)$  or  $\mathbf{G}_{\mathbf{C}} = SO(2n)$ . In the other direction, " $\pi_{\infty}$  an arbitrary LDS" (conjecturally) imposes no restriction on the multiplicities of the Hodge-Tate weights.

<span id="page-40-1"></span>10.6. **Proof of** Th. 10.4.1 **and** Th. 10.5.1. The results of §§10.4-10.5 will be deduced from our factorization theorem (Th. 8.2.1) coupled with the previously known Cor. 10.1.4 on which automorphic representations appear in the coherent cohomology of Shimura varieties. The proofs in the case of general groups and in that of unitary groups are almost identical. The only difference is that in the former case we assume that some very regular  $\pi$  satisfy Condition 10.3.1, while in the latter case this is given to us by Cor. 1.3 of [50]. Moreover, the argument we use is analogous to the one introduced by Taylor [101], and then applied in [54, 32, 39, 50]. For these reasons, we only treat the case of general groups to avoid repetition.

Remark 10.6.1. Note that [50, Cor. 1.3] is a concise combination of Shin's results [96, Th. 1.2] and [97, Th. A.1]. These build on the work of many people, see also Rmk. 10.6.2.

Consider first the case of torsion.

Proof of Th. 10.4.1: Fix  $(r; i, n, \eta)$  and  $\delta \in \mathbb{R}_{>0}$  as in Th. 10.4.1. Put

<span id="page-40-2"></span>
$$\delta' = \delta + 1 + \max\{|\langle \rho, \alpha^{\vee} \rangle| | \alpha \in \Phi(\mathbf{G}, \mathbf{T})\}.$$

By Th. 8.2.1(c) there exists  $\nu \in F(i, n, \eta)$  which is  $\delta'$ -regular. Hence  $-w_{0,\mathbf{L}}(\nu + \rho)$  is  $\max\{\delta, 1\}$ -regular.

Since  $\eta_{\omega} \in \mathcal{C}$  (§3.4) and  $\nu \in F(i, n, \eta)$ , Th. 8.2.1(b) implies that there exists  $k \in \mathbf{Z}_{\geq 1}$  such that  $\nu + ak\eta_{\omega} \in F(i, n, \eta)$  for all  $a \in \mathbf{Z}_{\geq 1}$ . Since  $\nu$  is  $\delta'$ -regular, there exists  $a_0 \in \mathbf{Z}_{\geq 1}$  such that  $\nu + ak\eta_{\omega}$  is  $\delta'$ -regular for all  $a \geq a_0$ . Thus  $-w_{0,\mathbf{L}}(\nu + \rho + ak\eta_{\omega})$  is  $\max\{\delta, 1\}$ -regular for all  $a \geq a_0$ . By Cor. 7.1.5, there exists  $a_1 \in \mathbf{Z}_{\geq 1}$  such that the reduction map

(10.6.1) 
$$H^{0}(\mathscr{S}_{\mathcal{K}}^{\Sigma}, \mathscr{V}^{\mathrm{sub}}(\nu + ak\eta_{\omega})) \to H^{0}(\mathscr{S}_{\mathcal{K}}^{\Sigma, n}, \mathscr{V}^{\mathrm{sub}}(\nu + ak\eta_{\omega}))$$

is surjective for all  $a > a_1$ .

From now on, fix k as above and assume  $a \ge \max\{a_0, a_1\}$ . Then

- (i)  $\nu + ak\eta_{\omega} \in F(i, n, \eta),$
- (ii)  $-w_{0,\mathbf{L}}(\nu+\rho+ak\eta_{\omega})$  is  $\max\{\delta,1\}$ -regular, and
- (iii) the map (10.6.1) is surjective.

Suppose  $f \in H^0(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\nu + ak\eta_{\omega}))$  is a Hecke eigenform and let  $\pi(f)$  be the cuspidal automorphic representation of  $\mathbf{G}$  that it generates. By the Casselman-Osborne Theorem (cf. [48, Prop. 3.1.4]), the infinitesimal character  $\chi_{\infty}(f)$  of  $\pi(f)$  is given by  $\chi_{\infty}(f) = -w_{0,L}(\nu + ak\eta_{\omega} + \rho)$ . Hence  $\chi_{\infty}(f)$  is 1-regular by construction. Since  $\pi(f)$  (hence also  $\pi(f)_{\infty}$ ) is unitary, it follows from a result of Salamanca-Riba [91, Th. 1.8] that the archimedean component  $\pi(f)_{\infty}$  is discrete series. Therefore the hypothesis of Th. 10.4.1 concerning (GalRep-p) applies to f.

Applying this hypothesis to all eigenforms in  $H^0(\mathscr{S}^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\nu + ak\eta_{\omega}))$  yields a unique continuous, semisimple Galois representation

<span id="page-40-0"></span>(10.6.2) 
$$\rho_a: \operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \longrightarrow GL(m, \mathcal{H}^{0,+}(\nu + ak\eta_{\omega}) \otimes \overline{\mathbf{Q}}_p)$$

such that  $(\operatorname{tr} \rho_a)(\operatorname{Frob}_v^j) = T_v^{(j)}(r; 0, +, \nu + ak\eta_\omega)$  for all  $j \in \mathbf{Z}_{\geq 1}$  (§10.2). Since  $\operatorname{tr} \rho_a \subset \mathcal{H}^{0,+}(\nu + ak\eta_\omega)$ , there is an induced pseudo-representation

(10.6.3) 
$$\rho_a^{\text{pseudo}} : \text{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \longrightarrow \mathcal{H}^{0,+}(\nu + ak\eta_{\omega}).$$

Since a is chosen so that (10.6.1) is surjective, Lemma 8.3.1 implies that  $\mathcal{H} \to \mathcal{H}^{0,n}(\nu + ak\eta_{\omega})$  factors through  $\mathcal{H} \to \mathcal{H}^{0,+}(\nu + ak\eta_{\omega})$ . Since  $\nu + ak\eta_{\omega} \in F(i,n,\eta)$ ,  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  factors through  $\mathcal{H} \to \mathcal{H}^{0,n}(\nu + ak\eta_{\omega})$ . Composing the two factorizations shows that  $\mathcal{H} \to \mathcal{H}^{i,n}(\eta)$  factors through  $\mathcal{H} \to \mathcal{H}^{0,+}(\nu + ak\eta_{\omega})$ , yielding a map

$$\mathcal{H}^{0,+}(\nu + ak\eta_{\omega}) \to \mathcal{H}^{i,n}(\eta).$$

Further composing with  $\rho_a^{\text{pseudo}}$  gives a continuous pseudo-representation  $R_{p,\iota}(r;i,n,\eta)$  satisfying (10.4.2)(see Rmk. 10.2.2). Uniqueness follows from the Tchebotarev density theorem.

The case of LDS will now be deduced from that of torsion.

Proof of Th. 10.5.1: Let  $\pi$  be as in Th. 10.5.1, with  $\pi_{\infty} = \pi(\lambda, \mathcal{C})$ . Let  $\eta := -w_{0,\mathbf{L}}\lambda - \rho$  and  $i := \operatorname{cd}(\mathcal{C})$ . Since  $(\lambda, \mathcal{C})$  is non-degenerate,  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$ . For every  $v \notin \operatorname{Ram}(\pi)$ , let  $\mathcal{K}_v$  be a hyperspecial subgroup of  $\mathbf{G}(\mathbf{Q}_v)$ . Since  $\pi$  is unramified at p, this includes a hyperspecial subgroup  $\mathcal{K}_p \subset \mathbf{G}(\mathbf{Q}_p)$ . Let  $\gamma'_{\pi} \in \bigcap_{v \notin \operatorname{Ram}(\pi)} \pi_f^{\mathcal{K}_v}$ ; thus  $\gamma'_{\pi}$  is a Hecke eigenform for  $\mathcal{H}$  satisfying  $\gamma'_{\pi} \in \pi_f^{\mathcal{K}_p}$ . Choose a sufficiently small open compact subgroup  $\mathcal{K}^p \subset \mathbf{G}(\mathbf{Q}_p^p)$  of the form  $\mathcal{K}^p = \prod_{v \neq p} \mathcal{K}'_v$  with  $\mathcal{K}'_v \subset \mathbf{G}(\mathbf{Q}_v)$  so that

- (a) we may apply §6.1.1 to the integral model  $\mathscr{S}_{\mathcal{K}}$ ,
- (b) for all  $v \notin \text{Ram}(\pi) \cup \{p\}$ , one has  $\mathcal{K}'_v \subset \mathcal{K}_v$ .

By Cor. 10.1.4, the vector  $\gamma'_{\pi}$  is a Hecke eigenclass in  $\bar{H}^i(\mathscr{S}^{\Sigma}_{\mathcal{K}} \otimes \overline{\mathbf{Q}}_p, \mathscr{V}(\eta))$  for some smooth toroidal compactification  $\mathscr{S}^{\Sigma}_{\mathcal{K}}$  (recall from §8.1.5 that refining  $\Sigma$  does not change the cohomology).

First we explain how to pass from the "interior cohomology" (10.1.4) to that of the subcanonical extension. Let  $\bar{\mathcal{H}}^{i,0}(\eta)$  be the image of the Hecke algebra  $\mathcal{H}$  in  $\operatorname{End}(\bar{H}^i(\mathscr{S}^\Sigma_{\mathcal{K}} \otimes \overline{\mathbf{Q}}_p, \mathscr{V}(\eta)))$  By definition, one has the surjection  $H^i(\mathscr{S}^\Sigma_{\mathcal{K}} \otimes \overline{\mathbf{Q}}_p, \mathscr{V}^{\operatorname{sub}}(\eta)) \to \bar{H}^i(\mathscr{S}^\Sigma_{\mathcal{K}} \otimes \overline{\mathbf{Q}}_p, \mathscr{V}(\eta))$ . Thus  $\mathcal{H} \to \bar{\mathcal{H}}^{i,0}(\eta)$  factors through  $\mathcal{H}^{i,0}(\eta)$ . Therefore there exists an eigenclass  $\gamma_{\pi} \in H^i(\mathscr{S}^\Sigma_{\mathcal{K}} \otimes \overline{\mathbf{Q}}_p, \mathscr{V}^{\operatorname{sub}}(\eta))$  with the same eigenvalues as  $\gamma'_{\pi}$ . After replacing  $\mathcal{O}_{\mathfrak{p}}$  by a finite extension, we may assume that  $\gamma_{\pi}$  lies in  $H^i(\mathscr{S}^\Sigma_{\mathcal{K}}, \mathscr{V}^{\operatorname{sub}}(\eta))$ .

Let  $\theta_+: \mathcal{H}^{i,+}(\eta) \longrightarrow \mathcal{O}_{\mathfrak{p}}$  be the eigenvalue map of  $\gamma_{\pi}$  and  $\theta_n: \mathcal{H}^{i,n}(\eta) \longrightarrow \mathcal{O}_{\mathfrak{p}}/\mathfrak{p}^n$  its reduction modulo  $\mathfrak{p}^n$ . By definition of the correspondence  $\pi_v \leftrightarrow \text{Class}(\pi_v)$  (recalled in §10.2),

$$\theta_+(T_v^{(j)}(r;i,+,\eta)) = \iota^{-1}\operatorname{tr}(r_v(\operatorname{Class}(\pi_v)^j)) = \operatorname{tr}(\operatorname{Class}_{p,\iota}(\pi_v,r_v)^j).$$

By the assumption that  $S_{\mathcal{K}}^{\Sigma}$  satisfies Condition 6.4.2 and that  $(S_{\mathcal{K}}^{\Sigma}, \eta)$  satisfies Condition 7.1.2, Th. 10.4.1 applies to  $H^{i}(\mathscr{S}_{\mathcal{K}}^{\Sigma,n}, \mathscr{V}^{\mathrm{sub}}(\eta))$  and yields a continuous pseudo-representatation  $R_{p,\iota}(r; i, n, \eta)$  satisfying (10.4.2). Since  $\theta_{n}(T_{v}^{(j)}(r; i, n, \eta))$  is the reduction modulo  $\mathfrak{p}^{n}$  of  $\theta_{+}(T_{v}^{(j)}(r; i, +, \eta))$ , the  $\theta_{n} \circ R_{p,\iota}(r; i, n, \eta)$  form a  $\mathfrak{p}$ -adic system of pseudo-representations satisfying

$$\theta_n \circ R_{p,\iota}(r; i, n, \eta)(\operatorname{Frob}_v^j) \equiv \operatorname{tr}(\operatorname{Class}_{p,\iota}(\pi_v, r_v)^j) \pmod{\mathfrak{p}^n}.$$

Their limit gives a continuous pseudo-representation  $\chi: \operatorname{Gal}(\overline{\mathbf{Q}}/\mathbf{Q}) \to \mathcal{O}_{\mathfrak{p}} \hookrightarrow \overline{\mathbf{Q}}_p$  satisfying

$$\chi(\operatorname{Frob}_v^j) = \operatorname{tr}(\operatorname{Class}_{p,\iota}(\pi_v, r_v)^j)$$

for all  $j \geq 1$ . By [101, Th. 1], the  $\overline{\mathbf{Q}}_p$ -valued pseudo-representation  $\chi$  is the trace of a unique, semisimple (true) representation  $R_{p,\iota}(\pi,r)$  satisfying Condition 10.3.1 (GalRep-p) (for a conjugacy class  $X \subset GL(n,\overline{\mathbf{Q}}_p)$ , the sequence of traces  $(\operatorname{tr}(X^j))_{j\geq 1}$  uniquely determines the semi-simplification  $X^{\operatorname{ss}}$ ). Uniqueness follows again from the Tchebotarev density theorem.

<span id="page-41-1"></span>Remark 10.6.2. In view of the "change of weight" afforded by Th. 8.2.1(c), in the case of unitary similitude groups we only use a weak version of [50, Cor. 1.3], where the archimedean component is  $\delta$ -regular. By applying Th. 8.2.1(c) with  $\delta = 1$ , it suffices for us to combine Shin's earlier work [96, Th. 1.2] with Labesse's restricted base change [64]. In particular our results use neither Shin's extended base change [97, Th. A.1], nor the work of Chenevier-Harris [22].

11. Systems of Hecke eigenvalues on the generalized superpecial locus

<span id="page-41-0"></span>This section is concerned with the generalization of Serre's letter to Tate, Th. I.4.1.

<span id="page-41-2"></span><sup>&</sup>lt;sup>12</sup>To be completely precise, Labesse's result has the disadvantage of being stated for unitary groups rather than unitary similitude groups, and to assume  $F^+ \neq \mathbf{Q}$ , so in that respect we do use Shin's [97, Th. A.1], but not concerning the regularity of the archimedean component.

11.1. Statement of the result and a corollary. Recall that  $S_{\mathcal{K}}$  is the special fiber of the integral model  $\mathscr{S}_{\mathcal{K}}$  (§4.2) at a prime p > 2 and that the stratum  $S_e$  is nonempty and zero-dimensional. "System of Hecke eigenvalues" will always refer to the Hecke algebra  $\mathcal{H}$  defined in §8.1.1. By §§8.1.4-8.1.5, for  $? \in \{\text{can, sub}\}$  one has the  $\mathcal{H}$ -modules

$$M^i := \bigoplus_{\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})} H^i(S_{\mathcal{K}}, \mathscr{V}(\eta)), \quad M^i_? := \bigoplus_{\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})} H^i(S_{\mathcal{K}}^{\Sigma}, \mathscr{V}^?(\eta)), \quad \text{and} \quad M_e := \bigoplus_{\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})} H^0(S_e, \mathscr{V}(\eta)).$$

<span id="page-42-0"></span>**Theorem 11.1.1.** If (G, X) is neither of compact-type, nor of PEL-type, then assume:

(\*) There exists a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant Cartier divisor D' such that  $D'_{\mathrm{red}} = D$  and  $\omega^k(-D')$  is ample on  $\mathscr{S}_{\mathcal{K}}^{\Sigma}$  for all  $k \gg 0$ .

<span id="page-42-1"></span>Then each of the  $\mathcal{H}$ -modules  $M^0, M^0_{\mathrm{sub}}, M^0_{\mathrm{can}}$  and  $M_e$  admits precisely the same systems of Hecke eigenvalues. Remark 11.1.2.

- (a) If (G, X) is of compact type, then  $(\star)$  is trivially satisfied with D = D' = 0, since then  $\omega$  is ample on  $\mathscr{S}_{K}$ .
- (b) If  $(\mathbf{G}, \mathbf{X})$  is of noncompact, PEL type, then [66, Th. 7.3.3.4] (explained further in [69, (2.1)]) produces a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant Cartier divisor D' satisfying  $(\star)$  for  $\Sigma$  as above which is also projective [69, Def. 7.3.1.1]. The construction of D' should apply in the general Hodge case to the compactifications of [77] (still associated to projective  $\Sigma$ ). Since we were unable to find a precise reference to this effect, the existence of such D' appears as hypothesis  $(\star)$  in Th. 11.1.1.
- (c) Note that Th. 11.1.1 assumes neither Koecher's Principle nor Conditions 6.4.2, 7.1.2 for  $S_K$ .

An immediate consequence of Rmk. 8.2.5 and Th. 11.1.1 is:

<span id="page-42-3"></span>**Corollary 11.1.3.** If i = 0, make the assumptions of Th. 11.1.1; if i > 0, then in addition make the assumptions of Th. 8.2.1. Then only a finite number of systems of Hecke eigenvalues appear in

(11.1.1) 
$$\bigoplus_{i>0} M_{\mathrm{sub}}^i \oplus M_{\mathrm{can}}^i \oplus M^0.$$

Remark 11.1.4. Using Lan's Higher Koecher Principle [71] one obtains results analogous to Cor. 11.1.3 for  $M^j$ , j > 0, under additional hypotheses about the codimension of the boundary of  $S_{\mathcal{K}}^{\min}$ .

11.2. **Proof of** Th. 11.1.1 and Cor. 11.1.3. The hypotheses of Th. 11.1.1 are assumed throughout this section. Given  $\mathcal{H}$ -modules M, M', write  $M \leadsto_{\mathcal{H}} M'$  to signify that every system of Hecke eigenvalues appearing in M also appears in M'. We shall prove the following cycle of relations:

$$M^0 \leadsto_{\mathcal{H}} M_e \leadsto_{\mathcal{H}} M^0_{\text{sub}} \leadsto_{\mathcal{H}} M^0_{\text{can}} \leadsto_{\mathcal{H}} M^0.$$

The relations  $M^0_{\mathrm{sub}} \leadsto_{\mathcal{H}} M^0_{\mathrm{can}} \leadsto_{\mathcal{H}} M^0$  are trivial (Lemma 11.2.2). Besides that, the argument is in three steps, analogous to simplified versions of the steps "Descent", "Weight increase" and "Ascent" in the proof of Th. 8.2.1: First we use Ghitza's argument [30] to show that  $M^0 \leadsto_{\mathcal{H}} M_e$  (Lemma 11.2.4). Second, Lemma 11.2.5 uses the nowhere vanishing Hasse invariant  $h_e \in H^0(S_e, \omega^{N_e})$  to exhibit  $m \geq 1$  such that, for all  $\eta$ , the systems appearing in  $H^0(S_e, \mathcal{V}(\eta))$  are the same as those appearing in  $H^0(S_e, \mathcal{V}(\eta) \otimes \omega^m)$ . Finally, Lemma 11.2.6 shows that if m' is a sufficiently large multiple of m, then every system appearing in  $H^0(S_e, \mathcal{V}(\eta) \otimes \omega^m)$  also appears in  $H^0(S_e^{\Sigma}, \mathcal{V}^{\mathrm{sub}}(\eta) \otimes \omega^m)$ ). The one and only step which uses the hypothesis on the existence of a Cartier divisor D' as in Th. 11.1.1 is Lemma 11.2.6.

<span id="page-42-2"></span>Remark 11.2.1. The argument given in [30, Prop. 24] and cited in [90, Prop. 5.17] for Lemma 11.2.6 seems to contain a serious error: If  $j: S_{\mathcal{K}} \to \mathbf{P}^n$  is the immersion associated to a very ample power  $\omega^m$  of  $\omega$ , then it is claimed in loc. cit. that every  $\mathcal{V}(\lambda)$  admits a locally free extension to  $\mathbf{P}^n$ . Already for the Siegel scheme  $S_{g,\mathcal{K}}$  with  $g \geq 2$  this cannot be: It would contradict the well-known fact that most  $\mathcal{V}(\lambda)$  fail to admit a locally free extension to  $S_{\mathcal{K}}^{\min}$ .

<span id="page-42-4"></span> $\textbf{Lemma 11.2.2.} \ \ One \ has \ H^0(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\operatorname{sub}}(\eta)) \leadsto_{\mathcal{H}} H^0(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\operatorname{can}}(\eta)) \ \ and \ H^0(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\operatorname{can}}(\eta)) \leadsto_{\mathcal{H}} H^0(S_{\mathcal{K}}, \mathscr{V}(\eta)).$ 

*Proof.* The  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant short exact sequence

$$0 \to \mathscr{V}^{\mathrm{sub}}(\eta) \to \mathscr{V}^{\mathrm{can}}(\eta) \to \mathscr{V}^{\mathrm{can}}(\eta)|_D \to 0$$

induces a Hecke-equivariant injection  $H^0(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{sub}}(\eta)) \hookrightarrow H^0(S^{\Sigma}_{\mathcal{K}} \mathscr{V}^{\mathrm{can}}(\eta))$ . Since  $S_{\mathcal{K}}$  is open dense in  $S^{\Sigma}_{\mathcal{K}}$ , restriction gives another Hecke-equivariant injection  $H^0(S^{\Sigma}_{\mathcal{K}}, \mathscr{V}^{\mathrm{can}}(\eta)) \hookrightarrow H^0(S_{\mathcal{K}}, \mathscr{V}(\eta))$ . Applying Lemma 8.3.1 to these injections of  $\mathcal{H}$ -modules gives the result.

To show that  $M^0 \leadsto_{\mathcal{H}} M_e$ , we shall need an auxiliary lemma about "good filtrations" of L-modules. Let V be an L-module (not necessarily finite-dimensional). Recall that an ascending filtration  $0 = V_0 \subset V_1 \subset \cdots \subset V_i \subset \cdots \subset V$  of V by L-submodules  $V_i$  is called a good filtration if  $\bigcup_i V_i = V$  and every graded piece  $V_i/V_{i-1} \cong V_{\eta_i}$  for some  $\eta_i \in X_{+,L}^*(T)$ , [53, II, 4.1.6]. Recall that the assumption p > 2 is still in force.

<span id="page-43-6"></span>**Lemma 11.2.3.** For every  $n \ge 1$  and  $\eta \in X_{+,L}^*(T)$ , the L-module  $\operatorname{Sym}^n((\operatorname{Lie}(G)/\operatorname{Lie}(P))^{\vee}) \otimes V_{\eta}$  admits a good filtration.

*Proof.* The proof amounts to combining a result of Andersen-Janzten [1] on good filtrations for  $\operatorname{Sym}^n \operatorname{Lie}(G)$  with closure properties for good filtrations given by Donkin [26].

Since  $(\mathbf{G}, \mathbf{X})$  is of Hodge type,  $\mathbf{G}$  (and hence also G and L) are of classical type (i.e., have no factors of exceptional type) [24, 1.3.10]. Therefore every prime p > 2 is good for G in the sense of Steinberg [1, §4.4]: The  $\Delta$ -dominant T-weights  $\chi$  of  $\mathrm{Lie}(G)$  all satisfy  $0 \le \langle \chi, \alpha^{\vee} \rangle \le p - 1$  for all  $\alpha \in \Delta$ . Let  $\tilde{G}$  be the simply-connected cover of the derived subgroup of G (in the sense of algebraic groups, as in [53, II, 1.6]). Since p is good for G, the  $\tilde{G}$ -module  $\mathrm{Sym}^n$   $\mathrm{Lie}(\tilde{G})$  admits a good filtration for all  $n \ge 1$  by [1, Proof of Prop. 4.4].

Let V', V'' be two L-modules. By [1, 4.1(1)], the sum  $V \oplus V'$  admits a good filtration if and only if both summands V, V' admit good filtrations. Further, if V' and V'' both admit good filtrations, so does  $V' \otimes V''$ , [26, Th. 4.3.1] (see also [1, 4.1.4(3)])<sup>13</sup>. It follows as in [1, 4.1.4] that  $\operatorname{Sym}^n(V' \oplus V'')$  admits a good filtration for all  $n \geq 1$  if and only if  $\operatorname{Sym}^n(V')$  and  $\operatorname{Sym}^n(V'')$  both admit good filtrations for all  $n \geq 1$ .

Let  $U^+$  be the unipotent radical of  $P^+$ . One has  $\text{Lie}(G) = \text{Lie}(P) \oplus \text{Lie}(U^+)$  and  $\text{Lie}(P)^\vee = \text{Lie}(P^+)$  as L-modules. Also  $\text{Lie}(G) \simeq \text{Lie}(G)^\vee$  as G-modules. Thus  $(\text{Lie}(G)/\text{Lie}(P))^\vee = \text{Lie}(U)$  as L-modules. Since  $\text{Lie}(G) = \text{Lie}(P^+) \oplus \text{Lie}(U)$  as L-modules, we are reduced to showing that  $\text{Sym}^n \text{Lie}(G)$  admits a good filtration as L-module for all  $n \geq 1$ . By reductions of Donkin, [26, Props. 3.2.7, 3.4.3], since  $\text{Sym}^n \text{Lie}(\tilde{G})$  admits a good filtration as a  $\tilde{G}$ -module, it also admits a good filtration as G-module. Since Lie(G) is the direct sum of its center and  $\text{Lie}(\tilde{G})$ , the result used above about symmetric powers of a sum implies that  $\text{Sym}^n \text{Lie}(G)$  admits a good filtration as a G-module for all  $n \geq 1$ . By [26, Th. 4.3.1], the property of admitting a good filtration is stable under restriction to a Levi subgroup. Thus  $\text{Sym}^n \text{Lie}(G)$  admits a good filtration as L-module for all  $n \geq 1$ .

# <span id="page-43-0"></span>Lemma 11.2.4. One has $M^0 \leadsto_{\mathcal{H}} M_e$ .

*Proof.* Let  $f \in H^0(S_{\mathcal{K}}, \mathcal{V}(\eta))$  be an eigenform with system of eigenvalues  $(b_T)_{T \in \mathcal{H}}$ . Let  $\mathcal{I}$  be the ideal sheaf of  $S_e$  in  $S_{\mathcal{K}}$ . By §4.2, the short exact sequence

<span id="page-43-4"></span>
$$(11.2.1) 0 \to \mathcal{I} \otimes \mathcal{V}(\eta) \to \mathcal{V}(\eta) \to \mathcal{V}(\eta)|_{S_e} \to 0.$$

is  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant (§4.1.10). Similarly all the powers  $\mathcal{I}^j$  are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant and so are the short exact sequences

<span id="page-43-5"></span>
$$(11.2.2) 0 \to \mathcal{I}^{j-1} \to \mathcal{I}^j \to \mathcal{I}^j / \mathcal{I}^{j-1} \to 0.$$

Since (11.2.1) and (11.2.2) are  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant, the induced long exact sequences in cohomology are  $\mathcal{H}$ -equivariant (§8.1.4). Since  $S_{\mathcal{K}}$  is Noetherian and  $S_e$  is nonempty, there exists a largest  $j \in \mathbf{Z}_{\geq 0}$  such that  $f \in H^0(S_{\mathcal{K}}, \mathcal{I}^j \otimes \mathcal{V}(\eta))$ . Then the image  $\bar{f}$  of f in  $H^0(S_e, \mathcal{I}^j/\mathcal{I}^{j+1} \otimes \mathcal{V}(\eta))$  is non-zero. Since  $S_e$  and  $S_{\mathcal{K}}$  are smooth,  $\mathcal{I}^j/\mathcal{I}^{j+1} = \operatorname{Sym}^j(\mathcal{I}/\mathcal{I}^2)$ . Since in addition  $S_e$  is zero-dimensional, the "co-normal exact sequence" of differentials simplifies to a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant isomorphism  $\mathcal{I}/\mathcal{I}^2 \cong (\Omega^1_{S_{\mathcal{K}}})|_{S_e}$  of sheaves on  $S_e$ . Hence  $\bar{f} \in H^0(S_e, \operatorname{Sym}^j \Omega^1_{S_{\mathcal{K}}} \otimes \mathcal{V}(\eta))$ . So the eigensystem  $(b_T)_{T \in \mathcal{H}}$  of f also appears in  $H^0(S_e, \operatorname{Sym}^j \Omega^1_{S_{\mathcal{K}}} \otimes \mathcal{V}(\eta))$ .

The automorphic vector bundle  $\Omega^1_{S_K}$  is associated to the L-module  $(\text{Lie}(G)/\text{Lie}(P))^\vee = \text{Lie}(U)$  via the construction of §§4.1.9, 6.1.5. Indeed, it is sufficient to check this for the cotangent bundle over  $\mathscr{S}_{K,\mathbf{C}}$ , where it follows trivially from the complex uniformization of  $\mathscr{S}_K(\mathbf{C})$  and the Borel embedding  $\mathbf{X} \hookrightarrow (\mathbf{G}/\mathbf{P})(\mathbf{C})$ . Since the associated bundle construction is an exact tensor functor,  $\text{Sym}^j(\Omega^1_{S_K}) \otimes \mathscr{V}(\eta)$  is associated to the L-module  $\text{Sym}^j((\text{Lie}(G)/\text{Lie}(P))^\vee) \otimes V_\eta$ . By Lemma 11.2.3, this L-module admits a good filtration. Hence the system of Hecke eigenvalues of f appears in  $H^0(S_e, \mathscr{V}(\eta'))$  for some  $\eta' \in X^*_{+,\mathbf{L}}(\mathbf{T})$  and some graded piece  $V_{\eta'}$  of a good filtration for  $\text{Sym}^j((\text{Lie}(G)/\text{Lie}(P))^\vee) \otimes V_\eta$ .

By Th. 3.2.3 (with w = e), there exists a nowhere vanishing, Hecke-equivariant section  $h_e \in H^0(S_e, \omega^{N_e})$  for some  $N_e \ge 1$ . The following is then immediate:

<span id="page-43-1"></span>Lemma 11.2.5. Multiplication by h<sub>e</sub> induces a Hecke-equivariant isomorphism

$$H^0(S_e, \mathscr{V}(\eta)) \stackrel{\sim}{\to} H^0(S_e, \mathscr{V}(\eta) \otimes \omega^{N_e}).$$

The last step, of going up from  $S_e$  to  $S_K$ , is given by:

<span id="page-43-2"></span>**Lemma 11.2.6.** For every  $\eta \in X_{+,\mathbf{L}}^*(\mathbf{T})$  and every system of Hecke eigenvalues  $(b_T)_{T\in\mathcal{H}}$  appearing in  $H^0(S_e, \mathcal{V}(\eta))$ , there exists  $m \geq 1$  such that  $(b_T)_{T\in\mathcal{H}}$  also appears in  $H^0(S_{\mathcal{K}}, \mathcal{V}(\eta) \otimes \omega^m)$ .

<span id="page-43-3"></span><sup>&</sup>lt;sup>13</sup>The theorem of Donkin cited above assumed that p > 2 when G has factors of type  $E_7$  or  $E_8$ . Mathieu later showed [78] that the existence of good filtrations is closed under tensor product without any restriction on p or G (still assumed connected, reductive).

*Proof.* Let  $f \in H^0(S_e, \mathcal{V}(\eta))$  be an eigenform with eigenvalues  $(b_T)$ . By Lemma 11.2.5,  $fh_e^a \in H^0(S_e, \mathcal{V}(\eta) \otimes \omega^{aN_e})$  is an eigenform with the same eigenvalues  $(b_T)$  for all  $a \geq 1$ .

Let  $\Sigma$  be a smooth, projective, finite, admissible rpcd. Let D' be a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant Cartier divisor supported on D such that  $\omega^k(-D')$  is ample on  $\mathscr{S}^\Sigma_{\mathcal{K}}$  for all  $k\gg 0$ , as afforded by hypothesis  $(\star)$  of Th. 11.1.1 and Rmk. 11.1.2. Since  $S_e\cap D=\emptyset$ , one has  $\omega^k(-D')|_{S_e}=\omega^k|_{S_e}$ . Let  $\mathcal{I}^\Sigma$  be the ideal sheaf of  $S_e$  in  $S^\Sigma_{\mathcal{K}}$ . Then we have the analogue of (11.2.1) for  $S^\Sigma_{\mathcal{K}}$ :

<span id="page-44-1"></span>(11.2.3) 
$$0 \to \mathcal{I}^{\Sigma} \otimes \mathscr{V}^{\operatorname{can}}(\eta) \to \mathscr{V}^{\operatorname{can}}(\eta) \to \mathscr{V}(\eta)|_{S_{e}} \to 0.$$

By Serre vanishing, if r is sufficently large, then

<span id="page-44-2"></span>(11.2.4) 
$$H^{1}(S_{\kappa}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta) \otimes \mathcal{I}^{\Sigma} \otimes \omega^{kr}(-rD')) = 0.$$

Twisting (11.2.3) by  $\omega^{kr}(-rD')$  and passing to cohomology, the vanishing (11.2.4) gives a surjection

<span id="page-44-3"></span>(11.2.5) 
$$H^{0}(S_{\kappa}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}(-rD')) \longrightarrow H^{0}(S_{e}, \mathcal{V}(\eta) \otimes \omega^{kr}).$$

Let  $j: rD' \to S_{\mathcal{K}}^{\Sigma}$  be the inclusion. The restriction map (11.2.5) is the composition of

<span id="page-44-4"></span>(11.2.6) 
$$H^{0}(S_{\mathcal{K}}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}(-rD')) \to H^{0}(S_{\mathcal{K}}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr})$$

and

<span id="page-44-5"></span>(11.2.7) 
$$H^{0}(S_{\kappa}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}) \to H^{0}(S_{\kappa}, \mathcal{V}(\eta) \otimes \omega^{kr}),$$

where the first map is induced from  $0 \to \mathcal{O}_{S_{\kappa}^{\Sigma}}(-rD') \to \mathcal{O}_{S_{\kappa}^{\Sigma}} \to \mathcal{O}_{rD'} \to 0$  and the second is restriction. Since both (11.2.6) and (11.2.7) are Hecke-equivariant by the methods of §§8.1.5-8.1.6, so is there composition (11.2.5).

Therefore  $(b_T)$  appears in  $H^0(S_K^{\Sigma}, \mathscr{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}(-rD'))$ . Since the latter is Hecke-equivariantly embedded in  $H^0(S_K^{\Sigma}, \mathscr{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}(-D))$  and  $\mathscr{V}^{\operatorname{can}}(\eta) \otimes \omega^{kr}(-D) = \mathscr{V}^{\operatorname{sub}}(\eta) \otimes \omega^{kr}$ , we conclude that  $(b_T)$  also appears in  $H^0(S_K^{\Sigma}, \mathscr{V}^{\operatorname{sub}}(\eta) \otimes \omega^{kr})$ .

Proof of Th. 11.1.1. Apply Lemmas 11.2.2, 11.2.4, 11.2.5 and 11.2.6 consecutively.

Remark 11.2.7. Suppose that the theory of integral models and their compactifications applies to  $(\mathbf{G}, \mathbf{X})$  also for p=2. e.g., this is the case if  $(\mathbf{G}, \mathbf{X})$  is of PEL-type with no factors of type D. Then it is clear that the proof of Lemma 11.2.6 works for p=2. However, even in the Siegel case, we don't know whether Lemma 11.2.4 remains valid for p=2. According to [53, p. 241], it seems likely that Lemma 11.2.3 is false when p=2.

Proof of Cor. 11.1.3. Let  $d = \dim S_{\mathcal{K}}^{\Sigma}$ . The canonical bundle of  $S_{\mathcal{K}}^{\Sigma}$  is isomorphic to  $\omega^m(-D)$  for some  $m \geq 1$ , [77, 5.3.11]. By Serre duality,  $H^i(S_{\mathcal{K}}^{\Sigma}, \mathcal{V}^{\operatorname{can}}(\eta)) \cong H^{d-i}(S_{\mathcal{K}}^{\Sigma}, \mathcal{V}^{\operatorname{sub}}(m\eta_{\omega} - \eta))$ . By Th. 8.2.1,  $F(i, 1, \eta) \neq \emptyset$  for all  $\eta$ . Hence Rmk. 8.2.5 and Th. 11.1.1 imply that every system system of Hecke eigenvalues that appears in (11.1.1) also appears in  $M_e$  (recall that  $\mathcal{V}(\eta)$ ,  $\mathcal{V}^{\operatorname{can}}(\eta)$  and  $\mathcal{V}^{\operatorname{sub}}(\eta)$  all have the same restriction to  $S_e$ ). The finiteness then follows by the same argument as that given in [95, 30, 90].

Remark 11.2.8. The finiteness of Hecke eigen-systems appearing in (11.1.1) can also be deduced as follows: Recall that the (non-compactified) flag space  $Fl_{\mathcal{K}}$  introduced in (9.1.1) admits a smooth map  $Fl_{\mathcal{K}} \to G$ -ZipFlag<sup> $\mu$ </sup>. By pull-back, the stratification defined in §2.3 induces a stratification of  $Fl_{\mathcal{K}}$ . There is a unique zero-dimensional stratum  $Fl_e$ , and the projection  $\pi: Fl_{\mathcal{K}} \to S_{\mathcal{K}}$  induces a  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant map  $Fl_e \to S_e$ . Hence, we obtain a Hecke-equivariant injection  $H^0(S_e, \mathcal{V}(\eta)) \to H^0(Fl_e, \pi^*\mathcal{V}(\eta))$ . Furthermore, each  $\pi^*\mathcal{V}(\eta)$  admits a filtration with graded pieces of the form  $\mathcal{L}(\lambda)$ . For each character  $\chi \in X^*(T)$ , there exists an integer  $N \geq 1$  such that  $\mathcal{L}(\chi)^N$  admits a non-vanishing  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant section (obtained by pull-back from the corresponding stratum in G-ZipFlag<sup> $\mu$ </sup>). In particular, the lattice of weights of  $\mathbf{G}(\mathbf{A}_f^p)$ -equivariant non-vanishing sections on  $Fl_e$  has finite covolume in  $X^*(T)$ . The finiteness of Hecke-eigensystems follows immediately.

### <span id="page-44-0"></span>ACKNOWLEDGEMENTS

We thank our respective collaborators Marc-Hubert Nicole and Torsten Wedhorn: The joint projects [39] and [62] were invaluable in leading us to the results of the current paper. We are grateful to David Geraghty for the many important ideas that he contributed during the initial part of this project. In addition, we thank Joseph Ayoub, Laurent Clozel, Pierre Deligne, Phillip Griffiths, David Helm, Matt Kerr, Arno Kret, Ben Moonen, Marc-Hubert Nicole, Stefan Patrikis, Jonathan Pottharst, Sug Woo Shin, Benoit Stroh, Jacques Tilouine, Adrian Vasiu and Torsten Wedhorn for helpful conversations and correspondence. Finally, we thank the referee for his/her very thorough work, detailed comments and valuable suggestions, which we believe have led to considerable improvements in the paper.

# <span id="page-45-0"></span>References

- <span id="page-45-39"></span><span id="page-45-30"></span>[1] H. Andersen and J. C. Jantzen. Cohomology of induced representations for algebraic groups. Math. Ann., 269(4):487–525, 1984.
- <span id="page-45-37"></span>[2] F. Andreatta and L. Barbieri-Viale. Crystalline realizations of 1-motives. Math. Ann., 331(1):111–172, 2005.
- <span id="page-45-26"></span>[3] J. Arthur. Automorphic representations of GSp(4). In Contributions to automorphic forms, geometry, and number theory, pages 65–81, Baltimore, MD, 2004. Johns Hopkins Univ. Press.
- <span id="page-45-22"></span>[4] M. Artin, J. E. Bertin, M. Demazure, P. Gabriel, A. Grothendieck, M. Raynaud, and J.-P. Serre. SGA3: Schémas en groupes, volume 1963/64. Institut des Hautes Études Scientifiques, Paris, 1965/1966.
- <span id="page-45-31"></span>[5] A. Ash. Galois representations attached to mod p cohomology of GL(n, Z). Duke Math. J., 65(2):235–255, 1992.
- <span id="page-45-36"></span>[6] W. Baily and A. Borel. Compactification of arithmetic quotients of bounded symmetric domains. Ann. Math, 84:442–528, 1966.
- <span id="page-45-41"></span>[7] A. Borel. Automorphic L-functions. In Borel and Casselman [\[8\]](#page-45-41), pages 247–289.
- <span id="page-45-35"></span>[8] A. Borel and W. Casselman, editors. Automorphic forms, representations and L-functions (Proc. Sympos. Pure Math., Oregon State Univ., Corvallis, OR., 1977), Part 2, volume 33 of Proc. Symp. Pure Math. Amer. Math. Soc., Providence, RI, 1979.
- [9] A. Borel and N. Wallach. Continuous Cohomology, Discrete Subgroups, and Representations of Reductive Groups, volume 94 of Annals of Math. Studies. Princeton Univ. Press, 1980.
- <span id="page-45-15"></span><span id="page-45-14"></span>[10] G. Boxer. Torsion in the coherent cohomology of Shimura varieties and Galois representations. Preprint, arXiv:1507.05922.
- <span id="page-45-27"></span>[11] G. Boxer. Torsion in the coherent cohomology of Shimura varieties and Galois representations. PhD thesis, Harvard University, Cambridge, Massachusetts, 2015.
- <span id="page-45-8"></span>[12] M. Brion and V. Lakshmibai. A geometric approach to standard monomial theory. Representation Theory, 7:651–680, 2003.
- <span id="page-45-16"></span>[13] Y. Brunebarbe, W. Goldring, J.-S. Koskivirta, and B. Stroh. Ample automorphic bundles on zip-schemes. In preparation.
- [14] K. Buzzard and T. Gee. The conjectural connections between automorphic representations and Galois representations. In Scholl and Taylor [\[93\]](#page-47-28), pages 135–187. Papers from the London Mathematical Society Symposium held in Durham, July 9–18, 1996.
- <span id="page-45-23"></span><span id="page-45-1"></span>[15] F. Calegari and D. Geraghty. Modularity lifting beyond the Taylor-Wiles method. Invent. Math., to appear.
- <span id="page-45-2"></span>[16] H. Carayol. Limites dégénérées de séries discrètes, formes automorphes et variétés de Griffiths-Schmid. Comp. Math., 111:51–88, 1998.
- [17] H. Carayol. Quelques relations entre les cohomologies des variétés de Shimura et celles de Griffiths-Schmid (cas du groupe SU(2, 1)). Comp. Math., 121:305–335, 2000.
- <span id="page-45-3"></span>[18] H. Carayol. Cohomologie automorphe et compactifications partielles de certaines variétés de Griffiths-Schmid. Comp. Math., 141:1081–1102, 2005.
- <span id="page-45-5"></span>[19] H. Carayol. Cohomologie automorphe et sous-variétés des variétés de Griffiths-Schmid. In B. Bost, P. Boyer, A. Genestier, L. Lafforgue, S. Lysenko, S. Morel, and B. C. Ngô, editors, De La Géométrie algébrique aux formes automorphes (I) - (Une collection d'articles en l'honneur du soixantième anniversaire de Gérard Laumon)., volume 369 of Astérisque, pages 203–222, Orsay, France, June 25-29 2012 2015. Soc. Math. France.
- <span id="page-45-28"></span><span id="page-45-4"></span>[20] H. Carayol and A. Knapp. Limits of discrete series with infinitesimal character zero. Trans. Amer. Math. Soc., 359(11):5611–5651, 2007.
- <span id="page-45-38"></span>[21] C. Chai and G. Faltings. Degeneration of abelian varieties, volume 22 of Ergebenisse der Math. Springer-Verlag, 1990.
- <span id="page-45-17"></span>[22] G. Chenevier and M. Harris. Construction of automorphic Galois representations, II. Cambridge J. of Math., 1:57–73, 2013.
- <span id="page-45-25"></span>[23] P. Deligne. Formes modulaires et représentations ℓ-adiques. Seminaire Bourbaki, 1968-1969. Exposé No. 355, 34p.
- [24] P. Deligne. Variétés de Shimura: Interprétation modulaire, et techniques de construction de modèles canoniques. In Borel and Casselman [\[8\]](#page-45-41).
- <span id="page-45-40"></span><span id="page-45-18"></span>[25] P. Deligne and J.-P. Serre. Formes modulaires de poids 1. Ann. Sci. ENS, 7(4):507–530, 1974.
- [26] S. Donkin. Rational representations of algebraic groups: Tensor products and filtration, volume 1140 of Lect. Notes in Math. Springer-Verlag, Berlin, 1985.
- <span id="page-45-32"></span>[27] D. Eisenbud. Commutative algebra, With a view toward algebraic geometry, volume 150 of Graduate Texts in Math. Springer-Verlag, New York, 1995.
- <span id="page-45-29"></span>[28] T. Ekedahl and G. van der Geer. Cycle classes of the E-O stratification on the moduli of abelian varieties. In Y. Tschinkel and Y. Zarhin, editors, Algebra, arithmetic and geometry, volume 269 of Progress in Math., pages 567–636, June 2009, Penn. State U., PA, 2009. Birkhäuser, Boston, MA.
- <span id="page-45-11"></span>[29] M. Emerton, D. Reduzzi, and L. Xiao. Galois representations and torsion in the coherent cohomology of Hilbert modular varieties. J. Reine Angew. Math., 726:93–127, 2017.
- <span id="page-45-34"></span><span id="page-45-24"></span>[30] A. Ghitza. Hecke eigenvalues of Siegel modular forms (mod p) and of algebraic modular forms. J. Number Theory, 106(2):345–384, 2004.
- <span id="page-45-19"></span>[31] W. Goldring. Classes of representations under functoriality. Talk given at Paris 13 on February 6, 2015.
- [32] W. Goldring. Galois representations associated to holomorphic limits of discrete series. Compositio Math., 150:191–228, 2014. with an appendix by S.-W. Shin.
- <span id="page-45-20"></span>[33] W. Goldring. An introduction to the Langlands program. In M. Kerr and G. Pearlstein, editors, Recent Advances in Hodge theory: Period Domains, Algebraic Cycles, and Arithmetic, pages 333–367, Vancouver, Canada, June 2013 2016. Cambridge Univ. Press.
- <span id="page-45-21"></span>[34] W. Goldring. Stability of degenerate limits of discrete series under functoriality, March 2011. Preprint, available at <https://sites.google.com/site/wushijig/>.
- <span id="page-45-33"></span>[35] W. Goldring. Galois Representations associated to holomorphic limits of discrete series. PhD thesis, Harvard Univesity, May 2011.
- <span id="page-45-7"></span><span id="page-45-6"></span>[36] W. Goldring and J.-S. Koskivirta. Zip stratifications of flag spaces and functoriality. IMRN, to appear; arXiv:1608.01504.
- [37] W. Goldring and J.-S. Koskivirta. Automorphic vector bundles with global sections on G-Zip<sup>Z</sup> -schemes. Compositio Math., 154:2586–2605, 2018.
- <span id="page-45-13"></span>[38] W. Goldring and J.-S. Koskivirta. Quasi-constant characters: Motivation, classification and applications. Adv. in Math., 339:336– 366, 2018.
- <span id="page-45-12"></span><span id="page-45-10"></span>[39] W. Goldring and M.-H. Nicole. The µ-ordinary Hasse invariant of unitary Shimura varieties. J. Reine Angew. Math., 728:137–151, 2017.
- <span id="page-45-9"></span>[40] E. Goren. Hasse invariants for Hilbert modular varieties. Israel J. Math., 122:157–174, 2001.
- [41] M. Green, P. Griffiths, and M. Kerr. Mumford-Tate groups and domains: Their Geometry and Arithmetic, volume 183 of Ann. of Math. Studies. Princeton U. Press, Princeton, NJ, 2012.

- <span id="page-46-0"></span>[42] M. Green, P. Griffiths, and M. Kerr. Hodge Theory, Complex Geometry and Representation Theory, volume 118 of CBMS Regional Conference Series. AMS, 2013.
- <span id="page-46-32"></span><span id="page-46-2"></span>[43] P. Griffiths, C. Robles, and D. Toledo. Quotients of non-classical flag domains are not algebraic. Alg. Geom., 1:1–13, 2014.
- <span id="page-46-36"></span>[44] P. Griffiths and W. Schmid. Locally homogeneous complex manifolds. Acta. Math., 123:253–302, 1969.
- <span id="page-46-28"></span>[45] Benedict H. Gross. On the Satake isomorphism. In Scholl and Taylor [\[93\]](#page-47-28), pages 223–237. Papers from the London Mathematical Society Symposium held in Durham, July 9–18, 1996.
- <span id="page-46-34"></span>[46] A. Grothendieck. EGA III.2: Étude cohomologique des faisceaux cohérents, volume 17 of Publ. Math. IHÉS. Springer-Verlag, 1963.
- <span id="page-46-35"></span>[47] A. Guichardet. Cohomologie des groupes topologiques et des algèbres de Lie. Cedic/F. Nathan, 1980.
- [48] M. Harris. Automorphic forms and the cohomology of vector bundles on Shimura varieties. In L. Clozel and J. Milne, editors, Automorphic forms, Shimura varieties, and L-functions, Vol. II (Proc. Conf. Ann Arbor, MI, 1988), volume 11 of Perspect. Math., pages 41–91. Academic Press, Boston, MA.
- <span id="page-46-40"></span><span id="page-46-39"></span>[49] M. Harris and R. Taylor. The geometry and cohomology of some simple Shimura varieties, volume 151 of Annals of Math. Studies. Princeton Univ. Press, Princeton, NJ, 2001. With an appendix by Vladimir G. Berkovich.
- [50] Michael Harris, Kai-Wen Lan, Richard Taylor, and Jack Thorne. On the rigid cohomology of certain Shimura varieties. Res. Math. Sci., 3:Paper No. 37, 308, 2016.
- <span id="page-46-11"></span><span id="page-46-4"></span>[51] R. Hartshorne. Algebraic Geometry, volume 52 of Graduate Texts in Math. Springer-Verlag, 1977.
- <span id="page-46-12"></span>[52] T. Ito. Hasse invariants for some unitary Shimura varieties. In C. Denniger, P. Schneider, and A. Scholl, editors, Oberwolfach Report 28/2005, pages 1565–1568. Euro. Math. Soc. Publ. House, 2005.
- [53] J. Jantzen. Representations of algebraic groups, volume 107 of Math. Surveys and Monographs. American Mathematical Society, Providence, RI, 2nd edition, 2003.
- <span id="page-46-21"></span><span id="page-46-8"></span>[54] F. Jarvis. On Galois representations associated to Hilbert modular forms. J. Reine. Angew. Math., 491:199–216, 1997.
- <span id="page-46-31"></span>[55] N. Katz. Nilpotent connections and the monodromy theorem: applications of a result of Turrittin. Publ. Math. IHÉS, 39:175–232, 1970.
- <span id="page-46-25"></span>[56] G. Kempf, Finn Faye Knudsen, D. Mumford, and B. Saint-Donat. Toroidal embeddings. I. Lect. Notes in Math., Vol. 339. Springer-Verlag, Berlin-New York, 1973.
- <span id="page-46-15"></span>[57] M. Kisin. Honda-Tate theory for Shimura varieties. Oberwolfach Report No. 39/2015, "Reductions of Shimura varieties".
- <span id="page-46-33"></span>[58] M. Kisin. Integral models for Shimura varieties of abelian type. J. Amer. Math. Soc., 23(4):967–1012, 2010.
- [59] A. Knapp and G. Zuckerman. Classification of irreducible tempered representations of semisimple groups. Ann. Math., 116(2):389– 455, 1982.
- <span id="page-46-14"></span><span id="page-46-6"></span>[60] J.-S. Koskivirta. Normalization of closed Ekedahl-Oort strata. Canad. Math. Bull., 61(3):572–587, 2018.
- [61] Jean-Stefan Koskivirta. Canonical sections of the Hodge bundle over Ekedahl-Oort strata of Shimura varieties of Hodge type. J. Algebra, 449:446–459, 2016.
- <span id="page-46-7"></span><span id="page-46-5"></span>[62] Jean-Stefan Koskivirta and Torsten Wedhorn. Generalized µ-ordinary Hasse invariants. J. Algebra, 502:98–119, 2018.
- <span id="page-46-41"></span>[63] A. Kret and S. W. Shin. Galois representations for general symplectic groups. Preprint, arXiv:1609.04223.
- [64] J.-P. Labesse. Changement de base CM et séries discrètes. In L. Clozel, M. Harris, J.-P. Labesse Labesse, and B.-C. Ngô, editors, On the stabilization of the trace formula, volume 1. Int. Press of Boston, 2011.
- <span id="page-46-18"></span><span id="page-46-9"></span>[65] K.-W. Lan. Toroidal compactifications of P EL-type Kuga families. Algebra and Number Theory, 6(5):885–966, 2012.
- [66] K.-W. Lan. Arithmetic compactifications of PEL-type Shimura varieties, volume 36 of London Mathematical Society Monographs. Princeton University Press, 2013.
- <span id="page-46-29"></span>[67] K.-W. Lan and B. Stroh. Relative cohomology of cuspidal forms on PEL-type Shimura varieties. Algebra and Number Theory., 8:1787–1799, 2014.
- <span id="page-46-24"></span>[68] K.-W. Lan and B. Stroh. Compactifications of subschemes of integral models of Shimura varieties. Forum Math. Sigma, 6:e18, 105pp, 2018.
- <span id="page-46-30"></span><span id="page-46-22"></span>[69] K.-W. Lan and J. Suh. Liftability of mod p cusp forms of parallel weights. IMRN, 2011(8):1870–1879, 2011.
- [70] K.-W. Lan and J. Suh. Vanishing theorems for torsion automorphic sheaves on general P EL-type Shimura varieties. Adv. Math., 242:228–286, 2013.
- <span id="page-46-20"></span><span id="page-46-19"></span>[71] Kai-Wen Lan. Higher Koecher's principle. Math. Res. Lett., 23(1):163–199, 2016.
- [72] Kai-Wen Lan. Compactifications of PEL-type Shimura varieties and Kuga families with ordinary loci. World Scientific Publishing Co. Pte. Ltd., Hackensack, NJ, 2018.
- <span id="page-46-38"></span><span id="page-46-37"></span>[73] G. Laumon. Sur la cohomologie à supports compacts des variétés de Shimura pour GSp(4)Q. Compositio Math., 105:267–359, 1997.
- [74] G. Laumon. Fonctions zêtas des variétés de Siegel de dimension trois. In Formes automorphes. II. Le cas du groupe GSp(4), volume 302 of Astérisque, pages 1–66. Soc. Math. France, 2005.
- <span id="page-46-13"></span>[75] G. Laumon and L. Moret-Bailly. Champs algébriques. Ergebnisse der Mathematik und ihrer Grenzgebiete. 3. Folge / A Series of Modern Surveys in Mathematics. Springer Berlin Heidelberg, 1999.
- <span id="page-46-26"></span><span id="page-46-10"></span>[76] D. U. Lee. Nonemptiness of Newton strata of Shimura varieties of Hodge type. Algebra Number Theory, 12(2):259–283, 2018.
- <span id="page-46-42"></span>[77] K. Madapusi. Toroidal compactifications of integral models of Shimura varieties of Hodge type. Preprint, arXiv:1211.1731.
- <span id="page-46-17"></span>[78] O. Mathieu. Filtrations of G-modules. Ann. Sci. École Norm. Sup. (4), 23(4):625–644, 1990.
- [79] H. Matsumura. Commutative ring theory, volume 8 of Cambridge Studies in Advanced Mathematics. Cambridge University Press, Cambridge, second edition, 1989. Translated from the Japanese by M. Reid.
- <span id="page-46-16"></span>[80] J. Milne. The points on a Shimura variety modulo a prime of good reduction. In R. Langlands and D. Ramakrishnan, editors, The zeta functions of Picard modular surfaces, pages 151–253, Montreal, Canada, 1992.
- <span id="page-46-3"></span>[81] B. Moonen. Group schemes with additional structures and Weyl group cosets. In Moduli of abelian varieties (Texel Island, 1999), volume 195 of Progr. Math., pages 255–298. Birkhäuser, Basel, 2001.
- <span id="page-46-27"></span><span id="page-46-1"></span>[82] B. Moonen and T. Wedhorn. Discrete invariants of varieties in positive characteristic. IMRN, 72:3855–3903, 2004.
- [83] D. Mumford. Abelian varieties, volume 5 of Tata Inst. of Fund. Res. Studies in Math. Hindustan Book Agency, New Delhi, India, 2008. With appendices by C. P. Ramanujam and Y. Manin. Corrected reprint of the second (1974) edition.
- <span id="page-46-23"></span>[84] A. Ogus. F-crystals, Griffiths transversality, and the Hodge decomposition, volume 221 of Astérisque. Soc. Math. France, 1994.

- <span id="page-47-0"></span>[85] F. Oort. A stratification of a moduli space of abelian varieties. In Moduli of abelian varieties (Texel Island, 1999), volume 195 of Progr. Math., pages 345–416. Birkhäuser, Basel, 2001.
- <span id="page-47-9"></span><span id="page-47-2"></span>[86] V. Pilloni and B. Stroh. Cohomologie cohérente et représentations Galoisiennes. Ann. Math. Québec, 40(1):167–202, 2016.
- <span id="page-47-3"></span>[87] R. Pink, T. Wedhorn, and P. Ziegler. Algebraic zip data. Doc. Math., 16:253–300, 2011.
- <span id="page-47-14"></span>[88] R. Pink, T. Wedhorn, and P. Ziegler. F-zips with additional structure. Pacific J. Math., 274(1):183–236, 2015.
- <span id="page-47-12"></span>[89] S. Ramanan and A. Ramanathan. Projective normality of flag varieties and Schubert varieties. Invent. Math., 79:217–224, 1985.
- <span id="page-47-27"></span>[90] D. Reduzzi. Hecke eigensystems for (mod p) modular forms of PEL type and algebraic modular forms. Int. Math. Res. Notices, 2013(9):2133–2178, 2013.
- <span id="page-47-22"></span>[91] S. Salamanca-Riba. On the unitary dual of real reductive Lie groups and the Aq(λ) modules: The strongly regular case. Duke Math. J., 96(3):521–546, 1998.
- <span id="page-47-28"></span>[92] W. Schmid. L -cohomology and the discrete series. Ann. of Math., 103(3):375–394, 1976.
- [93] A. Scholl and R. Taylor, editors. Galois representations in arithmetic algebraic geometry, volume 254 of London Mathematical Society Lecture Note Series. Cambridge University Press, Cambridge, 1998. Papers from the London Mathematical Society Symposium held in Durham, July 9–18, 1996.
- <span id="page-47-10"></span><span id="page-47-8"></span>[94] P. Scholze. On torsion in the cohomology of locally symmetric varieties. Ann. of Math., 182:945–1066, 2015.
- <span id="page-47-24"></span>[95] J.-P. Serre. Two letters on quaternions and modular forms (mod p). Israel J. Math., 95:281–299, 1996.
- <span id="page-47-26"></span>[96] S. W. Shin. Galois representations arising from some compact Shimura varieties. Ann. of Math., 173:1645–1741, 2011.
- <span id="page-47-20"></span>[97] S. W. Shin. On the cohomological base change for unitary similitude groups. 2011. Appendix to [\[32\]](#page-45-19).
- <span id="page-47-13"></span>[98] W. Soergel. On the n-cohomology of limits of discrete series representations. Representation Theory, 1:69–82, 1997. With an erratum "Corrections to: "On the n-cohomology of limits of discrete series rerpresentations", Vol. 19 (2015) pp. 1-2.
- <span id="page-47-18"></span>[99] The Stacks Project Authors. Stacks project. <http://stacks.math.columbia.edu>, 2015.
- <span id="page-47-7"></span>[100] B. Stroh. Cohomologie relatives des formes cuspidales. Available at <http://www.math.univ-paris13.fr/~stroh/>.
- <span id="page-47-19"></span>[101] R. Taylor. Galois representations associated to Siegel modular forms of low weight. Duke Math. J., 63(2):281–332, 1991.
- <span id="page-47-15"></span>[102] J. Tilouine. Formes compagnons et complexe BGG dual pour GSp4. Ann. Inst. Fourier (Grenoble), 62(4):1383–1436, 2012.
- <span id="page-47-17"></span>[103] A. Vasiu. Integral canonical models of Shimura varieties of preabelian type. Asian J. Math., 3:401–518, 1999.
- <span id="page-47-4"></span>[104] A. Vasiu. Manin problems for Shimura varieties of Hodge type. J. Ramanujan Math. Soc., 26(1):31–84, 2011.
- <span id="page-47-21"></span>[105] E. Viehmann and T. Wedhorn. Ekedahl-Oort and Newton strata for Shimura varieties of PEL type. Math. Ann., 356(4):1493–1550, 2013.
- <span id="page-47-1"></span>[106] D. Vogan and G. Zuckerman. Unitary representations with nonzero cohomology. Comp. Math., 53(1):51–90, 1984.
- <span id="page-47-25"></span>[107] T. Wedhorn. Ordinariness in good reductions of Shimura varieties of PEL-type. Ann. Sci. ENS, 32(5):575–618, 1999.
- [108] R. Weissauer. Four dimensional Galois representations. In Formes automorphes. II. Le cas du groupe GSp(4), volume 302 of Astérisque, pages 67–150. Soc. Math. France, 2005.
- <span id="page-47-23"></span><span id="page-47-6"></span>[109] F. Williams. The n-cohomology of limits of discrete series. J. Func. Anal., 80:451–461, 1988.
- <span id="page-47-11"></span>[110] D. Wortmann. The µ-ordinary locus for Shimura varieties of Hodge type. Preprint 2013, arXiv:1310.6444.
- <span id="page-47-16"></span>[111] L. Xiao and X. Zhu. Cycles on Shimura varieties via geometric Satake. Preprint, arXiv:1707.05700.
- <span id="page-47-5"></span>[112] C.-F. Yu. Non-emptiness of the basic locus of Shimura varieties. Oberwolfach Report No. 39/2015, "Reductions of Shimura varieties".
- [113] C. Zhang. Ekedahl-Oort strata for good reductions of Shimura varieties of Hodge type. Canad. J. Math., 70(2):451–480, 2018.

(Wushi Goldring) Department of Mathematics, Stockholm University, Stockholm SE-10691, Sweden wushijig@gmail.com

(Jean-Stefan Koskivirta) Department of Mathematics, South Kensington Campus, Imperial College London, London SW7 2AZ, UK

j.koskivirta@imperial.ac.uk