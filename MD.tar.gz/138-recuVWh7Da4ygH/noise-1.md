# On Hirzebruch's proportionality principle and the non-existence of amenable Clifford-Klein forms of certain homogeneous spaces

Maciej Bocheński and Aleksy Tralle Department of Mathematics and Computer Science, University of Warmia and Mazury, Słoneczna 54, 10-710, Olsztyn, Poland E-mail: mabo@matman.uwm.edu.pl (MB), tralle@matman.uwm.edu.pl (AT)

November 10, 2018

#### Abstract

This article continues a line of research aimed at solving an important problem of T. Kobayashi of the existence of compact Clifford-Klein forms of reductive homogeneous spaces. We contribute to this topic by showing that almost all symmetric spaces and 3-symmetric spaces do not admit amenable compact Clifford-Klein forms (with several exceptions). Our basic tool is a combination of the Hirzebruch proportionality principle with the theory of syndetic hulls. Using this, we prove a general theorem which yields a sufficient condition on the non-existence of compact Clifford-Klein forms in terms of the Pontryagin classes of some vector bundles naturally related to the given homogeneous space G/H.

MSC: 57S30, 22F30, 22E40, 22E46.

# 1 Introduction

Assume that we are given a non-compact homogeneous space G/H of a reductive real Lie group G and a closed subgroup H ⊂ G. If there exists a discrete subgroup Γ ⊂ G which acts properly and co-compactly on G/H by left translations, we say that G/H admits a compact Clifford-Klein form. The problem of determining which reductive homogeneous spaces admit such forms goes back to Calabi and Markus and was formulated as a research program by T. Kobayashi. The main inspiration for the research presented in this paper are the works [\[12\]](#page-17-0), [\[13\]](#page-17-1) and [\[14\]](#page-17-2). In [\[14\]](#page-17-2) the problem was explicitly formulated as follows: does a symmetric space admit compact Clifford-Klein forms? In general, the problem is still not solved, neither for symmetric spaces, nor for other wide classes of homogeneous spaces . In [\[14\]](#page-17-2) various ways to attack it are discussed (for example, Theorems 2.2.1, 2.3.1, 2.4.1, Corollary 3.5.9, Corollaries 3.6.4 and 3.6.5). Also, this article contains several important conjectures on the (non)existence of compact Clifford-Klein forms of symmetric spaces, as well as a description of general methods of the theory of Clifford-Klein forms: criteria of properness of the group actions and obstructions. In this article we focus on a question: what algebraic conditions should be satisfied by a discrete subgroup Γ ⊂ G, if it yields a compact Clifford-Klein form? The latter question is partially motivated by a theorem of Y. Benoist [\[2\]](#page-17-3). In the latter article, it was shown that no nilpotent group can act properly and co-compactly on a non-compact semisimple homogeneous space. Note that not much is known about the possible algebraic properties of discrete groups that may yield compact Clifford-Klein forms: the main examples are lattices in closed subgroups L ⊂ G of a given Lie group G and their deformations [\[9\]](#page-17-4),[\[11\]](#page-17-5). Also, [\[5\]](#page-17-6) contains an approach via the word hyperbolic groups acting by the Anosov representations. In our line of thinking the results of the present article continue [\[3\]](#page-17-7), were we have proved the same type of generalization of Benoist' theorem for homogeneous spaces G/H, where H is a semisimple part of a centralizer of a torus in G. It is worth noting that our approach to the problem differs from that of [\[3\]](#page-17-7) and might be of independent interest. We use a result of T. Kobayashi and K. Ono [\[12\]](#page-17-0) (which the authors call the Hirzebruch proportionality principle), together with an approach to the Clifford-Klein forms via syndetic hulls [\[23\]](#page-18-0). Thus, we combine topological methods with methods of the theory of algebraic groups, in order to understand the algebraic properties of Γ. This combination of methods yields new series of examples of homogeneous spaces G/H with no compact amenable Clifford-Klein forms: these are pseudo-Riemannian symmetric spaces (with three exceptions) and pseudo-Riemannian 3-symmetric spaces (in the sense of Wolf and Gray [\[26\]](#page-18-1), [\[27\]](#page-18-2)), with one exception. Note that we say that a homogeneous space G/H admits an amenable compact Clifford-Klein form, if there exists a discrete amenable subgroup  $\Gamma \subset G$  acting properly discontinuously and co-compactly on G/H by left translations. Our approach is based on a general theorem which is an application of the Hirzebruch proportionality principle, and may be of independent interest. It yields a sufficient condition on the non-existence of compact Clifford-Klein forms in terms of the Pontryagin classes of some vector bundles naturally related to the given homogeneous space G/H. To formulate it, we need to refer to Subsection 2.4 for the detailed explanations. Here we briefly recall the following. Let K be a maximal compact subgroup of G. Choose it in a way that  $K_H = K \cap H$  is a maximal compact subgroup of H. Consider the corresponding Lie algebras  $\mathfrak{g}, \mathfrak{k}, \mathfrak{h}$  and  $\mathfrak{k}_H$ . Take a Cartan decomposition  $\mathfrak{g} = \mathfrak{k} + \mathfrak{p}$ . There is an orthogonal (with respect to the Killing form of  $\mathfrak{g}$ ) decomposition

$$\mathfrak{g}=\mathfrak{k}_H+\mathfrak{k}_H^\perp+\mathfrak{p}_H+\mathfrak{p}_H^\perp$$

where  $\mathfrak{p}_H = \mathfrak{p} \cap \mathfrak{h}$ . Consider the vector bundle

$$G \times_{K_H} (\mathfrak{p}_H^{\perp} + \mathfrak{p}_H) \to G/K_H$$

with fiber  $\mathfrak{p}_H + \mathfrak{p}_H^{\perp}$  and the structure group  $K_H$  acting on the fiber by the adjoint representation. For any vector bundle  $E \to M$  denote by  $p_i(E)$  the i-th Pontryagin class of E. Assume that G/H admits a solvable Clifford-Klein form  $\Gamma$  and let B be a (connected) syndetic hull of  $\Gamma$  (the definition and the basic facts about syndetic hulls are given in Subsection 2.3). Let  $\mathfrak{g}$ ,  $\mathfrak{h}$ ,  $\mathfrak{b}$  be the Lie algebras of G, H, B, respectively. As usual, we consider the Lie algebra cohomology  $H^*(\mathfrak{g}, \mathbb{R})$  and the relative cohomology  $H^*(\mathfrak{g}, \mathfrak{b}, \mathbb{R})$ . Denote by  $\Gamma_H$  a co-compact lattice in H (it exists because H is reductive). It is easy to see that  $M_B := \Gamma_H \backslash G/B$  is a compact manifold of dimension  $\dim M_B := n$ .

**Theorem 1.** Let G/H be a non-compact reductive homogeneous space of a semisimple linear Lie group G. Assume that G/H admits an amenable compact Clifford-Klein form. Then it admits a solvable Clifford-Klein form with a syndetic hull B and the following holds.

- i) The map  $H^n(\mathfrak{g}, \mathfrak{b}, \mathbb{R}) \to H^n(\mathfrak{g}, \mathbb{R})$  induced by the inclusion  $\Lambda^n(\mathfrak{g}/\mathfrak{b}) \hookrightarrow \Lambda^n(\mathfrak{g})$  is injective.
- ii) rank G > rank H.

<span id="page-3-0"></span>iii) 
$$p_i(G \times_{K_H} (\mathfrak{p}_H^{\perp} + \mathfrak{p}_H)) = 0 \text{ for } i > 0.$$

As an application of the latter theorem, we get the non-existence of amenable Clifford-Klein forms for almost all pseudo-Riemannian symmetric spaces.

<span id="page-3-2"></span>Theorem 2. Non-compact pseudo-Riemannian symmetric spaces G/H of absolutely simple non-compact connected linear real Lie groups do not admit amenable compact Clifford-Klein forms, with, possibly, the following exceptions:

$$SO(n,m)/SO(n-k,m) \times SO(k)$$
, with  $0 < n \le m$ ;  $m$ ,  $n$  even,  $k$  odd,  $SU(2p,2q)/Sp(p,q)$ ,  $SU(2m-1,2m-1)/SO^*(4m-2)$ .

In the same way, we get the following.

<span id="page-3-3"></span>Theorem 3. Non-compact pseudo-Riemannian 3-symmetric spaces G/H of absolutely simple non-compact connected linear real Lie groups do not admit amenable compact Clifford-Klein forms, with, possibly, the following exceptions:

$$SO(3,5)/G_{2(2)}$$
.

Finally, let us mention topological obstructions to the existence of Clifford-Klein forms found by Y. Morita [\[17\]](#page-18-3), [\[18\]](#page-18-4) and N. Tholozan [\[22\]](#page-18-5). Note that Hirzebruch's proportionality principle has already been used in the context of symmetric spaces (for instance in [\[14\]](#page-17-2), Corollary 3.6.4): a semisimple symmetric space Sp(2n, R)/Sp(n, C) does not admit a compact Clifford-Klein form.

Acknowledgment. We thank Dmitri Alekseevsky and Ioannis Chrysikos for answering our questions.

# <span id="page-3-1"></span>2 Preliminaries

### 2.1 Homogeneous spaces and their Clifford-Klein forms

Throughout this paper we use the basics of Lie theory without further explanations. One can consult [\[10\]](#page-17-8). We denote Lie groups by G, H, ..., and their Lie algebras by the corresponding Gothic letters  $\mathfrak{g}, \mathfrak{h}...$  The symbol  $\mathfrak{g}^{\mathbb{C}}$  denotes the complexification of a real Lie algebra  $\mathfrak{g}$ . We also use relations between Lie groups and algebraic groups following [8] and [24]. If  $\mathbf{G} \subset GL(n,\mathbb{C})$  is an algebraic  $\mathbb{R}$ -group, then  $G = \mathbf{G}_{\mathbb{R}} = \mathbf{G} \cap GL(n,\mathbb{R})$  is a Lie group with a finite number of connected components.

Assume that G is a semisimple Lie group, and  $H \subset G$  is a closed connected subgroup. We use without further explanations the notion of the Cartan decomposition  $\mathfrak{g} = \mathfrak{k} + \mathfrak{p}$  and the related Cartan involution  $\theta$ . Let K denote a maximal compact subgroup in G corresponding to  $\mathfrak{k}$ . Then one can obtain the Iwasawa decomposition

$$\mathfrak{a} = \mathfrak{k} + \mathfrak{a} + \mathfrak{n}$$

where  $\mathfrak{a}$  is a maximal abelian subalgebra in  $\mathfrak{p}$ , and  $\mathfrak{n}$  is nilpotent, while  $\mathfrak{a} + \mathfrak{n}$  is a solvable subalgebra in  $\mathfrak{g}$ . On the Lie group level, one obtains the *global Iwasawa decomposition* G = KAN which is a topological decomposition into a direct product.

Let X be a Hausdorff topological space and  $\Gamma$  a topological group acting on X. We say that an action of  $\Gamma$  on X is *proper* if for any compact subset  $S \subset X$  the set

$$\{\gamma \in \Gamma \mid \gamma(S) \cap S \neq \emptyset\}$$

is compact. In particular, this article is devoted to the proper actions of a discrete subgroup  $\Gamma \subset G$  on G/H by left translations. We consider homogeneous spaces G/H of reductive type, which means, by definition, that there exists a Cartan involution  $\theta$  on  $\mathfrak g$  such that  $\theta(\mathfrak h) \subset \mathfrak h$ . Using the Cartan involution, one can obtain the compatible Cartan decomposition

$$\mathfrak{h} = \mathfrak{k}_H + \mathfrak{p}_H, \ \mathfrak{k}_H = \mathfrak{k} \cap \mathfrak{h}, \ \mathfrak{p}_H = \mathfrak{p} \cap \mathfrak{h},$$

on the Lie algebra level and we can choose a maximal abelian subalgebra in  $\mathfrak{p}_H$  so that  $\mathfrak{a}_H \subset \mathfrak{a}$ .

The main result of this article deals with symmetric spaces. The latter are homogeneous spaces G/H, where G is a Lie group, and H is a closed subgroup in G such that

<span id="page-4-0"></span>
$$G_0^{\sigma} \subset H \subset G^{\sigma}.$$
 (1)

Here  $G^{\sigma} = \{g \in G \mid \sigma(g) = g\}$  is a subgroup of fixed points of an involutive automorphism of G, and  $G_0^{\sigma}$  denotes the identity connected component of G. Note that we don't assume that G/H is Riemannian (the latter case is

well known: Riemannian symmetric spaces always have Clifford-Klein forms by a classical result of Borel). Any symmetric space G/H determines a symmetric pair (g, h). The subalgebra h is the subalgebra of the fixed points of the differential of σ. Note that throughout the paper we denote it by the same letter:

$$\mathfrak{h}=\mathfrak{g}^{\sigma}=\{X\in\mathfrak{g}\,|\,\sigma(X)=X\}.$$

In the same way, we consider pseudo-Riemannian 3-symmetric spaces, which are defined by the similar condition [1,](#page-4-0) but with the requirement that σ is an automorphism of G of order 3. These spaces were classified by Wolf and Gray [\[26\]](#page-18-1),[\[27\]](#page-18-2). Various interpretations of this class as well as its role in geometry are described in [\[15\]](#page-17-10).

Recall that we say that G/H admits a compact Clifford-Klein form if there exists a discrete subgroup Γ ⊂ G acting properly and co-compactly on G/H. Finally, recall that solvmanifolds are the homogeneous spaces of connected solvable Lie groups. In the proof of Theorem [1](#page-3-0) we will need the following classical result.

<span id="page-5-0"></span>Theorem 4 ([\[6\]](#page-17-11), Chapter 8). The Euler characteristic of a compact solvmanifold vanishes.

Remark 1. One can see that the Euler characteristic of a solvmanifold is zero without the reference [\[6\]](#page-17-11) just by looking at the classical construction of the Mostow bundle: let Γ \ B be a solvmanifold, determined by a lattice Γ ⊂ B. Let N<sup>B</sup> be the nil-radical of B. There is a fiber bundle

$$\Gamma \cap N_B \setminus N_B \to \Gamma \setminus B \to \Gamma N_B \setminus B$$

where ΓN<sup>B</sup> \ B is diffeomorphic to a torus.

Also, we need a classical theorem of Auslander and Szczarba.

Theorem 5 ([\[1\]](#page-16-0)). The real Pontryagin classes of any compact solvmanifold vanish.

Throughout this paper we consider characteristic classes of vector bundles [\[16\]](#page-18-7). In particular we write pi(E) considering i-th Pontryagin class of vector bundle E. If M is a manifold, we write pi(M) meaning that p<sup>i</sup> is the i-th Pontryagin class of the tangent bundle: pi(M) = pi(TM).

Finally, let us recall that a discrete group Γ is amenable, if it admits a finitely additive probability measure.

#### <span id="page-6-2"></span>2.2 Hirzebruch's proportionality principle

Let G/H be a homogeneous space of reductive type. Let  $G_u$  be a compact real form of a (connected) complexification  $G^{\mathbb{C}}$  of G and let  $H_u$  be a compact real form of  $H^{\mathbb{C}} \subset G^{\mathbb{C}}$ . The space  $G_u/H_u$  is called the homogeneous space of compact type associated with G/H (or dual to G/H). Groups  $G_u$ ,  $H_u$  are called the compact duals of G and H, respectively.

<span id="page-6-1"></span>**Theorem 6** ([12], Theorem 4, [13], Corollary 3.8). Assume that a discrete subgroup  $\Gamma \subset G$  acts on G/H freely and properly. Then there is a natural map

$$\eta: H^*(G_u/H_u, \mathbb{R}) \to H^*(\Gamma \setminus G/H, \mathbb{R})$$

which sends the Pontryagin classes of  $G_u/H_u$  to those of  $\Gamma \setminus G/H$ . If  $\Gamma \setminus G/H$  is compact then  $\eta$  is injective. Also, it sends the Euler class of  $G_u/H_u$  to the Euler class of  $\Gamma \setminus G/H$ .

In our proofs we essentially use a result in [13] which we now describe. Let  $\rho$ :  $H \to GL(V)$  be a representation of H in a real vector space V. Analogously let  $\rho_u : H_u \to GL(V_u)$  be a representation of  $H_u$ . Consider the following vector bundles:

$$E: \Gamma \backslash G \times_{\rho} V \to \Gamma \backslash G / H$$
 and  $E_u: G_u \times_{\rho_u} V_u \to G_u / H_u$ .

**Theorem 7** ([13], Theorem 3.7). Assume that the complexifications of  $\rho$  and  $\rho_u$  are isomorphic. Then the i-th real Pontryagin class satisfies

$$\eta(p_i(E_u)) = p_i(E).$$

**Remark 2.** Hirzebruch proved in [7] the "proportionality principle" for the Chern numbers of bounded Hermitian symmetric domains and their compact duals.

### <span id="page-6-0"></span>2.3 Syndetic hull

We will need the notion of a syndetic hull [23].

**Definition 1.** A syndetic hull of a subgroup  $\Gamma$  of a Lie group G is a subgroup B of G such that B is connected, B contains  $\Gamma$  and  $\Gamma \setminus B$  is compact.

In the sequel we will need Theorem 8 on the existence of some syndetic hulls.

<span id="page-7-0"></span>**Theorem 8** ([4], Section 1.6). Let V be a finite-dimensional real vector space and  $\Lambda$  a virtually solvable subgroup of GL(V). Then there exists at least one closed virtually solvable subgroup  $S \subset GL(V)$  containing  $\Lambda$  such that:

- i) S has finitely many components and each component meets  $\Lambda$ ;
- ii) (syndeticity) there exists a compact set  $K \subset H$  such that  $S = K \cdot \Lambda$ ;
- iii) S and  $\Lambda$  have the same Zariski closure in GL(V).

Recall that a real algebraic group T is a torus, if T is abelian and Zariski connected, and every element of T is semisimple. A torus T is  $\mathbb{R}$ -split, if every element of T is diagonalizable (and, therefore, hyperbolic).

<span id="page-7-1"></span>**Lemma 1** ([25]). Let T be a torus. If  $T_{split}$  is the maximal  $\mathbb{R}$ -split subtorus of T, and  $T_{cpt}$  is the maximal compact subtorus of T, then

$$T = T_{split} \cdot T_{cpt}$$

and  $T_{split} \cap T_{cpt}$  is finite.

We will also need the following well known fact (see [28]).

<span id="page-7-2"></span>**Proposition 1.** Let  $\Gamma$  be a (co-compact) lattice in a locally compact topological group L, and  $L_1$  be a normal subgroup. Let  $\pi: L \to L/L_1$  be the natural projection onto the quotient group. Then  $\Gamma \cap L_1$  is a (co-compact) lattice in  $L_1$  if and only if  $\pi(\Gamma) \subset L/L_1$  is a (co-compact lattice) in  $L/L_1$ .

<span id="page-7-3"></span>**Lemma 2.** If a solvable subgroup  $\Gamma \subset G$  acts properly and co-compactly on G/H, then there exists a solvable subgroup  $\Gamma_0 \subset AN$  that acts properly and co-compactly on G/H.

Proof. Since G is connected and linear,  $G \subset GL(V)$ . Take the Zariski closure  $L = \bar{\Gamma}$  and apply Theorem 8 to  $\Gamma$  (instead of  $\Lambda$ ). We obtain that there exists a subgroup  $B_1 \subset GL(V)$  such that  $\Gamma \subset B_1$  and  $\bar{\Gamma} = \bar{B}_1 = L \subset G$  (that is, we have  $B_1$  instead of S in Theorem 8). Since L is the Zariski closure of  $\Gamma$ , it is also solvable. Thus we obtain a (virtually) solvable subgroup  $B_1$  such that  $\Gamma \setminus B_1$  is compact. Consider the connected component B of  $B_1$ . Clearly, B

must be solvable. Since the Lie subgroup B<sup>1</sup> contains a uniform lattice Γ, so does B as B<sup>1</sup> has finitely many connected components.

In general the inclusion B ⊂ AN does not hold, but we may assume this in our context, because of the argument below. Note that L = Γ =¯ B¯ is real algebraic, and, hence it is a semidirect product

$$L = \bar{T} \ltimes \bar{U}$$

of a torus, and a unipotent subgroup U¯. By Lemma [1](#page-7-1)

$$\bar{T} = T_{split} \cdot T_{cpt}.$$

Take L<sup>1</sup> = Tsplit⋉U, a normal and co-compact subgroup of L. It follows that B ∩ L<sup>1</sup> is normal in B and B/B ∩ L<sup>1</sup> is a closed subgroup in the (Lie) group L/L1. By Proposition [1](#page-7-2) we see that Γ<sup>0</sup> := Γ ∩ (B ∩ L1) is a lattice in B ∩ L<sup>1</sup> (and in B as L/L<sup>1</sup> is compact). Therefore Γ<sup>0</sup> acts properly and co-compactly on G/H. It suffices to show that L<sup>1</sup> ⊂ AN. But any solvable subgroup of G that is generated by unipotent and hyperbolic elements is conjugate to a subgroup of AN (this is basically a generalization of the fact that a collection of commuting triangularizable matrices can be simultaneously triangularized, see the proof of Theorem 17.6 in [\[8\]](#page-17-9)). The proof of Lemma [2](#page-7-3) is complete.

#### <span id="page-8-0"></span>2.4 Duality of symmetric spaces

Let G/H be a (pseudo-Riemannian) symmetric space. Using the Killing form of g we get two orthogonal decompositions on the Lie algebra level. The first one is given by the eigenspaces of the Cartan involution θ, and the second one by σ:

$$\mathfrak{g} = \mathfrak{k} + \mathfrak{p}, \ \mathfrak{g} = \mathfrak{h} + \mathfrak{m}.$$

Without loss of generality we may assume that θ and σ commute. This yields the decompositions of k and p with respect to σ:

$$\mathfrak{k} = \mathfrak{k}_H^{\perp} + \mathfrak{k}_H, \ \mathfrak{p} = \mathfrak{p}_H + \mathfrak{p}_H^{\perp},$$

where h = k<sup>H</sup> + pH. Note that

$$[\mathfrak{k}_H, \mathfrak{p}_H^{\perp}] \subset \mathfrak{p}_H^{\perp} \text{ and } [\mathfrak{p}_H^{\perp}, \mathfrak{p}_H^{\perp}] \subset \mathfrak{k}_H.$$

Therefore

$$(\mathfrak{d},\mathfrak{k}_H),\,\mathfrak{d}:=\mathfrak{k}_H+\mathfrak{p}_H^\perp$$

is a symmetric pair given by the involution σθ. One can see that d ⊂ g, and that (g, d) is also a symmetric pair.

Definition 2. The pair (g, d) is called the symmetric pair associated to (g, h).

Note also that since (gu,k) and (gu, hu) are also symmetric pairs, we obtain analogous decompositions of compact duals:

$$\mathfrak{g}_u = \mathfrak{k} + \mathfrak{p}_u, \ \mathfrak{g}_u = \mathfrak{h}_u + \mathfrak{m}_u.$$

One can see that

$$\mathfrak{k}_H = \mathfrak{k}_{H_u} \ \mathfrak{p}_u = \mathfrak{p}_{H_u} + \mathfrak{p}_{H_u}^{\perp}.$$

Let D ⊂ G denote a connected group corresponding to d and D<sup>u</sup> the compact dual of D.

In what follows it will be useful for the reader to have in mind the following table of the "dualities":

$$G/K \longleftrightarrow G_u/K, G/H \longleftrightarrow G_u/H_u$$
  
 $H/K_H \longleftrightarrow H_u/K_H, G/K_H \longleftrightarrow G_u/K_H.$ 

as well as the corresponding decompositions of the considered Lie algebras:

$$\begin{split} \mathfrak{g} &= \mathfrak{k} + \mathfrak{p}, \ \mathfrak{g}_u = \mathfrak{k} + \mathfrak{p}_u, \ \mathfrak{g} = \mathfrak{h} + \mathfrak{m}, \ \mathfrak{g}_u = \mathfrak{h}_u + \mathfrak{m}_u, \\ \mathfrak{k} &= \mathfrak{k}_H + \mathfrak{k}_H^{\perp}, \ \mathfrak{p} = \mathfrak{p}_H + \mathfrak{p}_H^{\perp}, \ \mathfrak{p}_u = \mathfrak{p}_{H_u} + \mathfrak{p}_{H_u}^{\perp}, \\ \mathfrak{h} &= \mathfrak{k}_H + \mathfrak{p}_H, \ \mathfrak{h}_u = \mathfrak{k}_H + \mathfrak{p}_{H_u}, \\ \mathfrak{d} &= \mathfrak{k}_H + \mathfrak{p}_H^{\perp}, \ \mathfrak{d}_u = \mathfrak{k}_H + \mathfrak{p}_{H_u}^{\perp}, \\ \mathfrak{g} &= \mathfrak{k}_H + \mathfrak{k}_H^{\perp} + \mathfrak{p}_H + \mathfrak{p}_H^{\perp}, \ \mathfrak{g}_u = \mathfrak{k}_H + \mathfrak{k}_H^{\perp} + \mathfrak{p}_{H_u} + \mathfrak{p}_{H_u}^{\perp}. \end{split}$$

# 3 Proof of Theorem [1](#page-3-0)

#### 3.1 The case of maximal rank

We begin with the simplest case which follows from the Kobayashi and Ono theorem in a straightforward manner.

<span id="page-9-0"></span>Proposition 2. Let G/H be a non-compact homogeneous space of reductive type. Assume that rank G = rank H. Then no solvable Γ can yield a compact Clifford-Klein form of G/H.

Proof. Let K and K<sup>H</sup> be as in Section [2.](#page-3-1) Let Γ ⊂ G be a discrete subgroup determining a compact Clifford-Klein form. Note that all the arguments with the compactness property can be performed up to subgroups of a finite index in Γ, so throughout this paper we do not distinguish them. In particular, we may assume that Γ acts co-compactly and freely on X. Consider the fiber bundles

$$H/K_H \to G/K_H \to G/H$$
, and  $K/K_H \to G/K_H \to G/K$ ,

and

<span id="page-10-0"></span>
$$K/K_H \to \Gamma \setminus G/K_H \to \Gamma \setminus G/K.$$
 (2)

Since H/K<sup>H</sup> is diffeomorphic to some euclidean space, Γ\G/K<sup>H</sup> and Γ\G/H have the same homotopy type. Clearly, the classifying space for Γ is BΓ = Γ \ G/K, therefore χ(Γ) = χ(Γ \ G/K). Looking at [2](#page-10-0) we write down

<span id="page-10-1"></span>
$$\chi(\Gamma \setminus G/H) = \chi(\Gamma \setminus G/K_H) = \chi(K/K_H) \cdot \chi(\Gamma). \tag{3}$$

By assumption, G and H have equal ranks, hence the same is valid for G<sup>u</sup> and Hu. It is a classical result that χ(Gu/Hu) 6= 0, and that the Euler class of T(Gu/Hu) is not zero. By Theorem [6](#page-6-1) the Euler class e(T(Γ \ G/H)) and the Euler characteristic χ(Γ\G/H) also do not vanish. On the other hand, if Γ is solvable and acts on G/H, with a compact quotient, it admits a syndetic hull B, by Theorem [8,](#page-7-0) and, therefore, Γ \ B is a compact solvmanifold. By Theorem [4,](#page-5-0) χ(Γ \ B) = 0. Note that by [\[28\]](#page-18-9), Theorem 3.14, the group Γ contains a finite index subgroup which can be embedded into a simply connected solvable Lie subgroup B˜ as a lattice. Hence, χ(B/˜ Γ) = χ(Γ) = 0. Comparing this with [3](#page-10-1) yields a contradiction, hence Γ cannot be solvable.

### 3.2 A Lie cohomology obstruction

Assume that G/H admits a solvable Clifford-Klein form Γ and let B be a (connected) syndetic hull of Γ. Let g, h, b be the Lie algebras of G, H, B, respectively. Denote by Γ<sup>H</sup> a co-compact lattice in H (it exists because H is reductive). It is easy to see that M<sup>B</sup> := ΓH\G/B is a compact manifold of dimension dimM<sup>B</sup> := n. Since B is unimodular we have

$$(\Lambda^n(\mathfrak{g}/\mathfrak{b})^*)^B \neq 0.$$

Take any non-zero  $\Phi \in (\Lambda^n(\mathfrak{g}/\mathfrak{b})^*)^B$ . Then  $\Phi$  induces a G-invariant form on G/B which gives a volume form on  $M_B$ . Therefore

$$H^n(\mathfrak{g},\mathfrak{b},\mathbb{R})\neq 0.$$

Let  $A \subset B$  be any closed connected subgroup and denote by  $\mathfrak a$  the Lie algebra of A. Consider the following commutative diagram

$$H^{n}(\mathfrak{g}, \mathfrak{b}, \mathbb{R}) \xrightarrow{\eta} H^{n}(\mathfrak{g}, \mathfrak{a}, \mathbb{R})$$

$$f \downarrow \qquad \qquad \downarrow g$$

$$H^{n}(M_{B}, \mathbb{R}) \xrightarrow{\pi^{*}} H^{n}(\Gamma_{H} \backslash G/A)$$

As  $\pi^*$  is given by a fibration with a contractible typical fiber

$$B/A \to \Gamma_H \backslash G/A \xrightarrow{\pi} \Gamma_H \backslash G/B$$
,

thus  $\pi^*$  is an isomorphism. We obtain the following lemma

<span id="page-11-0"></span>**Lemma 3.** If G/H admits a solvable Clifford-Klein form then the map

$$0 \neq H^n(\mathfrak{g}, \mathfrak{b}, \mathbb{R}) \stackrel{\eta}{\to} H^n(\mathfrak{g}, \mathfrak{a}, \mathbb{R})$$

is injective.

*Proof.* Since f and  $\pi^*$  are injective thus the injectivity of  $\eta$  follows from the commutativity of the diagram.

Example 1. The 3-symmetric spaces

$$A := SO(4,4)/SU(1,2), B := SO(4,4)/G_{2(2)}$$

do not admit solvable compact Clifford-Klein forms.

*Proof.* Put  $\mathfrak{a} = \{0\}$  in Lemma 3.2. We obtain that the map

$$H^n(\mathfrak{g},\mathfrak{b},\mathbb{R}) \stackrel{\eta}{\to} H^n(\mathfrak{g},\mathbb{R})$$

has to be injective, where n = 16 for A and n = 21 for B. It follows from Lemma 3.7 and Proposition 3.9 in [12] (by putting  $\mathfrak{h} = \{0\}$ ) that

$$H^*(\mathfrak{g},\mathbb{R})\cong H^*(\mathfrak{g}_u,\mathbb{R}),$$

where  $\mathfrak{g}_u$  is the compact dual of  $\mathfrak{g}$ . In our case  $\mathfrak{g}_u = \mathfrak{so}(8)$ , dim $\mathfrak{so}(8) = 28$  which cohomology ring has generators in degrees

It follows that  $H^{16}(\mathfrak{g},\mathbb{R})=H^{20}(\mathfrak{g},\mathbb{R})=0$ . Thus  $\eta$  is not injective.  $\square$ 

#### 3.3 Obstructions coming from Pontryagin classes

Let  $\Gamma \backslash G \times_{\rho} V$  and  $\Gamma \backslash G_u \times_{\rho_u} V_u$  be two vector bundles such that  $\rho$  and  $\rho_u$  have isomorphic complexifications (see Section 2.2).

**Proposition 3.** Assume that G/H admits a solvable Clifford-Klein form. For the representation  $\rho: H \to V$  and its restriction onto  $K_H$ , the following conditions are equivalent:

- $p_i(K \times_{K_H} V) = 0$
- $p_i(\Gamma \backslash G \times_{K_H} V) = 0$
- $p_i(\Gamma \backslash G \times_H V) = 0$
- $p_i(G_u \times_{H_u} V_u) = 0$

Proof. Recall that G has a decomposition G = NAK. Thus  $\Gamma \backslash G/K_H \cong \Gamma \backslash AN \times (K/K_H)$ , as we may assume that  $\Gamma \subset AN$ . Now we make two straightforward general observations. First, if  $L \subset P \subset G$  is a triple of Lie groups and L acts linearly on a vector space V, then  $P \times_L V$  is the pullback of  $G \times_L V$  under the inclusion  $i: P/L \to G/L$ . Second, if  $P = P_1 \times P_2$  is a product of manifolds, and  $G \to P_2 \to P_2/G$  is a principal G-bundle, then, assuming that G acts trivially on G, one obtains a principal G-bundle  $G \to P_1 \times P_2 \to P_1 \times P_2/G$ . In this case, for any linear action of G on a vector space G, the associated vector bundle  $G \to P_1 \times P_2 \to P_2/G$  under the projection G is the pullback of  $G \to P_2 \to P_2/G$  under the projection G is the pullback of  $G \to P_2 \to P_2/G$  under the projection G is the product G is the product of G is a principal G is the pullback of  $G \to G$  is a principal G is the pullback of  $G \to G$  is a principal G. Applying these observations to G is a principal G is a principal G is the pullback of  $G \to G$  is a principal G. Applying these observations to G is a principal G is a principal G is a principal G.

$$p_i((\Gamma \setminus AN \times K) \times_{K_H} V = p_i(\Gamma \setminus G \times_{K_H} V) = q_2^* p_i(K \times_{K_H} V).$$

It follows that  $p_i(K \times_{K_H} V) = 0$  if and only if

$$p_i(\Gamma \backslash G \times_{K_H} V) = 0 \tag{4}$$

as  $q_2^*$  is injective. Consider the commutative diagram

$$G \times_{K_H} V \xrightarrow{\pi} G \times_H V$$

$$\downarrow \qquad \qquad \downarrow$$

$$G/K_H \longrightarrow G/H$$

We have already mentioned that  $G \times_{K_H} V = \pi^*(G \times_H V)$ . Let us make the following general remark. Assume that  $E \to B$  is a vector bundle, and  $f: B' \to B$  is a map, and assume that a group  $\Gamma$  acts on E, B' and B in a way that it commutes with f and preserves the structure of the vector bundle. Then,  $\hat{E} = E/\Gamma \to B/\Gamma$  is again a vector bundle, and there is a commutative diagram

$$f^{*}(E)/\Gamma \longrightarrow E/\Gamma$$

$$\downarrow \qquad \qquad \downarrow$$

$$B'/\Gamma \xrightarrow{\hat{f}} B/\Gamma$$

and  $\hat{f}^*(E/\Gamma) = (f^*E)/\Gamma$ . Applying this general obsevation to the case  $G/K_H$  and G/H one can write

$$(\Gamma \setminus G) \times_{K_H} V = \hat{\pi}^*(\Gamma \setminus G \times_H V).$$

The latter yields

$$p_i(\Gamma \setminus G \times_{K_H} V) = \hat{\pi}^* p_i(\Gamma \setminus G \times_H V).$$

Also, we have the commutative diagram

$$(\Gamma \setminus G) \times_{K_H} V \xrightarrow{\hat{\pi}} \Gamma \setminus G \times_H V$$

$$\downarrow \qquad \qquad \downarrow$$

$$\Gamma \setminus G/K_H \xrightarrow{\pi_2} \Gamma \setminus G/H$$

which yields

$$\hat{\pi}^* p_i(\Gamma \setminus G \times_H V) = \pi_2^* p_i(\Gamma \setminus G \times_H V) = p_i(\Gamma \setminus G \times_{K_H} V) = 0.$$

But  $\pi_2^*$  is an isomorphism, since  $\Gamma \setminus G/K_H$  and  $\Gamma \setminus G/H$  have the same homotopy type, hence  $p_i(\Gamma \setminus G \times_H V) = 0$  if and only if  $p_i(\Gamma \setminus G \times_{K_H} V) = 0$ . Using the Hirzebruch proportionality principle (Theorem 6), we conclude that

$$\eta(p_i(G_u \times_{H_u} V) = p_i(\Gamma \setminus G \times_H V)$$

and since  $\eta$  is injective, we get the result.

<span id="page-13-0"></span>**Remark 3.** By the definition of  $q_2^*$  it follows that if V is a  $K_H$ -module then

$$p_i(K \times_{K_H} V) = 0$$
 if and only if  $p_i(\Gamma \setminus G \times_{K_H} V) = 0$ .

<span id="page-14-1"></span>Proposition 4. If pi(G ×<sup>K</sup><sup>H</sup> (p ⊥ <sup>H</sup> + pH)) 6= 0 for some i > 0 then G/H does not admit solvable compact Clifford-Klein forms.

Proof. Consider the fibration

$$K/K_H \to \Gamma \backslash G/K_H \xrightarrow{l} \Gamma \backslash G/K \cong \Gamma \backslash AN.$$

Since Γ\AN is a solvmanifold it follows from the theorem of Auslander and Szczarba that pi(Γ\AN) = 0 for any i > 0. As rational Pontryagin classes are topological invariants we have pi(Γ\G/K) = 0. By the pullback via l we obtain

$$p_i(G \times_{K_H} (\mathfrak{p}_H^{\perp} + \mathfrak{p}_H)) = 0. \tag{5}$$

Let G/H be a symmetric space. Let (g, h) be the corresponding symmetric pair and (g, d) be the associated symmetric pair. Let also Gu, Hu, D<sup>u</sup> denote the compact duals of G, H, D, respectively. Also let K be the maximal compact subgroup of G and K<sup>H</sup> the maximal compact subgroup of H.

Corollary 1. If for some i > 0

$$p_i(K/K_H) = p_i(G_u/D_u) = 0 \neq p_i(G_u/H_u),$$

then G/H does not admit solvable compact Clifford-Klein forms.

Proof. It follows from Proposition [2.2](#page-6-2) that if pi(Gu/Hu) = pi(G<sup>u</sup> ×<sup>H</sup><sup>u</sup> (k ⊥ <sup>H</sup> + p ⊥ Hu )) 6= 0 then also

<span id="page-14-2"></span>
$$p_i(\Gamma \backslash G \times_{K_H} (\mathfrak{t}_H^{\perp} + \mathfrak{p}_H^{\perp})) \neq 0.$$
 (6)

Consider the following fiber bundle

$$D_u/K_H \xrightarrow{i} G_u/K_H \to G_u/D_u$$
.

Since pi(G<sup>u</sup> ×<sup>D</sup><sup>u</sup> (k ⊥ <sup>H</sup><sup>u</sup> + p<sup>H</sup><sup>u</sup> )) = 0 ( where G<sup>u</sup> ×<sup>D</sup><sup>u</sup> (k ⊥ <sup>H</sup><sup>u</sup> + p<sup>H</sup><sup>u</sup> ) is the tangent bundle of Gu/Du)it follows that the pullback bundle has the same property, that is

$$p_i(G_u \times_{K_H} (\mathfrak{k}_{H_u}^{\perp} + \mathfrak{p}_{H_u})) = 0.$$

By Theorem [6](#page-6-1) we obtain

<span id="page-14-0"></span>
$$p_i(\Gamma \backslash G \times_{K_H} (\mathfrak{t}_H^{\perp} + \mathfrak{p}_H)) = 0. \tag{7}$$

Since pi(K ×<sup>K</sup><sup>H</sup> k ⊥ <sup>H</sup>) = 0 it follows from Remark [3](#page-13-0) that

<span id="page-15-0"></span>
$$p_i(\Gamma \backslash G \times_{K_H} \mathfrak{k}_H^{\perp}) = 0 \tag{8}$$

Using [\(7\)](#page-14-0), [\(8\)](#page-15-0), Proposition [4](#page-14-1) and the Whitney sum formula one easily shows that

$$p_i(G \times_{K_H} (\mathfrak{t}_H^{\perp} + \mathfrak{p}_H^{\perp})) = 0,$$

but this contradicts [\(6\)](#page-14-2).

To complete the proof we need only to recall the Tits alternative, which shows that since there are no solvable Clifford-Klein forms in the considered cases, there are also no amenable ones (as the free group on two generators is non-amenable).

# 4 Proof of Theorem [2](#page-3-2)

To classify symmetric spaces that may admit solvable Clifford-Klein forms we take the Table A.1 in [\[19\]](#page-18-10) of all symmetric spaces that admit proper SL(2, R) actions (if a non-compact reductive space of a semisimple Lie group admits a compact Clifford-Klein form it also admits a proper action of SL(2, R), see [\[19\]](#page-18-10)). Using Proposition [2,](#page-9-0) we exclude rows that contain spaces of maximal rank and rows with spaces that do not admit compact Clifford-Klein forms listed in [\[17\]](#page-18-3). This way we obtain the following list of symmetric pairs:

• exceptional pairs:

$$(\mathfrak{e}_{6(2)}, \mathfrak{sp}(3,1)), (\mathfrak{e}_{6(-14)}, \mathfrak{f}_{4(-20)}).$$

• classical pairs:

$$SO(n,m)/SO(n-k,m) \times SO(k)$$
, with  $0 < n \le m$ ;  $m, n$  even;  $k$  odd,  $SU(2p,2q)/Sp(p,q)$ ,  $SU(2m-1,2m-1)/SO^*(4m-2)$ .

Exceptional pairs can be settled by the following arguments.

Case 1: The non-compact symmetric space determined by the symmetric pair (e6(−14), f4(−20)) does not admit solvable Clifford-Klein forms.

Proof. Assume that that the latter symmetric space admits a solvable Clifford-Klein form. Put a = {0} in Lemma [3.2.](#page-11-0) We obtain that the map

$$H^{62}(\mathfrak{g},\mathfrak{b},\mathbb{R}) \stackrel{\eta}{\to} H^{62}(\mathfrak{g},\mathbb{R})$$

has to be injective. It follows from Lemma 3.7 and Proposition 3.9 in [\[12\]](#page-17-0) (by putting h = {0}) that

$$H^*(\mathfrak{g},\mathbb{R})\cong H^*(\mathfrak{g}_u,\mathbb{R}),$$

where g<sup>u</sup> is the compact dual of g. In our case g<sup>u</sup> = e6, dime<sup>6</sup> = 78 which cohomology ring has generators in degrees

3, 9, 11, 15, 17, 23.

It follows that H<sup>62</sup>(gu, R) = H<sup>62</sup>(g, R) = 0. This contradicts the fact that H<sup>62</sup>(g, b, R) 6= 0 and η is injective.

Case 2: The non-compact symmetric space determined by the symmetric pair (e6(2), sp(3, 1)) does not admit solvable Clifford-Klein forms.

Proof. We have

$$G_u/H_u = E_6/Sp(4), \ K/K_H = SU(6)/Sp(3), \ G_u/D_u = E_6/F_4.$$

It follows from Theorem 6.18 and Theorem 6.21 in [\[20\]](#page-18-11) that p2(Gu/Hu) 6= 0 and p2(Gu/Du) = 0 and from Section 3.2 in [\[21\]](#page-18-12) that p2(K/KH) = 0.

# 5 Proof of Theorem [3](#page-3-3)

The proof is obtained by a combination of Example 1, Proposition [2](#page-9-0) and the classification of non-compact 3-symmetric spaces of simple and absolutely simple real Lie groups in [\[26\]](#page-18-1),[\[27\]](#page-18-2).

# <span id="page-16-0"></span>References

[1] L. Auslander, R. Szczarba, Characteristic classes of compact solvmanifolds, Ann. Math. 76(1962), 1-8

- <span id="page-17-7"></span><span id="page-17-3"></span>[2] Y. Benoist, Actions propres sur les espaces homogénes réductifs, Ann. Math. 144 (1996), 315-347.
- <span id="page-17-13"></span>[3] M. Bocheński, A. Tralle, On solvable compact Clifford-Klein forms, Proc. Amer. Math. Soc. 145 (2017), 1819-1832.
- [4] D. Fried, W. Goldman, Three-dimensional affine crystallographic groups, Adv. Math. 47 (1983), 1-49.
- <span id="page-17-6"></span>[5] F. Guéritaud, O. Guichard, F. Kassel, A. Wienhard, Compactification of certain Clifford-Klein forms of reductive homogeneous spaces, ArXiv: 1506.0374v2, to appear in Michigan Math. J.
- <span id="page-17-11"></span>[6] J. A. Hillman, Four-Manifolds, Geometries and Knots, Topology and Geometry Monographs 5, Geometry and Topology Publ., Coventry, 2002.
- <span id="page-17-12"></span>[7] F. Hirzebruch, Automorphe Formen und der Satz von Riemann-Roch, Symposium Internacional de Topologia algebraica (1956), 129-144.
- <span id="page-17-9"></span><span id="page-17-4"></span>[8] J. E. Humphreys, Linear Algebraic Groups, Springer, 1975.
- [9] F. Kassel, Deformation of proper actions on reductive homogeneous spaces, Math. Ann. 353(2012), 599-632
- <span id="page-17-8"></span><span id="page-17-5"></span>[10] A. Knapp, Lie Groups Beyond an Introduction, Birkhauser, 2002.
- [11] T. Kobayashi, Proper actions on a homogeneous space of reductive type, Math. Ann. 285(1989), 249-263
- <span id="page-17-0"></span>[12] T. Kobayashi, K. Ono, Note on Hirzebruch's proportionality principle, J. Fac. Sci. Univ. Tokyo 37 (1990), 71-87.
- <span id="page-17-1"></span>[13] T. Kobayashi, Discontinuous groups and Clifford-Klein forms of pseudo-Riemannian homogeneous manifolds, Perspectives in Mathematics (1997), 99-165.
- <span id="page-17-2"></span>[14] T. Kobayashi, T. Yoshino Compact Clifford-Klein forms of symmetric spaces revisited, Pure Appl. Math. Quart 1 (2005), 603-684.
- <span id="page-17-10"></span>[15] O. Kowalski, Generalized symmetric spaces, Springer, Berlin, 1980

- <span id="page-18-7"></span><span id="page-18-3"></span>[16] J. Milnor, J. Stasheff, Characteristic Classes, Princeton, 1974.
- [17] Y. Morita, A cohomological obstruction to the existence of compact Clifford-Klein forms, Selecta Math. N. S. (2016), 1-23.
- <span id="page-18-4"></span>[18] Y. Morita, A topological necessary condition for the existence of compact Clifford-Klein forms, J. Differential Geom. 100 (2015), 533-545.
- <span id="page-18-10"></span>[19] T. Okuda, Classification of semisimple symmetric spaces with proper SL(2, R)-actions, J. Differential Geometry 2 (2013), 301-342.
- <span id="page-18-12"></span><span id="page-18-11"></span>[20] B. Tshishiku, Pontryagin classes of locally symmetric manifolds, [arXiv:1404.1115](http://arxiv.org/abs/1404.1115)
- <span id="page-18-5"></span>[21] S. Terzič, Pontryagin classes of generalized symmetric spaces, Mathematical Notes, vol. 69, no. 4 (2001), 559-566.
- <span id="page-18-0"></span>[22] N. Tholozan, Volume and non-existence of compact Clifford-Klein forms, arXiv: 1511.09448
- [23] D. Witte Morris, Superrigid subgroups and syndetic hulls, in: Rigidity in Dynamics and Geometry (M. Burger, A. Iozzi, Eds.), Spinger, 2000.
- <span id="page-18-8"></span><span id="page-18-6"></span>[24] D. Witte Morris, Introduction to Arithmetic Groups, Deductive Press, 2015.
- <span id="page-18-1"></span>[25] D. Witte Morris, Tesselations of solvmanifolds, Trans. Amer. Math. Soc. 350 (1998), 3767-3796.
- [26] J. Wolf and A. Gray, Homogeneous spaces defined by Lie group automorphisms I, J. Differential Geom. 2(1968), 77-114
- <span id="page-18-2"></span>[27] J. Wolf and A. Gray, Homogeneous spaces defined by Lie group automorphisms II, J. Differential Geom. 2(1968), 78-159
- <span id="page-18-9"></span>[28] E. Vinberg, A. Onishchik, O. Shvartsman, Discrete subgroups of Lie groups, Itogi Nauki 21, Moscow 1988 (in Russian).