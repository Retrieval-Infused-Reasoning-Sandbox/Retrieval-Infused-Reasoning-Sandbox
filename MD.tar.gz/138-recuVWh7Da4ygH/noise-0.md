# <span id="page-0-2"></span>**CANONICAL INTEGRAL MODELS OF SHIMURA VARIETIES OF ABELIAN TYPE**

#### PATRICK DANIELS AND ALEX YOUCIS

Abstract. We prove a conjecture of Pappas and Rapoport for all Shimura varieties of abelian type with parahoric level structure when *p >* 3 by showing that the Kisin– Pappas–Zhou integral models of Shimura varieties of abelian type are canonical. In particular, this shows that these models of are independent of the choices made during their construction, and that they satisfy functoriality with respect to morphisms of Shimura data.

### Contents

| 1.<br>Introduction                                            |                                               | 1  |
|---------------------------------------------------------------|-----------------------------------------------|----|
| 2.<br>Preliminaries                                           |                                               | 5  |
| 2.1.                                                          | Some basic Bruhat–Tits theory                 | 5  |
| 2.2.                                                          | Fiber products of groups                      | 9  |
| 3.<br>Integral models of Shimura varieties at parahoric level |                                               | 13 |
| 3.1.                                                          | Existence of models and their properties      | 13 |
| 3.2.                                                          | A<br>E<br>The<br>-group and the<br>-group     | 17 |
| 3.3.                                                          | Construction of Kisin–Pappas–Zhou models      | 21 |
| 3.4.                                                          | Some properties and functoriality results     | 25 |
| 4.<br>The Pappas–Rapoport conjecture                          |                                               | 31 |
| 4.1.                                                          | The Pappas–Rapoport conjecture                | 31 |
| 4.2.                                                          | Statement of the main result and applications | 34 |
| 5.<br>The proof of the main result                            |                                               | 35 |
| 5.1.                                                          | An auxiliary Kisin–Pappas–Zhou model          | 36 |
| 5.2.                                                          | c<br>Construction of the<br>-shtuka<br>G      | 39 |
| 5.3.                                                          | The completion of the proof                   | 44 |
| References                                                    |                                               | 46 |

## 1 Introduction

<span id="page-0-0"></span>In [\[PR21\]](#page-47-0), Pappas and Rapoport conjecture the existence of "canonical" integral models with parahoric level structure and establish this conjecture in most cases of Hodge type. In this work, we prove the conjecture of Pappas and Rapoport for (almost all) Shimura varieties of abelian type. In particular, we prove the following theorem.

<span id="page-0-1"></span>**Theorem A** (See Theorem [4.10\)](#page-33-1)**.** *Let p >* 3*. Then the Pappas–Rapoport conjecture holds for Shimura varieties of abelian type with parahoric level structure at p.*

<span id="page-1-0"></span>Let us begin to contextualize this result. Shimura varieties are algebro-geometric objects which sit at the intersection of number theory and representation theory. They take the form of a projective system  $\{\operatorname{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}}$ , where  $\mathbf{G}$  is a reductive group over  $\mathbb{Q}$ ,  $\mathbf{X}$  is some auxiliary Hodge-theoretic datum, and  $\mathsf{K} \subseteq \mathbf{G}(\mathbb{A}_f)$  ranges over (neat) compact open subgroups. Shimura varieties have been inextricably linked with the Langlands program from its inception, as the cohomology of  $\{\operatorname{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}}$  ought to realize the global Langlands conjecture for  $\mathbf{G}$  (see e.g.,  $[\mathrm{Kot90}]$ ). Central to this cohomological understanding of the Langlands program is a conjecture which posits a "motivic decomposition" of the  $\bar{\mathbb{F}}_p$ -points of certain "canonical" integral models  $\{\mathscr{S}_{\mathsf{K}}\}_{\mathsf{K}}$  of  $\{\operatorname{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}}$  (see  $[\mathrm{LR87}]$ ). It is then not surprising that the construction of such natural integral models of Shimura varieties has prominently featured in many of the advances in the Langlands program.

Constructing such canonical integral models, and even characterizing what constitutes a "canonical" integral model, is quite difficult. Despite their importance, Shimura varieties in general remain fairly inexplicit in their definition. The variety  $\operatorname{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})$  ought to parameterize  $\mathbf{G}^c$ -motives M of type  $\mathbf{X}$  with K-level structure on the étale realization of M (e.g., see [Mil13]). Here  $\mathbf{G}^c$  is a certain quotient of  $\mathbf{G}$ , which agrees with  $\mathbf{G}$  in the Hodge-type case, but differs from  $\mathbf{G}$  in some abelian-type cases. While technical in nature, consideration of  $\mathbf{G}^c$  is crucial for such a conjectural motivic interpretation. Unfortunately, such a motivic description is currently out of reach, and instead  $\operatorname{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})$  is constructed from various abstract algebro-geometric existence results, which are not amenable to the study of integral models.

Despite this, Pappas and Rapoport in [PR21] (building off previous work of Pappas in [Pap22]) made significant headway in a definition of such conjectural canonical integral models when  $K = K_p K^p$  where  $K_p = \mathcal{G}(\mathbb{Z}_p)$  is a parahoric subgroup of  $\mathbf{G}(\mathbb{Q}_p)$ . This parahoricity-at-p condition may be thought of as representing the situation where relatively little level structure is imposed at p.

To explicate their work, let E be the completion of the reflex field of  $(\mathbf{G}, \mathbf{X})$  at a place v lying over p. Pappas and Rapoport call a system  $\{\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^p}$  of  $\mathscr{O}_E$ -models of  $\{\mathrm{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G}, \mathbf{X})_E\}_{\mathsf{K}^p}$  canonical if

- (i) the transition maps between the varying levels are finite étale,
- (ii) if R is a characteristic (0,p) discrete valuation ring over  $\mathcal{O}_E$  then

$$\left(\varprojlim_{\mathsf{K}^p} \mathsf{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})\right) (R[1/p]) = \left(\varprojlim_{\mathsf{K}^p} \mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})\right) (R),$$

- (iii) there exists a  $\mathcal{G}^c$ -shtuka on  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$  modeling the étale realization functor on  $\mathrm{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_E$ ,
- (iv) and for every  $\bar{\mathbb{F}}_p$ -point x of  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$ , there is an isomorphism

$$\Theta_x: \left(\mathcal{M}_{\mathcal{G}^c, b_x, \mu_h^c}^{\text{int}}\right)_{/x_0}^{\wedge} \xrightarrow{\sim} \left(\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G}, \mathbf{X})_{/x}^{\wedge}\right)^{\Diamond}, \tag{1.1}$$

such that  $\Theta_x^*(\mathscr{P}_{\mathsf{K}}) = \mathscr{P}^{\mathrm{univ}}$ .

Here the étale realization is a certain  $\mathcal{G}^c(\mathbb{Z}_p)$ -local system on  $\operatorname{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$  which should be thought of as the étale realization of the "universal motive" on  $\operatorname{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$ , but whose definition is unconditional on such a motivic interpretation. The group  $\mathcal{G}^c$  is a parahoric  $\mathbb{Z}_p$ -model for  $\mathbf{G}^c$  which is determined from  $\mathcal{G}$  using Bruhat–Tits theory. Furthermore, when we speak of shtukas here we mean in the sense of [PR21], and  $\mathscr{P}_{\mathsf{K}^p}$  modeling the étale <span id="page-2-2"></span>realization is meant in terms of the construction in [PR21, §2.6]. Finally,  $(\mathcal{M}_{G^c,b_x,\mu_h^c}^{\text{int}})_{/x_0}^{\wedge}$  is the completion of the integral local Shimura variety in the sense of [SW20, Chapter 25] with its universal shtuka  $\mathscr{P}^{\text{univ}}$ . We refer the reader to §4.1 for the definition of  $b_x$  and  $x_0$ , but mention that  $\mu_h^c$  is the geometric conjugacy class of cocharacters of  $G^c$  induced by the hodge cocharacter  $\mu_h$  of G, where we are writing  $G = \mathbf{G}_{\mathbb{Q}_p}$  and  $G^c = \mathbf{G}_{\mathbb{Q}_p}^c$ .

To help process this definition, note that, given the motivational moduli description of  $\operatorname{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$ , it is reasonable to expect that  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$  should be a moduli space of  $\mathscr{G}^c$ -motives. One can view conditions (iii) and (iv) as saying that  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$  possesses a shtuka, which should be the "shtuka realization" of the universal  $\mathscr{G}^c$ -motive, which, while not provably universal, is universal everywhere formally locally. Furthermore, condition (i) is natural, and condition (ii) is a technical condition ensuring that the members of the system  $\{\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  have sufficiently large special fibers.

Pappas and Rapoport prove that canonical integral models are unique if they exist, hence they do provide a good notion of models at parahoric level. Constructing such models is difficult though, and seems out of reach for general Shimura varieties with current methods. That said, when  $(\mathbf{G}, \mathbf{X})$  is of so-called "abelian type", the situation is much improved. Shimura varieties of abelian type may be thought of intuitively as moduli spaces of abelian motives with extra structure, but this again largely motivational (although see [Mil13, Theorem 11.16] for a partial justification of this claim).

Building off the work of Kisin (and others), Kisin–Pappas and Kisin–Zhou have constructed integral models for Shimura varieties of abelian type at parahoric level<sup>1</sup>. These models have proven to be quite useful in applications (e.g., see [KZ21]), but they have not yet been well-studied. For instance, there is no a priori functoriality for these models, and it is not even clear that the models are independent of the various ancillary choices made in their construction. Our main theorem clarifies these points.

**Theorem B** (see Theorem 4.10). Kisin–Pappas–Zhou models are canonical.

<span id="page-2-1"></span>One of the most pleasing consequences of this result is the following.

Corollary C (See Corollary 4.12 and Theorem 4.14). Kisin-Pappas-Zhou models are independent of all choices, and are functorial in the triple  $(G, X, \mathcal{G})$ .

We expect that our main result will have applications beyond this functoriality. For example, in [DvHKZ24a], it is shown that Kisin–Pappas–Zhou models of Hodge type admit a fiber product decomposition

$$\mathscr{S}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})^{\diamond} \longrightarrow \mathscr{G}\text{-}\mathbf{Sht}_{\mu_h}$$

$$\downarrow \qquad \qquad \downarrow$$

$$\mathrm{Igs}_{\mathsf{K}}(\mathbf{G}, \mathbf{X}) \longrightarrow \mathrm{Bun}_G$$

at the level of v-sheaves. Here  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})^{\diamond}$  denotes the v-sheaf associated to the p-adic completion of  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$ ,  $\mathcal{G}\text{-}\mathbf{Sht}_{\mu_h}$  is the moduli v-stack of  $\mathcal{G}$ -shtukas bounded by  $\mu_h$ , Bun $_G$  is the stack of G-bundles on the Fargues-Fontaine curve, and Igs $_{\mathsf{K}}$  is the Igusa stack defined in [DvHKZ24a], extending work of Zhang [Zha23] in the PEL-type case. Such a decomposition provides a crucial ingredient for the proof of torsion vanishing results for

<span id="page-2-0"></span><sup>&</sup>lt;sup>1</sup>The construction of the Kisin–Pappas–Zhou models requires some minor additional assumptions when p is 3, see Remark 3.9

<span id="page-3-1"></span>the cohomology of Shimura varieties, see [HL23] and [DvHKZ24a]. Our results produce a map of v-sheaves  $\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})^{\diamond} \to \mathscr{G}^c$ -Sht $_{\mu_h^c}$  for all Kisin–Pappas–Zhou models, and we expect that with this it will be possible to extend the results of [Zha23] and [DvHKZ24a] to the abelian-type case.

Let us close by mentioning a few ideas in the proof of Theorem 4.10. A useful heuristic for Shimura data of abelian type is that they are "spanned" by two (largely orthogonal) extremes: Shimura data of Hodge type and Shimura data of toral type. While a useful guiding principle, it requires some care to put this idea into practice. The main ingredient in our proof is the development of a precise formalism for realizing this heuristic. We do this by extending ideas of Lovering (see [Lov17a]) from the setting of Kisin's canonical integral models at hyperspecial level to the setting of arbitrary Kisin–Pappas–Zhou models. We are then able to prove Theorem A by reducing to the Hodge-type case (established in [PR21] and [DvHKZ24b], see Remark 4.7) and toral-type case (established in [Dan22]). We expect these methods to have applications more generally.

<span id="page-3-0"></span>Remark 1.1. We would like to direct the reader's attention to [vHS24]. In the process of this work, van Hoften and Sempliner have occasion to prove a modified version of Theorem A. Namely, they establish that Kisin–Pappas–Zhou models are "canonical" in an appropriate sense where one replaces  $\mathcal{G}^c$  with the more coarse quotient  $\mathcal{G}^{ad}$ . Their proof avoids much of the most subtle group theory used in proving Theorem A, but it is still sufficient to establish Corollary C (see [vHS24]). That said, the  $\mathcal{G}^{ad}$ -version of Theorem A is insufficient for many "motivic" applications, such as extending the results of [DvHKZ24a] to the abelian-type case.

Acknowledgements. The authors would like to thank David Schwein, Gopal Prasad, Pol van Hoften, and Bogdan Zavalyov for several useful conversations. In addition, we would like to thank Pol van Hoften for pointing several subtle points in an earlier draft of this article. Part of this work was conducted during a visit to the Hausdorff Research Institute for Mathematics, funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany's Excellence Strategy – EXC-2047/1 – 390685813, and the authors thank the Hausdorff Institute for their hospitality. During a portion of this work, the second author was supported as a JSPS fellow by a KAKENHI Grant-in-aid (grant number 22F22323).

#### Notation and conventions.

- For an S-scheme X, and a morphism of schemes  $T \to S$ , we shorten the notation  $X \times_S T$  to  $X_T$ . When  $T = \operatorname{Spec}(R)$ , we shorten this notation further to  $X_R$ . Similar conventions hold in other geometric categories.
- For a scheme X and subset S, we always consider the Zariski closure  $\overline{S}$  as a reduced subscheme, unless stated otherwise.
- Unless stated otherwise, we use the notation and terminology concerning v-sheaves, Fargues–Fontaine curve, and shtukas as in [PR21, §2]. In particular, when we speak of a shtuka over a  $\mathbb{Z}_p$ -scheme X, we mean a shtuka over the v-sheaf  $X^{\diamondsuit/}$  in the sense of [PR21, Definition 2.3.2].
- We use  $\mathcal{G}$ -Sht( $\mathscr{X}$ ) and  $\mathcal{G}$ -Sht<sub> $\mu$ </sub>( $\mathscr{X}$ ) to denote the groupoid of  $\mathcal{G}$ -shtukas on  $\mathscr{X}$  and groupoid of  $\mathcal{G}$ -sthukas bounded by  $\mu$  on  $\mathscr{X}$ , respectively.
- A reductive group over a field F is always assumed connected.

#### 2 Preliminaries

<span id="page-4-3"></span><span id="page-4-0"></span>We begin by establishing some preliminaries which will be essential for the proofs of the main results. In particular, we review the Bruhat-Tits theory which is necessary for our purposes, and discuss torsors for fiber products of group schemes.

<span id="page-4-1"></span>**2.1** Some basic Bruhat–Tits theory. In this section we review some basic Bruhat–Tits theory. For more in-depth discussion in this direction we suggest the reader to consult [BT84] or [KP23] and the references therein.

Throughout this section we fix a discretely valued field K with perfect residue field k. We denote by  $K^{\mathrm{ur}}$  the maximal unramified extension of K inside of  $K^{\mathrm{sep}}$ , and by  $\Gamma$  the Galois group  $\mathrm{Gal}(K^{\mathrm{ur}}/K)$ . Denote by  $I := \ker(\mathrm{Gal}(K^{\mathrm{sep}}/K) \to \Gamma)$  the inertia group of K.

**Remark 2.1.** As  $K^{ur}$  is another discretely valued field with perfect residue field, we will often apply to  $K^{ur}$  without comment definitions which are initially stated for K.

**2.1.1 The building and its functorialities.** Assume G is a reductive group over K. As in [KP23, Definition 7.6.1] (cf. [KP23, Definition 9.2.8]), associated to G is a building (in the sense of [KP23, Definition 1.5.5])

$$\mathscr{B}(G, K^{\mathrm{ur}}) := \mathscr{B}(G_{K^{\mathrm{ur}}}, K^{\mathrm{ur}}),$$

where the right-hand side is as in [KP23, Definition 7.6.1]. This building comes equipped with an action of  $G(K^{\mathrm{ur}}) \rtimes \Gamma$ . Moreover, the action of  $G(K^{\mathrm{ur}})$  factors through the natural map  $G(K^{\mathrm{ur}}) \to G^{\mathrm{ad}}(K^{\mathrm{ur}})$ .

Additionally, we have a building

$$\mathscr{B}(G,K) := \mathscr{B}(G,K^{\mathrm{ur}})^{\Gamma},$$

which naturally comes equipped with an action of G(K) which factorizes through the map  $G(K) \to G^{\mathrm{ad}}(K)$ . To distinguish these two objects, we call the  $\mathscr{B}(G,K^{\mathrm{ur}})$  the building associated to G over  $K^{\mathrm{ur}}$  and  $\mathscr{B}(G,K)$  the building associated to G over K.

**Remark 2.2.** The building(s) we are using here are more often called the *reduced Bruhat-Tits building(s)*. While there exists a notion of the *extended Bruhat-Tits building(s)*, we will not need these notions here and, in fact, this simpler object is better suited to our purposes. See [KP23] for more details.

Various functorial properties for these buildings have been established in the literature, see [Lan00] and [KP23, §14]. However, in this article we require only two basic functoriality statements.

<span id="page-4-2"></span>The first concerns quotient maps of reductive groups.

**Lemma 2.3** (cf. [KP23, Proposition 14.1.1]). Suppose that  $f: G \to H$  is a faithfully flat map of reductive groups over K. Then, there exists a unique surjective map

$$f_* \colon \mathscr{B}(G, K^{\mathrm{ur}}) \to \mathscr{B}(H, K^{\mathrm{ur}}),$$

which is equivariant for the map  $G(K^{\mathrm{ur}}) \rtimes \Gamma \to H(K^{\mathrm{ur}}) \rtimes \Gamma$ . A similar statement holds for the buildings over K.

For the second statement, we first make the following definition. For a field F, a map  $f: G \to H$  of reductive groups over F is an ad-isomorphism if  $f(Z(G)) \subseteq Z(H)$ , and the induced map  $f^{\text{ad}}: G^{\text{ad}} \to H^{\text{ad}}$  is an isomorphism. We record for later use the following

<span id="page-5-4"></span>proposition, whose proof is an exercise in assembling well-known facts about reductive groups over fields (e.g., see [Mil17]).

<span id="page-5-3"></span>**Proposition 2.4.** Let  $f: G \to H$  be a map of reductive groups over F. Then, the following conditions on f are equivalent:

- (1) f is an ad-isomorphism,
- (2)  $f^{-1}(Z(H)) = Z(G)$ ,
- (3) the induced map  $f: G^{\operatorname{der}} \to H^{\operatorname{der}}$  is a central isogeny.<sup>2</sup>

<span id="page-5-2"></span>The second basic functoriality result is the following.

**Lemma 2.5.** Suppose  $f: G \to H$  is an ad-isomorphism of reductive groups over K. Then f induces a bijection of buildings

$$f_* : \mathscr{B}(G, K^{\mathrm{ur}}) \xrightarrow{\sim} \mathscr{B}(H, K^{\mathrm{ur}}),$$

equivariant for the map  $G(K^{\mathrm{ur}}) \rtimes \Gamma \to H(K^{\mathrm{ur}}) \rtimes \Gamma$ . Moreover, if  $g: H \to L$  is another ad-isomorphism, then  $(g \circ f)_* = g_* \circ f_*$ . A similar statement holds for buildings over K.

*Proof.* As discussed on [KP23, p. 264], there are natural  $\Gamma$ -equivariant bijections

$$\mathscr{B}(G, K^{\mathrm{ur}}) \xrightarrow{\sim} \mathscr{B}(G^{\mathrm{ad}}, K^{\mathrm{ur}}), \qquad \mathscr{B}(H, K^{\mathrm{ur}}) \xrightarrow{\sim} \mathscr{B}(H^{\mathrm{ad}}, K^{\mathrm{ur}}),$$

which are equivariant for the maps  $G(K^{\mathrm{ur}}) \to G^{\mathrm{ad}}(K^{\mathrm{ur}})$  and  $H(K^{\mathrm{ur}}) \to H^{\mathrm{ad}}(K^{\mathrm{ur}})$ , respectively. These, together with the  $\Gamma$ -equivariant bijection  $\mathscr{B}(G^{\mathrm{ad}}, K^{\mathrm{ur}}) \xrightarrow{\sim} \mathscr{B}(H^{\mathrm{ad}}, K^{\mathrm{ur}})$  induced by  $f^{\mathrm{ad}}$ , gives us a  $\Gamma$ -equivariant bijection  $\mathscr{B}(G, K^{\mathrm{ur}}) \to \mathscr{B}(H, K^{\mathrm{ur}})$ . That this is equivariant for the map  $G(K^{\mathrm{ur}}) \to H(K^{\mathrm{ur}})$  is clear from construction as  $G(K^{\mathrm{ur}})$  and  $H(K^{\mathrm{ur}})$  act through their images in  $G^{\mathrm{ad}}(K^{\mathrm{ur}})$  and  $H^{\mathrm{ad}}(K^{\mathrm{ur}})$ , respectively. The proof for the buildings over K follows by passing to the fixed points for  $\Gamma$ .

**2.1.2** Parahoric groups and group schemes. Let G be a reductive group over K. As in [Kot97, §7] (see also [KP23, §11.1]), one may construct a group homomorphism

$$\kappa_G \colon G(K^{\mathrm{ur}}) \to \pi_1(G)_I$$

where  $\pi_1(G)$  denotes the fundamental group of Borovoi (see [Bor98, §1]), a finitely generated abelian group, and the subscript  $(-)_I$  denotes I-coinvariants. We call  $\kappa_G$  the Kottwitz homomorphism associated to G. We let  $\kappa_G \otimes 1$  denote the composition of  $\kappa_G$  with the map  $\pi_1(G)_I \to \pi_1(G)_I \otimes_{\mathbb{Z}} \mathbb{Q}$ .

We denote the kernel of  $\kappa_G$  and  $\kappa_G \otimes 1$  by  $G(K^{\mathrm{ur}})^0$  and  $G(K^{\mathrm{ur}})^1$ , respectively.<sup>3</sup> The Kottwitz homomorphism (and thus the subgroups  $G(K^{\mathrm{ur}})^0$  and  $G(K^{\mathrm{ur}})^1$ ) is functorial in G. More precisely, if  $f: G \to H$  is a map of reductive groups over K, then the diagram

$$G(K^{\mathrm{ur}}) \xrightarrow{\kappa_G} \pi_1(G)_I$$

$$f \downarrow \qquad \qquad \downarrow \pi_1(f)$$

$$H(K^{\mathrm{ur}}) \xrightarrow{\kappa_H} \pi_1(H)_I$$

commutes.

<span id="page-5-1"></span>that these groups coincides with our definition.

We then have the following definition of a parahoric group scheme.

<span id="page-5-0"></span><sup>&</sup>lt;sup>2</sup>Any isogeny is central if it is of degree coprime to the characteristic of F (see [Mil17, Remark 12.39]). <sup>3</sup>The groups  $G(K^{ur})^0$  and  $G(K^{ur})^1$  may be given more concrete definitions. See [KP23, Notation 2.6.15 and Definition 2.6.23] for these definitions, and [KP23, Lemma 11.5.2 and Proposition 11.5.4] for the proofs

<span id="page-6-6"></span>**Definition 2.6.** A group  $\mathcal{O}_K$ -scheme  $\mathcal{G}$  is parahoric if:

- (1)  $G := \mathcal{G}_K$  is a reductive group over K,
- (2)  $\mathcal{G}$  is a smooth affine group  $\mathcal{O}_K$ -scheme with connected fibers,
- (3) there exists a point x in  $\mathscr{B}(G, K^{\mathrm{ur}})$  (equiv.  $\mathscr{B}(G, K)$ ) such that

<span id="page-6-0"></span>
$$\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) = G(K^{\mathrm{ur}})^0 \cap \mathrm{Stab}_{G(K^{\mathrm{ur}})}(x). \tag{2.1}$$

**Remark 2.7.** That this definition agrees with that originally defined in [BT84] is (essentially) the content of [HR08, Proposition 3].

As in [KP23, §9.2.6], associated to any point x of  $\mathcal{B}(G, K)$  is a parahoric group scheme denoted by  $\mathcal{G}_x^{\circ}$ , characterized by Equation (2.1). Moreover, every parahoric group scheme arises in this way. A subgroup of G(K) is called *parahoric* if it is of the form  $\mathcal{G}(\mathcal{O}_K)$  for a parahoric group  $\mathcal{O}_K$ -scheme  $\mathcal{G}$ .

<span id="page-6-5"></span>**2.1.3** Parahoric models of tori and R-smooth tori. Suppose that T is a a torus over K. By Lemma 2.5 it's clear that  $\mathcal{B}(T,K)$  is a singleton, and thus that T has a unique parahoric model which we denote by T. As  $\mathcal{B}(T,K)$  is a singleton,  $T(\mathcal{O}_K)$  is equal to  $T(K)^0$ .

Let  $\mathcal{T}^{\text{lft}}$  be the Néron model of T (e.g., see [KP23, §B.7–B.8] and [BLR90]).

**Proposition 2.8** (see [KP23, §B.7–B.8]). There is a functorial identification  $\mathcal{T} \simeq (\mathcal{T}^{lft})^{\circ}$ .

Fix a finite Galois extension  $K_1$  of K splitting T, and set  $T_1 = \operatorname{Res}_{K_1/K} T_{K_1}$  which admits a natural embedding  $T \to T_1$ .

<span id="page-6-3"></span>**Definition 2.9** ([KZ21, Definition 2.4.3]). The torus T is called R-smooth if its Zariski closure in  $\mathcal{T}_1^{\text{lft}}$  is a smooth group  $\mathcal{O}_K$ -scheme.<sup>4</sup>

Consider now a reductive group G over K. As  $G_{K^{ur}}$  is quasi-split by Steinberg's theorem (see [Ste65, Theorem 1.9]), there is a unique  $G(K^{ur})$ -conjugacy class of maximally split maximal tori in  $G_{K^{ur}}$  which are precisely the centralizers of maximal split tori (see [Bor91, §20]).

<span id="page-6-2"></span>**Definition 2.10.** We say that a reductive K-group G is R-smooth if one (equivalently any) maximally split maximal torus of  $G_{K^{ur}}$  is R-smooth.

As the formation of Néron models commutes with unramified base change, Definition 2.10 agrees with that of Definition 2.9 when G is a torus.

<span id="page-6-4"></span>**2.1.4** Abelianization of parahoric group schemes. Suppose that G is a reductive group over  $\mathcal{O}_K$ , and consider the short exact sequence of reductive groups

$$1 \to G^{\operatorname{der}} \xrightarrow{i} G \xrightarrow{f} G^{\operatorname{ab}} \to 1.$$

By Lemma 2.3 and Lemma 2.5 we obtain maps of buildings

$$i_* \colon \mathscr{B}(G^{\operatorname{der}},K) \xrightarrow{\sim} \mathscr{B}(G,K), \qquad f_* \colon \mathscr{B}(G,K) \to \mathscr{B}(G^{\operatorname{ab}},K),$$

where the first map is a bijection and the second is surjective, and the maps are equivariant for  $G^{\text{der}}(K) \to G(K)$  and  $G(K) \to G^{\text{ab}}(K)$ , respectively. Similar statements hold for the buildings over  $K^{\text{ur}}$ .

<span id="page-6-1"></span><sup>&</sup>lt;sup>4</sup>As in [BT84, §4.4.8], one may show that the definition of being R-smooth does not depend on the choice of  $K_1$ .

<span id="page-7-4"></span>Let us fix a point y of  $\mathcal{B}(G,K)$  and set  $x=i_*^{-1}(y)$  and  $z=f_*(z)$ . By the functoriality of the Kottwitz homomorphism and the equivariant properties of these maps we see by [KP23, Corollary 2.10.10] that i and f extend to maps  $i: \mathcal{G}_x^{\circ} \to \mathcal{G}_y^{\circ}$  and  $f: \mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ}$ .

<span id="page-7-1"></span>**Proposition 2.11.** If  $G^{\text{der}}$  is R-smooth, then we have a short exact sequence

$$1 \to \mathcal{G}_x^{\circ} \to \mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ} \to 1$$

of group  $\mathcal{O}_K$ -schemes.

*Proof.* First observe that by the setup, we have a diagram

$$\mathcal{G}_x^{\circ} \to \mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ}$$
.

We first claim that  $\mathcal{G}_y^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}}) \to \mathcal{G}_z^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}})$  is surjective. Let T be a maximally split maximal torus in  $G_{K^{\mathrm{ur}}}$  as in [KP23, §8.3.6]. Then as in loc. cit. there exists a map  $\mathcal{T}(\mathcal{O}_{K^{\mathrm{ur}}}) \to \mathcal{G}_y^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}})$ , thus it suffices to show that  $\mathcal{T}(\mathcal{O}_{K^{\mathrm{ur}}}) \to \mathcal{G}_z^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}})$  is surjective. That said, observe that  $\ker(T \to G^{\mathrm{ab}}) = T \cap G^{\mathrm{der}}$  is a torus and therefore, by [KP23, Lemma 2.5.20] the map  $T(K^{\mathrm{ur}})^0 \to G^{\mathrm{ab}}(K^{\mathrm{ur}})^0$  is surjective, so the claim follows.

We now prove that  $f: \mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ}$  is faithfully flat. To see that f is surjective, we observe that f is surjective over K, being the map  $G \to G^{\mathrm{ab}}$ . Thus, it suffices to show that  $f_{k^{\mathrm{sep}}}$  contains every point of  $\mathcal{G}_z^{\circ}(k^{\mathrm{sep}})$  in its image. As  $\mathcal{G}_z^{\circ}$  is smooth, we know that  $\mathcal{G}_z^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}}) \to \mathcal{G}_z^{\circ}(k^{\mathrm{sep}})$  is surjective (e.g., see [Gro67, Thèoréme 18.5.17]), and, since  $\mathcal{G}_y^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}}) \to \mathcal{G}_z^{\circ}(\mathcal{O}_{K^{\mathrm{ur}}})$  is surjective, the claim follows. To show that f is flat, we may, by the critére de platitude par fibres (see [Gro66, Thèormé 11.3.10]), show instead that  $f_K$  and  $f_k$  are flat. But  $\mathcal{G}_z^{\circ} \to \mathrm{Spec}(\mathcal{O}_K)$  is smooth (and so  $(\mathcal{G}_z^{\circ})_K$  and  $(\mathcal{G}_z^{\circ})_k$  are reduced), so this follows from [Mil17, Theorem 3.34].

Finally, since  $G^{\text{der}}$  is R-smooth, it follows from [KZ21, Proposition 2.4.9] that the map  $\mathcal{G}_x^{\circ} \to \mathcal{G}_y^{\circ}$  is a closed immersion. Moreover, as  $\mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ}$  is flat, the group  $\mathcal{O}_K$ -scheme  $\ker(\mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ})$  is flat. So, to show that the closed immersion  $\mathcal{G}_x^{\circ} \to \mathcal{G}_y^{\circ}$  identifies  $\mathcal{G}_x^{\circ}$  with  $\ker(\mathcal{G}_y^{\circ} \to \mathcal{G}_z^{\circ})$  it suffices to check this claim on the generic fiber, where it is clear.

In practice, if we have fixed a parahoric model  $\mathcal{G}$  of G, then we write the unique parahoric model of  $G^{ab}$  by  $\mathcal{G}^{ab}$ . Given Proposition 2.11 this notational abuse is not too severe. Similarly, we denote the associated parahoric model of  $G^{der}$  by  $\mathcal{G}^{der}$ .

<span id="page-7-2"></span>**2.1.5** Parahoric group schemes and central quotients. Let  $f: G \to G'$  be a faithfully flat map such that  $Z := \ker(f)$  is a torus over K. Let x be a point of  $\mathscr{B}(G, K)$  and x' its image under the map the map  $f_*$  from Lemma 2.3. Let us write  $\mathcal{G} = \mathcal{G}_x^{\circ}$  and  $\mathcal{G}' = \mathcal{G}_{x'}^{\circ}$ 

As  $f_*$  is equivariant for the map  $G(K^{ur}) \to G'(K^{ur})$  and the Kottwitz homomorphism is functorial, we deduce that f maps  $\mathcal{G}(\mathcal{O}_{K^{ur}})$  into  $\mathcal{G}'(\mathcal{O}_{K^{ur}})$ . Thus, by [KP23, Corollary 2.10.10] f uniquely lifts to a map  $\mathcal{G} \to \mathcal{G}'$ . When Z is R-smooth, one can say more.

<span id="page-7-3"></span>**Proposition 2.12** ([KZ21, Proposition 2.4.14]). Suppose that Z is an R-smooth torus. Then, there exists a short exact sequence of group  $\mathcal{O}_K$ -schemes

$$1 \to \mathcal{Z} \to \mathcal{G} \xrightarrow{f} \mathcal{G}' \to 1$$
,

<span id="page-7-0"></span><sup>&</sup>lt;sup>5</sup>Suppose that X is a flat  $\mathcal{O}_K$ -scheme and  $Z_i \subseteq X$  are  $\mathcal{O}_K$ -flat closed subschemes such that  $(Z_1)_K = (Z_2)_K$ , then  $Z_1 = Z_2$ . Without loss of generality,  $X = \operatorname{Spec}(R)$  for some  $\mathcal{O}_K$ -algebra R. Write  $I_i$  for the ideal defining  $Z_i$ . Let x belong to  $I_1$ . Then  $(Z_1)_K = (Z_2)_K$ , so x belongs to  $(I_2)_K$  and thus there exists some  $m \geqslant 0$  such that  $\pi^m x$  belongs to  $I_2$ , with  $\pi$  a uniformizer of K. So,  $\pi^m x$  is zero in  $R/I_2$  which, as  $R/I_2$  is  $\mathcal{O}_K$ -flat, implies that x is zero in  $R/I_2$ , and so belongs to  $I_2$ . So,  $I_1 \subseteq I_2$ . By symmetry,  $I_2 \subseteq I_1$ .

<span id="page-8-5"></span>where Z is the Zariski closure of Z in G. Moreover, Z is a smooth group  $\mathcal{O}_K$ -scheme.

**2.1.6** Parahoric group schemes and ad-isomorphisms. Suppose that  $i: G \to H$  is an injective ad-isomorphism of reductive groups over K. Suppose that  $\mathcal{H}$  is a parahoric model of H, and y is a point of  $\mathcal{B}(H,k)$  such that  $\mathcal{H}$  is isomorphic to  $\mathcal{H}_y^{\circ}$ . By Lemma 2.5 there is a unique point x of  $\mathcal{B}(G,K)$  such that  $y=i_*(x)$ .

<span id="page-8-4"></span>The following basic proposition provides a recognition principle for  $\mathcal{G}_x^{\circ}$ .

**Proposition 2.13.** A model  $\mathcal{G}$  of G is isomorphic to  $\mathcal{G}_x^{\circ}$  if it is a smooth affine group  $\mathcal{O}_K$ -scheme with connected fibers and

<span id="page-8-1"></span>
$$\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) = \mathcal{H}(\mathcal{O}_{K^{\mathrm{ur}}}) \cap G(K^{\mathrm{ur}}). \tag{2.2}$$

Moreover, i extends to a map of  $\mathcal{O}_k$ -group schemes  $\mathcal{G} \to \mathcal{H}$  which is a closed embedding if G is R-smooth.

*Proof.* By the definition of parahoric group schemes, and the definition of  $\mathcal{G}_x^{\circ}$ , it suffices to show that

$$\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) = G(K^{\mathrm{ur}})^{0} \cap \mathrm{Stab}_{G(K^{\mathrm{ur}})}(x). \tag{2.3}$$

Since  $i_*$  defines a bijection  $\mathscr{B}(G, K^{\mathrm{ur}}) \xrightarrow{\sim} \mathscr{B}(H, K^{\mathrm{ur}})$  which is equivariant for the map  $G(K^{\mathrm{ur}}) \to H(K^{\mathrm{ur}})$ , we deduce that

$$\operatorname{Stab}_{G(K^{\operatorname{ur}})}(x) = \operatorname{Stab}_{H(K^{\operatorname{ur}})}(y) \cap G(K^{\operatorname{ur}}). \tag{2.4}$$

The inclusion  $\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) \subseteq \operatorname{Stab}_{G(K^{\mathrm{ur}})}(x)$  then follows immediately from (2.2). Additionally, as  $\mathcal{G}$  is a smooth affine group  $\mathcal{O}_K$ -scheme with connected fibers, it follows from [KP23, Proposition 8.3.15] that  $\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) \subseteq G(K^{\mathrm{ur}})^0$ . Thus,  $\mathcal{G}(\mathcal{O}_{K^{\mathrm{ur}}}) \subseteq G(K^{\mathrm{ur}})^0 \cap \operatorname{Stab}_{G(K^{\mathrm{ur}})}(x)$ .

On the other hand, if g belongs to  $G(K^{ur})^0 \cap \operatorname{Stab}_{G(K^{ur})}(x)$ , then i(g) belongs to  $\mathcal{H}(\mathcal{O}_{K^{ur}})$  by functoriality of the Kottwitz homomorphism along with the identity (2.4). Hence (2.2) implies that g belongs to  $\mathcal{G}(\mathcal{O}_{K^{ur}})$ .

Finally, the fact that i extends to a morphism  $i: \mathcal{G} \to \mathcal{H}$  follows from [KP23, Corollary 2.10.10] by (2.2). That i is a closed embedding if G is R-smooth follows from [KZ21, Proposition 2.4.9], whose proof works under the assumption that i is an ad-isomorphism.

- <span id="page-8-0"></span>**2.2 Fiber products of groups.** In this subsection we aim to collect some facts concerning fiber products of groups, in various contexts, that will be useful below.
- 2.2.1 Smoothness and connectedness of fiber products of group schemes. Fix a connected scheme S and consider a Cartesian diagram of group S-schemes

$$\begin{array}{ccc} \mathcal{D} & \stackrel{p}{\longrightarrow} & \mathcal{A} \\ q \Big\downarrow & & \Big\downarrow f \\ \mathcal{C} & \stackrel{g}{\longrightarrow} & \mathcal{B}. \end{array}$$

<span id="page-8-3"></span>Set  $\mathcal{K}$  to be the group S-scheme  $\ker(f)$ .

**Proposition 2.14.** Suppose that f is faithfully flat and quasi-compact, and that K and C are smooth group S-schemes with connected fibers. Then, D is a smooth group S-scheme with connected fibers.

<span id="page-8-2"></span>

<span id="page-9-1"></span>One may replace all instances of "connected" in the assumptions and conclusion of the above statement by "geometrically connected", "irreducible", or "geometrically irreducible" by standard theory concerning algebraic groups (see [Mil17, Summary 1.36]). We use this observation freely below.

Proof of Proposition 2.14. The morphism  $\mathcal{A} \times_{\mathcal{B}} \mathcal{A} \to \mathcal{K} \times_{S} \mathcal{A}$  given by  $(g,h) \mapsto (gh^{-1},h)$  is an isomorphism. But, as  $\mathcal{K} \to S$  is smooth, thus so is  $\mathcal{K} \times_{S} \mathcal{A} \to \mathcal{A}$ , and thus so is  $\mathcal{A} \times_{\mathcal{B}} \mathcal{A} \to \mathcal{A}$ . As f is faitfully flat and quasi-compact, we deduce by fpqc descent for smoothness (e.g., see [Sta17, Tag 0429]) that f is smooth. By stability of smoothness under base change we deduce that  $g: \mathcal{D} \to \mathcal{C}$  is smooth, and as  $\mathcal{C} \to S$  is smooth thus so is the composition  $\mathcal{D} \to S$ .

To prove that  $\mathcal{D} \to S$  has connected fibers, let s be an element of S and consider the map  $q_s \colon \mathcal{D}_s \to \mathcal{C}_s$ . By assumption we have that  $\mathcal{C}_s$  is connected and  $q_s \colon \mathcal{D}_s \to \mathcal{C}_s$  is surjective. Moreover, by the argument in the previous paragraph we have that  $q_s \colon \mathcal{D}_s \to \mathcal{C}_s$  is smooth, and thus open. On the other hand, as  $\mathcal{K} \to S$  has geometrically connected fibers, the same holds true for f as these fibers are translations of geometric fibers of  $\mathcal{K} \to S$ . Thus, the map  $q_s$  has geometrically connected fibers (see [Sta17, Tag 055E]). Therefore we deduce that  $\mathcal{D}_s$  is connected as desired from the simple fact that if  $f \colon Y \to X$  be an open surjective map of topological spaces with connected fibers and X is connected, then Y is connected.

2.2.2 Some fiber products of parahoric group schemes. Suppose now that, as in §2.1, K is a discretely valued field with perfect residue field. Suppose further that we have a Cartesian diagram of group  $\mathcal{O}_K$ -schemes

$$egin{array}{ccc} \mathcal{D} & \stackrel{p}{\longrightarrow} \mathcal{A} \\ q \Big\downarrow & & \Big\downarrow f \\ \mathcal{C} & \stackrel{g}{\longrightarrow} \mathcal{B}, \end{array}$$

where  $\mathcal{A}$ ,  $\mathcal{B}$ , and  $\mathcal{C}$  are parahoric group  $\mathcal{O}_K$ -schemes. For simplicity we denote the generic fiber of  $\mathcal{A}$ ,  $\mathcal{B}$ ,  $\mathcal{C}$ , and  $\mathcal{D}$ , by A, B, C, and D, respectively.

<span id="page-9-0"></span>**Proposition 2.15.** Suppose that f is faithfully flat and quasi-compact, both B and C are tori, and  $\ker(f)$  is a smooth group  $\mathcal{O}_K$ -scheme with connected fibers. Then,  $\mathcal{D}$  is a parahoric group  $\mathcal{O}_K$ -scheme. Moreover, if  $\mathcal{A} = \mathcal{G}_x^{\circ}$ , then  $\mathcal{D} = \mathcal{G}_{(x,*)}^{\circ}$  under the isomorphism

$$\mathscr{B}(D,K) \to \mathscr{B}(A \times_{\operatorname{Spec}\,(K)} C,K) \simeq \mathscr{B}(A,K) \times \{*\}$$

from Proposition 2.5.

*Proof.* By Proposition 2.14, we know that  $\mathcal{D}$  is a smooth group  $\mathcal{O}_K$ -scheme with connected fibers. Moreover, observe that we have a natural short exact sequence of group  $\mathcal{O}_K$ -schemes

$$1 \to \mathcal{D} \to \mathcal{A} \times_{\operatorname{Spec} \left(\mathcal{O}_K\right)} \mathcal{C} \to \mathcal{B} \to 1,$$

where the map  $\mathcal{A} \times_{\operatorname{Spec}(\mathcal{O}_K)} \mathcal{C} \to \mathcal{B}$  is given by sending (a,c) to  $f(a)g(c)^{-1}$ . This implies that D is a normal subgroup of the reductive group  $A \times_{\operatorname{Spec}(K)} C$  and so reductive (see [Mil17, Corollary 21.53]).

<span id="page-10-1"></span>On the other hand, this exact sequence also implies that  $D \to A \times_{\operatorname{Spec}(K)} C$  induces an isomorphism on adjoint subgroups as B is abelian. Moreover, observe that evidently

$$\mathcal{D}(\mathcal{O}_{K^{\mathrm{ur}}}) = (\mathcal{A}(\mathcal{O}_{K^{\mathrm{ur}}}) \times \mathcal{C}(\mathcal{O}_{K^{\mathrm{ur}}})) \cap D(K^{\mathrm{ur}}).$$

The claim then follows directly from Proposition 2.13.

2.2.3 Torsors for fiber products of groups. We next are interested in understanding the relationship between torsors for a fiber product of groups, and torsors for their constituent groups. The correct generality for this discussion is that of topoi. We follow the notation and conventions concerning torsors and topoi as found in [IKY23, §A.1].

Let us fix a topos  $\mathcal{T}$  with final object \*, and a Cartesian diagram of group objects

$$\begin{array}{ccc}
\mathcal{D} & \xrightarrow{p} & \mathcal{A} \\
q \downarrow & & \downarrow f \\
\mathcal{C} & \xrightarrow{g} & \mathcal{B}.
\end{array}$$

Consider the 2-fiber product of groupoids

$$\mathbf{Tors}(\mathcal{A}) \times_{f_*, \mathbf{Tors}(\mathcal{B}), g_*} \mathbf{Tors}(\mathcal{C}),$$

(e.g., see [Sta17, Tag 02X9]). Observe that there is a natural equivalence of functors

$$\theta_{\text{nat}}$$
:  $f_* \circ p_* \simeq (f \circ p)_* = (g \circ q)_* \simeq g_* \circ q_*$ ,

and thus the triple  $(p_*, q_*, \theta_{\text{nat}})$  determines an object of the 2-fiber product. Thus,

$$\Psi \colon \mathbf{Tors}_{\mathcal{D}}(\mathscr{T}) \to \mathbf{Tors}_{\mathcal{A}}(\mathscr{T}) \times_{f_*, \mathbf{Tors}_{\mathcal{B}}(\mathscr{T}), g_*} \mathbf{Tors}_{\mathcal{C}}(\mathscr{T}), \tag{2.5}$$

given by  $\Psi(\mathcal{P}) = (p_*\mathcal{P}, q_*\mathcal{P}, \theta_{\text{nat}})$  is a morphism of groupoids.

Conversely, suppose that  $(\mathcal{Q}_{\mathcal{A}}, \mathcal{Q}_{\mathcal{C}}, \theta)$  is an object of  $\mathbf{Tors}_{\mathcal{A}}(\mathscr{T}) \times_{f_*, \mathbf{Tors}_{\mathcal{B}}(\mathscr{T}), g_*} \mathbf{Tors}_{\mathcal{C}}(\mathscr{T})$ . Let us observe that we have a natural map

$$Q_A \to f_* Q_A = (\mathcal{B} \times Q_A)/\mathcal{A},$$

induced by the map (e, id):  $\mathcal{Q}_{\mathcal{A}} \to \mathcal{B} \times \mathcal{Q}_{\mathcal{A}}$ , where e denotes the identity section of  $\mathcal{B}$ . We similarly have a map  $\mathcal{Q}_{\mathcal{C}} \to g_* \mathcal{Q}_{\mathcal{C}}$ . Let us define

$$\mathcal{Q}_{\mathcal{A}} imes_{ heta} \mathcal{Q}_{\mathcal{C}} := \lim \left( egin{array}{c} \mathcal{Q}_{\mathcal{A}} \\ \downarrow \\ f_* \mathcal{Q}_{\mathcal{A}} \stackrel{ heta}{\longrightarrow} g_* \mathcal{Q}_{\mathcal{C}} \longleftarrow \mathcal{Q}_{\mathcal{C}} \end{array} 
ight),$$

where this limit is taken in  $\mathscr{T}$ . It is simple to check that there is a unique  $\mathcal{D}$ -action on  $\mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}}$  for which the natural map  $\mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}} \to \mathcal{Q}_{\mathcal{A}} \times \mathcal{Q}_{\mathcal{C}}$  is equivariant for the map  $\mathcal{D} \to \mathcal{A} \times \mathcal{C}$ . This  $\mathcal{D}$ -object of  $\mathscr{T}$  is evidently functorial in the triple  $(\mathcal{Q}_{\mathcal{A}}, \mathcal{Q}_{\mathcal{C}}, \theta)$ .

Note that it is not a priori clear that  $Q_A \times_{\theta} Q_C$  is a  $\mathcal{D}$ -torsor. That said, we do have the following affirmative result in this direction under the assumption that f is an epimorphism.

<span id="page-10-0"></span>**Proposition 2.16.** Suppose that f is an epimorphism. Then, the functor

$$\Phi \colon \mathbf{Tors}_{\mathcal{A}}(\mathscr{T}) \times_{f_*, \mathbf{Tors}_{\mathcal{B}}(\mathscr{T}), q_*} \mathbf{Tors}_{\mathcal{C}}(\mathscr{T}) \to \mathbf{Tors}_{\mathcal{D}}(\mathscr{T})$$

given by  $\Phi(\mathcal{Q}_{\mathcal{A}}, \mathcal{Q}_{\mathcal{C}}, \theta) = \mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}}$ , is a well-defined quasi-inverse to  $\Psi$ . Moreover, the equivalences  $\Psi$  and  $\Phi$  are compatible with pullbacks along a morphism of topoi  $\mathscr{T}' \to \mathscr{T}$ .

<span id="page-11-0"></span>*Proof.* To show that  $\mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}}$  is a  $\mathcal{D}$ -torsor we are free to localize  $\mathscr{T}$ . In particular, we may assume that  $\mathcal{Q}_{\mathcal{C}}$  is trivializable. Choose a trivialization corresponding to an element x of  $\mathcal{Q}_{\mathcal{C}}(*)$ . Consider then the induced element of  $g_*\mathcal{Q}_{\mathcal{C}}(*)$ , which we also denote by x, and the resulting element  $\theta^{-1}(x)$  of  $f_*\mathcal{Q}_{\mathcal{A}}(*)$ . As f is an epimorphism we may, after possibly localizing  $\mathscr{T}$  further, assume that there exists some element y of  $\mathcal{Q}_{\mathcal{A}}(*)$  mapping to  $\theta^{-1}(x)$ . These compatible elements define an isomorphism of diagrams

$$\begin{array}{cccc}
\mathcal{Q}_{\mathcal{A}} & & & \mathcal{A} \\
\downarrow & & \simeq & f \downarrow \\
f_*\mathcal{Q}_{\mathcal{A}} & \xrightarrow{\theta} g_*\mathcal{Q}_{\mathcal{C}} & & \mathcal{B} & \xrightarrow{\mathrm{id}} \mathcal{B} & \xrightarrow{g} \mathcal{C}.
\end{array}$$

As  $\mathcal{A} \times_{\mathrm{id}} \mathcal{C}$  is evidently the trivial  $\mathcal{D}$ -torsor, the claim follows.

To prove that  $\Phi \circ \Psi$  is naturally isomorphic to the identity, it suffices to prove the following claim: for a  $\mathcal{D}$ -torsor  $\mathcal{P}$  the natural map

$$\mathcal{P} \to f_* \mathcal{P} \times g_* \mathcal{P}$$

is equivariant for the map  $\mathcal{D} \to \mathcal{A} \times \mathcal{C}$ , and factorizes uniquely through a  $\mathcal{D}$ -equivariant map  $\mathcal{P} \to f_* \mathcal{P} \times_{\theta} g_* \mathcal{P}$ . But this claim can be checked after localizing on  $\mathscr{T}$ , which reduces us to the trivial case as in the previous paragraph.

To prove that  $\Psi \circ \Phi$  is naturally isomorphic to the identity, let us fix an object  $(\mathcal{Q}_{\mathcal{A}}, \mathcal{Q}_{\mathcal{C}}, \theta)$  of the 2-fiber product. Let us observe that we have a natural projection map

$$Q_{\mathcal{A}} \times_{\theta} Q_{\mathcal{C}} \rightarrow Q_{\mathcal{A}}$$

which is equivariant for the map  $\mathcal{D} \to \mathcal{A}$ . By the adjunction in [Gir71, Chapitre III, Proposition 1.3.6 (iii)] we obtain a unique  $\mathcal{A}$ -equivariant map

$$\alpha \colon f_*(\mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}}) \to \mathcal{Q}_{\mathcal{A}},$$

which is necessarily an isomorphism of A-torsors. Similarly, we obtain an isomorphism

$$\beta \colon g_*(\mathcal{Q}_{\mathcal{A}} \times_{\theta} \mathcal{Q}_{\mathcal{C}}) \to \mathcal{Q}_{\mathcal{C}}.$$

It is then easy to check that  $(\alpha, \beta)$  defines a natural morphism

$$\Psi(\Phi(\mathcal{Q}_A, \mathcal{Q}_C, \theta)) \to (\mathcal{Q}_A, \mathcal{Q}_C, \theta),$$

where the matching of  $\theta_{\text{nat}}$  in the source and  $\theta$  in the target may be checked locally on  $\mathcal{T}$ , from where we may reduce to the trivial case where it is clear. As the 2-fiber product is a groupoid, we deduce that  $(\alpha, \beta)$  is a natural isomorphism.

The final compatibility claim is clear by construction.

**2.2.4** Shtukas for fiber products of groups. We finally record the natural implication of Proposition 2.16 for shtukas over a pre-adic space in the sense of [PR21, §2.3].

To this end, let us fix a fiber product of group  $\mathbb{Z}_p$ -schemes

$$egin{array}{ccc} \mathcal{D} & \stackrel{p}{\longrightarrow} \mathcal{A} \\ q \Big\downarrow & & \Big\downarrow f \\ \mathcal{C} & \stackrel{g}{\longrightarrow} \mathcal{B}, \end{array}$$

where  $\mathcal{A}$ ,  $\mathcal{B}$ , and  $\mathcal{C}$  are smooth group  $\mathbb{Z}_p$ -schemes with connected fibers, f is faithfully flat and quasi-compact, and  $\ker(f)$  is a smooth group  $\mathbb{Z}_p$ -scheme with connected fibers. We then see by Proposition 2.14 that  $\mathcal{D}$  is a smooth group  $\mathbb{Z}_p$ -scheme with connected fibers.

<span id="page-12-3"></span>Further fix a discretely valued algebraic extension E of  $\mathbb{Q}_p$  with residue field  $k_E$ , and fix a pre-adic space  $\mathscr{X}$  over  $\mathcal{O}_E$ . We then have the following result.

<span id="page-12-2"></span>Corollary 2.17. There is an equivalence of categories

$$\mathcal{D}\text{-}\mathbf{Sht}(\mathscr{X}) \xrightarrow{\sim} \mathcal{A}\text{-}\mathbf{Sht}(\mathscr{X}) \times_{f_*,\mathcal{B}\text{-}\mathbf{Sht}(\mathscr{X}),g_*} \mathcal{C}\text{-}\mathbf{Sht}(\mathscr{X}).$$

*Proof.* Fix an morphism  $\alpha \colon S \to \mathscr{X}^{\lozenge/}$ , where S is an object of  $\mathbf{Perf}_{k_E}$ , with corresponding untilt  $S^{\sharp}$  over  $\mathcal{O}_E$ . Then, it immediately by applying Proposition 2.16 to the étale topoi of  $S \times \mathbb{Z}_p$  and  $S \times \mathbb{Z}_p \setminus S^{\sharp}$ , that there are equivalences

$$\mathcal{D}\text{-}\mathbf{Sht}(S) \xrightarrow{\sim} \mathcal{A}\text{-}\mathbf{Sht}(S) \times_{f_*,\mathcal{B}\text{-}\mathbf{Sht}(S),g_*} \mathcal{C}\text{-}\mathbf{Sht}(S).$$

<span id="page-12-0"></span>As this equivalence is 2-functorial in the topos, the claim then follows by letting S vary.  $\Box$ 

3 Integral models of Shimura varieties at parahoric level

In this section we study the Kisin–Pappas–Zhou models of Shimura varieties of abelian type at parahoric level as constructed in [KP18] and [KZ21].

- <span id="page-12-1"></span>3.1 Existence of models and their properties. In this subsection we precisely state the existence of integral models at parahoric level and list some of their properties which are most relevant for our purposes.
- **3.1.1 Shimura varieties.** We begin by recalling some definitions and notation from the theory of Shimura varieties. Let (G, X) be a Shimura datum, meaning that G is a reductive group over  $\mathbb{Q}$ , and X is a  $G(\mathbb{R})$ -conjugacy class of homomorphisms

$$h: \mathbb{S} \to \mathbf{G}_{\mathbb{R}},$$

(where  $\mathbb{S} = \operatorname{Res}_{\mathbb{C}/\mathbb{R}} \mathbb{G}_{m/\mathbb{C}}$  is the Deligne torus), satisfying the axioms (SV1)-(SV3) in [Mil05, Definition 5.5]. Associated to **X** is a unique conjugacy class  $\mu_h$  of coharacters  $\mathbb{G}_{m,\mathbb{C}} \to \mathbf{G}_{\mathbb{C}}$  (see [Mil05, p. 344]). We denote the field of definition of  $\mu_h$  by **E**, and call it the reflex field of (**G**, **X**) (see [Mil05, Definition 12.2]).

We often fix a place v of  $\mathbf{E}$  dividing p, and write E for the completion  $\mathbf{E}_v$ . Using [Kot84, Lemma 1.1.3],  $\mu_h$  gives rise to a unique conjugacy class of cocharacters  $\mathbb{G}_{m,\overline{E}} \to G_{\overline{E}}$ , which we also denote by  $\mu_h$ . One may check that this conjugacy class has field of definition E, and so we call this the local reflex field.

For any neat compact open subgroup  $K \subseteq \mathbf{G}(\mathbb{A}_f)$  (see [Mil05, p. 288]), we attach to  $(\mathbf{G}, \mathbf{X})$  and K the Shimura variety  $\mathrm{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})$ , which is a quasi-projective variety over  $\mathbb{C}$ , whose  $\mathbb{C}$ -points are given by the equality

$$\operatorname{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})(\mathbb{C}) = \mathbf{G}(\mathbb{Q}) \backslash \mathbf{X} \times \mathbf{G}(\mathbb{A}_f) / \mathsf{K}.$$

We write an element of this double quotient as  $[x, g]_{K}$ . As in [Del79] (cf. [Moo98]),  $\operatorname{Sh}_{K}(\mathbf{G}, \mathbf{X})$  admits a canonical model over the reflex field  $\mathbf{E}$ . Hereafter we will use  $\operatorname{Sh}_{K}(\mathbf{G}, \mathbf{X})$  to denote the canonical model over  $\mathbf{E}$ .

For a containment  $K \subseteq K'$  of neat compact open subgroups of  $\mathbf{G}(\mathbb{A}_f)$  and g in  $\mathbf{G}(\mathbb{A}_f)$  such that  $g^{-1}Kg \subseteq K'$ , there is a unique finite étale morphism of **E**-schemes

$$t_{\mathsf{K},\mathsf{K}'}(g): \mathrm{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X}) \to \mathrm{Sh}_{\mathsf{K}'}(\mathbf{G},\mathbf{X}),$$

which is given on C-points by the identity

$$t_{\mathsf{K},\mathsf{K}'}(g)[x,g']_{\mathsf{K}} = [x,g'g]_{\mathsf{K}'}.$$

<span id="page-13-1"></span>We write  $\pi_{\mathsf{K},\mathsf{K}'}$  for  $t_{\mathsf{K},\mathsf{K}'}(\mathrm{id})$ , and  $[g]_{\mathsf{K}}$  for  $t_{\mathsf{K},q^{-1}\mathsf{K}q}(g)$ .

The morphisms  $\pi_{K,K'}$  form a projective system  $\{\operatorname{Sh}_K(\mathbf{G},\mathbf{X})\}_K$  with finite étale transition morphisms. We define

<span id="page-13-0"></span>
$$\operatorname{Sh}(\mathbf{G}, \mathbf{X}) := \varprojlim_{\mathsf{K}} \operatorname{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X}),$$
 (3.1)

where the limit is taken over all neat compact open subgroups K of  $\mathbf{G}(\mathbb{A}_f)$ . Since each  $\pi_{K,K'}$  is affine, the limit in (3.1) exists as an **E**-scheme (see [Sta17, Tag 01YX]). The morphisms  $[g]_K$  endow  $\mathrm{Sh}(\mathbf{G},\mathbf{X})$  with a continuous action of  $\mathbf{G}(\mathbb{A}_f)$  in the sense of [Del79, 2.7.1].

We will often fix a prime p and consider neat compact open subgroups  $K = K_p K^p$  with  $K_p \subseteq \mathbf{G}(\mathbb{Q}_p)$  and  $K^p \subseteq \mathbf{G}(\mathbb{A}_f^p)$ . We define

$$\mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X}) \coloneqq \varprojlim_{\mathsf{K}^p} \mathrm{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X}),$$

where  $K^p$  varies over neat compact open subgroups of  $\mathbf{G}(\mathbb{A}_f^p)$ . As in the case of  $\mathrm{Sh}(\mathbf{G},\mathbf{X})$ , we see that  $\mathrm{Sh}_{K_p}(\mathbf{G},\mathbf{X})$  is a scheme over  $\mathbf{E}$  with a continuous action of  $\mathbf{G}(\mathbb{A}_f^p)$ .

**Remark 3.1.** When several Shimura data are simultaneously under consideration, we will differentiate them with numerical subscripts (e.g.,  $(\mathbf{G}_1, \mathbf{X}_1)$ ) and use the same numerical subscripts to denote the objects defined above (or below) for this Shimura datum (e.g.,  $\mathrm{Sh}_{K_p,1}K_1^p(\mathbf{G}_1,\mathbf{X}_1)$ ).

A morphism of Shimura data  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1) \to (\mathbf{G}, \mathbf{X})$  is a morphism of group  $\mathbb{Q}$ -schemes  $\alpha \colon \mathbf{G}_1 \to \mathbf{G}$  with the property that  $\alpha_{\mathbb{R}} \circ h_1$  belongs to  $\mathbf{X}$  for  $h_1$  in  $\mathbf{X}_1$ . We say that  $\alpha$  is an embedding if  $\mathbf{G}_1 \to \mathbf{G}$  is a closed embedding. From [Del79, §5], for a morphism of Shimura data  $\alpha$ , one has that  $\mathbf{E} \subseteq \mathbf{E}_1$  and there is a unique morphism  $\mathrm{Sh}(\mathbf{G}_1, \mathbf{X}_1) \to \mathrm{Sh}(\mathbf{G}, \mathbf{X})_{\mathbf{E}_1}$  of  $\mathbf{E}_1$ -schemes equivariant for the map  $\alpha \colon \mathbf{G}_1(\mathbb{A}_f) \to \mathbf{G}(\mathbb{A}_f)$  and such that if  $\alpha(\mathsf{K}_1) \subseteq \mathsf{K}$  then the induced map on the quotients  $\alpha_{\mathsf{K}_1,\mathsf{K}} \colon \mathrm{Sh}_{\mathsf{K}_1}(\mathbf{G}, \mathbf{X}) \to \mathrm{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})_{E_1}$  is given on  $\mathbb{C}$ -points by

$$\alpha_{K_1,K}([x_1,g_1]_{K_1}) = [\alpha \circ x_1,\alpha(g_1)]_{K}.$$

We say that  $\alpha$  is an ad-isomorphism if  $\alpha \colon \mathbf{G}_1 \to \mathbf{G}$  is an ad-isomorphism and moreover, that  $\alpha \colon (\mathbf{G}_1^{\mathrm{ad}}, \mathbf{X}_1^{\mathrm{ad}}) \to (\mathbf{G}^{\mathrm{ad}}, \mathbf{X}^{\mathrm{ad}})$  is an isomorphism.

**3.1.2 Parahoric Shimura data.** We say that a triple  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a parahoric Shimura datum if  $(\mathbf{G}, \mathbf{X})$  is a Shimura datum, and  $\mathcal{G}$  is a parahoric model of  $G := \mathbf{G}_{\mathbb{Q}_p}$ . By a morphism  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1) \to (\mathbf{G}, \mathbf{X}, \mathcal{G})$  of parahoric Shimura data we mean a morphism  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1) \to (\mathbf{G}, \mathbf{X})$  of Shimura data together with a specified model  $\mathcal{G}_1 \to \mathcal{G}$  of  $G_1 \to G$ , which we also denote  $\alpha$ . By [KP23, Corollary 2.10.10], such an  $\alpha$  is unique, and it exists if and only if  $\alpha \colon G(\mathbb{Q}_p) \to G_1(\mathbb{Q}_p)$  maps  $\mathcal{G}_1(\mathbb{Z}_p)$  into  $\mathcal{G}(\mathbb{Z}_p)$ . We say that  $\alpha$  is an embedding or an ad-isomorphism if  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1) \to (\mathbf{G}, \mathbf{X})$  is.

Given a parahoric Shimura datum  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  we often use the following shorthand

$$\mathsf{K}_p := \mathcal{G}(\mathbb{Z}_p).$$

Choosing a point x of  $\mathscr{B}(G,\mathbb{Q}_p)$  such that  $\mathcal{G}=\mathcal{G}_x^{\circ}$ , we write

$$\widetilde{\mathsf{K}}_p := G(\mathbb{Q}_p^{\mathrm{ur}})^1 \cap \mathrm{Stab}_{G(\mathbb{Q}_p)}(x),$$

which is a supergroup of  $K_p$  of finite index.

The following lemma will be important for later constructions. Let us denote by  $\mathbf{E}^p$  the maximal extension of  $\mathbf{E}$  unramified at places dividing p.

<span id="page-14-4"></span><span id="page-14-2"></span>Lemma 3.2 ([KP18, Corollary 4.3.9]). The natural map

$$\pi_0(\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\overline{\mathbf{E}}}) \to \pi_0(\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathbf{E}^p})$$

is a bijection.

In other words, this result says that the action of  $\operatorname{Gal}(\overline{\mathbf{E}}/\mathbf{E})$  on  $\pi_0(\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})_{\overline{\mathbf{E}}})$  factorizes through  $\operatorname{Gal}(\mathbf{E}^p/\mathbf{E})$  (cf. [Sta17, Tag 038D]).

**3.1.3 Some conditions on a Shimura datum.** The construction of Kisin–Pappas–Zhou models involves several conditions on a Shimura datum that we presently recall.

We start with the following standard definitions, in increasing level of generality.

### **Definition 3.3.** We say that (G, X) is

- of Siegel type if it is of the form  $(GSp(\mathbf{V}), \mathfrak{h}^{\pm})$  where  $\mathbf{V}$  is a symplectic  $\mathbb{Q}$ -space, and  $\mathfrak{h}^{\pm}$  is the union of the upper and lower Siegel half-spaces (e.g., see [Mil05, §6]),
- of *Hodge type* if there exists an embedding of Shimura data  $\iota : (\mathbf{G}, \mathbf{X}) \to (\mathrm{GSp}(\mathbf{V}), \mathfrak{h}^{\pm})$  (called a *Hodge embedding*),
- of abelian type if there exists a Shimura datum  $(\mathbf{G}_1, \mathbf{X}_1)$  of Hodge type and an isogeny  $\alpha \colon \mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$  inducing an isomorphism  $(\mathbf{G}_1^{\mathrm{ad}}, \mathbf{X}^{\mathrm{ad}}) \to (\mathbf{G}^{\mathrm{ad}}, \mathbf{X}^{\mathrm{ad}})$ , in which case we say that  $(\mathbf{G}_1, \mathbf{X}_1)$  is adapted to  $(\mathbf{G}, \mathbf{X})$ , leaving the  $\alpha$  implicit.

We have the following examples of Shimura data of abelian type.<sup>6</sup>

**Example 3.4.** Shimura data of PEL type (see [Mil05, §8]) are of Hodge type.

**Example 3.5.** Let V be a quadratic space over  $\mathbb{Q}$  of signature (n,2). The group  $\operatorname{GSpin}(V)$  acts transitively on the space X of oriented negative definite 2-planes in  $V_{\mathbb{R}}$ , and X can be identified with a  $\operatorname{GSpin}(V)(\mathbb{R})$ -conjugacy class of morphisms  $\mathbb{S} \to \operatorname{GSpin}(V)_{\mathbb{R}}$  (see [MP16, §1]). The pair  $(\operatorname{GSpin}(V), X)$  is a Shimura datum of Hodge type which is not of PEL type (see [MP16, §3]).

**Example 3.6.** Let  $F \supseteq \mathbb{Q}$  be a totally real field, B a quaternion algebra over F, and  $\mathbf{G}_B$  the algebraic  $\mathbb{Q}$ -group  $B^{\times}$ . There is a Shimura datum  $(\mathbf{G}_B, \mathbf{X}_B)$  associated to B (see [Mil05, Example 5.24]). If B is not  $\mathbb{R}$ -split then  $(\mathbf{G}_B, \mathbf{X}_B)$  is of abelian type, but not of Hodge type. The Shimura varieties associated to such  $(\mathbf{G}_B, \mathbf{X}_B)$  include Shimura curves.

<span id="page-14-3"></span>**Example 3.7.** For a  $\mathbb{Q}$ -torus  $\mathbf{T}$  any homomorphism  $h \colon \mathbb{S} \to \mathbf{T}_{\mathbb{R}}$  defines a Shimura datum  $(\mathbf{T}, \{h\})$  of abelian type, which is rarely of Hodge type, and which we refer to as being of *toral type*.

Kisin-Pappas-Zhou models are constructed when  $(\mathbf{G}, \mathbf{X})$  is of abelian type and when the following group-theoretic property holds.

**Definition 3.8** ([KZ21, Definition 3.3.2]). We say that  $(\mathbf{G}, \mathbf{X})$  is *acceptable* if  $G^{\mathrm{ad}}$  is isomorphic to a group of the form  $\prod_{i=1}^r \mathrm{Res}_{F_i/\mathbb{Q}_p} H_i$ , where each  $F_i$  is a finite extension of  $\mathbb{Q}_p$ , and  $H_i$  is an adjoint group over  $F_i$  which is split over a tame extension of  $F_i$ .

<span id="page-14-0"></span>**Remark 3.9.** The acceptability condition is very mild. For instance, if p > 3 the condition is vacuous, and when p = 3 it only excludes those Shimura data  $(\mathbf{G}, \mathbf{X})$  for which  $\mathbf{G}$  has an almost simple factor of type  $D_4$  (see [KZ21, §3.3.1]).

<span id="page-14-1"></span><sup>&</sup>lt;sup>6</sup>An essentially full classification of Shimura varieties of abelian type is given in the appendix of [MS81].

<span id="page-15-1"></span>The construction of Kisin–Pappas–Zhou models will be an iterative process, starting with a much more restrictive class of Shimura data. For convenience, we give name to this class.

**Definition 3.10.** We say that (G, X) is very good if:

- (**G**, **X**) is acceptable,
- $Z(\mathbf{G})$  is a torus, and
- Z(G),  $G^{der}$ , and G are R-smooth (see Definitions 2.9 and 2.10).

We say that a parahoric Shimura datum  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is of Hodge type, abelian type, acceptable, or very good if the underlying Shimura datum  $(\mathbf{G}, \mathbf{X})$  is.

**Definition 3.11.** A parahoric Shimura datum  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  of Hodge type is well-adapted to  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  when given an isogeny  $\alpha \colon \mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$  (often left implicit) such that

- (1)  $\alpha$  adapts  $(\mathbf{G}_1, \mathbf{X}_1)$  to  $(\mathbf{G}, \mathbf{X})$ ,
- (2) if the isomorphism

$$\mathscr{B}(G_1,\mathbb{Q}_p) \xrightarrow{\sim} \mathscr{B}(G,\mathbb{Q}_p)$$

induced from the isogeny  $\alpha \colon G_1^{\operatorname{der}} \to G^{\operatorname{der}}$  and Lemma 2.5 has the property that if  $\mathcal{G} \simeq \mathcal{G}_x^{\circ}$  for x, and  $x_1$  denotes the corresponding point in  $\mathscr{B}(G_1, \mathbb{Q}_p)$ , then  $\mathcal{G}_1 \simeq \mathcal{G}_{x_1}^{\circ}$ ,

(3) if  $\mathbf{E}' := \mathbf{E}\mathbf{E}_1$ , then  $\mathbf{E}'$  splits completely at every prime of  $\mathbf{E}$  lying over p.

Finally, we set some terminology used later on in the article. Let  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  be a parahoric Shimura datum of Hodge type. We call a map of Shimura data

$$\iota \colon (\mathbf{G}, \mathbf{X}, \mathcal{G}) \to (\mathrm{GSp}(\mathbf{V}), \mathfrak{h}^{\pm}, \mathrm{GSp}(\Lambda)),$$

where  $\mathbf{V}$  a symplectic  $\mathbb{Q}$ -space and  $\Lambda \subseteq \mathbf{V}_{\mathbb{Q}_p}$  is a self-dual  $\mathbb{Z}_p$ -lattice, a *Hodge embedding* of parahoric Shimura data if the underling map  $\iota \colon \mathbf{G} \to \mathrm{GSp}(\mathbf{V})$  is a closed embedding. We say that  $\iota$  respects stabilizers if  $\widetilde{\mathsf{K}}_p = \mathrm{GSp}(\Lambda) \cap \mathbf{G}(\mathbb{Q}_p)$ .

**3.1.4 Existence and properties of models.** We are now prepared to state the existence of Kisin–Pappas–Zhou models, as well as the major properties we need of these models.

<span id="page-15-0"></span>**Theorem 3.12** ([KP18, Theorem 4.6.23] and [KZ21, Theorem 5.2.12]). Suppose that  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is an acceptable parahoric Shimura datum of abelian type and. Then, there exists a system  $\{\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G}, \mathbf{X})\}$  of normal flat quasi-projective  $\mathcal{O}_E$ -models of  $\{\mathsf{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G}, \mathbf{X})_E\}$  such that the following properties hold.

(1) Fix neat compact open subgroups  $\mathsf{K}^p$  and  $\mathsf{K}^{p'}$  in  $\mathbf{G}(\mathbb{A}_f^p)$  and an element g of  $\mathbf{G}(\mathbb{A}_f^p)$  with  $g^{-1}\mathsf{K}^pg\subseteq \mathsf{K}^{p'}$ . Write  $\mathsf{K}=\mathsf{K}_p\mathsf{K}^p$  and  $\mathsf{K}'=\mathsf{K}_p\mathsf{K}^{p'}$ . Then, the morphism

$$t_{\mathsf{K},\mathsf{K}'}(q): \mathrm{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})_E \to \mathrm{Sh}_{\mathsf{K}'}(\mathbf{G},\mathbf{X})_E$$

admits a (necessarily unique) finite étale extension

$$t_{\mathsf{K},\mathsf{K}'}(g):\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}}(\mathbf{G},\mathbf{X}) \to \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}'}(\mathbf{G},\mathbf{X}).$$

(2) Writing

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X}) \coloneqq \varprojlim_{\mathsf{K}_{p}} \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}\mathsf{K}^{p}}(\mathbf{G},\mathbf{X}),$$

<span id="page-16-3"></span>one has the following extension property relative to a characteristic (0,p) discrete valuation ring R over  $\mathcal{O}_E$ : the natural map

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})(R) \to \mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})(R[1/p]),$$

is a bijection.

We will recall below, fairly precisely, the construction of the models  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}}(\mathbf{G},\mathbf{X})$ . The superscript  $\mathfrak{d}$ , which is either a very good parahoric Shimura datum of Hodge type well-adapted to  $(\mathbf{G},\mathbf{X},\mathcal{G})$ , or possibly  $\varnothing$  when  $(\mathbf{G},\mathbf{X},\mathcal{G})$  is of Hodge type. Its role is to emphasize various choices made in the construction of these models.

- <span id="page-16-0"></span>**3.2** The  $\mathscr{A}$ -group and the  $\mathscr{E}$ -group. Let  $\mathbf{G}$  be a reductive  $\mathbb{Q}$ -group. In this section we associate to  $\mathbf{G}$  groups  $\mathscr{A}(\mathbf{G})$  and  $\mathscr{A}(\mathbf{G})^{\circ}$ , and the so-called  $\mathscr{E}$ -group to a parahoric Shimura datum, following [Del79]. We also define analogs of these groups for  $\mathbb{Z}_{(p)}$ -valued points following [KP18] and [KZ21], and discuss some functorial properties of these groups. These groups play an important role in the construction of the models  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})$  from Theorem 3.12.
- **3.2.1 The** \*-product. Let us begin by recalling the \*-product of Deligne (see [Del79]). Suppose H and  $\Gamma$  are abstract groups equipped with actions of a group  $\Delta$  by group homomorphisms. Let

$$\psi: \Gamma \to H$$
, and  $\varphi: \Gamma \to \Delta$ 

be  $\Delta$ -equivariant group homomorphisms, where  $\Delta$  acts on itself by inner automorphisms, and assume that  $\psi$  and  $\varphi$  are compatible in the sense that, for all  $\gamma$  in  $\Gamma$ , we have the identity

$$\varphi(\gamma) \cdot h = \psi(\gamma)^{-1} h \psi(\gamma),$$

where  $\cdot$  denotes the action of  $\Delta$  on H. Then the semi-direct product  $H \rtimes \Delta$  admits a quotient

$$H *_{\Gamma} \Delta := H \rtimes \Delta / \{ (\psi(\gamma), \varphi(\gamma)^{-1}) \},$$

where one easily checks that the subgroup  $\{(\psi(\gamma), \varphi(\gamma)^{-1})\}$  of all the elements of the form  $(\psi(\gamma), \varphi(\gamma)^{-1})$  for  $\gamma$  in  $\Gamma$  is a normal subgroup.

For the purposes of this section, we will refer to a datum  $(H, \Gamma, \Delta, \psi, \varphi)$  as above as a *tuple*. A morphism of tuples  $(H, \Gamma, \Delta, \psi, \varphi) \to (H', \Gamma', \Delta', \psi', \varphi')$  is a triple (f, g, h), consisting of group homomorphisms  $f: H \to H'$  and  $g: \Gamma \to \Gamma'$  equivariant relative to a group homomorphism  $h: \Delta \to \Delta'$  and such that  $\psi' \circ g = f \circ \psi$  and  $h \circ \varphi = \varphi' \circ f$ .

<span id="page-16-1"></span>The \*-product satisfies the following elementary functoriality.

### Lemma 3.13. Any morphism of tuples

$$(f,g,h)\colon (H,\Gamma,\Delta,\varphi)\to (H',\Gamma',\Delta',\varphi')$$

induces a homomorphism of groups

$$H *_{\Gamma} \Delta \to H' *_{\Gamma'} \Delta'$$
.

For future use, we also remark that if X is a set equipped with a right action of  $H \rtimes \Delta$ , then the action descends to the an action of  $H *_{\Gamma} \Delta$  on the quotient  $X/\Gamma$ , where here  $\Gamma$  acts on X via

<span id="page-16-2"></span>
$$x \cdot \gamma = x \cdot (\psi(\gamma), \varphi(\gamma)^{-1}). \tag{3.2}$$

<span id="page-17-1"></span>**3.2.2** The groups  $\mathscr{A}(\mathbf{G})$  and  $\mathscr{A}(\mathbf{G})^{\circ}$ . Let us now recall some notation from [Del79].

If **G** is a reductive group over  $\mathbb{Q}$ , then we denote by  $\mathbf{G}(\mathbb{R})^+$  the connected component of the identity in  $\mathbf{G}(\mathbb{R})$  with respect to the real topology. For a subgroup H of  $\mathbf{G}(\mathbb{R})$ , we denote by  $\mathsf{H}_+$  the inverse image of  $\mathbf{G}^{\mathrm{ad}}(\mathbb{R})^+$  in H. We write also  $\mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+ = \mathbf{G}^{\mathrm{ad}}(\mathbb{Q}) \cap \mathbf{G}^{\mathrm{ad}}(\mathbb{R})^+$ .

Now suppose  $(\mathbf{G}, \mathbf{X})$  is a Shimura datum. Let  $\mathbf{Z}$  denote the center of  $\mathbf{G}$ , and let  $\mathbf{Z}(\mathbb{Q})^-$  denote the closure of  $\mathbf{Z}(\mathbb{Q})$  in  $\mathbf{G}(\mathbb{A}_f)$ . We define

$$\mathscr{A}(\mathbf{G}) := \mathbf{G}(\mathbb{A}_f)/\mathbf{Z}(\mathbb{Q})^- *_{\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q})} \mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+,$$

where  $\mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  acts by conjugation on  $\mathbf{G}(\mathbb{A}_f)/\mathbf{Z}(\mathbb{Q})^-$  and  $\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q}) \to \mathbf{G}(\mathbb{A}_f)/\mathbf{Z}(\mathbb{Q})^-$  and  $\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q}) \to \mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  are the obvious maps.

By [Mil05, Proposition 5.1], the map  $\mathbf{G}(\mathbb{R})^+ \to \mathbf{G}^{\mathrm{ad}}(\mathbb{R})^+$  is surjective with kernel  $\mathbf{Z}(\mathbb{R}) \cap \mathbf{G}(\mathbb{R})^+$ , which is contained in the center of  $\mathbf{G}(\mathbb{R})^+$ , so the conjugation action of  $\mathbf{G}$  on itself induces an action of  $\mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  on  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})$ . Combining this with the action of  $\mathbf{G}(\mathbb{A}_f)$  on  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})$  determines a right action of  $\mathscr{A}(\mathbf{G})$  on  $\mathrm{Sh}(\mathbf{G}, \mathbf{X})$ .

Denote by  $\mathbf{G}(\mathbb{Q})_+^-$  the closure of  $\mathbf{G}(\mathbb{Q})_+$  in  $\mathbf{G}(\mathbb{A}_f)$ . Define

$$\mathscr{A}(\mathbf{G})^{\circ} = \mathbf{G}(\mathbb{Q})_{+}^{-}/\mathbf{Z}(\mathbb{Q})^{-} *_{\mathbf{G}(\mathbb{Q})_{+}/\mathbf{Z}(\mathbb{Q})} \mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^{+},$$

where  $\mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  acts by conjugation on  $\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q})^-$  and  $\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q}) \to \mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q})^-$  and  $\mathbf{G}(\mathbb{Q})_+/\mathbf{Z}(\mathbb{Q}) \to \mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  are the obvious maps. Evidently  $\mathscr{A}(\mathbf{G})^\circ$  is a subgroup of  $\mathscr{A}(\mathbf{G})$ . But, the group  $\mathscr{A}(\mathbf{G})^\circ$  depends only on  $\mathbf{G}^{\mathrm{der}}$  and not on  $\mathbf{G}$ , since by [Del79, 2.1.15] it is given by the completion of  $\mathbf{G}^{\mathrm{ad}}(\mathbb{Q})^+$  with respect to the topology whose open sets are images of congruence subgroups in  $\mathbf{G}^{\mathrm{der}}(\mathbb{Q})$ .

It is clear that both the associations  $\mathbf{G} \mapsto \mathscr{A}(\mathbf{G})$  and  $\mathbf{G} \mapsto \mathscr{A}(\mathbf{G})^{\circ}$  are functorial in maps of reductive groups  $f \colon \mathbf{G} \to \mathbf{H}$  such that  $f(Z(\mathbf{G})) \subseteq Z(\mathbf{H})$ .

**3.2.3** The groups  $\mathscr{A}(\mathcal{G})$  and  $\mathscr{A}(\mathcal{G})^{\circ}$ . We define also analogs of  $\mathscr{A}(\mathbf{G})$  and  $\mathscr{A}(\mathbf{G})^{\circ}$  for  $\mathbb{Z}_{(p)}$ -valued points, following [KP18, §4.5.6] (see also [KZ21, §5.2.2]).

To begin, we record the following well-known Beauville–Lazslo-type lemma (which is a largely basic case of [Sta17, Tag 0F9Q]). For a ring A, let us denote by  $\mathbf{AlgGrp}_A$  =  $\mathbf{AlgGrp}_A^{\varnothing}$  the category of finite type affine group A-schemes, and by  $\mathbf{AlgGrp}_A^{\mathrm{fl}}$  and  $\mathbf{AlgGrp}_A^{\mathrm{sm}}$  the full subcategory of A-flat and A-smooth objects, respectively.

<span id="page-17-0"></span>**Proposition 3.14.** Let R be a Noetherian ring and f a non-zerodivisor of R. Denote the f-adic completion of R by  $\widehat{R}$ . Then the functor

$$\mathbf{AlgGrp}_R^P \to \mathbf{AlgGrp}_{R[1/f]}^P \times_{\mathbf{AlgGrp}_{\widehat{R}[1/f]}} \mathbf{AlgGrp}_{\widehat{R}}^P, \quad \mathcal{H} \mapsto (\mathcal{H}_{R[1/f]}, \mathcal{H}_{\widehat{R}}, \theta_{\mathrm{nat}}),$$

is an equivalence, where the target is the 2-fiber product (with the projection maps the obvious base change),  $\theta_{nat}$  is the natural isomorphism, and  $P \in \{\emptyset, fl, sm\}$ .

*Proof.* Observe that  $\operatorname{Spec}(\widehat{R}) \to \operatorname{Spec}(R)$  is flat (e.g., see [Sta17, Tag 00MB]) with image precisely the vanishing locus V(f) of f (e.g., as follows from combining [Sta17, Tag 00MC] and [Sta17, Tag 00HP]). Thus,

$$\operatorname{Spec}(\widehat{R}) \sqcup \operatorname{Spec}(R^{[1/f]}) \to \operatorname{Spec}(R)$$

is an fpqc cover. Moreover,

$$\operatorname{Spec}(\widehat{R}) \times_{\operatorname{Spec}(R)} \operatorname{Spec}(R[1/f]) \simeq \operatorname{Spec}(\widehat{R}[1/f]).$$

<span id="page-18-1"></span>The fully faithfulness follows from [Sta17, Tag 023Q]. The essential surjectivity follows from [Sta17, Tag 0245] to descend to an affine scheme, [Sta17, Tag 023Q] to descend the multiplication map and identity section, and finally [Sta17, Tag 02KZ], [Sta17, Tag 02L2], and [Sta17, Tag 02VL] to descend the property P.

Suppose now that that  $\mathbf{G}$  is a reductive group over  $\mathbb{Q}$  and  $\mathcal{G}$  is a parahoric model of  $\mathbf{G}_{\mathbb{Q}_p}$ . Let  $\mathcal{G}^{\mathrm{ad}}$  denote the parahoric  $\mathbb{Z}_p$ -model of  $G^{\mathrm{ad}}$  as discussed in §2.1.5. By Proposition 3.14 there exists a unique morphism of smooth group  $\mathbb{Z}_{(p)}$ -schemes  $\mathcal{G} \to \mathcal{G}^{\mathrm{ad}}$  modeling  $\mathbf{G} \to \mathbf{G}^{\mathrm{ad}}$  and  $\mathcal{G} \to \mathcal{G}^{\mathrm{ad}}$ . Let  $\mathbf{Z}_{\mathbf{G}}$  denote the center of  $\mathbf{G}$ , and denote by  $\mathcal{Z}_{\mathbf{G}}$  the closure of  $\mathbf{Z}_{\mathbf{G}}$  in  $\mathcal{G}$ .

Let  $\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^-$  and  $\mathcal{G}(\mathbb{Z}_{(p)})_+^-$  denote the closures of  $\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})$  and  $\mathcal{G}(\mathbb{Z}_{(p)})_+$  in  $\mathbf{G}(\mathbb{A}_f^p)$ , respectively. Following [KP18, §4.5.6] and [KZ21, §5.2.2], we set

$$\mathscr{A}(\mathcal{G}) \coloneqq \mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^- *_{\mathcal{G}(\mathbb{Z}_{(p)})+/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})} \mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+,$$

and

$$\mathscr{A}(\mathcal{G})^{\circ} := \mathcal{G}(\mathbb{Z}_{(p)})_{+}^{-}/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^{-} *_{\mathcal{G}(\mathbb{Z}_{(p)})+/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})} \mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^{+},$$

where in the first definition we have that  $\mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+$  acts on  $\mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^-$  by conjugation and

$$\mathcal{G}(\mathbb{Z}_{(p)})_+/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)}) \to \mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^-$$
 and  $\mathcal{G}(\mathbb{Z}_{(p)})_+/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)}) \to \mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+$ , are the obvious maps, and similarly for the second definition.

By [KP18, Lemma 4.6.4 (2)],  $\mathscr{A}(\mathcal{G})^{\circ}$  is a subgroup of  $\mathscr{A}(\mathcal{G})$  but depends only on  $\mathcal{G}^{\operatorname{der}}$ , where  $\mathcal{G}^{\operatorname{der}}$  denotes the parahoric model of  $\mathbf{G}_{\mathbb{Q}_p}^{\operatorname{der}}$  obtained as in §2.1.4 and  $\mathcal{G}^{\operatorname{der}}$  is obtained from Proposition 3.14.

<span id="page-18-0"></span>**Lemma 3.15.** Let G and H be reductive groups over  $\mathbb{Q}$  and set  $G = G_{\mathbb{Q}_p}$  and  $H = H_{\mathbb{Q}_p}$ . Fix parahoric models  $\mathcal{G}$  and  $\mathcal{H}$  of G and H corresponding to points x and y in the buildings  $\mathcal{B}(G,\mathbb{Q}_p)$  and  $\mathcal{B}(H,\mathbb{Q}_p)$ , respectively. Suppose  $f: G \to H$  is a homomorphism of reductive  $\mathbb{Q}$ -groups carrying  $\mathbf{Z}_G$  into  $\mathbf{Z}_H$ , and suppose that

$$f_*: \mathscr{B}(G, \mathbb{Q}_p^{\mathrm{ur}}) \to \mathscr{B}(H, \mathbb{Q}_p^{\mathrm{ur}})$$

is a map of buildings which is equivariant for the map  $f: G(\mathbb{Q}_p^{ur}) \to H(\mathbb{Q}_p^{ur})$  and which sends x to y. Then f induces group homomorphisms

$$\mathscr{A}(f) \colon \mathscr{A}(\mathcal{G}) \to \mathscr{A}(\mathcal{H}) \quad and \quad \mathscr{A}(f)^{\circ} \colon \mathscr{A}(\mathcal{G})^{\circ} \to \mathscr{A}(\mathcal{H})^{\circ}.$$

*Proof.* Since f carries  $\mathbf{Z}_{\mathbf{G}}$  into  $\mathbf{Z}_{\mathbf{H}}$ , it follows that f induces a homomorphism of groups

$$f \colon \mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^- \to \mathbf{H}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{H}}(\mathbb{Z}_{(p)})^-.$$

The equivariance of  $f_*$  implies that  $f(\operatorname{Stab}_{G(\mathbb{Q}_p^{\operatorname{ur}})}(x)) \subseteq \operatorname{Stab}_{H(\mathbb{Q}_p^{\operatorname{ur}})}(y)$ , and hence that  $f(\mathcal{G}(\mathbb{Z}_p^{\operatorname{ur}})) \subseteq \mathcal{H}(\mathbb{Z}_p^{\operatorname{ur}})$ . Thus f extends to a morphism  $f: \mathcal{G} \to \mathcal{H}$  by [KP23, Corollary 2.10.10]. We similarly obtain an extension  $f^{\operatorname{ad}}: \mathcal{G}^{\operatorname{ad}} \to \mathcal{H}^{\operatorname{ad}}$  of  $f^{\operatorname{ad}}: \mathcal{G}^{\operatorname{ad}} \to \mathcal{H}^{\operatorname{ad}}$ , which induces

$$f^{\mathrm{ad}}: \mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+ o \mathcal{H}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+.$$

Moreover, as f extends to a morphism  $\mathcal{G} \to \mathcal{H}$ , it follows that f restricts to homomorphisms

$$f' \colon \mathcal{G}(\mathbb{Z}_{(p)})_+ / \mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)}) \to \mathcal{H}(\mathbb{Z}_{(p)})_+ / \mathcal{Z}_{\mathbf{H}}(\mathbb{Z}_{(p)}),$$

<span id="page-19-2"></span>and

$$f^{\circ} \colon \mathcal{G}(\mathbb{Z}_{(p)})_{+}^{-}/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^{-} \to \mathcal{H}(\mathbb{Z}_{(p)})_{+}^{-}/\mathcal{Z}_{\mathbf{H}}(\mathbb{Z}_{(p)})^{-}.$$

By Lemma 3.13, it remains only to check that  $(f,f',f^{\mathrm{ad}})$  and  $(f^{\circ},f',f^{\mathrm{ad}})$  induce morphisms of tuples. By uniqueness of the extension of  $G\to H\to H^{\mathrm{ad}}$  to parahoric models and equivariance of the bijections  $\mathscr{B}(G,\mathbb{Q}_p^{\mathrm{ur}})\stackrel{\sim}{\to} \mathscr{B}(G^{\mathrm{ad}},\mathbb{Q}_p^{\mathrm{ur}})$  and  $\mathscr{B}(H,\mathbb{Q}_p^{\mathrm{ur}})\stackrel{\sim}{\to} \mathscr{B}(H^{\mathrm{ad}},\mathbb{Q}_p^{\mathrm{ur}})$  from Lemma 2.5, we see that the diagram

$$egin{aligned} \mathcal{G}(\mathbb{Z}_{(p)})_+/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)}) & \stackrel{f}{\longrightarrow} \mathcal{H}(\mathbb{Z}_{(p)})_+/\mathcal{Z}_{\mathbf{H}}(\mathbb{Z}_{(p)}) \ & \downarrow \ & \downarrow \ & \mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+ & \stackrel{f^{\mathrm{ad}}}{\longrightarrow} \mathcal{H}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+ \end{aligned}$$

commutes. Thus it remains only to show that f is equivariant for the action of  $\mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+$ . But this is clear since the action of  $\mathcal{G}^{\mathrm{ad}}(\mathbb{Z}_{(p)})^+ \subseteq \mathbf{G}(\mathbb{Q})$  on  $\mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^-$  is via conjugation, and  $f: \mathbf{G}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{G}}(\mathbb{Z}_{(p)})^- \to \mathbf{H}(\mathbb{A}_f^p)/\mathcal{Z}_{\mathbf{H}}(\mathbb{Z}_{(p)})^-$  is a group homomorphism.

**3.2.4** The group  $\mathscr{E}(\mathcal{G})$ . Suppose now that  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a parahoric Shimura datum with reflex field  $\mathbf{E}$ . Let  $\mathsf{K}_p = \mathcal{G}(\mathbb{Z}_p)$ . Fix a connected component  $\mathbf{X}^+$  of  $\mathbf{X}$ , which determines connected Shimura varieties  $\mathsf{Sh}(\mathbf{G}, \mathbf{X})^+ \subseteq \mathsf{Sh}(\mathbf{G}, \mathbf{X})$  and  $\mathsf{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})^+ \subseteq \mathsf{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})$ .

By Lemma 3.2, the action of  $\operatorname{Gal}(\overline{\mathbf{E}}/\mathbf{E})$  on  $\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})^+$  factors through  $\operatorname{Gal}(\mathbf{E}^p/\mathbf{E})$ . By abuse of notation, we will use  $\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})^+$  to refer to the  $\mathbf{E}^p$ -scheme obtained by descent.

Let  $\mathscr{E}(\mathcal{G}) \subseteq \mathscr{A}(\mathcal{G}) \times \operatorname{Gal}(\mathbf{E}^p/\mathbf{E})$  denote the stabilizer of  $\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})^+$  in  $\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})$ . By [KP18, Lemma 4.6.6],  $\mathscr{E}(\mathcal{G})$  is an extension of  $\operatorname{Gal}(\mathbf{E}^p/\mathbf{E})$  by  $\mathscr{A}(\mathcal{G})^{\circ}$ , and there is a canonical isomorphism

$$\mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{G})^{\circ}} \mathscr{E}(\mathcal{G}) \xrightarrow{\sim} \mathscr{A}(\mathcal{G}) \times \operatorname{Gal}(\mathbf{E}^p/\mathbf{E}),$$

where an element of  $\mathscr{E}(\mathcal{G})$  acts on  $\mathscr{A}(\mathcal{G})$  via conjugation by its image in  $\mathscr{A}(\mathcal{G})$ .<sup>7</sup> The  $\mathscr{E}$ -group satisfies a functoriality akin to that of the  $\mathscr{A}$ -groups.

<span id="page-19-1"></span>**Lemma 3.16.** Let  $f: (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1) \to (\mathbf{G}, \mathbf{X}, \mathcal{G})$  be a morphism of parahoric Shimura data. Suppose  $\mathcal{G}_1$  and  $\mathcal{G}$  correspond to points  $x_1$  and x in the buildings  $\mathcal{B}(G_1, \mathbb{Q}_p)$  and  $\mathcal{B}(G, \mathbb{Q}_p)$ , respectively. Suppose the induced  $f: \mathbf{G}_1 \to \mathbf{G}$  carries  $\mathbf{Z}_{\mathbf{G}}$  into  $\mathbf{Z}_{\mathbf{H}}$ , and suppose that

$$f_* \colon \mathscr{B}(G_1, \mathbb{Q}_p) \to \mathscr{B}(G, \mathbb{Q}_p)$$

is a map of buildings which is equivariant for the map  $f: G_1(\mathbb{Q}_p^{ur}) \to G(\mathbb{Q}_p^{ur})$  and which sends  $x_1$  to x. Then f induces a group homomorphism

$$\mathscr{E}(f):\mathscr{E}(\mathcal{G}_1)\to\mathscr{E}(\mathcal{G}).$$

*Proof.* This follows from the definition of  $\mathscr{E}(\mathcal{G})$  by Lemma 3.15, along with the fact that f is a morphism of Shimura data.

<span id="page-19-0"></span><sup>&</sup>lt;sup>7</sup>Explicitly, the isomorphism  $\mathscr{A}(\mathcal{G}) \times \operatorname{Gal}(\mathbf{E}^p/\mathbf{E}) \to \mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{G})^{\circ}} \mathscr{E}(\mathcal{G})$  is given by the association  $(a, \sigma) \mapsto (a\bar{e}^{-1}, e)$ , where e denotes a lift of  $\sigma$  to  $\mathscr{E}(\mathcal{G})$ , and  $\bar{e}$  denotes the image of e in  $\mathscr{A}(\mathcal{G})$ .

<span id="page-20-3"></span>Suppose now we have two parahoric Shimura data  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  and  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$ , and that there is a central isogeny  $\alpha \colon \mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$  which induces an isomorphism of Shimura data

$$(\mathbf{G}_1^{\mathrm{ad}}, \mathbf{X}_1^{\mathrm{ad}}) \xrightarrow{\sim} (\mathbf{G}^{\mathrm{ad}}, \mathbf{X}^{\mathrm{ad}}).$$

Let  $x_1$  in  $\mathscr{B}(G_1,\mathbb{Q}_p)$  and x in  $\mathscr{B}(G,\mathbb{Q}_p)$  denote points in the buildings of  $G_1$  and G, respectively, which correspond to  $\mathcal{G}_1$  and  $\mathcal{G}$ . Let us further assume that  $x_1$  and x correspond to the same point  $x_1^{\operatorname{ad}} = x^{\operatorname{ad}}$  in the building  $\mathscr{B}(G_1^{\operatorname{ad}}, \mathbb{Q}_p) \simeq \mathscr{B}(G^{\operatorname{ad}}, \mathbb{Q}_p)$ .

Fix a connected component  $\mathbf{X}_1^+$  as above, which determines a group  $\mathscr{E}(\boldsymbol{\mathcal{G}}_1)$ . By the real approximation theorem, we may assume that the image of  $\mathbf{X} \subseteq \mathbf{X}^{\mathrm{ad}}$  contains  $\mathbf{X}_1^+$  by replacing **X** by its conjugate by some element of  $G^{ad}(\mathbb{Q})$ . We set  $E' = E_1 E$ , and define  $\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  to be the fiber product

$$\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) := \mathscr{E}(\mathcal{G}_1) \times_{\mathrm{Gal}(\mathbf{E}_1^p/\mathbf{E}_1)} \mathrm{Gal}(\mathbf{E}'^p/\mathbf{E}'). \tag{3.3}$$

Then  $\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  is an extension of  $\mathrm{Gal}(\mathbf{E}'^p/\mathbf{E}')$  by  $\mathscr{A}(\mathcal{G}_1)^{\circ}$ , and by [KP18, Lemma 4.6.9], there is a natural map of extensions

<span id="page-20-1"></span>
$$\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) \to \mathscr{E}(\mathcal{G}).$$
 (3.4)

In particular, it follows that there is an isomorphism

<span id="page-20-2"></span>
$$\mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{C}_1)^{\circ}} \mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) \xrightarrow{\sim} \mathscr{A}(\mathcal{G}) \times \operatorname{Gal}(\mathbf{E}'^p/\mathbf{E}').$$
 (3.5)

<span id="page-20-0"></span>3.3 Construction of Kisin-Pappas-Zhou models. We now briefly recall the construction of the Kisin-Pappas-Zhou models  $\mathscr{S}_{\mathsf{K}}^{\mathfrak{d}}(\mathbf{G},\mathbf{X})$  from Theorem 3.12, focusing on the aspects most relevant for our purposes. We encourage the reader to consult the relevant parts of [KP18] and [KZ21] for details.

Throughout this section we fix the following data/notation:

- (G, X) is a Shimura datum,
- $\mathbf{E}$  is the reflex field of  $(\mathbf{G}, \mathbf{X})$ ,
- v is a place of **E** lying over p,
- $\mathcal{O}_{(v)}$  is the localization of  $\mathcal{O}_{\mathbf{E}}$  at v,
- $E = \mathbf{E}_v$ ,
- G = G<sub>ℚp</sub>,
  G = G<sub>x</sub> is a parahoric model of G,
- $\mathsf{K}_p := \mathcal{G}(\mathbb{Z}_p),$

We refer to  $\S 2.1$  and  $\S 3.2$  for the meaning of these terms, as well as other notation related to Bruhat–Tits theory and Shimura varieties.

The construction of Kisin-Pappas-Zhou models is carried out in a four step process.

Step 1: Global construction for Siegel type. Suppose that  $(GSp(V), \mathfrak{h}^{\pm})$  is a Siegel datum. Choose a  $\mathbb{Z}_p$ -lattice  $\Lambda \subseteq \mathbf{V}_{\mathbb{Q}_p}$  and set

$$K_p = \operatorname{GSp}(\Lambda) \subseteq \operatorname{GSp}(\mathbf{V} \otimes_{\mathbb{Q}} \mathbb{Q}_p).$$

For  $K^p$  a neat compact open subgroups of  $\mathrm{GSp}(\mathbf{V} \otimes_{\mathbb{Q}} \mathbb{A}_p^f)$ , we set  $\mathscr{S}_{K_pK^p}(\mathrm{GSp}(\mathbf{V}), \mathfrak{h}^{\pm})$  to be the  $\mathbb{Z}_{(p)}$ -scheme given by Mumford's moduli of principally polarized abelian varieties with  $\mathsf{K}^p$ -level structure (see [Del79, §4]). These form a  $\mathsf{GSp}(\mathbf{V} \otimes_{\mathbb{Q}} \mathbb{A}^p_f)$ -system of  $\mathbb{Z}_{(p)}$ -schemes. <span id="page-21-4"></span><span id="page-21-2"></span>Step 2: Construction for Hodge type data. Let us now assume that  $(G, X, \mathcal{G})$  is a parahoric Hodge type datum and let us fix a parahoric Hodge embedding

$$\iota \colon (\mathbf{G}, \mathbf{X}, \mathcal{G}) \to (\mathrm{GSp}(\mathbf{V}), \mathfrak{h}^{\pm}, \mathrm{GSp}(\Lambda)).$$

which respects stabilizers. As in [Kis10, Lemma 2.10] we may choose a neat compact open subgroup  $\mathsf{K}^p_1 \subseteq \mathbf{GSp}(\mathbf{V} \otimes_{\mathbb{Q}} \mathbb{A}^p_f)$  such that  $\iota(\widetilde{\mathsf{K}}_p\mathsf{K}^p) \subseteq \mathrm{GSp}(\Lambda)\mathsf{K}^p_1$ , and such that the map

<span id="page-21-0"></span>
$$\operatorname{Sh}_{\widetilde{\mathsf{K}}_{n}\mathsf{K}^{p}}(\mathbf{G},\mathbf{X}) \to \operatorname{Sh}_{\operatorname{GSp}(\Lambda)\mathsf{K}^{p}_{1}}(\operatorname{GSp}(\mathbf{V}),\mathfrak{h}^{\pm})_{\mathbf{E}},$$
 (3.6)

is a closed embedding.

We then set

- $\mathscr{S}^{\varnothing}_{\widetilde{\mathsf{K}}_{p}\mathsf{K}^{p}}(\mathbf{G},\mathbf{X})$  to be the normalization of the Zariski closure of  $\operatorname{Sh}_{\widetilde{\mathsf{K}}_{p}\mathsf{K}^{p}}(\mathbf{G},\mathbf{X})$  in the scheme  $\mathscr{S}_{\operatorname{GSp}(\Lambda)\mathsf{K}_{1}^{p}}(\operatorname{GSp}(\mathbf{V}),\mathfrak{h}^{\pm})_{\mathcal{O}_{(v)}}$ , via the embedding in (3.6),
- $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G},\mathbf{X})$  to be the normalization (in the sense of [Sta17, Tag 0BAK]) of  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G},\mathbf{X})$  relative to finite map

$$\operatorname{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X}) o \operatorname{Sh}_{\widetilde{\mathsf{K}}_n\mathsf{K}^p}(\mathbf{G},\mathbf{X}).$$

<span id="page-21-3"></span>**Remark 3.17.** As each  $\mathscr{S}_{\mathrm{GSp}(\Lambda)\mathsf{K}_1^p}(\mathrm{GSp}(\mathbf{V}),\mathfrak{h}^{\pm})_{\mathcal{O}_{(v)}}$  is quasi-projective over  $\mathbb{Z}_{(p)}$  (see [MFK94, Theorem 7.9]), Zariski closed embeddings are quasi-projective, normalization maps are finite in our setting (see [Sta17, Tag 035R] and [Sta17, Tag 07QW]) and thus quasi-projective, we deduce that each  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G},\mathbf{X})$  is a quasi-projective  $\mathcal{O}_{(v)}$ -scheme.

As Zariski closure and normalization are functorial constructions, we see that  $\{\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  form a projective system. We then further set

$$\mathscr{S}_{\mathsf{K}_p}^{\scriptscriptstyle\varnothing}(\mathbf{G},\mathbf{X}) := \varprojlim_{\mathsf{K}^p} \mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\scriptscriptstyle\varnothing}(\mathbf{G},\mathbf{X}).$$

The continuous  $\mathbf{G}(\mathbb{A}_f^p)$ -action of  $\mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_E$  extends to a continuous action on  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G},\mathbf{X})$  with the property that

$${\mathscr S}^{\scriptscriptstyle {\rm ff}}_{{\mathsf K}_p}({\mathbf G},{\mathbf X})/{\mathsf K}^p \simeq {\mathscr S}^{\scriptscriptstyle {\rm ff}}_{{\mathsf K}_p{\mathsf K}^p}({\mathbf G},{\mathbf X}),$$

compatibly in  $K^p$ . We finally set

$$\mathscr{S}^{\varnothing}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X}) := \mathscr{S}^{\varnothing}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_v} \ \ \mathrm{and} \ \ \mathscr{S}^{\varnothing}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X}) := \mathscr{S}^{\varnothing}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_v},$$

which is a scheme over  $\mathcal{O}_v$  with  $\mathbf{G}(\mathbb{A}_f^p)$ -action and a scheme over  $\mathcal{O}_v$ , respectively.

A priori, these schemes depend on the choice of parahoric Hodge embedding which respects stabilizers. That said, the following shows that the not case, thus justifying the omission of the parahoric Hodge embedding from the notation.

**Proposition 3.18** ([KZ21, Corollary 5.3.3], [PR21, Theorem 4.5.2], and [DvHKZ24b]). The objects  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})$ ,  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})$ ,  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G}, \mathbf{X})$ , and  $\mathscr{S}_{\mathsf{K}_p\mathsf{K}^p}^{\varnothing}(\mathbf{G}, \mathbf{X})$  are canonically independent of parahoric Hodge embedding.

While the action of  $\mathbf{G}(\mathbb{A}_f^p)$  extends to actions on  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})$  and  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})$ , it is not a priori clear that these can be extended further to actions of  $\mathscr{A}(\mathcal{G})$ . That said, this does hold true when  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is very good, as explained in [KP18, §4.6].

<span id="page-21-1"></span><sup>&</sup>lt;sup>8</sup>Indeed, the fact that  $(\mathbf{G}, \mathbf{X})$  is very good implies, in particular, that  $Z(\mathbf{G})$  is an R-smooth torus, and so Proposition 2.12 applies. This means that there is a group map  $\mathscr{A}(\mathcal{G}) \to \mathscr{B}(\mathcal{G}_x)$ , where, if  $\mathcal{G} = \mathcal{G}_x^{\circ}$ ,

<span id="page-22-4"></span><span id="page-22-1"></span>Step 3: Global construction relative to a very good Hodge type datum. Suppose now that  $(G, X, \mathcal{G})$  is a general acceptable parahoric Shimura datum of abelian type. The key proposition which allows us to bootstrap from the previous cases is the following.

**Proposition 3.19** ([KZ21, Proposition 5.2.6]). There exists a very good parahoric Shimura datum  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  of Hodge type well-adapted to  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$ .

*Proof.* The only claim that needs to be checked is that  $G^{\text{der}}$  may be taken to be R-smooth. But this follows by the construction in the proof of loc. cit. (cf. [KZ21, §5.3.10]).

Throughout the remainder of this section, we fix  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  as in the proposition above. Choose connected components  $\mathbf{X}^+ \subseteq \mathbf{X}$  and  $\mathbf{X}_1^+ \subseteq \mathbf{X}_1$  which correspond in  $\mathbf{X}^{\mathrm{ad}} \simeq \mathbf{X}_1^{\mathrm{ad}}$ . Using Lemma 3.2, we obtain connected components  $\mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})^+$  and  $\mathrm{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1, \mathbf{X}_1)^+$  defined over  $\mathbf{E}^p$  and  $\mathbf{E}_1^p$ , respectively. We also obtain subgroups

$$\mathscr{E}(\mathcal{G}) \subseteq \mathscr{A}(\mathcal{G}) \times \mathrm{Gal}(\mathbf{E}^p/\mathbf{E}), \qquad \mathscr{E}(\mathcal{G}_1) \subseteq \mathscr{A}(\mathcal{G}_1) \times \mathrm{Gal}(\mathbf{E}_1^p/\mathbf{E}),$$

and the group

$$\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) = \mathscr{E}(\mathcal{G}_1) \times_{\operatorname{Gal}(\mathbf{E}_{+}^p/\mathbf{E})} \operatorname{Gal}(\mathbf{E}'^p/\mathbf{E}),$$

as defined in §3.2.

We have a bijection

<span id="page-22-0"></span>
$$\pi_0(\operatorname{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)_{E_1^p}) \xrightarrow{\sim} \pi_0(\mathscr{S}_{\mathsf{K}_{p,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)_{\mathcal{O}_{\mathbf{E}_2^p}}),$$
 (3.7)

<span id="page-22-3"></span>as follows from combining the following general results.

**Lemma 3.20.** Let  $\{S_i\}$  be a projective system of spectral spaces with quasi-compact surjective transition maps. Write  $S = \varprojlim S_i$ . Then,

- (1) S is a spectral space,
- (2) the (dense) quasi-compact open subsets of S are precisely those of the form  $U = \varprojlim U_i$  with each  $U_i \subseteq S_i$  a (dense) quasi-compact open subset such that  $U_i$  is the preimage of  $U_j$  under  $S_i \to S_j$ ,
- (3) the natural map  $\pi_0(S) \to \pi_0(S_i)$  is surjective for all i,
- (4) the natural map  $\pi_0(S) \to \lim \pi_0(S_i)$  is a homeomorphism.

Moreover, if each  $S_i$  is a disjoint union of finitely many irreducible spaces, then for every dense quasi-compact open  $U \subseteq S$  the natural map  $\pi_0(U) \to \pi_0(S)$  is a homeomorphism.

Proof. Claim (1) follows from [FK18, Chapter 0, Theorem 2.2.10]. Claim (2) follows from [FK18, Chapter 0, Proposition 2.2.9 and Lemma 2.2.19]. Claim (4) follows from [ALY21, Lemma 4.1.6]), and claim (3) then follows from claim (4), as each projection  $\pi_0(S_i) \to \pi_0(S_j)$  is a surjection of compact Hausdorff spaces (see [Sta17, Tag 0906]), and so  $\varprojlim \pi_0(S_i) \to \pi_0(S_i)$  is surjective by Tychonoff's theorem. For the final claim write  $U = \varprojlim U_i$  with  $U_i \subseteq S_i$  a dense quasi-compact open. Then, each  $\pi_0(U_i) \to \pi_0(S_i)$  is clearly a bijection, and so the claim follows by passing to the limit using (4).

<span id="page-22-2"></span>**Lemma 3.21.** Let  $X \to Y$  be a flat and finite type morphism of Noetherian schemes where X is normal. Then, X is a finite disjoint union of irreducible spaces, and for any dense open  $U \subseteq Y$ , the open  $X_U \subseteq X$  is dense.

the group scheme  $\mathcal{G}_x$  is the stabilizer Bruhat–Tits group scheme as in [KP18, §1.1.2], and  $\mathcal{B}(\mathcal{G}_x)$  is as in [KP18, §4.5.6]. Then, one can define the action precisely as in [KP18, Lemma 4.5.7].

<span id="page-23-6"></span>*Proof.* The first claim follows from [Sta17, Tag 033N], and the latter is clear as f is open by [Sta17, Tag 01UA].

The bijection (3.7) shows that  $\operatorname{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)^+$  corresponds uniquely to a connected component  $\mathscr{S}_{\mathsf{K}_{p,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)^+$  of  $\mathscr{S}_{\mathsf{K}_{p,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)$ . Set  $\mathcal{O}_{(v)}^{\prime p}=\mathcal{O}_{\mathbf{E}'^p}\otimes_{\mathcal{O}_{\mathbf{E}}}\mathcal{O}_{(v)}$ . Consider then

<span id="page-23-0"></span>
$$\mathscr{S}_{\mathsf{K}_{p,1}}^{\scriptscriptstyle g}(\mathbf{G}_1,\mathbf{X}_1)_{\mathcal{O}_{(p)}^{\prime p}}^+ \times \mathscr{A}(\mathcal{G}).$$
 (3.8)

As observed in Step 2, we have that the right  $\mathscr{A}(\mathcal{G}_1)$ -action extends to  $\mathscr{S}^{\varnothing}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)$  and by the bijection (3.7) we deduce that  $\mathscr{E}(\mathcal{G}_1)$  stabilizes  $\mathscr{S}^{\varnothing}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)^+$ . We then get an induced action of  $\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  on  $\mathscr{S}^{\varnothing}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)^+_{\mathcal{O}_{(v)}^{/p}}$ . We then finally let  $\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  act on the right of (3.8) by setting

<span id="page-23-4"></span>
$$(s,a) \cdot e = (se, \overline{e}^{-1}a\overline{e}), \tag{3.9}$$

where  $\overline{e}$  denotes the image of e under the homomorphisms

<span id="page-23-1"></span>
$$\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) \to \mathscr{E}(\mathcal{G}) \to \mathscr{A}(\mathcal{G}),$$
 (3.10)

where the first map is as in (3.4), and the second map is projection.

We then consider  $\mathscr{A}(\mathcal{G}) \rtimes \mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$ , where  $\mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  acts again via the homomorphism from (3.10). Let the semi-direct product  $\mathscr{A}(\mathcal{G}) \rtimes \mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  act on (3.8) by having  $\mathscr{A}(\mathcal{G})$  act by right multiplication on the  $\mathscr{A}(\mathcal{G})$ -factor of (3.8), i.e.,

<span id="page-23-5"></span>
$$(s,a) \cdot a' = (s,aa').$$
 (3.11)

As in (3.2) we obtain an action of  $\mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{G}_1)^{\circ}} \mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1)$  on

<span id="page-23-2"></span>
$$\left[ \mathscr{S}_{\mathsf{K}_{p,1}}^{\alpha}(\mathbf{G}_{1}, \mathbf{X}_{1})_{\mathcal{O}_{(p)}^{\prime p}}^{+} \times \mathscr{A}(\mathcal{G}) \right] / \mathscr{A}(\mathcal{G}_{1})^{\circ}, \tag{3.12}$$

with notation as in loc. cit. Since

$$\mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{G}_1)^{\circ}} \mathscr{E}_{\mathbf{E}'}(\mathcal{G}_1) \simeq \mathscr{A}(\mathcal{G}) \times \mathrm{Gal}(\mathbf{E}'^p/\mathbf{E}),$$

(see (3.5)), we obtain an action of  $\mathscr{A}(\mathcal{G}) \times \operatorname{Gal}(\mathbf{E}'^p/\mathbf{E})$ , and hence of  $\mathbf{G}(\mathbb{A}_f^p) \times \operatorname{Gal}(\mathbf{E}'^p/\mathbf{E})$ , on (3.12).

Now, let J denote the image of the natural map

$$\mathscr{A}(\mathcal{G}_1)^{\circ} \backslash \mathscr{A}(\mathcal{G}) \to \mathscr{A}(\mathbf{G}_1)^{\circ} \backslash \mathscr{A}(\mathbf{G}) / K_p,$$

where the map  $\mathscr{A}(\mathcal{G}_1)^{\circ} \to \mathscr{A}(\mathcal{G})$  is as in Lemma 3.15. Then J is finite. Let  $\mathfrak{d} = (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$ , and consider

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{(v)}^{\prime p}} := \left( [\mathscr{S}^{\scriptscriptstyle egin{subarray}{c} \ \mathsf{K}_{p,1}}(\mathbf{G}_{1},\mathbf{X}_{1})^{+}_{\mathcal{O}_{(v)}^{\prime p}} imes \mathscr{A}(\mathcal{G})]/\mathscr{A}(\mathcal{G}_{1})^{\circ} 
ight)^{J},$$

which we endow with the diagonal (relative to the *J*-indexed factors) action of the group  $\mathbf{G}(\mathbb{A}_f^p) \times \mathrm{Gal}(\mathbf{E}'^p/\mathbf{E})$ . This action is continuous, and so by Galois descent gives to a unique scheme  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})_{\mathcal{O}'_{(v)}}$  with continuous action of  $\mathbf{G}(\mathbb{A}_f^p)$ , where  $\mathcal{O}'_{(v)} = \mathcal{O}_{\mathbf{E}'} \otimes_{\mathcal{O}_{\mathbf{E}}} \mathcal{O}_{(v)}$ .

<span id="page-23-3"></span><sup>&</sup>lt;sup>9</sup>That Galois descent applies here follows from the continuity of the action, the quasi-projectivity observation made in Remark 3.17, and the fact that quasi-projective morphisms satisfy effective descent relative to finite locally free maps (see [Sta17, Tag 0CCJ]).

### <span id="page-24-5"></span><span id="page-24-3"></span>Step 4: The construction in the local setting. Consider

$$(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}'_{(v)}})_{\mathcal{O}_E}.$$

That  $\mathbf{E}'$  is completely split over  $\mathbf{E}$  at every prime over p implies, in particular, that this decomposes as several copies of the same  $\mathcal{O}_v$ -scheme with a continuous action of  $\mathbf{G}(\mathbb{A}_f^p)$ , indexed by by the place of  $\mathbf{E}'$  lying over v. Choose any of these copies, and call it  $\mathscr{S}^{\mathfrak{d}}_{\mathbf{K}_p}(\mathbf{G}, \mathbf{X})$ . We then set

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}\mathsf{K}^{p}}(\mathbf{G},\mathbf{X}) := \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})/\mathsf{K}^{p},$$

for any neat compact open subgroup  $K^p$  of  $\mathbf{G}(\mathbb{A}_f^p)$ . That these quotients exist and are quasi-projective can be deduced from Remark 3.17 in conjunction with [Sta17, Tag 01ZY] and [Sta17, Tag 07S6].

- <span id="page-24-0"></span>**3.4** Some properties and functoriality results. In this subsection we establish some compatibilities satisfied by the Kisin–Pappas–Zhou integral models, and we prove the minimal amount of functoriality needed to prove our main result (see Theorem 4.10). This main result will then establish functoriality in general (see Theorem 4.14).
- **3.4.1** Kisin–Pappas–Zhou integral models of toral type. To utilize the results of [Dan22], it is useful to explicitly describe Kisin–Pappas–Zhou integral models of tori.

Recall from Example 3.7 that a Shimura datum  $(\mathbf{T}, \{h\})$  is of toral type if  $\mathbf{T}$  is a torus. In this case, for every compact open subgroup  $\mathsf{K} = \mathsf{K}_p \mathsf{K}^p \subseteq \mathbf{T}(\mathbb{A}_f^p)$ , the Shimura variety  $\mathsf{Sh}_{\mathsf{K}}(\mathbf{T}, \{h\})$  is zero-dimensional, i.e.,

<span id="page-24-2"></span>
$$\operatorname{Sh}_{\mathsf{K}}(\mathbf{T}, \{h\})_{E} = \bigsqcup_{i \in I} \operatorname{Spec}(E_{i})$$
(3.13)

for some finite index set I. In fact, each field  $E_i$  is the same field, and is an unramified extension of  $\mathbb{Q}_p$  (see [Dan22, Lemma 4.2] and the proof of [Dan22, Lemma 4.8]).

Set  $T = \mathbf{T}_{\mathbb{Q}_p}$ . As discussed in §2.1.3, there is a unique parahoric model  $\mathcal{T}$  of T, given by the connected component  $(\mathcal{T}^{\mathrm{lft}})^{\circ}$  of the Néron model  $\mathcal{T}^{\mathrm{lft}}$  of T.

<span id="page-24-4"></span>**Proposition 3.22.** Suppose  $(\mathbf{T}, \{h\}, \mathcal{T})$  is parahoric Shimura datum of toral type, and let  $\mathfrak{d} = (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  be a very good parahoric Shimura datum of Hodge type which is well-adapted to  $(\mathbf{T}, \{h\}, \mathcal{T})$ . Then,

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}}(\mathbf{T}, \{h\}) = \bigsqcup_{i \in I} \operatorname{Spec}(\mathcal{O}_{E_i}),$$

for any neat compact open subgroup  $\mathsf{K}^p \subseteq \mathbf{T}(\mathbb{A}_f^p)$  and with  $\mathsf{K} = \mathsf{K}_p \mathsf{K}^p$ . The same holds true for  $\mathscr{S}^{\varnothing}_{\mathsf{K}}(\mathbf{T},\{h\})$  if  $(\mathbf{T},\{h\})$  is of Hodge type.

*Proof.* First, observe that as  $(\mathbf{G}_1, \mathbf{X}_1)$  is adapted to the datum  $(\mathbf{T}, \{h\})$ , we have an isogeny  $\mathbf{G}_1^{\mathrm{der}} \to \mathbf{T}^{\mathrm{der}} = \{e\}$ , and hence  $\mathbf{G}_1^{\mathrm{der}}$  is trivial, since it is connected. Thus,  $\mathbf{G}_1$  is a torus.<sup>10</sup> Consider an arbitrary neat compact open subgroup  $\mathsf{K}_1^p \subseteq \mathbf{G}_1(\mathbb{A}_f^p)$ .

<span id="page-24-1"></span><sup>&</sup>lt;sup>10</sup>Indeed, if H is a commutative reductive group over a field K, and T is a maximal torus of H, then  $H = Z_H(T) = T$  (see [Mil17, Corollary 17.84]).

<span id="page-25-1"></span>Choose a parahoric Hodge embedding  $\iota \colon (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1) \to (\mathbf{GSp}(\mathbf{V}), \mathfrak{h}^{\pm}, \mathrm{GSp}(\Lambda))$  which respects stabilizers, and a neat compact open subgroup  $\mathsf{L}^p_1 \subseteq \mathrm{GSp}(\mathbf{V} \otimes_{\mathbb{Q}} \mathbb{A}^p_f)$  such that  $\iota(\mathsf{K}_{1,p}\mathsf{K}^p_1) \subseteq \mathrm{GSp}(\Lambda)\mathsf{L}^p_1$ , inducing a closed embedding

$$\operatorname{Sh}_{\mathsf{K}_{1,p}\mathsf{K}_1^p}(\mathbf{G}_1,\mathbf{X}_1) \to \operatorname{Sh}_{\operatorname{GSp}(\Lambda)\mathsf{L}_1^p}(\mathbf{GSp}(\mathbf{V}),\mathfrak{h}^{\pm})_{\mathbf{E}_1}.$$
 (3.14)

Note that  $\mathscr{S}_{\mathrm{GSp}(\Lambda)\mathsf{L}_1^p}(\mathbf{GSp}(\mathbf{V}),\mathfrak{h}^\pm)$  is flat, separated, and finite over  $\mathbb{Z}_{(p)}$ . Thus, considering (3.13), and using notation from **Step 2** of §3.3, it follows from Lemma 3.23 below that  $\mathscr{S}_{\widetilde{\mathsf{K}}_{p,1}\mathsf{K}_1^p}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)$  and thus  $\mathscr{S}_{\mathsf{K}_{p,1}\mathsf{K}_1^p}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)$  are disjoint unions of semi-local localizations of  $\mathcal{O}_{\mathbf{F}}$  for some finite extension  $\mathbf{F}$  of  $\mathbf{E}$ .

This implies that, using notation now from Step 3 of §3.3, that  $\mathscr{S}_{\mathsf{K}_{p,1}}^{z}(\mathbf{G}_{1},\mathbf{X}_{1})_{\mathcal{O}_{E}}^{+}$  is either the spectrum of a field or of a semi-local Dedekind domain. Thus, from the construction in Step 4 of §3.3 we deduce that for each neat compact open  $\mathsf{K}^{p} \subseteq \mathbf{G}(\mathbb{A}_{f}^{p})$  one has that  $\mathscr{S}_{\mathsf{K}_{p}\mathsf{K}^{p}}^{\mathfrak{d}}(\mathbf{G},\mathbf{X})$  is either the disjoint union of spectra of extensions of E, or the disjoint union of spectra of the rings of integers of finite extensions of E. That said, the former is impossible as it is then clear that such a model cannot satisfy the extension property from (2) of Theorem 3.12, and so the latter must hold. The fist claim follows. Moreover, the second claim follows from similar arguments.

Following [Sta17, Tag 035E], if X is a scheme with the property that every quasi-compact open has finitely many connected components, then we denote the normalization of X by  $X^{\nu}$ .

<span id="page-25-0"></span>**Lemma 3.23.** Let  $\mathcal{O}$  be an excellent Dedekind domain and  $\mathscr{X}$  be a separated, finite type, flat  $\mathcal{O}$ -scheme. Let x is a closed point of  $\mathscr{X}_{\eta}$  and let  $\overline{x}$  be the Zariski closure of x in  $\mathscr{X}$ . Then,  $\overline{x}^{\nu}$  is an open subscheme of Spec  $(\mathcal{O}')$  for a Dedekind domain  $\mathcal{O}'$  finite flat over  $\mathcal{O}$ .

*Proof.* Let  $\overline{X}$  be a compactification of  $\mathscr{X} \to \operatorname{Spec}(\mathcal{O})$  (see [Sta17, Tag 0ATT] and [Sta17, Tag 0F41]). Replacing  $\overline{\mathscr{X}}$  with the closed suscheme cut out by the  $\mathcal{O}$ -torsion in  $\mathcal{O}_{\mathscr{X}}$ , we may assume that  $\overline{\mathscr{X}}$  is flat over  $\mathcal{O}$  (see [GW20, Proposition 14.14]).

Let Z denote the Zariski closure of x in  $\overline{\mathscr{X}}$ . We claim that  $Z^{\nu} = \operatorname{Spec}(\mathcal{O}')$  for a Dedekind ring  $\mathcal{O}'$  finite flat over  $\mathcal{O}$ . As  $\overline{x} = \mathscr{X} \cap Z$ , the lemma will then follow from [Sta17, Tag 035K]. To prove the claim, we observe that Z is evidently irreducible and reduced, and thus integral. But, as  $Z \to \operatorname{Spec}(\mathcal{O})$  is dominant, we deduce that it is flat by [GW20, Proposition 14.14]. But, since  $\overline{\mathscr{X}}$  is a proper  $\mathcal{O}$ -scheme, so is Z. Thus, by [Sta17, Tag 0D4J] we deduce that  $Z_s$  is zero dimensional. Thus,  $Z \to \operatorname{Spec}(\mathcal{O})$  is proper and quasi-finite, and so finite (see [Sta17, Tag 02OG]). It follows that  $Z^{\nu}$  is also an integral scheme and  $Z^{\nu} \to \operatorname{Spec}(\mathcal{O})$  is dominant and finite (using [Sta17, Tag 035R]) over  $\mathcal{O}$  and so flat again by [GW20, Proposition 14.14]. Write  $Z^{\nu} = \operatorname{Spec}(\mathcal{O}')$ , then  $\mathcal{O}'$  is 1-dimensional Noetherian normal domain, and so a Dedekind domain as desired.

Given Proposition 3.22, we see that the definition of  $\mathscr{S}_{\mathsf{K}}^{\mathfrak{d}} = (\mathbf{T}, \{h\})$  is independent of the choice of  $\mathfrak{d}$ . We denote by  $\mathscr{S}_{\mathsf{K}}(\mathbf{T}, \{h\})$  the common object.

**3.4.2 Functoriality for ad-isomorphisms.** Suppose that  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1) \to (\mathbf{G}, \mathbf{X}, \mathcal{G})$  is an ad-isomorphism of parahoric Shimura datum. Take a very good parahoric Shimura datum  $\mathfrak{d} = (\mathbf{G}_2, \mathbf{X}_2, \mathcal{G}_2)$  of Hodge type well-adapted to  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$ . Then, since  $\alpha$  is an ad-isomorphism, one sees that  $\mathfrak{d}$  is also well-adapted to  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  in the obvious way.

<span id="page-26-1"></span><span id="page-26-0"></span>Proposition 3.24. There exists a unique quotient-finite étale morphism

$$\alpha \colon \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p,1}}(\mathbf{G}_{1},\mathbf{X}_{1}) \to \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E_{1}}},$$

which is equivariant for the map  $\alpha \colon \mathbf{G}_1(\mathbb{A}_f^p) \to \mathbf{G}(\mathbb{A}_f^p)$  and models

$$\alpha \colon \operatorname{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1) \to \operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{E_1}.$$

Here by quotient-finite étale we mean that if  $\mathsf{K}_1^p \subseteq \mathbf{G}_1(\mathbb{A}_f^p)$  and  $\mathsf{K}^p \subseteq \mathbf{G}(\mathbb{A}_f^p)$  are neat compact open subgroups such that  $\alpha(\mathsf{K}_1^p) \subseteq \mathsf{K}^p$ , then the induced map

$$\alpha \colon \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^{p}_{1}}(\mathbf{G}_{1}, \mathbf{X}_{1}) \to \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^{p}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{E_{1}}},$$

is a finite étale morphism.

Proof of Proposition 3.24. The fact that such a map is unique is clear by the separatedness of  $\alpha$  and the flatness of  $\mathcal{S}^{\mathfrak{d}}_{\mathsf{K}_{1}^{p}}(\mathbf{G}_{1},\mathbf{X}_{1})$ , which guarantees that its generic fiber is Zariski dense (e.g., see [GW20, Proposition 14.14]).

To see the existence, we note that by definition we have

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p,1}}(\mathbf{G}_{1},\mathbf{X}_{1}) = \left( \left[ \mathscr{S}^{\varnothing}_{\mathsf{K}_{p,2}}(\mathbf{G}_{2},\mathbf{X}_{2})^{+}_{\mathcal{O}_{E_{1}}} imes \mathscr{A}(\boldsymbol{\mathcal{G}}_{1}) \right] / \mathscr{A}(\boldsymbol{\mathcal{G}}_{2})^{\circ} \right)^{J_{1}},$$

and

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E_{1}}} = \left( \left[ \mathscr{S}^{\varnothing}_{\mathsf{K}_{p,2}}(\mathbf{G}_{2},\mathbf{X}_{2})^{+}_{\mathcal{O}_{E_{1}}} \times \mathscr{A}(\boldsymbol{\mathcal{G}}) \right] / \mathscr{A}(\boldsymbol{\mathcal{G}}_{2})^{\circ} \right)^{J}.$$

Now, by Lemma 3.15 and Lemma 3.16 we get morphisms

$$\alpha \colon \mathscr{A}(\mathcal{G}_1) \to \mathscr{A}(\mathcal{G}), \quad \alpha \colon \mathscr{A}(\mathcal{G}_1)^{\circ} \to \mathscr{A}(\mathcal{G}), \text{ and } \alpha \colon \mathscr{E}(\mathcal{G}_1) \to \mathscr{E}(\mathcal{G}).$$

Because  $\alpha(\mathsf{K}_{p,1}) \subseteq \mathsf{K}_p$ , we have a map of sets  $\alpha \colon J_1 \to J$ . Since the isomorphism from (3.5) is natural in these operations, we deduce the existence of a map

$$\left(\left[\mathscr{S}_{\mathsf{K}_{p,2}}^{\varnothing}(\mathbf{G}_{2},\mathbf{X}_{2})_{\mathcal{O}_{E_{1}}}^{+}\times\mathscr{A}(\boldsymbol{\mathcal{G}}_{1})\right]/\mathscr{A}(\boldsymbol{\mathcal{G}}_{2})^{\circ}\right)^{J_{1}}\rightarrow\left(\left[\mathscr{S}_{\mathsf{K}_{p,2}}^{\varnothing}(\mathbf{G}_{2},\mathbf{X}_{2})_{\mathcal{O}_{E_{1}}}^{+}\times\mathscr{A}(\boldsymbol{\mathcal{G}})\right]/\mathscr{A}(\boldsymbol{\mathcal{G}}_{2})^{\circ}\right)^{J},$$

equivariant for  $\alpha \colon \mathbf{G}_1(\mathbb{A}_f^p) \to \mathbf{G}(\mathbb{A}_f^p)$ . That the generic fiber of this map agrees with

$$\alpha \colon \operatorname{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1, \mathbf{X}_1)_{E_1} \to \operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})_{E_1}.$$

follows as in [KP18, Lemma 4.6.13].

Finally, we show that  $\alpha$  is quotient-finite étale. Let  $\mathscr{S}_1^+$  denote a connected component of  $\mathscr{S}_{\mathsf{K}_{p,1}}^{\mathfrak{d}}(\mathbf{G}_1, \mathbf{X}_1)$  mapping to a connected component  $\mathscr{S}^+$  of  $\mathscr{S}_{\mathsf{K}_p}^{\mathfrak{d}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{E_1}}$ . By construction, we have

$$\mathscr{S}_2^+ = \mathscr{S}_{\mathsf{K}_{p,2}}^{\varnothing}(\mathbf{G}_2,\mathbf{X}_2)_{\mathcal{O}_{E_1}}^+/\Delta_1 \quad \text{and} \quad \mathscr{S}^+ = \mathscr{S}_{\mathsf{K}_{p,2}}^{\varnothing}(\mathbf{G}_2,\mathbf{X}_2)_{\mathcal{O}_{E_1}}^+/\Delta,$$

where

$$\Delta_1 = \ker(\mathscr{A}(\mathcal{G}_2)^\circ \to \mathscr{A}(\mathcal{G})) \quad \text{and} \quad \Delta = \ker(\mathscr{A}(\mathcal{G}_2)^\circ \to \mathscr{A}(\mathcal{G})),$$

(see also the arguments of [KP18, Corollary 4.6.15]). Thus  $\mathscr{S}^+$  is the quotient of  $\mathscr{S}_1^+$  by the finite group  $\Delta/\Delta_1$ , and the result follows.

In particular, the proposition implies functoriality for morphisms  $(\mathbf{T}_1, \{h_1\}, \mathcal{T}_1) \to (\mathbf{T}, \{h\}, \mathcal{T})$  of parahoric Shimura data of toral type.

<span id="page-27-2"></span>**3.4.3 Functoriality for abelianizations.** Suppose now that  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a parahoric Shimura datum of abelian type. Consider the parahoric Shimura datum  $(\mathbf{G}^{ab}, \mathbf{X}^{ab}, \mathcal{G}^{ab})$ , where  $\mathbf{X}^{ab}$  is the result of post-composing any element h of  $\mathbf{X}$  with the canonical map  $\delta: \mathbf{G} \to \mathbf{G}^{ab}$ . We have the obvious associated morphism of parahoric Shimura data

$$\alpha \colon (\mathbf{G}, \mathbf{X}, \mathcal{G}) \to (\mathbf{G}^{\mathrm{ab}}, \mathbf{X}^{\mathrm{ab}}, \mathcal{G}^{\mathrm{ab}}).$$

<span id="page-27-1"></span>Write  $\mathsf{K}_p^{\mathrm{ab}} = \mathcal{G}^{\mathrm{ab}}(\mathbb{Z}_p)$ .

Proposition 3.25. There exists a unique

$$\alpha \colon \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X}) \to \mathscr{S}_{\mathsf{K}^{\mathrm{ab}}_{p}}(\mathbf{G}^{\mathrm{ab}}, \mathbf{X}^{\mathrm{ab}})_{\mathcal{O}_{E}},$$

which is equivariant for the map  $\alpha \colon \mathbf{G}_1(\mathbb{A}_f^p) \to \mathbf{G}(\mathbb{A}_f^p)$  and models

$$\alpha \colon \mathrm{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)_{E_1} \to \mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{E_1}.$$

Proof. Given the descriptions of  $\operatorname{Sh}_{\mathsf{K}^{\operatorname{ab}}_p}(\mathbf{G}^{\operatorname{ab}},\mathbf{X}^{\operatorname{ab}})$  and  $\mathscr{S}_{\mathsf{K}^{\operatorname{ab}}_p}(\mathbf{G}^{\operatorname{ab}},\mathbf{X}^{\operatorname{ab}})_{\mathcal{O}_E}$  from (3.13) and Proposition 3.22, respectively, the result follows from Lemma 3.26. More precisely, it suffices to construct maps at every finite level. But, by Proposition 3.22, the Kisin–Pappas–Zhou model S' for  $(\mathbf{G}^{\operatorname{ab}},\mathbf{X}^{\operatorname{ab}})$  base-changed to  $\mathcal{O}_E$  is finite flat over  $S=\operatorname{Spec}(\mathcal{O}_E)$ . On the other hand, the finite levels X of the Kisin–Pappas–Zhou models X for  $(\mathbf{G},\mathbf{X})$  are normal and quasi-projective and flat over S. Thus may apply Lemma 3.26 to the map at finite levels on the generic fiber.

<span id="page-27-0"></span>**Lemma 3.26.** Suppose that S is a scheme and U is an open subscheme of S which is schematically dense and for which the inclusion  $U \hookrightarrow S$  is quasi-compact. Given a diagram

$$X_{U} \longleftrightarrow X$$

$$\downarrow^{\alpha} \qquad \downarrow^{\downarrow}$$

$$S'_{U} \longleftrightarrow S'$$

$$\downarrow^{g}$$

$$U \longleftrightarrow S$$

with X a normal scheme, f quasi-compact, separated, and flat, and g quasi-compact, flat, and integral, there exists a unique arrow dashed arrow as in the diagram above which makes the top square Cartesian.

*Proof.* By [Sta17, Tag 081H],  $X_U \subseteq X$  is schematically dense, so the uniqueness follows from [Sta17, Tag 01RH]. In turn, by uniqueness, we may localize on S and X to prove existence. Using that g is affine, we may then assume without loss of generality that  $S = \operatorname{Spec}(A)$ ,  $S' = \operatorname{Spec}(A')$  and  $A \to A'$  is integral. Moreover, localizing on X we may further assume  $X = \operatorname{Spec}(B)$  with B a normal domain. We then have the following diagram of rings

$$A \xrightarrow{g} A' \xrightarrow{} B$$

$$\downarrow \qquad \qquad \downarrow \qquad \qquad \downarrow$$

$$\mathcal{O}(U) \longrightarrow \mathcal{O}(S'_U) \xrightarrow{\alpha} \mathcal{O}(X_U)$$

<span id="page-28-3"></span>The center and right-hand vertical arrows are injections by flatness of f and g along with [Sta17, Tag 081H] and [Sta17, Tag 01RE].

We claim that  $\alpha(A') \subseteq B$ . Indeed, let  $a' \in A'$ . Then by integrality of  $A \to A'$ , there exists a monic polynomial p(T) in A[T] such that p(a') = 0. But then  $\alpha(a')$  in  $\mathcal{O}(X_U)$  satisfies the monic polynomial f(p)(T) in B[T]. Thus  $\alpha(a')$  must lie in B by normality of B

It follows that we have a map  $\operatorname{Spec}(\alpha):\operatorname{Spec}(B)\to\operatorname{Spec}(A')$ . We claim that the diagram

$$X_U \longleftrightarrow X = \operatorname{Spec}(B)$$

$$\downarrow^{\alpha} \qquad \qquad \downarrow^{\operatorname{Spec}(\alpha)}$$

$$S'_U \longleftrightarrow S' = \operatorname{Spec}(A')$$

is Cartesian. For this it is enough to show that  $\operatorname{Spec}(\alpha)|_{X_U} = \alpha$ . Since  $U \hookrightarrow X$  is quasi-compact, U is quasi-compact, and therefore the same is true of  $S'_U$  and  $X_U$  by quasi-compactness of f and g. Since  $\operatorname{Spec}(\alpha)$  and  $\alpha$  induce the same map  $\mathcal{O}(S'_U) \to \mathcal{O}(X_U)$ , the result now follows from [Sta17, Tag 01P9].

**3.4.4 Two constructions for very good Hodge-type data.** We record here the following basic compatibility between the constructions made in §3.3. Let  $\mathfrak{d} = (\mathbf{G}, \mathbf{X}, \mathcal{G})$  be a very good parahoric Shimura datum of Hodge type.

<span id="page-28-2"></span>**Proposition 3.27.** There is a canonical  $G(\mathbb{A}_f^p)$ -equivariant identification

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X}) \xrightarrow{\sim} \mathscr{S}^{\varnothing}_{\mathsf{K}_{p}}, (\mathbf{G},\mathbf{X}),$$

extending the identity in the generic fiber.

*Proof.* We first construct a  $\mathbf{G}(\mathbb{A}_f^p)$ -equivariant map

$${\mathscr S}^{\mathfrak d}_{{\mathsf K}_p}({\mathbf G},{\mathbf X})_{{\mathcal O}_{(p)}^{\prime p}} o {\mathscr S}^{\varnothing}_{{\mathsf K}_p}({\mathbf G},{\mathbf X})_{{\mathcal O}_{(p)}^{\prime p}}.$$

Choosing a connected component  $X^+$  of X, we obtain an inclusion

$$\mathscr{S}^{\varnothing}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})^+_{\mathcal{O}_{(v)}^{'p}}\hookrightarrow \mathscr{S}^{\varnothing}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{(v)}^{'p}},$$

which extends by the action of  $\mathscr{A}(\mathcal{G})$  to

<span id="page-28-0"></span>
$$\mathscr{S}^{\varnothing}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X})^{+}_{\mathcal{O}^{\prime p}_{(v)}} \times \mathscr{A}(\mathcal{G}) \to \mathscr{S}^{\varnothing}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}^{\prime p}_{(v)}}$$
 (3.15)

via  $(s, a) \mapsto s \cdot a$ . One checks that (3.15) is equivariant for the action of  $\mathscr{A}(\mathcal{G}) \rtimes \mathscr{E}_{\mathbf{E}'}(\mathcal{G})$  on  $\mathscr{S}^{\scriptscriptstyle{\mathcal{S}}}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})^+_{\mathcal{O}^{\scriptscriptstyle{(p)}}_{(p)}} \times \mathscr{A}(\mathcal{G})$ , and it induces

<span id="page-28-1"></span>
$$[\mathscr{S}_{\mathsf{K}_{p}}^{\mathscr{S}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{(p)}^{\prime p}}^{+}\times\mathscr{A}(\mathcal{G})]/\mathscr{A}(\mathcal{G})^{\circ}\to\mathscr{S}_{\mathsf{K}_{p}}^{\mathscr{S}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{(p)}^{\prime p}}.$$
(3.16)

Indeed, this follows by the definition of the action of  $\mathscr{A}(\mathcal{G}) \rtimes \mathscr{E}_{\mathbf{E}'}(\mathcal{G})$  on the product  $\mathscr{S}_{\mathsf{K}_p}^{\scriptscriptstyle \sigma}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{(p)}^{\prime_p}}^{\scriptscriptstyle \sigma} \times \mathscr{A}(\mathcal{G})$  via (3.9) and (3.11), along with the fact that the composition

$$\mathscr{A}(\mathcal{G})^{\circ} o \mathscr{E}_{\mathbf{E}'}(\mathcal{G}) o \mathscr{E}(\mathcal{G}) o \mathscr{A}(\mathcal{G})$$

<span id="page-29-5"></span>is the inclusion  $\mathscr{A}(\mathcal{G})^{\circ} \hookrightarrow \mathscr{A}(\mathcal{G})$ . In turn, (3.16) determines a  $\mathscr{A}(\mathcal{G}) *_{\mathscr{A}(\mathcal{G})^{\circ}} \mathscr{E}_{\mathbf{E}'}(\mathcal{G})$ -equivariant, and hence  $\mathbf{G}(\mathbb{A}_f) \times \mathrm{Gal}(\mathbf{E}'^p/\mathbf{E})$ -equivariant, map

<span id="page-29-0"></span>
$$\mathscr{S}_{\mathsf{K}_{p}}^{\mathfrak{d}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{\prime p}} = \left( [\mathscr{S}_{\mathsf{K}_{p}}^{\mathscr{S}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{\prime p}}^{+} \times \mathscr{A}(\mathcal{G})] / \mathscr{A}(\mathcal{G})^{\circ} \right)^{J} \to \mathscr{S}_{\mathsf{K}_{p}}^{\mathscr{S}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{\prime p}}. \tag{3.17}$$

The map (3.17) is birational, since it is an isomorphism on generic fibers by [KP18, Lemma 4.6.13], and, by its definition, it is quasi-finite. By  $\mathbf{G}(\mathbb{A}_f^p)$ -equivariance, we may first pass to the map (3.17) after taking the quotient by any neat compact open subgroup  $\mathsf{K}^p$  of  $\mathbf{G}(\mathbb{A}_f^p)$ . In that case, the target is normal, so it follows that the quotient of (3.17) by  $\mathsf{K}^p$  is an open immersion on connected components by Lemma 3.21 and [GW20, Corollary 12.88]. Passing to the limit, we deduce that (3.17) is an open immersion. Moreover, (3.17) is surjective by part (2) of Theorem 3.12<sup>11</sup>, so it is an isomorphism.

**3.4.5** Kisin–Pappas–Zhou integral models for some products. Let  $\mathfrak{d} = (\mathbf{G}, \mathbf{X}, \mathcal{G})$  be a very good parahoric Shimura datum of Hodge type, and that  $(\mathbf{T}, \{h\}, \mathcal{T})$  is a parahoric Shimura datum of toral type. Write  $\mathbf{E}'$  for the compositum of the reflex fields of the two Shimura data, which is the reflex field of  $(\mathbf{G} \times \mathbf{T}, \mathbf{X} \times \{h\})$ , and set  $M_p = \mathcal{T}(\mathbb{Z}_p)$ .

<span id="page-29-4"></span>**Proposition 3.28.** There is a canonical  $\mathbf{G}(\mathbb{A}_f^p) \times \mathbf{T}(\mathbb{A}_f^p)$ -equivariant identification

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{n}\times\mathsf{M}_{n}}(\mathbf{G}\times\mathbf{T},\mathbf{X}\times\{h\})\overset{\sim}{\longrightarrow}\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{n}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E'}}\times\mathscr{S}_{\mathsf{M}_{p}}(\mathbf{T},\{h\})_{\mathcal{O}_{E'}}.$$

*Proof.* The projection map  $\mathbf{G} \times \mathbf{T} \to \mathbf{G}$  is an ad-isomorphism, so by Proposition 3.24, we have a quotient-finite map

<span id="page-29-3"></span>
$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}\times\mathsf{M}_{p}}(\mathbf{G}\times\mathbf{T},\mathbf{X}\times\{h\})\to\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E'}}$$
 (3.18)

extending the morphism on the generic fibers which is equivariant for the projection  $(\mathbf{G} \times \mathbf{T})(\mathbb{A}_f^p) \to \mathbf{G}(\mathbb{A}_f^p)$ . On the other hand, the map of reductive groups  $\mathbf{G} \times \mathbf{T} \to \mathbf{T}$  factors through  $(\mathbf{G} \times \mathbf{T})^{\mathrm{ab}}$ , which is a torus. Hence Proposition 3.24 and Proposition 3.25 combine to furnish us with a map

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}\times\mathsf{M}_{p}}(\mathbf{G}\times\mathbf{T},\mathbf{X}\times\{h\})\to\mathscr{S}_{\mathsf{M}_{p}}(\mathbf{T},\{h\})_{\mathcal{O}_{E'}}$$

extending the morphism on generic fibers, which is equivariant for  $(\mathbf{G} \times \mathbf{T})(\mathbb{A}_f^p) \to \mathbf{T}(\mathbb{A}_f^p)$ . From these, we obtain the map

<span id="page-29-2"></span>
$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}\times\mathsf{M}_{p}}(\mathbf{G}\times\mathbf{T},\mathbf{X}\times\{h\})\to\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E'}}\times\mathscr{S}_{\mathsf{M}_{p}}(\mathbf{T},\{h\})_{\mathcal{O}_{E'}},\tag{3.19}$$

which is equivariant for  $(\mathbf{G} \times \mathbf{T})(\mathbb{A}_f^p) \xrightarrow{\sim} \mathbf{G}(\mathbb{A}_f^p) \times \mathbf{T}(\mathbb{A}_f^p)$ . The map (3.19) is an isomorphism on generic fibers, and is quasi-finite at each finite level because (3.18) is quotient-finite. It follows that (3.19) is an isomorphism by the argument at the end of the proof of Proposition 3.27.

<span id="page-29-1"></span><sup>11</sup>Indeed, it is enough to show (3.17) is surjective on special fibers. An  $\overline{\mathbb{F}}_p$ -point of  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{'p}}$  factors through an R-point of  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{'p}}$ , where R is a discrete valuation ring of characteristic (0, p) (see [Sta17, Tag 0CM2]). This, in turn, induces an R[1/p]-point of  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{'p}}$ . We can pull this point back along the isomorphism on generic fibers, and the result lifts to an R-point of  $\mathscr{S}_{\mathsf{K}_p}^{\lozenge}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{'p}}$  by part (2) of Theorem 3.12. This maps to the original  $\overline{\mathbb{F}}_p$ -point of  $\mathscr{S}_{\mathsf{K}_p}^{\varnothing}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{(v)}^{'p}}$  by separatedness, as they generically agree.

### THE PAPPAS-RAPOPORT CONJECTURE

<span id="page-30-3"></span><span id="page-30-0"></span>In this section we state the Pappas-Rapoport conjecture and recall the cases in which it has been previously proven. We also state our main theorem and applications.

As in §3.3, throughout this section we often use the following notation and data:

- (G, X) is a Shimura datum,
- **Z** is the center of **G**,
- E is the reflex field of (G, X),
- v is a p-adic place of  $\mathbf{E}$ ,
- $E = \mathbf{E}_v$ ,
- $k_E$  is the residue field of E,

- $G = \mathbf{G}_{\mathbb{Q}_p}$ ,  $\mathcal{G} = \mathcal{G}_x^{\circ}$  is a parahoric model of G,
- ullet  $\mathsf{K}_p := \mathcal{G}(\mathbb{Z}_p),$
- $\mathsf{K}^p \subseteq \mathbf{G}(\mathbb{A}_n^f)$  is a neat compact open subgroup,
- $K = K_n K^p$ .
- <span id="page-30-1"></span>4.1 The Pappas-Rapoport conjecture. We now recall the formulation of the Pappas-Rapoport conjecture as given in [PR21] and extended in [Dan22].
- The group  $\mathcal{G}^c$ . In constrast to the case of Shimura varieties of Hodge type discussed in [PR21], to obtain shtukas on arbitrary Shimura varieties of abelian type, one must consider a modification  $\mathcal{G}^c$  of the parahoric group  $\mathcal{G}$ .

Let T be a multiplicative group over  $\mathbb{Q}$ . We denote by  $T_{\mathrm{ac}}$  the anti-cuspidal part of **T** as in [KSZ21, Definition 1.5.4]. More precisely, if  $T_a$  denotes the largest anisotropic subtorus of  $\mathbf{T}$ , then  $\mathbf{T}_{ac}$  is the largest subtorus of  $\mathbf{T}_a$  whose base change to  $\mathbb{R}$  contains the maximal split subtorus of  $(\mathbf{T}_a)_{\mathbb{R}}$ .

We write  $\mathbf{G}^c$  for the quotient  $\mathbf{G}^c/\mathbf{Z}_{ac}$ , and if H is a subgroup of  $\mathbf{G}(\mathbb{A}_f)$ , we write  $\mathsf{H}^c$  for the image of  $\mathsf{H}$  under  $\mathbf{G}(\mathbb{A}_f) \to \mathbf{G}^c(\mathbb{A}_f)$ . We also denote by  $G^c$  the base change of  $\mathbf{G}^c$  to  $\mathbb{Q}_p$ . The following lemma will be used below.

<span id="page-30-2"></span>**Lemma 4.1.** If  $\alpha: (\mathbf{G}_1, \mathbf{X}_1) \to (\mathbf{G}, \mathbf{X})$  is a morphism of Shimura data then  $\alpha(\mathbf{Z}_{1,\mathrm{ac}}) \subseteq \mathbf{Z}_{\mathrm{ac}}$ and so  $\alpha$  induces a map  $\alpha \colon \mathbf{G}_1^c \to \mathbf{G}^c$ . Consequently, if  $(\mathbf{G}, \mathbf{X})$  is of Hodge type, then the natural maps  $\mathbf{G} \to \mathbf{G}^c$  and  $\mathbf{G}^{ab} \to (\mathbf{G}^{ab})^c$  are isomorphisms.

*Proof.* The first claim is [IKY23, Lemma 4.7]. The second claim then follows from the first by embedding an arbitrary Hodge type datum (G, X) into one of Siegel type  $(G_1, X_1)$ , where it can be explicitly checked that  $\mathbf{Z}_{1,\mathrm{ac}}$  is trivial. For the claim concerning  $\mathbf{G}^{\mathrm{ab}}$ , we observe that the map  $\delta \colon \mathbf{G} \to \mathbf{G}^{\mathrm{ab}}$  restricts to a surjection  $\delta \colon \mathbf{Z} \to \mathbf{G}^{\mathrm{ab}}$  (e.g., see [Mil17, Example 19.25]). From here, it's easy to check that  $\delta$  surjects  $\mathbf{Z}_{ac}$  onto  $\mathbf{G}_{ac}^{ab}$ , and the claim follows.

We set  $\mathcal{G}^c$  to be the parahoric model of **G** induced by  $\mathcal{G}$  in the sense of §2.1.5. By construction, we see that  $G \to G^c$  extends to a morphism of group  $\mathbb{Z}_p$ -schemes  $\mathcal{G} \to \mathcal{G}^c$ . For a conjugacy class of cocharacters  $\mu$  of  $G_{\overline{\mathbb{Q}}_n}$ , we denote by  $\mu^c$  the image of this conjugacy class under  $G_{\overline{\mathbb{Q}}_p} \to G_{\overline{\mathbb{Q}}_p}^c$ .

The shtuka over  $Sh_K(G, X)_E$ . We now recall the existence of a "universal shtuka" which lives over the Shimura variety  $Sh_{K}(G, X)_{E}$ , as in [PR21, §4.1] and [Dan22,

For a normal compact open subgroup  $\mathsf{K}'_p\subseteq\mathsf{K}_p$ , we temporarily write  $\mathsf{K}'$  for the product  $\mathsf{K}'_{n}\mathsf{K}^{p}$ . Then the transition morphism

$$\pi_{\mathsf{K}',\mathsf{K}} \colon \operatorname{Sh}_{\mathsf{K}'}(\mathbf{G}, \mathbf{X})_E \to \operatorname{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})_E$$
 (4.1)

<span id="page-31-1"></span>is a finite étale Galois cover with Galois group  $K_p/(K_p'\mathbf{Z}(\mathbb{Q})_K^-)$ , where  $\mathbf{Z}(\mathbb{Q})_K^-$  is the closure of  $\mathbf{Z}(\mathbb{Q}) \cap K$  in K (see [KSZ21, §1.5.8]). We consider the infinite-level Shimura variety

$$\operatorname{Sh}_{\mathsf{K}^p}(\mathbf{G}, \mathbf{X})_E := \varprojlim_{\mathsf{K}_p' \subseteq \mathsf{K}_p} \operatorname{Sh}_{\mathsf{K}_p'}(\mathbf{G}, \mathbf{X})_E,$$

which exists as an E-scheme as each  $\pi_{K',K}$  is affine (see [Sta17, Tag 01YX]), and forms a  $K_p/\mathbf{Z}(\mathbb{Q})_K^-$ -torsor for the pro-etale site (in the sense of [BS15]) on  $\mathrm{Sh}_K(\mathbf{G},\mathbf{X})_E$ .

The map  $\mathsf{K}_p \to \mathcal{G}^c(\mathbb{Z}_p)$  factorizes through  $\mathsf{K}_p/\mathbf{Z}(\mathbb{Q})_{\mathsf{K}}^-$  (see [KSZ21, §1.5.8]). Thus, as in [Dan22, §4.2] or [IKY23, §2.1.5 and §4.3], from the  $\mathsf{K}_p/\mathbf{Z}(\mathbb{Q})_{\mathsf{K}}^-$ -torsor

$$\operatorname{Sh}_{\mathsf{K}^p}(\mathbf{G},X)_E \to \operatorname{Sh}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},X)_E,$$

<span id="page-31-0"></span>one constructs a  $\mathcal{G}^c(\mathbb{Z}_p)$  torsor  $\mathbb{P}_{\mathsf{K}}$  on the pro-étale site (see [Sch13]) of  $\mathrm{Sh}_{\mathsf{K}}(\mathbf{G},X)_E^{\mathrm{an}}$ .

**Proposition 4.2** ([PR21, Proposition 4.1.4] and [Dan22, Proposition 4.4]). There exists a  $\mathcal{G}^c$ -shtuka  $\mathscr{P}_{\mathsf{K},E}$  over  $\mathrm{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})_E^{\Diamond} \to \mathrm{Spd}(E)$  with one leg bounded by  $\mu_h^c$  which is associated to  $\mathbb{P}_{\mathsf{K}}$  in the sense of [PR21, §2.5]. Moreover, if  $\mathsf{K}' = \mathsf{K}_p \mathsf{K}^{p'}$  and g is in  $\mathbf{G}(\mathbb{A}_f^p)$  is such that  $g^{-1}\mathsf{K}^p g \subseteq \mathsf{K}^{p'}$ , there exists compatible isomorphisms

$$t_{\mathsf{K},\mathsf{K}'}(g)^*(\mathscr{P}_{\mathsf{K}',E}) \xrightarrow{\sim} \mathscr{P}_{\mathsf{K},E}.$$
 (4.2)

**4.1.3 Integral local Shimura varieties.** Let us define (see [SW20, Definition 24.1.1]), a parahoric local Shimura datum to be a triple  $(\mathcal{G}, b, \mu)$  where

- $\mathcal{G}$  is a parahoric group  $\mathbb{Z}_p$ -scheme with generic fiber G,
- $\mu$  is a conjugacy class of minuscule cocharacters of  $G_{\overline{\mathbb{Q}}_n}$ ,
- and b is an element of  $G(\tilde{\mathbb{Q}}_p)$  inducing an element of  $B(G, \mu^{-1})$  (see [RV14, Definition 2.3]).

The reflex field of  $(\mathcal{G}, b, \mu)$ , usually denoted E, is the field of definition of  $\mu$ . A morphism  $f: (\mathcal{G}_1, b_1, \mu_1) \to (\mathcal{G}, b, \mu)$  of parahoric local Shimura datum is a morphism of  $\mathbb{Z}_p$ -group schemes  $f: \mathcal{G}_1 \to \mathcal{G}$  carrying  $\mu_1$  to  $\mu$  and  $b_1$  to b. If such a morphism exists, then  $E_1 \supseteq E$ . We say that f is an ad-isomorphism if  $f: G_1 \to G$  is an ad-isomorphism.

Given a parahoric local Shimura datum  $(\mathcal{G}, b, \mu)$  with reflex field E, we obtain a presheaf

$$\mathcal{M}^{\mathrm{int}}_{\mathcal{G},b,\mu}\colon \mathbf{Perf}_{\mathcal{O}_{reve{E}}} o \mathbf{Set}$$

assigning to any perfectoid space S in characteristic p the set of isomorphism classes of tuples  $(S^{\sharp}, \mathscr{P}, \phi_{\mathscr{P}}, i_r)$ , where:

- $S^{\sharp}$  is the untilt of S over  $\mathcal{O}_{\check{E}}$  associated with  $S \to \operatorname{Spd}(\mathcal{O}_{\check{E}})$ ,
- $(\mathscr{P}, \phi_{\mathscr{P}})$  is a  $\mathscr{G}$ -shtuka on S with one leg along  $S^{\sharp}$  which is bounded by  $\mu$  (see [PR21, Definition 2.4.3]),
- and  $i_r$  is an isomorphism of  $\mathcal{G}$ -torsors  $\mathcal{G}|_{\mathcal{Y}_{[r,\infty)}(S)} \stackrel{\sim}{\longrightarrow} \mathscr{P}|_{\mathcal{Y}_{[r,\infty)}(S)}$  for large enough r, under which  $\phi_{\mathscr{P}}$  is identified with  $b \times \operatorname{Frob}_S$  (see [SW20, §25.1]).

By [SW20, §25.1] and [Gle20, Proposition 2.23], the presheaf  $\mathcal{M}_{\mathcal{G},b,\mu}^{\mathrm{int}}$  is a small v-sheaf (in the sense of [Sch17, Definition 12.1]), which is called the integral local Shimura variety associated to the local Shimura datum  $(\mathcal{G}, b, \mu)$ .

<span id="page-32-2"></span>If  $k_E$  denotes the residue field of E, then by [Gle22, Proposition 2.30], we have a natural identification

<span id="page-32-0"></span>
$$\mathcal{M}_{G,b,\mu}^{\text{int}}(\operatorname{Spd}(\bar{k}_E)) = X_{\mathcal{G}}(b,\mu^{-1})(\bar{k}_E), \tag{4.3}$$

where  $X_{\mathcal{G}}(b, \mu^{-1})$  denotes the affine Deligne-Lusztig variety associated to the triple  $(\mathcal{G}, b, \mu^{-1})$  (see [PR21, Definition 3.3.1]). For any point x of  $\mathcal{M}^{\text{int}}_{\mathcal{G},b,\mu}(\operatorname{Spd}(\bar{k}_E))$  we write  $(\mathcal{M}^{\text{int}}_{\mathcal{G},b,\mu})^{\wedge}_{/x}$  for the formal completion of  $\mathcal{M}^{\text{int}}_{\mathcal{G},b,\mu}$  at x in the sense of [Gle22].

**4.1.4** The conjecture of Pappas and Rapoport. We now state the Pappas–Rapoport conjecture. For details, see [PR21, §4.2] and [Dan22, §4.3].

Suppose we have a normal flat  $\mathcal{O}_E$ -model  $\mathscr{S}_K$  of  $\operatorname{Sh}_K(\mathbf{G}, \mathbf{X})_E$ , equipped with an extension  $\mathscr{P}_K$  of the  $\mathscr{G}^c$ -shtuka  $\mathscr{P}_{K,E}$  to a  $\mathscr{G}^c$ -shtuka defined over  $\mathscr{S}_K^{\Diamond/}$ . Note that  $\mathscr{P}_K$  is necessarily bounded by  $\mu_h^c$  by [Dan22, Lemma 2.1].

For any point x of  $\mathscr{S}_{\mathsf{K}}(\bar{k}_E)$ , the pullback  $x^*\mathscr{P}_{\mathsf{K}}$  defines a  $\mathscr{G}^c$ -shtuka over  $\mathrm{Spd}(\bar{k}_E)$ . In turn, by [PR21, Example 2.4.9],  $x^*\mathscr{P}_{\mathsf{K}}$  determines a pair  $(\mathcal{P}_x, \phi_x)$  consisting of a  $\mathscr{G}^c$ -torsor  $\mathcal{P}_x$  over  $\mathrm{Spec}(W(\bar{k}_E))$  along with an isomorphism

$$\phi_x: \phi^*(\mathcal{P})[1/p] \xrightarrow{\sim} \mathcal{P}_x[1/p].$$

Here  $\phi$  denotes the Frobenius homomorphism for  $W(\bar{k}_E)$ . After choosing a trivialization of  $\mathcal{P}_x$ , we obtain an element  $b_x$  in  $G^c(\check{\mathbb{Q}}_p)$ , and changing the trivialization will change  $b_x$  to some  $\sigma$ -conjugate of  $b_x$ . Therefore we obtain a well-defined conjugacy class  $[b_x]$  in  $B(G^c)$ .

Since the shtuka  $\mathscr{P}_{\mathsf{K}}$  is bounded by  $\mu_h^c$ , the same holds for  $(\mathcal{P}_x, \phi_x)$ , so the pair  $(\mathcal{P}_x, \mathrm{id})$  determines a point  $x_0$  of  $X_{\mathcal{G}}^c(b_x, (\mu_h^c)^{-1})(\bar{k}_E)$ . Hence  $X_{\mathcal{G}}(b_x, \mu_h^{-1})(\bar{k}_E)$  is nonempty, so by [He16, Theorem A], it follows that  $[b_x]$  belongs to  $B(G^c, (\mu_h^c)^{-1})$ . Then the triple  $(\mathcal{G}^c, b_x, \mu_h^c)$  defines a parahoric local Shimura datum, and we can consider the integral local Shimura variety  $\mathcal{M}_{\mathcal{G}^c, b_x, \mu_h^c}^{\mathrm{int}}$  along with the base point  $x_0$  (which makes sense by (4.3)).

<span id="page-32-1"></span>**Definition 4.3** ([PR21, Conjecture 4.2.2] and [Dan22, Conjecture 4.5]). Consider a system  $\{\mathscr{S}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^p}$  of normal flat  $\mathscr{O}_E$ -models  $\mathscr{S}_{\mathsf{K}}$  of  $\mathrm{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})$  for  $\mathsf{K} = \mathsf{K}_p \mathsf{K}^p$  with  $\mathsf{K}^p$  varying over all sufficiently small compact open subgroups of  $\mathbf{G}(\mathbb{A}_f^p)$ .

We say the system  $\{\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  is an canonical integral model for  $\{\mathrm{Sh}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  if the following properties are satisfied.

(i) For every discrete valuation ring R of characteristic (0, p) over  $\mathcal{O}_E$ ,

$$\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})(R[1/p]) = \left(\varprojlim_{\mathsf{K}^p} \mathscr{S}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})\right)(R). \tag{4.4}$$

(ii) For every sufficiently small  $\mathsf{K}^p \subseteq \mathbf{G}(\mathbb{A}^p_f)$  and  $\mathsf{K}'^p \subseteq \mathbf{G}(\mathbb{A}^p_f)$ , and element g of  $\mathbf{G}(\mathbb{A}^p_f)$  with  $g^{-1}\mathsf{K}^pg\subseteq \mathsf{K}^p$ , there are finite étale morphisms

$$t_{\mathsf{K},\mathsf{K}'}(g) \colon \mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X}) \to \mathscr{S}_{\mathsf{K}'}(\mathbf{G},\mathbf{X})$$

extending the corresponding maps on the generic fiber.

(iii) The  $\mathcal{G}^c$ -shtuka  $\mathscr{P}_{\mathsf{K},E}$  extends to a  $\mathcal{G}^c$ -shtuka  $\mathscr{P}_{\mathsf{K}}$  on  $\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})^{\lozenge/}$  for every sufficiently small  $\mathsf{K}^p \subseteq \mathbf{G}(\mathbb{A}_f^p)$ .

<span id="page-33-7"></span>(iv) Consider x in  $\mathscr{S}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})(\bar{k}_E)$  with corresponding element  $b_x$  of  $G(\mathbb{Q}_p)$ , and let  $x_0$  be the natural base point in  $\mathcal{M}^{\mathrm{int}}_{G^c, b_x, \mu_c^c}(\bar{k}_E)$ . Then there is an isomorphism of v-sheaves

$$\Theta_x : \left( \mathcal{M}_{\mathcal{G}^c, b_x, \mu_h^c}^{\text{int}} \right)_{/x_0}^{\wedge} \xrightarrow{\sim} \left( \mathscr{S}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})_{/x}^{\wedge} \right)^{\Diamond}, \tag{4.5}$$

such that  $\Theta_x^*(\mathscr{P}_{\mathsf{K}})$  agrees with the universal  $\mathscr{G}^c$ -shtuka  $\mathscr{P}^{\mathrm{univ}}$  on  $\mathcal{M}^{\mathrm{int}}_{\mathscr{G}^c,b_x,\mu_b^c}$ .

We observe the following uniqueness properties concerning a system of models satisfying the Pappas–Rapoport conjecture.

<span id="page-33-4"></span>**Proposition 4.4** (cf. [PR21, Corollary 2.7.10 and Theorem 4.2.4]). An canonical integral model of  $\{Sh_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  and the  $\mathcal{G}^c$ -shtukas  $\mathscr{P}_{\mathsf{K}}$  on these canonical integral models, are unique up to unique isomorphism (if they exist).

<span id="page-33-3"></span>The following is then what we refer to as the Pappas-Rapoport conjecture.

Conjecture 4.5 (Pappas-Rapoport). For any parahoric Shimura datum  $(\mathcal{G}, \mathbf{G}, \mathbf{X})$ , there exists an canonical integral model for  $\{\mathrm{Sh}_{\mathsf{K}}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^p}$ .

Conjecture 4.5 is known in the following cases, where we have elected to use our notation from §3.3 for maximal clarity.

<span id="page-33-5"></span>**Theorem 4.6** ([PR21, Theorem 4.5.2] and [DvHKZ24b, Corollary 4.1.5]). For any parahoric Shimura datum  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  of Hodge type, the system  $\{\mathscr{S}_{\mathsf{K}}^{\varnothing}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^p}$  satisfies the conditions of the Pappas–Rapoport conjecture.

<span id="page-33-2"></span>Remark 4.7. In [PR21], Pappas and Rapoport prove the conjecture under the stubborn technical assumption that  $K_p$  is a *stabilizer* parahoric, i.e., where  $K_p = \mathcal{G}(\mathbb{Z}_p)$  for a parahoric group scheme  $\mathcal{G}$  which is also the Bruhat–Tits stabilizer group scheme of a point in the extended Bruhat–Tits building of G. This assumption frequently holds; for example every parahoric  $\mathbb{Z}_p$ -model of G is of this form if  $\pi_1(G)_I$  is torsion free. That says, it eliminates many examples of Shimura varieties of abelian type (e.g., many cases of type  $D^{\mathbb{H}}$ ). The theorem was subsequently extended to arbitrary Shimura data of Hodge type in [DvHKZ24b].

<span id="page-33-6"></span>**Theorem 4.8** ([Dan22, Theorem A]). If  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a parahoric Shimura datum of toral type, then  $\{\mathscr{S}_{\mathbf{K}}(\mathbf{G}, \mathbf{X})\}_{\mathbf{K}^p}$  satisfies the conditions of the Pappas–Rapoport conjecture.

*Proof.* This follows from [Dan22, Theorem A] along with Proposition 3.22.  $\Box$ 

**Theorem 4.9** ([IKY23, Proposition 5.35]). If  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a parahoric Shimura datum of abelian type where  $\mathcal{G}$  is reductive, then the canonical integral models  $\{\mathscr{S}_{\mathsf{K}}^{\mathrm{Kis}}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^p}$  from [Kis10] satisfy the conditions of the Pappas–Rapoport conjecture.

<span id="page-33-0"></span>**4.2 Statement of the main result and applications.** We now state our main result and give some applications to the study of Kisin–Pappas–Zhou models.

<span id="page-33-1"></span>**Theorem 4.10.** Let  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  be an acceptable parahoric Shimura data of abelian type, and let  $\mathfrak{d}$  be a well-adapted very good parahoric Shimura datum of Hodge type. Then, the system  $\{\mathcal{S}^{\mathsf{K}}_{\mathsf{N}}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^{p}}$  satisfies the conditions of the Pappas-Rapoport conjecture.

As an immediate implication, and as an opportunity to reemphasize the mildness of the acceptability condition, we record the following corollary.

<span id="page-34-3"></span>**Corollary 4.11.** Suppose that p > 3. Then, the Pappas–Rapoport conjecture holds for all parahoric Shimura data of abelian type.

In addition, utilizing Proposition 4.4, and the previously known cases of the Pappas–Rapoport conjecture stated above, we can deduce the following omnibus independence result where, again, we are using notation from §3.3.

<span id="page-34-1"></span>**Corollary 4.12.** Suppose that  $(G, X, \mathcal{G})$  is an acceptable parahoric Shimura datum of abelian type. Then, the following statements are true.

- (1) The system  $\{\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  is canonically independent of the choice of  $\mathfrak{d}$ .
- (2) If  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$  is of Hodge type, then the system  $\{\mathscr{S}_{\mathsf{K}}^{\varnothing}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^{p}}$  is canonically isomorphic to the system  $\{\mathscr{S}_{\mathsf{K}}^{\mathfrak{d}}(\mathbf{G}, \mathbf{X})\}_{\mathsf{K}^{p}}$  for any  $\mathfrak{d}$ .
- (3) If  $\mathcal{G}$  is reductive then the system  $\{\mathscr{S}_{\mathsf{K}}^{\mathrm{Kis}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  is canonically isomorphic to the system  $\{\mathscr{S}_{\mathsf{K}}^{\mathfrak{d}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  for any  $\mathfrak{d}$ .

Given this independence result, the notation  $\{\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$  and  $\mathscr{S}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})$  for any of the systems of models discussed in §3.3 is unambiguous.

**Remark 4.13.** One implication of Corollary 4.12 is the fact that the more naively constructed models  $\mathscr{S}_{\mathsf{K}^p}^{\varnothing}(\mathbf{G}, \mathbf{X})$  possess a local model diagram (e.g., see (3) of [KZ21, Theorem 5.2.12]) even if [KZ21, Condition (5.1.11.1)] does not hold. Indeed, this follows by combining [KZ21, Theorem 5.2.12] and (2) of Corollary 4.12.

<span id="page-34-2"></span>Lastly, we observe that Theorem 4.10 implies functoriality for the systems  $\{\mathscr{S}_{\mathsf{K}}(\mathbf{G},\mathbf{X})\}_{\mathsf{K}^p}$ .

**Theorem 4.14.** Suppose that  $\alpha \colon (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1) \to (\mathbf{G}, \mathbf{X}, \mathcal{G})$  is a morphism of acceptable parahoric Shimura data of abelian type. Then, there exists a unique morphism

$$\alpha \colon \mathscr{S}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1) \to \mathscr{S}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E_1}},$$

which is equivariant for the map  $\alpha \colon \mathbf{G}_1(\mathbb{A}_f^p) \to \mathbf{G}(\mathbb{A}_f^p)$ , and whose generic fiber recovers the map

$$\alpha \colon \mathrm{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)_{E_1} \to \mathrm{Sh}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{E_1}.$$

*Proof.* This follows from the arguments of [PR21, Corollary 4.3.2], and [DvHKZ24b, Corollary 4.0.9]. We replicate the proof here for completeness.

We first observe, as in [PR21, Proof of Corollary 4.3.2], that the product

$$\mathscr{S}'' := \mathscr{S}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1) \times_{\operatorname{Spec} \mathcal{O}_{E_1}} \mathscr{S}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E_1}}$$

determines an integral model of  $\operatorname{Sh}_{\mathsf{K}_{p,1}\times\mathsf{K}_p}(\mathbf{G}_1\times\mathbf{G},\mathbf{X}_1\times\mathbf{X})$  which satisfies Conjecture 4.5. Then by [PR21, Theorem 4.3.1], the graph of  $\alpha$  determines a unique morphism of integral models  $\mathscr{S}_{\mathsf{K}_{p,1}}(\mathbf{G}_1,\mathbf{X}_1)\to\mathscr{S}''$  which extends the graph of  $\alpha$  on the generic fiber. We obtain the desired morphism by composition with the projection  $\mathscr{S}''\to\mathscr{S}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{E_1}$ .

<span id="page-34-0"></span>**Remark 4.15.** We remark that Theorem 4.14 is also proved in [vHS24], by establishing a modified version of Conjecture 4.5 using  $\mathcal{G}^{ad}$  in place of  $\mathcal{G}^c$ ; see Remark 1.1.

#### 5 The proof of the main result

This final section is devoted to the proof of our main theorem (Theorem 4.10). This will require the development of multiple ancillary concepts and results that we hope will be useful in other contexts. We fix notation as at the beginning of §4.

- <span id="page-35-1"></span><span id="page-35-0"></span>5.1 An auxiliary Kisin–Pappas–Zhou model. A useful heuristic for Shimura data of abelian type is that they are 'spanned' by two (largely orthogonal) extremes: Shimura data of Hodge type and Shimura data of toral type. Finding a precise formalism to realize this heuristic, especially when their integral models are part of the picture, is somewhat subtle. That said, this was achieved at hyperspecial level by Lovering in [Lov17a]. The goal of this subsection is to extend this formalism to the Kisin–Pappas–Zhou models of §3.
- 5.1.1 The Lovering construction. We begin by recalling the underlying Shimura datum as defined in [Lov17a,  $\S4.6$ ]. Let us fix an extension  $\mathbf{E}'$  of  $\mathbf{E}$ . Define then the group

$$\mathbf{B}_{\mathbf{E}'} := \mathbf{G} \times_{\delta, \mathbf{G}^{\mathrm{ab}}, r} \mathbf{T}_{\mathbf{E}'},$$

where  $\mathbf{T}_{\mathbf{E}'} := \operatorname{Res}_{\mathbf{E}'/\mathbb{Q}} \mathbb{G}_{m,\mathbf{E}'}$ ,  $\delta$  is the canonical map  $\mathbf{G} \to \mathbf{G}^{ab}$ , and r is obtained as the composition

$$\operatorname{Res}_{\mathbf{E}'/\mathbb{Q}} \mathbb{G}_{m,\mathbf{E}'} \xrightarrow{\operatorname{Res}_{\mathbf{E}'/\mathbb{Q}} \mu_h} \operatorname{Res}_{\mathbf{E}'/\mathbb{Q}} \mathbf{G}_{\mathbf{E}'}^{\operatorname{ab}} \xrightarrow{N} \mathbf{G}^{\operatorname{ab}}.$$

Here  $\mu_h \colon \mathbb{G}_{m,\mathbf{E}'} \to \mathbf{G}_{\mathbf{E}'}^{\mathrm{ab}}$  denotes the composition  $\delta \circ \mu$  for any element  $\mu$  of  $\mu_h$ , which is defined over  $\mathbf{E}'$  by the definition of reflex field and independent of choice since  $\mathbf{G}_{\mathbb{C}}^{\mathrm{ab}}$  is abelian, and N denotes the natural norm map. Observe that  $\mathbf{B}_{\mathbf{E}'}^{\mathrm{der}} = \mathbf{G}^{\mathrm{der}}$ , so we have a short exact sequence

$$1 \to \mathbf{G}^{\mathrm{der}} \to \mathbf{B}_{\mathbf{E}'} \to \mathbf{T}_{\mathbf{E}'} \to 1.$$

Furthermore, we have an exact sequence

$$1 \to \mathbf{B}_{\mathbf{E}'} \to \mathbf{G} \times \mathbf{T}_{\mathbf{E}'} \xrightarrow{(x,y) \mapsto \delta^{-1}(x)r(y)} \mathbf{G}^{\mathrm{ab}} \to 1,$$

and thus  $\mathbf{B}_{\mathbf{E}'}$  is reductive (see [Mil17, Corollary 21.53]).

Let  $\{\tau\}$  be the set of archimedean places of  $\mathbf{E}'$ , and let  $\{[\tau]\}$  denote the set of equivalences classes under the relation  $\tau \sim \overline{\tau}$ . Let  $\tau_0 \colon \mathbf{E}' \to \mathbb{C}$  be the natural inclusion which defines an element  $[\tau_0]$  of  $\{[\tau]\}$ . Then, we have that  $\mathbf{E}' \otimes_{\mathbb{Q}} \mathbb{R}$  is isomorphic to  $\prod_{[\tau]} \mathbf{E}'_{[\tau]}$ , where  $\mathbf{E}'_{[\tau]}$  is  $\mathbb{R}$  or  $\mathbb{C}$  if  $\tau$  is real or complex, respectively. We define

$$h_{\mathbf{T}} \colon \mathbb{S} \to (\mathbf{T}_{\mathbf{E}'})_{\mathbb{R}} = \prod_{[\tau]} \mathrm{Res}_{\mathbf{E}'_{\tau}/\mathbb{R}} \, \mathbb{G}_{m,\mathbf{E}'_{[\tau]}},$$

to be the unique morphism having trivial projection  $h_{\mathbf{T}_{\mathbf{E}'},[\tau]}$  to every  $[\tau]$  not equal to  $[\tau_0]$ , and satisfying

$$h_{\mathbf{T}_{\mathbf{E}'},[\tau_0]}(z) = \begin{cases} z\overline{z} & \text{if} \quad \tau_0 \text{ is real,} \\ z & \text{if} \quad \tau_0 \text{ is complex,} \end{cases}$$

for z in  $\mathbb{S}(\mathbb{R}) = \mathbb{C}^{\times}$ .

One may show (see [Lov17a, Proposition 4.6.5]) that for any element h of X, the pair

$$(h, h_{\mathbf{T}_{\mathbf{E}'}}) \colon \mathbb{S} \to \mathbf{G}_{\mathbb{R}} \times (\mathbf{T}_{\mathbf{E}'})_{\mathbb{R}},$$
 (5.1)

factorizes through  $(\mathbf{B}_{\mathbf{E}'})_{\mathbb{R}}$ , that the resulting  $\mathbf{B}_{\mathbf{E}'}(\mathbb{R})$ -conjugacy class  $\mathbf{Y}_{\mathbf{E}'}$  is independent of the choice of h, and that the pair  $(\mathbf{B}_{\mathbf{E}'}, \mathbf{Y}_{\mathbf{E}'})$  is a Shimura datum with reflex field  $\mathbf{E}'$ .

<span id="page-36-3"></span>Moreover, there is a commutative diagram of Shimura data:

<span id="page-36-1"></span>
$$(\mathbf{B}_{\mathbf{E}'}, \mathbf{Y}_{\mathbf{E}'}) \longrightarrow (\mathbf{T}_{\mathbf{E}'}, \{h_{\mathbf{T}}\})$$

$$\downarrow \qquad \qquad \downarrow$$

$$(\mathbf{G}, \mathbf{X}) \longrightarrow (\mathbf{G}^{\mathrm{ab}}, \mathbf{X}^{\mathrm{ab}}),$$

$$(5.2)$$

where  $\mathbf{B}_{\mathbf{E}'} \to \mathbf{G}$ ,  $\mathbf{B}_{\mathbf{E}'} \to \mathbf{T}_{\mathbf{E}'}$ , and  $\mathbf{G} \to \mathbf{G}^{ab}$  are the natural maps, and the map  $\mathbf{T}_{\mathbf{E}'} \to \mathbf{G}^{ab}$  is the norm map. We call  $(\mathbf{B}_{\mathbf{E}'}, \mathbf{Y}_{\mathbf{E}'})$  the *Lovering construction* applied to  $(\mathbf{G}, \mathbf{X})$ . When  $\mathbf{E}' = \mathbf{E}$ , we simplify  $\mathbf{T}_{\mathbf{E}}$ ,  $\mathbf{B}_{\mathbf{E}}$ , and  $\mathbf{Y}_{\mathbf{E}}$  to  $\mathbf{T}$ ,  $\mathbf{B}$ , and  $\mathbf{Y}$ , respectively.

We now record the following pleasant functoriality property of the Lovering construction.

<span id="page-36-2"></span>**Proposition 5.1** ([Lov17a, Lemma 4.6.6]). Let  $(\mathbf{G}_1, \mathbf{X}_1)$  be another Shimura datum and let  $\mathbf{E}'$  be a field containing the compositum  $\mathbf{E}_1\mathbf{E}$ . Suppose that  $f: \mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$  is an isogeny which induces an isomorphism  $f^{\mathrm{ad}}: (\mathbf{G}_1^{\mathrm{ad}}, \mathbf{X}_1^{\mathrm{ad}}) \xrightarrow{\sim} (\mathbf{G}^{\mathrm{ad}}, \mathbf{X}^{\mathrm{ad}})$ . Then there exists a unique map  $g: \mathbf{B}_{1,\mathbf{E}'} \to \mathbf{B}$  filling in the following diagram

$$1 \longrightarrow \mathbf{G}_{1}^{\mathrm{der}} \longrightarrow \mathbf{B}_{1,\mathbf{E}'} \longrightarrow \mathbf{T}_{1,\mathbf{E}'} \longrightarrow 1$$

$$f \downarrow \qquad \qquad g \downarrow \qquad \qquad N \downarrow$$

$$1 \longrightarrow \mathbf{G}^{\mathrm{der}} \longrightarrow \mathbf{B} \longrightarrow \mathbf{T} \longrightarrow 1,$$

where N is the natural norm map. Moreover, g induces a morphism of Shimura data  $(\mathbf{B}_{1,\mathbf{E}'},\mathbf{Y}_{1,\mathbf{E}'}) \to (\mathbf{B},\mathbf{Y})$ .

**5.1.2** Relationship to Kisin–Pappas–Zhou models. We now explain how the Lovering construction fits into the theory of Kisin–Pappas–Zhou models.

To begin, let us fix a very good parahoric Shimura of Hodge type  $\mathfrak{d} = (\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  well-adapted to  $(\mathbf{G}, \mathbf{X}, \mathcal{G})$ , and let us explicitly denote by f the implicitly defined isogeny  $\mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$ . We further set  $\mathbf{E}' = \mathbf{E}\mathbf{E}_1$ .

Consider the Lovering constructions  $(\mathbf{B}, \mathbf{Y})$  and  $(\mathbf{B}_{1,\mathbf{E}'}, \mathbf{Y}_{1,\mathbf{E}'})$ . For notational simplicitly we shorten  $(\mathbf{B}_{1,\mathbf{E}'}, \mathbf{Y}_{1,\mathbf{E}'})$  to  $(\mathbf{B}'_1, \mathbf{Y}'_1)$ , and similarly for other attendant notation. Observe that both of these Shimura data are of abelian type and, in fact,  $(\mathbf{G}_1, \mathbf{X}_1)$  is an associated very good parahoric Shimura datum of Hodge type adapted to both. Indeed, this follows since

<span id="page-36-0"></span>
$$\mathbf{B}_{1}^{\prime \operatorname{der}} = \mathbf{G}_{1}^{\operatorname{der}} \quad \operatorname{and} \quad \mathbf{B}^{\operatorname{der}} = \mathbf{G}^{\operatorname{der}},$$
 (5.3)

and so we may consider the isogenies

$$\mathbf{G}_1^{\mathrm{der}} \xrightarrow{\mathrm{id}} \mathbf{B}_1^{\prime} \xrightarrow{\mathrm{der}} \quad \mathrm{and} \quad \mathbf{G}_1^{\mathrm{der}} \xrightarrow{f} \mathbf{B}^{\mathrm{der}}$$

which produce the desired isomorphisms on adjoint Shimura data (cf. Proposition 2.4).

We would like to upgrade this setup to the level of parahoric Shimura data. To this end, observe that by (5.3) and Lemma 2.5 one deduces that there are natural identifications

$$\mathscr{B}(B,\mathbb{Q}_p) \xrightarrow{\sim} \mathscr{B}(G \times T,\mathbb{Q}_p), \text{ and } \mathscr{B}(B_1',\mathbb{Q}_p) \xrightarrow{\sim} \mathscr{B}(G_1 \times T_1',\mathbb{Q}_p).$$

Thus, we may associate parahoric models  $\mathcal{B}$  and  $\mathcal{B}'_1$  to our choice of parahoric models  $\mathcal{G}$  and  $\mathcal{G}_1$ , parahoric models, respectively. In fact, it follows from Proposition 2.15

$$\mathcal{B}' = \mathcal{G} \times_{\mathcal{G}^{\mathrm{ab}}} \mathcal{T}, \quad \text{and} \quad \mathcal{B}'_1 = \mathcal{G}_1 \times_{\mathcal{G}^{\mathrm{ab}}_1} \mathcal{T}'_1,$$

where  $\mathcal{T}$  and  $\mathcal{T}'_1$  are the unique parahoric models of T and  $T'_1$ , respectively. Now, applying (5.2) and Proposition 5.1 one produces a diagram of Shimura data

$$(\mathbf{T}'_1, \{h_{\mathbf{T}_1}\}) \longrightarrow (\mathbf{G}_1^{\mathrm{ab}}, \mathbf{X}_1^{\mathrm{ab}})$$

$$\uparrow \qquad \qquad \uparrow$$

$$(\mathbf{B}'_1, \mathbf{Y}'_1) \longrightarrow (\mathbf{G}_1, \mathbf{X}_1)$$

$$\downarrow \qquad \qquad \downarrow$$

$$(\mathbf{B}, \mathbf{Y}) \longrightarrow (\mathbf{G}, \mathbf{X}).$$

In particular, we obtain a diagram of  $\mathbf{E}'$ -schemes

<span id="page-37-0"></span>
$$\operatorname{Sh}_{\mathsf{M}'_{p,1}}(\mathbf{T}'_{1},\{h_{\mathbf{T}'_{1}}\})_{\mathbf{E}'} \longrightarrow \operatorname{Sh}_{\mathsf{N}_{p,1}}(\mathbf{G}_{1}^{\mathrm{ab}},\mathbf{X}_{1}^{\mathrm{ab}})_{\mathbf{E}'}$$

$$\uparrow \qquad \qquad \uparrow \qquad \qquad \uparrow$$

$$\operatorname{Sh}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_{1},\mathbf{Y}'_{1})_{\mathbf{E}'} \longrightarrow \operatorname{Sh}_{\mathsf{K}_{p,1}}(\mathbf{G}_{1},\mathbf{X}_{1})_{\mathbf{E}'}$$

$$\downarrow \qquad \qquad \downarrow$$

$$\operatorname{Sh}_{\mathsf{L}_{p}}(\mathbf{B},\mathbf{Y})_{\mathbf{E}'} \longrightarrow \operatorname{Sh}_{\mathsf{K}_{p}}(\mathbf{G},\mathbf{X})_{\mathbf{E}'}$$

$$(5.4)$$

each map equivariant for the natural map of groups. Here, we write  $L_p = \mathcal{B}(\mathbb{Z}_p)$  and  $L'_{p,1} = \mathcal{B}'_1(\mathbb{Z}_p)$ ,  $M'_{p,1} = \mathcal{T}'_1(\mathbb{Z}_p)$ , and  $N_{p,1} = \mathcal{G}^{ab}_1(\mathbb{Z}_p)$ . We then have the following relationship between the Lovering construction and Kisin–Pappas–Zhou models.

### <span id="page-37-1"></span>**Proposition 5.2.** There exists a unique diagram

$$\begin{split} \mathscr{S}_{\mathsf{M}_{p,1}'}(\mathbf{T}_1',\{h_{\mathbf{T}_1'}\})_{\mathcal{O}_E} & \longrightarrow \mathscr{S}_{\mathsf{N}_{p,1}}(\mathbf{G}_1^{\mathrm{ab}},\mathbf{X}_1^{\mathrm{ab}})_{\mathcal{O}_E} \\ & \uparrow \qquad \qquad \uparrow \\ \mathscr{S}_{\mathsf{L}_{p,1}'}^{\mathfrak{d}}(\mathbf{B}_1',\mathbf{Y}_1')_{\mathcal{O}_E} & \longrightarrow \mathscr{S}_{\mathsf{K}_{p,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)_{\mathcal{O}_E} \\ & \downarrow \\ & \mathscr{S}_{\mathsf{L}_p}^{\mathfrak{d}}(\mathbf{B},\mathbf{Y}) & \longrightarrow \mathscr{S}_{\mathsf{K}_p}^{\mathfrak{d}}(\mathbf{G},\mathbf{X}) \end{split}$$

whose maps are equivariant for the appropriate maps of groups, and which models (5.4) pulled back to the completion of  $\mathbf{E}'$  at a prime above v.

*Proof.* The existence of an equivariant map

$$\mathscr{S}_{\mathsf{N}_{p,1}'}(\mathbf{T}_1',\{h_{\mathbf{T}_1'}\})_{\mathcal{O}_E} o \mathscr{S}_{\mathsf{N}_{p,1}}(\mathbf{G}_1^{\mathrm{ab}},\mathbf{X}_1^{\mathrm{ab}})_{\mathcal{O}_E}$$

modeling the map on the generic fiber follows from Proposition 3.22, while the existence of the equivariant map

$$\mathscr{S}_{\mathsf{K}_{n,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)_{\mathcal{O}_E} o \mathscr{S}_{\mathsf{N}_{p,1}}(\mathbf{G}_1^{\mathrm{ab}},\mathbf{X}_1^{\mathrm{ab}})_{\mathcal{O}_E}$$

modeling the map on the generic fiber follows from Proposition 3.25. To construct the equivariant maps

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_{1},\mathbf{Y}'_{1})_{\mathcal{O}_{E}} \to \mathscr{S}^{\varnothing}_{\mathsf{K}_{p,1}}(\mathbf{G}_{1},\mathbf{X}_{1})_{\mathcal{O}_{E}}, \ \text{ and } \ \mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_{1},\mathbf{Y}'_{1})_{\mathcal{O}_{E}} \to \mathscr{S}_{\mathsf{M}'_{p,1}}(\mathbf{T}'_{1},\{h_{\mathbf{T}'_{1}}\})_{\mathcal{O}_{E}},$$

<span id="page-38-4"></span>modeling the maps on the generic fiber, it suffices by Proposition 3.28 and Proposition 3.27 to construct a map

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_{p,1}}(\mathsf{B}'_1,\mathsf{Y}'_1)_{\mathcal{O}_E} \to \mathscr{S}_{\mathsf{K}_{p,1}\times\mathsf{M}'_{p,1}}(\mathsf{G}_1\times\mathsf{T}'_1,\mathsf{X}_1\times\{h_{\mathsf{T}'_1}\})_{\mathcal{O}_E}.$$

Because the map  $\mathbf{B}_1' \to \mathbf{G}_1 \times \mathbf{T}_1'$  is an isomorphism on derived subgroups, we see from Proposition 2.4 that it is an ad-isomorphism, and so the claim follows from Proposition 3.24. The fact that this constructed square commutes may be checked on the generic fiber, where it is true by construction.

The existence of an equivariant map

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_1,\mathbf{Y}'_1)_{\mathcal{O}_E} o \mathscr{S}^{\mathfrak{d}}_{\mathsf{L}_p}(\mathbf{B},\mathbf{Y})$$

follows from Proposition 3.24 as the induced map  $\mathbf{B}_1'^{\mathrm{der}} \to \mathbf{B}^{\mathrm{der}}$  is identified with the isogeny  $f \colon \mathbf{G}_1^{\mathrm{der}} \to \mathbf{G}$  and so Proposition 2.4 applies. We similarly deduce the existence of a map

$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}_p}(\mathbf{B},\mathbf{Y}) o \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X}),$$

using the fact that  $\mathbf{B}^{\mathrm{der}} \to \mathbf{G}^{\mathrm{der}}$  is an isomorphism, along with Proposition 3.24 and Proposition 2.4.

<span id="page-38-0"></span>**5.2** Construction of the  $\mathcal{G}^c$ -shtuka. In this section we establish the following theorem.

<span id="page-38-3"></span>**Theorem 5.3.** There exists a unique  $\mathcal{G}^c$ -shtuka  $\mathscr{P}_{\mathsf{K}_p}$  on  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})$  bounded by  $\mu_h^c$ , which is compatible with the  $\mathbf{G}(\mathbb{A}_f^p)$ -action and which models  $\mathscr{P}_{\mathsf{K}_p,E}$ .

By [PR21, Corollary 2.7.10], there can be at most one shtuka  $\mathscr{P}_{\mathsf{K}_p}$  modeling  $\mathscr{P}_{\mathsf{K}_p,E}$ . Moreover, such a shtuka is automatically bounded by  $\mu_h^c$  by [Dan22, Lemma 2.1]. Thus, it suffices to construct a  $\mathscr{G}^c$ -shtuka  $\mathscr{P}_{\mathsf{K}_p}$  which is compatible with the  $\mathbf{G}(\mathbb{A}_f^p)$ -action and which models  $\mathscr{P}_{\mathsf{K}_p,E}$ . In fact, it suffices to construct a model with  $\mathbf{G}(\mathbb{A}_f^p)$ -action of  $\mathscr{P}_{\mathsf{K}_p,E'}$  for any discrete algebraic extension E' of E. Indeed, by [PR21, Corollary 2.7.10] one may lift the descent datum of  $\mathscr{P}_{\mathsf{K}_p,E'}$  relative to  $\mathscr{P}_{\mathsf{K}_p,E}$  to an integral descent datum, which is effective by [SW20, Proposition 19.5.3].

The proof of the existence of such a model will occupy the rest of this subsection, and will be carried out in several steps.

**Step 1: Group Theory.** We begin by establishing the following group-theoretic result which will be useful in our construction.

<span id="page-38-2"></span>**Proposition 5.4.** There is a canonical identification

$$\mathcal{B}_1^{\prime c} \xrightarrow{\sim} \mathcal{G}_1 \times_{\mathcal{G}_1^{ab}} \mathcal{T}_1^{\prime c}.$$

Proof. Let us begin by verifying that there is a canonical isomorphism

<span id="page-38-1"></span>
$$\mathbf{B}_{1}^{\prime c} \xrightarrow{\sim} \mathbf{G}_{1} \times_{\mathbf{G}_{1}^{\mathrm{ab}}} \mathbf{T}_{1}^{\prime c}. \tag{5.5}$$

Note here that we are using Lemma 4.1 to identify  $\mathbf{G}_1$  and  $\mathbf{G}_1^{\mathrm{ab}}$  with  $\mathbf{G}_1^c$  and  $(\mathbf{G}_1^{\mathrm{ab}})^c$ , respectively.

Observe that since  $\mathbf{B}_1' \to \mathbf{G}_1 \times \mathbf{T}_1'$  is an ad-isomorphism, we may use Proposition 2.4 to deduce that

$$Z(\mathbf{B}_1') = Z(\mathbf{G}_1) \times_{\mathbf{G}_1^{\mathrm{ab}}} \mathbf{T}_1'.$$

We then employ the following simple lemma.

#### **Lemma 5.5.** *Let*

$$egin{array}{ccc} \mathbf{T} & \longrightarrow & \mathbf{T}_1 \\ \downarrow & & \downarrow \\ \mathbf{T}_2 & \longrightarrow & \mathbf{T}_3, \end{array}$$

be a Cartesian diagram, where  $\mathbf{T}_i$ , for i = 1, 2, 3, are multiplicative groups over  $\mathbb{Q}$ , and such that  $\mathbf{T}_1^{\circ} \to \mathbf{T}_3^{\circ}$  is surjective. Then,

$$\mathbf{T}_{\mathrm{ac}} = (\mathbf{T}_1)_{\mathrm{ac}} \times_{(\mathbf{T}_2)_{\mathrm{ac}}} (\mathbf{T}_3)_{\mathrm{ac}}.$$

*Proof.* This follows easily from Proposition 2.14, and the observation that for a containment  $A \subseteq B$  of multiplicative groups over some field F, one has that  $A_a = (B_a \cap A)^\circ$  and  $A_s = (B_s \cap A)^\circ$ , where the subscripts a and s denote the maximal anisotropic and split subtori, respectively. Namely, one applies this with  $A = \mathbf{T}$ , and  $B = \mathbf{T}_1 \times \mathbf{T}_2$ .

Using this, and the fact that fiber products of groups commute with quotients, we easily deduce the existence of an isomorphism as in (5.5). Note that  $\mathcal{B}_1^c$  is a parahoric group by definition. The same is true of  $\mathcal{G}_1 \times_{\mathcal{G}_1^{\mathrm{ab}}} \mathcal{T}_1^{\prime c}$ . Indeed, this follows from Proposition 2.15, since  $G_1^{\mathrm{der}}$  is R-smooth (recall that we assume  $(\mathbf{G}_1, \mathbf{X}_1, \mathcal{G}_1)$  is very good) and thus Proposition 2.11 applies, implying that  $\ker(\mathcal{G}_1 \to \mathcal{G}^{\mathrm{ab}})$  is  $\mathcal{G}^{\mathrm{der}}$  which is is smooth with connected fibers. To conclude, it now suffices to show that  $\mathcal{B}_1^c$  and  $\mathcal{G}_1 \times_{\mathcal{G}_1^{\mathrm{ab}}} \mathcal{T}_1^{\prime c}$  correspond to matching points under the bijection

$$\mathscr{B}(B_1'^c, \mathbb{Q}_p) \xrightarrow{\sim} \mathscr{B}(G_1 \times_{G_1^{\mathrm{ab}}} T_1'^c, \mathbb{Q}_p),$$

coming from (5.5).

We have the following commutative diagram of equivariant bijections (utilizing a combination of Lemma 2.5 and Proposition 2.15 several times)

$$\mathscr{B}(G_1 \times_{G_1^{\mathrm{ab}}} T_1'^c) \longrightarrow \mathscr{B}(G_1 \times T_1'^c, \mathbb{Q}_p) \longleftarrow \mathscr{B}(G_1 \times T_1', \mathbb{Q}_p)$$

$$\uparrow \qquad \qquad \qquad \qquad \qquad \uparrow$$

$$\mathscr{B}(B_1'^c, \mathbb{Q}_p) \longleftarrow \mathscr{B}(B_1', \mathbb{Q}_p).$$

Tracing through the definitions, we see that the claim follows as the points we consider ultimately can be induced from the same point (x, \*) in the top-right corner, where  $\mathcal{G}_1 = \mathcal{G}_x^{\circ}$ . Here we are implicitly using that the formation of the (reduced) Bruhat–Tits building commutes with products.

<span id="page-40-1"></span>Step 2: Pullback and Descent to the Fiber Product. Let us now recall the commutative diagram

$$\begin{split} \mathscr{S}_{\mathsf{M}_{p,1}'}(\mathbf{T}_1',\{h_{\mathbf{T}_1'}\})_{\mathcal{O}_E} & \stackrel{c}{\longrightarrow} \mathscr{S}_{\mathsf{N}_{p,1}}(\mathbf{G}_1^{\mathrm{ab}},\mathbf{X}_1^{\mathrm{ab}})_{\mathcal{O}_E} \\ & \stackrel{d}{\uparrow} \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad \qquad$$

from Proposition 5.2, with the arrows labeled for convenience, and where the arrow e is defined to make the lower triangle commute.

Utilizing Theorem 4.6 and Theorem 4.8 there exist a  $\mathbf{G}_1(\mathbb{A}_f^p)$ -equivariant  $\mathcal{G}_1$ -shtuka  $\mathscr{P}_{\mathsf{K}_{p,1}}$  and a  $\mathbf{T}_1'(\mathbb{A}_f^p)$ -equivariant  $\mathcal{T}_1'^c$ -shtuka  $\mathscr{P}_{\mathsf{M}_{p,1}'}$  on  $\mathscr{S}_{\mathsf{K}_{p,1}}^{\varnothing}(\mathbf{G}_1,\mathbf{X}_1)_{\mathcal{O}_E}$  and  $\mathscr{S}_{\mathsf{M}_{p,1}'}(\mathbf{T}_1',\{h_{\mathbf{T}_1'}\})_{\mathcal{O}_E}$ , respectively. We then obtain a  $\mathcal{G}_1$ -shtuka and a  $\mathcal{T}_1'^c$ -shtuka on  $\mathscr{S}_{\mathsf{L}_{p,1}}^{\mathfrak{d}}(\mathbf{B}_1',\mathbf{Y}_1')_{\mathcal{O}_E}$ , given by  $a^*\mathscr{P}_{\mathsf{K}_{p,1}}$  and  $a^*\mathscr{P}_{\mathsf{M}_{p,1}'}$ , respectively.

We claim that  $a^* \mathscr{P}_{\mathsf{K}_{p,1}}$  and  $d^* \mathscr{P}_{\mathsf{M}'_{p,1}}$  are both equivariant relative to  $\mathbf{B}'_1(\mathbb{A}^p_f)$ . Indeed, this follows from the equivariance of these maps, as for an element g of  $\mathbf{B}'_1(\mathbb{A}^p_f)$  we have natural isomorphisms

$$[g]^*a^*\mathscr{P}_{\mathsf{K}_{p,1}} \simeq a^*([a(g)]^*\mathscr{P}_{\mathsf{K}_{p,1}}) \simeq a^*\mathscr{P}_{\mathsf{K}_{p,1}},$$

using the  $G_1(\mathbb{A}_f^p)$ -equivariance of  $\mathscr{P}_{\mathsf{K}_{p,1}}$ , and similarly in the case of  $d^*\mathscr{P}_{\mathsf{M}'_{p,1}}$ .

Our plan is now to use Corollary 2.17 to glue the shtukas  $a^* \mathscr{P}_{\mathsf{K}_{p,1}}$  and  $d^* \mathscr{P}_{\mathsf{M}'_{p,1}}$  in order to obtain a  $\mathcal{B}_1'^c$ -shtuka on  $\mathscr{P}_{\mathsf{L}'_{p,1}}^{\circ}(\mathbf{B}'_1,\mathbf{Y}'_1)_{\mathcal{O}_E}$  modeling the  $\mathcal{B}_1'^c$ -shtuka  $\mathscr{P}_{\mathsf{L}'_{p,1},E}$  living over the generic fiber  $\mathrm{Sh}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_1,\mathbf{Y}'_1)_{E'}$ , see Proposition 4.2.

<span id="page-40-0"></span>**Lemma 5.6.** Let  $\delta$  be the natural map  $\mathcal{G}_1 \to \mathcal{G}_1^{ab}$ , and let  $N: \mathcal{T}_1'^c \to \mathcal{G}_1^{ab}$  be the (map induced by) the norm. Then there is a  $\mathbf{B}_1'(\mathbb{A}_f^p)$ -equivariant isomorphism of  $\mathcal{G}_1^{ab}$ -torsors

$$\theta \colon \delta_* a^* \mathscr{P}_{\mathsf{K}_{p,1}} \xrightarrow{\sim} N_* d^* \mathscr{P}_{\mathsf{M}_{p,1}}.$$

*Proof.* To construct such an isomorphism, it suffices construct compatible isomorphisms over  $\mathcal{L}_{\mathsf{L}_1'^p}^{\flat}(\mathbf{B}_1',\mathbf{Y}_1')_{\mathcal{O}_E}$ , for each neat compact open subgroup  $\mathsf{L}_1'^p \subseteq \mathbf{B}_1'(\mathbb{A}_f^p)$ . Furthermore, by [PR21, Corollary 2.7.10], it suffices to construct such compatible isomorphisms on  $\mathrm{Sh}_{\mathsf{L}_{n-1}',\mathsf{L}_1'^p}(\mathbf{B}_1',\mathbf{Y}_1')_E$ .

The shtukas  $\mathscr{P}_{K_{p,1},E}$  and  $\mathscr{P}_{M_{p,1}}$  are functorially constructed from the corresponding étale realization functors  $\mathbb{P}_{K_{p,1},E}$  and  $\mathbb{P}_{M_{p,1}}$ , respectively, in a way compatible with pullbacks along morphisms of Shimura varieties and pushforwards along morphisms of groups. Standard compatabilities of étale realizations (c.f., [IKY23, Equation (4.3.2)]) imply that there are natural isomorphisms

$$\delta_* a^* \mathbb{P}_{\mathsf{N}_{p,1}} \simeq (b \circ a)^* \mathbb{P}_{\mathsf{N}_{p,1}} \simeq (c \circ d)^* \mathbb{P}_{\mathsf{N}_{p,1}} \simeq N_* d^* \mathbb{P}_{\mathsf{M}_{p,1}},$$

from where the claim follows. From this we deduce the existence of canonical isomormorphisms

$$\delta_* a^* \mathscr{P}_{\mathsf{K}_{p,1}} \simeq (b \circ a)^* \mathscr{P}_{\mathsf{N}_{p,1}} \simeq (c \circ d)^* \mathscr{P}_{\mathsf{N}_{p,1}} \simeq N_* d^* \mathscr{P}_{\mathsf{M}_{p,1}},$$

<span id="page-41-1"></span>where  $\mathscr{P}_{\mathsf{N}_{p,1}}$  is the unique model of  $\mathscr{P}_{\mathsf{N}_{p,1},E}$  from Theorem 4.8. The resulting composition  $\theta: \delta_* a^* \mathscr{P}_{\mathsf{K}_{p,1}} \xrightarrow{\sim} N_* d^* \mathscr{P}_{\mathsf{M}_{p,1}}$  is the desired isomorphism.

**Proposition 5.7.** There exists a  $\mathcal{B}_1'^c$ -shtuka  $\mathscr{P}_{\mathsf{L}_{p,1}'}$  on  $\mathscr{S}_{\mathsf{L}_{p,1}'}^{\mathfrak{d}}(\mathbf{B}_1',\mathbf{Y}_1')_{\mathcal{O}_E}$  which models  $\mathscr{P}_{\mathsf{L}_{p,1}',E}$ .

*Proof.* Using Lemma 5.6, we may apply Corollary 2.17 and Proposition 5.4 to deduce the construction of a  $\mathcal{B}_1'^c$ -shtuka  $\mathscr{P}_{\mathsf{L}_{p,1}'}$  on  $\mathscr{S}_{\mathsf{L}_{p,1}'}^{\mathfrak{d}}(\mathbf{B}_1',\mathbf{Y}_1')_{\mathcal{O}_E}$ . By construction this shtuka has an equivariant action of  $\mathbf{B}_1'(\mathbb{A}_f^p)$ . As in the last paragraph, to show  $\mathscr{P}_{\mathsf{L}_{p,1}'}$  models the  $\mathscr{B}_1'^c$ -shtuka  $\mathscr{P}_{\mathsf{L}_{p,1}',E}$ , it suffices to show that there is an isomorphism

$$\mathbb{P}_{\mathsf{K}_{p,1}} \times_{\theta} \mathbb{P}_{\mathsf{M}_{p,1}} \simeq \mathbb{P}_{\mathsf{L}'_{p,1}}.$$

Here we are applying Proposition 2.16, which makes sense when one views these local systems as torsors as in [IKY23,  $\S2.1.1$ ]. But, in view of Proposition 5.4 this is an elementary calculation (cf. [Lov17b,  $\S3.4.4$ ]).

Step 3: Descending to  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}$ . We now show that there is a  $\mathbf{G}(\mathbb{A}_{f}^{p})$ -equivariant  $\mathcal{G}^{c}$ -shtuka on  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X})_{E^{\mathrm{ur}}}$  which models  $\mathscr{P}_{\mathsf{K}_{p}, E^{\mathrm{ur}}}$ . As previously noted, this is sufficient to prove Theorem 5.3. Let us begin by considering the  $\mathcal{G}^{c}$ -shtuka

$$\mathscr{P}' := \mathscr{P}_{\mathsf{L}'_{p,1},\mathcal{O}_{E^{\mathrm{ur}}}} \times^{\mathcal{B}'_1{}^c} \mathcal{G}^c,$$

on  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_1^{p}}(\mathbf{B}'_1,\mathbf{Y}'_1)_{\mathcal{O}_{E^{\mathrm{ur}}}}.$ 

Choose a connected component  $\mathscr{S}'^+$  of  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_1^p}(\mathbf{B}'_1,\mathbf{Y}'_1)_{\mathcal{O}_{E^{\mathrm{ur}}}}$ , and let  $\mathscr{S}^+$  be the connected component of  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}$  containing its image under the map

<span id="page-41-0"></span>
$$\mathscr{S}^{\mathfrak{d}}_{\mathsf{L}'_{1}^{p}}(\mathbf{B}'_{1}, \mathbf{Y}'_{1})_{\mathcal{O}_{E^{\mathrm{ur}}}} \to \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_{p}}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}.$$
 (5.6)

Set  $\mathscr{P}'^+$  to be the pullback of  $\mathscr{P}^+$  to  $\mathscr{S}'^+$ .

**Lemma 5.8.** The  $\mathcal{G}^c$ -shtuka  $\mathscr{D}'^+$  descends uniquely to a  $\mathcal{G}^c$ -shtuka  $\mathscr{D}^+$  on  $\mathscr{S}^+$ , which models the restriction of  $\mathscr{P}_{K_p,E^{\mathrm{ur}}}$  to  $\mathscr{S}^+_{E^{\mathrm{ur}}}$ 

*Proof.* As noted in the proof of Proposition 3.24, the map  $\mathscr{S}^{\prime +} \to \mathscr{S}^{+}$  is a quotient by the group

$$\Delta = \ker(\mathscr{A}(\boldsymbol{\mathcal{G}}_1)^\circ \to \mathscr{A}(\boldsymbol{\mathcal{G}})) / \ker(\mathscr{A}(\boldsymbol{\mathcal{G}}_1)^\circ \to \mathscr{A}(\boldsymbol{\mathcal{B}}_1')),$$

which acts through a finite quotient asn in [Kis10, §E.6]. Thus, by [SW20, Proposition 19.5.3], it suffices to show that there is a  $\Delta$ -action on  $\mathscr{P}'^+$  which gives a descent datum. Arguing as in **Step 2**, it suffices to verify that there is a  $\Delta$ -descent datum on the  $\mathcal{G}^c(\mathbb{Z}_p)$ -local system  $\mathbb{P}'^+$  on  $\mathscr{S}'^+_{E^{ur}}$ , whose definition is, mutatis mutandis, the same as that of  $\mathscr{P}'^+$ . But, this is clear as the  $\mathcal{G}^c(\mathbb{Z}_p)$ -local system  $\mathbb{P}'$  on  $\mathrm{Sh}_{\mathsf{L}'_{p,1}}(\mathbf{B}'_1,\mathbf{Y}'_1)_{E^{ur}}$  is the pullback of a  $\mathcal{G}^c(\mathbb{Z}_p)$ -local system on  $\mathrm{Sh}_{\mathsf{K}_n}(\mathbf{G},\mathbf{X})_{E^{ur}}$  by [IKY23, Equation (4.3.2)].

Thus we obtain a  $\mathcal{G}^c$ -shtuka  $\mathscr{P}^+$  on  $\mathscr{S}^+$ . That this shtuka models the restriction of  $\mathscr{P}_{\mathsf{K}_p,E^{\mathrm{ur}}}$  to  $\mathscr{S}^+_{E^{\mathrm{ur}}}$  is clear by design. Indeed,  $\mathscr{P}^+$  is isomorphic to the  $\mathscr{G}^c$ -shtuka obtained as the descent of  $\mathscr{P}'^+$  with respect to the  $\Delta$ -action which, as noted before, agrees with that of the restriction to  $\mathscr{S}^+_{E^{\mathrm{ur}}}$  of the pullback of  $\mathscr{P}_{\mathsf{K}_p,E^{\mathrm{ur}}}$  along the map in (5.6).

<span id="page-42-0"></span>Using the  $\mathscr{A}(\mathcal{G})$ -equivariant bijection

$$\pi_0(\operatorname{Sh}_{\mathsf{K}_p}(\mathbf{G}, \mathbf{X})_{E^{\mathrm{ur}}}) \xrightarrow{\sim} \pi_0(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_n}(\mathbf{G}, \mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}),$$
 (5.7)

(see Lemma 3.20 and Lemma 3.21) and [KP18, Lemma 4.6.13], the group  $\mathscr{A}(\mathcal{G})$  acts transitively on  $\pi_0(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}})$ . Thus, for any component  $\mathscr{T}^+$  of  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}$  we may choose some g in  $\mathscr{A}(\mathcal{G})$  such that

$$[g]: \mathscr{S}^+ \xrightarrow{\sim} \mathscr{T}^+.$$

We define

$$\mathscr{P}_{\mathsf{K}_p,\mathcal{O}_{E^{\mathrm{ur}}},\mathscr{T}^+} := [g]^* \mathscr{P}^+.$$

To see that this is canonically independent of the choice of g we again note by [PR21, Corollary 2.7.10] that it suffices to verify this on the generic fiber. There, the statement follows from the fact that  $\mathscr{P}^+$  models the restriction of  $\mathscr{P}_{\mathsf{K}_p,E^{\mathrm{ur}}}$  to  $\mathscr{F}^+_{E^{\mathrm{ur}}}$ , and the  $\mathscr{A}(\mathcal{G})$ -equivariance of  $\mathscr{P}_{\mathsf{K}_p,E^{\mathrm{ur}}}$ . Moreover, by the same logic we see that  $\mathscr{P}_{\mathsf{K}_p,\mathcal{O}_{E^{\mathrm{ur}}},\mathscr{T}^+}$  models the restriction of  $\mathscr{P}_{\mathsf{K}_p,1,E^{\mathrm{ur}}}$  to  $\mathscr{F}^+_{E^{\mathrm{ur}}}$ .

For each neat compact open subgroup  $\mathsf{K}^p \subseteq \mathbf{G}(\mathbb{A}_f^p)$  and each connected component  $\mathscr{T}^+_{\mathsf{K}^p}$  of  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathscr{O}_{E^{\mathrm{ur}}}}$  we may choose any connected component  $\mathscr{T}^+$  of  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathscr{O}_{E^{\mathrm{ur}}}}$  mapping to it. The fact here that the map

$$\pi_0(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^\mathrm{ur}}}) \to \pi_0(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^\mathrm{ur}}})$$

is surjective follows from Lemma 3.20.

**Lemma 5.9.** The shtuka  $\mathscr{P}_{\mathsf{K}_p,\mathcal{O}_{E^{\mathrm{ur}},\mathscr{T}^+}}$  descends along the map  $\mathscr{T}^+ \to \mathscr{T}^+_{\mathsf{K}^p}$  to a shtuka  $\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}},\mathscr{T}^+_{\mathsf{K}^p}}}$  which models the restriction of  $\mathscr{P}_{\mathsf{K}^p,E^{\mathrm{ur}}}$  to  $\mathscr{T}^+_{\mathsf{K}^p,E^{\mathrm{ur}}}$ .

*Proof.* The map  $\mathscr{T}^+ \to \mathscr{T}^+_{\mathsf{K}^p}$  is a profinite étale cover, and thus by [SW20, Proposition 19.5.3] to show that  $\mathscr{P}_{\mathsf{K}_p,\mathcal{O}_E^{\mathrm{ur}},\mathscr{T}^+}$  descends along this map, it suffices to produce descent data. Again by [PR21, Corollary 2.7.10], this data can be obtained using the descent data for the restriction of  $\mathscr{P}_{\mathsf{K}_p,1,E^{\mathrm{ur}}}$  to  $\mathscr{T}^+_{E^{\mathrm{ur}}}$  relative to the map  $\mathscr{T}^+_{E^{\mathrm{ur}}} \to \mathscr{T}^+_{\mathsf{K}^p,E^{\mathrm{ur}}}$ .

It is clear by the definition of  $\mathscr{P}_{\mathsf{K}_p,\mathcal{O}_{E^{\mathrm{ur}},\mathscr{T}^+}}$ , [Kis10, Lemma 2.2.5], and the equivariance of the map  $\mathscr{T}^+ \to \mathscr{T}^+_{\mathsf{K}^p}$  that this descent is independent of all choices, and hence we obtain  $\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}},\mathscr{T}^+_{\mathsf{K}^p}}}$ . We conclude by observing that  $\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}},\mathscr{T}^+_{\mathsf{K}^p}}}$  models the restriction of  $\mathscr{P}_{\mathsf{K}^p,E^{\mathrm{ur}}}$  to  $\mathscr{T}^+_{\mathsf{K}^p,E^{\mathrm{ur}}}$  since, by definition, they have the same descent data relative to the map  $\mathscr{T}^+_{E^{\mathrm{ur}}} \to \mathscr{T}^+_{\mathsf{K}^p,E^{\mathrm{ur}}}$ .

Finally, we can construct the desired  $\mathcal{G}^c$ -shtuka on  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}}$ .

Construction 5.10. We set

$$\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}}}} = \bigsqcup_{\mathscr{T}^+_{\mathsf{K}^p} \in \pi_0(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}})} \mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}}},\mathscr{T}^+_{\mathsf{K}^p}}.$$

More precisely, let  $k_E$  denote the residue field of E. Then, as  $\pi_0(\mathscr{S}^{\flat}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}})$  is finite, the set of objects S of  $\mathbf{Perf}_{k_E}$  such that  $S \to (\mathscr{S}^{\flat}_{\mathsf{K}_p\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathcal{O}_{E^{\mathrm{ur}}}})^{\lozenge/}$  factorizes through some  $(\mathscr{T}^+_{\mathsf{K}^p})^{\lozenge/}$  is a basis of  $\mathbf{Perf}_{k_E}$ , and on such an object we define the  $\mathscr{G}^c$ -shtuka over S to be that determined by the (unique) map  $S \to (\mathscr{T}^+_{\mathsf{K}^p})^{\lozenge/}$ .

<span id="page-43-3"></span>Proof of Theorem 5.3. It is clear from our definition of  $\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}}}}$  that the collection  $\{\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}}}}\}_{\mathsf{K}^p}$  forms a compatible family of  $\mathscr{G}^c$ -shtukas over  $\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{\mathscr{O}_{E^{\mathrm{ur}}}}$ . Also, by design,  $\mathscr{P}_{\mathsf{K}^p,\mathcal{O}_{E^{\mathrm{ur}}}}$  models  $\mathscr{P}_{\mathsf{K}^p,E^{\mathrm{ur}}}$  since it does so on each connected component. Theorem 5.3 follows.  $\square$ 

<span id="page-43-0"></span>**5.3** The completion of the proof. We are now prepared to prove Theorem 4.10. Given Theorem 3.12 and Theorem 5.3 it remains to verify the following proposition.

<span id="page-43-1"></span>**Proposition 5.11.** For any neat compact open subgroup  $K^p \subseteq G(\mathbb{A}_f^p)$ , and x in  $\mathscr{S}^{\mathfrak{d}}_{K^p}(G, \mathbf{X})(\overline{k}_E)$ , there exists an isomorphism of v-sheaves

$$\Theta_x \colon \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G}^c,b_x,\mathbb{H}^c_h}
ight)_{/x_0}^\wedge \overset{\sim}{\longrightarrow} \left(\mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^p}(\mathbf{G},\mathbf{X})_{/x}^\wedge
ight)^\diamondsuit,$$

such that  $\Theta_x^*(\mathscr{P}_{\mathsf{K}^p})$  is isomorphic to  $\mathscr{P}^{\mathrm{univ}}$ , with notation as in Definition 4.3.

<span id="page-43-2"></span>The key to constructing such an isomorphism is the following result of Pappas–Rapoport.

**Proposition 5.12** ([PR21, Proposition 5.3.1]). Suppose that  $f: (\mathcal{G}_1, \mu_1, b_1) \to (\mathcal{G}, b, \mu)$  is an ad-isomorphism of local Shimura data, and that  $x_1$  is an element of  $\mathcal{M}^{\text{int}}_{\mathcal{G}_1,b_1,\mu_1}(\overline{k}_{E_1})$  with image x in  $\mathcal{M}^{\text{int}}_{G,b,\mu}(\overline{k}_E)$  (note that  $\overline{k}_{E_1} = \overline{k}_E$ ). Then the induced map

$$f \colon \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G}_1,b_1,\mu_1}\right)_{/x_1}^{\wedge} \to \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G},b,\mu}\right)_{/x}^{\wedge} \times_{\mathrm{Spd}(\mathcal{O}_E)} \mathrm{Spd}(\mathcal{O}_{E_1^{\mathrm{ur}}}),$$

is an isomorphism, and there is an identification

$$f^*(\mathscr{P}_{\mathcal{G}}^{\mathrm{univ}}) \simeq \mathscr{P}_{\mathcal{G}_1}^{\mathrm{univ}} \times^{\mathcal{G}_1} \mathcal{G}.$$

Proof of Proposition 5.11. Consider the commutative diagram

$$\mathcal{S}_{\mathsf{M}_{p,1}'}(\mathbf{T}_{1}',\{h_{\mathbf{T}_{1}'}\})_{\mathcal{O}_{E}} \xrightarrow{c} \mathcal{S}_{\mathsf{N}_{p,1}}(\mathbf{G}_{1}^{\mathrm{ab}},\mathbf{X}_{1}^{\mathrm{ab}})_{\mathcal{O}_{E}}$$

$$\downarrow^{a} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{b} \qquad \qquad \downarrow^{$$

from Proposition 5.2, where each map is equivariant for the relevant group homomorphism. Choose compact open subgroups

$$\mathsf{L}'^p\subseteq \mathbf{B}'_1(\mathbb{A}^p_f),\quad \mathsf{K}^p\subseteq \mathbf{G}(\mathbb{A}^p_f),\quad \mathsf{M}'^p_1\subseteq \mathbf{T}'_1(\mathbb{A}^p_f), \ \ \text{and} \ \ \mathsf{K}^p_1\subseteq \mathbf{G}_1(\mathbb{A}^p_f),$$

such that  $(a,e)(\mathsf{L}'_1^p)\subseteq \mathsf{K}_1^p\times \mathsf{M}'_1^p$  and  $e(\mathsf{L}'_1^p)\subseteq \mathsf{K}^p$ . We then obtain the diagram

from (5.2) (excluding some terms) and Proposition 3.28.

Let us now fix a point w of  $\mathscr{S}_{\mathsf{L}_{1}^{\prime p}}^{\mathfrak{d}}(\mathbf{B}_{1}^{\prime},\mathbf{Y}_{1}^{\prime})(\overline{k}_{E})$ . We set

$$x = e(w) \in \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^p}(\mathbf{G}, \mathbf{X})(\overline{k}_E), \qquad y = a(w) \in \mathscr{S}^{\mathfrak{d}}_{\mathsf{K}^p_1}(\mathbf{G}_1, \mathbf{X}_1)_{\mathcal{O}_E}(\overline{k}_E),$$

<span id="page-44-2"></span>and

$$z = c(w) \in \mathscr{S}_{\mathsf{M}_1'^p}(\mathbf{T}_1', \{h_{\mathbf{T}_1'}\})_{\mathcal{O}_E}(\overline{k}_E).$$

Since the maps

$$(\mathbf{B}_1')^{\mathrm{der}} o \mathbf{G}^{\mathrm{der}} \ \ \mathrm{and} \ \ (\mathbf{B}_1')^{\mathrm{der}} o (\mathbf{G}_1 imes \mathbf{T}_1')^{\mathrm{der}}$$

are isogenies, the maps

$$\mathbf{B}_1' \to \mathbf{G} \ \mathrm{and} \ \mathbf{B}_1' \to \mathbf{G}_1 \times \mathbf{T}_1'$$

are ad-isomorphisms by Proposition 2.4. Thus, the maps e and (a, c) are finite étale by Proposition 3.24, and we obtain induced isomorphisms

$$e \colon \widehat{\mathcal{O}}_x \xrightarrow{\sim} , \widehat{\mathcal{O}}_w \qquad (a,c) \colon \widehat{\mathcal{O}}_y \otimes_{\mathcal{O}_{\widecheck{E}}} \widehat{\mathcal{O}}_z \xrightarrow{\sim} \widehat{\mathcal{O}}_w.$$

Here we use the obvious notation for the complete local rings of these Kisin–Pappas–Zhou models at these  $\overline{k}_E$ -points. We also use the fact that  $\widehat{\mathcal{O}}_z$  is isomorphic to  $\mathcal{O}_{\widecheck{E}}$  (see [Dan22, Lemma 4.2]) to relate the local ring (y,z) to the tensor product of local rings.

Now, by Theorem 4.6 and Theorem 4.8 we may choose isomorphisms

$$\Theta_y : \left( \mathcal{M}^{\mathrm{int}}_{\mathcal{G}_1, b_y, \mu_y} \right)_{/y_0}^{\wedge} \xrightarrow{\sim} \mathrm{Spf} \left( \widehat{\mathcal{O}}_y \right)^{\Diamond} \ \text{and} \ \Theta_z : \left( \mathcal{M}^{\mathrm{int}}_{\mathcal{T}_1'^c, b_z, \mu_z} \right)_{/z_0}^{\wedge} \xrightarrow{\sim} \mathrm{Spf} \left( \widehat{\mathcal{O}}_z \right)^{\Diamond},$$

such that  $\Theta_y^*(\mathscr{P}_{\mathsf{K}_1^p}) \simeq \mathscr{P}_y^{\mathrm{univ}}$  and  $\Theta_z^*(\mathscr{P}_{\mathsf{M}_1^{'p}}) \simeq \mathscr{P}_z^{\mathrm{univ}}$ , where have used the obvious shortenings for the local cocharacters and universal shtukas. From these, we obtain an isomorphism

$$\Theta_y \times \Theta_z \colon \left( \mathcal{M}^{\rm int}_{\mathcal{G}_1, b_y, \mu_y} \right)_{/y_0}^{\wedge} \times \left( \mathcal{M}^{\rm int}_{\mathcal{T}_1'^c, b_z, \mu_z} \right)_{/z_0}^{\wedge} \xrightarrow{\sim} {\rm Spf} \; (\widehat{\mathcal{O}}_y)^{\Diamond} \times {\rm Spf} \; (\widehat{\mathcal{O}}_z)^{\Diamond}.$$

On the other hand, since  $B_1^{\prime c} \to G_1 \times T_1^{\prime c}$  is an ad-isomorphism, we see from Proposition 5.12 that we have an induced isomorphism

$$\left(\mathcal{M}^{\mathrm{int}}_{\mathcal{B}_{1}^{\prime c},b_{w},\mu_{w}}\right)_{/w_{0}}^{\wedge} \xrightarrow{\sim} \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G}_{1}\times\mathcal{T}_{1}^{\prime c},b_{(y,z)},\mu_{(y,z)}}\right)_{/(y_{0},z_{0})}^{\wedge}.$$

Using the fact that the formation of integral local Shimura varieties commutes with products in the obvious way, we obtain an induced isomorphism

$$(\alpha,\gamma)\colon \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{B}_{1}^{\prime c},b_{w},\mu_{w}}\right)_{/w_{0}}^{\wedge} \xrightarrow{\sim} \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G}_{1},b_{y},\mu_{y}}\right)_{/y_{0}}^{\wedge} \times \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{T}_{1}^{\prime c},b_{z},\mu_{z}}\right)_{/z_{0}}^{\wedge},$$

where we are again using the fact that  $(\mathcal{M}_{\mathcal{T}_1^{\prime c},b_z,\mu_z}^{\mathrm{int}})^{\wedge}_{/z_0}$  is a point to pass to the completions. We may then form the map

$$\Theta_w := (a,c)^{-1} \circ (\Theta_y \times \Theta_z) \circ (\alpha,\gamma) : \left( \mathcal{M}^{\text{int}}_{\mathcal{B}_1^{\prime c},b_w,\mu_w} \right)_{/w_0}^{\wedge} \xrightarrow{\sim} \text{Spf} (\widehat{\mathcal{O}}_w)^{\lozenge}.$$

Let us observe that by design

<span id="page-44-1"></span>
$$\Theta_w^*(\mathscr{P}_{\mathsf{L}_1'^p}) \times^{\mathcal{B}_1'^c} (\mathcal{G}_1 \times \mathcal{T}_1'^c) \simeq \alpha^* \mathscr{P}_y^{\mathrm{univ}} \times \gamma^* \mathscr{P}_z^{\mathrm{univ}} \simeq \mathscr{P}_w^{\mathrm{univ}} \times^{\mathcal{B}_1'^c} (\mathcal{G}_1 \times \mathcal{T}_1'^c). \tag{5.9}$$

But, since

$$\mathcal{B}_{1}^{\prime c}(\mathbb{Z}_{n}^{\mathrm{ur}}) = (\mathcal{G}_{1}(\mathbb{Z}_{n}^{\mathrm{ur}}) \times \mathcal{T}_{1}^{\prime c}(\mathbb{Z}_{n}^{\mathrm{ur}})) \cap B_{1}^{\prime c}(\mathbb{Q}_{n}^{\mathrm{ur}})$$

(as follows from Proposition 5.4), [PR22, Proposition 5.1.3] implies that the map of integral local Shimura varieties

<span id="page-44-0"></span>
$$\mathcal{M}_{\mathcal{B}_{1}^{\prime c},b_{w},\mu_{w}}^{\text{int}} \to \mathcal{M}_{\mathcal{G}_{1}\times\mathcal{T}_{1}^{\prime c},b_{(y,z)},\mu_{(y,z)}}^{\text{int}}$$

$$(5.10)$$

is a closed immersion. Because the map (5.10) is given at the level of objects by the push forward of shtukas along  $\mathcal{B}_1^{\prime c} \to \mathcal{G}_1 \times \mathcal{T}_1^{\prime c}$ , it follows from (5.9) that  $\Theta_w^*(\mathscr{P}_{\mathsf{L}_1^{\prime p}})$  is isomorphic to  $\mathscr{P}_w^{\mathrm{univ}}$ .

On the other hand, since  $B_1^{\prime c} \to G^c$  is an ad-isomorphism, we deduce from Proposition 5.12 an isomorphism

$$\varepsilon \colon \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{B}_{1}^{\prime c},b_{w},\mu_{w}}\right)_{/w_{0}}^{\wedge} \xrightarrow{\sim} \left(\mathcal{M}^{\mathrm{int}}_{\mathcal{G},b_{x},\mu_{x}}\right)_{/x_{0}}^{\wedge}.$$

We may then define

$$\Theta_x := e \circ \Theta_w \circ \varepsilon^{-1} \colon \left( \mathcal{M}_{\mathcal{G}, b_x, \mu_x} \right)_{/x_0}^{\wedge} \xrightarrow{\sim} \operatorname{Spf} \left( \widehat{\mathcal{O}}_x \right)^{\lozenge}.$$

That  $\Theta_x(\mathscr{P}_{\mathsf{K}^p})$  is isomorphic to  $\mathscr{P}_x^{\mathrm{univ}}$  is easy as

$$\Theta_{x}(\mathscr{P}_{\mathsf{K}^{p}}) \simeq (\varepsilon^{-1})^{*}(\Theta_{w}^{*}(e^{*}\mathscr{P}_{\mathsf{K}^{p}}))) 
\simeq (\varepsilon^{-1})^{*}(\Theta_{w}^{*}(\mathscr{P}_{\mathsf{L}_{1}^{'p}} \times^{\mathcal{B}_{1}^{'c}} \mathcal{G}^{c})) 
\simeq (\varepsilon^{-1})^{*}(\Theta_{w}^{*}(\mathscr{P}_{\mathsf{L}_{1}^{'p}}) \times^{\mathcal{B}_{1}^{'c}} \mathcal{G}^{c}) 
\simeq (\varepsilon^{-1})^{*}(\mathscr{P}_{w}^{\mathrm{univ}} \times^{\mathcal{B}_{1}^{'c}} \mathcal{G}^{c}) 
\simeq \mathscr{P}_{x}^{\mathrm{univ}}.$$

Here the first isomorphism holds by definition, the second holds by our construction of  $\mathscr{P}_{\mathsf{K}^p}$  as in Step 3 of §5.2, the third holds from abstract nonsense, the fourth holds by our construction of  $\Theta_w$ , and the final isomorphism holds from the properties of  $\varepsilon$  stated in Proposition 5.12.

The proof of Theorem 4.10 now follows by combining Theorem 3.12 with Theorem 5.3 and Proposition 5.11.

#### <span id="page-45-0"></span>References

- <span id="page-45-7"></span>[ALY21] Piotr Achinger, Marcin Lara, and Alex Youcis, Variants of the de Jong fundamental group, arXiv preprint arXiv:2203.11750, 2021. 23
- <span id="page-45-4"></span>[BLR90] S. Bosch, W. Lütkebohmert, and M. Raynaud, *Néron models*, Ergebnisse der Mathematik und ihrer Grenzgebiete, Springer-Verlag, Berlin, 1990. 7
- <span id="page-45-5"></span>[Bor91] Armand Borel, *Linear algebraic groups*, second ed., Graduate Texts in Mathematics, vol. 126, Springer-Verlag, New York, 1991. MR 1102012 7
- <span id="page-45-3"></span>[Bor98] Mikhail Borovoi, Abelian Galois cohomology of reductive groups, Mem. Amer. Math. Soc. 132 (1998), no. 626, viii+50. MR 1401491 6
- <span id="page-45-8"></span>[BS15] Bhargav Bhatt and Peter Scholze, *The pro-étale topology for schemes*, Astérisque (2015), no. 369, 99–201. MR 3379634 32
- <span id="page-45-2"></span>[BT84] F. Bruhat and J. Tits, Groupes réductifs sur un corps local. II. Schémas en groups. existence d'une donnée radicielle valuée, Inst. Hautes Études Sci. Publ. Math. (1984), no. 60, 197–376. 5, 7
- <span id="page-45-1"></span>[Dan22] P. Daniels, Canonical integral models for Shimura varieties of toral type, arxiv preprint arxiv:2207.09513v2 (2022). 4, 25, 31, 32, 33, 34, 39, 45
- <span id="page-45-6"></span>[Del79] Pierre Deligne, Variétés de Shimura: interprétation modulaire, et techniques de construction de modèles canoniques, Automorphic forms, representations and L-functions (Proc. Sympos. Pure Math., Oregon State Univ., Corvallis, Ore., 1977), Part 2, Proc. Sympos. Pure Math., XXXIII, Amer. Math. Soc., Providence, R.I., 1979, pp. 247–289. MR 546620 13, 14, 17, 18, 21

- <span id="page-46-2"></span>[DvHKZ24a] Patrick Daniels, Pol van Hoften, Dongryul Kim, and Mingjia Zhang, *Igusa stacks for Shimura varieties of Hodge type*, preprint (2024). [3,](#page-2-2) [4](#page-3-1)
- <span id="page-46-4"></span>[DvHKZ24b] , *On a conjecture of Pappas and Rapoport*, preprint (2024). [4,](#page-3-1) [22,](#page-21-4) [34,](#page-33-7) [35](#page-34-3)
- <span id="page-46-15"></span>[FK18] Kazuhiro Fujiwara and Fumiharu Kato, *Foundations of rigid geometry. I*, EMS Monographs in Mathematics, European Mathematical Society (EMS), Zürich, 2018. MR 3752648 [23](#page-22-4)
- <span id="page-46-11"></span>[Gir71] Jean Giraud, *Cohomologie non abélienne*, Die Grundlehren der mathematischen Wissenschaften, Band 179, Springer-Verlag, Berlin-New York, 1971. MR 0344253 [12](#page-11-0)
- <span id="page-46-18"></span>[Gle20] I. Gleason, *Specialization maps for Scholze's category of diamonds*, arXiv preprint arXiv:2012.05483 (2020). [32](#page-31-1)
- <span id="page-46-19"></span>[Gle22] , *On the geometric connected components of moduli spaces of p-adic shtukas and local Shimura varieties*, arxiv preprint arxiv:2107.03579 (2022), 33. [33](#page-32-2)
- <span id="page-46-9"></span>[Gro66] A. Grothendieck, *Éléments de géométrie algébrique. IV. Étude locale des schémas et des morphismes de schémas. III*, Inst. Hautes Études Sci. Publ. Math. (1966), no. 28, 255. MR 217086 [8](#page-7-4)
- <span id="page-46-8"></span>[Gro67] , *Éléments de géométrie algébrique. IV. Étude locale des schémas et des morphismes de schémas IV*, Inst. Hautes Études Sci. Publ. Math. (1967), no. 32, 361. MR 238860 [8](#page-7-4)
- <span id="page-46-16"></span>[GW20] Ulrich Görtz and Torsten Wedhorn, *Algebraic geometry I. Schemes—with examples and exercises*, Springer Studium Mathematik—Master, Springer Spektrum, Wiesbaden, [2020] ©2020, Second edition [of 2675155]. MR 4225278 [26,](#page-25-1) [27,](#page-26-1) [30](#page-29-5)
- <span id="page-46-20"></span>[He16] Xuhua He, *Kottwitz-Rapoport conjecture on unions of affine Deligne-Lusztig varieties*, Ann. Sci. Éc. Norm. Supér. (4) **49** (2016), no. 5, 1125–1141. [33](#page-32-2)
- <span id="page-46-3"></span>[HL23] Linus Hamann and Si Ying Lee, *Torsion vanishing for some Shimura varieties*, arXiv e-prints (2023). [4](#page-3-1)
- <span id="page-46-7"></span>[HR08] Thomas Haines and Michael Rapoport, *On parahoric subgroups*, Advances in Mathematics **219** (2008), no. 1, 188–198. [7](#page-6-6)
- <span id="page-46-10"></span>[IKY23] N. Imai, H. Kato, and A. Youcis, *The prismatic realization functor for Shimura varieties of abelian type*, preprint (2023). [11,](#page-10-1) [31,](#page-30-3) [32,](#page-31-1) [34,](#page-33-7) [41,](#page-40-1) [42](#page-41-1)
- <span id="page-46-14"></span>[Kis10] M. Kisin, *Integral models for Shimura varieties of abelian type*, J. Amer. Math. Soc. **23** (2010), no. 4, 967–1012. [22,](#page-21-4) [34,](#page-33-7) [42,](#page-41-1) [43](#page-42-0)
- <span id="page-46-13"></span>[Kot84] Robert E. Kottwitz, *Shimura varieties and twisted orbital integrals*, Math. Ann. **269** (1984), no. 3, 287–300. MR 761308 [13](#page-12-3)
- <span id="page-46-0"></span>[Kot90] , *Shimura varieties and λ-adic representations*, Automorphic forms, Shimura varieties, and *L*-functions, Vol. I (Ann Arbor, MI, 1988), Perspect. Math., vol. 10, Academic Press, Boston, MA, 1990, pp. 161–209. MR 1044820 [2](#page-1-0)
- <span id="page-46-6"></span>[Kot97] , *Isocrystals with additional structure. II*, Compositio Math. **109** (1997), no. 3, 255–339. MR 1485921 [6](#page-5-4)
- <span id="page-46-12"></span>[KP18] M. Kisin and G. Pappas, *Integral models of Shimura varieties with parahoric level structure*, Publ. Math. Inst. Hautes Études Sci. (2018), no. 128, 121–218. [13,](#page-12-3) [15,](#page-14-4) [16,](#page-15-1) [17,](#page-16-3) [18,](#page-17-1) [19,](#page-18-1) [20,](#page-19-2) [21,](#page-20-3) [22,](#page-21-4) [23,](#page-22-4) [27,](#page-26-1) [30,](#page-29-5) [43](#page-42-0)
- <span id="page-46-5"></span>[KP23] Tasho Kaletha and Gopal Prasad, *Bruhat-Tits theory—a new approach*, New Mathematical Monographs, vol. 44, Cambridge University Press, Cambridge, 2023. MR 4520154 [5,](#page-4-3) [6,](#page-5-4) [7,](#page-6-6) [8,](#page-7-4) [9,](#page-8-5) [14,](#page-13-1) [19](#page-18-1)
- <span id="page-46-17"></span>[KSZ21] M. Kisin, S.W. Shin, and Y. Zhu, *The stable trace formula for Shimura varieties of abelian type*, arxiv preprint arXiv:2110.05381 (2021). [31,](#page-30-3) [32](#page-31-1)
- <span id="page-46-1"></span>[KZ21] M. Kisin and R. Zhou, *Independence of ℓ for Frobenius conjugacy classes attached to abelian varieties*, arxiv preprint arxiv:2103.09945 (2021), 66. [3,](#page-2-2) [7,](#page-6-6) [8,](#page-7-4) [9,](#page-8-5) [13,](#page-12-3) [15,](#page-14-4) [16,](#page-15-1) [17,](#page-16-3) [18,](#page-17-1) [19,](#page-18-1) [21,](#page-20-3) [22,](#page-21-4) [23,](#page-22-4) [35](#page-34-3)

- <span id="page-47-8"></span>[Lan00] E. Landvogt, *Some functorial properties of the Bruhat-Tits building*, J. Reine Angew. Math. **518** (2000), 213 – 241. [5](#page-4-3)
- <span id="page-47-6"></span>[Lov17a] T. Lovering, *Integral canonical models for automorphic vector bundles of abelian type*, Algebra Number Theory **11** (2017), no. 8, 1837–1890. [4,](#page-3-1) [36,](#page-35-1) [37](#page-36-3)
- <span id="page-47-20"></span>[Lov17b] Tom Lovering, *Filtered f-crystals on Shimura varieties of abelian type*, 2017. [42](#page-41-1)
- <span id="page-47-1"></span>[LR87] R. P. Langlands and M. Rapoport, *Shimuravarietäten und Gerben*, J. Reine Angew. Math. **378** (1987), 113–220. MR 895287 [2](#page-1-0)
- <span id="page-47-16"></span>[MFK94] D. Mumford, J. Fogarty, and F. Kirwan, *Geometric invariant theory*, third ed., Ergebnisse der Mathematik und ihrer Grenzgebiete (2) [Results in Mathematics and Related Areas (2)], vol. 34, Springer-Verlag, Berlin, 1994. MR 1304906 [22](#page-21-4)
- <span id="page-47-12"></span>[Mil05] J. S. Milne, *Introduction to Shimura varieties*, Harmonic analysis, the trace formula, and Shimura varieties, Clay Math. Proc., vol. 4, Amer. Math. Soc., 2005, pp. 265–378. [13,](#page-12-3) [15,](#page-14-4) [18](#page-17-1)
- <span id="page-47-2"></span>[Mil13] , *Shimura varieties and moduli*, Handbook of moduli. Vol. II, Adv. Lect. Math. (ALM), vol. 25, Int. Press, Somerville, MA, 2013, pp. 467–548. MR 3184183 [2,](#page-1-0) [3](#page-2-2)
- <span id="page-47-9"></span>[Mil17] J.S. Milne, *Algebraic groups: The theory of group schemes of finite type over a field*, vol. 170, Cambridge University Press, 2017. [6,](#page-5-4) [8,](#page-7-4) [10,](#page-9-1) [25,](#page-24-5) [31,](#page-30-3) [36](#page-35-1)
- <span id="page-47-13"></span>[Moo98] B. Moonen, *Models of Shimura varieties in mixed characteristics*, Galois representations in arithmetic algebraic geometry (Durham, 1996), London Math. Soc. Lecture Note Ser., vol. 254, Cambridge Univ. Press, 1998, pp. 267–350. [13](#page-12-3)
- <span id="page-47-14"></span>[MP16] Keerthi Madapusi Pera, *Integral canonical models for spin Shimura varieties*, Compos. Math. **152** (2016), no. 4, 769–824. MR 3484114 [15](#page-14-4)
- <span id="page-47-15"></span>[MS81] J. S. Milne and Kuang-yen Shih, *The action of complex conjugation on a Shimura variety*, Ann. of Math. (2) **113** (1981), no. 3, 569–599. MR 621017 [15](#page-14-4)
- <span id="page-47-3"></span>[Pap22] G. Pappas, *On integral models of Shimura varieties*, Math. Ann. (2022), 61. [2](#page-1-0)
- <span id="page-47-0"></span>[PR21] G. Pappas and M. Rapoport, *p-adic shtukas and the theory of local and global Shimura varieties*, arxiv preprint arXiv:2106.08270 (2021). [1,](#page-0-2) [2,](#page-1-0) [3,](#page-2-2) [4,](#page-3-1) [12,](#page-11-0) [22,](#page-21-4) [31,](#page-30-3) [32,](#page-31-1) [33,](#page-32-2) [34,](#page-33-7) [35,](#page-34-3) [39,](#page-38-4) [41,](#page-40-1) [43,](#page-42-0) [44](#page-43-3)
- <span id="page-47-21"></span>[PR22] , *On integral local Shimura varieties*, arxiv preprint arxiv:2204.02829 (2022), 56. [45](#page-44-2)
- <span id="page-47-18"></span>[RV14] M. Rapoport and E. Viehmann, *Towards a theory of local Shimura varieties*, Münster Journal of Mathematics **7** (2014), no. 1, 273–326. [32](#page-31-1)
- <span id="page-47-17"></span>[Sch13] P. Scholze, *p-adic Hodge theory for rigid-analytic varieties*, Forum Math. Pi. **1** (2013), 77. [32](#page-31-1)
- <span id="page-47-19"></span>[Sch17] , *Étale cohomology of diamonds*, arXiv preprint arXiv:1709.07343 (2017). [32](#page-31-1)
- <span id="page-47-11"></span>[Sta17] The Stacks Project Authors, *Stacks Project*, <http://stacks.math.columbia.edu>, 2017. [10,](#page-9-1) [11,](#page-10-1) [14,](#page-13-1) [15,](#page-14-4) [18,](#page-17-1) [19,](#page-18-1) [22,](#page-21-4) [23,](#page-22-4) [24,](#page-23-6) [25,](#page-24-5) [26,](#page-25-1) [28,](#page-27-2) [29,](#page-28-3) [30,](#page-29-5) [32](#page-31-1)
- <span id="page-47-10"></span>[Ste65] Robert Steinberg, *Regular elements of semisimple algebraic groups*, Inst. Hautes Études Sci. Publ. Math. (1965), no. 25, 49–80. MR 180554 [7](#page-6-6)
- <span id="page-47-4"></span>[SW20] P. Scholze and J. Weinstein, *Berkeley lectures on p-adic geometry:* (*AMS-207*), Annals of Mathematical Studies, Princeton University Press, 2020. [3,](#page-2-2) [32,](#page-31-1) [39,](#page-38-4) [42,](#page-41-1) [43](#page-42-0)
- <span id="page-47-7"></span>[vHS24] Pol van Hoften and Jack Sempliner, *On the Piatetski-Shapiro construction for integral models of Shimura varieties*, preprint (2024). [4,](#page-3-1) [35](#page-34-3)
- <span id="page-47-5"></span>[Zha23] Mingjia Zhang, *A PEL-type Igusa stack and the p-adic geometry of Shimura varieties*, arxive preprint arxiv:2309.05152 (2023). [3,](#page-2-2) [4](#page-3-1)

Mathematics and Statistics Department, Skidmore College, Saratoga Springs, NY 12866 *Email address*: pdaniels@skidmore.edu

Department of Mathematics, National University of Singapore, Level 4, Block S17, 10 Lower Kent Ridge Road, Singapore, 119076

*Email address*: alex.youcis@gmail.com