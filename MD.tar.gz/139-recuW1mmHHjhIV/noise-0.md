## Ultrafast Modification of Hubbard U in a Strongly Correlated Material: Ab initio **High-Harmonic Generation in NiO**

<span id="page-0-0"></span>Nicolas Tancogne-Dejean, 1,\* Michael A. Sentef, and Angel Rubio 1,2,3,† <sup>1</sup>Max Planck Institute for the Structure and Dynamics of Matter and Center for Free-Electron Laser Science, Luruper Chaussee 149, 22761 Hamburg, Germany <sup>2</sup>Nano-Bio Spectroscopy Group and ETSF, Universidad del País Vasco, 20018 San Sebastián, Spain <sup>3</sup>Center for Computational Quantum Physics (CCQ), The Flatiron Institute, 162 Fifth Avenue, New York, New York 10010, USA

(Received 4 December 2017; revised manuscript received 22 June 2018; published 30 August 2018)

Engineering effective electronic parameters is a major focus in condensed matter physics. Their dynamical modulation opens the possibility of creating and controlling physical properties in systems driven out of equilibrium. In this Letter, we demonstrate that the Hubbard U, the widely used on-site Coulomb repulsion in strongly correlated materials, can be modified on femtosecond timescales by a strong nonresonant laser pulse excitation in the prototypical charge-transfer insulator NiO. Using our recently developed time-dependent density-functional theory plus self-consistent U method, we demonstrate the importance of a dynamically modulated U in the description of the high-harmonic generation of NiO. Our study opens the door to novel ways of modifying effective interactions in strongly correlated materials via laser driving, which may lead to new control paradigms for field-induced phase transitions and perhaps laser-induced Mott insulation in charge-transfer materials.

DOI: 10.1103/PhysRevLett.121.097402

The interaction of strong subresonant driving fields with solids just below their damage threshold leads to very interesting phenomena, such as high-harmonic generation (HHG) [1–9]. HHG has, so far, mainly been interpreted in a pure single-particle band-structure picture, assuming that electrons behave as independent particles during the interaction with the laser pulse. In this simplified view, only the electronic occupations of the bands change and the band structure of a solid remains frozen during the lightmatter interaction, allowing for an interpretation in terms of inter- and intraband mechanisms within the single-particle band structure of the solid.

However, we know that laser driving can modify both the band structure and its topology [10–15] and the effective interactions [16-27] in solids, rendering the frozen-band and frozen-interaction scenarios questionable in many cases, in particular, in the context of light-induced metal insulator transitions [28–30], magnetic systems [31–36], and superconductivity [37–40], among others.

The usual argument for neglecting dynamical changes of the electron-electron interaction in strong field physics is that the strong excitation induced by the intense driving field completely dominates over these effects [41]. For atoms in strong fields, the correlation effects are usually small, even if they can be relevant in specific cases [42].

In solids, it was recently shown that assuming independent electrons is a perfectly valid approximation for HHG from bulk silicon [43], and that it performs also very well for bulk MgO [44]. However, the general validity of the frozen-band-structure approximation in strong driving fields must be questioned in correlated materials such as transition metal oxides. It has already been shown using time-dependent Hartree-Fock calculations that excitonic effects modify the HHG spectrum of a one-dimensional chain of H atoms [45].

In this Letter, we investigate dynamical effects originating from the electron-electron interaction in the context of strong field physics in solids, namely, in the HHG emission spectra. To do so, we focus on a class of strongly correlated materials, the transition metal oxides, which exhibit a wealth of interesting physical properties, covering superconductivity, magnetic materials, and Mott or chargetransfer insulators [46–49]. Those physical properties are governed by the localized and partially occupied 3d orbitals of the transition metal atoms. The electron-electron interaction in these orbitals is typically described by an effective on-site repulsion, referred to as Hubbard U. Since U plays a crucial role for the insulating behavior in charge-transfer and Mott insulators, these materials offer a test bed to challenge the general validity of the independent-particle approximation in strong field physics.

Assuming that electrons remain independent during the interaction with an ultrafast driving field directly implies that any effective parameter describing the solid can be seen as constant during the interaction. To challenge this approximation, one therefore needs a theoretical framework capable of capturing the time evolution of U. One possible approach to access this dynamics is to extend state-of-the-art methods, such as the constrained random-phase approximation (CRPA) [50–54], to the time-dependent case. However, these methods have a prohibitive computational cost, and dynamical screening in Mott insulators without considering changes of U has been studied in a model system only so far [55]. In equilibrium, these methods have already highlighted the impact of dynamical-U effects both on dynamical response functions and thermodynamic phases in strongly correlated materials (see, for instance, Ref. [54]). In out-of-equilibrium settings such as strongly driven materials, the dynamical renormalization of U is therefore expected to lead to similarly important consequences.

Here we use the recently proposed ACBN0 functional [56], based on earlier work of Refs. [57], which can be seen as a pseudohybrid reformulation of the density-functional theory plus Hubbard U (DFT + U) method. This functional directly allows, by solving generalized Kohn-Sham equations, us to compute the Hubbard U and Hund's J ab initio and self-consistently, without the need of a supercell, where U and J have to be understood as the intra-atomic values averaged over the localized orbitals. The time-dependent generalized Kohn-Sham equations within the adiabatic approximation reads (in atomic units) [58]

$$\begin{split} i\frac{\partial}{\partial t}|\psi_{i}^{\sigma}(t)\rangle &= \left(-\frac{\nabla^{2}}{2} + \hat{v}_{\text{ext}}(t) + \hat{v}_{H}[n(\mathbf{r},t)] \right. \\ &+ \hat{v}_{\text{xc}}[n(\mathbf{r},t)] + \hat{V}_{U}[n(\mathbf{r},t),\{n_{mm'}^{\sigma}\}]\right)|\psi_{i}^{\sigma}(t)\rangle. \end{split} \tag{1}$$

where  $|\psi_{n,\mathbf{k}}^{\sigma}\rangle$  is a Bloch state with a band index n, at the point  $\mathbf{k}$  in the Brillouin zone and with the spin index  $\sigma$ ,  $v_{\rm ext}$  is the external potential containing both the driving laser field and the ionic potential,  $v_H$  is the Hartree potential,  $v_{\rm xc}$  is the exchange-correlation potential, and  $\hat{V}_U^{\sigma}$  is the plus U (nonlocal) operator

$$\hat{V}_{U}^{\sigma}[n, \{n_{mm'}^{\sigma}\}] = U_{\text{eff}} \sum_{m,m'} \left(\frac{1}{2} \delta_{mm'} - n_{mm'}^{\sigma}\right) \hat{P}_{m,m'}^{\sigma}. \quad (2)$$

Here  $\hat{P}_{mm'} = |\phi_m^{\sigma}\rangle\langle\phi_{m'}^{\sigma}|$  is the projector over the localized subspace defined by the localized orbitals  $\{\phi_m^{\sigma}\}$ , and  $n^{\sigma}$  is the density matrix of the localized subspace. The expressions of U and J in terms of the occupations are given in the Supplemental Material [59].

This method has been recently extended by some of us to the real-time case [65], within the framework of time-dependent density-functional theory (TDDFT) [66,67]. TDDFT + U is in practice a computationally efficient method to simulate the electronic response of systems driven out of equilibrium without relying on perturbation theory. It has been shown to yield accurate electronic band gaps, effective U, and surprisingly good linear absorption spectra of the charge-transfer insulators NiO and MnO [65]. Motivated by these promising results, we propose here to

employ this method to access the time evolution of U of systems driven out of equilibrium.

Using this fully *ab initio* TDDFT + U framework, we study HHG in bulk charge-transfer insulators, taking nickel oxide as a prototypical material. We show that, in the nonperturbative regime required to obtain HHG, U is strongly modified on the timescale of the laser pulse. We find that neglecting the dynamics of U leads to a modified HHG spectrum, showing that dynamical effects originating from the electron-electron interaction can strongly affect the nonlinear properties of solids driven by strong laser fields.

All the calculations presented here were performed for bulk NiO, which is a type-II antiferromagnetic material below its Néel temperature ( $T_N = 523 \text{ K } [68]$ ) [69]. The driving field is taken along the [001] crystallographic direction in all the calculations. We consider a laser pulse of 25 fs duration (FWHM), with a sin-square envelope for the vector potential. The carrier wavelength  $\lambda$  is 3000 nm, corresponding to a carrier photon energy of 0.43 eV. The time-dependent wave functions, current, and  $U_{\rm eff}$  are computed by propagating generalized Kohn-Sham equations within TDDFT + U, as provided by the Octopus package [70]. We employed the Perdew-Burke-Ernzerhof (PBE) functional [71] for describing the semilocal DFT part, and we computed the effective  $U_{\rm eff} = U - J$  for the O 2p  $(U_{\text{eff}}^{2p})$  for one of the Ni 3d orbitals  $(U_{\text{eff}}^{3d})$ , using localized atomic orbitals from the corresponding pseudopotentials [65]. Our ground-state values for U and J are consistent with other publications [56,65].

From Fig. 1, we find that the effective Hubbard U is strongly modified by the applied laser, and that it decreases for both the O 2p and Ni 3d orbitals. Moreover, increasing the driving field intensity [72] leads to a stronger decrease of U. The reduction of U is understood as follows. Dividing the Hilbert space into a localized subspace and the rest, as commonly done in CRPA [50–53], it is clear that the screening, originating from the polarization associated with the rest of the system, increases as electrons are pumped from the localized subspace to the delocalized rest. This enhanced screening leads to a dynamical decrease of U.

The time-dependent U exhibits oscillations at twice the frequency of the laser field, in agreement with the proposed mechanism, as each extrema of the electric field corresponds to the excitation of carriers to the conduction bands (see the Supplemental Material [59] for the direct comparison to the population of the localized orbitals).

It is worth noting that, at higher intensities, the variation of U is faster and then saturates to the same final value (see red lines in Fig. 1). This saturation is expected, as the localized states only have a finite number of electrons to be excited, and therefore the decrease of U must saturate as the intensity increases. However, a more thorough analysis (cf. Supplemental Material [59]) reveals that the saturation originates from the rapid change of the effective on-site screening.

<span id="page-2-0"></span>![](_page_2_Figure_1.jpeg)

FIG. 1. Self-consistent dynamics of Hubbard U for the Ni 3d orbitals (middle) and the oxygen 2p orbitals (bottom) for pump intensities as indicated. (Top) Represents the time-dependent vector potential, and the vertical dashed lines indicate the extrema of the vector potential, i.e., the minima of the driving electric field.

The final depletion of U, as taken from the long-time limit in Fig. 1, is shown in Fig. 2. We observe that, at moderate field strengths, the variation of U is proportional to the electric field strength, as expected from the linear response of the polarization, and then deviates from linear scaling, demonstrating a transition from linear to nonlinear reduction of U. We found that, for moderate field strength,  $-\Delta U_{\rm eff}^{3d} \approx 3.28E$  and  $-\Delta U_{\rm eff}^{2p} \approx 2.15E$ , where E is the electric field strength. The dynamics of U not only depends on the intensity of the driving pulse, but also depends on the shape and the length of the applied laser pulse. From these results, it is clear that it is not possible to assume that the Hubbard U remains constant during the interaction with the strong driving field, thus indicating, in principle, a breakdown of the widely assumed independent-particle or frozen-band-structure approximation for strongly correlated materials.

In order to confirm that the Hubbard U reduction comes from the promotion of localized electrons to conduction bands, we also compute the magnetization of the system, spherically averaged around the Ni atoms. As shown in Fig. 3, the Ni magnetization decreases together with

<span id="page-2-1"></span>![](_page_2_Figure_5.jpeg)

FIG. 2. Calculated change of U at the end of the laser pulse versus the peak driving field strength, for the Ni 3d orbitals (red curve) and the O 2p orbitals (blue curve). The dashed lines indicate a linear scaling in electric field strength, as expected from linear response theory. The calculated ground-state value of  $U_{\rm eff}$  is 6.93 eV.

Hubbard U, thus confirming our physical interpretation. Interestingly, we do not observe a saturation of the demagnetization of the Ni atoms, as opposed to the final decrease of U, which is saturated for the corresponding laser intensities. This is compatible with the fact that the saturation observed in Fig. 1 originates mainly from the fast change of the on-site screening. This interpretation is independently verified by performing ground-state DFT + U calculations using constrained occupations,

<span id="page-2-2"></span>![](_page_2_Figure_8.jpeg)

FIG. 3. Time evolution of the magnetization integrated around the Ni atoms for different driving intensities. We only report the magnetization computed around one of the Ni atoms, as the two atoms are found to have exactly opposite magnetization, as expected for the antiferromagnetic phase considered here. The magnetization is calculated by averaging over a sphere of radius 1.97 bohr around the Ni atom.

which confirm that the change in U is directly linked to the change in population on the localized orbitals (cf. Supplemental Material [59]). It is interesting to note the analogy between our results and LDA + DMFT calculations [73], in which it was found that doping NiO with holes leads to a reduction of the band gap and of the magnetic moment of the Ni atoms (from 1.85  $\mu_B$  up to 1.45  $\mu_B$  depending on the hole doping). The fact that the band gap and the magnetization change with the occupations of the localized orbitals reflects the multiorbital correlated character of NiO, which is captured by our time-dependent approach.

To get more insight about the relevance of the dynamical Hubbard U for describing the strong field response of NiO, we compute its HHG spectrum with dynamical and static U(Fig. 4). From Fig. 4, it is clear that neglecting the dynamics of U in NiO leads to a strongly modified HHG spectrum (see the Supplemental Material [59] for different intensities and a comparison with PBE). Indeed, freezing  $U_{\rm eff}$  to its ground-state value of 6.93 eV implies that the band structure, and, in particular, the band gap of the material, remains constant during laser irradiation. The light-induced reduction of U (by about 10%) implies that the band gap of the material becomes "dynamically" smaller during the laser pulse. As a direct consequence, the required excitation energy for Zener tunneling or multiphoton ionization decreases. Indeed, this energy depends directly on the number of photons needed to reach the band gap, thus reducing the band gap leads to a stronger excitation of electrons and therefore to stronger harmonic emission. Another important implication is that a dynamical U introduces a novel dimension that in the strong field response of solids, i.e., time. Indeed, in usual semiconductors, changing the length of the driving pulse only

<span id="page-3-0"></span>![](_page_3_Figure_3.jpeg)

FIG. 4. Effect of the time evolution of U (from Fig. 1) on the HHG spectrum of NiO. The HHG spectrum obtained from the full time evolution is shown in black, whereas the spectrum obtained for frozen U is shown in red. The red vertical line indicates the calculated ground-state band gap of NiO. The intensity is taken here as  $I_0 = 10^{12}~W~{\rm cm}^{-2}$ .

results in a change of the width of the harmonic peaks, as long as a pulse contains more than few optical cycles [74,75]. Effects such as the Stark effect [76] or the renormalization of the bands due to the coupling to the laser pulse [15] are usually quite small for the laser parameters considered in HHG from solids. The band structure of these solids remains unchanged on the timescale of the optical pulse [43], and two consecutive nonoverlapping pulses result in the same harmonic emission. However, for the case of NiO, a longer (shorter) pulse will lead to a more (less) important decrease of U, and a subsequent delayed pulse would feel a modify band structure, due to the reduction of U by the first pulse, resulting in a modified harmonic emission. In addition to HHG, we checked that our method reproduces well available experimental values for the low-energy thirdorder susceptibility  $\chi^3$  (see Supplemental Material [59]).

In summary, we investigated the HHG spectra of the prototypical charge-transfer insulator NiO driven by a strong below gap laser pulse excitation. We showed that the strong laser intensity needed to generate high-order harmonics in NiO induces a significant change of Hubbard U as a result of the increase of the screening from the photoexcited itinerant electrons. Neglecting the change in U strongly affects the solid HHG spectrum, demonstrating the measurable importance of the time dependence of U in the nonlinear response of the material to a strong laser field.

Our results demonstrate that dynamical modification of the electronic parameters in correlated materials is indeed possible by purely electronic means without involving the crystal lattice. This should be contrasted with other dynamical perturbations, such as, for instance, the concept of nonlinear phononics [77,78], in which direct excitations of optical phonons are used to induce such changes and trigger light-induced phase transitions. The timescales for phononic modifications of parameters are typically in the picosecond range, whereas here we showed that a much faster modification on femtosecond timescales is possible with our suggested mechanism, which might bear practical relevance for ultrafast switching processes. Conceptually, this faster mechanism may also allow us to disentangle electronic and phononic dynamics and also study cases in which such a decoupling is not possible, for instance, when the Born-Oppenheimer approximation breaks down [79]. The proposed effect could be detected experimentally using pump-probe spectroscopy. One could measure band-structure renormalizations in time-, angle-resolved photoemission spectroscopy, or one could detect the changes in terahertz conductivity or optical reflectivity in the time domain. Finally, we note that coupling to phonons and impurities, not considered in this Letter, is expected to revert the laser-induced changes on hundreds of femtosecond to picosecond timescales by relaxing back to thermal equilibrium the nonequilibrium occupations responsible for the modified screening.

From a methodological point of view, the developed TDDFT + U formalism allows for practical calculations from first principles of dynamically modulated U and other relevant couplings in real materials. In order to be efficient in controlling the dynamical properties of correlated materials, further studies should address the effect of the renormalization of U due to other excitations, such as, for instance, phonon dynamics, magnetic spin waves, and heat fluctuations, and compare it with the present effect. We expect that this work will pave the way for predicting and modeling interesting and potentially technologically relevant correlated materials for applications in ultrafast optoelectronics, magnetism, or spintronics.

A. R. acknowledges financial support from the European Research Council (ERC-2015-AdG-694097), Grupos Consolidados (IT578-13), and European Union's H2020 program under GA No. 676580 (NOMAD), and M. A. S. through the DFG Emmy Noether programme (SE 2558/2-1). We would like to thank O. D. Mücke and M. Altarelli for fruitful discussions.

- <span id="page-4-1"></span><span id="page-4-0"></span>\*nicolas.tancogne-dejean@mpsd.mpg.de †angel.rubio@mpsd.mpg.de
- <span id="page-4-2"></span>[1] S. Ghimire, A. D. DiChiara, E. Sistrunk, P. Agostini, L. F. DiMauro, and D. A. Reis, Nat. Phys. **7**, 138 (2011).
- [2] O. Schubert, M. Hohenleutner, F. Langer, B. Urbanek, C. Lange, U. Huttner, D. Golde, T. Meier, M. Kira, S. W. Koch, and R. Huber, Nat. Photonics **8**, 119 (2014).
- [3] M. Hohenleutner, F. Langer, O. Schubert, M. Knorr, U. Huttner, S. W. Koch, M. Kira, and R. Huber, Nature (London) **523**, 572 (2015).
- [4] T. T. Luu, M. Garg, S. Y. Kruchinin, A. Moulet, M. T. Hassan, and E. Goulielmakis, Nature (London) **521**, 498 (2015).
- [5] G. Ndabashimiye, S. Ghimire, M. Wu, D. A. Browne, K. J. Schafer, M. B. Gaarde, and D. A. Reis, Nature (London) 534, 520 (2016).
- [6] G. Vampa, T. J. Hammond, N. Thiré, B. E. Schmidt, F. Légaré, C. R. McDonald, T. Brabec, and P. B. Corkum, Nature (London) 522, 462 (2015).
- [7] H. Liu, Y. Li, Y. S. You, S. Ghimire, T. F. Heinz, and D. A. Reis, Nat. Phys. 13, 262 (2017).
- [8] Y. S. You, D. A. Reis, and S. Ghimire, Nat. Phys. **13**, 345 (2017).
- <span id="page-4-3"></span>[9] F. Langer, M. Hohenleutner, U. Huttner, S. W. Koch, M. Kira, and R. Huber, Nat. Photonics 11, 227 (2017).
- [10] T. Oka and H. Aoki, Phys. Rev. B 79, 081406 (2009).
- [11] N. H. Lindner, G. Refael, and V. Galitski, Nat. Phys. 7, 490 (2011).
- [12] Y. H. Wang, H. Steinberg, P. Jarillo-Herrero, and N. Gedik, Science 342, 453 (2013).
- [13] F. Mahmood, C.-K. Chan, Z. Alpichshev, D. Gardner, Y. Lee, P. A. Lee, and N. Gedik, Nat. Phys. 12, 306 (2016).
- [14] M. A. Sentef, M. Claassen, A. F. Kemper, B. Moritz, T. Oka, J. K. Freericks, and T. P. Devereaux, Nat. Commun. 6, 7047 (2015).

- <span id="page-4-8"></span>[15] H. Hübener, M. A. Sentef, U. D. Giovannini, A. F. Kemper, and A. Rubio, Nat. Commun. 8, 13940 (2017).
- <span id="page-4-4"></span>[16] Z. M. Raines, V. Stanev, and V. M. Galitski, Phys. Rev. B 91, 184506 (2015).
- [17] D. M. Kennes, E. Y. Wilner, D. R. Reichman, and A. J. Millis, Nat. Phys. 13, 479 (2017).
- [18] M. A. Sentef, Phys. Rev. B 95, 205111 (2017).
- [19] M. Knap, M. Babadi, G. Refael, I. Martin, and E. Demler, Phys. Rev. B 94, 214504 (2016).
- [20] A. Komnik and M. Thorwart, Euro. Phys. J. B 89, 244 (2016).
- [21] M. Babadi, M. Knap, I. Martin, G. Refael, and E. Demler, Phys. Rev. B 96, 014512 (2017).
- [22] Y. Murakami, N. Tsuji, M. Eckstein, and P. Werner, Phys. Rev. B 96, 045125 (2017).
- [23] G. Mazza and A. Georges, Phys. Rev. B 96, 064515 (2017).
- [24] E. Pomarico, M. Mitrano, H. Bromberger, M. A. Sentef, A. Al-Temimy, C. Coletti, A. Stöhr, S. Link, U. Starke, C. Cacho, R. Chapman, E. Springate, A. Cavalleri, and I. Gierz, Phys. Rev. B 95, 024304 (2017).
- [25] J. R. Coulthard, S. R. Clark, S. Al-Assam, A. Cavalleri, and D. Jaksch, Phys. Rev. B 96, 085104 (2017).
- [26] D. Shin, H. Hübener, U. De Giovannini, H. Jin, A. Rubio, and N. Park, Nat. Commun. 9, 638 (2018).
- [27] M. A. Sentef, M. Ruggenthaler, and A. Rubio, arXiv: 1802.09437.
- <span id="page-4-5"></span>[28] M. Rini, R. Tobey, N. Dean, J. Itatani, Y. Tomioka, Y. Tokura, R. W. Schoenlein, and A. Cavalleri, Nature (London) 449, 72 (2007).
- [29] A. D. Caviglia, R. Scherwitzl, P. Popovich, W. Hu, H. Bromberger, R. Singla, M. Mitrano, M. C. Hoffmann, S. Kaiser, P. Zubko, S. Gariglio, J.-M. Triscone, M. Först, and A. Cavalleri, Phys. Rev. Lett. 108, 136801 (2012).
- [30] L. Stojchevska, I. Vaskivskyi, T. Mertelj, P. Kusar, D. Svetin, S. Brazovskii, and D. Mihailovic, Science 344, 177 (2014).
- <span id="page-4-6"></span>[31] A. V. Kimel, A. Kirilyuk, F. Hansteen, R. V. Pisarev, and T. Rasing, J. Phys. Condens. Matter 19, 043201 (2007).
- [32] A. Kirilyuk, A. V. Kimel, and T. Rasing, Rev. Mod. Phys. **82**, 2731 (2010).
- [33] M. Först, R. I. Tobey, S. Wall, H. Bromberger, V. Khanna, A. L. Cavalieri, Y.-D. Chuang, W. S. Lee, R. Moore, W. F. Schlotter, J. J. Turner, O. Krupin, M. Trigo, H. Zheng, J. F. Mitchell, S. S. Dhesi, J. P. Hill, and A. Cavalleri, Phys. Rev. B 84, 241104 (2011).
- [34] M. Först et al., Nat. Mater. 14, 883 (2015).
- [35] J. H. Mentink, K. Balzer, and M. Eckstein, Nat. Commun. 6, 6708 (2015).
- [36] T. F. Nova, A. Cartella, A. Cantaluppi, M. Först, D. Bossini, R. V. Mikhaylovskiy, A. V. Kimel, R. Merlin, and A. Cavalleri, Nat. Phys. **13**, 132 (2017).
- <span id="page-4-7"></span>[37] D. Fausti, R. I. Tobey, N. Dean, S. Kaiser, A. Dienst, M. C. Hoffmann, S. Pyon, T. Takayama, H. Takagi, and A. Cavalleri, Science **331**, 189 (2011).
- [38] S. Kaiser, C. R. Hunt, D. Nicoletti, W. Hu, I. Gierz, H. Y. Liu, M. Le Tacon, T. Loew, D. Haug, B. Keimer, and A. Cavalleri, Phys. Rev. B 89, 184516 (2014).
- [39] W. Hu, S. Kaiser, D. Nicoletti, C. R. Hunt, I. Gierz, M. C. Hoffmann, M. Le Tacon, T. Loew, B. Keimer, and A. Cavalleri, Nat. Mater. 13, 705 (2014).

- [40] M. Mitrano, A. Cantaluppi, D. Nicoletti, S. Kaiser, A. Perucchi, S. Lupi, P. Di Pietro, D. Pontiroli, M. Riccò, S. R. Clark, D. Jaksch, and A. Cavalleri, Nature (London) 530, 461 (2016).
- <span id="page-5-0"></span>[41] U. Huttner, M. Kira, and S. W. Koch, Laser Photonics Rev. 11, 1700049 (2017).
- <span id="page-5-1"></span>[42] A. D. Shiner, B. E. Schmidt, C. Trallero-Herrero, H. J. Wörner, S. Patchkovskii, P. B. Corkum, J.-C. Kieffer, F. Légaré, and D. M. Villeneuve, Nat. Phys. 7, 464 (2011).
- <span id="page-5-2"></span>[43] N. Tancogne-Dejean, O. D. Mücke, F. X. Kärtner, and A. Rubio, Phys. Rev. Lett. 118, 087403 (2017).
- <span id="page-5-3"></span>[44] N. Tancogne-Dejean, O. D. Mücke, F. X. Kärtner, and A. Rubio, Nat. Commun. 8, 745 (2017).
- <span id="page-5-4"></span>[45] T. Ikemachi, Y. Shinohara, T. Sato, J. Yumoto, M. Kuwata-Gonokami, and K. L. Ishikawa, Phys. Rev. A 98, 023415 (2018).
- <span id="page-5-5"></span>[46] J. Zaanen, G. A. Sawatzky, and J. W. Allen, Phys. Rev. Lett. 55, 418 (1985).
- [47] M. Imada, A. Fujimori, and Y. Tokura, Rev. Mod. Phys. 70, 1039 (1998).
- [48] P. A. Lee, N. Nagaosa, and X.-G. Wen, Rev. Mod. Phys. 78, 17 (2006).
- [49] B. Keimer, S. A. Kivelson, M. R. Norman, S. Uchida, and J. Zaanen, Nature (London) 518, 179 (2015).
- <span id="page-5-6"></span>[50] T. Miyake and F. Aryasetiawan, Phys. Rev. B 77, 085122 (2008).
- [51] M. Aichhorn, L. Pourovskii, V. Vildosola, M. Ferrero, O. Parcollet, T. Miyake, A. Georges, and S. Biermann, Phys. Rev. B 80, 085101 (2009).
- [52] T. Miyake, F. Aryasetiawan, and M. Imada, Phys. Rev. B 80, 155134 (2009).
- [53] M. Aichhorn, S. Biermann, T. Miyake, A. Georges, and M. Imada, Phys. Rev. B 82, 064504 (2010).
- <span id="page-5-8"></span>[54] P. Werner, M. Casula, T. Miyake, F. Aryasetiawan, A. J. Millis, and S. Biermann, Nat. Phys. 8, 331 (2012).
- <span id="page-5-7"></span>[55] D. Golež, M. Eckstein, and P. Werner, Phys. Rev. B 92, 195123 (2015).
- <span id="page-5-9"></span>[56] L. A. Agapito, S. Curtarolo, and M. B. Nardelli, Phys. Rev. X 5, 011006 (2015).
- <span id="page-5-10"></span>[57] N. J. Mosey and E. A. Carter, Phys. Rev. B 76, 155123 (2007); N. J. Mosey, P. Liao, and E. A. Carter, J. Chem. Phys. 129, 014103 (2008).
- <span id="page-5-11"></span>[58] The nonlocal part of the pseudopotential is omitted for conciseness.
- <span id="page-5-12"></span>[59] See Supplemental Material at http://link.aps.org/ supplemental/10.1103/PhysRevLett.121.097402 for further analysis of the reported data, which includes Refs. [60–64].
- [60] W. E. Pickett, S. C. Erwin, and E. C. Ethridge, Phys. Rev. B 58, 1201 (1998).
- [61] M. Cococcioni and S. de Gironcoli, Phys. Rev. B 71, 035105 (2005).

- [62] Y. Takimoto, F. D. Vila, and J. J. Rehr, J. Chem. Phys. 127, 154114 (2007).
- [63] T. Chtouki, L. Soumahoro, B. Kulyk, H. Bougharraf, B. Kabouchi, H. Erguig, and B. Sahraoui, Optik (Stuttgart) **128**, 8 (2017).
- [64] M. Shkir, V. Ganesh, S. AlFaify, I. Yahia, and H. Zahran, J. Mater. Sci. 29, 6446 (2018).
- <span id="page-5-13"></span>[65] N. Tancogne-Dejean, M. J. T. Oliveira, and A. Rubio, Phys. Rev. B 96, 245133 (2017).
- <span id="page-5-14"></span>[66] E. Runge and E. K. U. Gross, Phys. Rev. Lett. **52**, 997 (1984).
- [67] R. van Leeuwen, Phys. Rev. Lett. 82, 3863 (1999).
- <span id="page-5-15"></span>[68] A. P. Cracknell and S. J. Joshua, Math. Proc. Cambridge Philos. Soc. 66, 493 (1969).
- <span id="page-5-16"></span>[69] Below its Néel temperature, NiO exhibits a rhombohedral structure, which is obtained by contraction of the original cubic cell along one of the [111] directions [68]. However, we have neglected the small distortions and considered NiO in its cubic rock-salt structure, which does not affect the result of calculated optical spectra. Calculations were performed using a lattice parameter of 4.1704 Å, a real-space spacing of  $\Delta r = 0.293$  bohr, and a  $28 \times 28 \times 28$  k-point grid to sample the Brillouin zone. We employ norm-conserving pseudopotentials. For such few-cycle driver pulses, the HHG spectra from solids have been shown to be quite insensitive to the carrier-envelope phase, which is therefore taken to be zero here.
- <span id="page-5-17"></span>[70] X. Andrade, D. Strubbe, U. De Giovannini, A. H. Larsen, M. J. T. Oliveira, J. Alberdi-Rodriguez, A. Varas, I. Theophilou, N. Helbig, M. J. Verstraete, L. Stella, F. Nogueira, A. Aspuru-Guzik, A. Castro, M. A. L. Marques, and A. Rubio, Phys. Chem. Chem. Phys. 17, 31371 (2015).
- <span id="page-5-18"></span>[71] J. P. Perdew, K. Burke, and M. Ernzerhof, Phys. Rev. Lett. 77, 3865 (1996).
- <span id="page-5-19"></span>[72] Note that the intensity  $I_0$  is defined here without the refractive index as  $I_0 = (c\epsilon_0/2)E^2$ , where E is the peak electric field strength, c is the velocity of light in vacuum, and  $\epsilon_0$  is the vacuum permittivity.
- <span id="page-5-20"></span>[73] J. Kuneš, V. I. Anisimov, A. V. Lukoyanov, and D. Vollhardt, Phys. Rev. B 75, 165115 (2007).
- <span id="page-5-21"></span>[74] F. Krausz and M. Ivanov, Rev. Mod. Phys. 81, 163 (2009).
- [75] Z. Chang, Fundamentals of Attosecond Optics (CRC Press, Boca Raton, FL, 2016).
- <span id="page-5-22"></span>[76] U. De Giovannini, H. Hübener, and A. Rubio, Nano Lett. 16, 7993 (2016).
- <span id="page-5-23"></span>[77] M. Först, C. Manzoni, S. Kaiser, Y. Tomioka, Y. Tokura, R. Merlin, and A. Cavalleri, Nat. Phys. 7, 854 (2011).
- [78] A. Subedi, A. Cavalleri, and A. Georges, Phys. Rev. B **89**, 220301 (2014).
- <span id="page-5-24"></span>[79] J. C. Tully, Annu. Rev. Phys. Chem. **51**, 153 (2000).