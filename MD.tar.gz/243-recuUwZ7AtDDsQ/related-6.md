### [Skip to main content](#page-1-0) [Cornell University](https://www.cornell.edu/)

We gratefully acknowledge support from the Simons Foundation, [member](https://info.arxiv.org/about/ourmembers.html) [institutions](https://info.arxiv.org/about/ourmembers.html), and all contributors. [Donate](https://info.arxiv.org/about/donate.html)

> [astro-ph](file:///list/astro-ph/recent) > arXiv:1503.01116 [arxiv logo](file:///)

#### [Help](https://info.arxiv.org/help) | [Advanced Search](https://arxiv.org/search/advanced)

![](_page_0_Picture_4.jpeg)

#### [arXiv logo](https://arxiv.org/)

[Cornell University Logo](https://www.cornell.edu/)

![](_page_0_Picture_7.jpeg)

| header |    |
|--------|----|
| all    |    |
|        | GO |

![](_page_1_Picture_0.jpeg)

## **quick links**

- [Login](https://arxiv.org/login) •
- [Help Pages](https://info.arxiv.org/help) •
- [About](https://info.arxiv.org/about) •

# <span id="page-1-0"></span>**Astrophysics > Cosmology and Nongalactic Astrophysics**

**arXiv:1503.01116** (astro-ph) [Submitted on 3 Mar 2015]

# **Title:Raising the bar: new constraints on the Hubble parameter with cosmic chronometers at z\$\sim\$2**

Authors:[Michele Moresco](https://arxiv.org/search/astro-ph?searchtype=author&query=Moresco,+M) [View PDF](file:///pdf/1503.01116)

> Abstract:One of the most compelling tasks of modern cosmology is to constrain the expansion history of the Universe, since this measurement can give insights on the nature of dark energy and help to estimate cosmological parameters. In this letter are presented two new measurements of the Hubble parameter H(z) obtained with the cosmic chronometer method up to \$z\sim2\$. Taking advantage of near-infrared spectroscopy of the few very

massive and passive galaxies observed at \$z>1.4\$ available in literature, the differential evolution of this population is estimated and calibrated with different stellar population synthesis models to constrain H(z), including in the final error budget all possible sources of systematic uncertainties (star formation history, stellar metallicity, model dependencies). This analysis is able to extend significantly the redshift range coverage with respect to presentday constraints, crossing for the first time the limit at \$z\sim1.75\$. The new H(z) data are used to estimate the gain in accuracy on cosmological parameters with respect to previous measurements in two cosmological models, finding a small but detectable improvement (\$\sim\$5 %) in particular on \$\Omega\_{M}\$ and \$w\_{0}\$. Finally, a simulation of a Euclid-like survey has been performed to forecast the expected improvement with future data. The provided constraints have been obtained just with the cosmic chronometers approach, without any additional data, and the results show the high potentiality of this method to constrain the expansion history of the Universe at these redshifts.

Comments: 5 pages, 4 figures. Accepted for publication as MNRAS letter. The

H(z) data can be downloaded at [this http URL](http://www.physics-astronomy.unibo.it/en/research/areas/astrophysics/cosmology-with-cosmic-chronometers)

Subjects: Cosmology and Nongalactic Astrophysics (astro-ph.CO)

Cite as: [arXiv:1503.01116](https://arxiv.org/abs/1503.01116) [astro-ph.CO]

(or [arXiv:1503.01116v1](https://arxiv.org/abs/1503.01116v1) [astro-ph.CO] for this version)

<https://doi.org/10.48550/arXiv.1503.01116>

Focus to learn more

arXiv-issued DOI via DataCite

<https://doi.org/10.1093/mnrasl/slv037>

Related DOI:

Focus to learn more

DOI(s) linking to related resources

## **Submission history**

From: Michele Moresco [\[view email\]](file:///show-email/0519c928/1503.01116)

**[v1]** Tue, 3 Mar 2015 21:00:11 UTC (1,341 KB)

Full-text links:

## **Access Paper:**

- [View PDF](file:///pdf/1503.01116) •
- [TeX Source](file:///src/1503.01116) •
- [Other Formats](file:///format/1503.01116) •

[view license](http://arxiv.org/licenses/nonexclusive-distrib/1.0/)

Current browse context: astro-ph.CO [< prev](file:///prevnext?id=1503.01116&function=prev&context=astro-ph.CO) | [next >](file:///prevnext?id=1503.01116&function=next&context=astro-ph.CO) [new](file:///list/astro-ph.CO/new) | [recent](file:///list/astro-ph.CO/recent) | [2015-03](file:///list/astro-ph.CO/2015-03) Change to browse by: [astro-ph](file:///abs/1503.01116?context=astro-ph)

### **References & Citations**

- [INSPIRE HEP](https://inspirehep.net/arxiv/1503.01116) •
- [NASA ADS](https://ui.adsabs.harvard.edu/abs/arXiv:1503.01116) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?arxiv_id=1503.01116) •
- [Semantic Scholar](https://api.semanticscholar.org/arXiv:1503.01116) •

export BibTeX citation

### **Bookmark**

[BibSonomy logo](http://www.bibsonomy.org/BibtexHandler?requTask=upload&url=https://arxiv.org/abs/1503.01116&description=Raising%20the%20bar:%20new%20constraints%20on%20the%20Hubble%20parameter%20with%20cosmic%20chronometers%20at%20z$%5Csim$2) [Reddit logo](https://reddit.com/submit?url=https://arxiv.org/abs/1503.01116&title=Raising%20the%20bar:%20new%20constraints%20on%20the%20Hubble%20parameter%20with%20cosmic%20chronometers%20at%20z$%5Csim$2)

Bibliographic Tools

## **Bibliographic and Citation Tools**

| Bibliographic Explorer Toggle                        |
|------------------------------------------------------|
| Bibliographic Explorer<br>(What is the Explorer?)    |
| Connected Papers Toggle                              |
| Connected Papers<br>(What is Connected Papers?)      |
| Litmaps Toggle                                       |
| Litmaps<br>(What is Litmaps?)                        |
| scite.ai Toggle                                      |
| scite Smart Citations<br>(What are Smart Citations?) |
|                                                      |
|                                                      |
| Code, Data, Media                                    |
|                                                      |

# **Code, Data and Media Associated with this Article**

| alphaXiv Toggle |                     |  |
|-----------------|---------------------|--|
| alphaXiv        | (What is alphaXiv?) |  |
|                 |                     |  |

| Links to Code Toggle<br>CatalyzeX Code Finder for Papers<br>(What is CatalyzeX?)                                                                                                                                                           |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| DagsHub Toggle<br>DagsHub<br>(What is DagsHub?)                                                                                                                                                                                            |
| GotitPub Toggle<br>Gotit.pub<br>(What is GotitPub?)                                                                                                                                                                                        |
| Huggingface Toggle<br>Hugging Face<br>(What is Huggingface?)                                                                                                                                                                               |
| Links to Code Toggle<br>Papers with Code<br>(What is Papers with Code?)                                                                                                                                                                    |
| ScienceCast Toggle<br>ScienceCast<br>(What is ScienceCast?)                                                                                                                                                                                |
| Demos                                                                                                                                                                                                                                      |
| Demos                                                                                                                                                                                                                                      |
| Replicate Toggle<br>Replicate<br>(What is Replicate?)<br>Spaces Toggle<br>Hugging Face Spaces<br>(What is Spaces?)<br>Spaces Toggle<br>TXYZ.AI<br>(What is TXYZ.AI?)<br>Related Papers                                                     |
| Recommenders and Search Tools                                                                                                                                                                                                              |
| Link to Influence Flower<br>Influence Flower<br>(What are Influence Flowers?)<br>Core recommender toggle<br>CORE Recommender<br>(What is CORE?)<br>IArxiv recommender toggle<br>IArxiv Recommender<br>(What is IArxiv?)<br>About arXivLabs |
|                                                                                                                                                                                                                                            |

## **arXivLabs: experimental projects with community collaborators**

arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.

Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.

Have an idea for a project that will add value for arXiv's community? **[Learn](https://info.arxiv.org/labs/index.html) [more about arXivLabs](https://info.arxiv.org/labs/index.html)**.

![](_page_6_Picture_0.jpeg)

[Which authors of this paper are endorsers?](file:///auth/show-endorsers/1503.01116) | [Disable MathJax](javascript:setMathjaxCookie()) [\(What is](https://info.arxiv.org/help/mathjax.html) [MathJax?\)](https://info.arxiv.org/help/mathjax.html)

[About](https://info.arxiv.org/about)

![](_page_7_Picture_1.jpeg)

[Contact](https://info.arxiv.org/help/contact.html)

![](_page_8_Picture_0.jpeg)

[Subscribe](https://info.arxiv.org/help/subscribe)

[Copyright](https://info.arxiv.org/help/license/index.html)

[Privacy Policy](https://info.arxiv.org/help/policies/privacy_policy.html)

[Web Accessibility Assistance](https://info.arxiv.org/help/web_accessibility.html)

#### [arXiv Operational Status](https://status.arxiv.org)

![](_page_10_Picture_0.jpeg)

![](_page_11_Picture_1.jpeg)

[email](https://subscribe.sorryapp.com/24846f03/email/new) or

![](_page_12_Picture_0.jpeg)

[slack](https://subscribe.sorryapp.com/24846f03/slack/new)