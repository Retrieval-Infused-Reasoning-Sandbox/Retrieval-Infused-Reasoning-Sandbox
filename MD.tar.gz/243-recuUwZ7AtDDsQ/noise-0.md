#### [Skip to main content](#page-1-0) [Cornell University](https://www.cornell.edu/)

We gratefully acknowledge support from the Simons Foundation, [member](https://info.arxiv.org/about/ourmembers.html) [institutions](https://info.arxiv.org/about/ourmembers.html), and all contributors. [Donate](https://info.arxiv.org/about/donate.html) > [astro-ph](file:///list/astro-ph/recent) > arXiv:1202.3665 [arxiv logo](file:///)

#### [Help](https://info.arxiv.org/help) | [Advanced Search](https://arxiv.org/search/advanced)

![](_page_0_Picture_3.jpeg)

#### [arXiv logo](https://arxiv.org/)

[Cornell University Logo](https://www.cornell.edu/)

![](_page_0_Picture_6.jpeg)

| header |    |  |
|--------|----|--|
| all    |    |  |
|        | GO |  |

![](_page_1_Picture_0.jpeg)

## **quick links**

- [Login](https://arxiv.org/login) •
- [Help Pages](https://info.arxiv.org/help) •
- [About](https://info.arxiv.org/about) •

# <span id="page-1-0"></span>**Astrophysics > Instrumentation and Methods for Astrophysics**

**arXiv:1202.3665** (astro-ph) [Submitted on 16 Feb 2012 ([v1\)](https://arxiv.org/abs/1202.3665v1), last revised 25 Nov 2013 (this version, v4)]

## **Title:emcee: The MCMC Hammer**

Authors:[Daniel Foreman-Mackey](https://arxiv.org/search/astro-ph?searchtype=author&query=Foreman-Mackey,+D), [David W. Hogg,](https://arxiv.org/search/astro-ph?searchtype=author&query=Hogg,+D+W) [Dustin Lang](https://arxiv.org/search/astro-ph?searchtype=author&query=Lang,+D), [Jonathan](https://arxiv.org/search/astro-ph?searchtype=author&query=Goodman,+J) [Goodman](https://arxiv.org/search/astro-ph?searchtype=author&query=Goodman,+J) [View PDF](file:///pdf/1202.3665)

Abstract:We introduce a stable, well tested Python implementation of the affine-invariant ensemble sampler for Markov chain Monte Carlo (MCMC) proposed by Goodman & Weare (2010). The code is open source and has already been used in several published projects in the astrophysics literature. The algorithm behind emcee has several advantages over traditional MCMC sampling methods and it has excellent performance as measured by the autocorrelation time (or function calls per independent sample). One major advantage of the algorithm is that it requires handtuning of only 1 or 2 parameters compared to \$\sim N^2\$ for a traditional algorithm in an N-dimensional parameter space. In this document, we describe the algorithm and the details of our

implementation and API. Exploiting the parallelism of the ensemble method, emcee permits any user to take advantage of multiple CPU cores without extra effort. The code is available online at [this http](http://dan.iel.fm/emcee) [URL](http://dan.iel.fm/emcee) under the MIT License.

Comments: Code re-licensed under MIT

Instrumentation and Methods for Astrophysics (astro-ph.IM);

Subjects: Computational Physics (physics.comp-ph); Computation

(stat.CO)

Cite as: [arXiv:1202.3665](https://arxiv.org/abs/1202.3665) [astro-ph.IM]

(or [arXiv:1202.3665v4](https://arxiv.org/abs/1202.3665v4) [astro-ph.IM] for this version)

<https://doi.org/10.48550/arXiv.1202.3665>

Focus to learn more

arXiv-issued DOI via DataCite <https://doi.org/10.1086/670067>

Related DOI:

Focus to learn more

DOI(s) linking to related resources

## **Submission history**

From: Daniel Foreman-Mackey [[view email](file:///show-email/65ee6cfe/1202.3665)]

**[\[v1\]](file:///abs/1202.3665v1)** Thu, 16 Feb 2012 20:41:19 UTC (17 KB)

**[\[v2\]](file:///abs/1202.3665v2)** Sat, 18 Feb 2012 03:52:41 UTC (18 KB)

**[\[v3\]](file:///abs/1202.3665v3)** Wed, 30 Jan 2013 15:48:37 UTC (15 KB)

**[v4]** Mon, 25 Nov 2013 15:56:48 UTC (15 KB)

Full-text links:

## **Access Paper:**

- [View PDF](file:///pdf/1202.3665) •
- [TeX Source](file:///src/1202.3665) •
- [Other Formats](file:///format/1202.3665) •

#### [view license](http://arxiv.org/licenses/nonexclusive-distrib/1.0/)

Current browse context:

astro-ph.IM

[< prev](file:///prevnext?id=1202.3665&function=prev&context=astro-ph.IM) | [next >](file:///prevnext?id=1202.3665&function=next&context=astro-ph.IM)

[new](file:///list/astro-ph.IM/new) | [recent](file:///list/astro-ph.IM/recent) | [2012-02](file:///list/astro-ph.IM/2012-02)

Change to browse by:

[astro-ph](file:///abs/1202.3665?context=astro-ph)

[physics](file:///abs/1202.3665?context=physics)

[physics.comp-ph](file:///abs/1202.3665?context=physics.comp-ph)

[stat](file:///abs/1202.3665?context=stat)

[stat.CO](file:///abs/1202.3665?context=stat.CO)

### **References & Citations**

- [NASA ADS](https://ui.adsabs.harvard.edu/abs/arXiv:1202.3665) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?arxiv_id=1202.3665) •
- [Semantic Scholar](https://api.semanticscholar.org/arXiv:1202.3665) •

### **[5 blog links](file:///tb/1202.3665)**

([what is this?\)](https://info.arxiv.org/help/trackback.html) export BibTeX citation

#### **Bookmark**

[BibSonomy logo](http://www.bibsonomy.org/BibtexHandler?requTask=upload&url=https://arxiv.org/abs/1202.3665&description=emcee:%20The%20MCMC%20Hammer) [Reddit logo](https://reddit.com/submit?url=https://arxiv.org/abs/1202.3665&title=emcee:%20The%20MCMC%20Hammer)

Bibliographic Tools

## **Bibliographic and Citation Tools**

| Bibliographic Explorer Toggle                        |
|------------------------------------------------------|
| Bibliographic Explorer<br>(What is the Explorer?)    |
| Connected Papers Toggle                              |
| Connected Papers<br>(What is Connected Papers?)      |
|                                                      |
| Litmaps Toggle                                       |
| Litmaps<br>(What is Litmaps?)                        |
| scite.ai Toggle                                      |
| scite Smart Citations<br>(What are Smart Citations?) |
|                                                      |
|                                                      |

Code, Data, Media

# **Code, Data and Media Associated with this Article**

| alphaXiv Toggle                                          |
|----------------------------------------------------------|
| alphaXiv<br>(What is alphaXiv?)                          |
| Links to Code Toggle                                     |
| CatalyzeX Code Finder for Papers<br>(What is CatalyzeX?) |
| DagsHub Toggle                                           |
| DagsHub<br>(What is DagsHub?)                            |

| GotitPub Toggle<br>Gotit.pub<br>(What is GotitPub?)                     |
|-------------------------------------------------------------------------|
|                                                                         |
| Huggingface Toggle<br>Hugging Face<br>(What is Huggingface?)            |
|                                                                         |
| Links to Code Toggle<br>Papers with Code<br>(What is Papers with Code?) |
| ScienceCast Toggle                                                      |
| ScienceCast<br>(What is ScienceCast?)                                   |
| Demos                                                                   |
|                                                                         |
| Demos                                                                   |
|                                                                         |
| Replicate Toggle                                                        |
| Replicate<br>(What is Replicate?)                                       |
| Spaces Toggle                                                           |
| Hugging Face Spaces<br>(What is Spaces?)                                |
| Spaces Toggle                                                           |
| TXYZ.AI<br>(What is TXYZ.AI?)                                           |
| Related Papers                                                          |
|                                                                         |
| Recommenders and Search Tools                                           |
|                                                                         |
| Link to Influence Flower                                                |
| Influence Flower<br>(What are Influence Flowers?)                       |
| Core recommender toggle                                                 |
| CORE Recommender<br>(What is CORE?)                                     |
| IArxiv recommender toggle                                               |
| IArxiv Recommender<br>(What is IArxiv?)                                 |
| About arXivLabs                                                         |
|                                                                         |
|                                                                         |

# **arXivLabs: experimental projects with community collaborators**

arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.

Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.

Have an idea for a project that will add value for arXiv's community? **[Learn](https://info.arxiv.org/labs/index.html) [more about arXivLabs](https://info.arxiv.org/labs/index.html)**.

![](_page_5_Picture_2.jpeg)

[Which authors of this paper are endorsers?](file:///auth/show-endorsers/1202.3665) | [Disable MathJax](javascript:setMathjaxCookie()) [\(What is](https://info.arxiv.org/help/mathjax.html) [MathJax?\)](https://info.arxiv.org/help/mathjax.html)

[About](https://info.arxiv.org/about)

[Help](https://info.arxiv.org/help)

![](_page_6_Picture_3.jpeg)

[Contact](https://info.arxiv.org/help/contact.html)

![](_page_7_Picture_0.jpeg)

[Subscribe](https://info.arxiv.org/help/subscribe)

[Copyright](https://info.arxiv.org/help/license/index.html)

[Privacy Policy](https://info.arxiv.org/help/policies/privacy_policy.html)

[Web Accessibility Assistance](https://info.arxiv.org/help/web_accessibility.html)

#### [arXiv Operational Status](https://status.arxiv.org)

![](_page_9_Picture_0.jpeg)

![](_page_10_Picture_1.jpeg)

[email](https://subscribe.sorryapp.com/24846f03/email/new) or

![](_page_11_Picture_0.jpeg)

[slack](https://subscribe.sorryapp.com/24846f03/slack/new)