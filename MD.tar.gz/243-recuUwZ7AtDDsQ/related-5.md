### Now on home page

• [ads icon](file:///)

# **[ads](file:///)**

[Enable full ADS](file:///core/never/abs/2020MNRAS.497.1590H/abstract) •

## **view**

[Abstract](file:///abs/2020MNRAS.497.1590H/abstract)  [Citations \(59\)](file:///abs/2020MNRAS.497.1590H/citations) [References \(95\)](file:///abs/2020MNRAS.497.1590H/references) [Co-Reads](file:///abs/2020MNRAS.497.1590H/coreads)  [Similar Papers](file:///abs/2020MNRAS.497.1590H/similar)  Volume Content Graphics [Metrics](file:///abs/2020MNRAS.497.1590H/metrics)  [Export Citation](file:///abs/2020MNRAS.497.1590H/exportcitation) 

# **ADS**

# **Generalized emergent dark energy: observational Hubble data constraints and stability analysis**

- [Hernández-Almada, A.](file:///search/?q=author%3A%22Hern%C3%A1ndez-Almada%2C+A.%22) •
- ; [Leon, Genly](file:///search/?q=author%3A%22Leon%2C+Genly%22) •
- ; [Magaña, Juan](file:///search/?q=author%3A%22Maga%C3%B1a%2C+Juan%22) ; •
- [García-Aspeitia, Miguel A.](file:///search/?q=author%3A%22Garc%C3%ADa-Aspeitia%2C+Miguel+A.%22) ; •
- [Motta, V.](file:///search/?q=author%3A%22Motta%2C+V.%22) •

### **Abstract**

Recently, a phenomenologically emergent dark energy (PEDE) model was presented with a dark energy density evolving as \$\widetilde{\Omega }\_{\rm {DE}}(z) = \Omega \_{\rm {DE,0}}[ 1 - {\rm {tanh}}({\log }\_{10}(1+z))]\$ , i.e. with no degree of freedom. Later on, a generalized model was proposed by adding one degree of freedom to the PEDE model, encoded in the parameter Δ. Motivated by these proposals, we constrain the parameter space ( \$h,\Omega \_m^{(0)}\$ ) and ( \$h,\Omega \_m^{(0)}, \Delta\$ ) for PEDE and generalized emergent dark energy (GEDE), respectively, by

employing the most recent observational (non-)homogeneous and differential age Hubble data. Additionally, we reconstruct the deceleration and jerk parameters and estimate yield values at z = 0 of \$q\_0 = -0.784^{+0.028} \_{-0.027}\$ and \$j\_0 = 1.241^{+0.164}\_{-0.149}\$ for PEDE and \$q\_0 = -0.730^{+0.059}\_{-0.067}\$ and \$j\_0 = 1.293^{+0.194}\_{-0.187}\$ for GEDE using the homogeneous sample. We report values on the decelerationacceleration transition redshift with those reported in the literature within 2σ CL. Furthermore, we perform a stability analysis of the PEDE and GEDE models to study the global evolution of the Universe around their critical points. Although the PEDE and GEDE dynamics are similar to the standard model, our stability analysis indicates that in both models there is an accelerated phase at early epochs of the Universe evolution.

```
Publication:
    Monthly Notices of the Royal Astronomical Society
Pub Date:
    September 2020
DOI:
    10.1093/mnras/staa2052
    10.48550/arXiv.2002.12881
arXiv:
    arXiv:2002.12881
Bibcode:
    2020MNRAS.497.1590H 
Keywords:
         cosmological parameters;
         dark energy;
         cosmology: observations;
         cosmology: theory;
         Astrophysics - Cosmology and Nongalactic Astrophysics;
         General Relativity and Quantum Cosmology
E-Print:
    Accepted for publication in MNRAS 
 full text sources
 OUP 
 |
 Preprint
 |
© The SAO Astrophysics Data System 
adshelp[at]cfa.harvard.edu 
        • 
        • 
        • 
        • 
        • 
        •
```

The ADS is operated by the Smithsonian Astrophysical Observatory under

NASA Cooperative Agreement 80NSSC21M0056

[Smithsonian logo](http://www.si.edu)

### [Harvard Center for Astrophysics logo](https://www.cfa.harvard.edu/) [NASA logo](http://www.nasa.gov)

\*The material contained in this document is based upon work supported by a National Aeronautics and Space Administration (NASA) grant or cooperative agreement. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author and do not necessarily reflect the views of NASA. Resources

- [About ADS](file:///about/)  •
- [ADS Help](file://ui.adsabs.harvard.edu/help/) •
- [What's New](file://ui.adsabs.harvard.edu/help/whats_new/) •
- [Careers@ADS](file:///about/careers/)  •
- [Web Accessibility Policy](file://ui.adsabs.harvard.edu/help/accessibility/) •

### Social

- [@adsabs](file://twitter.com/adsabs)  •
- [ADS Blog](file://ui.adsabs.harvard.edu/blog/)  •

### Project

- [Switch to full ADS](file:///core/never) •
- [Is ADS down? \(or is it just me...\)](https://adsisdownorjustme.herokuapp.com/) •
- [Smithsonian Institution](http://www.si.edu) •
- [Smithsonian Privacy Notice](http://www.si.edu/Privacy) •
- [Smithsonian Terms of Use](http://www.si.edu/Termsofuse) •
- [Smithsonian Astrophysical Observatory](http://www.cfa.harvard.edu/sao) •
- [NASA](http://www.nasa.gov) •

![](_page_2_Picture_18.jpeg)