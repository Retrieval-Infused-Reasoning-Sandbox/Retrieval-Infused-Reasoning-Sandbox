#### [Skip to main content](#page-1-0) [Cornell University](https://www.cornell.edu/)

We gratefully acknowledge support from the Simons Foundation, [member](https://info.arxiv.org/about/ourmembers.html) [institutions](https://info.arxiv.org/about/ourmembers.html), and all contributors. [Donate](https://info.arxiv.org/about/donate.html)

> [astro-ph](file:///list/astro-ph/recent) > arXiv:1601.01701 [arxiv logo](file:///)

#### [Help](https://info.arxiv.org/help) | [Advanced Search](https://arxiv.org/search/advanced)

![](_page_0_Picture_4.jpeg)

#### [arXiv logo](https://arxiv.org/)

[Cornell University Logo](https://www.cornell.edu/)

![](_page_0_Picture_7.jpeg)

| header |    |  |
|--------|----|--|
| all    |    |  |
|        | GO |  |

![](_page_1_Picture_0.jpeg)

## **quick links**

- [Login](https://arxiv.org/login) •
- [Help Pages](https://info.arxiv.org/help) •
- [About](https://info.arxiv.org/about) •

# <span id="page-1-0"></span>**Astrophysics > Cosmology and Nongalactic Astrophysics**

**arXiv:1601.01701** (astro-ph) [Submitted on 7 Jan 2016 ([v1](https://arxiv.org/abs/1601.01701v1)), last revised 2 May 2016 (this version, v2)]

# **Title:A 6% measurement of the Hubble parameter at \$z\sim0.45\$: direct evidence of the epoch of cosmic re-acceleration**

Authors:[Michele Moresco,](https://arxiv.org/search/astro-ph?searchtype=author&query=Moresco,+M) [Lucia Pozzetti](https://arxiv.org/search/astro-ph?searchtype=author&query=Pozzetti,+L), [Andrea Cimatti](https://arxiv.org/search/astro-ph?searchtype=author&query=Cimatti,+A), [Raul Jimenez](https://arxiv.org/search/astro-ph?searchtype=author&query=Jimenez,+R), [Claudia Maraston,](https://arxiv.org/search/astro-ph?searchtype=author&query=Maraston,+C) [Licia Verde](https://arxiv.org/search/astro-ph?searchtype=author&query=Verde,+L), [Daniel Thomas](https://arxiv.org/search/astro-ph?searchtype=author&query=Thomas,+D), [Annalisa Citro](https://arxiv.org/search/astro-ph?searchtype=author&query=Citro,+A), [Rita Tojeiro](https://arxiv.org/search/astro-ph?searchtype=author&query=Tojeiro,+R), [David Wilkinson](https://arxiv.org/search/astro-ph?searchtype=author&query=Wilkinson,+D) [View PDF](file:///pdf/1601.01701)

Abstract:Deriving the expansion history of the Universe is a major goal of modern cosmology. To date, the most accurate measurements have been obtained with Type Ia Supernovae and Baryon Acoustic Oscillations, providing evidence for the existence of a transition epoch at which the expansion rate changes from

decelerated to accelerated. However, these results have been obtained within the framework of specific cosmological models that must be implicitly or explicitly assumed in the measurement. It is therefore crucial to obtain measurements of the accelerated expansion of the Universe independently of assumptions on cosmological models. Here we exploit the unprecedented statistics provided by the Baryon Oscillation Spectroscopic Survey (BOSS) Data Release 9 to provide new constraints on the Hubble parameter \$H(z)\$ using the em cosmic chronometers approach. We extract a sample of more than 130000 of the most massive and passively evolving galaxies, obtaining five new cosmology-independent \$H(z) \$ measurements in the redshift range \$0.3<z<0.5\$, with an accuracy of \$\sim\$11-16\% incorporating both statistical and systematic errors. Once combined, these measurements yield a 6\ % accuracy constraint of \$H(z=0.4293)=91.8\pm5.3\$ km/s/Mpc. The new data are crucial to provide the first cosmologyindependent determination of the transition redshift at high statistical significance, measuring \$z\_{t}=0.4\pm0.1\$, and to significantly disfavor the null hypothesis of no transition between decelerated and accelerated expansion at 99.9\% confidence level. This analysis highlights the wide potential of the cosmic chronometers approach: it permits to derive constraints on the expansion history of the Universe with results competitive with standard probes, and most importantly, being the estimates independent of the cosmological model, it can constrain cosmologies beyond -and including- the \$\Lambda\$CDM model.

Comments: 31 pages, 10 figures, 5 tables, accepted for publication inJCAP. The H(z) data can be downloaded at [this http URL](http://www.physics-astronomy.unibo.it/en/research/areas/astrophysics/cosmology-with-cosmic-chronometers)

Subjects: Cosmology and Nongalactic Astrophysics (astro-ph.CO)

Cite as: [arXiv:1601.01701](https://arxiv.org/abs/1601.01701) [astro-ph.CO]

(or [arXiv:1601.01701v2](https://arxiv.org/abs/1601.01701v2) [astro-ph.CO] for this version)

<https://doi.org/10.48550/arXiv.1601.01701>

Focus to learn more

arXiv-issued DOI via DataCite

Journal reference: Journal of Cosmology and Astroparticle Physics, Issue 05, article id. 014 (2016)

<https://doi.org/10.1088/1475-7516/2016/05/014>

Related DOI:

Focus to learn more

DOI(s) linking to related resources

## **Submission history**

From: Michele Moresco [\[view email\]](file:///show-email/4e7e2a6f/1601.01701)

**[\[v1\]](file:///abs/1601.01701v1)** Thu, 7 Jan 2016 21:10:24 UTC (1,669 KB) **[v2]** Mon, 2 May 2016 10:21:27 UTC (1,702 KB)

Full-text links:

### **Access Paper:**

- [View PDF](file:///pdf/1601.01701) •
- [TeX Source](file:///src/1601.01701) •

#### [view license](http://arxiv.org/licenses/nonexclusive-distrib/1.0/)

[astro-ph](file:///abs/1601.01701?context=astro-ph)

Current browse context: astro-ph.CO [< prev](file:///prevnext?id=1601.01701&function=prev&context=astro-ph.CO) | [next >](file:///prevnext?id=1601.01701&function=next&context=astro-ph.CO) [new](file:///list/astro-ph.CO/new) | [recent](file:///list/astro-ph.CO/recent) | [2016-01](file:///list/astro-ph.CO/2016-01) Change to browse by:

### **References & Citations**

- [INSPIRE HEP](https://inspirehep.net/arxiv/1601.01701) •
- [NASA ADS](https://ui.adsabs.harvard.edu/abs/arXiv:1601.01701) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?arxiv_id=1601.01701) •
- [Semantic Scholar](https://api.semanticscholar.org/arXiv:1601.01701) •

export BibTeX citation

#### **Bookmark**

[BibSonomy logo](http://www.bibsonomy.org/BibtexHandler?requTask=upload&url=https://arxiv.org/abs/1601.01701&description=A%206%%20measurement%20of%20the%20Hubble%20parameter%20at%20$z%5Csim0.45$:%20direct%20evidence%20of%20the%20epoch%20of%20cosmic%20re-acceleration) [Reddit logo](https://reddit.com/submit?url=https://arxiv.org/abs/1601.01701&title=A%206%%20measurement%20of%20the%20Hubble%20parameter%20at%20$z%5Csim0.45$:%20direct%20evidence%20of%20the%20epoch%20of%20cosmic%20re-acceleration)

![](_page_3_Picture_17.jpeg)

Bibliographic Tools

## **Bibliographic and Citation Tools**

| Bibliographic Explorer Toggle<br>Bibliographic Explorer<br>(What is the Explorer?) |
|------------------------------------------------------------------------------------|
| Connected Papers Toggle<br>Connected Papers<br>(What is Connected Papers?)         |
| Litmaps Toggle<br>Litmaps<br>(What is Litmaps?)                                    |
| scite.ai Toggle<br>scite Smart Citations<br>(What are Smart Citations?)            |

Code, Data, Media

# **Code, Data and Media Associated with this Article**

| alphaXiv Toggle<br>alphaXiv<br>(What is alphaXiv?)                               |
|----------------------------------------------------------------------------------|
| Links to Code Toggle<br>CatalyzeX Code Finder for Papers<br>(What is CatalyzeX?) |
| DagsHub Toggle<br>DagsHub<br>(What is DagsHub?)                                  |
| GotitPub Toggle<br>Gotit.pub<br>(What is GotitPub?)                              |
| Huggingface Toggle<br>Hugging Face<br>(What is Huggingface?)                     |
| Links to Code Toggle<br>Papers with Code<br>(What is Papers with Code?)          |
| ScienceCast Toggle<br>ScienceCast<br>(What is ScienceCast?)                      |
| Demos                                                                            |
| Demos                                                                            |
| Replicate Toggle<br>Replicate<br>(What is Replicate?)                            |

Spaces Toggle Hugging Face Spaces ([What is Spaces?\)](https://huggingface.co/docs/hub/spaces) Spaces Toggle TXYZ.AI [\(What is TXYZ.AI?](https://txyz.ai)) Related Papers

## **Recommenders and Search Tools**

| Link to Influence Flower                          |
|---------------------------------------------------|
| Influence Flower<br>(What are Influence Flowers?) |
|                                                   |
| Core recommender toggle                           |
| CORE Recommender<br>(What is CORE?)               |
|                                                   |
| IArxiv recommender toggle                         |
| IArxiv Recommender<br>(What is IArxiv?)           |
|                                                   |
| About arXivLabs                                   |

# **arXivLabs: experimental projects with community collaborators**

arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.

Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.

Have an idea for a project that will add value for arXiv's community? **[Learn](https://info.arxiv.org/labs/index.html) [more about arXivLabs](https://info.arxiv.org/labs/index.html)**.

![](_page_6_Picture_0.jpeg)

[Which authors of this paper are endorsers?](file:///auth/show-endorsers/1601.01701) | [Disable MathJax](javascript:setMathjaxCookie()) [\(What is](https://info.arxiv.org/help/mathjax.html) [MathJax?\)](https://info.arxiv.org/help/mathjax.html)

[About](https://info.arxiv.org/about)

![](_page_7_Picture_1.jpeg)

[Contact](https://info.arxiv.org/help/contact.html)

![](_page_8_Picture_0.jpeg)

[Subscribe](https://info.arxiv.org/help/subscribe)

[Copyright](https://info.arxiv.org/help/license/index.html)

[Privacy Policy](https://info.arxiv.org/help/policies/privacy_policy.html)

[Web Accessibility Assistance](https://info.arxiv.org/help/web_accessibility.html)

#### [arXiv Operational Status](https://status.arxiv.org)

![](_page_10_Picture_0.jpeg)

![](_page_11_Picture_1.jpeg)

[email](https://subscribe.sorryapp.com/24846f03/email/new) or

![](_page_12_Picture_0.jpeg)

[slack](https://subscribe.sorryapp.com/24846f03/slack/new)