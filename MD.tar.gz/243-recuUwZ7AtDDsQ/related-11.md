A Simple Phenomenological Emergent Dark Energy Model can Resolve the Hubble Tension

XIAOLEI LI<sup>1, 2</sup> AND ARMAN SHAFIELOO<sup>1, 3</sup>

<sup>1</sup>Korea Astronomy and Space Science Institute, Daejeon 34055, Korea

<sup>2</sup> Quantum Universe Center, Korean Institute of Advanced Studies, Hoegiro 87, Dongdaemun-gu, Seoul 130-722, Korea
<sup>3</sup> University of Science and Technology, Yuseong-gu 217 Gajeong-ro, Daejeon 34113, Korea

(Dated: January 14, 2020)

#### ABSTRACT

Motivated by the current status of the cosmological observations and significant tensions in the estimated values of some key parameters assuming the standard  $\Lambda$ CDM model, we propose a simple but radical phenomenological emergent dark energy model where dark energy has no effective presence in the past and emerges at the later times. Theoretically, in this phenomenological dark energy model with zero degree of freedom (similar to a ΛCDM model), one can derive that the equation of state of dark energy increases from  $-\frac{2}{3\ln 10}-1$  in the past to -1 in the future. We show that by setting a hard-cut  $2\sigma$  lower bound prior for the  $H_0$  that associates with 97.72% probability from the recent local observations (Riess et al. 2019), this model can satisfy different combinations of cosmological observations at low and high redshifts (SNe Ia, BAO, Ly $\alpha$  BAO and CMB) substantially better than the concordance  $\Lambda \text{CDM}$  model with  $\Delta \chi_{bf}^2 \sim -41.08$  and  $\Delta \text{DIC} \sim -35.38$ . If there are no substantial systematics in SN Ia, BAO or Planck CMB data and assuming reliability of the current local  $H_0$ measurements, there is a very high probability that with slightly more precise measurement of the Hubble constant our proposed phenomenological model rules out the cosmological constant with decisive statistical significance and is a strong alternative to explain combination of different cosmological observations. This simple phenomenologically emergent dark energy model can guide theoretically motivated dark energy model building activities.

Keywords: Cosmology: observational - Dark Energy - Methods: statistical

#### 1. INTRODUCTION

While current cosmological observations have been in great agreement with the standard  $\Lambda$ CDM model, there is significant tensions of some key cosmological parameters derived by assuming this model. One of the major issues is the inconsistency between the local measurement of the Hubble constant by the Supernova H0 for the Equation of State(SH0ES) collaboration (Riess et al. 2016, 2018, 2019) and the estimation of this parameter using *Planck* cosmic microwave background (CMB) and other cosmological observations assuming  $\Lambda$ CDM model (Ade et al. 2016; Aghanim et al. 2018). Another issue is the estimation of the  $\Omega_m h_0^2$  from the baryon acoustic oscillation (BAO) measurement at z = 2.34 from BOSS and eBOSS surveys using Ly $\alpha$  forest and the estimated values from Planck CMB observations assuming  $\Lambda$ CDM model (Sahni et al. 2014; Ding et al. 2015; Zheng et al. 2016; Solà et al. 2017; Alam et al. 2017b; Shanks et al. 2018).

A possible solution to this issue may be a carefully constructed yet simple alternative model of dark energy that can satisfy all of the observations, or an unconventional model of the early Universe (Hazra et al. 2019).

In this letter we propose a simple (zero degree of freedom) but radical phenomenological model of dark energy with symmetrical behavior around the current time where dark energy and matter densities are comparable. In this model dark energy has no effective presence in the past and emerges at later times. Setting hard-cut priors from local measurements of the Hubble constant , we confront this model with combination of low and high redshift cosmological observations, namely SNe Ia data, BAO data (including BAO Ly $\alpha$  measurement) and CMB measurement and show that significantly it can outperform statistically the standard  $\Lambda$ CDM model as well as the  $w_0$ - $w_a$  parameterization.

This letter is organised as follows: in section 2 we briefly introduce the Friedmann equations for our model. The observational data to be used, including SNe Ia,

BAO and distance prior from CMB, are presented in section 3. Section 4 contains our main results and some discussion. We conclude in section 5.

# <span id="page-1-0"></span>2. PHENOMENOLOGICALLY EMERGENT DARK ENERGY MODEL (PEDE)

The Hubble parameter within the Friedmann-Lemaître-Robertson-Walker (FLRW) metric, assuming a flat universe, could be described as:

$$H^{2}(z) = H_{0}^{2} \left[ \Omega_{m} (1+z)^{3} + \widetilde{\Omega}_{DE}(z) \right]$$
 (1)

where  $\Omega_m$  is the matter density at present time and  $\widetilde{\Omega}_{DE}(z)$  can be expressed as:

$$\widetilde{\Omega}_{\rm DE}(z) = \Omega_{\rm DE,0} \times \exp\left[3\int_0^z \frac{1 + w(z')}{1 + z'} dz'\right]$$
 (2)

where  $w(z) = p_{\rm DE}/\rho_{\rm DE}$  is the equation of state of Dark Energy.

In  $\Lambda$ CDM model, w(z) = -1 and  $\widetilde{\Omega}_{\mathrm{DE}}(z) = (1 - \Omega_m) = \mathrm{constant}$ . For the widely used CPL parameterization model ( $w_0$ - $w_a$  model) (Chevallier & Polarski 2001; Linder 2003), the equation of state of dark energy is given by  $w(z) = w_0 + \frac{w_a z}{1+z}$  so one can derive  $\widetilde{\Omega}_{\mathrm{DE}}(z) = \Omega_{\mathrm{DE},0}(1+z)^{3(1+w_0+w_a)} \exp(\frac{-3w_a z}{1+z})$ .

In this letter, we introduce the PEDE model in which the dark energy density has the following form:

$$\widetilde{\Omega}_{DE}(z) = \Omega_{DE,0} \times [1 - \tanh(\log_{10}(1+z))] \quad (3)$$

where  $\Omega_{\text{DE},0} = 1 - \Omega_{0m}$  and 1 + z = 1/a where a is the scale factor. This dark energy model has no degree of freedom (similar to the case of  $\Lambda$ CDM model) and we can derive its equation of state following:

$$w(z) = \frac{1}{3} \frac{d \ln \widetilde{\Omega}_{DE}}{dz} (1+z) - 1 \tag{4}$$

where we get,

$$w(z) = -\frac{1}{3\ln 10} \times \frac{1 - \tanh^2 \left[\log_{10}(1+z)\right]}{1 - \tanh \left[\log_{10}(1+z)\right]} - 1$$
 (5)

$$= -\frac{1}{3\ln 10} \times (1 + \tanh \left[\log_{10} (1+z)\right]) - 1. \quad (6)$$

Note that in this model, the equation of state of dark energy at the early times would be  $w(z) = -\frac{2}{3\ln 10} - 1$  and it will evolve asymptotically to w(z) = -1 in the far future. In this model we have  $w(z=0) = -\frac{1}{3\ln 10} - 1$  at the present for the dark energy. In Fig. 1, we can see the behavior of this dark energy model in comparison to  $\Lambda$ . We should note that we can consider a more generalized form of this emergent dark energy

![](_page_1_Figure_17.jpeg)

![](_page_1_Figure_18.jpeg)

<span id="page-1-1"></span>Figure 1. The upper plot shows the evolution of dark energy density  $\Omega_{\rm DE}(z)$  from early times to the far future and the bottom plot presents the evolution of Equation of State of Dark Energy w(z) for  $\Lambda {\rm CDM}$  and PEDE models. This figure is only for demonstrating the behavior of this model in comparison with cosmological constant and flatness and  $\Omega_m=0.3$  is assumed for both  $\Lambda {\rm CDM}$  and PEDE models.

model introducing one or more degrees of freedom such as having  $\widetilde{\Omega}_{\mathrm{DE}}(z) = \Omega_{\mathrm{DE},0} \times \frac{F(z)}{F(z=0)}$  with  $F(z) = 1 - \tanh\left(\left[\log_{10}(1+z) - \log_{10}(1+z_t)\right]\right)$  where  $z_t$  is the transition redshift (similar models have been discussed in Bassett et al. (2002); Shafieloo et al. (2009)), but our results show that there is no statistical need to introduce an additional degree of freedom for this model. We can also use this generalized form and set  $z_t$  to be the redshift of dark energy-matter density equality where in this case there will not be any additional degree of

freedom. The behavior or this generalized form with its self-tuning characteristics will be discussed in future works.

## 3. ANALYSIS

<span id="page-2-0"></span>In order to place constraints on the Dark Energy models we described above, we consider different observations in our work, including:

- (i) SNe Ia: we use the new "Pantheon" sample [\(Scol](#page-6-15)[nic et al.](#page-6-15) [2017\)](#page-6-15), which is the largest combined sample of SN Ia and consists of 1048 data with redshifts in the range 0.01 < z < 2.3. In order to reduce the impact of calibration systematics on cosmology, the Pantheon compilation uses crosscalibration of the photometric systems of all the subsamples used to construct the final sample.
- (ii) BAOs: four lower redshift BAO data sets are used: 6-degree Field Galaxy Survey (6dFGS) [\(Beutler et al.](#page-6-16) [2011\)](#page-6-16), the SDSS Data Release 7 Main Galaxy sample (MGS) [\(Ross et al.](#page-6-17) [2015\)](#page-6-17), the BOSS DR12 galaxies [\(Alam et al.](#page-6-18) [2017a\)](#page-6-18) and the eBOSS DR14 quasars [\(Zhao et al.](#page-7-1) [2018\)](#page-7-1). In addition to these lower BAO measurement, a higher redshift BAO measurement which is derived from the cross-correlation of Lyα absorption and quasars in eBOSS DR14 was also used [\(Blomqvist](#page-6-19) [et al.](#page-6-19) [2019;](#page-6-19) [de Sainte Agathe et al.](#page-6-20) [2019\)](#page-6-20).
- (iii) Cosmic Microwave Background: we include CMB in our analysis by using the CMB distance prior, the acoustic scale l<sup>a</sup> and the shift parameter R together with the baryon density Ωbh 2 . The shift parameter is defined as

$$R \equiv \sqrt{\Omega_m H_0^2} r(z_*)/c \tag{7}$$

and the acoustic scale is

$$l_a \equiv \pi r(z_*)/r_s(z_*) \tag{8}$$

where r(z∗) is the comoving distance to the photon-decoupling epoch z∗. We use the distance priors from the finally release Planck TT, TE, EE +low E data in 2018 [\(Chen et al.](#page-6-21) [2019\)](#page-6-21), which makes the uncertainties 40% smaller than those from Planck TT+low P.

In our analysis, we consider two kinds of data combinations. The first is Lower redshift measurements: the Pantheon supernova compilation in combination with lower redshift BAO measurements from 6dFGS, MGS, BOSS DR12 and eBOSS DR14, hereafter we refer to as Pantheon+BAO. The second includes higher redshift observations from Lyα BAO measurements and CMB data (hereafter referred to as Pantheon+BAO+Lyα+CMB. In addition to the data combinations, 2σ and 1σ hard-cut H<sup>0</sup> priors, based on local measurement from [Riess et al.](#page-6-0) [\(2019\)](#page-6-0) H<sup>0</sup> = 74.03 ± 1.42 is used.

When using SNe Ia and BAO as cosmological probes, we use a conservative prior for Ωbh <sup>2</sup> based on the measurement of D/H by [Cooke et al.](#page-6-22) [\(2018\)](#page-6-22) and standard BBN with modelling uncertainties. The constraint results are obtained with Markov Chain Monte Carlo (MCMC) estimation using CosmoMC [\(Lewis & Bri](#page-6-23)[dle](#page-6-23) [2002\)](#page-6-23). For quantitative comparison between our proposed model, ΛCDM model and CPL parameterization, we employ the deviance information criterion (DIC)[\(Spiegelhalter et al.](#page-6-24) [2002;](#page-6-24) [Liddle](#page-6-25) [2007\)](#page-6-25), defined as

DIC 
$$\equiv D(\bar{\theta}) + 2p_D = \overline{D(\theta)} + p_D,$$
 (9)

where p<sup>D</sup> = D(θ) − D( ¯θ) and D( ¯θ) = −2 lnL + C, here C is a 'standardizing' constant depending only on the data which will vanish from any derived quantity and D is the deviance of the likelihood. If we define an effective χ <sup>2</sup> as usual by χ <sup>2</sup> = −2 lnL, we can write

$$p_D = \overline{\chi^2(\theta)} - \chi^2(\overline{\theta}). \tag{10}$$

We will show that by considering the priors for the Hubble constant, our proposed model can outperform both ΛCDM model and w0-w<sup>a</sup> parameterization by comparing their best fit likelihoods as well as their derived deviance information criterion.

## 4. RESULTS

<span id="page-2-1"></span>We show the results for ΛCDM in Fig. [2,](#page-3-0) in which we present the 2D regions and 1D marginalized distributions with 1σ and 2σ contours from different data combinations. The left panel shows the results with No H<sup>0</sup> prior, and the middle and right panels show the results of setting hard-cut 2σ H<sup>0</sup> prior and 1σ H<sup>0</sup> prior, respectively. Fig. [3](#page-3-1) shows the results for our PEDE model. Comparing Fig. [2](#page-3-0) and Fig. [3,](#page-3-1) we can find that PEDE model pushes the values of both H<sup>0</sup> and Ω<sup>m</sup> toward a higher direction for Pantheon+BAO data sets when No H<sup>0</sup> prior is considered. However adding CMB and high redshift BAO measurements makes the constraints on value of Ω<sup>m</sup> slightly smaller. While the tension in estimated value of the Hubble constant is relieved in PEDE model, some tension in estimated value of the matter density persist (though substantially reduced in comparison with the case of ΛCDM model).

![](_page_3_Figure_1.jpeg)

<span id="page-3-0"></span>Figure 2. 2-D regions and 1-D marginalized distributions with  $1\sigma$  and  $2\sigma$  contours for  $\Lambda$ CDM model from different observations. From left to right, we use No  $H_0$  prior,  $2\sigma$  hard-cut  $H_0$  prior and  $1\sigma$  hard-cut  $H_0$  prior from Riess et al. (2019), respectively. The black curves/contours denote for the constraints from Pantheon+BAO and the blue ones are derived with Pantheon+BAO+Ly $\alpha$ +CMB data combination.

![](_page_3_Figure_3.jpeg)

<span id="page-3-1"></span>Figure 3. 2-D regions and 1-D marginalized distributions with  $1\sigma$  and  $2\sigma$  contours for PEDE model from different observations. From left to right, we use No  $H_0$  prior,  $2\sigma$  hard-cut  $H_0$  prior and  $1\sigma$  hard-cut  $H_0$  prior from Riess et al. (2019), respectively. The black curves/contours denote for the constraints from Pantheon+BAO and the blue ones are derived with Pantheon+BAO+Ly $\alpha$ +CMB data combination.

The parameter constraints for  $\Lambda$ CDM model,  $w_0$ - $w_a$ parameterization and PEDE model are summarized in Table 1, in which we also show the best fit  $\chi^2$  and DIC values for each model from different data combinations. The  $\chi^2$  distributions for the converged MCMC chains for the  $\Lambda$ CDM model,  $w_0$ - $w_a$  parameterization and PEDE model from lower redshift observations (left) and combined observations (right) are shown in Fig. 4. The upper plots are based on a hard-cut  $2\sigma H_0$  prior and the lower plots are based on a hard-cut  $1\sigma$   $H_0$ prior. From Table 1 and Fig. 4 we can see that, PEDE model provides with substantially better  $\chi_{bf}^2$  with respect to  $\Lambda$ CDM model considering  $2\sigma$   $H_0$  prior, with  $\Delta \chi_{bf}^2 = -4.72$  for lower redshift observations and  $\Delta \chi_{bf}^2 = -41.08$  for the combined observations. When calculating DIC for different models, we find  $\Delta$  DIC = -5.55 and  $\Delta \, \mathrm{DIC} = -35.38$  with respect to  $\Lambda \, \mathrm{CDM}$ model for lower redshifts and combined observations,

respectively. DIC for PEDE model is very much comparable with  $w_0$ - $w_a$  parameterization when setting  $2\sigma$   $H_0$  prior.

As can be seen from Table 1 and lower plots in Fig. 4, with  $1\sigma$  hard-cut  $H_0$  prior, the  $\chi^2_{bf}$  of PEDE model becomes much lower than that of  $\Lambda$ CDM model, with  $\Delta\chi^2_{bf} = -10.21$  for lower redshift observations and  $\Delta\chi^2_{bf} = -88.58$  for combined observations. This is comparable to  $w_0$ - $w_a$  parameterization model, which has 2 more degree of freedom. When calculating DIC values, PEDE model gives best results among the three models we considered, with  $\Delta$  DIC = -94.13 with respect to  $\Lambda$ CDM model and  $\Delta$  DIC = -27.56 with respect to  $w_0$ - $w_a$  parameterization for combined observations. Lower plots in Fig. 4 clearly shows how the proposed PEDE model outperforms  $\Lambda$ CDM model if we set hard-cut  $H_0$  priors and effectively ruling it out with high statistical significance where the tail of  $\chi^2$  distribution

| Table 1. C                                                                 | Constraints on the parameters, $\chi_{bf}^2$ and the DIC for $\Lambda$ CDM model, CPL parameterization and PEDE model are        |  |  |  |  |  |  |
|----------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|
| presented. N                                                               | Note that with hard-cut $H_0$ priors, the PEDE model is clearly outperforming $\Lambda$ CDM model. With $1\sigma$ hard-cut $H_0$ |  |  |  |  |  |  |
| prior, the PEDE model is performing even better than CPL parameterization. |                                                                                                                                  |  |  |  |  |  |  |

<span id="page-4-1"></span>

| Model | Data          | Pantheon+BAO              |                            |                           | Pantheon+BAO+Ly $\alpha$ +CMB |                           |                           |
|-------|---------------|---------------------------|----------------------------|---------------------------|-------------------------------|---------------------------|---------------------------|
|       | Parameters    | No $H_0$ Prior            | $2\sigma H_0$ Prior        | $1\sigma H_0$ Prior       | No $H_0$ Prior                | $2\sigma H_0$ Prior       | $1\sigma H_0$ Prior       |
| ΛCDM  | $\Omega_m$    | $0.299^{+0.047}_{-0.043}$ | $0.335^{+0.040}_{-0.036}$  | $0.347^{+0.041}_{-0.036}$ | $0.311^{+0.016}_{-0.014}$     | $0.271^{+0.002}_{-0.003}$ | $0.256^{+0.002}_{-0.002}$ |
|       | $H_0$         | $66.94^{+3.721}_{-3.256}$ | $71.19^{+1.890}_{0.0}$     | $72.61^{+1.617}_{-0.000}$ | $67.91^{+1.074}_{-1.150}$     | $71.19^{+0.271}_{-0.000}$ | $72.61^{+0.200}_{-0.000}$ |
|       | $\chi^2_{bf}$ | 1046.94                   | 1054.76                    | 1060.25                   | 1056.12                       | 1112.28                   | 1168.98                   |
|       | DIC           | 1051.00                   | 1058.88                    | 1064.27                   | 1062.35                       | 1127.03                   | 1195.07                   |
| CPL   | $\Omega_m$    | $0.285^{+0.113}_{-0.180}$ | $0.332^{+0.071}_{-0.050}$  | $0.350^{+0.050}_{-0.043}$ | $0.307^{+0.026}_{-0.021}$     | $0.286^{+0.007}_{-0.011}$ | $0.274^{+0.006}_{-0.009}$ |
|       | $H_0$         | $64.84^{+14.49}_{-16.12}$ | $71.30^{+5.561}_{-0.117}$  | $72.70^{+2.746}_{-0.091}$ | $68.49^{+2.302}_{-2.680}$     | $71.19^{+1.277}_{-0.002}$ | $72.61^{+0.918}_{-0.004}$ |
|       | $w_0$         | $-0.82^{+0.193}_{-0.541}$ | $-1.08^{+0.422}_{-0.347}$  | $-1.05^{+0.350}_{-0.347}$ | $-0.98^{+0.267}_{-0.218}$     | $-1.07^{+0.259}_{-0.240}$ | $-1.13^{+0.274}_{-0.206}$ |
|       | $w_a$         | $0.675^{+0.547}_{-3.103}$ | $-0.11^{+1.510}_{-3.192}$  | $-0.46^{+1.830}_{-2.686}$ | $-0.16^{+0.816}_{-1.109}$     | $-0.20^{+0.986}_{-1.240}$ | $-0.11^{+0.728}_{-1.321}$ |
|       | $\chi^2_{bf}$ | 1044.98                   | 1048.84                    | 1049.66                   | 1055.52                       | 1066.85                   | 1080.83                   |
|       | DIC           | 1052.59                   | 1054.46                    | 1056.23                   | 1065.48                       | 1085.06                   | 1128.50                   |
| PEDE  | $\Omega_m$    | $0.341^{+0.045}_{-0.041}$ | $0.341^{+0.041}_{-0.037}$  | $0.341^{+0.041}_{-0.030}$ | $0.291^{+0.015}_{-0.016}$     | $0.289^{+0.002}_{-0.014}$ | $0.274^{+0.002}_{-0.006}$ |
|       | $H_0$         | $72.84^{+3.814}_{-3.530}$ | $73.01^{+3.371}_{-1.8231}$ | $72.79^{+2.652}_{-0.186}$ | $71.02^{+1.452}_{-1.368}$     | $71.19^{+1.306}_{-0.001}$ | $72.61^{+0.651}_{-0.000}$ |
|       | $\chi^2_{bf}$ | 1050.04                   | 1050.04                    | 1050.04                   | 1071.12                       | 1071.20                   | 1080.40                   |
|       | DIC           | 1052.01                   | 1053.33                    | 1052.98                   | 1091.15                       | 1091.65                   | 1100.94                   |

for this model has no overlap with the same distribution for the case of  $\Lambda \text{CDM}$  model. We should note that the considered  $2\sigma$  and  $1\sigma$  hard-cut priors for the Hubble constant that effectively affects the assumed models from the lower bound, associate to 97.72% and 84.13% probabilities respectively. In other words there is 97.72% chance that our results for  $2\sigma$   $H_0$  prior holds with future observations (with higher precision) and there is 84.13% chance that our results with  $1\sigma$   $H_0$  prior holds with future high precision observations.

#### 5. CONCLUSION

<span id="page-4-0"></span>We propose a simple phenomenologically emergent model of dark energy that has zero degrees of freedom, which is similar to the case of cosmological constant. The proposed functional form based on a hyperbolic tangent function has a symmetrical behavior in dark energy density as a function of the scale factor in logarithmic scales. The argument behind having the pivot of symmetry at current time can be associated with the fact that dark energy and matter densities are comparable at the current time. This model can be trivially modified to set the pivot of symmetry at the scale of dark energy-dark matter density equality which would be at  $z \approx 0.3$ . In our proposed PEDE model, dark energy has no effective presence in the past and its density increases to double of its current value in the far future. Theoretically this will be associated with a dark energy component with  $w = -\frac{2}{3 \ln 10} - 1$  in the past that will evolve to w = -1 in the far future.

Setting hard-cut  $2\sigma$  and  $1\sigma$  priors on Hubble constant from local measurements, associated with 97.72% and 84.13% probabilities respectively, and using most recent cosmological observations from low and high redshift universe, our proposed model surpasses cosmological constant with large margins. Assuming reliability of the Hubble constant measurement and no substantial systematic in any of the data we used, with  $2\sigma$  and  $1\sigma$ hard-cut priors of  $H_0$  our proposed PEDE model rules out cosmological constant with large statistical significance with  $\Delta DIC = -35.38$  and  $\Delta DIC = -94.13$  respectively. It is indeed interesting that with  $1\sigma$  hard-cut prior on  $H_0$ , this model can even outperform the widely used  $w_0$ - $w_a$  parametric form with  $\Delta DIC = -27.56$ . This can be a game changer as our proposed model can establish itself as an strong alternative and favorite to the cosmological constant in the current standard model of cosmology.

With no information on the Hubble constant, the concordance  $\Lambda \text{CDM}$  model seems to be the most favored model. Consequently, all our results and the conclusion on ruling out  $\Lambda$  is solely and directly associated with the reliability of the Hubble constant measurement.

While our proposed model can significantly reduce the tensions in estimation of the cosmological parameters using low- and high- redshift data, some level of tension remains, in particular in the estimation of the matter density. This matter requires further study in order to understand the origin of any discrepancy that persist in any model assumption. More detailed studies are required to compare our proposed model to different

![](_page_5_Figure_1.jpeg)

<span id="page-5-0"></span>Figure 4. The histograms of  $\chi^2$  distribution from the converged MCMC chains for  $\Lambda$ CDM model, CPL and PEDE are presented. The left plots shows the  $\chi^2$  distribution for the Pantheon+BAO combination and the right plots are obtained with Pantheon+BAO+Ly $\alpha$ +CMB combination. Upper plots are derived with setting  $2\sigma$   $H_0$  hard-cut prior and lower plots are derived with setting  $1\sigma$  hard-cut  $H_0$  prior. Combining all the data, there is hardly an overlap between the  $\chi^2$  distribution of the PEDE model and  $\Lambda$ CDM model that explains the huge difference we derived for their DIC.

cosmological observations that can have some traces of  $\Lambda$ CDM assumptions in their pipelines. However, it is evident that making more appropriate treatment of different data for our proposed model can only make this model to perform better with respect to  $\Lambda$ CDM model.

Assuming that current cosmological data are all viable, our proposed model is shown to be a better representative of the effective behavior of dark energy in comparison with the cosmological constant. This work can guide theoretical studies of dark energy and our Universe in general.

We should recall that our ultimate goal should be to find a theoretical explanation for dark energy or, in a more fundamental approach, for the whole dark sector considering both dark matter and dark energy. We should consider different possibilities and look for the correct theory of gravity; considering dark energy and dark matter as curvature effects or unifying the whole dark sector might be reasonable ways to explain theoretically the observationally supported emergent behavior of the effective dark energy (Capozziello et al. 2006; Yang et al. 2019). Distinguishing between physical and geometrical models of dark energy as well as modified theories of gravity and breaking the degeneracies is in fact a fundamental task in cosmology that might be achievable by cosmography (Shafieloo et al. 2013;

[Shafieloo et al.](#page-6-28) [2018;](#page-6-28) [Capozziello et al.](#page-6-29) [2019\)](#page-6-29). Future observations would shed light on this important problem.

We should note that at the latest stages of this work, we became aware of the work of [Keeley et al.](#page-6-30) [\(2019\)](#page-6-30), which discussed a similar behavior of dark energy, but employed a parametric form that has few degrees of freedom similar to what has been introduced earlier in [Bas](#page-6-13)[sett et al.](#page-6-13) [\(2002\)](#page-6-13); [Shafieloo et al.](#page-6-14) [\(2009\)](#page-6-14). The simplicity of our phenomenological model with zero degrees of freedom for dark energy sector and its great performance is the core of our analysis which allow us to rule out cosmological constant with large statistical significance when we set hard priors on the Hubble constant.

X. Li and A.S. would like to acknowledge the support of the National Research Foundation of Korea (NRF-2016R1C1B2016478). X. Li is supported by the Strategic Priority Research Program of the Chinese Academy of Sciences, Grant No. XDB23000000. A.S. would like to acknowledge the support of the Korea Institute for Advanced Study (KIAS) grant funded by the Korea government. This work benefits from the high performance computing clusters Polaris and Seondeok at the Korea Astronomy and Space Science Institute. A.L. and A.S. would like to thank Zong-Hong Zhu and Beijing Normal University for the hospitality during the early stages of this work.

## REFERENCES

- <span id="page-6-3"></span>Ade, P. A., Aghanim, N., Arnaud, M., et al. 2016, Astronomy & Astrophysics, 594, A13
- <span id="page-6-4"></span>Aghanim, N., Akrami, Y., Ashdown, M., et al. 2018, arXiv preprint arXiv:1807.06209
- <span id="page-6-18"></span>Alam, S., Ata, M., Bailey, S., et al. 2017a, Monthly Notices of the Royal Astronomical Society, 470, 2617
- <span id="page-6-8"></span>Alam, U., Bag, S., & Sahni, V. 2017b, Physical Review D, 95, 023524
- <span id="page-6-13"></span>Bassett, B. A., Kunz, M., Silk, J., & Ungarelli, C. 2002, Monthly Notices of the Royal Astronomical Society, 336, 1217
- <span id="page-6-16"></span>Beutler, F., Blake, C., Colless, M., et al. 2011, Monthly Notices of the Royal Astronomical Society, 416, 3017
- <span id="page-6-26"></span><span id="page-6-19"></span>Blomqvist, M., et al. 2019, arXiv preprint arXiv:1904.03430
- Capozziello, S., Cardone, V., & Troisi, A. 2006, Journal of Cosmology and Astroparticle Physics, 2006, 001
- <span id="page-6-29"></span>Capozziello, S., D'Agostino, R., & Luongo, O. 2019, Int. J. Mod. Phys., D28, 1930016
- <span id="page-6-21"></span>Chen, L., Huang, Q.-G., & Wang, K. 2019, Journal of Cosmology and Astroparticle Physics, 2019, 028
- <span id="page-6-11"></span>Chevallier, M., & Polarski, D. 2001, International Journal of Modern Physics D, 10, 213
- <span id="page-6-22"></span>Cooke, R. J., Pettini, M., & Steidel, C. C. 2018, The Astrophysical Journal, 855, 102
- <span id="page-6-20"></span>de Sainte Agathe, V., Balland, C., du Mas des Bourboux, H., et al. 2019, arXiv preprint arXiv:1904.03400
- <span id="page-6-6"></span>Ding, X., Biesiada, M., Cao, S., Li, Z., & Zhu, Z.-H. 2015, The Astrophysical Journal Letters, 803, L22
- <span id="page-6-10"></span>Hazra, D. K., Shafieloo, A., & Souradeep, T. 2019, Journal of Cosmology and Astroparticle Physics, 2019, 036

- <span id="page-6-30"></span>Keeley, R. E., Joudaki, S., Kaplinghat, M., & Kirkby, D. 2019, arXiv preprint arXiv:1905.10198
- <span id="page-6-25"></span><span id="page-6-23"></span>Lewis, A., & Bridle, S. 2002, Physical Review D, 66, 103511 Liddle, A. R. 2007, Monthly Notices of the Royal
  - Astronomical Society: Letters, 377, L74
- <span id="page-6-12"></span><span id="page-6-0"></span>Linder, E. V. 2003, Physical Review D, 68, 083503
- Riess, A. G., Casertano, S., Yuan, W., Macri, L. M., & Scolnic, D. 2019, arXiv preprint arXiv:1903.07603
- <span id="page-6-1"></span>Riess, A. G., Macri, L. M., Hoffmann, S. L., et al. 2016, The Astrophysical Journal, 826, 56
- <span id="page-6-2"></span>Riess, A. G., Rodney, S. A., Scolnic, D. M., et al. 2018, The Astrophysical Journal, 853, 126
- <span id="page-6-17"></span>Ross, A. J., Samushia, L., Howlett, C., et al. 2015, Monthly Notices of the Royal Astronomical Society, 449, 835
- <span id="page-6-5"></span>Sahni, V., Shafieloo, A., & Starobinsky, A. A. 2014, The Astrophysical Journal Letters, 793, L40
- <span id="page-6-15"></span>Scolnic, D., Jones, D., Rest, A., et al. 2017, arXiv preprint arXiv:1710.00845
- <span id="page-6-27"></span>Shafieloo, A., Kim, A. G., & Linder, E. V. 2013, PhRvD, 87, 023520
- <span id="page-6-28"></span>Shafieloo, A., L'Huillier, B., & Starobinsky, A. A. 2018, Phys. Rev., D98, 083526
- <span id="page-6-14"></span>Shafieloo, A., Sahni, V., & Starobinsky, A. A. 2009, Physical Review D, 80, 101301
- <span id="page-6-9"></span>Shanks, T., Hogarth, L., & Metcalfe, N. 2018, arXiv preprint arXiv:1810.02595
- <span id="page-6-7"></span>Sol`a, J., G´omez-Valent, A., & de Cruz P´erez, J. 2017, Physics Letters B, 774, 317
- <span id="page-6-24"></span>Spiegelhalter, D. J., Best, N. G., Carlin, B. P., & Van Der Linde, A. 2002, Journal of the royal statistical society: Series b (statistical methodology), 64, 583

<span id="page-7-2"></span>Yang, W., Pan, S., Vagnozzi, S., et al. 2019, arXiv preprint

arXiv:1907.05344

<span id="page-7-1"></span>Zhao, G.-B., Wang, Y., Saito, S., et al. 2018, arXiv preprint arXiv:1801.03043

<span id="page-7-0"></span>Zheng, X., Ding, X., Biesiada, M., Cao, S., & Zhu, Z.-H. 2016, The Astrophysical Journal, 825, 17