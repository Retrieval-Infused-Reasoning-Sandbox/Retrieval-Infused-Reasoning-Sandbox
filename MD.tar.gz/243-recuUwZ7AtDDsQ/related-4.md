### Now on home page

• [ads icon](file:///)

# **[ads](file:///)**

[Enable full ADS](file:///core/never/abs/2019ApJ...883L...3L/abstract) •

## **view**

[Abstract](file:///abs/2019ApJ...883L...3L/abstract)  [Citations \(205\)](file:///abs/2019ApJ...883L...3L/citations) [References \(33\)](file:///abs/2019ApJ...883L...3L/references) [Co-Reads](file:///abs/2019ApJ...883L...3L/coreads)  [Similar Papers](file:///abs/2019ApJ...883L...3L/similar)  Volume Content [Graphics](file:///abs/2019ApJ...883L...3L/graphics)  [Metrics](file:///abs/2019ApJ...883L...3L/metrics)  [Export Citation](file:///abs/2019ApJ...883L...3L/exportcitation) 

# **ADS**

# **A Simple Phenomenological Emergent Dark Energy Model can Resolve the Hubble Tension**

- [Li, Xiaolei](file:///search/?q=author%3A%22Li%2C+Xiaolei%22) ; •
- [Shafieloo, Arman](file:///search/?q=author%3A%22Shafieloo%2C+Arman%22) •

### **Abstract**

Motivated by the current status of cosmological observations and significant tensions in the estimated values of some key parameters assuming the standard ΛCDM model, we propose a simple but radical phenomenological emergent dark energy model where dark energy has no effective presence in the past and emerges at later times. Theoretically, in this phenomenological dark energy model with zero degrees of freedom (similar to a ΛCDM model), one can derive that the equation of state of dark energy increases from - \tfrac{2}{3{ln} 10}-1 in the past to -1 in the future. We show that by setting a hard-cut 2σ lower bound prior for H <sup>0</sup> associated with a 97.72% probability from recent local observations, this model can satisfy different combinations of cosmological observations at low and high redshifts (SNe Ia, baryon acoustic oscillation (BAO), Lyα BAO, and cosmic microwave background (CMB)) substantially better than the concordance ΛCDM model with {{Δ }}

{χ }{bf} <sup>2</sup>∼ -41.08 and Δ DIC ∼ -35.38. If there are no substantial systematics in SN Ia, BAO, or Planck CMB data, and assuming the reliability of current local H <sup>0</sup> measurements, there is a very high probability that with more precise measurements of the Hubble constant our proposed phenomenological model rules out the cosmological constant with decisive statistical significance and is a strong alternative to explain the combination of different cosmological observations. This simple phenomenologically emergent dark energy model can guide theoretically motivated dark energy model building activities.

```
Publication:
     The Astrophysical Journal
Pub Date:
     September 2019
DOI:
     10.3847/2041-8213/ab3e09
     10.48550/arXiv.1906.08275
arXiv:
     arXiv:1906.08275
Bibcode:
     2019ApJ...883L...3L 
Keywords:
          Hubble constant;
          Cosmological parameters;
          Dark energy;
          Cosmological constant;
          Observational cosmology;
          758;
          339;
          351;
          334;
          1146;
          Astrophysics - Cosmology and Nongalactic Astrophysics;
          General Relativity and Quantum Cosmology;
          High Energy Physics - Phenomenology;
          High Energy Physics - Theory
E-Print:
     7 pages, 4 figures, 1 table, published in ApJL 
 full text sources
 IOP 
 |
 Preprint
 |
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        • 
        •
```

### **Graphics**

![](_page_2_Figure_1.jpeg)

### [Click to view more](file:///abs/2019ApJ...883L...3L/graphics)

© The SAO Astrophysics Data System

adshelp[at]cfa.harvard.edu

The ADS is operated by the Smithsonian Astrophysical Observatory under NASA Cooperative Agreement 80NSSC21M0056

[Smithsonian logo](http://www.si.edu) [Harvard Center for Astrophysics logo](https://www.cfa.harvard.edu/) [NASA logo](http://www.nasa.gov)

\*The material contained in this document is based upon work supported by a National Aeronautics and Space Administration (NASA) grant or cooperative agreement. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author and do not necessarily reflect the views of NASA.

#### Resources

- [About ADS](file:///about/)  •
- [ADS Help](file://ui.adsabs.harvard.edu/help/) •
- [What's New](file://ui.adsabs.harvard.edu/help/whats_new/) •
- [Careers@ADS](file:///about/careers/)  •
- [Web Accessibility Policy](file://ui.adsabs.harvard.edu/help/accessibility/) •

#### Social

- [@adsabs](file://twitter.com/adsabs)  •
- [ADS Blog](file://ui.adsabs.harvard.edu/blog/)  •

#### Project

- [Switch to full ADS](file:///core/never) •
- [Is ADS down? \(or is it just me...\)](https://adsisdownorjustme.herokuapp.com/) •
- [Smithsonian Institution](http://www.si.edu) •
- [Smithsonian Privacy Notice](http://www.si.edu/Privacy) •
- [Smithsonian Terms of Use](http://www.si.edu/Termsofuse) •
- [Smithsonian Astrophysical Observatory](http://www.cfa.harvard.edu/sao) •
- [NASA](http://www.nasa.gov) •

![](_page_2_Picture_25.jpeg)