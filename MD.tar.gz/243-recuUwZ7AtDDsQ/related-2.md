# Generalized Emergent Dark Energy: observational Hubble data constraints and stability analysis

A. Hernández-Almada¹\*, Genly Leon²†, Juan Magaña³‡,

Miguel A. García-Aspeitia<sup>4,5</sup>§, V. Motta<sup>6</sup> ¶

- <sup>1</sup> Facultad de Ingeniería, Universidad Autónoma de Querétaro, Centro Universitario Cerro de las Campanas, 76010, Santiago de Querétaro, México
- <sup>2</sup> Departamento de Matemáticas, Universidad Católica del Norte, Avda. Angamos 0610, Casilla 1280 Antofagasta, Chile
- $^3 Instituto \ de \ Astrofísica \ \mathscr{C} \ Centro \ de \ Astro-Ingeniería, \ Pontificia \ Universidad \ Católica \ de \ Chile,$

Av. Vicuña Mackenna, 4860, Santiago, Chile

- <sup>4</sup> Unidad Académica de Física, Universidad Autónoma de Zacatecas,
- Calzada Solidaridad esquina con Paseo a la Bufa S/N C.P. 98060, Zacatecas, México.
- <sup>5</sup>Consejo Nacional de Ciencia y Tecnología, Av. Insurgentes Sur 1582.
- Colonia Crédito Constructor, Del. Benito Juárez C.P. 03940, Ciudad de México, México.
- <sup>6</sup>Instituto de Física y Astronomía, Universidad de Valparaíso, Avda. Gran Bretaña 1111, Valparaíso, Chile.

Accepted YYYYMMDD. Received YYYYMMDD; in original form YYYYMMDD

#### ABSTRACT

Recently, a phenomenologically emergent dark energy (PEDE) model was presented with a dark energy density evolving as  $\widetilde{\Omega}_{\mathrm{DE}}(z) = \Omega_{\mathrm{DE},0} \left[1 - \mathrm{tanh} \left(\log_{10}(1+z)\right)\right]$ , i.e. with no degree of freedom. Later on, a generalized model was proposed by adding one degree of freedom to the PEDE model, encoded in the parameter  $\Delta$ . Motivated by these proposals, we constrain the parameter space  $(h, \Omega_m^{(0)})$  and  $(h, \Omega_m^{(0)}, \Delta)$  for PEDE and Generalized Emergent Dark Energy (GEDE) respectively, by employing the most recent observational (non-)homogeneous and differential age Hubble data. Additionally, we reconstruct the deceleration and jerk parameters and estimate yield values at z=0 of  $q_0=-0.784^{+0.028}_{-0.027}$  and  $j_0=1.241^{+0.164}_{-0.149}$  for PEDE and  $q_0=-0.730^{+0.059}_{-0.067}$  and  $j_0=1.293^{+0.194}_{-0.187}$  for GEDE using the homogeneous sample. We report values on the deceleration-acceleration transition redshift with those reported in the literature within  $2\sigma$  CL. Furthermore, we perform a stability analysis of the PEDE and GEDE models to study the global evolution of the Universe around their critical points. Although the PEDE and GEDE dynamics are similar to the standard model, our stability analysis indicates that in both models there is an accelerated phase at early epochs of the Universe evolution.

**Key words:** cosmology: theory, dark energy, cosmological parameters, observations.

# 1 INTRODUCTION

One of the most important challenges in modern cosmology is to elucidate the source of the accelerated expansion of the Universe, first evidenced by the high resolution observations of type Ia supernovae up to redshift  $z \sim 1.2$  (Riess et al. 1998; Perlmutter et al. 1999) and then also confirmed by the acoustic peaks (position) of the cosmic microwave back-

ground radiation measurements (Aghanim et al. 2018). In the framework of General Relativity (GR), the late cosmic acceleration is originated by an exotic component dubbed dark energy (DE). In the cosmological standard model, the nature of the dark energy is associated to the energy density of the vacuum ( $\Lambda$ ), known as cosmological constant (Zel'dovich 1968; Weinberg 1989). One of the main properties of  $\Lambda$  is its equation of state,  $w_{\Lambda}=-1$ , implying an energy density constant over the cosmic time. The cosmological constant as DE has became a successful model to explain and fit several cosmological observations, however some theoretical aspects suggest that it might be necessary to consider a dynamical dark energy. For instance, there is no convincing fundamental hypothesis to explain the cos-

<sup>\*</sup> E-mail:ahalmada@uag.mx

<sup>†</sup> E-mail:genly.leon@ucn.cl

<sup>‡</sup> E-mail:jmagana@astro.puc.cl

<sup>§</sup> E-mail:aspeitia@fisica.uaz.edu.mx

<sup>¶</sup> E-mail:veronica.motta@uv.cl

mological constant dominates the dynamics of the universe at late times, this is commonly known as the coincidence problem. Another crucial difficulty is to reconcile the estimations of the Λ energy density from quantum field theory with those of the cosmological data. These problems have inspired plenty of models (see [Li et al.](#page-13-4) [2011,](#page-13-4) for a review) to explain that the late cosmic acceleration, some of them consider dynamical dark energy as a scalar field or a dark energy EoS parameterization [\(Barboza & Alcaniz](#page-12-0) [2008;](#page-12-0) [Armendariz-Picon et al.](#page-12-1) [2001,](#page-12-1) [2000;](#page-12-2) [Linder](#page-13-5) [2003;](#page-13-5) [Chevallier](#page-12-3) [& Polarski](#page-12-3) [2001;](#page-12-3) [Jassal et al.](#page-12-4) [2005;](#page-12-4) [Sendra & Lazkoz](#page-13-6) [2012;](#page-13-6) [Wetterich](#page-13-7) [1988;](#page-13-7) [Caldwell et al.](#page-12-5) [1998;](#page-12-5) [Caldwell](#page-12-6) [2002;](#page-12-6) [Chiba &](#page-12-7) [Nakamura](#page-12-7) [1998;](#page-12-7) [Chiba et al.](#page-12-8) [2000;](#page-12-8) [Guo et al.](#page-12-9) [2005;](#page-12-9) [Maga˜na](#page-13-8) [et al.](#page-13-8) [2017;](#page-13-8) [Rom´an-Garza et al.](#page-13-9) [2019;](#page-13-9) [Amante et al.](#page-12-10) [2019\)](#page-12-10), interactions between dark energy and dark matter [\(Caldera-](#page-12-11)[Cabral et al.](#page-12-11) [2009;](#page-12-11) [Bolotin et al.](#page-12-12) [2015;](#page-12-12) [Di Valentino et al.](#page-12-13) [2019;](#page-12-13) [Hern´andez-Almada et al.](#page-12-14) [2020\)](#page-12-14), viscous DE [\(Cruz](#page-12-15) [et al.](#page-12-15) [2019;](#page-12-15) [Hern´andez-Almada](#page-12-16) [2019\)](#page-12-16), but also models without dark energy where the Einstenian gravity is modified [\(Garc´ıa-Aspeitia et al.](#page-12-17) [2018a,](#page-12-17) [2019c,](#page-12-18) [2018b,](#page-12-19) [2019b;](#page-12-20) [Ovg¨un](#page-13-10) ¨ [et al.](#page-13-10) [2018;](#page-13-10) [Hern´andez-Almada et al.](#page-12-21) [2019\)](#page-12-21), and more recently, models that propose an emergent DE whose energy density is ρDE(z) ∝ tanh(z) [\(Mortonson et al.](#page-13-11) [2009;](#page-13-11) [Dhawan](#page-12-22) [et al.](#page-12-22) [2020;](#page-12-22) [Li & Shafieloo](#page-13-12) [2019,](#page-13-12) [2020\)](#page-13-13). Reviews on Dark Energy (theory and observations) can be found in [\(Capozziello](#page-12-23) [et al.](#page-12-23) [2006a](#page-12-23)[,b;](#page-12-24) [Copeland et al.](#page-12-25) [2006;](#page-12-25) [Tsujikawa](#page-13-14) [2011;](#page-13-14) [Bamba](#page-12-26) [et al.](#page-12-26) [2012;](#page-12-26) [Tsujikawa](#page-13-15) [2013,](#page-13-15) and references therein).

On the other hand, studies with observational data pointed out that the DE could be evolving as function of the scale factor or redshift [\(Holsclaw et al.](#page-12-27) [2010;](#page-12-27) [Zhao et al.](#page-13-16) [2017;](#page-13-16) [Sola Peracaula et al.](#page-13-17) [2019\)](#page-13-17). Recently, the evidence from two different groups (Planck and Supernova Projects) show that there is a significant tension in the value of H<sup>0</sup> (between 4.0σ and 5.8σ), predicting, from Planck data a value of H<sup>0</sup> = 67.4 ± 0.5km s<sup>−</sup><sup>1</sup> Mpc<sup>−</sup><sup>1</sup> [\(Abbott et al.](#page-11-1) [2018\)](#page-11-1) with 1% of precision, while for Supernovaes the value is H<sup>0</sup> = 74. ± 1.4km s<sup>−</sup><sup>1</sup> Mpc<sup>−</sup><sup>1</sup> (see [Riess et al.](#page-13-18) [\(2019\)](#page-13-18), and [Verde et al.](#page-13-19) [\(2019\)](#page-13-19) for details). Another interesting unexplained phenomena is related to an excess of radiation detected by the Experiment to Detect the Global Epoch of Reionization (EDGES, [Bowman et al.](#page-12-28) [\(2018\)](#page-12-28) at z ∼ 17, which could be due to the interaction of dark matter with baryons but other explanations related to the presence of emergent DE in early epochs can not be discarded [\(Garc´ıa-](#page-12-18)[Aspeitia et al.](#page-12-18) [2019c,](#page-12-18)[b\)](#page-12-20).

Therefore, it is plausible to consider, as a natural extension to the cosmological constant, dynamical dark energy (DDE) models as the cause for the accelerated expansion of the Universe. Recently, [Li & Shafieloo](#page-13-12) [\(2019\)](#page-13-12) introduced a phenomenological emergent dark energy model (PEDE), parameterizing the energy density of DE (with zero degree of freedom) using a hyperbolic tangent function, which is symmetric at logarithm scales (first attempts in the same line were done by [Mortonson et al.](#page-13-11) [\(2009\)](#page-13-11)). In this model, the DE is negligible at early times but at late times the contribution of <sup>Ω</sup>eDE increases, providing an alternative solution to the coincidence problem. The authors constrained the PEDE model using the latest data of Supernovae Ia (SNIa), Baryon Acoustic Oscillations (BAO) and the Planck measurements of Cosmic Microwave Background Radiation (CMB) and claim that it can solve the known tension problem with the Hubble constant. Later on, [Pan et al.](#page-13-20) [\(2019\)](#page-13-20) constrained the PEDE model in a six parameter space using different observational data (mainly CMB), obtaining higher H<sup>0</sup> value than the standard model which reconcile the H<sup>0</sup> tension within 68% of the confidence level. Moreover, the PEDE model is also studied by [Koo et al.](#page-12-29) [\(2020\)](#page-12-29) when they reconstruct the cosmic expansion from SNIa data using a non-parametric iterative smoothing method. They also show that PEDE SNIa constraints are consistent with those of the standard model. In this vein, [Li & Shafieloo](#page-13-13) [\(2020\)](#page-13-13), generalized the PEDE model, constructing the Generalized Emergent Dark Energy model (GEDE), which contains two new parameters: ∆ indicates the model we are dealing (PEDE or ΛCDM) and a transition redshift zt, with ΩDE(zt) = Ωm(zt), establishing a relationship between the matter density parameter and ∆ (i.e. not a free parameter).

Here, we revisit and constrain the free parameters of the PEDE and GEDE models using the latest compilation of observational Hubble data (OHD). In addition, another vital study is the dynamical system analysis of these models. Dynamical systems analysis have provided to be very helpful to study the stability of several cosmological scenarios at background and perturbation levels [\(Basilakos et al.](#page-12-30) [2019\)](#page-12-30), for instance, Teleparallel Dark Energy [\(Xu et al.](#page-13-21) [2012;](#page-13-21) [Karpathopoulos et al.](#page-12-31) [2018;](#page-12-31) [Cid et al.](#page-12-32) [2018\)](#page-12-32), Galileons [\(Leon](#page-13-22) [& Saridakis](#page-13-22) [2013;](#page-13-22) [De Arcia et al.](#page-12-33) [2016;](#page-12-33) [Giacomini et al.](#page-12-34) [2017;](#page-12-34) [Dimakis et al.](#page-12-35) [2017;](#page-12-35) [De Arcia et al.](#page-12-36) [2018\)](#page-12-36), Einstein-æther theories [\(Latta et al.](#page-12-37) [2016;](#page-12-37) [Coley & Leon](#page-12-38) [2019;](#page-12-38) [Leon et al.](#page-13-23) [2020\)](#page-13-23), Hoˇrava–Lifshitz theory [\(Leon & Saridakis](#page-13-24) [2009;](#page-13-24) [Leon](#page-12-39) [& Paliathanasis](#page-12-39) [2019\)](#page-12-39), Higher order Lagrangians [\(Pulgar](#page-13-25) [et al.](#page-13-25) [2015\)](#page-13-25), non-linear electrodynamics [\(Ovg¨un et al.](#page-13-10) ¨ [2018\)](#page-13-10), quintom models [\(Lazkoz & Leon](#page-12-40) [2006;](#page-12-40) [Lazkoz et al.](#page-12-41) [2007;](#page-12-41) [Leon et al.](#page-13-26) [2018\)](#page-13-26), modified Jordan-Brans-Dicke theory [\(Cid](#page-12-42) [et al.](#page-12-42) [2016;](#page-12-42) [Le´on et al.](#page-13-27) [2018;](#page-13-27) [Giacomini et al.](#page-12-43) [2020\)](#page-12-43), scalar field cosmologies [\(Leon](#page-12-44) [2009;](#page-12-44) [Fadragas et al.](#page-12-45) [2014;](#page-12-45) [Fadragas](#page-12-46) [& Leon](#page-12-46) [2014;](#page-12-46) [Leon & Silva](#page-13-28) [2019\)](#page-13-28), and other modified gravity models [\(Leon et al.](#page-13-29) [2013;](#page-13-29) [Kofinas et al.](#page-12-47) [2014;](#page-12-47) [Leon &](#page-13-30) [Saridakis](#page-13-30) [2015\)](#page-13-30). We investigate the stability of PEDE and GEDE models to search for different cosmic stages (i.e. radiation, matter, DE domination epochs) in order to demonstrate its feasibility with the standard ΛCDM model.

The paper is organized as follow: Sec. [2](#page-1-0) we present the background cosmology of the PEDE and GEDE models. In Section [3,](#page-3-0) we constrain the parameters of PEDE and GEDE models using the latest sample of OHD, discussing the results in Sec. [3.1.](#page-3-1) Furthermore, in Sec. [4](#page-4-0) we discuss the stability of both models through a dynamical system analysis. Finally, we present our remarks and conclusions in Sec. [5.](#page-10-0)

# <span id="page-1-0"></span>2 PHENOMENOLOGICAL EMERGENT DARK ENERGY COSMOLOGY

<span id="page-1-1"></span>In this section we introduced the phenomenological emergent dark energy model proposed by [Li & Shafieloo](#page-13-12) [\(2019\)](#page-13-12) for which the DE is negligible at early times but it emerges at late times. We consider a flat Friedmann-Lemaitre-Robertson-Walker (FLRW) metric which contains matter (m, dark matter plus baryons), radiation (r), and PEDE. The dynamics of this Universe is described by the Friedmann equation and the continuity equation for each component as:

$$H^2 \equiv \left(\frac{\dot{a}}{a}\right)^2 = \frac{8\pi G}{3}(\rho_{DE} + \rho_{\rm m} + \rho_r), \qquad (1a)$$

$$\dot{\rho}_{DE} + 3H(1 + w_{DE})\rho_{DE} = 0, \tag{1b}$$

$$\dot{\rho}_{\rm m} + 3H(1+w_m)\rho_{\rm m} = 0, \tag{1c}$$

$$\dot{\rho}_r + 3H(1+w_r)\rho_r = 0, (1d)$$

where H is the Hubble parameter, a the scale factor,  $\rho_i$  is the energy density for each component,  $w_{DE} = p_{DE}/\rho_{DE}$ ,  $w_m = 0$ ,  $w_r = 1/3$  are the equation of state for DE, matter and radiation respectively. By solving Eqs. (1b), (1c), (1d) we can rewrite the Eq. (1a) in terms of the density parameters,  $\Omega = \rho_i/\rho_c^{-1}$ , and redshift, z = 1/(1+a), as

$$H(z)^2 = H_0^2 \left[ \Omega_m^{(0)} (1+z)^3 + \Omega_r^{(0)} (1+z)^4 + \widetilde{\Omega}_{DE}(z) \right].$$
 (2)

The superscript (0) denotes quantities evaluated at z=0 (or a=1) and  $\widetilde{\Omega}_{\mathrm{DE}}(z)=\Omega_{\mathrm{DE}}^{(0)}f(z)$ , where  $\Omega_{\mathrm{DE}}^{(0)}=1-\Omega_{m}^{(0)}-\Omega_{r}^{(0)}$  from the flatness condition:

<span id="page-2-5"></span><span id="page-2-2"></span>
$$\Omega_{\rm DE} = 1 - \Omega_m - \Omega_{\rm r}.\tag{3}$$

Notice that

$$f(z) \equiv \frac{\rho_{de}(z)}{\rho_{de}(0)} = \exp\left(3\int_0^z \frac{1 + w_{DE}(z)}{1 + z} dz\right).$$
 (4)

Li & Shafieloo (2019) propose a phenomenological functional form for f(z) and hence  $\widetilde{\Omega}_{\mathrm{DE}}(z)$  as

$$\widetilde{\Omega}_{\rm DE}(z) = \Omega_{\rm DE}^{(0)} [1 - \tanh(\log_{10}(1+z))],$$
 (5)

where  $\widetilde{\Omega}_{\rm DE} \to 0$  at  $z \to \infty$  and  $\widetilde{\Omega}_{\rm DE} \to 1.4$  at  $z \to -1$ . Notice that

$$\Omega_{DE}(z) = \frac{H_0^2}{H(z)^2} \widetilde{\Omega}_{DE}(z) 
= \frac{H_0^2}{H(z)^2} \Omega_{DE}^{(0)} [1 - \tanh(\log_{10}(1+z))],$$
(6)

Therefore, the dimensionless Friedmann equation results as

$$E(z) \equiv \frac{H(z)}{H_0} = \left\{ \Omega_m^{(0)} (1+z)^3 + \Omega_r^{(0)} (1+z)^4 + \Omega_{\text{DE}}^{(0)} \left[ 1 - \tanh\left(\log_{10}(1+z)\right) \right] \right\}^{1/2},$$
(7)

where the radiation density parameter at current epoch is calculated as  $\Omega_r^{(0)} = 2.469 \times 10^{-5} h^{-2} (1 + 0.2271 N_{eff})$ , with  $N_{eff} = 3.04$  as the number of relativistic species (Komatsu & et. al. 2011), and h as the current Hubble dimensionless parameter. The PEDE EoS can be calculated as

$$w(z) = \frac{1}{3} \frac{d \ln \widetilde{\Omega}_{DE}}{dz} (1+z) - 1.$$
 (8)

By substituting (5) into Eq. (8) results

$$w(z) = -\frac{1}{3\ln 10} \left( 1 + \tanh \left[ \log_{10} \left( 1 + z \right) \right] \right) - 1. \tag{9}$$

The deceleration parameter  $q = -\ddot{a}a/\dot{a}^2$  can be rewritten in terms of redshift and E(z) as:

$$q(z) = \frac{(z+1)}{E(z)} \frac{dE(z)}{dz} - 1,$$

$$q(z) = -1 + \frac{1}{2E(z)^2} \left[ 3\Omega_{m0} (z+1)^3 + 4\Omega_{r0} (z+1)^4 - \Omega_{\text{DE}}^{(0)} \frac{\operatorname{sech}^2 \left[ \frac{\ln(z+1)}{\ln(10)} \right]}{\ln(10)} \right].$$
(10)

For completeness we also calculate the jerk parameter,  $j \equiv \dddot{a}/a\,H^3$ 

<span id="page-2-4"></span>
$$j(z) = q(z)^{2} + \frac{(z+1)^{2}}{2E(z)^{2}} \frac{d^{2}E(z)^{2}}{dz^{2}} - \frac{(z+1)^{2}}{4E(z)^{4}} \times \left(\frac{dE(z)^{2}}{dz}\right)^{2},$$
(11)

where

$$\frac{dE(z)^{2}}{dz} = 3\Omega_{m}^{(0)} (1+z)^{2} + 4\Omega_{r}^{(0)} (1+z)^{3} - \Omega_{DE}^{(0)} \frac{\operatorname{sech}^{2} \left[ \frac{\ln(z+1)}{\ln(10)} \right]}{(1+z)\ln(10)}, \tag{12}$$

$$\frac{d^{2}E(z)^{2}}{dz^{2}} = 6\Omega_{m}^{(0)} (1+z) + 12\Omega_{r}^{(0)} (1+z)^{2} + \Omega_{DE}^{(0)} \frac{\operatorname{sech}^{2} \left[ \frac{\ln(z+1)}{\ln(10)} \right]}{(1+z)^{2}\ln(10)} + \Omega_{DE}^{(0)} \frac{2\operatorname{sech}^{2} \left[ \frac{\ln(z+1)}{\ln(10)} \right]}{(1+z)^{2}\ln^{2}(10)} \times \operatorname{tanh} \left[ \frac{\ln(z+1)}{\ln(10)} \right], \tag{13}$$

which deviates from one, the jerk value for the cosmological constant.

#### 2.1 Generalized emergent dark energy

Recently, Li & Shafieloo (2020) proposed a generalisation for the PEDE model also known as GEDE model by introducing

$$\widetilde{\Omega}_{\mathrm{DE}}(z) = \Omega_{\mathrm{DE}}^{(0)} \frac{1 - \tanh\left(\Delta \log_{10}(\frac{1+z}{1+z_t})\right)}{1 + \tanh\left(\Delta \log_{10}(1+z_t)\right)}, \quad (14)$$

<span id="page-2-3"></span>where  $z_t$  is a transition redshift,  $\Omega_{DE}(z_t) = \Omega_m^{(0)} (1+z_t)^3$ ,  $\Delta$  is an appropriate dimensionless non-negative free parameter with the characteristic that if  $\Delta=0$  the  $\Lambda$ CDM model is recovered, and when  $\Delta=1$  and  $z_t=0$  the previously PEDE model is recovered. As  $z_t$  can be related to  $\Omega_m^{(0)}$  and  $\Delta$ , then  $z_t$  is not a free parameter. Notice that the DE density parameter is given by

<span id="page-2-6"></span>
$$\Omega_{\rm DE} = \frac{H_0^2}{H^2} \left( 1 - \Omega_m^{(0)} - \Omega_r^{(0)} \right) \frac{1 - \tanh\left(\Delta \log_{10}\left(\frac{1+z}{1+z_t}\right)\right)}{1 + \tanh\left(\Delta \log_{10}\left(1+z_t\right)\right)}.$$
 (15)

The GEDE Friedmann equation is given by

$$E(z) \equiv \frac{H(z)}{H_0} = \left[\Omega_m^{(0)} (1+z)^3 + \Omega_r^{(0)} (1+z)^4 + \Omega_{\rm DE}^{(0)} \frac{1-\tanh\left(\Delta \log_{10}(\frac{1+z}{1+z_t})\right)}{1+\tanh\left(\Delta \log_{10}(1+z_t)\right)}\right]^{1/2}.$$
(16)

<span id="page-2-0"></span><sup>&</sup>lt;sup>1</sup> The critical density is defined as  $\rho_c \equiv 3H^2/8\pi G$ .

<span id="page-2-1"></span><sup>&</sup>lt;sup>2</sup> Where it is defined  $\widetilde{\Omega}_{DE}(z) \equiv \rho_{DE}/\rho_c^{(0)}$ .

The EoS for GEDE model is given by

$$w(z) = -\frac{\Delta}{3\ln 10} \left( 1 + \tanh \left[ \Delta \log_{10} \frac{(1+z)}{1+z_t} \right] \right) - 1.$$
 (17)

The deceleration parameter reads

$$q(z) = -1 + \frac{1}{2E(z)^2} \left[ 3\Omega_m^{(0)} (1+z)^3 + 4\Omega_r^{(0)} (1+z)^4 - \frac{\Delta}{\ln(10)} \frac{\Delta}{\ln(10)} \frac{\sinh^2\left(\frac{\Delta \ln\left(\frac{1+z}{1+z_t}\right)}{\ln(10)}\right)}{1 + \tanh(\Delta \log_{10}(1+z_t))} \right].$$
(18)

As a complement, we also calculate the GEDE jerk parameter using Eq. (11), where

$$\frac{dE(z)^{2}}{dz} = 3\Omega_{m}^{(0)} (1+z)^{2} + 4\Omega_{r}^{(0)} (1+z)^{3} - 8 \operatorname{cch}^{2} \left[ \frac{\Delta \ln\left(\frac{1+z}{1+z_{t}}\right)}{\ln(10)} \right] \\
\Omega_{\mathrm{DE}}^{(0)} \frac{\Delta}{\ln(10)(1+z)} \frac{\operatorname{sech}^{2} \left[ \frac{\Delta \ln\left(\frac{1+z}{1+z_{t}}\right)}{\ln(10)} \right]}{1+\tanh(\Delta \log_{10}(1+z_{t}))}, \quad (19)$$

$$\frac{d^{2}E(z)^{2}}{dz^{2}} = 6\Omega_{m}^{(0)} (1+z) + 12\Omega_{r}^{(0)} (1+z)^{2} + 8 \operatorname{cch}^{2} \left[ \frac{\Delta \ln\left(\frac{1+z}{1+z_{t}}\right)}{\ln(10)} \right]}{1+\tanh(\Delta \log_{10}(1+z_{t}))} + \Omega_{\mathrm{DE}}^{(0)} \frac{\Delta \Delta}{\ln^{2}(10)(1+z)^{2}} \frac{\operatorname{sech}^{2} \left[ \frac{\Delta \ln\left(\frac{1+z}{1+z_{t}}\right)}{\ln(10)} \right]}{1+\tanh(\Delta \log_{10}(1+z_{t}))} \times \operatorname{tanh} \left[ \frac{\Delta \ln\left(\frac{1+z}{1+z_{t}}\right)}{\ln(10)} \right]. \quad (20)$$

# <span id="page-3-0"></span>3 OBSERVATIONAL CONSTRAINTS

A canonical test is to confront a cosmological model with the observational Hubble data (OHD) which gives direct measurement of expansion rate of the Universe. Currently, the OHD sample is obtained from the differential age technique (DA, Jimenez & Loeb 2002; Moresco et al. 2012) and BAO measurements. In this work, we consider the sample compiled by Magaña et al. (2018), which consists of 51 points in the redshift region 0.07 < z < 2.36. It is worth to note that 31 data points come from the cosmic chronometers, i.e. passive galaxies, using the DA technique which are cosmological-model-independent. However, 20 data points of this sample are estimated from BAO measurements under different fiducial cosmologies (based on ACDM), which could provide biased constraints. Nevertheless, Magaña et al. (2018) present also homogeneous BAO OHD points calculated using the sound horizon at the drag epoch from Planck measurements. Here, we use the full sample with non-homogeneous and homogeneous OHD data points from BAO, and OHD from DA method. Thus, the figure-of-merit is given by

$$\chi_{OHD}^{2} = \sum_{i=1}^{N_{i}} \left( \frac{H_{th}(z_{i}, \mathbf{\Theta}) - H_{obs}(z_{i})}{\sigma_{obs}^{i}} \right)^{2}, \quad (21)$$

where  $N_i$  is the number of data points,  $H_{th}(z_i, \Theta) - H_{obs}(z_i)$  denotes the difference between the theoretical Hubble parameter with parameter space  $\Theta = (h, \Omega_{dm}^{(0)})$  and

<span id="page-3-2"></span> $(h, \Omega_{dm}^{(0)}, \Delta)$  for PEDE and GEDE models respectively, and the observational one at the redshift  $z_i$ , and  $\sigma_{obs}^i$  is the uncertainty of  $H_{obs}^i$ .

To constrain the PEDE and GEDE cosmological parameters we perform a Markov chain Monte Carlo (MCMC) analysis employing the emcee Python module (Foreman-Mackey et al. 2013). We consider Gaussian likelihoods  $\mathcal{L} \propto e^{-\chi^2/2}$ , a Gaussian prior over h centered at  $h=0.7403\pm0.0142$  (Riess et al. 2019, R19, hereafter) and a flat prior over  $\Omega_m^{(0)}$ : [0, 1] for both, PEDE and GEDE models. Additionally, we consider a flat prior on  $\Delta$ : [0, 10]. Notice that the parameter  $z_t$  presented in the GEDE model is related to the parameter  $\Delta$  through the condition  $\Omega_{DE}(z_t) = \Omega_m(z_t)$ . As a complement, we perform a similar analysis but alternatively using a flat prior on h: [0, 1]. Our analysis consider a burn-in phase which is stopped when the Gelman-Rubin convergence criteria (< 1.1) is fulfilled and a MCMC phase with 3000 steps and 500 walkers for each one.

# <span id="page-3-1"></span>3.1 Results

In this section we report our results obtained in Bayesian analysis. In Table 1 are provided the mean values for the parameters and their uncertainties estimated at  $1\sigma$  in both scenarios and using the homogeneous, non-homogeneous and DA OHD. Additionally, we also report the parameter mean values when a flat prior over h is considered. These are in agreement with those obtained using a Gaussian prior on h. Our constraints are very similar to those obtained by Li & Shafieloo (2019), estimating a deviation on  $\Delta$  within  $1\sigma$ CL with the one estimated by Li & Shafieloo (2019) from a CMB+ h (R19) joint analysis. Figure 1 shows the 2D confidence region at 68% (1 $\sigma$ ), 95% (2 $\sigma$ ) and 99.7% (3 $\sigma$ ) of the free parameters for GEDE (top panel) and PEDE (bottom panel) models, using the homogeneous, non-homogeneous and DA OHD, respectively. Moreover, their 1D posterior distributions are presented. Regarding the generalization of PEDE discussed by Li & Shafieloo (2019), consisting in the addition of the parameter  $z_t$ , we found that our constraints on the space  $(h, \Omega_m^{(0)})$  presented in Fig. 1 are independent of the selected value for  $z_t$  (see Appendix A). Nevertheless, we have also constrained  $z_t$  by requiring the condition  $\Omega_m(z_t) =$  $\Omega_{DE}(z_t)$ . We found mean values of  $z_t = 0.378, 0.386$ , and 0.328 for homogeneous, non-homogeneous, and DA data, respectively (h Gaussian prior). Results are shown in Table 1 and in the middle panel of Fig. 1, which represents the corresponding constrained space  $(h, \Omega_m^{(0)}, z_t)$ . Notice that there is no significant differences on the h and  $\Omega_m$  bounds considering  $z_t = 0$  and  $z_t$  constrained to  $\Omega_m(z_t) = \Omega_{DE}(z_t)$ . It is worth to note that although the homogeneous sample provides slightly broader confidence contours than those obtained with the non-homogeneous sample, the constraints are less (cosmology-model) unbiased. Regarding DA OHD constraints, although we obtain the less restricted regions of the model parameters, they are completely unbiased (model independent). As it is expected, we find an anti-correlation relation between  $\Omega_{\rm m}^{(0)}$  and h for both models. For GEDE model, we also observe a positive correlation between  $\Delta$  and h. For the GEDE model, our  $\Delta$  constraints are in tension with  $\Delta = 1.13 \pm 0.28$  obtained by Li & Shafieloo (2020) employing CMB and the  $H_0$  measurements. Additionally,

in the case of LCDM, it is interesting to observe that the best-fit value of  $\Delta$  using DA OHD has the largest deviation compared to those obtained with the homogeneous or non-homogeneous samples. Figure 2 shows the comparison of the Hubble parameter in GEDE and PEDE cosmologies with the observational ones including non-homogeneous, homogeneous and DA OHD points. Notice that both models provide a good fit to the data. In addition, our estimates on  $H_0$  and  $\Omega_m^{(0)}$  are consistent within 1.2 $\sigma$  of those values obtained by Pan et al. (2019) and Riess et al. (2019), alleviating the tension with the results obtained by Planck satellite.

Figure 3 shows the reconstruction of the deceleration parameter as a function of redshift for both, PEDE and GEDE models when the non homogeneous, homogeneous and DA OHD are employed. The universe undergoes a transition from decelerated to accelerated expansion at redshift  $0.784^{+0.044}_{-0.044}$  and  $0.809^{+0.057}_{-0.057}$  for the PEDE and GEDE models respectively (homogeneous OHD). It is worth to mention that we observe an earlier deceleration-acceleration transition (close to 0.5) for DA OHD than for the previously mentioned sample. Our constraints are consistent at  $1.95\sigma$  and  $1.1\sigma$  respectively with the results by Jesus et al. (2018). Additionally, the reconstruction of the jerk parameter for both models is shown in Figure 4. By construction the PEDE and GEDE are DDE models, hence the jerk evolves as a function of the scale factor and it is not equal to one as in the cosmological constant paradigm. We also report the deceleration and jerk parameters at z = 0 for PEDE as  $q_0 = -0.784^{+0.028}_{-0.027}$ ,  $-0.784^{+0.028}_{-0.027}$ , and  $j_0 = 1.241^{+0.164}_{-0.149}$ ,  $1.487^{+0.010}_{-0.011}$ ,  $^{8}_{7}, -0.668^{+0.061}_{-0.067}$  $1.443^{+0.025}_{-0.023}$  using homogeneous, non-homogeneous and DA OHD, spectively. Similarly, for GEDE we estimate  $q_0$  $\begin{array}{llllllllllllllllllllllllllllllllllll$ non-homogeneous and DA OHD are considered. We found that the estimate of  $q_0(j_0)$ , using DA sample, is consistent within  $1.9\sigma(1.5\sigma)$  with the previous values using the (non-) homogeneous samples.

# <span id="page-4-0"></span>4 DYNAMICAL SYSTEM ANALYSIS

In this section, we investigate the PEDE and GEDE models from the dynamical system approach to obtain the critical points and stability conditions of the models. This phase-space and stability examination let us to bypass the nonlinearities of the cosmological equations, and facilitates a complete analytical treatment, to obtain a qualitative description of the global dynamics of these scenarios, which is independent of the initial conditions and the specific evolution of the universe. Furthermore, in these asymptotic solutions we are able to calculate various observable quantities, such as the DE and total equation-of-state parameters, the deceleration parameter, the density parameters for the different species, etc., that allows us to classify the solution.

In order to perform the stability analysis of a given cosmological scenario, one first transforms it to its autonomous form  $\mathbf{X}' = \mathbf{f}(\mathbf{X})$  (Wainwright & Ellis 1997; Ferreira & Joyce 1997; Copeland et al. 1998; Perko 2000; Coley 2003; Copeland et al. 2006; Chen et al. 2009; Cotsakis & Kittou 2013; Giambo & Miritzis 2010), where  $\mathbf{X}$  is a column vec-

<span id="page-4-1"></span>![](_page_4_Figure_7.jpeg)

Figure 1. 1D posterior distributions and 2D contours of the free parameters for GEDE (top panel) and PEDE with the constraint  $\Omega_m(z_t) = \Omega_{de}(z_t)$  (middle panel) and the case  $z_t = 0$  (bottom panel) models at  $1\sigma$ ,  $2\sigma$ ,  $3\sigma$  CL (from darker to lighter respectively). The orange, blue and green contours correspond to the space constrained using DA and (non-) homogeneous OHD respectively.

<span id="page-5-0"></span>**Table 1.** Mean values of the free parameters for GEDE and PEDE models using homogeneous, non-homogeneous and DA OHD and a Gaussian prior on  $h = 0.7403 \pm 0.0142$  (Riess et al. 2019). The last column shows the estimated redsfhit  $z_t$  using the condition  $\Omega_m(z_t) = \Omega_{DE}(z_t)$ . The uncertainties reported correspond to  $1\sigma$  confidence level. In parenthesis are the best fit values when a flat prior on h is considered in the region [0, 1].

| Sample              | $\chi^2$       | h                                                     | $\Omega_m^{(0)}$                                      | Δ                                                     | $z_t$                                                 |  |  |
|---------------------|----------------|-------------------------------------------------------|-------------------------------------------------------|-------------------------------------------------------|-------------------------------------------------------|--|--|
| PEDE                |                |                                                       |                                                       |                                                       |                                                       |  |  |
| homogeneous OHD     | 24.5 (24.5)    | $0.740^{+0.011}_{-0.011} \ (0.738^{+0.018}_{-0.018})$ | $0.252^{+0.016}_{-0.015} \ (0.254^{+0.024}_{-0.022})$ | 1.0                                                   | 0                                                     |  |  |
| non-homogeneous OHD | $32.1\ (32.1)$ | $0.740^{+0.010}_{-0.010} \ (0.740^{+0.014}_{-0.014})$ | $0.249^{+0.013}_{-0.013} \ (0.249^{+0.018}_{-0.016})$ | 1.0                                                   | 0                                                     |  |  |
| DA OHD              | $14.7\ (14.6)$ | $0.739^{+0.014}_{-0.014} \ (0.723^{+0.049}_{-0.044})$ | $0.319^{+0.035}_{-0.039} \ (0.329^{+0.057}_{-0.045})$ | 1.0                                                   | 0                                                     |  |  |
| homogeneous OHD     | $24.2\ (24.2)$ | $0.739^{+0.011}_{-0.011} \ (0.735^{+0.018}_{-0.018})$ | $0.251^{+0.016}_{-0.015} \ (0.255^{+0.024}_{-0.022})$ | 1.0                                                   | $0.378^{+0.035}_{-0.034} \ (0.371^{+0.049}_{-0.049})$ |  |  |
| non-homogeneous OHD | 31.6 (31.6)    | $0.738^{+0.010}_{-0.010} \ (0.736^{+0.013}_{-0.013})$ | $0.248^{+0.013}_{-0.013} \ (0.250^{+0.017}_{-0.016})$ | 1.0                                                   | $0.386^{+0.028}_{-0.028} \ (0.381^{+0.037}_{-0.037})$ |  |  |
| DA OHD              | $16.1\ (14.4)$ | $0.732^{+0.013}_{-0.013} \ (0.691^{+0.032}_{-0.032})$ | $0.275^{+0.031}_{-0.029} \ (0.333^{+0.064}_{-0.054})$ | 1.0                                                   | $0.328^{+0.060}_{-0.058}\ (0.226^{+0.096}_{-0.096})$  |  |  |
| GEDE                |                |                                                       |                                                       |                                                       |                                                       |  |  |
| homogeneous OHD     | 23.7(23.0)     | $0.735^{+0.012}_{-0.012} \ (0.725^{+0.023}_{-0.020})$ | $0.247^{+0.018}_{-0.017} \ (0.256^{+0.025}_{-0.022})$ | $0.690^{+0.624}_{-0.457} \ (0.533^{+0.712}_{-0.390})$ | $0.403^{+0.058}_{-0.057} \ (0.385^{+0.058}_{-0.056})$ |  |  |
| non-homogeneous OHD | $30.2\ (28.6)$ | $0.731_{-0.011}^{+0.012} \ (0.718_{-0.015}^{+0.017})$ | $0.245^{+0.014}_{-0.013} \ (0.255^{+0.018}_{-0.017})$ | $0.539_{-0.352}^{+0.470} \ (0.332_{-0.244}^{+0.472})$ | $0.417^{+0.044}_{-0.043}\ (0.403^{+0.043}_{-0.043})$  |  |  |
| DA OHD              | $14.7\ (14.6)$ | $0.739^{+0.014}_{-0.014} \ (0.723^{+0.048}_{-0.044})$ | $0.319^{+0.036}_{-0.039} \ (0.329^{+0.057}_{-0.046})$ | $3.930^{+2.304}_{-2.083} (3.264^{+3.258}_{-2.230})$   | $0.183^{+0.094}_{-0.057}\ (0.174^{+0.083}_{-0.064})$  |  |  |

<span id="page-5-1"></span>![](_page_5_Figure_3.jpeg)

Figure 2. Best fits over (non-)homogeneous and DA OHD sample at left, middle and right side of the panel for PEDE (top panel) and GEDE (bottom panel). The darker (lighter) band represents the uncertainty at  $1\sigma$  ( $3\sigma$ ) CL.

tor containing some auxiliary variables and primes denote derivative with respect to a time variable (conveniently chosen). Then, one extracts the critical points  $\mathbf{X_c}$  by imposing the condition  $\mathbf{X'} = \mathbf{0}$ , and in order to determine their stability properties, one expands around them with  $\mathbf{U}$  the column vector of the perturbations of the variables. Therefore, for each critical point the perturbation equations are expanded to first order as  $\mathbf{U'} = \mathbf{Q} \cdot \mathbf{U}$ , with the matrix  $\mathbf{Q}$  containing the coefficients of the perturbation equations. The eigenvalues of  $\mathbf{Q}$  determine the type and stability of the specific critical point.

# 4.1 PEDE model

To start our analysis, it is convenient to write the cosmic evolution equations in terms of the scale factor. Using the

rule

$$\frac{d\rho_i}{dt} = \frac{d\rho_i}{da}\frac{da}{dt} = aH\frac{d\rho_i}{da},\tag{22}$$

and using units where  $8\pi G=1,$  the field equations are written as

<span id="page-5-2"></span>
$$\rho_{DE}'(a) + 3(1 + w(a))\frac{\rho_{DE}(a)}{a} = 0, \tag{23a}$$

$$\rho'_{\rm m}(a) + 3\frac{\rho_{\rm m}(a)}{a} = 0, \tag{23b}$$

$$\rho_r'(a) + 4\frac{\rho_r(a)}{a} = 0, (23c)$$

$$\frac{H'(a)}{H(a)} = -\frac{3}{2} (1 + w(a)) \frac{\Omega_{DE}}{a} - \frac{3}{2} \frac{\Omega_{\rm m}}{a} - 2 \frac{\Omega_{\rm r}}{a}, (23d)$$

$$3H^{2}(a) = \rho_{DE}(a) + \rho_{m}(a) + \rho_{r}(a). \tag{23e}$$

Integrating (23a) with the EoS w(a) given by

$$w(a) = -\frac{1}{3\ln 10} \left( 1 - \tanh \left[ \log_{10} a \right] \right) - 1, \tag{24}$$

<span id="page-6-0"></span>![](_page_6_Figure_2.jpeg)

Figure 3. Reconstruction of the deceleration parameter for PEDE (top panel) and GEDE (bottom panel) using the mean values constraints from the (non-)homogeneous and DA OHD samples at left, middle and right side respectively of the panel. The darker (lighter) band represents the uncertainty at  $1\sigma$  ( $3\sigma$ ) CL.

<span id="page-6-1"></span>![](_page_6_Figure_4.jpeg)

Figure 4. Reconstruction of the jerk parameter for PEDE (top panel) and GEDE (bottom panel). using the mean values constraints from the (non-)homogeneous and DA OHD samples at left, middle and right side respectively. The darker (lighter) band represents the uncertainty at  $1\sigma$  ( $3\sigma$ ) CL.

 $\frac{df}{d\bar{\tau}} = \frac{H_0^2}{(H_0 + H)^2} \frac{df}{d\tau}$ . The new time variable  $\bar{\tau}$  can be calculated

and considering  $\rho_{DE}^{(0)}=\rho_{DE}|_{a=1}=3H_0^2\Omega_{\rm DE}^{(0)}$  we obtain

$$\rho_{DE}(a) = 3H_0^2 \Omega_{\rm DE}^{(0)} \left( \tanh \left( \log_{10}(a) \right) + 1 \right). \tag{25}$$

$$\Omega_{\rm DE} = \frac{H_0^2}{H^2} (1 - \Omega_m^{(0)} - \Omega_r^{(0)}) \left[ 1 + \tanh\left(\log_{10} a\right) \right].$$
 (26)

Defining the time variable  $\tau=\log_{10}a$ , we have  $\frac{df}{d\tau}=\ln(10)a\frac{df}{da}$ . Alternatively, we can define the time derivative

MNRAS 000, 000-000 (2020)

as a function of the redshift through

$$\frac{d\bar{\tau}}{dz} = -\frac{(1+E(z))^2}{(1+z)\ln 10}$$

$$= -\frac{1}{(1+z)\ln 10} \left(1 + \left[\Omega_m^{(0)} (1+z)^3 + \Omega_r^{(0)} (1+z)^4 + \Omega_{\rm DE}^{(0)} [1-\tanh (\log_{10}(1+z))]\right]^{1/2}\right)^2.$$
(27)

Defining

$$T = \frac{H_0}{H_0 + H}, \ \Omega_m = \frac{H_0^2 \Omega_m^{(0)}}{a^3 H^2}, \ \Omega_r = \frac{H_0^2 \Omega_r^{(0)}}{a^4 H^2}, \tag{28}$$

E(z) is related to T(z) by

$$E(z) = \frac{H}{H_0} = \frac{1 - T}{T}. (29)$$

Therefore,

dT

+

(1 − Ω (0) <sup>m</sup> − Ω (0) <sup>r</sup> )

<span id="page-7-0"></span>1

$$\Omega_{\rm DE} \, = \tfrac{T^2}{(1-T)^2} \big(1 - \Omega_m^{(0)} - \Omega_r^{(0)} \big) \left[1 + \tanh \left(\log_{10} a\right)\right]. \, (30)$$

On the other hand, due to the flatness condition [\(3\)](#page-2-5) we obtain the restriction

$$\frac{1 - \Omega_{\rm m} - \Omega_{\rm r}}{(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})} = \frac{T^2}{(1 - T)^2} \left[ 1 + \tanh\left(\log_{10} a\right) \right]. \tag{31}$$

This implies that the equation of state can be expressed as a function of the phase space variables, that is,

$$w(T, \Omega_{\rm m}, \Omega_{\rm r}) = -1 - \frac{1}{3\ln 10} \left[ 2 - \frac{(1 - \Omega_{\rm m} - \Omega_{\rm r})(1 - T)^2}{(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})T^2} \right].$$
(32)

The dynamical system for the vector state (T, Ωm, Ωr) T is now given by

$$\frac{dI}{d\bar{\tau}} = \frac{1}{2} (1 - T) T^3 (2(\Omega_{\rm m} + \Omega_{\rm r} - 1) + \ln(10)(3\Omega_{\rm m} + 4\Omega_{\rm r})) 
+ \frac{(1 - T)^3 T (1 - \Omega_{\rm m} - \Omega_{\rm r})^2}{2(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})},$$
(33a)
$$\frac{d\Omega_{\rm m}}{d\bar{\tau}} = T^2 \Omega_{\rm m} (\ln(10)(3\Omega_{\rm m} + 4\Omega_{\rm r} - 3) + 2(\Omega_{\rm m} + \Omega_{\rm r} - 1)) 
+ \frac{(1 - T)^2 \Omega_{\rm m} (1 - \Omega_{\rm m} - \Omega_{\rm r})^2}{(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})},$$
(33b)
$$\frac{d\Omega_{\rm r}}{d\bar{\tau}} = T^2 \Omega_{\rm r} (\Omega_{\rm m} (2 + 3\ln(10)) + 2(\Omega_{\rm r} - 1)(1 + 2\ln(10))) 
+ (1 - T)^2 \Omega_{\rm r} (1 - \Omega_{\rm m} - \Omega_{\rm r})^2$$

, (33c)

.

defined on the bounded phase space (T, Ωm, Ωr) ∈ R 3 : 0 6 T 6 1, Ω<sup>m</sup> + Ω<sup>r</sup> 6 1, Ω<sup>m</sup> > 0, Ω<sup>r</sup> > 0 We have three parameters in the model, Ω(0) <sup>m</sup> , Ω (0) <sup>r</sup> , Ω (0) DE = 1−Ω (0) <sup>m</sup> −Ω (0) <sup>r</sup> , which represent the values of Ωm, Ωr, ΩDE at redshift z = 0 (T = 0.5). For the PEDE model, these parameters are constrained in previous section, for the following qualitative and numerical analysis we take the homogeneous constraints, Ω (0) <sup>m</sup> , Ω (0) <sup>r</sup> , Ω (0) DE = 0.252, 7.62 × 10<sup>−</sup><sup>5</sup> , 0.747 ,

which are less unbiased for any fiducial cosmological model (see §[3\)](#page-3-0). Notice that multiplying term by term the system [\(33\)](#page-7-0) by the equation [\(27\)](#page-7-1), results in a system which can be integrated in terms of redshift.

We can study the dynamical system [\(33\)](#page-7-0) as we discussed in Table [2.](#page-8-0) The system [\(33\)](#page-7-0) admits two relevant invariant sets T = 1 and T = 0. The variable T satisfies T → 0 when H → ∞; T → 1 when H → 0; and T = 0.5 when H → H0.

<span id="page-7-2"></span><span id="page-7-1"></span>![](_page_7_Figure_19.jpeg)

Figure 5. Dynamics of the system [\(33\)](#page-7-0) on the invariant set T = 1. The equilibrium point P<sup>3</sup> : (1, 0, 1) is a local source, P<sup>4</sup> : (1, 1, 0) is a saddle and P<sup>5</sup> : (1, 0, 0) is a local sink (but a saddle in the 3D phase space).

<span id="page-7-3"></span>![](_page_7_Figure_21.jpeg)

Figure 6. Dynamics of the system [\(33\)](#page-7-0) on the invariant set T = 0. The line P<sup>7</sup> : (0, Ωm, 1 − Ωm), and its endpoints P<sup>8</sup> and P<sup>9</sup> are local attractors. P<sup>6</sup> is the global source.

In the invariant set T = 1 the dynamics of the system [\(33\)](#page-7-0) is as shown in Fig. [5.](#page-7-2) The equilibrium point P<sup>3</sup> : (1, 0, 1) is a local source, P<sup>4</sup> : (1, 1, 0) is a saddle and P<sup>5</sup> : (1, 0, 0) is a local sink (but a saddle in the 3D phase space). On the other hand, the dynamics at the invariant set T = 0 is governed by an integrable 2D dynamical system such that the orbit passing through (T, Ωm, Ωr) = (0, Ωm,0, Ωr,0) at ¯τ = ¯τ<sup>0</sup> is given by

$$\Omega_{\rm r}(\Omega_{\rm m}) = \frac{\Omega_{\rm m}\Omega_{\rm r,0}}{\Omega_{\rm m,0}}.$$
 (34)

For this solution, the relation between ¯τ and Ω<sup>m</sup> is

$$\bar{\tau}(\Omega_{\rm m}) = \bar{\tau}_0 + \frac{(\Omega_{\rm m} - \Omega_{\rm m,0})(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})(1 - \Omega_{\rm m,0} - \Omega_{\rm r,0})}{(\Omega_{\rm m,0} - \Omega_{\rm r,0})((1 - \Omega_{\rm m})\Omega_{\rm m,0} - \Omega_{\rm m}\Omega_{\rm r,0})} + (1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)}) \ln\left(\frac{\Omega_{\rm m}(1 - \Omega_{\rm m,0} - \Omega_{\rm r,0})}{(1 - \Omega_{\rm m})\Omega_{\rm m,0} - \Omega_{\rm m}\Omega_{\rm r,0}}\right).$$
(35)

Figure [6](#page-7-3) illustrates the dynamics of the system [\(33\)](#page-7-0) on the invariant set T = 0. The line P<sup>7</sup> : (0, Ωm, 1 − Ωm), and the endpoints P<sup>8</sup> and P<sup>9</sup> are local attractors. P<sup>6</sup> is the source (¯τ

| Label | $(T, \Omega_{\mathrm{m}}, \Omega_{r})$                            | Eigenvalues                                                                                                                                                                                                                           | Stability     |
|-------|-------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|
| $P_1$ | $\left(\frac{1}{1+\sqrt{2\Omega_{\mathrm{DE}}^{(0)}}},0,0\right)$ | $\left\{ -\frac{2}{\left(\sqrt{2\Omega_{\mathrm{DE}}^{(0)}}+1\right)^{2}}, -\frac{3\ln(10)}{\left(\sqrt{2\Omega_{\mathrm{DE}}^{(0)}}+1\right)^{2}}, -\frac{4\ln(10)}{\left(\sqrt{2\Omega_{\mathrm{DE}}^{(0)}}+1\right)^{2}} \right\}$ | sink          |
| $P_2$ | $\left(\frac{1}{1-\sqrt{2\Omega_{\mathrm{DE}}^{(0)}}},0,0\right)$ | $\left\{-\frac{2}{\left(\sqrt{2\Omega_{\rm DE}^{(0)}}-1\right)^2}, -\frac{3\ln(10)}{\left(\sqrt{2\Omega_{\rm DE}^{(0)}}-1\right)^2}, -\frac{4\ln(10)}{\left(\sqrt{2\Omega_{\rm DE}^{(0)}}-1\right)^2}\right\}$                        | sink          |
| $P_3$ | (1, 0, 1)                                                         | $\{2+4\ln(10), -2\ln(10), \ln(10)\}$                                                                                                                                                                                                  | saddle        |
| $P_4$ | (1, 1, 0)                                                         | $\left\{2+3\ln(10), -\frac{3\ln(10)}{2}, -\ln(10)\right\}$                                                                                                                                                                            | saddle        |
| $P_5$ | (1,0,0)                                                           | $\{-2(1+2\ln(10)), -2-3\ln(10), 1\}$                                                                                                                                                                                                  | saddle        |
| $P_6$ | (0,0,0)                                                           | $\left\{\frac{1}{1-\Omega_{\mathrm{m}}^{(0)}-\Omega_{\mathrm{r}}^{(0)}},\frac{1}{1-\Omega_{\mathrm{m}}^{(0)}-\Omega_{\mathrm{r}}^{(0)}},\frac{1}{2(1-\Omega_{\mathrm{m}}^{(0)}-\Omega_{\mathrm{r}}^{(0)})}\right\}$                   | source        |
| $P_7$ | $(0,\Omega_{\rm m},1-\Omega_{\rm m})$                             | $\{0,0,0\}$                                                                                                                                                                                                                           | nonhyperbolic |
| $P_8$ | (0, 0, 1)                                                         | $\{0,0,0\}$                                                                                                                                                                                                                           | nonhyperbolic |
| $P_9$ | (0, 1, 0)                                                         | $\{0,0,0\}$                                                                                                                                                                                                                           | nonhyperbolic |

<span id="page-8-0"></span>**Table 2.** Stability of the equilibrium points of the system (33).

was re scaled by the factor  $1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)} > 0$ ). In the 3D phase space, the late-time attractors are the equilibrium points  $P_{1,2}$  with  $T = \frac{1}{1 \pm \sqrt{2}\Omega_{\rm DE}^{(0)}}, \Omega_{\rm m} = 0, \Omega_{\rm r} = 0$ .

Therefore  $H_{\pm} = \pm \sqrt{2\Omega_{\rm DE}^{(0)}} H_0$ . The corresponding cosmolog-

ical solutions are  $a_{\pm}(t)=a_0e^{\pm\sqrt{2\Omega_{\rm DE}^{(0)}}H_0t}$ . The choice +, that corresponds to  $P_1$ , belongs to an ever expanding de Sitter solution. The solution corresponding to  $P_2$  satisfies  $a\to 0$  at late times; an static solution. However, this solution is not physical because the condition  $T\geqslant 0$  requires  $0\leqslant\Omega_{\rm DE}^{(0)}<\frac{1}{2}$ , which is not supported (at  $>5\sigma$ ) neither by the narrow bound placed by Planck data  $\Omega_{DE}^{(0)}=0.6889\pm0.0056$  (Abbott et al. 2018), nor by our values  $\Omega_{DE}^{(0)}=0.748^{+0.016}_{-0.015}$  (homogenous OHD),  $\Omega_{\rm DE}^{(0)}=0.6801^{+0.036}_{-0.036}$  (DA OHD). There are three solutions  $P_{\rm DE}^{(0)}=0.036$  (DA OHD).

There are three solutions  $P_3$ ,  $P_4$  and  $P_5$  dominated by radiation, DM and DE, respectively, that satisfy T=1. This means that H=0 for these solutions, and they are saddles. The point  $P_6$  is the source, it satisfies  $\Omega_{\rm m}=0,\Omega_{\rm r}=0$ , therefore, it is dominated by DE. As T=0, this implies that  $H\to\infty$ . Because it is a source, it represents the initial stages of the cosmic evolution, dominated by DE. This means that for the model not only dark energy accounts for the recent accelerated phase of the evolution but also the initial stage is driven by an accelerated dark-energy dominated expanding phase.

To analyse the nonhyperbolic points  $P_7$ ,  $P_8$  and  $P_9$  that satisfy  $T \to 0$ , we rely on numerical examination, where we see that they behave as saddles as shown in the top of Fig. 7. However, when the dynamics is restricted to the invariant set T=0, it is governed by an integrable 2D dynamical system, such that the line  $P_7:(0,\Omega_{\rm m},1-\Omega_{\rm m})$ , along with the endpoints  $P_8$  and  $P_9$ , are local attractors (as shown in Fig. 6), whereas  $P_6$  is the global source.

### 4.2 GEDE model

In this section we investigate the GEDE model with  $\Omega_{DE}$  given by Eq. (15) whose evolution is given by (1) with w(z) defined by (17).

Due to the flatness condition given by Eq. (3) we obtain the

restriction

$$\frac{1 - \Omega_{\rm m} - \Omega_{\rm r}}{(1 - \Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)})} = \frac{T^2}{(1 - T)^2} \left[ \frac{1 - \tanh\left(\Delta \log_{10}(\frac{1+z}{1+z_t})\right)}{1 + \tanh\left(\Delta \log_{10}(1+z_t)\right)} \right]. \tag{36}$$

This implies that the equation of state can be expressed as a function of the phase space variables, that is,

$$w(T, \Omega_{\rm m}, \Omega_{\rm r}) = \frac{\Delta \left( 2 - \frac{(T-1)^2 (\Omega_{\rm m} + \Omega_{\rm r} - 1) \left( \tanh\left(\frac{\Delta \ln(z_t + 1)}{\ln(10)}\right) + 1\right)}{T^2 (\Omega_{\rm m}^{(0)} + \Omega_{\rm r}^{(0)} - 1)} \right)}{3 \ln(10)}. (37)$$

In this case we calculate  $\bar{\tau}$  as a function of the redshift through

<span id="page-8-2"></span>
$$\frac{d\bar{\tau}}{dz} = -\frac{(1+E(z))^2}{(1+z)\ln 10}$$

$$= -\frac{1}{(1+z)\ln 10} \left(1 + \left[\Omega_m^{(0)} (1+z)^3 + \Omega_r^{(0)} (1+z)^4 + \Omega_{\rm DE}^{(0)} \frac{1-\tanh\left(\Delta\log_{10}(\frac{1+z}{1+z_t})\right)}{1+\tanh\left(\Delta\log_{10}(1+z_t)\right)}\right]^{1/2}\right)^2.$$
(38)

The dynamical system for the vector state  $(T, \Omega_{\rm m}, \Omega_r)^T$  is now given by

<span id="page-8-1"></span>
$$\frac{dT}{d\bar{\tau}} = -\frac{1}{2}(T-1)T^{3}(2\Delta(\Omega_{\rm m} + \Omega_{\rm r} - 1) + \ln(10)(3\Omega_{\rm m} + 4\Omega_{\rm r})) 
+ \frac{\Delta(T-1)^{3}T(\Omega_{\rm m} + \Omega_{\rm r} - 1)^{2}g(\Delta, z_{t})}{2(\Omega_{\rm m}^{(0)} + \Omega_{\rm r}^{(0)} - 1)},$$
(39a)
$$\frac{d\Omega_{\rm m}}{d\bar{\tau}} = T^{2}\Omega_{\rm m}(2\Delta(\Omega_{\rm m} + \Omega_{\rm r} - 1) + \ln(10)(3\Omega_{\rm m} + 4\Omega_{\rm r} - 3)) 
+ \frac{\Delta(1-T)^{2}\Omega_{\rm m}(1-\Omega_{\rm m} - \Omega_{\rm r})^{2}g(\Delta, z_{t}))}{1-\Omega_{\rm m}^{(0)} - \Omega_{\rm r}^{(0)}},$$
(39b)
$$\frac{d\Omega_{\rm r}}{d\bar{\tau}} = T^{2}\Omega_{\rm r}(2\Delta(\Omega_{\rm m} + \Omega_{\rm r} - 1) + \ln(10)(3\Omega_{\rm m} + 4\Omega_{\rm r} - 4)) 
+ \frac{\Delta(1-T)^{2}\Omega_{\rm r}(1-\Omega_{\rm m} - \Omega_{\rm r})^{2}g(\Delta, z_{t})}{1-\Omega_{\rm r}^{(0)} - \Omega_{\rm r}^{(0)}},$$
(39c)

with

$$g(\Delta, z_t) = \tanh(\Delta \log_{10}(z_t + 1)) + 1,$$
 (40)

 $\begin{array}{ll} \text{defined} & \text{on} & \text{the} & \text{bounded} & \text{phase} & \text{space} \\ \big\{(T,\Omega_m,\Omega_r) \in \mathbb{R}^3: 0 \leqslant T \leqslant 1, \Omega_m + \Omega_r \leqslant 1, \Omega_m \geqslant 0, \Omega_r \geqslant 0 \big\}. \end{array}$ 

In the GEDE model, we take as the observable parameters the homogeneous constraints (which are less unbiased due to any underlying cosmology, see §3):  $\left(\Omega_{\rm m}^{(0)}, \Omega_{\rm r}^{(0)}, \Omega_{\rm DE}^{(0)}\right) = (0.247, 7.72 \times 10^{-5}, 0.752).$ 

The stability of the equilibrium points of system (39) are discussed in table  $3^{3}$ 

The system (39) admits the relevant invariant sets T=1and T = 0.

In a similar way as for the PEDE model, the upper bounds within  $1\sigma$  confidence levels of the parameter mean

<span id="page-9-2"></span>
$$z_t \sim \begin{cases} 0.403 + 0.058 = 0.461, & \text{homogeneous OHD} \\ 0.183 + 0.094 = 0.277, & \text{DA OHD} \end{cases}$$
(41)  
$$\Delta \sim \begin{cases} 0.690 + 0.624 = 1.314, & \text{homogeneous OHD} \\ 3.930 + 2.304 = 6.234, & \text{DA OHD} \end{cases}$$
(42)

$$\Delta \sim \begin{cases} 0.690 + 0.624 = 1.314, & \text{homogeneous OHD} \\ 3.930 + 2.304 = 6.234, & \text{DA OHD} \end{cases}$$
 (42)

and the dynamics is qualitatively the same as for the system (33). That is, in the invariant set T=1 the equilibrium point  $P_3:(1,0,1)$  is a local source,  $P_4:(1,1,0)$  is a saddle and  $P_5:(1,0,0)$  is a local sink (but a saddle in the 3D phase space). On the other hand, the dynamics at the invariant set T=0 is governed by an integrable 2D dynamical system, such that the line  $P_7:(0,\Omega_{\rm m},1-\Omega_{\rm m})$ , along with the endpoints  $P_8$  and  $P_9$  are local attractors, whereas  $P_6$  is the global source.

The late-time attractors on the 3D phase space are the equilibrium points  $P_{1,2}$  with  $T = \frac{1}{(1\pm\bar{\Lambda})}, \Omega_{\rm m} = 0, \Omega_{\rm r} = 0$ , with

$$\tilde{\Lambda} \equiv \sqrt{\frac{2\Omega_{\mathrm{DE}}^{(0)}}{g(\Delta,z_t)}}$$
. Therefore  $H_{\pm} = \pm \tilde{\Lambda}$ . The cosmological solu-

tions corresponds to  $a_{\pm}(t)=a_0e^{\pm\tilde{\Lambda}t}$ . The choice +, that is associated to  $P_1$ , corresponds to an ever expanding de Sitter solution. The solution corresponding to  $P_2$  satisfies  $a \to 0$ at late times. Therefore, it is an static solution. However, this solution is not physical because the condition  $T \geqslant 0$ , requires  $0 \leqslant \Omega_{\mathrm{DE}}^{(0)} < \frac{g(\Delta, z_t)}{2}$ , with

$$g(\Delta, z_t) \sim \begin{cases} 1.213046, & \text{homogeneous OHD} \\ 1.90944, & \text{DA OHD} \end{cases}$$
 (43)

where we have used the upper bounds  $z_t$  and  $\Delta$  within  $1\sigma$ confidence levels given by (41), (42), respectively. For homogeneous OHD, we conclude that the interval for  $\Omega_{DE}^{(0)}$ is not supported by observations, i.e. the narrow bound from Planck data  $\Omega_{DE}^{(0)} = 0.6889 \pm 0.0056$  by Abbott et al. (2018). With our value  $\Omega_{DE}^{(0)} = 0.753^{+0.018}_{-0.017}$ , the restriction has less probability to be satisfied. However, for DA OHD this interval becomes  $0 \leqslant \Omega_{\rm DE}^{(0)} \lesssim 0.954722$ . For this set  $\Omega_{DE}^{(0)} \approx 1 - \Omega_{\rm m}^{(0)} = 0.6801^{+0.036}_{-0.036}$ , and the point  $P_2$  is allowed by the observations. A conservative upper bound 0.954722 was calculated with the largest values  $z_t, \Delta$ , but it takes a lower value ( $\sim 0.789332$ ) for the best-fit values.

There are three solutions  $P_3$ ,  $P_4$  and  $P_5$  dominated by radiation, dark matter and dark energy, respectively, that satisfy T=1. This means that H=0 at these solutions and they are saddles.

The point  $P_6$  is the global source, it satisfies  $\Omega_{\rm m}=0, \Omega_{\rm r}=0,$ therefore, it is dominated by DE. As T = 0, this implies that  $H \to \infty$ . Because it is a source, it represents the initial stages

<span id="page-9-0"></span>![](_page_9_Figure_17.jpeg)

![](_page_9_Figure_18.jpeg)

Figure 7. Dynamics of the systems (33) for the PEDE model with  $\left(\Omega_{\rm m}^{(0)}, \Omega_{\rm r}^{(0)}\right) = \left(0.252, 7.62 \times 10^{-5}\right)$  (top panel) and (39) for the GEDE model with  $\left(\Omega_{\rm m}^{(0)},\Omega_{\rm r}^{(0)}\right)=\left(0.247,7.72\times10^{-5}\right)$ (bottom panel). The blue lines correspond to the orbit with initial condition  $(T(0), \Omega_{\rm m}(0), \Omega_{\rm r}(0)) = (0.5, 0.252, 7.62 \times 10^{-5})$  and  $(0.5, 0.247, 7.72 \times 10^{-5})$ , for PEDE and GEDE respectively, which represents the current universe. We see that all orbits are attracted by the point (marked with a star)  $P_1: (T, \Omega_m, \Omega_r) =$ (0.449833, 0., 0.) (PEDE) and  $P_1: (T, \Omega_m, \Omega_r) = (0.472999, 0., 0.)$ (GEDE).

of the cosmic evolution, dominated by DE. This means that for the model not only dark energy accounts for the recent accelerated phase of the evolution but also for the initial expanding phase.

To analyse the the non-hyperbolic points  $P_7$ ,  $P_8$  and  $P_9$ that satisfy  $T \to 0$ , we use numerical examination, where we have shown they are saddles (see Fig. 7). However, when the dynamics is restricted to the invariant set T=0, it is governed by an integrable 2D dynamical system, such that the line  $P_7:(0,\Omega_{\rm m},1-\Omega_{\rm m})$ , along with the endpoints  $P_8$ and  $P_9$  are local attractors, whereas  $P_6$  is the global source. The dynamics is exactly the same as presented in Fig. 6 after

 $ar{ au}$  is re-scaled by the factor  $\frac{1-\Omega_{
m m}^{(0)}-\Omega_{
m r}^{(0)}}{\Delta q(\Delta,z_t))}>0.$  Figure 7 shows the dynamics of the systems  $\left(\Omega_{\rm m}^{(0)},\Omega_{\rm r}^{(0)}\right)$ (33) for the PEDE model with  $(0.252, 7.62 \times 10^{-5})$  and (39) for the GEDE model with  $\left(\Omega_{\rm m}^{(0)}, \Omega_{\rm r}^{(0)}\right)' = \left(0.247, 7.72 \times 10^{-5}\right)$ . The blue

<span id="page-9-1"></span> $<sup>^3</sup>$  Multiplying term by term system (39) by equation (38) we obtain a system that can be integrated in terms of redshift.

| Label | $(T, \Omega_{\mathrm{m}}, \Omega_{r})$           | Eigenvalues                                                                                                                      | Stability     |
|-------|--------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|---------------|
| $P_1$ | $\left(\frac{1}{1+\tilde{\Lambda}},0,0\right)$   | $\left\{-rac{4\ln(10)}{(	ilde{\Lambda}+1)^2},-rac{3\ln(10)}{(	ilde{\Lambda}+1)^2},-rac{2\Delta}{(	ilde{\Lambda}+1)^2} ight\}$ | sink          |
| $P_2$ | $\left(\frac{1}{1-\tilde{\Lambda}},0,\ 0\right)$ | $\left\{-rac{4\ln(10)}{(	ilde{\Lambda}-1)^2},-rac{3\ln(10)}{(	ilde{\Lambda}-1)^2},-rac{2\Delta}{(	ilde{\Lambda}-1)^2} ight\}$ | sink          |
| $P_3$ | (1, 0, 1)                                        | $\{-2\ln(10), \ln(10), 2(\Delta + 2\ln(10))\}$                                                                                   | saddle        |
| $P_4$ | (1, 1, 0)                                        | $\left\{-\frac{3\ln(10)}{2}, -\ln(10), 2\Delta + 3\ln(10)\right\}$                                                               | saddle        |
| $P_5$ | (1, 0, 0)                                        | $\{\Delta, -2(\Delta + 2\ln(10)), -2\Delta - 3\ln(10)\}$                                                                         | saddle        |
| $P_6$ | (0,0,0)                                          | $\left\{rac{2\Delta}{	ilde{\Lambda}^2},rac{2\Delta}{	ilde{\Lambda}^2},rac{\Delta}{	ilde{\Lambda}^2} ight\}$                   | source        |
| $P_7$ | $(0,\Omega_{\rm m},1-\Omega_{\rm m})$            | $\{0, 0, 0\}$                                                                                                                    | nonhyperbolic |
| $P_8$ | (0, 0, 1)                                        | $\{0,0,0\}$                                                                                                                      | nonhyperbolic |
| $P_9$ | (0, 1, 0)                                        | {0,0,0}                                                                                                                          | nonhyperbolic |

<span id="page-10-1"></span>**Table 3.** Stability of the equilibrium points of the system (39). We use the notations  $g(\Delta, z_t) = \tanh\left(\frac{\Delta \ln(z_t+1)}{\ln(10)}\right) + 1$ , and  $\tilde{\Lambda} \equiv \sqrt{\frac{2\Omega_{\rm DE}^{(0)}}{g(\Delta, z_t)}}$ 

to orbits with initial correspond  $(T(0), \Omega_{\rm m}(0), \Omega_{\rm r}(0))$ =  $(0.5, 0.252, 7.62 \times 10^{-5})$  $(0.5, 0.247, 7.72 \times 10^{-5})$ , for PEDE and GEDE respectively, which represent the current universe. All orbits are attracted by the point (marked with a star)  $P_1$ :  $(T, \Omega_{\rm m}, \Omega_{\rm r}) = (0.449833, 0., 0.)$  (PEDE) and  $P_1: (T, \Omega_{\rm m}, \Omega_{\rm r}) = (0.472999, 0., 0.)$  (GEDE). We have evaluated  $g(\Delta, z_t) \sim 1.213046$  using the upper bounds of  $z_t \sim 0.461$  and  $\Delta \sim 1.314$  (homogeneous OHD). For GEDE, using DA OHD, we have the upper bounds  $z_t = 0.277$  and  $\Delta = 6.234$  given by (41), (42) and  $\Omega_{DE}^{(0)} \approx 1 - \Omega_{\rm m}^{(0)} = 0.6801_{-0.036}^{+0.039} < 0.954722$ . For the best-fit values of  $z_t$  and  $\Delta$ , the interval is narrowed to  $0 \leq \Omega_{DE}^{(0)} < 0.789332$ . Therefore, the attractor  $P_2$ marginally exists.

The top panel of Figure 8 shows the numerical solution for the system (33) (PEDE) and (39) (GEDE) using the initial conditions at current epoch. For this particular solution, at early epochs, the universe is dominated by radiation (equilibrium point  $P_8$ ), later on, the matter becomes equal to radiation, then it begins to dominate (equilibrium point  $P_9$ ). At late times, the emergent DE dominates the Universe dynamics in a de Sitter phase (equilibrium point  $P_1$ ). The aforementioned radiation dominated solution  $P_8$  and the matter dominated solution  $P_4$  do have T=0. This means that  $H\to\infty$  at these solutions, as expected  $(H\sim\frac{1}{2t}$  for the usual radiation dominated solution and  $H\sim\frac{2}{3t}$  for the usual matter dominated solution). In the bottom panel of the same figure, it is shown the difference between the dynamical variables for the GEDE and PEDE models.

# <span id="page-10-0"></span>5 CONCLUSIONS

We investigated the phenomenological models recently proposed by Li & Shafieloo (2019, 2020) for which the dark energy is negligible at very early times of the Universe, dubbed PEDE and GEDE models. The main characteristic of these models is that they emerge at late times sourcing the accelerated expansion of the Universe through  $\Omega_{DE}(z) \propto \tanh(z)$ . While in PEDE model there is no extra degree of freedom as the standard model, the GEDE model introduces one free parameter ( $\Delta$ ) which plays an important role to recover the  $\Lambda$ CDM and PEDE dynamics when  $\Delta=0$  and  $\Delta=1$ , respectively.

We put observational constraints for the PEDE and

<span id="page-10-2"></span>![](_page_10_Figure_9.jpeg)

Figure 8. Top panel. Evolution of the dynamical variables  $(T, \Omega_m, \Omega_r, \Omega_{DE})$  over  $\tau$  for the GEDE model. In dotted-black lines are the corresponding variables for the PEDE model. Bottom panel.  $\Delta\Omega_i = \Omega_i^{GEDE} - \Omega_i^{PEDE}$  for i = m, r, DE and  $\Delta T = T^{GEDE} - T^{PEDE}$ .

GEDE models through the most recent observational Hubble data samples: one including non-homogeneous OHD points from BAO and other sample where they are homogeneous. Our analysis was performed with flat and Gaussian priors on the dimensionless Hubble parameter at the today h. Our constraints for the PEDE model are consistent with those obtained by Li & Shafieloo (2019). We also find

consistent values for h and  $\Omega_m^{(0)}$ , within  $1.2\sigma$ , with those reported by Pan et al. (2019). Nevertheless, our  $\Delta$  limits (e.g.  $0.69^{+0.624}_{-0.457}$ ) are consistent with PEDE model but in tension at  $1\sigma$  with  $\Delta = 1.13 \pm 0.28$  obtained by Li & Shafieloo (2020) from Planck and  $H_0$  (R19) measurements. Considering the uncertainties on  $\Delta$ , there is no strong support of GEDE over the  $\Lambda$  model when OHD (low redshift) are employed. In addition, we also reconstructed the cosmic evolution for the deceleration and jerk parameters in the PEDE and GEDE scenarios. For both models, the deceleration parameter undergoes a phase transition from a a decelerated expansion to an accelerated one (at  $z \sim 0.78, 0.8$ ). By construction PEDE and GEDE are dynamical dark energy models, hence the jerk parameter deviates from one. Furthermore, our values for the deceleration-acceleration transition redshift and currrent values of the cosmographic parameters  $q_0$  and  $j_0$  are in agreement with those reported in the literature (García-Aspeitia et al. 2018c; Haridasu et al. 2018; Hernández-Almada 2019; Hernández-Almada et al. 2020). Regarding our stability analysis, we reconstructed the evolution of the dynamical variables  $\Omega_m$ ,  $\Omega_r$ , and  $\Omega_{DE}$  for PEDE and GEDE models using the homogeneous constraints since they are less unbiased due to any underlying cosmology (see §3). We obtain that they have a very similar dynamics (Fig. 8). We see that the Universe evolves to a de Sitter solution, corresponding to the equilibrium point  $P_1$  with  $a_{+}(t) = a_0 e^{\tilde{\Lambda}t}$ , (see §4) from a matter dominated phase, preceded by a radiation dominated epoch. However, the main difference with the evolution of the  $\Lambda$ CDM model is that the global source (equilibrium point  $P_6$ ) is dominated by DE. This means that for the model not only dark energy accounts for the recent accelerated phase of the evolution but also the initial stages are driven by a DE dominated accelerated expanding phase. This feature of PEDE/GEDE models is not mentioned by Li & Shafieloo (2019, 2020). Furthermore, there is a possibility to have an attractor in  $P_2$ , with  $a_-(t) = a_0 e^{-\tilde{\Lambda}t}$ , which is not an expanding solution for  $H_0 > 0$  at late times. However, this solution is not tion for  $H_0 > 0$  at late times. However, this solution is not supported by data (Abbott et al. 2018) because the condition  $T \ge 0$  requires  $0 \le \Omega_{\rm DE}^{(0)} < \frac{1}{2}$  (PEDE, homogeneous OHD), or  $0 \le \Omega_{\rm DE}^{(0)} < \frac{g(\Delta,z_t)}{2^2} \sim 0.606518$  (GEDE, homogeneous OHD). In addition, our constraints (homogeneous OHD) are  $\Omega_{DE}^{(0)} = 0.748^{+0.016}_{-0.015}$ ,  $\Omega_r^{(0)} = (7.63^{+0.24}_{+0.23}) \times 10^{-5}$  for PEDE and  $\Omega_{DE}^{(0)} = 0.753^{+0.018}_{-0.017}$ ,  $\Omega_r^{(0)} = (7.72^{+0.26}_{+0.25}) \times 10^{-5}$  for GEDE, which makes the condition of existence for  $P_2$  hardest to be satisfied. However, using DA OHD, the intervals for est to be satisfied. However, using DA OHD, the intervals for GEDE are  $0 \leqslant \Omega_{\mathrm{DE}}^{(0)} < \frac{g(\Delta,z_t)}{2} \sim 0.954722$  where  $z_t = 0.277$  and  $\Delta = 6.234$ , and  $\Omega_{DE}^{(0)} \approx 1 - \Omega_{\mathrm{m}}^{(0)} = 0.6801^{+0.039}_{-0.036}$ . For the best-fit values of  $z_t$  and  $\Delta$ , the interval is narrowed to  $0 \leqslant \Omega_{DE}^{(0)} < 0.789332$ . Therefore,  $P_2$  is (marginally) allowed from these observations and it is an attractor, in contrast with previous cases.

On the other hand, many emergent DE models as those studied by García-Aspeitia et al. (2019a) based on unimodular gravity, predict a birth of DE in the reionization epoch at  $z\sim17$ , where an excess of photons has been detected by EDGES (Bowman et al. 2018) that could imply new physics beyond the standard scenario. In this vein, the PEDE (GEDE) model could also emerge at the same epoch, being in agreement with the unimodular gravity. At  $z\sim17$ , the PEDE density is  $\rho_{DE}\sim10\%\rho_c^{(0)}$  (i.e.  $\tilde{\Omega}_{DE}\sim0.1$ ).

Finally, the early accelerated phase, a possible connection to the reionization epoch together with other observational constraints, like those related with  $H_0$  tension (Pan et al. 2019), could be transcendental for PEDE and GEDE models and they should be further investigated.

#### ACKNOWLEDGMENTS

We thank the anonymous referee for thoughtful remarks and suggestions. G.L. was funded by ANID through FONDE-CYT Iniciación grant no. 11180126 and by Vicerrectoría de Investigación y Desarrollo Tecnológico at Universidad Católica del Norte., A.H.A. thanks to the PRODEP project, Mexico for resources and financial support. J.M. acknowledges the support from CONICYT project Basal AFB-170002, M.A.G.-A. acknowledges support from SNI-México, CONACyT research fellow, COZCyT and Instituto Avanzado de Cosmología (IAC) collaborations. V.M. acknowledges the support of Centro de Astrofísica de Valparaíso (CAV). J.M., M.A.G.-A and V.M. acknowledge CONICYT REDES (190147).

#### NOTE ADDED

While this work was being typed, we became aware of a complementary study of PEDE model, developed by Liu & Miao (2020), that appeared in the arXiv repository. Liu & Miao (2020), used CMB data from Planck 2018, BAO measurements and SNIa data, to obtain the bounds on total neutrino masses with the approximation of degenerate neutrino masses, in some Dark Energy settings, in particular in PEDE models.

# <span id="page-11-2"></span>APPENDIX A: PEDE MODEL INCLUDING THE TRANSITION REDSHIFT $\mathcal{Z}_T$

Li & Shafieloo (2019) also introduced a transition redshift  $z_t$  into  $\widetilde{\Omega}_{\rm DE}(z)$  of PEDE as

$$\widetilde{\Omega}_{\rm DE}(z) = \Omega_{\rm DE}^{(0)} \frac{1 - \tanh\left(\log_{10}(\frac{1+z}{1+z_t})\right)}{1 + \tanh\left(\log_{10}(1+z_t)\right)},$$
(A1)

which satisfies  $\widetilde{\Omega}_{DE}(z_t) = \Omega_m^{(0)} (1+z_t)^3$ . To assess the impact of this parameter  $z_t$  in our PEDE constraints, we carry out the MCMC analysis for all the OHD samples using the same Gaussian prior on h as before and including  $z_t$  as free parameter with the flat prior: [0,5]. Figure A1 shows the 1D posterior distributions and 2D contours for h,  $\Omega_m^{(0)}$  and  $z_t$ . Notice that the  $(h, \Omega_m^{(0)})$  bounds presented are independent of the selected value for  $z_t$ . This same result was found by Li & Shafieloo (2019).

#### REFERENCES

<span id="page-11-1"></span><span id="page-11-0"></span>Abbott T. M. C., et al., 2018, Monthly Notices of the Royal Astronomical Society, 480, 3879
Aghanim N., et al., 2018

<span id="page-12-61"></span>![](_page_12_Figure_2.jpeg)

Figure A1. 1D posterior distributions and 2D contours of the free parameters for PEDE including  $z_t$  as free parameter at  $1\sigma$ ,  $2\sigma$ ,  $3\sigma$  CL (from darker to lighter respectively)

<span id="page-12-10"></span>Amante M. H., Magaña J., Motta V., García-Aspeitia M. A., Verdugo T., 2019, arXiv e-prints, p. arXiv:1906.04107

<span id="page-12-2"></span>Armendariz-Picon C., Mukhanov V. F., Steinhardt P. J., 2000, Phys. Rev. Lett., 85, 4438

<span id="page-12-1"></span>Armendariz-Picon C., Mukhanov V. F., Steinhardt P. J., 2001, Phys. Rev., D63, 103510

<span id="page-12-26"></span>Bamba K., Capozziello S., Nojiri S., Odintsov S. D., 2012, Astrophys. Space Sci., 342, 155

<span id="page-12-30"></span><span id="page-12-0"></span>Barboza Jr. E. M., Alcaniz J. S., 2008, Phys. Lett., B666, 415
Basilakos S., Leon G., Papagiannopoulos G., Saridakis E. N., 2019, Phys. Rev., D100, 043524

<span id="page-12-12"></span>Bolotin Y. L., Kostenko A., Lemets O. A., Yerokhin D. A., 2015, International Journal of Modern Physics D, 24, 1530007

<span id="page-12-28"></span>Bowman J. D., Rogers A. E. E., Monsalve R. A., Mozdzen T. J., Mahesh N., 2018, Nature, 555, 67

<span id="page-12-11"></span>Caldera-Cabral G., Maartens R., Ureña López L. A., 2009, Phys. Rev. D, 79, 063518

<span id="page-12-6"></span>Caldwell R. R., 2002, Phys. Lett., B545, 23

<span id="page-12-5"></span>Caldwell R. R., Dave R., Steinhardt P. J., 1998, Phys. Rev. Lett., 80, 1582

<span id="page-12-23"></span>Capozziello S., Cardone V. F., Elizalde E., Nojiri S., Odintsov S. D., 2006a, Phys. Rev., D73, 043512

<span id="page-12-24"></span>Capozziello S., Nojiri S., Odintsov S. D., 2006b, Phys. Lett., B632, 597

<span id="page-12-55"></span><span id="page-12-3"></span>Chen X.-m., Gong Y.-g., Saridakis E. N., 2009, JCAP, 0904, 001 Chevallier M., Polarski D., 2001, Int. J. Mod. Phys., D10, 213

<span id="page-12-7"></span>Chiba T., Nakamura T., 1998, Progress of Theoretical Physics, 100, 1077

<span id="page-12-8"></span>Chiba T., Okabe T., Yamaguchi M., 2000, Phys. Rev., D62, 023511

<span id="page-12-42"></span>Cid A., Leon G., Leyva Y., 2016, JCAP, 1602, 027

<span id="page-12-32"></span>Cid A., Izaurieta F., Leon G., Medina P., Narbona D., 2018, JCAP, 1804, 041

<span id="page-12-54"></span>Coley A. A., 2003, Dynamical systems and cosmology. Vol. 291, Kluwer, Dordrecht, Netherlands, doi:10.1007/978-94-017-0327-7

<span id="page-12-38"></span>Coley A., Leon G., 2019, Gen. Rel. Grav., 51, 115

<span id="page-12-53"></span>Copeland E. J., Liddle A. R., Wands D., 1998, Phys. Rev., D57, 4686

<span id="page-12-25"></span>Copeland E. J., Sami M., Tsujikawa S., 2006, Int. J. Mod. Phys., D15, 1753

<span id="page-12-56"></span>Cotsakis S., Kittou G., 2013, Phys. Rev., D88, 083514

<span id="page-12-15"></span>Cruz N., Hernández-Almada A., Cornejo-Pérez O., 2019, Phys. Rev., D100, 083524

<span id="page-12-33"></span>De Arcia R., Gonzalez T., Leon G., Nucamendi U., Quiros I., 2016, Class. Quant. Grav., 33, 125036

<span id="page-12-36"></span>De Arcia R., Gonzalez T., Horta-Rangel F. A., Leon G., Nucamendi U., Quiros I., 2018, Class. Quant. Grav., 35, 145001

<span id="page-12-22"></span>Dhawan S., Brout D., Scolnic D., Goobar A., Riess A. G., Miranda V., 2020, Cosmological model insensitivity of local  $H_0$  from the Cepheid distance ladder (arXiv:2001.09260)

<span id="page-12-35"></span><span id="page-12-13"></span>Di Valentino E., Melchiorri A., Mena O., Vagnozzi S., 2019Dimakis N., Giacomini A., Jamal S., Leon G., Paliathanasis A.,2017, Phys. Rev., D95, 064031

<span id="page-12-46"></span><span id="page-12-45"></span>Fadragas C. R., Leon G., 2014, Class. Quant. Grav., 31, 195011Fadragas C. R., Leon G., Saridakis E. N., 2014, Class. Quant. Grav., 31, 075018

<span id="page-12-52"></span><span id="page-12-50"></span> Ferreira P. G., Joyce M., 1997, Phys. Rev. Lett., 79, 4740
 Foreman-Mackey D., Hogg D. W., Lang D., Goodman J., 2013, pasp, 125, 306

<span id="page-12-17"></span>García-Aspeitia M. A., Magaña J., Hernández-Almada A., Motta V., 2018a, International Journal of Modern Physics D, 27, 1850006

<span id="page-12-19"></span>García-Aspeitia M. A., Hernandez-Almada A., Magaña J., Amante M. H., Motta V., Martínez-Robles C., 2018b, Phys. Rev. D. 97, 101301

<span id="page-12-58"></span>García-Aspeitia M. A., Hernández-Almada A., Magaña J., Amante M. H., Motta V., Martínez-Robles C., 2018c, Phys. Rev., D97, 101301

<span id="page-12-60"></span>García-Aspeitia M. A., Hernández-Almada A., Magaña J., Motta V., 2019a

<span id="page-12-20"></span>García-Aspeitia M. A., Hernández-Almada A., Magaña J., Motta V., 2019b, arXiv e-prints, p. arXiv:1912.07500

<span id="page-12-18"></span>García-Aspeitia M. A., Martínez-Robles C., Hernández-Almada A., Magaña J., Motta V., 2019c, Phys. Rev. D, 99, 123525

<span id="page-12-34"></span>Giacomini A., Jamal S., Leon G., Paliathanasis A., Saavedra J., 2017, Phys. Rev., D95, 124060

<span id="page-12-43"></span>Giacomini A., Leon G., Paliathanasis A., Pan S., 2020

<span id="page-12-57"></span>Giambo R., Miritzis J., 2010, Class. Quant. Grav., 27, 095003

<span id="page-12-9"></span>Guo Z.-K., Piao Y.-S., Zhang X.-M., Zhang Y.-Z., 2005, Phys. Lett., B608, 177

<span id="page-12-59"></span>Haridasu B. S., Luković V. V., Moresco M., Vittorio N., 2018, Journal of Cosmology and Astroparticle Physics, 2018, 015

<span id="page-12-16"></span>Hernández-Almada A., 2019, The European Physical Journal C, 79, 751

<span id="page-12-21"></span>Hernández-Almada A., Magaña J., García-Aspeitia M. A., Motta V., 2019, European Physical Journal C, 79, 12

<span id="page-12-14"></span>Hernández-Almada A., García-Aspeitia M. A., Magana J., Motta V., 2020, Stability analysis and constraints on interacting viscous cosmology (arXiv:2001.08667)

<span id="page-12-27"></span>Holsclaw T., Alam U., Sansó B., Lee H., Heitmann K., Habib S., Higdon D., 2010, Phys. Rev. D, 82, 103502

<span id="page-12-4"></span>Jassal H. K., Bagla J. S., Padmanabhan T., 2005, Mon. Not. Roy. Astron. Soc., 356, L11

<span id="page-12-51"></span>Jesus J. F., Holanda R. F. L., Pereira S. H., 2018, J. Cosmology Astropart. Phys., 2018, 073

<span id="page-12-49"></span>Jimenez R., Loeb A., 2002, ApJ, 573, 37

<span id="page-12-31"></span>Karpathopoulos L., Basilakos S., Leon G., Paliathanasis A., Tsamparlis M., 2018, Gen. Rel. Grav., 50, 79

<span id="page-12-47"></span>Kofinas G., Leon G., Saridakis E. N., 2014, Class. Quant. Grav., 31, 175011

<span id="page-12-48"></span>Komatsu E., et. al. 2011, The Astrophysical Journal Supplement Series, 192, 18

<span id="page-12-29"></span>Koo H., Shafieloo A., Keeley R. E., L'Huillier B., 2020, arXiv e-prints, p. arXiv:2001.10887

<span id="page-12-37"></span>Latta J., Leon G., Paliathanasis A., 2016, JCAP, 1611, 051

<span id="page-12-40"></span>Lazkoz R., Leon G., 2006, Phys. Lett., B638, 303

<span id="page-12-41"></span>Lazkoz R., Leon G., Quiros I., 2007, Phys. Lett., B649, 103

<span id="page-12-44"></span>Leon G., 2009, Class. Quant. Grav., 26, 035008

<span id="page-12-39"></span>Leon G., Paliathanasis A., 2019, Eur. Phys. J., C79, 746

- <span id="page-13-24"></span>Leon G., Saridakis E. N., 2009, [JCAP,](http://dx.doi.org/10.1088/1475-7516/2009/11/006) 0911, 006
- <span id="page-13-22"></span>Leon G., Saridakis E. N., 2013, [JCAP,](http://dx.doi.org/10.1088/1475-7516/2013/03/025) 1303, 025
- <span id="page-13-30"></span>Leon G., Saridakis E. N., 2015, [JCAP,](http://dx.doi.org/10.1088/1475-7516/2015/04/031) 1504, 031
- <span id="page-13-28"></span>Leon G., Silva F. O. F., 2019
- <span id="page-13-29"></span>Leon G., Saavedra J., Saridakis E. N., 2013, [Class. Quant. Grav.,](http://dx.doi.org/10.1088/0264-9381/30/13/135001) 30, 135001
- <span id="page-13-26"></span>Leon G., Paliathanasis A., Morales-Mart´ınez J. L., 2018, [Eur.](http://dx.doi.org/10.1140/epjc/s10052-018-6225-y) [Phys. J.,](http://dx.doi.org/10.1140/epjc/s10052-018-6225-y) C78, 753
- <span id="page-13-23"></span>Leon G., Coley A., Paliathanasis A., 2020, [Annals Phys.,](http://dx.doi.org/10.1016/j.aop.2019.168002) 412, 168002
- <span id="page-13-27"></span>Le´on G., Paliathanasis A., Velazquez L. A., 2018
- <span id="page-13-12"></span>Li X., Shafieloo A., 2019, [ApJ,](http://dx.doi.org/10.3847/2041-8213/ab3e09) [883, L3](https://ui.adsabs.harvard.edu/abs/2019ApJ...883L...3L)
- <span id="page-13-13"></span>Li X., Shafieloo A., 2020, arXiv e-prints, [p. arXiv:2001.05103](https://ui.adsabs.harvard.edu/abs/2020arXiv200105103L)
- <span id="page-13-4"></span>Li M., Li X.-D., Wang S., Wang Y., 2011, [Commun. Theor. Phys.,](http://dx.doi.org/10.1088/0253-6102/56/3/24) 56, 525
- <span id="page-13-5"></span>Linder E. V., 2003, [Phys. Rev. Lett.,](http://dx.doi.org/10.1103/PhysRevLett.90.091301) 90, 091301
- <span id="page-13-35"></span>Liu Z., Miao H., 2020
- <span id="page-13-8"></span>Maga˜na J., Motta V., Cardenas V. H., Foex G., 2017, [Mon. Not.](http://dx.doi.org/10.1093/mnras/stx750) [Roy. Astron. Soc.,](http://dx.doi.org/10.1093/mnras/stx750) 469, 47
- <span id="page-13-32"></span>Maga˜na J., Amante M. H., Garc´ıa-Aspeitia M. A., Motta V., 2018, [Monthly Notices of the Royal Astronomical Society,](http://dx.doi.org/10.1093/mnras/sty260) 476, 1036
- <span id="page-13-31"></span>Moresco M., et al., 2012, [J. Cosmology Astropart. Phys.,](http://dx.doi.org/10.1088/1475-7516/2012/08/006) [2012,](https://ui.adsabs.harvard.edu/abs/2012JCAP...08..006M) [006](https://ui.adsabs.harvard.edu/abs/2012JCAP...08..006M)
- <span id="page-13-11"></span><span id="page-13-10"></span>Mortonson M., Hu W., Huterer D., 2009, [Physical Review D,](http://dx.doi.org/10.1103/physrevd.80.067301) 80 Ovg¨un A., Leon G., Maga˜na J., Jusufi K., 2018, ¨ [European Phys](http://dx.doi.org/10.1140/epjc/s10052-018-5936-4)[ical Journal C,](http://dx.doi.org/10.1140/epjc/s10052-018-5936-4) [78, 462](https://ui.adsabs.harvard.edu/abs/2018EPJC...78..462O)
- <span id="page-13-20"></span>Pan S., Yang W., Di Valentino E., Shafieloo A., Chakraborty S., 2019, arXiv e-prints, [p. arXiv:1907.12551](https://ui.adsabs.harvard.edu/abs/2019arXiv190712551P)
- <span id="page-13-34"></span>Perko L., 2000, Differential Equations and Dynamical Systems,

- Third Edition. Springer
- <span id="page-13-1"></span>Perlmutter S., Aldering G., Goldhaber G., Knop R. A., Nugent P., others Project T. S. C., 1999, The Astrophysical Journal, 517, 565
- <span id="page-13-25"></span>Pulgar G., Saavedra J., Leon G., Leyva Y., 2015, [JCAP,](http://dx.doi.org/10.1088/1475-7516/2015/05/046) 1505, 046
- <span id="page-13-0"></span>Riess A. G., Filippenko A. V., Challis P., Clocchiatti A., Diercks A., et al., 1998, The Astronomical Journal, 116, 1009
- <span id="page-13-18"></span>Riess A. G., Casertano S., Yuan W., Macri L. M., Scolnic D., 2019, [The Astrophysical Journal,](http://dx.doi.org/10.3847/1538-4357/ab1422) 876, 85
- <span id="page-13-9"></span>Rom´an-Garza J., Verdugo T., Maga˜na J., Motta V., 2019, [Euro](http://dx.doi.org/10.1140/epjc/s10052-019-7390-3)[pean Physical Journal C,](http://dx.doi.org/10.1140/epjc/s10052-019-7390-3) [79, 890](https://ui.adsabs.harvard.edu/abs/2019EPJC...79..890R)
- <span id="page-13-6"></span>Sendra I., Lazkoz R., 2012, [MNRAS,](http://dx.doi.org/10.1111/j.1365-2966.2012.20661.x) [422, 776](https://ui.adsabs.harvard.edu/abs/2012MNRAS.422..776S)
- <span id="page-13-17"></span>Sola Peracaula J., Gomez-Valent A., de Cruz P´erez J., 2019, [Phys.](http://dx.doi.org/10.1016/j.dark.2019.100311) [Dark Univ.,](http://dx.doi.org/10.1016/j.dark.2019.100311) 25, 100311
- <span id="page-13-14"></span>Tsujikawa S., 2011, Dark Energy: Investigation and Modeling. Springer Netherlands, Dordrecht, pp 331–402, [doi:10.1007/978-90-481-8685-3˙8,](http://dx.doi.org/10.1007/978-90-481-8685-3_8) [https://doi.org/10.](https://doi.org/10.1007/978-90-481-8685-3_8) [1007/978-90-481-8685-3\\_8](https://doi.org/10.1007/978-90-481-8685-3_8)
- <span id="page-13-15"></span>Tsujikawa S., 2013, Class. Quant. Grav., 30, 214003
- <span id="page-13-19"></span>Verde L., Treu T., Riess A. G., 2019, in Nature Astronomy 2019. ([arXiv:1907.10625](http://arxiv.org/abs/1907.10625)), [doi:10.1038/s41550-019-0902-0](http://dx.doi.org/10.1038/s41550-019-0902-0)
- <span id="page-13-33"></span>Wainwright J., Ellis G. F. R., 1997, Dynamical Systems in Cosmology. Cambridge University Press
- <span id="page-13-3"></span>Weinberg S., 1989, Reviews of Modern Physics, 61
- <span id="page-13-7"></span>Wetterich C., 1988, [Nuclear Physics B,](http://dx.doi.org/10.1016/0550-3213(88)90193-9) [302, 668](http://adsabs.harvard.edu/abs/1988NuPhB.302..668W)
- <span id="page-13-21"></span>Xu C., Saridakis E. N., Leon G., 2012, [JCAP,](http://dx.doi.org/10.1088/1475-7516/2012/07/005) 1207, 005
- <span id="page-13-2"></span>Zel'dovich Y. B., 1968, Soviet Physics Uspekhi, 11, 381
- <span id="page-13-16"></span>Zhao G.-B., Raveri M., et. al. 2017, [Nature Astronomy,](http://dx.doi.org/10.1038/s41550-017-0216-z) 1, 627–632