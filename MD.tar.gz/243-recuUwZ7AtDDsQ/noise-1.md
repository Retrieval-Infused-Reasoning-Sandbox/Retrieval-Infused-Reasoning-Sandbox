#### [Skip to main content](#page-1-0) [Cornell University](https://www.cornell.edu/)

We gratefully acknowledge support from the Simons Foundation, [member](https://info.arxiv.org/about/ourmembers.html) [institutions](https://info.arxiv.org/about/ourmembers.html), and all contributors. [Donate](https://info.arxiv.org/about/donate.html) > [astro-ph](file:///list/astro-ph/recent) > arXiv:2404.03002 [arxiv logo](file:///)

#### [Help](https://info.arxiv.org/help) | [Advanced Search](https://arxiv.org/search/advanced)

![](_page_0_Picture_4.jpeg)

[arXiv logo](https://arxiv.org/)

[Cornell University Logo](https://www.cornell.edu/)

![](_page_0_Picture_7.jpeg)

| header |    |  |
|--------|----|--|
| all    |    |  |
|        | GO |  |

![](_page_1_Picture_0.jpeg)

### **quick links**

- [Login](https://arxiv.org/login) •
- [Help Pages](https://info.arxiv.org/help) •
- [About](https://info.arxiv.org/about) •

# <span id="page-1-0"></span>**Astrophysics > Cosmology and Nongalactic Astrophysics**

**arXiv:2404.03002** (astro-ph) [Submitted on 3 Apr 2024 ([v1\)](https://arxiv.org/abs/2404.03002v1), last revised 4 Nov 2024 (this version, v3)]

# **Title:DESI 2024 VI: Cosmological Constraints from the Measurements of Baryon Acoustic Oscillations**

Authors:[DESI Collaboration:](https://arxiv.org/search/astro-ph?searchtype=author&query=DESI+Collaboration) [A. G. Adame](https://arxiv.org/search/astro-ph?searchtype=author&query=Adame,+A+G), [J. Aguilar](https://arxiv.org/search/astro-ph?searchtype=author&query=Aguilar,+J), [S. Ahlen](https://arxiv.org/search/astro-ph?searchtype=author&query=Ahlen,+S), [S. Alam,](https://arxiv.org/search/astro-ph?searchtype=author&query=Alam,+S) [D. M.](https://arxiv.org/search/astro-ph?searchtype=author&query=Alexander,+D+M) [Alexander,](https://arxiv.org/search/astro-ph?searchtype=author&query=Alexander,+D+M) [M. Alvarez,](https://arxiv.org/search/astro-ph?searchtype=author&query=Alvarez,+M) [O. Alves](https://arxiv.org/search/astro-ph?searchtype=author&query=Alves,+O), [A. Anand](https://arxiv.org/search/astro-ph?searchtype=author&query=Anand,+A), [U. Andrade,](https://arxiv.org/search/astro-ph?searchtype=author&query=Andrade,+U) [E. Armengaud](https://arxiv.org/search/astro-ph?searchtype=author&query=Armengaud,+E), [S.](https://arxiv.org/search/astro-ph?searchtype=author&query=Avila,+S) [Avila,](https://arxiv.org/search/astro-ph?searchtype=author&query=Avila,+S) [A. Aviles](https://arxiv.org/search/astro-ph?searchtype=author&query=Aviles,+A), [H. Awan,](https://arxiv.org/search/astro-ph?searchtype=author&query=Awan,+H) [B. Bahr-Kalus,](https://arxiv.org/search/astro-ph?searchtype=author&query=Bahr-Kalus,+B) [S. Bailey,](https://arxiv.org/search/astro-ph?searchtype=author&query=Bailey,+S) [C. Baltay](https://arxiv.org/search/astro-ph?searchtype=author&query=Baltay,+C), [A. Bault,](https://arxiv.org/search/astro-ph?searchtype=author&query=Bault,+A) [J.](https://arxiv.org/search/astro-ph?searchtype=author&query=Behera,+J) [Behera](https://arxiv.org/search/astro-ph?searchtype=author&query=Behera,+J), [S. BenZvi,](https://arxiv.org/search/astro-ph?searchtype=author&query=BenZvi,+S) [A. Bera](https://arxiv.org/search/astro-ph?searchtype=author&query=Bera,+A), [F. Beutler,](https://arxiv.org/search/astro-ph?searchtype=author&query=Beutler,+F) [D. Bianchi](https://arxiv.org/search/astro-ph?searchtype=author&query=Bianchi,+D), [C. Blake,](https://arxiv.org/search/astro-ph?searchtype=author&query=Blake,+C) [R. Blum,](https://arxiv.org/search/astro-ph?searchtype=author&query=Blum,+R) [S.](https://arxiv.org/search/astro-ph?searchtype=author&query=Brieden,+S) [Brieden,](https://arxiv.org/search/astro-ph?searchtype=author&query=Brieden,+S) [A. Brodzeller,](https://arxiv.org/search/astro-ph?searchtype=author&query=Brodzeller,+A) [D. Brooks,](https://arxiv.org/search/astro-ph?searchtype=author&query=Brooks,+D) [E. Buckley-Geer](https://arxiv.org/search/astro-ph?searchtype=author&query=Buckley-Geer,+E), [E. Burtin,](https://arxiv.org/search/astro-ph?searchtype=author&query=Burtin,+E) [R. Calderon,](https://arxiv.org/search/astro-ph?searchtype=author&query=Calderon,+R) [R.](https://arxiv.org/search/astro-ph?searchtype=author&query=Canning,+R) [Canning,](https://arxiv.org/search/astro-ph?searchtype=author&query=Canning,+R) [A. Carnero Rosell,](https://arxiv.org/search/astro-ph?searchtype=author&query=Rosell,+A+C) [R. Cereskaite](https://arxiv.org/search/astro-ph?searchtype=author&query=Cereskaite,+R), [J. L. Cervantes-Cota,](https://arxiv.org/search/astro-ph?searchtype=author&query=Cervantes-Cota,+J+L) [S. Chabanier](https://arxiv.org/search/astro-ph?searchtype=author&query=Chabanier,+S), [E. Chaussidon,](https://arxiv.org/search/astro-ph?searchtype=author&query=Chaussidon,+E) [J. Chaves-Montero](https://arxiv.org/search/astro-ph?searchtype=author&query=Chaves-Montero,+J), [S. Chen](https://arxiv.org/search/astro-ph?searchtype=author&query=Chen,+S), [X. Chen,](https://arxiv.org/search/astro-ph?searchtype=author&query=Chen,+X) [T. Claybaugh,](https://arxiv.org/search/astro-ph?searchtype=author&query=Claybaugh,+T) [S. Cole](https://arxiv.org/search/astro-ph?searchtype=author&query=Cole,+S), [A.](https://arxiv.org/search/astro-ph?searchtype=author&query=Cuceu,+A) [Cuceu,](https://arxiv.org/search/astro-ph?searchtype=author&query=Cuceu,+A) [T. M. Davis](https://arxiv.org/search/astro-ph?searchtype=author&query=Davis,+T+M), [K. Dawson,](https://arxiv.org/search/astro-ph?searchtype=author&query=Dawson,+K) [A. de la Macorra](https://arxiv.org/search/astro-ph?searchtype=author&query=de+la+Macorra,+A), [A. de Mattia](https://arxiv.org/search/astro-ph?searchtype=author&query=de+Mattia,+A), [N. Deiosso](https://arxiv.org/search/astro-ph?searchtype=author&query=Deiosso,+N), [A.](https://arxiv.org/search/astro-ph?searchtype=author&query=Dey,+A) [Dey,](https://arxiv.org/search/astro-ph?searchtype=author&query=Dey,+A) [B. Dey](https://arxiv.org/search/astro-ph?searchtype=author&query=Dey,+B), [Z. Ding](https://arxiv.org/search/astro-ph?searchtype=author&query=Ding,+Z), [P. Doel](https://arxiv.org/search/astro-ph?searchtype=author&query=Doel,+P), [J. Edelstein](https://arxiv.org/search/astro-ph?searchtype=author&query=Edelstein,+J), [S. Eftekharzadeh](https://arxiv.org/search/astro-ph?searchtype=author&query=Eftekharzadeh,+S), [D. J. Eisenstein](https://arxiv.org/search/astro-ph?searchtype=author&query=Eisenstein,+D+J), [A.](https://arxiv.org/search/astro-ph?searchtype=author&query=Elliott,+A) [Elliott,](https://arxiv.org/search/astro-ph?searchtype=author&query=Elliott,+A) [P. Fagrelius,](https://arxiv.org/search/astro-ph?searchtype=author&query=Fagrelius,+P) [K. Fanning,](https://arxiv.org/search/astro-ph?searchtype=author&query=Fanning,+K) [S. Ferraro](https://arxiv.org/search/astro-ph?searchtype=author&query=Ferraro,+S), [J. Ereza](https://arxiv.org/search/astro-ph?searchtype=author&query=Ereza,+J), [N. Findlay,](https://arxiv.org/search/astro-ph?searchtype=author&query=Findlay,+N) [B. Flaugher](https://arxiv.org/search/astro-ph?searchtype=author&query=Flaugher,+B), [A.](https://arxiv.org/search/astro-ph?searchtype=author&query=Font-Ribera,+A) [Font-Ribera,](https://arxiv.org/search/astro-ph?searchtype=author&query=Font-Ribera,+A) [D. Forero-Sánchez](https://arxiv.org/search/astro-ph?searchtype=author&query=Forero-S%C3%A1nchez,+D), [J. E. Forero-Romero,](https://arxiv.org/search/astro-ph?searchtype=author&query=Forero-Romero,+J+E) [C. S. Frenk](https://arxiv.org/search/astro-ph?searchtype=author&query=Frenk,+C+S), [C. Garcia-](https://arxiv.org/search/astro-ph?searchtype=author&query=Garcia-Quintero,+C)[Quintero](https://arxiv.org/search/astro-ph?searchtype=author&query=Garcia-Quintero,+C), [E. Gaztañaga](https://arxiv.org/search/astro-ph?searchtype=author&query=Gazta%C3%B1aga,+E), [H. Gil-Marín](https://arxiv.org/search/astro-ph?searchtype=author&query=Gil-Mar%C3%ADn,+H), [S. Gontcho A Gontcho,](https://arxiv.org/search/astro-ph?searchtype=author&query=Gontcho,+S+G+A) [A. X. Gonzalez-](https://arxiv.org/search/astro-ph?searchtype=author&query=Gonzalez-Morales,+A+X)[Morales](https://arxiv.org/search/astro-ph?searchtype=author&query=Gonzalez-Morales,+A+X), [V. Gonzalez-Perez,](https://arxiv.org/search/astro-ph?searchtype=author&query=Gonzalez-Perez,+V) [C. Gordon](https://arxiv.org/search/astro-ph?searchtype=author&query=Gordon,+C), [D. Green](https://arxiv.org/search/astro-ph?searchtype=author&query=Green,+D), [D. Gruen,](https://arxiv.org/search/astro-ph?searchtype=author&query=Gruen,+D) [R. Gsponer](https://arxiv.org/search/astro-ph?searchtype=author&query=Gsponer,+R), [G.](https://arxiv.org/search/astro-ph?searchtype=author&query=Gutierrez,+G) [Gutierrez,](https://arxiv.org/search/astro-ph?searchtype=author&query=Gutierrez,+G) [J. Guy](https://arxiv.org/search/astro-ph?searchtype=author&query=Guy,+J), [B. Hadzhiyska,](https://arxiv.org/search/astro-ph?searchtype=author&query=Hadzhiyska,+B) [C. Hahn,](https://arxiv.org/search/astro-ph?searchtype=author&query=Hahn,+C) [M. M. S Hanif](https://arxiv.org/search/astro-ph?searchtype=author&query=Hanif,+M+M+S), [H. K. Herrera-](https://arxiv.org/search/astro-ph?searchtype=author&query=Herrera-Alcantar,+H+K)[Alcantar](https://arxiv.org/search/astro-ph?searchtype=author&query=Herrera-Alcantar,+H+K), [K. Honscheid](https://arxiv.org/search/astro-ph?searchtype=author&query=Honscheid,+K), [C. Howlett](https://arxiv.org/search/astro-ph?searchtype=author&query=Howlett,+C), [D. Huterer](https://arxiv.org/search/astro-ph?searchtype=author&query=Huterer,+D), [V. Iršič,](https://arxiv.org/search/astro-ph?searchtype=author&query=Ir%C5%A1i%C4%8D,+V) [M. Ishak](https://arxiv.org/search/astro-ph?searchtype=author&query=Ishak,+M), [S. Juneau](https://arxiv.org/search/astro-ph?searchtype=author&query=Juneau,+S), [N.](https://arxiv.org/search/astro-ph?searchtype=author&query=Kara%C3%A7ayl%C4%B1,+N+G) [G. Karaçaylı](https://arxiv.org/search/astro-ph?searchtype=author&query=Kara%C3%A7ayl%C4%B1,+N+G), [R. Kehoe](https://arxiv.org/search/astro-ph?searchtype=author&query=Kehoe,+R), [S. Kent](https://arxiv.org/search/astro-ph?searchtype=author&query=Kent,+S), [D. Kirkby](https://arxiv.org/search/astro-ph?searchtype=author&query=Kirkby,+D), [A. Kremin](https://arxiv.org/search/astro-ph?searchtype=author&query=Kremin,+A), [A. Krolewski,](https://arxiv.org/search/astro-ph?searchtype=author&query=Krolewski,+A) [Y. Lai](https://arxiv.org/search/astro-ph?searchtype=author&query=Lai,+Y), [T.-W.](https://arxiv.org/search/astro-ph?searchtype=author&query=Lan,+T) [Lan,](https://arxiv.org/search/astro-ph?searchtype=author&query=Lan,+T) [M. Landriau,](https://arxiv.org/search/astro-ph?searchtype=author&query=Landriau,+M) [D. Lang,](https://arxiv.org/search/astro-ph?searchtype=author&query=Lang,+D) [J. Lasker,](https://arxiv.org/search/astro-ph?searchtype=author&query=Lasker,+J) [J.M. Le Goff](https://arxiv.org/search/astro-ph?searchtype=author&query=Goff,+J+L) [et al. \(103 additional authors](javascript:toggleAuthorList() [not shown\)](javascript:toggleAuthorList() You must enable JavaScript to view entire author list. [View PDF](file:///pdf/2404.03002) [HTML \(experimental\)](https://arxiv.org/html/2404.03002v3)

Abstract:We present cosmological results from the measurement of baryon acoustic oscillations (BAO) in galaxy, quasar and Lyman-\$ \alpha\$ forest tracers from the first year of observations from the Dark Energy Spectroscopic Instrument (DESI), to be released in the DESI Data Release 1. DESI BAO provide robust measurements of the transverse comoving distance and Hubble rate, or their combination, relative to the sound horizon, in seven redshift bins from over 6 million extragalactic objects in the redshift range \$0.1<z<4.2\$. DESI BAO data alone are consistent with the standard flat \$\Lambda\$CDM cosmological model with a matter density \$\Omega\_\mathrm{m}=0.295\pm 0.015\$. Paired with a BBN prior and the robustly measured acoustic angular scale from the CMB, DESI requires \$H\_0=(68.52\pm0.62)\$ km/s/Mpc. In conjunction with CMB anisotropies from Planck and CMB lensing data from Planck and ACT, we find \$\Omega\_\mathrm{m} =0.307\pm 0.005\$ and \$H\_0=(67.97\pm0.38)\$ km/s/Mpc. Extending the baseline model with a constant dark energy equation of state parameter \$w\$, DESI BAO alone require \$w=-0.99^{+0.15}\_{-0.13}\$. In models with a time-varying dark energy equation of state parametrized by \$w\_0\$ and \$w\_a\$, combinations of DESI with CMB or with SN~Ia individually prefer \$w\_0>-1\$ and \$w\_a<0\$. This preference is 2.6\$\sigma\$ for the DESI+CMB combination, and persists or grows when SN~Ia are added in, giving results discrepant with the \$\Lambda\$CDM model at the \$2.5\sigma\$, \$3.5\sigma\$ or \$3.9\sigma\$ levels for the addition of Pantheon+, Union3, or DES-SN5YR datasets respectively. For the flat \$\Lambda\$CDM model with the sum of neutrino mass \$\sum m\_\nu\$ free, combining the DESI and CMB data yields an upper limit \$\sum m\_\nu < 0.072\$ \$(0.113)\$ eV at 95% confidence for a \$\sum m\_\nu>0\$ \$(\sum m\_\nu>0.059)\$ eV prior. These neutrino-mass constraints are substantially relaxed in models beyond \$\Lambda\$CDM. [Abridged.]

This DESI Collaboration Key Publication is part of the 2024

publication series using the first year of observations (see [this https URL](https://data.desi.lbl.gov/doc/papers)). 68 pages, 15 figures. Version accepted for

publication in JCAP

Subjects: Cosmology and Nongalactic Astrophysics (astro-ph.CO)

Cite as: [arXiv:2404.03002](https://arxiv.org/abs/2404.03002) [astro-ph.CO]

Comments:

(or [arXiv:2404.03002v3](https://arxiv.org/abs/2404.03002v3) [astro-ph.CO] for this version)

#### <https://doi.org/10.48550/arXiv.2404.03002>

Focus to learn more

arXiv-issued DOI via DataCite

Journal reference: JCAP 02 (2025) 021

<https://doi.org/10.1088/1475-7516/2025/02/021>

Focus to learn more

Related DOI:

DOI(s) linking to related resources

### **Submission history**

From: Mustapha Ishak [[view email](file:///show-email/e7b4710d/2404.03002)]

**[\[v1\]](file:///abs/2404.03002v1)** Wed, 3 Apr 2024 18:41:51 UTC (5,348 KB) **[\[v2\]](file:///abs/2404.03002v2)** Wed, 24 Apr 2024 17:17:34 UTC (5,740 KB) **[v3]** Mon, 4 Nov 2024 16:43:36 UTC (5,075 KB)

Full-text links:

### **Access Paper:**

- [View PDF](file:///pdf/2404.03002) •
- [HTML \(experimental\)](https://arxiv.org/html/2404.03002v3) •
- [TeX Source](file:///src/2404.03002) •
- [Other Formats](file:///format/2404.03002) •

[view license](http://creativecommons.org/licenses/by/4.0/)

Current browse context: astro-ph.CO [< prev](file:///prevnext?id=2404.03002&function=prev&context=astro-ph.CO) | [next >](file:///prevnext?id=2404.03002&function=next&context=astro-ph.CO)

[new](file:///list/astro-ph.CO/new) | [recent](file:///list/astro-ph.CO/recent) | [2024-04](file:///list/astro-ph.CO/2024-04) Change to browse by: [astro-ph](file:///abs/2404.03002?context=astro-ph)

#### **References & Citations**

- [INSPIRE HEP](https://inspirehep.net/arxiv/2404.03002) •
- [NASA ADS](https://ui.adsabs.harvard.edu/abs/arXiv:2404.03002) •
- [Google Scholar](https://scholar.google.com/scholar_lookup?arxiv_id=2404.03002) •
- [Semantic Scholar](https://api.semanticscholar.org/arXiv:2404.03002) •

#### **[4 blog links](file:///tb/2404.03002)**

([what is this?\)](https://info.arxiv.org/help/trackback.html) export BibTeX citation

#### **Bookmark**

[BibSonomy logo](http://www.bibsonomy.org/BibtexHandler?requTask=upload&url=https://arxiv.org/abs/2404.03002&description=DESI%202024%20VI:%20Cosmological%20Constraints%20from%20the%20Measurements%20of%20Baryon%20Acoustic%20Oscillations) [Reddit logo](https://reddit.com/submit?url=https://arxiv.org/abs/2404.03002&title=DESI%202024%20VI:%20Cosmological%20Constraints%20from%20the%20Measurements%20of%20Baryon%20Acoustic%20Oscillations)

Bibliographic Tools

## **Bibliographic and Citation Tools**

| Bibliographic Explorer Toggle                            |
|----------------------------------------------------------|
| Bibliographic Explorer<br>(What is the Explorer?)        |
|                                                          |
| Connected Papers Toggle                                  |
| Connected Papers<br>(What is Connected Papers?)          |
| Litmaps Toggle                                           |
| Litmaps<br>(What is Litmaps?)                            |
|                                                          |
| scite.ai Toggle                                          |
| scite Smart Citations<br>(What are Smart Citations?)     |
|                                                          |
|                                                          |
| Code, Data, Media                                        |
|                                                          |
|                                                          |
| Code, Data and Media Associated                          |
| with this Article                                        |
|                                                          |
|                                                          |
|                                                          |
|                                                          |
| alphaXiv Toggle<br>alphaXiv<br>(What is alphaXiv?)       |
|                                                          |
| Links to Code Toggle                                     |
| CatalyzeX Code Finder for Papers<br>(What is CatalyzeX?) |
|                                                          |
| DagsHub Toggle<br>DagsHub<br>(What is DagsHub?)          |
|                                                          |
| GotitPub Toggle                                          |
| Gotit.pub<br>(What is GotitPub?)                         |
|                                                          |
| Huggingface Toggle                                       |
| Hugging Face<br>(What is Huggingface?)                   |
| Links to Code Toggle                                     |
| Papers with Code<br>(What is Papers with Code?)          |
| ScienceCast Toggle                                       |

| Demos |  |
|-------|--|

## **Demos**

| Replicate Toggle                         |
|------------------------------------------|
| Replicate<br>(What is Replicate?)        |
|                                          |
| Spaces Toggle                            |
| Hugging Face Spaces<br>(What is Spaces?) |
|                                          |
| Spaces Toggle                            |
| TXYZ.AI<br>(What is TXYZ.AI?)            |
|                                          |
| Related Papers                           |

## **Recommenders and Search Tools**

| Link to Influence Flower                          |
|---------------------------------------------------|
| Influence Flower<br>(What are Influence Flowers?) |
| Core recommender toggle                           |
| CORE Recommender<br>(What is CORE?)               |
| IArxiv recommender toggle                         |
| IArxiv Recommender<br>(What is IArxiv?)           |
| About arXivLabs                                   |

# **arXivLabs: experimental projects with community collaborators**

arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.

Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.

Have an idea for a project that will add value for arXiv's community? **[Learn](https://info.arxiv.org/labs/index.html) [more about arXivLabs](https://info.arxiv.org/labs/index.html)**.

![](_page_6_Picture_0.jpeg)

[Which authors of this paper are endorsers?](file:///auth/show-endorsers/2404.03002) | [Disable MathJax](javascript:setMathjaxCookie()) [\(What is](https://info.arxiv.org/help/mathjax.html) [MathJax?\)](https://info.arxiv.org/help/mathjax.html)

[About](https://info.arxiv.org/about)

![](_page_7_Picture_1.jpeg)

[Contact](https://info.arxiv.org/help/contact.html)

![](_page_8_Picture_0.jpeg)

[Subscribe](https://info.arxiv.org/help/subscribe)

[Copyright](https://info.arxiv.org/help/license/index.html)

[Privacy Policy](https://info.arxiv.org/help/policies/privacy_policy.html)

[Web Accessibility Assistance](https://info.arxiv.org/help/web_accessibility.html)

#### [arXiv Operational Status](https://status.arxiv.org)

![](_page_10_Picture_0.jpeg)

![](_page_11_Picture_1.jpeg)

[email](https://subscribe.sorryapp.com/24846f03/email/new) or

![](_page_12_Picture_0.jpeg)

[slack](https://subscribe.sorryapp.com/24846f03/slack/new)