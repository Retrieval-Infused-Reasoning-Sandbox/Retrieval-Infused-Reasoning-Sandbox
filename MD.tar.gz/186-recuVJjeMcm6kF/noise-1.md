![](_page_0_Picture_1.jpeg)

**CERN-PH-TH/2010-090**

# **Simulating QCD at finite density**

## **Philippe de Forcrand**∗

*Institute for Theoretical Physics, ETH Zürich, CH-8093 Zürich, Switzerland and*

*CERN, Physics Department, TH Unit, CH-1211 Geneva 23, Switzerland E-mail:* [forcrand@phys.ethz.ch](mailto:forcrand@phys.ethz.ch)

In this review, I recall the nature and the inevitability of the "sign problem" which plagues attempts to simulate lattice QCD at finite baryon density. I present the main approaches used to circumvent the sign problem at small chemical potential. I sketch how one can predict analytically the severity of the sign problem, as well as the numerically accessible range of baryon densities. I review progress towards the determination of the pseudo-critical temperature *Tc*(µ), and towards the identification of a possible QCD critical point. Some promising advances with non-standard approaches are reviewed.

*The XXVII International Symposium on Lattice Field Theory - LAT2009 July 26-31 2009 Peking University, Beijing, China*

∗Speaker.

<span id="page-1-0"></span>![](_page_1_Figure_1.jpeg)

**Figure 1:** Conjectured phase diagram of QCD as a function of quark chemical potential µ and temperature *T*, from Wikipedia.

## **1. Introduction**

Just like with water, the form taken by quark matter depends on its temperature and its density, or equivalently the chemical potential coupled to the quark number. In fact, one should consider distinct, possibly different chemical potentials coupled to the densities of *u*,*d*, and *s* quarks which are separately conserved by the strong interactions, giving in total a 4-dimensional parameter space with a rich phase diagram. A conjectured two-dimensional (µ,*T*) section (where the requirements of electric neutrality and of beta-equilibrium reduce the three chemical potentials to a single combination) is proposed Fig. 1, taken from a popular reference. The behaviour of QCD in some limiting cases (high *T* or large µ) can be predicted from perturbation theory thanks to asymptotic freedom, and the *T* ≥ 0,<sup>µ</sup> = 0 properties have been well studied on the lattice. Otherwise, almost all of the phase diagram Fig. 1 is based on educated guesses awaiting validation. Putting this phase diagram on a firm basis is obviously of fundamental importance.

The QCD phase diagram follows from the non-perturbative properties of the QCD Lagrangian, and can in principle be determined unambiguously by lattice simulations. Unfortunately, standard Monte Carlo simulations can only be applied to the <sup>µ</sup> = 0 vertical axis in Fig. 1. As is well-known, for <sup>µ</sup> 6= 0 the simulations are plagued by the "sign problem". The purpose of this review is to explain the origin and the nature of the sign problem, and to report on recent progress towards circumventing it. I have tried both to start from elementary considerations and to cover some very recent, promising developments. This has forced me to skip reviewing some new work presented at this Conference, for which I apologize.

### <span id="page-2-0"></span>2. Sign problem

The sign problem is a necessary evil, unavoidable as soon as one integrates out the fermion fields and expresses the partition function in terms of the gauge fields. Analytic integration over each fermion species gives a factor  $\det(D + m + \mu \gamma_0)$ , where D is the massless Dirac operator and the last term appears when the chemical potential  $\mu$  is non-zero. Now, D satisfies  $\gamma_5$ -hermiticity:  $\gamma_5 D \gamma_5 = D^{\dagger}$ , so that

$$\gamma_5(\cancel{D} + m + \mu \gamma_0)\gamma_5 = \cancel{D}^{\dagger} + m - \mu \gamma_0 = (\cancel{D} + m - \mu^* \gamma_0)^{\dagger}$$
(2.1)

Taking the determinant on both sides gives  $\det(\not D + m + \mu \gamma_0) = \det^*(\not D + m - \mu^* \gamma_0)$ , which constrains the determinant to be real only if  $\mu$  is zero or pure imaginary. In such case, an even number of degenerate flavors (same m, same  $\mu$ ) yields a non-negative factor in the integration measure over the gauge fields, and standard Monte Carlo techniques apply. The same is true for pairs of flavors with opposite, real  $\mu$ , i.e. isospin chemical potential.

In the general case, the determinant may be complex, and in fact it *must* be complex to produce the expected physics. This can be seen by considering the free energy of a static color charge or anti-charge, respectively related to the expectation value of the Polyakov loop or its adjoint. Denoting by  $d\varpi$  the integration measure which includes the determinant, one sees that

$$\langle \text{Tr Polyakov} \rangle = \exp(-\frac{1}{T}F_q) = \int \text{Re}(\text{Polyakov}) \times \text{Re}(d\varpi) - \text{Im}(\text{Polyakov}) \times \text{Im}(d\varpi)$$
 (2.2)

$$\langle \operatorname{Tr} \operatorname{Polyakov}^* \rangle = \exp(-\frac{1}{T}F_q^-) = \int \operatorname{Re}(\operatorname{Polyakov}) \times \operatorname{Re}(d\varpi) + \operatorname{Im}(\operatorname{Polyakov}) \times \operatorname{Im}(d\varpi) \quad (2.3)$$

Different free energies  $F_q$  and  $F_{\overline{q}}$ , as happens when a chemical potential favors charge over anticharge, can only be obtained if  $\text{Im}(d\overline{\varpi}) \neq 0$ , i.e. with a complex measure<sup>1</sup>.

A corollary of the above statement is that any Monte Carlo ensemble (which is sampled using a real non-negative measure) has average baryon number zero (or pure imaginary). So the direct sampling of a finite-density ensemble is not possible. Three main approaches have been pursued towards circumventing this difficulty: reweighting, Taylor expansion and analytic continuation from imaginary  $\mu$ . I will review them in succession, emphasizing their application to the determination of the pseudo-critical temperature  $T_c(\mu)$  and of the QCD critical point.

#### 3. Reweighting

#### 3.1 General results

Let me first illustrate the problem in a toy model. Consider the "partition function"  $Z(\lambda) \equiv \int_{-\infty}^{+\infty} dx \exp(-x^2 + i\lambda x)$ . Since  $Z(\lambda)$  is real, we can focus on the real part of the integrand, shown Fig. 2. While the important values of x are clearly near zero when  $\lambda = 0$ , this is no longer true when  $\lambda \neq 0$ . Large cancellations take place, and integration far into the tail of the distribution is needed to obtain the analytic result  $Z(\lambda)/Z(0) = \exp(-\lambda^2/4)$ . The size of the "important" integration region is governed by  $\lambda$ , not by the width of the  $\lambda = 0$  Gaussian. The situation is similar in QCD, where

<sup>&</sup>lt;sup>1</sup>In the SU(2),  $N_f = 2$  case, the square of the determinant remains real positive even when  $\mu \neq 0$ . But the baryonic chemical potential can be turned into an isospin chemical potential by a redefinition of the quark fields.

<span id="page-3-0"></span>![](_page_3_Figure_1.jpeg)

**Figure 2:** Toy example of an oscillatory integrand: "every *x* is important".

configurations suppressed by  $\mathcal{O}(\exp(-\text{Volume}))$  must be properly summed over, as stressed most forcefully by Splittorff and collaborators [1]. Loosely speaking, "every configuration is important", and it is not even clear how to sample them.

In general, one may ask the question: given a real, oscillatory integrand f(x), what is the optimal weight  $g(x) \ge 0$  which should be used for sampling? Uniform sampling is not the answer, since it is clearly wasteful to sample regions where |f(x)| is zero or very small. A precise answer can be obtained by considering how one forms the expectation value  $\langle W \rangle_f$  of a general observable W in the desired, target ensemble with partition function  $Z_f = \int dx \, f(x)$ :

$$\langle W \rangle_f = \frac{\int dx \, W(x) f(x)}{\int dx \, f(x)} = \frac{\int dx \, W(x) \frac{f(x)}{g(x)} g(x)}{\int dx \, \frac{f(x)}{g(x)} g(x)} = \frac{\langle W \frac{f}{g} \rangle_g}{\langle \frac{f}{g} \rangle_g}$$
(3.1)

This is the strategy of *reweighting*: successive measurements of W, obtained from ordinary Monte Carlo sampling of the auxiliary partition function  $Z_g = \int dx \ g(x)$ ,  $g(x) \ge 0$ , are given a varying, oscillatory weight f/g in the ensemble average. The denominator  $\langle \frac{f}{g} \rangle_g = Z_f/Z_g$  is called the "average sign". As we will see shortly, it becomes exponentially small as the volume is increased. In addition, the relative error on the average sign propagates to every observable W. Therefore, g(x) should be chosen so as to minimize the relative variance of f/g. In the limit where the average sign tends to zero, the solution is g(x) = |f(x)| (up to an arbitrary multiplicative constant) [2]. Then, each measurement of the reweighting factor f/g gives  $\pm 1$ , and  $Z_g$  is often called the "sign quenched" ensemble.

Since the average sign is a ratio of two partition functions, it can be rewritten as

$$\left\langle \frac{f}{g} \right\rangle_g = \frac{Z_f}{Z_g} \underset{V \to \infty}{=} \exp\left(-\frac{V}{T}\Delta f(T,\lambda)\right)$$
 (3.2)

for a system of volume V at temperature T, where  $\Delta f$  is the free energy density difference between the two ensembles, which depends on the temperature and the couplings of the theory ( $\mu$ 

<span id="page-4-0"></span>![](_page_4_Figure_1.jpeg)

Figure 3: Left: Sketch of the QCD pseudo-critical line  $T_c(\mu)$  (in red), starting from  $\sim m_N/3$  at T=0, superimposed with the phase transition line (in blue) of the phase-quenched theory (alias isospin chemical potential), starting from  $m_\pi/2$  at T=0. Bose-Einstein condensation of charged pions in the phase-quenched ensemble causes a severe sign problem. Right: Comparison of values of the "average phase factor"  $\langle \exp(2i\theta) \rangle$ , measured in lattice simulations and predicted by one-loop chiral perturbation theory [5]. Good agreement persists up to  $T/T_c \sim 0.90$ .

for QCD). This makes clear the dependence of the average sign on the volume. To maintain statistical accuracy, the number of independent measurements must grow as  $\exp(+2\frac{V}{T}\Delta f(T,\lambda))$ , i.e., exponentially fast with V.

#### 3.2 Reweighting for QCD

For QCD, the optimal choice of Monte Carlo probability is therefore  $|\text{Re}(\det(\mu)^{N_f})|$  [2, 3]. However, this expression cannot be recast, as customary, into a Gaussian integral for further stochastic estimation. This causes a considerable  $\mathcal{O}(V^2)$  computational overhead. A more appropriate choice is the "phase quenched" ensemble with probability  $|\det(\mu)^{N_f}|$ . Given eq. (2.1), this can be rewritten as  $\det(+\mu)^{N_f/2}\det(-\mu)^{N_f/2}$ , corresponding to an isospin chemical potential applied to  $N_f/2$  pairs of flavors (i,j). This latter form can be readily recast into a Gaussian integral and sampled with the usual Rational Hybrid Monte Carlo. However, the chemical potential is now coupled to all  $q_i q_j$  mesons. The lightest among those, the charged pions  $u\gamma_5 d$  (using  $N_f = 2$  notation), undergo Bose-Einstein condensation when  $\mu > \mu_c(T)$ , with  $\mu_c(T=0) = m_\pi/2$ , as illustrated Fig. 3 left. Then, the physics of the auxiliary Monte Carlo ensemble differs qualitatively from that of the target baryonic- $\mu$  ensemble, which causes  $\Delta f$  in eq. (3.2) to become large: the sign problem becomes severe.

Remarkably, the average sign is mostly determined by the physics of pions, for which chiral perturbation theory, or even random matrix theory, provides an accurate analytic description provided  $T \ll m_{\pi}$  and  $\mu \ll m_{\rho}/2$ . A convenient observable to study is the "average phase factor"  $\langle \exp(2i\theta) \rangle = \frac{Z(+\mu,+\mu)}{Z(+\mu,-\mu)} = \langle \frac{\det(\mu)^2}{|\det(\mu)|^2} \rangle_{||}$ , where  $Z(+\mu,+\mu)$  is the target ensemble with chemical potential  $\mu$ ,  $Z(+\mu,-\mu)$  is the auxiliary Monte Carlo ensemble with isospin chemical potential, and  $\langle ... \rangle_{||}$  is an expectation value with respect to the latter. The observable  $\langle \exp(2i\theta) \rangle$  measures the

<span id="page-5-0"></span>![](_page_5_Figure_1.jpeg)

**Figure 4:** *Left*: QCD phase diagram from [[7\]](#page-19-0) obtained by combined reweighting in <sup>µ</sup> and β of the <sup>µ</sup> = 0,β = β*<sup>c</sup>* ensemble (blue dot). *Middle*: corresponding smallest Lee-Yang zero imaginary part (related to the inverse of the specific heat) extrapolated to the thermodynamic limit. *Right*: full data illustrating the insensitivity to µ followed by an abrupt change, courtesy of Z. Fodor.

effect of changing the chemical potential from +<sup>µ</sup> to −<sup>µ</sup> for half of the quark flavors, or equivalently the corresponding fermion boundary conditions in Euclidean time. It is thus ultra-violet finite and can be estimated using continuum chiral perturbation theory. Comparison between analytic and numerical lattice QCD results shows good agreement, even at rather high temperatures not far from *T<sup>c</sup>* [\[5\]](#page-19-0): see Fig. [3](#page-4-0) *right*.

Pion condensation is a consequence of choosing to sample a Monte Carlo ensemble with isospin chemical potential. One may wonder if the severe sign problem could not be avoided with another choice of Monte Carlo ensemble, e.g., <sup>µ</sup> = 0. However, it is still because of the *phase* of the reweighting factor that pion condensation for <sup>µ</sup> > *m*π/2 does not occur. Additional fluctuations in its magnitude only cause the evaluation of the average sign to be even more noisy, and the sign problem even more severe. In addition, a pernicious effect occurs: the distribution of the reweighting factor becomes broader and non-Gaussian, which makes the analysis of the statistical error less reliable. Moreover, the necessarily finite Monte Carlo sample may contain zero configurations in the region which is most important for the target ensemble. This leads to wrong results, because the underestimated statistical error does not reflect the large deviation from the correct answer. Failure of reweighting may go undetected, as in the unfortunate "Glasgow method" [[6](#page-19-0)].

In spite of these difficulties, reweighting has produced a landmark result [\[7\]](#page-19-0), with a determination of the pseudo-critical temperature *Tc*(µ) and of a critical point (see Fig. 4) for QCD with physical quark masses, on an *N<sup>t</sup>* = 4 (4 time-slices, *a* ∼ 0.3 fm) lattice. The Monte Carlo ensemble chosen, (<sup>µ</sup> = 0,β = β*c*(<sup>µ</sup> = 0)), was sub-optimal, yet vastly superior to the earlier "Glasgow method" which kept β fixed [[6](#page-19-0)]. Still, one may question whether the statistical error, which one would expect to grow exponentially with µ 2 , is reliably evaluated. Doubts are fueled by the observation of [\[8](#page-19-0)] that the critical point is located near the estimated boundary to the pion-condensed phase (Fig. [3](#page-4-0) *left*), and that the system appears insensitive to µ until very close to the critical point (Fig. 4, right). Six years onward, this issue is still not settled, in spite of the authors' own efforts to devise a more reliable error estimation [[9\]](#page-19-0), and doubts about the determination of the critical point linger on.

Progress is continuing in the analytic estimation of the average sign. Recent work includes the influence of the topological sector at finite µ [\[12](#page-19-0)], and the determination of the *distribution* of the phase of the determinant, as well as its correlation with various observables like the baryon

<span id="page-6-0"></span>![](_page_6_Figure_1.jpeg)

![](_page_6_Figure_2.jpeg)

**Figure 5:** Isolines of the average sign in the (µ,*T*) plane for a random matrix model [[10\]](#page-19-0) and in the (density, β) plane for *N<sup>f</sup>* = 8 simulations [\[11](#page-19-0)].

number [\[13](#page-19-0)]. Even a random matrix model with a critical point [[10](#page-19-0)] gives a description of the sign problem roughly consistent with numerical reweighting [\[11](#page-19-0)]: compare Fig. 5 *left* and *right*. One should note that pion interactions do not play a major role in the determination of the average sign. On the other hand, taking the baryons into account improves the description (and turns out to make the sign problem less severe). This can be accomplished by describing the two systems (baryonic-µ and isospin-µ) by a non-interacting hadron resonance gas. A fit of lattice simulation results to such an ansatz [[14\]](#page-20-0) works well. Interestingly, one can then in turn *predict* the maximum baryon number which can be included in a lattice by reweighting, for an average sign of, say, 0.1 or greater. For practical lattice sizes, this number is O(10) (and decreases for lighter quarks), which is barely sufficient for a statistical treatment.

## **4. Taylor expansion**

As we have seen, reweighting is limited to small volumes, and its breakdown is difficult to detect. It may be more useful and efficient to try and determine, in the thermodynamic limit, the first few Taylor coefficients in the expansion of an arbitrary observable in powers of <sup>µ</sup>/*T* about <sup>µ</sup> = 0. In particular, one may consider the pressure *P*(*T*,µ), since all thermodynamic properties can be extracted from its derivatives. Defining ∆*P*(*T*,µ) ≡ *P*(*T*,µ)−*P*(*T*,<sup>µ</sup> = 0), one expands

$$\frac{\Delta P(T,\mu)}{T^4} = \sum_{k=1}^{\infty} c_{2k}(T) \left(\frac{\mu}{T}\right)^{2k} \tag{4.1}$$

$$c_{2k} = \langle \text{Tr}(\text{degree } 2k \text{ polynomial in } \cancel{D}^{-1}, \frac{\partial \cancel{D}}{\partial \mu}) \rangle_{\mu=0}$$
 (4.2)

where the Taylor coefficients *c*2*<sup>k</sup>* can be expressed as expectation values of traces of matrix polynomials in the <sup>µ</sup> = 0 ensemble. The trace of each monomial can then be estimated by the standard stochastic averaging over "noise vectors". This strategy looks straightforward, and indeed works well at low orders: see Fig. [6](#page-7-0) [[15](#page-20-0)]. Notice however how the statistical errors grow with the Taylor order. Since one must go to higher order as µ is increased, to keep the truncation error of the Taylor expansion under control, an essential practical question is: how does the work increase with the order *k* ?

The answer has several parts, and a full complexity analysis has not been carried out yet:

- The number of terms in the degree 2*<sup>k</sup>* polynomial grows approximately as 62*<sup>k</sup>* [\[16](#page-20-0)].
- The Taylor coefficient *c*2*<sup>k</sup>* has a finite thermodynamic limit, but the monomials in eq. (4.2) grow

<span id="page-7-0"></span>![](_page_7_Figure_1.jpeg)

**Figure 6:** First three coefficients in the Taylor expansion of the QCD pressure eq. [\(4.1\)](#page-6-0) versus *T*/*T<sup>c</sup>* [[15\]](#page-20-0).

as *V* 2*k* , implying large cancellations, which can only be controlled by a large (exponential in *k*) increase with *V* in the number of noise vectors. This is where the complexity ∼ exp(*V*) of the reweighting approach resurfaces. After all, the underlying strategy is an extrapolation in µ at fixed β, much like the Glasgow method.

- The distribution of the values whose average yields *c*2*<sup>k</sup>* is less and less Gaussian as *k* increases.
- Finite-size effects grow with *k*, since *c*2*<sup>k</sup>* is analogous to a 2*k*-point function.

These considerations should lead us to expect steady, but slow progress in the expansion to higher order. In my opinion, increasing *k* by one requires increasing computer resources by well over two orders of magnitude. The current state of the art is *k*max = 4 (8*th* order expansion) on an *N<sup>t</sup>* = 6 lattice [\[17](#page-20-0)].

In this situation, it is worth exploring alternative methods to obtain the Taylor coefficients. These are based on simulations at imaginary chemical potential.

# **5. Imaginary** µ

The strategy is simple: perform independent simulations at different values of the imaginary chemical potential <sup>µ</sup> = *i*µ*<sup>i</sup>* , fit the results with an ansatz, and analytically continue the ansatz to real µ. If the ansatz is polynomial, the fit parameters are the usual Taylor coefficients. Although this approach has been used mostly to determine the pseudo-critical temperature *Tc*(µ), it has also been applied to the pressure, yielding the same Taylor coefficients *c*2*<sup>k</sup>* as in eq. [\(4.2\)](#page-6-0). A recent study [\[14](#page-20-0)] is illustrated Fig. [7](#page-8-0). At low temperature, the pressure is best described by a hadron resonance gas ansatz. For *T* ≥ 0.95*Tc*, this ansatz becomes poor, and a better description is obtained by a Taylor expansion, which is sensitive to *c*6. Similar observations have been made in Ref. [[18](#page-20-0)] on a smaller lattice. A technical difference is that Ref. [[14\]](#page-20-0) measures only the quark density, i.e. the first derivative of the pressure, as a function of imaginary quark and isospin chemical potentials both, while Ref. [[18\]](#page-20-0) measures all derivatives in <sup>µ</sup>*u*,µ*<sup>d</sup>* up to 4th order, but as a function of quark chemical potential only. It would make sense to marry the two approaches: derivatives up to 4th order are easy to compute, and imaginary isospin chemical potential straightforward to implement. Another important technical issue should be addressed: how to choose the simulated values of imaginary chemical potential and the statistics for each value, so as to maximize the accuracy on a given set of Taylor coefficients? Larger values of <sup>µ</sup>*<sup>i</sup>* increase the sensitivity to the desired higher-order terms, but also the truncation error in the fitted Taylor polynomial.

<span id="page-8-0"></span>![](_page_8_Figure_1.jpeg)

![](_page_8_Figure_2.jpeg)

**Figure 7:** Imaginary quark density as a function of imaginary quark and isospin chemical potentials, for temperatures  $0.9T_c$  (*left*) and  $1.25T_c$  (*right*), from [14]. The surfaces represent hadron resonance gas and polynomial fits, respectively.

# **6. Results:** $T_c(\mu)$

The pseudo-critical temperature can be determined in a variety of ways. As illustrated Fig. 8 *left*, all determinations agree for small  $\mu/T$ . In particular, the curvature  $t_2$  in the Taylor expansion

$$\frac{T_c(\mu)}{T_c(\mu=0)} = 1 - \sum_{k=1} \mathbf{t_{2k}} \left(\frac{\mu}{\pi T}\right)^{2k}$$
 (6.1)

can be determined by the most economical method, which seems to be that of analytic continuation from imaginary  $\mu$ . While in the past, coarse lattices with  $N_t = 4$  and 6 time-slices only have been considered, this year has seen remarkable progress, with a first extrapolation to the continuum limit for physical quark masses [19]. Using  $N_t = 4,6,8$  and 10 lattices and an imaginary- $\mu$  method, this study confirms earlier indications that the curvature of the pseudo-critical line decreases as  $a \rightarrow 0$  [4] and is small [20] compared to that of the freeze-out curve, defined as the fireball temperature below which inelastic collisions stop taking place and the "chemical", hadronic composition of the fireball decay products remains frozen. Since one has a crossover at  $\mu = 0$ ,  $T_c$  depends on the observable considered, and so does the curvature. Still, all observables yield a curvature smaller than that of the freeze-out curve  $t_2 \sim 2$  [21].

This result is of phenomenological importance. As seen Fig. 8 right, a flatter pseudo-critical line  $T_c(\mu)$  increases the distance from the putative QCD critical point to the freeze-out curve, giving more time for a possible signature of criticality to be washed out as the fireball expands before hadronization. Note, however, that the determination of the freeze-out curve is still being debated (compare [21] with, e.g., [22, 23]).

The difficulties of determining subleading coefficients  $t_{2k}$ , k > 1 in the expansion eq. (6.1) has been considered in [25], using the imaginary- $\mu$  approach in cases free of sign problem (SU(2) and SU(3) with isospin  $\mu$ ) where the analytic continuation to real  $\mu$  can be checked against a direct determination. For real  $\mu$ , the pseudo-critical line  $T_c(\mu)$  bends down more and more with increasing  $\mu$ . This indicates that the coefficients  $t_{2k}$  are positive. Unfortunately, for imaginary  $\mu$  the Taylor series is then alternating. Successive contributions largely cancel each other, and the  $t_{2k}$ 's are poorly determined, as illustrated Fig. 9. Technical issues like the best strategy for choosing simulation points and the best choice of fitting ansatz are starting to be explored.

<span id="page-9-0"></span>![](_page_9_Figure_1.jpeg)

Figure 8: (*Left*) Pseudo-critical temperature determined by various approaches for the same lattice theory (4-flavor staggered quarks with mass am = 0.05 on an  $N_t = 4$  lattice) [24]. All approaches agree for  $\mu/T \lesssim 1$ . (*Right*) Effect of a small curvature of the pseudo-critical temperature  $T_c(\mu)$ : the distance from the putative critical point to the freeze-out curve increases, and any signature of the critical point tends to be washed out.

![](_page_9_Figure_3.jpeg)

**Figure 9:** Analytic continuation of the pseudo-critical line  $T_c(\mu)$ : for imaginary  $\mu$  the Taylor series is alternating, making the determination of the subleading Taylor coefficients difficult [25].

#### 7. Results: critical endpoint

Assume that the phase diagram of QCD features a critical point  $(\mu_E, T_E)$ , as marked by the star in Fig. 1. This critical point may or may not be *chiral*. A chiral critical point belongs to the chiral critical surface, swept by the  $\mu = 0$  chiral critical line in the lower left corner of Fig. 10 *left* as  $\mu$  is turned on. A chiral critical point can be brought to  $\mu = 0$  by tuning the quark masses, otherwise not.

A general strategy to locate the QCD critical point, chiral or not, is shown by the first arrow Fig. 10 *right*: one looks for a singularity in  $\mu$ , keeping the quark masses fixed. All such approaches, except for the reweighting study of Fodor and Katz [26, 7], also keep the temperature fixed. One then has to address the delicate question of how to correctly determine the temperature  $T_E$ . For a chiral critical point, an alternative is to stay on the critical surface (second arrow Fig. 10 *right*), where the critical temperature is implicitly defined as a function of  $\mu$  and the quark masses. I review these two strategies in succession.

<span id="page-10-0"></span>![](_page_10_Figure_1.jpeg)

**Figure 10:** (*Left*) Order of the  $\mu = 0$  finite temperature transition as a function of the light and strange quark masses. (*Right*) Two strategies to reach the chiral critical point: (1) at fixed quark masses or (2) along the critical surface.

#### 7.1 Fixed mass, fixed temperature: "effective radius of convergence"

The determination of the Taylor expansion of the pressure, eq. (4.1), provides in principle a simple way to estimate the location of the QCD critical point: the Taylor expansion will stop converging. The pole at  $(\mu_E, T_E)$  in the second derivative  $d^2P/d\mu^2 \equiv \chi_q$  of the pressure will govern the divergence of the coefficients. In fact, there is another pole at  $(-\mu_E, T_E)$ , so that  $d^2P/d\mu^2(\mu, T = T_E) \propto 1/(\mu_E - \mu) + 1/(\mu_E + \mu) \propto (\mu_E^2 - \mu^2)^{-1}$ . It follows that

$$\frac{\mu_E}{T_E} = \lim_{n \to \infty} \sqrt{\left| \frac{c_{2n}(T)}{c_{2n+2}(T)} \right|} \quad \text{at} \quad T = T_E$$
 (7.1)

Thus, some indication about the QCD critical point can perhaps be obtained for free from the first few Taylor coefficients. Indeed, this approach has been followed by Karsch and collaborators [15] and by Gavai and Gupta [17]. The latter group has made strong statements, like "We find the radius of convergence of the series at various temperatures, and bound the location of the QCD critical point to be  $T_E/T_c \approx 0.94$  and  $\mu_E/T_E < 0.6$ " (abstract Ref. [17]). Such strong statements force me to balance them with strong words of caution.

The first and obvious point is that eq. (7.1) concerns the  $n \to \infty$  limit of the Taylor coefficients. From a small number of low-order coefficients, the ratios that one can form are neither a lower nor an upper bound of any sort on the radius of convergence. In fact, [17] considers the Taylor expansion of  $\chi_q$  rather than that of the pressure itself. This leads to an equivalent expression for the radius of convergence

$$\frac{\chi_q}{T^2} = \frac{1}{T^2} \frac{d^2 P}{d\mu^2} = \sum_{n=1}^{\infty} 2n(2n-1) \ c_{2n}(T) \left(\frac{\mu}{T}\right)^{2n-2} \tag{7.2}$$

$$\frac{\mu_E}{T_E} = \lim_{n \to \infty} \sqrt{\left| \frac{2n(2n-1)c_{2n}(T)}{(2n+2)(2n+1)c_{2n+2}(T)} \right|} \quad \text{at} \quad T = T_E$$
 (7.3)

But for n = 1, the "effective radius of convergence" differs from that obtained from eq. (7.1) by a factor  $\sqrt{6}$ . Thus, the coincidence of estimates from successive small values of n depends in part on the choice of observable to expand. Moreover, the QCD critical point is in the universality class of the 3d Ising model, with known, non-trivial critical exponents, and the susceptibility  $\chi_q$  does not simply diverge like  $(\mu_E^2 - \mu^2)^{-1}$ , leading to a modification of eq. (7.3) for finite n.

Another difficulty is that the Taylor coefficients vary with the temperature, and so does the radius of convergence of the expansion. At high temperature, we know from Roberge and Weiss [27] that there is a first-order transition line at  $\mu/T = i\pi/3$ . This singularity at negative  $\mu^2$  is consistent with the measured Taylor coefficients, which alternate in sign at high temperature starting from  $c_4$ . At low temperature, a first-order transition occurs at real  $\mu$ , which should cause high-order Taylor coefficients to all be positive. This remains true as T increases, until the critical endpoint of the first-order line is reached at  $T = T_E$ . When T rises above  $T_E$ , the real singularity due to the critical point branches into a pair of conjugate poles in the complex  $\mu$  plane, as shown by Stephanov in [28]. These complex poles move towards the imaginary  $\mu$  axis as T increases, and approach the origin closer than the QCD critical point [28]. Therefore, the determination of  $T_E$  should not be based on the minimization of the radius of convergence, but on the sign behaviour of the Taylor coefficients. The two groups use different prescriptions. Karsch et al. determine  $T_E$  as the highest temperature at which all measured Taylor coefficients are positive, as appropriate for a singularity at real  $\mu$ . Gavai and Gupta choose for  $T_E$  the lowest temperature  $T_E$  for which all measured Taylor coefficients are positive (see Fig. 11 of [17]).

Finally, the strongest reason for skepticism, in my opinion, comes from the original reweighting study of Fodor and Katz [7]. The observable they focused on, the imaginary part of the Lee-Yang zero closest to the real axis, extrapolated to the thermodynamic limit, is closely related to the inverse of the maximum value of the specific heat. In the small- $\mu$  region where reweighting can be trusted, the specific heat shows complete insensitivity to  $\mu$ . It would take a high-order Taylor expansion about  $\mu = 0$  of the curve Fig. 4 *right* to capture the zero signaling the QCD critical point. Note, as further confirmation of this lack of sensitivity to a putative critical point, that all susceptibilities measured in the determination of the pseudo-critical line  $T_c(\mu)$  [19] reported Sec. 6 appear to slightly *decrease* as  $\mu$  is turned on.

#### 7.2 The curvature of the critical surface

Considering the difficulties and ambiguities of determining the convergence radius of the Taylor expansion, it is worth pursuing a complementary, broader strategy: the determination of the chiral critical surface Fig. 10 *right*, following the second arrow. I have been pursuing this approach for several years with Owe Philipsen [29, 30, 31, 32, 33]. We have now reached conclusive results on coarse  $N_t = 4$  lattices, using standard staggered fermions and setting aside possible issues with taking fractional powers of the fermion determinant.

The first step was the determination of the  $\mu=0$  critical line in the  $(m_{u,d},m_s)$  quark mass plane, shown Fig. 11 *left*. No surprises were encountered there. We confirmed that the physical point lies in the region where a finite-temperature crossover takes place, not a phase transition. And our results were consistent with the tricritical scaling implied by a tricritical point at  $m_{u,d}=0$ ,  $m_s\sim 500$  MeV (solid blue curve in Fig. 11 *left*).

<span id="page-12-0"></span>![](_page_12_Figure_1.jpeg)

Figure 11: Left: Chiral critical line at  $\mu = 0$  in the  $(m_{u,d}, m_s)$  quark mass plane [31]. Compare with expectations Fig. 10 left. The two red arrows mark the points at which the curvature of the critical surface was measured. Center: Leading effect of a negative curvature. Note the curvature of the deconfinement critical surface for heavy quarks [34]. Right: Possible back-bending due to higher-order terms [35].

The next step has been to measure the variation of the critical quark masses with chemical potential, expressed in Taylor series form as

$$\frac{m_c(\mu)}{m_c(0)} = 1 + \sum_{k=1} \mathbf{c_k} \left(\frac{\mu}{\pi T}\right)^{2k} \tag{7.4}$$

This endeavour has been pursued at the two mass points marked by red arrows Fig. 11 *left*, corresponding to three degenerate flavors and to a strange quark with physical mass, respectively. In the  $N_f = 3$  case, we have compared the effect of an infinitesimal imaginary  $\mu$ , which yields the Taylor coefficients  $c_k$  directly, and that of several finite imaginary  $\mu$ 's with results fitted by a polynomial, finding good consistency. We have also compared two spatial volumes,  $8^3$  and  $12^3$ , finding excellent agreement. Our final result [32] is

$$\frac{m_c(\mu)}{m_c(0)} = 1 - 3.3(3) \left(\frac{\mu}{\pi T}\right)^2 - 47(20) \left(\frac{\mu}{\pi T}\right)^4 - \dots$$
 (7.5)

Since we identify the critical mass  $m_c$  as that which gives the Binder cumulant  $B_4 \equiv \frac{\langle (\delta \bar{\psi} \psi)^4 \rangle}{\langle (\delta \bar{\psi} \psi)^2 \rangle^2}$  of the quark condensate  $\bar{\psi} \psi$  its critical Ising value 1.604..., our observable is built from  $4^{th}$  derivatives of the pressure. Extracting  $c_2$  as above then requires the measurement of  $8^{th}$  derivatives of the pressure. As indicated Sec. 4, this is the current state of the art. To obtain such results, we accumulated about 25 million RHMC trajectories, and started to use the EGEE computing Grid [36].

In the  $N_f = 2 + 1$  non-degenerate case with physical strange quark mass, we had to tune  $m_{u,d}$  to values smaller than in nature in order to turn the finite-temperature crossover into a second-order phase transition. This forced us to use a larger,  $16^3$ , volume and use the computing Grid extensively. Our final result [33], based on about 1.5 million trajectories, is

$$\frac{m_c^{u,d}(\mu)}{m_c^{u,d}(0)} = 1 - 39(8) \left(\frac{\mu}{\pi T}\right)^2 - \dots$$
 (7.6)

Thus, in both cases we find that the region of quark masses where a first-order transition takes place *shrinks* as  $\mu$  is turned on, just like in the case of heavy quarks where the sign problem is mild and the critical surface can be determined by brute force reweighting [34, 37]. The chiral critical

<span id="page-13-0"></span>![](_page_13_Figure_1.jpeg)

![](_page_13_Figure_2.jpeg)

Figure 12: Left: estimate of the region of first-order transition in the quark mass plane, in physical units, from improved (stout-smeared) actions on  $N_t = 4$  and 6 lattices [42]. Right: current status of the measurement of the curvature of the critical surface on  $N_t = 6$  lattices. The  $\mathcal{O}((\mu/T)^2)$  Taylor coefficient is obtained from the intercept, and the  $\mathcal{O}((\mu/T)^4)$  coefficient from the slope of the fit. A negative curvature is favored as for  $N_t = 4$ , but the results are not conclusive yet.

surface then bends as shown Fig. 11 *center*. As indicated in the figure, this rules out, on  $N_t = 4$  lattices, the presence of a chiral critical point, at least for  $\mu/T \lesssim \mathcal{O}(1)$  where one would expect the truncation error of the Taylor expansion to be small.

This conclusion must be accompanied by important cautionary remarks. First, one may be worried about the convergence of the Taylor expansion. Already for  $\mu/T=1$ , the last terms of eqs. (7.5) and (7.6) are dominant. Even though the sign of the next-order contribution has been estimated and reinforces the shrinking of the first-order region, it is clear that higher-order terms may quickly produce a "back-bending" of the critical surface as in Fig. 11 *right*. Indeed, this must happen if one wishes to reconcile our result with that of Fodor and Katz [7], whose critical point Fig. 4 lies at  $\mu/T \sim 0.7$  for mass parameters similar to eq. (7.6). Similarly, there is no inconsistency between our conclusion and that of Ejiri [38], who finds a critical point at  $\mu/T \sim 2.4$ . Such a back-bending can also be explained by model calculations. In the  $N_f=2$  case, it is known that a restoration of the  $U(1)_A$  symmetry favors a first-order transition [39, 40]. Similarly for  $N_f=2+1$ , a back-bending surface can be produced in an NJL-type model, by adding a 't Hooft  $U(1)_A$ -breaking term  $(\det \overline{q_i}(1-\gamma_5)q_j+h.c.)$ , with a  $\mu$ -dependent strength [35] <sup>2</sup>. A similar pattern can even be obtained in a linear sigma model including thermal fluctuations [41].

The second issue is the systematic error caused by the rather coarse lattice spacing:  $N_t = 4$  implies  $a \sim 0.3$  fm. Even at  $\mu = 0$  and on  $N_t = 8$  lattices, discretization errors are presumably the cause of the  $\mathcal{O}(15\%)$  discrepancy between estimates of  $T_c$  by Karsch et al. [43] and by Fodor et al. [44]. Here, the critical surface which we study is sensitive to deviations from the Stefan-Boltzmann law at high temperature, and even more so to the violation of taste symmetry which strongly affects the thermodynamics of the 16 "pions". It should come as no surprise – a posteriori – that the critical line in the quark mass plane, using physical coordinates like  $m_\pi/T_c$ , seems to move

<sup>&</sup>lt;sup>2</sup>Interestingly, back-bending does not necessarily produce a critical point. The critical temperature is determined implicitly as one moves on the critical surface, and may decrease to zero, thus terminating the critical surface, before the quark masses have reached their physical values [35].

by O(100%) as *N<sup>t</sup>* increases from 4 to ∞. Early indications came from improving the discretization of the Dirac operator at fixed *N<sup>t</sup>* = 4: the critical pion mass seemed to decrease by a factor ∼ 4 [[45](#page-21-0)]. More recently, an even more dramatic shrinking of the first-order region has been reported in [[42](#page-21-0)], estimating from stout-smeared *N<sup>t</sup>* = 4 and 6 simulations that the first-order region is limited to quark masses about 10 times smaller than physical (see Fig. [12](#page-13-0) *left*). A less dramatic, but similar effect has been seen in [[4\]](#page-19-0) when comparing *m*π/*T<sup>c</sup>* for the 3-flavor theory on lattices with *N<sup>t</sup>* = 4 (*m*π/*T<sup>c</sup>* = 1.680(4)) and 6 (*m*π/*T<sup>c</sup>* = 0.954(12)) time-slices. Clearly, finer lattices tend to make the finite-temperature transition smoother. This can in fact be seen in an NJL model by truncating the sum over Matsubara frequencies to the first *N<sup>t</sup>* values [[46\]](#page-21-0). This effect by itself makes it more difficult to imagine a critical point at small µ: the physical point lies further from the critical line, and the critical surface would have to bend very strongly towards larger quark masses.

Moreover, one may hope, because the chemical potential does not affect the UV physics, that while the critical surface will move significantly towards the origin *mu*,*<sup>d</sup>* = *m<sup>s</sup>* = 0 as *a* → 0, its *curvature* will vary less. This pious wish needs to be confirmed by numerical simulations, which have proved to be challenging. Using the same method as for *N<sup>t</sup>* = 4, we have been simulating an <sup>18</sup><sup>3</sup> <sup>×</sup>6 lattice, with 3 degenerate quark flavors at the <sup>µ</sup> <sup>=</sup> 0 critical mass. After over two years of simulation and a half-million units of Molecular Dynamics time, the current results Fig. [12](#page-13-0) *right* are still too noisy to conclude. The curvature of the critical surface is obtained from the <sup>µ</sup> = 0 intercept of the data: a negative value is favored, as for *N<sup>t</sup>* = 4, but the errors are large and the (correlated) data do not exclude a positive value. Moreover, a linear fit, including a (µ/*T*) 4 term, is preferred over a constant fit. The sign of the (µ/*T*) 4 coefficient then reinforces the shrinking of the first-order region as in eq. [\(7.5\)](#page-12-0). However, its magnitude (which is very poorly determined at the moment) could make this term dominant over the leading (µ/*T*) 2 term as soon as <sup>µ</sup>/*T*>∼0.15. If this turns out to be the case, then our truncated Taylor expansion can only be trusted up to such values. Going to larger µ would require determining higher-order Taylor coefficients, a daunting task.

## **8. Left out**

I have not covered several recent developments in the numerical study of finite-density QCD.

- The numerical study of the canonical ensemble, with a fixed number of baryons, has been extended from staggered fermions [\[47](#page-21-0), [48,](#page-21-0) [38](#page-20-0)] to Wilson fermions, with several technical refinements [[49](#page-21-0), [50, 51\]](#page-21-0). This is computationally challenging, since the fermion determinant must be computed exactly, at a cost proportional to the cube of the matrix size, so that the work is increased 64-fold on a given lattice size. On a 6<sup>3</sup> <sup>×</sup> 4 lattice, the phase diagram appears to be qualitatively different for *N<sup>f</sup>* = 2,3 and 4 flavors, suggesting a possible critical point for *N<sup>f</sup>* = 3. These results are presented by Anyi Li in a plenary talk [\[52](#page-21-0)].
- Instead of aiming at a finite density of baryons, one may study *T* = 0 few-body physics: by measuring the interactions between two or three baryons, one can constrain the couplings of an effective theory describing nuclear matter. This is a very important and active research direction, reviewed last year [[53\]](#page-21-0), with two large-scale efforts underway [[54, 55](#page-21-0)]. The sign problem appears in the form of a signal-to-noise ratio for baryon correlators degrading exponentially fast in Euclidean time [\[56](#page-21-0)]. But since one works at *T* = 0, a toolbox of variational trial states can be used

to try and isolate the groundstate before the signal dies away [[57](#page-21-0)]. The state of the art is reviewed by Will Detmold in a plenary talk [\[58](#page-21-0)]. Spectacular results have already been obtained for multimeson states, corresponding to an isospin chemical potential [[59\]](#page-21-0).

- Other interesting developments concern non-QCD theories, e.g. 2-color "QCD" [[60](#page-21-0)] where a variety of regimes may appear at low temperature, as the chemical potential is increased, or (1+1)*d* Gross-Neveu and NJL models whose phase diagram can be determined analytically [[61, 62\]](#page-21-0), including inhomogeneous, crystalline phases. These features may well be present in QCD also.
- An important approach to tackling the sign problem is the "density of states" approach, where the partition function is expressed as a one-dimensional integral *Z* = R *dx* <sup>ρ</sup>(*x*), and the computer effort can be concentrated on values of *x* where <sup>ρ</sup>(*x*) is more noisy [[63\]](#page-21-0). A large-scale effort, taking for *x* the gluon action, gave hints of a triple point in the (µ,*T*) plane [[64](#page-21-0)]. More recently, this approach has been espoused, in part, by Ejiri in [[38](#page-20-0)].
- Several contributions to this Conference did not fit in the categories above, and I omitted them from this subjective review, with apologies.

## **9. Prospects**

I have painted a rather bleak landscape, where systematic errors are very large and one should only expect slow progress, helped with massive amounts of computer time. Is there nothing more exciting in sight? Yes, definitely. Let me emphasize two directions where I consider enthusiasm to be justified. Amusingly, they both represent a revival of topics which were "hot" twenty years ago.

## **9.1 Worldline formalism and strong coupling limit**

As we have seen Sec. [2](#page-2-0), as soon as one integrates out the fermions, one must encounter a sign problem with the resulting determinant at finite density. This suggests changing the order of integration, and performing at least a partial integration over the gauge fields first [[65](#page-21-0)]. Integrating out the gauge links seems hopeless, since the plaquette term in the action introduces a complicated 4-link interaction. Still, this may be simpler than dealing with the sign problem. To start with, one can consider the strong-coupling limit βgauge = 0, where the plaquette term in the action drops out. Then, the link integration factorizes into a product of 1-link integrals, which can be performed analytically. Only color singlets survive, made of quark fields. The Grassmann integration produces only a handful of terms, which represent the hopping of color singlets from site to site. In other words, the partition function has been reexpressed as a sum over configurations of *loops*, representing the worldlines of hadronic color singlets.

At this stage, this reformulation is relatively simple, since it only involves discrete variables, and physically appealing. But it is not clear that simulations will be any easier: The fixed number of underlying Grassmann variables at each site generates a constraint on the loop configuration (the number of ¯*qq* mesons connected to each site is fixed), which makes local Monte Carlo updates hopelessly inefficient. And a severe sign problem follows from the fermionic nature of the baryons (for an odd number of colors): baryon loops are oriented, and their weight flips sign with their orientation. Fortunately, this sign problem can be solved by partial resummation at <sup>µ</sup> = 0, and then remains very mild at <sup>µ</sup> 6= 0 [\[66](#page-21-0)]. And a recent Monte Carlo algorithm, the "worm" algo-

<span id="page-16-0"></span>rithm [67], is particularly efficient at updating globally such discrete systems with constraints [68]. This efficiency does not even degrade in the chiral limit.

All this was understood and tried around 1990 [66, 69], and abandoned before the discovery of the worm algorithm. This crucial algorithmic progress has enabled a complete numerical determination of the  $(\mu, T)$  phase diagram for the strong coupling limit of QCD with staggered fermions [70], superseding ancient [71] and recent [72] analytical approximations, and even a precise study of nuclear interactions and of "nuclear matter" in this lattice model, all with "tabletop" computer resources.

I am insisting on one particular project because of my personal involvement. But the same worldline approach can be applied to other lattice fermion models [73, 74], and to bosonic models normally afflicted by a sign problem, after transforming to dual variables [75]. It may even be useful to "fermionize" a bosonic system, treating the bosons as fermion composites. Recall that this yields a simple derivation of Onsager's solution to the 2*d* Ising model [76]. This "new computational approach" was reviewed by its main proponent at last year's Conference [77].

Can all lattice models, in particular QCD at weak coupling, be formulated and efficiently simulated as a gas of loops? One technical ingredient for success is the worm algorithm. Its limits of applicability are not clear yet. It appears to work well for at least one model, the  $2d CP^{N-1}$  spin model [78], where cluster algorithms are known to fail. If the random worms can be generalized to random surfaces, then one could apply the same treatment to the Yang-Mills part of the action and simulate QCD at weak coupling, as a gas of quark loops forming the boundary of gauge surfaces. Unfortunately, this step requires a duality transformation, which for a non-Abelian theory gives negative weights and/or non-local couplings [79, 80].

A somewhat less ambitious strategy consists of designing fermion-based, sign-problem free actions, with symmetries which ensure a desired effective low energy limit. Such actions can be efficiently simulated, even in the massless limit, to address precise questions about the effective low energy theory. A variety of models with chiral symmetry can be realized [81]. What is still missing is a non-Abelian gauge symmetry.

### 9.2 Complex Langevin

The idea of stochastic quantization is to introduce a Langevin evolution for a field  $\phi$  in a fictitious time  $\tau$ , obeying

$$\frac{\partial \phi}{\partial \tau} = -\frac{\delta S[\phi]}{\delta \phi} + \eta \tag{9.1}$$

where  $\eta$  is a Brownian noise. When the action  $S[\phi]$  is real, one can prove the existence of an associated Fokker-Planck equation and its convergence to the fixed-point distribution  $\propto \exp(-S[\phi])$ , so that all observables satisfy

$$\langle W[\phi] \rangle_{\tau} = \frac{1}{Z} \int \mathcal{D}\phi \exp(-S[\phi])W[\phi]$$
 (9.2)

where  $\langle..\rangle_{\tau}$  is an average over the fictitious Langevin time  $\tau.$ 

What happens when  $S[\phi]$  is complex? The drift force  $-\frac{\delta S[\phi]}{\delta \phi}$  becomes complex, so that each component of the field  $\phi$  will become complex under the evolution eq. (9.1). One can then complexify  $\phi$  into  $(\phi^R + i\phi^I)$ , evolve with the complexified version of eq. (9.1), and monitor the time-average  $\langle W\left[\phi^R + i\phi^I\right]\rangle_{\tau}$ . There still is an associated Fokker-Planck equation, but almost nothing

is known about stationary solutions. Nevertheless, it turns out that  $\langle W \left[ \phi^R + i \phi^I \right] \rangle_{\tau}$  has the desired value  $\frac{1}{Z} \int \mathcal{D} \phi \exp(-S[\phi]) W \left[ \phi \right]$  – sometimes. Some other times, the  $(\phi^R + i \phi^I)$  distribution in the complex plane does not converge to a  $\tau$ -stationary distribution, because  $(\phi^R + i \phi^I)$  runs to infinity. And some other times, convergence is achieved to a distribution giving wrong expectation values  $\langle W \left[ \phi^R + i \phi^I \right] \rangle_{\tau}$ . An understanding of sufficient conditions (besides taking a real action) to avoid runaways and convergence to the wrong answer was not reached in the 1980s [82, 83, 84, 85]. Activity on this topic died away.

It was noticed only recently that a drastic reduction in the discrete stepsize of the complex Langevin evolution sufficed to almost eliminate runaways. With an adaptive stepsize [86] the runaways disappeared completely. This opened a new playground where to study convergence. Surprisingly, correct answers have been obtained in many cases: toy models with one gauge link matrix; 4d complex  $\phi^4$  theory with a chemical potential, where  $T\approx 0$  Bose-Einstein condensation is reproduced for  $\mu \geq \mu_c$  [87], as well as the lack of  $\mu$ -induced effect for  $\mu < \mu_c$  (known as the "Silver Blaze problem" [88]); and even QCD with chemical potential, in the heavy-dense limit, where results are consistent with those of reweighting [89]. These extraordinary successes should be balanced against a short list of failures: the noise  $\eta$  in eq. (9.1), which a priori only needs to satisfy  $\langle \eta(\tau)|\eta(\tau')\rangle=2\delta(\tau-\tau')$  and can be complex, must in fact be kept real for convergence; and real-time quantum evolution still seems to be out of reach [90]. Clearly, the approach looks promising and its limits must be further explored and understood.

To get the flavor of the magic at work here, let us consider the simple example of Sec. 3.1:  $Z(\lambda) \equiv \int_{-\infty}^{+\infty} dx \exp(-x^2 + i\lambda x)$ . When  $\lambda = 0$ , the real Langevin evolution is  $dx/d\tau = -2x + \eta$ . When  $\lambda \neq 0$ , the drift force becomes complex and one needs to complexify x into (x+iy). The corresponding Langevin evolution becomes

$$\frac{d}{d\tau}(x+iy) = -2(x+iy) + i\lambda + \eta \tag{9.3}$$

In this simple case, this equation can be solved analytically. Since  $Z(\lambda)$  is a Gaussian integral, the stationary distribution of (x,y) is a nice Gaussian shown Fig. 13, centered at the complex saddle point  $(x=0,y=i\lambda/2)$ . It is perhaps not intuitive how expectation values  $\langle W(x) \rangle$  are recovered: one must analytically continue W(x) to W(x+iy) to obtain  $\langle W(x+iy) \rangle_{\tau} = \langle W(x) \rangle_{Z}$ . The original, negative contributions of some values of x are then reconstructed when one integrates W(x+iy) over y. Note that the y-width of the Gaussian depends on the variance of the imaginary part of the Langevin noise: for a real noise, the y-width shrinks to zero. But, in this case at least, correct answers are obtained for any complex Langevin noise satisfying  $\langle \eta(\tau)|\eta(\tau')\rangle=2\delta(\tau-\tau')$ .

This toy example suggests that an analysis of the saddle points of the classical action can be fruitful. This is the starting point of a loop-like expansion considered in [91], which may shed light on the convergence properties of complex Langevin: The Langevin noise distorts the classical Gaussian distribution around the saddle points, hopefully in a weak manner. Indeed, one may guess that systems with one complex saddle point can perhaps be safely studied by complex Langevin, while competition between saddle points (as at a first-order transition) may present a challenge. The "safe" category might include the effect of a  $\theta$  vacuum angle, as studied in a saddle-point formulation in [92]. Gauge theories are more likely to be in the "unsafe" category, due to flat directions in the action, which correspond to gauge transformations and extend to complex infinity

<span id="page-18-0"></span>![](_page_18_Figure_1.jpeg)

**Figure 13:** Complex Langevin for 1 degree of freedom *x* → (*x*+*iy*): the oscillatory *x*-distribution of Fig. [2,](#page-3-0) shown in red and green, becomes a smooth positive Gaussian in the (*x*,*y*) plane, centered at the complex saddle point *i*λ/2. All moments of the original, oscillatory *x*-distribution are equal to moments of (*x* + *iy*) with respect to the Gaussian, positive (*x*,*y*) distribution.

because gauge links are complexified from *SU*(*N*) to *SL*(*N*,**C**). Progress is being made towards understanding necessary conditions for convergence [[93\]](#page-22-0). Finally, I note the intriguing, perhaps fruitful analogy between complex Langevin and *PT*-symmetric quantum mechanics [[94\]](#page-22-0) and its cousin, complexified classical mechanics [[95\]](#page-22-0).

## **10. Conclusions**

Determining the phase diagram of QCD as a function of temperature and chemical potential is an important fundamental goal. Even if clear answers are not available yet, and if the progress in our knowledge is likely to be slow, it is definitely worth pursuing the present efforts. Finite-density lattice QCD is not just a temporarily fashionable topic: it justifies a sustained research program.

Three numerical approaches give reliable, consistent results provided the chemical potential is small enough: reweighting, Taylor expansion and analytic continuation from imaginary µ. This allows crosschecks in the region where the reliability of these methods becomes doubtful. Confidence in finite-density simulations can be established, so that comparison between QCD and models can become reliable and fruitful. For instance, the well-established phase diagram of QCD at imaginary µ is already a useful testing ground for effective models.

Similarly, the curvature of the pseudo-critical temperature *Tc*(µ) at <sup>µ</sup> = 0 is almost under numerical control, and provides useful phenomenological information. The situation is more delicate regarding the existence and location of a QCD critical point, which requires venturing to non-zero µ. Nevertheless, analytic knowledge about the severity of the sign problem can give us, before we start the computation, reliable information about the (µ,*T*) region which can be explored and

<span id="page-19-0"></span>the baryon density which can be reached. And it now seems clear that the coarseness of the usual *N<sup>t</sup>* = 4 or 6 lattices is the major source of systematic error. Thus, with necessary massive increases in computer resources, we can expect slow but steady progress towards the final, continuum limit answer.

This review suggests two possibilities for breakthroughs, or at least for rapid development: reversing the order of integration and integrating over the gauge links first; and dealing with the sign problem using complex Langevin. Whatever the final scope of these two strategies, one can already predict that they will contribute to increasing our knowledge of finite-density QCD at least in some limiting regimes of parameters.

I would like to end by citing Confucius, who knew all about the importance of scholarly research: "Real knowledge is to know the extent of one's ignorance".

## **Acknowledgements**

I am very grateful to numerous colleagues for discussions and patient explanations, among them G. Aarts, A. Alexandru, M. Alford, B. Bringoltz, M. D'Elia, W. Detmold, S. Ejiri, Z. Fodor, M. Fromm, K. Fukushima, C. Gattringer, R. Gavai, M. Goltermann, S. Gupta, S. Hands, A. Hasenfratz, S. Kim, A. Kurkela, K.-F. Liu, A. Ohnishi, M. Panero, O. Philipsen, C. Schmidt, S. Sharpe, K. Splittorff.

## **References**

- [1] J. C. Osborn, K. Splittorff and J. J. M. Verbaarschot, arXiv:0808.1982 [hep-lat].
- [2] P. de Forcrand, S. Kim and T. Takaishi, Nucl. Phys. Proc. Suppl. **119** (2003) 541 [arXiv:hep-lat/0209126].
- [3] S. D. H. Hsu and D. Reeb, Int. J. Mod. Phys. A **25** (2010) 53.
- [4] P. de Forcrand, S. Kim and O. Philipsen, PoS **LAT2007** (2007) 178 [arXiv:0711.0262 [hep-lat]].
- [5] K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. D **77** (2008) 014514 [arXiv:0709.2218 [hep-lat]].
- [6] I. Barbour, N. E. Behilil, E. Dagotto, F. Karsch, A. Moreo, M. Stone and H. W. Wyld, Nucl. Phys. B **275** (1986) 296.
- [7] Z. Fodor and S. D. Katz, JHEP **0404** (2004) 050 [arXiv:hep-lat/0402006].
- [8] K. Splittorff, arXiv:hep-lat/0505001.
- [9] F. Csikor, G. I. Egri, Z. Fodor, S. D. Katz, K. K. Szabo and A. I. Toth, JHEP **0405** (2004) 046 [arXiv:hep-lat/0401016].
- [10] J. Han and M. A. Stephanov, Phys. Rev. D **78** (2008) 054507 [arXiv:0805.1939 [hep-lat]].
- [11] P. de Forcrand, M. A. Stephanov and U. Wenger, PoS **LAT2007** (2007) 237 [arXiv:0711.0023 [hep-lat]].
- [12] J. C. R. Bloch and T. Wettig, JHEP **0903** (2009) 100 [arXiv:0812.0324 [hep-lat]].
- [13] M. P. Lombardo, K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. D **80** (2009) 054509 [arXiv:0904.2122 [hep-lat]].

- <span id="page-20-0"></span>[14] M. D'Elia and F. Sanfilippo, Phys. Rev. D **80** (2009) 014502 [arXiv:0904.1400 [hep-lat]].
- [15] C. R. Allton *et al.*, Phys. Rev. D **71** (2005) 054508 [arXiv:hep-lat/0501030].
- [16] C. Schmidt, private communication.
- [17] R. V. Gavai and S. Gupta, Phys. Rev. D **78** (2008) 114503 [arXiv:0806.2233 [hep-lat]].
- [18] T. Takaishi, P. de Forcrand and A. Nakamura, arXiv:1002.0890 [hep-lat].
- [19] G. Endrodi, these proceedings, PoS **LAT2009** (2010) 167; G. Endrodi, Z. Fodor, S. D. Katz and K. K. Szabo, PoS **LATTICE2008** (2008) 205 [arXiv:0901.3018 [hep-lat]].
- [20] See, e.g., Table I in O. Philipsen, Prog. Theor. Phys. Suppl. **174** (2008) 206 [arXiv:0808.0672 [hep-ph]].
- [21] J. Cleymans, H. Oeschler, K. Redlich and S. Wheaton, J. Phys. G **32** (2006) S165 [arXiv:hep-ph/0607164].
- [22] A. Andronic *et al.*, Nucl. Phys. A **837** (2010) 65 [arXiv:0911.4806 [hep-ph]].
- [23] J. Rafelski and J. Letessier, Nucl. Phys. A **715** (2003) 98 [arXiv:nucl-th/0209084].
- [24] S. Kratochvila and P. de Forcrand, PoS **LAT2005** (2006) 167 [arXiv:hep-lat/0509143].
- [25] P. Cea, L. Cosmai, M. D'Elia, C. Manneschi and A. Papa, Phys. Rev. D **80** (2009) 034501 [arXiv:0905.1292 [hep-lat]].
- [26] Z. Fodor and S. D. Katz, Phys. Lett. B **534** (2002) 87 [arXiv:hep-lat/0104001].
- [27] A. Roberge and N. Weiss, Nucl. Phys. B **275** (1986) 734.
- [28] M. A. Stephanov, Phys. Rev. D **73** (2006) 094508 [arXiv:hep-lat/0603014].
- [29] P. de Forcrand and O. Philipsen, Nucl. Phys. B **642** (2002) 290 [arXiv:hep-lat/0205016].
- [30] P. de Forcrand and O. Philipsen, Nucl. Phys. B **673** (2003) 170 [arXiv:hep-lat/0307020].
- [31] P. de Forcrand and O. Philipsen, JHEP **0701** (2007) 077 [arXiv:hep-lat/0607017].
- [32] P. de Forcrand and O. Philipsen, JHEP **0811** (2008) 012 [arXiv:0808.1096 [hep-lat]].
- [33] J. T. Moscicki, M. Wos, M. Lamanna, P. de Forcrand and O. Philipsen, arXiv:0911.5682 [Unknown].
- [34] S. Kim, Ph. de Forcrand, S. Kratochvila and T. Takaishi, PoS **LAT2005** (2006) 166 [arXiv:hep-lat/0510069].
- [35] J. W. Chen, K. Fukushima, H. Kohyama, K. Ohnishi and U. Raha, Phys. Rev. D **80** (2009) 054012 [arXiv:0901.2407 [hep-ph]].
- [36] P. de Forcrand and O. Philipsen, PoS **LATTICE2008** (2008) 208 [arXiv:0811.3858 [hep-lat]].
- [37] J. Langelage and O. Philipsen, arXiv:0911.2577 [hep-lat].
- [38] S. Ejiri, Phys. Rev. D **78** (2008) 074507 [arXiv:0804.3227 [hep-lat]]; PoS **LATTICE2008** (2008) 002 [arXiv:0812.1534 [hep-lat]].
- [39] R. D. Pisarski and F. Wilczek, Phys. Rev. D **29** (1984) 338.
- [40] S. Chandrasekharan and A. C. Mehta, Phys. Rev. Lett. **99** (2007) 142004 [arXiv:0705.0617 [hep-lat]].
- [41] E. S. Bowman and J. I. Kapusta, Phys. Rev. C **79** (2009) 015202 [arXiv:0810.0042 [nucl-th]].

<span id="page-21-0"></span>[42] G. Endrodi, Z. Fodor, S. D. Katz and K. K. Szabo, PoS **LAT2007** (2007) 182 [arXiv:0710.0998 [hep-lat]].

- [43] A. Bazavov *et al.*, Phys. Rev. D **80** (2009) 014504 [arXiv:0903.4379 [hep-lat]].
- [44] Y. Aoki, Z. Fodor, S. D. Katz and K. K. Szabo, Phys. Lett. B **643** (2006) 46 [arXiv:hep-lat/0609068]; Y. Aoki, S. Borsanyi, S. Durr, Z. Fodor, S. D. Katz, S. Krieg and K. K. Szabo, JHEP **0906** (2009) 088 [arXiv:0903.4155 [hep-lat]].
- [45] F. Karsch, C. R. Allton, S. Ejiri, S. J. Hands, O. Kaczmarek, E. Laermann and C. Schmidt, Nucl. Phys. Proc. Suppl. **129** (2004) 614 [arXiv:hep-lat/0309116].
- [46] J. W. Chen, K. Fukushima, H. Kohyama, K. Ohnishi and U. Raha, arXiv:0912.2099 [hep-ph].
- [47] A. Hasenfratz and D. Toussaint, Nucl. Phys. B **371**, 539 (1992).
- [48] P. de Forcrand and S. Kratochvila, Nucl. Phys. Proc. Suppl. **153**, 62 (2006) [arXiv:hep-lat/0602024].
- [49] A. Alexandru, A. Li and K. F. Liu, PoS **LAT2007** (2007) 167 [arXiv:0711.2678 [hep-lat]].
- [50] X. f. Meng, A. Li, A. Alexandru and K. F. Liu, PoS **LATTICE2008** (2008) 032 [arXiv:0811.2112 [hep-lat]].
- [51] J. Danzer and C. Gattringer, Phys. Rev. D **78** (2008) 114506 [arXiv:0809.2736 [hep-lat]].
- [52] A. Li, arXiv:1002.4459 [hep-lat].
- [53] S. R. Beane, PoS **LATTICE2008** (2008) 008 [arXiv:0812.1236 [hep-lat]].
- [54] S. Aoki, T. Hatsuda and N. Ishii, arXiv:0909.5585 [hep-lat].
- [55] S. R. Beane *et al.* [NPLQCD Collaboration], arXiv:0912.4243 [hep-lat].
- [56] G. P. Lepage, "The analysis of algorithms for lattice gauge theory", Invited lectures given at TASI'89 summer school, Boulder, CO, June 4-30, 1989. Published in Boulder ASI 1989:97-120 (QCD161:T45:1989).
- [57] S. R. Beane *et al.*, Phys. Rev. D **80** (2009) 074501 [arXiv:0905.0466 [hep-lat]].
- [58] W. Detmold, PoS **LAT2009** (2010) 008.
- [59] S. R. Beane, W. Detmold, T. C. Luu, K. Orginos, M. J. Savage and A. Torok, Phys. Rev. Lett. **100** (2008) 082004 [arXiv:0710.1827 [hep-lat]].
- [60] S. Hands, S. Kim and J. I. Skullerud, arXiv:1001.1682 [hep-lat].
- [61] G. Basar and G. V. Dunne, Phys. Rev. D **78** (2008) 065022 [arXiv:0806.2659 [hep-th]].
- [62] G. Basar, G. V. Dunne and M. Thies, Phys. Rev. D **79** (2009) 105012 [arXiv:0903.1868 [hep-th]].
- [63] G. Bhanot, K. Bitar and R. Salvador, Phys. Lett. B **188** (1987) 246; A. Gocksch, Phys. Rev. Lett. **61** (1988) 2054.
- [64] Z. Fodor, S. D. Katz and C. Schmidt, JHEP **0703** (2007) 121 [arXiv:hep-lat/0701022].
- [65] B. Bringoltz, arXiv:1004.0030 [hep-lat].
- [66] F. Karsch and K. H. Mutter, Nucl. Phys. B **313** (1989) 541.
- [67] N. Prokof'ev and B. Svistunov, Phys. Rev. Lett. **87** (2001) 160601.
- [68] D. H. Adams and S. Chandrasekharan, Nucl. Phys. B **662** (2003) 220 [arXiv:hep-lat/0303003].
- [69] G. Boyd, J. Fingberg, F. Karsch, L. Karkkainen and B. Petersson, Nucl. Phys. B **376** (1992) 199.

<span id="page-22-0"></span>[70] P. de Forcrand and M. Fromm, Phys. Rev. Lett. **104** (2010) 112005 [arXiv:0907.1915 [hep-lat]]; M. Fromm and P. de Forcrand, PoS **LAT2009** (2010) 193, arXiv:0912.2524 [hep-lat].

- [71] P. H. Damgaard, D. Hochberg and N. Kawamoto, Phys. Lett. B **158** (1985) 239; P. H. Damgaard, N. Kawamoto and K. Shigemoto, Nucl. Phys. B **264** (1986) 1.
- [72] K. Miura, T. Z. Nakano and A. Ohnishi, Prog. Theor. Phys. **122** (2009) 1045 [arXiv:0806.3357 [nucl-th]].
- [73] C. Gattringer, V. Hermann and M. Limmer, Phys. Rev. D **76** (2007) 014503 [arXiv:0704.2277 [hep-lat]].
- [74] U. Wenger, PoS **LAT2009** (2010) 022, arXiv:0911.4099 [hep-lat]; Phys. Rev. D **80** (2009) 071503 [arXiv:0812.3565 [hep-lat]].
- [75] D. Banerjee and S. Chandrasekharan, arXiv:1001.3648 [hep-lat].
- [76] S. Samuel, J. Math. Phys. **21** (1980) 2806.
- [77] S. Chandrasekharan, PoS **LATTICE2008** (2008) 003 [arXiv:0810.2419 [hep-lat]].
- [78] U. Wolff, Nucl. Phys. B **832** (2010) 520 [arXiv:1001.2231 [hep-lat]].
- [79] A. Ukawa, P. Windey and A. H. Guth, Phys. Rev. D **21** (1980) 1013.
- [80] J. W. Cherrington, D. Christensen and I. Khavkine, Phys. Rev. D **76** (2007) 094503 [arXiv:0705.2629 [hep-lat]]; J. W. Cherrington, arXiv:0910.1890 [hep-lat].
- [81] D. J. Cecile and S. Chandrasekharan, Phys. Rev. D **77** (2008) 014506 [arXiv:0708.0558 [hep-lat]]; Phys. Rev. D **77** (2008) 091501 [arXiv:0801.3823 [hep-lat]].
- [82] G. Parisi, Phys. Lett. B **131** (1983) 393.
- [83] J. R. Klauder, J. Phys. A **16** (1983) L317.
- [84] F. Karsch and H. W. Wyld, Phys. Rev. Lett. **55** (1985) 2242.
- [85] J. Ambjorn and S. K. Yang, Phys. Lett. B **165** (1985) 140.
- [86] G. Aarts, F. A. James, E. Seiler and I. O. Stamatescu, Phys. Lett. B **687** (2010) 154 [arXiv:0912.0617 [hep-lat]].
- [87] G. Aarts, Phys. Rev. Lett. **102** (2009) 131601 [arXiv:0810.2089 [hep-lat]].
- [88] T. D. .. Cohen, Phys. Rev. Lett. **91** (2003) 222001 [arXiv:hep-ph/0307089].
- [89] G. Aarts and I. O. Stamatescu, JHEP **0809** (2008) 018 [arXiv:0807.1597 [hep-lat]].
- [90] J. Berges, S. Borsanyi, D. Sexty and I. O. Stamatescu, Phys. Rev. D **75** (2007) 045007 [arXiv:hep-lat/0609058].
- [91] G. Guralnik and C. Pehlevan, Nucl. Phys. B **822** (2009) 349 [arXiv:0902.1503 [hep-lat]].
- [92] V. Azcoiti, G. Di Carlo, A. Galante and V. Laliena, Phys. Rev. Lett. **89** (2002) 141601 [arXiv:hep-lat/0203017].
- [93] G. Aarts, E. Seiler and I. O. Stamatescu, Phys. Rev. D **81** (2010) 054508 [arXiv:0912.3360 [hep-lat]].
- [94] C. M. Bender, Contemp. Phys. **46** (2005) 277 [arXiv:quant-ph/0501052].
- [95] C. M. Bender, D. D. Holm and D. W. Hook, J. Phys. A **40** (2007) F793 [arXiv:0705.3893 [hep-th]].

![](_page_23_Figure_0.jpeg)

![](_page_24_Figure_0.jpeg)

![](_page_24_Figure_1.jpeg)

![](_page_25_Figure_0.jpeg)

![](_page_26_Figure_0.jpeg)

![](_page_27_Figure_0.jpeg)

![](_page_28_Picture_0.jpeg)

![](_page_29_Picture_0.jpeg)

![](_page_30_Figure_0.jpeg)