# <span id="page-0-0"></span>8.962 General Relativity, Spring 2017 Massachusetts Institute of Technology Department of Physics

Lectures by: Alan Guth Notes by: Andrew P. Turner

May 26, 2017

# 1 Lecture 1 (Feb. 8, 2017)

## 1.1 Why general relativity?

Why should we be interested in general relativity?

- (a) General relativity is the uniquely greatest triumph of analytic reasoning in all of science. Simultaneity is not well-defined in special relativity, and so Newton's laws of gravity become Ill-defined. Using only special relativity and the fact that Newton's theory of gravity works terrestrially, Einstein was able to produce what we now know as general relativity.
- (b) Understanding gravity has now become an important part of most considerations in fundamental physics. Historically, it was easy to leave gravity out phenomenologically, because it is a factor of 10<sup>38</sup> weaker than the other forces. If one tries to build a quantum field theory from general relativity, it fails to be renormalizable, unlike the quantum field theories for the other fundamental forces. Nowadays, gravity has become an integral part of attempts to extend the standard model. Gravity is also important in the field of cosmology, which became more prominent after the discovery of the cosmic microwave background, progress on calculations of big bang nucleosynthesis, and the introduction of inflationary cosmology.

## 1.2 Review of Special Relativity

The basic assumption of special relativity is as follows: All laws of physics, including the statement that light travels at speed c, hold in any inertial coordinate system. Furthermore, any coordinate system that is moving at fixed velocity with respect to an inertial coordinate system is also inertial. The statements that all laws of physics hold in any inertial frame and any frame that moves at fixed velocity with respect to an inertial frame is also inertial are often called Galilean relativity.

The statement that the speed of light should always be c might seem somewhat counterintuitive. We can avoid the seeming contradictions that this causes by relaxing our assumptions about how observations in two different reference frames are related. That is, everything is consistent if we change our ideas relating the observations of different observers.

The kinematic consequences of special relativity can be summarized in three statements:

• Time dilation: A clock moving relative to an inertial frame will "appear" to run slow by a factor of  $\gamma = \frac{1}{\sqrt{1-v^2/c^2}}$ .

To demonstrate that time dilation is essential, we can consider the thought experiment of the light clock. Consider a clock that, in its rest frame, consists of two stationary parallel mirrors with a light beam bouncing back and forth between them. By measuring the time it takes the light beam to make one full transit, we can use this setup as a clock. Now consider another inertial frame in which the same clock is moving at velocity v, in a direction parallel to the plane of the mirrors. In this frame, the light pulse moves diagonally from one mirror to the other and back. This path is longer than the path in the rest frame of the clock, and so the clock runs slower as viewed from this frame. This uses the assumption that the speed of light is the same for all observers, as well as the assumption that the separation between the two mirrors is the same in both frames. The latter assumption can be argued by consistency. Consider the case that the travelling clock passed through a similar clock in our rest frame. If the separation changed due to the motion, the moving mirrors would either pass between or around the mirrors in the rest frame; either situation violates the symmetry between the two frames, and so the separation between the mirrors cannot change.

• Lorentz–Fitzgerald Contraction: Any rod moving along its length at speed v relative to an inertial frame will "appear" contracted by a factor of  $\gamma$ . There is no contraction along directions perpendicular to the direction of movement.

There is another simple thought experiment that allows us to derive the necessity of length contraction. We again consider a light clock, and we now assume that we measure the separation between the mirrors exactly using a measuring rod. We then consider going to a frame in which the clock is moving at speed v in a direction perpendicular to the plane of the mirrors. As we have seen, we know this clock must slow down by a factor of  $\gamma$  due to time dilation. We can then compute the separation of the mirrors in this frame necessary to explain this slowing of the clock, and the result is that the separation must have contracted by an factor of  $\gamma$ .

• Relativity of simultaneity: If two clocks that are synchronized in their rest frame are viewed in a frame where they are moving along their line of separation at speed v relative to an inertial frame, the trailing clock will lag by an amount  $\frac{v\ell_0}{c^2}$ , where  $\ell_0$  is the rest frame separation of the clocks

Imagine two clocks at rest, separated by a measuring rod of rest length  $\ell_0$ , that have been synchronized in the rest frame of the system. Now consider a frame in which this system is moving at a speed v along the direction of separation between the clocks. The clocks will not be synchronized in this frame. The time  $t_1^{\text{clock}}$  read off of the leading clock will be related to the time  $t_2^{\text{clock}}$  of the trailing clock by

$$t_2^{\text{clock}} = t_1^{\text{clock}} + \frac{v\ell_0}{c^2}. \tag{1.1}$$

How can we synchronize the clocks in their rest frame? If we know the separation  $\ell_0$  between the clocks in the rest frame, we can emit a light pulse at time  $t_1$  from the first clock. When the light pulse reaches the second clock, we set the second clock to read time

$$t_2 = t_1 + \frac{\ell_0}{c} \,. \tag{1.2}$$

Now consider the same process in a frame where the system is moving at speed v along the direction of separation between the two clocks. In this frame, the separation between the clocks is  $\ell = \ell_0/\gamma$ . At time  $t_1'$ , the light pulse is emitted at the first clock, when this clock reads  $t_{\rm emit}^{\rm clock}$ . At some later time  $t_2'$ , the light beam reaches the second clock, which is then set to read

$$t_{\text{rec}}^{\text{clock 2}} = t_{\text{emit}}^{\text{clock 1}} + \frac{\ell_0}{c}. \tag{1.3}$$

By comparing these times with the times  $t'_1$  and  $t'_2$ , we can find the amount by which the leading and trailing clocks differ.

Here, the word "appear" does not mean what one observer sees with his or her eyes; finding what one observer actually sees requires taking into account the light travel time from the point of emission to the observer's eyes. The word "appears" here means that we have already taken out the effect of this light travel time; we imagine that all of space is filled with observers at rest in the same inertial frame, and the observations are always taken locally and then collected after the fact.

### 1.3 Notation of Special Relativity

We want to be able to describe space and time as a single entity, as they will be mixed by Lorentz transformations. To this end, we introduce four-vector coordinates

$$x \equiv (x^0, x^1, x^2, x^3) = (ct, x, y, z) \in \mathbb{R}^4.$$
(1.4)

We often denote the components of x with the shorthand  $x^{\mu}$ , in which  $\mu$  runs through 0,1,2,3. We will use the convention that Greek letters  $\mu,\nu,\ldots$  run over all spacetime coordinates 0,1,2,3, while roman letters  $i,j,\ldots$  run over only spatial coordinates 1,2,3.

We will often be dealing with coordinates in multiple frames. The transformations that convert between inertial coordinates are called *Lorentz transformations*. We will denote such transformations by  $\Lambda$ . The conversion between coordinates is written as

$$x^{\mu'} = \Lambda^{\mu'}_{\phantom{\mu'}\nu} x^{\nu} \,. \tag{1.5}$$

Here, we are using the Einstein summation notation, in which repeated indices in a single term are always summed over. In particular,

$$\Lambda^{\mu'}{}_{\nu}x^{\nu} \equiv \sum_{\nu=0}^{3} \Lambda^{\mu'}{}_{\nu}x^{\nu} \,. \tag{1.6}$$

If we have expressions of the form  $a^{\mu} + b^{\mu}$ , the index  $\mu$  is **not** summed over, as it is never repeated in a single term.

The symbol x represents a vector in this notation. This means that x has a universal meaning, irrespective of a choice of coordinate system. In our notation, the symbol  $x^{\mu}$  denotes the coordinates of this vector in the unprimed frame. By comparison, the symbol  $x^{\mu'}$  denotes the coordinates of the vector x in the primed frame; note that the prime is on the index  $\mu$  and not on x, because the components of x change when we change frames but the vector x itself does not.

The coordinate basis vectors will be denoted  $e_{(\mu)}$ . Note that  $\mu$  here is not a Lorentz index;  $e_{(0)}$ , for example, is itself a four-vector, so we put the index in parentheses to avoid confusion. The vector x can then be written

$$x = x^{\mu} e_{(\mu)} \,. \tag{1.7}$$

## 2 Lecture 2 (Feb. 15, 2017)

#### 2.1 Lorentz Transformations

In special relativity, we denote coordinate vectors by x. By  $x^{\mu}$ , we mean the coordinates of the vector x in the unprimed frame,

$$x^{\mu} = (x^{0}, x^{1}, x^{2}, x^{3}) \equiv (ct, x, y, z). \tag{2.1}$$

The same vector can be expressed in another frame, which we can denote with a prime on the index, as

$$x^{\mu'} = (x^{0'}, x^{1'}, x^{2'}, x^{3'}) \equiv (ct', x', y', z'). \tag{2.2}$$

These two inertial frames are related by Lorentz transformations,  $\Lambda^{\mu'}_{\nu}$ . It is important to be careful with our conventions here; in Carroll's notation,  $\Lambda^{\mu'}_{\nu}$  transforms from the unprimed frame to the primed frame, while  $\Lambda^{\mu}_{\nu'}$  transforms from the primed frame to the unprimed frame. These two transformations are inverses of one another,

<span id="page-3-0"></span>
$$\Lambda^{\mu}_{\ \nu'}\Lambda^{\nu'}_{\ \lambda} = \delta^{\mu}_{\lambda} \,. \tag{2.3}$$

In other texts, such as those by Wald or Weinberg, indices are used simply as variables that run from 0 to 3, with no assumption that primes on indices have any special meaning. In that notation, Eq. (2.3) would be written as

$$\left(\Lambda^{-1}\right)^{\mu}_{\phantom{\mu}\nu}\Lambda^{\nu}_{\phantom{\nu}\lambda} = \delta^{\mu}_{\lambda} \,. \tag{2.4}$$

In this course, we will be using Carroll's notation.

Lorentz transformations act on coordinates as

$$x^{\mu'} = \Lambda^{\mu'}_{\ \nu} x^{\nu} \,. \tag{2.5}$$

There are two types of Lorentz transformations: rotations and Lorentz boosts. Let's first discuss rotations. As an example, we can consider a counterclockwise rotation about the z-axis by an angle  $\theta$ . This transformation leaves the t and z directions unaffected and rotates the x- and y-directions into one another as

$$x' = x\cos\theta + y\sin\theta, \qquad (2.6)$$

$$y' = -x\sin\theta + y\cos\theta, \qquad (2.7)$$

$$t' = t, (2.8)$$

$$z' = z. (2.9)$$

We can express this in the form of a matrix:

$$\Lambda^{\mu'}_{\ \nu} = \begin{bmatrix} 1 & 0 & 0 & 0 \\ 0 & \cos\theta & \sin\theta & 0 \\ 0 & -\sin\theta & \cos\theta & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix}. \tag{2.10}$$

Here, the rows are labelled by the value of the index  $\mu'$ , while the columns are labelled by the value of the index  $\nu$ .

The other type of Lorentz transformation is a Lorentz boost, which mixes the spatial and temporal components of spacetime. Consider a boost in which the primed coordinate system moves in the +x-direction at velocity v relative to the unprimed system, as shown in Fig. 1. We imagine a series of clocks at rest in the unprimed frame, laid out along the x-axis and synchronized in this frame, and similarly a set of clocks at rest in the primed frame, laid out along the x'-axis and synchronized in the primed frame. At time t=0 in the unprimed frame, the origins of both frames are coincident and the clock at rest at the origin of the primed frame reads  $t'_0=0$ .

<span id="page-4-0"></span>![](_page_4_Figure_4.jpeg)

Figure 1: Unprimed and primed coordinate systems, each constructed from rods and clocks, shown as seen in the unprimed frame at time t. The primed system is moving at speed v in the  $+\hat{x}$ -direction relative to the unprimed frame. The clocks shown on each axis are at rest and are synchronized in the rest frame of their respective axes. The x- and x'-axes actually lie on top of one another, but are shown separated to avoid clutter.

To determine the transformation equations, we will calculate the t- and x-coordinates of the clock shown at position x' on the x'-axis, where the time shown on the clock is denoted by  $t'_{x'}$ . Starting with time, we note that the clocks on the x'-axis run slowly in the unprimed frame due to time dilation, and so the clock at rest at the origin of the primed frame must now read  $t'_0 = \frac{t}{\gamma}$ . The clock at position x', which is synchronized in the primed frame with the clock at the origin of the primed frame, is seen in the unprimed frame to lag behind the clock at the origin by an amount  $\frac{vx'}{c^2}$  due to the relativity of simultaneity. The clock at position x' thus reads

<span id="page-4-1"></span>
$$t'_{x'} = \frac{t}{\gamma} - \frac{vx'}{c^2} \,. \tag{2.11}$$

We can drop the subscript x' on  $t'_{x'}$ , so  $t'_{x'} \equiv t'$ , since the time on the clock at x' defines the time at x' in the primed coordinate system. Then solving this equation for t gives

$$t = \gamma \left( t' + \frac{vx'}{c^2} \right). \tag{2.12}$$

Thus we have expressed the coordinate time t in the unprimed frame as a function of the t' and x' coordinates in the primed frame.

We can do something similar to find an expression for x. We know that in the time t, the entire primed coordinate system has moved a distance vt in the unprimed frame. The clock at the origin of the primed system is therefore at position x = vt in the unprimed frame. The clock at position x' has a rest separation of x' from the clock at the origin of the primed system, so due to Lorentz contraction, the separation in the unprimed frame is  $\frac{x'}{\gamma}$ . Thus,

$$x = vt + \frac{x'}{\gamma} \,. \tag{2.13}$$

Substituting in our expression for t from Eq. (2.12), this gives

$$x = \gamma(x' + vt'). \tag{2.14}$$

The y and z coordinates are unaffected by the boost. Altogether, we have

$$t = \gamma \left( t' + \frac{vx'}{c^2} \right),$$

$$x = \gamma (x' + vt'),$$

$$y = y',$$

$$z = z'.$$
(2.15)

We can invert these relations to also give us

$$t' = \gamma \left( t - \frac{vx}{c^2} \right),$$

$$x' = \gamma (x - vt),$$

$$y' = y,$$

$$z' = z.$$

$$(2.16)$$

These are the relationships between coordinates in the two frames that are related by a Lorentz boost along the x-axis. As we would expect, inversion of the equations is equivalent to simply replacing v by -v, since the relationship between the two coordinate systems is symmetric, except for the sign of v.

We can now write this Lorentz boost in the matrix form as

$$\Lambda^{\mu'}{}_{\nu} = \begin{bmatrix} \gamma & -\frac{v\gamma}{c} & 0 & 0\\ -\frac{v\gamma}{c} & \gamma & 0 & 0\\ 0 & 0 & 1 & 0\\ 0 & 0 & 0 & 1 \end{bmatrix}. \tag{2.17}$$

#### 2.2 The Lorentz-Invariant Interval

The quantity

$$-c^2t^2 + x^2 + y^2 + z^2 (2.18)$$

is a Lorentz invariant, meaning that it does not change when we transform between frames,

$$-c^{2}t^{2} + x^{2} + y^{2} + z^{2} = -c^{2}t'^{2} + x'^{2} + y'^{2} + z'^{2}.$$
 (2.19)

If the origins of the two different coordinate systems do not coincide, the spatial and temporal differences are unaffected, and so we can write the Lorentz invariant as

$$\Delta s^2 \equiv -c^2 \Delta t^2 + \Delta x^2 + \Delta y^2 + \Delta z^2, \qquad (2.20)$$

where  $\Delta x = x^{(2)} - x^{(1)}$  is the difference in coordinates of two events.

If the spacetime interval vanishes,  $\Delta s^2 = 0$ , then this implies that the two events are separated by a light signal. The fact that  $\Delta s^2$  is invariant then implies that the speed of light c is invariant, as we expect.

#### 2.3 Lorentz Metric

Instead of writing out the Lorentz interval, we can instead define a tensor

$$\eta_{\mu\nu} \equiv \begin{bmatrix} -1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix}. \tag{2.21}$$

The Lorentz interval can then be expressed as

$$\Delta s^2 = \eta_{\mu\nu} \Delta x^{\mu} \Delta x^{\nu} \,. \tag{2.22}$$

We can take this further by defining

$$\Delta x_{\mu} \equiv \eta_{\mu\nu} \Delta x^{\nu} \,, \tag{2.23}$$

which allows us to express the Lorentz interval as

$$\Delta s^2 = \Delta x_\mu \Delta x^\mu \,. \tag{2.24}$$

We can now generalize this notation to allow us to lower indices of any tensor object using the metric:

$$T^{\cdots}_{\mu} = \eta_{\mu\nu} T^{\cdots\nu\cdots}. \tag{2.25}$$

We can similarly use the metric to raise indices. To do so, we first introduce the inverse metric  $\eta^{\mu\nu}$ , which is defined by the relation

$$\eta^{\mu\alpha}\eta_{\alpha\nu} = \eta_{\nu\beta}\eta^{\beta\mu} = \delta^{\mu}_{\nu} \,. \tag{2.26}$$

For the moment, this may seem like an odd definition, because  $\eta = \eta^{-1}$ , but it is still useful to take these definitions because in the future we will deal with metrics that are not equal to their own inverse. This new quantity allows us to raise indices, such as

$$\Delta x^{\mu} = \eta^{\mu\nu} \Delta x_{\nu} \,. \tag{2.27}$$

If an index is lowered and then raised, or vice versa, then the original tensor is recovered. More generally, we have

<span id="page-6-0"></span>
$$T^{\cdots\mu\cdots} = \eta^{\mu\nu}T^{\cdots}_{\phantom{\alpha}\nu}. \tag{2.28}$$

We can now show a special property of the Lorentz transformation: it leaves the metric invariant. We begin by using the fact that the spacetime interval is invariant:

$$\Delta s'^{2} = \Delta s^{2}$$

$$= \eta_{\mu\nu} \Delta x^{\mu} \Delta x^{\nu}$$

$$= \eta_{\mu\nu} \Lambda^{\mu}_{\ \mu'} \Delta x^{\mu'} \Lambda^{\nu}_{\ \nu'} \Delta x^{\nu'}$$

$$= \eta_{\mu\nu} \Lambda^{\mu}_{\ \mu'} \Lambda^{\nu}_{\ \nu'} \Delta x^{\mu'} \Delta x^{\nu'}.$$
(2.29)

On the other hand, we have

<span id="page-6-1"></span>
$$\Delta s^{\prime 2} = \eta_{\mu'\nu'} \Delta x^{\mu'} \Delta x^{\nu'} \,. \tag{2.30}$$

Since Eqs. (2.29) and (2.30) must match for every  $\Delta x^{\mu'}$ , we conclude that

$$\boxed{\eta_{\mu\nu}\Lambda^{\mu}_{\ \mu'}\Lambda^{\nu}_{\ \nu'} = \eta_{\mu'\nu'}}.$$
(2.31)

In fact, this is typically used as the defining quality of a Lorentz transformation: the group of Lorentz transformations is precisely the group of transformations that satisfy this property.

We can write this as a matrix equation by being careful with our indices. We have

$$\Lambda^{\mu}_{\ \mu'}\eta_{\mu\nu}\Lambda^{\nu}_{\ \nu'} = \eta_{\mu'\nu'} \,. \tag{2.32}$$

By using the transpose

$$\left(\Lambda^{\mathrm{T}}\right)_{\mu'}^{\ \mu} \equiv \Lambda^{\mu}_{\ \mu'}, \tag{2.33}$$

we can write this as

$$(\Lambda^{T})_{\mu'}^{\ \mu} \eta_{\mu\nu} \Lambda^{\nu}_{\ \nu'} = \eta_{\mu'\nu'}. \tag{2.34}$$

<span id="page-7-0"></span>Since we are only contracting adjacent indices in this expression, we can write it directly as a matrix equation,

$$\boxed{\Lambda^{\mathrm{T}} \eta \Lambda = \eta}. \tag{2.35}$$

By inverting the matrices to move them to other sides of the equation, we can also write this in the form

$$\boxed{\eta^{-1}\Lambda^{\mathrm{T}}\eta = \Lambda^{-1}}.$$
 (2.36)

## 2.4 Curved Spacetime

We now wish to generalize the concept of the metric to a non-Euclidean space (i.e. a non-Minkowskian spacetime). Whereas before we wrote

$$\Delta s^2 = \eta_{\mu\nu} \Delta x^{\mu} \Delta x^{\nu} \tag{2.37}$$

for arbitrarily large separations ∆x µ , this no longer makes sense in a curve spacetime, because the metric varies. Thus, we can only we can only write a simple expression for infinitesimal separations dx µ . Furthermore, we will denote the metric by gµν(x) rather than ηµν to make it clear that we are talking about a general curved metric,

$$ds^{2} = g_{\mu\nu}(x) dx^{\mu} dx^{\nu}.$$
 (2.38)

Note that the metric gµν(x) is now a function of spacetime.

It is worth mentioning that there is nothing special or intrinsic about our choice of coordinates; they are simply one of many ways of assigning coordinates to spacetime, and each way is as good as any other (though certain choices can make particular calculations easier).

We do assume that gµν(x) has the signature [−1, 1, 1, 1], meaning that it has three positive eigenvalues and one negative eigenvalue. This ensures that our spacetime has one temporal direction and three spatial directions.

We will now make another definition to make our lives easier. For any massive object moving through spacetime, two points on its worldline will be timelike separated, because the object is moving at speed less than c (we will set c = 1 from here on out). As such, the spacetime interval between these points will be ds<sup>2</sup> < 0. This is inconvenient, so we define

$$d\tau^2 \equiv -ds^2. (2.39)$$

This dτ is precisely the proper time, meaning the time interval measured on a clock carried by a traveler travelling at the right velocity to travel from the first event to the second.

## 2.5 Paths in Spacetime

Consider a trajectory through spacetime between points A and B, which we will denote by x µ (λ). Here, λ is a parameter that runs between some λ<sup>1</sup> at endpoint A and λ<sup>2</sup> at endpoint B between the initial and final points of the trajectory. For each value of λ, the quantity x µ (λ) gives the spacetime coordinate of the corresponding point on the trajectory.

We want to write the length of this path, which will be the proper time. This length is given by

$$D = \int_{A}^{B} d\tau . \tag{2.40}$$

This is precisely the total time measured on the watch of a traveller moving along this spacetime trajectory, which is the proper time. We can compute this as

$$D = \int_{A}^{B} d\tau = \int_{\lambda_{1}}^{\lambda_{2}} \frac{d\tau}{d\lambda} d\lambda.$$
 (2.41)

We can express dτ as

$$d\tau = \sqrt{-g_{\mu\nu}(x(\lambda))} \, dx^{\mu} \, dx^{\nu} = \sqrt{-g_{\mu\nu}(x(\lambda))} \frac{dx^{\mu}}{d\lambda} \frac{dx^{\nu}}{d\lambda} \, d\lambda \,. \tag{2.42}$$

Thus, we have

$$D = \int_{\lambda_1}^{\lambda_2} \sqrt{-g_{\mu\nu}(x(\lambda)) \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda}} \,\mathrm{d}\lambda \,. \tag{2.43}$$

We then define a geodesic as a stationary point of the function D. We see then that unlike in classical physics, where gravity is a force that acts on particles, in general relativity gravity arises as a result of curved spacetime, in which particles in free fall move along geodesics, which are the closest thing to straight lines through the curved spacetime.

# 3 Lecture 3 (Feb. 21, 2017)

## 3.1 The Metric: Description of Riemannian Geometry

The general idea is that distances are always defined by a quadratic form

$$ds^2 = g_{\mu\nu}(x)dx^{\mu}dx^{\nu}, \qquad (3.1)$$

where gµν(x) is the metric. Here, µ runs through the values 0, 1, 2, 3.

An important difference between general relativity and special relativity is that space can be curved, so unlike in the case of flat space, the only simple expression for distance we can write down is for infinitesimal distances. The coordinates are simply an arbitrary way of labelling the points in the (3 + 1)-dimensional spacetime, and so we cannot immediately infer distances by looking at the coordinates.

The metric gµν(x) has signature (−1, 1, 1, 1), which indicates the signs of the eigenvalues of the metric as a matrix. We can always find a coordinate system such that in the neighborhood of any particular point in spacetime, the metric looks arbitrarily close to that of special relativity. This is precisely why we allow the metric to be quadratic, because it allows such a linearization. In order to guarantee this property, we cannot change the signature of the metric.

Starting now, we will set c = 1.

In the absence of external forces, particles in spacetime travel along geodesics, which are essentially the closest paths in the curved spacetime to straight lines. Today, we want to derive the geodesic equation, which defines the curve on which free-falling particles will travel.

Particles must always move along timelike trajectories, because particles can only travel at up to the speed of light. It is thus conventional to define

$$d\tau^2 \equiv -ds^2. (3.2)$$

This quantity has a natural interpretation; everything we learned from special relativity still applies in general relativity, because we can always go to a coordinate system that is locally flat. If the separation dτ 2 is positive, then this means we have a timelike separation, and we can then go to a frame in which the two events happen at the same spatial location. In this frame, we simply have dτ <sup>2</sup> = dt 2 . Thus, dτ is the proper time between the two events, that is, the time as measured on a clock that moves from one event to the other at uniform velocity.

The concept of constant velocity is somewhat problematic because we have not defined what coordinate systems we are using, but this concept does make sense so long as our coordinate system is smooth (differentiable) and the separation is infinitesimal (any acceleration caused by curving of spacetime will be second order in the infinitesimal separation).

## 3.2 Geodesics

Now let us consider a trajectory connecting two points A and B in spacetime. We will parametrize the curve by the parameter λ, such that λ = λ<sup>1</sup> at point A and λ = λ<sup>2</sup> at point B. The trajectory can then be written as a function x µ (λ). Note that the parameter λ is not unique, as there are many ways we could parametrize the trajectory.

The length of the trajectory can then be computed as

$$D = \int_{A}^{B} d\tau = \int_{\lambda_{1}}^{\lambda^{2}} \frac{d\tau}{d\lambda} d\lambda.$$
 (3.3)

We can express the proper time as

<span id="page-9-0"></span>
$$d\tau = \sqrt{-g_{\mu\nu}(x(\lambda)) dx^{\mu} dx^{\nu}} = \sqrt{-g_{\mu\nu}(x(\lambda)) \frac{dx^{\mu}}{d\lambda} \frac{dx^{\mu}}{d\lambda}} d\lambda.$$
 (3.4)

We can then write

$$D = \int_{\lambda_1}^{\lambda_2} \sqrt{-g_{\mu\nu}(x(\lambda))} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \,\mathrm{d}\lambda.$$
 (3.5)

This path length is the proper time experienced by an observer travelling along the trajectory.

A geodesic is a trajectory x µ (λ) for which this length D is stationary, meaning that the firstorder variation of D due to a small change in the path vanishes. Thus, in order to determine the condition for D to be stationary, we need to consider a nearby path

$$\tilde{x}^{\mu}(\lambda) = x^{\mu}(\lambda) + \delta x^{\mu}(\lambda). \tag{3.6}$$

We assume that δx<sup>µ</sup> (λ) is small enough that we can treat it to first order, and we will insist that the variation of D vanish when we do so. We must guarantee that the endpoints A and B of the path remain fixed, so we fix

$$\delta x^{\mu}(\lambda_1) = \delta x^{\mu}(\lambda_2) = 0. \tag{3.7}$$

We now wish to calculate

$$\delta D = D[x^{\mu}(\lambda) + \delta x^{\mu}(\lambda)] - D[x^{\mu}(\lambda)]. \tag{3.8}$$

Here, the square brackets are used to indicate that D is a functional, rather than simply a function; its argument is itself a function, and D depends on all values of the function it takes as input. Before dealing with the form of D given in Eq. [\(3.5\)](#page-9-0), we will derive a general formula by considering

$$D = \int_{\lambda_1}^{\lambda_2} L\left(x^{\mu}(\lambda), \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\right) \mathrm{d}\lambda, \qquad (3.9)$$

and we can specialize later. The variation is

$$\delta D = \int_{\lambda_1}^{\lambda_2} \left\{ \frac{\partial L}{\partial x^{\mu}}(x(\lambda)) \delta x^{\mu} + \frac{\partial L}{\partial \left(\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\right)}(x(\lambda)) \delta \left(\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\right) \right\} \mathrm{d}\lambda \,. \tag{3.10}$$

The first term in brackets is essentially the first term in a Taylor expansion of L, which is all we need because we are treating the variation δx<sup>µ</sup> only to first order. The second term is the same, but expanding with respect to the four variables <sup>d</sup><sup>x</sup> µ dλ ; as far as L is concerned, these are simply additional variables. We now note that

$$\delta\left(\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\right) = \frac{\mathrm{d}\tilde{x}^{\mu}}{\mathrm{d}\lambda} - \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} = \frac{\mathrm{d}}{\mathrm{d}\lambda}[(x^{\mu}(\lambda) + \delta x^{\mu}(\lambda)) - x^{\mu}(\lambda)] = \frac{\mathrm{d}}{\mathrm{d}\lambda}\delta x^{\mu}(\lambda). \tag{3.11}$$

We then have

$$\delta D = \int_{\lambda_1}^{\lambda_2} \left\{ \frac{\partial L}{\partial x^{\mu}} \delta x^{\mu} + \frac{\partial L}{\partial \left(\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\right)} \frac{\mathrm{d}}{\mathrm{d}\lambda} \delta x^{\mu}(\lambda) \right\} \mathrm{d}\lambda \,. \tag{3.12}$$

The trick at this point is to integrate the second term by parts, which will introduce a surface term:

$$\delta D = \int_{\lambda_1}^{\lambda_2} \left\{ \frac{\partial L}{\partial x^{\mu}} \delta x^{\mu} - \frac{\mathrm{d}}{\mathrm{d}\lambda} \left[ \frac{\partial L}{\partial \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right)} \right] \delta x^{\mu} \right\} \mathrm{d}\lambda + \left[ \frac{\partial L}{\partial \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right)} \delta x^{\mu}(\lambda) \right]_{\lambda_1}^{\lambda_2}. \tag{3.13}$$

The surface term vanishes precisely because we chose the boundary conditions

$$\delta x^{\mu}(\lambda_1) = \delta x^{\mu}(\lambda_2) = 0. \tag{3.14}$$

Thus, we are left with

$$\delta D = \int_{\lambda_1}^{\lambda_2} \left\{ \frac{\partial L}{\partial x^{\mu}} - \frac{\mathrm{d}}{\mathrm{d}\lambda} \left[ \frac{\partial L}{\partial \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right)} \right] \right\} \delta x^{\mu} \, \mathrm{d}\lambda \,. \tag{3.15}$$

Now, we insist that δD = 0. Normally, the requirement that the integral vanishes does not imply that the integrand must vanish; however, in this case we know that δD must vanish for every possible δx<sup>µ</sup> , which necessitates that the term in brackets must vanish identically. We will now give a rough argument for why this should be true, via a proof by contradiction. For ease of notation, define

$$\{\}_{\mu} \equiv \left\{ \frac{\partial L}{\partial x^{\mu}} - \frac{\mathrm{d}}{\mathrm{d}\lambda} \left[ \frac{\partial L}{\partial \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right)} \right] \right\}. \tag{3.16}$$

Now, suppose by way of contradiction that {}<sup>µ</sup> > 0 for some λ0, and assume that all quantities of interest are continuous. Thus, because {}<sup>µ</sup> is positive at λ<sup>0</sup> and {}<sup>µ</sup> is continuous, there must be some neighborhood of λ<sup>0</sup> for which {}<sup>µ</sup> > 0. We can then choose a δx<sup>µ</sup> (λ) to be zero everywhere outside this neighborhood and nonzero within the neighborhood, which results in  $\delta D \neq 0$ . This is a contradiction, and thus completes the proof. (Note that the same argument works for the case where  $\{\}_{\mu} < 0$  at some  $\lambda_0$ .)

At this point, we have derived the Euler-Lagrange equations

$$\frac{\mathrm{d}}{\mathrm{d}\lambda} \left[ \frac{\partial L}{\partial \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right)} \right] = \frac{\partial L}{\partial x^{\mu}} \,. \tag{3.17}$$

Note that this is actually four equations, one for each value of  $\mu$ .

We now wish to apply this to our particular Lagrangian,

$$L = \sqrt{-g_{\mu\nu}(x(\lambda))} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}.$$
 (3.18)

Note that the derivatives  $\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}$  are considered as independent variables from  $x^{\mu}$ , so that

$$\frac{\partial}{\partial \left(\frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}\right)} \left[\frac{\mathrm{d}x^{\rho}}{\mathrm{d}\lambda}\right] = \delta^{\rho}_{\sigma}. \tag{3.19}$$

We can then compute

$$\frac{\partial L}{\partial x^{\sigma}} = -\frac{1}{2L} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} , \qquad (3.20)$$

$$\frac{\partial L}{\partial \left(\frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}\right)} = -\frac{1}{2L} \left[ \delta^{\mu}_{\sigma} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} + \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \delta^{\nu}_{\sigma} \right] g_{\mu\nu} . \tag{3.21}$$

The second expression can be simplified by noting that  $g_{\mu\nu}$  is symmetric, which allows us to write

$$\frac{\partial L}{\partial x^{\sigma}} = -\frac{1}{2L} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} , \qquad (3.22)$$

$$\frac{\partial L}{\partial \left(\frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}\right)} = -\frac{1}{L} g_{\mu\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} \,. \tag{3.23}$$

The Euler-Lagrange equations then tell us

$$\frac{\mathrm{d}}{\mathrm{d}\lambda} \left[ \frac{1}{L} g_{\sigma\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} \right] = \frac{1}{2L} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} . \tag{3.24}$$

This is the result for a completely arbitrary parameter; it is messy, because the derivative on the left acts on  $\frac{1}{L}$  as well as the rest of the expression. We can simplify this by choosing a preferred parametrization. The Lagrangian is

$$L = \sqrt{-g_{\mu\nu}(x(\lambda))\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}} = \frac{\mathrm{d}\tau}{\mathrm{d}\lambda}.$$
 (3.25)

We can simplify this expression by setting  $\lambda = \tau$ , which then sets

<span id="page-11-0"></span>
$$L = 1. (3.26)$$

The geodesic equation then simplifies to

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\sigma\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{1}{2} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \,. \tag{3.27}$$

This is the geodesic equation. Though many texts treat this simply as an intermediate result to finding the form of the geodesic equation we will write down later, it is very useful in its own rite. First, it only has one term involving a derivative of gµν, while the other form involves three. Second, if the metric is independent of any coordinate x <sup>α</sup>, then the right-hand side vanishes, telling us immediately that

$$g_{\alpha\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} = \text{constant} \,.$$
 (3.28)

Could we have started with τ as our parameter to begin with and avoided the extra complications in this computation? If we had started by parametrizing our paths by τ , then the trajectory length would be

$$D = \int_{\tau_1}^{\tau_2} d\tau = \tau_2 - \tau_1, \qquad (3.29)$$

and it would be hard to tell how to vary the path. To vary the path, we would have to allow τ<sup>2</sup> to depend on the path, requiring a more complicated formalism. By parametrizing the path with parameter λ, we were able to easily insist that the λ1, λ<sup>2</sup> were the same for both the original and the varied paths. This raises the question of whether it is valid to set λ = τ after the fact; it is, because the geodesic equation we arrived at in terms of the parameter λ is local in λ, meaning it is independent of global stationary points. After arriving at this equation, we can then set the parameter λ = τ .

We will now derive the standard form of the geodesic equation. We expand the left-hand side of Eq. [\(3.27\)](#page-11-0) as

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\sigma\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \left( \frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \right) \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} + g_{\sigma\nu} \frac{\mathrm{d}^{2}x^{\nu}}{\mathrm{d}\tau^{2}} \,. \tag{3.30}$$

Plugging this back into Eq. [\(3.27\)](#page-11-0) and rearranging terms then yields

$$g_{\sigma\nu} \frac{\mathrm{d}^2 x^{\nu}}{\mathrm{d}\tau^2} = -\frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} + \frac{1}{2} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \,. \tag{3.31}$$

We can factor the expression on the right side to reach

$$g_{\sigma\nu} \frac{\mathrm{d}^2 x^{\nu}}{\mathrm{d}\tau^2} = -\frac{1}{2} \left[ \frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} + \frac{\partial g_{\sigma\mu}}{\partial x^{\nu}} - \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \right] \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} , \tag{3.32}$$

where we have used the fact that

$$\frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} = \frac{1}{2} \left( \frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} + \frac{\partial g_{\sigma\mu}}{\partial x^{\nu}} \right) \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} , \qquad (3.33)$$

which follows because

<span id="page-12-1"></span><span id="page-12-0"></span>
$$\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \tag{3.34}$$

is symmetric in the indices µ and ν. The final step to simplifying this equation is to define the inverse metric g µν, which is defined by the property

$$g^{\mu\sigma}g_{\sigma\nu} = g_{\nu\sigma}g^{\sigma\mu} = \delta^{\mu}_{\nu}. \tag{3.35}$$

We can then contract both sides of Eq. [\(3.32\)](#page-12-0) with the inverse metric g λσ to reach

$$\frac{\mathrm{d}^2 x^{\lambda}}{\mathrm{d}\tau^2} = -\Gamma^{\lambda}_{\mu\nu} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau},$$
(3.36)

where we have defined

$$\Gamma^{\lambda}_{\mu\nu} \equiv \frac{1}{2} g^{\lambda\sigma} \left[ \frac{\partial g_{\sigma\nu}}{\partial x^{\mu}} + \frac{\partial g_{\sigma\mu}}{\partial x^{\nu}} - \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \right], \tag{3.37}$$

which is called the *affine connection* or the *Christoffel symbol*. The geodesic equation as given in Eq. (3.36) is in the standard form.

### **3.2.1** Example

Consider the two-dimensional metric

$$g_{ij} = \begin{pmatrix} 1 & 0 \\ 0 & x^2 \end{pmatrix}, \quad x^i = (x, y).$$
 (3.38)

The spacetime interval then takes the form

$$ds^2 = dx^2 + x^2 dy^2. (3.39)$$

We can work out the Christoffel symbols, and we find

$$\Gamma_{xx}^{x} = \Gamma_{xy}^{x} = \Gamma_{yx}^{x} = \Gamma_{yy}^{y} = 0, 
\Gamma_{yy}^{x} = \frac{1}{2}g^{xx}(-\partial_{x}g_{yy}) = -x, 
\Gamma_{xy}^{y} = \Gamma_{yx}^{y} = \frac{1}{2}g^{yy}(\partial_{x}g_{yy}) = \frac{x}{x^{2}} = \frac{1}{x}.$$
(3.40)

Thus, the geodesic equation gives us the equations of motion

$$\ddot{x} = -\Gamma_{yy}^x \dot{y}\dot{y} = x\dot{y}\dot{y}\,,\tag{3.41}$$

$$\ddot{y} = -\Gamma^{y}_{xy}\dot{x}\dot{y} - \Gamma^{y}_{yx}\dot{x}\dot{y} = -\frac{2}{x}\dot{x}\dot{y}. \tag{3.42}$$

We note that the metric has the same form as that of standard polar coordinates for the plane,

$$ds^2 = dr^2 + r^2 d\theta^2, (3.43)$$

so although the metric as we have written it does not immediately appear to be the one for flat space, it turns out that a change of coordinates will leave us with the metric for flat space. Thus, this metric does in fact describe flat space, and the geodesics are actually straight lines in the Cartesian coordinates.

# 4 Lecture 4 (Feb. 22, 2017)

#### 4.1 General Coordinate Transformations

In special relatively, the only form of transformations we talk about are linear transformations, namely the Lorentz transformations

$$x^{\mu} \to x^{\nu'} = \Lambda_{\mu}^{\nu'} x^{\mu} \,. \tag{4.1}$$

These transformations take us from one frame where the laws of physics are simple (special relativity) to another frame where the same simple laws apply.

In general relativity, we deal with general coordinate transformations, which take us from any coordinate system to any other:

$$x^{\mu} \to x^{\nu'} = f^{\nu'}(x)$$
. (4.2)

We do impose some minor restrictions on the function f: we assume that  $f^{\nu'}(x)$  is smooth (or just  $C^1$ , i.e. first-differentiable) and invertible. We can then compute  $g_{\mu'\nu'}$ . From  $x^{\nu'} = f^{\nu'}(x)$  we can write

$$dx^{\nu'} = \frac{\partial f^{\nu'}}{\partial x^{\mu}} dx^{\mu} . \tag{4.3}$$

To simplify notation, we often define the new coordinates directly as a function of the old coordinates,  $x^{\nu'}(x) \equiv f^{\nu'}(x)$ , so we can instead write

<span id="page-14-0"></span>
$$dx^{\nu'} = \frac{\partial x^{\nu'}}{\partial x^{\mu}} dx^{\mu}. \tag{4.4}$$

We can find the new form of the metric by requiring that the spacetime interval be invariant under the change of coordinates:

$$ds^{2} = g_{\mu'\nu'} dx^{\mu'} dx^{\nu'} = g_{\mu\nu} dx^{\mu} dx^{\nu}.$$
(4.5)

Using Eq. (4.4) twice, this gives us

$$g_{\mu'\nu'}\frac{\partial x^{\mu'}}{\partial x^{\mu}}\frac{\partial x^{\nu'}}{\partial x^{\nu}}\,\mathrm{d}x^{\mu}\,\mathrm{d}x^{\nu} = g_{\mu\nu}\,\mathrm{d}x^{\mu}\,\mathrm{d}x^{\nu}. \tag{4.6}$$

This must hold for all differential separations, so we conclude that

<span id="page-14-1"></span>
$$g_{\mu\nu} = \frac{\partial x^{\mu'}}{\partial x^{\mu}} \frac{\partial x^{\nu'}}{\partial x^{\nu}} g_{\mu'\nu'} \,. \tag{4.7}$$

We can invert this relation (using the assumption that the coordinate transformation is invertible) to write

$$g_{\mu'\nu'} = \frac{\partial x^{\mu}}{\partial x^{\mu'}} \frac{\partial x^{\nu}}{\partial x^{\nu'}} g_{\mu\nu}$$
(4.8)

Note that there is a hidden transformation here if we want to express the metric as a function of the coordinates, because on one side of the equation we must use unprimed coordinates, and on the other side we must use the corresponding primed coordinates.

Equation (4.7) is a model for the general transformation rule for covariant (lower-indexed) tensors. This rule is given by

<span id="page-14-2"></span>
$$T_{\mu_1\mu_2\cdots\mu_k} = \frac{\partial x^{\mu'_1}}{\partial x^{\mu_1}} \frac{\partial x^{\mu'_2}}{\partial x^{\mu_2}} \cdots \frac{\partial x^{\mu'_k}}{\partial x^{\mu_k}} T_{\mu'_1\mu'_2\cdots\mu'_k}. \tag{4.9}$$

We insist that the coordinate transformation be invertible, which means we require

$$Det \frac{\partial x^{\mu'}}{\partial x^{\nu}} \neq 0. \tag{4.10}$$

Why is this the necessary statement? If Det  $\frac{\partial x^{\mu'}}{\partial x^{\nu}} = 0$ , then  $\frac{\partial x^{\mu'}}{\partial x^{\nu}}$  must have a zero eigenvector. Thus, there exists a  $\mathrm{d}x^{\nu}$  such that

$$dx^{\mu'} = \frac{\partial x^{\mu'}}{\partial x^{\nu}} dx^{\nu} = 0, \qquad (4.11)$$

meaning that a small change in the coordinates of the unprimed coordinate system is not detectable in the primed coordinate system, meaning that the coordinate transformation can not be inverted.

## 4.2 Embeddings

So far we have talked about transformations from one (3 + 1)-dimensional space to another, but sometimes we are interested in talking about transformations from one space to a higher- or lowerdimensional space. Thus, it is useful to give some formalism for a general embedding, which is a mapping from some space into a higher-dimensional space.

Suppose we have a mapping from R <sup>2</sup> → R 3 . To describe this concretely, we use maps x i (u <sup>α</sup>), where i = 1, 2, 3 and α = 1, 2. Suppose the metric on R 3 is Euclidean, so that gij = δij . Then we can determine the metric on the embedded curved two-dimensional surface from the metric of the three-dimensional space using Eq. [\(4.7\)](#page-14-1), giving

$$g_{\alpha\beta} = \frac{\partial x^{i'}}{\partial u^{\alpha}} \frac{\partial x^{j'}}{\partial u^{\beta}} g_{i'j'}. \tag{4.12}$$

This is called the induced metric, or the pullback of the metric on R 3 . This phrase originates from the fact that we used the maps x i (u <sup>α</sup>), which map "forward" from the coordinates on the surface to the coordinates in R 3 , to "pull back" the metric of R 3 to a metric on the surface.

Note that the affine connection Γ<sup>λ</sup> µν is not a tensor. Why? One important property of tensors is that if a tensor vanishes in one frame, it must vanish in all frames; this can be seen by inspecting the transformation rule Eq. [\(4.9\)](#page-14-2). We saw an example in the previous lecture where the affine connection was zero for the Euclidean plane in Cartesian coordinates but nonzero for the Euclidean plane in polar coordinates, so clearly it cannot be a tensor.

## 4.3 Example

Recall the geodesic equation

$$\frac{\mathrm{d}^2 x^{\lambda}}{\mathrm{d}\tau^2} = -\Gamma^{\lambda}_{\mu\nu} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \,, \tag{4.13}$$

which describes a freely falling particle not under the influence of any force other than gravity.

Suppose that

$$ds^{2} = -dt^{2} + g_{ij} dx^{i} dx^{j}, \qquad (4.14)$$

for i, j = 1, 2, 3. In this case, the only nonzero components of the affine connection are the Γ<sup>i</sup> jk. From the geodesic equation, we then see that

$$\frac{\mathrm{d}^2 t}{\mathrm{d}\tau^2} = 0, \quad \frac{\mathrm{d}^2 x^i}{\mathrm{d}\tau^2} = -\Gamma^i_{jk} \frac{\mathrm{d}x^j}{\mathrm{d}\tau} \frac{\mathrm{d}x^k}{\mathrm{d}\tau}.$$
 (4.15)

From the first of these equations, we see that

$$\frac{\mathrm{d}t}{\mathrm{d}\tau} = \text{constant} \,. \tag{4.16}$$

The proper time is given by

$$d\tau^2 = dt^2 - g_{ij} dx^i dx^j. (4.17)$$

Dividing through by dτ 2 , this becomes

$$1 = \left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^2 - g_{ij}\frac{\mathrm{d}x^i}{\mathrm{d}\tau}\frac{\mathrm{d}x^j}{\mathrm{d}\tau}.$$
 (4.18)

Because <sup>d</sup><sup>t</sup> dτ is a constant, we thus conclude that

$$g_{ij} \frac{\mathrm{d}x^i}{\mathrm{d}\tau} \frac{\mathrm{d}x^j}{\mathrm{d}\tau} = \text{constant} \,.$$
 (4.19)

This can then be interpreted as a kinetic energy for the system that will be conserved.

## 4.4 The Equivalence Principle

The Weak Equivalence Principle is the statement that for any object, the inertial mass is equal to the gravitational mass. By inertial mass, we mean the parameter m appearing in the equation F = ma, which determines how the object responds to forces acting on it; by gravitational mass, we mean the parameter m appearing in the gravitational force law F = −m∇φ, where φ is the gravitational potential. This statement tells us that the acceleration under gravity is the same for all objects.

General relativity uses a stronger form of the equivalence principle, called the Einstein Equivalence Principle. The Einstein Equivalence Principle says that local physics in a locally free-falling frame is indistinguishable from special relativity. Another way to say this is that local physics in a gravitational field is indistinguishable from the physics in an accelerating reference frame.

The classic picture to demonstrate the equivalence principle is to imagine observers inside a box sitting at rest on the surface of the Earth; the statement is that this situation can never be distinguished, by an observer within the box, from the situation in which the box is actually sitting in a spaceship that is accelerating. There are some subtleties with this picture; in actuality, one could tell the difference by measuring the local gravity vector at opposite ends of the box, which would point in slightly different directions if the box were on Earth. This is why the equivalence principle only holds for very small distances.

## 4.5 Locally Inertial Frames

We will now discuss an important theorem of Riemannian geometry, which tells us that we can always find a coordinate transformation that causes the metric to be Minkowskian and have vanishing derivative at a particular point. This is very useful, because it allows us to locally treat general relativity in the same way that we treat special relativity.

<span id="page-16-1"></span>Theorem 1 For any point x<sup>0</sup> in spacetime, we can find a local inertial coordinate system (also called a free-falling coordinate system, a locally Minkowskian coordinate system, or geodesic normal coordinates) such that

$$g_{\mu\nu}(x_0) = \eta_{\mu\nu} \,, \quad \partial_{\lambda}g_{\mu\nu}(x_0) = 0 \,.$$
 (4.20)

<span id="page-16-0"></span>2

Note that ∂λgµν(x0) = 0 implies that Γ<sup>λ</sup> µν(x0) = 0.

Proof We will first show that we can achieve gµν(x0) = ηµν. We know that the metric transforms under a general coordinate transformation as

$$g_{\mu\nu} = \frac{\partial x^{\lambda'}}{\partial x^{\mu}} \frac{\partial x^{\sigma'}}{\partial x^{\nu}} g_{\lambda'\sigma'}. \tag{4.21}$$

We want to appeal to our intuition about matrices, and so we define the matrix

$$M = [M]_{\lambda'\mu} = \frac{\partial x^{\lambda'}}{\partial x^{\mu}} \tag{4.22}$$

as the transformation matrix of our coordinate transformation. Being careful with the order of indices, we can then write transformation rule for the metric as

$$g_{\mu\nu} = M^{\mathrm{T}}gM. \tag{4.23}$$

The metric g can be diagonalized by some orthogonal transformation  $\mathcal{O}$ , with  $\mathcal{O}^{\mathrm{T}} = \mathcal{O}^{-1}$ , allowing us to write

$$q^{\text{diag}} = \mathcal{O}^{\mathrm{T}} q \mathcal{O}. \tag{4.24}$$

This gets us to a diagonal metric tensor, but we want eigenvalues (-1, 1, 1, 1). We can achieve this by using another transformation that scales the eigenvalues; we define

$$\tilde{M} = \begin{bmatrix} m_0 & 0 & 0 & 0 \\ 0 & m_1 & 0 & 0 \\ 0 & 0 & m_2 & 0 \\ 0 & 0 & 0 & m_3 \end{bmatrix}. \tag{4.25}$$

Then

$$g = \tilde{M}^{\mathrm{T}} g^{\mathrm{diag}} \tilde{M} \,. \tag{4.26}$$

We have insisted that the metric have signature (-,+,+,+), and so we have now constructed a transformation that gives us

$$g = \eta. (4.27)$$

The transformation that leads to  $g_{\mu\nu}(x_0) = \eta_{\mu\nu}$  is not unique, because it can be followed by any Lorentz transformation, which will leave the Minkowski metric  $\eta_{\mu\nu}$  invariant, as described by Eq. (2.35),

$$\Lambda^{\mathrm{T}} \eta \Lambda = \eta \,. \tag{4.28}$$

Thus, the local inertial coordinate system is defined only up to a Lorentz transformation. The matrix M of Eq. (4.22) has sixteen independent components, which includes six for the orthogonal transformation to diagonalize g, four to rescale the eigenvalues to have magnitude 1, and six that correspond to the remaining freedom of an arbitrary Lorentz transformation.

Now we must show that we can further transform the coordinates so that the derivative of the metric vanishes. Before we continue, however, it will be useful to take a moment and discuss the counting of degrees of freedom. Suppose that  $S_{\mu_1\cdots\mu_R}$  is symmetric, and suppose that  $\mu$  takes on D distinct values (in our case, we will have D=4). How many independent components N are there? A particular independent component can be picked out by specifying how many of the indices have value 0, how many have value 1, etc. Because the tensor is symmetric by definition, it does not matter which indices take which values.

This observation allows us to turn the problem into a purely combinatorial one. Consider D-1 partitions that subdivide an interval into D segments, and R dots (one for each index) that lie in the segments between the partitions, such as

$$\bullet \bullet | \bullet | \bullet \bullet \bullet | \cdots | \bullet . \tag{4.29}$$

Such an arrangement represents a choice of values for the indices of  $S_{\mu_1\cdots\mu_R}$ ; the number of dots in the *i*th segment is the number of indices that have value *i*. Thus, counting the number of possible such arrangements gives us the answer to our problem. We are arranging R + D - 1 objects; the number of ways to do so if every object were distinct would be

$$(R+D-1)!$$
. (4.30)

But here we have overcounted because the objects are not all distinct. For any choice of ordering, we could rearrange all the dots among themselves, which could be done in R! ways, and rearrange the partitions among themselves, which could be done in (D-1)! ways. Thus, the number of arrangements is

<span id="page-18-1"></span>
$$N = \frac{(R+D-1)!}{R!(D-1)!}. (4.31)$$

This is the number of independent components of a symmetric, R-index tensor for which the indices take on D possible values.

Now we return to the proof. Assume we have already done the necessary transformations to reach  $g = \eta$  at  $x_0$ . We let  $x_0 = 0$  without loss of generality. In the primed coordinates, we have  $g_{\mu'\nu'}(0) = \eta_{\mu'\nu'}(0)$ . We can then expand the metric in a Taylor series as

$$g_{\mu'\nu'}(x) = \eta_{\mu'\nu'} + A_{\mu'\nu'\lambda'}x^{\lambda'} + \frac{1}{2}B_{\mu'\nu'\lambda'\sigma'}x^{\lambda'}x^{\sigma'} + \cdots$$
 (4.32)

The tensor  $A_{\mu'\nu'\lambda'}$  is symmetric in  $\mu', \nu'$ , which gives us ten independent components, and for each of these there are four possible values of  $\lambda'$ , so  $A_{\mu'\nu'\lambda'}$  has 40 independent components. Similarly,  $B_{\mu'\nu'\lambda'\sigma'}$  is symmetric in  $\mu', \nu'$  and symmetric in  $\lambda', \sigma'$ , which gives 100 independent components.

We will now briefly abandon the Carroll notation for indices, so that indices will just represent numbers that run from 0 to 3, and we will put primes on the coordinates themselves. We consider a coordinate transformation to the unprimed frame, in which we will try to arrange for  $\partial_{\lambda}g_{\mu\nu}(0) = 0$ . The coordinates  $x'^{\lambda}$  and  $x^{\lambda}$  can be related by an infinite power series

$$x^{\prime \lambda} = x^{\lambda} + \frac{1}{2} C^{\lambda}_{\ \mu\nu} x^{\mu} x^{\nu} + \frac{1}{3} D^{\lambda}_{\ \mu\nu\rho} x^{\mu} x^{\nu} x^{\rho} + \cdots$$
 (4.33)

(The first term on the right is the reason why the Carroll convention for indices would be awkward—we want to have the same index on both a primed and an unprimed coordinate.) The metric in the unprimed frame can be written as

<span id="page-18-0"></span>
$$g_{\mu\nu} = \frac{\partial x^{\prime\lambda}}{\partial x^{\mu}} \frac{\partial x^{\prime\sigma}}{\partial x^{\nu}} g_{\lambda\sigma}^{\prime} . \tag{4.34}$$

Using the expansion Eq. (4.33) gives us

$$\frac{\partial x'^{\lambda}}{\partial x^{\mu}} = \delta^{\lambda}_{\mu} + C^{\lambda}_{\mu\nu} x^{\nu} + D^{\lambda}_{\mu\nu\rho} x^{\nu} x^{\rho} + \cdots$$
 (4.35)

Using this along with Eq. (4.32), we have

$$g_{\mu\nu} = \frac{\partial x'^{\lambda}}{\partial x^{\mu}} \frac{\partial x'^{\sigma}}{\partial x^{\nu}} g'_{\lambda\sigma}$$

$$= \left[ \delta^{\lambda}_{\mu} + C^{\lambda}_{\mu\rho} x^{\rho} + \cdots \right] \left[ \delta^{\sigma}_{\nu} + C^{\sigma}_{\nu\rho} x^{\rho} + \cdots \right] \left[ \eta_{\lambda\sigma} + A_{\lambda\sigma\tau} x'^{\tau} + \cdots \right].$$

$$(4.36)$$

We want to express the right-hand side in terms of unprimed coordinates, so the quantity  $x'^{\tau}$  must be further expanded using Eq. (4.33). Expanding out the full right-hand side order by order, we find to first order that

$$g_{\mu\nu} = \eta_{\mu\nu} + C_{\nu\mu\rho}x^{\rho} + C_{\mu\nu\rho}x^{\rho} + A_{\mu\nu\rho}x^{\rho}. \tag{4.37}$$

We see that to make the derivative of  $g_{\mu\nu}$  vanish to first order, it is sufficient to achieve

<span id="page-18-2"></span>
$$C_{\nu\mu\rho} + C_{\mu\nu\rho} = -A_{\mu\nu\rho} \,. \tag{4.38}$$

Recall that, for our problem, the As are given, determined by the metric in the primed coordinates. Our goal is to find a set of Cs such that  $\partial_{\lambda}g_{\mu\nu}(0) = 0$ . Since  $C_{\mu\nu\rho}$  is symmetric in its last two indices and  $A_{\mu\nu\rho}$  is symmetric in its first two indices, A and C each have 40 independent components. Forty linear equations in 40 unknowns will typically have a solution, but this could fail if the equations are not linearly independent. Next time, we will solve Eq. (4.38), completing the proof.

## 5 Lecture 5 (Feb. 27, 2017)

### 5.1 Locally Inertial Frames

We will now complete the proof of Thm. 1 from last lecture. We will begin by summarizing our progress thus far.

PROOF (CONT.) Thus far, we have chosen  $x_0 = 0$  without loss of generality. We wrote down the transformation of the metric under an arbitrary change of coordinates as

$$g = M^{\mathrm{T}} g' M, \tag{5.1}$$

where

$$M^{\mu'}_{\ \nu} = \frac{\partial x^{\mu'}}{\partial x^{\nu}} \,. \tag{5.2}$$

Note that the matrix M has sixteen parameters. We did this transformation in two steps. First, we diagonalized g (which is always possible because g is symmetric) via an orthogonal matrix  $\mathcal{O}$  as

$$g^{\text{diag}} = \mathcal{O}^{\mathrm{T}} g' \mathcal{O}. \tag{5.3}$$

There are six parameters in the orthogonal matrix  $\mathcal{O}$ . Second, we scaled the eigenvalues of  $g^{\text{diag}}$  using the transformation

$$\eta = \tilde{M}^{\mathrm{T}} g^{\mathrm{diag}} \tilde{M} \,, \tag{5.4}$$

where

$$\tilde{M} = \begin{bmatrix} m_1 & 0 & 0 & 0 \\ 0 & m_2 & 0 & 0 \\ 0 & 0 & m_3 & 0 \\ 0 & 0 & 0 & m_4 \end{bmatrix}. \tag{5.5}$$

This transformation clearly has four parameters.

There are six parameters in M that are undetermined by the transformations we have done thus far (six parameters are fixed by  $\mathcal{O}$  and four by  $\tilde{M}$ ). These six parameters are the parameters of an arbitrary Lorentz transformation, which leaves the Minkowski metric invariant.

For the second half of the proof, we assume that  $g_{\mu'\nu'}(0) = \eta_{\mu'\nu'}$ , but  $\partial_{\lambda'}g_{\mu'\nu'} \neq 0$ . We want to find an unprimed coordinate system in which

$$g_{\mu\nu}(0) = \eta_{\mu\nu} \,, \quad \partial_{\lambda}g_{\mu\nu} = 0 \,. \tag{5.6}$$

In Eq. (4.32), we wrote down a Taylor expansion for the metric

$$g_{\mu'\nu'}(x) = \eta_{\mu'\nu'} + A_{\mu'\nu'\lambda'}x^{\lambda'} + \frac{1}{2}B_{\mu'\nu'\lambda'\sigma'}x^{\lambda'}x^{\sigma'} + \cdots$$
 (5.7)

We noted that A was symmetric in its first two indices, meaning that there are ten parameters in A for each value of  $\lambda'$ , giving a total of 40 parameters in A. The tensor B is symmetric in its first two indices and symmetric in its last two indices, giving a total of 100 parameters in B.

In Eq. (4.33), we constructed a general transformation that leaves things invariant near the origin to first order (abandoning the index notation from Carroll, so that the indices are simply numbers that run from 0 to 3) as

$$x^{\prime \lambda} = x^{\lambda} + \frac{1}{2} C^{\lambda}_{\ \mu\nu} x^{\mu} x^{\nu} + \frac{1}{3} D^{\lambda}_{\ \mu\nu\rho} x^{\mu} x^{\nu} x^{\rho} + \cdots$$
 (5.8)

We note that C is symmetric in its last two indices, meaning it has 40 parameters, and D is symmetric in its final three indices, meaning it has  $4 \cdot \frac{(4+3-1)!}{3!(4-1)!} = 80$  parameters.

We found that the effect of this transformation on the metric is, to first order,

$$g_{\mu\nu} = \frac{\partial x'^{\lambda}}{\partial x^{\mu}} \frac{\partial x'^{\sigma}}{\partial x^{\nu}} g'_{\lambda\sigma} = \eta_{\mu\nu} + C_{\nu\mu\rho} x^{\rho} + C_{\mu\nu\rho} x^{\rho} + A_{\mu\nu\rho} x^{\rho}.$$
 (5.9)

Thus, to make the derivative of  $g_{\mu\nu}$  vanish at first order, we must solve Eq. (4.38),

$$C_{\nu\mu\rho} + C_{\mu\nu\rho} = -A_{\mu\nu\rho}. (5.10)$$

Both A and C have 40 free parameters, and these are 40 equations, so this seems like the kind of system we should be able to solve. One approach would be to write down the correct answer and verify it works. Another approach is to rearrange indices and add and subtract these equations until we find an answer. A third approach is to look at special cases.

We will take yet another approach, which is to take advantage of the symmetries of these objects. Because  $C_{\lambda\mu\nu}$  is symmetric in its last two indices, we can write it in the form

$$C_{\lambda\mu\nu} = C_{\lambda\mu\nu}^{\text{sym}} + C_{\lambda\mu\nu}^{\text{else}}, \tag{5.11}$$

where  $C_{\lambda\mu\nu}^{\text{sym}} = C_{(\lambda\mu\nu)}$  is the fully-symmetrized part of  $C_{\lambda\mu\nu}$ , and  $C_{\lambda\mu\nu}^{\text{else}}$  is whatever is left over. Note that, because  $C_{\lambda\mu\nu}$  is symmetric in its final two indices, so is  $C_{\lambda\mu\nu}^{\text{else}}$ ; because we have removed the fully symmetric piece of  $C_{\lambda\mu\nu}$ , we see that

$$C_{(\lambda\mu\nu)}^{\text{else}} = 0. \tag{5.12}$$

We will use the same decomposition for A:

<span id="page-20-1"></span>
$$A_{\lambda\mu\nu} = A_{\lambda\mu\nu}^{\text{sym}} + A_{\lambda\mu\nu}^{\text{else}}.$$
 (5.13)

We are trying to solve the equation

<span id="page-20-0"></span>
$$C_{\nu\mu\rho} + C_{\mu\nu\rho} = -A_{\mu\nu\rho}. (5.14)$$

Symmetrizing both sides, we reach

$$2C_{\mu\nu\rho}^{\text{sym}} = -A_{\mu\nu\rho}^{\text{sym}}. \tag{5.15}$$

This equation is easily solved:

<span id="page-20-2"></span>
$$C_{\mu\nu\rho}^{\text{sym}} = -\frac{1}{2} A_{\mu\nu\rho}^{\text{sym}}. \tag{5.16}$$

Now we only need to find  $C_{\mu\nu\rho}^{\rm else}$ . Subtracting Eq. (5.15) from Eq. (5.14), we reach

$$C_{\nu\mu\rho}^{\text{else}} + C_{\mu\nu\rho}^{\text{else}} = -A_{\mu\nu\rho}^{\text{else}}. \tag{5.17}$$

Because  $C^{\mathrm{else}}$  is symmetric in its final two indices, we can rewrite this as

$$C_{\nu\mu\rho}^{\text{else}} + C_{\mu\rho\nu}^{\text{else}} = -A_{\mu\nu\rho}^{\text{else}} \,. \tag{5.18}$$

Note that because  $C_{(\lambda\mu\nu)}^{\text{else}} = 0$ , we have

$$C_{\nu\mu\rho}^{\text{else}} + C_{\mu\rho\nu}^{\text{else}} + C_{\rho\nu\mu}^{\text{else}} = 0. \tag{5.19}$$

The first two terms here are exactly the left-hand side of Eq. (5.17), so we can now write

$$-C_{\rho\nu\mu}^{\text{else}} = -A_{\mu\nu\rho}^{\text{else}}.$$
 (5.20)

Now we have both  $C^{\text{sym}}$  and  $C^{\text{else}}$ , so we can put them together to find  $C_{\lambda\mu\nu}$ . We have

$$C_{\lambda\mu\nu} = C_{\lambda\mu\nu}^{\text{sym}} + C_{\lambda\mu\nu}^{\text{else}} = -\frac{1}{2} A_{\mu\nu\lambda}^{\text{sym}} + A_{\mu\nu\lambda}^{\text{else}}.$$
 (5.21)

Here, we have reordered the indices on both terms on the right-hand side; we can write  $A_{\lambda\mu\nu}^{\rm sym} = A_{\mu\nu\lambda}^{\rm sym}$  because  $A^{\rm sym}$  is fully symmetric, and we can write  $A_{\nu\mu\lambda}^{\rm else} = A_{\mu\nu\lambda}^{\rm else}$ , because A and thus  $A^{\rm else}$  is symmetric in its first two indices.

We then have

$$C_{\lambda\mu\nu} = -\frac{1}{2} A_{\mu\nu\lambda}^{\text{sym}} + A_{\mu\nu\lambda}^{\text{else}}$$

$$= -\frac{1}{2} A_{\mu\nu\lambda}^{\text{sym}} + \left( A_{\mu\nu\lambda} - A_{\mu\nu\lambda}^{\text{sym}} \right)$$

$$= -\frac{3}{2} A_{\mu\nu\lambda}^{\text{sym}} + A_{\mu\nu\lambda}$$

$$= -\frac{1}{2} (A_{\mu\nu\lambda} + A_{\nu\lambda\mu} + A_{\lambda\mu\nu}) + A_{\mu\nu\lambda}.$$
(5.22)

In the last step, we have simply written out the definition of  $A_{\mu\nu\lambda}^{\text{sym}} = A_{(\mu\nu\lambda)}$ ; note that we only had to write down three permutations of the indices rather than six, because we already know that A is symmetric in its first two indices. We can now write down the solution:

$$C_{\lambda\mu\nu} = \frac{1}{2} [A_{\mu\nu\lambda} - A_{\nu\lambda\mu} - A_{\lambda\mu\nu}]. \tag{5.23}$$

This completes the proof.

Could we go to the next order if we wanted to? To see if we could eliminate the second derivatives, we can count the degrees of freedom in the Taylor expansions Eq. (4.32) and Eq. (4.33). In order to make the second derivative of the metric vanish, we must make the Bs vanish. There are 100 Bs, and 80 Ds with which to cancel them. We see that we cannot, in general, cancel all of the second derivatives of the metric; there appear to be 20 linear combinations of second derivatives of  $g_{\mu\nu}$  that cannot be made to vanish by a change of coordinates. We will see later that these are the 20 independent components of the Riemann curvature tensor  $R_{\mu\nu\rho\sigma}$ .

### 5.2 Newtonian Limit of Geodesic Equations

Next, we want to look at the Newtonian limit of the geodesic equations Eq. (3.36). In order to take the Newtonian limit, we will make three assumptions:

- We assume we are in the nonrelativistic limit, where  $\frac{v^2}{c^2} = O(\epsilon)$  for some small parameter  $\epsilon$ .
- We assume that the gravitational fields are weak, so that

$$g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu} \,, \tag{5.24}$$

with  $h_{\mu\nu} = O(\epsilon)$ .

• We assume that the metric is static, ∂tgµν = 0.

What do these assumptions give us? We have

$$d\tau^2 = -g_{\mu\nu} \, dx^{\mu} \, dx^{\nu} \,, \tag{5.25}$$

implying

$$1 = -g_{\mu\nu} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \,. \tag{5.26}$$

We can expand the right-hand side in the form

$$1 = \left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^2 - \left(\frac{\mathrm{d}\vec{x}}{\mathrm{d}\tau}\right)^2 - h_{00}\left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^2 + O\left(\epsilon^{3/2}\right). \tag{5.27}$$

A simple rearrangement gives us

$$\left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^2 (1 - h_{00}) = 1 + \left(\frac{\mathrm{d}\vec{x}}{\mathrm{d}\tau}\right)^2 + O\left(\epsilon^{3/2}\right). \tag{5.28}$$

We can then take the square root and expand, using the expansions

$$\sqrt{1+\epsilon} = 1 + \frac{1}{2}\epsilon + O(\epsilon^2). \tag{5.29}$$

We then have

$$\left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)\left(1 - \frac{1}{2}h_{00}\right) = 1 + \frac{1}{2}\vec{v}^2 + O(\epsilon^{3/2}),\tag{5.30}$$

where ~v = d~x dτ . Using the expansion

$$\frac{1}{1+\epsilon} = 1 - \epsilon + O(\epsilon), \qquad (5.31)$$

we then have

<span id="page-22-0"></span>
$$\frac{\mathrm{d}t}{\mathrm{d}\tau} = \left(1 + \frac{1}{2}h_{00}\right)\left(1 + \frac{1}{2}\vec{v}^2\right) + O\left(\epsilon^{3/2}\right) = 1 + \frac{1}{2}h_{00} + \frac{1}{2}\vec{v}^2 + O\left(\epsilon^{3/2}\right). \tag{5.32}$$

We now make use of the geodesic equation in the form Eq. [\(3.27\)](#page-11-0),

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\mu\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{1}{2} \frac{\partial g_{\lambda\sigma}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\tau} \,. \tag{5.33}$$

For µ = i, the left-hand side of the geodesic equation becomes

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{\mathrm{d}}{\mathrm{d}\tau} \left[ \eta_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} + h_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right]. \tag{5.34}$$

We can write

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ h_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = h_{ij} \frac{\mathrm{d}^{2}x^{j}}{\mathrm{d}\tau^{2}} + h_{i0} \frac{\mathrm{d}^{2}t}{\mathrm{d}\tau^{2}} + \frac{\partial h_{i\nu}}{\partial x^{\lambda}} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} = O\left(\epsilon^{3/2}\right).$$
 (5.35)

Thus, the left-hand side of the geodesic equation for µ = i is

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{\mathrm{d}}{\mathrm{d}\tau} \left[ \eta_{i\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] + O\left(\epsilon^{3/2}\right) = \frac{\mathrm{d}^2 x_i}{\mathrm{d}\tau^2} + O\left(\epsilon^{3/2}\right). \tag{5.36}$$

The right-hand side of the geodesic equation becomes

$$\frac{1}{2} \frac{\partial g_{\lambda \sigma}}{\partial x^{i}} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\tau} = \frac{1}{2} \frac{\partial h_{00}}{\partial x^{i}} \left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^{2} + O\left(\epsilon^{3/2}\right) = \frac{1}{2} \frac{\partial h_{00}}{\partial x^{i}} + O\left(\epsilon^{3/2}\right). \tag{5.37}$$

Thus, to first order in , we have

$$\frac{\mathrm{d}^2 x_i}{\mathrm{d}\tau^2} = \frac{1}{2} \frac{\partial h_{00}}{\partial x^i} \,. \tag{5.38}$$

We want this to be equal to the force equation for Newtonian gravity,

$$\frac{\mathrm{d}^2 x_i}{\mathrm{d}t^2} = -\partial_i \Phi \,, \tag{5.39}$$

where Φ is the gravitational potential. These equations match if

$$h_{00} = -2\Phi. (5.40)$$

For µ = 0, we can write to first order in that

$$g_{0\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} = \text{constant} \,,$$
 (5.41)

because the right side of the geodesic equation will vanish exactly for µ = 0, since the metric is static. To first order in , this equation is

$$(-1 + h_{00})\frac{\mathrm{d}t}{\mathrm{d}\tau} = \text{constant}. \tag{5.42}$$

We define the energy to be

$$E \equiv -(-1 + h_{00})\frac{\mathrm{d}t}{\mathrm{d}\tau} = (1 - h_{00})\frac{\mathrm{d}t}{\mathrm{d}\tau}.$$
 (5.43)

Using the expansion Eq. [\(5.32\)](#page-22-0), this gives us

$$E = 1 - \frac{1}{2}h_{00} + \frac{1}{2}\vec{v}^2 = 1 + \frac{1}{2}\vec{v}^2 + \Phi.$$
 (5.44)

This is exactly the energy per mass: the first term is the mass energy per mass, the second is the kinetic energy per mass, and the final term is the gravitational potential energy per mass.

# 6 Lecture 6 (Mar. 1, 2017)

## 6.1 Note on Locally Inertial Coordinates

Recall that we can always transform to a locally inertial coordinate frame; if we assume that we have already arranged for gµ0<sup>ν</sup> <sup>0</sup> = ηµ0<sup>ν</sup> <sup>0</sup> at the origin, we expand the metric as

$$g_{\mu'\nu'} = \eta_{\mu'\nu'} + A_{\mu'\nu'\lambda'}x^{\lambda'} + O(x^2)$$
. (6.1)

We can then construct an unprimed coordinate system that is related to the primed system by

$$x'^{\lambda} = x^{\lambda} + \frac{1}{2} C^{\lambda}_{\mu\nu} x^{\mu} x^{\nu} . \tag{6.2}$$

Then we can arrange for  $\partial_{\lambda}g_{\mu\nu}(0) = 0$  if we set

$$C_{\lambda\mu\nu} = \eta_{\lambda\sigma}C^{\sigma}_{\ \mu\nu} = \frac{1}{2}[A_{\mu\nu\lambda} - A_{\nu\lambda\mu} - A_{\lambda\mu\nu}]. \tag{6.3}$$

We note that these derivatives of the metric look very similar to those in the Christoffel symbols. In fact, from this we can derive the new statement

<span id="page-24-0"></span>
$$x'^{\lambda} = x^{\lambda} - \frac{1}{2} \Gamma^{\lambda}_{\mu\nu} x^{\mu} x^{\nu}$$
 (6.4)

We see then that

$$\frac{\partial x^{\lambda'}}{\partial x^{\mu}} = \delta^{\lambda'}_{\mu} - \Gamma^{\lambda'}_{\mu\nu} x^{\nu} \,, \tag{6.5}$$

where we have returned to the Carroll notation for primes. Plugging this into

$$g_{\mu\nu} = \frac{\partial x^{\lambda'}}{\partial x^{\mu}} \frac{\partial x^{\sigma'}}{\partial x^{\nu}} g_{\lambda'\sigma'}, \qquad (6.6)$$

we can write (once again violating the Carroll convention)

$$g_{\mu\nu} = g'_{\mu\nu} - \Gamma^{\lambda}_{\mu\sigma} x^{\sigma} g_{\lambda\nu} - \Gamma^{\lambda}_{\nu\sigma} x^{\sigma} g_{\mu\sigma} + O(x^2). \tag{6.7}$$

We can then plainly see

$$\frac{\partial g_{\mu\nu}}{\partial x^{\rho}}\bigg|_{x=0} = \partial_{\rho}g'_{\mu\nu} - \Gamma^{\lambda}_{\mu\rho}g_{\lambda\nu} - \Gamma^{\lambda}_{\nu\rho}g_{\lambda\mu} = 0.$$
(6.8)

The fact that this expression vanishes is a famous result that we have not yet seen in the course; this quantity is the covariant derivative of  $g_{\mu\nu}$ , which vanishes identically. Thus, with the new expression Eq. (6.4), it is direct to see that our transformation successfully achieves  $\partial_{\lambda}g_{\mu\nu}(0) = 0$ .

#### 6.2 The Schwarzschild Metric

The Schwarzschild metric is the metric in a vacuum outside of a spherically symmetric object with mass  $M \neq 0$ . The metric is given by

$$ds^{2} = -\left(1 - \frac{2GM}{r}\right)dt^{2} + \left(1 - \frac{2GM}{r}\right)^{-1}dr^{2} + r^{2}d\Omega^{2},$$
 (6.9)

where

$$d\Omega^2 \equiv d\theta^2 + \sin^2\theta \, d\phi^2 \,. \tag{6.10}$$

This metric comes from solving Einstein's equations with spherical symmetry. The derivation of this metric does not assume that the gravitational source is static; the source could be time-dependent, but so long as it is spherically symmetric then the associated metric will be the Schwarzschild metric. This is known as *Birkhoff's Theorem*: the Schwarzschild metric is the unique spherically symmetric vacuum solution to Einstein's equation.

Note that at very large r, we recover Minkowski space. Note that we have

$$g_{tt} = -1 + \frac{2GM}{r} \,. ag{6.11}$$

To first order in GM <sup>r</sup> 1, we can compare this with the Newtonian limit, in which

$$g_{tt}|_{\text{Newtonian}} = -(1+2\Phi). \tag{6.12}$$

This implies that

$$\Phi = -\frac{GM}{r} \tag{6.13}$$

which is exactly what we expect.

Consider the term

$$\left(1 - \frac{2GM}{r}\right)^{-1} \mathrm{d}r^2. 
\tag{6.14}$$

As we take r → 2GM from above, we see that 1 − 2GM r −<sup>1</sup> → ∞. Thus, the distances corresponding to a fixed dr get larger and larger as we approach r = 2GM. This does not imply that the distance from, say, r = 4GM to r = 2GM is infinite; this is an integrable singularity. If we consider only radial motion, we have

$$ds = \frac{1}{\sqrt{1 - \frac{2GM}{r}}} dr = \frac{\sqrt{r}}{\sqrt{r - 2GM}} dr,$$
 (6.15)

which has an integrable singularity at r = 2GM. This tells us that the distance between r = 2GM and any r > 2GM is finite.

<span id="page-25-0"></span>We can visualize this using an embedding diagram. This diagram displays a two-dimensional slice through the three-dimensional spatial part of spacetime. We can then visualize the curvature of this two-dimensional slice by embedding it in a fictitious three-dimensional space, and visualizing the metric on the two-dimensional surface as the induced metric coming from the three-dimensional space. Such a diagram, taken from Sean Carroll's 1997 Lecture Notes on General Relativity, is shown below: Note that this diagram is a double copy, with the "funnel" going out both sides of

![](_page_25_Picture_14.jpeg)

Figure 2: The embedding diagram for a black hole.

the diagram. Later in the course, we will discuss the motivation for the double copy, but for now we will concern ourselves only with the region r > 2GM, where only the upper half of this diagram is relevant.

What does this metric mean? In this metric, r does not measure the distance from the origin. The metric does contain one factor we're familiar with, which is r 2 dθ <sup>2</sup> + sin<sup>2</sup> θ dφ 2 . This is exactly the Euclidean metric on the surface of a sphere. Thus, so long as we stay on the surface of a sphere, all of the rules we are used to still apply: the circumference of an equator is 2πr and the surface area of the sphere is 4πr<sup>2</sup> . For this reason, the coordinate r is sometimes called the circumferential radius.

We will now make one comment about r < 2GM. Notice that in this regime, 1 − 2GM r < 0. Thus, the signs of the dt <sup>2</sup> and dr 2 terms switch; this tells us that for r < 2GM, t is a spatial (spacelike) coordinate and r is a temporal (timelike) coordinate. Note that this also means the metric is not static for r < 2GM, because the metric depends on the time coordinate r. This is crucial to the fact that black holes radiate; static objects cannot radiate, even when quantum mechanical effects are taken into account, but black holes can radiate (and they do) because the Schwarzschild metric is not static for r < 2GM.

The Schwarzschild horizon is the surface at the Schwarzschild radius

$$R_* = 2GM. (6.16)$$

At this radius, the metric is singular, because grr = ∞ and gtt = 0. Each of these statements individually tells us that the metric is singular; a metric is singular if any of its eigenvalues is zero or ∞. This singularity is actually only a coordinate singularity; it can be removed by considering a better choice of coordinates. The most useful set of coordinates to consider are the Kruskal coordinates, which we will discuss later.

In SI units, the Schwarzschild radius is

$$R_* = \frac{2GM}{c^2} \,. \tag{6.17}$$

For the sun, the Schwarzschild radius is

$$R_*^{\odot} = \frac{2GM_{\odot}}{c^2}$$

$$= \frac{2(6.67 \times 10^{-11} \,\mathrm{m \, kg^{-1} \, s^{-2}})(2 \times 10^{30} \,\mathrm{kg})}{9 \times 10^{16} \,\mathrm{m^2 \, s^{-2}}}$$

$$= 2.95 \,\mathrm{km} \ll R_{\odot} = 7.5 \times 10^5 \,\mathrm{km} \,. \tag{6.18}$$

We see that this radius is much smaller than the radius R of the Sun, so the Schwarzschild metric is invalid for describing the Sun. This saves the Sun from being peculiar; in particular, it is why the Sun is not a black hole. Black holes occur when R<sup>∗</sup> > Robject, in which case the Schwarzschild metric is valid at r = R<sup>∗</sup> and the object is a black hole with horizon R∗.

The surface at r = R<sup>∗</sup> is a horizon, meaning that if an object is ever at r < R∗, then it can never escape. We will discuss this more later.

## 6.2.1 Conservation Laws

Writing the geodesic equation in the form

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\mu\nu} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \right] = \frac{1}{2} \frac{\partial g_{\lambda\sigma}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\tau} \,. \tag{6.19}$$

From this, we can immediately see that if the metric does not depend on a particular coordinate, then we automatically have a conserved quantity.

The Schwarzschild metric is independent of t and φ; we can thus define two conserved quantities. The first is what we will refer to as the energy,

$$E \equiv -g_{00} \frac{\mathrm{d}x^0}{\mathrm{d}\tau} = -g_{00} \frac{\mathrm{d}t}{\mathrm{d}\tau} = \left(1 - \frac{2GM}{r}\right) \frac{\mathrm{d}t}{\mathrm{d}\tau}.$$
 (6.20)

From

$$d\tau^{2} = \left(1 - \frac{2GM}{r}\right)dt^{2} - \left(1 - \frac{2GM}{r}\right)^{-1}dr^{2} - r^{2}\left(d\theta^{2} + \sin^{2}\theta d\phi^{2}\right), \tag{6.21}$$

we can find

$$\left(\frac{\mathrm{d}t}{\mathrm{d}\tau}\right)^{2} = \left(1 - \frac{2GM}{r}\right)^{-1} \left\{1 + \left(1 - \frac{2GM}{r}\right)^{-1} \left(\frac{\mathrm{d}r}{\mathrm{d}\tau}\right)^{2} + r^{2} \left[\left(\frac{\mathrm{d}\theta}{\mathrm{d}\tau}\right)^{2} + \sin^{2}\theta \left(\frac{\mathrm{d}\phi}{\mathrm{d}\tau}\right)^{2}\right]\right\}, \quad (6.22)$$

which we could substitute into the expression for E.

The conserved quantity associated with φ is the angular momentum,

$$L_{\phi} \equiv g_{\phi\phi} \frac{\mathrm{d}\phi}{\mathrm{d}\tau} = r^2 \sin\theta \frac{\mathrm{d}\phi}{\mathrm{d}\tau}.$$
 (6.23)

Both E and L<sup>φ</sup> are conserved, meaning that they have constant values along any geodesic.

### 6.2.2 Gravitational Time Dilation

For stationary objects in the Schwarzschild metric, we have

$$d\tau^2 = -g_{00} dt^2, (6.24)$$

<span id="page-27-0"></span>giving us

$$d\tau = \sqrt{1 - \frac{2GM}{r}} dt. ag{6.25}$$

This tells us how proper time dτ , which is the time read on a clock at rest at r, is related to dt, the coordinate time interval. We can also consider what this looks like from the point of view of an observer at infinity, receiving light signals from the clock at r. As shown in Fig. [3,](#page-28-0) the coordinate time interval between the ticks of a clock at r is the same as the coordinate time interval between the receipt of the light signals at infinity, since the metric is static for r > 2GM. But at infinity, dt = dτ , so dt is the time interval that would be measured by the clock at infinity. Thus, the redshift factor of Eq. [\(6.25\)](#page-27-0) describes the slowing of the clock in the gravitational well, as observed from infinity.

The relation

$$d\tau = \sqrt{1 - \frac{2GM}{r}} dt \tag{6.26}$$

tells us that the proper time is shorter than the coordinate time. When GM <sup>r</sup> 1, this dilation factor is

$$\sqrt{1 - \frac{2GM}{r}} \approx 1 - \frac{GM}{r} \,. \tag{6.27}$$

As an example, consider a satellite orbiting the Earth at radius

$$R_{\rm s} \sim 27\,000\,\mathrm{km} \approx 4R_{\oplus}\,,\tag{6.28}$$

where R<sup>⊕</sup> is the radius of the Earth. Using M<sup>⊕</sup> ≈ 6.0 × 10<sup>24</sup> kg as the mass of the Earth, we find that

$$\frac{GM_{\oplus}}{R_{\rm s}c^2} \approx 1.6 \times 10^{-10} \,.$$
 (6.29)

<span id="page-28-0"></span>![](_page_28_Figure_3.jpeg)

Figure 3: The diagram shows a clock at rest at r > 2GM, which ticks at coordinate times  $t_1$  and  $t_2$ , with  $\Delta t \equiv t_2 - t_1$ . The ticks are transmitted via light signals to a clock at rest at "infinity," meaning at a radial coordinate much larger than r. Since the metric is static, each light signal takes the same amount of coordinate time to reach the clock at infinity, and therefore their coordinate separation at infinite distance is also  $\Delta t$ .

This does not seem like a huge factor, but it makes a big difference for GPS satellites. In one day, the accumulated error is

$$\Delta t = 1.6 \times 10^{-10} \cdot 1 \,\text{day} = 1.6 \times 10^{-10} \cdot 86400 \,\text{s} = 14 \,\mu\text{s} \,.$$
 (6.30)

Given the large value of the speed of light, this would cause a GPS satellite to measure locations inaccurately by

$$c\Delta t = c(14 \text{ us}) = 4.2 \text{ km}$$
 (6.31)

For GPS, it would be more relevant to compare with a clock on Earth, rather than a clock at infinity, and one would also want to take into account the motion of the satellite; however, the simple calculation above show that accounting for relativistic effects is crucial for GPS.

We can also discuss some numbers for the time dilation near a black hole. At radius  $r = \frac{4}{3}R_*$ , we have  $d\tau = \frac{1}{2} dt$ . At  $r = \frac{100}{99}R_*$ , we have  $d\tau = \frac{1}{10} dt$ . Note that as  $r \to R_*$  from above, the dilation factor diverges,  $\sqrt{1 - \frac{2GM}{r}} \to \infty$ .

For a radially in-falling light ray, the proper time is  $d\tau = 0$ , which gives us

$$0 = -\left(1 - \frac{2GM}{r}\right) dt^2 + \left(1 - \frac{2GM}{r}\right)^{-1} dr^2,$$
 (6.32)

from which we find

$$dr = \pm \left(1 - \frac{2GM}{r}\right) dt = \pm \left(\frac{r - R_*}{r}\right) dt.$$
 (6.33)

Near the horizon, we can define  $\epsilon \equiv r - R_*$ , and we find that

$$d\epsilon = \pm \frac{\epsilon}{r} dt \approx \pm \frac{\epsilon}{R_*} dt$$
, (6.34)

where we used r ≈ R<sup>∗</sup> in the denominator. Integrating this yields

$$\epsilon(t) = Ce^{-t/R_*} \tag{6.35}$$

for some constant C. Note that this epsilon decreases exponentially in the time coordinate, which implies that the light never actually reaches the horizon. In the Schwarzschild coordinates, a light ray never reaches the horizon, which implies that timelike trajectories, corresponding to objects falling into the black hole at less than the speed of light, will also never reach the horizon.

## 7 Lecture 7 (Mar. 6, 2017; Guest Lecturer: Mohammad Namjoo)

Recall the Schwarzschild Metric

$$ds^{2} = -\left(1 - \frac{2GM}{r}\right)dt^{2} + \left(1 - \frac{2GM}{r}\right)^{-1}dr^{2} + r^{2}d\Omega^{2},$$
 (7.1)

where

$$d\Omega^2 = d\theta^2 + \sin^2\theta \, d\phi^2 \,. \tag{7.2}$$

We define

$$R_{\rm s} \equiv 2GM. \tag{7.3}$$

This metric has Christoffel symbols

$$\Gamma_{tr}^{t} = \frac{GM}{r(r - 2GM)} \tag{7.4}$$

$$\Gamma_{tt}^r = \frac{GM}{r^3}(r - 2GM) \tag{7.5}$$

$$\Gamma_{rr}^r = -\frac{GM}{r(r - 2GM)} \tag{7.6}$$

$$\Gamma^r_{\theta\theta} = -(r - 2GM) \tag{7.7}$$

$$\Gamma^r_{\phi\phi} = -(r - 2GM)\sin^2\theta \tag{7.8}$$

$$\Gamma_{r\theta}^{\theta} = \frac{1}{r} \tag{7.9}$$

$$\Gamma^{\theta}_{\phi\phi} = -\sin\theta\cos\theta\tag{7.10}$$

$$\Gamma^{\phi}_{\theta\phi} = \cot\theta \tag{7.11}$$

$$\Gamma^{\phi}_{r\phi} = \frac{1}{r} \tag{7.12}$$

(7.13)

## 7.1 Orbits of the Schwarzschild Metric

Today we will discuss orbits of the Schwarzschild metric. The geodesic equation is

$$\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} = -\Gamma^{\mu}_{\sigma\rho} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\rho}}{\mathrm{d}\lambda} \tag{7.14}$$

How is this equation simplified by symmetries? We can write the geodesic equation instead in the form

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\sigma\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} \right] = \frac{1}{2} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} . \tag{7.15}$$

The metric is independent of t, so we immediately see that the right-hand side will vanish for  $\sigma = 0$ , giving us a conserved quantity

$$E \equiv -g_{00} \frac{\mathrm{d}t}{\mathrm{d}\lambda} = \left(1 - \frac{R_{\mathrm{s}}}{r}\right) \frac{\mathrm{d}t}{\mathrm{d}\lambda}.$$
 (7.16)

Similarly, because the metric is independent of  $\phi$ , we have a conserved quantity

$$L_{\phi} \equiv g_{\phi\phi} \frac{\mathrm{d}\phi}{\mathrm{d}\lambda} = r^2 \sin^2 \theta \frac{\mathrm{d}\phi}{\mathrm{d}\lambda} \,. \tag{7.17}$$

Using these quantities will simplify our work.

There is actually another symmetry we can use; the metric is invariant under the  $\mathbb{Z}_2$  transformation  $z \to -z$ . This means that if we begin at  $\theta = \frac{\pi}{2}$  with  $\dot{\theta} = 0$ , then  $\dot{\theta} = 0$  for all time along a geodesic. To see this, consider the geodesic equation for  $\theta$ :

$$\ddot{\theta} = -\Gamma^{\theta}_{\mu\nu} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\lambda} = -2\frac{1}{r}\dot{\theta}\dot{r} + \sin\theta\cos\theta\dot{\phi}^{2}. \tag{7.18}$$

We can see that with  $\theta = \frac{\pi}{2}$  and  $\dot{\theta} = 0$ , this gives  $\ddot{\theta} = 0$ , meaning that the geodesic will always remain in the z = 0 plane, as desired.

For a massive particle, the trajectory will always be timelike, so we consider

$$d\tau^{2} = -ds^{2} = \left(1 - \frac{R_{s}}{r}\right)dt^{2} - \left(1 - \frac{R_{s}}{r}\right)^{-1}dr^{2} - r^{2}d\Omega^{2}.$$
 (7.19)

For massless particles, we have  $d\tau^2 = 0$ . We divide this equation by  $d\lambda^2$  to find a relationship between the parameter  $\lambda$  and the proper time  $\tau$ . Setting  $\theta = \frac{\pi}{2}$  and  $\dot{\theta} = 0$ , we reach

$$a \equiv \left(\frac{\mathrm{d}\tau}{\mathrm{d}\lambda}\right)^2 = \left(1 - \frac{R_\mathrm{s}}{r}\right) \left(\frac{\mathrm{d}t}{\mathrm{d}\lambda}\right)^2 - \left(1 - \frac{R_\mathrm{s}}{r}\right)^{-1} \left(\frac{\mathrm{d}r}{\mathrm{d}\lambda}\right)^2 - r^2 \left(\frac{\mathrm{d}\phi}{\mathrm{d}\lambda}\right)^2. \tag{7.20}$$

Here, a=0 for massless particles and a=1 for massive particles (using the parameter  $\lambda=\tau$ ). We can rewrite this equation using the conserved quantities E and  $L_{\phi}$ :

$$a = \left(1 - \frac{R_{\rm s}}{r}\right)^{-1} E^2 - \left(1 - \frac{R_{\rm s}}{r}\right)^{-1} \left(\frac{\mathrm{d}r}{\mathrm{d}\lambda}\right)^2 - \frac{L_{\phi}^2}{r^2}.$$
 (7.21)

We can further rewrite this equation in the form

$$\frac{1}{2} \left( \frac{\mathrm{d}r}{\mathrm{d}\lambda} \right)^2 + V(r) \equiv \mathcal{E} = \frac{1}{2} E^2 \,, \tag{7.22}$$

where

$$V(r) = \frac{1}{2} \left( 1 - \frac{R_s}{r} \right) \left( a + \frac{L_\phi^2}{r^2} \right) = \frac{1}{2} \left( a - \frac{aR_s}{r} + \frac{L_\phi^2}{r^2} - \frac{R_s L_\phi^2}{r^3} \right). \tag{7.23}$$

Let's analyze this potential. The first term is constant, and thus unimportant. The second term is the standard Newtonian potential,  $\frac{GM}{r}$ . The third term is the standard angular momentum potential term. The final term is the new correction to the Newtonian potential coming from general relativity.

Let's see what behavior this gives for massless particles such as the photon. In this case, a = 0. The effective potential then simplifies to

$$V(r) = \frac{1}{2} \left( \frac{L_{\phi}^2}{r^2} - \frac{R_{\rm s} L_{\phi}^2}{r^3} \right). \tag{7.24}$$

For Newtonian gravity, we would simply have

$$V_{\text{Newton}}(r) = \frac{1}{2} \left( \frac{L_{\phi}^2}{r^2} \right). \tag{7.25}$$

Note that the potential  $V_{\text{Newton}}(r)$  has no local extrema, meaning there is no orbit for the photon in Newtonian gravity; the photon will always accelerate away from the black hole at r = 0.

However, this is not the case for the general relativistic potential V(r). We can extremize this potential by setting

$$V'(r_{\rm m}) = -\frac{L_{\phi}^2}{r_{\rm m}^3} + \frac{3}{2} \frac{R_{\rm s} L_{\phi}^2}{r_{\rm m}^4} = 0.$$
 (7.26)

This gives

$$r_{\rm m} = \frac{3}{2}R_{\rm s} = 3GM. (7.27)$$

Note that  $V''(r_{\rm m}) < 0$ , meaning that this is a maximum of the potential. Thus, there is an unstable circular orbit of the photon about the black hole at radius  $r = r_{\rm m}$ . For  $r > r_{\rm m}$ , the trajectory of the photon will bend around the black hole, but the photon will escape; for  $r < r_{\rm m}$ , the photon will spiral in to the singularity.

Now we consider massive particles. In this case, a = 1, so the potential becomes

$$V(r) = \frac{1}{2} \left( 1 - \frac{R_{\rm s}}{r} + \frac{L_{\phi}^2}{r^2} - \frac{R_{\rm s}L_{\phi}^2}{r^3} \right). \tag{7.28}$$

For the case of Newtonian gravity, we instead have

$$V_{\text{Newton}}(r) = \frac{1}{2} \left( 1 - \frac{R_{\text{s}}}{r} + \frac{L_{\phi}^2}{r^2} \right).$$
 (7.29)

Extremizing this potential gives

$$V'(r_{\rm m,N}) = \frac{R_{\rm s}}{2r_{\rm m,N}^2} - \frac{L_{\phi}^2}{r_{\rm m,N}^3} = 0, \qquad (7.30)$$

yielding

$$r_{\rm m,N} = \frac{2L_{\phi}^2}{R_c} \,. \tag{7.31}$$

At this extremum, we have  $V''(r_{m,N}) > 0$ , so this is a minimum of the potential. There is a stable circular orbit at  $r = r_{m,N}$ , meaning that the particle will oscillate about  $r = r_{m,N}$  when perturbed, giving elliptical orbits.

Now let's consider the general relativistic potential. Extremizing gives

$$V'(r_{\rm c}) = \frac{R_{\rm s}}{r_{\rm s}^2} - \frac{L_{\phi}^2}{r_{\rm s}^3} + \frac{3R_{\rm s}L_{\phi}^2}{2r_{\rm s}^4} = 0,$$
 (7.32)

from which we find the two extrema

$$r_{\rm c} = \frac{L_{\phi}^2}{R_{\rm s}} \left( 1 \pm \sqrt{1 - \frac{3R_{\rm s}^2}{L_{\phi}^2}} \right).$$
 (7.33)

We can gain some intuition about these extrema by considering limiting behavior. We see that for L<sup>φ</sup> Rs, the extrema become

$$r_{\rm c} \approx \left(\frac{2L_{\phi}^2}{R_{\rm s}}, \frac{3R_{\rm s}}{2}\right).$$
 (7.34)

For the former extremum, V <sup>00</sup> > 0, meaning that it is a minimum, while for the latter extremum we have V <sup>00</sup> < 0, meaning that it is a maximum. Thus, there are both stable and unstable circular orbits for the massive particle in this limit, as well as elliptical orbits. Note that in the regime L<sup>φ</sup> < √ 3Rs, r<sup>c</sup> becomes imaginary, meaning that there is no extremum, and thus no orbits; the massive particle will spiral fall in to the singularity in this case.

## 7.2 Precession of the Perihelion

For an elliptical orbit about the Sun, the point of closest approach is called the perihelion. In general relativity, the position of the perihelion will change as a function of time due to the general relativistic correction. In other words, for Newtonian gravity we expect that the radius in the orbit will be periodic in φ, r(φ+ 2π) = r(φ), but in general relativity this is not the case. We will instead find

$$r(\phi + 2\pi) = r(\phi) + \text{corrections}.$$
 (7.35)

For the massive particle, the Schwarzschild metric gave us the equation

$$1 = \left(1 - \frac{R_{\rm s}}{r}\right)^{-1} E^2 - \left(1 - \frac{R_{\rm s}}{r}\right)^{-1} \dot{r}^2 - \frac{L_{\phi}^2}{r^2},\tag{7.36}$$

where ˙r = dr dλ . Because we have assumed θ = π 2 , we have L<sup>φ</sup> = r 2φ˙ . Note then that we can write

$$r' \equiv \frac{\mathrm{d}r}{\mathrm{d}\phi} = \frac{\mathrm{d}r/\,\mathrm{d}\lambda}{\mathrm{d}\phi/\,\mathrm{d}\lambda} = \frac{\dot{r}r^2}{L_\phi} \,. \tag{7.37}$$

We also make the change of variables

<span id="page-32-0"></span>
$$u = \frac{1}{r},\tag{7.38}$$

which lets us write

$$u' \equiv \frac{\mathrm{d}u}{\mathrm{d}\phi} = -\frac{1}{r^2}r'. \tag{7.39}$$

We can then rewrite Eq. [\(7.36\)](#page-32-0) as

$$1 - R_{\rm s}u = E^2 - u'^2 L_{\phi}^2 - L_{\phi}^2 u^2 (1 - R_{\rm s}u). \tag{7.40}$$

Differentiating again with respect to φ yields

$$-R_{\rm s}u' = -2u'u''L_{\phi}^2 - 2L_{\phi}^2uu'(1 - R_{\rm s}u) + L_{\phi}^2u^2R_{\rm s}u'.$$
 (7.41)

Simplifying, this gives us

$$u'' + u = \frac{R_{\rm s}}{2L_{\phi}^2} + \frac{3R_{\rm s}}{2}u^2.$$
 (7.42)

If we had carried out this procedure with Newtonian gravity, we would instead have

$$u'' + u = \frac{R_{\rm s}}{2L_{\phi}^2},\tag{7.43}$$

so the last term is the GR correction.

We will now solve this equation perturbatively. We take  $u = u_0 + u_1$ , where  $u_0$  is the Newtonian solution, and  $u_1$  is the GR correction, with  $u_0 \gg u_1$ . The Newtonian (zeroth-order) solution satisfies

$$u_0'' + u_0 = \frac{R_s}{2L_\phi^2},\tag{7.44}$$

which yields

$$u_0 = \frac{R_s}{2L_\phi^2} (1 + e\cos\phi). \tag{7.45}$$

This is an elliptical orbit with eccentricity  $e = L_{\phi} \frac{b^2}{a^2}$ , where a and b are the semi-major and semi-minor axes, respectively.

We then consider the equation to the next order:

$$(u_0 + u_1)'' + (u_0 + u_1) = \frac{R_s}{2L_\phi^2} + \frac{3R_s}{2}(u_0 + u_1)^2.$$
 (7.46)

We can cancel terms from this equation using the fact that  $u_0$  satisfies the Newtonian equation. Further, we can take  $(u_0 + u_1)^2 \approx u_0^2$  on the right-hand side because we are working to leading order. This leads to

$$u_1'' + u_1 = \frac{3R_s}{2}u_0^2 = \frac{3R_s^3}{8L_\phi^4}(1 + e\cos\phi)^2.$$
 (7.47)

This is the same equation as before, just with a different source. Thus, we can absorb this by making a change  $e \to e'$ , and this will only contribute to the homogeneous solution for  $u_1$ .

We want to find the particular solution. Note that the right-hand side is

$$\frac{3R_{\rm s}^3}{8L_{\phi}^4}(1+e\cos\phi)^2 = \frac{3R_{\rm s}^3}{8L_{\phi}^4}\left[1+2e\cos\phi + \frac{e^2}{2}(1+\cos2\phi)\right]. \tag{7.48}$$

We further note that

$$\frac{\mathrm{d}^2}{\mathrm{d}\phi^2}(\phi\sin\phi) + \phi\sin\phi = 2\cos\phi, \quad \frac{\mathrm{d}^2}{\mathrm{d}\phi^2}(\cos2\phi) + \cos2\phi = -3\cos2\phi. \tag{7.49}$$

Using these facts, we find the particular solution for  $u_1$ :

$$u_1 = \frac{3R_s^3}{8L_\phi^4} \left[ 1 + e\phi \sin\phi + e^2 \left( \frac{1}{2} - \frac{1}{6} \cos 2\phi \right) \right]. \tag{7.50}$$

We are interested in the behavior of the perihelion, where  $\frac{dr}{d\phi} = 0$ . Because  $u = \frac{1}{r}$ , we then want to compute  $\frac{du}{d\phi}$ . We have

$$\frac{\mathrm{d}u}{\mathrm{d}\phi} = \frac{3R_{\mathrm{s}}^3}{8L_{\phi}^4} \left[ e\sin\phi + e\phi\cos\phi + \frac{e^2}{3}\sin2\phi \right] - \frac{R_{\mathrm{s}}}{2L_{\phi}^2} e\sin\phi. \tag{7.51}$$

If the first perihelion is at  $\phi = 0$ , then the following perihelion will occur at  $\phi = 2\pi + \alpha$  due to the GR correction. Solving for  $\alpha$ , we find

$$\alpha = \frac{3\pi R_{\rm s}^2}{2L_{\phi}^2} = \frac{6\pi G^2 M^2}{L_{\phi}^2} \,. \tag{7.52}$$

For Newtonian gravity,  $\alpha = 0$ , so this is purely a GR correction.

If we calculate this correction for Mercury, which has e = 0.2 and  $r_{\mbox{$\odot$}} \approx 6 \times 10^{10} \, \mbox{m}$ , we find

$$\alpha \approx 42.98 \, \mathrm{arcsec/century} \,.$$
 (7.53)

This anomaly went unexplained before Einstein developed general relativity, and predicting the precession of the perihelion of Mercury was one of the first pieces of evidence in support of the theory.

## 8 Lecture 8 (Mar. 8, 2017)

## 8.1 Circular Orbits in the Schwarzschild Metric

We saw last time that we can model a massive particle moving along a geodesic in the Schwarzschild metric as a nonrelativistic particle moving in an effective potential given by

$$V(r) = \frac{1}{2} \left( 1 - \frac{R_{\rm s}}{r} + \frac{L_{\phi}^2}{r^2} - \frac{R_{\rm s}L_{\phi}^2}{r^3} \right). \tag{8.1}$$

We will now review the possible circular orbits in the Schwarzschild radius. A circular orbit is is one of constant radius; such an orbit can only occur at a critical point of the potential, where  $V'(r_c) = 0$ . We saw last time that these points occur at

$$r_c = \frac{L_\phi^2}{R_s} \left( 1 \pm \sqrt{1 - \frac{3R_s^2}{L_\phi^2}} \right).$$
 (8.2)

For simplicity, we will give these roots distinct names:

$$r_{+} = \frac{L_{\phi}^{2}}{R_{s}} \left( 1 + \sqrt{1 - \frac{3R_{s}^{2}}{L_{\phi}^{2}}} \right), \quad r_{-} = \frac{L_{\phi}^{2}}{R_{s}} \left( 1 - \sqrt{1 - \frac{3R_{s}^{2}}{L_{\phi}^{2}}} \right).$$
 (8.3)

We now want to scan over all possible values of  $L_{\phi}$  and find what kind of circular orbits we can get.

- For  $L_{\phi}^2 < 3R_{\rm s}^2$ , we don't have any real roots, meaning there are no stationary points of the potential and thus no circular orbits.
- For  $L_{\phi}^2 = 3R_s^2$ , we have  $r_+ = r_- = \frac{L_{\phi}^2}{R_s} = 3R_s$ . This is a boundary between a region with no roots and a region with two roots; on this boundary, there is exactly one root.
- As  $L_{\phi}^2$  runs from  $3R_s^2$  up to  $\infty$ , we see that  $r_+$  runs from  $3R_s$  up to  $\infty$ . Is this a stable orbit? After some effort, we can show  $V''(r_+) > 0$ , which indicates that  $r_+$  is a stable minimum of V(r) and there is a stable orbit at this radius. This also means that there are stable elliptical orbits around  $r_+$ .

As  $L_{\phi}^2$  runs from  $3R_{\rm s}^2$  up to  $\infty$ , the root  $r_{-}$  runs from  $3R_{\rm s}$  to  $\frac{3}{2}R_{\rm s}$ . To see this, note that for  $L_{\phi}^2 \gg R_{\rm s}$  we have

$$r_{-} \approx \frac{L_{\phi}^{2}}{R_{\rm s}} \left[ 1 - \left( 1 - \frac{3R_{\rm s}^{2}}{2L_{\phi}^{2}} \right) \right] = \frac{3}{2}R_{\rm s} \,.$$
 (8.4)

We can show that  $V''(r_{-}) < 0$ , meaning that this is a maximum of the potential, and thus corresponds to an unstable circular orbit.

In summary, we have found that for  $r > 3R_s$ , there are stable circular orbits in the Schwarzschild metric; for  $\frac{3}{2}R_s < r < 3R_s$ , there are unstable circular orbits; and for  $r < \frac{3}{2}R_s$ , there are no orbits. Note that this means that an observer at  $r < \frac{3}{2}R_s$  without a rocket engine (or a large initial radial velocity) cannot escape the gravitational well, even if they start outside of the horizon at  $R_s$ .

### 8.2 Perihelion of Mercury

Last time, we saw that the precession per orbit of the perihelion, due to the GR correction, was given by

$$\alpha = \frac{6\pi G^2 M_{\odot}^2}{L_{\phi}^2} \,. \tag{8.5}$$

We can find Newton's constant G and the mass  $M_{\odot}$  of the Sun easily, but what do we put in for the angular momentum  $L_{\phi}$  of Mercury? We could compute it directly using

$$L_{\phi} = r^2 \sin^2 \theta \frac{\mathrm{d}\phi}{\mathrm{d}\tau} \,, \tag{8.6}$$

where  $\sin \theta = 1$  because the solution was calculated for the equatorial plane of the coordinate system. We can find  $L_{\phi}$  more simply, however, by noting that Mercury has a roughly circular orbit very far outside the Schwarzschild radius of the Sun. For  $L_{\phi} \gg R_{\rm s}$ , we have a circular orbit at

$$r = r_{+} = \frac{L_{\phi}^{2}}{R_{s}} [1 + \sqrt{1 - 0}] = \frac{2L_{\phi}^{2}}{R_{s}},$$
 (8.7)

so we can simply set

$$L_{\phi}^{2} = \frac{1}{2} R_{\rm s} r_{\mbox{$\beta$}} = G M_{\odot} r_{\mbox{$\beta$}},$$
 (8.8)

where  $r_{ \mbox{\Large \slash}}$  is the radius of Mercury.

The punchline is that the precession of the perihelion of Mercury's orbit about the Sun is

$$\alpha = 42.98 \operatorname{arcsec/century}$$
. (8.9)

Predicting this value was the first major success of general relativity.

### 8.3 Manifolds

We now want to define what a manifold is; this is a way to describe objects that we can not describe with Euclidean coordinates because of their topological properties. An example is the surface of a sphere; we know how to put coordinates on the surface of the sphere, using the polar angles  $\theta$  and  $\phi$ , but this coordinate system becomes singular at the north and south poles, where  $\phi$  becomes meaningless. The solution to this problem is to instead describe multiple patches of the surface with different coordinate systems, none of which are singular, and which in some sense agree on their overlaps.

**Definition 1** A (real) manifold M is a set of points (a topological space) that is locally equivalent to  $\mathbb{R}^n$ .

Let's consider some examples to build intuition. One family of manifolds are the n-spheres: the circle  $S^1$ , the sphere  $S^2$ , and so on (note that these do not refer to the interiors of the circle and sphere, which are called disks, but only their exterior surfaces). A non-example of a manifold is a figure eight, which crosses itself at a point; there is no consistent way to put Euclidean coordinates on the intersection point.

Any manifold M can be constructed from open patches  $U_i \subset M$  satisfying  $\bigcup_i U_i = M$ , meaning that every point  $x \in M$ ,  $x \in U_i$  for some i. For each such patch  $U_i$ , we can define a continuous, one-to-one map  $\phi_i$  (actually a homeomorphism) called a *coordinate chart*, which maps  $U_i \to V_i$ , where  $V_i$  is an open subset of  $\mathbb{R}^n$ . A set  $V_i$  is open if, for every point  $x \in V_i$ , there exists an  $\epsilon > 0$  such that  $|y - x| < \epsilon$  implies  $y \in V_i$ . Intuitively, this means that for every  $x \in V_i$ , we can draw a sphere around x that lies entirely within  $V_i$ . In particular, this means that  $V_i$  cannot contain its own boundary.

The open sets  $U_i$  must overlap because they are open and cover the entire manifold. If two open sets  $U_i$  and  $U_j$  overlap, there must be a relationship between the coordinate charts  $\phi_i$  and  $\phi_j$  that assign Euclidean coordinates to these sets. For a point  $p \in U_i \cap U_j$ , we have  $\phi_i(p) \in V_i$  and  $\phi_j(p) \in V_j$ . We can then construct a transition map  $\phi_i \circ \phi_j^{-1} \colon V_2 \to V_1$ ; we will always consider smooth manifolds, for which we require these transition maps to be infinitely differentiable.

### 8.3.1 Coordinates on a Sphere

We will now find coordinate charts for a sphere to properly define it as a manifold. To do so, we will use stereographic projection. To construct these coordinates, we consider a plane tangent to the sphere at the south pole; we then find the stereographic coordinates of a point p (which cannot be the north pole) by drawing a straight line connecting the north pole to the point p, and finding the intersection of this line with the plane. This maps every point on the sphere other than the north pole to a point in the plane. Thus, we have an open set  $U_1$  of the sphere, which contains all points other than the north pole, that can be mapped to the Euclidean plane by a coordinate chart  $\phi_1$ .

We need another coordinate patch that will cover the north pole. To do this, we similarly consider a plane tangent to the sphere at the north pole, and find the stereographic coordinates for a point by drawing a straight line connecting the south pole to the point p and finding its intersection with the plane. This defines a coordinate chart  $\phi_2$  on the open set  $U_2$  containing all points of the sphere other than the south pole.

All points other than the two poles have local coordinates described by both coordinate charts; we can thus discuss the transition map for the overlap of the two charts. To do so, we will find an explicit expression for the maps  $\phi_1$  and  $\phi_2$ . This will be simplest using polar coordinates  $(r, \phi)$  on the plane. Consider a point on the sphere at spherical coordinate  $(\theta, \phi)$ ; this  $\phi$  will be the same azimuthal angle  $\phi$  in either of the planes at the north and north pole; we must then figure out the radii on the two planes using the spherical angle  $\theta$ . We find that

$$\phi_1(\theta,\phi) = (r,\phi) = \left(2\cot\frac{\theta}{2},\phi\right), \quad \phi_2(\theta,\phi) = (r',\phi') = \left(2\tan\frac{\theta}{2},\phi\right). \tag{8.10}$$

We see then that  $r' = \frac{4}{r}$  and  $\phi' = \phi$ , which tells us that

$$\phi_2 \circ \phi_1^{-1}(r, \phi) = \left(\frac{4}{r}, \phi\right).$$
 (8.11)

Note that we have been a little sloppy by using polar coordinates on the plane, because these still have an ambiguity at the origin. This will all work properly if we instead use (x, y) coordinates on the planes, but the answers are easier to write down in polar coordinates.

#### 8.3.2 Diffeomorphisms

We now need a way to determine if two different manifolds are actually equivalent to one another.

**Definition 2** Two manifolds M and M' are equivalent, or diffeomorphic, if there exists a bijective (one-to-one and onto) map  $\phi \colon M \to M'$  that is  $C^{\infty}$  (infinitely differentiable) on charts. The map  $\phi$  is called a diffeomorphism.

Consider a chart  $\phi_i : U_i \to V_i$  that maps an open set  $U_i$  of M to  $V_i \subset \mathbb{R}^n$ , and a chart  $\phi'_i$  that maps an open set  $U'_i$  of M' to  $V'_i \subset \mathbb{R}^n$ . The map  $\phi : M \to M'$  then allows us to define

$$\phi_i' \circ \phi \circ \phi_i^{-1} \colon V_i \to V_i' \,, \tag{8.12}$$

and the statement that  $\phi$  must be  $C^{\infty}$  on charts means that this induced map  $\phi'_i \circ \phi \circ \phi_i^{-1}$  must be infinitely differentiable as a map from  $\mathbb{R}^n$  to  $\mathbb{R}^n$ .

## 9 Lecture 9 (Mar. 13, 2017)

### 9.1 Manifolds

In general relativity, we assume that spacetime is described by a (3+1)-dimensional manifold. In most cases, this spacetime will be isomorphic to  $\mathbb{R}^4$ , but that need not be the case. For example, a wormhole can exist connecting regions of space; this explains the full picture in Fig. 2. We will see that eternal black holes (not black holes formed by collapse) have wormholes at their center.

### 9.2 Tangent Spaces and Vector Fields

In flat space, the first vector that we learned about was the displacement vector, which points from one point in space to another. Later we learned about other vectors, such as the momentum of a particle or the electric field, which can be defined at a single point in space, without needing a pair of points. In curved spaces, the notion of a vector that goes from one point in space to another is lost. In a curved space, a line that connects one point to another is necessarily curved, and is a more complicated object than a vector. In particular, there is no natural definition of how one might add two such curves, and addition is a central ingredient to what we call a vector space. The concept of a vector defined at a point, however, can be adapted to curved spaces, but it is not trivial. We want a notion of vectors on manifolds, and we want ways to correlate these vectors with directions on the manifold.

If a curved manifold is embedded in a higher-dimensional Euclidean space, with the induced metric, then the tangent space to the manifold at a point can be visualized as a plane in Euclidean space, tangent to the manifold at that point. This illustrates the concept that each point has its own tangent space. It is not immediately clear how to compare vectors in the tangent space of one point with vectors in the tangent space of another.

We now want to generalize this concept; we want to be able to define the tangent space to a manifold at a point without having to embed the manifold in a higher-dimensional space (though such an embedding into a higher-dimensional flat space with the appropriate signature is always possible).

A scalar field f on a manifold M is a mapping  $f: M \to \mathbb{R}$  from the manifold to the real numbers. For any point  $\overline{x} \in M$ , there exists a coordinate chart  $x^{\mu}: U \to \mathbb{R}^n$  on a neighborhood U of  $\overline{x}$ , which allows us to define  $f(x^{\mu})$ . Then, the most general possible first-order derivative of f at  $\overline{x}$  can be written as

$$V^{\mu}(\overline{x}) \frac{\partial}{\partial x^{\mu}} f(x) \bigg|_{\overline{x}}$$
 (9.1)

This  $V^{\mu}(\overline{x})$  is our definition of a vector in the tangent space at the point  $\overline{x}$ . The tangent space  $T_x M$  at the point x is the space of all possible  $V^{\mu}(x)$ . In other words,  $T_x M$  is the space spanned by the basis vectors  $\frac{\partial}{\partial x^{\mu}}$ . Note that this implies  $\dim(T_x M) = \dim(M)$ .

There is an alternative construction of the tangent space, which considers trajectories in the manifold. A trajectory in the manifold M is defined by  $x \colon \mathbb{R} \to M$ . In coordinates,  $x = x^{\mu}(\lambda)$ , which traces out the trajectory on the manifold as a function of the parameter  $\lambda$ . Then, a tangent vector at the point  $x \in M$  that the trajectory passes through is simply defined to be  $\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda}|_{x}$ ; the tangent space  $T_{x}M$  to M at x is defined to be the set of all possible such tangent vectors, for any trajectory  $x^{\mu}(\lambda)$  that passes through the point x.

Next, we will discuss vector fields. A vector field is a map that assigns to each point in the manifold a vector in the tangent space to the manifold at that point. In coordinates, this is  $V^{\mu}(x)$ . (We might loosely imagine that the vector field is described by  $V: M \to T_x M$ , but this is not quite a correct use of the notation, since each point x in M is mapped to a different tangent space  $T_x M$ . We will see below how to describe the mapping more accurately by introducing the idea of a tangent bundle.) We can then define a commutator of vector fields. For two vector fields defined by their actions on scalar fields

$$Vf(x) = V^{\mu}(x)\frac{\partial}{\partial x^{\mu}}f, \quad Uf(x) = U^{\mu}(x)\frac{\partial}{\partial x^{\mu}}f,$$
 (9.2)

we can define the *product* of the vector fields as

$$UVf(x) = U^{\mu}(x)\frac{\partial}{\partial x^{\mu}} \left[ V^{\nu}(x)\frac{\partial}{\partial x^{\nu}} f \right]. \tag{9.3}$$

The *commutator* of the two vector fields is then defined to be

$$[U, V] = UV - VU. (9.4)$$

Now we want to work out how vector fields behave under coordinate transformations. Consider the coordinate charts  $\phi_i : U_i \to \mathbb{R}^n$ ; the map  $\phi_i$  maps an open subset  $U_i \subset M$  to coordinates  $x^{\mu}$  in  $\mathbb{R}^n$ . From these coordinate charts, we can construct the transition maps  $\phi_j \circ \phi_i^{-1} : \mathbb{R}^n \to \mathbb{R}^n$  on the overlap between  $U_i$  and  $U_j$ , which maps coordinates  $x^{\mu}$  on coordinate patch  $U_i$  to coordinates  $x^{\mu'}$  on the coordinate patch  $U_j$ . We can then relate the action of a vector field V in one set of coordinates (viewed as a differential operator) to the other coordinates, using the rules we already know from ordinary calculus:

$$V^{\mu}(x)\frac{\partial}{\partial x^{\mu}}f(x) = \underbrace{V^{\mu}(x)\frac{\partial x^{\nu'}}{\partial x^{\mu}}}_{=V^{\nu'}}\frac{\partial}{\partial x^{\nu'}}f(x') = V^{\nu'}\frac{\partial}{\partial x^{\nu'}}f(x'). \tag{9.5}$$

Here, we have used the arguments x and x' to denote the coordinate n-tuples in the unprimed and primed coordinate systems, respectively. Thus, we see that

$$V^{\nu'}(x') = \frac{\partial x^{\nu'}}{\partial x^{\mu}} V^{\mu}(x). \tag{9.6}$$

## 9.3 Fiber Bundles

We will now define the concept of a vector bundle; in particular, we are interested in the tangent bundle. The tangent bundle T M of a manifold M is defined by

$$T M = \bigsqcup_{x \in M} T_x M, \qquad (9.7)$$

the disjoint union of the tangent spaces at each point in M. Each tangent space T<sup>x</sup> M is associated with its particular point x ∈ M. This allows us to define a projection operator π : T M → M as

$$\pi(p \in T M) = \{x : p \in T_x M\}. \tag{9.8}$$

We can also talk about the inverse of the projection map, π −1 . The set

$$\pi^{-1}(x) = \{ p \in T M : \pi(p) = x \}$$
(9.9)

is the set of all points in the tangent bundle that map to x under π. Thus,

$$\pi^{-1}(x) = T_x M. (9.10)$$

The tangent bundle is an example of a fiber bundle. An F-bundle B over a manifold M, is a union of copies of fibers F at each point x ∈ M,

$$B = \bigsqcup_{x \in M} F_x \,. \tag{9.11}$$

Each F<sup>x</sup> is a fiber space, all homeomorphic to F, meaning that there is exists a continuous, oneto-one, onto map from F<sup>x</sup> to F whose inverse is also continuous. The set F<sup>x</sup> is called the fiber over the point x.

More formally, a fiber bundle consists of a base space M, a total space B, and a fiber F, along with a continuous surjection (i.e. a map that is onto, so that all points in M are covered) π : B → M, called the projection map, such that for every point x ∈ B, there exists an open neighborhood U ⊂ M of π(x) such that there is a homeomorphism φ: π −1 (U) → U × F in such a way that π(p) = proj<sup>U</sup> ◦φ(p), where proj<sup>U</sup> : U × F → U is the projection onto the first factor. In other words, the formal definition is that for every point x in the total space, there is an open neighborhood U of the corresponding point y = π(x) in the base space. The preimage of U in the total space, π −1 (U) ⊂ B, is a local patch that is equivalent to U × F, in the sense that there exists a one-to-one, onto, continuous, invertible (with continuous inverse) map (a homeomorphism) φ between it and U × F, which has the property that the notion of a corresponding base point is treated consistently. For any point p ∈ π −1 (U), the image φ(p) = (y, f) ∈ U × F gives the same base point y as the projection operator π(p), i.e. y = π(p). Thus, the fiber bundle is locally equivalent to U × F, where U ⊂ M, but globally it is generically not so simple.

One common case is where the fiber is a vector space, in which case B is a vector bundle. Another is the case where the fiber is a Lie group G, in which case B is a G-bundle. In particular, gauge theories are examples of G-bundles, where G is the gauge group; a gauge transformation is a map from the spacetime manifold to the gauge group, which is called a section of the fiber bundle.

A section of a fiber bundle is a continuous map σ : M → B such that π(σ(x)) = x. In other words, a section assigns, to each point of the manifold, a point in the fiber over that point in that manifold. We see then that a vector field is just a section of the tangent bundle.

Next, we define the concept of a cotangent space. The cotangent space, denoted  $(T_x M)^*$  or  $T_x^* M$ , is the space of linear maps from  $T_x M$  to  $\mathbb{R}$ . It is the dual space to the tangent space. If  $V^{\mu} \in T_x M$ , then a general linear map to  $\mathbb{R}$  can written as

$$\omega(V^{\mu}) = \omega_{\mu} V^{\mu} \,. \tag{9.12}$$

Thus, the set of all  $\omega_{\mu}$  defines the cotangent space. Recall that vectors with lower-indexed vectors like  $\omega_{\mu}$  are called contravariant vectors. As we did with the contravariant vector  $V^{\mu}$ , we can determine the transformation properties of the covariant vector  $\omega_{\mu}$ . We want  $\omega_{\mu}$  to define the same map regardless of what coordinate system we use, which means we want

$$V^{\mu'}\omega_{\mu'} = V^{\mu}\omega_{\mu}. \tag{9.13}$$

We know that

$$V^{\mu'} = \frac{\partial x^{\mu'}}{\partial x^{\nu}} V^{\nu} \,, \tag{9.14}$$

so this gives us

$$V^{\nu} \frac{\partial x^{\mu'}}{\partial x^{\nu}} \omega_{\mu'} = V^{\mu} \omega_{\mu} \,. \tag{9.15}$$

Thus, we must set

$$\omega_{\nu} = \frac{\partial x^{\mu'}}{\partial x^{\nu}} \omega_{\mu'} \,. \tag{9.16}$$

We now define the cotangent bundle. The cotangent bundle is the set

$$T^* M = \bigsqcup_{x \in M} T^*_x M. \tag{9.17}$$

This is the fiber bundle over M for which the fiber over the point x is the cotangent space  $T^*_x M$ . We define a *tensor* of type (p,q) at the point  $x \in M$  to be an object

$$T^{\mu_1 \cdots \mu_p}_{\nu_1 \cdots \nu_q} \in \underbrace{\mathbf{T}_x \, M \otimes \cdots \otimes \mathbf{T}_x \, M}_{p \text{ times}} \otimes \underbrace{\mathbf{T}^*_x \, M \otimes \cdots \otimes \mathbf{T}^*_x \, M}_{q \text{ times}}, \tag{9.18}$$

where the tensor product  $A \otimes B$  of two spaces A and B is the space spanned by pairs  $(a_i, b_j)$  for basis vectors  $a_i$  of A and  $b_j$  of B.

# 10 Lecture 10 (Mar. 15, 2017)

## 10.1 Derivatives on Manifolds

Suppose we have a vector field  $V^{\nu}(x)$ . Is  $\partial_{\mu}V^{\nu}(x)$  a tensor? We compute

$$\partial_{\mu'} V^{\nu'}(x') = \partial_{\mu'} \left[ \frac{\partial x^{\nu'}}{\partial x^{\lambda}} V^{\lambda} \right]$$

$$= \frac{\partial x^{\sigma}}{\partial x^{\mu'}} \partial_{\sigma} \left[ \frac{\partial x^{\nu'}}{\partial x^{\lambda}} V^{\lambda} \right]$$

$$= \frac{\partial x^{\sigma}}{\partial x^{\mu'}} \frac{\partial x^{\nu'}}{\partial x^{\lambda}} \frac{\partial V^{\lambda}}{\partial x^{\sigma}} + \frac{\partial x^{\sigma}}{\partial x^{\mu'}} \frac{\partial^{2} x^{\nu'}}{\partial x^{\sigma} \partial x^{\lambda}} V^{\lambda}.$$
(10.1)

Note that the first term is exactly how a tensor would transform; the second piece is additional, and is the reason that quantity ∂µV ν is not a tensor. Note that if a tensor vanishes in one frame, it vanishes in all frames; this is not true here, because the second term is proportional to V λ rather than ∂σV λ . Thus, the derivative of a vector field may vanish in one frame but not in others.

Consider, for example, the 2D Euclidean plane. A possible vector field is then V (x, y) = ˆx. This is a constant vector field. Because this vector field is constant in space, we see that its spatial derivatives vanish, ∂iV = 0. However, if we consider this vector field in polar coordinates,

$$\hat{r} = \cos \theta \hat{x} + \sin \theta \hat{y},$$

$$\hat{\theta} = -\sin \theta \hat{x} + \cos \theta \hat{y},$$
(10.2)

we find that it is written

$$V(r,\theta) = \cos\theta \hat{r} - \sin\theta \hat{\theta}. \tag{10.3}$$

We see that this vector field is a function of the coordinate θ, and so ∂θV 6= 0.

We want to fix this issue by modifying our definition of the derivative. We will define a quantity called the covariant derivative, which will transform as a tensor under a change of coordinates.

An important concept here is that of parallel transport. In flat space, it is clear how we can transport a vector from point to point in such a way that the vector is always pointing in the same direction. On a curved space, this is not so obvious, because each vector belongs to the tangent space at a particular point, and we don't immediately see how to relate vectors in two different tangent spaces to one another. Parallel transport tells us how to carry a vector along a curve, keeping its direction "fixed."

In this course, we are concerned with (pseudo-)Riemannian geometry, where the metric defines a smoothly-varying quadratic form (Riemannian metrics are positive-definite, while pseudo-Riemannian metrics like the Minkowski metric need not be). The approach to parallel transporting a vector here is to go to a locally inertial frame; in a LIF, parallel transport amounts to moving the vector and keeping its coordinates fixed. We can then go to LIF, parallel transport the vector by an infinitesimal amount, then go to LIF at the new location of the vector, and repeat.

The parallel transport depends on the path. As an example, consider the sphere S 2 , and consider a vector sitting on the equator and pointing due north. We will first parallel transport the vector along the equator until it is at the antipodal point of the sphere (exactly opposite to where it started). As we carry out this parallel transport, the vector always remains pointing north. Alternatively, we can start at the same original location, with the vector pointing north, but this time we will imagine carrying it over the north pole. As we transport the vector north, it always points north, but after we pass through the north pole, the vector will now point south. When the vector reaches the antipodal point from its starting point, it now points south. Thus, we have found that, depending on the path, the final direction of the vector can be north or south. In fact, depending on the path chosen, the vector could have finished pointing in any direction.

### 10.1.1 Connections

An example of relevance to us is the second derivative

$$\frac{\mathrm{d}^2 x^{\mu}}{\mathrm{d}\tau^2} = \lim_{\Delta \tau \to 0} \frac{\frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} (\tau + \Delta \tau) - \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} (\tau)}{\Delta \tau} \,. \tag{10.4}$$

In reality, it is unclear how to compare the velocity vectors at two different points, because they belong to different tangent spaces, and so we don't formally know what the numerator of this expression means.

We need a new structure in order to define parallel transport, called a connection. We will use the language of fiber bundles. The connection defines parallel transport, allowing us transport an element of  $T_x M$  (a vector) to an element of  $T_{x+\delta x} M$ . Equivalently, a connection defines a covariant derivative  $D_{\mu}\sigma$ , where  $\sigma$  is a section of the fiber bundle. Then, parallel transporting a vector along a path is the same as requiring that the covariant derivative of the vector vanish along the path. That is,  $V^{\mu}D_{\mu}\sigma = 0$  if and only if  $\sigma(x^{\mu})$  and  $\sigma(x^{\mu} + \epsilon V^{\mu})$  are related by parallel transport.

In more detail, fibers of the fiber bundle (which are all diffeomorphic to one another) transform according to the *structure group G*. For the tangent bundle, the group of transformations that acts on the fibers is the general group of invertible (i.e. nonvanishing determinant) real linear transformations,  $GL(n, \mathbb{R})$ , called the *general linear group*. As another example, in E&M the fields defined on the manifold are described by a bundle, and the structure group is the group of gauge transformations, U(1). A charged field  $\psi(x)$  transforms under a gauge transformation as

$$\psi(x) \to e^{i\Lambda(x)}\psi(x)$$
. (10.5)

In general, a connection on a bundle B is a covariant vector field (one-form)  $C_{\mu}$  that defines an infinitesimal transformation of a fiber, for a section of a bundle. A covariant derivative is defined to be

$$\nabla_{\mu}\sigma = \partial_{\mu}\sigma + C_{\mu}\sigma. \tag{10.6}$$

For a tangent vector  $V^{\mu}$ , the covariant derivative is

$$\nabla_{\mu}V^{\nu} = \frac{\partial}{\partial x^{\mu}}V^{\nu} + (\Gamma_{\mu})^{\nu}_{\ \lambda}V^{\lambda}, \qquad (10.7)$$

for some  $(\Gamma_{\mu})^{\nu}_{\lambda}$ . For any tangent vector  $\omega^{\mu}$ , the quantity

$$\omega^{\nu}\Gamma_{\mu\ \lambda}^{\ \nu}V^{\lambda} \tag{10.8}$$

describes the infinitesimal change in  $V^{\nu}$  under parallel transport along  $\omega^{\mu}$ .

For (pseudo-)Riemannian spaces, there is a particular definition of parallel transport, which corresponds to going to locally inertial coordinates and transporting with constant components. For this notion of parallel transport, the appropriate connection is the Levi-Civita connection, in which case  $\Gamma^{\nu}_{u\lambda}$  is the Christoffel symbol. For E&M, the covariant derivative is

$$D_{\mu} = \partial_{\mu} + ieA_{\mu} \,, \tag{10.9}$$

and so we see that the vector potential  $A_{\mu}$  plays the role of the connection.

We now return to the question of how to find the coordinate components  $\Gamma_{\mu}^{\ \nu}_{\lambda}$  for the connection in general. To do so, we must introduce the concept of torsion. The *torsion* is defined to be

$$T^{\lambda}_{\mu\nu} = \Gamma^{\lambda}_{\mu\nu} - \Gamma^{\lambda}_{\nu\mu} \,. \tag{10.10}$$

Note that this vanishes if  $\Gamma^{\lambda}_{\mu\nu}$  is the Christoffel symbol, so in general relativity our connections are torsion-free. For more general fiber bundles, there may be nonzero torsion, and generalizations of general relativity that include torsion have been explored. There is no evidence, however, that torsion is needed to describe gravitational interactions in nature.

Given a particular metric, we can say that  $\Gamma$  is metric-compatible if

$$\nabla_{\rho}q_{\mu\nu} = 0. \tag{10.11}$$

### Theorem 2 (Fundamental Theorem of Riemannian Geometry) Given a

(pseudo-)Riemannian manifold M with metric g, there is a unique metric-compatible, torsion-free connection.

PROOF We assume that

$$\nabla_{\rho}g_{\mu\nu} = \partial_{\rho}g_{\mu\nu} - \Gamma^{\lambda}_{\rho\mu}g_{\lambda\nu} - \Gamma^{\lambda}_{\rho\nu}g_{\mu\lambda} = 0. \qquad (10.12)$$

We want to determine the form of such a connection, if one exists. Using this expression, we can write

$$\partial_{\rho}g_{\mu\nu} - \partial_{\mu}g_{\nu\rho} - \partial_{\nu}g_{\rho\mu} = \Gamma^{\lambda}_{\rho\mu}g_{\lambda\nu} + \Gamma^{\lambda}_{\rho\nu}g_{\mu\lambda} - \Gamma^{\lambda}_{\mu\nu}g_{\lambda\rho} - \Gamma^{\lambda}_{\mu\rho}g_{\nu\lambda} - \Gamma^{\lambda}_{\nu\rho}g_{\lambda\mu} - \Gamma^{\lambda}_{\nu\mu}g_{\rho\lambda} = -2\Gamma^{\lambda}_{\mu\nu}g_{\lambda\rho}, \quad (10.13)$$

where we used the fact that  $\Gamma^{\lambda}_{\mu\nu}$  is torsion-free to freely interchange the two lower indices. We can then rearrange to reach

$$\Gamma^{\lambda}_{\mu\nu} = \frac{1}{2} g^{\lambda\rho} (\partial_{\mu} g_{\rho\nu} + \partial_{\nu} g_{\rho\mu} - \partial_{\rho} g_{\mu\nu}), \qquad (10.14)$$

which agrees with the Christoffel symbol that we introduced when we derived the geodesic equation. Carroll (p. 100) says that this is sometimes called the Christoffel connection, sometimes the Levi-Civita connection, and sometimes the Riemannian connection. Weinberg's *Gravitation and Cosmology* (p. 71) calls it the affine connection, and Wald's *General Relativity* (p. 36) just calls the corresponding covariant derivative the natural definition of the derivative. But whatever the name, it is unambiguously the connection that is used in general relativity.

# 11 Lecture 11 (Mar. 20, 2017)

#### 11.1 Connections

Recall that connections are associated with covariant derivatives. In pseudo-Riemannian spaces, one way of defining the covariant derivative is by going to a LIF; in this frame, the covariant derivative is the ordinary derivative,  $\nabla_{\mu}\sigma = \partial_{\mu}\sigma$ , for any tensor  $\sigma$  (with indices suppressed). This is a direct consequence of the Einstein equivalence principle: if we have an equation with derivatives in general relativity, then in the locally inertial frame these must become regular derivatives, as in special relativity.

Explicitly, the covariant derivatives of a contravariant vector and a covariant vector can be written as

$$\nabla_{\mu}V^{\nu} = \partial_{\mu}V^{\nu} + \Gamma^{\nu}_{\mu\lambda}V^{\lambda},$$

$$\nabla_{\mu}V_{\nu} = \partial_{\mu}V_{\nu} - \Gamma^{\lambda}_{\mu\nu}V_{\lambda}.$$
(11.1)

We showed last time that the torsion-free condition,  $\Gamma^{\lambda}_{\mu\nu} = \Gamma^{\lambda}_{\nu\mu}$ , and the the metric compatible condition,  $\nabla_{\mu}g_{\lambda\sigma} = 0$ , imply that the coordinate components of the connection are the familiar Christoffel symbols,

$$\Gamma^{\lambda}_{\mu\nu} = \frac{1}{2} g^{\lambda\rho} [\partial_{\mu} g_{\rho\nu} + \partial_{\nu} g_{\rho\mu} - \partial_{\rho} g_{\mu\nu}]. \tag{11.2}$$

This connection has various names: the Christoffel connection, the Levi-Civita connection, the affine connection (more generally), or the natural connection.

### 11.1.1 General Properties of Connections

We now discuss properties of connections in general. Consider a general connection Γ and associated covariant derivative ∇µ.

1. For any scalar function f,

$$\nabla_{\mu} f = \partial_{\mu} f \,. \tag{11.3}$$

2. Linearity: for any tensor A, B and α, β ∈ R,

$$\nabla_{\mu}(\alpha A + \beta B) = \alpha \nabla_{\mu} A + \beta \nabla_{\mu} B. \tag{11.4}$$

3. Leibniz rule: for any tensors A µ1···µ<sup>n</sup> <sup>ν</sup>1···ν<sup>m</sup> and B λ1···λ<sup>k</sup> σ1···σ` ,

$$\nabla_{\mu} \left( A^{\mu_{1} \cdots \mu_{n}}_{\nu_{1} \cdots \nu_{m}} B^{\lambda_{1} \cdots \lambda_{k}}_{\sigma_{1} \cdots \sigma_{\ell}} \right) = \left( \nabla_{\mu} A^{\mu_{1} \cdots \mu_{n}}_{\nu_{1} \cdots \nu_{m}} \right) B^{\lambda_{1} \cdots \lambda_{k}}_{\sigma_{1} \cdots \sigma_{\ell}} + A^{\mu_{1} \cdots \mu_{n}}_{\nu_{1} \cdots \nu_{m}} \left( \nabla_{\mu} B^{\lambda_{1} \cdots \lambda_{k}}_{\sigma_{1} \cdots \sigma_{\ell}} \right).$$

$$(11.5)$$

4. Consistency with contractions: from the first property, we have

$$\nabla_{\mu}(V^{\nu}\omega_{\nu}) = \partial_{\mu}(V^{\nu}\omega_{\nu}) = (\partial_{\mu}V^{\nu})\omega_{\nu} + V^{\nu}(\partial_{\mu}\omega_{\nu}), \qquad (11.6)$$

because V <sup>ν</sup>ω<sup>ν</sup> is a scalar function. On the other hand, from the third property (the Leibniz rule), we have

$$\nabla_{\mu}(V^{\nu}\omega_{\nu}) = (\nabla_{\mu}V^{\nu})\omega_{\nu} + V^{\nu}(\nabla_{\mu}\omega_{\nu})$$

$$= (\partial_{\mu}V^{\nu})\omega_{\nu} + \Gamma^{\nu}_{\mu\lambda}V^{\lambda}\omega_{\nu} + V^{\nu}(\nabla_{\mu}\omega_{\nu})$$

$$= (\partial_{\mu}V^{\nu})\omega_{\nu} + V^{\nu}\left[\Gamma^{\lambda}_{\mu\nu}\omega_{\lambda} + \nabla_{\mu}\omega_{\nu}\right].$$
(11.7)

Comparing these two equations gives us

$$\nabla_{\mu}\omega_{\nu} = \partial_{\mu}\omega_{\nu} - \Gamma^{\lambda}_{\mu\nu}\omega_{\lambda}. \tag{11.8}$$

5. Torsion free (optional).

### 11.1.2 Parallel Transport and the Geodesic Equation

We now discuss the connection (for lack of a better word) between parallel transport and the geodesic equation. We begin by defining the covariant derivative along a curve. Consider a parameterized curve x µ (λ) on the manifold M, with a vector V µ (x(λ)) defined along the curve. The covariant derivative along the curve x µ (λ) is defined to be

$$\frac{\mathrm{D}}{\mathrm{d}\lambda}V^{\mu} \equiv \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}\nabla_{\sigma}V^{\mu} 
= \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}[\partial_{\sigma}V^{\mu} + \Gamma^{\mu}_{\sigma\nu}V^{\nu}] 
= \frac{\mathrm{d}V^{\mu}}{\mathrm{d}\lambda} + \Gamma^{\mu}_{\sigma\nu}\frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda}V^{\nu}.$$
(11.9)

This can be generalized to arbitrary tensors.

We can now make the following statement, which relates parallel transport to the covariant derivative along a curve:  $\frac{D}{D\lambda}V^{\mu} = 0$  if and only if  $V^{\mu}$  is parallel transported along the curve  $x^{\mu}(\lambda)$ . Note that we can rewrite the geodesic equation

<span id="page-45-0"></span>
$$\frac{\mathrm{d}^2 x^{\mu}}{\mathrm{d}\tau^2} + \Gamma^{\mu}_{\lambda\sigma} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\tau} = 0 \tag{11.10}$$

<span id="page-45-1"></span>in the form

$$\frac{\mathrm{D}}{\mathrm{d}\tau} \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \right) = 0. \tag{11.11}$$

Thus, the statement that a trajectory satisfies the geodesic equation is equivalent to the statement that the tangent vector to the trajectory is parallel transported along the trajectory.

### 11.2 Lightlike Geodesics

We can now consider lightlike geodesics, such as the trajectory  $x^{\mu}(\lambda)$  of a photon. As we have just seen, this geodesic satisfies

<span id="page-45-2"></span>
$$\frac{\mathrm{D}}{\mathrm{d}\lambda} \left( \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\lambda} \right) = 0, \tag{11.12}$$

equivalent to the geodesic equation

<span id="page-45-3"></span>
$$\frac{\mathrm{d}^2 x^{\mu}}{\mathrm{d}\lambda^2} + \Gamma^{\mu}_{\lambda\sigma} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\lambda} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\lambda} = 0 \tag{11.13}$$

Note that we use the parameter  $\lambda$  here rather than  $\tau$ ; because the spacetime interval vanishes for the photon between any two points on its trajectory, its proper time is always zero, and so it does not make sense to use  $\tau$  as a parameter. Just as Eqs. (11.10) and (11.11) hold only if  $\tau$  is proportional to proper time (up to a shift), Eqs. (11.12) and (11.13) hold only if the parameter  $\lambda$  is what is called an *affine parameter*.

What does this mean? In special relativity, we often draw spacetime diagrams, in which a lightlike geodesic would be a path along the x=t line in the (x,t)-plane. We can imagine marking off this line with evenly spaced dots, which would be evenly spaced in both t and x. If we change Lorentz frames, then the distance between these dots will change, but they will remain equally-spaced. Thus, observers in different frames will agree on the affine parameter  $\lambda$ , up to a multiplicative factor. Generally, two affine parameters  $\lambda$ ,  $\eta$  are related by  $\lambda = a\eta + b$ , for constants  $a, b \in \mathbb{R}$ . In general relativity, an affine parameter is one for which the increments of its value appear to be evenly spaced in a locally inertial frame. For timelike geodesics, any parameter of the form  $\lambda = a\tau + b$ , where  $\tau$  is proper time and a, b are real constants, is an affine parameter; for spacelike geodesics, any parameter  $\lambda = as + b$ , where s is proper length and s, are real constants, is an affine parameter. For lightlike geodesics, there is no analogue of proper time or proper length, but the concept of an affine parameter is still well-defined. Eqs. (11.12) and (11.13) can describe any type of geodesic—timelike, spacelike, or lightlike (also called null). If the equation holds, then the parameter  $\lambda$  is necessarily an affine parameter.

### 11.3 Curvature

How do we tell if a space is truly curved, or if the metric can be transformed to the Minkowski metric to all orders via a change of coordinates? We have shown that we can always change to a coordinate system where the metric is equal to the Minkowski metric through first order at a point, so we know that any signs of nonzero curvature must appear at the second order in the metric.

How many degrees of freedom are there in second derivatives of the metric? The object  $\frac{\partial^2 g_{\mu\nu}}{\partial x^\lambda x^\sigma}$  is symmetric in  $\mu, \nu$  and also symmetric in  $\lambda, \sigma$ , and so there are  $10 \times 10 = 100$  independent second derivatives of the metric. How many of these can we eliminate by coordinate transformations? As we have seen before, we can write a general change of coordinates at the second order in the form

$$x^{\prime \mu} = x^{\mu} + C^{\mu}_{\lambda \sigma \rho} x^{\lambda} x^{\sigma} x^{\rho} . \tag{11.14}$$

The tensor  $C^{\mu}_{\lambda\sigma\rho}$  is symmetric in its last three indices, and so has a total of  $4\times20=80$  independent components. Thus, there are 20 independent second derivatives of the metric that cannot be removed by a general coordinate transformation; we will see that these components are the components of an object known as the curvature tensor.

Recall that when we parallel transport a vector between two points on the sphere, the resultant vector at the second point depends on the path we took. We could then consider parallel transporting a vector around a closed loop: for example, we could consider a vector on the equator of a sphere pointing north, and parallel transport it along the equator to the antipodal point, and then continue to parallel transport it due north over the pole, and then due south back to the original location. The vector will then point south. In general, a change in the direction of a vector parallel transported around a closed loop is a direct way to measure the curvature of a space. To measure the curvature locally, we could then shrink this down to an infinitesimal loop. As we will see, this amounts to looking at the commutator of two covariant derivatives.

By analogy, consider E&M, where the connection is the four-vector potential  $A_{\mu}$ ; the covariant derivative in this case is

<span id="page-46-0"></span>
$$D_{\mu} = \partial_{\mu} + ieA_{\mu} \,. \tag{11.15}$$

We can then compute the commutator of two covariant derivatives:

$$[D_{\mu}, D_{\nu}] = ie(\partial_{\mu}A_{\nu} - \partial_{\nu}A_{\mu}) = ieF_{\mu\nu}. \tag{11.16}$$

Thus, the field strength tensor  $F_{\mu\nu}$  measures the curvature in E&M.

No we return to general relativity. We want to compute the commutator of two covariant derivatives, as an operator; we will do so by considering its action on a vector  $V^{\rho}$ . We compute

$$\begin{split} [\nabla_{\mu}, \nabla_{\nu}] V^{\rho} &= \nabla_{\mu} \nabla_{\nu} V^{\rho} - \nabla_{\nu} \nabla_{\mu} V^{\rho} \\ &= \nabla_{\mu} [\partial_{\nu} V^{\rho} + \Gamma^{\rho}_{\nu\sigma} V^{\sigma}] - (\mu \leftrightarrow \nu) \\ &= \partial_{\mu} [\partial_{\nu} V^{\rho} + \Gamma^{\rho}_{\nu\sigma} V^{\sigma}] - \Gamma^{\lambda}_{\mu\nu} \left[ \partial_{\lambda} V^{\rho} + \Gamma^{\rho}_{\lambda\sigma} V^{\sigma} \right] + \Gamma^{\rho}_{\mu\lambda} \left[ \partial_{\nu} V^{\lambda} + \Gamma^{\lambda}_{\nu\sigma} V^{\sigma} \right] - (\mu \leftrightarrow \nu) \\ &= \left[ \partial_{\mu} \Gamma^{\rho}_{\nu\sigma} - \partial_{\nu} \Gamma^{\rho}_{\mu\sigma} \right] V^{\sigma} + \left[ \Gamma^{\rho}_{\mu\lambda} \Gamma^{\lambda}_{\nu\sigma} - \Gamma^{\rho}_{\nu\lambda} \Gamma^{\lambda}_{\mu\sigma} \right] V^{\sigma} \\ &= R^{\rho}_{\sigma\mu\nu} V^{\sigma} \,, \end{split}$$

$$(11.17)$$

where

$$R^{\rho}_{\ \sigma\mu\nu} \equiv \partial_{\mu}\Gamma^{\rho}_{\nu\sigma} - \partial_{\nu}\Gamma^{\rho}_{\mu\sigma} + \Gamma^{\rho}_{\mu\lambda}\Gamma^{\lambda}_{\nu\sigma} - \Gamma^{\rho}_{\nu\lambda}\Gamma^{\lambda}_{\mu\sigma} \tag{11.18}$$

is the curvature tensor or the Riemann tensor. In the fourth line of Eq. (11.17), we have cancelled many of the explicitly-written terms with the corresponding  $\mu \leftrightarrow \nu$  terms. In particular, all terms involving first or second derivatives of  $V^{\rho}$  cancel out.

Note that different books use different conventions for the curvature tensor; Carroll and Wald use the convention given here, but Weinberg defines  $R^{\rho}_{\sigma\mu\nu}$  with the opposite sign.

Why is the Riemann tensor a tensor? We have shown that

<span id="page-46-1"></span>
$$[\nabla_{\mu}, \nabla_{\nu}] V^{\rho} = R^{\rho}_{\ \sigma\mu\nu} V^{\sigma} \,. \tag{11.19}$$

We know that  $V^{\rho}$  is a tensor, and so are its covariant derivatives; thus, every object on each side of this equation, other than potential  $R^{\rho}_{\sigma\mu\nu}$ , is a tensor. This means that the left side of the equation transforms as a tensor, and so  $R^{\rho}_{\sigma\mu\nu}$  must transform as a tensor so that the entire right side of the equation also transforms as a tensor.

### 11.3.1 Properties of the Riemann Tensor

We now want to determine any properties we can of the Riemann tensor. To do so, it is convenient to go to the locally inertial frame, where the Christoffel symbols (but not necessarily their derivatives) vanish. The properties of interest will be expressed as tensor equations, so if they hold in the locally inertial coordinates, they will hold in all coordinate systems. It is also convenient to lower the first index, so that the Riemann tensor is entirely covariant.

Thus, we work in a LIF, where  $g = \eta$ ,  $\partial g = 0$ , and  $\Gamma = 0$ . We consider the tensor

$$R_{\rho\sigma\mu\nu} = g_{\rho\tau} R^{\tau}_{\sigma\mu\nu} \,. \tag{11.20}$$

Using the definition of the Riemann tensor, we see that

$$R_{\rho\sigma\mu\nu} = \frac{1}{2} \partial_{\mu} [\partial_{\nu} g_{\rho\sigma} + \partial_{\sigma} g_{\rho\nu} - \partial_{\rho} g_{\nu\sigma}] - (\mu \leftrightarrow \nu)$$

$$= \frac{1}{2} [\partial_{\mu} \partial_{\sigma} g_{\rho\nu} - \partial_{\mu} \partial_{\rho} g_{\nu\sigma} - \partial_{\nu} \partial_{\sigma} g_{\rho\mu} + \partial_{\nu} \partial_{\rho} g_{\mu\sigma}].$$
(11.21)

Next time, we will use this equation to derive the symmetry properties of the Riemann tensor.

## 12 Lecture 12 (Mar. 22, 2017)

### 12.1 Curvature

#### 12.1.1 Properties of the Riemann Tensor

Last time we saw that, in a LIF, the fully-covariant Riemann curvature tensor has the simple expression

$$R_{\rho\sigma\mu\nu} = \frac{1}{2} [\partial_{\mu}\partial_{\sigma}g_{\rho\nu} - \partial_{\mu}\partial_{\rho}g_{\nu\sigma} - \partial_{\nu}\partial_{\sigma}g_{\rho\mu} + \partial_{\nu}\partial_{\rho}g_{\mu\sigma}]. \tag{12.1}$$

We now want to note all symmetry properties this tensor has.

• We note that this tensor is antisymmetric in  $\mu \leftrightarrow \nu$ , i.e.

<span id="page-47-0"></span>
$$R_{\rho\sigma\mu\nu} = -R_{\rho\sigma\nu\mu} \,, \tag{12.2}$$

<span id="page-47-1"></span>which we knew even before lowering the first index.

• From the expression we have found for the covariant tensor, we see that it is antisymmetric in  $\rho \leftrightarrow \sigma$ , i.e.

$$R_{\rho\sigma\mu\nu} = -R_{\sigma\rho\mu\nu} \,. \tag{12.3}$$

• The tensor is symmetric under  $(\rho, \sigma) \leftrightarrow (\mu \nu)$ , i.e.

<span id="page-47-2"></span>
$$R_{\rho\sigma\mu\nu} = R_{\mu\nu\rho\sigma} \,. \tag{12.4}$$

• Although it is not immediately easy to see, we find that

<span id="page-48-0"></span>
$$R_{\rho[\sigma\mu\nu]} = 0, \qquad (12.5)$$

where

$$R_{\rho[\sigma\mu\nu]} = \frac{1}{6} [R_{\rho\sigma\mu\nu} + R_{\rho\mu\nu\sigma} + R_{\rho\nu\sigma\mu} - R_{\rho\sigma\nu\mu} - R_{\rho\nu\mu\sigma} - R_{\rho\mu\sigma\nu}]$$
 (12.6)

is the result of antisymmetrizing the final three indices.

How could we see this? The index  $\rho$  plays a special role in this expression, since it is the one index that is not antisymmetrized, so we consider the locations where it could occur. All of the terms in the curvature tensor are second derivatives of the metric, so  $\rho$  must appear as the index of a derivative or an index of g. In the first case, the term has the form

$$\partial_{\rho}\partial_{[\sigma}g_{\mu\nu]}$$
, (12.7)

which vanishes because  $g_{\mu\nu}$  is symmetric, and this is antisymmetrized in  $\sigma$ ,  $\mu$ , and  $\nu$ . In the second case, the term has the form

$$\partial_{[\mu}\partial_{\nu}g_{\sigma]\rho}$$
, (12.8)

which again vanishes, because  $\partial_{\mu}\partial_{\nu}$  is symmetric and this is antisymmetrized in  $\sigma$ ,  $\mu$ , and  $\nu$ .

These properties all must hold in all frames; although we discovered these properties by considering the curvature tensor in the LIF, because Eqs. (12.2), (12.3), (12.4), and (12.5) are all tensor equations, they must hold in all frames if they hold in one.

We now count the degrees of freedom in the Riemann tensor. There are 6 degrees of freedom among the first two indices because they are antisymmetric, and there are 6 degrees of freedom in the final two indices because they are antisymmetric. To impose the third condition above,  $R_{\rho\sigma\mu\nu} = R_{\mu\nu\rho\sigma}$ , we can count as though the first two indices are a single index with 6 possible values, and similarly for the last two. Then the number of degrees of freedom from these three conditions is

$$\frac{6(6+1)}{2} = 21\,, (12.9)$$

which is the counting for a 2-index symmetric tensor whose indices take on 6 distinct values.

We have not yet imposed the final condition,  $R_{\rho[\sigma\mu\nu]} = 0$ . First, we note that—given the conditions of Eqs. (12.2)–(12.5)— $R_{\rho[\sigma\mu\nu]}$  is actually fully antisymmetric in all of its indices; this is because it is antisymmetric in  $\rho\sigma$ , and then  $\sigma$  is antisymmetric with both  $\mu$  and  $\nu$ . To check the antisymmetry in  $\rho \leftrightarrow \sigma$ , we note that

$$R_{\sigma[\rho\mu\nu]} = \frac{1}{3} [R_{\sigma\rho\mu\nu} + R_{\sigma\mu\nu\rho} + R_{\sigma\nu\rho\mu}]$$

$$= -\frac{1}{3} [R_{\rho\sigma\mu\nu} + R_{\rho\nu\sigma\mu} + R_{\rho\mu\nu\sigma}]$$

$$= -R_{\rho[\sigma\mu\nu]}.$$
(12.10)

This demonstrates that  $R_{\rho[\sigma\mu\nu]}$  is completely antisymmetric. Then, we note that there is only one independent component in this tensor, so the condition  $R_{\rho[\sigma\mu\nu]} = 0$  removes a single component.

Thus, the curvature tensor has 20 independent components, which is exactly the number of second derivatives of the metric that we found we could not remove by a coordinate transformation.

We will now generalize this argument to D spacetime dimensions. The number of independent combinations for an antisymmetric 2-index tensor in D dimensions is  $\frac{D(D-1)}{2}$ . Then, the number of

degrees of freedom after imposing the first three conditions (Eqs. [\(12.2\)](#page-47-0)–[\(12.4\)](#page-47-2)) will be the number of degrees of freedom in a symmetric 2-index tensor where each index takes on <sup>D</sup>(D−1) 2 independent values, which is

$$\frac{1}{2} \left( \frac{D(D-1)}{2} \right) \left( \frac{D(D-1)}{2} + 1 \right). \tag{12.11}$$

For the fourth condition, we note that Rρ[σµν] is a completely antisymmetric rank 4 tensor, with indices that take on D values, which has

$$\frac{D(D-1)(D-2)(D-3)}{4!} \tag{12.12}$$

independent components. Then, the constraint Rρ[σµν] = 0 removes this many degrees of freedom. Thus, in D spacetime dimensions, the number of independent components of the curvature tensor is

$$N = \frac{1}{2} \left( \frac{D(D-1)}{2} \right) \left( \frac{D(D-1)}{2} + 1 \right) - \frac{D(D-1)(D-2)(D-3)}{4!} = \frac{1}{12} D^2 (D^2 - 1). \quad (12.13)$$

Several values are shown below:

$$\begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

We see that a one-dimensional spacetime cannot have any curvature, and that there is only a single component of curvature in two spacetime dimensions. The case of D = 3 = 2 + 1 is relevant to the case of cosmic strings, which have infinite extent along one direction; because there is no dependence on the spatial direction along which they extend, we can project out this dimension when considering cosmic strings, after which they look like point particles in 2 + 1 spacetime dimensions. We see that the curvature tensor in 2 + 1 spacetime dimension has 6 independent components. The Ricci tensor

$$R_{\mu\nu} \equiv R^{\lambda}_{\ \mu\lambda\nu} \tag{12.15}$$

also has 6 independent components, meaning that, in D = 3, if the Ricci tensor vanishes then the Riemann tensor must as well; this is significant because the Einstein field equations are

$$R^{\mu\nu} - \frac{1}{2}Rg^{\mu\nu} = 8\pi G T^{\mu\nu} \,, \tag{12.16}$$

where

$$R \equiv g^{\mu\nu} R_{\mu\nu} \,. \tag{12.17}$$

In empty space, T µν = 0, in which case we have

$$R^{\mu\nu} - \frac{1}{2}Rg^{\mu\nu} = 0. {(12.18)}$$

Contracting the left side with gµν then yields

$$R - \frac{1}{2}DR = 0, (12.19)$$

implying R = 0, where D is the number of spacetime dimensions. Thus, in empty space, we have Rµν = 0. In D = 4, the Riemann curvature tensor has 10 more components than the Ricci tensor, so spacetime can still be curved in empty space; in D = 3, however, the vanishing of the Ricci tensor implies the vanishing of the Riemann tensor, so empty space is completely flat in D = 2 + 1. This means that for cosmic strings, thought of as particles in 2 + 1 dimensions, there is only curvature directly inside the cosmic strings; this is why we say that cosmic strings create conical singularities.

We now move on to another property of the Riemann curvature tensor, which is called the Bianchi identity. For any set of commutators of linear operators, we have a cyclic identity, known as the Jacobi identity,

<span id="page-50-0"></span>
$$[[\nabla_A, \nabla_B], \nabla_C] + [[\nabla_B, \nabla_C], \nabla_A] + [[\nabla_C, \nabla_A], \nabla_B] = 0.$$
(12.20)

As an example of the kinds of cancellations which cause this to be true, the term ∇A∇B∇<sup>C</sup> appears in the first commutator, but appears negatively in the term −∇A[∇B, ∇C] coming from the second commutator.

<span id="page-50-2"></span>We recall that the Riemann tensor was originally defined in terms of commutators of covariant derivatives, and so the cyclic identity implies the Bianchi identity for the Riemann curvature tensor:

<span id="page-50-3"></span>
$$\nabla_{\lambda} R^{\rho}_{\ \sigma\mu\nu} + \nabla_{\mu} R^{\rho}_{\ \sigma\nu\lambda} + \nabla_{\nu} R^{\rho}_{\ \sigma\lambda\mu} = 0.$$
 (12.21)

Note added: In lecture, in order to save time the formula above was stated without derivation. But it seems worthwhile to show the derivation here, since it is not at all obvious. To start, we rewrite Eq. [\(11.19\)](#page-46-1) for a covariant vector Vρ:

$$[\nabla_{\mu}, \nabla_{\nu}] V_{\rho} = R_{\rho\sigma\mu\nu} V^{\sigma} = -R_{\sigma\rho\mu\nu} V^{\sigma} = -R_{\rho\mu\nu}^{\sigma} V_{\sigma}. \tag{12.22}$$

If [∇µ, ∇ν] operates on a tensor with two lower indices (a tensor of type (0, 2)), then

<span id="page-50-1"></span>
$$[\nabla_{\mu}, \nabla_{\nu}] T_{\lambda\sigma} = -R^{\rho}_{\ \lambda\mu\nu} T_{\rho\sigma} - R^{\rho}_{\ \sigma\mu\nu} T_{\lambda\rho} , \qquad (12.23)$$

which follows from applying [∇µ, ∇ν] to a product VλWσ, using the Leibniz rule, and then generalizing by invoking the fact that tensors of the form VλW<sup>σ</sup> can form a basis for the full space of tensors with two lower indices. Now we consider an arbitrary covariant vector field ωσ, and note that the Jacobi identity [\(12.20\)](#page-50-0) implies that

$$[[\nabla_{\mu}, \nabla_{\nu}], \nabla_{\lambda}]\omega_{\sigma} + \text{Cyclic}(\mu, \nu, \lambda) = 0, \qquad (12.24)$$

where Cyclic(µ, ν, λ) means to add the cyclic permutations in the indices µ, ν, and λ; i.e., it means to add a term equal to all preceding terms, but modified by the substitutions (µ → ν, ν → λ, λ → ν), and then add another term equal to the first added term, but with the substitutions (µ → ν, ν → λ, λ → ν) performed on it. Now we expand the outer commutator, and apply Eq. [\(12.23\)](#page-50-1):

$$0 = [\nabla_{\mu}, \nabla_{\nu}] \nabla_{\lambda} \omega_{\sigma} - \nabla_{\lambda} [\nabla_{\mu}, \nabla_{\nu}] \omega_{\sigma} + \text{Cyclic}(\mu, \nu, \lambda)$$

$$= -R^{\rho}_{\lambda\mu\nu} \nabla_{\rho} \omega_{\sigma} - R^{\rho}_{\sigma\mu\nu} \nabla_{\lambda} \omega_{\rho} + \nabla_{\lambda} (R^{\rho}_{\sigma\mu\nu} \omega_{\rho}) + \text{Cyclic}(\mu, \nu, \lambda)$$

$$= -R^{\rho}_{\lambda\mu\nu} \nabla_{\rho} \omega_{\sigma} - R^{\rho}_{\sigma\mu\nu} \nabla_{\lambda} \omega_{\rho} + (\nabla_{\lambda} R^{\rho}_{\sigma\mu\nu}) \omega_{\rho} + R^{\rho}_{\sigma\mu\nu} \nabla_{\lambda} \omega_{\rho} + \text{Cyclic}(\mu, \nu, \lambda)$$

$$(12.25)$$

Now notice that the first term in the last line vanishes under the cyclic sum over µ, ν, and λ, by the cyclic property of the Riemann tensor (Eq. [\(12.5\)](#page-48-0)). The second and fourth terms cancel identically, so we are left with the third term,

$$(\nabla_{\lambda} R^{\rho}_{\sigma\mu\nu})\omega_{\rho} + \text{Cyclic}(\mu, \nu, \lambda) = 0.$$
 (12.26)

Since this holds for any ωρ, we can write

$$\nabla_{\lambda} R^{\rho}_{\ \sigma\mu\nu} + \text{Cyclic}(\mu, \nu, \lambda) = 0, \qquad (12.27)$$

which is exactly the Bianchi identity of Eq. [\(12.21\)](#page-50-2).

From the Riemann curvature tensor, we define the Ricci tensor

$$R_{\mu\nu} \equiv R^{\lambda}_{\ \mu\lambda\nu} \tag{12.28}$$

and the Ricci scalar

$$R \equiv g_{\mu\nu}R^{\mu\nu} \,. \tag{12.29}$$

These satisfy a contracted version of the Bianchi identity:

$$g^{\rho\mu}g^{\sigma\nu}\left[\nabla_{\lambda}R^{\rho}_{\ \sigma\mu\nu} + \nabla_{\mu}R^{\rho}_{\ \sigma\nu\lambda} + \nabla_{\nu}R^{\rho}_{\ \sigma\lambda\mu}\right] = \partial_{\lambda}R - \nabla^{\mu}R_{\mu\lambda} - \nabla^{\mu}R_{\mu\lambda} = 0.$$
 (12.30)

Here, we have used the fact that the connection is metric compatible, so ∇ρgµν = 0, and the fact that the covariant derivative satisfies the Leibniz rule. This tells us that

$$\nabla^{\mu}R_{\mu\nu} = \frac{1}{2}\nabla_{\nu}R. \qquad (12.31)$$

This is the contracted Bianchi identity. Note that the covariant derivative is equivalent to the regular derivative when acting on a scalar.

From this, we see that

$$\nabla_{\mu} \left( R^{\mu\nu} - \frac{1}{2} g^{\mu\nu} R \right) = 0. \tag{12.32}$$

This is important because the quantity in parentheses is the left-hand side of Einstein's field equations. The reason this is the case is because it is necessary to be consistent with conservation of the energy–momentum tensor, T µν. In special relativity, we have ∂µT µν = 0, which gives us conservation of energy and momentum. In general relativity, this expression is made covariant, ∇µT µν = 0. Thus, we see that both sides of Einstein's field equations

$$R^{\mu\nu} - \frac{1}{2}g^{\mu\nu}R = 8\pi G T^{\mu\nu} \tag{12.33}$$

vanish when contracted with a covariant derivative (this property is called being covariantly conserved).

## 12.2 Parallel Transport Around Infinitesimal Closed Loops

We want to see what happens when we parallel transport a vector around an infinitesimal closed loop. We will consider a loop composed of four infinitesimal segments. Without loss of generality, take the initial point of the loop to be the origin, x <sup>µ</sup> = 0. Let the first segment be along the vector A<sup>µ</sup> , the second along a different vector B<sup>µ</sup> , and then the third and fourth along −A<sup>µ</sup> and −B<sup>µ</sup> in order to close the loop, as shown in Figure [4.](#page-52-0) We will consider what happens when we parallel transport a vector V <sup>σ</sup> around this closed loop.

Along A<sup>µ</sup> , the condition of parallel transport is

$$A^{\mu}\nabla_{\mu}V^{\sigma} = A^{\mu}\left[\partial_{\mu}V^{\sigma} + \Gamma^{\sigma}_{\mu\lambda}V^{\lambda}\right] = 0.$$
 (12.34)

To first order,

$$A^{\mu}\partial_{\mu}V^{\sigma} = V^{\sigma}(A^{\mu}) - V^{\sigma}(0). \qquad (12.35)$$

so we have

$$V^{\sigma}(A^{\mu}) - V^{\sigma}(0) = -\Gamma^{\sigma}_{\mu\lambda}A^{\mu}V^{\lambda}(0). \qquad (12.36)$$

<span id="page-52-0"></span>![](_page_52_Picture_3.jpeg)

Figure 4: An infinitesimal loop defined by two vectors  $A^{\mu}$  and  $B^{\nu}$ .

We rewrite this as

$$V^{\sigma}(A) = \left[\delta^{\sigma}_{\lambda} - \Gamma^{\sigma}_{\mu\lambda} \left(\frac{1}{2}A\right) A^{\mu}\right] V^{\lambda}(0), \qquad (12.37)$$

where we have evaluated the Christoffel symbol at the middle of this segment of the loop.

We then have four such legs around the loop. For simplicity, we will reduce our notation by suppressing all indices that are not contracted with  $A^{\mu}$  or  $B^{\mu}$ . For the first segment, we thus schematically write

$$V_f = \left[1 - \Gamma_\mu \left(\frac{1}{2}A\right)A^\mu\right]V_i. \tag{12.38}$$

The full loop is then

$$V_f = \left[1 + \Gamma_{\mu} \left(\frac{B}{2}\right) B^{\mu}\right] \left[1 + \Gamma_{\nu} \left(\frac{A}{2} + B\right) A^{\nu}\right] \left[1 - \Gamma_{\rho} \left(A + \frac{B}{2}\right) B^{\rho}\right] \left[1 - \Gamma_{\sigma} \left(\frac{A}{2}\right) A^{\sigma}\right] V_i. \quad (12.39)$$

We are only calculating to first order in the displacements from the origin, so we can drop terms with products of more than one of the correction terms. We will, however, include terms proportional to the product AB, because this is the area of the loop. We drop terms proportional to  $A^2$  and  $B^2$ , which would cancel if we carried out the calculation to higher order. Note that the terms  $+\Gamma_{\mu}(\frac{B}{2})B^{\mu}$  and  $-\Gamma_{\rho}(A+\frac{B}{2})B^{\rho}$  would cancel if the Christoffel symbols were evaluated at the same point, so their sum is proportional to the derivative of the Christoffel symbol. Thus, we have

$$V_f = \left[ 1 - \frac{\partial \Gamma_{\mu}}{\partial x^{\lambda}} A^{\lambda} B^{\mu} + \frac{\partial \Gamma}{\partial \lambda} B^{\lambda} A^{\mu} - \Gamma_{\mu} A^{\mu} \Gamma_{\lambda} B^{\lambda} + \Gamma_{\mu} B^{\mu} \Gamma_{\lambda} A^{\lambda} \right] V_i, \qquad (12.40)$$

In the final two terms, we did not include the correction from the fact that the Christoffel symbols were evaluated at different points because these corrections are higher than the order to which we are working.

The change in the vector from the parallel transport is then

$$\delta V = V_f - V_i = \left[ -\frac{\partial \Gamma_{\mu}}{\partial x^{\lambda}} A^{\lambda} B^{\mu} + \frac{\partial \Gamma}{\partial \lambda} B^{\lambda} A^{\mu} - \Gamma_{\mu} A^{\mu} \Gamma_{\lambda} B^{\lambda} + \Gamma_{\mu} B^{\mu} \Gamma_{\lambda} A^{\lambda} \right] V_i$$
 (12.41)

We can rewrite this as

$$\delta V = A^{\mu} B^{\nu} \left[ \frac{\partial \Gamma_{\mu}}{\partial x^{\nu}} - \frac{\partial \Gamma_{\nu}}{\partial x^{\mu}} + \Gamma_{\nu} \Gamma_{\mu} - \Gamma_{\mu} \Gamma_{\nu} \right] V_{i} . \tag{12.42}$$

Restoring indices, this is

$$\delta V^{\sigma} = A^{\mu} B^{\nu} \left[ \frac{\partial \Gamma^{\sigma}_{\mu\lambda}}{\partial x^{\nu}} - \frac{\partial \Gamma^{\sigma}_{\nu\lambda}}{\partial x^{\mu}} + \Gamma^{\sigma}_{\nu\rho} \Gamma^{\rho}_{\mu\lambda} - \Gamma^{\sigma}_{\mu\rho} \Gamma^{\rho}_{\nu\lambda} \right] V_{i}^{\lambda} = R^{\sigma}_{\lambda\nu\mu} V_{i}^{\lambda} A^{\mu} B^{\nu} . \tag{12.43}$$

Note that we have found the opposite sign from Carroll's Eq. (3.109). Since Carroll does not give a derivation of this formula, we have no way of knowing the origin of our difference.

If we have any two dimensional surface, the only thing that can happen to the vector is that it can rotate in the plane, and rotations in the plane commute. We could then imagine building up a bigger loop by joining two smaller loops; the interior edges cancel each other, as shown in Figure [5.](#page-53-0)

<span id="page-53-0"></span>![](_page_53_Picture_7.jpeg)

Figure 5: The rotation angle that a vector will experience when parallel transported around the outside of two loops is equal to the sum of the rotation angles that it would experience going around each loop individually, since the contributions from the common edge cancel each other.

Going around the full loop is thus equal to the sum of going around the two loops individually. This allows us to construct finite loops by integrating the corrections from infinitesimal loops. Thus, if there is uniform curvature, such as there is on the sphere or in hyperbolic space, then the rotation angle will simply be proportional to the area of the loop. If the curvature is not constant, then the angle of rotation is simply the integral over the loop of the infinitesimal rotations due to curvature at each point. Note that these arguments do not generalize to higher dimensions, because rotations in more than two dimensions do not commute.

# 13 Lecture 13 (Apr. 3, 2017)

## 13.1 Geodesic Deviation

We now discuss geodesic deviation. We will begin by discussing the approach given in Weinberg's textbook. We first write down the geodesic equation,

$$\frac{\mathrm{d}^2 x^{\mu}}{\mathrm{d}\tau^2} + \Gamma^{\mu}_{\nu\lambda}(x) \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} = 0, \qquad (13.1)$$

where τ is an affine parameter. A geodesic x µ (τ ) satisfies this equation. We also consider a nearby geodesic x µ (τ ) + δx<sup>µ</sup> (τ ); the geodesic equation for this nearby geodesic is then

$$\frac{\mathrm{d}^2}{\mathrm{d}\tau^2}(x^\mu + \delta x^\mu) + \Gamma^\mu_{\nu\lambda}(x + \delta x) \frac{\mathrm{d}}{\mathrm{d}\tau}(x^\nu + \delta x^\nu) \frac{\mathrm{d}}{\mathrm{d}\tau}(x^\lambda + \delta x^\lambda) = 0.$$
 (13.2)

We can then extract the first-order piece of this equation (which should hold on its own), giving

$$\boxed{\frac{\mathrm{d}^2 \delta x^{\mu}}{\mathrm{d}\tau^2} + \frac{\partial \Gamma^{\mu}_{\nu\lambda}}{\partial x^{\rho}} \delta x^{\rho} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} + 2\Gamma^{\mu}_{\nu\lambda}(x) \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \frac{\mathrm{d}\delta x^{\lambda}}{\mathrm{d}\tau} = 0}.$$
(13.3)

This is one form of the geodesic deviation equation.

We now continue with Carroll's approach (Wald's approach is similar). We begin by considering a family of geodesics  $x^{\mu}(\sigma,\tau)$ ; by this, we mean that for each  $\sigma$ ,  $x^{\mu}(\sigma,\tau)$  is a geodesic function of  $\tau$ . We define a vector

$$T^{\mu} \equiv \frac{\partial x^{\mu}}{\partial \tau} \,. \tag{13.4}$$

This is the tangent vector of the geodesics, which is what we would normally call the *velocity*. We also define a vector

$$S^{\mu} \equiv \frac{\partial x^{\mu}}{\partial \sigma} \,. \tag{13.5}$$

This is the geodesic deviation vector, which tells us how  $x^{\mu}$  varies as we move between the geodesics in the family. We further define

$$V \equiv \nabla_T S \,, \tag{13.6}$$

which in coordinates is

$$V^{\mu} = T^{\rho} \nabla_{\rho} S^{\mu} \equiv \frac{\mathrm{D} S^{\mu}}{\mathrm{d}\tau} \,. \tag{13.7}$$

This is the *relative velocity*, which is the rate at which the relative separation of the geodesics changes. Finally, we define

$$A = \nabla_T V \,, \tag{13.8}$$

which in coordinates is

$$A^{\mu} = T^{\sigma} \nabla_{\sigma} V^{\mu} \equiv \frac{\mathrm{D}V^{\mu}}{\mathrm{d}\tau} = \frac{\mathrm{D}^{2} S^{\mu}}{\mathrm{d}\tau^{2}} \,. \tag{13.9}$$

This is the relative acceleration.

Note that these quantities do not have the intuitive interpretations that we might hope they did. As Carroll says on p. 145, we "should take the names [relative velocity and relative acceleration] with a grain of salt." We cannot think of the vector A as being a direct measure of the acceleration of the separation between two nearby geodesics. Because  $A^{\mu}$  is defined in terms of second derivatives, there are general relativistic corrections even in a locally inertial frame, so our intuition from special relativity is not reliable. But these quantities are well-defined, and the geodesic deviation equation that we will derive will, of course, be valid.

We now have

$$A = \nabla_T(\nabla_T S), \tag{13.10}$$

which in coordinates is

$$A^{\mu} = T^{\sigma} \nabla_{\sigma} [T^{\rho} \nabla_{\rho} S^{\mu}]. \tag{13.11}$$

Evaluating the quantity in brackets, we find

$$\nabla_T S^{\mu} = \frac{\partial x^{\rho}}{\partial \tau} \nabla_{\rho} \frac{\partial x^{\mu}}{\partial \sigma} 
= \frac{\partial x^{\rho}}{\partial \tau} \left[ \frac{\partial}{\partial x^{\rho}} \frac{\partial x^{\mu}}{\partial \sigma} + \Gamma^{\mu}_{\rho \lambda} \frac{\partial x^{\lambda}}{\partial \sigma} \right] 
= \frac{\partial^2 x^{\mu}}{\partial \tau \partial \sigma} + \Gamma^{\mu}_{\rho \lambda} \frac{\partial x^{\rho}}{\partial \tau} \frac{\partial x^{\lambda}}{\partial \sigma} .$$
(13.12)

We can similarly compute

$$\nabla_{S} T^{\mu} = \frac{\partial x^{\rho}}{\partial \sigma} \nabla_{\rho} \frac{\partial x^{\mu}}{\partial \tau} 
= \frac{\partial x^{\rho}}{\partial \sigma} \left[ \frac{\partial}{\partial x^{\rho}} \frac{\partial x^{\mu}}{\partial \tau} + \Gamma^{\mu}_{\rho \lambda} \frac{\partial x^{\lambda}}{\partial \tau} \right] 
= \frac{\partial^{2} x^{\mu}}{\partial \sigma \partial \tau} + \Gamma^{\mu}_{\rho \lambda} \frac{\partial x^{\rho}}{\partial \sigma} \frac{\partial x^{\lambda}}{\partial \tau} .$$
(13.13)

We note that this matches the previous expression due to the symmetry of partial derivatives of smooth functions and the fact that we are working in a theory with no torsion. Thus, we have

$$\nabla_S T = \nabla_T S \,. \tag{13.14}$$

This statement can also be written in the form

<span id="page-55-0"></span>
$$[T, S] = 0. (13.15)$$

If we adopted a basis of coordinates for four-space, we start out with a class of function  $x^{\mu}(\sigma,\tau)$  and must come up with two additional coordinates beyond  $\sigma$  and  $\tau$ . These four coordinates would span four-space. In these coordinates, we have  $T^{\mu} = \delta^{\mu}_{\tau}$  and  $S^{\mu} = \delta^{\mu}_{\sigma}$ , where we are using the notation  $T = T^{\mu}\partial_{\mu}$  and  $S = S^{\mu}\partial_{\mu}$ . This gives us an alternative way to justify Eq. (13.15).

Now we can write

$$A^{\mu} \equiv \frac{D^{2}S^{\mu}}{d\tau^{2}}$$

$$= \nabla_{T}(\nabla_{T}S)$$

$$= \nabla_{T}\nabla_{S}T$$

$$= (\nabla_{T}\nabla_{S} - \nabla_{S}\nabla_{T})T + \nabla_{S}\nabla_{T}T.$$
(13.16)

The geodesic equation tells us that  $\nabla_T T = 0$ , so the final term vanishes. We thus have

$$A^{\mu} = ([\nabla_T, \nabla_S]T)^{\mu}. \tag{13.17}$$

Recall now that the curvature tensor is defined by Eq. (11.17),

$$[\nabla_{\mu}, \nabla_{\nu}]V^{\rho} = R^{\rho}_{\sigma\mu\nu}V^{\sigma}. \tag{13.18}$$

We then see that

$$A^{\mu} = [T^{\rho} \nabla_{\rho}, S^{\sigma} \nabla_{\sigma}] T^{\mu}$$

$$= T^{\rho} \nabla_{\rho} (S^{\sigma} \nabla_{\sigma} T^{\mu}) - S^{\sigma} \nabla_{\sigma} (T^{\rho} \nabla_{\rho} T^{\mu})$$

$$= T^{\rho} (\nabla_{\rho} S^{\sigma}) \nabla_{\sigma} T^{\mu} + T^{\rho} S^{\sigma} \nabla_{\rho} \nabla_{\sigma} T^{\mu} - S^{\sigma} (\nabla_{\sigma} T^{\rho}) \nabla_{\rho} T^{\mu} - S^{\sigma} T^{\rho} \nabla_{\sigma} \nabla_{\rho} T^{\mu}.$$

$$(13.19)$$

Now, using the fact that the first and third terms above can be written as

$$\nabla_T S^{\sigma} \nabla_{\sigma} T^{\mu} - \nabla_S T^{\rho} \nabla_{\rho} T^{\mu} = 0, \qquad (13.20)$$

we are left with

$$A^{\mu} = T^{\rho} S^{\sigma} [\nabla_{\rho}, \nabla_{\sigma}] T^{\mu}$$
  
=  $T^{\rho} S^{\sigma} R^{\mu}_{\nu \rho \sigma} T^{\nu}$ . (13.21)

We reorder terms to reach the standard expression,

$$A^{\mu} = R^{\mu}_{\ \nu\rho\sigma} T^{\nu} T^{\rho} S^{\sigma}. \tag{13.22}$$

This is a second form of the geodesic deviation equation.

Now we will derive a third version of the geodesic deviation equation, using the "8.962 approach." Here, we compute  $\frac{d^2\ell}{d\tau^2}$ , where

$$\ell = |S| = \sqrt{g_{\mu\nu}S^{\mu}S^{\nu}} \,. \tag{13.23}$$

The quantity  $\frac{d^2\ell}{d\tau^2}$  really is the acceleration of the distance between nearby geodesics, since  $\ell\Delta\sigma$  is the separation, to first order in  $\Delta\sigma$ , of two geodesics corresponding to nearby values of  $\sigma$ .

Because  $\ell$  is a scalar, we can write

$$\frac{\mathrm{d}^2 \ell}{\mathrm{d}\tau^2} = \nabla_T(\nabla_T \ell) \,. \tag{13.24}$$

We compute

$$\frac{\mathrm{d}\ell}{\mathrm{d}\tau} = \nabla_T \ell 
= \nabla_T \sqrt{g_{\mu\nu} S^{\mu} S^{\nu}} 
= \frac{1}{2} \frac{1}{\ell} \nabla_T (g_{\mu\nu} S^{\mu} S^{\nu}) 
= \frac{1}{\ell} g_{\mu\nu} \frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} S^{\nu}.$$
(13.25)

Here, we have used the fact that the covariant derivative of the metric vanishes. The second derivative is then

$$\frac{\mathrm{d}^{2}\ell}{\mathrm{d}\tau^{2}} = \nabla_{T} \left[ \frac{1}{\ell} g_{\mu\nu} \frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} S^{\nu} \right] 
= \frac{1}{\ell} g_{\mu\nu} \frac{\mathrm{D}^{2}S^{\mu}}{\mathrm{d}\tau^{2}} S^{\nu} + \frac{1}{\ell} g_{\mu\nu} \frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{D}S^{\nu}}{\mathrm{d}\tau} - \frac{1}{\ell^{2}} \left[ \frac{1}{\ell} g_{\lambda\sigma} \frac{\mathrm{D}S^{\lambda}}{\mathrm{d}\tau} S^{\sigma} \right] \left[ g_{\mu\nu} \frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} S^{\nu} \right].$$
(13.26)

To simplify notation, we will begin writing  $A \cdot B = g_{\mu\nu}A^{\mu}B^{\nu}$  for any two vectors  $A^{\mu}$  and  $B^{\mu}$ . We can then rewrite this result, using our expression for the relative acceleration  $A^{\mu}$ , as

$$\left| \frac{\mathrm{d}^2 \ell}{\mathrm{d}\tau^2} = \frac{1}{\ell} R_{\mu\nu\rho\sigma} S^{\mu} T^{\nu} T^{\rho} S^{\sigma} + \frac{1}{\ell^3} \left[ S^2 \frac{\mathrm{D}S}{\mathrm{d}\tau} \cdot \frac{\mathrm{D}S}{\mathrm{d}\tau} - \left( S \cdot \frac{\mathrm{D}S}{\mathrm{d}\tau} \right)^2 \right] \right|. \tag{13.27}$$

This is a third form of the geodesic deviation equation. The first term is the vector  $A^{\mu}$  contracted with  $S^{\mu}$ ; the term in brackets is a general relativistic correction, which shows us explicitly that the acceleration of the distance between the two geodesics is not simply  $A \cdot S/\ell$ , but has other contributions that are independent of A.

The correction term vanishes in two dimensions when we begin with the initial condition  $T \cdot S = 0$ . To see this, we want to show that  $T \cdot S$  is constant along a trajectory. We compute

$$\nabla_T(T \cdot S) = (\nabla_T T) \cdot S^{-0} + T \cdot \nabla_T S = T \cdot \nabla_S T = \frac{1}{2} \nabla_S (T^2) = 0, \qquad (13.28)$$

because  $T^2=-1$  as we have chosen  $\tau$  to be the proper time (or more generally, an affine parameter) along a timelike trajectory. We can then choose  $T\cdot S=0$  initially, and we have just shown that they will then remain orthogonal along two geodesics for all time. We can also see that

$$T \cdot \frac{\mathrm{D}S}{\mathrm{d}\tau} = T \cdot \nabla_T S = T \cdot \nabla_S T = \frac{1}{2} \nabla_S (T^2) = 0.$$
 (13.29)

Thus, both S and  $\frac{DS}{d\tau}$  are orthogonal to T. In D=2, this means that S and  $\frac{DS}{d\tau}$  must be parallel to one another, in which case the correction term vanishes.

## 13.2 The Raychaudhuri Equation

Note: The Raychaudhuri equation appears in Carroll appendix F.

We define a congruence to be a set of curves in an open region such that each point in the region lies on exactly one curve in the set. We are interested in geodesic congruences, in which each curve in the congruence is a geodesic. We can think of a congruence as the set of flow lines of particles in a fluid; in order to have a geodesic congruence, we must require that the fluid be pressureless, because pressures would result in forces other than gravity and would cause the curves to deviate from geodesic trajectories.

Consider

$$\frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} = \nabla_{T}S^{\mu}$$

$$= \nabla_{S}T^{\mu}$$

$$= S^{\rho}\nabla_{\rho}T^{\mu}.$$
(13.30)

We define

$$B^{\mu}_{\ \nu} = \nabla_{\nu} T^{\mu} \,, \tag{13.31}$$

letting us write

$$\frac{\mathrm{D}S^{\mu}}{\mathrm{d}\tau} = B^{\mu}_{\ \nu} S^{\nu} \,. \tag{13.32}$$

We can now ask what happens if S µ is parallel to T µ . In this case, S <sup>µ</sup> doesn't really point between two distinct geodesics, but rather between the same geodesic with different parametrizations. That is, x µ (σ, τ ) and x µ (σ + dσ, τ ) lie on the same geodesic. We are not interested in these deviations, because we want to compare two different geodesics. To this end, we define the projection operator

$$P^{\mu}_{\ \nu} = \delta^{\mu}_{\nu} + T^{\mu}T_{\nu} \,. \tag{13.33}$$

To see that this projection operator does what we want, we note that

$$P^{\mu}_{\ \nu}T^{\nu} = T^{\mu} + T^{\mu}T_{\nu}T^{\nu} = T^{\mu} - T^{\mu} = 0, \qquad (13.34)$$

where we have used T <sup>2</sup> = −1. Thus, P µ <sup>ν</sup> projects onto the normal subspace (the subspace orthogonal to T).

We now check that Bµν (the index-lowered version of B µ <sup>ν</sup> ) is normal:

$$T^{\mu}B_{\mu\nu} = T^{\mu}\nabla_{\nu}T_{\mu} = \frac{1}{2}\nabla_{\nu}(T^{2}) = 0$$

$$T^{\nu}B_{\mu\nu} = T^{\nu}\nabla_{\nu}T_{\mu} = 0.$$
(13.35)

Thus, Bµν is entirely normal.

# 14 Lecture 14 (Apr. 5, 2017)

## 14.1 The Raychaudhuri Equation

We now continue our discussion of the Raychaudhuri equation. We are considering a geodesic congruence, which is a family of geodesics x µ (σ<sup>i</sup> , τ ). Here, σ<sup>i</sup> for i = 1, 2, 3 parametrize which geodesic we are on, and τ is the proper time along this geodesic. There are three parameters specifying the geodesic because the family of geodesics is assumed to be space-filling with the region we are considering. For each x in this region, x <sup>µ</sup> = x µ (σ<sup>i</sup> , τ ) for exactly one value of (σ<sup>i</sup> , τ ). We then define the tangent and geodesic deviation vectors

$$T^{\mu} \equiv \frac{\partial x^{\mu}}{\partial \tau}, \quad S^{\mu}_{(i)} \equiv \frac{\partial x^{\mu}}{\partial \sigma_i}.$$
 (14.1)

As we saw last time, the relative velocity vector can be written

$$\frac{\mathrm{D}S_{(i)}^{\mu}}{\mathrm{d}\tau} = T^{\rho}\nabla_{\rho}S_{(i)}^{\mu} = \nabla_{T}S_{(i)}^{\mu} = \nabla_{S_{(i)}}T^{\mu} = S_{(i)}^{\nu}\nabla_{\nu}T^{\mu} = B^{\mu}_{\ \nu}S_{(i)}^{\nu}, \tag{14.2}$$

where

$$B^{\mu}_{\ \nu} \equiv \nabla_{\nu} T^{\mu} \,. \tag{14.3}$$

We define a projection operator that is useful for timelike geodesics,

$$P^{\mu}_{\ \nu} = \delta^{\mu}_{\nu} + T^{\mu}T_{\nu} \,, \tag{14.4}$$

which projects onto the subspace normal to T,  $P^{\mu}_{\ \nu}T^{\nu}=0$ . We saw last time that

$$T^{\mu}B_{\mu\nu} = T^{\nu}B_{\mu\nu} = 0, \qquad (14.5)$$

so  $B_{\mu\nu}$  is normal to T.

We now want to decompose  $B_{\mu\nu}$  into invariant pieces. We can always take any two-tensor and decompose it into a symmetric and an antisymmetric part; the symmetric part has a trace, in general, and so we further decompose it into a trace part and a traceless part. These different parts (trace, symmetric traceless, and antisymmetric) are invariant in the sense that they still have these properties after an arbitrary coordinate transformation. We then write  $B_{\mu\nu}$  as

$$B_{\mu\nu} = \frac{1}{3}\theta P_{\mu\nu} + \sigma_{\mu\nu} + \omega_{\mu\nu} \,. \tag{14.6}$$

In this order, these are the trace part, the symmetric traceless part, and the antisymmetric part. Here,  $\theta$  is a scalar that is equal to the trace of  $B_{\mu\nu}$ , and we write this term proportional to  $P_{\mu\nu}$  because this projector is normal to T, and we know that  $B_{\mu\nu}$  is normal to T.

We can determine explicit expressions for each of the parts of this decomposition. We see that

$$g^{\mu\nu}B_{\mu\nu} = \theta = \nabla_{\mu}T^{\mu} \,. \tag{14.7}$$

Thus,  $\theta$  is the divergence of the fluid flow, if we think of these geodesics as representing the flow of a pressureless fluid. We can also write

$$\sigma_{\mu\nu} = B_{(\mu\nu)} - \frac{1}{3}\theta P_{\mu\nu} \,,$$
 (14.8)

where the  $-\frac{1}{3}\theta P_{\mu\nu}$  correction guarantees that  $\sigma_{\mu\nu}$  is traceless, and

$$\omega_{\mu\nu} = B_{[\mu\nu]} \,. \tag{14.9}$$

We have now decomposed  $B_{\mu\nu}$  into three invariant pieces.

We are interested in

$$\frac{\mathrm{D}B_{\mu\nu}}{\mathrm{d}\tau} = T^{\sigma}\nabla_{\sigma}B_{\mu\nu} = T^{\sigma}\nabla_{\sigma}\nabla_{\nu}T_{\mu}. \tag{14.10}$$

We can rewrite this in the form

$$\frac{\mathrm{D}B_{\mu\nu}}{\mathrm{d}\tau} = T^{\sigma}\nabla_{\nu}\nabla_{\sigma}T_{\mu} + T^{\sigma}[\nabla_{\sigma}, \nabla_{\nu}]T_{\mu}$$

$$= \nabla_{\nu}(T^{\sigma}\nabla_{\sigma}T_{\mu}) - (\nabla_{\nu}T^{\sigma})(\nabla_{\sigma}T_{\mu}) + T^{\sigma}R^{\lambda}_{\mu\nu\sigma}T_{\lambda}.$$
(14.11)

In the second line, we have rewritten the first term by pulling T σ into the covariant derivative and then subtracting off the additional term this produces, and we have rewritten the second term using the definition of the Riemann tensor, where the form shown in Eq. [\(12.22\)](#page-50-3) is the closest to this usage. The first term on the right-hand side is zero by the geodesic equation, ∇<sup>T</sup> T = 0. We thus have

$$\frac{DB_{\mu\nu}}{d\tau} = -B^{\sigma}_{\ \nu}B_{\mu\sigma} + R_{\lambda\mu\nu\sigma}T^{\sigma}T^{\lambda}. \tag{14.12}$$

<span id="page-59-0"></span>Note that Carroll has the wrong sign on the final term.

We can then take the trace by contracting with g µν; note that this will turn the Riemann tensor into the Ricci tensor (with a minus sign, because the Ricci tensor is defined by contracting the first and third indices of the Riemann tensor). We then have

$$\frac{\mathrm{d}\theta}{\mathrm{d}\tau} = -B^{\sigma}_{\ \nu}B^{\nu}_{\ \sigma} - R_{\lambda\sigma}T^{\lambda}T^{\sigma}. \tag{14.13}$$

Note that we now have an ordinary derivative because θ is a scalar. We can then plug in the decomposition of Bµν to reach the Raychaudhuri equation,

$$\boxed{\frac{\mathrm{d}\theta}{\mathrm{d}\tau} = -\frac{1}{3}\theta^2 - \sigma_{\mu\nu}\sigma^{\mu\nu} + \omega_{\mu\nu}\omega^{\mu\nu} - R_{\lambda\sigma}T^{\lambda}T^{\sigma}}.$$
(14.14)

How can we interpret this equation?

1. First, we note that we can take the antisymmetric part of Eq. [\(14.12\)](#page-59-0) to reach

$$\frac{D\omega_{\mu\nu}}{d\tau} = -\frac{2}{3}\theta\omega_{\mu\nu} + \sigma_{\mu}{}^{\alpha}\omega_{\nu\alpha} - \sigma_{\nu}{}^{\alpha}\omega_{\mu\alpha}.$$
 (14.15)

Note that if we have ωµν = 0 initially, then ωµν = 0 along the entire geodesic. We can use this to create a geodesic congruence in which ωµν vanishes everywhere; these are called irrotational flows, because ωµν describes rotation of the fluid.

2. We also note that

$$\sigma_{\mu\nu}\sigma^{\mu\nu} \ge 0\,, (14.16)$$

because σµν is normal to T µ , so in a locally inertial frame in which T µ 0 has only a time component, σµ0<sup>ν</sup> <sup>0</sup> will have only spatial components.

3. We define the strong energy condition (SEC), which is the statement that

$$R_{\mu\nu}T^{\mu}T^{\nu} \ge 0 \tag{14.17}$$

for any timelike T µ (this is called the strong energy condition because Einstein's equations relate the Ricci tensor to the energy–momentum tensor). For example, for a perfect fluid, this amounts to requiring that both ρ + p ≥ 0 and ρ + 3p ≥ 0, where ρ is the energy density and p is the pressure. (The first condition was mistakenly omitted in lecture; when the SEC fails, it is usually the second condition that fails.) When this holds, the Raychaudhuri equation implies

$$\frac{\mathrm{d}\theta}{\mathrm{d}\tau} \le -\frac{1}{3}\theta^2 \,. \tag{14.18}$$

This tells us that under these assumptions gravity always focuses, rather than defocuses, rays; the divergence gets more negative as time goes on. This statement is used to prove the famous singularity theorems of general relativity.

Although most systems do satisfy the strong energy condition, there do exist systems that violate it. In particular, a state dominated by the potential energy of a scalar field has the property that p = −ρ, with ρ > 0. This violates the strong energy condition. In this case, gravity defocuses rather than focuses, which is exactly what happens in an inflationary universe. Inflationary cosmology is based on the assumption that there was a brief phase in the early history of our universe in which p = −ρ.

We can now consider the lightlike version of the Raychaudhuri equation. In this case, we will let T <sup>µ</sup> ∝ k µ , with k <sup>2</sup> = 0. In this case, the tangent vector itself is normal to the space it generates. We will only summarize the approach for this case. We introduce an auxiliary lightlike vector ` µ , such that in some inertial frame we can write

$$k^{\mu} = (k^0, \vec{k}), \quad \ell^{\mu} = (k^0, -\vec{k}).$$
 (14.19)

We can normalize these so that

$$k \cdot \ell = -(k^0)^2 - (\vec{k})^2 = -1.$$
 (14.20)

We replace the projector Pµν by

$$Q_{\mu\nu} = g_{\mu\nu} + k_{\mu}\ell_{\nu} + k_{\nu}\ell_{\mu}. \tag{14.21}$$

This gives us

$$Q_{\mu\nu}k^{\mu} = Q_{\mu\nu}\ell^{\mu} = 0. {14.22}$$

We still have

$$\theta = \nabla_{\mu} T^{\mu} \,. \tag{14.23}$$

Then, for an affine parameter λ, we have

$$\frac{\mathrm{d}\theta}{\mathrm{d}\lambda} \le -\frac{1}{2}\theta^2 \tag{14.24}$$

if

$$R_{\mu\nu}k^{\mu}k^{\nu} \ge 0 \tag{14.25}$$

for any lightlike vector k µ , which is known as the null energy condition (NEC). For a perfect fluid, this condition is ρ + p ≥ 0. Note that inflationary states satisfy this condition classically; however, because ρ + p = 0 for the states dominated by the potential energy of a scalar field, quantum fluctuations about zero will cause the state to violate the condition quantum mechanically about half the time. The null energy condition still holds in the average at a quantum mechanical level, because the quantum fluctuations are just as likely to be positive as negative; thus, these states do satisfy the average null energy condition, which comes from averaging along a geodesic, at the level of quantum mechanics. Most of the singularity theorems have been extended to include systems that satisfy this condition.

The null energy condition tells us that collapsing universes cannot bounce; if a collapsing universe bounced to become an expanding universe, then converging lightlike rays would become diverging ones, violating the null energy condition. One of the only mathematical constructions of a system that violates the null energy condition is the "ghost condensate," which has the bizarre property that there is a nonzero value of  $\dot{\phi}$  in the ground state, so that the scalar fields keep running along the real axis in the ground state. It is not known whether this state is stable.

### 14.2 Homotopy Groups

At this point, we will depart from the study of general relativity to make a brief detour into homotopy theory. In the context of particle theory and especially applications of particle theory to cosmology, homotopy theory allows one to understand how spontaneously broken gauge theories can give rise to topological defects, such as magnetic monopoles and cosmic strings. These objects are interesting from the point of view of general relativity, since they have relevance for cosmology, and because the spacetime of a cosmic string is rather interesting and counterintuitive. Homotopy theory is also highly relevant to topological considerations in condensed matter physics (see the article by N. D. Mermin cited in Problem Set 9). Our goal will be an understanding of something called the exact homotopy sequence, which is a powerful example of using fiber bundle ideas to prove some very useful results. Although our treatment will be quick and far from rigorous, it will be possible to understand the basic definitions and to follow the key steps of the logic. The beauty of the exact homotopy sequence is that a series of simple steps can lead to a final result which seems much more powerful than anything that went into it.

For a manifold M and a point  $m_0 \in M$ , we wish to define the nth homotopy group  $\pi^n(M, m_0)$ , for  $n \in \mathbb{Z}, n \geq 1$ . Note that  $\pi^1(M, m_0)$  is also called the fundamental homotopy group, or simply the fundamental group. The homotopy groups are defined in terms of continuous mappings  $f: S^n \to M$  (recall that  $S^n$  is the n-dimensional surface of a sphere in n + 1 dimensions).

For  $S^n$ , we choose an arbitrary base point  $p_0$  (which will refer to as the "north pole"). For the manifold M, we have chosen an arbitrary base point  $m_0$ . For the mappings  $f: S^n \to M$  that we consider, we require that  $f(p_0) = m_0$ .

We must further define the concept of a homotopy. Two maps  $f_1$  and  $f_2$  of the above type are homotopic if they can be continuously deformed into each other. (Recall that a function on a topological space is continuous if the preimage of any open set in its codomain is an open set in its domain. Our brief discussion of homotopy groups, however, will make no attempt at rigor, so we will consider a function to be continuous if it "looks" continuous.) Two maps  $f_1$  and  $f_2$  of the above type can be continuously deformed into one another if there exists a continuous interpolating function  $F(p,t): S^n \times [0,1] \to M$  such that  $F(p,t=0) = f_1(p)$ ,  $F(p,t=1) = f_2(p)$ , and  $F(p_0,t) = m_0$  for any t.

We define [f], the homotopy class of f, to be the set of all such maps that are homotopic to f. These homotopy classes will be the elements of the group  $\pi^n(M, m_0)$ . We will continue next time to define the group multiplication operation of these elements.

# 15 Lecture 15 (Apr. 10, 2017)

### 15.1 Homotopy Groups

Last time, we defined the elements of  $\pi^n(M, m_0)$ , the *n*th homotopy group, where M is a manifold with a base point  $m_0$ . These groups were defined by considering maps  $f: S^n \to M$  with  $f(p_0) = m_0$ , where  $S^n$  is the *n*-sphere (boundary of the ball in  $\mathbb{R}^{n+1}$ ) with  $p_0$  the north pole; two such functions

f<sup>1</sup> and f<sup>2</sup> are homotopic if f<sup>1</sup> can be continuously deformed to f2. We define [f], the homotopy class of f, to be the set of all ˜f that are homotopic to f. The set of all homotopy classes is the set of elements of the homotopy group π n (M, m0).

<span id="page-62-0"></span>Now, we must define the multiplication operation of the homotopy groups. We introduce "standard coordinates" on S n , which we construct in two steps. First, we visualize the sphere as S 2 , and imagine breaking it apart at the north pole p0. We imagine that it is made of soft putty, so that we can deform it into a flat, finite disk. The entire boundary of the disk will be the north pole and the center will be the south pole. The latitude lines are mapped to concentric circles on the disk, and the longitude lines are mapped to radial lines on the disk, as shown in Figure [6.](#page-62-0)

![](_page_62_Picture_5.jpeg)

Figure 6: Deforming a sphere into a disk.

We will now describe this in coordinates, in arbitrary dimension n. We start with the sphere defined as

$$S^{n} = \{(x_{1}, \dots, x_{n+1}) : x_{1}^{2} + x_{2}^{2} + \dots + x_{n+1}^{2} = 1\},$$

$$(15.1)$$

which is a redundant description of the n-dimensional S <sup>n</sup> using n + 1 coordinates. We then map this into the n-dimensional ball

$$B^{n} = \{(y_{1}, \dots, y_{n}) : y_{1}^{2} + \dots + y_{n}^{2} \le 1\}$$
(15.2)

such that p<sup>0</sup> is mapped to the entire outer edge. The north pole, in the original coordinates, is

$$p_0 = (0, 0, \dots, 0, 1). \tag{15.3}$$

We can similarly define the south pole as

south pole = 
$$(0, 0, \dots, 0, -1)$$
. (15.4)

For any point p = (x1, . . . , xn+1) on the sphere, we can construct a unit vector tangent to the sphere at the south pole, which points toward p:

$$\hat{x}_i = \frac{x_i}{\sqrt{x_1^2 + \dots + x_n^2}}, \quad \text{for } i = 1, \dots, n.$$
 (15.5)

We can then use the unit vectors to define the map y(x): S <sup>n</sup> → B<sup>n</sup> ,

$$y_i = \frac{1}{2}(1 + x_{n+1})\hat{x}_i. {15.6}$$

That was all step one. In step two, we want to map this unit ball to a unit n-cube. Again, we visualize the map for n = 2, so we are mapping a disk into a square. We will do so such that the

<span id="page-63-0"></span>![](_page_63_Picture_3.jpeg)

Figure 7: Deforming a disk into a square.

longitude lines—which were mapped to radial directions on the disk—are still mapped to radial directions on the square, but the latitude lines—which were mapped to concentric circles on the disk—are deformed to concentric squares within the image square, as shown in Figure [7.](#page-63-0)

The north pole p<sup>0</sup> is again mapped to the entire outer edge. In coordinates, the cube is defined by

$$C^{n} = \{(z_{1}, \dots, z_{n}) : 0 \le z_{i} \le 1, \forall i\}.$$
(15.7)

The map to these coordinates, in terms of the coordinates y<sup>i</sup> , is given by

<span id="page-63-2"></span><span id="page-63-1"></span>
$$z_i = \frac{1}{2} \left( 1 + \frac{R}{M} y_i \right), \tag{15.8}$$

with

$$R = \sqrt{y_1^2 + \ldots + y_n^2}, \quad M = \max_{1 \le i \le n} (|y_i|).$$
 (15.9)

Note that for any point on the outer edge of the ball B<sup>n</sup> , R = 1, and then Eq. [\(15.8\)](#page-63-1) implies that the coordinate z<sup>i</sup> for the value of i that maximizes |y<sup>i</sup> | will be 0 or 1, placing the point (z1, . . . , zn) on the outer edge of the cube.

We can now define multiplication on the set of homotopy classes. Given homotopy classes [f1] and [f2], we first choose a representative map from each, f<sup>1</sup> ∈ [f1], f<sup>2</sup> ∈ [f2]; our multiplication operation will be well-defined, in the sense that it will not depend on this choice. We define the product of these two maps (acting on the coordinates zi) to be

$$f(z_1, \dots, z_n) = \begin{cases} f_1(z_1, \dots, z_{n-1}, 2z_n) & z_n \le \frac{1}{2} \\ f_2(z_1, \dots, z_{n-1}, 2z_n - 1) & z_n \ge \frac{1}{2} \end{cases}$$
 (15.10)

Note that this map is well-defined at z<sup>n</sup> = 2 ; in this case, the final argument of f<sup>1</sup> is 1 and the argument of f<sup>2</sup> is 0, meaning that we are on the boundary in each case. The boundary of the cube is the north pole of the sphere. These maps were all defined so that the north pole of the sphere is mapped to the base point m<sup>0</sup> ∈ M, so these two functions agree at this point. Pictorially, the multiplication operation of Eq. [\(15.10\)](#page-63-2) is illustrated in Figure [8.](#page-64-0)

It can be formally shown that [f] is independent our choice of the representatives f<sup>1</sup> of [f1] and [f2] of [f2]; thus, this multiplication on the individual maps can be lifted to a multiplication of the homotopy classes.

<span id="page-64-0"></span>![](_page_64_Picture_3.jpeg)

Figure 8: The product f = f<sup>2</sup> ◦ f1. The dots shown within each cube represent the points in M to which these points are mapped. In principle, these dots should fill the space inside the cubes, and should be color-coded to indicate the point in M to which every point in the cube is mapped. The multiplication operation creates one map f : C <sup>n</sup> → M from two such maps, by compressing the two original cubes along the z<sup>n</sup> direction, and then combining the two cubes into one.

We now must verify that this multiplication on the set of homotopy classes defines a group. First, we check associativity:

$$[f_3 \circ (f_2 \circ f_1)] = [(f_3 \circ f_2) \circ f_1]. \tag{15.11}$$

This is apparent from our construction, because we can continuously deform the product f3◦(f2◦f1) into the product (f<sup>3</sup> ◦ f2) ◦ f1, so they belong to the same homotopy class.

<span id="page-64-1"></span>Next, we must check the existence of an identity. The identity element [e] is the homotopy class of the map e: S <sup>n</sup> → M the maps every point to the base point in the manifold, e(S n ) = m0. When we compose this map with another map f, the result is just a compressed version of f, which can be continuously deformed back to f.

![](_page_64_Picture_9.jpeg)

Figure 9: Constructing the inverse of a homotopy group element.

Finally, we check the existence of inverses. For any group element [f] with representative f, we define the inverse [f −1 ] to be the homotopy class of the map

$$f^{-1}(z_1, \dots, z_n) = f(z_1, \dots, z_{n-1}, 1 - z_n).$$
(15.12)

The composition f <sup>−</sup><sup>1</sup> ◦f can be continuously deformed to the identity e as follows: the composition is symmetric about the plane z<sup>n</sup> = 1 2 on the cube, as shown in Figure [9.](#page-64-1) We can now move two planes outward in opposite directions from z<sup>n</sup> = 1 2 , toward z<sup>n</sup> = 0 and z<sup>n</sup> = 1, at the same speed; at any point, the points on the two planes are mapped to the manifold in the same way, because the map is symmetrically arranged about the plane z<sup>n</sup> = 1 2 . We deform the map between the planes to be independent of zn, with values equal to those on the two planes. Once the planes reach the edges of the cube, this map is the identity, because the entire boundary of the cube is mapped to the base point of the manifold. Thus, we have constructed the inverse elements of the group.

We conclude that π n (M, m0) is a group under this multiplication operation. For n ≥ 2, this group is abelian, meaning that the multiplication operator is commutative. Figure [10](#page-65-0) shows pictorially why this is the case.

<span id="page-65-0"></span>![](_page_65_Picture_5.jpeg)

Figure 10: For n ≥ 2, π n (M, m0) is abelian. The diagram shows pictorially how the product f<sup>2</sup> ◦ f<sup>1</sup> can be continuously deformed into f<sup>1</sup> ◦ f2.

For n = 1 (the fundamental group), however, the multiplication is not commutative in general. Consider, for example, a plane with two points A and B removed; we could consider a loop that travels first counterclockwise around A and then counterclockwise around B. This is clearly different from a loop that travels first counterclockwise around B and then counterclockwise around A, as illustrated in Figure [11.](#page-65-1)

<span id="page-65-1"></span>![](_page_65_Picture_8.jpeg)

Figure 11: For n = 1, homotopy groups are not necessarily abelian. The diagram illustrates an example where it is not.

We now want to determine the dependence of the homotopy group on the base point. Consider  $\pi^n(M, m_0)$  and  $\pi^n(M, \tilde{m}_0)$ , the *n*th homotopy groups of M with respect to two different base points  $m_0$  and  $\tilde{m}_0$ . We will show that, if  $m_0$  and  $\tilde{m}_0$  can be connected by a continuous path in M, there is an *isomorphism* (a group structure preserving, one-to-one, onto map) between these groups, proving that they are isomorphic (for all intents and purposes, they are the same group). Consider the homotopy class  $[f] \in \pi^n(M, m_0)$ ; this is the set of all continuous deformations of the map  $f(z_1, \ldots, z_n)$  on the *n*-cube such that the whole boundary of the cube is mapped to  $m_0$ . We want to map this to an element of the homotopy group  $\pi^n(M, \tilde{m}_0)$ , in which every point on the boundary of the *n*-cube is mapped to  $\tilde{m}_0$ .

Let m(t) describe a path in M that varies continuously from  $m_0$  to  $\tilde{m}_0$  as t varies from 0 to 1. Construct the new map  $\tilde{f}: C^n \to M$  by first shifting and rescaling the coordinates  $z_i$  so that the original map is confined to a smaller cube, say one for which  $0.1 \le z_i \le 0.9$  for all i. For values of  $z_i$  that lie outside this range, which we will call the outer shell, define  $\tilde{f}$  to map to m(t), where t is defined to vary continuously from 0 to 1 as the point  $(z_1, \ldots, z_n)$  varies from the outer edge of the smaller cube to the edge of the full cube. The values of  $\tilde{f}(z_1, \ldots, z_n)$  for points in the outer shell are fixed, independent of f. The new map  $\tilde{f}$  is illustrated in Figure 12. This deformation maps every element of  $\pi^n(M, m_0)$  to an element of  $\pi^n(M, \tilde{m}_0)$ . To construct the inverse map, just change the mapping of the outer shell by replacing t by t-t. The two groups t0 and t1 and t2 are thus isomorphic, which means that these two groups have the exact same group structure. For this reason, many authors simply write t2 and t3 are thus base point.

<span id="page-66-0"></span>![](_page_66_Picture_5.jpeg)

Figure 12: Changing the base point of a homotopy group.

Example 1 Consider  $\pi^1(S^m)$  for m > 1. This can be visualized by drawing a closed loop on the surface of the sphere, which denotes the image of the original circle in the sphere  $S^m$ . The image of this circle can never fill space, so there is some point on the sphere that we can puncture to stretch the sphere into a disk, as we did before, with the loop contained in the disk. The entire boundary of the disk is mapped to the point we punctured, so the loop cannot touch the boundary; the loop and the base point  $m_0$ , which is on the loop, are entirely inside the disk. Thus, there is no obstruction to continuously deforming the loop onto the base point, which defines a continuous deformation of the loop to the identity map. This shows us that the only homotopy class in this homotopy group is [e], the homotopy class of the identity map. Thus,  $\pi^1(S^m) = 1$ , the trivial group.

**Example 2** We now consider  $\pi^1(S^1)$ . It turns out that  $\pi^1(S^1) = \mathbb{Z}$ , the group if integers. We see that when we map the circle into the circle, we can choose to wind it around the circle any integer number of times in the counterclockwise direction before it finally ends at the starting point; the number of times we wrap around the circle is called the *winding number*. Formally, we have a map

 $f: S^1 \to S^1$  with  $f(p_0) = p_0$ . We can parametrize  $S^1$  by  $\theta$ , with  $\theta \sim \theta + 2\pi$ . Take  $p_0$  to be the point  $\theta = 0$ , so we have f(0) = 0. We can then construct f such that  $f(2\pi) = 2\pi n \sim 0$ , for  $n \in \mathbb{Z}$ . This n is the winding number. If we take the product of two such maps, their winding numbers add; thus, the group product of  $\pi^1(S^1)$  is equivalent to the operation of addition for the integers  $\mathbb{Z}$ .

**Example 3** It turns out that, in general,  $\pi^n(S^n) = \mathbb{Z}$ . We will not prove this now.

**Example 4** It is clear that  $\pi^n(S^1) = 1$  for n > 1; the only way to map a higher-dimensional sphere into the circle is trivially.

**Example 5** More surprisingly,  $\pi^3(S^2) = \mathbb{Z}$ . (This fact is related to the famous Hopf fibration, which you may be familiar with.)

## 16 Lecture 16 (Apr. 12, 2017)

### 16.1 Homotopy Groups

Recall that the elements of the homotopy group  $\pi^n(M, m_0)$ , where M is a manifold with base point  $m_0$ , are equivalence classes of maps  $f : S^n \to M$  with the property  $f(p_0) = m_0$ , where  $p_0$  is the north pole of  $S^n$ . The equivalence classes are the homotopy classes, in which the elements are related by homotopies. To define multiplication on this set, we first devised a procedure to map a sphere  $S^n$  (a spherical shell with no interior) on to a cube  $C^n$  (a cube with interior). The multiplication operation of two homotopy classes is to take a representative from each class, determine its action on the cube  $C^n$ , and then glue the two cubes together along a face; we can then rescale the resulting figure to a cube and interpret the result as a map in and of itself, which will be a representative of a new homotopy class.

### 16.2 Spontaneous Symmetry Breaking in a Field Theory

Spontaneous symmetry breaking is a crucial mechanism within the Standard Model of particle physics, a model which can successfully explain all particle physics experiments that we are capable of doing. (Neutrino masses were not allowed in the "classic" form of the model, but it can be modified to include them. We are not sure, however, that we know the right way to add neutrino masses.) Spontaneous symmetry breaking is also present in many extensions of the Standard Model, including grand unified theories.

We now define some terminology. These particle physics theories will contain Higgs fields  $\phi_i(\vec{x},t)$ ,  $i=1,\ldots,n$ ; we will sometimes write  $\vec{\phi}(\vec{x},t)$  to indicate all values of i in one notation. In the Standard Model, there are four real Higgs fields (two complex Higgs fields). We define  $\mathcal{H}$  to be the space of all values of  $\vec{\phi}$  at a given point in space. In most cases,  $\mathcal{H} = \mathbb{R}^n$ .

The important quantity that defines the physics of these Higgs fields is their potential energy density  $V(\vec{\phi})$ , often referred to simply as the "potential."

**Example 6** An example is the potential energy density for the electric field,

$$V(\vec{E}) = \frac{1}{8\pi} |\vec{E}|^2. \tag{16.1}$$

The potential energy here is the amount of energy we would need to construct this configuration of fields; the same will be true of the potential energies of the scalar Higgs fields we will discuss.

We will consider the symmetry group G of  $V(\vec{\phi})$ , meaning that  $V(g\vec{\phi}) = V(\vec{\phi})$  for any  $g \in G$ . The group G includes the gauge group, but may also include additional global symmetries, such as  $\phi_i \to -\phi_i$ .

**Example 7** An example of a gauge theory is electromagnetism; the gauge symmetry is manifest when expressed in terms of the four-vector potential  $A_{\mu}$ . The electromagnetic field strength tensor is

$$F_{\mu\nu} = \partial_{\mu}A_{\nu} - \partial_{\nu}A_{\mu} \,. \tag{16.2}$$

This theory is invariant under a gauge transformation

$$A_{\mu}(x) \to A'_{\mu}(x) = A_{\mu}(\vec{x}, t) + \partial_{\mu} \Lambda(\vec{x}, t). \tag{16.3}$$

These transformations depend on space and time, and are thus called local transformations. The term "gauge symmetry" is synonymous with "local symmetry." The function  $\Lambda(\vec{x},t)$  defines the gauge transformation. If we compute the field strength tensor after making the transformation, we will find that it is unchanged,  $F'_{\mu\nu} = F_{\mu\nu}$ . For this reason,  $A'_{\mu}(x)$  and  $A_{\mu}(x)$  describe the same physics. The gauge group in this case can be thought of as the group of the real numbers under addition, as  $\Lambda(\vec{x},t)$  would suggest, but it is usually described as U(1), the group of  $1 \times 1$  unitary matrices, also known as the circle group. This is because fields associated with charged particles are complex fields that transform as

$$\psi(x) \to \psi'(x) = e^{iq\Lambda(\vec{x},t)}\psi(\vec{x},t), \qquad (16.4)$$

where q is the charge, and the transformation for the gauge fields can also be written in terms of the phase factor, since

$$\partial_{\mu}\Lambda(\vec{x},t) = -\frac{i}{q}e^{-iq\Lambda(\vec{x},t)}\partial_{\mu}e^{iq\Lambda(\vec{x},t)}.$$
(16.5)

We now pick out a particular  $\vec{\phi}_0$ , which is some particular choice of minimum of the potential  $V(\vec{\phi})$ ; in all interesting cases, the minimum will not be unique. We define a manifold  $\mathcal{M} \subset \mathcal{H}$ , called the manifold of degenerate vacua (or the moduli space), given by

$$\mathcal{M} = \{ \vec{\phi} \in \mathcal{H} : V(\vec{\phi}) = V(\vec{\phi}_0) \}. \tag{16.6}$$

This is the space of all values of  $\vec{\phi}$  that minimize the potential. We assume that for every  $\vec{\phi} \in \mathcal{M}$ , there exists some  $g \in G$  such that  $\vec{\phi} = g\vec{\phi}_0$ . This assumption says that there are no "accidental" vacua; every vacuum is related by the symmetry group to our specially chosen vacuum.

If the Higgs field lies in the vacuum manifold  $\mathcal{M}$ , this will usually break some portion of the symmetry group G. In general, there is an unbroken subgroup H of G, which leaves the vacuum  $\vec{\phi}_0$  invariant. Consider some  $\vec{\phi} \in \mathcal{M}$ . By assumption, there exists a  $g \in G$  such that  $\vec{\phi} = g\vec{\phi}_0$ . It follows that  $\vec{\phi} = gh\vec{\phi}_0$  for any  $h \in H$ , because H is the subgroup of transformations that leave  $\vec{\phi}_0$  invariant. Thus, we see that  $\mathcal{M}$  is the quotient space

$$\mathcal{M} = G/H. \tag{16.7}$$

In words, an element of  $\mathcal{M}$  can be identified with an equivalence class of elements of G, where two elements  $g_1, g_2 \in G$  are equivalent if  $g_1 = g_2 h$  for some  $h \in H$ .

**Example 8** One example of a symmetry group is G = SO(3), which is the group of  $3 \times 3$  orthogonal  $(\mathcal{O}^T = \mathcal{O}^{-1})$  matrices with det  $\mathcal{O} = 1$ . This is the group of rigid rotations in three dimensions. We consider a vector

$$\vec{\phi} = (\phi_1, \phi_2, \phi_3), \tag{16.8}$$

which is a vector under SO(3), meaning that it transforms as  $\vec{\phi} \to \mathcal{O}\vec{\phi}$ .

<span id="page-69-0"></span>The potential must be invariant under SO(3), which means that it is a function  $V(\vec{\phi}) = V(||\vec{\phi}||)$ . In order to be interesting, we will assume that the potential is minimized at  $||\vec{\phi}|| = \sigma$ , as illustrated in Figure 13.

![](_page_69_Figure_7.jpeg)

Figure 13: An example of a Higgs field potential.

A choice of minimum of the potential is then

<span id="page-69-1"></span>
$$\vec{\phi}_0 = \sigma \hat{z} \,. \tag{16.9}$$

This is not invariant under rotations about the x- or y-axes, but it is invariant under rotations about the z-axis. Thus, the unbroken subgroup is

$$H = \{ \text{rotations about } z \text{-axis} \} = SO(2) \cong U(1),$$
 (16.10)

where  $\cong$  indicates that the groups are isomorphic. The space of degenerate vacua is

$$\mathcal{M} = \left\{ \vec{\phi} \in \mathcal{H} : \vec{\phi} = \sigma \hat{n}, \ \hat{n} = \text{unit vector in } \mathbb{R}^3 \right\}.$$
 (16.11)

In the language of groups, this is

$$\mathcal{M} = G/H = SO(3)/SO(2)$$
. (16.12)

Topologically, Eq. (16.11) shows that this is the two-sphere, so  $SO(3)/SO(2) \cong S^2$ , where  $\cong$  in this case indicates that these topological spaces are homeomorphic (there exists a one-to-one, onto, continuous map between the spaces, which means that from a topological viewpoint they are equivalent).

### 16.3 Topological Defects

#### 16.3.1 Monopoles

There are several types of topological defects we can discuss; the first is the *monopole*. By this, we mean a point-like, topologically stable twist in the Higgs fields. The reason this is called a monopole is because, in the full theory including the gauge fields, these configurations, which would behave as particles, would necessarily have a net magnetic charge. Consider a 3D space with vacuum conditions,  $\vec{\phi} \in \mathcal{M}$ , on the sphere at infinity. The sphere at infinity is  $S^2$ , so this defines a mapping

$$\vec{\phi}_{\infty} \colon S^2 \to \mathcal{M} \,.$$
 (16.13)

If  $\pi^2(\mathcal{M})$  is nontrivial, then  $\vec{\phi}_{\infty}$  can belong to a different homotopy class from the identity, in which case  $\vec{\phi}_{\infty}$  would not be continuously deformable to the identity.

We will now show that if  $\vec{\phi}_{\infty}$  belongs to a nontrivial element of  $\pi^2(\mathcal{M})$ , then  $\vec{\phi}(\vec{x})$  cannot be everywhere in  $\mathcal{M}$ . This means that there must be nonzero energy, because there must be some point in space where the Higgs field is not at its vacuum. This will be a proof by contradiction. Assume that  $\vec{\phi}(\vec{x}) \in \mathcal{M}$  for all x. We could then start at the sphere at infinity, on which we have the field configuration  $\vec{\phi}(\hat{n})$  (where  $\hat{n}$  is a unit vector, indicating the point on the sphere at infinity). We can then consider smaller and smaller spheres, each of which has a field configuration entirely within  $\mathcal{M}$ . As we shrink the sphere down to the single point at the origin, we reach the trivial map, where every point on the sphere is mapped to a single point in  $\mathcal{M}$ . This would define a continuous deformation of  $\vec{\phi}(\hat{n})$  to the identity map, which is impossible by assumption, because we have taken  $\vec{\phi}(\hat{n})$  to be a nontrivial element of  $\pi^2(\mathcal{M})$ . Thus, it is not possible to have  $\vec{\phi}(\vec{x}) \in \mathcal{M}$  for all x.

Consider the case  $\pi^2(\mathcal{M}) = \mathbb{Z}$ , and suppose that  $\vec{\phi}_{\infty}(\hat{n})$  belongs to the homotopy class corresponding to n = 1 (winding number 1). The minimum energy state within this class of configurations is the monopole.

Example 9 ('t Hooft-Polyakov Magnetic Monopole) Consider the gauge group G = SO(3), with the Higgs fields forming a vector under SO(3),

$$\vec{\phi} = (\phi_1, \phi_2, \phi_3). \tag{16.14}$$

Again, we assume that  $V(\|\vec{\phi}\|)$  is minimized at  $\|\vec{\phi}\| = \sigma$ , as illustrated in Figure 13. At each point in space, we can draw the vector  $\vec{\phi}(\vec{x})$ , which gives us a visual representation of the vector field. In the monopole configuration, we have  $\vec{\phi}(\vec{0}) = 0$ . Even though the vector  $\vec{\phi}$  lies in field space, rather than physical space, we can still draw the vector  $\vec{\phi}$  at each point in space using axes  $\phi_1$ ,  $\phi_2$ , and  $\phi_3$  that are chosen to align with the x, y, and z axes of physical space. The picture would then look like Figure 14.

Near the origin, the field magnitude will be small, because the field is continuous, and the vector  $\vec{\phi}$  will point radially outward. As we continue outward from the origin, the field always points radially outward, with increasing magnitude such that as  $\|\vec{x}\| \to \infty$ ,  $\|\vec{\phi}\| \to \sigma$ . Thus, this configuration does approach the vacuum state at spatial infinity. Furthermore, all of the energy is localized near the origin, as the potential decreases to the vacuum as we move toward spatial infinity. This is the magnetic monopole configuration.

### 16.3.2 Cosmic Strings

Suppose that  $\pi^1(\mathcal{M})$  is nontrivial. Consider 3D configurations of  $\vec{\phi}(\vec{x})$  that are independent of z. In this case, we can consider only the (x,y)-plane, because the behavior on every parallel plane will

<span id="page-71-0"></span>![](_page_71_Picture_3.jpeg)

Figure 14: The Higgs field configuration of a magnetic monopole.

be the same. We consider now the configuration  $\vec{\phi}_{\infty}$  on the circle at infinity in the (x, y)-plane. This defines a map  $\vec{\phi}_{\infty} \colon S^1 \to \mathcal{M}$ . We can label the coordinate on this circle by  $\theta$ , so the Higgs field at large distances in the x- or y-directions is given by  $\vec{\phi}_{\infty}(\theta) \in \mathcal{M}$ .

If  $\vec{\phi}_{\infty}(\theta)$  belongs to a nontrivial element of  $\pi^1(\mathcal{M})$ , then  $\vec{\phi}(\vec{x})$  cannot be in  $\mathcal{M}$  everywhere. This follows from the same argument as given in the previous section. If  $\pi^1(\mathcal{M}) = \mathbb{Z}$ , then the minimum energy solution for the n = 1 configuration is the cosmic string.

**Example 10** If we have  $\vec{\phi} = (\phi_1, \phi_2)$ , with the potential  $V(\|\vec{\phi}\|)$  minimized at  $\|\vec{\phi}\| = \sigma$ , then the cosmic string configuration looks like the monopole solution in two dimensions. This configuration has  $\vec{\phi}(\vec{0})$  vanishing;  $\vec{\phi}(x)$  points radially outward from the z-axis with increasing magnitude as we move away from the origin, with  $\|\vec{\phi}\| \to \sigma$  as  $\|\vec{x}\| \to \infty$ .

# 17 Lecture 17 (Apr. 19, 2017)

### 17.1 Exact Homotopy Sequence

Last time we discussed spontaneous symmetry breaking. In this mechanism, we begin with a theory with symmetry group G, and then find that the lowest energy state of this theory breaks the symmetry group down to a subgroup H of G. As examples, we found that a theory contains monopole solutions if and only if  $\pi^2(G/H)$  is nontrivial, and cosmic string solutions if and only if  $\pi^1(G/H)$  is nontrivial.

We now discuss the exact homotopy sequence (also called the long exact sequence of homotopy groups). Given any continuous group G and subgroup H, there exists an infinite sequence of

group-preserving maps (homomorphisms)

$$\cdots \to \pi^{n}(H) \xrightarrow{M_{1}} \pi^{n}(G) \xrightarrow{M_{2}} \pi^{n}(G/H) \xrightarrow{M_{3}} \pi^{n-1}(H) \to \cdots \to \pi^{1}(G/H)$$
$$\to \pi^{0}(H) \to \pi^{0}(G) \to \pi^{0}(G/H) \to 1.$$
(17.1)

The sequence of maps of the form  $M_1$ ,  $M_2$ , and  $M_3$  repeats infinitely far to the left (with different values of n at each repetition), while the sequence terminates on the right. Here, we have included  $\pi^0(M)$ ; this is the set of disconnected components of the manifold M, as it is the set of homotopy classes of maps of a single point into M. Note that the maps involving  $\pi^0$  are not homomorphisms, as  $\pi^0(M)$  is not a group. When we say that the maps  $M_i$  are group-preserving (homomorphisms), we mean that if a and b are in the domain of  $M_i$ , then  $M_i(a)M_i(b) = M_i(ab)$ .

This sequence is *exact*, meaning that the image of each map is exactly equal to the kernel of the following map. The *kernel* (or *null space*) of a map is the set of elements in the domain that are mapped to the identity element.

We will now make a choice of base points for G, H, and G/H. For the groups G and H, we choose the identity element e as the base point. For G/H, we choose the equivalence class of the identity,  $[e]_H = H$ , as the base point. Here we use  $[g]_H$  to denote the equivalence class of g under the equivalence relation where  $g_1 \sim g_2$  if  $g_1 = g_2 h$  for  $h \in H$ . (Recall that we also used square brackets, but without a subscript H, in defining [f] as the class of functions homotopic to f.)

### **17.1.1** Defining $M_1$ , $M_2$ , and $M_3$

We now want to explicitly construct the maps  $M_1$ ,  $M_2$ , and  $M_3$ . The first is exactly what we would expect. An element of  $\pi^n(H)$  is a homotopy class of maps  $f_1 \colon S^n \to H$  with  $f_1(p_0) = e$ , so we begin by choosing a particular representative  $f_1$ . Then we want to construct a map  $f_2 \colon S^n \to G$  with  $f_2(p_0) = e$ , which defines an element of  $\pi^n(G)$ . Because H is a subgroup of G, there is a natural choice of map from H to G, which is the inclusion  $N_1 \colon h \to h$ . That is, h is mapped into itself,  $N_1(h) = h$ , but  $N_1(h)$  is viewed as an element of G. Then, we take

$$f_2 = N_1 \circ f_1 \colon S^n \xrightarrow{f_1} H \xrightarrow{N_1} G.$$
 (17.2)

This defines the map  $M_1: \pi^n(H) \to \pi^n(G)$  as  $M_1(f_1) = f_2$ . To be rigorous, we would then have to ensure that this map is well-defined on the homotopy classes, i.e. that  $M_1([f_1]) = [f_2]$  for any choice of representatives of these homotopy classes. We are not trying to give proofs here, but one can see from the above equation that any continuous deformation of  $f_1$  results in a continuous deformation of  $f_2$ . One must also check the group-preserving property,  $M_1([\tilde{f}_1]) \circ M_1([f_1]) = M_1([\tilde{f}_1]) \circ [f_1]$ , but this is in fact straightforward.

Next, we discuss  $M_2$ . This map is also natural. Given an element of  $\pi^n(G)$ , we can choose a representative  $f_2$  from the homotopy class, where  $f_2 \colon S^n \to G$  with  $f_2(p_0) = e$ . Then we want to construct a map  $f_3 \colon S^n \to G/H$  with  $f_3(p_0) = [e]_H$ , which defines an element of  $\pi^n(G/H)$ . To do so, we use the map  $N_2 \colon G \to G/H$  given by  $N_2 \colon g \mapsto [g]_H$ . Then, we construct

$$f_3 = N_2 \circ f_2 \colon S^n \xrightarrow{f_2} G \xrightarrow{N_2} G/H$$
 (17.3)

This defines the map  $M_2$ :  $\pi^n(G) \to \pi^n(G/H)$  as  $M_2(f_2) = f_3$ . Again, we should ensure that this function is well-defined on homotopy classes, and that it is group-preserving.

Finally, we consider  $M_3$ , which is not as obvious as the other two cases. The construction of  $M_3$  uses a lift. We are given  $f_3 \colon S^n \to G/H$  with  $f_3(p_0) = [e]_H = H$ . To construct the lift, we make use of the standard coordinates  $(z_1, \ldots, z_n)$  inside the unit cube  $C^n$ , which has the entire

boundary identified with the north pole  $p_0$  of  $S^n$ . For each point  $(z_1, \ldots, z_n)$  in the cube, we have a corresponding point  $f_3(z_1, \ldots, z_n) \in G/H$ , and we know that for any point on the boundary,  $f_3 = [e]_H = H$ . For every point inside the cube, we are going to lift this map to a map into G, by continuously choosing a representative g of  $[g]_H$  for each  $f_3(z_1, \ldots, z_n) \in G/H$ . That is, we construct a map  $\tilde{f}(z_1, \ldots, z_n) \in G$ , the *lift*, such that

$$\tilde{f}(z_1, \dots, z_n) \in f_3(z_1, \dots, z_n)$$
 (17.4)

We can state this same condition as

$$[\tilde{f}(z_1, \dots, z_n)]_H = f_3(z_1, \dots, z_n).$$
 (17.5)

We can construct this lift as follows. We start at the origin  $(z_1, \ldots, z_n) = (0, \ldots, 0)$ , which is on the boundary of  $C^n$  (the  $z_i$  run from 0 to 1), which we know must have  $f_3(0, \ldots, 0) = [e]_H$ , and choose  $\tilde{f}(0, \ldots, 0) = e$ . We then construct the entire map  $\tilde{f}$  by considering neighborhoods of points for which we have already defined  $\tilde{f}$ . When constructing the lift, we do not require that the boundary is identified as a single point; allowing ourselves this freedom, we can always successfully construct the lift as above, but we will not try to prove this fact.

Now let us consider what happens on the boundary. We know that  $f_3 = H$  on the boundary, so we know that  $\tilde{f} \in H$  on the boundary. We then define a map  $f_4 \colon S^{n-1} \to H$  such that  $f_4 = \tilde{f}\Big|_{\text{boundary}}$ . (Recall that the boundary of the unit cube  $C^n$  is topologically  $S^{n-1}$ .) This maps  $p_0 = (0, \ldots, 1)$  to  $f_4(p_0) = e$ , and so it is exactly what we wanted. This defines  $M_3 \colon \pi^n(G/H) \to \pi^{n-1}(H)$  as  $M_3(f_3) = f_4$ .

#### 17.1.2 Generalization to Fiber Bundles

We can now discuss the generalization of this story to fiber bundles. We can see that G forms a fiber bundle over the base space G/H with fiber H, and so this same story carries over in general to fiber bundles (and fibrations, even more generally). In the fiber bundle notation, we have a fiber bundle  $(B = G, M = G/H, \pi, F = H)$ , with total space B, base space M, projection map  $\pi \colon B \to M$ , and fiber F. We can construct a long exact sequence of fiber bundles (or fibrations) using exactly the approach above.

#### 17.1.3 Exactness

We now want to show that this sequence is exact, i.e. that the image of each map in the sequence is equal to the kernel of the next map in the sequence. We will first show that  $\operatorname{image}(M_2) = \ker(M_3)$ . Recall that  $M_2 \colon \pi^n(G) \to \pi^n(G/H)$ , where an element of  $\pi^n(G)$  is an equivalence class of maps of the form  $f_2 \colon S^n \to G$  with  $f_2(p_0) = e$ , from which we can choose a representative. An element of  $\pi^n(G/H)$  is an equivalence class of maps of the form  $f_3 \colon S^n \to G/H$  with  $f_3(p_0) = [e]_H = H$ . The map  $M_2$  defines  $f_3$  by

$$f_3(p) = [f_2(p)]_H$$
 (17.6)

Recall also that  $M_3$ :  $\pi^n(G/H) \to \pi^{n-1}(H)$ , where an element of  $\pi^n(G/H)$  is an equivalence class of maps  $f_3$  above and an element of  $\pi^{n-1}(H)$  is an equivalence class of maps of the form  $f_4$ :  $S^{n-1} \to H$  with  $f_4(p_0) = e$ . We constructed  $f_4$  as

$$f_4 = \tilde{f} \Big|_{\text{boundary}},$$
 (17.7)

where  $\tilde{f}$  is the lift of  $f_3$ .

We will first show that  $\operatorname{image}(M_2)$  is a subgroup of  $\ker(M_3)$ . Suppose that  $f_3 \in \operatorname{image}(M_2)$ . We then know that we can write  $f_3(p) = [f_2(p)]_H$  for some  $f_2 \in \pi^n(G)$ . We then lift  $f_3$  to  $\tilde{f}$ ; one possible lift is

$$\tilde{f}(z_1, \dots, z_n) = f_2(z_1, \dots, z_n).$$
 (17.8)

Then  $f_4$  is given by  $\tilde{f}\Big|_{\text{boundary}}$ , but we know that  $f_2(p_0) = e$ , so this gives us  $f_4 = e$ . Thus,  $M_3$  takes  $f_3 \mapsto e$ , showing that  $\text{image}(M_2)$  is a subgroup of  $\text{ker}(M_3)$ . (Note that we only showed this for one particular lift; to be rigorous, we would have to show that any two lifts can be continuously deformed into one another).

Now we will show that  $\ker(M_3)$  is a subgroup of  $\operatorname{image}(M_2)$ . Suppose that  $f_3 \in \ker(M_3)$ . Then there exists a lift

<span id="page-74-0"></span>
$$\underbrace{\tilde{f}(z_1, \dots, z_n)}_{\in G} \in \underbrace{f_3(z_1, \dots, z_n)}_{\in G/H}$$
(17.9)

with the property

$$\tilde{f}(z_1, \dots, z_n)\Big|_{\text{boundary}} = e.$$
(17.10)

Then, Eq. (17.9) can be rewritten as

$$f_3(z_1,\ldots,z_n) = [\tilde{f}(z_1,\ldots,z_n)]_H.$$
 (17.11)

We can then consider

$$f_2(z_1, \dots, z_n) = \tilde{f}(z_1, \dots, z_n).$$
 (17.12)

By construction, we then have  $M_2(f_2) = f_3$ . This shows that  $f_3$  is in the image of  $M_2$ , so  $\ker(M_3)$  is a subgroup of  $\operatorname{image}(M_2)$ .

Thus, we have shown that  $image(M_2) = ker(M_3)$ .

### 17.1.4 Applications

We will now discuss applications of the exact homotopy sequence.

Recall that monopole solutions exist if and only if  $\pi^2(G/H) \neq 1$  (where 1 is the trivial group). A part of the long exact sequence of homotopy groups is

$$\pi^2(G) \to \pi^2(G/H) \to \pi^1(H) \to \pi^1(G)$$
. (17.13)

Suppose that  $\pi^2(G) = \pi^1(G) = 1$ . (This is not always true, but it is true for all grand unified theories. In mathematical terms, it is true for all simple, compact, simply connected Lie groups, and all grand unified theories are, or can be, formulated with the group G in this class. The definitions of these terms are not needed here, but for completeness: a group G is simple if it has no normal subgroups—subgroups H such that  $g^{-1}hg \in H$  for all  $g \in G$ —other than the trivial group and the group itself; a group is compact if every open cover of its parameter space has a finite subcover [examples: rotation groups are compact, while the Lorentz groups is not, since boosts are unbounded]; a group is simply connected if its parameter space has no non-contractible loops [which is synonymous with  $\pi^1(G) = 1$ ] and is path-connected; and a Lie group is a continuous group for which the parameter space is an infinitely differentiable manifold, and for which the multiplication operation is described by an infinitely differentiable function. All the continuous groups that are discussed in physics are Lie groups: SO(n), SU(n), Sp(n), the Lorentz group, the Poincaré group, etc.). Then, we can infer that

$$\pi^2(G/H) = \pi^1(H). \tag{17.14}$$

How do we draw this conclusion? Under this assumption, we have

$$1 \to \pi^2(G/H) \to \pi^1(H) \to 1$$
. (17.15)

Suppose, more generally, that we have

$$1 \xrightarrow{M_2} A \xrightarrow{M_3} B \xrightarrow{M_1} 1. \tag{17.16}$$

Because this sequence is exact, we know that ker(M3) = image(M2); because 1 contains only the identity e, we know that image(M2) = e (note that we are abusing notation here, using the same symbol e to denote the identity in each group). Thus, ker(M3) = e.

This shows that M<sup>3</sup> is one-to-one (injective): if a1, a<sup>2</sup> ∈ A have M3(a1) = M3(a2), then we have

$$e = M_3(a_1)M_3(a_2)^{-1} = M_3(a_1)M_3(a_2^{-1}) = M_3(a_1a_2^{-1}),$$
 (17.17)

where we have used the group-preserving property of the homomorphism M3. Thus, a1a −1 <sup>2</sup> ∈ ker(M3) = e, so a<sup>1</sup> = a2, showing that M<sup>3</sup> is one-to-one.

Next, we have image(M3) = ker(M1). However, we know that ker(M1) = B, because M<sup>1</sup> maps into the trivial group 1. Thus, image(M3) = B, meaning that M<sup>3</sup> is onto. Thus, M<sup>3</sup> is both oneto-one (injective) and onto (surjective), as well as being a homomorphism, so it is an isomorphism between A and B. Thus, A and B are isomorphic, which means that they are essentially the same group, differing by no more than the names used for the group elements.

## 18 Lecture 18 (Apr. 24, 2017)

## 18.1 Spontaneously Broken Gauge Theories

We have previously defined M = G/H to be the manifold of degenerate vacua, where G is the symmetry group of V (φ~), and H is the unbroken subgroup of G. We saw that monopoles exist if and only if π 2 (G/H) 6= 1 (where 1 is the trivial group), and cosmic strings exist if and only if π 1 (G/H) 6= 1. Finally, we learned how to construct the (long) exact homotopy sequence

$$\cdots \to \pi^{n}(H) \xrightarrow{M_{1}} \pi^{n}(G) \xrightarrow{M_{2}} \pi^{n}(G/H) \xrightarrow{M_{3}} \pi^{n-1}(H) \to \cdots \to \pi^{1}(G/H)$$
$$\to \pi^{0}(H) \to \pi^{0}(G) \to \pi^{0}(G/H) \to 1.$$
(18.1)

This sequence is exact, meaning that the image of each map is equal to the kernel of the next map. We showed that monopoles exist if and only if π 2 (G/H) 6= 1. From the exact homotopy sequence, we know that

$$\pi^2(G) \to \pi^2(G/H) \to \pi^1(H) \to \pi^1(G)$$
 (18.2)

is exact. Suppose that π 2 (G) = π 1 (G) = 1, which is true for any simple, compact, simply connected Lie group. (A manifold is simply connected if it is path-connected and contains no non-contractible loops. A Lie group is a group that is also a differentiable manifold, such that the group operations and the complex structure are compatible.) Then, we have

$$1 \to \pi^2(G/H) \to \pi^1(H) \to 1$$
. (18.3)

The first map is clearly one-to-one, and the last map is clearly onto; with the fact that the sequence is exact, these imply that the middle map is an isomorphism, so π 2 (G/H) ∼= π 1 (H), i.e. these are the same group for all intents and purposes.

Similarly, we saw that cosmic strings exist if and only if π 1 (G/H) 6= 1. The exact homotopy sequence tells us that

$$\pi^1(G) \to \pi^1(G/H) \to \pi^0(H) \to \pi^0(G)$$
. (18.4)

We suppose that π 1 (G) = π 0 (G) = 1. This relates π 1 (G/H) and π 0 (H); note that π 0 (H) is not a group, and so we can not say that these are isomorphic; however, π 0 (H) will tell us the number of elements of π 1 (G/H).

## 18.2 Standard Model of Particle Physics

The Standard Model of Particle Physics is based on the gauge group

$$G = SU(3) \times SU(2) \times U(1). \tag{18.5}$$

Here, the SU(3) is the gauge group of quantum chromodynamics, and SU(2)×U(1) is the electroweak gauge group, which is broken down to U(1)EM (note that this is not the same U(1) as in the electroweak gauge group, but rather a linear combination of this U(1) and one of the generators of SU(2)).

The Higgs fields is an SU(2) doublet

$$\vec{\phi} = \begin{pmatrix} \phi_1 \\ \phi_2 \end{pmatrix}, \tag{18.6}$$

where the φ<sup>i</sup> are complex. The manifold of degenerate vacua is

$$\mathcal{M} = \left\{ \vec{\phi} : |\phi_1|^2 + |\phi_2|^2 = v^2 \right\} \cong S^3,$$
 (18.7)

where ∼= in this case represents topological equivalence (homeomorphism). Thus,

$$\pi^2(\mathcal{M}) \cong \pi^2(S^3) = 1, \qquad (18.8)$$

where now ∼= indicates group theoretic equivalence (group isomorphism). Similarly,

$$\pi^1(\mathcal{M}) \cong \pi^1(S^3) = 1.$$
 (18.9)

Thus, there are no monopoles and no cosmic strings in the Standard Model.

### 18.2.1 Grand Unified Theories

Now we will imagine embedding that Standard Model into a grand unified theory. Note that neither of these theories have gravity (we can ignore gravity here because it is incredibly weak by comparison with the other forces we observe). In this case, the unbroken symmetry will still be H = U(1)EM, as in the Standard Model. The difference is the starting group G, which is different for different grand unified theories; various choices include SU(5), SO(10), and E<sup>6</sup> (there are more). These groups all contain SU(3) × SU(2) × U(1). For example, consider an element g ∈ SU(5); this is a 5 × 5 unitary matrix with determinant 1. We can then consider elements of the form

$$g = \begin{pmatrix} e^{i\frac{\pi}{3}\phi}g_{3\times 3} & 0\\ 0 & e^{-i\frac{\pi}{2}\phi}g_{2\times 2} \end{pmatrix},$$
 (18.10)

where g3×<sup>3</sup> and g2×<sup>2</sup> are SU(3) and SU(2) matrices, respectively. This form for g clearly decomposes into a 3 × 3 unitary matrix with determinant 1, a 2 × 2 unitary matrix with determinant 1, and a phase factor. Embedding the Standard Model in SO(10) is only a slight extension of this: SO(10) acts on a 10-dimensional real vector space, preserving the sum of the squares of the components; SU(5) acts on a 5-dimensional complex vector space, preserving the sum of the squared absolute magnitudes of the components. If one treats each complex number in the vector space on which SU(5) acts as two real numbers, the SU(5) transformations become a subgroup of SO(10).

We now consider G = SU(5). What are π 2 (SU(5)), π 1 (SU(5)), and π 0 (SU(5))? Topologically, we have SU(2) ∼= S 3 , and

$$SU(n)/SU(n-1) \cong S^k \tag{18.11}$$

for some k as a function of n. The exact homotopy sequence then tells us that

$$\pi^3\left(S^k\right) \to \pi^2(\mathrm{SU}(n-1)) \to \pi^2(SU(n)) \to \pi^2\left(S^k\right).$$
 (18.12)

For k > 3, the first group is 1, and for k > 2, the final group is 1. The exactness of the sequence then implies

$$\pi^2(SU(n-1)) \cong \pi^2(SU(n)).$$
 (18.13)

Thus, because π 2 S 3 = 1, by induction we see that π 2 (SU(n)) = 1. Similarly, π 1 (SU(n)) = 1 and π 0 (SU(N)) = 1.

We can then ask if there are magnetic monopoles in this grand unified theory. We have

$$\pi^2(G) = \pi^1(G) = 1, \tag{18.14}$$

meaning that we can use π 2 (G/H) ∼= π 1 (H). We have

$$\pi^{1}(H) = \pi^{1}(U(1)_{EM}) = \mathbb{Z},$$
(18.15)

which then implies the existence of magnetic monopoles.

What about cosmic strings? Since π 1 (SU(5)) = π 0 (SU(5)) = 1, strings exist if and only if π 0 (H) 6= 1. However, π 0 (U(1)EM) = 1, meaning that there are no cosmic strings in this grand unified theory.

Let us now consider G = SO(10). This story is a little bit more complicated because SO(10) is not simply connected, meaning that it has non-contractible loops. In fact, π 1 (SO(10)) = Z<sup>2</sup> = π 1 (SO(3)). We know that

$$SO(3) \cong SU(2)/\mathbb{Z}_2. \tag{18.16}$$

Similarly, there exists a simply connected group called Spin(10), also known as the covering group of SO(10), for which

$$SO(10) \cong Spin(10)/\mathbb{Z}_2. \tag{18.17}$$

Generally,

$$SO(n) \cong Spin(n)/\mathbb{Z}_2$$
. (18.18)

Note that Spin(3) ∼= SU(2).

We can then take G = Spin(10) in order to use our previous formalism, with unbroken symmetry group H = U(1)EM × Z2. It then follows that

$$\pi^2(G) = \pi^1(G) = \pi^0(G) = 1,$$
(18.19)

meaning that monopoles exist if and only if π 1 (H) 6= 1, and cosmic strings exist if and only if π 0 (H) 6= 1. We see that

$$\pi^{1}(\mathrm{U}(1)_{\mathrm{EM}} \times \mathbb{Z}_{2}) = \mathbb{Z}, \qquad (18.20)$$

so we do have monopoles, with integer quantized charge. We also have

$$\pi^0(U(1)_{EM} \times \mathbb{Z}_2) = \mathbb{Z}_2,$$
 (18.21)

implying the existence of Z<sup>2</sup> cosmic strings. This means that having one string is distinct from having none, but any two strings can combine to vanish, leaving no strings.

## 18.3 Instantons

In quantum field theory, one is interested in path integrals. A path integral is a functional integral over all fields,

$$\mathcal{Z} = \int \prod_{i} \mathcal{D}\phi_i \ e^{iS[\phi_i(x)]} = \int \prod_{i} \prod_{x} d\phi_i(x) \ e^{iS[\phi_i(x)]}, \qquad (18.22)$$

where S[φi(x)] is the action. In the second expression, we have discretized spacetime, and we are doing regular integrals over the value of each field at each point in the discretized spacetime. What we are actually interested in is correlation functions, which are expectation values of time ordered products of fields:

$$\langle T\{\phi_1(x_1)\cdots\phi_n(x_n)\}\rangle = \frac{\int \prod_i \mathcal{D}\phi_i \ e^{iS[\phi_i(x)]}\phi_1(x_1)\cdots\phi_n(x_n)}{\int \prod_i \mathcal{D}\phi_i \ e^{iS[\phi_i(x)]}}.$$
 (18.23)

We can now perform a Wick rotation: we analytically continue in t to imaginary values t = iτ . The action then becomes

$$S[\phi_i(x)] = \int d^3 \vec{x} dt \, \mathcal{L}[\phi_i(x)] = i \int d^3 \vec{x} d\tau \, \mathcal{L}[\phi_i(x)].$$
 (18.24)

The path integral becomes

$$\mathcal{Z} = \int \prod_{i} \mathcal{D}\phi_{i} \ e^{-\int d^{4}\vec{x} \mathcal{L}[\phi_{i}(x)]} \ . \tag{18.25}$$

The integral in the exponent is now positive-definite, after doing the Wick rotation. This means that the exponential will be zero everywhere except for where the Lagrangian approaches zero at large distances. That is, in order for Z to be finite, we require L −−−−→ |x|→∞ 0. For a non-gauge theory,

this would require all of the fields to go to zero at infinity. However, in a gauge theory, there are many nonzero configurations of the gauge fields that still leave the Lagrangian density vanishing, because the Lagrangian density is gauge invariant. For a gauge theory, all that is required is that the field configuration be a gauge transformation of the zero-field configuration.

After the Wick rotation, our spacetime is R 4 , which has as its boundary S 3 . Thus, a choice of gauge transformation on the boundary is a choice g(x) ∈ G for every point on S 3 , the sphere at infinity. At |x| = ∞, the configuration is thus an element of π 3 (G). For SU(3), the gauge group of quantum chromodynamics (QCD), π 3 (G) = Z. This means that there are topologically nontrivial gauge configurations. The instanton is the lowest-action configuration that corresponds to the n = 1 element of π 3 (G).

What makes this relevant is that when one does path integrals in this Euclidean form, one can make use of saddle point approximations, where we expand the fields around configurations that give stationary points of the action; these instantons are stationary points of the action.

# 19 Lecture 19 (Apr. 26, 2017)

## 19.1 The Einstein Equations

In Lecture 5, we discussed the Newtonian limit of the geodesic equation, in which

$$\frac{\mathrm{d}^2 x_i}{\mathrm{d}t^2} = -\partial_i \Phi \,, \tag{19.1}$$

where

$$g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu} \tag{19.2}$$

and

$$\Phi = -\frac{1}{2}h_{00} \,. \tag{19.3}$$

In the Newtonian limit, we can write down the Poisson equation

$$\nabla^2 \Phi = 4\pi G \rho \,, \tag{19.4}$$

where ρ is the energy density, or equivalently the mass density, since we use units with c = 1.

Our motivation for the Einstein equations is to match these equations in the Newtonian limit. We note that ρ is not a Lorentz scalar. In fact, it is a part of the energy–momentum tensor (also called the stress–energy tensor ). Consider a dust of free particles, and let n be the number density of this dust in its rest frame (this is a Lorentz invariant quantity). The fluid of particles is also characterized by a four-velocity U <sup>µ</sup> = dx µ dτ . In the rest frame, the mass density is given by ρ = mn, where m is the rest mass of one particle.

We define the flux as

$$N^{\mu} = nU^{\mu} \,. \tag{19.5}$$

The temporal component component of this is simply the number density (in any frame),

$$N^0 = n\gamma. (19.6)$$

The spatial components N<sup>i</sup> form the flux vector, which is the number of particles per unit time crossing a unit cross-sectional area. This is given by

$$N^i = n\gamma v^i \,, \tag{19.7}$$

where

$$v^i = \frac{\mathrm{d}x^i}{\mathrm{d}t} \tag{19.8}$$

is the ordinary three-velocity.

We can also consider the momentum of a single particle, p <sup>µ</sup> = mU<sup>µ</sup> . From these ingredients we can now build up the energy–momentum tensor

$$T_{\text{dust}}^{\mu\nu} = p^{\mu}N^{\nu} = mnU^{\mu}U^{\nu}$$
. (19.9)

Note that the energy–momentum tensor is symmetric; this will always be the case (in other contexts, you may see the canonical energy–momentum tensor, which may not be symmetric, but can be altered to make it symmetric).

How do we interpret the energy–momentum tensor? The T <sup>00</sup> component is the energy density of the dust. The component T <sup>0</sup><sup>i</sup> = p <sup>0</sup>N<sup>i</sup> can be thought of as the flux of energy in the i direction; this is also equal to the density of the momentum p i , T <sup>0</sup><sup>i</sup> = N0p i . The component T ij is the flux of p i in the j-direction. The diagonal entry T ii can also be interpreted as the pressure in the i-direction.

We now want to consider a perfect fluid, which is characterized by its velocity U µ , energy density ρ, and pressure p. In the rest frame, we know that

$$U^{\mu} = (1, 0, 0, 0). \tag{19.10}$$

By definition, we know that T <sup>00</sup> = ρ. In the rest frame, there is no energy flux and no shear stress (off-diagonal T ij entries), so we just have the pressure on the diagonal. The energy–momentum tensor is then

$$T_{\text{fluid, rest}}^{\mu\nu} = \begin{pmatrix} \rho & 0 & 0 & 0\\ 0 & p & 0 & 0\\ 0 & 0 & p & 0\\ 0 & 0 & 0 & p \end{pmatrix}. \tag{19.11}$$

To find this in all frames, we simply need to write it in a covariant form; we can write

$$T_{\text{fluid}}^{\mu\nu} = (\rho + p)U^{\mu}U^{\nu} + p\eta^{\mu\nu}$$
. (19.12)

Note that here we are considering flat space. This expression holds in any frame.

The energy–momentum tensor is conserved, by which we mean that

$$\partial_{\mu}T^{\mu\nu} = 0. \tag{19.13}$$

Because there is one free index, this is actually four equations. The ν = 0 equation gives conservation of energy, and the ν = i equations give conservation of p i . For the perfect fluid, these equations are

$$\partial_{\mu} T^{\mu\nu}_{\text{fluid}} = [\partial_{\mu} (\rho + p)] U^{\mu} U^{\nu} + (\rho + p) (U^{\mu} \partial_{\mu} U^{\nu} + u^{\nu} \partial_{\mu} U^{\mu}) + \partial^{\nu} p = 0.$$
 (19.14)

We can break this up into two pieces—one that is parallel to U ν , and one that is orthogonal to U ν . The parallel part is

$$U_{\nu}\partial_{\mu}T^{\mu\nu} = 0, \qquad (19.15)$$

which (after some algebra) gives us

$$\partial_{\mu}(\rho U^{\mu}) = -p\partial_{\mu}U^{\mu}. \tag{19.16}$$

This says that the divergence of energy flux is equal to minus the pressure times the divergence of the velocity, which makes physical sense. The orthogonal part is found by projecting out the component of the equation in the direction of U ν , using the projection operator

$$P^{\sigma}_{\ \nu} = \delta^{\sigma}_{\ \nu} + U^{\sigma}U_{\nu} \,, \tag{19.17}$$

which satisfies P σ <sup>ν</sup> U <sup>ν</sup> = 0. We can then consider

$$P^{\sigma}_{\ \nu}\,\partial_{\mu}T^{\mu\nu} = 0\,, (19.18)$$

which ultimately gives us

$$(\rho + p)U^{\mu}\partial_{\mu}U^{\sigma} = -\partial^{\sigma}p - U^{\sigma}U^{\mu}\partial_{\mu}p. \qquad (19.19)$$

The left-hand side of this equation can be interpreted roughly as the mass density times the acceleration, with the pressure serving as a relativistic correction to the mass density. The right-hand side is essentially the spatial pressure gradient. The role of the second term on the right-hand side is to project the gradient into the space orthogonal to U µ , which in the rest frame just cancels out the time derivative, leaving only spatial derivatives.

There are a number of Lorentz-invariant states that have nontrivial energy–momentum tensors. One is the vacuum state. Another is the state of a uniform scalar field; depending on the value of this field, it could have a nonzero potential energy density. We usually think of the vacuum as having no energy, but that doesn't actually appear to be the case for our vacuum. At a classical level we would expect the vacuum to have no energy density, but in a quantum field theory, the vacuum is a very complicated state, so there is no reason to expect its energy density to be zero. The energy density of the vacuum is synonymous with what Einstein called the cosmological constant. Since 1998, we have known that the expansion of the universe is accelerating, and the simplest explanation is that the vacuum has a small, but positive, energy density.

Lorentz-invariant states must have Lorentz-invariant energy–momentum tensors. The energy– momentum tensor for the perfect fluid is

$$T_{\text{fluid}}^{\mu\nu} = (\rho + p)U^{\mu}U^{\nu} + p\eta^{\mu\nu}$$
. (19.20)

Under what circumstances can this be Lorentz-invariant? (It is always Lorentz-covariant). The second term is always Lorentz-invariant, because η µν is Lorentz-invariant. The first term is only Lorentz-invariant if it vanishes, which requires p = −ρ. This is crucial to the behavior of the cosmological constant and to early universe inflationary models. Negative pressures produce gravitational repulsion; this means we could have a positive cosmological constant (corresponding to a positive energy density) with a negative pressure, which causes an accelerating universe (like the one we live in).

We will now review the energy–momentum tensor in the context of E&M, as another example. In its relativistic formulation, E&M is formulated in terms of a four-vector Aµ(x), which is related to the electromagnetic field strength tensor

$$F_{\mu\nu}(x) = \partial_{\mu}A_{\nu} - \partial_{\nu}A_{\mu}. \tag{19.21}$$

This theory has a gauge symmetry under transformations of the form

$$A_{\mu} \to A'_{\mu}(x) = A_{\mu}(x) + \partial_{\mu}\Lambda(x). \qquad (19.22)$$

The field strength Fµν is gauge-invariant. The Lagrangian density is

$$\mathcal{L} = -\frac{1}{4} F_{\mu\nu} F^{\mu\nu} + A_{\mu} J^{\mu} \,, \tag{19.23}$$

where here we are treating J<sup>µ</sup> as a fixed external source for the electromagnetic field, but in a more complete theory J<sup>µ</sup> would be expressed in terms of other fields. The equations of motion, which follow from extremizing the action, are given by Euler–Lagrange equations

$$\frac{\partial \mathcal{L}}{\partial A_{\nu}} - \partial_{\mu} \left( \frac{\partial \mathcal{L}}{\partial (\partial_{\mu} A_{\nu})} \right) = 0.$$
 (19.24)

Applying this equation gives

$$\partial_{\nu}F^{\mu\nu} = J^{\mu} \,. \tag{19.25}$$

These are the inhomogeneous Maxwell's equations. The homogeneous Maxwell's equations follow simply from the definition of  $F^{\mu\nu}$  in terms of  $A_{\mu}$ . The energy–momentum tensor is given by

$$T_{\rm EM}^{\mu\nu} = F^{\mu\lambda}F^{\nu}_{\ \lambda} - \frac{1}{4}\eta^{\mu\nu}F^{\lambda\sigma}F_{\lambda\sigma}. \tag{19.26}$$

The divergence of the energy-momentum tensor is then

$$\partial_{\mu} T_{\rm EM}^{\mu\nu} = F^{\nu}_{\lambda} J^{\lambda} \,, \tag{19.27}$$

where the expression on the right describes the transfer of energy and momentum between  $F_{\mu\nu}$  and the source  $J^{\mu}$ .

Now that we've seen several examples of energy—momentum tensors, we want to figure out how to use it in a sensible equation that will reproduce the Poisson equation,

$$\nabla^2 \Phi = 4\pi G \rho \,, \tag{19.28}$$

in the nonrelativistic limit. Because  $\rho$  is a component of  $T^{\mu\nu}$ , we expect the right-hand side of our equation to be of the form const.  $T^{\mu\nu}$ . The left-hand side should apparently contain second derivatives of the metric, since  $\Phi = -\frac{1}{2}h_{00}$ . We know that the Riemann tensor  $R^{\rho}_{\sigma\mu\nu}$  is composed of second derivatives of the metric, but this has too many indices. We can reduce the number of indices by considering the Ricci tensor,  $R_{\mu\nu} = R^{\lambda}_{\ \mu\lambda\nu}$ , so this has a chance of being the left-hand side of the equation. However, we know that

$$\nabla_{\mu}T^{\mu\nu} = 0, \qquad (19.29)$$

where  $\nabla_{\mu}$  is a covariant derivative; the energy–momentum tensor is covariantly conserved. If this is true for the right-hand side of the equation, it must also be true of the left-hand side. However,  $\nabla_{\mu}R^{\mu\nu} \neq 0$  in general. We previously saw that the Bianchi identity gave us

$$\nabla_{\mu} \left( R^{\mu\nu} - \frac{1}{2} R g^{\mu\nu} \right) = 0. \tag{19.30}$$

The quantity in parentheses, called the Einstein tensor, is thus a good candidate for the left-hand side of the equation. We thus guess

$$R^{\mu\nu} - \frac{1}{2} R g^{\mu\nu} = \text{const.} \cdot T^{\mu\nu} \,.$$
 (19.31)

We can uniquely determine the constant by taking the weak-field limit and ensuring that we recover the Poisson equation; this gives us

$$R^{\mu\nu} - \frac{1}{2}Rg^{\mu\nu} = 8\pi G T^{\mu\nu}$$
 (19.32)

This is the famous Einstein equation. It describes how gravitational fields are affected by matter.

### 19.2 The Schwarzschild Metric

Recall that the Schwarzschild metric has the form

$$ds^{2} = -\left(1 - \frac{R_{s}}{r}\right)dt^{2} + \left(1 - \frac{R_{s}}{r}\right)^{-1}dr^{2} + r^{2}d\Omega^{2},$$
(19.33)

where R<sup>s</sup> = 2GM and

$$d\Omega^2 = d\theta^2 + \sin^2\theta \, d\phi^2 \,. \tag{19.34}$$

On Problem Set 6, we verified that this satisfies

$$R_{\mu\nu} = 0. (19.35)$$

Thus, the Einstein equations for the Schwarzschild metric are

$$T^{\mu\nu} = 0. (19.36)$$

This solution describes the behavior outside of the mass that generates the Schwarzschild metric; this is the unique spherically symmetric solution to the vacuum Einstein equations.

There is an apparent singularity at r = R<sup>s</sup> = 2GM; however, this is a coordinate singularity, meaning that it is not actually a singularity, but rather an artifact of the coordinate system we are using. Note that there is also a singularity at r = 0; this is a real singularity.

We now want to change to a coordinate system that does not have this coordinate singularity. To do so, we consider radial light rays. For such rays, ds <sup>2</sup> = 0 (light rays) and dΩ<sup>2</sup> = 0 (radial), so we have

$$0 = -\left(1 - \frac{R_{\rm s}}{r}\right) dt^2 + \left(1 - \frac{R_{\rm s}}{r}\right)^{-1} dr^2.$$
 (19.37)

We can rewrite this as

$$\left(\frac{\mathrm{d}t}{\mathrm{d}r}\right)^2 = \left(\frac{r}{r - R_\mathrm{s}}\right)^2. \tag{19.38}$$

We define a new coordinate

$$r_* = r + R_{\rm s} \ln \left( \frac{r}{R_{\rm s}} - 1 \right).$$
 (19.39)

For large values of r, the first term dominates, so r<sup>∗</sup> <sup>r</sup>→∞ −−−→ <sup>r</sup>. For <sup>r</sup> <sup>∼</sup> <sup>R</sup>s, the second term is a large negative number, so r<sup>∗</sup> <sup>r</sup>→R<sup>s</sup> −−−→ −∞. This makes the horizon at <sup>r</sup> <sup>=</sup> <sup>R</sup><sup>s</sup> look infinitely far away. This coordinate has a nice relationship with time, because

$$dr_* = dr \left[ 1 + \left( \frac{1}{\frac{r}{R_s} - 1} \right) \right] = dr \left( \frac{r}{r - R_s} \right). \tag{19.40}$$

Thus

$$\frac{\mathrm{d}t}{\mathrm{d}r_*} = 1. \tag{19.41}$$

We can then think of r<sup>∗</sup> as measuring distance in light seconds of Schwarzschild coordinate time. Changing to this coordinate simplifies the metric to

$$ds^{2} = -\left(1 - \frac{R_{s}}{r}\right) \left(dt^{2} - dr_{*}^{2}\right) + r^{2} d\Omega^{2}.$$
 (19.42)

Next time, we will continue manipulating this metric to reach the Kruskal coordinate system.

# 20 Lecture 20 (May 1, 2017)

Recall that the Schwarzschild metric is the most general spherically symmetric solution to the Einstein field equations in the absence of matter. The metric is

$$ds^{2} = -\left(1 - \frac{R_{s}}{r}\right)dt^{2} + \left(1 - \frac{R_{s}}{r}\right)^{-1}dr^{2} + r^{2}d\Omega^{2}, \qquad (20.1)$$

where R<sup>s</sup> ≡ 2GM and

$$d\Omega^2 = d\theta^2 + \sin^2\theta \, d\phi^2 \,. \tag{20.2}$$

As a brief reminder that may be useful for Problem Set 11, recall that the geodesic equation can be written in the form

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\sigma\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{1}{2} \frac{\partial g_{\mu\nu}}{\partial x^{\sigma}} \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \,. \tag{20.3}$$

This was originally discussed in Lecture 3.

A nice property of this form is that, if the right-hand side vanishes, then we immediately know that the quantity in brackets on the left-hand side is a conserved quantity. For example, if the metric is independent of t, then there is a conserved quantity

$$E = -g_{00} \frac{\mathrm{d}x^0}{\mathrm{d}\tau} = \left(1 - \frac{R_{\mathrm{s}}}{r}\right) \frac{\mathrm{d}t}{\mathrm{d}\tau}.$$
 (20.4)

This is the energy per unit mass of the particle travelling along the geodesic. Similarly, if the metric is independent of φ, then there is a conserved quantity

$$L_{\phi} = g_{\phi\phi} \frac{\mathrm{d}\phi}{\mathrm{d}\tau} = r^2 \sin^2 \theta \frac{\mathrm{d}\phi}{\mathrm{d}\tau} \,. \tag{20.5}$$

This is the angular momentum per unit mass of the particle travelling along the geodesic. These conservation equations can be found in Lecture 6.

The easiest way to make use of these properties is by considering the line element

$$d\tau^2 = -ds^2 = \left(1 - \frac{R_s}{r}\right)dt^2 - \left(1 - \frac{R_s}{r}\right)^{-1}dr^2 - r^2d\Omega^2.$$
 (20.6)

To include the possibility of a lightlike trajectory, for which dτ = 0, we introduce an affine parameter λ, such that λ = τ for the timelike case where m 6= 0. For equatorial orbits, we have θ = π 2 and ˙θ = 0, and we can rewrite the metric (dividing by dλ 2 ) as

$$\left(\frac{\mathrm{d}\tau}{\mathrm{d}\lambda}\right)^2 = \left(1 - \frac{R_\mathrm{s}}{r}\right) \left(\frac{\mathrm{d}t}{\mathrm{d}\lambda}\right)^2 - \left(1 - \frac{R_\mathrm{s}}{r}\right)^{-1} \left(\frac{\mathrm{d}r}{\mathrm{d}\lambda}\right)^2 - r^2 \left(\frac{\mathrm{d}\phi}{\mathrm{d}\lambda}\right)^2. \tag{20.7}$$

We define

<span id="page-84-0"></span>
$$a \equiv \left(\frac{\mathrm{d}\tau}{\mathrm{d}\lambda}\right)^2 = \begin{cases} 1 & \text{if } m \neq 0\\ 0 & \text{if } m = 0 \end{cases}.$$
 (20.8)

We can rewrite Eq. [\(20.7\)](#page-84-0) as

$$\frac{1}{2} \left( \frac{\mathrm{d}r}{\mathrm{d}\lambda} \right)^2 + V(r) = \mathcal{E} = \frac{1}{2} E^2 \,, \tag{20.9}$$

where

$$V(r) = \frac{1}{2} \left( 1 - \frac{R_s}{r} \right) \left( a + \frac{L_\phi^2}{r^2} \right). \tag{20.10}$$

This was discussed in Lecture 7.

## 20.1 Kruskal Coordinates

We now return to the construction of Kruskal coordinates. This coordinate system removes the coordinate singularity at r = R<sup>s</sup> that we see in Schwarzschild coordinates. Note that there is also a singularity at r = 0; this is a real singularity, and cannot be removed by any change of coordinates.

We begin by considering lightlike, radial trajectories. For such trajectories, we have

$$0 = d\tau^2 = \left(1 - \frac{R_s}{r}\right) dt^2 - \left(1 - \frac{R_s}{r}\right)^{-1} dr^2.$$
 (20.11)

We omit the angular pieces because we are considering only radial trajectories. We can rearrange this to reach

$$\frac{\mathrm{d}t}{\mathrm{d}r} = \pm \frac{r}{r - R_{\mathrm{s}}}.$$
(20.12)

We now define a new radial variable r∗, such that

$$\frac{\mathrm{d}t}{\mathrm{d}r_*} = 1. \tag{20.13}$$

We can see that this requires

$$\frac{\mathrm{d}r_*}{\mathrm{d}r} = \frac{r}{r - R_\mathrm{s}} \,,\tag{20.14}$$

which we solve to reach

$$r_* = r + R_{\rm s} \ln \left( \frac{r}{R_{\rm s}} - 1 \right).$$
 (20.15)

The relation between r and r<sup>∗</sup> has no analytic inverse.

We can rewrite the metric in terms of this new variable as

$$ds^{2} = -\left(1 - \frac{R_{s}}{r}\right) \left(dt^{2} - dr_{*}^{2}\right) + r^{2} d\Omega^{2}.$$
 (20.16)

This is much simpler than what we had before. We now introduce lightcone coordinates,

$$u \equiv t - r_*, \quad v \equiv t + r_*. \tag{20.17}$$

These satisfy

$$uv = t^2 - r_*^2$$
,  $du dv = dt^2 - dr_*^2$ . (20.18)

With these coordinates, the metric can be written as

$$ds^{2} = -\left(1 - \frac{R_{s}}{r}\right) du dv + r^{2} d\Omega^{2}.$$
 (20.19)

We want to get rid of the singular factor 1 − Rs r . To do so, we will rewrite it in terms of u and v. We see that

$$\frac{1}{2}(v-u) = r_* = r + R_s \ln\left(\frac{r}{R_s} - 1\right). \tag{20.20}$$

Dividing by Rs, we find

$$\frac{v-u}{2R_{\rm s}} = \frac{r}{R_{\rm s}} + \ln\left(\frac{r}{R_{\rm s}} - 1\right),\tag{20.21}$$

which we can further exponentiate to reach

$$e^{(v-u)/2R_s} = e^{r/R_s} \left(\frac{r}{R_s} - 1\right).$$
 (20.22)

We can rewrite

$$\left(\frac{r}{R_{\rm s}} - 1\right) = \frac{r}{R_{\rm s}} \left(1 - \frac{R_{\rm s}}{r}\right),\tag{20.23}$$

and then solve for 1 − Rs r to reach

$$1 - \frac{R_{\rm s}}{r} = \frac{R_{\rm s}}{r} e^{-r/R_{\rm s} + (v-u)/2R_{\rm s}}.$$
 (20.24)

The metric then becomes

$$ds^{2} = -\frac{R_{s}}{r}e^{-r/R_{s}}e^{v/2R_{s}} dv e^{-u/2R_{s}} du + r^{2} d\Omega^{2}.$$
 (20.25)

We then define

$$V \equiv e^{v/2R_{\rm s}}, \quad U \equiv -e^{-u/2R_{\rm s}},$$
 (20.26)

which give

$$dV = \frac{e^{v/2R_s} dv}{2R_s}, \quad dU = \frac{e^{-u/2R_s} du}{2R_s}.$$
 (20.27)

The metric can then be rewritten as

$$ds^{2} = -\frac{4R_{s}^{3}}{r}e^{-r/R_{s}} dU dV + r^{2} d\Omega^{2}.$$
 (20.28)

We have now achieved our goal; this metric is singular only at r = 0. This is one way of writing the Kruskal metric, though it is not the standard form.

In the standard form of the Kruskal metric, we define new time and radial coordinates

$$T \equiv \frac{1}{2}(V+U), \quad R \equiv \frac{1}{2}(V-U).$$
 (20.29)

These satisfy

$$V = T + R$$
,  $U = T - R$ ,  $UV = T^2 - R^2$ ,  $dU dV = dT^2 - dR^2$ . (20.30)

We can then write the metric as

$$ds^{2} = \frac{4R_{s}^{3}}{r}e^{-r/R_{s}}\left(-dT^{2} + dR^{2}\right) + r^{2}d\Omega^{2}$$
 (20.31)

Here, r is no longer our radial coordinate, so we think of it as a function r = r(T, R), given by the relation

$$\left(1 - \frac{r}{R_{\rm s}}\right)e^{r/R_{\rm s}} = T^2 - R^2,$$
(20.32)

which follows from the earlier relation

$$e^{(v-u)/2R_s} = e^{r/R_s} \left(\frac{r}{R_s} - 1\right).$$
 (20.33)

This is the standard form of the Kruskal metric.

We can write the Kruskal coordinates, in the region  $r > R_s$ , in terms of the original Schwarzschild coordinates as

$$T = \frac{1}{2}(V+U) = \left(\frac{r}{R_{\rm s}} - 1\right)^{1/2} e^{r/2R_{\rm s}} \sinh\left(\frac{t}{2R_{\rm s}}\right),$$

$$R = \frac{1}{2}(V-U) = \left(\frac{r}{R_{\rm s}} - 1\right)^{1/2} e^{r/2R_{\rm s}} \cosh\left(\frac{t}{2R_{\rm s}}\right).$$
(20.34)

These have the relationship

$$\frac{T}{R} = \tanh\left(\frac{t}{2R_{\rm s}}\right). \tag{20.35}$$

Note that our derivation of these coordinates only makes sense in the region  $r > R_s$ , because

$$r_* = r + R_{\rm s} \ln \left( \frac{r}{R_{\rm s}} - 1 \right) \tag{20.36}$$

is complex for  $r < R_s$ . However, now that we have constructed the metric in terms of T, R,  $\theta$ , and  $\phi$ , we know that this metric satisfies the vacuum Einstein equations  $R_{\mu\nu} = 0$  at least in the region that corresponds to the external region  $r > R_s$ . But the metric is an analytic function of these coordinates, provided only that r > 0, so  $R_{\mu\nu} = 0$  will hold everywhere that r > 0. The spacetime described by this metric for this enlarged region is sometimes called the *Kruskal extension* of the Schwarzschild coordinates.

### 20.2 Kruskal Diagram

<span id="page-87-0"></span>We now consider the (R, T)-plane.

![](_page_87_Figure_13.jpeg)

Figure 15: Diagram of the Kruskal coordinate space and its relation to the Schwarzschild coordinates t and r.

Outside of the horizon,  $r > R_s$ , we know that R > 0, and furthermore R > |T|, because  $\cosh\left(\frac{t}{2R_s}\right) > \left|\sinh\left(\frac{t}{2R_s}\right)\right|$ . Thus, the exterior region  $r > R_s$  is mapped to a quadrant of the

(R, T)-plane, along the positive R-axis between the lines T = R and T = −R, shown as region I in Figure [15.](#page-87-0)

Continuing these lines through the origin, the whole diagram is subdivided into four quadrants. The top quadrant, along the positive T-axis, is the interior of the black hole. The line T = R dividing this from the exterior region is the horizon r = Rs.

This metric is singular at r = 0, and has

$$R_{\mu\nu\lambda\sigma}R^{\mu\nu\lambda\sigma} = \frac{48G^2M^2}{r^6}. (20.37)$$

Since this quantity is coordinate invariant, we know that the singularity at r = 0 cannot possibly be removed by a change of coordinates. Thus, we cannot continue the manifold to negative values of r, so the manifold has a singular boundary at r = 0. We have

$$T^2 - R^2 = \left(1 - \frac{r}{R_s}\right)e^{r/R_s},$$
 (20.38)

which (for r > 0) implies that T <sup>2</sup> −R<sup>2</sup> ≤ 1. The equation T <sup>2</sup> = 1+R<sup>2</sup> is a hyperbola with branches in the top and bottom quadrants. The manifold ends at these boundaries, because it only exists within the region T <sup>2</sup> − R<sup>2</sup> ≤ 1. These boundaries are precisely the boundaries at r = 0.

From the relation

$$T^2 - R^2 = \left(1 - \frac{r}{R_{\rm s}}\right)e^{r/R_{\rm s}}\,,\tag{20.39}$$

we see that lines of constant r form hyperbolas in the (R, T)-plane. The two lines through the origin at ±45◦ form a degenerate hyperbola at r = Rs, and the boundaries in T <sup>2</sup> − R<sup>2</sup> = 1 form the hyperbola at r = 0. Lines of constant t are straight lines in the (R, T)-plane. The line t = 0 is T = 0; lines with t = const. > 0 have positive slope, and t = const. < 0 have negative slope. The ±45◦ lines both correspond to r = Rs, and correspond to t = ±∞. The fact that these lines all correspond to a single point in the Schwarzschild coordinates demonstrates the coordinate singularity of the Schwarzschild coordinates.

What are the other two quadrants? The full solution must include them, or the spacetime would be geodesically incomplete, meaning that trajectories which would otherwise be perfectly good geodesics would suddenly end as they crossed the artificial boundary where we removed these extra regions. The left quadrant is the second exterior region, and the bottom quadrant is the white hole. We will discuss these shortly.

To understand the evolution described by this spacetime metric, we can consider several spacelike slices, each with constant Kruskal time T, as shown in Carroll's Figure 5.14, shown here as Figure [16.](#page-89-0) To visualize each slice, we take advantage of the spherical symmetry, which allows us to consider a two-dimensional slice through the middle of the three-dimensional object, with no loss of information. The curved two-dimensional slices can then be visualized by embedding them in some fictitious three-dimensional space. Such a representation is often called an embedding diagram.

As can be seen in Figure [17,](#page-89-1) slice A has two disconnected pieces. The piece on the right starts at r = 0, where it is singular; we will see a cusp here. As r → ∞, this approaches flat space. The opposite piece is just a mirror image of the first.

Slice C has a single connected piece. Once again, we have asymptotic flat space at both ends, but the two halves join smoothly in the curved middle region. A (spacelike) line from the right end to the left of Figure [16](#page-89-0) would begin at r = ∞ in the external region, where the geometry is asymptotically Euclidean. Recall that r has a simple geometric description: since r 2 is the coefficient of dΩ<sup>2</sup> in the metric, the circumference of the sphere described by varying θ and φ is

<span id="page-89-0"></span>![](_page_89_Picture_3.jpeg)

Figure 16: Spacelike slices in Kruskal coordinates. (Carroll Figure 15.4)

<span id="page-89-1"></span>![](_page_89_Picture_5.jpeg)

Figure 17: Geometry of the spacelike slices in Figure [16.](#page-89-0) (Carroll Figure 15.5)

2πr. The variable r is therefore often called the circumferential radius. As we follow the line, r decreases to a minimum value of Rs, and then starts to increase again in the second external region. On the embedding diagram, the line can be seen to reach the second external region by crossing a connecting tube, which is called a wormhole, or an Einstein–Rosen bridge.

Slice E looks exactly like slice A, and slices B and D interpolate between their neighboring slices. Slices B and D both include wormholes, which are narrower than the maximal wormhole in slice C. The wormhole appears at some time between slice A and slice B, and disappears between slice D and slice E.

We will continue the discussion of the Kruskal geometry in the next lecture.

# 21 Lecture 21 (May 3, 2017)

## 21.1 Kruskal Coordinates

Recall that the Kruskal metric is

$$ds^{2} = \frac{4R_{s}^{3}}{r}e^{-r/R_{s}}(-dT^{2} + dR^{2}) + r^{2}d\Omega^{2}, \qquad (21.1)$$

where r is implicitly defined by the equation

$$\left(1 - \frac{r}{R_{\rm s}}\right)e^{r/R_{\rm s}} = T^2 - R^2.$$
(21.2)

We derived this form of the metric considering only Region I in Figure [15.](#page-87-0) Since the Schwarzschild metric satisfied Rµν = 0, we know that this metric must also satisfy Rµν = 0 (we could also check this explicitly). Then, because the Kruskal metric is an analytic function of the coordinates T and R, we know that the metric must satisfy Rµν = 0 for all values of T and R where the metric is well-defined. This realization allows us to use the metric in all four regions seen in Figure [15.](#page-87-0) We still have the restriction r > 0, which leads to the constraint T <sup>2</sup> − R<sup>2</sup> < 1.

We saw that Region II in Figure [15](#page-87-0) is the interior of the black hole. Regions III and IV are necessary if we want the manifold to not have an artificial boundary (which would cause the manifold to be geodesically incomplete).

We described the evolution of this system by considering embedding diagrams, as seen in Figure [17.](#page-89-1) These were constructed by taking cuts through the Kruskal diagram (Figure [15\)](#page-87-0) at fixed values of the Kruskal time T, as in Figure [16.](#page-89-0) We then described what happens on each of these cuts by drawing an embedding diagram. Each slice is a three-dimensional object that is spherically symmetric; because it is spherically symmetric, we lose nothing by taking a two-dimensional cross section. We then visualize these curved two-dimensional objects by embedding them in three dimensional space (the third dimension we introduce is not physical, and is only added as a useful tool for visualization). Slices A and E have two disconnected components, each of which have cusps. As we move inward to slices B and D, and then to slice C, these cusps connect to form an open tube, which connects Region I and Region III. These tubes are called wormholes or Einstein–Rosen bridges.

We now make several comments regarding the Kruskal metric:

0. Note that we cannot get from Region I to Region III; these regions are spacelike separated. This means that even though these two regions are connected by a wormhole, an observer could not travel through the wormhole unless they could travel backward through time. We say that the wormhole is not traversable.

We might wonder if we could hold the wormhole open by introducing matter to the problem. If we allow ourselves to consider any kind of matter, then we can write down any metric we want and use Einstein's equation to tell us what energy–momentum tensor we need to produce that metric. If one wants to consider only reasonable forms of T µν, then this is harder. As discussed by Carroll on pp. 124–177, general relativists have defined a number of distinct assumptions that one might adopt to define a reasonable form of T µν, called energy conditions.

It turns out that if we want to make the wormhole traversable, we need matter that violates the null energy condition. This follows directly from the Raychaudhuri equation: if one only has matter that satisfies the null energy condition, then the Raychaudhuri equation tells us that gravity only focuses and never defocuses. If the wormhole were traversable, we could imagine a spherical pulse of light travelling inward in Region I, which would then traverse the wormhole and end up travelling spherically outward in Region III, which violates the condition that gravity only focuses. Thus, in order for the wormhole to be traversable, we must have matter that violates the null energy condition.

- 1. Because ds <sup>2</sup> ∝ − dT <sup>2</sup> + dR<sup>2</sup> , light travels along 45◦ lines in the Kruskal diagram.
- 2. Keep in mind that each point in the Kruskal diagram is actually a sphere S 2 , because we have suppressed the coordinates θ and φ.
- 3. Note that r = R<sup>s</sup> = 2GM is an event horizon, meaning that it is the boundary of a region from which particles and light cannot escape to infinity. Within Region II, a timelike line is

one that has a slope steeper than the lightlike line at 45◦ . Looking at Figure [15,](#page-87-0) we then see that every timelike path in Region II must hit the singularity. Unlike the popular picture of black holes, in which there is some powerful force pulling an observer into the singularity after they pass the event horizon, we see that the observer approaches the singularity simply because this is the timelike direction within the horizon; the observer must always move toward the singularity, and they will reach it in finite proper time. The singularity cannot be avoided for the same reason that we cannot avoid reaching tomorrow.

- 4. Region IV is what is known as the white hole region. This is the time reversal of the black hole region: any timelike trajectory in Region IV must begin at the singularity of the white hole, and must cross the horizon at r = R<sup>s</sup> within finite proper time.
- 5. Infalling objects begin in Region I, cross the event horizon to enter Region II, and then terminate on the singularity. By inspecting Figure [15,](#page-87-0) we reach two conclusions:
  - (a) We can immediately see that the amount of proper time for the infalling object to reach the singularity must be finite. This is because the metric is finite; any trajectory that has finite length in the Kruskal diagram will have a finite proper time.
  - (b) If one looks at the Schwarzschild time t, lines of constant t are straight in the Kruskal diagram, and t = ∞ at the 45◦ degree line. Thus, as the particle falls in toward the horizon, t → ∞; the observer at infinity sees the infalling particle take an infinite amount of time to reach the horizon.
- 6. Where is the mass? There is no mass anywhere in the spacetime. We can imagine that there is mass hidden in the singularity at r = 0, but there is no way to formalize this idea mathematically. We can interpret the mass of the Schwarzschild metric as the mass of the spherically symmetric mass distribution that generates it, so long as we do not go within the mass distribution itself. For example, the Sun is described by a Schwarzschild metric outside of the radius of the Sun, and the mass we find in the Schwarzschild metric is exactly the mass of the Sun (not simply the rest mass, but including all of the energy of the Sun).
- 7. Do real black holes actually have wormholes connecting to other spacetimes? Almost certainly not. The key physics that gets leads us to this conclusion is the fact that Rµν = 0 only holds if there is no matter. The Kruskal extension describes an eternal black hole, but we believe that astrophysical black holes (the kind that actually exist) form from the collapse of matter. If we have infalling matter, then the Kruskal metric only holds outside of the infalling mass distribution; the infalling matter then cuts off the wormhole that we find at the center of the Kruskal diagram, as shown in Figure [18.](#page-92-0)
- 8. If there are no wormholes connecting the two external regions, is there any physical significance of the second external region? Maybe.
  - i. In cosmology, there are possibly relevant GR solutions describing "false vacuum bubbles" (see Blau, Guendelman, and Guth, Phys. Rev. D35, 1747 (1987)). A false vacuum is a region in which the energy is in the form of the potential energy of a uniform scalar field. As we have seen, Lorentz invariance of such a system requires p = −ρ; we expect that ρ > 0, meaning that we then have negative pressure. This drives inflation.
    - This situation seems somewhat paradoxical. The negative pressure inside the region implies that the region should grow, due to the gravitational repulsive force associated with inflation. On the other hand, on the boundary, we can see that the pressure gradient

<span id="page-92-0"></span>![](_page_92_Figure_3.jpeg)

Figure 18: A black hole formed by the collapse of matter. The green region is the collapsing matter. The Kruskal metric holds in the grey region.

is inward (negative pressure inside, zero pressure outside), which seems that it would compress the region. Further, if we consider the gravitational force on the outside of the bubble, the region outside of the bubble is described by the Schwarzschild metric with a positive mass M, and so gravity is attractive and acts to shrink the bubble.

The resolution of this issue is that the boundary of the bubble appears to shrink as viewed from the outside, while the volume nonetheless enlarges on the inside. The false vacuum bubble wall is driven to the left in the Kruskal diagram, consistent with the pressure gradient, as shown in Figure [19.](#page-93-0) But it is driven into the second external region, so being pushed to the left means being pushed to larger values of r. Although the diagram does not make it obvious, because the diagram does not show the behavior of the metric, the false vacuum region (diagonal lines) actually grows without limit. Figure [20](#page-93-1) shows a sequence of spacelike hypersurfaces, and Figure [21](#page-94-0) shows embedding diagrams for each of these hypersurfaces. This a process that produces completely separate inflationary universes that split off from our own universe.

ii. In quantum gravity (see Maldacena and Susskind, 2013, arXiv:1306.0533), there is the proposition of ER = EPR. Here, ER refers to the Einstein–Rosen bridge we have recently discussed, and EPR refers to Einstein–Podolsky–Rosen entanglement. Using quantum entanglement, we can use measurements on one particle of an entangled pair to make predictions about subsequent measurements on the other particle of the entangled pair (note that this cannot be used to send information faster than the speed of light). The ER = EPR proposition suggests that entanglement may in fact be related to the Einstein–Rosen bridges of general relativity.

<span id="page-93-0"></span>![](_page_93_Picture_3.jpeg)

Figure 19: A spacetime diagram of a monotonically growing false vacuum bubble solution. Angular coordinates θ and φ are suppressed, and the diagram is plotted so that lightlike lines are at 45◦ . The bubble wall is shown as a heavy line with an arrow on it. The true vacuum region (shaded) is to the right of the bubble wall, and the false vacuum region (diagonal lines) is to the left. The diagram shows the initial (lower) and final (upper) r = 0 singularities, and also a nonsingular r = 0 line (i.e., the center of a spherical coordinate system) that runs along the left edge.

<span id="page-93-1"></span>![](_page_93_Picture_5.jpeg)

Figure 20: The monotonically growing false vacuum bubble of Figure [19,](#page-93-0) showing horizontal lines indicating spacelike hypersurfaces to be illustrated in Figure [21.](#page-94-0)

## 21.2 Tolman–Oppenheimer–Volkoff Equation

We now consider a static, spherically symmetric, perfect fluid. The energy–momentum tensor for a perfect fluid is

$$T^{\mu\nu} = (\rho + p)U^{\mu}U^{\nu} + pg^{\mu\nu}. \tag{21.3}$$

We further assume that we know enough about the matter to write down an equation of state p(ρ). The assumption of that the metric is static and spherically symmetric lets us write down a

<span id="page-94-0"></span>![](_page_94_Picture_3.jpeg)

Figure 21: Embedding diagrams for a monotonically growing false vacuum bubble solution. Each lettered diagram illustrates a spacelike hypersurface indicated in Figure [20.](#page-93-1) The false vacuum region is shown as shaded. Note that diagram (d) shows a new universe detaching from the original spacetime.

general form for the metric:

$$ds^{2} = -e^{2\alpha(r)} dt^{2} + e^{2\beta(r)} dr^{2} + r^{2} d\Omega^{2}, \qquad (21.4)$$

where α(r) and β(r) are arbitrary functions, as far as we know thus far. This is the most general static metric we can write down that is explicitly spherically symmetric: the coefficients of dt 2 , dr 2 , and dΩ<sup>2</sup> are functions of only the radial coordinate. To be more careful, we should note the fact that in GR we have invariance under general coordinate changes, so we might imagine a spherically metric that doesn't manifestly look spherically symmetric, so we have to ask the question of whether it is always possible to transform a spherically symmetric metric into the form above. It turns out that this is always possible.

We now apply Einstein's equations,

$$G_{\mu\nu} \equiv R_{\mu\nu} - \frac{1}{2}g_{\mu\nu}R = 8\pi G T_{\mu\nu} \,.$$
 (21.5)

In solving this equation, it becomes useful to change variables, writing

$$e^{2\beta(r)} = \left[1 - \frac{2Gm(r)}{r}\right]^{-1}. (21.6)$$

We have just rewritten an arbitrary function of r in another way. We will find that the function m(r) turns out the be the total mass within the radius r of the perfect fluid.

We first consider the Gtt Einstein's equation,

$$G_{tt} = 8\pi G T_{tt} \,. \tag{21.7}$$

After some algebra, this gives us

$$\frac{\mathrm{d}m}{\mathrm{d}r} = 4\pi r^2 \rho(r) \,. \tag{21.8}$$

We integrate this to reach

<span id="page-95-2"></span>
$$m(r) = 4\pi \int_0^r \rho(r')r'^2 dr',$$
 (21.9)

which gives us the physical interpretation of m(r) that we anticipated before: it is the total mass within radius r.

We next consider

$$G_{rr} = 8\pi G T_{rr} \,, \tag{21.10}$$

which gives the equation

<span id="page-95-0"></span>
$$\frac{\mathrm{d}\alpha}{\mathrm{d}r} = \frac{Gm(r) + 4\pi Gr^3 p}{r[r - 2Gm(r)]} \tag{21.11}$$

Using spherical symmetry, we have

$$G_{\theta\theta} = \frac{1}{\sin^2 \theta} G_{\phi\phi} \,, \tag{21.12}$$

so the associated Einstein's equations will contain the same information. We also know that  $\nabla_{\mu}T^{\mu\nu} = 0$ ; this is implied by Einstein's equations, so Einstein's equations along with the conservation of the energy–momentum tensor form a redundant system of equations. In our case, it is most convenient to use this fact to ignore the  $G_{\theta\theta}$  and  $G_{\phi\phi}$  Einstein's equations, and instead use the equation following from energy–momentum conservation,

<span id="page-95-1"></span>
$$(\rho + p)\frac{\mathrm{d}\alpha}{\mathrm{d}r} = -\frac{\mathrm{d}p}{\mathrm{d}r}.$$
 (21.13)

Combining Eqs. (21.11) and (21.13), we find the TOV equation:

$$\boxed{\frac{\mathrm{d}p}{\mathrm{d}r} = -\frac{\left[(\rho + p)Gm(r) + 4\pi Gr^3 p\right]}{r[r - 2Gm(r)]}}.$$
(21.14)

At r = 0, the above expression looks singular, since the denominator has two factors of zero. However, to leading order in r we have from Eq. (21.9) that

$$m(r) = \frac{4\pi}{3}\rho(0)r^3 + O(r^4), \qquad (21.15)$$

which tells us that, in fact, dp/dr vanishes at r=0, so there is no singularity.

We can use the TOV equation to integrate outward from the center of the star, choosing an initial value for the mass density,  $\rho(0)$ . The equation of state determines p in terms of  $\rho$ . Incrementing r in very small steps  $\Delta r$ , at each step the TOV equation is used to determine the update in p. The equation of state then determines the update in  $\rho$ , and Eq. (21.9) determines the update in m(r). The integration is continued until  $\rho(r) = p(r) = 0$ , which defines the outer edge of the star.

## 22 Lecture 22 (May 8, 2017)

### 22.1 Symmetries and Killing Vectors

Killing vectors are a general way of describing symmetries in general relativity. To start with, we will define a symmetry, or isometry, of the metric, following the treatment given in Weinberg. Note that for this discussion we will also drop Carroll's treatment of primes, using  $x^{\mu}$  and  $x'^{\mu}$  to denote two different coordinate systems for the same space, with  $\mu$  and  $\mu'$  both being regular indices running from 0 to 3.

We say that the metric  $g_{\mu\nu}(x)$  is form-invariant under a given transformation  $x \to x'(x)$  if the transformed metric  $g'_{\mu\nu}(x')$  is the same function of its argument  $x'^{\mu}$  as  $g_{\mu\nu}(x)$  is of its argument  $x^{\mu}$ . When can this happen? The general transformation rule for the metric is

$$g_{\mu\nu}(x) = \frac{\partial x^{\prime\rho}}{\partial x^{\mu}} \frac{\partial x^{\prime\sigma}}{\partial x^{\nu}} g_{\rho\sigma}^{\prime}(x^{\prime}). \qquad (22.1)$$

Given this equation, we see that form-invariance of the metric is the statement

<span id="page-96-0"></span>
$$g_{\mu\nu}(x) = \frac{\partial x^{\prime\rho}}{\partial x^{\mu}} \frac{\partial x^{\prime\sigma}}{\partial x^{\nu}} g_{\rho\sigma}(x^{\prime}), \qquad (22.2)$$

where we have simply dropped the prime on the metric on the right-hand side. Such a transformation x'(x) is called an *isometry*.

To discuss Killing vectors, we want to discuss infinitesimal isometries. We write an infinitesimal transformation in the form

$$x'^{\mu} = x^{\mu} + \epsilon K^{\mu}(x), \qquad (22.3)$$

where we take  $\epsilon$  to be infinitesimal. This is where it becomes important that we are not using Carroll's notation; we want the indices on each side of the equation to be the same, making it apparent that the transformed coordinates are equal to the original coordinates to leading order. We can then plug this expression for the infinitesimal transformation into Eq. (22.2) and expand to leading order in  $\epsilon$ , giving

$$g_{\mu\nu}(x) = \left[\delta^{\rho}_{\mu} + \epsilon \frac{\partial K^{\rho}}{\partial x^{\mu}}\right] \left[\delta^{\sigma}_{\nu} + \epsilon \frac{\partial K^{\sigma}}{\partial x^{\nu}}\right] \left[g_{\rho\sigma}(x) + \epsilon \frac{\partial g_{\rho\sigma}}{\partial x^{\lambda}} K^{\lambda}\right]. \tag{22.4}$$

Dropping terms above first order in  $\epsilon$  and rearranging then gives

<span id="page-96-1"></span>
$$0 = \frac{\partial K^{\rho}}{\partial x^{\mu}} g_{\rho\nu} + \frac{\partial K^{\sigma}}{\partial x^{\nu}} g_{\sigma\mu} + \frac{\partial g_{\mu\nu}}{\partial x^{\lambda}} K^{\lambda}. \tag{22.5}$$

This is the equation that  $K^{\mu}$  must satisfy to be a Killing vector; this is not the standard form of the Killing equation, but it is often easier to see what properties  $K^{\mu}$  satisfies by looking at this equation.

We can rewrite this equation by replacing the first two terms each with a total derivative, and then subtracting off the additional term this introduces. This gives us

$$0 = \partial_{\mu}(K^{\rho}g_{\rho\nu}) - K^{\rho}\partial_{\mu}g_{\rho\nu} + \partial_{\nu}(K^{\sigma}g_{\sigma\mu}) - K^{\sigma}\partial_{\nu}g_{\sigma\mu} + \frac{\partial g_{\mu\nu}}{\partial x^{\lambda}}K^{\lambda}. \tag{22.6}$$

Regrouping terms, this becomes

$$0 = \partial_{\mu} K_{\nu} + \partial_{\nu} K_{\mu} - K^{\rho} [\partial_{\mu} g_{\rho\nu} + \partial_{\nu} g_{\rho\mu} - \partial_{\rho} g_{\mu\nu}]$$
  
=  $\partial_{\mu} K_{\nu} + \partial_{\nu} K_{\mu} - 2K_{\rho} \Gamma^{\rho}_{\mu\nu}$ . (22.7)

We see that these Christoffel symbols are exactly what are necessary to change the first two terms into covariant derivatives, which leads us finally to the *Killing equation*:

$$\boxed{\nabla_{\mu}K_{\nu} + \nabla_{\nu}K_{\mu} = 0}.$$
(22.8)

As a special case, consider  $K = \partial_{\sigma}$ , for some particular value of  $\sigma$ . Since  $K = K^{\mu}\partial_{\mu}$ , this means that  $K^{\mu} = \delta^{\mu}_{\sigma}$ . In this case, Eq. (22.5) simply gives us

<span id="page-97-0"></span>
$$\partial_{\sigma}g_{\mu\nu} = 0, \qquad (22.9)$$

telling us that  $g_{\mu\nu}$  is independent of  $x^{\sigma}$ . Note that the above equation holds for all values of  $\mu$  and  $\nu$ , but only for the one particular value of  $\sigma$  specified at the start of the paragraph.

Killing vectors correspond to conservation laws along geodesics. We have already seen a special case of this. One form of the geodesic equation we have seen is

$$\frac{\mathrm{d}}{\mathrm{d}\tau} \left[ g_{\mu\nu} \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \right] = \frac{1}{2} \frac{\partial g_{\lambda\sigma}}{\partial x^{\mu}} \frac{\mathrm{d}x^{\lambda}}{\mathrm{d}\tau} \frac{\mathrm{d}x^{\sigma}}{\mathrm{d}\tau} \,. \tag{22.10}$$

One immediate consequence of this equation is that if the the metric is independent of one coordinate  $x^{\mu}$ , then the right-hand side vanishes for that value of  $\mu$ , and then the expression in brackets on the left-hand side is a conserved quantity.

In general, when a Killing vector exists, then  $p_{\mu}K^{\mu}$  is conserved along geodesics. We will now prove this fact. Let  $x^{\mu}(\tau)$  describe a timelike geodesic. Then

$$p^{\mu} = m \frac{\mathrm{d}x^{\mu}}{\mathrm{d}\tau} \,, \tag{22.11}$$

where m is the rest mass of the particle. We then have

$$\frac{\mathrm{d}}{\mathrm{d}\tau}(p_{\mu}K^{\mu}) = \frac{\mathrm{d}x^{\nu}}{\mathrm{d}\tau} \nabla_{\nu}(p_{\mu}K^{\mu})$$

$$= \frac{1}{m} p^{\nu} \left[ (\nabla_{\nu} p_{\mu}) K^{\mu} \right]$$

$$= \frac{1}{m} p^{\nu} p_{\mu} \nabla_{\nu} K^{\mu}$$

$$= \frac{1}{m} p^{\nu} p^{\mu} \nabla_{\nu} K_{\mu}.$$
(22.12)

On the second line, the first term is zero from the geodesic equation, which says that the velocity vector is parallel transported along the geodesic,  $p^{\nu}\nabla_{\nu}p_{\mu} = 0$ . The Killing equation, Eq. (22.8), tells us that  $\nabla_{\nu}K_{\mu}$  is antisymmetric in its indices, while  $p^{\nu}p^{\mu}$  is clearly symmetric, so we finally find

$$\frac{\mathrm{d}}{\mathrm{d}\tau}(p_{\mu}K^{\mu}) = 0\,, (22.13)$$

proving that  $p_{\mu}K^{\mu}$  is conserved along the geodesic.

If  $K^{\mu}$  is a timelike Killing vector, then  $p_{\mu}K^{\mu}$  is the conserved energy. Note that if  $K^{\mu}$  exists, we can always define a coordinate system  $x^{\mu'}$  such that  $K^{\mu}\partial_{\mu} = \partial_{\sigma'}$  for some particular value of  $\sigma'$ . The metric in the primed coordinates is then independent of  $x^{\sigma'}$  (for the particular value of  $\sigma'$ ).

### 22.2 Volumes in Curved Spacetimes

#### 22.2.1 Volumes in Euclidean Space

Consider a rectangle in  $\mathbb{R}^2$ , with side lengths  $\mathrm{d}x^1$  and  $\mathrm{d}x^2$ . The area of this rectangle, as we know, is  $A = \mathrm{d}x^1 \, \mathrm{d}x^2$ . It is useful to understand the areas of not only rectangles, but also parallelograms. Consider a parallelogram defined by two vectors  $\mathrm{d}\vec{x}_{(1)}$ ,  $\mathrm{d}\vec{x}_{(2)}$ , with angle  $\theta$  between them. The area of the parallelogram is then

$$A = |d\vec{x}_{(1)}||d\vec{x}_{(2)}|\sin\theta = |d\vec{x}_{(1)} \times d\vec{x}_{(2)}| = \tilde{\epsilon}_{ij} dx_{(1)}^i dx_{(2)}^j, \qquad (22.14)$$

where  $\tilde{\epsilon}_{ij}$  is the Levi-Civita symbol, defined to be the totally-antisymmetric two-index tensor with  $\tilde{\epsilon}_{12} = 1$ . Note that, in terms of the 3-dimensional Levi-Civita symbol  $\tilde{\epsilon}_{ijk}$ ,  $\tilde{\epsilon}_{ij} = \tilde{\epsilon}_{ijz}$ .

Now in  $\mathbb{R}^3$ , we will analogously consider a parallelepiped defined by vectors  $d\vec{x}_{(1)}$ ,  $d\vec{x}_{(2)}$ , and  $d\vec{x}_{(3)}$ . The volume can be written as

$$V = (d\vec{x}_{(1)} \times d\vec{x}_{(2)}) \cdot d\vec{x}_{(3)} = \tilde{\epsilon}_{ijk} dx_{(1)}^i dx_{(2)}^j dx_{(3)}^k.$$
 (22.15)

We now claim that, in  $\mathbb{R}^N$ , the N-dimensional parallelepiped (technically called an N-parallelotope) defined by  $d\vec{x}_{(1)}, \dots, d\vec{x}_{(N)}$  has volume

$$V^{(N)} = \tilde{\epsilon}_{i_1 \cdots i_N} \, \mathrm{d}x_{(1)}^{i_1} \cdots \mathrm{d}x_{(N)}^{i_N} \,. \tag{22.16}$$

This can be shown by an inductive argument, developing the idea that  $V^{(N)}$  is equal to the product of the volume  $V^{(N-1)}$  of the (N-1)-dimensional parallelepiped defined by  $d\vec{x}_{(1)}, \ldots, d\vec{x}_{(N-1)}$  and the component of  $d\vec{x}_{(N)}$  that is orthogonal to the space spanned by the vectors  $d\vec{x}_{(1)}, \ldots, d\vec{x}_{(N-1)}$ .

How does the Levi–Civita symbol  $\tilde{\epsilon}$  transform under rotations? If  $\mathcal{O}$  is the orthogonal matrix of the rotation, we have

$$\tilde{\epsilon}'_{i'_1 \cdots i'_N} = \mathcal{O}_{i'_1}{}^{i_1} \mathcal{O}_{i'_2}{}^{i_2} \cdots \mathcal{O}_{i'_N}{}^{i_N} \tilde{\epsilon}_{i_1 \cdots i_N} . \tag{22.17}$$

Suppose we look at one particular value of this tensor (this will tell us all entries, because it is totally-antisymmetric). We have

$$\tilde{\epsilon}'_{12\cdots N} = \mathcal{O}_1^{i_1} \mathcal{O}_2^{i_2} \cdots \mathcal{O}_N^{i_N} \tilde{\epsilon}_{i_1\cdots i_N} = \det \mathcal{O} = 1.$$
(22.18)

Here, we have used the definition of the determinant in terms of the Levi–Civita symbol, and the fact that all (orientation-preserving) orthogonal matrices have determinant 1. Thus, it follows that

$$\tilde{\epsilon}' = \tilde{\epsilon} \,. \tag{22.19}$$

The Levi–Civita symbol is invariant under rotations.

### 22.2.2 Curved Space

In curved space, we can write the same expression in locally inertial coordinates for any infinitesimal volume:

$$dV^{(N)} = \tilde{\epsilon}_{i_1 \cdots i_N} d\xi_{(1)}^{i_1} \cdots d\xi_{(N)}^{i_N}.$$
(22.20)

We now want to write this expression in general coordinates, instead of the locally inertial coordinates; using the chain rule, we have

<span id="page-99-0"></span>
$$dV^{(N)} = \tilde{\epsilon}_{i_{1}\cdots i_{N}} \frac{\partial \xi_{(1)}^{i_{1}}}{\partial x_{(1)}^{i'_{1}}} \cdots \frac{\partial \xi_{(N)}^{i_{N}}}{\partial x_{(N)}^{i'_{N}}} dx_{(1)}^{i'_{1}} \cdots dx_{(N)}^{i'_{N}}$$

$$= \tilde{\epsilon}_{i_{1}\cdots i_{N}} \frac{\partial \xi^{i_{1}}}{\partial x^{i'_{1}}} \cdots \frac{\partial \xi^{i_{N}}}{\partial x^{i'_{N}}} dx_{(1)}^{i'_{1}} \cdots dx_{(N)}^{i'_{N}}$$

$$= \tilde{\epsilon}_{i'_{1}\cdots i'_{N}} \det\left(\frac{\partial \xi^{j}}{\partial x^{k}}\right) dx_{(1)}^{i'_{1}} \cdots dx_{(N)}^{i'_{N}}$$

$$= \tilde{\epsilon}_{i_{1}\cdots i_{N}} \det\left(\frac{\partial \xi^{j}}{\partial x^{k}}\right) dx_{(1)}^{i_{1}} \cdots dx_{(N)}^{i_{N}}.$$

$$(22.21)$$

In the second line, we used the fact that the transformation matrix is the same for each vector, so we dropped the  $(1), \ldots, (N)$ . To justify the third line, consider first the contribution to the second line from  $(i'_1, \ldots, i'_N) = (1, \ldots, N)$ , noting that

$$\tilde{\epsilon}_{i_1\cdots i_N} \frac{\partial \xi^{i_1}}{\partial x^1} \cdots \frac{\partial \xi^{i_N}}{\partial x^N} = \det\left(\frac{\partial \xi^j}{\partial x^k}\right).$$
 (22.22)

Then for arbitrary assignment of  $(i'_1, \ldots, i'_N)$ , the result must be fully antisymmetric:

$$\tilde{\epsilon}_{i_1\cdots i_N} \frac{\partial \xi^{i_1}}{\partial x^{i'_1}} \cdots \frac{\partial \xi^{i_N}}{\partial x^{i'_N}} = \tilde{\epsilon}_{i'_1\cdots i'_N} \det\left(\frac{\partial \xi^j}{\partial x^k}\right). \tag{22.23}$$

Then in the last line of Eq. (22.21), we dropped primes on all dummy indices.

Beginning with

<span id="page-99-1"></span>
$$g_{\mu\nu} = \frac{\partial \xi^{\mu'}}{\partial x^{\mu}} \frac{\partial \xi^{\nu'}}{\partial x^{\nu}} \eta_{\mu'\nu'} , \qquad (22.24)$$

we can take the determinant of both sides to reach

$$\det(g_{\mu\nu}) = -\left[\det\left(\frac{\partial \xi^j}{\partial x^k}\right)\right]^2. \tag{22.25}$$

We then define

$$g \equiv -\det(g_{\mu\nu}) = \left[\det\left(\frac{\partial \xi^j}{\partial x^k}\right)\right]^2.$$
 (22.26)

We can then write

$$dV^{(N)} = \sqrt{g} \,\tilde{\epsilon}_{i_1 \cdots i_N} \,dx_{(1)}^{i_1} \cdots dx_{(N)}^{i_N}. \tag{22.27}$$

We define

$$\epsilon_{i_1\cdots i_N} \equiv \sqrt{g}\,\tilde{\epsilon}_{i_1\cdots i_N}\,,\tag{22.28}$$

so  $\epsilon_{i_1\cdots i_N}$  transforms as a tensor, unlike  $\tilde{\epsilon}_{i_1\cdots i_N}$ , which according to Eq. (22.23) acquires a factor of  $\det\left(\frac{\partial \xi^j}{\partial x^k}\right)$ , which makes the Levi–Civita symbol a tensor density of weight 1. Then,

$$dV^{(N)} = \epsilon_{i_1 \dots i_N} dx_{(1)}^{i_1} \cdots dx_{(N)}^{i_N}.$$
(22.29)

As a special case, we consider the case where the parallelepiped is a rectangular solid in coordinate space, with each side running along one of the coordinate axes. Then

<span id="page-99-2"></span>
$$dx_{(1)}^i = \delta_1^i dx^1, \quad dx_{(2)}^i = \delta_2^i dx^2, \quad \dots$$
 (22.30)

In this case, the volume formula gives us

$$dV^{(N)} = \sqrt{g}\,\tilde{\epsilon}_{1\cdots N}\,dx^1\cdots dx^N = \sqrt{g}\,dx^1\cdots dx^N \equiv \sqrt{g}\,d^Nx\,. \tag{22.31}$$

## 23 Lecture 23 (May 10, 2017)

### 23.1 Integration

Last time, we saw that we could write the volume of an N-dimensional Euclidean parallelepiped (technically an N-parallelotope) as

$$dV^{(N)} = \tilde{\epsilon}_{i_1 \cdots i_N} dx_{(1)}^{i_1} \cdots dx_{(N)}^{i_N}, \qquad (23.1)$$

where  $\tilde{\epsilon}_{i_1\cdots i_N}$  is the Levi–Civita symbol, the totally-antisymmetric tensor with  $\tilde{\epsilon}_{12\cdots N}=1$ . Here,  $\mathrm{d}x^i_{(j)}$  indicates the *i*th component of the vector defining the *j*th edge of the parallelepiped.

We generalized this to curved spaces by using the above formula in the locally inertial coordinates, and then transforming back to general coordinates. The result we found was

$$dV^{(N)} = \sqrt{g} \,\tilde{\epsilon}_{i_1 \cdots i_N} \,dx_{(1)}^{i_1} \cdots dx_{(N)}^{i_N}, \qquad (23.2)$$

where  $g \equiv |\det g_{\mu\nu}|$ . We then define

$$\epsilon_{i_1\cdots i_N} \equiv \sqrt{g}\,\tilde{\epsilon}_{i_1\cdots i_N}\,,$$
(23.3)

the Levi-Civita tensor. We can then write

$$dV^{(N)} = \epsilon_{i_1 \cdots i_N} dx_{(1)}^{i_1} \cdots dx_{(N)}^{i_N}, \qquad (23.4)$$

In the case of curved space, the vectors  $dx_{(j)}^i$  must be infinitesimal. As a special case, we can consider the rectangular solid in coordinate space, where these vectors lie along the coordinate basis directions. In this case, we have

$$\mathrm{d}x_{(j)}^i = \delta_j^i \,\mathrm{d}x^j \,, \tag{23.5}$$

where there is no implied summation over j, e.g.  $dx_{(1)}^i = \delta_1^i dx^1$ . Then, the volume formula gives

$$dV^{(N)} = \sqrt{g}\,\tilde{\epsilon}_{1\cdots N}\,dx^1\cdots dx^N = \sqrt{g}\,dx^1\cdots dx^N \equiv \sqrt{g}\,d^Nx\,. \tag{23.6}$$

#### 23.1.1 Differential Forms

Another common notation for dealing with these concepts is that of *n*-forms and wedge products. An *n*-form is a fully antisymmetric covariant tensor,  $\omega_{\mu_1\cdots\mu_n}$ . We define the exterior derivative of an *n*-form by

$$(d\omega)_{\mu_1\cdots\mu_{n+1}} = (n+1)\partial_{[\mu_{n+1}}\omega_{\mu_1\cdots\mu_n]},$$
 (23.7)

where we have antisymmetrized on all of the indices. We can immediately see that  $d d\omega = 0$ , because partial derivatives commute, so when we antisymmetrize all of the indices this will vanish.

<span id="page-100-0"></span>We now define the wedge product. Given a p-form A and a q-form B, their wedge product is given by

$$(A \wedge B)_{\mu_1 \cdots \mu_{p+q}} = \frac{(p+q)!}{p!q!} A_{[\mu_1 \cdots \mu_p} B_{\mu_{p+1} \cdots \mu_{p+q}]}. \tag{23.8}$$

The numerical factor in the numerator cancels the factor coming from the definition of antisymmetrization (e.g.,  $A_{[\mu\nu]} = \frac{1}{2!}[A_{\mu\nu} - A_{\nu\mu}]$ ), while the factors in the denominator give the corresponding factors that would accompany the antisymmetrization of A and B separately.

We must now define coordinate 1-forms, written as  $dx^{\mu}$ . This looks like it has a single upper index, so it doesn't seem to fit our definition of a 1-form. However, our interpretation here is

that  $x^{\mu}$  is a 0-form (with no indices), where  $\mu$  is simply a label telling us which coordinate we are considering. The exterior derivative of this 0-form is then

$$(\mathrm{d}x^{\mu})_{\alpha} = \partial_{\alpha}x^{\mu} = \delta^{\mu}_{\alpha}. \tag{23.9}$$

Keep in mind here that  $\mu$  is the label of which coordinate we are considering, while  $\alpha$  is the index. This allows us to define another convention. We define

$$\mathrm{d}x^{\mu} = \mathrm{d}x^{\mu}_{\alpha}dx^{\alpha} = \delta^{\mu}_{\alpha}dx^{\alpha} = dx^{\mu}\,,\tag{23.10}$$

where we are now using  $dx^{\alpha}$  (note the italicized d) to indicate an ordinary coordinate differential, by contrast with  $dx^{\mu}$ , which is the exterior derivative of the 0-form  $x^{\mu}$ .

We can then consider the wedge product  $dx^1 \wedge dx^2 \wedge \cdots \wedge dx^n$ , which can be written in components as

$$(dx^{1} \wedge dx^{2} \wedge \cdots \wedge dx^{n})_{\alpha_{1} \cdots \alpha_{n}} = n! (dx^{1})_{[\alpha_{1}} (dx^{2})_{\alpha_{2}} \cdots (dx^{n})_{\alpha_{n}]}$$

$$= n! \delta^{1}_{[\alpha_{1}} \delta^{2}_{\alpha_{2}} \cdots \delta^{n}_{\alpha_{n}]}$$

$$= \tilde{\epsilon}_{\alpha_{1} \cdots \alpha_{n}}.$$

$$(23.11)$$

The factor of n! appears in the first line above as a consequence of the definition of the wedge product, Eq. (23.8). It disappears in the last equality, because the antisymmetrization in the  $\alpha$ s introduces a factor of  $\frac{1}{n!}$ ; for n=2, for example, the last equality reduces to  $2!\delta_{[\alpha_1}^1\delta_{\alpha_2]}^2=2!\cdot\frac{1}{2}\left(\delta_{\alpha_1}^1\delta_{\alpha_2}^2-\delta_{\alpha_2}^1\delta_{\alpha_1}^2\right)=\tilde{\epsilon}_{\alpha_1\alpha_2}$ . Recall that  $\tilde{\epsilon}_{\alpha_1\cdots\alpha_n}$  is not a tensor, but it is related to the tensor  $\epsilon_{\alpha_1\cdots\alpha_n}=\sqrt{g}\,\tilde{\epsilon}_{\alpha_1\cdots\alpha_n}$ . Thus, in the language of forms we define the volume form by

$$dV^{(n)} = \sqrt{g} dx^1 \wedge dx^2 \wedge \dots \wedge dx^n, \qquad (23.12)$$

which in terms of components is written

<span id="page-101-0"></span>
$$\left( dV^{(n)} \right)_{\alpha_1 \cdots \alpha_n} = \epsilon_{\alpha_1 \cdots \alpha_n} \,. \tag{23.13}$$

We define integration over a form  $\omega$  in terms of its components by

$$\int \omega \equiv \int \omega_{12\cdots n} dx^1 dx^2 \cdots dx^n , \qquad (23.14)$$

where the integral on the right can be interpreted as either a Riemann or a Lebesgue integral. This definition is discussed in Wald, Appendix B, while Carroll seems to tacitly assume it, although it appears in Carroll's Eq. (2.96) on p. 90. With this definition,

$$\int dV^{(n)} = \int \sqrt{g} dx^1 dx^2 \cdots dx^n \equiv \int \sqrt{g} d^n x, \qquad (23.15)$$

in agreement with Eq. (22.31).

Note also that Eq. (23.14) implies that

$$\int dx^1 \wedge dx^2 \wedge \dots \wedge dx^n \equiv \int d^n x, \qquad (23.16)$$

and that our normalization conventions imply that

$$\omega = \frac{1}{n!} \omega_{\alpha_1 \cdots \alpha_n} \, \mathrm{d}x^{\alpha_1} \wedge \cdots \wedge \mathrm{d}x^{\alpha_n} \tag{23.17}$$

for any *n*-form  $\omega$ .

### 23.1.2 Stokes Theorem

In the language of differential forms, Stokes' theorem tells us that

$$\int_{M} d\omega = \int_{\partial M} \omega \,, \tag{23.18}$$

where M is a region of a manifold with dimension dim M = n, ∂M is the boundary of M, and ω is an (n − 1)-form.

We will now see that this reproduces the results we are familiar with from vector calculus. To see this, we will use the fact that

<span id="page-102-1"></span>
$$\nabla_{\mu}V^{\mu} = \frac{1}{\sqrt{g}}\partial_{\mu}(\sqrt{g}V^{\mu}), \qquad (23.19)$$

which will be shown on Problem Set 13. We will also write

$$\omega_{\mu_1\cdots\mu_{n-1}} = \epsilon_{\mu_1\cdots\mu_n} V^{\mu_n} \,. \tag{23.20}$$

It is always possible to find such a V µ (it is called the Hodge dual of ω); we can convince ourselves that this is possible by noting that ω has d independent components, where d = n is the dimension of spacetime. To see this, note that the antisymmetry of ωµ1···µn−<sup>1</sup> implies that nonzero values have all the µ<sup>1</sup> · · · µn−<sup>1</sup> different, and that the value of ω for one ordering determines the value for all other orderings. When µ<sup>1</sup> · · · µn−<sup>1</sup> are all different, there is exactly one value that is left out, so each independent value of ωµ1···µn−<sup>1</sup> can be associated with one possible value for the index. We can then write

<span id="page-102-0"></span>
$$d\omega = n\partial_{[\mu_n} \left( \epsilon_{\mu_1 \cdots \mu_{n-1}]\nu} V^{\nu} \right) = \partial_{\nu} \left( \epsilon_{\mu_1 \cdots \mu_n} V^{\nu} \right) = \tilde{\epsilon}_{\mu_1 \cdots \mu_n} \partial_{\nu} \left( \sqrt{g} V^{\nu} \right). \tag{23.21}$$

The middle equality is not obvious, but note that the antisymmetrization gives

$$n\partial_{[\mu_n}\left(\epsilon_{\mu_1\cdots\mu_{n-1}]\nu}V^\nu\right) = \sum_{j=1}^n (-1)^j \partial_{\mu_j}\left(\epsilon_{\mu_1\cdots\mu_j\cdots\mu_n\nu}V^\nu\right),\tag{23.22}$$

where the cross-out on µ<sup>j</sup> means that µ<sup>j</sup> is omitted from the sequence. Since the expression is totally antisymmetric in µ<sup>1</sup> · · · µn, it is sufficient to evaluate it for µ<sup>1</sup> = 1, µ<sup>2</sup> = 2, etc. Then

$$n\partial_{[n}\left(\epsilon_{1\cdots(n-1)]\nu}V^{\nu}\right) = \sum_{j=1}^{n} (-1)^{j}\partial_{j}\left(\epsilon_{1\cdots\not{j}\cdots n\nu}V^{\nu}\right), \qquad (23.23)$$

The antisymmetry of implies that the expression will vanish unless ν = j, and if the indices are rearranged to their natural order, the factor of (−1)<sup>j</sup> will be cancelled:

$$n\partial_{[n}(\epsilon_{1\cdots(n-1)]\nu}V^{\nu}) = \sum_{\nu=1}^{n} \partial_{\nu}(\epsilon_{1\cdots n}V^{\nu}) = \partial_{\nu}(\epsilon_{1\cdots n}V^{\nu}).$$
 (23.24)

Restoring the full antisymmetry in µ<sup>1</sup> · · · µ<sup>n</sup> gives the result that we used in Eq. [\(23.21\)](#page-102-0). Using Eq. [\(23.19\)](#page-102-1), we then have

$$d\omega = \sqrt{g}\,\tilde{\epsilon}_{\mu_1\cdots\mu_n}\nabla_{\nu}V^{\nu} = \epsilon_{\mu_1\cdots\mu_n}\nabla_{\nu}V^{\nu}. \tag{23.25}$$

We see then that

$$\int_{M} d\omega = \frac{1}{n!} \int_{M} \epsilon_{\mu_{1} \cdots \mu_{n}} \nabla_{\nu} V^{\nu} dx^{\mu_{1}} \wedge \cdots \wedge dx^{\mu_{n}}$$

$$= \int_{M} \sqrt{g} d^{n}x \nabla_{\nu} V^{\nu}$$

$$= \int_{M} d^{n}x \partial_{\nu} (\sqrt{g} V^{\nu}).$$
(23.26)

This turns the left-hand side of Stokes' theorem into a regular vector calculus integral.

The right-hand side of Stokes' theorem involves integration over a surface, which is the boundary of the volume M. Define Σ = ∂M to be the boundary of M; this surface has codimension 1, meaning that dim Σ = dim M − 1. To describe this surface, we will use a special set of coordinates, called Gaussian normal coordinates. Let y1, . . . , yn−<sup>1</sup> be arbitrary coordinates on Σ, and let y<sup>n</sup> be the normalized coordinate normal to Σ in M. In these coordinates, the metric on M can be written in the form

$$g_{\mu\nu} = \begin{pmatrix} \gamma_{ij} & 0\\ 0 & 1 \end{pmatrix}, \tag{23.27}$$

where i, j = 1, . . . , n − 1 and µ, ν = 1, . . . , n. Note that the bottom right entry is 1 because we chose y<sup>n</sup> to be normalized, and the off-diagonal elements are zero because y<sup>n</sup> is measured in the direction orthogonal to the surface. This implies that det gµν = det γij . We can then write

$$\int_{\Sigma} \omega = \frac{1}{(n-1)!} \int_{\Sigma} \epsilon_{\mu_1 \cdots \mu_n} V^{\mu_n} \, \mathrm{d}y^{i_1} \wedge \cdots \wedge \mathrm{d}y^{i_{n-1}} 
= \int_{\Sigma} \sqrt{g} \,\tilde{\epsilon}_{1 \cdots (n-1)\mu_n} V^{\mu_n} \, \mathrm{d}y^1 \wedge \cdots \wedge \mathrm{d}y^{n-1} .$$
(23.28)

Defining γ = |det γij |, we then use the fact that g = γ to reach

$$\int_{\Sigma} \omega = \int_{\Sigma} \sqrt{\gamma} d^{n-1} y \ V^n = \int_{\Sigma} \sqrt{\gamma} d^{n-1} y \ n_{\mu} V^{\mu} . \tag{23.29}$$

Here we have used the fact that since y j takes on the values j = 1, . . . , n − 1, the only value of µ<sup>n</sup> for which the Levi–Civita symbol does not vanish is µ<sup>n</sup> = n. We have defined n<sup>µ</sup> to be a normalized outward normal vector to Σ.

In conclusion, we have

$$\int_{M} d^{n}x \sqrt{g} \nabla_{\mu} V^{\mu} = \int_{\partial M} d^{n-1}y \sqrt{\gamma} n_{\mu} V^{\mu}.$$
 (23.30)

We can relate this to our standard vector calculus knowledge by using Eq. [\(23.19\)](#page-102-1) to write

$$\int_{M} d^{n}x \sqrt{g} \nabla_{\mu} V^{\mu} = \int_{M} d^{n}x \, \partial_{\nu} (\sqrt{g} V^{\nu}). \qquad (23.31)$$

# 24 Lecture 24 (May 15, 2017)

## 24.1 Energy

The energy–momentum tensor T µν of matter is not conserved; it is instead covariantly conserved,

$$0 = \nabla_{\mu} T^{\mu\nu} = \frac{1}{\sqrt{g}} \partial_{\mu} (\sqrt{g} T^{\mu\nu}) + \Gamma^{\nu}_{\mu\lambda} T^{\mu\lambda} . \tag{24.1}$$

The second term describes the transfer of energy and momentum between the gravitational field and matter. This indicates that the energy of gravity alone or of matter alone is not conserved.

This leads us to a question: is it possible to define the energy of the gravitational field in such a way that the total energy is conserved? A partial non-answer is that there certainly exists no local definition of gravitational energy that is covariant under coordinate transformations.

We now have to decide if we want to insist on covariance. This question divides people into two different groups. There are the "orthodox covariantists," such as Carroll[1](#page-0-0) and Wald[2](#page-0-0) , who insist on a covariant definition; as a result, these authors make very few statements about gravitational energy, because it is very hard to make such statements if we insist on covariance. Both quote the ADM (Arnowitt–Deser–Misner) energy, which is defined only in asymptotically flat spaces. Wald also quotes a theorem about the Bondi energy, which also requires asymptotic flatness. The ADM energy is defined on spacelike slices of the spacetime, while the Bondi energy considers energies at various retarded times, making it useful when discussing gravitational radiation.

There are a few defects to the "orthodox covariantist" approach, in the opinion of this lecturer. One is that there is no evidence that the universe is asymptotically flat. (In fact, most cosmologists would be shocked if we were told that the universe is asymptotically flat. You may have heard that the universe is known to be at least very nearly flat, but this is a different meaning of the word "flat". Inflation predicts that the three-dimensional geometry of the universe should be almost exactly flat (Euclidean), and it has been confirmed that the average mass density of the universe is within 0.5% of the value needed for flatness. However, asymptotic flatness refers to four-dimensional spacetime flatness, i.e., Minkowski space, and the universe looks nothing like that.) Second, even if the universe were asymptotically flat, a statement of the form Etot = const., as in the case of the ADM energy, is completely meaningless; we cannot test it, since we can't measure the energy of the universe, and even if we were told the total energy, we couldn't use it in any useful way: in particular, it would not exclude the possibility that energy could disappear on Earth, and appear in some hidden location behind the galaxy M87. To be fair, we can apply the ADM analysis to any gravitationally isolated system, which may be a subset of the entire universe, although the application of this is still very limited. We could apply it, perhaps, to the solar system and some region around it, but it would still not be very useful. The key question is whether or not we can build an energy production machine in our basement that exploits some loophole about energy conservation in general relativity, and the ADM analysis says nothing about this.

The other approach is the non-covariant approach. In this approach, people define the energy– momentum pseudotensor for gravity, which looks like a tensor but does not transform like one. It is intended to encode the energy, momentum, and stress contained in the gravitational field. Books that take this approach include Landau and Lifshitz[3](#page-0-0) (LL); Misner, Thorne, and Wheeler[4](#page-0-0) (MTW); Weinberg[5](#page-0-0) (W) (Weinberg defines a different pseudotensor than LL and MTW); and Poisson and Will[6](#page-0-0) (PW). The first three of these only discuss the pseudotensor in the context of integrating it over all of spacetime, while the fourth describes the conservation of energy locally, relating the

<sup>1</sup>Spacetime and Geometry: An Introduction to General Relativity, by Sean M. Carroll (Addison-Wesley, 2004).

<sup>2</sup>General Relativity, by Robert M. Wald (University of Chicago Press, 1984).

<sup>3</sup>The Classical Theory of Fields, Revised Third Edition, by L. D. Landau and E. M. Lifshitz (Pergamon Press, 1971, first published in English 1951).

<sup>4</sup>Gravitation, by Charles W. Misner, Kip S. Thorne, and John Archibald Wheeler (W. H. Freeman and Company, 1970).

<sup>5</sup>Gravitation and Cosmology: Principles and Applications of the General Theory of Relativity, by Steven Weinberg (John Wiley & Sons, 1972).

<sup>6</sup>Gravity: Newtonian, Post-Newtonian, Relativistic, by Eric Poisson and Clifford M. Will (Cambridge University Press, 2014).

change in the total energy in any volume to the flow of energy through its boundary. We will follow the non-covariant approach. We begin by expanding the metric as

$$g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu} \,. \tag{24.2}$$

This looks like we might be doing perturbation theory, but we will not assume that hµν is small (at least not everywhere). Weinberg assumes that hµν → 0 at large distances, which is the same as the asymptotic flatness assumption:

> The physical significance of the Einstein equations can be clarified by writing them in an entirely equivalent form that, because not manifestly covariant, reveals their relation to the wave equations of elementary particle physics. Let us adopt a coordinate system that is quasi-Minkowskian, in the sense that the metric gµν approaches the Minkowski metric ηµν at great distances from the finite material system under study.

—Weinberg, p. 165.

Note how Weinberg extolls the virtues of sometimes avoiding manifest covariance, in contrast to all the other authors mentioned in this lecture.

We can then expand Rµκ in a power series in hµν, yielding

$$R_{\mu\kappa} = R_{\mu\kappa}^{(1)} + R_{\mu\kappa}^{(2)} + \cdots$$
 (24.3)

Because this is not perturbation theory, we will have to use the whole series. We will not have to worry about the convergence of the series, however, as we will use it only to extract the first few terms of the expansion. We will then express the sum of all higher-order terms as the exact expression, minus the terms that have been extracted. We will raise and lower indices using η, rather than g, so that we can keep track of powers of hµν. Note that using η to raise and lower indices is a departure from the usual conventions, but it does not involve making any approximations. All our equations will be exact; wherever hµν is relevant, its contributions will be shown explicitly.

Next, we rewrite Einstein's equations as

$$R_{\mu\kappa}^{(1)} - \frac{1}{2} \eta_{\mu\kappa} R_{\lambda}^{(1)\lambda} = 8\pi G (T_{\mu\kappa} + t_{\mu\kappa}).$$
 (24.4)

On the left-hand side, we have what looks like the ordinary left-hand side of Einstein's equations, but only using the first term in the expansion of the Ricci tensor. The new term on the right contains all of the extra pieces that we didn't include on the left:

$$t_{\mu\kappa} = \frac{1}{8\pi G} \left[ R_{\mu\kappa}^{(1)} - \frac{1}{2} \eta_{\mu\kappa} R_{\lambda}^{(1)\lambda} - R_{\mu\kappa} + \frac{1}{2} g_{\mu\kappa} g^{\lambda\sigma} R_{\lambda\sigma} \right]. \tag{24.5}$$

This is the gravitational energy–momentum pseudotensor, a la Weinberg. The full energy–momentum tensor is then

$$\tau^{\nu\lambda} = \eta^{\nu\mu} \eta^{\lambda\kappa} (T_{\mu\kappa} + t_{\mu\kappa}). \tag{24.6}$$

We now follow Weinberg's comments regarding the energy–momentum pseudotensor.

(A) Note that the first term in the expansion of the Ricci tensor satisfies a linearized Bianchi identity:

$$\frac{\partial}{\partial x^{\nu}} \left[ R^{(1)\nu\lambda} - \frac{1}{2} \eta^{\nu\lambda} R_{\mu}^{(1)\mu} \right] = 0.$$
 (24.7)

The full Bianchi identity would have a covariant derivative and the full metric in place of the partial derivative and η νλ .

This implies the conservation law

<span id="page-106-1"></span>
$$\frac{\partial}{\partial x^{\nu}} \tau^{\nu\lambda} = 0. {24.8}$$

We can then define the total four-momentum to be

$$P^{\lambda} \equiv \int_{V} \tau^{0\lambda} \, \mathrm{d}^{3} x \,. \tag{24.9}$$

<span id="page-106-0"></span>It follows that

$$\frac{\mathrm{d}P^{\lambda}}{\mathrm{d}t} = -\int_{S} \tau^{i\lambda} n_{i} \,\mathrm{d}S. \tag{24.10}$$

where S = ∂V is the boundary of V , n<sup>i</sup> is the unit normal to S ( P <sup>i</sup> nin<sup>i</sup> = 1), and dS is the area element. The interpretation is that P λ is a conserved energy–momentum "vector" (Since we referred to τ νλ as a pseudotensor, it might make sense to call this a "pseudovector," but that terminology is already used elsewhere in physics).

It is worthwhile to also discuss the Landau–Lifshitz pseudotensor, which is different from Weinberg's. LL begin by defining

$$h^{\mu\nu\lambda} \equiv \frac{1}{16\pi G} \frac{\partial}{\partial x^{\sigma}} \left[ (-g) \left( g^{\mu\nu} g^{\lambda\sigma} - g^{\mu\lambda} g^{\nu\sigma} \right) \right]. \tag{24.11}$$

Note that this is antisymmetric in ν, λ. In terms of this object, they define t µν by the equation

$$(-g)(T^{\mu\nu} + t^{\mu\nu}) = \frac{\partial h^{\mu\nu\lambda}}{\partial x^{\lambda}}.$$
 (24.12)

Einstein's equations are assumed to hold, so T µν can be expressed in terms of Rµν, allowing t µν to be expressed entirely in terms of the metric and its derivatives. By construction, this satisfies

$$\partial_{\nu} \left[ \frac{\partial h^{\mu\nu\lambda}}{\partial x^{\lambda}} \right] = 0, \qquad (24.13)$$

by the antisymmetry of h µνλ in ν, λ. With some calculation, one can see that in a locally inertial frame, t µν vanishes. Thus, t µν vanishes when gravity is absent (in the sense that gµν = ηµν and ∂λgµν = 0), and can be added to the energy–momentum tensor of matter to get something that is conserved.

We now return to the discussion of Weinberg's pseudotensor, and ask a controversial question. Can Eq. [\(24.10\)](#page-106-0) be applied to any arbitrary finite volume, or should it only be applied to an integral over all of an asymptotically flat spacetime? Weinberg only uses it for the entirety of an asymptotically flat spacetime, as described in the quotation above. LL state

The integration in (101.9) [equivalent to our Eq. [\(24.9\)](#page-106-1)] can be taken over any infinite hypersurface, including all of the three-dimensional space.

—Landau & Lifshitz, p. 306.

They go on to say

Let us draw around the masses under consideration a region of space sufficiently large so that outside of it we may say that there is no gravitational field. In the course of time, this region cuts out a "channel" in four-dimensional space-time. Outside of this channel there is no field, so that four-space is flat. Because of this we must, when calculating the energy and momentum of the field, choose a four-dimensional reference system such that outside the channel it goes over into a Galilean system and all the t ik vanish.

—Landau & Lifshitz, pp. 307–308.

MTW emphatically state that the spacetime must be asymptotically flat:

The spacetime must be asymptotically flat if there is to be any possibility of defining energy and angular momentum. Only then can linearized theory be applied; and only on the principle that linearized theory applies far away can one justify using the flux integrals (20.9) [equivalent to Eq. [\(25.9\)](#page-111-0) below, including the analogous equation for angular momentum] in the full nonlinear theory. Nobody can compel a physicist to move in close to define energy and angular momentum. He has no need to move in close; and he may have compelling motives not to: the internal structure of the sources may be inaccessible, incomprehensible, uninteresting, dangerous, expensively distant, or frightening. This requirement for far-away flatness is a remarkable feature of the flux integrals (20.9); it is also a decisive feature.

Misner, Thorne, & Wheeler, p. 463.

Unlike the previous three, PW do not insist that this equation only be used for integration over all of an asymptotically flat spacetime:

Because they involve a partial-derivative operator, the differential identities of Eq. (6.8),

$$\partial_{\beta} \left[ (-g) \left( T^{\alpha\beta} + t_{\rm LL}^{\alpha\beta} \right) \right] = 0,$$
 (6.8)

can immediately be turned into integral identities. We consider a three-dimensional region V , a fixed (time-independent) domain of the spatial coordinates x j , bounded by a two-dimensional surface S. We assume that V contains at least some of the matter (so that T αβ is non-zero somewhere within V ), but that S does not intersect any of the matter (so that T αβ = 0 everywhere on S).

Poisson & Will, p. 295.

We now discuss the lecturer's opinions on this matter:

- 1. Equation [\(24.10\)](#page-106-0) holds in any coordinate system, despite the fact that it is not a tensorial equation. The reason that is usually given to prefer tensor equations is that if a tensor equation is valid in one coordinate system, then it is valid in all coordinate systems. While Eq. [\(24.10\)](#page-106-0) is not a tensor equation, it nonetheless shares with tensor equations this important property.
- 2. We need to expect that energy depends on the coordinates in a complicated way. For instance, for any point in space, we can choose coordinates that are locally inertial at that point, which seemingly allows us to make the energy density of the gravitational

field vanish at any point simply by a change of coordinates. The LL pseudotensor was constructed so that it vanishes at a point where the metric is locally inertial, although this is not true of Weinberg's pseudotensor because it includes second derivatives of the metric. However, Weinberg's pseudotensor is still dramatically affected by such coordinate transformations.

Furthermore, a system of particles can be at rest in some coordinate system, but in some other coordinate system each particle can move in its own pattern. If we want the total energy to look conserved from outside the system, then the energy density must depend on the metric in a way that compensates for the changes in the kinetic energies of the particles from these coordinate changes.

- 3. If we do decide we can apply Eq. [\(24.10\)](#page-106-0) locally, then once we fix the choice of coordinates, this equation answers the key question: we cannot build an energy production machine that freely produces energy. Eq. [\(24.10\)](#page-106-0) implies that if energy, as defined by the volume integral, is produced in a volume V , that change must be reflected by a flow of energy into the region across its boundary S, as given by the surface integral. This lecturer sees no reason why the lack of covariance should cause us to doubt this conclusion.
- (B) We can also discuss the conservation of angular momentum. Because ∂µτ µν = 0 and τ µν is symmetric, the object

$$M^{\mu\nu\lambda} \equiv \tau^{\mu\lambda} x^{\nu} - \tau^{\mu\nu} \lambda \tag{24.14}$$

is conserved,

$$\partial_{\mu}M^{\mu\nu\lambda} = 0. (24.15)$$

Note that Mµνλ is antisymmetric in ν, λ. We can then define

$$J^{\nu\lambda} \equiv \int_{V} d^{3}x \ M^{0\nu\lambda} = -J^{\lambda\nu} \,. \tag{24.16}$$

This implies that

$$\frac{\mathrm{d}J^{\nu\lambda}}{\mathrm{d}t} = -\int_{S} M^{i\nu\lambda} n_i \,\mathrm{d}S. \qquad (24.17)$$

The spatial components J ij are related to the angular momenta, J ij = ijkJ k . What about the other components? We have

$$J^{i0} = \int_{V} d^{3}x \ M^{0i0} = \int_{V} d^{3}x \ \left[\tau^{00}x^{i} - \tau^{0i}t\right].$$
 (24.18)

We define

$$\langle x^i \rangle = \frac{\int_V d^3 x \, T^{00} x^i}{\int_V d^3 x \, T^{00}} \,,$$
 (24.19)

which can be described as the center of energy, or center of mass. In terms of this quantity, we can write

$$J^{i0} = P^0 \left[ \langle x^i \rangle - \frac{P^i}{P^0} t \right]. \tag{24.20}$$

This J i0 is a peculiar conserved quantity in that it is defined in a way that explicitly depends on time, but its value is independent of time. Its time-independent value tells us how to find the position of the center of energy at any time, if P µ is also known. The significance of J i0 is less well-recognized in textbooks, with W in particular commenting

These components have no clear physical significance, and in fact can be made to vanish if we fix the origin of coordinates to coincide with the 'center of energy' at t = 0, that is, if at t = 0 the moment ´ x iT <sup>00</sup> d <sup>3</sup>x vanishes.

—Weinberg, p. 47.

# 25 Lecture 25 (May 17, 2017)

## 25.1 The Energy–Momentum Pseudotensor

We now continue our discussion of the energy–momentum pseudotensor for gravitation, following Weinberg's comments.

(C) If τµκ is written as a power series in hµν, it starts at second order. This is analogous to the situation with electromagnetism, where the energy–momentum tensor is given by

$$T_{\rm EM}^{\mu\nu} = F^{\mu\lambda} F^{\nu}_{\ \lambda} - \frac{1}{4} \eta^{\mu\nu} F^{\lambda\sigma} F_{\lambda\sigma} \,. \tag{25.1}$$

For E&M, the energy–momentum tensor stops at second order, but for gravitation there are higher order terms as well, reflecting the fact that gravitational fields have self-interactions.

- (D) Note that while tµκ, τ νλ, and Mµνλ are not generally covariant, they are Lorentz covariant. The formalism of GR allows general coordinate changes (diffeomorphisms), but the Lorentz transformations from special relativity are a subset of these, and for this subset the quantities tµκ, τ νλ, and Mµνλ all transform as Lorentz tensors.
- (E) For isolated systems, such as the Solar System, that behave like Newtonian gravity, where as r → ∞ we have hµν = O 1 r , then τµκ = O 1 r 4 , implying that the total energy converges.
- (F) According to Weinberg, τ νλ is exactly what one would measure:

By its construction, τ νλ is clearly the energy–momentum "tensor" we determine when we measure the gravitational field produced by any system. Indeed, there are many possible definitions of the energy–momentum "tensor" of gravitation that share most of the good properties of our tµκ (these definitions are usually based on the action principle; see Chapter 12), but τµκ is specially picked out by its role in (7.6.3),

$$R_{\mu\kappa}^{(1)} - \frac{1}{2} \eta_{\mu\kappa} R_{\lambda}^{(1)} = -8\pi G [T_{\mu\kappa} + t_{\mu\kappa}],$$
 (7.6.3)

as part of the source of hµν.

—Weinberg, p. 168.

Apparently Weinberg is saying that by making detailed geometric and timing measurements we can determine hµν(x), in a chosen coordinate system, and then from Eq. (7.6.3) we can determine tµκ. Misner, Thorne, and Wheeler, however, make a directly contradictory statement:

Moreover, "local gravitational energy–momentum" has no weight. It does not curve space. It does not serve as a source term on the righthand side of Einstein's field equations. It does not produce any relative geodesic deviation of two nearby world lines that pass through the region of space in question. It is not observable.

—Misner, Thorne, & Wheeler, p. 467.

This lecturer finds this statement of MTW to be a little unclear. The geodesic deviation equation we discussed previously (see Lecture 13) was

$$\frac{\mathrm{D}^2 S^{\mu}}{\mathrm{d}\tau^2} = R^{\mu}_{\ \nu\rho\sigma} T^{\nu} T^{\rho} S^{\sigma} \,. \tag{25.2}$$

The Riemann tensor clearly includes the nonlinear parts of the curvature that appear in the energy–momentum pseudotensor, which implies that the energy–momentum pseudotensor does cause geodesic deviation. Perhaps MTW were thinking of the Raychaudhuri equation (see Lectures 13 and 14)

$$\frac{\mathrm{d}\theta}{\mathrm{d}\tau} = -\frac{1}{3}\theta^2 - \sigma_{\mu\nu}\sigma^{\mu\nu} + \omega_{\mu\nu}\omega^{\mu\nu} - R_{\lambda\sigma}T^{\lambda}T^{\sigma}, \qquad (25.3)$$

where only Rλσ appears, rather than the full Riemann tensor. Since Rλσ vanishes if Tµν does (see Eq. [\(25.25\)](#page-114-0) below), if one were limited to measuring only dθ/ dτ one would see no effects of gravity in a region that did not contain matter. But there is no reason for such a limitation. It is hard to know what to conclude when the world's experts disagree, but this lecturer thinks that Weinberg is more likely to be on the right side of this issue.

(G) To discuss the energy–momentum pseudotensor, we have written Einstein's equations in the form

$$R^{(1)\nu\lambda} - \frac{1}{2}\eta^{\nu\lambda}R^{(1)\mu}_{\ \mu} = 8\pi G \tau^{\nu\lambda}.$$
 (25.4)

Note that although this is written using an expansion, it is still an exact equation. The (linearized) Bianchi identity says that the divergence of the left-hand side of this equation vanishes, which means we can write the left-hand side in the form

$$R^{(1)\nu\lambda} - \frac{1}{2}\eta^{\nu\lambda}R^{(1)\mu}_{\quad \mu} \equiv \frac{\partial}{\partial x^{\rho}}Q^{\rho\nu\lambda}, \qquad (25.5)$$

where Qρνλ is antisymmetric in ρ ↔ ν. The form of the right-hand side guarantees that the divergence vanishes,

$$\frac{\partial}{\partial x^{\nu}} \frac{\partial}{\partial x^{\rho}} Q^{\rho\nu\lambda} , \qquad (25.6)$$

because the partial derivatives commute, but Qρνλ is antisymmetric in ρ ↔ ν.

We can explicitly determine Qρνλ ,

$$Q^{\rho\nu\lambda} = -\frac{1}{2} \left[ \frac{\partial h^{\mu}_{\ \mu}}{\partial x_{\nu}} \eta^{\rho\lambda} - \frac{\partial h^{\mu\nu}}{\partial x^{\mu}} \eta^{\rho\lambda} + \frac{\partial h^{\nu\lambda}}{\partial x_{\rho}} - (\rho \leftrightarrow \nu) \right]. \tag{25.7}$$

Note that the indices are raised and lowered with ηµν.

This guarantees that

$$\frac{\partial \tau^{\nu\lambda}}{\partial x^{\nu}} = 0. {(25.8)}$$

We can then use Stokes' theorem (in this context, also called the divergence theorem, or Gauss's theorem) to express the conserved four-momentum "vector" as a surface integral:

<span id="page-111-0"></span>
$$P^{\lambda} = -\frac{1}{8\pi G} \int_{V} \frac{\partial Q^{\rho 0\lambda}}{\partial x^{\rho}} d^{3}x$$

$$= -\frac{1}{8\pi G} \int_{V} \frac{\partial Q^{i0\lambda}}{\partial x^{i}} d^{3}x$$

$$= -\frac{1}{8\pi G} \int_{S} Q^{i0\lambda} n_{i} dS.$$
(25.9)

In particular, the total energy is

$$P^{0} = -\frac{1}{16\pi G} \int_{S} \left\{ \frac{\partial h_{jj}}{\partial x^{i}} - \frac{\partial h_{ij}}{\partial x^{j}} \right\} n_{i} \, dS, \qquad (25.10)$$

where we sum over indices appearing twice, regardless of whether they are upper or lower. For asymptotically flat spacetimes with S taken at infinity, this is exactly the ADM mass.

- (H) It can be proven that for nonsingular asymptotically flat spacetimes that are consistent with the dominant energy condition, P <sup>0</sup> ≥ 0, and P <sup>0</sup> = 0 only for Minkowski space.[7](#page-0-0) The dominant energy condition requires that for every timelike vector t µ , Tµνt µ t <sup>ν</sup> ≥ 0 and also that T µνt<sup>µ</sup> is either a timelike or null vector. The second condition can be interpreted qualitatively as the statement that energy cannot travel faster than light, as in the rest frame of t µ it reduces to the statement that T µ0 is timelike or null, and T µ0 is the energy flow vector. For a perfect fluid, the dominant energy condition reduces to ρ ≥ |p|, where ρ is the energy density and p is the pressure.
- (I) For asymptotically flat spacetimes, under any coordinate transformation that maintains explicitly asymptotic flatness, P µ transforms as a Lorentz vector.
- (J) If matter is divided into distinct subsystems, which are sufficiently isolated so that the space in between is essentially flat, then

$$P_{\text{total}}^{\mu} = \sum_{n} P_{(n)}^{\mu} \,.$$
 (25.11)

(K) This is an extra comment due to the lecturer, regarding closed universes. Landau and Lifshitz note that the total electric charge and the total four-momentum P i (LL use i for a fourdimensional index) must be zero in a closed universe:

It is interesting to note that in a closed space the total electric charge must be zero. Namely, every closed surface in a finite space encloses on each side of itself a finite region of space. Therefore the flux of the electric field through this surface is equal, on the one hand, to the total charge located in the interior of the surface, and on the other hand to the total charge outside of it, with opposite sign. Consequently, the sum of the charges on the two sides of the surface is zero.

Similarly, from the expression (101.14) for the four-momentum in the form of a surface integral there follows the vanishing of the total four-momentum P <sup>i</sup> over all space. Thus the definition of the total four-momentum loses its meaning, since the corresponding conservation law degenerates into the empty identity 0 = 0.

Landau & Lifshitz, p. 335.

<sup>7</sup>R. Shoen and S.-T. Yau, "Proof of the Positive Mass Theorem. II," Commun. Math. Phys. 79, 231–260 (1981); E. Witten, "A New Proof of the Positive Energy Theorem," Commun. Math. Phys. 80, 381–402 (1981).

These issues are also controversial, with MTW saying the opposite:

There is no such thing as "the energy (or angular momentum, or charge) of a closed universe," according to general relativity, and this for a simple reason. To weigh something one needs a platform on which to stand to do the weighing.

—Misner, Thorne, & Wheeler, p. 457.

For the case of electric charge, this lecturer finds LL's argument totally convincing: the total charge in a closed universe must be zero, essentially because the flux lines associated with Gauss's law have no place to escape. Furthermore, the statement that the total charge is zero is not an empty identity 0 = 0. Rather, it is a nontrivial statement that if one measures a charge Q in one region of a closed universe, one can predict that the total charge in the complementary region is −Q.

The lecturer suspects that the corresponding statements for energy are also valid, but here it is not completely clear. Note that the energy of gravity is generically negative, which allows the possibility of zero total energy even when the energy of matter is always positive. To discuss a closed universe with nonsingular coordinates, one needs at least two patches. For electric charges and electric fields, all quantities have proper tensorial definitions, so in LL's argument one knows for sure that the flux across the surface will have a coordinate-independent value which must therefore have the same magnitude when computed in the coordinate systems on either side. For the energy–momentum pseudotensor of gravity, however, it is not clear—at least to this lecturer—if the same conclusion applies. But if the overlap can be treated in a way that guarantees the equality of the flux as measured in each coordinate system, then there would be a meaningful statement that the total energy of a closed universe must be zero, and it would be nontrivial, in the same sense as the statement about charge. It would mean that if one measured the total energy in one region of a closed universe, one could predict that the total energy in the complementary region would cancel it.

While it is unclear whether the total energy of a closed universe is zero, or meaningless, it is clear that total energy does not impose any constraints on the evolution of closed universes. By looking at the Friedmann equations that describe homogeneous isotropic universes, one can see that if one allows the equation of state p(ρ) to be arbitrary, then any closed universe can evolve into any other. Furthermore, it is also clear in this limited context that there is a nontrivial constraint that can be interpreted as a statement that the energy is required to be zero. If the metric is written as

$$ds^{2} = -dt^{2} + a^{2}(t) \left\{ \frac{dr^{2}}{1 - r^{2}} + r^{2} (d\theta^{2} + \sin^{2}\theta \ d\phi^{2}) \right\},$$
 (25.12)

then the first-order Friedmann equation is

$$\left(\frac{\dot{a}}{a}\right)^2 = \frac{8\pi}{3}G\rho - \frac{1}{a^2}.$$
 (25.13)

This can be made to more strongly resemble an energy conservation equation by defining

$$M \equiv 2\pi^2 \rho a^3 \,, \tag{25.14}$$

where 2π 2a 3 is the volume, and multiplying the equation by M a<sup>2</sup> and bringing all the terms to one side:

$$M + M\dot{a}^2 - \frac{4}{3\pi} \frac{GM^2}{a} = 0. {(25.15)}$$

We can regard these three terms as measures of the rest energy, kinetic energy, and potential energy of the closed universe, and knowledge of any two will clearly determine the third.

#### 25.2 Gravitational Radiation

Gravitational radiation describes a wave of gravity traveling through empty space. An interesting first question is the following: how many degrees of freedom does gravity contain on its own? This is a tricky question because of gauge invariance issues.

An object with a single (real) degree of freedom is a single (real) scalar field. This might obey, for example, the Klein–Gordon equation  $(\Box + m^2)\phi = 0$ , where  $\Box = \nabla_{\mu}\nabla^{\mu}$ . Since the equation is second order in time (i.e., the highest time derivative is  $\partial^2/\partial t^2$ ), the solution is completely determined by specifying two initial condition functions,

$$\phi(\vec{x}, t = 0), \quad \frac{\partial \phi}{\partial t}(\vec{x}, t = 0).$$
 (25.16)

So we say that one degree of freedom corresponds to two initial condition functions.

For gravity in empty space, we have  $G_{\mu\nu} = 0$ , which are ten equations that are second order in time. Thus, we initially imagine imposing 20 initial condition functions,

$$g_{\mu\nu}(\vec{x}, t=0), \quad \frac{\partial g_{\mu\nu}}{\partial t}(\vec{x}, t=0),$$
 (25.17)

so it looks like we have 10 degrees of freedom, but this is overcounting. The overcounting is due to constraint equations and gauge invariance.

If one examines the four equations  $G_{0\mu}=0$ , one finds that they contain no second time derivatives. These are therefore constraint equations, imposing four constraints on our freedom to choose the 20 functions described in Eq. (??). This leaves us with 20-4=16 functions specifying the initial conditions.

We further must consider the gauge symmetry, or invariance under general coordinate transformations  $x^{\mu} \to x^{\mu'}(x)$ . The metric changes as

$$g_{\mu'\nu'}(x') = \frac{\partial x^{\lambda}}{\partial x^{\mu'}} \frac{\partial x^{\sigma}}{\partial x^{\nu'}} g_{\lambda\sigma}(x). \qquad (25.18)$$

Which of these are relevant to the initial conditions at t = 0? We have

$$g_{0'0'}(x') = \frac{\partial x^{\lambda}}{\partial x^{0'}} \frac{\partial x^{\sigma}}{\partial x^{0'}} g_{\lambda\sigma}(x) , \qquad (25.19)$$

which includes the first time derivative of the gauge transformation. We then also have

$$\frac{\partial g_{0'0'}}{\partial x^{0'}}(x') = \frac{\partial^2 x^{\lambda}}{\partial (x^{0'})^2} \frac{\partial x^{\sigma}}{\partial x^{0'}} g_{\lambda\sigma}(x) + \cdots$$
 (25.20)

Thus there are 12 gauge transformation functions— $x^{\mu'}(x')$ ,  $\frac{\partial x^{\lambda}}{\partial x^{0'}}(x')$ , and  $\frac{\partial^2 x^{\lambda}}{\partial (x^{0'})^2}(x')$ —that modify the initial value functions, each reducing the number of physically meaningful initial condition functions by one.

This leaves us with 16-12=4 functions, which implies 2 degrees of freedom. This means that gravitational waves, like electromagnetic waves, will have two polarizations.

We will now expand

$$g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu} \,, \tag{25.21}$$

with  $|h_{\mu\nu}| \ll 1$ , treating the metric perturbatively. We will raise and lower indices with  $\eta_{\mu\nu}$ , and we will take  $\Box = \partial^{\mu}\partial_{\mu}$ . The Einstein equations are

$$R_{\mu\nu} - \frac{1}{2}g_{\mu\nu}R = 8\pi G T_{\mu\nu} \,. \tag{25.22}$$

If we take the trace of both sides of this equation, we find

$$R - \frac{1}{2} \cdot 4R = 8\pi G T^{\mu}_{\ \mu} \ , \tag{25.23}$$

implying

$$R = -8\pi G T^{\mu}_{\ \mu} \ , \tag{25.24}$$

<span id="page-114-0"></span>which we can plug back into the original Einstein equations to arrive at the trace-reversed Einstein equations,

$$R_{\mu\nu} = 8\pi G \left( T_{\mu\nu} - \frac{1}{2} g_{\mu\nu} T^{\lambda}_{\lambda} \right). \tag{25.25}$$

Expanding  $R_{\mu\nu}$  in terms of  $h_{\mu\nu}$ , this becomes

$$\Box h_{\mu\nu} - \frac{\partial^2}{\partial x^{\lambda} \partial x^{\mu}} h^{\lambda}_{\ \nu} - \frac{\partial^2}{\partial x^{\lambda} \partial x^{\nu}} h^{\lambda}_{\ \mu} + \frac{\partial^2}{\partial x^{\mu} \partial x^{\nu}} h^{\lambda}_{\ \lambda} = -16\pi G \left( T_{\mu\nu} - \frac{1}{2} \eta_{\mu\nu} T^{\lambda}_{\ \lambda} \right). \tag{25.26}$$

But it is still possible to make gauge transformations, which we will need to understand. Since we are interested only in infinitesimal values of  $h_{\mu\nu}$ , we need consider only infinitesimal coordinate transformations. Departing from Carroll's notation for indices, we write an infinitesimal transformation of the coordinates as

$$x^{\mu} \to x'^{\mu} = x^{\mu} + \epsilon^{\mu}(x)$$
. (25.27)

Inverting, we have to first order in  $\epsilon^{\mu}$  that

$$x^{\mu} = x'^{\mu} - \epsilon^{\mu}(x'). \tag{25.28}$$

From

$$g'_{\mu\nu} = \frac{\partial x^{\lambda}}{\partial x'^{\mu}} \frac{\partial x^{\sigma}}{\partial x'^{\nu}} g_{\lambda\sigma} , \qquad (25.29)$$

we then conclude that

$$h'_{\mu\nu} = h_{\mu\nu} - \frac{\partial \epsilon_{\mu}}{\partial x^{\nu}} - \frac{\partial \epsilon_{\nu}}{\partial x^{\mu}}.$$
 (25.30)

This transformation represents a change in coordinates, but no changes in physics.

We choose harmonic coordinates, in which

$$g^{\mu\nu}\Gamma^{\lambda}_{\mu\nu} = 0\,, (25.31)$$

which gives to first order

$$\frac{\partial}{\partial x^{\mu}}h^{\mu}_{\phantom{\mu}\nu} = \frac{1}{2}\frac{\partial}{\partial x^{\nu}}h^{\mu}_{\phantom{\mu}\mu}. \tag{25.32}$$

These are four gauge conditions, one for each value of the free index  $\nu$ .

This coordinate choice allows us to write the Einstein equations in the simple form

$$\Box h_{\mu\nu} = -16\pi G \left( T_{\mu\nu} - \frac{1}{2} \eta_{\mu\nu} T^{\lambda}_{\ \lambda} \right). \tag{25.33}$$

This has a solution in terms of retarded time,

$$h_{\mu\nu}(\vec{x},t) = 4G \int d^3x' \frac{S_{\mu\nu}(\vec{x}',t-|\vec{x}-\vec{x}'|)}{|\vec{x}-\vec{x}'|}, \qquad (25.34)$$

where

$$S_{\mu\nu} \equiv T_{\mu\nu} - \frac{1}{2} \eta_{\mu\nu} T^{\lambda}_{\ \lambda} \ . \tag{25.35}$$

When we look inside the source in E&M, the first term in the multipole expansion of the source is a dipole. But, we can't do this with mass, because there is no positive/negative charge of mass; all mass has positive "charge," and the center of mass of any complete, isolated system never undergoes acceleration. Thus, there is no dipole radiation coming from oscillating mass. The first term in the multipole expansion of the source is therefore the quadrupole, which is usually the only contribution worth considering.

In empty space, we have  $\Box h_{\mu\nu} = 0$ . The plane wave solutions are

$$h_{\mu\nu}(x) = e_{\mu\nu}e^{ik_{\lambda}x^{\lambda}} + e_{\mu\nu}^{*}e^{-ik_{\lambda}x^{\lambda}}$$
 (25.36)

Here,  $k_{\lambda}$  is the wavenumber of the solution, and  $e_{\mu\nu}$  is the polarization tensor. We now want to impose the equation of motion  $\Box h_{\mu\nu} = 0$ , which implies that  $k_{\lambda}k^{\lambda} = 0$ . This tells us that the gravitational waves travel at the speed of light. The harmonic condition implies that

<span id="page-115-1"></span><span id="page-115-0"></span>
$$k_{\mu}e^{\mu}_{\ \nu} = \frac{1}{2}k_{\nu}e^{\mu}_{\ \mu}. \tag{25.37}$$

We now consider gauge transformations that preserve the form of the plane wave solution, Eq. (25.36), and also the gauge condition, Eq. (25.37). These are of the form

$$\epsilon^{\mu}(x) = i\epsilon^{\mu}e^{ik_{\lambda}x^{\lambda}} - i\epsilon^{*\mu}e^{-ik_{\lambda}x^{\lambda}}, \qquad (25.38)$$

for any values of the four complex constants  $\epsilon^{\mu}$ . Applying such a gauge transformation, only the polarization tensor changes,

<span id="page-115-2"></span>
$$e'_{\mu\nu} = e_{\mu\nu} + k_{\mu}\epsilon_{\nu} + k_{\nu}\epsilon_{\mu}. \tag{25.39}$$

<span id="page-115-3"></span>![](_page_115_Picture_16.jpeg)

Figure 22: The effect of a gravitational wave with polarization  $e_{11} = -e_{22}$  is to distort a circle of test particles into ellipses oscillating in a vertical and horizontal pattern.

Since  $e_{\mu\nu}$  is symmetric, we started with 10 linearly independent (complex) values. These were restricted by the four gauge-fixing constraints of Eq. (25.37), and are subject to modification or elimination by four gauge transformations, Eq. (25.39). This leaves two linearly independent choices, corresponding again to two polarizations, as we deduced when we considered the full Einstein equations. The fact that the  $\epsilon_{\mu\nu}$  are complex corresponds to the two-initial functions

<span id="page-116-0"></span>![](_page_116_Picture_3.jpeg)

Figure 23: The effect of a gravitational wave with polarization e<sup>12</sup> = e<sup>21</sup> is to distort a circle of test particles into oscillating ellipses, at 45◦ relative to Figure [22.](#page-115-3)

per degree of freedom that we found earlier. Keeping the gauge-fixing constraints and the gauge invariance in mind, the two independent solutions can be written as

$$e_{11} = -e_{22}$$
, all others zero, (25.40)

and

$$e_{12} = e_{21}$$
, all others zero. (25.41)

These solutions represent the two independent polarizations of gravitational waves. All other solutions are gauge equivalent to linear combinations of these solutions.

The first solution is what Carroll calls the + solution. Figure 7.4 in Carroll, included here as Figure [22,](#page-115-3) shows the behavior of this solution in time. As time goes on, h<sup>11</sup> increases/decreases as h<sup>22</sup> decreases/increases. The second solution is what Carroll calls the − solution, which has the same behavior but rotated by 45◦ , as shown in Figure [23](#page-116-0) (Carroll's Figure 7.5).

We can ask how the polarization varies as we rotate the angle from which we are viewing the wave. If we imagine looking at the wave of Figure [22,](#page-115-3) we see that after rotating our head by 45◦ about an axis along the beam, perpendicular to the page, the polarization of the wave has changed to that of Figure [23.](#page-116-0) If we continue to a 90◦ rotation from the original, we come back to the polarization we started with, but 180◦ out of phase. At the instant when we would have seen a maximum extension in the vertical direction before we rotated, we now see a maximum extension in the horizontal direction. After rotating our head by 180◦ , the polarization pattern returns to the original. As we rotate our head a full 360◦ , the polarization of the gravitational wave goes through two complete cycles. If one does the analogous thought experiment for a plane polarized electromagnetic wave, one finds that the polarization goes through one full cycle as we rotate our head by 360◦ . For this reason the electromagnetic wave is said to have helicity 1, while the gravitational wave has helicity 2. When the theories are quantized, these properties imply that the photon has spin 1, and the graviton has spin 2.