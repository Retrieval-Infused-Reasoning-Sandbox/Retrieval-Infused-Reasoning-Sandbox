# Introductory lectures on lattice QCD at nonzero baryon number

## Gert Aarts

Department of Physics, College of Science, Swansea University, Swansea SA2 8PP, United Kingdom

E-mail: g.aarts@swan.ac.uk

Abstract. These lecture notes contain an elementary introduction to lattice QCD at nonzero chemical potential. Topics discussed include chemical potential in the continuum and on the lattice; the sign, overlap and Silver Blaze problems; the phase boundary at small chemical potential; imaginary chemical potential; and complex Langevin dynamics. An incomplete overview of other approaches is presented as well. These lectures are meant for postgraduate students and postdocs with an interest in extreme QCD. A basic knowledge of lattice QCD is assumed but not essential. Some exercises are included at the end.

Based on lectures delivered at the XIII International Workshop on Hadron Physics, Brazil, March 2015.

# 1. Introduction

Quantum Chromodynamics (QCD), describing the interaction between quarks and gluons, is formulated using only a few ingredients: it is an SU(3) gauge theory with six flavours of quarks, of which the lightest two are nearly massless. Yet, this results in an extremely rich theory, containing asymptotic freedom, confinement, chiral symmetry breaking, phase transitions, etc.

![](_page_0_Figure_9.jpeg)

<span id="page-0-0"></span>Figure 1. Sketch of the QCD phase diagram in the plane of temperature and baryon density.

Because QCD is strongly interacting at low energies, many interesting questions are not easily answerable. The questions relevant for these lectures concern the QCD phase diagram, i.e. the phase structure of strongly interacting matter, of which a sketch is presented in Fig. [1.](#page-0-0) Several phases are shown: the hadronic phase at low temperature and density, the quark-gluon plasma at high temperature, possible colour-superconducting phases for cold dense matter, and perhaps there exist other phases not indicated in this version of the phase diagram.

However, these lectures will not be about the phase diagram as such. Many good reviews are available where this is described in detail, see e.g. Refs. [\[1](#page-42-0)[–3\]](#page-42-1). Instead our focus is on a practical and concrete problem, which has been around for many years: namely why has the QCD phase diagram not yet been determined from first principles, and why is the standard nonperturbative approach, lattice QCD, not immediately applicable? Given these limitations, we then address what can be determined, and, importantly, what progress there is in evading this *status quo* altogether.

By definition these lectures are incomplete, limited by time and knowledge. Hence one may supplement them with e.g. the review talks presented at the annual Lattice conference [\[4](#page-42-2)[–10\]](#page-42-3), which are usually quite accessible. My goal is to provide a basis for new postgraduate students and postdocs in the field and hence I have refrained from including very recent material which is still in development. This is especially relevant for the material discussed towards the end.

These lectures are structured as follows:

- Sec. [2.](#page-2-0) Quantum statistical mechanics and the QCD partition function
- Sec. [3.](#page-3-0) Chemical potential in the continuum
- Sec. [4.](#page-6-0) Chemical potential on the lattice
- Sec. [5.](#page-7-0) Phase-quenching: sign, overlap and Silver Blaze problems
- Sec. [6.](#page-10-0) Phase boundary at small chemical potential
- Sec. [7.](#page-15-0) Imaginary chemical potential
- Sec. [8.](#page-23-0) Complex Langevin dynamics
- Sec. [9.](#page-28-0) Complex Langevin dynamics for gauge theories
- Sec. [10.](#page-32-0) Other approaches
- Sec. [11.](#page-35-0) Conclusion

Exercises

In the following section we start with a reminder of some basic concepts in quantum statistical mechanics and give the QCD partition function as a euclidean path integral. The sign problem at nonzero chemical potential is demonstrated. Chemical potential in the continuum and on the lattice are introduced in Secs. [3](#page-3-0) and [4,](#page-6-0) respectively, both for fermionic and bosonic fields. The Silver Blaze problem is first mentioned in Sec. [3](#page-3-0) as well. Some general remarks on the sign problem are contained in Sec. [5,](#page-7-0) including the Silver Blaze problem from the viewpoint of the Dirac operator. The transition from the confined hadronic phase to the deconfined quark-gluon plasma can be studied in detail using standard numerical methods for vanishing and small chemical potential. Given the ongoing heavy-ion collisions at the Relativistic Heavy-Ion Collider (RHIC) at BNL and the Large Hadron Collider (LHC) at CERN, this is of high phenomenological relevance. Methods applicable here are discussed in Sec. [6.](#page-10-0) At imaginary chemical potential the sign problem is absent and an intricate phase structure emerges, which is relevant for real chemical potential as well. This is discussed in detail in Sec. [7.](#page-15-0) At larger (real) chemical potential the sign problem prohibits the use of well-established methods. One approach which has seen some genuine progress in recent years is complex Langevin dynamics. In Secs. [8](#page-23-0) and [9](#page-28-0) we focus on the basics, since this is still very much a topic in development. Finally, several other approaches are briefly discussed in Sec. [10.](#page-32-0) The Appendices contain some exercises, with solutions. A basic knowledge of lattice field theory is useful but not essential, except perhaps in Sec. [9.](#page-28-0)

#### <span id="page-2-0"></span>2. Quantum statistical mechanics and the QCD partition function

We consider QCD at nonzero temperature and baryon density. The standard approach in statistical mechanics uses the grand canonical ensemble, where the system is kept at a finite temperature T in a spatial volume V [11]. Conserved quantities, such as baryon number, are coupled to a chemical potential  $\mu$ , and the grand canonical partition function is given by

$$Z = \operatorname{Tr} e^{-(H-\mu N)/T} = e^{-F/T},$$
 (2.1)

where H is the hamiltonian (we use  $\hbar = c = k_B = 1$ ). From the partition function, or free energy F, other thermodynamic quantities follow by differentiation with respect to T,  $\mu$ , etc. For instance, the conserved number (density) is determined by

$$\langle N \rangle = T \frac{\partial}{\partial \mu} \ln Z, \qquad \langle n \rangle = \frac{1}{V} \langle N \rangle, \qquad (2.2)$$

and fluctuations in the number density by the susceptibility

$$\langle \chi \rangle = \frac{1}{V} \left[ \langle N^2 \rangle - \langle N \rangle^2 \right] = \frac{\partial \langle n \rangle}{\partial \mu}.$$
 (2.3)

By studying the behaviour of these and other thermodynamic quantities as the external parameters are changed, the phase structure can be determined.

In QCD one may consider various conserved charges. For simplicity, let's take two flavours, up and down, with chemical potentials  $\mu_u, \mu_d$ . To obtain quark number, we choose the quark chemical potentials equal,  $\mu_u = \mu_d = \mu_q$ , such that

$$\langle n_q \rangle = \langle n_u \rangle + \langle n_d \rangle. \tag{2.4}$$

Note that baryon number is given by  $\langle n_B \rangle = \langle n_q \rangle / 3$  and that the baryon chemical potential equals  $\mu_B = 3\mu_q$ . One way to think about chemical potential is that it corresponds to the free energy required to add one particle to the system. This makes the relation  $\mu_B = 3\mu_q$  obvious.

Another possibility is to consider a nonzero isospin density. In that case, the chemical potentials are chosen as  $\mu_u = -\mu_d = \mu_{iso}$ , and the isospin density equals

$$\langle n_{\rm iso} \rangle = \langle n_u \rangle - \langle n_d \rangle.$$
 (2.5)

Finally, we might be interested in the electrical charge density and take  $\mu_u = \frac{2}{3}\mu_Q$ ,  $\mu_d = -\frac{1}{3}\mu_Q$ , such that the electrical charge density is given by

$$\langle n_Q \rangle = \frac{2}{3} \langle n_u \rangle - \frac{1}{3} \langle n_d \rangle.$$
 (2.6)

In these lectures we are interested in nonzero quark (or baryon) density and  $\mu$  will generically refer to quark chemical potential from now on.

Since QCD is strongly interacting in the regions of interest for the phase structure, i.e. where the transition from a hadron gas, or hadron plasma, to a quark-gluon plasma at high temperature or dense nuclear or quark matter at larger chemical potential and lower temperature occurs, it is necessary to use a nonperturbative approach. Lattice QCD provides such an approach in principle and is extremely successful at T>0 and  $\mu\sim 0$  (as well as of course at  $T=\mu=0$ ). However, a full determination of the QCD phase diagram requires numerical simulations in the entire  $T-\mu$  plane and this is where the stumbling block appears. Due to what is known as the sign problem, there is at present no first-principle determination of the QCD phase diagram, the main motivation for these lectures.

On the lattice the QCD partition function is written as an euclidean path integral,[1](#page-3-1)

<span id="page-3-2"></span>
$$Z = \int DU D\bar{\psi}D\psi e^{-S} = \int DU e^{-S_{\text{YM}}} \det M(\mu), \qquad (2.7)$$

where U denote the gauge links and ψ, ψ¯ the quark fields. The QCD action has the following schematic form

$$S = S_{\rm YM} + \int d^4x \,\bar{\psi} M\psi. \tag{2.8}$$

Here SYM is the Yang-Mills action, depending on U, and M denotes the fermion matrix, depending on U and the chemical potentials. Integrating over the quark fields yields the righthand side of Eq. [\(2.7\)](#page-3-2), which contains the determinant det M.

Now, in numerical simulations the integrand,

$$\rho(U) \sim e^{-S_{\rm YM}} \det M(\mu), \tag{2.9}$$

is interpreted as a (real and positive) probability weight such that configurations of gauge links can be generated, relying on importance sampling. However, at nonzero chemical potential the fermion determinant turns out to be not real and positive but complex,

<span id="page-3-4"></span>
$$[\det M(\mu)]^* = \det M(-\mu^*) \in \mathbb{C}, \tag{2.10}$$

as is reviewed below. As a result the weight ρ(U) is complex as well and standard numerical algorithms based on importance sampling are not applicable. As stated above, this is usually referred to as the sign problem, even though complex-phase problem would be more accurate. The goal of these lectures is to review these statements, as well as to discuss some partial or possibly complete solutions to the sign problem.

## <span id="page-3-0"></span>3. Chemical potential in the continuum

# *3.1. Fermions*

Let us consider noninteracting fermions, with the euclidean action,[2](#page-3-3)

$$S = \int_0^{1/T} d\tau \int d^3x \, \bar{\psi} \left( \gamma_\nu \partial_\nu + m \right) \psi. \tag{3.1}$$

Due to the global symmetry

$$\psi \to e^{i\alpha}\psi, \qquad \bar{\psi} \to \bar{\psi}e^{-i\alpha},$$
 (3.2)

fermion number is a conserved charge,

$$N = \int d^3x \, \bar{\psi} \gamma_4 \psi = \int d^3x \, \psi^{\dagger} \psi \qquad \Rightarrow \qquad \partial_{\tau} N = 0. \tag{3.3}$$

$$\gamma_{\nu}^{\dagger}=\gamma_{\nu}\quad \gamma_{5}^{\dagger}=\gamma_{5},\quad \{\gamma_{\mu},\gamma_{\nu}\}=2\delta_{\mu\nu},\quad \{\gamma_{\nu},\gamma_{5}\}=0,\quad \gamma_{5}^{2}=1.$$

<span id="page-3-1"></span><sup>1</sup> Note that I will not review the lattice formulation, see e.g. the textbooks [\[12,](#page-42-5) [13\]](#page-42-6). It suffices to know that it is formulated in terms of the links Uxν = e iaAxν , with Axν the vector potential and a the lattice spacing. The inverse temperature is given by the extent in the temporal direction, 1/T = aN<sup>τ</sup> , with N<sup>τ</sup> the number of time slices. We will often use 'lattice units', a ≡ 1.

<span id="page-3-3"></span><sup>2</sup> We use the following conventions:

To obtain the grand canonical partition function in the euclidean path integral formulation, we add the following term to the action,

<span id="page-4-0"></span>
$$\frac{\mu N}{T} = \frac{\mu}{T} \int d^3x \, \bar{\psi} \gamma_4 \psi = \int_0^{1/T} d\tau \int d^3x \, \mu \bar{\psi} \gamma_4 \psi, \tag{3.4}$$

which, after the inclusion of an abelian gauge field  $A_{\nu}$ , now reads

$$S = \int_0^{1/T} d\tau \int d^3x \, \bar{\psi} \left[ \gamma_{\nu} (\partial_{\nu} + iA_{\nu}) + \mu \gamma_4 + m \right] \psi = \int d^4x \, \bar{\psi} M \psi. \tag{3.5}$$

We can now make a few observations:

- $\mu$  appears in the same way as  $iA_4$ , i.e. as the imaginary part of the four-component of an abelian vector field. This will be important when chemical potential is introduced in the lattice formulation.
- The action is complex. This can be seen by the absence of ' $\gamma_5$  hermiticity'. At  $\mu = 0$  it is easy to check that

$$(\gamma_5 M)^{\dagger} = \gamma_5 M, \qquad M^{\dagger} = \gamma_5 M \gamma_5, \qquad (3.6)$$

leading to

$$\det M^{\dagger} = \det (\gamma_5 M \gamma_5) = \det M = (\det M)^*, \tag{3.7}$$

i.e. the determinant is real. On the other hand, when  $\mu \neq 0$  we find

$$M^{\dagger}(\mu) = \gamma_5 M(-\mu^*) \gamma_5, \tag{3.8}$$

resulting in Eq. (2.10) and a complex determinant.

- When the chemical potential is chosen to be purely imaginary, the determinant is real again. This has been exploited extensively and will be discussed below.
- For abelian gauge theories, the chemical potential can be removed by a simple gauge transformation of  $A_4$  (choose  $\mu$  imaginary and use analyticity). This is no longer true in SU(N) theories or for theories with more than one chemical potential.

It is important to realise that the sign problem not specific for fermions. In particular, it is not due to the Grassmann nature of fermions, since, after all, standard lattice simulations work well at zero chemical potential. Instead it arises from the complexity of the determinant (or the action) in the path integral weight, and as such it is also present in bosonic theories.

## 3.2. Bosons

To illustrate this, let us now consider a complex scalar field, with again a global symmetry  $\phi \to e^{i\alpha}\phi$ . The action is

$$S = \int d^4x \left( |\partial_{\nu} \phi|^2 + m^2 |\phi|^2 + \lambda |\phi|^4 \right), \tag{3.9}$$

and the conserved charge reads

$$N = \int d^3x \, i \left[\phi^* \partial_4 \phi - (\partial_4 \phi^*) \phi\right]. \tag{3.10}$$

In order to write down the euclidean path integral at nonzero  $\mu$  for this case, we have to revisit the derivation of the path integral with a bit more care than above [11]. We start from the partition function,

$$Z = \text{Tr}\,e^{-(H-\mu N)/T},$$
 (3.11)

and express the hamiltonian and conserved charge (densities) in terms of the canonical momenta  $\pi_1 = \partial_4 \phi_1, \pi_2 = \partial_4 \phi_2$ , where  $\phi = (\phi_1 + i\phi_2)/\sqrt{2}$ . For example, the charge now takes the form

$$N = \int d^3x \left(\phi_2 \pi_1 - \phi_1 \pi_2\right), \tag{3.12}$$

and the partition function reads

$$Z = \operatorname{Tr} e^{-(H-\mu N)/T} = \int D\phi_1 D\phi_2 \int D\pi_1 D\pi_2 \exp \int d^4x \Big[ i\pi_1 \partial_4 \phi_1 + i\pi_2 \partial_4 \phi_2 - \mathcal{H} + \mu(\phi_2 \pi_1 - \phi_1 \pi_2) \Big].$$
(3.13)

After integrating out the momenta, we find the following expression for the euclidean action

$$S = \int d^4x \left[ (\partial_4 + \mu)\phi^* (\partial_4 - \mu)\phi + |\partial_i \phi|^2 + m^2 |\phi|^2 + \lambda |\phi|^4 \right]$$
  
= 
$$\int d^4x \left[ |\partial_\nu \phi|^2 + (m^2 - \mu^2)|\phi|^2 + \mu(\phi^* \partial_4 \phi - \partial_4 \phi^* \phi) + \lambda |\phi|^4 \right].$$
(3.14)

We observe that the chemical potential appears again as an imaginary vector potential. In the second line, the linear term in  $\mu$  is purely imaginary, resulting in a complex action  $S^*(\mu) = S(-\mu^*)$ , while the quadratic term in  $\mu$  arose from integrating out the momenta and is absent in fermionic theories.

The bosonic theory is discussed in much more detail in Appendix A in the form of an exercise.

## <span id="page-5-0"></span>3.3. Towards the Silver Blaze problem

Consider a particle with mass m and a conserved charge at low temperature: as mentioned earlier,  $\mu$  is the change in free energy when a particle carrying the conserved charge is added, i.e. the energy cost for adding one particle. Hence

- if  $\mu < m$ : not enough energy available to create a particle  $\Rightarrow$  no change in the groundstate;
- if  $\mu > m$ : plenty of energy available  $\Rightarrow$  the groundstate has a nonzero density of particles.

Hence it follows from simple statistical mechanics that at zero temperature the density becomes nonzero (the 'onset') at  $\mu = \mu_c \equiv m$ . We will now demonstrate this for free fermions.

The standard expression for the logarithm of the partition function for a free relativistic fermion gas is given by [11]

$$\ln Z = 2V \int \frac{d^3 p}{(2\pi)^3} \left[ \beta \omega_{\mathbf{p}} + \ln \left( 1 + e^{-\beta(\omega_{\mathbf{p}} - \mu)} \right) + \ln \left( 1 + e^{-\beta(\omega_{\mathbf{p}} + \mu)} \right) \right], \tag{3.15}$$

where  $\omega_{\mathbf{p}} = \sqrt{\mathbf{p}^2 + m^2}$  and  $\beta = 1/T$ . The 2 arises from spin, the first term is the zero-point energy and the other terms represent particles and anti-particles at nonzero temperature and chemical potential. The density is given by

$$\langle n \rangle = \frac{T}{V} \frac{\partial \ln Z}{\partial \mu} = 2 \int \frac{d^3 p}{(2\pi)^3} \left[ \frac{1}{e^{\beta(\omega_{\mathbf{p}} - \mu)} + 1} - \frac{1}{e^{\beta(\omega_{\mathbf{p}} + \mu)} + 1} \right]. \tag{3.16}$$

Let us consider the low-temperature limit,  $T \to 0$ . We have to distinguish two cases:

•  $\mu < m$ : the '1' in the denominator of the Fermi-Dirac distribution can be ignored and

$$\langle n \rangle \sim 2 \int \frac{d^3 p}{(2\pi)^3} \left[ e^{-\beta(\omega_{\mathbf{p}} - \mu)} - e^{-\beta(\omega_{\mathbf{p}} + \mu)} \right] \to 0.$$
 (3.17)

Particles and antiparticles are thermally excited but Boltzmann suppressed.

•  $\mu > m$ : in this case  $\mu$  can be larger than  $\omega_{\mathbf{p}}$  and the first Fermi-Dirac distribution becomes a step function at T = 0,

$$\langle n \rangle \sim 2 \int \frac{d^3 p}{(2\pi)^3} \Theta(\mu - \omega_{\mathbf{p}}) = \frac{(\mu^2 - m^2)^{3/2}}{3\pi^2} \Theta(\mu - m).$$
 (3.18)

We find a nonzero density, with the onset at  $\mu = m$ , as expected.

At strictly zero temperature, we note therefore that thermodynamic quantities (free energy, pressure,  $\langle n \rangle, \chi, \ldots$ ) are independent of  $\mu$  when  $\mu < \mu_c$ , i.e. as long as  $\mu$  is below the mass of the lightest particle in the channel with the appropriate quantum numbers. How this independence emerges in numerical simulations is nontrivial and has been dubbed the *Silver Blaze* problem [14], to be discussed further below. Finally, we note that the same holds for bosons, see Appendix A for details.

## <span id="page-6-0"></span>4. Chemical potential on the lattice

We now discuss how to add chemical potential to the action on the lattice. Naively adding  $\mu\bar{\psi}\gamma_4\psi$ , see Eq. (3.4), leads to  $\mu$ -dependent ultraviolet divergences [15]. However, this is not expected on general grounds, since the presence of temperature or chemical potential should not affect renormalisation at short distances. Instead, we better follow the observations made in the continuum:

- the chemical potential couples to the conserved charge;
- it appears as the imaginary part of the four-component of an abelian vector field.

We consider a lattice action, where the derivatives are replaced by simple nearest-neighbour terms. The terms in the action from which the conserved lattice current follows, the so-called hopping terms, are<sup>3</sup>

<span id="page-6-3"></span>
$$S \sim \bar{\psi}_x U_{x\nu} \gamma_\nu \psi_{x+\nu} - \bar{\psi}_{x+\nu} U_{x\nu}^{\dagger} \gamma_\nu \psi_x, \tag{4.1}$$

where  $\nu = 1, 2, 3, 4$ . The exactly conserved (point-split) current reads then

$$j_{\nu} \sim \bar{\psi}_x U_{x\nu} \gamma_{\nu} \psi_{x+\nu} + \bar{\psi}_{x+\nu} U_{x\nu}^{\dagger} \gamma_{\nu} \psi_x. \tag{4.2}$$

Chemical potential is now introduced [15, 16] as an imaginary abelian vector field in the 4-direction, i.e. in the temporal hopping terms,

<span id="page-6-2"></span>forward hopping: 
$$U_{x4} = e^{iA_{4x}} \Rightarrow e^{a\mu}$$
, backward hopping:  $U_{x4}^{\dagger} = e^{-iA_{4x}} \Rightarrow e^{-a\mu}$ , (4.3)

where a is the lattice spacing in the temporal direction, written explicitly here. It is easy to check that an expansion in small  $a\mu$  yields the correct (naive) continuum limit and that the chemical potential couples to the exactly conserved charge, even for finite lattice spacing. Moreover, no new ultraviolet divergences appear. Note that different prescriptions are possible, provided that they agree in the continuum limit [17].

Note that typically expressions are written in terms of lattice units,  $a \equiv 1$ , and hence the factor a is not included in the exponentials. However, it is always clear what is meant, since  $\mu$  will appear in the following combination,

(lattice notation) 
$$\mu N_{\tau} = \mu/T$$
 (continuum notation). (4.4)

The reason for this is explained shortly.

<span id="page-6-1"></span><sup>&</sup>lt;sup>3</sup> Note that under a unitary gauge transformation,  $\psi_x \to \Omega_x \psi, \bar{\psi}_x \to \bar{\psi}\Omega_x^{\dagger}, U_{x\nu} \to \Omega_x U_{x\nu}\Omega_{x+\nu}^{\dagger}$  with  $\Omega_x^{\dagger}\Omega_x = 1$ ; hence these terms are gauge invariant.

![](_page_7_Picture_1.jpeg)

**Figure 2.** (a) Forward (backward) hopping is (dis)favoured by  $e^{\mu n_{\tau}}$  ( $e^{-\mu n_{\tau}}$ ), while closed loops are  $\mu$ -independent. (b) Loops wrapping around the temporal direction contribute  $e^{\pm \mu/T}$ .

<span id="page-7-1"></span>As can be seen in Eq. (4.3), the chemical potential introduces an imbalance between forward and backward hopping in the euclidean-time direction,

$$n_{\tau}$$
 steps of forward hopping (quark)  $\Rightarrow$  favoured as  $e^{\mu n_{\tau}}$ ;  $n_{\tau}$  steps of backward hopping (anti-quark)  $\Rightarrow$  disfavoured as  $e^{-\mu n_{\tau}}$ . (4.5)

It follows that in closed worldlines the  $\mu$  dependence cancels exactly, see Fig. 2.

Therefore the  $\mu$  dependence will only survive when worldlines wrap around the time direction. This suggests that  $\mu$  can effectively be thought of as a boundary condition. This notion can be made explicit as follows: consider the field redefinition

<span id="page-7-4"></span>
$$\psi_x = e^{-\mu\tau} \psi_x', \qquad \bar{\psi}_x = e^{\mu\tau} \bar{\psi}_x'. \tag{4.6}$$

The  $\mu$  dependence then drops from all terms of the form  $\bar{\psi}_x e^{\mu} \psi_{x+4}$  and  $\bar{\psi}_{x+4} e^{-\mu} \psi_x$  (and also from terms on the same time slice, such as spatial hopping terms), but appears instead as a boundary condition,<sup>4</sup>

$$\psi_{N_{\tau}} = -\psi_0 \qquad \Rightarrow \qquad \psi'_{N_{\tau}} = -e^{\mu N_{\tau}} \psi'_0, \tag{4.7}$$

wrapping around the temporal direction. This explains the presence of the factor  $e^{\pm \mu/T}$ .

The Bose gas on the lattice is discussed as an exercise in Appendix A.

## <span id="page-7-0"></span>5. Phase-quenching: sign, overlap and Silver Blaze problems

## 5.1. Overlap problem

Let us consider again the partition function

$$Z = \int DU D\bar{\psi} D\psi e^{-S} = \int DU e^{-S_B} \det M, \tag{5.1}$$

with a complex determinant,

$$\det M = |\det M|e^{i\varphi}. \tag{5.2}$$

An apparently straightforward solution to the complex-phase problem is to absorb the phase in the observable, as follows

<span id="page-7-3"></span>
$$\langle O \rangle_{\text{full}} = \frac{\int DU \, e^{-S_B} \det M \, O}{\int DU \, e^{-S_B} \det M} = \frac{\int DU \, e^{-S_B} |\det M| \, e^{i\varphi} O}{\int DU \, e^{-S_B} |\det M| \, e^{i\varphi}} = \frac{\langle e^{i\varphi} O \rangle_{\text{pq}}}{\langle e^{i\varphi} \rangle_{\text{pq}}}, \tag{5.3}$$

<span id="page-7-2"></span><sup>&</sup>lt;sup>4</sup> The minus sign is due to the anticommuting nature of fermions.

where  $\langle \cdot \rangle_{\text{full}}$  denotes expectation values taken with respect to the original, complex weight, while  $\langle \cdot \rangle_{\text{pq}}$  denotes expectation values with respect to the phase-quenched weight, i.e. using  $|\det M|$ . Every step in Eq. (5.3) is well defined in principle.

To analyse why this method is nevertheless not applicable in general, let us take a closer look at the average phase factor  $\langle e^{i\varphi}\rangle_{pq}$ . It is simple algebra to write

$$\langle e^{i\varphi} \rangle_{pq} = \frac{\int DU \, e^{-S_B} |\det M| \, e^{i\varphi}}{\int DU \, e^{-S_B} |\det M|} = \frac{Z_{\text{full}}}{Z_{pq}} = e^{-\Omega \Delta f},$$
 (5.4)

where we have expressed the partition functions in terms of the free energy densities,

$$Z \equiv Z_{\text{full}} = e^{-F/T} = e^{-\Omega f},$$
  $Z_{pq} = e^{-F_{pq}/T} = e^{-\Omega f_{pq}},$  (5.5)

with  $\Omega$  the spacetime volume ( $\Omega = V/T$  in physical units or  $N_{\tau}N_s^3$  in lattice units), and

$$\Delta f = f - f_{pq} \tag{5.6}$$

is the difference in the free energy densities. Note that  $Z_{\text{full}} \leq Z_{\text{pq}}$ . We find therefore that the average phase factor is the ratio of two partition functions and that it goes to zero in the thermodynamic limit, unless  $f = f_{\text{pq}}$ . As a consequence the ratio in Eq. (5.3) is not defined! Both numerator and denominator vanish exponentially as the spacetime volume is increased.

The reason for this is the so-called *overlap problem*: the phase-quenched theory is manifestly different from the full theory and hence, even though the weight in the phase-quenched theory is real and positive, sampling from it is a highly ineffective approach to mimic sampling from the full theory. Because of the exponential dependence on the four-volume, it is often said that the sign problem is exponentially hard.

The overlap problem emphasises that the physics of the phase-quenched and the full theory differ in an essential way. This can be nicely illustrated in QCD with two degenerate flavours [18]. Recall that  $M^{\dagger}(\mu) = \gamma_5 M(-\mu)\gamma_5$  for real quark chemical potential  $\mu$ . Then the determinant in the full theory reads

$$[\det M(\mu)]^2 \tag{5.7}$$

while the determinant in the phase-quenched theory can be written as

$$|\det M(\mu)|^2 = \det M^{\dagger}(\mu) \det M(\mu) = \det M(-\mu) \det M(\mu). \tag{5.8}$$

Hence the phase-quenched theory corresponds in fact to a theory at nonzero isospin chemical potential (see Sec. 2). It turns out that this theory has a very different phase structure than QCD at nonzero baryon chemical potential, especially at low temperature. This can be understood from the discussion in Sec. 3.3: while the lightest particle with nonzero baryon number is the nucleon, the lightest particle with nonzero isospin is the pion. Hence the onset at zero temperature takes place at a critical quark chemical potential  $\mu_c$ , which equals

- for quark chemical potential:  $\mu_c = [\text{nucleon mass } m_N \text{binding energy}]/3 \implies \text{transition}$  to nuclear matter;
- for isospin chemical potential:  $\mu_c = [\text{pion mass } m_{\pi}]/2 \quad \Rightarrow \quad \text{pion condensation.}$

At strictly zero temperature, we find therefore that in the interval  $0 < \mu < m_{\pi}/2$  the full and the phase-quenched theories are identical, but no interesting physics is taking place since the thermodynamic quantities are independent of chemical potential. On the other hand, in the interval  $m_{\pi}/2 < \mu \lesssim m_N/3$  strong cancelations are required to cancel the  $\mu$  dependence in the full theory. These cancelations are arising from the phase factor, ignored in the phase-quenched

![](_page_9_Figure_1.jpeg)

<span id="page-9-0"></span>**Figure 3.** Average phase factor in the thermodynamic limit in the phase-quenched theory at T = 0.

theory. Therefore, in the thermodynamic limit, the average phase factor will be as shown in Fig. 3.

We conclude that if the full theory is studied via simulations of the phase-quenched theory, excessive cancelations of the  $\mu$  dependence should take place in the region  $m_{\pi}/2 < \mu \lesssim m_B/3$ . It turns out that this is quite a severe constraint to do this correctly, and many straightforward numerical methods fail this test! As mentioned earlier, this phenomenon has been dubbed the Silver Blaze problem, named after a Sherlock Holmes story (see Ref. [14]).

In Appendix A, it is shown that the same feature is present in the Bose gas: here the phasequenched theory is simply a theory with a  $\mu^2$ -dependent effective mass parameter  $m_{\text{eff}}^2 = m^2 - \mu^2$ and the region of severe cancelations (the Silver Blaze region) is given by  $0 < \mu < m$ .

#### 5.2. Silver Blaze problem and the Dirac operator

The original formulation of the Silver Blaze problem was given in the context of the eigenvalues of the Dirac operator [14]. Since the weight and therefore configurations in lattice simulations depend on the chemical potential, so should the eigenvalues. Yet, as mentioned several times above, this  $\mu$  dependence should cancel in the expectation value of thermodynamic quantities. In order to achieve this, it was found that the density of the Dirac eigenvalues has to behave in a highly nontrivial manner [14,19,20]. We will now briefly describe this.

Let us write the Dirac operator as

$$M = D + m$$
 with  $D = \mathcal{D} + \mu \gamma_4$ . (5.9)

The partition function is written as

$$Z = \int DU \det(D+m)e^{-S_{YM}} = \langle \det(D+m)\rangle_{YM}, \qquad (5.10)$$

where the subscript YM indicates the average over the gluonic field only (and with slight abuse of notation, the brackets  $\langle \cdot \rangle_{\rm YM}$  are not normalised). The determinant is the product of the eigenvalues,

$$\det(D+m) = \prod_{k} (\lambda_k + m) \qquad D\psi_k = \lambda_k \psi_k. \tag{5.11}$$

Note that since D is not  $\gamma_5$  hermitian at nonzero  $\mu$ , the eigenvalues not purely real or imaginary, but they are complex in general.

It is customary to look at the chiral condensate, which is expressed as ( $\Omega$  denotes again the spacetime volume)

$$\langle \bar{\psi}\psi \rangle = \frac{1}{\Omega} \frac{\partial \ln Z}{\partial m} = \frac{1}{Z} \left\langle \frac{1}{\Omega} \sum_{k} \frac{1}{\lambda_k + m} \prod_{j} (\lambda_j + m) \right\rangle_{YM},$$
 (5.12)

since the derivative with respect to m removes every factor  $\lambda_k + m$  from the determinant once. This expression can be written succinctly in terms of the density of eigenvalues, defined as

$$\rho(z;\mu) = \frac{1}{Z} \int DU \det(D+m) e^{-S_{YM}} \frac{1}{\Omega} \sum_{k} \delta^{2}(z-\lambda_{k})$$

$$= \frac{1}{Z} \left\langle \det(D+m) \frac{1}{\Omega} \sum_{k} \delta^{2}(z-\lambda_{k}) \right\rangle_{YM}.$$
(5.13)

We can then finally write

$$\langle \bar{\psi}\psi\rangle = \int d^2z \frac{\rho(z;\mu)}{z+m},$$
 (5.14)

i.e. the chiral condensate is given by an integral in the complex plane over the spectral density. Now, in general  $\rho(z;\mu)$  will depend on  $\mu$ , since the Dirac operator D does. In fact, for every fixed configuration of gauge fields at nonzero  $\mu$ , there will be explicit  $\mu$  dependence. However, once the average over all gauge fields is taken, a.k.a. the integral over the spectral density is performed, the  $\mu$  dependence should cancel in the region where  $\mu \lesssim m_B/3$ , i.e. below onset, in the thermodynamic limit  $\Omega \to \infty$ . This is achieved as follows [19,20]: in the Silver Blaze region,  $\rho(z;\mu)$  is a complex function, oscillating with amplitude  $e^{\Omega\mu}$  and period  $1/\Omega$ . Only when all oscillations are correctly integrated,  $\mu$  dependence will cancel. This provides the resolution of the Silver Blaze problem, from the viewpoint of the eigenvalues of the Dirac operator. Detailed studies of the Dirac spectral density and the interplay with the sign problem can be found in Refs. [19–23].

In Appendix B this is worked out in detail in the form of an exercise for QCD in one dimension, in the case of the gauge group U(1).

### <span id="page-10-0"></span>6. Phase boundary at small chemical potential

The overlap problem is severe at low temperatures, making a lattice study of cold and dense matter prohibitively difficult using standard techniques. However, another relevant question for the QCD phase diagram concerns the thermal transition from the hadronic phase to the quark-gluon plasma when  $\mu \sim 0$ . Here one may expect the overlap problem to be less severe, since the theories with quark and isospin chemical potential are more alike, and also that approximate methods exploiting the relative smallness of the chemical potential with respect to the temperature can be employed successfully. In this section, we discuss this in some detail.

The aim will be to determine the phase boundary between the confined and deconfined phase at small  $\mu$  and, possibly, locate the critical endpoint in the phase diagram, assuming it exists. As a reminder, a sketch of the "standard" phase diagram is shown in Fig. 4. For physical quark masses, the transition at  $\mu=0$  is a crossover [24], and one may expect this to change into a first-order transition at larger  $\mu$ . The critical endpoint marks the end of the first-order line [25]. We note here that the investigation of this part of the phase diagram is very well motivated from an experimental point of view, due to the ongoing and planned heavy-ion collisions at RHIC, the LHC and hopefully at FAIR at GSI.

![](_page_11_Figure_1.jpeg)

<span id="page-11-0"></span>Figure 4. "Standard" phase diagram.

For small chemical potential, the critical temperature of the phase boundary at nonzero  $\mu$  can be written as a series in  $\mu/T$  [26, 27], for instance as

$$\frac{T_c(\mu)}{T_c(0)} = 1 + \# \left(\frac{\mu}{T_c(0)}\right)^2 + \# \left(\frac{\mu}{T_c(0)}\right)^4 + \dots$$
 (6.1)

Since the partition function is an even function of  $\mu$ , only even powers of  $\mu$  appear. Note that if the transition is a crossover, a unique transition line is not defined and hence the coefficients in this expansion and also  $T_c(0)$  may depend on the observable. To avoid too many notational complications, we will refer to  $T_c$  as the generic transition temperature, defined in a suitable manner in the case of a crossover. A considerably more advanced step is to also attempt to determine the location of the critical endpoint from the radius of convergence of the expansion, with knowledge of the first few coefficients only [28].

In the following we discuss several approaches which have been used to determine the phase boundary.

#### 6.1. Reweighting

The general strategy in reweighting was already discussed above and is summarised here. The partition function is written as

$$Z_w = \int DU w(U), \qquad w(U) \in \mathbf{C}, \tag{6.2}$$

and observables are expressed as

$$\langle O \rangle_w = \frac{\int DU \, O(U) w(U)}{\int DU \, w(U)}. \tag{6.3}$$

Let us now introduce a new weight r(U) (r for 'reweighting' or 'real'), chosen at will, such that

$$\langle O \rangle_w = \frac{\int DU \, O(U) \frac{w(U)}{r(U)} r(U)}{\int DU \, \frac{w(U)}{r(U)} r(U)} = \frac{\langle O \frac{w}{r} \rangle_r}{\langle \frac{w}{r} \rangle_r}. \tag{6.4}$$

As above, the reweighting factor indicates the severity of the overlap problem,

$$\left\langle \frac{w}{r} \right\rangle_r = \frac{Z_w}{Z_r} = e^{-\Omega \Delta f}, \qquad \Delta f = f_w - f_r \ge 0,$$
 (6.5)

![](_page_12_Figure_1.jpeg)

<span id="page-12-0"></span>**Figure 5.** Reweighting at fixed temperature (left) and multiparameter reweighting, aiming at maximising the overlap as well as possible (right).

where  $\Omega$  denotes again the spacetime volume.

There is considerable freedom in choosing the new weight r(U), provided that it has the interpretation of a probability weight, such that numerical simulations are possible. Hence one may adapt r to the problem at hand. Two examples are

• Glasgow reweighting [29]: work at a fixed temperature (or lattice coupling  $\beta$ ) and increase  $\mu$  from 0, i.e.

$$\frac{w}{r} \sim \frac{\det M(\mu)}{\det M(0)},$$
 (6.6)

as illustrated in Fig. 5 (left). However, this choice has a severe overlap problem, since the high-density phase is probed with hadronic physics at  $\mu = 0$ . One expects  $\Delta f$  to be large and hence the overlap problem will appear already on small volumes.

• multi-parameter/overlap preserving reweighting [30]: here the temperature (or lattice coupling  $\beta$ ) is adapted as well, see Fig. 5 (right). Hence

$$\frac{w}{r} \sim \frac{\det M(\mu)}{\det M(0)} e^{-\Delta S_{\rm YM}},\tag{6.7}$$

where  $\Delta S_{\rm YM}$  is the difference between gauge actions with different gauge couplings. The main idea here is to attempt to stay on the pseudo-critical line  $T_c(\mu)$ , hence improving or even ensuring overlap, since both the hadronic phase and the quark-gluon plasma are sampled during the numerical simulation. This approach has led to a determination of the location of the critical endpoint [31]: namely  $\mu_E^q = 120(13)$  MeV,  $T_E = 162(2)$  MeV, see Fig. 6. This result was obtained using  $N_f = 2 + 1$  quark flavours with physical quark masses on a coarse lattice with  $N_{\tau} = 4$  points in the temporal direction. Unfortunately, this method is very expensive to extend to smaller lattice spacing (larger  $N_{\tau}$ ) and it has not been repeated. A critical analysis can be found in Ref. [32]

## 6.2. Taylor series expansion

An alternative, and more modest, idea relies on a Taylor series expansion in  $\mu/T$  around  $\mu = 0$ . The coefficients in the expansion can be calculated using conventional simulations at  $\mu = 0$ , where the sign problem is absent. This approach continues to be pursued by several groups [26, 28, 33–36]. A recent review can be found in Ref. [10].

Let us start again from the grand-canonical ensemble, or pressure,

$$p = \frac{T}{V} \ln Z. \tag{6.8}$$

![](_page_13_Figure_1.jpeg)

<span id="page-13-0"></span>Figure 6. Left: Location of the critical endpoint using multi-parameter/overlap preserving reweighting, on a lattice with  $N_{\tau}=4$  [31]. Continuum estimate of the pressure as a function of temperature for  $\mu_L=0$  and 400 MeV, only including the term up to  $\mathcal{O}(\mu_L^2)$ , for  $N_f=2+1$  flavours of quarks with physical masses, using an continuum extrapolation [36]. Here  $\mu_L$  refers to the baryon chemical potential for the two light flavours only.

Using that the pressure is an even function of  $\mu$ , we can write

$$\Delta p(\mu) \equiv p(\mu) - p(0) = \frac{\mu^2}{2!} \frac{\partial^2 p}{\partial \mu^2} \Big|_{\mu=0} + \frac{\mu^4}{4!} \frac{\partial^4 p}{\partial \mu^4} \Big|_{\mu=0} + \dots, \tag{6.9}$$

or more compactly,

$$\frac{\Delta p(\mu)}{T^4} = \sum_{n=1}^{\infty} c_{2n}(T) \left(\frac{\mu}{T}\right)^{2n}.$$
(6.10)

The coefficients  $c_{2n}$  are defined at  $\mu = 0$ . Note that other thermodynamic quantities follow immediately, for example the density is given by

$$\langle n(\mu) \rangle = \frac{\partial p}{\partial \mu} = 2T^3 \sum_{n=1}^{\infty} nc_{2n}(T) \left(\frac{\mu}{T}\right)^{2n-1}.$$
 (6.11)

In order to see what it is needed in practice, it is useful to give some explicit expressions. We start from

$$Z = \int DU (\det M)^{N_f} e^{-S_{YM}} = \int DU e^{-S_{YM} + N_f \ln \det M(\mu)}.$$
 (6.12)

Differentiation is straightforward and

$$\frac{\partial \ln Z}{\partial \mu} = \left\langle N_f \frac{\partial}{\partial \mu} \ln \det M \right\rangle,$$

$$\frac{\partial^2 \ln Z}{\partial \mu^2} = \left\langle N_f \frac{\partial^2}{\partial \mu^2} \ln \det M \right\rangle + \left\langle \left( N_f \frac{\partial}{\partial \mu} \ln \det M \right)^2 \right\rangle - \left\langle N_f \frac{\partial}{\partial \mu} \ln \det M \right\rangle^2, \quad (6.13)$$

etc. Writing  $\ln \det M = \operatorname{Tr} \ln M$ , these can be expressed as

$$\frac{\partial}{\partial \mu} \ln \det M = \operatorname{Tr} M^{-1} \frac{\partial M}{\partial \mu},$$

$$\frac{\partial^2}{\partial u^2} \ln \det M = \operatorname{Tr} M^{-1} \frac{\partial^2 M}{\partial u^2} - \operatorname{Tr} M^{-1} \frac{\partial M}{\partial u} M^{-1} \frac{\partial M}{\partial u},$$
(6.14)

![](_page_14_Figure_1.jpeg)

<span id="page-14-0"></span>Figure 7. Phase boundary around  $\mu^2 = 0$  in the  $T - \mu^2$  plane.

etc., allowing for an easy diagrammatic interpretation. It is straightforward to work out more derivatives, but the number of terms increases rapidly, see e.g. Ref. [28] for terms contributing to quite high order. Moreover, there are again cancelations required: the pressure p is an intensive quantity, and hence the coefficients  $c_{2n}$  are finite in the thermodynamics limit. However, the individual contributions may scale differently, as is clear from the explicit expressions above. This situation is familiar from e.g. the usual (second-order) susceptibilies  $\chi$ , but is enhanced at higher order, where the  $c_{2n}$ 's can be viewed as generalized susceptibilities.

Most current work focuses on going closer to the continuum limit for physical quark masses. An example is given in Fig. 6 (right) [36]: plotted is a continuum estimate of the pressure as a function of temperature for two values of  $\mu_L$ , the baryon chemical potential for the two light flavours. Note that only the  $\mathcal{O}(\mu_L^2)$  contribution is included.

#### 6.3. Imaginary $\mu$

As shown in Sec. 2 the fermion matrix satisfies the property

$$[\det M(\mu)]^* = \det M(-\mu^*).$$
 (6.15)

Hence its determinant is real if the chemical potential is chosen to be purely imaginary,  $\mu = i\mu_{\rm I}$ . One is then able to perform ordinary simulations employing importance sampling. In particular, one may obtain the transition line  $T_c(\mu_{\rm I})$  at imaginary  $\mu$ . Treating  $\mu$  as a complex parameter the transition line for real  $\mu$  can then be obtained by analytical continuation. Since  $T_c$  is even in  $\mu$ , this is particularly straightforward and amounts to  $+\mu_{\rm I}^2 \to -\mu^2$ . Hence one may follow these steps, as illustrated in Fig. 7:

- (i) determine the phase boundary at  $\mu^2 < 0$ ;
- (ii) parametrise and fit  $T_c(-\mu^2)$ ;
- (iii) obtain the phase boundary at  $\mu^2 > 0$ .

This approach has been carried out during the past decade in great detail; an incomplete list includes Refs. [27,37–42]. However, it turns out that at imaginary  $\mu$  QCD has quite an intricate phase structure and that the topic is much richer than just for applying analytical continuation around  $\mu^2 \sim 0$ . Hence we will discuss QCD at imaginary  $\mu$  in more detail in the next section.

# 6.4. Summary

A compilation of results for the phase boundary using various methods is presented in Fig. 8. This plot from 2009 [4] is by now already rather old, but it shows the essential findings. Good

![](_page_15_Figure_1.jpeg)

imaginary  $\mu$  2 parameter imag.  $\mu$  double reweighting (Lee-Yang zeroes) double reweighting (susceptibilities) canonical

<span id="page-15-1"></span>Figure 8. Phase boundary in the plane of gauge coupling and chemical potential in lattice units, or, in physical units,  $\mu/T$  and  $T/T_c$ , comparing several methods, for four flavours of staggered quarks on a lattice with  $N_{\tau} = 4$  sites in the temporal direction [4].

agreement exists between the various methods as long as  $\mu/T \lesssim 1$ , for which the average sign is distinctly different from zero, at least on the small spatial volume sizes and fixed  $N_{\tau}=4$  considered. However, as the chemical potential is increased, the average sign becomes zero within the error and the results from the various approaches start to deviate. Which result is correct, if any, cannot be concluded. Hence the sign problem is preventing further progress.

In more recent years the attention has shifted to the determination of the lowest-order coefficients in the expansion to higher precision than before, i.e. for physical quark masses and closer to the continuum limit. For instance, Ref. [43] gives a summary for results for the second-order coefficient  $\kappa$  in the expansion

$$\frac{T_c(\mu_B)}{T_c} = 1 - \kappa \left(\frac{\mu_B}{T_c}\right)^2 + \mathcal{O}\left(\mu_B^4\right),\tag{6.16}$$

and finds that  $0.007 \lesssim \kappa \lesssim 0.018$ , depending on the method used. Most results have been obtained still away from the continuum limit and hence it is expected that a unique answer will emerge eventually. The state-of-the-art has recently been summarised in Ref. [10].

Possibilities for the critical endpoint will discussed again at the end of the next section.

#### <span id="page-15-0"></span>7. Imaginary chemical potential

QCD at imaginary chemical potential is a much richer topic than we have seen so far. It has an intricate phase structure due to the following two reasons:

- (i) the interplay of chemical potential and centre symmetry;
- (ii) the sensitivity of the thermal transition to the masses of the three light quarks (u, d, s).

In this section, we will discuss this in some detail, starting from the quark mass dependence of the thermal transition, summarised in the so-called Columbia plot. We then discuss centre symmetry in the pure SU(3) gauge theory and with the addition of quarks, and finally extend the Columbia plot to three dimensions, by including the chemical potential. This section is based on a series of papers, see e.g. Refs. [27, 38, 40, 44, 45] and especially Ref. [46].

![](_page_16_Figure_1.jpeg)

<span id="page-16-0"></span>Figure 9. Columbia plot: quark mass dependence of thermal transition.

#### 7.1. Quark mass dependence of the thermal transition

Characteristics of the thermal transition are very sensitive to the masses of the three lightest quarks,  $m_q = m_{u,d,s}$ . This is summarised in the Columbia plot, shown in Fig. 9, through which we walk now. The horizontal axis indicates the (degenerate) u and d quark masses, and the vertical axis the s quark mass, ranging from 0 to  $\infty$ . Of course, changing the quark masses is not possible in Nature, but it is possible and very useful in theoretical computations, as it offers additional insight in the phase structure of the strong interaction.

Let us start in the top right corner:  $m_q = \infty$ . Since the quarks decouple, this corner corresponds to the pure SU(3) gauge theory. As will be discussed shortly, the confinement/deconfinement transition can be defined here with the help of  $\mathbb{Z}_3$  centre symmetry, which is unbroken at low temperature and broken spontaneously at high temperature. The Polyakov loop acts as the order parameter and the transition is first order. In the presence of quarks with a finite mass (rather than infinite), the centre symmetry is broken explicitly and the Polyakov loop is no longer a true order parameter. Yet the deconfinement transition remains first order for large, but not infinite, quark masses.

Next we consider the bottom left corner. Here the quarks are massless,  $m_q = 0$ , and hence chiral symmetry can be used to define the transition, with the chiral condensate as the order parameter. Again the transition is first order, and remains first order for small, but nonzero quark massess. Increasing the quark masses more, or reducing them from infinity, the transition becomes a crossover with no change in symmetry properties (both chiral and centre symmetry are broken explicitly). The lines where the change from first order to crossover happens are lines of second-order phase transitions, as indicated in the figure. The physical point, with the quark masses as in Nature, is in the crossover region [24].

Finally, there are some special choices of quark masses: the diagonal line  $N_f = 3$  corresponds to three degenerate flavours; the line  $N_f = 2$  corresponds to two degenerate flavours  $(m_s = \infty)$ ; and the line  $N_f = 1$  to one-flavour QCD  $(m_{u,d} = \infty)$ . The vertical line at  $m_{u,d} = 0$  indicates two massless flavours and a massive s quark. The phase structure at larger  $m_s$  is still under investigation [42]: if the transition turns second order at large  $m_s$ , the first and the second-order transition meet at a tricritical point, indicated with  $m_s^{\rm tric}$ .

#### 7.2. Pure gauge: centre symmetry

In SU(N) gauge theories without quarks (or with infinitely heavy quarks), there is an exact global symmetry [47], which is unbroken at low and spontaneously broken at high temperature

(we consider N = 3, but write N for the number of colours). Let us multiply each temporal link in a fixed time slice with a phase factor  $z^k$ ,

$$U_4(\tau, \mathbf{x}) \rightarrow z^k U_4(\tau, \mathbf{x}), \qquad z^k = e^{2\pi i k/N} \qquad (k = 0, \dots, N-1).$$
 (7.1)

These phase factors are elements of the centre of SU(N), i.e. they commute with every element of the group:  $z^k \mathbb{1} \in \mathbb{Z}_N$ , with  $det(z^k \mathbb{1}) = 1$ . This centre transformation leaves the action and the path integral measure invariant and is hence a symmetry of the pure gauge theory. Note that it is not a gauge transformation.

The Polyakov loop, the traced product of all links at a spatial site  $\mathbf{x}$  in the temporal direction,

$$P(\mathbf{x}) = \frac{1}{N} \operatorname{tr} \prod_{\tau=0}^{N_{\tau}-1} U_4(\tau, \mathbf{x}), \tag{7.2}$$

transforms under this multiplication as

$$P(\mathbf{x}) \to z^k P(\mathbf{x}).$$
 (7.3)

Hence if  $\langle P \rangle = 0$ , the Polyakov loop expectation value remains zero under a centre transformation and centre symmetry is unbroken. However, if  $\langle P \rangle \neq 0$ , a centre transformation will change the expectation value,

$$\langle P \rangle \to z \langle P \rangle \to z^2 \langle P \rangle \to \dots \to z^{N-1} \langle P \rangle,$$
 (7.4)

and centre symmetry is broken. Note that the perturbative vacuum corresponds to  $U_4 = 1$  ( $A_4 = 0$ ) and therefore  $\langle P \rangle = 1$ . Hence centre symmetry is broken perturbatively and there are in fact N equivalent vacua. For N=3, this is illustrated in Fig. 10 ( $z=1,e^{\pm 2\pi i/3}$ ). Since perturbation theory is relevant at high temperature, we may already expect that at high temperature the centre symmetry is (spontaneously) broken.

![](_page_17_Picture_11.jpeg)

**Figure 10.** Equivalent vacua in SU(3) gauge theory, in the case of broken centre symmetry  $\mathbb{Z}_3$ .

<span id="page-17-0"></span>This conclusion can be better understood by interpreting the Polyakov loop as the worldline of a massive, i.e. static, quark, and the conjugate Polyakov loop,

$$P^{\dagger}(\mathbf{x}) = \frac{1}{N} \operatorname{tr} \prod_{\tau=N_{-}-1}^{0} U_4^{\dagger}(\tau, \mathbf{x}), \tag{7.5}$$

as the worldline of a massive anti-quark [48, 49]. Then the free energy  $F_{q\bar{q}}(r)$  for a static quark/anti-quark pair, separated by a distance r, is given by

$$\langle P(\mathbf{x})P^{\dagger}(\mathbf{y})\rangle = e^{-F_{q\bar{q}}(r)/T}, \qquad r = |\mathbf{x} - \mathbf{y}|.$$
 (7.6)

At large separation, only the disconnected part of the expectation value survives and

$$\lim_{r \to \infty} \langle P(\mathbf{x}) P^{\dagger}(\mathbf{y}) \rangle = \langle P(\mathbf{x}) \rangle \langle P^{\dagger}(\mathbf{y}) \rangle = |\langle P \rangle|^{2}. \tag{7.7}$$

When there is confinement, the free energy grows with the distance since quarks cannot be separated (there is no string breaking in the pure gauge theory), while in the absence of confinement, the free energy remains finite. Hence we find

- $F_{q\bar{q}}(\infty) \to \infty \qquad \Rightarrow \qquad \langle P \rangle = 0,$   $F_{a\bar{q}}(\infty) \text{ finite} \qquad \Rightarrow \qquad \langle P \rangle \neq 0.$ • confined phase:
- deconfined phase:

The Polyakov loop acts therefore as an order parameter for (de)confinement and centre symmetry is broken in the deconfined phase.

#### 7.3. Centre symmetry with quarks

In the presence of quarks, centre symmetry is broken explicitly: for instance the term  $\bar{\psi}_x U_4 \psi_{x+4}$ in the action, see Eq. (4.1), is not invariant under the centre transformation. While in the pure gauge theory, all  $\mathbb{Z}(N)$  vacua are equivalent, with quarks the trivial vacuum is preferred,  $\langle P \rangle \sim 1$ . The quarks act as an external symmetry breaking field, choosing a preferred direction, in the same way an external magnetic field acts in the Ising model or a quark mass in the case of chiral symmetry.

However, in the presence of an imaginary chemical potential, multiplying the temporal links as  $U_4 \to e^{i\mu_1}U_4$ , something nontrivial happens, since the centre transformation can be undone by a shift in  $\mu_{\rm I}$ . To see this, let us move all the  $\mu_{\rm I}$  dependence to the final time slice, which is possible via a field redefinition, see Eq. (4.6). The chemical potential now appears as  $e^{i\mu_{\rm I}/T}$ . If a  $\mathbb{Z}(N)$  transformation is performed on the final time slice, the following combination appears,

$$z^k e^{i\mu_{\rm I}/T} = \exp i \left( \frac{\mu_{\rm I}}{T} + \frac{2\pi k}{N} \right). \tag{7.8}$$

Hence we note that the centre transformation can be undone by a shift in  $\mu_{\rm I}$ : this leads to a new symmetry, often called Roberge-Weiss symmetry [44],

$$Z\left(\frac{\mu}{T}\right) = Z\left(\frac{\mu}{T} + \frac{2\pi ik}{N}\right). \tag{7.9}$$

Note that  $Z(\mu) = Z(-\mu)$  still holds as well. Hence the partition function and the phase structure are periodic in the  $\mu_{\rm I}$  direction with period  $2\pi T/N$  and the range of  $\mu_{\rm I}/T$  is limited by  $\pi/N$ , starting at  $\mu_{\rm I} = 0$ .

Another way to interpret the Roberge-Weiss symmetry is to note that an increase in  $\mu_{\rm I}$ is equivalent to a centre transformation. However, since the Polyakov loop is not invariant under the latter, the choice of preferred vacuum will change as  $\mu_{\rm I}$  is increased. When  $\langle P \rangle \neq 0$ , the Polyakov loop expectation value cycles through the N different possibilities: the preferred vacuum is given by the

- $\langle P \rangle \sim 1$  at  $\mu_{\rm I}/T \sim 0$ ; • trivial vacuum
- $\langle P \rangle \sim z$  at  $\mu_{\rm I}/T \sim 2\pi/N$ ; • rotated vacuum
- $\langle P \rangle \sim z^2$  at  $\mu_{\rm T}/T \sim 4\pi/N$ : • rotated vacuum

etc. In the confined phase  $\langle P \rangle = 0$  and this observation is not relevant. However, in the deconfined phase,  $\langle P \rangle \neq 0$ , and the direction of symmetry breaking changes. This is illustrated in Fig. 11 (left) by the symbols with the three little arrows. The remarkable consequence of this

![](_page_19_Figure_1.jpeg)

<span id="page-19-0"></span>**Figure 11.** Phase structure in the  $\mu_{\rm I} - T$  plane [46] (left) and the  $\mu^2 - T$  plane (right). See main text for more details.

is that exactly at the boundaries, given by  $\mu_{\rm I}/T = (2r+1)\pi/N$  (r=0,1,2,...), we find again a proper first-order phase transition, with the Polyakov loop as order parameter, even in the presence of quarks!

To continue, let us now include the thermal transition line in the phase diagram. Recall that for real  $\mu$  we have written

$$\frac{T_c(\mu)}{T_c} = 1 - \# \left(\frac{\mu}{T_c}\right)^2 + \dots, \qquad \# > 0.$$
 (7.10)

Hence this line increases quadratically with  $\mu_{\rm I}$ , as indicated with the dotted line in Fig. 11 (left). It is natural to connect the thermal transition line with the vertical Roberge-Weiss line at  $\mu_{\rm I}/T = \pi/3$ . The point where the lines meet is known as the Roberge-Weiss endpoint. For larger  $\mu_{\rm I}$ , the phase structure is determined by the periodicity.

To combine the findings for real and imaginary chemical potential in one diagram, we show the resulting phase structure in the  $\mu^2 - T$  plane in Fig. 11 (right). The thermal transition line decreases linearly in  $\mu^2$  around  $\mu^2 \sim 0$  and connects to the Roberge-Weiss endpoint on the left.

We saw from the Columbia plot that details of the phase structure depend strongly on the quark masses. At  $\mu=0$  the transition is first order for very light or very heavy quarks, and a crossover for intermediate quark masses. This structure extends to nonzero chemical potential as follows (for definiteness we consider the case  $N_f=3$ ):

- heavy or light quarks: the first-order transition remains first order for all imaginary  $\mu$ . At the Roberge-Weiss endpoint, three first-order lines come together, making it triple point. This is illustrated in Fig. 12 (left);
- quarks with intermediate mass: the crossover at  $\mu^2 = 0$  turns into a first-order transition at some value of  $\mu_{\rm I}$  and possibly also at some value of real  $\mu$ . The point(s) where this occurs are second-order critical endpoints (CEP). The Roberge-Weiss point is still a triple point, see Fig. 12 (middle);
- adapting the quark mass even more: the CEP at imaginary  $\mu$  coincides with the Roberge-Weiss point. The transition is a crossover for all values of  $\mu_{\rm I}$ . There might also still be a CEP for real  $\mu$ , see Fig. 12 (right).

We find therefore that the Roberge-Weiss endpoint is either a first-order triple point, where three first-order lines come together (for heavy and light quarks), or a second-order critical

![](_page_20_Figure_1.jpeg)

Figure 12. Phase structure in the  $\mu^2 - T$  plane for  $N_f = 3$  degenerate quarks, for very heavy or very light quarks (left), for quarks with an intermediate mass (middle), and for quark masses changed even more (right). The Roberge-Weiss endpoint is a triple point in the first two cases and a critical endpoint in the latter.

<span id="page-20-0"></span>![](_page_20_Figure_3.jpeg)

<span id="page-20-1"></span>Figure 13. Left: Quark mass dependence of the temperature of the Roberge-Weiss endpoint,  $T_{\text{RW}}$ , for  $N_f = 3$ . Right: equivalent of the Columbia plot at  $\mu_{\text{I}} = (\pi/3)T$ .

endpoint (for intermediate masses). Note that the temperature of the Roberge-Weiss endpoint depends on the quark mass as well: it increases with quark mass, just as the critical temperature at  $\mu=0$  increases with quark mass. This leads to the result shown in Fig. 13 (left): the critical temperature  $T_{\rm RW}$  as a function of the quark mass, for  $N_f=3$ . Since the Roberge-Weiss point is second order for intermediate quark masses and first order for larger and smaller masses, there are two tricritical points on this diagram, namely where the first and second-order lines meet.

## 7.4. Three-dimensional Columbia plot

We are now in a position to extend the Columbia plot by including the chemical potential. Recall that at  $\mu=0$  this plot indicates the order (first, second or crossover) of the thermal transition. First let us consider the case of  $\mu_{\rm I}/T=\pi/3$ . As argued above, the transition takes place at  $T_{\rm RW}$  and it is either first order or second order, depending on the quark masses. Hence a conjectured Columbia plot at  $\mu_{\rm I}/T=\pi/3$  is as shown in Fig. 13 (right). We remind the reader that the entire plot is critical and that the boundaries where the first- and second-order transitions meet are tricritial. This should be compared with the Columbia plot at  $\mu=0$ , where the central region indicates a crossover and the boundaries are second-order lines. Note that Fig. 13 (left) is the  $N_f=3$  (diagonal) cut through the plot on the right. The tricritical lines can be determined numerically by varying the quark masses, since there is no sign problem. This amounts to a detailed study of the properties of the Roberge-Weiss endpoint [45,46].

![](_page_21_Figure_1.jpeg)

<span id="page-21-0"></span>**Figure 14.** Columbia plot extended with chemical potential  $(\mu/T)^2$  in the vertical direction, for nondegenerate quark masses  $m_{u,d}$  and  $m_s$  [50] (left) and for  $N_f = 3$ , with  $m_{u,d,s} = m$  (right).

Finally, we can properly extend the Columbia plot with the chemical potential as the third direction. The obvious choice for coordinate is  $\mu^2/T^2$ , with

$$-(\pi/3)^2 \le (\mu/T)^2 < \infty, \tag{7.11}$$

where the lower boundary comes from the Roberge-Weiss periodicity. The result is shown in Fig. 14 (left). The red fishnets indicate second-order surfaces, inside of which the transition is a crossover, while near the  $m_q = 0$  and  $m_q \to \infty$  axes, the transition is first order. The plane  $\mu = 0$  is the original Columbia plot, while the plane  $(\mu/T)^2 = -(\pi/3)^2$  was already shown in Fig. 13 (right). By considering degenerate quark masses  $(N_f = 3)$ , we get the cut through the three-dimensional Columbia plot as shown in Fig. 14 (right). All features of this plot should now be familiar.

In all known cases, it appears that the first-order regions shrink as  $(\mu/T)^2$  is increased. This can be made very precise for heavy quarks [46,51,52]. To do this, let us take the blue/dashed line on the right-hand side of Fig. 14 (right) and rotate it. The result is shown in Fig. 15. The line

![](_page_21_Figure_7.jpeg)

<span id="page-21-1"></span>**Figure 15.** Critical quark mass separating the crossover and first-order regions as a function of  $(\mu/T)^2$ , for large quark masses.

![](_page_22_Figure_1.jpeg)

![](_page_22_Figure_2.jpeg)

<span id="page-22-0"></span>**Figure 16.** Tricritical scaling [46],  $m_c$  versus  $(\mu/T)^2$ , for heavy quarks, in the three-state Potts model [51] (left) and QCD in a strong coupling expansion [52] (right).

indicates the boundary between the crossover and first-order region and is second order; we will denote it with  $m_c$ . Note that the line emerges from the tricritical point at  $(\mu/T)^2 = -(\pi/3)^2$ . For increasing  $\mu^2$  the first-order region shrinks, i.e. the critical quark mass increases.

It turns out that the tricritical point makes its presence felt: it determines the curvature of the second-order line via tricritical scaling [46]. If we use the notation  $x = (\mu/T)^2$  and  $x_* = -(\pi/3)^2$ , then tricritical scaling dictates that

$$m_c(x) = m_c(x_*) + K(x - x_*)^{2/5},$$
 (7.12)

where the exponent 2/5 is fixed by universality and K is a free parameter.

How well this works in practice, i.e. how far the scaling region extends away from  $x_*$ , has been tested in models where the sign problem is milder than in full QCD, namely in the three-state Potts model [51], an effective model for QCD with heavy quarks, and in QCD in a combined strong coupling and hopping parameter expansion [52]. The results are shown in Fig. 16. In both models the sign problem is sufficiently mild such that simulations for real  $\mu$  are possible (in the Potts model the sign problem can be eliminated completely via a reformulation [53] and the results for QCD actually come from semi-analytical considerations). This allows us to see that tricritical scaling works extremely well: the data points fall on the scaling curve and the scaling region extends well into the  $\mu^2 > 0$  domain. Hence for heavy quarks highly nontrivial predictions on the phase structure for real  $\mu$  are possible from knowledge obtained purely at imaginary chemical potential, in a way that goes substantially beyond Taylor series and analytical continuation.

To conclude, we note that tricritical scaling has been investigated mainly for heavy quarks. It is an interesting question whether this large scaling region is also present for light quarks.

## 7.5. Critical endpoint

In the three-dimensional Columbia plot the regions of first-order transitions were shown to shrink as  $(\mu/T)^2$  increases. The astute reader may wonder what this implies for the critical endpoint at real chemical potential, discussed in Sec. 6. Here several scenarios are possible, illustrated in Fig. 17. Note that the position of physical quark masses is indicated with the vertical blue line. The standard scenario is sketched on the left: the surface bends away from the  $m_q = 0$  axis and the critical endpoint is located at the intersection of the (red) surface and the (blue) line. If on the other hand the first-order region shrinks, as is the case for heavy quarks, there is no critical endpoint related to the second-order surface (centre). Finally, it is possible that

![](_page_23_Figure_1.jpeg)

<span id="page-23-1"></span>Figure 17. Possible scenarios for the curvature of the second-order surface for light quarks and the critical endpoint for physical quark masses [\[4\]](#page-42-2).

the second-order surface depends in a more complicated manner on the chemical potential and quark masses, with forwards and backwards bending as µ is increased (right) [\[54\]](#page-43-8), making it substantially harder to establish its existence starting from zero or imaginary chemical potential.

This long-standing question is still not settled: it will require extensive computational resources and, ideally, approaches in which the sign problem is resolved.

## <span id="page-23-0"></span>8. Complex Langevin dynamics

As we have seen above, straightforward importance sampling combined with reweighting is typically not viable, due to the overlap problem. At small µ/T it might be feasible to preserve the overlap as best as possible, on small volumes, or to use approximate methods, such as a Taylor series expansion or analytical continuation and scaling from imaginary chemical potential. To fully attack the sign problem, however, something more radical is needed and the configuration space should be explored in a different manner. This is what we will focus on now.

![](_page_23_Figure_7.jpeg)

<span id="page-23-2"></span>Figure 18. What are the dominant configurations in a path integral with a complex weight? In complex Langevin dynamics, the question is answered by extending the configuration space into the complex plane.

The overlap problem is due to the fact that the relevant configurations differ in an essential way from those obtained at µ = 0 or using the absolute value of the determinant. Given the excessive cancelation between configurations with 'positive' and 'negative' weight, one may wonder whether it is possible to give a sensible meaning to the notion of dominant configurations, e.g. by extending the configuration space, as illustrated in Fig. [18.](#page-23-2) Here we discuss the answer according to complex Langevin dynamics.

#### 8.1. Gaussian integrals

We consider a simple Gaussian integral

<span id="page-24-0"></span>
$$Z(a,b) = \int_{-\infty}^{\infty} dx \, e^{-S(x)}, \qquad S(x) = \frac{1}{2}ax^2 + ibx.$$
 (8.1)

In *Kindergarten*, you learn to do this integral by completing the square, i.e. by going into complex plane. The lesson is therefore to analytically continue ("complexify") the degrees of freedom,  $x \to z = x + iy$ , which enlarges the configuration space and gives new directions to explore. In particular, it might be possible to find a real and positive distribution P(x, y), which is amenable to numerical approaches, see Fig. 18.

In complex Langevin dynamics, it is proposed that this distribution is constructed as the solution of a stochastic process [55,56]. To motivate this, consider again the Gaussian integral (8.1). We note that the action satisfies  $S^*(b) = S(-b^*)$  and we take a > 0 and real, such that

$$Z(a,b) = \sqrt{\frac{2\pi}{a}}e^{-\frac{1}{2}b^2/a}.$$
 (8.2)

The corresponding phase-quenched partition function is

$$Z_{pq} = \int_{-\infty}^{\infty} dx \, e^{-\frac{1}{2}ax^2} = Z(a,0) = \sqrt{\frac{2\pi}{a}},$$
 (8.3)

and hence the average phase factor equals

$$\langle e^{-ibx} \rangle_{pq} = \frac{Z(a,b)}{Z(a,0)} = e^{-\frac{1}{2}b^2/a}.$$
 (8.4)

Since this is only a simple integral, there is no volume factor in the exponential.

The goal will be to compute expectation values, such as

$$\langle x^2 \rangle = -2 \frac{\partial \ln Z}{\partial a} = \frac{a - b^2}{a^2},$$
 (8.5)

numerically, but without the use of importance sampling. Let us first take b = 0 and use the analogy with Brownian motion [57]: a particle moving in a fluid is subject to friction (a) and kicks  $(\eta)$  and satisfies a Langevin equation

$$\dot{x}(t) = -ax(t) + \eta(t), \qquad \langle \eta(t)\eta(t') \rangle = 2\delta(t - t'). \tag{8.6}$$

The kicks  $\eta$  are modelled as random Gaussian noise with  $\langle \eta(t) \rangle = 0$ . This problem is easily solved, without having to resort to numerics in this case,

$$x(t) = e^{-at}x(0) + \int_0^t ds \, \eta(s)e^{-a(t-s)}, \tag{8.7}$$

and hence the correlator (taking x(0) = 0, since the dependence on the initial condition decays exponentially in any case) equals

$$\langle x^2(t)\rangle = \int_0^t ds \int_0^t ds' \langle \eta(s)\eta(s')\rangle e^{-a(2t-s-s')}.$$
 (8.8)

Using that  $\langle \eta(s)\eta(s')\rangle = 2\delta(s-s')$ , we easily find

$$\lim_{t \to \infty} \langle x^2(t) \rangle = \frac{1}{a},\tag{8.9}$$

which is indeed the correct answer.

Associated with the Langevin equation is a Fokker-Planck equation for the distribution  $\rho(x,t)$ , defined via the relation

<span id="page-25-0"></span>
$$\langle O(x(t))\rangle_{\eta} = \int dx \, \rho(x,t)O(x),$$
 (8.10)

for a generic observable O(x). Here the noise average on the left-hand side is made explicit with the subscript  $\eta$  while the average on the right-hand side is over the distribution  $\rho(x,t)$ . The derivation of the Fokker-Planck equation is carried out as an exercise in Appendix C for the Langevin process

$$\dot{x}(t) = K(x(t)) + \eta(t), \qquad K(x) = -S'(x),$$
 (8.11)

where the drift K(x) is derived from the action S(x). The result is

<span id="page-25-1"></span>
$$\partial_t \rho(x,t) = \partial_x (\partial_x + S'(x)) \rho(x,t). \tag{8.12}$$

It is easy to see that the stationary solution of this Fokker-Planck equation equals  $\rho(x) \sim e^{-S(x)}$ , justifying the relation (8.10). Moreover, one can show that the stationary solution is typically reached exponentially fast, see e.g. the comprehensive review [58].

Let us now make the problem a bit more interesting by taking  $b \neq 0$ . Completing the square results in a shift in the complex plane  $x \to x - ib/a$ . We will now demonstrate that the same is achieved with the (complex) Langevin equation for z = x + iy. Writing S(z) = S(x + iy), the real and imaginary parts of the Langevin equation are (see Appendix C and using "real" noise)

$$\dot{x} = -\operatorname{Re} \partial_z S(z) + \eta = -ax + \eta, \tag{8.13}$$

$$\dot{y} = -\operatorname{Im} \partial_z S(z) = -ay - b, \tag{8.14}$$

with the solution

$$x(t) = x(0)e^{-at} + \int_0^t ds \, e^{-a(t-s)}\eta(s), \qquad y(t) = [y(0) + b/a]e^{-at} - b/a. \tag{8.15}$$

The two-point correlators follow easily as

<span id="page-25-2"></span>
$$\langle x^{2}(t)\rangle = x^{2}(0)e^{-2at} + (1 - e^{-2at})/a \qquad \to \qquad 1/a,$$

$$\langle x(t)y(t)\rangle = x(0)e^{-at}\left([y(0) + b/a]e^{-at} - b/a\right) \qquad \to \qquad 0,$$

$$\langle y^{2}(t)\rangle = \left([y(0) + b/a]e^{-at} - b/a\right)^{2} \qquad \to \qquad b^{2}/a^{2}.$$

$$(8.16)$$

The expressions after the arrows correspond to the limit  $t \to \infty$ . The *n*-point functions we are interested in depend on the holomorphic combination z = x + iy, and we find

<span id="page-25-3"></span>
$$\lim_{t \to \infty} \langle (x(t) + iy(t))^2 \rangle = \langle x^2 - y^2 + 2ixy \rangle = \frac{1}{a} - \frac{b^2}{a^2} = \frac{a - b^2}{a^2}, \tag{8.17}$$

which is as expected. We presented this in some detail to emphasise that the individual terms,  $\langle x^2 \rangle$ ,  $\langle y^2 \rangle$  and  $\langle xy \rangle$ , have no meaning as such: only expectation values of holomorphic observables are physically relevant.

![](_page_26_Figure_1.jpeg)

<span id="page-26-0"></span>Figure 19. Distribution P(x, y) for the action S = 1 2 ax<sup>2</sup> + ibx, for a = 1 and b = 0 (left), b = −2 (right).

The real and positive probability distribution associated with this process is now determined via

$$\langle O[x(t) + iy(t)] \rangle_{\eta} = \int dx dy \, P(x, y; t) O(x + iy), \tag{8.18}$$

and the Fokker-Planck equation reads

$$\partial_t P(x, y; t) = \left[ \partial_x \left( \partial_x + \text{Re } \partial_z S \right) + \partial_y \text{Im } \partial_z S \right] P(x, y; t). \tag{8.19}$$

This equation arises from a stochastic process in x and y, but with no noise applied in the y direction (see again [Appendix C\)](#page-39-0). However, unlike in the case of Eq. [\(8.12\)](#page-25-1) for ρ(x, t), no generic solutions are known for this Fokker-Planck equation. In fact, even the existence of a stationary solution is not guaranteed! This makes the justification of complex Langevin dynamics substantially harder [\[59,](#page-43-13) [60\]](#page-43-14) than for the original real Langevin process. It relies on the equivalence of

$$\int dx \,\rho(x,t)O(x) = \int dxdy \,P(x,y;t)O(x+iy),\tag{8.20}$$

for holomorphic observables O(x+ iy). Refs. [\[59,](#page-43-13)[60\]](#page-43-14) contain a detailed analysis of this problem, including consistency conditions which can be verified a posteriori.

However, for the model considered here, the solution is easily constructed. We note that the dynamics in the y direction is decoupled from x and, importantly, also from the noise. Hence the distribution is simply obtained by a shift in the complex plane, y → −b/a, and the distribution effectively sampled by the Langevin process equals

$$P(x,y) \sim e^{-ax^2/2} \delta(y + b/a).$$
 (8.21)

This is illustrated in Fig. [19.](#page-26-0) Hence the Langevin process completes the square for us.

A final Gaussian example is discussed as an exercise in [Appendix D.](#page-40-0) In this case we consider the action

$$S = \frac{1}{2}(a+ib)x^2,$$
 (8.22)

and hence x and y are not decoupled. The resulting probability distribution P(x, y) is therefore a proper two-dimensional, real and positive, distribution, as demonstrated in Fig. [20.](#page-27-0) The Langevin process finds this distribution, giving an explicit realisation of the sketch in Fig. [18.](#page-23-2)

![](_page_27_Figure_1.jpeg)

<span id="page-27-0"></span>**Figure 20.** Distribution P(x,y) for the action  $S=\frac{1}{2}(a+ib)x^2$  with a=1 and b=0.01,1,10(from left to right).

#### 8.2. Discretisation, field theory

Of course, most cases of interest are not analytically solvable and one has to turn to numerical solutions of the Langevin equation. A standard (lowest-order) discretisation of the Langevin time  $t = \epsilon n$  yields the discretised equations [58]

<span id="page-27-1"></span>
$$x_{n+1} = x_n + \epsilon K_n^{\mathrm{R}} + \sqrt{\epsilon} \eta_n,$$
  $K^{\mathrm{R}} = -\mathrm{Re} \frac{\partial S}{\partial z},$   $\langle \eta_n \eta_{n'} \rangle = \delta_{nn'},$  (8.23)  
 $y_{n+1} = y_n + \epsilon K_n^{\mathrm{I}},$   $K^{\mathrm{I}} = -\mathrm{Im} \frac{\partial S}{\partial z}.$  (8.24)

$$y_{n+1} = y_n + \epsilon K_n^{\mathrm{I}}, \qquad K^{\mathrm{I}} = -\mathrm{Im} \frac{\partial S}{\partial z}.$$
 (8.24)

This discretisation scheme has finite stepsize errors, which vanish linearly in  $\epsilon$ . Higher-order schemes can be used to improve the convergence to the limit of zero stepsize, see e.g. Ref. [61] for an explicit example. Note that the stepsize can be chosen adaptively if necessary [62].

In field theory, the approach outlined here is known, for real actions, as stochastic quantisation [57] and, for complex actions or drifts, as complex Langevin dynamics [55, 56]. We consider the euclidean path integral

$$Z = \int D\phi \, e^{-S}. \tag{8.25}$$

Now Langevin dynamics takes place in the 'fifth' time direction, as

$$\frac{\partial \phi(x,t)}{\partial t} = -\frac{\delta S[\phi]}{\delta \phi(x,t)} + \eta(x,t), \tag{8.26}$$

with the noise satisfying

$$\langle \eta(x,t) \rangle = 0$$
  $\langle \eta(x,t)\eta(x',t') \rangle = 2\delta(x-x')\delta(t-t').$  (8.27)

As in the cases above, one computes expectation values  $\langle \phi(x,t)\phi(x',t)\rangle$ , etc, and studies the convergence as the Langevin time  $t\to\infty$ . Both the discretisation and the complexification are as above. Gauge theories will be discussed in the next section.

#### 8.3. Applicability to theories with a sign problem

Langevin dynamics for real actions – stochastic quantisation – was discussed extensively in the 1980s and equivalence with path integral quantisation has been demonstrated [58]. For complex actions on the other hand, a formal proof was notably absent. This situation has improved considerably in recent years and the theoretical foundation has now been formulated [59]. Moreover, practical criteria for correctness can be written down and these can be assessed in numerical studies [60]. Failure of the approach, first observed in the 1980s [63, 64], can be

explained within the theoretical framework, albeit only a posteriori, see e.g. Ref. [\[65\]](#page-43-19) for a discussion of success and failure in the three-dimensional XY model with a complex action.

A crucial role in the justification is played by the distribution P(x, y). Provided that the action is holomorphic and the distribution P(x, y) is sufficiently localised, i.e.

$$P(x,y) = 0 \text{ for } |y| > y_{\text{max}}$$
 [or  $P(x,y) \to 0 \text{ fast enough}$ ], (8.28)

correct results are obtained, modulo some technical requirements [\[59,](#page-43-13) [60\]](#page-43-14). The proof relies on the Cauchy-Riemann equations, and hence holomorphicity of the drift and observables, and the possibility to perform partial integral in the imaginary direction without picking up boundary conditions. In the case of simple models with a holomorphic action, this has led to a complete, both numerical and analytical, understanding [\[66\]](#page-43-20).

An open question concerns the situation with meromorphic drifts, i.e. drifts with poles, which arise for instance from the inclusion of a log det in the effective action, schematically

$$Z = \int dx \, e^{-S} \det M = \int dx \, e^{-S_{\text{eff}}}, \qquad S_{\text{eff}} = S - \log \det M,$$
 (8.29)

with a drift

$$K = -\partial_z S_{\text{eff}} = -\partial_z S + \text{Tr} M^{-1} \partial_z M.$$
 (8.30)

In this case the assumed holomorphicity of the (effective) action is not present and the formal derivation has to be reconsidered. In practice, it has been found that problems *may* appear but not necessarily so [\[67\]](#page-43-21). This is still very much a topic of ongoing studies [\[68](#page-43-22)[–71\]](#page-43-23).

Aside from this important issue, the most exciting findings are that it has been shown that the method can handle severe sign and Silver Blaze problems, e.g. in the four-dimensional Bose gas at nonzero chemical potential [\[72\]](#page-43-24). The applicability of complex Langevin dynamics to the SU(3) spin model, to which it was first applied in 1985 [\[73\]](#page-43-25), is now also understood [\[61\]](#page-43-15), as has the essential difference between abelian and nonabelian spin models [\[74\]](#page-43-26). Most importantly, in the context of the QCD, there has been essential progress in the treatment of nonabelian gauge theories, to which we turn now.

## <span id="page-28-0"></span>9. Complex Langevin dynamics for gauge theories

The recent interest in complex Langevin dynamics for QCD at nonzero density arises from successful applications to SU(3) gauge theory, first in the presence of heavy (static) quarks and then also in the presence of dynamical quarks. This is still very much a topic in development, so in these lectures I want to focus on the algorithmic advance of gauge cooling [\[75\]](#page-43-27), which, in combination with the improved analytic understanding mentioned above, has led to some remarkable progress.

In SU(N) gauge theories, the complexification works as follows [\[76,](#page-43-28)[77\]](#page-43-29). Originally the gauge links Uxν are elements of SU(N), i.e., they are unitary with determinant 1. After discretisation of the Langevin time and using a lowest-order scheme in ǫ, a (complex) Langevin update takes the form [\[78\]](#page-43-30),

$$U_{x\nu}(n+1) = R_{x\nu}(n) U_{x\nu}(n), \qquad R_{x\nu} = \exp\left[i\lambda_a \left(\epsilon K_{x\nu a} + \sqrt{\epsilon}\eta_{x\nu a}\right)\right]. \tag{9.1}$$

Here <sup>λ</sup><sup>a</sup> are the Gell-Mann matrices and a sum over the indices <sup>a</sup> = 1, . . . N<sup>2</sup> <sup>−</sup> 1 is assumed. Kxνa is the drift,

$$K_{x\nu a} = -D_{x\nu a}(S_{YM} + S_F),$$
  $S_F = -\ln \det M,$  (9.2)

![](_page_29_Figure_1.jpeg)

<span id="page-29-0"></span>**Figure 21.** Deviation from SU(3): Langevin time evolution of the unitarity norm Tr  $U_4^{\dagger}U_4/3 \ge 1$  in heavy dense QCD on a  $4^4$  lattice with  $\beta = 5.6$ ,  $\kappa = 0.12$ ,  $N_f = 3$  [77].

where the action includes the logarithm of the fermion determinant. Differentiation is defined as

$$D_{x\nu a}f(U) = \frac{\partial}{\partial \alpha} f\left(e^{i\alpha\lambda_a} U_{x\nu}\right)\Big|_{\alpha=0},\tag{9.3}$$

and the noise is normalised as usual,

$$\langle \eta_{x\nu a}(n)\eta_{x'\nu'a'}(n')\rangle = 2\delta_{xx'}\delta_{\nu\nu'}\delta_{aa'}\delta_{nn'}. \tag{9.4}$$

Below we will suppress indices, when appropriate. Note that the combination of the drift and the noise in the exponential appears just as in Eq. (8.23) for one degree of freedom. Since the Gell-Mann matrices are traceless, the determinant of R and hence of U remain 1 for any choice of K and  $\eta$ . Moreover, if the action and therefore the drift K are real, R and U will remain unitary, using this update.

Let us now consider the case that the action (or the fermion determinant) is complex. In that case  $K^{\dagger} \neq K$  and U will no longer be unitary. Instead, U will take values in the special linear group, i.e. the complexification in this case is from  $\mathrm{SU}(N)$  to  $\mathrm{SL}(N,\mathbb{C})$ . One remark is that now  $U^{\dagger}$  and  $U^{-1}$  are no longer identical. Since complex Langevin dynamics provides the analytical continuation of the original theory, it is essential that links are written as U and  $U^{-1}$  in the action, such that S(U) is a holomorphic function of U in principle (ignoring possible issues due to the fermion determinant here). For instance, the original statement of unitarity,  $UU^{\dagger} = 1$ , is now replaced with  $UU^{-1} = 1$ , which still holds of course. Similarly, physical observables should be written as functions of U and  $U^{-1}$ , such that they are holomorphic. This is similar to the discussion for the Gaussian models above, see e.g. Eqs. (8.16, 8.17).

On the other hand, nonholomorphic combinations can be used to gain insight in the complex Langevin process. In the Gaussian models, the width of the distribution P(x, y) is given by  $\langle y^2 \rangle$ , or  $\langle y^k \rangle$  in general. Similarly, the deviation from  $\mathrm{SU}(N)$  can be studied using so-called unitarity norms [75, 77, 79], such as

$$\frac{1}{N}\operatorname{Tr}\left(UU^{\dagger} - \mathbb{1}\right) \ge 0, \qquad \frac{1}{N}\operatorname{Tr}\left(UU^{\dagger} - \mathbb{1}\right)^{2} \ge 0, \tag{9.5}$$

etc, where the second inequality is obvious and the first inequality follows from the polar decomposition of  $U \in SL(N,\mathbb{C})$ : U = VP, with  $V \in SU(N)$  and P a positive semidefinite hermitian matrix with  $\det P = 1$  [77]. Indeed, during a complex Langevin simulation these

norms become nonzero, as demonstrated in Fig. 21 for QCD in the presence of static quarks for two values of the chemical potential  $\mu$ .

Intuition says that during a simulation the evolution should be controlled in the following way: configurations should stay close to the SU(N) submanifold

- when the chemical potential  $\mu$  is small;
- when small nonunitary initial conditions are introduced;
- in the presence of roundoff errors.

In practice however, it turns out that this is not the case and the unitary submanifold is unstable. This observation has been made one way or the other several times in the past, but the relation between this and the breakdown of the approach – convergence to incorrect results – is fairly recent and follows from the combination of theoretical and numerical ideas [59, 60, 75]. Given what we learnt in previous sections, a simple way to test whether this instability arises is to study analyticity (or lack thereof) of observables around  $\mu^2 \sim 0$ .

## 9.1. Gauge cooling

The instability of the SU(N) submanifold is related to gauge freedom. Consider a link at site k, which transforms as

$$U_k \to \Omega_k U_k \Omega_{k+1}^{-1}, \qquad \qquad \Omega_k = e^{i\omega_a^k \lambda_a},$$
 (9.6)

with  $\omega_a^k$  the gauge parameters. Note that in  $\mathrm{SU}(N)$ ,  $\omega_a^k \in \mathbb{R}$ , while in  $\mathrm{SL}(N,\mathbb{C})$ ,  $\omega_a^k \in \mathbb{C}$ . While unitary gauge transformations preserve the unitarity norms,  $\mathrm{SL}(N,\mathbb{C})$  transformations with  $\omega_a^k$  nonreal do not. In fact, those transformations can make the unitarity norms increase out of bounds, leading to broad undesirable distributions.

Having made this observation, one can use it in a constructive manner. It is possible to devise gauge transformations that *reduce* the unitarity norms and hence control the Langevin evolution. This goes under the name *gauge cooling* [75]. We hence consider

$$U_k \to \Omega_k U_k \Omega_{k+1}^{-1}, \qquad \qquad \Omega_k = e^{-\alpha f_a^k \lambda_a}, \qquad \qquad \alpha > 0,$$
 (9.7)

or, similarly, a cooling update at site k,

$$U_k \to \Omega_k U_k, \qquad U_{k-1} \to U_{k-1} \Omega_k^{-1}.$$
 (9.8)

Let us consider the effect of this on the unitarity norm

$$d = \sum_{k} \frac{1}{N} \operatorname{Tr} \left( U_k U_k^{\dagger} - 1 \right). \tag{9.9}$$

After one update and linearising in  $\alpha$ , we find

$$d' - d = -\frac{\alpha}{N} (f_a^k)^2 + \mathcal{O}(\alpha^2) \le 0,$$
 (9.10)

i.e. the distance from SU(N) has indeed been reduced, see Fig. 22.

Up to now, we have not defined  $f_a^k$ . One possibility is to choose it as the gradient of the unitarity norm itself, i.e.

$$f_a^k = 2 \operatorname{Tr} \lambda_a \left( U_k U_k^{\dagger} - U_{k-1}^{\dagger} U_{k-1} \right). \tag{9.11}$$

Hence when  $U \in SU(N)$ , we find that  $f_a^k = 0$  and cooling has no effect, as it should be.

![](_page_31_Picture_1.jpeg)

**Figure 22.** Gauge cooling of links in  $SL(N, \mathbb{C})$  reduces the distance from SU(N). The left orbit is equivalent to a SU(N) configuration, while the one on the right is not [79].

<span id="page-31-0"></span>We will now demonstrate this in a simple one-link example [79], with the action and gauge freedom,

$$S = \frac{1}{N} \operatorname{Tr} U, \qquad U \to \Omega U \Omega^{-1}. \tag{9.12}$$

The distance d and gauge cooling function  $f_a$  are

$$d = \frac{1}{N} \operatorname{Tr} \left( U U^{\dagger} - 1 \right), \qquad f_a = 2 \operatorname{Tr} \lambda_a \left( U U^{\dagger} - U^{\dagger} U \right). \tag{9.13}$$

In this simple model, the trace of U is invariant under cooling and hence c = Tr U/N and  $c^* = \text{Tr } U^{\dagger}/N$  are preserved. After one cooling update, we find that

$$\mathbf{d}' - \mathbf{d} = -\frac{\alpha}{N} f_a^2 = -\frac{16\alpha}{N} \operatorname{Tr} U U^{\dagger} [U, U^{\dagger}]. \tag{9.14}$$

Specialising now to SU(2) and  $SL(2,\mathbb{C})$ , while taking the continuous cooling-time limit,  $d' - d \rightarrow d$ , we find the cooling equation

<span id="page-31-1"></span>
$$\dot{\mathbf{d}} = -8\alpha \left( \mathbf{d}^2 + 2\left( 1 - |c|^2 \right) \mathbf{d} + c^2 + c^{*2} - 2|c|^2 \right), \tag{9.15}$$

expressed in terms of the invariants c and  $c^*$ . We can now consider two cases:

•  $c = c^*$ : U is gauge equivalent to an SU(2) matrix. Eq. (9.15) simplifies to

$$\dot{\mathbf{d}} = 8\alpha(\mathbf{d} + 2 - 2c^2)\mathbf{d},$$
 (9.16)

with the asymptotic solution

$$d(t) \sim e^{-16\alpha(1-c^2)t} \to 0,$$
 (9.17)

i.e. the distance vanishes, as expected

•  $c \neq c^*$ : U is not gauge equivalent to an SU(2) matrix. Hence there is a minimal distance from the SU(2) submanifold, given by the fixed point of Eq. (9.15),

$$d(t) \to d_0 = |c|^2 - 1 + \sqrt{1 - c^2 - c^{*2} + |c|^4} > 0, \tag{9.18}$$

which is again reached exponentially fast.

This demonstrates the idea behind gauge cooling in a simple, analytically solvable example. It should be noted that for many links the approach to the minimal distance is no longer exponential but appears to follow a power law [79]. Finally, the parameter  $\alpha$  can be chosen adaptively, to optimise the numerical implementation [79,80].

## 9.2. Complex Langevin dynamics with gauge cooling for QCD

In QCD the unitary submanifold is unstable. Even in SU(3) gauge theory, without a complex action, links will not remain unitary when Langevin updates are employed, due to roundoff errors. These are of course also present in other algorithms, but for simulations of theories with a real action they can be easily controlled, namely by occasionally re-unitarising the links, i.e. projecting them back into SU(3). However, this option is not available when the action is complex and links *should* be outside of SU(3). Hence, it becomes necessary to use an alternative manner to control the exploration and this is provided by gauge cooling. In practice Langevin updates and cooling updates are alternated, with considerable freedom in the number of cooling steps, and choosing both the gauge cooling parameter and the Langevin stepsize adaptively.

This approach [75] was first applied to heavy dense QCD, i.e. SU(3) gauge theory in the presence of heavy quarks. Since the (anti)quarks are static, they are represented by (conjugate) Polyakov loops, and the fermion determinant for a single flavour takes on a simple form [77],

<span id="page-32-1"></span>
$$\det M = \prod_{\mathbf{x}} \det \left( 1 + he^{\mu/T} \mathcal{P}(\mathbf{x}) \right)^2 \left( 1 + he^{-\mu/T} \mathcal{P}^{-1}(\mathbf{x}) \right)^2, \tag{9.19}$$

where the remaining determinant is in colour space only,  $\mathcal{P}$  is the untraced Polyakov loop,

$$\mathcal{P}(\mathbf{x}) = \prod_{\tau=0}^{N_{\tau}-1} U_4(\tau, \mathbf{x}), \tag{9.20}$$

and  $h=(2\kappa)^{N_\tau}$  is related to the quark mass via  $m_q=-\ln(2\kappa)$  at leading order in the hopping expansion considered here. The determination of the phase diagram using this approach is in progress and a recent status report can be found in Ref. [81]. It should be noted that gauge cooling stops being effective when the gauge coupling  $\beta$  is chosen too small [75], i.e. on a coarse lattice. Since ultimately one has to reduce the lattice spacing (increase the gauge coupling  $\beta$ ), this is no problem in principle, but it rules out tests on small lattices. It also stimulates the search for alternatives to gauge cooling.

The first application to full QCD, i.e. with dynamical quarks, can be found in Ref. [82]. This constitutes a major step forward. In Ref. [68] results in full QCD were subsequently compared with those obtained in QCD using a hopping parameter expansion to all orders, and in Ref. [83] with reweighting. Finally, complex Langevin dynamics has also been applied to SU(3) gauge theory in the presence of a nonzero  $\theta$ -term [84].

As stated above, this topic is in continuous development and hence it is premature to discuss physically relevant results in detail at this stage. Two outstanding problems concern the treatment of poles in the drift, present due to the logarithm of the fermion determinant in the effective action, and the breakdown of gauge cooling at small  $\beta$ .

## <span id="page-32-0"></span>10. Other approaches

There are more approaches under development to tackle the sign problem than I was able to cover in the lectures. This final section contains a partial list of other methods that are currently being studied and does not aspire to be complete. Its main message should be the variety of ideas and proposals that are available and hence the richness of the subject. Some of these proposals, and some others, are reviewed a bit more extensively in Refs. [85, 86].

#### 10.1. Changing the order of integration, strong coupling

As we saw throughout these lectures, it is the complex fermion determinant at nonzero chemical potential that leads to the sign problem. Hence it makes sense not to integrate out the fermions first but instead perform the integral over the gauge links. Since the gauge sector is an interacting

theory by itself, this cannot be done exactly. One possible starting point is to consider the strong-coupling limit, where the gauge coupling  $\beta = 2N_c/g^2$ , the coefficient of the plaquette in the (Yang-Mills) action, is taken to zero. The gluonic path integral now factorises into the product of one-link integrals, which can be done analytically. The resulting partition function has a very physical representation in terms of worldlines of mesons and baryons (Monomer-Dimer-Polymer (MDP) system) [87], which can be studied [88,89] using efficient worm-type algorithms [90]. In order to go beyond the strong-coupling limit, one may include the first  $\mathcal{O}(\beta)$  corrections [91], or include the plaquettes by integrating them in steps, via the introduction of auxiliary fields [92–95].

Another possibility is to combine the strong coupling expansion with the hopping expansion for quarks (an expansion in the inverse mass), to construct effective models amenable to numerical simulations [96]. The determinant at leading order in the hopping expansion was already presented in Eq. (9.19). Going to higher order cures a number of deficits of the static limit and gives access to the onset to cold dense matter for heavy quarks [97].

#### 10.2. Dual formulations

A related approach uses a strong-coupling expansion to all orders. This method is not easily applicable to nonabelian gauge theories, but has been very successful in abelian theories and spin models. For illustration, consider the three-dimensional SU(3) spin model, an effective model for QCD at nonzero temperature and density [73]. The action is written as

$$S = S_B + S_F, \tag{10.1}$$

with

$$S_B = -\beta \sum_{\langle xy \rangle} \left[ P_x P_y^* + P_x^* P_y \right], \qquad S_F = -h \sum_x \left[ e^{\mu} P_x + e^{-\mu} P_x^* \right]. \tag{10.2}$$

The degrees of freedom are effective Polyakov loops,  $P_x = \text{Tr } U_x$ ,  $P_x^* = \text{Tr } U_x^{\dagger}$ , where the  $U_x$ 's are SU(3) matrices, living on a three-dimensional lattice. Static (anti)quarks are represented by (conjugate) Polyakov loops, weighted with the chemical potential to introduce an imbalance. Note that  $S^*(\mu) = S(-\mu^*)$ . Expanding the Boltzmann weight to all orders, as in a classical high-temperature expansion, yields a representation of the partition function containing terms of the following form [98]

$$I(n_x, \bar{n}_x) = \int_{SU(3)} dU_x \left( \operatorname{Tr} U_x \right)^{n_x} \left( \operatorname{Tr} U_x^{\dagger} \right)^{\bar{n}_x}.$$
 (10.3)

Crucially, it is now possible to perform these single-site SU(3) integrals, yielding again a monomer-dimer system with constraints, since  $I(n_x, \bar{n}_x)$  is only nonzero provided  $(n_x - \bar{n}_x)$  mod 3 = 0. It turns out that all the nonzero weights that appear in this representation are real and positive, even when  $\mu \neq 0$ . These, and similar, models can then be solved with importance sampling or a worm algorithm, see Ref. [8] for a review.

#### 10.3. Density of states, histograms

In the approach known as density of states, factorisation, histogram method or Wang-Landau [99–106], the idea is to evaluate the path integral in two stages. At the first stage one evaluates a constrained integral with one degree of freedom fixed. At the second stage the remaining integral over the resulting probability distribution – the density of states – constructed in the first step, is performed. The density of the states can be obtained by constructing histograms during the constrained simulation. For example, if P denotes the degree of freedom that is kept

fixed (e.g. the plaquette, action density or Polyakov loop), then the (unnormalised) density of states is given by

$$w(P) = \int DU \,\delta(P - P') \,e^{-S_{\text{YM}}} \det M, \tag{10.4}$$

where P ′ is the value of P taken during the simulation. The expectation value of P is then determined by the simple integrals

$$\langle P \rangle = \frac{1}{Z} \int dP \, w(P) P, \qquad Z = \int dP \, w(P).$$
 (10.5)

The main issues in this approach are

- (i) the contrained integral should have a positive weight, so that it can be determined unambiguously;
- (ii) the weight w(P) should be computable to very high *relative* precision;
- (iii) the remaining integral should be doable, which may be nontrivial due to the sign problem. Recently promising results have been obtained with improvements [\[106](#page-44-6)[–109\]](#page-44-7) of the Wang-Landau algorithm [\[110\]](#page-44-8).

## *10.4. Lefschetz thimbles*

In complex Langevin dynamics, a complexified configuration space is explored, relying on holomorphicity of the theory under consideration. This arises naturally in the simpler integrals considered earlier, which are often evaluated using steepest-descent or stationary-phase approximations, with saddle points in the complex plane. This can be made mathematically very precise using integration along so-called Lefschetz thimbles [\[111\]](#page-44-9). The numerical implementation of this idea for QCD and other field theories was proposed in Ref. [\[112\]](#page-44-10).

In this approach the integration path is deformed such that it passes through the fixed (or critical) points of the complex action. The integration contour follows paths of steepest descent, along which the imaginary part of the action is constant; these are the (stable) thimbles J . For one degree of freedom and one saddle point, this amounts to writing

$$Z = \int dx \, e^{-S(x)} = e^{-i \text{Im} \, S_{\mathcal{J}}} \int_{\mathcal{J}} dz \, e^{-\text{Re} \, S(z)}$$
$$= e^{-i \text{Im} \, S_{\mathcal{J}}} \int ds \, J(s) e^{-\text{Re} \, S(z(s))}, \qquad J(s) = x'(s) + i y'(s). \tag{10.6}$$

Since the imaginary part of the action is constant along the thimble, it can be taken out of the integral. Two sign problems remain in this formulation: in the second line we have parametrised the thimble in terms of z(s) = x(s) + iy(s), resulting in a complex jacobian J(s) in general. This yields a residual sign problem, which may however be milder than the original one [\[112\]](#page-44-10). The second sign problem arises if more than one critical point contributes and the associated thimbles differ in their phases. The partition function is then a sum over thimbles and

$$Z = \sum_{k} m_k e^{-i\operatorname{Im} S_{\mathcal{J}_k}} \int_{\mathcal{J}_k} dz \, e^{-\operatorname{Re} S(z)}, \tag{10.7}$$

with m<sup>k</sup> the so-called intersection number. How to treat these global phases numerically is not clear yet, but based on universality it has been conjectured that a single saddle point (e.g. the perturbative one) suffices [\[112\]](#page-44-10). This is often not the case in simpler models, but it should be noted that these models will typically lack universality. Lefschetz thimbles for lattice models are currently actively being studied, from a number of angles: residual sign problem and numerical algorithms [\[113–](#page-44-11)[117\]](#page-44-12); thimble structure and the global sign problem in simple models [\[118–](#page-44-13)[120\]](#page-44-14); and a comparison with complex Langevin dynamics [\[121,](#page-44-15)[122\]](#page-44-16), including the role of zeroes of the determinant [\[123\]](#page-44-17).

#### <span id="page-35-0"></span>11. Conclusion

In these lectures a basic introduction to lattice QCD at nonzero chemical potential was given. This topic is extremely rich and this overview is therefore by necessity incomplete. Yet, the hope is that with the foundation provided here current research papers will be accessible to a newcomer in the field. In the second part new methods to evade the sign problem altogether were discussed, in particular complex Langevin dynamics. These approaches are still very much in development and hence a conclusion or consensus has not yet been reached, let alone a complete determination of the QCD phase diagram. The upshot of this is that there is still a lot of scope for input, progress and clever ideas, which, combined with the increase of computing power, may eventually result in the QCD phase diagram.

#### Acknowledgements

It is a pleasure to thank the organisers – especially Marcelo Chiapparini –, the participants and the other lecturers for the excellent meeting in a pleasant environment. Special thanks go to Awena Jones. Over the past years, I have learnt about QCD at nonzero chemical potential from many people. In particular I would like to thank Simon Hands, Nucu Stamatescu, Erhard Seiler, Dénes Sexty, Kim Splittorff, Philippe de Forcrand and Owe Philipsen. My work is supported by STFC under grant ST/L000369/1, the Royal Society and the Wolfson Foundation.

#### <span id="page-35-1"></span>Appendix A. Relativistic Bose gas at nonzero chemical potential

Consider a self-interacting complex scalar field in the presence of a chemical potential  $\mu$ , with the continuum action

<span id="page-35-2"></span>
$$S = \int d^4x \left[ |\partial_{\nu}\phi|^2 + (m^2 - \mu^2)|\phi|^2 + \mu \left(\phi^* \partial_4 \phi - \partial_4 \phi^* \phi\right) + \lambda |\phi|^4 \right]. \tag{A.1}$$

The euclidean action is complex and satisfies  $S^*(\mu) = S(-\mu^*)$ . Take  $m^2 > 0$ , so that at vanishing and small  $\mu$  the theory is in its symmetric phase.

The lattice action, with lattice spacing  $a_{\text{lat}} \equiv 1$ , is

$$S = \sum_{x} \left[ \left( 2d + m^{2} \right) \phi_{x}^{*} \phi_{x} + \lambda \left( \phi_{x}^{*} \phi_{x} \right)^{2} - \sum_{\nu=1}^{4} \left( \phi_{x}^{*} e^{-\mu \delta_{\nu,4}} \phi_{x+\hat{\nu}} + \phi_{x+\hat{\nu}}^{*} e^{\mu \delta_{\nu,4}} \phi_{x} \right) \right], \tag{A.2}$$

where the number of euclidean dimensions is d = 4.

- i) Show that this action reduces to (A.1) in the continuum limit.
- ii) The complex field is written in terms of two real fields  $\phi_a$  (a = 1, 2) as  $\phi = \frac{1}{\sqrt{2}}(\phi_1 + i\phi_2)$ . Show that the lattice action then reads

<span id="page-35-3"></span>
$$S = \sum_{x} \left[ \frac{1}{2} \left( 2d + m^{2} \right) \phi_{a,x}^{2} + \frac{\lambda}{4} \left( \phi_{a,x}^{2} \right)^{2} - \sum_{i=1}^{3} \phi_{a,x} \phi_{a,x+\hat{i}} - \cosh \mu \, \phi_{a,x} \phi_{a,x+\hat{4}} + i \sinh \mu \, \varepsilon_{ab} \phi_{a,x} \phi_{b,x+\hat{4}} \right], \tag{A.3}$$

where  $\varepsilon_{ab}$  is the antisymmetric tensor with  $\epsilon_{12} = 1$ , and summation over repeated indices is implied. Note that the 'sinh  $\mu$ ' term is complex.

From now on the self-interaction is ignored and we take  $\lambda = 0$ . After going to momentum space, the action (A.3) reads

<span id="page-35-4"></span>
$$S = \sum_{p} \frac{1}{2} \phi_{a,-p} \left( \delta_{ab} A_p - \varepsilon_{ab} B_p \right) \phi_{b,p} = \sum_{p} \frac{1}{2} \phi_{a,-p} M_{ab,p} \phi_{b,p}, \tag{A.4}$$

where

$$M_p = \begin{pmatrix} A_p & -B_p \\ B_p & A_p \end{pmatrix}, \tag{A.5}$$

and

$$A_p = m^2 + 4\sum_{i=1}^{3} \sin^2 \frac{p_i}{2} + 2(1 - \cosh \mu \cos p_4), \qquad B_p = 2\sinh \mu \sin p_4. \tag{A.6}$$

iii) Show that the propagator corresponding to the action (A.4) is

$$G_{ab,p} = \frac{\delta_{ab}A_p + \varepsilon_{ab}B_p}{A_p^2 + B_p^2}. (A.7)$$

iv) Demonstrate that the dispersion relation that follows from the poles of the propagator, taking  $p_4 = iE_{\mathbf{p}}$ , reads

$$\cosh E_{\mathbf{p}}(\mu) = \cosh \mu \left( 1 + \frac{1}{2} \hat{\omega}_{\mathbf{p}}^2 \right) \pm \sinh \mu \sqrt{1 + \frac{1}{4} \hat{\omega}_{\mathbf{p}}^2}, \tag{A.8}$$

where

$$\hat{\omega}_{\mathbf{p}}^2 = m^2 + 4\sum_{i} \sin^2 \frac{p_i}{2}.$$
 (A.9)

v) Show that this can be written as

$$\cosh E_{\mathbf{p}}(\mu) = \cosh \left[ E_{\mathbf{p}}(0) \pm \mu \right], \tag{A.10}$$

such that the (positive energy) solutions are

$$E_{\mathbf{p}}(\mu) = E_{\mathbf{p}}(0) \pm \mu. \tag{A.11}$$

Sketch the spectrum. Note that the critical  $\mu$  value for onset is  $\mu_c = E_0(0)$ , so that one mode becomes exactly massless at the transition (Goldstone boson).

vi) The phase-quenched theory corresponds to  $\sinh \mu = B_p = 0$ . Show that the dispersion relation in the phase-quenched theory is

$$\cosh E_{\mathbf{p}}(\mu) = \frac{1}{\cosh \mu} \left( 1 + \frac{1}{2} \hat{\omega}_{\mathbf{p}}^2 \right), \tag{A.12}$$

which corresponds to  $E_{\mathbf{p}}^{2}(\mu) = m^{2} - \mu^{2} + \mathbf{p}^{2}$  in the continuum limit.

vii) Compare the spectrum of the full and the phase-quenched theory, when  $\mu < \mu_c$ . At larger  $\mu$ , it is necessary to include the self-interaction to stabilize the theory. Based on what you know about symmetry breaking, sketch the spectrum in the full and the phase-quenched theory at larger  $\mu$  as well.

Although the spectrum depends on  $\mu$ , thermodynamic quantities do not. Up to an irrelevant constant, the logarithm of the partition function is

$$\ln Z = -\frac{1}{2} \sum_{p} \ln \det M = -\frac{1}{2} \sum_{p} \ln(A_p^2 + B_p^2), \tag{A.13}$$

and some observables are given by

$$\langle |\phi|^2 \rangle = -\frac{1}{\Omega} \frac{\partial \ln Z}{\partial m^2} = \frac{1}{\Omega} \sum_p \frac{A_p}{A_p^2 + B_p^2},$$
 (A.14)

and

$$\langle n \rangle = \frac{1}{\Omega} \frac{\partial \ln Z}{\partial \mu} = -\frac{1}{\Omega} \sum_{p} \frac{A_p A_p' + B_p B_p'}{A_p^2 + B_p^2}, \tag{A.15}$$

where  $\Omega = N_{\sigma}^3 N_{\tau}$  and  $A'_p = \partial A_p / \partial \mu$ ,  $B'_p = \partial B_p / \partial \mu$ .

viii) Evaluate the sums (e.g. numerically) to demonstrate that thermodynamic quantities are independent of  $\mu$  in the thermodynamic limit at vanishing temperature. This exercise is based on Ref. [124].

## <span id="page-37-0"></span>Appendix B. One-dimensional QCD

Consider QCD in one (temporal) dimension, with the staggered fermion action

$$S = \sum \bar{\chi}(D+m)\chi = \sum_{x=1}^{n} \left[ \frac{1}{2} \bar{\chi}_{x} e^{\mu} U_{x,x+1} \chi_{x+1} - \frac{1}{2} \bar{\chi}_{x+1} e^{-\mu} U_{x,x+1}^{\dagger} \chi_{x} + m \bar{\chi}_{x} \chi_{x} \right].$$
 (B.1)

Here n denotes the number of points in the time direction and is taken to be even. The quarks obey anti-periodic boundary conditions. The links  $U_{x,x+1}$  are elements of U(N) or SU(N) and transform as  $U_{x,x+1} \to \Omega_x U_{x,x+1} \Omega_{x+1}^{\dagger}$ .

Via a unitary transformation, all links but one can be transformed away ("temporal gauge"), i.e.  $U_{n,1} \equiv U$ , all other U's are unity. The determinant can then be written, up to an overall constant, as [126,127]

$$\det(D+m) = \det_C \left( e^{n\mu_c} + e^{-n\mu_c} + e^{n\mu}U + e^{-n\mu}U^{\dagger} \right).$$
 (B.2)

The remaining determinant is in colour space and  $\mu_c$  is related to the mass m as

$$m = \sinh \mu_c. \tag{B.3}$$

The reason for introducing  $\mu_c$  will become clear below.

- i) Show that the determinant has the usual symmetry under complex conjugation.
- ii) In one dimension, the partition function is simply

$$Z_{N_f} = \int dU \, \det^{N_f} (D+m) \,, \tag{B.4}$$

since there is no Yang-Mills action. From now on we take as gauge group U(1): this captures all the essential characteristics in one dimension but also allows one to do the group integral without any effort. We hence write

$$U = e^{i\phi}, \qquad \int dU = \int_0^{2\pi} \frac{d\phi}{2\pi}. \tag{B.5}$$

Show that the partition function for  $N_f = 2$  is independent of  $\mu$  and equal to

$$Z_{N_f=2} = 4 + 2\cosh(2n\mu_c).$$
 (B.6)

Note that the  $\mu$  independence is generic in  $\mathrm{U}(N)$  theories, since  $\mu$  can be absorbed in the  $\mathrm{U}(1)$  phase (take  $\mu$  to be imaginary for this). This is of course not possible in  $\mathrm{SU}(N)$  theories, where there is no such freedom.

iii) Show that the phase-quenched  $N_f=2$  partition function depends on  $\mu$  and equals

$$Z_{N_f=1+1^*} = \int dU |\det(D+m)|^2 = \int dU \det(D(\mu) + m) \det(D(-\mu) + m)$$
  
= 2 + 2 \cosh(2n\mu\_c) + 2 \cosh(2n\mu). (B.7)

iv) The chiral condensate and the number density are defined by

$$\Sigma = \frac{1}{n} \frac{\partial \ln Z}{\partial m}, \qquad \langle n_B \rangle = \frac{1}{n} \frac{\partial \ln Z}{\partial \mu}.$$
 (B.8)

Show that in the full theory one finds

$$\Sigma = \frac{2\sinh(2n\mu_c)}{2 + \cosh(2n\mu_c)} \frac{1}{\cosh\mu_c} \to \frac{2\operatorname{sgn}(\mu_c)}{\cosh\mu_c}, \qquad \langle n_B \rangle = 0.$$
 (B.9)

The arrow denotes the thermodynamic limit  $n \to \infty$ . The  $\mu$  independence is obvious.

v) Show that in the phase-quenched theory one finds on the other hand

$$\Sigma = \frac{2\sinh(2n\mu_c)}{1 + \cosh(2n\mu_c) + \cosh(2n\mu)} \frac{1}{\cosh \mu_c} \to \begin{cases} \frac{2\text{sgn}(\mu_c)}{\cosh \mu_c} & |\mu| < |\mu_c| \\ 0 & |\mu| > |\mu_c| \end{cases},$$
(B.10)

and

$$\langle n_B \rangle = \frac{2 \sinh(2n\mu)}{1 + \cosh(2n\mu_c) + \cosh(2n\mu)} \to \begin{cases} 0 & |\mu| < |\mu_c| \\ 2 \operatorname{sgn}(\mu) & |\mu| > |\mu_c| \end{cases}$$
 (B.11)

The full and phase-quenched theories agree when  $\mu < \mu_c$  (no  $\mu$  dependence). The phasequenched theory undergoes a phase transition at  $\mu = \mu_c$ , where the density jumps to 2. The interesting region in view of the Silver Blaze problem is therefore this large  $\mu$  region, where the sign problem is severe and the average phase factor vanishes in the thermodynamic limit:

$$\langle e^{2i\varphi} \rangle_{\text{pq}} = \frac{Z_{N_f=2}}{Z_{N_f=1+1^*}} \to 0, \qquad \det(D+m) = e^{i\varphi} |\det(D+m)|.$$
 (B.12)

vi) The eigenvalues of D are

$$\lambda_k = \frac{1}{2} e^{i(2\pi(k + \frac{1}{2}) + \phi)/n + \mu} - \frac{1}{2} e^{-i(2\pi(k + \frac{1}{2}) + \phi)/n - \mu} \qquad (k = 1, \dots, n).$$
 (B.13)

The  $k + \frac{1}{2}$  arises from the antiperiodic boundary conditions and the  $\phi/n$  from uniformly distributing the link U over all links as  $U^{1/n}$ .

Demonstrate that the eigenvalues lie on an ellipse in the complex plane, determined by

$$\left(\frac{\operatorname{Re}\lambda_k}{\sinh(\mu)}\right)^2 + \left(\frac{\operatorname{Im}\lambda_k}{\cosh(\mu)}\right)^2 = 1.$$
(B.14)

The transition in the phase-quenched theory occurs when the quark mass gets inside this ellipse. vii) To compute the eigenvalue density,

$$\rho(z;\mu) = \frac{1}{Z_{N_f}} \int dU \, \det^{N_f}(D+m) \, \sum_k \delta^2(z-\lambda_k), \tag{B.15}$$

we therefore parametrize

$$z = \frac{1}{2} \left( e^{i\alpha + \mu} - e^{-i\alpha - \mu} \right), \tag{B.16}$$

such that

<span id="page-39-1"></span>
$$\Sigma = \int_0^{2\pi} \frac{d\alpha}{2\pi} \frac{\rho(\alpha; \mu)}{z(\alpha) + m}.$$
 (B.17)

One then finds, for  $N_f = 2$ ,

$$\rho(\alpha; \mu) = \frac{4 \left[ \cosh(n\mu_c) + \cosh(n(\mu + i\alpha)) \right]^2}{2 + \cosh(2n\mu_c)}.$$
(B.18)

Show that in the thermodynamic limit, the eigenvalue density behaves as

$$\rho(\alpha; \mu) = \begin{cases} 2 & |\mu| < |\mu_c| \\ 2e^{2n(|\mu| - |\mu_c| + i\alpha)} & |\mu| > |\mu_c| \end{cases},$$
(B.19)

i.e. it is well-behaved when the full and phase-quenched theories agree, but it is complex and oscillating with a divergent amplitude in the Silver Blaze region.

viii) Show that these oscillations are necessary to find a  $\mu$  independent chiral condensate by evaluating Eq. (B.17) explicitly (write  $e^{i\alpha} = w$  and use contour integration).

One-dimensional QCD is discussed in Refs. [125–127]. This exercise is based on Ref. [128].

## <span id="page-39-0"></span>Appendix C. Fokker-Planck equation

Consider the Langevin process

$$\dot{x}(t) = K[x(t)] + \eta(t), \qquad K(x) = -S'(x), \qquad \langle \eta(t)\eta(t')\rangle_{\eta} = 2\lambda\delta(t - t'), \tag{C.1}$$

where  $\lambda$  normalizes the noise. We want to derive the associated Fokker-Planck equation

<span id="page-39-3"></span>
$$\partial_t \rho(x,t) = \partial_x \left(\lambda \partial_x - K\right) \rho(x,t),\tag{C.2}$$

for the distribution  $\rho(x,t)$ , defined via

<span id="page-39-2"></span>
$$\langle O[x(t)] \rangle_{\eta} = \int dx \, \rho(x,t) O(x),$$
 (C.3)

with O(x) a generic observable. Here the subscript  $\eta$  denotes noise averaging and will be dropped from now on.

To achieve this we consider the discretized process

$$\delta_n \equiv x_{n+1} - x_n = \epsilon K_n + \sqrt{\epsilon} \eta_n, \qquad \langle \eta_n \eta_{n'} \rangle = 2\lambda \delta_{nn'}.$$
 (C.4)

i) Show that

$$\langle O(x_{n+1}) \rangle - \langle O(x_n) \rangle = \langle O'(x_n) \delta_n + \frac{1}{2} O''(x_n) \delta_n^2 + \ldots \rangle$$

$$= \epsilon \langle O'(x_n) K_n + \lambda O''(x_n) \rangle + \mathcal{O}(\epsilon^{3/2}). \tag{C.5}$$

In the  $\epsilon \to 0$  limit, this gives

$$\partial_t \langle O(x) \rangle = \langle O'(x)K(x) + \lambda O''(x) \rangle.$$
 (C.6)

ii) Use Eq. (C.3) to demonstrate that this yields the Fokker-Planck equation (C.2) for  $\rho(x,t)$ . What should  $\lambda$  be in order to obtain the desired equilibrium distribution?

iii) We now repeat the analysis for the complex Langevin equations.

$$\dot{x} = K_x + \eta_x, \qquad K_x = -\operatorname{Re} S'(z), \qquad \langle \eta_x(t)\eta_x(t') \rangle = 2\lambda_x \delta(t - t'), 
\dot{y} = K_y + \eta_y, \qquad K_y = -\operatorname{Im} S'(z), \qquad \langle \eta_y(t)\eta_y(t') \rangle = 2\lambda_y \delta(t - t'). \tag{C.7}$$

By writing z = x + iy, show that these Langevin equations are equivalent to

$$\dot{z} = -S'(z) + \eta,$$
  $\langle \eta(t)\eta(t')\rangle = 2\delta(t - t').$  (C.8)

Express  $\eta$  in terms of  $\eta_{x,y}$  and derive the necessary restrictions on  $\lambda_{x,y}$  (answer:  $\lambda_x - \lambda_y = 1$ ). The case  $\lambda_y > 0$  is referred to as complex noise.

iv) The distribution P(x, y; t) is now defined via

$$\langle O[x(t) + iy(t)] \rangle_{\eta} = \int dx dy \, P(x, y; t) O(x + iy). \tag{C.9}$$

Show that P(x, y; t) satisfies

$$\partial_t P(x, y; t) = \left[ \partial_x \left( \lambda_x \partial_x - K_x \right) + \partial_y \left( \lambda_y \partial_y - K_y \right) \right] P(x, y; t). \tag{C.10}$$

The case  $\lambda_x = 1$ ,  $\lambda_y = 0$  is used in the main text.

This is reviewed e.g. in Ref. [58]. Complex noise and especially its problems are discussed in Ref. [59].

## <span id="page-40-0"></span>Appendix D. Yet another Gaussian model

Consider the complex integral

$$Z = \int_{-\infty}^{\infty} dx \, \rho(x), \qquad \rho(x) = e^{-S}, \qquad S = \frac{1}{2}\sigma x^2, \qquad \sigma = a + ib. \tag{D.1}$$

i) Show that the corresponding complex Langevin equations are given by

$$\dot{x} = K_x + \eta, \qquad K_x = -ax + by, \tag{D.2}$$

$$\dot{y} = K_y, \qquad K_y = -ay - bx, \tag{D.3}$$

where  $\langle \eta(t)\eta(t')\rangle = 2\delta(t-t')$ .

ii) Demonstrate that these Langevin equations are solved by

$$x(t) = e^{-at} \left[ \cos(bt)x(0) + \sin(bt)y(0) \right] + \int_0^t ds \, e^{-a(t-s)} \cos[b(t-s)] \eta(s), \tag{D.4}$$

$$y(t) = e^{-at} \left[ \cos(bt)y(0) - \sin(bt)x(0) \right] - \int_0^t ds \, e^{-a(t-s)} \sin[b(t-s)]\eta(s). \tag{D.5}$$

iii) Show that the expectation values in the infinite time limit are given by

$$\langle x^2 \rangle = \frac{1}{2a} \frac{2a^2 + b^2}{a^2 + b^2}, \qquad \langle y^2 \rangle = \frac{1}{2a} \frac{b^2}{a^2 + b^2}, \qquad \langle xy \rangle = -\frac{1}{2} \frac{b}{a^2 + b^2}.$$
 (D.6)

iv) Demonstrate that this yields the desired result

$$\langle x^2 \rangle \to \langle (x+iy)^2 \rangle = \frac{a-ib}{a^2+b^2} = \frac{1}{a+ib} = \frac{1}{\sigma}.$$
 (D.7)

*v*) The Fokker-Planck equation for the (real and positive) weight P(x, y;t), defined via

$$\langle O(x(t) + iy(t)) \rangle = \int dx dy P(x, y; t) O(x + iy),$$
 (D.8)

is given by

$$\partial_t P(x, y; t) = \left[ \partial_x \left( \partial_x - K_x \right) - \partial_y K_y \right] P(x, y; t) \tag{D.9}$$

Since the original integral is Gaussian, the equilibrium distribution P(x, y) is also Gaussian and can be written as

$$P(x,y) = N \exp\left[-\alpha x^2 - \beta y^2 - 2\gamma xy\right], \qquad (D.10)$$

where N is a normalization constant.

Using the Fokker-Planck equation, show that the coefficients are given by

$$\alpha = a, \qquad \beta = a\left(1 + \frac{2a^2}{b^2}\right), \qquad \gamma = \frac{a^2}{b},$$
(D.11)

and demonstrate that this gives the previously computed expectation values

$$\langle x^2 \rangle = \frac{\int dx dy \, P(x, y) x^2}{\int dx dy \, P(x, y)},$$
 (D.12)

etc.

*vi*) From the equivalence

$$\int dx \,\rho(x)O(x) = \int dxdy \,P(x,y)O(x+iy),\tag{D.13}$$

it follows that the real distribution is related to the original complex one via

$$\rho(x) = \int dy P(x - iy, y). \tag{D.14}$$

Verify this explicitly (up to the undetermined normalization). This is simple version of the problem treated in Ref. [\[124\]](#page-44-18).

#### <span id="page-42-0"></span>References

- [1] J. B. Kogut and M. A. Stephanov, "The phases of quantum chromodynamics: From confinement to extreme environments," Camb. Monogr. Part. Phys. Nucl. Phys. Cosmol. 21 (2004).
- [2] K. Yagi, T. Hatsuda and Y. Miake, "Quark-gluon plasma: From big bang to little bang," Camb. Monogr. Part. Phys. Nucl. Phys. Cosmol. 23 (2005).
- <span id="page-42-2"></span><span id="page-42-1"></span>[3] K. Fukushima and T. Hatsuda, Rept. Prog. Phys. 74 (2011) 014001 [arXiv:1005.4814 [hep-ph]].
- [4] P. de Forcrand, PoS LAT **2009** (2009) 010 [arXiv:1005.0539 [hep-lat]].
- $[5] \ S. \ Gupta, \ PoS \ LATTICE \ {\bf 2010} \ (2010) \ 007 \ [arXiv:1101.0109 \ [hep-lat]].$
- [6] L. Levkova, PoS LATTICE **2011** (2011) 011 [arXiv:1201.1516 [hep-lat]].
- <span id="page-42-33"></span>[7] G. Aarts, PoS LATTICE **2012** (2012) 017 [arXiv:1302.3028 [hep-lat]].
- [8] C. Gattringer, PoS LATTICE **2013** (2014) 002 [arXiv:1401.7788 [hep-lat]].
- <span id="page-42-3"></span>[9] D. Sexty, PoS LATTICE **2014** (2014) 016 [arXiv:1410.8813 [hep-lat]].
- <span id="page-42-4"></span>[10] S. Borsanyi, arXiv:1511.06541 [hep-lat].
- [11] J. I. Kapusta and C. Gale, "Finite-temperature field theory: Principles and applications," Camb. Monogr. Math. Phys. (2006).
- <span id="page-42-5"></span>[12] J. Smit, "Introduction to quantum fields on a lattice: A robust mate," Cambridge Lect. Notes Phys. 15 (2002).
- <span id="page-42-7"></span><span id="page-42-6"></span>[13] C. Gattringer and C. B. Lang, "Quantum chromodynamics on the lattice," Lect. Notes Phys. 788 (2010).
- <span id="page-42-8"></span>[14] T. D. Cohen, Phys. Rev. Lett. **91** (2003) 222001 [hep-ph/0307089].
- <span id="page-42-9"></span>[15] P. Hasenfratz and F. Karsch, Phys. Lett. B 125 (1983) 308.
- [16] J. B. Kogut, H. Matsuoka, M. Stone, H. W. Wyld, S. H. Shenker, J. Shigemitsu and D. K. Sinclair, Nucl. Phys. B 225 (1983) 93.
- <span id="page-42-11"></span><span id="page-42-10"></span>[17] N. Bilić and R. V. Gavai, Z. Phys. C 23 (1984) 77.
- <span id="page-42-12"></span>[18] D. T. Son and M. A. Stephanov, Phys. Rev. Lett. 86 (2001) 592 [hep-ph/0005225].
- <span id="page-42-13"></span>[19] J. C. Osborn, K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. Lett. 94 (2005) 202001 [hep-th/0501210].
- [20] J. C. Osborn, K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. D 78 (2008) 065029 [arXiv:0805.1303 [hep-th]].
- [21] K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. Lett. 98 (2007) 031601 [hep-lat/0609076].
- <span id="page-42-14"></span>[22] K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. D 75 (2007) 116003 [hep-lat/0702011 [HEP-LAT]].
- <span id="page-42-15"></span>[23] K. Splittorff and J. J. M. Verbaarschot, Phys. Rev. D 77 (2008) 014514 [arXiv:0709.2218 [hep-lat]].
- <span id="page-42-16"></span>[24] Y. Aoki, G. Endrődi, Z. Fodor, S. D. Katz and K. K. Szabo, Nature 443 (2006) 675 [hep-lat/0611014].
- [25] M. A. Stephanov, Prog. Theor. Phys. Suppl. **153** (2004) 139 [Int. J. Mod. Phys. A **20** (2005) 4387] [hep-ph/0402115].
- <span id="page-42-17"></span>[26] C. R. Allton, S. Ejiri, S. J. Hands, O. Kaczmarek, F. Karsch, E. Laermann, C. Schmidt and L. Scorzato, Phys. Rev. D 66 (2002) 074507 [hep-lat/0204010].
- <span id="page-42-19"></span><span id="page-42-18"></span>[27] P. de Forcrand and O. Philipsen, Nucl. Phys. B 642 (2002) 290 [hep-lat/0205016].
- <span id="page-42-20"></span>[28] R. V. Gavai and S. Gupta, Phys. Rev. D 71 (2005) 114014 [hep-lat/0412035].
- [29] I. M. Barbour, S. E. Morrison, E. G. Klepfish, J. B. Kogut and M. -P. Lombardo, Nucl. Phys. Proc. Suppl. 60A (1998) 220 [hep-lat/9705042].
- <span id="page-42-22"></span><span id="page-42-21"></span>[30] Z. Fodor and S. D. Katz, JHEP 0203 (2002) 014 [hep-lat/0106002].
- <span id="page-42-23"></span>[31] Z. Fodor and S. D. Katz, JHEP **0404** (2004) 050 [hep-lat/0402006].
- <span id="page-42-24"></span>[32] K. Splittorff, PoS LAT **2006** (2006) 023 [hep-lat/0610072].
- [33] C. R. Allton, M. Döring, S. Ejiri, S. J. Hands, O. Kaczmarek, F. Karsch, E. Laermann and K. Redlich, Phys. Rev. D 71 (2005) 054508 [hep-lat/0501030].
- [34] O. Kaczmarek et al., Phys. Rev. D 83 (2011) 014504 [arXiv:1011.3130 [hep-lat]].
- <span id="page-42-25"></span>[35] G. Endrődi, Z. Fodor, S. D. Katz and K. K. Szabo, JHEP 1104 (2011) 001 [arXiv:1102.1356 [hep-lat]].
- [36] S. Borsányi, G. Endrődi, Z. Fodor, S. D. Katz, S. Krieg, C. Ratti and K. K. Szabo, JHEP 1208 (2012) 053 [arXiv:1204.6710 [hep-lat]].
- <span id="page-42-29"></span><span id="page-42-26"></span>[37] M.-P. Lombardo, Nucl. Phys. Proc. Suppl. 83 (2000) 375 [hep-lat/9908006].
- [38] M. D'Elia and M. -P. Lombardo, Phys. Rev. D 67 (2003) 014505 [hep-lat/0209146].
- <span id="page-42-30"></span>[39] P. de Forcrand and O. Philipsen, Nucl. Phys. B 673 (2003) 170 [hep-lat/0307020].
- [40] P. de Forcrand and O. Philipsen, JHEP 0811 (2008) 012 [arXiv:0808.1096 [hep-lat]].
- [41] P. Cea, L. Cosmai, M. D'Elia, A. Papa and F. Sanfilippo, Phys. Rev. D 85 (2012) 094512 [arXiv:1202.5700 [hep-lat]].
- <span id="page-42-27"></span>[42] C. Bonati, P. de Forcrand, M. D'Elia, O. Philipsen and F. Sanfilippo, Phys. Rev. D 90 (2014) 7, 074030 [arXiv:1408.5086 [hep-lat]].
- <span id="page-42-31"></span><span id="page-42-28"></span>[43] M. D'Elia, PoS LATTICE **2014** (2015) 020 [arXiv:1502.06047 [hep-lat]].
- <span id="page-42-32"></span>[44] A. Roberge and N. Weiss, Nucl. Phys. B 275 (1986) 734.
- [45] M. D'Elia and F. Sanfilippo, Phys. Rev. D 80 (2009) 111501 [arXiv:0909.0254 [hep-lat]].

- <span id="page-43-1"></span><span id="page-43-0"></span>[46] P. de Forcrand and O. Philipsen, Phys. Rev. Lett. 105 (2010) 152001 [arXiv:1004.3144 [hep-lat]].
- <span id="page-43-2"></span>[47] G. 't Hooft, Nucl. Phys. B 138 (1978) 1.
- <span id="page-43-3"></span>[48] A. M. Polyakov, Phys. Lett. B **72** (1978) 477.
- <span id="page-43-4"></span>[49] L. Susskind, Phys. Rev. D 20 (1979) 2610.
- [50] C. Bonati, P. de Forcrand, M. D'Elia, O. Philipsen and F. Sanfilippo, PoS LATTICE 2011 (2011) 189 [arXiv:1201.2769 [hep-lat]].
- <span id="page-43-6"></span><span id="page-43-5"></span>[51] S. Kim, P. de Forcrand, S. Kratochvila and T. Takaishi, PoS LAT 2005 (2006) 166 [hep-lat/0510069].
- <span id="page-43-7"></span>[52] J. Langelage and O. Philipsen, JHEP 1001 (2010) 089 [arXiv:0911.2577 [hep-lat]].
- <span id="page-43-8"></span>[53] M. G. Alford, S. Chandrasekharan, J. Cox and U. J. Wiese, Nucl. Phys. B 602 (2001) 61 [hep-lat/0101012].
- [54] J. W. Chen, K. Fukushima, H. Kohyama, K. Ohnishi and U. Raha, Phys. Rev. D 80 (2009) 054012 [arXiv:0901.2407 [hep-ph]].
- <span id="page-43-10"></span><span id="page-43-9"></span>[55] G. Parisi, Phys. Lett. B 131 (1983) 393.
- [56] J. R. Klauder, Stochastic quantization, in: H. Mitter, C.B. Lang (Eds.), Recent Developments in High-Energy Physics, Springer-Verlag, Wien, 1983, p. 351; J. Phys. A: Math. Gen. 16 (1983) L317; Phys. Rev. A 29 (1984) 2036.
- <span id="page-43-12"></span><span id="page-43-11"></span>[57] G. Parisi and Y. -s. Wu, Sci. Sin. 24 (1981) 483.
- <span id="page-43-13"></span>[58] P. H. Damgaard and H. Hüffel, Phys. Rept. 152 (1987) 227.
- <span id="page-43-14"></span>[59] G. Aarts, E. Seiler and I. O. Stamatescu, Phys. Rev. D 81 (2010) 054508 [arXiv:0912.3360 [hep-lat]].
- [60] G. Aarts, F. A. James, E. Seiler and I. O. Stamatescu, Eur. Phys. J. C 71 (2011) 1756 [arXiv:1101.3270 [hep-lat]].
- <span id="page-43-16"></span><span id="page-43-15"></span>[61] G. Aarts and F. A. James, JHEP 1201 (2012) 118 [arXiv:1112.4655 [hep-lat]].
- [62] G. Aarts, F. A. James, E. Seiler and I. -O. Stamatescu, Phys. Lett. B 687 (2010) 154 [arXiv:0912.0617 [hep-lat]].
- <span id="page-43-18"></span><span id="page-43-17"></span>[63] J. Ambjorn and S. K. Yang, Phys. Lett. B 165 (1985) 140.
- <span id="page-43-19"></span>[64] J. Ambjorn, M. Flensburg and C. Peterson, Nucl. Phys. B 275 (1986) 375.
- <span id="page-43-20"></span>[65] G. Aarts and F. A. James, JHEP **1008** (2010) 020 [arXiv:1005.3468 [hep-lat]].
- <span id="page-43-21"></span>[66] G. Aarts, P. Giudice and E. Seiler, Annals Phys. 337 (2013) 238 [arXiv:1306.3075 [hep-lat]].
- <span id="page-43-22"></span>[67] A. Mollgaard and K. Splittorff, Phys. Rev. D 88 (2013) 11, 116007 [arXiv:1309.4335 [hep-lat]].
- [68] G. Aarts, E. Seiler, D. Sexty and I. O. Stamatescu, Phys. Rev. D 90 (2014) 11, 114505 [arXiv:1408.3770 [hep-lat]].
- [69] A. Mollgaard and K. Splittorff, Phys. Rev. D 91 (2015) 3, 036007 [arXiv:1412.2729 [hep-lat]].
- <span id="page-43-23"></span>[70] K. Splittorff, Phys. Rev. D **91** (2015) 3, 034507 [arXiv:1412.0502 [hep-lat]].
- <span id="page-43-24"></span>[71] J. Nishimura and S. Shimasaki, Phys. Rev. D 92 (2015) 1, 011501 [arXiv:1504.08359 [hep-lat]].
- <span id="page-43-25"></span>[72] G. Aarts, Phys. Rev. Lett. **102** (2009) 131601 [arXiv:0810.2089 [hep-lat]].
- <span id="page-43-26"></span>[73] F. Karsch and H. W. Wyld, Phys. Rev. Lett. **55** (1985) 2242.
- [74] G. Aarts, F. A. James, J. M. Pawlowski, E. Seiler, D. Sexty and I. O. Stamatescu, JHEP 1303 (2013) 073 [arXiv:1212.5231 [hep-lat]].
- <span id="page-43-28"></span><span id="page-43-27"></span>[75] E. Seiler, D. Sexty and I. O. Stamatescu, Phys. Lett. B 723 (2013) 213 [arXiv:1211.3709 [hep-lat]].
- <span id="page-43-29"></span>[76] J. Berges, S. Borsányi, D. Sexty and I.-O. Stamatescu, Phys. Rev. D 75 (2007) 045007 [hep-lat/0609058].
- <span id="page-43-30"></span>[77] G. Aarts and I.-O. Stamatescu, JHEP **0809** (2008) 018 [arXiv:0807.1597 [hep-lat]].
- [78] G. G. Batrouni, G. R. Katz, A. S. Kronfeld, G. P. Lepage, B. Svetitsky and K. G. Wilson, Phys. Rev. D 32 (1985) 2736.
- <span id="page-43-31"></span>[79] G. Aarts, L. Bongiovanni, E. Seiler, D. Sexty and I. -O. Stamatescu, Eur. Phys. J. A 49 (2013) 89 [arXiv:1303.6425 [hep-lat]].
- <span id="page-43-32"></span>[80] G. Aarts, F. Attanasio, B. Jäger, E. Seiler, D. Sexty and I. O. Stamatescu, PoS LATTICE 2014 (2014) 200 [arXiv:1411.2632 [hep-lat]].
- <span id="page-43-33"></span>[81] G. Aarts, F. Attanasio, B. Jäger, E. Seiler, D. Sexty and I. O. Stamatescu, Acta Phys. Polon. Supp. 8 (2015) 2, 405 [arXiv:1506.02547 [hep-lat]].
- <span id="page-43-35"></span><span id="page-43-34"></span>[82] D. Sexty, Phys. Lett. B **729** (2014) 108 [arXiv:1307.7748 [hep-lat]].
- <span id="page-43-36"></span>[83] Z. Fodor, S. D. Katz, D. Sexty and C. Török, arXiv:1508.05260 [hep-lat].
- <span id="page-43-37"></span>[84] L. Bongiovanni, G. Aarts, E. Seiler and D. Sexty, PoS LATTICE 2014 (2014) 199 [arXiv:1411.0949 [hep-lat]].
- <span id="page-43-38"></span>[85] G. Aarts, Pramana 84 (2015) 5, 787 [arXiv:1312.0968 [hep-lat]].
- <span id="page-43-39"></span>[86] G. Aarts, PoS CPOD **2014** (2014) 012 [arXiv:1502.01850 [hep-lat]].
- <span id="page-43-40"></span>[87] F. Karsch and K. H. Mütter, Nucl. Phys. B 313 (1989) 541.
- <span id="page-43-41"></span>[88] P. de Forcrand and M. Fromm, Phys. Rev. Lett. **104** (2010) 112005 [arXiv:0907.1915 [hep-lat]].
- <span id="page-43-42"></span>[89] W. Unger and P. de Forcrand, J. Phys. G 38 (2011) 124190 [arXiv:1107.1553 [hep-lat]].
- <span id="page-43-43"></span>[90] N. Prokof'ev and B. Svistunov, Phys. Rev. Lett. 87 (2001) 160601.
- [91] P. de Forcrand, J. Langelage, O. Philipsen and W. Unger, Phys. Rev. Lett. 113 (2014) 15, 152002 [arXiv:1406.4397 [hep-lat]].

- <span id="page-44-0"></span>[92] K. Fabricius and O. Haan, Phys. Lett. B 143 (1984) 459.
- [93] H. Vairinhos, arXiv:1010.1253 [hep-lat].
- <span id="page-44-1"></span>[94] H. Vairinhos and P. de Forcrand, JHEP 1412 (2014) 038 [arXiv:1409.8442 [hep-lat]].
- <span id="page-44-2"></span>[95] B. B. Brandt and T. Wettig, PoS(LATTICE2014)307 [arXiv:1411.3350 [hep-lat]].
- <span id="page-44-3"></span>[96] M. Fromm, J. Langelage, S. Lottini and O. Philipsen, JHEP 1201 (2012) 042 [arXiv:1111.4953 [hep-lat]].
- [97] M. Fromm, J. Langelage, S. Lottini, M. Neuman and O. Philipsen, Phys. Rev. Lett. 110 (2013) 12, 122001 [arXiv:1207.3005 [hep-lat]].
- <span id="page-44-5"></span><span id="page-44-4"></span>[98] C. Gattringer, Nucl. Phys. B 850 (2011) 242 [arXiv:1104.2503 [hep-lat]].
- [99] A. Gocksch, Phys. Rev. Lett. **61** (1988) 2054.
- [100] J. Ambjorn, K. N. Anagnostopoulos, J. Nishimura and J. J. M. Verbaarschot, JHEP 0210 (2002) 062 [hep-lat/0208025].
- [101] Z. Fodor, S. D. Katz and C. Schmidt, JHEP **0703** (2007) 121 [hep-lat/0701022].
- [102] S. Ejiri, Phys. Rev. D 77 (2008) 014508 [arXiv:0706.3549 [hep-lat]].
- [103] K. N. Anagnostopoulos, T. Azuma and J. Nishimura, Phys. Rev. D 83 (2011) 054504 [arXiv:1009.4504 [cond-mat.stat-mech]].
- [104] S. Ejiri, Eur. Phys. J. A 49 (2013) 86 [arXiv:1306.0295 [hep-lat]].
- [105] H. Saito, S. Ejiri, S. Aoki, K. Kanaya, Y. Nakagawa, H. Ohno, K. Okuno and T. Umeda, Phys. Rev. D 89 (2014) 3, 034507 [arXiv:1309.2445 [hep-lat]].
- <span id="page-44-6"></span>[106] K. Langfeld, B. Lucini and A. Rago, Phys. Rev. Lett. 109 (2012) 111601 [arXiv:1204.3243 [hep-lat]].
- [107] K. Langfeld and J. M. Pawlowski, Phys. Rev. D 88, **071502** (R) (2013) [arXiv:1307.0455 [hep-lat]].
- <span id="page-44-7"></span>[108] K. Langfeld and B. Lucini, Phys. Rev. D **90** (2014) 9, 094502 [arXiv:1404.7187 [hep-lat]].
- <span id="page-44-8"></span>[109] C. Gattringer and P. Törek, Phys. Lett. B 747 (2015) 545 [arXiv:1503.04947 [hep-lat]].
- <span id="page-44-9"></span>[110] F. Wang and D. P. Landau, Phys. Rev. Lett. 86, 2050 (2001).
- <span id="page-44-10"></span>[111] E. Witten, arXiv:1001.2933 [hep-th].
- [112] M. Cristoforetti et al. [AuroraScience Collaboration], Phys. Rev. D 86 (2012) 074506 [arXiv:1205.3996 [hep-lat]].
- <span id="page-44-11"></span>[113] M. Cristoforetti, F. Di Renzo, A. Mukherjee and L. Scorzato, Phys. Rev. D 88 (2013) 051501 [arXiv:1303.7204 [hep-lat]].
- [114] A. Mukherjee, M. Cristoforetti and L. Scorzato, Phys. Rev. D 88 (2013) 051502 [arXiv:1308.0233 [physics.comp-ph]].
- [115] H. Fujii, D. Honda, M. Kato, Y. Kikukawa, S. Komatsu and T. Sano, JHEP **1310** (2013) 147 [arXiv:1309.4371 [hep-lat]].
- [116] M. Cristoforetti, F. Di Renzo, G. Eruzzi, A. Mukherjee, C. Schmidt, L. Scorzato and C. Torrero, Phys. Rev. D 89 (2014) 11, 114505 [arXiv:1403.5637 [hep-lat]].
- <span id="page-44-13"></span><span id="page-44-12"></span>[117] A. Alexandru, G. Basar and P. Bedaque, arXiv:1510.03258 [hep-lat].
- [118] T. Kanazawa and Y. Tanizaki, JHEP 1503 (2015) 044 [arXiv:1412.2802 [hep-th]].
- <span id="page-44-14"></span>[119] Y. Tanizaki, Y. Hidaka and T. Hayata, arXiv:1509.07146 [hep-th].
- <span id="page-44-15"></span>[120] H. Fujii, S. Kamata and Y. Kikukawa, arXiv:1509.08176 [hep-lat].
- <span id="page-44-16"></span>[121] G. Aarts, Phys. Rev. D 88 (2013) 9, 094501 [arXiv:1308.4811 [hep-lat]].
- <span id="page-44-17"></span>[122] T. Hayata, Y. Hidaka and Y. Tanizaki, arXiv:1511.02437 [hep-lat].
- <span id="page-44-18"></span>[123] G. Aarts, L. Bongiovanni, E. Seiler and D. Sexty, JHEP 1410 (2014) 159 [arXiv:1407.2090 [hep-lat]].
- <span id="page-44-21"></span>[124] G. Aarts, JHEP **0905** (2009) 052 [arXiv:0902.4686 [hep-lat]].
- <span id="page-44-19"></span>[125] P. E. Gibbs, GLASGOW PRINT-86-0389; Phys. Lett. B 172, 53 (1986).
- <span id="page-44-20"></span>[126] N. Bilić and K. Demeterfi, Phys. Lett. B 212, 83 (1988).
- <span id="page-44-22"></span>[127] L. Ravagli and J. J. M. Verbaarschot, Phys. Rev. D 76, 054506 (2007) [0704.1111 [hep-th]].
- [128] G. Aarts and K. Splittorff, JHEP 1008 (2010) 017 [arXiv:1006.0332 [hep-lat]].