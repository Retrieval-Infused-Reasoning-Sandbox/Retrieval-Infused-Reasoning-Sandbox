# Combinatorial Nullstellensatz

Noga Alon <sup>∗</sup>

#### Abstract

We present a general algebraic technique and discuss some of its numerous applications in Combinatorial Number Theory, in Graph Theory and in Combinatorics. These applications include results in additive number theory and in the study of graph coloring problems. Many of these are known results, to which we present unified proofs, and some results are new.

#### 1 Introduction

Hilbert's Nullstellensatz (see, e.g., [58]) is the fundamental theorem that asserts that if F is an algebraically closed field, and f, g1, . . . , g<sup>m</sup> are polynomials in the ring of polynomials F[x1, . . . , xn], where f vanishes over all common zeros of g1, . . . , gm, then there is an integer k and polynomials h1, . . . , h<sup>m</sup> in F[x1, . . . , xn] so that

$$f^k = \sum_{i=1}^n h_i g_i.$$

In the special case m = n, where each g<sup>i</sup> is a univariate polynomial of the form Q s∈S<sup>i</sup> (x<sup>i</sup> − s), a stronger conclusion holds, as follows.

Theorem 1.1 Let F be an arbitrary field, and let f = f(x1, . . . , xn) be a polynomial in F[x1, . . . , xn]. Let S1, . . . , S<sup>n</sup> be nonempty subsets of F and define gi(xi) = Q s∈S<sup>i</sup> (x<sup>i</sup> −s). If f vanishes over all the common zeros of g1, . . . , g<sup>n</sup> (that is; if f(s1, . . . , sn) = 0 for all s<sup>i</sup> ∈ Si), then there are polynomials h1, . . . , h<sup>n</sup> ∈ F[x1, . . . , xn] satisfying deg(hi) ≤ deg(f) − deg(gi) so that

$$f = \sum_{i=1}^{n} h_i g_i.$$

Moreover, if f, g1, . . . g<sup>n</sup> lie in R[x1, . . . , xn] for some subring R of F then there are polynomials h<sup>i</sup> ∈ R[x1, . . . , xn] as above.

<sup>∗</sup>Department of Mathematics, Raymond and Beverly Sackler Faculty of Exact Sciences, Tel Aviv University, Tel Aviv, Israel and Institute for Advanced Study, Princeton, NJ 08540, USA. Research supported in part by a grant from the Israel Science Foundation, by a Sloan Foundation grant No. 96-6-2, by an NEC Research Institute grant and by the Hermann Minkowski Minerva Center for Geometry at Tel Aviv University.

As a consequence of the above one can prove the following,

Theorem 1.2 Let F be an arbitrary field, and let f = f(x1, . . . , xn) be a polynomial in F[x1, . . . , xn]. Suppose the degree deg(f) of f is P<sup>n</sup> <sup>i</sup>=1 ti, where each t<sup>i</sup> is a nonnegative integer, and suppose the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x ti i in f is nonzero. Then, if S1, . . . , S<sup>n</sup> are subsets of F with |S<sup>i</sup> | > ti, there are s<sup>1</sup> ∈ S1, s<sup>2</sup> ∈ S2, . . . , s<sup>n</sup> ∈ S<sup>n</sup> so that

$$f(s_1,\ldots,s_n)\neq 0.$$

In this paper we prove these two theorems, which may be called Combinatorial Nullstellensatz, and describe several combinatorial applications of them. After presenting the (simple) proofs of the above theorems in Section 2, we show, in Section 3 that the classical theorem of Chevalley and Warning on roots of systems of polynomials as well as the basic theorem of Cauchy and Davenport on the addition of residue classes follow as simple consequences. We proceed to describe additional applications in Additive Number Theory and in Graph Theory and Combinatorics in Sections 4,5,6,7 and 8. Many of these applications are known results, proved here in a unified way, and some are new. There are several known results that assert that a combinatorial structure satisfies certain combinatorial property if and only if an appropriate polynomial associated with it lies in a properly defined ideal. In Section 9 we apply our technique and obtain several new results of this form. The final Section 10 contains some concluding remarks and open problems.

#### 2 The proofs of the two basic theorems

To prove Theorem 1.1 we need the following simple lemma proved, for example, in [13]. For the sake of completeness we include the short proof.

Lemma 2.1 Let P = P(x1, x2, . . . , xn) be a polynomial in n variables over an arbitrary field F. Suppose that the degree of P as a polynomial in x<sup>i</sup> is at most t<sup>i</sup> for 1 ≤ i ≤ n, and let S<sup>i</sup> ⊂ F be a set of at least t<sup>i</sup> + 1 distinct members of F. If P(x1, x2, . . . , xn) = 0 for all n-tuples (x1, . . . , xn) ∈ S<sup>1</sup> × S<sup>2</sup> × . . . × Sn, then P ≡ 0.

Proof. We apply induction on n. For n = 1, the lemma is simply the assertion that a non-zero polynomial of degree t<sup>1</sup> in one variable can have at most t<sup>1</sup> distinct zeros. Assuming that the lemma holds for n − 1, we prove it for n (n ≥ 2). Given a polynomial P = P(x1, . . . , xn) and sets S<sup>i</sup> satisfying the hypotheses of the lemma, let us write P as a polynomial in xn- that is,

$$P = \sum_{i=0}^{t_n} P_i(x_1, \dots, x_{n-1}) x_n^i,$$

where each P<sup>i</sup> is a polynomial with x<sup>j</sup> -degree bounded by t<sup>j</sup> . For each fixed (n − 1)-tuple

$$(x_1,\ldots,x_{n-1})\in S_1\times S_2\times\ldots\times S_{n-1},$$

the polynomial in x<sup>n</sup> obtained from P by substituting the values of x1, . . . , xn−<sup>1</sup> vanishes for all x<sup>n</sup> ∈ Sn, and is thus identically 0. Thus Pi(x1, . . . , xn−1) = 0 for all (x1, . . . , xn−1) ∈ S<sup>1</sup> ×. . .×Sn−1. Hence, by the induction hypothesis, P<sup>i</sup> ≡ 0 for all i, implying that P ≡ 0. This completes the induction and the proof of the lemma. ✷

Proof of Theorem 1.1. Define t<sup>i</sup> = |S<sup>i</sup> | − 1 for all i. By assumption,

$$f(x_1, \dots, x_n) = 0$$
 for every  $n$ -tuple  $(x_1, \dots, x_n) \in S_1 \times S_2 \times \dots \times S_n$ . (1)

For each i, 1 ≤ i ≤ n, let

$$g_i(x_i) = \prod_{s \in S_i} (x_i - s) = x_i^{t_i + 1} - \sum_{j=0}^{t_i} g_{ij} x_i^j.$$

Observe that,

if 
$$x_i \in S_i$$
 then  $g_i(x_i) = 0$ - that is,  $x_i^{t_i+1} = \sum_{j=0}^{t_i} g_{ij} x_i^j$ . (2)

Let f be the polynomial obtained by writing f as a linear combination of monomials and replacing, repeatedly, each occurrence of x fi i (1 ≤ i ≤ n), where f<sup>i</sup> > t<sup>i</sup> , by a linear combination of smaller powers of x<sup>i</sup> , using the relations (2). The resulting polynomial f is clearly of degree at most t<sup>i</sup> in x<sup>i</sup> , for each 1 ≤ i ≤ n, and is obtained from f by subtracting from it products of the form hig<sup>i</sup> , where the degree of each polynomial h<sup>i</sup> ∈ F[x1, . . . , xn] does not exceed deg(f) − deg(gi) (and where the coefficients of each h<sup>i</sup> are in the smallest ring containing all coefficients of f and g1, . . . , gn.) Moreover, f(x1, . . . , xn) = f(x1, . . . , xn), for all (x1, . . . , xn) ∈ S1×. . .×Sn, since the relations (2) hold for these values of x1, . . . , xn. Therefore, by (1), f(x1, . . . , xn) = 0 for every n-tuple (x1, . . . , xn) ∈ S1×. . .×S<sup>n</sup> and hence, by Lemma 2.1, f ≡ 0. This implies that f = P<sup>n</sup> <sup>i</sup>=1 hig<sup>i</sup> , and completes the proof. ✷ Proof of Theorem 1.2. Clearly we may assume that |S<sup>i</sup> | = ti+1 for all i. Suppose the result is false, and define gi(xi) = Q s∈S<sup>i</sup> (x<sup>i</sup> − s). By Theorem 1.1 there are polynomials h1, . . . , h<sup>n</sup> ∈ F[x1, . . . , xn] satisfying deg(h<sup>j</sup> ) ≤ P<sup>n</sup> <sup>i</sup>=1 t<sup>i</sup> − deg(g<sup>j</sup> ) so that

$$f = \sum_{i=1}^{n} h_i g_i.$$

By assumption, the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x ti i in the left hand side is nonzero, and hence so is the coefficient of this monomial in the right hand side. However, the degree of hig<sup>i</sup> = h<sup>i</sup> Q s∈S<sup>i</sup> (x<sup>i</sup> − s) is at most deg(f), and if there are any monomials of degree deg(f) in it they are divisible by x ti+1 i . It follows that the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x ti i in the right hand side is zero, and this contradiction completes the proof. ✷

#### 3 Two classical applications

The following theorem, conjectured by Artin in 1934, was proved by Chevalley in 1935 and extended by Warning in 1935. Here we present a very short proof using our Theorem 1.2 above. For simplicity, we restrict ourselves to the case of finite prime fields, though the proof easily extends to arbitrary finite fields.

Theorem 3.1 (cf., e.g., [52]) Let p be a prime, and let

$$P_1 = P_1(x_1, \dots, x_n), P_2 = P_2(x_1, \dots, x_n), \dots, P_m = P_m(x_1, \dots, x_n)$$

be m polynomials in the ring Zp[x1, . . . , xn]. If n > P<sup>m</sup> <sup>i</sup>=1 deg(Pi) and the polynomials P<sup>i</sup> have a common zero (c1, . . . , cn), then they have another common zero.

Proof. Suppose this is false, and define

$$f = f(x_1, \dots, x_n) = \prod_{i=1}^m (1 - P_i(x_1, \dots, x_n)^{p-1}) - \delta \prod_{j=1}^n \prod_{c \in Z_p, c \neq c_j} (x_j - c),$$

where δ is chosen so that

$$f(c_1,\ldots,c_n)=0. (3)$$

Note that this determines the value of δ, and this value is nonzero. Note also that

$$f(s_1, \dots, s_n) = 0 \tag{4}$$

for all s<sup>i</sup> ∈ Zp. Indeed, this is certainly true, by (3), if (s1, . . . , sn) = (c1, . . . , cn). For other values of (s1, . . . , sn), there is, by assumption, a polynomial P<sup>j</sup> that does not vanish on (s1, . . . , sn), implying that 1 − P<sup>j</sup> (s1, . . . , sn) <sup>p</sup>−<sup>1</sup> = 0. Similarly, since s<sup>i</sup> 6= c<sup>i</sup> for some i, the product Q c∈Zp,c6=c<sup>i</sup> (s<sup>i</sup> − c) is zero and hence so is the value of f(s1, . . . , sn).

Define t<sup>i</sup> = p − 1 for all i and note that the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x ti i in f is −δ 6= 0, since the total degree of

$$\prod_{i=1}^{m} (1 - P_i(x_1, \dots, x_n)^{p-1})$$

is (p−1) P<sup>m</sup> <sup>i</sup>=1 deg(Pi) < (p−1)n. Therefore, by Theorem 1.2 with S<sup>i</sup> = Z<sup>p</sup> for all i we conclude that there are s1, . . . , s<sup>n</sup> ∈ Z<sup>p</sup> for which f(s1, . . . , sn) 6= 0, contradicting (4) and completing the proof. ✷

The Cauchy-Davenport Theorem, which has numerous applications in Additive Number Theory, is the following.

Theorem 3.2 ([20]) If p is a prime, and A, B are two nonempty subsets of Zp, then

$$|A + B| \ge min\{p, |A| + |B| - 1\}.$$

Cauchy proved this theorem in 1813, and applied it to give a new proof to a lemma of Lagrange in his well known 1770 paper that shows that any integer is a sum of four squares. Davenport formulated the theorem as a discrete analogue of a conjecture of Khintchine (which was proved a few years later by H. Mann) about the Schnirelman density of the sum of two sequences of integers. There are numerous extensions of this result, see, e.g., [45]. The proofs of Theorem 3.2 given by Cauchy and Davenport are based on the same combinatorial idea, and apply induction on |B|. A different, algebraic proof has recently been found by the authors of [10], [11], and its main advantage is that it extends easily and gives several related results. As shown below, this proof can be described as a simple application of Theorem 1.2.

Proof of Theorem 3.2. If |A| + |B| > p the result is trivial, since in this case for every g ∈ Z<sup>p</sup> the two sets A and g −B intersect, implying that A+B = Zp. Assume, therefore, that |A|+|B| ≤ p and suppose the result is false and |A+B| ≤ |A|+|B| −2. Let C be a subset of Z<sup>p</sup> satisfying A+B ⊂ C and |C| = |A| + |B| − 2. Define f = f(x, y) = Q <sup>c</sup>∈C(x + y − c) and observe that by the definition of C

$$f(a,b) = 0 \text{ for all } a \in A, b \in B.$$
 (5)

Put t<sup>1</sup> = |A| − 1, t<sup>2</sup> = |B| − 1 and note that the coefficient of x <sup>t</sup><sup>1</sup> y t2 in f is the binomial coefficient |A|+|B|−<sup>2</sup> |A|−1 which is nonzero in Zp, since |A| + |B| − 2 < p. Therefore, by Theorem 1.2 (with n = 2, S<sup>1</sup> = A, S<sup>2</sup> = B), there is an a ∈ A and a b ∈ B so that f(a, b) 6= 0, contradicting (5) and completing the proof. ✷

### 4 Restricted sums

The first theorem in this section is a general result, first proved in [11]. Here we observe that it is a simple consequence of Theorem 1.2 above. We also describe some of its applications, proved in [11], which are extensions of the Cauchy Davenport Theorem.

Let p be a prime. For a polynomial h = h(x0, x1, . . . , xk) over Z<sup>p</sup> and for subsets A0, A1, . . . , A<sup>k</sup> of Zp, define

$$\bigoplus_{i=0}^{k} A_i = \{ a_0 + a_1 + \dots + a_k : a_i \in A_i, \ h(a_0, a_1, \dots, a_k) \neq 0 \}.$$

Theorem 4.1 ([11]) Let p be a prime and let h = h(x0, . . . , xk) be a polynomial over Zp. Let A0, A1, . . . , A<sup>k</sup> be nonempty subsets of Zp, where |A<sup>i</sup> | = c<sup>i</sup> + 1 and define m = P<sup>k</sup> <sup>i</sup>=0 c<sup>i</sup> − deg(h). If the coefficient of Q<sup>k</sup> <sup>i</sup>=0 x ci i in

$$(x_0 + x_1 + \dots + x_k)^m h(x_0, x_1, \dots, x_k)$$

is nonzero (in Zp) then

$$|\oplus_h \sum_{i=0}^k A_i| \ge m+1$$

(and hence m < p).

Proof Suppose the assertion is false, and let E be a (multi-) set of m (not necessarily distinct) elements of Z<sup>p</sup> that contains the set ⊕<sup>h</sup> P<sup>k</sup> <sup>i</sup>=0 A<sup>i</sup> . Let Q = Q(x0, . . . , xk) be the polynomial defined as follows:

$$Q(x_0, \dots, x_k) = h(x_0, x_1, \dots x_k) \cdot \prod_{e \in E} (x_0 + \dots + x_k - e).$$

Note that

$$Q(x_0, \dots, x_k) = 0 \text{ for all } (x_0, \dots, x_k) \in (A_0, \dots, A_k).$$
 (6)

This is because for each such (x0, . . . , xk) either h(x0, . . . , xk) = 0 or x<sup>0</sup> +. . .+x<sup>k</sup> ∈ ⊕<sup>h</sup> P<sup>k</sup> <sup>i</sup>=0 A<sup>i</sup> ⊂ E. Note also that deg(Q) = m + deg(h) = P<sup>k</sup> <sup>i</sup>=0 c<sup>i</sup> and hence the coefficient of the monomial x c0 0 · · · x ck k in Q is the same as that of this monomial in the polynomial (x<sup>0</sup> + . . . + xk) <sup>m</sup>h(x0, . . . , xk), which is nonzero, by assumption.

By Theorem 1.2 there are x<sup>0</sup> ∈ A0, x<sup>1</sup> ∈ A1, . . . , x<sup>k</sup> ∈ A<sup>k</sup> such that Q(x0, x1, . . . , xk) 6= 0, contradicting (6) and completing the proof. ✷

One of the applications of the last theorem is the following.

Proposition 4.2 Let p be a prime, and let A0, A1, . . . , A<sup>k</sup> be nonempty subsets of the cyclic group Zp. If |A<sup>i</sup> | 6= |A<sup>j</sup> | for all 0 ≤ i < j ≤ k and P<sup>k</sup> <sup>i</sup>=0 |A<sup>i</sup> | ≤ p + k+2 2 − 1 then

$$|\{a_0 + a_1 + \ldots + a_k : a_i \in A_i, a_i \neq a_j \text{ for all } i \neq j\}| \ge \sum_{i=0}^k |A_i| - \binom{k+2}{2} + 1.$$

Note that the very special case of this proposition in which k = 1, A<sup>0</sup> = A and A<sup>1</sup> = A − {a} for an arbitrary element a ∈ A implies that if A ⊂ Z<sup>p</sup> and 2|A| − 1 ≤ p + 2 then the number of sums a<sup>1</sup> + a<sup>2</sup> with a1, a<sup>2</sup> ∈ A and a<sup>1</sup> 6= a<sup>2</sup> is at least 2|A| − 3. This easily implies the following theorem, conjectured by Erd˝os and Heilbronn in 1964 (cf., e.g., [25]). Special cases of this conjecture have been proved by various researchers ([49], [43], [50], [29]) and the full conjecture has recently been proved by Dias Da Silva and Hamidoune [21], using some tools from linear algebra and the representation theory of the symmetric group.

Theorem 4.3 ([21]) If p is a prime, and A is a nonempty subset of Zp, then

$$|\{a + a' : a, a' \in A, a \neq a'\}| \ge min\{p, 2|A| - 3\}.$$

In order to deduce Proposition 4.2 from Theorem 4.1 we need the following Lemma which can be easily deduced from the known results about the Ballot problem (see, e.g., [44]), as well as from the known connection between this problem and the hook formula for the number of Young tableaux of a given shape. A simple, direct proof is given in [11].

Lemma 4.4 Let c0, . . . , c<sup>k</sup> be nonnegative integers and suppose that <sup>P</sup><sup>k</sup> <sup>i</sup>=0 c<sup>i</sup> = m + k+1 2 , where m is a nonnegative integer. Then the coefficient of Q<sup>k</sup> <sup>i</sup>=0 x ci i in the polynomial

$$(x_0 + x_1 + \ldots + x_k)^m \prod_{k \ge i > j \ge 0} (x_i - x_j)$$

is

$$\frac{m!}{c_0!c_1!\dots c_k!} \prod_{k\geq i>j\geq 0} (c_i - c_j).$$

✷

Let p be a prime, and let A0, A1, . . . , A<sup>k</sup> be nonempty subsets of the cyclic group Zp. Define

$$\bigoplus_{i=0}^{k} A_i = \{ a_0 + a_1 + \ldots + a_k : a_i \in A_i, a_i \neq a_j \text{ for all } i \neq j \}.$$

In this notation, the assertion of Proposition 4.2 is that if |A<sup>i</sup> | 6= |A<sup>j</sup> | for all 0 ≤ i < j ≤ k and P<sup>k</sup> <sup>i</sup>=0 |A<sup>i</sup> | ≤ p + k+2 2 − 1 then

$$| \oplus_{i=0}^k A_i | \ge \sum_{i=0}^k |A_i| - \binom{k+2}{2} + 1.$$

Proof of Proposition 4.2. Define

$$h(x_0,\ldots,x_k) = \prod_{k \ge i > j \ge 0} (x_i - x_j),$$

and note that for this h, the sum ⊕<sup>k</sup> <sup>i</sup>=0A<sup>i</sup> is precisely the sum ⊕<sup>h</sup> P<sup>k</sup> <sup>i</sup>=0 A<sup>i</sup> . Suppose |A<sup>i</sup> | = c<sup>i</sup> + 1 and put

$$m = \sum_{i=0}^{k} c_i - {k+1 \choose 2} \quad (= \sum_{i=0}^{k} |A_i| - {k+2 \choose 2}).$$

By assumption m < p and by Lemma 4.4 the coefficient of Q<sup>k</sup> <sup>i</sup>=0 x ci i in

$$h \cdot (x_0 + \ldots + x_k)^m$$

is

$$\frac{m!}{c_0!c_1!\dots c_k!} \prod_{k\geq i>j\geq 0} (c_i - c_j),$$

which is nonzero modulo p, since m < p and the numbers c<sup>i</sup> are pairwise distinct. Since m = P<sup>k</sup> <sup>i</sup>=0 c<sup>i</sup> + deg(h), the desired result follows from Theorem 4.1. ✷

An easy consequence of Proposition 4.2 is the following. See [11] for the detailed proof.

**Theorem 4.5** Let p be a prime, and let  $A_0, \ldots, A_k$  be nonempty subsets of  $Z_p$ , where  $|A_i| = b_i$ , and suppose  $b_0 \geq b_1 \ldots \geq b_k$ . Define  $b'_0, \ldots, b'_k$  by

$$b'_0 = b_0 \quad and \quad b'_i = min\{b'_{i-1} - 1, b_i\}, \text{ for } 1 \le i \le k.$$
 (7)

If  $b'_k > 0$  then

$$|\bigoplus_{i=0}^{k} A_i| \ge \min\{p, \sum_{i=0}^{k} b'_i - \binom{k+2}{2} + 1\}.$$

Moreover, the above estimate is sharp for all possible values of  $p \ge b_0 \ge ... \ge b_k$ .

The following result of Dias da Silva and Hamidoune [21] is a simple consequence of (a special case of) the above theorem.

**Theorem 4.6 ([21])** Let p be a prime and let A be a nonempty subset of  $Z_p$ . Let  $s^{\wedge}A$  denote the set of all sums of s distinct elements of A. Then  $|s^{\wedge}A| \ge \min\{p, s|A| - s^2 + 1\}$ .

**Proof.** If |A| < s there is nothing to prove. Otherwise put s = k + 1 and apply Theorem 4.5 with  $A_i = A$  for all i. Here  $b_i' = |A| - i$  for all  $0 \le i \le k$  and hence

$$|(k+1)^{\wedge}A| = |\bigoplus_{i=0}^{k} A_i| \ge \min\{p, \sum_{i=0}^{k} (|A|-i) - \binom{k+2}{2} + 1\}$$

$$= \min\{p, (k+1)|A| - \binom{k+1}{2} - \binom{k+2}{2} + 1\} = \min\{p, (k+1)|A| - (k+1)^2 + 1\}.$$

Another easy application of Theorem 4.1 is the following result, proved in [10].

**Proposition 4.7** If p is a prime and A, B are two nonempty subsets of  $Z_p$ , then

$$|\{a+b: a \in A, b \in B, ab \neq 1\}| \ge \min\{p, |A|+|B|-3\}.$$

The proof is by applying Theorem 4.1 with k = 1,  $h = x_0x_1 - 1$ ,  $A_0 = A$ ,  $A_1 = B$ , and m = |A| + |B| - 4. It is also shown in [10] that the above estimate is tight in all nontrivial cases. Additional extensions of the above proposition appear in [11].

## 5 Set addition in vector spaces over prime fields

A triple (r, s, n) of positive integers satisfies the Hopf-Stiefel condition if

 $\binom{n}{k}$  is even for every integer k satisfying n - r < k < s.

This condition arises in Topology. However, studying the combinatorial aspects of the well known Hurwitz problem, Yuzvinsky [59] showed that it has an interesting relation to a natural additive problem. he proved that in a vector space of infinite dimension over GF(2), there exist two subsets A, B ⊂ V satisfying |A| = r, |B| = s and |A + B| ≤ n if and only if the triple (r, s, n) satisfies the Hopf-Stiefel condition.

Eliahou and Kervaire [23] have shown very recently that this can be proved using the algebraic technique of [10], [11], and generalized this result to an arbitrary prime p, thus obtaining a common generalization of Yuzvinsky's result and the Cauchy Davenport Theorem. Here is a description of their result, and a quick derivation of it from Theorem 1.2. It is worth noting that the same result also follows from the main result of Bollob´as and Leader in [18], proved by a different, more combinatorial, approach.

Let us say that a triple (r, s, n) of positive integers satisfies the Hopf-Stiefel condition with respect to a prime p if

$$\binom{n}{k}$$
 is divisible by  $p$  for every integer  $k$  satisfying  $n - r < k < s$ . (8)

Let βp(r, s) denote the smallest integer n for which the triple (r, s, n) satisfies (8). We note that it is not difficult to give a recursive formula for βp(r, s), which enables one to compute it quickly, given the representation of r and s in basis p.

Theorem 5.1 ([23], see also [18]) If A and B are two finite nonempty subsets of a vector space V over GF(p), and |A| = r, |B| = s, then |A + B| ≥ βp(r, s).

Proof. We may assume that V is finite, and identify it with the finite field F<sup>q</sup> of the same cardinality over GF(p). Viewing A and B as subsets of Fq, define C = A + B, and assume the assertion is false and |C| = n < βp(r, s). As in the previous section, define

$$Q(x,y) = \prod_{c \in C} (x+y-c),$$

where Q is a polynomial over Fq, and observe that Q(a, b) = 0 for all a ∈ A, b ∈ B. By the definition of βp(r, s) there is some k satisfying n − r < k < s such that <sup>n</sup> k is not divisible by p. Therefore, the coefficient of x <sup>n</sup>−ky k in the above polynomial is not zero, and since |A| = r > n − k, |B| = s > k there are, by Theorem 1.2, a ∈ A and b ∈ B such that Q(a, b) 6= 0, contradiction. This completes the proof. ✷

The authors of [23] have also shown that the estimate in Theorem 5.1 is sharp for all possible r and s. In fact, if A is the set of r vectors whose coordinates correspond to the p-adic representation of the integers 0, 1, . . . , r−1, and B is the set of s vectors whose coordinates correspond to the p-adic representation of the integers 0, 1, . . . , s−1, it is not too difficult to check that A+B is the set of of all vectors whose coordinates correspond to the p-adic representation of the integers 0, 1, . . . , βp(r, s)−1. For more details and several extensions, see [23].

#### 6 Graphs, subgraphs and cubes

A well known conjecture of Berge and Sauer, proved by Ta´skinov [53], asserts that any simple 4 regular graph contains a 3-regular subgraph. This assertion is easily seen to be false for graphs with multiple edges, but as shown in [6] one extra edge suffices to ensure a 3-regular subgraph in this more general case as well. This follows from the case p = 3 in the following result, which, as shown below, can be derived quickly from Theorem 1.2.

Theorem 6.1 ([6]) For any prime p, any loopless graph G = (V, E) with average degree bigger than 2p − 2 and maximum degree at most 2p − 1 contains a p-regular subgraph.

Proof. Let (av,e)v∈V,e∈<sup>E</sup> denote the incidence matrix of G defined by av,e = 1 if v ∈ e and av,e = 0 otherwise. Associate each edge e of G with a variable x<sup>e</sup> and consider the polynomial

$$F = \prod_{v \in V} [1 - (\sum_{e \in E} a_{v,e} x_e)^{p-1}] - \prod_{e \in E} (1 - x_e),$$

over GF(p). Notice that the degree of F is |E|, since the degree of the first product is at most (p − 1)|V | < |E|, by the assumption on the average degree of G. Moreover, the coefficient of Q <sup>e</sup>∈<sup>E</sup> x<sup>e</sup> in F is (−1)|E|+1 6= 0. Therefore, by Theorem 1.2, there are values x<sup>e</sup> ∈ {0, 1} such that F(x<sup>e</sup> : e ∈ E) 6= 0. By the definition of F, the above vector (x<sup>e</sup> : e ∈ E) is not the zero vector, since for this vector F = 0. In addition, for this vector, P <sup>e</sup>∈<sup>E</sup> av,ex<sup>e</sup> is zero modulo p for every v, since otherwise F would vanish at this point. Therefore, in the subgraph consisting of all edges e ∈ E for which x<sup>e</sup> = 1 all degrees are divisible by p, and since the maximum degree is smaller than 2p all positive degrees are precisely p, as needed. ✷

The assertion of Theorem 6.1 is proved in [6] for prime powers p as well, but it is not known if it holds for every integer p. Combining this result with some additional combinatorial arguments, one can show that for every k ≥ 4r, every loopless k-regular graph contains an r-regular subgraph. For more details and additional results, see [6].

Erd¨os and Sauer (c.f., e.g., [16], page 399) raised the problem of estimating the maximum number of edges in a simple graph on n vertices that contains no 3-regular subgraph. They conjectured that for every positive this number does not exceed n 1+ , provided n is sufficiently large as a function of . This has been proved by Pyber [47], using Theorem 6.1. He proved that any simple graph on n vertices with at least 200n log n edges contains a subgraph with maximum degree 5 and average degree more than 4. This subgraph contains, by Theorem 6.1, a 3-regular subgraph. On the other hand, Pyber, R¨odl and Szemer´edi [48] proved, by probabilistic arguments, that there are simple graphs on n vertices with at least Ω(n log log n) edges that contain no 3-regular subgraphs. Thus Pyber's estimate is not far from being best possible.

Here is another application of Theorem 1.2, which is not very natural, but demonstrates its versatility.

Proposition 6.2 Let p be a prime, and let G = (V, E) be a graph on a set of |V | > d(p−1) vertices. Then there is a nonempty subset U of vertices of G such that the number of cliques of d vertices of G that intersect U is 0 modulo p.

Proof. For each subset I of vertices of G, let K(I) denote the number of copies of K<sup>d</sup> in G that contain I. Associate each vertex v ∈ V with a variable xv, and consider the polynomial

$$F = \prod_{v \in V} (1 - x_v) - 1 + G,$$

where

$$G = [\sum_{\emptyset \neq I \subset V} (-1)^{|I|+1} K(I) \prod_{i \in I} x_i]^{p-1}$$

over GF(p). Since K(I) is obviously zero for all I of cardinality bigger than d, the degree of this polynomial is |V |, as the degree of G is at most d(p − 1) < |V |. Moreover, the coefficient of Q <sup>v</sup>∈<sup>V</sup> x<sup>v</sup> in F is (−1)|<sup>V</sup> <sup>|</sup> 6= 0. Therefore, by Theorem 1.2, there are x<sup>v</sup> ∈ {0, 1} for which F(x<sup>v</sup> : v ∈ V ) 6= 0. Since F vanishes on the all 0 vector, it follows that not all numbers x<sup>v</sup> are zero, and hence that G(x<sup>v</sup> : v ∈ V ) 6= 1, implying, by Fermat's little Theorem that

$$\sum_{\emptyset \neq I \subset V} (-1)^{|I|+1} K(I) \prod_{i \in I} x_i \equiv 0 (\bmod p).$$

However, the left hand side of the last congruence is precisely the number of copies of K<sup>d</sup> that intersect the set U = {v : x<sup>v</sup> = 1}, by the Inclusion-Exclusion formula. Since U is nonempty, the desired result follows. ✷

The assertion of the last proposition can be proved for prime powers p as well. See also [8], [4] for some related results. Some versions of these results arise in the study of the minimum possible degree of a polynomial that represents the OR function of n variables in the sense discussed in [54] and its references.

We close this section with a simple geometric result, proved in [7] answering a question of Komj´ath. As shown below, this result is also a simple consequence of Theorem 1.2.

Theorem 6.3 ([7]) Let H1, H2, . . . , H<sup>m</sup> be a family of hyperplanes in R<sup>n</sup> that cover all vertices of the unit cube {0, 1} n but one. Then m ≥ n.

Proof. Clearly we may assume that the uncovered vertex is the all zero vector. Let (a<sup>i</sup> , x) = b<sup>i</sup> be the equation defining H<sup>i</sup> , where x = (x1, x2, . . . , xn), and (a, b) is the inner product between the two vectors a and b. Note that for every i, b<sup>i</sup> 6= 0, since H<sup>i</sup> does not cover the origin. Assume the assertion is false and m < n, and consider the polynomial

$$P(x) = (-1)^{n+m+1} \prod_{j=1}^{m} b_j \prod_{i=1}^{n} (x_i - 1) - \prod_{i=1}^{m} [(a_i, x) - b_i].$$

The degree of this polynomial is clearly n, and the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x<sup>i</sup> in it is (−1)n+m+1 Q<sup>m</sup> <sup>j</sup>=1 b<sup>j</sup> 6= 0. Therefore, by Theorem 1.2 there is a point x ∈ {0, 1} n for which P(x) 6= 0. This point is not the all zero vector, as P vanishes on it, and therefore it is some other vertex of the cube. But in this case (a<sup>i</sup> , x) − b<sup>i</sup> = 0 for some i (as the vertex is covered by some Hi), implying that P does vanish on this point, a contradiction. ✷

The above result is clearly tight. Several extensions are proved in [7].

#### 7 Graph Coloring

Graph coloring is arguably the most popular subject in graph theory. An interesting variant of the classical problem of coloring properly the vertices of a graph with the minimum possible number of colors arises when one imposes some restrictions on the colors available for every vertex. This variant received a considerable amount of attention that led to several fascinating conjectures and results, and its study combines interesting combinatorial techniques with powerful algebraic and probabilistic ideas. The subject, initiated independently by Vizing [57] and by Erd˝os, Rubin and Taylor [27], is usually known as the study of the choosability properties of a graph. Tarsi and the author developed in [13] an algebraic technique that has already been applied by various researchers to solve several problems in this area as well as problems dealing with traditional graph coloring. In this section we observe that the basic results of this technique can be derived from Theorem 1.2, and describe various applications. More details on some of these applications can be found in the survey [2].

We start with some notation and background. A vertex coloring of a graph G is an assignment of a color to each vertex of G. The coloring is proper if adjacent vertices receive distinct colors. The chromatic number χ(G) of G is the minimum number of colors used in a proper vertex coloring of G. An edge coloring of G is, similarly, an assignment of a color to each edge of G. It is proper if adjacent edges receive distinct colors. The minimum number of colors in a proper edge-coloring of

G is the chromatic index χ 0 (G) of G. This is clearly equal to the chromatic number of the line graph of G.

If G = (V, E) is a (finite, directed or undirected) graph, and f is a function that assigns to each vertex v of G a positive integer f(v), we say that G is f-choosable if, for every assignment of sets of integers S(v) ⊂ Z to all the vertices v ∈ V , where |S(v)| = f(v) for all v, there is a proper vertex coloring c : V 7→ Z so that c(v) ∈ S(v) for all v ∈ V . The graph G is k-choosable if it is f-choosable for the constant function f(v) ≡ k. The choice number of G, denoted ch(G), is the minimum integer k so that G is k-choosable. Obviously, this number is at least the classical chromatic number χ(G) of G. The choice number of the line graph of G, which we denote here by ch<sup>0</sup> (G), is usually called the list chromatic index of G, and it is clearly at least the chromatic index χ 0 (G) of G.

As observed by various researchers, there are many graphs G for which the choice number ch(G) is strictly larger than the chromatic number χ(G). A simple example demonstrating this fact is the complete bipartite graph K3,3. If {u1, u2, u3} and {v1, v2, v3} are its two vertex-classes and S(ui) = S(vi) = {1, 2, 3} \ {i}, then there is no proper vertex coloring assigning to each vertex w a color from its class S(w). Therefore, the choice number of this graph exceeds its chromatic number. In fact, it is not difficult to show that, for any k ≥ 2, there are bipartite graphs whose choice number exceeds k. Moreover, in [2] it is proved, using probabilistic arguments, that for every k there is some finite c(k) so that the choice number of every simple graph with minimum degree at least c(k) exceeds k.

In view of this, the following conjecture, suggested independently by various researchers including Vizing, Albertson, Collins, Tucker and Gupta, which apparently appeared first in print in the paper of Bollob´as and Harris ([17]), is somewhat surprising.

#### Conjecture 7.1 (The list coloring conjecture) For every graph G, ch<sup>0</sup> (G) = χ 0 (G).

This conjecture asserts that for line graphs there is no gap at all between the choice number and the chromatic number. Many of the most interesting results in the area are proofs of special cases of this conjecture, which is still wide open. An asymptotic version of it, however, has been proven by Kahn [38] using probabilistic arguments: for simple graphs of maximum degree d, ch<sup>0</sup> (G) = (1 + o(1))d, where the o(1)-term tends to zero as d tends to infinity. Since in this case χ 0 (G) is either d or d + 1, by Vizing's theorem [56], this shows that the list coloring conjecture is asymptotically nearly correct.

The graph polynomial f<sup>G</sup> = fG(x1, x2, . . . , xn) of a directed or undirected graph G = (V, E) on a set V = {v1, . . . , vn} of n vertices is defined by fG(x1, x2, . . . , xn) = Π{(xi−x<sup>j</sup> ) : i < j , {v<sup>i</sup> , vj} ∈ E}. This polynomial has been studied by various researchers, starting already with Petersen [46] in 1891. See also, for example, [51], [40].

A subdigraph H of a directed graph D is called *Eulerian* if the indegree  $d_H^-(v)$  of every vertex v of H is equal to its outdegree  $d_H^+(v)$ . Note that we do not assume that H is connected. H is even if it has an even number of edges, otherwise, it is odd. Let EE(D) and EO(D) denote the numbers of even and odd Eulerian subgraphs of D, respectively. (For convenience we agree that the empty subgraph is an even Eulerian subgraph.) The following result is proved in [13].

**Theorem 7.2** Let D = (V, E) be an orientation of an undirected graph G, denote  $V = \{1, 2, ..., n\}$  and define  $f : V \mapsto Z$  by  $f(i) = d_i + 1$ , where  $d_i$  is the outdegree of i in D. If  $EE(D) \neq EO(D)$ , then D is f-choosable.

**Proof (sketch):** For  $1 \leq i \leq n$ , let  $S_i \subset Z$  be a set of  $d_i + 1$  distinct integers. The existence of a proper coloring of D assigning to each vertex i a color from its list  $S_i$  is equivalent to the existence of colors  $c_i \in S_i$  such that  $f_G(c_1, c_2, \ldots, c_n) \neq 0$ .

Since the degree of  $f_G$  is  $\sum_{i=1}^n d_i$ , it suffices to show that the coefficient of  $\prod_{i=1}^n x_i^{d_i}$  in  $f_G$  is nonzero in order to deduce the existence of such colors  $c_i$  from Theorem 1.2. This can be done by interpreting this coefficient combinatorially.

It is not too difficult to see that the coefficients of the monomials that appear in the standard representation of  $f_G$  as a linear combination of monomials can be expressed in terms of the orientations of G as follows. Call an orientation D of G even if the number of its directed edges (i, j) with i > j is even, otherwise call it odd. For non-negative integers  $d_1, d_2, \ldots, d_n$ , let  $DE(d_1, \ldots, d_n)$  and  $DO(d_1, \ldots, d_n)$  denote, respectively, the sets of all even and odd orientations of G in which the outdegree of the vertex  $v_i$  is  $d_i$ , for  $1 \le i \le n$ . In this notation, one can check that

$$f_G(x_1,\ldots,x_n) = \sum_{d_1,\ldots,d_n \ge 0} (|DE(d_1,\ldots,d_n)| - |DO(d_1,\ldots,d_n)|) \prod_{i=1}^n x_i^{d_i}.$$

Consider, now, the given orientation D which lies in  $DE(d_1, \ldots, d_n) \cup DO(d_1, \ldots, d_n)$ . For any orientation  $D_2 \in DE(d_1, \ldots, d_n) \cup DO(d_1, \ldots, d_n)$ , let  $D \oplus D_2$  denote the set of all oriented edges of D whose orientation in  $D_2$  is in the opposite direction. Since the outdegree of every vertex in D is equal to its outdegree in  $D_2$ , it follows that  $D \oplus D_2$  is an Eulerian subgraph of D. Moreover,  $D \oplus D_2$  is even as an Eulerian subgraph if and only if D and  $D_2$  are both even or both odd. The mapping  $D_2 \longrightarrow D \oplus D_2$  is clearly a bijection between  $DE(d_1, \ldots, d_n) \cup DO(d_1, \ldots, d_n)$  and the set of all Eulerian subgraphs of D. In case D is even, it maps even orientations to even (Eulerian) subgraphs, and odd orientations to odd subgraphs. Otherwise, it maps even orientations to odd subgraphs, and odd orientations to even subgraphs. In any case,

$$|DE(d_1,...,d_n)| - |DO(d_1,...,d_n)|| = |EE(D) - EO(D)|.$$

Therefore, the absolute value of the coefficient of the monomial Π<sup>n</sup> <sup>i</sup>=1x di i in the standard representation of f<sup>G</sup> = fG(x1, . . . , xn) as a linear combination of monomials, is |EE(D) − EO(D)|. In particular, if EE(D) 6= EO(D), then this coefficient is not zero and the desired result follows from Theorem 1.2. ✷

An interesting application of Theorem 7.2 has been obtained by Fleischner and Stiebitz in [28], solving a problem raised by Du, Hsu and Hwang in [22], as well as a strengthening of it suggested by Erd˝os.

Theorem 7.3 ([28]) Let G be a graph on 3n vertices, whose set of edges is the disjoint union of a Hamilton cycle and n pairwise vertex-disjoint triangles. Then the choice number and the chromatic number of G are both 3.

The proof is based on a subtle parity argument that shows that, if D is the digraph obtained from G by directing the Hamilton cycle as well as each of the triangles cyclically, then EE(D) − EO(D) ≡ 2(mod 4 ). The result thus follows from Theorem 7.2.

Another application of Theorem 7.2 together with some additional combinatorial arguments is the following result, that solves an open problem from [27].

Theorem 7.4 ([13]) The choice number of every planar bipartite graph is at most 3.

This is tight, since ch(K2,4) = 3.

Recall that the list coloring conjecture (Conjecture 7.1) asserts that ch<sup>0</sup> (G) = χ 0 (G) for every graph G. In order to try to apply Theorem 7.2 for tackling this problem, it is useful to find a more convenient expression for the difference EE(D) − EO(D), where D is the appropriate orientation of a given line graph. Such an expression is described in [2] for line graphs of d-regular graphs of chromatic index d. This expression is the sum, over all proper d-edge colorings of the graph, of an appropriately defined sign of the coloring. See [2] for more details, and [35] for a related discussion. Combining this with a known result of [55] (which asserts that for planar cubic graphs of chromatic index 3 all proper 3-edge colorings have the same sign), and with the Four Color Theorem, the following result, observed jointly with F. Jaeger and M. Tarsi, follows immediately:

Corollary 7.5 For every 2-connected cubic planar graph G, ch<sup>0</sup> (G) = 3.

Note that the above result is a strengthening of the Four Color Theorem, which is well known to be equivalent to the fact that the chromatic index of any such graph is 3.

As shown in [24], it is possible to extend this proof to any d-regular planar multigraph with chromatic index d.

Another interesting application of the algebraic method described above appears in [33], where the authors apply it to show that the list coloring conjecture holds for complete graphs with an odd number of vertices, and to improve the error term in the asymptotic estimate of Kahn for the maximum possible list chromatic index of a simple graph with maximum degree d. Finally we mention that Galvin [30] proved recently that the list coloring conjecture holds for any bipartite multigraph, by an elementary, non-algebraic method.

#### 8 The permanent lemma

The following lemma is a slight extension of a lemma proved in [12]. As shown below, it is an immediate corollary of Theorem 1.2 and has several interesting applications.

Lemma 8.1 (The permanent lemma) Let A = (aij ) be an n by n matrix over a field F, and suppose its permanent P er(A) is nonzero (over F). Then for any vector b = (b1, b2, . . . , bn) ∈ F <sup>n</sup> and for any family of sets S1, S2, . . . , S<sup>n</sup> of F, each of cardinality 2, there is a vector x ∈ S1×S2×. . .×S<sup>n</sup> such that for every i the i th coordinate of Ax differs from bi.

Proof. The polynomial

$$P(x_1, x_2, \dots, x_n) = \prod_{i=1}^{n} \left[ \sum_{j=1}^{n} a_{ij} x_j - b_j \right]$$

is of degree n and the coefficient of Q<sup>n</sup> <sup>i</sup>=1 x<sup>i</sup> in it is P er(A) 6= 0. The result thus follows from Theorem 1.2. ✷

Note that in the special case S<sup>i</sup> = {0, 1} for every i the above lemma asserts that if the permanent of A is non-zero, then for any vector b, there is a subset of the column-vectors of A whose sum differs from b in all coordinates.

A conjecture of Jaeger asserts that for any field with more than 3 elements and for any nonsingular n by n matrix A over the field, there is a vector x so that both x and Ax have non-zero coordinates. Note that for the special case of fields of characteristic 2 this follows immediately from the Permanent Lemma. Simply take b to be the zero vector, let each S<sup>i</sup> be an arbitrary subset of size 2 of the field that does not contain zero, and observe that in characteristic 2 the permanent and the determinant coincide, implying that P er(A) 6= 0. With slightly more work relying on some simple properties of the permanent function, the conjecture is proved in [12] for every non-prime field. It is still open for prime fields and, in particular, for p = 5.

Let f(n, d) denote the minimum possible number f so that every set of f lattice points in the ddimensional Euclidean space contains a subset of cardinality n whose centroid is also a lattice point. The problem of determining or estimating f(n, d) was suggested by Harborth [34], and studied by various authors.

It is convenient to reformulate the definition of f(n, d) in terms of sequences of elements of the abelian group Z d n . In these terms, f(n, d) is the minimum possible f so that every sequence of f members of Z d n contains a subsequence of size n the sum of whose elements (in the group) is 0.

By an old result of Erd˝os, Ginzburg and Ziv [26], f(n, 1) = 2n − 1 for all n. The main part in the proof of this statement is its proof for prime values of n = p, as the general case can then be easily proved by induction.

Proposition 8.2 ([26]) For any prime p, any sequence of 2p − 1 members of Z<sup>p</sup> contains a subsequence of cardinality p the sum of whose members is 0 (in Zp).

There are many proofs of this result. Here is one using the permanent lemma. Given 2p−1 members of Zp, renumber them a1, a2, . . . , a2p−<sup>1</sup> such that 0 ≤ a<sup>1</sup> ≤ . . . ≤ a2p−1. If there is an i ≤ p − 1 such that a<sup>i</sup> = ai+p−<sup>1</sup> then a<sup>i</sup> + ai+1 + . . . + ai+p−<sup>1</sup> = 0, as needed. Otherwise, let A denote the p − 1 by p − 1 all 1 matrix, and define S<sup>i</sup> = {a<sup>i</sup> , ai+p−1} for all 1 ≤ i ≤ p − 1. Let b1, . . . , bp−<sup>1</sup> be the set of all elements of Z<sup>p</sup> besides −a2p−1. Since P er(A) = (p − 1)! 6= 0, by Lemma 8.1, there are s<sup>i</sup> ∈ S<sup>i</sup> such that the sum Pp−<sup>1</sup> <sup>j</sup>=1 s<sup>i</sup> differs from each b<sup>j</sup> and is thus equal to −a2p−1. Hence, in Zp,

$$a_{2p-1} + \sum_{i=1}^{p-1} s_i = 0,$$

completing the proof. ✷

Kemnitz [39] conjectured that f(n, 2) = 4n − 3, observed that f(n, 2) ≥ 4n − 3 for all n and proved his conjecture for n = 2, 3, 5 and 7. As in the one dimensional case, it suffices to prove this conjecture for prime values p. In [5] it is shown that f(p, 2) ≤ 6p − 5 for every prime p. The details are somewhat complicated, but the main tool is again the Permanent Lemma mentioned above.

An additive basis in a vector space Z n p is a collection C of (not necessarily distinct) vectors, so that for every vector u in Z n p there is a subset of C the sum of whose elements is u. Motivated by the study of universal flows in graphs, Jaeger, Linial, Payan and Tarsi [36] conjectured that for every prime p there exists a constant c(p), such that any union of c(p) linear bases of Z n p contains an additive basis. This conjecture is still open, but in [9] it is shown that any union of d(p − 1) log<sup>e</sup> ne + p − 2 linear bases of Z n p contains such an additive basis. Here, too, the permanent lemma plays a crucial role in the proof. The main idea is to observe how it can be applied to give equalities rather than inequalities (extending the very simple application described in the proof of Proposition 8.2 above.) Here is the basic approach. For a vector v of length n over Zp, let v <sup>∗</sup> denote the tensor product of v with the all one vector of length p − 1. Thus v ∗ is a vector of length (p − 1)n obtained by concatenating (p-1) copies of v. In this notation, the following result follows from the permanent lemma.

**Lemma 8.3** Let  $S = (v_1, v_2, \ldots, v_{(p-1)n})$  be a sequence of (p-1)n vectors of length n over  $Z_p$ , and let A be the (p-1)n by (p-1)n matrix whose columns are the vectors  $v_1^*, v_2^*, \ldots, v_{(p-1)n}^*$ . If  $Per(A) \neq 0$  (over  $Z_p$ ), then the sequence S is an additive basis of  $Z_p^n$ .

**Proof.** For any vector  $b=(b_1,b_2,\ldots,b_n)$ , let  $u_b$  be the concatenation of the (p-1) vectors  $b+j,b+2j,\ldots,b+(p-1)j$ , where j is the all one vector of length n. By the Permanent Lemma with all sets  $S_i=\{0,1\}$ , there is a subset  $I\subset\{1,2,\ldots,(p-1)n\}$  such that the sum  $\sum_{i\in I}v_i^*$  differs from  $u_b$  in all coordinates. This supplies (p-1) forbidden values for every coordinate of the sum  $\sum_{i\in I}v_i$ , and hence implies that  $\sum_{i\in I}v_i=b$ . Since b was arbitrary, this completes the proof.  $\square$ 

In [9] it is shown that from any set consisting of all elements in the union of an appropriate number of linear bases of  $\mathbb{Z}_p^n$  it is possible to choose (p-1)n vectors satisfying the assumptions of the lemma. This is done by applying some properties of the permanent function. The details can be found in [9]. The following conjecture seems plausible, and would imply, if true, that the union of any set of p bases of  $\mathbb{Z}_p^n$  is an additive basis.

Conjecture 8.4 For any p nonsingular n by n matrices  $A_1, A_2, \ldots, A_p$  over  $Z_p$ , there is an n by pn matrix C such that the pn by pn matrix

$$M' = \begin{bmatrix} A_1 & A_2 & \dots & A_{p-1} & A_p \\ A_1 & A_2 & \dots & A_{p-1} & A_p \\ \vdots & \vdots & \ddots & \vdots & \vdots \\ A_1 & A_2 & \dots & A_{p-1} & A_p \\ & & C & & \end{bmatrix}$$

has a nonzero permanent over  $Z_p$ .

We close this section with a simple result about directed graphs. A *one-regular* subgraph of a digraph is a subgraph of it in which all outdegrees and all indegrees are precisely 1 (that is: a spanning subgraph which is a union of directed cycles.)

**Proposition 8.5** Let D = (V, E) be a digraph containing a one-regular subgraph. Then, for any assignment of a set  $S_v$  of two reals for each vertex v of V, there is a choice  $c(v) \in S_v$  for every v, so that for every vertex u the sum  $\sum_{v: (u,v) \in E} c(v) \neq 0$ .

**Proof.** Let  $A = (a_{u,v})$  be the adjacency matrix of D defined by  $a_{u,v} = 1$  iff  $(u,v) \in E$  and  $a_{u,v} = 0$  otherwise. By the assumption, the permanent of A over the reals is strictly positive. The result thus follows from the permanent lemma.  $\square$ 

#### 9 Ideals of polynomials and combinatorial properties

There are several known results that assert that a combinatorial structure satisfies a certain combinatorial property if and only if an appropriate polynomial associated with it lies in a properly defined ideal. Here are three known results of this type, all applying the graph polynomial defined in Section 7.

Theorem 9.1 (Li and Li, [40]) A graph G does not contain an independent set of k + 1 vertices if and only if the graph polynomial f<sup>G</sup> lies in the ideal generated by all graph polynomials of unions of k pairwise vertex disjoint complete graphs that span its set of vertices.

Theorem 9.2 (Kleitman and Lov´asz, [41], [42]) A graph G is not k colorable if and only if the graph polynomial f<sup>G</sup> lies in the ideal generated by all graph polynomials of complete graphs on k + 1 vertices.

Theorem 9.3 (Alon and Tarsi, [13]) A graph G on the n vertices {1, 2, . . . , n} is not k colorable if and only if the graph polynomial f<sup>G</sup> lies in the ideal generated by the polynomials x k <sup>i</sup> −1, (1 ≤ i ≤ n).

Here is a quick proof of the last theorem, using Theorem 1.1.

Proof of Theorem 9.3. If f<sup>G</sup> lies in the ideal generated by the polynomials x k <sup>i</sup> −1 then it vanishes whenever each x<sup>i</sup> attains a value which is a k th root of unity. This means that in any coloring of the vertices of G by the k th roots of unity, there is a pair of adjacent vertices that get the same color, implying that G is not k-colorable.

Conversely, suppose G is not k-colorable. Then f<sup>G</sup> vanishes whenever each of the polynomials gi(xi) = x k <sup>i</sup> −1 vanishes, and thus, by Theorem 1.1, f<sup>G</sup> lies in the ideal generated by these polynomials. ✷

As described in Section 7, there are several interesting combinatorial consequences that can be derived from (some versions of) Theorem 9.3, but even without any consequences, such theorems are interesting in their own. One reason for this is that these theorems characterize coNP-complete properties, which, according to the common belief that the complexity classes NP and coNP differ, cannot be checked by a polynomial time algorithm.

Using Theorem 1.1 it is not difficult to generate results of this type. We illustrate this with two examples, described below. Many other results can be formulated and proved in a similar manner. It would be nice to deduce any interesting combinatorial consequences of these results or their relatives.

The bandwidth of a graph G = (V, E) on n vertices is the minimum integer k such that there is a bijection f : V 7→ {1, 2, . . . , n} satisfying |f(u) − f(v)| ≤ k for every edge uv ∈ E. This invariant has been studied extensively by various researchers. See, e.g., [19] for a survey.

Proposition 9.4 The bandwidth of a graph G = (V, E) on a set V = {1, 2, . . . , n} of n vertices is at least k + 1 if and only if the polynomial

$$Q_{G,k}(x_1, \dots, x_n) = \prod_{1 \le i < j \le n} (x_i - x_j) \prod_{ij \in E, i < j} \prod_{k < |l| < n} (x_i - x_j - l)$$

lies in the ideal generated by the polynomials

$$\{g_i(x_i) = \prod_{j=1}^n (x_i - j), 1 \le i \le n\}.$$

Proof. If QG,k lies in the above mentioned ideal, then it vanishes whenever we substitute a value in {1, 2, . . . , n} for each x<sup>i</sup> . In particular, it vanishes when we substitute distinct values for these variables, implying that there is some edge ij ∈ E for which |x<sup>i</sup> − x<sup>j</sup> | > k, and hence the bandwidth of G exceeds k.

Conversely, assume the bandwidth of G exceeds k. We claim that in this case QG,k(x1, . . . , xn) vanishes whenever each x<sup>i</sup> attains a value in {1, 2, . . . , n}. Indeed, if two of the variables attain the same value, the first product (Q 1≤i<j≤n (x<sup>i</sup> − x<sup>j</sup> )) in the definition of QG,k vanishes. Else, the numbers x<sup>i</sup> form a permutation of the members of {1, 2, . . . , n} and thus, by the assumption on the bandwidth, there is some edge ij ∈ E for which |x<sup>i</sup> − x<sup>j</sup> | > k, implying that the polynomial vanishes in this case as well. Therefore, QG,k vanishes whenever each x<sup>i</sup> lies in {1, 2, . . . , n} and thus, by Theorem 1.1, it lies in the ideal generated by the polynomials gi(xi), completing the proof. ✷

A hypergraph H is a pair (V, E), where V is a finite set, whose elements are called vertices, and E is a collection of subsets of V , called edges. It is k-uniform if each edge contains precisely k vertices. Thus, a 2-uniform hypergraph is simply a graph. H is 2-colorable if there is a vertex coloring of H with two colors so that no edge is monochromatic.

Proposition 9.5 The 3-uniform hypergraph H = (V, E) is not 2-colorable if and only if the polynomial

$$\prod_{e \in E} \left[ \left( \sum_{v \in e} x_v \right)^2 - 9 \right]$$

lies in the ideal generated by the polynomials {x 2 <sup>v</sup> − 1 : v ∈ V }.

Proof. The proof is similar to the previous one. If the polynomial lies in that ideal, then it vanishes whenever each x<sup>v</sup> attains a value in {−1, 1}, implying that some edge is monochromatic in each vertex coloring by {−1, 1}, and hence implying that H is not 2-colorable. Conversely, if H is not 2-colorable, then in every vertex coloring by the numbers −1 and +1 some edge is monochromatic, implying that the polynomial vanishes in each such point, and thus showing, by Theorem 1.1, that it lies in the above ideal. ✷

Note that since the properties characterized in any of the theorems in this section are coNPcomplete, it is possible to use the usual reductions and obtain, for each coNP-complete problem, a characterization in terms of some ideals of polynomials. In most cases, however, the known reductions are somewhat complicated, and would thus lead to cumbersome polynomials which are not likely to imply any interesting consequences. The results mentioned here are in terms of relatively simple polynomials, and are therefore more likely to be useful.

#### 10 Concluding remarks

The discussion in Section 7 as well as that in Section 9 raises the hope that the polynomial approach might be helpful in the study of the Four Color Theorem. This certainly deserves more attention. Further results in the study of the List Coloring Conjecture (Conjecture 7.1) using the algebraic technique are also desirable.

Most proofs presented in this paper are based on the two basic theorems, proved in Section 2, whose proofs are algebraic, and hence non-constructive in the sense that they supply no efficient algorithm for solving the corresponding algorithmic problems.

In the classification of algorithmic problems according to their complexity, it is customary to try and identify the problems that can be solved efficiently, and those that probably cannot be solved efficiently. A class of problems that can be solved efficiently is the class P of all problems for which there are deterministic algorithms whose running time is polynomial in the length of the input. A class of problems that probably cannot be solved efficiently are all the NP-complete problems. An extensive list of such problems appears in [31]. It is well known that if any of them can be solved efficiently, then so can all of them, since this would imply that the two complexity classes P and NP are equal.

Is it possible to modify the algebraic proofs given here so that they yield efficient ways of solving the corresponding algorithmic problems? It seems likely that such algorithms do exists. This is related to questions regarding the complexity of search problems that have been studied by several researchers. See, e.g., [37].

In the study of complexity classes like P and NP one usually considers only decision problems, i.e., problems for which the only two possible answers are "yes" or "no." However, the definitions extend easily to the so called "search" problems, which are problems where a more elaborate output is sought. The search problems corresponding to the complexity classes P and NP are sometimes denoted by F P and F NP.

Consider, for example, the obvious algorithmic problem suggested by Theorem 6.1 (for p = 3,

say). Given a simple graph with average degree that exceeds 4 and maximum degree 5, it contains, by this theorem, a 3-regular subgraph. Can we find such a subgraph in polynomial time ?

It seems plausible that finding such a subgraph should not be a very difficult task. However, our proof provides no efficient algorithm for accomplishing this task. The situation is similar with many other algorithmic problems corresponding to the various results presented here. Can we, given an input graph satisfying the assumptions of Theorem 7.3 and given a list of three colors for each of its vertices, find, in polynomial time, a proper vertex coloring assigning each vertex a color from its class ? Similarly, can we color properly the edges of any given planar cubic 2-connected graph using given lists of three colors per edge, in polynomial time ?

These problems remain open. Note, however, that any efficient procedure that finds, for a given input polynomial that satisfies the assumptions of Theorem 1.2, a point (s1, s2, . . . , sn) satisfying its conclusion, would provide efficient algorithms for most of these algorithmic problems. It would thus be interesting to find such an efficient procedure. See also [1] for a related discussion for other algorithmic problems.

Another computational aspect suggested by the results in Section 9 is the complexity of the representation of polynomials in the form that shows they lie in certain ideals. Thus, for example, by Proposition 9.5, a 3-uniform hypergraph is not 2-colorable iff the polynomial associated with it in that proposition is a linear combination with polynomial coefficients of the polynomials x 2 <sup>v</sup> −1. Since the problem of deciding whether such a given input hypergraph is not 2-colorable is coNP-complete, the existence of a representation like this that can be checked in polynomial time would imply that the complexity classes NP and coNP coincide, and this is believed not to be the case by most researchers.

In this paper we developed and discussed a technique in which polynomials are applied for deriving combinatorial consequences. There are several other known proof-techniques in Combinatorics which are based on properties of polynomials. The most common and successful one is based on a dimension argument. This is the method of proving an upper bound for the size of a collection of combinatorial structures satisfying certain prescribed properties by associating each structure with a polynomial in some space of polynomials, showing that these polynomials are linearly independent, and then deducing the required bound from the dimension of the corresponding space. There are many interesting results proved in this manner; see, e.g., [32], [14], [15] and [3] for surveys of results of this type.

#### References

- [1] N. Alon, Non-constructive proofs in Combinatorics, Proc. of the International Congress of Mathematicians, Kyoto 1990, Japan, Springer Verlag, Tokyo (1991), 1421-1429.
- [2] N. Alon, Restricted colorings of graphs, in "Surveys in Combinatorics", Proc. 14th British Combinatorial Conference, London Mathematical Society Lecture Notes Series 187, edited by K. Walker, Cambridge University Press, 1993, 1-33.
- [3] N. Alon, Tools from higher algebra, in: Handbook of Combinatorics, (edited by R. Graham, M. Gr¨otschel and L. Lov´asz), Elseveir and MIT Press (1995), 1749-1783.
- [4] N. Alon and Y. Caro, On three zero-sum Ramsey-type problems, J. Graph Theory 17 (1993), 177-192.
- [5] N. Alon and M. Dubiner, Zero-sum sets of prescribed size, in: "Combinatorics, Paul Erd¨os is Eighty", Bolyai Society, Mathematical Studies, Keszthely, Hungary, 1993, 33-50.
- [6] N. Alon, S. Friedland and G. Kalai, Regular subgraphs of almost regular graphs, J. Combinatorial Theory Ser. B 37 (1984), 79-91. Also: N. Alon, S. Friedland and G. Kalai, Every 4-regular graph plus an edge contains a 3-regular subgraph, J. Combinatorial Theory Ser. B 37 (1984), 92-93.
- [7] N. Alon and Z. F¨uredi, Covering the cube by affine hyperplanes, European J. Combinatorics 14 (1993), 79-83.
- [8] N. Alon, D. Kleitman, R. Lipton, R. Meshulam, M. Rabin and J. Spencer, Set systems with no union of cardinality 0 modulo m, Graphs and Combinatorics 7 (1991), 97-99.
- [9] N. Alon, N. Linial and R. Meshulam, Additive bases of vector spaces over prime fields, J. Combinatorial Theory Ser. A 57 (1991), 203-210.
- [10] N. Alon, M. B. Nathanson, and I. Z. Ruzsa, Adding distinct congruence classes modulo a prime, Amer. Math. Monthly 102 (1995), 250-255.
- [11] N. Alon, M. B. Nathanson, and I. Z. Ruzsa, The polynomial method and restricted sums of congruence classes, J. Number Theory 56 (1996), 404-417.
- [12] N. Alon and M. Tarsi, A nowhere-zero point in linear mappings, Combinatorica 9 (1989), 393- 395.
- [13] N. Alon and M. Tarsi, Colorings and orientations of graphs, Combinatorica 12 (1992), 125-134.

- [14] L. Babai and P. Frankl, Linear Algebra Methods in Combinatorics, to appear.
- [15] A. Blokhuis, Polynomials in Finite Geometries and Combinatorics, in "Surveys in Combinatorics", Proc. 14th British Combinatorial Conference, London Mathematical Society Lecture Notes Series 187, edited by K. Walker, Cambridge University Press, 1993, 35-52.
- [16] B. Bollob´as, Extremal Graph Theory, Academic Press, 1978.
- [17] B. Bollob´as and A. J. Harris, List colorings of graphs, Graphs and Combinatorics 1 (1985), 115-127.
- [18] B. Bollob´as and I. Leader, Sums in the grid, Discrete Math. 162 (1996), 31-48.
- [19] F. R. K. Chung, Labelings of graphs, Selected Topics in Graph Theory 3, Academic Press (1988), 151-168.
- [20] H. Davenport, On the addition of residue classes, J. London Math. Soc. 10 (1935), 30–32, 1935.
- [21] J. A. Dias da Silva and Y. O. Hamidoune, Cyclic spaces for Grassmann derivatives and additive theory, Bull. London Math. Soc. 26 (1994), 140-146.
- [22] D. Z. Du, D. F. Hsu and F. K. Hwang, The Hamiltonian property of consecutive-d digraphs, Mathematical and Computer Modelling 17 (1993), 61-63.
- [23] S. Eliahou and M. Kervaire, Sumsets in vector spaces over finite fields, J. Number Theory 71 (1998), 12-39.
- [24] M. N. Ellingham and L. Goddyn, List edge colorings of some 1-factorable multigraphs, Combinatorica 16 (1996), 343-352.
- [25] P. Erd˝os and R. L. Graham, Old and New Problems and Results in Combinatorial Number Theory, L'Enseignement Math´ematique, Geneva, 1980.
- [26] P. Erd˝os, A. Ginzburg and A. Ziv, Theorem in the additive number theory, Bull. Research Council Israel 10F (1961), 41-43.
- [27] P. Erd˝os, A. L. Rubin and H. Taylor, Choosability in graphs, Proc. West Coast Conf. on Combinatorics, Graph Theory and Computing, Congressus Numerantium XXVI, 1979, 125-157.
- [28] H. Fleischner and M. Stiebitz, A solution to a coloring problem of P. Erd˝os, Discrete Math. 101 (1992), 39-48.

- [29] G. A. Freiman, L. Low, and J. Pitman, The proof of Paul Erd˝os' conjecture of the addition of different residue classes modulo a prime number, In: Structure Theory of Set Addition, CIRM Marseille (1993), 99-108.
- [30] F. Galvin, The list chromatic index of a bipartite multigraph, J. Combinatorial Theory Ser. B 63 (1995), 153-158.
- [31] M. R. Garey and D. S. Johnson, Computers and Intractability, A guide to the Theory of NP-Completeness, W. H. Freeman and Company, New York, 1979.
- [32] C. Godsil, Tools from linear algebra, in: Handbook of Combinatorics, (edited by R. Graham, M. Gr¨otschel and L. Lov´asz), Elseveir and MIT Press (1995), 1705-1748.
- [33] R. H¨aggkvist and J. Janssen, New bounds on the list chromatic index of the complete graph and other simple graphs, Combin., Prob. and Comput. 6 (1997), 295-313.
- [34] H. Harborth, Ein Extremalproblem f¨ur Gitterpunkte, J. Reine Angew. Math. 262/263 (1973), 356-360.
- [35] F. Jaeger, On the Penrose number of cubic diagrams, Discrete Math. 74 (1989), 85-97.
- [36] F. Jaeger, N. Linial, C. Payan and M. Tarsi, Group connectivity of graphs- a nonhomogeneous analogue of nowhere-zero flow, J. Combinatorial Theory Ser. B 56 (1992), 165-182.
- [37] D. S. Johnson, C. H. Papadimitriou and M. Yannakakis, How easy is local search?, JCSS 37 (1988), 79-100.
- [38] J. Kahn, Asymptotically good list colorings, J. Combinatorial Theory Ser. A 73 (1996), 1–59.
- [39] A. Kemnitz, On a lattice point problem, Ars Combinatoria 16b (1983), 151-160.
- [40] S. Y. R. Li and W. C. W. Li, Independence numbers of graphs and generators of ideals, Combinatorica 1 (1981), 55-61.
- [41] L. Lov´asz, Bounding the independence number of a graph, in: Bonn Workshop on Combinatorial Optimization, (A. Bachem, M. Gr¨otschel and B. Korte, eds.), Mathematics Studies 66, Annals of Discrete Mathematics 16, North Holland, Amsterdam, 1982, 213-223.
- [42] L. Lov´asz, Stable sets and polynomials, Discrete Math. 124 (1994), 137-153.
- [43] R. Mansfield, How many slopes in a polygon? Israel J. Math. 39 (1981), 265–272.

- [44] M. P. A. Macmahon, Combinatory Analysis, Chelsea Publishing Company, 1915, Chapter V.
- [45] M. B. Nathanson, Additive Number Theory: Inverse Theorems and the Geometry of Sumsets, Springer-Verlag, New York, 1996.
- [46] J. Petersen, Die Theorie der regul¨aren Graphs, Acta Math. 15 (1891), 193-220.
- [47] L. Pyber, Regular subgraphs of dense graphs, Combinatorica 5 (1985), 347-349.
- [48] L. Pyber, V. R¨odl and E. Szemer´edi, Dense Graphs without 3-regular Subgraphs , J. Combinatorial Theory Ser. B 63 (1995), 41-54.
- [49] U.-W. Rickert, Uber eine Vermutung in der additiven Zahlentheorie ¨ , PhD thesis, Tech. Univ. Braunschweig, 1976.
- [50] O. J. R¨odseth, ¨ Sums of distinct residues mod p, Acta Arith. 65 (1994), 181-184.
- [51] D. E. Scheim, The number of edge 3-colorings of a planar cubic graph as a permanent, Discrete Math. 8 (1974), 377-382.
- [52] W. Schmidt, Equations over Finite Fields, an Elementary Approach, Lecture Notes in Mathematics, Vol. 536, Springer, Berlin, 1976.
- [53] V. A. Ta´skinov, Regular subgraphs of regular graphs, Soviet Math. Dokl. 26 (1982), 37-38.
- [54] S. C. Tsai, Lower bounds on representing Boolean functions as polynomials in Zm, SIAM J. Discrete Math. 9 (1996), 55-62.
- [55] L. Vigneron, Remarques sur les r´eseaux cubiques de classe 3 associ´es au probl´eme des quatre couleurs, C. R. Acad. Sc. Paris, t. 223 (1946), 770-772.
- [56] V. G. Vizing, On an estimate on the chromatic class of a p-graph (in Russian), Diskret. Analiz. 3 (1964), 25-30.
- [57] V. G. Vizing, Coloring the vertices of a graph in prescribed colors (in Russian), Diskret. Analiz. No. 29, Metody Diskret. Anal. v. Teorii Kodov i Shem 101 (1976), 3-10.
- [58] B. L. van der Waerden, Modern Algebra, Julius Springer, Berlin, 1931.
- [59] S. Yuzvinsky, Orthogonal pairings of Euclidean spaces, Michigan Math. J. 28 (1981), 109-119.