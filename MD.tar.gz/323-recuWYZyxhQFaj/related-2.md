# 18. Structure Functions

Revised August 2023 by E.C. Aschenauer (BNL), R.S. Thorne (UCL) and R. Yoshida (ANL).

#### <span id="page-0-1"></span>18.1 Deep inelastic scattering

High-energy lepton-nucleon scattering plays a key role in determining the partonic structure of the proton. The process  $\ell N \to \ell' X$  is illustrated in Fig. 18.1. The filled circle in this figure represents the internal structure of the proton which can be expressed in terms of structure functions.

<span id="page-0-0"></span>![](_page_0_Picture_6.jpeg)

**Figure 18.1:** Kinematic quantities for the description of deep inelastic scattering. The quantities k and k' are the four-momenta of the incoming and outgoing leptons, P is the four-momentum of a nucleon with mass M, and W is the mass of the recoiling system X. The exchanged particle is a  $\gamma$ ,  $W^{\pm}$ , or Z; it transfers four-momentum q = k - k' to the nucleon.

Invariant quantities:

 $\nu = \frac{q \cdot P}{M} = E - E'$  is the lepton's energy loss in the nucleon rest frame (in earlier literature sometimes  $\nu = q \cdot P$ ). Here, E and E' are the initial and final lepton energies in the nucleon rest frame

$$Q^2 = -q^2 = 2(EE' - \overrightarrow{k} \cdot \overrightarrow{k}') - m_\ell^2 - m_{\ell'}^2$$
 where  $m_\ell(m_{\ell'})$  is the initial (final) lepton mass. If  $EE' \sin^2(\theta/2) \gg m_\ell^2$ ,  $m_{\ell'}^2$ , then

 $\approx 4EE'\sin^2(\theta/2)$ , where  $\theta$  is the lepton's scattering angle with respect to the lepton beam direction.

 $x=\frac{Q^2}{2M\nu}$  where, in the parton model, x is the fraction of the nucleon's momentum carried by the struck quark. Beyond leading order the equation remains the definition of x, but this is no longer identical to nucleon momentum fraction.

 $y = \frac{q \cdot P}{k \cdot P} = \frac{\nu}{E}$  is the fraction of the lepton's energy lost in the nucleon rest frame.

 $W^2=(P+q)^2=M^2+2M\nu-Q^2$  is the mass squared of the system X recoiling against the scattered lepton.

 $s=(k+P)^2=rac{Q^2}{xy}+M^2+m_\ell^2$  is the center-of-mass energy squared of the lepton-nucleon system.

The process in Fig. 18.1 is called deep  $(Q^2 \gg M^2)$  inelastic  $(W^2 \gg M^2)$  scattering (DIS). In what follows, the masses of the initial and scattered leptons,  $m_\ell$  and  $m_{\ell'}$ , are neglected.

#### 18.1.1 DIS cross sections

The double-differential cross section for deep inelastic scattering can be expressed in terms of kinematic variables in several ways.

$$\frac{d^2\sigma}{dx\,dy} = x\left(s - M^2\right) \frac{d^2\sigma}{dx\,dQ^2} = \frac{2\pi\,M\nu}{E'} \frac{d^2\sigma}{d\Omega_{\text{Nrest}}\,dE'} \,. \tag{18.1}$$

In lowest-order perturbation theory, the cross section for the scattering of polarized leptons on polarized nucleons can be expressed in terms of the products of leptonic and hadronic tensors associated with the coupling of the exchanged bosons at the upper and lower vertices in Fig. 18.1 (see Refs. [1-4])

<span id="page-1-1"></span><span id="page-1-0"></span>
$$\frac{d^2\sigma}{dxdy} = \frac{2\pi y\alpha^2}{Q^4} \sum_j \eta_j L_j^{\mu\nu} W_{\mu\nu}^j .$$
 (18.2)

For neutral-current processes, the summation is over  $j = \gamma, Z$  and  $\gamma Z$  representing photon and Z exchange and the interference between them, whereas for charged-current interactions there is only W exchange, j = W. (For transverse nucleon polarization, there is a dependence on the azimuthal angle of the scattered lepton.) The lepton tensor  $L_{\mu\nu}$  is associated with the coupling of the exchange boson to the leptons. For incoming leptons of charge  $e = \pm 1$  and helicity  $\lambda = \pm 1$ ,

$$L_{\mu\nu}^{\gamma} = 2\left(k_{\mu}k_{\nu}' + k_{\mu}'k_{\nu} - (k \cdot k' - m_{\ell}^{2})g_{\mu\nu} - i\lambda\varepsilon_{\mu\nu\alpha\beta}k^{\alpha}k'^{\beta}\right),$$

$$L_{\mu\nu}^{\gamma Z} = (g_{V}^{e} + e\lambda g_{A}^{e})L_{\mu\nu}^{\gamma}, \quad L_{\mu\nu}^{Z} = (g_{V}^{e} + e\lambda g_{A}^{e})^{2}L_{\mu\nu}^{\gamma},$$

$$L_{\mu\nu}^{W} = (1 + e\lambda)^{2}L_{\mu\nu}^{\gamma}, \qquad (18.3)$$

where  $g_V^e = -\frac{1}{2} + 2\sin^2\theta_W$ ,  $g_A^e = -\frac{1}{2}$ .

Although here the helicity basis is adopted, an alternative approach is to express the tensors in Eq. (18.3) in terms of the polarization of the lepton.

The factors  $\eta_j$  in Eq. (18.2) denote the ratios of the corresponding propagators and couplings to the photon propagator and coupling squared

<span id="page-1-2"></span>
$$\eta_{\gamma} = 1 \; ; \; \eta_{\gamma Z} = \left(\frac{G_F M_Z^2}{2\sqrt{2}\pi\alpha}\right) \left(\frac{Q^2}{Q^2 + M_Z^2}\right);$$

$$\eta_Z = \eta_{\gamma Z}^2 \; ; \; \eta_W = \frac{1}{2} \left(\frac{G_F M_W^2}{4\pi\alpha} \frac{Q^2}{Q^2 + M_W^2}\right)^2. \tag{18.4}$$

The hadronic tensor, which describes the interaction of the appropriate electroweak currents with the target nucleon, is given by

$$W_{\mu\nu} = \frac{1}{4\pi} \int d^4z \, e^{iq\cdot z} \, \langle P, S | \left[ J^{\dagger}_{\mu}(z), J_{\nu}(0) \right] | P, S \rangle, \tag{18.5}$$

where  $J_{\alpha}$  is the hadronic contribution to the electromagnetic, or weak current and S denotes the nucleon-spin 4-vector, with  $S^2 = -M^2$  and  $S \cdot P = 0$ .

#### <span id="page-2-3"></span>18.2 Structure functions of the proton

The structure functions are defined in terms of the hadronic tensor (see Refs. [1–3])

$$W_{\mu\nu} = \left(-g_{\mu\nu} + \frac{q_{\mu}q_{\nu}}{q^{2}}\right) F_{1}(x,Q^{2}) + \frac{\hat{P}_{\mu}\hat{P}_{\nu}}{P \cdot q} F_{2}(x,Q^{2})$$

$$- i\varepsilon_{\mu\nu\alpha\beta} \frac{q^{\alpha}P^{\beta}}{2P \cdot q} F_{3}(x,Q^{2})$$

$$+ i\varepsilon_{\mu\nu\alpha\beta} \frac{q^{\alpha}}{P \cdot q} \left[S^{\beta}g_{1}(x,Q^{2}) + \left(S^{\beta} - \frac{S \cdot q}{P \cdot q} P^{\beta}\right) g_{2}(x,Q^{2})\right]$$

$$+ \frac{1}{P \cdot q} \left[\frac{1}{2} \left(\hat{P}_{\mu}\hat{S}_{\nu} + \hat{S}_{\mu}\hat{P}_{\nu}\right) - \frac{S \cdot q}{P \cdot q} \hat{P}_{\mu}\hat{P}_{\nu}\right] g_{3}(x,Q^{2})$$

$$+ \frac{S \cdot q}{P \cdot q} \left[\frac{\hat{P}_{\mu}\hat{P}_{\nu}}{P \cdot q} g_{4}(x,Q^{2}) + \left(-g_{\mu\nu} + \frac{q_{\mu}q_{\nu}}{q^{2}}\right) g_{5}(x,Q^{2})\right]$$
(18.6)

where

<span id="page-2-0"></span>
$$\hat{P}_{\mu} = P_{\mu} - \frac{P \cdot q}{q^2} q_{\mu}, \qquad \hat{S}_{\mu} = S_{\mu} - \frac{S \cdot q}{q^2} q_{\mu} . \tag{18.7}$$

In [2], the definition of  $W_{\mu\nu}$  with  $\mu \leftrightarrow \nu$  is adopted, which changes the sign of the  $\varepsilon_{\mu\nu\alpha\beta}$  terms in Eq. (18.6), although the formulae given below are unchanged. Ref. [1] tabulates the relation between the structure functions defined in Eq. (18.6) and other choices available in the literature.

The cross sections for neutral- and charged-current deep inelastic scattering on unpolarized nucleons can be written in terms of the structure functions in the generic form

<span id="page-2-1"></span>
$$\frac{d^2\sigma^i}{dxdy} = \frac{4\pi\alpha^2}{xyQ^2} \eta^i \left\{ \left( 1 - y - \frac{x^2y^2M^2}{Q^2} \right) F_2^i + y^2xF_1^i \mp \left( y - \frac{y^2}{2} \right) xF_3^i \right\}, \tag{18.8}$$

where  $i={\rm NC}$ , CC corresponds to neutral-current  $(eN\to eX)$  or charged-current  $(eN\to \nu X)$  or  $\nu N\to eX$ ) processes, respectively. For incoming neutrinos,  $L^W_{\mu\nu}$  of Eq. (18.3) is still true, but with  $e,\lambda$  corresponding to the outgoing charged lepton. In the last term of Eq. (18.8), the – sign is taken for an incoming  $e^+$  or  $\bar{\nu}$  and the + sign for an incoming  $e^-$  or  $\nu$ . The factor  $\eta^{\rm NC}=1$  for unpolarized  $e^\pm$  beams, whereas

$$\eta^{\rm CC} = (1 \pm \lambda)^2 \eta_W \tag{18.9}$$

with  $\pm$  for  $\ell^{\pm}$ ; and where  $\lambda$  is the helicity of the incoming lepton and  $\eta_W$  is defined in Eq. (18.4); for incoming neutrinos  $\eta^{\text{CC}} = 4\eta_W$ . The CC structure functions, which derive exclusively from W exchange, are

$$F_1^{\text{CC}} = F_1^W, \ F_2^{\text{CC}} = F_2^W, \ xF_3^{\text{CC}} = xF_3^W.$$
 (18.10)

The NC structure functions  $F_2^{\gamma}, F_2^{\gamma Z}, F_2^{Z}$  are, for  $e^{\pm}N \to e^{\pm}X$ , given by [5],

$$F_2^{\text{NC}} = F_2^{\gamma} - (g_V^e \pm \lambda g_A^e) \eta_{\gamma Z} F_2^{\gamma Z} + (g_V^{e^2} + g_A^{e^2} \pm 2\lambda g_V^e g_A^e) \eta_Z F_2^Z$$
 (18.11)

and similarly for  $F_1^{NC}$ , whereas

$$xF_3^{\text{NC}} = -(g_A^e \pm \lambda g_V^e)\eta_{\gamma Z}xF_3^{\gamma Z} + [2g_V^e g_A^e \pm \lambda (g_V^{e^2} + g_A^{e^2})]\eta_Z xF_3^Z . \tag{18.12}$$

The polarized cross-section difference

<span id="page-2-2"></span>
$$\Delta \sigma = \sigma(\lambda_n = -1, \lambda_\ell) - \sigma(\lambda_n = 1, \lambda_\ell) , \qquad (18.13)$$

where  $\lambda_{\ell}, \lambda_n$  are the helicities (±1) of the incoming lepton and nucleon, respectively, may be expressed in terms of the five structure functions  $g_{1,...5}(x,Q^2)$  of Eq. (18.6). Explicitly,

$$\frac{d^2 \Delta \sigma^i}{dx dy} = \frac{8\pi \alpha^2}{xyQ^2} \eta^i \left\{ -\lambda_\ell y \left( 2 - y - 2x^2 y^2 \frac{M^2}{Q^2} \right) x g_1^i \right.$$

$$+ \lambda_\ell 4x^3 y^2 \frac{M^2}{Q^2} g_2^i + 2x^2 y \frac{M^2}{Q^2} \left( 1 - y - x^2 y^2 \frac{M^2}{Q^2} \right) g_3^i$$

$$- \left( 1 + 2x^2 y \frac{M^2}{Q^2} \right) \left[ \left( 1 - y - x^2 y^2 \frac{M^2}{Q^2} \right) g_4^i + x y^2 g_5^i \right] \right\}$$
(18.14)

with i=NC or CC as before. The Eq. (18.13) corresponds to the difference of antiparallel minus parallel spins of the incoming particles for  $e^-$  or  $\nu$  initiated reactions, but the difference of parallel minus antiparallel for  $e^+$  or  $\bar{\nu}$  initiated processes. For longitudinal nucleon polarization, the contributions of  $g_2$  and  $g_3$  are suppressed by powers of  $M^2/Q^2$ . These structure functions give an unsuppressed contribution to the cross section for transverse polarization [1], but in this case the cross-section difference vanishes as  $M/Q \to 0$ .

Because the same tensor structure occurs in the spin-dependent and spin-independent parts of the hadronic tensor of Eq. (18.6) in the  $M^2/Q^2 \to 0$  limit, the differential cross-section difference of Eq. (18.14) may be obtained from the differential cross section Eq. (18.8) by replacing

<span id="page-3-0"></span>
$$F_1 \rightarrow -g_5 , \quad F_2 \rightarrow -g_4 , \quad F_3 \rightarrow 2g_1 , \qquad (18.15)$$

and multiplying by two, since the total cross section is the average over the initial-state polarizations. In this limit, Eq. (18.8) and Eq. (18.14) may be written in the form

$$\frac{d^2\sigma^i}{dxdy} = \frac{2\pi\alpha^2}{xyQ^2} \,\eta^i \left[ Y_+ F_2^i \mp Y_- x F_3^i - y^2 F_L^i \right],$$

$$\frac{d^2 \Delta \sigma^i}{dx dy} = \frac{4\pi \alpha^2}{xyQ^2} \eta^i \left[ -Y_+ g_4^i \mp Y_- 2x g_1^i + y^2 g_L^i \right], \tag{18.16}$$

with i = NC or CC, where  $Y_{\pm} = 1 \pm (1 - y)^2$  and

$$F_L^i = F_2^i - 2xF_1^i, g_L^i = g_4^i - 2xg_5^i. (18.17)$$

In the naive quark-parton model, the analogy with the Callan-Gross relations [6]  $F_L^i = 0$ , are the Dicus relations [7]  $g_L^i = 0$ . Therefore, there are only two independent polarized structure functions:  $g_1$  (parity conserving) and  $g_5$  (parity violating), in analogy with the unpolarized structure functions  $F_1$  and  $F_3$ .

## <span id="page-3-1"></span>18.2.1 Structure functions in the quark parton model

In the naive quark-parton model [8,9], contributions to the structure functions  $F^i$  and  $g^i$  can be expressed in terms of the quark distribution functions  $q(x,Q^2)$  of the proton, where  $q=u,\overline{u},d,\overline{d}$  etc. The quantity  $q(x,Q^2)dx$  is the number of quarks (or antiquarks) of designated flavor that carry a momentum fraction between x and x+dx of the proton's momentum in a frame in which

the proton momentum is large. One of the most striking predictions of the quark-parton model is that the structure functions  $F_i$ ,  $g_i$  scale, i.e.,  $F_i(x, Q^2) \to F_i(x)$  in the Bjorken limit that  $Q^2$  and  $\nu \to \infty$  with x fixed [10]. This property is related to the assumption that the transverse momentum of the partons in the infinite-momentum frame of the proton is small.

For the neutral-current processes  $ep \rightarrow eX$ ,

$$\begin{split} \left[F_{2}^{\gamma},\ F_{2}^{\gamma Z},\ F_{2}^{Z}\right] &= x \sum_{q} \left[e_{q}^{2},\ 2e_{q}g_{V}^{q},\ g_{V}^{q^{2}} + g_{A}^{q^{2}}\right]\ (q + \overline{q})\ , \\ \left[F_{3}^{\gamma},\ F_{3}^{\gamma Z},\ F_{3}^{Z}\right] &= \sum_{q} \left[0,\ 2e_{q}g_{A}^{q},\ 2g_{V}^{q}g_{A}^{q}\right]\ (q - \overline{q})\ , \\ \left[g_{1}^{\gamma},\ g_{1}^{\gamma Z},\ g_{1}^{Z}\right] &= \frac{1}{2}\ \sum_{q} \left[e_{q}^{2},\ 2e_{q}g_{V}^{q},\ g_{V}^{q^{2}} + g_{A}^{q^{2}}\right]\ (\Delta q + \Delta \overline{q})\ , \\ \left[g_{5}^{\gamma},\ g_{5}^{\gamma Z},\ g_{5}^{Z}\right] &= \sum_{q} \left[0,\ e_{q}g_{A}^{q},\ g_{V}^{q}g_{A}^{q}\right]\ (\Delta \overline{q} - \Delta q)\ , \end{split}$$
(18.18)

where  $g_V^q = \pm \frac{1}{2} - 2e_q \sin^2 \theta_W$  and  $g_A^q = \pm \frac{1}{2}$ , with  $\pm$  according to whether q is a u- or d-type quark respectively. The quantity  $\Delta q$  is the difference  $q \uparrow - q \downarrow$  of the distributions with the quark spin parallel and antiparallel to the proton spin.

For the charged-current processes  $e^-p \to \nu X$  and  $\bar{\nu}p \to e^+X$ , the structure functions are:

<span id="page-4-0"></span>
$$F_2^{W^-} = 2x(u + \overline{d} + \overline{s} + c \dots) ,$$

$$F_3^{W^-} = 2(u - \overline{d} - \overline{s} + c \dots) ,$$

$$g_1^{W^-} = (\Delta u + \Delta \overline{d} + \Delta \overline{s} + \Delta c \dots) ,$$

$$g_5^{W^-} = (-\Delta u + \Delta \overline{d} + \Delta \overline{s} - \Delta c \dots) ,$$

$$(18.19)$$

where only the active flavors have been kept and where CKM mixing has been neglected. For  $e^+p \to \overline{\nu}X$  and  $\nu p \to e^-X$ , the structure functions  $F^{W^+}, g^{W^+}$  are obtained by the flavor interchanges  $d \leftrightarrow u, s \leftrightarrow c$  in the expressions for  $F^{W^-}, g^{W^-}$ . The structure functions for scattering on a neutron are obtained from those of the proton by the interchange  $u \leftrightarrow d$ . For both the neutral- and charged-current processes, the quark-parton model predicts  $2xF_1^i = F_2^i$  and  $g_4^i = 2xg_5^i$ .

Neglecting masses, the structure functions  $g_2$  and  $g_3$  contribute only to scattering from transversely polarized nucleons, and have no simple interpretation in terms of the quark-parton model. They arise from off-diagonal matrix elements  $\langle P, \lambda' | [J^{\dagger}_{\mu}(z), J_{\nu}(0)] | P, \lambda \rangle$ , where the proton helicities satisfy  $\lambda' \neq \lambda$ . In fact, the leading-twist contributions to both  $g_2$  and  $g_3$  are both twist-2 and twist-3, which contribute at the same order of  $Q^2$ . The Wandzura-Wilczek relation [11] expresses the twist-2 part of  $g_2$  in terms of  $g_1$  as

$$g_2^i(x) = -g_1^i(x) + \int_x^1 \frac{dy}{y} g_1^i(y)$$
 (18.20)

However, the twist-3 component of  $g_2$  is unknown. Similarly, there is a relation expressing the twist-2 part of  $g_3$  in terms of  $g_4$ . A complete set of relations, including  $M^2/Q^2$  effects, can be found in [12].

#### 18.2.2 Structure functions and QCD

In QCD, there are perturbative corrections to the partonic cross sections defining structure functions. Also, the radiation of hard gluons from the quarks violates the assumption that the transverse momentum of the partons is small, leading to logarithmic scaling violations, which are particularly large at small x, see Fig. 18.2. The radiation of gluons produces the evolution of the partons and structure functions. As  $Q^2$  increases, more and more gluons are radiated, which in turn split into  $q\bar{q}$  pairs. This process leads both to the softening of the initial quark momentum distributions and to the growth of the gluon density and the  $q\bar{q}$  sea as x decreases.

<span id="page-5-0"></span>![](_page_5_Figure_3.jpeg)

Figure 18.2: The proton structure function  $F_2^p$  given at two  $Q^2$  values (6.5 GeV<sup>2</sup> and 90 GeV<sup>2</sup>), which exhibit scaling at the 'pivot' point  $x \sim 0.14$ . See the captions in Fig. 18.10 and Fig. 18.12 for the references of the data. The various data sets have been renormalized by the factors shown in brackets in the key to the plot, which were globally determined in a previous HERAPDF analysis [13]. The curves were obtained using the PDFs from the HERAPDF analysis [14]. In practice, data for the reduced cross section,  $F_2(x,Q^2) - (y^2/Y_+)F_L(x,Q^2)$ , were fitted, rather than  $F_2$  and  $F_L$  separately. The agreement between data and theory at low  $Q^2$  and x can be improved by a positive higher-twist correction to  $F_L(x,Q^2)$  [15,16] (see Fig. 8 of Ref. [16]), or small-x resummation [17,18].

For  $Q^2 \gg M^2$ , the structure functions satisfy the factorization theorem [19],

<span id="page-6-1"></span>
$$F_i = \sum_a C_i^a \otimes f_a + \mathcal{O}(M^2/Q^2), \tag{18.21}$$

where  $\otimes$  denotes the convolution integral

$$C \otimes f = \int_{x}^{1} \frac{dy}{y} C(y) f\left(\frac{x}{y}\right),$$
 (18.22)

and where the coefficient functions  $C_i^a$ , where a=g or q, are given as a power series in  $\alpha_s$ . The scale-dependent parton distribution  $f_a(x,\mu^2)$  corresponds, at a given x, to the density of parton a in the proton integrated over transverse momentum  $k_t$  up to the factorization scale  $\mu$ . Typically,  $\mu$  is the scale of the probe Q. For parton distributions x always refers to the nucleon momentum fraction of the parton, whereas for structure functions it retains the definition in Sec. 18.1. The parton evolution in  $\mu$  is described in QCD by a DGLAP equation (see Refs. [20–23]) which has the schematic form

<span id="page-6-0"></span>
$$\frac{\partial f_a}{\partial \ln \mu^2} \sim \frac{\alpha_s(\mu^2)}{2\pi} \sum_b \left( P_{ab} \otimes f_b \right) , \qquad (18.23)$$

where the  $P_{ab}$ , which describe the parton splitting  $b \to a$ , are also given as a power series in  $\alpha_s$ . Although perturbative QCD can predict, via Eq. (18.23), the evolution of the parton distribution functions from a particular scale,  $\mu_0$ , these DGLAP equations cannot predict them *a priori* at any particular  $\mu_0$ . Thus they must be measured at a starting point  $\mu_0$  before the predictions of QCD can be compared to the data at other scales,  $\mu$ . In general, all observables involving a hard hadronic interaction (such as structure functions) can be expressed as a convolution of calculable, process-dependent coefficient functions and these universal parton distributions, e.g. Eq. (18.21).

It is often convenient to write the evolution equations in terms of the gluon, non-singlet  $(q^{NS})$  and singlet  $(q^S)$  quark distributions, such that

$$q^{NS} = q_i - \overline{q}_i \quad (\text{or } q_i - q_j), \qquad q^S = \sum_i (q_i + \overline{q}_i) .$$
 (18.24)

The non-singlet distributions have non-zero values of flavor quantum numbers, such as isospin and baryon number. The DGLAP evolution equations then take the form

$$\frac{\partial q^{NS}}{\partial \ln \mu^2} = \frac{\alpha_s(\mu^2)}{2\pi} P_{qq} \otimes q^{NS} ,$$

$$\frac{\partial}{\partial \ln \mu^2} \begin{pmatrix} q^S \\ g \end{pmatrix} = \frac{\alpha_s(\mu^2)}{2\pi} \begin{pmatrix} P_{qq} & 2n_f P_{qg} \\ P_{gq} & P_{gg} \end{pmatrix} \otimes \begin{pmatrix} q^S \\ g \end{pmatrix}, \tag{18.25}$$

where *P* are splitting functions that describe the probability of a given parton splitting into two others, and *n<sup>f</sup>* is the number of (active) quark flavors. The leading-order Altarelli-Parisi [\[22\]](#page-20-21) splitting functions are

$$P_{qq} = \frac{4}{3} \left[ \frac{1+x^2}{(1-x)} \right]_+ = \frac{4}{3} \left[ \frac{1+x^2}{(1-x)_+} \right] + 2\delta(1-x) , \qquad (18.26)$$

$$P_{qg} = \frac{1}{2} \left[ x^2 + (1-x)^2 \right] , \ P_{gq} = \frac{4}{3} \left[ \frac{1 + (1-x)^2}{x} \right] ,$$
 (18.27)

$$P_{gg} = 6\left[\frac{1-x}{x} + x(1-x) + \frac{x}{(1-x)_{+}}\right] + \left[\frac{11}{2} - \frac{n_f}{3}\right]\delta(1-x),$$
(18.28)

where the notation [*F*(*x*)]<sup>+</sup> defines a distribution such that for any sufficiently regular test function, *f*(*x*),

$$\int_0^1 dx f(x) [F(x)]_+ = \int_0^1 dx \ (f(x) - f(1)) F(x) \ . \tag{18.29}$$

In general, the splitting functions can be expressed as a power series in *αs*. The series contains both terms proportional to ln *µ* <sup>2</sup> and to ln(1*/x*) and ln(1−*x*). The leading-order DGLAP evolution sums up the (*α<sup>s</sup>* ln *µ* 2 ) *n* contributions, while at next-to-leading order (NLO) the sum over the *αs*(*α<sup>s</sup>* ln *µ* 2 ) *n*−1 terms is included [\[24,](#page-21-0) [25\]](#page-21-1). The NNLO contributions to the splitting functions and the DIS coefficient functions are also all known [\[26–](#page-21-2)[28\]](#page-21-3), as are the N3LO corrections to the coefficient functions [\[29\]](#page-21-4). Some Mellin moments of the N3LO splitting functions are also known [\[30\]](#page-21-5), together with some other pieces of specific information.

In the kinematic region of very small *x*, one may also sum leading terms in ln(1*/x*), independent of the value of ln *µ* 2 . At leading order, LLx, this is done by the BFKL equation for the unintegrated distributions (see Refs. [\[31,](#page-21-6)[32\]](#page-21-7)). The leading-order (*α<sup>s</sup>* ln(1*/x*))*<sup>n</sup>* terms result in a power-like growth, *x* <sup>−</sup>*<sup>ω</sup>* with *ω* = (12*αs*ln2)*/π*, at asymptotic values of ln 1*/x*. The next-to-leading ln 1*/x* (NLLx) contributions are also available [\[33,](#page-21-8) [34\]](#page-21-9). They are so large (and negative) that the results initially appeared to be perturbatively unstable. Methods, based on a combination of collinear and small-*x* resummations, have been developed which reorganize the perturbative series into a more stable hierarchy [\[35–](#page-21-10)[38\]](#page-21-11), and this has been used as the basis for a framework for including the corrections in phenomenological studies [\[39,](#page-21-12)[40\]](#page-21-13). There are some limited indications that small-*x* resummations become necessary for sufficient precision for *x* . 10−<sup>3</sup> at low scales [\[17,](#page-20-16) [18\]](#page-20-17). At sufficiently small *x* it is expected that evolution should also be affected by non-linear/saturation effects due to a high density of partons, i.e. the gluon density would be so high that gluon-gluon recombination effects would become significant, see [\[41–](#page-21-14)[43\]](#page-21-15) for reviews. However, there is not yet any very convincing indication for a non-linear regime for *Q*<sup>2</sup> & 2 GeV<sup>2</sup> in hadron DIS. Better evidence for saturation may be found in more exclusive final states such as dihadron correlations in proton-nucleus collisions, e.g. [\[44,](#page-21-16) [45\]](#page-21-17).

The precision of the experimental data demands that at least NLO, and preferably NNLO, DGLAP evolution be used in comparisons between QCD theory and experiment. Beyond the leading order, it is necessary to specify, and to use consistently, both a renormalization and a factorization scheme. The renormalization scheme used almost universally is the modified minimal subtraction (MS) scheme [\[46,](#page-21-18)[47\]](#page-21-19). The most popular choices for the factorization scheme is also MS [\[48\]](#page-21-20). Historically, sometimes the DIS [\[49\]](#page-21-21) scheme was adopted, in which there are no higher-order corrections to the *F*<sup>2</sup> structure function, and this was extended to a specific definition appropriate to small *x* [\[50\]](#page-22-0). assimilated in the parton distribution functions.

The discussion above relates to the  $Q^2$  behavior of leading-twist (twist-2) contributions to the structure functions. Higher-twist terms, which involve their own non-perturbative input, exist. These die off as powers of Q; specifically twist-n terms are damped by  $1/Q^{n-2}$ . Provided a cut, say  $W^2 > 15 \text{ GeV}^2$  is imposed, the higher-twist terms appear to be numerically unimportant for  $Q^2$  above a few  $\text{GeV}^2$ , except possibly for very small x and more definitely for x close to 1 [51–53], though it is important to note that they are likely to be larger in  $xF_3(x,Q^2)$  than in  $F_2(x,Q^2)$  (see e.g. [54]) due to a lack of a constraining sum rule for  $xF_3(x,Q^2)$ .

## <span id="page-8-0"></span>18.3 Determination of parton distributions

The parton distribution functions (PDFs) can be determined from an analysis of data for deep inelastic lepton-nucleon scattering and for related hard-scattering processes initiated by nucleons; see Refs. [55–61] for reviews. Table 18.1 highlights some of the processes and their primary sensitivity to PDFs. LHC data are playing an increasing role [62], and new processes are continually being added to the list. Fixed-target and collider experiments have complementary kinematic reach (as is shown in Fig. 18.3), which enables the determination of PDFs over a wide range in x and  $\mu^2$ . As more precise LHC data for  $W^{\pm}$ , Z,  $\gamma$ , jet,  $b\bar{b}$  and  $t\bar{t}$  production become available, tighter constraints on the PDFs are expected in a wider kinematic range. At present about half the constraint on PDFs comes from LHC data [63], but much of the constraint still comes from structure functions.

Recent determinations and releases of the unpolarized PDFs up to NNLO have been made by five groups: MSHT [63], NNPDF [66], CT [67], ATLAS [68] and ABMP [69]. The CJ group produce PDFs at NLO and concentrate on the high x, low  $Q^2$  regime, including data with lower kinematic cuts [70]. All groups start evolution at  $Q_0^2 = 1 - 4$  GeV<sup>2</sup>. Most groups use input PDFs of the form  $xf = x^a(...)(1-x)^b$  with 14-32 free parameters in total. In these cases the PDF uncertainties are made available using the "Hessian" formulation. The free parameters are expanded around their best fit values, and orthogonal eigenvector sets of PDFs depending on linear combinations of the parameter variations are obtained. The uncertainty is then the quadratic sum of the uncertainties arising from each eigenvector. The NNPDF group combines a Monte Carlo representation of the probability measure in the space of PDFs with the use of neural networks. Fits are performed to a very large number of "replica" data sets obtained by allowing individual data points to fluctuate randomly by amounts determined by the size of the data uncertainties. This results in a set of replicas of unbiased PDF sets. In this case the best prediction is the average obtained using all PDF replicas and the uncertainty is the standard deviation over all replicas. It is possible to convert the eigenvectors of Hessian-based PDFs to Monte Carlo replicas [71] and vice versa [72]. Recently accumulated information on N<sup>3</sup>LO calculation has been used by MSHT in order to produce a first set of approximate N<sup>3</sup>LO global PDFs [73] together with theoretical uncertainties, and an alternative approach to theoretical uncertainty has been made in [74].

In these analyses, the u, d and s quarks are taken to be massless, but the treatment of the heavy c and b quark masses,  $m_Q$ , differs, and has a long history, which may be traced from Refs. [75–86]. The MSHT, CT, NNPDF and HERAPDF analyses use different variants of the General-Mass Variable-Flavour-Number Scheme (GM-VFNS). This combines fixed-order contributions to the coefficient functions (or partonic cross sections) calculated with the full  $m_Q$  dependence, with the all-order resummation of contributions via DGLAP evolution in which the heavy quarks are treated as massless after starting evolution at some transition point. Transition matrix elements are computed, following [78], which provide the boundary conditions between  $n_f$  and  $n_f + 1$  PDFs. The ABMP analysis uses for structure function calculations a FFNS where only the three light (massless) quarks enter the evolution, while the heavy quarks enter the partonic cross sections with their full  $m_Q$  dependence. The GM-VFNS and FFNS approaches yield different results: in particular  $\alpha_s(M_Z^2)$ 

<span id="page-9-0"></span>**Table 18.1:** The main processes relevant to global PDF analyses, ordered in three groups: fixed-target experiments, HERA and the  $p\bar{p}$  Tevatron / pp LHC. For each process we give an indication of their dominant partonic subprocesses, the primary partons which are probed and the approximate range of x constrained by the data. This list expands as more processes are measured and calculated with sufficient precision.

| Process                                                   | Subprocess                                     | Partons                           | x range                            |
|-----------------------------------------------------------|------------------------------------------------|-----------------------------------|------------------------------------|
| $\ell^{\pm} \{p, n\} \to \ell^{\pm} X$                    | $\gamma^* q \to q$                             | $q,ar{q},g$                       | $x \gtrsim 0.01$                   |
| $\ell^{\pm}n/p \to \ell^{\pm}X$                           | $\gamma^* d/u \to d/u$                         | d/u                               | $x \gtrsim 0.01$                   |
| $pp \to \mu^+ \mu^- X$                                    | $u\bar{u},d\bar{d}\to\gamma^*$                 | $ar{q}$                           | $0.015 \lesssim x \lesssim 0.35$   |
| $pn/pp \to \mu^+\mu^- X$                                  | $(u\bar{d})/(u\bar{u}) \to \gamma^*$           | $ar{d}/ar{u}$                     | $0.015 \lesssim x \lesssim 0.35$   |
| $\nu(\bar{\nu})  N \to \mu^-(\mu^+)  X$                   | $W^*q \to q'$                                  | $q,ar{q}$                         | $0.01 \lesssim x \lesssim 0.5$     |
| $\nu N \to \mu^- \mu^+ X$                                 | $W^*s \to c$                                   | s                                 | $0.01 \lesssim x \lesssim 0.2$     |
| $\bar{\nu} N \to \mu^+ \mu^- X$                           | $W^*\bar{s} \to \bar{c}$                       | $ar{s}$                           | $0.01 \lesssim x \lesssim 0.2$     |
| $e^{\pm}  p \to e^{\pm}  X$                               | $\gamma^* q \to q$                             | $g,q,ar{q}$                       | $10^{-4} \lesssim x \lesssim 0.1$  |
| $e^+ p \to \bar{\nu} X$                                   | $W^+\left\{d,s\right\} \to \left\{u,c\right\}$ | d, s                              | $x \gtrsim 0.01$                   |
| $e^{\pm}p \rightarrow e^{\pm}c\bar{c}X, e^{\pm}b\bar{b}X$ | $\gamma^*c \to c, \gamma^*g \to c\bar{c}$      | c,b,g                             | $10^{-4} \lesssim x \lesssim 0.01$ |
| $e^{\pm}p \rightarrow \mathrm{jet} + X$                   | $\gamma^* g \to q \bar{q}$                     | g                                 | $0.01 \lesssim x \lesssim 0.1$     |
| $p\bar{p}, pp \to \text{jet(dijet)} + X$                  | gg,qg,qq 	o 2j                                 | g,q                               | $0.00005 \lesssim x \lesssim 0.5$  |
| $p\bar{p} \to (W^\pm \to \ell^\pm \nu)  X$                | $ud \to W^+, \bar{u}\bar{d} \to W^-$           | $u,d,s,\bar{u},\bar{d},\bar{s}$   | $x \gtrsim 0.05$                   |
| $pp 	o (W^\pm 	o \ell^\pm  u)  X$                         | $u\bar{d} \to W^+, d\bar{u} \to W^-$           | $u,d,s,\bar{u},\bar{d},\bar{s},g$ | $x \gtrsim 0.001$                  |
| $p\bar{p}(pp) \to (Z \to \ell^+\ell^-)X$                  | $uu,dd,(u\bar{u},)\to Z$                       | u,d,s,(g)                         | $x \gtrsim 0.001$                  |
| $pp \to W^- c, \ W^+ \bar{c}$                             | $gs \to W^-c$                                  | $s,ar{s}$                         | $x \sim 0.01$                      |
| $pp \to (\gamma^* \to \ell^+ \ell^-) X$                   | $u\bar{u},d\bar{d},\to\gamma^*$                | $ar{q},g$                         | $x \gtrsim 10^{-5}$                |
| $pp \to (\gamma^* \to \ell^+ \ell^-) X$                   | $u\gamma, d\gamma, \to \gamma^*$               | $\gamma$                          | $x \gtrsim 10^{-2}$                |
| $pp 	o b \bar b  X, \ t \bar t X$                         | $gg 	o bar{b}, \;\; tar{t}$                    | g                                 | $x \gtrsim 10^{-5}, 10^{-2}$       |
| $pp \to t(\bar{t}) X,$                                    | $bu(\bar{b}d) \to td(\bar{t}u)$                | b, d/u                            | $x \gtrsim 10^{-2}$                |
| $pp \to \text{exclusive } J/\psi, \Upsilon$               | $\gamma^*(gg) \to J/\psi, \Upsilon$            | g                                 | $x \gtrsim 10^{-5}, 10^{-4}$       |
| $pp \to \gamma X$                                         | $gq \to \gamma q, g\bar{q} \to \gamma \bar{q}$ | g                                 | $x \gtrsim 0.005$                  |

and the large-x gluon PDF at large  $Q^2$  are both significantly smaller in the FFNS. It has been argued [52, 53, 85] that the difference is due to the slow convergence of the  $\ln^n(Q^2/m_Q^2)$  terms in certain regions in a FFNS. The final HERA combination of heavy flavour structure function data has been published [87], and the evolution of these measurements and their interpretation may be

<span id="page-10-0"></span>![](_page_10_Figure_2.jpeg)

**Figure 18.3:** Kinematic domains in *x* and *Q*<sup>2</sup> probed by fixed-target and collider experiments, where here *Q*<sup>2</sup> can refer either the literal *Q*<sup>2</sup> for deep inelastic scattering, or the hard scale of the process in hadron-hadron collisions, e.g. invariant mass or transverse momentum *p* 2 *T* . Some of the final states accessible at the LHC are indicated in the appropriate regions, where *y* is the rapidity. The incoming partons have *x*1*,*<sup>2</sup> = (*Q/*14 TeV)*e* <sup>±</sup>*<sup>y</sup>* where *Q* is the hard scale of the process shown in blue in the figure. For example, open charm production [\[64\]](#page-22-21) and exclusive *J/ψ* and *Υ* production [\[65\]](#page-22-22) at high |*y*| at the LHC may probe the gluon PDF down to *x* ∼ 10−<sup>5</sup> .

traced in [\[88\]](#page-23-2).

The recent determinations of the groups fitting a variety of data and using a GM-VFNS (MSHT, NNPDF and CT) have converged, so that now a good agreement has been achieved between the resulting PDFs. Indeed, the recent global fit PDF sets, CT18 [67], MSHT2018 [63], and NNPDF3.1 [89], have been combined [90] using the Monte Carlo approach [71] mentioned above. The single combined set of PDFs is discussed in detail in Ref. [91].

For illustration, we show in Fig. 18.4 the PDFs obtained in the NNLO MSHT analysis [63] at scales  $\mu^2 = 10$  and  $10^4$  GeV<sup>2</sup> (and an equivalent plot for polarized PDFs from NNPDF [92]). The values of  $\alpha_s$  found by MSHT [93] may be taken as representative of those resulting from the GM-VFNS analyses

NLO: 
$$\alpha_s(M_Z^2) = 0.1203 \pm 0.0015$$
,

NNLO: 
$$\alpha_s(M_Z^2) = 0.1174 \pm 0.0013$$
,

where the error (at 68% C.L.) corresponds to the uncertainties resulting from the data fitted (the uncertainty that might be expected from the neglect of higher orders is at least as large). A similar results is found by the NNPDF group [94], who find  $\alpha_s(M_Z^2) = 0.1185 \pm 0.0012$  at NNLO and the CT group [67], who obtain  $\alpha_s(M_Z^2) = 0.1164 \pm 0.0026$ . The ABMP analysis [69], which uses a FFNS, finds  $\alpha_s(M_Z^2) = 0.1147 \pm 0.0011$  at NNLO.

As a first step towards the inclusion of higher order electroweak corrections a recent development has been a vastly increased understanding of the photon content of the proton. Sets of PDFs with a photon contribution were considered in Refs. [95–97]. However, due to weak data constraints, the uncertainty was extremely large. Subsequently, there has been a much improved understanding of the separation into elastic and inelastic contributions [98–100]. This gives much more theoretical precision, since the elastic contribution, arising from coherent emission of a photon from the proton, can be directly related to the well-known proton electric and magnetic form factors; the model dependence of the inelastic (incoherent) contribution, related to the quark PDFs, is at the level of tens of percent. A final and decisive development directly relating the entire photon contribution to the proton structure function [101] resulted in a determination of the photon content of the proton as precise as that of the light quarks. The framework has been applied within global fits to PDFs via an iterative procedure in [102] and to provide the low-scale input photon PDF in [103, 104]. A further development is the calculation of photon-initiated collider processes directly from structure functions [105].

There are also some calculations of PDFs using lattice QCD, see [106, 107] for a recent review. There has been significant recent progress in the development of efficient algorithms for generating ensembles of gauge field configurations and in tools for extracting the required information from correlation functions. However, there remain a number of sources of systematic uncertainty; discretization effects, pion mass dependence, finite volume effects, excited state contamination and renormalization, which need to be determined and ideally minimised. Moreover, PDFs cannot be determined directly in Euclidean lattice QCD because they depend on quantum fields at light-like separations. Traditionally the lattice has been used to determine matrix elements of twist two operators which can be related to integer moments of PDFs. Until recently these did not always agree well with determinations using global fit PDFs [106]. However, there have been recent improvements [108–110], though uncertainties are still relatively large. An alternative approach [111] suggested the computation of the matrix elements of frame-dependent, equal-time correlators in the large momentum limit. This leads to so-called Quasi-PDFs, which in the infinite momentum frame can be related to light-cone PDFs via a matching procedure, and there is the closely related psuedo PDF appraoch [112]. Recent results using physical values of the light quark masses are in [113–117].

<span id="page-12-0"></span>![](_page_12_Figure_2.jpeg)

**Figure 18.4:** The bands are x times the unpolarized parton distributions f(x) (where  $f = u_v, d_v, \overline{u}, \overline{d}, s \simeq \overline{s}, c = \overline{c}, b = \overline{b}, g$ ) obtained in the NNLO MSHT20 global analysis [63] (top) at scales  $\mu^2 = 10 \text{ GeV}^2$  (left) and  $\mu^2 = 10^4 \text{ GeV}^2$  (right), with  $\alpha_s(M_Z^2) = 0.118$ . The polarized parton distributions f(x) obtained in the NLO NNPDFpol1.1 fit [92] (bottom).

Comprehensive sets of PDFs are available from the LHAPDF library [118], which can be linked directly into a user's programme to provide access to recent PDFs in a standard format. This also includes many nuclear and polarized PDFs.

Nuclear PDFs: The study of the parton distributions for nucleons within nuclei, so-called nuclear parton distribution functions (nPDFs), is now reaching a level of maturity and sophistication similar to nucleon PDFs (and some nuclear target data is often included in determinations of nucleon PDFs), though they are still typically performed at NLO in perturbative QCD. The PDFs are also a function of the nucleon number of the nucleus, A. The nPDFs are obtained via fits to deep inelastic scattering data and dilepton (Drell-Yan) and pion production from proton-nucleus, and most recently also from jet and heavy flavour production data. There are a number of recent examples of NLO analyses, TUJU21 [119], nCTEQ15HQ(HiX) [120, 121], EPPS21 [122],nNNPDF3.0 [123], while NNLO analyses with a smaller selection of data types now also exist [119,124,125]. A comparison of the nuclear modification factors for nCTEQ15HQ [120], EPPS21 [122] and nNNPDF3.0 [123] is shown in Fig. 18.5 where, for example, for the up quark  $R_u^{\rm Pb} = (Z_{Pb}u_{Pb} + (A_{Pb} - Z_{Pb})d_{Pb})/(Z_{Pb}u_p + (A_{Pb} - Z_{Pb})d_p)$  i.e. it involves "physical" nuclear PDFs and is normalised such that  $R_u^{\rm Pb} = 1$  corresponds to no nuclear effects.

<span id="page-13-0"></span>![](_page_13_Figure_3.jpeg)

**Figure 18.5:** Comparison of the nNNPDF3.0, nCTEQ15HQ and EPPS21 nuclear PDFs. The curves shown are ratios to the result in the limit of no nuclear corrections. Plot from NNPDF collaboration (Juan Rojo – private communication).

Much of the heavy-nucleus data included are in the form of ratios to proton or deuteron measurements. Initially most nuclear PDFs were related to a particular proton PDF via a nuclear modification factor, i.e.

$$f_i^{p/A}(x,Q^2) = R_i^A(x,Q^2) f_i^p(x,Q^2).$$
(18.30)

However, it is now common to parameterise the nuclear PDFs directly but so that they become equal to proton PDFs in the limit A=1, and this approch has been adopted in [119–121, 123]. There is some variation in whether charged current neutrino DIS data is used as well as neutral current DIS data since there is no clear compatibility in the modification factors obtained [126,127]. Recently, LHC data from vector boson production [128–131] in proton-lead collisions has been used along with DIS data in most fits, though the most recent data [132] shows some tendency to require NNLO corrections. LHC jet data [133] has been included in some fits [122,123] giving extra constraint on the gluon within nuclei. Further information at smaller x values is also obtained from heavy meson production at LHCb [134]. Single inclusive hadron production e.g. [135, 136], is already sometimes used. All the PDF extractions above are based on the Hessian formulation,

except for the NNPDF studies which use Monte Carlo replicas. Agreement between the different nuclear PDFs is generally good, though uncertainty is still large compared to proton PDFs. As well as improved constraints from further LHC data, nPDFs would be very significantly improved by data from a potential high-energy Electron-Ion Collider [\[137–](#page-24-12)[139\]](#page-24-13).

**Double Parton Distributions** Double parton scattering (DPS) occurs when two pairs of partons initiate two distinct hard scattering processes in a single collision. It becomes more prevalent at higher collider energies as the parton flux increases. Hence, it is becoming relevant at the LHC, and even moreso for planning of higher energy colliders. It has a long theoretical history [\[140–](#page-24-14)[144\]](#page-24-15), and in recent years experimental studies have started. DPS is often supressed, but this is less the case in certain kinematic regions, e.g. when the total transverse momentum of the two hard-scattering processes is small [\[145](#page-24-16)[–148\]](#page-24-17), when they have a large rapidity separation [\[149,](#page-24-18) [150\]](#page-24-19), or when single particle production is supressed by coupling constants, e.g. like-sign *W* production [\[151\]](#page-24-20). There have been results with some evidence for DPS found from both the Tevatron [\[152,](#page-24-21) [153\]](#page-24-22) involving final states with multijets and photons, and at the LHC [\[154–](#page-24-23)[156\]](#page-24-24) in states with multiple vector bosons or mesons. Recent developments have been involved in putting the theoretical foundations of DPS on a much more rigorous footing and describing it in terms of well-defined double partons distributions (DPDs) which extend the concept of parton distribution functions (PDFs) to the case of two partons [\[145–](#page-24-16)[148,](#page-24-17) [157–](#page-24-25)[159\]](#page-25-0). The current knowledge of DPDs is still limited, though there are a number of attempts to impose theoretical constrains as a limit on the forms [\[160–](#page-25-1)[162\]](#page-25-2). The DPDs can be calculated quite accurately when the tranverse separtion of the two partons is small, since in this limit the observed partons are produced by a splitting from a single parton. This limit is complicated by potential double counting [\[148\]](#page-24-17), and an approach to deal with this has been devised [\[159\]](#page-25-0). The full splitting functions for DPS have been calculated at LO [\[148\]](#page-24-17), and there is progress at NLO, e.g. [\[163\]](#page-25-3).

**Polarized PDFs:** For spin-dependent structure functions, data exists for a more restricted range of *Q*<sup>2</sup> and has lower precision, so that the scaling violations are not seen so clearly. However, spin-dependent (or polarized) parton distributions have been extracted by comparison to data using NLO global analyses which include measurements of the *g*<sup>1</sup> structure function in inclusive polarized DIS, 'flavour-tagged' semi-inclusive DIS data, open–charm production in DIS and results from polarized *pp* scattering at RHIC. There are recent results on DIS from JLAB [\[164\]](#page-25-4) (for *g n* 1 */F <sup>n</sup>* 1 ), COMPASS [\[165,](#page-25-5)[166\]](#page-25-6) and CLAS [\[167\]](#page-25-7). NLO analyses are given in Refs. [\[168–](#page-25-8)[171\]](#page-25-9) and more recent extractions [\[172,](#page-25-10)[173\]](#page-25-11). Improved parton-to-hadron fragmentation functions, needed to describe the semi-inclusive DIS (SIDIS) data, can be found in Refs. [\[174–](#page-25-12)[177\]](#page-25-13). The DSSV collaboration includes in their NLO analysis to extract polarized PDFs all the world data, inclusive and semi-inclusive DIS, double spin asymmetries in jet [\[179\]](#page-25-14), dijet [\[180\]](#page-25-15) and inclusive *π* 0 -production [\[181\]](#page-25-16), but not yet the single spin asymmetries in *W*±*, Z*<sup>0</sup> production [\[182,](#page-25-17) [183\]](#page-25-18). A determination [\[184\]](#page-25-19), using the NNPDF methodology, concentrates just on the inclusive polarized DIS data, and finds the uncertainties on the polarized gluon PDF have been underestimated in the earlier analyses. An update to this [\[92\]](#page-23-6), where jet and *W*<sup>±</sup> data from *pp* collisions and open–charm DIS data have been included via reweighting, reduces the uncertainty and suggests a positive polarized gluon PDF. The evidence for a positive gluon polarization is strengthened by the most recent jet [\[185–](#page-25-20)[187\]](#page-25-21) and inclusive *π* 0 [\[188\]](#page-25-22) data. The DSSV group has recently implemented a Monte Carlo sampling strategy to extract helicity parton densities and their uncertainties from a reference set of longitudinally polarized scattering data [\[178\]](#page-25-23). A simultaneous extraction of spin-dependent parton distributions and fragmentation functions has recently also been performed [\[189\]](#page-25-24). Calculations of polarised

<span id="page-15-0"></span>![](_page_15_Figure_2.jpeg)

**Figure 18.6:** Ensemble of replicas (dotted blue lines) for the NLO gluon helicity density *∆g*(*x, Q*<sup>2</sup> ) at *Q*<sup>2</sup> = 10 GeV<sup>2</sup> shown along with its statistical average (solid blue line) and variance (dot-dashed blue lines). The corresponding results from the DSSV14 fit (black lines) [\[172\]](#page-25-10) and the NNPDFpol1.1 analysis (green lines) [\[92\]](#page-23-6) are shown for comparison. Figure taken from Ref. [\[178\]](#page-25-23).

PDFs on the lattice are frequently produced by the same studies as for unpolarised PDFs. These are usually in better agreement with the corresponding moments obtained from global fits, than the unpolarised PDFs, and also tend to have much more competitive uncertainties, see [\[106,](#page-23-18) [107\]](#page-23-19) for a review and e.g. [\[109,](#page-23-31) [190\]](#page-25-25) for more recent results.

A comparison of the polarized gluon PDFs obtained in the NLO analyses of NNPDF [\[92\]](#page-23-6) and DSSV [\[178\]](#page-25-23) is shown in Fig. [18.6](#page-15-0) at scale *µ* <sup>2</sup> = 10 GeV<sup>2</sup> . The world data of the inclusive structure function *g*<sup>1</sup> for proton and deuterium included in these analysis are shown in Fig. [18.16](#page-34-0) and Fig. [18.17.](#page-35-0)

## **18.4 The hadronic structure of the photon**

Besides the *direct* interactions of the photon, it is possible for it to fluctuate into a hadronic state via the process *γ* → *qq*. While in this state, the partonic content of the photon may be *resolved*, for example, through the process *e* +*e* <sup>−</sup> → *e* +*e* <sup>−</sup>*γ ?γ* → *e* +*e* <sup>−</sup>*X*, where the virtual photon emitted by the DIS lepton probes the hadronic structure of the quasi-real photon emitted by the other lepton. The perturbative LO QED contributions to this process with *γ* → *qq* in conjunction with *γ ? q*(¯*q*) → *q*(¯*q*), are subject to QCD corrections due to the radiation of gluons from these quarks.

Often the equivalent-photon approximation is used to express the differential cross section for deep inelastic electron–photon scattering in terms of the structure functions of the transverse quasireal photon times a flux factor  $N_{\gamma}^{T}$  (for these incoming quasi-real photons of transverse polarization)

$$\frac{d^2\sigma}{dxdQ^2} = N_{\gamma}^T \frac{2\pi\alpha^2}{xQ^4} \left[ \left( 1 + (1-y)^2 \right) F_2^{\gamma}(x, Q^2) - y^2 F_L^{\gamma}(x, Q^2) \right], \tag{18.31}$$

where we have used  $F_2^{\gamma} = 2xF_T^{\gamma} + F_L^{\gamma}$  (where  $F_T$  is the transverse structure function), not to be confused with  $F_2^{\gamma}$  of Sec. 18.2. Complete formulae are given, for example, in the comprehensive review of [191].

The hadronic photon structure function,  $F_2^{\gamma}$ , evolves with increasing  $Q^2$  from the 'hadron-like' behavior, calculable via the vector-meson-dominance model, to the dominating 'point-like' behaviour, calculable in perturbative QCD. Due to the point-like coupling, the logarithmic evolution of  $F_2^{\gamma}$  with  $Q^2$  has a positive slope for all values of x, see Fig. 18.18. The 'loss' of quarks at large x due to gluon radiation is over-compensated by the 'creation' of quarks via the point-like  $\gamma \to q\bar{q}$  coupling. The logarithmic evolution was first predicted in the quark–parton model  $(\gamma^*\gamma \to q\bar{q})$  [192,193], and then an improved expression was obtained using QCD corrections in the limit of large  $Q^2$  [194]. The evolution is now known to NLO [195–197]. The NLO data analyses to determine the parton densities of the photon can be found in Refs. [198–200].

## 18.5 Diffractive DIS (DDIS)

Some 10% of DIS events are diffractive,  $\gamma^*p \to X + p$ , in which the slightly deflected proton and the cluster X of outgoing hadrons are well-separated in rapidity [201]. Besides x and  $Q^2$ , two extra variables are needed to describe a DDIS event: the fraction  $x_{I\!P}$  of the proton's momentum transferred across the rapidity gap and t, the square of the 4-momentum transfer of the proton. The DDIS data [206,207] are usually analysed using two levels of factorization. First, the diffractive structure function  $F_2^{\rm D}$  satisfies collinear factorization, and can be expressed as the convolution [208]

$$F_2^{\rm D} = \sum_{a=a,a} C_2^a \otimes f_{a/p}^{\rm D},$$
 (18.32)

with the same coefficient functions as in DIS (see Eq. (18.21)), and where the diffractive parton distributions  $f_{a/p}^{D}$  (a = q, g) satisfy DGLAP evolution. Second, Regge factorization is assumed [209],

<span id="page-16-0"></span>
$$f_{a/p}^{\rm D}(x_{I\!P}, t, z, \mu^2) = f_{I\!P/p}(x_{I\!P}, t) f_{a/I\!P}(z, \mu^2),$$
 (18.33)

where  $f_{a/\!I\!\!P}$  are the parton densities of the Pomeron, which itself is treated like a hadron, and  $z \in [x/x_{I\!\!P}, 1]$  is the fraction of the Pomeron's momentum carried by the parton entering the hard subprocess. The Pomeron flux factor  $f_{I\!\!P/p}(x_{I\!\!P}, t)$  is taken from Regge phenomenology. There are also secondary Reggeon contributions to Eq. (18.33). A sample of the t-integrated diffractive parton densities, obtained in this way, is shown in Fig. 18.7. A more recent extraction of the parton densities may be found in [210].

Although collinear factorization holds as  $\mu^2 \to \infty$ , there are non-negligible corrections for finite  $\mu^2$  and small  $x_{I\!\!P}$ . Besides the resolved interactions of the Pomeron, the perturbative QCD Pomeron may also interact directly with the hard subprocess, giving rise to an inhomogeneous evolution equation for the diffractive parton densities analogous to the photon case. The results of the MRW analysis [204], which includes these contributions, are also shown in Fig. 18.7.

Unlike the inclusive case, the diffractive parton densities cannot be directly used to calculate diffractive hadron-hadron cross sections, since account must first be taken of "soft" rescattering effects.

<span id="page-17-0"></span>![](_page_17_Figure_2.jpeg)

**Figure 18.7:** Diffractive parton distributions, *xIP zf* <sup>D</sup> *a/p*, obtained from fitting to the ZEUS data with *Q*<sup>2</sup> *>* 5 GeV<sup>2</sup> [\[202\]](#page-26-12),H1 data with *Q*<sup>2</sup> *>* 8*.*5 GeV<sup>2</sup> assuming Regge factorization [\[203\]](#page-26-13), and from MRW2006 [\[204\]](#page-26-11) using a more perturbative QCD approach [\[204\]](#page-26-11). Only the Pomeron contributions are shown and not the secondary Reggeon contributions, which are negligible at the value of *xIP* = 0*.*003 chosen here. The H1 2007 Jets distribution [\[205\]](#page-26-14) is similar to H1 2006 Fit B.

# **18.6 Three-dimensional structure of hadrons**

Generalized parton distributions (GPDs) and their compliment, transverse momentum dependent distributions (TMDs) describe the three-dimensional structure of hadrons. While GPDs encode the transverse position of a parton in a nucleon, TMDs, encompassing both the parton distributions (TMD PDF) and fragmentation functions (TMD FF), encode their transverse momenta and lead to observable transverse momenta in the final state. Both TMDs and GPDs derive, via integration over the appropriate variable, from Wigner distributions [\[211–](#page-26-15)[213\]](#page-26-16) that depend on the average transverse momentum and position of partons.

### **18.6.1** *Generalized parton distributions*

The parton distributions of the proton of Sec. [18.3](#page-8-0) are given by the diagonal matrix elements h*P, λ*|*O*ˆ|*P, λ*i, where *P* and *λ* are the 4-momentum and helicity of the proton, and *O*ˆ is a twist-2 quark or gluon operator. However, there is new information in the so-called generalised parton distributions (GPDs) defined in terms of the off-diagonal matrix elements h*P* 0 *, λ*<sup>0</sup> |*O*ˆ|*P, λ*i; see Refs. [\[214](#page-26-17)[–219\]](#page-26-18) for reviews. Unlike the diagonal PDFs, the GPDs cannot be regarded as parton densities, but are to be interpreted as probability amplitudes.

The physical significance of GPDs is best seen using light-cone coordinates, *z* <sup>±</sup> = (*z* <sup>0</sup> ±*z* 3 )*/* √ 2, and in the light-cone gauge, *A*<sup>+</sup> = 0. It is conventional to define the generalised quark distributions

<span id="page-18-1"></span>![](_page_18_Figure_2.jpeg)

Figure 18.8: Schematic diagrams of the three distinct kinematic regions of the imaginary part of  $H_q$ . The proton and quark momentum fractions refer to  $\bar{P}^+$ , and x covers the interval (-1,1). In the ERBL domain the GPDs are generalisations of distribution amplitudes which occur in processes such as  $p\bar{p} \to J/\psi$ .

in terms of quark operators at light-like separation

<span id="page-18-0"></span>
$$F_{q}(x,\xi,t) = \frac{1}{2} \int \frac{dz^{-}}{2\pi} e^{ix\bar{P}^{+}z^{-}} \langle P' | \bar{\psi}(-z/2) \gamma^{+} \psi(z/2) | P \rangle \bigg|_{z^{+}=z^{1}=z^{2}=0}$$

$$= \frac{1}{2\bar{P}^{+}} \left( H_{q}(x,\xi,t) \ \bar{u}(P') \gamma^{+} u(P) + E_{q}(x,\xi,t) \ \bar{u}(P') \frac{i\sigma^{+\alpha} \Delta_{\alpha}}{2m} u(P) \right)$$
(18.34)

with  $\bar{P} = (P + P')/2$  and  $\Delta = P' - P$ , and where we have suppressed the helicity labels of the protons and spinors. We now have two extra kinematic variables:

$$t = \Delta^2, \qquad \xi = -\Delta^+/(P + P')^+.$$
 (18.35)

We see that  $-1 \le \xi \le 1$ . Similarly, we may define GPDs  $\tilde{H}_q$  and  $\tilde{E}_q$  with an additional  $\gamma_5$  between the quark operators in Eq. (18.34); and also an analogous set of gluon GPDs,  $H_g$ ,  $E_g$ ,  $\tilde{H}_g$  and  $\tilde{E}_g$ . After a Fourier transform with respect to the transverse components of  $\Delta$ , we are able to describe the spatial distribution of partons in the impact parameter plane in terms of GPDs [220, 221].

For P' = P,  $\lambda' = \lambda$  the matrix elements reduce to the ordinary PDFs of Sec. 18.2.1

$$H_q(x,0,0) = q(x), \quad H_q(-x,0,0) = -\bar{q}(x), \quad H_g(x,0,0) = xg(x),$$
 (18.36)

$$\tilde{H}_q(x,0,0) = \Delta q(x), \ \tilde{H}_q(-x,0,0) = \Delta \bar{q}(x), \ \tilde{H}_g(x,0,0) = x\Delta g(x),$$
 (18.37)

where  $\Delta q = q \uparrow - q \downarrow$  as in Eq. (18.18). No corresponding relations exist for E,  $\tilde{E}$  as they decouple in the forward limit,  $\Delta = 0$ .

The functions  $H_g$ ,  $E_g$  are even in x, and  $\tilde{H}_g$ ,  $\tilde{E}_g$  are odd functions of x. We can introduce valence and 'singlet' quark distributions which are even and odd functions of x respectively. For example

$$H_q^V(x,\xi,t) \equiv H_q(x,\xi,t) + H_q(-x,\xi,t) = H_q^V(-x,\xi,t),$$
 (18.38)

$$H_q^S(x,\xi,t) \equiv H_q(x,\xi,t) - H_q(-x,\xi,t) = -H_q^S(-x,\xi,t).$$
 (18.39)

All the GPDs satisfy relations of the form

$$H(x, -\xi, t) = H(x, \xi, t)$$
 and  $H(x, -\xi, t)^* = H(x, \xi, t),$  (18.40)

and so are real-valued functions. Moreover, the moments of GPDs, that is the x integrals of  $x^n H_q$  etc., are polynomials in  $\xi$  of order n+1. Another important property of GPDs are Ji's sum rule [214]

$$\frac{1}{2} \int_{-1}^{1} dx \ x \left( H_q(x, \xi, t) + E_q(x, \xi, t) \right) = J_q(t), \tag{18.41}$$

where  $J_q(0)$  is the total angular momentum carried by quarks and antiquarks of flavour q, with a similar relation for gluons.

To visualize the physical content of  $H_q$ , we Fourier expand  $\psi$  and  $\bar{\psi}$  in terms of quark, antiquark creation (b,d) and annihilation  $(b^{\dagger},d^{\dagger})$  operators, and sketch the result in Fig. 18.8. There are two types of domain: (i) the time-like or 'annihilation' domain, with  $|x| < |\xi|$ , where the GPDs describe the wave functions of a t-channel  $q\bar{q}$  (or gluon) pair and evolve according to modified ERBL equations [222, 223]; (ii) the space-like or 'scattering' domain, with  $|x| > |\xi|$ , where the GPDs generalise the familiar  $\bar{q}$ , q (and gluon) PDFs and describe processes such as 'deeply virtual Compton scattering'  $(\gamma^* p \to \gamma p)$ ,  $\gamma p \to J/\psi p$ , etc., and evolve according to modified DGLAP equations. The splitting functions for the evolution of GPDs are known to NLO [224–226].

GPDs describe new aspects of proton structure and must be determined from experiment. We can parametrise them in terms of 'double distributions' [227,228], which reduce to diagonal PDFs as  $\xi \to 0$ . Alternatively, flexible SO(3)-based parametrisations have been used to determine GPDs from DVCS data [229,230]; a more recent summary may be found in Ref. [231,232].

#### 18.6.2 Transverse momentum dependent distributions

For a proton, there are eight independent transverse dependent distribution (TMD) PDFs, at leading twist, three of which correspond to the usual unpolarized, longitudinally polarized and transversely polarized quark parton distributions [233, 234]. The novel TMD PDFs have physical interpretations. For example, the Sivers function [235] represents the distribution of unpolarized

<span id="page-19-0"></span>![](_page_19_Figure_9.jpeg)

Figure 18.9: (Left) Sivers function in the momentum space for u quark [236] at x = 0.1 as a function of transverse momentum  $k_T$  for different values of Q. The bands are 68%CI. (Right) Momentum space density function as defined in [236] for the unpolarized u quark in a proton totally polarized in the y direction. The white cross indicates the origin with respect to which a shift of the distribution along the x-direction due to the Sivers function can be seen. The width of the patterns in the plot roughly indicates the uncertainty of the extraction.

partons inside a transversely polarized hadron. For (pseudo)scalar particles, such as kaon and pions, there are two independent leading-twist TMD FFs, one being the ordinary unpolarized fragmentation function and the other the Collins FF [\[237\]](#page-27-9) which is related to the probability of a polarized quark fragmenting into an unpolarized hadron.

Factorization of TMDs has been shown for semi-inclusive DIS, for the Drell-Yan process as well as for electron-position annihilation into dihadrons [\[238–](#page-27-10)[243\]](#page-27-11). Recently first TMD global fits have become available [\[244–](#page-27-12)[252\]](#page-27-13), although potential problems with consistent descriptions are highlighted in remain [\[253–](#page-27-14)[255\]](#page-27-15). The results of a recent extraction of Sivers function from a global fit to polarized Semi-Inclusive DIS, polarized pion-induced Drell-Yan and W+-/Z boson production data is shown in Fig. [18.9](#page-19-0) [\[236\]](#page-27-8).

Because TMD PDFs encode nonperturbative information about transverse momentum and polarization degrees of freedom, they are important for descriptions of multi-scale, non-inclusive collider observables, for example, production of electroweak gauge bosons at LHC [\[256\]](#page-27-16) and can have an effect on determination of the *W* boson mass [\[257\]](#page-27-17). The combination of TMD PDFs and FFs can give consistent global description of spin and azimuthal asymmetries and provide predictions. Some recent reviews of this rapidly developing field are given here [\[256,](#page-27-16) [258–](#page-27-18)[261\]](#page-27-19).

# <span id="page-20-0"></span>*References*

- [1] J. Blumlein and N. Kochelev, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(97)00234-4) **[B498](http://doi.org/10.1016/S0550-3213(97)00234-4)**, 285 (1997), [\[hep-ph/9612318\].](https://arxiv.org/abs/hep-ph/9612318)
- <span id="page-20-3"></span>[2] S. Forte, M. L. Mangano and G. Ridolfi, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(01)00101-8) **[B602](http://doi.org/10.1016/S0550-3213(01)00101-8)**, 585 (2001), [\[hep-ph/0101192\].](https://arxiv.org/abs/hep-ph/0101192)
- <span id="page-20-2"></span><span id="page-20-1"></span>[3] M. Anselmino, P. Gambino and J. Kalinowski, [Z. Phys.](http://doi.org/10.1007/BF01557397) **C64**[, 267](http://doi.org/10.1007/BF01557397) (1994), [\[hep-ph/9401264\].](https://arxiv.org/abs/hep-ph/9401264)
- [4] M. Anselmino, A. Efremov and E. Leader, [Phys. Rept.](http://doi.org/10.1016/0370-1573(95)00011-5) **[261](http://doi.org/10.1016/0370-1573(95)00011-5)**, 1 (1995), [Erratum: Phys. Rept.281,399(1997)], [\[hep-ph/9501369\].](https://arxiv.org/abs/hep-ph/9501369)
- <span id="page-20-4"></span>[5] M. Klein and T. Riemann, [Z. Phys.](http://doi.org/10.1007/BF01571719) **C24**[, 151](http://doi.org/10.1007/BF01571719) (1984).
- <span id="page-20-5"></span>[6] C. G. Callan, Jr. and D. J. Gross, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.22.156) **22**[, 156](http://doi.org/10.1103/PhysRevLett.22.156) (1969).
- <span id="page-20-6"></span>[7] D. A. Dicus, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.5.1367) **D5**[, 1367](http://doi.org/10.1103/PhysRevD.5.1367) (1972).
- <span id="page-20-7"></span>[8] J. D. Bjorken and E. A. Paschos, [Phys. Rev.](http://doi.org/10.1103/PhysRev.185.1975) **185**[, 1975](http://doi.org/10.1103/PhysRev.185.1975) (1969).
- <span id="page-20-8"></span>[9] R.P. Feynman, Photon Hadron Interactions (Benjamin, New York, 1972).
- <span id="page-20-9"></span>[10] J. D. Bjorken, [Phys. Rev.](http://doi.org/10.1103/PhysRev.179.1547) **179**[, 1547](http://doi.org/10.1103/PhysRev.179.1547) (1969).
- <span id="page-20-10"></span>[11] S. Wandzura and F. Wilczek, [Phys. Lett.](http://doi.org/10.1016/0370-2693(77)90700-6) **72B**[, 195](http://doi.org/10.1016/0370-2693(77)90700-6) (1977).
- <span id="page-20-11"></span>[12] J. Blumlein and A. Tkabladze, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(99)00289-8) **[B553](http://doi.org/10.1016/S0550-3213(99)00289-8)**, 427 (1999), [\[hep-ph/9812478\].](https://arxiv.org/abs/hep-ph/9812478)
- <span id="page-20-12"></span>[13] A.M. Cooper-Sarkar, private communication.
- <span id="page-20-13"></span>[14] H. Abramowicz *et al.* (H1, ZEUS), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-015-3710-4) **C75**[, 12, 580](http://doi.org/10.1140/epjc/s10052-015-3710-4) (2015), [\[arXiv:1506.06042\].](https://arxiv.org/abs/1506.06042)
- <span id="page-20-14"></span>[15] L. A. Harland-Lang *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-016-4020-1) **C76**[, 4, 186](http://doi.org/10.1140/epjc/s10052-016-4020-1) (2016), [\[arXiv:1601.03413\].](https://arxiv.org/abs/1601.03413)
- <span id="page-20-15"></span>[16] I. Abt *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.94.034032) **D94**[, 3, 034032](http://doi.org/10.1103/PhysRevD.94.034032) (2016), [\[arXiv:1604.02299\].](https://arxiv.org/abs/1604.02299)
- <span id="page-20-16"></span>[17] R. D. Ball *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-5774-4) **C78**[, 4, 321](http://doi.org/10.1140/epjc/s10052-018-5774-4) (2018), [\[arXiv:1710.05935\].](https://arxiv.org/abs/1710.05935)
- <span id="page-20-17"></span>[18] H. Abdolmaleki *et al.* (xFitter Developers' Team), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-6090-8) **C78**[, 8, 621](http://doi.org/10.1140/epjc/s10052-018-6090-8) (2018), [\[arXiv:1802.00064\].](https://arxiv.org/abs/1802.00064)
- <span id="page-20-18"></span>[19] J. C. Collins, D. E. Soper and G. F. Sterman, [Adv. Ser. Direct. High Energy Phys.](http://doi.org/10.1142/9789814503266_0001) **5**[, 1](http://doi.org/10.1142/9789814503266_0001) (1989), [\[hep-ph/0409313\].](https://arxiv.org/abs/hep-ph/0409313)
- <span id="page-20-19"></span>[20] V. N. Gribov and L. N. Lipatov, Sov. J. Nucl. Phys. **15**, 438 (1972), [Yad. Fiz.15,781(1972)].
- [21] L.N. Lipatov, Sov. J. Nucl. Phys. **20**, 95 (1975).
- <span id="page-20-21"></span>[22] G. Altarelli and G. Parisi, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(77)90384-4) **[B126](http://doi.org/10.1016/0550-3213(77)90384-4)**, 298 (1977).
- <span id="page-20-20"></span>[23] Y. L. Dokshitzer, Sov. Phys. JETP **46**, 641 (1977), [Zh. Eksp. Teor. Fiz.73,1216(1977)].

- <span id="page-21-0"></span>[24] G. Curci, W. Furmanski and R. Petronzio, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(80)90003-6) **[B175](http://doi.org/10.1016/0550-3213(80)90003-6)**, 27 (1980); W. Furmanski and R. Petronzio, [Phys. Lett.](http://doi.org/10.1016/0370-2693(80)90636-X) **97B**[, 437](http://doi.org/10.1016/0370-2693(80)90636-X) (1980).
- <span id="page-21-1"></span>[25] R.K. Ellis *et al.*, QCD and Collider Physics (Cambridge UP, 1996).
- <span id="page-21-2"></span>[26] W. L. van Neerven and E. B. Zijlstra, [Phys. Lett.](http://doi.org/10.1016/0370-2693(91)91024-P) **[B272](http://doi.org/10.1016/0370-2693(91)91024-P)**, 127 (1991); E. B. Zijlstra and W. L. van Neerven, [Phys. Lett.](http://doi.org/10.1016/0370-2693(91)90301-6) **[B273](http://doi.org/10.1016/0370-2693(91)90301-6)**, 476 (1991); E. B. Zijlstra and W. L. van Neerven, [Phys.](http://doi.org/10.1016/0370-2693(92)91277-G) [Lett.](http://doi.org/10.1016/0370-2693(92)91277-G) **[B297](http://doi.org/10.1016/0370-2693(92)91277-G)**, 377 (1992); E. B. Zijlstra and W. L. van Neerven, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(92)90087-R) **[B383](http://doi.org/10.1016/0550-3213(92)90087-R)**, 525 (1992).
- [27] S. Moch and J. A. M. Vermaseren, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(00)00045-6) **[B573](http://doi.org/10.1016/S0550-3213(00)00045-6)**, 853 (2000), [\[hep-ph/9912355\].](https://arxiv.org/abs/hep-ph/9912355)
- <span id="page-21-3"></span>[28] S. Moch, J. A. M. Vermaseren and A. Vogt, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2004.03.030) **[B688](http://doi.org/10.1016/j.nuclphysb.2004.03.030)**, 101 (2004), [\[hep-ph/0403192\];](https://arxiv.org/abs/hep-ph/0403192) A. Vogt, S. Moch and J. A. M. Vermaseren, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2004.04.024) **[B691](http://doi.org/10.1016/j.nuclphysb.2004.04.024)**, 129 (2004), [\[hep-ph/0404111\];](https://arxiv.org/abs/hep-ph/0404111) S. Moch, J. A. M. Vermaseren and A. Vogt, [Phys. Lett.](http://doi.org/10.1016/j.physletb.2004.11.063) **[B606](http://doi.org/10.1016/j.physletb.2004.11.063)**, 123 (2005), [\[hep-ph/0411112\].](https://arxiv.org/abs/hep-ph/0411112)
- <span id="page-21-4"></span>[29] J. A. M. Vermaseren, A. Vogt and S. Moch, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2005.06.020) **[B724](http://doi.org/10.1016/j.nuclphysb.2005.06.020)**, 3 (2005), [\[hep-ph/0504242\].](https://arxiv.org/abs/hep-ph/0504242)
- <span id="page-21-5"></span>[30] S. Moch *et al.*, [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2021.136853) **825**[, 136853](http://doi.org/10.1016/j.physletb.2021.136853) (2022), [\[arXiv:2111.15561\];](https://arxiv.org/abs/2111.15561) G. Falcioni *et al.*, [Phys.](http://doi.org/10.1016/j.physletb.2023.137944) [Lett. B](http://doi.org/10.1016/j.physletb.2023.137944) **842**[, 137944](http://doi.org/10.1016/j.physletb.2023.137944) (2023), [\[arXiv:2302.07593\].](https://arxiv.org/abs/2302.07593)
- <span id="page-21-6"></span>[31] V. S. Fadin, E. A. Kuraev and L. N. Lipatov, [Phys. Lett.](http://doi.org/10.1016/0370-2693(75)90524-9) **[60B](http://doi.org/10.1016/0370-2693(75)90524-9)**, 50 (1975); E. A. Kuraev, L. N. Lipatov and V. S. Fadin, Sov. Phys. JETP **44**, 443 (1976), [Zh. Eksp. Teor. Fiz.71,840(1976)]; E. A. Kuraev, L. N. Lipatov and V. S. Fadin, Sov. Phys. JETP **45**, 199 (1977), [Zh. Eksp. Teor. Fiz.72,377(1977)].
- <span id="page-21-7"></span>[32] I. I. Balitsky and L. N. Lipatov, Sov. J. Nucl. Phys. **28**, 822 (1978), [Yad. Fiz.28,1597(1978)].
- <span id="page-21-8"></span>[33] V. S. Fadin and L. N. Lipatov, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(98)00473-0) **[B429](http://doi.org/10.1016/S0370-2693(98)00473-0)**, 127 (1998), [\[hep-ph/9802290\].](https://arxiv.org/abs/hep-ph/9802290)
- <span id="page-21-9"></span>[34] G. Camici and M. Ciafaloni, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(97)01387-7) **B412**[, 396](http://doi.org/10.1016/S0370-2693(97)01387-7) (1997), [Erratum: Phys. Lett.B417,390(1998)], [\[hep-ph/9707390\];](https://arxiv.org/abs/hep-ph/9707390) M. Ciafaloni and G. Camici, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(98)00551-6) **[B430](http://doi.org/10.1016/S0370-2693(98)00551-6)**, [349](http://doi.org/10.1016/S0370-2693(98)00551-6) (1998), [\[hep-ph/9803389\].](https://arxiv.org/abs/hep-ph/9803389)
- <span id="page-21-10"></span>[35] M. Ciafaloni, D. Colferai and G. P. Salam, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.60.114036) **D60**[, 114036](http://doi.org/10.1103/PhysRevD.60.114036) (1999), [\[hep-ph/9905566\];](https://arxiv.org/abs/hep-ph/9905566) M. Ciafaloni, D. Colferai and G. P. Salam, [JHEP](http://doi.org/10.1088/1126-6708/2000/07/054) **07**[, 054](http://doi.org/10.1088/1126-6708/2000/07/054) (2000), [\[hep-ph/0007240\].](https://arxiv.org/abs/hep-ph/0007240)
- [36] M. Ciafaloni *et al.*, [Phys. Lett.](http://doi.org/10.1016/j.physletb.2003.09.078) **[B576](http://doi.org/10.1016/j.physletb.2003.09.078)**, 143 (2003), [\[hep-ph/0305254\];](https://arxiv.org/abs/hep-ph/0305254) M. Ciafaloni *et al.*, [Phys.](http://doi.org/10.1103/PhysRevD.68.114003) [Rev.](http://doi.org/10.1103/PhysRevD.68.114003) **D68**[, 114003](http://doi.org/10.1103/PhysRevD.68.114003) (2003), [\[hep-ph/0307188\].](https://arxiv.org/abs/hep-ph/0307188)
- [37] G. Altarelli, R. D. Ball and S. Forte, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2006.01.046) **[B742](http://doi.org/10.1016/j.nuclphysb.2006.01.046)**, 1 (2006), [\[hep-ph/0512237\];](https://arxiv.org/abs/hep-ph/0512237) G. Altarelli, R. D. Ball and S. Forte, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2008.03.003) **[B799](http://doi.org/10.1016/j.nuclphysb.2008.03.003)**, 199 (2008), [\[arXiv:0802.0032\].](https://arxiv.org/abs/0802.0032)
- <span id="page-21-11"></span>[38] C. D. White and R. S. Thorne, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.75.034005) **D75**[, 034005](http://doi.org/10.1103/PhysRevD.75.034005) (2007), [\[hep-ph/0611204\].](https://arxiv.org/abs/hep-ph/0611204)
- <span id="page-21-12"></span>[39] M. Bonvini, S. Marzani and T. Peraro, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-016-4445-6) **C76**[, 11, 597](http://doi.org/10.1140/epjc/s10052-016-4445-6) (2016), [\[arXiv:1607.02153\].](https://arxiv.org/abs/1607.02153)
- <span id="page-21-13"></span>[40] M. Bonvini, S. Marzani and C. Muselli, [JHEP](http://doi.org/10.1007/JHEP12(2017)117) **12**[, 117](http://doi.org/10.1007/JHEP12(2017)117) (2017), [\[arXiv:1708.07510\].](https://arxiv.org/abs/1708.07510)
- <span id="page-21-14"></span>[41] Y. V. Kovchegov and E. Levin, *Quantum chromodynamics at high energy*, volume 33, Cambridge University Press (2012), ISBN 978-0-521-11257-4, 978-1-139-55768-9.
- [42] J. L. Albacete and C. Marquet, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2014.01.004) **[76](http://doi.org/10.1016/j.ppnp.2014.01.004)**, 1 (2014), [\[arXiv:1401.4866\].](https://arxiv.org/abs/1401.4866)
- <span id="page-21-15"></span>[43] A. Morreale and F. Salazar, [Universe](http://doi.org/10.3390/universe7080312) **7**[, 8, 312](http://doi.org/10.3390/universe7080312) (2021), [\[arXiv:2108.08254\].](https://arxiv.org/abs/2108.08254)
- <span id="page-21-16"></span>[44] G. Giacalone and C. Marquet, [Nucl. Phys. A](http://doi.org/10.1016/j.nuclphysa.2018.10.009) **982**[, 291](http://doi.org/10.1016/j.nuclphysa.2018.10.009) (2019), [\[arXiv:1807.06388\].](https://arxiv.org/abs/1807.06388)
- <span id="page-21-17"></span>[45] X. Chu (STAR), in "28th International Workshop on Deep Inelastic Scattering and Related Subjects," (2021), [\[arXiv:2110.03731\].](https://arxiv.org/abs/2110.03731)
- <span id="page-21-18"></span>[46] G. 't Hooft and M. J. G. Veltman, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(72)90279-9) **B44**[, 189](http://doi.org/10.1016/0550-3213(72)90279-9) (1972).
- <span id="page-21-19"></span>[47] G. 't Hooft, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(73)90376-3) **B61**[, 455](http://doi.org/10.1016/0550-3213(73)90376-3) (1973).
- <span id="page-21-20"></span>[48] W. A. Bardeen *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.18.3998) **D18**[, 3998](http://doi.org/10.1103/PhysRevD.18.3998) (1978).
- <span id="page-21-21"></span>[49] G. Altarelli, R. K. Ellis and G. Martinelli, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(78)90085-8) **[B143](http://doi.org/10.1016/0550-3213(78)90085-8)**, 521 (1978), [Erratum: Nucl. Phys.B146,544(1978)].

- <span id="page-22-0"></span>[50] S. Catani, [Z. Phys. C](http://doi.org/10.1007/s002880050104) **70**[, 263](http://doi.org/10.1007/s002880050104) (1996), [\[hep-ph/9506357\].](https://arxiv.org/abs/hep-ph/9506357)
- <span id="page-22-1"></span>[51] A. D. Martin *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s2004-01825-2) **C35**[, 325](http://doi.org/10.1140/epjc/s2004-01825-2) (2004), [\[hep-ph/0308087\].](https://arxiv.org/abs/hep-ph/0308087)
- <span id="page-22-19"></span>[52] R. D. Ball *et al.* (NNPDF), [Phys. Lett.](http://doi.org/10.1016/j.physletb.2013.05.019) **[B723](http://doi.org/10.1016/j.physletb.2013.05.019)**, 330 (2013), [\[arXiv:1303.1189\].](https://arxiv.org/abs/1303.1189)
- <span id="page-22-2"></span>[53] R. S. Thorne, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-014-2958-4) **C74**[, 7, 2958](http://doi.org/10.1140/epjc/s10052-014-2958-4) (2014), [\[arXiv:1402.3536\].](https://arxiv.org/abs/1402.3536)
- <span id="page-22-3"></span>[54] M. Dasgupta and B. R. Webber, [Phys. Lett.](http://doi.org/10.1016/0370-2693(96)00674-0) **[B382](http://doi.org/10.1016/0370-2693(96)00674-0)**, 273 (1996), [\[hep-ph/9604388\].](https://arxiv.org/abs/hep-ph/9604388)
- <span id="page-22-4"></span>[55] A. De Roeck and R. S. Thorne, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2011.06.001) **66**[, 727](http://doi.org/10.1016/j.ppnp.2011.06.001) (2011), [\[arXiv:1103.0555\].](https://arxiv.org/abs/1103.0555)
- [56] S. Forte and G. Watt, [Ann. Rev. Nucl. Part. Sci.](http://doi.org/10.1146/annurev-nucl-102212-170607) **63**[, 291](http://doi.org/10.1146/annurev-nucl-102212-170607) (2013), [\[arXiv:1301.6754\].](https://arxiv.org/abs/1301.6754)
- [57] J. Blumlein, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2012.09.006) **69**[, 28](http://doi.org/10.1016/j.ppnp.2012.09.006) (2013), [\[arXiv:1208.6087\].](https://arxiv.org/abs/1208.6087)
- [58] E. Perez and E. Rizvi, [Rept. Prog. Phys.](http://doi.org/10.1088/0034-4885/76/4/046201) **76**[, 046201](http://doi.org/10.1088/0034-4885/76/4/046201) (2013), [\[arXiv:1208.1178\].](https://arxiv.org/abs/1208.1178)
- [59] R. D. Ball *et al.*, [JHEP](http://doi.org/10.1007/JHEP04(2013)125) **04**[, 125](http://doi.org/10.1007/JHEP04(2013)125) (2013), [\[arXiv:1211.5142\].](https://arxiv.org/abs/1211.5142)
- [60] J. Gao, L. Harland-Lang and J. Rojo, [Phys. Rept.](http://doi.org/10.1016/j.physrep.2018.03.002) **[742](http://doi.org/10.1016/j.physrep.2018.03.002)**, 1 (2018), [\[arXiv:1709.04922\].](https://arxiv.org/abs/1709.04922)
- <span id="page-22-5"></span>[61] J. J. Ethier and E. R. Nocera, [Ann. Rev. Nucl. Part. Sci.](http://doi.org/10.1146/annurev-nucl-011720-042725) **70**[, 43](http://doi.org/10.1146/annurev-nucl-011720-042725) (2020), [\[arXiv:2001.07722\].](https://arxiv.org/abs/2001.07722)
- <span id="page-22-6"></span>[62] J. Rojo *et al.*, [J. Phys.](http://doi.org/10.1088/0954-3899/42/10/103103) **G42**[, 103103](http://doi.org/10.1088/0954-3899/42/10/103103) (2015), [\[arXiv:1507.00556\].](https://arxiv.org/abs/1507.00556)
- <span id="page-22-7"></span>[63] S. Bailey *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-021-09057-0) **81**[, 4, 341](http://doi.org/10.1140/epjc/s10052-021-09057-0) (2021), [\[arXiv:2012.04684\].](https://arxiv.org/abs/2012.04684)
- <span id="page-22-21"></span>[64] V. Bertone, R. Gauld and J. Rojo, [JHEP](http://doi.org/10.1007/JHEP01(2019)217) **01**[, 217](http://doi.org/10.1007/JHEP01(2019)217) (2019), [\[arXiv:1808.02034\].](https://arxiv.org/abs/1808.02034)
- <span id="page-22-22"></span>[65] R. Aaij *et al.* (LHCb), [JHEP](http://doi.org/10.1007/JHEP10(2018)167) **10**[, 167](http://doi.org/10.1007/JHEP10(2018)167) (2018), [\[arXiv:1806.04079\].](https://arxiv.org/abs/1806.04079)
- <span id="page-22-8"></span>[66] R. D. Ball *et al.* (NNPDF), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-022-10328-7) **82**[, 5, 428](http://doi.org/10.1140/epjc/s10052-022-10328-7) (2022), [\[arXiv:2109.02653\].](https://arxiv.org/abs/2109.02653)
- <span id="page-22-9"></span>[67] T.-J. Hou *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.103.014013) **103**[, 1, 014013](http://doi.org/10.1103/PhysRevD.103.014013) (2021), [\[arXiv:1912.10053\].](https://arxiv.org/abs/1912.10053)
- <span id="page-22-10"></span>[68] G. Aad *et al.* (ATLAS), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-022-10217-z) **82**[, 5, 438](http://doi.org/10.1140/epjc/s10052-022-10217-z) (2022), [\[arXiv:2112.11266\].](https://arxiv.org/abs/2112.11266)
- <span id="page-22-11"></span>[69] S. Alekhin *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.96.014011) **D96**[, 1, 014011](http://doi.org/10.1103/PhysRevD.96.014011) (2017), [\[arXiv:1701.05838\].](https://arxiv.org/abs/1701.05838)
- <span id="page-22-12"></span>[70] A. Accardi *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.93.114017) **93**[, 11, 114017](http://doi.org/10.1103/PhysRevD.93.114017) (2016), [\[arXiv:1602.03154\].](https://arxiv.org/abs/1602.03154)
- <span id="page-22-13"></span>[71] G. Watt and R. S. Thorne, [JHEP](http://doi.org/10.1007/JHEP08(2012)052) **08**[, 052](http://doi.org/10.1007/JHEP08(2012)052) (2012), [\[arXiv:1205.4024\].](https://arxiv.org/abs/1205.4024)
- <span id="page-22-14"></span>[72] S. Carrazza *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-015-3590-7) **C75**[, 8, 369](http://doi.org/10.1140/epjc/s10052-015-3590-7) (2015), [\[arXiv:1505.06736\].](https://arxiv.org/abs/1505.06736)
- <span id="page-22-15"></span>[73] J. McGowan *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-023-11236-0) **83**[, 3, 185](http://doi.org/10.1140/epjc/s10052-023-11236-0) (2023), [Erratum: Eur.Phys.J.C 83, 302 (2023)], [\[arXiv:2207.04739\].](https://arxiv.org/abs/2207.04739)
- <span id="page-22-16"></span>[74] R. Abdul Khalek *et al.* (NNPDF), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-019-7401-4) **79**[, 11, 931](http://doi.org/10.1140/epjc/s10052-019-7401-4) (2019), [\[arXiv:1906.10698\].](https://arxiv.org/abs/1906.10698)
- <span id="page-22-17"></span>[75] J. C. Collins, F. Wilczek and A. Zee, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.18.242) **D18**[, 242](http://doi.org/10.1103/PhysRevD.18.242) (1978).
- [76] E. Laenen *et al.*, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(93)90201-Y) **[B392](http://doi.org/10.1016/0550-3213(93)90201-Y)**, 162 (1993).
- <span id="page-22-18"></span>[77] M. A. G. Aivazis *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.50.3102) **D50**[, 3102](http://doi.org/10.1103/PhysRevD.50.3102) (1994), [\[hep-ph/9312319\].](https://arxiv.org/abs/hep-ph/9312319)
- [78] M. Buza *et al.*, [Eur. Phys. J.](http://doi.org/10.1007/BF01245820) **C1**[, 301](http://doi.org/10.1007/BF01245820) (1998), [\[hep-ph/9612398\].](https://arxiv.org/abs/hep-ph/9612398)
- [79] J. C. Collins, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.58.094002) **D58**[, 094002](http://doi.org/10.1103/PhysRevD.58.094002) (1998), [\[hep-ph/9806259\].](https://arxiv.org/abs/hep-ph/9806259)
- [80] A. Chuvakin, J. Smith and W. L. van Neerven, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.61.096004) **D61**[, 096004](http://doi.org/10.1103/PhysRevD.61.096004) (2000), [\[hep](https://arxiv.org/abs/hep-ph/9910250)[ph/9910250\].](https://arxiv.org/abs/hep-ph/9910250)
- [81] R. S. Thorne, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.73.054019) **D73**[, 054019](http://doi.org/10.1103/PhysRevD.73.054019) (2006), [\[hep-ph/0601245\].](https://arxiv.org/abs/hep-ph/0601245)
- [82] R. S. Thorne and W. K. Tung, in "Proceedings, HERA and the LHC Workshop Series on the implications of HERA for LHC physics: 2006-2008," 332–351 (2008), [,2(2008)], [\[arXiv:0809.0714\].](https://arxiv.org/abs/0809.0714)
- [83] S. Alekhin and S. Moch, [Phys. Lett.](http://doi.org/10.1016/j.physletb.2011.04.026) **[B699](http://doi.org/10.1016/j.physletb.2011.04.026)**, 345 (2011), [\[arXiv:1011.5790\].](https://arxiv.org/abs/1011.5790)
- [84] S. Forte *et al.*, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2010.03.014) **[B834](http://doi.org/10.1016/j.nuclphysb.2010.03.014)**, 116 (2010), [\[arXiv:1001.2312\].](https://arxiv.org/abs/1001.2312)
- <span id="page-22-20"></span>[85] R. S. Thorne, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.86.074017) **D86**[, 074017](http://doi.org/10.1103/PhysRevD.86.074017) (2012), [\[arXiv:1201.6180\].](https://arxiv.org/abs/1201.6180)

- <span id="page-23-0"></span>[86] E. G. de Oliveira *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-013-2616-2) **C73**[, 10, 2616](http://doi.org/10.1140/epjc/s10052-013-2616-2) (2013), [\[arXiv:1307.3508\].](https://arxiv.org/abs/1307.3508)
- <span id="page-23-1"></span>[87] H. Abramowicz *et al.* (H1, ZEUS), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-5848-3) **C78**[, 6, 473](http://doi.org/10.1140/epjc/s10052-018-5848-3) (2018), [\[arXiv:1804.01019\].](https://arxiv.org/abs/1804.01019)
- <span id="page-23-2"></span>[88] O. Behnke, A. Geiser and M. Lisovyi, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2015.06.002) **[84](http://doi.org/10.1016/j.ppnp.2015.06.002)**, 1 (2015), [\[arXiv:1506.07519\].](https://arxiv.org/abs/1506.07519)
- <span id="page-23-3"></span>[89] R. D. Ball *et al.* (NNPDF), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-017-5199-5) **77**[, 10, 663](http://doi.org/10.1140/epjc/s10052-017-5199-5) (2017), [\[arXiv:1706.00428\].](https://arxiv.org/abs/1706.00428)
- <span id="page-23-4"></span>[90] J. Butterworth *et al.*, [J. Phys.](http://doi.org/10.1088/0954-3899/43/2/023001) **G43**[, 023001](http://doi.org/10.1088/0954-3899/43/2/023001) (2016), [\[arXiv:1510.03865\].](https://arxiv.org/abs/1510.03865)
- <span id="page-23-5"></span>[91] R. D. Ball *et al.* (PDF4LHC Working Group), [J. Phys. G](http://doi.org/10.1088/1361-6471/ac7216) **49**[, 8, 080501](http://doi.org/10.1088/1361-6471/ac7216) (2022), [\[arXiv:2203.05506\].](https://arxiv.org/abs/2203.05506)
- <span id="page-23-6"></span>[92] E. R. Nocera *et al.* (NNPDF), [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2014.08.008) **[B887](http://doi.org/10.1016/j.nuclphysb.2014.08.008)**, 276 (2014), [\[arXiv:1406.5539\].](https://arxiv.org/abs/1406.5539)
- <span id="page-23-7"></span>[93] T. Cridge *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-021-09533-7) **81**[, 744](http://doi.org/10.1140/epjc/s10052-021-09533-7) (2021), [\[arXiv:2106.10289\].](https://arxiv.org/abs/2106.10289)
- <span id="page-23-8"></span>[94] R. D. Ball *et al.* (NNPDF), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-5897-7) **C78**[, 5, 408](http://doi.org/10.1140/epjc/s10052-018-5897-7) (2018), [\[arXiv:1802.03398\].](https://arxiv.org/abs/1802.03398)
- <span id="page-23-9"></span>[95] A. D. Martin *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s2004-02088-7) **C39**[, 155](http://doi.org/10.1140/epjc/s2004-02088-7) (2005), [\[hep-ph/0411040\].](https://arxiv.org/abs/hep-ph/0411040)
- [96] R. D. Ball *et al.* (NNPDF), [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2013.10.010) **[B877](http://doi.org/10.1016/j.nuclphysb.2013.10.010)**, 290 (2013), [\[arXiv:1308.0598\].](https://arxiv.org/abs/1308.0598)
- <span id="page-23-10"></span>[97] C. Schmidt *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.93.114015) **D93**[, 11, 114015](http://doi.org/10.1103/PhysRevD.93.114015) (2016), [\[arXiv:1509.02905\].](https://arxiv.org/abs/1509.02905)
- <span id="page-23-11"></span>[98] M. Gluck, C. Pisano and E. Reya, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(02)02125-1) **[B540](http://doi.org/10.1016/S0370-2693(02)02125-1)**, 75 (2002), [\[hep-ph/0206126\].](https://arxiv.org/abs/hep-ph/0206126)
- [99] A. D. Martin and M. G. Ryskin, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-014-3040-y) **C74**[, 3040](http://doi.org/10.1140/epjc/s10052-014-3040-y) (2014), [\[arXiv:1406.2118\].](https://arxiv.org/abs/1406.2118)
- <span id="page-23-12"></span>[100] L. A. Harland-Lang, V. A. Khoze and M. G. Ryskin, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.94.074008) **D94**[, 7, 074008](http://doi.org/10.1103/PhysRevD.94.074008) (2016), [\[arXiv:1607.04635\].](https://arxiv.org/abs/1607.04635)
- <span id="page-23-13"></span>[101] A. Manohar *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.117.242002) **117**[, 24, 242002](http://doi.org/10.1103/PhysRevLett.117.242002) (2016), [\[arXiv:1607.04266\].](https://arxiv.org/abs/1607.04266)
- <span id="page-23-14"></span>[102] V. Bertone *et al.* (NNPDF), [SciPost Phys.](http://doi.org/10.21468/SciPostPhys.5.1.008) **5**[, 1, 008](http://doi.org/10.21468/SciPostPhys.5.1.008) (2018), [\[arXiv:1712.07053\].](https://arxiv.org/abs/1712.07053)
- <span id="page-23-15"></span>[103] L. A. Harland-Lang *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-019-7296-0) **C79**[, 10, 811](http://doi.org/10.1140/epjc/s10052-019-7296-0) (2019), [\[arXiv:1907.02750\].](https://arxiv.org/abs/1907.02750)
- <span id="page-23-16"></span>[104] K. Xie *et al.* (CTEQ-TEA), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.105.054006) **105**[, 5, 054006](http://doi.org/10.1103/PhysRevD.105.054006) (2022), [\[arXiv:2106.10299\].](https://arxiv.org/abs/2106.10299)
- <span id="page-23-17"></span>[105] L. A. Harland-Lang, [JHEP](http://doi.org/10.1007/JHEP03(2020)128) **03**[, 128](http://doi.org/10.1007/JHEP03(2020)128) (2020), [\[arXiv:1910.10178\].](https://arxiv.org/abs/1910.10178)
- <span id="page-23-18"></span>[106] H.-W. Lin *et al.*, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2018.01.007) **100**[, 107](http://doi.org/10.1016/j.ppnp.2018.01.007) (2018), [\[arXiv:1711.07916\].](https://arxiv.org/abs/1711.07916)
- <span id="page-23-19"></span>[107] M. Constantinou *et al.*, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/j.ppnp.2021.103908) **121**[, 103908](http://doi.org/10.1016/j.ppnp.2021.103908) (2021), [\[arXiv:2006.08636\].](https://arxiv.org/abs/2006.08636)
- <span id="page-23-20"></span>[108] Y.-B. Yang *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.121.212001) **121**[, 21, 212001](http://doi.org/10.1103/PhysRevLett.121.212001) (2018), [\[arXiv:1808.08677\].](https://arxiv.org/abs/1808.08677)
- <span id="page-23-31"></span>[109] C. Alexandrou *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.101.094513) **101**[, 9, 094513](http://doi.org/10.1103/PhysRevD.101.094513) (2020), [\[arXiv:2003.08486\].](https://arxiv.org/abs/2003.08486)
- <span id="page-23-21"></span>[110] Z. Fan, H.-W. Lin and M. Zeilbeck, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.107.034505) **107**[, 3, 034505](http://doi.org/10.1103/PhysRevD.107.034505) (2023), [\[arXiv:2208.00980\].](https://arxiv.org/abs/2208.00980)
- <span id="page-23-22"></span>[111] X. Ji, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.110.262002) **110**[, 262002](http://doi.org/10.1103/PhysRevLett.110.262002) (2013), [\[arXiv:1305.1539\].](https://arxiv.org/abs/1305.1539)
- <span id="page-23-23"></span>[112] A. V. Radyushkin, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.96.034025) **96**[, 3, 034025](http://doi.org/10.1103/PhysRevD.96.034025) (2017), [\[arXiv:1705.01488\].](https://arxiv.org/abs/1705.01488)
- <span id="page-23-24"></span>[113] C. Alexandrou *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.121.112001) **121**[, 11, 112001](http://doi.org/10.1103/PhysRevLett.121.112001) (2018), [\[arXiv:1803.02685\].](https://arxiv.org/abs/1803.02685)
- [114] R. Zhang, H.-W. Lin and B. Yoon, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.104.094511) **104**[, 9, 094511](http://doi.org/10.1103/PhysRevD.104.094511) (2021), [\[arXiv:2005.01124\].](https://arxiv.org/abs/2005.01124)
- [115] Z. Fan, W. Good and H.-W. Lin, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.108.014508) **108**[, 1, 014508](http://doi.org/10.1103/PhysRevD.108.014508) (2023), [\[arXiv:2210.09985\].](https://arxiv.org/abs/2210.09985)
- [116] M. Bhat *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.103.034510) **103**[, 3, 034510](http://doi.org/10.1103/PhysRevD.103.034510) (2021), [\[arXiv:2005.02102\].](https://arxiv.org/abs/2005.02102)
- <span id="page-23-25"></span>[117] B. Joó *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.125.232003) **125**[, 23, 232003](http://doi.org/10.1103/PhysRevLett.125.232003) (2020), [\[arXiv:2004.01687\].](https://arxiv.org/abs/2004.01687)
- <span id="page-23-26"></span>[118] A. Buckley *et al.*, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-015-3318-8) **C75**[, 132](http://doi.org/10.1140/epjc/s10052-015-3318-8) (2015), [\[arXiv:1412.7420\].](https://arxiv.org/abs/1412.7420)
- <span id="page-23-27"></span>[119] I. Helenius, M. Walt and W. Vogelsang, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.105.094031) **105**[, 9, 094031](http://doi.org/10.1103/PhysRevD.105.094031) (2022), [\[arXiv:2112.11904\].](https://arxiv.org/abs/2112.11904)
- <span id="page-23-28"></span>[120] P. Duwentäster *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.105.114043) **105**[, 11, 114043](http://doi.org/10.1103/PhysRevD.105.114043) (2022), [\[arXiv:2204.09982\].](https://arxiv.org/abs/2204.09982)
- <span id="page-23-29"></span>[121] E. P. Segarra *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.103.114015) **103**[, 11, 114015](http://doi.org/10.1103/PhysRevD.103.114015) (2021), [\[arXiv:2012.11566\].](https://arxiv.org/abs/2012.11566)
- <span id="page-23-30"></span>[122] K. J. Eskola *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-022-10359-0) **82**[, 5, 413](http://doi.org/10.1140/epjc/s10052-022-10359-0) (2022), [\[arXiv:2112.12462\].](https://arxiv.org/abs/2112.12462)

- <span id="page-24-0"></span>[123] R. Abdul Khalek *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-022-10417-7) **82**[, 6, 507](http://doi.org/10.1140/epjc/s10052-022-10417-7) (2022), [\[arXiv:2201.12363\].](https://arxiv.org/abs/2201.12363)
- <span id="page-24-1"></span>[124] R. Abdul Khalek, J. J. Ethier and J. Rojo (NNPDF), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-019-6983-1) **79**[, 6, 471](http://doi.org/10.1140/epjc/s10052-019-6983-1) (2019), [\[arXiv:1904.00018\].](https://arxiv.org/abs/1904.00018)
- <span id="page-24-2"></span>[125] H. Khanpour *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.104.034010) **104**[, 3, 034010](http://doi.org/10.1103/PhysRevD.104.034010) (2021), [\[arXiv:2010.00555\].](https://arxiv.org/abs/2010.00555)
- <span id="page-24-3"></span>[126] K. Kovarik *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.106.122301) **106**[, 122301](http://doi.org/10.1103/PhysRevLett.106.122301) (2011), [\[arXiv:1012.0286\].](https://arxiv.org/abs/1012.0286)
- <span id="page-24-4"></span>[127] H. Paukkunen and C. A. Salgado, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.110.212301) **110**[, 21, 212301](http://doi.org/10.1103/PhysRevLett.110.212301) (2013), [\[arXiv:1302.2001\].](https://arxiv.org/abs/1302.2001)
- <span id="page-24-5"></span>[128] G. Aad *et al.* (ATLAS), [Phys. Rev.](http://doi.org/10.1103/PhysRevC.92.044915) **C92**[, 4, 044915](http://doi.org/10.1103/PhysRevC.92.044915) (2015), [\[arXiv:1507.06232\].](https://arxiv.org/abs/1507.06232)
- [129] V. Khachatryan *et al.* (CMS), [Phys. Lett.](http://doi.org/10.1016/j.physletb.2015.09.057) **[B750](http://doi.org/10.1016/j.physletb.2015.09.057)**, 565 (2015), [\[arXiv:1503.05825\].](https://arxiv.org/abs/1503.05825)
- [130] V. Khachatryan *et al.* (CMS), [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2016.05.044) **[759](http://doi.org/10.1016/j.physletb.2016.05.044)**, 36 (2016), [\[arXiv:1512.06461\].](https://arxiv.org/abs/1512.06461)
- <span id="page-24-6"></span>[131] A. M. Sirunyan *et al.* (CMS), [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2019.135048) **800**[, 135048](http://doi.org/10.1016/j.physletb.2019.135048) (2020), [\[arXiv:1905.01486\].](https://arxiv.org/abs/1905.01486)
- <span id="page-24-7"></span>[132] A. M. Sirunyan *et al.* (CMS), [JHEP](http://doi.org/10.1007/JHEP05(2021)182) **05**[, 182](http://doi.org/10.1007/JHEP05(2021)182) (2021), [\[arXiv:2102.13648\].](https://arxiv.org/abs/2102.13648)
- <span id="page-24-8"></span>[133] A. M. Sirunyan *et al.* (CMS), [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.121.062002) **121**[, 6, 062002](http://doi.org/10.1103/PhysRevLett.121.062002) (2018), [\[arXiv:1805.04736\].](https://arxiv.org/abs/1805.04736)
- <span id="page-24-9"></span>[134] R. Aaij *et al.* (LHCb), [JHEP](http://doi.org/10.1007/JHEP10(2017)090) **10**[, 090](http://doi.org/10.1007/JHEP10(2017)090) (2017), [\[arXiv:1707.02750\].](https://arxiv.org/abs/1707.02750)
- <span id="page-24-10"></span>[135] S. Acharya *et al.* (ALICE), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-6013-8) **C78**[, 8, 624](http://doi.org/10.1140/epjc/s10052-018-6013-8) (2018), [\[arXiv:1801.07051\].](https://arxiv.org/abs/1801.07051)
- <span id="page-24-11"></span>[136] S. S. Adler *et al.* (PHENIX), [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.98.172302) **98**[, 172302](http://doi.org/10.1103/PhysRevLett.98.172302) (2007), [\[arXiv:nucl-ex/0610036\].](https://arxiv.org/abs/nucl-ex/0610036)
- <span id="page-24-12"></span>[137] E. C. Aschenauer *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.96.114005) **D96**[, 11, 114005](http://doi.org/10.1103/PhysRevD.96.114005) (2017), [\[arXiv:1708.05654\].](https://arxiv.org/abs/1708.05654)
- [138] R. Abdul Khalek *et al.*, [Nucl. Phys. A](http://doi.org/10.1016/j.nuclphysa.2022.122447) **1026**[, 122447](http://doi.org/10.1016/j.nuclphysa.2022.122447) (2022), [\[arXiv:2103.05419\].](https://arxiv.org/abs/2103.05419)
- <span id="page-24-13"></span>[139] R. A. Khalek *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.103.096005) **103**[, 9, 096005](http://doi.org/10.1103/PhysRevD.103.096005) (2021), [\[arXiv:2102.00018\].](https://arxiv.org/abs/2102.00018)
- <span id="page-24-14"></span>[140] P. V. Landshoff and J. C. Polkinghorne, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.18.3344) **18**[, 3344](http://doi.org/10.1103/PhysRevD.18.3344) (1978).
- [141] R. Kirschner, [Phys. Lett. B](http://doi.org/10.1016/0370-2693(79)90300-9) **84**[, 266](http://doi.org/10.1016/0370-2693(79)90300-9) (1979).
- [142] N. Paver and D. Treleani, [Nuovo Cim. A](http://doi.org/10.1007/BF02814035) **70**[, 215](http://doi.org/10.1007/BF02814035) (1982).
- [143] V. P. Shelest, A. M. Snigirev and G. M. Zinovev, [Phys. Lett. B](http://doi.org/10.1016/0370-2693(82)90049-1) **113**[, 325](http://doi.org/10.1016/0370-2693(82)90049-1) (1982).
- <span id="page-24-15"></span>[144] M. Mekhfi, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.32.2371) **32**[, 2371](http://doi.org/10.1103/PhysRevD.32.2371) (1985).
- <span id="page-24-16"></span>[145] B. Blok *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.83.071501) **83**[, 071501](http://doi.org/10.1103/PhysRevD.83.071501) (2011), [\[arXiv:1009.2714\].](https://arxiv.org/abs/1009.2714)
- [146] M. Diehl and A. Schafer, [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2011.03.024) **698**[, 389](http://doi.org/10.1016/j.physletb.2011.03.024) (2011), [\[arXiv:1102.3081\].](https://arxiv.org/abs/1102.3081)
- [147] B. Blok *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-012-1963-8) **72**[, 1963](http://doi.org/10.1140/epjc/s10052-012-1963-8) (2012), [\[arXiv:1106.5533\].](https://arxiv.org/abs/1106.5533)
- <span id="page-24-17"></span>[148] M. Diehl, D. Ostermeier and A. Schafer, [JHEP](http://doi.org/10.1007/JHEP03(2012)089) **03**[, 089](http://doi.org/10.1007/JHEP03(2012)089) (2012), [Erratum: JHEP 03, 001 (2016)], [\[arXiv:1111.0910\].](https://arxiv.org/abs/1111.0910)
- <span id="page-24-18"></span>[149] C. H. Kom, A. Kulesza and W. J. Stirling, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.107.082002) **107**[, 082002](http://doi.org/10.1103/PhysRevLett.107.082002) (2011), [\[arXiv:1105.4186\].](https://arxiv.org/abs/1105.4186)
- <span id="page-24-19"></span>[150] C. H. Kom, A. Kulesza and W. J. Stirling, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-011-1802-3) **71**[, 1802](http://doi.org/10.1140/epjc/s10052-011-1802-3) (2011), [\[arXiv:1109.0309\].](https://arxiv.org/abs/1109.0309)
- <span id="page-24-20"></span>[151] J. R. Gaunt *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-010-1362-y) **69**[, 53](http://doi.org/10.1140/epjc/s10052-010-1362-y) (2010), [\[arXiv:1003.3953\].](https://arxiv.org/abs/1003.3953)
- <span id="page-24-21"></span>[152] F. Abe *et al.* (CDF), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.56.3811) **56**[, 3811](http://doi.org/10.1103/PhysRevD.56.3811) (1997).
- <span id="page-24-22"></span>[153] V. M. Abazov *et al.* (D0), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.93.052008) **93**[, 5, 052008](http://doi.org/10.1103/PhysRevD.93.052008) (2016), [\[arXiv:1512.05291\].](https://arxiv.org/abs/1512.05291)
- <span id="page-24-23"></span>[154] R. Aaij *et al.* (LHCb), [JHEP](http://doi.org/10.1007/JHEP06(2017)047) **06**[, 047](http://doi.org/10.1007/JHEP06(2017)047) (2017), [Erratum: JHEP 10, 068 (2017)], [\[arXiv:1612.07451\].](https://arxiv.org/abs/1612.07451)
- [155] M. Aaboud *et al.* (ATLAS), [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2019.01.062) **790**[, 595](http://doi.org/10.1016/j.physletb.2019.01.062) (2019), [\[arXiv:1811.11094\].](https://arxiv.org/abs/1811.11094)
- <span id="page-24-24"></span>[156] A. M. Sirunyan *et al.* (CMS), [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-019-7541-6) **80**[, 1, 41](http://doi.org/10.1140/epjc/s10052-019-7541-6) (2020), [\[arXiv:1909.06265\].](https://arxiv.org/abs/1909.06265)
- <span id="page-24-25"></span>[157] A. V. Manohar and W. J. Waalewijn, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.85.114009) **85**[, 114009](http://doi.org/10.1103/PhysRevD.85.114009) (2012), [\[arXiv:1202.3794\].](https://arxiv.org/abs/1202.3794)
- [158] B. Blok *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-014-2926-z) **74**[, 2926](http://doi.org/10.1140/epjc/s10052-014-2926-z) (2014), [\[arXiv:1306.3763\].](https://arxiv.org/abs/1306.3763)

- <span id="page-25-0"></span>[159] M. Diehl, J. R. Gaunt and K. Schönwald, [JHEP](http://doi.org/10.1007/JHEP06(2017)083) **06**[, 083](http://doi.org/10.1007/JHEP06(2017)083) (2017), [\[arXiv:1702.06486\].](https://arxiv.org/abs/1702.06486)
- <span id="page-25-1"></span>[160] J. R. Gaunt and W. J. Stirling, [JHEP](http://doi.org/10.1007/JHEP03(2010)005) **03**[, 005](http://doi.org/10.1007/JHEP03(2010)005) (2010), [\[arXiv:0910.4347\].](https://arxiv.org/abs/0910.4347)
- [161] K. Golec-Biernat *et al.*, [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2015.09.067) **750**[, 559](http://doi.org/10.1016/j.physletb.2015.09.067) (2015), [\[arXiv:1507.08583\].](https://arxiv.org/abs/1507.08583)
- <span id="page-25-2"></span>[162] M. Diehl *et al.*, [Eur. Phys. J. C](http://doi.org/10.1140/epjc/s10052-020-8038-z) **80**[, 5, 468](http://doi.org/10.1140/epjc/s10052-020-8038-z) (2020), [\[arXiv:2001.10428\].](https://arxiv.org/abs/2001.10428)
- <span id="page-25-3"></span>[163] M. Diehl, J. R. Gaunt and P. Ploessl, [JHEP](http://doi.org/10.1007/JHEP08(2021)040) **08**[, 040](http://doi.org/10.1007/JHEP08(2021)040) (2021), [\[arXiv:2105.08425\].](https://arxiv.org/abs/2105.08425)
- <span id="page-25-4"></span>[164] D. Flay *et al.* (Jefferson Lab Hall A), [Phys. Rev.](http://doi.org/10.1103/PhysRevD.94.052003) **D94**[, 5, 052003](http://doi.org/10.1103/PhysRevD.94.052003) (2016), [\[arXiv:1603.03612\].](https://arxiv.org/abs/1603.03612)
- <span id="page-25-5"></span>[165] C. Adolph *et al.* (COMPASS), [Phys. Lett.](http://doi.org/10.1016/j.physletb.2015.11.064) **[B753](http://doi.org/10.1016/j.physletb.2015.11.064)**, 18 (2016), [\[arXiv:1503.08935\].](https://arxiv.org/abs/1503.08935)
- <span id="page-25-6"></span>[166] C. Adolph *et al.* (COMPASS), [Phys. Lett.](http://doi.org/10.1016/j.physletb.2017.03.018) **[B769](http://doi.org/10.1016/j.physletb.2017.03.018)**, 34 (2017), [\[arXiv:1612.00620\].](https://arxiv.org/abs/1612.00620)
- <span id="page-25-7"></span>[167] R. Fersch *et al.* (CLAS), [Phys. Rev.](http://doi.org/10.1103/PhysRevC.96.065208) **C96**[, 6, 065208](http://doi.org/10.1103/PhysRevC.96.065208) (2017), [\[arXiv:1706.10289\].](https://arxiv.org/abs/1706.10289)
- <span id="page-25-8"></span>[168] M. Hirai and S. Kumano (Asymmetry Analysis), [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2008.12.026) **B813**[, 106](http://doi.org/10.1016/j.nuclphysb.2008.12.026) (2009), [\[arXiv:0808.0413\].](https://arxiv.org/abs/0808.0413)
- [169] D. de Florian *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.101.072001) **101**[, 072001](http://doi.org/10.1103/PhysRevLett.101.072001) (2008), [\[arXiv:0804.0422\];](https://arxiv.org/abs/0804.0422) D. de Florian *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.80.034030) **D80**[, 034030](http://doi.org/10.1103/PhysRevD.80.034030) (2009), [\[arXiv:0904.3821\].](https://arxiv.org/abs/0904.3821)
- [170] E. Leader, A. V. Sidorov and D. B. Stamenov, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.82.114018) **D82**[, 114018](http://doi.org/10.1103/PhysRevD.82.114018) (2010), [\[arXiv:1010.0574\].](https://arxiv.org/abs/1010.0574)
- <span id="page-25-9"></span>[171] J. Blumlein and H. Bottcher, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2010.08.005) **[B841](http://doi.org/10.1016/j.nuclphysb.2010.08.005)**, 205 (2010), [\[arXiv:1005.3113\].](https://arxiv.org/abs/1005.3113)
- <span id="page-25-10"></span>[172] D. de Florian *et al.*, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.113.012001) **113**[, 1, 012001](http://doi.org/10.1103/PhysRevLett.113.012001) (2014), [\[arXiv:1404.4293\].](https://arxiv.org/abs/1404.4293)
- <span id="page-25-11"></span>[173] N. Sato *et al.* (Jefferson Lab Angular Momentum), [Phys. Rev.](http://doi.org/10.1103/PhysRevD.93.074005) **D93**[, 7, 074005](http://doi.org/10.1103/PhysRevD.93.074005) (2016), [\[arXiv:1601.07782\].](https://arxiv.org/abs/1601.07782)
- <span id="page-25-12"></span>[174] D. de Florian *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.91.014035) **D91**[, 1, 014035](http://doi.org/10.1103/PhysRevD.91.014035) (2015), [\[arXiv:1410.6027\].](https://arxiv.org/abs/1410.6027)
- [175] D. de Florian *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.95.094019) **D95**[, 9, 094019](http://doi.org/10.1103/PhysRevD.95.094019) (2017), [\[arXiv:1702.06353\].](https://arxiv.org/abs/1702.06353)
- [176] V. Bertone *et al.* (NNPDF), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-017-5088-y) **C77**[, 8, 516](http://doi.org/10.1140/epjc/s10052-017-5088-y) (2017), [\[arXiv:1706.07049\].](https://arxiv.org/abs/1706.07049)
- <span id="page-25-13"></span>[177] V. Bertone *et al.* (NNPDF), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-6130-4) **C78**[, 8, 651](http://doi.org/10.1140/epjc/s10052-018-6130-4) (2018), [\[arXiv:1807.03310\].](https://arxiv.org/abs/1807.03310)
- <span id="page-25-23"></span>[178] D. De Florian *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.100.114027) **100**[, 11, 114027](http://doi.org/10.1103/PhysRevD.100.114027) (2019), [\[arXiv:1902.10548\].](https://arxiv.org/abs/1902.10548)
- <span id="page-25-14"></span>[179] L. Adamczyk *et al.* (STAR), [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.115.092002) **115**[, 9, 092002](http://doi.org/10.1103/PhysRevLett.115.092002) (2015), [\[arXiv:1405.5134\].](https://arxiv.org/abs/1405.5134)
- <span id="page-25-15"></span>[180] L. Adamczyk *et al.* (STAR), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.95.071103) **95**[, 7, 071103](http://doi.org/10.1103/PhysRevD.95.071103) (2017), [\[arXiv:1610.06616\].](https://arxiv.org/abs/1610.06616)
- <span id="page-25-16"></span>[181] A. Adare *et al.* (PHENIX), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.90.012007) **90**[, 1, 012007](http://doi.org/10.1103/PhysRevD.90.012007) (2014), [\[arXiv:1402.6296\].](https://arxiv.org/abs/1402.6296)
- <span id="page-25-17"></span>[182] J. Adam *et al.* (STAR), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.99.051102) **99**[, 5, 051102](http://doi.org/10.1103/PhysRevD.99.051102) (2019), [\[arXiv:1812.04817\].](https://arxiv.org/abs/1812.04817)
- <span id="page-25-18"></span>[183] A. Adare *et al.* (PHENIX), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.98.032007) **98**[, 3, 032007](http://doi.org/10.1103/PhysRevD.98.032007) (2018), [\[arXiv:1804.04181\].](https://arxiv.org/abs/1804.04181)
- <span id="page-25-19"></span>[184] R. D. Ball *et al.* (NNPDF), [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2013.05.007) **[B874](http://doi.org/10.1016/j.nuclphysb.2013.05.007)**, 36 (2013), [\[arXiv:1303.7236\].](https://arxiv.org/abs/1303.7236)
- <span id="page-25-20"></span>[185] J. Adam *et al.* (STAR), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.100.052005) **100**[, 5, 052005](http://doi.org/10.1103/PhysRevD.100.052005) (2019), [\[arXiv:1906.02740\].](https://arxiv.org/abs/1906.02740)
- [186] M. Abdallah *et al.* (STAR), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.103.L091103) **103**[, 9, L091103](http://doi.org/10.1103/PhysRevD.103.L091103) (2021), [\[arXiv:2103.05571\].](https://arxiv.org/abs/2103.05571)
- <span id="page-25-21"></span>[187] M. S. Abdallah *et al.* (STAR), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.105.092011) **105**[, 9, 092011](http://doi.org/10.1103/PhysRevD.105.092011) (2022), [\[arXiv:2110.11020\].](https://arxiv.org/abs/2110.11020)
- <span id="page-25-22"></span>[188] A. Adare *et al.* (PHENIX), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.93.011501) **93**[, 1, 011501](http://doi.org/10.1103/PhysRevD.93.011501) (2016), [\[arXiv:1510.02317\].](https://arxiv.org/abs/1510.02317)
- <span id="page-25-24"></span>[189] C. Cocuzza *et al.* (Jefferson Lab Angular Momentum (JAM)), [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.106.L031502) **106**[, 3, L031502](http://doi.org/10.1103/PhysRevD.106.L031502) (2022), [\[arXiv:2202.03372\].](https://arxiv.org/abs/2202.03372)
- <span id="page-25-25"></span>[190] J. Liang *et al.*, [Phys. Rev. D](http://doi.org/10.1103/PhysRevD.98.074505) **98**[, 7, 074505](http://doi.org/10.1103/PhysRevD.98.074505) (2018), [\[arXiv:1806.08366\].](https://arxiv.org/abs/1806.08366)
- <span id="page-25-26"></span>[191] R. Nisius, [Phys. Rept.](http://doi.org/10.1016/S0370-1573(99)00115-5) **332**[, 165](http://doi.org/10.1016/S0370-1573(99)00115-5) (2000), [\[hep-ex/9912049\].](https://arxiv.org/abs/hep-ex/9912049)
- <span id="page-25-27"></span>[192] T. F. Walsh and P. M. Zerwas, [Phys. Lett.](http://doi.org/10.1016/0370-2693(73)90520-0) **44B**[, 195](http://doi.org/10.1016/0370-2693(73)90520-0) (1973).
- <span id="page-25-28"></span>[193] R. L. Kingsley, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(73)90168-5) **[B60](http://doi.org/10.1016/0550-3213(73)90168-5)**, 45 (1973).

- <span id="page-26-0"></span>[194] E. Witten, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(77)90038-4) **[B120](http://doi.org/10.1016/0550-3213(77)90038-4)**, 189 (1977).
- <span id="page-26-1"></span>[195] W. A. Bardeen and A. J. Buras, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.21.2041) **D20**[, 166](http://doi.org/10.1103/PhysRevD.21.2041) (1979), [Erratum: Phys. Rev.D21,2041(1980)].
- [196] M. Fontannaz and E. Pilon, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.45.382) **D45**[, 382](http://doi.org/10.1103/PhysRevD.45.382) (1992).
- <span id="page-26-2"></span>[197] M. Gluck, E. Reya and A. Vogt, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.45.3986) **D45**[, 3986](http://doi.org/10.1103/PhysRevD.45.3986) (1992).
- <span id="page-26-3"></span>[198] F. Cornet, P. Jankowski and M. Krawczyk, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.70.093004) **D70**[, 093004](http://doi.org/10.1103/PhysRevD.70.093004) (2004), [\[hep-ph/0404063\].](https://arxiv.org/abs/hep-ph/0404063)
- [199] P. Aurenche, M. Fontannaz and J. P. Guillet, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s2005-02355-1) **C44**[, 395](http://doi.org/10.1140/epjc/s2005-02355-1) (2005), [\[hep](https://arxiv.org/abs/hep-ph/0503259)[ph/0503259\].](https://arxiv.org/abs/hep-ph/0503259)
- <span id="page-26-4"></span>[200] W. Slominski, H. Abramowicz and A. Levy, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s2005-02458-7) **C45**[, 633](http://doi.org/10.1140/epjc/s2005-02458-7) (2006), [\[hep-ph/0504003\].](https://arxiv.org/abs/hep-ph/0504003)
- <span id="page-26-5"></span>[201] H. Abramowicz and A. Caldwell, [Rev. Mod. Phys.](http://doi.org/10.1103/RevModPhys.71.1275) **71**[, 1275](http://doi.org/10.1103/RevModPhys.71.1275) (1999), [\[hep-ex/9903037\].](https://arxiv.org/abs/hep-ex/9903037)
- <span id="page-26-12"></span>[202] S. Chekanov *et al.* (ZEUS), [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2010.01.014) **[B831](http://doi.org/10.1016/j.nuclphysb.2010.01.014)**, 1 (2010), [\[arXiv:0911.4119\].](https://arxiv.org/abs/0911.4119)
- <span id="page-26-13"></span>[203] A. Aktas *et al.* (H1), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-006-0035-3) **C48**[, 715](http://doi.org/10.1140/epjc/s10052-006-0035-3) (2006), [\[hep-ex/0606004\].](https://arxiv.org/abs/hep-ex/0606004)
- <span id="page-26-11"></span>[204] A. D. Martin, M. G. Ryskin and G. Watt, [Phys. Lett.](http://doi.org/10.1016/j.physletb.2006.11.032) **[B644](http://doi.org/10.1016/j.physletb.2006.11.032)**, 131 (2007), [\[hep-ph/0609273\].](https://arxiv.org/abs/hep-ph/0609273)
- <span id="page-26-14"></span>[205] A. Aktas *et al.* (H1), [JHEP](http://doi.org/10.1088/1126-6708/2007/10/042) **10**[, 042](http://doi.org/10.1088/1126-6708/2007/10/042) (2007), [\[arXiv:0708.3217\].](https://arxiv.org/abs/0708.3217)
- <span id="page-26-6"></span>[206] F. D. Aaron *et al.* (H1, ZEUS), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-012-2175-y) **C72**[, 2175](http://doi.org/10.1140/epjc/s10052-012-2175-y) (2012), [\[arXiv:1207.4864\].](https://arxiv.org/abs/1207.4864)
- <span id="page-26-7"></span>[207] F. D. Aaron *et al.* (H1), [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-012-2074-2) **C72**[, 2074](http://doi.org/10.1140/epjc/s10052-012-2074-2) (2012), [\[arXiv:1203.4495\].](https://arxiv.org/abs/1203.4495)
- <span id="page-26-8"></span>[208] J. C. Collins, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.61.019902) **D57**[, 3051](http://doi.org/10.1103/PhysRevD.61.019902) (1998), [Erratum: Phys. Rev.D61,019902(2000)], [\[hep](https://arxiv.org/abs/hep-ph/9709499)[ph/9709499\].](https://arxiv.org/abs/hep-ph/9709499)
- <span id="page-26-9"></span>[209] G. Ingelman and P. E. Schlein, [Phys. Lett.](http://doi.org/10.1016/0370-2693(85)91181-5) **[152B](http://doi.org/10.1016/0370-2693(85)91181-5)**, 256 (1985).
- <span id="page-26-10"></span>[210] M. Goharipour, H. Khanpour and V. Guzey, [Eur. Phys. J.](http://doi.org/10.1140/epjc/s10052-018-5787-z) **C78**[, 4, 309](http://doi.org/10.1140/epjc/s10052-018-5787-z) (2018), [\[arXiv:1802.01363\].](https://arxiv.org/abs/1802.01363)
- <span id="page-26-15"></span>[211] X. Ji, [Phys. Rev. Lett.](http://doi.org/10.1103/PhysRevLett.91.062001) **91**[, 062001](http://doi.org/10.1103/PhysRevLett.91.062001) (2003), [\[hep-ph/0304037\].](https://arxiv.org/abs/hep-ph/0304037)
- [212] A. V. Belitsky, X. Ji and F. Yuan, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.69.074014) **D69**[, 074014](http://doi.org/10.1103/PhysRevD.69.074014) (2004), [\[hep-ph/0307383\].](https://arxiv.org/abs/hep-ph/0307383)
- <span id="page-26-16"></span>[213] C. Lorce, B. Pasquini and M. Vanderhaeghen, [JHEP](http://doi.org/10.1007/JHEP05(2011)041) **05**[, 041](http://doi.org/10.1007/JHEP05(2011)041) (2011), [\[arXiv:1102.4704\].](https://arxiv.org/abs/1102.4704)
- <span id="page-26-17"></span>[214] X.-D. Ji, [J. Phys.](http://doi.org/10.1088/0954-3899/24/7/002) **G24**[, 1181](http://doi.org/10.1088/0954-3899/24/7/002) (1998), [\[hep-ph/9807358\].](https://arxiv.org/abs/hep-ph/9807358)
- [215] K. Goeke, M. V. Polyakov and M. Vanderhaeghen, [Prog. Part. Nucl. Phys.](http://doi.org/10.1016/S0146-6410(01)00158-2) **47**[, 401](http://doi.org/10.1016/S0146-6410(01)00158-2) (2001), [\[hep-ph/0106012\].](https://arxiv.org/abs/hep-ph/0106012)
- [216] M. Diehl, [Phys. Rept.](http://doi.org/10.1016/j.physrep.2003.08.002) **[388](http://doi.org/10.1016/j.physrep.2003.08.002)**, 41 (2003), [\[hep-ph/0307382\].](https://arxiv.org/abs/hep-ph/0307382)
- [217] A. V. Belitsky and A. V. Radyushkin, [Phys. Rept.](http://doi.org/10.1016/j.physrep.2005.06.002) **[418](http://doi.org/10.1016/j.physrep.2005.06.002)**, 1 (2005), [\[hep-ph/0504030\].](https://arxiv.org/abs/hep-ph/0504030)
- [218] S. Boffi and B. Pasquini, [Riv. Nuovo Cim.](http://doi.org/10.1393/ncr/i2007-10025-7) **30**[, 387](http://doi.org/10.1393/ncr/i2007-10025-7) (2007), [\[arXiv:0711.2625\].](https://arxiv.org/abs/0711.2625)
- <span id="page-26-18"></span>[219] K. Kumericki, S. Liuti and H. Moutarde, [Eur. Phys. J.](http://doi.org/10.1140/epja/i2016-16157-3) **A52**[, 6, 157](http://doi.org/10.1140/epja/i2016-16157-3) (2016), [\[arXiv:1602.02763\].](https://arxiv.org/abs/1602.02763)
- <span id="page-26-19"></span>[220] M. Burkardt, [Int. J. Mod. Phys.](http://doi.org/10.1142/S0217751X03012370) **A18**[, 173](http://doi.org/10.1142/S0217751X03012370) (2003), [\[hep-ph/0207047\].](https://arxiv.org/abs/hep-ph/0207047)
- <span id="page-26-20"></span>[221] M. Diehl, [Eur. Phys. J.](http://doi.org/10.1007/s10052-002-1016-9) **C25**[, 223](http://doi.org/10.1007/s10052-002-1016-9) (2002), [Erratum: Eur. Phys. J.C31,277(2003)], [\[hep](https://arxiv.org/abs/hep-ph/0205208)[ph/0205208\].](https://arxiv.org/abs/hep-ph/0205208)
- <span id="page-26-21"></span>[222] A. V. Efremov and A. V. Radyushkin, [Phys. Lett.](http://doi.org/10.1016/0370-2693(80)90869-2) **94B**[, 245](http://doi.org/10.1016/0370-2693(80)90869-2) (1980).
- <span id="page-26-22"></span>[223] G. P. Lepage and S. J. Brodsky, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.22.2157) **D22**[, 2157](http://doi.org/10.1103/PhysRevD.22.2157) (1980).
- <span id="page-26-23"></span>[224] A. V. Belitsky, A. Freund and D. Mueller, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(00)01129-1) **[B493](http://doi.org/10.1016/S0370-2693(00)01129-1)**, 341 (2000), [\[hep-ph/0008005\].](https://arxiv.org/abs/hep-ph/0008005)
- [225] A. V. Belitsky, A. Freund and D. Mueller, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(00)00012-2) **[B574](http://doi.org/10.1016/S0550-3213(00)00012-2)**, 347 (2000), [\[hep-ph/9912379\].](https://arxiv.org/abs/hep-ph/9912379)
- <span id="page-26-25"></span><span id="page-26-24"></span>[226] V. M. Braun *et al.*, [JHEP](http://doi.org/10.1007/JHEP06(2017)037) **06**[, 037](http://doi.org/10.1007/JHEP06(2017)037) (2017), [\[arXiv:1703.09532\].](https://arxiv.org/abs/1703.09532)
- [227] A. V. Radyushkin, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.59.014030) **D59**[, 014030](http://doi.org/10.1103/PhysRevD.59.014030) (1999), [\[hep-ph/9805342\].](https://arxiv.org/abs/hep-ph/9805342)

- <span id="page-27-0"></span>[228] A. V. Radyushkin, [Phys. Lett.](http://doi.org/10.1016/S0370-2693(98)01584-6) **[B449](http://doi.org/10.1016/S0370-2693(98)01584-6)**, 81 (1999), [\[hep-ph/9810466\].](https://arxiv.org/abs/hep-ph/9810466)
- <span id="page-27-1"></span>[229] K. Kumerički and D. Mueller, [Nucl. Phys.](http://doi.org/10.1016/j.nuclphysb.2010.07.015) **[B841](http://doi.org/10.1016/j.nuclphysb.2010.07.015)**, 1 (2010), [\[arXiv:0904.0458\].](https://arxiv.org/abs/0904.0458)
- <span id="page-27-2"></span>[230] N. d'Hose, S. Niccolai and A. Rostomyan, [Eur. Phys. J.](http://doi.org/10.1140/epja/i2016-16151-9) **A52**[, 6, 151](http://doi.org/10.1140/epja/i2016-16151-9) (2016).
- <span id="page-27-3"></span>[231] M. Guidal, H. Moutarde and M. Vanderhaeghen, [Rept. Prog. Phys.](http://doi.org/10.1088/0034-4885/76/6/066202) **76**[, 066202](http://doi.org/10.1088/0034-4885/76/6/066202) (2013), [\[arXiv:1303.6600\].](https://arxiv.org/abs/1303.6600)
- <span id="page-27-4"></span>[232] M. Anselmino, M. Guidal and P. Rossi, [The European Physical Journal A](http://doi.org/10.1140/epja/i2016-16164-4) **52**[, 6, 149](http://doi.org/10.1140/epja/i2016-16164-4) (2016), ISSN 1434-601X, URL <https://doi.org/10.1140/epja/i2016-16164-4>.
- <span id="page-27-5"></span>[233] P. J. Mulders and R. D. Tangerman, [Nucl. Phys.](http://doi.org/10.1016/S0550-3213(96)00648-7) **[B461](http://doi.org/10.1016/S0550-3213(96)00648-7)**, 197 (1996), [Erratum: Nucl. Phys.B484,538(1997)], [\[hep-ph/9510301\].](https://arxiv.org/abs/hep-ph/9510301)
- <span id="page-27-6"></span>[234] D. Boer and P. J. Mulders, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.57.5780) **D57**[, 5780](http://doi.org/10.1103/PhysRevD.57.5780) (1998), [\[hep-ph/9711485\].](https://arxiv.org/abs/hep-ph/9711485)
- <span id="page-27-7"></span>[235] D. W. Sivers, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.41.83) **[D41](http://doi.org/10.1103/PhysRevD.41.83)**, 83 (1990).
- <span id="page-27-8"></span>[236] M. Bury, A. Prokudin and A. Vladimirov, [JHEP](http://doi.org/10.1007/JHEP05(2021)151) **05**[, 151](http://doi.org/10.1007/JHEP05(2021)151) (2021), [\[arXiv:2103.03270\].](https://arxiv.org/abs/2103.03270)
- <span id="page-27-9"></span>[237] J. C. Collins, [Nucl. Phys.](http://doi.org/10.1016/0550-3213(93)90262-N) **[B396](http://doi.org/10.1016/0550-3213(93)90262-N)**, 161 (1993), [\[hep-ph/9208213\].](https://arxiv.org/abs/hep-ph/9208213)
- <span id="page-27-10"></span>[238] X. Ji, J. Ma and F. Yuan, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.71.034005) **D71**[, 034005](http://doi.org/10.1103/PhysRevD.71.034005) (2005), [\[hep-ph/0404183\].](https://arxiv.org/abs/hep-ph/0404183)
- [239] J. Collins, Foundations of perturbative QCD Camb. Monogr. Part. Phys. Nucl. Phys. Cosmol. 32 (2011) 1-624 and references therein.
- [240] S. M. Aybat and T. C. Rogers, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.83.114042) **D83**[, 114042](http://doi.org/10.1103/PhysRevD.83.114042) (2011), [\[arXiv:1101.5057\].](https://arxiv.org/abs/1101.5057)
- [241] M. G. Echevarria, A. Idilbi and I. Scimemi, [JHEP](http://doi.org/10.1007/JHEP07(2012)002) **07**[, 002](http://doi.org/10.1007/JHEP07(2012)002) (2012), [\[arXiv:1111.4996\].](https://arxiv.org/abs/1111.4996)
- [242] M. G. A. Buffing, A. Mukherjee and P. J. Mulders, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.88.054027) **D88**[, 054027](http://doi.org/10.1103/PhysRevD.88.054027) (2013), [\[arXiv:1306.5897\].](https://arxiv.org/abs/1306.5897)
- <span id="page-27-11"></span>[243] T. C. Rogers and P. J. Mulders, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.81.094006) **D81**[, 094006](http://doi.org/10.1103/PhysRevD.81.094006) (2010), [\[arXiv:1001.2977\].](https://arxiv.org/abs/1001.2977)
- <span id="page-27-12"></span>[244] A. Signori *et al.*, [JHEP](http://doi.org/10.1007/JHEP11(2013)194) **11**[, 194](http://doi.org/10.1007/JHEP11(2013)194) (2013), [\[arXiv:1309.3507\].](https://arxiv.org/abs/1309.3507)
- [245] M. Anselmino *et al.*, [JHEP](http://doi.org/10.1007/JHEP04(2014)005) **04**[, 005](http://doi.org/10.1007/JHEP04(2014)005) (2014), [\[arXiv:1312.6261\].](https://arxiv.org/abs/1312.6261)
- [246] U. D'Alesio *et al.*, [JHEP](http://doi.org/10.1007/JHEP11(2014)098) **11**[, 098](http://doi.org/10.1007/JHEP11(2014)098) (2014), [\[arXiv:1407.3311\].](https://arxiv.org/abs/1407.3311)
- [247] P. Sun *et al.*, [Int. J. Mod. Phys.](http://doi.org/10.1142/S0217751X18410063) **A33**[, 11, 1841006](http://doi.org/10.1142/S0217751X18410063) (2018), [\[arXiv:1406.3073\].](https://arxiv.org/abs/1406.3073)
- [248] V. Bertone, I. Scimemi and A. Vladimirov, [JHEP](http://doi.org/10.1007/JHEP06(2019)028) **06**[, 028](http://doi.org/10.1007/JHEP06(2019)028) (2019), [\[arXiv:1902.08474\].](https://arxiv.org/abs/1902.08474)
- [249] I. Scimemi and A. Vladimirov, [JHEP](http://doi.org/10.1007/JHEP06(2020)137) **06**[, 137](http://doi.org/10.1007/JHEP06(2020)137) (2020), [\[arXiv:1912.06532\].](https://arxiv.org/abs/1912.06532)
- [250] M. G. Echevarria, Z.-B. Kang and J. Terry, [JHEP](http://doi.org/10.1007/JHEP01(2021)126) **01**[, 126](http://doi.org/10.1007/JHEP01(2021)126) (2021), [\[arXiv:2009.10710\].](https://arxiv.org/abs/2009.10710)
- [251] A. Bacchetta *et al.*, [Phys. Lett. B](http://doi.org/10.1016/j.physletb.2022.136961) **827**[, 136961](http://doi.org/10.1016/j.physletb.2022.136961) (2022), [\[arXiv:2004.14278\].](https://arxiv.org/abs/2004.14278)
- <span id="page-27-13"></span>[252] A. Bacchetta *et al.* (MAP (Multi-dimensional Analyses of Partonic distributions)), [JHEP](http://doi.org/10.1007/JHEP10(2022)127) **[10](http://doi.org/10.1007/JHEP10(2022)127)**, [127](http://doi.org/10.1007/JHEP10(2022)127) (2022), [\[arXiv:2206.07598\].](https://arxiv.org/abs/2206.07598)
- <span id="page-27-14"></span>[253] J. O. Gonzalez-Hernandez *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.98.114005) **D98**[, 11, 114005](http://doi.org/10.1103/PhysRevD.98.114005) (2018), [\[arXiv:1808.04396\].](https://arxiv.org/abs/1808.04396)
- [254] A. Bacchetta *et al.*, [Phys. Rev.](http://doi.org/10.1103/PhysRevD.100.08) **D100**[, 1, 014018](http://doi.org/10.1103/PhysRevD.100.08) (2019), [\[arXiv:1901.06916\].](https://arxiv.org/abs/1901.06916)
- <span id="page-27-15"></span>[255] M. Bury *et al.*, [JHEP](http://doi.org/10.1007/JHEP10(2022)118) **10**[, 118](http://doi.org/10.1007/JHEP10(2022)118) (2022), [\[arXiv:2201.07114\].](https://arxiv.org/abs/2201.07114)
- <span id="page-27-16"></span>[256] R. Angeles-Martinez *et al.*, [Acta Phys. Polon.](http://doi.org/10.5506/APhysPolB.46.2501) **B46**[, 12, 2501](http://doi.org/10.5506/APhysPolB.46.2501) (2015), [\[arXiv:1507.05267\].](https://arxiv.org/abs/1507.05267)
- <span id="page-27-17"></span>[257] A. Bacchetta *et al.*, [Phys. Lett.](http://doi.org/10.1016/j.physletb.2018.11.002) **[B788](http://doi.org/10.1016/j.physletb.2018.11.002)**, 542 (2019), [\[arXiv:1807.02101\].](https://arxiv.org/abs/1807.02101)
- <span id="page-27-18"></span>[258] M. Diehl, [Eur. Phys. J.](http://doi.org/10.1140/epja/i2016-16149-3) **A52**[, 6, 149](http://doi.org/10.1140/epja/i2016-16149-3) (2016), [\[arXiv:1512.01328\].](https://arxiv.org/abs/1512.01328)
- [259] A. Bacchetta, [Eur. Phys. J.](http://doi.org/10.1140/epja/i2016-16163-5) **A52**[, 6, 163](http://doi.org/10.1140/epja/i2016-16163-5) (2016).
- <span id="page-27-20"></span>[260] http://hepdata.cedar.ac.uk/pdfs.
- <span id="page-27-19"></span>[261] I. Scimemi, [Adv. High Energy Phys.](http://doi.org/10.1155/2019/3142510) **2019**[, 3142510](http://doi.org/10.1155/2019/3142510) (2019), [\[arXiv:1901.08398\].](https://arxiv.org/abs/1901.08398)

<span id="page-28-0"></span>![](_page_28_Figure_2.jpeg)

Figure 18.10: The proton structure function  $F_2^p$  measured in electromagnetic scattering of electrons and positrons on protons, and for electrons/positrons (SLAC,HERMES,JLAB) and muons (BCDMS, E665, NMC) on a fixed target. Statistical and systematic errors added in quadrature are shown. The H1+ZEUS combined values are obtained from the measured reduced cross section and converted to  $F_2^p$  with a HERAPDF NLO fit, for all measured points where the predicted ratio of  $F_2^p$  to reduced cross-section was within 10% of unity. The data are plotted as a function of  $Q^2$  in bins of fixed x. Some points have been slightly offset in  $Q^2$  for clarity. The H1+ZEUS combined binning in x is used in this plot; all other data are rebinned to the x values of these data. For the purpose of plotting,  $F_2^p$  has been multiplied by  $F_2^p$ , where  $F_2^p$  is the number of the  $F_2^p$  bin, ranging from  $F_2^p$  bins of fixed  $F_2^p$  has been multiplied by  $F_2^p$  bins of the  $F_2^p$  bins of these data. For the purpose of plotting,  $F_2^p$  has been multiplied by  $F_2^p$  bins of the  $F_2^p$  bins of these data with  $F_2^p$  bins of the  $F_2^p$  bins of these data. For the purpose of plotting,  $F_2^p$  bins been multiplied by  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of the  $F_2^p$  bins of t

References: H1 and ZEUS—H. Abramowicz et al., Eur. Phys. J. C75, 580 (2015) (for both data and HERAPDF parameterization); BCDMS—A.C. Benvenuti et al., Phys. Lett. B223, 485 (1989) (as given in [260]) E665—M.R. Adams et al., Phys. Rev. D54, 3006 (1996); NMC—M. Arneodo et al., Nucl. Phys. B483, 3 (1997); SLAC—L.W. Whitlow et al., Phys. Lett. B282, 475 (1992); HERMES—A. Airapetian et al., JHEP 1105, 126 (2011); JLAB—Y. Liang et al., Jefferson Lab Hall C E94-110 collaboration, nuclex/0410027, M.E. Christy et al., Jefferson Lab Hall C E94-110 Collaboration, Phys. Rev. C70, 015206 (2004), S. Malace et al., Jefferson Lab Hall C E00-116 Collaboration, Phys. Rev. C80, 035207 (2009), V. Tvaskis et al., Jefferson Lab Hall C E99-118 Collaboration, Phys. Rev. C81, 055207 (2010), M. Osipenko et al., Jefferson Lab Hall B CLAS6 Collaboration, Phys. Rev. D67, 092001 (2003).

![](_page_29_Figure_2.jpeg)

Figure 18.11: The deuteron structure function  $F_2^d$  measured in electromagnetic scattering of electrons/positrons (SLAC,HERMES,JLAB) and muons (BCDMS, E665, NMC) on a fixed target, shown as a function of  $Q^2$  for bins of fixed x. Statistical and systematic errors added in quadrature are shown. For the purpose of plotting,  $F_2^d$  has been multiplied by  $2^{i_x}$ , where  $i_x$  is the number of the x bin, ranging from 1 (x = 0.85) to 29 (x = 0.00076). Only data with  $W^2 > 3.5 \text{ GeV}^2$  is included. Plot from CJ collaboration (Shujie Li – private communication) References: BCDMS—A.C. Benvenuti et al., Phys. Lett. B237, 592 (1990). E665, NMC, SLAC,HERMES—same references as Fig. 18.10; JLAB—S. Malace et al., Jefferson Lab Hall C E00-116 Collaboration, Phys. Rev. C80, 035207 (2009), V. Tvaskis et al., Jefferson Lab Hall C E03-103 Collaboration, Phys. Rev. C81, 055207 (2010), J. Seely (MIT, LNS) et al., Jefferson Lab Hall C E03-103 Collaboration, Phys. Rev. Lett. 103, 202301 (2009), M. Osipenko et al., Jefferson Lab Hall B CLAS6 Collaboration, Phys. Rev. C73, 045205 (2006).

<span id="page-30-0"></span>![](_page_30_Figure_2.jpeg)

Figure 18.12: a) The deuteron structure function  $F_2$  measured in deep inelastic scattering of muons on a fixed target (NMC) is compared to the structure function  $F_2$  from neutrino-iron scattering (CCFR and NuTeV) using  $F_2^{\mu} = (5/18)F_2^{\nu} - x(s+\bar{s})/6$ , where heavy-target effects have been taken into account. The data are shown versus  $Q^2$ , for bins of fixed x. The NMC data have been rebinned to CCFR and NuTeV x values. For the purpose of plotting, a constant  $c(x) = 0.05i_x$  is added to  $F_2$ , where  $i_x$  is the number of the x bin, ranging from 0 (x = 0.75) to 7 (x = 0.175). For  $i_x = 8$  (x = 0.125) to 11 (x = 0.015), 2c(x) has been added. References: NMC—M. Arneodo et al., Nucl. Phys. B483, 3 (1997); CCFR/NuTeV—U.K. Yang et al., Phys. Rev. Lett. 86, 2741 (2001); NuTeV—M. Tzanov et al., Phys. Rev. D74, 012008 (2006). b) The proton structure function  $F_2^p$  mostly at small x and  $Q^2$ , measured in electromagnetic scattering of electrons and positrons (H1, ZEUS), electrons (SLAC), and muons (BCDMS, NMC) on protons. Lines are ZEUS Regge and HERAPDF parameterizations for lower and higher  $Q^2$ , respectively. The width of the bins can be up to 10% of the stated  $Q^2$ . Some points have been slightly offset in x for clarity. The H1+ZEUS combined values for  $Q^2 \geq 3.5 \text{ GeV}^2$  are obtained from the measured reduced cross section and converted to  $F_2^p$  with a HERAPDF NLO fit, for all measured points where the predicted ratio of  $F_2^p$  to reduced crosssection was within 10% of unity. A turn-over is visible in the low-x points at medium  $Q^2$  (3.5 GeV<sup>2</sup> and 6 GeV<sup>2</sup>) for the H1+ZEUS combined values. In order to obtain  $F_2^p$  from the measured reduced cross-section,  $F_L$  must be estimated; for the points shown, this estimate is obtained from HERAPDF2.0. No  $F_L$  value consistent with the HERA data can eliminate the turn-over. This may indicate that at low x and  $Q^2$  there are contributions to the structure functions that cannot be described in standard DGLAP evolution. References: H1 and ZEUS—F.D. Aaron et al., JHEP 1001, 109 (2010) (data for  $Q^2 < 3.5 \text{ GeV}^2$ ), H. Abramowicz et al., Eur. Phys. J. C75, 580 (2015) (data for  $Q^2 > 3.5 \text{ GeV}^2$  and HERAPDF parameterization); ZEUS—J. Breitweg et al., Phys. Lett. B487, 53 (2000) (ZEUS Regge parameterization); BCDMS, NMC, SLAC—same references as Fig. 18.10. Statistical and systematic errors added in quadrature are shown for both plots.

![](_page_31_Figure_2.jpeg)

**Figure 18.13:** a) The charm-quark structure function *F cc* 2 (*x*), i.e. that part of the inclusive structure function *F p* 2 arising from the production of charm quarks, measured in electromagnetic scattering of positrons on protons (H1, ZEUS) (the values are obtained from the measured reduced cross section and converted to *F cc* 2 using the PDFs from the MMHT NNLO fit) and muons on iron (EMC). For the purpose of plotting, a constant *c*(*Q*) = 0*.*07*i<sup>Q</sup>* 1*.*7 is added to *F cc* <sup>2</sup> where *i<sup>Q</sup>* is the number of the *Q*<sup>2</sup> bin, ranging from 1 (*Q*<sup>2</sup> = 2*.*5 GeV<sup>2</sup> ) to 12 (*Q*<sup>2</sup> = 2000 GeV<sup>2</sup> ). References: **H1 and ZEUS run I +II combination**—H. Abramowicz *et al.*, Eur. Phys. J. **C78**, 473 (2018); **EMC**—J.J. Aubert *et al.*, Nucl. Phys. **B213**, 31 (1983). b) The bottom-quark structure function *F bb* 2 (*x*). For the purpose of plotting, a constant *c*(*Q*) = 0*.*01*i* 1*.*6 *<sup>Q</sup>* is added to *F bb* <sup>2</sup> where *i<sup>Q</sup>* is the number of the *Q*<sup>2</sup> bin, ranging from 1 (*Q*<sup>2</sup> = 2*.*5 GeV<sup>2</sup> ) to 12 (*Q*<sup>2</sup> = 2000 GeV<sup>2</sup> ). References: **H1 and ZEUS run I combination**—H. Abramowicz *et al.*, Eur. Phys. J. **C78**, 473 (2018).

For both plots, statistical and systematic errors added in quadrature are shown. The data are given as a function of *x* in bins of *Q*<sup>2</sup> . Points may have been slightly offset in *x* for clarity. Some data have been rebinned to common *Q*<sup>2</sup> values. Also shown is the MMHT2014 parameterization given at several *Q*<sup>2</sup> values (L. A. Harland-Lang *et al.*, Eur. Phys. J. **C75**, 204 (2015)).

![](_page_32_Figure_2.jpeg)

Highre 18.14. The structure function  $xF_3$  in heasthed in electroweak scattering of a) electrons on protons (H1 and ZEUS) and b) muons on carbon (BCDMS). The line in a) is the HERAPDF parameterization. References: H1 and ZEUS—H. Abramowicz  $et\ al.$ , Eur. Phys. J. C75, 580 (2015) (for both data and HERAPDF parameterization); BCDMS—A. Argento  $et\ al.$ , Phys. Lett. B140, 142 (1984). c) The structure function  $xF_3$  of the nucleon measured in  $\nu$ -Fe scattering. The data are plotted as a function of  $Q^2$  in bins of fixed x. For the purpose of plotting, a constant  $c(x) = 0.5(i_x - 1)$  is added to  $xF_3$ , where  $i_x$  is the number of the x bin as shown in the plot. The NuTeV and CHORUS points have been shifted to the nearest corresponding x bin as given in the plot and slightly offset in  $Q^2$  for clarity. References: CCFR—W.G. Seligman  $et\ al.$ , Phys. Rev. Lett. 79, 1213 (1997); NuTeV—M. Tzanov  $et\ al.$ , Phys. Rev. D74, 012008 (2006); CHORUS—G. Önengüt  $et\ al.$ , Phys. Lett. B632, 65 (2006).

![](_page_33_Figure_2.jpeg)

Figure 18.15: Top panels: The longitudinal structure function  $F_L$  as a function of x in bins of fixed  $Q^2$  measured on the proton (except for the SLAC data which also contain deuterium data). BCDMS, NMC, and SLAC results are from measurements of R (the ratio of longitudinal to transverse photon absorption cross sections) which are converted to  $F_L$  by using the BDCMS parameterization of  $F_2$  (A.C. Benvenuti et al., Phys. Lett. B223, 485 (1989)). It is assumed that the  $Q^2$  dependence of the fixed-target data is small within a given  $Q^2$  bin. Some of the other data may have been rebinned to common  $Q^2$  values. Some points have been slightly offset in x for clarity. Also shown is the MSTW2008 parameterization given at three  $Q^2$  values (A.D. Martin et al., Eur. Phys. J. C63, 189 (2009)). References: H1—V. Andreev et al., Eur. Phys. J. C74, 2814 (2014); ZEUS—S. Chekanov et al., Phys. Lett. B682, 8 (2009); H. Abramowicz et al., Phys. Rev. D90, 072002 (2014); BCDMS—A. Benvenuti et al., Phys. Lett. B223, 485 (1989); NMC—M. Arneodo et al., Nucl. Phys. B483, 3 (1997); SLAC—L.W. Whitlow et al., Phys. Lett. B250, 193 (1990) and numerical values from the thesis of L.W. Whitlow (SLAC-357).

Bottom panel: The longitudinal structure function  $F_L$  as a function of  $Q^2$ . Some points have been slightly offset in  $Q^2$  for clarity. References: **H1**—V. Andreev *et al.*, Eur. Phys. J. **C74**, 2814 (2014); **ZEUS**—H. Abramowicz et al., Phys. Rev. **D90**, 072002 (2014).

The results shown in the bottom plot require the assumption of the validity of the QCD form for the  $F_2$  structure function in order to extract  $F_L$ . Statistical and systematic errors added in quadrature are shown for both plots.

<span id="page-34-0"></span>![](_page_34_Figure_2.jpeg)

Figure 18.16: World data on the spin-dependent structure function  $g_1^p$  as a function of  $Q^2$  for various values of x The lines represent the  $Q^2$  dependence for each value of x, as determined from a NLO QCD fit. The dashed ranges represent the region with  $W^2 < 10 \text{ (GeV/}c^2)^2$ . References: EMC—J. Ashman et al., Phys. Lett. B206, 363 (1988); Nucl. Phys. B328, 1 (1989); E143—K. Abe et al., Phys. Rev. D58, 112003 (1998); SMC—B. Adeva et al., Phys. Rev. D58, 112001 (1998); HERMES—A. Airapetian et al., Phys. Rev. D75, 012007 (2007); E155—P.L. Anthony et al., Phys. Lett. B493, 19 (2000); COMPASS—M.G. Alekseev et al., Phys. Lett. B690, 466 (2010), C. Adolph, et al., Phys. Lett. B753, 18 (2016); CLAS—K.V. Dharmawardane et al., Phys. Lett. B641, 11 (2006) (which also includes resonance region data not shown on this plot — there is also low  $W^2$  CLAS data in Y. Prok et al., Phys. Rev. C90, 025212 (2014) and N. Guler et al., Phys. Rev. C92, 055201 (2015)).

<span id="page-35-0"></span>![](_page_35_Figure_2.jpeg)

Figure 18.17: World data on the spin-dependent structure function  $g_1^d$  as a function of  $Q^2$  for various values of x The lines represent the  $Q^2$  dependence for each value of x, as determined from a NLO QCD fit. The dashed ranges represent the region with  $W^2 < 10 \text{ (GeV/c}^2)^2$ . CLAS—K.V. Dharmawardane et al., Phys. Lett. B641, 11 (2006) HERMES—A. Airapetian et al., Phys. Rev. D75, 012007 (2007); SMC—B. Adeva et al., Phys. Rev. D58, 112001 (1998); E155—P.L. Anthony et al., Phys. Lett. B463, 339 (1999); E143—K. Abe et al., Phys. Rev. D58, 112003 (1998); COMPASS—C. Adolph, et al., Phys. Lett. B769, 34 (2017);

<span id="page-36-0"></span>![](_page_36_Figure_2.jpeg)

Figure 18.18: The hadronic structure function of the photon  $F_2^{\gamma}$  divided by the fine structure constant α measured in  $e^+e^-$  scattering, shown as a function of  $Q^2$  for bins of x. Data points have been shifted to the nearest corresponding x bin as given in the plot. Some points have been offset in  $Q^2$  for clarity. Statistical and systematic errors added in quadrature are shown. For the purpose of plotting, a constant  $c(x) = 1.5i_x$  is added to  $F_2^{\gamma}/\alpha$  where  $i_x$  is the number of the x bin, ranging from 1 (x = 0.0055) to 8 (x = 0.9). References: ALEPH–R. Barate et al., Phys. Lett. B458, 152 (1999); A. Heister et al., Eur. Phys. J. C30, 145 (2003); DELPHI–P. Abreu et al., Z. Phys. C69, 223 (1995); L3–M. Acciarri et al., Phys. Lett. B436, 403 (1998); M. Acciarri et al., Phys. Lett. B447, 147 (1999); M. Acciarri et al., Phys. Lett. B483, 373 (2000); OPAL–A. Ackerstaff et al., Phys. Lett. B411, 387 (1997); A. Ackerstaff et al., Z. Phys. C74, 33 (1997); G. Abbiendi et al., Eur. Phys. J. C18, 15 (2000); G. Abbiendi et al., Phys. Lett. B533, 207 (2002) (note that there is overlap of the data samples in these last two papers); AMY–S.K. Sahu et al., Phys. Lett. B346, 208 (1995); T. Kojima et al., Phys. Lett. B400, 395 (1997); JADE–W. Bartel et al., Z. Phys. C24, 231 (1984); PLUTO–C. Berger et al., Phys. Lett. 142B, 111 (1984); C. Berger et al., Nucl. Phys. B281, 365 (1987); TASSO–M. Althoff et al., Z. Phys. C31, 527 (1986); TOPAZ–K. Muramatsu et al., Phys. Lett. B332, 477 (1994); TPC/Two Gamma–H. Aihara et al., Z. Phys. C34, 1 (1987).