## Revealing proton shape fluctuations with incoherent diffraction at high energy

Heikki M¨antysaari and Bj¨orn Schenke Physics Department, Brookhaven National Laboratory, Upton, NY 11973, USA

The differential cross section of exclusive diffractive vector meson production in electron proton collisions carries important information on the geometric structure of the proton. More specifically, the coherent cross section as a function of the transferred transverse momentum is sensitive to the size of the proton, while the incoherent, or proton dissociative cross section is sensitive to fluctuations of the gluon distribution in coordinate space. We show that at high energies the experimentally measured coherent and incoherent cross sections for the production of J/Ψ mesons are very well reproduced within the color glass condensate framework when strong geometric fluctuations of the gluon distribution in the proton are included. For ρ meson production we also find reasonable agreement. We study in detail the dependence of our results on various model parameters, including the average proton shape, analyze the effect of saturation scale and color charge fluctuations and constrain the degree of geometric fluctuations.

#### PACS numbers: 24.85.+p, 13.60.-r

#### I. INTRODUCTION

Measuring the partonic structure of the proton has been one of the main motivations of deeply inelastic scattering (DIS) experiments. To date, the most precise data on the proton structure is provided by the H1 and ZEUS experiments at HERA [1, 2]. Fundamentally, one is interested in the Wigner distributions of the proton's constituents [3], which carry information on both the three dimensional momentum and spatial distributions. It is not known how to measure this distribution itself, such that typically some of the variables are integrated out. Most commonly both the spatial structure and transverse momentum are integrated out, yielding ordinary parton distribution functions (pdfs), only depending on the longitudinal momentum fraction x. If only either the transverse momentum or the spatial coordinates are integrated out, one obtains generalized parton distribution functions (GPDs) [4–7] or transverse momentum dependent parton distribution functions (TMDs) [8–14], respectively. These pdfs also carry detailed information on the angular momentum carried by partons, including their spin and orbital motion.

In this work we are interested in an additional piece of information, namely how much the spatial distribution of gluons within the proton fluctuates event-by-event. This information is experimentally accessible via exclusive incoherent diffractive vector meson production, namely scattering events that produce a single vector meson and, separated by a rapidity gap, remnants of the dissociated proton. Together with data on coherent diffractive vector meson production, in which the proton stays intact, the shape and fluctuations of the gluon distribution in the proton can be constrained [15].

We are particularly interested in large center of mass energies, where we are sensitive to the small x part of the constituents in the proton. We will thus work in the framework of the color glass condensate (CGC) effective theory [16, 17] of quantum chromodynamics (QCD). Within the CGC framework, experimental data

on the proton structure function have been well reproduced [18–20]. Furthermore, a large variety of observables in high energy collisions, including, for example, single [20–25] and double inclusive [26–28] particle production in proton-proton and proton-nucleus collisions, can be described. The CGC framework has also been extensively applied to study diffractive DIS in current and future experiments, including ultra-peripheral heavy ion and proton-nucleus collisions [29–37]. Incoherent diffraction with proton targets, however, has only been studied in a few publications [38, 39]. The importance of significant geometric fluctuations in the description of the incoherent cross section measured at HERA was pointed out in a recent Letter [15], on which we expand in this work. In the near future, before the realization of an Electron Ion Collider [40, 41], new data in a wide range of photonnucleon center-of-mass energies can be obtained from ultra-peripheral heavy ion [42–45] and proton-nucleus collisions [46, 47].

Besides its fundamental interest, the fluctuating geometric shape of the proton is potentially an important ingredient for describing high multiplicity proton-proton and proton-nucleus collisions. Many collective phenomena have been observed in such collisions [48–51] (see also Ref. [52] for a recent review). One possible explanation for such collectivity are strong final state interactions, which are responsible for the generation of anisotropic flow in heavy ion collisions. They can be modeled by applying hydrodynamic simulations [53]. A successful description of the experimental data in p+A collisions by hydrodynamic models with sophisticated initial states, requires knowledge of the proton's initial state geometry and its fluctuations [54]. Various analyses of geometric and interaction strength (equivalent to proton size) fluctuations in p+p and p+A collisions have been performed in the literature [55–60]. To really test the physical picture of hydrodynamic behavior in small collision systems, it is necessary to constrain proton shape fluctuations from other data than that from p+A (or p+p) collisions themselves, which will be done in this work.

![](_page_1_Picture_1.jpeg)

FIG. 1: Kinematics of diffractive deep inelastic scattering. The "zigzag" line represents pomeron exchange between the target and the photon.

This paper is organized as follows. In Sec. II we present the calculation of diffractive vector meson production cross sections in the CGC framework. Various phenomenological corrections to the cross sections are analyzed in Sec. III. Geometric fluctuations are implemented in Sec. IV and saturation scale fluctuations in Sec. V. The numerical results are shown in Sec. VI. In the appendices we show the quantitative effect of the phenomenological corrections and study various parameter dependencies in more detail.

## II. DIFFRACTIVE DIS IN THE DIPOLE PICTURE

We study the exclusive production of a vector meson V with momentum  $P_V$  in deeply inelastic scattering of leptons from protons:

$$l(\ell) + p(P) \to l'(\ell') + p'(P') + V(P_V)$$
. (1)

Here  $\ell$  and  $\ell'$  are the lepton momenta and P and P' are the proton momenta before and after the scattering, respectively. The kinematics are illustrated in Fig. 1. The Lorentz invariant quantities that characterize the scattering process are

$$Q^2 \equiv -q^2 = -(\ell - \ell')^2 \tag{2}$$

$$t \equiv -(P' - P)^2 \tag{3}$$

$$x_{\mathbb{P}} \equiv \frac{(P - P') \cdot q}{P \cdot q} = \frac{M^2 + Q^2 - t}{W^2 + Q^2 - m_N^2}.$$
 (4)

Here  $m_N$  is the proton mass, M is the mass of the produced vector meson and  $W^2 = (P+q)^2$  is the total center-of-mass energy squared of the virtual photon-proton scattering. The fraction of the longitudinal momentum of the proton transferred to the vector meson is  $x_{\mathbb{P}}$ , where  $\mathbb{P}$  stands for 'pomeron'. The relation to the pomeron comes from the fact that in diffractive processes no color is exchanged between the proton and the produced system. This means that there are no color strings between

them, leading to a rapidity gap, i.e., a region in rapidity with no produced particles, which is used experimentally to identify diffractive events. The scattered proton p' can either remain intact or break up, leading to coherent and incoherent diffractive events, respectively.

In the Good-Walker picture [61], diffraction is described in terms of states that diagonalize the scattering matrix. At high energy, these states are the ones where a virtual photon fluctuates into a quark-antiquark dipole with fixed transverse separation and impact parameter, and with a particular configuration of the target. The cross section is obtained by averaging over target configurations. Performing the average on the level of the scattering amplitude is equivalent to assuming that the target remains intact (coherent diffraction), and the cross section is proportional to the average proton structure. On the other hand, averaging on the level of the cross section includes events in which the target breaks up, resulting in the total diffractive cross section. Subtracting the coherent contribution leaves us with only events where the target breaks up (incoherent diffraction), which is proportional to the variance of the target profile, see e.g. Refs. [33, 62–64]. For a pedagogical discussion of diffractive scattering and its description within perturbative QCD, we refer the reader to Ref. [65].

Explicitly, in coherent diffraction the cross section can be written as [62, 66]

$$\frac{\mathrm{d}\sigma^{\gamma^* p \to V p}}{\mathrm{d}t} = \frac{1}{16\pi} \left| \langle \mathcal{A}^{\gamma^* p \to V p}(x_{\mathbb{P}}, Q^2, \mathbf{\Delta}) \rangle \right|^2, \quad (5)$$

where  $\mathcal{A}^{\gamma^*p\to Vp}(x_{\mathbb{P}},Q^2,\boldsymbol{\Delta})$  is the scattering amplitude. The incoherent cross section can be written as the variance [62] (see also e.g. Refs. [33, 34, 63, 64]):

$$\frac{\mathrm{d}\sigma^{\gamma^* p \to V p^*}}{\mathrm{d}t} = \frac{1}{16\pi} \left( \left\langle \left| \mathcal{A}^{\gamma^* p \to V p}(x_{\mathbb{P}}, Q^2, \boldsymbol{\Delta}) \right|^2 \right\rangle - \left| \left\langle \mathcal{A}^{\gamma^* p \to V p}(x_{\mathbb{P}}, Q^2, \boldsymbol{\Delta}) \right\rangle \right|^2 \right).$$
(6)

We note that in [67] and [68] the different averaging procedures leading to above expressions are discussed in the context of a semi-classical description of small x processes [69], such as the CGC picture employed in this work. In [68] it is shown that the total diffractive cross section is obtained by averaging over the target fields on the level of the cross section, while in [67] the coherent cross section is computed by averaging on the amplitude level as done in Eq. (5). Following Ref. [66], the scattering amplitude for diffractive vector meson production can be written as

$$\mathcal{A}_{T,L}^{\gamma^* p \to Vp}(x_{\mathbb{P}}, Q^2, \mathbf{\Delta}) = i \int d^2 \mathbf{r} \int d^2 \mathbf{b} \int \frac{dz}{4\pi} \times (\Psi^* \Psi_V)_{T,L}(Q^2, \mathbf{r}, z) \times e^{-i[\mathbf{b} - (1-z)\mathbf{r}] \cdot \mathbf{\Delta}} \frac{d\sigma_{\text{dip}}^p}{d^2 \mathbf{b}} (\mathbf{b}, \mathbf{r}, x_{\mathbb{P}}).$$
(7)

![](_page_2_Picture_1.jpeg)

FIG. 2: Photon-proton scattering in the dipole picture.

Here the momentum transfer in the scattering process is  $\Delta = (P' - P)_{\perp}$ , and throughout this work we assume  $|\Delta| \approx \sqrt{-t}$ . The subscripts T and L refer to transverse and longitudinal polarization of the virtual photon. Equation (7) has a simple interpretation which is also illustrated in Fig. 2: First, an incoming virtual photon fluctuates into a quark-antiquark dipole with transverse size  $\mathbf{r}$  and z being the longitudinal momentum fraction of the photon carried by the quark. This splitting is described by the virtual photon wave function  $\Psi$ , that can be calculated from perturbative QED (for a pedagogical discussion, see Ref. [70]). The color dipole then scatters off the target proton with the dipole-proton cross section  $\sigma_{\text{dip}}^{\text{p}}(\mathbf{b}, \mathbf{r}, x_{\mathbb{P}})$ , which we will discuss in detail below. This cross section is Fourier transformed into momentum space with the transverse momentum transfer  $\Delta$  being the Fourier conjugate to the center-of-mass of the dipole  $\mathbf{b} - (1-z)\mathbf{r}$  (in the transverse plane and relative to the proton's center), where **b** is the impact parameter [66]. Finally, the scattered dipole forms the final state particle, in this case a vector meson with wave function  $\Psi_V$ .

The vector meson wave function needs to be modeled. In this work we use the Boosted Gaussian wave function parametrization from Ref. [66] as it has been successfully used to describe HERA diffractive measurements. There are also other wave functions available in the literature, but the different wave functions mainly affect the overall normalization of the results without significantly changing the t dependence of the cross sections (see e.g. [66]). Thus, our main results are not sensitive to the uncertainties related to the vector meson wave functions.

The dipole cross section  $\sigma_{\rm dip}^{\rm p}$  is related to the forward elastic dipole-target scattering amplitude N via the optical theorem as

$$\frac{\mathrm{d}\sigma_{\mathrm{dip}}^{\mathrm{p}}}{\mathrm{d}^{2}\mathbf{b}}(\mathbf{b}, \mathbf{r}, x_{\mathbb{P}}) = 2N(\mathbf{b}, \mathbf{r}, x_{\mathbb{P}}). \tag{8}$$

In the CGC framework the energy (or  $x_{\mathbb{P}}$ ) evolution of the dipole amplitude is given by evolution equations that can be derived using perturbative techniques. Initial conditions for the small-x evolution (dipole amplitude at initial Bjorken-x) can be determined by performing a fit to the HERA DIS data as in Refs. [18, 20]. Then one can evolve the amplitude to smaller x by solving the JIMWLK [71–74] or Balitsky-Kovchegov (BK) [75, 76] evolution equation.

Alternatively, the small-x evolution can be modeled

along with the impact parameter and  $Q^2$  dependence of the dipole cross section, as done in the impact parameter dependent saturation (IPSat) model [77]. Because this approach has been very successful in describing a wide range of data from HERA and it avoids problems with the QCD evolution equations for finite size systems, such as the emergence of unphysical Coulomb tails [78, 79], we will use the IPSat model and the IP-Glasma model, [80, 81], where IPSat is coupled to classical Yang-Mills dynamics of the initial gluon fields.

In the IPs at model the dipole cross section is given by [77]

$$\frac{\mathrm{d}\sigma_{\mathrm{dip}}^{\mathrm{p}}}{\mathrm{d}^{2}\mathbf{b}}(\mathbf{b}, \mathbf{r}, x_{\mathbb{P}}) = 2 \left[ 1 - \exp\left(-\mathbf{r}^{2} F(x_{\mathbb{P}}, \mathbf{r}^{2}) T_{p}(\mathbf{b})\right) \right].$$
(9)

Here  $T_p(\mathbf{b})$  is the proton (transverse) spatial profile function which is assumed to be Gaussian:

$$T_p(\mathbf{b}) = \frac{1}{2\pi B_p} e^{-\mathbf{b}^2/(2B_p)}$$
. (10)

The function F is proportional to the DGLAP evolved gluon distribution [82],

$$F(x_{\mathbb{P}}, \mathbf{r}^2) = \frac{\pi^2}{2N_c} \alpha_{\mathrm{s}} \left(\mu^2\right) x_{\mathbb{P}} g\left(x_{\mathbb{P}}, \mu^2\right), \qquad (11)$$

with  $\mu^2 = \mu_0^2 + 4/\mathbf{r}^2$ . The proton width  $B_p$ ,  $\mu_0^2$  and the initial condition for the DGLAP evolution of the gluon distribution  $x_{\mathbb{P}}g$  are parameters of the model. They are obtained in Ref. [19] by performing fits to HERA DIS data. For consistency with these fits we shall use the same scale  $\mu^2$  also in the calculation of the diffractive cross section. See however Ref. [83] for a discussion of a possible |t| dependence of the scale choice in diffractive scattering. We use a charm mass of  $m_c = 1.4$  GeV.

In the IP-Glasma model [80] the dipole amplitude N can be calculated from the Wilson lines  $V(\mathbf{x})$  as

$$N\left(\mathbf{b} = \frac{\mathbf{x} + \mathbf{y}}{2}, \mathbf{r} = \mathbf{x} - \mathbf{y}, x_{\mathbb{P}}\right) = 1 - \frac{1}{N_{c}} \operatorname{Tr}\left(V(\mathbf{x})V^{\dagger}(\mathbf{y})\right).$$
(12)

Here the  $x_{\mathbb{P}}$  dependence of the Wilson lines is left implicit. To get the Wilson lines, we first sample the color charges  $\rho^a(\mathbf{x})$  from a Gaussian distribution

$$\langle \rho^a(x^-, \mathbf{x}) \rho^b(y^-, \mathbf{y}) \rangle = g^2 \delta^{ab} \delta^{(2)}(\mathbf{x} - \mathbf{y}) \delta(x^- - y^-) \mu^2.$$
(13)

The color charge density  $g\mu$  is set to be proportional to the saturation scale  $Q_s(x_{\mathbb{P}},\mathbf{x})$  determined from the IPsat model. We treat the proportionality constant as a free parameter that mainly affects the overall normalization of our results. We will use  $Q_s = 0.7g^2\mu$  when we include geometric fluctuations of the proton and  $Q_s = 0.65g^2\mu$  without. For a more detailed discussion on the relation between the saturation scale and color charge density, we refer the reader to Ref. [84].

Solving the Yang-Mills equations for the gluon fields, one obtains

$$V(\mathbf{x}) = P \exp\left(-ig \int dx^{-} \frac{\rho(x^{-}, \mathbf{x})}{\nabla^{2} + m^{2}}\right).$$
 (14)

Here P indicates path ordering and m is an infrared cutoff. Its role is to suppress infrared long-distance Coulomb tails, and consequently it affects the proton size. Generally one expects  $m \sim \Lambda_{\rm QCD}$ , and unless otherwise noted we will use m=0.4 GeV. Sensitivity on the infrared cutoff m is discussed in Appendix C.

The path ordering is calculated by discretizing the expression in (14) as

$$V(\mathbf{x}) = \prod_{k=1}^{N_y} \exp\left(-ig\frac{\rho_k(\mathbf{x})}{\nabla^2 + m^2}\right). \tag{15}$$

This corresponds to dividing the longitudinal direction into  $N_y$  slices. The continuum limit is obtained by taking  $N_y \to \infty$ . In our calculations we use  $N_y = 100$ . We have checked that for  $N_y > 100$  our results remain unchanged.

Calculations are performed on a 2-dimensional lattice with transverse spacing  $a=0.02\,\mathrm{fm}$ . We have checked that smaller lattice spacings do not alter the results. For more details on the IP-Glasma framework, the reader is referred to Ref. [85].

As already discussed above, the coherent diffractive cross section is related to the Fourier transform of the dipole cross section  $\sigma_{\rm dip}^{\rm p}$  from coordinate space to momentum space (see Eqs. (5) and (7)). Thus, the coherent cross section as a function of |t| is directly related to the Fourier transform of the impact parameter profile of the proton. In the IPsat model the density profile is Gaussian, resulting in an approximately Gaussian spectrum in momentum space. The proton size can then be characterized by the diffractive slope  $B_D$  defined by fitting the coherent cross section by a function  $\sim e^{-B_D|t|}$  in the small |t| region. Notice that  $B_D$  is not exactly the  $B_p$ parameter in the IPsat model. The growth of the proton size (parameter  $B_D$ ) as a function of energy has been observed at HERA [86] and in ultra-peripheral collisions by the ALICE collaboration [46]. Because in the IPsat model the density profile is assumed to factorize from the gluon distribution function xg, it is not possible to explain this measured proton growth within this framework as the width of the Gaussian does not change when the overall normalization (gluon density) increases [66]. When performing explicit small x QCD evolution as done in [79] the growth of the proton with energy naturally emerges.

The incoherent cross section, on the other hand, is given by the variance of the scattering amplitude (see Eq. (6)). Thus, it is proportional to the event-by-event fluctuations of the proton density profile in coordinate space. As discussed in Ref. [62], at small |t| it is dominated by fluctuations of the overall proton density (in our case driven by the value of  $Q_s$  and possible color charge

fluctuations). As we will demonstrate, at larger |t|, the effect of these fluctuations is negligible compared to the contribution originating from the geometric fluctuations.

#### III. PHENOMENOLOGICAL CORRECTIONS

#### A. Real part of the diffractive amplitude

Derivation of the diffractive scattering amplitude (7) relies on an assumption that the dipole scattering amplitude is purely real and the diffractive amplitude imaginary. The real part of the amplitude can be taken into account by multiplying the calculated cross section by a factor  $(1+\beta^2)$ , where the ratio of real to imaginary parts of the scattering amplitude is [66]

$$\beta = \tan \frac{\pi \lambda}{2},\tag{16}$$

where

$$\lambda = \frac{\mathrm{d}\ln \mathcal{A}_{T,L}^{\gamma^* p \to V p}}{\mathrm{d}\ln 1/x_{\mathbb{P}}}.$$
 (17)

In our calculation this correction is calculated without any event-by-event fluctuations.

Because in the IP-Glasma framework the dipole amplitude has both real and imaginary parts, we do not include the real part correction when an IP-Glasma proton is used. However, we note that the contribution from the imaginary part of the dipole amplitude to the cross section is around 1%, significantly less than the correction  $\sim 10\%$  calculated from Eq. (16) in the kinematics relevant to this work (see Appendix A).

#### B. Skewedness correction

At lowest order the dipole-target scattering involves an exchange of two gluons, because there cannot be an exchange of color charge. The two gluons in the target are probed at different values of Bjorken x ( $x_1$  and  $x_2$  satisfying  $x_1 - x_2 = x_{\mathbb{P}}$ ). Because we calculate the imaginary part of the scattering amplitude, the dominant contribution is obtained when the intermediate propagators are close to the mass shell. Thus, the first gluon exchange has to bring the  $q\bar{q}$  dipole mass close to the mass of the produced vector meson. Then, there is only a significantly smaller longitudinal momentum fraction  $x_2$  left for the second gluon. The dominant kinematical regime is then  $x_2 \ll x_1 \approx x_{\mathbb{P}}$  [87–89].

In the IPsat model the collinear factorization gluon distribution  $x_{\mathbb{P}}g(x_{\mathbb{P}}, \mu^2)$  is corrected to correspond to the off-diagonal (or skewed) distribution, which depends on both  $x_1$  and  $x_2$ , by multiplying it by a skewedness factor  $R_g$  following the prescription of Ref. [66]:

$$R_g = 2^{2\lambda_g + 3} \frac{\Gamma(\lambda_g + 5/2)}{\sqrt{\pi} \Gamma(\lambda_g + 4)}$$
 (18)

with

$$\lambda_g = \frac{\mathrm{d} \ln x_{\mathbb{P}} g(x_{\mathbb{P}}, \mu^2)}{\mathrm{d} \ln 1/x_{\mathbb{P}}}.$$
 (19)

In the IP-Glasma model the gluon distribution function does not enter explicitly in the calculation of the diffractive scattering amplitude. In that case the skewedness correction is approximated by calculating its effect to the diffractive cross section within the IPsat model without geometrical fluctuations, and using the obtained correction factors to scale the calculated diffractive cross section.

Especially the skewedness correction is numerically important and needed to describe the HERA diffractive measurements. We will study the relative importance of these corrections in Appendix A.

#### IV. FLUCTUATING PROTON SHAPE

While the average (or root-mean-square) proton radius<sup>1</sup> is constrained relatively well, little is known about fluctuations in the proton's geometry. Here we explore several models for the fluctuating shape of the proton's gluon distribution and use experimental data on incoherent diffractive vector meson production to constrain the degree of fluctuations.

#### A. Constituent quark proton

The simplest profile we use to model proton event-byevent fluctuations is inspired by the constituent quark picture. Here, the large-x valence quarks can be thought of as sources of small-x gluons, emitted around the constituent quarks [79].

We implement this picture by sampling the constituent quarks' positions in the transverse plane relative to the origin, b<sup>i</sup> , from a Gaussian distribution with width Bqc. The angular distribution of quarks is assumed to be uniform and we neglect any possible correlations between the quark positions. The density profile of each constituent quark in the transverse plane is also assumed to be Gaussian

$$T_q(\mathbf{b}) = \frac{1}{2\pi B_q} e^{-\mathbf{b}^2/(2B_q)},$$
 (20)

with width parameter Bq. This corresponds to the replacement

$$T_p(\mathbf{b}) \to \frac{1}{N_q} \sum_{i=1}^{N_q} T_q(\mathbf{b} - \mathbf{b}_i)$$
 (21)

![](_page_4_Figure_14.jpeg)

FIG. 3: Examples of proton density profiles at x ≈ 10<sup>−</sup><sup>3</sup> with two parametrizations used in this work.

in Eq. (9). N<sup>q</sup> can be interpreted as the number of large x partons, typically chosen to be 3, for the three constituent quarks. We will also study larger values of N<sup>q</sup> in Appendix B, representing the situation of additional large x gluons or sea-quarks.

For fixed Nq, the degree of fluctuations is controlled by the parameters Bqc and Bq. Examples of the sampled proton density profiles for N<sup>q</sup> = 3 are given in Fig. 3. We show a "lumpy" proton configuration in panel a) and a "smooth" proton that has little fluctuations in panel b). In case of no geometric fluctuations, when the proton density profile is Gaussian with width B<sup>p</sup> (see Eq. (10)), the two-dimensional gluonic root mean square radius of the proton is r<sup>p</sup> = p 2Bp. When coherent HERA data is fitted, one obtains r<sup>p</sup> = 0.55 fm. Similarly, we can define the average radius of our fluctuating proton to be p 2(B<sup>q</sup> + Bqc), which in case of the parameter sets used in Fig. 3 has the same value.

In the IP-Glasma model geometric fluctuations are implemented by first performing the replacement (21) in the IPsat model, which then provides the saturation scale

<sup>1</sup> One can define e.g. the magnetic, charge [90–93], Zemach [94, 95], axial [96] and gluonic [97, 98] radius of the proton. In this work we deal with the gluonic content of the proton.

values according to the modified thickness functions. In the IP-Glasma framework the additional parameter m controls the infrared physics and thus affects the spatial size of the gluon distribution. Because of this the values for the parameters  $B_{qc}$  and  $B_q$  in both models cannot be directly compared. Examples of the proton density profiles obtained from the IP-Glasma model with the parametrization used in this work are illustrated in Fig. 4 by showing  $1-{\rm Re}\,{\rm Tr}\,V({\bf x})/N_{\rm c}$ .

![](_page_5_Figure_2.jpeg)

FIG. 4: Illustration of the proton density profile  $(1.0 - \text{Re Tr } V(x,y)/N_c)$  obtained from the IP-Glasma framework at  $x \approx 10^{-3}$  with parameters  $B_{qc} = 3.0 \text{ GeV}^{-2}$ ,  $B_q = 0.3 \text{ GeV}^{-2}$  and m = 0.4 GeV.

The total photon-proton cross section, and the proton structure functions, are proportional to the integral of the dipole amplitude over impact parameter. As the modification (21) is done in the exponent and the impact parameter dependence factorizes only in the dilute region, the replacement (21) affects the overall normalization of, for example,  $F_2$ . In practice, including geometric fluctuations  $(B_{qc} = 3.3 \text{ GeV}^{-2}, B_q = 0.7 \text{ GeV}^{-2})$ decreases  $F_2$  at  $x \sim 10^{-3}, Q^2 \sim 10 \text{ GeV}^2$  by approximately 8%. The diffractive cross section changes more, as it is proportional to the squared amplitude. Ideally one should perform a new fit to HERA DIS data with geometric fluctuations included, but this is beyond the scope of this work. However, this normalization uncertainty is similar for both coherent and incoherent cross sections and will not affect our conclusions about the required amount of geometric fluctuations in the proton wave function.

To determine the sensitivity on the details of the assumed proton shape we will also calculate the diffractive cross sections using a three-dimensional exponential den-

sity profile for the constituent quark

$$T_q(b) = \frac{1}{8\pi \tilde{B}_g^3} e^{-b/\tilde{B}_q},$$
 (22)

and sample the constituent quark locations from a three-dimensional exponential distribution  $\sim e^{-b/\tilde{B}_{qc}}$ . The sampled quarks are then projected on the transverse plane. We note that the resulting transverse density profile is not exactly exponential.

### B. Stringy proton

In order to explore the dependence on the model details we also implement the geometric fluctuations using a color string inspired picture. Here, the idea is that based on quenched lattice QCD calculations, the constituent quarks are connected via gluon fields that merge at the Fermat point<sup>2</sup> of the quark triangle [99] (see also Ref. [56]). We are not aware of calculations beyond the quenched approximation, which would be a more appropriate input to our model.

We implement this picture by sampling the constituent quark positions from a three dimensional Gaussian distribution with width  $B_t$ . Then, the density profile is obtained by connecting the constituent quarks to the Fermat point of the triangle by tubes whose transverse shape is Gaussian with width  $B_r$ . The 2-dimensional density profile of the proton  $T_p(\mathbf{b})$  is then obtained by integrating over the longitudinal direction.

In this picture the total gluonic content of the proton also fluctuates event-by-event, as when the quarks are sampled to be further away from each other, the flux tubes are longer at a constant density, leading to more gluons in the proton. This adds normalization fluctuations to the picture, which are similar to those introduced by saturation scale fluctuations (see the following section). The overall normalization factor, which controls the energy density of the tube, is fixed by requiring that the proton structure function  $F_2$  calculated from the stringy proton at  $Q^2 = 10 \text{ GeV}^2$ ,  $x = 10^{-3}$  is the same as that from the original IPsat parametrization without fluctuations. Example density profiles (integrated over the longitudinal direction) are shown in Fig. 5. The parameters  $B_t$  and  $B_r$  are fixed by requiring a good description of HERA coherent and incoherent diffractive  $J/\Psi$  production measurements [100].

<sup>&</sup>lt;sup>2</sup> The Fermat point of a triangle is defined such that the total distance from that point to the vertices of the triangle is the smallest possible.

![](_page_6_Figure_1.jpeg)

FIG. 5: Example density profiles of the "stringy proton" in the transverse plane at  $x\approx 10^{-3}$  with parameters  $B_t=4.2~{\rm GeV^{-2}}, B_r=0.6~{\rm GeV^{-2}}$ 

#### V. SATURATION SCALE FLUCTUATIONS

Experimentally observed multiplicity distributions and rapidity correlations in p+p collisions can be explained in the IP-Glasma framework when the saturation scale fluctuates according to [101, 102]

$$P(\ln Q_s^2/\langle Q_s^2 \rangle) = \frac{1}{\sqrt{2\pi}\sigma} \exp\left[-\frac{\ln^2 Q_s^2/\langle Q_s^2 \rangle}{2\sigma^2}\right], \quad (23)$$

with the amount of fluctuations controlled by  $\sigma \sim 0.5$ .

Because the log-normal distribution (23) leads to the expectation value  $E[Q_s^2/\langle Q_s^2\rangle]=e^{\sigma^2/2}$ , sampling the  $Q_s$  fluctuations directly from that distribution would make the average  $Q_s^2$  to be  $\approx 13\%$  larger (for  $\sigma=0.5$ ) than in case of no saturation scale fluctuations. This would not be consistent with the IPsat model fit to the HERA data. Thus, when the saturation scale is sampled from the distribution (23), we normalize it by the mean of the distribution in order to get a fluctuating  $Q_s$  distribution that always results in positive saturation scales and does not change the desired mean value.

In our constituent quark picture a natural way to include  $Q_s$  fluctuations is to let the saturation scale of each constituent quark fluctuate independently. In case of no geometric fluctuations, we implement the  $Q_s$  fluctuations by dividing the transverse space into a grid, where the cell size is set by the typical  $1/Q_s^2$  (cf. [103]), which for the EIC and HERA kinematics we consider corresponds to  $a \times a$  cells with  $a \sim 0.4$  fm.

#### VI. RESULTS

We present results on coherent and incoherent diffractive vector meson production from the IPsat model with and without geometric fluctuations in Section VIA. We show the effect of saturation scale fluctuations in Section VIB and present results for the same observables in the IP-Glasma model in Section VIC.

#### A. IPsat

We start by calculating the diffractive  $J/\Psi$  photoproduction ( $Q^2=0$ ) cross section that has been measured at HERA [86, 100, 104–106] in the IPSat model with and without geometric fluctuations. We compare our results with the HERA measurements at  $\langle W \rangle = 100$  GeV, corresponding to (in case of  $J/\Psi$  photoproduction at t=0)  $x_{\mathbb{P}} = 9.6 \cdot 10^{-4}$  [86, 104–106], and  $\langle W \rangle = 75$  GeV that corresponds to slightly larger  $x_{\mathbb{P}} = 1.7 \cdot 10^{-3}$  [100].

![](_page_6_Figure_13.jpeg)

FIG. 6: Coherent (thick lines) and incoherent (thin lines) cross section as a function of |t| compared with HERA data [86, 104–106]. The coherent cross section obtained without any fluctuations is also shown as a dotted line ( $B_p = 4.0 \text{ GeV}^{-2}$ ). The bands show statistical errors of the calculation

Comparison to the H1 and ZEUS high energy data on coherent and incoherent diffractive  $J/\Psi$  production as a function of |t| [86, 104–106] at  $\langle W \rangle = 100$  GeV is shown in Fig. 6. At this energy, the H1 collaboration has measured the total diffractive cross section, which at high |t| is to very good accuracy purely incoherent. Apart from the standard IPSat result with a round proton, for which the incoherent cross section is exactly zero, we employ the constituent quark profile discussed in Sec. IV A. We find that one has to introduce large geometric fluctuations (relatively small hot spots far away from the center of the proton with  $B_{qc}=3.3~{\rm GeV}^{-2}, B_q=0.5\dots0.7~{\rm GeV}^{-2}$ ) in order to obtain a large enough variance and consequently

![](_page_7_Figure_1.jpeg)

![](_page_7_Figure_2.jpeg)

a large incoherent cross section comparable with the experimental data. In particular, the much smoother proton configuration ( $B_{qc} = 1.0 \text{ GeV}^{-2}, B_q = 3.0 \text{ GeV}^{-2}$ ) underestimates the incoherent cross section by several orders of magnitude while still being compatible with the measured coherent cross section. For typical proton configurations in these two situations see Fig. 3. One can further see that when the constituent quark size  $B_q$  is decreased at constant  $B_{qc}$  the amount of fluctuations increases leading to a larger incoherent cross section. Also, the |t| slope of the incoherent cross section at large |t| is directly given by the constituent quark size [34]. Note that the overall normalization is affected by the inclusion of geometric fluctuations as discussed above.

Comparison to the H1 data [100] at the lower  $\langle W \rangle = 75~{\rm GeV}$  is shown in Fig. 7. Conclusions are the same as for  $\langle W \rangle = 100~{\rm GeV}$ . The agreement with the lumpy proton structure  $(B_{qc}=3.3~{\rm GeV}^{-2}, B_q=0.7~{\rm GeV}^{-2})$ , that also worked well with  $\langle W \rangle = 100~{\rm GeV}$  data, is good, while a smoother proton is incompatible with the incoherent data. We do not reproduce accurately the change in total coherent cross section from  $\langle W \rangle = 100~{\rm GeV}$  to  $\langle W \rangle = 75~{\rm GeV}$ . For the lumpy proton the incoherent cross section is only underestimated at very low |t|, where the contribution from e.g. saturation scale fluctuations is expected to be dominant [62]. The effect of  $Q_s$  fluctuations is studied numerically in Sec. VIB.

In order to study the dependence on the exact form of the geometric fluctuations, we next present diffractive cross sections calculated using the "stringy proton" density profile introduced in Sec. IV B. The results are shown in Fig. 8 and compared with H1 data at  $\langle W \rangle = 75$  GeV [100] where we again see that we need large geometric fluctuations, corresponding to a "tube width"  $B_T$  much smaller than the average distance of

![](_page_7_Figure_6.jpeg)

FIG. 8: Coherent (thick lines) and incoherent (thin lines) cross section as a function of |t| calculated using two "stringy proton" model parametrizations compared with H1 data [100]. The bands show statistical errors of the calculation.

the quarks from the center set by  $B_t$ . A good description of the data is obtained with  $B_t = 4.2 \text{ GeV}^{-2}$  and  $B_r = 0.6 \text{ GeV}^{-2}$ . Example density profiles from the parametrization that has large fluctuations are shown in Fig. 5. A smoother parametrization that has  $B_t = B_r$  is comparable with the coherent cross section measurements but underestimates the incoherent cross section by more than an order of magnitude. Comparing to the results obtained using constituent quark protons shown in Fig. 7, we conclude that the precise nature of the fluctuating shape cannot be constrained by the incoherent diffractive  $J/\Psi$  production.

The effect of replacing Gaussian density distributions by exponential distributions (see Eq. (22)) in the constituent quark picture is shown in Fig. 9. We obtain a good description of the H1 data with parameters  $B_{qc}$  =  $0.91 \text{ GeV}^{-1}$  and  $\tilde{B}_q = 0.42 \text{ GeV}^{-1}$ . With these parameters, we get the same 2-dimensional root mean square distance of the quark centers from the proton center as in case of the Gaussian distribution used in Fig. 9. Similarly the quarks' 2-dimensional root-mean-square radii are the same. This means that again we have large event-byevent fluctuations with small constituent quarks far away from each other  $(B_{qc} \gg B_q)$ . Using exponential distributions mainly modifies the large |t| tail of the coherent cross section. Because the coherent |t| data ends at  $|t| \sim 1 \text{ GeV}^2$ , one cannot currently distinguish between Gaussian and exponential density profiles.

The coherent cross section is experimentally challenging to measure at large |t| where the incoherent background starts to dominate. We can also see that in Fig. 6 the H1 and ZEUS results start to deviate in the largest |t| bins. A precise measurement of the coherent cross section at large |t| would allow us to further constrain the details of the average shape of the proton. Lacking such

![](_page_8_Figure_1.jpeg)

FIG. 9: Coherent (thick lines) and incoherent (thin lines) cross section as a function of |t| calculated with Gaussian  $(B_{qc}=3.3~{\rm GeV}^{-2},B_q=0.7~{\rm GeV}^{-2})$  and exponential  $(\tilde{B}_{qc}=0.91~{\rm GeV}^{-1},\tilde{B}_q=0.42~{\rm GeV}^{-1})$  density profile compared with HERA data [100]. The bands show statistical errors of the calculation.

![](_page_8_Figure_3.jpeg)

FIG. 10: Coherent (thick lines) and incoherent (thin lines) cross section as a function of |t| compared with HERA data [100] at  $\langle W \rangle = 75$  GeV. The bands show statistical errors of the calculation. Saturation scale fluctuations are included in the round proton case  $(B_p = 4.0 \text{ GeV}^{-2})$ , and their effect on top of proton geometric fluctuations is also shown.

constraining data we choose to use a Gaussian distribution in the rest of this work.

### B. Including saturation scale fluctuations

Having analyzed the effect of geometric fluctuations we now turn to the study of additional fluctuations of the saturation scale. As described in Sec. V within the

constituent quark proton model we allow the saturation scale of each quark to fluctuate individually. The spectra obtained with the same constituent quark proton parametrizations as used in Fig. 7 and with additional saturation scale fluctuations are shown in Fig. 10. In the figure we also show the cross sections obtained by allowing the saturation scale of a round proton  $(B_p =$ 4 GeV<sup>-2</sup>) to fluctuate independently between different cells of size  $a^2 = (0.4 \text{ fm})^2$  in the transverse plane as discussed in Sec. V. As anticipated, we find that including saturation scale fluctuations improves the agreement with the experimental incoherent cross section, particularly at small |t|, with the effect diminishing at higher |t|. This is in line with early discussions of the effect of different kinds of fluctuations on incoherent diffraction [62]. The  $Q_s$  fluctuations alone underestimate the measured incoherent cross section by approximately an order of magnitude.

In addition to  $J/\Psi$ , also diffractive production of lighter  $\phi$  and  $\rho$  mesons has been measured at HERA [105, 107-111]. The small mass of these mesons makes the photoproduction cross section calculation unreliable, because the cross section would receive significant contributions from large dipoles where non-perturbative effects become more relevant. The IPsat model includes some non-perturbative physics by requiring the dipole amplitude to reach unity in the large dipole limit. However, the model is still expected to reach the limits of its applicability as the dipole becomes large. Thus, in the following we study the diffractive production of  $\rho$  mesons at values of  $Q^2$  that are large enough to allow for the perturbative treatment of the scattering process. However, even at  $Q^2$  up to  $\sim 20 \text{ GeV}^2$  the relative contribution from large dipoles is stronger than in  $J/\Psi$  photoproduction [66], which means that non-perturbative physics may be more relevant.

The H1 collaboration has measured and incoherent  $\rho$  production in the range = 3.3...33.0 GeV<sup>2</sup> [111]. We calculate the corresponding cross sections within our framework by using the IPsat model with constituent quarks and the same parameters that were used to describe the  $J/\Psi$ photoproduction data. The results are shown in Fig. 11 (upper panel) for coherent and in Fig. 11 (lower panel) for incoherent  $\rho$  production. For coherent cross section, the agreement with the data is better for the highest  $Q^2$  bins. For small |t| the coherent cross section is underestimated, especially at low  $Q^2$ . The measured incoherent cross section would prefer slightly larger constituent quark size which would make the calculated |t| slope steeper, but such a change would not be favored by the incoherent  $J/\Psi$  production cross section which is theoretically under better control. As discussed above we expect our model to be less reliable in diffractive  $\rho$  production due to contributions from large dipoles even at moderate values of  $Q^2$ . When saturation scale fluctuations are included, the description of the small-|t|part of the incoherent cross section is improved.

![](_page_9_Figure_1.jpeg)

![](_page_9_Figure_2.jpeg)

FIG. 11: Coherent (upper) and incoherent (lower) diffractive  $\rho$  production cross section at W=75 GeV as a function of |t| compared with HERA data [111]. The bands show statistical errors of the calculation. Geometric fluctuations are included using the constituent quark picture with  $B_{qc}=3.3~{\rm GeV^{-2}}, B_q=0.7~{\rm GeV^{-2}}.~Q_s$  fluctuations are included in the results represented by solid lines.

### C. IP-Glasma model

Finally, we present results for coherent and incoherent diffractive  $J/\Psi$  and  $\rho$  production in the IP-Glasma model. The two main differences to the IPsat model are the existence of color charge fluctuations (in addition to possible saturation scale and geometric fluctuations), and the emergence of long-distance Coulomb tails in the gluon fields from the solution of the Yang-Mills equation. These infrared tails are regulated by the mass parameter m (see Eq. (14)) for which we use m = 0.4 GeV. Other values of m reduce the simultaneous agreement with experimental coherent and incoherent HERA data using any combination of parameters  $B_{qc}$  and  $B_q$  as we will demonstrate in Appendix C. Other than these differences, and the fact that the dipole amplitude is computed from the Wilson lines (14) according to Eq. (12) instead of Eq. (9), the physics content of the two models is the same. In partic-

![](_page_9_Figure_6.jpeg)

FIG. 12: Coherent (thick lines) and incoherent (thin lines)  $J/\Psi$  photoproduction cross section in the IP-Glasma framework as a function of |t| compared with HERA data [86, 104–106] at  $\langle W \rangle = 100$  GeV. The  $B_p = 4$  GeV<sup>-2</sup> result includes only color charge fluctuations.

ular, the geometry characterized by the different thickness functions is the same, only modified by the effects of large infrared tails in the IP-Glasma model, which are mainly compensated by the cutoff m.

First we compare coherent and incoherent cross sections with the HERA data for diffractive  $J/\Psi$  production at  $\langle W \rangle = 100$  GeV. The results are shown in Fig. 12. We find that the color charge fluctuations alone are not enough to describe the large incoherent cross section. Large geometric fluctuations  $(B_{qc} \gg B_q)$  on top of color charge fluctuations are needed to obtain an incoherent cross section compatible with the experimental data<sup>3</sup>. Because m does affect the size of the system, it is the combination of  $B_{qc}$ ,  $B_q$  and m that determines the geometry and its fluctuations in the IP-Glasma model. A direct comparison of  $B_{qc}$  and  $B_q$  between IPSat and IP-Glasma is thus difficult.

We next compare with H1 data at  $\langle W \rangle = 75$  GeV, where the incoherent cross section is measured also at smaller |t| [100]. The results are shown in Fig. 13. We find again that only when including large geometric fluctuations is the large-|t| part of the incoherent cross section described well. The small-|t| part of the incoherent cross section can only be reproduced with additional saturation scale fluctuations. This was expected based on Ref. [62], as saturation scale fluctuations contribute

<sup>&</sup>lt;sup>3</sup> Note that in our previous calculation in [15] the center of the proton was moved to the origin after the constituent quark positions were sampled, effectively making the proton smaller. This transformation is not done in this work which changes the numerical value of  $B_{qc}$ . Concerning the related issue of retaining the proton's center of mass see [112].

![](_page_10_Figure_1.jpeg)

FIG. 13: Coherent (thick lines) and incoherent (thin lines)  $J/\Psi$  production cross sections at  $\langle W \rangle = 75$  GeV compared with H1 data [100].

to the incoherent cross section dominantly at small |t|. Fluctuations at different distance scales are visible in the incoherent cross section: the lowest-|t| part is sensitive to  $Q_s$  fluctuations that are visible at the largest distance scales, as they correspond to fluctuations of overall density. Geometrical fluctuations become dominant at  $|t| \gtrsim 0.2 \text{ GeV}^2$ , where we become sensitive to distance scales smaller than the proton size. Color charge fluctuations take place at very small distance scales but also affect the overall normalization. As shown explicitly in Fig. 12, their effect is thus mainly visible at very small |t|. Overall, including geometric,  $Q_s$ , and color charge fluctuations in the IP-Glasma model, we are able to achieve excellent agreement with the experimental data at all values of |t|.

The  $\rho$  production cross sections calculated using the same fluctuating proton parametrizations are shown in Fig. 14. The coherent cross section measured at large  $Q^2$ is described well, and  $Q_s$  fluctuations are again found to improve the description of incoherent cross section data at small |t|. Neither the coherent cross section at small  $Q^2$  nor the incoherent cross section at large |t| are described accurately by our calculation. This is likely due to contributions from large dipoles that are not correctly described within our framework as discussed earlier in case of the IPsat model. In the IP-Glasma model the situation is even worse as the dipole cross section does not go to one at large r like in the parametrized IPSat expression. This is evident from Eq. (12): as soon as one end of the dipole is outside the proton, the expression for N goes to zero (also see Ref. [79]).

![](_page_10_Figure_5.jpeg)

![](_page_10_Figure_6.jpeg)

FIG. 14: Coherent (upper) and incoherent (lower) diffractive  $\rho$  production cross section at  $\langle W \rangle = 75$  GeV as a function of |t| compared with HERA data [111] calculated in the IP-Glasma framework. The bands show statistical errors of the calculation. Geometric fluctuations are included using the constituent quark picture with  $B_{qc}=3.0~{\rm GeV}^{-2}, B_q=0.3~{\rm GeV}^{-2}$  and  $m=0.4~{\rm GeV}$ . For the incoherent cross section the effect of  $Q_s$  fluctuations is included in the result shown as solid curves.

## VII. CONCLUSIONS AND OUTLOOK

We have presented a detailed event-by-event computation of exclusive diffractive vector meson production in the color glass condensate framework. Within the IPSat and IP-Glasma models, whose parameters are almost entirely constrained by HERA data on deeply inelastic scattering, we find that in order to describe the experimental incoherent cross section of both  $J/\Psi$  and  $\rho$  production, large geometric fluctuations are needed. This finding is independent of the details of the model. These include different density distributions of gluons in the proton, of which we studied Gaussian and exponential distributions, as well as a stringy model, motivated by QCD in the limit of large quark masses. Apart from geometric fluctuations, we included fluctuations of the saturation scale

and in the case of the IP-Glasma model, color charges. They contribute at all values of |t| but dominate in the limit  $|t| \to 0$ . In particular in the IP-Glasma model, which includes all relevant fluctuations, we find excellent agreement of both the coherent and incoherent diffractive  $J/\Psi$  production cross sections. The diffractive production of  $\rho$  mesons is less accurately described, which we can attribute to more significant contributions from large dipoles that are not well described in our framework.

Our analysis provides constraints on the proton's fluctuating shape at high energy (small x), which is an important input for calculations of observables in p+p and p+A collisions. These include in particular azimuthal anisotropy coefficients, which in case of strong final state effects are highly sensitive to the initial shape of the proton. We will investigate in the future if the fluctuating proton shape constrained in this work is indeed compatible with experimental data on anisotropic flow in p+Pb collisions at the LHC and p+Au collisions at RHIC.

#### Acknowledgments

We thank E. Aschenauer, T. Lappi, S. Schlichting, M. Strikman, T. Ullrich, and R. Venugopalan for discussions. This work was supported under DOE Contract No. DE-SC0012704. This research used resources of the National Energy Research Scientific Computing Center, which is supported by the Office of Science of the U.S. Department of Energy under Contract No. DE-AC02-05CH11231. BPS acknowledges a DOE Office of Science Early Career Award.

#### Appendix A: Phenomenological corrections

As discussed already in Sec. III, the phenomenological corrections, and especially the skewedness correction, are numerically important. To demonstrate this, we show in Fig. 15 the effect of the skewedness and real part corrections on the coherent diffractive  $\rho$  production cross section at different values of  $Q^2$ . The corrections are calculated separately for transversally and longitudinally polarized photons. The effect of the skewedness correction (see Eq. (18)) is quantified in the IPSat model without fluctuations by the ratio of the diffractive  $\rho$  production cross section with and without taking the skewedness correction into account. The real part correction is quantified by the factor  $(1+\beta^2)$  from Eq. (16), again calculated in the IPSat model without fluctuations.

As the corrections depend slightly on |t|, the results shown in Fig. 15 are the average correction factors at  $|t| < 0.5 \text{ GeV}^2$ . We observe that especially at high  $Q^2$ , where the gluon density rises most rapidly, the skewedness correction becomes very large, of the order of 50%. For  $J/\Psi$  photoproduction in the same kinematics (as shown in Fig. 10) the skewedness correction is  $\approx 43\%$  and the real part correction  $\approx 11\%$ .

![](_page_11_Figure_8.jpeg)

FIG. 15: Average effect of the skewedness and real part corrections at  $|t| < 0.5~{\rm GeV}^2$  to the coherent  $\rho$  production cross section calculated from the IPsat model without fluctuations at  $\langle W \rangle = 75~{\rm GeV}$ .

![](_page_11_Figure_10.jpeg)

FIG. 16: Dependence of coherent (thick lines) and incoherent (thin lines) diffractive  $J/\Psi$  production cross section at  $\langle W \rangle = 75$  GeV on the number of constituent quarks (hot spots)  $N_q$ . The bands show statistical errors of the calculation.

# Appendix B: Dependence on the number of constituent quarks

We study the dependence of the effect of geometric fluctuations on the number of hot spots  $(N_q \text{ in Eq. (21)})$ . Numbers larger than 3 can be interpreted as the three constituent quarks plus large x sea-quarks or gluons, which are emitted from the large-x valence quarks (see also Ref. [113, 114]). This change does not affect the coherent cross section, as the average proton density profile remains approximately the same. However, it results in a smoother proton on average and thus one would ex-

![](_page_12_Figure_1.jpeg)

FIG. 17: Sensitivity of the results on the infrared cutoff m in the IP-Glasma model. Cross sections are compared with HERA data [100].

pect to see a smaller incoherent cross section compared to the case with  $N_q=3$ . This is demonstrated in Fig. 16, where having  $N_q=5$  hot spots decreases the incoherent cross section by  $\sim 30\%$ . If the size of the hot spots is reduced by decreasing the constituent quark width from  $B_q=0.7~{\rm GeV}^{-2}$  to  $B_q=0.5~{\rm GeV}^{-2}$ , a similar degree of

fluctuations and comparable incoherent cross section is obtained at large |t|.  $Q_s$  fluctuations are not included in this analysis.

## Appendix C: Dependence on the infrared cutoff in the IP-Glasma model

Because it affects the average proton size and overall normalization of the gluon distribution, the infrared cutoff parameter m, introduced for the IP-Glasma model in Eq. (14), is expected to have an effect on both the coherent and incoherent cross sections. To study the sensitivity on this parameter, we show in Fig. 17 the coherent and incoherent cross section calculated with m ranging from 0.2 GeV to 0.6 GeV. As could be expected, the results are most sensitive to the infrared cutoff in the small-|t|region, while for  $|t| \gtrsim 1 \text{ GeV}^2$  its effect becomes negligible. The dependence on m at small momentum can be understood as follows: Smaller masses allow for longer Coulomb tails, making the proton effectively larger, leading to steeper coherent |t| spectra. The fact that for smaller m the proton becomes more dense at large impact parameters also increases the overall normalization of both the coherent and incoherent cross sections. We note that the ratio of the incoherent and the coherent cross section is almost independent of m [15].

- H1 and ZEUS collaboration, F. Aaron et. al., Combined Measurement and QCD Analysis of the Inclusive e<sup>±</sup>p Scattering Cross Sections at HERA, JHEP 1001 (2010) 109 [arXiv:0911.0884 [hep-ex]].
- [2] H1 and ZEUS collaboration, H. Abramowicz et. al., Combination of measurements of inclusive deep inelastic e<sup>±</sup>p scattering cross sections and QCD analysis of HERA data, Eur. Phys. J. C75 (2015) 580 [arXiv:1506.06042 [hep-ex]].
- [3] A. V. Belitsky, X.-d. Ji and F. Yuan, Quark imaging in the proton via quantum phase space distributions, Phys. Rev. D69 (2004) 074014 [arXiv:hep-ph/0307383 [hep-ph]].
- [4] D. Müller, D. Robaschik, B. Geyer, F. M. Dittes and J. Hořejši, Wave functions, evolution equations and evolution kernels from light ray operators of QCD, Fortsch. Phys. 42 (1994) 101 [arXiv:hep-ph/9812448 [hep-ph]].
- [5] X.-D. Ji, Deeply virtual Compton scattering, Phys. Rev. D55 (1997) 7114 [arXiv:hep-ph/9609381 [hep-ph]].
- [6] A. V. Radyushkin, Nonforward parton distributions, Phys. Rev. D56 (1997) 5524 [arXiv:hep-ph/9704207 [hep-ph]].
- J. C. Collins, L. Frankfurt and M. Strikman,
   Factorization for hard exclusive electroproduction of mesons in QCD, Phys. Rev. D56 (1997) 2982
   [arXiv:hep-ph/9611433 [hep-ph]].
- [8] R. D. Tangerman and P. J. Mulders, *Intrinsic transverse momentum and the polarized Drell-Yan*

- process, Phys. Rev. **D51** (1995) 3357 [arXiv:hep-ph/9403227 [hep-ph]].
- [9] P. J. Mulders and J. Rodrigues, Transverse momentum dependence in gluon distribution and fragmentation functions, Phys. Rev. D63 (2001) 094021
   [arXiv:hep-ph/0009343 [hep-ph]].
- [10] M. A. Kimber, A. D. Martin and M. G. Ryskin, Unintegrated parton distributions, Phys. Rev. D63 (2001) 114027 [arXiv:hep-ph/0101348 [hep-ph]].
- [11] U. D'Alesio and F. Murgia, Parton intrinsic motion in inclusive particle production: Unpolarized cross sections, single spin asymmetries and the Sivers effect, Phys. Rev. D70 (2004) 074009 [arXiv:hep-ph/0408092 [hep-ph]].
- [12] M. Anselmino, M. Boglione, U. D'Alesio, E. Leader and F. Murgia, Parton intrinsic motion: Suppression of the Collins mechanism for transverse single spin asymmetries in p<sup>↑</sup>p → πX, Phys. Rev. D71 (2005) 014002 [arXiv:hep-ph/0408356 [hep-ph]].
- [13] M. Anselmino, M. Boglione, U. D'Alesio, E. Leader, S. Melis and F. Murgia, The general partonic structure for hadronic spin asymmetries, Phys. Rev. D73 (2006) 014020 [arXiv:hep-ph/0509035 [hep-ph]].
- [14] S. M. Aybat and T. C. Rogers, TMD Parton Distribution and Fragmentation Functions with QCD Evolution, Phys. Rev. D83 (2011) 114042 [arXiv:1101.5057 [hep-ph]].
- [15] H. Mäntysaari and B. Schenke, Evidence of strong proton shape fluctuations from incoherent diffraction,

- arXiv:1603.04349 [hep-ph].
- [16] E. Iancu and R. Venugopalan, The Color Glass Condensate and high-energy scattering in QCD, arXiv:hep-ph/0303204 [hep-ph].
- [17] F. Gelis, E. Iancu, J. Jalilian-Marian and R. Venugopalan, The Color Glass Condensate, Ann. Rev. Nucl. Part. Sci. 60 (2010) 463 [arXiv:1002.0333 [hep-ph]].
- [18] J. L. Albacete, N. Armesto, J. G. Milhano, P. Quiroga-Arias and C. A. Salgado, AAMQS: A non-linear QCD analysis of new HERA data at small-x including heavy quarks, Eur. Phys. J. C71 (2011) 1705 [arXiv:1012.4408 [hep-ph]].
- [19] A. H. Rezaeian, M. Siddikov, M. Van de Klundert and R. Venugopalan, Analysis of combined HERA data in the Impact-Parameter dependent Saturation model, Phys. Rev. D87 (2013) 034002 [arXiv:1212.2974].
- [20] T. Lappi and H. Mäntysaari, Single inclusive particle production at high energy from HERA data to proton-nucleus collisions, Phys. Rev. D88 (2013) 114020 [arXiv:1309.6963 [hep-ph]].
- [21] P. Tribedy and R. Venugopalan, Saturation models of HERA DIS data and inclusive hadron distributions in p+p collisions at the LHC, Nucl. Phys. A850 (2011) 136 [arXiv:1011.1895 [hep-ph]].
- [22] H. Fujii and K. Watanabe, Heavy quark pair production in high energy pA collisions: Quarkonium, Nucl. Phys. A915 (2013) 1 [arXiv:1304.2221 [hep-ph]].
- [23] Y.-Q. Ma and R. Venugopalan, Comprehensive Description of J/Ψ Production in Proton-Proton Collisions at Collider Energies, Phys. Rev. Lett. 113 (2014) 192301 [arXiv:1408.4075 [hep-ph]].
- [24] B. Ducloué, T. Lappi and H. Mäntysaari, Forward J/ψ production in proton-nucleus collisions at high energy, Phys. Rev. D91 (2015) 114005 [arXiv:1503.02789 [hep-ph]].
- [25] B. Ducloué, T. Lappi and H. Mäntysaari, Forward J/ψ production at high energy: centrality dependence and mean transverse momentum, arXiv:1605.05680 [hep-ph].
- [26] J. L. Albacete and C. Marquet, Azimuthal correlations of forward di-hadrons in d+Au collisions at RHIC in the Color Glass Condensate, Phys. Rev. Lett. 105 (2010) 162301 [arXiv:1005.4065 [hep-ph]].
- [27] A. Stasto, B.-W. Xiao and F. Yuan, Back-to-Back Correlations of Di-hadrons in dAu Collisions at RHIC, Phys. Lett. B716 (2012) 430 [arXiv:1109.1817 [hep-ph]].
- [28] T. Lappi and H. Mäntysaari, Forward dihadron correlations in deuteron-gold collisions with the Gaussian approximation of JIMWLK, Nucl. Phys. A908 (2013) 51 [arXiv:1209.2853 [hep-ph]].
- [29] Y. V. Kovchegov and E. Levin, Diffractive dissociation including multiple pomeron exchanges in high parton density QCD, Nucl. Phys. B577 (2000) 221 [arXiv:hep-ph/9911523 [hep-ph]].
- [30] M. Kuroda and D. Schildknecht, J/Ψ photo- and electroproduction, the saturation scale and the gluon structure function, Phys. Lett. B638 (2006) 473 [arXiv:hep-ph/0507098 [hep-ph]].
- [31] V. P. Goncalves and M. V. T. Machado, The QCD pomeron in ultraperipheral heavy ion collisions. IV. Photonuclear production of vector mesons, Eur. Phys. J. C40 (2005) 519 [arXiv:hep-ph/0501099 [hep-ph]].

- [32] H. Kowalski, T. Lappi, C. Marquet and R. Venugopalan, Nuclear enhancement and suppression of diffractive structure functions at high energies, Phys. Rev. C78 (2008) 045201 [arXiv:0805.4071 [hep-ph]].
- [33] A. Caldwell and H. Kowalski, Investigating the gluonic structure of nuclei via J/Ψ scattering, Phys. Rev. C81 (2010) 025203 [arXiv:0909.1254].
- [34] T. Lappi and H. Mäntysaari, Incoherent diffractive
   J/Ψ-production in high energy nuclear DIS, Phys. Rev.
   C83 (2011) 065202 [arXiv:1011.1988 [hep-ph]].
- [35] T. Toll and T. Ullrich, Exclusive diffractive processes in electron-ion collisions, Phys. Rev. C87 (2013) 024913 [arXiv:1211.3048 [hep-ph]].
- [36] T. Lappi and H. Mäntysaari, J/Ψ production in ultraperipheral Pb+Pb and p+Pb collisions at LHC energies, Phys. Rev. C87 (2013) 032201 [arXiv:1301.4095 [hep-ph]].
- [37] T. Lappi, H. Mäntysaari and R. Venugopalan, Ballistic protons in incoherent exclusive vector meson production as a measure of rare parton fluctuations at an Electron-Ion Collider, Phys. Rev. Lett. 114 (2015) 082301 [arXiv:1411.0887 [hep-ph]].
- [38] F. Dominguez, C. Marquet and B. Wu, On multiple scatterings of mesons in hot and cold QCD matter, Nucl. Phys. A823 (2009) 99 [arXiv:0812.3878 [nucl-th]].
- [39] C. Marquet and B. Wu, Exclusive vs. diffractive vector meson production in DIS at small x or off nuclei, arXiv:0908.4180 [hep-ph].
- [40] D. Boer, M. Diehl, R. Milner, R. Venugopalan, W. Vogelsang et. al., Gluons and the quark sea at high energies: Distributions, polarization, tomography, arXiv:1108.1713 [nucl-th].
- [41] A. Accardi, J. Albacete, M. Anselmino, N. Armesto, E. Aschenauer et. al., Electron Ion Collider: The Next QCD Frontier Understanding the glue that binds us all, arXiv:1212.1701 [nucl-ex].
- [42] **ALICE** collaboration, B. Abelev *et. al.*, Coherent  $J/\psi$  photoproduction in ultra-peripheral Pb-Pb collisions at  $\sqrt{s_{NN}} = 2.76$  TeV, Phys. Lett. **B718** (2013) 1273 [arXiv:1209.3715 [nucl-ex]].
- [43] ALICE collaboration, E. Abbas et. al., Charmonium and e<sup>+</sup>e<sup>−</sup> pair photoproduction at mid-rapidity in ultra-peripheral Pb-Pb collisions at √s<sub>NN</sub> = 2.76 TeV, Eur. Phys. J. C73 (2013) 2617 [arXiv:1305.1467 [nucl-ex]].
- [44] CMS collaboration, V. Khachatryan et. al., Coherent  $J/\Psi$  photoproduction in ultra-peripheral PbPb collisions at  $\sqrt{s_{\mathrm{NN}}} = 2.76\,\mathrm{TeV}$  with the CMS experiment, arXiv:1605.06966 [nucl-ex].
- [45] **ATLAS** collaboration, "Measurement of high-mass dimuon pairs from ultraperipheral lead-lead collisions at  $\sqrt{s_{\mathrm{NN}}} = 5.02~\text{TeV}$  with the ATLAS detector at the LHC." ATLAS-CONF-2016-025.
- [46] **ALICE** collaboration, B. B. Abelev et. al., Exclusive  $J/\Psi$  photoproduction off protons in ultra-peripheral p-Pb collisions at  $\sqrt{s_{\mathrm{NN}}} = 5.02$  TeV, Phys. Rev. Lett. 113 (2014) 232504 [arXiv:1406.7819 [nucl-ex]].
- [47] CMS collaboration, "Measurement of exclusive  $\Upsilon$  photoproduction in pPb collisions at  $\sqrt{s_{\mathrm{NN}}} = 5.02$  TeV." CMS-PAS-FSQ-13-009.
- [48] CMS collaboration, V. Khachatryan et. al., Observation of Long-Range Near-Side Angular Correlations in Proton-Proton Collisions at the LHC,

- JHEP 09 (2010) 091 [arXiv:1009.4122 [hep-ex]].
- [49] ALICE collaboration, B. Abelev et. al., Long-range angular correlations on the near and away side in p-Pb collisions at <sup>√</sup> sNN = 5.02 TeV, Phys. Lett. B719 (2013) 29 [arXiv:1212.2001 [nucl-ex]].
- [50] ATLAS collaboration, G. Aad et. al., Observation of Associated Near-Side and Away-Side Long-Range Correlations in <sup>√</sup> sNN = 5.02 TeV Proton-Lead Collisions with the ATLAS Detector, Phys. Rev. Lett. 110 (2013) 182302 [arXiv:1212.5198 [hep-ex]].
- [51] PHENIX collaboration, A. Adare et. al., Quadrupole Anisotropy in Dihadron Azimuthal Correlations in Central <sup>d</sup> <sup>+</sup> Au Collisions at <sup>√</sup>sNN = 200 GeV, Phys. Rev. Lett. 111 (2013) 212301 [arXiv:1303.1794 [nucl-ex]].
- [52] K. Dusling, W. Li and B. Schenke, Novel collective phenomena in high-energy proton–proton and proton–nucleus collisions, Int. J. Mod. Phys. E25 (2016) 1630002 [arXiv:1509.07939 [nucl-ex]].
- [53] C. Gale, S. Jeon and B. Schenke, Hydrodynamic Modeling of Heavy-Ion Collisions, Int. J. Mod. Phys. A28 (2013) 1340011 [arXiv:1301.5893 [nucl-th]].
- [54] B. Schenke and R. Venugopalan, Eccentric protons? Sensitivity of flow to system size and shape in p+p, p+Pb and Pb+Pb collisions, Phys. Rev. Lett. 113 (2014) 102301 [arXiv:1405.3605 [nucl-th]].
- [55] W.-T. Deng, Z. Xu and C. Greiner, Elliptic and Triangular Flow and their Correlation in Ultrarelativistic High Multiplicity Proton Proton Collisions at 14 TeV, Phys. Lett. B711 (2012) 301 [arXiv:1112.0470 [hep-ph]].
- [56] C. E. Coleman-Smith and B. M¨uller, Mapping the proton's fluctuating size and shape, Phys. Rev. D89 (2014) 025019 [arXiv:1307.5911 [hep-ph]].
- [57] M. Alvioli, B. A. Cole, L. Frankfurt, D. V. Perepelitsa and M. Strikman, Evidence for x-dependent proton color fluctuations in pA collisions at the CERN Large Hadron Collider, Phys. Rev. C93 (2016) no. 1 011902 [arXiv:1409.7381 [hep-ph]].
- [58] ATLAS collaboration, G. Aad et. al., Measurement of the centrality dependence of the charged-particle pseudorapidity distribution in proton–lead collisions at <sup>√</sup>sNN = 5.<sup>02</sup> TeV with the ATLAS detector, Eur. Phys. J. C76 (2016) no. 4 199 [arXiv:1508.00848 [hep-ex]].
- [59] K. Welsh, J. Singer and U. W. Heinz, Initial state fluctuations in collisions between light and heavy ions, arXiv:1605.09418 [nucl-th].
- [60] J. L. Albacete and A. Soto-Ontoso, Hot spots and the hollowness of proton-proton interactions at high energies, arXiv:1605.09176 [hep-ph].
- [61] M. L. Good and W. D. Walker, Diffraction disssociation of beam particles, Phys. Rev. 120 (1960) 1857.
- [62] H. I. Miettinen and J. Pumplin, Diffraction Scattering and the Parton Structure of Hadrons, Phys. Rev. D18 (1978) 1696.
- [63] L. Frankfurt, G. A. Miller and M. Strikman, Evidence for color fluctuations in hadrons from coherent nuclear diffraction, Phys. Rev. Lett. 71 (1993) 2859 [arXiv:hep-ph/9309285 [hep-ph]].
- [64] L. Frankfurt, M. Strikman, D. Treleani and C. Weiss, Evidence for color fluctuations in the nucleon in high-energy scattering, Phys. Rev. Lett. 101 (2008)

- 202003 [arXiv:0808.0182 [hep-ph]].
- [65] V. Barone and E. Predazzi, High-Energy Particle Diffraction, vol. 565 of Texts and Monographs in Physics. Springer-Verlag, Berlin Heidelberg, 2002.
- [66] H. Kowalski, L. Motyka and G. Watt, Exclusive diffractive processes at HERA within the dipole picture, Phys. Rev. D74 (2006) 074016 [arXiv:hep-ph/0606272].
- [67] Y. V. Kovchegov and L. D. McLerran, Diffractive structure function in a quasiclassical approximation, Phys. Rev. D60 (1999) 054025 [arXiv:hep-ph/9903246 [hep-ph]]. [Erratum: Phys. Rev.D62,019901(2000)].
- [68] A. Kovner and U. A. Wiedemann, Eikonal evolution and gluon radiation, Phys. Rev. D64 (2001) 114002 [arXiv:hep-ph/0106240 [hep-ph]].
- [69] W. Buchmuller, T. Gehrmann and A. Hebecker, Inclusive and diffractive structure functions at small x, Nucl. Phys. B537 (1999) 477 [arXiv:hep-ph/9808454 [hep-ph]].
- [70] Y. V. Kovchegov and E. Levin, Quantum chromodynamics at high energy. Cambridge University Press, 2012.
- [71] J. Jalilian-Marian, A. Kovner, L. D. McLerran and H. Weigert, The Intrinsic glue distribution at very small x, Phys. Rev. D55 (1997) 5414 [arXiv:hep-ph/9606337 [hep-ph]].
- [72] J. Jalilian-Marian, A. Kovner, A. Leonidov and H. Weigert, The BFKL equation from the Wilson renormalization group, Nucl. Phys. B504 (1997) 415 [arXiv:hep-ph/9701284 [hep-ph]].
- [73] J. Jalilian-Marian, A. Kovner, A. Leonidov and H. Weigert, The Wilson renormalization group for low x physics: Towards the high density regime, Phys. Rev. D59 (1998) 014014 [arXiv:hep-ph/9706377 [hep-ph]].
- [74] E. Iancu and L. D. McLerran, Saturation and universality in QCD at small x, Phys. Lett. B510 (2001) 145 [arXiv:hep-ph/0103032 [hep-ph]].
- [75] I. Balitsky, Operator expansion for high-energy scattering, Nucl. Phys. B463 (1996) 99 [arXiv:hep-ph/9509348].
- [76] Y. V. Kovchegov, Small-x F<sup>2</sup> structure function of a nucleus including multiple pomeron exchanges, Phys. Rev. D60 (1999) 034008 [arXiv:hep-ph/9901281 [hep-ph]].
- [77] H. Kowalski and D. Teaney, An Impact parameter dipole saturation model, Phys. Rev. D68 (2003) 114005 [arXiv:hep-ph/0304189 [hep-ph]].
- [78] K. J. Golec-Biernat and A. Stasto, On solutions of the Balitsky-Kovchegov equation with impact parameter, Nucl. Phys. B668 (2003) 345 [arXiv:hep-ph/0306279 [hep-ph]].
- [79] S. Schlichting and B. Schenke, The shape of the proton at high energies, Phys. Lett. B739 (2014) 313 [arXiv:1407.8458 [hep-ph]].
- [80] B. Schenke, P. Tribedy and R. Venugopalan, Fluctuating Glasma initial conditions and flow in heavy ion collisions, Phys. Rev. Lett. 108 (2012) 252301 [arXiv:1202.6646 [nucl-th]].
- [81] B. Schenke, P. Tribedy and R. Venugopalan, Multiplicity distributions in p+p, p+A and A+A collisions from Yang-Mills dynamics, Phys. Rev. C89 (2014) 024901 [arXiv:1311.3636 [hep-ph]].
- [82] J. Bartels, K. J. Golec-Biernat and H. Kowalski, A

- modification of the saturation model: DGLAP evolution, Phys. Rev. D66 (2002) 014001 [arXiv:hep-ph/0203258 [hep-ph]].
- [83] E. Gotsman, E. Levin, U. Maor and E. Naftali, Momentum transfer dependence of the differential cross-section for J/Ψ production, Phys. Lett. B532 (2002) 37 [arXiv:hep-ph/0110256 [hep-ph]].
- [84] T. Lappi, Wilson line correlator in the MV model: Relating the glasma to deep inelastic scattering, Eur. Phys. J. C55 (2008) 285 [arXiv:0711.3039 [hep-ph]].
- [85] B. Schenke, P. Tribedy and R. Venugopalan, Event-by-event gluon multiplicity, energy density, and eccentricities in ultrarelativistic heavy-ion collisions, Phys. Rev. C86 (2012) 034908 [arXiv:1206.6805 [hep-ph]].
- [86] H1 collaboration, A. Aktas et. al., Elastic J/Ψ production at HERA, Eur. Phys. J. C46 (2006) 585 [arXiv:hep-ex/0510016].
- [87] A. D. Martin and M. G. Ryskin, The effect of off diagonal parton distributions in diffractive vector meson electroproduction, Phys. Rev. D57 (1998) 6692 [arXiv:hep-ph/9711371 [hep-ph]].
- [88] A. G. Shuvaev, K. J. Golec-Biernat, A. D. Martin and M. G. Ryskin, Off-diagonal distributions fixed by diagonal partons at small x and ξ, Phys. Rev. D60 (1999) 014015 [arXiv:hep-ph/9902410].
- [89] A. D. Martin, M. Ryskin and T. Teubner, Q 2 dependence of diffractive vector meson electroproduction, Phys. Rev. D62 (2000) 014022 [arXiv:hep-ph/9912551 [hep-ph]].
- [90] R. Hofstadter, Electron scattering and nuclear structure, Rev. Mod. Phys. 28 (Jul, 1956) 214.
- [91] A1 collaboration, J. C. Bernauer et. al., High-precision determination of the electric and magnetic form factors of the proton, Phys. Rev. Lett. 105 (2010) 242001 [arXiv:1007.5076 [nucl-ex]].
- [92] X. Zhan et. al., High-Precision Measurement of the Proton Elastic Form Factor Ratio µpGE/G<sup>M</sup> at low Q 2 , Phys. Lett. B705 (2011) 59 [arXiv:1102.0318 [nucl-ex]].
- [93] Proton structure from the measurement of 2s-2p transition frequencies of muonic hydrogen, Science 339 (2013) no. 6118 417.
- [94] J. L. Friar and I. Sick, Zemach moments for hydrogen and deuterium, Phys. Lett. B579 (2004) 285 [arXiv:nucl-th/0310043 [nucl-th]].
- [95] M. O. Distler, J. C. Bernauer and T. Walcher, The RMS Charge Radius of the Proton and Zemach Moments, Phys. Lett. B696 (2011) 343 [arXiv:1011.1861 [nucl-th]].
- [96] U. G. Meissner, Low-Energy Hadron Physics from Effective Chiral Lagrangians with Vector Mesons, Phys. Rept. 161 (1988) 213.
- [97] M. Kawasaki, T. Maehara and M. Yonezawa, Gluonic radius of the proton and high-energy pp¯ scattering, Phys. Rev. D57 (1998) 1822.
- [98] A. Caldwell and H. Kowalski, Investigating the gluonic structure of nuclei via J/Ψ scattering, in Phys. Rev. [33], p. 025203, [arXiv:0909.1254].
- [99] F. Bissey, F.-G. Cao, A. R. Kitson, A. I. Signal, D. B. Leinweber, B. G. Lasscock and A. G. Williams, Gluon

- flux-tube distribution and linear confinement in baryons, Phys. Rev. D76 (2007) 114512 [arXiv:hep-lat/0606016 [hep-lat]].
- [100] H1 collaboration, C. Alexa et. al., Elastic and Proton-Dissociative Photoproduction of J/Ψ Mesons at HERA, Eur. Phys. J. C73 (2013) no. 6 2466 [arXiv:1304.5162 [hep-ex]].
- [101] L. McLerran and P. Tribedy, Intrinsic Fluctuations of the Proton Saturation Momentum Scale in High Multiplicity p+p Collisions, Nucl. Phys. A945 (2016) 216 [arXiv:1508.03292 [hep-ph]].
- [102] A. Bzdak and K. Dusling, Probing proton fluctuations with asymmetric rapidity correlations, Phys. Rev. C93 (2016) no. 3 031901 [arXiv:1511.03620 [hep-ph]].
- [103] A. Dumitru and Y. Nara, KNO scaling of fluctuations in pp and pA, and eccentricities in heavy-ion collisions, Phys. Rev. C85 (2012) 034907 [arXiv:1201.6382 [nucl-th]].
- [104] ZEUS collaboration, S. Chekanov et. al., Exclusive photoproduction of J/Ψ mesons at HERA, Eur. Phys. J. C24 (2002) 345 [arXiv:hep-ex/0201043 [hep-ex]].
- [105] ZEUS collaboration, S. Chekanov et. al., Measurement of proton dissociative diffractive photoproduction of vector mesons at large momentum transfer at HERA, Eur. Phys. J. C26 (2003) 389 [arXiv:hep-ex/0205081 [hep-ex]].
- [106] H1 collaboration, A. Aktas et. al., Diffractive photoproduction of J/Ψ mesons with large momentum transfer at HERA, Phys. Lett. B568 (2003) 205 [arXiv:hep-ex/0306013 [hep-ex]].
- [107] H1 collaboration, S. Aid et. al., Elastic Electroproduction of ρ and J/Ψ Mesons at large Q 2 at HERA, Nucl. Phys. B468 (1996) 3 [arXiv:hep-ex/9602007 [hep-ex]].
- [108] H1 collaboration, C. Adloff et. al., Elastic electroproduction of ρ mesons at HERA, Eur. Phys. J. C13 (2000) 371 [arXiv:hep-ex/9902019 [hep-ex]].
- [109] ZEUS collaboration, J. Breitweg et. al., Measurement of diffractive photoproduction of vector mesons at large momentum transfer at HERA, Eur. Phys. J. C14 (2000) 213 [arXiv:hep-ex/9910038 [hep-ex]].
- [110] ZEUS collaboration, S. Chekanov et. al., Exclusive electroproduction of phi mesons at HERA, Nucl. Phys. B718 (2005) 3 [arXiv:hep-ex/0504010 [hep-ex]].
- [111] H1 collaboration, F. Aaron et. al., Diffractive Electroproduction of ρ and φ Mesons at HERA, JHEP 1005 (2010) 032 [arXiv:0910.5831 [hep-ex]].
- [112] J. T. Mitchell, D. V. Perepelitsa, M. J. Tannenbaum and P. W. Stankus, Tests of constituent-quark generation methods which maintain both the nucleon center of mass and the desired radial distribution in Monte Carlo Glauber models, Phys. Rev. C93 (2016) no. 5 054910 [arXiv:1603.08836 [nucl-ex]].
- [113] C. Flensburg, G. Gustafson and L. L¨onnblad, Exclusive final states in diffractive excitation, JHEP 12 (2012) 115 [arXiv:1210.2407 [hep-ph]].
- [114] A. H. Mueller and S. Munier, On parton number fluctuations at various stages of the rapidity evolution, Phys. Lett. B737 (2014) 303 [arXiv:1405.3131 [hep-ph]].