![](_page_0_Picture_0.jpeg)

![](_page_0_Picture_1.jpeg)

#### Available online at www.sciencedirect.com

## **ScienceDirect**

**Physics** 

**Procedia** 

Physics Procedia 84 (2016) 35 - 39

International Conference "Synchrotron and Free electron laser Radiation: generation and application", SFR-2016, 4-8 July 2016, Novosibirsk, Russia

# Status and Perspectives of Compton Sources

Ryoichi Hajima<sup>a,b,\*</sup>

<sup>a</sup>National Institutes of Quantum and Radiological Sciences and Technology, Tokai, Ibaraki 319-1106, Japan <sup>b</sup>High Energy Accelerator Research Organization, Tsukuba, Ibaraki, 305-0801, Japan

#### Abstract

Generation of high-energy photons via collision of relativistic electron and laser beams is known as inverse Compton scattering or laser Compton scattering. Compton sources, photon sources based on Compton scattering, have been developed in the world to realize high-flux/high-brightness X-ray/gamma-ray sources and exploit applications with energy-tunable and narrow-bandwidth photon beams from these sources. Recent progress of electron accelerator and laser technologies will open a new era in Compton sources. An electron beam of small emittance and high-average current contributes to improving spectral brightness of Compton scattered photons. Flux of generating photons is also increased by a high-power laser together with apparatus such as laser enhancement cavity. We overview the current status of Compton sources including an experiment carried out at the Compact ERL, which is the first demonstration of Compton scattering by combination of an energy-recovery linac and a laser enhancement cavity.

© 2016 The Authors. Published by Elsevier B.V. This is an open access article under the CC BY-NC-ND license (http://creativecommons.org/licenses/by-nc-nd/4.0/).

Peer-review under responsibility of the organizing committee of SFR-2016.

Keywords:

#### 1. Introduction

High-energy photons are generated via Compton scattering of laser beams by relativistic electrons. Such phenomenon was originally studied in the context of basic science, energy loss for cosmic-ray electrons by scattering with photons of starlight, but now is considered as a practical method for high-energy photon generation after progress of laser and electron accelerator technologies (Krafft and Priebe (2010)). Compton sources are characterized by energy tunability, narrow bandwidth, short pulse and polarization and have been developed and utilized in a wide range of photon energies from keV to GeV with various types of electron accelerators. In the present paper, we summarize current status and future perspectives of Compton sources.

In most of Compton sources discussed here, scattering of laser photons in the electron rest frame is recognized as Thomson scattering, because a laser photon energy in the rest frame is much smaller than the electron rest mass. We use the term of Compton scattering, however, to represent high-energy photon sources based on collision of laser and electron beams in this article.

<sup>\*</sup> Corresponding author. Tel.: +81-70-3943-3449 ; fax: +81-29-287-1446. E-mail address: hajima.ryoichi@qst.go.jp

![](_page_1_Picture_2.jpeg)

Fig. 1. A schematic view of Compton scattering of a laser photon by a relativistic electron.

#### 2. Compton scattering of laser photons with relativistic electrons

Figure 1 is a schematic view of Compton scattering of a laser photon with a relativistic electron, where an electron with an energy of *Ee* collides with a laser photon with an energy of *E*<sup>1</sup> to produce a scattered photon with an energy of *E*2. The energy of scattered photon is given as

$$\epsilon_2 = \epsilon_1 \frac{1 - \beta \cos \theta_1}{1 - \beta \cos \theta_2 + (\epsilon_1 / \gamma_e)(1 - \cos \theta)},\tag{1}$$

where γ*<sup>e</sup>* = *Ee*/*mc*2, -<sup>1</sup> = *E*1/*mc*<sup>2</sup> and -<sup>2</sup> = *E*2/*mc*<sup>2</sup> are the electron, incident and scattered photon energies normalized by the electron rest mass, respectively, β is the electron velocity in units of light speed, θ<sup>1</sup> and θ<sup>2</sup> are the angles between the direction of motion of the electrons and incident and scattered photons, θ is the angle between the electron and scattered photons.

The energy of scattered photons is controllable in a wide range from keV to GeV, because it is a function of electron beam energy, laser photon energy and scattering geometry as seen in Eq.(1). Photons generated from Compton scattering inherit temporal structure and polarization from the electron and laser beams. Furthermore, the energy bandwidth of generated photons can be narrowed to be 10−<sup>2</sup> or less by putting an on-axis collimator to restrict scattering angle, θ in Fig.1. The bandwidth, however, has additional dilution due to inhomogeneous natures of electron and laser beams such as energy spread, diffraction and emittance. The inhomogeneous broadening of photon spectrum after an on-axis collimator is given as

$$\frac{\sigma_{\Delta\gamma}}{E_{\gamma}} = \sqrt{(\gamma_e \theta_{rms})^4 + \left(\frac{\sigma_{\Delta\gamma}}{E_{\gamma}}\right)_{inhomo.}^2},\tag{2}$$

where <sup>θ</sup>*rms* 1 is rms acceptance of the collimator and σΔ<sup>γ</sup> *E*γ *inhomo*. is inhomogeneous spectral dilution of Compton scattered photons due to energy spread and divergence of electron and laser beams, which is given by Petirillo et al. (2012):

$$\left(\frac{\sigma_{\Delta\gamma}}{E_{\gamma}}\right)_{inhomo.} = \sqrt{4\left(\frac{\sigma_{\Delta E}}{E_{e}}\right)^{2} + \left(\frac{\varepsilon_{n}}{\sigma_{e}}\right)^{4} + \left(\frac{\sigma_{\Delta E_{1}}}{E_{1}}\right)^{2} + \left(\frac{\lambda}{4\pi\sigma_{X}}\right)^{4}},\tag{3}$$

where σ<sup>Δ</sup>*<sup>E</sup>* and ε*<sup>n</sup>* are electron energy spread and normalized emittance, respectively, σ<sup>Δ</sup>*E*<sup>1</sup> , λ, are energy spread and wavelength of the incident laser photons, respectively. Detail studies of Compton scattering in the six-dimensional phase space has been conducted analytically and numerically (Brown et al. (2004); Hartemann et al. (2005); Sun and Wu (2011)), which show an electron beam with small emittance and small energy-spread is essential for obtaining narrow-bandwidth photon beams by Compton scattering.

These unique fetures of Compton sources: generation of energy-tunable, narrow-bandwidth, polarized and shortpulse photons are useful for various applications. In the following sections, we see typical applications of Compton sources from keV to GeV energies.

## 3. Compton sources for keV photons

Energy-tunable X-ray beams of narrow-bandwidth are available at synchrotron radiation from electron storage rings. Compton source can generate such X-ray beams with relatively low energy electrons from a small accelerator in comparison with synchrotron radiation.

A linac-based Compton source has been developed at National Institute of Advanced Industrial Science and Technology (Kuroda et al. (2011)). They employed a 42-MeV S-band linac equipped with a photocathode RF gun. For the laser Compton scattering, they use a Ti:Sapphire laser. The X-ray source has been used mainly for imaging applications such as phase contrast imaging of rat's lumber vertebra (Ikeura-Sekiguchi et al. (2008)) and K-shell absorption angiography of rabbit (Yamada et al. (2009)).

A compact X-ray source has been developed by utilizing an electron storage ring and a laser enhancement cavity at Lyncean Technologies (Loewen (2003)). In this apparatus, electrons of 25-45 MeV have head-on collision with Nd:YAG laser pulses stored in the cavity to produce X-ray beams. They recently reported monochromatic computed tomography of skeleton of a mouse with the X-ray source (Achterhold et al. (2013)).

## 4. Compton sources for MeV photons

Laser Compton scattering is the only practical method to produce energy-tunable and quasi-monoenergetic photon beams in MeV energies. Compton sources based on electron storage rings have been developed to provide MeV photons for application users. There are two user facilities providing MeV photons, NewSUBARU at Hyogo University and HIGS at Duke University. Laser pulses from external laser are introduced to an electron storage ring at NewSUB-ARU. The laser is CW or Q-switched at kHz repetition (Amano et al. (2009)). A free-electron laser is adopted for laser Compton scattering at HIGS (Weller et al. (2009)).

Photons of MeV energies can be used for studying nuclear physics, because they interact with nuclei via electromagnetic processes. Detection of photo-nuclear reaction such as (γ, *n*) and (γ, γ ) is a common approach to investigate nuclear structure and dynamics. These reaction can also be used for industrial applications. Non-destructive detection and measurement of fissile material utilizing nuclear resonance fluorescence (NRF) is one of the promising applications (Hajima et al. (2008)).

A linac-based laser Compton source is under construction at ELI-NP to produce MeV photons having higher spectral density than that from storage rings (Bacci et al. (2013)). The gamma source of ELI-NP produced Compton photons with tunable energy (1-20MeV), very narrow bandwidth (0.3%), and high spectral density (10<sup>4</sup> photons/s/eV).

A similar MeV photon source is under development at Lawrence Livermore National Laboratory (LLNL) for applications of nuclear resonance fluorescence (Albert et al. (2011)). Since the linac-based Compton source is free from electron bunch thermalization due to quantum recoil at Compton scattering, it has potential ability to produce Compton scattered photon beam of narrow bandwidth. Small duty factor of the linacs is compensated by high-density collision of electron and laser beams. Modern technology of photo-injector enables one to reduce the inhomogeneous spectral broadening of Compton scattered photons by colliding a small emittance electron beam with laser photons.

An energy recovery linac (ERL) is able to accelerate an electron beam of high-average current and small emittance. Energy-recovery linacs have been developed mainly for high-power free electron lasers and future synchrotron light sources but has advantages in Compton sources as well because the electron beam of high-average current and small emittance contribute directly to generation of high-flux and narrow-bandwidth X-ray and γ-ray via Compton scattering (Hajima (2010)). We see a result of Compton scattered photon generation at an ERL in Section 6.

#### 5. Compton sources for GeV photons

A beam-line to provide 1.5-3.0 GeV photons is opened to users at SPring-8 for studying hadron physics. In the beam line, GeV photons are generated from collision of Nd-YAG laser and 8-GeV electrons and have a flux of 10<sup>6</sup> ph/s (Fujiwara (2003); Niiyama (2013)). The GeV photons have a wide energy band, 1,5-3.0 GeV, but each photon energy is identified with an accuracy of 12 MeV (rms) by measuring energies of recoiled electrons.

Generation of a narrow-band GeV photon beam from an X-ray free electron laser oscillator (XFELO) was recently proposed (Hajima and Fujiwara (2016)). In this proposal, a 7-GeV electron beam operated at 3-MHz repetition is utilized for an X-ray FEL oscillator, in which 7-GeV  $\gamma$ -ray photons with extremely narrow bandwidth,  $\sim 0.1\%$  (FWHM), and a high spectral density,  $\sim 10^2$  ph/(MeV s) are produced by Compton scattering. The flux can be improved by increasing the electron bunch repetition or by enlarging the number of X-ray photons stored in the oscillator up to the limit of thermal deformation of the crystal mirrors. The energy of  $\gamma$ -ray is tunable by varying the electron beam energy as far as XFELO is lasing. The XFELO- $\gamma$  will open a new opportunity for studying the charmed quark (c-quark) production dynamics from proton and neutron which mainly consist of u- and d-quarks.

#### 6. Development of an ERL-based Compton source

An energy-recovery linac combined with a laser enhancement cavity is an ideal apparatus to realize a high-flux and narrow-bandwidth Compton source. An ERL-based Compton source to produce 2-MeV photons with a flux of  $10^{13}$  ph/s was designed for a nuclear industrial application, non-destructive assay of nuclear materials (Hajima et al. (2009)). In order to develop technologies necessary for such future ERL-based Compton sources, a research program was established in Japan. In this program, generation of Compton scattered photon beam from an energy-recovery linac was demonstrated at the Compact ERL. The Compact ERL is a facility of energy-recovery linac constructed as a test bed for future ERL-based photon sources such as synchrotron X-ray, high-power FELs and Compton sources (Sakanaka et al. (2015)). In this section, experimental results of X-ray generation at the Compact ERL are briefly summarized.

The Compact ERL (cERL) consists of an injector equipped with a 500-kV photocathode DC gun, a superconducting main linac and a recirculation loop for energy recovery. For high-flux LCS photon generation at the cERL, a high-finesse laser enhancement cavity of a 4-mirror bow-tie shape was developed and installed at the recirculation loop of the cERL. Laser pulses from a mode-locked laser were stacked inside the enhancement cavity to collide with electron bunches many times. The electron and laser beams had a repetition of 162.5 MHz, the 8th sub-harmonics of the fundamental frequency of the superconducting cavity. The electron beam current was limited to 0.1 mA at the experiment.

The electron beam was tightly focused at the collision point and precisely overlapped with the laser spot. Synchronization of the electron and laser beams were also established with an accuracy of 10 ps (rms). After these tunings, Compton scattered photons were measured by silicon drift X-ray detector located at an experimental area, 16 m away from the collision point. Table 1 summarize experimental parameters.

| Table 1. Experimental | parameters of Compt | ton scattering at the Compact ERL |
|-----------------------|---------------------|-----------------------------------|
|                       |                     |                                   |

| Electron beam   Laser beam                                 |                   |                                                  |               |
|------------------------------------------------------------|-------------------|--------------------------------------------------|---------------|
| Repetition Rate                                            | 162.5MHz          | Repetition Rate                                  | 162.5MHz      |
| Energy                                                     | 20 MeV            | Wavelength                                       | 1064 nm       |
| Bunch charge                                               | 0.355 pC          | Stored pulse energy                              | $61.5 \mu J$  |
| Average current                                            | 58 μA             | Stored power                                     | 10.4 kW       |
| Spot size at the collision $(\sigma_x/\sigma_y)$           | 78/16 μm          | Spot size at the collision $(\sigma_x/\sigma_y)$ | $24/32 \mu m$ |
| Normalized emittance $(\varepsilon_{nx}/\varepsilon_{ny})$ | 0.32/0.28 mm-mrad | Collision angle                                  | 18 degree     |
| Bunch length (rms)                                         | 2 ps              | Stored pulse width (rms)                         | 10 ps         |

In the experiment, X-ray photon energy was measured to be  $6.95 \pm 0.01$  keV and bandwidth for the detector half-opening angle, 0.14 mrad, was 0.4% (rms). The count rate of X-ray photons at the detector was 1370 cps, which corresponds to the source flux of  $(2.6 \pm 0.1) \times 10^7$  ph/s. These results are consistent with Monte Carlo simulations based on the experimental parameters including measured timing jitters between the electron and laser pulses and possible misalignment of the detector. Detail description of the experiment is seen elswhere (Akagi et al. (2016)).

The successful demonstration of Compton scattered X-ray generation at the cERL clearly shows that critical technologies for a high-flux and narrow-bandwidth Compton source have been established. The technologies cover a wide range: generation and transportation of a small emittance beam, stable operation of an energy-recovery linac, a laser cavity for enhancing laser pulse energy by several orders of magnitude, precise synchronization and spatial overlapping of electron and laser beams for collision. Another experiment with a 10-mA electron beam and a 100-kW laser beam is planned at the cERL to produce Compton scattered photons with a flux over 10<sup>11</sup> ph/s in near future.

## 7. Summary

Generation and applications of electromagnetic wave from relativistic electrons have been exploited in many forms. Compton source to produce energy-tunable high-energy photons with narrow-bandwidth and arbitrary polarization is a unique apparatus especially in photon energies of MeV and GeV. Two key technologies in the Compton source, the electron accelerator and the laser, have been matured for these decades and still keep on evolving to improve Compton sources in their flux and bandwidth, which will open a new era of photonuclear science and industrial applications of high-energy photons.

## Acknowledgments

This study is supported in part by a Government (MEXT) Subsidy for Strengthening Nuclear Security and by Photon and Quantum Basic Research Coordinated Development Program of MEXT, Japan.

## References

- G.A. Krafft and G. Priebe, Rev. Accl. Sci. Tech. 03, 147 (2010).
- V. Petrillo *et al.*, Nucl. Instr. Meth. A 693, 109 (2012).
- W.J. Brown and F.V. Hartemann, Phys. Rev. ST-AB 7, 060703 (2004).
- C. Sun and Y.K. Wu, Phys. Rev. ST-AB 14, 044701 (2011).
- F.V. Hartemann *et al.*, Phys. Rev. ST-AB 8, 100702 (2005).
- R. Kuroda et al., Nucl. Instr. Meth. A 637, S183 (2011).
- H. Ikeura-Sekiguchi et al., Appl. Phys. Lett. 92, 131107 (2008).
- K. Yamada et al., Nucl. Instr. Meth. A 608, S7 (2009)
- R. Loewen, A compact light source : Design and technical feasibility study of a LASER-electron storage ring X-ray source. Ph.D. thesis, Stanford University (2003).
- K. Achterhold, M. Bech, S. Schleede, G. Potdevin, R. Ruth, R. Loewen, F. Pfeiffer, Sci. Rep. 3, 1313 (2013).
- S. Amano et al., Nucl. Instr. Meth. A 602, 337-341 (2009).
- H. R.Weller, M.W. Ahmed, H. Gao,W. Tornow,Y.K. Wu, M. Gai, and R. Miskimen, Prog. Part. Nucl. Phys. 62, 257 (2009).
- R. Hajima et al., J. Nucl. Sci. and Tech. 45, 441 (2008).
- A. Bacci et al., J. Appl. Phys. 113, 194508 (2013).
- F. Albert et al.m Phys. Rev. ST Accel. Beams 14, 050703 (2011).
- M. Fujiwara, Progress in Particle and Nuclear Physics, 50, 487-497 (2003).
- M. Niiyama, Nucl. Phys. A 914, 543 (2013).
- R. Hajima, Rev. Acc. Sci. and Tech. 3, 121-146 (2010).
- R. Hajima and M. Fujiwara, Phys. Rev. Accel. Beams 19, 020702 (2016).
- R. Hajima et al., Nucl. Instr. Meth. A 608, S57-S61 (2009).
- S. Sakanaka et al., Proc. 2015 Particle Accelerator Conference, Richmond, VA, 2015 (JACOW, Richmond, 2015), p.1359.
- T. Akagi et al., submitted.