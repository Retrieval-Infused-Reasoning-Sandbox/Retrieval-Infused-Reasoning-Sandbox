# THE

# PHYSICAL REVIEW

# A QUANTUM THEORY OF THE SCATTERING OF X-RAYS BY LIGHT ELEMENTS

By ARTHUR H. COMPTON

#### ABSTRACT

A quantum theory of the scattering of X-rays and  $\gamma$ -rays by light elements. -The hypothesis is suggested that when an X-ray quantum is scattered it spends all of its energy and momentum upon some particular electron. This electron in turn scatters the ray in some definite direction. The change in momentum of the X-ray quantum due to the change in its direction of propagation results in a recoil of the scattering electron. The energy in the scattered quantum is thus less than the energy in the primary quantum by the kinetic energy of recoil of the scattering electron. The corresponding increase in the wave-length of the scattered beam is  $\lambda_{\theta} - \lambda_{0} = (2h/mc) \sin^{2}\frac{1}{2}\theta = 0.0484 \sin^{2}\frac{1}{2}\theta$ , where h is the Planck constant, m is the mass of the scattering electron, c is the velocity of light, and  $\theta$  is the angle between the incident and the scattered ray. Hence the increase is independent of the wave-length. The distribution of the scattered radiation is found, by an indirect and not quite rigid method, to be concentrated in the forward direction according to a definite law (Eq. 27). The total energy removed from the primary beam comes out less than that given by the classical Thomson theory in the ratio  $I/(I+2\alpha)$ , where  $\alpha=h/mc\lambda_0$ =  $0.0242/\lambda_0$ . Of this energy a fraction  $(1 + \alpha)/(1 + 2\alpha)$  reappears as scattered radiation, while the remainder is truly absorbed and transformed into kinetic energy of recoil of the scattering electrons. Hence, if  $\sigma_0$  is the scattering absorption coefficient according to the classical theory, the coefficient according to this theory is  $\sigma = \sigma_0/(1 + 2\alpha) = \sigma_s + \sigma_a$ , where  $\sigma_s$  is the true scattering coefficient  $[(1 + \alpha)\sigma/(1 + 2\alpha)^2]$ , and  $\sigma_a$  is the coefficient of absorption due to scattering  $[\alpha\sigma/(1+2\alpha)^2]$ . Unpublished experimental results are given which show that for graphite and the Mo-K radiation the scattered radiation is longer than the primary, the observed difference  $(\lambda_{\pi/2} - \lambda_0 = .022)$ being close to the computed value .024. In the case of scattered  $\gamma$ -rays, the wave-length has been found to vary with  $\theta$  in agreement with the theory, increasing from .022 A (primary) to .068 A ( $\theta = 135^{\circ}$ ). Also the velocity of secondary  $\beta$ -rays excited in light elements by  $\gamma$ -rays agrees with the suggestion that they are recoil electrons. As for the predicted variation of absorption with A, Hewlett's results for carbon for wave-lengths below 0.5 A are in excellent agreement with this theory; also the predicted concentration in the forward direction is shown to be in agreement with the experimental results,

both for X-rays and  $\gamma$ -rays. This remarkable agreement between experiment and theory indicates clearly that scattering is a quantum phenomenon and can be explained without introducing any new hypothesis as to the size of the electron or any new constants; also that a radiation quantum carries with it momentum as well as energy. The restriction to light elements is due to the assumption that the constraining forces acting on the scattering electrons are negligible, which is probably legitimate only for the lighter elements.

Spectrum of K-rays from Mo scattered by graphite, as compared with the spectrum of the primary rays, is given in Fig. 4, showing the change of wavelength.

Radiation from a moving isotropic radiator.—It is found that in a direction  $\theta$  with the velocity,  $I_{\theta}/I' = (\mathbf{1} - \beta)^2/(\mathbf{1} - \beta \cos \theta)^4 = (\nu_{\theta}/\nu')^4$ . For the total radiation from a black body in motion to an observer at rest,  $I/I' = (T/T')^4 = (\nu_m/\nu_m')^4$ , where the primed quantities refer to the body at rest.

J. J. Thomson's classical theory of the scattering of X-rays, though supported by the early experiments of Barkla and others, has been found incapable of explaining many of the more recent experiments. This theory, based upon the usual electrodynamics, leads to the result that the energy scattered by an electron traversed by an X-ray beam of unit intensity is the same whatever may be the wave-length of the incident rays. Moreover, when the X-rays traverse a thin layer of matter, the intensity of the scattered radiation on the two sides of the layer should be the same. Experiments on the scattering of X-rays by light elements have shown that these predictions are correct when X-rays of moderate hardness are employed; but when very hard X-rays or  $\gamma$ -rays are employed, the scattered energy is found to be decidedly less than Thomson's theoretical value, and to be strongly concentrated on the emergent side of the scattering plate.

Several years ago the writer suggested that this reduced scattering of the very short wave-length X-rays might be the result of interference between the rays scattered by different parts of the electron, if the electron's diameter is comparable with the wave-length of the radiation. By assuming the proper radius for the electron, this hypothesis supplied a quantitative explanation of the scattering for any particular wave-length. But recent experiments have shown that the size of the electron which must thus be assumed increases with the wave-length of the X-rays employed, and the conception of an electron whose size varies with the wave-length of the incident rays is difficult to defend.

Recently an even more serious difficulty with the classical theory of X-ray scattering has appeared. It has long been known that secondary  $\gamma$ -rays are softer than the primary rays which excite them, and recent experiments have shown that this is also true of X-rays. By a spectroscopic examination of the secondary X-rays from graphite, I have, indeed,

<sup>&</sup>lt;sup>1</sup> A. H. Compton, Bull. Nat. Research Council, No. 20, p. 10 (Oct., 1922).

been able to show that only a small part, if any, of the secondary X-radiation is of the same wave-length as the primary. While the energy of the secondary X-radiation is so nearly equal to that calculated from Thomson's classical theory that it is difficult to attribute it to anything other than true scattering, these results show that if there is any scattering comparable in magnitude with that predicted by Thomson, it is of a greater wave-length than the primary X-rays.

Such a change in wave-length is directly counter to Thomson's theory of scattering, for this demands that the scattering electrons, radiating as they do because of their forced vibrations when traversed by a primary X-ray, shall give rise to radiation of exactly the same frequency as that of the radiation falling upon them. Nor does any modification of the theory such as the hypothesis of a large electron suggest a way out of the difficulty. This failure makes it appear improbable that a satisfactory explanation of the scattering of X-rays can be reached on the basis of the classical electrodynamics.

## THE QUANTUM HYPOTHESIS OF SCATTERING

According to the classical theory, each X-ray affects every electron in the matter traversed, and the scattering observed is that due to the combined effects of all the electrons. From the point of view of the quantum theory, we may suppose that any particular quantum of X-rays is not scattered by all the electrons in the radiator, but spends all of its energy upon some particular electron. This electron will in turn scatter the ray in some definite direction, at an angle with the incident beam. This bending of the path of the quantum of radiation results in a change in its momentum. As a consequence, the scattering electron will recoil with a momentum equal to the change in momentum of the X-ray. The energy in the scattered ray will be equal to that in the incident ray minus the kinetic energy of the recoil of the scattering electron; and since the scattered ray must be a complete quantum, the frequency will be reduced in the same ratio as is the energy. Thus on the quantum theory we should expect the wave-length of the scattered X-rays to be greater than that of the incident rays.

The effect of the momentum of the X-ray quantum is to set the

<sup>&</sup>lt;sup>1</sup> In previous papers (Phil. Mag. 41, 749, 1921; Phys. Rev. 18, 96, 1921) I have defended the view that the softening of the secondary X-radiation was due to a considerable admixture of a form of fluorescent radiation. Gray (Phil. Mag. 26, 611, 1913; Frank. Inst. Journ., Nov., 1920, p. 643) and Florance (Phil. Mag. 27, 225, 1914) have considered that the evidence favored true scattering, and that the softening is in some way an accompaniment of the scattering process. The considerations brought forward in the present paper indicate that the latter view is the correct one.

<sup>&</sup>lt;sup>2</sup> A. H. Compton, loc. cit., p. 16.

scattering electron in motion at an angle of less than 90° with the primary beam. But it is well known that the energy radiated by a moving body is greater in the direction of its motion. We should therefore expect, as is experimentally observed, that the intensity of the scattered radiation should be greater in the general direction of the primary X-rays than in the reverse direction.

The change in wave-length due to scattering.—Imagine, as in Fig. 1A,

![](_page_3_Picture_4.jpeg)

that an X-ray quantum of frequency  $\nu_0$  is scattered by an electron of mass m. The momentum of the incident ray will be  $h\nu_0/c$ , where c is the velocity of light and h is Planck's constant, and that of the scattered ray is  $h\nu_0/c$  at an angle  $\theta$  with the initial momentum. The principle of the conservation of momentum accordingly demands that the momentum of recoil of the scattering electron shall equal the vector difference between the momenta of these two rays, as in Fig. 1B. The momentum of the electron,  $m\beta c/\sqrt{1-\beta^2}$ , is thus given by the relation

$$\left(\frac{m\beta c}{\sqrt{1-\beta^2}}\right)^2 = \left(\frac{h\nu_0}{c}\right)^2 + \left(\frac{h\nu_\theta}{c}\right)^2 + 2\frac{h\nu_0}{c} \cdot \frac{h\nu_\theta}{c}\cos\theta,\tag{I}$$

where  $\beta$  is the ratio of the velocity of recoil of the electron to the velocity of light. But the energy  $h\nu_{\theta}$  in the scattered quantum is equal to that of the incident quantum  $h\nu_{\theta}$  less the kinetic energy of recoil of the scattering electron, *i.e.*,

$$h\nu_{\theta} = h\nu_{0} - mc^{2} \left( \frac{I}{\sqrt{I - \beta^{2}}} - I \right)$$
 (2)

We thus have two independent equations containing the two unknown quantities  $\beta$  and  $\nu_{\theta}$ . On solving the equations we find

$$\nu_{\theta} = \nu_0/(1 + 2\alpha \sin^2 \frac{1}{2}\theta), \tag{3}$$

where

$$\alpha = h\nu_0/mc^2 = h/mc\lambda_0. \tag{4}$$

Or in terms of wave-length instead of frequency,

$$\lambda_{\theta} = \lambda_0 + (2h/mc) \sin^2 \frac{1}{2}\theta. \tag{5}$$

It follows from Eq. (2) that  $I/(I-\beta^2)=\{I+\alpha[I-(\nu_\theta/\nu_0)]\}^2$ , or solving explicitly for  $\beta$ 

$$\beta = 2\alpha \sin \frac{1}{2}\theta \frac{\sqrt{1 + (2\alpha + \alpha^2) \sin^2 \frac{1}{2}\theta}}{1 + 2(\alpha + \alpha^2) \sin^2 \frac{1}{2}\theta}.$$
 (6)

Eq. (5) indicates an increase in wave-length due to the scattering process which varies from a few per cent in the case of ordinary X-rays tomore than 200 per cent in the case of  $\gamma$ -rays scattered backward. At the same time the velocity of the recoil of the scattering electron, as calculated from Eq. (6), varies from zero when the ray is scattered directly forward to about 80 per cent of the speed of light when a  $\gamma$ -ray is scattered at a large angle.

It is of interest to notice that according to the classical theory, if an X-ray were scattered by an electron moving in the direction of propagation at a velocity  $\beta'c$ , the frequency of the ray scattered at an angle  $\theta$  is given by the Doppler principle as

$$\nu_{\theta} = \nu_0 / \left( \mathbf{I} + \frac{2\beta'}{\mathbf{I} - \beta'} \sin^2 \frac{1}{2}\theta \right) . \tag{7}$$

It will be seen that this is of exactly the same form as Eq. (3), derived on the hypothesis of the recoil of the scattering electron. Indeed, if  $\alpha = \beta'/(1-\beta')$  or  $\beta' = \alpha/(1+\alpha)$ , the two expressions become identical. It is clear, therefore, that so far as the effect on the wave-length is concerned, we may replace the recoiling electron by a scattering electron moving in the direction of the incident beam at a velocity such that

$$\overline{\beta} = \alpha/(1+\alpha). \tag{8}$$

We shall call  $\beta c$  the "effective velocity" of the scattering electrons.

Energy distribution from a moving, isotropic radiator.—In preparation for the investigation of the spatial distribution of the energy scattered by a recoiling electron, let us study the energy radiated from a moving, isotropic body. If an observer moving with the radiating body draws a sphere about it, the condition of isotropy means that the probability is equal for all directions of emission of each energy quantum. That is, the probability that a quantum will traverse the sphere between the angles  $\theta'$  and  $\theta' + d\theta'$  with the direction of motion is  $\frac{1}{2} \sin \theta' d\theta'$ . But

the surface which the moving observer considers a sphere (Fig. 2A) is

![](_page_5_Picture_3.jpeg)

Fig. 2

considered by the stationary observer to be an oblate spheroid whose polar axis is reduced by the factor  $\sqrt{1-\beta^2}$ . Consequently a quantum of radiation which traverses the sphere at the angle  $\theta'$ , whose tangent is y'/x' (Fig. 2A), appears to the stationary observer to traverse the spheroid at an angle  $\theta''$  whose tangent is y''/x'' (Fig. 2B). Since  $x' = x''/\sqrt{1-\beta^2}$  and y' = y'', we have

$$\tan \theta' = y'/x' = \sqrt{1 - \beta^2} y''/x'' = \sqrt{1 - \beta^2} \tan \theta'', \tag{9}$$

and

$$\sin \theta' = \frac{\sqrt{1 - \beta^2} \tan \theta''}{\sqrt{1 + (1 - \beta^2) \tan^2 \theta''}}.$$
 (10)

![](_page_5_Picture_9.jpeg)

Fig. 3. The ray traversing the moving spheroid at P' at an angle  $\theta''$  reaches the stationary spherical surface drawn about O, at the point P, at an angle  $\theta$ .

Imagine, as in Fig. 3, that a quantum is emitted at the instant t = 0, when the radiating body is at O. If it traverses the moving observer's sphere at an angle  $\theta'$ , it traverses the corresponding oblate spheroid, imagined by the stationary observer to be moving with the body, at an angle  $\theta''$ . After I second, the quantum will have reached some point P on a sphere of radius c drawn about O, while the radiator will have moved a distance  $\beta c$ . The stationary observer at P therefore finds that the radiation is coming to him from the point O, at an angle  $\theta$  with the direction of motion. That is, if the moving observer considers the quantum to be emitted at an angle  $\theta'$  with the direction of motion, to the stationary observer the angle appears to be  $\theta$ , where

$$\sin \theta / \sqrt{1 + \beta^2 - 2\beta \cos \theta} = \sin \theta'', \tag{11}$$

and  $\theta''$  is given in terms of  $\theta'$  by Eq. (10). It follows that

$$\sin \theta' = \sin \theta \frac{\sqrt{1 - \beta^2}}{1 - \beta \cos \theta} \,. \tag{12}$$

On differentiating Eq. (12) we obtain

$$d\theta' = \frac{\sqrt{1-\beta^2}}{1-\beta\cos\theta}d\theta. \tag{13}$$

The probability that a given quantum will appear to the stationary observer to be emitted between the angles  $\theta$  and  $\theta + d\theta$  is therefore

$$P_{\theta}d\theta = P_{\theta'}d\theta' = \frac{1}{2}\sin\theta'd\theta'$$
,

where the values of  $\sin \theta'$  and  $d\theta'$  are given by Eqs. (12) and (13). Subsstituting these values we find

$$P_{\theta}d\theta = \frac{1 - \beta^2}{(1 - \beta \cos \theta)^2} \cdot \frac{1}{2} \sin \theta d\theta. \tag{14}$$

Suppose the moving observer notices that n' quanta are emitted per second. The stationary observer will estimate the rate of emission as

$$n^{\prime\prime}=n^{\prime}\sqrt{1-\beta^2},$$

quanta per second, because of the difference in rate of the moving and stationary clocks. Of these n'' quanta, the number which are emitted between angles  $\theta$  and  $\theta + d\theta$  is  $dn'' = n'' \cdot P_{\theta}d\theta$ . But if dn'' per second are emitted at the angle  $\theta$ , the number per second received by a stationary observer at this angle is  $dn = dn''/(1 - \beta \cos \theta)$ , since the radiator is approaching the observer at a velocity  $\beta \cos \theta$ . The energy of each quantum is, however,  $h\nu_{\theta}$ , where  $\nu_{\theta}$  is the frequency of the radiation as

received by the stationary observer. Thus the intensity, or the energy per unit area per unit time, of the radiation received at an angle  $\theta$  and a distance R is

$$I_{\theta} = \frac{h\nu_{\theta} \cdot dn}{2\pi R^{2} \sin \theta d\theta} = \frac{h\nu_{\theta}}{2\pi R^{2} \sin \theta d\theta} \frac{n'(\mathbf{I} - \beta^{2})^{3/2}}{(\mathbf{I} - \beta \cos \theta)^{3}} \frac{1}{2} \sin \theta d\theta$$

$$= \frac{n'h\nu_{\theta}}{4\pi R^{2}} \frac{(\mathbf{I} - \beta^{2})^{3/2}}{(\mathbf{I} - \beta \cos \theta)^{3}}.$$
(15)

If the frequency of the oscillator emitting the radiation is measured by an observer moving with the radiator as  $\nu'$ , the stationary observer judges its frequency to be  $\nu'' = \nu' \sqrt{1 - \beta^2}$ , and, in virtue of the Doppler effect, the frequency of the radiation received at an angle  $\theta$  is

$$\nu_{\theta} = \nu''/(1 - \beta \cos \theta) = \nu'[\sqrt{1 - \beta^2}/(1 - \beta \cos \theta)]. \tag{16}$$

Substituting this value of  $\nu_{\theta}$  in Eq. (15) we find

$$I_{\theta} = \frac{n'h\nu'}{4\pi R^2} \frac{(1-\beta^2)^2}{(1-\beta\cos\theta)^4} \,. \tag{17}$$

But the intensity of the radiation observed by the moving observer at a distance R from the source is  $I' = n'h\nu'/4\pi R^2$ . Thus,

$$I_{\theta} = I'[(\mathbf{I} - \beta)^2/(\mathbf{I} - \beta \cos \theta)^4] \tag{18}$$

is the intensity of the radiation received at an angle  $\theta$  with the direction of motion of an isotropic radiator, which moves with a velocity  $\beta c$ , and which would radiate with intensity I' if it were at rest.<sup>2</sup>

It is interesting to note, on comparing Eqs. (16) and (18), that

$$I_{\theta}/I' = (\nu_{\theta}/\nu')^4. \tag{19}$$

- <sup>1</sup> At first sight the assumption that the quantum which to the moving observer had energy  $h\nu'$  will be  $h\nu$  for the stationary observer seems inconsistent with the energy principle. When one considers, however, the work done by the moving body against the back-pressure of the radiation, it is found that the energy principle is satisfied. The conclusion reached by the present method of calculation is in exact accord with that which would be obtained according to Lorenz's equations, by considering the radiation to consist of electromagnetic waves.
- $^2$  G. H. Livens gives for  $I_\theta/I'$  the value  $(\mathbf{I} \boldsymbol{\beta} \cos \theta)^{-2}$  ("The Theory of Electricity," p. 600, 1918). At small velocities this value differs from the one here obtained by the factor  $(\mathbf{I} \boldsymbol{\beta} \cos \theta)^{-2}$ . The difference is due to Livens' neglect of the concentration of the radiation in the small angles, as expressed by our Eq. (14). Cunningham ("The Principle of Relativity," p. 60, 1914) shows that if a plane wave is emitted by a radiator moving in the direction of propagation with a velocity  $\boldsymbol{\beta}c$ , the intensity I received by a stationary observer is greater than the intensity I' estimated by the moving observer, in the ratio  $(\mathbf{I} \boldsymbol{\beta}^2)/(\mathbf{I} \boldsymbol{\beta})^2$ , which is in accord with the value calculated according to the methods here employed.

The change in frequency given in Eq. (16) is that of the usual relativity theory. I have not noticed the publication of any result which is the equivalent of my formula (18) for the intensity of the radiation from a moving body.

This result may be obtained very simply for the total radiation from a black body, which is a special case of an isotropic radiator. For, suppose such a radiator is moving so that the frequency of maximum intensity which to a moving observer is  $\nu_m$  appears to the stationary observer to be  $\nu_m$ . Then according to Wien's law, the apparent temperature T, as estimated by the stationary observer, is greater than the temperature T' for the moving observer by the ratio  $T/T' = \nu_m/\nu_m$ . According to Stefan's law, however, the intensity of the total radiation from a black body is proportional to  $T^4$ ; hence, if I and I' are the intensities of the radiation as measured by the stationary and the moving observers respectively,

$$I/I' = (T/T')^4 = (\nu_m/\nu_m')^4.$$
 (20)

The agreement of this result with Eq. (19) may be taken as confirming the correctness of the latter expression.

The intensity of scattering from recoiling electrons.—We have seen that the change in frequency of the radiation scattered by the recoiling electrons is the same as if the radiation were scattered by electrons moving in the direction of propagation with an effective velocity  $\beta = \alpha/(1 + \alpha)$ , where  $\alpha = h/mc\lambda_0$ . It seems obvious that since these two methods of calculation result in the same change in wave-length, they must also result in the same change in intensity of the scattered beam. This assumption is supported by the fact that we find, as in Eq. 19, that the change in intensity is in certain special cases a function only of the change in frequency. I have not, however, succeeded in showing rigidly that if two methods of scattering result in the same relative wave-lengths at different angles, they will also result in the same relative intensity at different angles. Nevertheless, we shall assume that this proposition is true, and shall proceed to calculate the relative intensity of the scattered beam at different angles on the hypothesis that the scattering electrons are moving in the direction of the primary beam with a velocity  $\beta = \alpha/(1 + \alpha)$ . If our assumption is correct, the results of the calculation will apply also to the scattering by recoiling electrons.

To an observer moving with the scattering electron, the intensity of the scattering at an angle  $\theta'$ , according to the usual electrodynamics, should be proportional to  $(\mathbf{I} + \cos^2 \theta')$ , if the primary beam is unpolarized. On the quantum theory, this means that the probability that a quantum will be emitted between the angles  $\theta'$  and  $\theta' + d\theta'$  is proportional to  $(\mathbf{I} + \cos^2 \theta') \sin \theta' d\theta'$ , since  $2\pi \sin \theta' d\theta'$  is the solid angle included between  $\theta'$  and  $\theta' + d\theta'$ . This may be written  $P_{\theta'}d\theta' = k(\mathbf{I} + \cos^2 \theta') \sin \theta' d\theta'$ .

The factor of proportionality k may be determined by performing the integration

$$\int_0^{\pi} P_{\theta'} d\theta' = k \int_0^{\pi} (\mathbf{I} + \cos^2 \theta') \sin \theta' d\theta' = \mathbf{I},$$

with the result that k = 3/8. Thus

$$P_{\theta'}d\theta' = (3/8)(1 + \cos^2 \theta') \sin \theta' d\theta' \tag{21}$$

is the probability that a quantum will be emitted at the angle  $\theta'$  as measured by an observer moving with the scattering electron.

To the stationary observer, however, the quantum ejected at an angle  $\theta'$  appears to move at an angle  $\theta$  with the direction of the primary beam, where  $\sin \theta'$  and  $d\theta'$  are as given in Eqs. (12) and (13). Substituting these values in Eq. (21), we find for the probability that a given quantum will be scattered between the angles  $\theta$  and  $\theta + d\theta$ ,

$$P_{\theta}d\theta = \frac{3}{8}\sin\theta d\theta \frac{(1-\beta^2)\{(1+\beta^2)(1+\cos^2\theta) - 4\beta\cos\theta\}}{(1-\beta\cos\theta)^4}.$$
 (22)

Suppose the stationary observer notices that n quanta are scattered per second. In the case of the radiator emitting n'' quanta per second while approaching the observer, the n''th quantum was emitted when the radiator was nearer the observer, so that the interval between the receipt of the 1st and the n''th quantum was less than a second. That is, more quanta were received per second than were emitted in the same time. In the case of scattering, however, though we suppose that each scattering electron is moving forward, the nth quantum is scattered by an electron starting from the same position as the 1st quantum. Thus the number of quanta received per second is also n.

We have seen (Eq. 3) that the frequency of the quantum received at an angle  $\theta$  is  $\nu_{\theta} = \nu_{0}/(1 + 2\alpha \sin^{2}\frac{1}{2}\theta) = \nu_{0}/\{1 + \alpha(1 - \cos\theta)\}$ , where  $\nu_{0}$ , the frequency of the incident beam, is also the frequency of the ray scattered in the direction of the incident beam. The energy scattered per second at the angle  $\theta$  is thus  $nh\nu_{\theta}P_{\theta}d\theta$ , and the intensity, or energy per second per unit area, of the ray scattered to a distance R is

$$\begin{split} I_{\theta} &= \frac{nhv_{\theta}P_{\theta}d\theta}{2\pi R^2\sin\theta d\theta} \\ &= \frac{nh}{2\pi R^2} \cdot \frac{v_0}{1+\alpha(1-\cos\theta)} \cdot \frac{3}{8} \cdot \frac{(1-\beta^2)\{(1+\beta^2)(1+\cos^2\theta)-4\beta\cos\theta\}}{(1-\beta\cos\theta)^4} \; . \end{split}$$

Substituting for  $\beta$  its value  $\alpha/(1 + \alpha)$ , and reducing, this becomes

$$I = \frac{3nh\nu_0}{16\pi R} \frac{(1+2\alpha)\{1+\cos^2\theta+2\alpha(1+\alpha)(1-\cos\theta)^2\}}{(1+\alpha-\alpha\cos\theta)^5}.$$
 (23)

In the forward direction, where  $\theta = 0$ , the intensity of the scattered beam is thus

$$I_0 = \frac{3}{8\pi} \frac{nh\nu_0}{R^2} (I + 2\alpha). \tag{24}$$

Hence

$$\frac{I_{\theta}}{I_0} = \frac{I}{2} \frac{I + \cos^2 \theta + 2\alpha (I + \alpha) (I - \cos \theta)^2}{\{I + \alpha (I - \cos \theta)\}^5}$$
 (25)

On the hypothesis of recoiling electrons, however, for a ray scattered directly forward, the velocity of recoil is zero (Eq. 6). Since in this case the scattering electron is at rest, the intensity of the scattered beam should be that calculated on the basis of the classical theory, namely,

$$I_0 = I(Ne^4/R^2m^2c^4), (26)$$

where I is the intensity of the primary beam traversing the N electrons which are effective in scattering. On combining this result with Eq. (25), we find for the intensity of the X-rays scattered at an angle  $\theta$  with the incident beam,

$$I = I \frac{Ne^4}{2R^2m^2c^4} \frac{I + \cos^2\theta + 2\alpha(I + \alpha)(I - \cos\theta)^2}{\{I + \alpha(I - \cos\theta)\}^5}$$
 (27)

The calculation of the energy removed from the primary beam may now be made without difficulty. We have supposed that n quanta are scattered per second. But on comparing Eqs. (24) and (26), we find that

$$n = \frac{8\pi}{3} \frac{INe^4}{h\nu_0 m^2 c^4 (1 + 2\alpha)}.$$

The energy removed from the primary beam per second is  $nh\nu_0$ . If we define the scattering absorption coefficient as the fraction of the energy of the primary beam removed by the scattering process per unit length of path through the medium, it has the value

$$\sigma = \frac{nh\nu_0}{I} = \frac{8\pi}{3} \frac{Ne^4}{m^2 c^4} \cdot \frac{I}{I + 2\alpha} = \frac{\sigma_0}{I + 2\alpha},$$
 (28)

where N is the number of scattering electrons per unit volume, and  $\sigma_0$  is the scattering coefficient calculated on the basis of the classical theory.

In order to determine the total energy truly scattered, we must integrate the scattered intensity over the surface of a sphere surrounding the scattering material, i.e.,  $\epsilon_s = \int_0^{\pi} I_{\theta} \cdot 2\pi R^2 \sin \theta d\theta$ . On substituting the value of  $I_{\theta}$  from Eq. (27), and integrating, this becomes

$$\epsilon_s = \frac{8\pi}{3} \frac{INe^4}{m^2c^4} \frac{1+\alpha}{(1+2\alpha)^2} \cdot$$

<sup>1</sup> Cf. J. J. Thomson, "Conduction of Electricity through Gases," 2d ed., p. 325.

The true scattering coefficient is thus

$$\sigma_{s} = \frac{8\pi}{3} \frac{Ne^{4}}{m^{2}c^{4}} \frac{1+\alpha}{(1+2\alpha)^{2}} = \sigma_{0} \frac{1+\alpha}{(1+2\alpha)^{2}}.$$
 (29)

It is clear that the difference between the total energy removed from the primary beam and that which reappears as scattered radiation is the energy of recoil of the scattering electrons. This difference represents, therefore, a type of true absorption resulting from the scattering process. The corresponding *coefficient of true absorption due to scattering* is

$$\sigma_a = \sigma - \sigma_s = \frac{8\pi}{3} \frac{Ne^4}{m^2 c^4} \frac{\alpha}{(1+2\alpha)^2} = \sigma_0 \frac{\alpha}{(1+2\alpha)^2}$$
 (30)

### EXPERIMENTAL TEST.

Let us now investigate the agreement of these various formulas with exper ments on the change of wave-length due to scattering, and on the magnitude of the scattering of X-rays and  $\gamma$ -rays by light elements.

Wave-length of the scattered rays.—If in Eq. (5) we substitute the accepted values of h, m, and c, we obtain

$$\lambda_{\theta} = \lambda_0 + 0.0484 \sin^2 \frac{1}{2}\theta,\tag{31}$$

if λ is expressed in Angström units. It is perhaps surprising that the increase should be the same for all wave-lengths. Yet, as a result of an extensive experimental study of the change in wave-length on scattering, the writer has concluded that "over the range of primary rays from 0.7 to 0.025 A, the wave-length of the secondary X-rays at 90° with the incident beam is roughly 0.03 A greater than that of the primary beam which excites it." <sup>1</sup> Thus the experiments support the theory in showing a wave-length increase which seems independent of the incident wavelength, and which also is of the proper order of magnitude.

A quantitative test of the accuracy of Eq. (31) is possible in the case of the characteristic K-rays from molybdenum when scattered by graphite. In Fig. 4 is shown a spectrum of the X-rays scattered by graphite at right angles with the primary beam, when the graphite is traversed by X-rays from a molybdenum target.<sup>2</sup> The solid line represents the spectrum of these scattered rays, and is to be compared with the broken line, which represents the spectrum of the primary rays, using the same slits and crystal, and the same potential on the tube. The primary spectrum is, of course, plotted on a much smaller scale than

<sup>&</sup>lt;sup>1</sup> A. H. Compton, Bull. N. R. C., No. 20, p. 17 (1922).

<sup>&</sup>lt;sup>2</sup> It is hoped to publish soon a description of the experiments on which this figure is based.

the secondary. The zero point for the spectrum of both the primary and secondary X-rays was determined by finding the position of the first order lines on both sides of the zero point.

![](_page_12_Figure_3.jpeg)

Fig. 4. Spectrum of molybdenum X-rays scattered by graphite, compared with the spectrum of the primary X-rays, showing an increase in wave-length on scattering.

It will be seen that the wave-length of the scattered rays is unquestionably greater than that of the primary rays which excite them. Thus the  $K\alpha$  line from molybdenum has a wave-length 0.708 A. The wave-length of this line in the scattered beam is found in these experiments, however, to be 0.730 A. That is,

$$\lambda_{\theta} - \lambda_0 = 0.022 \text{ A}$$
 (experiment).

But according to the present theory (Eq. 5),

$$\lambda_{\theta} - \lambda_{0} = 0.0484 \sin^{2} 45^{\circ} = 0.024 \text{ A}$$
 (theory),

which is a very satisfactory agreement.

The variation in wave-length of the scattered beam with the angle is illustrated in the case of  $\gamma$ -rays. The writer has measured <sup>1</sup> the mass absorption coefficient in lead of the rays scattered at different angles when various substances are traversed by the hard  $\gamma$ -rays from RaC. The mean results for iron, aluminium and paraffin are given in column 2 of Table I. This variation in absorption coefficient corresponds to a

<sup>&</sup>lt;sup>1</sup> A. H. Compton, Phil. Mag. 41, 760 (1921).

difference in wave-length at the different angles. Using the value given by Hull and Rice for the mass absorption coefficient in lead for wavelength 0.122, 3.0, remembering  $^1$  that the characteristic fluorescent absorption  $\tau/\rho$  is proportional to  $\lambda^3$ , and estimating the part of the absorption due to scattering by the method described below, I find for the wave-lengths corresponding to these absorption coefficients the values given in the fourth column of Table I. That this extrapolation is very

Table I Wave-length of Primary and Scattered  $\gamma$ -rays

|         | Angle | $\mu/\rho$ | au/ ho | λ obs.  | λ calc.   |
|---------|-------|------------|--------|---------|-----------|
| Primary | o°    | .076       | .017   | 0.022 A | (0.022 A) |
|         | 45°   | .10        | ,042   | .030    | 0.029     |
|         | 90°   | .21        | ,123   | .043    | 0.047     |
|         | 135°  | .59        | ,502   | .068    | 0.063     |

nearly correct is indicated by the fact that it gives for the primary beam a wave-length 0.022 A. This is in good accord with the writer's value 0.025 A, calculated from the scattering of  $\gamma$ -rays by lead at small angles,² and with Ellis' measurements from his  $\beta$ -ray spectra, showing lines of wave-length .045, .025, .021 and .020 A, with line .020 the strongest.³ Taking  $\lambda_0 = 0.022$  A, the wave-lengths at the other angles may be calculated from Eq. (31). The results, given in the last column of Table I., and shown graphically in Fig. 5, are in satisfactory accord with the measured values. There is thus good reason for believing that Eq. (5) represents accurately the wave-length of the X-rays and  $\gamma$ -rays scattered by light elements.

Velocity of recoil of the scattering electrons.—The electrons which recoil in the process of the scattering of ordinary X-rays have not been observed. This is probably because their number and velocity is usually small compared with the number and velocity of the photoelectrons ejected as a result of the characteristic fluorescent absorption. I have pointed out elsewhere, however, that there is good reason for believing that most of the secondary  $\beta$ -rays excited in light elements by the action of  $\gamma$ -rays are such recoil electrons. According to Eq. (6), the velocity of these electrons should vary from 0, when the  $\gamma$ -ray is scattered forward, to  $v_{\text{max}} = \beta_{\text{max}} c = 2c\alpha[(1 + \alpha)/(1 + 2\alpha + 2\alpha^2)]$ , when the  $\gamma$ -ray quantum

<sup>&</sup>lt;sup>1</sup> Cf. L. de Broglie, Jour. de Phys. et Rad. 3, 33 (1922); A. H. Compton, Bull. N. R. C., No. 20, p. 43 (1922).

<sup>&</sup>lt;sup>2</sup> A. H. Compton, Phil. Mag. **41**, 777 (1921).

<sup>&</sup>lt;sup>8</sup> C. D. Ellis, Proc. Roy. Soc. A, 101, 6 (1922).

<sup>&</sup>lt;sup>4</sup> A. H. Compton, Bull. N. R. C., No. 20, p. 27 (1922).

is scattered backward. If for the hard  $\gamma$ -rays from radium C,  $\alpha = 1.09$ , corresponding to  $\lambda = 0.022$  A, we thus obtain  $\beta_{max} = 0.82$ . The effective velocity of the scattering electrons is, therefore (Eq. 8),  $\bar{\beta} = 0.52$ . These results are in accord with the fact that the average velocity of the

![](_page_14_Figure_3.jpeg)

Fig. 5. The wave-length of scattered  $\gamma$ -rays at different angles with the primary beam, showing an increase at large angles similar to a Doppler effect.

 $\beta$ -rays excited by the  $\gamma$ -rays from radium is somewhat greater than half that of light.<sup>1</sup>

Absorption of X-rays due to scattering.—Valuable information concerning the magnitude of the scattering is given by the measurements of the absorption of X-rays due to scattering. Over a wide range of wavelengths, the formula for the total mass absorption,  $\mu/\rho = \kappa\lambda^3 + \sigma/\rho_r$  is found to hold, where  $\mu$  is the linear absorption coefficient,  $\rho$  is the density,  $\kappa$  is a constant, and  $\sigma$  is the energy loss due to the scattering process. Usually the term  $\kappa\lambda^3$ , which represents the fluorescent absorption, is the more important; but when light elements and short wavelengths are employed, the scattering process accounts for nearly all the energy loss. In this case, the constant  $\kappa$  can be determined by measurements on the longer wave-lengths, and the value of  $\sigma/\rho$  can then be estimated with considerable accuracy for the shorter wave-lengths from the observed values of  $\mu/\rho$ .

Hewlett has measured the total absorption coefficient for carbon over a wide range of wave-lengths.<sup>2</sup> From his data for the longer wave-

<sup>&</sup>lt;sup>1</sup> E. Rutherford, Radioactive Substances and their Radiations, p. 273.

<sup>&</sup>lt;sup>2</sup> C. W. Hewlett, Phys. Rev. 17, 284 (1921).

lengths I estimate the value of  $\kappa$  to be 0.912, if  $\lambda$  is expressed in A. On subtracting the corresponding values of  $\kappa\lambda^3$  from his observed values of  $\mu/\rho$ , the values of  $\sigma/\rho$  represented by the crosses of Fig. 6 are obtained.

![](_page_15_Figure_3.jpeg)

Fig. 6. The absorption in carbon due to scattering, for homogeneous X-rays.

The value of  $\sigma_0/\rho$  as calculated for carbon from Thomson's formula is shown by the horizontal line at  $\sigma/\rho=0.201$ . The values of  $\sigma/\rho$  calculated from Eq. (28) are represented by the solid curve. The circle shows the experimental value of the total absorption of  $\gamma$ -rays by carbon, which on the present view is due wholly to the scattering process.

For wave-lengths less than 0.5 A, where the test is most significant, the agreement is perhaps within the experimental error. Experiments by Owen, <sup>1</sup> Crowther, <sup>2</sup> and Barkla and Ayers <sup>3</sup> show that at about 0.5 A the "excess scattering" begins to be appreciable, increasing rapidly in importance at the longer wave-lengths.<sup>4</sup> It is probably this effect which results in the increase of the scattering absorption above the theoretical value for the longer wave-lengths. Thus the experimental values of the absorption due to scattering seem to be in satisfactory accord with the present theory.

True absorption due to scattering has not been noticed in the case of

- <sup>1</sup> E. A. Owen, Proc. Camb. Phil. Soc. 16, 165 (1911).
- <sup>2</sup> J. A. Crowther, Proc. Roy. Soc. **86**, 478 (1912).
- <sup>3</sup> Barkla and Ayers, Phil. Mag. 21, 275 (1911).
- <sup>4</sup> Cf. A. H. Compton, Washington University Studies, 8, 109 ff. (1921).

X-rays. In the case of hard  $\gamma$ -rays, however, Ishino has shown that there is true absorption as well as scattering, and that for the lighter elements the true absorption is proportional to the atomic number. That is, this absorption is proportional to the number of electrons present, just as is the scattering. He gives for the true mass absorption coefficient of the hard  $\gamma$ -rays from RaC in both aluminium and iron the value 0.021. According to Eq. (30), the true mass absorption by aluminium should be 0.021 and by iron, 0.020, taking the effective wave-length of the rays to be 0.022 A. The difference between the theory and the experiments is less than the probable experimental error.

Ishino has also estimated the true mass scattering coefficients of the hard  $\gamma$ -rays from RaC by aluminium and iron to be 0.045 and 0.042 respectively.² These values are very far from the values 0.193 and 0.187 predicted by the classical theory. But taking  $\lambda = 0.022$  A, as before, the corresponding values calculated from Eq. (29) are 0.040 and 0.038, which do not differ seriously from the experimental values.

It is well known that for soft X-rays scattered by light elements the total scattering is in accord with Thomson's formula. This is in agreement with the present theory, according to which the true scattering coefficient  $\sigma_s$  approaches Thomson's value  $\sigma_0$  when  $\alpha \equiv h/mc\lambda$  becomes small (Eq. 29).

The relative intensity of the X-rays scattered in different directions with the primary beam.—Our Eq. (27) predicts a concentration of the energy in the forward direction. A large number of experiments on the scattering of X-rays have shown that, except for the excess scattering at small angles, the ionization due to the scattered beam is symmetrical on the emergence and incidence sides of a scattering plate. The difference in intensity on the two sides according to Eq. (27) should, however, be noticeable. Thus if the wave-length is 0.7 A, which is probably about that used by Barkla and Ayers in their experiments on the scattering by carbon, the ratio of the intensity of the rays scattered at 40° to that at 140° should be about 1.10. But their experimental ratio was 1.04, which differs from our theory by more than their probable experimental error.

It will be remembered, however, that our theory, and experiment also, indicates a difference in the wave-length of the X-rays scattered in different directions. The softer X-rays which are scattered backward are the more easily absorbed and, though of smaller intensity, may produce an

<sup>&</sup>lt;sup>1</sup> M. Ishino, Phil. Mag. 33, 140 (1917).

<sup>&</sup>lt;sup>2</sup> M. Ishino, loc. cit.

<sup>&</sup>lt;sup>3</sup> Barkla and Ayers, loc. cit.

ionization equal to that of the beam scattered forward. Indeed, if  $\alpha$  is small compared with unity, as is the case for ordinary X-rays, Eq. (27) may be written approximately  $I_{\theta}/I_{\theta}' = (\lambda_0/\lambda_{\theta})^3$ , where  $I_{\theta}'$  is the intensity of the beam scattered at the angle  $\theta$  according to the classical theory. The part of the absorption which results in ionization is however proportional to  $\lambda^3$ . Hence if, as is usually the case, only a small part of the X-rays entering the ionization chamber is absorbed by the gas in the chamber, the ionization is also proportional to  $\lambda^3$ . Thus if  $i_{\theta}$ represents the ionization due to the beam scattered at the angle  $\theta$ , and if  $i_{\theta}'$  is the corresponding ionization on the classical theory, we have  $i_{\theta}/i_{\theta}' = (I_{\theta}/I_{\theta}')(\lambda_{\theta}/\lambda_{0})^{3} = I$ , or  $i_{\theta} = i_{\theta}'$ . That is, to a first approximation, the ionization should be the same as that on the classical theory, though the energy in the scattered beam is less. This conclusion is in good accord with the experiments which have been performed on the scattering of ordinary X-rays, if correction is made for the excess scattering which appears at small angles.

![](_page_17_Figure_3.jpeg)

Fig. 7. Comparison of experimental and theoretical intensities of scattered  $\gamma$ -rays.

In the case of very short wave-lengths, however, the case is different. The writer has measured the p-rays scattered at different angles by iron, using an ionization chamber so designed as to absorb the greater part of even the primary p-ray beam. It is not cl'ear just how the ionization due to the y-rays will vary with the wave-length under the conditions of the experiment, but it appears probable that the variation will not be great. If we suppose accordingly that the ionization measures the intensity of the scattered y-ray beam, these data for the intensity are represented by the circles in Fig. 7. The experiments showed that the intensity at 90 was 0.074 times that predicted by the classical theory, or 0.<sup>037</sup> Ip, where Ip is the intensity of the scattering at the angle <sup>0</sup> = 0 as calculated on either the classical or the quantum theory. The absolute intensities of the scattered beam are accordingly plotted us'ing Ip as the unit. The solid curve shows the intensity in the same units, calculated according to Eq. (2p). As before, the wave-length of the y-rays is taken as 0.022 A. The beautiful agreement between the theoretical and the experimental values of the scattering is the more striking when one notices that there is not a singl'e adjustable constant connecting the two sets of values.

# DiscvssroN

This remarkable agreement between our formulas and the experiments can leave but little doubt that the scattering of X-rays is a quantum phenomenon. The hypothesis of a large electron to explain these effects is accordingly superfIuous, for all the experiments on X-ray scattering to which this hypothesis has been applied are now seen to be explicable from the point of view of the quantum theory without introducing any new hypotheses or constants. In addition, the present theory accounts satisfactorily for the change in wave-length due to scattering, which was left unaccounted for on the hypothesis of the large electron. From the standpoint of the scattering of X-rays and p-rays, 'therefore, there is no longer any support for the hypothesis of an electron whose diameter is comparable with the wave-length of hard X-rays.

The present theory depends essentially upon the assumption that each electron which is effective in the scattering scatters a complete quantum. It involves also the hypothesis that the quanta of radiation are received from definite directions and are scattered in definite directions. The experimental support of the theory indicates very convincingly that a radiation quantum carries with it directed momentum as well as energy.

Emphasis has been laid upon the fact that in its present form the A. H. Compton, Phil. Mag. 41, p58 (192').

quantum theory of scattering applies only to light elements. The reason for this restriction is that we have tacitly assumed that there are no forces of constraint acting upon the scattering electrons. This assumption is probably legitimate in the case of the very light elements, but cannot be true for the heavy elements. For if the kinetic energy of recoil of an electron is less than the energy required to remove the electron from the atom, there is no chance for the electron to recoil in the manner we have supposed. The conditions of scattering in such a case remain to be investigated.

The manner in which interference occurs, as for example in the cases of excess scattering and X-ray reflection, is not yet clear. Perhaps if an electron is bound in the atom too firmly to recoil, the incident quantum of radiation may spread itself. over a large number of electrons, distributing its .energy and momentum among them, thus making interference possible. In any case, the problem of scattering is so closely allied with those of reHection and interference that a study of the problem may very possibly shed some light upon the difficult question of the relation between interference and the quantum theory.

Many of the ideas involved in this paper have been developed in discussion with Professor G. E. M. Janncey of this department.

WASHINGTON UNIVERSITY) SAINT LOUIS, December I g, I922