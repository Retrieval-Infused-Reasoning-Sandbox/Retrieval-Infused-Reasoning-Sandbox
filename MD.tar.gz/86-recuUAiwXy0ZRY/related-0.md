# DAVID WILLIAMS

# Probability with Martingales

CAMBRIDGE MATHEMATICAL TEXTBOOKS

# Probability with Martingales

# Probability with Martingales

David Williams *Statistical Laboratory, DPMMS Cambridge University*

![](_page_4_Picture_2.jpeg)

cambridge university press

Cambridge, New York, Melbourne, Madrid, Cape Town, Singapore, Sa~ o Paulo, Delhi, Mexico City

Cambridge University Press

The Edinburgh Building, Cambridge CB2 8RU, UK

Published in the United States of America by Cambridge University Press, New York

<www.cambridge.org>

Information on this title:<www.cambridge.org/9780521406055>

© Cambridge University Press 1991

and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press. This publication is in copyright. Subject to statutory exception

First published 1991 15th printing 2012

Printed in the United Kingdom at the University Press, Cambridge

*A catalogue record for this publication is available from the British Library*

ISBN 978-0-521-40605-5 Paperback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party internet websites referred to in this publication, and does not guarantee that any content on such websites is, or will remain, accurate or appropriate.

# Contents

Preface - please read!

Chapter 2: Events

A Question of Terminology

| A Guide to Notation                                                                                                                                                                                                                                                                                                                                             | xiv          |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|
| Chapter 0: A Branching-Process Example                                                                                                                                                                                                                                                                                                                          | 1            |
| 0.0. Introductory remarks. 0.1. Typical number of children, $X$ . 0.2. So of $n^{\text{th}}$ generation, $Z_n$ . 0.3. Use of conditional expectations. 0.4. Extinct probability, $\pi$ . 0.5. Pause for thought: measure. 0.6. Our first marting 0.7. Convergence (or not) of expectations. 0.8. Finding the distribution $M_{\infty}$ . 0.9. Concrete example. | tion<br>ale. |
| PART A: FOUNDATIONS                                                                                                                                                                                                                                                                                                                                             |              |
| Chapter 1: Measure Spaces                                                                                                                                                                                                                                                                                                                                       | 14           |
| 1.0. Introductory remarks. 1.1. Definitions of algebra, $\sigma$ -algebra. 1.2. amples. Borel $\sigma$ -algebras, $\mathcal{B}(S)$ , $\mathcal{B} = \mathcal{B}(R)$ . 1.3. Definitions concerns the functions. 1.4. Definition of measure space. 1.5. Definitions of                                                                                            | ning         |

cerning measures. 1.6. Lemma. Uniqueness of extension,  $\pi$ -systems. 1.7. Theorem. Carathéodory's extension theorem. 1.8. Lebesgue measure Leb on  $((0,1],\mathcal{B}(0,1])$ . 1.9. Lemma. Elementary inequalities. 1.10. Lemma. Monotone-convergence properties of measures. 1.11. Example/Warning.

xi

xiii

23

2.1. Model for experiment:  $(\Omega, \mathcal{F}, P)$ . 2.2. The intuitive meaning. 2.3. Examples of  $(\Omega, \mathcal{F})$  pairs. 2.4. Almost surely (a.s.) 2.5. Reminder:  $\limsup_{n \to \infty} E_n$ ,  $(E_n, i.o.)$ . 2.7.

Vl Content8

[First Borel-Cantelli Lemma \(BC1\). 2.8. Definitions. liminf](#page--1-0) En,(En,ev). [2.9. Exercise.](#page--1-0)

#### Chapter 3: Random Variables [29](#page--1-0)

[3.1. Definitions. L:-measurable function, mL:, \(mL:\)+,bL:. 3.2. Elementary](#page--1-0)  [Propositions on measurability.](#page--1-0) [3.3. Lemma. Sums and products of mea](#page--1-0)[surable functions are measurable. 3.4. Composition Lemma.](#page--1-0) [3.5. Lemma](#page--1-0)  [on measurability of infs, lim infs of functions.](#page--1-0) [3.6. Definition. Random](#page--1-0) [variable.](#page--1-0) [3. 7. Example. Coin tossing.](#page--1-0) [3.8. Definition. a-algebra generated](#page--1-0)  [by a collection of functions on](#page--1-0) n. [3.9. Definitions. Law, Distribution Func](#page--1-0)[tion. 3.10. Properties of distribution functions.](#page--1-0) [3.11. Existence of random](#page--1-0)  [variable with given distribution function.](#page--1-0) [3.12. Skorokod representation of](#page--1-0)  [a random variable with prescribed distribution function.](#page--1-0) [3.13. Generated](#page--1-0)  a-algebras- [a discussion.](#page--1-0) [3.14. The Monotone-Class Theorem.](#page--1-0)

#### Chapter 4: Independence [38](#page--1-0)

[4.1. Definitions of independence. 4.2. The 71'-system Lemma; and the](#page--1-0)  [more familiar definitions.](#page--1-0) [4.3. Second Borel-Cantelli Lemma \(BC2\).](#page--1-0) [4.4.](#page--1-0)  [Example.](#page--1-0) [4.5. A fundamental question for modelling. 4.6. A coin-tossing](#page--1-0)  [model with applications. 4.7. Notation: liD RVs.](#page--1-0) [4.8. Stochastic processes;](#page--1-0)  [Markov chains. 4.9. Monkey typing Shakespeare. 4.10. Definition. Tail a](#page--1-0)[algebras. 4.11. Theorem. Kolmogorov](#page--1-0)'s 0-1 law. [4.12. Exercise/Warning.](#page--1-0) 

#### Chapter 5: Integration [49](#page--1-0)

[5.0. Notation, etc.](#page--1-0) J-L(f) :=: J fdJ-L, J-LU; A). [5.1. Integrals of non-negative](#page--1-0)  [simple functions, SF+.](#page--1-0) [5.2. Definition of](#page--1-0) J-L(f), f E(mL:)+. [5.3. Monotone-](#page--1-0)[Convergence Theorem \(MON\). 5.4. The Fatou Lemmas for functions \(FA-](#page--1-0)[TOU\).](#page--1-0) 5.5. ['Linearity'. 5.6. Positive and negative parts of](#page--1-0) f. [5.7. Inte](#page--1-0)[grable function,](#page--1-0) 1:} ( S, L:, J-L ). [5.8. Linearity.](#page--1-0) [5.9. Dominated Convergence](#page--1-0)  [Theorem \(DOM\).](#page--1-0) 5.10. Scheffe['s Lemma \(SCHEFFE\). 5.11. Remark on](#page--1-0)  [uniform integrability. 5.12. The standard machine. 5.13. Integrals over](#page--1-0)  [subsets. 5.14. The measure](#page--1-0) fJ-L, f E(mL:)+.

## Chapter 6: Expectation [58](#page--1-0)

[Introductory remarks. 6.1. Definition of expectation. 6.2. Convergence](#page--1-0)  [theorems. 6.3. The notation](#page--1-0) E(X; F). 6.4. Markov['s inequality. 6.5.](#page--1-0)  [Sums of non-negative RVs.](#page--1-0) 6.6. Jensen['s inequality for convex functions.](#page--1-0)  [6.7. Monotonicity of](#page--1-0) CP norms. [6.8. The Schwarz inequality.](#page--1-0) 6.9. [£2:](#page--1-0)  [Pythagoras, covariance, etc. 6.10. Completeness of](#page--1-0) CP (1 � p < oo) . [6.11.](#page--1-0)  [Orthogonal projection.](#page--1-0) 6.12. The ['elementary formula' for expectation.](#page--1-0)  [6.13. Holder from Jensen.](#page--1-0) 

Contents Vll

## Chapter 7: An Easy Strong Law [71](#page--1-0)

7.1. ['Independence means multiply'-](#page--1-0) again! [7.2. Strong Law-](#page--1-0) first version.

[7.3. Chebyshev](#page--1-0)'s inequality. [7.4. Weierstrass approximation theorem.](#page--1-0)

#### Chapter 8: Product Measure [75](#page--1-0)

[8.0. Introduction and advice.](#page--1-0) [8.1. Product measurable structure,](#page--1-0) L:1 XL:2 . [8.2. Product measure, Fubini](#page--1-0)'s Theorem. [8.3. Joint laws, joint pdfs.](#page--1-0) [8.4.](#page--1-0) [Independence and product measure.](#page--1-0) 8.5. B(R)n = [B\(Rn\).](#page--1-0) [8.6. The n-fold](#page--1-0)  [extension.](#page--1-0) [8.7. Infinite products of probability triples.](#page--1-0) [8.8. Technical note](#page--1-0)  [on the existence of joint laws.](#page--1-0)

#### PART B: MARTINGALE THEORY

#### Chapter 9: Conditional Expectation [83](#page--1-0)

[9.1. A motivating example.](#page--1-0) [9.2. Fundamental Theorem and Definition](#page--1-0)  [\(Kolmogorov, 1933](#page--1-0)). [9.3. The intuitive meaning.](#page--1-0) [9.4. Conditional ex](#page--1-0)[pectation as least-squares-best predictor. 9.5. Proof of Theorem 9.2. 9.6.](#page--1-0)  [Agreement with traditional expression.](#page--1-0) [9.7. Properties of conditional ex](#page--1-0)[pectation: a list. 9.8. Proofs of the properties in Section 9.7.](#page--1-0) [9.9. Regular](#page--1-0)  [conditional probabilities and pdfs.](#page--1-0) [9.10. Conditioning under independe\\_nce](#page--1-0)  [assumptions.](#page--1-0) [9.11. Use of symmetry: an example.](#page--1-0)

## Chapter 10: Martingales [93](#page--1-0)

[10.1. Filtered spaces.](#page--1-0) [10.2. Adapted processes.](#page--1-0) [10.3. Martingale, super](#page--1-0)[martingale, submartingale. 10.4. Some examples of martingales.](#page--1-0) [10.5. Fair](#page--1-0)  [and unfair games.](#page--1-0) [10.6. Previsible process, gambling strategy. 10.7. A fun](#page--1-0)[damental principle: you can](#page--1-0)'t beat the system! [10.8. Stopping time.](#page--1-0) [10.9.](#page--1-0)  [Stopped supermartingales are supermartingales.](#page--1-0) 10.10. Doob['s Optional-](#page--1-0)[Stopping Theorem. 10.11. Awaiting the almost inevitable.](#page--1-0) [10.12. Hitting](#page--1-0)  [times for simple random walk.](#page--1-0) [10.13. Non-negative superharmonic func](#page--1-0)[tions for Markov chains.](#page--1-0)

#### Chapter 11: The Convergence Theorem [106](#page--1-0)

[11.1. The picture that says it all.](#page--1-0) [11.2. Upcrossings.](#page--1-0) 11.3. Doob['s Upcross](#page--1-0)[ing Lemma. 11.4. Corollary.](#page--1-0) 11.5. Doob['s 'Forward' Convergence Theorem.](#page--1-0) [11.6. Warning.](#page--1-0) [11.7. Corollary.](#page--1-0)

Vlll Contents

## Chapter 12: Martingales bounded in £2 [110](#page--1-0)

[12.0. Introduction.](#page--1-0) 12.1. Martingales in £2: [orthogonality of increments.](#page--1-0)  [12.2. Sums of zero-mean independent random variables in](#page--1-0) £2• [12.3. Ran](#page--1-0)[dom signs. 12.4. A symmetrization technique: expanding the sample space.](#page--1-0) 12.5. Kolmogorov['s Three-Series Theorem.](#page--1-0) [12.6. Cesaro](#page--1-0)'s Lemma. [12.7.](#page--1-0)  Kronecker['s Lemma. 12.8. A Strong Law under variance constraints. 12.9.](#page--1-0)  Kolmogorov['s Truncation Lemma.](#page--1-0) 12.10. Kolmogorov['s Strong Law of](#page--1-0)  [Large Numbers \(SLLN\). 12.11. Doob decomposition.](#page--1-0) [12.12. The angle](#page--1-0)[brackets process](#page--1-0) {M). [12.13. Relating convergence of](#page--1-0) M to finiteness of [\(M\)00•](#page--1-0) 12.14. A trivial ['Strong Law' for martingales in](#page--1-0) £2. [12.15. Levy](#page--1-0)'s [extension of the Borel-Cantelli Lemmas. 12.16. Comments.](#page--1-0) 

#### Chapter 13: Uniform Integrability [126](#page--1-0)

13.1. An ['absolute continuity' property.](#page--1-0) [13.2. Definition. UI family. 13.3.](#page--1-0)  [Two simple sufficient conditions for the UI property. 13.4. UI property](#page--1-0)  [of conditional expectations.](#page--1-0) [13.5. Convergence in probability.](#page--1-0) [13.6. Ele](#page--1-0)[mentary proof of \(BDD\). 13.7. A necessary and sufficient condition for](#page--1-0) £1 [convergence.](#page--1-0) 

## Chapter 14: UI Martingales [133](#page--1-0)

[14.0. Introduction. 14.1. UI martingales.](#page--1-0) 14.2. Levy['s 'Upward' Theorem.](#page--1-0)  [14.3. Martingale proof of Kolmogorov](#page--1-0)'s 0-1 law. 14.4. Levy['s 'Downward'](#page--1-0) [Theorem.](#page--1-0) [14.5. Martingale proof of the Strong Law.](#page--1-0) [14.6. Doob](#page--1-0)'s Sub[martingale Inequality. 14.7. Law of the Iterated Logarithm: special case.](#page--1-0)  [14.8. A standard estimate on the normal distribution. 14.9. Remarks on ex](#page--1-0)[ponential bounds; large deviation theory. 14.10. A consequence of Holder](#page--1-0)'s [inequality. 14.11. Doob](#page--1-0)'s £P inequality. 14.12. Kakutani['s Theorem on](#page--1-0)  ['product' martingales. 14.13.The Radon-Nikodym theorem. 14.14. The](#page--1-0)  [Radon-Nikodym theorem and conditional expectation.](#page--1-0) [14.15. Likelihood](#page--1-0)  [ratio; equivalent measures. 14.16. Likelihood ratio and conditional expec](#page--1-0)[tation.](#page--1-0) 14.17. Kakutani['s Theorem revisited; consistency of LR test.](#page--1-0) [14.18.](#page--1-0)  [Note on Hardy spaces, etc.](#page--1-0)

## Chapter 15: Applications [153](#page--1-0)

[15.0. Introduction-](#page--1-0) please read! [15.1. A trivial martingale-representation](#page--1-0)  [result. 15.2. Option pricing; discrete Black-Scholes formula.](#page--1-0) [15.3. The](#page--1-0)  [Mabinogion sheep problem.](#page--1-0) [15.4. Proof of Lemma 15.3\(c\).](#page--1-0) [15.5. Proof](#page--1-0)  [of result 15.3\( d\). 15.6. Recursive nature of conditional probabilities. 15. 7.](#page--1-0)  Bayes[' formula for bivariate normal distributions. 15.8. Noisy observation of](#page--1-0)  [a single random variable. 15.9. The Kalman-Bucy filter.](#page--1-0) [15.10. Harnesses](#page--1-0)  [entangled. 15.11. Harnesses unravelled, 1. 15.12. Harnesses unravelled, 2.](#page--1-0) 

ContentJ IX

#### PART C: CHARACTERISTIC FUNCTIONS

#### Chapter 16: Basic Properties of CFs [172](#page--1-0)

[16.1. Definition. 16.2. Elementary properties. 16.3. Some uses of char](#page--1-0)[acteristic functions.](#page--1-0) [16.4. Three key results. 16.5. Atoms. 16.6. Levy](#page--1-0)'s [Inversion Formula.](#page--1-0) [16.7. A table.](#page--1-0) 

#### Chapter 17: Weak Convergence [179](#page--1-0)

17.1. The ['elegant' definition.](#page--1-0) 17.2. A ['practical' formulation. 17.3. Sko](#page--1-0)[rokhod representation.](#page--1-0) [17.4. Sequential compactness for Prob\(R\). 17.5.](#page--1-0)  [Tightness.](#page--1-0) 

#### Chapter 18: The Central Limit Theorem [185](#page--1-0)

18.1. Levy['s Convergence Theorem. 18.2. o and](#page--1-0) 0 notation. [18.3. Some](#page--1-0)  [important estimates. 18.4. The Central Limit Theorem. 18.5. Example.](#page--1-0) [18.6. CF proof of Lemma 12.4.](#page--1-0) 

#### APPENDICES

#### Chapter A1: Appendix to Chapter 1 [192](#page--1-0)

[Al.l. A non-measurable subset](#page--1-0) A of S1. [Al.2. d-systems.](#page--1-0) [Al.3. Dynkin](#page--1-0)'s [Lemma. A1.4. Proof of Uniqueness Lemma 1.6. Al.5. .A-sets:](#page--1-0) 'algebra' [case. Al.6. Outer measures.](#page--1-0) [Al.7. Caratheodory](#page--1-0)'s Lemma. [Al.8. Proof of](#page--1-0)  [Caratheodory](#page--1-0)'s Theorem. [Al.9. Proof of the existence of Lebesgue measure](#page--1-0)  [on \(\(0, 1\], 8\(0, 1\]\). Al.10. Example of non-uniqueness of extension. Al.11.](#page--1-0)  [Completion of a measure space.](#page--1-0) [Al.12. The Baire category theorem.](#page--1-0) 

#### Chapter A3: Appendix to Chapter 3 [205](#page--1-0)

[A3.1. Proof of the Monotone-Class Theorem 3.14. A3.2. Discussion of](#page--1-0)  [generated a-algebras.](#page--1-0) 

# Chapter A4: Appendix to Chapter 4 [208](#page--1-0)

A4.1. Kolmogorov['s Law of the Iterated Logarithm. A4.2. Strassen's Law](#page--1-0)  [of the Iterated Logarithm.](#page--1-0) [A4.3. A model for a Markov chain.](#page--1-0) 

#### Chapter A5: Appendix to Chapter 5 [211](#page--1-0)

[A5.1. Doubly monotone arrays. A5.2. The key use of Lemma 1.10\(a\).](#page--1-0)  A5.3. ['Uniqueness of integral'. A5.4. Proof of the Monotone-Convergence](#page--1-0)  [Theorem.](#page--1-0) 

<sup>X</sup>Contents

| Chapter A9: Appendix to Chapter 9                                                                                                                                                     | 214 |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| A9.1. Infinite products: setting things up. A9.2. Proof of A9.1(e).                                                                                                                   |     |
| Chapter A13: Appendix to Chapter 13                                                                                                                                                   | 217 |
| A13.1.<br>Modes of convergence:<br>definitions.<br>A13.2.<br>Modes of convergence:<br>relationships.                                                                                  |     |
| Chapter A14: Appendix to Chapter 14                                                                                                                                                   | 219 |
| A14.1. The a-algebra :FT, T a stopping time. A14.2. A special case of OST.<br>A14.3. Doob's Optional-Sampling Theorem for UI martingales. A14.4. The<br>result for UI submartingales. |     |
| Chapter A16: Appendix to Chapter 16                                                                                                                                                   | 222 |
| A16.1. Differentiation under the integral sign.                                                                                                                                       |     |
| Chapter E: Exercises                                                                                                                                                                  | 224 |
| References                                                                                                                                                                            | 243 |
| Index                                                                                                                                                                                 | 246 |

# Preface - please read!

The most important chapter in this book is *Chapter E: Exercises.* I have left the interesting things for *you* to do. You can start *now* on the 'EG' exercises, but see 'More about exercises' later in this Preface.

The book, which is essentially the set of lecture notes for a third-year undergraduate course at Cambridge, is as lively an introduction as I can manage to the rigorous theory of probability. Since much of the book is devoted to martingales, it is bound to become very lively: look at those Exercises on Chapter 10! But, of course, there is that initial plod through the measure-theoretic foundations. It must be said however that measure theory, that most arid of subjects when done for its own sake, becomes amazingly more alive when used in probability, not only because it is then applied, but also because it is immensely enriched.

You cannot avoid measure theory: an *event* in probability is a measurable set, a *random variable* is a measurable function on the sample space, the *expectation* of a random variable is its integral with respect to the probability measure; and so on. To be sure, one can take some central results from measure theory as axiomatic in the main text, giving careful proofs in appendices; and indeed that is exactly what I have done.

Measure theory for its own sake is based on the fundamental addition rule for measures. Probability theory supplements that with the multiplication rule which describes independence; and things are already looking up. But what really enriches and enlivens things is that we deal with lots of a-algebras, not just the one a-algebra which is the concern of measure theory.

In planning this book, I decided for every topic what things I considered just a bit too advanced, and, often with sadness, I have ruthlessly omitted them.

For a more thorough training in many of the topics covered here, see Billingsley (1979), Chow and Teicher (1978), Chung (1968), Kingman and XlI *Preface*

Taylor (1966), Laha and Rohatgi (1979), and Neveu (1965). As regards measure theory, I learnt it from Dunford and Schwartz (1958) and Halmos (1959). After reading this book, you must read the still-magnificent Breiman (1968), and, for an excellent indication of what can be done with discrete martingales, Hall and Heyde (1980).

Of course, intuition is much more important than knowledge of measure theory, and you should take every opportunity to sharpen your intuition. There is no better whetstone for this than Aldous (1989), though it is a very demanding book. For appreciating the scope of probability and for learning how to think about it, Karlin and Taylor (1981), Grimmett and Stirzaker (1982), Hall (1988), and Grimmett's recent superb book, Grimmett (1989), on percolation are strongly recommended.

*More about exercises.* In compiling Chapter E, which consists exactly of the homework sheet I give to the Cambridge students, I have taken into account the fact that this book, like any other mathematics book, implicitly contains a vast number of other exercises, many of which are easier than those in Chapter E. I refer of course to the exercises *you* create by reading the statement of a result, and then trying to prove it for yourself, before you read the given proof. One other point about exercises: you will, for example, surely forgive my using expectation E in Exercises on Chapter 4 before E is treated with full rigour in Chapter 6.

Acknowledgements. My first thanks must go to the students who have endured the course on which the book is based and whose quality has made me try hard to make it worthy of them; and to those, especially David Kendall, who had developed the course before it became my privilege to teach it. My thanks to David Tranah and other staff of CUP for their help in converting the course into this book. Next, I must thank Ben Garling, James Norris and Chris Rogers without whom the book would have contained more errors and obscurities. (The many faults which surely remain in it are my responsibility.) Helen Rutherford and I typed part of the book, but the vast majority of it was typed by Sarah Shea-Simonds in a virtuoso performance worthy of Horowitz. My thanks to Helen and, most especially, to Sarah. Special thanks to my wife, Sheila, too, for all her help.

But my best thanks - and yours if you derive any benefit from the book - must go to three people whose names appear in capitals in the Index: J.L. Doob, A.N. Kolmogorov and P. Levy: without them, there wouldn't have been much to write about, as Doob (1953) splendidly confirms.

# A Question of Terminology

Randolll variables: functions or equivalence classes?

At the level of this book, the theory would be more 'elegant' if we regarded a random variable as an *equivalence cIa""* of measurable functions on the sample space, two functions belonging to the same equivalence class if and only if they are equal almost everywhere. Then the conditional-expectation map

$$X \mapsto \mathsf{E}(X|\mathcal{G})$$

would be a truly well-defined contraction map from LP(f'l, *F,* P) to LP(n, 9, P) for *p* 2::: 1; and we would not have to keep mentioning versions (representatives of equivalence classes) and would be able to avoid the endless 'almost surely' qualifications.

I have however chosen the 'inelegant' route: firstly, I prefer to work with *function",* and confess to preferring

$$4+5=2 \mod 7$$
 to  $[4]_7+[5]_7=[2]_7$ 

But there is a substantive reason. I hope that this book will tempt you to progress to the much more interesting, and more important, theory where the parameter set of our process is uncountable (e.g. it may be the timeparameter set [0, 00)). There, the equivalence-class formulation just will not work: the 'cleverness' of introducing quotient spaces loses the subtlety which is essential even for formulating the fundamental results on existence of continuous modifications, etc., unless one performs contortions which are hardly elegant. Even if these contortions allow one to *formulate* results, one would still have to use genuine functions to *prove* them; so where does the reality lie?!

# A Guide to Notation

.. signifies something important, **....** something very important, and **......** the Martingale Convergence Theorem.

I use ':=' to signify 'is defined to equal'. This Pascal notation is particularly convenient because it can also be used in the reversed sense.

I use analysts' (as opposed to category theorists') conventions:

$$N := \{1, 2, 3, ...\} \subseteq \{0, 1, 2, ...\} =: Z^+.$$

Everyone is agreed that R+ := [0,00).

For a set *B* contained in some universal set S, *IB* denotes the indicator function of *B:* that is *IB* : S {a, I} and

$$I_B(s) := \left\{ egin{array}{ll} 1 & ext{if } s \in B, \\ 0 & ext{otherwise.} \end{array} \right.$$

For *a, b* E R,

$$a \wedge b := \min(a, b), \qquad a \vee b := \max(a, b).$$

CF:characteristic function; DF: distribution function; pdf: probability density function.

u-algebra, u(C) (1.1); u(Y.." : , E C) (3.8, 3.13). 1r-system (1.6); *d-system* (A1.2).

a.e.: almost everywhere (1.5)

a.s.: almost surely (2.4)

bE: the space of bounded ~-measurablefunctions (3.1) 8(5): the Borel u-algebra on 5, B := 8(R) (1.2)

*C.X:* discrete stochastic integral (10.6)

*d>.-/d{t:* Radon-Nikodym derivative (5.14)

*dQ/dP:* Likelihood Ratio (14.13)

E(X): expectation E(X) := In *X(w*)P(*dw)* of X (6.3)

E(X; *F): IF XdP (6.3)*

E(XIQ): conditional expectation (9.3)

*(En,ev): (En,* i.o.): lim inf *En* (2.S) lim sup *En (2.6)*

*fx:* probability density function (pdf) of X (6.12).

*fx,Y:* joint pdf (S.3)

*fXIY:* conditional pdf (9.6)

*Fx:* distribution function of X (3.9)

liminf: lim sup: for sets, (2.S) for sets, (2.6)

*<sup>X</sup>* =i limxn : *<sup>X</sup> <sup>n</sup>* i *x* in that *<sup>X</sup> <sup>n</sup>* :5 *<sup>X</sup> n+l ('In)* and *<sup>X</sup> <sup>n</sup>* ---+ *x.*

log: natural (base e) logarithm

£'x, Ax: law of *X (3.9)*

*£,P, LP:* Leb: Lebesgue spaces (6.7, 6.13) Lebesgue measure (l.S)

space of E-measurable functions (3.1)

process *M* stopped at time *T (10.9)*

*(M):* angle-brackets process (12.12)

*{t(f):* integral of f with respect to I" (5.0, 5.2)

*{t(f; A): IA fdl"* (5.0, 5.2)

<.p x: CF of *X* (Chapter 16)

*r.p:* pdf of standard normal N(O,l) distribution

<P: *XT:* DF of N(O,l) distribution X stopped at time *T (10.9)*

# *Chapter 0*

# A Branching-Process Example

*(This Chapter is not essential for the remainder of the book. You can start with Chapter* 1 *if you wish.)*

# 0.0. Introductory remarks

The purpose of this chapter is threefold: to take something which is probably well known to you from books such as the immortal Feller (1957) or Ross (1976), so that you start on familiar ground; to make you start to think about some of the problems involved in making the elementary treatment into rigorous mathematics; and to indicate what new results appear if one applies the somewhat more advanced theory developed in this book. We stick to one example: a branching process. This is rich enough to show that the theory has some substance.

## 0.1. Typical nun'lber of cllildren, )(

In our model, the number of children of a typical animal (see Notes below for some interpretations of 'child' and 'animal') is a random variable X with values in Z+. *We assume that*

$$\mathbf{P}(X=0)>0.$$

We define the *generating function* f *of* X as the map f [0, 1] [0,1], where

$$f(\theta) := \mathsf{E}(\theta^X) = \sum_{k \in \mathbf{Z}^+} \theta^k \mathsf{P}(X = k).$$

Standard theorems on power series imply that, for *B* E [0,1],

$$f'(\theta) = \mathsf{E}(X\theta^{X-1}) = \sum k\theta^{k-1}\mathsf{P}(X=k)$$

and

$$\mu := \mathsf{E}(X) = f'(1) = \sum k \mathsf{P}(X = k) \le \infty.$$

Of course, *f'(l)* is here interpreted as

$$\lim_{\theta \uparrow 1} \frac{f(\theta) - f(1)}{\theta - 1} = \lim_{\theta \uparrow 1} \frac{1 - f(\theta)}{1 - \theta}$$

since *f(l)* = 1. *We assume that*

$$\mu < \infty$$
.

*Notes.* The first application of branching-process theory was to the question of survival of family names; and in that context, animal = man, and child = son.

In another context, 'animal' can be 'neutron', and 'child' of that neutron will signify a neutron released if and when the parent neutron crashes into a nucleus. Whether or not the associated branching process is supercritical can be a matter of real importance.

We can often find brallching processes embedded in richer structures and can then use the results of this chapter to start the study of more interesting things.

For superb accounts of branching processes, see Athreya and Ney (1972), Harris (1963), Kendall (1966, 1975).

# 0.2. Size of nth generatioll, *Zn*

To be a bit formal: suppose that we are given a doubly infinite sequence

(a) 
$$\left\{X_r^{(m)}: m, r \in \mathbf{N}\right\}$$

of independent identically distributed random variables (lID RVs), each with the same distribution as X:

$$P(X_r^{(m)} = k) = P(X = k).$$

The idea is that for n E Z+ and r E N, the variable X~n+l) represents the number of children (who will be in the (n + 1)th generation) of the rth animal (if there is one) in the nth generation. The fundamental rule therefore is that if *Zm* signifies the size of the nth generation, then

(b) 
$$Z_{n+1} = X_1^{(n+1)} + \dots + X_{Z_n}^{(n+1)}$$

*We assume that Zo* = 1, so that (b) gives a full recursive definition of the sequence *(Zm* : m E Z+) from the sequence (a). Our first task is

to calculate the distribution function of  $Z_n$ , or equivalently to find the generating function

(c) 
$$f_n(\theta) := \mathsf{E}(\theta^{Z_n}) = \sum \theta^k \mathsf{P}(Z_n = k).$$

#### 0.3. Use of conditional expectations

The first main result is that for  $n \in \mathbb{Z}^+$  (and  $\theta \in [0,1]$ )

(a) 
$$f_{n+1}(\theta) = f_n(f(\theta)),$$

so that for each  $n \in \mathbb{Z}^+$ ,  $f_n$  is the n-fold composition

$$f_n = f \circ f \circ \ldots \circ f.$$

Note that the 0-fold composition is by convention the identity map  $f_0(\theta) = \theta$ , in agreement with – indeed, forced by – the fact that  $Z_0 = 1$ .

To prove (a), we use - at the moment in intuitive fashion - the following very special case of the very useful Tower Property of Conditional Expectation:

(c) 
$$\mathsf{E}(U) = \mathsf{E}\mathsf{E}(U|V);$$

to find the expectation of a random variable U, first find the conditional expectation  $\mathsf{E}(U|V)$  of U given V, and then find the expectation of that. We prove the ultimate form of (c) at a later stage.

We apply (c) with  $U = \theta^{Z_{n+1}}$  and  $V = Z_n$ :

$$\mathsf{E}(\theta^{Z_{n+1}}) = \mathsf{E}\mathsf{E}(\theta^{Z_{n+1}}|Z_n).$$

Now, for  $k \in \mathbb{Z}^+$ , the conditional expectation of  $\theta^{\mathbb{Z}_{n+1}}$  given that  $\mathbb{Z}_n = k$  satisfies

(d) 
$$\mathsf{E}(\theta^{Z_{n+1}}|Z_n=k) = \mathsf{E}(\theta^{X_1^{(n+1)}+\cdots+X_k^{(n+1)}}|Z_n=k).$$

But  $Z_n$  is constructed from variables  $X_s^{(r)}$  with  $r \leq n$ , and so  $Z_n$  is independent of  $X_1^{(n+1)}, \ldots, X_k^{(n+1)}$ . The conditional expectation given  $Z_n = k$  in the right-hand term in (d) must therefore agree with the absolute expectation

(e) 
$$\mathsf{E}(\theta^{X_1^{(n+1)}} \dots \theta^{X_k^{(n+1)}}).$$

But the expression at (e) is a expectation of the product of independent  $random\ variables$  and as part of the family of 'Independence means multiply' results, we know that this expectation of a product may be rewritten as the product of expectations. Since (for every n and r)

$$\mathsf{E}(\theta^{X_r^{(n+1)}}) = f(\theta),$$

we have proved that

$$\mathsf{E}(\theta^{Z_{n+1}}|Z_n=k)=f(\theta)^k,$$

and this is what it means to say that

$$\mathsf{E}(\theta^{Z_{n+1}}|Z_n) = f(\theta)^{Z_n}.$$

[If V takes only integer values, then when V = k, the conditional expectation  $\mathsf{E}(U|V)$  of U given V is equal to the conditional expectation  $\mathsf{E}(U|V = k)$  of U given that V = k. (Sounds reasonable!)] Property (c) now yields

$$\mathsf{E}\theta^{Z_{n+1}} = \mathsf{E}f(\theta)^{Z_n},$$

and, since

$$\mathsf{E}(\alpha^{Z_n}) = f_n(\alpha), \qquad \Box$$

result (a) is proved.

Independence and conditional expectations are two of the main topics in this course.

# 0.4. Extinction probability, $\pi$

Let  $\pi_n := P(Z_n = 0)$ . Then  $\pi_n = f_n(0)$ , so that, by (0.3,b),

$$\pi_{n+1} = f(\pi_n).$$

Measure theory confirms our intuition about the extinction probability:

(b) 
$$\pi := \mathbf{P}(Z_m = 0 \text{ for some } m) = \uparrow \lim \pi_n.$$

Because f is continuous, it follows from (a) that

(c) 
$$\pi = f(\pi).$$

The function f is analytic on (0,1), and is non-decreasing and convex (of non-decreasing slope). Also, f(1) = 1 and f(0) = P(X = 0) > 0. The slope f'(1) of f at 1 is  $\mu = E(X)$ . The celebrated pictures opposite now make the following Theorem obvious.

#### THEOREM

If E(X) > 1, then the extinction probability  $\pi$  is the unique root of the equation  $\pi = f(\pi)$  which lies strictly between 0 and 1. If  $E(X) \le 1$ , then  $\pi = 1$ .

![](_page_22_Figure_3.jpeg)

*Case* 1: *subcritical,* Jl =f' (1) < 1. Clearly, 7r = 1.

The *critical case* Jl = <sup>1</sup> has <sup>a</sup> silnilar picture.

![](_page_22_Figure_6.jpeg)

*Case* 2: *supercritical,* Jl =*1'(1)* <sup>&</sup>gt; 1. Now, 7r < 1.

#### 0.5. Pause for thought: measure

Now that we have finished revising what introductory courses on probability theory say about branching-process theory, let us think about why we must find a more precise language. To be sure, the claim at (0.4,b) that

(a) 
$$\pi = \uparrow \lim \pi_n$$

is intuitively plausible, but how could one prove it? We certainly cannot prove it at present because we have no means of stating with pure-mathematical precision what it is supposed to mean. Let us discuss this further.

Back in Section 0.2, we said 'Suppose that we are given a doubly infinite sequence  $\{X_r^{(m)}: m,r\in \mathbb{N}\}$  of independent identically distributed random variables each with the same distribution as X'. What does this mean? A random variable is a (certain kind of) function on a sample space  $\Omega$ . We could follow elementary theory in taking  $\Omega$  to be the set of all outcomes, in other words, taking  $\Omega$  to be the Cartesian product

$$\Omega = \prod_{r,s} \mathbf{Z}^+,$$

the typical element  $\omega$  of  $\Omega$  being

$$\omega = (\omega_s^{(r)} : r \in \mathbb{N}, s \in \mathbb{N}),$$

and then setting  $X_s^{(r)}(\omega) = \omega_s^{(r)}$ . Now  $\Omega$  is an uncountable set, so that we are outside the 'combinatorial' context which makes sense of  $\pi_n$  in the elementary theory. Moreover, if one assumes the Axiom of Choice, one can *prove* that it is impossible to assign to all subsets of  $\Omega$  a probability satisfying the 'intuitively obvious' axioms and making the X's IID RVs with the correct common distribution. So, we have to know that the set of  $\omega$  corresponding to the event 'extinction occurs' is one to which one can uniquely assign a probability (which will then provide a definition of  $\pi$ ). Even then, we have to prove (a).

**Example.** Consider for a moment what is in some ways a bad attempt to construct a 'probability theory'. Let C be the class of subsets C of N for which the 'density'

$$\rho(C) := \lim_{n \uparrow \infty} \sharp \{k : 1 \leq k \leq n; k \in C\}$$

exists. Let  $C_n := \{1, 2, ..., n\}$ . Then  $C_n \in \mathcal{C}$  and  $C_n \uparrow \mathbb{N}$  in the sense that  $C_n \subseteq C_{n+1}, \forall n$  and also  $\bigcup C_n = \mathbb{N}$ . However,  $\rho(C_n) = 0, \forall n$ , but  $\rho(\mathbb{N}) = 1$ .

Hence the logic which will allow us correctly to deduce (a) from the fact that

$${Z_n = 0} \uparrow {\text{extinction occurs}}$$

fails for the (N,C,p) set-up: (N,C,p) is not 'a probability triple'. 0

There *are* problems. Measure theory resolves them, but provides a huge bonus in the form of much deeper results such as the Martingale Convergence Theorem which we now take a first look at - at an intuitive level, I hasten to add.

#### **0.6. Our first martillgale**

Recall from (O.2,b) that

$$Z_{n+1} = X_1^{(n+1)} + \dots + X_{Z_n}^{(n+1)},$$

where the *x.(n+l)* variables are independent of the values *Zl, Z2, .* .. *,Zn.* It is clear from this that

$$P(Z_{n+1} = j | Z_0 = i_0, Z_1 = i_1, \dots, Z_n = i_n) = P(Z_{n+1} = j | Z_n = i_n),$$

<sup>a</sup> result which you will probably recognize as stating that the process *Z = (Zn* : *n* 0) *is a Markov chain.* We therefore have

$$\mathsf{E}(Z_{n+1}|Z_0 = i_0, Z_1 = i_1, \dots, Z_n = i_n) = \sum_j j \mathsf{P}(Z_{n+1} = j|Z_n = i_n)$$
$$= \mathsf{E}(Z_{n+1}|Z_n = i_n)$$

or, in a condensed and better notation,

(a) 
$$E(Z_{n+1}|Z_0,Z_1,\ldots,Z_n)=E(Z_{n+1}|Z_n).$$

Of course, it is intuitively obvious that

(b) 
$$\mathsf{E}(Z_{n+1}|Z_n) = \mu Z_n,$$

because each of the *Zn* animals in the nth generation has on average J.l children. We can confirm result (b) by differentiating the result

$$\mathsf{E}(\theta^{Z_{n+1}}|Z_n) = f(\theta)^{Z_n}$$

with respect to () and setting () = 1.

Now define

(c) 
$$M_n := Z_n/\mu^n, \qquad n \ge 0$$

Then

$$\mathsf{E}(M_{n+1}|Z_0,Z_1,\ldots,Z_n)=M_n,$$

which exactly says that

(d) *M is a martingale relative to the Z process.*

Given the history of *Z* up to stage *n,* the next value *M <sup>n</sup>*+1 of *M* is on average what it is now: *M* is 'constant on average' in this very sophisticated sense of conditional expectation given 'past' and 'present'. The true statement

(e) 
$$\mathsf{E}(M_n) = 1, \quad \forall n$$

is of course infinitely cruder.

A statement *S* is said to be true allllost surely (a.s.) or with probability 1 if (surprise, surprise!)

$$P(S \text{ is true}) = 1.$$

Because our martingale 1\1 is *non-negative (Mn* 0, "In), the Martingale Convergence Tlleorem implies that *it is almost surely true that*

$$(f) M_{\infty} := \lim M_n \quad exists.$$

Note that if Moo > 0 for some outcome (which can happen with positive probability only when *J-L* > 1), then the statelnent

$$Z_n/\mu^n \to M_\infty$$
 (a.s.)

is a precise formulation of 'exponential growth'. A particularly fascinating question is: *suppose that* Jl > 1; *what is the behaviour of Z conditional on the value of Moo?*

# 0.7. COllvergence (or Ilot) of expectatiollS

We know that *Mex:>* := lim *Aln* exists with probability 1, and that *E(Mn )* = 1, "In. We might be tempted to believe that E(Moo ) = 1. However, we already know that if *J-l* 1, then, almost surely, the process dies out and M *<sup>n</sup>* IS eventually o. Hence

(a) if 
$$\mu \leq 1$$
, then  $M_{\infty} = 0$  (a.s.) and 
$$0 = \mathsf{E}(M_{\infty}) \neq \lim \mathsf{E}(M_n) = 1.$$

This is an excellent exanlple to keep in 111ind when we come to study *Fatou's Lemma,* valid for any sequence *(Yn )* of non-negative random variables:

$$\mathsf{E}(\liminf Y_n) \le \liminf \mathsf{E}(Y_n)$$

What is 'going wrong' at (a) is that (\vhen J-l :::; 1) for large *n,* the chances are that *}yIn* will be large if *lvIn* is not 0 and, very roughly speaking, this large value times its small probability \vill keep E(Al<sup>n</sup> ) at 1. See the concrete examples in Section 0.9.

Of course, it is very i111portant to know when

(b) 
$$\lim \mathsf{E}(\cdot) = \mathsf{E}(\lim \cdot),$$

and we do spend quite a considerable tilue studying this. The best general theorelns are rarely good enough to get the best results for concrete problenls, as is evidenced by the fact that

(c) 
$$\mathsf{E}(M_\infty) = 1$$
 if and only if both  $\mu > 1$  and  $\mathsf{E}(X \log X) < \infty$ ,

where --,x" is the typicall1ulllber of children. Of course 0 log 0 = o. If J-l > 1 and E(X logX) = 00, then, even though the process may not die out, *lv/(X)* = 0, a.s.

# 0.8. Fillding the distributioll of AJ(X)

Since *.i.\1*<sup>n</sup> ---+ M(X) (a.s.), it is obvious that for *A* > 0,

$$\exp(-\lambda M_n) \to \exp(-\lambda M_\infty)$$
 (a.s.)

Now since each *M n* 0, the \vhole sequence (exp(*-AlvIn))* is bounded in absolute value by the constant 1, independently of the outcome of our experiment. The *Bounded Convergence Theorem* says that we *can* now assert what we would wish:

(a) 
$$\operatorname{\mathsf{E}} \exp(-\lambda M_{\infty}) = \lim \operatorname{\mathsf{E}} \exp(-\lambda M_n).$$

Since *]yIn* = *Zn/ J-ln* and *E(BZn)* = *fn(B),* \ve have

(b) 
$$\mathsf{E}\exp(-\lambda M_n) = f_n(\exp(-\lambda/\mu^n)),$$

so that, in principle (if very rarely in practice), \ve can calculate the left-hand side of (a). However, for a non-negative random variable *Y, the distribution function y* P(Y :s; *y) is completely determined by the map*

$$\lambda \mapsto \mathsf{E} \exp(-\lambda Y)$$
 on  $(0, \infty)$ .