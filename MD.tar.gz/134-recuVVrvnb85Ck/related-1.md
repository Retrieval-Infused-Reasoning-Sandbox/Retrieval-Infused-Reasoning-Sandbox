# **Flow analysis with cumulants: direct calculations**

Ante Bilandzic Nikhef, Science Park 105, 1098 XG Amsterdam, The Netherlands Utrecht University, P.O. Box 80000, 3508 TA Utrecht, The Netherlands Raimond Snellings Utrecht University, P.O. Box 80000, 3508 TA Utrecht, The Netherlands Sergei Voloshin Wayne State University, 666 W. Hancock Street, Detroit, MI 48201, USA

#### **Abstract**

Anisotropic flow measurements in heavy-ion collisions provide important information on the properties of hot and dense matter. These measurements are based on analysis of azimuthal correlations and might be biased by contributions from correlations that are not related to the initial geometry, so called non-flow. To improve anisotropic flow measurements advanced methods based on multi-particle correlations (cumulants) have been developed to suppress non-flow contribution. These multi-particle correlations can be calculated by looping over all possible multiplets, however this quickly becomes prohibitively CPU intensive. Therefore, the most used technique for cumulant calculations is based on generating functions. This method involves approximations, and has its own biases, which complicates the interpretation of the results. In this paper we present a new exact method for direct calculations of multi-particle cumulants using moments of the flow vectors.

### **pacs:**

25.75.Ld, 25.75.Gz, 05.70.Fh

### **I Introduction**

Anisotropic flow is a response of the system created in a heavy-ion collision to the anisotropies in the initial geometry. Thus, anisotropic flow is very sensitive to the properties of the system at an early time of its evolution. The sizable azimuthal momentum-space anisotropy observed at RHIC energies (for a review, see [Voloshin:2008dg ;](#page-30-0) [Sorensen:2009cz](#page-30-1) ) is the main evidence for the nearly perfect liquid behavior [Teaney:2009qa](#page-30-2) ; [Heinz:2009xj](#page-30-3) of the created matter. Quantitatively, anisotropic flow is characterized by coefficients in the Fourier expansion of the azimuthal dependence of the invariant yield of particles relative to the reaction plane [Voloshin:1994mz ;](#page-30-4) [Poskanzer:1998yz](#page-30-5) :

Ed3Nd3p=12πd2Nptdptdy(1+∑n=1∞2vncos(n(ϕ−ΨR))).superscript3superscript312superscript2subscriptsubscript1superscriptsubscript12subscriptitalicϕsubscriptΨE\frac{d^{3}N}{d^{3}p}=\frac{1}{2\pi}\frac{d^{2}N}{p\_{t}dp\_{t}dy}\!\left(1\!+\!\sum\_{n=1}^{\infty} 2v\_{n}\cos\left(n\!\left(\phi\!-\!\Psi\_{R}\right)\right)\!\right).

Here EE is the energy of particle, ptsubscriptp\_{t} is the transverse momentum, ϕitalic-ϕ\phi is its azimuthal angle, yy is the rapidity, and ΨRsubscriptΨ\Psi\_{R} the reaction plane angle (see Fig [1](#page-1-0)). The first coefficient, v1subscript1v\_{1}, is usually called directed flow, and the second coefficient, v2subscript2v\_{2}, is called elliptic flow. In general the vn=⟨cos[n(ϕ−ΨRP)]⟩subscriptdelimited-⟨⟩italic-ϕsubscriptΨv\_{n} =\langle\cos[n(\phi-\Psi\_{RP})]\rangle coefficients are ptsubscriptp\_{t} and yy dependent – in this context we refer to them as differential flow. The integrated flow is defined as a weighted average with the invariant distribution used as a weight:

<span id="page-1-2"></span>vn≡∫0∞vn(pt)dNdptpt∫0∞dNdptpt.subscriptsuperscriptsubscript0subscriptsubscriptsubscriptdifferentialdsubscriptsuperscriptsubscript0subscriptdifferential-dsubscriptv\_{n} \equiv\frac{\displaystyle\int\_{0}^{\infty}v\_{n}(p\_{t})\frac{\displaystyle dN} {\displaystyle dp\_{t}}dp\_{t}}{\displaystyle\int\_{0}^{\infty}\frac{\displaystyle dN}{\displaystyle dp\_{t}}dp\_{t}}\,. (2)

<span id="page-1-0"></span>Refer to caption

Figure 1: Schematic view of a non-central nucleus-nucleus collision in the transverse plane.

Since the reaction plane ΨRsubscriptΨ\Psi\_{R} is not known experimentally, the anisotropic flow is estimated using azimuthal correlations between the observed particles. For example, using 2-particle azimuthal correlations:

```
⟨cos(n(ϕ1−ϕ2))⟩=⟨ein(ϕ1−ϕ2)⟩=⟨vn2⟩+δn,delimited-⟨⟩subscriptitalic-
ϕ1subscriptitalic-ϕ2delimited-⟨⟩superscriptsubscriptitalic-
ϕ1subscriptitalic-ϕ2delimited-⟨⟩
superscriptsubscript2subscript\displaystyle\langle\cos(n(\phi_{1}-
\phi_{2}))\rangle=\langle e^{in(\phi_{1}-\phi_{2})}\rangle=\langle
v_{n}^{2}\rangle+\delta_{n},
                                                                        (3)
```

where the first term, ⟨vn2⟩delimited-⟨⟩superscriptsubscript2\langle v\_{n} ^{2}\rangle, is the part due to anisotropic flow, and δnsubscript\delta\_{n} represents the so called non-flow contribution, that comes from correlations not related to the initial system geometry. If non-flow is small, Eq. ([3\)](#page-1-1) can be used to measure vnsubscriptv\_{n}, but in general the non-flow contribution is not negligible. To suppress non-flow one can exploit the collective nature of anisotropic flow using multi-particle correlations. The method based on multiparticle cumulants (genuine multi-particle correlations) to measure anisotropic flow was proposed in [Borghini:2000sa](#page-30-6) ; [Borghini:2001vi](#page-31-0) ; [Borghini:](#page-31-1) [2001zr ;](#page-31-1) [Adler:2002pu](#page-31-2) . This method allows to subtract non-flow effects from flow measurements order by order. Note that some experimental artifacts, such as track splitting, in the analysis also contribute to the two particle correlation; in this respect multi-particle techniques are also valuable, as they suppress such contributions as well.

One of the problems in using multi-particle correlations is the computing power needed to go over all possible particle multiplets, which practically prohibits calculations of correlations of order larger than k=33k=3 (threeparticle correlations). To avoid this problem, it was suggested in [Borghini:](#page-30-6)

[2000sa](#page-30-6) to express cumulants in terms of moments of the magnitude of the corresponding flow vector QnsubscriptQ\_{n}, defined as:

<span id="page-2-0"></span>Qn≡∑i=1Meinϕi,subscriptsuperscriptsubscript1superscriptsubscriptitalic<sup>ϕ</sup>Q\_{n}\equiv\sum\_{i=1}^{M}e^{in\phi\_{i}}\,, (4)

where MM is the number of particles. Unfortunately, flow estimates from cumulants constructed in such a way were systematically biased by the interference between various harmonics. An improved cumulant method using the formalism of generating functions suggested in [Borghini:2001vi](#page-31-0) ; [Borghini:2001zr](#page-31-1) fixed the problem of interfering harmonics while keeping the number of operations still linear with multiplicity MM. For this approach the analytical calculations become rather tedious and therefore the solutions are obtained using interpolation formulae. Unfortunately this introduces numerical uncertainties and requires tuning of interpolating parameters for different values of the flow harmonics vnsubscriptv\_{n} and multiplicity. More recently a Lee-Yang-Zero's sum method [BBO:2003a](#page-31-3) ; [Bhalerao:2003xf](#page-31-4) ; [Borghini:2004ke ;](#page-31-5) [Bilandzic:2008nx](#page-31-6) has been developed to suppress non-flow contribution to all orders. Closely related to that are methods of Fourier and Bessel transforms of the QQ-distributions [Voloshin:2006gz](#page-31-7) , and the method of direct fitting of the QQ-distribution. All these methods, while indeed being almost insensitive to non-flow, are biased by interference of different harmonics.

In this paper we present a new method to calculate multi-particle cumulants in terms of moments of (in general, different harmonics) QQ-vectors. In our approach the cumulants are not biased by interference between various harmonics, interpolating formulas used in the formalism of generating functions are not needed, and, moreover, all detector effects can be disentangled from the flow estimates in a single pass over the data at the level of or better than any other method. The number of operations required in our approach is still ∝Mproportional-toabsent\propto M for each kk. Since in our approach cumulants are calculated without any approximation and directly from the data we often call them direct cumulants (also referred to as QQ-cumulants because they are expressed analytically in terms of different harmonic QQ-vectors).

Flow fluctuations are an important part of an anisotropic flow study. It is believed that flow fluctuations are mostly determined by initial geometry fluctuations [Miller:2003kd](#page-31-8) of the system created in a collision. An important consequence of this is that the anisotropic flow develops relative to the socalled participant plane(s) instead of the reaction plane determined by the direction of the impact parameter [Manly:2005zy](#page-31-9) . We note that the method to calculate cumulants proposed in this paper is not influenced by how exactly the anisotropic flow is being developed.

In our simulations we show results obtained up to the 8-th order cumulant, although we think that in practice there is little advantage to go higher than order six, because going to higher order does not remove the systematic uncertainty related to contribution from clusters exhibiting flow (see the discussion of systematic uncertainties associated with cumulant analysis in [Adams:2003zg](#page-31-10) ). For example, in a 4-particle correlation analysis this bias

corresponds to the situation when two particles are correlated because they are coming from the same cluster and, in addition, correlated with another two particles via flow.

The paper is organized as follows. After the main definitions are introduced in section [II](#page-3-0), we describe how the so-called reference flow can be calculated. The reference flow is an average flow in some momentum window; it is needed for the calculation of the differential flow of particles of interest. To optimize the procedure, the reference flow can be calculated using weights, e.g. weighted with transverse momentum of the particle. Thus the reference flow can be noticeably different from integrated flow of the same particles. Section [IV](#page-8-0) describes how the differential flow is calculated. To show how the method works in different environments and how it compares to some other methods we show simulation results in section [V.](#page-11-0) Finally, we summarize the main features of the method. Technical details, including the derivation of the main equations, equations in case of using non-unity weights in the calculation of reference flow, and acceptance effects are provided in Appendices.

## <span id="page-3-0"></span>**II Multi-Particle azimuthal correlations and cumulants**

In this paper we discuss mostly 2- and 4-particle azimuthal correlations (formulae for 6-particle correlation are provided in the Appendix), but the generalization to azimuthal correlations involving more particles is straightforward. The method can be easily applied for calculations of mixed harmonics multi-particle correlations. In fact, mixed harmonics correlations are needed in our approach for calculations of any multi-particle correlations with order higher than 2. Presenting 4-particle correlations below, we also show how the 3-particle correlations, involving one particle of a double harmonic can be calculated. All the correlations are obtained by first averaging over all particles in a given event and then averaging over all events. The latter may involve weights depending on event multiplicity.

We define single-event average 2- and 4-particle azimuthal correlations in the following way:

```
⟨2⟩delimited-⟨⟩
2\displaystyle\langle
2\rangle
                    ≡\displaystyle\equiv
                                         ⟨ein(ϕ1−ϕ2)⟩≡1PM,2∑′i,j′ein(ϕi−ϕj),delimited-⟨⟩superscriptsubscriptitalic-
                                         ϕ1subscriptitalic-
                                         ϕ21subscript2subscriptsuperscript′superscriptsubscriptitalic-
                                         ϕsubscriptitalic-ϕ\displaystyle\left<e^{in(\phi_{1}-\phi_{2})}
                                         \right>\equiv\frac{1}{P_{M,2}}\,\sideset{}{{}^{\prime}}{\sum}_{i,j}
                                         e^{in(\phi_{i}-\phi_{j})}\,,
⟨4⟩delimited-⟨⟩
4\displaystyle\langle
4\rangle
                    ≡\displaystyle\equiv
                                         ⟨ein(ϕ1+ϕ2−ϕ3−ϕ4)⟩delimited-⟨⟩superscriptsubscriptitalic-ϕ1subscriptitalic-
                                         ϕ2subscriptitalic-ϕ3subscriptitalic-ϕ4\displaystyle\langle e^{in(\phi_{1}+
                                         \phi_{2}-\phi_{3}-\phi_{4})}\rangle
                    ≡\displaystyle\equiv
                                         1PM,4∑′i,j,k,l′ein(ϕi+ϕj−ϕk−ϕl),
                                         1subscript4subscriptsuperscript′superscriptsubscriptitalic-
                                         ϕsubscriptitalic-ϕsubscriptitalic-ϕsubscriptitalic-ϕ\displaystyle\frac{1}{P_{M,
```

```
4}}\,\sideset{}{{}^{\prime}}{\sum}_{i,j,k,l}\phi {k}-\phi {I})}\,,
```

where Pn,m=n!/(n-m)!subscript $PnmnnmP_{n,m}=n!/(n-m)!$ , and the prime in the sum  $\sum superscript'sideset{}{{}^{\n}}{sum}$  means that all indices in the sum must be taken different.

The second step involves averaging over all events:

```
(\langle ein(\phi 1 - \phi 2) \rangle) delimited-\langle \rangle delimited-\langle \rangle
⟨⟩2\displaystyle\langle\langle\displaystyle\equiv
((2))delimited-()delimited-
                                                           \phi2\displaystyle\eft<\li>eft<e^{in(\phi_
2\rangle\rangle
                                                           \phi {2})\
                                                           \sum \text{events}(W(2))i(2)i\sum \text{events}(W(2))i,\text{subs}(W(2))i
                                                           ⟨⟩2isubscriptdelimited-⟨⟩
                                                           2isubscripteventssubscriptsubscriptWd
                                 ≡\displaystyle\equiv ⟨⟩2i\displaystyle\frac{\displaystyle\sum
                                                           events}(W {\left<2\right>}) {i}
                                                           \left(\frac{2\right)}{\left(\frac{1}{3}\right)}
                                                           events\{(W \{\{\{i,j\}\}\}, \{i\}\}\}, \{i\}\}\}
                                                           \langle \langle ein(\phi 1 + \phi 2 - \phi 3 - \phi 4) \rangle \rangle \rangle delimited-\langle \langle elin(\phi 1 + \phi 2 - \phi 3 - \phi 4) \rangle \rangle
                                                           superscripteinsubscriptitalic-φ1subscrip
((4))delimited-()delimited-
⟨⟩4\displaystyle\langle\langle\displaystyle\equiv \phi2subscriptitalic-\phi3subscriptitalic-
                                                           φ4\displaystyle\left<\!\left<e^{in(\phi
4\rangle\rangle
                                                           \phi {2}-\phi {3}-\phi {4})}\right>\!\r
                                                           \sum \text{events}(W(4))i(4)i\sum \text{events}(W(4))i,\text{subs}(W(4))i
                                                           ⟨⟩4isubscriptdelimited-⟨⟩
                                                           4isubscripteventssubscriptsubscriptWd
                                  ≡\displaystyle\equiv ()4i\displaystyle\frac{\displaystyle\sum
                                                           events}(W {\left<4\right>}) {i}
                                                           \left<4\right>_{i}}{\displaystyle\sum_
                                                           events}(W {\left<4\right>}) {i}}\,,
```

where by double brackets we denote an average, first over all particles and then over all events. W(2) subscriptW delimited- $\langle \rangle 2W_{\text{left}} < 2 \rangle$  and W(4) subscriptW delimited- $\langle \rangle 4W_{\text{left}} < 4 \rangle$  are the event weights, which are used to minimize the effect of multiplicity variations in the event sample on the estimates of 2- and 4-particle correlations. In general, the optimal choice of weights would be determined by the multiplicity dependence of vnsubscript $vnv_{\text{left}}$  The best approach might be to calculate the cumulants at fixed MMM and then average over the entire event sample. In our calculations, with vnsubscript $vnv_{\text{left}}$  independent of multiplicity, we use:

```
  \begin{tabular}{ll} $W(2)$ subscript$W$ delimited- \\ $\langle \rangle 2 \otimes ystyle & $M(M-1),MM1 \otimes ystyle \\ $M(M-1),$, \end{tabular}
```

```
⟨⟩4\displaystyle
W_{\left<4\right>}
```

The above choice for the event weights takes into account the number of different 2- and 4-particle combinations in an event with multiplicity MM.

The general formalism of cumulants was introduced into flow analysis by Ollitrault et al [Borghini:2000sa ;](#page-30-6) [Borghini:2001vi](#page-31-0) ; [Borghini:2001zr](#page-31-1) . We will use below the notations from those papers. The 2ndsuperscript2nd2^{\rm nd} order cumulant, cn{2}subscript2c\_{n}\{2\}, is simply an average of 2 particle correlation defined in Eq. ([7](#page-4-0)):

<span id="page-5-0"></span>
$$cn{2} = \langle \langle 2 \rangle \rangle$$
.subscript $cn2$ delimited- $\langle \rangle$ delimited- $\langle \rangle$ 2c\_{n}\{2\} = \left<\left<2\right>\right>\,. (11)

As was pointed out first in [Borghini:2001vi](#page-31-0) the genuine 444-particle correlation (i.e. 444-particle cumulant), is given by:

<span id="page-5-1"></span>
$$cn\{4\} = \langle \langle 4 \rangle \rangle - 2 \cdot \langle \langle 2 \rangle \rangle 2. subscript \ cn 4 delimited - \langle \rangle delimited - \langle \rangle \\ 4 \cdot 2 superscript delimited - \langle \rangle 22 c_{n} \setminus \{4 \} \\ = \left| \left| \left| \left| \left| \left| \left| \left| \left| \left| \left| \left| \left|$$

Expressions [\(11](#page-5-0)) and ([12](#page-5-1)) are applicable only for detectors with uniform acceptance and will be generalized in Appendix [C](#page-20-0) to extend their applicability for detectors with non-uniform acceptance.

Different order cumulants provide independent estimates for the same reference harmonic vnsubscriptv\_{n}. In particular [Borghini:2001vi](#page-31-0) :

```
vn{2}
subscript2\displaystyle
v_{n}\{2\}
                     =\displaystyle= cn{2},subscript2\displaystyle\sqrt{c_{n}
                                    \{2\}}\,, (13)
vn{4}
subscript4\displaystyle
v_{n}\{4\}
                     =\displaystyle=
                                    −cn{4}4,
                                    4subscript4\displaystyle\sqrt[4]{-
                                    c_{n}\{4\}}\,,
                                                                     (14)
```

where the notation vn{2}subscript2v\_{n}\{2\} is used to denote the reference flow vnsubscriptv\_{n} estimated from the 2ndsuperscript2nd2^{\rm nd} order cumulant cn{2}subscript2c\_{n}\{2\}, and vn{4}subscript4v\_{n}\{4\} stands for the reference flow vnsubscriptv\_{n} estimated from the 4thsuperscript4th4^{\rm th} order cumulant cn{4}subscript4c\_{n}\{4\}.

# **III Reference flow**

To obtain the 2ndsuperscript2nd2^{\mathrm{nd}} order cumulant it suffices to separate diagonal and off-diagonal terms in |Qn|2superscriptsubscript2\left|Q\_{n}\right|^{2}:

```
|Qn|2=\sum_{i,j=1} Mein(\phi_i-\phi_j)=M+\sum_{i,j'} ein(\phi_i-\phi_j), superscripts ubscript Qn 2 superscript subscript disubscript lic-\phi_j M subscript superscript lic-\phi_j lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript lic-\phi_j N cript
```

which can be trivially solved to obtain (2)delimited-()2\left<2\right>:

```
 \begin{tabular}{ll} $\langle 2 \rangle = |Qn|2-MM(M-1).delimited-$\langle 2 \rangle = \|Qn|2-MM(M-1).delimited-$\langle 2 \rangle = \|frac_{\left(\|eft\|Q_{n}\right)\|} $$ (16) $$ $$ ^{2}-M}_{M(M-1)}.
```

The event averaging is being performed via Eq. ( $\frac{7}{2}$ ). The resulting expression for  $(\frac{2}{\text{climited-}})$  delimited- $(\frac{2}{\text{climited-}})$  angle  $\frac{2}{\text{climited-}}$  is than used to estimate 2ndsuperscript2nd2 $^{\text{climited-}}$  order cumulant (see Eq. ( $\frac{11}{1}$ )), which in turn is used to estimate the reference flow harmonic vnsubscript $\frac{1}{2}$  by making use of Eq. ( $\frac{13}{1}$ ).

To obtain the 4thsuperscript4th4 $^{\mathrm{th}}$  order cumulant we start with the decomposition of |Qn|4superscriptsubscriptQn4left $|Q_{n}|$ right $|Q_{n}|$  (for details, see Appendix A)

 $|Qn|4=QnQnQn*Qn*=\sum_{i,j,k,l=1} Mein(\phi_i+\phi_j-\phi_k-\phi_l).superscriptsubscript Qn4subscript Qn4subscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-\phi_lsubscriptitalic-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-opension-open$ 

We have four distinct cases for the indices ii, jj, kk and ll: 1) they are all different (4-particle correlation), 2) three are different, 3) two are different or 4) they are all the same. Note, that the case of three different indices corresponds to the so-called mixed harmonics 3-particle correlations, in many analyses of great interest by itself Adams:2003zg; Borghini:2002vp. Equations for 3-particle correlations are provided in Appendix  $\Delta$ . Taking everything into account, we obtain the following analytic result for the single-event average 4-particle correlation defined in Eq. ( $\underline{6}$ ):

```
 \langle 4 \rangle \text{delimited-()} \\ 4 \rangle \text{displaystyle} \text{left} \langle 4 \rangle \text{right} \rangle \\ = \langle 4 \rangle \text{displaystyle} \text{displaystyle} \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle \\ = \langle 4 \rangle \text{displaystyle} \rangle
```

The reason why the originally proposed cumulant analysis <u>Borghini:2000sa</u> was biased lies in the fact that the terms consisting of QQQ-vectors evaluated in different harmonics (for instance terms  $|Q2n|2superscriptsubscriptQ2n2\left|Q_{2n}\rightright|^{2}$  and  $\Re [Q2nQn*Qn*]\Re [Qelimited-[]subscript<math>Q2nsuperscriptsubscriptQnsuperscriptsubscriptQn\mathfrak{Re}$ 

[]subscriptQ2nsuperscriptsubscriptQnsuperscriptsubscriptQn\mathfrak{Re}\left[Q\_{2n}Q\_{n}^{\*}Q\_{n}^{\*}\right]) have been neglected. As seen from Eq. (18), such terms do appear in the analytic results and are crucial in disentangling the interference between harmonics. In particular, if a higher

```
harmonic v2nsubscriptv2nv_{2n} is present than  |\operatorname{Qn}| 4 \operatorname{superscriptsubscript} \mathcal{Q}_n 4 \operatorname{left}| Q_{n} \operatorname{right}|^{4} \text{ picks up an additional contribution depending on that harmonic, namely v2n2M(M-1)+vn2v2n2M } (M-1)(M-2)\operatorname{superscriptsubscriptv} 2n2MM1\operatorname{superscriptsubscriptv} 2n2MM1M2v_^{2}M(M)!-\!1)\!+\!v_{n}^{2}v_{2n}2MM1\operatorname{superscriptsubscriptv} 2n2MM1M2v_^{2}M(M)!-\!1)\!+\!v_{n}^{2}v_{2n}2M(M)!-\!1)(M)!-\!2), which is exactly canceled out with the contribution of harmonic v2nsubscriptv2nv_{2n} to |Q2 n|2\operatorname{superscriptsubscript} Q2n2\operatorname{left}|Q_{2n}\operatorname{right}|^{2} \text{ and } \Re_{\mathbb{Q}} Qnn*Qn*]\Re_{\mathbb{Q}} \operatorname{left}|Q_{2n}\operatorname{right}|^{2} \text{ and } \Re_{\mathbb{Q}} Qnn*Qn*]\Re_{\mathbb{Q}} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \text{ and } \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname{right}|^{2} \operatorname{left}|Q_{n}\operatorname
```

The final, event averaged 4-particle azimuthal correlation,  $(\langle 4 \rangle)$  delimited- $\langle \rangle$  delimited- $\langle \rangle$  4\left<\left<4\right>\right>, is then obtained by making use of Eqs. (8) and (10). Using  $(\langle 4 \rangle)$  delimited- $\langle \rangle$  delimited- $\langle \rangle$  4\left<\left<4\right>\right> and  $(\langle 2 \rangle)$  delimited- $\langle \rangle$  delimited- $\langle \rangle$  2\left<\left<2\right>\right> one can calculate the 4thsuperscript4th4^{\mathrm{th}} order cumulant from Eq. (12).

The reference flow is mainly used to calculate differential flow. Therefore, one can optimize the calculation of reference flow to minimize the uncertainties in the final results. This is done by using different weights (e.g. particle transverse momentum) in the definition of flow vectors used in reference flow calculations. We provide all the equations necessary for calculations with weights in Appendix B.

The equations so far are applicable for an analysis with a detector with full uniform azimuthal coverage. In a non-ideal case one needs to take into account the acceptance corrections Bhalerao:2003xf; Selyuzhenkov:2007zi. Acceptance affects the cumulants in three ways: (i) contributions from additional terms, e.g. proportional to  $(\langle cosn\phi \rangle) delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle delimited - \langle cosn\phi \rangle de$ 

The generalized 2ndsuperscript2nd2^{\rm nd} order cumulant which can also be used for detectors with non-uniform acceptance is:

```
 \langle \langle 2 \rangle \rangle - \Re \{ [ \langle (\cos \phi 1) \rangle + i \langle (\sin \phi 1) \rangle ]   \operatorname{cn}\{2\}   \operatorname{subscript}_{cn}2 \operatorname{displaystyle} = \operatorname{displaystyle} = \operatorname{hip}\{Re\} \operatorname{hip}\{\{\}\} \}   \operatorname{c}_{n}\{2\}   \operatorname{c}_{n}\{2\}   \operatorname{c}_{n}\{2\}   \operatorname{c}_{n}\{2\}   \operatorname{c}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\} \operatorname{cos}_{n}\{1\}
```

```
 \times [\langle \langle cosn\varphi2 \rangle \rangle -i \langle \langle sinn\varphi2 \rangle \rangle] \} \\ \langle displaystyle \rangle times \langle [] \rangle \{-\langle sinn\varphi1 \rangle \} \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi1 \rangle \rangle -i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle \} \\ \langle (2) \rangle -i \langle (sinn\varphi2 \rangle \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sinn\varphi1 \rangle +i \langle sin
```

where for the last line we have used the fact that for instance  $(\langle \cos n \rangle)$  delimited- $\langle \rangle$  delimited- $\langle \rangle$  nsubscriptitalic- $\langle \rangle$  1\left<\left<\cos n\phi\_{1}\right>\right> and  $\langle \langle \cos n \rangle 2 \rangle$  delimited- $\langle \rangle$  delimited- $\langle \rangle$  nsubscriptitalic- $\langle \rangle$  left<\left<\cos n\phi\_{2}\right>\right> are the same quantities apart from the trivial relabeling. Remarkably, only two additional terms appear in Eq. (19), namely  $\langle \langle \cos n \rangle \rangle$  2\superscriptdelimited- $\langle \rangle$  delimited- $\langle \rangle$  nsubscriptitalic- $\langle \rangle$  12\left<\left<\cos n\phi\_{1}\right>\right>\right>^{2}\ and  $\langle \langle \sin n \rangle \rangle$  2\superscriptdelimited- $\langle \rangle$  delimited- $\langle \rangle$  nsubscriptitalic- $\langle \rangle$  12\left<\left<\sin n\phi\_{1}\right>\right>^{2}\, which counterbalance the bias to  $\langle \langle 2 \rangle \rangle$  delimited- $\langle \rangle$  2\left<\left<2\right>\right>\right> coming from very general detector inefficiencies. Further details on treating the acceptance effects, including formulae for the 4thsuperscript4th4^{\rm th} order cumulant are provided in Appendix C.

### <span id="page-8-0"></span>**IV Differential flow**

Once the reference flow has been estimated with the help of the formalism from previous section, we proceed to the calculation of differential flow. For that, all particles selected for flow analysis are labeled as Reference Flow Particle, RFP, and/or Particle Of Interest, POI. These labels are needed because flow analysis is being performed in two steps. In the first step one estimates the reference flow by using only the RFPs, while in the second step we estimate the differential flow of POIs with respect to the reference flow of the RFPs obtained in the first step.

### IV.1 Reduced multi-particle azimuthal correlations

For reduced single-event average 2- and 4-particle azimuthal correlations we use the following notations and definitions:

```
\label{eq:continuous} $$ \langle 2' \rangle = \min_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle \\ = \lim_{0 \le j \le 1} \langle 2' \rangle
```

 $\equiv \text{displaystyle} = \text{displaystyle}$  displaystyle displaystyle displaystyle

```
\label{eq:continuous} $$ \end{align} $$ $$ $$ (4')delimited-{} \sup {\end{align}} $$ $$ $$ $$ (ein(\psi 1+\phi 2-\phi 3-\phi 4))delimited-{} $$ $$ $$ $$ $$ $$ $$ $$ $$ $$ $$ $$ $$
```

where mpsubscript $mpm_{p}$  is the total number of particles labeled as POI (some of which might have been also labeled additionally as RFP), mqsubscript $mqm_{q}$  is the total number of particles labeled both as RFP and POI, MMM is the total number of particles labeled as RFP (some of which might have been also labeled additionally as POI) in the event, wisubscript $\psi i \gg \{i\}$  is the azimuthal angle of the ii-th particle labeled as POI and taken from the phase window of interest (taken even if it was also additionally labeled as RFP),  $\psi$ -subscriptitalic- $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ - $\psi$ 

Final, event averaged reduced 2- and 4-particle correlations are given by:

```
∑events(w(2′))i(2′)i∑events
                                                                                                                                                                                                                                                                                                                      ()superscript2'isubscriptdel
     ((2'))delimited-()delimited-()
                                                                                                                                                                                                                                                                                                                      superscript2'isubscripteven
     superscript2'\displaystyle\langle\langle \equiv\displaystyle\equiv \\superscript2'\displaystyle
     2^{\prime}\rangle\rangle
                                                                                                                                                                                                                                                                                                                      events}(w_{\left<2^{\prim
                                                                                                                                                                                                                                                                                                                      2^{\prime}\rangle {i}}{\d
                                                                                                                                                                                                                                                                                                                      (w {\left<2^{\prime}\right
                                                                                                                                                                                                                                                                                                                      \sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum \text{events}(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)i\langle 4'\rangle i\sum events(w\langle 4'\rangle)
                                                                                                                                                                                                                                                                                                                      ()superscript4'isubscriptdel
     ((4'))delimited-()delimited-()
                                                                                                                                                                                                                                                                                                                      superscript4'isubscriptevents
     superscript4'\displaystyle\angle = \displaystyle\equiv superscript4'i\displaystyle\f
     4^{\prime}\rangle\rangle
                                                                                                                                                                                                                                                                                                                      events}(w {\left<4^{\prim
                                                                                                                                                                                                                                                                                                                      \left<4^{\prime}\right> {i
                                                                                                                                                                                                                                                                                                                      (w {\left<4^{\prime}\right</pre>
 In our calculations we use event weights w(2')subscriptwdelimited-()
superscript2'w {\left<2^{\prime}\right>} and w(4')subscriptwdelimited-()
 superscript4'w {\left<4^{\prime}\right>} defined as:
     w(2')
     subscriptwdelimited-()
    superscript2'\displaystyle \equiv \text{displaystyle} \land mpM-mq, subscript_{mpM} subscript_{mq} \land m_{q}\
w \left\{\left\{ \frac{2^{\left( \frac{1}{m}\right)}}{m_{q}} \right\}\right\}
     w {\left<2^{\prime}
     \right>}
     w(4')
     subscriptwdelimited-()
    superscript4'\displaystyle \equiv\displaystyle\equiv (mpM-3mq)(M-1)(M-2).subscriptmpM3s w {\left<4^{\prime}}
     w {\left<4^{\prime}</pre>
     \right>}
```

### IV.2 Differential cumulants

We derive equations for the differential equations with the help of  $p_pp$ - and  $q_qq$ -vectors; the former built out of all POIs (mpsubscript $m_pm_{qp}$  in total), and the second only from POI labeled also as RFP (mqsubscript $m_qm_{qp}$  in total):

The  $q_q$ q-vector is introduced here in order to subtract effects of autocorrelations. Using those, we have obtained the following equations for the average reduced single- and all-event 2-particle correlations:

```
\label{eq:continuous} $$ \langle 2'\rangle \leq |\nabla - \nabla - \nabla - \nabla - \nabla - \nabla - \nabla - \nabla - \nabla - \nabla
```

For detectors with uniform azimuthal acceptance the differential 2ndsuperscript2nd2^{\rm nd} order cumulant is given by

```
dn\{2\} = \langle (2') \rangle, subscript dn 2 delimited -\langle (n) \rangle delimited -\langle (n) \rangle (30) -\langle (n) \rangle (30)
```

where, again we use notation from Ref. <u>Borghini:2001vi</u>. We present equations for the case of detectors with non-uniform acceptance in Appendix  $\underline{C}$ .

Estimates of differential flow vn′subscriptsuperscript $v'nv^{\rho}$  are being denoted as vn′{2}subscriptsuperscript $v'n2v^{\rho}$ , and are given by  $\underline{Borghini:2001vi}$ :

```
 vn'\{2\} \\ subscriptsuperscript v'n2 \ displaystyle = \ dn\{2\}cn\{2\}. \\ subscriptdn2 subscript v'n2 \ v^{\prime}_{n}\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
```

Below we present the corresponding formulae for reduced 4-particle correlations:

```
\label{eq:continuous} $$ \displaystyle\eft<4^{\sigma}\circ =\displaystyle=
```

-\displaystyle-  $Q_{n}+q^2nQ^2n^*+2q^2nQ^2n^*+2q^2nQ^2n^*+2q^2q^2n^2q^2n^2q^2q^2n^2q^2q^2q^2q^2q^2q^2q^2q^2q^2q^2q^2q^2q^$ 

```
+\displaystyle+\ 2\cdot mqM-6\cdot mq]\displaystyle+\ 2\cdot mqM-6\cdot mq]\displaystyle+\ (mpM-3mq)(M-1)(M-1)(M-2)\bigg\{]\}\,, ((4')\delimited-()\superscript4'
```

The 4thsuperscript4th4^{\rm th} order differential cumulant is given by <u>Borghini:2001vi</u>:

Equations for the case of detectors with non-uniform acceptance are again presented in Appendix  $\underline{C}$ .

Having obtained estimates for  $dn{4}$  subscript $dn{4d}_{n}\$  and  $cn{4}$  subscript $cn{4c}_{n}\$ , we can estimate differential flow  $\underline{Borghini:2001vi}$ :

```
 vn'\{4\} \\ subscriptsuperscript v'n4 \ displaystyle = \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
```

Similarly to reference flow, we use the notation  $vn'\{4\}$  subscriptsuperscript $v'n4v^{\rho}=\{n\}\{4\}$  for differential flow harmonics vn'subscriptsuperscript $v'nv^{\rho}=\{n\}$  obtained from 4thsuperscript4th4 $^{\phi}=\{n\}$  order cumulants.  $vn'\{4\}$  subscriptsuperscript $v'n4v^{\rho}=\{n\}\{4\}$  and  $vn'\{2\}$  subscriptsuperscript $v'n2v^{\rho}=\{n\}\{2\}$  are independent estimates for the same differential flow harmonic vn'subscriptsuperscript $v'nv^{\rho}=\{n\}$ .

### <span id="page-11-0"></span>**V** Simulation results

We have tested the new method with extensive simulations. The results, presented below, show that the method effectively suppresses non-flow contributions, illustrate the ability to remove the interference of the different harmonics, show the applicability for detectors having significant acceptance "holes", and give an example of a differential flow analysis. In the figures, v2  $\{MC\}$  subscript $v2MCv_{2}\$  rm  $MC\$ , shown in the first bin, represents the Monte Carlo estimate for vnsubscript $vnv_{n}$ , which was obtained using the known reaction plane event-by-event. Other estimates in the figures are obtained without using this information.

<span id="page-11-1"></span>Refer to caption

Figure 2: Elliptic flow extracted by different methods for 105superscript10510^{5} simulated events with multiplicity M=500500M=500, v2=0.05subscript20.05v\_{2}=0.05 and at the same time v4=0.1subscript40.1v\_{4}=0.1.

Figure [2](#page-11-1) shows the results from a simulation of events with anisotropic flow present in two harmonics, the second and the fourth. Elliptic flow estimated by different methods is shown in the figure. A clear bias is observed in the estimates from fitting of the QQ-distribution method and the Lee-Yang Zero's Sum method, labeled as v2{FQD}subscript2FQDv\_{2}\{\rm FQD\} and v2{LYZS}subscript2LYZSv\_{2}\{\rm LYZS\}, respectively. Results obtained with direct cumulants of different order, labeled as v2{k,QC} subscript2QCv\_{2}\{k,{\rm QC}\}, are unaffected by v4subscript4v\_{4} interference.

<span id="page-12-0"></span>Refer to caption

(a)

Refer to caption

(b)

Refer to caption

(c)

Figure 3: a) The azimuthal distribution of accepted particles. b) Extracted elliptic flow accounting for acceptance effects, closed markers, and without, open markers. c) Extracted elliptic flow accounting for acceptance effects in different methods.

To demonstrate that the method works well even in cases with rather bad acceptance we simulated 107superscript10710^{7} events with v2=0.05subscript20.05v\_{2}=0.05 for a detector that had two large "holes" (see Fig. [3](#page-12-0)a). Figure [3b](#page-12-0) shows the obtained v2subscript2v\_{2} estimates using Eqs. [\(11](#page-5-0)) and ([12](#page-5-1)) which are valid for detectors with perfect acceptance using open markers. Clearly these values are strongly biased. The v2subscript2v\_{2} estimates obtained from the more general equations for cumulants, namely Eqs. ([66\)](#page-20-1) and ([71\)](#page-21-0), which do account for the acceptance effects are shown as closed markers and agree with the Monte Carlo estimate. In Fig. [3c](#page-12-0) we look in more detail at the agreement with the Monte Carlo estimate and, in addition, compare to other methods.

The figure clearly shows that detector effects are corrected for at the level of or better than other methods.

As an example of a differential flow analysis we show results for v2′(pt)subscriptsuperscript′2subscriptv^{\prime}\_{2}(p\_{t}) obtained with Therminator [Kisiel:2005hn](#page-31-13) . As RFPs we select pions and as POIs we select protons. In the first step we estimate the reference flow by only making use of particles labeled as RFPs (using Eqs. [\(11](#page-5-0)), [\(12\)](#page-5-1), ([13](#page-5-2)) and ([14\)](#page-5-3)). The estimates of reference flow are presented in Fig. [4.](#page-13-0)

<span id="page-13-0"></span>Refer to caption

Figure 4: Reference flow extracted from particles labeled as RFPs (pions in Therminator)

In the second step we estimate the differential flow of POIs (in this example protons were labeled as POIs) with respect to the reference flow of RFPs estimated in the first step. For each ptsubscriptp\_{t} bin we evaluate dn{2} subscript2d\_{n}\{2\} and dn{4}subscript4d\_{n}\{4\}, and use equations ([31](#page-10-0)) and ([35](#page-11-2)) to estimate differential flow. The differential flow results for protons are presented in Fig. [5](#page-13-1).

<span id="page-13-1"></span>Refer to caption

Figure 5: Differential flow extracted for particles labeled as POIs from Therminator events (in this example we used protons). The open circles denote 2ndsuperscript2nd2^{\rm nd} order estimate (Eq. [\(31\)](#page-10-0)) and closed squares denote 4thsuperscript4th4^{\rm th} order estimate (Eq. ([35](#page-11-2))).

The resulting ptsubscriptp\_{t}-integrated flow of protons calculated by making use of Eq. ([2](#page-1-2)) is presented in Fig. [6.](#page-13-2)

<span id="page-13-2"></span>Refer to caption

Figure 6: ptsubscriptp\_{t}-integrated flow calculated from Eq. ([2](#page-1-2)) of protons whose differential flow is presented in Fig. [5.](#page-13-1)

The figures for the integrated flow of the RFPs and POIs clearly show that the 2ndsuperscript2nd2^{\rm nd} order cumulant is biased by nonflow while the higher order cumulants are in perfect agreement with the Monte Carlo.

### **VI Summary**

In summary, we propose a new method to calculate multi-particle azimuthal correlations, which provides fast (in a single scan over the data) and exact (no approximations) non-biased (no interference between different harmonics) estimates for cumulants. In the paper, we provide the corresponding formulae for correlations up to the 6-th order, but the method, if needed, can be generalized for higher orders.

We have not discussed issues of the cumulant approach in general, such as multiplicity fluctuations, flow fluctuations, and low sensitivity for small flow values, but believe that our method will be helpful in investigating all these questions.

The proposed method has been extensively tested in simulations and has been used for real data analysis by the STAR and ALICE Collaborations [Dhevan:PhD ;](#page-31-14) [Ante:PhD](#page-31-15) . Further details about the method, including equations for 8-particle correlations, equations for estimates and evaluation of statistical errors, comparison to other methods, can be found in [Ante:PhD](#page-31-15) .

### Acknowledgements.

We thank Dhevan Gangadharan, Rene Kamermans, Naomi van der Kolk, Paul Kuijer, Mikolaj Krzewicki, Art Poskanzer, Gerard Smit, Paul Sorensen, Aihong Tang, Jim Thomas, Adam Trzupek, Fugiang Wang and Evan Warren for their help, discussions, and interest in this work. The work of SV was supported in part by the US Department of Energy, Grant No. DE-FG02-92ER40713. The work of AB and RS was supported in part by the Dutch funding agencies FOM and NWO.

# <span id="page-14-0"></span>Appendix A Equations for 3-, 4- and 6particle correlations

Below we use the following definitions:

```
\langle 2 \rangle \equiv \langle 2 \rangle n | ndelimited - \langle 2 \rangle subscript delimited - \langle 2 \rangle
\frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}{2} = \frac{1}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ≡\displaystyle\! 1s
 n}
 \langle 2 \rangle 2n|2nsubscriptdelimited-\langle \rangle 2conditional2n2n \rangle displaystyle \langle
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ≡\displaystyle\! 1s
 2\rangle \{2n|2n\}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                \eauiv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ≡\displaystyle\! 1s
 (3)2n|n,nsubscriptdelimited-()
 3conditional2nnn\displaystyle\left<3\right> {2n|n,n}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                \equiv
 (3)n,n|2nsubscriptdelimited-()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ≡\displaystyle\! (3
 3n conditional n 2n \displays tyle \left < 3\right > \{n,n|2n\}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                \equiv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ≡\displaystyle\! 1s
 \langle 4 \rangle \equiv \langle 4 \rangle n, n | n, ndelimited - \langle \rangle 4 subscript delimited - \langle \rangle
4n conditional nnn \displaystyle \left < 4\right > \equiv \left < 4\right > \frac{1}{1} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < 4\right > \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac{1}{2} \left < \frac
 n,n}
```

1F

 $\Phi i$ 

e′ 1F

 $\Phi i$ \_{ 1F

 $\Phi i$ 

n, 1F

\si \p

Using this notation one finds:

```
|Qn|4superscriptsubscriptQn4\displaystyle\|eft| =\displaystyle= 4nconditionalnnnsubscriptPM
 Q {n}\right|^{4}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   n,n\cdot P_{M,4}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  [\langle 3 \rangle 2n|n,n+\langle 3 \rangle n,n|2n] \cdot PM,3 \cdot c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   +\displaystyle+ 3,000ditional2,nnsubscriptde
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  3nconditionaln2nsubscriptPM
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   n,n}+\left( -3\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -\left( n,n\right) -
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    \langle 2 \rangle n | n \cdot 4PM, 2(M-1) \cdot subscript
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      +\displaystyle+ 2conditionalnn4subscriptPM2
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   n}\cdot 4P \{M,2\}(M-1)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     +\displaystyle+
```

```
(2)2n|2n\cdot PM, 2\cdot subscript delin

2conditional 2n 2n subscript PM

2n\}\cdot cdot\ P_{M,2}

+\cdot displaystyle+\ 2PM, 2+M. 2subscript PM 2M \cdot displaystyle+
```

The 2-particle correlations  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript delimited -  $\langle 2 \rangle_n$  | nsubscript

 $2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot n = 2 \cdot$ 

```
\label{eq:conditional2n2n} $$ \langle 2 \rangle_n|2n=|Q2n|2-MPM,2.subscriptdelimited-\langle \rangle $$ 2conditional2n2nsuperscriptsubscript$$ 2n2Msubscript$$PM2 \cap (42) 2 \cap (2n)=\frac{2n}{n}^{2n}. $$
```

To obtain  $\langle 3 \rangle 2n|n$ ,nsubscriptdelimited- $\langle \rangle 3$ conditional2nnn\left<3\right>\_{2n|n,n} and  $\langle 3 \rangle n$ ,n|2nsubscriptdelimited- $\langle \rangle 3n$ conditionaln2n\left<3\right>\_{n,n|2n} we have to decompose

```
Q2nQn*Qn*subscriptQ2nsuperscriptsubscriptQnsuperscriptsubscriptQn\displaystyle Q_{2n}Q_{n}^{*}Q_{n}^{*}
```

+\displaysty

and QnQnQ2n\*subscriptQnsubscriptQnsuperscriptsubscript $Q2nQ_{n}Q_{n}Q_{n}Q_{n}Q_{n}Q_{n}Q_{n}Q_{n$ 

```
 \begin{array}{lll} & 2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*Qn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q2nQn*]-2\Re \{[Q
```

After inserting Eqs. (16), (42) and (44) into Eq. (41) and solving the resulting expression for  $\langle 4 \rangle n, n|n, n$ subscriptdelimited- $\langle 1 \rangle n, n|n, n$  the single-event average 4-particle correlations (Eq.(18)) follows.

This derivation can be generalized to obtain analytic results for any higher order multi-particle azimuthal correlations. Below we provide the expression for the 6-particle correlation:

```
(6) delimited-() 6\displaystyle\left<6\right> \equiv\displaystyle\equiv
```

1PM,6∑′i,j,k,l,m,n=1′M′ein(ϕi+ϕj+ϕk−ϕl−ϕm−ϕn)1subscript6superscriptsubscriptsuperscript′1superscriptsubscriptitalicϕsubscriptitalic-ϕsubscriptitalic-ϕsubscriptitalic-ϕsubscriptitalic-ϕsubscriptitalic-ϕ\displaystyle\frac{1}{P\_{M,6}}\sideset{}{{} ^{\prime}}{\sum}\_{i,j,k,l,m,n=1}^{M}\!\!\!\!\!\!e^{in(\phi\_{i}+\phi\_{j}+\phi\_{k}-\phi\_{l}-\phi\_{m}-\phi\_{n})} =\displaystyle= |Qn|6+9⋅|Q2n|2|Qn|2−6⋅ℜ[Q2nQnQn∗Qn∗Qn∗]M(M−1)(M−2)(M−3)(M−4)(M−5)superscriptsubscript6⋅9superscriptsubscript22superscriptsubscript2⋅6ℜdelimited- []subscript2subscriptsuperscriptsubscriptsuperscriptsubscriptsuperscriptsubscript12345\displaystyle\frac{\left| Q\_{n}\right|^{6}\!+\!9\cdot\left|Q\_{2n}\right|^{2}\left|Q\_{n}\right|^{2}\!-\!6\cdot\mathfrak{Re}\left[Q\_{2n}Q\_{n}Q\_{n}^{\*} Q\_{n}^{\*}Q\_{n}^{\*}\right]}{M(M-1)(M-2)(M-3)(M-4)(M-5)} +\displaystyle+ 4ℜ[Q3nQn∗Qn∗Qn∗]−3⋅ℜ[Q3nQ2n∗Qn∗]M(M−1)(M−2)(M−3)(M−4)(M−5)4ℜdelimited- []subscript3superscriptsubscriptsuperscriptsubscriptsuperscriptsubscript⋅3ℜdelimited- []subscript3superscriptsubscript2superscriptsubscript12345\displaystyle 4\,\frac{\mathfrak{Re}\left[Q\_{3n}Q\_{n} ^{\*}Q\_{n}^{\*}Q\_{n}^{\*}\right]-3\cdot\mathfrak{Re}\left[Q\_{3n}Q\_{2n}^{\*}Q\_{n}^{\*}\right]}{M(M-1)(M-2)(M-3)(M-4)(M-5)} +\displaystyle+ 29(M−4)⋅ℜ[Q2nQn∗Qn∗]+2⋅|Q3n|2M(M−1)(M−2)(M−3)(M−4)(M−5)2⋅94ℜdelimited- []subscript2superscriptsubscriptsuperscriptsubscript⋅2superscriptsubscript3212345\displaystyle 2\, \frac{9(M-4)\cdot\mathfrak{Re}\left[Q\_{2n}Q\_{n}^{\*}Q\_{n}^{\*}\right]+2\cdot\left|Q\_{3n}\right|^{2}}{M(M-1)(M-2)(M-3)(M-4) (M-5)} −\displaystyle- 9|Qn|4+|Q2n|2M(M−1)(M−2)(M−3)(M−5)9superscriptsubscript4superscriptsubscript221235\displaystyle 9\,\frac{\left| Q\_{n}\right|^{4}+\left|Q\_{2n}\right|^{2}}{M(M-1)(M-2)(M-3)(M-5)} +\displaystyle+ 18|Qn|2M(M−1)(M−3)(M−4)18superscriptsubscript2134\displaystyle 18\,\frac{\left|Q\_{n}\right|^{2}}{M(M-1)(M-3)(M-4)} −\displaystyle- 6(M−1)(M−2)(M−3).6123\displaystyle\frac{6}{(M-1)(M-2)(M-3)}\,.

With that, the 6thsuperscript6th6^{\rm th} order cumulant is given by

```
cn{6}=⟨⟨6⟩⟩−9⋅⟨⟨2⟩⟩⟨⟨4⟩⟩+12⋅⟨⟨2⟩⟩3,subscript6delimited-⟨⟩delimited-⟨⟩
6⋅9delimited-⟨⟩delimited-⟨⟩2delimited-⟨⟩delimited-⟨⟩
4⋅12superscriptdelimited-⟨⟩delimited-⟨⟩23c_{n}\{6\}
=\left<\left<6\right>\right>-9\cdot\left<\langle
2\rangle\right>\left<\left<4\right>\right>+12\cdot\left<\langle
2\rangle\right>^{3}\,,
                                                                         (46)
```

and the reference flow vnsubscriptv\_{n} is estimated as

$$vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}=14cn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript vn{6}6.subscript v$$

### <span id="page-16-0"></span>**Appendix B Particle weights**

Below we provide formulae to use for the case when the reference flow is calculated using particle weights. For that we introduce a weighted QQvector evaluated in harmonic nn:

<span id="page-16-1"></span>Qn,k≡∑i=1Mwikeinϕi,subscriptsuperscriptsubscript1superscriptsubscriptsuperscriptsubscriptitalic<sup>ϕ</sup>Q\_{n,k}\equiv\sum\_{i=1}^{M}w\_{i}^{k}e^{in\phi\_{i}}\,, (48)

where wisubscriptw\_{i} is a particle weight of the ii-th particle labeled as RFP and MM is the total number of RFPs in an event. In general, we will need flow vectors with power kk up to the order of multi-particle correlations. Similarly, we define

```
pn,ksubscriptpnk\displaystyle
p {n,k}
```

```
\Sigma i=1mpwikein\psii.superscriptsubscript {m_{p}}w_{i}^{k}e^{in\beta_{i}}
```

Note that only particles which have a RFP label, have a non-unit weight, while for the particles labeled as POI only, wi=1subscript $wi1w_{i1}=1$ . For the subset of POIs which consists of all particles labeled both as POI and RFP (mqsubscript $mqm_{q}$  in total) we introduce

```
qn,ksubscriptqnk\displaystyle =\displaystyle\equiv \sum_{i=1}^{i=1}mqwikein\psii.superscriptsubscript q_{n,k} m_{q,k} m_{q,k} m_{q,k} m_{q,k}
```

For RFPs we also introduce:

For all particles labeled both as RFP and POI we evaluate the following quantity:

while in the definition below the first sum runs over all POIs in the window of interest and the remaining sums run over all RPs in an event

```
\label{eq:linear_mathing_problem} $$ $\operatorname{Mabcd} $ : = \lim_{j \to \infty} j,k,l,\ldots = 1'M' wiawjbwkcwld. $$ $$ $
```

Using the definitions presented above the weighted single-event 2- and 4-particle correlations are given by:

```
 \begin{array}{lll} & 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1 \\ 1
```

The event weights (9) and (10) now read

```
 \begin{array}{l} \text{W(2)} \\ \text{subscript} \\ \text{W} \\ \text{elimited-} \equiv \\ \text{displaystyle} \\ \text{equiv} \\ \text{$-\{11\}$} \\ \text{,} \end{array}
```

```
()2\displaystyle
  W {\langle
  2\rangle}
  W(4)
  subscriptWdelimited-
\equiv \text{displaystyle} \neq \text{displaystyle} 
                                                                                                                                {1111}\,.
  ()4\displaystyle
  W {\left<4\right>}
Analogously, the reduced single-event multi-particle correlations now read:
  (2')delimited-()superscript2'
                                                                                                                                    \equiv \text{displaystyle} \cdot 1 \times 01 \cdot \sum_{i=1}^{n} \text{mp} \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{i=1}^{n} \text{mp} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wjein} \cdot 01 \cdot \sum_{j=1}^{n} M' \text{wj
  \displaystyle\left<2^{\prime}\right>
                                                                                                                                   \!\equiv
                                                                                                                                                                                    φi\displaystyle\!\!\frac{1}{
                                                                                                                                                                                    1M0111'\Sigma i=1mp\Sigma'i,k,l=1'M'
                                                                                                                                    ≡\displaystyle\! 1subscriptsuperscriptM′011
  (4')delimited-()superscript4'
                                                                                                                                                                                    φ<sub>i</sub>subscriptitalic-φ<sub>k</sub>subscript
  \displaystyle\left<4^{\prime}\right>
                                                                                                                                   \!\equiv
                                                                                                                                                                                    w \{k\}w \{l\}\,e^{in(\psi \{i\})}
where the event weights (24) and (25) are now:
  w(2')
  superscript2'\displaystyle \equiv\displaystyle\equiv ^{\infty}01',subscriptsuperscript^{\infty}01\displaystyle ^{\infty}_{\prime}_{01}\,,
  subscriptwdelimited-()
  w {\left<2^{\prime}</pre>
  \right>}
  w(4')
  subscriptwdelimited-()
  superscript4'\displaystyle \equiv\displaystyle\equiv ^{M0111'}.subscriptsuperscript^{M'0111'}\displaystyle ^{\ell}_{\prime}_{0111}\,.
  w {\left<4^{\prime}
  \right>}
The weighted average 2-particle correlations are given by the following
equations:
                                                                                                                                                                                                     |Qn,1|2-S1,2S2,1-S1
  (2)delimited-()2\displaystyle\langle 2\rangle =\displaystyle=
                                                                                                                                                                                                     Q_{n,1}\right]^{2}-S
                                                                                                                                                                                                     \Sigma i = 1N(M11)i\langle 2 \rangle i \Sigma i = 1N
  ((2))delimited-()delimited-()
                                                                                                                                                                                                     2isuperscriptsubscript
                                                                                                                                       =\displaystyle=
  2\displaystyle\left<\langle 2\rangle\right>
                                                                                                                                                                                                     \{11\}) \{i\}\langle\ 2\rangle
  M11subscriptM11\displaystyle\mathcal{M}
                                                                                                                                      \equiv \text{displaystyle} = \sum_{j=1}^{\infty} M'wiwjsuperscr \\ \{\text{prime}\} \{\text{sum}\}_{i=1}^{\infty}
  {11}
                                                                                                                                                                                                     S2,1-S1,2, subscript S2
                                                                                                                                       =\displaystyle=
and the weighted average 4-particle correlations are given by:
                                                                                                                                                                                                                    [|Qn,1|4+|Q2n,2|
  <4)delimited-()4\displaystyle\left<4\right>
                                                                                                                                                      =\displaystyle=
                                                                                                                                                                                                                     2}\right|^{2}-2\d
                                                                                                                                                                                                                    8. Re[Qn, 3Qn, 1*]
                                                                                                                                                      +\displaystyle+
                                                                                                                                                                                                                    []subscriptQn3sup
                                                                                                                                                                                                                     8\cdot\mathfrak{
```

```
-\displaystyle-
                                                                    6.S1,4-2.S2,2]/N
M1111subscriptM1111\displaystyle\mathcal{M}
                                                                    \sum i,j,k,l=1'M'wiwjw
                                                ≡\displaystyle\equiv
_{1111}
                                                                    {{}^{\prime}}{
                                                                    S4,1-6.S1,2S2,1
                                                =\displaystyle=
                                                                    S {4,1}-6\cdot S
                                                                    6.S1,4,.6subscrip
                                                -\displaystyle-
                                                                    \Sigma i = 1N(M1111)i\langle 4 \rangle
((4))delimited-()delimited-()
                                                                    4isuperscriptsubs
                                                =\displaystyle=
4\displaystyle\left<\left<4\right>\right>
                                                                    {1111}) {i}\left
where the weighted QQQ-vector, Qn,ksubscriptQnkQ \{n,k\}, was defined in Eq.
(48) and Sp,ksubscriptSpkS {p,k} in Eq. (51).
Weighted reduced 2- and 4-particle azimuthal correlations are given by the
following formulas:
                                                                           k1,nQ0,nq
(2')delimited-()superscript2'
                                                       =\displaystyle=
\displaystyle\left<2^{\prime}\right>
                                                                           ^{*}-s_{1
                                                                           \Sigma i = 1N(MC)
((2'))delimited-()delimited-()superscript2'
                                                                           superscrip
                                                       =\displaystyle=
\displaystyle\left<\left<2^{\prime}\right>\right>
                                                                           \left<2^{\
and,
(4')delimited-()superscript4'\displaystyle\left<4^ {\prime}</pre>
                                                            =\displaystyle=[pn,0Qn,1
\right>
                                                                          q2n,1Qn,
                                                            -\displaystyle-
                                                                           q_{2n,1}
                                                                           2·S1,2pn,
                                                            -\displaystyle-
                                                                           2\cdot S
                                                                           7.qn,2Qn,
                                                            +\displaystyle+
                                                                           Q {n,1}^
                                                                           q2n,1Q2n
                                                            +\displaystyle+
                                                                           Q {2n,2}
                                                            +\displaystyle+ 2·s1,1S1,
```

 $\label{eq:continuous} $$ \langle \langle 4' \rangle \rangle = \min_{\coloredge = 0}$ 

<span id="page-19-0"></span> $\begin{tabular}{ll} $$ $M0111'subscriptsuperscript$M'0111\displaystyle\mathcal{M} $$ =\displaystyle\! $$ $$ ^{\prime}_{0111}$$ 

 $-\displaystyle\$   $3\cdot[s1,1(S2)]$   $[]subscription (S_{2,1})$ 

We note that to evaluate all quantities appearing on the right hand sides in analytic expressions (62-65) only a single loop over data is required.

### <span id="page-20-0"></span>**Appendix C Non-uniform acceptance**

Building cumulants from multi-particle correlations we have so far omitted terms which vanish for the detectors with uniform acceptance. For a more general case they have to be kept <u>Borghini:2000sa</u>; <u>Borghini:2001vi</u>; <u>Selyuzhenkov:2007zi</u>; <u>K:1962</u>. The more general 2ndsuperscript2nd2^{\mathrm{nd}} order cumulant now reads:

```
((2))—limit-fromdelimited-()
cn{2}
subscriptcn2\displaystyle =\displaystyle= \frac{delimited-\langle \rangle}{2\sqrt{displaystyle}}
                                                      2\displaystyle\langle\langle
c \{n\} \setminus \{2\}
                                                      2\rangle\rangle-
                                                     [(\langle \cos n\phi 1 \rangle) 2 + \langle \langle \sin n\phi 1 \rangle) 2]. delimited-
                                                     []superscriptdelimited-()delimited-()
                                                     nsubscriptitalic-
                                                                                                      (66)
                                                      φ12superscriptdelimited-()
                                                     delimited-()nsubscriptitalic-
                                                      $12\displaystyle\left[\left<\left<\cos</pre>
                                                     n\phi {1}\right/right>^{2}+
                                                     \left<\left<\sin
                                                      n\phi {1}\right>\right>^{2}\right]
```

The correction terms can be expressed in terms of the real and imaginary parts of the QQQ-vector (4):

```
\Sigma i=1N(\Re e[Qn])i\Sigma i=1NMi,superscriptsubs
((cosn\phi1))delimited-()
                                                  []subscriptQnisuperscriptsubscripti1Nsub
delimited-()nsubscriptitalic-
φ1\displaystyle\left<\left<\cos
                                                   ^{N}\left( \mathbb{R}^{Re}\right) 
n\phi {1}\right>\right>
                                                   M \{i\} \} \setminus
(\sinn\phi1)\delimited-(\)
                                                   \Sigma i=1N(\Im m[Qn])i\Sigma i=1NMi.superscriptsubs
                                 =\displaystyle= []subscriptQnisuperscriptsubscripti1Nsub
delimited-()nsubscriptitalic-
$1\displaystyle\left<\left<\sin</pre>
                                                  ^{N}\left(\mathfrak{Im}\left[Q {n}\right]
n\phi {1}\right>\right>
                                                   M \{i\}\\,.
```

When particle weights are used the average 2-particle correlation  $(\langle 2 \rangle)$  delimited- $\langle 2 \rangle$  delimited- $\langle 2 \rangle$  and  $\langle 2 \rangle$ , while Eqs. (67) and (68) generalize into:

```
 \langle \langle \cosh \rangle \rangle | \text{delimited-} \langle \rangle \\ \text{delimited-} \langle \rangle \\ \text{nsubscriptitalic-} \\ \phi 1 | \text{displaystyle} \rangle | \text{left} \langle \text{left} \rangle \\ \text{os} \\ \text{hlipping} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{os} \\ \text{
```

where Qn,1subscript1Q\_{n,1} can be determined from the definition of the weighted QQ-vector ([48\)](#page-16-1) and S1,1subscript11S\_{1,1} from definition [\(51](#page-17-0)).

The generalized 4thsuperscript4th4^{\mathrm{th}} order cumulant reads:

<span id="page-21-0"></span>

| cn{4}<br>subscript𝑐𝑛4\displaystyle<br>=\displaystyle=<br>c_{n}\{4\} | ⟨⟨4⟩⟩−2⋅⟨⟨2⟩⟩2−delimited-⟨⟩delimited-⟨⟩4limit<br>from⋅2superscriptdelimited-⟨⟩delimited-⟨⟩<br>22\displaystyle\left<\left<4\right>\right>-2\cdot\left<\langle<br>2\rangle\right>^{2}-                                                                                                                                                                                   |
|---------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| −\displaystyle                                                      | 4⋅⟨⟨cosnϕ1⟩⟩⟨⟨cosn(ϕ1−ϕ2−ϕ3)⟩⟩⋅4delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic-ϕ2subscriptitalic-ϕ3\displaystyle<br>4\cdot\left<\left<\cos<br>n\phi_{1}\right>\right>\left<\left<\cos n(\phi_{1}-\phi_{2}-<br>\phi_{3})\right>\right>                                                                    |
| +\displaystyle+                                                     | 4⋅⟨⟨sinnϕ1⟩⟩⟨⟨sinn(ϕ1−ϕ2−ϕ3)⟩⟩⋅4delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic-ϕ2subscriptitalic-ϕ3\displaystyle<br>4\cdot\left<\left<\sin n\phi_{1}\right>\right>\left<\left<\sin<br>n(\phi_{1}-\phi_{2}-\phi_{3})\right>\right>                                                                        |
| −\displaystyle-                                                     | ⟨⟨cosn(ϕ1+ϕ2)⟩⟩2−⟨⟨sinn(ϕ1+ϕ2)⟩⟩2superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ1subscriptitalic<br>ϕ22superscriptdelimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic-ϕ22\displaystyle\left<\left<\cos<br>n(\phi_{1}+\phi_{2})\right>\right>^{2}-\left<\left<\sin<br>n(\phi_{1}+\phi_{2})\right>\right>^{2}                                        |
| +\displaystyle+                                                     | 4⋅⟨⟨cosn(ϕ1+ϕ2)⟩⟩⋅4delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic-ϕ2\displaystyle 4\cdot\left<\left<\cos<br>n(\phi_{1}+\phi_{2})\right>\right>                                                                                                                                                                                                          |
| ×\displaystyle\times                                                | [⟨⟨cosnϕ1⟩⟩2−⟨⟨sinnϕ1⟩⟩2]delimited-[]superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ12superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic<br>ϕ12\displaystyle\left[\left<\left<\cos<br>n\phi_{1}\right>\right>^{2}-\left<\left<\sin<br>n\phi_{1}\right>\right>^{2}\right]                                                                                |
| +\displaystyle+                                                     | 8⋅⟨⟨sinn(ϕ1+ϕ2)⟩⟩⟨⟨sinnϕ1⟩⟩⟨⟨cosnϕ1⟩⟩⋅8delimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ1subscriptitalic-ϕ2delimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1\displaystyle 8\cdot\left<\left<\sin<br>n(\phi_{1}+\phi_{2})\right>\right>\left<\left<\sin<br>n\phi_{1}\right>\right>\left<\left<\cos<br>n\phi_{1}\right>\right> |
| +\displaystyle+                                                     | 8⋅⟨⟨cosn(ϕ1−ϕ2)⟩⟩⋅8delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic-ϕ2\displaystyle 8\cdot\left<\left<\cos<br>n(\phi_{1}-\phi_{2})\right>\right>                                                                                                                                                                                                          |
| ×\displaystyle\times                                                | [⟨⟨cosnϕ1⟩⟩2+⟨⟨sinnϕ1⟩⟩2]delimited-[]superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ12superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic<br>ϕ12\displaystyle\left[\left<\left<\cos                                                                                                                                                                      |
|                                                                     |                                                                                                                                                                                                                                                                                                                                                                        |

The terms starting from the second line in Eq. (71) counter balance the bias coming from non-uniform acceptance so that  $cn\{4\}$  subscript $cn\{4\}$  is unbiased. These terms can be expressed in terms of QOQ-vectors:

<span id="page-22-0"></span> $(\langle \cos n(\phi 1 + \phi 2) \rangle)$  delimited- $\langle \rangle$ 

```
delimited-()nsubscriptitalic-
                                                                                                                   \Sigma i=1N(\Re e[QnQn-Q2n])i\Sigma i=1NMi(Mi-1),s
n(\phi \{1\})!+(\phi \{2\})
                                                                                                                   \{ \sum_{i=1}^{N} M_{i}(M_{i})!-!1 \},
\right>\right>\!\!
(\langle \sin (\phi 1 + \phi 2) \rangle)  delimited-\langle \rangle
delimited-()nsubscriptitalic-
                                                                                                                   \sum_{i=1}^{N} (\Im_{m}[QnQn-Q2n]) i \sum_{i=1}^{N} (Mi-1),
                                                                           =\displaystyle= []subscriptQnsubscriptQnsubscriptQ2nisu
φ1subscriptitalic-
                                                                                                                  \label{eq:linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_linear_line
$\displaystyle\left<\left<\sin</pre>
n(\phi_{1})!+\psi_{2})
                                                                                                                   {\sum_{i=1}^{N}M \{i\}(M \{i\}\setminus i-1)\},}
\right>\right>\!\!
\langle\langle \cos n(\phi 1 - \phi 2 - \phi 3)\rangle\rangle
delimited-()delimited-()
nsubscriptitalic-
                                                                                                                   \{\Sigma i=1N(\Re e[QnQn*Qn*-QnQ2n*]\}
φ1subscriptitalic-
                                                                           =\displaystyle\!\displaystyle\!\!\bigg{\{}\sum {i=1}^{\frac{n}{2}}}
φ2subscriptitalic-
                                                                                                                  \left( \mathbf{Re} \right) 
φ3\displaystyle\left<\cos
                                                                                                                  Q \{n\}^{*}-Q \{n\}Q \{2n\}^{*}\right]
n(\phi {1}\!-\!\phi {2}\!-\!
\phi_{3})\right= \sinh_{3}\right)
                                                                                                                  -2(M-1)\Re e[Qn*])i\}/\Sigma i=1NMi(Mi-1)(Mi-1)
                                                                                                                  \displaystyle\left.-2(M\!-\!1)\mathfrak{Re
                                                                                                                  \left[Q_{n}^{*}\right]\right]
                                                                                                                  \sum_{i=1}^{N}M \{i\}(M \{i\})!-(M \{i\})!
                                                                                                                  2)\,,
\langle (\sin (\phi 1 - \phi 2 - \phi 3)) \rangle delimited-
()delimited-()nsubscriptitalic-
                                                                                                                  \{\sum_{i=1}^{N} (\Im_{m}[QnQn*Qn*-QnQ2n*]\}
φ1subscriptitalic-
                                                                           =\displaystyle\!\displaystyle\!\!\bigg{\{}\sum {i=1}^{\frac{N}{2}}}
φ2subscriptitalic-
                                                                                                                  \left( \mathcal L_n \right) = \left( \mathcal L_n \right) 
φ3\displaystyle\left<\left<\sin
                                                                                                                  Q \{n\}^{*}-Q \{n\}Q \{2n\}^{*}\right]
n(\phi {1}\!-\!\phi {2}\!-\!
\phi {3}\rangle right > right >
                                                                                                                  -2(M-1)\Im m[Qn*])i\}/\Sigma i=1NMi(Mi-1)(Mi-1)
                                                                                                                  \displaystyle\eft.-2(M\!-\!1)\mathfrak{Im}
```

2)\,.

<span id="page-22-3"></span>\left[Q\_{n}^{\*}\right]\right)\_{i}\bigg{\} \sum {i=1}^{N}M {i}(M {i}\!-\!1)(M {

```
When particle weights are used the average 2-particle correlation (\langle 2 \rangle) delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  determined from Eqs. (62), the average 4-particle correlation (\langle 4 \rangle \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delimited-\langle 2 \rangle = 2  delim
```

```
\langle (\cos n(\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle ((\phi 1 + \phi 2)) \rangle delimited - \langle
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      \Sigma i=1N(\Re e[Qn,1Qn,1-Qn])
        nsubscriptitalic-∮1subscriptitalic-
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       []subscriptOn1subscrip
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  =\displaystyle=
          φ2\displaystyle\left<\left<\cos n(\phi {1}\!
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^{N}\left(\mathfrak{F
          +\!\phi {2})\right>\right>
          \langle (\sin (\phi 1 + \phi 2)) \rangle delimited-\langle () delimited-\langle () \rangle
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      \sum i=1N(\Im m[Qn,1Qn,1-i]
          nsubscriptitalic-ϕ1subscriptitalic-
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      []subscriptQn1subscrip
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  =\displaystyle=
          Φ2\displaystyle\left<\left<\sin n(\phi {1}\!</pre>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ^{N}\left(\mathfrak{I
          +\!\phi {2})\right>\right>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ١,,
        \mathcal{M}11subscript\mathcal{M}11\displaystyle\mathcal{M} =\displaystyle\equiv \sum_{i,j=1}^{i} \mathcal{M}'wiwj=S2,1-S
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        {{}^{\prime}}{\sum
        {11}
and the Eqs. (74) and (75) generalize into
          (\langle \cos n(\phi 1 - \phi 2 - \phi 3) \rangle) delimited-(\langle n \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \sin \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi \cos \phi 1 - \phi 
          \phi3\displaystyle\left<\cos n(\phi {1}\!-\!\phi {2}\!-\!\phi {3})\right>\right>
          \langle \sin(\phi_1 - \phi_2 - \phi_3) \rangle \rangle delimited-\langle nsubscriptitalic-\phi_1subscriptitalic-\phi_2subscriptitalic-<math>\phi_1subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-<math>\phi_1subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscriptitalic-\phi_2subscri
          \phi3\displaystyle\eft<\sin n(\phi {1}\!-\!\phi {2}\!-\!\phi {3})\right>\right>
          \mathcal{M}111 \equiv \sum_{i,j,k=1}^{\infty} M'wiwjwksubscript\mathcal{M}111superscriptsubscriptsuperscript'ijk1Msubscript
        {111}\\leq {111}\
The generalized 2ndsuperscript2nd2^{\mathrm{nd}} order differential
cumulant reads
        dn\{2\} = \langle \langle 2' \rangle \rangle - subscript dn2 limit-from delimited - \langle \rangle delimited - \langle \rangle
          superscript2\langle displaystyle d {n} = \left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{2}{\left| \frac{1}{\left| \frac{2}{\left| \frac{1}{\left| \frac{1}{\left| \frac{1}{\left| \frac{1}{\left| \frac{1}{\left| \frac{1}{\left| \frac{1}\right| }\right|}}\right|}}}{\left| \frac{1}}\right|}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
        \right>\right>-
          (\langle \cos n\psi 1 \rangle) (\langle \cos n\varphi 2 \rangle) - (\langle \sin n\psi 1 \rangle) (\langle \sin n\varphi 2 \rangle) \cdot delimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial elimited - (\langle \partial eli
          nsubscript\psi1delimited-\langle \rangledelimited-\langle \rangle nsubscriptitalic-\phi2delimited-\langle \rangle
          delimited-\langle \rangle n subscript \psi 1 delimited-\langle \rangle d elimited-\langle \rangle n subscript italic-
          Φ2\displaystyle\!\!\left<\left<\cos</pre>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              (78)
          n\psi {1}\right>\right>\left<\cos n\phi {2}\right>\right>\!-\!
          \langle\langle\sin n\psi {1}\rangle\rangle\left<\left<\sin
          n\phi {2}\right>\right>\..
Expressions for (\langle \cos n\phi 1 \rangle) delimited-(\langle act \rangle) delimited-(\langle act \rangle) nsubscriptitalic-
\phi1\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}{\left(\frac{1}\right)}\right)}}}\right)}}}{1}}}}}}{1\right)}}} 1\right)} 1} 1 1 1 1 1 1 1 1}}  1 1 1 1}}  1 1 1 1}}  1 1 1 1 1}}  1 1 1 1 1 1}}}  1 1 1 1 1 1}}}  1 1 1 1 1 1}}}  1 1 1 1 1 1}}}  1 1 1 1 1 1 1}}}  1 1 1 1 1 1 1 1}}}  1 1 1 1 1 1 1 1 1 1}}}  1 1 1 1 1 1 1 1 1 1 1 1 1}}}  1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
```

delimited- $\langle n$  subscriptitalic- $\phi 1$  left<\sin n hi  $\{1\}$  right>\right> were

already given in Eqs. [\(67\)](#page-20-2) and [\(68](#page-20-3)), respectively (when particle weights are being used in Eqs. ([69](#page-20-4)) and ([70\)](#page-20-5), respectively). Similarly:

```
⟨⟨cosnψ1⟩⟩delimited-⟨⟩delimited-⟨⟩
subscript1\displaystyle\left<\left<\cos
n\psi_{1}\right>\right>
                                      =\displaystyle=
                                                      ∑i=1N(ℜ[pn])i∑i=1N(mp)i,superscriptsubscript1subscriptℜdelimited-
                                                      []subscriptsuperscriptsubscript1subscriptsubscript\displaystyle\frac{\sum_{i=1}
                                                      ^{N}\left(\mathfrak{Re}\left[p_{n}\right]\right)_{i}}{\sum_{i=1}^{N}(m_{p})_{i}}\,,
⟨⟨sinnψ1⟩⟩delimited-⟨⟩delimited-⟨⟩
subscript1\displaystyle\left<\left<\sin
n\psi_{1}\right>\right>
                                      =\displaystyle=
                                                      ∑i=1N(ℑ[pn])i∑i=1N(mp)i,superscriptsubscript1subscriptℑdelimited-
                                                      []subscriptsuperscriptsubscript1subscriptsubscript\displaystyle\frac{\sum_{i=1}
                                                      ^{N}\left(\mathfrak{Im}\left[p_{n}\right]\right)_{i}}{\sum_{i=1}^{N}(m_{p})_{i}}\,,
```

where pnsubscriptp\_{n} and mpsubscriptm\_{p} were defined in Section [IV.](#page-8-0) The Eqs. ([79\)](#page-24-0) and [\(80\)](#page-24-1) remain unchanged when particle weights are being used.

The generalized 4thsuperscript4th4^{\mathrm{th}} order differential

+\displaystyle+

```
cumulant reads:
dn{4}
subscript4\displaystyle
d_{n}\{4\}
                          =\displaystyle=
                                                ⟨⟨4′⟩⟩−2⋅⟨⟨2′⟩⟩⟨⟨2⟩⟩delimited-⟨⟩delimited-⟨⟩
                                                superscript4′⋅2delimited-⟨⟩delimited-⟨⟩
                                                superscript2′delimited-⟨⟩delimited-⟨⟩
                                                2\displaystyle\langle\langle 4^{\prime}
                                                \rangle\rangle-2\cdot\left<\left<2^{\prime}
                                                \right>\right>\left<\langle 2\rangle\right>
                          −\displaystyle-
                                                ⟨⟨cosnψ1⟩⟩⟨⟨cosn(ϕ1−ϕ2−ϕ3)⟩⟩delimited-⟨⟩
                                                delimited-⟨⟩subscript1delimited-⟨⟩
                                                delimited-⟨⟩subscriptitalic-
                                                ϕ1subscriptitalic-ϕ2subscriptitalic-
                                                ϕ3\displaystyle\left<\left<\cos
                                                n\psi_{1}\right>\right>\left<\left<\cos
                                                n(\phi_{1}\!-\!\phi_{2}\!-\!\phi_{3})
                                                \right>\right>
                          +\displaystyle+
                                                ⟨⟨sinnψ1⟩⟩⟨⟨sinn(ϕ1−ϕ2−ϕ3)⟩⟩delimited-⟨⟩
                                                delimited-⟨⟩subscript1delimited-⟨⟩
                                                delimited-⟨⟩subscriptitalic-
                                                ϕ1subscriptitalic-ϕ2subscriptitalic-
                                                ϕ3\displaystyle\left<\left<\sin
                                                n\psi_{1}\right>\right>\left<\left<\sin
                                                n(\phi_{1}\!-\!\phi_{2}\!-\!\phi_{3})
                                                \right>\right>
                          −\displaystyle-
                                                ⟨⟨cosnϕ1⟩⟩⟨⟨cosn(ψ1−ϕ2−ϕ3)⟩⟩delimited-⟨⟩
                                                delimited-⟨⟩subscriptitalic-ϕ1delimited-⟨⟩
                                                delimited-⟨⟩subscript1subscriptitalic-
                                                ϕ2subscriptitalic-
                                                ϕ3\displaystyle\left<\left<\cos
```

n\phi\_{1}\right>\right>\left<\left<\cos n(\psi\_{1}\!-\!\phi\_{2}\!-\!\phi\_{3})

⟨⟨sinnϕ1⟩⟩⟨⟨sinn(ψ1−ϕ2−ϕ3)⟩⟩delimited-⟨⟩ delimited-⟨⟩subscriptitalic-ϕ1delimited-⟨⟩ delimited-⟨⟩subscript1subscriptitalic-

\right>\right>

|                      | ϕ2subscriptitalic<br>ϕ3\displaystyle\left<\left<\sin<br>n\phi_{1}\right>\right>\left<\left<\sin<br>n(\psi_{1}\!-\!\phi_{2}\!-\!\phi_{3})<br>\right>\right>                                                                                                                                                     |
|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| −\displaystyle       | 2⋅⟨⟨cosnϕ1⟩⟩⟨⟨cosn(ψ1+ϕ2−ϕ3)⟩⟩<br>⋅2delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1subscriptitalic<br>ϕ2subscriptitalic-ϕ3\displaystyle<br>2\cdot\left<\left<\cos<br>n\phi_{1}\right>\right>\left<\left<\cos<br>n(\psi_{1}\!+\!\phi_{2}\!-\!\phi_{3})<br>\right>\right> |
| −\displaystyle       | 2⋅⟨⟨sinnϕ1⟩⟩⟨⟨sinn(ψ1+ϕ2−ϕ3)⟩⟩⋅2delimited-<br>⟨⟩delimited-⟨⟩𝑛subscriptitalic-ϕ1delimited-⟨⟩<br>delimited-⟨⟩𝑛subscript𝜓1subscriptitalic<br>ϕ2subscriptitalic-ϕ3\displaystyle<br>2\cdot\left<\left<\sin<br>n\phi_{1}\right>\right>\left<\left<\sin<br>n(\psi_{1}\!+\!\phi_{2}\!-\!\phi_{3})<br>\right>\right>    |
| −\displaystyle-      | ⟨⟨cosn(ψ1+ϕ2)⟩⟩⟨⟨cosn(ϕ1+ϕ2)⟩⟩delimited-⟨⟩<br>delimited-⟨⟩𝑛subscript𝜓1subscriptitalic<br>ϕ2delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic<br>ϕ2\displaystyle\left<\left<\cos n(\psi_{1}\!<br>+\!\phi_{2})\right>\right>\left<\left<\cos<br>n(\phi_{1}\!+\!\phi_{2})\right>\right>               |
| −\displaystyle-      | ⟨⟨sinn(ψ1+ϕ2)⟩⟩⟨⟨sinn(ϕ1+ϕ2)⟩⟩delimited-⟨⟩<br>delimited-⟨⟩𝑛subscript𝜓1subscriptitalic<br>ϕ2delimited-⟨⟩delimited-⟨⟩𝑛subscriptitalic<br>ϕ1subscriptitalic<br>ϕ2\displaystyle\left<\left<\sin n(\psi_{1}\!+<br>\!\phi_{2})\right>\right>\left<\left<\sin<br>n(\phi_{1}\!+\!\phi_{2})\right>\right>               |
| +\displaystyle+      | 2⋅⟨⟨cosn(ϕ1+ϕ2)⟩⟩⋅2delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1subscriptitalic<br>ϕ2\displaystyle 2\cdot\left<\left<\cos<br>n(\phi_{1}+\phi_{2})\right>\right><br>[⟨⟨cosnψ1⟩⟩⟨⟨cosnϕ1⟩⟩−⟨⟨sinnψ1⟩⟩⟨⟨sinnϕ1⟩⟩]delimited-                                                                                     |
| ×\displaystyle\times | []delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic<br>ϕ1\displaystyle\left[\left<\left<\cos<br>n\psi_{1}\right>\right>\left<\left<\cos                                              |

n\phi\_{1}\right>\right>\!-\!\left<\left<\sin

|                      | n\psi_{1}\right>\right>\left<\left<\sin<br>n\phi_{1}\right>\right>\right]                                                                                                                                                                                                                           |
|----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| +\displaystyle+      | 2⋅⟨⟨sinn(ϕ1+ϕ2)⟩⟩⋅2delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1subscriptitalic<br>ϕ2\displaystyle 2\cdot\left<\left<\sin                                                                                                                                                                         |
|                      | n(\phi_{1}\!+\!\phi_{2})\right>\right><br>[⟨⟨cosnψ1⟩⟩⟨⟨sinnϕ1⟩⟩+⟨⟨sinnψ1⟩⟩⟨⟨cosnϕ1⟩⟩]delimited-<br>[]delimited-⟨⟩delimited-⟨⟩                                                                                                                                                                       |
| ×\displaystyle\times | 𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic<br>ϕ1\displaystyle\left[\left<\left<\cos                                                                                                            |
|                      | n\psi_{1}\right>\right>\left<\left<\sin<br>n\phi_{1}\right>\right>\!+\!\left<\left<\sin<br>n\psi_{1}\right>\right>\left<\left<\cos<br>n\phi_{1}\right>\right>\right]                                                                                                                                |
| +\displaystyle+      | 4⋅⟨⟨cosn(ϕ1−ϕ2)⟩⟩⋅4delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1subscriptitalic<br>ϕ2\displaystyle 4\cdot\left<\left<\cos<br>n(\phi_{1}\!-\!\phi_{2})\right>\right>                                                                                                                               |
| ×\displaystyle\times | [⟨⟨cosnψ1⟩⟩⟨⟨cosnϕ1⟩⟩+⟨⟨sinnψ1⟩⟩⟨⟨sinnϕ1⟩⟩]delimited-<br>[]delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1delimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic                                                              |
|                      | ϕ1\displaystyle\left[\left<\left<\cos<br>n\psi_{1}\right>\right>\left<\left<\cos<br>n\phi_{1}\right>\right>\!+\!\left<\left<\sin<br>n\psi_{1}\right>\right>\left<\left<\sin<br>n\phi_{1}\right>\right>\right]                                                                                       |
| +\displaystyle+      | 2⋅⟨⟨cosn(ψ1+ϕ2)⟩⟩⋅2delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1subscriptitalic-ϕ2\displaystyle<br>2\cdot\left<\left<\cos n(\psi_{1}\!+\!<br>\phi_{2})\right>\right>                                                                                                                                     |
| ×\displaystyle\times | [⟨⟨cosnϕ1⟩⟩2−⟨⟨sinnϕ1⟩⟩2]delimited-<br>[]superscriptdelimited-⟨⟩delimited-⟨⟩<br>𝑛subscriptitalic-ϕ12superscriptdelimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic<br>ϕ12\displaystyle\left[\left<\left<\cos<br>n\phi_{1}\right>\right>^{2}\!-\!<br>\left<\left<\sin<br>n\phi_{1}\right>\right>^{2}\right] |
| +\displaystyle+      | 4⋅⟨⟨sinn(ψ1+ϕ2)⟩⟩⟨⟨cosnϕ1⟩⟩⟨⟨sinnϕ1⟩⟩<br>⋅4delimited-⟨⟩delimited-⟨⟩<br>𝑛subscript𝜓1subscriptitalic-ϕ2delimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ1delimited-⟨⟩<br>delimited-⟨⟩𝑛subscriptitalic-ϕ1\displaystyle                                                                                    |

4\cdot\left<\left<\sin n(\psi\_{1}\!+\!

```
\phi_{2})\right>\right>\left<\left<\cos
                     n\phi_{1}\right>\right>\left<\left<\sin
                     n\phi_{1}\right>\right>
+\displaystyle+
                     4⋅⟨⟨cosn(ψ1−ϕ2)⟩⟩[⟨⟨cosnϕ1⟩⟩2+⟨⟨sinnϕ1⟩⟩2]⋅4delimited-
                     ⟨⟩delimited-⟨⟩subscript1subscriptitalic-
                     ϕ2delimited-[]superscriptdelimited-⟨⟩
                     delimited-⟨⟩subscriptitalic-
                     ϕ12superscriptdelimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-ϕ12\displaystyle
                     4\cdot\left<\left<\cos n(\psi_{1}\!-\!
                     \phi_{2})\right>\right>\left[\left<\left<\cos
                     n\phi_{1}\right>\right>^{2}\!+\!
                     \left<\left<\sin
                     n\phi_{1}\right>\right>^{2}\right]
−\displaystyle-
                     6⋅[⟨⟨cosnϕ1⟩⟩2−⟨⟨sinnϕ1⟩⟩2]⋅6delimited-
                     []superscriptdelimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-ϕ12superscriptdelimited-⟨⟩
                     delimited-⟨⟩subscriptitalic-ϕ12\displaystyle
                     6\cdot\left[\left<\left<\cos
                     n\phi_{1}\right>\right>^{2}\!-\!
                     \left<\left<\sin
                     n\phi_{1}\right>\right>^{2}\right]
×\displaystyle\times
                     [⟨⟨cosnψ1⟩⟩⟨⟨cosnϕ1⟩⟩−⟨⟨sinnψ1⟩⟩⟨⟨sinnϕ1⟩⟩]delimited-
                     []delimited-⟨⟩delimited-⟨⟩
                     subscript1delimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩
                     subscript1delimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-
                     ϕ1\displaystyle\left[\left<\left<\cos
                     n\psi_{1}\right>\right>\left<\left<\cos
                     n\phi_{1}\right>\right>\!-\!\left<\left<\sin
                     n\psi_{1}\right>\right>\left<\left<\sin
                     n\phi_{1}\right>\right>\right]
−\displaystyle-
                     12⋅⟨⟨cosnϕ1⟩⟩⟨⟨sinnϕ1⟩⟩⋅12delimited-⟨⟩
                     delimited-⟨⟩subscriptitalic-ϕ1delimited-⟨⟩
                     delimited-⟨⟩subscriptitalic-ϕ1\displaystyle
                     12\cdot\left<\left<\cos
                     n\phi_{1}\right>\right>\left<\left<\sin
                     n\phi_{1}\right>\right>
×\displaystyle\times
                     [⟨⟨sinnψ1⟩⟩⟨⟨cosnϕ1⟩⟩+⟨⟨cosnψ1⟩⟩⟨⟨sinnϕ1⟩⟩].delimited-
                     []delimited-⟨⟩delimited-⟨⟩
                     subscript1delimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-ϕ1delimited-⟨⟩delimited-⟨⟩
                     subscript1delimited-⟨⟩delimited-⟨⟩
                     subscriptitalic-
                     ϕ1\displaystyle\left[\left<\left<\sin
                     n\psi_{1}\right>\right>\left<\left<\cos
                     n\phi_{1}\right>\right>\!+\!\left<\left<\cos
                     n\psi_{1}\right>\right>\left<\left<\sin
                     n\phi_{1}\right>\right>\right]\,.
```

The terms starting from the second line in Eq. ([C](#page-24-2)) counter balance the bias coming from non-uniform acceptance. Some of the new terms appearing in this expression can be expressed again in products of flow vectors:

```
⟨⟨cosn(ψ1+ϕ2)⟩⟩delimited-⟨⟩
delimited-⟨⟩
subscript1subscriptitalic-
ϕ2\displaystyle\left<\left<\cos
n(\psi_{1}\!+\!\phi_{2})
\right>\right>
                             =\displaystyle\!
                             \!=
                                             ∑i=1N(ℜ[pnQn−q2n])i∑i=1N(mpM−mq)i,superscriptsubscript1subscriptℜdelimited-
                                             []subscriptsubscriptsubscript2superscriptsubscript1subscriptsubscriptsubscript\displaystyle\!
                                             \!\frac{\sum_{i=1}^{N}\!\!\left(\mathfrak{Re}\left[p_{n}Q_{n}\!-\!q_{2n}\right]\right)_{i}}{\sum_{i=1}
                                             ^{N}\!\!\left(m_{p}M\!-\!m_{q}\right)_{i}}\,,
⟨⟨sinn(ψ1+ϕ2)⟩⟩delimited-⟨⟩
delimited-⟨⟩
subscript1subscriptitalic-
ϕ2\displaystyle\left<\left<\sin
n(\psi_{1}\!+\!\phi_{2})
\right>\right>
                             =\displaystyle\!
                             \!=
                                             ∑i=1N(ℑ[pnQn−q2n])i∑i=1N(mpM−mq)i,superscriptsubscript1subscriptℑdelimited-
                                             []subscriptsubscriptsubscript2superscriptsubscript1subscriptsubscriptsubscript\displaystyle\!
                                             \!\frac{\sum_{i=1}^{N}\!\!\left(\mathfrak{Im}\left[p_{n}Q_{n}\!-\!q_{2n}\right]\right)_{i}}{\sum_{i=1}
                                             ^{N}\!\!\left(m_{p}M\!-\!m_{q}\right)_{i}}\,,
⟨⟨cosn(ψ1+ϕ2−ϕ3)⟩⟩
delimited-⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\cos
n(\psi_{1}\!+\!\phi_{2}-\!
\phi_{3})\right>\right>
                             =\displaystyle=
                                             {∑i=1N(ℜ[pn(|Qn|2−M)]
                                             \displaystyle\bigg{\{}\sum_{i=1}^{N}
                                             \big{(}\mathfrak{Re}\left[p_{n}\!
                                             \left(\left|Q_{n}\right|^{2}\!-\!M\right)
                                             \right]
                                             −ℜ[q2nQn∗+mqQn−2qn])i}/
                                             ∑i=1N[(mpM−2mq)(M−1)]i,\displaystyle-
                                             \mathfrak{Re}\left[q_{2n}Q_{n}^{*}\!
                                             +\!m_{q}Q_{n}\!-\!2q_{n}\right]\big{)}
                                             _{i}\bigg{\}}/\sum_{i=1}^{N}
                                             \left[(m_{p}M\!-\!2m_{q})(M\!-\!
                                             1)\right]_{i}\,,
⟨⟨sinn(ψ1+ϕ2−ϕ3)⟩⟩delimited-
⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\sin
n(\psi_{1}\!+\!\phi_{2}-\!
\phi_{3})\right>\right>
                             =\displaystyle=
                                             {∑i=1N(ℑ[pn(|Qn|2−M)]
                                             \displaystyle\bigg{\{}\sum_{i=1}^{N}
                                             \big{(}\mathfrak{Im}\left[p_{n}\!
                                             \left(\left|Q_{n}\right|^{2}\!-\!M\right)
                                             \right]
                                             −ℑ[q2nQn∗+mqQn−2qn])i}/
                                             ∑i=1N[(mpM−2mq)(M−1)]i,\displaystyle-
                                             \mathfrak{Im}\left[q_{2n}Q_{n}^{*}\!
                                             +\!m_{q}Q_{n}\!-\!2q_{n}\right]\big{)}
                                             _{i}\bigg{\}}/\sum_{i=1}^{N}
                                             \left[(m_{p}M\!-\!2m_{q})(M\!-\!
                                             1)\right]_{i}\,,
⟨⟨cosn(ψ1−ϕ2−ϕ3)⟩⟩
delimited-⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\cos
                             =\displaystyle=
                                             {∑i=1N(ℜ[pnQn∗Qn∗−pnQ2n∗]
                                             \displaystyle\bigg{\{}\sum_{i=1}^{N}
                                             \big{(}\mathfrak{Re}\left[p_{n}Q_{n}
                                             ^{*}Q_{n}^{*}\!-\!p_{n}Q_{2n}^{*}
                                             \right]
```

```
n(\psi_{1}\!-\!\phi_{2}-\!
\phi_{3})\right>\right>
                                             −ℜ[2mqQn∗−2qn∗])i}/
                                             ∑i=1N[(mpM−2mq)(M−1)]i,\displaystyle-
                                             \mathfrak{Re}\left[2m_{q}Q_{n}^{*}
                                             \!-\!2q_{n}^{*}\right]\big{)}_{i}
                                             \bigg{\}}/\sum_{i=1}^{N}\left[(m_{p}
                                             M-2m_{q})(M-1)\right]_{i}\,,
⟨⟨sinn(ψ1−ϕ2−ϕ3)⟩⟩delimited-
⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\sin
n(\psi_{1}\!-\!\phi_{2}-\!
\phi_{3})\right>\right>
                              =\displaystyle=
                                             {∑i=1N(ℑ[pnQn∗Qn∗−pnQ2n∗]
                                             \displaystyle\bigg{\{}\sum_{i=1}^{N}
                                             \big{(}\mathfrak{Im}\left[p_{n}Q_{n}
                                             ^{*}Q_{n}^{*}-p_{n}Q_{2n}^{*}
                                             \right]
                                             −ℑ[2mqQn∗−2qn∗])i}/
                                             ∑i=1N[(mpM−2mq)(M−1)]i.\displaystyle-
                                             \mathfrak{Im}\left[2m_{q}Q_{n}^{*}
                                             \!-\!2q_{n}^{*}\right]\big{)}_{i}
                                             \bigg{\}}/\sum_{i=1}^{N}\left[(m_{p}
                                             M-2m_{q})(M-1)\right]_{i}\,.
When particle weights are used Eqs. (82) generalize into:
⟨⟨cosn(ψ1+ϕ2)⟩⟩delimited-⟨⟩
delimited-⟨⟩
subscript1subscriptitalic-
ϕ2\displaystyle\left<\left<\cos
n(\psi_{1}\!+\!\phi_{2})
\right>\right>
                              =\displaystyle=
                                             ∑i=1N(ℜ[pnQn,k−q2n,k])i∑i=1N(mpS1,1−s1,1)i,superscriptsubscript1subscriptℜdelimited-
                                             []subscriptsubscriptsubscript2superscriptsubscript1subscriptsubscriptsubscript11subscript11\displaystyle\frac{\sum_{i=1}
                                             ^{N}\left(\mathfrak{Re}\left[p_{n}Q_{n,k}-q_{2n,k}\right]\right)_{i}}{\sum_{i=1}^{N}\left(m_{p}S_{1,1}-s_{1,1}\right)_{i}}\,,
⟨⟨sinn(ψ1+ϕ2)⟩⟩delimited-⟨⟩
delimited-⟨⟩
subscript1subscriptitalic-
ϕ2\displaystyle\left<\left<\sin
n(\psi_{1}\!+\!\phi_{2})
\right>\right>
                              =\displaystyle=
                                             ∑i=1N(ℑ[pnQn,k−q2n,k])i∑i=1N(mpS1,1−s1,1)i,superscriptsubscript1subscriptℑdelimited-
                                             []subscriptsubscriptsubscript2superscriptsubscript1subscriptsubscriptsubscript11subscript11\displaystyle\frac{\sum_{i=1}
                                             ^{N}\left(\mathfrak{Im}\left[p_{n}Q_{n,k}-q_{2n,k}\right]\right)_{i}}{\sum_{i=1}^{N}\left(m_{p}S_{1,1}-s_{1,1}\right)_{i}}\,,
Eqs. (LABEL:3pAnizDFa) generalize into:
⟨⟨cosn(ψ1+ϕ2−ϕ3)⟩⟩
delimited-⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\cos
n(\psi_{1}\!+\!\phi_{2}-\!
\phi_{3})\right>\right>
                              =\displaystyle\!
                              \!\!=
                                             {∑i=1N(ℜ[pn(|Qn,1|2−S1,2)]\displaystyle\!\!\!\bigg{\{}\sum_{i=1}^{N}\big{(}\mathfrak{Re}\left[p_{n}\left(\left|Q_{n,
                                             1}\right|^{2}\!-\!S_{1,2}\right)\right]
                                             −ℜ[q2n,1Qn,1∗+s1,1Qn,1−2qn,2])i}/\displaystyle-\mathfrak{Re}\left[q_{2n,1}Q_{n,1}^{*}+s_{1,1}Q_{n,1}-2q_{n,2}\right]
                                             \big{)}_{i}\bigg{\}}/
```

{∑i=1N(mp(S2,1−S1,2)−2⋅(s1,1S1,1−s1,2))i},superscriptsubscript1subscriptsubscriptsubscript21subscript12⋅2subscript11subscript11subscript12\displaystyle\bigg{\

{}\sum\_{i=1}^{N}\left(m\_{p}(S\_{2,1}-S\_{1,2})-2\cdot(s\_{1,1}S\_{1,1}-s\_{1,2})\right)\_{i}\bigg{\}}\,,

```
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\sin
n(\psi_{1}\!+\!\phi_{2}-\!
\phi_{3})\right>\right>
                              =\displaystyle\!
                              \!\!=
                                             {∑i=1N(ℑ[pn(|Qn,1|2−S1,2)]\displaystyle\!\!\!\bigg{\{}\sum_{i=1}^{N}\big{(}\mathfrak{Im}\left[p_{n}\left(\left|Q_{n,
                                             1}\right|^{2}\!-\!S_{1,2}\right)\right]
                                             −ℑ[q2n,1Qn,1∗+s1,1Qn,1−2qn,2])i}/\displaystyle-\mathfrak{Im}\left[q_{2n,1}Q_{n,1}^{*}\!+\!s_{1,1}Q_{n,1}\!-\!2q_{n,
                                             2}\right]\big{)}_{i}\bigg{\}}/
                                             {∑i=1N(mp(S2,1−S1,2)−2⋅(s1,1S1,1−s1,2))i},superscriptsubscript1subscriptsubscriptsubscript21subscript12⋅2subscript11subscript11subscript12\displaystyle\bigg{\
                                             {}\sum_{i=1}^{N}\left(m_{p}(S_{2,1}-S_{1,2})-2\cdot(s_{1,1}S_{1,1}-s_{1,2})\right)_{i}\bigg{\}}\,,
and finally, Eqs. (LABEL:3pAnizDFb) generalize into:
⟨⟨cosn(ψ1−ϕ2−ϕ3)⟩⟩
delimited-⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\cos
n(\psi_{1}\!-\!\phi_{2}-\!
\phi_{3})\right>\right>
                              =\displaystyle\!
                              \!\!=
                                             {∑i=1N(ℜ[pn(Qn,1∗Qn,1∗−Q2n,2∗)]\displaystyle\!\!\!\bigg{\{}\sum_{i=1}^{N}\big{(}\mathfrak{Re}\left[p_{n}\left(Q_{n,1}
                                             ^{*}Q_{n,1}^{*}\!-\!Q_{2n,2}^{*}\right)\right]
                                             −2⋅ℜ[s1,1Qn,1∗−qn,2∗])i}/\displaystyle-2\cdot\mathfrak{Re}\left[s_{1,1}Q_{n,1}^{*}-q_{n,2}^{*}\right]\big{)}_{i}
                                             \bigg{\}}/
                                             {∑i=1N(mp(S2,1−S1,2)−2⋅(s1,1S1,1−s1,2))i},superscriptsubscript1subscriptsubscriptsubscript21subscript12⋅2subscript11subscript11subscript12\displaystyle\bigg{\
                                             {}\sum_{i=1}^{N}\left(m_{p}(S_{2,1}-S_{1,2})-2\cdot(s_{1,1}S_{1,1}-s_{1,2})\right)_{i}\bigg{\}}\,,
⟨⟨sinn(ψ1−ϕ2−ϕ3)⟩⟩delimited-
⟨⟩delimited-⟨⟩
subscript1subscriptitalic-
ϕ2subscriptitalic-
ϕ3\displaystyle\left<\left<\sin
n(\psi_{1}\!-\!\phi_{2}-\!
\phi_{3})\right>\right>
                              =\displaystyle\!
                              \!\!=
                                             {∑i=1N(ℑ[pn(Qn,1∗Qn,1∗−Q2n,2∗)]\displaystyle\!\!\!\bigg{\{}\sum_{i=1}^{N}\big{(}\mathfrak{Im}\left[p_{n}\left(Q_{n,1}
                                             ^{*}Q_{n,1}^{*}\!-\!Q_{2n,2}^{*}\right)\right]
                                             −2⋅ℑ[s1,1Qn,1∗−qn,2∗])i}/\displaystyle-2\cdot\mathfrak{Im}\left[s_{1,1}Q_{n,1}^{*}-q_{n,2}^{*}\right]\big{)}_{i}
                                             \bigg{\}}/
                                             {∑i=1N(mp(S2,1−S1,2)−2⋅(s1,1S1,1−s1,2))i}.superscriptsubscript1subscriptsubscriptsubscript21subscript12⋅2subscript11subscript11subscript12\displaystyle\bigg{\
                                             {}\sum_{i=1}^{N}\left(m_{p}(S_{2,1}-S_{1,2})-2\cdot(s_{1,1}S_{1,1}-s_{1,2})\right)_{i}\bigg{\}}\,.
```

### **References**

⟨⟨sinn(ψ1+ϕ2−ϕ3)⟩⟩delimited-

subscript1subscriptitalic-

⟨⟩delimited-⟨⟩

- <span id="page-30-0"></span>(1) S. A. Voloshin, A. M. Poskanzer and R. Snellings, [arXiv[:0809.2949](http://arxiv.org/abs/0809.2949)]. •
- <span id="page-30-1"></span>(2) P. Sorensen, [arXiv:[0905.0174](http://arxiv.org/abs/0905.0174)]. •
- <span id="page-30-2"></span>(3) D. A. Teaney, arXiv:0905.2433 [nucl-th]. •
- <span id="page-30-3"></span>(4) U. W. Heinz, [arXiv:[0901.4355\]](http://arxiv.org/abs/0901.4355). •
- <span id="page-30-4"></span>(5) S. Voloshin and Y. Zhang, Z. Phys. C 70 (1996) 665 [arXiv[:hep-ph/](http://arxiv.org/abs/hep-ph/9407282) [9407282\]](http://arxiv.org/abs/hep-ph/9407282). •
- <span id="page-30-5"></span>(6) A. M. Poskanzer and S. A. Voloshin Phys. Rev. C 58 (1998) 1671 [arXiv[:nucl-ex/9805001](http://arxiv.org/abs/nucl-ex/9805001)]. •
- <span id="page-30-6"></span>(7) N. Borghini, P. M. Dinh and J. Y. Ollitrault, Phys. Rev. C 63 (2001) 054906 [arXiv:[nucl-th/0007063](http://arxiv.org/abs/nucl-th/0007063)]. •

- <span id="page-31-0"></span>(8) N. Borghini, P. M. Dinh and J. Y. Ollitrault, Phys. Rev. C 64 (2001) 054901 [arXiv:[nucl-th/0105040](http://arxiv.org/abs/nucl-th/0105040)]. •
- <span id="page-31-1"></span>(9) N. Borghini, P. M. Dinh and J. Y. Ollitrault, [arXiv[:nucl-ex/0110016\]](http://arxiv.org/abs/nucl-ex/0110016). •
- <span id="page-31-2"></span>(10) C. Adler et al. [STAR Collaboration], Phys. Rev. C 66, 034904 (2002) [arXiv:nucl-ex/0206001]. •
- <span id="page-31-3"></span>(11) R. S. Bhalerao, N. Borghini and J. Y. Ollitrault Phys. Lett. B 580, 157 (2004) [arXiv:[nucl-th/0307018](http://arxiv.org/abs/nucl-th/0307018)]. •
- <span id="page-31-4"></span>(12) R. S. Bhalerao, N. Borghini and J. Y. Ollitrault Nucl. Phys. A 727 (2003) 373 [arXiv:[nucl-th/0310016\]](http://arxiv.org/abs/nucl-th/0310016). •
- <span id="page-31-5"></span>(13) R. S. Bhalerao, N. Borghini and J. Y. Ollitrault J. Phys. G 30 (2004) S1213 [arXiv[:nucl-th/0402053\]](http://arxiv.org/abs/nucl-th/0402053). •
- <span id="page-31-6"></span>(14) A. Bilandzic, N. van der Kolk, J. Y. Ollitrault and R. Snellings [arXiv: [0801.3915](http://arxiv.org/abs/0801.3915)]. •
- <span id="page-31-7"></span>(15) S. A. Voloshin, arXiv:nucl-th/0606022. •
- <span id="page-31-8"></span>(16) M. Miller and R. Snellings, arXiv:nucl-ex/0312008. •
- <span id="page-31-9"></span>(17) S. Manly et al. [PHOBOS Collaboration], Nucl. Phys. A 774, 523 (2006) [arXiv:nucl-ex/0510031]. •
- <span id="page-31-10"></span>(18) J. Adams et al. [STAR Collaboration], Phys. Rev. Lett. 92, 062301 (2004) [arXiv:nucl-ex/0310029]. •
- <span id="page-31-11"></span>(19) N. Borghini, P. M. Dinh and J. Y. Ollitrault, Phys. Rev. C 66, 014905 (2002) [arXiv:nucl-th/0204017]. •
- <span id="page-31-12"></span>(20) I. Selyuzhenkov and S. A. Voloshin Phys. Rev. C 77 (2008) 034904 [arXiv[:0707.4672](http://arxiv.org/abs/0707.4672)]. •
- <span id="page-31-13"></span>(21) A. Kisiel, T. Taluc, W. Broniowski and W. Florkowski, Comput. Phys. Commun. 174, 669 (2006) [arXiv:nucl-th/0504047]. •
- <span id="page-31-14"></span>(22) D. Gangadharan, Local Parity Violation in the Strong Interactions and Parton Collectivity in Au+Au Collisions at RHIC, Ph.D. thesis, University of California – Los Angeles, 2010. •
- <span id="page-31-15"></span>(23) A. Bilandzic, Ph.D. thesis (in preparation), Nikhef, Amsterdam, The Netherlands, 2011. •
- <span id="page-31-16"></span>(24) R. Kubo, Journal of the Physical Society of Japan, Vol. 17, No. 7, (1962). •

[◄](javascript:%20void(0)) [Feeling](file:///feeling_lucky) [lucky?](file:///feeling_lucky) [Conversion](file:///log/1010.0233) [report](file:///log/1010.0233) [Report](https://github.com/dginev/ar5iv/issues/new?template=improve-article--arxiv-id-.md&title=Improve+article+1010.0233) [an issue](https://github.com/dginev/ar5iv/issues/new?template=improve-article--arxiv-id-.md&title=Improve+article+1010.0233) [View original](https://arxiv.org/abs/1010.0233) [on arXiv](https://arxiv.org/abs/1010.0233)[►](javascript:%20void(0)) [Copyright](https://arxiv.org/help/license) [Privacy Policy](https://arxiv.org/help/policies/privacy_policy) [ar5iv homepage](file:///)

Generated on Mon Mar 18 08:39:33 2024 by L [T](http://dlmf.nist.gov/LaTeXML/) [a](http://dlmf.nist.gov/LaTeXML/) [e](http://dlmf.nist.gov/LaTeXML/)[XML](http://dlmf.nist.gov/LaTeXML/)