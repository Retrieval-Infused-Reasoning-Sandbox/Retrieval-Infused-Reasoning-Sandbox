# Physics of Strongly coupled Quark-Gluon Plasma

Edward Shuryak Department of Physics and Astronomy University at Stony Brook,NY 11794 USA shuryak@tonic.physics.sunysb.edu

May 30, 2018

#### Abstract

This review cover our current understanding of strongly coupled Quark-Gluon Plasma (sQGP), especially theoretical progress in (i) explaining the RHIC data by hydrodynamics, (ii) describing lattice data using electric-magnetic duality; (iii) understanding of gauge-string duality known as AdS/CFT and its application for "conformal" plasma. In view of interdisciplinary nature of the subject, we include brief introduction into several topics "for pedestrians". Some fundamental questions addressed are: Why is sQGP such a good liquid? What is the nature of (de)confinement and what do we know about "magnetic" objects creating it? Do they play any important role in sQGP physics? Can we understand the AdS/CFT predictions, from the gauge theory side? Can they be tested experimentally? Can AdS/CFT duality help us understand rapid equilibration/entropy production? Can we work out a complete dynamical "gravity dual" to heavy ion collisions?

## 1 Introduction

Soon after discovery of QCD, people used asymptotic freedom to argue that very hot/dense matter must be weakly coupled [1] and thus deconfined. My own entrance to this field started with the question: while vacuum fluctuations of gauge field lead to anti-screening, the famous negative coefficient leading to asymptotic freedom, what their thermal fluctuations would do? Explicit calculation [2], using the Coulomb gauge, have produced positive sign of the Debye mass, opposite to that of virtual gluons and the same as in QED! Thus I called this phase of matter "plasma", putting it even in the paper title<sup>1</sup> . One more important finding of that calculation was that static magnetic screening is absent, also like in QED: we will see that this conclusion would be seriously modified non-perturbatively.

The next 25 years theory of QGP was based on pQCD. The program to do so, with a number of "signals" was proposed in my other paper [3] : those were based on high energy hadronic/nuclear collisions and included several perturbative process, from gluonic production of new quark flavors to charmonium dissociation by gluonic "photoeffect". A lot of efforts have been made to derive perturbative series for finite-T thermodynamics, and eventually all calculable terms have been calculated, see e.g. [4]. Convergence was bad, but we thought that some clever re-summation can still make it work.

<sup>1</sup>A small anecdote is related to that: in those days plasma research in Russia was semi-classified and thus the paper returned to me with a note saying that it lacks proper permissions. I found a quick fix to this problem: a letter from renown plasma physicist saying this plasma has nothing to do with "real plasma physics". And perhaps it was true: I got an invitation to speak about it at some plasma physics meeting only 30 years later.

But whether QGP can or cannot be created experimentally was not at all clear. In fact all the way to the year 2000, when RHIC started, most theorists argued that nothing else but a "firework of mini-jets" can possibly be seen at RHIC.

And yet, in my talk at QM99 I predicted based on hydro calculations, that elliptic flow at RHIC would be twice larger than at SPS. It did not take long after the start of RHIC operation to see that this is indeed what happens: in fact a rather perfect case for hydrodynamical explosion was made both from radial and elliptic flows. After lots of debates, this period culminated with the "discovery" workshop of 2004 and subsequent "white papers" from 4 experimental collaborations which documented it.

Theory of QGP is still profoundly affected by this "paradigm shift" to the so called strong-coupling regime. We are still in so-to-say non-equilibrium transition, as huge amount of physics issues required to be learned. Some came from other fields, including physics of strongly coupled QED plasmas and trapped ultracold gases with large scattering length. String theory provided a remarkable tool – the AdS/CFT correspondence – which related heavy ions to the the fascinating physics of strong gravity and black holes. Another important trend is that transport properties of QGP and non-equilibrium dynamics came to the forefront: and for those the Euclidean approaches (lattice, instantons) we used before is much less suited than for thermodynamics. All of it made the last 5 years the time of unprecedented challenges.

Because the issues we discuss incorporate several fields of physics, some introductory parts of this review are marked "for pedestrians". Indeed, heavy ion physics did not have much in common with string theory and black holes, or dilute quantum gases, so some basic definitions and main physics statements (made at an "intuitive" level) may be helpful to some readers. We start with two such introductory subsections, about classical strongly coupled plasmas and quantum ultracold gases, which we will not discuss in this review in depth.

#### 1.1 Strongly coupled plasmas for pedestrians

By definition, plasmas are states of matter in which particles are "charged" and thus interact via long range (massless) gauge<sup>2</sup> fields. This separate it from "neutral" gases, liquids or solids in which the interparticle interaction is short range. Sometimes plasmas were called "the 4-th state of matter", but this does not comply with standard terminology: in fact plasmas can themselves be gases, liquids or solids.

Classical plasmas are of course those which does not involve quantum mechanics or ¯h. Let me start with counting the parameters of the problem. There are 4 variables <sup>3</sup> – the particle mass and density, the temperature and the Coulomb charge. Three of them can be used as units of mass, length and time: thus only one combination remains. The standard choice is the so called plasma parameter, which can be loosely defined as the ratio of interaction energy to kinetic energy, and is more technically defined as

$$\Gamma = (Ze)^2/(a_{WS}T) \tag{1}$$

where Ze, aW S, T are respectively the ion charge, the Wigner-Seitz radius aW T = (3/4πn) <sup>1</sup>/<sup>3</sup> and the temperature: this form is convenient to use because it only involves the input parameters, such as the temperature and density, while average potential energy is not so easily available. The meaning of it is the same, and the values of all observables - like transport coefficients we will discuss below – are usually expressed as a function of Γ.

<sup>2</sup>Why only gauge and not scalar fields? Indeed, supersymmetric models have massless scalars which in many cases create the so called BPS situation, in which gauge repulsion is canceled by scalar attraction: and we will call them plasmas as well. However this is as far as it goes: a generic massless scalar, attractive in all channels and not restricted by supersymmetry, is just a recipe for instability and should not be considered at all.

<sup>3</sup>Recall that the problem is not only classical but it is also nonrelativistic: thus no ¯h or c.

Depending on magnitude of this parameter Γ classical plasmas have the following regimes:

- i. a weakly coupled or gas regime, for Γ < 1;
- ii. a liquid regime for Γ ≈ 1 − 10;
- iii. a glassy liquid regime for Γ ≈ 10 − 100;
- iv. a solid regime for Γ > 300.

Existence of permanent correlation between the particles is seen in the simplest way via densitydensity correlation functions

$$G(r,t) = \frac{1}{N} \left\langle \sum_{i=1}^{N} \sum_{j=1}^{N} \delta(\vec{x} + \vec{x}_i(0) - \vec{x}_j(t)) \right\rangle,$$
 (2)

with N is the number of particles, ~xi(t) is the position of the i-th-particle at time t. G(r, t) characterizes the likelihood to find 2 particles a distance r away from each other at time t. Here are some examples, from our own (non-Abelian) MD simulations [5], which show that liquid regime demonstrate nearestneighbor peaks, and crystals have peaks corresponding to longer range order. They also show "healing" of correlations with time in gases, but much less so in liquids and solids.

![](_page_2_Figure_8.jpeg)

Figure 1: (Color online) G<sup>d</sup> correlation function for Γ = 0.83, 31.3, 131, respectively. Red circles correspond to t <sup>∗</sup> = 0, and blue squares correspond to t <sup>∗</sup> = 6.

The case of small Γ is widely discussed in statistical mechanics courses: let me just remind the reader that it is in this case when one can use Boltzmann eqn, cascades and other simple tools appropriate for a gas. Unlike gases and solids, the interplay of local order and randomness at large distances makes liquids difficult to treat theoretically<sup>4</sup> . Thus, in spite of their crucial importance for a lot of chemistry in general and our life in particular, most physics and statistical mechanics courses tend to either omit them completely or tell as little as possible about them. It is possibly worth reminding heavy ion practitioners, that for liquids neither Boltzmann equation nor cascades can be used because particle are strongly correlated with several neighbors at all times. The very idea of "scattering" and cross section involves particles coming from and going to infinity: it is appropriate for dilute gases but not condensed matter where interparticle distances do not exceed the range of the forces at any time.

<sup>4</sup> I heard an opinion, ascribed to a lecture of V.Weisskopf, that if theorists would invent the Universe from scratch, without any experiment, they would never think about liquids.

Strongly coupled classical electromagnetic plasmas can be studied experimentally: they are not at all exotic objects. For example, table solt N aCl can be considered a crystalline plasma made of permanently charged ions N a<sup>+</sup> and Cl<sup>−</sup>. At T ∼ 10<sup>3</sup>K (still too small to ionize non-valence electrons) one gets a molten solt, which is liquid plasma with Γ ∼ 60. A more famous object of recent experimentation is a charged dust: in space (e.g. at International Space Station) it has been put into a nice crystal and studied in depth. For example, one can get a particle piercing it and creating Mach cones, several if there are excitations other than the sound. One can find more introductory information and references on the subject in Mrowczynski and Thoma review [6].

We will not discuss any theory of it, but just note that starting from about 1980's availability of computational resources get sufficient to use "Molecular Dynamics" (MD). This means that one can write equations of motion (EOM) for the interparticle forces and directly solve them for say 10<sup>3</sup> particles. It is this simplest but powerful theoretical tool we will use to access properties of strongly coupled QGP by classical simulations.

#### 1.2 Strongly coupled ultracold gases

Back in 1999 G.Bertsch formulated a "many-body challenge problem," asking: what are the ground state properties of a two-species fermion system in the limit that the scattering length (as) of its interaction approaches infinity? (This limit is usually referred to as the "unitary limit" because the scattering cross section reaches its unitarity limit per s-wave.) Such problem was originally set up as a parameter-free model for a fictitious dilute neutron matter: recall that nn scattering length is indeed huge because of near-zero-energy isoscalar virtual state.

The answer was provided experimentally by atomic experimentalists, who found a way to modify the interaction strength in ultracold trapped systems by the magnetic field, which can shift level positions till they cross and form the so called "Feshbach resonances". As a result, the interaction measure – the scattering length in units of interparticle spacing a ∗ n <sup>1</sup>/<sup>3</sup> – can be changed in a wide interval, practically from −∞ (very strong attraction) to +∞ (very strong repulsion). Systems of ultracold atoms became a very hot topic a decade earlier, when laser cooling techniques were developed so that temperatures got low enough (so that atomic thermal de Brogle wavelength get comparable to interparticle distances) to observe Bose-Einstein condensation (BEC) for bosonic atoms. Last years was the time of strongly coupled quantum gases made of fermions, possessing superfluidity and huge pairing gaps. Never before one had manybody quantum systems with widely tunable interparticle interaction amenable to experimentation, and clearly it created a kind of revolution in quantum manybody physics.

For some technical reasons, BEC in strongly systems (of interest to us in respect to monopole condensation/confinement) is not yet studied, while strongly coupled fermions have been investigated quite extensively. Let me briefly review the questions which were of the main interest of the atomic community. One of them is whether two known weakly coupled phases – BCS superconductor for small and negative a and BEC of bound atom pairs at small positive a – join smoothly or there exist a discontinuity at the Feshbach resonance. The answer seems to be the former, namely two phases do join smoothly. Another issue is whether low-T strongly coupled fermions is in a gaped superfluid state: it has been answered positively, and phenomena as complex as Abrikosov's lattice of vortexes has been observed.

Clearly, there are many fascinating phenomena in this field, but let us focus on just two issues most relevant for this review and sQGP:

- (i) whether transition from weakly to strongly coupling regime is reflected in an unusually small viscosity, seen in onset of hydrodynamical behavior in unexpectedly small systems;
- (ii) possible universal limits in the infinite interaction limit a ∗ n <sup>1</sup>/<sup>3</sup> → ∞ for pairing, in connection to color superconductivity of quark matter.

Rather early it has been observed that the answer to the former question is clearly affirmative. When

![](_page_4_Figure_0.jpeg)

Figure 2: (a) False color absorption images of a strongly interacting degenerate Fermi gas of ultracold  $^6\text{Li}$  atoms as a function of time after release from a laser trap. From O'Hara et~al.[7] (b) "Quantum viscosity" in strongly-interacting Fermi gas  $\alpha = \eta/\hbar\,n$  (trap-averaged). (c) Same data for the shear viscosity as  $\eta/\hbar s$  in units of the entropy density s as a function of energy E. The lower green dotted line shows the string theory prediction  $1/(4\pi)$ . The light blue bar shows the estimate for a quark-gluon plasma (QGP) while the blue solid bar shows the estimate for  $^4\text{He}$ , near the  $\lambda$ - point.

the trap is switched off, the atoms in a weakly coupled gas simply fly away with their thermal/quantum velocities, displaying *isotropic* angular distribution of velocities *irrespective* of the trap shape. However in strongly coupled regime, with the particle mean free path smaller than the system size, hydrodynamical flow develops. Deformed traps thus develop "elliptic flows" in the direction of maximal pressure gradient, in a way analogous to what is happening in heavy ion collisions: see Fig.2(a). This is by no means trivial: the interparticle distances are about 1000 times the atomic size, and the total number of atoms is only  $\sim 10^4$  (only few times more than in central heavy ion collisions at RHIC): similar number of water molecules would *not* show any hydro!

The next questions was whether one can use hydrodynamics quantitatively, find out its accuracy and quantify the viscosity. From "released traps" the experiments switched to quadrupole vibrational modes: as the trapped system has a cigar-shape with much weaker focusing along z axes compared to axial ones, there is softer z-vibrations and higher frequency "axial" mode. I will not go into vast literature and simply say that the value of the vibrational frequencies are indeed given by hydro, reaching near-percent accuracy at the Feshbach resonance point (where  $|a| = \infty$ ).

The first study of viscosity has been made by Gelman, myself and Zahed [8]: from available data on two different vibrational modes – z-mode and axially symmetric radial mode of a cigar-shaped atomic cloud – we tried to deduce viscosity and found that the values are roughly consistent with each other. Instead of going into details of that work, let us discuss what one would expect based on "universality"

arguments. The main point is that if certain observable are finite in the  $a * n^{1/3} \to \infty$  limit, the value can only depend on few parameters – e.g. the particle mass m, the density n and Plank constant  $\hbar$  when the temperature is zero. By dimensional analysis, at T = 0, the energy density of infinitely strongly coupled gas can only be a number times the energy density of the ideal Fermi gas with the same density,

$$\epsilon(n) = \beta \frac{\hbar^2 n^{2/3}}{m} \tag{3}$$

with some universal constant  $\beta$ .

Assuming that there can be nonzero "quantum viscosity" at zero T for large amplitude oscillations, we [8] proposed to measure viscosity in units of  $\alpha = \eta/\hbar n$ , the only combination with the right dimension. Experimental data by Turlapov et al. [9] for viscosity in such units are shown in Fig.2(b). It is plotted as a function of energy per particle in Fermi energy units,  $E/E_F$ , which basically characterizes the excitation temperature:  $E/E_F \approx .5$  (corresponding to the left side of the figure) is close to the ground state T=0. From the measured points it seems that  $\alpha=\eta/\hbar n$  is actually vanishing in the ground state, about linearly in T. Another way to express viscosity – familiar from Black Hole physics—is to express it as  $\eta/\hbar s$  with s being the entropy density. Such ratio is shown in Fig.2(c): and it looks like this one reaches nonzero value as  $T, s \to 0$ . Its magnitude makes strongly coupled fermionic atoms to be the "second best liquid" known, in between the sQGP (light blue band below) and the "bronze winner" (former champion), liquid He4, shown by dark blue.

Few people (myself included) may find it fascinating, but most of atomic quantum gases community do not care and even unaware that some qualitatively new regime happens close to the Feshbach resonance: global parameters (like  $\beta$  in total energy which was subject of many theoretical and numerical works) are smooth there. Small viscosity of quantum gases does not yet have any microscopic explanations: certainly not by "unitary" cross section and kinetic theory. Linear behavior of  $\eta$  and s in T reminds that of electrons in solids: but strong coupling actually destroys the Fermi surface (as experiments measuring momentum distribution show quite clearly) and makes a very strong superconductor. The critical point in units is at  $E/E_F \approx .85$ : a look at the discussed figure reveals no changes in viscosity (nor in oscillation frequencies themselves) visible by an eye.

Apart of being in general related to the issue of sQGP as "the most perfect liquid", the strongly coupled atomic superconductor provides some valuable information on how large the pairing gaps—can possibly become in cold quark matter with color superconductivity. Assuming that near deconfinement cold quark matter is also strongly coupled, with weakly bound diquarks playing the role of Feshbach resonance, in [10] I have used universality of the ratio  $T_c/\epsilon_F$  (the pairing critical temperature to the Fermi energy) and data on strongly coupled fermionic atoms to get upper limit on the corresponding transition to the color superconductivity. Fig.3 explains the argument. "Universality" tells that the critical temperature must be simply proportional to the Fermi energy

$$T_c = \alpha_{T_c} E_F \tag{4}$$

with the universal constant  $\alpha_{T_c}$ . In fact two values of T show some change: the phase transition to superfluidity at  $\alpha_{T_c} = \frac{T_c}{E_F} = .35$  and  $\alpha_2 = \frac{T_2}{T_F} \approx 0.7 - 0.8$  which experimentalists (Kinast et al) interpret as a transition to a regime where not only there is no *condensate* of atomic pairs, but even the pairs themselves are melted. Using these two values as slopes of solid and dashed lines in Fig.3(b), one can see that all chemical freezeouts in heavy ion collisions (points) are above possible domain of pairing, even at infinite coupling. At finite coupling the gaps and  $T_c$  is even smaller.

Let me finish with one recent development, providing quite fascinating prospects if true. The idea is that infinitely strongly interacting atoms may have "gravity dual" description similar to AdS/CFT. Son [11] and also Balasubramanian and McGreevy [12] have argued that since at  $a*n^{1/3} \to \infty$  the interaction can be treated as a kind of boundary condition when two atoms meet, and this problem has

![](_page_6_Figure_0.jpeg)

![](_page_6_Figure_1.jpeg)

Figure 3: (a) Schematic phase diagram for QCD, in the plane baryon chemical potential - temperature. M (multifragmentation) point is the endpoint of nuclear gas-liquid transition. E is a similar endpoint separating the first order transition to the right from a crossover to the left of it. (Black) solid lines show phase boundaries, dashed lines are curves of marginal stability of indicated states. Two dash-dotted straight lines are related with bounds from atomic experiments we discuss in the text, they intersect with unbinding of diquark Cooper pairs (D) and most strongly coupled point (S), which is at the maximum of the transition line and is also a divider between BCS-like and BEC-like color superconductor. Other lines are zero binding for singlet gg, singlet ¯cc, octet qg, gg and finally triplet qq states. (right) Compilation of experimental data on the chemical freezeout from different experiments: squares (circles) are for fits at mid-rapidity (all particles), respectively. Two solid lines are the phase transition lines with the quark effective mass M<sup>1</sup> = 0 and 100 MeV , two dashed lines show pair unbinding lines for the same masses.

what he called "Schreodinger symmetry", a subgroup of conformal symmetry. They found examples of the metric possessing this very symmetry and suggested it may be the desired "gravity dual" . (The reader should however be reminded that there is no proof of its existence or in fact any empirical confirmation of this idea so far.)

## 2 Heavy Ion Collisions

### 2.1 Heavy ion collisions and flows for pedestrians

Let me start with brief history. At one hand, high energy physics was for all of its history been interested in "high energy asymptotic" s → ∞. In practice this mostly was reduced to global features like total and elastic cross sections, as it was thought that multibody final state produced is too complicated to get some sufficiently simple theoretical treatment. Nuclear physicists started from nuclear collisions at nonrelativistic domain: their cross section was obvious and the main objective was understanding of "excited matter". Experimental program at Relativistic Heavy Ion Collider (RHIC) at Brookhaven and Large Hadronic Collider (LHC) at CERN is so to say a brainchild of both communities.

What do we mean saying that collisions produced "excited matter"? Should one expect simplification if it is the case? The answer is that we are not interested in any excited system produced (e.g. in "elementary" pp collisions), but mostly in a macroscopically large fireball whose size (macro scale) R greatly exceed the micro scale l of correlations inside it.

$$R >> l$$
 (5)

In weakly coupled systems (gases) l is the mean free path length, or relaxation time. In strongly coupled setting such as AdS/CFT the temperature T would be the only dimensional parameter describing the microscopic physics: most dissipative phenomena have the scale 1/T as a relaxation scale.

Have we reached this regime? Perhaps good illustration that the question is nontrivial are my own two unsuccessful attempts to apply macroscopic physics for high energy processes. In 1971 I proposed "spherical explosion" in e +e <sup>−</sup> annihilation into many pions [13], only to be killed by discovery of asymptotic freedom in 1973 and jets in e +e <sup>−</sup> evens in 1976. In 1979 Zhirov and myself [14] looked at fresh results from pp collisions at then-new ISR collider at CERN<sup>5</sup> . The general idea of the paper was to look for collective transverse flows. We argued that since secondaries have different masses, the kinematic effect of a collective motion (flow velocity) can be separated from their thermal spectra. More specifically, if the "matter flow" is only longitudinal, along the beam direction, the transverse momenta spectra of different secondaries would be just thermal

$$\frac{dN}{dp_t^2} \sim exp(-\frac{M_t}{T}) \tag{6}$$

where the mass and transverse momentum combine into a "transverse mass" M<sup>2</sup> <sup>t</sup> = M<sup>2</sup> + p 2 t . The ISR data indeed showed this "M<sup>t</sup> scaling": but there was no sign of the deviations from it due to transverse flow. (Lacking the effect, we argued that it is the "vacuum pressure" which stops it.)

Heavy ion collisions are used to make the system larger. The macro scale – nuclear sizes – for Au (or Pb) used in Brookhaven (or CERN) have typical A ∼ 200 and radius R ∼ 6fm. At RHIC the temperature T changes from the initial value of about T<sup>i</sup> ∼ 400MeV ∼ 1/(.5fm), thus RT ∼ 10 >> 1 can be viewed as a large parameter. In fact experiments with Cu beam, A = 64, also showed good macroscopic behavior, as are rather peripheral collisions. The boundary between macroscopic and microscopic systems should be somewhere, as pp collisions are not hydro-like: but the exact location of it is not yet known: small systems of several nucleons are subject of large fluctuations, and it is not easy<sup>6</sup> to study them.

Once produced, the fireball is expanding hydrodynamically up to the so called freezeout conditions. People familiar with Big Bang can recognize existence of multiple freezeout, for each reaction at its own time: and in the Little Bang it is similar. The so called chemical freezeout (at which particle composition gets frozen) is at T ∼ 170 MeV at RHIC, while re-scattering continue to T<sup>f</sup> ∼ 90 MeV (for central collisions). In units of QCD critical temperature, it is T/T<sup>c</sup> variation from about 2 to 1/2, conveniently bracketing the QCD deconfinement/chiral restoration transition.

Flow velocity is decomposed into longitudinal (along the beam) and transverse components. The latter is further split into radial flow (present even for axially symmetric central collisions) and elliptic flow which exists only for non-central collisions. The reason elliptic flow to be very important was pointed out by H.Sorge: it is developed earlier than the radial one, and thus most sensitive to the QGP era than other flows.

The radial flow has Hubble-like profile, with transverse rapidity growing roughly linear till the edge of the fireball. The maximal radial flow velocity at RHIC is about .7 c. This radial flow is firmly

<sup>5</sup>L. van Hove and few others, including myself, put forward a proposal to accelerate heavy ions in ISR, to see what happens. CERN leaders basically rejected it; the experiments never went beyond the alpha-particles, and then this first hadronic collider was physically destroyed. As we know now, QGP could have been discovered and studied at ISR 20 years prior to RHIC.

<sup>6</sup>On top of that, there is experimental background, as very peripheral collisions of two beams is hard to tell from beam-residual gas interaction.

established from a combined analysis of particle spectra, HBT correlations, a deuteron coalescence and other observables: so we will not show

At non-zero impact parameter the original excited system has a deformed almond-like shape: thus its expansion in the transverse plane can be described by the (Fourier) series in azimuthal angle  $\phi$ 

$$v_n(s, p_t, M_i, y, b, A) = \langle \cos(n\phi) \rangle \tag{7}$$

where average is over all particles<sup>7</sup>. At mid-rapidity y = 0 only even harmonics are allowed, the second one characterizes the so called *elliptic flow*. Multiple arguments of the parameter  $v_2$  stand for the collision energy s, transverse momentum  $p_t$ , particle mass/type  $M_i$ , rapidity y, centrality<sup>8</sup> b and the atomic number A characterizing the colliding system.

If in high energy collisions of hadrons and/or nuclei a macroscopically large excited system is produced, its expansion and decay can be described by relativistic hydrodynamics. Its history starts with the pioneer paper by Fermi of 1951 [16] who proposed a statistical model to Lorentz-contracted initial state. Pomeranchuk [17] then pointed out that initial Fermi stage cannot be the final stage of the collisions since strong interaction in the system persists: he proposed a freezeout temperature  $T_f \sim m_{\pi}$ . L.D.Landau [15] then explain that one should use relativistic hydrodynamics in between those two stages, saving Fermi's prediction of the multiplicity by entropy conservation.

(Before we go into details, a comment: often hydrodynamics is considered as some consequence of kinetic equations, but in fact applicability conditions of both approaches are far from being coincident. In particular, for the former approach the stronger the interaction in the system is, the better. Kinetic approach, on the contrary, was never formulated but for weakly interacting systems: and as we repeatedly emphasize in this review, it is *not* so for QGP.)

The conceptual basis of the ideal hydrodynamics is very simple: it is just a set of local conservation laws for the stress tensor  $(T^{\mu\nu})$  and for the conserved currents  $(J_i^{\mu})$ ,

$$\partial_{\mu}T^{\mu\nu} = 0$$

$$\partial_{\mu}J^{\mu}_{i} = 0$$
(8)

The assumption is in local form for  $T^{\mu\nu}$  and  $J_i^{\mu}$  related to the bulk properties of the fluid and its 4-velocity  $u^{\mu}$  by the relations,

$$T^{\mu\nu} = (\epsilon + p)u^{\mu}u^{\nu} - pg^{\mu\nu}$$

$$J_i^{\mu} = n_i u^{\mu}$$
(9)

Here  $\epsilon$  is the energy density, p is the pressure,  $n_i$  is the number density of the corresponding current, and  $u^{\mu} = \gamma(1, \mathbf{v})$  is the proper velocity of the fluid. In strong interactions, the conserved currents are isospin  $(J_I^{\mu})$ , strangeness  $(J_S^{\mu})$ , and baryon number  $(J_B^{\mu})$ . For the hydrodynamic evolution, isospin symmetry is assumed and the net strangeness is set to zero; therefore only the baryon current  $J_B$  is considered below.

Let me add a simple heuristic argument why the first term in the stress tensor has  $(\epsilon + p)$  and not any other combination. The point is  $\epsilon$  and p themselves are defined up to a constant  $\pm B$  (which depending on context we call the bag constant, or cosmological term or dark energy). The combination  $(\epsilon + p)$  does not have it, and it is also proportional to entropy which is defined uniquely. How this

<sup>&</sup>lt;sup>7</sup>This is written as if the direction of impact parameter of the event is known. I would not go into how it is determined in detail but just say that it usually comes from counters sitting at rapidity  $y \approx \pm 3$  far from the region where most observations are done, at mid-rapidity  $y \approx 0$ .

 $<sup>^{8}</sup>$ In real experiments the measure of impact parameter is the so called the number of participants  $N_{p}$ , which changes from zero at most peripheral collisions to 2A at central collisions. This number is the total number of nucleons 2A minus the so called spectators, which fly forward and are directly observed by forward-backward calorimeters.

argument complies with the last term in (9)? Well it has B but without velocity, so in hydro eqns there is only pressure gradient and this B term disappears as well.

In order to close up this set of equations, one needs also the equation of state (EoS)  $p(\epsilon)$ . One should also be aware of two thermodynamical differentials

$$d\epsilon = Tds \qquad dp = sdT \tag{10}$$

and the definition of the sound velocity

$$c_s^2 = \frac{\partial p}{\partial \epsilon} = \frac{s}{T} \frac{\partial T}{\partial s} \tag{11}$$

and that  $\epsilon + p = Ts$ . Using these equations and the thermodynamical relations in the form

$$\frac{\partial_{\mu}\epsilon}{\epsilon + p} = \frac{\partial_{\mu}s}{s} \tag{12}$$

one may show that these equations imply another nontrivial conservation law, namely, the conservation of the entropy

$$\partial_{\mu}(su_{\mu}) = 0 \tag{13}$$

Therefore in the ideal hydro all the entropy is produced only in the discontinuities – shock waves – which are not actually there is application we discuss. Thus the "initial entropy" is simply passed to the solution as an initial parameter, determined in the earlier (violent) stage of the collision: (this is similar to Big Bang cosmology, in which "entropy production" stage is also very different from stages of cosmological evolution we can observe by e.g. Nucleosynthesis.)

Next order effects in micro-to-macro expansion is the domain of "viscous hydrodynamics": we will discuss their applications to data description as well as their derivation from AdS/CFT settings.

The simplest Bjorken 1+1 dim solution is a good example "for pedestrians", reminding how to write hydro in arbitrary coordinates.

$$T^{mn}_{:m} = 0, j^m_{:m} = 0, (14)$$

where the semicolon indicates a covariant derivative. For tensors of rank 1 and 2 it reads explicitly

$$j_{:p}^{i} = j_{,p}^{i} + \Gamma_{pk}^{i} j^{k}, T^{ik}_{:p} = T^{ik}_{,p} + \Gamma_{pm}^{i} T^{mk} + \Gamma_{pm}^{k} T^{im},$$

$$(15)$$

where the comma denotes a simple partial derivative and the Christoffel symbols  $\Gamma_{ij}^s$  are given by derivatives of the metric tensor  $g^{ab}(x)$ :

$$\Gamma_{ij}^s = (1/2)g^{ks}(g_{ik,j} + g_{jk,i} - g_{ij,k}). \tag{16}$$

As an example, let us do the following transformation from Cartesian to light cone coordinates:

$$x^{\mu} = (t, x, y, z) \longrightarrow \bar{x}^{m} = (\tau, x, y, \eta)$$
  
 $t = \tau \cosh \eta$   $\tau = \sqrt{t^{2} - z^{2}}$   
 $z = \tau \sinh \eta$   $\eta = (1/2) \ln \frac{t+z}{t-z}$ .

In the new coordinate system the velocity field (after inserting  $v_z = z/t$ ) is given by

$$\bar{u}^m = \bar{\gamma}(1, \bar{v}_x, \bar{v}_y, 0) \tag{17}$$

with  $\bar{v}_i \equiv v_i \cosh \eta$ , i = x, y, and  $\bar{\gamma} \equiv 1/\sqrt{1-\bar{v}_x^2-\bar{v}_y^2}$ .

![](_page_10_Figure_0.jpeg)

Figure 4: The left and right sides show the hydrodynamic solution at the SPS and RHIC. The thin lines show contours of constant transverse fluid rapidity  $(v_T = \tanh(y_T))$  with values 0.1,0.2,...,0.7. The thick lines show contours of constant energy density.  $e_{120}$  denotes the energy density where  $T = 120 \,\text{MeV}$ .  $e_H$  and  $e_Q$  denote the energy density where the matter shifts from hadronic to mixed and mixed to a QGP, respectively. The shift to hadronic cascade is made at  $e_H$ .  $\langle y_T \rangle$  denotes the mean transverse rapidity weighted with the total entropy flowing through the energy density contours. Walking along these contours, the line is broken into segments by dashed and then solid lines. 20% of the total entropy passing through the entire arc passes through each segment.

Now we turn to the metric of the new system. We have

$$ds^{2} = g_{\mu\nu}dx^{\mu}dx^{\nu} = dt^{2} - dx^{2} - dy^{2} - dz^{2}$$
$$= d\tau^{2} - dx^{2} - dy^{2} - \tau^{2}d\eta^{2}$$
(18)

and therefore

$$g_{mn} = \begin{pmatrix} 1 & 0 & 0 & 0 \\ 0 & -1 & 0 & 0 \\ 0 & 0 & -1 & 0 \\ 0 & 0 & 0 & -\tau^2 \end{pmatrix}, \tag{19}$$

The only non-vanishing Christoffel symbols are

$$\Gamma^{\eta}_{\eta\tau} = \Gamma^{\eta}_{\tau\eta} = \frac{1}{\tau}, \qquad \Gamma^{\tau}_{\eta\eta} = \tau.$$
(20)

The 1+1d equations for boost-invariant solution can be written in the following way

$$\frac{\partial}{\partial t}(s\,\cosh y) + \frac{\partial}{\partial z}(s\,\sinh y) = 0\tag{21}$$

$$\frac{\partial}{\partial t}(T\,\sinh y) + \frac{\partial}{\partial z}(T\,\cosh y) = 0\tag{22}$$

The so called Bjorken [18] solution<sup>9</sup> is obtained if the velocity is given by the velocity  $u_{\mu} = (t,0,0,z)/\tau$  where  $\tau^2 = t^2 - z^2$  is the proper time. In this 1-d-Hubble regime there is no longitudinal acceleration at all: all volume elements are expanded linearly with time and move along straight lines from the collision point. The spatial  $\tanh^{-1}(z/t)$  and the energy-momentum rapidity  $y \tanh^{-1} v$  are just equal to each other. Exactly as in the Big Bang, for each "observer" (the volume element) the picture is just the same, with the pressure from the left compensated by that from the right. The history is also the same for all volume elements, if it is expressed in its own proper time  $\tau$ .

Thus the entropy conservation becomes the following (ordinary) differential equation in proper time

 $\tau$ 

$$\frac{ds(\tau)}{d\tau} + \frac{s}{\tau} = 0 \tag{23}$$

which has the obvious solution

$$s = \frac{const}{\tau} \tag{24}$$

Let us compare three simple cases: (i) hadronic matter, (ii) quark-gluon plasma and (iii) the mixed phase (existing if there are first order transitions in the system). In the first case we adopt the equation of state suggested in [22]  $c^2 = \partial p/\partial \epsilon = const(\tau) \approx .2$ . If so, the decrease of the energy density with time is given by

$$\epsilon(\tau) = \epsilon(0) \left(\frac{\tau_0}{\tau}\right)^{1+c^2} \tag{25}$$

In the QGP case the same law holds, but with  $c^2 = 1/3$ 

In the mixed phase the pressure remains constant  $p = p_c$ , therefore

$$\epsilon(\tau) = (\epsilon(0) + p_c)(\frac{\tau_{mix}}{\tau}) - p_c \tag{26}$$

So far all dissipative phenomena were ignored. Including first dissipative terms into our equations one has

$$\frac{1}{\epsilon + p} \frac{d\epsilon}{d\tau} = \frac{1}{s} \frac{ds}{d\tau} = -\frac{1}{\tau} \left( 1 - \frac{(4/3)\eta + \zeta}{(\epsilon + p)\tau} \right) \tag{27}$$

Note that ignoring  $\zeta$  one finds in the r.h.s. exactly the combination which also appears in the sound attenuation, so the correction to ideal case is  $(1 - \Gamma_s/\tau)$ . Thus the length  $\Gamma_s$  directly tells us the magnitude of the dissipative corrections. At time  $\tau \sim \Gamma_s$  one has to abandon the hydrodynamics altogether, as the dissipative corrections cannot be ignored. Since the correction is negative, it reduces the rate of the entropy decrease with time. Another way to say that, is that the total positive sign shows that some amount of entropy is generated by the dissipative term. We will discuss "gravity dual" to this solution in the last chapter.

### 2.2 Collective flows and hydrodynamics

Any treatment of the explosion by hydro in general includes (i) the initiation; (ii) hydro evolution and (iii) freezeout. Geometrically, (i) and (iii) form two 3-hypersurfaces in 4 dimensions, together constituting a boundary of 4-volume region in which hydro eqns are solved. Only the stage (ii) deals with the Equation of State and transport properties of new form of matter, the QGP – while (i)

<sup>&</sup>lt;sup>9</sup>We call it following established tradition, although the existence of such simple solution was first noticed by Landau and it was included in his classic paper as some intermediate step. The space-time picture connected with such scaling regime was discussed in refs [20, 21] before Bjorken, and some estimates for the energy above which the transition to the scaling regime were expected to happen were also discussed in my paper [3] as well.

and (iii) have to deal with stages at which hydrodynamics is not applicable. The stage (i) is least understood theoretically: yet the uncertainties it produces are rather minor. Correct treatment of the freezeout stage (iii) is much more important for calculations of the final spectra which are compared to data: and that is where most intensive debates were. Fortunately the latest hadronic stage is not that mysterious, as some theorists think: it happens in a dilute gas-like medium made of mostly pions and their resonances. We understand their low energy scattering cross sections quite well, the corresponding cascade codes have been extensively tested using the low energy heavy ion collisions at AGS (BNL) and SPS(CERN). It just needs a bit of extra work.

Solving hydro eqns is not simple – they are nonlinear and prone to instabilities – but solutions are easily controllable by the energy, momentum and entropy (for ideal hydro) conservation: thus I presume it was done correctly by all groups. At years 2000-2004 most groups used an approximation in which one out of 3+1 (coordinates+time) – the longitudinal spatial rapidity – was taken as irrelevant, thus switching to 2+1. Example of output from such hydro calculations [19], with properly chosen EoS<sup>10</sup> is shown in Fig.4, for two collision energies, s <sup>1</sup>/<sup>2</sup> = 15, 200 GeV per nucleon, marked SPS and RHIC and shown at left and right figure. The only thing I would like to mention is that the fraction of time spent in the QGP phase (below the e<sup>Q</sup> curve) is not that large: but its existence crucially change flow pattern at RHIC. As one can see from the right plot, all lines of constant rapidity are nearly vertical and nearly equidistant: it means after QGP the flow gets a simple Hubble-like flow with v<sup>t</sup> = Hr<sup>t</sup> and time-independent constant H.

Location of the freezeout surface is also a nontrivial task. In our first application of hydrodynamics for radial transverse flow at SPS [23] we developed rather tedious "differential freezeout", for each geometry and each secondary particle was applied. We calculated individual reaction rates for different secondaries and matched them with hydro expansion rates locally. In spite of relative success of the work, there were no followers to this approach at RHIC. Selecting hydrodynamics as a Ph.D. topic for my graduate student, Derek Teaney [19], we had in mind a different procedure for freezout, namely switching at the onset of hadronic phase (e<sup>H</sup> in the figure above) to a hadronic cascade (RQMD) which automatically leads to earlier freezeout for smaller systems or particles with smaller hadronic cross sections<sup>11</sup>. The same approach was later used by Hirano et al, who generalized our rapidityindependent hydro to the full 3+1 dimensional case, successfully reproducing also the v<sup>2</sup> dependence on rapidity y [24]. They confirmed that v<sup>2</sup> linearly decreases from its maximum at mid-rapidity linearly, for the same reason as it decreases toward smaller energies: there is less matter there, shorter QGP phase and also shorter hadronic phase due to earlier freezeout. Independently developed code by Nonaka and Bass [25], with a different cascade code UrQMD, later also confirmed these calculations and well reproduce data for all dependences. These three groups have basically covered all outstanding issues related to applications of the ideal hydrodynamics to RHIC data.

One might think that, after a couple of groups checked the calculations themselves, the rest would be history if all heavy ion community would recognize/accept it. Unfortunately, it is not the case. Many hydro groups have not implemented hadronic freezeout, ending hydro at some (arbitrarily selected) isoterms T = T<sup>f</sup> . There is absolutely no reason to think it is the right choice. Even thinking about freezout as a local concept, one finds that it is determined not by local density but by local expansion rate ˙n = ∂µu<sup>µ</sup> of matter. It is well known for more than a decade [23] that the isoterms do not resemble the lines of fixed expansion rate. Furthermore, while hydro solutions simply scale with the size/time of the system<sup>12</sup>, the freezout conditions (involving the reaction rates) do not. It is thus not at all surprising, that many results based on unrealistic freezeout show qualitatively wrong dependencies.

Let me start with few plots from PHENIX "white paper" [26] in Fig.5 for protons and pions, to

<sup>10</sup>LH8 mentioned in the figure means the"latent heat" of magnitude .8GeV /fm<sup>3</sup> at the QCD transition temperature.

<sup>11</sup>Note that e.g. φ meson and the nucleon have about the same mass of 1 GeV, but cross section of re-scattering on pions ranging from few mb for the former to 200 mb for the latter, at the ∆ resonance peak dominating re-scattering.

<sup>12</sup>Hydro eqns have only first derivative over coordinates, which can thus be rescaled.

![](_page_13_Figure_0.jpeg)

Figure 5: Top two panels: On the left, proton v2(p<sup>T</sup> )/ vs. p<sup>T</sup> for minimum-bias collisions at RHIC [27, 28] are compared with hydro calculations [19, 29, 30, 31], and on the right is the same comparison for pions. Bottom two panels: (1/2π)d <sup>2</sup>N/ptdptdy. On the left, for protons, for 0–5% centrality bin collisions at RHIC [32] are compared with the same hydro calculations. On the the right, the same comparison for pions.

illustrate some important physics points explaining different level of success of different authors. The lower part of Fig.5 shows measured p<sup>t</sup> spectra of protons and pions, in comparison with different hydro calculations. The shape of those is very different mostly because heavy protons and light pions have different thermal motion at the time of freezout, in spite of the same collective radial flow. Note that nearly every group has a correct shape of the spectra (and thus correct radial flow velocity), but they don't aways have the normalization (for the nucleons) correctly: it is because of "chemical freezout" not implemented by some groups. There is no problem for hydro+cascade model [19] (the red curve).

Now we switch to elliptic flow, shown as the ratio of observed momentum anisotropy v2(pt) divided by calculated spatial elliptic anisotropy , shown in the upper part of Fig.5. Although some calculations

are not too close to the data, the overall magnitude of the effect and its p<sup>t</sup> dependence is clearly reproduced. However, that is only true for the "good" dependence v2(pt). (Actually there is another one, the dependence of v2(m) on the particle mass, which everybody get right. See one nice example of that from Hirano in Fig. 6(d).)

Unfortunately other dependences of v<sup>2</sup> are not so forgiving as v2(pt) and they show qualitative differences between models which do and do not include hadronic freezeout properly. Those include the dependences of the elliptic flow on (i) collision energy s 1/2 , (ii) centrality b or number of participants Np, (iii) and rapidity y. Let me start with the collision energy: Heinz and Kolb in their large hydro review [30] give their excitation curve for elliptic flows shown in Fig.6(a). All variants of their prediction for the elliptic flow has rapid rise on the left side of the plot (at low collision energies) with about constant saturating values at higher energies (one variant even reaches a peak followed by a decrease ). As one sees from see Fig.6(b) from the same review, this is not the trend observed in the RHIC domain: the data show a slow rise without peaks or saturation. Kolb and Heinz thus concluded that hydro is not supported by the data, at all collision energies below RHIC. This lead to a myth about a "hydro limit" which was "never reached before RHIC" which was (and still is) repeated from one conference to another. Finally Fig.6(c) from that review display rapidity dependence of v2(y) from a calculation by Hirano (before he switched to hydro+cascade): the conclusion was that hydro only works at mid-rapidity.

All those results are for fixed-T freezeout, which is not based on anything and thus is simply wrong. Here what hydro+cascades approach finds for all of these observables. The energy excitation curves of v<sup>2</sup> from [19] and [24] are shown in Fig. 7, left and right. When correct freezout is implemented, the elliptic flow is rising steadily all the way from SPS to RHIC, as the data do. The reason Heinz et al (as well as curved marked 120 Mev and 100 MeV in left and right plots) strongly overshoot the data is simply because the freezout does not occur at the same T at different collision energy. In fact, it is independently measured (from radial flow for central collisions) that while the freezeout temperature at SPS is about 140 MeV, it is as low as 90 MeV at RHIC. The trend is well understood: the larger is the system, the hotter it is at the beginning, and the cooler it gets at the end of the explosion!

Another "hydro problem" discussed in Kolb-Heinz review, the rapidity dependence of v2, also went away as soon as correct freezeout was used by Hirano et al. The results (circles in Fig.8 ) are right on top of the data (triangles), without any change of any parameters. The reason is exactly the same as for the energy dependence: in fact one can check that v2(y) show good "limiting fragmentation properties, depending basically on y − Y , the distance to beam rapidity Y . One can see the difference in centrality dependence as well, in the left side of Fig.8 .

Intermediate summary: these "problems" (and associated myths) were caused by wrong freezeout. Matter at this time is a dilute pion gas, which is not a good liquid, neither at SPS, not at RHIC and will not be at LHC, and cascade is the best<sup>13</sup> approach we have to describe it. As far as we can now test, two other evolution eras – sQGP and "mixed" or near-T<sup>c</sup> one – can be surprisingly well described by the ideal hydrodynamics.

The last statement should not be understood that the agreement with all details of the data is perfect. Theoretically, one should always ask about accuracy and applicability limits of this hydrodynamical description. As emphasized by Teaney [35] the answer should be obtained by calculation the role of viscous effects. Since we will have extensive derivation of "derivative expansion" in AdS/CFT language at the end of this paper, I will not go into details here, going directly into new developments.

In order to get more accurate account of viscosity effect on flow, a new round of studies has been performed during the last year. Relativistic Navier-Stokes has some problem with causality, thus 'higher order" methods has been used. Apart from viscosity those methods have another parameter, the

<sup>13</sup>This does not imply that we have complete confidence in many details of those cascades. To name one outstanding issue: the precise in-matter modification of hadronic resonances like ρ, ∆ etc, dominating the cross sections, is being addressed but still far from been solved.

![](_page_15_Figure_0.jpeg)

Figure 6: (a) Excitation function of the elliptic (solid) and radial (dashed) flow for Pb+Pb or Au+Au collisions at b=7 fm from a hydrodynamic calculation.[33] The collision energy is parametrized on the horizontal axis in terms of total particle multiplicity density dN/dy at this impact parameter. (b) A compilation of  $v_2$  data vs. collision energy from mid-central (12–34% of the total cross section) Pb+Pb and Au+Au collisions. (c)  $p_t$ -integrated elliptic flow for minimum bias Au+Au collisions at  $s^{1/2}=130\,A\,\text{GeV}$  as a function of pseudorapidity, compared with data from PHOBOS and STAR. (d)Transverse momentum dependence of  $v_2$  for pions, kaons and protons. Filled plots are the results from the hybrid model. The impact parameter in the model simulation is 7.2 fm which corresponds to 20-30% centrality.

relaxation time  $\tau_r$ , which is can either be used as a regulator – and its value put to zero at the end – or as a real representation of two-gradient terms. There are 4 groups who have reported solving 2+1 dim higher order hydrodynamics. P. and U. Romatschke [36], Dusling and Teaney [37], Heinz and Song<sup>14</sup> [38]. Molnar [39] have compared viscous hydro with some version of his parton cascade and found good agreement when the parameters are tuned appropriately: but cascade describe  $v_2(p_t)$  even at larger momenta, the solution is supposed to converge to that of the Navier-Stokes eqn, avoiding the causality problems.

In Fig.9 we show Romatschke's results: literally taken they favor very small viscosity, even less than the famous lower bound. Now, is the accuracy level really allows us to extract  $\eta/s$ ? The uncertainties in the initial state deformation [40, 41] are at the 10% level, comparable to the viscosity effect itself. EoS

<sup>&</sup>lt;sup>14</sup>This group originally found viscosity effects about twice larger than others: but it was found in their later work that this happened because of different account for some higher order term. In the  $\tau_r \to 0$  limit, in which Navier-Stokes limits is supposed to be recovered, all results are now consistent with others.

![](_page_16_Figure_0.jpeg)

Figure 7: (Two examples of the excitation function of  $v_2$  in Au+Au collisions:(a) from [19] and (b) from [24]. Points obtained with fixed- $T_f$  (120 Mev in (a) and 100 MeV in (b)) freezeout strongly overpredict the data at low energies, but with cascade freezeout (red curves in both) those describe data quite well. (Two triangular points in (a) correspond to SPS and RHIC collision energies.)

can probably be constrained better, but I think uncertainties related to freezeout – not yet discussed at all – are also at 10 percent level, although they can also be reduced down to few percent level provided more efforts to understand hadronic resonances/interactions at the hadronic stage will be made. All of it leaves us with a statement that while literally fits require  $\eta/s \sim 0.1$  or less, we can only conclude that it is definitely  $\eta/s < .2$ . <sup>15</sup>. Even so, sQGP is still the most perfect liquid known.

In summary: hydrodynamics+hadronic cascades reproduces all RHIC data on radial and elliptic flows of various secondaries, as a function of centrality,rapidity or energy are reproduced till  $p_t \sim 2 GeV$ , which is 99% of particles. Contrary to predictions of some, CuCu data match AuAu well, so Cu is large enough to be treated hydrodynamically. New round of studies last year included viscosity and relaxation time parameters on top of ideal hydro: viscosity values is limited to very small value.

### 2.3 Jets quenching and correlations

Pairs of partons can collide at small impact parameter: in pp collisions this produces a pair of large  $p_t$  hadronic jets, which are (nearly) back-to-back in transverse plane (because total transverse momentum due to "intrinsic' parton  $p_t$  is small). We can use therefore those high- $p_t$  partons as a kind of x-rays, penetrating through the medium on its way outward and in principle providing its "tomography".

We will not go into this subject in depth (see e.g. PHENIX "white paper" [26] but just note that accurate calibration of structure functions have been made in pp and dAu collisions, as well as with hard photon measurements (which are not interacting with the QGP). Thus we know quite well how many jets are being produced, for any impact parameter. The number of hard hadrons observed at transverse momentum  $p_t$  relative to those expected to be produced as calculated from the parton model is called  $R_{AA}(p_t)$ . If this quantity is 1, it means the jets are all accounted for and none is lost in the medium. This is what indeed is observed with direct photons, not interacting with the matter, see Fig.10(a). It was quite unexpected that for mesons this ratio  $R_{AA}(p_t)$  was found to be rapidly decreasing and then in a wide range of momenta  $p_t > 4 \, GeV$  its value is only  $R_{AA}(p_t) \sim .2$  for central AuAu collisions, which means that 80% of jets are absorbed.

<sup>&</sup>lt;sup>15</sup>Unfortunately I am skeptical about magnitude of systematic errors of any lattice results for  $\eta/s$  (such as [42]): while the Euclidean correlation functions themselves are quite accurate, the spectral density is obtained by rather arbitrary choice between many excellent possible fits.

![](_page_17_Figure_0.jpeg)

Figure 8: (From [24]) (Left) Centrality dependence of  $v_2$ . The solid (dashed) line results from a full ideal fluid dynamic approach (a hybrid model). For reference, a result from a hadronic cascade model is also shown (dash-dotted line). (Right) Pseudorapidity dependence of  $v_2$ . The solid (dashed) line is the result from a full ideal hydrodynamic approach with  $T^{\text{th}} = 100 \text{ MeV}$  ( $T^{\text{th}} = 169 \text{ MeV}$ ). Filled circles are the result from the hybrid model. All data are from the PHOBOS Collaboration. [34]

![](_page_17_Figure_2.jpeg)

Figure 9: (From [36]) Elliptic flow  $v_2$  dependence on (Left) centrality and (Right)  $p_t$ , compared to viscous hydro with variable viscosity.

Theory of quenching mechanisms included gluon radiation on uncorrelated centers (with Landau-Pomeranchuk-Migdal effect) [43], synchrotron-like radiation on coherent fields [44, 45], as well as losses due to elastic scattering. Comparing two radiation mechanisms in general let me just remind that the synchrotron-like radiation gives the energy loss  $dE/dt \sim E^2$  growing quadratically with energy, it is stronger at high energies than radiation from uncorrelated kicks which gives only the first power  $dE/dt \sim E$ : but then correlation length in "GLASMA" fields and their lifetime is limited. As for elastic scattering losses, it depends on what are the couplings and especially masses of quasiparticles (quarks, gluons or maybe monopoles near  $T_c$ ) on which scattering occurs. The rate of energy loss itself is an order of magnitude larger than pQCD predictions. Multiple phenomenological fits for the  $R_{AA}(p_t)$  were made: but they depend on models.

Furthermore, as noted in my paper [46], any such model has predictions for ellipticity  $v_2$  in the range below its "geometric limit" for infinite quenching, while the data showed  $v_2$  exceeding such limits for all models used. In simpler words, those models could fit  $R_{AA}(p_t)$  but not a double plot  $R_{AA}(p_x, p_y)$ . The reason of such large  $v_2$  is not yet found, to my knowledge.

![](_page_18_Figure_0.jpeg)

Figure 10: (left) RAA from PHENIX for γ, π<sup>0</sup> , η and STAR for protons and charged pions. (right top) Two particle correlation function from STAR; (right bottom) RAA from PHENIX for single leptons (closed points) and π 0 (open points) compared to theoretical calculations

Further crucial test of this theory came from experimental observation of "single lepton" quenching and v2: those leptons come from semileptonic decays of c, b quarks. At the same p<sup>t</sup> heavy quarks have smaller velocity, and if the main quenching mechanism be radiative, it should reduce quenching accordingly. The data however do not show any serious reduction, with the same RAA(pt) ≈ .2 value for single leptons as for pions (coming mostly from gluon jets). This fact cast doubts at any perturbative mechanism of energy loss, since re-scattering of a gluon should be larger than that of a quark by the Casimir (color charge) ratio 9/4.

Moore and Teaney [47] developed a general framework of dealing with heavy quark dynamics in QGP, by invoking Focker-Plank or Langevin eqn. They have provided a general argument that if quark mass relative to temperature M/T is large, relaxation of heavy quark is happening slowly and thus justify the Langevin's uncorrelated kicks assumption.

$$\frac{dp_i}{dt} = \xi_i(t) - \eta_D p_i , \qquad \langle \xi_i(t)\xi_j(t')\rangle = \kappa \delta_{ij}\delta(t - t') . \qquad (28)$$

Here η<sup>D</sup> is a momentum drag coefficient and ξi(t) delivers random momentum kicks which are uncorrelated in time. 3κ is the mean squared momentum transfer per unit time. The usual diffusion constant D in space is related to those parameters by

$$D = \frac{T}{M\eta_D} = \frac{2T^2}{\kappa} \ . \tag{29}$$

![](_page_19_Figure_0.jpeg)

Figure 11: (from Moore and Teaney) (a) The charm quark nuclear modification factor RAA and (b) elliptic flow for representative values of the diffusion coefficient given in the legend. In this model, the drag is proportional to the velocity, dp dt ∝ v.

In Fig.11 we show the calculated dependence of quenching RAA and elliptic flow v<sup>2</sup> for leptons, resulting from the Langevin process (calculated on top of hydro evolution). As one can see stronger coupling leads to smaller RAA and larger v2: comparison with data (value about .2 for RAA and yellow band for v2) clearly favor the smallest diffusion constant, about DpπT ∼ 1. Further work on heavy quark diffusion by Rapp and collaborators [48] have tried to specify the diffusion constant from data better, and also suggested its explanation using heavy-light resonances.

The next RHIC discovery was associated with "jet correlations", which means that in events triggered by one hard particle with large p<sup>t</sup> one look for a second "companion particle" correlated<sup>16</sup> with it. While in pp and peripheral collisions one sees "back-to-back jets", with two peaks and relative azimuthal angle ∆φ values near zero or π, nuclear collisions typically show no (or strongly reduced) peak at π. Further subtraction of flow in the correlation functions revealed new peaks shifted from the direction of the companion jet by a large angle ∆φ ∼ 1.2rad ∼ 80<sup>o</sup> , see Fig.12(b).

Where the energy of the quenched jets go? Thinking about this question at the time we came with the answer: provided energy is deposited locally, hydrodynamics should provide a detailed prediction. Thus new hydrodynamical phenomenon<sup>17</sup> suggested in [49, 50], – the so called conical flow – is induced by jets quenched in sQGP. The kinematics is explained in Fig.12(a) which show a plane transverse to the beam. Two oppositely moving jets originate from the hard collision point B. Due to strong quenching, the survival of the trigger jet biases it to be produced close to the surface and to move outward. This forces its companion to move inward through matter and to be maximally quenched. The energy deposition starts at point B, thus a spherical sound wave appears (the dashed circle in Fig.12left ). Further energy deposition is along the jet line, and is propagating with a speed of light, till the leading parton is found at point A at the moment of the snapshot. The expected Mach cone

<sup>16</sup>It means that thousands of particles not correlated with the trigger are statistically subtracted.

<sup>17</sup>In the field of heavy ion collisions Mach cone emission was actively discussed in 1970's by Greiner et al: but it turned out not to work because nuclear matter – unlike sQGP – is not a particularly good liquid. The nucleon m.f.p. in nuclear matter is about 1.5 fm is not much smaller than the nuclear size.

$$cos(\theta_M) = \frac{\langle c(sound) \rangle}{c} \tag{30}$$

Here angular bracket means not only the ensemble average but also the time average over the time from appearance of the wave to its observation<sup>18</sup> .

Experimental correlation functions include the usual elliptic flow and the serious experimental issue was whether the peaks I just described are not the artifact of elliptic flow subtraction. By Quark Matter 05 this was shown not to be the case, see Fig.12( top right), which shows PHENIX data selected in bins with specific angle between trigger jet and the reaction plane: the shape and position of the maximum (shown by blue lines) are the same while elliptic flow has a very different phase at all these bins. The position of the cone is independent on angle relative to reaction plane Fig.12(right top), centrality (not shown here) and p<sup>t</sup> Fig.12(right down): so one may think it is an universal property of the medium. The angle values themselves are a bit different, with 1.2 rad preferred by Phenix and 1.36 rad by Star data: those correspond to amazingly small velocity of the sound wave<sup>19</sup> < c<sup>s</sup> >= 0.36 − 0.2, indicating perhaps that what we see was related to the near − T<sup>c</sup> region. Another evidence for that is observation of conical structure at low collision (SPS) energies, reported at QM08 by CERES collaboration: at such energies near-T<sup>c</sup> region dominates.

At the last Quark Matter 08 large set of 3-particle correlation data ( a hard trigger plus two companions) have been presented both by STAR and PHENIX collaborations. Although those are too technical to be shown here, the overall conclusion is that Mach cone structure is more likely explanation of the data than other possibilities such as "deflected jets".

A number of authors have by now reproduced the very existence of conical flow in hydro, see e.g. Baeuchle et al[51]: but really quantitative study of its excitation is still to be done. Casalderrey and myself[52] have shown, using conservation of adiabatic invariants, that fireball expansion should in fact greatly enhance the sonic boom: the reason is similar to enhancement of a sea wave (such as tsunami) as it goes onshore. They also showed that data exclude 1-st order phase transition, because in this case conical flow would stop and split into two, which is not observed.

Antinori and myself[53] suggested a decisive test by b-quark jets. Those can be tagged experimentally even when semi-relativistic: the Mach cone should then shrink, till it goes to zero at the critical velocity v = c<sup>s</sup> = 1/ √ 3. (Gluon radiation behaves oppositely, expanding with decreasing v.)

The experiments with tagged b-jets seem to be even more important in view of recent studies by Guylassy et al [193, 192] who found (using AdS/CFT results from [157] and specific model relating it to Cooper-Fry formula) that when the velocity of the jet v approach c<sup>s</sup> the angle of the peak does not accurately follow the Mach angle but remains always larger. They have further found that the main part of the peak comes not from cones but from the non-hydrodynamical near-jet zone (they call the "neck"): what is the nature of those large angle emission remains unknown. This group have further studied weak-coupling (pQCD-based) version of the near zone [192], finding that in this case most of the flow remains at small angles, with very small but visible peaks at Mach angle, but no trace of large-angle emission predicted by AdS/CFT.

Let me finally mention the main open question, which is the absolute and relative amplitudes of excitation of two hydrodynamical modes, the sound (responsible for the Mach cone structure) and the "diffuson" mode, which show matter co-moving forward behind the jet. As emphasized in our works, this question cannot be answered from hydro itself, as close to the jet it looses its applicability. As we will see later, this ratio was recently found from AdS/CFT: but we don't know yet of it does or does not agree with the data.

<sup>18</sup>Recall that the speed of sound changes significantly during the evolution, becoming small near T<sup>c</sup>

<sup>19</sup>Note, it is the velocity not squared. The speed of sound squared can be seen as a dash curve in Fig.15(right).

![](_page_21_Figure_0.jpeg)

Figure 12: (left) A schematic picture of flow created by a jet going through the fireball. The trigger jet is going to the right from the origination point B. The companion quenched jet is moving to the left, heating the matter (in shadowed area) and producing a shock cone with a flow normal to it, at the Mach angle cosθ<sup>M</sup> = cs/v, where v, c<sup>s</sup> are jet and sound velocities.

(right top)The background subtracted correlation functions from PHENIX experiments, a distribution in azimuthal angle ∆φ between the trigger jet and associated particle. Unlike in pp and dAu collisions where the decay of the companion jet create a peak at ∆φ = π (STAR plot), central AuAu collisions show a minimum at that angle and a maximum corresponding to the Mach angle

#### 2.4 Charmonium suppression

Charmonium suppression is one of the classic probes: since charm quark pairs originate during early hard processes, they go through all stages of the evolution of the system. A small fraction of such pairs  $\sim O(10^{-2})$  produce bound  $\bar{c}c$  states. By comparing the yield of these states in heavy ion collisions to that in pp collisions (where matter is absent) one can observe their survival probability, giving us important information about the properties of the medium.

Many mechanisms of  $J/\psi$  suppression in matter were proposed over the years. The first was suggested by myself in the original "QGP paper" [3], it is a gluonic analog to "photo-effect"  $gJ/\psi \to \bar{c}c$ . Perturbative calculations of its rate (see e.g. Kharzeev et al [54]) leads to a large excitation rates. Indeed, since charmonia are surrounded by many gluons in QGP, and nearly each has energy sufficient for excitation, one may think  $J/\psi$  would have hard time surviving. That was the first preliminary conclusion: nearly all charmonium states at RHIC should be rapidly destroyed. If so, the observed  $J/\psi$  may only come from recombined charm quarks at chemical freezout, as advocated e.g. by Andronic et al [55].

However the argument given above is valid only if QGP is a weakly coupled gas, so that charm quarks would fly away from each other as soon as enough energy is available. As was recently shown by Young and myself [56], in strongly coupled QGP the fate charmonium is very different. Multiple momentum exchanges with matter will lead to rapid equilibration in momentum space, while equilibration in position space is  $very\ slow$  and diffusive in nature. Persistent attractions between  $\bar{c}$  and c makes the possibility of returning back to the ground state for the  $J/\psi$  quite substantial, leading to a substantially higher survival probability. For the sake of argument, imagine the matter so dense that any diffusion of  $\bar{c}$  and c is completely stopped: then, after this situation changes by hadronization, one would still find them close to each other and thus  $J/\psi$  — with its by far the largest density at the origin — will be obtained again. Thus, strongly coupled — sticky - plasma may actually preserve the  $J/\psi$ .

Matsui and Satz [57] have proposed another idea and asked a different question: up to which T does charmonium survive as a bound state? They argued that because of the deconfinement and the Debye screening, the effective  $\bar{c}c$  attraction in QGP is simply too small to hold them together. Satz and others in 1980's have used the *free energy* potential, obtained from the lattice, as an effective potential in Schreodinger eqn.

$$F(T,r) \approx -\frac{4\alpha(s)}{3r} \exp(-M_D(T)r) + F(T,\infty)$$
(31)

They have shown that as the Debye screening radius  $M_D^{-1}$  decreases with T and becomes smaller than the r.m.s. radii of corresponding states  $\chi, \psi', J/\psi, \Upsilon'', \Upsilon', \Upsilon$ , those states should subsequently melt. Furthermore, it was found that for  $J/\psi$  the melting point is nearly exactly  $T_c$ , making it a famous "QGP signal".

Dedicated lattice studies [58, 59] extracted quarkonia spectral densities using the so called maximal entropy method (MEM) to analyze the temporal (Euclidean time) correlators. Contrary to the above-mentioned predictions, the peaks corresponding to  $\eta_c$ ,  $J/\psi$  states remains basically unchanged with T in this region, indicating the dissolution temperature is as high as  $T_{\psi} \approx (2.5-3)T_c$ . Mocsy et al [60] have used the Schrödinger equation for the Green function in order to find an effective potential which would describe best not only the lowest s-wave states, but the whole spectral density. Recently [61] they have argued that a near-threshold enhancement is hard to distinguish from a true bound state: according to these authors, the above mentioned MEM dissolution temperature is perhaps too high. My view is that the collisional width of states in sQGP is probably large and thus the discussion of MEM data is rather academic: in any case we dont observe  $J/\psi$  in plasma but after it, and a survival is a real-time issue which cannot be answered by the lattice anyway.

Let us now briefly review the experimental situation. For a long time it was dominated by the SPS experiments NA38/50/60, who have observed both "normal" nuclear absorption and an "anomalous"

![](_page_23_Figure_0.jpeg)

![](_page_23_Figure_1.jpeg)

Figure 13: (From [56]). (a)Distribution over quark pair separation at fixed T = 1.5T<sup>c</sup> after 9 fm/c of Langevin evolution, with (red squares) and without (green triangles) the ¯cc potential. Strong enhancement at small distances due to potential is revealed. (b)The points are PHENIX data for anomalous suppression of J/ψ in AuAu min bias collisions Ranomalous AA (y = 0). Two curves are Langevin model, with (solid, upper) and without (dashed, lower) feed-down.

suppression, maximal in central PbPb collisions. Since at RHIC QGP has a longer lifetime and reaches a higher energy density, straightforward extrapolations of the naive J/ψ melting scenarios predicted near-total suppression. And yet, the first RHIC data apparently indicate a survival probability very similar to that observed at the SPS.

One possible explanation [62, 63] is that the J/ψ suppression is (nearly exactly) canceled by a recombination process from unrelated (or non-diagonal) ¯cc pairs floating in the medium. However this scenario needs quite accurate fine-tuning of two mechanisms. It also would require rapidity and momentum distributions of the J/ψ at RHIC be completely different from those in a single hard production.

Another logical possibility advocated by Karsch, Kharzeev and Satz [64] is that J/ψ actually does survive both at SPS and RHIC: all the (so called anomalous, or nonnuclear) suppression observed is simply due to suppression of feed-down from higher charmonium states, ψ <sup>0</sup> and χ. (Those are feeding down about 40% of J/ψ in pp collisions.) These authors however have not explained why J/ψ survival probability can be close to one.

Young and myself [56] did exactly that, followed Langevin dynamics of charm quark pairs, propagating on top of (hydro) expanding fireball. The treatment basically is the same as that discussed in the preceding section, where heavy quark diffusion constant has been derived. One new important element though is the ¯cc effective potential, which we found is slowing down dissolution of the pair quite substantially, l see Fig.13(a) leading to "quasiequilibrium" situation in which ratios of different charmonium states are close to equilibrium ones at corresponding T, while the probability is continue to leak into unbound pairs which occupy slowly growing volume. The main finding of this work is that the lifetime of sQGP is not sufficient to reach the equilibrium distribution of the pairs in space, allowing for a significant fraction of J/ψ ∼ 1/2 to survive through ∼ 5 fm/c of the sQGP era. This probability for charmonium dissociation in sQGP is much large than in perturbative estimates, or for Langevin diffusion which would not include strong mutual interaction. We have not yet answered many other questions: e.g. what happens during ∼ 5 fm/c of the "mixed phase". (In view of it seem to be a magnetic plasma, as we will argue below, the mutual attraction of charmed quarks gets only stronger there,)

### 3 From lattice QCD to sQGP

This section has been more difficult to write than others, because a connection between lattice results and the "strongly coupled" regime of QGP at T = (1 − 2)T<sup>c</sup> remains indirect. Perhaps by itself it is rather unconvincing for a critical reader, as it was for many lattice practitioners, who are still quite reluctant to accept the "paradigm shift" of 2004. There are quite serious reasons for that. One (which we will discuss in the AdS/CFT section) is that the difference between weakly and strongly coupled regimes is deceivingly small in thermodynamical quantities. The second reason is that by performing Euclidean rotation of the formalism and correlators, one indeed gets rid of the unwanted phase factors, but a heavy price for that is extremely limited ability to understand real-time transport properties – diffusion constants, viscosity and so on – which turned out to be at the heart of this debate. As usual, we start with introduction for pedestrians which experts should jump over.

#### 3.1 The QCD phase diagram for pedestrians

QCD phase diagram is quite multidimensional: apart from the temperature T one can introduce chemical potentials µ<sup>f</sup> for each quark flavors u, d, s. One however only consider 2 combinations of those,the baryonic µ<sup>b</sup> = (1/N<sup>f</sup> ) P <sup>f</sup> µ<sup>f</sup> and isospin µ<sup>I</sup> = µ<sup>u</sup> − µ<sup>d</sup> chemical potentials. Then one can vary parameters of the theory itself, such as the number of colors N<sup>c</sup> or quark masses m<sup>f</sup> : in many cases however we will only discuss certain limits, for example in our discussion below a shorthand notation "2 flavors" N<sup>f</sup> = 2 would imply massless u, d quarks and infinitely heavy (or just absent) s, c, b, t quarks.

Three main phenomena will be under discussion: (i) confinement, (ii) chiral symmetry breaking and (iii) color superconductivity. The minimalistic phase diagram may have only three main phases: (a) hadronic, at low T and µb, which is both confined and has broken chiral symmetry; (b) Quark-Gluon plasma (QGP) at high T and µ<sup>f</sup> , where all kind of condensates are absent; and (c) color superconductor (CS) at high µ<sup>b</sup> and low T. There can of course be many more phases, as these features are not really exclusive– e.g. there can be coexisting chiral and CS condensates.

Note that two last phenomena are due to different kinds of pairing, chiral breaking (ii) is due to quark-antiquark pairing, its nonzero order parameter is the "quark condensate" < qq > ¯ ; while color superconductivity (iii) is due to quark-quark pairing and its nonzero order parameters are a set of diquark condensates < q<sup>a</sup> i q b <sup>j</sup> >, with color indices a,b and the flavor ones i,j arranged in various ways. (The spinor indices will be always suppressed because it is believed that whatever color-flavor structure of the condensates can be, the diquark spin remains zero, in most cases except very exotic ones.)

By confinement we mean more specifically electric confinement, which means that electric color field is expelled into flux tubes, making quark-antiquark potentials linear. M agnetic component of the gauge field is not expelled from the low temperature T < T c phase: we will in fact see that it actually dominates it<sup>20</sup>. Linear potential is synonymous to the "Wilson area law" of a large Wilson loop C

$$\langle W_C \rangle \sim exp[-\sigma Area(C)]$$
 (32)

with the nonzero string tension. From pioneering lattice calculation by Creutz in 1980's we know that pure gauge theories indeed have this feature, although mathematical "proof" of that remains famously elusive. Polyakov introduced in 1978 his famous loop and argued that it provides a disorder parameter, with nonzero value at T > Tc. We will discuss issues related to this below in some detail.

The area law and Polyakov loop average are of course true order parameters only in pure gauge theory without quarks. Since quark pair can be produced, the lattice static potentials show linear behavior up to certain distances. Many people thus think that in QCD with quarks the confining phase

<sup>20</sup>We will not discuss AdS/QCD in this review: let me still remind its practitioners that popular models of confinement – hard or soft "walls" ending the holographic space and forcing strings to generate linear potential – are over-simplistic, because the same thing happens with electric and magnetic strings.

![](_page_25_Figure_0.jpeg)

Figure 14: (a) The Polyakov loop, with am = 0.01 and 16<sup>3</sup> × 4 lattice. (b) Susceptibility of the chiral condensate, with am = 0.01 and two different lattices: 8<sup>3</sup> × 4, 16<sup>3</sup> × 4. The data are compatible with a crossover at the chiral transition. In the inset, the chiral condensate within the same range of β values. A clear jump is visible at the deconfinement phase transition. (c) The ρ parameter, with am = 0.01, L<sup>t</sup> = 4, for two different spatial volumes.

cannot be strictly defined and thus there should be no real phase transition separating it from the deconfined QGP.

This is however still disputed. Another possible order parameter (albeit nonlocal) is based on the idea of the "dual superconductor" by tHooft and Mandelstamm [103] which suggested long ago an existence of a nonzero magnetic condensate of some bosonic objects. Di Giacomo and collaborators have implemented the corresponding observable – called "Pisa order parameter" - which is an operator adding one explicit monopole to the vacuum. If so, the deconfinement should be a true phase transition: but numerical lattice data for generic nonzero quark masses show only a rapid crossover. This contradiction is not yet resolved.

To show one example in which all used order parameters are studied together, let me discuss the work by Pisa group on adjoint QCD [65] shown in Fig.14. In this theory a quark has the same color as gauge particles, and – unlike the usual quarks – it makes chiral restoration temperature distinctly different<sup>21</sup> from deconfinement. (Larger color representation (charge) of quarks is believed to lead to stronger ¯qq pairing and thus higher melting temperature for the chiral condensate.) The Polyakov loop shown in figure (a) behaves as disorder parameter at deconfinement indeed, the same point as indicated by Pisa parameter (c), while the chiral condensate and its susceptibility (b) indicate much smoother higher-T chiral restoration transition. Thus in adjoint QCD we see a presence of one more phase (on top of the minimal list of three given above), a deconfined but chirally broken phase which is usually called "a plasma of constituent quarks". It has all the requisites of a chirally broken phase, such as massless Goldstone bosons – pions, etc.

In general it is believed that with growing µ all transition become sharper. Arguments about likely shift in real-world QCD from near-crossover at zero µ and T<sup>c</sup> ≈ 170 MeV to real second-order point (the so called QCD critical point) and then first order line has been put forward by Rajagopal,Stephanov and myself [66], as well as few proposals how one can experimentally search for it. RHIC specialized run with greatly reduced beam energy is planned for 2009: perhaps it will shed light on this issue.

What happens if one changes another famous parameter, the number of colors by increasing Nc? Because gluons are adjoint and their effects are ∼ N<sup>2</sup> c , they dominate all quark-induced ∼ N<sup>1</sup> c effects. It has been recently argued by McLerran and Pisarski [67] that this implies that at large enough N<sup>c</sup> Tdeconf inement >> Tchiral. The phase in between –chirally restored and confined – they called a

<sup>21</sup>Most lattice works agree on coinciding deconfinement and chiral symmetry in fundamental – real-world – QCD, but it is still debated and I refrained from taking sides and show one but not the other plot.

"quarkionic" phase, thinking about quark-filled Fermi sphere but with baryonic excitations at the surface. Glozman [68] further suggested even more exotic possibility: particle excitations in form of (chirally symmetric) baryons, without baryonic holes. The issue is not yet settled and such phases have not been seen on the lattice<sup>22</sup>. My view is that both these exotic ideas are perhaps excluded in a confined phase, so it should be just baryonic.

In the discussion above we have ignored short 1-st order transition line between the "vacuum-like" and "nuclear matter-like" regions, at µ ≈ M<sup>N</sup> /3, T < T<sup>c</sup> ∼ 8 MeV . Since the usual N<sup>c</sup> = 3 nuclear matter is Fermi-liquid, it is not qualitatively different from the bulk of hadronic phase: thus one can go around this phase transition. This is not the case for larger Nc, as in this case baryons are becoming heavier M<sup>B</sup> ∼ N<sup>c</sup> while the nuclear forces are believed to have a smooth limit

$$V(r, N_c) \to V(r, N_c = \infty)$$
 (33)

The obvious consequence of this is crystallization, as kinetic energy gets subleading to the potential one. Examples of specific calculations with the skyrmions are well known<sup>23</sup> [70]. Is there a possibility that solidification happens even for physical N<sup>c</sup> = 3 QCD? Old Migdal's pion condensation was of this nature, and for more recent study of crystalline quark matter see Rapp, myself and Zahed [71]. There can also be a crystalline color superconductor, known also as LOFF phase, see more in the review [72]. Instead of going any further into the zoo of possibilities, let me stop with a joke: perhaps QCD would not have less phases than water does, and this is quite a lot.

Finally, for completeness, let me mention the opposite direction, increasing the number of light quarks N<sup>f</sup> . At some point asymptotic freedom will disappear, but before that there should be a critical line (or more) at which Banks-Zaks infrared fixed point will make the theory conformal in IR. As the corresponding fixed point coupling gets less and less, chiral symmetry breaking and confinement must go: again either together or separately. All this territory is amenable to lattice analysis but remains largely unexplored.

#### 3.2 Main QGP properties from the lattice

The thermodynamical observables – pressure and energy density p(T), (T) – from the lattice is the simplest global observable, thus they were calculated more than a decade ago (and used in hydro calculations). Let me show two recent plots from Karsch [73] which depict them in a combinations which reveal somewhat more than standard plots of p(T), (T).

The first combination − 3p = Tµµ is related to the famous scale anomaly: the fact that its value relative to p, themselves goes to zero means that QGP gets more and more conformal. However the way it goes down is not 1/T<sup>4</sup> – as simple bag model predicts: this phenomenon is not yet explained.

As shown in [73] and earlier papers, quark and gluon quasiparticles dominate at T > 1.5Tc. But what happens below that? Gluon/quark masses are too high M ∼ (3−4)T to explain the peak of −3p. Chernodub et al [74] have shown that lattice magnetic objects – monopoles and vortices – reproduce the shape<sup>24</sup> of this curve well.

The second combination<sup>25</sup> is p/ - now conformity is seen as the place where this ratio reaches 1/3.

<sup>22</sup>Chirally symmetric baryons can certainly exist: in fact Liao and myself [69] have argued that those are needed to explain lattice susceptibilities in the usual N<sup>c</sup> = 3 QGP near deconfinement at T ∼ µ.

<sup>23</sup>These works also found another phase at higher density, in which skyrmions "fragment" into objects of fractional topology: they interpreted those as a "chirally restored" baryonic phase. I however don't know if one can trust the model all the way to this phase.

<sup>24</sup>Unfortunately not the absolute normalization: this issue deserves further studies as the lattice used in this work is rather small.

<sup>25</sup>Its special role in hydrodynamics was emphasized [23] and its minimum got a spatial name - "the softest point". Indeed, the gradient of pressure provides a force and energy density a mass to be moved, so p/ it is proportional to hydrodynamical acceleration of matter.

![](_page_27_Figure_0.jpeg)

![](_page_27_Figure_1.jpeg)

Figure 15: The trace anomaly,  $(\epsilon - 3p)/T^4$  (left) calculated on lattices with temporal extent  $N_{\tau} = 6$ , 8 and the ratio of pressure and energy density as well as the velocity of sound obtained in calculations with the p4fat3 action on  $N_{\tau} = 6$  (short dashes) and 8 (long dashes).

One can clearly see that it is not yet reached at RHIC, but it is the case at LHC. This is one of the reasons why LHC experiments will be decisive in proving (or disproving) whether the AdS/CFT duality can (or cannot) be used in the  $conformal\ window$  of finite-T QCD.

Let me now turn to the screening lengths. As I already mentioned, QGP got its name after it was found [2] that thermal gluons – unlike virtual ones – lead to electric screening of the charge in weakly coupled regime (high T). The corresponding electric (or a Debye) mass is  $M(electric) \sim gT$ . Static magnetic screening does not appear via perturbative diagrams; but it has been soon conjectured by Polyakov [75] that magnetic screening should appear non-perturbatively, at the smaller "magnetic scale"  $M(magnetic) \sim g^2T$ .

To illustrate whether lattice results on the screening masses are or are not in agreement with that, we show their T-dependence calculated by Nakamura et al [76], see Fig.16(a). Note that at high T the electric mass is indeed significantly larger than the magnetic one, but it vanishes at  $T_c$  – here electric objects gets too heavy and "electric part" of QGP effectively disappears. However magnetic screening mass grows continuously toward  $T_c$ : thus the two cross each other, around  $T = 1.5T_c$ .

These observation were in fact the starting point for Liao and myself in thinking about "magnetic scenario" for the near- $T_c$  region. We had used the screening masses to get an idea about density of electric and magnetic objects, one should conclude that QGP switched from electric to magnetic plasma somewhere around of

$$T_{E=M} \approx 1.5T_c \sim 300 \, MeV \tag{34}$$

The static potential between quark and anti-quark is another traditional observable, by means of which quark confinement in Non-Abelian gauge theories was established. It was originally inferred from heavy meson spectrum and Regge trajectories, and then studied in great detail numerically, through lattice gauge theories, for review see e.g. [78]. It is usually represented as a sum of a Coulomb part  $V \sim 1/r$ , dominant at small distances, and a linear part  $V = \sigma r$  dominant at large distances. The latter, related with existence of electric flux tubes, is a manifestation of quark confinement. The string tension in the vacuum (T = 0) has been consistently determined by different methods to be about

$$\sigma_{vac.} \approx (426 MeV)^2 \approx 0.92 \, GeV/fm$$
 (35)

![](_page_28_Figure_0.jpeg)

Figure 16: (upper left) Temperature dependence of electric and magnetic screening masses according to Nakamura et al [76]. The dotted line is fitted by the assumption,  $m_g \sim g^2 T$ . For the electric mass, the dashed and solid lines represent LOP and HTL re-summation results, respectively. (upper right) Temperature dependence of the effective string tensions of the free and potential energies  $\sigma_F, \sigma_V$ . (down) The energy and entropy (as  $TS_{\infty}(T)$ ) of two static quarks separated by large distance, in 2-flavor QCD according to [77].

Studies of the static QQ potential have been extended to finite T. In particular, deconfinement temperature  $T_c$  is defined as a disappearance of the linear behavior as a signal of deconfinement at  $T > T_c$  in the corresponding free energy F(T, r). Bielefeld-BNL group has published lattice results for static  $\bar{Q}Q$  free energy, as well as internal energy and entropy

$$V(T,r) = F - TdF/dT = F + TS$$
(36)

at T both below and above  $T_c$ , see [79, 80].

Remarkable features of these results include:

- 1. The linear (in r) part of the potentials. Their effective tensions are shown in Fig.16(top right). While that for free energy vanishes at  $T_c$  (by definition), that for potential energy extends till at least about  $1.3T_c$ , with a peak values about 5 times (!) the  $\sigma_{vac}$ . Similar behavior is seen in entropy, while canceling in free energy. The widths of these peaks provide a natural definition of "near- $T_c$ " region as  $T/T_c = 0.8 1.2$
- 2. Although potentials at large distances  $r \to \infty$  are finite  $V(T, \infty)$ , near  $T_c$  their values reach very large magnitudes, see Fig.16(down). The corresponding large entropy  $S(T_c, \infty) \approx 20$  means that really huge  $\sim exp(20)$  number of states is involved;

The origin of this large energy and entropy associated with static  $\bar{Q}Q$  pairs near  $T_c$ , remains mysterious: many attempts (e.g. [81]) failed to explain it. Below we will return to this phenomenon in connection with "magnetic plasma" scenario.

Before looking for explanations, however, let us focus on physical difference between F and U, based on papers by Zahed, Liao and myself [82, 83], in which they are related to what happens for slow and

f ast motion of the charges. To be specific, let's consider a pair of static charges held by external hands. Suppose they are close initially Lini. → 0, and then are separated to some finite L. This can be done in two possible ways, adiabatically slowly or very fast. The difference between them in thermodynamical and quantum-mechanical contexts are known in many fields of physics. Perhaps the oldest is the so called Landau-Zener problem [84] of electron motion, following the motion of two nucleus in a diatomic molecule. While nuclei change their relative distance L with velocity v<sup>12</sup> = dL/dt, the electrons are in a specific quantum state with the energy depending in L. The issue is probability of the level crossings, which appear when there are two quantum levels E1(L) ≈ σ1L + C<sup>1</sup> E2(L) ≈ σ2L + C<sup>2</sup> crossing each other, at some separation L0. When the two nucleus approach the crossing at L<sup>0</sup> very slowly, then the electrons may jump from one energy state to another, always selecting the lowest energy state. However if the two nucleus move fast, there is large probability for the electron to remain in the original state. More quantitatively, Landau-Zener showed that this probability is given by

$$P_{fast} = exp \left[ -\frac{2\pi |H_{12}|^2}{v_{12}|\sigma_1 - \sigma_2|} \right]$$
 (37)

where H<sup>12</sup> is the non-diagonal transition matrix element of the Hamiltonian; but we will only need the limits of large and small v12. The adiabatic limit obviously corresponds to free energy F(T, L) measured on the lattice. The "potential energy" V (T, L) means that no entropy is generated: this implies that there was no transition from the original pure state at T=0 into multiple states as level crossing occur: thus it corresponds to fast motion limit. The positivity of entropy means that V > F always.

This discussion is very relevant for the problem of effective potential to be used in Schreodinger eqn for the bound states, e.g. in charmonium problem. Zahed and myself [82] argued that in this case one should use the internal energy: provide much more stable bound states, delaying J/ψ melting to higher T ∼ 3Tc. Several authors (e.g. [85]) have used effective potentials in between those two limiting cases. With such potentials not only charmonium but also light quark mesons get bound, as also are baryons and "gluonic chains" [86] and also colored binary states. However, in a liquid with the parameters we expect from such interaction the number of nearest neighbors associated with one charge is expected to be ∼ 4, and thus it is not clear what is the role of the binary states. Quantum manybody studies of these systems are not attempted yet, and we don't know if there is any sense to identify them, and if so how wide those states may be.

### 3.3 Polyakov loop, "Higgsing" and deformations of QCD

Physics of monopoles, to which we will turn shortly below, has been originally developed in the Georgi-Glashow model or N =2 SUSY which has adjoint scalars. Those may have some nonzero expectation values – this phenomenon would be colloquially referred to as "Higgsing" below. If so, the color group is broken, generically to diagonal U(1)<sup>N</sup> c . QCD-like theories are much more difficult precisely because they do not have elementary scalars, making Higgsing much more subtle, with its role at finite T presumably played by the zeroth component of the gauge field A0.

The definition of the Polyakov loop [75] is a holonomy of the gauge field across the periodic direction

$$U = Pexp(i \int_0^\beta A_0 d\tau) \tag{38}$$

where β = 1/T is the Matsubara time. If it has VEV one can think of < U > as a diagonal color matrix, with some eigenvalues v1...v<sup>N</sup> : Polyakov's view on confinement is that the eigenvalues widely fluctuate and < T r(U) >= 0: in the deconfined (plasma phase) these eigenvalues fluctuate little near minima of the effective action, at v<sup>k</sup> = e <sup>2</sup>πik/N . At high T – that is in weak coupling – one can calculate this effective potential perturbatively. In zeroth order, A<sup>0</sup> = const costs no energy, but its coupling

![](_page_30_Figure_0.jpeg)

Figure 17: Schematic phase diagram for adjoint QCD with Shifman-Unsal deformations, on a plane deformation parameter a - temperature T. At zero deformation a=0 (left side of the plot) one has the usual adjoint QCD in which deconfinement happens below chiral symmetry restoration. However, as a grows and we deform into a theory without deconfinement, the order must be reversed, giving place to a new phase in the right upper corner, which is confined but chirally symmetric.

to gluons in the heat bath leads to shifting the gluon states<sup>26</sup> and as a result one gets the following effective action

$$V_{eff} = -\frac{2T^4}{\pi^2} \sum_{n=1} \frac{|TrU^n|}{n^4}$$
 (39)

This pushes TrU away from zero, to the minima mentioned. One set of lattice data on  $\langle P(T) \rangle$  has been already shown in Fig.14(a): as one can see the breaking indeed happens and thus it is indeed a disorder parameter.

Opinions on the role of the breaking of the  $Z_N$  symmetry vastly duffer: while some think it the very essence of confinement others think it has no dynamical meaning at all. To exemplify this polemics the reader may e.g. see Ref. [87] in which Smilga pointed out that it is highly suspicious that the pure gauge theory – which has no such symmetry and can be formulated as SO(3) gauge theory rather than SU(2), with  $Z_2$  explicitly eliminated. Smilga further argued using simpler examples that effective potential is gauge-dependent concept and should be treated with care, he emphasized that although at finite lattices/coupling one may apparently see  $Z_N$  domains, only one minimum is physical and the so called Z(N) bubbles with nonzero surface tension are not really there. For comparison of these two lattice formulation see deForcrand [88]. The question is no longer debatable when there are fundamental fermions in the theory, as they see different  $Z_N$  phases and thus no longer respect the symmetry and one vacuum with real Polyakov line VEV is preferred.

Before we discuss phenomenology of the Polyakov line and its effective potential in strong coupling (on the lattice) in real-world QCD, let us turn to interesting "deformations" of QCD recently discussed by Unsal [89] and Shifman and Unsal [90]. The central idea is to deform some QCD-like theory continuously into something else to which the answer is either known or can be obtained perturbatively. Although they consider several different fermion representations, for simplicity we will only consider in this section the case of adjoint fermions, for which the interplay of gluons and fermions is simpler. Before going into details, here is the list of deformations:

<sup>&</sup>lt;sup>26</sup>Here we mean gluodynamics only: we turn to quarks a bit later.

- (i) rotating fermionic boundary conditions along the time from anti-periodic to periodic
- (ii) putting the theory into a spatial box with variable size
- (iii) introducing additional potential for the Polyakov loop.

The first deformation is obtained via the introduction of the phase into fermion boundary condition, allowing to interpolate smoothly between the periodic and anti-periodic boundary condition

$$(-) = \exp(i\alpha + i\pi) \tag{40}$$

into fermionic contribution into a line, with α changing from 0 (anti-periodic) to π (periodic) continuously. The effective potential becomes then

$$V_{eff} \sim \sum_{n} (N_f e^{(i\alpha + i\pi)n} - 1) \frac{|TrU^n|^2}{n^4}$$
 (41)

When α = π (periodic boundary conditions) and the number of flavors N<sup>f</sup> = 1 two terms in the effective action simply cancel: this happens because this theory is the N =1 SUSY gluodynamics with the supersymmetry remaining unbroken<sup>27</sup>. The famous argument based on Witten index applies in this case, telling that the number of vacua cannot be changed with any deformation. When N<sup>f</sup> > 1 the fermionic terms dominate and the sign of the potential is reversed. It means in this case one has the theory in which U is not pushed to large values and there is no Z<sup>N</sup> breaking and thus no deconfinement even at weak coupling.

Let us now think about deconfinement and chiral symmetry of the adjoint QCD for 2 ≤ N<sup>f</sup> ≤ 5 (the upper limit from asymptotic freedom) in the α − T plane, shown in Fig.17. When α = 0 we have the usual (undeformed) adjoint QCD in which (see Fig.14) T<sup>χ</sup> > Tconf . But when α = π there should be no deconfinement phase at all, which means that Tconf (α) grows indefinitely before crossing the α = π vertical line. There should however still be chiral symmetry breaking at any α: in fact the α = π theory with periodic fermions has well known dyons with 2N<sup>f</sup> fermionic zero modes, which generate NJL-type interaction and chiral symmetry breaking provided T is small enough to get the coupling large enough<sup>28</sup>. As a result, there should be an intersection between the deconfinement line Tconf (α) and the chiral restoration line Tχ(α) at some αcrossing, as shown in Fig.17: after the deconfinement and chiral symmetry restoration lines have crossed one finds a qualitatively new phase, with confinement but with unbroken chiral symmetry .

Now let us turn to the second Shifman-Unsal deformation of the QCD-like theories: if one formulates the theory on R<sup>3</sup> ×S<sup>1</sup> space with (periodic for fermions) compact direction of the variable length L, one can gradually interpolate between 4-d and 3-d gauge theories. The major difference between those, as explained by Polyakov [93] many years ago, is that while 4-d instanton-antiinstanton interaction is short range 1/r<sup>4</sup> , the 3d instantons (that is, monopoles) interact by a long range magnetic Coulomb 1/r. The result is that the 3d theory is confined by monopoles-instantons, while the 4d theory is not confined by its instantons. Moreover, it happens even in the weak coupling regime, in which the instanton-monopole density is exponentially small.

Specific mechanism for QCD on R<sup>3</sup> × S <sup>1</sup> was discussed by Unsal in a separate paper [94] for periodic fermions, it is condensation of magnetic charge 2 "bions" – pairs of certain dyons – bound by fermion-induced forces in spite of mutual magnetic repulsion. The binding is analogous to instantonantiinstanton molecule formation, the confinement at high T is like Polyakov mechanism in 3dim [93].

The third Shifman-Unsal deformation is done by an addition to the QCD action of artificial potential for the U, e.g.

$$V_{add} \sim \sum_{n} a_n |TrU^n| \tag{42}$$

<sup>27</sup>We remind the reader that normal thermal boundary conditions obviously break the symmetry between fermions and bosons.

<sup>28</sup>The physics of chiral transition is the same transition between "instanton liquid" and "instanton-antiinstanton molecules described by Ilgenfritz and myself [91], see also references for later studies in the review [92].

with some coefficients  $a_n$  chosen at will. The authors themselves argued that if the coefficients are chosen in order to *oppose* the  $V_{eff}(U)$  generated by quantum fluctuations naturally, one should be able to delay deconfinement (increase  $T_{conf}$ ), to the extent that it will occur in the weakly coupled domain and make it tractable in a (semiclassical) controlled approximation.

Perhaps it is also interesting to go to another direction as well, decreasing  $T_{conf}$ , reaching for the regime in which electric theory is even stronger coupled than usual but its dual –magnetic theory of monopoles – will gets perturbative instead. Both deformations can easily be done on the lattice: a possibility to check continuity of the underlying physics of both deconfinement and chiral restoration all the way from strong to weak coupling will surely contribute a lot into our understand of both.

#### 3.4 Phenomenology of $V_{eff}(U)$ in QCD

The early history of perturbative derivation of the effective potential for U (or  $A_0 = const$ ) can be found in the classic review [95]. Instead of repeating here well known results, let me refer to more recent attempts to combine known perturbative results with the lattice data include a paper by Pisarski [96] where one can find the details of the recommended effective Lagrangian.

One more motivation to study the QCD deformation via adding extra potential for Polyakov loop on the lattice comes from heavy ion phenomenology. Dumitru and collaborators [97] have used this form of the effective Lagrangian to study real-time evolution of  $A_0$ . The main conclusion from their work is that that  $\langle A_0 \rangle$  belongs to the class of so called *slow variables*, and its evolution in heavy ion collisions has to be treated separately from the overall equilibration. They have performed numerical solution of the EOM for it, starting from "suddenly quenched" value corresponding to its vacuum form, moving toward its minimum at the deconfined phase at  $T=2T_c$ . The main finding of this work is that the relaxation of this variable is very slow, taking about 40 fm/c or so. This time significantly exceeds the QGP lifetime at RHIC which is only about 5 fm/c or so, which suggests that in real collisions we should treat  $A_0$  as essentially random variable frozen at some value and color direction during hydro evolution. It means there is a chaotic out-of-equilibrium Higgsing, slowly rolling down, like in cosmological inflationary models: thus one would like to know as much as possible about phase transitions and EoS for *all* values of  $\langle U \rangle$ .

Another active direction using effective potential  $V_{eff}(U)$  is the so called PNJL model [98], which combines the Polyakov loop with well known Nambu-Iona-Lasinio model for chiral symmetry breaking, see also [99]. Quite impressive results for QCD thermodynamics were obtained along this path by the group of Weise [100]. Let me give their notations and the parameterization of the potential. A background color gauge field  $\phi \equiv A_4 = iA_0$ , where  $A_0 = \delta_{\mu 0} g \mathcal{A}_a^{\mu} t^a$  with the  $SU(3)_c$  gauge fields  $\mathcal{A}_a^{\mu}$  and the generators  $t^a = \lambda^a/2$ . The matrix valued, constant field  $\phi$  relates to the (traced) Polyakov loop as follows:

$$\Phi = \frac{1}{N_c} \text{Tr} \left[ \mathcal{P} \exp \left( i \int_0^\beta d\tau A_4 \right) \right] = \frac{1}{3} \text{Tr} \, e^{i\phi/T} , \qquad (43)$$

In the so-called Polyakov gauge one chooses a diagonal representation for the matrix  $\phi$ ,  $\phi = \phi_3 \lambda_3 + \phi_8 \lambda_8$ , which leaves only two independent variables,  $\phi_3$  and  $\phi_8$ . The potential involves the logarithm of  $J(\Phi)$ , the Jacobi determinant which results from integrating out six non-diagonal SU(3) generators while keeping the two diagonal ones,  $\phi_{3,8}$ , to represent  $\Phi$ :

$$\frac{\mathcal{U}(\Phi, \Phi^*, T)}{T^4} = -\frac{1}{2}a(T)\,\Phi^*\Phi + b(T)\,\ln\left[1 - 6\,\Phi^*\Phi + 4\left(\Phi^{*3} + \Phi^3\right) - 3\left(\Phi^*\Phi\right)^2\right] \tag{44}$$

with

$$a(T) = a_0 + a_1 \left(\frac{T_0}{T}\right) + a_2 \left(\frac{T_0}{T}\right)^2, \qquad b(T) = b_3 \left(\frac{T_0}{T}\right)^3.$$
 (45)

![](_page_33_Figure_0.jpeg)

Figure 18: Comparison of PNJL model predictions [100] with susceptibilities of different order, from 2 to 8 derivatives over  $\mu$  at  $\mu = 0$  with the lattice data [101].

The logarithmic divergence of  $\mathcal{U}(\Phi, \Phi^*, T)$  as  $\Phi$ ,  $\Phi^* \to 1$  automatically limits the Polyakov loop  $\Phi$  to be always smaller than 1, reaching this value asymptotically only as  $T \to \infty$ . The parameters  $a_i$  and  $b_3$  are determined to reproduce lattice data for the thermodynamics of pure gauge lattice QCD up to about twice the critical temperature<sup>29</sup>. The values of these parameters are  $a_0 = 3.51$ ,  $a_1 = -2.47$ ,  $a_2 = 15.22$ ,  $b_3 = -1.75$ . The critical temperature  $T_0$  for deconfinement in the pure gauge sector is fixed at 270 MeV in agreement with lattice results.

After performing a bosonization of the PNJL action and introducing scalar and pseudoscalar auxiliary fields,  $\sigma$  and  $\vec{\pi}$ , the PNJL thermodynamic potential becomes:

$$\Omega\left(T, \mu_{q}, \sigma, \Phi, \Phi^{*}\right) = \mathcal{U}\left(\Phi, \Phi^{*}, T\right) + \frac{\sigma^{2}}{2G} - 2N_{f} \int \frac{\mathrm{d}^{3}p}{(2\pi)^{3}} \left\{ T \ln\left[1 + 3\Phi e^{-(E_{p} - \mu_{q})/T} + 3\Phi^{*} e^{-2(E_{p} - \mu_{q})/T} + e^{-3(E_{p} - \mu_{q})/T}\right] + T \ln\left[1 + 3\Phi^{*} e^{-(E_{p} + \mu_{q})/T} + 3\Phi e^{-2(E_{p} + \mu_{q})/T} + e^{-3(E_{p} + \mu_{q})/T}\right] + 3\Delta E_{p} \theta \left(\Lambda^{2} - \vec{p}^{2}\right) \right\}$$
(46)

where the quark quasiparticle energy is  $E_p = \sqrt{\vec{p}^2 + m^2}$  and the dynamical (constituent) quark mass is the same as in the standard NJL model:  $m = m_0 - \sigma = m_0 - G\langle \bar{\psi}\psi \rangle$ . The last term in the previous equation involves the difference  $\Delta E_p$  between the quasiparticle energy  $E_p$  and the energy of free fermions (quarks).

In order to see how this model works, the reader can have a look at Fig.18: the agreement is very good. The key feature of the expression above is the suppression by the Polyakov loop, which appears

<sup>&</sup>lt;sup>29</sup>At much higher temperatures, where transverse gluons begin to dominate, the PNJL model is not supposed to be applicable.

as Φ in the single quark (or antiquark) term in square brackets, as Φ<sup>∗</sup> for diquarks and finally there is no Φ in the last term corresponding to 3 quarks in colorless combination. The effect of all of that is that quark and diquark terms are suppressed in the deconfined phase, while 3-quarks are not: this drastically improves the prediction of the original NJL model. The reader should note, that unsuppressed colorless 3-quark term is basically nothing else but a baryon – thus the main lesson of this work is actually quite similar to that of Liao and myself [69], namely that the QCD thermodynamics at finite µ, both below and right above Tc, is still dominated by baryons rather than by individual quarks.

### 4 Electric-magnetic duality and finite-T gauge theories

Electric/magnetic duality is repeatedly resurfacing during the history of physics, serving as a source of inspiration for a while and then going dormant again. I would put the first occurrence of that to famous Maxwell's guess about displacement current, guided by a "dual relation" containing time derivative of magnetic flux discovered by Faraday. From then on, vacuum Maxwell eqns are of course perfectly E-B dual.

In the first years of quantum mechanics Dirac famously shown that the wave function can only be consistently defined if the electric and magnetic coupling constants are related by the celebrated quantization condition

$$\alpha(electric)\alpha(magnetic) = n \tag{47}$$

where n is some integer. With advent of quantum field theory, renormalization and running couplings, this condition elevates into a requirement that these two couplings must run in the opposite directions:

$$\beta(electric) + \beta(magnetic) = 0 \tag{48}$$

Thus when α(electric) = e <sup>2</sup>/4π is small (at high T), α(magnetic) = g <sup>2</sup>/4π should be strong. We will discuss implications of that for QGP below.

In 1974 't Hooft and Polyakov have discovered monopole solutions in gauge theories. The specific setting was Georgi-Glashow model, which is a gauge theory supplemented by adjoint scalar providing "Higgsing". Recall that when VEV is diagonalized, all N<sup>c</sup> −1 diagonal color matrices commute with it, which leave those U(1) "photons" massless<sup>30</sup>. (There is huge literature about monopoles in this setting and in supersymmetric theories, for non-experts the book by Shnir [102] can be recommended.)

G.'t Hooft and Mandelstamm [103] famously suggested to explain confinement by a "dual superconductor" made of Bose-condensed magnetically charged objects. Seiberg and Witten [104] have famously shown how it works in the N=2 super Yang Mills theory. They have shown spectacular example of "triality" between electric, magnetic and "dyonic" descriptions near the corresponding singularities on the moduli space. Work continues on the supersymmetric front, populating our "topological zoo" by new species, for good pedagogical review see e.g.[105]. Let me just mention two recent additions: the non-Abelian magnetic strings and monopoles which live inside them as "beads" [106] or duality between gauge theory on domain walls and in the bulk [107]. All these developments are of course the pillars of our understanding of magnetic objects: which however remains quite incomplete for the very theory it is needed, the QCD. One obvious way to find and study dynamical role of magnetic objects in various observables is the detailed analysis of lattice configurations. Such approach was very successful for instantons (for review see e.g.[92]). Let me comment on those works related to monopoles, dyons and fermionic dyons, consequently.

Lattice observation of the monopoles require fixing the gauge, as explained long ago e.g. in DeGrand [108], and then calculating the total magnetic flux through all elementary 3-d boxes. Naively, since each link appears twice there should be always zero flux: but since the phase is counted modulo 2π there

<sup>30</sup>In SU(3) theory those are 2 – λ3, λ<sup>8</sup> – massless and 6 massive gluons.

are nonzero fluxes in some boxes. It literally means that (in a particular gauge) we look where singular Dirac strings end. The monopole current can then be defined: monopole boxes form closed loops. Are those objects physical or just some UV noise in unphysical gauge choice? The answer to this long standing question in general is still not completely clear: however better posed specific questions recently produced so reasonable and consistent answers – apparently independent of the particular lattice parameters – that they should be physical (in my opinion).

In particular, if one counts only the loops which are winding around the lattice at least once, then their density was shown to scale correctly with lattice parameters. As we show in the next section, the correlation function between those monopoles behave "physically", in a way consistent with what one expects from a running magnetic coupling. In vacuum, they run around confining electric flux tubes, as "magnetic coil" should do. Above T<sup>c</sup> they show liquid-like correlation in quantitative agreement with MD for classical electric/magnetic plasmas. All of this prompts me optimistically assume that those objects are physical. (Yet we still don't quite understand the objects themselves, don't know their masses and structure, and we even cannot explain why in some other gauge one cannot see them at all.)

From the point of view of the definition, another kind of magnetic objects – the self-dual dyons – are much easier. Kraan-van Baal solution [111] has shown that already at the classical level, in the presence of nonzero holonomy or "Higgsing", finite T instantons are decomposed into N<sup>c</sup> self-dual dyons.

Because these dyons are descendant of instantons, they may be seen "via the eyes of fermions" : and indeed such methods were developed by Gattringer, Ilgenfritz and others, with stunningly beautiful examples of such dyons in gauge configurations. Diakonov and collaborators have evaluated quantum one-loop correction to Kraan-van Baal solution [112] and discussed the ensemble of dyons [113]. Yet there are serious reasons to think that dyons are less important than monopoles: . (i) Their density is not peaking near Tc; (ii) They seem to be more massive than monopoles (we will return to this issue in the summary of the chapter); and – last but not least – (iii) Bose-condensed dyons would not create only electric confinement, as needed, because they are selfdual and thus cannot tell E~ from B~ field.

Finally, massless fermions have zero modes on topological objects, including the monopoles/dyons. Supersymmetric theories – e.g. the celebrated Seiberg-Witten N =2 theory – must have it as a requirement, since all monopoles/dyons should have fermionic superpartners. I would think that in QCD quarks should also be able to "ride on a monopole": but their masses, density and dynamical role is not yet investigated.

### 4.1 A "magnetic scenario" for near-T<sup>c</sup> region

In the chapter related with applications of hydrodynamics it was called traditionally "the mixed phase", as the model EoS used still had a phase order transition and Maxwell construction at intermediate (entropy) density. This was done along the traditional thinking, although we know for fact that none of the overheating-overcooling fluctuation phenomena (known near any first order transition) are actually observed in heavy ion collisions. The so called event-by-event fluctuations there turn out to be remarkably small and simple. So, this is definitely not a QGP and hadronic phase mixed together in some kind of emulsion.

The question is, what is the adequate picture for the near-T<sup>c</sup> region? Liao and myself [114] proposed a new and very simple view on this question – "the magnetic scenario" – which basically suggests it to be a magnetic plasma of monopoles, in a liquid form. Another line of work based on lattice data lead Chernodub and Zakharov [115] to the same conclusion.

Let me start with a qualitative discussion of the running couplings on the phase diagram, which is a crucial element of the argument. As QGP produced is cooling down and T decreases toward Tc, the electric coupling grows and the magnetic one decreases, in accordance with asymptotic freedom and Dirac condition (47). The electric objects – quarks – gets heavier and more strongly coupled, while

![](_page_36_Figure_0.jpeg)

Figure 19:

the monopoles get lighter and less correlated: thus one should expect an equilibrium at some T, with dual language based on monopoles being simpler. A schematic phase diagram explaining these ideas is shown in Fig.19(top left). The main assumption is that plasma becomes magnetic-dominated at T above the deconfinement line, interpreted as a BEC transition of magnetic media.

In the beginning of this chapter we already defined the near- $T_c$  region as  $T/T_c = 0.8 - 1.2$ , based on the width of various "specific heat" peaks in static dipole energy. Recent lattice data [109] provided dramatic conformation of this scenario<sup>31</sup>. Fig.19(b) shows two sets of these data, and the correlation (and thus magnetic coupling) is indeed stronger at higher T. Furthermore, the correlation function for 50-50 mix of electric/magnetic plasma obtained in our Molecular Dynamics (MD) simulation Fig.19(c) has the same shape and magnitude, provided one compare at the same value of the magnetic plasma parameter  $\Gamma \equiv \alpha(magnetic)/(\frac{3}{4\pi n})^{1/3}/T$ : its extracted values are shown in Fig.19(d). It is very nice to find always  $\Gamma > 1$ , which means that magnetic component of sQGP is also liquid not gas, thus it does not spoil the "perfect liquid" at RHIC. One may further think that viscosity has a minimum where both electric quasiparticles (quarks) and magnetically ones (monopoles) have similar difficulty propagating. We infer from lattice data that such electric-magnetic equilibrium is at  $T \approx 1.5T_c$ , right in middle of the RHIC domain.

We already reviewed the main properties of lattice potentials in the previous chapter. A good starting

<sup>&</sup>lt;sup>31</sup>Even more recent lattice work by Meyer [110] have found liquid-like peaks in the correlators of the energy as well.

point for development of such a model is to think along the line of "dual superconductor" by t'Hooft-Mandelstamm [103]. If the QCD vacuum at T=0 contains some magnetically charged condensate, it will expel electric flux between  $\bar{Q}Q$  into a flux tube, analogous to the Abrikosov-Nielsen-Olesen (ANO) vertex.

An explanation of the linear rise of energy and entropy to very large values is due to persistence of a flux tubes even in the plasma deconfined phase. This point of view was proposed in [114] and was further developed in [116], for infinitely long flux tubes. In the latest paper [117] we extended the model to finite-distance potentials, by developing an analytic "elliptic flux-bag" model, with two static quarks at its focal points. Omitting all technical details, we will only present two main results for the tensions of "slow" and "fast" potentials. In the former case we obtained

$$\sqrt{\sigma_S} = 1.69 \times \alpha_E^{1/4} \times \mathcal{P}_M^{1/4} \tag{49}$$

and the saturated value of transverse radius to be

$$\mathcal{R}_S = 0.82 \times \alpha_E^{1/4} \times \mathcal{P}_M^{-1/4} \tag{50}$$

For "fast" potential, related to "normal" component of magnetic plasma, the corresponding results are

$$\sqrt{\sigma_F} = 2.94 \times \alpha_E^{1/6} \times n_M^{1/3} \tag{51}$$

and the saturated value of transverse radius to be

$$\mathcal{R}_F = 0.57 \times \alpha_E^{1/3} \times n_M^{-1/3} \tag{52}$$

Using these expressions and lattice potentials/tensions one can estimate the monopole density needed to produce the energy string tension at  $T_c$ ,  $\sigma_E(T_c) \approx 5.15\,\sigma_{vac}$ . From (51) we obtain the monopole density should be  $n_M(T_c) \approx 4.65 fm^{-3}$  assuming  $\alpha_E = 1$ , or  $n_M(T_c) \approx 6.58 fm^{-3}$  assuming  $\alpha_E = 0.5$ . This again is a reasonable number as compared to direct lattice observations. The transverse size is then  $\mathcal{R}_F \approx 0.34 fm$  for  $\alpha_E = 1$  and  $\mathcal{R}_F \approx 0.24 fm$  for  $\alpha_E = 0.5$ . The results are shown in Fig.20, for Bose condensed component (upper) and "normal" one (lower), the latter compared to lattice data on directly observed monopole paths (winding ones around time axis). We will return to these numbers at the summary of this chapter below.

### 4.2 Molecular dynamics for magnetic/electric plasmas

Gelman, Zahed and myself [5] proposed a classical model for the description of strongly interacting colored quasiparticles as a nonrelativistic Non-Abelian Coulomb gas. The sign and strength of the inter-particle interactions are fixed by the scalar product of their classical color vectors subject to Wong's equations. Details should be looked at the papers: let us just explain here its physical meaning. For SU(2) color group a color vector rotates around the direction of the total color field induced by all other particles at its position: same as magnetic moments would do in a magnetic field. For arbitrary group precession on a group is determined by the Poisson brackets of color vectors:  $\{Q^a, Q^b\} = f^{abc} Q^c$  which are classical analogue of the SU(N<sub>c</sub>) color commutators. Thus for arbitrary gauge group one should use its structure constants  $f^{abc}$  describing "precession" of the color vector.

For the non-Abelian group SU(2) the adjoint color vectors resign on a 3-d unit sphere: with one conserved quantity  $((Q^a)^2)$  it makes  $S^2$  or 2 degrees of freedom. For SU(3) the group has 8 dimensions: with two conserved combinations  $(Q^a)^2$ ,  $d^{abc}Q^aQ^bQ^c$  it is 6 d.o.f., and so on. Although color precession equations do not look like the usual canonical EoM for pairs of coordinates and momenta, they actually can be rewritten as pairs of conjugated variables, as can be shown via the so called Darboux

![](_page_38_Figure_0.jpeg)

Figure 20: (top left) free energy F (in unit of  $\alpha_E/l_C$ ) versus separation  $L/l_C$ ; (top right) monopole condensate energy density  $\mathcal{E}^{1/4}$  in unit of  $\sqrt{\sigma_{vac}}$ , the two curves are for  $\alpha_E$  being 0.5(upper) and 1(lower) respectively.

(down left) The potential energy V (in unit of  $\alpha_E/l_M$ ) versus separation  $L/l_M$ ; (down right) thermal monopole density  $n_M/T^3$ , the two curves across boxes are for  $\alpha_E$  being 0.5(upper) and 1(lower) respectively, and green curve across diamonds shows data for  $T > 1.3T_c$  from D'Elia and D'Alessandro.

parameterization. Thus one can even define the phase space and use all pertinent theorems related to its classical evolution, if needed.

The model can be studied using Molecular Dynamics (MD), which means solving numerically EoM for  $10^2-10^3$  particles. It displays strong correlations and various phases, as the Coulomb coupling is increased ranging from a gas, to a liquid, to a crystal with anti-ferromagnetic-like color ordering. There is no place for details here: so we simply jump to results on transport properties. In Fig.21 one can see the result for diffusion and viscosity vs coupling: note how different and nontrivial they are. When extrapolated to the sQGP suggest that the phase is liquid-like, with a diffusion constant  $D \approx 0.1/T$  and a bulk viscosity to entropy density ratio  $\eta/s \approx 1/3$ .

Transport properties for novel types of plasmas, including electric and magnetic charges, have been calculated by Liao and myself [114]: and  $\eta$  is indeed minimal for most symmetric mixture 50-50%. Before we turn to these results, let me qualitatively explain why in this case the diffusion/viscosity is maximally reduced. Imagine one of the particles - e.g. a quark. The Lorentz force makes it rotate around a magnetic field line, which brings it toward one of the nearest monopoles. Bouncing from it, quark will go along the line to an antimonopole, and then bounce back again: like electrons/ions do in

![](_page_39_Figure_0.jpeg)

Figure 21: The diffusion constant (a) and shear viscosity (b) as a function of the dimensionless coupling  $\Gamma$ . Three sets of data are for only electric particles (M00), with the quoter (M25) and the half (M50) particles being monopoles. Note the decrease in viscosity as the admixture of monopoles grows.

the so called "magnetic bottle" <sup>32</sup>. Thus in 50-50 mixture all particles can be trapped between their dual neighbors, so that the medium can only expand/flow collectively.

![](_page_39_Figure_3.jpeg)

Figure 22: Transport summary from [114]:  $Log[1/(\eta/s)]$  v.s.  $Log[1/(2\pi TD)]$  including results from our MD simulations, the AdS/CFT calculations, the weakly coupled CFT calculations, as compared with experimental values, see text.

Our MD results are shown on viscosity-diffusion plane in Fig.22 by three lines: they are compared to those from the AdS/CFT correspondence in weak and strong coupling as well as with empirical values from RHIC experiments (gray oval). The dashed curve in the left lower corner is for  $\mathcal{N}=4$  SUSY YM theory in weak coupling: , where viscosity for this theory in weak coupling is from [118] and diffusion constant from [119]. The curve has a slope of one on this plot, as in weak coupling both quantities are proportional to the same mean free path. These weak coupling results are quite far from empirical

<sup>&</sup>lt;sup>32</sup>By the way, invented in 1950's by one of my teachers G.Budker.

data from RHIC in the right upper corner. (Viscosity estimates follow from deviations of the elliptic flow at large p<sup>t</sup> from hydro predictions and diffusion constants are estimated from RAA and elliptic flow of charm .) The strong-coupling AdS/CFT results (viscosity according to [120] with O(λ −3/2 ) correction, diffusion constant from [121]) are represented by the upper dashed line, going right through the empirical region. Our MD results – three solid lines on the right – are close to the experiment as well, especially the version with the equal mixture of electric and magnetic particles.

#### 4.3 Bose condensation: from liquid He to monopole plasma

Classical approximation discussed above can explain many properties of liquids and solids, but it obviously ignores quantum effects<sup>33</sup>. It is well known that quantum effect at low temperatures may lead to qualitative changes in the system's behavior, such as superfluidity and superconductivity. A system of bosons may undergo Bose-Einstein condensation<sup>34</sup> (BEC). While for ideal gas BEC is a textbook material , it is a difficult problem for interacting systems. Liquid He<sup>4</sup> remained for a long time the only example and the relation between its superfluidity and BEC phenomenon was hotly debated and even denied in many classic works. The dilute atomic gases were finally cooled to BEC in 1990's, but those are weakly coupled and we would not discuss them.

Liquid He<sup>4</sup> problem became amenable to direct numerical attack in 1980's, when simulation of the Feynman path integral via Monte Carlo algorithms was finally technically possible. Such first-principle approach was a success: see e.g. Ceperley's review [125]. After that, other systems were studied, filling the gap between weakly coupled gases and liquid He<sup>4</sup> . And yet when we studied this literature – trying to understand conditions for BEC of the monopoles –it still looked that the net was not cast wide enough and many general questions remained open. To name one particular example, such question of principle – whether solid He<sup>4</sup> is a supersolid at T = 0, and if not why and whether a bit different atomic potentials may still produce it.

One of the first applications of the path integral method by Feynman himself were aimed at explanation of the He<sup>4</sup> λ-point. His classical papers [123, 124] introduced the idea of "polygon clusters". Starting from some configuration of particles at Euclidean time τ = 0, Feynman identifies such clusters as a group of atoms which exchange places during the Matsubara time τ = β = ¯h/T. The polygons of course in principle may have any shape, but since a minimal additional action for "jumping" atoms be required, the most probable paths are those where particles interchange places with their nearestneighbors and thus the most probable jumps have length of one interparticle distance. And yet, the polygons themselves need not be small: as Feynman shown BEC implies that there should be infinitely large cluster. Furthermore, the BEC transition temperature can be defined as such T at which the series over infinitely long polygons start to be divergent. And, since the number of polygons grow with its length in a certain geometrical way, one may argue that there should be universal action per "jumping" particle ∆S ∗ corresponding to all BEC transitions.

Feynman's main approximation was the estimate of ∆S <sup>∗</sup> using kinetic energy only, ignoring the potential one. He motivated by "rapid particle rearrangements" and wrote the thermal partition function in the form

$$Z = e^{-\frac{F}{T}} = \frac{1}{N} \sum_{P} \int \left(\frac{m^*T}{2\pi\hbar}\right)^{3N/2} \exp\left[-\frac{m^*T}{\hbar^2} \sum_{i} (\underline{R}_i - P\underline{R}_i)^2\right] \rho(\underline{R}_1 ... \underline{R}_N) d^3\underline{R}_1 ... d^3\underline{R}_N$$
 (53)

where exponent comes from "jumps" done in a straight lines and containing corresponding action related to kinetic energy. To correct for potential energy somehow, Feynman introduced an "effective mass of a He atom" m<sup>∗</sup> . The sum is done over permutation P of the particle coordinates, the function ρ includes

<sup>33</sup>Some of quantum effects can be put into effective potential, see e.g. recent dedicated study related to charm quarks in sQGP [122].

<sup>34</sup>In fact "Bose-Einstein" statistics is due entirely to Bose while condensation entirely to Einstein.

![](_page_41_Figure_0.jpeg)

Figure 23: Total extra action for "jumping" He4 atoms as a function of the temperature.

effects of the interparticle interactions. His main idea was that the function ρ can be inferred from general properties of the liquid (or solid), its quasi-ordered local structure with peaked distribution over interparticle distances at some nearest-neighbor value d (in the case of cubic lattice d is the lattice spacing).

The relative amplitude of a term with permutation of n atoms is thus proportional to the n-th power of the "jump amplitude"

$$y_F = exp(-\Delta S) = \exp\left[-\frac{m^*Td^2}{2\hbar^2}\right]$$
 (54)

which should at the transition point be exactly compensated the divergence of the combinatorial prefactors, describing a number of corresponding to non-crossing polygons on the corresponding 3d lattices. Feynman estimated that he expected the critical value to be in the range y<sup>c</sup> = 1/4 – 1/3. Kikuchi et al. [127] have argued that the critical action should be S<sup>c</sup> ≈ 1.9, but later studies in the eighties such as by Elser [129] determined numerically that the critical action is smaller S<sup>c</sup> ≈ 1.44.

Let us see what critical temperature for He would follow from those actions, in Feynman approximation. We consider the distance d of a "jump" being fixed to the position of the nearest neighbor maximum in the static correlation function g(r) for liquid He, which is d ≈ 0.35 nm . Kikuchi's critical action with the unmodified He mass leads to T<sup>c</sup> = 3.57K while Elser's to T<sup>c</sup> = 2.72K, still well above the correct position of the λ-point T<sup>c</sup> = 2.17K.

Cristoforetti and myself [130] have tried to generalize Feynman criterion for interacting gases by including the potential energy effect "jumps" and their actions. We have used two approaches, (i) a semiclassical one, in which the path is found by minimizing classical equation of motion and the action given by this "instanton"; and (ii) numerical one, simulating path integral for a "jumping" particle in the potential created by "non-jumping" particles in the background.

The setting for the calculation can be described as follows: imagine Helium atoms filling the bestpacking lattice and consider all atoms to be non-jumping except of atoms in one raw of the lattice which are all "jumping" coherently by one step in the same direction. This is a good approximation because one should consider a very large polygon with infinite number of atoms. We found that many different systems, from He atoms to Coulomb systems<sup>35</sup> have effective potentials for jump which can be quite accurately be represented by universal periodic potential with only one harmonics V ∼ cos(πx/a). It is simple to find the instanton path for this potential and its action. It improves substantially Feynman estimate, but since the value of the critical action (∼ 1.5) is not really large, semiclassical estimates cannot be very accurate here and have mostly pedagogical value.

In fact it is not difficult to perform numerical evaluation of the ratio of two path integrals, for "jumping" to "periodic" paths can be performed numerically: in this way also quantum fluctuation around the classical trajectory are taken into account. These calculations are very cheap in terms of computational power because we have a system with only one particle. We have done so for different values of the temperature, the result is presented in Fig. 23. The value of the jump action at T<sup>c</sup> = 2.17K is S<sup>c</sup> = 1.48, which is very close to the value S<sup>c</sup> ≈ 1.44 computed in [129] using the combinatorial method<sup>36</sup> .

Solid He is a bit denser than liquid, and thus its action never reaches S<sup>c</sup> ≈ 1.44: thus – from the viewpoint of this criterion – it seems never become a "supersolid". (The experimental situation is complicated with conflicting experiments about rotating solid He at very low T.)

Let us now return to QCD near-T<sup>c</sup> region. Before we return to our monopole, let me mentioned one school of thought (from [132] to [131]) who think differently about confinement, putting 2d objects – vortices – as a primary objects randomizing the vacuum fields and leading to the area law for the Wilson loop. If so, the vacuum should have a condensate of vortices, which are after all also bosonic objects. However to my knowledge neither the order parameter – resembling Pisa one for monopoles – have been constructed, nor there is any understanding how one can address the issue of BEC for such objects, whose worldvolumes are 2-dimensional.

The monopoles, on the other hand, are particles, and the Feynman criterion ( S = S <sup>∗</sup> at T = Tc) discussed above should be applicable. Let us use it a la Feynman, using only kinetic energy first. The motion of the monopole which tries to occupy the position of another identical monopole at distance a away during the Matsubara time β = ¯h/T = 1/(.27 GeV ) = .73 fm is relativistic, with the (Euclidean) velocity on the straight path v = a/β. Since we speak about tunneling, having imaginary action and velocity > 1 is in fact quite appropriate; no negative roots should appear. The Euclidean relativistic action is just the length of the path

$$S_E = iS_M = im \int ds = m\beta \sqrt{1 + a^2/\beta^2}$$

$$\tag{55}$$

should be S <sup>∗</sup> ≈ 1.44 at T = Tc. Since we know the monopole density (and thus a) and Tc, we can use this criterion to estimate the effective monopole mass: this sets it in the range m = (0.2−0.3)GeV . Putting Coulombic repulsion and monopoles into appropriate cubic lattice, one can get sinusoidal potential for jumps and evaluate semiclassically or numerically the action for a "jump" more accurately.

Since in principle lattice data on the whole path integrals of monopoles is known, in the future one should be able to learn the effective monopole masses and interactions in the near-T<sup>c</sup> region and verify the details of their Bose-Einstein condensation.

### 4.4 Summary of the magnetic scenario in the near-T<sup>c</sup> QGP

The main conclusion of this section is that lattice monopole-like singularities — located via endpoints of the Dirac strings in certain gauges such as maximal abelian gauge – are found to behave as physical particles. Their density is independent of the lattice details. The extracted magnetic coupling grows with T, exactly as expected. Their spatial correlation functions agree with the idea that their ensemble

<sup>35</sup>Let me remind the reader that below we hope to use this criterion of confinement for monopole plasma.

<sup>36</sup>The figure clearly shown a minimum at T = 1.94 K and then grows again but presumably the Feynman argument cannot be used at T < Tc.

is just a strongly coupled liquid driven essentially by the magnetic Coulomb interaction: they are quantitatively reproduced by simple classical MD. In addition, the transport properties of such a magnetic plasma is in agreement with heavy ion phenomenology.

But we don't yet know many important parameters, such as e.g. the masses of all quasiparticles involved. Current understanding of those masses is vague, the only direct lattice measurements have been done at T = 1.5T<sup>c</sup> and 3T<sup>c</sup> for quarks and gluons in [133], both masses are about equal and M ≈ .6 − .8GeV at both T. Let us assume that they are the same at T<sup>c</sup> as well.

We now proceed to self-dual dyons, a components of finite-T instantons. The mass is derived from the instanton action

$$M_{dyons} = T(\frac{8\pi^2}{g^2 N_c}) \sim 4T_c \sim 1 \, GeV \tag{56}$$

where we used a typical instanton action to be around 12. Their density (for all N<sup>c</sup> types together) can also be estimated from lattice data on instantons

$$n_{dyons} \sim \frac{n_{inst}}{TN_c} \sim 2 fm^3 \tag{57}$$

So, although the dyon density is not negligible, it is not peaking near T<sup>c</sup> and is few times smaller than that of monopoles.

The monopole density numbers from Figures above does peak at Tc, indicating that they do play significant role in confinement. It is numerically very high – in absolute numbers it is about

$$n_{mono}(T = T_c) \sim 10 fm^{-3}$$
 (58)

This is larger than Bose gas of non-interacting bosons even with zero mass, but for strongly correlated liquid this is probably possible. Hopefully, the estimate of the monopole mass from the Feynman's Bose condensation criterion mmono = (0.2 − 0.3)GeV will also work out. At the moment, all we know about magnetic plasma is its density and magnetic coupling. Those have been combined into Gamma parameter in the Fig.19 (down right) with a conclusion that it is always above 1, so we do have a magnetic liquid.

As explained above, we had classical MD simulations which lead to reasonable diffusion and viscosity of such plasmas: and a 50-50 mixture of electric and magnetic particles (occurring somewhere at T ≈ 1.5Tc) is probably the optimal point for the lowest viscosity. How classical effects will modify these numbers we do not know yet.

### 5 AdS/CFT duality

AdS/CFT correspondence [134] is a duality between specific gauge theory known as N =4 super-Yang-Mills theory (SYM) in 4 dimensions and the (10-dimensional) superstring theory in a specific setting. Before we describe the results obtained, here is a brief introduction, explaining its logic and what all these words mean aiming at non-experts. Those who know it may skip two next subsections.

### 5.1 Black holes and AdS/CFT for pedestrians

For applications we have in mind the most important feature of string theories is the existence of massless modes of closed strings, which include spin-2 "gravitons" as well as lower spin members of the multiplet, including vectors and scalars. String theory thus has aspiration to be "theory of everything" combining gauge and gravity interactions known in nature. This aspect of it is not discussed in this paper at all: all of these "bulk" fields in 10 dimensions will only play a role to mimic 4-dimensional QCD-like gauge theories.

One of several "string theory revolutions" of 1990's was caused by a discovery of solitonic objects of (nearly) any dimensions p (ranging p = -1 - 9) called  $D_p$  branes. One should think of them as some p-dimensional membranes, solitons made of strings and embedded in 9+1 dimensions of space+time. For our purposes the most important example is the  $D_3$  brane which has infinite extension in 3 coordinates  $x_1, x_2, x_3$ , while it has no extension (and thus is just a point object) in the remaining 6 coordinates  $x_4...x_9$ .

Since branes are material objects with certain masses and charges, they create gravity/Coulomb/scalar fields around them in the bulk, like planets and stars do. As they have no extension in some coordinates (e.g. just mentioned  $x_4...x_9$  coordinates for  $D_3$  brane), their fields are that of a point objects: in general relativity this naturally implies that they are black hole-like in such coordinates. As they are extended in other coordinates, the proper name of such objects is black branes. To find out their properties in classical (no loops or quantum fluctuations) approximation, one has to solve coupled Einstein-Maxwell-Scalar eqns, looking for static spherically symmetric solutions. This is no more difficult than to find the Schwartzschild solution for the usual black hole, which we remind has a metric tensor in spherical coordinates

$$ds^{2} = g_{\mu\nu}dx^{\mu}dx^{\nu} = -(1 - r_{h}/r)dt^{2} + \frac{dr^{2}}{(1 - r_{h}/r)} + r^{2}d\Omega^{2}$$
(59)

and the horizon radius (in full units) is  $r_h = 2G_N M/c^2$ , containing the mass M and Newton constant  $G_N$ . The horizon – zero of  $g_{00}$  – is the "event horizon": a distant observer cannot see beyond it. (There  $g_{00}, g_{rr}$  change sign.) Similar expressions, with appropriate powers of the distance can be derived for p-branes.

Note that at large distance  $r \ll r_h$  deviations from flat metrics is a small correction – there the nonrelativistic potential description of Newtonian gravity is possible. Similarly far from a brane the fields are just given by Newton+Coulomb+scalar formulae in corresponding dimensions, and it is not hard to figure out what are their mutual interactions. Surprising (to anyone not involved in monopoles/supersymmetry research) the answer is that all these forces mutually cancels out, so there is no interactions between branes –they are so called BPS protected objects. As a result, a "brane engineer" may consider a number of parallel branes to be put at some random points: and they will stay there. Large  $(N_c \to \infty)$  number of branes put into the same point combine their mass and thus create strong gravity field, justifying the use of classical Einstein/Maxwell eqns. Open string states, which keep their ends on some branes i and j lead to effective gauge theory on the brane with the  $U(N_c)$  group.

When the black hole has a nonzero vector charge, the Gauss' law insists on constant flux through sphere of any radius, thus there are nonzero fields at large r and Schwartzschild solution gets modified into a "charged black hole". For asymptotically flat spaces there is the famous statement, much emphasized by Wheeler: there are "no scalar hairs" of black holes, as there is no Gauss theorem to protect them. This happens to be not true in general, and for spaces which are AdS-like thus scalars should not be left over<sup>37</sup>.

The solution for  $D_3$  brane happens to be the so called *extremal* (6-dimensional) charged black hole, which has the lowest possible mass for a given charge. When the mass decreases to the extreme value, the horizon shrinks to nothing, and thus it is especially simple. Spherical symmetry in 6d allows one to separate the 5 angles (making the 5-dim sphere  $S_5$ ) from the radius r (in 6-dimensions orthogonal to "our world" space  $x_1, x-2, x-3$ ) and write the resulting 10-d metrics as follows

$$ds^{2} = \frac{-dt^{2} + dx_{1}^{2} + dx_{2}^{2} + dx_{3}^{2}}{\sqrt{1 + L^{4}/r^{4}}} + \sqrt{1 + L^{4}/r^{4}}(dr^{2} + r^{2}d\Omega_{5}^{2})$$
(60)

<sup>&</sup>lt;sup>37</sup>In fact there is a whole recent direction based on solution with a "scalar atmosphere" around black branes, providing gravity dual to superconductors on the boundary.

Again, at large r all corrections are small and we have the asymptotically flat space there. However at this point Maldecena told us to use instead further simplified version of this metric, in the "near-horizon region" at r << L, when 1 in the roots can be ignored. If so, in the last term two  $r^2$  cancels out and the 5-dimensional sphere element gets constant coefficient and thus gets decoupled from 5 other coordinates. Thus quantum numbers or motion in  $S^5$  becomes kind of internal quantum numbers like flavor in QCD, and it will be mostly ignored from now on. What is left is very simple 5-dimensional metric known as Anti-de-Sitter metric. Using a new coordinate  $z = L^2/r$  we get it into the "standard  $AdS_5$  form" used below:

$$ds^{2} = \frac{-dt^{2} + dx_{1}^{2} + dx_{2}^{2} + dx_{3}^{2} + dz^{2}}{z^{2}}$$

$$(61)$$

Note that z counts the distance from "the AdS boundary" z=0. This metric has no scale and is not asymptotically flat even at the boundary. Performing dilatation on these 5 coordinates we find that the metric remains invariant: in fact one can do any conformal transformation. It is this metric which is AdS in the AdS/CFT correspondence, and string theory in this background is "holographically gravity dual" to some conformal gauge theory at the boundary.

So far nothing unusual happened: all formulae came straight from string and general relativity textbooks. A truly remarkable theoretical discovery is the so called "holography": the exact duality (one-to-one correspondence) between the 5-dim "bulk" effective theory in  $AdS_5$  to 4-dim "boundary"  $(r \to \infty)$  gauge theory. There is a dictionary, relating any observable in the gauge theory to another one in string theory: the duality implies that all answers are the same in both formulations. We will see below how it works "by examples".

The last step, which makes it useful, is the Maldacena relations between the gauge coupling, the AdS radius L and the string tension  $\alpha'$  (which comes from the total mass of the brane set):

$$L^4 = g^2 N_c(\alpha')^2 = \lambda(\alpha')^2 \tag{62}$$

It tells us that large gauge coupling  $\lambda >> 1$  corresponds to large AdS radius (in string units) and one can use classical (rather than quantum) gravity. At the same time the string and gravity couplings  $g_s \sim g^2$  may remain small: so one may do perturbative calculations in the bulk!

At this point many readers are probably very confused by new 5-th dimension of space. One possible approach is to think of it as just a mathematical trick, somewhat analogous to more familiar introduction of the complex variables.

(Suppose an Experimentalist measured some complicated cross section which is approximately a sum of Breit-Wigner resonances. His friend Phenomenologist may be able to write the answer as an analytic function with certain pole singularities in the complex energy plane, which will help for fitting and for evaluating integrals. Even better, their other friend Theorist cleverly developed a "bulk theory", deriving the pole positions from some interaction laws on the complex plane.)

However, there is a perfectly physical meaning of the 5-th coordinate. One hint is provided by the fact that distance along it  $\int_a^b dl = \int_a^b dz/z = \log(b/a)$  is the logarithm of the ratio. Thus its meaning is the "scale", the argument of the renormalization group. If one takes a bulk object and move it into larger z, its hologram at the boundary (z=0) grows in size: this direction thus corresponds to the infrared direction. The running coupling constant would thus be a z-dependent field called "dilaton". Indeed, there are theories with gravity dual, in which this field (related to the coupling) does "run" in z:unfortunately, known examples do not (yet?) include QCD! In spite of that, there are efforts to built its gravity dual "bottom-up", introducing weak coupling at ultraviolet (small z) [139] and confinement in infrared (large z) [140, 141] by certain modification of the rules. These approaches – known as AdS/QCD– we would not discuss in this review, except briefly in the subsection on bulk viscosity.

Let me briefly remind few more facts from the Black Hole toolbox. Studies of how quantum field theory can sit in a background of a classical black hole metrics have resulted in two major discoveries:

the Hawking radiation and the Bekenshtein entropy, related to horizon radius and area, respectively. Hawking radiation makes black holes in asymptotically flat space unstable: it and heats the Universe till the black hole disappears. Putting black hole into a finite box also does not help: it is generically thermodynamically unstable and gets smaller and hotter till it finally burns out. Only in appropriate curved spaces black branes can be in thermal equilibrium with their "Universe", filled with radiation at some finite temperature T. As shown by Witten, all one has to do to get its metric is to consider non-extreme (excited extreme) black brane solution, which has a horizon.

Let me now make a logical jump and instead of just giving the metric for finite-T solution let me first provide an "intuitive picture" for non-experts, explaining the finite-temperature Witten's settings in which most<sup>38</sup> pertinent calculations are done, shown in Fig.25. The upper rectangle is the 3-dimensional space boundary z=0 (only 2 dim shown), which is flat (Minkowskian) and corresponds to "our world" where the gauge theory lives. Lower black rectangles (reduced in area because of curvature induced by 1/z<sup>2</sup> in metric) is the corresponding (same in x − 1, x − 2, x − 3) patch of the horizon (at z = zh) of a black hole, whose center is located at z = ∞. Studies of finite-T conformal plasma by AdS/CFT famously started exactly by evaluation of the Bekenstein entropy [138], S = A/4 via calculating the horizon area A.

Now comes the promised "intuitive picture": this setting can be seen as a swimming pool, with the gauge theory (and us, to be referred below as "distant observers") living on its surface, at zero depth z = 0, enjoying the desired temperature T. In order to achieve that, the pool's bottom looks inf initely hot for observers which are sitting at some fixed z close to its coordinate zh: thus diving to such depth is not recommended. Strong gravity takes care and stabilizes this setting thermodynamically: recall that time units, as well as those of energy and temperature are subject to "warping" with g<sup>00</sup> component of the metric, which vanishes at zh.

When astronomers found evidences for black holes and accretion into those, the physics of black hole became a regular part of physics since lots of problem have to be solved. Here important step forward was the so called membrane paradigm developed by many people and best formulated by Thorne and collaborators [136], known also under the name of "stretched horizons". Its main idea is to imagine that there is a physical membrane at some small distance away from the horizon, and that it has properties exactly such that all the eqns (Maxwell's, Einstein's etc) would have the same solutions outside it as without a membrane but with a continuation through horizon. For example, a charged black hole would have a membrane with a nonzero charge density, to terminate the electric field lines. The fact that Poynting vector at the membrane must be pointed inward means some (time-odd!) relation between E~ and B~ : this is achieved by giving the membrane finite conductivity, which in turn leads to ohmic losses, heat and entropy generation in it. Furthermore, as shown by Damour back in 1980's, displacements of the membrane and relations for gravitational analog of the Poynting vector leads to nonzero viscosity of the membrane, and its effective low frequency theory take the form of Navier-Stokes hydrodynamics. For a bit more modern derivations of the effective action and field theory point of view look at Parikh nd Wilczek [137]. As we will see below in this chapter, all of those ideas have resurfaced now in AdS context, generating new energy of young string theorists who now pushed the "hydrodynamics of the horizon memebrane" well beyond the Navier-Stokes to a regular construction of systematic derivative expansions to any needed order.

#### 5.2 CFT for pedestrians

The N =4 SYM theory is a cousin of QCD: it also has gauge fields with SU(Nc) color symmetry, but instead of quarks it has four "flavors" of fermions called gluinoes, as their adjoint colors are the same

<sup>38</sup>The exception is heavy quark diffusion constant calculated by Casalderrey and Teaney[121] which needs more complicated settings, with a Kruskal metric connecting a World to an Anti-world through the black hole.

as for gluons. There are also 6 adjoint scalars: with 2 polarizations of gluons it makes 8 bosonic modes, same as 2\*4 fermions. This makes supersymmetry possible and leads to cancellations of power divergences. This theory is the most symmetric theory possible in 4 dimensions: it has conformal symmetry and its coupling does not run!

How do we know this? Of course, one had calculated first few perturbative coefficients of the beta function, and indeed see that negative gauge contribution is nicely canceled by fermions and scalars, order by order. But there are infinitely many coefficients, and one has to check them all! An elegant way to prove the case is based on another outstanding feature of the N =4 SYM: this theory is self − dual under electric-magnetic duality. As we discussed above, the Dirac condition requires the product of electric and magnetic couplings to be constant: and so in QCD and other gauge theories they indeed run in the opposite directions, electric becoming weak in ultraviolet and magnetic weak in infrared. But the multiplet of (lowest) magnetic objects of the N =4 SYM theory include 6 scalars (the monopoles), plus 4 fermions (monopoles plus one gluino zero mode occupied), plus 2 spin-1 (monopoles with 2 gluinoes): this turns out to be exactly the same set of states as the original electric degrees of freedom (gluons-gluinoes-Higgses). That means that an effective magnetic theory has the same Lagrangian as the original electric formulation: thus it must have the same beta function. Since two couplings cannot run in the opposite direction following the same beta function, they cannot run at all!)

Recall that in QCD-like theories the scale ΛQCD came about because of running coupling. If in the N =4 SYM theory the coupling constant does not run, it means that there is no analog of ΛQCD in this theory, and since all the fields are massless and all the coupling dimensionless, thus the N =4 SYM theory has no scale at all. It is thus conformal field theory – the CFT in the AdS/CFT correspondence. One consequence is that the finite-T version of this theory (we will be mostly interested in) is the same whether T is large or small, since there is no other scale to compare with! This is similar to QCD plasma in the so called "quasi-conformal regime": at high enough T > 2T<sup>c</sup> all dimensionless ratios like (energy density)/T <sup>4</sup> are practically T-independent.

Weakly coupled N =4 SYM theory can be studied perturbatively, like any other gauge theory. What makes it unique is that AdS/CFT correspondence allows also to study it in the strong coupling limit, defined by a large value of the so called 't Hooft coupling, a combination of gauge coupling and number of colors which go together

$$\lambda = g^2 N_c >> 1 \tag{63}$$

It is this combination which appears in physical effects, e.g. the Coulomb law. Thus, before we embark on studies of strong coupling regime λ >>!, the reader have all reason to say: wait a moment, is it not followed from Klein-Gordon (or Dirac) eqns that for coupling larger than something two charges will fall at each other, as the square of the Coulomb potential ∼ λ <sup>2</sup>/r<sup>2</sup> will dominate the centrifugal term l(l + 1)/r<sup>2</sup> ? Zahed and myself [142] worried about this, and their semiclassical approach to density of charge was even used later by Klebanov, Maldacena and Thorn [143]. When the spectrum of heavy quarkonia was eventually found from AdS/CFT, all states including the lowest s-wave ones were accounted for – they have small but positive masses, and string theorists were not surprised. But frankly I still don't understand why no falling actually happens. This is one of many puzzles which shows that what can be derived from gravity side may be very hard to understand in the gauge theory.

### 5.3 The first example of AdS/CFT at work: new Coulomb law

Let me start with our first example of the "AdS/CFT at work", related with the strong-coupling version of the Coulomb law calculated in [135]. The setting– to be called "the Maldecena dipole" – is shown in Fig.24(a), includes two static charges (heavy fundamental quarks) separated by the distance R.

At weak coupling – the usual QED – we think of one charge creating the electric potential in which

the other is placed, leading to the usual Coulomb law which in our notation is

$$V(L) = -\frac{g^2}{4\pi L} \tag{64}$$

is a sum of two Coulomb fields.

$$E_m(y) = \left(\frac{g}{4\pi}\right) \left(\frac{y_m - (L/2)e_m}{|y_m - (L/2)e_m|^3} - \frac{y_m + (L/2)e_m}{|y_m + (L/2)e_m|^3}\right)$$
(65)

Because of a cancellation between two terms, at large distances from the dipole the field decays as  $E \sim L/y^3$ . The corresponding energy density (and other components of the stress tensor) are thus of the order  $T_{00} \sim g^2 L^2/y^6$ , with certain "dipole" angular distribution.

In the  $\mathcal{N}=4$  theory at weak coupling the only difference is that one can exchange massless scalars on top of gluons. It is always attractive, and for two heavy quarks leads to cancellation of the force, with doubling for quark-antiquark (we discuss now). The QED coupling  $g^2$  changes to 't Hooft coupling  $\lambda = g^2 N_c$  proportional to the number of colors  $N_c$ .

Now we turn to the AdS/CFT for the  $\mathcal{N}=4$  theory at strong coupling [144, 145]. The electric flux in the bulk forms a singular object – the string (shown by the solid curve in Fig.24(a)) – which pends from the boundary z=0 due to gravity force into the 5-th dimension, like in the famous catenary (chain) problem<sup>39</sup>. The calculation thus follows from Nambu-Goto action for the string, whose general form is

$$S = \frac{1}{2\pi\alpha'} \int d\sigma d\tau \sqrt{\det G_{MN} \partial_{\alpha} X^{M} \partial_{\beta} X^{N}}$$
 (66)

where 2 coordinates  $\sigma$ ,  $\tau$  parameterize the string world line  $X^M(\tau, \sigma)$ , where M, N are space-time indices in the whole space (10dim reduced to 5d in AdS/CFT).  $G_{MN}$  is the space metric and det stands for 2\*2 matrix with all  $\alpha, \beta$ . In the  $AdS_5$  metric we need the components  $-G_{00} = G_{11} = G_{55} = 1/z^2$ , and we can think of  $\sigma, \tau$  as our coordinates x, t: the string is then described by only one function z(t, x) and its action is reduced to

$$S \sim \int dt dx \frac{1}{z^2} \sqrt{1 + (\partial z/\partial x)^2 - (\partial z/\partial t)^2}$$
 (67)

We will use this action for "falling strings" below, and now proceed to further simplifications for static string, for which there is no time derivative and the function is z(x). Maldacena uses u(x) = 1/z(x) and thus the Lagrangian becomes  $L = \sqrt{(u_{,x})^2 + u^4}$  with comma meaning the x- derivative. One more simplification comes from the fact that x does not appear in it: thus an "energy" is conserved

$$H = p\dot{q} - L = \frac{\partial L}{u_{,x}}u_{,x} - L = E = const \tag{68}$$

which reduces the EOM from second order eqn to just  $(u_{,x})^2 = u^4(u^4/E^2 - 1)$  which can finally be directly integrated to

$$x(u) = \int_{u_m}^{u} \frac{du'}{(u')^2 \sqrt{(u')^4 / E^2 - 1}}$$
(69)

The minimum position of the string  $u_m$  is related to E by the relation following from this formula at x = L/2. Plugging the solution back into action and removing divergence (which is independent of L) gives finally the total string energy, which is the celebrated new Coulomb law at strong coupling

$$V(L) = -\frac{4\pi^2}{\Gamma(1/4)^4} \frac{\sqrt{\lambda}}{L} \tag{70}$$

<sup>&</sup>lt;sup>39</sup>Another – more Einsteinian –way to explain it is to note that this is simply the shortest string possible: it is not straight because the space is curved. It is the same reason why the shortest path from New York to London does not look straight on the map.

The power of distance 1/L is in fact the only one possible by dimension, as the theory is conformal and has no scales of its own. What is remarkable is the (now famous) <sup>√</sup> λ appearing instead of λ in the weak coupling. (The numerical coefficient in the first bracket is 0.228, to be compared to the result from a diagrammatic re-summation below.)

What is the reason for this modification? For pedagogical reasons let me start with two "naive but reasonable guesses", both to be shown to be wrong later in this section:

- (i) One idea is that strongly coupled vacuum acts like some kind of a space-independent dielectric constant, ∼ 1/ √ λ which is reducing the effect of the Coulomb field, similarly at all points.
- (ii) Perhaps such dielectric constant has nonlinear effects, and thus is not the same at different points: but the fields created by static dipole are still just the electric field E~ .

A good feature of the AdS/CFT is that one can get many further details about the problem and test ideas like just expressed: but we cannot get all features. In order to understand the difference between dipole fields in a weakly and strongly regimes it be nice to calculate the electric and the scalar field distributions in both limits. Unfortunately we cannot do that: those fields do not belong to limited set of quantities one can calculate via AdS/CFT correspondence. In general AdS/CFT rules allows one to find holograms on the boundary of whatever happens in the bulk. This can be done by solving bulk wave eqns for massless bulk fields - which are scalars, vectors or gravitons. For example I will give our results for boundary stress tensor obtained from the (linearized) Einstein equation for the gravity perturbations, shown by the dashed line in Fig.24(a).

For example, in (relatively recent) paper Lin and myself [146] have found the stress tensor of matter < Tµν(y) > at any point y on the boundary, induced by the Maldacena dipole. The solution is too technical to be presented here and even the resulting stress tensor expression is too long<sup>40</sup>: let me just show only the leading terms far from the dipole y >> L.

$$T_{00} = \sqrt{\lambda} L^3 \left( \frac{C_1 y_1^2 + C_2 y^2}{|y|^9} \right) f(\theta)$$
 (71)

where C1, C<sup>2</sup> are numerical constants whose values can be looked up in the paper and f(θ) is the angular distribution shown by solid line in Fig.24(b), quite different that in weak coupling (the dashed line). Note that in weak coupling the energy density from the dipole is just electric field (65) squared, leading to a different power T<sup>00</sup> ∼ λL<sup>2</sup>/y<sup>6</sup> .

As we get glimpse of some first results from AdS/CFT we see that they are quite different from weak coupling and we would like to understand them. In fact we would like to do so both from the bulk (gravity) side as well as from the gauge theory side. It turns out the first is relatively easy. For example, both in the total energy and energy density we get <sup>√</sup> λ because this factor is in front of the Nambu-Goto Lagrangian (in proper units). The reason the field decays as y 7 is extremely natural: in the AdS<sup>5</sup> space the function which inverts the Laplacean (analogously to Coulomb 1/r in flat 3d) has that very power of distance

$$P_s = \frac{15}{4\pi} \frac{z^2}{(z^2 + r^2)^{\frac{7}{2}}} \tag{72}$$

with z being the 5-th coordinate of the source and r the 3-distance between it and the observation point<sup>41</sup> .

In order to understand the same results from the gauge side we will need a bit of pedagogical introduction: the resolution will be given by the idea of short color correlation time by Zahed and

<sup>40</sup>By he way, the stress tensor should always be traceless in conformal theory and have zero divergence: those conditions are used to verify explicitly that no mistake in the calculation was made.

<sup>41</sup>Please recall that in gravity there are no cancellations between different contributions: any energy source perturbs gravity with the same sign.

![](_page_50_Figure_0.jpeg)

![](_page_50_Figure_1.jpeg)

Figure 24: Setting of the Maldacena dipole: two charges at the boundary (black dots) are connected by the string (shown by solid curve) pending under gravity toward the AdS center z → ∞. Classical graviton propagator (the dashed line) should be used to calculate the "hologram" – the stress tensor at the observation point y. The string is the gravity source; the point A has to be integrated over. (b) Angular distribution of the far field energy versus the polar angle (cos(θ) = y1/|y|). Solid black line is the AdS.CFT result, compared to the perturbative dipole energy (3cos<sup>2</sup> θ + 1)/4 (the dashed blue line), both normalized at zero angle.

myself [142]. In QCD, with its running coupling, higher-order effects modify the zeroth order Coulomb field/potential. Since we consider static problem, one can rotate time into Euclidean time τ = it, which not only makes possible lattice simulations but also simplifies perturbative diagrams. Let us do Feynman diagrams directly in the coordinate representation. The lowest order energy, given by the diagram in which one massless quantum (scalar or gauge component A0) is emitted by one charge at time τ<sup>1</sup> and absorbed by another at time τ<sup>2</sup> is just

$$V(L)(Time) \sim -g^2 \int_0^{Time} \frac{d\tau_1 d\tau_2}{L^2 + (\tau_1 - \tau_2)^2} \sim -\frac{g^2(Time)}{L}$$
 (73)

where 'Time' is total integration time and the denominator – the square of the 4-dim distance between gluon emission and absorption represents the Feynman propagator in Euclidean space-time. The propagation time for a virtual quantum (τ<sup>1</sup> − τ2) ∼ L, thus the Coulomb 1/L in the potential.

Higher order diagrams include self-coupling of gluons/scalars and multiple interactions with the charges. A famous simplification proposed by 't Hooft is the large number of colors limit in which only planar diagrams should be considered. People suggested that as g grows those diagrams are becoming "fishnets" with smaller and smaller holes, converging to a "membrane" or string worldline: but although this idea was fueling decades of studies trying to cast gauge theory into stringy form it have not strictly speaking succeeded. It may still be true: just nobody was smart enough to sum up all planar diagrams<sup>42</sup> .

If one does not want to give up on re-summation idea, one may consider a subset of those – the ladders – which can be summed up. Semenoff and Zarembo [148] have done that: let us look what have they found. The first point is that in order that each rung of the ladder contributes a factor Nc, emission time ordering should be strictly enforced, on each charge; let us call these time moments s<sup>1</sup> > s<sup>2</sup> > s3... and t<sup>1</sup> > t<sup>2</sup> > t3.... Ladder diagrams must connect s<sup>1</sup> to t1, etc, otherwise it is nonplanar and subleading diagram. Thus the main difference from the Abelian theory comes from the dynamics of the color vector. The (re-summed) Bethe-Salpeter kernel Γ(s, t), describing the evolution from time

<sup>42</sup>Well, AdS/CFT is kind of a solution, actually, but it is doing it indirectly.

zero to times s, t at two lines, satisfies the following integral equation

$$\Gamma(\mathcal{S}, \mathcal{T}) = 1 + \frac{\lambda}{4\pi^2} \int_0^{\mathcal{S}} ds \int_0^{\mathcal{T}} dt \frac{1}{(s-t)^2 + L^2} \Gamma(s, t)$$
(74)

If this eqn is solved, one gets re-summation of all the ladder diagram. The kernel obviously satisfies the boundary condition  $\Gamma(S,0) = \Gamma(0,T) = 1$ . If the equation is solved, the ladder-generated potential is

$$V_{\text{lad}}(L) = -\lim_{T \to +\infty} \frac{1}{T} \Gamma(T, T) , \qquad (75)$$

In weak coupling  $\Gamma \approx 1$  and the integral on the rhs is easily taken, resulting in the usual Coulomb law. For solving it at any coupling, it is convenient to switch to the differential equation

$$\frac{\partial^2 \Gamma}{\partial \mathcal{S} \partial \mathcal{T}} = \frac{\lambda/4\pi^2}{(\mathcal{S} - \mathcal{T})^2 + L^2} \Gamma(\mathcal{S}, \mathcal{T}) . \tag{76}$$

and change variables to x = (S - T)/L and y = (S + T)/L through

$$\Gamma(x,y) = \sum_{m} \mathbf{C}_{m} \gamma_{m}(x) e^{\omega_{m} y/2}$$
(77)

with the corresponding boundary condition  $\Gamma(x,|x|) = 1$ . The dependence of the kernel  $\Gamma$  on the relative times x follows from the differential equation

$$\left(-\frac{d^2}{dx^2} - \frac{\lambda/4\pi^2}{x^2 + 1}\right) \gamma_m(x) = -\frac{\omega_m^2}{4} \gamma^m(x) \tag{78}$$

For large  $\lambda$  the dominant part of the potential in (78) is from *small* relative times x resulting into a harmonic equation [148]

At large times  $\mathcal{T}$ , the kernel is dominated by the lowest harmonic mode. For large times  $\mathcal{S} \approx \mathcal{T}$  that is small x and large y

$$\Gamma(x,y) \approx \mathbf{C}_0 e^{-\sqrt{\lambda}x^2/4\pi} e^{\sqrt{\lambda}y/2\pi}$$
 (79)

From (75) it follows that in the strong coupling limit the ladder generated potential is

$$V_{\rm lad}(L) = -\frac{\sqrt{\lambda}/\pi}{L} \tag{80}$$

which has the same parametric form as the one derived from the AdS/CFT correspondence (70) except for the overall coefficient. Note that the difference is not so large, since  $1/\pi = 0.318$  is larger than the exact value 0.228 by about 1/3. Why did it happened that the potential is reduced relative to the Coulomb law by  $1/\sqrt{\lambda}$ ? It is because the relative time between gluon emissions is no longer  $\sim L$ , as in the Abelian case, but reduced to parametrically small time of relative color coherence  $\tau_c \sim 1/L\lambda^{1/2}$ . Thus we learned an important lesson: in the strong coupling regime even the static charges communicate with each other via high frequency gluons and scalars, propagating (in Euclidean formulation!) with a super-luminal velocity  $v \approx \lambda^{1/2} \gg 1$ .

This idea –although it seemed to be too bizarre to be true – as we will see below to explain some of the AdS/CFT results. Klebanov, Maldacena and Thorn [143] have pointed out that the reason the stress tensor around the dipole is different from perturbative one by a factor  $\sim (L/r)/\sqrt{\lambda}$  is actually explained by limited relative emission time by color coherence time. I am sure possible usage of this idea does not ends here.

Before we leave the subject of Maldacena dipole, one more interesting question is what happen if one of the charges makes a small accelerated motion near its original position. Will there be a radiation? In

a somewhat different setting than used above, the answer was provided by Mikhailov [149]. He studied perturbations of the string and found that the radiated energy is described by familiar classical Liénard formula

$$\Delta E = A \int_{-\infty}^{\infty} \frac{\ddot{\vec{x}}^2 - \left[\dot{\vec{x}} \times \ddot{\vec{x}}\right]^2}{\left(1 - \dot{\vec{x}}^2\right)^3} dt \tag{81}$$

in which QED weak coupling constant  $A = \frac{2}{3}e^2$  is substituted by CFT strong coupling  $A = \frac{\sqrt{\lambda}}{2\pi}$ . This result is similar in its meaning to QCD synchrotron radiation we already mentioned [44] and would provide complete quenching of all jets beyond certain energy if the coherent fields in "glasma" would produce such acceleration, see discussion in [45].

#### 5.4 Conformal plasma in equilibrium and the idea of relaxation

In brief, the finite-T setting is different from zero-T AdS space discussed so far by existence of a horizon. Relaxation is due to the fact that all objects in the bulk sink toward it and their energy and information gets lost.

After we have considered static heavy quarks and their strings, it is natural to proceed to the next stationary situation with a heavy quark, now in the finite-T setting. Fig.25(a) shows a setting of heavy quark quenching [150, 151, 152, 153, 154]: a quark is being dragged (at some hight  $z_m$  related to the quark mass) by an "invisible hand" (to the left): its electric flux goes into the 5-th dimension, into the so called "trailing string". Its weight forces it to fall to the bottom (horizon). (Think of a heavy quark as a ship diligently laying underwater cable to the pool's bottom.) The cost of that is the drag

$$dP/dt = -\pi T^2 \sqrt{g^2 N_c} \frac{v/2}{\sqrt{1-v^2}}$$

connected to the diffusion constant via Einstein relation, a nontrivial successful check on two very different calculations.

Another form of relaxation is studied via propagating "bulk waves" (b): massless ones may have spin S=0 (dilaton/axion),1(vector) or 2 (gravitons). Absorptive boundary condition at the horizon (black bottom)leads to spectra of "quasinormal<sup>43</sup> modes" with the imaginary part  $Im(\omega_n) \sim \pi T n$ , setting the dissipation timescale of various fluctuations.

We will give the equations themselves in the next subsection: let me just mentioned near-zero modes, corresponding to two propagating "surface waves", the longitudinal sound and transverse "diffuson". Absorption at the bottom (horizon) of both famously gives the viscosity  $\eta/s = 1/4\pi[120]$ . The waves may have real (timelike) 4-momentum or virtual (spacelike) one<sup>44</sup>. Rather complete spectra of quasi-normal modes and spectral densities for S=0,1,2 correlators are available, unfortunately mostly extracted numerically. The case (c) – a "falling stone" – perhaps represent colorless (no strings attached) "mesons", released to plasma and relaxing.

The dashed lines in all Fig.25 corresponds to the next-order diagram, describing back reaction of the falling bulk objects onto the boundary, the observation point denoted by a small open circle. This fields may also have spins 0,1 or 2, providing 3 pictures – the (4-d) "holograms" – of the boundary. Contrary to our intuition (developed from our limited flat-world experience), the hologram is *not* a reduced reflection of more complete 5-d dynamics in the bulk, but in fact represents it fully. This phenomenon – the AdS/CFT duality – is a miracle occurring due to near-black-hole setting.

<sup>&</sup>lt;sup>43</sup>Quasinormal modes are those which do not conserve the norm of the wave: it is like decaying radioactive states in nuclear physics which are distinct from scattering ones, with real energies.

<sup>&</sup>lt;sup>44</sup>This case, named DIS in AdS, is discussed here by E.Iancu.

![](_page_53_Picture_0.jpeg)

Figure 25: Schematic view of the relaxation settings, a string (a), a wave (b) or a particle (c) fall into the 5-th dimension toward the black hole.

![](_page_53_Figure_2.jpeg)

Figure 26: From [156]: hologram of the trailing string, the normalized energy density for one quark (supersonic jet) with v = 3/4 at nonzero T.

These holographic images are what the surface observer will see. Image of the trailing string was calculated in [155, 156]: the recent example at nonzero T is shown in Fig.26(b,c): it accurately displays hydro conical flow. For a hologram of the stone Fig.25(c) see recent paper [157]: but to our knowledge the holographic "back reaction" of the falling waves remains to be done.

How these predictions are related to experiment? Apart of those shown in Fig.22, important test is whether the drag force indeed depends only on the velocity (rather than momentum): can be done via single electrons from c and b decays. Another challenge is to test if the effective viscosity  $\eta(k)$  is indeed decreasing with increasing gradients (or momentum k), as AdS/CFT nontrivially indicate. While in [158] only the issue of initial entropy production was discussed, experimentally better control of this effect can be inferred from studies of the viscous corrections to elliptic flow at more peripheral collisions, when the gradient in the direction of impact parameter  $k \sim R_x$  can be made large.

Last but not least, the AdS/CFT correspondence predict a particular ratio of the excitation amplitudes of the sound (conical flow) and diffuson mode. So far we seem to see experimentally only the conical flow, but not the second mode (which would result in a peak in the original direction of the jet). Much more detailed experimental and theoretical studies are required to see if indeed there is a potential discrepancy here or not.

### 6 AdS/CFT and hydrodynamics

### 6.1 Linearized hydrodynamics

Son and collaborators [159] started their program of studies in linearized approximation: they wanted to see if small amplitude perturbations of the finite T Witten's metric do in fact correspond to hydro-

dynamical modes: the sound and diffuson. The answer was positive, for example their famous value of viscosity turned out to be consistently the same in all tests they have made. This paper and its sequels are so clearly written that any reviewer can hardly hope to improve the presentation: so my advice is to look up these papers.

Small perturbations are described by linearized Einstein eqns, and if time and 3-space derivatives are substituted by  $\omega, \vec{k}$  one has second order differential eqns in the "holographic coordinate" which for now we will denote  $u = z/z_h$ . The three relevant eqns and their quasinormal spectra are to be found in Kovtun and Starinets [160], the WKB approach to spectral densities for vector/stress tensor currents in Teaney [161] and also in another paper by Kovtun and Starinets[162]. The "master equation" has the form

 $\frac{d^2}{du^2}Z_a(u) + p_a(u)\frac{d}{du}Z_a(u) + q_a(u)Z_a(u) = 0,$ (82)

where a=1,2,3 labels the three symmetry channels, called *shear*, sound and scalar, respectively. Three sets of coefficients depend on the dimensionless frequency  $\mathbf{w} \equiv \omega/2\pi \mathbf{T}$  and momentum  $\mathbf{q} \equiv \mathbf{k}/2\pi \mathbf{T}$  and are

$$p_1(u) = \frac{(\mathbf{w}^2 - \mathbf{q}^2 f)f + 2u^2 \mathbf{w}^2}{uf(\mathbf{q}^2 f - \mathbf{w}^2)}, \quad q_1(u) = \frac{\mathbf{w}^2 - \mathbf{q}^2 f}{uf^2}.$$
 (83)

$$p_2(u) = -\frac{3\mathbf{w}^2(1+u^2) + \mathbf{q}^2(2u^2 - 3u^4 - 3)}{uf(3\mathbf{w}^2 + \mathbf{q}^2(u^2 - 3))},$$
(84)

$$q_2(u) = \frac{3\mathbf{w}^4 + \mathbf{q}^4(3 - 4u^2 + u^4) + \mathbf{q}^2(4u^2\mathbf{w}^2 - 6\mathbf{w}^2 - 4u^3f)}{uf^2(3\mathbf{w}^2 + \mathbf{q}^2(u^2 - 3))}.$$
 (85)

$$p_3(u) = -\frac{1+u^2}{uf}, \quad q_3(u) = \frac{\mathbf{w}^2 - \mathbf{q}^2 f}{uf^2},$$
 (86)

where  $f = 1 - u^2$ . The procedure is to look for solution satisfying the incoming wave condition at the horizon u = 1. Those can be written as a linear combination of two independent solutions with different behavior at u = 0

$$Z_a(u) = A_a Z_a^I(u) + B_a Z_a^{II}(u)$$
(87)

and standard general argument express the retarded Green function in terms of the ratio of two coefficients, now written in the original units

$$G_a(\omega, q) = -\pi^2 N_c^2 T^4 \frac{B_a(\omega, k)}{A_a(\omega, k)}.$$
(88)

The quasinormal modes are poles of G or zeros<sup>45</sup> of A in the lower part of the frequency complex plane.

To make the equations more familiar they may be easily put into the form of Schroedinger eqn. Let me just comment on some issues which may be confusing for non-experts. The issue I want to comment on is existence of the "horizon" in the thermal AdS metric at  $z = z_h$ , and from  $z > z_h$  no wave will return. The same situation also appears in quantum mechanics, e.g. for radioactive alpha decay problem. There are two ways to address the problem, which are orthogonal to each other: (i) to consider scattering formalism with real  $\omega, k$  and multiple (but normalizable) scattering wave functions, and (ii) use of discrete "quasitationary states" which have complex  $\omega, k$  coming from "black wall" quantization condition. There is vast literature on how to use those: beware for example that if the sign of  $Im(\omega)$  corresponds to decay of the system, Im(k) would produce a wave exponentially

 $<sup>\</sup>overline{\phantom{a}^{45}}$ So that only better behaved solution  $Z_a^{II}(u)$  is present at u=0. We remind that a boundary condition at u=1 was satisfied already, and thus it is standard quantization setting.

![](_page_55_Figure_0.jpeg)

Figure 27: Sound dispersion (real and imaginary parts) obtained from the analysis of quasinormal modes in the AdS black hole background, from Ref.[160]. Gothic omega and q are frequency and momentum in units of 2πT.

growing at large distances. So such states cannot be normalized, and need a lot of care to deal with. Quasinormal modes of black holes are also vast field, starting from original setting by Regge and Wheeler in 1950's for Schwartzschild solution, to AdS black holes in various dimensions: recent review by Siopsis is recommended [164].

Let me give one of the examples of the Kovtun-Starinets paper, showing the real and imaginary part of the lowest quasinormal mode in the sound channel, see Fig.27: we will return to its discussion in section 6.4. Note that at small momenta we have a standard sound, with velocity c<sup>s</sup> = 1/ √ 3 and small dissipation described by bulk viscosity (thin solid lines) but it departs from this behavior for large q > 1. Although I do not show spectral densities of the appropriate correlators, they do contain a "sound peak" whose position is given by real part and width by the imaginary part of this quasinormal mode. Thus (at least the low frequency part of) bulk gravitons becomes the "gravity dual" to sound, in a very direct way.

### 6.2 Bulk viscosity

In the hydrodynamic discussions above we focused on shear viscosity η and now we will discuss recent progress related with the bulk viscosity ζ. As their ratio ζ/η is known to be relatively small both at small and large T, one may naturally expect it to be maximal at or around Tc, when compressibility of matter is very small. The Kubo formula for ζ includes correlator of pressures. Trace of the stress tensor or the dilatational charge can also be used (with care), and based on corresponding sum rules Kharzeev et al [165] predicted integral of the spectral density. These authors predicted a dramatic rise of the bulk viscosity near Tc, see also Karsch et al [166] who sugested that at T<sup>c</sup> the peak value be as large as ζ/s ∼ .3.

From the phenomenological point of view,one may expect limits on the < ζ > value (averaged over time in hydro evolution, in which the near-T<sup>c</sup> region makes about 1/3 of the time at RHIC) from the same sources as limits on shear viscosity η. One source of that is elliptic flow, which would be destroyed if < ζ > be too large: in fact the limits obtained by Romatschke [36] and others is actually for a combination of η and ζ. While we expect η/s to be nearly constant and ζ/s peaked near Tc, the latter gets a smaller weight in the time average: however since the QGP and "near-Tc" eras have similar duration at RHIC this factor is about (1/2) or so. The same argument applies to conical flow, and perhaps this condition is even stronger because (as we argued in our discussion of he conical flow

above) large angle implies that it is mostly formed exactly in the near-T<sup>c</sup> region. Unfortunately, to my knowledge such phenomenological limits are not yet worked out in the quantitative form: my initial guess is that Karsch et al value just mentioned is about as large as possible.

Violation of conformal symmetry in AdS/CFT setting would lead to (i) deviation of the thermodynamics, with nonzero (c 2 <sup>s</sup> − 1/3); and (ii) nonzero bulk viscosity ζ. Both effects were studied in [167, 168, 169] in a gauge theory deformed by a mass to N =2 super-Yang-Mills. Recently Gubser and Nellore [171] simplified the setting considerably, in the spirit of AdS/QCD<sup>46</sup> scalar field with some tunable potential which basically mimics the beta-function of the desired theory. The relevant action is

$$S = \frac{1}{16\pi G_5} \int d^5 x \sqrt{-g} \left[ R - \frac{1}{2} (\partial \phi)^2 - V(\phi) \right]$$
 (89)

and the corresponding equations of motion are

$$\Delta \phi = V'(\phi) \qquad R_{\mu\nu} - \frac{1}{2} R g_{\mu\nu} = \tau_{\mu\nu} \tag{90}$$

where the triangle stands for covariant Dalambetian and the stress tensor for the scalar is

$$\tau_{\mu\nu} = \frac{1}{2}\partial_{\mu}\phi\partial_{\nu}\phi - \frac{1}{4}g_{\mu\nu}(\partial\phi)^2 - \frac{1}{2}g_{\mu\nu}V(\phi)$$
(91)

The backgrounds of interest have the form

$$ds^{2} = e^{2A(r)} \left[ -h(r)dt^{2} + d\vec{x}^{2} \right] + e^{2B(r)} \frac{dr^{2}}{h(r)} \qquad \Phi = \phi(r)$$
(92)

The choice of radial variable r is arbitrary: re-parameterizing it leads only to a different choice of B.

We will follow more recent paper by Gubser et al [172], from which Fig.28 is taken. The idea of the method is explained at Fig.(a), which compares extraction of the shear (left) and bulk (right) viscosities: in both cases it is given by a probability of a reflected waves. The QCD-like potential is taken to be in th form

$$V(\phi) = -\frac{12}{L^2} \cosh(\gamma \phi) + b\phi^2.$$
(93)

The parameter b can be adjusted so that the dimension ∆ of the field theory operator dual to the bulk field φ matches that of trF<sup>2</sup> µν in QCD at a particular scale. γ, ∆ can be tuned to get QCD-like behavior of the entropy shown in the top figure: the corresponding bulk viscosity are shown by blue lines in the two variants of the calculation shown in the bottom. The peak in bulk viscosity is indeed there, but it is about 5 times smaller than proposed by Karsch et al [166]. If so, the bulk viscosity is probably unimportant in comparison to the shear one at RHIC.

### 6.3 Deriving gravity dual to (non-linear) hydrodynamics

Janik and Peschanski [173] have proposed an approach which I call "top-down": they proposed to take some well known hydro solution – e.g. the rapidity-independent Bjorken 1+1 dimensional expansion we discussed above – and look for its gravity dual by extrapolation. It can be said to be a combination of a Big Bang expansion in one "stretching" coordinate and a black hole in all others.

They have used Fefferman-Graham coordinates, which is basically a gauge in which g<sup>55</sup> = 1/z<sup>2</sup> , g5<sup>i</sup> = 0. In this gauge the so called "holographic renormalization" – the Taylor expansion of the metric near the boundary

$$g_{AB} = g_{AB}^{(0)} + z^2 g_{AB}^{(2)} + z^4 g_{AB}^{(4)}$$
(94)

<sup>46</sup>This large subject by itself is unfortunately outside the scope of this review: the reader is advised to look into [170] for a general introduction and other references.

![](_page_57_Figure_0.jpeg)

Figure 28: (top)The normalized entropy density  $s/T^3$  as a function of  $T/T_c$  for two potentials of the form (93) with parameters  $\{\gamma \approx 0.606, b \approx 2.06, \Delta \approx 3.93\}$  and  $\{\gamma \approx 0.606, b \approx 1.503, \Delta \approx 3.61\}$ . (bottom) The ratio of bulk viscosity to entropy density  $\zeta/s$  for those two potentials, respectively. The result of the calculation is shown by the blue curve (the lower one, except at small T). The other (black) curve shows the upper bound suggested by Buchel.

has the most direct physical meaning: the unperturbed term  $g_{\mu\nu}^{(0)}$  is just flat Minkowski metric,  $g_{\mu\nu}^{(2)} = 0$  on general grounds and  $g_{\mu\nu}^{(4)} \sim < T_{\mu\nu} >$  is related to the induced stress tensor on the boundary. If the latter is consider known, from some assumed solution to relativistic hydrodynamics, standard argument from the theory of differential equations ensures that for a second order differential equation a knowledge of 2 subsequent Taylor coefficients is equivalent to knowledge of all of them since the equation itself provides the recursive relation. So one can in principle extrapolate from z=0 into finite z, recovering the whole "gravity dual" solution in the bulk.

Writing the metric as a late-time expansion of the form (schematically, with different functions for different pertinent components)

$$g_{\mu\nu} \sim g_{\mu\nu}^{AdS} exp\left[\sum_{n} \left(\frac{1}{\tau^{2/3}}\right)^n C_n(z^4/\tau^{4/3})\right]$$
 (95)

with coefficients depending only on a single scaling variable  $z^4/\tau^{4/3}$ , Janik and collaborators have put this series into Einstein equations and got multiple coupled eqns for these coefficients. The leading order solution indeed has a departing horizon located at  $z_h \sim \tau^{1/3}$ , in agreement with the entropy conservation in ideal hydro. The next subleading terms  $O(\tau^{-2/3})$  has been calculated by Sin and Nakamura [174] who identified them with the viscosity effects. The viscosity value was however only fixed by still further term calculated again by Janik, following the following principle: all physical observables – the invariants made of curvature tensors – should be nonsingular at the horizon. However still the next (the

third) term calculated in [175] had bad logarithmic singularity which produced unphysical imaginary part in curvatures beyond the horizon. This singularity indicated that something is serious wrong with the asymptotic solution expressed as series by Janik et al. Although appearance of *some* singularities in the bulk are to be expected on general ground, one usually hope (as the next subsection would show directly) that all singularities are hidden from the distant observers by corresponding horizons, at which locally nothing happens to curvature invariants. (I argued even before that something is wrong already with Fefferman-Graham coordinates, as they cannot show metric beyond the horizon.)

Very recently Heller et al [176] have argued that the problem was somehow induced by Fefferman-Graham coordinates, and in a different (Eddington-Filkenstein) coordinates, a non-singular asymptotic solution for Bjorken flow is naturally obtained. Explicitly the metric found is up to second order in gradient expansion. The reason why it works in this settings is better explained from the opposite approach to bulk "gravity dual", which we will discuss now. general setting.

"Down-up approach" to derivation of hydro is based on two papers by Bhattacharayya et al [178, 179], see also [180], who have worked out very intuitive and general derivation of hydrodynamics starting from (a parameterized) horizon singularity and solving Einstein eqns toward the boundary. I view it as the AdS/CFT incarnation of the old "membrane paradigm": the details are different (e.g. conformal symmetry now forces the bulk viscosity and many similar coefficients to vanish).

Before we get technical, let me explain its quite intuitive idea for pedestrians. Recall our finite-T setting, which I compared to a pool heated from its floor. In equilibrium this floor was flat, located at the depth  $z_h$  which defined the temperature at the surface z=0. Now we generalize this problem into a situation which appears in case of tsunami, when the ocean bottom is moving and also not flat. It is intuitively clear that it is easier to get waves on the surface starting from the known position of the bottom, rather than recalculate what happened on the bottom from the observations on the top.

Simplification of the situation, allowing for a systematic study, is obtained due to the assumption of small derivatives (in 3 physical coordinates plus time)

$$\left|\frac{\partial z_h(t,x_i)}{\partial t}\right| \sim \left|\frac{\partial z_h(t,x_i)}{\partial x_i}\right| \sim \epsilon \ll 1$$
 (96)

In the zeroth order in  $\epsilon$  one obviously have a simple "tubewise" approximation, in which  $T(t, x_i)$  on the boundary is given just by the bottom position at the same time and directly below the observation point. The authors worked out two next approximations, the orders  $\epsilon, \epsilon^2$ , corresponding to Navier-Stokes and the second-order hydrodynamics, respectively: apart of technical complexity of expressions, nothing seems to prevent calculation of further terms of this expansion.

Mathematically speaking, the Einstein tensor in 5d has 15 components (thus equations), the metric after fixing the gauge has 10 components. As we restricted zeroth order solution to an ansatz, the first order (in derivatives) part of metric is unknown functions which is found from 10 eqns. The rest are "constrains" which should be valid without any freedom left: thus 4 functions in the original ansatz (the local temperature and flow velocity  $T(x_{\mu}), u_{\mu}(x_{\mu})$ , remember  $u_{\mu}u^{\mu} = 1$ ) cannot be arbitrary. Remarkably, the constraints happen to be (zeroth order) hydrodynamical eqns!

Let us return to "equations" for metric: as usual there are three versions of the z-eqns (for 4d spin-0,1,2 of the 5d gravity). Keeping derivatives of zero order ansatz as sources, all of them can be actually solved by straight integration for arbitrary sources. The starting point is the form of the metric the 'boosted black branes'  $^{47}$ 

$$ds^{2} = -2 u_{\mu} dx^{\mu} dr - r^{2} f(b r) u_{\mu} u_{\nu} dx^{\mu} dx^{\nu} + r^{2} P_{\mu\nu} dx^{\mu} dx^{\nu} , \qquad (97)$$

with

$$f(r) = 1 - \frac{1}{r^4}, \quad u^v = \frac{1}{\sqrt{1 - \beta^2}}, \quad u^i = \frac{\beta_i}{\sqrt{1 - \beta^2}},$$
 (98)

<sup>&</sup>lt;sup>47</sup>The indices in the boundary are raised and lowered with the Minkowski metric  $u_{\mu} = \eta_{\mu\nu} u^{\nu}$ .

where the temperature T = 1 π b and velocities β<sup>i</sup> are all constants with β <sup>2</sup> = β<sup>j</sup> β j , and

$$P^{\mu\nu} = u^{\mu}u^{\nu} + \eta^{\mu\nu} \tag{99}$$

is the projector onto spatial directions. The zero of g<sup>00</sup> is so-to-say proto-horizon: the true event horizon is to be discussed below, after the metric is determined.

If all 4 parameters – T and velocity – are promoted into slowly varying functions of space and time, the Einstein eqn are no longer automatically satisfied: yet it remains a good zeroth order approximation, with systematic corrections<sup>48</sup> organized in power of . At the end, a set of equations one get for the functions turned out to be the fluid dynamics eqns on the boundary.

Let me omit the solution itself: just saying that second order eqns in holographic coordinate r are as usual classified into 3 classes, with spin 0,1,2, each solved for arbitrary "source terms" coming from all those derivative terms which Einstein eqns generate. The general second order expressions are rather lengthy: let me just give for illustration the explicit global metric to first order in boundary derivatives about y <sup>µ</sup> = 0

$$ds^{2} = 2 dv dr - r^{2} f(r) dv^{2} + r^{2} dx_{i} dx^{i} - 2 x^{\mu} \partial_{\mu} \beta_{i}^{(0)} dr dx^{i} - 2 x^{\mu} \partial_{\mu} \beta_{i}^{(0)} r^{2} (1 - f(r)) dv dx^{i}$$

$$-4 \frac{x^{\mu} \partial_{\mu} b^{(0)}}{r^{2}} dv^{2} + 2 r^{2} F(r) \sigma_{ij}^{(0)} dx^{i} dx^{j} + \frac{2}{3} r \partial_{i} \beta_{i}^{(0)} dv^{2} + 2 r \partial_{v} \beta_{i}^{(0)} dv dx^{i}.$$

$$(100)$$

where

$$F(r) = \int_{r}^{\infty} dx \, \frac{x^2 + x + 1}{x(x+1)(x^2+1)} = \frac{1}{4} \left[ \ln \left( \frac{(1+r)^2(1+r^2)}{r^4} \right) - 2 \arctan(r) + \pi \right]$$
 (101)

This metric solves Einstein's equations to first order in the neighborhood of x <sup>µ</sup> = 0 provided the functions b (0) and β (0) i satisfy

$$\partial_t b^{(0)} = \frac{\partial_i \beta_i^{(0)}}{3}, \quad \partial_i b^{(0)} = \partial_t \beta_i^{(0)}.$$
 (102)

Given g (1), it is in principle straightforward to use the AdS/CFT correspondence to recover the stress tensor. Transforming the metric to Fefferman-Graham form and taking their boundary limit z ∼ 1/r → 0, one can finally read off the desired Tµν

$$T^{\mu\nu} = \frac{1}{b^4} \left( 4 u^{\mu} u^{\nu} + \eta^{\mu\nu} \right) - \frac{2}{b^3} \sigma^{\mu\nu}. \tag{103}$$

where the last term contains the first order term which –as expected –has the Navier-Stokes shear structure

$$\sigma^{\mu\nu} = P^{\mu\alpha}P^{\nu\beta} \,\,\partial_{(\alpha}u_{\beta)} - \frac{1}{3} P^{\mu\nu} \,\partial_{\alpha}u^{\alpha} \tag{104}$$

with known viscosity-to-entropy ratio.

The same story is repeated in the second order, with 1-st order hydro eqns needed for the bulk solution and the stress tensor on the boundary containing the second order terms

$$T^{\mu\nu} = (\pi T)^4 (\eta^{\mu\nu} + 4 u^{\mu} u^{\nu}) - 2 (\pi T)^3 \sigma^{\mu\nu}$$
 (105)

$$+(\pi T)^{2} \left( (\ln 2) \ T_{2a}^{\mu\nu} + 2 T_{2b}^{\mu\nu} + (2 - \ln 2) \left[ \frac{1}{3} T_{2c}^{\mu\nu} + T_{2d}^{\mu\nu} + T_{2e}^{\mu\nu} \right] \right)$$
 (106)

(107)

where

$$\sigma^{\mu\nu} = P^{\mu\alpha}P^{\nu\beta} \quad \partial_{(\alpha}u_{\beta)} - \frac{1}{3} P^{\mu\nu} \partial_{\alpha}u^{\alpha} \quad T^{\mu\nu}_{2a} = \epsilon^{\alpha\beta\gamma(\mu} \sigma^{\nu)}_{\ \gamma} u_{\alpha} l_{\beta} \quad T^{\mu\nu}_{2b} = \sigma^{\mu\alpha}\sigma^{\nu}_{\ \alpha} - \frac{1}{3} P^{\mu\nu} \sigma^{\alpha\beta}\sigma_{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^{\alpha\beta} d^$$

<sup>48</sup>In this respect the calculation is similar to a derivation of the effective chiral Lagrangian in its spirit.

$$T_{2c}^{\mu\nu} = \partial_{\alpha}u^{\alpha} \,\sigma^{\mu\nu} \quad T_{2d}^{\mu\nu} = \mathcal{D}u^{\mu} \,\mathcal{D}u^{\nu} - \frac{1}{3} \,P^{\mu\nu} \,\mathcal{D}u^{\alpha} \,\mathcal{D}u_{\alpha} \quad T_{2e}^{\mu\nu} = P^{\mu\alpha} \,P^{\nu\beta} \,\mathcal{D}\left(\partial_{(\alpha}u_{\beta)}\right) - \frac{1}{3} \,P^{\mu\nu} \,P^{\alpha\beta} \,\mathcal{D}\left(\partial_{\alpha}u_{\beta}\right)$$
$$l_{\mu} = \epsilon_{\alpha\beta\gamma\mu} \,u^{\alpha} \partial^{\beta}u^{\gamma}.$$

The second order coefficients agree with those found previously by Baier et al [177] who worked out linearized approximation. Haack and Yarom[181] generalized this analysis for conformal fluids in dimensions 3¡D¡7. Thus, in a way we know a bit more about the CFT plasma than about such usual liquids as water!

The second paper [178] of this (somewhat enlarged) group of authors provides further important developments and clarifications. One of them is the issue of finding the true dynamical horizon of the solution – which in dynamical situation is of course not located at zero of the g00. (This can be seen from the fact that true horizon must be a null surface.) Its position can be found also via expansion, in a quasi-local form. I will not here go into real calculation of it, but following the authors themselves explaining the issue with a simpler example. The so called Vaidya metric describes massless matter accreting into the usual (3+1d) black hole

$$ds^{2} = -\left(1 - \frac{2m(t)}{r}\right)dt^{2} + 2dtdr + r^{2}d\Omega^{2}$$
(108)

The horizon is at some position r = rh(t) which must define a null surface: this condition means that it must satisfy the following eqn

$$r_h(t) = 2m(t) + 2r_h(t)\dot{r}_h(t)$$
 (109)

Without the last term we have static Schwartzschild black hole with the usual r<sup>h</sup> = 2m. With timedepending accretion, it is a differential eqn, so in general the horizon position is a global entity depending on the whole history of accretion process m(t). However this is drastically simplified in the case of slow accretion with ˙m = O(), to the extent that one can write down a local ansatz

$$r_h(t) = 2m(t) + am(t)\dot{m}(t) + bm(t)\dot{m}(t)^2 + cm(t)^2\ddot{m}(t)$$
(110)

with a, b, c being just numbers fixed from the eqn to be 8,64,32, etc. The second O() term is positive: thus the event horizon is above the zero of the g<sup>00</sup> and calculation of its area is not affected by it. In a general case, with a horizon slowly depending on all 4 coordinates, the formulae are more involved but the principle is the same.

A qualitative picture of evolution of the perturbed horizon is given in the Fig. 29 with time ripples on the horizon disappear

The last issue they successfully addressed is that of entropy production. Even in dynamical situation one expects that the Bekenstein entropy is still ultimately is given by the horizon area, as it is a UV concept and cannot depend on soft variation of the horizon shape. Since the horizon surface was located explicitly, one may calculate this area. Furthermore, one may check the local form of the second law of thermodynamics, namely that at any spatial point entropy's time derivative is strictly non-negative. This is indeed demonstrated to be the case, to the <sup>2</sup> order solution obtained.

(That can be of course be checked from the second order hydro eqns: this is the usual form of entropy production dissipative terms. What is shown in [178] is more than that: the positivity of entropy production is true not only in our world, on the pool's surface, but all the way to the "hell" with its infinite temperature and even locally at any point!)

We have pictorially argued in the preceding sections that gravity dual to dissipative relaxation processes means falling into the gravitational abyss. Now, for pure gravity falling, [178] found how to trace the entropy production locally in time (and z coordinate), relating it to r<sup>z</sup> and its derivative terms – the declined/time dependent bottom. Similarly one may ask how the entropy is produced if other forms of bulk matter – e.g. classical strings – are falling as well.

![](_page_61_Figure_0.jpeg)

Figure 29: (from [178]).The event horizon r = rH(x µ ) sketched as a function of the time t and one of the spatial coordinates x (the other two spatial coordinates are suppressed).

#### 6.4 Entropy production in hydro: beyond the derivative expansion

With derivative expansion being now under theoretical control, one may try to go beyond it and think about some kind of re-summations of all dissipative effects. This is not yet done: but let me provide two different reasons for doing that, one based on phenomenology and one on theory.

Phenomenology of hydro, discussed at the beginning of the review, hints that its applicability starts very early, at a time of about 1/2 fm/c at RHIC. At this time the longitudinal derivatives are not formally small enough yet to make the dissipative (Navier-Stokes etc) terms negligible even for the smallest η/s = 1/4π; and yet the ideal hydro seem to do a good job even keeping the entropy. Can it be that the higher order terms somehow compensate the first (viscosity), making its total effect smaller?

The theory issue pointed out by Lublinsky and myself [158], comes from the behavior of the quasinormal modes. Although there is nothing linearized about the early stages of heavy ion collisions, let me still use this example to illustrate the issue.

Writing down the Navier-Stokes eqn and solving it for sound dispersion produces the following dispersion relation

$$\omega = -\frac{i\Gamma_s k^2}{2} \pm \sqrt{c_s^2 k^2 - \Gamma_s^2 k^4 / 4}$$
 (111)

where Γ<sup>s</sup> = η/( + p) is the so called sound absorption length. Reliable hydro region is of course at small k, so one should disregard the last higher order term under the square root and get the textbook answer. Let me for pedagogical reason keep this last term and see what it does: it curves the path of ω(k) on the complex plane so that that left and right moving sound waves make half circle and collide at a finite k when the square root vanishes: apparently there is no sound beyond that point, the Navier and Stokes would say.

What we just did is of course not justified because higher order gradient terms were not included. In the preceding section we discussed the second order gradients recently determined: it turns out those are O(k 3 ) real correction for the sound: they are increasing its speed a bit but keep sound dissipation unchanged. For the diffusion (shear) mode there is a correction to the imaginary part <sup>49</sup>

$$-Im\omega(k) = (1/4)k^2 + \frac{(2-ln2)}{32}k^4 + \dots$$
 (112)

<sup>49</sup>We remind that this expression is written in units of πT for ω, k.

![](_page_62_Figure_0.jpeg)

Figure 30: (Fraction of entropy produced during the hydro phase as a function of initial proper time. The initial temperature  $T_0 = 300 \,\text{MeV}$ . The left (blue) points correspond to the first order (shear) viscosity approximation. The right (red) points are for the all order re-summation.

which has the same sign as the first term, increasing the dissipation as k (or gradients) grows.

Thus both examples seem to tell us that dissipation grows with k monotonously, even more so when we try to include corrections. Yet it is not clear how  $Im\omega(k)$  depends on k away from the origin, or even if it is growing monotonously. Condensed matter physics is full of such examples, with peaks in the dissipation at some characteristic momenta/frequencies.

In fact the lowest quasinormal mode from AdS/CFT does turn around, see Fig.27(b) and its imaginary part is reduced after the maximum at  $k/2\pi T \sim 1$ . This means that the expansion in derivatives should have a radius of convergence  $q/2\pi T \sim 1$ .

The exercise Lublinsky and myself did was to introduce effective momentum-dependent viscosity  $\eta(k)$  and assume that it is *decreasing* with momentum k, reproducing the path of the lowest quasinormal mode<sup>50</sup>. We found that changing constant viscosity to such effective one turns out to be very important at very early stages, see Fig.30. While the first order effects (left) more than double the initial entropy of the flow, the modified viscosity (right) produce much better controlled hydrodynamics and produces an order of magnitude smaller amount of entropy.

### 7 AdS/CFT out of equilibrium

### 7.1 Black hole creation: qualitative ideas

The most challenging frontier in the AdS/CFT-based studies are those attempting to use it out of equilibrium, addressing initial equilibration and entropy production. Non-equilibrium state between the collision moment and ("reasonably") equilibrated QGP is now called "glasma" – which so far is modeled by random classical glue by Venugopalan and collaborators, via classical Yang-Mills equations in weak coupling. However the corresponding "saturation scale"  $Q_s$  at RHIC is only about 1-1.5 GeV – not far from parton momenta in sQGP, the perfect liquid as we now know – so one may wander if a strongly coupled regime should be tried instead. This is what I propose to call "sglasma" frontier.

If AdS/CFT is the tool to be used, one has to start with high energy collision inside cold T = 0  $AdS_5$  (the vacuum, or a bottomless pool) and then dynamically solve two difficult problems: (i) explain how and with what accuracy "the collision debris" act like a "heater" imitating black/hot patch of Fig.25; (ii) find a consistent solution with "falling bottom",  $z_h(time)$ , and find its hologram describing hydro

<sup>&</sup>lt;sup>50</sup>For clarity: we don't understand its physics and do not claim it is the case: we did it to see what possible effect this would have, if true.

![](_page_63_Picture_0.jpeg)

Figure 31: Schematic view of the collision setting. Setting of the sGLASMA studies: (a) a single pair of heavy quark jets, moving with velocities v and -v and creating falling string. Multiple strings create a 3-d falling membrane (2d shown), which is (b) first far from trapped surface and then very closed to it (c).

explosion/cooling.

Since the temperature/entropy only appear when a horizon is dynamically created, leading to the information loss, one may say that "falling debris" upgrade the extreme black hole into a non-extreme one.

A lot of work has been done on gravitational collapse in asymptotically flat 4d space, for collapse into real black holes in our Universe. With modified multidimensional gravity, people are thinking about their possible formation in LHC experiments, and this also created extensive literature. In the AdS/CFT language we are sure that black hole production is not a rare event: in fact it must happen in each and every RHIC heavy ion collision event, with an effective gravity (imitating QCD) in the imaginary (unreal) 5-th dimension.

In heavy ion context, Sin, Zahed and myself [182] first argued that exploding/cooling fireball on the brane is dual to a departing small black hole (separate from the AdS center), formed by the collision debris and then falling toward the AdS center. A specific solution discussed in that paper was a brane departing from a static black hole, which generated a "spherical" solution (no dependence on all 3 spatial coordinates) with a time-dependent T (which however is more appropriate for cosmology but not heavy ion applications). We also discussed several idealized settings, with d-dimensional stretching, corresponding for d=1 to a collision of two infinite thin walls and subsequent Bjorken rapidity-independent expansion, with 2d and 3d corresponding to cylindrical and spherical relativistic collapsing walls.

Before we embark on some details, let me explain what (I think) should be done to solve this problem, schematically shown in Fig.31. The first figure (a) shows the first step – a string which belongs to expanding dipole, with charges moving away from each other. The string solution and the corresponding hologram will be discussed in the next subsection: let us now just note that in this case no horizon is produced and thus no temperature, entropy or hydrodynamics are expected. The second figure (b) display multiple strings with departing ends: those we think can be a good approximation for heavy ion collisions, at least if we think of heavy ions as being made of heavy quarks. If the combined mass of all the strings (or other collision debris) is large enough, their gravity will induce a bubble of trapped surface (a part of is shown in the lower part of figure (b)). From the viewpoint of distant observer, the two membranes – the falling debris and rising horizon ones – will be after some time glued and moved together, as shown in figure (c). This is what I call the two membranes paradigm, to which we turn in the last subsection.

Completing this introductory subsection, let me mention a separate direction by Kajantie et al [183] addressing the same issues in the 1+1 dimensional world. It is easier to work out math in this case: and one can indeed see how a black hole is produced. However, since the shear viscosity is absent in it because of 1+1 dimensions and the bulk viscosity is prohibited by conformity, so it is a cute toy case without any dissipation.

![](_page_64_Figure_0.jpeg)

Figure 32: The hologram of a falling string. The contours show the magnitude of the energy density (a) and the Poynting vector  $T^{0i}$  in the transverse plane (b) at some time. The direction of the momentum flow is indicated by arrows.

### 7.2 Falling strings and "jets" at strong coupling

Rather early in development of QCD, when the notion of confinement and electric flux tubes – known also as the QCD strings – were invented in 1970's, B.Andersen and collaborators [184] developed what gets to be known as the Lund model of hadronic collisions. Its main idea is that during short time of passage of one hadron through another, the strings can get reconnected, and therefore with certain probability some strings become connected to color charges in two different hadrons. Those strings get stretched longitudinally and then break up into parts, making secondary mesons and (with smaller probability) baryons. Many variants of string-based models were developed, and some descendants –e.g. PYTHIA – remain widely "event generators" till today.

AdS/CFT version of the Lund model has been developed in two works by S.Lin and myself [185, 146]. Before we describe some of its results, let me mention another possible usage of those results. Some of the dreams high energy theorists have about possible discoveries at LHC or beyond is existence of "hidden" interactions which we don't see because the so called "mediators" – particles which are charged both under Standard Model and hidden theory – are heavy. Perhaps the hidden sector is strongly coupled: if so one may wander how production of a pair of new charges would look like. Further discussion of this issue (and more references) can be found in a paper by Hofman and Maldacena[186], who made further steps toward understanding the "strongly coupled collider physics".

Let us now return to [185, 146] and consider two heavy quarks departing from each other with velocities  $\pm v$  and connected by a flux tube (classical string): in AdS setting it is not breaking<sup>51</sup> but rather falling into the 5-th z direction, see Fig.31(a). Its action is the familiar Nambu-Goto action in  $AdS_5$  background, and if one ignores two transverse coordinates  $x_2, x_3$  and uses as two internal coordinates the t, x (time and longitudinal coordinate) the string is described by by one function of two variables z(x,t). The corresponding string action is t

$$S = -\frac{R^2}{2\pi\alpha'} \int dt \int \frac{dx}{z^2} \sqrt{1 + (\frac{\partial z}{\partial x})^2 - (\frac{\partial z}{\partial t})^2}$$
 (113)

<sup>&</sup>lt;sup>51</sup>This is so for classical string minimizing the action. However account for fluctuations of the string allows it to touch the flavor brane and break: in fact Peeters, Sonnenschein and Zamaklar [147] have calculated the holographic decays of large-spin mesons this way.

Before solving the corresponding equation in full, we will first discuss "scaling" solutions in the separable form

$$z(\tau, \eta) = \frac{\tau}{f(\eta)} \tag{114}$$

where τ, η are the proper time and space-time rapidity we discussed when we discussed Bjorken solution. This form, suggested by conformal properties of the theory, were used in literature [187], in a different – Euclidean – context, for AdS/CFT calculation of the anomalous dimensions of "kinks" on the Wilson lines (of which our produced pair of charges is one). The corresponding solution was obtained, but we found that it can only exists for sufficiently small<sup>52</sup> velocities. Moreover, the analysis of the classical stability of such scaling solution revealed that it gets unstable for Y > Y<sup>m</sup> ≈ 1/4, where quark rapidity is related to their velocity in the usual way v = tanh(Y ). For larger velocity of the quarks the scaling solution has to be substituted by a non-scaling one, depending on both variables in a nontrivial way, which was analyzed numerically.

The physical picture an observer at the boundary would see is again given by a (gravitational) hologram of the falling string calculated in the second paper [146]. One feature of the result should not be surprising for the readers who followed the description of the hologram of the static Maldacena string above: indeed, no trace of a string is in fact visible. The results – shown in fig.26(a) are nearspherical explosion. This means that there are no jets at strong coupling! Instead of giving rather lengthy formulae let me just comment that we found this explosion to be non-thermal and thus nonhydrodynamical, in the sense that the stress tensor found (although of course conserved and traceless) cannot be parameterized by the energy density and isotropic pressure.

#### 7.3 Entropy production and the "double membranes paradigm"

As it was explained in the previous section, "top-down" [173] and "down-up" significantly clarified how hydrodynamics can be derived in AdS/CFT. But we also would like in principle to understand how initial equilibration happened and the "dynamical horizon" get formed: this means to solving the gravitational collapse problem following Einstein equations from some initial "debris" produced by the collision all the way to black hole.

The initial question is what can an appropriate representation be of the colliding nuclei. One straightforward approach is by Romatschke and Grumiller [188] who literally used the "shock waves" which holographically leads to the delta-funciton like boundary Tµν. Their metric for one shock wave is

(115)

note that it grows in into the z direction indefinitely, thus collision is that of "icebergs" which have their main weight deep down. Not surprisingly, the solution is developing in time "bottom-up", from infrared to the boundary, with boundary Tµν growing with the proper time. The solution is first found analytically at small proper time, expanding in its powers. Perhaps, if the authors would be able to do the second part of their program – solve numerically Einstein equations for finite proper time, they will be able to see approach to equilibrium and eventually transition to hydrodynamical expansion and cooling. Even then, the solution is not expected to go to Bjorken flow because the setting is not rapidity independent.

A significant leap forward had been done recently by Gubser, Pufu and Yarom [189], who proposed to look at heavy ion collision as a process of head-on collision of two point-like black holes, separated from the boundary by some depth L – tuned to the nuclear size of Au to be about 4 fm, see Fig.33. By using global AdS coordinates, these authors argued that (apart of obvious axial O(2) symmetry) this

<sup>52</sup>In particular, for velocities going to zero one finds a strongly coupled version of Ampere's law, the interaction of two nonrelativistic currents.

![](_page_66_Picture_0.jpeg)

Figure 33: From [189]:A projection of the marginally trapped surface that we use onto a fixed time slice of the AdS geometry. The size of the trapped surface is controlled by the energy of the massless particles that generate the shock waves. These particles are shown as dark blue dots.

case has higher – namely O(3)– symmetry with the resulting black hole at the collision moment at its center, thus in certain coordinate

$$q = \frac{\vec{x}_{\perp}^2 + (z - L)^2}{4zL} \tag{116}$$

the 3-d trapped surface C at the collision moment should be just a 3-sphere, at constant  $q = q_c$ . (Here  $x_{\perp}$  are two coordinates transverse to the collision axes.) The picture of it is shown in Fig.29(b)

If so, one can find the radius at which it is the trapped null-surface and determine its energy and Bekenstein entropy. For large  $q_c$  these expressions are

$$E \approx \frac{4L^2 q_c^3}{G_5}, \ S \approx \frac{4\pi L^3 q_c^2}{G_5},$$
 (117)

from which, eliminating  $q_c$ , the main result of the paper follows, namely that the entropy grows with the collision energy as

$$S \sim E^{2/3}$$
 (118)

Note that this power very much depends on the 5-dimensional gravity and is different from the 1950's prediction of Fermi/Landau, that this power should be 1/2. Simplistic comparison with data ignore the nonzero baryon number, important especially at lower collision energies, which should be of course be removed from the *produced* entropy<sup>53</sup>.

While the model is far from being realistic, the math of this paper is extremely interesting. First of all, the "depth" of the colliding objects should not at all be related to the nuclear size (which can in principle be taken to be infinite, for two colliding walls), but rather to the typical "saturation scale" of parton's momenta. Second, this paper does not try to answer the most difficult issue – the dynamical formation of a horizon. Indeed, both colliding objects are already black holes, with nonzero temperature and entropy: at the collision time those are just joint together into a new shape. And, last but not least, it is not clear whether the resulting black hole will retain the same "spherical" shape of the horizon as it falls into the AdS center: if not, further entropy is produced. All of that would of course be subject of subsequent works: whether the result (118) will survive or not remains to be seen.

Further work toward a more realistic "gravity dual" to heavy ion fireball is ongoing. A sketch of our current thinking has already been presented in Fig.31. If many strings are falling together their combined gravity is non-negligible – they are partly falling under their own weight. So one should solve

<sup>&</sup>lt;sup>53</sup>This point was clarified after this question was asked by E.Kiritsis at some meeting.

nonlinear Einstein eqns, which tell us that (from the viewpoint of distant observer) extra weight may actually slow down falling, eventually leading to near-horizon levitation. The trapped surface is moving first upward (shown at the bottom of Fig.31(b)) toward the falling membrane, till two collide, get close and fall together, see Fig.31(c). After that distant observer finds a thermal hydrodynamical explosion as a hologram. This is the case at mid-rapidity but never in the fragmentation regions.

So far we cannot solve it in realistic geometry, and used a simplifications instead. Lin and myself [191] considered the case when falling shell (or membrane, made of collision debris) is flat (x1, x2, x3 independent). In this collapsing shell case one finds a quasiequilibrium solution: the metric above the falling membrane is static thermal AdS in spite of the fact that the membrane is falling. We derived and solved equation of motion of it – from the so called Israel junction condition– and the metric below the falling membrane, which is simple (vacuum) AdS.

The main question is by which experiments an observer on the boundary can distinguish true thermal state from "quasiequilibrium". What we found is that a "one-point observer" would simply see equilibrium pressure and energy density, while more sophisticated "two-point observer" who can measure correlation functions will see deviations from the equilibrium ones in their spectral densities. Solving for various two-point functions in the background with falling shell/membrane we found such deviations: they are oscillating in frequency or peak at certain "echo" times : see more on this interesting phenomenon in [191].

## 8 Brief summary and two open questions

As the reader have seen from this review, the field is actively developing and is very much in flux. At such stage it would be dangerous to make any firm conclusions: instead let me explain in general terms where we are now.

The near-T<sup>c</sup> temperature region got a lot of new attention: from old and experimentally discredited view of being a "mixed phase" – a mixture of dense QGP and much more dilute hadronic phase – it got a new name and picture, it is now viewed as a magnetic plasma region. In it monopoles already dominate the bulk of plasma and expelled electric fields/objects, but they are not yet Bose condensed, as in the confined phase. Its theory is rapidly developing, both based on classical MD and quantum phenomena eventually leading to BEC of monopoles and confinement.

The "quasi-conformal region" T > 2T<sup>c</sup> would perhaps be amenable to AdS/CFT approach, on which we have many intriguing results described above. In particular we have gained amazing insights into the nature of hydrodynamics (deriving it directly from Einstein eqn, order by order in derivatives) and dissipation in general, relating those with classical information loss into the black holes.

Here comes the main open experimental question, originating from the following fact: the RHIC experiments had never ventured into the "quasi-conformal region" . Indeed one needs to run heavy ion collision at LHC to do that. Thus all of us are waiting for the first heavy ion run and the first ALICE data, which will tell us if hydrodynamics (elliptic flow especially) will be as good there as it was at RHIC. The positive answer will put AdS/CFT – and our relations with string community – to further heavy use. The negative answer would mean that the "perfect liquid" at RHIC is a near-T<sup>c</sup> phenomenon, perhaps induced by an interplay of electric and magnetic quasiparticles we discussed above.

Let me end with the central theoretical question of the day: is there a direct relation between two explanations of "perfect liquid", the one based on electric/magnetic duality/transition and that based on AdS/CFT duality? In essence, the former is based on the gauge coupling g <sup>2</sup>/4π passing from the value < 1 to "strong coupling" or magnetic domain where it is > 1. AdS/CFT duality operates with the 't Hooft coupling λ = g <sup>2</sup>Nc. Since N<sup>c</sup> is thought of as infinitely large, λ is large always and the value of g itself is of no importance. Whether we are in electric or magnetic domain does not really matter! What this all means is that a progress in AdS/CFT at finite N<sup>c</sup> is badly needed, before we can

unite the two main theory directions – based on two famous dualities – into one consistent theory.

## 9 Acknowledgements

The work was partially done during my participation in Galileo Galilei Institute spring 2008 program, and I am grateful to the Institute for support and to my fellow co-organizers, especially to Adriano Di Giacomo and to Valentin Zakharov, who made this interesting program happen. Many new things I learned from its participants are embedded in this review. Many more people helped me, especially my collaborators at Stony Brook Ismail Zahed, Derek Teaney, Jinfeng Liao and Shu Li. The work is partially supported by the US-DOE grants DE-FG02-88ER40388 and DE-FG03-97ER4014.

### References

- [1] J. C. Collins and M. J. Perry, Phys. Rev. Lett. 34, 1353 (1975).
- [2] E. V. Shuryak, Sov. Phys. JETP 47, 212 (1978) [Zh. Eksp. Teor. Fiz. 74, 408 (1978)].
- [3] E. V. Shuryak, Phys. Lett. B 78, 150 (1978) [Sov. J. Nucl. Phys. 28, 408.1978 YAFIA,28,796 (1978 YAFIA,28,796-808.1978)].
- [4] J. O. Andersen and M. Strickland, Annals Phys. 317, 281 (2005) [arXiv:hep-ph/0404164].
- [5] B. A. Gelman, E. V. Shuryak and I. Zahed, Phys. Rev. C 74, 044908 (2006) [arXiv:nuclth/0601029].
- [6] S. Mrowczynski and M. H. Thoma, Ann. Rev. Nucl. Part. Sci. 57, 61 (2007) [arXiv:nuclth/0701002].
- [7] K.M. O'Hara, S.L. Hemmer, M.E. Gehm, S.R. Granade, and J.E. Thomas, Science 298 (2002) 2179.
- [8] B. A. Gelman, E. V. Shuryak and I. Zahed, arXiv:nucl-th/0410067.
- [9] A. Turlapov, J. Kinast, B. Clancy, Le Luo, J. Joseph, J. E. Thomas, Kovtun:2005ev
- [10] E. V. Shuryak, arXiv:nucl-th/0606046.
- [11] D. T. Son, arXiv:0804.3972 [hep-th].
- [12] K. Balasubramanian and J. McGreevy, arXiv:0804.4053 [hep-th].
- [13] E. V. Shuryak, Phys. Lett. B 34, 509 (1971).
- [14] E. V. Shuryak and O. V. Zhirov, Phys. Lett. B 89, 253 (1979).
- [15] L. D. Landau, Izv. Akad. Nauk Ser. Fiz. 17, 51 (1953).
- [16] E. Fermi, Phys. Rev. 81, 683 (1951).
- [17] I. Y. Pomeranchuk, Dokl. Akad. Nauk Ser. Fiz. 78, 889 (1951).
- [18] J. Bjorken, Phys. Rev. D27(1983)140
- [19] D. Teaney, J. Lauret and E. V. Shuryak, arXiv:nucl-th/0110037.

- [20] C. B. Chin, E. C. G. Sudarshan and K. H. Wang, Phys. Rev 012(1975)902
- [21] M. I. Gorenshtein, V. A. Zhdanov and Yu. M. Sinjukov, ZhETF 74(1978)833
- [22] E. V. Shuryak, Yadernaya Fizika 16(1972)395
- [23] C. M. Hung and E. V. Shuryak, Phys. Rev. C 57, 1891 (1998) [arXiv:hep-ph/9709264].
- [24] T. Hirano, Acta Phys. Polon. B 36, 187 (2005) [arXiv:nucl-th/0410017].
- [25] C. Nonaka and S. A. Bass, Phys. Rev. C 75, 014902 (2007) [arXiv:nucl-th/0607018].
- [26] K. Adcox et al. [PHENIX Collaboration], Nucl. Phys. A 757, 184 (2005) [arXiv:nucl-ex/0410003].
- [27] S. S. Adler et al. [PHENIX Collaboration], Phys. Rev. Lett. 91, 182301 (2003) [arXiv:nuclex/0305013].
- [28] C. Adler et al. [STAR Collaboration], Phys. Rev. Lett. 87, 182301 (2001) [arXiv:nucl-ex/0107003].
- [29] T. Hirano and K. Tsuda, Phys. Rev. C 66, 054905 (2002) [arXiv:nucl-th/0205043].
- [30] P. F. Kolb and U. W. Heinz, arXiv:nucl-th/0305084.
- [31] P. Huovinen, P. F. Kolb, U. W. Heinz, P. V. Ruuskanen and S. A. Voloshin, Phys. Lett. B 503, 58 (2001) [arXiv:hep-ph/0101136].
- [32] S. S. Adler et al. [PHENIX Collaboration], Phys. Rev. C 69, 034909 (2004) [arXiv:nucl-ex/0307022].
- [33] P. F. Kolb, J. Sollfrank and U. W. Heinz, Phys. Rev. C 62, 054909 (2000) [arXiv:hep-ph/0006129].
- [34] B. B. Back et al. [PHOBOS Collaboration], Phys. Rev. C 72, 051901 (2005) [arXiv:nuclex/0407012].
- [35] D. Teaney, Phys. Rev. C 68, 034913 (2003) [arXiv:nucl-th/0301099].
- [36] P. Romatschke and U. Romatschke, Phys. Rev. Lett. 99, 172301 (2007) [arXiv:0706.1522 [nucl-th]].
- [37] K. Dusling and D. Teaney, Phys. Rev. C 77, 034905 (2008) [arXiv:0710.5932 [nucl-th]].
- [38] U. W. Heinz and H. Song, arXiv:0806.0352 [nucl-th].
- [39] D. Molnar, arXiv:0707.1251 [nucl-th].
- [40] T. Lappi and R. Venugopalan, Phys. Rev. C 74, 054905 (2006) [arXiv:nucl-th/0609021].
- [41] F. Gelis and R. Venugopalan, Acta Phys. Polon. B 37, 3253 (2006).
- [42] H. B. Meyer, Nucl. Phys. B 795, 230 (2008) [arXiv:0711.0738 [hep-lat]].
- [43] R. Baier, Y. L. Dokshitzer, A. H. Mueller, S. Peigne and D. Schiff, Nucl. Phys. B 484, 265 (1997) [arXiv:hep-ph/9608322].
- [44] E. V. Shuryak and I. Zahed, Phys. Rev. D 67, 054025 (2003) [arXiv:hep-ph/0207163].
- [45] D. E. Kharzeev, arXiv:0806.0358 [hep-ph].
- [46] E. V. Shuryak, Phys. Rev. C 66, 027902 (2002) [arXiv:nucl-th/0112042].

- [47] G. D. Moore and D. Teaney, Phys. Rev. C 71, 064904 (2005) [arXiv:hep-ph/0412346].
- [48] H. van Hees, M. Mannarelli, V. Greco and R. Rapp, Phys. Rev. Lett. 100, 192301 (2008) [arXiv:0709.2884 [hep-ph]].
- [49] H. Stoecker, Nucl. Phys. A 750, 121 (2005) [arXiv:nucl-th/0406018].
- [50] J. Casalderrey-Solana, E. V. Shuryak and D. Teaney, J. Phys. Conf. Ser. 27, 22 (2005) [Nucl. Phys. A 774, 577 (2006)] [arXiv:hep-ph/0411315].
- [51] B. Bauchle, L. Csernai and H. Stocker, arXiv:0710.1476 [nucl-th].
- [52] J. Casalderrey-Solana and E. V. Shuryak, arXiv:hep-ph/0511263.
- [53] F. Antinori and E. V. Shuryak, J. Phys. G 31, L19 (2005) [arXiv:nucl-th/0507046].
- [54] D. Kharzeev and H. Satz, Phys. Lett. B 356, 365 (1995) [arXiv:hep-ph/9504397].
- [55] A. Andronic, P. Braun-Munzinger, K. Redlich and J. Stachel, Phys. Lett. B 571, 36 (2003) [arXiv:nucl-th/0303036].
- [56] C. Young and E. Shuryak, arXiv:0803.2866 [nucl-th].
- [57] T. Matsui and H. Satz, Phys. Lett. B 178, 416 (1986).
- [58] M. Asakawa and T. Hatsuda, Phys. Rev. Lett. 92, 012001 (2004) [arXiv:hep-lat/0308034].
- [59] S. Datta, F. Karsch, P. Petreczky and I. Wetzorke, Nucl. Phys. Proc. Suppl. 119, 487 (2003) [arXiv:hep-lat/0208012].
- [60] A. Mocsy, P. Petreczky and J. Casalderrey-Solana, Nucl. Phys. A 783, 485 (2007) [Nucl. Phys. A 785, 266 (2007)] [arXiv:hep-ph/0609205].
- [61] A. Mocsy and P. Petreczky, PoS LAT2007, 216 (2007) [arXiv:0710.5205 [hep-lat]].
- [62] R. L. Thews, Nucl. Phys. A 783, 301 (2007) [arXiv:hep-ph/0609121].
- [63] L. Grandchamp, R. Rapp and G. E. Brown, J. Phys. G 30, S1355 (2004) [arXiv:hep-ph/0403204].
- [64] F. Karsch, D. Kharzeev and H. Satz, Phys. Lett. B 637, 75 (2006) [arXiv:hep-ph/0512239].
- [65] G. Cossu, M. D'Elia, A. Di Giacomo, G. Lacagnina and C. Pica, Phys. Rev. D 77, 074506 (2008) [arXiv:0802.1795 [hep-lat]].
- [66] M. A. Stephanov, K. Rajagopal and E. V. Shuryak, Phys. Rev. Lett. 81, 4816 (1998) [arXiv:hepph/9806219].
- [67] L. McLerran and R. D. Pisarski, Nucl. Phys. A 796, 83 (2007) [arXiv:0706.2191 [hep-ph]].
- [68] L. Y. Glozman, arXiv:0803.1636 [hep-ph].
- [69] J. Liao and E. V. Shuryak, Phys. Rev. D 73, 014509 (2006) [arXiv:hep-ph/0510110].
- [70] L. Castillejo, P. S. J. Jones, A. D. Jackson, J. J. M. Verbaarschot and A. Jackson, Nucl. Phys. A 501, 801 (1989).
- [71] R. Rapp, E. V. Shuryak and I. Zahed, Phys. Rev. D 63, 034008 (2001) [arXiv:hep-ph/0008207].

- [72] M. G. Alford, A. Schmitt, K. Rajagopal and T. Schafer, arXiv:0709.4635 [hep-ph].
- [73] F. Karsch [RBC Collaboration and HotQCD Collaboration], arXiv:0804.4148 [hep-lat].
- [74] M. N. Chernodub, K. Ishiguro, A. Nakamura, T. Sekido, T. Suzuki and V. I. Zakharov, PoS LAT2007, 174 (2007) [arXiv:0710.2547 [hep-lat]].
- [75] A. M. Polyakov, Phys. Lett. B 72, 477 (1978).
- [76] A. Nakamura, T. Saito and S. Sakai, Phys. Rev. D 69, 014506 (2004) [arXiv:hep-lat/0311024].
- [77] O. Kaczmarek and F. Zantow, PoS LAT2005, 192 (2006) [arXiv:hep-lat/0510094].
- [78] G. S. Bali, arXiv:hep-ph/9809351.
- [79] O. Kaczmarek and F. Zantow, Phys. Rev. D 71, 114510 (2005) [arXiv:hep-lat/0503017].
- [80] P. Petreczky and K. Petrov, Phys. Rev. D 70, 054503 (2004) [arXiv:hep-lat/0405009].
- [81] D. Antonov, S. Domdey and H. J. Pirner, Nucl. Phys. A 789, 357 (2007) [arXiv:hep-ph/0612256].
- [82] E. V. Shuryak and I. Zahed, Phys. Rev. C 70, 021901 (2004) [arXiv:hep-ph/0307267].
- [83] E. V. Shuryak and I. Zahed, Phys. Rev. D 70, 054507 (2004) [arXiv:hep-ph/0403127].
- [84] L.D.Landau and E.M.Lifshits, Quantum Mechanics, chapter 90.
- [85] W. M. Alberico, A. Beraudo, A. De Pace and A. Molinari, Phys. Rev. D 75, 074009 (2007) [arXiv:hep-ph/0612062].
- [86] J. Liao and E. V. Shuryak, Nucl. Phys. A 775, 224 (2006) [arXiv:hep-ph/0508035].
- [87] A. V. Smilga, Annals Phys. 234, 1 (1994).
- [88] P. de Forcrand and O. Jahn, Nucl. Phys. B 651, 125 (2003) [arXiv:hep-lat/0211004].
- [89] M. Unsal and L. G. Yaffe, arXiv:0803.0344 [hep-th].
- [90] M. Shifman and M. Unsal, arXiv:0802.1232 [hep-th].
- [91] E. M. Ilgenfritz and E. V. Shuryak, Nucl. Phys. B 319, 511 (1989).
- [92] T. Schafer and E. V. Shuryak, Rev. Mod. Phys. 70, 323 (1998) [arXiv:hep-ph/9610451].
- [93] A. M. Polyakov, Nucl. Phys. B 120, 429 (1977).
- [94] M. Unsal, arXiv:0709.3269 [hep-th].
- [95] D. J. Gross, R. D. Pisarski and L. G. Yaffe, Rev. Mod. Phys. 53, 43 (1981).
- [96] R. D. Pisarski, Phys. Rev. D 74, 121703 (2006) [arXiv:hep-ph/0608242].
- [97] A. Bazavov, B. A. Berg and A. Dumitru, arXiv:0805.0784 [hep-ph].
- [98] K. Fukushima, Phys. Lett. B 591, 277 (2004) [arXiv:hep-ph/0310121].
- [99] E. Megias, E. Ruiz Arriola and L. L. Salcedo, Phys. Rev. D 74, 065005 (2006) [arXiv:hepph/0412308].

- [100] C. Ratti, S. Roessner, M. A. Thaler and W. Weise, Eur. Phys. J. C 49, 213 (2007) [arXiv:hepph/0609218].
- [101] C. R. Allton et al., Phys. Rev. D 71, 054508 (2005) [arXiv:hep-lat/0501030].
- [102] Y. M. Shnir, Berlin, Germany: Springer (2005) 532 p
- [103] S. Mandelstam, Phys. Rept. 23, 245 (1976). G. 't Hooft, Nucl. Phys. B 190, 455 (1981).
- [104] N. Seiberg and E. Witten, Nucl. Phys. B 426, 19 (1994) [Erratum-ibid. B 430, 485 (1994)] [arXiv:hep-th/9407087].
- [105] D. Tong, arXiv:hep-th/0509216.
- [106] M. Shifman and A. Yung, Phys. Rev. D 77, 125016 (2008) [arXiv:0803.0158 [hep-th]].
- [107] M. Shifman and A. Yung, Prepared for 7th Workshop on Continuous Advances in QCD, Minneapolis, Minnesota, 11-14 May 2006
- [108] T. A. DeGrand and D. Toussaint, Phys. Rev. D 22, 2478 (1980).
- [109] A. D'Alessandro and M. D'Elia, arXiv:0711.1266 [hep-lat].
- [110] H. B. Meyer, arXiv:0808.1950 [hep-lat].
- [111] T. C. Kraan and P. van Baal, Nucl. Phys. B 533, 627 (1998) [arXiv:hep-th/9805168].
- [112] D. Diakonov and N. Gromov, Phys. Rev. D 72, 025003 (2005) [arXiv:hep-th/0502132].
- [113] D. Diakonov and V. Petrov, Phys. Rev. D 76, 056001 (2007) [arXiv:0704.3181 [hep-th]].
- [114] J. Liao and E. Shuryak, Phys. Rev. C 75, 054907 (2007) [arXiv:hep-ph/0611131].
- [115] M. N. Chernodub and V. I. Zakharov, Phys. Rev. Lett. 98, 082002 (2007) [arXiv:hep-ph/0611228].
- [116] J. Liao and E. Shuryak, Phys. Rev. C 77, 064905 (2008) [arXiv:0706.4465 [hep-ph]].
- [117] J. Liao and E. Shuryak, arXiv:0804.4890 [hep-ph].
- [118] S. C. Huot, S. Jeon and G. D. Moore, Phys. Rev. Lett. 98, 172303 (2007) [arXiv:hep-ph/0608062].
- [119] P. M. Chesler and A. Vuorinen, JHEP 0611, 037 (2006) [arXiv:hep-ph/0607148].
- [120] G. Policastro, D. T. Son and A. O. Starinets, Phys. Rev. Lett. 87, 081601 (2001) [arXiv:hepth/0104066].
- [121] J. Casalderrey-Solana and D. Teaney, hep-ph/0605199.
- [122] K. Dusling and C. Young, arXiv:0707.2068 [nucl-th].
- [123] R.P. Feynman, Phys. Rev. 90, 1116 (1953)
- [124] R.P. Feynman, Phys. Rev. 91, 1291 (1953)
- [125] D.M.Ceperley, RMP 67 , 279, (1995).
- [126] S. Jang, S. Jang and J.A. Voth, J. Chem. Phys. 115, 7832 (2001)

- [127] R. Kikuchi et al., Phys. Rev. 119, 1823 (1960)
- [128] R.A. Aziz, et al. J. Chem. Phys. 70, 4330 (1979)
- [129] V. Elser, PhD. Thesis, U.C. Berkeley, (1984)
- [130] M.Cristoforetti and E.Shuryak, Bose condensation in liquids and confinement of monopoles, in progress
- [131] A. Gorsky and V. Zakharov, Phys. Rev. D 77, 045017 (2008) [arXiv:0707.1284 [hep-th]].
- [132] L. Del Debbio, M. Faber, J. Greensite and S. Olejnik, Phys. Rev. D 55, 2298 (1997) [arXiv:heplat/9610005].
- [133] P. Petreczky, F. Karsch, E. Laermann, S. Stickan and I. Wetzorke, Nucl. Phys. Proc. Suppl. 106, 513 (2002) [arXiv:hep-lat/0110111].
- [134] J. M. Maldacena, Adv. Theor. Math. Phys. 2, 231 (1998) [Int. J. Theor. Phys. 38, 1113 (1999)] [arXiv:hep-th/9711200].
- [135] J. M. Maldacena, Phys. Rev. Lett. 80, 4859 (1998) [arXiv:hep-th/9803002]. S. J. Rey and J. T. Yee, Eur. Phys. J. C 22, 379 (2001) [arXiv:hep-th/9803001].
- [136] K. S. . Thorne, R. H. . Price and D. A. . Macdonald, NEW HAVEN, USA: YALE UNIV. PR. (1986) 367p
- [137] M. Parikh and F. Wilczek, Phys. Rev. D 58, 064011 (1998) [arXiv:gr-qc/9712077].
- [138] S. S. Gubser, I. R. Klebanov and A. A. Tseytlin, Nucl. Phys. B 534, 202 (1998) [arXiv:hepth/9805156].
- [139] E. Shuryak, arXiv:0711.0004 [hep-ph].
- [140] A. Karch, D. T. Son, E. Katz and M. A. Stephanov, Prepared for 7th Workshop on Continuous Advances in QCD, Minneapolis, Minnesota, 11-14 May 2006
- [141] U. Gursoy and E. Kiritsis, JHEP 0802, 032 (2008) [arXiv:0707.1324 [hep-th]].
- [142] E. Shuryak and I. Zahed, Phys. Rev. D 69, 046005 (2004) [arXiv:hep-th/0308073].
- [143] I. R. Klebanov, J. M. Maldacena and C. B. . Thorn, JHEP 0604, 024 (2006) [arXiv:hepth/0602255].
- [144] J. M. Maldacena, Phys. Rev. Lett. 80, 4859 (1998) [arXiv:hep-th/9803002].
- [145] S. J. Rey and J. T. Yee, Eur. Phys. J. C 22, 379 (2001) [arXiv:hep-th/9803001].
- [146] S. Lin and E. Shuryak, Phys. Rev. D 76, 085014 (2007) [arXiv:0707.3135 [hep-th]].
- [147] K. Peeters, J. Sonnenschein and M. Zamaklar, JHEP 0602, 009 (2006) [arXiv:hep-th/0511044].
- [148] G. W. Semenoff and K. Zarembo, Nucl. Phys. Proc. Suppl. 108, 106 (2002) [arXiv:hepth/0202156].
- [149] A. Mikhailov, arXiv:hep-th/0305196.

- [150] S. J. Sin and I. Zahed, Phys. Lett. B 608, 265 (2005) [arXiv:hep-th/0407215].
- [151] C. P. Herzog, A. Karch, P. Kovtun, C. Kozcaz and L. G. Yaffe, JHEP 0607, 013 (2006) [arXiv:hepth/0605158].
- [152] S. S. Gubser, Phys. Rev. D 74, 126005 (2006) [arXiv:hep-th/0605182].
- [153] A. Buchel, Phys. Rev. D 74, 046006 (2006) [arXiv:hep-th/0605178].
- [154] S. J. Sin and I. Zahed, Phys. Lett. B 648, 318 (2007) [arXiv:hep-ph/0606049].
- [155] J. J. Friess, S. S. Gubser and G. Michalogiorgakis, JHEP 0609, 072 (2006) [arXiv:hep-th/0605292].
- [156] P. M. Chesler and L. G. Yaffe, arXiv:0712.0050 [hep-th].
- [157] S. S. Gubser and A. Yarom, arXiv:0803.0081 [hep-th].
- [158] M. Lublinsky and E. Shuryak, Phys. Rev. C 76, 021901 (2007) [arXiv:0704.1647 [hep-ph]].
- [159] G. Policastro, D. T. Son and A. O. Starinets, JHEP 0209, 043 (2002) [arXiv:hep-th/0205052].
- [160] P. K. Kovtun and A. O. Starinets, Phys. Rev. D 72, 086009 (2005) [arXiv:hep-th/0506184].
- [161] D. Teaney, Phys. Rev. D 74, 045025 (2006) [arXiv:hep-ph/0602044].
- [162] P. Kovtun and A. Starinets, Phys. Rev. Lett. 96, 131601 (2006) [arXiv:hep-th/0602059].
- [163] P. K. Kovtun and A. O. Starinets, Phys. Rev. D 72, 086009 (2005) [arXiv:hep-th/0506184].
- [164] G. Siopsis, arXiv:0804.2713 [hep-th].
- [165] D. Kharzeev and K. Tuchin, arXiv:0705.4280 [hep-ph].
- [166] F. Karsch, D. Kharzeev and K. Tuchin, Phys. Lett. B 663, 217 (2008) [arXiv:0711.0914 [hep-ph]].
- [167] A. Buchel, Phys. Rev. D 72, 106002 (2005) [arXiv:hep-th/0509083].
- [168] A. Parnachev and A. Starinets, JHEP 0510, 027 (2005) [arXiv:hep-th/0506144].
- [169] P. Benincasa, A. Buchel and A. O. Starinets, Nucl. Phys. B 733, 160 (2006) [arXiv:hepth/0507026].
- [170] U. Gursoy, E. Kiritsis, L. Mazzanti and F. Nitti, arXiv:0804.0899 [hep-th].
- [171] S. S. Gubser, A. Nellore, S. S. Pufu and F. D. Rocha, arXiv:0804.1950 [hep-th].
- [172] S. S. Gubser, S. S. Pufu and F. D. Rocha, arXiv:0806.0407 [hep-th].
- [173] R. A. Janik and R. B. Peschanski, Phys. Rev. D 73, 045013 (2006) [arXiv:hep-th/0512162].
- [174] S. Nakamura and S. J. Sin, JHEP 0609, 020 (2006) [arXiv:hep-th/0607123].
- [175] P. Benincasa, A. Buchel, M. P. Heller and R. A. Janik, Phys. Rev. D 77, 046006 (2008) [arXiv:0712.2025 [hep-th]].
- [176] M. P. Heller, P. Surowka, R. Loganayagam, M. Spalinski and S. E. Vazquez, arXiv:0805.3774 [hep-th].

- [177] R. Baier, P. Romatschke, D. T. Son, A. O. Starinets and M. A. Stephanov, JHEP 0804, 100 (2008) [arXiv:0712.2451 [hep-th]].
- [178] S. Bhattacharyya, V. E. Hubeny, S. Minwalla and M. Rangamani, JHEP 0802, 045 (2008) [arXiv:0712.2456 [hep-th]].
- [179] S. Bhattacharyya et al., arXiv:0803.2526 [hep-th].
- [180] M. Natsuume and T. Okamura, Phys. Rev. D 77, 066014 (2008) [arXiv:0712.2916 [hep-th]].
- [181] M. Haack and A. Yarom, arXiv:0806.4602 [hep-th].
- [182] E. Shuryak, S. J. Sin and I. Zahed, J. Korean Phys. Soc. 50, 384 (2007) [arXiv:hep-th/0511199].
- [183] K. Kajantie, J. Louko and T. Tahkokallio, Phys. Rev. D 76, 106006 (2007) [arXiv:0705.1791 [hep-th]].
- [184] B. Andersson, G. Gustafson, G. Ingelman and T. Sjostrand, Phys. Rept. 97, 31 (1983).
- [185] S. Lin and E. Shuryak, Phys. Rev. D 77, 085013 (2008) [arXiv:hep-ph/0610168].
- [186] D. M. Hofman and J. Maldacena, JHEP 0805, 012 (2008) [arXiv:0803.1467 [hep-th]].
- [187] D. J. Gross, A. Mikhailov and R. Roiban, Annals Phys. 301, 31 (2002) [arXiv:hep-th/0205066]. Y. Makeenko, P. Olesen and G. W. Semenoff, Nucl. Phys. B 748, 170 (2006) [arXiv:hepth/0602100].
- [188] D. Grumiller and P. Romatschke, arXiv:0803.3226 [hep-th].
- [189] S. S. Gubser, S. S. Pufu and A. Yarom, arXiv:0805.1551 [hep-th].
- [190] C. Ratti, S. Roessner and W. Weise, Phys. Lett. B 649, 57 (2007) [arXiv:hep-ph/0701091].
- [191] S. Lin and E. Shuryak, arXiv:0808.0910 [hep-th].
- [192] B. Betz, M. Gyulassy, J. Noronha and G. Torrieri, arXiv:0807.4526 [hep-ph].
- [193] M. Gyulassy, J. Noronha and G. Torrieri, arXiv:0807.2235 [hep-ph].