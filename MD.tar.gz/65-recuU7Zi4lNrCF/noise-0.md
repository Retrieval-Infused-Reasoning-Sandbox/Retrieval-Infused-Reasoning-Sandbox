# 1 Adsorption desalination— Principles, process design, and its hybrids for future sustainable desalination

Muhammad W. Shahzad, Muhammad Burhan, Li Ang, Kim C. Ng King Abdullah University of Science & Technology (KAUST), Thuwal, Saudi Arabia

#### Nomenclature

Symbols

P pressure (kPa)

P0 saturation pressure (kPa)

R universal gas constant (kJ/kmolK)

T temperature (K)

T surface heterogeneity for To´th

Greek symbols

Γ Dubinin-Astakhow power factor

Ε adsorption site energy (kJ/kmol or kJ/kg) ε<sup>c</sup> equilibrium adsorption site energy (kJ/kg)

ε<sup>1</sup> to ε<sup>3</sup> reference energy (kJ/kmol)

θ adsorption uptake (kg/kg of adsorbent) θ local adsorption uptake (kg/kg of adsorbent)

Μ chemical potential (kJ/kmol) χ(ε) energy distribution function

Subscript

Α adsorbed phase G gaseous phase

#### 1.1 Introduction

Water and energy are two major needs for life continuation. Presently, about 36% of global population (2.5 billion people) live in water-scarce regions, yet contributing to 22% of the world's GDP (9.4 trillion USD) [\[1\]](#page-25-0). The global water demand (in terms of water withdrawals) is projected to increase by 55% by 2050, mainly because of growing demands from manufacturing (400%), thermal electricity generation (140%), and domestic use (130%). As a result, freshwater availability will be increasingly strained over this time period, and more than 40% of the global population is projected to be living in areas of severe water stress through 2050 [\[2\]](#page-25-0).

![](_page_1_Figure_2.jpeg)

Fig. 1.1 Desalination capacities installed in the world and percent share on the basis of feed water type [3].

Presently, more than 18,000 desalination plants in 150 countries produce  $\sim$ 38 billion m<sup>3</sup> per year as shown in Fig. 1.1 [4–6]. It is projected to increase to 54 billion m<sup>3</sup> per year by 2030, 40% more compared with 2016 [7–9]. Desalination is the most energy-intensive water treatment process that consumes 75.2 TWh per year, about 0.4% of global electricity [10]. Fossil-fuel-operated energy-intensive desalination processes are the major source of CO<sub>2</sub> emission. Presently, globally installed desalination capacities are contributing 76 million tons (Mt) of CO<sub>2</sub> per year and it is expected to grow to 218 million tons of CO<sub>2</sub> per year by 2040 [11,12]. In 2019, the global CO<sub>2</sub> emission is estimated to grow to 43.2 Gt per year, 20% higher than the 2013 value of 36.1 Gt per year [13]. Two-thirds share of the CO<sub>2</sub> emission for the COP21 goal, maintaining the environment temperature increase to below 2°C, has already been used and the remaining will be exhausted by 2050 [13–17].

Fig. 1.2 shows the percentage increase of world water withdrawals and consumption, population and  $\rm CO_2$  emission from 1900. It can be seen that the  $\rm CO_2$  emission is more than 1500% and it is expected to grow to 2200% by 2040 [3]. Similarly, water withdrawals and consumption also increased to more than 1000%. The increase in primary energy consumption is also plotted (1970 baseline at 100%) and it is expected to grow to 500% by 2040 [3,18,19].

In the Gulf Cooperation Council (GCC) countries, a similar water scarcity situation is predicted with the water stress level deemed as severe primarily due to the low rainfall, high evaporation rates, depletion of nonrenewable subsurface water, high industrial and population growth rates. As shown in Fig. 1.3, the annual per capita (APC) renewable water availability in the Gulf countries has decreased rapidly between 1962 and 2010. The reported APC of renewable water varied from a low value of 7.3 m<sup>3</sup> in Kuwait, 20 m<sup>3</sup> in UAE, 33 m<sup>3</sup> in Qatar, 92 m<sup>3</sup> in Bahrain to a higher value of 503 m<sup>3</sup> of Oman [20,21]. The rapid shrinkage of renewable water availability can be attributed to three factors, namely, an increase in industrial and agricultural activities, as well as the

<span id="page-2-0"></span>![](_page_2_Figure_2.jpeg)

Fig. 1.2 Percentage growth rate of life necessity from 1900 to 2040. Water, population and CO2 emission: 1900 baseline at 100%, primary energy: 1970 baseline at 100%.

![](_page_2_Figure_4.jpeg)

Fig. 1.3 Annual per capita renewable water resource in GCC countries between 1962 and 2010.

exponential growth rate of local population. It is estimated that the water demand in most of the GCC countries will be tripled by 2020 from the 2000 level as shown in [Table 1.1](#page-3-0) [\[22\].](#page-26-0)

The currently available water sources are unable to fill the gap between the water supply-demand of most economies in the GCC. To maintain the same economic growth rates in the region, the only source for freshwater supply in the future is by

| ii oiii 2000 to 2020 [22] (iiiiiiioiiis oi iiiiperiui guiroiis) |                   |                   |                   |  |  |  |  |  |
|-----------------------------------------------------------------|-------------------|-------------------|-------------------|--|--|--|--|--|
| Country                                                         | 2000              | 2010              | 2020              |  |  |  |  |  |
| Saudi Arabia<br>Bahrain                                         | 170,476<br>27,930 | 246,065<br>43,181 | 373,444<br>43,181 |  |  |  |  |  |
| Qatar                                                           | 32,303            | 56,222            | 104,780           |  |  |  |  |  |
| Dubai                                                           | 41,354            | 98,178            | 155,109           |  |  |  |  |  |

<span id="page-3-0"></span>Table 1.1 Projected water demand in selected GCC countries from 2000 to 2020 [22] (millions of imperial gallons)

seawater desalination. In the last four decades, the GCC countries have implemented different desalination technologies including: (1) thermal technologies such as multistage flash (MSF) and multiple-effect distillation (MED); and (2) membrane technologies such as Sea Water Reverse Osmosis (SWRO).

Thermally driven MSF operates at a top-brine temperature (TBT) of 120°C and consumes 191-290 MJ/m³ thermal energy and 2.5-5.0 kWh<sub>elec</sub>/m³ electric energy. Typically, MSF can have 40 number of flashing stages and GOR in the range of 8–10. Their CO<sub>2</sub> emission varies from 20 to 25 kg/m<sup>3</sup> as a standalone operation to 14–16 kg/m<sup>3</sup> as a cogeneration operation with the steam power plant. On the other hand, the MED operating temperature varies from 65°C to 70°C and they consume 140–230 MJ/m<sup>3</sup> thermal energy and 2.0–2.5 kWh<sub>elec</sub>/m<sup>3</sup> electric energy. The MED effects varies from 8 to 10 and GOR from 12 to 15 with TVC operation. Their CO<sub>2</sub> emission varies from 12 to 19 kg/m<sup>3</sup> as a standalone operation to 8–9 kg/m<sup>3</sup> as a cogeneration operation with steam power plants [23–32]. The RO processes only required electricity for desalination and the energy consumption is dependent on the recovery ratio and total dissolved solids (TDS) in the feed since the osmotic pressure is related to TDS. Today's SWRO processes required from 3 to 8 kWh<sub>elec</sub>/m<sup>3</sup> (55–82 bar pump pressure) for seawater and 1.5–2.5 kWh<sub>elec</sub>/m<sup>3</sup> for brackish water for large to medium sized plants. Since the RO-specific energy consumption is the lowest among all desalination technologies, it causes the lowest CO<sub>2</sub> emission, 2.79 kg/m<sup>3</sup> in steam cycle operation, and 1.75 kg/m<sup>3</sup> in combined CCGT power plants [33–39].

Despite the fact that the reverse osmosis (RO) technology is the world leading technology due to its low energy intensity, the thermal desalination (MSF and MED) are still dominating in the GCC and account for 68% of the total desalination units in 2010 leaving the rest 32% for RO [40,41]. All these technologies are not only energy intensive but also not environment friendly. Fig. 1.4 shows that the annual electricity demand in the GCC will increase from 467 TWh in 2011 to about 1400 TWh in 2030 and reaching about 2000 TWh in 2040. At the same time, the demand for freshwater in the GCC will grow significantly from 6470 GL in 2011 to 16,000 GL in 2030 and 21,000 GL in 2040 as shown in Fig. 1.4 [42].

From the viewpoint of water-energy-environment nexus, innovative solutions are required to address three major issues; (i) lowering specific energy consumption in terms of kWh/m³ (ii) utilization of low-temperature heat of renewable and nonrenewable sources, and (iii) lowering of pollutants in brine discharge as well as carbon dioxide emission of burned fossil fuels.

<span id="page-4-0"></span>![](_page_4_Figure_2.jpeg)

Fig. 1.4 GCC countries electricity demand trend from 2011 to 2050 (TWh).

The adsorption (AD) cycle is an innovative solution that can operate using lowtemperature waste heat and can produce water. Extensive studies have been conducted to investigate adsorption isotherms of various pairs [43–[52\]](#page-27-0). The hybridization of both cycles, MED and AD called MED-AD, extend the range of downstream (last stage) temperature of conventional MED system typically from 40°C to 5°C. The additional number of stages enhances the water production of the MED cycle by two- to threefold at the same top-brine temperatures (TBTs). In addition, AD integration cycle has the following advantages: (i) it increases interstage temperature differential of each MED stage due to the lowering of the bottom-brine temperature; (ii) the AD cycle utilizes only low-temperature waste heat; (iii) it has almost no major moving parts; (iv) it reduces the chances of corrosion and fouling due to high concentration exposed to a low temperature (5°C) in the last stages; (v) it produces additional cooling effect from the last stages of MED operating below ambient temperature; and (vi) significant increase in system performance. The basics of the adsorption phenomenon, AD cycle, and its hybrids and desalination processes and economics are presented in detail in this chapter.

#### 1.2 Basic adsorption theory

In designing an adsorption-based system, the basic equilibria-vapor uptake information at assorted pressures and temperatures of the vapor must be available. These are commonly represented in the form of isotherms of an adsorbent-adsorbate pair which, hitherto, have been captured by many empirical and semiempirical models. The simplest adsorption isotherm model is the classical Langmuir model [\[53\]](#page-28-0), where it assumes a homogeneous surface with a monolayer vapor uptake with all surfaces containing a uniform charged energy (a flat distribution). Each pore vacant site is filled by a single vapor molecule to form a single sorption event. Invoking the fundamental rate of gas molecules filling the adsorption sites, as given by Ward and coworkers [\[54](#page-28-0)–57], the expression of the Langmuir isotherm model can be derived as follows:

<span id="page-5-0"></span>
$$\frac{d\theta}{dt} = K' \left[ \exp\left(\frac{\mu_g - \mu_\alpha}{RT}\right) - \exp\left(\frac{\mu_\alpha - \mu_g}{RT}\right) \right]$$
 (1.1)

$$\theta = \frac{K \exp\left(\frac{\varepsilon}{RT}\right) P}{1 + K \exp\left(\frac{\varepsilon}{RT}\right) P}$$
(1.2)

However, on a real solid surface where geometrical roughness is inevitably introduced during formation, the energetic heterogeneity cannot be ignored. The gas molecules experience different potential as adsorption sites of uneven energy are reached. As such, the surface is divided into infinitesimal pieces in which the local adsorption energy sites can be treated equally. Hence, the total adsorption of a heterogeneous surface is expressed:

$$\theta = \sum_{i} \chi(\varepsilon_{i}) \cdot \widetilde{\theta}(\varepsilon_{i}) = \int_{0}^{\infty} \chi(\varepsilon) \cdot \widetilde{\theta}(\varepsilon) d\varepsilon \tag{1.3}$$

where  $\overset{\sim}{\theta}(\varepsilon_i)$  is the local surface coverage on which the Langmuir model can be applied. It corresponds to the probability of the adsorption site energy distribution and it inherently satisfies the following condition:

$$\int_{0}^{\infty} \chi(\varepsilon) \cdot d\varepsilon = 1 \tag{1.4}$$

Applying the condensation approximation (CA) for moderate temperatures, the local surface coverage can be simplified to a step-like Dirac-delta function as shown in Fig. 1.5, and expressed below,

![](_page_5_Figure_9.jpeg)

Fig. 1.5 Step-like profile yielded from Eq. (1.5) at moderate temperatures.

<span id="page-6-0"></span>
$$\lim_{T \to 0} \widetilde{\theta}(\varepsilon) = \begin{cases} 0 \text{ for } \varepsilon < \varepsilon_c \\ 1 \text{ for } \varepsilon \ge \varepsilon_c \end{cases}$$
 (1.5)

where  $\varepsilon_c$  relates to the adsorption energy in equilibrium conditions. Hence, Eq. (1.3) can be simplified to

$$\theta = \int_{0}^{\varepsilon_{c}} 0 \cdot \chi(\varepsilon) d\varepsilon + \int_{\varepsilon_{c}}^{\infty} 1 \cdot \chi(\varepsilon) d\varepsilon$$

$$= \int_{\varepsilon_{c}}^{\infty} \chi(\varepsilon) d\varepsilon$$
(1.6)

Obtaining a solution of  $\chi(\varepsilon)$  to represent the site energy allocation for a real adsorbent surface is difficult. However, it is possible to simplify the solution by approximating  $\chi(\varepsilon)$  to a continuous probability distribution function. Depending on the adsorbent surface characteristics during adsorption interaction, symmetrical or asymmetrical Gaussian functions can be assumed, as illustrated in Fig. 1.6.

Table 1.2 summarizes the functions of  $\chi(\varepsilon)$  for the classic Langmuir-Freundlich [58], Dubinin-Astakhov [59], Dubinin-Raduskevich [60], and Tóth isotherm models. By integrating distribution functions from  $\varepsilon_c$  to  $\infty$ , the exact form of these isotherm models can be yielded.

In the recent development of adsorption isotherm theory, Li [61] proposed a universal model that was able to fit all types of isotherms, as specified in Eq. (1.7). Type I—V patterns at various temperatures could be directly captured by the equation with four regression parameters:

![](_page_6_Figure_8.jpeg)

**Fig. 1.6** An illustration of symmetrical or asymmetrical Gaussian function to represent the adsorption site energy distribution for classical isotherm models.

 $\theta = \frac{KP \exp\left(\frac{\varepsilon_3}{RT}\right)}{\left\{1 + \left[KP \exp\left(\frac{\varepsilon_3}{RT}\right)\right]^t\right\}_t^{\frac{1}{t}}}$ 

| Dubinin-Radushkevich, and Tóth isotherm models |                                                                                                                                                                            |                                                                                                                                                                          |  |  |  |  |
|------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|
| Model name                                     | Adsorption site energy distribution $\chi(\varepsilon)$                                                                                                                    | Isotherm equation                                                                                                                                                        |  |  |  |  |
| Langmuir-<br>Freundlich                        | $\chi(\varepsilon) = \frac{\frac{1}{c} \exp\left(\frac{\varepsilon - \varepsilon_0}{c}\right)}{\left[1 + \exp\left(\frac{\varepsilon - \varepsilon_0}{c}\right)\right]^2}$ | $\theta = \frac{\left[KP \exp\left(\frac{\varepsilon_0}{RT}\right)\right]^{\frac{RT}{c}}}{1 + \left[KP \exp\left(\frac{\varepsilon_0}{RT}\right)\right]^{\frac{RT}{c}}}$ |  |  |  |  |
| Dubinin-<br>Astakhov                           | $\chi(\varepsilon) = \frac{r(\varepsilon - \varepsilon_1)^{r-1}}{E^r} \exp\left[-\left(\frac{\varepsilon - \varepsilon_1}{E}\right)^r\right]$                              | $\theta = \exp\left[-\left(\frac{RT}{E}\ln\frac{P_0}{P}\right)^r\right]$                                                                                                 |  |  |  |  |
| Dubinin-                                       | $2(\varepsilon - \varepsilon_1)$ over $\left[ (\varepsilon - \varepsilon_2)^2 \right]$                                                                                     | $\begin{bmatrix} (RT P_0)^2 \end{bmatrix}$                                                                                                                               |  |  |  |  |

 $\chi(\varepsilon) = \frac{\frac{1}{RT} \left[ \exp\left(\frac{\varepsilon - \varepsilon_3}{RT}\right) \right]^t}{\left\{ 1 + \left[ \exp\left(\frac{\varepsilon - \varepsilon_3}{RT}\right) \right]^t \right\}^{\frac{t+1}{t}}}$ 

<span id="page-7-0"></span>Table 1.2 Forms of adsorption site energy distribution functions for the classical Langmuir-Freundlich, Dubinin-Astakhov, Dubinin-Radushkevich, and Tóth isotherm models

$$\frac{q}{q_0} = \frac{A\phi \exp\left(\beta \frac{P}{P_s}\right) \frac{P}{P_s} + C\frac{P}{P_s}}{\left\{1 + \phi \exp\left(\beta \frac{P}{P_s}\right) \frac{P}{P_s}\right\}^t}$$
(1.7)

and

Radushkevich

Tóth

$$\beta = \exp\left(\frac{E_c}{RT}\right) \tag{1.8}$$

$$A = \frac{\left[1 + \phi \exp(\beta)\right]^t - C}{\phi \exp(\beta)} \tag{1.9}$$

where the alphabet  $\phi$  and C are constants; t is the surface heterogeneity factor; and  $E_c$  denotes the characteristic energy of the adsorbent-adsorbate pair. These four parameters are required to calculate in the regression process. The rest of the letters have their usual means.

Using the unified adsorption isotherm framework, a universal adsorption site energy distribution function (EDF) was proposed that relates directly to their isotherm types, and the proposed EDF fitted well with the statistical rate theory of adsorption. The EDF yielded a single peak asymmetrical distribution for type I which was similar to that for the classical LF, DA, DR, and Tóth isotherm models. The EDF is given as below:

$$\chi(\varepsilon) = \frac{\beta^*}{RT} \left[ \phi \exp(\beta^*) \frac{\beta^*}{\beta} + 1 \right]^{-t-1} \left\{ \begin{bmatrix} A\phi \exp(\beta^*) \frac{(\beta^* + 1)}{\beta} + \frac{C}{\beta} \end{bmatrix} \\ \left[ 1 - \phi \exp(\beta^*) \frac{\beta^*}{\beta} (t - 1) \right] \\ -Ct\phi \exp(\beta^*) \left( \frac{\beta^*}{\beta} \right)^2 \end{bmatrix} \right\}$$
(1.10)

where the variable  $\beta^*$  is a function of the adsorption site energy  $\varepsilon$  and expressed as

$$\beta^* = \exp\left(\frac{2E_c - \varepsilon}{RT}\right) \tag{1.11}$$

From the data available from the literature and Eqs. (1.9), (1.10), the assorted isotherms categorized by the IUPAC can be successfully captured succinctly by these equations using only four coefficients of regression, and these EDFs and isotherms are depicted in Table 1.3. For each type of isotherm, the corresponding EDFs have been developed:

The adsorbent-adsorbate interactions is the key in the design of adsorption cycle, which can be functionalized to adopt to warmer ambient temperatures, particularly for operation in the summer period of semiarid or desert regions. Fig. 1.7A and B depict two major types of useful adsorbents in water uptake: The former is the silica gel type 3A, suitable for an AD cycle operating below 33°C ambient such as the tropical weather conditions. The latter figure depicts the isotherms of zeolite (Z0-alumina phosphate oxide, Al<sub>X</sub>Ph<sub>Y</sub>O·nH<sub>2</sub>O). It has properties that can be tailored for adsorption/desorption at ambient temperatures of up to 50°C (corresponding to desorption at 3.8–4.5 kPa (60°C isotherm) and adsorption at 2–2.8 kPa (40°C isotherm). The thermophysical properties of both adsorbents are tabulated in Table 1.4 and Fig. 1.8 shows the field emission microscopic view of type 3A silica gel.

#### 1.3 Basic adsorption cycle

The main components of AD cycle are: (i) evaporator, (ii) adsorption and desorption reactor beds, (iii) condenser, (iv) pumps, and (v) pretreatment facility. The detailed process diagram is shown in Fig. 1.9. The AD operation involves two main processes: (i) adsorption-assisted evaporation and (ii) desorption-activated condensation.

(i) Adsorption-assisted-evaporation: in which the vapors generated in the AD evaporator are adsorbed onto the pore surface area of the adsorbent. The heat source is circulated through the tubes of the evaporator and seawater is sprayed on the tube bundle. It is observed that the evaporation is initiated by the heat source, but during the adsorption process the high affinity of water vapor of the adsorbent drops the evaporator pressure and contributes in evaporation. The AD evaporator operation temperature can be controlled by the heat source temperature that is normally circulated in terms of chilled water. The AD evaporator can

Types of isotherms (IUPAC categorization) Adsorbate-adsorbent pair/references Type I Water-silica gel Type RD Type I Water-silica gel Type A Jiayou, Qiu [\[62\]](#page-28-0) Type II <sup>⋄</sup> Water-boehmite Type II Δ Water-polyvinyl pyrrolidone Wang et al. [\[63\]](#page-28-0) and Zhang et al. [\[64\]](#page-29-0) Type III <sup>⋄</sup> Water-activated carbon Type III Δ Water-carbon S-W nanotube Kim, Pyoungchung and Sandeep Agnihotri [\[65\]](#page-29-0)

<span id="page-9-0"></span>Table 1.3A summary of the energy distribution functions and isotherms as categorized by the IUPAC

![](_page_10_Figure_1.jpeg)

<span id="page-11-0"></span>![](_page_11_Figure_0.jpeg)

**Fig. 1.7** (A) Shows the isotherms of water-silica gel type 3A at four temperatures: 30–45°C at increasing pressure up to 10kPa, while (B) depicts the isotherms of zeolite (Z01, alumina phosphate oxide) from 30°C to 60°C.

 $\ensuremath{\mathsf{Table}}$  1.4 Thermophysical properties of the silica gel type 3A and Zeolite FAM Z01

| Properties                                                        | Silica gel type 3A | Zeolite FAM Z01 |  |
|-------------------------------------------------------------------|--------------------|-----------------|--|
| BET surface area (m <sup>2</sup> /g)                              | 680                | 147.3           |  |
| Porous volume (mL/g)                                              | 0.47               | 0.071           |  |
| Apparent density (kg/m <sup>3</sup> )                             | 770                | 600-700         |  |
| Thermal conductivity (W/m K)                                      | 0.174              | 0.113 (30°C)    |  |
| Heat of adsorption (H <sub>2</sub> O) (kJ/kg of H <sub>2</sub> O) | 2800               | 3110 (25°C)     |  |
| Specific heat capacity (kJ/kgK)                                   | 0.921              | 0.805 (30°C)    |  |

<span id="page-12-0"></span>![](_page_12_Picture_2.jpeg)

Fig. 1.8 Field emission scanning electron microscopic (FESEM) photographs for (A) silica gel type 3A and (B) zeolite FAM Z01.

![](_page_12_Picture_4.jpeg)

Fig. 1.9 Detailed flow schematic of the adsorption cycle.

operate at a wide range of chilled water temperature varying from 5°C to 30°C to produce the cooling effect as well at low-temperature operation. The vapor adsorption process continues until the adsorbent bed reaches a saturation state.

(ii) Desorption-activated-condensation: in which saturated adsorbent is regenerated using the low-grade industrial waste heat or renewable energy (desorption temperature varies from 55°C to 85°C) and desorbed vapors are condensed in a water-cooled condenser and collected as a distillate water.

In a multibed AD system, the operation and switching technique is used. During operation, one or a pair of adsorbent reactor beds undergo the adsorption process and at same time one or a pair of adsorbent reactor beds execute the desorption process. The time for adsorbent reactor bed operation, either adsorption or desorption, is dependent on the heat source temperature and silica gel quantity packed in a bed. Prior to changing the reactor duties, there is a short time interval called switching in which the adsorber bed is preheated while the desorber bed is precooled to enhance the performance of the cycle. In AD cycles, the operation (adsorption and desorption) and switching processes are controlled by an automated control scheme that can open and close the respective bed hot/cold water valves. During the switching operation, all vapor valves are closed so that no adsorption or desorption takes place. It can be seen that the AD cycle can produce two useful effects: cooling effect during adsorption-assisted evaporations and freshwater during desorption-activated condensation.

The AD cycle can produce two useful effects, cooling by adsorption-assisted evaporation and freshwater by desorption-activated condensation simultaneously with only one heat input. To investigate the performance of the basic adsorption cycle, a four-bed adsorption cycle was installed in KAUST, Saudi Arabia, as shown in [Fig. 1.10](#page-14-0)A. Experiments were conducted to calculate specific daily water production and specific cooling as presented in [Fig. 1.10B](#page-14-0) and C. It can be seen that the AD cycle can be operated from cooling to desalination mode just by adjusting the chilled water temperature with the same hardware [\[68\].](#page-29-0)

#### 1.4 The MED–AD hybrid cycle

In a conventional MED system, the vapor produced in a steam generator is condensed in successive stages to recover the heat of condensation and this improves the energy utilization for desalination. The number of stages in a MED is controlled by TBT and the lower-brine temperature (LBT). The TBT of typically 70°C is restricted by soft scaling components in the feedwater and the LBT is controlled by ambient conditions due to the water-cooled condenser to condense the last stage vapors. The thermal desalination system can be more efficient if these two limitations can be removed to increase the number of recoveries. Researchers have found that TBT can be increased to 125°C by inducing nanofiltration (NF) before introducing the feed into the system. This NF process helps to remove the soft scaling components and prevent scaling and fouling on the tubes of evaporators. The interstage temperature and the last stage operating temperature limitations can be overcome by hybridization with the adsorption cycle. The AD cycle can operate below ambient conditions typically as low as 5°C due the high affinity of water vapors of the adsorbent (silica gel). MED last stage temperature can be lowered down to 5°C by introducing the AD at the downstream.

MED-AD is the hybrid of the multieffect desalination (MED) system and the adsorption desalination (AD) cycle. The main components of this novel thermal hybrid system are: (1) the multieffect distillation (MED) system, (2) adsorption desalination (AD) cycle, and (3) auxiliary equipment. In this hybridization system, the last stage of the MED is connected to adsorption beds of the AD cycle for the direct vapor communication to adsorption beds. [Fig. 1.11](#page-15-0) shows the detailed process flow schematic of the MED-AD hybrid system.

<span id="page-14-0"></span>![](_page_14_Figure_2.jpeg)

Fig. 1.10 (A) Adsorption cycle pilot at KAUST, (B) specific daily water production, and (C) specific cooling power.

<span id="page-15-0"></span>![](_page_15_Figure_2.jpeg)

Fig. 1.11 Schematic representation of MED-AD hybrid cycle process flow.

The detailed process is discussed in different forms of streams involved in the operation as discussed below.

Feed stream: The MED system is designed for parallel feed and spray nozzle headers are installed in each MED stage to atomize the feed water for better film evaporation. Each stage is equipped with a built-in feed preheater loop to preheat the feed by extracting the energy from the hot brine sump. A special magnetic coupling pump is used to pressurize the feed water for nozzle operation. Feed flow is controlled via a regulating valve and measured with turbine magnetic pickup flow meter to ensure the required amount of feed to all stages.

Vapor stream (in MED operation): Hot media or heat source is circulated through the tubes during the first stage of MED also called a steam generator to produce the primary vapors. The sprayed brine generates saturated vapors at the state of saturation pressure (PTBT) and temperature (TTBT). These vapors are cascaded to the tube side of the second stage where the vaporization process is repeated by extracting the heat of condensation to evaporate the sprayed brine. The vapors condensed inside the tubes produce the desalted water. These vapors energy reutilization process continues until the last stage where the vapors are condensed in a water-cooled condenser. Low-pressure steam jet ejectors are provided in between the MED stages which extract any noncondensed vapor that may be accumulated at the distillate boxes of MED stages and the removal of noncondensable is a key aspect of MED smooth operation.

Vapor stream (in MED-AD operation): In the case of MED-AD operation, the last stage is connected with AD silica gel beds to adsorb the last-stage vapors. This combination allows removing the condenser with a conventional MED system and hence the last stage can operate as low as 5°C. In the hybrid system, in the last stage the evaporation is observed by the two drivers namely: (1) heat of condensation of tube side vapors and (2) pulling effect of the adsorbent. The AD cycle is operated in a batch manner and the desorption temperature (55–85°C) can be obtained from low-grade waste heat or from renewable energy. The desorbed vapors are than condensed in a AD condenser.

The system investigated here is only having three stages, but in real plants it can be up to 15–20 stages with a combination of NF-MED-AD and it is expected that it can be better than the RO system energetically and efficiently in terms of kWhpe/m<sup>3</sup> .

Distillate stream: To maintain the pressure difference between the MED stages, the distillate box of each stage is connected to a distillate header via a U-tube to collect each stage distillate production. This distillate header is then connected to a distillate tank. Aichi-Tokei high accuracy turbine flow meter is used to measure and for logging the total distillate production from MED and AD systems.

Brine stream: The excess brine from each stage is collected to a brine header via a U-tube. This brine header is connected to the brine collection tank to collect brine. This brine can be recirculated for more recovery depending on the concentration and for that it has a communication line with the feed tank to mix with seawater.

Vacuum system: Since the system is under vacuum, so to maintain the required vacuum level a vane-type vacuum pump is installed. All the equipment are directly connected to the vacuum pump to pull any air ingress into the system at any point. System vacuum is tested for 48 h before experimentation and is found to have very good vacuum holding capacity.

This novel desalination cycle can mitigate the limitations of conventional MED systems to increase the system performance. This combination allows the MED last stage to operate below the ambient temperature typically at 5°C as compared with the traditional MED at 40°C. This not only reduces the corrosion chances but also increases the distillate production to almost twofold as compared with traditional MED systems. The details of the MED-AD hybrid cycle can be found in the literature [\[69](#page-29-0)–78].

#### 1.5 MED-AD pilot experimentation

MED-AD hybrid experiments were conducted at different heat source temperature ranges from 70°C to 15°C. Fig. 1.12 shows the instantaneous temperatures of MED-AD components at a heat source temperature of 50°C. It can be seen that steady-state events (minimum temperature fluctuations) occur after 1 h from startup and experiments for distillate collection are continued for 4–5 h. It can be seen clearly that the interstage temperature difference (ΔT) is more than twice per stage as compared with the conventional MED stages. This is attributed to the vapor uptake by the adsorbent of AD cycle, resulting in the increase of vapor production. The MED + AD cycle yields a stage ΔT from 3°C to 4°C as compared with 1°C or less in the case of MED alone.

[Figs. 1.13 and 1.14](#page-18-0) show the steady-state temperature and pressure values of MED-AD components for heat source temperatures varying from 15°C to 70°C. It can be observed that in all cases, interstage temperature varies from 3°C to 4°C. The ambient energy scavenging effect can also be seen at 15°C and 20°C heat source temperature

![](_page_17_Figure_7.jpeg)

Fig. 1.12 Temperature profiles of MED and MED-AD components at a 50°C heat source.

<span id="page-18-0"></span>![](_page_18_Figure_2.jpeg)

Fig. 1.13 Steady-state temperatures of MED-AD components at different heat sources.

![](_page_18_Figure_4.jpeg)

Fig. 1.14 Steady-state pressures of MED-AD components at different heat sources.

where the heat source outlet temperature is higher. It is predicted that in a full-scale 25–30-stage plant, the ambient energy can be scavenged in the last few stages working below ambient temperatures. An additional cooling effect can also be extracted from the stages working below ambient temperatures. Even with only three stages of MED, the hybridization effect can be seen clearly in terms of interstage temperature distribution.

MED stage distillate production is collected in a MED collection tank and AD condenser production in another tank. Both side productions are measured by a highaccuracy turbine flow meter. [Fig. 1.15](#page-19-0) shows the distillate production trace at a 50°C heat source from MED stages, AD condenser, and combined. The batchoperated AD production can be seen clearly. At the start of desorption, the production is higher and it drops with time to zero during the switching period, while the MED stage production is quite stable. Small fluctuations in MED water production may be due to the fluctuations in the spray of the feed that affect the condensation rate.

<span id="page-19-0"></span>![](_page_19_Figure_2.jpeg)

Fig. 1.15 Water production profiles of MED and MED-AD cycles at a 50°C heat source.

![](_page_19_Figure_4.jpeg)

Fig. 1.16 Water production MED-AD cycles at different heat source temperatures.

Experiments are conducted for 4–5 h for stable distillate production measurement. Fig. 1.16 shows the average water production at heat source temperature varies from 15°C to 70°C. The drop in production with lowering the heat source temperature is due to the drop in saturation temperature and hence the saturation pressure. Even though the last stage production is lower, it is still feasible due to energy harvesting from ambient conditions. Another useful effect from the last stage operating below ambient conditions is cooling that can be produced simultaneously with water production. This additional benefit cannot be obtained from conventional MED systems.

Although the experimental facility had only three stages, experiments were conducted in a piecewise manner where the saturation temperature of the last stage was reproduced as the input temperature to the steam generator. In this succession manner, it is possible to collate the performances of the MED-AD hybrid as though

![](_page_20_Figure_2.jpeg)

Fig. 1.17 Water production comparison of MED and hybrid MED-AD cycles at assorted heat source temperatures.

the AD cycle is integrated to many stages of MED, a design concept akin to what can be permitted by the available ΔT between the top-brine to the bottom-brine stages. Fig. 1.17 shows the water production measured from both the three-stage MED and from MED-AD hybrid (same three-stage) for an assorted range of stage temperatures. At each steam generator temperature, a marked improvement to the water production is observed with a two- to threefold quantum jump.

#### 1.6 Desalination costing: An exergy approach

In desalination, the cost of fuel or input energy is a major contribution to the overall production cost. Since, the desalination processes are energy intensive, they are normally associated with power generation systems as a dual purpose plant.

In dual purpose plants, primary energy apportionment is very important for fair costing of power production and desalination. In the literature, many researchers [\[79](#page-29-0)–82] provided a detailed economic analysis but all studies use energy-based cost apportionment. Energy-based cost apportionment is not the true cost distribution because desalination plants utilized low-grade bleed steam. This low-grade bleed steam has very less ability to perform work in turbines but it can produce a substantial work in desalination because of low-pressure operation. So in dual-purpose power and desalination plants, consideration of same level energies for cost apportionment is irrespective of the water production systems.

For dual-purpose plants, the cost apportioning on the basis of "quality" of energy utilized by the process is the true cost distribution. Cost apportionment utilizing exergy analysis shows the real cost of primary fuel energy for power plants and desalination processes since the quality of the energy is differentiated.

Exergy is an extensive thermodynamic function defined as the maximum theoretically achievable work from an energy carrier under an environmentally imposed condition (To, Po) at a given amount of chemical element. At environmental state also called as dead state, system exergy is considered as zero. Therefore, the general exergy term includes thermomechanical and chemical exergy. The thermomechanical exergy is the maximum available work when system conditions (T and P) approach environmental conditions (To, Po) without changes in the chemical composition of the process stream. The chemical exergy is defined as the maximum work obtained when the concentration (Co) of each substance in process streams changes to that of environmental conditions (To, Po).

The main difference between energy and exergy is that energy always remains conserved in a process according to the first law of thermodynamics, while exergy is destroyed due to irreversibilities in the process. Exergy destruction or annihilation is caused by entropy generation in a process within each component of the system. In addition, there are some exergy losses to the ambient due to the temperature difference and it is called effluent exergy losses. The main point of interest is to find the potential of work of the flow stream also called specific exergy across each component of the system.

Many researchers [83–[103\]](#page-30-0) conducted the detailed exergy analysis for different thermal and membrane desalination processes as a standalone and with dual-purpose plant configuration but for costing they used energy-apportionment techniques. The method of exergy-based cost apportionment is discussed in following sections in detail.

## 1.6.1 System description

The exergy destruction analysis accurately apportions the amount of primary energy consumed by the major components of the plant. This is demonstrated by considering a cogeneration of power (594MW) and desalination (2813m3 /h), as shown schematically in [Fig. 1.18](#page-22-0) [\[104\].](#page-31-0) The major components are arranged synergistically where the gas turbine (GT) generators is operated with high-exergy gases while both the steam turbines and the thermally driven desalination processes are powered by the recovered exergy from the GT exhaust gases.

The distribution of exergy destruction of combined-cycle gas turbines (CCGT) is 75% and the heat recovery steam generator (HRSG) has the remaining 25%. The latter exergy is converted into steam which operates the multistage steam turbines (ST), the steam condenser, and the multi-effect distillation (MED). Approximately 231.5% of the available exergy is converted into steam of high pressure and temperature which is then supplied to the steam turbines for further power production and the thermally driven MED desalination processes. Only less than 30.5% of the available exergy is purged to the ambient as exhaust of combustion products.

In view of the imbalanced exergy destruction in cogeneration processes, it is proposed to convert all derived energies to primary energy using the appropriate conversion factors to calculate the proposed universal performance ratio (UPR) as presented

<span id="page-22-0"></span>![](_page_22_Figure_1.jpeg)

Fig. 1.18 Schematic diagram of the combined power and water desalination plant.

in Eq. (1.12). The proposed UPR is based on the consumption of the primary energy for desalination.

$$UPR = \frac{h_{fg}}{3.6 \sum_{i=1}^{2} {\{\varphi_1(kWh_{elec}/m^3) + \varphi_2^{(TBT)}(kWh_{ther}/m^3)\}}}$$
(1.12)

where  $\varphi_1$  and  ${\varphi_2}^{(TBT)}$  are the conversion factors needed for converting the derived electricity and thermal input at a given TBT to the respective primary energy. The  $h_{fg}$  is the latent heat of potable water produced, that is, 2326kJ/kg. Based on the primary energy consumption, the detailed UPR values of desalination processes are shown in Table 1.5.

On the basis of the above exergy analysis, a life cycle costing analysis is conducted for a dual purpose plant (power+desalination) and it is found that MED-AD has the lowest water production cost of less than US\$0.5/m³—the lowest specific cost ever reported in the literature as shown in Fig. 1.19. We also won the GE-ARAMCO global water challenge award for desalination cost of less than US\$ 0.5/m³.

#### 1.7 Conclusions

Recent developments in adsorption theory, adsorption desalination (AD), and conventional MED desalination cycles have been reviewed in this chapter. We highlight the key role of AD cycles which can be hybridized with the proven cycles such as the MED cycle, exploiting the thermodynamic synergy between the thermally driven cycles that significantly improve the water production yields. Experiments were conducted on a laboratory-scale pilot MED-AD and confirmed the superior synergetic effects that boosted the water production by up to two- to threefold over the conventional MED. We also presented UPR to compare all kinds of desalination processes on the basis of primary energy consumption. It shows that the MED-AD hybrid cycle UPR is the highest among all technologies. The projected LCC of water production can be lowered to as low as US\$0.485/m³.

#### 1.8 Future roadmap

Thermally driven processes MSF/MED have lower performance because of their process limitations. In MED processes, top-brine temperature (TBT) is limited at 70°C due to the soft scaling components such as magnesium (Mg<sup>2+</sup>), calcium (Ca<sup>2+</sup>), and sulfate (SO<sub>4</sub><sup>2-</sup>) ions in the feed that contribute in system degradation at high TBT typically more than 70°C. As a solution, the researchers have found that these scaling agents can be suppressed by pretreating the feed through nanofiltration (NF) or antiscalant dosing and TBT can be raised to 130°C. The last-stage operating temperature limitations, 40°C, can be overcome by adsorption cycle hybridization that can operate below ambient conditions typically as low as 10°C. This tri-hybrid

<span id="page-24-0"></span>Table 1.5 Universal performance ratio of desalination processes

|                             | Derived energy                      |                                     | Conversion factors                  |                                  |                             |                      |
|-----------------------------|-------------------------------------|-------------------------------------|-------------------------------------|----------------------------------|-----------------------------|----------------------|
| Desalination process        | kWh <sub>elec</sub> /m <sup>3</sup> | kWh <sub>ther</sub> /m <sup>3</sup> | Electrical energy conversion factor | Thermal energy conversion factor | Primary<br>energy           | UPR                  |
| SWRO<br>MSF<br>MED<br>MEDAD | 3.5<br>3.0<br>2.3<br>2.5            | NA<br>80.6<br>71.7<br>36            | 47.0%                               | 3.4%                             | 7.45<br>9.1<br>7.36<br>6.56 | 86<br>71<br>87<br>98 |

<span id="page-25-0"></span>![](_page_25_Figure_2.jpeg)

Fig. 1.19 Desalination methods costing by energetic and exergetic approach.

desalination cycle, NF +MED + AD, can operate from a heat source temperature of 130°C to a last-stage temperature of 10°C with more than 20 number of effects and hence the UPR¼250, over 20% of TL. The other hybrid combinations such as NF +RO +MSF, NF +MSF +MED were also proposed for higher performance and maximum thermodynamic synergy. In terms of robustness and commercialization, all individual technologies (NF, MED, MSF, and AD) are well proven and are readily available in the market. Today, thermally driven technologies are available on the shelf to achieve a COP21 goal for sustainable water supplies [3].

#### Acknowledgment

The authors acknowledge the King Abdullah University of Science & Technology (KAUST) (Project no. 7000000411) for the financial support for MED-AD pilot project.

## References

- [1] Findingthe blue path for a sustainable economy, a white paper by Veolia water. [http://www.](http://www.veolianorthamerica.com/sites/g/files/dvc596/f/assets/documents/2014/10/19979IFPRI-White-Paper.pdf) [veolianorthamerica.com/sites/g/files/dvc596/f/assets/documents/2014/10/19979IFPRI-](http://www.veolianorthamerica.com/sites/g/files/dvc596/f/assets/documents/2014/10/19979IFPRI-White-Paper.pdf)[White-Paper.pdf.](http://www.veolianorthamerica.com/sites/g/files/dvc596/f/assets/documents/2014/10/19979IFPRI-White-Paper.pdf)
- [2] [Water and energy. The United Nations world water development report; 2014.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0010)
- [3] [Shahzad MW, Burhan M, Li A, Ng KC. Energy-water-environment nexus underpinning](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0015) [future desalination sustainability. Desalination 2017;413:52](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0015)–64.
- [4] Desalination by the numbers, International Desalination Association; 2016. [http://](http://idadesal.org/desalination-101/desalination-by-the-numbers/) [idadesal.org/desalination-101/desalination-by-the-numbers/](http://idadesal.org/desalination-101/desalination-by-the-numbers/).

- <span id="page-26-0"></span>[5] [Ghaffour N, Missimer TM, Amy GL. Technical review and evaluation of the economics](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0020) [of water desalination: current and future challenges for better water supply sustainability.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0020) [Desalination 2013;309:197](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0020)–207.
- [6] [Elimelech M, Phillip WA. The future of seawater desalination: energy, technology, and](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0025) [the environment. Science 2011;333:712](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0025)–7.
- [7] [World Water Development Report \(WWDR\). U.N.'s World Water Assessment Program;](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0030) [2014.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0030)
- [8] UN Stresses Water and Energy Issues, World Water Day 2014 Report; 2014.
- [9] Water and energy: facts and figures, The United Nations World Water Development (WWDR) Report; 2014.
- [10] UN Water Report, The United Nations inter-agency mechanism on all related issues, including sanitation; 2014. <http://www.unwater.org/statistics/statistics-detail/es/c/211827/>.
- [11] Concept chapter, global clean water desalination alliance "H20 minus CO2". [http://](http://www.diplomatie.gouv.fr/fr/IMG/pdf/global_water_desalination_alliance_1dec2015_cle8d61cb.pdf) [www.diplomatie.gouv.fr/fr/IMG/pdf/global\\_water\\_desalination\\_alliance\\_1dec2015\\_](http://www.diplomatie.gouv.fr/fr/IMG/pdf/global_water_desalination_alliance_1dec2015_cle8d61cb.pdf) [cle8d61cb.pdf](http://www.diplomatie.gouv.fr/fr/IMG/pdf/global_water_desalination_alliance_1dec2015_cle8d61cb.pdf).
- [12] Redrawing the energy-climate map, World energy outlook special Report, International Energy Agency (IEA); 2013. [www.worldenergyoutlook.org/aboutweo/workshops](http://www.worldenergyoutlook.org/aboutweo/workshops).
- [13] [Friedlingstein P, et al. Persistent growth of CO2 emissions and implications for reaching](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0035) [climate targets. Nat Geosci 2014;7:709](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0035)–15.
- [14] COP 21: UN climate change conference, Paris; 2015. [http://www.cop21.gouv.fr/en/why-](http://www.cop21.gouv.fr/en/why-2c/)[2c/;](http://www.cop21.gouv.fr/en/why-2c/) <http://www.c2es.org/facts-figures/international-emissions/historical>.
- [15] [Francey RJ, et al. Atmospheric verification of anthropogenic CO2 emission trends.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0040) [Nat Clim Chang 2013;3:520](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0040)–4.
- [16] [Raupach MR, Le Qu](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0045)e[r](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0045)e [C, Peters GP, Canadell JG. Anthropogenic CO2 emissions.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0045) [Nat Clim Chang 2013;3:603](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0045)–4.
- [17] Carbon Dioxide Information Analysis Center, Oak Ridge National Laboratory, Center for climate and Energy Solutions; 2016.
- [18] Sustaining growth via water productivity: 2030/2050 scenarios. [http://growingblue.com/](http://growingblue.com/wp-content/uploads/2011/05/IFPRI_VEOLIA_STUDY_2011.pdf) [wp-content/uploads/2011/05/IFPRI\\_VEOLIA\\_STUDY\\_2011.pdf.](http://growingblue.com/wp-content/uploads/2011/05/IFPRI_VEOLIA_STUDY_2011.pdf)
- [19] Desalination for water supplies, a review of current technologies. A report by Foundation for Water Research, UK. [www.fwr.uk.](http://www.fwr.uk)
- [20] Yousef Almulla, Gulf cooperation council (GCC) countries 2040 energy scenario for electricity generation and water desalination, [Master of Science thesis], KTH, EGI2014.
- [21] Aidrous IAZ. How to overcome the fresh water crisis in the Gulf, [http://russiancouncil.ru/](http://russiancouncil.ru/en/inner/?id_4=4190#top-content) [en/inner/?id\\_4](http://russiancouncil.ru/en/inner/?id_4=4190#top-content)¼[4190#top-content](http://russiancouncil.ru/en/inner/?id_4=4190#top-content); 2014.
- [22] The GCC in 2020: resources for the future, a report from the Economist Intelligence Unit Sponsored by the Qatar Financial Centre Authority; 2010. [http://graphics.eiu.com/](http://graphics.eiu.com/upload/eb/GCC_in_2020_Resources_WEB.pdf) [upload/eb/GCC\\_in\\_2020\\_Resources\\_WEB.pdf](http://graphics.eiu.com/upload/eb/GCC_in_2020_Resources_WEB.pdf).
- [23] Al-Fulaij HF. Dynamic modeling of multi stage flash (MSF) desalination plant, [PhD thesis]. Department of Chemical Engineering University College London; 2011, [http://discovery.ucl.ac.uk/1324506/1/1324506.pdf.](http://discovery.ucl.ac.uk/1324506/1/1324506.pdf)
- [24] [Al-Karaghouli A, Kazmerski LL. Energy consumption and water production cost of con](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0060)[ventional and renewable-energy-powered desalination processes. Renew Sust Energ Rev](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0060) [2013;24:343](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0060)–56.
- [25] ESCWA (Economic and Social Commission for Western Asia). Role of desalination in addressing water scarcity, [http://www.escwa.un.org/information/publications/edit/](http://www.escwa.un.org/information/publications/edit/upload/sdpd-09-4.pdf) [upload/sdpd-09-4.pdf](http://www.escwa.un.org/information/publications/edit/upload/sdpd-09-4.pdf); 2009.
- [26] Cooley H, Gleick PH, Wolff G. Desalination, with a grain of salt: a California perspective, [http://pacinst.org/app/uploads/2015/01/desalination-grain-of-salt.pdf;](http://pacinst.org/app/uploads/2015/01/desalination-grain-of-salt.pdf) 2006.

- <span id="page-27-0"></span>[27] [Mabrouk A-NA, Nafey AS, Fath HES. Steam, electricity and water costs evaluation of](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0075) [power-desalination co-generation plants. Desalin Water Treat 2010;22:56](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0075)–64.
- [28] [Sommariva C, Hogg H, Callister K. Environmental impact of seawater desalination: rela](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0080)[tions between improvement in efficiency and environmental impact. Desalination](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0080) [2004;167:439](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0080)–44.
- [29] [Raluy RG, Serra L, Uche J, Valero A. Life-cycle assessment of desalination technologies](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0085) [integrated with energy production systems. Desalination 2004;167:445](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0085)–58.
- [30] [Reddy KV, Ghaffour N. Overview of the cost of desalinated water and costing metho](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0090)[dologies. Desalination 2007;205:340](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0090)–53.
- [31] Leon Awerbuch, Corrado Sommariva, MSF distillate driven desalination process and apparatus, WO 2006021796 A1 (2006).
- [32] [Al-Rawajfeh AE, Ihm S, Varshney H, Mabrouk AN. Scale formation model for high](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0095) [top brine temperature multi-stage flash \(MSF\) desalination plants. Desalination](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0095) [2014;350:53](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0095)–60.
- [33] [Fritzmann C, L](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0100)€[owenberg J, Wintgens T, Melin T. State-of-the-art of reverse osmosis](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0100) [desalination. Desalination 2007;216:1](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0100)–76.
- [34] [Dundorf S, MacHarg J, Sessions B, Seacord TF. In: Optimizing lower energy seawater](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0105) [desalination, the affordable desalination collaboration. IDA World Congress-](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0105)[Maspalomas, Gran Canaria, Spain; 2007.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0105)
- [35] [Pen˜ate](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [B,](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [de](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [la](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [Fuente](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [JA,](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [Barreto](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [M.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [Operation](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [of](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [the](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [RO](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [kinetic](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110)® [energy recovery](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110) [system: description and real experiences. Desalination 2010;252:179](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0110)–85.
- [36] [Dundorf S, MacHarg J, Sessions B, Seacord TF. In: Optimizing lower energy seawater](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0115) [desalination: the affordable desalination collaboration. IDA World Congress, Dubai](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0115) [UAE; 2009.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0115)
- [37] [Ludwig H. In: Energy consumption of seawater reverse osmosis: expectations and reality](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0120) [for state-of-the-art Technology. IDA World Congress, Dubai UAE; 2009.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0120)
- [38] [Farooque AM, Jamaluddin ATM, Al-Reweli AR. Comparative study of various energy](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0125) [recovery devices used in SWRO process. SWCC Technical Report No. TR.3807/EVP](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0125) [02005, 2004.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0125)
- [39] [Sauvet-Goichon B. Ashkelon desalination plant-a successful challenge. Desalination](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0130) [2007;203:75](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0130)–81.
- [40] [Eltawil MA, Zhengming Z, Yuan L. In: Renewable energy powered desalination sys](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0135)[tems: technologies and economics-state of the art. Twelfth International Water Technol](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0135)[ogy Conference, IWTC12 2008 Alexandria, Egypt; 2008.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0135)
- [41] [Mabrouk AN, Fath HES. Technoeconomic study of a novel integrated thermal MSF](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0140) [MED desalination technology. Desalination 2015;371:115](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0140)–25.
- [42] [Almulla Y. Gulf cooperation council \(GCC\) countries 2040 energy scenario for electric](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0145)[ity generation and water desalination. \[Master of Science thesis\], KTH, 2014.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0145)
- [43] Thu K, Ng KC, Saha BB, Chakraborty A, Koyama S. Operational strategy of adsorption desalination system. Int J Heat Mass Transfer 2009;52(7–8):1811–6. [https://doi.org/](https://doi.org/10.1016/j.ijheatmasstransfer.2008.10.012) [10.1016/j.ijheatmasstransfer.2008.10.012](https://doi.org/10.1016/j.ijheatmasstransfer.2008.10.012).
- [44] B.B Saha, K.C. Ng, A. Chakraborty, K. Thu (2009), Most energy efficient approach of desalination and cooling, Cooling India, May–June, pp 72–78, (2009).
- [45] [Saha BB, Ng KC, Chakraborty A, Thu K. Energy efficient environment friendly adsorp](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0155)[tion cooling cum desalination system. Cooling India, July](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0155)–August, 2010. p. 22–6.
- [46] Chakraborty A, Leong KC, Thu K, Saha BB, Ng KC. Theoretical insight of adsorption cooling. Appl Phys Lett 2011;98:1. [https://doi.org/10.1063/1.3592260.](https://doi.org/10.1063/1.3592260)

- <span id="page-28-0"></span>[47] Ng KC, Thu K, Saha BB, Chakraborty A, Chun WG. Study on a waste heat-driven adsorption cooling cum desalination cycle. Int J Refrig 2012;35(3):685–93. [https://](https://doi.org/10.1016/j.ijrefrig.2011.01.008) [doi.org/10.1016/j.ijrefrig.2011.01.008](https://doi.org/10.1016/j.ijrefrig.2011.01.008).
- [48] Thu K, Saha BB, Chakraborty A, Chun WG, Ng KC. Thermo-physical properties of silica gel for adsorption desalination cycles. Appl Therm Eng 2013;50:1596–602. [https://doi.](https://doi.org/10.1016/j.applthermaleng.2011.09.038) [org/10.1016/j.applthermaleng.2011.09.038.](https://doi.org/10.1016/j.applthermaleng.2011.09.038)
- [49] Myat A, Ng KC, Thu K, Kim Y-D. Experimental investigation on the optimal performance of Zeolite–water adsorption chiller. Appl Energy 2013;102:582–90. [https://doi.](https://doi.org/10.1016/j.apenergy.2012.08.005) [org/10.1016/j.apenergy.2012.08.005.](https://doi.org/10.1016/j.apenergy.2012.08.005)
- [50] Thu K, Chakraborty A, Kim Y-D, Myat A, Saha BB, Ng KC. Numerical simulation and performance investigation of an advanced adsorption desalination cycle. Desalination 2013;308:209–18. <https://doi.org/10.1016/j.desal.2012.04.021>.
- [51] Ng KC, Thu K, Kim Y-D, Chakraborty A, Amy G. Adsorption desalination: an emerging low-cost thermal desalination method. Desalination 2013;308:161–79. [https://doi.org/](https://doi.org/10.1016/j.desal.2012.07.030) [10.1016/j.desal.2012.07.030.](https://doi.org/10.1016/j.desal.2012.07.030)
- [52] Thu K, Yanagi H, Saha BB, Ng KC. Performance analysis of a low-temperature waste heat-driven adsorption desalination prototype. Int J Heat and Mass Transfer 2013;65:662–9. <https://doi.org/10.1016/j.ijheatmasstransfer.2013.06.053>.
- [53] [Langmuir I. The adsorption of gases on plane surfaces of glass, mica and platinum. J Am](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0195) [Chem Soc 1918;40:1361](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0195)–403.
- [54] [Ward C, Findlay R, Rizk M. Statistical rate theory of interfacial transport. I. Theoretical](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0200) [development. J Chem Phys 1982;76:5599](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0200)–605.
- [55] [Elliott JAW, Ward CA. Statistical rate theory description of beam-dosing adsorption](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0205) [kinetics. J Chem Phys 1997;106:5667](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0205)–76.
- [56] [Elliott JAW, Ward CA. Statistical rate theory and the material properties control](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0210)[ling adsorption kinetics, on well defined surfaces. Stud Surf Sci Catal 1997;104:](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0210) 285–[333.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0210)
- [57] [Elliott JAW, Ward CA. Temperature programmed desorption: a statistical rate theory](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0215) [approach. J Chem Phys 1997;106:5677](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0215)–84.
- [58] [Rudzinski W, Borowiecki T, Dominko A, Panczyk T. A new quantitative interpretation](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0220) [of temperature-programmed desorption spectra from heterogeneous solid surfaces, based](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0220) [on statistical rate theory of interfacial transport: the effects of simultaneous readsorption.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0220) [Langmuir 1999;15:6386](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0220)–94.
- [59] [Rudzinski W, Lee S-L, Panczyk T, Yan C-CS. A fractal approach to adsorption on het](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0225)[erogeneous solids surfaces. 2. Thermodynamic analysis of experimental adsorption data.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0225) [J Phys Chem B 2001;105:10857](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0225)–66.
- [60] [Rudzinski W, Lee S-L, Yan C-CS, Panczyk T. A fractal approach to adsorption on het](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0230)[erogeneous solid surfaces. 1. The relationship between geometric and energetic surface](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0230) [heterogeneities. J Phys Chem B 2001;105:10847](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0230)–56.
- [61] [Li A. Experimental and theoretical studies on the heat transfer enhancement of adsorbent](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0235) [coated heat exchangers \[Doctor of Philosophy\]. Department of Mechanical Engineering,](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0235) [National University of Singapore; 2014.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0235)
- [62] [Jiayou Q. Characterization of silica gel-water vapor adsorption \[MEng thesis\]. NUS;](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0240) [2004.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0240)
- [63] [Wang S-L, Johnston CT, Bish DL, White JL, Hem SL. Water-vapor adsorption and](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0245) [surface area measurement of poorlycrystalline boehmite. J Colloid Interface Sci](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0245) [2003;260\(1\):26](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0245)–35.

- <span id="page-29-0"></span>[64] Zhang J, Zografi G. The relationship between "BET" and "free volume"-derived parameters for water vapor absorption into amorphous solids. J Pharm Sci 2000;89(8):1063–72.
- [65] Kim P, Agnihotri S. Application of water-activated carbon isotherm models to water adsorption isotherms of single-walled carbon nanotubes. J Colloid Interface Sci 2008;325(1):64–73.
- [66] Bansal RC, Dhami TL. Surface characteristics and surface behaviour of polymer carbons-II: adsorption of water vapor. Carbon 1978;16(5):389–95.
- [67] Lagorsse S, Campo MC, Magalhaes FD, Mendes A. Water adsorption on carbon molecular sieve membranes: experimental data and isotherm model. Carbon 2005;43 (13):2769–79.
- [68] Al-kharabsheh S, Goswami DY. Theoretical analysis of a water desalination system using low grade solar heat. J Sol Energy Eng Trans ASME 2004;126:774–80.
- [69] Shahzad MW, Ng KC. On the road to water sustainability in the Gulf. Nature Middle East 2016, https://doi.org/10.1038/nmiddleeast.2016.50.
- [70] Shahzad MW, Thu K, Ng KC. A waste heat driven hybrid ME+AD cycle for desalination, water technology. R Soc Chem Environ Sci Water Res Technol 2016, https://doi.org/10.1039/C5EW00217F.
- [71] Thu K, Kim Y-D, Shahzad MW, Saththasivam J, Ng KC. Performance investigation of an advanced multi-effect adsorption desalination (MEAD) cycle. Appl Energy 2015;159:469–77.
- [72] Bidyut Baran Saha, Ibrahim I. El-Sharkawy, Muhammad Wakil Shahzad, Kyaw Thu, Li Ang and Kim Choon Ng, Fundamental and application aspects of adsorption cooling and desalination, Appl Therm Eng, https://doi.org/10.1016/j.applthermaleng.2015.09.113
- [73] Shahzad MW, Thu K, Kim Y-d, Ng KC. An experimental investigation on MEDAD hybrid desalination cycle. Appl Energy 2015;148:273–81.
- [74] Shahzad MW, Thu K, Ng KC, WonGee C. Recent development in thermally-activated desalination methods: achieving an energy efficiency less than 2.5 kWh<sub>elec</sub>/m<sup>3</sup>. Desalin Water Treat 2015;1–10. https://doi.org/10.1080/19443994.2015.1035499.
- [75] Ng KC, Thu K, Oh SJ, Ang L, Shahzad MW, Ismail AB. Recent developments in thermally-driven seawater desalination: energy efficiency improvement by hybridization of the MED and AD cycles. Desalination 2015;356:255–70.
- [76] Shahzad MW, Ng KC, Thu K, Saha BB, Chun WG. Multi effect desalination and adsorption desalination (MEDAD): a hybrid desalination method. Appl Therm Eng 2014;72:289–97.
- [77] Kim Choon NG, Thu K, Shahzad MW, Chun WG. Progress of adsorption cycle and its hybrid with conventional MSF/MED processes in the field of desalination. Int Desalin Assoc J Water Desalin Reuse 2014;6(1):44–56. https://doi.org/10.1177/2051645214Y. 0000000020.
- [78] Shahzad MW, Myat A, WonGee C, Ng KC. Bubble-assisted film evaporation correlation for saline water at sub-atmospheric pressures in horizontal-tube evaporator. Appl Therm Eng 2013;50:670–6. https://doi.org/10.1016/j.applthermaleng.2012.07.003.
- [79] Moran MJ. Availability analysis: a guide to efficient energy use. Englewood Cliffs, NJ: Prentice Hall; 1981.
- [80] Kotas TJ. The exergy method of thermal plant analysis. Malabar, FL: Krieger; 1995.
- [81] Tribus M, Evans RB, Crellin GL. In: Spiegler KW, editor. Principles of desalination. New York: Academic Press; 1966.
- [82] Gaggioli RA. Second law analysis for process and energy engineering. ACS symposium series, Washington, DC: American Chemical Society; 1983.

- <span id="page-30-0"></span>[83] [Al-Sulaiman FA, Ismail B. Exergy analysis of major re-circulating multi-stage flash](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0340) [desalting plants in Saudi Arabia. Desalination 1995;103:265](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0340)–70.
- [84] O.A. Hamed, A.M. Zamamir, S. Aly, N. Lior, Thermal performance and exergy analysis of a thermal vapor compression desalination system, Energy Convers Manag 37 (4) (1996) 379-387.
- [85] [Spliegler KS, E1-Sayed YM. The energetics of desalination processes. Desalination](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0345) [2001;134:109](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0345)–28.
- [86] [Sharqawy MH, Lienhard V JH, Zubair SM. In: Formulation of seawater flow exergy](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0350) [using accurate thermodynamic data. Proceeding of the International Mechanical Engi](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0350)[neering Congress and Exposition IMECE-2010, November 12](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0350)–18, Vancouver, British [Columbia, Canada; 2010.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0350)
- [87] [Cerci Y. Improving the thermodynamic and economic efficiencies of desalination plants](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0355) [\[PhD dissertation\]. Mechanical Engineering, University of Nevada; 1999.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0355)
- [88] [Cengel YA, Cerci Y, Wood B. In: Second law analysis of separation processes of mix](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0360)[tures. ASME international mechanical engineering congress and exposition, Nashville,](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0360) [Tennessee, November 14e19; 1999.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0360)
- [89] [Cerci Y. Exergy analysis of a reverse osmosis desalination plant in California.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0365) [Desalination 2002;142:257](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0365)–66.
- [90] N. Kahraman, Y.A. Cengel, B. Wood, Y. Cerci, Exergy analysis of a combined RO, NF, and EDR desalination plant, Desalination 171 (2004) 217e232.
- [91] [Kahraman N, Cengel YA. Exergy analysis of a MSF distillation plant. Energy Convers](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0370) [Manag 2005;46:2625](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0370)–36.
- [92] [Banat F, Jwaied N. Exergy analysis of desalination by solar-powered membrane distil](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0375)[lation units. Desalination 2008;230:27](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0375)–40.
- [93] [Nafeya AS, Fath HE, Mabrouka AA. Exergy and thermo-economic evaluation of MSF](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0380) [process using a new visual package. Desalination 2006;201:224](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0380)–40.
- [94] [Mabrouka AA, Nafeya AS, Fath HE. Analysis of a new design of a multi-stage](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0385) [flash-mechanical vapor compression](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0385) desalination process. Desalination [2007;204:482](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0385)–500.
- [95] [Nafeya AS, Fath HE, Mabrouka AA. Thermo-economic design of a multi effect evapo](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0390)[ration mechanical vapor compression \(MEEeMVC\) desalination process. Desalination](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0390) [2008;230:1](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0390)–15.
- [96] [Kamali RK, Mohebinia S. Experience of design and optimization of multi-effects desa](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0395)[lination systems in Iran. Desalination 2008;222:639](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0395)–45.
- [97] [Kamali RK, Abbassi A, Sadough Vanini SA, Saffar Avval M. Thermodynamic design](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0400) [and parametric study of MED-TVC. Desalination 2008;222:596](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0400)–604.
- [98] [Ameri M, Mohammadi SS, Hosseini M, Seifi M. Effect of design parameters on multi](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0405)[effect desalination system specifications. Desalination 2009;245:266](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0405)–83.
- [99] [Wang Y, Lior N. Performance analysis of combined humidified gas turbine power gen](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0410)[eration and multi-effect thermal vapor compression desalination systems-part 1: the](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0410) [desalination unit and its combination with a steam-injected gas turbine power system.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0410) [Desalination 2006;196:84](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0410)–104.
- [100] [Chacartegui R, Sa´nchez D, di Gregorio N, Jim](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0415)[enez-Espadafor FJ, Mun˜oz A, Sa´nchez T.](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0415) [Feasibility analysis of a MED desalination plant in a combined cycle based cogeneration](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0415) [facility. Appl Therm Eng 2009;29:412](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0415)–7.
- [101] [Darwish MA, Al Otaibi S, Al Shayji K. Suggested modifications of power-desalting](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0420) [plants in Kuwait. Desalination 2007;216:222](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0420)–31.
- [102] Darwish MA, [Alotaibi S, Alfahad S. On the reduction of desalting energy and its cost in](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0425) [Kuwait. Desalination 2008;220:483](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0425)–95.

- <span id="page-31-0"></span>[103] [Deng R, Xie L, Lin H, Liu J, Han W. Integration of thermal energy and seawater desa](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0430)[lination. Energy 2010;35:4368](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0430)–74.
- [104] [Palenzuela P, Zaragoza G, Alarco´n D, Blanco J. Simulation and evaluation of the cou](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0435)[pling of desalination units to parabolic-trough solar power plants in the Mediterranean](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0435) [region. Desalination 2011;281:379](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0435)–87.

#### Further reading

- [1] [Li A, Thu K, Ismail AB, Shahzad MW, Ng KC. Performance of adsorbent-embedded heat](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0440) [exchangers using binder-coating method. Int J Heat Mass Transfer 2016;92:149](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0440)–57.
- [2] [Ng KC, Chua HT, Chung CY, Loke CH, Kashiwagi T, Akisawa A, et al. Experimental](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0445) [inventogation of the silica gel-water adsorption isotherm characteristics. Appl Therm](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0445) [Eng 2001;21:1631](http://refhub.elsevier.com/B978-0-12-815818-0.00001-1/rf0445)–42.