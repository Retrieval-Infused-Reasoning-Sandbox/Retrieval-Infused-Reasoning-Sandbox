# <span id="page-0-0"></span>**Investigation of Heat Pump Technologies with Potential for Ultra-High Temperature Applications**

**September | 2023**

**JunSoo Yoo<sup>1</sup> , Carlos E. Estrada-Perez<sup>1</sup> , Byunghee Choi<sup>1</sup> , Vivek Utgikar<sup>2</sup> , Chaithanya Balumuru<sup>2</sup> , Quinn Dodge<sup>2</sup>**

*Idaho National Laboratory 2University of Idaho*

![](_page_0_Picture_5.jpeg)

#### **DISCLAIMER**

This information was prepared as an account of work sponsored by an agency of the U.S. Government. Neither the u.s. government nor any agency thereof, nor any of their employees, makes any warranty, expressed or implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness, of any information, apparatus, product, or process disclosed, or represents that its use would not infringe privately owned rights. References herein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise, does not necessarily constitute or imply its endorsement, recommendation, or favoring by the U.S. Government or any agency thereof. The views and opinions of authors expressed herein do not necessarily state or reflect those of the U.S. government or any agency thereof.

# Investigation of Heat Pump Technologies with Potential for Ultra-High Temperature Applications

JunSoo Yoo<sup>1</sup>, Carlos E. Estrada-Perez<sup>1</sup>, Byunghee Choi<sup>1</sup>, Vivek Utgikar<sup>2</sup>, Chaithanya Balumuru<sup>2</sup>, Quinn Dodge<sup>2</sup>

<sup>1</sup>Idaho National Laboratory <sup>2</sup>University of Idaho

September 2023

Idaho National Laboratory Integrated Energy Systems Idaho Falls, Idaho 83415

http://www.ies.inl.gov

Prepared for the
U.S. Department of Energy
Office of Nuclear Energy
Under DOE Idaho Operations Office
Contract DE-AC07-05ID14517

*Page intentionally left blank*

## **ABSTRACT**

<span id="page-4-0"></span>This report provides a comprehensive investigation into heat pump (HP) technologies to achieve heat supply temperatures above 250°C, referred to as ultra-high-temperature heat pump (UHTHP). UHTHP, a low-carbon heat delivery and augmentation technology, offers an alternative to traditional combustion heating for decarbonizing high-temperature industrial processes. The scope of this review covers both mechanical and chemical HP technologies. The heat supply temperature of over 250°C pursued by UHTHP surpasses the temperature range typically covered in the high-temperature HP literature and existing capabilities of commercial HP systems. This report seeks to pinpoint technical gaps and challenges that have hindered widespread adoption of UHTHP in industry, explore potential improvements and solutions to address the challenges, and discuss its technical feasibility for practical contribution to industrial decarbonization. Current efforts are intended to lay the ground for future research and commercial deployment endeavors for UHTHP.

*Page intentionally left blank*

## **CONTENTS**

| ABS | STRAC | ТТ     |             |                                                                     | iii |
|-----|-------|--------|-------------|---------------------------------------------------------------------|-----|
| ACI | RONYN | MS     |             |                                                                     | xii |
| 1   | INTR  | RODUCT | ΓΙΟΝ        |                                                                     | 1   |
| 2   | ULTI  | RA-HIG | Н ТЕМРЕ     | RATURE HEAT PUMPS                                                   | 4   |
|     | 2.1   | Mecha  | nically Dri | iven Heat Pump                                                      | 6   |
|     |       | 2.1.1  |             | ompression Heat Pumps                                               |     |
|     |       |        | 2.1.1.1     | Reversed Rankine Cycles                                             |     |
|     |       |        | 2.1.1.2     | Reversed Kalina Cycle                                               | 12  |
|     |       | 2.1.2  | Gas Com     | pression Heat Pumps                                                 | 14  |
|     |       |        | 2.1.2.1     | Reversed Joule-Brayton Cycle                                        | 14  |
|     |       |        | 2.1.2.2     | Stirling Heat Pumps                                                 | 18  |
|     | 2.2   | Therm  | ally Drive  | n Heat Pump (Chemical Heat Pump)                                    | 25  |
|     |       | 2.2.1  | Working     | Principle                                                           | 25  |
|     |       | 2.2.2  | Working     | Fluids                                                              | 27  |
|     |       |        | 2.2.2.1     | Water Vapor as Working Fluid: Hydroxide-Oxide System                | 29  |
|     |       |        | 2.2.2.2     | Carbon Dioxide as a Working Fluid: Carbonate-Oxide System           | 33  |
|     |       |        | 2.2.2.3     | Oxygen/Hydrogen As Working Fluids: Metal Hydrides and Oxides        | 39  |
|     |       |        | 2.2.2.4     | Thermodynamics of Hydroxide Systems                                 | 43  |
|     |       |        | 2.2.2.5     | Kinetics of Hydroxide and Carbonate Systems                         | 44  |
|     |       | 2.2.3  | Operation   | nal Parameters and Characteristics                                  | 48  |
|     |       | 2.2.4  | Performa    | nce, Scalability, and Capital Costs                                 | 48  |
| 3   |       |        |             | AT PUMP TECHNOLOGIES FOR ULTRA-HIGH-                                | 50  |
|     |       |        |             | LICATIONS                                                           |     |
|     | 3.1   |        |             | iven Heat Pump Technologies                                         |     |
|     | 3.2   |        | •           | n Heat Pump Technologies                                            |     |
| 4   | TECI  | HNICAL | GAPS, C     | HALLENGES, AND POTENTIAL IMPROVEMENT                                | 63  |
|     | 4.1   | Mecha  | nically Dri | iven Heat Pumps                                                     | 63  |
|     |       | 4.1.1  | Turboma     | chinery (Compressor)                                                | 63  |
|     |       | 4.1.2  | Working     | Fluids                                                              | 68  |
|     |       |        | 4.1.2.1     | Working Fluid Challenge for Vapor Compression Heat Pump Cycles      | s68 |
|     |       |        | 4.1.2.2     | Working Fluid Challenge for Gas Compression Heat Pump Cycles        | 70  |
|     |       | 4.1.3  |             | changer (Thermal Interface Design)                                  |     |
|     |       | 4.1.4  |             | S                                                                   |     |
|     |       | 4.1.5  |             | d Heat Pump Systems and Associated Research Efforts                 | 74  |
|     |       |        | 4.1.5.1     | Mechanically Driven Heat Pumps Combined With Thermal Energy Storage | 74  |
|     |       |        |             | ~                                                                   | / 1 |

|   |      |       | 4.1.5.2     | Combination of Ultra-High-Temperature Heat Pump and Electric He     |    |
|---|------|-------|-------------|---------------------------------------------------------------------|----|
|   |      |       | 4.1.5.3     | Cascade Heat Pump Systems                                           |    |
|   |      |       | 4.1.5.4     | High-Temperature Transcritical Heat Pump Systems                    | 77 |
|   |      |       | 4.1.5.5     | Heat Pump Systems With Zeotropic Mixture                            | 78 |
|   |      |       | 4.1.5.6     | Others                                                              | 78 |
|   | 4.2  | Therm | ally Drive  | n Heat Pumps (Chemical Heat Pump)                                   | 79 |
|   |      | 4.2.1 | Technica    | al Challenges                                                       | 79 |
|   |      | 4.2.2 | Potential   | Methods to Alleviate Performance Degradation Challenges             | 79 |
|   |      |       | 4.2.2.1     | Al <sub>2</sub> O <sub>3</sub>                                      | 79 |
|   |      |       | 4.2.2.2     | LiOH                                                                | 80 |
|   |      |       | 4.2.2.3     | Na <sub>2</sub> Si <sub>3</sub> O <sub>7</sub>                      | 80 |
|   |      |       | 4.2.2.4     | Nano-SiO <sub>2</sub>                                               | 81 |
|   |      |       | 4.2.2.5     | Salts (Chlorides, Sulfates, Nitrates and Acetates) of Alkali Metals | 81 |
|   |      |       | 4.2.2.6     | Addition of CaTiO <sub>3</sub>                                      | 81 |
| 5 |      |       |             | ELING STUDY FOR ULTRA-HIGH-TEMPERATURE HEAT                         | 81 |
|   | 5.1  | Vapor | Compress    | sion Cycle                                                          | 81 |
|   |      | 5.1.1 | Vapor C     | ompression Cycle With Flash Tank                                    | 81 |
|   |      | 5.1.2 | _           | ompression Cycle With Heat Exchanger                                |    |
|   | 5.2  | Chemi | ical Heat P | Pump Cycle                                                          | 85 |
|   | 5.3  | Dynan | nic Heat P  | ump Simulation                                                      | 90 |
| 6 | SUM  | MARY  | AND CO      | NCLUSIONS                                                           | 91 |
| 7 | DEEI | DENCI | E C         |                                                                     | 0/ |

## **FIGURES**

| Figure 1. CO2<br>emissions from U.S. primary energy-related end-use sectors (as of 2021, top), and<br>distribution of process heat temperature demand by industrial subsectors in 2014<br>(bottom) [1]2                                                                                           |  |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|
| Figure 2. Carnot COP as a function of heat source and heat sink temperatures.<br>3                                                                                                                                                                                                                |  |
| Figure 3. Classification of heat pumps by temperature (adapted and expanded from References<br>[6,7]), HP: conventional HP, HTHP: high-temperature HP, VHTHP: very-high<br>temperature HP, UHTHP: ultra-high-temperature HP. No distinction is made between<br>HTHP and VHTHP in this study.<br>5 |  |
| Figure 4. Classification of HPs for ultra-high-temperature applications.<br>5                                                                                                                                                                                                                     |  |
| Figure 5. Comparing temperature levels and scales of thermodynamic power cycles (adapted and<br>revised from Reference [9])6                                                                                                                                                                      |  |
| Figure 6. Schematics of the ideal reverse Brayton cycle (a) components diagram and (b)<br>temperature vs. entropy diagram.<br>15                                                                                                                                                                  |  |
| Figure 7. Comparison of critical temperatures and pressures of various gases and water16                                                                                                                                                                                                          |  |
| Figure 8. Comparison of volumetric heat capacity of different gases and water17                                                                                                                                                                                                                   |  |
| Figure 9. Reverse Brayton cycle COP for high compressor outlet temperatures T218                                                                                                                                                                                                                  |  |
| Figure 10. Idealized Stirling engine cycle.<br>19                                                                                                                                                                                                                                                 |  |
| Figure 11. A simple ChHP system involving a condensable product<br>[98].<br>25                                                                                                                                                                                                                    |  |
| Figure 12. Classification of CHPs27                                                                                                                                                                                                                                                               |  |
| Figure 13. The schematic of an IES coupled with ChHP to deliver process heat to high<br>temperature industries28                                                                                                                                                                                  |  |
| Figure 14. (a) Schematics of components of Ca(OH)2/CaO ChHP system and (b) Clausius<br>Clapeyron diagram (Q →<br>heat, P →<br>pressure, T →<br>temperature; subscripts H →<br>high,<br>M →<br>medium, L →<br>low, C →<br>condenstaion, E →<br>evaporation).<br>29                                 |  |
| Figure 15. (a) Schematic of the cross-flow diagram of the pilot reactor and (b) reactor filled with<br>20<br>kg of Ca(OH)2<br>[114].<br>31                                                                                                                                                        |  |
| Figure 16. Process flow diagram of the test bench [114]31                                                                                                                                                                                                                                         |  |
| Figure 17. (a) Indirectly operated thermochemical storage reactor and (b) multifunctional test<br>bench [115]32                                                                                                                                                                                   |  |
| Figure 18. Principle of MgO/H2O chemical thermal storage [116].<br>32                                                                                                                                                                                                                             |  |
| Figure 19. Conceptual flow diagram of CaO-CO2<br>energy storage system in heat augmentation<br>mode [119]34                                                                                                                                                                                       |  |
| Figure 20. Schematic diagram of CaO-CO2<br>energy storage systems with three different CO2<br>gas<br>storage methods [119].<br>35                                                                                                                                                                 |  |
| Figure 21. Principle of CaO/PbO/CO2<br>ChHPs of heat transformation type operation: (a) heat<br>storage mode and (b) heat output mode [120].<br>36                                                                                                                                                |  |
| Figure 22. HP cycle of CaO/PbO/CO2<br>reaction equilibrium.<br>36                                                                                                                                                                                                                                 |  |
| Figure 23. Schematic of CaL solar thermal power plant.<br>37                                                                                                                                                                                                                                      |  |

| Figure 24. COP vs. upgraded temperature of CaO-CO2<br>energy storage systems with various CO2<br>storage system [119]37                                                                                                                                                                                                 |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Figure 25. Principle of PbO/CO2<br>chemical reaction heat-storage system: (a) heat-storage mode<br>and (b) heat supply mode [120]39                                                                                                                                                                                     |
| Figure 26. Charging (left) and discharging (right) processes of MHTES [127].<br>39                                                                                                                                                                                                                                      |
| Figure 27. Schematic of combined MHTES and cooling system integrated with solar thermal<br>power plant<br>[127]40                                                                                                                                                                                                       |
| Figure 28. Schematic of cascade metal oxide TCES system employing four different oxide<br>materials [127]42                                                                                                                                                                                                             |
| Figure 29. Schematic of pilot-scale test facility to study redox-based thermochemical storage.<br>43                                                                                                                                                                                                                    |
| Figure 30. Equilibrium relationship for hydroxide systems45                                                                                                                                                                                                                                                             |
| Figure 31. Mechanical HP simplified cycle52                                                                                                                                                                                                                                                                             |
| Figure 32. Temperature changes through the compression stage reported from the literature.<br>54                                                                                                                                                                                                                        |
| Figure 33. Working fluids influence on the COP.<br>56                                                                                                                                                                                                                                                                   |
| Figure 34. ΔTLift<br>vs COP for selected studies in the literature. Circle size depends on the<br>maximum temperature (T2)57                                                                                                                                                                                            |
| Figure 35. Temperature lift achieved using ChHPs62                                                                                                                                                                                                                                                                      |
| Figure 36. Expected lifetime of commercial compressors relative to capacity (sourced from [43]).<br>67                                                                                                                                                                                                                  |
| Figure 37. The compatibility between working fluid selection and application (adapted from [43]).<br>69                                                                                                                                                                                                                 |
| Figure 38. Comparison of isentropic exponent (Cp/Cv) for GCHP working fluids71                                                                                                                                                                                                                                          |
| Figure 39. Integration of heat pump with TES (PTES for combined heat and power production).<br>75                                                                                                                                                                                                                       |
| Figure 40. A conceptual drawing of cascade HP cycle77                                                                                                                                                                                                                                                                   |
| Figure 41. Comparison of temperature profile during heat rejection depending on HP cycles,<br>subcritical operation (left) vs. transcritical or supercritical operation (right) (from [38])78                                                                                                                           |
| Figure 42. Vapor compression cycle with two stage and flash tank using ammonia82                                                                                                                                                                                                                                        |
| Figure 43. P-H diagram for vapor compression cycle with two stage and intercooler using<br>ammonia.<br>83                                                                                                                                                                                                               |
| Figure 44. P-H diagram for vapor compression cycle with two stage and intercooler using<br>Diphenyl ether-biphenyl (Dowtherm A)83                                                                                                                                                                                       |
| Figure 45. Vapor compression cycle with single-stage intermediate heat exchanger using<br>synthetic oil84                                                                                                                                                                                                               |
| Figure 46. H-P graph for vapor compression cycle with single-stage intermediate heat exchanger.<br>85                                                                                                                                                                                                                   |
| Figure 47. parametric study for vapor compression cycle with single-stage intermediate heat<br>exchanger. (left) COP as a function of temperature of heat sink at different discharging<br>pressure and (right) temperature where the COP<br>drop suddenly at different discharging<br>pressure and corresponding COP85 |
| Figure 48. Chemical equilibrium curve as a function of temperature and suggested operating<br>conditions for the reactors in ChHP87                                                                                                                                                                                     |

| Figure 49. Process flow diagram and simulation results of ChHP using CaO-Ca(OH)2<br>reactions<br>without inert gas.<br>88 |  |
|---------------------------------------------------------------------------------------------------------------------------|--|
| Figure 50. Process flow diagram of ChHP using CaO-Ca(OH)2<br>reactions with inert and<br>simulation results89             |  |
| Figure 51. Flow diagram of ammonia VCHP for dynamic simulation90                                                          |  |
| Figure 52. Preliminary dynamic simulation result, temperature control at stream S491                                      |  |

## **TABLES**

| Table 1. Organic and synthetic fluids potentially available for UHTHP applications8                                                                                                   |    |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----|
| Table 2. Existing studies investigating the optimal selection of components for (V)HTHP and<br>their performance impact on the VCHP systems10                                         |    |
| Table 3. High-temperature VCHP studies using fluid mixtures as working fluid (reversed Kalina<br>cycle).<br>13                                                                        |    |
| Table 4. Fluids available for UHT for Stirling engine and HP applications21                                                                                                           |    |
| Table 5. Studies investigating the optimal components selection and operation for HTHP/VHT<br>HP/applications and their performance impact on the high-temperature Stirling systems23 |    |
| Table 6. Identified Stirling engines and Stirling HPs companies with the potential of UHT<br>applications24                                                                           |    |
| Table 7. Clean thermal energy sources.<br>28                                                                                                                                          |    |
| Table 8. Specifications of the reactor30                                                                                                                                              |    |
| Table 9. The equilibrium relation between pressure and temperature.<br>43                                                                                                             |    |
| Table 10. Equilibrium relationships for hydroxide systems.<br>46                                                                                                                      |    |
| Table 11. Rate equations of dehydration-hydration reactions of Ca(OH)2-CaO.<br>47                                                                                                     |    |
| Table 12. Kinetic parameters of carbonation reaction over three different temperature ranges.                                                                                         | 48 |
| Table 13. ChHP operating conditions and characteristics [127]49                                                                                                                       |    |
| Table 14. Types of HPs and technology gaps [127].<br>49                                                                                                                               |    |
| Table 15. MDHP technologies for UHT application.<br>58                                                                                                                                |    |
| Table 16. ChHP technologies for UHT application61                                                                                                                                     |    |
| Table 17. Compressors found in the literature/commercial market for UHTHP applications64                                                                                              |    |
| Table 18. High-temperature lubricants potentially available for UHTHP applications66                                                                                                  |    |
| Table 19. Potential challenges of working fluids for VCHP cycle and possible improvement (data<br>has been collected, adapted, and expanded from References [28,29,37]).<br>69        |    |
| Table 20. Potential benefits and challenges of working fluids for GCHP cycle72                                                                                                        |    |
| Table 21. PTES studies integrating UHPHP with TES76                                                                                                                                   |    |
| Table 22. COP of the pump for different temperature of heat sink.<br>89                                                                                                               |    |

*Page intentionally left blank*

## **ACRONYMS**

<span id="page-13-0"></span>ACHP Absorption-Compression Heat Pump

ASME American Society of Mechanical Engineers

BPVC Boiling and Pressure Vessel Code

COP Coefficient of Performance

COPch Coefficient of performance for chemical heat pump

ChHP Chemical Heat Pump

GCHP Gas Compression Heat Pump GWP Global Warming Potential

HP Heat Pump

HTF Heat Transfer Fluid

HTHP High Temperature Heat Pump HTMH High Temperature Metal Hydride

IES Integrated Energy System

LTMH Low-Temperature Metal Hydride

MARVEL Microreactor Applications Research Validation and Evaluation

MDHP Mechanically Driven Heat Pump

MH Metal Hydride

MHTES Metal Hydride-based Thermal Energy Storage NASA National Aeronautics and Space Administration

ODP Ozone Depletion Potential ORC Organic Rankine Cycle

PTES Pumped Thermal Energy Storage sCO<sup>2</sup> Supercritical Carbon Dioxide r-SRC Reversed Steam Rankine Cycle r-ORC Reversed Organic Rankine Cycle

SRC Steam Rankine Cycle

TCES Thermochemical Energy Storage TDHP Thermally Driven Heat Pump

TES Thermal Energy Storage TRL Technical Readiness Level UHT Ultra-High Temperature

UHTHP Ultra-High Temperature Heat Pump VHTHP Very High Temperature Heat Pump

#### VCHP Vapor Compression Heat Pump

*Units*

C<sup>p</sup> Specific heat at constant pressure [J/kg-K] C<sup>v</sup> Specific heat at constant volume [J/kg-K] P<sup>1</sup> Pressure at compressor inlet (suction) [bar] P<sup>2</sup> Pressure at compressor outlet (discharge) [bar]

Pmax Maximum pressure in the system [bar]

Pcrit Critical pressure [bar] ΔTlift Temperature lift [℃]

T<sup>1</sup> Temperature at compressor inlet (suction) [℃]

T<sup>2</sup> Temperature at compressor outlet (discharge) [℃]

Tcrit Critical temperature [℃]

Tsource Heat source temperature [℃] Tsink Heat sink temperature [℃]

VHC Volumetric heating capacity [J/m<sup>3</sup> -K]

#### *Greeks*

γ Isentropic exponent (=Cp/Cv)

#### *Subscripts*

*l* Low *h* High *Page intentionally left blank*

## **Investigation of Heat Pump Technologies with Potential for Ultra-High Temperature Applications**

## **1 INTRODUCTION**

<span id="page-16-0"></span>Transforming carbon-intensive industries, such as manufacturing, into carbon neutrality necessitates a reduction in CO<sup>2</sup> emissions from combustion used to supply process heat. To achieve net-zero emissions by 2050, significant shifts in the energy supply within industrial sector are imperative. High-temperature heat pumps (HTHPs), a low-carbon technology, have significant potential as a sustainable alternative to combustion heating, in terms of reducing CO<sup>2</sup> emissions and enhancing energy utilization efficiency.

Of particular interest in this study is the potential opportunity for decarbonizing industrial processes, especially those involving high-temperature process heat, through HTHP technologies. [Figure 1](#page-17-0) (top) shows the primary energy-related CO<sup>2</sup> emissions in the United States (U.S.) by end-use sector, with the U.S. industrial sector contributing approximately 30% of the total CO<sup>2</sup> emissions. In addition[, Figure 1](#page-17-0) (bottom) compares the process heat temperature demands for the five most carbon-intensive manufacturing subsectors, which collectively contribute to over 50% of the energy-related CO<sup>2</sup> emissions in the U.S. industrial sector [1]. According to a report by International Energy Agency [2], about 30% of global industrial process heat demand comes from "low-temperature" applications (below 150°C), 22% from "medium-temperature" processes (150°C–400°C), and the remaining 48% from "high-temperature" processes (above 400°C). This suggests that, in the context of industrial decarbonization, addressing hightemperature industrial processes, although more challenging, is just as significant as addressing low- and medium-temperature industrial processes.

Heat pumps (HPs) used in industries are usually utilized to elevate temperature of wasted (or unused) heat to a temperature level where it becomes more valuable, while offering cost savings and low-carbon heating methods compared to alternatives, such as gas-fired boilers or electric heaters. HPs achieve this by capturing waste heat, replacing purchased energy, or reducing overall energy expenses in industrial processes. A HTHP is a technology that could reduce reliance on fossil fuels by offering a sustainable way to effectively harness heat derived from low-carbon resources, such as nuclear, solar, and wind. Another potential is that it can serve as a demand-side response and management tool to promote decarbonization by enhancing the flexibility of low-carbon source utilization.

However, augmenting heat using HPs entails inevitable costs, as it requires external energy input such as electricity or heat. For the commercial implementation of HTHP, it is therefore crucial to develop HP systems in a way that ensures the benefits gained from using a HP outweigh the associated costs. The cost-effectiveness of a HP is determined by various factors, including the cost of external energy source (e.g., electricity), capital investment (including the expenses related to equipment, installation, and infrastructure modifications), turbomachinery efficiency, heat exchanger efficiency, and system operating conditions and requirements, such as temperature, pressure, and target temperature lift (ΔTlift).

![](_page_17_Figure_0.jpeg)

![](_page_17_Figure_2.jpeg)

<span id="page-17-0"></span>Figure 1. CO<sup>2</sup> emissions from U.S. primary energy-related end-use sectors (as of 2021, top), and distribution of process heat temperature demand by industrial subsectors in 2014 (bottom) [1].

HP technology is well established for supplying heat to industrial processes at temperatures below 100℃ [3]. Recent commercial HTHPs have capabilities to increase heat supply temperatures (or Tsink) up to 160℃–200℃ or higher [4,5]. However, despite the growing interest in HTHP technology, the majority of recent studies and state-of-the-art commercial HP technologies address heat supply temperatures of at most 200℃–250℃ or less. To date, there have been few adoptions of HTHPs within industry that handle temperatures above 250℃, which is the main focus of this study. The primary reason behind this is that, as heat sink temperature rises, not only may the performance (or efficiency) of HPs be limited, but it can also lead to challenges with components (such as compressor and heat exchanger) or material. [Figure 2](#page-18-0) illustrates the varying Carnot coefficient of performance (COP) as a function of heat sink temperature (Tsink) for the various specified heat source temperatures (Tsource). This shows how the HP performance (i.e., COP) can degrade substantially depending on the heat sink temperature. However, this can also be interpreted that COP can be greatly improved as the heat source temperature rises for a given heat sink temperature. That said, a HP may operate with enhanced performance even at high temperatures if high temperature heat sources are available, such as high-grade industrial waste heat.

![](_page_18_Figure_0.jpeg)

<span id="page-18-0"></span>Figure 2. Carnot COP as a function of heat source and heat sink temperatures.

Recent growing interest in HP technology, especially for augmenting heat above 250℃, is related to the growing demand for decarbonizing high-temperature industrial processes. As described in Reference [1], the industrial sector is deemed a "difficult-to-decarbonize" sector of the energy economy. This is related to the fact that a diverse temperature range of energy inputs are required by a wide array of industrial processes and operations. One of the critical challenges in industrial decarbonization is that, while industrial heat demand is distributed over a wide temperature range from low to extremely high temperatures, the temperature range of heat directly available from low-carbon energy sources such as nuclear and solar heat energy is limited. For example, if a light-water nuclear reactor, producing heat at around 300℃, is employed in an industrial process, its application would be confined to the lowtemperature processes (T<300℃). This means that it cannot be used directly for higher temperature processes requiring heat above 400℃ that account for about 50% of the global industrial process heat demand [2]. This challenge, however, can be mitigated or addressed if HTHP technology can be utilized to upgrade the heat from low-carbon sources to a higher temperature level that meets the hightemperature heat demand, especially when the heat supply and heat demand temperatures do not match.

This study focuses specifically on HTHP technology aiming to elevate the heat sink temperature above 250℃, which we term an ultra-high-temperature heat pump (UHTHP). The critical benefits that UHTHP technology can bring to the overall energy economy can be summarized in three key aspects:

- UHTHP allows for the recovery and recycling of low-grade waste heat derived from low-carbon energy sources, such as nuclear and solar heat, which contributes to energy saving, improved energy utilization, and enhanced decarbonization by maximizing the use of low-carbon energy sources.
- UHTHP enables the augmentation of excess or unused heat produced from low-carbon energy sources to higher grade heat (T>400℃), extending its value to high-temperature industrial processes.
- UHTHP systems have the potential to enhance the overall efficiency of industrial processes by effectively harnessing and upgrading waste heat, reducing the need for primary energy sources, such as carbon-based fuels, and lowering CO<sup>2</sup> emissions.

Taken together, UHTHP technology holds a great potential to advance the decarbonization of the entire energy economy, particularly high-temperature industrial processes, by optimizing the utilization of low-carbon energy sources and enhancing their flexibility. Nevertheless, UHTHP is an emerging technology that has yet to see widespread adoption in the commercial market.

The main objective of this study is to investigate HP technologies, including both mechanically and thermally driven HP systems, focusing particularly on those applicable to UHTHP. In particular, efforts were made to pinpoint technical gaps and challenges that have hindered the widespread application of this technology and explore potential improvements and solutions to address the current challenges, thereby laying the ground for future research endeavors for UHTHP systems.

This report is organized as follows. Sectio[n 2](#page-19-0) clarifies further the current research scope of UHTHP, especially in comparison to existing industrial HP technologies. We then review the HP technologies having a potential to be developed and utilized as UHTHP, including both mechanical and chemical HP technologies. Section [3](#page-65-0) summarizes the literature review findings and performs comparisons among various HP technologies in terms of temperature range, performance, technological readiness, etc. In Sectio[n 4,](#page-78-0) specific technical gaps and challenges that have prevented the commercial deployment of UHTHP are discussed. Additionally, potential improvements and solutions to address or mitigate the current challenges are explored, along with the associated research and development needs. Sectio[n 5](#page-96-3) describes preliminary modeling efforts performed during this fiscal year for both mechanical and chemical HP systems. Finally, this report concludes by summarizing the results from the current reviews and modeling efforts, as well as outlining the future research prospects for UHTHPs.

## **2 ULTRA-HIGH TEMPERATURE HEAT PUMPS**

<span id="page-19-0"></span>Our particular focus is the HP technology aimed at elevating heat supply (or heat sink) temperature beyond 250℃, which we call UHTHP. This exceeds the temperature ranges commonly addressed in the literature for HTHPs as well as the typical capabilities of commercial HP systems. The term 'high temperature heat pump (HTHP)' is commonly used in the context of industrial HP, primarily for recovering waste heat in process heating applications. However, there is a lack of consistency in the literature as to what temperature range the HTHP specifically covers. To provide clarity, we present [Figure 3](#page-20-0) based on the HP classification by temperature proposed in recent papers [6,7], offering a visual representation of the current research interest compared to existing HTHP studies. It should be noted, however, that, despite the classification between HTHP and very-high-temperature heat pump (VHTHP) shown in [Figure 3,](#page-20-0) this study does not make this distinction, and only assumes the heat sink temperature of 250℃ as a boundary for classifying an UHTHP.

[Figure 4](#page-20-1) breaks down the various types of HP systems for potential UHTHP applications. Between open- and closed-cycle HP systems, the current focus is on closed-cycle HP systems, as this type has been most widely used and offers a wide range of sizes suitable for various HP applications [7,8].

The following two subsections, Sections [2.1](#page-21-0) and [2.2,](#page-40-0) discuss various HP technologies under the category of mechanically driven heat pumps (MDHP) and thermally driven heat pumps (TDHP), respectively, including the fundamental working principles, technical potentials and limitations in the context of ultra-high temperature (UHT) heat pumping application.

![](_page_20_Figure_0.jpeg)

<span id="page-20-0"></span>Figure 3. Classification of heat pumps by temperature (adapted and expanded from References [6,7]), HP: conventional HP, HTHP: high-temperature HP, VHTHP: very-high-temperature HP, UHTHP: ultrahigh-temperature HP. No distinction is made between HTHP and VHTHP in this study.

![](_page_20_Figure_2.jpeg)

<span id="page-20-1"></span>Figure 4. Classification of HPs for ultra-high-temperature applications.

## **2.1 Mechanically Driven Heat Pump**

<span id="page-21-0"></span>MDHP refers to a specific category of HPs that utilize mechanical work, typically provided by external power source (electricity), to transfer heat from a lower temperature heat source to a higher temperature heat sink. The MDHPs operate based on thermodynamic cycles. In the context of UHT applications, where the heat sink temperatures exceed 250℃, largely two distinct thermodynamic cycles can be considered for MDHP and have been studied in literature: (i) vapor compression heat pump (VCHP) cycle and (ii) gas compression heat pump (GCHP) cycle (including Stirling HP cycle). As discussed, VCHP and GCHP cycles are distinguished depending on whether a working fluid undergoes phase changes in the process of transferring heat throughout the HP cycle.

[Figure 5](#page-21-1) shows the relevant operating temperature and capacity ranges of various thermodynamic "power" cycles, providing an insight into how heat sources at different temperatures can combine with the power cycles capable of producing different levels of capacity. This plot was originally created by Liu et al. [9], which we revised later by incorporating insights gained from recent studies regarding the possible operating temperature of the organic Rankine and Kalina power cycles [10,11]. Considering that HP cycles are the reverse of thermodynamic power cycles, the operating temperatures and capacities of MDHP cycles may, at least theoretically, exhibit similar characteristics to those of power cycles shown in [Figure 5.](#page-21-1) However, the current state-of the-art MDHP technology, including commercial HP products, is predominantly limited to heat sink temperatures (Tsink) below 200℃ [3,12]. The primary hindrance to its widespread application in UHT scenarios (T>250℃) lies in the challenges posed by components and the limited HP performance at such high temperatures (which will be detailed in Section [4\)](#page-78-0). Research on MDHPs targeting heat sink temperatures above 250℃ is still very limited. Only recently has this area begun to attract attention as a potential alternative for decarbonizing industrial heating processes [13,14].

![](_page_21_Figure_3.jpeg)

<span id="page-21-1"></span>Figure 5. Comparing temperature levels and scales of thermodynamic power cycles (adapted and revised from Reference [9]<sup>1</sup> ).

<sup>1</sup> Note that the maximum available temperature for organic Rankine and Kalina cycles have been revised based on findings in other literature, such as Vescovo et al. (2017) and Hossain et al. (2021).

In the following subsections under Sectio[n 2.1,](#page-21-0) we investigate MDHP technology, encompassing VCHP and GCHP. These are further subdivided based on the thermodynamic cycles involved, as illustrated in [Figure 4.](#page-20-1) The primary concern of each following subsection is the feasibility, technical challenge, and potential of each HP type as an UHTHP. To ensure a coherent discussion, each subsection is structured in the following sequence: (i) working principle, (ii) working fluid, (iii) operating temperature (Tsource/Tsink), (iv) performance, (v) heating capacity, (vi) capital investment, and (vii) technical challenges and gaps.

#### <span id="page-22-0"></span>**2.1.1 Vapor Compression Heat Pumps**

VCHP is a type of MDHP that operates based on the vapor compression (thermodynamic) cycle to transfer heat from a lower temperature heat source to a higher temperature heat sink. It typically operates by circulating a working fluid through a closed loop system, utilizing phase change (i.e., evaporation and condensation) to exchange heat with an external heat source or heat sink. VCHPs are currently the most prevalent and widely employed method among the HP systems utilized in commercial applications. Many recent studies on UHT applications of HPs or power cycles are also being conducted on this basis [10,12,15,16]. UHTHPs that fall within this category of VCHP operate based on reversed Rankine cycles (Section [2.1.1.1\)](#page-22-1) or reversed Kalina cycle (Section [2.1.1.2\)](#page-27-0)', each of which is detailed in the following subsections.

#### <span id="page-22-1"></span>**2.1.1.1 Reversed Rankine Cycles**

#### *2.1.1.1.1 Working Principle*

VCHPs operating on the reversed Rankine cycle are divided into two types, reversed steam Rankine cycle (r-SRC) and reversed organic Rankine cycle (r-ORC), depending on the working fluid adopted within the HP cycle, and commonly encompass four main processes: compression, condensation (heat rejection), expansion, and evaporation (heat absorption). Specifically, in a reversed Rankine cycle, a working fluid is compressed by a compressor to higher temperature and pressure (compression) and then passed through a heat exchanger where it releases absorbed heat to a higher temperature sink (heat rejection). After that, the working fluid expands through a turbine (expansion), which converts thermal energy into mechanical energy and cools the working fluid. The fluid then passes through another heat exchanger where it absorbs heat from a lower temperature source (heat absorption). The cycle then repeats.

HTHPs utilizing reversed Rankine cycles typically operate on subcritical or transcritical cycles. For an UHT application (Tsink >250℃), subcritical cycles require working fluids with high critical temperatures. On the other hand, transcritical cycles intentionally compress working fluids above the critical points to dissipate heat in a gas cooler instead of a condenser.

#### *2.1.1.1.2 Working Fluid*

Working fluids for the VCHPs using a reversed Rankine cycle can be found in studies investigating the working fluids for the steam and organic Rankine power cycles (hereafter, SRC and ORC).

SRCs, commonly used in large power plants, employ water as the working fluid. ORCs, however, deviate from this norm by utilizing working fluids other than water. In scenarios where heat sources are at lower temperatures and for smaller-scale power plants (usually under 1 MW), opting for organic or synthetic fluids can be advantageous compared to using water. This is because those fluids allow effective heat absorption and rejection through phase changes at lower or higher temperatures than water to improve the overall thermodynamic cycle performance. In other words, organic or synthetic fluids can be

selected as the working fluid and tailored to specific temperature ranges and requirements to optimize the Rankine cycle efficiency for a given heat source.

For the working fluids relevant to the ORCs, a comprehensive review of the potential candidate fluids is provided by Bao et al. [17]. To date, commercially available ORC technology is generally limited by the thermal stability limits of the organic or synthetic fluids of up to approximately 300℃ [10]. For UHTHP or power cycles applications (T>250℃), a very limited number of fluids have been reported to be available, which are summarized in [Table 1.](#page-23-0)

The working fluids for application to a specific ORC must be selected by taking into account multiple factors and criteria. These include critical temperature and pressure, saturation temperature and pressure, heat transfer capability (e.g., volumetric heating capacity), long-term chemical and thermal stability, compatibility with the system operational conditions and requirements, cost, heat source and sink types, environmental impacts (i.e., global warming potential [GWP], ozone depletion potential [ODP]), and potential safety issues. The systematic process for the working fluids selection, optimization, and associated studies are well presented in References [18–20].

<span id="page-23-0"></span>Table 1. Organic and synthetic fluids potentially available for UHTHP applications.

| Working Fluid                     | Max<br>Operating<br>Temp. [℃] | Tcrit<br>[℃] | Pcrit<br>[bar] | Boiling<br>Temp.<br>(at 1<br>bar)<br>[℃] | Reference |
|-----------------------------------|-------------------------------|--------------|----------------|------------------------------------------|-----------|
| Octamethyltrisiloxane<br>(MDM)    | 290                           | 291          | 14.1           | 153                                      | [10,21]   |
| Hexamethyldisiloxane<br>(MM)      | 290                           | 246          | 19.4           | 100                                      | [10,21]   |
| Toluene                           | 300                           | 318          | 41.3           | 110                                      | [21]      |
| Cyclopentane                      | 3002                          | 238.6        | 45.1           | 49.2                                     | [10,21]   |
| Dowtherm A                        | 400                           | 497          | 31.3           | 257                                      | [21,22]   |
| Titanium tetrabromide<br>(TiBr4)  | 3<br>380                      | 522.6        | 62.7           | 230                                      | [16,23]   |
| Titanium tetrachloride<br>(TiCl4) | 500                           | 364.9        | 46.6           | 135.9                                    | [24]      |

#### *2.1.1.1.3 Operation Temperature (Tsource and Tsink)*

There are several studies for high-temperature VCHP using water as working fluid (i.e., r-SRC). However, most studies belong to the group of HTHP or VHTHP [\(Figure 3\)](#page-20-0) with Tsink up to about 200℃ [6,25–27], and it is hard to find studies for UHTHP application in the existing literature. Theoretically, water can be used to achieve heat pumping above 250℃ in VCHP systems. This is due to the thermodynamic properties of water, including its high critical temperature and pressure (373.9℃, 220 bar). Also, the water-based Rankine cycle (SRC) is well established for the power generation cycle and has widely been employed in large power plants with high-temperature heat sources above 300℃ [9]. Therefore, this can provide a valuable technical basis for water-based UHTHP systems.

<sup>2</sup> Note, however, that, in Pasetti et al. (2014), Cyclopentane exhibited a decomposition rate greater than 1 %/year at 275℃, which was regarded as the upper temperature limit that maintained its thermal stability.

<sup>3</sup> This value is based on the experimental demonstration conducted by Anderson (2010), observing the thermochemical stability of TiBr<sup>4</sup> at 380℃ for a duration of 3,000 hours while in contact with pure titanium.

Nonetheless, there are several practical challenges to address in order to use a water-based VCHP for UHTHP applications, especially when they are combined with a high-temperature heat source. The practical challenges include high compression ratio, high pressure and temperature at compressor discharge, low water vapor density leading to high swept volume and reduced heat transfer efficiency [28,29]. Note that the high pressure may significantly restrict the temperatures that can be employed by a HP system due to the material limitations, such as creep. The creep limitation has prevented conventional carbon steels from being used in high-pressure thermal applications at temperatures above 427℃ [30]. The specific challenges and possible improvement for water-based VCHP systems, especially for UHT applications, will be discussed more in comparison with other HP systems in Section [4.1.](#page-78-1)

VCHP using organic or synthetic fluids (i.e., r-ORC) can also offer heat pumping solution for UHTHP application, while mitigating the above-mentioned challenges that can occur with water-based VCHPs. The upper temperature limit of r-ORC is usually limited by the maximum working fluid operating temperatures to prevent chemical decomposition. The working fluids for r-ORC or ORC typically have favorable thermophysical properties that facilitate efficient heat transfer and energy conversion at T<300℃. However, there are some recent studies to extend the application temperature range of ORC beyond 300℃ [10,21,24,31]. The main motivation of these studies is that ORCs can achieve higher efficiencies than SRCs depending on a given heat source temperature [21]. Another advantage is that ORC can operate at lower pressures to achieve the same operating temperature as SRC, leading to reduced installation, operating, and maintenance costs of the overall HP system [32]. Up to now, the primary focus of these studies has centered on enhancing the power production efficiency of ORCs by employing working fluids having high thermal stability at T>300℃. However, the same principle can also be applied to the VCHPs using reversed Rankine cycle.

As a part of the current effort, we built a HP model for preliminary study using Dowtherm A, one of the high-temperature fluids listed in [Table 1.](#page-23-0) This model showcased the technical feasibility of the UHTHP cycle supplying heat above 300℃ based on r-ORC, operating at a maximum pressure of 20 bar. Further elaboration on the modeling effort will be provided in Sectio[n 5.](#page-96-3)

#### *2.1.1.1.4 Performance (COP)*

The performance of VCHPs using reversed Rankine cycles depends on various factors that are often interdependent to each other. Among these factors, key considerations include the availability and quality of the heat source (Tsource), heat sink temperature (Tsink), temperature lift (ΔTlift), efficiency of the key components (e.g., compressor, heat exchanger), working fluid type, material compatibility, heat loss, and HP cycle configuration. In UHT applications, the selection of suitable components—such as compressor, heat exchanger, and working fluid—is particularly important, along with the configuration of the HP system itself. Consequently, many studies have focused on investigating the impact of these factors on VCHP performance [19,20,29]. However, the majority of those studies have been carried out at temperatures lower than the particular interest of this study (T>250℃).

COP and volumetric heating capacity (VHC) are common metrics used when evaluating VCHP performance, size of a VCHP system, and associated costs. While COP is not a direct measure of cost, it is used to assess the energy efficiency of a HP system, which naturally impacts operational costs over time. VHC is also important for evaluating how efficiently a HP can transfer heat while minimizing the footprint and capital investment. Inevitably, these two metrics are heavily influenced by the performance and efficiency of the key components within a VCHP system, specifically the compressor, heat exchanger, and working fluid. Likewise, the system operating conditions and performance target, such as heat source and sink temperatures, heating capacity, and material compatibility, can significantly impact the selection of those components for a high-temperature VCHP.

[Table 2](#page-25-0) summarizes multiple studies focusing on the optimal selection of the key components and their impact on the overall performance of high-temperature VCHPs. Most of the studies shown in Table 2 belong to the group of HTHP or VHTHP operating at a lower temperature range than the UHTHP (see [Figure 3\)](#page-20-0), due to the scarcity of research focusing directly on the UHT applications.

<span id="page-25-0"></span>Table 2. Existing studies investigating the optimal selection of components for (V)HTHP and their

performance impact on the VCHP systems

| Authors                               | Compressor | Working<br>fluid | Heat<br>exchanger | Summary                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|---------------------------------------|------------|------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Bertinat<br>(1985) [33]               |            | √                |                   | -<br>Compare thermodynamic performance<br>of 250<br>potential working<br>fluids condensing at 150°C and<br>evaporating at 100°C.<br>-<br>Assume ideal vapor compression cycle.                                                                                                                                                                                                                                                                                                                              |
| Jiang et al.<br>(2022)<br>[34]        | √          | √                | √                 | -<br>First select working fluids<br>based on required Tsink,<br>then<br>choose<br>compressor<br>and<br>heat exchanger types<br>based on required heating capacity, and finally selects<br>VCHP<br>system<br>configuration<br>by efficiency requirement.<br>-<br>Consider four<br>different types of compressors and heat<br>exchangers, respectively.<br>-<br>Case studies include the cases<br>Tsink>160℃.                                                                                                 |
| Mairhofer et<br>al.<br>(2022)<br>[20] |            | √                |                   | -<br>Performance study<br>associated with<br>fluid selection<br>with upper bound<br>of<br>Tsink<230℃.<br>-<br>Identify the suitable working fluids<br>via optimization<br>of both COP and VHC.<br>-<br>Analyze<br>one-stage and two-stage cycles.                                                                                                                                                                                                                                                           |
| Frate et al.<br>(2019)<br>[19]        | √          | √                |                   | -<br>Performance investigation with<br>different working<br>fluids<br>with Tsink<br>up<br>to 150℃.<br>-<br>Preselect 27 fluids based on technical and<br>environmental limitations, then conduct performance<br>comparison (COP) for each combination of Tsrc<br>and<br>Tsink.<br>-<br>Analyze different compressor technologies<br>depending<br>on VCHP size.                                                                                                                                              |
| Degueurce et<br>al. (1984)<br>[35]    | √          |                  |                   | -<br>Performance experimental testing of<br>steam<br>compressors<br>(Tsink<br>up to 246℃).<br>-<br>Oil-free twin<br>screw compressor.                                                                                                                                                                                                                                                                                                                                                                       |
| Tamura<br>et al.<br>(1997)<br>[36]    | √          | √                |                   | -<br>Analytical<br>study of<br>high-temperature HP<br>system with<br>Tsink<br>up<br>to 180℃.<br>-<br>Use<br>water, steam,<br>and ammonia<br>as working fluids<br>with a screw-type compressor.                                                                                                                                                                                                                                                                                                              |
| Sarkar et al.<br>(2007)<br>[37]       |            | √                |                   | -<br>Theoretical<br>and computational<br>analyses of subcritical<br>and transcritical VCHP<br>cycles, with<br>a heating target of<br>Tsink<br>up to 200℃.<br>-<br>Optimize compressor discharge pressures to<br>maximize COP.<br>-<br>Performance impact of<br>four different natural fluids:<br>CO2, ammonia, propane, and isobutane.<br>-<br>Compare heat transfer performance<br>of four<br>working<br>fluids,<br>influencing<br>the heat exchanger<br>dimensions and<br>weight<br>for a given capacity. |

| Vieren et al.<br>(2023)<br>[38]                 |   | √ | √ | -<br>Analysis includes case<br>studies<br>with Tsink<br>up to 300℃<br>(COP<br>around three).<br>-<br>Performance comparison<br>of both subcritical and<br>transcritical HTHP cycles with various working fluids<br>and large temperature glides.                                                                                                                                                                                                                                                                                                                                                                                                                         |
|-------------------------------------------------|---|---|---|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Kondou et al.<br>(2015)<br>[39]                 | √ | √ | √ | -<br>Performance comparison<br>with four<br>different working<br>fluids,<br>R717, R365mfc, R1234ze(E), and R1234ze(Z),<br>with a heating target from Tsrc=80℃ to<br>Tsink<br>=160℃.<br>-<br>Investigate the effects of compressor efficiency and<br>heat exchanger size<br>on the VCHP performance<br>(COP).<br>-<br>Employ multiple-stage extraction cycle<br>to<br>reduce the<br>throttling loss in the expansion valve and the exergy<br>loss in the condensers, resulting in<br>the<br>increase in<br>COP.                                                                                                                                                           |
| Aapagaus et<br>al.<br>(2018,<br>2020)<br>[7,40] | √ | √ |   | -<br>Transcritical HTHP cycles with Tsink<br>up to 200℃.<br>-<br>Analysis with low GWP refrigerants and<br>hydrocarbons.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Bergamini<br>et<br>al. (2019) [41]              |   | √ |   | -<br>Performance comparison of<br>three<br>different<br>HTHP<br>cycle configurations<br>(i.e., single-stage, double-stage,<br>and cascade<br>cycles)<br>using<br>four<br>different natural<br>refrigerants<br>(i.e., propane, isobutane, ammonia,<br>and<br>water).<br>-<br>Performance comparison based on<br>COP and exergy<br>efficiency.<br>-<br>Ammonia performed<br>best at<br>low source and sink<br>temperatures, while water<br>performed better at higher<br>temperature.<br>-<br>HTHP was found to be a competitive option for<br>replacing<br>boilers,<br>for heat supply temperature (Tsink)<br>up<br>to 180°C<br>with temperature lifts reaching<br>160°C. |
| Vieren et al.<br>[38]                           |   | √ | √ |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |

The performance of UHTHPs that employ various working principles, discussed in existing literature, will be discussed and compared in Section [3.](#page-65-0)

#### *2.1.1.1.5 Heating Capacity, Capital Investment, and Technical Challenges and Gaps*

The heating capacity of VCHP (using reversed Rankine cycle) is heavily influenced by the component capabilities employed within the HP system, including compressor, working fluid, and heat exchanger. In particular, the compressor performance at high temperature ranges and associated limitations are critical. To the best of our knowledge (as of 2023), current commercially available hightemperature compressors, using steam as a working fluid, can provide a heating capacity of up to about 15 MW (with discharge temperature and pressure up to 250℃ and 40 bar) [42,43]. This performance limit, however, may vary substantially depending on the working fluid selection and system operating conditions (e.g., Tsource/Tsink and required compression ratio). For example, CO<sup>2</sup> compressors typically used in oil and gas industry are known to be able to provide a heating capacity of 30–50 MW [15]. In general, for a large heating capacity (>1 MW) and volume flow rates, dynamic compressors, such as centrifugal and axial compressors, are suitable. Conversely, for smaller size heating applications, positive displacement compressors (e.g., scroll or rotary compressors) may be suitable [19,34]. The detailed technical gaps and challenges of compressor technology for UHTHP application are intensively discussed in Section [4.1.1.](#page-78-2)

The capital investment of a VCHP for UHT applications is heavily influenced by the system operating target, such as required system pressure, temperature, and working fluid, in addition to the cost of the components used within the VCHP system. Comparing the VCHP systems using r-SRC and r-ORC, the former may require higher system pressure compared to the latter, especially when dealing with UHT heat sources (T>250℃). This is due to the fact that water needs a pressure of at least about 4 MPa or higher to boil at or above 250℃, whereas there are synthetic fluids, as shown in [Table 1,](#page-23-0) which can meet the boiling requirement at lower pressures. In addition, the low density of water vapor typically requires a large compression (or pressure) ratio and low volumetric efficiency [27]. This may increase the costs associated with construction, maintenance, and operation for water-based VCHP systems.

To precisely evaluate the capital investment of a UHTHP system, multiple factors must be taken into account, including the costs of critical components, operating performance, such as COP, VHC, exergy efficiency, and required system pressure. There are several studies investigating the economic aspects of high-temperature VCHPs, including the cost analysis of the key components in combination with the technical performance and efficiency of the overall HTHP systems [27,44,45]. However, there are no studies focusing directly on the VCHP systems for UHT application.

Technical challenges for applying VCHPs to UHT applications are primarily tied to component technology, especially the compressor. This will be intensively discussed in Section [4.](#page-78-0)

#### <span id="page-27-0"></span>**2.1.1.2 Reversed Kalina Cycle.**

#### *2.1.1.2.1 Working Principle*

VCHPs in this category refer to those that employ binary mixtures of fluids, as in the Kalina (power) cycle. Compared to conventional Rankine cycle, the Kalina cycle distinguishes itself by incorporating a binary mixture as the working fluid, which allows for boiling and condensation to occur over a range of temperatures throughout the thermodynamic cycle. This characteristic enables the Kalina cycle (or reversed Kalina cycle) to extract a greater amount of heat from the heat source (or deliver a greater amount of heat to the heat sink) compared to a system using a pure working fluid. The Kalina cycle is generally known for its potential to achieve higher thermal efficiency compared to the conventional Rankine cycle when combined with lower temperature heat sources. In high-temperature VCHPs using the reversed Kalina cycle, the use of binary mixtures can also provide additional benefits compared to using pure fluids, such as lowering compression ratios and reducing compressor outlet temperature [28,46].

A typical example of HPs utilizing the reversed Kalina cycle is the absorption-compression HP (ACHP). ACHP combines principles of both absorption and vapor compression HPs using a zeotropic mixture of ammonia and water as the working fluid [47]. Like the reversed Rankine cycle, the reversed Kalina cycle requires external mechanical work (e.g., electric motor-driven compressor) to provide the necessary compression and expansion of the working fluid.

#### *2.1.1.2.2 Working Fluid*

The ammonia-water (zeotropic) mixture is one of the most common mixtures used as working fluid for the VCHPs operating on the reversed Kalina cycle. Other types of fluid mixtures used in recent (V)HTHP studies include mixtures containing natural refrigerants (e.g., water, CO2, ammonia), hydrocarbons (e.g., butane, propane), and hydrofluoroolefins (HFO) [28,48]. A key advantage of using the fluid mixtures is the presence of what is called "temperature glide," which refers to the gradual change in temperature of a fluid mixture as it undergoes phase changes in heat exchangers (i.e., evaporator and condenser). Fluid mixtures allow for both the deliberate adjustment of thermodynamic properties of the

working fluids and strategic temperature matching with heat source or sink temperature profiles in order to achieve the minimization of exergy losses.

For the ammonia-water mixture, the feasibility has been successfully demonstrated in a Kalina power cycle operating at high temperatures above 500°C [49–51]. For other types of fluid mixtures, there is generally a significant lack of knowledge about which fluid mixtures can be used reliably above 200°C.

<span id="page-28-0"></span>Table 3. High-temperature VCHP studies using fluid mixtures as working fluid (reversed Kalina cycle).

| Author(s)                                  | Working fluid                                                                                                                                   | Maximum                | Research            | Summary                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|--------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|---------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| - Tutiloi(B)                               | Working Haid                                                                                                                                    | T <sub>sink</sub> [°C] | type                | •                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Abedini et al. (2023) [28]                 | Binary (zeotropic)<br>mixtures of natural<br>and synthetic working<br>fluids (e.g., water,<br>ammonia, CO <sub>2</sub> ,<br>hydrocarbons, HFO). | 4734                   | Simulation          | <ul> <li>HTHP (VCHP) study using binary mixtures as working fluid (zeotropic mixtures).</li> <li>Conduct optimization with HP operating conditions, mole fraction of binary mixtures, and cycle configuration to maximize COP.</li> <li>Case studies with three different combination of heat sources and sinks (i.e., latent/latent, latent/sensible, sensible/sensible).</li> <li>Most of the best performing mixtures were hydrocarbons with high risk of flammability.</li> <li>Incorporating an internal heat exchanger to the HP cycle significantly altered the choice of best performing mixtures.</li> <li>COP calculated using mixtures as working fluid ranges from 3.3 to 4.3.</li> </ul> |
| Fernandez-<br>Moreno et al.<br>(2022) [48] | Binary and tertiary<br>mixtures of<br>refrigerants.                                                                                             | 175                    | Simulation          | - Flammability was the most critical parameter that restricts the COP (mixing the flammable and non-flammable refrigerants reduced the COP) COP calculated using mixtures as working fluid ranges from 2.1 to 2.8.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Bamigbetan et al. (2016) [52]              | Ammonia,<br>hydrocarbons (i.e.,<br>propane, butane,<br>pentane), and their<br>zeotropic mixtures.                                               | 150                    | Simulation          | <ul> <li>Performance study of HTHPs using natural fluids and their mixtures.</li> <li>Hydrocarbon mixtures used in a cascade cycle showed higher COP of up to 13.5% compared to pure fluids.</li> <li>Optimizing mixture compositions prevented hydrocarbon limitations, such as subatmospheric evaporation, high discharge temperature and volume flow.</li> </ul>                                                                                                                                                                                                                                                                                                                                   |
| Zuhlsdorf et al. (2017) [53]               | Zeotropic mixtures<br>using Propane, Iso-<br>Butane, n-Butane, Iso-<br>Pentane, n-Pentane,<br>and n-Hexane.                                     | 130                    | Simulation          | - The best COP achieved with Propane/Iso-Pentane (50/50 wt%) mixture with COP=3.08 COP calculated using a range of mixtures ranges from 2.9 to 3.08.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Ahrens et al. (2021)                       | Ammonia/water.                                                                                                                                  | 115                    | Experiment (review) | - Analyze 23 experimental studies for ammonia/water-based ACHP for high-temperature heat supply up to 115°C Heating capacity range: 1.44500 kW COP range: 1.411.3.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Zhang et al.                               | Zeotropic mixtures                                                                                                                              | 110                    | Simulation          | - Using mixture (R1234zf/Propane (60/40 wt%))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |

<sup>&</sup>lt;sup>4</sup> This heat sink temperature was achieved with ammonia-water mixture (COP=3.48, compression ratio=12.5).

| (2010) | containing HFOs    | causes<br>higher COP with<br>a lower compressor  |
|--------|--------------------|--------------------------------------------------|
|        | (i.e., HFO-1234yf, | discharge temperature and a lower<br>compression |
|        | HFO-1234ze(z),     | ratio.                                           |
|        | HFO-1234ze(e) and  | -<br>COP range: 2.9̵4.2.                         |
|        | HFO-1234zf).       |                                                  |

#### *2.1.1.2.3 Operation Temperature (Tsource and Tsink)*

In the existing literature, there are very few studies for VCHP employing fluid mixtures (reversed Kalina cycle) to achieve UHT heat pumping above 250℃. Most of the HTHP studies in this category aims to achieve heat supply temperature (Tsink) below 200℃ [28,47,48], as shown in [Table 3](#page-28-0) that summarizes recent studies for (V)HTHP using fluid mixtures as working fluid.

However, as discussed above, the technical feasibility of ammonia-water mixtures have been proven for Kalina power cycle under very-high-temperature and pressure conditions (T>500°C, P>100 bar) [49– 51]. This implies that applying the ammonia-water mixture to UHTHP systems can also be possible, and the associated performance study can be a promising research subject.

#### *2.1.1.2.4 Performance (COP)*

UHTHP applications using fluid mixtures as the working fluid are scarce, but the (V)HTHP studies indicate that the theoretical performance represented by COP values tend to outperform the pure fluids in many cases. The COP values of (V)HTHP presented in the literature range between 2.5 and 4.5 (see [Table](#page-28-0)  [3\)](#page-28-0). This performance, however, may substantially depend on heat source and demand temperature profiles, level of temperature control required during heat transfer, and associated exergy loss [54].

#### *2.1.1.2.5 Heating Capacity, Capital Investment, and Technical Challenges and Gaps*

The heating capacity and overall cost of VCHPs under this category (using a reversed Kalina cycle) can be greatly impacted by the thermodynamic properties of the fluid mixtures employed, including the VHC, in addition to the component limits and capabilities discussed in Section [2.1.1.1.](#page-22-1) The technical challenges and gaps in applying fluid mixtures to UHTHP systems mainly come from the lack of knowledge (e.g., thermal stability, material compatibility) and experimental demonstration.

#### <span id="page-29-0"></span>**2.1.2 Gas Compression Heat Pumps**

In this study, HP cycles on which the fluid remains on a gaseous state not undergoing any phase change while in the loop are classified as gas compression HP (GCHP). Within this category, HPs based on the reversed Joule-Brayton cycle and Stirling engines will be included as a secondary classification.

#### <span id="page-29-1"></span>**2.1.2.1 Reversed Joule-Brayton Cycle**

Joule-Brayton cycles can be operated at high temperatures, the upper temperature limits of Braytonbased power cycles can reach up to or above 1000°C [12,55–58]. Hence, HP systems using the reversed Joule-Brayton cycle are considered as a candidate for the implementation of a UHTHP. Common Joule-Brayton cycle's working fluids may include nitrogen (N2), helium (He), argon (Ar), and mixture of gases such as air and CO2. From such diversity of working fluids, CO<sup>2</sup> has gain recent attention due to its high efficiency within the cycle. It is interesting to note that CO<sup>2</sup> as a working fluid has extensively been used in vapor compression cycles for refrigeration systems (subcritical cycles) and for low to VHTHPs

(transcritical and supercritical cycles). The usability of CO<sup>2</sup> for multiple temperature ranges makes CO2 based cycles a versatile option within the HP area [13,59–62].

#### *2.1.2.1.1 Working Principle*

The reverse Brayton cycle has previously been used for heating or cooling applications, either as a heat augmentation device (HP) or as a refrigerator. A HP cycle based on the reversed Brayton cycle is similar in design to a HP based on the reverse Rankine cycle (VCHP). However, the working fluid remains in a gaseous or supercritical state throughout the whole cycle [63]. A reversed Brayton cycle HP consists of four major components: a compressor, an expansion valve or turbine, and two heat exchangers (see [Figure 6](#page-30-0) (a)).

The heat exchangers may be either gas-to-gas or gas-to-liquid exchangers. One heat exchanger will work at low temperatures and pressures while the other at high temperatures and pressures. Typical temperature and pressure values will depend on the available heat source and final customer demands (heat sink).

It is worth noting that the compressor has been identified as a component that strongly influences the overall efficiency of the system. There are technical challenges especially due to the high temperatures and pressures and large mass flow rates required to satisfy demanding costumer goals. However, in the literature, some compressor options have been identified which will be summarized in Section [4.1.1.](#page-78-2)

As shown in [Figure 6](#page-30-0) (b), the working fluid (gas) undergoes an isentropic compression from Point 1 to 2. Subsequently, the working fluid deposits the gained energy to the industry process fluid. This energy exchange is through the high-pressure heat exchanger from Point 2 to 3. The gas is then expanded from Point 3 to 4 through either an expansion valve or a turbine. From Point 4 to 1, the working gas regains energy from an external energy source by going through the low-pressure heat exchanger.

![](_page_30_Figure_6.jpeg)

<span id="page-30-0"></span>Figure 6. Schematics of the ideal reverse Brayton cycle (a) components diagram and (b) temperature vs. entropy diagram.

#### *2.1.2.1.2 Working Fluids*

As previously mentioned, common gases used in the GCHPs (operating on reversed Brayton cycles) include carbon dioxide (CO2), air, helium (He), and others. From these options CO<sup>2</sup> has been extensively studied as a promising candidate on the reversed Brayton cycle configuration as a HP for refrigeration systems, for temperature augmentation, and for thermal energy storage, or, using the direct Brayton cycle, as a primary or secondary fluid for power generation. The thermodynamic properties of CO<sup>2</sup> are more aligned for its utilization on the superhigh temperature applications, which is the aim of this work. The benefits have been highlighted in many works including higher density at the temperatures and pressures required, low change of thermodynamic properties at high temperatures, low viscosity to reduce friction losses, high energy content, etc. [64]. For the sake of comparison, [Figure 7](#page-31-0) shows the critical pressure and temperatures of common gases and water. As shown in [Figure 7,](#page-31-0) most of gases become supercritical at low temperatures and pressures, However, CO<sup>2</sup> shows a relatively high critical temperature and pressure. The critical temperature of CO<sup>2</sup> can be seen as a benefit to the thermodynamic efficiency of HP cycles because it coincides with the values at which the CO<sup>2</sup> specific heat shows a maximum value, and the density is significantly higher than other gases. This can be seen in [Figure 8](#page-32-0) in which the volumetric heat capacity (ρCp) is shown. The volumetric heat capacity of CO<sup>2</sup> is significantly higher than other gases, moreover, for high temperatures (T>500℃) the volumetric heat capacity of CO<sup>2</sup> is larger than that of pure water. This characteristic allows for the design of smaller heat exchangers for the CO2-based HP cycle.

![](_page_31_Figure_2.jpeg)

<span id="page-31-0"></span>Figure 7. Comparison of critical temperatures and pressures of various gases and water.

![](_page_32_Figure_0.jpeg)

<span id="page-32-0"></span>Figure 8. Comparison of volumetric heat capacity of different gases and water.

#### *2.1.2.1.3 Operation Temperature (Tsource and Tsink)*

Brayton cycles have been used widely in the power industry because of their high temperature capabilities. For instance, the upper temperature limits of Brayton-based power cycles can reach over 1000°C with an unlimited variety of heat sources, such as VHTR reactors [58], hot gas furnaces [12,55], or concentrated solar collector [56,57]. Most of the power gas cycles are based on the Brayton cycle. However, HPs work in the reverse Brayton cycle configuration, hence the components working temperatures are reversed (i.e., for a power cycle the maximum temperature is located in the inlet of the turbine while for a HP cycle the maximum temperature will be located at the compressor outlet). Currently, gas turbines can withstand UHTs, but fewer options are available for gas compressors. Therefore, the maximum temperatures of reversed Brayton cycles are going to be dictated by the limiting operational conditions of the compressor. For example, a state-of-the-art air compressor has a maximum limiting operational temperature of about 600°C (see [Table 17\)](#page-79-0).

#### *2.1.2.1.4 Performance (COP)*

For an ideal reversed Brayton cycle HP, the simplest definition of the COP [13] is:

$$\text{COP}_{\text{Brayton}} = \frac{\dot{Q_{\text{H}}}}{\dot{W_{\text{C}}}} = \frac{\dot{q_{\text{h}}}}{\dot{q_{\text{h}}} - \dot{q_{\text{c}}}} = \frac{T_2}{T_2 - T_1}$$

As an example, [Figure 9](#page-33-1) shows the COP values of a HP based on the ideal reversed Brayton cycle as a function of different heat source temperatures. This figure shows the trend of a low COP for high sink temperatures, which also holds for the Rankine cycle HPs, and explains why high-temperature HPs tend to have a lower COP than those for domestic purpose and low temperatures. Nonetheless, if heat sources of higher quality are available, much higher COP values are expected (see [Figure 2\)](#page-18-0). This demonstrates the feasibility of augmenting the heat from low-carbon energy sources (e.g., nuclear and solar heat) for demanding industries.

![](_page_33_Figure_0.jpeg)

<span id="page-33-1"></span>Figure 9. Reverse Brayton cycle COP for high compressor outlet temperatures T2.

#### *2.1.2.1.5 Technical Readiness*

One may assign a high technical readiness for reversed Brayton cycle UHTHP by considering that the same basic components are found on high-yield power generation cycles that are also based in the Brayton cycles. This may be true for piping materials, heat exchangers, and expansion valves and turbines. These components had experienced decades of development pushed by the economical benefits of increasing the efficiencies and capabilities of such components. However, in reversed Brayton HPs, the most challenged component is the gas compressor. The compressor experiences the highest pressures and highest temperatures, which differs from the conditions of a regular Brayton cycle in which the compressor experiences the lowest temperatures in the cycle at much lower pressures. Hence, the technical readiness of a UHTHP is directly correlated to the availability of gas compressor technologies. This is further discussed in Section [4.1.1.](#page-78-2)

#### <span id="page-33-0"></span>**2.1.2.2 Stirling Heat Pumps**

Stirling heat pumps, theoretically, can handle similar pressures and temperatures as those experienced by Stirling engines. Hence, attributes considered for Stirling heat engines can be directly applied to Stirling heat pumps. Among those attractive attributes are their high operating temperatures, low maintenance, compactness, and efficiency. In this section, a more in-depth discussion on Stirling heat pumps is provided.

#### *2.1.2.2.1 Working Principle*

Stirling engines, as many other heat engines, receive heat from external sources and convert it to mechanical work, while rejecting non-used energy as low-temperature waste heat [65]. In the HP arena, a reversed Stirling cycle can be used for refrigeration or for heat augmentation. Machines based on the reversed Stirling cycle are currently receiving much attention for the UHTHP application because Stirling HPs can operate in any temperature regime within the capability of the construction material [65].

The operation of the Stirling HP may be viewed as a modified reversed Brayton cycle (see Section [2.1.2.1\)](#page-29-1) in which gas is compressed and heated through mechanical work for later expansion in a cyclic manner. Within this cycle, heat exchange is required for heat input and removal. Briefly, the operation of an idealized Stirling cycle is described as follows with [Figure 10:](#page-34-0)

- 1. The heat of the external energy source is transferred to the working gas in the heater. The heated working gas expands, pushing the working piston down.
- 2. The displacer moves the working gas from the expansion space to the compression space. The working gas moves towards the regenerator and the cooler, where it transfers the heat to an external coolant, up to the compression space where it is compressed (compression and cooling processes occur in the compression space).
- 3. Then, the working piston moves upwards, and the displacer moves downwards, resulting in the transfer of the gas from the cold volume to the hot volume, through the regenerator. During this process, the gas is heated by the regenerator material, assuming the regenerator as a perfect storage or releasing heat, the gas temperature at the end of this process regains temperature.

Thus, the cyclic pressure variations result in mechanical work[. Figure 10](#page-34-0) depicts one type of the multiple arrangements of Sterling engines, which differs with the classical arrangement on the piston crankshaft, which is replaced by an interior spring damping system. By this way, the movements of the displacer and the piston are independent and are only based on the pressure variation of the working gas.

![](_page_34_Picture_5.jpeg)

Figure 10. Idealized Stirling engine cycle.

<span id="page-34-0"></span>As can be inferred from the above description, the displacer is a no-working component simply displacing fluid from the compression space to the expansion space and vice versa, while the working piston can be seen as an analogous component to the compressor in a Brayton cycle.

Stirling HPs operate in the same way as the Sterling engine described above with the essential difference that the temperatures of the expansion space and compression space are switched by having the cooler interacting with the expansion space and the heater with the compression space, and hence, mechanical work is required to move the working piston.

#### *2.1.2.2.2 Working Fluids*

Traditionally, Stirling engines have been operated using gases, which can be considered ideal gases at a large range of temperatures and pressures. Examples of selected fluids for the efficient operation of Stirling engines are helium, nitrogen, and argon, which by virtue of their good thermophysical characteristics, allow the design of engines with high heat fluxes and moderate pressure losses. [66]. Even air has been used for simple engine designs for low specific power and speeds.

There have been successful efforts to use the Stirling cycle with working fluids in a liquid state, for example, the Malone engine. The Malone engine is similar in function to a regular Stirling hot air engine, but instead of using a gas through its cycle, the Malone engine uses a liquid working fluid through its cycle [67,68]. The Malone engine will not be covered in this review, and we will focus on the operation of Stirling cycles with gases as working fluids.

To compare Stirling engine performance depending on the type of ideal gas used, Saed et al. [69] studied air, nitrogen, and helium at a maximum temperature of about 930°C. It was concluded that Stirling engines can improve the output work by 10 fold only by switching from air to hydrogen. The advantage of hydrogen over air as a working fluid is further increased with increases in temperature. Hence hydrogen seems a valuable option for UHT applications. However, the high flammability of hydrogen has impaired its utilization in many applications, this explains the extended use towards safer options, such as helium.

Invernizzi et al. [66] compared the traditional gases with ideal gas behavior, with other gases with strong real-gas behavior. The results showed that the real gas effects at high reduced pressures are responsible for very high-power parameters in comparison with the values obtainable from cycles operating with ideal gases; in fact, real gases outperformed ideal gases by 2–3 times in the power parameter. These results were performed with source temperatures of about 340℃ and low temperatures in the vicinity of 1.1 times the critical temperature of the gas. Part of the conclusions at the given temperature ranges can be extended towards the application at UHT. For instance, for real gases to be competitive, high pressures are required, at least 100–300bar. The high pressures necessary are considered acceptable due to the benefits of using a low compressibility gas, which in turn translated in smaller engines. Again, this conclusion remains to be tested at higher source temperatures.

Another attempt to use gases with strong real-gas behavior in a Stirling cycle was performed by Alberti et al. [70]. One important conclusion of their research was that supercritical CO2 (sCO2) presented many challenges that hindered the Stirling engine performance. Their analysis was performed assuming maximum temperatures of the heat source of about 200°C–300°C, charging pressure of about 135 bar and minimum temperatures of 40°C to 60°C.

This apparent discrepancies on the use of non-ideal gases (such as CO2) points to the case-by-case scenarios in which at given "system conditions" real gases will outperform ideal gases. These "system condition" thresholds are not yet understood and in need of further investigation. Nevertheless, researchers had explored the feasibility of CO<sup>2</sup> as a working fluid with claimed performance improvements [71]. However, these studies had been preliminary without experimental efforts to validate such claims.

Some studies had performed theoretical investigations on the use of multicomponent and multiphase working fluids [69,72–74]. This in fact violates our Stirling HP classification, which was indeed reserved for gas or supercritical working fluids. In these studies, it was concluded that major modifications to the Stirling cycle are required, which add complexity to the system. The scarcity of Stirling engine studies using multiphase working fluids points out the challenges that such systems face; hence in this study, no further attention to this area is recommended. Nevertheless, it seems an adequate topic for future research since it may open the application for larger temperature lifts at higher working temperatures.

A summary of the Stirling cycle working fluids at UHT is summarized in [Table 4,](#page-36-0) which includes scenarios with and without HP applications.

<span id="page-36-0"></span>Table 4. Fluids available for UHT for Stirling engine and HP applications.

| Working<br>Fluid | Max<br>Operating<br>Temp. [℃] | P [bar] | Reference                              |  |  |
|------------------|-------------------------------|---------|----------------------------------------|--|--|
| Nitrogen         | 370                           | 33.98   | [75]5<br>Thermoacoustic<br>Stirling HP |  |  |
| Helium<br>776    |                               | 150     | Free-Piston<br>Power [76]              |  |  |
| Hydrogen<br>800  |                               | 100     | Dish-Stirling<br>Solar Power<br>[77]   |  |  |
| Hydrogen<br>1053 |                               | 140     | Solar Power<br>[57]                    |  |  |
| Helium<br>750    |                               | 150     | Solar Power<br>[56]                    |  |  |
| Helium           | 227                           | 75      | HP<br>Olvondo HighLift<br>[78,79]      |  |  |
| Nitrogen         | 400                           | 29      | Power Coolenergy<br>[80]               |  |  |
| 600<br>𝐶𝑂2       |                               | —       | HP<br>Residential<br>[81]              |  |  |
| Helium           | 250                           | —       | HP<br>Enerin<br>HoegTemp<br>[82]       |  |  |

#### *2.1.2.2.3 Operation Temperature (Tsource and Tsink)*

Stirling Heat Pumps may be regarded as a reversed Brayton cycle, hence, the operational temperatures are share similar conditions as the reversed Brayton cycles HP, see Section [2.1.2.1.](#page-29-1)

#### *2.1.2.2.4 Performance (COP)*

Design guidelines for elementary estimates of Stirling machines performance include the use of the Beale number concept where the Beale number is defined with:

$$N_{BEALE} = \frac{\dot{Q}}{PVf} = 0.015$$

where Q̇ is the power output in Watts, P is the mean pressure in bars, V is the piston displacement in cm<sup>2</sup> , f is the engine frequency in hz. A similar equation for the power input to Stirling HPs exists, but the range of the "constant" (0.015) is still unknown.

#### *2.1.2.2.5 Heating Capacity (Scalability)*

In practice, in terms of the heating capacity, Stirling HPs tend to be on the lower end of production, with most of them below the Megawatt threshold. The maximum capacity of a single unit found by the authors to date was on the order of 750 kW [78]. These units can be scaled up by stacking them and sharing the same heat source. By doing so, capacities of over 1 MW are possible [82,83]. However, the mentioned HP system reached maximum temperatures of about 250°C, which is the lower end of the temperature range of interest (>250°C) of this paper. Hence further research is required to test these systems at UHT.

Another reason to include these low-temperature systems is the fact that Stirling engines are capable of working at UHT for solar power production. As a matter of fact, Stirling engines are among the highest temperature engines commercially available. In these instances temperatures above 1000°C are achieved

<sup>5</sup> Maximum Temperature achieved in a prototype thermoacustic Stirling heat Pump

[57] on smaller capacity units. It remains to be investigated if the staking of such units in a HP configuration can be a viable alternative in terms of efficiency and economics.

#### *2.1.2.2.6 Life Cycle*

In terms of the maximum life cycle, or continuous operation without maintenance breaks, Stirling engines have been designated as machines with perpetual motion and minimum maintenance. This is especially true for the so-called free-piston Stirling systems. Hence, free-piston Stirling engines have been proposed as ideal for space exploration applications [84,85] and for use in remote areas [56,57,80]. Freepiston engines are self-contained systems, which rely on dedicated springs to move the working piston. However, the benefits of long-term operation are no longer applied when considering Stirling HPs.

Most of the Stirling HPs require external mechanical work to move the working piston. This indeed increases the number of moving parts hence hindering the long-term operation that otherwise is possible. Stirling HPs at a maximum temperature of about 250°C have tested up to 8,000 working hours without maintenance [78].

It should be noted that caution on the interpretation of the previous results is required when considering higher operational temperatures. As with any other HP technologies, common issues of machinery become increasingly unreliable with increases in temperature. Piston seals, lubricants aging, heat exchangers efficiencies, and material operational limits will tend to decrease with temperature. The overall downtime and maintenance of the system is expected to be larger at higher temperatures.

#### *2.1.2.2.7 Technical Readiness*

Stirling systems are getting attention as a viable option for energy savings through multiple applications, including industrial waste heat recovery [72,80] and electricity production from concentrated solar applications [56,57,77]. In such applications Stirling systems are considered mature, reliable, and profitable options. As HPs applications, for cooling, Stirling HPs excel in their performance as the main components of cryocoolers [86,87].

There has been some development of Stirling HPs as heat augmentation devices for housing and lowtemperature applications [81]. Few commercial options are available for HTHP applications [78], while scarce options exist for UHTHP. In terms of the technical readiness, Stirling UHTHP options are only laboratory-scale prototypes with uncertain performances [88]. For this study, the technical readiness of Stirling HPs within the UHT range have been determined to be a TRL 6.

#### *2.1.2.2.8 Technical Gap or Challenges*

Some of the technical challenges identified for the Stirling cycle in the literature are summarized in [Table 5.](#page-38-0) This information provides guidance towards future research topics to address the specific gaps to make the Stirling UHTHP a reality. Interestingly, most of the identified literature analyzes the working fluid influence on the performance of the HPs. This implies that some maturity of the systems' components has been achieved. Also, it has highlighted the need for research into heat exchangers, which is also one of the efficiency driving components of Stirling cycles.

<span id="page-38-0"></span>Table 5. Studies investigating the optimal components selection and operation for HTHP/VHT

HP/applications and their performance impact on the high-temperature Stirling systems

| Regenerator | Compressor<br>Working<br>Piston<br>/<br>Displacer<br>/<br>Geometry | Working<br>Fluid | Heat<br>Exchanger | Summary                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-------------|--------------------------------------------------------------------|------------------|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|             |                                                                    | √                |                   | working gas was used with an impact to<br>C02<br>engine efficiency of about 10%.<br>The change of<br>working fluid is justified due to the advantage of<br>coupling of a Sterling Engine and a Ranking HP<br>[81].                                                                                                                                                                                                                                                                                                   |
|             |                                                                    | √                |                   | Non-typical gases<br>with non-ideal thermodynamic<br>behavior showed to increase by as much of 20%<br>the cycles efficiency, but at the cost of higher<br>maximum pressures of about 100-300 bars<br>[66].                                                                                                                                                                                                                                                                                                           |
|             | √                                                                  |                  | √                 | Self-recirculating heat exchangers increase sink<br>engine heat transfer, but at a cost of overall<br>system efficiency<br>[76]. Increases of loop length<br>and pipe diameter<br>tend to decrease efficiency.                                                                                                                                                                                                                                                                                                       |
|             |                                                                    |                  | √                 | Large temperature gradients in the hot heat<br>exchanger may potentially improve the COP, but<br>due to the mixing of different temperature<br>bodies<br>of fluid in the compression space<br>adversely<br>affects efficiency [27].                                                                                                                                                                                                                                                                                  |
|             |                                                                    | √                |                   | Among fluid properties, for Brayton and Rankine<br>cycles, it was determined that cp<br>and (1<br>− cv/cp)<br>play a major role in the efficiency of power<br>systems. It is required a high value of cp<br>and low<br>values of (1<br>− cv/cp) for the compressing and<br>expanding processes.<br>For Stirling cycles, a preliminary selection of<br>working fluids depends on k/(cp<br>⋅ ρ) and on<br>0.5<br>2<br>3<br>. A methodology and<br>Qwf<br>∝ (ρ<br>cp<br>)<br>mathematical expressions were developed to |
|             |                                                                    | √                |                   | compare between different power cycles [89].<br>A<br>model to predict internal operational conditions<br>from pressure measurements was developed.<br>These effort to monitor the industrial application<br>of a HTHP (max temperature shy of 240°C)<br>[90].                                                                                                                                                                                                                                                        |
| √           |                                                                    | √                | √                 | Configuration, heater shape, heat exchanger size,<br>and regenerator type and geometry were<br>optimized by means of a second-order software<br>called PROSA [91].<br>It was determined that for<br>UHT<br>(600-800°C).<br>Alpha-type Stirling systems<br>were<br>more efficient. This configuration is the<br>preferred for HPs.                                                                                                                                                                                    |

| <b>V</b> | Developed a new concept for improvement of cycle efficiency reaching near-isothermal expansion and compression. This was by increasing the working piston heat transfer area by adding fins. A prototype was built and some theoretical designs were tested with experiments [92,93]. |
|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

#### 2.1.2.2.9 *Companies*

The versatility of Stirling engine technology allows an easy transition from engine to HP, this by inducing mechanical work to move the working piston and by reversing the hot and cold heat exchangers. Considering this versatility, the authors considered important to explore technologies focused not only on Stirling HPs, but also on Stirling engine prototypes with demonstrated maximum temperatures above 250°C.

Although most companies manufacturing Stirling HPs had focused on cryogenics applications [86,87] and heating/cooling at small capacities [94,95], in this section we summarized those companies or institutions that have explored Stirling HPs and/or engines on large-scale applications either in production or prototypes. Also, we included those companies with interesting or breakthrough technologies that seem promising for the advancement of UHTHP technology.

<span id="page-39-0"></span>Table 6. Identified Stirling engines and Stirling HPs companies with the potential of UHT applications.

<span id="page-39-1"></span>

| Company/<br>Institution | Application                      | Max Temperature [°C] | Capacity                      | Max<br>COP/efficiency |
|-------------------------|----------------------------------|----------------------|-------------------------------|-----------------------|
| CoolEnergy              | Power Generation                 | 400                  | 25 kW                         | ~30%                  |
| FluidMechanics          | HP<br>Heating                    | _                    | 10 kW                         | ~60%                  |
| SoundEnergy             | HP<br>Cooling<br>(Thermoacustic) | 300                  | 170 kW<br>stackable for<br>MW | _                     |
| Olvondo<br>HighLift     | HP<br>Heating                    | 227                  | 750 kW                        | 1.9                   |
| Qnergy <sup>6</sup>     | Power Generation                 | 650                  | 6 kW                          | ~30%                  |
| Microgen <sup>6</sup>   | Power<br>Generation              | 560                  | 2 kW                          | ~30%                  |

\_

<sup>&</sup>lt;sup>6</sup> Manufactures of low-capacity modules. These are included in this review due to historical collaboration with nuclear industry for power generation (MARVEL) and NASA space program.

## **2.2 Thermally Driven Heat Pump (Chemical Heat Pump)**

<span id="page-40-0"></span>In contrast to MDHPs discussed in Sectio[n 2.1,](#page-21-0) TDHPs use heat to drive a "thermal" compressor. Traditionally, TDHPs are based on the utilization of natural gas or clean fuel, renewable energy source (geothermal energy, for example), or vapor absorption and adsorption. Chemical heat pumps (ChHPs) are relatively recent manifestations of the TDHP systems based on reversible chemical reactions and hold much promise for achieving high temperature amplifications as discussed in this section. Similar to Sectio[n 2.1,](#page-21-0) the following subsections delve into ChHP technology applicable to UHTHP purposes, considering the following subcriteria: working principle, working fluid options, operational parameters and characteristics, performance, scalability, and capital investment.

#### <span id="page-40-1"></span>**2.2.1 Working Principle**

The basic operation of a ChHP is shown in [Figure 11.](#page-40-2) The heat transferred from a primary energy source (nuclear reactor, solar thermal collector, etc.) is used to drive a chemical reaction as shown on the left side of the figure. The reaction typically consists of a decomposition of a solid reactant into two products—a solid product that remains in the reactor and a gas that is removed from the reactor for either storage in a tank or a vapor that is condensed and stored as a liquid. This reaction is endothermic, involving the breakdown of chemical bonds in the reactant to form products that act as the energy storage media. Reconstitution of the original chemical bonds by reversing the reaction results in the formation of the reactant of the first step along with the release of energy due to the exothermicity of the reverse reaction. Manipulation of the operating conditions of the reverse reaction makes it possible to achieve thermoamplification or temperature amplification thus obtaining energy at a higher temperature than that of the source [96–99].

![](_page_40_Picture_4.jpeg)

Figure 11. A simple ChHP system involving a condensable product [98].

<span id="page-40-2"></span>The generalized equation representing the reactions taking place in the ChHP reactor can be represented by:

$$A(s) \leftrightarrow B(g) + C(s)$$

In this generalized reaction scheme, the forward reaction is endothermic while the reverse reaction is exothermic. A broader classification of ChHPs incorporated physical sorption processes as well and is shown in [Figure 12](#page-42-1) [100].

The sorption processes generally involve sorption-desorption of water, ammonia, or hydrogen. ChHPs based on reversible chemical reactions typically involve a hydration/dehydration, carbonation/decarbonation, hydrogenation/dehydrogenation, or redox reaction couple.

It can be seen from [Figure 11](#page-40-2) that ChHPs include organic and inorganic chemical systems. Isopropanol-acetone is one of the promising organic ChHPs involving the following reversible hydrogenation-dehydrogenation reaction [101,102]:

$$(CH_3)_2CHOH \leftrightarrow (CH_3)_2CO + H_2$$

A reversible methanation-steam reforming system is also a possibility for application as a ChHPs [103]:

$$CH_4 + H_2O \leftrightarrow CO + 3H_2$$

This reaction system has been extensively studied, however, from the perspective of energy storage or hydrogen transmission alternatives and not for ChHP applications. Organic systems involving gas phase reactions are subject to equilibrium limitations as well as substantial volumetric storage requirements. Inorganic systems involving solid reactants are more promising for both energy storage and HP applications.

The hydration/dehydration and carbonation/decarbonation ChHPs systems (listed under water and carbon dioxide systems, respectively, in [Figure 11\)](#page-40-2) are typified through the following reactions involving Ca [100]:

$$Ca(OH)_2 \leftrightarrow CaO + H_2O$$
  
 $CaCO_3 \leftrightarrow CaO + CO_2$ 

The alternative to Ca includes Mg for the hydration/dehydration ChHPs and Pb for carbonation/decarbonation ChHPs. Other examples include chemical-looping reactions, such as metal oxidation/reduction cycles or methane forming/reforming.

Current applications of ChHPs include thermal energy storage, heating and cooling (including refrigeration), and temperature amplification (thermotransformer) [98–100,104]. Typical uses include refrigeration and air conditioning for ammoniacal system, heat storage, and space heating and cooling for the hydrate and hydride systems (Cot-Gores et al. 2012). Isopropanol-acetone-hydrogen and paraldehyde/acetaldehyde are two of the most commonly investigated organic reaction systems, suitable for low-temperature applications (<200℃) [98,102,104]. Sorption processes have been exploited for lowtemperature applications with maximum output temperatures of 200℃–250℃ [104]. ChHPs based on these systems will not be able to provide the higher temperatures needed by processes as shown in [Figure](#page-40-2)  [11.](#page-40-2)

![](_page_42_Figure_0.jpeg)

<span id="page-42-1"></span>Figure 12. Classification of CHPs.

#### <span id="page-42-0"></span>**2.2.2 Working Fluids**

The temperature requirements of the chemical processes narrow down the choice of the ChHP systems primarily to two working fluids that are transferred in and out of the chemical reactor: water (vapor) and carbon dioxide (CO2). Oxygen is also a possibility as a working fluid when inorganic metal oxide systems are considered. [Figure 13](#page-43-0) shows the schematic of an integrated energy system (IES) showing the importance of ChHPs based on reaction systems (i.e., Ca(OH)2-CaO, CaCO3-CaO, Mg(OH)2-MgO and PbCO3-PbO) effecting energy transfer from primary energy sources to chemical

process applications. The solar thermal and nuclear energy are used as primary sources of thermal energy for process heat application for high-temperature industries [105–108], as shown i[n Table 7.](#page-43-1) ChHPs are introduced to overcome the temperature mismatch between the primary source of energy and the high value industrial processes, as shown by solid lines.

<span id="page-43-1"></span>Table 7. Clean thermal energy sources.

| Thermal Energy Source                                                                                     | Operational Temperature (°C) | Maturity of Technology |
|-----------------------------------------------------------------------------------------------------------|------------------------------|------------------------|
| Solar: Parabolic Trough                                                                                   | 390                          | High                   |
| Solar: Central Receiver                                                                                   | 565                          | High                   |
| Solar: Parabolic Dish                                                                                     | 750                          | Medium                 |
| Nuclear: Light water                                                                                      | 325                          | High                   |
| Nuclear: Gen IV (sodium<br>cooled-fast reactor, molten-salt<br>reactor, gas-cooled fast reactor,<br>etc.) | 500–850                      | Low-medium             |

![](_page_43_Figure_3.jpeg)

<span id="page-43-0"></span>Figure 13. The schematic of an IES coupled with ChHP to deliver process heat to high temperature industries.

Various studies reported in literature involving these working fluids are described in the following subsections.

#### <span id="page-44-0"></span>**2.2.2.1 Water Vapor as Working Fluid: Hydroxide-Oxide System**

#### *2.2.2.1.1 Ca(OH)2/CaO ChHP:*

The Ca(OH)2/CaO ChHP process is highly attractive because of its high reaction enthalpy and wide operating temperature range (300℃–700℃) [109]. Further, calcium hydroxide is inexpensive and readily accessible, which is an important factor in ChHP selection. Other common systems based on ammonium salts or MH, sulfur dioxide, carbon dioxide, or hydrogen are more costly, involve species that are toxic in nature (such as NH<sup>3</sup> or SO2, etc.), have issues related to reversibility, and the reagent handling is challenging, particularly when dealing with noncondensable gases [98].

The operation of this system can be understood from the operation shown in [Figure](#page-44-1) 14. Addition of heat at T<sup>M</sup> to the chemical bed of calcium hydroxide at low pressure results in its decomposition with the vapor is captured in a condenser and heat is rejected at TC. The reverse reaction involves increasing the pressure to PH, at temperature TE. The vapor then hydrates the chemical bed of calcium oxide formed in the first step, releasing the stored heat at TH. The heat input and rejection temperatures of ChHPs are governed by the saturation or equilibrium temperatures with the thermodynamics of the system shown using a Clausius-Clapeyron diagram as shown in [Figure](#page-44-1) 14 (b).

![](_page_44_Figure_4.jpeg)

<span id="page-44-1"></span>Figure 14. (a) Schematics of components of Ca(OH)2/CaO ChHP system and (b) Clausius-Clapeyron diagram (Q → heat, P → pressure, T → temperature; subscripts H → high, M → medium, L → low, C → condenstaion, E → evaporation).

The calcium oxide hydration reaction has the potential to receive heat at 350℃ during charging and deliver heat above 600℃ during discharge. This means the reaction is not only helpful in delivering heat at high temperatures but also temperature lifts greater than 250℃. High-temperature operation and large temperature lifts make the CaO/Ca(OH)<sup>2</sup> ChHPs a great candidate for efficient high-temperature process heating using low-carbon thermal energy.

CaO hydration/dehydration ChHP proof-of-concept tests were carried out by Hasatani [110]. To generate steam at 640 K and release heat at 1205 K in the high-temperature CaO reactor, a system pressure of 27.5 MPa is required. The proof-of-concept tests proved that, as steam pressure increased, the CaO hydration reaction's pseudo-equilibrium temperature moved to higher temperatures.

To predict the dynamic behavior of a CaO hydration/dehydration reactor connected with an evaporator and condenser, Fujimoto et al. [111] developed a theoretical model. The model was verified using the outcomes of experiments.

Both fixed- and fluidized-bed reactor systems have been investigated experimentally utilizing this reaction [97,112–114].

Schmidt et al. [114] focused on hydration-dehydration cycles in a pilot-scale reactor (20 kg of powdered CaO, particle size of  $d_{50} = 5 \mu m$ ), which was indirectly operated, employing a heat transfer fluid in addition to the working fluid. A mixture of air and electric heaters heated the heat transfer fluid (HTF) to 700°C. The specifications of the reactor are mentioned in Table 8.

<span id="page-45-0"></span>Table 8. Specifications of the reactor.

| rable 6. Specifications of the reactor. |                                                                                                                             |  |  |  |  |  |
|-----------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|
| Material (Reactor and Thermoshelves)    | 1.4404 – X <sub>2</sub> CrNiMo 17-12-2                                                                                      |  |  |  |  |  |
| Metal weight                            | 145 kg                                                                                                                      |  |  |  |  |  |
| Reaction bed dimensions                 | 45 L (≈25 kg powdered Ca(OH)2)<br>20 × 200 × 800 mm (10 channels)                                                           |  |  |  |  |  |
| Max. permissible temperature            | 600°C                                                                                                                       |  |  |  |  |  |
| Max. permissible pressure               | Reaction gas side: 0.1–2.5 bar<br>HTF side: 0–5.0 bar                                                                       |  |  |  |  |  |
| Thermoshelves dimensions                | $250 \times 850 \text{ mm } (10 \text{ channels})$<br>4.25 m <sup>2</sup> total heat transfer area                          |  |  |  |  |  |
| Power                                   | $P_{Nominal} = 5 \text{ kW}$ $P_{max} = 10 \text{ kW}$                                                                      |  |  |  |  |  |
| HTF mass flow                           | 0.00283–0.0531 kg/s                                                                                                         |  |  |  |  |  |
| Operating conditions                    | Dehydration: Pressure = 10 kPa Temperature = 400°C–590°C Hydration: Pressure = 200 kPa Temperature = 550°C Total Cycles: 10 |  |  |  |  |  |

HTF and reaction gas flows in a cross-flow arrangement, allowing for significant heat exchange along the reactor's length and a short distance through the reaction bed to the reactor's bottom, as illustrated in Figure 15 (a). Although there is a small drop in pressure over the reaction bed, it is reasonable to predict a constant bed temperature. Air was used as the HTF.

One more unit, depicted in Figure 16, was constructed to supply the reaction gas. With 2 liters of distilled water, an 8.5 liter tube-bundle heat exchanger is brought up to operating temperature. In order to maintain a pure water vapor atmosphere, a vacuum pump is used to lower the system's pressure to 10 mbar. A fluid level sensor continuously monitored the water level (Vegaflex 65, coaxial measuring probe,  $\pm 2 \text{ mm}$ ).

![](_page_46_Picture_0.jpeg)

Figure 15. (a) Schematic of the cross-flow diagram of the pilot reactor and (b) reactor filled with 20 kg of Ca(OH)<sup>2</sup> [114].

<span id="page-46-0"></span>![](_page_46_Picture_2.jpeg)

Figure 16. Process flow diagram of the test bench [114].

<span id="page-46-1"></span>Similar study was presented by Linder et al. [115], as shown in [Figure 17,](#page-47-0) and it was clear from this comparison of the experimental and simulated results that microscale measurements and known bed parameters provide a good approximation of effective conditions in a given chemical bed.

![](_page_47_Figure_0.jpeg)

<span id="page-47-0"></span>Figure 17. (a) Indirectly operated thermochemical storage reactor and (b) multifunctional test bench [115].

#### *2.2.2.1.2 Mg(OH)2/MgO ChHP*

The operation of magnesium-oxide-based ChHP is similar to the one for the calcium-oxide-based ChHP, with similar reversible hydration/dehydration chemical reactions shown below, and the schematic of the system i[n Figure 18:](#page-47-1)

![](_page_47_Figure_4.jpeg)

<span id="page-47-1"></span>Figure 18. Principle of MgO/H2O chemical thermal storage [116].

Magnesium oxide has a high energy density [117]. The materials are also nontoxic, abundant, and relatively inexpensive. Magnesium oxide has shown good cyclic stability because during the hydration/dehydration process cracks form in the magnesium oxide leading to a new surface area to react [118]. The ChHP can operate efficiently at dehydration temperatures between 300℃ and 500℃, and the efficiency of the pump is reliant on hydration temperature [118]. A temperature increase range of 100℃– 200℃ has been seen in a cogeneration system [116].

Kato et al. [116] measured the dehydration and hydration rates during the application of MgO/H2O ChHPs, then determined the kinetic equation of hydration, and then examined a packed-bed reactor of a MgO/H2O ChHPs under various operation conditions. They revealed that the amount of hydrated MgO increases with increasing water vapor pressure while decreasing with increasing water vapor temperature.

However, magnesium oxide has a problem with agglomeration and sintering at high dehydration temperatures, which leads to reduced reactivity. This has caused a need to dope the magnesium oxide with something to increase separation between particles. An example would be using exfoliated graphite [117]. Even though magnesium oxide has good cyclic stability, a decrease in reactivity in the first few cycles has been observed before the reactivity remained constant [118]. This ChHP has been studied extensively over the years; however, no industrial applications are currently in operation. Moreover, it has largely been researched for energy storage purposes instead of temperature amplification.

#### <span id="page-48-0"></span>**2.2.2.2 Carbon Dioxide as a Working Fluid: Carbonate-Oxide System**

#### *2.2.2.2.1 CaCO3/CaO*

Calcium oxide to calcium carbonate high temperature ChHPs utilize the reversible carbonation/decarbonation reaction where the carbonation step is exothermic and decarbonation step is endothermic. The CaCO3/CaO reaction pair is characterized by high temperature and enthalpy (*ΔH<sup>o</sup>* = 178.1 kJ mol-1 ). In order for the calcination reaction to commence, the equilibrium pressure of CaCO<sup>3</sup> must be greater than the CO<sup>2</sup> partial pressure in the system since CaCO<sup>3</sup> breakdown occurs at higher temperatures (>850℃).

$$CaO(s) + CO_2(g) \rightleftharpoons CaCO_3$$

The storage of CO<sup>2</sup> produced during the dissociation of CaCO<sup>3</sup> in a high temperature CaO-CO<sup>2</sup> thermochemical energy storage system was examined by Kyaw et al. [119] in 1997. Three different techniques for storing the dissociated CO<sup>2</sup> gas (in the form of compressed gas, other carbonate, or adsorbed CO<sup>2</sup> in an appropriate adsorbent like zeolite or activated carbon) were investigated in their study. [Figure 19](#page-49-0) displays the schematic of the process flow together with a full inset of each CO<sup>2</sup> storage method. [Figure 20](#page-50-0) depicts the temperature-pressure behavior of each CO<sup>2</sup> storage device.

The zeolite adsorbent CO<sup>2</sup> storage is quite comparable with other systems if the adsorptivity of the adsorbent increases to higher values. Also, the COP of the heat upgrading system decreases with the upgraded temperature.

![](_page_49_Picture_0.jpeg)

Figure 19. Conceptual flow diagram of CaO-CO<sup>2</sup> energy storage system in heat augmentation mode [119].

<span id="page-49-0"></span>Kato et al. [120] reported an experimental study involving a CaO/ PbO/CO<sup>2</sup> ChHPs [\(Figure 21\)](#page-51-0). The HP was operated at 0.4 atm during the heat-storage mode and at 1.0 atm during the heat output mode. The HP stored the heat available at about 860℃ and upgraded it to above 880℃ under subatmospheric pressure without any external assistance [\(Figure 22\)](#page-51-1).

The concept of the CaO/CO<sup>2</sup> ChHPs reaction system was also applied to a heat-storage system that utilizes heat from a high-temperature gas reactor. Experiments were conducted on a CaO/CO<sup>2</sup> packed-bed reactor containing one kilogram of reactant. The HP reactor needed 2.85 m<sup>3</sup> of CaO to produce a minimum of 1 MW of power output at 998℃ during 60 minutes of operation at an operating pressure of 4 atm. Their study suggested that the heat output of the packed-bed reactor can be improved by enhancing the heat conduction.

Meier et al. [121] designed and tested a 10 kW solar rotary kiln reactor for the production of lime (CaO) for the chemical and pharmaceutical industry through the calcination of CaCO<sup>3</sup> , in order to study the technical feasibility of the solar calcination process. The efficiency of a solar reactor, defined as the ratio of process heat used for the chemical reaction to the solar power input, reached around 20% for an input solar flux of 1200 kW/m<sup>2</sup> . A reactor efficiency of 30–35% for a solar flux input of 2000 kW/m<sup>2</sup> and a production rate of 4 kg/h were obtained. Investigation of the decarbonation reaction using small-scale

solar furnace (1–2 kW) reactors (i.e., fluidized bed and rotary kiln) was carried out at the Laboratory of Ultra-Rgfractazres in France. The fluidized bed showed a conversion fraction of 0.8 and thermal efficiency of 15%, whereas for the rotary kiln, these values were 0.3 and 7%, respectively.

![](_page_50_Figure_1.jpeg)

<span id="page-50-0"></span>Figure 20. Schematic diagram of CaO-CO<sup>2</sup> energy storage systems with three different CO<sup>2</sup> gas storage methods [119].

![](_page_51_Figure_0.jpeg)

<span id="page-51-0"></span>Figure 21. Principle of CaO/PbO/CO<sup>2</sup> ChHPs of heat transformation type operation: (a) heat-storage mode and (b) heat output mode [120].

![](_page_51_Figure_2.jpeg)

<span id="page-51-1"></span>Figure 22. HP cycle of CaO/PbO/CO<sup>2</sup> reaction equilibrium.

Several investigators have explored the possibility of developing calcium looping (CaL) integrated concentrated solar power (CSP) plants. Unlike CaL for CO<sup>2</sup> capture, CaL in a CSP plant is a closed system, in which CO<sup>2</sup> is circulated between the calciner and the carbonator. The CaL system is comprised of a heliostat field, a solar calciner, a carbonator, two containers for storing CaO and CaCO<sup>3</sup> , a CO<sup>2</sup> compression-storage unit, and a power cycle, as shown in [Figure 23.](#page-52-0) Calcination takes place in the calcinator by absorbing the concentrated solar energy available from the heliostat, and the released CO<sup>2</sup> is compressed and stored in a tank after due cooling. The energy-release process takes place in the carbonator, which is a pressurized-fluidized-bed reactor. This reaction aims to use pure CO<sup>2</sup> at the highest possible temperature in order to maximize the thermal-to-electrical conversion efficiency. The exothermic heat of the carbonation reaction is delivered to a power cycle, which either directly employs CO<sup>2</sup> in a Brayton cycle or uses a heat exchanger coupling a secondary fluid.

![](_page_52_Figure_0.jpeg)

<span id="page-52-0"></span>Figure 23. Schematic of CaL solar thermal power plant.

It was suggested to employ heat at 773 K and a pressure of 0.01 kPa to decompose CaCO<sup>3</sup> in a thermal energy storage device. At 214 K and 0.01 kPa, the CO<sup>2</sup> was absorbed by zeolite. Desorption of the zeolite decreased from 10 to 4 g/100 g and CO<sup>2</sup> gas pressure increased from 0.01% to 1100 kPa when the zeolite was heated from 214 to 260 K. The desorbed CO<sup>2</sup> was heated to 773 K before being fed to the CaO reaction (via heat exchange with a similar device that is running in heat-storage mode). The CaCO<sup>3</sup> product was created by the reaction of CO<sup>2</sup> and CaO at a pressure of 1100 kPa and an equilibrium temperature of 1273 K.

A comparison of all CO<sup>2</sup> storage technologies is shown in [Figure 24](#page-52-1) [119]. The COP of each system gradually declines with an increase in upgraded temperature. The COP of the zeolite-based CO<sup>2</sup> storage system was comparable to that of other systems and that its COP rose in direct proportion to an increase in absorptivity.

![](_page_52_Figure_4.jpeg)

<span id="page-52-1"></span>Figure 24. COP vs. upgraded temperature of CaO-CO<sup>2</sup> energy storage systems with various CO<sup>2</sup> storage system [119].

Barker [122] studied multiple calcination and carbonation cycles with 10 μm CaCO<sup>3</sup> and found that the surface area of the produced was 28.7 m<sup>2</sup> /g after the initial decarbonation process, a significant increase over the essentially nonporous unreacted or the calcined limestone, which had surface areas of 0.46 and 0.34 m<sup>2</sup> /g, respectively. The decomposition of calcium carbonate yields the much more porous oxide of calcium (by a factor of 50) because the carbon dioxide left behind a significant number of extremely tiny pores (4 nm in diameter) [122]. The carbonation temperature was found to have a significant impact on the conversion of CaO to carbon dioxide in the studies conducted by Grasa et al. [123] and Chen et al. [124].

Ströhle et al. [125] developed and installed at Technische Universität Darmstadt a 1 MWth carbonate looping pilot plant with two coupled circulating fluidized-bed (CFB) reactors. The pilot plant operated in fluidized-bed mode for over 1,500 hours, 400 of which have included carbon dioxide capture. Combustion of propane or pulverized coal with O<sup>2</sup> enriched air produced the heat for the calciner's endothermic regeneration of CaO. For extended periods of time, the carbonator was able to attain high CO<sup>2</sup> absorption efficiencies of up to 85%. With the calciner's oxyfuel combustion contributing to the total, the pilot plant achieved total CO<sup>2</sup> capture rates of over 90% during operation.

Nikulshina et al. [126] presented a thermochemical cyclic process and associated reactor for the continuous removal of CO<sup>2</sup> from ambient air via sequential CaO-carbonation and CaCO3-calcination stages, using high-temperature process heat derived by concentrated solar energy. The carbonator and calcinator were combined into one fluidized bed, eliminating the need to move solids between processes. At the carbonation stage, CaO particles were converted to CaCO3, and CO2-depleted air was evacuated from the reaction site using ambient air with additional steam as the fluidizing gas. In the calcination process, CaCO<sup>3</sup> particles are converted to CaO, and pure CO<sup>2</sup> was released from the reaction site. Further, by running two identical reactors side by side, the carbonation and calcination phases could be carried out simultaneously by rerouting the gaseous reactants between the reactors and regulating the temperatures accordingly. After running the process for five iterations in a row, the residence time of 1.3 seconds for each carbonation stage was found to be sufficient to remove all of the CO<sup>2</sup> from a continuous airflow containing 500 ppm of CO2and subsequent total release of CO<sup>2</sup> and regeneration of the CaO reacting particles during the calcination process.

#### *2.2.2.2.2 PbO/PbCO<sup>3</sup>*

Kato et al. [120] investigated several inorganic oxide/carbon dioxide reaction systems for ChHP systems and found that the inorganic oxides, such as PbO, MgO, CuO, MnO, ZnO, NiO, and CoO, can be selected as candidates. As for the chemical reaction heat storage, the lead oxide/carbon dioxide (PbO/CO2) reaction displayed the most outstanding features.

The working principle of PbO/CO<sup>2</sup> reaction system is based on the following chemical equation:

$$PbO(s) + CO_2(g) \rightleftharpoons PbCO_3 \Delta H_o = 271 \text{kJ/mol}$$

The principle of chemical reaction heat-storage/heat-pump system using PbO/CO2reaction is shown in [Figure 25.](#page-54-1) An innovative approach is used in these investigations to manage the storage of CO<sup>2</sup> evolved in the decarbonation of PbCO<sup>3</sup> by directing it into a bed of CaO to form CaCO3. This is an exothermic process that offers the benefit of heat recovery. The reverse step involves releasing the stored CO<sup>2</sup> from the CaCO<sup>3</sup> bed and introducing it into the bed of PbO to reform PbCO3. Effectively, the CO<sup>2</sup> is shuttled between the two beds that alternate between oxide and carbonate forms, a process that is governed by the equilibria shown in [Figure 25.](#page-54-1)

![](_page_54_Picture_0.jpeg)

Figure 25. Principle of PbO/CO<sup>2</sup> chemical reaction heat-storage system: (a) heat-storage mode and (b) heat supply mode [120].

#### <span id="page-54-1"></span><span id="page-54-0"></span>**2.2.2.3 Oxygen/Hydrogen As Working Fluids: Metal Hydrides and Oxides**

#### *2.2.2.3.1 Hydrogen*

Utilizing metal hydrides (MHs) for thermochemical energy storage is an appealing concept, due to its high exergetic efficiency, high energy density, wide range of operating temperatures, and potential to be environmentally friendly. Such energy conversion systems can produce energy densities as high as 2,814 kJ/kg of hydride. MH are compounds formed and decomposed by the reversible chemical reaction of hydrogen and a metal atom by releasing and absorbing thermal energy. The general form of reaction is:

$$M + \frac{X}{2}H_2 = MH_X + \Delta H$$

where M is a metal or an intermetallic compound, MHx is the hydride, and ΔH refers to the heat of reaction. Absorption of energy results in the release of hydrogen during the charging process and the absorption of hydrogen results in energy release as shown in [Figure 26.](#page-54-2)

![](_page_54_Figure_7.jpeg)

<span id="page-54-2"></span>Figure 26. Charging (left) and discharging (right) processes of MHTES [127].

Hydrogen released during the charging process from the high temperature metal hydride (HTMH) can either be stored as compressed gas or directed towards a low-temperature metal hydride (LTMH). For compressed gas storage, H<sup>2</sup> is compressed and stored in either a pressure vessel or a salt cavern/ lined rock cavern. In the latter case, a LTMH is employed for H<sup>2</sup> storage, without requiring any compressor work. The compactness of the system depends on the H<sup>2</sup> storage capacity of the LTMH. The charging and discharging processes of the two-reactor system are thermally controlled, i.e. the pressure of absorption/ desorption of both the reactor is controlled by controlling temperature in both the reactor. Furthermore, with proper selection of LTMH, some amount of cooling can also be produced in the LTMH reactor, leading to the concept of co-generation (simultaneous heating and cooling effect). During discharging of

the two-reactor MHTES system, the pressure of H<sup>2</sup> coming out from the LTMH continuously falls due to drop in temperature and hysteresis effect in LTMH, leading to the reduction in the driving potential (the difference between the supply pressure of H<sup>2</sup> and the equilibrium pressure of the MH bed). The temperature of energy release in HTMH decreases because of the drop in H<sup>2</sup> pressure coming out from the LTMH. To overcome this drawback, the research team from IIT Guwahati(India) explored the concept of compressor driven MHTES system. The schematic of the compressor-driven MHTES system integrated with the solar thermal power plant is shown in [Figure 27.](#page-55-0)

![](_page_55_Picture_1.jpeg)

Figure 27. Schematic of combined MHTES and cooling system integrated with solar thermal power plant [127].

<span id="page-55-0"></span>The proposed system is comprised of an HTMH reactor, regenerator, compressor, and LTMH reactor. During on-sun hours, a portion of solar heat is directed to HTMH to desorb H<sup>2</sup> in an endothermic reaction. The released H<sup>2</sup> is stored in LTMH at ambient temperature. During the off-sun period, the proposed system utilizes the compressor to drive the H<sup>2</sup> from LTMH to HTMH. The suction side of the compressor is connected to the LTMH, and the delivery side is connected to the HTMH. A continuous cooling effect is produced in the LTMH due to H<sup>2</sup> desorption from LTMH to suction pressure of compressor. The compressed H<sup>2</sup> from delivery side of compressor is supplied to the HTMH. The HTMH releases heat by absorbing H<sup>2</sup> in an exothermic reaction. The exothermic heat of HTMH is supplied to the power cycle to generate electricity. The compressor-driven MHTES system maintains the driving potential needed for H<sup>2</sup> transfer throughout the reaction over thermal-driven MHTES system. Also, by increasing the delivery pressure of compressor greater than the desorbing pressure of H<sup>2</sup> during charging process, the proposed system can also operate as heat transformer. A regenerator is employed between the two reactors to extract/deliver the heat from/to hydrogen gas leaving/entering the HTMH during the charging/discharging process.

The performance of the MH-based system is governed by the selection of MH alloys. It is desirable that alloys employed for the heat-storage application have a high hydrogen-storage capacity, flat plateau (amount of hydrogen that can be stored reversibly with no variations in pressure and temperature), low hysteresis, fast kinetics, easy activation, and high melting point. Alloys with a high heat of formation and low disassociation pressure at higher temperatures are preferable. Those MHs that have been primarily investigated to date for high-temperature energy storage applications are magnesium hydride (MgH<sup>2</sup> ), titanium hydride (TiH<sup>2</sup> ), and calcium hydride (CaH<sup>2</sup> ). Apart from these, some complex MH involving lighter elements, such as boron, nitrogen, or aluminum, which offer extreme hydrogen densities (up to 20%), have also been explored, only to demonstrate poor thermodynamic and kinetic properties and limited reversibility. The MgH2-Mg system has been identified as the most attractive high-temperature heat-storage material because of its substantial hydrogen-storage capacity and the high energy density. The cyclic stability of pure MgH2, however, drops by 75% after 500 cycles, which can be improved by doping with nickel or iron, thus leading to consistent cyclic stability over 500 cycles. Kawamura et al. [128,129] investigated the potential use of Mg2Ni for heat-storage application, with a testing prototype using 6.27 kg of Mg2Ni. Their experimental findings indicated that the heat transfer coefficient and the insulation of the system heavily influenced the large temperature gain of the HTF. On a laboratory scale, Wierse and Groll [130] conducted experiments with Ni-doped MgH2. The heat-storage setup comprised 24 kg of Mg powder housed in a stainless-steel container, which was subjected to testing for about 1,200 hours at 280–500 °C. This system exhibited heat-storage capacity of 5.3 kW.

MH systems have been studied primarily for energy storage applications, for power generation via fuel cells, and for stationary or transportation applications. Instances of thermal output and utilization as ChHP are rare, and no pilot-scale studies are available in literature.

#### *2.2.2.3.2 Oxygen*

Redox reactions are one of the most promising thermochemical energy storage (TCES) materials, explored in the early 1980s. These materials store/release thermal energy by absorbing/releasing oxygen at temperatures between 350℃ and 1100℃. Redox systems have the advantage of using oxygen as both the HTF and the reactant, bypassing the need for a separate heat exchanger and eliminating auxiliary requirements such as storing CO<sup>2</sup> or evaporating water. The general form of redox reaction is:

$$MO_{(OX)} + Heat \leftrightarrow MO_{(red)} + \frac{1}{2}O_{2(g)}$$

Among the pure metal oxides, only cobalt oxide, iron oxide, copper oxide, and manganese oxide show suitable reaction temperatures, reaction enthalpies, cycling stabilities, and material costs. The feasibility of reducing and oxidizing cobalt oxide at around 900°C during an on-sun period and at lower temperatures during an off-sun period was tested. Thirty cycles were performed on Co3O<sup>4</sup> + 5% Al2O<sup>3</sup> without any degradation of material but yielding only a 50% conversion due to insufficient mixing of the material. Thermogravimetric analysis on Mn2O<sup>3</sup> , Co3O<sup>4</sup> , and their corresponding mixed oxides showed that pure oxide samples showed faster and constant reduction and reoxidation temperatures than doped samples. Despite the lower energy density, Mn2O<sup>3</sup> exhibited excellent cycle stability, low toxicity, and inexpensiveness. The concept of a hybrid thermochemical-sensible energy storage system employing ceramic honeycomb structures (made of Al2O<sup>3</sup> and SiC foams) coated with or manufactured entirely from a redox material like Co3O<sup>4</sup> was developed to increase the volumetric heat-storage capacity and reaction kinetics. TG analysis showed that the coated support exhibited a constant, reproducible cyclic behavior up to 30 cycles.

The concept of a cascaded metal oxide TCES using porous heat-exchange modules coated with metal oxide was introduced to maximize the amount of redox material participating in the reaction as shown in [Figure 28.](#page-57-0) The system was cascaded according to a decreasing reduction temperature. Thermogravimetric analyses of CuO/Cu2O, Mn2O<sup>3</sup> /Mn3O<sup>4</sup> , and BaO<sup>2</sup> / BaO, as well as with one perovskite system, were conducted to identify suitable materials for the cascade TCES. Results showed a large temperature gap between oxidation (780℃–690℃) and reduction (940℃) of Mn3O<sup>4</sup> /Mn2O<sup>3</sup> , whereas the CuO/Cu2O and BaO<sup>2</sup> /BaO pairs failed to work reproducibly and quantitatively. These experiments also revealed that, in

addition to Co3O<sup>4</sup> /CoO, only Mn2O<sup>3</sup> /Mn3O<sup>4</sup> is capable of cyclic operation. Furthermore, the laboratoryscale Co3O4- and Mn2O<sup>3</sup> -coated porous cordierite honeycombs and foams were tested to advance the cascade TCES concept. The operating conditions of a cascade TCES were dictated by a higher reduction temperature and slower oxidation rate of the Mn2O<sup>3</sup> /Mn3O<sup>4</sup> pair, without demonstrating any significant thermal benefit in the explored configuration.

A comparative appraisal between cordierite honeycomb coated with a Co3O<sup>4</sup> TCES and the uncoated cordierite honeycomb sensible heat-storage system was reported. Schematics of the complete installation and pilot-scale reactor chamber are shown in [Figure 29.](#page-58-1) Results showed that the TCES system achieved a storage capacity of 47 kWh compared to the sensible heat storage of 25.3 kWh. A storage-performance factor (defined as actual storage to ideal storage) of 0.84 was achieved, alongside an energy chargedischarge efficiency close to 100%, thereby signifying release of the entire energy stored during charging.

![](_page_57_Figure_2.jpeg)

<span id="page-57-0"></span>Figure 28. Schematic of cascade metal oxide TCES system employing four different oxide materials [127].

![](_page_58_Picture_0.jpeg)

Figure 29. Schematic of pilot-scale test facility to study redox-based thermochemical storage.

<span id="page-58-1"></span>Several studies involving metal oxide systems have been reported in literature, most of them conducted with thermogravimetry. A limited number of studies have employed packed-bed or fluidizedbed reactors. These studies have focused primarily on the energy storage aspects of the system rather than HP applications.

#### <span id="page-58-0"></span>**2.2.2.4 Thermodynamics of Hydroxide Systems**

The behavior of the ChHP reaction system is governed by the thermodynamics as shown by the Clausius-Clapeyron diagram in [Figure](#page-44-1) 14. The equilibrium relationships between temperature and pressure reported by various investigators for the calcium hydroxide/oxide system are shown in [Table 9.](#page-58-2) The impact of temperature dependency on thermodynamic characteristics and reaction equilibrium was examined by Gupta et al. [131]. Incorporating the temperature dependence of enthalpy change leads to a more accurate equilibrium pressure-temperature relationship.

<span id="page-58-2"></span>Table 9. The equilibrium relation between pressure and temperature.

| Equation                                                     | References               |  |
|--------------------------------------------------------------|--------------------------|--|
| 𝑃𝑒𝑞[𝑃𝑎]<br>11375<br>ln (<br>) = −<br>+ 14.574<br>105<br>𝑇[𝐾] | Samms and Evans<br>[132] |  |
| 𝑃𝑒𝑞[𝑃𝑎]<br>12845<br>ln (<br>) = −<br>+ 16.508<br>105<br>𝑇[𝐾] | Schaube et al. [133]     |  |
|                                                              |                          |  |

| $\ln\left(\frac{P_{eq}[Pa]}{10^5}\right) = -\frac{11607}{T[K]} + 14.648$                                                                                                                                           | Criado et al. [134];<br>Barin and Platzki<br>[135] |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|
| $lnP = \frac{\left(-109170 + \frac{c_{r,1}Tln(T)}{1000} + \frac{c_{r,2}T^2}{2*10^6} + \frac{c_{r,3}T^3}{6*10^9} + \frac{c_{r,4}T^4}{12*10^{12}} + \frac{1000.c_{r,5}}{2T} - c_{r,6} + c_{r,8}\right)}{RT} + 17.14$ | Gupta et al. [131]                                 |

The equilibrium P-T relationships for nine different hydroxide systems reported in literature are shown in Figure 30. The reported data were subjected to regression using two different equations, and the resulting equation parameters are shown in Table 10. The two equations (i.e., Equation 1 and Equation 2 represented in Table 10) are:

$$ln(P) = A + B/T$$
  
$$ln(P) = A + B/T + C*ln(T) + DT$$

#### <span id="page-59-0"></span>2.2.2.5 Kinetics of Hydroxide and Carbonate Systems

#### 2.2.2.5.1 $Ca(OH)_2$

Table 11 presents the various reaction kinetics models reported in literature for the Ca(OH)<sub>2</sub>-CaO dehydration-hydration reaction system, with X referring to the conversion of the reactant. According to Lin et al. [136], 100% conversion of CaO to Ca(OH)<sub>2</sub> during hydration occurred at a temperature of 1023 K with a high vapor pressure of 3.8 MPa. However, as the hydration temperature was increased even higher, the hydration conversion decreased as can be expected from thermodynamic considerations. The outcome demonstrates that the hydration reaction of CaO can be promoted by appropriate high temperature and pressure.

#### 2.2.2.5.2 CaCO<sub>3</sub>

Carbonation, also known as the synthesis reaction for CaCO<sub>3</sub>, is an exothermic reaction that occurs when CaO and CO<sub>2</sub> react. Initial surface reaction creates a thin CaCO<sub>3</sub> layer, and subsequent reaction requires the diffusion of CO<sub>2</sub> diffuses through that layer [122,137]. Table 12 displays the kinetic parameters for the kinetic and diffusion control zones. The changes in the morphology and texture of the CO<sub>2</sub> sorbent have been attributed to the difference in activation energies.

![](_page_60_Figure_0.jpeg)

<span id="page-60-0"></span>Figure 30. Equilibrium relationship for hydroxide systems.

Table 10. Equilibrium relationships for hydroxide systems.

<span id="page-61-0"></span>

|                     |       |           |                |           | Equation 1  |           |             |             | Equation 2 |           |        |       |  |
|---------------------|-------|-----------|----------------|-----------|-------------|-----------|-------------|-------------|------------|-----------|--------|-------|--|
| Chemical<br>Systems | A     | B         | H<br>(KJ/mol) | T1<br>(K) | P1<br>(atm) | T2<br>(K) | P2<br>(atm) | P<br>(atm) | A          | B         | C      | D     |  |
| MgO                 | 18.63 | -9852.40  | -81.92         | 573.15    | 4.23        | 873.15    | 1553.49     | 1549.26     | -11.53     | -8714.19  | 4.90   | -0.01 |  |
| CaO                 | 17.63 | -13208.00 | -109.82        | 573.15    | 0.004       | 873.15    | 12.22       | 12.22       | -145.65    | -3428.32  | 24.39  | -0.01 |  |
| ZnO                 | 18.15 | -6206.40  | -51.60         | 573.15    | 1506.31     | 873.15    | 62189.59    | 60683.28    | -57.90     | -4040.90  | 13.09  | -0.02 |  |
| NiO                 | 16.57 | -5777.50  | -48.04         | 573.15    | 659.67      | 873.15    | 21060.47    | 20400.80    | 74.45      | -7530.25  | -9.83  | 0.01  |  |
| CoO                 | 19.55 | -7217.10  | -60.01         | 573.15    | 1049.44     | 873.15    | 79412.41    | 78362.97    | 395.60     | -18801.80 | -63.70 | 0.09  |  |
| FeO                 | 19.44 | -7338.50  | -61.02         | 573.15    | 762.95      | 873.15    | 62092.04    | 61329.09    | -88.00     | -3943.52  | 18.11  | -0.02 |  |
| CuO                 | 14.70 | -6063.70  | -50.42         | 573.15    | 61.83       | 873.15    | 2343.44     | 2281.61     | -29.34     | -4423.50  | 7.17   | -0.01 |  |
| BaO                 | 18.73 | -18743.00 | -155.84        | 573.15    | 0.0000009   | 873.15    | 0.06        | 0.06        | 461.50     | -50784.22 | -64.02 | 0.03  |  |
| SrO                 | 6.29  | -12275.00 | -102.06        | 573.15    | 0.0000003   | 873.15    | 0.0004      | 0.0004      | 106.18     | -22584.73 | -13.63 | 0.00  |  |

In Table 10, P1 and P2 are pressures of the endothermic (energy storage) and exothermic (energy discharge) steps, respectively. The temperatures corresponding to these pressures are 573.15K and 873.15K, respectively, indicating a temperature amplification of 300K.

<span id="page-62-0"></span>Table 11. Rate equations of dehydration-hydration reactions of Ca(OH)<sub>2</sub>-CaO.

| able 11. Rate equations of dehydration-hydration reactions of $Ca(OH)_2$ -CaC                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | '.<br>I              |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------|
| Equations                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | References           |
| For non-isothermal, $\frac{d\alpha}{dt} = \left(\frac{A}{\beta}\right) exp\left(-\frac{E}{RT}\right) f(\alpha)$ Cylindrical model, $G(\alpha) = 1 - (1 - \alpha)^{\frac{1}{2}}, f(\alpha) = 2(1 - \alpha)^{\frac{1}{2}}$                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | Long et al. [138]    |
| Hydration rate, $k = \frac{1}{d_p^{0.11}} 0.0069 \exp\left(-\frac{8400}{RT}\right) \left(p_{H_2O} - p_{H_2O}^*\right)$                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Lin et al. [139]     |
| For dehydration, $X < 0.2$ $\frac{dX}{dt} = 1.9425 \times 10^{12} exp \left( -\frac{187.88 \times 10^{3}}{RT} \right) \left( 1 - \frac{p}{p_{eq}} \right)^{3} (1 - X)$ $X > 0.2$ $\frac{dX}{dt} = 8.9588 \times 10^{9} exp \left( -\frac{162.62 \times 10^{3}}{RT} \right) \left( 1 - \frac{p}{p_{eq}} \right)^{3} 2 (1 - X)^{0.5}$ For hydration, $T_{eq} - T \ge 50 \text{ K}$ $\frac{dX}{dt} = 13945 \times exp \left( -\frac{89.486 \times 10^{3}}{RT} \right) \left( \frac{p}{p_{eq}} - 1 \right)^{0.83} 3 (1 - X) [-ln(1 - X)]^{0.666}$ $T_{eq} - T < 50 \text{ K}$ $\frac{dX}{dt} = 1.0004 \times 10^{-34} exp \left( \frac{53.332 \times 10^{3}}{T} \right) \left( \frac{p}{10^{5}} \right)^{6} (1 - X)$ | Schaube et al. [133] |
| For isothermal, $\frac{dX}{dt} = 1.35 \times 10^6 e^{\frac{-12354}{T}} (1 - X)$ For non-isothermal, $\frac{dX}{dt} = 1.35 \times 10^6 e^{\frac{-12354}{T_o + \beta t}} (1 - X)$                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Gupta et al. [140]   |

<span id="page-63-2"></span>Table 12. Kinetic parameters of carbonation reaction over three different temperature ranges.

|                                                  |        | Kinetic Control Region |                      |               | Diffusion Control Region |
|--------------------------------------------------|--------|------------------------|----------------------|---------------|--------------------------|
| References                                       | T (⁰C) | k (min-1<br>)          | (kJ mol-1<br>Ea<br>) | k (min-1<br>) | Ea (kJ mol-1<br>)        |
|                                                  | 600    | 0.24                   |                      | 0.098         |                          |
| Fedunik-Hofman et al.<br>(2019)<br>[141]         | 700    | 0.27                   | 17.45                | 0.158         | 59.95                    |
|                                                  | 750    | 0.30                   |                      | 0.210         |                          |
|                                                  | 600    | 0.97                   |                      | —             |                          |
| Sun et al. (2008) [142]                          | 700    | 0.81                   | 24.0                 | —             | —                        |
|                                                  | 750    | 0.67                   |                      | —             |                          |
|                                                  | 600    | 0.858                  |                      | 0.357         |                          |
| Gupta and Fan (2002);<br>Lee (2004)<br>[143,144] | 700    | —                      | 19.2                 | —             | 102.5                    |
|                                                  | 750    | —                      |                      | —             |                          |

#### <span id="page-63-0"></span>**2.2.3 Operational Parameters and Characteristics**

ChHPs, due to the considerable variety of reaction systems, have a wide range of temperatures over they operate. As a result, they can be integrated with a large number of primary energy sources as shown earlier in [Figure 13.](#page-43-0) A good summary of operating conditions for various ChHPs, listed on the basis of reaction and working fluid, is available from Sunku et al. [127] and is reproduced in [Table 13.](#page-64-0)

#### <span id="page-63-1"></span>**2.2.4 Performance, Scalability, and Capital Costs**

ChHP is a technology under development with a TRL of 2–3. As described above, the majority of investigations on ChHP systems rely upon either thermogravimetric measurements (<1 g of reactant) or small-scale laboratory investigations. [Table 14](#page-64-1) provides a broad overview of the various ChHP alternatives [127].

Experimental data on larger, pilot-scale systems is sparse, with several operational challenges described later in this report. There is a pressing need to obtain experience with pilot-scale systems operating at MW power rating and acquire useful practical data for advancing the ChHP technology.

The paucity of data also results in a difficulty in estimating the capital cost of the ChHP system. Gupta et al. [143,145] used a fundamental bottom-up approach by designing major pieces of equipment and estimating their costs for a Ca(OH)2/CaO ChHP. They arrive at a cost of \$4500/kW for what is essentially a first-of-a-kind system.

<span id="page-64-0"></span>Table 13. ChHP operating conditions and characteristics [127].

| Reaction                                                                              | T <sub>range</sub> (°C) | P <sub>range</sub> (bar) | $\Delta H$ (kJ/mol)         |      | $E_g$ (kJ/kg)            | $E_v (MJ/m^3)$                      |
|---------------------------------------------------------------------------------------|-------------------------|--------------------------|-----------------------------|------|--------------------------|-------------------------------------|
| SOLID-GAS REACTION SYSTEM                                                             |                         |                          |                             |      |                          |                                     |
| Carbonates:                                                                           |                         |                          |                             |      |                          |                                     |
| $CaCO_{3(s)} + \Delta H \rightleftharpoons CaO_{(s)} + CO_{2(g)}$                     | 973-1273                | 0–10                     | 178                         |      | 3029                     | 3260                                |
| $SrCO_{3(s)} + \Delta H \Rightarrow SrO_{(s)} + CO_{2(g)}$                            | 900-1200                | 0–2                      | 234                         |      | 300-1000                 | 1200-1500                           |
| $BaCO_3 + \Delta H \rightleftharpoons BaO_{(s)} + CO_{2(g)}$                          | ~ 1290                  | _                        | 273                         |      | _                        | _                                   |
| $PbCO_{3(s)} + \Delta H \rightleftharpoons PbO_{(s)} + CO_{2(g)}$                     | 573-1730                | 0–1                      | 88                          |      | _                        | -                                   |
| $MgCO_{3(s)} + \Delta H \rightleftharpoons MgO_{(s)} + CO_{2(g)}$                     | 320 - 431               | 0.1 - 2                  | 116.4                       |      | _                        | _                                   |
| Hydroxides:                                                                           |                         |                          |                             |      |                          |                                     |
| $CaO + H_2O \rightleftharpoons Ca(OH)_2 + \Delta H$                                   | 400-600                 | 0.1-10                   | 104.4                       |      | ~ 2000                   | 1640                                |
| Metal Hydrides:                                                                       |                         |                          |                             |      |                          |                                     |
| Reaction                                                                              | T <sub>range</sub> (°C) | P <sub>range</sub> (bar) | ΔH (kJ/mol.H <sub>2</sub> ) | Wt%  | E <sub>g</sub> (kJ/kg)   | E <sub>v</sub> (MJ/m <sup>3</sup> ) |
| $Mg + H_2 \rightleftharpoons MgH_2 + \Delta H$                                        | 300–480                 | 1–63                     | 75                          | 5.8  | 2160                     | 3995                                |
|                                                                                       | 300-500                 | 1-100                    | 74                          | 6    | 2814 (theo.)2204 (expt.) | 3996 (theo.)1763 (expt.             |
| $2Mg + Fe + 3H_2 \Rightarrow Mg_2FeH_6 + \Delta H$                                    | 300-500                 | 0–60                     | 77.4                        | 5.0  | 2106 (theo.)1921 (expt.) | 5768 (theo.)2344 (expt.             |
| $Mg_2Ni + 2H_2 \rightleftharpoons Mg_2NiH_4 + \Delta H$                               | 253-523                 | 1–20                     | 64.6                        | 3.62 | 1159.7                   | 3142.7                              |
| $NaH + Mg + H_{2(g)} \rightleftharpoons NaMgH_3 + \Delta H$                           | 475–575                 | 7–37                     | 86.6                        | 3.3  | 1721                     | ~ 1721                              |
| $NaF + Mg + H_{2(g)} \rightleftharpoons NaMgH_2F + \Delta H$                          | 510-605                 | 7–37                     | 96.8                        | 2.5  | 1416                     | 1968                                |
| $2\text{TiH} + \text{H}_2 \rightleftharpoons 2\text{TiH}_2 + \Delta \text{H}$         | 650-750                 | 1–10                     | 170                         | 1.05 | 890                      | 4014                                |
| $Ca + H_2 \rightleftharpoons CaH_2 + \Delta H$                                        | 1100 –1400              | 1–5                      | 186                         | 4.5  | 3857                     | 7374                                |
| $CaAl_2 + H_2 \rightleftharpoons CaH_2 + 2Al + \Delta H$                              | ~ 600                   | -                        | 83.1                        | 2.1  | 865                      | ~ 1488                              |
| $Na + 0.5H_2 \rightleftharpoons NaH + \Delta H$                                       | 600                     | 53                       | 117                         | 4.2  | 2072                     | 2890.8                              |
| Metal Oxides:                                                                         |                         |                          |                             |      |                          |                                     |
| Reaction                                                                              | T <sub>range</sub> (°C) | P <sub>range</sub> (bar) | ΔH (kJ/mol)                 |      | E <sub>g</sub> (kJ/kg)   | E <sub>v</sub> (MJ/m <sup>3</sup> ) |
| $2\text{Co}_3\text{O}_4 + \Delta\text{H} \rightleftharpoons 6\text{CoO} + \text{O}_2$ | ~ 900                   | ~ 1                      | 200                         |      | 844                      | 720                                 |
| $2BaO_2 + \Delta H \rightleftharpoons 2BaO + O_2$                                     | ~ 740                   | ~ 1                      | 79.4                        |      | 527.18                   | 3015                                |
|                                                                                       | 727– 1027               | 0.11-1                   | 77.3                        |      | 468                      | 2900                                |
| $6Mn_2O_3 + \Delta H \rightleftharpoons 4Mn_3O_4 + O_2$                               | $T_{eq} = 1000$         | ~ 1                      | 32                          |      | 204                      | 225                                 |
| $4CuO + \Delta H \rightleftharpoons 2Cu_2O + O_2$                                     | $T_{\rm eq} = 1030$     | < 1                      | 64                          |      | 811                      | -                                   |

<span id="page-64-1"></span>Table 14. Types of HPs and technology gaps [127].

| Material      | Advantages                                                                            | Drawbacks                                                              | Technology Status                                        |
|---------------|---------------------------------------------------------------------------------------|------------------------------------------------------------------------|----------------------------------------------------------|
| Carbonates    | Cheap, abundant, and non-toxic                                                        | Less reversibility                                                     | Lab-scale (fixed or fluidized-bed reactors) and          |
|               | <ul> <li>High energy density</li> </ul>                                               | <ul> <li>Low cyclic stability (10–20</li> </ul>                        | pilot-scale (CaL technology for CO <sub>2</sub> capture) |
|               | <ul> <li>High operating temperatures (up to 1700 K)</li> </ul>                        | cycles)                                                                |                                                          |
|               | suitable for high-temperature power generation                                        | <ul> <li>Sintering</li> </ul>                                          |                                                          |
| Hydroxides    | <ul> <li>Low material cost</li> </ul>                                                 | <ul> <li>Agglomeration of material</li> </ul>                          | Lab-scale and pilot-scale                                |
|               | <ul> <li>Abundant</li> </ul>                                                          | <ul> <li>Side reactions with CO<sub>2</sub></li> </ul>                 |                                                          |
|               | <ul> <li>Non-toxic</li> </ul>                                                         |                                                                        |                                                          |
| MetalHydrides | <ul> <li>High energy density</li> </ul>                                               | <ul> <li>Poor reaction kinetics</li> </ul>                             | Pilot-scale                                              |
|               | High reversibility                                                                    | <ul> <li>Hydrogen embrittlement</li> </ul>                             |                                                          |
|               | <ul> <li>A lot of experimental feedback on H<sub>2</sub>-storage and</li> </ul>       | <ul> <li>Higher material cost</li> </ul>                               |                                                          |
|               | heat pump applications                                                                |                                                                        |                                                          |
| Oxides        | <ul> <li>High reaction enthalpy (205 kJ/mol)</li> </ul>                               | <ul> <li>Storage of O<sub>2</sub></li> </ul>                           | Lab-scale                                                |
|               | <ul> <li>Wide operating temperature (400–1300 K)</li> </ul>                           | <ul> <li>Toxicity of products (Co<sub>3</sub>O<sub>4</sub>/</li> </ul> |                                                          |
|               | <ul> <li>Low operating pressure (0–10 bar)</li> </ul>                                 | CoO)                                                                   |                                                          |
|               | No catalyst                                                                           | <ul> <li>Cost of products</li> </ul>                                   |                                                          |
|               | <ul> <li>No side reaction (BaO/BaO<sub>2</sub>)</li> </ul>                            | •                                                                      |                                                          |
|               | <ul> <li>High reversibility (500 cycles) (Co<sub>3</sub>O<sub>4</sub>/CoO)</li> </ul> |                                                                        |                                                          |

## <span id="page-65-0"></span>**3 COMPARISON OF HEAT PUMP TECHNOLOGIES FOR ULTRA-HIGH-TEMPERATURE APPLICATIONS**

## **3.1 Mechanically Driven Heat Pump Technologies**

<span id="page-65-1"></span>This section is intended to summarize the literature review findings in terms of HP technologies that are currently available within or close to the range of UHT previously defined in Section [2.](#page-19-0)

From the literature database, a criterion was implemented to select those works that show a high source of informational potential. Within the selected criteria parameters are:

- MDHPs were selected for this comparison. TDHPs, specifically ChHP are addressed in another section (Section [3.2\)](#page-75-0). This is due to the large technological differences and challenges between mechanical and ChHPs.
- HP technologies and important HP components that can withstand the defined UHT of interest (T2> 250℃). It is worth clarifying that the actual definition of UHT used in this work considers those applications in which the sink temperature is Tsink> 250°C. The sink temperature was not used as a filtering option because of its rare availability in the reported data. The compressor outlet and inlet temperatures were parameters more easily found in the literature. Furthermore, the maximum temperature of the HP is dictated by T2, which is independent of the heat sink heat exchanger efficiency; hence, T<sup>2</sup> was considered a good parameter to identify those technologies with the potential of delivering UHT.
- Studies that involve individual HPs or those involving HPs installed within a broader system.
- In terms of the study types, two themes emerged: simulations/theoretical studies and experimental studies. The simulation/theoretical classification included the thermodynamic assessments of HP systems, estimation of components optimal operational conditions, impact of working fluids on HP performance and related efficiencies, etc. The experimental classification included the efforts of prototype testing, components improvements, and showcases of commercially available HPs capable of working at or near UHT.
- In terms of the HP application, there was no filter as long as the application or final customer required UHT. There was a scarcity of UHTHP applications; hence, at the beginning of this search, it was decided to include technological applications, which did not necessarily involve a HP. For instance, a previously considered candidate topic was research on power generation using solar-dish Stirling technologies [56,57,59,77,146,147]. This was justified by the fact that Stirling engines can be easily converted to a HP by reversing the heat exchange between the hot and cold spaces [65]. However, this approach was subsequently discarded because of the difficulty of comparing with other HP technologies. Moreover, although solar-dish Stirling systems can operate in the upper end of the UHT range (~900°C), these operate mainly in the free-piston Stirling configuration [76,148]. This in fact created issues on the hypothetical implementation as a HP since mechanical work is indeed required for the ultimate temperature increase. Hence, all the heat to power applications were disregarded. An application that remained within the scope of this research was the direct application of HPs linked to thermal energy storages (i.e., pump thermal energy storage systems [PTESs]). Studies providing HP characteristics within the PTES charging cycle were included. The PTES studies presented a challenge in terms of developing a fair comparison against other HP technologies. For instance, the PTES HPs are theoretically exposed to limiting maximum temperatures near 1000°C when charging the hot storage, while at the same time exposed to subzero minimum temperatures when charging the cold storage. Hence, it was deemed important to include such scenarios. This can provide an indication of the limiting temperatures and pressures that HPs may, theoretically speaking, be able to operate.

- COP for technology comparison. For the comparison of thermodynamic systems, it is common practice to utilize the Carnot efficiency (ηsys). The Carnot efficiency has been defined in terms of heat to power systems, such as the Rankine or Brayton cycles. However, considering that mechanical HPs are based on either reversed Brayton or reverse Rankine cycles, the HP performance is based on the COP, which, in the ideal case, is the inverse of the Carnot efficiency. To define the COP in terms of HP parameters, we refer to [Figure 31.](#page-67-0)
- [Figure 31.](#page-67-1) This figure depicts the basic components, namely compressor, hot heat exchanger (HHX) expansion valve, turbine, and cold heat exchanger (CHX). The HHX and CHX are the heat thermal transport components interacting with the sink and the source process fluids, respectively. The source process fluid arrives at a temperature Tsource and departs at a temperature Tsource. And the sink process fluid arrives at a temperature Tsink and departs at a temperature Tsink. An important figure of merit is the temperature lift, which is defined as the temperature rise between the HP sink and source ΔTLift = Tsink − Tsource. Another important figure of merit describing the performance of the HP is the working fluid temperature differential before (T1) and after the compressor (T2), here defined as ΔT<sup>C</sup> = T<sup>2</sup> − T1, which for vapor and gas compression ideal isentropic scenarios, is related to the work required to drive the compressor. Hence the COP is defined as:

$$COP = \frac{T_2}{T_2 - T_1}$$

Using the COP as defined above may seem a fair measure to compare the performance among the different technologies found in the literature. However, each technology has unique configurations, and the COP as defined above may be inadequate. For instance, in the studies on which thermal storage uses a HP to charge, the parameters in the previous equation may be misleading because the COP represents the efficiency of a machine operating on a Carnot-equivalent cycle, which may not be the case for thermal storage systems. This is because in the Carnot cycle, heat addition and rejection are assumed to occur at constant temperatures, which may not be consistent with the need to progressively heat or cool a thermal storage mass from a charged temperature back to a discharged temperature [149]. For the same reasons, the HP sink and source temperatures of PTES systems may seem significantly larger in magnitude. Having this in mind, it was decided to use the reported COP from the various studies rather than directly using the reported inlet and outlet temperatures of the compressor.

• Working fluids. There was no filtering in terms of the explored working fluids. The only consideration was that the working fluids should not be above degradation limits nor above safe operational conditions inherent to the fluid.

<span id="page-67-1"></span>![](_page_67_Picture_0.jpeg)

Figure 31. Mechanical HP simplified cycle.

<span id="page-67-0"></span>• Technological readiness level (TRL). One of the important measures to test new technology feasibility in terms of near-term industrial availability is the TRL. The TRL measures the evolution of a new technology from its conception, design, development, and deployment. Based on the literature survey, each of the studies were classified depending on their TRL.

[Table 15](#page-73-0) summarizes the literature review findings using the criteria explained above. It is worth noting that some parameters were gathered directly from the document text, figures, and diagrams when available. In the cases in which a parameter was not found, it was inferred from ideal cycle expressions and from related reported parameters. For instance, in those cases in which the inlet compressor temperature (T1) was not available, the isentropic compression relationship for ideal gases was used:

$$\frac{T_2}{T_1} = \frac{P_2^{\left(1 - \frac{1}{\gamma}\right)}}{P_1}$$

which relates the temperature (T2/T1), pressure (P2/P1), and the specific heat ratios (or isentropic exponent) (Cp/Cv) through the compression process. These expressions depended on the availability of data, type of cycle and working fluid.

[Figure 32](#page-69-0) is an attempt to visually highlight the studies summarized in [Table 5.](#page-38-0) In this figure, the temperature rise through the compressor is graphically displayed as the length of a bar, starting at T<sup>1</sup> and ending at T2; with this approach, relationship among the type of cycle and working fluids can be inferred. Also, by means of a color coding, the technological readiness level is distinguished, red representing those works with a TRL > 6, and black to those with TRL ≤ 5. As per the TRL classification (see Appendix A), the TRL≤ 5 is assigned to technologies that have only been studied theoretically by proofof-concept simulations without prototypes or working units available. On the other hand, a TRL > 6 include those technologies that provide a physical prototype and experimental evidence to test the new technology. Out of the 32 found studies, only four were classified with a TRL >6. This is a clear indication of the scarcity of efforts toward the development of HP technology for UHT. Nevertheless, there is an increasing interest in the potential use of UHTHP as a plausible substitute of fossil-based heat augmentation devices. In the next paragraphs, we summarize those works with TRL>6.

Degueurce et al. [35] in 1984 showed one of the first attempts on the improvement of mechanical vapor compression technology towards industrial HP utilization. On their research, a HP facility was

developed to test a commercially available twin screw air compressor. The tests were aimed to evaluate the use of water as a refrigerant instead of air. These tests were successful; the compressors outlet temperature using steam reached about 250°C. This temperature is on the lower end of the UHT pursued in the current review. However, it was decided to highlight this work because it demonstrates that legacy equipment can be modified to perform outside of the original designed operational conditions. This may be the case for UHTHP technology, on which currently available components need to be modified or retrofitted to reach the temperature and performance levels required to implement an efficient HP. For instance, backed by the simulation studies summarized in Table 15, multiple fluids and fluids mixtures may be used to gain higher efficiencies; this implies that experimental efforts are required to test these claims and that a compressor and HP related components need to allow multiple working fluids testing. This may be one of the main obstacles for further development because most components are fluid-specific designs that may not accommodate multiple fluids. This application was deemed plausible by the authors, and a TRL of 8 was assigned because of the successful demonstration and reasonable results. However, no follow-up work by the authors within this area was found. No temperature lift information of the process fluid was available.

Howes et al. (2011) [149] showcased multiple prototypes of HPs integrated to a thermal energy storage. These prototypes were tested under controlled experimental conditions. The thermodynamic cycle was based on the Ericsson cycle and targeted to have large temperature differences between the hot and cold storage tanks. However, caution on the interpretation of such results is deemed necessary. There were no details on the working nor the design of the HP. This was found to be a common practice of companies showcasing their designs. Some experimental results were presented but with little to no inference as to the scale of temperature plots. From what was reported in the paper, it was gathered that this HP worked similarly to a Stirling engine described in Section 2.1.2.2. This HP used argon as a working fluid, and a theoretical large-scale application was proposed capable of achieving up to a maximum temperature of  $T_2 \approx 500^{\circ}\text{C}$  and a cold storage temperature of about  $T_{\text{sink}} \approx -166^{\circ}\text{C}$ . No experimental evidence of such temperatures was available nor was further work by the authors published; hence, a TRL of 6 was assigned. No temperature lift information of the process fluid was available.

Bassem et al. [75] in 2011 tested the capabilities of a thermoacoustic Stirling HP. Using nitrogen at a system pressure of 0.5 MPa, they achieved a sink temperature  $T_2 \approx 370^{\circ}\text{C}$  with a source temperature of about  $T_{\text{source}} \approx 40^{\circ}\text{C}$ . There was no mention of the HP capacity nor any detail on the heat sink process fluid characteristics. The prototype performance was verified with experimental measurements, and a TRL of 6 was assigned. There have been some follow-up studies and prototypes in the literature; for instance, a study not included in the present work summary was a demonstration by Tianjiao et al. [150] in 2017. They developed a 5 kW prototype of a thermoacoustic engine capable of reaching temperatures up to 650°C. This work was not included due to the small laboratory scale and the fact that it was not a direct application to HP technology. Although thermoacoustic HP technology is still in its infancy, some companies have ventured to produce medium-scale machines for heating and cooling applications[151,152]. Similarly, as with other technologies, the source temperatures remain well below 250°C, hence limiting the output of thermoacoustic HPs. This should be a niche of research with a lot of potential for the UHTHP.

![](_page_69_Figure_0.jpeg)

<span id="page-69-0"></span>Figure 32. Temperature changes through the compression stage reported from the literature.

In 2020, Zevenhoven et al. [78] presented a study of a HP based on the reverse Rankine cycle, featuring the HighLift model of Olvondo Technology [79]. The researchers developed an optimization process on the heat exchangers and operational conditions to achieve maximum temperatures of about T<sup>2</sup> ≈ 227°C using helium as the working fluid and an average pressure of about 5 Mpa and a capacity of 750 kW. Although this HP underperformed in terms of UHT, it is a promising candidate considering that the source temperature was room temperature (T<sup>1</sup> = 21°C). The Olvondo Technology in this work was issued a TRL of 8 because an actual prototype was tested in an industrial setting. This reversed Stirling cycle towards high-temperature HP technologies has been also explored by Contreras [82]. The merits of Contreras work [82] was the use of currently available HP technology for operational conditions just below UHT following the use of electrical heaters to reach above UHT. The HTHP by Enerin-Engineering, the HoegTemp [4], was used, and a technoeconomic analysis was performed. The HoegTemp [4] HP was not included in the technologies with high TRLs because no experimental results from an actual unit are found outside of the company datasheet. The HoegTemp HP was assigned a TRL of 5.

One of the more meaningful developments towards UHTHP are the recent efforts of the DLR-COBRA prototype [153]. This prototype has the aim to address industry needs for temperature augmentation higher than 200°C. Their latest claims set the maximum achieved temperature of T<sup>2</sup> ≈350°C. This technology has been backed up by peer-reviewed articles [13,154] and a lot of attention from the community on the energy sector. The COBRA prototype is a reversed Brayton cycle HP with air as a working fluid. It has been reported with a COP of 1.48 for an output temperature of 276.9°C using only ambient air with 15°C as heat source [13]. Although the main objective of the COBRA prototype is for the experimentation and optimization of HPs, it was assigned a TRL level of 8. This level can be improved once the technology is in commercial venues.

From the summary of works with high TRL (highlighted red in [Figure 32\)](#page-69-0) discussed earlier, several conclusions can be inferred. In terms of the operational temperatures, there are no mature HP technologies targeting UHTs. Studies with high TRL inlet compressors temperatures are well below the low-end limit of the defined UHT range, and only three studies documented outlet compressor temperatures within the UHT range. These results may mislead to believe that the feasibility of UHTHP is not practical; however, these limitations may be attributed to the fact that there has been no need to upgrade the already high-quality thermal sources above 250°C, which historically, have been upgraded by means of high-temperatures boilers or others high CO<sup>2</sup> emission components.

In the other hand, when considering the studies with lower TRL (<5) (shown in black in [Figure 32\)](#page-69-0), it is clear that UHTHP is a technology with high potential for temperature augmentation above the 250°C limit, and also, with high potential for feasible implementation. This statement is supported by multiple theoretical studies pursuing the same goal of pushing the HP technology to higher temperatures applications.

Another important finding of this review is that most of the identified theoretical works (i.e., TRL <5) study the performance of thermal energy storage systems driven by UHTHP. These works are shown green in [Figure 32.](#page-69-0) Pursuance of facilities construction or prototype testing is a common suggestion among researchers for model validation. From the HP perspective, these works expect relaxed technological limitations to allow maximum temperatures close to those found in high energy power cycles.

Hence, there is a preferential use of reversed Brayton cycle HPs for energy storage applications. Brayton cycles are known to work at much higher temperatures than Rankine cycles. The Brayton cycles listed in [Figure 32](#page-69-0) show the use of multiple gases as working fluids, such as helium, nitrogen, argon, air, and CO2.Within the thermal storage studies found, only one used a water/ammonia Rankine cycle and showed the lowest expected temperature at the outlet of the compressor.

The studies labeled as "others" (shown in black in [Figure 32\)](#page-69-0), accounted for either HPs in industrial applications or studies related to HPs improvements. Among the applications are spray drying, distillation, pressurized hot water, alumina production, solar power generation, hydrogen production, water desalination, etc. The industrial application of HPs in the UHT range includes both Rankine and Brayton cycles. These do not go above the maximum temperature of 650°C. Interestingly the maximum temperature was achieved on a Rankine cycle rather than on a Brayton cycle, which was the case for the thermal storage studies. The working fluids of the HP Rankine cycles include transcritical CO2, water/ammonia, ethanol/P-Xylene, and water, while the working fluids for the Brayton cycle were supercritical CO<sup>2</sup> and argon.

[Figure 33](#page-71-0) shows the COP values reported on the UHTHP found in the literature. These were organized by type of working fluid and by type of thermodynamic cycle. The thermodynamic cycle was color coded: green and black color codes corresponding to Brayton cycles, while red color code represented Rankine cycles. Additionally, the green color identified those studies in which HPs working on a Brayton cycle was used on thermal storage applications. The size of the circles on this scatter plot is related to the maximum temperature in the HP cycle (T2). Several trends were relevant for the HP

discussion. There is an apparent correlation between the COP and the thermodynamic cycles such that it was possible to define a COP boundary dividing the cycles. This COP boundary was found at a value of about COP=3.0, above which only studies using the Rankine cycle were found. Below COP = 3.0, only Brayton cycles are found. Another trend within the Brayton cycles studies was related to the maximum temperatures. Studies of thermal energy storages reported the highest temperatures as shown by the green color-coded circles. In the other hand, the Rankine cycles showed lower maximum temperatures (see redcoded circles). These are expected trends since Brayton cycles can achieve larger temperature lifts, which in turn will reduce the COP values. An opposite trend is observed by the Rankine cycles in which the maximum temperatures are moderate with lower temperature lifts, which increases the COP significantly.

![](_page_71_Figure_1.jpeg)

<span id="page-71-0"></span>Figure 33. Working fluids influence on the COP.

[Figure 34](#page-72-0) shows a comparison among the selected studies of the temperature lift (ΔTLift) impact on the reported COP. The temperature lift has a clear decreasing trend as a function of the COP. Considering the definition of the ideal definition of the COP and its relationship to the temperature lift, this trend is the expected result. However, it is still surprising to find this trend even among these highly diverse types of works. As previously mentioned, each COP reported value is based on each study particular system configuration and on assumptions from researchers. Finding the expected trend is an indication of a correct data gathering process by the authors of this document. This process included in some instances, inferring values for missing data points from other given parameters and theoretical relationships of ideal thermodynamic scenarios. [Figure 34](#page-72-0) has the same color code as in [Figure 33](#page-71-0) and shows the same "cycles" boundary at a value of COP=3 which was discussed previously. Also, as expected the studies with thermal storage are shown to have the highest values of temperature lifts with a maximum of 675°C but reported, as discussed previously, low values of COP.

Following this trend, we can make predictions towards targeted COP and temperature lifts. For instance, if our interest is to have a temperature lift of say ΔTLift ≈300°C we can pursue a HP based on the reverse Brayton cycle with a predicted COP value of about 2.4. But if our interest is to have a COP larger than three, we must sacrifice the temperature lift to up to ΔTLift ≈200°C with a Rankine cycle. Further

down-selection of the working fluid and system configuration will be required depending on the process fluid thermodynamics, heat exchanger types and efficiencies, and availability of compressors technology.

The results presented in this section are intended to serve as a guiding starting point in terms of UHTHP cycle capabilities. Also, curves such as the one portrayed in [Figure 34](#page-72-0) may help guide the selection of HP thermodynamic cycle depending on the sink and source temperatures and the targeted COP.

It can be concluded that the gathered information in this work helped fulfill two main purposes: to demonstrate that an UHTHP is a feasible option and to help as a starting point towards the design of an UHTHP based on the initial system requirements, namely ΔTLift and COP.

![](_page_72_Figure_3.jpeg)

<span id="page-72-0"></span>Figure 34. ΔTLift vs COP for selected studies in the literature. Circle size depends on the maximum temperature (T2).

Table 15. MDHP technologies for UHT application.

<span id="page-73-0"></span>

| Reference                      | Cycle                   | Type of<br>Research | Working<br>Fluid | COP<br>[-] | T1<br>[℃] | T2<br>[℃] | Pmax<br>[bar] | Pr [-] | Tsource<br>[℃] | Tsink<br>[℃] | ΔTlift<br>[℃] | Capacity<br>[MW] | Effic. | TRL |
|--------------------------------|-------------------------|---------------------|------------------|------------|-----------|-----------|---------------|--------|----------------|--------------|---------------|------------------|--------|-----|
| Vinnemeier et al. (2016) [155] | Brayton                 | Simulation          | Air              | 1.3        | 483.0     | 600.0     | 120.0         | 3.4    | 25.0           | 600.0        | 850.0         | —                | 0.6    | 3.0 |
| Oehler et al. (2021) [13]      | Brayton                 | Experimental        | Air              | 1.7        | 197.0     | 370.0     | 3.0           | 3.0    | 15.0           | 370.0        | 370.0         | 0.2              | 0.7    | 8.0 |
| Mahdi (2022) [156]             | Brayton                 | Simulation          | Air              | 2.8        | 400.0     | 551.6     | 100.0         | 2.0    | 290.0          | 560.0        | 270.0         | 100              | 79.0   | 3.0 |
| Sharan et al. (2021) [44]      | Brayton                 | Simulation          | N2               | 7.0        | 425.0     | 485.0     | 10.0          | 10.0   | 350.0          | 450.0        | 100.0         | —                | 0.9    | 3.0 |
| Davenne (2020) [157]           | Brayton                 | Simulation          | Ar               | —          | 25.0      | 726.0     | 200.0         | 20.0   | -<br>150.0     | 726.0        | 876.0         | 1000.0           | 0.7    | 3.0 |
| Howes (2011) [149]             | Ericsson                | Experimental        | Ar               | —          | 55.0      | 500.0     | 12.0          | 12.0   | -<br>166.0     | 500.0        | 666.0         | 0.2              | 0.7    | 6.0 |
| Pimm et al. (2023) [55]        | Brayton                 | Simulation          | Ar               | 1.7        | 263.0     | 500.0     | 200.0         | 200.0  | 303.2          | 500.0        | 196.9         | 1                | 0.7    | 3.0 |
| Laughlin et al. (2017) [30]    | Brayton                 | Simulation          | Ar               | —          | 221.9     | 549.0     | 36.0          | 3.6    | -93.2          | 549.0        | 642.2         | —                | 0.7    | 3.0 |
| Desrues et al. (2010) [158]    | Brayton                 | Simulation          | Ar               | —          | 500.0     | 1000.0    | 5.0           | 4.6    | -70.0          | 1000.<br>0   | 1070.<br>0    | 600.0            | 0.7    | 3.0 |
| Vinnemeier et al. (2016) [155] | Brayton                 | Simulation          | Ar               | 1.3        | 483.0     | 600.0     | 50.0          | 1.4    | 25.0           | 600.0        | 850.0         | —                | 0.6    | 3.0 |
| McTigue (2020) [59]            | Brayton                 | Simulation          | Ar               | 2.4        | 350.0     | 560.0     | 250.0         | 3.1    | -30.2          | 560.0        | 590.2         | —                | 0.7    | 3.0 |
| Mahdi (2022) [156]             | Brayton                 | Simulation          | Ar               | 2.8        | 400.0     | 496.6     | 36.0          | 1.6    | 290.0          | 560.0        | 270.0         | 100              | 78.0   | 3.0 |
| White et al. (2013) [159]      | Brayton                 | Simulation          | Ar               | —          | 25.0      | 500.0     | 4.0           | 4.0    | -<br>173.0     | 500.0        | 673.0         | —                | —      | 3.0 |
| Tafur et al. (2022) [60]       | Brayton (Supercritical) | Simulation          | CO2              | —          | 427.0     | 626.9     | 250.0         | 2.9    | 27.0           | 600.0        | 573.0         | 12.0             | 0.8    | 3.0 |
| Zuhlsdorf et al. (2019) [12]   | Brayton (Multistage)    | Simulation          | CO2              | 3.0        | 140.0     | 290.0     | 1400.0        | 3.5    | 60.0           | 280.0        | 220.0         | >>1              | 0.5    | 3.0 |
| Vinnemeier et al. (2016) [155] | Brayton (—)             | Simulation          | CO2              | 1.3        | 563.0     | 700.0     | 200.0         | 5.7    | 25.0           | 700.0        | 950.0         | —                | 0.6    | 3.0 |
| Mallinak (2023) [61]           | Rankine (Transcritical) | Simulation          | CO2              | 2.4        | 276.9     | 600.0     | 200.0         | 4.0    | 250.0          | 550.0        | 300.0         | —                | 0.7    | 3.0 |
| McTigue (2020) [59]            | Brayton (Supercritical) | Simulation          | CO2              | 2.4        | 400.0     | 560.0     | 250.0         | 3.1    | 16.3           | 560.0        | 543.7         | —                | 0.7    | 3.0 |

| Reference                       | Cycle                 | Type of<br>Research | Working<br>Fluid    | COP<br>[-] | T1<br>[℃] | T2<br>[℃] | Pmax<br>[bar] | Pr [-] | Tsource<br>[℃] | Tsink<br>[℃] | ΔTlift<br>[℃] | Capacity<br>[MW] | Effic. | TRL |
|---------------------------------|-----------------------|---------------------|---------------------|------------|-----------|-----------|---------------|--------|----------------|--------------|---------------|------------------|--------|-----|
| Aga et al. (2016) [15]          | Brayton (Recuperator) | Simulation          | CO2                 | 1.2        | 280.0     | 490.0     | 200.0         | 200.0  | 60.0           | 565.0        | 505.0         | 100.0            | 0.4    | 3.0 |
| Zuhlsdorf et al. (2019)<br>[12] | Brayton (Multistage)  | Simulation          | CO2                 | 3.0        | 140.0     | 290.0     | 1400.0        | 3.5    | 50.0           | 210.0        | 160.0         | >>1              | 0.5    | 3.0 |
| Mahdi (2022)<br>[156]           | Brayton (—)           | Simulation          | CO2                 | 2.7        | 400.0     | 653.2     | 200.0         | 3.0    | 290.0          | 560.0        | 270.0         | 100              | 78.1   | 3.0 |
| Aga et al. (2016)<br>[15]       | Brayton (Recuperator) | Simulation          | CO2                 | 1.3        | 280.0     | 490.0     | 200.0         | 200.0  | 60.0           | 565.0        | 505.0         | 100.0            | 0.4    | 3.0 |
| Abedini et al. (2023)<br>[28]   | Rankine (—)           | Simulation          | Ethano/<br>P-Xylene | 3.5        | 110.0     | 259.0     | 23.0          | 11.5   | 110.0          | 200.0        | 90.0          | —                | —      | 3.0 |
| Zevenhoven, et al. (2020) [78]  | Stirling (—)          | Experimental        | He                  | 1.9        | 27.0      | 227.0     | 38.0          | 1.4    | 20.0           | 200.0        | 180.0         | 0.8              | 0.7    | 9.0 |
| Guo et al. (2016) [160]         | Brayton (—)           | Simulation          | Idal gas            | —          | 386.0     | 550.0     | 100.0         | 10.0   | 26.9           | 550.0        | 523.2         | —                | 0.6    | 3.0 |
| Mahdi (2022) [156]              | Brayton (—)           | Simulation          | N2                  | 2.8        | 400.0     | 549.6     | 60.0          | 2.0    | 290.0          | 560.0        | 270.0         | 100              | 79.0   | 3.0 |
| Laughlin et al. (2017) [30]     | Brayton (—)           | Simulation          | N2                  | —          | 221.9     | 549.0     | 65.0          | 6.5    | -93.2          | 549.0        | 642.2         | —                | 0.7    | 3.0 |
| Bassem et al. (2011) [75]       | Stirling (—)          | Experimental        | N2                  | —          | 25.0      | 370.0     | 0.0           | 4.0    | —              | —            | —             | —                | —      | 5.0 |
| Degueurce et al. (1984) [35]    | Rankine (—)           | Experimental        | Water               | 15.8       | 118.0     | 246.0     | 3.0           | 2.5    | 94.4           | 196.8        | 102.4         | 0.124            | 0.6    | 9.0 |
| Zuhlsdorf et al. (2019) [12]    | Rankine (Multistage)  | Simulation          | Water               | 3.0        | 125.0     | 397.0     | 68.0          | 27.2   | 60.0           | 280.0        | 220.0         | >>1              | 0.5    | 3.0 |
| Zuhlsdorf et al. (2019) [12]    | Rankine (Multistage)  | Simulation          | Water               | 3.0        | 125.0     | 397.0     | 68.0          | 27.2   | 50.0           | 210.0        | 160.0         | >>1              | 0.5    | 3.0 |
| Abedini et al. (2023) [28]      | Rankine (—)           | Simulation          | Water               | 3.7        | 97.3      | 430.0     | 7.0           | 1.0    | 97.3           | 162.0        | 64.7          | —                | —      | 3.0 |
| Abedini et al. (2023) [28]      | Rankine (—)           | Simulation          | Water/<br>Ammonia   | 3.5        | 110.0     | 473.0     | 16.0          | 12.2   | 110.0          | 200.0        | 90.0          | —                | —      | 3.0 |
| Steinmann et al. (2014) [161]   | Rankine (Cascade)     | Simulation          | Water/<br>Ammonia   | —          | 60.0      | 400.0     | 105.0         | 105.0  | 10.0           | 400.0        | 390.0         | 1000.0           | 0.7    | 3.0 |
| Abedini et al. (2023) [28]      | Rankine (—)           | Simulation          | Water/<br>Ethanol   | 3.5        | 110.0     | 378.0     | 17.0          | 15.2   | 110.0          | 200.0        | 90.0          | —                | —      | 3.0 |

## **3.2 Thermally Driven Heat Pump Technologies**

<span id="page-75-0"></span>As discussed in Section [2,](#page-19-0) the technological differences between the ChHP and MDHP result in a major challenge in conducting the comparative analysis of ChHP technologies on a single and unified basis. Nevertheless, an attempt is made to follow a similar approach and use similar criteria, discussed in Sectio[n 3.1,](#page-65-1) to assess the various alternatives.

• COP for technology comparison: The concept of COP for MDHPs is well established and is relatively straightforward to understand as it can be readily computed on the basis of lower and upper temperatures. For ChHPs, it is more appropriately expressed in terms of energies involved [119] as shown below:

$$COP_{ch} = \frac{\text{Heat avaiable at upgraded temperature}}{\text{Energy supplied for regeneration}}$$

The energy term in the denominator includes heat as well as mechanical energy that is inevitably needed for compressing the gases.

- Working Fluids: Working fluids in the MDHPs function as energy carriers while retaining their chemical structure, that is, their chemical identity remains unchanged as they move through energy storage and discharge steps. Working fluids in the ChHPs function as partial energy carriers, as some of the energy remains with another chemical that is typically a solid phase reagent. Further, the working fluid chemical identity changes between energy storage and discharge steps, as it participates in a reaction with the solid reagent.
- TRL: TRL, as discussed in Sectio[n 3.1,](#page-65-1) indicates the status of the technology as it evolves from its conception through design, development, and demonstration to deployment. In general, ChHP technologies, particularly high and UHTHP technologies have a low TRL, typically 3–5. Some lowtemperature organics-based ChHP technologies have been further along in their development with a TRL of 7 or 8, but these have limited utility for the high-temperature industrial process applications of interest and are not included in the analysis.

The following table, [Table 16,](#page-76-0) summarizes the different ChHP systems on the basis of working fluids and temperatures. The studies listed in this table are visually highlighted in the figure following the table. As with the figure for MDHPs [\(Figure 32\)](#page-69-0), the temperature rise is depicted as a bar, starting at T<sup>1</sup> and ending at T<sup>2</sup> with this approach.

Table 16. ChHP technologies for UHT application.

<span id="page-76-0"></span>

| Systems             | Working<br>Fluid | References                     | Type of<br>Studies           | T <sub>1</sub> [°C] | ΔT <sub>lift</sub> [°C] | T <sub>2</sub> [°C] | Capacity   | TRL |
|---------------------|------------------|--------------------------------|------------------------------|---------------------|-------------------------|---------------------|------------|-----|
|                     |                  | Ervin, 1977 [109]              | Experiment                   | 450                 | 50                      | 500                 |            | 3   |
|                     |                  | Wongsuwan et al., 2001 [98]    | Experimental/<br>Theoretical | 350                 | 250                     | 600                 |            | 3   |
|                     |                  | Hasatani, 1992 [110]           | Experiment                   | 366                 | 566                     | 932                 |            | 3   |
| Ca(OH) <sub>2</sub> | $_{ m H_2O}$     | Fujimoto et al., 2002 [111]    | Experiment/<br>Simulation    | 427                 | 73                      | 500                 | 0.5-1KW/kg | 3   |
| 0(011)2             | 1120             | Criado et al., 2017 [112]      | Experiment                   | 460                 | 50                      | 510                 | 0.0 112    | 3   |
|                     |                  | Schmidt et al., 2014 [114]     | Experiment                   | 400                 | 150                     | 550                 |            | 5   |
|                     |                  | Funayama et al., 2019 [113]    | Experiment                   | 490                 | 110                     | 600                 |            | 3   |
|                     |                  | Gupta et al., 2021 [162]       | Experiment                   | 350                 | 370                     | 720                 |            | 3   |
|                     |                  | Linder et al., 2014 [115]      | Experiment                   | 400                 | 200                     | 600                 |            | 5   |
|                     |                  | Kim et al., 2019 [163]         | Experiment                   | 330                 | 30                      | 360                 |            | 3   |
| MO                  | 11.0             | Mastronardo et al., 2016 [117] | Experiment                   | 350                 | 150                     | 500                 | 119 W/kg   | 3   |
| MgO                 | $H_2O$           | Pan et al., 2015 [118]         | Experiment                   | 300                 | 200                     | 500                 | 203 Kpa    | 3   |
|                     |                  | Kato et. al. 2005 [116]        | Experiment                   | 400                 | 200                     | 600                 |            | 3   |
|                     |                  | Kyaw et al., 1997 [119]        | Experiment                   | 500                 | 499                     | 999                 |            | 3   |
| CaCO <sub>3</sub>   | $CO_2$           | Meier et al., 2004 [121]       | Experiment                   | 425                 | 724                     | 1149                | 0.5-1KW/kg | 5   |
|                     |                  | Nikulshina et al., 2009 [126]  | Experiment                   | 875                 | 325                     | 1200                |            | 4   |
| PbCO <sub>3</sub>   | $CO_2$           | Kato et al., 1999 [120]        | Experiment                   | 450                 | 300                     | 750                 | NA         | 3   |

### **Chemical Heat Pump Literature Example**

![](_page_77_Figure_1.jpeg)

<span id="page-77-0"></span>Figure 35. Temperature lift achieved using ChHPs.

## <span id="page-78-0"></span>**4 TECHNICAL GAPS, CHALLENGES, AND POTENTIAL IMPROVEMENT**

## **4.1 Mechanically Driven Heat Pumps**

<span id="page-78-1"></span>Successful implementation and operation of MDHP for UTH heat pumping (T>250℃) requires both reliable component technology and a well-designed HP system for improved system performance. Defining the appropriate equipment type, sizing, and operating parameters is arguably the most challenging aspect of developing HTHP and UHPHP systems [29]. For the UHTHPs, the major technical challenges often involve the less matured component technology, the necessity for additional material and safety testing, and limitations in HP performance due to the high temperature operation. In general, the key challenges to developing the MDHPs for UHT application include the following five aspects: (i) materials, (ii) turbomachinery (especially, compressor), (iii) working fluids, (iv) heat exchanger (thermal interface design), and (v) advanced HP system configuration for performance enhancement.

This section focuses on the technical gaps and challenges in each aspect that must be addressed to enable the practical implementation of MDHPs for UHT application purposes. In addition, potential improvements as well as research and development needs are discussed for each aspect as appropriate.

#### <span id="page-78-2"></span>**4.1.1 Turbomachinery (Compressor)**

Compressors used in UHTHP must be able to demonstrate reliable operation over the anticipated spectrum of system operating conditions and requirements. This reliability is one of the most critical challenges to achieving the goal of using MDHP for UHT application. There are many factors to consider when selecting compressors, such as required heating capacity, volume flow rate, compression ratio and discharge temperature and pressure, working fluid type, driver type (e.g., electric motor, steam/gas turbine, combustion engine/turbine), environmental impact, noise, and safety. Among these, the most challenging part is to find compressors that can operate both reliably and efficiently in UHT heating conditions (T>250℃). The current state-of-the-art high-temperature compressors available in the commercial market are primarily constrained to providing heat supply temperatures (Tsink) below 200℃ 250℃ [12,28,164,165]. On the other hand, according to Aga et al. (2016) [15], there are CO<sup>2</sup> compressors used in oil and gas industry that can operate at temperatures up to 480℃ [\(Table 17\)](#page-79-0), which belong to the same design family widely used in the ammonia manufacture and process industry. In Vinnemeier et al. [155], it is mentioned that the turbo devices using CO<sup>2</sup> have the potential to be designed with higher efficiencies compared to air devices at the same boundary conditions. However, the key challenges of using CO<sup>2</sup> are that CO2-based HP systems typically require a high compression ratio and discharge pressure. According to Sarka et al. [37] and Mercangoz et al. [166], the CO<sup>2</sup> compressors have a maximum discharge pressure limit of 15 MPa. The maximum pressure limits of hydrocarbon and ammonia compressors currently available are even lower, on the order of 4 MPa. This implies that, in scenarios that require UHT heating (T>250℃), it might be necessary to lower the discharge pressure below the optimal level (depending on the working fluid type) with a risk of compromising performance goal (e.g., COP).

[Table 17](#page-79-0) provides a summary of compressor technologies found in the literature that are potentially available for UHTHP application. As shown in this table, the compressor technologies that are practically applicable to UHTHP application are very limited.

<span id="page-79-0"></span>Table 17. Compressors found in the literature/commercial market for UHTHP applications.

| Investigator(s) / supplier(s) | Working<br>fluid                 | Maximum heating Temp.  [°C] | Maximum pressure [bar] | Compressor type                                                                            | Capacity<br>[MW <sub>e</sub> ] |
|-------------------------------|----------------------------------|-----------------------------|------------------------|--------------------------------------------------------------------------------------------|--------------------------------|
| Oehler et al. [13]            | Air                              | 250                         | _                      | Axial compressor<br>(Reverse Brayton<br>cycle)                                             | 0.2                            |
| Spilling technologies [42]    | Water<br>steam                   | 250–280                     | 40                     | Electric-driven piston compressor                                                          | 1–15                           |
| Degueurce et al. [35]         | Water<br>steam                   | 250                         | 3.657                  | Oil-free twin screw (steam) compressor                                                     |                                |
| Enerin [4]<br>(HoegTemp HP)   | Helium,<br>nitrogen,<br>hydrogen | 250                         | —                      | Piston compressor                                                                          | 0.3–10                         |
| Aga et al. [15]               | $CO_2$                           | Up to 480 <sup>8</sup>      | 140                    | Double casing double<br>staged CO <sub>2</sub><br>compressor<br>(Reverse Brayton<br>cycle) | 30–50                          |
| Vinnemeier et al. [155]       | Air                              | 600 <sup>9</sup>            | _                      | _                                                                                          | _                              |

The main challenges of compressors for UHT application are two-fold: (1) limitations of the components to support high-temperature and high-pressure operation and (2) performance degradation with the increase of discharge temperature [12]. These two aspects are detailed in the following:

(1) Limitations of the compressor components associated with high-temperature and high-pressure application (i.e., lubricant oils, working fluids, and materials)

High-temperature and high-pressure operation of a compressor may pose extreme challenges to sealing, bearing lubricant, and materials in the compressor. As a result, compression ratio, defined as the ratio of the compressor's suction pressure to its discharge pressure, is a major design consideration for compressor. High compression ratio can adversely affect bearing lubrication (e.g., degradation or decomposition) and cause excessively high temperatures of motor, oil, sealing, and valve plate<sup>10</sup>, which can eventually reduce compressor efficiency, lifespan, and overall HP system performance [167]. The maximum compression ratio is usually limited by the maximum discharge temperature of a compressor, which is dictated by the maximum operating temperature of the components. It is therefore a common practice to employ interstage cooling when aiming for high compression ratios through multistage compression [47,168]. Cooling techniques typically used for this purpose encompass two-phase compression, vapor or liquid injection, and intercooling [169,170]. However, for the UHTHPs, which require the ability to deliver ultra-high-temperature heat (T>250°C), compressor cooling may not be as effective a method as it is for lower temperature HP applications.

64

<sup>&</sup>lt;sup>7</sup> This represents the highest pressure measured at the compressor discharge among the test results presented by Degueurce et al. (1984).

<sup>&</sup>lt;sup>8</sup> Regarding the temperature limit of CO<sub>2</sub> compressor, Vinnemeier et al. (2014) contend that designing CO<sub>2</sub> compressors operating at temperatures above 450°C will demand substantial engineering effort.

<sup>&</sup>lt;sup>9</sup> Vinnemeier et al. (2014) mentioned the temperature limits of air compressors implemented in modern gas turbines, but no further details are provided.

<sup>&</sup>lt;sup>10</sup> The valve plate is a component in the compressor that manages the fluid flow during the compression process.

The choice of working fluid can also impact the selection of compressors and associated challenges for the UHTHP system. For example, water is a very promising natural working fluid for HTHP application due to its high value of latent heat, natural abundance, and environmental compatibility. However, water vapor's low density and molecular weight can require a compressor with a significant swept volume and compression ratio, which will potentially necessitate the use of larger or higher speed compressors, such as oil-free turbo-compressors, to achieve the same mass flow rate compared to other working fluids [7,29]. In addition, to deal with the high temperature heat sources above T>250℃, waterbased VCHPs require high system pressures, which can lead to elevated costs for construction, operation, and maintenance of the overall VCHP system. CO2-based UHTHP system may also have similar challenges of requiring high compression work and high pressure. Ammonia, another natural fluid widely used in industrial HPs (typically Tsink<100℃), has the benefits of a high VHC compared to other refrigerants [171]. For UHTHP applications, however, it is crucial to tackle the pressure limitations of existing ammonia compressors, as well as concerns regarding toxicity and material compatibility. The challenges associated with working fluids for UHTHP are discussed in more detail in Section [4.1.2.](#page-83-0)

#### *(2) Compressor performance (or efficiency) degradation*

Compressor is the largest power consumer in MDHP systems. Thus, improving the compressor performance, especially at high temperatures, is critical to improving the overall MDHP system performance. According to Chua et al. [172], advanced compressor technology may offer the potential to reduce energy consumption in HP systems by up to 80%. Performance degradation often occurs when the compressor and its components are exposed to high temperature heat. Accordingly, a common way to enhance performance and reduce the energy consumption by the compressor is to employ compressor cooling techniques, such as (1) external motor cooling and (2) isothermal compression cooling [169]. These are to prevent the deterioration of compressor performance that can be caused by the overheating of the compressor parts, such as shell, lubricating oil, and motor. In Degueurce and Tersiguel (1982) [173], the significant impact of compressor cooling on performance has been demonstrated through experiments using oil-free steam compressors equipped with water injection or other cooling devices.

However, as previously discussed, compressor cooling cannot be a practical solution for the UHTHPs that necessitate the delivery of ultra-high-temperature heat (T>250℃). Rather, it is important to find a lubricant, working fluid, and other advanced compressor technology that can improve the performance at such high temperatures. Technologies that may provide solutions in this regard are described below.

#### *(3) Possible solutions to overcome the current challenges of compressors for UHTHP*

The main constraint preventing the current practical use of compressors in ultra-high-temperature applications is predominantly associated with the limited availability of high-temperature lubricants. There are several potentially promising solutions and recent studies to address this challenge.

#### - **Lubricants for UHT application**

One possible solution is to find lubricants that can withstand higher temperature than conventional lubricants. As of now (2023), according to the authors' review, most state-of-the-art commercial (liquidtype) lubricant products have a maximum service temperature range of up to approximately 400℃. Also, common challenges with conventional liquid-based lubricants are that their performance often degrades at temperatures exceeding 300°C and there is potential risk to human and environmental health when used in such high-temperature environments [174]. Addressing this challenge, including the development of new lubrication materials for high temperature application, is a shared priority across multiple engineering applications, encompassing aerospace, metal processing, and internal combustion engines.

<span id="page-81-0"></span>Table 18. High-temperature lubricants potentially available for UHTHP applications.

| Lubricant                                                                                                                           | Max Operating Temperature [°C] | Туре   | Reference |
|-------------------------------------------------------------------------------------------------------------------------------------|--------------------------------|--------|-----------|
| Krytox lubricants                                                                                                                   | 400                            | Liquid | [175]     |
| ZnMoO <sub>2</sub> S <sub>2</sub> -H <sub>2</sub> O, ZnMoS <sub>4</sub>                                                             | 40011                          | Solid  | [176]     |
| Carbon-based lubricants (e.g., graphite, graphene)                                                                                  | 400–450                        | Solid  | [174]     |
| Ce <sub>2</sub> (MoO <sub>2</sub> S <sub>2</sub> ) <sub>3</sub><br>(Cerium dithiomolybdate)                                         | 600                            | Solid  | [177]     |
| CaSO <sub>4</sub> (Calcium sulfate)                                                                                                 | 500                            | Solid  | [178]     |
| hBN (hexagonal boron nitride) <sup>12</sup>                                                                                         | 900                            | Solid  | [174]     |
| MoS <sub>2</sub> and WS <sub>2</sub> <sup>13</sup> (in air / in vacuum)                                                             | 500 / 1000                     | Solid  | [174,179] |
| Metal oxides<br>(e.g., PbO, B <sub>2</sub> O <sub>3</sub> , Ag <sub>3</sub> VO <sub>4</sub> ,<br>Ag <sub>2</sub> MoO <sub>4</sub> ) | >1000                          | Solid  | [179]     |
| Alkaline fluorides<br>(e.g., CaF <sub>2</sub> , BaF <sub>2</sub> , LiF)                                                             | 1000                           | Solid  | [179]     |

#### - Oil-free turbo-compressors

There are solid-based lubricants capable of withstanding temperatures well above 300°C, and the development of new lubrication materials aimed at enhancing the reliability and lifespans of manufactured products is widespread and active. Comprehensive reviews of high-temperature solid lubricants including the state-of-the-art for engineering applications are provided in Gong et al. [179] and Kumar et al. [174]. According to Kumar et al. [174], the use of "self-lubricating" materials, materials containing solid lubricants, have the potential to minimize or even omit the use of conventional liquid-based lubricants. Sarkar et al. [37] also briefly outlined several high-temperature lubricant options potentially available for UHTHP applications (T>250°C). Based on the present literature review, Table 18 summarizes several lubricant options that can potentially overcome the existing temperature limit of compressors to be applied in UHTHP systems.

Another possible and promising solution to overcome the existing temperature limit of compressors is the use of oil-free compressor, especially oil-free turbo-compressor. Oil-free turbo-compressors have the potential to achieve greater energy efficiency and reduce environmental impact, in addition to their high-temperature application potential [12,173]. Since oil-free turbo-compressors can operate without the need for oil lubrication, it allows the compressor volume to be reduced (by the amount of associated lubrication device) and essentially avoiding the constraints imposed by conventional lubrication systems. This type of compressors is already a commercially available technology, but its application has been predominantly limited to operating temperatures below 200°C [5].

While there are currently no commercially available oil-free turbo-compressors designed for UHTHP systems, it is worth noting that turbochargers, which share the operational principles with turbo-

66

<sup>&</sup>lt;sup>11</sup> Experiments were performed up to 500°C, and effective lubricity was demonstrated up to 400°C.

 $<sup>^{12}</sup>$  Kumar et al. (2022) describe a 5–15 vol% of hBN as the optimal inclusion in the composites to provide effective lubrication at T=600°C-900°C.

<sup>&</sup>lt;sup>13</sup> Molybdenum Disulfide (MoS<sub>2</sub>) and Tungsten Disulfide (WS<sub>2</sub>).

compressors and are widely used in internal combustion engines, are typically designed to withstand extreme temperatures of exhaust gas generated during the internal engine's combustion process. Specifically, the turbine housing, the hottest part of the turbocharger, is generally constructed from cast iron capable of enduring hot gas temperatures up to 950℃ [180,181]. This suggests that, although there are no commercial products of turbo-compressors available for UHT yet, there is a high likelihood that the technology to develop them already exists; although the design limits and efficiencies of the compressors may highly depend on the choice of working fluid type [155]. In a similar vein, Aga et al. (2016) [15] noted that given the common occurrence of high-temperature process conditions in gas turbine industry, the current temperature limitation of the HP cycle does not primarily result from technological constraints related to materials, seals, or other factors. Instead, the more fundamental reason is the lack of market demand for high-temperature compressors that operate without intercooling. That said, until recently, there was no incentive for suppliers to develop such high-temperature compressors given the absence of market demand.

Besides the technical feasibility discussed above, another practical aspect to consider is that oil-free turbo-compressors designed for UHTHP applications may entail higher equipment costs compared to traditional compressors. Typically, the costs of turbomachinery, including compressor and turbine, correlate with their capacity or power output. In general, costs tend to rise significantly below 1 MW while the efficiency increases with power [161]. Additionally, as illustrated in [Figure 36,](#page-82-0) there is a trend of increasing the expected lifetime of commercial compressors with their capacity. While the precise reason for this trend has not been fully determined, this is possibly due to larger capacity compressors being constructed with higher quality components and frequently used in scenarios where they operate below their capacity limits, thereby minimizing operational stresses. Therefore, determining the optimal size of the compressor is important for the overall economics of the UHTHP system.

![](_page_82_Figure_2.jpeg)

<span id="page-82-0"></span>Figure 36. Expected lifetime of commercial compressors relative to capacity (sourced from [43]).

#### <span id="page-83-0"></span>**4.1.2 Working Fluids**

#### <span id="page-83-1"></span>**4.1.2.1 Working Fluid Challenge for Vapor Compression Heat Pump Cycles**

Identifying and selecting suitable working fluids applicable to UHTHPs is another significant challenge. Among the VCHP cycles discussed in Section [2.1.1,](#page-22-0) this is particularly important for reversed ORC and reversed Kalina cycles, where a wide selection of working fluids can be considered.

For the heat sink temperatures up to 160℃, the possible working fluid options for the heat pump applications have been widely investigated in literature such as Arpagaus et al. (2018) [7] and Sun et al. [182]. At higher temperatures, between 220℃ and 350℃, Pasetti et al. (2014) [31] present experimental findings concerning the thermal stability of three organic fluids, Cyclopentane, Isopentane and n-Butane, in which the three fluids were observed thermally stable up to 275℃, 290℃, and 310℃, respectively. Other working fluid options for the high-temperature ORC relevant to UHTHP are summarized in [Table 1](#page-23-0) (Section [2.1.1\)](#page-22-0). To the best of the authors' knowledge, among the working fluids for the ORC, Titanium Tetrachloride (TiCl4) has been used at the highest temperature and has proven its stability up to 500℃ [24]. Given the low cost, zero GWP and ODP, TiCl<sup>4</sup> can be considered as a potential working fluid in ultra-high-temperature VCHPs. However, it exhibits strong reactivity upon contact with water, which may result in the release of both toxic and corrosive hydrogen chloride (HCl) gas, classifying TiCl<sup>4</sup> as hazardous by National Fire Protection Agency standards [16,24].

In general, the organic or synthetic fluids data available in existing literature, particularly in the temperature range relevant to UHTHP applications (T>250℃), remain very limited and often contradictory [31]. This makes it more difficult to search for the suitable fluids with high performance, high thermal stability, minimal GWP and ODP, as well as low flammability and toxicity. Also, in case of synthetic fluids, made of hydrocarbons, the flammability become more intractable at high temperatures and pressures [29]. Potential working fluid options for ultra-high-temperature applications of VCHP are summarized in [Table 1.](#page-23-0) However, further research and development is required in this area, especially regarding the practical challenges summarized in [Table 19.](#page-84-1)

In the case of fluid mixtures (reversed Kalina cycle), as discussed above in Section [2.1.1.2](#page-27-0) [\(Table 3\)](#page-28-0), most of the practical applications and associated studies have been limited to heat sink temperatures (Tsink) below 200℃. The only exception, although not in HP application, is the use of ammonia-water mixtures in Kalina power cycles at temperatures higher than 500℃ [49–51]. It should be noted, however, that the high-temperature ammonia-based HPs typically require special attention regarding the material compatibility and high toxicity. Also, the zeotropic mixtures such as ammonia-water mixture (i.e., mixtures undergoing temperature glide during phase transition) may pose a risk for fractionation when there is a large temperature glide (difference) requirement on the sink side [28,183]. Another potential concern regarding the use of an ammonia-based fluid mixture at UHT is nitridation. Nitridation is a process that leads to the formation of nitrides within a material due to exposure to reducing, high temperature environments with high nitrogen activity. If nitridation occurs, it has the potential to weaken the material's strength and may lead to equipment corrosion [49]. Nevertheless, the use of ammonia-water mixture at UHT (T>500℃) has been successfully demonstrated in a Kalina power cycle by Canoga Park [51], and there is a patent related to the high-temperature and high-pressure application of ammonia-water mixtures (up to T=1093℃ and P=689.5 bar) while preventing nitridation through the use of appropriate additives [50].

In addition to the limitations of the working fluid itself discussed above, selection of the optimal fluid depending on the end-use application must also be a key consideration in a UHTHP design. Specifically, [Figure 37](#page-84-0) represents which type of working fluid can be a better option for a UHTHP system depending on the level of temperature glide required on the heat sink side.

![](_page_84_Figure_0.jpeg)

<span id="page-84-0"></span>Figure 37. The compatibility between working fluid selection and application (adapted from [43]).

The potential challenges associated with working fluids for UHTHP application, especially for VCHP cycles, and the existing/potential solutions to address the challenges are summarized in [Table 19.](#page-84-1)

<span id="page-84-1"></span>Table 19. Potential challenges of working fluids for VCHP cycle and possible improvement

(data has been collected, adapted, and expanded from References [28,29,37]).

| HP Cycle | Working Fluid | Potential<br>Challenges                                                                                | Existing and/or Possible<br>Improvements                                                                                                                                                                                                                                   |  |  |
|----------|---------------|--------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|
|          |               | High compression ratio<br>required,<br>limited<br>temperature lift                                     | -<br>Multistage<br>compression<br>-<br>Use alternative refrigerant<br>or<br>refrigerant blend                                                                                                                                                                              |  |  |
|          | Water         | High compressor discharge<br>(potentially<br>temperature14<br>availability<br>addressed)               | High-temperature lubricants,<br>oil-free turbo-compressor,<br>higher<br>equipment cost<br>and lack of commercial product<br>should also be                                                                                                                                 |  |  |
|          |               | High volume flow rate                                                                                  | Turbo-compressors,<br>parallel compressors<br>[29]<br>(Compressor technology<br>limitation)<br>-<br>Sarkar et al.[37]: 4 MPa is the<br>discharge pressure limit of ammonia<br>compressors<br>-<br>Bamigbetan et al.[29]: 6<br>MPa<br>coupled with Tsink<br>of 97.5℃ is the |  |  |
| VCHP     | Ammonia       | High discharge pressure<br>associated with the existing<br>ammonia compressor technology<br>limitation | discharge pressure limit of ammonia<br>compressor<br>-<br>Arpagaus et al.<br>[7]: there are<br>commercially available ammonia<br>compressors (by EMERSON<br>Electric Co.) with<br>special cast steel<br>construction for<br>use up to P=76 bar                             |  |  |

<sup>14</sup> Multi-stage compression combined with intercooling is a typical solution to control discharge temperature of a compressor. However, as discussed in Section 4.1.1, this cannot be a practical solution for UHTHP.

|                                                           |                                                                                                                                                                             | and T=110℃                                                                                                                                                                                                                              |
|-----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                           | High discharge temperature,<br>compressor cooling13                                                                                                                         | High-temperature lubricants                                                                                                                                                                                                             |
|                                                           | Material compatibility                                                                                                                                                      | Use the proven cases of enhanced<br>materials in ultra-high-temperature<br>Kalina power cycle systems (=> A<br>set of information of tested/proven<br>materials are available in [51])                                                  |
|                                                           | High toxicity                                                                                                                                                               | Leak detection, ventilation                                                                                                                                                                                                             |
| Organic and<br>synthetic fluids<br>(e.g., hydrocarbon)    | High-temperature flammability,<br>thermal stability, environmental<br>compatibility, safety, efficiency,<br>limited availability<br>(especially for<br>applications T>400℃) | -<br>Leak detection, ventilation, and<br>safety relief valve<br>with flame<br>arrestor<br>[29]<br>-<br>New synthetic fluid development,<br>-<br>Zeotropic<br>mixture<br>(e.g., ammonia<br>water)<br>-<br>High<br>temperature lubricants |
| Zeotropic mixtures<br>(e.g., ammonia<br>water<br>mixture) | Lack of availability/knowledge,<br>fractionation<br>[28], nitridation<br>[49], high<br>compressor discharge<br>temperature<br>and pressure, high<br>toxicity<br>of ammonia  | A few of<br>demonstration and patent<br>cases using<br>ammonia-water mixture<br>at UHT<br>(T>500℃)<br>in Kalina power<br>cycle<br>[49–51]                                                                                               |

#### <span id="page-85-0"></span>**4.1.2.2 Working Fluid Challenge for Gas Compression Heat Pump Cycles**

Working fluids commonly used in GCHP cycle include air, CO2, helium, argon, and hydrogen, as discussed in Section [2.1.2.](#page-29-0) These fluids have in common high-temperature stability suitable for use in UHTHP systems, each with its own benefits and weaknesses. From a UHTHP application perspective, "thermal property," "temperature lift (ΔTlift) efficiency," and "compression efficiency" can be good criteria for comparing the advantages and potential challenges of each fluid.

Air possesses reasonably good thermal properties, is readily available, and is operationally safe at high temperatures. However, the temperature lift efficiency is expected to be lower than those of the monoatomic gases, such as helium and argon. This means that, for a given pressure ratio (P2/P1), it can achieve rather limited temperature lift. This is closely related to the fact that air has a lower isentropic exponent, or specific heat ratio (Cp/Cv), than monoatomic gases (see the discussion of isentropic compression with an equation in Section [3.1\)](#page-65-1). That said, a higher isentropic exponent is beneficial to the system efficiency of UHTHP. [Figure 38](#page-86-0) compares the isentropic exponents of six different fluids over a wide range of temperature, showing higher values for monoatomic gases (i.e., helium and argon).

![](_page_86_Figure_0.jpeg)

<span id="page-86-0"></span>Figure 38. Comparison of isentropic exponent (Cp/Cv) for GCHP working fluids.

Helium has superior thermal properties, such as high thermal conductivity and heat capacity, and high-temperature operational stability. Its high heat capacity (Cp) can reduce the mass flow rate required to achieve the same heating power compared to other monatomic gases, such as argon. This can also lead to benefits in terms of reducing pressure drop throughout the HP cycle [184]. Another strength of helium is the high-temperature lift efficiency as a monoatomic gas. However, helium is highly compressible, which reduces compression efficiency, so more compression work is required to achieve the same pressure ratio. In addition, the low density of helium may cause large system volume and poor heat delivery efficiency.

Argon, another monoatomic gas, has similar benefits to helium (i.e., high ΔTlift efficiency). However, its heat capacity is much lower than that of helium (about 10 times lower), thus achieving the same heating power requires a higher mass flow rate than helium. This may pose a critical challenge to argon, as the higher mass flow rate typically leads to a more complex and costly HP system [156].

CO<sup>2</sup> presents the highest VHC (or energy density) among the six fluids compared, as shown in [Figure](#page-32-0)  [8](#page-32-0) (Sectio[n 2.1.2.1\)](#page-29-1). As shown in [Figure 38,](#page-86-0) however, it has the lowest isentropic exponent (Cp/Cv) and

therefore the lowest temperature lift efficiency. Another critical challenge is associated with the limited knowledge of sCO<sup>2</sup> properties. Knowledge about the sCO<sup>2</sup> properties near critical point is still limited, especially about the influence of subregions within its supercritical state (as depicted in Reference [185]—Figure 1). This knowledge gap includes significant uncertainties in estimating the properties of sCO2, such as compressibility, density, and heat capacity. For example, sharp variations in the properties of sCO<sup>2</sup> (e.g., heat capacity, viscosity) may occur during compression near the critical point called pseudocritical points, which may cause system stability and control issues [186]. Given that the thermodynamic behavior of sCO<sup>2</sup> may have significant impact on turbomachinery operation, performance, and design, closing this knowledge gap is crucial. However, studies on the effect of sCO<sup>2</sup> properties on turbomachinery, such as compressor performance and instability, are still limited. Lastly, the pressure limitations of existing CO<sup>2</sup> compressors, discussed in Section [4.1.1,](#page-78-2) may also act as a practical limitation for employing CO<sup>2</sup> in UHTHP system.

In the case of hydrogen, the biggest benefit is its high specific heat (Cp) (even higher than helium). However, its temperature lift efficiency is limited like air or CO2, and the high compressibility will decrease the compression efficiency as discussed above with helium. Another challenge of employing hydrogen for UHTHP application is its high flammability.

[Table 20](#page-87-0) summarizes the comparison of benefits and potential challenges of each fluid applicable to GCHP cycle, discussed above, especially from a viewpoint of UHTHP application.

<span id="page-87-0"></span>Table 20. Potential benefits and challenges of working fluids for GCHP cycle.

|        | Potential Benefit                                                                                                                              | Potential Challenge                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Air    | Reasonably good thermal properties, readily<br>available, operational safety                                                                   | Limited ΔTlift<br>efficiency compared to<br>monoatomic gases (due to low isentropic<br>exponent)                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| CO2    | High energy density (high volumetric heat<br>capacity)<br>(see<br>comparison in<br>Figure 8)                                                   | High discharge pressure (and high<br>compression ratio required)15 associated with<br>the existing CO2<br>compressor technology<br>limitation; limited ΔTlift efficiency;<br>limited<br>knowledge of sCO2<br>properties<br>and associated<br>behavior<br>near crucial point<br>(pseudocritical<br>behavior<br>[185])<br>(Compressor technology limitation)<br>-<br>Abdemini et al. [37], Bamignetan et al. [29]:<br>about 15 MPa is the maximum discharge<br>pressure limit of currently available CO2<br>compressors<br>-<br>Aga et al. [15]: 14 MPa is presented as the |
|        |                                                                                                                                                | typical pressure constraints of off-the-shelf<br>CO2<br>compressors commonly used in the oil,<br>gas, and process industry                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Helium | High ΔTlift<br>efficiency (high isentropic<br>exponent); superior thermal properties (e.g.,<br>high thermal conductivity and heat<br>capacity) | High compressibility<br>(low compression<br>efficiency), low energy density (Figure 8);<br>leakage                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

<sup>15</sup> In Sarkar et al. (2007) investigating a CO2-based VCHP (Tsink up to 200℃), CO<sup>2</sup> cycle was evaluated unsuitable for high temperature operation due to the extremely high discharge pressures (as high as 20 MPa).

| Argon    | High ΔTlift<br>efficiency (high isentropic<br>exponent)            | High pressure drop (compared to helium), low<br>energy density (Figure 8)                                                                                                                                  |
|----------|--------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Hydrogen | High specific heat (low mass flow rate<br>required); low viscosity | Limited ΔTlift<br>efficiency compared to<br>monoatomic gases (due to low isentropic<br>exponent); high compressibility<br>(low<br>compression efficiency); low energy density;<br>leakage;<br>flammability |

#### <span id="page-88-0"></span>**4.1.3 Heat Exchanger (Thermal Interface Design)**

Heat exchanger is another critical component that can significantly impact the performance, size, and cost of a UHTHP system. There are several critical aspects of heat exchangers that can potentially contribute to enhancing the cycle efficiency and cost reduction of the overall UHTHP system. These encompass aspects such as heat transfer efficiency, pressure drop, material and manufacturing costs, size and space requirements, weight, and operation and maintenance costs of the heat exchanger. The impact of varying these aspects may become even more critical in TDHP systems.

Shell-and-tube heat exchangers or their variants, such as finned tube heat exchangers, have been widely used as condensers or evaporators in MDHP systems [187,188]. Given that heat exchangers for high-temperature applications are among the primary HP cost factors for the capital investment and derived heat cost, a compact heat exchanger (CHE) featuring both high surface area density (m<sup>2</sup> /m<sup>3</sup> ) and high heat transfer efficiency has a potential to substantially improve the overall economics of UHTHP systems by enhancing the operating efficiency [47,165,188,189]. In addition, CHEs, such as printed circuit heat exchangers (PCHEs), may be necessitated in many cases to withstand the fairly high pressures and temperatures typically encountered during the operation of UHTHP systems.

However, to effectively integrate advanced heat exchangers like CHEs into UHTHP systems, the following practical challenges must be addressed carefully:

- For heat exchangers intended for use in nuclear service, the design and construction must comply with the requirements outlined in ASME BPVC Section III. However, in the case of CHEs, ASME codes often do not have established rules regarding their construction for nuclear service (Section III, Division 5), as opposed to conventional shell-and-tube heat exchangers [58,190]. If the UHTHP system intends to recover and/or boost thermal energy generated by nuclear reactors, this issue must be addressed.
- CHEs can be susceptible to the performance degradation and/or failure caused by fouling and maldistribution of working fluid flow, which may significantly affect the performance of both heat exchanger and overall HP system [187,188]. For example, the PCHEs may not be a suitable choice for UHTHP system if it involves corrosive fluids like molten salts. This is because they may lead to potential clogging issues with the salt inside the narrow channels. Additionally, there are challenges associated with inspection and monitoring of these compact heat exchangers, particularly when applied on a large scale, such as in megawatt industrial applications [58]. Therefore, to ensure the reliable performance of a UHTHP system, these potential issues must be considered from the heat exchanger design (or selection) stage to operation and maintenance.
- Selecting a working fluid that is compatible with the heat exchanger material also holds significance (in addition to the thermal stability of working fluid for ultra-high temperature application).
- CHEs may have the potential to encounter the risk of excessive thermal stresses. Thus, it is essential to predict and address this concern.

#### <span id="page-89-0"></span>**4.1.4 Materials**

Given that steam or gas compression within an MDHP cycle inevitably results in high temperatures and pressures, UHTHP systems should also be able to handle potential material issues, such as creep limitations of alloy steels, typically encountered by high-pressure steam power systems. Modern supercritical steam power plants can operate at pressures approaching 30 MPa (300 bar) [191]. Nevertheless, the use of high pressure imposes significant limitations on the allowable operating temperatures. For example, conventional carbon steels cannot be used in high-pressure thermal systems at temperatures above 427℃ [30]. The creep limitations of various alloy steels, including nickel-based alloys such as Inconel, are laid out in ASME Boiling and Pressure Vessel Code (BPVC) Section II, Division D (maximum allowable steel stress) [192]. According to the material limitations outlined in ASME BPVC Section II, temperatures exceeding 600℃ are likely to cause problems to most alloys, and these standards are considered in modern supercritical steam plants [30]. Hence, for commercial deployment of UHTHP, these material constraints can serve as limitations on the achievable heat supply temperature.

#### <span id="page-89-1"></span>**4.1.5 Advanced Heat Pump Systems and Associated Research Efforts**

The previous subsections focused primarily on component-related challenges that should be addressed for the UHT application of MDHP. This subsection explores advanced HP systems and related research endeavors that hold the potential to address current challenges via enhancing the thermodynamic performance, overall energy utilization, and economic viability of UHTHP systems.

#### <span id="page-89-2"></span>**4.1.5.1 Mechanically Driven Heat Pumps Combined With Thermal Energy Storage**

There are studies incorporating Thermal Energy Storage (TES) into MDHP cycles, with the objective of enhancing the overall performance (or round-trip efficiency) of the HP cycle. This approach leverages the stored thermal energy in TES as a supplementary heat source for the HP cycle, preheating the working fluid before it enters the compressor. As a result, this recuperated HP cycle reduces the energy required by the compressor, leading to an elevated COP for the entire cycle. Recent studies on Pumped Thermal Energy Storage (PTES) are a typical example of the integrated application of high-temperature HPs (especially, UHTHP) with TES.

PTES is a technology that integrates HP, TES, and heat engine (power cycle), the concept of which is briefly illustrated in [Figure 39.](#page-90-0) It has primarily been investigated as a large-scale Electric Energy Storage (EES) solution due to its potential benefits, including scalability, high energy density, and reasonably moderate round-trip efficiency (up to approximately 80% depending on the operating conditions [193,194]). The core principle of PTES involves the conversion of electric energy into heat using a HP to charge a TES. Later, this stored heat is converted back into electricity using a heat engine. Specifically, the PTES establishes a temperature gradient between two thermal reservoirs (i.e., hot and cold storage) using a HP, and subsequently uses this temperature gradient with a heat engine. In this process, the cold storage serves as a heat sink for the power cycle and a supplementary heat source for the HP cycle.

Recent studies on PTES, especially combining UHTHP with TES, can be broadly categorized into two groups: (1) Brayton PTES (utilizing reversed Brayton cycle) and (2) Rankine PTES (utilizing reversed Rankine cycle). The typical temperature and pressure ranges for Brayton PTES are -170℃– 950℃ and 1–20 bar, while for Rankine PTES, they extend from -30℃ to 400℃ and between 1 and 200 bar [184]. The commonly used working fluids for Brayton PTES include argon, helium, supercritical CO2, hydrogen, air, and nitrogen. In the case of Rankine PTES, water or organic fluids are typically used, the selection of which is driven by the scale and operating temperature throughout the HP cycle. Also, there have been studies introducing a transcritical CO<sup>2</sup> cycle [166] and cascade cycles [195] to reduce

exergy destruction during heat transfer in the evaporator and condenser by achieving better temperature matching.

Aga et al. [15] proposed a PTES system that integrates a sCO<sup>2</sup> HP cycle (UHTHP cycle) with a molten-salt TES. The discharge (power generation) occurs through a standard SRC. A CO<sup>2</sup> compressor available from oil and gas industry was adopted, which had an upper temperature limit of approximately 480°C. Given this limitation of CO<sup>2</sup> compressors, an electric heater was incorporated downstream of the HP to elevate the molten-salt temperature to the higher desired TES temperature (>550℃). McTigue et al. [59] investigated the PTES systems incorporating an ideal gas or sCO<sup>2</sup> Brayton cycle with a molten-salt TES. The performance and economics of PTES systems integrating the GCHP cycles with existing CSP plant was also discussed (called solar-PTES). One notable finding was that the benefits of operating the PTES at temperatures above 600℃ were limited by the increasing material cost of heat exchangers. When comparing the solar-PTES system with a CSP plant coupled with an electrical heater to charge the molten-salt TES instead of a HP, the latter exhibited significantly lower efficiency with round-trip efficiencies of approximately 40%. Vinnemeier et al. [155] arrived at a similar conclusion in their PTES study, arguing that electric heaters are not competitive to HPs in terms of the achievable efficiencies. In the best case scenario, the efficiency of electric heaters was 15%–20% lower.

There are also some ongoing commercial development projects in the context of PTES with various combination of HP technologies, TES, and power cycles. A good review of commercial and laboratoryscale prototypes and pilot plants is presented in Reference [196].

In [Table 21,](#page-91-1) multiple studies on PTES integrating UHTHP with TES are summarized, along with details on the system configurations, key components, and achievable round-trip efficiencies.

![](_page_90_Figure_4.jpeg)

<span id="page-90-0"></span>Figure 39. Integration of heat pump with TES (PTES for combined heat and power production).

<span id="page-91-1"></span>Table 21. PTES studies integrating UHPHP with TES.

| Author(s)                        | HP Cycle                                      | Working<br>Fluid                                          | Hot Storage<br>TES Medium                                      | Cold Storage<br>TES Medium | Temperature<br>Range [°C]                                | Round-Trip<br>Efficiency |
|----------------------------------|-----------------------------------------------|-----------------------------------------------------------|----------------------------------------------------------------|----------------------------|----------------------------------------------------------|--------------------------|
| Blanquiceth et al. (2023) [197]  | Brayton                                       | CO <sub>2</sub> , air, argon,                             | Solar salt                                                     | Environment (ambient air)  | 45–700                                                   | 50%-65%                  |
| Tafur-Escanta et al. (2022) [60] | Brayton (supercritical)                       | CO <sub>2</sub>                                           | Solar salt                                                     | Pressurized<br>water       | 41–600                                                   | 80%                      |
| McTigue et al. (2022) [59]       | Braton<br>(supercritical<br>/ transcritical)  | CO <sub>2</sub> , air                                     | Solar salt,<br>mineral oil                                     | Methanol,<br>water         | -71–565 (air)<br>30–503 (CO <sub>2</sub> ) <sup>16</sup> | 63–77%                   |
| Mahdi et al. (2022)              | Brayton                                       | Air, argon,<br>nitrogen,<br>CO <sub>2</sub> <sup>17</sup> | Solar salt                                                     | Environment or solar heat  | 25–600,<br>385–600 <sup>18</sup>                         | 43–79%                   |
| Aga et al. (2016) [15]           | Brayton (supercritical)                       | $CO_2$                                                    | Solar salt                                                     | Water                      | 15–565                                                   | Up to 60%                |
| Vinnemeier et al. (2016) [155]   | Brayton<br>(supercritical<br>/ transcritical) | CO <sub>2</sub> , air, argon                              | Solar salt                                                     | Environment (ambient air)  | 50–700                                                   | 50–60%                   |
| Steinmann et al. (2014)          | Rankine                                       | Water                                                     | NaNO <sub>3</sub> ,<br>NaNO <sub>3</sub> +KN<br>O <sub>3</sub> | Environment or ammonia     | 25–400                                                   | 54–78%                   |
| Desrues et al. (2010) [158]      | Brayton                                       | Argon                                                     | _                                                              | _                          | -70–1000                                                 | ~67%                     |

#### <span id="page-91-0"></span>4.1.5.2 Combination of Ultra-High-Temperature Heat Pump and Electric Heaters

Given the current technical constraints of compressors regarding the high temperature, a combination of HPs and electric heaters may offer a viable approach to achieving energy efficiency without the need for developing new compressor technology. Vinnemeier et al. [155] assessed the performance of a PTES system with a UHTHP and electric heaters connected in series. When introducing an electric heater to heat the upper 10%–20% of the temperature range; although, the round-trip efficiency was reduced by a few percent (2%–5%) compared to the HP-based PTES, the technical challenges associated with high-temperature compression were substantially mitigated. Benato et al. [198] and Aga et al. [15] also proposed the PTES systems with the addition of an electric heater providing extra heat after a compressor to achieve the desired target temperature. In a similar context, Pimm et al. (2023) [55] investigated the potential of reducing energy demand of hydrogen-based industrial heating systems, which was achieved by employing a reversed Brayton cycle HP as a preheater to provide preheat temperatures of up to 500°C.

However, with respect to the employment of electric heating system, while it appears to be simpler and more cost-effective option compared to HPs, implementing an actual system on a large scale (e.g.,

<sup>16</sup> Note that recuperator was removed in the CO<sub>2</sub> Brayton cycle due to the large variations in density and heat capacity of CO<sub>2</sub> near its critical point. Also, large temperature variation through the hot storage required the use of two different hot storage media (i.e., molten salt and mineral oil) to avoid the salt freezing. This doubled the number of hot heat exchangers and storage vessels, whereas the round-trip efficiency was 12% greater than the air cycle.

<sup>&</sup>lt;sup>17</sup> Based on the comparative analysis, Mahdi et al. (2022) determined nitrogen as the optimal working fluid.

<sup>&</sup>lt;sup>18</sup> The temperature range of PTES cycle depends on whether solar heat or environmental air is used as a low-temperature heat source for a HP cycle.

megawatt scale) and for high-temperature lifts will require better understanding of the operating characteristics of electric heaters in such environment.

#### <span id="page-92-0"></span>**4.1.5.3 Cascade Heat Pump Systems**

Cascade HP cycle, which involves two or more single-stage HP cycles to efficiently achieve high temperatures, can also serve as a means to enhance the performance of UHTHP. The cascade HP cycles employ a heat exchanger to couple the single-stage HP cycles, creating a cycle with a low-temperature side (bottom cycle) and a high-temperature side (top cycle), as illustrated i[n Figure 40.](#page-92-2) This heat exchanger serves as the evaporator for the top cycle and the condenser for the bottom cycle. The motivation behind employing a cascade HP cycle is usually to overcome challenges that single-stage HP systems may encounter, such as high compression ratio, high discharge pressure/temperature, low COP, low volumetric efficiency, and limited temperature lift [27]. Although the high-temperature cascade HP systems have been widely studied due to their superior performance [3,27,199,200], its application for UHTHP remains relatively limited.

![](_page_92_Picture_3.jpeg)

Figure 40. A conceptual drawing of cascade HP cycle.

#### <span id="page-92-2"></span><span id="page-92-1"></span>**4.1.5.4 High-Temperature Transcritical Heat Pump Systems**

The high-temperature transcritical HP cycle is another technology with considerable efficiency potential for UHTHP, due to the temperature glide. This is especially true for processes with significant temperature changes on the sink side, such as drying (e.g., superheated steam drying), thermal oil heating, air heating, or pressurized hot water heating. In a transcritical HP cycle, heat rejection occurs at pressures higher than the critical pressure. As a result, it can achieve superior temperature matching during heat rejection, compared to traditional subcritical HP cycles, especially in scenarios with significant changes in heat sink temperature. This temperature matching is crucial in reducing exergy destruction and improving the overall HP cycle performance. The fundamental differences in temperature profiles between the two HP cycles (i.e., subcritical vs transcritical) during heat rejection are illustrated in [Figure 41.](#page-93-2)

CO<sup>2</sup> is commonly chosen as the working fluid for high-temperature transcritical HP cycles [37,38,59,155], but there are also studies using refrigerants [201,202].

![](_page_93_Figure_0.jpeg)

<span id="page-93-2"></span>Figure 41. Comparison of temperature profile during heat rejection depending on HP cycles, subcritical operation (left) vs. transcritical or supercritical operation (right) (from [38]).

#### <span id="page-93-0"></span>**4.1.5.5 Heat Pump Systems With Zeotropic Mixture**

The use of zeotropic mixtures as a working fluid has the potential to improve the exergy efficiency of the UHTHP systems through better temperature matching on the sink side. For example, as discussed in [12], VCHP cycles utilizing water as a working fluid exhibit high efficiency when applied to cases where both the heat source and sink maintain relatively constant temperatures. However, in applications where single-phase fluids are heated with temperature glide, inefficiencies may arise during heat rejection. Therefore, in such applications, VCHP cycles using zeotropic mixture or GCHP cycles might show improved efficiency. Given that the ultra-high-temperature application of an ammonia-water mixture has been proven in a Kalina power cycle, as discussed in Section [2.1.1.2,](#page-27-0) employing the zeotropic mixture may be a viable approach that can be considered to improve the performance of UHTHP systems depending on the application.

A potential risk of this approach is, however, that the zeotropic mixture may undergo fractionation if there is a large temperature glide [38].

#### <span id="page-93-1"></span>**4.1.5.6 Others**

In addition to the above discussion, there are also studies employing a turbine that is mechanically connected to a compressor, instead of expansion valve, to reduce the compressor work of UHTHP system and improve the overall cycle performance [55]. Also, multistage compression, regeneration, or heatdriven ejectors may be considered to enhance the performance characteristics of UHTHP systems [172]. Lastly, another important factor that must be mentioned for improving the performance of UHTHP is the availability of high-quality waste heat or surplus heat from low-carbon energy sources.

## **4.2 Thermally Driven Heat Pumps (Chemical Heat Pump)**

#### <span id="page-94-1"></span><span id="page-94-0"></span>**4.2.1 Technical Challenges**

ChHP systems need to overcome several technical challenges for advancement of their TRL. The drawbacks of the hydride and oxide systems have been listed in [Table 14](#page-64-1) (Section [2.2.4\)](#page-63-1). In light of their primary focus on energy storage and not HP applications, this discussion will focus primarily on hydroxide and carbonate systems. The major technical challenges are:

- Stability of the solid phase: Maintaining structural integrity of the solid phase as it cycles through forward and reverse reactions is the most significant challenge and is possibly the source of several other problems. The mechanical, thermal, and chemical stability of the solid phase is impacted as the molecular volumes of the reactant and product are different.
- Agglomeration and sintering with increased number of cycles have further effect on loss of reactive surface area, which in turn results in performance degradation. Attrition and breakage of pellets can also result in increased fines in the reactor, impacting the flow of gas/vapor through the reactor bed, contributing further to the lower effectiveness.
- The second major challenge is related to heat transfer to and from the reactor. In general, the solid phase in these systems has a low thermal conductivity, making it difficult to maintain uniform temperature conditions to prevent hot and cold spots, that exacerbate the problem.
- A better understanding of the thermodynamics and kinetics is needed for developing the reactor design and designing the auxiliary pieces of equipment. This will lead to a more robust reliable model that can further feed into realistic technoeconomic analysis of ChHP systems.

## <span id="page-94-2"></span>**4.2.2 Potential Methods to Alleviate Performance Degradation Challenges**

The key to advancing the ChHP technology is in the mitigation of performance degradation associated with the degradation of the solid reactant. An approach based on modification of the solid phase by introducing inert components that enhance the mechanical and physical properties of the reactant is described below, focusing on the calcium oxide system. CaO obtained from natural limestone has low mechanical performance, which results in structural deformation and deactivation of CaO-based material over the repeated hydration and dehydration cycles.

#### <span id="page-94-3"></span>**4.2.2.1 Al2O<sup>3</sup>**

Incorporating alumina increases the macroscopic integrity compared to pure CaO, though at the cost of the hydration activity of the synthesized material as reported by Sakellarious et al. [203]. Ca/Al molar ratios ranged from 52/48 to 89/11 in the precursors used to synthesize materials via liquid phase self propagating high-temperature synthesis (LPSHS) in their investigations. The hydrated phase was discovered to be Ca3Al2(OH)<sup>12</sup> by Brunauer-Emmett-Teller (BET), scanning electron microscopy (SEM), and x-ray diffraction **(**XRD) examination, indicating that Ca3Al2O<sup>6</sup> was the primary component in the CaO-Al2O<sup>3</sup> materials, though varying amounts of Ca12Al14O33, and CaAl2O4, and Ca5Al6O14were also formed depending on the synthesis conditions. Ca3Al2O<sup>6</sup> encapsulated CaO, resulting in a small surface area of CaO in contact with water. The synthetic material's hydration activity was lower than that of pure CaO primarily because of this, though the degradation began at a lower temperature as the Al concentration of the composite materials increased. A higher mass ratio of 81:19 (in weight percent) of CaO/Al2O<sup>3</sup> in synthetic material could improve heat storage ability.

The breakdown curves of hydrated ex-CaA materials exhibited the same morphology as those of hydrated CaA materials.

A study by Liu et al. [204] where calcium and magnesium salts of d-gluconic acid, sintering-resistant sorbents were made using a straightforward wet mixing technique. It was discovered that calcium oxide was evenly distributed throughout the sorbents, and metal oxide nanoparticles on the surface acted as physical barriers, retaining the sorbents' ability to trap CO<sup>2</sup> across several cycles of use. Other organometallic salts of calcium and magnesium/aluminum were also synthesized using this approach, and they too exhibited exceptionally high reversibility. The inert support materials' synthesis mechanism was suggested by Zhou et al. [205]. Wet mixing was used to create a variety of CaO-based CO<sup>2</sup> sorbents from various calcium and aluminum precursors. Most synthetic CaO-based sorbents demonstrated significantly greater CO<sup>2</sup> capture capability and stability over numerous carbonation/calcination cycles than pure CaO, which was attributed to the sorbents' relatively high specific surface areas and the inert support material that can successfully cease or defer CaO particles from sintering. Koirala et al. [206] studied the high temperature multicyclic CO<sup>2</sup> capture, M/Ca (M = La, Y, Hf, W, and Al) sorbents with a 1:10 molar ratio have been synthesized using the single nozzle flame spray pyrolysis (FSP) method. Al-doped CaO sorbent stood out for its exceptional adsorption capability and stability among other sorbents. Ca12Al14O<sup>33</sup> synthesis, with its uniform distribution, created a robust framework to prevent the CaO grain growth during multiple cycles, which was the reason for the material's increased resilience and durability.

#### <span id="page-95-0"></span>**4.2.2.2 LiOH**

CaO-based material modified with LiOH was analyzed using crystal structure models of quantum chemistry by Yan et al. [207]. Dehydration kinetics of Ca(OH)<sup>2</sup> were shown to be altered when LiOH was added, according to the model's simulations. By introducing LiOH, the dehydration reaction of Li-doped Ca(OH)<sup>2</sup> could take place at a lower temperature than the original Ca(OH)2. As a result, the dehydration reaction rate and heat storage efficiency of Ca(OH)<sup>2</sup> were both improved by the addition of lithium. It suggests that the addition of LiOH primarily alters the kinetics of Ca(OH)<sup>2</sup> dehydration reaction and enhances its dehydration efficiency. Dehydration reaction enthalpy and the specific heat capacity of Ca(OH)<sup>2</sup> were unaffected by this alteration in the molecular structure.

Ca(OH)<sup>2</sup> dehydration efficiency can be substantially enhanced by doping LiOH, however, the high expense of LiOH should not be overlooked. Lithium resources are priced between \$4 and \$7 per kilogram. Lithium resource output is stable at roughly 32,000 ton/year, but lithium resource demand is increasing by an average of 8% per year around the world. Adding lithium to CaO-based material does not require a large amount of lithium, thus, it will not contribute to the overall cost.

#### <span id="page-95-1"></span>**4.2.2.3 Na2Si3O<sup>7</sup>**

Na2Si3O7-modified CaO was examined by Criado et al. [208] for its mechanical stability and crushing strength, as well as its impact resistance. These materials were synthesized by mechanically combining the calcium precursors (CaCO3, Ca(OH)<sup>2</sup> or CaO) with the Na2Si3O<sup>7</sup> solution at ambient temperature and drying the mixture before calcining the materials for 10 minutes at 850°C. Na2Si3O<sup>4</sup> and Ca2SiO<sup>4</sup> were produced in the synthesis process when CaO interacted with the Na2Si3O7, as described by the following equation:

$$5CaO + Na_2Si_3O_7 \xrightarrow{\Delta} Na_2CaSiO_4 + 2Ca_2SiO_4$$

In addition to the use of additives, Criado et al. [208] suggest that decreasing the reaction time was a good way to improve mechanical stability. Decreasing the reaction will lower the conversion; however, it also lowers the volume changes and consequent mechanical stresses on the reactant increasing the useful life of the solid phase.

#### <span id="page-96-0"></span>**4.2.2.4 Nano-SiO<sup>2</sup>**

Roβkopf et al. [209,210] observed that found that the inclusion of nano-SiO<sup>2</sup> in the formulation, the bulk characteristics of calcium oxide were stabilized, leading to high cyclic stability for calcium oxide. They also discovered that the mixing intensity of CaO, SiO2, and water had a significant impact on CaO's hydration conversion. Because the surface of the CaO particles gathered the nanoparticles formed from the separation of nanostructured agglomerates, the high mixing intensity improved the hydration conversion of CaO. Instead of interacting with CaO, nano-SiO<sup>2</sup> only covered the surface of CaO particles as inert supports.

#### <span id="page-96-1"></span>**4.2.2.5 Salts (Chlorides, Sulfates, Nitrates and Acetates) of Alkali Metals**

Shkatulov and Aristov [211] investigated the doping effect of different alkaline metal (Li, Na, and K) chlorides, nitrates, sulphates and acetates salts. All these salts were found to have the potential to improve dehydration dynamics and regulate dehydration temperature. KNO<sup>3</sup> as a doping salt was found to be the most thermostable addition and have the greatest effect on the dehydration temperature, lowering it by ~40 K.

#### <span id="page-96-2"></span>**4.2.2.6 Addition of CaTiO<sup>3</sup>**

Gupta et al. [140] investigated CaTiO<sup>3</sup> as an additive to pure Ca(OH)<sup>2</sup> in composite pellets in proportions of 1:0.5 and 1:1 Ca(OH)2:CaTiO<sup>3</sup> (by weight ratio). Composite pellets were found to retain their shape and suffer much lower loss of mechanical strength after repeated cycles as compared to pellets of pure Ca(OH)2. The composite pellets also had faster kinetics, most likely because of the increased surface area due to the presence of CaTiO3. Similar faster kinetics upon addition of CaTiO<sup>3</sup> was noted for the carbonation and decarbonation system by Aihara et al. [212].

## **5 PRELIMINARY MODELING STUDY FOR ULTRA-HIGH-TEMPERATURE HEAT PUMP SYSTEMS**

<span id="page-96-3"></span>This chapter will discuss the preliminary modeling study of UHTHP. Some reference models for UHTHP systems have been established and run using Aspen Plus V11.0.

## **5.1 Vapor Compression Cycle**

<span id="page-96-4"></span>The VCHP system is one of the common types of HP system that utilizes the change in phase transition temperature of the heat transporting fluid with pressure change. The VCHP system mainly consists of the compressor, expansion nozzle, heat sink, and heat source. Additionally, supplementary components such as flash tank, heat exchanger, or other units may be added to improve the performance. Evaporation occurs when absorbing heat from the surroundings in a low-pressure and low-temperature heat source, whereas condensation occurs in a high-pressure and high-temperature heat sink when releasing heat to the surroundings. Note that the heat sink temperature is supposed to be higher than that of the heat source to achieve the goal of HP.

#### <span id="page-96-5"></span>**5.1.1 Vapor Compression Cycle With Flash Tank**

Ammonia (NH3) is one of heat transporting fluids used for large-scale AC systems, of which phase transition occurs near the room temperature. Multistage vapor compression system employs more than

one compressor to increase the HP efficiency. [Figure 42](#page-97-0) represents process flow diagram for the twostage compressor HP system with flash tank, using ammonia as the working fluid. Each stream of the cycle is named by appending "S" to the number enumerated in the figure of flow diagram.

In this simulation, liquid NH<sup>3</sup> is evaporated at the heat source of 1.5 bar, gaseous NH<sup>3</sup> is pressurized to 10 bars by compressor, heat exchanged at flash tower and pressurized to 1.5 bar that expansion valve 1 during loop 1. Similarly, gaseous NH<sup>3</sup> is pressurized to 60 bars and superheated by compressor 2, and supercooled by condensation at the heat source, depressurized by expansion valve 2, and go back to flash tank. Two different loops are combined by flash tank. To exchange heat, flash tank is employed as a intercooler. Heat flow (S6) after the heat sink and expansion valve 2 and heat flow (S2) after the heat source and compressor are mixed and separated by their phase at the flash tank. Vapor stream (S3) are introduced second loop's compressor 2 and heat sink while liquid stream (S7) is flow back to first loop and expansion valve. It is known that flash tanks have not only higher efficiency but also cheaper installation cost than that of heat exchanger with respect to heat transferring between two streams of media [213]. Flash tank mixes all streams of heat transfer media together, and released into saturated liquid and gas, whereas heat exchanger only has indirect heat transfer between cold and hot stream of heat transfer media. Heat exchanger has more complex and expensive configuration than that of flash tank because heat exchanger is designed for each stream to be physically segregated but to occur heat transfer well. The Peng-Robinson equation is used as the equation of the states. Efficiency of each compressor is estimated as below correlation [214]. Through this HP, -24.9°C of heat are upgraded to 238.0°C of heat, yielding a COP of 1.979.

$$\eta = 0.9343 - 0.04478(p_2/p_1)$$

![](_page_97_Figure_3.jpeg)

<span id="page-97-0"></span>Figure 42. Vapor compression cycle with two stage and flash tank using ammonia.

The pressure-enthalpy (P-H) diagram clearly shows how the process goes on for HPs. [Figure 43](#page-98-1) shows the P-H diagram of the HP cycle shown in [Figure 42,](#page-97-0) in which the saturation curve of heat transfer medium (or ammonia, blue) and thermodynamic HP cycle (yellow and orange) are described. The phase of medium is liquid if the point locates at on and left hand-side of left saturation curve, whereas it is gas if the point locates at on and right hand-side of right saturation curve. The medium has two phases (gas and liquid) if the point is within the curve. Points enumerated on the diagram correspond to the flow streams numbered in [Figure 42.](#page-97-0)

However, not all materials can use this configuration. Some synthetic oil that has different shapes of saturation curve cannot use this configuration. [Figure 44](#page-98-2) shows the P-H diagram for a HP cycle that has an identical configuration with that shown in [Figure 42](#page-97-0) except the heat transfer medium, synthetic oil

(diphenyl ether-biphenyl mixture). The saturating curve of synthetic oil has a thin tail-shaped feature that is sharply bent to the right, which is contrary to the bell-shaped saturation curve of ammonia. As the slope of saturation curve of synthetic oil is sharper than that of the thermodynamic ideal compressor and the outlet flow from the flash tank is designed to maintain a saturated gas or liquid state, some oil must remain liquid during the compression stages (1–2 and 3–4), as illustrated in [Figure 44.](#page-98-2) Liquid oil in a compressor can damage the compressor. Thus, the HP cycle with a flash tank configuration is only available for fluids whose saturation curve does not change sharply, such as NH<sup>3</sup> or R134.

![](_page_98_Figure_1.jpeg)

<span id="page-98-1"></span>Figure 43. P-H diagram for vapor compression cycle with two stage and intercooler using ammonia.

![](_page_98_Figure_3.jpeg)

<span id="page-98-2"></span>Figure 44. P-H diagram for vapor compression cycle with two stage and intercooler using Diphenyl etherbiphenyl (Dowtherm A).

#### <span id="page-98-0"></span>**5.1.2 Vapor Compression Cycle With Heat Exchanger**

Dowtherm® A (CAS #8004-13-5), comprised of diphenyl ether (26.5 %) and biphenyl (73.5 %), is one of candidates for high-temperature heat transporting media . Dowtherm® A is known to be suitable for high-temperature heat transfer applications up to 400°C [21,22]. This synthetic oil might be thermally self-decomposed at temperatures above the limit. As mentioned in previous section, a flash tank is not appropriate for synthetic oil as heat transfer medium. The heat exchanger can overcome the limitation of flash tank. In the heat exchanger, only heat is exchanged from hot flow to cold flow, meaning that outflow can be superheated or supercooled.

[Figure 45](#page-99-0) represents process flow diagram for the single stage with heat exchanger using Dowtherm® A, and [Figure 46](#page-100-1) shows the HP diagram corresponding to the process flow at [Figure 45.](#page-99-0) Heat is supplied from heat source at 260°C by evaporation, and temperature is increased though heat exchanger, heated oil of 1 bar is pressurized to 20 bars by multistage compressor (two stage, efficiency 0.72) and is released at heat sink of 440°C by condensation. Using that heat exchanger, heat transporting medium is supercooled/superheated (S3, S7) enough so that liquid does not exist within the compressor stage and stream right before condensation stage at heat sink has only gaseous medium. The compressor is installed within stream S2 unlike the cycle illustrated in to avoid liquid oil in the compressor. COP of this HP yields 2.305.

Parametric study is also performed for this model, in which we vary (1) discharge pressure at the compressor and (2) temperature at the heat sink[. Figure 47](#page-100-2) represents the result of the parametric study. COP is a function of the temperature at the heat sink. COP decreases as temperature at the heat sink increases, showing that there is a trade-off relationship between the temperature difference between the heat sink and source and COP. There is a threshold temperature showing a sharp drop of COP as temperature increases. The maximum temperature at the heat sink in [Figure 47](#page-100-2) is determined by the temperature at which the COP sharply drops down. If the temperature at the heat sink is larger than the maximum temperature at the heat sink, COP is sharply drop down and HP is no longer economical.

<span id="page-99-0"></span>![](_page_99_Picture_3.jpeg)

Figure 45. Vapor compression cycle with single-stage intermediate heat exchanger using synthetic oil.

![](_page_100_Figure_0.jpeg)

<span id="page-100-1"></span>Figure 46. H-P graph for vapor compression cycle with single-stage intermediate heat exchanger.

![](_page_100_Figure_2.jpeg)

<span id="page-100-2"></span>Figure 47. parametric study for vapor compression cycle with single-stage intermediate heat exchanger. (left side) COP as a function of temperature of heat sink at different discharging pressure, (right side) temperature where the COP drop suddenly at different discharging pressure and corresponding COP.

## **5.2 Chemical Heat Pump Cycle**

<span id="page-100-0"></span>The ChHP concept employs reversible chemical reactions to offer high heat of reaction, making it useful for heat augmentation. As VCHPs utilize the change in phase transition temperature with pressure change, ChHPs utilize the direction of the heat of reaction – whether it is endothermic or exothermic – in conjunction with pressure change. The concept of ChHP is similar to that of chemical heat storage, but its operating condition is limited. An endothermic reaction should occur at the heat source with low temperature while an exothermic reaction occurs at the heat sink with high temperature because we want to upgrade heat to a high temperature. In the case of CaO – Ca(OH)<sup>2</sup> reactions, for example, dehydration of Ca(OH)<sup>2</sup> is endothermic and thus supposed to be heat source with low temperature:

$$Ca(OH)_2 \leftrightarrow CaO + H_2O_{(a)} \Delta H_{298k} = 104 \, kJ/mol$$

The direction of the reaction can be determined by comparing the reaction quotient Q and equilibrium constant  $K_{eq}$ . The reaction quotient Q determines the relative amounts of products and reactants. It is defined as the ratio of the activities of the products to the activities of the reactants, taking stoichiometric coefficients of the reaction into account as exponents of the activities. Since both CaO and  $Ca(OH)_2$  are solid phases whose activities are usually considered as unity, the reaction quotient Q can be expressed solely by the partial pressure of the medium (i.e.,  $H_2O$ ) as follows:

$$Q = \frac{a_{H_2O} \ a_{CaO}}{a_{Ca(OH)_2}} = \frac{\left(\frac{f_{CaO}}{p^0}\right)^1 \left(\frac{f_{H_2O}}{p^0}\right)^1}{\left(\frac{f_{Ca(OH)_2}}{p^0}\right)^1} = \phi_{H_2O} \frac{p_{H_2O}}{p^0} \cong \frac{p_{H_2O}}{p^0}$$

The chemical equilibrium constant,  $K_{eq}$ , is either measured by an experiment or thermodynamically calculated from the Gibbs energy of the reaction by using the fact that the value of Q is equal to that of  $K_{eq}$  at the equilibrium condition. The correlation of chemical equilibrium constant  $K_{eq}$  for dehydration of  $Ca(OH)_2$  is expressed below [215]:

$$K_{eq} = 2.3 \cdot 10^6 \cdot \exp(-11,607 / T [K])$$

Generally, the direction of the reaction is determined as the value of reaction quotient Q changes to the value of  $K_{eq}$ , reaching chemical equilibrium where  $Q = K_{eq}$ . In other words, a forward reaction is favorable when  $Q < K_{eq}$ , but a backward reaction is favorable when  $Q > K_{eq}$ . The reaction stops if either all reactant is consumed, or chemical equilibrium is reached. This reaction behavior corresponds to the reactor where inert gas acts as carrier gas to  $CaO/Ca(OH)_2$  reaction. The direction of the reaction is determined as the partial pressure of the steam (or reaction quotient) changes to the value of the chemical equilibrium constant at a specific temperature.

However, if only steam is employed as a carrier medium for the CaO/Ca(OH)<sub>2</sub> reaction without introducing an inert gas, the reaction behavior becomes different. In this case, the reaction quotient is determined by the total pressure of the reactor and does not change even though the reaction occurs. A stable equilibrium cannot be accomplished but the reaction proceeds until all reactant, determined by the direction, is consumed. Figure 48 represents the chemical equilibrium curve and candidate operating conditions of two reactors in the HP system qualitatively. The chemical equilibrium constant as a function of temperature is colored as green. Blue square implies an operating condition of the reactor in which endothermic Ca(OH)<sub>2</sub> dehydration reaction occurs, and red diamond shows that of another reactor in which exothermic CaO hydration reaction occurs. Operating condition of Ca(OH)<sub>2</sub> dehydration (blue square) is supposed to lie below the equilibrium curve, whereas that of CaO hydration (red diamond) lies above the curve. There is a special limit on the ChHP that is not necessary for chemical heat storage. The reaction temperature of an endothermic reaction (blue) is supposed to be lower than that of an exothermic reaction (red). Otherwise, the system becomes an AC system, not a HP.

![](_page_102_Figure_0.jpeg)

<span id="page-102-0"></span>Figure 48. Chemical equilibrium curve as a function of temperature and suggested operating conditions for the reactors in ChHP.

It is hard to simply conclude whether the inert gases are of benefit to ChHP systems or not. The reactor used for heat source prefers the existence of inert gas because low partial pressure of steam is readily obtained by adding an inert gas. However, it is opposite to the reactor used for heat sink where high partial pressure of steam is required. Additional energy required to pressurize the inert gas reduces COP. Thus, two different ChHP designs either with or without inert gas are suggested.

[Figure 49](#page-103-0) represents a process flow diagram of reference ChHP model without inert gas. The Ca(OH)2/CaO dehydration-hydration reaction is employed, and only H2O is used as a heat transporting medium. The thick blue line represents the water/steam flow, while the thin black line represents solid material only. Through this HP, 450℃ of heat from the reactor (RX1) is augmented and released at the reactor (RX2) to 650℃, and the amount of heat transferred is approximately 1 MW. Soave-Redlich-Kwong (SRK) model is selected as the equation of the state model.

Solid Ca(OH)2at a flow rate of 50 kmol/hr from stream (CaOH2-1) and steam at a flow rate of 20 kmol/hr from stream (S0) are mixed and introduced into the Gibbs reactor model (RX1) with restricted equilibrium option. The operating temperature and pressure of the reactor (RX1) is specified as 450℃ and 0.2 bar, respectively, resulting in the reaction quotient (or total pressure in this case) lower than the chemical equilibrium constant of the reaction. Ca(OH)<sup>2</sup> dehydration occurs, and all Ca(OH)<sup>2</sup> are turned into CaO and H2O. The total pressure should not be too low. Uneven pressure profiles that might happen locally within the reactor cannot be negligible if total pressure is too low and can affect the direction of the reactions. Reliability is not guaranteed under too low pressure conditions. CaO is separated from H2O flow through an ideal cyclone separator (SEP1). Heat transporting medium, steam (S3), undergoes a process of cooling and condensation (HX1, HT1), and is pressurized to 10 bars by pump (PP1) instead of direct pressurization that would entail a high energy input from a compressor. Subsequently, the condensed steam undergoes a heating and vaporization process (HX1, HX2, HT2). The phase transition occurs at the cold stream of the heat exchanger (HX2), and thus the temperature of the stream does not change. Then, the CaO separated at the separator (SEP1) is reintroduced to the pressurized steam (S8). The H2O-CaO mixture is heated to 650℃ and introduced to second reactor (RX2), forming Ca(OH)2. Remaining steam after the dehydration reaction is separated from Ca(OH)<sup>2</sup> by an ideal cyclone separator (SEP2) and depressurized to 0.2 bar at the nozzle (NZ1). The temperature reduced by the nozzle is reheated by heater HT3. Stream CAOH2-3, and CAO-3 can be considered as purge of solid materials, and stream CaOH2-2 and CAO-2 does as make-up of solid materials. They might be connected to the storage tank for solid materials. The reactor (RX2) releases 1,340 kW of heat, while the work and heat inputs

required to drive the entire HP cycle are provided by pump (PP1, 1.174 kW), heater (HT2, 854.7 kW), and heater (HT3, 1.095 kW). This results in the COP of 1.56.

![](_page_103_Figure_1.jpeg)

<span id="page-103-0"></span>Figure 49. Process flow diagram and simulation results of ChHP using CaO-Ca(OH)<sup>2</sup> reactions without inert gas

The condensation concept used in [Figure 49](#page-103-0) cannot be directly employed if inert gas is introduced. This is because the inert gas, having low boiling point, requires excess energy for condensation. In other words, the energy input required for condensing the inert gas is so large that it eliminates the benefit of using a pump. To overcome this problem, a new concept of design is proposed in this study which is illustrated in [Figure 50.](#page-104-0) The blue, red and black line represents stream of steam, inter gas (nitrogen) and solid material, respectively. The key to the new configuration is to use a distillation tower to separate the nitrogen from the reactor. By separating nitrogen, we can not only continue to maintain condensation concept, but also obtain a benefit in second reactor. In addition, inert gas separated can be used as carrier gas for solid flow.

Steam-inert gas mixture at a flow rate of 350 kmol/hr at stream S0, in which composition molar ratio of N<sup>2</sup> to H2O is 9:1, and 40 kmol/hr of CaOH2 and CaO2 are introduced through stream CaOH2-4 and CAO-2, respectively. Gibbs reactor model with restricted equilibrium option is used for both reactors (RX1, RX2). The distillation column (DST1) is introduced, which can separate liquid water as exactly as we need, instead of condensing all heat transporting gas mixture. Inert gases are separated before the heat sink reactor and rejoined before the heat source reactor (MX3). Downstream of the distillation column passes the heat exchangers (HX1 and HX2) to recover the heat, of which the design is specified as cold stream outlet temperature to be 430℃ and 200℃, respectively. Condensed steam passes exchanger HX2 and HX3 and is introduced to the reactor (RX2). Heat exchanger HX3 is designed such that the hot stream outlet temperature is 530℃. Inert gas does not need to pressurize, saving the work for pressurization. In

addition, the disadvantage of inert gas at the heat sink, which increases the total pressure required for the proper direction of the reaction, can be avoided. The distillation to feed ratio and reflux ratio of the distillation column is specified to obtain liquid water at 55.5084 kmol/hr and near zero purity (1.1 × 10-15) of nitrogen at liquid water stream (S7), which is 0.901724 and 0.108342, respectively, for [Figure 50.](#page-104-0) Ten stages of the distillation column is assumed, and inlet stream (S6) is introduced at 5th stage from the top.

Work and heat introduced to the system for running HP locates at pump (PP1), reboiler of the distillation column (QR of DST1), heater (HT2), and heater (HT3). Thus, COP is calculated by the amount of the heat released at the reactor (RX2) divided by work heat supplied at the four units mentioned above. [Table 22](#page-104-1) represents the COP of the pump for four different temperatures (650 ~ 800℃) of heat sink. Discharging pressure of PUMP1 and PUMP2 is changed to be larger than chemical equilibrium constant at specific temperature. Temperature augmentation of 200 ~ 350℃ can be obtained in this ChHP configuration. Interestingly, COP yields approximately 1.48 for all cases.

As fine tuning has not been completed yet for this process, especially for heat exchanger and distillation column, COP can be improved in further work. The benefit of this design is (1) that we can maintain the atmospheric pressure at the heat source region by controlling the amount of inert gas, and thus (2) readily increase the temperature of the heat sink by controlling the discharge pressure of pumps (PUMP1, and PUMP2).

![](_page_104_Figure_3.jpeg)

<span id="page-104-0"></span>Figure 50. Process flow diagram of ChHP using CaO-Ca(OH)<sup>2</sup> reactions with inert gas and its simulation results for the case with heat sink temperature of 650℃.

<span id="page-104-1"></span>Table 22. COP of the pump for different temperature of heat sink.

| RX2         |              |               | DST1   | Pump1   | HX1    | HX2    | COP    |        |
|-------------|--------------|---------------|--------|---------|--------|--------|--------|--------|
| [℃]<br>𝑇𝐻2𝑂 | Keq<br>[bar] | [bar]<br>𝑝𝐻2𝑂 | Q [kW] | QR [kW] | W [kW] | Q [kW] | Q [kW] | [-]    |
| 650         | 8.9458       | 10            | 1,072  | 60.81   | 0.8835 | 67.47  | 594    | 1.4824 |

| 700 | 16.9824 | 20 | 1,053 | 61.23 | 1.865 | 50.46 | 594.7 | 1.4868 |
|-----|---------|----|-------|-------|-------|-------|-------|--------|
| 750 | 29.9823 | 35 | 1,031 | 60.81 | 3.338 | 33.14 | 595.9 | 1.4873 |
| 800 | 49.7    | 55 | 1,008 | 61.31 | 5.301 | 15.76 | 597.4 | 1.4829 |

## **5.3 Dynamic Heat Pump Simulation**

<span id="page-105-0"></span>This section performs preliminary HP dynamic simulation using Aspen Plus Dynamics V11. Whereas Aspen Plus handles steady-state models, the Aspen Plus Dynamics solves time-dependent process models. The VCHP model using synthetic oil handled in Section [5.1.2](#page-98-0) is modified as illustrated in [Figure](#page-105-1)  [51.](#page-105-1) A bypass stream is added to the process in which a portion of flow is separated at the splitter (B2) and returned back to the mixer (B5) between the heat exchanger (B10) and Heater (B9). The higher the split ratio of the bypass flow is, the lower the temperature of stream S4 is. Controller (B3) is designed to control the split ratio of mass flow at splitter (B2) based on the temperature of stream (S4)[. Figure 52](#page-106-1) represents the preliminary dynamic simulation results, showing the temperature of stream S4 and split ratio of bypass as a function of time. The set point (dark blue) of the controller (B3) is ramped up from 400°C to 420°C at 3.5 hours and down to 410°C after 15 minutes. The temperature of flow at the stream S4 (blue) is followed by the set point of the controller by changing the controller output (or split ratio at the splitter, green) accordingly. It might be employed for the case where heat flow at the heat source (B7) and heat sink (B4) are changing as a function of temperature to keep the temperature of stream S4 constant. Further study is required.

<span id="page-105-1"></span>![](_page_105_Picture_3.jpeg)

Figure 51. Flow diagram of ammonia VCHP for dynamic simulation.

![](_page_106_Figure_0.jpeg)

<span id="page-106-1"></span>Figure 52. Preliminary dynamic simulation result, temperature control at stream S4.

## **6 SUMMARY AND CONCLUSIONS**

<span id="page-106-0"></span>This report provides a comprehensive review of HP technologies with the potential to achieve heat supply temperatures above 250℃, referred to as UHTHP, as an alternative to traditional combustion heating widely used in high-temperature industrial processes. The scope of this review includes both mechanically and thermally driven HP technologies. The heat supply temperature of over 250℃ pursued by UHTHP exceeds the temperature range commonly discussed in the HTHP literature and the existing capabilities of commercial HP systems. Hence, this study focused on the UHTHP's feasibility, specific technical challenges, and identification of potential technologies to address the current challenges, based on the review of the current state-of-the-art HTHP technologies.

For MDHPs, most of the recent studies and state-of-the-art commercial HPs have focused on heat supply temperatures of at most 200℃–250℃. To date, there have been few adoptions of HPs within industry that handle temperatures above 250℃. The technical challenges primarily arise from two aspects: (i) component limitations and (ii) HP system performance degradation. The component limitations [(i)], particularly those related to temperature, pertain to the constraints of the compressor, working fluid, and materials. Accordingly, we delved into the state-of-the-art for compressors, lubricants, and working fluids available at temperatures around 250℃ or higher. The performance degradation of UHTHP [(ii)] is another challenge that arises due to increased compressor work required as the heat supply temperature rises for a given heat source temperature.

To provide useful insights into the feasibility of UHTHP, this study further explored advanced technologies that can alleviate the current technical challenges in terms of both components and HP system performance. Regarding the component limitations [(i)], despite the temperature constraints of commercial HPs, several recent studies discuss the currently available compressor technology capable of operating at temperatures up to 480℃ (CO<sup>2</sup> compressor) in the oil-gas sector and up to 600℃ (air compressor) in the gas turbine sector. In addition, turbochargers for internal combustion engines, operating on similar principles as turbo-compressors, are typically designed and constructed to withstand temperatures up to 950℃. Oil-free compressors and high-temperature lubricants, investigated through this study, are also important technologies that can facilitate compressor operation in UHT environments. Besides the compressor, this study also reviewed and identified a range of natural and synthetic fluids proven for use in high-temperature power cycles (T>300℃), including an ammonia-water mixture. While research on UHTHP using these fluids is yet limited, it could serve as a critical basis for future UHTHP

studies to improve its exergy efficiency and overall economics. As for the performance degradation of UHTHP [(ii)], potential performance improvement strategies and relevant studies were investigated, including integration with TES or electric heaters, the use of azeotropic fluid mixtures, and the utilization of cascade-cycle- or transcritical-cycle-based HP systems. Another critical factor to consider for improving the performance of UHTHP is the availability of reliable waste (or surplus) heat sources from low-carbon energy outlets like nuclear and solar heat. With a reliable waste heat source, UHTHP can operate more efficiently even at high temperatures due to reduced compressor work as discussed in Sectio[n 3.](#page-65-0)

For TDHPs, that is, ChHPs, may offer a potential solution to accomplish not only efficient thermal storage but also temperature amplification to enhance the applicability of a wide variety of thermal sources (nuclear, solar thermal, biomass, waste heat, etc.) over a wide range of temperatures. ChHPs are based on reversible chemical reactions, and this study focused on systems that are capable of providing a high to very high temperature boost. The candidate systems that can provide this boost are based on working fluids, water vapor, carbon dioxide, oxygen, or hydrogen. Of these fluids, hydrogen and oxygen systems are typically operated in energy storage rather than the HP mode. Water vapor is the working fluid in systems where chemicals alternate between hydroxide and oxide forms, while carbon dioxide is the working fluid in systems where the chemicals alternate between carbonate and oxide forms. Several studies, particularly on calcium-based systems, have been reported in literature investigating the fundamental aspects (thermodynamics and kinetics) as well as system operation at small scales. However, the TRL of these systems is lower as compared to the MDHP systems.

Overall, the key findings of the current review and the insights gained can be summarized as follows:

- In the case of MDHP, existing compressor technologies used in the oil and gas industry, gas turbines, and automobile sectors strongly suggest that the technology for developing HP systems supplying heat above 250℃ (i.e., UHTHP) may already exist. The fundamental reason for the current temperature limitation of commercial HPs primarily stem from a lack of sufficient market demand rather than technical constraints. However, the limitations of materials (i.e., alloy steels) still exist, most of which have a temperature limit of around or below 600℃ under high temperature and pressure conditions of UHTHP. For commercial deployment of UHTHP, these material constraints can lead to practical limitations on the achievable heat supply temperature.
- Current review also revealed promising technological advances applicable to UHTHP, including high-temperature lubricants, refrigerants, and advanced HTHP systems.
- Integrating MDHP cycles with electrical heaters can be a viable approach for UHT heat pumping to meet the decarbonization demands of the high-temperature industrial processes with suitably high efficiency, without requiring new technology development, such as compressors.
- The presence of reliable waste (or surplus) heat sources from low-carbon energy outlets, like nuclear and solar, can substantially improve the performance of MDHP cycles. The comparative studies among various UHTHP systems in the literature indicated that COPs of up to about three or higher are achievable, depending on ΔTlift and thermodynamic cycles.
- For MDHP, the gathered information in this work can help fulfill two main purposes 1) to demonstrate that an UHTHP is a feasible option and 2) to assist in the thermodynamic cycle selection and design of an UHTHP based on initial system requirements, namely ΔTlift and COP.
- ChHP systems, based on solid-gas reactions, suffer from performance deterioration with increasing number of cycles, with degradation of solid reactant being the main cause. Overcoming the structural integrity and mechanical stability of the solid phase is a major challenge in the development of ChHPs.

- ChHPs also lag behind MDHP systems in terms of fundamental understanding of the phenomena. The thermodynamics and kinetics of the systems need to be refined for improving process models which in turn will enhance the accuracy of system design. Scaled up, sustained operation of the systems also needs to be demonstrated to increase the TRL of ChHPs.
- In general, commercial deployment of UHTHP systems still requires strong business cases beyond technology development and demonstration. Increasing demand for decarbonizing industrial processes may lead to growing demand for UHTHP technologies.
- Developing business cases for UHTHP requires detailed analysis of the industrial process requirements, including temperature, pressure, heat load, duty cycle, etc. This should be an integral part of future research plan towards the commercial deployment of UHTHP.

Taken together, UHTHP holds significant promise as a clean energy technology to decarbonize hightemperature industrial processes, and MDHP in particular has already exhibited its technological feasibility from practical application cases in several industries. Commercial suppliers have increasingly shown interest in developing MDHP systems capable of achieving heat supply temperatures above 250°C, and several prototype developments are currently underway [13,43].

To make an effective and practical contribution to industrial decarbonization, UHTHP requires access to low-carbon heat sources such as nuclear. That said, further research is required for the systems that integrate UHTHP, low-carbon heat sources, and actual industrial processes. The preliminary HP models established in this study will be expanded and refined to support progress in this direction.

## **7 REFERENCES**

- <span id="page-109-0"></span>[1] DOE/EE-2635, *Industrial Decarbonization Roadmap*, U.S. Department of Energy (DOE), 2022.
- [2] C. Philibert, "Renewable energy for industry," *Paris: International Energy Agency*, 2017.
- [3] K.-M. Adamson, T.G. Walmsley, J.K. Carson, Q. Chen, F. Schlosser, L. Kong, and D.J. Cleland, "High-temperature and transcritical heat pump cycles and advancements: A review," *Renewable and Sustainable Energy Reviews*, vol. 167, 2022, p. 112798.
- [4] Enerin-Energy-Engineering, "Ultra high-temperature heat pumps at: https://www.enerin.no/hoegtemp," 2022.
- [5] Internet, "Open Loop Heat Pump System in Dryficiency, Available at:https://dryficiency.eu/industrial-heat-pumps/open-loop," 2021.
- [6] D. Wu, J. Jiang, B. Hu, and R. Wang, "Experimental investigation on the performance of a very high temperature heat pump with water refrigerant," *Energy*, vol. 190, 2020, p. 116427.
- [7] C. Arpagaus, F. Bless, M. Uhlmann, J. Schiffmann, and S.S. Bertsch, "High temperature heat pumps: Market overview, state of the art, research status, refrigerants, and application potentials," *Energy*, vol. 152, 2018, pp. 985–1010.
- [8] P. Nellissen and S. Wolf, "Heat pumps in non-domestic applications in Europe: Potential for an energy revolution," *Emerson Climate Technologies, Delta-ee 3rd Annual Heat Pumps & Utilities Roundtable*, 2015.
- [9] L. Liu, Q. Yang, and G. Cui, "Supercritical carbon dioxide (s-CO2) power cycle for waste heat recovery: a review from thermodynamic perspective," *Processes*, vol. 8, 2020, p. 1461.
- [10] R. Vescovo and E. Spagnoli, "High temperature ORC systems," *Energy Procedia*, vol. 129, 2017, pp. 82–89.
- [11] M.M. Hossain, M.S. Hossain, N.A. Ahmed, and M.M. Ehsan, "Numerical Investigation of a modified Kalina cycle system for high-temperature application and genetic algorithm based optimization of the multi-phase expander's inlet condition," *Energy and AI*, vol. 6, 2021, p. 100117.
- [12] B. Zühlsdorf, F. Bühler, M. Bantle, and B. Elmegaard, "Analysis of technologies and potentials for heat pump-based process heat supply above 150 C," *Energy Conversion and Management: X*, vol. 2, 2019, p. 100011.
- [13] J. Oehler, J.O. Gollasch, A.P. Tran, and E. Nicke, "Part load capability of a high temperature heat pump with reversed brayton cycle," *13th IEA Heat Pump Conference 2021 (HPC2020) Conference Proceedings*, 2021.
- [14] C. Arpagaus, "Industrial Heat Pumps: Technology readiness, economic conditions, and sustainable refrigerants," American Council for an Energy Efficient Economy, 2023.
- [15] V. Aga, E. Conte, R. Carroni, B. Burcker, and M. Ramond, "Supercritical CO2-based heat pump cycle for electrical energy storage for utility scale dispatchable renewable energy power plants," *Proc: 5th Int. Symp.—Supercritical CO2 Power Cycles (San Antonio, United States)*, 2016.
- [16] P. Bombarda and C. Invernizzi, "Binary liquid metal–organic Rankine cycle for small power distributed high efficiency systems," *Proceedings of the Institution of Mechanical Engineers, Part A: Journal of Power and Energy*, vol. 229, 2015, pp. 192–209.
- [17] J. Bao and L. Zhao, "A review of working fluid and expander selections for organic Rankine cycle," *Renewable and sustainable energy reviews*, vol. 24, 2013, pp. 325–342.
- [18] H. Yu, X. Feng, and Y. Wang, "Working fluid selection for organic Rankine cycle (ORC) considering the characteristics of waste heat sources," *Industrial & Engineering Chemistry Research*, vol. 55, 2016, pp. 1309–1321.

- [19] G.F. Frate, L. Ferrari, and U. Desideri, "Analysis of suitability ranges of high temperature heat pump working fluids," *Applied Thermal Engineering*, vol. 150, 2019, pp. 628–640.
- [20] J. Mairhofer and M. Stavrou, "A Multi-Criteria Study of Optimal Working Fluids for High Temperature Heat Pumps," *Chemie Ingenieur Technik*, vol. 95, 2023, pp. 458–466.
- [21] E.O. Sampedro and L. Védie, "Diphenyl-diphenyl oxide eutectic mixture for high temperature waste-heat valorization by a partially evaporated cycle cascade," *Energy*, vol. 263, 2023, p. 125812.
- [22] Dow, "DOWTHERM A heat transfer fluid. Product Technical Data," 1997.
- [23] W. Anderson, "Intermediate temperature fluids for heat pipes and loop heat pipes," *5th International Energy Conversion Engineering Conference and Exhibit (IECEC)*, 2007, p. 4836.
- [24] C.M. Invernizzi, P. Iora, D. Bonalumi, E. Macchi, R. Roberto, and M. Caldera, "Titanium tetrachloride as novel working fluid for high temperature Rankine Cycles: Thermodynamic analysis and experimental assessment of the thermal stability," *Applied Thermal Engineering*, vol. 107, 2016, pp. 21–27.
- [25] M. Eisa, R. Best, and F. Holland, "Working fluids for high temperature heat pumps," *Journal of heat recovery systems*, vol. 6, 1986, pp. 305–311.
- [26] M. Chamoun, R. Rulliere, P. Haberschill, and J.-L. Peureux, "Experimental and numerical investigations of a new high temperature heat pump for industrial heat recovery using water as refrigerant," *International Journal of Refrigeration*, vol. 44, 2014, pp. 177–188.
- [27] Z. Wu, X. Wang, L. Sha, X. Li, X. Yang, X. Ma, and Y. Zhang, "Performance analysis and multiobjective optimization of the high-temperature cascade heat pump system," *Energy*, vol. 223, 2021, p. 120097.
- [28] H. Abedini, E. Vieren, T. Demeester, W. Beyne, S. Lecompte, S. Quoilin, and A. Arteconi, "A comprehensive analysis of binary mixtures as working fluid in high temperature heat pumps," *Energy Conversion and Management*, vol. 277, 2023, p. 116652.
- [29] O. Bamigbetan, T.M. Eikevik, P. Nekså, and M. Bantle, "Review of vapour compression heat pumps for high temperature heating using natural working fluids," *International journal of refrigeration*, vol. 80, 2017, pp. 197–211.
- [30] R.B. Laughlin, "Pumped thermal grid storage with heat exchange," *Journal of Renewable and Sustainable Energy*, vol. 9, 2017.
- [31] M. Pasetti, C.M. Invernizzi, and P. Iora, "Thermal stability of working fluids for organic Rankine cycles: An improved survey method and experimental results for cyclopentane, isopentane and nbutane," *Applied Thermal Engineering*, vol. 73, 2014, pp. 764–774.
- [32] M. Linnemann, K.-P. Priebe, A. Heim, C. Wolff, and J. Vrabec, "Experimental investigation of a cascaded organic Rankine cycle plant for the utilization of waste heat at high and low temperature levels," *Energy Conversion and Management*, vol. 205, 2020, p. 112381.
- [33] M. Bertinat, "Fluids for high temperature heat pumps," *International journal of refrigeration*, vol. 9, 1986, pp. 43–50.
- [34] J. Jiang, B. Hu, T. Ge, and R. Wang, "Comprehensive selection and assessment methodology of compression heat pump system," *Energy*, vol. 241, 2022, p. 122831.
- [35] B. Degueurce, F. Banquet, J. Densant, and D. Favrat, "Use of a twin screw compressor for steam compression," *Hydraulic Pneumatic Mechanical Power*, vol. 30, 1984, pp. 335–337.
- [36] I. Tamura, H. Taniguchi, H. Sasaki, R. Yoshida, I. Sekiguchi, and M. Yokogawa, "An analytical investigation of high-temperature heat pump system with screw compressor and screw expander for power recovery," *Energy conversion and management*, vol. 38, 1997, pp. 1007–1013.

- [37] J. Sarkar, S. Bhattacharyya, and M.R. Gopal, "Natural refrigerant-based subcritical and transcritical cycles for high temperature heating," *International journal of refrigeration*, vol. 30, 2007, pp. 3–10.
- [38] E. Vieren, T. Demeester, W. Beyne, A. Arteconi, M. De Paepe, and S. Lecompte, "The thermodynamic potential of high-temperature transcritical heat pump cycles for industrial processes with large temperature glides," *Applied Thermal Engineering*, 2023, p. 121197.
- [39] C. Kondou and S. Koyama, "Thermodynamic assessment of high-temperature heat pumps using Low-GWP HFO refrigerants for heat recovery," *International Journal of Refrigeration*, vol. 53, 2015, pp. 126–141.
- [40] C. Arpagaus, F. Bless, and S. Bertsch, "Theoretical analysis of transcritical HTHP cycles with low GWP HFO refrigerants and hydrocarbons for process heat up to 200° C," *Proc. IIR Rankine 2020 Conference, Glasgow*, 2020.
- [41] R. Bergamini, J.K. Jensen, and B. Elmegaard, "Thermodynamic competitiveness of high temperature vapor compression heat pumps for boiler substitution," *Energy*, vol. 182, 2019, pp. 110–121.
- [42] "Spilling Technologies: Spilling Steam Compressor, www.heatpumpingtechnologies.org/annex58/."
- [43] B. Zühlsdorf, J.L. Poulsen, S. Dusek, V. Wilk, J. Krämer, R. Rieberer, M. Verdnik, T. Demeester, E. Vieren, C. Magni, H. Abedini, C. Leroy, L. Yang, M.P. Andersen, B. Elmegaard, T. Turunen-Saaresti, A. Uusitalo, F.D. Carlan, C. Gachot, F. Schlosser, S. Klöppel, O.A. Khass, O.A. Khass, U. Wittstadt, S. Henninger, H.T. de Oliveira, T. Kaida, M. Ramirez, J.-A.L. a Nijeholt, C. Schlemminger, O.M. Moen, G. Lee, and C. Arpagaus, "High-Temperature Heat Pumps: Task 1 - Technologies," vol. Report no. HPT-AN58-2, 2023.
- [44] P. Sharan, J.D. McTigue, T.J. Yoon, R. Currier, and A.T. Findikoglu, "Energy efficient supercritical water desalination using a high-temperature heat pump: A zero liquid discharge desalination," *Desalination*, vol. 506, 2021, p. 115020.
- [45] Z. Zhao, H. Yuan, S. Gao, and Y. Tian, "Comparative study on performance and applicability of high temperature water steam producing systems with waste heat recovery," *Case Studies in Thermal Engineering*, vol. 28, 2021, p. 101622.
- [46] Z. Yang, H. Liu, and X. Wu, "Theoretical and experimental study of the inhibition and inert effect of HFC125, HFC227ea and HFC13I1 on the flammability of HFC32," *Process Safety and Environmental Protection*, vol. 90, 2012, pp. 311–316.
- [47] M.U. Ahrens, M. Loth, I. Tolstorebrov, A. Hafner, S. Kabelac, R. Wang, and T.M. Eikevik, "Identification of Existing Challenges and Future Trends for the Utilization of Ammonia-Water Absorption–Compression Heat Pumps at High Temperature Operation," *Applied Sciences*, vol. 11, 2021, p. 4635.
- [48] A. Fernández-Moreno, A. Mota-Babiloni, P. Gimenez-Prades, and J. Navarro-Esbr, "Optimal refrigerant mixture in single-stage high-temperature heat pumps based on a multiparameter evaluation," *Sustainable Energy Technologies and Assessments*, vol. 52, 2022, p. 101989.
- [49] A. Modi and F. Haglind, "Performance analysis of a Kalina cycle for a central receiver solar thermal power plant with direct steam generation," *Applied Thermal Engineering*, vol. 65, 2014, pp. 201–208.
- [50] A.I.Kalina, "Method of Preventing Nitridation or Carburization of Metals, United States, Patent 6482272 B2," 2002.
- [51] M.D. Mirolli, "Kalina Cycle Power Systems in Waste Heat Recovery Applications, pp.1-8 (Online). Available: www.globalcement.com/magazine/ articles/721-kalina-cycle-power-systemsin-waste-heat-recovery-applications," 2012.

- [52] O. Bamigbetan, T. Eikevik, P. Nekså, and M. Bantle, "Evaluation of natural working fluids for the development of high temperature heat pumps," *12th Iir Gustav Lorentzen Natural Working Fluids Conference*, 2016, pp. 575–582.
- [53] B. Zühlsdorf, F. Bühler, R. Mancini, S. Cignitti, and B. Elmegaard, "High temperature heat pump integration using zeotropic working fluids for spray drying facilities," *Rotterdam: 12th IEA Heat pump Conf*, 2017, pp. 1–11.
- [54] M. Pitarch, E. Hervas-Blasco, E. Navarro-Peris, and J.M. Corberan, "Exergy analysis on a heat pump working between a heat sink and a heat source of finite heat capacity rate," *International Journal of Refrigeration*, vol. 99, 2019, pp. 337–350.
- [55] A.J. Pimm, T.T. Cockerill, and W.F. Gale, "Reducing industrial hydrogen demand through preheating with very high temperature heat pumps," *Applied Energy*, vol. 347, 2023, p. 121464.
- [56] T. Mancini, P. Heller, B. Butler, B. Osborn, W. Schiel, V. Goldberg, R. Buck, R. Diver, C. Andraka, and J. Moreno, "Dish-Stirling systems: An overview of development and status," *J. Sol. Energy Eng.*, vol. 125, 2003, pp. 135–151.
- [57] F. Nepveu, A. Ferriere, and F. Bataille, "Thermal model of a dish/Stirling systems," *Solar Energy*, vol. 83, 2009, pp. 81–89.
- [58] J. Yoo, S. Qin, A.B.P. Silvino, and E. Hisahara, *A Comparative Evaluation and Selection of High-Temperature Heat Exchangers for Application to Integrated Energy Systems*, Idaho National Lab.(INL), Idaho Falls, ID (United States), 2023.
- [59] J. McTigue, P. Farres-Antunez, K. Ellingwood, T. Neises, and A. White, "Pumped thermal electricity storage with supercritical CO2 cycles and solar heat input," *AIP Conference Proceedings*, AIP Publishing LLC, 2020, p. 190024.
- [60] P. Tafur-Escanta, R. Valencia-Chapi, M. Lopez-Guillem, O. Fierros-Peraza, and J. Munoz-Anton, "Electrical energy storage using a supercritical CO2 heat pump," *Energy Reports*, vol. 8, 2022, pp. 502–507.
- [61] J.A. Mallinak, *A Thermally-Driven Transcritical CO 2 Heat Pump for Upgrading LWR-Grade Heat to High Temperatures*, Research Performance Progress Report: DE-SC0022694, 2023.
- [62] S. Lecompte, E. Ntavou, B. Tchanche, G. Kosmadakis, A. Pillai, D. Manolakos, and M. De Paepe, "Review of experimental research on supercritical and transcritical thermodynamic cycles designed for heat recovery application," *Applied Sciences*, vol. 9, 2019, p. 2571.
- [63] V.K. Patel and B.D. Raja, "A comparative performance evaluation of the reversed Brayton cycle operated heat pump based on thermo-ecological criteria through many and multi objective approaches," *Energy conversion and management*, vol. 183, 2019, pp. 252–265.
- [64] P. Wu, Y. Ma, C. Gao, W. Liu, J. Shan, Y. Huang, J. Wang, D. Zhang, and X. Ran, "A review of research and development of supercritical carbon dioxide Brayton cycle technology in nuclear engineering applications," *Nuclear Engineering and Design*, vol. 368, 2020, p. 110767.
- [65] G. Walker, R. Fauvel, R. Gustafson, and J. Van Bentham, "Stirling engine heat pumps," *International Journal of Refrigeration*, vol. 5, 1982, pp. 91–97.
- [66] C.M. Invernizzi, "Stirling engines using working fluids with strong real gas effects," *Applied Thermal Engineering*, vol. 30, 2010, pp. 1703–1710.
- [67] J. Malone, "A new prime mover," *Journal of the Royal Society of Arts*, vol. 79, 1931, pp. 679– 709.
- [68] G. Swift, "A Stirling engine with a liquid working substance," *Journal of applied physics*, vol. 65, 1989, pp. 4157–4172.
- [69] A. Sa'ed and I. Tlili, "Numerical investigation of working fluid effect on Stirling engine performance," *Int J Therm Environ Eng*, vol. 10, 2015, pp. 31–6.

- [70] F. Alberti and L. Crema, "Design of a new medium-temperature Stirling engine for distributed cogeneration applications," *Energy Procedia*, vol. 57, 2014, pp. 321–330.
- [71] J.I. Lee and S.M. Son, "STIRLING ENGINE USING SUPERCRITICAL FLUID," U.S. Patent WO2018062627, 2018.
- [72] Z. Gu, H. Sato, and X. Feng, "Using supercritical heat recovery process in Stirling engines for high thermal efficiency," *Applied thermal engineering*, vol. 21, 2001, pp. 1621–1630.
- [73] D. Renfroe, A. Ahlert, and M. Counts, "Application of hydrated salts in two phase two component Stirling engine regenerators," *Proc., Intersoc. Energy Convers. Eng. Conf.;(United States)*, Mechanical Engineering Department, University of Arkansas, Fayetteville …, 1984.
- [74] C. West, "Stirling engines with controlled evaporation of a two-phase two-component working fluid," *Proc., Intersoc. Energy Convers. Eng. Conf.;(United States)*, Oak Ridge National Laboratory, Oak Ridge, Tennessee, 1983.
- [75] M.M. Bassem, Y. Ueda, and A. Akisawa, "Thermoacoustic stirling heat pump working as a heater," *Applied physics express*, vol. 4, 2011, p. 107301.
- [76] J. Luo, L. Zhang, Y. Sun, Y. Chen, G. Yu, J. Hu, and E. Luo, "Operational characteristics of a free-piston Stirling generator with resonant self-circulating heat exchangers," *Applied Thermal Engineering*, vol. 229, 2023, p. 120534.
- [77] A. Boretti, "α-Stirling hydrogen engines for concentrated solar power," *International journal of hydrogen energy*, vol. 46, 2021, pp. 16241–16247.
- [78] R. Zevenhoven, U. Khan, C. Haikarainen, L. Saeed, T.-M. Tveit, and H. Saxén, "Performance improvement of an industrial Stirling engine heat pump," *Proceedings of the ECOS*, 2020.
- [79] Internet, "Olvondo Technology, Available at:http://olvondotech.no," 2021.
- [80] L. Smith, B. Nuel, S.P. Weaver, S. BERKOWER, S.C. WEAVER, and B. GROSS, "25 kW lowtemperature stirling engine for heat recovery, solar, and biomass applications," *17th International Stirling Engine Conference (ISEC)*, 2016.
- [81] D.M. Berchowitz, M. Janssen, and R.O. Pellizzari, "CO2 Stirling heat pump for residential use," 2008.
- [82] C. Contreras Aramayo, "Integration of an industrial heat pump for a TES-based power-to-heat system: A techno-economic assessment," 2023.
- [83] E.E. Engineering, .
- [84] M.A. White, S. Qiu, R.M. Erbeznik, R.W. Olan, and S.C. Welty, "Status of an advanced radioisotope space power system using free-piston Stirling technology," 1998.
- [85] K. Heidman, "Testing maintenance-free engines that power science in Deep Space," *NASA*, May. 2018.
- [86] J.-S. Huang and C.-H. Cheng, "An efficient theoretical model of rotary-integral Stirling cryocooler validated by experimental testing," *Thermal Science and Engineering Progress*, vol. 43, 2023, p. 101996.
- [87] M.H. Ahmadi, M.A. Ahmadi, A.H. Mohammadi, M. Feidt, and S.M. Pourkiaei, "Multi-objective optimization of an irreversible Stirling cryogenic refrigerator cycle," *Energy Conversion and Management*, vol. 82, 2014, pp. 351–360.
- [88] S. Zare, A. Tavakolpour-Saleh, A. Aghahosseini, and R. Mirshekari, "Thermoacoustic Stirling engines: A review," *International Journal of Green Energy*, vol. 20, 2023, pp. 89–111.
- [89] C. Toro and N. Lior, "Analysis and comparison of solar-heat driven Stirling, Brayton and Rankine cycles for space power generation," *Energy*, vol. 120, 2017, pp. 549–564.
- [90] N. Häggqvist, T.-M. Tveit, and R. Zevenhoven, "Combining measurements and simulation for condition monitoring and performance optimization of an alpha-configuration double-acting high-

- temperature Stirling cycle-based heat pump," *Case Studies in Thermal Engineering*, vol. 47, 2023, p. 103066.
- [91] L. Rabhi, H.H. El, N. Boutammachte, and A. Khmou, "Examination of Stirling engine parameters effect on its thermal efficiency using PROSA software," *Thermal Science*, 2023, pp. 139–139.
- [92] M. Crowley, "NEAR ISOTHERMAL MACHINE," U.S. Patent WO 2016/189289A1, 2016.
- [93] M. Crowley, "Fluidmechanics Co.," 2023.
- [94] Internet, "Qnergy, Available at:http://qnergy.com/tech/," 2019.
- [95] Internet, "Microgen Engine Corporation, Available at:http://microgen-engine.com/," 2019.
- [96] H. Ogura, M. Haguro, Y. Shibata, and Y. Otsubo, "Reaction Characteristics of CaSO4/CaSO4 1/2H2O Reversible Reaction for Chemical Heat Pump," *JOURNAL OF CHEMICAL ENGINEERING OF JAPAN*, vol. 40, 2007, pp. 1252–1256.
- [97] F. Schaube, A. Kohzer, J. Schütz, A. Wörner, and H. Müller-Steinhagen, "De- and rehydration of Ca(OH)2 in a reactor with direct heat transfer for thermo-chemical heat storage. Part A: Experimental results," *Chemical Engineering Research and Design*, vol. 91, May. 2013, pp. 856– 864.
- [98] W. Wongsuwan, S. Kumar, P. Neveu, and F. Meunier, "A review of chemical heat pump technology and applications," *Applied Thermal Engineering*, vol. 21, Oct. 2001, pp. 1489–1519.
- [99] M. Olszewski, "High-Lift Chemical Heat Pump Technologies For Industrial Processes. ASME International Congress and Exposition, November 12-17," May. 1995.
- [100] J. Cot-Gores, A. Castell, and L.F. Cabeza, "Thermochemical energy storage and conversion: Astate-of-the-art review of the experimental research under practical conditions," *Renewable and Sustainable Energy Reviews*, vol. 16, Sep. 2012, pp. 5207–5224.
- [101] S. Spoelstra, W.G. Haije, and J.W. Dijkstra, "Techno-economic feasibility of high-temperature high-lift chemical heat pumps for upgrading industrial waste heat," *Applied Thermal Engineering*, vol. 22, Oct. 2002, pp. 1619–1630.
- [102] I. KlinSoda and P. Piumsomboon, "Isopropanol–acetone–hydrogen chemical heat pump: A demonstration unit," *Energy Conversion and Management - ENERG CONV MANAGE*, vol. 48, Apr. 2007, pp. 1200–1207.
- [103] "IAEA Annual Report for 2021," Oct. 2022.
- [104] J. Guo and X. Huai, "The application of entransy theory in optimization design of Isopropanol– Acetone–Hydrogen chemical heat pump," *Energy*, vol. 43, Jul. 2012, pp. 355–360.
- [105] L.M. Krall, A.M. Macfarlane, and R.C. Ewing, "Nuclear waste from small modular reactors," *Proceedings of the National Academy of Sciences*, vol. 119, Jun. 2022, p. e2111833119.
- [106] M. Romero and A. Steinfeld, "Concentrating solar thermal power and thermochemical fuels," *Energy & Environmental Science*, vol. 5, 2012, p. 9234.
- [107] R.M. Saeed, K.L. Frick, A. Shigrekar, D. Mikkelson, and S. Bragg-Sitton, "Mapping thermal energy storage technologies with advanced nuclear reactors," *Energy Conversion and Management*, vol. 267, Sep. 2022, p. 115872.
- [108] W.R. Stewart and K. Shirvan, "Capital cost estimation for advanced nuclear power plants," *Renewable and Sustainable Energy Reviews*, vol. 155, Mar. 2022, p. 111880.
- [109] G. Ervin, "Solar heat storage using chemical reactions," *Journal of Solid State Chemistry*, vol. 22, Sep. 1977, pp. 51–61.
- [110] M. Hasatani, "highly developed energy utilization by use of chemical heat pump," *New York; Hemisphere Pub. Corp.*, 1992.
- [111] S. Fujimoto, E. Bilgen, and H. Ogura, "CaO/Ca(OH)2 chemical heat pump system," *Energy Conversion and Management*, vol. 43, May. 2002, pp. 947–960.

- [112] Y.A. Criado, A. Huille, S. Rougé, and J.C. Abanades, "Experimental investigation and model validation of a CaO/Ca(OH)2 fluidized bed reactor for thermochemical energy storage applications," *Chemical Engineering Journal*, vol. 313, Apr. 2017, pp. 1194–1205.
- [113] S. Funayama, H. Takasu, M. Zamengo, J. Kariya, S.T. Kim, and Y. Kato, "Composite material for high‐temperature thermochemical energy storage using calcium hydroxide and ceramic foam," *Energy Storage*, vol. 1, Apr. 2019, p. e53.
- [114] M. Schmidt, C. Szczukowski, C. Roßkopf, M. Linder, and A. Wörner, "Experimental results of a 10 kW high temperature thermochemical storage reactor based on calcium hydroxide," *Applied Thermal Engineering*, vol. 62, Jan. 2014, pp. 553–559.
- [115] M. Linder, C. Roßkopf, M. Schmidt, and A. Wörner, "Thermochemical Energy Storage in kWscale based on CaO/Ca(OH)2," *Energy Procedia*, vol. 49, 2014, pp. 888–897.
- [116] Y. Kato, Y. Sasaki, and Y. Yoshizawa, "Magnesium oxide/water chemical heat pump to enhance energy utilization of a cogeneration system," *Energy*, vol. 30, Aug. 2005, pp. 2144–2155.
- [117] E. Mastronardo, L. Bonaccorsi, Y. Kato, E. Piperopoulos, and C. Milone, "Efficiency improvement of heat storage materials for MgO/H2O/Mg(OH)2 chemical heat pumps," *Applied Energy*, vol. 162, Jan. 2016, pp. 31–39.
- [118] Z. Pan and C.Y. Zhao, "Dehydration/hydration of MgO/H2O chemical thermal storage system," *Energy*, vol. 82, Mar. 2015, pp. 611–618.
- [119] K. Kyaw, T. Shibata, F. Watanabe, H. Matsuda, and M. Hasatani, "Applicability of zeolite for CO2 storage in a CaO-CO2 high temperature energy storage system," *Energy Conversion and Management*, vol. 38, Jul. 1997, pp. 1025–1033.
- [120] Y. Kato, N. Harada, and Y. Yoshizawa, "Kinetic feasibility of a chemical heat pump for heat utilization of high-temperature processes," *Applied Thermal Engineering*, vol. 19, Mar. 1999, pp. 239–254.
- [121] A. Meier, E. Bonaldi, G.M. Cella, W. Lipinski, D. Wuillemin, and R. Palumbo, "Design and experimental investigation of a horizontal rotary reactor for the solar thermal production of lime," *Energy*, vol. 29, Apr. 2004, pp. 811–821.
- [122] R. Barker, "The reactivity of calcium oxide towards carbon dioxide and its use for energy storage," *Journal of Applied Chemistry and Biotechnology*, vol. 24, Apr. 1974, pp. 221–227.
- [123] G. Grasa, I. Martínez, M.E. Diego, and J.C. Abanades, "Determination of CaO Carbonation Kinetics under Recarbonation Conditions," *Energy & Fuels*, vol. 28, Jun. 2014, pp. 4033–4042.
- [124] D. Chen, X. Gao, and D. Dollimore, "The application of non-isothermal methods of kinetic analysis to the decomposition of calcium hydroxide," *Thermochimica Acta*, vol. 215, Feb. 1993, pp. 65–82.
- [125] J. Ströhle, M. Junk, J. Kremer, A. Galloy, and B. Epple, "Carbonate looping experiments in a 1MWth pilot plant and model validation," *Fuel*, vol. 127, Jul. 2014, pp. 13–22.
- [126] V. Nikulshina, C. Gebald, and A. Steinfeld, "CO2 capture from atmospheric air via consecutive CaO-carbonation and CaCO3-calcination cycles in a fluidized-bed solar reactor," *Chemical Engineering Journal*, vol. 146, Feb. 2009, pp. 244–248.
- [127] J. Sunku Prasad, P. Muthukumar, F. Desai, D.N. Basu, and M.M. Rahman, "A critical review of high-temperature reversible thermochemical energy storage systems," *Applied Energy*, vol. 254, Nov. 2019, p. 113733.
- [128] M. Kawamura, S. Ono, and S. Higano, "Experimental studies on the behaviours of hydride heat storage system," *Energy Conversion and Management*, vol. 22, 1982, pp. 95–102.
- [129] M. Kawamura, S. Ono, and Y. Mizuno, "Dynamic characteristics of a hydride heat storage system," *Journal of the Less Common Metals*, vol. 89, 1983, pp. 365–372.

- [130] M. Wierse and M. Groll, "System performance of a solar-thermal power station with thermochemical energy storage," *Fuel and Energy Abstracts*, Elsevier Science, 1997, pp. 167– 167.
- [131] A. Gupta, P.D. Armatis, P. Sabharwall, B.M. Fronk, and V. Utgikar, "Thermodynamics of Ca(OH)2/CaO reversible reaction: Refinement of reaction equilibrium and implications for operation of chemical heat pump," *Chemical Engineering Science*, vol. 230, Feb. 2021, p. 116227.
- [132] J.A.C. Samms and B.E. Evans, "Thermal dissociation of Ca(OH)2 at elevated pressures," *Journal of Applied Chemistry*, vol. 18, May. 1968, pp. 5–8.
- [133] F. Schaube, L. Koch, A. Wörner, and H. Müller-Steinhagen, "A thermodynamic and kinetic study of the de- and rehydration of Ca(OH)2 at high H2O partial pressures for thermo-chemical heat storage," *Thermochimica Acta*, vol. 538, Jun. 2012, pp. 9–20.
- [134] Y.A. Criado, M. Alonso, and J.C. Abanades, "Kinetics of the CaO/Ca(OH) \_2 Hydration/Dehydration Reaction for Thermochemical Energy Storage Applications," *Industrial & Engineering Chemistry Research*, vol. 53, Aug. 2014, pp. 12594–12601.
- [135] I. Barin and G. Platzki, *Thermochemical data of pure substances*, Wiley Online Library, 1989.
- [136] S. Lin, M. Harada, Y. Suzuki, and H. Hatano, "CaO hydration rate at high temperature ( 1023 K)," *Energy & fuels*, vol. 20, 2006, pp. 903–908.
- [137] A.M. Kierzkowska, R. Pacciani, and C.R. Müller, "CaO-Based CO ₂ Sorbents: From Fundamentals to the Development of New, Highly Effective Materials," *ChemSusChem*, vol. 6, Jul. 2013, pp. 1130–1148.
- [138] X.F. Long, L. Dai, B. Lou, and J. Wu, "The kinetics research of thermochemical energy storage system Ca(OH) \_2 /CaO: Kinetics research thermochemical energy storage," *International Journal of Energy Research*, vol. 41, Jun. 2017, pp. 1004–1013.
- [139] S. Lin, M. Harada, Y. Suzuki, and H. Hatano, "CaO Hydration Rate at High Temperature (∼1023 K)," *Energy & Fuels*, vol. 20, May. 2006, pp. 903–908.
- [140] A. Gupta, P.D. Armatis, P. Sabharwall, B.M. Fronk, and V. Utgikar, "Kinetics of Ca(OH)2 decomposition in pure Ca(OH)2 and Ca(OH)2-CaTiO3 composite pellets for application in thermochemical energy storage system," *Chemical Engineering Science*, vol. 246, Dec. 2021, p. 116986.
- [141] Fedunik-Hofman, Bayon, and Donne, "Comparative Kinetic Analysis of CaCO3/CaO Reaction System for Energy Storage and Carbon Capture," *Applied Sciences*, vol. 9, Oct. 2019, p. 4601.
- [142] P. Sun, J.R. Grace, C.J. Lim, and E.J. Anthony, "Determination of intrinsic rate constants of the CaO–CO2 reaction," *Chemical Engineering Science*, vol. 63, Jan. 2008, pp. 47–56.
- [143] H. Gupta and L.-S. Fan, "Carbonation−Calcination Cycle Using High Reactivity Calcium Oxide for Carbon Dioxide Separation from Flue Gas," *Industrial & Engineering Chemistry Research*, vol. 41, Aug. 2002, pp. 4035–4042.
- [144] D. Lee, "An apparent kinetic model for the carbonation of calcium oxide by carbon dioxide," *Chemical Engineering Journal*, vol. 100, Jul. 2004, pp. 71–77.
- [145] A. Gupta, P. Sabharwall, P. Armatis, B. Fronk, and V. Utgikar, "Coupling Chemical Heat Pump with Nuclear Reactor for Temperature Amplification by Delivering Process Heat and Electricity: A Techno-Economic Analysis," *Energies*, vol. 15, Aug. 2022, p. 5873.
- [146] S. Abanades, "Metal oxides applied to thermochemical water-splitting for hydrogen production using concentrated solar energy," *ChemEngineering*, vol. 3, 2019, p. 63.
- [147] B.T. Gorman, N.G. Johnson, J.E. Miller, and E.B. Stechel, "Thermodynamic investigation of concentrating solar power with thermochemical storage," *Energy Sustainability*, American Society of Mechanical Engineers, 2015, p. V001T05A026.

- [148] C. Perozziello, L. Grosu, and B.M. Vaglieco, "Free-piston Stirling engine technologies and models: a review," *Energies*, vol. 14, 2021, p. 7009.
- [149] J. Howes, "Concept and development of a pumped heat electricity storage device," *Proceedings of the IEEE*, vol. 100, 2011, pp. 493–503.
- [150] T. Bi, Z. Wu, L. Zhang, G. Yu, E. Luo, and W. Dai, "Development of a 5 kW traveling-wave thermoacoustic electric generator," *Applied energy*, vol. 185, 2017, pp. 1355–1361.
- [151] K. de Blok, "Aster Thermoacoustics," 2020.
- [152] Internet, "SoundEnergy, Available at:http://soundenergy.nl/," 2019.
- [153] G.A.C. (DLR), "CoBra supports the thermal transition in inustry at: https://www.dlr.de/en/latest/news/2022/03/cobra-supports-the-thermal-transition-in-industry," 2021.
- [154] J. Oehler, A.P. Tran, and P. Stathopoulos, "Simulation of a Safe Start-Up Maneuver for a Brayton Heat Pump," *Turbo Expo: Power for Land, Sea, and Air*, American Society of Mechanical Engineers, 2022, p. V004T06A003.
- [155] P. Vinnemeier, M. Wirsum, D. Malpiece, and R. Bove, "Integration of heat pumps into thermal plants for creation of large-scale electricity storage capacities," *Applied Energy*, vol. 184, 2016, pp. 506–522.
- [156] Z. Mahdi, J. Dersch, P. Schmitz, S. Dieckmann, R.A.C. Caminos, C.T. Boura, U. Herrmann, C. Schwager, M. Schmitz, H. Gielen, and others, "Technical assessment of Brayton cycle heat pumps for the integration in hybrid PV-CSP power plants," *AIP Conference Proceedings*, AIP Publishing, 2022.
- [157] T.R. Davenne and B.M. Peters, "An analysis of pumped thermal energy storage with de-coupled thermal stores," *Frontiers in Energy Research*, vol. 8, 2020, p. 160.
- [158] T. Desrues, J. Ruer, P. Marty, and J.-F. Fourmigué, "A thermal energy storage process for large scale electric applications," *Applied Thermal Engineering*, vol. 30, 2010, pp. 425–432.
- [159] A. White, G. Parks, and C.N. Markides, "Thermodynamic analysis of pumped thermal electricity storage," *Applied Thermal Engineering*, vol. 53, 2013, pp. 291–298.
- [160] J. Guo, L. Cai, J. Chen, and Y. Zhou, "Performance evaluation and parametric choice criteria of a Brayton pumped thermal electricity storage system," *Energy*, vol. 113, 2016, pp. 693–701.
- [161] W.-D. Steinmann, "The CHEST (Compressed Heat Energy STorage) concept for facility scale thermo mechanical energy storage," *Energy*, vol. 69, 2014, pp. 543–552.
- [162] A. Gupta, P.D. Armatis, P. Sabharwall, B.M. Fronk, and V. Utgikar, "Energy and exergy analysis of Ca(OH)2/CaO dehydration-hydration chemical heat pump system: Effect of reaction temperature," *Journal of Energy Storage*, vol. 39, Jul. 2021, p. 102633.
- [163] S.T. Kim, H. Miura, H. Takasu, Y. Kato, A. Shkatulov, and Y. Aristov, "Adapting the MgO-CO2 Working Pair for Thermochemical Energy Storage by Doping with Salts: Effect of the (LiK)NO3 Content," *Energies*, vol. 12, Jun. 2019, p. 2262.
- [164] B. Hu, "Development Of Twin-screw Steam Compressor with Water Sealing," 2022.
- [165] T. Ommen, J.K. Jensen, W.B. Markussen, L. Reinholdt, and B. Elmegaard, "Technical and economic working domains of industrial heat pumps: Part 1–Single stage vapour compression heat pumps," *International Journal of Refrigeration*, vol. 55, 2015, pp. 168–182.
- [166] M. Mercangöz, J. Hemrle, L. Kaufmann, A. Z'Graggen, and C. Ohler, "Electrothermal energy storage with transcritical CO2 cycles," *Energy*, vol. 45, 2012, pp. 407–415.
- [167] J. Horn and P. Scharf, "Design considerations for heat pump compressors," 1976.
- [168] K. Brun and R. Kurz, *Compression machinery for oil and gas*, Gulf Professional Publishing, 2018.

- [169] X. Wang, Y. Hwang, and R. Radermacher, "Investigation of potential benefits of compressor cooling," *Applied thermal engineering*, vol. 28, 2008, pp. 1791–1797.
- [170] M. Yang, B. Wang, X. Li, W. Shi, and L. Zhang, "Evaluation of two-phase suction, liquid injection and two-phase injection for decreasing the discharge temperature of the R32 scroll compressor," *international journal of refrigeration*, vol. 59, 2015, pp. 269–280.
- [171] A. Pearson, "High Pressure Ammonia Systems–New Opportunities," 2010.
- [172] K.J. Chua, S.K. Chou, and W. Yang, "Advances in heat pump systems: A review," *Applied energy*, vol. 87, 2010, pp. 3611–3624.
- [173] B. Deguerce and C. Tersiguel, "Problems encountered and results obtained in the application of compressors in industrial processes for energy saving," *Journal of Heat Recovery Systems*, vol. 2, 1982, pp. 437–441.
- [174] R. Kumar, I. Hussainova, R. Rahmani, and M. Antonov, "Solid lubrication at high-temperatures a review," *Materials*, vol. 15, 2022, p. 1695.
- [175] Internet, "Krytox(TM) Lubricants, Available at:https://miller-stephenson.com/chemicals/krytoxtribosys-finish-line/krytox-lubricants," 2023.
- [176] D. Feng, J. Zhou, W. Liu, and Q. Xue, "The thermal stability and lubricity of zinc thiomolybdenate at temperatures up to 500° C," *Wear*, vol. 246, 2000, pp. 68–73.
- [177] D. Feng, W. Liu, and Q. Xue, "The lubrication mechanism of cerium dithiomolybdate from room temperature to 600° C," *Materials Science and Engineering: A*, vol. 326, 2002, pp. 195–201.
- [178] P. John, S. Prasad, A. Voevodin, and J. Zabinski, "Calcium sulfate as a high temperature solid lubricant," *Wear*, vol. 219, 1998, pp. 155–161.
- [179] H. Gong, C. Yu, L. Zhang, G. Xie, D. Guo, and J. Luo, "Intelligent lubricating materials: A review," *Composites Part B: Engineering*, vol. 202, 2020, p. 108450.
- [180] H. Basir, S. Alaviyoun, and M.A. Rosen, "Thermal Investigation of a Turbocharger Using IR Thermography," *Clean Technologies*, vol. 4, 2022, pp. 329–344.
- [181] N.C. Baines, "Fundamentals of turbocharging," *(No Title)*, 2005.
- [182] J. Sun, Y. Wang, Y. Qin, G. Wang, R. Liu, and Y. Yang, "A Review of Super-High-Temperature Heat Pumps over 100° C," *Energies*, vol. 16, 2023, p. 4591.
- [183] F. Heberle, M. Preißinger, and D. Brüggemann, "Zeotropic mixtures as working fluids in Organic Rankine Cycles for low-enthalpy geothermal resources," *Renewable Energy*, vol. 37, 2012, pp. 364–370.
- [184] A. Vecchi, K. Knobloch, T. Liang, H. Kildahl, A. Sciacovelli, K. Engelbrecht, Y. Li, and Y. Ding, "Carnot Battery development: A review on system performance, applications and commercial state-of-the-art," *Journal of Energy Storage*, vol. 55, 2022, p. 105782.
- [185] S.S. Saravi and S.A. Tassou, "An investigation into sCO2 compressor performance prediction in the supercritical region for power systems," *Energy Procedia*, vol. 161, 2019, pp. 403–411.
- [186] J. Lee, S. Baik, S.K. Cho, J.E. Cha, and J.I. Lee, "Issues in performance measurement of CO2 compressor near the critical point," *Applied Thermal Engineering*, vol. 94, 2016, pp. 111–121.
- [187] D. Reay, "Compact heat exchangers, enhancement and heat pumps," *International Journal of Refrigeration*, vol. 25, 2002, pp. 460–470.
- [188] S. Ishaque, M.I.H. Siddiqui, and M.-H. Kim, "Effect of heat exchanger design on seasonal performance of heat pump systems," *International Journal of Heat and Mass Transfer*, vol. 151, 2020, p. 119404.
- [189] M.-H. Kim, S.Y. Lee, S.S. Mehendale, and R.L. webb, "Microchannel heat exchanger design for evaporator and condenser applications," *Advances in heat transfer*, vol. 37, 2003, pp. 297–430.

- [190] R.B. Keating, S.P. McKillop, T. Allen, and M. Anderson, "ASME boiler and pressure vessel code roadmap for compact heat exchangers in high temperature reactors," *Journal of Nuclear Engineering and Radiation Science*, vol. 6, 2020, p. 041106.
- [191] A.S. Leyzerovich, *Steam turbines for modern fossil-fuel power plants*, Crc Press, 2021.
- [192] ASME, "2007 Boiler and Pressure Vessel Code (with Addenda for 2008) (ASME, New York, 2007), Part II, Sec. D, Subpart 1," 2007.
- [193] J. Martinek, J. Jorgenson, and J.D. McTigue, "On the operational characteristics and economic value of pumped thermal energy storage," *Journal of Energy Storage*, vol. 52, 2022, p. 105005.
- [194] J.I. Linares, A. Martn-Colino, E. Arenas, M.J. Montes, A. Cantizano, and J.R. Pérez-Domnguez, "Carnot Battery Based on Brayton Supercritical CO2 Thermal Machines Using Concentrated Solar Thermal Energy as a Low-Temperature Source," *Energies*, vol. 16, 2023, p. 3871.
- [195] M. Abarr, J. Hertzberg, and L.D. Montoya, "Pumped thermal energy storage and bottoming system part B: sensitivity analysis and baseline performance," *Energy*, vol. 119, 2017, pp. 601– 611.
- [196] V. Novotny, V. Basta, P. Smola, and J. Spale, "Review of carnot battery technology commercial development," *Energies*, vol. 15, 2022, p. 647.
- [197] J. Blanquiceth, J. Cardemil, M. Henrquez, and R. Escobar, "Thermodynamic evaluation of a pumped thermal electricity storage system integrated with large-scale thermal power plants," *Renewable and Sustainable Energy Reviews*, vol. 175, 2023, p. 113134.
- [198] A. Benato, "Performance and cost evaluation of an innovative Pumped Thermal Electricity Storage power system," *Energy*, vol. 138, 2017, pp. 419–436.
- [199] O. Bamigbetan, T.M. Eikevik, P. Nekså, M. Bantle, and C. Schlemminger, "Experimental investigation of a prototype R-600 compressor for high temperature heat pump," *Energy*, vol. 169, 2019, pp. 730–738.
- [200] X. Ma, Y. Zhang, X. Li, H. Zou, N. Deng, J. Nie, X. Yu, S. Dong, and W. Li, "Experimental study for a high efficiency cascade heat pump water heater system using a new near-zeotropic refrigerant mixture," *Applied Thermal Engineering*, vol. 138, 2018, pp. 783–794.
- [201] K. Besbes, A. Zoughaib, F. de Carlan, and J. Peureux, "A R-32 transcritical heat pump for high temperature industrial applications," *Proceedings of the Twenty Fourth IIR International Congress of Refrigeration*, 2015.
- [202] M. Verdnik and R. Rieberer, "Influence of operating parameters on the COP of an R600 hightemperature heat pump," *International Journal of Refrigeration*, vol. 140, 2022, pp. 103–111.
- [203] K.G. Sakellariou, G. Karagiannakis, Y.A. Criado, and A.G. Konstandopoulos, "Calcium oxide based materials for thermochemical heat storage in concentrated solar power plants," *Solar Energy*, vol. 122, Dec. 2015, pp. 215–230.
- [204] W. Liu, B. Feng, Y. Wu, G. Wang, J. Barry, and J.C. Diniz Da Costa, "Synthesis of Sintering-Resistant Sorbents for CO ₂ Capture," *Environmental Science & Technology*, vol. 44, Apr. 2010, pp. 3093–3097.
- [205] Z. Zhou, P. Xu, M. Xie, Z. Cheng, and W. Yuan, "Modeling of the carbonation kinetics of a synthetic CaO-based sorbent," *Chemical Engineering Science*, vol. 95, May. 2013, pp. 283–290.
- [206] R. Koirala, G.K. Reddy, J.-Y. Lee, and P.G. Smirniotis, "Influence of Foreign Metal Dopants on the Durability and Performance of Zr/Ca Sorbents during High Temperature CO2 Capture," *Separation Science and Technology*, vol. 49, Jan. 2014, pp. 47–54.
- [207] J. Yan and C.Y. Zhao, "First-principle study of CaO/Ca(OH)2 thermochemical energy storage system by Li or Mg cation doping," *Chemical Engineering Science*, vol. 117, Sep. 2014, pp. 293– 300.

- [208] Y.A. Criado, M. Alonso, and J.C. Abanades, "Enhancement of a CaO/Ca(OH)2 based material for thermochemical energy storage," *Solar Energy*, vol. 135, Oct. 2016, pp. 800–809.
- [209] C. Roßkopf, S. Afflerbach, M. Schmidt, B. Görtz, T. Kowald, M. Linder, and R. Trettin, "Investigations of nano coated calcium hydroxide cycled in a thermochemical heat storage," *Energy Conversion and Management*, vol. 97, Jun. 2015, pp. 94–102.
- [210] C. Roßkopf, M. Haas, A. Faik, M. Linder, and A. Wörner, "Improving powder bed properties for thermochemical storage by adding nanoparticles," *Energy Conversion and Management*, vol. 86, Oct. 2014, pp. 93–98.
- [211] A. Shkatulov and Y. Aristov, "Modification of magnesium and calcium hydroxides with salts: An efficient way to advanced materials for storage of middle-temperature heat," *Energy*, vol. 85, Jun. 2015, pp. 667–676.
- [212] M. Aihara, T. Nagai, J. Matsushita, Y. Negishi, and H. Ohya, "Development of porous solid reactant for thermal-energy storage and temperature upgrade using carbonation/decarbonation reaction," *Applied Energy*, vol. 69, Jul. 2001, pp. 225–238.
- [213] J. Jiang, B. Hu, R. Wang, N. Deng, F. Cao, and C.-C. Wang, "A review and perspective on industry high-temperature heat pumps," *Renewable and Sustainable Energy Reviews*, vol. 161, 2022, p. 112106.
- [214] S. Dai, Y. Yin, W. Li, and F. Zhang, "Thermodynamic analysis of a novel chemical heat pump cycle based on the physical-chemical thermal effects of reversible reaction," *Energy Conversion and Management*, vol. 225, 2020, p. 113419.
- [215] J. Criado, M. Macias, and A. Macias-Machin, "Analysis of the system CaO CO2 H2O for storage of solar thermal energy," *Solar energy*, vol. 49, 1992, pp. 83–86.
- [216] D.A.G. DAG and W. Ethic, *Introduction to systems engineering*, Citeseer, 2000.
- [217] S. Hirshorn and S. Jefferies, *Final report of the NASA Technology Readiness Assessment (TRA) study team*, 2016.

## **Appendix A. Technical Readiness Level**

To measure or assess the maturity of the UHTHP, a technology readiness level (TRL) level is assigned to each of the explored technologies. It was decided to include this parameter i[n Table 15](#page-73-0) to help determine the level or readiness for short term deployment of the technology [216,217].

| Level | Definition                                                                                        | TRL Description                                                                                                                                                                                                                                                                                                           |
|-------|---------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1     | Basic principles observed<br>and reported                                                         | Lowest level of technology readiness. Scientific research begins to be translated<br>into applied research and development. Examples might include paper studies of a<br>technology's basic properties.                                                                                                                   |
| 2     | Technology concept<br>and/or application<br>formulated.                                           | Invention begins. Once basic principles are observed, practical applications can be<br>invented. Applications are speculative and there may be no proof or detailed<br>analysis to support the assumptions. Examples are limited to analytic studies.                                                                     |
| 3     | Analytical and<br>experimental critical<br>function and/or<br>characteristic proof of<br>concept. | Active research and development is initiated. This includes analytical studies and<br>laboratory studies to physically validate analytical predictions of separate elements<br>of the technology. Examples include components that are not yet integrated or<br>representative.                                           |
| 4     | Component and/or<br>breadboard validation in<br>laboratory environment.                           | Basic technological components are integrated to establish that they will work<br>together. This is relatively "low fidelity" compared to the eventual system.<br>Examples include the integration of "ad hoc" hardware in the laboratory.                                                                                |
| 5     | Component and/or<br>breadboard validation in<br>relevant environment.                             | The Fidelity of breadboard technology increases significantly. The basic<br>technological components are integrated with reasonably realistic supporting<br>elements so it can be tested in a simulated environment.                                                                                                      |
| 6     | System/subsystem model<br>or prototype<br>demonstration in a<br>relevant environment.             | A representative model or prototype system, which is well beyond that of TRL 5, is<br>tested in a relevant environment. Represents a major step up in a technology's<br>demonstrated readiness.                                                                                                                           |
| 7     | System prototype<br>demonstration in an<br>operational environment.                               | Prototype near, or at, planned operational system. Represents a major step up from<br>TRL 6, requiring the demonstration of an actual system prototype in an operational<br>environment such as an aircraft, vehicle, or space.                                                                                           |
| 8     | Actual system completed<br>and qualified through test<br>and demonstration.                       | Technology has been proven to work in its final form and under expected<br>conditions. In almost all cases, this TRL represents the end of true system<br>development. Examples include developmental test and evaluations of the system in<br>its intended weapon system to determine if it meets design specifications. |
| 9     | Actual system has proven<br>through successful<br>mission operations.                             | The actual application of the technology in its final form and under mission<br>conditions, such as those encountered in operational test and evaluation. Examples<br>include using the system under operational mission conditions.                                                                                      |