![](_page_0_Picture_0.jpeg)

![](_page_0_Picture_2.jpeg)

![](_page_0_Picture_3.jpeg)

Energy 30 (2005) 1162–1175

[www.elsevier.com/locate/energy](http://www.elsevier.com/locate/energy)

# Exergy analysis of transcritical carbon dioxide refrigeration cycle with an expander

Jun Lan Yang, Yi Tai Ma\*, Min Xia Li, Hai Qing Guan

Thermal Energy Research Institute of Tianjin University, 300072 Tianjin, People's Republic of China Received 1 June 2003

# Abstract

In this paper, a comparative study is performed for the transcritical carbon dioxide refrigeration cycles with a throttling valve and with an expander, based on the first and second laws of thermodynamics. The effects of evaporating temperature and outlet temperature of gas cooler on the optimal heat rejection pressure, the coefficients of performance (COP), the exergy losses, and the exergy efficiencies are investigated. In order to identify the amounts and locations of irreversibility within the two cycles, exergy analysis is employed to study the thermodynamics process in each component. It is found that in the throttling valve cycle, the largest exergy loss occurs in the throttling valve, about 38% of the total cycle irreversibility. In the expander cycle, the irreversibility mainly comes from the gas cooler and the compressor, approximately 38% and 35%, respectively. The COP and exergy efficiency of the expander cycle are on average 33% and 30% higher than those of the throttling valve cycle, respectively. It is also concluded that an optimal heat rejection pressure can be obtained for all the operating conditions to maximize the COP. The analysis results are of significance to provide theoretical basis for optimization design and operation control of the transcritical carbon dioxide cycle with an expander. q 2004 Elsevier Ltd. All rights reserved.

# 1. Introduction

With growing environmental concerns of global warming and ozone depletion, environmentally benign natural refrigerants have attracted considerable attention. As one of the natural refrigerants, carbon dioxide has many excellent advantages in engineering application, such as no toxicity,

<sup>\*</sup> Corresponding author. Tel.: C86-22-27890627/0061; fax: C86-22-27404741. E-mail address: ytma@tju.edu.cn (Y.T. Ma).

```
Nomenclature
h specific enthalpy (kJ/kg)
q specific refrigeration effect (kJ/kg)
s specific entropy (kJ/kg K)
t temperature (8C)
w actual specific work (kJ/kg)
COP coefficient of performance
I specific irreversibility (kJ/kg)
P pressure (bar)
T temperature (K)
Greek symbol
h exergy efficiency
Subscripts
c gas cooler
com compressor
e evaporator
exp expander
h adiabatic
i component
l loss
o environment
opt optimal
r cold room
rev reversible cycle
s isentropic
tot total
v valve
```

no inflammability, high volumetric capacity with a possibility to make a system compact, lower pressure ratio, better heat transfer properties, complete compatibility with normal lubricants, easy availability, lower price and no recycling problem [\[1,2\]](#page-12-0). However, since the critical temperature of carbon dioxide (31.1 8C) is usually lower than the typical value of the heat rejection temperature of air-conditioning and heat pump systems [\[3\]](#page-12-0), the transcritical vapor compression cycle instead of the conventional vapor compression cycle is applicable for carbon dioxide for water heating and comfort cooling and heating [\[4\].](#page-12-0)

Among other studies, [\[4–6\]](#page-12-0) discussed the use of carbon dioxide in automobile air conditioners, heat pump water heaters and environmental control units, respectively. Also, many researches have been working on the theoretical analysis of transcritical CO2 cycles. Kauf [\[7\]](#page-13-0) presented a graphical method and a simulation model to find the optimal heat rejection pressure for the maximum coefficients of performance (COP). Liao et al. [\[3\]](#page-12-0) developed a correlation of the optimal heat rejection pressure in terms of appropriate parameters. Brown et al. [\[8\]](#page-13-0) and Hwang [\[9\]](#page-13-0) analyzed the performance of the trancritical carbon dioxide cycles. All the above studies indicate that due to a larger energy loss in the throttling valve, the system efficiency of the trancritical carbon dioxide cycles is very low and the total global warming impact is therefore relatively high. Robinson and Groll [\[10\]](#page-13-0) developed two thermodynamic models for the transcritical carbon dioxide cycles with and without an expansion turbine, respectively. The first and second law efficiencies of the two cycles were compared with those of conventional HCFC-22 cycles. It was found that the application of an expansion turbine in place of the throttling valve can reduce the total irreversibility by 35%, and hence increase the system COP over 25%. Zha [\[11\]](#page-13-0) presented that when the expander isentropic efficiency is greater than 11%, the cycle performance with an expander is better than the cycle with an internal exchanger. Meanwhile, various expander prototypes have been developed for the experimental test.

From the viewpoint of the first law, COP is a typical criterion to evaluate the refrigeration system. However, according to the second law point of view, exergy analysis is also usually applied. Based on exergy analysis, Yumrutas [\[12\]](#page-13-0) developed a computational model to investigate an ammonia vapor compression refrigeration system. Chen and Prasad [\[13\]](#page-13-0) employed both COP and exergy loss to analyze HFC134a and CFC12 vapor compression refrigeration cycles. In reality, the exergy analysis has become an important method in the study of refrigeration and heat pump systems [\[14–17\],](#page-13-0) but it is hardly employed to evaluate the performance of transcritical carbon dioxide cycle. In this paper, a comparative study is performed for the transcritical carbon dioxide refrigeration cycles with a throttling valve and with an expander, based on the first and second laws of thermodynamics. Effects of evaporating temperature and outlet temperature of gas cooler on the COP, exergy loss, and exergy efficiency are also investigated.

# 2. Background

A typical transcritical carbon dioxide refrigeration cycle consists of a compressor, a gas cooler, an evaporator and an expansion device, which in this study is either a throttling valve or an expander. The working fluid from suction line at state 1 enters the compressor. The high-pressure vapor leaves the compressor at state 2 and enters the gas cooler. At state 3, the cooled CO2 refrigerant enters the expansion device (the expander in this case), and then expands to the evaporator pressure at state 4. After absorbing heat from the cold space in the evaporator, the refrigerant re-enters the compressor at state 1. The schematic diagram is shown in Fig. 1 and the corresponding T–s (temperature–entropy) diagram is

![](_page_2_Figure_6.jpeg)

Fig. 1. Schematic diagram of transcritical CO2 cycle with an expander.

![](_page_3_Figure_2.jpeg)

Fig. 2. T-s diagram of the transcritical CO<sub>2</sub> cycles.

illustrated in Fig. 2. In the T-s diagram, the line 1- $2_s$ -3- $4_s$ -1 shows the ideal refrigeration cycle with an expander, the 1-2-3-4-1 represents the actual refrigeration cycle with an expander and the 1-2-3- $4_h$ -1 shows the actual refrigeration cycle with a throttling valve.

The coefficient of performance (COP<sub>v</sub>) of transcritical CO<sub>2</sub> cycle with a throttling valve is defined as

$$COP_{v} = \frac{q_{v}}{w_{v}} = \frac{(h_{1} - h_{4h})}{(h_{2} - h_{1})}$$
(1)

where  $q_v$  represents the specific refrigeration effect,  $w_v$ , the specific compression work, and  $h_1$ ,  $h_2$ ,  $h_{4h}$  denote the specific enthalpies of  $CO_2$  at the corresponding points, respectively, as shown in Fig. 2.

The coefficient of performance (COP<sub>exp</sub>) of transcritical CO<sub>2</sub> cycle with an expander is defined as

$$COP_{exp} = \frac{q_{exp}}{w_{exp}} = \frac{(h_1 - h_4)}{(h_2 - h_1) - (h_3 - h_4)}$$
 (2)

where  $q_{\rm exp}$  represents the specific refrigeration effect,  $w_{\rm exp}$ , the specific compression work, and  $h_1$ ,  $h_2$ ,  $h_3$ ,  $h_4$  denote the specific enthalpies of CO<sub>2</sub> at the corresponding points, respectively, as shown in Fig. 2.

The exergy efficiency for the transcritical CO<sub>2</sub> refrigeration cycle can be defined as the ratio of the minimum work requirement to the actual work input [12]

$$\eta = \frac{w_{\text{rev}}}{w} = \frac{w_{\text{rev}}}{w_{\text{rev}} + w_{\text{l}}} = 1 - \frac{w_{\text{l}}}{w}$$
 (3)

where  $w_{rev}$  and w are the work inputs to a reversible and an actual refrigeration cycle, respectively, and  $w_1$  is the lost work or the total exergy loss.

#### 3. Exergy analysis

In reality, the refrigeration cycle includes various irreversible processes. Exergy or availability of a system at given state represents its maximum work potential. Therefore, the exergy loss provides a very important criterion to evaluate the thermodynamic performance of a system [13]. By analyzing the irreversibility of the system, it can be known how the actual cycle departures from the ideal cycle.

Exergy analysis is usually aimed to determine the maximum performance of the system and identify the locations of exergy destruction and to show the direction for potential improvements [\[12\].](#page-13-0)

The exergy loss is calculated by making exergy balance for each component of the system. In the following, the exergy loss analysis for the actual transcritical CO2 cycles with a throttling valve (1–2–3–4h–1) and with an expander (1–2–3–4–1) will be presented. The assumptions in the study are given as follows:

- (1) Steady state operation,
- (2) Negligible pressure drop,
- (3) Adiabatic compressor and expander,
- (4) Saturated state at the evaporator outlet.

# 3.1. Exergy loss analysis for throttling valve cycle

Exergy loss computation equations for compressor, gas cooler, throttling valve and evaporator are as follows

$$I_{\text{vcom}} = T_{\text{o}}(s_2 - s_1) \tag{4}$$

$$I_{\rm vc} = h_2 - h_3 - T_{\rm o}(s_2 - s_3) \tag{5}$$

$$I_{vv} = T_o(s_{4h} - s_3) \tag{6}$$

$$I_{\text{ve}} = T_{\text{o}}(s_1 - s_{4h}) + (h_{4h} - h_1) \times T_{\text{o}}/T_{\text{r}}$$
(7)

$$I_{\text{vtot}} = I_{\text{vcom}} + I_{\text{vc}} + I_{\text{vv}} + I_{\text{ve}} \tag{8}$$

# 3.2. Exergy loss analysis for expander cycle

Exergy loss equations for compressor, gas cooler, expander and evaporator are given as follows

$$I_{\text{com}} = T_{\text{o}}(s_2 - s_1) \tag{9}$$

$$I_{c} = h_{2} - h_{3} - T_{o}(s_{2} - s_{3})$$

$$\tag{10}$$

$$I_{\rm exp} = T_{\rm o}(s_4 - s_3) \tag{11}$$

$$I_{\rm e} = T_{\rm o}(s_1 - s_4) + (h_4 - h_1) \times T_{\rm o}/T_{\rm r}$$
(12)

$$I_{\text{tot}} = I_{\text{com}} + I_{\text{c}} + I_{\text{exp}} + I_{\text{e}} \tag{13}$$

The percentage of the exergy loss in each component can be calculated and expressed as the ratio of the partial exergy loss to the total exergy loss.

#### 3.3. Parameters determination and assumption

The transcritical CO<sub>2</sub> cycles are simulated within a wide range of operation conditions. The assumptions are given as follows:

- (1) The isentropic efficiency of the compressor and expander are taken to be 75 and 65% [11], respectively,
- (2) The outlet temperature of gas cooler:  $32 \,^{\circ}\text{C} \le t_3 \le 50 \,^{\circ}\text{C}$ ,
- (3) The evaporating temperature:  $-25 \,^{\circ}\text{C} \le t_e \le 20 \,^{\circ}\text{C}$ ,
- (4) The environment temperature:  $T_0 = 303 \text{ K}$ ,
- (5) The refrigerated object temperature:  $-20 \,^{\circ}\text{C} \le T_r \le 25 \,^{\circ}\text{C}$ .

Based on the above analysis, a steady state simulation program for the transcritical CO<sub>2</sub> cycles using EES software [18] is developed.

#### 4. Results and discussion

#### 4.1. Optimal heat rejection pressures

The presented studies [3,7,10] indicate that an optimal heat rejection pressure exists in carbon dioxide throttling valve and expander cycle, and consequently a maximum COP can be obtained for the given conditions. Fig. 3 gives the optimal heat rejection pressures of the two cycles versus evaporation temperature for the outlet temperature of the gas cooler  $t_3$ =40 °C. It is seen that the optimal heat rejection pressure is decreased with the increase of evaporating temperature. Fig. 4 gives the relationship between the optimal heat rejection pressures of the two cycles and the outlet temperature of the gas cooler for evaporation temperature  $t_e$ =5 °C. The optimal heat rejection pressure is increased nearly linearly with the outlet temperature of the gas cooler. From Figs. 3 and 4, it also can be found that the throttling valve cycle has the higher optimal heat rejection pressures.

![](_page_5_Figure_13.jpeg)

Fig. 3. Optimal heat rejection pressures versus evaporating temperature.

<span id="page-6-0"></span>![](_page_6_Figure_2.jpeg)

Fig. 4. Optimal heat rejection pressures versus the outlet temperature of the gas cooler.

# 4.2. Effects of evaporating temperature on the performance of the two cycles

Fig. 5 presents the COP value of the two cycles versus the evaporating temperature for the outlet temperature of the gas cooler t3Z40 8C and at the optimal heat rejection pressure. The COP value of the expander cycle is on average 34% higher than that of the throttling valve cycle.

[Fig. 6](#page-7-0) shows the percentage of exergy loss in each component of the transcritical CO2 cycle with a throttling valve corresponding to various evaporating temperature for the outlet temperature of the gas cooler t3Z40 8C and at the optimal heat rejection pressure. It is found that the largest exergy loss occurs in the throttling valve, about 38% of the total exergy loss. The exergy losses of gas cooler and compressor are in the second and the third place, about 32 and 25%, respectively. The evaporator accounts for about 5% of the cycle total exergy loss. [Fig. 7](#page-7-0) shows the percentage of exergy loss in each component of the transcritical CO2 cycle with an expander at various evaporating temperature for the outlet temperature of the gas cooler t3Z40 8C and at the optimal heat rejection pressure. The gas cooler

![](_page_6_Figure_7.jpeg)

Fig. 5. Two cycles COP versus evaporating temperature.

<span id="page-7-0"></span>![](_page_7_Figure_2.jpeg)

Fig. 6. Component exergy loss as percentage of throttling valve cycle loss versus te.

and the compressor account for approximately 40 and 34% of the total cycle irreversibility, respectively. The percentage of exergy loss in the expander is only about 19%, almost 50% of the throttling valve exergy loss. The evaporator accounts for about 7% of the cycle total exergy loss. As shown in Figs. 6 and 7, the exergy loss percentage of each component in the two cycles changes slightly with the evaporating temperature.

[Fig. 8](#page-8-0) shows exergy efficiencies of the two cycles for different evaporating temperatures. The exergy efficiency of the carbon dioxide expander cycle is on average 34% higher than that of the throttling valve cycle. Therefore, it is also clear that the application of an expander can effectively recover work and while transfer it to the compressor, and as a result greatly improve the system efficiency. In addition, it is found that the two cycles' exergy efficiencies are decreased and tend to close with increasing evaporating temperature.

In order to detect the absolute irreversibility in each component of the two cycles, [Figs. 9 and 10](#page-8-0) indicate their change trends with the evaporating temperature. It can be seen that all the exergy losses in the system components drop with the increasing evaporating temperature. And the legends in [Figs. 9 and 10](#page-8-0) show

![](_page_7_Figure_7.jpeg)

Fig. 7. Component exergy loss as percentage of expander cycle loss versus te.

<span id="page-8-0"></span>![](_page_8_Figure_2.jpeg)

Fig. 8. Exergy efficiencies of the two cycles versus evaporating temperature.

![](_page_8_Figure_4.jpeg)

Fig. 9. Component exergy loss of throttling valve cycle versus te.

![](_page_8_Figure_6.jpeg)

Fig. 10. Component exergy loss of expander cycle versus te.

![](_page_9_Figure_2.jpeg)

Fig. 11. Two cycles COP versus the outlet temperature of the gas cooler.

the descending order of their exergy losses. In addition, the component irreversibility in the throttling valve cycle is greater than that of the corresponding component in the expander cycle except for the evaporator.

# 4.3. Effects of the outlet temperature of the gas cooler t3

Fig. 11 presents COP values of the two cycles versus the outlet temperature of the gas cooler for evaporating temperature teZ5 8C and at the optimal heat rejection pressure. It can be seen that the COP value of the expander cycle is on average 32% higher than that of the throttling valve cycle.

Fig. 12 shows the effect of the outlet temperature of the gas cooler for teZ5 8C on the exergy loss percentage of each component for the throttling valve cycle. It is found that the exergy loss percentage of the throttling valve varies slightly with t3, on average about 38% of the total cycle irreversibility. The exergy loss percentage of the gas cooler is increased significantly, from 20 to 36.7%. The exergy loss

![](_page_9_Figure_8.jpeg)

Fig. 12. Component exergy loss as percentage of throttling valve cycle loss versus t3.

![](_page_10_Figure_2.jpeg)

Fig. 13. Component exergy loss as percentage of expander cycle loss versus t3.

percentage of the compressor drops from 31.1 to 22.7% and that in the evaporator is decreased from 9.6 to 3.4% with the increase of t3. Fig. 13 shows the percentage of exergy loss in each component of expander cycle versus the outlet temperature of the gas cooler for evaporating temperature teZ5 8C. As can be seen from Fig. 13, the irreversibility losses in the gas cooler and the compressor change greatly in the reverse trend, with the former rising from 24.4 to 45.3% and the latter dropping from 42.4 to 31%. The expander produces the second lowest percentage of cycle exergy loss, varying slightly from 19.7 to 18.7% with the increase in t3. The evaporator accounts for about 8% of the cycle total exergy loss.

The exergy efficiencies of the two cycles at different outlet temperature of the gas cooler are shown in Fig. 14. The exergy efficiency of the carbon dioxide expander cycle is on average 32% higher than that of the throttling valve cycle. In addition, the two cycles' exergy efficiencies are decreased with the increase in outlet temperature of the gas cooler.

The analysis presented in [Figs. 9 and 10](#page-8-0) is repeated in [Figs. 15 and 16](#page-11-0) by varying the outlet temperature of the gas cooler. The exergy loss in each component except the evaporator increases with

![](_page_10_Figure_7.jpeg)

Fig. 14. Exergy efficiencies of the two cycles versus the outlet temperature of the gas cooler.

<span id="page-11-0"></span>![](_page_11_Figure_2.jpeg)

Fig. 15. Component exergy loss of throttling valve cycle versus t3.

the increasing outlet temperature of the gas cooler. In the two figures, when t<sup>3</sup> is lower, the exergy loss in the compressor is greater than that in the gas cooler. When t<sup>3</sup> is higher, the descending order of component exergy loss can be seen from the legends in the two figures. Also, the component irreversibility in the throttling valve cycle is greater than that of the corresponding component in the expander cycle except for the evaporator.

In [Table 1](#page-12-0), a comparison of exergy loss in the two cycles at given teZ5 8C and t3Z40 8C is shown. It can be seen that the total exergy loss in the expander cycle is smaller than that in the throttling valve cycle with the difference of 11.475 kJ/kg. Among this, there is about 9.457 kJ/kg decrement in the expansion process, 1.62 and 0.423 kJ/kg reduction in the gas cooler and the compressor, respectively, and there is also 0.025 kJ/kg increment in the evaporator. It is obvious that almost 82.4% of the total exergy loss decrement comes from the expansion process by replacing the throttling valve with the expander. The distribution of the exergy loss in the system components reveals the influence of the irreversibility of each component on the overall system efficiency.

![](_page_11_Figure_6.jpeg)

Fig. 16. Component exergy loss of expander cycle versus t3.

<span id="page-12-0"></span>Table 1 Exergy loss of two cycles for teZ5 8C and t3Z40 8C

| Component         | Exergy loss of expander cycle (kJ/kg) | Exergy loss of throttling valve cycle (kJ/kg) |
|-------------------|---------------------------------------|-----------------------------------------------|
| Compressor        | 9.827                                 | 10.25                                         |
| Gas cooler        | 10.85                                 | 12.47                                         |
| Expansion device  | 5.233                                 | 14.69                                         |
| Evaporator        | 2.178                                 | 2.153                                         |
| Total exergy loss | 28.088                                | 39.563                                        |

### 5. Conclusions

A comparative study based on the first and second laws of thermodynamics is performed for the transcritical carbon dioxide refrigeration cycles with a throttling valve and with an expander. The conclusions are given as follows.

- (1) At given conditions, the throttling valve cycle has the higher optimal heat rejection pressure compared to the expander cycle.
- (2) In the transcritical carbon dioxide refrigeration cycles with a throttling valve and with an expander, the evaporating temperature and the outlet temperature of the gas cooler have different influences on the optimal heat rejection pressure, the COP, the exergy losses, and the exergy efficiencies.
- (3) In the throttling valve cycle, the largest exergy loss arises in the throttling valve. With the application of the expander, the irreversibility loss of the expansion process is reduced almost by 50%, and as a result the exergy efficiency can be increased greatly. Therefore, a high efficiency expander is very important to improve the performance of the transcritical CO2 cycle.
- (4) In the expander cycle, the main exergy losses occur in the gas cooler and the compressor. Therefore, the optimization in the gas cooler structure and improvement in the compressor efficiency are indispensable.

### Acknowledgements

The authors acknowledge the support by the Specialized Research Fund for the Doctoral Program of Higher Education under Grant D0200105.

### References

- [1] Lorentzen G. Revival of carbon dioxide as a refrigerant. Int J Refrig 1994;17(5):292–301.
- [2] Lorentzen G. The use of natural refrigerants: a complete solution to the CFC/HCFC predicament. Int J Refrig 1995;18(3): 190–7.
- [3] Liao SM, Zhao TS, Jakobsen A. A correlation of optimal heat rejection pressures in transcritical carbon dioxide cycles. Appl Therm Eng 2000;20(9):831–41.
- [4] Lorentzen G, Pettersen J. A new, efficient and environmentally benign system for car air conditioning. Int J Refrig 1993; 16(1):4–12.

- <span id="page-13-0"></span>[5] Neksa˚ P, Rekstad H, Zakeri GR, Schiefloe PA. CO2-heat pump water heater: characteristics, system design and experimental results. Int J Refrig 1998;21(3):172–9.
- [6] Li DQ, Robinson DM, Groll EA. Performance of a carbon dioxide-based environmental control unit for US army. In: Groll EA, Robinson DM, editors. The Fourth IIR-Gustav Lorentzen conference on natural working fluids. Indiana, West Lafayette: Purdue University; 2000. p. 123–31.
- [7] Kauf F. Determination of the optimum high pressure for transcritical CO2-refrigeration cycles. Int J Therm Sci 1999; 38(4):325–30.
- [8] Brown JS, Yana-Motta SF, Domanski PA. Comparitive analysis of an automotive air conditioning systems operating with CO2 and R134a. Int J Refrig 2002;25(1):19–32.
- [9] Hwang Y. Comprehensive investigation of carbon dioxide refrigeration cycle. PhD dissertation, University of Maryland; 1996.
- [10] Robinson DM, Groll EA. Efficiencies of transcritical CO2 cycles with and without an expansion turbine. Int J Refrig 1998; 21(7):577–89.
- [11] Zha ST. Study and development of CO2 transcritical expander [in Chinese]. PhD Dissertation, University of Tianjin, China; 2002.
- [12] Yumrutas R, Kunduz M, Kanoglu M. Exergy analysis of vapor compression refrigeration systems. Exergy 2002;2(4): 266–72.
- [13] Chen QY, Prasad RC. Simulation of a vapour-compression refrigeration cycles using HFC134a and CFC12. Int Commun Heat Mass Transfer 1999;26(4):513–21.
- [14] Chen J, Chen X, Wu C. Optimization of the rate of exergy output of a multistage endoreversible combined refrigeration system. Exergy 2001;1(2):100–6.
- [15] Torres-Reyes E, Cervantes De Gortari J. Optimal performance of an irreversible solar assisted heat pump. Exergy 2001; 1(2):107–11.
- [16] Krakow KI. Relationships between irreversibility, exergy destruction and entropy generation for systems and components. ASHRAE Trans 1994;100(1):3–10.
- [17] Yaqub M, Zubair SM, Khan SH. Second-law-based thermodynamic analysis of hot-gas by-pass, capacity-control schemes for refrigeration and air-conditioning systems. Energy 1995;20(6):483–93.
- [18] Klein S, Alvarado F. Engineering equation solver. Middleton, WI: F-chart software; 1996.