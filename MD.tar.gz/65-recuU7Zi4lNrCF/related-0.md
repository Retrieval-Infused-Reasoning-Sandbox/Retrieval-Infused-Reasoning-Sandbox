![](_page_0_Picture_2.jpeg)

# Annex 58

**High-Temperature Heat Pumps** 

Task 1 – Technologies

**Task Report** 

Operating Agent: Benjamin Zühlsdorf, PhD Danish Technological Institute August 2023 Report no. HPT-AN58-2

**Published by** Heat Pump Centre

c/o RISE – Research Institutes of Sweden

Box 857, SE-501 15 Borås

Sweden

Phone +46 10 16 53 42

**Website** [https://heatpumpingtechnologies.org](https://heatpumpingtechnologies.org/)

**Legal Notice** Neither the Heat Pump Centre nor any person acting on its behalf:

(a) makes any warranty or representation, express or implied, with respect to the information contained in this report; or (b) assumes liabilities with respect to the use of, or damages,

resulting from, the use of this information.

Reference herein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise, does not necessarily constitute or imply its endorsement recommendation or favouring.

The views and opinions of authors expressed herein do not necessarily state or reflect those of the Heat Pump Centre, or any of its employees. The information herein is presented in the authors' own words.

**© Heat Pump Centre** All rights reserved. No part of this publication may be reproduced, stored in a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise, without prior permission of the Heat Pump Centre, Borås, Sweden. — except that Participants in the Technology Collaboration Programme on Heat Pumping Technologies may reproduce and distribute this material provided it is not used with a view to profit.

**Production** Heat Pump Centre, Borås, Sweden

ISBN 978-91-89821-34-7 Report No. HPT-AN58-2

## <span id="page-4-0"></span>**Preface**

This project was carried out within the Technology Collaboration Programme on Heat Pumping Technologies (HPT TCP), which is a Technology Collaboration Programme within the International Energy Agency, IEA.

## **The IEA**

The IEA was established in 1974 within the framework of the Organization for Economic Cooperation and Development (OECD) to implement an International Energy Programme. A basic aim of the IEA is to foster cooperation among the IEA participating countries to increase energy security through energy conservation, development of alternative energy sources, new energy technology and research and development (R&D). This is achieved, in part, through a programme of energy technology and R&D collaboration, currently within the framework of nearly 40 Technology Collaboration Programmes.

## **The Technology Collaboration Programme on Heat Pumping Technologies (HPT TCP)**

The Technology Collaboration Programme on Heat Pumping Technologies (HPT TCP) forms the legal basis for the implementing agreement for a programme of research, development, demonstration and promotion of heat pumping technologies. Signatories of the TCP are either governments or organizations designated by their respective governments to conduct programmes in the field of energy conservation.

Under the TCP, collaborative tasks, or "Annexes", in the field of heat pumps are undertaken. These tasks are conducted on a cost-sharing and/or task-sharing basis by the participating countries. An Annex is in general coordinated by one country which acts as the Operating Agent (manager). Annexes have specific topics and work plans and operate for a specified period, usually several years. The objectives vary from information exchange to the development and implementation of technology. This report presents the results of one Annex.

The Programme is governed by an Executive Committee, which monitors existing projects and identifies new areas where collaborative effort may be beneficial.

## **Disclaimer**

The HPT TCP is part of a network of autonomous collaborative partnerships focused on a wide range of energy technologies known as Technology Collaboration Programmes or TCPs. The TCPs are organised under the auspices of the International Energy Agency (IEA), but the TCPs are functionally and legally autonomous. Views, findings and publications of the HPT TCP do not necessarily represent the views or policies of the IEA Secretariat or its individual member countries.

This report has been produced within HPT Annex 58. Views and findings in this report do not necessarily represent the views or policies of the HPT TCP and its individual member countries.

#### **The Heat Pump Centre**

A central role within the HPT TCP is played by the Heat Pump Centre (HPC).

Consistent with the overall objective of the HPT TCP, the HPC seeks to accelerate the implementation of heat pump technologies and thereby optimise the use of energy resources for the benefit of the environment. This is achieved by offering a worldwide information service to support all those who can play a part in the implementation of heat pumping technology including researchers, engineers, manufacturers, installers, equipment users, and energy policy makers in utilities, government offices and other organisations. Activities of the HPC include the production of a Magazine with an additional newsletter 3 times per year, the HPT TCP webpage, the organization of workshops, an inquiry service and a promotion programme. The HPC also publishes selected results from other Annexes, and this publication is one result of this activity.

For further information about the Technology Collaboration Programme on Heat Pumping Technologies (HPT TCP) and for inquiries on heat pump issues in general contact the Heat Pump Centre at the following address:

Heat Pump Centre

c/o RISE - Research Institutes of Sweden Box 857, SE-501 15 BORÅS, Sweden

Phone: +46 10 516 53 42

Website: [https://heatpumpingtechnologies.org](https://heatpumpingtechnologies.org/)

## <span id="page-5-0"></span>**Operating Agent**

Annex 58 about High-Temperature Heat Pumps is coordinated by the Operating Agent:

Benjamin Zühlsdorf, PhD, [bez@dti.dk](mailto:bez@dti.dk) Danish Technological Institute, Energy and Climate

The Annex is being operated from 01/2020 to 12/2023. The main information can be found at the Annex 58 homepage:<https://heatpumpingtechnologies.org/annex58/>

## <span id="page-5-1"></span>**Participating countries of Annex 58**

There is a high number of countries participating in Annex 58, while each country is represented by a national team consisting of a number of organizations. The following countries are formally participating in Annex:

- Austria
- Belgium
- Canada
- China
- Denmark
- Finland
- France
- Germany
- Japan
- Netherlands
- Norway
- South Korea
- Switzerland
- USA

A presentation of all national teams can be found on the Annex 58 homepage.

## <span id="page-6-1"></span>**Authors of the report and contributors to Task 1**

The report has been prepared as a collaborative effort with contributions from various authors and has been coordinated by the main author Benjamin Zühlsdorf. An overview of the contributors is shown in [Table 0-1.](#page-6-0)

<span id="page-6-0"></span>Table 0-1: Overview of authors of the report, sorted by organization and country.

| Name                            | Role/Title                              | Organization &<br>Country                 | Contact information (E-mail)                   |
|---------------------------------|-----------------------------------------|-------------------------------------------|------------------------------------------------|
| Benjamin Zühlsdorf              | Centre Project<br>Manager, PhD          | DTI, Denmark                              | bez@teknologisk.dk                             |
| Jonas Lundsted Poulsen          | Senior Specialist                       | DTI, Denmark                              | jlp@teknologisk.dk                             |
| Sabrina Dusek                   | Research Engineer                       | AIT, Austria                              | Sabrina.Dusek@ait.ac.at                        |
| Veronika Wilk                   | Senior<br>Research<br>Engineer          | AIT, Austria                              | Veronika.Wilk@ait.ac.at                        |
| Johannes Krämer                 | Research Engineer                       | AIT, Austria                              | johannes.kraemer@ait.ac.at                     |
| René Rieberer                   | Professor                               | TU Graz, Austria                          | rene.rieberer@tugraz.at                        |
| Manuel Verdnik                  | PhD student                             | TU Graz, Austria                          | manuel.verdnik@tugraz.at                       |
| Toon Demeester                  | Postdoctoral<br>researcher              | Belgium                                   | toon.demeester@ugent.be                        |
| Elias Vieren                    | PhD student                             | Belgium                                   | elias.vieren@ugent.be                          |
| Chiara Magni                    | PhD student                             | Belgium                                   | chiara.magni@kuleuven.be                       |
| Hamed Abedini                   | Postdoctoral<br>researcher              | Belgium                                   | hamed.abedini@kuleuven.be                      |
| Chantal Leroy                   | Manager                                 | Natural<br>Resources<br>Canada,<br>Canada | chantal.leroy@nrcan-rncan.gc.ca                |
| Luwei Yang                      | Professor                               | TIPC-CAS,<br>China                        | lwyang2002@mail.ipc.ac.cn                      |
| Martin Pihl Andersen            | PhD Student                             | DTU, Denmark                              | mapian@dtu.dk                                  |
| Brian Elmegaard                 | Professor                               | DTU, Denmark                              | brel@dtu.dk                                    |
| Teemu Turunen-Saaresti          | Professor                               | Finland                                   | teemu.turunen-saaresti@lut.fi                  |
| Antti Uusitalo                  | Assoc. professor                        | Finland                                   | antti.uusitalo@lut.fi                          |
| Florence De Carlan              | Research Engineer                       | EDF, France                               | Florence.de-carlan@edf.fr                      |
| Clément Gachot                  | Project manager                         | EDF, France                               | clement.gachot@edf.fr                          |
| Florian Schlosser               | Postdoctoral<br>researcher              | Paderborn<br>University,<br>Germany       | florian.schlosser@uni<br>paderborn.de          |
| Steffen Klöppel                 | Research Engineer                       | DLR, Germany                              | Steffen.Kloeppel@dlr.de                        |
| Omar Abu Khass                  | Research Engineer                       | DLR, Germany                              | Omar.AbuKhass@dlr.de                           |
| Robert Schaffrath               | Research Engineer                       | DLR, Germany                              | Robert.Schaffrath@dlr.de                       |
| Ursula Wittstadt                | Research Engineer                       | Fraunhofer ISE,<br>Germany                | Ursula.wittstadt@ise.fraunhofer.d<br>e         |
| Stefan Henninger                | Research Engineer                       | Fraunhofer ISE,<br>Germany                | Stefan.henninger@ise.fraunhofer.<br>de         |
| Hannah Teles de Oliveira        | Research Engineer                       | Fraunhofer ISE,<br>Germany                | Hannah.teles.de.oliveira@ise.frau<br>nhofer.de |
| Takenobu Kaida                  | Research Engineer                       | CRIEPI, Japan                             | kaida@criepi.denken.or.jp                      |
| Miguel Ramirez                  | Research Engineer                       | Netherlands                               | miguel.ramirez@tno.nl                          |
| Jan-Aiso Lycklama a<br>Nijeholt | Project Manager                         | Netherlands                               | jan-aiso.lycklamaanijeholt@tno.nl              |
| Christian Schlemminger          | Research Scientist /<br>PhD             | Norway                                    | christian.schlemminger@sintef.no               |
| Ole Marius Moen                 | Research Scientist                      | Norway                                    | ole.moen@sintef.no                             |
| Gilbong Lee                     | Research Engineer                       | South Korea                               | giblee@kier.re.kr                              |
| Cordin Arpagaus                 | Senior Research<br>Eng., Dr. sc. techn. | OST,<br>Switzerland                       | cordin.arpagaus@ost.ch                         |

## <span id="page-7-0"></span>**Foreword**

This report has been compiled as part of the IEA HPT Annex 58 about High-Temperature Heat Pumps (HTHP). The Annex is structured into the following 5 tasks:

- Task 1: Technologies State of the art and ongoing developments for systems and components
- Task 2: Integration Concepts Development of best practice integration concepts for promising application cases
- Task 3: Applications and Transition Strategies for the conversion to HTHP-based process heat supply
- Task 4: Definition and testing of HP specifications Recommendations for defining and testing of specifications for high-temperature heat pumps in commercial projects
- Task 5: Dissemination

The overall objective of the Annex is to provide an overview of the technological possibilities and applications as well as to develop best practice recommendations and strategies for the transition towards heat pump-based process heat supply. The intention is to improve the understanding of the technology's potential among various stakeholders, such as manufacturers, potential end-users, consultants, energy planners, and policy makers. In addition, the Annex aims to provide supporting material to facilitate and enhance the transition to a heat pump-based process heat supply for industrial applications.

This will be achieved by the following sub-objectives:

- Provide an overview of the technology, including the most relevant systems and components that are commercially available and under development (Task 1).
- Identify technological bottlenecks and clarify the need for technical developments regarding components, working fluids, and system design (Task 1).
- Present best practice system solutions for a range of applications to underline the potential of HTHPs (Task 2).
- Present strategies for the transition to heat-pump-based process heat supply (Task 3).
- Enhance the information basis about industrial heat pumps, potential applications, and potential contribution to the decarbonization of the industry (Task 1, 2 & 3).
- Develop guidelines for handling industrial heat pump projects with a focus on the HP specifications and the testing of these specifications (Task 4).
- Disseminate the findings to various stakeholders and add to the knowledge base for energy planners and policy makers (Task 5).

Annex 58 focuses on HTHPs, which are heat pumps that supply a relevant share of their main product at temperatures above 100 °C. In this context, the focus is on developing, summarizing, and communicating information about the most relevant technologies and applications rather than covering all technologies. The relevance was mainly determined by the various participants and indirectly given by the technologies' application potential and market perspectives. Therefore, the Annex is primarily focused on applications for industrial heat supply but will not specifically be limited to these applications.

This report documents the work of Task 1 – Technologies. Chapter 1 provides an introduction to the topic of high-temperature heat pumps, basic definitions and principles, and an overview of promising applications. Chapter 2 provides an overview of HTHP technologies that are commercially available or under development and expected to be demonstrated in industry within the next years. The technology review is based on and supplemented by various information schemes that technology suppliers provided. In Chapter 3, the participating countries summarized the national HTHP markets and technology perspectives. Finally, this information was condensed to an overall outlook of the technology development perspectives in Chapter 5.

## <span id="page-8-0"></span>**Executive Summary**

Industries are using a considerable share of their final energy consumption on process heating, which is often based on fossil fuels and accordingly accounting for a large share of their greenhouse gas emissions. Decarbonizing the process heating by electrification and energy efficiency is a top priority for industries with respect to reaching their climate ambitions towards 2030 and beyond. Industrial heat pumps can provide industrial process heating, based on potentially emission free electricity and at highest efficiencies, which is making them a key technology for decarbonizing industrial process heating. For heat supply temperatures below 100 °C, they are already a well proven technology and being implemented in industries. With fuel prices and carbon taxes that are becoming more beneficial for industrial heat pumps, their range of application as the preferred technology is emerging to temperatures well above 100 °C. For the large share of process heat requirements above 100 °C, there is currently a limited number of technologies available, while various technologies are under development.

Enabling a large variety of industries to convert their process heat supply to high-temperature heat pumps with supply temperatures above 100 °C requires a common understanding of the technology, its potentials and its perspectives for a variety of stakeholders. This report aims at supporting the overall development of high-temperature heat pumps by providing an overview of the current state of the art and future perspectives towards 2030 on a global level.

The first section provides an overview of the terminology and the basic working principles of hightemperature heat pumps. Subsequently, an overview of high-temperature heat pump technologies with supply temperatures above 100 °C is presented, considering market ready technologies as well as technologies under development. The comprehensive overview is based on a systematic description of 34 technologies, including information about the technology such as the general layout, the development status and perspectives, expected performances for various application examples, compressor type, working fluid, capacity and temperature range, investment cost, footprint and weight. The reviewed solutions covered technologies with a technology readiness level between 4 to 9, specific investment cost between 200 €/kW to 1500 €/kW, capacities between 30 kW to 70 MW and maximum supply temperature between 100 °C and 280 °C. It must be noted that the development status for a given temperature and capacity is not only depending on the technology readiness level, but also on achievable efficiencies, the cost of the technology and the geographical availability of a sales, service and maintenance network.

The review of supplier technologies has been complemented with a review of realized demonstration cases and 18 realized HTHP applications could be realized and systematically described. Each demonstration case description included information about the sector, application, process integration, technology type and manufacturer, operating experiences and more. The identified demonstrations were installed in various sectors, including food and beverage, refinery, electronics, chemicals and were mainly based on closed vapor compression cycles, steam compression and heat transformers.

Finally, an overview is given of the HTHP industries, the markets and application potentials, the development perspectives of the technologies and selected R&D projects. The overview is given on a national basis for 13 countries, before the main development perspectives are condensed into a holistic overview of the global development perspectives of HTHPs. The national reviews indicate a generally large technical application potential, with different market potentials and motivations on a national and local level. For the European market, both electrification and energy efficiency are driving factors, while energy efficiency is the dominating factor for markets such as North America. Europe and Japan are the forerunners with respect to technology development, with well-established industries for industrial heat pumps, which is being extended to high-temperature heat pumps.

From the overall review, it can be concluded that there are some solutions which are already commercially offered and implemented, but also that there is still a considerable effort needed to develop and demonstrate the required variety of solutions at the scale needed for reaching the required implementation targets for decarbonizing industries. For the coming years, there will be a strong focus on bringing technologies into application, demonstrating them in industrial applications and establishing supply chains as well as increasing the variety of solutions and extending the range of applications. In parallel, industrial end-users will work on optimizing their production to be able to convert to heat pumpbased process heat supply. It is expected that various high-temperature heat pump technologies will become commercially available and implemented during 2024 to 2025 for supply at up to 120 °C, during 2025 to 2026 for temperatures up to 160 °C, and during 2026 to 2027 for even higher temperatures.

This development is however strongly driven by innovative technology development initiatives, first movers among industrial end-users as well as the regulatory frameworks and economic boundary conditions. Changing any of these factors has the potential to accelerate the development even more, and thereby the transition towards decarbonized industrial process heating.

## <span id="page-10-0"></span>**Nomenclature**

## **Abbreviations**

| CCHP | Closed Compression Heat Pump | IHX  | Internal Heat Exchanger        |
|------|------------------------------|------|--------------------------------|
| COP  | Coefficient of Performance   | MVR  | Mechanical Vapor Recompression |
| GHG  | Green House Gas              | MVC  | Mechanical Vapor Compression   |
| HC   | Hydrocarbon                  | ORC  | Organic Rankine Cycle          |
| HCFO | Hydrochlorofluoroolefin      | RES  | Renewable Energy System        |
| HFC  | Hydroflourocarbon            | TDHP | Thermally Driven Heat Pumps    |
| HFO  | Hydrofluorooefin             | TRL  | Technology Readiness Level     |
| HTHP | High Temperature Heat Pump   | VCHP | Vapor Compression Heat Pump    |

## **Symbols**

| COP | Coefficient of Performance, - | 𝑄̇ | Heat rate, kW               |
|-----|-------------------------------|----|-----------------------------|
| Δ   | The change of a variable, -   | s  | Specific entropy, kJ/(kg K) |
| 𝜂   | Efficiency, -                 | T  | Temperature, °C or K        |
| h   | Specific enthalpy, kJ/kg      | 𝑊̇ | Power, kW                   |
| p   | Pressure, bar                 |    |                             |

## **Subscripts and superscripts<sup>1</sup>**

| H | High   |
|---|--------|
| L | Low    |
| M | Medium |

̅ Mean value, example: ̅

<sup>1</sup> Self-explaining subscripts and superscripts are excluded from the nomenclature.

## <span id="page-11-0"></span>**Table of Content**

| Preface      |                                                            | 5  |
|--------------|------------------------------------------------------------|----|
| Operating A  | Agent                                                      | 6  |
| Participatin | g countries of Annex 58                                    | 6  |
| Authors of   | the report and contributors to Task 1                      | 7  |
| Foreword     |                                                            | 8  |
| Executive    | Summary                                                    | 9  |
| Nomenclat    | ure                                                        | 11 |
| Table of Co  | ontent                                                     | 12 |
| 1. Introd    | uction to High-Temperature Heat Pumps                      | 15 |
| 1.1.         | Glossary                                                   | 15 |
| 1.2. F       | Principles and technologies                                | 16 |
| 1.2.1.       | Electrically driven high-temperature heat pump systems     | 17 |
| 1.2.2.       | Thermally driven high-temperature heat pump systems        | 27 |
| 1.2.3.       | Ideal cycles and performance benchmarks                    | 35 |
| 1.3. A       | Applications                                               | 37 |
| 1.3.1.       | Industrial Processes                                       | 37 |
| 1.3.2.       | Other applications                                         | 42 |
| 2. Overv     | iew of Technologies                                        | 43 |
| 2.1.         | Overview of collected information                          | 43 |
| 2.2.         | Description of Supplier HTHP Technology                    | 45 |
| 2.2.1.       | Compressors from the process industry                      | 46 |
| 2.2.2.       | Modified refrigeration compressors                         | 49 |
| 2.2.3.       | Novel and adapted compressor technologies                  | 56 |
| 2.3.         | Overall trends between key parameters                      | 61 |
| 3. Demo      | nstration cases                                            | 66 |
| 3.1.         | Summary of demonstration cases                             | 66 |
| 3.2. F       | Promising Applications                                     | 68 |
| 3.2.1.       | Drying                                                     | 68 |
| 3.2.2.       | Steam generation                                           | 69 |
| 3.2.3.       | Key Learnings and Success Criteria                         | 70 |
| 4. Natior    | nal HTHP market and perspectives                           | 71 |
| 4.1. A       | ustria                                                     | 71 |
| 4.1.1.       | Overview of national HTHP industry                         | 71 |
| 4.1.2.       | Overview of national HTHP market and application potential | 71 |
| 4.1.3.       | Development perspectives for HTHP technologies             | 72 |
| 4.1.4.       | Selected RD&D projects                                     | 73 |
| 12 E         | Ralaium                                                    | 78 |

| 4.2.1. | Overview of national HTHP industry 78                          |  |
|--------|----------------------------------------------------------------|--|
| 4.2.2. | Overview of national HTHP market and application potential 78  |  |
| 4.2.3. | Development perspectives for HTHP technologies 79              |  |
| 4.2.4. | Selected RD&D projects 79                                      |  |
| 4.3.   | Canada 80                                                      |  |
| 4.3.1. | Overview of national HTHP industry 80                          |  |
| 4.3.2. | Overview of national HTHP market and application potential 81  |  |
| 4.3.3. | Development perspectives for HTHP technologies 82              |  |
| 4.3.4. | Selected RD&D projects 82                                      |  |
| 4.4.   | China 83                                                       |  |
| 4.4.1. | Overview of national HTHP industry 83                          |  |
| 4.4.2. | Overview of national HTHP market and application potential 84  |  |
| 4.4.3. | Development perspectives for HTHP technologies 84              |  |
| 4.5.   | Denmark 84                                                     |  |
| 4.5.1. | Overview of national HTHP industry 84                          |  |
| 4.5.2. | Overview of national HTHP market and application potential 85  |  |
| 4.5.3. | Development perspectives for HTHP technologies 86              |  |
| 4.5.4. | Selected RD&D projects 87                                      |  |
| 4.6.   | Finland 90                                                     |  |
| 4.6.1. | Overview of national HTHP industry 90                          |  |
| 4.6.2. | Overview of national HTHP market and application potential 91  |  |
| 4.6.3. | Development perspectives for HTHP technologies 92              |  |
| 4.6.4. | Selected RD&D projects 92                                      |  |
| 4.7.   | France 94                                                      |  |
| 4.7.1. | Overview of national HTHP industry 94                          |  |
| 4.7.2. | Overview of national HTHP market and application potential 95  |  |
| 4.7.3. | Development perspectives for HTHP technologies 96              |  |
| 4.7.4. | Selected RD&D projects 97                                      |  |
| 4.8.   | Germany 99                                                     |  |
| 4.8.1. | Overview of national HTHP industry 99                          |  |
| 4.8.2. | Overview of national HTHP market and application potential 102 |  |
| 4.8.3. | Development perspectives for HTHP technologies 103             |  |
| 4.8.4. | Selected RD&D projects 103                                     |  |
| 4.9.   | Japan 110                                                      |  |
| 4.9.1. | Overview of national HTHP industry 110                         |  |
| 4.9.2. | Overview of national HTHP market and application potential 110 |  |
| 4.9.3. | Development perspectives for HTHP technologies 112             |  |
| 4.9.4. | Selected RD&D projects 112                                     |  |

|      | 4.10.   | Netherlands 118                                                          |  |
|------|---------|--------------------------------------------------------------------------|--|
|      | 4.10.1. | Overview of national HTHP industry 118                                   |  |
|      | 4.10.2. | Overview of national HTHP market and application potential 118           |  |
|      | 4.10.3. | Development perspectives for HTHP technologies 120                       |  |
|      | 4.10.4. | Selected RD&D projects 121                                               |  |
|      | 4.11.   | Norway 130                                                               |  |
|      | 4.11.1. | Overview of national HTHP industry 130                                   |  |
|      | 4.11.2. | Overview of national HTHP market and application potential 134           |  |
|      | 4.11.3. | Development perspectives for HTHP technologies 137                       |  |
|      | 4.11.4. | Selected RD&D projects 138                                               |  |
|      | 4.12.   | South Korea 140                                                          |  |
|      | 4.12.1. | Overview of national HTHP industry 140                                   |  |
|      | 4.12.2. | Overview of national HTHP market and application potential 142           |  |
|      | 4.12.3. | Development perspectives for HTHP technologies 144                       |  |
|      | 4.12.4. | Selected RD&D projects 144                                               |  |
|      | 4.13.   | Switzerland 147                                                          |  |
|      | 4.13.1. | Overview of the National HTHP Industry 147                               |  |
|      | 4.13.2. | Realized HTHP applications examples in Switzerland 148                   |  |
|      | 4.13.3. | Overview of the Swiss national HTHP market and application potential 151 |  |
|      | 4.13.4. | Funding programs for industrial heat pumps in Switzerland 154            |  |
|      | 4.13.5. | Research programs for HTHPs in Switzerland 156                           |  |
|      | 4.13.6. | Selected R&D projects for HTHPs in Switzerland 157                       |  |
|      | 4.13.7. | Development perspectives for HTHP technologies in Switzerland 160        |  |
| 5.   |         | Technology development and deployment perspectives 162                   |  |
| 5.1. |         | Technology development perspectives of high-temperature heat pumps 162   |  |
| 5.2. |         | Factors that are impacting the development perspectives towards market   |  |
|      |         | deployment 164                                                           |  |
| 6.   |         | References 166                                                           |  |

## <span id="page-14-0"></span>1. Introduction to High-Temperature Heat Pumps

High-temperature heat pumps are advanced thermal systems that provide heat at temperatures exceeding 100 °C, making them suitable for a wide range of applications in industry. These heat pumps operate on the same principles as conventional heat pumps but employ modified components and potentially new working fluids that enable them to achieve high efficiency and performance at elevated temperatures. This chapter will provide an overview of high-temperature heat pumps, including a glossary of key terms and important definitions. Working principles, important technologies, working fluids, components, and promising applications are presented to understand their characteristics and advantages. Further, it will be outlined how these systems can help to reduce energy consumption, lower greenhouse gas emissions, and enhance the sustainability of various sectors.

#### <span id="page-14-1"></span>1.1. **Glossary**

This section introduces the main terminology to be used within the Annex 58.

#### Carnot cycle:

A Carnot cycle is a thermodynamic, ideal cycle transferring heat from a hot reservoir to a colder reservoir while extracting work in the process. The working fluid in the cycle undergoes four successive processes namely, isothermal heat absorption, isentropic compression, isothermal heat rejection, and isentropic expansion.

A heat pump may be an example of a reverse Carnot cycle where work is added to transfer heat from a cold reservoir to a hotter reservoir.

#### Coefficient of performance (COP):

The coefficient of performance is a measure of the efficiency of a heat pump. It is a measure of how much heating or cooling is produced per unit of energy input, and is defined as the ratio of the amount of heat transferred to a hot reservoir compared to the amount of work input required to transfer that heat. For a heating application, the COP is given by:

$$COP = \frac{\dot{Q}_h}{\dot{W}}$$

where  $\dot{Q}_h$  is the amount of heat transferred to a high-temperature reservoir, and  $\dot{W}$  is the amount of power input required to transfer that heat.

## **Crossing temperature profiles:**

Crossing temperature profiles is here defined as the case where a part of the sink side has a lower temperature than a part of the source side temperature glide. In this case, a part of the temperature increase could be made with direct heat exchange by heat recovery from the source side, and it is not meaningful to calculate a COP<sub>Lorenz</sub>.

### **Entropic average temperature:**

The entropic average temperature is used for calculating an average temperature of a medium changing temperature between state 1 and 2. The entropic average temperature is defined as the ratio of the difference in specific enthalpy h, over the difference in specific entropy s.  $\overline{T}_{\text{entropic,average}} = \frac{h_1 - h_2}{s_1 - s_2}$ 

$$\overline{T}_{\text{entropic,average}} = \frac{h_1 - h_2}{s_1 - s_2}$$

This definition can be applied to all streams, including the case of steam supply with a combination of condensation at constant temperature and subcooling at varying temperature. For streams with a constant capacity, the entropic mean temperature can be approximated by the logarithmic mean temperature.

#### Heat source and sink:

The heat source describes the reservoir from which heat is being recovered and upgraded. Examples of heat sources are excess heat from industrial processes, ambient heat, solar collectors, or district heating. The heat sink describes accordingly the reservoir to which the heat is being supplied. Examples of heat sinks include the supply of process heat, charging of thermal energy storages, or district heating supply.

A heat pumping system can work between multiple heat sources and sinks at various temperature levels.

## • **High-temperature heat pumps (HTHP):**

A heat pump is a device that recovers heat from a specific temperature and upgrades it to a higher temperature by means of high-quality energy, such as electricity or heat from even higher temperatures.

High-temperature heat pumps are characterized by supplying a part of their main product at supply temperatures above 100 °C.

A device that recovers heat from a certain heat source for heating water from 80 °C to 120 °C can accordingly be defined as a HTHP.

High-temperature heat pumps are mainly applied in commercial and industrial applications with heating capacities larger than 100 kW. However, no minimum heating capacity has been defined for HTHPs in the context of Annex 58.

## • **Lorenz cycle:**

A Lorenz cycle is an ideal thermodynamic cycle, transferring heat from a cold reservoir to a hotter reservoir. The heat transfer occurs at the thermodynamic average temperature of the heat source and the hear sink, which may have a temperature glide. The compression and expansion processes are isentropic. The Lorenz COP describes the maximum achievable performance for a heat pump device working between two temperature reservoirs. The Lorenz cycle equals the Carnot cycle, for applications in which no temperature glide occurs in the heat source and the heat sink.

#### • **Lorenz efficiency:**

The Lorenz efficiency is a measure used to evaluate the performance of a heat pump compared to the maximum achievable performance, described by the Lorenz cycle. The Lorenz efficiency may be defined as the ratio of the actual heat pump COP and the Lorenz COP for a specific heat source and heat sink. The Lorenz efficiency approaches the Carnot efficiency in case of no temperature glide in both the heat source and the heat sink.

#### • **Mean temperature lift:**

The performance for a heat pump is strongly dependent on the temperature lift. The mean temperature lift is here calculated by the difference between the entropic mean temperatures of the heat sink and heat source:

$$\Delta \overline{T}_{\text{lift,mean}} = \overline{T}_{\text{sink}} - \overline{T}_{\text{source}}$$

### • **Mechanical Vapor Recompression and Steam Compression:**

Mechanical vapor recompression refers to a thermal process, in which the vapor from an evaporator is reused for heating the same evaporation step, after being upgraded to slightly higher pressure and temperature. The upgrading can be realized by thermal or mechanical compression, while the latter process is referred to as mechanical vapor recompression. Mechanical vapor recompression is a process with a variety of proven technologies, including steam compressors. These steam compressors may be utilized in other steam compression applications, such as heat pumping applications.

#### • **Temperature glide:**

The temperature glide describes the difference in inlet and outlet temperature of a stream that is either heated or cooled. Water heated from 80 °C to 120 °C will have a temperature glide of 40 K.

#### • **Working fluid:**

The working fluid is the substance circulating within the closed cycle of the heat pump. The choice of working fluid greatly influences the performance of the heat pump and is often referred to as the refrigerant.

#### <span id="page-15-0"></span>**1.2. Principles and technologies**

A heat pump is a device that utilizes electricity or heat to transfer heat from a lower temperature to a higher temperature. In doing so, it recovers heat that would otherwise be wasted and makes it available for practical purposes such as process heating or other applications. This principle is presented i[n Figure](#page-16-1)  [1-1.](#page-16-1)

![](_page_16_Picture_0.jpeg)

*Figure 1-1: The fundamental principle of a heat pump*

<span id="page-16-1"></span>Heat pumps work by exploiting the natural thermodynamic properties of working fluids by manipulating pressure and temperature. This section will explain the technologies commonly used in heat pumps, including their working principles, types, components, and applications. The characteristics of the various technologies are explained with a focus on the most promising applications.

#### <span id="page-16-0"></span>**1.2.1. Electrically driven high-temperature heat pump systems**

Electrically driven high-temperature heat pumps (HTHPs) are heat pumps where the main driver of the thermodynamic cycle is electricity. The vapor-compression heat pump is the main example of this. Here, the cycle is primarily driven by the power for the compressor, which usually is delivered by an electric drive.

## **1.2.1.1. System types**

In this section, the most common and promising system layouts of electrically driven heat pumps are presented. The presented cycles change the thermodynamic in distinct ways, resulting in higher thermodynamic performance depending on the deployed refrigerant.

### **Single-stage cycle (with/without IHX)**

The simplest system is a single-stage cycle. Depending on the properties of the refrigerant, an internal heat exchanger (IHX) can be used to increase cycle performance as depicted in [Figure 1-2.](#page-16-2) The IHX is most beneficial for refrigerants with a saturated vapor curve with a positive slope (dT/ds > 0) that requires substantial superheating to avoid wet compression. More information on those refrigerants can be found in [1]. The compression in standard cycles or IHX cycles can be realized in a single-stage compression or as a multi-stage compression with or without interstage cooling.

<span id="page-16-2"></span>![](_page_16_Picture_9.jpeg)

*Figure 1-2: Single-stage cycle with IHX (Source: AIT).*

## **Economizer cycle**

In an economizer cycle (see [Figure 1-3\)](#page-17-0), a slip stream of the refrigerant is expanded after the condenser in an expansion valve to an intermediate pressure. Thereby, the temperature of this slip stream decreases and is partially evaporated. Therefore, heat is exchanged from the liquid refrigerant (high pressure) to the partially evaporated (intermediate pressure) refrigerant. The refrigerant (intermediate pressure) is now completely evaporated in the economizer heat exchanger. The evaporated slip stream is then fed into the compressor. The remaining liquid refrigerant is expanded and flows through the evaporator. In this configuration, a higher refrigerant mass flow occurs in the condenser than in the evaporator. Part of the refrigerant mass flow must be compressed from low pressure (evaporator) to high pressure (condenser). The remaining part is compressed only from medium pressure to high pressure, so the power consumption is lower for the same heating capacity.

![](_page_17_Picture_2.jpeg)

*Figure 1-3: Economizer cycle (Source: AIT).*

#### <span id="page-17-0"></span>**Twin cycle / Multi cycle**

This cycle type, shown in [Figure 1-4,](#page-17-1) consists of two (twin) or more (multi) refrigeration cycles. In this arrangement, the sources or sinks can be connected either in parallel or in series. A serial connection is used to overcome a high temperature difference between inlet and outlet. In general, different COPs per cycle occur in this configuration because the operating temperatures per cycle differ from each other. The cycle that must overcome a lower temperature lift operates at a higher COP.

The multi or twin cycle configuration provides advantages at operating conditions with higher temperature differences (between source inlet and outlet or between sink inlet and outlet), as not only one refrigerant cycle or compressor must provide the entire heating capacity or temperature lift.

![](_page_17_Figure_7.jpeg)

*Figure 1-4: Twin cycle / Multi cycle* [2]

#### <span id="page-17-1"></span>**Cascade cycle**

The cascade cycle [\(Figure 1-5\)](#page-18-0) consists of two refrigeration cycles (low- and high-temperature refrigeration cycle), which are connected by a heat exchanger (so-called evaporator-condenser). In this heat exchanger, the refrigerant of the low-temperature cycle condenses, and the refrigerant of the hightemperature cycle evaporates simultaneously. In this configuration, each individual refrigeration cycle has to overcome a lower pressure ratio than in the single-stage configuration, which results in an increase in efficiency, especially at high temperature lifts. However, as one cycle is the heat source for the other cycle, the heat output of this configuration is lower compared to twin cycle type.

![](_page_18_Picture_1.jpeg)

*Figure 1-5: Cascade cycle (Source: AIT).*

#### <span id="page-18-0"></span>**Condenser outlet split (COS) ejectors cycle**

The use of an ejector is a method of increasing efficiency and reducing losses [\(Figure 1-6\)](#page-18-1). The basic idea is to use the expansion of the high-pressure refrigerant to compress the entrained low-pressure refrigerant. After mixing and leaving the ejector, the refrigerant is at an intermediate pressure level ensuring that the compressor has not to overcome the whole pressure difference between condenser and evaporator as would be the case in a single-stage cycle. The ejector consists of a nozzle, a mixing zone and a diffusor. The high-pressure refrigerant is accelerating in the nozzle. Afterwards the lowpressure refrigerant is injected in the mixing zone, where it entrains into the high-pressure refrigerant. In the diffusor a simultaneous reduction of the velocity results in the establishment of an intermediate pressure level. Further information on ejectors can be found in chapter [1.2.1.4.](#page-25-0)

![](_page_18_Picture_5.jpeg)

*Figure 1-6: Cycle with condenser outlet split (COS) ejectors (Source: AIT)*

#### <span id="page-18-1"></span>**Transcritical cycle**

While in the previously described cycles, condensation of the refrigerant occurs during the heat release (subcritical cycle), in transcritical cycles, heat is released at gliding temperature. In transcritical cycles, heat absorption also takes place in the subcritical range under evaporation of the refrigerant. The stages of both ideal cycles are described in the following and shown in [Figure 1-7.](#page-19-0)

- 1. The isentropic compression from state 1 to state 2 (higher temperature and pressure).
- 2. Isobaric heat transfer to the heat sink from 2 to 3.
- 3. Isenthalpic expansion from state 3 to 4.
- 4. Isobaric heat uptake from the heat source from state 4 to1.

![](_page_19_Figure_0.jpeg)

*Figure 1-7: p-h diagram of (a) subcritical and (b) transcritical heat pump cycle (Source: AIT)*

<span id="page-19-0"></span>Most commonly, CO<sup>2</sup> is used as a refrigerant in transcritical processes (e.g., suitable for hot water generation). The critical pressure is at 73.8 bar, and the critical temperature is 31 °C.

## **Joule cycle**

The Joule cycle (also known as reversed Brayton cycle) differs from the other cycles already described in that there is no phase change in the entire cycle. Due to the circumstance that the medium is gaseous throughout the whole process, only sensible heat exchange occurs. Therefore, it is well suited for heat sources and sinks with large temperature differences.

In the following, the stages of the ideal Joule cycle are described as depicted in [Figure 1-8.](#page-19-1)

- 1. The isentropic compression from state 1 to state 2 (higher temperature and pressure).
- 2. Isobaric heat transfer to the heat sink from 2 to 3.
- 3. Isentropic expansion from state 3 to 4.
- 4. Isobaric heat uptake from the heat source from state 4 to1.

![](_page_19_Figure_10.jpeg)

*Figure 1-8: T-s diagram of the Joule cycle (Source: AIT)*

#### <span id="page-19-1"></span>**Stirling cycle**

The ideal Stirling process is also a gas compression process which is most commonly used in refrigeration applications at low temperatures. It is also called Philips process, as the company was the first to reach 20 K with this process. The process consists of two isochoric and two isothermal changes of state and is realized in a machine with two chambers that are connected by two pistons. The two chambers are connected by a regenerator, which has a high heat conductivity and a large specific surface to be heated and cooled rapidly. The charge pressure and configuration will define the maximum pressure and amplitude and can be used to regulate the load of the heat pump. The process can adapt to any external temperature regardless of gas pressures, and any restriction on the temperatures is caused by the mechanical implementation of the process. It is especially useful for high temperature lifts.

In the following, the stages of the ideal Stirling process are described as depicted in [Figure 1-9.](#page-20-0)

- 1. Isothermal compression from 2 to 3 in the first chamber, volume change work is done to the gas at a constant temperature, heat is released to the heat sink.
- 2. Gas is transferred to the second chamber at a constant volume from 3 to 4, the regenerator is heated, the gas is cooled. For constant volume, the movement of the two pistons is synchronized mechanically.
- 3. Isothermal expansion from 4 1, volume change work is released, the piston is moved, the gas heated by the heat source to keep the temperature constant.

4. Gas is transferred back to first chamber at constant volume from 1 – 2, the gas is heated by the regenerator.

![](_page_20_Figure_1.jpeg)

*Figure 1-9: T-s diagram of the Sterling process (Source: AIT)*

#### <span id="page-20-0"></span>**Mechanical vapor recompression (MVR)**

MVR systems have two main configurations, open and semi-open. In open MVR systems, vapor from an industrial process is compressed to a higher pressure and thus a higher temperature and condensed in the same process providing heat. In semi-open systems, heat from the recompressed vapor is transferred to the process indirectly via a heat exchanger.

MVR systems are usually designed for R-718 (water) as refrigerant, although other process vapors are also used, notably in the (petro-) chemical industry.

Because one or two heat exchangers are eliminated (evaporator and/or condenser) and the temperature lift is generally small, the performance of MVR systems is high (COPs higher than 10 are possible for some applications [3]).

In principle, all common compressor types are suitable for MVR recompression. The respective high temperature application with its operating conditions determines which compressor type is the most suitable.

#### **Steam compression systems**

Steam compression systems can be constructed as closed and open systems. The closed configuration corresponds to a conventional heat pump cycle, working with water (R-718) as working fluid.

In open systems, the steam is directly utilized and distributed in steam networks, providing heat to various processes. As in conventional combustion-based steam networks, the steam can be condensed in a heat exchanger to transfer heat to processes or injected directly into process streams.

The compressors being considered for steam compression include equipment from MVR technologies and equipment from process gas compression, as well as novel developments based on compression equipment from other heat pump applications.

#### **1.2.1.2. Working fluids**

#### **Overview of working fluids**

[Table 1-1](#page-21-0) gives an overview of the properties of present and future working fluids used in electrically driven HTHP applications (excluding noble gases like helium or argon applied in Stirling and Brayton cycles) [1]. Listed are the critical temperature and pressure, the ozone depletion potential (ODP), the global warming potential (GWP), and the safety group classification.

<span id="page-21-0"></span>Table 1-1: Properties of present and future working fluids used in electrically-driven HTHPs (Source: [1]) (HC: Hydrocarbons, HFO: Hydrofluoroolefins, HCFO: Hydrochlorofluoroolefins, HFC: Hydrofluorocarbons, *T*crit: Critical temperature, *p*crit: Critical pressure, ODP: Ozone Depletion Potential relative to R-11, GWP: Global Warming Potential relative to CO<sup>2</sup> based on 100-year time horizon, SG: Safety group classification).

| Type    | Working fluid | Description                                | Tcrit<br>(°C) | pcrit<br>(bar) | ODP<br>(-) | GWP<br>(-) | SG  |
|---------|---------------|--------------------------------------------|---------------|----------------|------------|------------|-----|
|         | R-718         | Water                                      | 373.9         | 220.6          | 0          | 0          | A1  |
| Natural | R-717         | Ammonia                                    | 132.3         | 113.3          | 0          | 0          | B2L |
|         | R-744         | Carbon dioxide                             | 31.0          | 73.8           | 0          | 1          | A1  |
|         | R-601         | n-Pentane                                  | 196.6         | 33.7           | 0          | 5          | A3  |
|         | R-601a        | Isopentane                                 | 187.8         | 33.8           | 0          | 4          | A3  |
| HC      | R-600         | n-Butane                                   | 152.0         | 38.0           | 0          | 4          | A3  |
|         | R-600a        | Isobutane                                  | 134.7         | 36.3           | 0          | 3          | A3  |
|         | R-290         | Propane                                    | 96.7          | 42.5           | 0          | 3          | A3  |
|         | R-1336mzz(Z)  | 1,1,1,4,4,4-Hexafluoro-2-butene            | 171.3         | 29.0           | 0          | 2          | A1  |
|         | R-1234ze(Z)   | cis-1,3,3,3-Tetrafluoro-1-propene          | 150.1         | 35.3           | 0          | <1         | A2L |
| HFO     | R-1336mzz(E)  | trans-1,1,1,4,4,4,-Hexafluoro-2-<br>butene | 130.4         | 27.8           | 0          | 18         | A1  |
|         | R-1234ze(E)   | trans-1,3,3,3-Tetrafluoro-1-propene        | 109.4         | 36.4           | 0          | <1         | A2L |
|         | R-1234yf      | 2,3,3,3-Tetrafluoro-1-propene              | 94.7          | 33.8           | 0          | <1         | A2L |
|         | R-1233zd(E)   | 1-chloro-3,3,3-Trifluoro-propene           | 166.5         | 36.2           | 0.00034    | 1          | A1  |
| HCFO    | R-1224yd(Z)   | 1-chloro-2,3,3,3-Tetrafluoro-propene       | 155.5         | 33.3           | 0.00012    | <1         | A1  |
|         | R-365mfc      | 1,1,1,3,3-Pentafluorobutane                | 186.9         | 32.7           | 0          | 804        | A2  |
| HFC     | R-245fa       | 1,1,2,2,3-Pentafluoropropane               | 154.0         | 36.5           | 0          | 858        | B1  |
|         | R-134a        | 1,1,1,2-Tetrafluoroethane                  | 101.1         | 40.6           | 0          | 1'300      | A1  |

The choice of working fluid depends primarily on the temperature levels of the heat pump. Therefore, the working fluid properties optimally match the process requirements to achieve high efficiency. [Figure](#page-21-1)  [1-10](#page-21-1) shows the temperature application ranges for different working fluids. The upper application limit is drawn for subcritical cycles (with condensation) by the critical temperature. A condensation temperature of about 15 K below the critical temperature should ensure efficient heat pump operation.

![](_page_21_Figure_3.jpeg)

<span id="page-21-1"></span>*Figure 1-10: Temperature application ranges for different working fluids in HTHP applications (Source: OST-IES).* Note: The lower limit is defined by the boiling temperature at 1 bar and the upper limit is 15 K below the critical temperature for subcritical condensation. Exceptions are R744 (transcritical up to 120 °C) and R718 (vapor recompression).

HFCs such as R-245fa or R-365mfc are commonly used as working fluids in HTHPs today. However, their GWP is comparatively high, and in view of the prevention of global warming (F-gas regulation), these working fluids will be restricted in the foreseeable future. Therefore, natural refrigerants and alternative synthetic working fluids with low GWP will be applied.

## **Natural refrigerants**

Natural refrigerants suitable for HTHP applications are water (R-718), CO<sup>2</sup> (R-744), ammonia (R-717), and hydrocarbons (e.g., R-600, R-601).

## **Water**

When using water (R-718) in a subcritical cycle, a major part of the heat pump cycle may be below atmospheric pressure because of the high normal boiling point of 100 °C. In addition, the latent heat of water is large, which makes water very attractive for temperatures above 150 °C. However, the required swept volume and pressure ratio are very high due to the low water vapor density. Therefore, several compression stages are required with intermediate cooling (e.g., water injection) to keep the discharge temperature to a tolerable level. Typically, water vapor recompression (MVR) systems are operated using large compressors or high-speed oil-free turbo compressors with high flow rates and low-pressure ratios to compensate for the low density of the water vapor.

## **CO<sup>2</sup>**

CO2 (R-744) has a critical temperature of 31 °C and high critical pressure of 73.6 bar. CO<sup>2</sup> heat pumps achieve heat sink temperatures of about 90 to 120 °C in transcritical cycles. R-744 is feasible as an HTHP working fluid if the return temperature of the heat sink is low and not too far above the critical temperature. The high temperature difference in the gas cooler makes R-744 particularly suitable for hot water or air heating processes.

#### **Ammonia**

Ammonia (R-717) is widely used in refrigeration and industrial heat pumps up to about 90 °C heat sink temperature. Beneficial is its high volumetric heating capacity (VHC) compared to other working fluids due to its low molecular weight resulting in high vaporization latent heat. However, for higher temperatures, existing compressor technology is limited by the high discharge pressures. With special cast steel construction, NH3 compressors can withstand pressures of up to about 76 bar and 110 °C. However, certain safety precautions must be implemented due to the toxicity of ammonia (B2L). For a 1 MW 2-stage heat pump, the ammonia charge is approximately 350 kg.

### **Hydrocarbons**

The hydrocarbons n-butane (R-600) and pentane (R-601) are refrigerants without ODP and very low GWP. They have high critical temperatures of 152 °C and 196.6 °C at 38.0 bar and 33.7 bar, respectively. R-600 is considered a suitable medium in HTHPs with condensation temperatures up to about 120 °C. These temperatures can be achieved in standard compressors. On the other hand, special safety measures must be implemented due to the high flammability (A3). The EN 378-1:2016 standard specifies the criteria for calculating the permissible charge, depending on the person access category, installation area, and type of application. For monitored commercial installations with appropriate explosion protection, the maximum filling quantity is 2.5 kg. For industrial applications and district heating, the refrigerant charge can be a lot higher considering suitable safety measures, and multiple examples have been built with refrigerant charges above 1 ton and heating capacities up to 8 MW.

#### **Alternative synthetic working fluids**

## **HFOs**

Hydrofluoroolefins (HFOs) are considered environmentally friendly (low GWP) alternatives to replace HFCs. R-1234yf, R-1234ze(E), and R-1336mzz(E) are regarded as substitutes for R-134a. The critical temperatures and pressures are comparable. R-1234ze(E) and R-1234yf are rated as non-toxic and low flammable (A2L). On the other hand, one of the main atmospheric decomposition products of R-1234yf is trifluoroacetic acid (TFA, CF3COOH) that can be harmful to aquatic organisms in concentrations above 0.1 mg/L. The molar yield of TFA formation is 100% for R-1234yf. However, according to the current state-of-the-art [4], the estimated TFA concentrations and its salts in the environment that result from degradation of HCFCs, HFCs, and HFOs in the atmosphere do not present a risk to humans and environment. Therefore, they could serve as working fluids for the first stage of a two-stage HTHP cascade cycle. Nevertheless, a better understanding of TFA sources would help to evaluate the environmental impact of HFO refrigerants.

R-1336mzz(Z) and R-1234ze(Z) are attractive replacements for R-245fa and R-365mfc. R-1336mzz(Z) has a high critical temperature of 171.3 °C at a relatively low pressure of 29.0 bar, safety class A1, a GWP of 2, zero ODP, and an atmospheric life of about 22 days. In addition, it delivers heat sink

temperatures up to 160 °C in waste heat recovery applications and steam generation. Its isomer R-1336mzz(E) has a GWP of 18, a critical temperature of 130.4 °C, and zero ODP. It could be used in HTHPs to recover heat from various heat sources, as its VHC is comparable to R-245fa. R-1234ze(Z) is another promising drop-in alternative to R-245fa in HTHP applications. However, relatively little information is available. Its critical temperature and pressure are 150.1 °C and 35.3 bar, allowing subcritical cycle operations at high temperatures. Although its flammability is rated with A2L, its GWP is smaller than 1.

#### **HCFOs**

The hydrochlorofluoroolefin R-1233zd(E) has a critical temperature and pressure of 165.5 °C and 35.7 bar, and it is safety class A1. R-1224yd(Z) is non-flammable and has a GWP value under 1. Its physical properties are close to R-245fa and R-1233zd(E). Although R-1233zd(E) and R-1224yd(Z) contain chlorine, their ODPs are extremely small (0.00034 and 0.00012) due to the very short atmospheric lifetime of about 40 days and 21 days. Both working fluids are used in centrifugal chillers and heat pumps for waste heat recovery. Furthermore, they are compatible with most used metals, plastics, and elastomers and are miscible with synthetic oils such as POEs. It should be noted that R-1233zd(E) has a molar yield of TFA formation of only about 2%.

#### **Working fluid aspects**

The selection of the working fluid (refrigerant) is a key element in the design of HTHPs. The essential evaluation criteria for the application in HTHPs can be categorized into thermal suitability, environmental compatibility, safety, efficiency, availability, and other factors [\(Table 1-2\)](#page-23-0).

<span id="page-23-0"></span>

| Category            | Required properties                                             |
|---------------------|-----------------------------------------------------------------|
| Thermal suitability | High critical temperature (>150 °C) allowing subcritical cycles |
|                     | Low critical pressure (<30 bar)                                 |
|                     | Pressure at standstill >1 atm                                   |
|                     | Low pressure ratio                                              |
| Environmental       | No ozone depletion (ODP zero)                                   |
| compatibility       | Low global warming (GWP < 10)                                   |
|                     | Short atmospheric lifetime (< 30 days)                          |
|                     | Future-proof according to F-gas regulations (EU 517/2014)       |
| Safety              | Non-toxicity                                                    |
|                     | No or only low flammability                                     |
| Efficiency          | High efficiency (COP) at high temperature lifts                 |
|                     | Minimal superheat to prevent liquid compression                 |
|                     | High volumetric heating capacity (VHC)                          |
| Availability        | Available on the market                                         |
|                     | Low price                                                       |
| Other factors       | Satisfactory solubility in oil                                  |
|                     | Thermal stability of the refrigerant-oil mixture                |
|                     | Lubricating properties at high temperatures                     |
|                     | Material compatibility with aluminum, steel, and copper         |

In industry, more weight is given to environmental analysis than hazard potential since qualified personnel can ensure maintenance. The hazard classification is based on the current standard and weighted according to flammable (A3) to non-flammable (A1) and toxic (B) to non-toxic (A). For environmental analysis, the ODP and GWP are critical. The F-Gas Regulation (EU 517/2014) specifies the permits. For industrial heat pumps, the ODP must be 0, while GWP values greater than 1 are also permitted.

## **1.2.1.3. Compressors**

The compressor is the main component of a compression heat pump. It compresses the gaseous refrigerant from a lower to a higher-pressure level. Therefore, the compressor highly impacts the efficiency of the HP system. Different compressor types are available. The main compressor types currently used in HTHPs are piston (reciprocating), scroll, screw, and turbo compressors (including centrifugal compressors). Typically, these compressor types are driven by an electric motor.

**Piston compressor:** In this type, the gaseous refrigerant at lower pressure is sucked in through a valve when the piston moves downwards. When the piston moves upwards, the gas is compressed to a higher pressure. The disadvantages of this type of compressor are the pulsating volume flows and the possible occurrence of a liquid hammer.

**Screw compressor:** In this type of compressor, compression is accomplished by two counter-rotating screw-shaped rotors. The advantages of screw compressors are, for example, the compact design and the high speeds that can be realized. A disadvantage is the oil injection that is necessary for sealing. Moreover, it requires oil management systems and oil degradation at high temperatures might be an issue limiting the application.

**Scroll compressor:** In scroll compressors, the gaseous refrigerant is compressed by means of two spirals moving into each other. The advantages of this type include low vibration, low noise level and not sensitive to liquid hammer. However, the capacity range of the compressor type is very limited.

**Turbo compressor:** In contrast to the other compressors described above, the turbo compressor is a fluid-flow machine and does not operate on the displacement principle. In this type of compressor, the energy is transferred to the medium by means of rotating impellers. The pressure increase is achieved by means of a diffuser. The advantage of this type is the small space requirement, the large flow rates, the good speed control, and the low abrasion. However, the feasible pressure ratios per stage are low. Typically, water vapor recompression systems are operated using large compressors or high-speed oil-free turbo compressors with high flow rate and low-pressure ratio to compensate for the low density of the water vapor.

<span id="page-24-0"></span>Table 1-3 summarizes the main characteristics of the above-described compressor types.

| Compressor type                | Piston              | Scroll         | Screw                 | Turbo                             |
|--------------------------------|---------------------|----------------|-----------------------|-----------------------------------|
| Driving force                  | Displacement        | Displacement   | Displacement          | Flow machine                      |
| Compression                    | Static              | Static         | Static                | Dynamic                           |
| Swept volume                   | Geometrical         | Geometrical    | Geometrical           | Depending on the counter pressure |
| Production                     | Pulsing             | Continuously   | Continuously          | Continuously                      |
| Volume flow                    | Up to 1,000<br>m³/h | Up to 500 m³/h | 100 to 10,000<br>m³/h | 100 to 50,000<br>m³/h             |
| Heating capacity               | Up to 800 kW        | Up to 400 kW   | 80 kW to 8 MW         | 80 kW to 40 MW                    |
| Pressure ratio (single stage)  | Up to 10            | Up to 10       | Up to above 20*       | Up to 5                           |
| Controllable at constant speed | In stages           | Difficult      | Continuously          | Continuously                      |
| Speed control                  | Possible            | Possible       | Possible              | Possible                          |
| Sensitivity to liquid slugging | High                | Low            | Low                   | Low                               |
| Causes vibrations              | Yes                 | No             | No                    | No                                |

Table 1-3: Main characteristics of compressors [5].

Furthermore, compressors differ not only in their functional principle, but also in the design, especially on the case design. A general distinction is made between fully hermetic, semi-hermetic and open compressors. In fully hermetic compressors, the compressor and motor are surrounded by a hermetically welded housing. One advantage of these compressors is their high tightness. A disadvantage is that it is not possible to service this type of compressor. In contrast to the fully hermetic compressor, the motor and compressor are separated in the open compressor. Possible leaks are a disadvantage with this type, although repair is possible. In a semi-hermetic compressor, the compressor and motor are surrounded by a housing, but this is not welded. This type has a higher tightness than an

<sup>\*</sup>Pressure ratio of screw compressor taken from [6]

open compressor and maintenance is also possible.

#### **Rotational compression**

In contrast to conventional compression heat pumps, the rotation heat pump, based on the Joule process, uses the centrifugal potential instead of the compressors mentioned above to increase pressure. In general, the rotation heat pump consists of two heat exchangers installed on a rotor, including piping. A fan is used for the circulation of the gaseous heat transfer medium [7].

### <span id="page-25-0"></span>**1.2.1.4. Other components**

### **Ejectors as expansion recovery devices**

Exergy analysis of heat pumps generally show that the expansion valve throttling is a major irreversibility process. This is particularly true in the case of high temperature heat pumps which often necessitate high compression ratio between the evaporator and the condenser, especially for high-lift applications. Various expansion means may be used to recover expansion work, such as reciprocating piston, scroll and screw devices. However, these systems present moving parts with friction and potential leakage problems, possibly resulting in control issues in the case of a common shaft between compressor and expander. The use of the ejector as an expansion device is one alternative that is being investigated by several research organizations with the objective to improve the performance of heat pump cycles.

[Figure 1-11](#page-25-1) shows a typical vapor-compression cycle with an ejector to reduce throttling losses during the expansion process. This ejector expansion cycle differs from the conventional mechanical cycle by the replacement of the isenthalpic expansion valve with a quasi-isentropic expansion ejector and a separator located between the ejector discharge and the compressor suction. The high-pressure refrigerant is used as motive fluid. The recovered work is used to partially compress the vapor leaving the evaporator and reduces the load on the compressor. Advanced ejector cycle configurations can be obtained by adding other components such as IHX.

![](_page_25_Picture_7.jpeg)

*Figure 1-11 Compression cycle with a two-phase ejector as an expander*

<span id="page-25-1"></span>Compared to existing well established refrigeration applications, a limited number of studies has been carried out on the use of the ejector with HTHP. Popovac et al. [8] designed and tested a HTHP based on butane as the refrigerant. Two cycle configurations, with and without ejector were tested. The temperature levels considered for the tests were in the range of 50-80 °C on the low temperature side and 100-130 °C on the high temperature side. Some instabilities in the operation were observed, which restricted the full range measurements. However, the results at moderate temperature levels show an improved COP of about 25% for the ejector heat pump, compared to a standard heat pump configuration.

Luo and Zou [9] simulated Ejector-HTHP cycle using different refrigerants at a condensing temperature of 120 °C with a temperature lift of 40 °C. The ejector cycle improved energy efficiency and heating capacity by about 8-14% and 8-10% compared to a basic cycle respectively.

Bai et al. [10] analyzed theoretically two ejector cycles in HTHP with various low GWP refrigerants. At a condensation temperature of 105 °C and evaporation temperature of 30 °C, the COP improvement of

the ejector cycles may reach 14.5% compared to a basic cycle.

Mateu-Royo et al. [11] investigated numerically the performance of an ejector cycle in HTHP for lowgrade waste heat recovery ( = 70− 90 °). A single-stage cycle using HFC-245fa was used as a reference for comparison. Ejector configurations with IHX provide a COP improvement of up to 36% for a heating temperature production of 140 °C. In addition, the volumetric heating capacity increases around 40%. The authors recommend IHX in high temperature applications to increase the performance efficiency and ensure dry compression of most of the alternative low GWP refrigerants.

Recently, Mateu-Royo et al. [12] theoretically conducted a comparative performance analysis of several HTHP configurations with low GWP refrigerants for industrial waste heat recovery. The ejector cycle among the eight proposed configurations, slightly improves the energy performance and requires more compact compressor than the basic single-stage configuration. The cost of the different cycles was also evaluated. The cycle with ejector was slightly more expensive than the basic one (<2%).

Ejectors in HTHP applications still faces a research gap especially in terms of experimental studies. Ejector operation and performance need to be accurately determined so as to correspond to the refrigerant type and the HTHP conditions. However, they are expected to play a key role in improving high temperature heat pump performance in a near future, as they already do in CO2 refrigeration applications.

#### <span id="page-26-0"></span>**1.2.2. Thermally driven high-temperature heat pump systems**

#### **1.2.2.1. Introduction to heat driven technologies**

Thermally driven heat pumps (TDHPs) are mainly driven by thermal energy, as opposed to vapor compression heat pumps (VCHPs), where the main driver is mechanical power for the compressor, usually delivered by an electric drive. Thermally driven heat pumps may still require some electrical power, e.g., for pumps, but considerably less than VCHPs. This section provides an introduction to thermally driven heat pumps, more specifically different types of sorption machines based on absorption or adsorption. Other types of TDHPs are not discussed, for example thermoacoustic and hybrid heat pumps.

![](_page_26_Figure_7.jpeg)

*Figure 1-12: Overview of thermally driven heat pumps.*

Although VCHP systems are the most competitive heat pump technology, researchers in the field of thermally driven heat pumps claim that VCHPs have several drawbacks that can be avoided by using thermally driven heat pumps [13]. Cited drawbacks are: that VCHPs often use refrigerants with high Global Warming Potentials (GWPs) and/or Ozone Depleting Potentials (ODPs); that VCHPs are typically driven by electric motors, and that electricity currently is mostly generated by fossil-fuels; that VCHPs have higher noise and vibration levels due to the mechanical compression; and that VCHPs are more maintenance-intensive. However, state-of-the-art heat pumps mainly use natural refrigerants and HFOs/HCFOs, as demonstrated by the supplier information obtained by the Annex 58. These refrigerants have a zero ODP and a low GWP. Furthermore, the carbon intensity of electricity generation is strongly declining; in the EU-27 it decreased from 510 g CO2eq/kWh in 1990 to 281 g CO2eq/kWh in 2018 [14]. With the increasing shift to renewables, this number will further decrease. Although these drawbacks are partially solved for VCHPs, they can in theory be tackled easily by use of TDHPs. However, these systems have their own drawbacks: larger and more complex installations (e.g., higher capital costs), lower performance (COP) and a limited amount of fossil-fuel-free thermal energy drivers [15].

The economics of these competing heat pump technologies strongly depend on local energy prices. In case fossil fuels generate the thermal energy, TDHPs will have more favorable economics in the event of low fossil-fuel prices compared to electricity prices, while VCHPs will have more favorable economics in case of high fossil-fuel prices compared to electricity prices. In future scenarios, it is expected that fuel prices will be high compared to the electricity cost, so that VCHPs promise to be more cost-effective compared to fossil-based TDHPs. On the other hand, TDHPs that use low-temperature heat (e.g., heat transformers, see further) can also be cost-effective if that heat is freely available (e.g., waste heat). This section describes the most important concepts and types of TDHPs. Below, an overview is given of the subscripts and symbols that are used to describe TDHPs.

- subscripts:
  - o : Low temperature
  - o : Medium temperature
  - o : High temperature
  - o ℎ = heat engine
  - o ℎ = heat pump
- variables:
  - o : temperature
  - o : pressure
  - o : sorption capacity

## **1.2.2.2. Introduction to sorption machines**

The general principle of sorption machines is to replace the compressor of a VCHP with a thermally driven process that relies on sorption and desorption of the refrigerant and consequently requires much lower mechanical (electrical) power to compress the refrigerant vapor. *Sorption* is defined as "the process by which a substance (the *sorbate*) is sorbed (adsorbed or absorbed) on or in another substance (the *sorbent*)" [16]. *Absorption* is the incorporation of a sorbate in one state, into the volume of a sorbent in another state; in this case absorption of a gaseous refrigerant in a liquid. On the other hand, *adsorption* is adherence or bonding of a sorbate onto the surface of a sorbent; in this case adsorption of a gaseous refrigerant onto a solid's surface. For sorption machines, these sorption processes must be reversible. Furthermore, they can be based on physical or chemical principles, resulting in respectively *physicosorption* and *chemisorption*. Hence, this type of machine is sometimes also called a *chemical heat pump*, in contrast to a VCHP.

The sorption capacity (or loading), , expresses the amount of sorbate (gaseous refrigerant) taken up per unit of mass or volume of the sorbent. At a given pressure and temperature , a given combination of refrigerant and sorbent has an equilibrium capacity , i.e. the capacity that is reached if pressure and temperature were kept constant for a sufficiently long time. [Figure 1-13](#page-28-0) shows the capacity for a typical refrigerant-sorbent pair as a function of and . The capacity is displayed on a () versus (−1/) diagram, as isosteres (lines of constant capacity ) tend to form straight lines in that case. It can be observed that the equilibrium capacity increases with pressure and decreases with temperature. Following *Le Chatelier's principle*<sup>2</sup> , sorption is an *exothermic* process (releases heat), while desorption is *endothermic* (requires heat addition).

<sup>2</sup> According to Le Chatelier's principle, sorption must be exothermic to provide an opposing force. If gas is sorbed, then heat is released by the exothermic process, so that temperature rises and sorption capacity decreases. As a consequence, sorption will diminish and an equilibrium will form.

![](_page_28_Figure_0.jpeg)

*Figure 1-13: Lines of constant equilibrium sorption capacity (isosteres) as found in sorption machines.*

<span id="page-28-0"></span>[Figure 1-14](#page-28-1) schematically shows how the sorption principle is used to create a TDHP. The "thermally driven compressor" is not explained in detail, as this differs for absorption and adsorption machines. Due to the addition of sorption and desorption processes, these heat pumps work with 4 heat fluxes (2 in and 2 out), although they are typically designed to work at only 3 distinct temperature levels. After taking up low temperature heat ( ) in the evaporator, the gaseous refrigerant is sorbed, releasing heat at a medium temperature (). After the pressure has been raised (without a mechanical compressor), the refrigerant is desorbed, requiring a high temperature () heat input. It is then condensed, providing useful heat at , and sent to the expansion valve. This way, a certain amount of high temperature driving heat is "amplified" into a larger amount of medium temperature useful heat.

![](_page_28_Figure_3.jpeg)

*Figure 1-14: Principle of sorption heat pump.*

<span id="page-28-1"></span>As there are now 4 heat fluxes in and out of the machine, the cycle is more flexible. For a heat pump, the condenser pressure is higher than the evaporator pressure , hence temperatures are higher at the condenser side. However, if the expansion valve is replaced by a pump, then will be higher so that the evaporator side has the higher temperatures. The result is called a *heat transformer*, as opposed to a *heat pump*. The principle of a heat transformer is shown in [Figure 1-15.](#page-29-0) Notice that the condenser now rejects low temperature heat, while only the sorption process provides useful high temperature heat. This way a large medium temperature heat flux is "transformed" to a smaller high temperature flux.

![](_page_29_Figure_0.jpeg)

*Figure 1-15: Principle of sorption heat transformer.*

<span id="page-29-0"></span>For sorption machines, the COP is defined as the amount of useful process heat supplied, divided by the primary energy input. For heat pumps, the COP is the ratio of the useful output heat at the condenser () to the high temperature driving heat for desorption (), which is always larger than 1. For heat transformers, the COP is the ratio of the useful output heat from sorption () to the input heat at both the evaporator and for desorption (), and is always lower than 1. The different COP definitions, the corresponding theoretical maximum COP and typical practical values are given in [Table 1-4](#page-29-1). In some cases, an "electrical COP" is reported for TDHPs, where the auxiliary electric power is used in the in the denominator instead of the driving heat. As electrical power use (e.g. for pumps) is typically very low, this results in very large electrical COPs. Note that such values are in no way representative for the thermodynamic performance of the TDHP.

Table 1-4: Definition of COP with theoretical and practical values for different technologies.

<span id="page-29-1"></span>

| Technology        | COP definition      | Maximum COP                               | Typical COPs   |
|-------------------|---------------------|-------------------------------------------|----------------|
| TDHP<br>–<br>heat | 𝑄̇<br>𝑝𝑟𝑜𝑐𝑒𝑠𝑠       | 𝑇𝐿<br>𝑇𝑀                                  | 1.3 – 2.2 [17] |
| pump              | 𝐶𝑂𝑃 =<br>𝑄̇<br>ℎ𝑖𝑔ℎ | 𝐶𝑂𝑃 = (1 −<br>) (<br>)<br>𝑇𝐻<br>𝑇𝑀<br>−𝑇𝐿 |                |
| TDHP<br>–<br>heat | 𝑄̇<br>𝑝𝑟𝑜𝑐𝑒𝑠𝑠       | 𝑇𝐿<br>𝑇𝐻<br>𝐶𝑂𝑃 = (1 −<br>) (<br>)        | 0.2 – 0.5      |
| transformer       | 𝐶𝑂𝑃 =<br>𝑄̇𝑤𝑎𝑠𝑡𝑒    | 𝑇𝑀<br>𝑇𝐻<br>−𝑇𝐿                           | [18], [19]     |
|                   |                     |                                           |                |
| VCHP              | 𝑄̇<br>𝑝𝑟𝑜𝑐𝑒𝑠𝑠       | 𝑇𝐻                                        | 2 – 5 [1]      |
|                   | 𝐶𝑂𝑃 =<br>𝑊̇<br>𝑒𝑙   | 𝐶𝑂𝑃 =<br>𝑇𝐻<br>− 𝑇𝐿                       |                |

In the next sections, absorption and adsorption machines are explained in detail. Heat pump and heat transformer cycles are discussed for both, and an overview is given of possible working pairs (refrigerant/sorbent pairs).

#### *1.2.2.3.* **Absorption machines**

Absorption machines can be classified as *absorption heat pumps* for heat amplification and *absorption heat transformers* for temperature upgrading.

## **Absorption heat pump**

The standard configuration of an absorption heat pump is the single-effect cycle shown in [Figure 1-16.](#page-30-0) The cycle works on two pressure levels: the generator and condenser operate at high pressure, while the evaporator and absorber work lower. In addition, a solution heat exchanger (SHX) is often added to increase the efficiency of the cycle.

In (a), a solution rich in refrigerant is pumped to a higher pressure level (b) and preheated through the SHX. When the rich solution reaches the generator (c), the heat input () enables the desorption of the refrigerant from the absorbent (g). Two streams leave the generator: the concentrated absorbent (low refrigerant fraction) and the gaseous refrigerant. The absorbent (d) passes through the solution heat exchanger (d-e) and is expanded from high to low-pressure (e-f) before reaching the absorber again. The gaseous refrigerant (g) is condensed, yielding useful heat (). The pressure of the liquid (h) is then reduced through a valve (i) and the liquid is then sent to the evaporator, where it is evaporated using ambient or waste heat ( ). Finally, the refrigerant (l) is absorbed again, producing useful heat () [17].

![](_page_30_Figure_1.jpeg)

*Figure 1-16: Thermodynamic cycle of a single-effect absorption heat pump.*

#### <span id="page-30-0"></span>**Absorption heat transformer**

[Figure 1-17](#page-30-1) presents the configuration of a single-effect absorption heat transformer, the standard configuration for this type of machine. The generator, which now operates at low pressure level, absorbs heat ( ) enabling the desorption of the refrigerant from the absorbent. The diluted mixture (h) is pumped to a higher pressure level and is sent to the absorber after crossing the heat recovery system (i-l). The gaseous refrigerant (a) flows to the condenser where it rejects heat ( ), often to the ambient. The liquid is then pumped to a higher pressure level (c), so that it can take up heat () in the evaporator. After evaporation, the gaseous refrigerant (d) enters the absorber, where it is absorbed, releasing useful heat (). Finally, the rich solution (e) goes through a heat recovery system (e-f) and finally is expanded to a lower pressure level through a valve (f-g) [17].

![](_page_30_Figure_5.jpeg)

*Figure 1-17: Thermodynamic cycle of a single-effect absorption heat transformer*

## <span id="page-30-1"></span>**Working pairs**

The working pairs (absorbent-refrigerant) preferred for absorption machines must have a high latent heat, high solubility, good stability at high temperatures and low corrosivity. They can be classified in three groups:

• *Water-based working pairs:* Water is an excellent refrigerant thanks to its large availability, low cost and good thermal properties. This category includes LiBr-water, which is a popular choice. Other

- water-based working pairs include binary salt-water solutions, multi-salt water solutions, acid and lye.
- *Ammonia-based working pair:* largely employed in commercial and industrial applications, this working pair can also work at temperatures below zero. Its major drawback is that the boiling temperatures of water and ammonia are similar. This category includes water-ammonia, salt-waterammonia and salt-ammonia solutions.
- *Organic-based working pairs:* These generally present good stability and low corrosivity at high temperatures. The main two types of working pairs in this category are alcohol based and halogenated hydrocarbon based working pairs.

## **1.2.2.4. Adsorption machines**

## **Adsorption heat pump**

The adsorption heat pump is described based on the single-bed adsorption heat pump cycle, as illustrated in [Figure 1-18.](#page-31-0) This cycle has four main components (evaporator, condenser, expansion valve and adsorbent bed) and additional control valves. The cycle consists of four processes, shown in [Figure](#page-32-0)  [1-19](#page-32-0) and described below.

- **1. (nearly) Isosteric heating (a-b):** During this process the bed is isolated by use of the control valves. Initially, the adsorbent bed is at low temperature and pressure and is rich in adsorbed refrigerant. When heat is supplied ( ), the bed temperature increases, so that the adsorption capacity decreases and some refrigerant is desorbed, implying a pressure rise. This process happens at quasi-constant adsorbate mass in the adsorbent bed (i.e. nearly isosteric).
- **2. Isobaric desorption (b-c):** After isosteric heating, the valve connecting the adsorbent bed and the condenser opens. The driving heat source continues to deliver heat to the adsorbent bed (), allowing regeneration of the adsorbent as the bed temperature increases. Desorption of the refrigerant from the adsorbent happens at constant pressure. The refrigerant vapor goes to the condenser where it rejects useful process heat () during condensation. Afterwards, the liquid refrigerant is expanded and flows to the evaporator.
- **3. (nearly) Isosteric cooling (c-d):** After isobaric desorption, the adsorbent bed is isolated again. Now the hot bed is cooled (), so that temperature decreases, and adsorption capacity increases. Some refrigerant is then readsorbed, causing a pressure decrease.
- 4. **Isobaric adsorption (d-a):** After isosteric cooling, evaporator and adsorbent bed are connected, enabling a refrigerant flow from the evaporator to the bed. In the evaporator, low temperature heat ( ) is supplied to evaporate the refrigerant. Next, the refrigerant vapor is adsorbed by the absorbent bed, releasing heat () while the bed temperature decreases.

![](_page_31_Figure_10.jpeg)

<span id="page-31-0"></span>*Figure 1-18: Thermodynamic cycle of an adsorption heat pump.*

![](_page_32_Figure_0.jpeg)

*Figure 1-19: Overview of the four main processes of an adsorption heat pump cycle.*

<span id="page-32-0"></span>The adsorption heat pump described above has an intermittent cycle, in contrast with absorption heat pumps. To provide useful heat in a more continuous way, two adsorbent beds can be operated in counter-phase [20].

In order to enhance the performance and compactness of basic adsorption heat pumps, more advanced cycles exists; multi-bed adsorption cycles, cascade cycles, thermal wave cycles, multi-stage cycles, etc. [13], [21].

#### **Adsorption heat transformer**

The adsorption heat transformer cycle, shown in [Figure 1-20](#page-33-0) and [Figure 1-21,](#page-33-1) is very similar to the adsorption heat pump cycle, but has a pump instead of an expansion valve. The main difference with the heat pump cycle is that adsorption and desorption are now pressure-driven isothermal processes, instead of isobaric temperature-driven processes.

- **(nearly) Isosteric heating (a-b):** In this process the adsorbent bed (low pressure, ) and the evaporator (high pressure, ) are connected. In the evaporator waste heat is supplied, inducing evaporation of the refrigerant. Due to the pressure difference, vapor flows from evaporator to adsorbent bed, increasing its pressure. This increases the adsorption capacity, hence some vapor is absorbed (exothermic reaction) and the adsorber temperature increases (from to ).
- **Isothermal adsorption (b-c):** After the desired temperature ( ) is reached, useful heat is continually released to the heat sink, causing further adsorption to become isothermal. The process ends once the pressure in the adsorbent bed equals the evaporator pressure.
- **(nearly) Isosteric cooling (c-d):** During the isosteric cooling phase the adsorbent bed (high pressure, ) is connected to the condenser (low pressure, ), which releases heat to a low temperature heat sink. Due to the pressure difference, refrigerant vapor will flow from the adsorbent bed to the condenser, decreasing the pressure in the bed. This causes some refrigerant to desorb, resulting in a temperature decrease of the bed to .
- **Isothermal desorption phase (d-a):** After the desired temperature () is reached, waste heat is supplied to the bed, so that desorption becomes isothermal. The process ends when the bed pressure reaches the condenser pressure. In order to restart the cycle, the condensate is returned to the evaporator by a small pump, consuming a negligible amount of power.

![](_page_33_Figure_0.jpeg)

*Figure 1-20: Thermodynamic cycle of an adsorption heat transformer.*

<span id="page-33-0"></span>![](_page_33_Figure_2.jpeg)

<span id="page-33-1"></span>*Figure 1-21: Overview of the four main processes of an adsorption heat transformer cycle, note that the adsorbent bed is never isolated.*

Again, an intermittent cycle is observed: in only one of the four processes, useful heat is released. Some advanced cycles (e.g. continuous cycles) are discussed in [22].

#### **Working pairs**

The selection of a suitable working pair is the most crucial choice when designing an adsorption machine and depends strongly on the application. Important thermophysical parameters and other parameters of the working pair are listed in [Table 1-5](#page-33-2).

Table 1-5: Desired properties of the working pair [21].

<span id="page-33-2"></span>

| Thermophysical properties                    | Other working pair properties           |
|----------------------------------------------|-----------------------------------------|
| Large uptake swing                           | High stability                          |
| High heat of vaporization of refrigerant     | Low cost                                |
| High density                                 | Non-toxic                               |
| High thermal conductivity                    | Non-flammable                           |
| Low binding energy                           | No global warming potential             |
| Low bed specific capacity                    | No ozone depletion potential            |
| Operating pressures marginally above ambient | Good compatibility with other materials |
| pressure                                     |                                         |

The stability of the refrigerant-adsorbent pair is a particularly important property, as it tends to decrease

over time. For high temperature applications, stability of the working pair is a major issue and will impact the heat pump's lifetime. Typical refrigerants used for adsorption machines are: water, ammonia, methanol and ethanol. Water is by far the most used, as high COPs can be achieved from water's high heat of vaporization, and due to the fact that it is non-toxic, non-flammable, inexpensive and has no impact on the environment. However, the vapor density of water is low, and sub-atmospheric operation may be required, complicating the design. In addition, it has a freezing point of 0 °C, preventing the use of low evaporator temperatures. Typical adsorbents are: zeolites, silica gel, activated carbons, metalorganic frameworks (MOFs), composites, etc. [13], [21].

#### <span id="page-34-0"></span>1.2.3. Ideal cycles and performance benchmarks

This section describes the ideal, thermodynamic cycles and necessary tools for evaluating the performance of a heat pump across various operating temperatures. These tools should be used to understand how close a given heat pump is to thermodynamically ideal conditions.

#### 1.2.3.1. Carnot and Lorenz cycles

The reversed Carnot cycle and the Lorenz cycle describe ideal, thermodynamic cycles that transfer heat from a cold reservoir to a hotter reservoir. This action requires the addition of work according to the second law of thermodynamics. In a common vapor compression cycle the work will be supplied by a compressor. The theoretically maximal performance of such a heat pump is given by the Carnot COP, COP<sub>Carnot</sub>, for operating between two reservoirs at constant temperature:

servoirs at constant tempton 
$${\rm COP_{Carnot}} = \frac{T_{\rm sink}}{T_{\rm sink} - T_{\rm source}}$$

Where  $T_{\rm sink}$  and  $T_{\rm source}$  are the absolute temperature of the heat sink and heat source, respectively.  $COP_{Carnot}$  then describes the heat delivered at  $T_{sink}$  for each unit of supplied work.

Commonly, neither the sink nor the source will be at constant temperatures but exhibit a temperature alide.

![](_page_34_Figure_8.jpeg)

Figure 1-22: Example of a heat sink and heat source with a temperature glide.

<span id="page-34-1"></span>Figure 1-22 shows an example of two temperature profiles where a heat pump is intended to operate between:

- Sink side (blue line): Heated up from 80 °C to 120 °C.
- Source side (red line): Cooled down from 40 °C to 30 °C.

With such temperature profiles, it is more appropriate to compare it to the Lorenz cycle instead of the Carnot cycle. The Lorenz COP, COP<sub>Lorenz</sub>, which for a reversible heat pump operating between two finite reservoirs is defined as:

$$\mathsf{COP}_{\mathsf{Lorenz}} = \frac{\overline{T}_{\mathsf{sink}}}{\overline{T}_{\mathsf{sink}} - \overline{T}_{\mathsf{source}}}$$

 ${\rm COP_{Lorenz}} = \frac{\overline{T}_{\rm sink}}{\overline{T}_{\rm sink} - \overline{T}_{\rm source}}$  It is here assumed that the heat sink and heat source have constant heat capacity, and the entropic mean temperatures of the sink and source are further defined as:

$$\overline{T}_{\rm sink} = \frac{\Delta T_{\rm sink}}{\ln\left(\frac{T_{\rm sink,out}}{T_{\rm sink,in}}\right)} \, {\rm and} \, \, \overline{T}_{\rm source} = \frac{\Delta T_{\rm source}}{\ln\left(\frac{T_{\rm source,in}}{T_{\rm source,out}}\right)}$$

Which for the given example yields entropic mean temperatures of:

The yields entropic mean temperatures of:
$$\overline{T}_{\text{sink}} = \frac{\Delta T_{\text{sink}}}{\ln\left(\frac{T_{\text{sink,out}}}{T_{\text{sink,in}}}\right)} = \frac{393.2 \text{ K} - 353.2 \text{ K}}{\ln\left(\frac{393.2 \text{ K}}{353.2 \text{ K}}\right)} = 372.8 \text{ K}$$

$$\overline{T}_{\text{source}} = \frac{\Delta T_{\text{source}}}{\ln\left(\frac{T_{\text{source,in}}}{T_{\text{source,out}}}\right)} = \frac{313.2 \text{ K} - 303.2 \text{ K}}{\ln\left(\frac{313.2 \text{ K}}{303.2 \text{ K}}\right)} = 308.2 \text{ K}$$

And the corresponding  $\ensuremath{\text{COP}_{\text{Lorenz}}}$  can then be calculated as

$$COP_{Lorenz} = \frac{\bar{T}_{sink}}{\bar{T}_{sink} - \bar{T}_{source}} = \frac{372.8 \text{ K}}{372.8 \text{ K} - 308.2 \text{ K}} = 5.77$$

The calculated COP<sub>Lorenz</sub> can be used to investigate the performance of studied HTHP systems and use cases. If a  $\text{COP}_{\text{heating}}$  for the given temperatures is stated to be to 3.5 the Lorenz efficiency is calculated as the following ratio [23]:

$$\eta_{\text{Lorenz}} = \frac{\text{COP}_{\text{heating}}}{\text{COP}_{\text{Lorenz}}} = \frac{3.5}{5.77} = 61 \%$$

 $\eta_{\rm Lorenz} = \frac{{\rm COP_{heating}}}{{\rm COP_{Lorenz}}} = \frac{3.5}{5.77} = 61 \, \%$  It should be noted that the Lorenz cycle approaches the Carnot cycle when the temperature glides of both the sink and in the source approach zero.

#### 1.2.3.2. Analysis with crossing temperature profiles.

When analyzing the Lorenz efficiency and temperature lift for a crossing temperature profile only the heat pumping part of the possible heat transfer is included in the analysis.

![](_page_35_Figure_10.jpeg)

Figure 1-23 Example of crossing temperature profile for sink and source side.

<span id="page-35-0"></span>Figure 1-23 shows an example of a crossing temperature profile with the following temperature profile:

- Sink side (blue line): Heated up from 20 °C to 190 °C.
- Source side (red line): Cooled down from 110 °C to 100 °C.
- The sink side can then be split up with a direct heat exchange part ranging from 20 °C to 110 °C, and a heat pumping part ranging from 110 °C to 190 °C.

With such a temperature profile the direct heat exchange part can then be calculated as:

Direct heat exchange part = 
$$\frac{T_{\text{source,in}} - T_{\text{sink,in}}}{T_{\text{sink,out}} - T_{\text{sink,in}}} = \frac{110 \text{ °C} - 20 \text{ °C}}{190 \text{ °C} - 20 \text{ °C}} = \frac{90 \text{ °C}}{170 \text{ °C}} = 52.9 \text{ %}$$

The heat pumping part can be calculated as:

Heat pumping part = 
$$\frac{T_{\text{sink,out}} - T_{\text{source,in}}}{T_{\text{sink,out}} - T_{\text{sink,in}}} = \frac{190 \text{ °C} - 110 \text{ °C}}{190 \text{ °C} - 20 \text{ °C}} = \frac{80 \text{ °C}}{170 \text{ °C}} = 47.1 \text{ %}$$

If a  $COP_{heating}$  for the given example is stated to be 3.5, the  $COP_{heating}$  is then scaled with the heat pumping part:

$$COP_{heating,heat pump part} = 0.471 * COP_{heating} = 1.65$$

which with a COP<sub>Lorenz</sub> valid for the heat pumping part (hear calculated to be 9.64) then can be used to define a Lorenz efficiency for the heat pumping part:

$$\eta_{\text{Lorenz,heat pumping part}} = \frac{1.65}{9.64} = 17.1 \%$$

The temperature lift for a crossing temperature profile is also defined in this analysis only for the heat pumping part, which can be calculated to the following with the numbers in the above example:

$$\Delta \bar{T}_{\text{lift,HP part}} = \frac{\Delta T_{\text{sink}}}{\ln\left(\frac{T_{\text{sink,out}}}{T_{\text{sink in}}}\right)} - \frac{\Delta T_{\text{source,in}}}{\ln\left(\frac{T_{\text{source,in}}}{T_{\text{source out}}}\right)} = \frac{(463.2 \text{ K} - 383.2 \text{ K})}{\ln\left(\frac{463.2 \text{ K}}{383.2 \text{ K}}\right)} - \frac{(383.2 \text{ K} - 373.2 \text{ K})}{\ln\left(\frac{383.2 \text{ K}}{373.2 \text{ K}}\right)} = 43.8 \text{ K}$$

#### <span id="page-36-0"></span>1.3. Applications

This chapter summarizes the scope of applications and provides examples of possible heat sources and heat sinks. Further, current studies on the estimation of application potentials may be summarized here.

#### <span id="page-36-1"></span>1.3.1. Industrial Processes

This section outlines the application of heat pumps with sink temperature in the temperature range of 100 °C to 200 °C. This will be the largest application area for this technology.

#### 1.3.1.1. Process heat source and sink

The integration of HTHP in industrial processes comes when a series of energy efficiency measures have already been considered. The efficiency of heat pumps (COP) makes their integration into industrial processes very attractive, either for operational costs or for decarbonization of the industrial processes. Some of them require external mechanical, thermal energy source or both to operate [24].

The industrial processes where HTHP can be applied are diverse, however, their feasibility depends mainly on the temperature range, the stability, the capacity and the glide of both the source & the sink sides. Moreover, the type of process (batch or continuous), the annual operating hours and the type of energy carrier (fuel, electricity) used to heat up the processes are important techno-economic factors.

To be economically viable the main requirement for a HTHP integration into an industrial process is to have an adequate heat source. Typical heat sources that a heat pump can utilise are as follows:

- Waste heat from industrial processes
  - o Refrigeration or cooling plant heat sink
  - o Cooling water (directed to cooling tower)
  - o Radiant heat from product
  - o Air with high moisture content
- Recirculation streams in processes
- Heat from renewable sources (low or zero cost)
  - Solar thermal
  - Geothermal
  - Sea or river water
  - o Ambient air

<span id="page-37-0"></span>Table 1-6, Potential processes and their respective sectors in which HTHPs could be implemented (Source: [1]).

![](_page_37_Figure_1.jpeg)

On the other hand, heat sink temperatures of HTHP units for industrial applications are considered to be above 100°C. Some of the main processes that have been identified for potential applications are drying, boiling, bleaching, pasteurization, sterilization, distillation, moulding and colouring. The main industries using these processes are pulp & paper, food & beverage, chemicals, metal, plastic, automotive, wood, textiles, etc. In [Table 1-6](#page-37-0) are listed the industrial processes where HTHPs can be implemented and their respective sectors.

The sink side of closed-loop HTHP can be integrated in the process stream either directly using the condenser(s) and/or subcooler to heat the flow, or to heat a utility stream (secondary loop) used as a heating medium to heat a process. Another way to integrate a vapor compression HTHP is with mechanical vapor recompression (MVR) systems. This system has been studied lately for application in the oil & gas industry as process intensification measure in distillation units, where energy consumption reduction is up to 65 % [25].

## **1.3.1.2. Application Potential**

There have been numerous attempts in the literature to quantify the application potential of heat pumps for the industrial sector. Marina et al [26] indicated that, in general, there are two approaches to estimate application potential: a top-down approach and a bottom-up approach. The top-down approach usually starts with the total energy use of a sector and determines which part is used for heating purposes. Thereafter, this heating demand is divided across temperature intervals based on a fraction of the total heat demand. Although this method provides relatively quick estimates, it lacks specific process information. It is not possible to derive the capacity of a heat pump for a specific application this way. The bottom-up approach analyses individual processes and aggregates this to a higher level. This usually results in limited market coverage but can provide information on capacity of heat pumps and specific temperature conditions. The nature of industrial heat pump operation, whereby a waste heat source is upgraded in temperature to produce process heat requires that heat pump application potential is most accurately determined from information obtained on an individual process level, rather than generalised data from a sectoral or total industrial level.

There have been a number of published studies which attempt to quantify the application potential of industrial heat pump technology. The most notable works are summarised below:

Wolf and Blesl [27] conducted a study focused on quantifying the entire industrial heat pump market on a European level. This study was however restricted in that the heat pump sink temperature was limited to 100°C. The focus was primarily on the calculation of bulk energy saving and CO<sup>2</sup> abatement potential (both economic and technical). The combined top-down and bottom-up methodology utilised for calculating waste and process heat amounts and temperature levels, led to the calculation of a final energy consumption reduction potential of 1717 PJ in the sectors investigated. Based on use of energy price data (from 2013) it was estimated that 270 PJ of final energy savings were economically feasible. The total CO<sup>2</sup> abatement potential amounted to 86.2 Mt (17 % of the energy related CO2 emissions of the EU-28 for the industrial sector), of which 21.5 Mt were covered by economically feasible cases.

Kosmadakis [28], presented a study whereby the potential of industrial heat pumps was estimated focusing on applications in the temperature range of 100 °C to 200 °C. Process and waste heat quantities were derived separately, but in general consisted of aggregated values grouped into temperature level and broad application. The heat pump potential was calculated on this aggregated level, estimated to be 102 PJ in EU industries.

Marina et al. [26] conducted a study to estimate the European (EU28) industrial heat pump market potential in terms of magnitude, sizing and number of units. Potential heat pump applications in the food, paper, chemical and refining sectors were identified considering a maximum sink temperature of 200°C. This study utilised a bottom-up methodology that uses detailed information from individual processes in the aforementioned sectors. Combining individual process data with typical plant capacities provides information on the heating capacities of heat pumps. The data is upscaled to European level, using production statistics relevant to the individual processes analysed. Since the database of processes used was generic in nature and not fully covering the whole industrial sector, the results of this analysis provided a conservative estimate of the heat pump market potential. The results show a potential cumulative heating capacity of industrial heat pumps in EU28 of 23.0 GW, consisting of 4174 heat pump units which are able to cover 641 PJ/a of process heat demand. A notable result from this study was the distribution of the heating capacity for the heat pump units which make up the heat pump market as seen in [Figure 1-24.](#page-39-0) The largest number of heat pump units (%) can be found for heating capacities <10 MW, making up about 50% of the total market cumulative heating capacity.

![](_page_39_Figure_0.jpeg)

<span id="page-39-0"></span>*Figure 1-24: Distribution of the heating capacity (<30 MW) for the heat pump units which make up the EU28 industrial heat pump market estimated by Marina et al.* [26]

Finally an IEA special report [29] created a comprehensive and detailed roadmap to achieve net zero energy related and industrial process CO<sup>2</sup> emissions globally by 2050. For the net zero emission scenario, a breakdown is given for technologies used to cover the industrial heat demand in light industries up to 2050 (see [Figure 1-25\)](#page-39-1). The scenario outlines the large role for heat pumps for supplying low (<100 °C) and some medium (100-400 °C) heat, with heat pumps covering 30 % of total heating demand in these sectors in 2050. In the IEA net zero emission scenario, around 500 MW of heat pumps need to be installed every month over the next 30 years.

![](_page_39_Figure_3.jpeg)

<span id="page-39-1"></span>*Figure 1-25: Share of heating technology by temperature level in light industries in the IEA net zero emission scenario* [29]*.*

#### **1.3.1.3. Simultaneous heating and cooling**

The temperature difference between the source and the sink side of a HTHP is inversely proportional to the COP of the system. Common source/sink side temperature difference values are between 60 K to 80 K. For HTHPs that are integrated into a process in which the source side is cooling down a process stream rather than using waste, the performance of the HTHP increases substantially. This type of configuration is highly recommended for higher COP values and therefore lower operational costs.

The first heat pump applications are being applied in the food and beverage sector, which traditionally has the most experience with this technology as refrigeration equipment. The need for simultaneous heating and cooling in the food industry is itself a driver for first heat pump applications. Cooling of products will produce waste heat at temperatures above ambient, which can be upgraded using a heat pump to satisfy the process heating requirements.

Coupling process heating and cooling needs through the use of a heat pump will result in high process efficiencies and low operational costs. As such, this solution is gaining traction in the market. It is expected that the experience gained from the use of heat pumps in this way can be transferred to utilise a multitude of waste heat streams in both the food sector as well as in other industrial sectors.

#### **1.3.1.4. Level of process integration**

An electrically driven heat pump is process equipment configured with compressors, heat exchangers, valves, vessels, and piping. The modular nature ensures that the technology is flexible, and it may be developed and installed for a broad range of applications, capacities, and temperature levels. This, however, also indicates that there are several potential solutions for a given application and that the right choice will depend on performance, efficiency, investment, technology readiness level, and regulations.

Compared to conventional steam-based systems heated by fuel combustion in a boiler, heat pump technology offers highly different options, ranging from intrinsic integration into a given process, integration at the process unit level, or as replacement for a central heating system.

Intrinsic integration into a process can require little additional process equipment and at the same time achieve the highest COP, as high as 20 units heating per unit electricity consumed. However, at the same time it may lead to significant changes to the process and conditions, the feasibility of which may need to be assessed.

Mechanical vapor recompression (MVR) is an example of integration into drying processes by compressing water vapor from the process and condensing it higher pressure and accordingly providing the heating needed for drying. An example of such an application is given in [Figure 1-26.](#page-40-0)

![](_page_40_Figure_8.jpeg)

*Figure 1-26: Example of intrinsic heat pump integration through MVR*

<span id="page-40-0"></span>A heat pump can also be coupled to the process at a unit level. Again, the COP is mainly dependent on the relative temperature levels of the heat source and sink but will generally result in lower COPs when compared with intrinsic integration in the process.

The final option is a central heat pump solution substituting an existing heating installation at the utility level, which will require the fewest changes in the existing process. This solution will have a lower COP because the generation of heat from the central utility system requires a higher temperature that is sufficient for all processes.

### <span id="page-41-0"></span>**1.3.2. Other applications**

## **1.3.2.1. Power-to-heat-to-power**

Nowadays, electricity from renewable energy systems is the main objective of the energy agenda of most countries. The main disadvantage of renewable energy systems (RES) is the intermittent pattern of their production, which is usually not simultaneous with the power peak demand periods. Electrical energy storage for power grids is the solution to enhance the RES grids' reliability. Several possible systems can be implemented for power storage, including batteries, pumped hydro, compressed air, or pumped thermal energy storage systems. Compressed air and pumped hydro are dependent on geological constraints, while batteries are a costly way to store electricity for large-scale power systems.

On the other hand, pumped thermal energy storage systems, which are basically Carnot batteries, can store electricity in the form of heat. Thermal storage systems are cheaper than power storage systems and can be installed independently of geological or geographical features. HTHP systems can be part of pumped thermal energy storage systems as the thermal charging system. Surplus power is used by the HTHP to charge the thermal storage with high temperature heat. When electricity is required, the stored heat is used to drive a thermal power cycle (i.e. ORC) obtaining electricity during the discharging process and delivering it to the grid. These systems can reach high roundtrip efficiency values and allow the integration of low temperature heat sources coming from industrial waste heat, solar thermal, geothermal, data center installations, etc. [30].

![](_page_41_Picture_6.jpeg)

*Figure 1-27 Schematic diagram of the working principle of a pumped thermal energy storage system* [31]*.*

Depending on the temperature conditions of the heat source and the heat sink, the size of the thermal storage systems and the capacity of both the charging and discharging systems the roundtrip efficiency of a pumped thermal energy storage system can reach values of 1, as presented by Trebilcock [31].

## <span id="page-42-0"></span>**2. Overview of Technologies**

As part of the HTHP technology review, information about a wide range of different supplier technologies, commercially available and under development, has been collected in two-page summaries. These descriptions can be found on the Annex 58 homepage, please see the following link: <https://heatpumpingtechnologies.org/annex58/task1/>

In this chapter, the information collected in these summaries are analysed to give an overview of developments (TRL 4-9 considered) and potentials for high-temperature heat pumps.

## <span id="page-42-1"></span>**2.1. Overview of collected information**

The information was collected from the various suppliers in a standardized way using a common review template. The suppliers have provided all information without third-party validation. The information was provided as an indicative basis and may be different in final installations depending on applicationspecific parameters. Please note that a broad range of different HTHP technologies has been collected, and that some of the technologies indicate a TRL corresponding to a status of prototype demonstration, while a TRL of 9 can indicate a readiness level only valid for specific use cases.

The information collected about the technologies in general includes information about:

- System layout/type
- Compressor type
- Working fluid
- Capacity range
- Development status (TRL level)
- Maximum supply temperature or other limitations
- Expected lifetime
- Size
- Information on sub-components
- Range for specific investment cost for installed system without integration
- Performance data for use cases with COPheating and temperature glides on sink and source side
- Project examples

In total, information 34 different HTHP technologies with over 80 different use case examples have been collected. An overview of the suppliers and key information is summarized in [Table 2-2](#page-43-0) on the next pages. From the table it can be seen that there is a wide range of different technologies for HTHP from the various suppliers, and that the suppliers indicate a very varying TRL levels and costs, which depends on the given application and size of the heat pump. For several of the cases the stated costs are estimates or cost targets for future developments, especially for cases with low TRL. For the definition of TRL, please see [Table 2-1.](#page-42-2)

*Table 2-1: Definition of TRL levels* [32]*.*

<span id="page-42-2"></span>

| TRL 1 | Basic principles observed                                            |
|-------|----------------------------------------------------------------------|
| TRL 2 | Technology concept formulated                                        |
| TRL 3 | Experimental proof of concept                                        |
| TRL 4 | Technology validated in lab                                          |
| TRL 5 | Technology validated in relevant environment (industrially relevant  |
|       | environment in the case of key enabling technologies)                |
| TRL 6 | Technology demonstrated in relevant environment (industrially        |
|       | relevant environment in the case of key enabling technologies)       |
| TRL 7 | System prototype demonstration in operational environment            |
| TRL 8 | System complete and qualified                                        |
| TRL 9 | Actual system proven in operational environment (competitive         |
|       | manufacturing in the case of key enabling technologies; or in space) |

*Table 2-2: Overview of suppliers and HTHP technology, sorted after maximum capacity.*

<span id="page-43-0"></span>

| Supplier                                 | Compressor<br>type         | Working fluid                                                          | Capacity<br>[MW] | Tmax,supply<br>[°C] | TRL<br>indication         | Spec. invest.<br>cost [€/kW] |
|------------------------------------------|----------------------------|------------------------------------------------------------------------|------------------|---------------------|---------------------------|------------------------------|
| Fuji Electric                            | Reciprocating              | R-245fa                                                                | 0.03             | 120                 | 9                         | n/a                          |
| Emerson                                  | Scroll and EVI<br>scroll   | R-245fa, R<br>410a, R-718                                              | 0.03             | 120                 | 6                         | n/a                          |
| Mayekawa<br>(EcoSirocco)                 | Reciprocating              | R-744                                                                  | 0.1              | 100                 | 8-9                       | n/a                          |
| Mayekawa<br>(EcoCircuit)                 | Reciprocating              | R-1234ze(Z)                                                            | 0.1              | 120                 | 9                         | n/a                          |
| Skala Fabrikk                            | Piston<br>(semiher.)       | R-290+R-600                                                            | 0.3              | 115                 | 7 (proto.<br>demo.)       | 500-700                      |
| Kobelco<br>Compressors<br>Corp. (SGH120) | Two stage<br>twin -screw   | R-245fa                                                                | 0.37             | 120                 | 9                         | n/a                          |
| Mitsubishi<br>Heavy Ind.                 | Two-stage<br>centrifugal   | R-134a                                                                 | 0.6              | 130                 | 9                         | n/a                          |
| Kobelco<br>Compressors<br>Corp. (SGH165) | Twin-screw                 | R-245fa+R-134a<br>(mixture), R-718<br>for steam comp.                  | 0.624            | 175                 | 9                         | n/a                          |
| ecop                                     | Centrifugal<br>compression | ecop fluid 1                                                           | 0.7              | 150                 | 6-7                       | 700                          |
| Mayekawa<br>Europe (HS<br>comp.)         | Piston                     | R-600                                                                  | 0.75             | 120                 | 7                         | 450                          |
| Kobelco Comp.<br>Corp.<br>(MSRC160)      | Twin -screw                | R-718                                                                  | 0.8              | 175                 | 9                         | n/a                          |
| Mayekawa<br>Europe (FC<br>comp.)         | Screw                      | R-601                                                                  | 1.0              | 145                 | 5                         | 720                          |
| GEA<br>Refrigeration<br>Netherlands      | Semi-hermetic<br>piston    | R-744                                                                  | 0.1-1.2          | 130                 | 8                         | 200-300                      |
| Fenagy                                   | Reciprocating              | R-744                                                                  | 0.3-1.8          | 120                 | 5-6<br>(concept<br>study) | 250-425                      |
| Rank                                     | Screw                      | R-245fa, R<br>1336mzz(Z),<br>R-1233zd(E)                               | 0.12-2.0         | 160                 | 7<br>(prototype<br>demo.) | 200-400                      |
| SRM                                      | Screw                      | R-718                                                                  | 0.25-2.0         | 165                 | 5                         | n/a                          |
| COMBITHERM<br>GmbH                       | Screw                      | R-1233zd(E),<br>R-1234ze,<br>R-515B,<br>R-450A,<br>R-513A,<br>R-1234yf | 0.3-3.3          | 120                 | 9                         | 200-400                      |
| Sustainable<br>Process Heat              | Piston                     | HFOs                                                                   | 0.3-5.0          | 165                 | 6-8                       | 150-1000                     |
| Johnson<br>Controls                      | Reciprocating              | R-717+R-600<br>(cascade)                                               | 0.5-5.0          | 120                 | 7-8 (for HC<br>top cycle) | n/a                          |
| Hybrid Energy                            | Piston, screw              | R-717 and R<br>718                                                     | 0.5-5.0          | 120                 | 9                         | 200-600                      |
| ToCircle                                 | Rotary vane                | R-717+R-718                                                            | 1.0-5.0          | 188                 | 6-7                       | 250-430                      |
| Weel & Sandvig                           | Turbo                      | R-718                                                                  | 1.0-5.0          | 160                 | 4-9                       | 150-250                      |
| Olvondo                                  | Piston (double<br>acting)  | R-704                                                                  | 5.0              | 200                 | 9                         | 1200                         |

| Heaten                  | Reciprocating,<br>custom design                                         | HFO and HC                                   | 1.0-6.0   | 200 | 7-9                                                                      | 250-350   |
|-------------------------|-------------------------------------------------------------------------|----------------------------------------------|-----------|-----|--------------------------------------------------------------------------|-----------|
| Enerin                  | Piston                                                                  | R-704                                        | 0.3-10.0  | 250 | 6<br>(prototype<br>testing)                                              | 600-800   |
| Aneo Industry           | Centrifugal fan<br>and piston<br>comp.                                  | R-717, R-718                                 | 1.2-10.0  | 150 | 7-8                                                                      | n/a       |
| Enertime                | 1 or 2 stage<br>centrifugal<br>hermetic<br>compressor                   | R-1336mzz(Z),<br>R-1224yd(Z),<br>R-1233zd(E) | 2.0-10.0  | 160 | 4-8<br>(depending<br>on concept)                                         | 300-400   |
| Spilling                | Piston                                                                  | R-718                                        | 1.0-15.0  | 280 | 9                                                                        | 100-400   |
| Epcon                   | High-pressure<br>centrifugal<br>fan; positive<br>displacement<br>blower | R-718                                        | 0.5-30.0  | 150 | 9                                                                        | 200-400   |
| Turboden                | Turbo                                                                   | Application<br>specific                      | 3.0-30.0  | 200 | 7-9                                                                      | 300-700   |
| MAN Energy<br>Solutions | Centrifugal<br>turbo-comp.<br>with expander                             | R-744                                        | 10.0-50.0 | 150 | 7-8                                                                      | 300-500   |
| Piller                  | Turbo                                                                   | R-718                                        | 1.0-70.0  | 212 | 8-9                                                                      | 850       |
| Siemens<br>Energy       | Turbo<br>(geared-type<br>or single<br>shaft)                            | R-1233zd(E)/<br>R-1234ze(E)                  | 8.0-70.0  | 160 | 9 (up to 90<br>°C), pilot<br>plant at 120<br>°C currently<br>being built | 250-800   |
| Qpinch                  | Chemical<br>adsorption<br>heat<br>transformer<br>(no comp.)             | Water, H3PO4<br>and derivatives              | > 2.0     | 230 | 9                                                                        | 1000-2000 |

## <span id="page-44-0"></span>**2.2. Description of Supplier HTHP Technology**

As seen in [Table 2-2,](#page-43-0) several suppliers are currently working with and developing various HTHP technology at different TRL levels and capacities. The compressor is a key component with a high relevance for the development status of HTHP systems. The development of the various compressor technologies for operating at higher temperatures can be divided into the following three categories:

- Compressors from the process industry: This is typical application specific designs with relative high capacities, and compressors already available in the industry, which also can be used in connection with a heat pump system. These compressors have large potentials in large scale application and relative low maintenance costs.
- Modified refrigeration compressors: Includes standard compressors based on cost-effective, proven technology, which continuously have been modified to operate at higher temperatures. Typical compressors have lower capacities than compressors from the process industry.
- Novel and adapted compressor technologies: This includes compressor technologies based on (and strongly adapted) equipment from automobiles (e.g. turbo compressors with high potential for mass production), pumps, Stirling engines, etc.

Each of the supplier descriptions are in the following sections shortly summarized and categorized to these overall compressor categories. Please refer to the Annex 58 homepage for full supplier HTHP technology descriptions. It may be noted that some of the suppliers are using combinations of different compressor technologies, which could have justified including them in multiple categories.

#### <span id="page-45-0"></span>**2.2.1. Compressors from the process industry**

#### **2.2.1.1. Aneo Industry**

The core technology of Aneo Industry is an integrated heat pump system which can supply process heat in the form of pressurized steam of up to 150 °C or 5 bar(a). The steam producing heat pump (SPHP) is standardized for excess heat temperatures between 20 °C and 90 °C. The SPHP integration includes an energy recovery unit for moist air, however also other excess heat sources can be integrated. The recovered heat is transferred to a bottom cycle which upgrades the energy into low pressure steam. The bottom cycle uses ammonia (R-717) as working media. The low-pressure steam is further compressed by multistage steam compressors.

The principal layout of the SPHP is given and is a combination of a closed loop bottom cycle and an open loop top cycle (typically known as Mechanical Vapor Recompression). The top cycle can also be integrated as closed loop according to process requirements. The heat supply capacity can optionally be up to 10 MW.

![](_page_45_Figure_4.jpeg)

*Figure 2-1: Steam producing heat pump with excess heat recovery and multi-stage compression.*

## **2.2.1.2. Enertime**

High-temperature heat pumps and steam generators heat pumps from Enertime are custom made solutions adapted to industrial constraints and project needs. The heat pumps are using new-generation non-flammable HFO fluids and custom-made centrifugal compressors with rotation speeds up to 20,000 RPM and compression ratios up to 3.2. Enertime compressors are using 1 or 2 high speed hermetic motors and magnetic bearings to reach the highest possible performance while ensuring an oil-free and wear-free operation, low vibration rates, and low noise emissions. The capacity range is from 2 MW to 10 MW, and the temperature is up to 160 °C regarding steam generation.

![](_page_45_Picture_8.jpeg)

*Figure 2-2 Example of Enertime Heat Pump with a capacity of 3.7 MW.*

#### **2.2.1.3. Spilling**

The technology from Spilling is an electric-driven steam piston compressor, which can be used both in an open HTHP cycle with steam recycling and in a closed HTHP cycle. The design of the compressors is application-specific and is based on a modular design with 1 to 6 cylinders.

The compressor portfolio covers steam flows between approx. 2 t/h to 20 t/h and thermal loads between

approx. 1 MW to 15 MW. The pressure increase of each stage is possible up to a factor of 3 per compression stage, and with a triple-stage compressor, a temperature increase of >100 K is possible in the same unit. Typical temperatures for the source and sink are above 120 °C and below 250 °C, respectively.

![](_page_46_Picture_1.jpeg)

*Figure 2-3: 3D drawing of a Spilling steam compressor.*

#### **2.2.1.4. Epcon**

The Mechanical Vapor Recompression (MVR) system from Epcon can have an open or a closed loop layout. The compression technology consists of high-pressure centrifugal fans or positive displacement blowers. The system uses water as a working fluid, and features serial compression steps for flexible system design and optimized COP. The MVR temperature lift is 30 to 60 °C.

For example, the technology is well suited in a cascade system with bottom cycle HP. Relevant applications include Industries with existing- or new thermal separation processes such as evaporation, distillation, drying, and/or plants with excess applicable thermal energy. The lower capacity range is 1 to 3 MW, and the higher capacity range is 10 to 30 MW.

![](_page_46_Picture_6.jpeg)

*Figure 2-4: Epcon compact MVR fans.*

## **2.2.1.5. Turboden**

Turboden makes systems with a thermal power output from 3 to 30 MW per single unit and uses a turbo compressor. The temperature lift can be up to 100 K by making custom designs, and the maximum temperature is 200 °C. Different working fluids can be used, including hydrocarbons and siloxanes.

![](_page_47_Picture_0.jpeg)

*Figure 2-5: Turboden large heat pump (LHP).*

## **2.2.1.6. MAN Energy Solutions**

The MAN high temperature industrial heat pump system has been derived from the Electro-Thermal Energy Storage technology developed originally by ABB and further developed by MAN Energy Solutions. The working fluid is CO<sup>2</sup> operated in an optimized transcritical heat pump cycle with a centrifugal turbo-compressor (HOFIM compressor) with integrated expander.

The system is customized to the specific customer requirements for several applications in three frame sizes (small-middle-large) depending on the duty varying between 10 MW to 50 MW thermal supply capacity per unit. Typical applications are for district heating plants and process industry applications demanding medium to high supply temperatures (up to 150 °C). By using CO<sup>2</sup> as working fluid a temperature lift up to 150-170 °C can be achieved.

![](_page_47_Picture_5.jpeg)

*Figure 2-6: General arrangement of typical MAN Energy heat pump system.*

#### **2.2.1.7. Piller**

Piller makes compressors and blowers for open loop MVR cycles and steam heat pumps. The design of the individual blowers and compressors (radial turbomachine) and their interconnection in a multistage system are adapted to achieve the needed compression of the working fluid. The bearings are forced-oil lubricated with no oil in contact with working fluid/process vapors. The Piller technology is used for large industrial plants with high temperature steam demand or direct vapor recompression for heating column reboilers and evaporators. The max. supply capacity is 70 MW, and the temperature range is between 40 °C - 230 °C.

![](_page_48_Picture_0.jpeg)

![](_page_48_Picture_1.jpeg)

*Figure 2-7: left - PILLER High Performance Blower, right - multi-stage system in operation.*

## **2.2.1.8. Siemens Energy**

Siemens Energy heat pumps are designed for a particular application depending on required capacity, temperatures of sink and source, boundary conditions at site as e.g. electrical connection or available space. A variety of different cycle designs is possible, e.g. in closed systems in different configurations (with or without flash box, internal heat exchanger, cascade, etc.) The compressor drive can be electrical or mechanical (gas engine or gas/steam turbine), both variants within Siemens Energy scope. Most relevant applications are chemical, pulp & paper, food & beverage and district heating. The compressor technology as geared-type or single-shaft depending on application and available space.

The heat supply capacity is between 8 to 70 MW in one unit with one turbo compressor, while laboratory demonstration of a kW-size heat pump with temperatures up to 160 °C with R-1233zd among other the tested working fluids. A pilot plant with 8 MW capacity and 120 °C supply temperature is currently being built for Vattenfall in Berlin for a district heating application. A case with sink outlet temperature of 190 °C by using steam compression is also mentioned in the suppler technology description.

![](_page_48_Picture_6.jpeg)

*Figure 2-8: Exemplary model of a new Siemens Energy high temperature heat pump.*

## <span id="page-48-0"></span>**2.2.2. Modified refrigeration compressors**

#### **2.2.2.1. Fuji Electric**

The steam generation heat pump from Fuji Electric was commercialized in 2015. This heat pump can be used as an alternative to the low-pressure steam boiler used for heating processes. The heat pump is expected to be installed near each heating process. Installing the heat pump near the process can reduce the heat loss as well as effectively recover the waste heat from the process. For the easy installation near the process, this heat pump is made compact.

The system has a steam generation part and a heat pump cycle part. The heat pump lifts the heat from the heat source water (60-80 °C) and sends the heat to the feed water. The feed water is preheated at the subcooler and evaporated at the condenser. The water is sent to the steam separator in the form of wet steam. Saturated steam (up to 120°C, 0.1 MPaG) from the separator is controlled with the pressure regulator and supplied to a heating process. While saturated water from the separator is mixed with the preheated feed water and returned to the condenser.

For the working fluid of the heat pump, R-245fa is selected because of its high critical temperature of 154 °C. The compressor is a reciprocating type. The subcooler improves the heat pump cycle efficiency as well as preheats the feed water.

![](_page_49_Figure_1.jpeg)

*Figure 2-9: External appearance and element configuration for Fuji Electric heat pump.*

#### **2.2.2.2. Emerson**

Emerson has developed a prototype of a cascade high temperature industrial heat pump system, where the compressor model is specialized for high-temperature applications. The system is designed for two functions, one is to obtain stable hot air supply at 120 °C, and the other function of the cascade system is designed to expand multiple heat sources such as industrial wastewater heat recovery or air conditioning processes.

The heat supply capacity is 30 kW. The system can be divided into three parts, LT cycle, HT cycle and hot air chamber. The LT cycle is a loop with R-410A refrigerant. The compressor is a variable speed model of Emerson ZWW050. The HT cycle refrigerant is R-245fa. Two EVI fix-speed compressors of high temperature heating compressor models are installed in parallel.

![](_page_49_Figure_6.jpeg)

*Figure 2-10: Prototype and internal design of cascade system.*

## **2.2.2.3. Mayekawa**

Mayekawa commercialized a one-way CO<sup>2</sup> air heater heat pump (Eco Sirocco) in 2009 and a hot air circulation heat pump (Eco Circuit) in 2018. Eco Sirocco is suitable for applications in drying processes with large temperature glides at the heat sink, and supplies hot air up to 120 °C. On the other hand, the Eco Circuit is suitable for applications in drying processes with small temperature glides at the heat sink, and supplies hot air up to 85 °C. A new product Eco Circuit 100 was commercialized in 2021. This heat pump supplies hot air up to 100 °C as a result of improving the existing Eco Circuit. The higher supply temperature expands the application of the heat pump in more drying processes.

The heat supply capacity is 100 kW class, while the compressor for both Eco Circuit and Eco Sirocco is a reciprocating type. The working fluid for Eco Circuit is R-1234ze(E).

![](_page_50_Picture_0.jpeg)

![](_page_50_Picture_1.jpeg)

*Figure 2-11: left - CO<sup>2</sup> Air Heater HP (EcoSirocco), right - Hot Air Circulation HP (EcoCircuit 100).*

## **2.2.2.4. Skala Fabrikk**

The SkaleUP Cascade HTHP from Skala Fabrikk is a unit for a) simultaneous ice- and process hot water production or b) utilization and upgrade of low temperature waste heat, i.e. from dry-coolers.

The heat pump is decided as a classical cascade cycle where hydrocarbons are applied to give an optimal performance, while having a high temperature lift of 70 K to 135 K. This high lift enables applications in new designed heating and cooling systems, as well as the retrofit in already existing pressures process hot water supply systems.

The heat pump is constructed modularly on frames enabling an installation in a 10 feet shipping container or in a machinery room. One module simultaneous provides up to 0.3 MWheating at 115 °C and 0.15 MWcooling at 0 °C, process cooling may be realized down to -20 °C with reduced capacity.

The vapor compression cycles with their standardized components, such as semi-hermetic compressors, plate heat exchangers etc. are having service cost and lifetime of classical chillers.

![](_page_50_Picture_8.jpeg)

*Figure 2-12: Skala Fabrikk - SkaleUP Cascade HTHP.*

## **2.2.2.5. Kobelco Compressor Corporation**

The SGH120 steam supply heat pump from Kobelco was commercialized in 2011. This system can be used as an alternative to a low-pressure steam boiler used for heating processes such as distillation of alcohol, concentration of beverage or waste liquid, and sterilization in food industry. The system is composed of an electrically driven heat pump with two-stage twin screw compressor and a flash tank. The heat pump unit lifts the heat from the heat source water (25-75°C) and sends the heat to the pressurized circulating water. In the flash tank, the pressurized water is decompressed and evaporated. The flash steam (up to 120 °C) is supplied to each process, and make-up water is feed into the flash tank for keeping the water level. The working fluid of the SGH120 heat pump is R-245fa.

The SGH160 is an alternative to a middle-pressure steam boiler. This system is composed of an electrically driven heat pump unit, a flash tank, and a steam compressor unit. The heat pump unit lifts the heat from the heat source water (35-70 °C) and sends the heat to the pressurized circulating water. In the flash tank, the pressurized water at 115 °C is decompressed, and the flash steam at 110 °C is generated. The steam compressor unit compresses the steam up to 175 °C while injecting water. The saturated steam is supplied to each process, and make-up water is fed into the flash tank for keeping the water level. For the working fluid of the heat pump, the mixture of R-245fa and R-134a is selected for achieving a good performance. As the heat pump cycle, an economizer cycle with an internal heat exchanger is used. The thermal supply capacity for SGH 120 is 624 kW.

Kobelco also makes a micro steam recovery twin screw compressor (MSRC), which is a mechanical vapor recompression system for general-purpose applications. The MSRC was commercialized in 2011 and has a supply capacity of 0.8 MW. This system can be used as steam recovery by compressing the steam, which is a flash steam deriving from condensate drain, or low-pressure steam after being used in a heating process.

![](_page_51_Picture_3.jpeg)

![](_page_51_Picture_4.jpeg)

![](_page_51_Picture_5.jpeg)

*Figure 2-13: left - SGH-165, middle - SGH-120, right - MSRC-160.*

#### **2.2.2.6. Mitsubishi Heavy Industries Thermal Systems**

The 130 °C hot water supply heat pump (ETW-S type) from Mitsubishi Heavy Industries Thermal Systems is equipped with a two-stage centrifugal compressor. For higher efficiency, impellers with different sizes are used for the 1st and 2nd stages. The heat pump was commercialized in 2011, and can supply pressurized water of 130 °C and can e.g. be applied for heating processes such as drying and sterilization. The cycle is a transcritical heat pump cycle with intercooler and R-134a (which has a critical temperature and pressure are 101.1°C and 4.06 MPa) as working fluid. The thermal heat supply capacity is 0.6 MW.

![](_page_51_Picture_9.jpeg)

*Figure 2-14: Mitsubishi ETW-S Heat Pump.*

## **2.2.2.7. Mayekawa Europe**

In district heating applications the heat is commonly produced by combustion. The HS compressor heat pump package from Mayekawa Europe NV was specifically developed to replace or reduce the use of the burners by supplying hot brine up to 120 °C. The heat pump is a closed loop plug & play package which uses water as the heat source medium. It uses piston compressors and R-600 as working fluids, and the heat supply capacity is 750 kW with a maximum supply temperature of 120 °C.

The FC compressor heat pump package was specifically developed to replace or reduce the use of the burners by generating steam up to 145°C. To achieve high efficiencies and a low GWP, pentane (R-601) is considered as refrigerant. The use of R-601 as refrigerant results in low operating pressures combined with high operating temperatures, which allows the use of conventional refrigeration compressors with some minor modifications. The compressor is an oil lubricated screw type with a heating capacity of around 1000 kW. The compressor is driven by an electromotor. The heating capacity can be modified by changing the rotational speed of the motor with an inverter and during startup/turndown by means of the mechanical slide valve.

![](_page_52_Picture_3.jpeg)

*Figure 2-15: General layout of HS compressor (left) and FC compressor (right).*

## **2.2.2.8. GEA Heating and Refrigeration Technologies**

GEA's high-temperature industrial CO<sup>2</sup> heat pump for combined heating and cooling applications can provide heating water at up to 130 °C. The unique properties of supercritical CO<sup>2</sup> makes it a favorable choice of heat pumps for heating 'once through' water. It can also be used for heating process water with a low return temperature and high forward temperature. The hot water return temperature ideally should be between 10 °C – 45 °C. The lower the hot water return temperature, the higher the heat pump efficiency.

The heat pump is constructed with multiple reciprocating transcritical CO<sup>2</sup> compressors (2 – 8) to deliver the required heating and cooling capacities. The heat pump is equipped with a flooded evaporator and separation vessel. The gas coolers can be 1 or 2 heat exchangers in series depending on the temperature lift. For very high temperature lift the intermediate temperature between the high temperature gas cooler (HTGC) and the low temperature gas cooler (LTGC) is optimized to give the best heat pump efficiency. The thermal heat supply capacity is up to 1.2 MW, and the maximum supply temperature is up to 130 °C.

![](_page_53_Picture_0.jpeg)

*Figure 2-16: Transcritical chiller with BLUE compressors.*

#### **2.2.2.9. Fenagy**

The technology from Fenagy is an electric-driven heat pump using CO<sup>2</sup> as working fluid and is targeted on district heating and industrial applications. The racks are designed and built according to specific customer needs with thermal supply capacities between 0.3 to 1.8 MW.

The energy uptake can be either from air (AW) or water (WW). Reciprocating compressors from either Dorin or Bitzer are typically used, with optional variable speed drive. Internal heat exchangers are used to increase the temperature before the compressor and optimize the performance.

When using CO<sup>2</sup> as a working fluid, the heat pump systems can be made relative compact, and the systems have a high potential for applications with large temperature glides, where it is possible for the CO<sup>2</sup> to match the temperature profiles.

A concept study of high temperature application with supply temperatures of 120 °C has been made, which shows the increase in performance when using an expander for active recovery of the expansion losses.

![](_page_53_Picture_7.jpeg)

*Figure 2-17: Fenagy H600 heat pump with CO<sup>2</sup> as working fluid.*

#### **2.2.2.10.SRM**

SRM is currently developing a steam screw compressor for applications in process industries. A prototype has been tested in the laboratory, while the full-scale system is under development and planned for full-scale demonstration in 2023/2024.

The steam screw compressor from SRM is a positive displacement compressor that is designed for steam system use. It is electrically direct driven by a frequency-controlled motor. A separate oil skid provides lubrication to feed the bearings with oil. Advanced labyrinth shaft seals perform sealing of the water steam against oil. The system can be operated in open cycles, e.g., working between two steam distribution systems or closed cycles.

The purpose of the prototype system was to demonstrate the application of a screw compressor in a heat pump system intended for large steam systems in the paper and pulp industry, as well as other energy-intensive industries. The prototype system delivered heat to a stream being heated from 119 °C to 126 °C, while cooling a stream from 90 °C to 86 °C. The prototype has a heat supply of 250 kW, while the next model is designed for 2 MW.

![](_page_54_Picture_1.jpeg)

*Figure 2-18: SRM prototype compressor skid.*

#### **2.2.2.11.Johnson Controls**

Different working fluids have been identified by Johnson Controls in a project for working at elevated temperatures up to 250 °C or higher. For temperatures from 90 °C to 130 °C, a hydrocarbon working fluid such as n-Butane (R-600) is identified be a good solution with high COP, low swept volume and low condensing pressure.

For a specific project in Germany, a 27,000 m<sup>3</sup> old coal mine is being explored as a possible heat storage facility. On the surface, different means to heat the water are explored, such as solar heat, which during the summer period is to heat up the water reservoir and use this as a thermal energy storage. A cascade heat pump system with reciprocating compressors with an ammonia Sabroe HeatPac heat pump on the first stage and a Butane heat pump on the second stage is to deliver a high stage temperature of maximum 120 °C at an ambient temperature of -10 °C, and a sink outlet temperature of 80 °C at an ambient temperature of 0 °C. The top cycle uses an ATEX unit with separate enclosure with ventilation and gas detection.

![](_page_54_Picture_6.jpeg)

*Figure 2-19: ATEX-compliant enclosure for hydrocarbon heat pump.*

## **2.2.2.12.COMBITHERM GmbH**

COMBITHERM's high temperature heat pump series provides heating water temperatures up to 120 °C. The series was commercialized in 2021.

The heat pump uses one to three BITZER screw compressors type CSH2T with frequency converters, for part load efficiency and stepless capacity control between 17-100 %. The heating capacity ranges from 0.3 MW (1 compressor, 35 °C heat source) to 3.3 MW (3 compressors, 90 °C heat source).

Relevant applications include drying processes where heat source and heat sink are present in the same process or industries with a cooling water network and a hot water demand at 80 - 120 °C.

The heat pump is electrically driven and is designed as a closed circuit. Water is used as heat transfer

medium.

![](_page_55_Picture_1.jpeg)

*Figure 2-20: COMBITHERM HWW 2/9583I R-1233zd(E) with BITZER CSH2T screw compressors*

#### <span id="page-55-0"></span>**2.2.3. Novel and adapted compressor technologies**

#### **2.2.3.1. ecop**

The rotation heat pump from ecop is based on the Joule-Cycle and realized in a closed pipe system and allows heating and cooling in industrial applications as well as in district heating system. The compression of the environmentally friendly refrigerant is achieved by centrifugal forces, and not depending on special lubrication. The working fluid, consisting of Helium, Argon and Krypton, is not flammable and is non-toxic while the GWP is zero. Further, the working fluid is always gaseous and not condensing and evaporating in the heat exchangers. The heat supply capacity is 0.7 MW, with a max. supply temperature of 150 °C.

![](_page_55_Picture_6.jpeg)

*Figure 2-21: Rotation heat pump from ecop.*

#### **2.2.3.2. Rank®**

Rank® is a recognized company in the design and manufacture of Organic Rankine Cycles for different capacities and applications. Now, Rank® is using this experience to develop high-temperature heat pumps.

New Rank® HTHP systems are based on a single-stage cycle with an internal heat exchanger (IHX). However, a two-stage cascade cycle with IHXs can be assembled for covering larger temperature lifts.

The compressor is electrically driven, is based on a screw technology with a frequency inverter to be

adapted to the customer's actual operation. The compressor is based on direct drive, avoiding gears or pulleys, minimizing the maintenance, and increasing electrical efficiency. Moreover, magnetic coupling ensures tightness and avoids the possibility of leakage.

The working fluid is adaptable to the application, and is e.g. R-245fa, R-1336mzz(Z), and R-1233zd(E). The heat supply capacity range is between 0.12-2.0 MW and the max. supply temperature is 160 °C.

![](_page_56_Picture_2.jpeg)

![](_page_56_Picture_3.jpeg)

*Figure 2-22: Rank® HTHP and compressor.*

## **2.2.3.3. Sustainable Process Heat**

The ThermBooster from Sustainable Process Heat is a closed loop compression type heat pump. It runs with different types of low GWP A1 HFO refrigerants like R-1233zd or R-1336mzz-Z to reach temperatures up to 165 °C and a thermal power output of about 500-1000 kW per used compressor. The compressor is a 4-cylinder piston compressor, especially designed for the use of HFO in high temperature applications. The piston compressor is an open type with a shaft sealing, driven by an electrical IE4 performance motor. The system is available as 1-stage system for temperature lifts up to about 60 K and as 2-stage system for lifts up to about 140 K. The first systems will be deployed into industrial applications in the first half of 2022.

![](_page_56_Picture_7.jpeg)

*Figure 2-23: ThermBooster Water-Water configuration.*

#### **2.2.3.4. Hybrid Energy**

Hybrid Energy High Temperature heat pumps are based on hybrid technology using a mixture of ammonia and water as refrigerant and both a compressor and a solution pump. Two types are available, GreenPAC is a one-stage heat pump, and HyPAC is 2-stage. The heat supply capacity is 0.5 MW to 2 MW with a reciprocating compressor, and 1 MW to 5 MW with a screw compressor. The maximum supply temperature is 120 °C with a maximum temperature of 90 °C. 20+ heat pumps made by Hybrid Energy are currently in operation.

![](_page_57_Picture_0.jpeg)

*Figure 2-24: GreenPAC heat pump from Hybrid Energy at TINE Bergen.*

#### **2.2.3.5. ToCircle**

Tocircle's technology is a rotary vane compressor (TC-C920) which can be used both in open loop heat pump (Mechanical Vapor Recompression) or closed loop heat pump operating with pure steam or a binary mixture of steam and ammonia as the refrigerant. The compressor is a positive displacement machine driven by an electrical motor.

The compression chambers are formed between the static outer casing and the vanes connected to the rotor (see [Figure 2-25\)](#page-57-0). Unlike in conventional rotary vane compressors, the extension of vane tips in Tocircle's compressor is controlled with bearing technology mounted in the machine center. This results in no friction between the casing and vane tips, and hence no need for oil lubrication in the compression chambers.

The heat supply capacity range is 0.40 MW to 5.0 MW and the max. supply temperature is 188 °C.

![](_page_57_Picture_6.jpeg)

*Figure 2-25: Cross-sectional area of TC-C920 compressor.*

## <span id="page-57-0"></span>**2.2.3.6. Weel & Sandvig**

Weel & Sandvig develops turbo compressors operating in steam (R-718) either as open system (direct on process steam/water) or as a closed water/steam loop and process heat exchangers. The most relevant applications are upgrading excess heat sources with temperatures from 80 -110 ˚C with temperature lift of 20 - 25 ˚C as 1-stage and up to 55 ˚C as 2-stage applications. The ceramic bearings are oil lubricated with an external oil loop. There are no contact between steam and lubricating oil system. The heat supply capacity is 1 MW to 5 MW. Weel and Sandvig is in the phase of laboratory demonstrations with their own test rig located at Technical University of Denmark.

![](_page_58_Picture_0.jpeg)

*Figure 2-26: WS Turbo Steam, as a 1-stage direct drive turbo compressor working on R-718 in a closed loop.*

#### **2.2.3.7. Olvondo**

The heat pump configuration from Olvondo is a double-acting alpha Stirling engine of the "Franchot" type. "Double-acting" means that the working medium is acting on both sides of the pistons. The Franchot type means in contrast to a "Rinia" or "Siemens" type configuration, one of the cylinders is always containing cold gas and one of the cylinders is hot gas. The driving energy is waste heat with an electrical motor for the piston compressor.

The refrigerant used is R-704 (Helium), a natural refrigerant. Helium has both GWP and ozone depletion potential (ODP) equal to zero, and the toxicity and flammability classification of Helium is "A1". The working medium stays a gas throughout the cycle. The heat supply capacity is 0.5 MW (additional heat pump capacity is scheduled to 0.75 MW), and the max. supply temperature is 200 °C.

![](_page_58_Picture_5.jpeg)

*Figure 2-27: Production of the HighLift high temperature heat pump at Olvondo.*

## **2.2.3.8. Heaten**

Heaten's patented high-temperature heat pump is based on piston compressors. The HeatBooster turns waste heat into process heat and can provide an output temperature up to 200 °C with a capacity of 1 MW to 6 MW. The HeatBooster is a closed-loop heat pump with three different variants, water/water, water/steam, and steam/steam which could be configurated for single or two stage or cascade.

![](_page_59_Picture_0.jpeg)

*Figure 2-28: Heaten HTHP.*

#### **2.2.3.9. Enerin**

The HoegTemp heat pump from Enerin operates on the Stirling cycle, with a closed single-phase system undergoing compression and expansion by double-acting pistons. Heat exchangers for heat source and heat sink are integrated with the compressors assembly, making up a standard stand-alone unit with a 0.3 to 1.0 MW thermal supply. The working fluid is Helium (R-704) which is non-toxic, non-flammable, and has zero ODP and GWP. Nitrogen or hydrogen are suitable alternative working fluids. The maximum supply temperature is 250 °C.

The closed process volume of the heat pump is oil-free, and the compressor crank and associated systems are lubricated by standard engine oil (0W-50) with an integrated oil pump, filters, and water cooling. The HoegTemp heat pump is designed based on more than 30,000 hours of industrial operating experience with prototypes, and it will be qualified for industrial application through pilot installations in 2022 and 2023 (TRL 6 current estimate).

![](_page_59_Picture_5.jpeg)

*Figure 2-29: Enerin HoegTemp heat pump.*

#### **2.2.3.10.Qpinch**

The Qpinch Heat Transformer (QHT) is based on the reversible reaction of phosphate oligomerization inspired by the adenosine triphosphate – adenosine diphosphate (ATPADP) cycle in all living cells. This chemical principle is brought to a continuous industrial process in the form of a phosphate absorption heat transformer. The system consists of a closed loop phosphate oligomerization and hydrolysis loop. Qpinch have in 2021 made 3 commercial installations. In [Figure 2-30](#page-60-1) examples of installations are shown.

![](_page_60_Picture_0.jpeg)

*Figure 2-30: Several Qpinch Heat Transformer units.*

<span id="page-60-1"></span>Low temperature residual heat (from industrial processes) drives the whole system. Only around 25 kWh electrical power is used to generate 1 ton of steam. This power is consumed in centrifugal pumps as no compressors are used in this technology as it is heat driven.

#### <span id="page-60-0"></span>**2.3. Overall trends between key parameters**

Based on the collected information a series of calculations and plots are done for analysing the collected information for overall trends between the key parameters for the different technologies (for electrical driven cycles).

[Figure 2-31](#page-60-2) shows the indicated maximum supply temperature as a function of the thermal heating capacity, including a legend with the corresponding technology suppliers. Please note, that the axis in the figure is logarithmic, showing the average capacity with a colored symbol and the capacity ranges with black horizontal lines. The capacities vary between 0.03 MW and 70 MW, and the maximum supply temperature varies between 100 °C and 280 °C. In the figure a general trend with higher possible supply temperatures for the larger capacities can be seen.

![](_page_60_Figure_6.jpeg)

*Figure 2-31: Maximum supply temperature as a function of capacity.*

<span id="page-60-2"></span>[Figure 2-32](#page-61-0) shows the specific investment cost as a function of the mean temperature lift. For the supplier technologies that have indicated a cost, the specific investment cost (disregarding installation and integration cost) varies between 200 €/kW to 1200 €/kW, and the mean temperature lift for the

different technologies varies between 20 °C and 190 °C. In the figure a general trend with higher cost for higher temperature lift can be seen. For the specific cost ranges that are stated, and shown with black vertical lines in the figure, the cost depends strongly on the size and application of the heat pump for the given technology.

[Figure 2-33](#page-61-1) shows the specific investment cost as a function of the indicated maximum supply temperatures which varies between 120 °C and 280 °C for these cases. In general, a minor trend can be seen that the specific investment cost is lower for the lower supply temperatures, an exception is however the cost indicated for the case with a max. supply temperature of 280 °C, which is a case with steam MVR. The values with a 1200 €/kW are for a cycle with the Stirling motor principle.

![](_page_61_Figure_2.jpeg)

*Figure 2-32: Specific investment cost as a function of mean temperature lift.*

<span id="page-61-0"></span>![](_page_61_Figure_4.jpeg)

*Figure 2-33: Specific investment cost as a function of maximum supply temperature.*

<span id="page-61-1"></span>[Figure 2-34](#page-62-0) shows the specific investment cost as a function of the capacity. For both the cost and capacities the indicated ranges are shown with black vertical and horizontal lines, respectively. No clear trend is seen for a correlation here.

![](_page_62_Figure_1.jpeg)

*Figure 2-34: Specific investment cost as a function of capacity.*

<span id="page-62-0"></span>In [Figure 2-35](#page-62-1) the COPheating for all the cases is plotted as a function of the mean temperature lifts. Please refer to section [1.1](#page-14-1) for explanation of the terminology used. e.g. definition of heat pumping part of crossing temperature profiles. The indicated COP heating varies between 1.4 and 10.3. The legend indicates if the case has a crossing temperature profile for the source and sink side, and also whether the case is a MVR case. For the MVR cases colored green it is assumed there is no temperature glide for the source and sink, while for the black colored cases a subcooling down to 105 °C is assumed. An indication of theoretical cycles with different Lorenz efficiencies is also shown.

![](_page_62_Figure_4.jpeg)

*Figure 2-35: COPheating as a function of mean temperature lift.*

<span id="page-62-1"></span>A strong correlation for lower indicated COPheating at higher mean temperature lifts is seen. In general, the cases with crossing temperature profiles have a lower COPheating compared to the cases without crossing temperature profiles. For the cases with MVR a relatively high COPheating is seen, however if these technologies were used in a closed loop application a little lower performance is also expected

due to the heat losses there will be in the heat exchangers between the working fluid and the sink/source media.

[Figure 2-36](#page-63-0) shows the Lorenz efficiency as a function of the mean temperature lift. For the black dots with MVR subcooled to 105 °C the entropic average temperature is used for the calculation of the Lorenz efficiency. The Lorenz efficiency varies between 11 % and 69 % and the figure shows a strong correlation with higher Lorenz efficiency for higher temperature lifts. As for the COPheating, the crossing temperature profiles have a lower efficiency compared to the cases without crossing temperature profiles, and the MVR cases have a relatively high efficiency with the used assumptions.

![](_page_63_Figure_2.jpeg)

*Figure 2-36: Lorenz efficiency as a function of mean temperature lift.*

<span id="page-63-0"></span>The stated average expected lifetime as a function of the capacity is summarized in [Figure 2-37](#page-63-1) on the next page. Most suppliers have indicated 20 years as the expected lifetime, however a clear trend with increasing expected lifetime as a function of increasing capacity can be seen. For the smaller systems below 0.5 MW an average of 14.5 years is stated and for systems between 0.5 MW and 5 MW and expected average of 19.0 years is stated. For the larger systems above 5 MW an expected average lifetime of 23.3 years is specified.

![](_page_63_Figure_5.jpeg)

<span id="page-63-1"></span>*Figure 2-37: Average expected lifetime as a function of capacity.*

In general, the technology review has identified a wide range of different HTHP technologies and that several suppliers are working on developing the technologies further. The various HTHP technologies have different marked readiness, which depends on the actual application case. [Figure 2-38](#page-64-0) shows three examples of different dependencies between some of the key parameters for HTHP technology. The green line in the figure shows an example with a relatively high max. supply temperature of 250 °C with a TRL level of 6. The example with the orange line in the figure shows a lower max. supply, but in turn also a higher TRL of 7.5.

![](_page_64_Figure_1.jpeg)

*Figure 2-38: 3 examples of dependencies for HTHP technologies*

<span id="page-64-1"></span><span id="page-64-0"></span>[Table 2-3](#page-64-1) summarizes the ranges for the information collected in the review.

Table 2-3: Summary of Annex 58 HTHP technology review.

| TRL level               | 4-9                                                        |
|-------------------------|------------------------------------------------------------|
| Average specific cost   | 200 €/kW - 1500 €/kW                                       |
| Capacity                | 0.03 MW - 70 MW                                            |
| Max. supply temperature | 100 °C - 280 °C                                            |
| Availability            | Geographical dependent, e.g.<br>between Europe and Japan   |
| Size of HTHP review     | 34 different technologies with<br>85 performance use cases |

## <span id="page-65-0"></span>3. Demonstration cases

Within the framework of the Annex, 16 demonstration cases that use HTHPs were collected in collaboration with the HP manufacturers. The data set on which this evaluation is based is supplemented by two application cases for HTHPs (> 100 °C) collected in Annex 35. Closed compression heat pumps (CCHP), mechanical vapour recompressors (MVR) and heat transformers are predominantly used.

<span id="page-65-2"></span>Table 3-1: Overview of demonstration cases and their characteristics based on [33] Annex 35 (2014) and [34] Annex 58 (2022)

| No. | Supplier                       | Industry            | Process                    | Heats                           | ource                    |                         | Heat                 | sink                     |                         | НР Туре                        | Refrigerant                | Compressor                            | Capacity | СОРн        | Op.   | Ref. |
|-----|--------------------------------|---------------------|----------------------------|---------------------------------|--------------------------|-------------------------|----------------------|--------------------------|-------------------------|--------------------------------|----------------------------|---------------------------------------|----------|-------------|-------|------|
|     |                                |                     |                            | Unit<br>Operation               | T <sub>out</sub><br>[°C] | T <sub>in</sub><br>[°C] | Unit<br>Operation    | T <sub>out</sub><br>[°C] | T <sub>in</sub><br>[°C] |                                |                            |                                       | [kW]     |             | [h/a] |      |
| 1   | n. a.                          | beverage            | alcoholic<br>distillation  | product<br>cooling              | 75                       | 78.3                    | distillation         | 140                      | n. a.                   | M VR                           | n. a.                      | n. a.                                 | 350      | 5.2         | n. a. | [1]  |
| 2   | Mayekawa                       | electronic          | coil drying                | electro-<br>painting<br>cooling | 25                       | 30                      | drying               | 120                      | 20                      | ССНР                           | R744                       | piston                                | 89       | 3.1         | n. a. | [1]  |
| 3   | AMT/AIT                        | food                | starch drying              | waste heat                      | 72                       | 76                      | drying               | 138                      | 96                      | ССНР                           | R-1336mzz(Z)               | screw                                 | 374      | 3.2         | 4,000 | [2]  |
| 4   | Olvondo                        | pharma-<br>ceutical | recooling                  | recooling<br>heat               | 34                       | 36                      | steam<br>generation  | 183                      | 178                     | Stirling HP                    | R704                       | piston                                | 2,250    | 1.7         | 6,100 | [2]  |
| 5   | Kobelco                        | sewage              | sludge drying              | exhaust<br>dry ing air          | 93                       | 93                      | steam<br>generation  | 160                      | 160                     | MVR                            | R718                       | twin-screw,<br>roots blower           | 675      | 2.9         | n. a. | [2]  |
| 6   | Kobelco                        | refinery            | bioethanol<br>distillation | process<br>cooling              | 60                       | 65                      | distillation         | 115                      | 110                     | CCHP +<br>Flash Tank           | R245fa                     | twin-screw                            | 1,850    | 3.5         | n. a. | [2]  |
| 7   | МНІ                            | electronic          | coil drying                | waste heat                      | 50                       | 55                      | drying               | 130                      | 70                      | ССНР                           | R134a                      | centrifugal                           | 627      | 3.0         | n. a. | [2]  |
| 8   | Piller                         | plastics            | thermal<br>seperation      | exhaust<br>vapour               | 60                       | 60                      | steam<br>generation  | 131                      | 126                     | M VR                           | R718                       | turbo<br>(8 blowers)                  | 10,000   | 4.4         | 8,000 | [2]  |
| 9   | AMT/AIT                        | minerals            | brick drying               | exhaust<br>dry ing air          | 80                       | 84                      | drying               | 121                      | 96                      | ССНР                           | R-1336mzz(Z)               | piston<br>(8 compr.)                  | 296      | 5           | 4,000 | [2]  |
| 10  | Spilling                       | pulp and<br>paper   | pulp drying                | exhaust<br>vapour               | 105                      | 133                     | steam<br>generation  | 201                      | n. a.                   | MVR                            | R718                       | piston<br>(4 LT-, 2 HT-<br>cylinders) | 11,200   | 4.2         | 7,500 | [2]  |
| 11  | Spilling                       | chemical            | chemical                   | exhaust<br>vapour               | 105                      | 152                     | steam<br>generation  | 211                      | n. a.                   | MVR                            | R718                       | piston<br>(4 LT-, 2 HT-<br>cylinders) | 12,000   | 5.3         | 7,500 | [2]  |
| 12  | Rotrex,<br>Epcon               | sewage              | sludge drying              | surp lus<br>steam               | 100                      | n. a.                   | steam<br>generation  | 146                      | n. a.                   | M VR                           | R718                       | turbo<br>(2 stages)                   | 500      | 4.5         | n. a. | [2]  |
| 13  | SkaleUP                        | dairy               | process hot<br>water       | (re)cooling                     | 12,<br>0                 | 20,<br>5                | process hot<br>water | 115                      | 95                      | ССНР                           | LT-C: R290,<br>HT-C: R600  | piston                                | 300      | 2.5,<br>2.3 | 6,500 | [2]  |
| 14  | QPinch                         | chemical            | steam<br>production        | exhaust<br>vapour               | 120 -                    | - 145                   | steam<br>generation  | 140                      | - 185                   | heat trans-<br>former          | $H_2PO_4$                  | heat-driven                           | 2,900    | 0.45        | 2,500 | [2]  |
| 15  | Huayuan<br>Taimeng             | refinery            | ethyl-<br>benzene          | waste heat                      | 95                       | 120                     | steam<br>generation  | 152                      | n. a.                   | heat trans-<br>former          | LiBr-H <sub>2</sub> O      | heat-driven                           | 7,553    | 0.48        | n. a. | [2]  |
| 16  | Shanghai<br>Nuotong            | beverage            | alcoholic<br>distillation  | air                             | n. a.                    | 18.9                    | steam<br>generation  | 120                      | 90                      | CCHP +<br>Flash Tank +<br>M VR | LT-C:R410a,<br>HT-C:R245fa | screw                                 | 180      | 1.85        | n. a. | [2]  |
| 17  | Huayuan<br>Taimeng             | refinery            | alky l-<br>benzene         | waste heat                      | 86                       | 127                     | steam<br>generation  | 150                      | n. a.                   | heat trans-<br>former          | LiBr-H <sub>2</sub> O      | heat-driven                           | 5,100    | 0.48        | n. a. | [2]  |
| 18  | Shandong<br>Zhangqiu<br>Blower | refinery            | ethanol<br>distillation    | exhaust<br>vapour               | 76                       | n. a.                   | steam<br>generation  | 116                      | n. a.                   | MVR                            | R718                       | centrifugal                           | n. a.    | 7.68        | 7,000 | [2]  |

### <span id="page-65-1"></span>3.1. Summary of demonstration cases

In ten of all case studies, the HTHPs are used to generate steam for use in thermal separation like distillation. Seven cases are drying applications of which three are steam-based drying applications, and four are drying air applications. One HTHP is used to generate process hot water. Table 3-1 also shows that most applications are in the food, chemical, sewage, and electrical industries. In addition, there are case studies from the refinery, mineral, paper, and pharmaceutical industries.

![](_page_66_Figure_0.jpeg)

*Figure 3-1: Number of case studies by industries and application processes.*

The target temperatures are between 115 °C and 240 °C. The latter is achieved by MVRs. The highest sink temperature reached by the Stirling heat pump is 183 °C. For conventional closed-cycle compression heat pump (CCHP), it is 138 °C. Basically, analogous to [Figure 2-35](#page-62-1) and [Figure 2-36,](#page-63-0) the MVRs achieve a higher efficiency than comparable CCHPs due to the open mode of operation. If subcooling takes place on the heat source side, as in cases 10 and 11, this efficiency can be increased even further. The range of mean temperature lifts that can be reached with the HTHPs varies from 26 K up to 145 K. As expected, [Figure 3-2](#page-66-0) shows that the COP decreases with increasing temperature range but is at a relatively high level.

![](_page_66_Figure_3.jpeg)

<span id="page-66-0"></span>*Figure 3-2: Boxplot of target sink temperatures (left) and COPheating as a function of mean temperature lift (without heat transformer cases)*

[Figure 3-3](#page-67-2) shows, as expected, that the Lorenz efficiencies are slightly increasing with increasing mean temperature lift. The MVRs generally show higher efficiency than the CCHP. The MVRs varies between 0.45 and 0.91. The CCHP are between 0.35 and 0.59.

![](_page_67_Figure_0.jpeg)

*Figure 3-3: Lorenz efficiency as a function of mean temperature lift.*

<span id="page-67-2"></span>The highest temperature lift is achieved with Stirling heat pumps followed by the MVR applications. In lower temperature ranges above 100 °C, closed loop compression heat pumps (CCHP) are the predominant technology. For steam generation, MVR or a combination of HTHP, flash tank/evaporator and MVR are predominantly used.

## <span id="page-67-0"></span>**3.2. Promising Applications**

In the following, the integration concepts of the prevailing application principles are presented and key learnings as well as success factors are derived.

#### <span id="page-67-1"></span>**3.2.1. Drying**

In convective dryers, the reduction of moisture in a product takes place through evaporation. [Figure 3-4](#page-68-1) (a) shows the changes of state of the air in the Mollier-h-x diagram. For this purpose, a hot and relatively dry air flow (state 2) heats the product to evaporation temperature and transfers the necessary enthalpy of evaporation. [Figure 3-4](#page-68-1) (b) illustrates how a heat pump can be integrated into the convective drying process. The humid exhaust air leaving the dryer (3) serves as a heat source for the evaporator. For this purpose, parts of the sensible heat and evaporation enthalpy are recovered, by cooling (3→4) and dehumidifying (4→5) the humid exhaust air. After compression to the drying temperature level, the incoming supply air can be (1→2) can be (pre-) heated before the drying process in the dryer is carried out.

![](_page_68_Figure_0.jpeg)

<span id="page-68-1"></span>*Figure 3-4: Changes of state of a convective drying process in the Mollier- h-x diagram and (b) in the schematic of an integrated heat pump* [35]*.*

Case studies 2 and 9 are working according the in [Figure 3-4](#page-68-1) described principle whereas case studies 3 and 7 are using an intermediate pressurized hot water cycle.

Success factors of the drying application is the obligatory occurrence of heat source and heat sinks, which enables efficient process integration without storages. Due to the high moisture content of the exhaust air, there is a big waste heat source is at dew point temperature level. On the sink side, heat pumps are preferred, which have efficiency advantages at high temperature change. High extract air humidities and air mass flows as well as low supply air temperatures favour the integration of HTHPs. On the other hand, air as a heat transfer medium has a lower heat capacity and density. During drying, these properties lead to large temperature changes with small enthalpy flow changes, which can result in high temperature lifts.

## <span id="page-68-0"></span>**3.2.2. Steam generation**

For steam generation, MVRs, or a combination of HTHP, flash tank/evaporator and MVR are predominantly used. The use of MVRs is state of the art for evaporation, distillation and preservation processes in the paper, chemical and food industries.

![](_page_68_Figure_6.jpeg)

*Figure 3-5: Steam generation with (a) MVR, (b) MVR and flash tank or (c) CCHP and heat exchanger.*

<span id="page-68-2"></span>Case studies 5, 8 and 16 are generating steam based on exhaust vapor or drying air by a flash tank or evaporator in combination with MVRs like concept [Figure 3-5](#page-68-2) (a) + (b) whereas case studies 1, 10, 11, 12 and 18 are directly compressing low temperature steam to high temperature steam according to principle [Figure 3-5](#page-68-2) (a). The heat pumps in case study 6 are generating pressurized water for evaporating feed water in a flash tank (cf. [Figure 3-5](#page-68-2) (b)). Similar to that, a heat exchanger in case study 4 is using the pressurized water from CCHP for generating steam like shown in [Figure 3-5](#page-68-2) (c).

A high temperature difference between source and sink processes often limits economically viable integrations of CCHPs. Direct steam applications reduce the heat exchanger-specific temperature difference and increase the COP. In a simulation study, Wilk et al. (2019) compared the direct steam generation in the condenser of the heat pump with alternative concepts such as an intermediate circuit, a flash tank or vapor recompression. To generate steam in the range of 2 to 5 bar absolute pressure, vapor recompression is the most efficient, followed by direct steam generation in the condenser. The efficiency advantage becomes greater the higher the pressure of the saturated steam produced. Direct steam generation in the condenser is advantageous in terms of its reduced system complexity. Fewer components are required, which results in the lowest investment costs and the smallest space requirement.

In addition to the reduction in steam consumption, the steam generating HTHPs also reduces cooling water demand, decreasing the overall energy consumption on site.

#### <span id="page-69-0"></span>**3.2.3. Key Learnings and Success Criteria**

Prerequisite for a successful integration of HTHPs is a preliminary detailed analysis of process requirement (heat demand, temporal behavior, temperatures) and waste heat source (amount, properties of exhaust gases and drying air and their effects on heat exchange). Due to high pressures and temperature challenges regarding material compatibility (lubricant, refrigerant, sealing materials), mechanical design (vibrations), infrastructure (pressure maintenance, measurement), process control (start-up procedure, data transfer) have to be solved.

One success criterion for economic implementation is the reduced cooling demand in addition to reduced steam demand. Furthermore, internal heat recovery cycles enable the valorisation of waste heat from several processes at a site.

## <span id="page-70-0"></span>**4. National HTHP market and perspectives**

This chapter will provide an overview of the national HTHP Industry, and the ongoing research, development, and demonstration activities in the participating countries.

## <span id="page-70-1"></span>**4.1. Austria**

#### <span id="page-70-2"></span>**4.1.1. Overview of national HTHP industry**

There are only a few Austrian HTHP manufacturers. According to the authors' best knowledge, the following Austrian heat pump manufacturers offering systems with utilization temperatures greater than or equal to 100°C were identified.

- 1. **OCHSNER Energie Technik GmbH [\(https://ochsner-energietechnik.com/\)](https://ochsner-energietechnik.com/)** has three conventional compression heat pumps in its portfolio for the considered application range. The maximum sink outlet temperature is 130°C. The possible heating capacity range is given as 170 kW to 750 kW. With a twin unit, the heating capacity range can be increased to 1.5 MW. In these heat pumps screw compressors are applied. In addition, non-toxic and non-flammable refrigerants are used.
- 2. **ecop Technologies GmbH [\(https://www.ecop.at/de/home/\)](https://www.ecop.at/de/home/)** offers the rotation heat pump based on the Joule Cycle. Currently a 700 kW heat pump with a maximum sink outlet temperature of 150°C is available. The working fluid applied is an environmentally friendly, nontoxic and non-flammable inert gas.

## <span id="page-70-3"></span>**4.1.2. Overview of national HTHP market and application potential**

In 2020, the industrial sector in Austria had a final energy consumption of about 85 TWh. This corresponds to around 29% of Austria's final energy demand [36].

![](_page_70_Figure_9.jpeg)

<span id="page-70-4"></span>*Figure 4-1: Final thermal energy demand for selected useful energy categories in Austria in 2020 for different industrial sectors.* [36]

[Figure 4-1](#page-70-4) shows the final energy consumption to cover the heat demand for different industrial sectors in Austria. The heat demand is differentiated into three categories "*space heating and hot water", "process heat <200°C"* and "*process heat >200°C"*. In 2020, the category "*process heat <200°C"* amounts to 42% of the Austrian industrial heat demand. The three industrial sectors with the largest final energy demand in this category are "*paper, pulp and print"* (15 TWh), "*chemical and petrochemical"* (6 TWh) and "*Food, tobacco and beverages"* (2 TWh). In these sectors, up to 94% of the final energy demand for "*process heat <200°C"* is produced from natural gas. Based on the assumption that the share of "*process heat <200°C"* which is currently generated by natural gas can also be provided by heat pumps, the following heat pump potential per year results for the above-mentioned sectors; *chemical and petrochemical*: 4.1 TWh, *food, tobacco, and beverages*: 2.3 TWh, *paper, pulp and print*: 4.6 TWh [36].

This potential enables a CO2-emission reduction of 72% (CO<sup>2</sup> emission factor: natural gas 268 g/kWh, electrical energy 219 g/kWh [37]) compared to a gas burner, assuming a COP of 2.76<sup>3</sup> and gas burner efficeincy of 95%. [Figure 4-2](#page-71-1) shows the calculated CO2-emissions for all three sectors based on the heat pump potential per year. In addition, this measure saves 66% in final energy consumption. Based on an electricity price of 200 €/MWh [38] and a gas price of 103 €/MWh [39], this results in an operating cost saving of 33 % (including an estimate for network charges and other levies). If additional costs for CO<sup>2</sup> certificates of 88 €/t CO<sup>2</sup> [40] are taken into account, the operating cost savings increase to 39%.

![](_page_71_Figure_1.jpeg)

<span id="page-71-1"></span>*Figure 4-2: CO<sup>2</sup> emissions for the generation of process heat in a temperature range <200°C in selected industrial sectors (natural gas combustion compared to high-temperature heat pump). Based on [35],* [37]*.*

#### <span id="page-71-0"></span>**4.1.3. Development perspectives for HTHP technologies**

Austria has set itself the goal of becoming climate neutral by 2050 at the latest without the use of nuclear energy. To achieve this, sectors not subject to the ETS are to reduce their CO2 emissions by 36% by 2030 compared to 2005. For sectors that are subject to the ETS, a reduction in CO2 emissions of at least 43% compared to 2005 is to be achieved. In addition, electricity generation is to be converted to 100% renewable by 2030 [41]. It should be noted that, depending on the water availability, 55-67% of Austria's electricity is already generated from hydropower.

The IndustRiES study [42] published in 2019 shows how Austrian industry can theoretically be supplied with 100% renewable energy and what demands this implies for the infrastructure. Three different scenarios were used in the study, and in all of them the industrial energy demand can be covered with renewable energy, but the energy demand of the other sectors cannot be fully covered with renewable energy. Depending on the scenario, a coverage gap of 71 to 97 TWh occurs. This gap can be kept as small as possible by increasing efficiency.

The study identifies storages and high-temperature heat pumps as basic technologies for increasing the efficiency of industrial processes. It also emphasizes the importance of identifying waste heat potential and that this should be a topic in demonstration and research projects in order to make optimum use of waste heat in the future. The use of high-temperature heat pumps is mentioned in this study primarily for steam generation, but also for supplying drying processes. In addition, the need for research on steam-generating heat pumps is pointed out [42]

In [43] the numbers of industrial heat pumps in operation are published annually. In this study, industrial heat pumps are heat pumps that are used in industrial and commercial processes and are manufactured on a project-specific basis. The numbers of industrial heat pumps in operation from the year 2012-2020 are shown in [Figure 4-3.](#page-72-1) An increase in the numbers per year can be clearly seen. In the Austrian technology roadmap for heat pumps [44], three future scenarios were considered based on the data from [43] for the years 2012 - 2015. These scenarios are also shown in [Figure 4-3.](#page-72-1) The low scenario represents the continuation of the numbers of the base years. In the medium scenario, annual market growth is 20% and in the high scenario, annual market growth of 25% was assumed. From 2017 onwards, the provided numbers by [43] are significantly higher than in the assumed future scenarios.

<sup>3</sup> For example, a COP of 2.76 results from generating 120°C saturated steam with a source inlet temperature of 65°C. For this, the source is cooled down to 60°C and a second law efficiency of 0.46 is assumed.

![](_page_72_Figure_0.jpeg)

<span id="page-72-1"></span>*Figure 4-3: Annual numbers of industrial heat pumps in operation in Austria including forecast until 2030 based on the numbers from 2012-2015.* [43], [44]*.*

In the Austrian technology roadmap for heat pumps [44] it is also stated that the research and development topics until 2030 include mainly the implementation of model solutions and pilot plants of market available products for the dissemination and increase the acceptance of industrial heat pumps. Moreover, the development of industrial heat pumps for higher target temperatures (150°C-200°C), as these are needed in industrial processes, and new concepts for industrial heat pumps should be developed.

Since the roadmap was published, a number of large capacity industrial heat pumps have come into operation. In addition, in 2019, as part of the H2020 project DryFiciency (see Chapter [4.1.4\)](#page-72-0), two demo plants that deliver heat utilization temperatures of up to 160°C went into operation in two Austrian industrial companies. It is therefore assumed that the number of HTHPs in operation will continue to increase in the future.

#### <span id="page-72-0"></span>**4.1.4. Selected RD&D projects**

**1.** Hot Cycle – Refrigerant and cycle design for high temperature heat pumps of small and medium capacity, using a separating hood compressor.

• Duration: 04/2015 – 06/2018

• Participants: TU Graz- Institute of Thermal Engineering, FRIGOPOL Kälteanlagen

GmbH

• Financing: Funded by the Austrian Climate and Energy Fund and carried out within the Austrian Energy Research Program 2015 (FFG-Nr. 848892)

• Further information: [https://energieforschung.at/projekt/hotcycle-hochtemperatur](https://energieforschung.at/projekt/hotcycle-hochtemperatur-waermepumpe-kleiner-bis-mittlerer-leistung-mit-trennhaubenkompressor/)[waermepumpe-kleiner-bis-mittlerer-leistung-mit-trennhaubenkompressor/](https://energieforschung.at/projekt/hotcycle-hochtemperatur-waermepumpe-kleiner-bis-mittlerer-leistung-mit-trennhaubenkompressor/)

In this project the approach to utilize a separating hood compressor in a small- to medium-capacity HTHP system to establish an efficient and safe heat supply with temperatures up to 110°C was investigated. A key objective was to redesign and further develop an existing separating hood compressor (see [Figure 4-4\)](#page-73-0). This compressor concept promises advantages with respect to safety and serviceability compared to standard compressors when used for "new" – usually flammable and / or toxic – high temperature refrigerants and the product range covers thermal capacities from a few kW up to 75 kW.

![](_page_73_Picture_0.jpeg)

*Figure 4-4: HotCycle - Standard air cooled separating hood compressor and cross section sketch of the suction gas cooled adaption* [45]*.*

<span id="page-73-0"></span>The refrigerant selection and cycle development lead to the design and construction of a prototype of the HTHP utilizing R-600 (n-butane) and a variable cycle configuration. Since R-600 requires a certain degree of suction gas superheat to prevent a wet compression into the two-phase region, different measures were experimentally investigated. These included a suction gas cooled compressor (denoted as SHX in [Figure 4-5\)](#page-73-1) and the additional possibility to use a dedicated superheater or an internal heat exchanger.

The compressor and system efficiencies were evaluated through extensive experimental investigations, including the stability of refrigerant superheat at the evaporator outlet. [Figure 4-5](#page-73-1) (right) shows the reached COP for heat source (SO) inlet/outlet temperatures between 50/45°C and 80/75°C and heat sink (SI) temperatures 50/80°C to 80/110°C using the suction gas cooled compressor (configuration SHX) and an inverter frequency of 50 Hz. At the marked operating point SO60/55 SI80/110, a COP of 3.5 was reached, a t/h-diagram of this operating point is shown in [Figure 4-5](#page-73-1) (left).

![](_page_73_Figure_4.jpeg)

<span id="page-73-1"></span>*Figure 4-5: HotCycle - Experimental results in terms of COP of the SHX configuration (right) and the t/hdiagram based on experimental data for the operation point heat source (SO) inlet/outlet 60/55°C, heat sink (SI) 80/110°C (left)* [45]*.*

Economical key figures and specific CO<sup>2</sup> emissions for selected applications in the food industry (evaporation, sterilization and blanching) were calculated based on the results of a validated simulation model. The results indicate economically viable payback periods of 5 to 6 years compared to a boiler running on natural gas.

**2.** DryFiciency - Waste Heat Recovery in Industrial Drying Processes

• Duration: 09/2016 – 08/2021

• Participants: AIT Austrian Institute of Technology GmbH, Agrana Stärke GmbH,

Wienerberger AG, RTDS GmbH, Rotrex A/S,

Bitzer Kühlmaschinenbau GmbH, Chemours Deutschland GmbH,

Fuchs Europe Schmierstoffe GmbH, Heaten AS, SINTEF,

EPCON Evaporation Technology AS, EHPA European Heat Pump

Association, Scanship AS

• Total budget: 7 mio. €

• Financing: H2020 – Innovation Action, ID nr: 723576

• Further information: <https://dryficiency.eu/>

The overall objective of the DryFiciency project is to lead the European energy intensive industry to high energy efficiency and a reduction of fossil carbon emissions by means of waste heat recovery. Technically and economically viable solutions for upgrading idle waste heat streams to process heat streams at higher temperature levels up to 160 °C are elaborated. The key elements are three high temperature vapour compression heat pumps (two closed loop heat pumps for air drying / one open loop heat pump for steam drying). The solutions are demonstrated and validated under real production conditions in operational industrial drying processes in three leading European manufacturing companies from food, brick and waste management industries. The closed loop heat pumps have been operated for ca. 4000 h each and proved to be efficient measures to reduce energy consumption and carbon emissions.

Several innovations have been achieved for the technologies on component and system level.

Closed loop heat pump technologies:

- Fine-tuned, novel synthetic lubricant for high temperature applications working stable with a novel, non-flammable, non-toxic refrigerant with a minimum global warming potential at elevated temperature levels.
- Adapted screw and piston compressor technologies, working well with the lubricant-refrigerant mixture selected at elevated temperature levels up to 160°C.
- Novel system concepts and configurations successfully validated at high temperatures of up to 160°C for two closed loop heat pump installations with more than 4.000 operation hours each with a max. heat output of 375kW and a COP of 2 to 4 at varying source temperatures.
- Training program for multiple stakeholders successfully tested with more than 100 trainees.

Open loop heat pump system:

- Advanced, low-cost, oil-free turbo compressor prototype based on newly developed and patented step-up technology.
- Novel, highly efficient MVR dryer technology with a 75% increase in efficiency, while reducing energy consumption by 70%.
- System concept and configuration of an open loop heat pump system successfully tested under lab conditions up to discharge temperatures of 155°C; at a temperature lift up to 45K, in a twostage compression with a COP of >4.

The heat pump solutions developed in the project have the potential to cover the full range of industrial drying processes. With heat supply temperatures of up to 160°C, they are replicable in many sectors, such as chemicals, food, textiles, or the paper industry.

Calculations performed based on the operation results from the closed loop heat pumps have shown, that CO<sup>2</sup> savings from 50% up to 80% are achievable when applying them in drying applications. This figure will further rise, as the share of renewable energy sources for electricity generation increases. By making use of green electricity, industrial drying processes can be almost completely decarbonized in the future.

**3.** TransCrit – Trans-critical high temperature heat pump for waste heat recovery

• Duration: 04/2018 – 09/2021

• Participants: TU Graz- Institute of Thermal Engineering, FRIGOPOL Kälteanlagen

## GmbH

• Financing: Funded by the Austrian Climate and Energy Fund and carried out within the Austrian Energy Research Program 2017 (FFG-Nr. 865083)

• Further information: [https://energieforschung.at/projekt/transkritische-hochtemperatur](https://energieforschung.at/projekt/transkritische-hochtemperatur-waermepumpe-zur-abwaermenutzung/)[waermepumpe-zur-abwaermenutzung/](https://energieforschung.at/projekt/transkritische-hochtemperatur-waermepumpe-zur-abwaermenutzung/)

The project TransCrit investigated the innovative approach of a trans-critical cycle with a natural refrigerant different from CO<sup>2</sup> for the application in a high temperature vapor compression heat pump with a supply temperature higher than 150°C. The application of a trans-critical cycle extends the operating range of HTHPs to temperatures beyond the critical temperature of the used refrigerant. The consideration of natural refrigerants accounts for future legal restrictions concerning refrigerants.

By means of simulation studies and taking into consideration component availability and operating ranges, a single-stage cycle using R-600 with an inverter-driven suction-gas cooled reciprocating compressor and IHX for suction gas superheat was realized in a prototype (see [Figure 4-6\)](#page-75-0). This HTHP enables lifting heat from source inlet temperature level of 60°C (heat source outlet 55°C) to a supply temperature of up to 160°C.

![](_page_75_Picture_5.jpeg)

*Figure 4-6: TransCrit - Scheme of the refrigerant cycle (left) and picture of the HTHP prototype with opened casing (right)* 

<span id="page-75-0"></span>The influence of the operating parameters heat source and heat sink temperatures, compressor speed, suction gas superheat in the IHX and high pressure on the heating capacity and COP of the HTHP were studied using experimental data and the results of a detailed simulation model [46]. The existence of an optimum high pressure which depends on the operating conditions, was identified. Increasing the suction gas superheat in the IHX was found to lower the optimum high-side pressure and to increase the COP.

A strategy for controlling the high-side pressure using the temperature difference between refrigerant outlet of the condenser and heat sink inlet was successfully tested, the achieved values for heating capacity and COP at the nominal compressor speed are presented in [Figure 4-7](#page-76-0)[Figure 4-6.](#page-75-0)

![](_page_76_Figure_0.jpeg)

<span id="page-76-0"></span>*Figure 4-7: TransCrit – COP (left) and heating capacity (right) at different heat source (SO) and heat sink (SI) temperature levels (derived from* [47]*).*

**4.** BAMBOO - Boosting new Approaches for flexibility Management By Optimizing process Off-gas and waste use

• Duration: 09/2018 – 08/2022

• Participants: CIRCE Foundation (Centre of Research for Energy Resources and

Consumption), Technische Universität Braunschweig, AIT Austrian Institute of Technology GmbH, IKERLAN S.COOP, Centre for Research and Technology Hellas, Energieinstitut an der Johannes Kepler Universität Linz, N-SIDE SA, TURBODEN SPA, AMT Kältetechnik GmbH, Rina Consulting S.p.A, Cosmo Tech, ArcelorMittal España, Turkiye Petrol Rafinerileri Anonim Sirketi, Grecian Magnesite – Mining, Industrial, Shipping and Commercial Company Societe Anonyme, UPM GMBH, SIDENOR ACEROS ESPECIALES S.L., MAGNESITAS NAVARRAS, S.A., Fondazione iCons, EDF

ELECTRICITE DE FRANCE

• Total budget: 11 mio. €

• Financing: Funded by European Commission (H2020) reference 820771

• Further information: [https://www.bambooproject.eu](https://www.bambooproject.eu/)

BAMBOO aims at developing new technologies addressing energy and resource efficiency challenges in 4 intensive industries (steel, petrochemical, minerals and pulp and paper). BAMBOO will scale up promising technologies to be adapted, tested and validated under real production conditions focusing on three main innovation pillars: waste heat recovery, electrical flexibility and waste streams valorisation. These technologies include industrial heat pumps, Organic Rankine Cycles, combustion monitoring and control devices, improved burners and hybrid processes using energy from different carriers (waste heat, steam and electricity) for upgrading solid biofuels. These activities will be supported by quantitative Life Cycle Assessments.

In order to maximize their application and impact to plant level, flexibility measures will be implemented in each demo case towards energy neutrality and joined in a horizontal decision support system for flexibility management. This tool will analyse, digest and interchange information from both, the process parameters and the energy market, including the BAMBOO solutions. As a result, the operation of the plants will be improved in terms of energy and raw materials consumption, and will lay the foundation of new approaches in the energy market. BAMBOO will empower intensive industries to take better decisions to become more competitive in the use of natural resources in a broader context, in the spirit of facilitating the use of larger variability and quantity of RES.

BAMBOO consortium comprises strong industrial participation; 6 large companies as final users and 3 SMEs as technology providers, working with experienced RTOs and supporting entities. Lastly, the transferability potential of BAMBOO is extremely relevant as targeted process and plant improvements offer very high potential applications in other intensive industries.

In particular, work package 4 addresses the development, design, manufacturing, testing and validation of an industrial heat pump for low quality waste heat recovery to be integrated into different processes to increase the overall energy efficiency. Work package 8 addresses the final implementation, verification, commissioning and validation of the solution developed in WP4.

## <span id="page-77-0"></span>**4.2. Belgium**

### <span id="page-77-1"></span>**4.2.1. Overview of national HTHP industry**

The heat pump and refrigeration industry in Belgium consists mostly of system integrators and engineering companies. Currently two companies provide heat over 100 °C, namely Qpinch and Mayekawa Europe.

**Qpinch** is a start-up (2012) that has demonstrated its technology and is currently expanding. They have developed a MW-scale chemical adsorption heat transformer that is able to provide lifts up to 100 °C, using waste heat of 40 °C or higher. This way, a large amount of waste heat is transformed to a smaller amount of useful process heat, using only low amounts of electrical power. The (petro)chemial industry is Qpinch's main market.

Mayekawa, with head office in Japan, is an OEM of amongst others industrial compressors. **Mayekawa Europe** (Brussels) is one of the leading companies for refrigeration and gas compressors in the European market. They currently provide compressors for HTHPs up to 150 °C, both for projects with natural refrigerants and with HFOs, usually through local contractors, e.g. SKT and EQUANS Axima Refrigeration in Belgium.

A number of Belgian system integrators and engineering companies were identified, that are currently focused on low temperature heat pumps and cooling installations. These companies can move to higher temperature heat pumps when the market grows. For example, SKT already developed a two-stage ammonia heat pump (750 kW) that goes up to 80 °C.

- SKT: industrial cooling and heating, ammonia heat pump up to 80 °CFrigro: refrigeration and heat pump systems and components
- Fieuw Koeltechniek: industrial cooling and heat recuperation
- Colt: industrial climatisation
- Timmerman EHS: heat exchangers and piping

In addition to Belgian companies, several multinationals have large manufacturing and research centers in Belgium, such as Atlas Copco (compressors) and Daikin (heat pumps).

#### <span id="page-77-2"></span>**4.2.2. Overview of national HTHP market and application potential**

It is difficult to find complete and consistent values for industrial heat demand and waste heat availability in Belgium, but the following numbers clearly show that Belgium's industry has a large potential for the integration of VHTHPs. Compared to other countries, the energy demand of Belgium's industry is relatively large (compared to total demand), mostly due to the presence of a large (petro)chemical industry (40% of total industrial energy demand). Industrial heat demand below 200 °C is around 30% of the total; for Flanders this amounts to 20 TWh/y below 200 °C. The waste heat heat potential in Belgium's chemical sector is estimated at 1 TWh/y, of which about 1/3 is in the temperature range below 100 °C.

Because of low gas and high electricity prices, the ratio of electricity to gas price is unfavorable in Belgium, and among the highest in Europe. Based on Eurostat data from 2016-2020 for non-household consumers (excluding very large consumers), average prices in Belgium were €0.081/kWh for electricity and €0.024/kWh for gas. The resulting ratio of 3.43 is higher than most neighboring countries. Using the same metric, a ratio of 1.25 is found for Finland, 2.05 for France, 2.56 for Germany and 3.85 for the UK. However, carbon prices are increasing quickly: from below €10/tonCO2eq, to above €80/tonCO2eq in 4 years. If this trend continues, this can have a positive impact on heat pump economics in the future. In Belgium, both the federal and regional governments are in part responsible for energy and climate legislation, which tents to obstruct a well-coordinated approach. The ambition of the federal (national) government is to supply 80% of the total demand of the energy-intensive industries (chemical, petrochemical and steel) from CO2 neutral/sustainable energy in an economic cost-effective way by 2040. Wallonia wants to reduce emissions by 55% by 2030 (w.r.t 1990), both for ETS and non-ETS industries. Flanders, which has a larger industry, targets a 40% reduction of emissions in non-ETS sectors by 2030 (w.r.t. 2005). The European Commission commented that the Belgian plan "lacks reforms towards better climate policy".

The energy transition fund (ETF) subsidizes research, development and innovation projects related to energy since 2017. For 2022, a budget of €25M is allocated.

### <span id="page-78-0"></span>**4.2.3. Development perspectives for HTHP technologies**

To reach Belgium's climate goals, VHTHPs are a promising technology that can be integrated in energy intensive industries. End-users of the VHTHP technology in Belgium are foreseen in the chemical sector filling the gap for medium temperature heat between 100°C and 200°C relevant for, but not limited to, drying processes, surface treatment, continuous extrusion, distillation columns. In addition, the main heating need for the food and drink industry falls in the envisaged temperature ranges.

Several R&D projects have been funded in the past decade to pave the way toward commercialization of VHTHPs in Belgium. Currently, the (Flemish) Upheat-INES 2.0 project is running. We estimate the follow-up trajectory to take approximately 7-8 years, coinciding with an overall rise in heat pump technologies. In an optimistic scenario, the first Belgian pre-commercial VHTHP (TRL8-9) could be implemented by 2029 or 2030. If successful, manufacturing and assembly infrastructure could grow accordingly thereafter, but this is expected only in 2032-2035, depending on many market developments.

In a realistic scenario, implementation of HTHPs and VHTHPs could supply 2623 GWh of mid grade heat demand in Flanders, with chemistry, refineries and food being responsible for 41% of this potential. This is based on 18% potential supply of the mid-grade waste heat per sector. This 18% share is based on assuming a 75% share of 93 out of the 384 companies minimum 20 GWh waste heat supply. The conservative, realistic vs optimistic results are based on the carbon intensity reduction of respectively 59, 104 or 131 gCO2eq/KWhth compared to the baseline.

## <span id="page-78-1"></span>**4.2.4. Selected RD&D projects**

1. Upheat-INES, Upgraded High Temperature Heat in Energy Intensive Sectors

• **Funding code:** HBC.2020.2616

• **Running time:** 01/03/2021 – 31/08/2022

• **Funding amount:** €760 450

The UpHeat-INES project aims to develop industrial VHTHPs to upgrade residual heat to temperatures in the range of 160-200°C. In energy-intensive industries, residual heat from production processes is often reused to drive other low- or mid-temperature processes. Upgrading this residual heat for use in high-temperature processes in the range of 160-200°C is, however, uncommon. Today's heat pumps generally only reach a maximum temperature of 150°C.

Using thermodynamic simulations, Upheat-INES will evaluate when and how an industrial heat pump architecture can deliver higher temperatures at higher economic value. Specifically, the use of zeotropic mixtures and transcritical cycles is investigated. This approach has the potential to significantly increase the performance of the heat pump architecture, allowing for an optimal temperature match with various chemical processes.

An optimal architecture (cycle type, working fluid) will be chosen, based on thermodynamic, economic, technical and safety considerations. Finally, a lab scale heat pump prototype will be designed, to be constructed in a continuation project.

By upgrading residual heat for use in high-temperature processes, Upheat-INES will allow energyintensive Flemish industries to better exploit residual heat, pursue sustainable energy innovations, and significantly reduce their CO2 emissions.

2. Upheat-INES 2.0, Upgraded High Temperature Heat in Energy Intensive Sectors

• **Funding code:** HBC.2022.0539

• **Running time:** 01/01/2023 – 01/07/2025

• **Funding amount:** €1 945 546

The goal of the project is to decarbonize the production of industrial heat at temperatures between 160°C and 200°C by developing a very high temperature heat pump (VHT-HP) based on a zeotropic mixture of natural refrigerants.

The project develops a proof-of-concept very high temperature vapor compression heat pump that delivers heat sink temperatures between 160°C and 200°C. The performance of the system is evaluated based on the COP for given heat sink and source temperatures and output powers. Second law efficiencies between 40–60% are expected with a minimal COP of 2.4. The proof-of-concept system operates with a zeotropic water-ammonia working fluid mixture. The addition of ammonia is key in achieving a high COP and increases the optimal integration potential. Suitable materials for the construction and design of water-ammonia VHT-HPs are identified, tested and selected. The design, control and fault detection in heat pumps are often treated separately. The present project presents a combined design, control and operation strategy taking into account the variability of the heat source on multiple time scales.

3. HP4Drying, Energetic and environmental optimisation of drying processes by integration of heap pumps

• **Funding code:** IWT-CORNET 130375 • **Running time:** 01/03/2014 – 30/06/2016

• **Funding amount:** €1 192 034

The main target of this project was to integrate HPs into different industrial drying processes in order to exploit the corresponding advantages by energetic and environmental optimization. The focus was on convective dryers because they are used most frequently and can be most conveniently modified to integrate HPs. By adapting HPs to operate under varying temperature levels (by using fluid mixtures, hybrid and multi-stage HPs, HPs with variable pressure ratio etc.) and developing innovative control systems, HPs could better follow the drying process.

As drying is crucial in various production systems, the project results are expected to be welcomed among a broad spectrum of industrial branches proving it to be a trans-sectorial project. In the project consortium, RTOs with a strong track record on HP and/or drying technology are brought together with branch-oriented SMEs having practical knowledge of the production methods and specific technological/economic/ecological prerequisites in the industrial sectors. Fields associated with wood, textile, agricultural product processing, brick and tiles as well as biotechnology are represented by German RTOs. Within the Flemish User Group, additional branches are represented by participating companies.

## <span id="page-79-0"></span>**4.3. Canada**

#### <span id="page-79-1"></span>**4.3.1. Overview of national HTHP industry**

In Canada, the Heat pump industry is very limited in terms of equipment manufactures or assemblers (integrators). Among the very few companies present on the market, no one is in a position to offer products that can deliver heat above 100°C at the moment. This means that potential end users (process and manufacturing industry) have to rely on imported products and are expected to continue to do so for a certain number of years.

It is expected that future technical developments in the area of HT HPs will be driven mostly by companies from the private sector currently evolving in the refrigeration market (commercial and industrial). Among them, some recognized to have led the path in North America for systems using CO2, have recently decided to enter the heat pump market with systems able to supply heat at 70 °C – 80 °C , with applications in buildings equipped with hydronic heating distribution systems, and in the industrial sector. The technical developments for products that can supply higher temperature will most likely be supported by government and university research capabilities, and utilities. It is also expected that technology developments will be accelerated by an uptake of the demand in the industry favoured by Canada's new aggressive GHG emission reduction targets and, the attention that industrial process electrification is receiving. Expected policies toward process electrification will probably include government funding schemes for demonstration projects that besides providing valuable data for system improvement, will increase confidence in the technology and contribute to the development of the demand.

## <span id="page-80-0"></span>**4.3.2. Overview of national HTHP market and application potential**

The industrial sector in Canada currently accounts for about 37% of Canada's GHG emissions, with very energy intensive subsectors like Pulp & Paper, Mining, Oil & gas that rely heavily on fossil fuel to meet high-temperature process requirements. Hence, in the path to decarbonize process and manufacturing industries, Industrial process electrification and consequently, the adoption of high temperature heat pumps is expected to play a key role. So far, high temperature heat pump projects in the Canadian industrial sector are for the most part at the evaluation stage, very few have been implemented, however.

A recently completed departmental analysis on Canada's industrial sector potential to integrate different electrification technology, was performed by differentiating the technical, economic, and achievable potential, allowing to have realistic projections. The study looks at 170 different electrification technologies in a variety of industrial end uses which include: steam production, combined heat and power, mining, tractors, materials handling, high temperature heat, machine drives, medium temperature heat, steelmaking, clinker (i.e. cement), and low temperature heat. In that study, heat pumping technologies are considered to be applicable for the following end uses steam production, process heating, space heating and water heating. It is estimated that, for the next 30 years or so (2021- 2050) heat pumps have a realistic potential to reduce the GHG emissions of the industrial sector by 75 million of tons of CO2, corresponding to 27% of total GHG emission reduction resulting from process electrification, with 445 millions of GJ of fossil fuel abated. The usage of HTHPs for steam production is only estimated to contribute to 16,5% of the total electrification potential. Those values constitute the annual Cumulative total in 2050 (sum of annual Incremental Impact from the start of the time period, 2021). Several factors affecting heat pumps adoption in the industry are taken into account in the study, as well as how those factors will evolves over the next 30 year period, such as but not limited to: the commercially available technologies and their cost effectiveness compared to competing electrotechnologies, the regional differences in terms of electricity grid mix, provincial emission profiles of power generation, and energy cost structure, the Canadian policy on Carbon tax.

Another study performed on the path to process decarbonization identifies that the sectors that are the most likely expected to adopt high temperature heat pumps in a short term are: Thermomechanical Pup (TMP) and paper making, and the light industry defined by the size of the plants, temperature level requirement below 200 C and by the fact that CO2 emissions come mostly from heat production rather than form the processes involved. Those light industries include for example, food processing, dairy plants, breweries, lumber industry. Those sectors' heating needs will typically require temperatures below 200 C, for steam production, hot air drying, washing sterilization, drying, distillation and concentration. Heavy industrial sectors, like Iron pelletizing, steel making, cement, lime kraft pulping, oil refineries and chemicals are more likely to adopt other electrification strategies or if they adopt heat pumps, it might be on a medium or long term.

.

• Factors influencing the uptake of HTHPs at end-users: relevant national regulations or subsidy schemes which are making HTHPs very beneficial.

Like in all countries, the pace of high temperature heat pump uptake in Canada will be influenced by the availability of technologies and economic viability of the projects. Other factors that present some challenges and opportunities in the uptake of the technology in Canada are discussed below:

## **Policy**

Policies that can influence the uptake of heat pumps in the industry are still at an infancy stage in Canada. Thus far, much of the attention and effort has been focused on energy conservation and grid decarbonization. Policies are developed at the national and provincial level, with possible grant programs coming from the government or utility companies.

At the national level, one important policy already in place that is expected to influence high temperature heat pumps uptake by influencing the economic viability of projects is the Carbone tax. Since 2019, every jurisdiction in Canada has had a price on carbon pollution. Canada's approach is flexible: any province or territory can design its own pricing system tailored to local needs or can choose the federal pricing system.

So far, no grant programs at the national and provincial level target specifically the implementation of heat pumps in the industrial process. Some are, however, indirectly supporting the adoption of heat pumps. In the province of QC for instance, a fiscal policy was adopted for capital investments aimed at recovering heat in process industries that include heat pumping technologies. There is also a program, to which the federal government also contributes, that targets specifically heat recovery projects including the implementation of heat pumps.

With the aggressive GHG emission reduction targets (Canada has pledged to achieve a net-zero electricity system by 2035 and net-zero economy by 2050) more policies favoring the uptake of high temperature heat pumps, are expected to be adopted in a near future. Hence, the comprehensive study on the potential of electrification which is referred to in the text above, was conducted with the objective to plan federal electrification programs, encourage provincial/utility electrification deployment programs, shape supply-side policies with regards to interprovincial and international interties and to deploy funding to support provincial electricity system planning under electrification scenarios, and to inform policies for the prioritization of research and development funding.

## **Price of fossil fuels vs electricity**

Energy markets in Canada show a strong regional variation in utility rate, structure. Electricity can be up to 6 times more expensive (per unit of energy) vs. natural gas in some regions. This creates a challenging economic context for electrically driven systems.

#### **Grid mix and availability of green electricity**

Carbon emissions associated with electricity generation vary greatly in Canada by regions, and the adoption of heat pumps will most likely be more important in the coming years in provinces where the hydropower potential is abundant, like in British Columbia, Manitoba, Quebec, and more recently in Newfoundland and Labrador. In a lot of provinces in Canada with very energy intensive industrial sectors, like Alberta, some part of Ontario, a large portion of electricity generation is achieved using fossil-fuel based thermal plants. In these regions, the uptake of electrically driven HT heat pumps will depend on the pace of the greening of the electrical grids, as well as the relative cost of electricity to fossil fuels. This is where developments in thermally driven heat pumps can play a role in sectors where waste heat is available.

• Sectors and/or business models which are facilitating the application of high-temperature heat pumps.

Because of temperature requirements that can be met with available or close to market technologies, the following sectors will be the first ones to adopt HT heat pumps, in regions where the electricity grid mix and energy cost structure are favorable.

- o TMP Pulp and paper industries
- o Food and beverage: Dairy plants, meet processing, Slaughterhouses, breweries
- o Wood products
- o Other light industries
- Kind of systems most relevant (electricity driven or heat driven) and why

In regions where the grid is green (mainly in Qc and BC) electricity driven systems are most relevant. In regions where the grid is not green, or when the relative price of electricity to fossil fuel is prohibitive, and there is access to excess waste energy, then heat driven systems are most relevant.

## <span id="page-81-0"></span>**4.3.3. Development perspectives for HTHP technologies**

The advancement for high temperature heat pumps during the next 5 to 10 years in Canada will most likely come from industry main players in the commercial, institutional and industrial market, starting with products with supply temperature under 200 °C. But this assumption will need to be confirmed in the next 5 years. More high temperature heat pump projects are expected to be done in industrial processes in the next 10 years with imported products at first, and potentially with assemblers emerged from the national industry.

#### <span id="page-81-1"></span>**4.3.4. Selected RD&D projects**

At the moment, R&D projects on High temperature heat pumps is very limited in Canada, but as mentioned, this situation is expected to evolve favorably in the coming years, in the private sector supported by governmental research labs and academia. One project worth mentioning is done at Hydro-Quebec research center with the collaboration of EMERSON Canada, and University of

Sherbrooke. Project details are provided below.

**Title:** Development of a 150 °C supply temperature Heat pump using LGWP refrigerant

**Objective**: To build and test a low GWP heat pump to reach temperature as high as 150 °C from a heat

source at a temperature of 90 °C. **Project Lead:** Hydro-Quebec

**Partners**: Emerson and University of Sherbrooke

**Financing:** Hydro-Quebec, Emerson and NSERC Research grant

The project is still in its early stages. The work has been focusing on the development of a numerical model for performance assessment. Water (R-718) was selected as the refrigerant. The construction of a test bench will eventually follow, with the determination of operating limits and optimal operating conditions maximizing the production of useful energy.

The anticipated benefits of this research project are:

- Develop knowledge on high-temperature heat pumps to propel the commercialization of new technologies.
- Facilitate the decarbonation of industries efficiently.
- Changing environmental standards for refrigerants.

Distillation, Drying, Evaporation, Boiling and Extrusion are examples of industrial process which need high temperature heat (more than 140°C)

## <span id="page-82-0"></span>**4.4. China**

## <span id="page-82-1"></span>**4.4.1. Overview of national HTHP industry**

High-temperature heat pumps have many industrial applications in China, especially MVR for the zerodischarge treatment of high salinity wastewater. With the continuous promotion of clean energy by the government and the increasing demand for its applications, the application prospects of hightemperature heat pumps in the industrial field are promising. In recent years, the high-temperature heat pump industry has developed rapidly, with various products gradually maturing and the application field constantly expanding. With the continuous advancement of technology and the continuous reduction of costs, the application of high-temperature heat pumps in more fields will gradually become popular, such as papermaking,food, chemical, pharmaceutical, textile, printing and drying and so on.

The main research of high-temperature heat pump focus on the development of systems and key equipment. Compressors mainly include roots compressor, centrifugal compressor, screw compressor; different heat exchangers are used with anticorrosive properties and anti-blocking; many applications are integrated with the mechanical compressor or absorption high temperature heat pump.

Some manufacturers and technical suppliers include:

#### **Technical Institute of Physics and Chemistry, CAS**

TIPC is a professional research institution that carries out high-temperature heat pump research in China, committed to the research of steam centrifugal compressor, screw compressor, at the same time, cooperate with partners to carry out the different drying and evaporation system using high-temperature heat pump as heat sources.

## **Shandong Zhangqiu Blower Co., Ltd.**

[\(https://www.blower.cn/abouta.html](https://www.blower.cn/abouta.html))

The company mainly develops Roots compressors, centrifugal compressors, and integrates MVR evaporation and crystallization technologies into a complete system. The company has developed a series of B-type single-stage high-speed centrifugal steam compressors suitable for MVR systems. The maximum saturation temperature rise of a single compressor can reach 20℃. Additionally, the VR series Roots steam compressors have a maximum saturation temperature rise of 25℃ and 350m<sup>3</sup> /min steam volume.

#### **Beijing Huayuan Taimeng Energy Saving Equipment Co., Ltd**

[\(http://www.powerbeijinghytm.com/\)](http://www.powerbeijinghytm.com/)

Specializes in researching and producing absorption-based technologies for high temperature difference heat exchange, waste heat recovery, and second type absorption heat pump units. The second type absorption heat pump, used in the Daxie petrochemical waste heat recovery project, recovers the waste heat of 120℃ process hot water generated by the ethylbenzene production unit to produce 0.45 MPa、151℃ steam. It recovers about 15.583MW of waste heat and produces 11.8t/h of steam, saving 34,300 tons of steam and 15,330 tons of standard coal annually, and conserving 10.4 million tons of circulating water annually.

### **Kaeser Compressors Compression Technology (Suzhou) Co., Ltd** [\(http://www.ctscompressor.com/down.php\)](http://www.ctscompressor.com/down.php)

The company is committed to researching and developing single screw compression technology and has designed and manufactured a series of single screw steam compressors. The maximum suction capacity of the largest single screw compressor is 60 m<sup>3</sup> /min. The star wheels of the CSW series MVR steam compressor can withstand high temperatures of up to 200 ℃, and the single-stage temperature rise can reach 60~80℃. The products developed by the company are widely used in various fields such as MVR evaporation, oil and gas recovery, industrial gas compression, and expansion power generation compression.

#### <span id="page-83-0"></span>**4.4.2. Overview of national HTHP market and application potential**

According to the data from China's National Bureau of Statistics, China's total energy consumption in 2021 was 5.24 billion tons of standard coal, with fossil fuel consumption accounting for 83.4% and industrial energy consumption accounting for about 66.7% of the total consumption. Various industries have a demand for heat, such as food processing, wood processing, papermaking, pharmaceuticals, chemicals, metallurgy, rubber, and fibers. In 2020, energy consumption in the agriculture and food processing industry (including alcohol, beverages, and refined tea) and tobacco processing in China was 75.29 million tons of standard coal, wood processing consumed 10.07 million tons of standard coal, papermaking and paper products industry consumed 39.27 million tons of standard coal, pharmaceutical industry consumed 22.59 million tons of standard coal, chemical industry consumed 567.23 million tons of standard coal, black and non-ferrous metal s melting consumed 92.311 million tons of standard coal, and the fiber, rubber, and plastic product industry consumed 73.45 million tons of standard coal. Moreover, according to statistics, the waste clean-up volume was 235.117 million tons in 2020, and industrial pollution control investment was 45.42586 billion yuan, of which investment in the treatment of solid waste and wastewater amounted to a total of 7.46916 billion yuan. Industries such as food processing, wood processing, pharmaceuticals, and fibers generally require temperatures in the range of 60 to 200℃, and high-temperature heat sources above 100℃ are also needed for solid waste and wastewater treatment and sludge drying. High-temperature heat pumps can meet these demands, and with China's large energy consumption base, the market potential for high-temperature heat pumps is evident.

#### <span id="page-83-1"></span>**4.4.3. Development perspectives for HTHP technologies**

In recent years, the development of environmentally friendly high-temperature heat pump working fluids has become an important research direction. Among them, natural working fluids such as ammonia, water, carbon dioxide, and hydrocarbons are the focus of research.

Ammonia has a GWP and COP of 0, and using ammonia as a working fluid requires high pressure. Although ammonia itself is toxic and flammable, it has a large volumetric heat capacity and is a relatively mature heat pump working fluid. Currently, the absorption-compression hybrid heat pump using ammonia-water working fluid pairs is a hot research topic and an important direction for future energysaving and emission-reducing development.

Water, as an excellent working fluid for high-temperature heat pumps, has a high boiling point at atmospheric pressure. In China, MVR heat pump systems for zero discharge of wastewater will be a developing focus.

In the future, high temperature heat pump will use to recover the latent heat of evaporation, drying, and distillation in industrial operation processes, greatly reducing the energy consumption and operating costs of related industries.

## <span id="page-83-2"></span>**4.5. Denmark**

## <span id="page-83-3"></span>**4.5.1. Overview of national HTHP industry**

Denmark boasts a handful of component manufacturers who specialize in HTHP equipment. Among them are CS TechCom, Weel & Sandvig, and Johnson Controls.

- **CS TechCom** and **Weel & Sandvig** focus on developing components for heat pumps using water as a refrigerant. Both companies develop centrifugal compressors aiming at sink temperatures up to 200°C.
- **Johnson Controls** is a large manufacturer of custom- as well as pre-built heat pumps. They are developing HTHPs based on hydrocarbons as a working fluid. An example is a project in Germany that aims to achieve a supply temperature of 130 °C. Johnson Controls has also recently acquired Hybrid Energy to enhance their industrial heat pump portfolio.

Additionally, Denmark is home to numerous system suppliers and consultancies who are highly skilled in engineering design and installation of heat pumps in the industrial and district heating sectors (with supply temperatures below 100 °C). With access to sufficiently developed compressors, they too have the potential to deliver and work with HTHPs. Some of the notable system integrators include Verdo, Multikøl & Energi, Fenagy, Soft & Teknik, Aktive Energi Anlæg, and Tjæreborg Industri. The consultants identified include Rambøll, Niras, Viegand Maagøe, COWI and Process Engineering. Several of the aforementioned system integrators and consultancies participate in national- as well as international development projects.

## <span id="page-84-0"></span>**4.5.2. Overview of national HTHP market and application potential**

The potential for HTHPs in the Danish market is significant, especially when considering the size and economy of Denmark. This can be attributed to several factors, which will be elaborated on in this section.

Denmark has a rich history of agriculture, leading to a considerable number of food processing companies within its borders. Many food products require high-temperature heat for sterilization or hightemperature cleaning water for production systems. However, often these products are cooled using air, which results in warm air being dumped into the environment. In such cases, HTHPs can be employed to recycle the heat back into the process, minimizing the need for fuel burners or other heating utilities. Additionally, many food processing companies deliver frozen foods, which necessitates the use of large cooling compressors to freeze the product. The energy removed from the products in the freezing process is typically expelled to the ambient, either by cooling towers or dry coolers. The low-temperature heat removed during the freezing process can be upgraded to process heat or hot cleaning water.

Denmark has a high percentage of residential heating covered by district heating. Heat pumps are gaining acceptance as the future source of district heating, with low-temperature sources including ocean water, industrial waste heat, geothermal heat, and ambient air. As existing district heating systems relying on fuels such as natural gas, wood pellets, or biomass are upgraded or replaced, HTHPs would be a natural choice for the district heating transmission systems operating at higher temperature levels of up to 120 °C. [Figure 4-8](#page-84-1) shows a steady increase in installed heat pump capacity for district heating until today with a significant increase in 2020, indicating this trend.

![](_page_84_Figure_7.jpeg)

<span id="page-84-1"></span>*Figure 4-8: Total amount of heat pumps used for district heating in Denmark seen on left y-axis and blue bars, and accumulated capacity on right y-axis and green curve in MW. The overview only includes large scale heat* 

There is a long tradition for placing high taxes on energy and energy sources for private consumption in Denmark, with the aim of promoting energy savings. The industry, on the other hand, has had lower taxes, to ensure their global competitiveness. This creates a complication when using industrial waste heat for residential heating, since the industry can produce heat much cheaper than any private person, thereby creating a potential tax evasion by using waste heat.

To overcome this, the government has so far put taxes on industrial waste heat if used for private heating (and for office heating in the industry). The result may have been a success taxwise, but at the same time there has been a clear reluctance towards reusing the industrial waste heat.

As of January 1st, 2022, the rules have been changed so that the tax on waste heat is reduced to approx. 12 €/MWh. In addition, any company can cut this tax to 0 (zero) by joining a government program to monitor the energy efficiency of the processes used (acc. to standard ISO 50001:2018). If a technically possible energy saving is found, that can be implemented with a payback time of 5 years or less, then the company is obliged to implement this modification within 12 months. With this setup, there's a natural incentive to sell the waste heat (0 tax) and energy-optimize the production processes. Hence, the potential market for heat pumps for upgrading waste heat is expected to increase.

HTHP's can be integrated in different ways in industrial systems. In the "simplest" version, a factory uses its own production waste heat and upgrades this to the required process temperatures, so the heat can be returned directly back into production. In that case, it's possible to optimize the heat pump process, because all operating conditions are known. The drawback, if any, is that the system may not be very flexible, so any variation in production temperature or heat requirement could change the efficiency of the system. In other words, the waste heat must be available at the same time and rate as the required process heat to make the system function efficiently. In a batch process with many starts and stops, this may not be the case.

At the other end of the scale, the HTHP may be integrated into the local district heating (DH) system in a way that makes it possible to supply heat at temperatures above those normal for DH. In this way, the DH system can serve as an energy backbone system for both residential heating and industrial process heat/waste heat. The DH system would then use the hot water in the DH system as source for a HTHP delivering process heat to industries and maybe receive "waste heat" from the same industries. The big advantage of such a system is that it can serve as a buffer, taking up variations in both production and consumption. DH systems typically have very large quantities of hot water circulating in the piping, that can serve as buffer, both as source for a HTHP and sink for waste heat. Likewise, such a system could be able to use a variety of waste heat sources, effectively reusing the same heat energy many times at different temperature levels.

#### <span id="page-85-0"></span>**4.5.3. Development perspectives for HTHP technologies**

Heat pumps tend to be developed in steps, temperature wise. The first heat pump systems were typically used for residential heating, delivering hot water at 50 °C - 60 °C. The next development step was heat pumps for district heating, typically in the range of 80 °C - 90 °C. Such systems are mature and commercially available today. The next step is expected to be the design of heat pumps that can deliver industrial process heat economically favorably compared to fuel burners.

Denmark has an overall goal to reduce the CO<sup>2</sup> emission by 70 % in 2030. In a report published by "Klimarådet" different directions and initiatives are proposed to achieve this goal [49]. The different initiatives are described for different areas and what green technology can contribute with for reducing the emission of CO2. For the industry a reduction of 0.5 mil. ton CO<sup>2</sup> in 2030 can be achieved by electrification with special focus on heat pumps. In the same report an expected heat production for process energy is estimated to be 15 PJ. HTHPs are hence expected to become an acknowledged keytechnology for reducing CO2 emissions, and it is in the report suggested that 25 % of the CO2 reductions expected from the Danish industry are to be reached by implementing industrial heat pumps.

The Danish Energy Agency estimates that HTHPs is under a rapid development, and especially has a large potential for industrial processes with temperatures up to 150 °C [50]. Considering the temperature requirements of the Danish industry, it becomes apparent, that this corresponds to a considerable

demand for HTHPs.

## <span id="page-86-0"></span>**4.5.4. Selected RD&D projects**

A number of ongoing RD&D projects on HTHP is on-going in Denmark, this includes:

**1.** SuPrHeat (Sustainable process heating with high-temperature heat pumps using NatRefs)

| Duration            | 2020-2024                                                                                                                                      |
|---------------------|------------------------------------------------------------------------------------------------------------------------------------------------|
| Participants        | DTI (lead), DTU, Soft & Teknik, BOCK, Hamburg Vacuum, CS TechCom,                                                                              |
|                     | Spirax Sarco, Alfa Laval, Danfoss, Fuchs Lubricants, Viegand Maagøe,<br>GEA Process Engineering, Arla Foods, Danish Crown, Royal Unibrew, Chr. |
|                     | Hansen                                                                                                                                         |
| Total budget        | 8.2 mio. €                                                                                                                                     |
| Funding             | EUDP                                                                                                                                           |
| Further information | http://www.suprheat.dk/high-temperature-heat-pumps/                                                                                            |

SuPrHeat aims at developing and demonstrating a heat pump portfolio consisting of a concise number of natural refrigerants to provide optimal solutions for a variety of industrial applications. Three pilot plants are going to be developed and tested, and will be using R-718, R-744, and hydrocarbons as working fluid. Semi-hermetic piston compressors from BOCK will be the basis for both the hydrocarbon system and the CO<sup>2</sup> system. The steam compressors are turbo compressors from CS TechCom and a spindle compressor from Hamburg Vacuum. The hydrocarbon system, will supply temperatures of up to 160 °C, while the spindle steam compressor is expected to reach 200 °C.

![](_page_86_Figure_6.jpeg)

*Figure 4-9: The potential matching between choice of working fluid and application.*

The first pilot plant is currently being installed in DTI's HTHP lab, and start of testing of it is planned for August 2023. This heat pump is a hydrocarbon cascade heat pump with R-600 in the bottom cycle and R-601a in the top cycle, it has heating capacity of 500 kW, and a container enclosure around it, see [Figure 4-10.](#page-86-1)

<span id="page-86-1"></span>![](_page_86_Picture_9.jpeg)

*Figure 4-10: Pilot plant with 500 kW hydrocarbon heat pump from S&T installed at DTI (source: DTI).*

Furthermore, the SuPrHeat project develops advanced process integration methods for integrating industrial heat pumps in industrial sites, as well as strategies for the transition towards the identified integration scenarios, enabling industries to reap the benefits of heat pump technology in their production processes.

2. InterHeat (Demonstrating high-temperature heat pumps at different integration levels)

![](_page_87_Figure_2.jpeg)

This project focuses on HTHP and sector integration benefits. This includes solutions for heat recovery as well as load balancing through the district heating network. Two HTHP demonstration cases will be tested in both pilot tests at DTI and afterwards at end-users, please refer to Figure 4-11.

![](_page_87_Figure_4.jpeg)

<span id="page-87-0"></span>Figure 4-11: HP integration on sector level in the project "Demonstrating high-temperature heat pumps at different integration levels".

The integration on different integration levels requires technical solutions for effective integration. On process level, there is a strong dependency between the process and the heat pump system, which creates the need for load balancing and dynamic operation of the heat pump systems. On utility or sector level, efficient recovery of excess heat and/or provision of cooling are important aspects to ensure high performances. The development of technical solutions for sector level focuses on the integration of district heating, which will enable new business models that facilitate the sector integration.

The first system will be integrated in a protein powder drying process and based on semi-hermetic standard components for smaller capacities. The second system will be demonstrated as a solution for upgrading district heating for supply of process heating at temperatures of up to 160 °C. The second technology will be based on industrial open compressors for hydrocarbons and steam. The systems will be demonstrated for several months and outline the benefits of the different approaches, while the technological developments will be proven in long-term operation. Table 4-1 shows an overview of the two demonstration cases, while Figure 4-12 shows the compressor types from Frascold and SRM.

*Table 4-1: Overview of use cases in Interheat.*

<span id="page-88-0"></span>

| Us cas           | HC cascade system            | HC & steam system                     |
|------------------|------------------------------|---------------------------------------|
| Bottom cycl      | Iso-Butane (R600a) → 120 °C  | Butane (R600) → 120 °C                |
| Top cycl         | Iso-Pentane (R601a) → 160 °C | Water (R718) → 160 °C (steam)         |
| Compr ssor       | Frascold screw compressors   | SRM screw compressors                 |
| Th rmal capac ty | 500 kW                       | 1 MW                                  |
| Proc ss          | Drying                       | Steam for process heating (source DH) |

![](_page_88_Picture_2.jpeg)

![](_page_88_Picture_3.jpeg)

*Figure 4-12: Frascold screw compressor (left) and SRM screw compressor (right).*

<span id="page-88-1"></span>**3.** SPIRIT heat (Implementation of sustainable heat upgrade technologies for industry)

| Duration            | 2022-2026                                                                                                                                                                                                                                                                                                                 |  |  |  |  |
|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|
| Participants        | TNO (coordinator),<br>DTI,<br>DLR, European Heat Pump Association,<br>Mayekawa, SINLOC, EURAC, Euroheat and Power, Technical<br>University of Denmark, TVP Solar, Tiense Suiker, TLK Energy, GEA<br>Refrigeration Germany, Spilling Technologies, Smurfit Kappa Paper<br>Services, Smurfit Kappa Czech and Stella Polaris |  |  |  |  |
| Total budget        | 11.2 mio. €                                                                                                                                                                                                                                                                                                               |  |  |  |  |
| Financing           | Horizon Europe research and innovation programme under grant<br>agreement No. 101069672 (SPIRIT).                                                                                                                                                                                                                         |  |  |  |  |
| Further information | https://spirit-heat.eu/                                                                                                                                                                                                                                                                                                   |  |  |  |  |

The purpose of the SPIRIT project is to demonstrate stable and robust operation of three industrial heat pumps, integrated into operational production facilities at a Belgian sugar company, a Norwegian prawn processing plant, and a Czech paper mill. Three well-known technology providers (GEA, Mayekawa and Spilling) will design and construct the industrial heat pumps which will use waste heat and upgrade this waste heat to supply temperatures of 139 °C, 143 °C, and 157 °C. These demonstrations will increase the technical knowledge of and provide guidelines on heat pump integration in industry, and at the same time it will be demonstrated that industrial heat pumps can be integrated into existing processes without disturbing the production process. The GEA compressor and demonstration site for the sugar beet production site can be seen in [Figure 4-13.](#page-89-2)

The potential is great in the selected sectors. The paper & pulp and the food & beverage industries together cover 63 % of the potential high-temperature heat upgrade market. The expectation is that demonstration of the technology at these temperatures will pave the way for further development to achieve even higher temperatures in the future and thus spreading the use of the technology in the industry even further.

The project aims to have a sustained operation of between 2000 and 4000 hours per year for each demonstration system. This will demonstrate heat pump technology as a robust and reliable technology. At the same time, there is an expectation that a reduction in energy use of at least 30 % will be achieved - and as a result, a corresponding reduction in energy costs and CO<sup>2</sup> emissions.

![](_page_89_Picture_1.jpeg)

![](_page_89_Picture_2.jpeg)

*Figure 4-13: GEA screw compressor (left) and sugar factory in Tienen, Belgium (right).*

<span id="page-89-2"></span>**4.** Various projects concerning the development of steam compressors:

There have been various projects focusing on the development of steam compressors. These were mainly focusing on turbo-compressors and a novel spindle-compressor type. The steam compressor developments were initiated due to the immense potential for steam-based heat pump systems. Water can be easily integrated in industrial systems and has a high acceptance. The turbo compressors were based on turbochargers from automobile industries and the spindle compressor was designed based on vacuum pumps. Both compressor types have a great potential and are currently in the transition from prototypes to demonstrations in industrial applications. The R&D projects for steam compressor development include:

- Water vapor-based heat pump systems (ELFORSK 350-052): This project has been concerned with the long-term testing of a Rotrex turbo-compressor in an evaporator.
- Development of high temperature prototype heat pump (CS TechCom, Innobooster project): This project focused on the development of a prototype of a direct-driven turbo compressor.
- High-temperature Heat Pump for Tunnel Oven (ELFORSK 352-009): This project is concerned with the development of a prototype for a spindle compressor for large temperature lifts using steam as required in tunnel ovens. The project aims at delivering heat above 200 °C enabling the possibility to bake bread, cookies or even spray drying of dairy products.
- Optimization of heat pump driven steam systems (ELFORSK 351-022): This project has studied the general feasibility of heat pump-based steam systems for industrial process heat supply. It was mainly based on case studies analyzing the efficiency losses in existing steam networks. Critical bottlenecks and main losses were identified and built the basis for deriving approaches for enhancing the efficiencies of existing networks. The project confirmed the promising economic feasibility of heat pump-based process heat supply and identified promising cases.
- SpeedUP High-temperature heat pump based on steam turbo-compressor and high-speed motor:

The project includes the development and testing of a new concept with a directly driven highspeed turbo compressor to achieve an energy efficient, compact, and competitive heat pump using steam as a refrigerant. The target market is in replacing heat supply in industrial processes at temperatures above 100 °C and with heat output of 500 kW– 1500 kW.

## <span id="page-89-0"></span>**4.6. Finland**

#### <span id="page-89-1"></span>**4.6.1. Overview of national HTHP industry**

There is identified two Finnish heat pump manufactures which are providing HTHP above 100°C. They are Oilon Oy and Calefa Oy. Oilon ChillHeat heat pump products have the heating capacity range from tens of kW up to multi-MW systems. AmbiHeat heat pump products by Calefa Oy have the heating capacities from about 100 kW to 3 MW. Calefa Oy has heat pump products capable of providing heat up to 130°C and Oilon Oy has heat pump products for providing heat up to 120°C.

In addition to the heat pump manufacturers, there are companies providing heat pump components. Vahterus Oy is providing plate and shell type of heat exchangers also for the heat pump applications. The heat pump industry in Finland includes also engineering companies, system integrators and consultants. The large scale HTHP are mainly installed in district heating network operating by the local municipalities.

The technological development of HTHPs is mainly done in projects funded by national funding together by industry and universities and research agencies.

#### <span id="page-90-0"></span>**4.6.2. Overview of national HTHP market and application potential**

Production of industrial heat and district heat in Finland is approx. 90 TWh/a (see [Figure 4-14\)](#page-91-2). Renewable energy (mainly biomass) is used to produce the major share of the heat. However, the share of heat pumps and other energy sources has been increasing especially in district heating sector. The Finnish market for HTHP will be mainly in district heating and in different industrial sectors. Especially, the pulp and paper industry is a significant consumer of heating power in Finland. District heating is available in almost all cities and major municipalities and heat pumps are already used in the largest cities. These heat pumps typically utilize heat, for example, from large-scale water treatment plants or from other types of heat sources. A substantial amount of energy is needed for steam production and drying processes in pulp and paper industry and sawmills, which temperature level would be suitable for HTHPs. The temperature level required for typical pulp and paper drying processes varies between 95°C to 120°C which can be evaluated as a technologically feasible temperature level for hightemperature heat pumps.

If waste heat technical potential is used to evaluate HTHPs potential, there is approx. 19 TWh/a available waste heat in Finland [51]. The major industry sectors producing waste heat and having good opportunities for upgrading the heat with heat pumps are Pulp and Paper, petrochemical, and food processing.

Finland targets to be a carbon neutral society in 2035. The policy makers have supported transition for using electricity in district heating by decreasing electricity taxation for heat pumps, electric boilers, and geothermal heat production. The taxation rules have been changed on 1st of July 2022. This has increased the attractiveness of using heat pumps in district heating.

Electricity driven heat pumps are the most relevant systems to be utilized in Finland. There is abundant amount of renewable energy production, mainly wind installed and will be installed in Finland providing relatively cheap electricity in future. Generally, most of the electricity is produced by renewable energy or other low CO<sup>2</sup> emission production methods, such as nuclear power.

![](_page_90_Figure_8.jpeg)

![](_page_91_Figure_1.jpeg)

*Figure 4-14 Production of industrial and district heat in Finland in 2000-2021.* [52]

#### <span id="page-91-2"></span><span id="page-91-0"></span>**4.6.3. Development perspectives for HTHP technologies**

To achieve higher temperatures with heat pumps, it is anticipated that there are three main development fields, namely the working fluids, compressors and the heat exchangers/heat collection. There is a clear need for heat pump working fluids that can allow to reach high performances with high temperature lifts. Based on the new legislation and regulations in European Union (F-Gas regulations and PFAS regulations) the use of natural working fluids, such as CO2, ammonia and different hydrocarbons, seems to be favoured in heat pump systems in the future. This sets demands for further development for high temperature heat pumps that are capable to operate efficiently with natural refrigerants.

One of the key components in heat pump systems is the compressor and its operation and performance have a direct impact on the operation of the heat pump. Currently, there is a clear need for compressors that are capable for high temperature lifts and high pressure ratios. The compressor technologies need to be further developed and more compressor suppliers are needed in the market. In Finland, there are research and development projects going on for developing oil-free, hermetic turbocompressors for high temperature heat pumps.

There is also development work related to heat exchangers. The heat exchanger development includes improved heat exchanger designs and products for HTHPs having more compact size, increased heat transfer, and lower cost. The improvements related to heat exchangers would make the heat pump systems more feasible at different temperature levels. In addition, there is research and development work related to heat pumps that can collect heat from multiple heat sources, such as from different waste heat streams of an industrial process, instead of utilizing a single heat source. The efficient utilization of ambient air as a heat source in high temperature heat pumps is one of the important development topics, since air is a low-cost heat source that is widely available.

In addition, development and research on improved control systems and system optimization is needed for reaching the full potential of high temperature heat pumps.

#### <span id="page-91-1"></span>**4.6.4. Selected RD&D projects**

#### **Development of Next Generation Large Scale Heat Pump Systems (NEXTHEPS)- project.**

The NEXTHEPS-project investigates and develops design methods and new technological solutions that can be adopted in large-scale, high-temperature heat pump systems. The investigations are concentrated on heat pump systems having heating capacity of few MW, high-temperature heat pump markets, as well as more specifically on certain heat pump main components. The project can be generally divided to four main research topics, namely 1) heat collectors and heat delivery processes, 2) high-speed compressor technology, 3) integration of large-scale heat pumps to energy systems, as well as 4) market environment and business opportunities. The research project duration is 9/2022- 8/2024 and the project is funded by Business Finland. The project partners are LUT (Lappeenranta-Lahti University of Technology), Yaskawa Environmental Energy / The Switch, Vahterus, Fincoil LU-VE, Suomen Tekojää, Nevel, Suur-Savon Sähkö and Finnish Heat Pump Association.

In NEXTHEPS-project, the goals are to develop accurate analysis and design methods, as well as to find new technological solutions for large-scale and high-temperature heat pump systems. Industrial scale high-temperature heat pumps could replace heating systems based on combustion technologies using fossil fuels, for example in district heating networks and in producing low pressure process steam in various industrial sectors in the future. The goal of the project is also to strengthen the competitiveness and market share of Finnish heat pump industry in fast growing global heat pump markets.

In the project, the properties and characteristics of different types of refrigerants and their applicability for large-scale high-temperature heat pumps are investigated. The aim is to identify potential working fluids that are environmentally friendly and feasible for high temperature heat pumps from the technological and thermodynamic point of view. In addition, the tightening regulations related to usage of different refrigerants in the future are considered in the identification of the most potential fluids for the future heat pump systems.

Design and losses of heat pump cycles, heat exchangers, as well as heat collection from different types of heat sources are investigated. The heat exchanger research aims on developing advanced design methods and heat transfer correlations for heat pump heat exchangers, namely for the condenser and evaporator. The heat collection from air is also investigated as it is a low-cost heat source that is widely available. Research work on centrifugal compressor technology is concentrating on the design and losses of efficient heat pump compressor units, that are based on centrifugal type of compressors and high-speed electric motor technology. These investigations will cover the compressor aerodynamic design and loss estimations, electric motor design and cooling, magnetic bearing design, as well as rotor dynamic analyses. The project goal is to develop a combined design method for the compressor unit, allowing to perform a fast feasibility evaluation of the compressor unit with different fluids, operating conditions, and power levels. The effective integration and operation characteristics of large-scale hightemperature heat pumps as a part of larger energy systems, such as district heating networks or producing process steam, are investigated, and analysed. This includes the research on operation, optimization and control principles of large-scale heat pumps as part of larger energy systems. In the market environment and business opportunities research Market environment and business ecosystem modelling, commercialization opportunities and business models, as well as international scaling of the heat pump business are investigated.

### **Efficient, magnetic and bearingless heat pump for industrial and residential heating (EMBER)**

The project scope is to research, plan, design and construct a HTHP proof-of-concept. This includes all necessary tasks which will verify the technical concept and specification for the HTHP. In addition, the project scope is to investigate the business environment and the value chain of the future customers. Following the market analysis a value proposition will be created and principles of HTHP technology demonstration will be based on customer value verification.

The end goal is to replace fossil fuel burning heat industrial production with new radical technology of HTHPs, that are more economical and environment safe.

![](_page_93_Picture_0.jpeg)

*Figure 4-15: Developed bearingless high pressure ratio heat pump compressor.*

#### <span id="page-93-0"></span>**4.7. France**

#### <span id="page-93-1"></span>**4.7.1. Overview of national HTHP industry**

The heat pump market in France is highly developed in the building sectors. There are some high-power heat pumps working on district heating network. In industry, the market is relatively underdeveloped. Indeed, there are a few units, especially for standard heat pumps supplying a need at a temperature below 80°C with a large number of manufacturers, beyond this temperature the existing market is poor and the number of suppliers between 90 and 120°C is very low and upper for now there is no commercial solution available.

Indeed, the energy price ratio has more encouraged the deployment of combustible boilers, which are also less expensive in CAPEX than HP, and then subsidies has more encouraged energy efficiency on the existing solutions than replacing for HP. At the moment, the business models of heat pump projects most of the time do not permit to reach payback attended by industrial customers (target less than 4 years). Thanks to the France Relance plan dedicated on decarbonization of indutry and due to the french low carbon electricity, some heat pump and MVR projects have been awarded. The France 2030 and EU plan could allow for wider deployment.

This is not the only factor, fuel boilers can provide a variety of needs (temperatures and powers) in both water and steam. However, today, heat pump technologies can meet more and more industrial needs. Technologies available on the market can reach 120°C and produce several MegaWatts (MW). Heat pumps that can reach higher temperatures exist as demonstrators and the market should open up relatively quickly to reach 150°C. In addition, serious works to develop heat pump technologies producing steam are underway. Indeed, suppliers of heat pumps producing steam should appear on the market in the next two years.

There are more and more energy efficiency service providers such as Dalkia and others currently adding large heat pump and MVR in their offers for industrial customers.

Also there are many system integrators working on steam generation such as TGE, France Evaporation, Tech-Evap, TLV, Armstrong and others. Some of these companies have strong experience in MVR and steam generation.

#### **4.7.1.1. Manufacturers with factory in France**

#### **ENERTIME**

Enertime is a french manufacturer of VHT heat pumps. Enertime's core business is rather the ORC cycle, but the company has been able to transpose its know-how to design a proprietary centrifugal compressor and a HTHP. Enertime heat pumps run on R-1233zd(E), which is one of the new highperformance HCFO fluids with a very low GWP and can supply superheated hot water up to 120°C. The compressors used are single or two-stage centrifugal compressors and the capacities offered range from 2 to 10 MW.

Enertime is one of the partners of the EU projects which were awarded at the last Horizon call wich could be an opportunity to do the first demonstration of their HTHP.

#### **CARRIER**

Carrier offers a wide range of heating solutions: air-water, water-water heat pumps, heating only or reversible, with scroll and screw compressors with a heat output of 14 to 2,500 kW. Carrier heating units are designed to provide hot water temperature up to 85°C.

AquaForce® is the high temperature water-to-water heat pump from CARRIER using HFO R-1234ze refrigerant and screw compressor at fixed speed. The nominal heating capacity ranges from 200 kW up to 2 500 kW.

Aquaforce PUREtec 61XWHZE water-to-water heat pumps are the premium solution for industrial and commercial heating applications (district heating, ambient heating, industrial heating) where users, engineers and building owners demand optimum performance, hot water outlet temperature high, maximum reliability and an environmental solution.

## **JONHSON CONTROLS INDUSTRIE (JCi)**

Johnson Controls Industrie has a factory in France (Carquefou, 44) dedicated to the assembly of cooling systems and high power and high temperature heat pump for many applications such as commercial and military navy, district heating and industry. JCi has a dedicated R&D team working on the developpment of high temperature heat pump. JCi is currently working on a high temperature heat pump producing hot water up to 120°C with 1234ze-E working media. This heat pump is based on a centrifugal compressor.

EDF and JCi have developed a technology of water to water high temperature heat pump named PACO using water has working fluid. Experimental tests have been realized up to 130 °C. At this level, technical feasibility is demonstrated with a centrifugal compressor with magnetic bearings. The first industrial demonstration is being researched.

## **TRANE**

Trane is a large American group, TRANE is established in France with two factories dedicated to all European, EMEA markets and provides local service through its 16 sales offices. Trane designs, manufactures and provides services for HVAC-R control systems and modules to create and maintain safe, comfortable and efficient working environments for industrial buildings and industrial processes.

In France, TRANE has a test center and 2 production sites allowing to supply 7,000 units per year, up to 3.5 MW.TRANE's goal is to reduce CO2 emissions at its customers by 1 Gt by 2030.

To achieve this, TRANE is working on HFO refrigerants, on optimizing machine performance, on heat recovery and the services it can provide to its customers through equipment modernization and maintenance. Today, TRANE is working on the marketing of high and very high temperature heat pumps (120°C) for waste heat recovery applications on industrial sites. Requests from manufacturers for heat pumps providing temperatures above 85°C are increasingly frequent. TRANE is a partner of the Finnish group OILON, manufacturer of heat pumps up to 120°C.

## <span id="page-94-0"></span>**4.7.2. Overview of national HTHP market and application potential**

The manufacturing industry in France represent an added value of 219 billion euros and around 7,5 million direct and indirect jobs (Source: INSEE).

The share of the energy consumption in the French industry sectors is given by [Figure 4-16.](#page-95-1)

![](_page_95_Figure_0.jpeg)

*Figure 4-16: The distribution of energy consumption between industrial sectors*

<span id="page-95-1"></span>On the total consumption of industry representing around 315TWh (80MtCO<sup>2</sup> ) there is around 236TWh dedicated to heating almost completely produced by fossil fuels. The French Center for Economic studies and research on Energy (CEREN) has done a specific study on heat needs and wasted heat by sector, temperature levels and others criterias of the french industry. Analysis of these datas show that the sector with the biggest heat need at temperature lower than 150°C are food, chemical and paper/cardboard industries.

The french agency of the ecological transition, Ademe, has done an analysis of CEREN datas in order to give an overview of the potential of energy efficiency possible in industry by recovering waste heat estimated at a total of 109,5TWh (Source: Ademe Chaleur Fatale 2017 -

[https://www.ademe.fr/sites/default/files/assets/documents/chaleur\\_fatale-8821-2018-06\\_pdf.pdf\)](https://www.ademe.fr/sites/default/files/assets/documents/chaleur_fatale-8821-2018-06_pdf.pdf).

![](_page_95_Figure_5.jpeg)

*Figure 4-17: Left: Distribution of waste heat generation. Right: Process of origin for the waste heat.*

Most of the waste heat interesting for the HP market is lower than 100°C which represent more than 50% of the total waste heat and mostly come from cooling and drying processes.

### <span id="page-95-0"></span>**4.7.3. Development perspectives for HTHP technologies**

France is committed within its low carbon strategy to reduce by 35% by 2030 and by 81% by 2050 the greenhouse emissions of industry. The low carbon electricity mix available in France thanks to a mix of nuclear and renewable energies make electrification one of the best solution to climate neutrality.

With the "France 2030" plan, the government wants to increase the growth of industry while decarbonizing it. In this plan there is specific subsidies package dedicated to the deployment of low carbon technology demonstrators in industry and dedicated to develop new factories and products allowing decarbonization such as HTHP.

On the potential for HTHP in France, EDF has worked on an analysis of the data from CEREN and presented this analysis in 2019 at the High Temperature Heat Pump Symposium in Copenhagen.

![](_page_96_Figure_0.jpeg)

*Figure 4-18: Distribution of heat pump potential between temperature ranges*

This potential is a maximum estimation taking into account the different temperature levels of heat needs and waste heat available in each sector of industry.

The food, chemical and paper industries represent around 65% of this potential.

Even with the low price of electricity in France and some subsidies, dedicated to heat pump, projects don't always go to the end mostly because the industrial customers are used to short payback (less than 4 years) and because they need more warranties on the energy price variation.

With a large part of the potential upper than 100°C and a commercial offer limited to 120°C mostly with water as carrier, it is necessary to develop an offer on the market up to 150°C and with steam production in order to cover this potential. More and more manufacturers and actors on the market are working to develop this offer and demonstrators.

#### <span id="page-96-0"></span>**4.7.4. Selected RD&D projects**

## **1.** TRANSPAC

#### **Funding agency: Ademe**

## **Context**

Optimization and integration studies of high-temperature heat pumps have shown that, in the case of processes having heat requirements with a large temperature difference such as industrial dryers, the use of a transcritical cycle makes it possible to multiply the coefficient of performance (COP) of the heat pump by two compared to a conventional cycle.

These works led to the filing of a patent by EDF. Following this study, a thesis with ARMINES made it possible to produce a first pilot prototype of 30 kW thermal whose expected energy performance was observed: COP close to 4 under the conditions of an industrial dryer.

#### **Objective**

As a continuation of this work, the ADEME TRANSPAC project consists of designing, producing and installing a scale 1 industrial transcritical heat pump demonstrator on the dryer of an industrial paper site.

The installation of this innovative transcritical heat pump will make it possible to save fossil energy and reduce the site's CO2 emissions and will constitute a first industrial reference and will be the starting point for the dissemination of this technological offer on other sites.

#### **Progress of the project**

Preliminary tests were carried out under industrial conditions on the 30 kW test bench and made it possible to select the optimum fluid/oil couple. At the end of these tests, specifications were drawn up for the demonstrator. The key points are the choice of compressor and the sizing of the gas cooler.

To secure the project, additional tests are carried out on a compressor of the same brand and technology as the one chosen for the demonstrator, but on a 1/4 scale. According to the compressor supplier's recommendations, the compressor must run for 1000 hours (transcritical compression/expansion cycles). Oil samples are regularly taken to be analyzed and thus monitor the state of wear of the compressor in order to adjust the periodicity of the maintenance to be carried out to keep the compressor in good working order.

To date, an operating contract has been signed between DALKIA and the manufacturer. The work will take place in 2022 and the experimental commissioning is scheduled for the end of 2022. A 9-month experimental operating period is scheduled to validate the performance of the machine before entering the industrial operating phase.

## **Perspectives**

The innovation is based on the association of the transcritical cycle with very high temperature levels (> 130°C).

The demonstrator will be installed on the industrial dryer to validate its technical, economic and environmental performance under industrial production conditions.

This transcritical heat pump will save fossil energy of around 5.2 GWh/year, which will be replaced by electricity consumption of around 1.2 GWh/year. The reduction in CO2 emissions will be around 1,000 teq/year.

The results of the project could be transposed to all industrial sectors, in particular food industry and chemical industry, whose energy consumptions linked to drying operations are also significant: approximately 11 TWh/year for food industry and 6.3 TWh/year for chemicals.

#### **2.** BAMBOO: see detailed description in Austria part

Concerning french implication in BAMBOO project, EDF Lab Les Renardières will test a steam generator heat pump. A water-to-water heat pump will be used to heat pressurized water. In a flash tank, this pressurized water is expanded with a throttle and a part of the water mass flow is converted to steam during the expansion. The generated steam can be utilized, the rest of the pressurized water is recirculated to the heat pump together with feed water. The flash tank system has been successfully tested first in the EDF's laboratory (Les Renardières, 77 France) and then operated in the Arcelor Mittal's laboratory (Aviles, Spain).

## <span id="page-98-0"></span>**4.8. Germany**

## <span id="page-98-1"></span>**4.8.1. Overview of national HTHP industry**

The HTHP industry in Germany is made up of traditional manufacturers of heat pumps for domestic heating as well as power plant manufacturers and/or operators, traditional refrigeration engineering companies and start-ups. However, currently only a couple of technology suppliers offer technologies for temperatures above 100 °C. A distinction between system integrators and technology suppliers is difficult to state. There are however, plenty of system integrators that could design, manufacture, and install a HTHP, if they get a compressor supplied with guarantees. The following relevant suppliers were identified in the market analysis and provided information on their products in the technical survey:

**1. Siemens Energy** have been developing heat pumps since 1980s and 1990s. In fact, around 50 large scale heat pumps with capacities around 30 MW and capable of delivering temperature levels up to 90 °C are still running till today from that period, see [Figure 4-19.](#page-98-2)

![](_page_98_Picture_4.jpeg)

*Figure 4-19 An existing Siemens energy heat pump<sup>4</sup>*

<span id="page-98-2"></span>The heat pumps provided by Siemens are specifically tailored and designed based on a particular application, temperatures of heat source and sink, required capacity and the associated boundary conditions such as the available electrical connections and the space. Most relevant applications for the heat pumps are chemical, pulp & paper, food & beverage and district heating. Moreover, Siemens provides turbo compressor technology as geared type or single-shaft depending on the application. The compressor drive can also be electrical or mechanical using gas engine or gas/steam turbine. Currently a laboratory demonstration of a kW-size heat pump is being developed with temperatures up to 160 °C with R-1233zd(E) and R-1234ze(E) among other tested refrigerants, see [Figure 4-20.](#page-98-3) Moreover, as to what will be mentioned in section 4.8.4, Siemens has managed to develop and construct a pilot plant at Vattenfall in Berlin for district heating network. The plant is able to supply a capacity of 8 MWth and sink temperatures in the range of 85 °C – 120 °C.

![](_page_98_Picture_7.jpeg)

*Figure 4-20: Exemplary model of a new Siemens Energy high temperature heat pump<sup>5</sup>*

<span id="page-98-3"></span><sup>4</sup> <https://heatpumpingtechnologies.org/annex58/wp-content/uploads/sites/70/2022/07/siemens-energy-hthp-technology.pdf>

<sup>5</sup> [https://press.siemens-energy.com/global/de/pressemitteilung/vattenfall-und-siemens-energy-treiben-mit-grosswaermepumpe-die](https://press.siemens-energy.com/global/de/pressemitteilung/vattenfall-und-siemens-energy-treiben-mit-grosswaermepumpe-die-klimafreundliche)[klimafreundliche](https://press.siemens-energy.com/global/de/pressemitteilung/vattenfall-und-siemens-energy-treiben-mit-grosswaermepumpe-die-klimafreundliche)

<span id="page-99-0"></span>**2. COMBITHERM GmbH<sup>6</sup>** together with **BITZER** have developed a high temperature heat pump that can provide temperatures up to 120 °C. The HTHP uses one to three screw compressors using R1233zd(E) as a refrigerant and equipped with frequency converters for controlling the delivered capacity. The heating capacity ranges from 0.3 MW (1 compressor, 35 °C heat source) to 3.3 MW (3 compressors, 90 °C heat source).<sup>7</sup> The main relevant application for this heat pump is in drying processes where the source heat and sink are present in the same process.

In a project example, COMBITHERM have installed four high temperature heat pumps having a total capacity of 3.5 MW in Geelen Counterflow's first electric counterflow dryer.<sup>8</sup> The installation has resulted in saving 3,000 t of CO2 emissions and energy reduction of 15,000 MWh per year.

![](_page_99_Picture_2.jpeg)

*Figure 4-21 COMBITHERM HWW 2/9583I R1233zd(E) with BITZER CSH2T screw compressors[6](#page-99-0)*

**3. Spilling Technologies GmbH**<sup>9</sup> is known to manufacture expansion machines and compressors for steam. The focus of Spilling has been shifted towards manufacturing steam compressors that can upgrade waste heat to useful temperature and pressure levels. Spilling has manufactured a piston steam compressor that can be integrated in open or closed HTHP cycles, see [Figure 4-22.](#page-99-1) Typical applications of this heat pump are the same as mentioned in the previous manufacturer section, mainly chemical, food, pharma industry and even petrochemical. The technology provided by Spilling is most promising using a source temperature of 120 °C at a pressure of 2 bar(a) and a sink temperature and pressure of maximum 250 °C and 40 bar(a) respectively. The heat pump can provide steam flows of approximately 2t/h to 20t/h and can provide thermal loads between 1 MW and 15 MW.

<span id="page-99-2"></span>![](_page_99_Picture_5.jpeg)

*Figure 4-22 3D drawing of a Spilling steam compressor [9](#page-99-2)*

<span id="page-99-1"></span><sup>6</sup> <https://www.combitherm.de/de/produkte-und-loesungen/hochtemperaturwaermepumpen/>

<sup>7</sup> <https://heatpumpingtechnologies.org/annex58/wp-content/uploads/sites/70/2022/12/combithermhthpannex58.pdf>

<sup>8</sup> <https://www.geelencounterflow.com/insights/geelen-counterflow-starts-up-first-electric-dryer-for-cargill-ewos-in-norway/>

<sup>9</sup> <https://heatpumpingtechnologies.org/annex58/wp-content/uploads/sites/70/2022/07/hthpannex58suppliertechnologyspilling.pdf>

<span id="page-100-1"></span>**4. Piller<sup>10</sup>** uses the existing process fluids, for example vapor from the process or water. Compressing the vapor directly is a principle that corresponds to the classic mechanical vapor compression (MVC), see [Figure 4-23.](#page-100-0) As seen in the figure, water is used in the evaporator as a working fluid to generate steam at low temperature and pressure. This steam is compressed afterwards by the blowers developed by Piller to the high temperature and pressure needed by the heating system.

![](_page_100_Picture_1.jpeg)

*Figure 4-23 Piller mechanical vapor compression [10](#page-100-1)*

<span id="page-100-0"></span>The main innovation developed by Piller is the high-performance blowers. The driving energy can be electric or by steam turbines. The compressor technology developed by Piller is radial turbomachine series of single stage. The most relevant application is food, chemical, paper, petrochemical and beverage industries. Piller provides solutions for large industrial plants with high demands on steam with high temperature or for heating column reboilers and evaporators using direct vapor recompression.

![](_page_100_Picture_4.jpeg)

*Figure 4-24 Piller high performance blower [10](#page-100-1)*

**5. SPH -Sustainable Process Heat<sup>11</sup>**, featuring the ThermBooster system with a reciprocating piston currently under development, being able to work with a broad range of HFO, HCFO and natural HC refrigerants, with a planned heat supply capacity of 300 kW – 5 MW providing a heat sink temperature of 80°C up to 165°C with heat source in the range of 20 °C – 120 °C. Whereas Siemens for example is a technology provider and system integrators, the focus of the startup SPH is currently on the technology provision and demonstration.

While the MVR systems are already well established in the industry, all of the offered compression heat pumps were so far only demonstrated on pilot scale and therefore are still under development. Siemens Energy offers tailored solutions for temperatures up to 160 °C and thermal capacities between 8 to 70 MW for one turbo compressor unit. So far two HFO's were implemented, other refrigerants are currently in development. SPH is a small company specialised in HTHP. The developed reciprocating piston compressor can supply a thermal capacity between 0,5 and 1 MW. With HFOs a maximum temperature of 165 °C is possible, natural hydrocarbon are planned for further rise of the temperature.

<sup>10</sup> <https://heatpumpingtechnologies.org/annex58/wp-content/uploads/sites/70/2022/07/hthpannex58pillartechnology.pdf>

<sup>11</sup> <https://heatpumpingtechnologies.org/annex58/task1/>

In addition to the above-mentioned suppliers, the following technology suppliers/manufacturers located in Germany were identified:

- ENGIE formerly Dürr thermae with a CO2 heat pump
- GEA Refrigeration Germany with various heat pumps lines, e.g. GEA Grasso RedAstrum or RedGenium
- GEA MVR/TVR System suppliers
- Ago Energie<sup>12</sup> engineers and constructs decentralized energy plants. In terms of HTHPs, AGO offers the product line AGO Calora with heat supply of up to 140°C using ammonia/water as a refrigerant in a combination of an absorption and a compression cycle. (see [Table 4-2\)](#page-102-2)
- SMARDT-OPK- traditional refrigeration system supplier, using a turbo compressor also usable for HTHP

In addition to the listed suppliers, various companies are currently investigating their future role in HTHP. This includes new possible market players as well as manufactures of components such as heat exchangers. Due to the current dynamic, a comprehensive list is difficult to obtain. Furthermore, energy suppliers are interested in expanding heat contracting for the industry with decarbonized solutions, like HTHP. In the past years various R&D projects were realized, as described in section [Selected RD&D](#page-102-1)  [projects4.8.4.](#page-102-1)

#### <span id="page-101-0"></span>**4.8.2. Overview of national HTHP market and application potential**

Despite of the increased interest, the market share of HTHP is still negligible. Regarding the overall heat consumption in German industry with approximately 500 TWh per year, of which ca. 25 % corresponds to temperatures below 200 °C, the application potential appears to be great. Moreover, 6.1 Million households, which is about 14 % of all houses and apartments in Germany are connected to district heating networks. The amount of heat provided in these networks was about 126 TWh in 2020 which can be provided by HTHPs technologies.

One barrier is the unfavourable price ratio between electricity and gas price per kWh, as the price for 1 kWh electricity is about three to five times as much as the gas price. According to statistical data of the German federal statistical office (Destatis) the average energy prices for the industrial sector are 25 ct/kWh electricity and 8 ct/kWh gas respectively<sup>13</sup>. This is an electricity to gas price ratio of 3 which only changed from the recent years compared to the year 2020 where this ratio was about 5. Due to the increased costs for CO<sup>2</sup> emissions in Europe this ratio is decreasing and expected to decrease further in the coming years. Furthermore, current politics and public opinion are putting pressure on the industry to decarbonize their processes.

So far, the German government does not provide a specific funding scheme for HTHP but there are some possibilities within other programs. For example, HTHP can be subsidised through the national German funding schemes, within the Applied non-nuclear research funding in the 7th energy research program (7. Energieforschungsprogramm) of the German Federal Ministry for Economic Affairs and Energy, where further development of heat pumps with a focus on new temperature levels and increased efficiency is one topic. Also, the funding scheme called "decarbonization of the industry" of the German Federal Ministry for the Environment, Nature Conservation and Nuclear Safety can be applied for companies of energy intensive industries (recorded in the EU Emission Trading Scheme (EU-ETS)) to implement technologies that reduce their emissions.

Moreover, in the light of the phase-out of coal-fired power generation by 2038 and the shutdown of all nuclear power plants on April 1, 2023, the use of heat pumps in heating networks is receiving increased support in Germany. The Federal Funding for Efficient Heating Networks (BEW) supports the construction of new heating networks with a high proportion of renewable energies and the decarbonization of existing networks. The program, which has been running since September 15, 2022, offers funding for transformation plans and feasibility studies as well as (thereafter) systemic funding for

<sup>12</sup> AGO Calora - [industry and high temperature heat pump \(ago-energie.de\)](https://www.ago-energie.de/en/ago-thermal-technology/ago-calora-industry-and-high-temperature-heat-pump/)

<sup>13</sup> [https://www.destatis.de](https://www.destatis.de/)

new construction and existing networks in the form of an investment cost subsidy. The installation of a heat pump is also eligible for funding as an individual measure (up to 40%, restricted to a maximum of the amount required to make the project economically viable). Furthermore, it is then also possible to apply for a subsidy for the operating costs of these systems for a maximum of 10 years. A study of the hurdles in the use of large-temperature heat pumps in district heating networks<sup>14</sup> shows that this funding is necessary at the present time to bring the developing technologies into use.

## <span id="page-102-0"></span>**4.8.3. Development perspectives for HTHP technologies**

Heat pumps with a sink temperature above 100 °C are currently under investigation by a number of research institutions and companies. While large scale mechanical vapor recompression systems have been available for a number of years, different trends can be observed: The first is the development of large high-temperature heat pumps with other refrigerants than water (R-718). Heat pumps based on vapor-compression cycles will be expanded to higher temperatures. Generally, it can be anticipated that a number of different technologies will be developed for an optimal match of heat source and sink.

Due to the coal phase-out, a number of power plants will be shut down. Without these, many district heating networks are without a heat source. While many cities are building gas turbine plants for combined power and heat generation, large-scale high-temperature heat pumps are a possible solution when the existing district heating networks are too kept with original temperature levels.

Generally, there is a large pressure on the industries with a high-process heat demand such as chemical and paper industries to develop solutions for carbon neutral production. Germany plans to be carbonneutral by 2045 and to reduce the emissions by 55 % until 2035 compared to 1990. The prices for CO2 certificates are increasing from 25 €/t in 2021 to 55 €/t in 2025. Many of the companies plan on a significant reduction of their greenhouse gas emissions and are looking for solutions for fossil-free process heat generation. Since the heat sources are usually distributed, but heat usage is centralised via a steam network, the size of the heat pump will be adjusted to the available heat source and usually small compared to the centralised steam generation facilities. Furthermore, smaller production companies, such as food production will have to adopt their process heat generation, where hightemperature heat pumps can be a viable solution, given that they will reach industrial maturity at a competitive cost. The cost reduction will be an important topic, especially for applications far above 100 °C, where the first systems are now being developed. Economically attractive systems will be achieved by standardisation and an increase in performance parameters, especially for MVR systems. There are no official aims for an overall capacity or a number of installations, but a replacement of a steam generation capacity of 50 TWh/a of gas burners by alternative sources is expected for 2030, with more than half of this substitution achieved by high-temperature heat pumps.<sup>15</sup> Besides using available waste heat streams, alternative heat sources (solar, geothermal, water bodies etc.) will become increasingly important, making progress on storage for the intermittent heat supply mandatory.

#### <span id="page-102-1"></span>**4.8.4. Selected RD&D projects**

[Table 4-2](#page-102-2) presents the most relevant national and international R&D projects in Germany related to HTHPs. The table briefly describes the motivation and objectives of the project, the partners involved in the project, the running time, the key results and expected outcomes.

*Table 4-2 Relevant national and international R&D projects in Germany*

<span id="page-102-2"></span>

| Project                 | Key information and output                                                |
|-------------------------|---------------------------------------------------------------------------|
| HT Wärmepumpe:          |                                                                           |
| Entwicklung einer       | Motivation and objectives:                                                |
| Hochtemperaturwärmep    |                                                                           |
| umpe für Temperaturen   | The aim is the demonstration of an advanced hybrid high-temperature heat  |
| bis zu 160°C auf Basis  | pump for upgrading waste heat from source temperatures of 60 °C to 100 °C |
| eines                   | to sink temperatures of 100 °C to 160 °C. Proposed heat sink media are    |
| Kältekreisprozesses mit | steam and pressurized hot water. Proposed use cases are in the chemical,  |

<sup>14</sup> <https://www.isi.fraunhofer.de/de/competence-center/energiepolitik-energiemaerkte/projekte/fernwp.html#1904386173>

<sup>15</sup> Luderer, G., C. Kost, and D. Sörgel. "Ariadne-Report: Deutschland auf dem Weg zur Klimaneutralität 2045–Szenarien und Pfade im Modellvergleich." *Potsdam Institute for Climate Impact Research. https://doi. Org/10.48485/pik*

**Lösungsumlauf (**HT heat pump: development of a high-temperature heat pump for temperatures up to 160°C based on a refrigeration cycle with solution circulation)<sup>16</sup>

paper and food industries.

**Total Budget:** 483.109,00 EUR

**Running time:** 01.10.2018 – 30.06.2022

**Partners:** AGO AG Energie+Anlagen, Kulmbach, Bayern

**Key results:** Besides the experimental validation and gain of operational experience, the project aims at verifying the simulations and along with these the theoretical determined efficiency.

**Output:** The investigated technology is based on a European patent (EP 3 355 002 A1). This patent expands the state-of-the-art hybrid heat pump with ammonia/water as a working fluid by a number of components in different configurations. Hybrid heat pumps combine an absorption and a vapor compression cycle. At low pressures and temperatures, the ammonia is desorbed from the water by the waste heat. The liquid water is pumped to the high pressure, while the ammonia vapor is compressed. At the high pressure, the ammonia is absorbed by the water, thereby releasing its heat of solution. By throttling the solution, the cycle is closed.

In this project, the basic cycle is expanded by a two-stage compression with intercooling by the rich solution, a rectification column for reducing the volumetric flow in the desorber, and solution heat exchangers for internal heat displacement. A prototype of the developed heat pump with a thermal capacity of 1 MW was installed in Neuburg for hot water production up to 140°C. It is used to upgrade the waste heat from a combined heat and power plant which could before only used in the winter season for heating purposes.<sup>17</sup>

![](_page_103_Picture_8.jpeg)

*Investigated heat pump design of the project "HT Wärmepumpe"*

<sup>16</sup> <https://www.enargus.de/pub/bscw.cgi/?op=enargus.eps2&q=03ET1588&v=10&id=953112>

<sup>17</sup> [HT Wärmepumpe: Klimafreundliche Wärmepumpe erreicht 150 Grad Celsius -](https://www.industrie-energieforschung.de/news/de/ht_waermepumpe_ammoniak_kaeltemittel) industrie-energieforschung.de

**Verbundvorhaben: EnEff:Wärme: Qwark3 - Quartiers-Wärme-Kraft-Kälte-Kopplung / Teilvorhaben: 'Aufbau einer Groß- und Hochtemperaturwärmep umpe für die Einbindung in das Berliner Stadtwärmenetz' (**Joint project: EnEff:Wärme: Qwark3 - Quartiers-Wärme-Kraft-Kälte-Kopplung / Subproject: 'Construction of a largescale and hightemperature heat pump for integration into the Berlin urban heating network')<sup>18</sup>

## **Motivation and objectives:**

To realize, demonstrate and test heat supply for existing district heating networks on the basis of waste heat and electricity from renewable energies by means of a novel large-scale high-temperature heat pump.

**Total budget:** 3.330.085,00 EUR

**Running time:** 01.08.2020 – 31.07.2025

**Partners:** Vattenfall Wärme Berlin AG and Siemens Energy AG

#### **Key results:**

- a reduction in heat output to the environment of 37 GWh
- a reduction in water demand in cooling towers of 120,000m³
- a heat supply of about 55 GWh per year
- a reduction in CO<sup>2</sup> emissions of about 6500t per year
- provide warm water to 30.000 apartments in summer and 3.000 with heat in winter

**Output:** Making reliable statements on the technical and economic potentials of HTHPs. The project thus, can be a basis for medium- and long-term planning of heat supply infrastructure. In the project, the heat pump developed is to relieve the re-cooling circuit at the refrigeration plant and to raise the temperature level of water heat to levels up to 85 °C to 120 °C on the demand side. This will make the heat pump usable in Berlin's urban heating network. The heat pump output should be flexible and adapted to the output of the waste heat source. Output heat between 4.8 and 8 MWth is expected<sup>19</sup> .

#### **Project FernWP, Fernund**

### **Prozesswärmeversorgun g durch Wärmepumpen als Ersatz der Kohleverbrennung**

("District and Process heat supply by heat pumps as a replacement for coal combustion")

[https://www.ieg.fraunhofer.](https://www.ieg.fraunhofer.de/en/references/fernwp.html) [de/en/references/fernwp.ht](https://www.ieg.fraunhofer.de/en/references/fernwp.html) [ml](https://www.ieg.fraunhofer.de/en/references/fernwp.html)

#### **Motivation and objectives:**

This project focus on reducing the barriers to the timely integration of largescale heat pumps into district heating systems on both the technical and the economic side. The focus is on:

- 1. What are suitable low-temperature heat sources available at the sites of today's coal-fired power plants, what are their characteristics, how can they be integrated, and what are the resulting technical requirements for large heat pumps?
- 2. What are the requirements of district heating networks for large scale heat pump?
- 3. Which new designs have to be developed on the basis of these requirements, which characteristics do they have and what has to be considered with regard to the refrigerant?
- 4. Which refrigerants can be used, especially with regard to greenhouse and ozone depletion potential?
- 5. How can the currently still poor economic efficiency, especially in the operation of large-scale heat pumps (opex) in the transformation phase, but also in terms of specific investments (capex) be mitigated?
- 6. What needs to be considered in the system integration of largescale heat pumps from a techno-economic perspective?

<sup>18</sup> [https://www.enargus.de/pub/bscw.cgi/?op=enargus.eps2&q=Vattenfall%20GmbH&v=10&s=10&id 1445051](https://www.enargus.de/pub/bscw.cgi/?op=enargus.eps2&q=Vattenfall%20GmbH&v=10&s=10&id%201445051)

<sup>19</sup> <https://group.vattenfall.com/de/newsroom/pressemitteilungen/2022/richtfest-hochtemperatur-waermepumpe-am-potsdamer-platz>

- 7. What are the framework conditions that favor a market ramp-up of GWP and what are the current obstacles to a higher market penetration?
- 8. What is the potential of high-temperature heat pumps to provide process heat for industrial processes and what technical developments are required for the individual components?

**Total budget:** 4,472,042.33 €

**Running time:** 01.10.2021 – 30.09.2025

**Partners:** Fraunhofer IEG, Fraunhofer ISE, Johnson Controls System & Service GmbH, Stadtwerke Cottbus GmbH, Gesmex Exchangers GmbH,AGFW-Projektgesellschaft für Rationalisierung, Information und Standardisierung mbH

#### **Key results:**

- The basics of the theoretically possible cycle processes as well as the specification of the preselected refrigerants will be provided and elaborate
- The efficiencies of the thermodynamic cycles identified and the corresponding possible interconnections and components will be investigated
- At bench scale, first implementation of different COP optimizations will be realized at Fraunhofer ISE.
- The scale-up of the laboratory plant will be realized together with the industrial partners
- The development of a test plant and investigations on market integration from a system perspective will be carried out

**Output:** A research large-scale heat pump is built, operated and monitored. Different hardware components will be tested and the operation of a hybrid concept will be elaborated. Valuable measurement data will be obtained during the test cycles of this experimental plant, which will be fed back to the development team on the one hand, and on the other hand will contribute to a better understanding of the dynamic behavior in real operation and serve to verify the design parameters. Beside the large-scale heat pump, special attention will be attained to the development of an industrial high temperature heat pump for the provision of process heat, which will be developed in parallel on the basis of the large-scale heat pump. Component elaboration and development takes place and the technical further development of the required components will be advanced. Overall, the collaboration and contribution to the IEA Annex High Temperature Heat Pumps (HTHP) is planned.

**Entwicklung einer Hochtemperatur Wärmepumpe mit Wasserdampf-Schraubenverdichter zur Wärme- und Prozessdampfbereitstell ung** (Development of a high-temperature heat pump with water vapor screw compressor for heat and process steam

#### **Motivation and objectives:**

The aim of the SteamScrew joint project is the joint development of a hightemperature heat pump using water as a refrigerant to provide heat at a temperature level of 140 to 200°C. The level of the heat source is between 80 and 120°C and can be provided in the later field of application, for example, by waste heat or by deep geothermal energy.

**Total budget:** 2.600.000 €

**Running time:** 01.01.2023 – 30.06.2026

**Partners:** Fraunhofer IEG, Technische Universität Dortmund, Aerzener

supply)<sup>20</sup> Maschinenfabrik Gesellschaft

**Key results:** The focus is on upgrading the compressor and developing a suitable material, bearing and sealing concept and optimizing the injection parameters.

**Output:** The compressor will be investigated in initial experiments using air and steam and will be tested at Fraunhofer IEG in a closed heat pump circuit having a capacity of about 400 kW. Future aspect of the project is to scale up the heat pump to industrial levels. Experimental results obtained will be compared to simulation data to assess the suitability, efficiency and size of the heat pump for integration into industrial processes.

## **EnEff:Wärme: HeatSHIFT**

## **- Untersuchung effizienter**

**Einbindungsmöglichkeit en von** 

**Hochtemperaturwärmep umpen in** 

**Bestandsfernwärmenetz e mit** 

**Vorlauftemperaturen von typischerweise über 120 Grad Celsius**

(EnEff:Wärme: HeatSHIFT - Investigation of efficient integration options for high-temperature heat pumps in existing district heating networks with flow temperatures typically above 120 degrees Celsius)**<sup>21</sup>**

## **Motivation and objectives:**

District heating plays a key role in achieving the German government's 2045 climate targets and the associated far-reaching decarbonization of the heat supply. Against the backdrop of emission avoidance and the simultaneous increase in the security of supply of the heat supply, the HeatSHIFT research project will investigate efficient integration options for high-temperature heat pumps in district heating networks. The focus of the analyses is on existing district heating networks with high flow temperatures of 120 degrees Celsius and higher. The core objective of the project is the systematic investigation and technical as well as economic evaluation of the use of high-temperature heat pumps by means of process simulation, considering different heat sources and different high-temperature heat pump technologies.

**Total budget:** 418.499,51 €

**Running time:** 01.03.2023 – 28.02.2026

**Partners:** Kempten University

**Key results:** realistic process simulation models of high-temperature heat pumps as well as CHP plants (especially biomass and waste-to-energy plants) are created and combined on the basis of the data of the participating partners.

**Output:** Based on the validated process simulation models, an optimization of the integration of the high-temperature heat pumps as well as an evaluation of the economic efficiency will be performed. In addition, a simplified tool for the initial design of the high-temperature heat pump application for district heating suppliers will be created.

## **German Aerospace center (DLR)**

#### **Motivation and objectives:**

The DLR Institute of Low-Carbon Industrial Processes in Cottbus<sup>22</sup> (Brandenburg) is working on technologies and solutions for an energy system of the future that is sustainable and in which industrial operations can do without fossil fuels for their production. The CoBra experimental plant is making a significant contribution to the heat transition in industry. The name CoBra is a combination of "Cottbus" and the "Brayton process" of thermodynamics on which the plant is based. A large proportion of industries require process heat between 100 and 500 degrees Celsius. This is true, for example, of the food industry, the paper industry and the chemical industry. If renewably generated electricity is used, high-temperature heat pumps are climate-neutral. At the same time, industrial companies can save energy

<sup>20</sup> <https://www.ieg.fraunhofer.de/de/referenzprojekte/SteamScrew.html>

<sup>21</sup> <https://www.enargus.de/pub/bscw.cgi/?op=enargus.eps2&q=Fernw%c3%a4rme&v=10&s=10&id=23450180>

<sup>22</sup> [CoBra supports the thermal transition in industry \(dlr.de\)](https://www.dlr.de/en/latest/news/2022/03/cobra-supports-the-thermal-transition-in-industry)

with high-temperature heat pumps.

#### **Key results:**

The CoBra can achieve values that are unprecedented for the temperature lift and heat release temperature of 300 degrees Celsius with a heat output of around 200 kilowatts. In the future, the aim is to go much further and reach higher temperature ranges that are necessary for a low-CO <sup>2</sup> conversion of the corresponding industrial processes. CoBra has the potential to enable massive CO <sup>2</sup> reductions.

## **Output:**

The CoBra pilot plant was built within two years; financed with funds from the state of Brandenburg. DLR primarily selected companies from the region for the preparations and construction of the plant. In the long term, another larger CoBra pilot plant will be developed and built, which will allow even higher temperatures and a higher heat output. The CoBra pilot plant currently uses air as the working medium. However, it can also work with argon gas. The question of how to scale the prototype so that it is suitable for as many industries as possible is also the focus of the research.

![](_page_107_Picture_5.jpeg)

Pilot CoBra

## **German Aerospace center (DLR)**

## **Motivation and objectives:**

The Institute of Low-Carbon Industrial Processes in Zittau<sup>23</sup> (Saxony) is developing a high-temperature heat pump (HTWP) based on the Rankine process (working medium water/steam) and will set up the corresponding DLR test facility ZiRa for this purpose. For the development of this plant, the construction of the pilot plant ZiRa is necessary:

- to start experimental research well before completion of the DLR infrastructure in Zittau,
- to build up know-how for key topics such as plant construction, plant operation, measurement and control technology, safety.

#### **Key results:**

The planned pilot plant ZiRa serves as an experimental basis for future research work, therefore the scalability of the components for the planned experimental plant ZiRa will be considered during conceptual design and

<sup>23</sup> [Institute of Low-Carbon Industrial Processes -](https://www.dlr.de/di/en/desktopdefault.aspx/tabid-18914/) Pilot ZiRa (dlr.de)

procurement. In addition to the test possibilities at the pilot plant, experience will be gained on the technical limits, the risk in the design and construction of the DLR test plant ZiRa will be reduced, and unnecessary system variants will be avoided.

## **Output:**

With the pilot plant, the Institute of Low-Carbon Industrial Processes is pursuing the goals of advancing the heat transition in industry with innovative technology and demonstrating a possibility for decarbonizing energy-intensive industrial sectors. The pilot plant thereby extends the research to energy carrier media with phase change. The ZiRa pilot plant will achieve a TRL (Technology Readiness Level) of 3 - 4.

![](_page_108_Figure_3.jpeg)

## <span id="page-109-0"></span>**4.9. Japan**

### <span id="page-109-1"></span>**4.9.1. Overview of national HTHP industry**

Japan has a well-developed heat pump industry. There are many heat pump system manufacturers as well as components manufacturers such as refrigerants, lubricant oils, compressors, heat exchangers and expansion valves.

For industrial heat pumps (IHPs), as shown on [Figure 4-25,](#page-109-3) there are 24 manufactures in Japan [53]. Among them, 9 companies specialize in mechanical vapor recompressions (MVRs) and provide the MVR system, including the process engineering. The remaining 15 companies produce general-purpose heat pump equipment. At this moment, 4 companies – Fuji Electric, KOBELCO, Mayekawa, and Mitsubishi Heavy Industries (MHI) Thermal Systems – provide high-temperature heat pumps (HTHPs) with the supply temperature of 100 °C or higher. KOBELCO and Mayekawa also provide MVRs.

![](_page_109_Picture_4.jpeg)

*Figure 4-25: Manufacturers for industrial high-temperature heat pumps in Japan.*

<span id="page-109-3"></span>In Japan, HTHPs have been on the market since the latter half of the 2000s. Initially, electric utility companies became the driver, and together with manufacturers developed HTHPs for extending the application range of IHPs. Recently, HTHPs have been developed mainly with national R&D projects by New Energy and Industrial Technology Development Organization (NEDO).

#### <span id="page-109-2"></span>**4.9.2. Overview of national HTHP market and application potential**

[Figure 4-26](#page-110-0) shows the distribution of heat demand by temperature in the Japanese industrial sector [54]. The high temperature heat demand above 200 °C is limited to energy-intensive industries such as steel, metal, cement and petrochemicals, and most of the heat is used as combustion by burner. On the other hand, below 200 °C various industries exist, having various types of heat demand such as washing sterilization, drying, distillation and concentration. Another feature is that it is used mainly as a form of steam although combustion heating with burner is also used for drying processes. This heat demand area below 200 °C becomes 1250 PJ (= 347 TWh) and accounts for 28 % of the total industrial heat demand.

[Figure 4-27](#page-110-1) shows the graph picking up the heat demand of hot water and steam from [Figure 4-26.](#page-110-0) It can be seen that the applicable potential of heat pump expands as its supply temperature rises. However, when introducing heat pump, it is important to first clarify the heat demand of the process, not the heat demand of the utility, and to supply heat at a lower temperature as possible. In conventional factories, even when the heat demand temperature of the process is less than 100 °C, steam above 100 °C is often supplied uniformly by steam boiler centrally installed in the energy center. If the heat demand is less than 100 °C, it is possible to supply heat with a heat pump using utility waste heat or ambient air heat as the heat source even when process waste heat is not available.

![](_page_110_Figure_0.jpeg)

![](_page_110_Figure_1.jpeg)

<span id="page-110-0"></span>*Figure 4-26: Heat demand in the Japanese industry (a) by industry and (b) by heat use form.*

![](_page_110_Figure_3.jpeg)

<span id="page-110-1"></span>*Figure 4-27: Heat demand of hot water and steam.*

Also, when the steam boiler is located far from each process, it is confirmed that a large amount of heat is dissipated from the steam pipes. [Figure 4-28](#page-111-2) shows the energy flow from fuel to process heat demand. Even if the boiler equipment efficiency is about 90%, the end-use efficiency of steam is only 54% when the heat loss from steam pipes and condensate drain is taken into consideration. The values shown in this figure are the average of the measurement results in actual 29 factories [55].

![](_page_111_Figure_1.jpeg)

*Figure 4-28: Energy flow in conventional steam supply system*

<span id="page-111-2"></span>In summary, conventional steam supply system has the following problems: (1) to supply heat above the temperature required for the process and loses its exergy, and (2) to dissipate a large amount of heat from the long pipes. To solve these problems, clarifying the heat demand temperature and distributing heat pumps near each process can improve the energy efficiency.

It is also possible to shift the heat demand for steam above 100 °C to the heat demand for hot water below 100 °C by improving the process. For example, in an alcohol distillation column, the temperature required for distillation can be lowered by making the pressure inside the column negative (below atmospheric pressure). Then it becomes possible to apply a standard heat pump which supplies heat at below 100 °C [56].

High temperature heat pumps above 100 °C should be applied to the required processes after improving process and clarifying heat demand temperature. It is also important to clarify whether the required heat is latent heat (steam) or sensible heat (hot air, pressurized water or heat medium oil). This is because it greatly affects the performance of the heat pump and is related to the cycle configuration of the HTHP to be developed. If the required heat is sensible heat, that is, if the temperature glide is large, it is possible to achieve a relatively high COP even when the temperature lift is large.

#### <span id="page-111-0"></span>**4.9.3. Development perspectives for HTHP technologies**

In Japan, the product lineup of IHPs was expanded by the first half of the 2010s, and in 2011 the world's first heat pump capable of supplying steam at 165 °C was launched on the market. However, at that time, the refrigerants capable to HTHPs were limited to R-245fa and R-718 (water). Therefore, the only option was to use R-245fa up to about 120 °C and R-718 above it. The heat pump types and refrigerants of HTHPs that were developed by the early 2010s and are still available on the Japanese market are:

- Latent heat type: 120 °C steam supply heat pump (R-245fa)
- Latent heat type: 165 °C steam supply heat pump (cascade of R-245fa and R-718)
- Sensible heat type: 120 °C hot air supply heat pump (R-744 transcritical)
- Sensible heat type: 130 °C pressurized water supply (R-134a transcritical)

In recent years, with the reduction of GWP, some refrigerants applicable to HTHPs such as R-1224yd(Z), R-1233zd(E) and R-1336mzz(Z) have been developed. Moreover, if the needs for HTHPs increase in the global market, it is expected that additional new refrigerants will be developed.

As described in the next section, 3 manufacturers are developing 5 new HTHPs. In the near future, 150 °C steam supply heat pumps without cascading a steam compressor (R-718) for latent heat type and 200 °C supply heat pump for sensible heat type would be put into practical use.

#### <span id="page-111-1"></span>**4.9.4. Selected RD&D projects**

In the national R&D projects by NEDO, Fuji Electric, Mayekawa and MHI Thermal Systems are developing HTHPs capable of supplying heat of 150 °C or higher. Each project will be outlined below.

## **1.** Fuji Electric, 150 °C steam supply heat pump

[Table 4-3](#page-112-0) shows the development specifications [57]. The goal is to achieve the COP of 3.2 or higher at a heat source water temperature of 90 °C and a supply steam temperature of 150 °C. The heating capacity per unit is relatively small at 30 kW, and it can be installed near each process, so the external dimensions are the same as those of vending machines. It is possible to connect up to 10 units.

<span id="page-112-0"></span>Table 4-3: Development specifications

| Item                     | Specification                     |
|--------------------------|-----------------------------------|
| Supply steam temperature | 120 °C – 150 °C (Saturated steam) |
| Heat source temperature  | 60 °C – 90 °C                     |
| Heating capacity         | 30 kW                             |
| Steam flow rate          | 45 kg/h                           |
| Maximum integration unit | 10 units                          |
| COP                      | > 3.2                             |
| Size W×D×H               | < 1.5 m × 1.0 m × 1.8 m           |

[Figure 4-29](#page-112-1) shows the external view of the prototype and [Figure 4-30](#page-113-0) shows the system configuration [58]. The system consists of 3 parts: a waste heat recovery part, a heat pump cycle part, and a steam generator part.

For the heat pump cycle part, two-stage compression two-stage expansion cycle was selected so that the COP, control and economic performances are better compared to other cycles. R-1336mzz(Z), which has a low GWP and is nonflammable, was selected as the refrigerant. A scroll type compressor was adopted, and a mechanism has been developed that enables two-stage compression with a single scroll.

In the steam generator part, feed water is preheated in the subcooler and evaporated in the condenser. Then, saturated steam is taken out through the steam separator. By arranging the steam separator at a position relatively high with respect to the condenser, water circulation by natural convection using the thermosiphon phenomenon was realized. Therefore, a circulation pump is no longer necessary.

<span id="page-112-1"></span>![](_page_112_Picture_7.jpeg)

*Figure 4-29: External view of prototype*

![](_page_113_Figure_0.jpeg)

*Figure 4-30: System configuration of prototype*

<span id="page-113-0"></span>As a result of performance evaluation using the prototype, COP of 3.38 was achieved under the conditions of the heat source water temperature of 90 °C and the supply steam temperature of 150 °C. Field test is been conducting and prepared for market launch.

#### **2.** Mayekawa, 150 °C steam supply heat pump

[Table 4-4](#page-113-1) shows the development specifications [59]. The goal is to achieve the COP of 3.0 or higher at the evaporation temperature of 80 °C and the condensation temperature of 160 °C, assuming 150 °C steam supply.

<span id="page-113-1"></span>Item Specification Supply steam temperature 150 °C (Saturated steam) Condensation temperature 160 °C Evaporation temperature 80 °C COP > 3.0 GWP < 150

Table 4-4: Development specifications

[Figure 4-31](#page-114-0) shows the external view of the prototype and [Figure 4-32](#page-114-1) shows the system configuration [59]. R-601 (n-pentane) was selected as the refrigerant. A screw type compressor was adopted, and a high temperature technology was developed with a design temperature of 200 °C. Since the main purpose was to test the performance of the compressor, steam was not generated in the prototype, and heat medium oil was used for heat sink.

![](_page_114_Picture_0.jpeg)

*Figure 4-31: External view of prototype.*

<span id="page-114-0"></span>![](_page_114_Figure_2.jpeg)

*Figure 4-32: System configuration of prototype.*

<span id="page-114-1"></span>As a result of performance evaluation by the prototype, COP of 3.0 was achieved under the conditions of evaporation temperature of 80 °C and condensation temperature of 160 °C.

#### **3.** Mayekawa, 180 °C supply heat pump

[Table 4-5](#page-114-2) shows the development specifications [60]. The goal is to achieve the COP of 3.5 or higher at the heat source temperature of 80 °C and the supply temperature of 180 °C. The heating capacity is about 500 kW. It is a sensible heat type heat pump with a large heat sink temperature glide of 100 K.

<span id="page-114-2"></span>Table 4-5: Development specifications

| Item                    | Specification                              |
|-------------------------|--------------------------------------------|
| Supply temperature      | 80 °C in / 180 °C out (Sensible heat type) |
| Heat source temperature | 80 °C                                      |
| Heating capacity        | 500 kW                                     |
| COP                     | > 3.5                                      |

[Figure 4-33](#page-115-0) shows the external view of the prototype and [Figure 4-34](#page-115-1) shows the system configuration [61]. For the first prototype, R-600 (n-butane) was selected as the refrigerant. Three-stage turbo compressor was adopted. The heating capacity was about 300 kW. Next, for the second prototype, HFO refrigerant was selected, and the number of compressor stages was changed to 4.

![](_page_115_Figure_0.jpeg)

*Figure 4-33: External view of prototype.*

<span id="page-115-0"></span>![](_page_115_Figure_2.jpeg)

*Figure 4-34: System configuration of prototype.*

<span id="page-115-1"></span>Currently, performance and reliability tests are being conducted with the second prototype. Based on the test results, the elemental technologies such as compressors and heat exchangers are optimized, and then it is planned to be put on the market from around 2025.

#### **4.** MHI Thermal Systems, 160 °C supply heat pump

[Table 4-6](#page-115-2) shows the development specifications [62]. The goal is to achieve the COP of 4.0 or higher at the heat source temperature of 80 °C and the supply temperature of 160 °C. The heating capacity is about 600 kW. It is a sensible heat type heat pump with a large heat sink temperature glide of 90 K.

<span id="page-115-2"></span>

| Item                    | Specification                              |
|-------------------------|--------------------------------------------|
| Supply temperature      | 70 °C in / 160 °C out (Sensible heat type) |
| Heat source temperature | 80 °C in / 70 °C out                       |
| Heating capacity        | 600 kW                                     |
| COP                     | > 4.0                                      |

[Figure 4-35](#page-116-0) shows the system configuration [62]. Two-stage extraction cycle was selected for realizing

high COP under the large heat sink temperature glide [63]. Turbo type compressor was adopted, and R-1336mzz(Z) was selected as the refrigerant.

![](_page_116_Picture_1.jpeg)

*Figure 4-35: System configuration.*

<span id="page-116-0"></span>A drop-in test was performed using a modified machine for R-1336mzz(Z) from an existing product (90 °C supply two-stage compression and one-stage expansion economizer cycle with R-134a). As the result, it was confirmed that the heat pump was successfully operated at the hot water outlet temperature of 170 °C and the expected performance was obtained. [Figure 4-36](#page-116-1) shows the picture of the drop-in machine. Not only the COP, but also the compressor aerodynamic characteristics, the heat exchanger performance and the pipe pressure loss were almost as expected. Based on this result, the performance for the two-stage extraction cycle is predicted and the development is proceeding.

![](_page_116_Picture_4.jpeg)

*Figure 4-36: Implementation status of drop-in test*

#### <span id="page-116-1"></span>**5.** MHI Thermal Systems, 200 °C supply heat pump

[Table 4-7](#page-117-3) shows the development specifications [64]. The goal is to achieve the COP of 3.5 or higher at the heat source temperature of 95 °C and the supply temperature of 200 °C. The heating capacity is about 600 kW. It is a sensible heat type heat pump with a large heat sink temperature glide of 100 K.

Table 4-7: Development specifications.

<span id="page-117-3"></span>

| Item                    | Specification                               |
|-------------------------|---------------------------------------------|
| Supply temperature      | 100 °C in / 200 °C out (Sensible heat type) |
| Heat source temperature | 95 °C in / 90 °C out                        |
| Heating capacity        | 600 kW                                      |
| COP                     | > 3.5                                       |

The system configuration is the same as that shown in [Figure 4-35,](#page-116-0) and the two-stage extraction cycle was adopted. However, HFE356mmz, which has a higher critical temperature than R-1336mzz(Z), was used as the refrigerant. The critical temperature of HFE356mmz is 186.3 °C, and the safety grade is equivalent to A2L. Similar to the above-mentioned R-1336mzz(Z) test, a drop-in test using HFE356mmz was also conducted to verify the performance.

In parallel with the above-mentioned 160 °C supply heat pump, this 200 °C supply heat pump is under development.

#### <span id="page-117-0"></span>**4.10. Netherlands**

#### <span id="page-117-1"></span>**4.10.1. Overview of national HTHP industry**

The Netherlands has clear ambitions relating to the use of high temperature heat pumps for covering the industrial heat supply between 100°C and 200°C. Despite this, availability of market ready technology from Dutch suppliers is currently limited. To overcome the limited market availability of the technology, there have been a number of coordinated development and demonstration projects conducted in the last decade, supported by national funding schemes (see section 4.9.4).

Vapor compression heat pumps have been the core focus of development and demonstration projects related to high temperature heat pumps due to the high TRL of the technology for heat pump and refrigeration applications. In all these projects, the common denominator preventing the fast rollout of the technology is the availability of high-capacity compressor technology which is able to operate reliably under high temperatures required.

Indeed, within the aforementioned development and demonstration projects, there has been an absence of a Dutch technology supplier developing compressor technology specifically for the high temperature heat pump market. This is possibly attributed to the Netherlands historically not having strong developments in refrigeration/heat pump technology, although there are a few developments in this area (i.e. GEA piston technologies for up to 95°C supply). Instead, developments are led by Innovative system integrators (IBK, Bronswerk Heat Transfer, Heinen & Hopman, Standard Fasel) looking to gain a competitive advantage by providing solutions which fulfil the technology gap in the market or transition their activities towards sustainable heat supply systems. These developments are typically supported by national R&D institutes (ECN / TNO) who have dedicated testing facilities for characterising the performance of new technologies and in general aim to fulfil a societal role by facilitating the rollout of this low carbon technology. Despite the Netherlands clear ambitions for rollout of vapor compression heat pumps, the absence of compressor technology suppliers will necessitate growing international collaborations to facilitate the desired impact in the coming years.

#### <span id="page-117-2"></span>**4.10.2. Overview of national HTHP market and application potential**

Historically, the demand for heat in Dutch industry has been covered by cheap and readily available fossil sources, in particular, supplies of locally sourced natural gas. Primarily for this reason, early enduser interest and subsequent developments related to HTHP systems were based on (waste / process) thermally driven cycles (i.e. sorption / thermoacoustic concepts). A subsequent change in governmental policy in the last decade aimed at lowering reliance on natural gas, driven by closure of national gas extraction facilities, has led to strong interests in electrically driven heat pump concepts.

Over the last years, a number of changing market conditions have presented which make the uptake of electrically driven industrial heat pumps an interesting method for covering industrial process heating needs. These include:

- Increased availability of renewable electricity in power generation mix driven by large scale (offshore) wind and solar projects. This has increased from 9.6% 2010 to 26% in 2020 [65].
- Favourable price ratio of electricity relative to natural gas (per unit energy). Whilst the value

- differs per end-user and absolute energy prices are depending on specific consumption, in a European context it can be generalized that electricity prices are low, relative to natural gas prices. For small scale industrial end-users (2 GWh/a to 20 GWh/a electricity, 3 GWh/a to 28 GWh/a gas), this value is reported to be 2.24 by Eurostat [66].
- Increasing price (tax) on carbon emissions. Since 2021, industrial end-users have been subjected to a carbon tax of €30/tonne, which increase year on year [67]. This also applies to large companies which fall under the EU ETS scheme. CO<sup>2</sup> prices under the EU-ETS scheme have also increased to levels above €90/tonne in early 2022, further increasing pressure for companies to adopt low carbon heating technologies. Further to this, there is a clear trend of companies applying an internal cost of CO<sup>2</sup> emissions (≥€50/tonne) when evaluating new investment decisions.

The above-mentioned market conditions are supported by new subsidy programs which make it especially attractive for end-users to adopt electrically driven heat pump technology:

- The general aim of the Demonstration Energy and Climate Innovation (DEI+) subsidy [68] is to support pilot and demonstration projects that contribute to the cost-effective reduction of CO emissions in the Netherlands by 2030. Industrial heat pumps may be considered under the theme of Energy Efficiency with investment costs subsidised up to a maximum rate of 50%.
- The Stimulering Duurzame Energieproductie en Klimaattransitie (SDE++) scheme [69] is intended for companies to stimulate both the production of sustainable energy and CO<sup>2</sup> reduction in a multitude of sectors (industry, mobility, electricity, agriculture and the built environment). SDE++ subsidy is available for covering (part) operational costs of industrial heat pumps which have a COP > 2.3 (≤12.0 for open cycle heat pumps) and heating capacity ≥0.5 MW.

Other drivers for uptake of industrial heat pumps by Dutch end-users include the requirement to reduce emissions to maintain a license to operate, presenting a green image driven by consumer values, and lack of alternate technology or heating sources (limited electrical capacity, no access to biomass / biogas / hydrogen).

It is generally considered that heat pumps will be the key technology for covering the process heat demand <200°C in the Netherlands by 2050. A common method of determining the application potential for heat pump technology is to assess the current heat demand in industry up to this temperature level.

Based on national statistics from CBS for energy use in the Netherlands in 2020, final energy consumption of the industry is in the order of 644 PJ, of which 531 PJ is used for heating purposes. [70] presented data on the heat use in Dutch industry by temperature level up to 200°C for processes in the refinery, iron and steel, paper, food and chemical sectors, which has been collated by an assessment of the individual processes in these sectors and has been provided in [Figure 4-37.](#page-119-1) Heat demand <200°C in these sectors was estimated to be 194 PJ. Based on these numbers, it can be expected that heat pumps applied to these sectors can cover approximately 30% of the heat demand of the Dutch industry. It is clear that the highest potential sectors for heat pump application are in the paper, food and chemical sectors. The Netherlands has a well-established and relatively large chemical industry, and as such this sector has the highest potential for heat pump application (99 PJ).

![](_page_119_Figure_0.jpeg)

*Figure 4-37: Heat demand in NL by temperature level.*

#### <span id="page-119-1"></span><span id="page-119-0"></span>**4.10.3. Development perspectives for HTHP technologies**

Developments in the coming years on vapor compression heat pumps within the Netherlands will continue to be driven by innovative system integrators with increased collaboration on a European and international level with technology suppliers, particularly for compressors. The upcoming technology targets are highlighted in section 4.9.4. There are also efforts ongoing (but no firm commitments) to establish the full technology chain as a means of value and job creation for the Dutch industry.

In parallel to developments on vapor compression systems, there are efforts to bring thermoacoustic heat pumps for industrial applications to the market through targeted R&D projects. These developments are spearheaded by the national R&D institute (TNO) and are facilitated by piston compressor development by Howden Thomassen. Piston compressors, adapted from oil and gas industry applications are developed by Howden for these purposes. TRL level and demonstrated heating capacity of the technology remains low, however sink temperatures >200°C have been demonstrated, showcasing the technology potential. Developments which bring this heat pump technology closer to market implementation are expected in the coming years.

With the changing market conditions (see section 4.9.2) stimulating the uptake of industrial heat pumps, it is expected that there will be significant uptake from industry in the coming years. Topsector Energy (TSE) is a Netherlands organization which is the driving force behind innovations that are necessary for the transition to an affordable, reliable, and sustainable energy system. TSE focuses on different themes (Top consortia for Knowledge and Innovation - TKI) one of which is Energy and Industry (TKI-E&I). TKI-E&I has recently published a roadmap for electrification in the industry [71] which gives insights into the ambitions and expected rollout of heat pups in Dutch industry.

![](_page_120_Figure_0.jpeg)

*Figure 4-38: Electrification potential of Dutch industry.*

<span id="page-120-1"></span>This roadmap estimates that technical potential for electrification of the Dutch industry currently stands at 684 PJ [\(Figure 4-38\)](#page-120-1). Of this technical potential, the roadmap proposes the direct electrification of processes with heat pumps as a solution in the short term despite also indicating that technical developments are still needed for heat pumps to reach higher temperatures (200°C). Roll out of heat pumps are seen to be one of the primary electrification methods up to 2030, after which other direct and indirect electrification options are seen to become more prevalent. The introduction of heat pumps is for low-temperature (<200°C) heat, found in the sectors such as paper, food and those based on bio-based feedstocks. Until 2030, heat pumps are proposed to cover 119 PJ of this low-temperature heat (61% of the 194 PJ LT heat demand by industry) needed by these sectors, meaning 4.2 GW of installed capacity (based on 8000 operational hours per year) and leading to CO<sup>2</sup> emission reduction of more than 7 Mton/a.

#### <span id="page-120-0"></span>**4.10.4. Selected RD&D projects**

**1.** Compression, Acoustic, Thermochemical Hybrids Innovative Technologies for Paper Making Industry (CATCH-IT)

• Duration: 2012 – 2015

• Participants: ECN (now TNO, coordinator), Bronswerk Heat Transfer, IBK, Smurfit

Kappa

• Grant amount: €2.8M

• Financing: ISPT, Project Number: BC-10-09

The CATCH-IT project objective was to reduce the energy costs and enhance the sustainability of paper production with the aid of industrial heat pumps. At the same time this project aims to improve the competitiveness of Dutch technology suppliers through the development of novel heat pump technologies and systems.

In this project a 200 kW heat pump system consisting of a heat recovery system, a compression heat pump and the integration into the paper production process is developed, build and tested on a paper production site under actual operating conditions. Furthermore, development work on laboratory scale is done on Thermo Acoustic and Hybrid Thermo Chemical heat pump technologies.

## **Compression heat pump**

In this part of the project, A 160 kW pilot scale heat pump able to deliver low pressure steam from 60˚C waste heat was demonstrated at the Smurfit Kappa Roermond mill. The heat pump used butane as a working fluid and a piston compressor. Low pressure steam (0.5 barg – 2.4 barg) and hot process water was produced using boiler feed water and hot process water from fresh but already preheated water.

The source heat is recovered from moist exhaust air from the paper machine drying section. A schematic of the heat pump as well as an image of the containerised unit are provided in [Figure 4-39.](#page-121-0)

![](_page_121_Figure_1.jpeg)

*Figure 4-39: CATCH-IT Heat pump layout (left) and containerized unit (right) at site location.*

<span id="page-121-0"></span>For the heat pump, a COP of 3.7 for steam production was calculated, a COP of 3.8 was measured. The overall COP (steam + hot water) resulted in 5.4. The full results and details of the system are provided in the paper by Wemmers et al. [72].

#### **Thermoacoustic heat pump**

Within this part of the project, two options have been explored in studies and experimentally to apply a thermoacoustic system at a paper mill for upgrading waste heat from the drying section to process heat. These options concern an electrically and a gas driven system. The electrical system consists of an electrical drive to generate the acoustic power, that is subsequently used by a thermoacoustic heat pump. The gas driven system uses high-temperature heat from burning gas to drive a thermoacoustic engine that generates acoustic power and steam at lower temperature. This acoustic power is then used in the heat pump part of the system also producing steam

A system study has been done to determine the optimal system for hot flue gas heat supply system to the TA engine. Several combinations of burner type, TA gas engine types, and heat recuperation have been studied. The best efficiency is found for systems in which "waste" heat from the flue gasses leaving the TA engine is recuperated and used to preheat the combustion air. A maximum efficiency of 143% is found for 130°C steam production from 65°C waste heat. It was found that the TAE engine in which the largest part of sensible heat from the flue gas can be used as input to the engine has the highest system efficiency (useful process heat out/fuel in). The optimal configuration found is to supply heat from the outlet of the gas turbine to the TA heat pump. Very high efficiency up to 220 % is found in this case.

A full-scale conceptual design has been made of a piston compressor driven thermo-acoustic heat pump. The purpose of this task was to verify the technical feasibility and is used to estimate the costs of the full-scale system. A full scale (1MW) TA design shows a COP of 3.5 for pumping heat from 65°C to 130°C. Large TA systems seem to lower the relative losses. Study on industrial piston compressors shows that industrial piston compressors with maximum frequency up to 30 Hz and typical (acoustic) power output of 0.5 MW are available to drive the TAHP. Only slight modifications of the compressor are needed to achieve the coupling with the TAHP.

![](_page_122_Picture_0.jpeg)

*Figure 4-40: Thermoacoustic heat engine (left) and compressor driven thermoacoustic heat pump (right) tested in Catch-IT.*

#### **Thermochemical heat pump**

This part of the project studied the feasibility of the hybrid adsorption‐compression heat pump concept. It focused specifically on the technical feasibility of the sorbent material by means of measurements on the composite material and the economic feasibility based on a global design and cost estimate made by Bronswerk Heat Transfer.

A heat exchanger concept has been developed, based on a composite of Expanded Natural Graphite (ENG) in combination with a salt (such as CaCl2, MgCl2 of LiCl). Based on successful, repetitive charging and discharging of ammonia on various sorbents, the concept is considered technically feasible. A cost estimate has been made for a 1 MW system on the basis of this concept. The cost estimate led to an estimated 3 year payback time, leading to the conclusion it also seems economically feasible.

#### **2.** Sustainable Steam Production for Industry (STEPS)

• Duration: 2015 – 2019

• Participants: ECN (now TNO, coordinator), AkzoNobel, Bronswerk Heat Transfer,

DOW, DSM, Huntsman, Heineken, IBK, IF Technology, Lamb-Weston Meijer, SmurfitKappa, Warmtebedrijf Rotterdam, Cargill B.V., DOW Benelux B.V., IBK Groep B.V., Loders Croklaan B.V., Smurfit Kappa

Paper Services

• Grant amount: €880k

• Financing: RVO, Project Number: TEEI115010

The overall objective of the STEPS project is to produce steam in an economically feasible (payback period <5 years) way in the temperature range 120-200°C on the basis of a geothermal or residual heat source.

The specific objective of this project was to validate and determine the technical and economic feasibility of a two-stage compression heat pump. The aim with the compression heat pump was to achieve steam levels of 150°C, with uptake of waste heat at two distinct temperature levels.

In addition, a business case evaluation is performed for each of the end users, including a short quick scan of the possibilities of geothermal energy for the location in question.

#### **Compression heat pump**

For the STEPS project, the single-stage butane heat pump that was originally tested in the CATCH-IT project at SmurfitKappa Roermond has been converted to a two-stage compression system with two compressors and two evaporators. In addition, butane has been replaced by pentane. The heating capacity of the heat pump is ~150 kW.

Based on information obtained from end-users and the capabilities of the compression heat pump, a test program was carried out on the heat pump using a test rig, specially designed for this project by Bronswerk Heat Transfer:

- One evaporator (52°C 97°C), one compressor, steam production (120°C 150°C)
- One evaporator (52°C 97°C), two compressors, steam production (120°C 150°C)
- Two evaporators (52°C 97°C, 97°C 111°C), two compressors, steam production (120°C 150°C)

![](_page_123_Picture_3.jpeg)

![](_page_123_Picture_4.jpeg)

*Figure 4-41: Heat pump (left) coupled to specially designed test rig (right).*

The results from testing the heat pump under the aforementioned process conditions are reported by [73]. In general, the results of the experimental analysis demonstrate that it is indeed possible to build an industrial steam producing heat pump utilising equipment currently available in the market. Using this standard equipment, the heat pump demonstrated a maximum steam temperature of 150 °C with condensing temperatures exceeded 157 °C. Another notable result was a maximum external temperature lift of 90 °C, achieved using the dual stage cycle with heat input at an intermediate temperature level.

#### **Supporting activities**

For the month of November 2018, Smurfit Kappa has made the process data of the PM2 available as input for efficiency calculations of the heat pump. The process data contains the exhaust air conditions and the steam pressures of the pre- and post-drying batch. The steam pressures indicate the temperatures of the process heat to be supplied, the exhaust air the temperatures of the source heat.

The analysis showed that despite the large temperature lifts, reasonable COP values (2.5 – 3.0) are still obtained. The largest COP is obtained for the lowest grammage because the drying temperature is the lowest for this. The performance of the heat pump can be greatly improved if the source heat is available at a higher temperature. For this, the paper production process would have to be adapted to work with much less ventilation air.

In addition to the above, business case analysis was conducted for both the geothermal and waste heat source cases, estimating the required investments per company. Operating costs are determined based on the performance of the geothermal source, the (compression) heat pump, energy prices (electricity, steam) and CO<sup>2</sup> prices. The big unknown in this story is the integration costs. In this project, simple payback times have been calculated on the investment costs in the heat pump or the geothermal + heat pump combination.

The analysed business cases show that the payback times for the heat pump alone are between 1.9 and 5.1 years if freely available residual heat is used. The greater the temperature difference between residual heat and process heat, the lower the performance of the heat pump and therefore the longer the payback period becomes. If the source heat from the heat pump is not 'free', the payback period will be considerably higher. The payback period still needs to be corrected for the integration costs, which can be in the same order as the heat pump investment.

If geothermal energy is used as a source for the heat pump, the investments and also the income are higher. Payback periods are in almost all cases longer than in the residual heat case, with the exception of the situation where no 'free' residual heat is present.

## **3.** Low-CapEx

• Duration: 2017 – 2021

• Participants: TNO/ECN (coordinator), Cargill B.V., DOW Benelux B.V., IBK Groep

B.V., Loders Croklaan B.V., Smurfit Kappa Paper Services

• Grant amount: €752k

• Financing: RVO, Project Number: TEEI117006 • Further information: [https://www.tno.nl/en/focus-areas/energy](https://www.tno.nl/en/focus-areas/energy-transition/roadmaps/towards-co2-neutral-industry/sustainable-industrial-heat-system/low-capex-industrial-heat-pump/)[transition/roadmaps/towards-co2-neutral-industry/sustainable-industrial-heat-system/low](https://www.tno.nl/en/focus-areas/energy-transition/roadmaps/towards-co2-neutral-industry/sustainable-industrial-heat-system/low-capex-industrial-heat-pump/)[capex-industrial-heat-pump/](https://www.tno.nl/en/focus-areas/energy-transition/roadmaps/towards-co2-neutral-industry/sustainable-industrial-heat-system/low-capex-industrial-heat-pump/)

In the Low CapEx project, TNO works together with end-users and technology- and system suppliers to develop and test a reduced capex heat pump system that produces steam (up to 2 bara) from waste heat sources from 50˚C tot 80˚C. The goal of this project was to demonstrate that an industrial (steam producing) heat pump, having the capacity of 2 MW thermal output can be produced with a cost target of less than €200 per kW of heat output (<€400k).

The heat pump constructed as part of the LowCapEx project was manufactured by Ochsner and utilises two screw compressors operating in parallel from Hanbell. To minimize the costs of the unit to meet the cost target, a non-flammable synthetic HCFO working media, R-1233zd(E) was used. The heat pump features a shared evaporator unit with two separate condenser unit.

The heat pump was connected to TNO heat pump test rig for measuring and characterising the performance of the unit. As of early 2022, testing of the unit is ongoing, with the unit successfully producing steam. However, to date, no official numbers on the performance of the unit have been released.

Further within this project, demonstration cases of the heat pump are prepared in the food-, paper- and chemical industries. One such demonstration case is planned to be carried out in the paper sector in a follow up project.

![](_page_124_Picture_10.jpeg)

*Figure 4-42: LowCapEx heat pump being installed at TNO testing facilities.*

## **4.** FUSE

• Duration: 2019-2023

• Participants: TNO, Heinen & Hopman, IBK Groep, DOW, Royal Cosun,

LambWeston Meijer, Spurfit Kappa, Tata Steel, DSM, Hutamaki,

Bronswerk Heat Transfer, Emmtec, ISPT, Post & Dekker

• Grant amount: €934k

• Financing: RVO, Project Number: TEEI118008

Previous Dutch R&D projects (CATCH-IT, STEPS) demonstrated the operation of pilot scale compression heat pumps for industrial applications, however CAPEX costs in the order of €500/kW proved to be prohibitive for market introduction. Whist the Low CapEx project was conducted with the goal to demonstrate full scale heat pump technology could be produced with a cost target <€200/kW, this was to be achieved this using a non-flammable HFO working medium. The development and success of an industrial heat pump market is dependent on the ability to produce a standardized, modular, flexible compression heat pump technology on a scale level of 1-10 MW that uses a natural refrigerant and has low CAPEX. This requirement was the background for the FUSE project

The primary goal of the FUSE project is to develop a full-scale (1-2 MW), steam producing, industrial heat pump using natural working media that uses waste heat sources in the range of 60°C-90°C and produces medium pressure steam (range of 2-5 bara) with a specific investment cost of <€200/kW (excluding integration). Other activities in the project are dedicated to developing standardized and modular designs for industrial heat pumps.

Addressing the primary goal, Mayekawa Europe has is connected to the project and will supply the heat pump. Whilst for this demonstration unit the cost target was not achievable, the technical goals of the project can be reached. Mayekawa will supply a 1 MW (heating capacity) heat pump which operates on Pentane and can reach sink temperatures up to 150°C.

![](_page_125_Picture_10.jpeg)

*Figure 4-43: The heat pump constructed and tested in FUSE.*

The heat pump will be transported to TNO for testing and characterisation of the performance on a specially designed test rig. The heat pump will be tested under steady state and dynamic conditions representative of those which could be found in industrial processes. Commissioning of the unit will be done end Q2, 2022, with the testing programme completed in Q3 and Q4. Following the completion of the project, it is the intention that the heat pump will be transported to an industrial site for demonstration. Search and selection of an appropriate demonstration site is still ongoing.

## **5.** Kickstart

• Duration: 2022 – 2025

• Participants: IBK Groep B.V. (coordinator), TNO, TUDelft, University of Twente, TU

Eindhoven, de Kleijn Energy Consultants & Engineers, KWA,

Kiremko, Yeager Energy, SmurfitKappa, Corbion, FarmFrites, Shell,

Bunge Loders Croklaan

• Grant amount: €3.2M

• Financing: RVO, TSE-20-22-04 - MOOI Industrie, Project Number: MOOI42002

The KickStart Project (beginning 2022) is the largest coordinated R&D project conducted within the Netherlands with the intention to bring industrial heat pumps to the market as a reference heating technology for industry.

#### **Goals**

The objective of this project is accelerate the implementation of industrial heat pumps by:

- Developing technological solutions that are a commercially viable alternative to fossil fuel fired heating systems for industrial heat demand < 200°C, both for brown field and green field applications;
- Identifying the main non-technical barriers that hamper market implementation and how to reduce them.

The project aims to make the technology commercially viable. Commercially viable means:

- Technology is available that meets the technical requirements of the application at sufficiently low cost and sufficiently high performance to achieve pay back times less than 5 years.
- Technology suppliers have organized their supply chain and are able to produce this technology at desired price levels still maintaining a profitable business.

Reaching the aforementioned objectives will enable the implementation of heat pump technology on significant scale before 2030 and on the long term to covering a large share of the industrial heat demand < 200°C. This will provide a significant contribution to a CO2-neutral industry in 2050.

#### **Project Activities**

Full-scale heat pumps are developed for a specific application for two different end-users. To facilitate future integration of heat pumps, a so-called Digital Twin is developed. The heat pumps are tested in at TNO Petten under controlled simulated end-user conditions. For green field application of heat pump integrated processes, a detailed thermodynamic analysis of common unit operations in industry with a heat demand < 200°C will be made. This will be combined with an analysis of several heat pump concepts based on 'standard' compression heat pump and modifications thereof and alternative systems. This will result in the conceptual design of a new process/unit operation, including the heat pump. Finally, the non-technical barriers for market implementation of industrial heat pumps will be investigated and addressed through case studies with end-users, the supply chain and the innovation ecosystem.

## **Result**

The project will generate the following results:

- Two repeatable heat pump concepts developed and tested for brown field applications
- Five repeatable concepts developed for heat pump integrated processes
- Recommendations for accelerating market implementation of the heat pump technology

#### **6.** Steam Compression Heat Pump (SCHP)

• Duration: 2021 – 2023

• Participants: TNO (coordinator), Standard Fasel, Smurfit Kappa

• Grant amount: €497k

## **Objective**

The aim of this project is to investigate whether a Steam Compression Heat Pump (SCHP) is technically and economically feasible. The technical feasibility is being investigated by means of the development, construction and testing of a bench scale prototype (heating capacity ~250 kW) of the SCHP. From the bench scale it is possible in a follow-up project to develop in one go to a pilot on an industrial scale (~2 MW). The economic feasibility is determined by relating the technical performance to the economic benefits and the required investment.

## **SCHP concept**

The SHCP concept, as seen in [Figure 4-44,](#page-127-0) is based on the generation of steam in vacuum conditions (<1 bara, <100°C) and subsequent compression to produce low to medium pressure steam (1-5 bara). In this way the working fluid used is that which is directly used for driving the process, making this heat pump a semi-open cycle. The concept allows the uptake of significant amounts of available waste heat streams from industry in the range of 60°C-80°C. The use of water as (an environmentally friendly) working medium as well as for lubrication and sealing of the compressor rotors presents significant benefit over the competing closed cycle vapor compression heat pump concept.

![](_page_127_Picture_5.jpeg)

*Figure 4-44: Concept of half-open steam compression heat pump (left) and 3D representation (right).*

#### <span id="page-127-0"></span>**Project Activities**

In the SCHP project, a small and decisive consortium is working together to make rapid innovations for a promising technology. Using its knowledge of industrial steam systems, Standard Fasel will develop the vacuum boiler in-house and the steam compressors in collaboration with a compressor supplier. Subsequently, Standard Fasel will build the prototype of the SCHP. Using its knowledge of industrial heat pump systems, TNO will develop and build the interface between the TNO test rig and the semiopen heat pump and connect the prototype SCHP. The system is jointly started up and tested under simulated industrial conditions (testing in Q3/Q4 2022). Using the experiences during the development and construction of the prototype SCHP and the measurement results, the technological and economic feasibility and preconditions of a full-scale system are determined. Smurfit Kappa provides input regarding the process conditions relevant to them and assesses the feasibility of the SCHP in the paper industry.

#### **Result**

The project resulted in two SCHP designs, one fully developed for the construction of the bench scale prototype and one in outline for a cost estimate of a full-scale system. In addition, the performance of the bench scale prototype SCHP is determined by means of measurements under simulated, realistic, industrial conditions. Using the information gained during development, construction and measurement, a statement is made about the technical and economic feasibility of a full-scale system. If there is sufficient perspective, a roadmap for further development up to and including TRL9 is also a project result. This project will also expand knowledge of industrial, constant displacement steam compressors, working in ~0.2 bar<sup>a</sup> vacuum in relation to heat pump technology and the (dynamic) behaviour of semiopen, two-stage compression heat pump systems.

**7.** TASTE (Electrically driven Thermoacoustic high temperature steam producing heat pump)

• Duration: 2015-2018

• Participants: ECN/TNO, Howden Thomassen compressors (HTC), DOW Benelux,

Bronswerk Heat Transfer (BHT), Smurfit Kappa paper services ISPT

• Grant amount: €490k

• Financing: RVO, Project Number: TEEI314009

A bench scale thermoacoustic high temperature steam producing heat pump test set-up (TASTE) has been realized by BHT and tested at ECN/TNO. The heat pump has been designed by ECN/TNO by means of thermoacoustic simulation software. The TASTE heat pump has been tested in the ECN/TNO laboratory. Measurement results show that it is possible to produce steam without the intervention of a thermal circuit. The hot heat exchanger inside the TASTE heat pump functions as an evaporator of feed water. The feed water and partly evaporated water steam mixture is circulated between the heat pump and the oil cooled saturated water/steam vessel. The maximum measured steam temperature was 170°C. Higher temperatures are possible if the insulation of the steam vessel is improved.

The COP needs to be further improved. This can be achieved by lowering of internal heat losses in the helium working fluid. Future improvement of the heat exchanger will further increase the COP.

A conceptual design of a full-scale industrial TA heat pump has been made. This serves on the one hand to demonstrate the scalability of the technology and on the other hand to investigate the costs, the return on investment, and the economic potential. Project partner BHT has made a cost estimate and design information for the heat exchangers and the design of the pressure vessel. HTC has provided cost information and the selection and design of the reciprocating compressor.

The design study shows that it is technically possible to scale up the TAWP to a maximum of 30 MW for a modular and compact system without resonator. The conclusion of the study is that this compact design without resonator is from a practical and economic perspective the most promising. The compact heat pump is driven by an electrically driven piston compressor of 2, 4, 6 or 8 pistons.

![](_page_128_Picture_11.jpeg)

*Figure 4-45: TASTE Thermoacoustic high temperature steam producing heat pump with resonator tube and driven by small piston compressor.*

**8.** COMTA (COMpact modular Thermoacoustic heat pump)

• Duration: 2019-2022

• Participants: TNO, Howden Thomassen compressors, DOW Benelux, Bronswerk

Heat Transfer, ISPT

• Grant amount: €814k

• Financing: RVO, Project Number: TEEI118003

The compact thermoacoustic heat pump (COMTA) is a compact electrically driven TAHP without a resonator tube. From full scale industrial design studies (MW scale in TASTE project) it was found that the resonator would become too expensive due to its large dimensions. The solution was a redesign into a compact system without resonator and a direct coupling of a thermoacoustic unit to the cylinder of a reciprocating piston compressor. This COMTA concept has been translated into a test set-up which is build and tested at TNO in Petten. The set-up consists of a modified Howden piston compressor and a thermoacoustic unit. The heat pump is coupled to an oil-cooled feed water/steam vessel enabling testing with steam production by the heat pump at different steam temperatures.

![](_page_129_Picture_3.jpeg)

![](_page_129_Picture_4.jpeg)

*Figure 4-46: COMTA bench scale thermoacoustic heat pump (left) and artist impression of a two piston double acting industrial TAHP (right).*

The measurements proved the very wide operational temperature window of the COMTA heat pump and high temperature lift up to 100°C. Steam production between 110 and 180°C has been demonstrated with the COMTA set-up. Currently (2022), improved heat exchangers and measures to limit internal heat losses are implemented into the COMTA heat pump aiming to increase the COP.

The experimental results will be used to establish a full-scale modular design by cooperation between TNO, Bronswerk, and Howden. End users will contribute to the evaluation of the techno-economic feasibility and market potential of the thermoacoustic heat pump. The experimental results, full-scale design and cost calculations are used to establish the economic feasibility and market potential. Dissemination of the project results is organized by ISPT.

#### <span id="page-129-0"></span>**4.11. Norway**

#### <span id="page-129-1"></span>**4.11.1. Overview of national HTHP industry**

In Norway there is high experimental research activity on HTHPs with key projects HighEFF, HeatUp, SkaleUP, FreeToHeat and DryFiciency focusing on developing various high temperature heat pumps concepts, lab-scale systems, and full-scale pilots together with the industry. Low electricity to gas price ratios and extensive heating demands, due to cold climate, but also energy intensive industry, have created favourable conditions for implementation and development of heat pumps in general. Heat pumps for both residential and industrial use have therefore long been in existence in Norway. From an economic point of view heat pumps are very competitive compared to fossil or electricity fuelled boilers. In the recent years, more and more industry plants have installed pilot and full-scale HTHPs. Naturally due to higher temperature lift, COP is lower, which often requires utilization of waste heat streams. There are few component developers in Norway. However, there are relatively many system suppliers and developers for HTHPs. The technology on offer is quite varied ranging from hybrid absorption compression heat pumps, Stirling heat pumps, MVR heat pumps, traditional reciprocating compressor heat pumps and rotary vane compression heat pumps. A general trend is that most of the manufacturers are focusing on developing systems utilizing natural working fluids such as ammonia, water, CO2, hydrocarbons, and helium.

A summary of the key system developers and suppliers are listed in the sections below.

**Hybrid Energy AS:** A company that has sprung out from the Norway's Institute for Energy Technology (IFE). Hybrid Energy is a world leading manufacturer of Hybrid Absorption Compression Heat Pumps

(HACHP). The heat pumps use reciprocating compressor technology, and components are based on ammonia units with a design pressure of 25 bar. Their HTHP product range includes GreenPAC-R, HyPAC-R and HyPAC-s, which utilize heat sources in the temperature range of 40-60°C and deliver 80- 120°C, with capacities up to 5 MW. Detailed information is listed in the table below. Their heat pumps have been applied in dairies and food processing, bio-gas production, district heating and the process industry [74].

Table 4-8: Performance parameters for Hybrid Energy models [74].

| Model      | Nr. stages | Source temperature | supply temperature | Capacity     |
|------------|------------|--------------------|--------------------|--------------|
| GreenPAC-R | 1          | 50-65°C            | 90-100°C           | 500-2000 kW  |
| HyPAC-R    | 2          | 40-60°C            | 80-120°C           | 750-2000 kW  |
| HyPAC-S    | 1          | 40-60°C            | 80-120°C           | 2000-5000 kW |

**Skala Fabrikk AS:** The Skala group is leading supplier of technical services, processing equipment and consumables to the food industry. Skala Fabrikk builds and develops refrigeration and heat pump systems including tailor made heat exchangers. The are specialised on small medium size transcritical CO<sup>2</sup> heat pumps delivering up to 80 °C hot water. Development, test and verification of an industrial HTHP. SkaleUP Cascade HTHP is a unit for a) simultaneous ice and process hot water production or b) utilization and upgrade of low temperature waste heat, i.e. from dry-coolers. The heat pump is decided as a classical cascade cycle where hydrocarbons are applied to give an optimal performance, while having a high temperature lift of 70 K to 135 K. This high lift enables applications in new designed heating and cooling systems, as well as the retrofit in already existing pressurized process hot water supply systems.

HTHP is constructed modularly on frames enabling an installation in a 10 feet shipping container or in a machinery room. One module simultaneous provides up to 0.3 MWheating at 115 °C and 0.15MWcooling at 0 °C, process cooling may be realized down to -20 °C with reduced capacity. Performance examples are given below.

Table 4-9: Performance parameters for "SkaleUP" HTHP from Skala Fabrikk.

| Tsource,in | Tsource,out | Tsink,in | Tsink,out | Tlift | COP     | COP      |
|------------|-------------|----------|-----------|-------|---------|----------|
| [°C]       | [°C]        | [°C]     | [°C]      | [K]   | heating | combined |
| -15        | -20         | 95       | 115       | 135   | 1.9-2.0 | 2.7-2.9  |
| 4          | 0.5         | 95       | 115       | 115   | 2.2-2.4 | 3.3-3.5  |
| 12         | 6           | 95       | 115       | 109   | 2.4-2.6 | 3.6-3.8  |
| 25         | 15          | 95       | 115       | 100   | 2.7-2.9 | 4.1-4.3  |

**Enerin AS:** Enerin is an energy engineering company which develops and supplies ultra-hightemperature heat pumps, a development that dates back to the year 2000. Enerin is currently developing its HTHP named "HoegTemp", which operates based on the reversed Stirling cycle, which operates in gas-phase only. A stand-alone unit has a capacity between 300-1000 KW of thermal output. Multiple stand-alone units can be combined up to 10MW of thermal output. The technology is developed based on more than 30 000 hours of industrial operating experience with prototypes. Suitable working fluids are helium and nitrogen, with maximum supply temperatures of 250°C, while minimum source temperatures can be down to minus 100°C [75]. Examples of performance at various operating temperatures are given in the table below:

Table 4-10: Performance parameters for "HoegTemp" heat pump from Enerin.

| Tsource,in<br>[°C] | Tsource,out<br>[°C] | Tsink,in<br>[°C] | Tsink,out<br>[°C] | COPheating<br>[-] |
|--------------------|---------------------|------------------|-------------------|-------------------|
| 85                 | 65                  | 206              | 212               | 2.0-2.15          |
| 16                 | 12                  | 206              | 212               | 1.6-1.7           |
| 135                | 113                 | 154              | 160               | 3.3-3.7           |
| 80                 | 50                  | 154              | 160               | 2.2-2.45          |
| 16                 | 12                  | 154              | 160               | 1.75-1.9          |

**Olvondo Technology AS:** Olvondo is a technology company that develops and manufactures industrial

HTHPs. Although the company was founded in 2016, the heat pump technology dates back to early concepts and R&D from the mid-2000s. Their heat pump is called "HighLift" and is based on the reversed Stirling Cycle, using helium as working fluid. The operating principle is given in [Figure 4-47.](#page-131-0) Rated capacity is up to 750 kW of thermal output, while the operating temperature range is from 0-100°C on the source side, and 100-200°C on the sink side, [76].

![](_page_131_Picture_1.jpeg)

*Figure 4-47: Principle sketch of Olvondo's High-lift heat pump configuration* [76]*.*

<span id="page-131-0"></span>Two reference plants for Olvondo are, [77]:

- 1. Astra Zenica plant in Sweden, where steam is supplied using 4x HighLift heat pumps at 175- 184°C, 8-10 barg utilizing waste heat of 25-35°C.
- 2. Tine dairy in Ålesund, where steam is supplied using 3x HighLift heat pumps at 175-184°C, 8- 10 barg utilizing district heating as heat source (90-100°C)

The commercial operational experience with the HighLift technology is over 50,000 operational hours from commercial services.

**ToCircle Industries AS**: ToCircle Industries is a technology developer founded in 2003. Its product is based on a patented controlled rotary vane principle. The rotary vane compressor is a multiphase displacement machine driven by an electrical motor, which provides a circular movement for all mechanical parts and process fluids. Unlike reciprocal action compressors the motion is therefore not prone to inducing vibration or generating noise, thus eliminating the need for space consuming vibration dampening devices [78].

The rotary vane compressor (TC-C920), illustrated in [Figure 4-48,](#page-132-0) can be used both in open loop heat pump (Mechanical Vapor Recompression) or closed loop heat pump operating with pure steam or other refrigerants. The compression chambers are formed between the static outer casing and the vanes connected to the rotor. Unlike in conventional rotary vane compressors, the extension of vane tips in Tocircle's compressor is controlled with bearing technology mounted in the machine centre, eliminating friction between the casing and vane tips, and the need for oil lubrication. Internal lubrication is achieved through liquid injection into the internal bearings in the compressor, resulting in two-phase evaporative compression of the refrigerant.

![](_page_132_Picture_0.jpeg)

*Figure 4-48: Cross-sectional view of the TC-C920 rotary vane compressor.*

<span id="page-132-0"></span>The capacity range of ToCircle's heat pumps is 1-5 MW with a maximum condensation temperature of 188°C, and a maximum temperature lift of approx. 90 K. Heat pump COP is 4 to 5, example: COP of 5.41 with a sink temperature of 141°C and a source temperature of 112°C.

**Epcon evaporation systems AS:** Epcon is a system developer and supplier and has long and leading experience with MVR based heat pumps. Located in Trondheim, Norway, Epcon has since 1986 evolved as a technology company with a multidiscipline expertise in heat pump process engineering, construction and mechanical engineering, chemistry and material technology [79].

Their experience extends to more than 100 energy efficient MVR plants. The MVR systems are characterized by open or partly open circuits primarily using water as working fluids. Their heat pumps can utilize heat source temperatures down to 50°C, while heat supply temperatures are in the range from 60-150°C. Their systems can be scaled up to over 100 MW if necessary. At low temperature lifts, very high COP values are obtained. The compressor machinery is well proven centrifugal fans, as illustrated in [Figure 4-49,](#page-132-1) or roots blowers. Typical applications are evaporation, distillation processes and drying [79].

![](_page_132_Picture_5.jpeg)

*Figure 4-49: Epcon standard MVR-fan* [79]*.*

<span id="page-132-1"></span>**Heaten AS:** Heaten is a technology developer and supplier of MW-scale HTHPs. Their R&D experience dates back to 2010 on heat to power ORC systems and power to heat HTHPs. Heaten's patented HTHP is called the HeatBooster and is a one-stage, closed-loop vapor compression heat pump ideal for single or cascade configurations, illustrated in [Figure 4-50.](#page-133-1) It uses reciprocating compressors and 4th generation HFOs [80], [81]. The well proven technology is designed for low maintenance and long service life. The HeatBooster can utilize heat sources between 2-150°C, and deliver temperatures in the range of 70-165°C. Heaten plans to further extend the temperature range to well over 200°C. The nominal scale for heat delivery is 1 MW. COP values lies in the range of 3 to 5 depending on temperature lift. An example is 4.8 with a heat source of 120°C and a heat sink of 165°C.

![](_page_133_Picture_1.jpeg)

*Figure 4-50: Heaten HeatBooster.*

#### <span id="page-133-1"></span><span id="page-133-0"></span>**4.11.2. Overview of national HTHP market and application potential**

The overall energy consumption in Norway was 216 TWh in 2018. [Figure 4-51](#page-133-2) shows the overview of all heating and cooling demands in Norway for 2018, classified according to the primary energy source for the main user groups; households, industry and service industry. The combined energy consumption for heating and cooling was 72.5 TWh [82].

Norway has a high access to renewable energy sources primarily in the form of hydro power, which accounts for 90% of Norway's normal annual electricity production of 153 TWh [83]. The annual power consumption corresponds to 135-140 TWh (excluding the offshore oil and gas sector) [84], leading to a surplus of electric energy. The primary energy source for heating and cooling in households and service industry is dominated by electricity. For the industry sector there a larger mix of energy sources, with natural gas, oil and oil products contributing to roughly 30% of the heating and cooling supply. Still, a relatively large share (40%) is based on [82].

![](_page_133_Figure_6.jpeg)

*Figure 4-51: Overview of all heating and cooling demands (TWh) in Norway (2018)* [82]*.*

<span id="page-133-2"></span>[Figure 4-52](#page-134-0) shows the heat production from heat pumps in Norway (2018). The overall annual heat production from heat pumps is estimated to 16.1 TWh, which corresponds to more than 10% of Norway's

electricity consumption. Heat pumps for the domestic sector (households) is dominating with 9.4 TWh annual heat production, which makes up more than 30% of all electricity-based heating for household. Heat pumps are not so widely implemented in the industry sector. Still, heat production from heat pumps corresponds to 1.3 TWh or 17% of electricity-based heating and cooling generation in the industry and 7% of all heat and cooling generation when all energy sources are included [82].

The numbers above and Norway's extensive use and potential for electricity based heating, indicates that there is a large potential for further implementation of heat pumps especially for households and service industry, where commercial small unit heat pumps are available at a low cost. There is also a potential in the industry sector, especially to cover low temperature demands as this can be utilized based on ambient heat from the air or sea water, and fully commercialized heat pump solutions.

Heat supply to industrial process heat with HTHP is more challenging, both from a technological perspective, but also the availability of waste heat and the complexity of integrating HTHPs into the industrial processes. In recent years the technological development has enabled piloting of HTHPs in the industry, especially within the food industry, where simultaneous demands for cooling and heating occur.

![](_page_134_Figure_3.jpeg)

*Figure 4-52: Heat production from heat pumps (GWh) in Norway (2018). Reproduced from* [82]*.*

<span id="page-134-0"></span>The overall techno-economic potential for heat pumps (in all temperature ranges) in Norway has been estimated to be around 8 TWh. This potential can lead to primary energy savings up to 5 TWh [82].

The largest energy intensive industries in Norway are shown in the map in [Figure 4-53.](#page-135-0) It shows that the energy-intensive industries are geographically distributed all across Norway.

![](_page_135_Figure_0.jpeg)

*Figure 4-53: Map of the largest energy intensive industry sites in Norway,* [85]*.*

<span id="page-135-0"></span>[Figure 4-54](#page-135-1) Shows a break-down of the overall industry heat demand in GWh distributed on the temperature range and industry sector in Norway. The temperature ranges most applicable for nearfuture implementation of HTHPs in this overview are the 100 to 150°C range and 150 to 200°C. At these temperatures the food, beverages and tobacco, paper and paper products, chemical and iron, steel and non-ferrous industries are the dominating sectors [86].

![](_page_135_Figure_3.jpeg)

<span id="page-135-1"></span>*Figure 4-54: Breakdown of Norwegian heat demand distributed on temperature-range and industry sector* [86]*.*

In the food processing industry, there are several examples of HTHP pilot installations in the recent years, especially within the dairy industry where HTHPs are installed in Bergen, Trondheim and Ålesund, operating with delivery temperatures around 100°C and beyond.

One of several successful examples is the dairy in Bergen, which is operated by TINE SA. The old dairy was replaced with a new dairy, which was commissioned in 2018 utilizing a solution with integrated cooling and heating with heat pumps and thermal storage at each main temperature level, see [Figure](#page-136-1)  [4-55.](#page-136-1)

![](_page_136_Figure_0.jpeg)

<span id="page-136-1"></span>*Figure 4-55: Process integration with heat pumps and thermal storage tanks in TINE's new dairy in Norway* [87]*.*

The new dairy was the first in the world without the use of fossil or direct electric heating, and for this it won the *Heat pump City of the year* award in 2019. The dairy has reduced its energy consumption by 40%, its overall annual energy consumption from 10.1 GWh to 6.5 GWh and the product specific consumption from 0.24 kWh to 0.15 kWh per litre produced. CO<sup>2</sup> emissions savings using heat pumps compared to using a fossil fuel fired heating solution were over 90% [87].

The main contribution to the energy reduction is based on integrating the dairy's heating and cooling processes through use of heat pumps. The old dairy handled cooling and heating demands separately, using chillers for process and storage cooling, while fossil fuelled or electric boilers supplied the necessary heat for energy demanding processes such as pasteurizing and cleaning (CIP). In TINE's new dairy, the waste heat from the cooling processes, which normally is dispatched to the ambient through dry cooling, was instead recovered using heat pumps. The heat is upgraded to an intermediate temperature level (67°C), using two ammonia heat pumps (1577 kW total capacity). Further, heat upgrade to 95°C is achieved through an ammonia-water hybrid absorption compression heat pump (HACHP) cycle (940 kW capacity) delivered by the Norwegian supplier Hybrid Energy. This resulted in a total system COP of 4.1. The thermal storage tanks, which are installed at all consumer temperature levels is essential to the integration since many of the processes are performed in batches, which means high peak energy demands, and non-simultaneous cooling and heating [87].

#### <span id="page-136-0"></span>**4.11.3. Development perspectives for HTHP technologies**

As seen in the overview of the Norwegian heat pump market there are many manufacturers and there is a large span in cycles and compressor technology, as well as working fluids that are used. To achieve supply temperatures going beyond 150°C, many developers rely on oil free operation of the compressor. Some manufacturers use rotational compressors to achieve this, however, as seen the use of reciprocating compressors are also applied. Several suppliers are now working with pilot projects and targeting MW-scale operation of their heat pump systems.

In terms of working fluids, the trend seems to be towards the use of natural working fluids. This is seen amongst the Norwegian suppliers, where most of them are offering systems using natural working fluids. It is also seen for new installations and pilot plants, e.g., TINE Bergen (Ammonia and Ammonia-water), that natural working fluids are being used. Industrial heat pumps applied in district heating also follows the same trend with several ammonia-based systems installed in the recent years.

A study performed within the HighEFF research centre investigated the feasibility for HTHPs for supplying heat up to 200°C. It was pointed out that market available heat pump could deliver heat up to 160°C and that working fluids with higher critical temperatures should be selected in order to reach higher temperatures. Water (R-718) was identified as a suitable candidate for this purpose. Furthermore, the compressor technology was identified as a key cost driver. Compact turbo compressors were identified as a compressor technology that can significantly reduce investment costs, especially for small-scale systems, (< 1 MW) requiring temperature lifts larger than 30-40 Kelvin [88].

As pointed out in [4.11.2](#page-133-0) there are several industrial sectors in Norway where there is a large heat demand at temperature ranges of 100-200°C which are suitable for short term implementation of HTHPs. So far, the food processing sector has led the way in terms of implementing HTHP pilotsystems into their process plants. However, other industries are also gaining interest in HTHP based heating to facilitate the reduction of energy consumption and CO<sup>2</sup> emissions. This includes wood and paper processing, textile industry and metal industry. And although not necessarily for heat supply above 100°C; there is also a growing interest for data centres to implement heat pumps for waste heat recovery and upgrade to cover industrial or residential heating demands.

## <span id="page-137-0"></span>**4.11.4. Selected RD&D projects**

**1.** DryFiciency

• Duration: 2016 – 2021

• Participants: AIT (Coordinator), Agrana, Wienerberger, RTDS, EHPA, Rotrex,

Bitzer, Chemours, Fuchs, Mars, SINTEF, Viking heat engines,

Scanship, Heaten

• Total budget: 7 mill € (overall budget)

• Financing: H2020 – Innovation Action, ID nr: 723576

• Further information: https://dryficiency.eu/

DryFiciency is a four-year Innovation Action project funded by Horizon 2020 Research & Innovation Framework. In the Dryficiency project one of the demonstrated technologies was an open-loop MVR dryer using a steam heat pump based on turbo-compressor technology. The system was installed and demonstrated at a test site in Norway. The background for using the turbo-compressor technology, was the possibility to reduce the specific investment costs, as MVR-systems using traditional compression technology is normally only applied when the thermal capacity is higher than 10 MW. By using turbocompressors originating from the automotive industry a more-cost competitive alternative can be considered [89]. The system is further described in the demo cases chapter.

![](_page_137_Picture_12.jpeg)

*Figure 4-56: Principal sketch of the 2-stage turbo-compression MVR heat pump test-rig* [89]*.*

## **2.** HeatUP

• Duration: 2015 – 2019

• Participants: SINTEF (Project owner), NTNU, Equinor, Statkraft, Hydro, Vedde,

Tine, MARS, Cadio, HybridEnergy, Epcon

• Total budget: 1 mill € (grant budget)

• Financing: Funded by Norwegian research council – ENERGIX ref: 243679

• Further information: <https://www.sintef.no/projectweb/heatup/>

In HeatUP SINTEF, together with industry partners, are aiming is to extend the temperature range for heat pumps beyond 200°C by using natural working fluids like butane, ammonia (NH3) and water. HeatUP investigated the possibility to use MVR for steam based drying processes and developed a turbo-compressor for steam compression, [90].

Another developed HTHP system In HeatUP was a cascaded HTHP propane-butane cycle, using reciprocating compressors, see the schematics of the test-rig in [Figure 4-57.](#page-138-0) A 20 kW test-rig was built in cooperation with Cadio and compressor manufacturer Dorin and installed and tested at SINTEFs lab.

Through testing it was demonstrated to be capable of delivering thermal energy at 110°C-120°C. It recovers low-temperature waste heat at from industrial processes at 30°C and can deliver ice water for refrigeration processes. The high-temperature heat delivery is suitable for drying, sterilization and pasteurization. Regarding performance, a heating COP of 2.6 was achieved, while a combined COP for cooling and heating of 4.1 was achieved [91]. The system is further described in demo cases chapter.

![](_page_138_Figure_7.jpeg)

*Figure 4-57: HeatUP test rig schematics* [91]*.*

## <span id="page-138-0"></span>**3.** SkaleUP

• Duration: 2019 – 2022

• Participants: SKALA Fabrikk (Project owner), SINTEF (Coordinator), TINE, Cadio,

Officine Mario Dorin

• Total budget: 250 000 € (grant budget)

• Financing: Funded by Norwegian research council – ENERGIX ref: 296374

• Further information: [Prosjektbanken Forskningsrådet -](https://prosjektbanken.forskningsradet.no/en/project/FORISS/296374?Kilde=FORISS&distribution=Ar&chart=bar&calcType=funding&Sprak=no&sortBy=date&sortOrder=desc&resultCount=30&offset=0&Organisasjon.3=SKALA+FABRIKK+AS) HeatUP

SkaleUP builds on its previous project HeatUp and aims to develop and pilot a novel, but proven heat pump for industries where heating traditional is supplied using fossil energy sources. SkaleUP will evaluate and prove the potential of the high temperature heat pump with an industrial pilot implemented in an industrial process. The SkaleUp heat pump supplies process heat at 115°C and simultaneous cooling at 0°C.

## **4.** Free2Heat

• Duration: 2018 – 2023

• Participants: ToCircle Industries (Project owner), SINTEF

• Total budget: 800 000 € (grant budget)

• Financing: Funded by Norwegian research council – ENERGIX ref: 282123

• Further information: <https://www.sintef.no/en/projects/2019/free2heat/>

Free2Heat is an innovation project for the industry, funded by the Norwegian Research Council and aims to develop and validate concept for HTHPs. The technology that is investigated is based on Kjell Vadings patented expander principle. The HTHP heat pump is being developed with a rotary vane compressor at its core. The compressor illustrated in [Figure 4-48,](#page-132-0) ToCircle industries is the project partner [92]. The technology is further described in the supplier technology chapter.

**5.** Centre for an Energy Efficient and Competitive Industry for the Future (HighEFF)

• Duration: 2016 – 2024

• Participants: SINTEF (Project owner) + a large number of research institutes,

universities, user industry, and vendor and technology providers

• Total budget: 180 million € (total grant budget)

• Financing: Funded by Norwegian research council – FMETEKN-FME ref: 257632

• Further information: <https://www.sintef.no/projectweb/higheff/>

The HighEFF research centre focuses on technologies and processes with potential for large reduction in specific energy use. The research areas in HighEFF spans wide ranging from the investigation methodologies, components, cycles, applications and case studies. HighEFF also provides support for important lab-infrastructures, such as the HighEFF-lab. HTHP concepts have been developed in case studies for several industry sector including metal, oil and gas, food, chemical and industry clusters. One example is TINES's new dairy production site in Bergen described in [4.11.2](#page-133-0) [93].

Published work performed within HighEFF research centre on HTHP include:

- [Heat pump concepts for steam production at Glencore Nikkelverk](https://www.sintef.no/globalassets/project/higheff/deliverables-2019/d6.2_2019.03-heat-pump-concepts-for-steam-production-at-glencore-nikkelverk.pdf)
- [Test rig design for CO2 heat pump system lifting from ultra-low to high temperatures](https://www.sintef.no/globalassets/project/higheff/deliverables-ra3/d3.2_2017.08-test-rig-design-for-co2-heat-pump-system-lifting-from-ultra-low-to-high-temperatures.pdf)
- [Feasibility study on high temperature heat pump with heat sink at 200°C. Identification of](https://www.sintef.no/globalassets/project/higheff/deliverables-ra3/d3.2_2017.01-feasibility-study-on-high-temperature-heat-pump-to-200-degc.pdf)  [working fluid, technology readiness levels and system availability](https://www.sintef.no/globalassets/project/higheff/deliverables-ra3/d3.2_2017.01-feasibility-study-on-high-temperature-heat-pump-to-200-degc.pdf)
- [HTHP with Ejector](https://www.sintef.no/globalassets/project/higheff/deliverables-2019/d2.2_2019.04_hthp-with-ejector_final.pdf)
- [Novel Dairy Energy Systems with HTHP](https://www.sintef.no/globalassets/project/higheff/case2engtine09_14.pdf)

## <span id="page-139-0"></span>**4.12. South Korea**

#### <span id="page-139-1"></span>**4.12.1. Overview of national HTHP industry**

In Korea, many HVAC manufacturers produces various types of heat pump systems for cooling, heating, hot waters and so on. As for the heat pump market, the commercial and residential sectors are the major field, so small and medium capacity systems which are suitable for mass production dominate the market. The industrial sector which is known to have high potential demand for HTHP, requires customized heat pump design and manufacturing. In Korea, such an order-made heat pump production sector is not established due to low demand.

Heat pump manufacturers generally provide both air-source and geothermal types for building cooling, heating and hot water production. The air-source type is designed to produce up to 60 °C hot water in a single outdoor unit configuration under cold climate condition. In addition, some manufacturers provide 80 °C hot water production type with cascade configuration that adds booster cycle to efficiently produce high temperature heat. The figure below is LG Electronics 80 °C hydro kit (brand name, ThermaV) configuration. Since outdoor air temperature drops below -10 °C in the winter, other manufacturers also adopt similar cascade configuration for 80 °C hot water air-source HTHP. These days, not only existing heat pump manufacturers but also traditional residential boiler manufacturers are providing heat pump cooling/heating/hot water solutions as a new business strategy since transition to carbon neutral society requires less use of fossil fuel boilers.

![](_page_140_Figure_2.jpeg)

![](_page_140_Figure_3.jpeg)

![](_page_140_Figure_6.jpeg)

*Figure 4-58 LG Electronics Therma V high temperature system: up to 80 °C.*

These heat pumps can be applied to industrial processes requiring hot water. Manufacturers suggest various applications such as heating, cleaning, sterilization, etc., but in Korea, there is literally no application cases of heat pump to actual industrial processes.

There are a few manufacturers that provide high-temperature heat pump solutions for mid- to largecapacity heat pump systems, typically using screw compressors or turbo compressors, and having unit system capacity over 100 RT. Century, one of Korea's HVAC manufacturers, exhibited screw heat pumps that can supply 45 to 100 °C hot water or process steam over 100 °C at the 2017 HARFKO (Heating, Air Conditioning, Refrigeration and Fluid Exhibition – Korea). (R-717 for hot water and R-245fa for steam generation type). Bumyang showed a 120 °C steam generation heat pump system using R-245fa at 2019 HARFKO. The system also used screw compressor and featured 3.30 COP at a 300 kW output. In addition, through a national R&D projects, industrial heat pump system that can produce 120 °C steam using turbo compressors has been developed, and commercialization is currently underway. LG Electronics has a 2,500 RT turbo heat pump lineup that can supply 80 °C of hot water using a sewage heat source. One of the turbo systems were installed in a district heating plant in Magok district, Seoul. Although HTHP technologies up to 120 °C were developed by some manufacturers, but there are very few cases of their actual applications to industrial processes.

![](_page_141_Picture_0.jpeg)

*Figure 4-59 LG Electronics' 80 °C Turbo heat pump system (source : [https://www.lge.co.kr/kr/business/product/cooling/chiller-heater-pump\)](https://www.lge.co.kr/kr/business/product/cooling/chiller-heater-pump)*

![](_page_141_Picture_2.jpeg)

*Figure 4-60 Bumyang's steam generation heat pump at 2019 HARFKO (Source: [https://www.hvacrj.co.kr/news/articleView.html?idxno=10287\)](https://www.hvacrj.co.kr/news/articleView.html?idxno=10287).*

#### <span id="page-141-0"></span>**4.12.2. Overview of national HTHP market and application potential**

In Korea's HVAC sector, the demand for cooling is much higher than that of heating and hot water. Due to this trend, most manufacturers focus their heat pump business on small and medium-sized air source or geothermal systems using scroll compressors that are suitable for mass production and are easily modified from cooling systems.

Korea's refrigeration and HVAC market size is estimated about KRW 10 trillion, but there is literally not any specific market information on heat pump system. A report said that the market size of Korea's geothermal heat pump system was about KRW 320-350 billion, of which the heat pump's portion is estimated to be around KRW 150 billion excluding installation cost.

KEPCO (Korea Electric Power Corporation), a public electricity enterprise, has been implementing a subsidy program since 2014 to encourage the pentration of heat pumps boiler designated to late-night electriticy. This program's main object is to replace the current late-night electric boilers with high efficient heat pump boilers which should be able to produce 80 °C hot water heat using ambient air.

![](_page_142_Picture_0.jpeg)

*Figure 4-61 Configuration diagram of KEPCO heat storage heat pump boiler (source: https://home.kepco.co.kr/kepco/CY/K/htmlView/CYKDHP01101.do?menuCd=FN02070410).*

The table below shows the number of heat pump boilers installed through this support, and in 2017, the number of installation cases reached over 10,000. However, the total amount of subsidies has been largely reduced since 2019 and in 2022, the total installation cases is estimated about 100.

*Table 4-11 Heat pump boiler installation cases through KEPCO subsidy program (source: http://kharn.kr/news/article\_print.html?no=10897)*

| Year          | 2014 | 2015  | 2016  | 2017    | 2018   | 2019.08 |
|---------------|------|-------|-------|---------|--------|---------|
| Installations | 725  | 2,370 | 7,910 | 116,923 | 10,488 | 1,642   |

Large-capacity high-temperature heat pumps that can produce industrial process heat under 100 °C have been commercialized by Century, Bumyang, and LG Electronics. However, there are almost no cases of actual installation. The main reasons may be low awareness of consumers to HTHP and government policies centered on the building/household sector.

Despite current market obstacles, there are many positive signals for the future market of HTHP. According to the total energy survey report, Korea's largest energy consumption sector is the industrial sector, accounting for 60% of the total consumption. De-carbonization of the industrial sector is the key factor of Korea's transition to carbon neutral society. Therefore, it is expected that the HTHP market will be formed in Korea soon to cope with the global carbon neutral.

![](_page_142_Figure_7.jpeg)

*Figure 4-62 Energy Consumption Survey, 2020, complied by Korea Energy Economics Institute and Korea Energy Agency.*

#### <span id="page-143-0"></span>4.12.3. Development perspectives for HTHP technologies

Many heat pump RD&D projects have been focused on heat pump's efficiency improvement, utilization of waste heat, unused heat, or low temperature renewable heat. In order to properly dealing with industrial heat demand, the temperature that a heat pump produce should be increased from current 60-80 °C to a level that can generate steam. HTHP for steam generation has not yet been commercialized in the Korean market due to market conditions and technical limitations. Since Korea's industrial sector accounts for more than 60 % of energy, RD&D activities should be carried out to overcome various obstacles and establish reference application cases of HTHP to industrial processes. Key RD&D directions include low GWP refrigerant adaptation, key components developments (compressors, heat exchangers, etc.) to overcome high-temperature operation range, system design tool embracing industrial processes and district heating, etc.

#### <span id="page-143-1"></span>4.12.4. Selected RD&D projects

#### Steam generation heat pump system development for a chemical process

In the industry field, steam is widely used in the processes such as refining, extraction, and food processing. Many researchers have been working on developing energy saving method of steam generation using low temperature waste heat. High temperature heat pump which can generate low pressure steam is one of the technical candidates for this. In this study, a heat pump system that produces steam of over 100 °C with capacity of 0.5 ton/h was developed based on cycle design methods in chapter 2. The steam heat pump utilizes waste heat of 50-70 °C, producing 110-120 °C steam using a flash tank. Then, the developed steam heat pump system was tested at a Chemical Polycarbonate (PC) production line in Yeosu Industrial Complex.

R-245fa was considered as suitable refrigerant of heat pump cycle for steam generation condition since the critical temperature of R-245fa is above the operation temperature of steam generation condition. Similar design concepts of R-134a hot water heat pump could be applied to design steam heat pump cycle when steam is produced through flashing process.

Below figure shows a conceptual diagram of the steam heat pump apparatus, which receives heat from the heat source water on the left side and produces steam through a flash tank on the right side. The manufactured steam heat pump system is shown in the next figure. Performance improvement and stability evaluation were conducted in the laboratory prior to the installation in the demonstration site. The final performance in the laboratory was Steam 118.3 °C, capacity 362.6 kW, and COP 3.73.

![](_page_143_Figure_7.jpeg)

Figure 4-63 Schematic diagram of steam generation heat pump.

![](_page_144_Picture_0.jpeg)

![](_page_144_Picture_1.jpeg)

*Figure 4-64 Steam generation heat pump unit.*

The pressure of the steam line of the target process was about 0.16 MPa, which corresponds to steam temperature of 115 °C. The developed HTHP package was installed in the demonstration site of a chemical factory. It consists of a heat pump unit and a flash tank unit. The installation in the chemical plant took about two months, and the operation of the steam pump system started in February 2018. The performance of the steam heat pump during the test run period is as follows; Steam output: approx. 0.53 ton/h, steam heat pump performance: 348 kW, COP 3.03.

![](_page_144_Picture_6.jpeg)

![](_page_144_Picture_7.jpeg)

*Figure 4-65 Field test and evaluation of steam heat pump at LG Chem.*

![](_page_144_Figure_9.jpeg)

*Figure 4-66 Generated steam temperature and heat source temperature of heat pump during field test*

#### Oil-free turbo compressor development for a HTHP

The RD&D project for Steam Heat Pump was conducted by Bumyang Co., LTd and other 6 institutes. (project period: 2014.06.01—2018.11.30) The main goal of the project is the development of an oil-free centrifugal refrigerant compressor suitable for high temperatures operation. The screw compressor

needs cooling of the lubricating device, and the volume of the system should be increased. However, an oil-free refrigerant compressor with a simple magnetic bearing needs no lubrication device. So, the volume of compressor part can be reduced, and compressor becomes free of the failure of lubricant cooling device. The motor performance evaluation was performed up to 138°C and long-term operation was tested at 38,500 rpm. In the early stage of development, bump foil type gas bearing was applied because of its simple structure and low manufacturing cost. Then, to respond to rapid operation changes, the bearing part was changed to magnetic bearing which showed safer results under high temperature/high pressure (130 °C, 23 bar) and surging conditions. Below figures shows the configuration of the steam heat pump developed, and a cycle diagram. In addition, a plate and shell type heat exchanger was developed as a condenser to provide excellent durability and heat transfer efficiency under high temperature and high pressure conditions and facilitate maintenance in industrial sites. The plate and shell heat exchanger has a heat transfer performance similar to that of the platetype heat exchanger. Using R-245fa as a refrigerant, COP 3.37 was achieved with a capacity of 300 kW, a steam production temperature of 120 °C and an evaporation heat source temperature of 70 °C.

![](_page_145_Picture_1.jpeg)

*Figure 4-67 Configuration of the developed steam heat pump.*

![](_page_145_Picture_3.jpeg)

*Figure 4-68 Steam heat pump cycle diagram.*

![](_page_146_Picture_0.jpeg)

*Figure 4-69 Structure of plate and shell heat exchanger.*

#### <span id="page-146-0"></span>**4.13. Switzerland**

This chapter provides an overview of Switzerland's national HTHP industry and ongoing research, development, demonstration, and funding activities.

#### <span id="page-146-1"></span>**4.13.1. Overview of the National HTHP Industry**

According to the authors' best knowledge, only two manufacturers in Switzerland offer HTHP technology with supply temperatures above 100°C, namely FRIOTHERM AG, headquartered in Frauenfeld, and MAN Energy Solutions AG from Zurich. Their focus is primarily on tailor-made large-scale heat pumps with heating capacities in the MW range. Therefore, the main driving force behind the technical developments in their compressor technologies represents a unique selling proposition.

Friotherm AG [94] has over 30 years of operating experience with large heat pumps in district heating networks using its core UnitopTM centrifugal compressor technology. [Figure 4-70](#page-146-2) gives an overview of Friotherm AG's HTHP technology, including 1-stage and 2-stage customized heat pumps with heating capacities from 3 MW to 35 MW, delivering water temperatures up to 120 °C from various liquid heat sources in a wide temperature range.

As a specialty, [Figure 4-70](#page-146-2) (C) shows a 25 MW heat pump producing superheated water at 137 °C for low-pressure steam generation. This steam-generating heat pump was designed for a heat source of 55/40 °C and a heat sink of 130/137 °C. It operates with the refrigerant R-1233zd(E) and achieves a COP of approx. 2.5. The dimensions are approx. 18 x 15 x 10 m.

<span id="page-146-2"></span>![](_page_146_Picture_8.jpeg)

*Figure 4-70: Application range of FRIOTHERM AG heat pumps with heat supply temperatures above 100 °C. (A) 1-stage and 2--stage tailor-made heat pumps with centrifugal compressor, heating capacity from 3 MW to 35 MW, various liquid heat sources in a wide temperature range, supplying hot water temperatures up to 120 °C (higher on request). (B) Customized double-group heat pump with dimensions of 22.5 x 10.8 x 6.8 m (L x W x H) and up to 35 MW heating capacity. (C) Heat pump producing superheated water at 137 °C for the low-pressure steam generation with a heating capacity of 25 MW, heat source 55/40 °C, heat sink 130/137 °C, R-1233zd(E) refrigerant, COP of around 2.5, dimensions approx. 18 x 15 x 10 m (Pictures courtesy of Friotherm AG, Frauenfeld, Switzerland).*

In 1986, Friotherm AG (Sulzer) introduced the first steam-generating heat pump consisting of a Unitop® heat pump with two Uniturbo 22 BX turbo compressors connected in series. The technical data suggested a steam temperature of 123 °C at 59 °C/56 °C heat source (inlet/outlet) and a COP of 2.7.

The employed R-114 refrigerant, which is prohibited today due to ozone depletion, has been replaced by low-GWP HFO refrigerants. Thus, steam-generating heat pumps in the MW range with turbo compressors will directly serve the low-pressure steam of an industrial company.

MAN Energy Solutions Schweiz AG [95] supplies the heat pump solution HPU that runs with CO<sup>2</sup> as a working medium in an optimized transcritical cycle. This HTHP unit can generate temperatures from 0° C up to 150 °C, up to 50 MW of thermal heat, and 30 MW of cold. The core technology is the High-Speed Oil-Free Integrated Motor compressor (HOFIM®), which incorporates an active magnetic bearing system that ensures a wide operating range, high reliability, availability, and a fast start-up and shutdown.

[Figure 4-71](#page-147-1) (A, B, and C) shows an example of the MAN heat pump, the HOFIM® compressor details, and its operating range and efficiency. At nominal reference conditions with a heat sink supply/return temperature of 110 °C/40 °C and heat source temperature of 10 °C/7 °C, the MAN HPU43 type heat pump (with 20 tons CO<sup>2</sup> refrigerant charge) reportedly achieves a heating COP of 3.05 and a COP for cooling of 2.05 (combined around 5.1). The transcritical cycle is especially suited for significant heat sink temperature glides above 40 K.

![](_page_147_Figure_4.jpeg)

<span id="page-147-1"></span>*Figure 4-71: (A) Example of a MAN Heat Pump. (B) Typical HOFIM™ (High-speed Oil-Free Integrated Motor compressor) skid with up to 16 MW electrical power. (C) Predicted performance map (COP heating) for different operating conditions and COP values as a function of heat sink supply and return temperatures for constant source temperatures (Pictures courtesy of MAN Energy Solutions Schweiz AG, Zurich).*

MAN's electro-thermal energy storage system (MAN ETES) [96] integrates heat and cold production, storage, and reconversion into electricity by an expander. Therefore, the ETES system is a complete energy management system that allows a broad range of applications and enables sector coupling. So far, MAN Energy Solutions is mainly active in district heating and is about to deliver the first crosssectoral ETES technology to the Danish port city of Esbjerg [97] with an overall heating capacity of 50 MW.

#### <span id="page-147-0"></span>**4.13.2. Realized HTHP applications examples in Switzerland**

Some industrial heat pumps installed in Switzerland can produce heat with temperatures higher than 100 °C but operate at a lower supply temperature. Three application examples reach 90 to 95 °C and a CO<sup>2</sup> heat pump prototype up to 119 °C [\(Figure 4-72\)](#page-148-0).

![](_page_148_Picture_0.jpeg)

*Figure 4-72: (A) HTHP installed at the mountain cheese factory Gais in Appenzell working with mildly flammable refrigerant R-1234ze(E) in an economizer cycle, Type IWWHS 570 ER6c2 from Ochsner Energie Technik GmbH, 520 kW heating capacity, screw compressor, heat source (in/out) 18/14 °C, heat sink (in/out) 82/92 °C or 55/65 °C). (B) HTHP installed at GVS Landi in Schaffhausen, Type ISWHS 60 ER3 from Ochsner Energie Technik GmbH, 63 kW heating, and 48 kW cooling capacity, ÖKO 1 (R-145fa) refrigerant, screw compressor, heat sink from 80 to 95 °C, heat source 37 °C, COP heating of 4.2. (C) Three CO<sup>2</sup> heat pumps of the type thermeco2 HHR 260* [98] *at the Slaughterhouse in Zurich provide hot water of 90 °C for slaughtering and cleaning purposes. (D) The CO<sup>2</sup> heat pump prototype at Empa NEST in Dübendorf delivers heat up to 119 °C for a wellness sauna.*

<span id="page-148-0"></span>For example, at the mountain cheese factory Gais in Appenzell [99], an industrial HTHP from Ochsner Energie Technik GmbH (AT) [100], [101] (Type IWWHS 570 ER6c2) [\(Figure 4-72,](#page-148-0) A) transforms waste heat from the neighboring data center into process heat of up to about 95 °C for heating and processing milk. The installed heat pump can produce > 100 °C heat but runs at a lower production temperature. It saves the mountain cheese factory about 1.5 million kWh of natural gas annually, corresponding to around 300 tCO2/year emissions savings. The HTHP features an economizer cycle with steam injection into a two-stage screw compressor, providing an efficient solution for high-temperature lifts. The nominal heating capacity is 520 kW. Depending on the operating conditions, the heating COP ranges from 2.55 to 2.85 at a 74 K temperature lift (W18-14/W82-92) and from 3.75 to 4.20 at a 47 K lift (W18-14/W55- 65).

At GVS Landi AG in Schaffhausen [102], another HTHP is installed [\(Figure 4-72,](#page-148-0) B) that could potentially deliver supply temperatures > 100 °C. It recovers waste heat from air-coolers of the refrigeration plants (used for cooling warehouses) to generate process water for cleaning a bottling machine and wine tanks [103] in the wine cellar needs. Installed is an HTHP from Ochsner (Type: ISWHS 60 ER3, with 63 kW heating capacity) with a screw compressor, economizer cycle, and refrigerant ÖKO 1 (R-245fa). The investment has reduced CO<sup>2</sup> emissions by 30% with a payback period of 4 years (at relatively moderate investment costs of CHF 120,000). The heating COP is about 4.2 at a heat source of 37 °C and a heat sink of 80 to 95 °C.

At the slaughterhouse in Zürich, three CO<sup>2</sup> heat pumps (thermeco2 HHR 260, ENGIE) have operated since 2011 with a heating capacity of 800 kW to heat water from approx. 30 °C to 90 °C for cleaning purposes and as feed water for a steam generator and the heating system. Twelve GEA CO2 transcritical compressors drive the heat pumps. The heat pump system uses the waste heat from an existing ammonia refrigeration machine, an oil-cooled air compressor plant, and fan-coil units. EWZ [104] planned and operates the heat pump system. The COP of the HTHP is 3.4 at 90 °C/30 °C. In this way, fuel consumption could be reduced by 30% and the CO<sup>2</sup> emissions by 510 tCO2/year.

A prototype CO<sup>2</sup> heat pump is installed in a research building of EMPA NEST for the wellness sauna

application [105] [\(Figure 4-72,](#page-148-0) C). In cooperation with Scheco AG [106], a new CO<sup>2</sup> heat pump was designed and installed as a pilot system with different temperature levels for saunas, steam baths, and shower heating. Measurements are being carried out to optimize the overall HTHP system. Low return temperatures are crucial for efficiency. The system impresses with high temperatures on the refrigerant side (120 to 140 °C) and the consumer side (up to 119 °C). A maximum COP of 3.6 has been reached, but there is potential for improvement to reduce return flow temperature for higher heat pump efficiency. In another R&D project, Scheco AG has developed a water-brine heat pump for waste heat recovery from an electrolyzer for hydrogen production. The heating capacity is 54 kW, and a COP of 2.3 is achieved at 93 °C/100 °C (heat sink) and 35 °C/30 °C (heat source).

The market for HTHP in Switzerland is still in its infancy and has yet to be developed [107]. However, there are numerous system integrators. For example, Walter Wettstein AG Kältetechnik [108] is a leading manufacturer of refrigeration chillers and heat pumps for the industry, especially with ammonia (NH3) as a natural refrigerant. Currently, the company offers R-717 heat pumps with a heating capacity of 0.2 to 20 MW with supply temperatures up to 85 °C. A HTHP solution with R-717/R-600 (n-butane) is in the technical clarification phase.

A realized example in the field of district heating in Switzerland is the district heating network of Gruyère Energie SA (GESA) in Bulle with a heat pump from Ochsner (Type IWWDS 540/540 R4c4) [109] and a heating capacity of 1.8 MW [110]. The heat pump uses waste heat from the Liebherr company and can operate up to 125 °C on the heat sink, but it works at W60/W90.

Besides closed-cycle HTHPs, MVR (Mechanical Vapor Recompression) is applied in Switzerland, and there are several operational examples, mainly focused on the food industry, including:

- Saline de Bex (Bex): Brine concentration for salt production
- Cremo (Villars-sur-Glâne): Milk concentration by evaporation for milk powder production
- Nestlé (Orbe): Coffee extract concentration for instant coffee production
- Ramseier (Sursee): Fruit juice concentration

Additional applications are currently being identified, e.g., in the concentration and drying of wastewater sludge. In addition, several Swiss companies also apply MVR for desalination plants [111].

Interestingly, MVR is a Swiss success story. The principle of MVR technology was invented [112] in Switzerland by Antoine-Paul Piccard (great-granduncle of the famous aeronaut Bertrand Piccard, known for his round-the-world balloon flight and Solar Impulse project) to produce salt by evaporation of brine at the Saline de Bex [113].

[Figure 4-73](#page-149-0) illustrates one of the early designs of the MVR by A.-P. Piccard for brine concentration installed in 1877 at Saline de Bex.

![](_page_149_Picture_11.jpeg)

*Figure 4-73: One of the early designs of mechanical vapour compression by A.-P. Piccard for brine concentration at the Saline de Bex (Excerpt from Georges Gavairon, June 2011, Le sel de A à Bex – Résumé de 500 ans d'histoire, de persévérance, d'ingéniosité, de compétence, de labeur et de passion aux Mines et Salines de Bex* [114]*).*

<span id="page-149-0"></span>After the invention of the principle, A.-P. Piccard improved technology several times. Later, MVR

technology was applied in numerous other salt plants in Switzerland, as reviewed by Martin Zogg in "History of Heat Pumps: Swiss Contributions and International Milestones" [115]. Today, Switzerland's largest MVR systems are in operation in Riburg and Schweizerhalle, with a total evaporation capacity of about 80 MW. Presently, the MVR system for the production of salt at the Saline de Bex consumes approximately 500 kW of electrical power to upgrade 11'200 kg/h vapor from 1.29 to 2.25 bar (136 °C) and supplies about 7.4 MW of thermal energy to evaporate water from brine [\(Figure 4-74\)](#page-150-1). The resulting COP is about 14.7.

![](_page_150_Figure_1.jpeg)

<span id="page-150-1"></span>*Figure 4-74: (A) Turbocompressor from MAN at Saline de Bex (Picture courtesy of Pierre Krummenacher). (B) Simplified schematic of the MVR installation at Saline de Bex (Source: Sulzer/Saline de Bex, adapted by Pierre Krummenacher, reproduced with permission of Salines Suisses).*

Currently, most of the installed heat pumps in Switzerland are electrically driven. To the authors' knowledge, few (if any) large-capacity absorption heat pumps are in operation in Switzerland, although small/medium-capacity gas-fired heat pumps are available for HVAC applications. In addition, there is no Swiss statistic on absorption heat pump sales.

In addition, the opportunities for meaningful integration of thermally driven HTHPs in the industry are likely to be significantly lower than those of electrically driven HTHPs because thermally driven HTHPs require additional features, such as a particular shape of the Grand Composite Curve of the process/industrial site, which is less often fulfilled than for electrically driven HTHPs.

#### <span id="page-150-0"></span>**4.13.3. Overview of the Swiss national HTHP market and application potential**

[Figure 4-75](#page-151-0) shows the sales statistics from FWS (Fachvereinigung Wärmepumpen Schweiz) [116] of the Swiss heat pump market in 2021 compared to gas and oil boilers, (A) in sales units and (B) in total installed heating capacity. The FWS statistically tracks air-water, brine-water, and water-water heat pumps. Heat pumps are well established in the lower capacity range for the residential sector (market share of over 90% in new buildings).

When multiplying the units with the heating capacity, it becomes clear that above 50 kW oil and gas boilers dominate the market regarding heat production volume, hence illustrating the decarbonization potential in the Swiss industry. Furthermore, Switzerland's cumulated numbers of gas and oil boilers cover a much larger share (1'025 MW) of the heating capacity than heat pumps (630 MW).

<span id="page-151-0"></span>*Figure 4-75: Statistics of the Swiss heat pump market (orange) compared to oil and gas boilers (blue) (A) in units of sales and (B) in cumulated heating capacity distributed by heating capacity range (Data: FWS, 2021).*

According to FWS 2021 sales statistics, the number of sold heat pumps increased to an all-time high of 33'704 units compared to 28'064 in 2020, corresponding to an annual growth rate of 20%. Also, 73% of the sold heat pumps were air/water and 25.6% brine/water-based. There were 169 heat pumps sold with >100 kW heating capacity (around 0.5% of all units). Unfortunately, there needs to be more information about the temperature ranges of the heat sources and sinks. In addition, there are no statistics on MVR sales or specifically on industrial heat pumps.

Aside from space heating and hot water, the industry needs process heat for manufacturing, processing, and refining products. As shown in [Figure 4-76](#page-151-1) (A), according to the Swiss Federal Office of Energy (SFOE), the process heat demand in Swiss industry corresponds to around 86.8 PJ (24.1 TWh) or 56.1% of the total industrial final energy consumption (154.7 PJ or 43.0 TWh) (as of 2018).

![](_page_151_Figure_4.jpeg)

<span id="page-151-1"></span>*Figure 4-76: Process heat demand (>80 °C) in the Swiss industry (2018) (A) divided by industrial sector (B) showing the theoretical addressable market potential for industrial HTHPs (Data: SFOE, 2019).*

The addressable potential using HTHPs in the Swiss industry can be roughly estimated based on the process heat demand and the share of process heat below 150 °C [\(Table 4-12\)](#page-152-0).

According to Heat Roadmap Europe, the energy demand for process heat below 100 °C is about 222.5 TWh (9% of the total energy for industrial heat demand in Europe), and for process heat between 100 °C and 200 °C about 508 TWh (21%), which together corresponds to 30%. If this factor is applied to the Swiss industry, the process heat demand below 150 °C is 7'232 GWh/year.

Assuming in a pessimistic and an optimistic scenario that HTHPs could cover 10% and 50% of this, respectively, the process heat potential that can be covered by HTHPs is 723 and 3'616 GWh/year, i.e., approximately 3% to 15% of the industrial process heat demand [\(Table 4-12\)](#page-152-0).

If the integrated HTHPs run with at least 5000 operating hours per year, this results in a total heating capacity of 145 to 723 MW and, with specific investment costs (incl. installation, without integration) of approx. 480 to 750 CHF per kW heating capacity, [117], [118] a potential investment volume of 69 to <span id="page-152-0"></span>542 million CHF for the Swiss industry. Assuming an average heating capacity per HTHP unit of 1 MW results in 145 to 723 HTHP units.

Table 4-12: Estimation of the potential addressable market for HTHPs in the Swiss industry.

| Pot<br>t al calc lat o for HTHPs<br>Sw tz rla |                           |       |             | Data so rc , r marks                   |
|-----------------------------------------------|---------------------------|-------|-------------|----------------------------------------|
| Swiss industry energy                         | 42,972                    |       | GWh         | 154.7 PJ (as of 2018, SFOE)            |
| consumption                                   |                           |       |             |                                        |
| Process heat demand                           | 24,107                    |       | GWh         | 56.1% [119]                            |
| Process heat demand < 150 °C<br>7,232         |                           |       | GWh         | 30% estimate, Heat Roadmap             |
| Scenarios                                     | Pessimistic<br>Optimistic |       |             | Europe [120]                           |
| Conversion change to HTHPs                    | 10%                       | 50%   |             | Own estimate                           |
| Addressable process heat by<br>HTHPs          | 723                       | 3,616 | GWh         |                                        |
| % of total process heat demand<br>by HTHPs    | 3%                        | 15%   |             |                                        |
| Heating capacity of installed<br>HTHPs        | 145                       | 723   | MW          | 5,000 h/a operation assumed<br>average |
| Electrical need for HTHPs                     | 241                       | 1,205 | GWh         | COP = 3, own estimate                  |
| Energy savings by HTHPs use                   | 482                       | 2,411 | GWh         |                                        |
| Investment volume min                         | 69                        | 347   | Mio.<br>CHF | 480 CHF/kW (Wolf et al., 2017)         |
| Investment volume max                         | 108                       | 542   | Mio.<br>CHF | 750 CHF/kW (Wolf et al., 2017)         |
| HTHP units                                    | 145                       | 723   | Units       | 1 MW average size, own estimate        |

Target markets for decarbonizing process heat in Switzerland and with high potential for using HTHPs are the chemical/pharmaceutical, minerals, food/beverage, metal, and paper industries [\(Figure 4-76,](#page-151-1) B). The most promising sectors in terms of complementarity between available waste heat at 40 to 60 °C and process heat demand at 100 to 150 °C seem to be the chemicals and pulp/paper industries, where the use of industrial heat pumps can cover more than all the demand at these temperatures, and the food industry (25% coverage rate) [121]. In addition, the iron and steel industry also shows potential for waste heat recovery through industrial heat pumps.

Based on a study from EPFL [122], the most promising industrial sectors for heat pump integration are the food and beverage sector (overall carbon mitigation potential between 25 to 58% and payback times from 3 to 6 years), followed by the chemical sector (total of 22 to 74% emission reduction potential with a payback of 2.1 years).

![](_page_153_Picture_0.jpeg)

![](_page_153_Picture_1.jpeg)

![](_page_153_Picture_11.jpeg)

![](_page_153_Picture_12.jpeg)

![](_page_153_Picture_13.jpeg)

![](_page_153_Picture_14.jpeg)

![](_page_153_Picture_15.jpeg)

![](_page_153_Picture_16.jpeg)

![](_page_153_Picture_17.jpeg)

![](_page_153_Picture_26.jpeg)

<span id="page-153-1"></span>Case studies for HTHPs can be found in particular in the dairy industry (evaporation, pasteurization) and biotechnology (distillation) for low-pressure steam generation (e.g., 120 °C). It was estimated that approximately 35% [124] of the total fuel energy consumption in the Swiss industry is used to meet the demand for steam, which could be supplied by low-pressure evaporation and MVR or HTHP systems [125], [126].

All in all, there is a significant application potential for tailor-made industrial HTHPs to end-users in the food/beverage, paper, metal, and chemical/pharmaceutical industries, especially for (low-pressure) steam generation, drying, preheating, distillation processes as well as pasteurization, sterilization, cooking, evaporation, or even washing or dyeing. [Figure 4-77](#page-153-1) illustrates potential applications and target industrial sectors for industrial HTHPs.

#### <span id="page-153-0"></span>**4.13.4. Funding programs for industrial heat pumps in Switzerland**

There are several national funding programs at the federal level to accelerate the integration of heat pumps in the industry. However, the subsidies depend to a large extent on a legal basis. In general, funding programs are a dynamic field with details subject to change.

Following Switzerland's failed CO<sup>2</sup> energy law in 2021, a provisional CO<sup>2</sup> law now secures the legal basis until 2024. What the legal provisions will look like after that is still being determined. But, judging by the public debates, subsidies will likely play a major role in achieving the goal of net zero by 2050. However, it is still being determined what the subsidy share for heat pumps will be.

[Table 4-13](#page-154-0) gives an overview of a selection of funding programs for HPs for industrial process heat in Switzerland. Further information on the programs, program managers, financing, and subsidy conditions is available via the info links. For a more general overview of innovation promotion in the energy sector, the reader is referred to the admin.ch website. 24

<sup>24</sup> <https://www.bfe.admin.ch/bfe/en/home/research-and-cleantech/overview-of-innovation-promotion.html>

<span id="page-154-0"></span>Table 4-13: A selection of funding programs for industrial heat pumps in Switzerland (SFOE: Swiss Federal Office of Energy).

| F<br>g<br>program | P<br>ch A alys s                                                                                       | H at P mps for<br>Proc ss H at                                                                                                                                                   | Kl mapräm<br>(Cl mat bo<br>s)                                                                                                            | P lot a<br>D mo strat o                                                                                                                                |
|-------------------|--------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| Program           | EnergieSchweiz                                                                                         | EnergieSchweiz                                                                                                                                                                   | Energie Zukunft                                                                                                                          | SFOE                                                                                                                                                   |
| Manager           | (SuisseEnergie)                                                                                        | (SuisseEnergie)                                                                                                                                                                  | Schweiz                                                                                                                                  |                                                                                                                                                        |
| Financing         | SFOE                                                                                                   | SFOE                                                                                                                                                                             | KliK Foundation                                                                                                                          | SFOE                                                                                                                                                   |
| Amount            | Pre-analyses:<br>max. 60% of<br>total costs<br>Pinch analyses:<br>max. 40% of<br>total costs           | Max. 40% of<br>additional costs<br>compared to<br>conventional<br>technology (e.g., oil<br>or gas boiler)                                                                        | 0.18 CHF/kWh heat<br>About 360 CHF/kW heat<br>at 2000 h annual<br>operation                                                              | Up to 40% (60%)<br>of non<br>amortizable<br>supplementary<br>costs                                                                                     |
| Criteria          | Using PinCH<br>Software<br>Trained experts<br>Publication of<br>findings<br>(summary, final<br>report) | Industrial process<br>heat<br>Payback > 4 years<br>Funding request<br>before construction<br>starts<br>Companies with a<br>CO2<br>tax exemption<br>are examined<br>individually. | Replacement of oil/gas<br>boiler with heat pump<br>Order not yet placed<br>CO savings to be<br>transferred to Energie<br>Zukunft Schweiz | Application<br>potential<br>Innovation<br>content<br>Pilot: TRL 4 to 7<br>Demonstration:<br>TRL 7 to 9<br>Publication of<br>findings (final<br>report) |
| Infos             | Website25<br>,<br>Flyer26                                                                              | Website27, Flyer28                                                                                                                                                               | Website29, Flyer30<br>,<br>31                                                                                                            | Website32                                                                                                                                              |

**Pinch Analyses:** The SFOE financially supports pinch analyses of up to 40% of total costs and preanalyses of savings potential and pinch suitability covering up to 60% of the total costs. Depending on the data basis, a pinch analysis costs between 30 and 80 kCHF. Only analyses by experts with recognized training in pinch methodology (e.g., pinch software PinCH 2.0/3.0/3.5, Lucerne University of Applied Sciences and Arts)<sup>33</sup> are supported. The funding is associated with delivering a management summary or final report of the study results, which includes the technical measures derived with an estimate of investment costs and energy cost savings. The final reports will be made available on the

<sup>25</sup> <https://www.energieschweiz.ch/beratung/pinch/> (DE) and<https://www.suisseenergie.ch/conseil/pinch/> (FR)

<sup>26</sup> <https://pubdb.bfe.admin.ch/de/publication/download/8357> (DE) and <https://pubdb.bfe.admin.ch/fr/publication/download/8357>

<sup>27</sup> <https://www.energieschweiz.ch/prozesse-anlagentechnik/industrielle-waermepumpe/> (DE) and <https://www.suisseenergie.ch/processus-technique-dinstallations/pompes-industrie/> (FR)

<sup>28</sup> <https://pubdb.bfe.admin.ch/de/publication/download/10753> (DE) and <https://pubdb.bfe.admin.ch/fr/publication/download/10753> (FR)

<sup>29</sup> [https://www.klimapraemie.ch](https://www.klimapraemie.ch/) (DE) and [https://www.primeclimat.ch](https://www.primeclimat.ch/) (FR)

<sup>30</sup> [https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-factsheet](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-factsheet-grosse-anlagen_2022.pdf)[grosse-anlagen\\_2022.pdf](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-factsheet-grosse-anlagen_2022.pdf) (DE) and [https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-factsheet-grosse-anlagen-fr.pdf)[factsheet-grosse-anlagen-fr.pdf](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-factsheet-grosse-anlagen-fr.pdf)

<sup>31</sup> [https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-detaillierte-foerderkriterien_wp_de.pdf)[detaillierte-foerderkriterien\\_wp\\_de.pdf](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-detaillierte-foerderkriterien_wp_de.pdf) (DE) and [https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-detaillierte-foerderkriterien_wp_fr.pdf)[detaillierte-foerderkriterien\\_wp\\_fr.pdf](https://energiezukunftschweiz.ch/wAssets/docs/foerderprogramme/klimapraemie/klimapraemie-detaillierte-foerderkriterien_wp_fr.pdf)

<sup>32</sup> <https://www.bfe.admin.ch/bfe/en/home/research-and-cleantech/pilot-and-demonstration-programme.html>

<sup>33</sup> <https://pinch-analyse.ch/en/pinch> (EN) and<https://pinch-analyse.ch/fr/> (FR)

SFOE's publications database <sup>34</sup> . The SFOE contribution is paid exclusively to the implementing company.

**Heat Pumps for Process Heat:** The "Heat Pumps for Process Heat" funding program started in 2021 and promotes the market entry of industrial heat pumps. It supports up to 40% of the additional investment costs of a heat pump (system and installation) compared to the costs of a conventional heating technology (e.g., oil or gas boiler). Engineering and monitoring costs can also be funded by up to 40%. The heat pump must generate process heat, and the funding request must be made before construction. In addition, the project must have a payback time of more than 4 years. Combining subsidies from other funding programs (e.g., KliK) is generally possible. In 2021, 4 projects with a total of approx. 500 kCHF were subsidized. In 2022, there were 4 projects funded with 700 kCHF in total. The SFOE actively promotes the funding program through a targeted information campaign, contacting potential companies directly and focusing on industries with strong net-zero targets. The goal is to reach 60% to 80% of this market. So far, SFOE is on track to achieve this goal. Today, the biggest hurdles tend to be technical, mainly that integrating a heat pump into the process is more complicated than a 1:1 replacement of the fossil heating system. Even in greenhouses, converting to fossil-free heating requires some system integration work. To address this issue, the SFOE will focus on easy-to-integrate solutions in the hope that these will create a larger market starting in 2023.

**Klimaprämie (Climate bonus):** The "Klimaprämie" provided by the Klik Foundation and managed by Energie Zukunft Schweiz AG is a subsidy program for renewable energy use in heating applications to replace natural gas or oil heating systems with heat pumps or wood heating systems in residential, office and commercial buildings, as well as in industrial heat generation. The climate bonus is calculated based on the previous annual fossil energy consumption and amounts to CHF 0.18/kWh, i.e., approx. CHF 1.8/L of heating oil or m<sup>3</sup> of natural gas saved, or approx. CHF 360/kW for 2000 h of annual operation. The climate bonus is not subject to an upper limit and offers new opportunities for large-scale systems. Up to funding of CHF 200'000, 50% of the amount is paid after commissioning and 50% after the first year of operation. For a large heat pump with a heating capacity >2 MW, a reference offer for the 1:1 replacement of fossil heating is required. Bivalent and multivalent systems are also eligible. Finally, the CO<sup>2</sup> savings achieved with the heat pump need to be transferred to Energie Zukunft Schweiz AG and cannot be the subject of any other compensation.

**Pilot and Demonstration (P+D) projects:** With the P+D program [127], the SFOE promotes the development and testing of new technologies, solutions, and concepts related to the economic and ecological use of energy, the transmission and storage of energy, and the use of renewable forms of energy. The P+D program acts as an interface between research and the market [\(Figure 4-78\)](#page-159-1). The main funding criteria of P+D projects are substantial application potential and innovation content. A research partner (e.g., a University of Applied Science) is required to ensure the scientific nature of the P+D project. Funding covers the cost of the research partner. The maximum permissible financial support by the SFOE to P&D projects is up to 40% (in exceptional cases even 60%) of the nonamortizable supplementary costs. P+D projects with HTHP technology appear realistic, especially for heat pumps generating steam.

### <span id="page-155-0"></span>**4.13.5. Research programs for HTHPs in Switzerland**

**Heat Pumps and Refrigeration:** Under the research program Heat Pumps and Refrigeration [128], the SFOE defines "heat pumps with a broad, flexible temperature regime" and "innovative heat pumps for industrial processes" as current research priorities. HTHP technology fits into these priorities.

**Buildings and Cities:** The Buildings and Cities research program [129] aims to promote the further development of sustainability strategies with new technologies and an optimized interaction of energy production, storage, distribution, and consumption. In the 2020 call, the project HiTemHP [130] (Efficient use of HTHPs in old buildings and for renovations) from EMPA (Dübendorf) and Scheco AG (Winterthur) was approved. This project investigates CO2 HTHPs with supply temperatures up to 90 °C and how the heat pump system with heat source and sink must be designed to achieve a comfortable indoor climate and high energy efficiency.

**SCCER EIP (Swiss Competence Center Energy Research - Efficiency of Industrial Processes):** A major outcome of the finished SCCER EIP project [131] was research on HTHPs, published in a book

<sup>34</sup> <https://pubdb.bfe.admin.ch/de/suche?keywords=&q=pinch>

entitled Hochtemperatur-Wärmepumpen [132] and a well-cited review paper [1]. Apart from the theoretical analyses, a prototype HTHP was built at the OST Eastern Switzerland University of Applied Sciences with eco-friendly refrigerants reaching 70 °C to 150 °C heat sink temperature with a COP of 2.1 to 4.5 and a temperature lift of 30 K to 70 K. Although HTHP systems are already in operation, several market barriers have been identified, such as high specific investment costs, a limited number of HTHP manufacturers on the market, little experience among planners and end-users, and preconceptions about lifetime and suitability.

**SWEET - SWiss Energy research for the Energy Transition:** SWEET [133] is a funding program of the SFOE to accelerate innovations that are key to implementing Switzerland's Energy Strategy 2050 and achieving the country's climate goals. The funding program was launched in early 2021 and runs until 2032. One sponsored project is SWEET DeCarbCH (Decarbonisation of Cooling and Heating in Switzerland, [www.sweet-decarb.ch\)](http://www.sweet-decarb.ch/) [134] with the University of Geneva as the host institution. Work package WP05 focuses on the optimal combination of existing and future technologies to achieve medium and high temperatures and cooling at different capacity levels. Furthermore, the technical solutions for industrial HTHP will be considered, and proposals for accelerated market introduction will be developed.

#### <span id="page-156-0"></span>**4.13.6. Selected R&D projects for HTHPs in Switzerland**

[Table 4-14](#page-156-1) presents the most relevant national and international R&D projects of the Swiss partners related to HTHPs, including motivation, objectives, partners, and main results. Several ongoing research projects for HTHPs will receive federal funding during the next years. The ARAMIS<sup>35</sup> information system systematically records federal funded research, innovation, and evaluation projects.

<span id="page-156-1"></span>Table 4-14: List of selected R&D projects for industrial HTHPs in Switzerland (Abbreviations of partners: CSD: CSD Ingenieurs, EAWAG: Swiss Federal Institute of Aquatic Science and Technology, EMPA: Swiss Federal Laboratories for Materials Science and Technology, EPFL: Ecole Polytechnique de Lausanne, ETHZ: ETH Zurich, HSLU: Lucerne University of Applied Sciences and Arts, FNHW: University of Applied Sciences and Arts Northwestern Switzerland, HEIG-VD: Haute Ecole d'Ingénierie et de Gestion du Canton de Vaud, OST: Eastern Switzerland University of Applied Sciences, UNIGE: Université de Genève).

**SCCER EIP – Swiss Competence Center for Research in Energy, Efficiency of Industrial Processes (InnoSuisse, Swiss Innovation Agency, 2013-2020)** [www.sccer-eip.ch](http://www.sccer-eip.ch/)

**Project Key information and output**

**Motivation and objectives:** The SCCER EIP project, with 9 Swiss research institutions, developed the science and technology that allows Swiss industry to transition to sustainable use of energy in its processes, reduce greenhouse gases, and ensure that the target of 14 TWh energy consumption reduction until 2050 is achieved while keeping the impacts on the economics of the corresponding processes to a minimum.

**Total Budget:** > 34 Mio. CHF

**Partners:** ETHZ, EPFL, EAWAG, EMPA, HSLU, OST, FNHW, UNIGE **Key results:** Development of HTHP in laboratory-scale, test rigs are available at OST laboratory for further investigation of this technology, analysis of steam generation cycles using renewable energy, and investigation of electricity savings in refrigeration systems.

**Output:** Experience in market analysis of HTHP systems, state-of-the-art in HTHP research, review papers, application case studies of industrial heat pumps, deep knowledge of the HTHP technology, and economic analysis.

**IEA HPT TCP Annex 48 – Industrial Heat Pumps (Second Phase) (2017-2019)**

ARAMIS<sup>36</sup> Project No. SI/501782

[www.heatpumpingtech](http://www.heatpumpingtechnologies.org/annex48) [nologies.org/annex48](http://www.heatpumpingtechnologies.org/annex48) and

[www.waermepumpe-](file:///C:/Users/cordin.arpagaus/AppData/Local/Microsoft/Windows/INetCache/Content.Outlook/MJCOCUE3/www.waermepumpe-izw.de)

**Motivation and objectives:** The main goal was to overcome existing barriers to introducing industrial heat pumps to the larger scale market. Member countries participating and sharing knowledge were Germany (Operating Agent), Austria, Denmark, France, Japan, Switzerland, and the UK.

**Partners:** EPFL, OST.

**Key results:** Analysis and documentation of successful applications, case studies of industrial heat pumps, models for integrating heat pumps into processes, country-specific market overviews, and a white paper on the decarbonization of industrial heat by heat pumps.

**Output:** Collection and experience of 25 case studies of industrial heat pumps in Switzerland, knowledge sharing in analysis and comparison of the different

<sup>35</sup> <https://www.aramis.admin.ch/>

<sup>36</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=41721>

| izw.de                | HP integration concepts, and international network of heat pump technologies. |
|-----------------------|-------------------------------------------------------------------------------|
| Methods for           | Motivation and objectives: This project explored new horizons for industrial  |
| developing integrated | heat pumps in industry and the participation in IEA Annex 48 regarding        |
| industrial heat pump  | industrial HPs on behalf of Switzerland. In collaboration with SCCER-EIP, the |
| systems considering   | goal was to develop new methods to improve industrial energy efficiency and   |
| existing and novel    | mitigate CO2<br>emissions by properly integrating industrial HPs and          |
| components, SFOE,     | investigating the role of industrial heat towards the goals of the energy     |
| 2016-2019)            | transition 2050.                                                              |
| ARAMIS37 Project No.  | Total budget: 150 kCHF                                                        |
| SI/501487             | Partners: EPFL                                                                |
| Report                | Key results: Innovative concepts of industrial HPs considering progress in    |
| Refrigerant Selection | working fluids, heat exchange, multistage systems, compression and            |
| Tool                  | expansion technologies using optimization methods and process integration     |
|                       | techniques.                                                                   |
|                       | Output: Methods for correctly placing heat pumps following a set of energetic |
|                       | principles based on Pinch Analysis methodology, saving potentials through     |
|                       | heat recovery and HP integration in various Swiss industrial sectors, and web |
|                       | based refrigeration selection tool.                                           |
| SGHP – Steam          | Motivation and objectives: This national project develops a two-stage         |
| generating heat pump  | steam-generating heat pump (SGHP) system with open steam turbo                |
| (InnoSuisse, 2020-    | compressor at the high stage. The major aim is the proof of technology for    |
| 2023)                 | efficient steam generation from waste heat using a low-charge heat pump with  |
|                       | hydrocarbon refrigerant and a mechanical vapor recompression unit with a      |
|                       | direct drive oil-free turbo compressor.                                       |
|                       | Partners: OST, EPFL                                                           |
|                       | Key results: A 100 kW SGHP prototype capable of operating up to 150 °C        |
|                       | Output: Proof of technology and experience in the design and technology       |
|                       | development of steam-generating heat pumps, deep knowledge of research        |
|                       | status on SGHP technologies.                                                  |
| SWEET DeCarbCH –      | Motivation and objectives: The SWEET DeCarbCH project addresses the           |
| Decarbonization of    | colossal challenge of decarbonizing heating and cooling in Switzerland within |
| Cooling and Heating   | three decades and prepares the grounds for negative CO2<br>emissions. 16      |
| in Switzerland (SFOE, | Swiss research institutions and 50+ industrial partners are participating. A  |
| 2021-2028)            | major objective of the project is the combination of renewables, heat         |
| ARAMIS38 Project No.  | transformation, and storage for medium (80 to 200 °C) and high-temperature    |
| SI/502260             | heating (>200 °C) as well as cooling.                                         |
| www.sweet-decarb.ch   | Total Budget: >16 Mio. CHF                                                    |
|                       | Partners: UNIGE, ETHZ, OST, HSLU, ZHAW, EMPA, Industrial partners             |
|                       | Key results: System solutions for integrating renewables to deliver medium    |
|                       | and high-temperature heat, increasing the share of renewable energy sources   |
|                       | in existing solutions with digitalization approaches, and determining optimal |
|                       | integration levels.                                                           |
|                       | Output: Deep knowledge of the medium and high-temperature renewable           |
|                       | heat, demonstration of heating technologies on the system level, experience   |
|                       | evaluating the potential of negative emission technologies, and extended      |
|                       | experience in knowledge and technology transfer (KTT).                        |
| IntSGHP – Integration | Motivation and objectives: This Swiss national project will investigate three |
| of steam-generating   | specific case studies and analyze possible system integration of open and     |
| heat pumps in         | closed-cycle SGHPs. The aim is to fill the gap between the process            |
| industrial sites      | integration analysis and implementation. The findings (control approach,      |
| (retrofit)            | storage, cost of equipment and integration, etc.) will derive guidelines      |
| (SFOE, 2021-2023)     | applicable to many industrial sites in Switzerland and Europe.                |
| ARAMIS39 Project No.  | Total budget: 120 kCHF                                                        |
| SI/502292             | Partners: OST, Industrial partners                                            |

**Key results:** Guideline with recommendations for retrofitting and integrating SGHPs, techno-economic comparison to current steam-generating systems

<sup>37</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=38624>

<sup>38</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=48859>

<sup>39</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=49319>

(e.g., gas boiler), simulation model capable of doing a time-step analysis on these processes including integration of auxiliaries, storages, open and closed cycle SGHPs, and controls.

**Output:** Experience in planning a demonstration project (P+D) and implementing SGHPs into industrial sites.

**Case studies of industrial and hightemperature heat pumps (Swiss Federal Office** 

**of Energy, 2018-2022)**

**Motivation and objectives:** This project investigates the technical and economic feasibility of heat pump integrations in the Swiss industry and thermal grids. They are matchmaking with manufacturers, distributors, contractors, etc. Results are usually confidential.

**Partners:** OST, Industrial partners

**Key results:** Direct collaboration and financing with various industries. In some cases, OST received a mandate from the SFOE to investigate heat pump integration, which can be published.

**Output:** Experience in planning and integration of HTHP into industrial sites.

**High-efficiency hightemperature heat pumps with temperature glide (Bridge Discovery, SNF, Swiss National Science Foundation, 2022-2025)** SNF description<sup>40</sup>

**Motivation and objectives:** This project investigates high-efficiency industrial HTHPs with temperature glide. Refrigerant mixtures will be optimized for typical industrial applications by an integrated refrigerant and process design framework. An experimental high-temperature test stand and a heat pump breadboard system will be developed to enable validation and demonstration.

**Total Budget:** 1.5 Mio. CHF

**Partners:** ETHZ, OST, Industrial partners

**Key results:** Optimized refrigerants for temperature glides, high-temperature test stand (200 kW, 250 °C), and HTHP demonstrator.

(Grant number 203645) **Output:** Experience in handling refrigerant mixtures for HTHPs.

**DeCarb-PUI – Decarbonization of industrial processes through redesign of the process-utility interface, SFOE, P+D project, 2021-2024)** ARAMIS<sup>41</sup> Project No. SI/502298

**Motivation and objectives:** The overall aim of DeCarb-PUI is to decrease the exergy losses of the process-utility interface and consequently lower the exergy required for heating and cooling in process industries (e.g., steam systems). Case studies from the food and beverage sector are used to extend existing graphical tools and methods for heat integration and demonstrate the decarbonization potential thanks to larger heat recovery, enhanced efficiency, and profitability of heat upgrading technologies (heat pumps) and renewable resources.

**Total Budget:** 230 kCHF

**Partners:** HEIG-VD, HSLU, Industrial partners

**Key results:** Demonstrating the improvement potentials (energy efficiency and decarbonization) when considering actual process requirements over the existing situation, demonstrating total cost reductions (CAPEX & OPEX of processes and utilities), elaborating practical guidelines and training material for industries and manufacturers.

**Output:** Quantitative benefits (energy, CO<sup>2</sup> emissions, costs) over the stateof-the-art, a solution-focused collaboration between manufacturers and process industry partners, a practice-relevant methodology (graphical tools, e.g., GCC, methods, workflow), demonstration of case studies, increased awareness of all stakeholders.

**HTHP-CH – Integration of HTHPs in Swiss Industrial Processes (2021- 2025)**

ARAMIS<sup>42</sup> Project No. SI/502336

[www.heatpumpingtech](http://www.heatpumpingtechnologies.org/annex58) [nologies.org/annex58](http://www.heatpumpingtechnologies.org/annex58)

**Motivation and objectives:** This project develops a guide and an assessment tool for integrating HTHPs in practice based on highly relevant case studies for the Swiss industry. The focus is on processes with energy demand above 100 °C in batch and continuous operation. Examples are drying, evaporation, sterilization, etc. Suitable HTHP integration concepts will be developed with quantified results regarding efficiency gains, CO2 emission reduction potentials, and cost efficiency. In parallel, the project will be accompanied by participating in the IEA HPT TCP Annex 58 on HTHPs to share results and knowledge with a group of international domain experts. Member countries participating and sharing knowledge (as of October 2021) are Denmark (Operating Agent), Austria, Belgium, Canada, France, Germany, Norway, Finland, Japan, China, the USA, and Switzerland.

<sup>40</sup> <https://data.snf.ch/grants/grant/203645>

<sup>41</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=49367>

<sup>42</sup> <https://www.aramis.admin.ch/Grunddaten/?ProjectID=49514>

**Total budget:** 265 kCHF

**Partners:** OST, HEIG-VD, EPFL, CSD, Industrial partners

**Key results:** State-of-the-art HTHP technologies and ongoing developments for systems and components, strategies for converting to HTHP-based process heat supply, definition, and specifications for testing HTHPs.

**Output:** Participation in the Annex project, extending international network on HTHP technologies, deep knowledge of commercially available HTHP technologies, and manufacturers ready for demonstration and research status.

## <span id="page-159-0"></span>**4.13.7. Development perspectives for HTHP technologies in Switzerland**

Switzerland's development perspectives for HTHP technologies are difficult to describe, as Switzerland is rather not a country producing and processing heat pump components. No specific targets are defined by a national institution, e.g., the number of HTHP installations, targeted installed capacity, or the number of technology providers.

The development perspectives relate to pilot and demonstration (P+D) projects and technology development. P+D projects act as an interface between research and the marketplace and promote the development and testing of new technologies [\(Figure 4-78\)](#page-159-1). It is envisioned that some P+D projects on HTHP technology will be funded in the next 5 years, especially for heat pumps that produce steam.

![](_page_159_Figure_7.jpeg)

*Figure 4-78: Characteristics of Pilot and Demonstration projects between research and market* [135]

<span id="page-159-1"></span>In addition, there is a need for case study analysis and techno-economic evaluation of HTHP integration, which will bring progress for HTHP integrations. The results of the case studies will be shared at international conferences and through the IEA Annex 58 project. Another topic is business models for the energy sector, which uses heat as a service. This energy contracting is a new sector for energy service companies.

An acceleration and control instrument for the decarbonization of the Swiss industry is the CO<sup>2</sup> tax on fossil fuels (e.g., heating oil and natural gas), which will be gradually increased over time and will be 120 CHF/tCO<sup>2</sup> from 2022 [136], which is relatively high compared to other European countries.

Finally, [Figure 4-79](#page-160-0) shows that the average ratio of electricity to gas prices for industrial companies in Switzerland is about 2.4, making electrically driven heat pumps relatively attractive compared to gasfired boilers.

![](_page_160_Figure_0.jpeg)

<span id="page-160-0"></span>*Figure 4-79: Electricity and gas prices for industrial companies in Switzerland (Data: Swiss Federal Statistical Office).*

## <span id="page-161-0"></span>5. Technology development and deployment perspectives

High-temperature heat pumps (HTHP) can provide industrial process heating based on potentially emission-free electricity at highest efficiencies, making it the most promising technology for decarbonizing various industrial process heating applications. Multiple studies, such as the Net-Zero by 2050 Roadmap from the International Energy Agency [29], have confirmed the technology's potential and suggest a wide-scale deployment of industrial heat pumps at an unprecedented speed and scale for reaching greenhouse gas reduction targets by 2030.

Most of the application potential lies in the temperature range between 100 °C and 200 °C. For this temperature range, there are only a few commercially available HTHP technologies, while research, development and demonstration activities are ongoing.

To exploit the full potential of the HTHP technology, it is required that the various involved stakeholders, such as technology providers, end-users, R&D organizations, policymakers, investors and more, have a common understanding of the technology, its potential and its perspectives.

This chapter presents an overview of the HTHP technology's technical development perspectives, which is currently expected based on the information gathered within IEA HPT Annex 58. It may be noted that the presented forecast is based on ongoing R&D partnerships for the HTHP technology development and demonstration, possibilities from technology providers to develop HTHP technologies and scale productions, and the ambitions of end-users under the given boundary conditions. Changing any of these factors may impact the overall development accordingly and result in accelerated or delayed action compared to the forecast. The second part of the chapter discusses the possible impact of these factors on the development and deployment of the HTHP technology.

## <span id="page-161-1"></span>5.1. Technology development perspectives of high-temperature heat pumps

Chapter 4 provided a comprehensive overview of the various developments for HTHP technologies and the development perspectives on a national level. **Error! Reference source not found.** summarizes these developments for the HTHP technology development, demonstration, and deployment in industries towards 2030.

![](_page_161_Figure_7.jpeg)

Figure 5-1: Overview of the technology development perspectives for high-temperature heat pumps towards 2030 based on the insights from Annex 58 (Source: DTI)

## • HTHPs for heat supply at **up to 120 °C** and **200 kW to 10 MW**:

This category is dominated by technologies based on commercial and industrial refrigeration technologies, which have been slightly modified and optimized for higher temperatures. Wellproven technologies, e.g., ammonia heat pumps for district heating, are available, with supply temperatures of up to around 95 °C. In comparison, various developments were ongoing for the temperature range of up to 120 °C. In 2022 and 2023, few commercial products were available, while multiple prototypes of new technologies were being demonstrated in full-scale industrial applications, often as part of publicly funded R&D projects. These demonstration activities resulted in several commercially available technologies, which will be implemented in commercial projects in the coming years. HTHPs are expected to be the preferred process heating technology by 2025 to 2026 for a wide range of applications and industries. Currently, available technologies are largely based on synthetic HFO refrigerants, while most suppliers are working on natural refrigerant-based solutions as supplements or replacements.

## • HTHPs for heat supply at **120 °C to 160 °C** and **200 kW to 10 MW**:

The technologies being developed for this category are largely based on the same technologies from commercial and industrial refrigeration technologies but required more thorough modifications and optimizations to be suitable for higher temperatures. Additionally, novel technologies are being developed, such as compressors based on truck engines or turbochargers. Many of these technologies will be tested as prototypes by 2023, while largescale demonstrations at temperatures of up to 160 °C in industrial environments are expected for 2024 to 2025. This will result in a variety of HTHP technologies becoming commercially available during 2025 and a subsequent roll-out of these technologies in commercial projects. During these projects, further activities will be continued to increase the range of applications to other processes, improve performance, reduce investment costs, and standardize the solutions. At temperatures of up to 160 °C, there is a clear market pull from industrial end-users. More and more industrial end-users consider heat pumps for these temperature ranges a key technology for decarbonizing the process heating demands. This can be noticed in the development of HTHP technologies, which have been accelerated in recent years.

## • HTHPs for heat supply at **above 160 °C** and **200 kW to 10 MW**:

For higher temperatures, the business case becomes more challenging, and the maturity of technologies is lower. Two main technology developments are ongoing: steam compressors and sterling heat pumps. Steam compressors are of various types, including turbo compressors, rotary vane compressors, piston compressors, screw compressors and spindle compressors. Most of them are in a prototype stage during 2023, and full-scale demonstrations are expected from 2024 to 2025. Some steam compressors are already at a higher development stage and commercially available but are currently working on optimizing cost and performance. Two sterling heat pump manufacturers have already demonstrated their technologies in industrial applications by 2023, while the development focuses on optimizing cost and performance. Depending on the market development and the pull from industrial end-users, it is expected that there will be various products entering the market from 2026 to 2028.

#### • HTHPs for heat supply at **up to 120 °C** and **above 10 MW**:

For applications above 10 MW, various advanced technologies from process gas compression are being adopted for heat pump applications. These technologies are typically large turbo compressors designed on an application-specific basis. These technologies are based on an economy of scale, as is known from power plants or larger process plants. This means that the specific cost is becoming comparably high for capacities below around 10 MW, while it is becoming more competitive for larger capacities. The turbo compressors from process gas compression are advanced technologies generally suitable for more challenging conditions as required by HTHP applications. This makes the suppliers confident enough to offer the systems commercially without full-scale demonstrations in industrial applications. However, some suppliers are involved in prototype demonstrations on a smaller scale and first commercial installations by 2023. Full-scale demonstrations are likely to be realized as mainly commercial projects, thereby strongly dependent on the investment decisions of industrial end-users and the economical boundary conditions for the end-users. This makes it challenging to estimate a specific timespan. Still, considering the currently shared information, these HTHPs are expected to become the preferred process heating technology from 2025 and onwards, resulting in

several commercial systems. Also, in this category, it can be noted that most suppliers are working on establishing a natural refrigerant-based solution as a supplement or replacement for synthetic refrigerants.

## • HTHPs for heat supply at **above 120 °C** and **above 10 MW**:

The HTHP technologies for the temperature range above 120 °C are also based on turbo compressors from process gas compression applications, while the preferred refrigerant for applications above 120 °C is steam (R-718). There is a number of suppliers on the market offering steam compressors for supply temperatures well above 200 °C. At the same time, it may be noted that they have not yet been demonstrated in industrial HTHP applications. The demonstration in industrial applications is similarly dependent on the investment decision of industrial end-users and, accordingly, underlying the discussed uncertainties. However, it may be expected that the first large-scale demonstrations will be commissioned in 2025, starting in the lower temperature range and advancing to higher temperatures in the coming years.

Irrespective of the temperature and the heating capacity, it may be noted that HTHPs can be integrated at different levels of integration. For integrations on a unit level, e.g., a close integration in a drying process, there is often a process equipment manufacturer, e.g., for drying equipment, involved. Process equipment manufacturers are a valuable part of the supply chain, as they have in-depth knowledge about the processes and the possibilities to optimize them for heat pump-based process heat supply. They may accelerate the uptake of heat pumps in industries even more.

The presented forecast of HTHP technologies towards 2030 should be interpreted considering the following aspects:

- All information refers to the bulk of the developments based on a global industry picture. When stating that "Various HTHP technologies are commercially available," it refers to HTHP technologies that can be supplied at scale for a considerable market share based on an established network for sales, installation, service and maintenance. As presented in Chapter 2, some companies can be considered ahead of the bulk development.
- The technology readiness level (TRL) is not solely dependent on temperature and capacity but also on factors such as the temperature glide, efficiency, investment cost, location, support for service and maintenance and others. The variety of these underlines the need to consider the bulk development of the HTHP technology.
- The indicated temperatures are the maximum supply temperatures of the HTHP technologies, while the return temperature from the process is not considered. This can correspond to cases at which the entire heat is provided around the maximum temperature or to cases at which large temperature glides in the sink cause the average temperature to be considerably below the maximum supply temperature.
- The capacity of 10 MW thermal heat supply as the boundary between heat pumps based on industrial compressors and compressors from process gas compression is not a sharp boundary, but an indication. Compressors from industrial heat pump technologies can be built with a maximum heating capacity of around 5 MW to 10 MW on a single compressor. For larger capacities, it is common to install several compressors in parallel, as has been proven in district heating applications with capacities of up to 50 MW and beyond in some cases. Compressors from process gas compression have a relatively constant price, irrespective of the capacity, causing the specific investment cost to increase for smaller capacities and decrease for larger capacities. Experiences from district heating indicate the tipping point between 10 MW and 20 MW of heating capacity, while the exact business case is highly dependent on applicationspecific parameters.

#### <span id="page-163-0"></span>**5.2. Factors that are impacting the development perspectives towards market deployment**

The development of HTHPs towards market deployment depends not only on the technology development, but also on the adoption of end-users with respect to utilizing this new technology, as well as on the boundary conditions impacting the business case.

External boundary conditions, such as cost for fuels and greenhouse gas emissions, taxes, subsidies, and other market developments, impact the interests of end-users to tackle the conversion towards decarbonized process heating and thereby towards the implementation of HTHPs. The market deployment depends on the preparedness of industrial end-users for converting towards novel process heating equipment, which requires a shift of mindset for the design and operation of their processing plants to exploit the full potential.

However, these two factors depend on actual technological developments, making the aspects mutually interdependent. Industrial end-users will, for example, only prepare for implementing HTHPs, when they are aware of the technology's availability, its development perspectives, and possible benefits. HTHP technology suppliers will, on the other hand, only invest in developing new technologies and upscaling production capacities when they see a clear and direct market potential among the end-users.

The mutual interdependency of the various aspects makes it apparent that partnerships between stakeholders from different groups, e.g., HTHP technology suppliers, end-users, R&D organizations, consultants, and policymakers, are promising approaches for reducing uncertainties and overcoming barriers.

![](_page_164_Figure_3.jpeg)

*Figure 5-2: Schematic overview of the aspects impacting the technology development towards market deployment (Source: DTI)*

The presented HTHP technology development perspectives are based on the expectations from ongoing R&D activities from globally leading organizations. This makes it a relatively solid baseline for the minimum expected developments within the next years. Establishing boundary conditions that benefit electrification and energy efficiency enhances the market pull for HTHPs considerably, accelerating the development of HTHPs beyond the presented forecasts.

## <span id="page-165-0"></span>**6. References**

- [1] C. Arpagaus, F. Bless, M. Uhlmann, J. Schiffmann, and S. S. Bertsch, "High temperature heat pumps: Market overview, state of the art, research status, refrigerants, and application potentials," *Energy*, vol. 152, pp. 985–1010, Jun. 2018, doi: 10.1016/j.energy.2018.03.166.
- [2] A. Arnitz, R. Rieberer, and V. Wilk, "IEA HPT Annex 48: Second Phase. Task 4: Training materials for industrial heat pumps," *IEA HPT (Ed.), Austrian Report*, 2019. https://nachhaltigwirtschaften.at/de/iea/publikationen/iea-hpt-annex-48-industrial-heat-pumpsaustrian-report-task4-2019.php (accessed Nov. 26, 2021).
- [3] E. Klop, "Steaming ahead with MVR, Cogeneration & On-Site Power Production," 2015.
- [4] K. R. Solomon *et al.*, "Sources, fates, toxicity, and risks of trifluoroacetic acid and its salts: Relevance to substances regulated under the Montreal and Kyoto Protocols," *Journal of Toxicology and Environmental Health, Part B*, vol. 19, no. 7, pp. 289–304, Oct. 2016, doi: 10.1080/10937404.2016.1175981.
- [5] S. Wolf, U. Fahl, M. Blesl, A. Voß, and R. Jakobs, "Analyse des Potenzials von Industriewärmepumpen in Deutschland, Forschungsbericht," 2014.
- [6] R. and A.-C. E. American Society of Heating, *2020 ASHRAE Handbook—HVAC Systems and Equipment*. 2020.
- [7] A. Längauer, B. Adler, C. Rakusch, and K. Ponweiser, "COP tests of a Rotation Heat Pump," in *Proceedings of ICR 2019*,
- [8] M Popovac, M Lauermann, A Baumhakel, and G Drexler, . "Performance analysis of a hightemperature heat pump with ejector based on butane as the refrigerant," in *12th IEA Heat Pump Conference 2017*, Rotterdam, 2017.
- [9] B. Luo and P. Zou, "Performance analysis of different single stage advanced vapor compression cycles and refrigerants for high temperature heat pumps," *International Journal of Refrigeration*, vol. 104, pp. 246–258, Aug. 2019, doi: 10.1016/j.ijrefrig.2019.05.024.
- [10] T. Bai, G. Yan, and J. Yu, "Thermodynamic assessment of a condenser outlet split ejectorbased high temperature heat pump cycle using various low GWP refrigerants," *Energy*, vol. 179, pp. 850–862, Jul. 2019, doi: 10.1016/j.energy.2019.04.191.
- [11] C. Mateu-Royo, J. Navarro-Esbrí, A. Mota-Babiloni, and Á. Barragán-Cervera, "Theoretical performance evaluation of ejector and economizer with parallel compression configurations in high temperature heat pumps," *International Journal of Refrigeration*, vol. 119, pp. 356–365, Nov. 2020, doi: 10.1016/j.ijrefrig.2020.07.016.
- [12] C. Mateu-Royo, C. Arpagaus, A. Mota-Babiloni, J. Navarro-Esbrí, and S. S. Bertsch, "Advanced high temperature heat pump configurations using low GWP refrigerants for industrial waste heat recovery: A comprehensive study," *Energy Convers Manag*, vol. 229, p. 113752, Feb. 2021, doi: 10.1016/j.enconman.2020.113752.
- [13] J. M. S. Dias and V. A. F. Costa, "Adsorption heat pumps for heating applications: A review of current state, literature gaps and development challenges," *Renewable and Sustainable Energy Reviews*, vol. 98, pp. 317–327, Dec. 2018, doi: 10.1016/j.rser.2018.09.026.
- [14] EEA, "European Environment Agency (EEA)." https://www.eea.europa.eu/data-andmaps/indicators/overview-of-the-electricity-production-3/assessment (accessed Mar. 03, 2022).
- [15] J. M. Corberan *et al.*, "Strategic Research Priorities for Renewable Heating & Cooling Cross-Cutting Technology," 2012.
- [16] A. D. McNaught and A. Wilkinson, *The IUPAC Compendium of Chemical Terminology*. Research Triangle Park, NC: International Union of Pure and Applied Chemistry (IUPAC), 2019. doi: 10.1351/goldbook.
- [17] Z. Xu and R. Wang, "Absorption heat pump for waste heat reuse: current states and future development," *Frontiers in Energy*, vol. 11, no. 4, pp. 414–436, Dec. 2017, doi: 10.1007/s11708-017-0507-1.
- [18] M. Khamooshi, K. Parham, M. Yari, F. Egelioglu, H. Salati, and S. Babadi, "Thermodynamic Analysis and Optimization of a High Temperature Triple Absorption Heat Transformer," *The Scientific World Journal*, vol. 2014, pp. 1–10, 2014, doi: 10.1155/2014/980452.
- [19] K. Parham, M. Khamooshi, D. B. K. Tematio, M. Yari, and U. Atikol, "Absorption heat transformers – A comprehensive review," *Renewable and Sustainable Energy Reviews*, vol. 34, pp. 430–452, Jun. 2014, doi: 10.1016/j.rser.2014.03.036.
- [20] A. Kuehn, F. Ziegler, B. Dawoud, P. Schossig, J. Wienen, and R. Critoph, "Thermally driven heat pumps for heating and cooling," *Universitätsverlag der TU Berlin*, 2013.
- [21] D. B. Boman, A. W. Raymond, and S. Garimella, *Adsorption Heat Pumps*. Cham: Springer

- International Publishing, 2021. doi: 10.1007/978-3-030-72180-0.
- [22] F. Cudok *et al.*, "Absorption heat transformer state-of-the-art of industrial applications," *Renewable and Sustainable Energy Reviews*, vol. 141, p. 110757, May 2021, doi: 10.1016/j.rser.2021.110757.
- [23] J. K. Jensen, T. Ommen, L. Reinholdt, W. B. Markussen, and B. Elmegaard, "Heat pump COP, part 2: Generalized COP estimation of heat pump processes," *Refrig. Sci. Technol.* , vol. 2018- June, pp. 1255–1264, 2018, doi: 10.18462/iir.gl.2018.1386.
- [24] US Department of Energy, "Industrial Heat Pumps for Steam and Fuel Savings," 2003. Accessed: Mar. 15, 2023. [Online]. Available: https://www.energy.gov/sites/prod/files/2014/05/f15/heatpump.pdf
- [25] Y. Xu, J. Li, Q. Ye, and Y. Li, "Design and optimization for the separation of tetrahydrofuran/isopropanol/water using heat pump assisted heat-integrated extractive distillation," *Sep Purif Technol*, vol. 277, p. 119498, Dec. 2021, doi: 10.1016/j.seppur.2021.119498.
- [26] A. Marina, S. Spoelstra, H. A. Zondag, and A. K. Wemmers, "An estimation of the European industrial heat pump market potential," *Renewable and Sustainable Energy Reviews*, vol. 139, p. 110545, Apr. 2021, doi: 10.1016/j.rser.2020.110545.
- [27] S. Wolf and M. Blesl, "Model-based quantification of the contribution of industrial heat pumps to the European climate change mitigation strategy," in *ECEEE Industrial Summer Study Proceedings*, 2016.
- [28] G. Kosmadakis, "Estimating the potential of industrial (high-temperature) heat pumps for exploiting waste heat in EU industries," *Appl Therm Eng*, vol. 156, pp. 287–298, Jun. 2019, doi: 10.1016/j.applthermaleng.2019.04.082.
- [29] IEA, "Net Zero by 2050," 2021. https://www.iea.org/reports/net-zero-by-2050 (accessed Mar. 15, 2023).
- [30] H. Jockenhöfer, W.-D. Steinmann, and D. Bauer, "Detailed numerical investigation of a pumped thermal energy storage with low temperature heat integration," *Energy*, vol. 145, pp. 665–676, Feb. 2018, doi: 10.1016/j.energy.2017.12.087.
- [31] F. Trebilcock, M. Ramirez, C. Pascual, T. Weller, S. Lecompte, and A. H. Hassan, "Development of a compressed heat energy storage system prototype.," in *IIR Rankine Conference 2020*, 2020. doi: 10.18462/iir.rankine.2020.1178.
- [32] HORIZON 2020, "G. Technology readiness levels (TRL)," *Extract from Part 19 - Commission Decision C*, 2014. https://ec.europa.eu/research/participants/data/ref/h2020/wp/2014\_2015/annexes/h2020 wp1415-annex-g-trl\_en.pdf (accessed May 02, 2023).
- [33] Annex 35, "Annex 35." 2014.
- [34] Annex 58, "Annex 58." 2022.
- [35] F. Schlosser, "Integration of heat pumps for decarbonisation of industrial heat supply (in German)," 2020.
- [36] Statistics Austria, "Useful energy analysis 1993-2020, Prepared on behalf of the Federal Ministry for Climate Protection, Environment, Energy, Mobility, Innovation and Technology," Dec. 10, 2021. http://www.statistik.at/web\_de/statistiken/energie\_umwelt\_innovation\_mobilitaet/energie\_und\_u mwelt/energie/nutzenergieanalyse/index.html (accessed Feb. 25, 2022).
- [37] Umweltbundesamt, "Berechnung von Treibhausgas (THG)-Emissionen verschiedener Energieträger (Calculation of greenhouse gas (GHG) emissions from various energy sources)," Nov. 2021. https://secure.umweltbundesamt.at/co2mon/co2mon.html (accessed Apr. 13, 2022).
- [38] Epexspot, "Epexspot," 2022. https://www.epexspot.com/en/marketdata?market\_area=AT&trading\_date=2022-02-25&delivery\_date=2022-02- 26&underlying\_year=&modality=Auction&sub\_modality=DayAhead&product=60&data\_mode=a ggregated&period= (accessed Feb. 25, 2022).
- [39] CEGH, "Central European Gas Hub AG," Feb. 2022. https://www.cegh.at/ (accessed Feb. 25, 2023).
- [40] EEX, "European Energy Exchange AG," 2022. https://www.eex.com/de/marktdaten/umweltprodukte/spotmarkt (accessed Feb. 25, 2022).
- [41] R. and T. Bundesministerium Nachhaltigkeit und Tourismus (Federal Ministry Republic of Austria. Agriculture, "Langfriststrategie 2050 - Österreich (Long-term strategy 2050 - Austria)," Vienna, 2019.
- [42] R. Geyer, S. Knöttner, C. Diendorfer, G. Drexler-Schmid, and IndustRiES, "Energieinfrastruktur

- für 100 % Erneuerbare Energie in der Industrie (IndustRiES. Energy infrastructure for 100% renewable energy in industry)," Vienna, 2019.
- [43] P. Biermayer et al., "Innovative Energietechnologien in Österreich Marktentwicklung 2020 (Innovative Energy Technologies in Austria Market Development 2020)," 2021.
- [44] M. Hartl, P. Biermay, A. Schneeberger, and P. Schöfmann, "Österreichische Technologie- und Umsetzungsroadmap für Wärmepumpen (Austrian technology and implementation roadmap for heat pumps)," 2016.
- [45] H. Moisi and R. Rieberer, "Experimental Analysis of a R600 High Temperature Heat Pump," in *Proceedings of the 13th IIR Gustav Lorentzen Conference*, Valencia, Spain, Jun. 2018.
- [46] M. Verdnik and R. Rieberer, "Influence of operating parameters on the COP of an R600 hightemperature heat pump," *International Journal of Refrigeration, submitted for publication*, 2022.
- [47] R. Rieberer, M. Verdnik, and A. Baumhakel, ""TransCrit" Final Project Report (FFG-Nr.: 865083)," Graz, 2021.
- [48] Varmepumpedata.dk, "Overview of installed heat pumps in Denmark," 2022. https://varmepumpedata.dk/ (accessed Feb. 22, 2022).
- [49] Klimarådet, "Kendte veje og nye spor til 70 procents reduktion retning og tiltag for de næste ti års klimaindsats i Danmark," 2020.
- [50] Danish Energy Agency, "Analysis of Green Industry," 2020. https://ens.dk/sites/ens.dk/files/Energibesparelser/groen\_industrianalyse.pdf (accessed Mar. 13, 2023).
- [51] E. Motiva Oy, "Ylijäämälämmön potentiaali teollisuudessa," 2019. https://www.motiva.fi/files/16214/Esiselvitys\_-\_Ylijaamalammon\_potentiaali\_teollisuudessa.pdf (accessed Apr. 14, 2023).
- [52] Statistics Finland's statistical databases, "Production of electricity and heat," 2023. https://pxdata.stat.fi/PxWeb/pxweb/en/StatFin/StatFin\_\_salatuo/ (accessed Apr. 14, 2023).
- [53] Japan Electro-Heat Center, "Survey report on industrial heat pump introduction," Oct. 2021.
- [54] Mitsubishi Research Institute, "Survey report on heat demand and heat supply equipment," Feb. 2018.
- [55] Japan Electro-Heat Center, "Industrial Heat Pump Utilization Guide," 2021.
- [56] T. Kaida, "High temperature heat pumps in Japan: Potential, development trends and case studies," in *Proceedings of 2nd Conference of High Temperature Heat Pumps*, Copenhagen, Denmark, Sep. 2019.
- [57] M. Ajima and M. Iwasaki, "Development status of waste heat recovery high temperature steam generation heat pump," *Electrical Review*, Mar. 2019.
- [58] Y. Onishi, T. Yoshida, M. Ajima, and M. Iwasaki, "Development of high temperature steam generating low GWP refrigerant 2 stage cycle heat pump utilizing thermal energy of waste hot water," in *Proceedings of 2018 JSRAE Annual Conference*, Koriyama, Japan, Sep. 2018.
- [59] H. Fuchikami, A. Machida, K. Ito, and N. Mugabi, "Development of a steam generation heat pump using a natural refrigerant," in *Proceedings of 2013 JSRAE Annual Conference*, Tokyo, Japan, Sep. 2013.
- [60] Mayekawa Mfg, "Development of industrial high temperature heat pump using low GWP refrigerant," in *ENEX2020*, Tokyo, Japan, Jan. 2020.
- [61] T. Kimura, H. Fuchikami, N. Yoshihiro, M. Kudo, and A. Machida, "Development of a high temperature heat pump using reusable heat as the heat source," in *Proceedings of JRAIA International Conference 2021*, Oct. 2021.
- [62] R. Suemitsu *et al.*, "Research and development for 200°C compressed water heat pump using exhaust heat with low GWP refrigerant for industrial use," in *Proceedings of 13th IEA Heat Pump Conference*, Jeju, Korea, Apr. 2021.
- [63] C. Kondou and S. Koyama, "Thermodynamic assessment of high-temperature heat pumps using low-GWP HFO refrigerants for heat recovery," *International Journal of Refrigeration, Vol. 53, 126–141*, 2018.
- [64] Y. Hasegawa, R. Suemitsu, and H. Yuki, "Research and development for high temperature heat pump using exhaust heat for industrial use, Refrigeration," May 2021.
- [65] CBS.nl, "Centraal Bureau voor de Statistiek," 2022. https://www.cbs.nl/ (accessed Mar. 14, 2023).
- [66] Eurostat, "Energy Statistics prices of natural gas and electricity," 2020.
- [67] Rijksoverheid.nl, "CO2-heffing voor industrie | Milieubelastingen," 2022. https://www.rijksoverheid.nl/onderwerpen/milieubelastingen/co2-heffing-voor-industrie (accessed Mar. 14, 2023).
- [68] RVO.nl, "Demonstratie Energie- en Klimaatinnovatie (DEI+) aanvragen," 2022.

- https://www.rvo.nl/subsidie-en-financieringswijzer/demonstratie-energie-en-klimaatinnovatie-dei (accessed Mar. 14, 2023).
- [69] RVO.nl, "Stimulating Sustainable Energy Production and Climate Transition (SDE++) ," 2022. https://www.rvo.nl/subsidie-en-financieringswijzer/sde (accessed Mar. 14, 2023).
- [70] A. Marina, "High Temperature Heat Pumps in Dutch Industry: Market Potential and Challenges in Implementation," in *International Workshop on High Temperature Heat Pumps*, Copenhagen, 2017.
- [71] topsectorenergie.nl, "Routekaart Elektrificatie in de Industrie.pdf," 2022. https://www.topsectorenergie.nl/sites/default/files/uploads/TKI%20Energie%20%26%20Industri e/Documenten/Routekaart%20Elektrificatie%20in%20de%20Industrie.pdf (accessed Mar. 14, 2023).
- [72] A. K. Wemmers, T. van Hassteren, and P. K. J. van der Kremers, "Test results R600 pilot heat pump," in *12th IEA heat pump conference*, 2017.
- [73] A. Marina, S. F. Smeding, A. K. Wemmers, S. Spoelstra, and P. Kremers, "Design and Experimental Results of a Two-Stage Steam Producing Industrial Heat Pump," in *13th IEA Heat Pump Conference*, Jeju, South Korea, 2020.
- [74] Hybridenergy.no, "Hybridenergy," 2022. https://www.hybridenergy.no/ (accessed Feb. 04, 2022).
- [75] Enerin.no, "HoegTemp ultra high temperature heat pumps," 2022. https://www.enerin.no/hoegtemp (accessed Feb. 04, 2022).
- [76] Olvondo Technology, "Olvondo Technology," 2022. https://www.olvondotech.no/ (accessed Feb. 04, 2022).
- [77] R. Myrvang, "High-temperature heat pump based on Stirling Cycle," *Presentation May 2021, Annex 58 – HTHP*. May 2021.
- [78] Tocircle.com, "ToCircle Industries," 2022, Accessed: Feb. 04, 2022. [Online]. Available: https://tocircle.com/box/technology
- [79] Epcon.org, "Epcon Evaporation Technology," 2022. https://www.epcon.org/ (accessed Feb. 04, 2022).
- [80] Valinor.no, "Valinor Heaten," 2022. https://valinor.no/investments/heaten/ (accessed Feb. 04, 2022).
- [81] Heaten.com, "Heaten HeatBooster," 2022, Accessed: Feb. 04, 2022. [Online]. Available: https://www.heaten.com/
- [82] Oslo Economics and Asplan Viak, "Kartlegging og vurdering av potensial for effektivisering av oppvarming og kjøling i Norge," 2020.
- [83] NVE.no, "Nve kraftproduksjon," 2022. https://www.nve.no/energi/energisystem/kraftproduksjon/ (accessed Feb. 04, 2022).
- [84] Statnett.no, "Statnett det eksepsjonelle kraftåret 2021," 2021. https://www.statnett.no/omstatnett/nyheter-og-pressemeldinger/nyhetsarkiv-2022/det-eksepsjonelle-kraftaret-2021/ (accessed Feb. 04, 2022).
- [85] S. Moe and H. Laird, "Energiintensiv industri En beskrivelse og økonomisk analyse av energiintensiv industri i Norge," 2013.
- [86] A. Sevault, O. L. Tranås, and M. J. Mazzetti, "Industrial Excess Heat Recovery Status of the Norwegian Industry," *Report within the framework of SINTEF's participation in IEA IETS Annex XV*, no. 2018:00856, 2018.
- [87] M. U. Ahrens, S. S. Foslie, O. M. Moen, M. Bantle, and T. M. Eikevik, "Integrated high temperature heat pumps and thermal storage tanks for combined heating and cooling in the industry," *Appl Therm Eng*, vol. 189, p. 116731, May 2021, doi: 10.1016/j.applthermaleng.2021.116731.
- [88] M. Lauermann, "Feasibility study on high temperature heat pump with heat sink at 200°C. Identification of working fluid, technology readiness levels and system availability," Dec. 2017.
- [89] M. Bantle, C. Schlemminger, and I. Tolstorebrov, "Performance evaluation of two stage mechanical vapour recompression with turbo-compressors," *International Institute of Refrigeration*, Jun. 2018, doi: 10.18462/iir.gl.2018.1157.
- [90] Sintef.no, "SINTEF HeatUp project," 2022. https://www.sintef.no/projectweb/heatup/ (accessed Feb. 04, 2022).
- [91] O. Bamigbetan, T. M. Eikevik, P. Nekså, M. Bantle, and C. Schlemminger, "Experimental investigation of the Performance of a hydrocarbon heat pump for high temperature industrial heating," *International Institute of Refrigeration*, Jun. 2018.
- [92] Sintef.no, "SINTEF Free2Heat project," 2022, Accessed: Feb. 04, 2022. [Online]. Available: https://www.sintef.no/en/projects/2019/free2heat/

- [93] Sintef.no, "FME HighEFF," 2022. https://www.sintef.no/projectweb/higheff/ (accessed Feb. 04, 2022).
- [94] Friotherm.com, "Friotherm | Unitop," 2022.
- [95] MAN-ES.com, "Man Heat Pumps," 2022. https://www.man-es.com/docs/default-source/energystorage/man-heat-pump.pdf (accessed Mar. 14, 2023).
- [96] MAN-ES.com, "MAN ETES," 2022.
- [97] MAN-ES.com, "MAN ETES Esbjerg," 2022, Accessed: Mar. 14, 2023. [Online]. Available: https://www.man-es.com/docs/default-source/press-releases-new/20210921\_man-es-pr-etesesbjerg-visit\_eng.pdf
- [98] Engie-Refrigeration.de, "CO2 Hochtemperaturwarmepumpen," 2022. https://www.engierefrigeration.de/de/waerme/thermeco2-hochtemperaturwaermepumpen (accessed Mar. 14, 2023).
- [99] C. Arpagaus, "From Waste heat to Cheese," *HPT Magazine*, vol. 37, no. 2, 2019, Accessed: Mar. 14, 2023. [Online]. Available: https://heatpumpingtechnologies.org/publications/fromwaste-heat-to-cheese
- [100] Ochsner-Energietechnik.com, "Referenzen," 2022. https://ochsnerenergietechnik.com/referenzen (accessed Mar. 14, 2023).
- [101] Ochsner-Energietechnik.com, "Warmepumpen für Grosse Leistungen," 2022. https://www.ochsner.com/de-ch/ochsner-produkte/waermepumpen-fuer-grosse-leistungen (accessed Mar. 14, 2023).
- [102] C. Arpagaus and S. Bertsch, "Industrial Heat Pumps in Switzerland, Application Potentials and Case Studies," 2020. Accessed: Mar. 14, 2023. [Online]. Available: https://www.aramis.admin.ch/Default?DocumentID=66033
- [103] Suisseenergie.ch, "Nettoyage climatiquement neutre d'une embouteilleuse grâce à une pompe à chaleur," 2022. https://www.suisseenergie.ch/stories/pompe-a-chaleur-industrielle/ (accessed Mar. 14, 2023).
- [104] EWZ.ch, "EWZ," 2022. https://www.ewz.ch/ (accessed Mar. 14, 2023).
- [105] Seitz et al., "High-Temperature Heat Pump for Wellness Applications using CO2 as a refrigerant," in *17th International Refrigeration and Air Conditioning Conference at Purdue*, Jul. 2018. Accessed: Mar. 15, 2023. [Online]. Available: https://docs.lib.purdue.edu/iracc/1933
- [106] Scheco.ch, "Scheco," 2022. https://www.scheco.ch/referenzen/alle (accessed Mar. 15, 2023).
- [107] C. Arpagaus, "Swiss National Market, Event on High-Temperature Heat Pumps," Mar. 24, 2023. https://www.sweetdecarb.ch/fileadmin/downloads/Presentations\_File/03\_Swiss\_National\_Market\_Cordin\_Arpaga us.pdf (accessed May 25, 2023).
- [108] WWAG.de, "WWAG.de," 2022. https://www.wwag.ch/de/Kompetenzen/Waermepumpen (accessed Mar. 15, 2023).
- [109] CEES.ch, "CEES.ch," 2022, Accessed: Mar. 15, 2023. [Online]. Available: https://www.cees.ch/fr-fr/accueil/retrospectives/conference-energie-ccf-et-pac,-un-couple-idealpour-le-chauffage-a-distance-a-bulle.html
- [110] Swisspower.ch, "Swisspower.ch," 2022, Accessed: Mar. 15, 2023. [Online]. Available: https://swisspower.ch/content/files/publications/Medienspiegel/HK-Gebaeudetechnik-8- 18\_EWS-S52-56\_WKK-Forum-2018\_MSt\_v99.pdf
- [111] AquaSwiss.eu, "AquaSwiss.eu," 2022. http://aquaswiss.eu/desalination-solutions/mechanicalvapor-compression (accessed Mar. 15, 2023).
- [112] Salz.ch, "Salz.ch," 2022. https://www.salz.ch/fr/decouvrir-le-sel/mines-de-sel-de-bex/proposdes-mines-de-sel/notre-histoire (accessed Mar. 15, 2023).
- [113] Saline.ch, "Saline.ch," 2022. https://www.saline.ch/fr/saline-de-bex (accessed Mar. 15, 2023).
- [114] Clubjurassien.ch, "Clubjurassien.ch," 2022. http://www.clubjurassien.ch/archivePDF/1339880218.pdf (accessed Mar. 15, 2023).
- [115] M. Zogg, "History of Heat Pumps Swiss Contributions and International Milestones," 2008. Accessed: Mar. 15, 2023. [Online]. Available: https://www.aramis.admin.ch/Default?DocumentID=68224
- [116] FWS.ch, "FWS.ch," 2022. https://www.fws.ch/wp-content/uploads/2022/02/FWS-Statistiken-2021-1.pdf (accessed Mar. 15, 2023).
- [117] S. Wolf, R. Flatau, P. Radgen, and M. Blesl, "Systematische Anwendung von Großwärmepumpen in der Schweizer Industrie," May 2017. Accessed: Mar. 15, 2023. [Online]. Available: https://www.bfe.admin.ch/bfe/de/home/news-undmedien/publikationen.exturl.html/aHR0cHM6Ly9wdWJkYi5iZmUuYWRtaW4uY2gvZGUvcHVib GljYX/Rpb24vZG93bmxvYWQvODY3Ng==.html

- [118] S. Wolf, R. Flatau, and P. Radgen, "Rahmenbedingungen für die Anwendung von Großwärmepumpen in der Schweizer Industrie," Jun. 2017. Accessed: Mar. 15, 2023. [Online]. Available: https://www.bfe.admin.ch/bfe/de/home/news-undmedien/publikationen.exturl.html/aHR0cHM6Ly9wdWJkYi5iZmUuYWRtaW4uY2gvZGUvcHVib GljYX/Rpb24vZG93bmxvYWQvODY3OQ==.html
- [119] SFOE, "Analysis of energy consumption by specific use, 2000 2018," 2022. https://www.bfe.admin.ch/bfe/en/home/supply/statistics-and-geodata/energy-statistics/analysisof-energy-consumption-by-specific-use.html (accessed Mar. 15, 2023).
- [120] T. Fleiter *et al.*, "Profile of Heating and Cooling Demand in 2015," 2017. Accessed: Mar. 15, 2023. [Online]. Available: https://heatroadmap.eu/wp-content/uploads/2018/11/HRE4\_D3.1.pdf
- [121] N. Calame-Darbellay, F. Rognon, and O. Sari, "High temperature heat pumps for industrial processes - State of the art and research needs," in *Conference: 23. Tagung des BFE-Forschungsprogramms «Wärmepumpen und Kälte»*, Burgdorf, Switzerland, 2017.
- [122] Wallerand et al., "Integrated industrial heat pump systems Background, software development & Swiss potentials," Bern, 2020.
- [123] Arpagaus et al., "Potential Impact of Industrial High-Temperature Heat Pumps on the European Market," Copenhagen, Denmark, Mar. 2022. Accessed: Mar. 15, 2023. [Online]. Available: https://hthp-symposium.org
- [124] M. J. S. Zuberi, F. Bless, J. Chambers, C. Arpagaus, S. S. Bertsch, and M. K. Patel, "Excess heat recovery: An invisible energy resource for the Swiss industry sector," *Appl Energy*, vol. 228, pp. 390–408, Oct. 2018, doi: 10.1016/j.apenergy.2018.06.070.
- [125] Zuberi et al., "Decarbonizing Swiss industrial sectors by process integration, electrification, and traditional energy efficiency measures," in *Eceee Industrial Summer Study ProceedingsEceee Industrial Summer Study Proceedings*, Sep. 2020. Accessed: Mar. 15, 2023. [Online]. Available: https://www.eceee.org/library/conference\_proceedings/eceee\_Industrial\_Summer\_Study/2020/ 4-technology-products-and-systems/decarbonizing-swiss-industrial-sectors-by-processintegration-electrification-and-traditional-energy-efficiency-measures/
- [126] F. Bless, C. Arpagaus, S. S. Bertsch, and J. Schiffmann, "Theoretical analysis of steam generation methods - Energy, CO 2 emission, and cost analysis," *Energy*, vol. 129, pp. 114– 121, Jun. 2017, doi: 10.1016/j.energy.2017.04.088.
- [127] SFOE, "P&D PRogramme," 2022. https://www.bfe.admin.ch/bfe/en/home/research-andcleantech/pilot-and-demonstration-programme.html (accessed Mar. 15, 2023).
- [128] SFOE, "Heat Pumps and Refrigeration," 2022. https://www.bfe.admin.ch/bfe/en/home/research-and-cleantech/research-programmes/heatpumps-and-refrigeration.html (accessed Mar. 15, 2023).
- [129] SFOE, "Buildings and Cities," 2022. https://www.bfe.admin.ch/bfe/en/home/research-andcleantech/research-programmes/buildings-and-cities.html (accessed Mar. 15, 2023).
- [130] SFOE, "Buildings and Cities research programme List of projects funded in 2020," 2022. https://pubdb.bfe.admin.ch/de/publication/download/2966 (accessed Mar. 15, 2023).
- [131] Innosuisse, "Energy Funding Programme 2013-2020, Final Report," 2021. https://www.innosuisse.ch/dam/inno/en/dokumente/themenorientierteprogramme/Energie/finalreportsccer.pdf (accessed Mar. 15, 2023).
- [132] C. Arpagaus, *Hochtemperatur-Wärmepumpen: Marktübersicht, Stand der Technik und Anwendungspotenziale*. VDE-Verlag, 2019. Accessed: Mar. 15, 2023. [Online]. Available: https://www.vde-verlag.de/buecher/494550/hochtemperatur-waermepumpen.html
- [133] SFOE, "SWEET," 2021. https://www.bfe.admin.ch/bfe/en/home/research-andcleantech/funding-program-sweet/sweet-overview.html (accessed Mar. 15, 2023).
- [134] SWEET DeCarbCH, "SWEET DeCarbCH," 2022. https://www.sweet-decarb.ch/ (accessed Mar. 15, 2023).
- [135] SFOE, "Pilot and demonstration programme," 2022. https://www.bfe.admin.ch/bfe/en/home/research-and-cleantech/pilot-and-demonstrationprogramme.html (accessed Mar. 15, 2023).
- [136] FOEN, "CO2 Levy," 2022. https://www.bafu.admin.ch/bafu/en/home/topics/climate/infospecialists/reduction-measures/co2-levy.html (accessed Mar. 15, 2023).

![](_page_172_Picture_1.jpeg)

Heat Pump Centre c/o RISE - Research Institutes of Sweden PO Box 857 SE -501 15 BORÅS Sweden

Tel: +46 10 516 53 42

E-mail: [hpc@heatpumpcentre.org](mailto:hpc@heatpumpcentre.org) http://www.heatpumpingtechnologies.org Report no. HPT -AN58 - 2