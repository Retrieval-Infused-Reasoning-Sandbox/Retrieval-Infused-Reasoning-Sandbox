# Chapter 7

Chapter Outline 7.1 Building-Integrated

# High Efficiency Plants and Building Integrated Renewable Energy Systems

| Photovoltaics (BIPV)               | 443 | Opportunities, and Strategies   |     |
|------------------------------------|-----|---------------------------------|-----|
| 1. Introduction                    | 443 | for BIPV Application            | 493 |
| 2. BIPV Basis                      | 444 | 5.1 Development Situation of PV |     |
| 2.1 What is BIPV and Why           |     | Market Around the World         | 493 |
| BIPV?                              | 444 | 5.2 Benefits of BIPV Systems    | 496 |
| 2.2 PV Effect, PV Materials,       |     | 5.3 Barriers for BIPV           |     |
| and PV Cells                       | 446 | Applications                    | 497 |
| 2.3 PV Modules Suitable for        |     | 5.4 Future Opportunities        |     |
| Building Integration               | 450 | of BIPV                         | 499 |
| 2.4 PV Cell/Module/Panel/Array 450 |     | 5.5 Strategies for Promoting    |     |
| 3. Classification, Composition,    |     | BIPV Applications               | 501 |
| and System Design of BIPV          |     | 6. Summary                      | 502 |
| Systems                            | 452 | References                      | 503 |
| 3.1 Classifications of BIPV        |     | 7.2 Solar Thermal Energy for    |     |
| Systems                            | 452 | Building Applications           | 507 |
| 3.2 Main Components of a           |     | 1. Introduction                 | 507 |
| BIPV System                        | 457 | 2. Solar Collectors             | 508 |

5. Benefits, Barriers, Future

2.1 Flat Plate Collectors [508](#page-67-0) 2.2 FPCs With Diffuse Reflectors [512](#page-71-0)

Cooling [520](#page-79-0) 4.1 Space Heating and Service

Hot Water [521](#page-80-0) 4.2 Air Systems [522](#page-81-0) 4.3 Water Systems [523](#page-82-0) 5. Solar Cooling [525](#page-84-0)

Collectors [513](#page-72-0) 2.4 Evacuated Tube Collectors [516](#page-75-0) 3. Building Integration of RES [518](#page-77-0)

2.3 Compound Parabolic

4. Solar Space Heating and

3.3 BIPV System Design [461](#page-20-0)

Capacity of BIPVs [464](#page-23-0)

Cooling Load [483](#page-42-0) 4.3 Overall Energy Performance of BIPV Systems [484](#page-43-0)

of BIPVs [489](#page-48-0)

4. Potential, Performance and Life-Cycle Assessment of BIPV Systems [463](#page-22-0)

4.1 Electricity Generation

4.2 Effect of BIPVs on Heat Gain/Loss or Heating/

4.4 Life-Cycle Assessment

| 6. Solar Cooling With Absorption   |     | 9.2 Effect of Condenser Pressure 553 |     |
|------------------------------------|-----|--------------------------------------|-----|
| Refrigeration                      | 526 | 9.3 Effect of Other System           |     |
| 7. Recent Research                 | 528 | Parameters                           | 553 |
| 7.1 Solar Heating and Cooling      |     | 10. Carbon Dioxide Emissions and     |     |
| Systems                            | 528 | Other Environmental Impacts          | 554 |
| 7.2 Absorption Cooling,            |     | 11. GSHP Examples                    | 555 |
| Adsorption Cooling, and            |     | 12. Conclusions                      | 556 |
| Trigeneration                      | 529 | References                           | 556 |
| 8. Conclusions                     | 532 | 7.4 CCHP for Buildings: Design       |     |
| References                         | 532 | Methodologies, Operational           |     |
| 7.3 Ground-Source Heat Pumps       | 535 | Strategies, and Optimization         |     |
| 1. Introduction                    | 535 | Schemes                              | 560 |
| 2. Space Heating and Cooling       |     | 1. Introduction                      | 560 |
| Systems                            | 536 | 2. Design Methodologies              | 562 |
| 3. GSHP Systems                    | 537 | 2.1 Optimal Sizing of CCHP           | 562 |
| 4. Earth Connections for GSHPs     | 539 | 3. Operational Strategies            | 564 |
| 4.1 Closed-Loop Systems            | 540 | 3.1 FEL and FTL Operations           | 564 |
| 4.2 Open-Loop Systems              | 543 | 3.2 Advanced Control for             |     |
| 4.3 Ground Connection Pipe         |     | Real-Time Operation                  | 566 |
| Lengths and Heat Transfer          |     | 4. Optimization Schemes              | 566 |
| Details                            | 544 | 4.1 Operation With Energy            |     |
| 5. Global Status of GSHPs          | 544 | Storage                              | 569 |
| 6. Recent Advances in GSHPs        | 546 | 5. Case Studies                      | 569 |
| 7. Ground-Loop Heat Exchangers     | 548 | 6. Conclusions                       | 570 |
| 8. Ground- vs Air-Source Heat      |     | References                           | 570 |
| Pump Systems                       | 549 | 7.5 Efficient Heating Fan Coil       |     |
| 8.1 Comparison of Ground           |     | Unit in Buildings                    | 575 |
| and Air-Source Heat Pumps          | 549 | 1. Introduction                      | 575 |
| 8.2 Advantages of Ground- and      |     | 2. Concept Definitions               | 577 |
| Air-Source Heat Pumps              | 549 | 3. Design Methodologies              | 581 |
| 9. Effects of System and Operating |     | 4. Experiment Results                | 588 |
| Parameters on GSHP                 |     | 5. Case Studies                      | 590 |
| Performance                        | 550 | 6. Conclusions                       | 594 |
| 9.1 Effect of Compressor           |     | References                           | 595 |
| Efficiency                         | 551 | Further Reading                      | 595 |

#### <span id="page-2-0"></span>Chapter 7.1

# **Building-Integrated Photovoltaics (BIPV)**

Tiantian Zhang and Hongxing Yang

The Hong Kong Polytechnic University, Hong Kong, China

#### INTRODUCTION

With the rapid development of society and economy, the excessive consumption of fossil fuels has brought great challenges of energy shortage, environmental damage, and climate change. Therefore, new opportunities are created to explore and utilize renewable energy resources. Renewable energy technology is now becoming one of the world's fast-developing sectors, so as to meet the future energy requirement as well as mitigating environmental problems.

Of all previously available renewable energy resources, solar energy is considered to be an inexhaustible, and the cleanest and the most abundant one [1]. The power of the sun reaching the earth can be estimated to be approximately  $1.8 \times 10^{11}$  MW, which is far greater than the world's energy demand [2]. There are roughly four ways to capture and utilize solar energy, that is, solar lighting technology, solar heating and cooling technology, solar thermal power generation technology, and solar photovoltaic (PV) technology. PV technology is believed to be the most promising way to harness solar power, as it generates electrical power on-site directly from solar radiation through the PV effect of employed solar cells.

The exploration of PV applications has shifted from small PV cells to large scale grid-connected PV systems in recent years. Nowadays, more than 90% of existing PV systems is large-scale grid-connected systems, among which a significant proportion belongs to building-integrated photovoltaic (BIPV) systems, an emerging subsector of PVs [3]. BIPV technology refers to the PV utilization method that uses PV cells to substitute traditional building materials by integrating them into building envelopes, such as roofs, windows, facades, balcony, skylights, etc. In BIPV field, PV modules are increasingly incorporated into new buildings as principal or ancillary materials, or into existing buildings for retrofitting [1]. The main advantage of BIPVs over nonintegrated PV systems is that the integration of building envelopes and PV modules can offset the system initial costs. Integrated into building envelopes, BIPV components always carry out multifunctions including thermal insulation, noise prevention, weather proof, privacy protection, and on-site electricity production.

Enjoying so many advantages, BIPV is anticipated to be a promising future energy system. Thus, this technology has been developed rapidly in recent years due to advances in technology, cost reduction in PV materials, and increase in <span id="page-3-0"></span>governments' incentive policy for renewable energy technologies. Through a broad literature review, this section provides an overview of the basis, composition, and classification of BIPV systems, and then discusses some issues associated with the design, maintenance, and the performance assessment of BIPV systems. Finally, the benefits, barriers, future opportunities, and strategies for BIPV development are also analyzed.

# 2. BIPV BASIS

#### 2.1 What is BIPV and Why BIPV?

#### 2.1.1 What is BIPV?

Essentially, BIPV refers to the integration of PV modules into the building envelope, and therefore can provide multiple functions to serve as part of building structures by replacing traditional building materials and to produce electricity on-site. In this form, the PV modules can be easily blended into building envelopes, including roofs, windows, facades, balcony or skylights, during the design stage; thus it's quite suitable for application in new buildings. Another application term for BIPV is to add PV modules on exterior envelopes of existing buildings to form building-applied photovoltaic (BAPV) systems, which can be conveniently adopted in the retrofit of old buildings.

BIPV applications firstly appeared in the 1970s in the United States and elsewhere. At this beginning stage, in remote areas with no electric power grid, aluminum-frame PV modules were used for domestic electricity generation by connecting, or mounting them to buildings. In the 1980s, roof-integrated PV systems, which were usually installed on buildings and connected to regional power grid, began to be studied and applied. In the 1990s, commercial PV products specially designed for BIPV applications were already available in building material markets. The past decade has witnessed the development and prosperity of PV technologies in building field for both new projects and old building retrofits. After years of application and practice, BIPV has demonstrated its potential to be a multifunctional and effective building energy technology that can bring many advantages to buildings. For example, a PV window is firstly a necessary component of the building envelope, secondly a solar power generation system, and finally a daylighting device; furthermore, it is capable of reducing space cooling load by weakening the heat transfer in the window area due to the shading effect. Actually, BIPV presents great innovation and potential in realizing green or zero energy buildings in future.

# 2.1.2 Why BIPV?

With heightened concerns over resource depletion and environmental degradation, the awareness of the environmental impact resulted from building construction and operation has been dramatically improved. Meanwhile, the shortcomings of conventional buildings are becoming increasingly clear: poor designed thermal and energy systems squander a larger amount of electricity from the power grid. People come to realize that future buildings should not only be esthetically pleasing, but also be environmentally friendly. The first step is to improve the performances of indoor energy systems, including the building thermal insulating system, the lighting system, and the HVAC system. Previously, significant advances have been made on these systems, but it is still far from being enough. Designing sustainable buildings that rely entirely on renewable resources may be a future trend.

PV is capable of producing electricity directly from sunlight. And the process is free of energy consumption, environmental pollution, and noise making. Integrating PV elements to buildings makes it possible for buildings to achieve self-producing and self-consumption on electricity. The electricity produced can be partially or fully used to balance the electricity requirement of indoor energy systems, thus can mitigate the power supply pressure of traditional power grid, and further reduce the fossil fuel consumption and the greenhouse gas emissions.

Another distinctive attribute of BIPV is its appearance when compared with conventional building materials. Until now, BIPV is recommended as a promising compromise between building energy and building esthetics. There are many types of PV cells that can be integrated into buildings, providing numerous opportunities for innovative architectural design and can make future buildings esthetically appealing. Despite being an energy producer, PV modules can either act as opaque roof/shading-devices or semitransparent window/fac¸ade/skylight components. Moreover, some modules can be flexible, colorful, and visually arresting, thus can respond to architects' or designers' imagination to create various visual effects as well as make buildings environmentally friendly.

There are some other advantages that BIPV can bring to a building. For instance, in summer, adding PV modules to building envelopes can help to reduce the heat gain by preventing the envelopes from being directly exposed to solar radiation so that it can effectively reduce the cooling load of indoor air conditioning systems. Reserving a ventilated air channel between the PV modules and the external envelopes of a building may benefit from the air circulation in the channel by decreasing the operation temperature of the PV modules, which provides an effective method to increase the PV modules' energy efficiency. Experimental results verified that PV walls with a properly designed ventilation channel can increase the electricity production by 8%, through decreasing the modules' temperature by 15°C.

From an overall point of view, incorporating PV technologies into buildings, not only introduces an on-site electricity producing opportunity, but also brings about some by-produced advantages related to architectural esthetics and energy efficiency aspects. In BIPV involved buildings, compared with conventional buildings, this integration provides better natural lighting, enhanced thermal comfort, reduced energy consumption, and esthetically pleasing. BIPV broadens the road to architectural design and energy conservation for future buildings.

# <span id="page-5-0"></span>2.2 PV Effect, PV Materials, and PV Cells

#### 2.2.1 The PV Effect

This PV effect, which was the principle of producing electricity from solar radiation, was first observed in 1839 by Alexandre Edmond Becquerel, a French scientist Edmund Becquerel. The PV effect is a process that, when sun lights strike on the boundary layer of semiconductor materials, electric current can be generated. Since then, many scientists attempted to develop electricity generation technologies based on this effect. In 1870, the PV effect was studied in selenium, and the results indicated that the power efficiency by solid selenium was only 1%–2%, which was far below the acceptable value for potential energy convertors. In 1950, crystalline silicon with high purity was developed; in 1954, silicon PV cell with the converting efficiency of 4% was developed in Bell Labs; later, the efficiency was further improved to 11%. At this time, the PV effect created a new era of solar power generation.

Fig. 1 illustrates the principle of the PV effect in a PV cell. Essentially, sunlight is composed of photons, which can be considered as discrete units of the energy stored in light. A PV cell is made from semiconductor materials with a p-n junction. When solar radiation strikes a solar cell, part of the photons can be absorbed by the cell, resulting in the production electron hole pairs in the cell. If an external circuit is formed, the voltage difference drives the electrons from the n-side to the p-side of the junction. Consequently, the electric current is formed in the external circuit.

#### 2.2.2 PV Materials

Nowadays, various semiconductor materials can be used for PV cell fabrication, including silicon-based materials, non-silicon-based materials, and a number of advanced materials. Among the above-mentioned semiconductor materials, silicon is believed to be the main material for PV cell production, and its physical,

![](_page_5_Picture_8.jpeg)

FIG. 1 Principle operation of a PV cell.

optical, and electrical properties have been most studied in the past decades. PV cells fabricated from silicon materials have been proven to be reliable in solar PV fields. Silicon-based PV technologies can be grouped into three types, such as single-crystal or monocrystalline silicon, polycrystalline silicon, and thinfilm amorphous silicon [4]. Silicon now takes approximately 80% of the PV market, while the rest part is shared by non-silicon-based thin-film materials, such as gallium arsenide (GaAs), cadmium telluride (CdTe), copper indium diselenide (CIS), and copper indium gallium selenide (CIGS) [5].

Among silicon-based PV cells, monocrystalline ones are usually black or gray in color and have higher efficiencies and higher prices, since they are made from pure monocrystalline silicon. Fabricated from ingots of multi-crystalline silicon, polycrystalline cells enjoy easier manufacturing process and are multicolored with shining blue tones. They are cheaper but less effective. In amorphous silicon PV cells, a thin un-crystallized layer silicon is attached onto a substrate, which rides the cell relatively thin. The color of amorphous silicon cells is reddish-brown or black. The power efficiencies of these silicon-based PV cells are very different from each other. For monocrystalline cells, the efficiency ranges between 16% and 24%; the efficiency of polycrystalline cells varies in the range of 14%-18%; for these two cells, the power per unit varies between 75 and 155 Wp/m<sup>2</sup>. As for the amorphous silicon cells, the efficiency varies from 4% to 10%, and the power per unit area is typically 40–65 Wp/m<sup>2</sup> [6].

Up to now, CdTe and CIGS are the most promising materials for costeffective thin-film solar power production. CdTe PV cell benefits from the lowest manufacturing cost among all current thin-film technologies. The efficiency of CdTe cells varies from 9.4% to 13.8%. CIS and CIGS are the most effective materials for the thin-film PV technology, and the efficiency of CIS and CIGS cells is typically 11%–18.7% [7]. The color of non-silicon-based thin-film cells is often dark gray to black. Fig. 2 presents the timeline for efficiencies of reported PV technologies from laboratories, universities, and companies, including multifunction, single-junction GaAs, crystalline silicon, thin-film, and other emerging PV technologies.

#### Three Generations of PV Cells 223

Although silicon-based PV cells occupy the majority of the commercial PV market nowadays, various innovative types of PV cells are still continuously being developed or improved to reduce the manufacturing, operating, and maintenance costs of PV cells as well as to improve the power efficiency.

The existing PV technologies can be generally classified into three generations according to their technical attributes [8]. Presently, the research and development attempts at cost reduction and efficiency improvement of PV cells are processed by a number of research groups from all over the world. Unfortunately, the majority of PV markets are currently covered by the first- and secondgeneration PV cells. Fig. 3 illustrates the three generations of existing PV cells.

<span id="page-7-0"></span>![](_page_7_Figure_1.jpeg)

FIG. 2Reported timeline of solar cell energy conversion efficiencies (National Renewable Energy Laboratory).

<span id="page-8-0"></span>![](_page_8_Figure_2.jpeg)

FIG. 3 Three generations of solar PV cells.

#### First Generation

The basic technology of first-generation PV cells is the Si wafer technology. The monocrystalline and polycrystalline silicon PV cells belong to this generation. These cells universally have single-junction structure with the theoretical highest efficiency to be 33%. Generally, first-generation PV cells last longer and have higher efficiency than other PV cells. However, their manufacturing process costs higher both in energy consumption and labor, and they are easy to degrade the performance at higher temperature conditions. First-generation cells are currently the most efficient and the most widely used among all the three generations.

#### Second Generation

Second-generation PV cells are still single-junction devices, but compared with the first-generation ones, their manufacturing consumption on semiconductor martials is significantly reduced. Second-generation PV cells are usually manufactured by thin-film PV technology. Compared with first-generation cells, they are usually made from very thin layers of semiconductor materials. The manufacturing processes of these cells are simple and consume fewer materials, so they have a lower price than the first-generation cells. Using less semiconductor materials, their efficiencies are lower when compared with the siliconbased first-generation cells. Basically, there are mainly three types of PV cells in this generation, including amorphous silicon, CdTe, and CIGS. They together take approximately 20% of the total PV market.

#### <span id="page-9-0"></span>Third Generation

The main goal of third-generation PV cells is to produce high-efficiency devices still using the thin-film technology in second-generation PV cells. It aims to make the solar PV technology more efficient and less expensive, using a variety of new materials besides silicon, including solar inks, nanotubes, organic dyes, and conductive plastics. Most of the research and development work on thirdgeneration PV technology is now being processed in laboratory condition of research groups in universities or companies, so most of them are still not commercially available.

#### 2.3 PV Modules Suitable for Building Integration

Conventionally, PV modules are designed and manufactured for outdoor applications. Thus, they can operate under the sun, rain, and other climate impacts, which make possible the use of PV modules as potential components for external enclosures of buildings. With the development in the past few decades, various types of PV module technologies are now available in the PV market, but not all these technologies are suitable for the integration or incorporation in building envelopes, since PV modules are traditionally designed mainly for power generation, and their functionalities as envelope elements are generally overlooked.

As construction products, BIPV modules should be able to satisfy some essential requirements considering the properties of mechanical stability, fire resistance, sound insulation, thermal insulation, etc. There are several options for the integration of PV modules into buildings, including roofs, walls, windows, and shadings. There are mainly two methods to form BIPV systems, one is to mount PV modules on existing building envelopes, and the other is to use PV modules to replace part of the conventional materials in building envelopes. Standard PV modules are commonly used in BIPV applications, especially for existing building retrofitting, but the frame has impeded their convenient and elegant integration into envelopes. To overcome this shortage of standard PV modules, PV laminates were developed by omitting the frame of PV modules. PV laminates can be mounted into envelope components like glass panes. [Table 1](#page-10-0) shows the applicability of previous PV modules for the integration in sloped roofs, flat roofs, walls, windows, and shading systems.

# 2.4 PV Cell/Module/Panel/Array

As already stated, through the PV effect, direct current can be produced by solar cells from solar radiation. Solar cell is the basic component of PV electricity generation. However, a single solar cell cannot produce sufficient power for related applications. Therefore, as presented in [Fig. 4,](#page-10-0) solar cells are connected with each other in series to achieve a greater power generation capacity. Additionally, the connected cells are deposited between transparent or opaque covers for protection. This packaged series of cells are known as PV modules. PV

<span id="page-10-0"></span>

| TABLE 1<br>Applicability of Different Types of PV Modules for Building |
|------------------------------------------------------------------------|
| Integration                                                            |

|                                                                                   | Applicability  |              |      |        |         |  |
|-----------------------------------------------------------------------------------|----------------|--------------|------|--------|---------|--|
| Module Structure<br>Technology                                                    | Sloped<br>Roof | Flat<br>Roof | Wall | Window | Shading |  |
| Standard modules with<br>plastic or metal frame,<br>non-transparent back<br>sheet | +              | o            | o    |        | o       |  |
| Standard laminates as<br>above without frames                                     | +              | +            | +    |        | +       |  |
| Glass–glass modules<br>with predefined<br>transparency                            | o              | o            | +    | +      | +       |  |
| Glass modules with<br>transparent plastic<br>back sheet<br>(transparent)          | o              | o            | +    | +      | +       |  |
| Module with metal<br>back sheet and plastic<br>cover                              | +              | +            | +    |        | +       |  |
| Roofing modules (tiles/<br>slates)                                                | +              |              |      |        | +       |  |
| Custom-designed<br>modules                                                        | +              | +            | +    | +      | +       |  |

<sup>+</sup> High suitability, o low suitability, not suitable.

![](_page_10_Picture_5.jpeg)

FIG. 4 PV cells, modules, panels and arrays.

modules can be designed with various power outputs by assembling solar cells with different numbers, sizes, and materials. In general, the module's top layers are transparent and are usually made from hardened or tempered glass to protect the internal PV cells from the ambient and severe weather conditions. The cover <span id="page-11-0"></span>prevents outer water, water vapor, and gaseous pollutants from penetrating the module. Moreover, the back sides of PV modules are covered with a layer of tedlar or glass. Additionally, a frame made of aluminum or composite materials is necessary to ensure the mechanical stability of PV modules for mounting and fixing.

There are currently many types of PV modules available, and glass-to-tedlar PV modules are the most widely used in PV applications. In this type of PV module, the series-connected cells are sandwiched between a top glass cover and tedlar back sheet, and sealed with a metal frame. In these modules, one cell can produce approximately 0.5 V. As illustrated in [Fig. 8](#page-14-0), 36 cells are connected and packaged into a standard module, which can produce a nominal 12 V, and maximal 18 V power. These standard modules are originally designed for charging 12 V batteries. Furthermore, any desired current, voltage, and power can be achieved by connecting individual PV modules in series or/and parallel. When modules are fixed together, a PV panel is formed. Additionally, when more than two panels are connected together, a PV array is structured. In a PV array, PV modules are connected in series to produce the required voltage; then the series-connections are further connected in parallel to enhance the current and power output. The array sizes are always determined by the required power output.

The electrical output of a PV module depends on solar irradiance, solar cell temperature, electrical efficiency of solar cells, and load resistance. For a given size of solar cell, the current increases with increasing solar irradiance, and the current increases marginally with temperature rise; however, a higher solar cell temperature decreases the voltage output of solar cell, which in turn decreases power output. For better performance, the PV module in an array must operate at the peak power point; the array must be installed in an open place, and the PV module must be kept cool.

# 3. CLASSIFICATION, COMPOSITION, AND SYSTEM DESIGN OF BIPV SYSTEMS

# 3.1 Classifications of BIPV Systems

BIPV systems can be roughly classified according to the energy supply and storage modes, the integrating modes and the module types.

# 3.1.1 According to Energy Supply and Storage Mode

BIPV systems generate electricity and then provide direct current (DC) and/or alternating current (AC) power to end users. They can operate independent of or interconnected with the utility grid. For power supply safety, they may cooperate with other power sources and energy storage systems. According to their power supply and storage modes, there are basically two types of BIPV systems, such as the grid-connected system and the stand-alone system. The former is usually connected to an electric grid, which serves as a storage component and ensures system stability and reliability. While the later needs a battery for surplus power storage. The battery also helps to ensure a stable power supply from the fluctuating power generation. Moreover, in stand-alone systems, to ensure a continuous supply under extreme conditions, a supplementary generator is necessary.

#### Grid-Connected BIPV Systems

Grid-connected systems, also named utility-interactive systems, imply that the BIPV systems are connected to an available electric utility grid to achieve a parallel and interconnected operation. As presented in Fig. 5, an inverter or power conditioning unit is necessary in these systems for the purpose of converting the produced DC power into AC power, which has the same voltage and power quality with that in the utility grid. A distribution panel performs a bi-directional regulation between the AC output of the BIPV system and the utility grid. It cuts down the supply of electricity to the grid automatically when the BIPV system output is below the on-site load during nighttime or other periods and enables electricity extraction from the grid. It also distributes the produced electricity between on-site supply and back-feed the grid during sunny time. Actually, the utility grid acts like a power storage system. Thus a battery is not essential in this type of BIPV systems.

#### Stand-Alone BIPV Systems

Stand-alone BIPV systems are usually designed to operate independently in areas that have no access to a power utility grid or are not easily accessible. Thus, these systems are generally designed with certain DC and/or AC supply capacities. Stand-alone systems usually employ one or more PV arrays to be the power source, or other energy sources, such as wind, diesel or gas engine, or the utility grid, as auxiliary power sources.

![](_page_12_Figure_7.jpeg)

FIG. 5 Diagram of grid-connected BIPV system.

![](_page_13_Picture_2.jpeg)

FIG. 6 Diagram of direct-coupled BIPV system.

The simplest type of stand-alone systems is the direct-coupled system, in which the PV array is directly connected to available DC loads, as illustrated in Fig. 6. These systems can only operate during sunlight hours, since there is no power storage or regulation component. This makes these systems suitable for very limited applications, such as ventilating fans and water pumps. One challenge for the direct-coupled systems is to balance the electricity output of PV arrays and the on-site load. Matching the impedance of the electrical load to the maximum power output of the PV array is a critical part of designing a well-performing direct-coupled system.

In stand-alone systems, normally, batteries are necessary to expand their applicability. Fig. 7 shows the diagram of a typical stand-alone BIPV system. The battery is used for power storage. This type of BIPV system typically consists of a PV array or arrays, a battery, a charge controller, and an inverter that converts DC power from the PV array to AC electricity for general appliances. This system can simultaneously power DC and AC loads.

[Fig. 8](#page-14-0) shows a typical BIPV hybrid system. In the hybrid system, more than one type of electricity generator is employed. Besides the PV generator, another type of generator is employed. This generator can be either renewable source or conventional source, such as wind turbine, diesel or gas engine generator, or even the utility grid. The hybrid system can also satisfy both DC and AC loads simultaneously.

![](_page_13_Figure_7.jpeg)

FIG. 7 Diagram of stand-alone BIPV system.

<span id="page-14-0"></span>![](_page_14_Figure_2.jpeg)

FIG. 8 Diagram of BIPV hybrid system.

#### 3.1.2 According to Integration Pattern of Building and PVs

As described in previous sections, according to the integration pattern, BIPV systems could be roughly classified as building-integrated system and building-applied PV system. The former is suitable for new buildings by substituting conventional building materials with PV modules, while the latter is easily applied to existing buildings by adding PV modules to some parts of their envelopes, and if the PV modules are removed, the buildings can still run normally.

PV modules can be integrated into different parts of a building, including the roofs, the fac¸ades, the sun-shades, the rain-screens, the atrium/skylights, claddings, railings, etc. So there are many alternatives for PV integration in buildings. Fig. 9 presents some of these potential integration methods.

In current BIPV market, about 80% of BIPV systems are based on roof integrations, while the rest 20% are based on fac¸ade integrations.

PVs can be integrated into the roof by the following means: the most widely used method is to add PV modules to the roof, another is to directly integrated

![](_page_14_Figure_9.jpeg)

FIG. 9 Integration methods of PV modules.

PV modules into the roof, and the last is to use PV modules as constructing materials of roofs. In general, in BIPV practice, the roof-integrated PV technologies are the most widely used, since roofs have a number of attractions as sites for PVs. Compared to wall-based PV systems, the roof slope can be easily optimized for high power performance, and it is easy to integrate PVs into roofs functionally and esthetically.

Facades offer a large area for PV module integration. A typical BIPV facade often faces southward in northern hemisphere, but vertical PV modules produce much less electricity than well-designed sloped roof PV systems. There are also various measures, by which PVs can be integrated into vertical facades. The most promising one is the ventilated PV fac¸ades, which use ambient air to cool the PV modules, thus can improve the power conversion efficiency. This structure can be formed by either adding PV modules to existing buildings, or constructing double layer PV facades during the design stage of new buildings. This structure benefits from both the electric and the thermal merits. The air circulation between the PV module and the inner fac¸ade layer on one hand helps to reduce the module temperature, thus improves the electrical performance. On the other hand, the air circulation and the shading effect of PV modules also reduce the inner layer temperature, and consequently decrease the cooling load. Additionally, the warmed air can be a potential heating source of indoor environment in winter conditions.

The integration of PV modules into solar shading devices is one of the most effective ways to control indoor thermal and light conditions. It prevents sun lights from passing into the indoor environment, thus reducing the cooling demand in summer. Simultaneously, the blocked sun lights are used for power generation. If the sun-shading PV system is well designed with a controllable system, the position of the sun could be tracked for optimizing electricity production. Moreover in winter, the system can be regulated for operating in a more solar heat gain mode, to improve the indoor thermal environment.

Rain-screen cladding systems normally consist of panels that are set slightly off the exterior walls to allow drainage and ventilation. So these systems are quite suitable for PV integration.

Atrium/skylights are envelope components with the purpose of regulating the indoor light condition. Transparent or semitransparent PV (STPV) modules are suitable for integrating in these structures to allow controlled light into the indoor environment. A well designed PV atrium/skylight system can not only produce electricity, but also protect the building from heat, sunlight, glare, and the weather.

# 3.1.3 According to PV Module Types

Up to now, according to the module shape, BIPV systems can be categorized as rigid module-based BIPV system and flexible module-based BIPV system. The former is constructed by rigid BIPV modules, while the latter by flexible BIPV <span id="page-16-0"></span>modules. Rigid BIPV modules can be manufactured from all PV technologies available by employing a rigid back sheet or rigid substructure, such as plastic, glass, and metal sheets. According to their mechanical properties, rigid BIPV modules are very suitable to replace conventional cladding materials for building facades and roofs.

Flexible BIPV modules can be fabricated from most emerging technologies including perovskite PV technology, dye-sensitized PV technology, organic PV technology, and all thin-film technologies, including copper indium gallium selenide, cadmium telluride, amorphous silicon, microcrystalline silicon, etc. The substructure of flexible PV modules can be polymer films or metal sheeting.

#### 3.2 Main Components of a BIPV System

As illustrated in [Fig. 10,](#page-17-0) a typical BIPV system consists of the PV module and the balance of system (BOS) components for mounting and connecting PV modules as well as converting the generated DC electricity to AC electricity. Generally, the following components are included:

- (1) Solar PV modules: PV modules in the BIPV system might be crystalline or thin-film, rigid or flexible, transparent, semitransparent, or opaque; they are strung together in series or parallel with cables and wires to form PV arrays, and then integrated into building envelopes.
- (2) A power storage system to store surplus electricity and to re-provide power during no-sunlight hours; as mentioned above, the storage system would be batteries in stand-alone BIPV systems, and the utility grid in grid-connected BIPV systems.
- (3) A charge controller is necessary in stand-alone systems for regulating the produced DC power from the PV array into and out of the storage batteries.
- (4) A power conditioning unit or an inverter to convert DC power to AC power that can be supplied to AC loads or be fed into the utility grid.
- (5) Backup power generators such as wind turbine, diesel, or gas engine generator are essential for power supply reliability in stand-alone systems.
- (6) Supporting and mounting elements and other accessories including cables, connectors, and safety facilities.

# 3.2.1 PV Modules

In all BIPV systems, the PV modules are the most basic and critical element, since they are the power generating units which produce electricity through the PV effect. The output voltage is determined by the number of PV modules in series, and the output current is sized by the number of the parallel connected PV strings.

<span id="page-17-0"></span>![](_page_17_Picture_1.jpeg)

FIG. 10 System components of stand-alone and grid-connected BIPV systems.

# 3.2.2 Power Storage Systems (Batteries)

The electricity production of PV modules varies a lot according to the weather condition. Additionally, in the BIPV system, energy storage systems are required because of the fluctuating nature of the PV module output. During the sunny hours, the system operates well and produces a considerable amount of electricity; while in cloudy days and during the nighttime, BIPV systems stop generating electricity. Accordingly, there may be a mismatch between the power output and the electricity load. The mismatch should be balanced using related energy storage devices to ensure the electricity supply reliability. In grid-connected BIPV system, the utility grid acts as the storage system; while in stand-alone BIPV systems, a storage device is essential. For BIPV systems, the storage system should be low cost, recyclable, long lasting, and easy to operate and maintain. There are numerous types of energy storage methods for storing electricity, but only a few of them are suitable for BIPV systems.

Batteries provide a promising alternative for power storage in BIPV systems. They are used to store surplus electricity during sunny hours, and to supply electricity at night or other times when the power output of the BIPV system cannot meet the power demand. The principal requirement of batteries for the BIPV system is that they can be repeatedly charged and discharged without damage.

Lead-acid, nickel/cadmium, nickel/hydride, and lithium are the main types of batteries available currently [\[9\].](#page-62-0) Themost widely used batterytypeisthe deep-cycle lead-acid batteries, which can either be a flooded type with longer lasting, or be a valve-regulated type with less maintenance. There are also some alternative battery options that are being developed, such as zinc/bromine, nickel/hydrogen, nickel/ metal hydride, nickel/iron, nickel/zinc, and sodium/sulfur batteries[\[10\].](#page-62-0) These batteries are expected to replace previous batteries by providing higher energy density, broader operation temperature range, longer lifetime, and other benefits.

When batteries are used in BIPV systems, the safety aspect should be taken into consideration. The charging process produces hydrogen and oxygen gas, which may result in explosion or fire under certain conditions. Thus, locating vented batteries in adequately ventilated areas would help to avoid these hazards. Additionally, it is advisable to place batteries in cool and dry environments. Another safety issue is the cell imbalance that occurs when one or more PV cells are weaker than the rest. Cell imbalance may lead to overcharging problems and may result in unnecessary gassing. So quarterly or annually performance tests of individual cells are important for identifying and removing the weak cells. Another concern is that the electrolytes in most batteries are corrosive and may threaten humans' skin, eyes, and other vulnerable parts. Thus, when maintaining these batteries, necessary safeguard should be taken.

# 3.2.3 Inverter

Inverters are essential components of BIPV systems, since they are universally used for effectively converting DC output power from the PV arrays into sinusoidal AC electricity which could be consumed by on-site users or be fed into the grid utility. The inverter output power can be single or three-phase AC electricity. The optimal specification and sizing of an inverter can be determined by designers in accordance with the PV output and the load requirement. Optimal selected inverters should be with high efficiency, low power loss, and high reliability. The efficiency of an inverter should be kept at a high level over a broad range of power input. Additionally, inverters should be capable of withstanding short-term overload to cope with high start-up power demands.

Various types of inverters are available for BIPV systems [\[10\].](#page-62-0) The sine wave, modified sine wave, and square wave inverters are the three major types. For sine-wave inverters and modified sine-wave inverters, the major advantage is the fact that they can be operated with most appliances, since these appliances are designed for operating with sine-wave electricity. Square-wave inverters are much cheaper than sine-wave inverters, but their applicability is limited. Fortunately, employing a power filter, the output square waveform current can be converted into a sine waveform, which helps to broaden their scope of applications.

# 3.2.4 Charge Controllers

Charge controllers are crucial in BIPV systems to prevent batteries from being damaged by overcharging and over-discharging by controlling the current flow from and to the batteries. They can also protect the appliances that are connected to the batteries in BIPV systems. Most batteries can hardly recover after overcharging and over-discharging, so the employment of controllers in BIPV systems can prolong the service life of the batteries. There are various types of charge controllers, including shunt controls, single-stage controls, multistage controls, etc. [\[10\].](#page-62-0)

Shunt controllers monitor the maximum point of battery charging. Once the batteries are fully charged, they are alienated from the PV arrays by the shunt controller, and the surplus power is converted into heat, and then the heat is dissipated through the heat sinks of the shunt controllers. Through these regulations, the overcharging can be prevented for batteries. For shunt controllers, adequate ventilation is necessary for heat dissipation.

In BIPV systems controlled by single-stage controllers, once the batteries are fully charged, the charging circle is switched off to protect the batteries. In the control strategy, the full state of charge is predetermined as the charge termination point, while the minimum state of the battery is set as the charge starting point. When the battery is drained up to the charge starting point, the single-stage controller reconnects charging circle to enable charging. There is little electricity converted into heat in BIPV systems controlled by this type of controller, thereby can eradicate the need for ventilation.

In BIPV systems utilizing multistage controllers, the current flow for battery charging is permitted when the batteries are at a low power state. When batteries <span id="page-20-0"></span>approach full power state, the surplus power for PV arrays can be dissipated. Similar to shunt controllers, multistage can also prolong the battery lifetime. This control mechanism also requires sufficient ventilation, as heat is produced during the power dissipation.

# 3.2.5 Other Elements

In an entire BIPV system, some additional elements are required to ensure an effective and safe operation. For instance, system balance components, including plugs, sockets, switches, and cables should be properly designed, selected, and installed to realize the correct and optimal operation of the BIPV systems. Additionally, in some cases, DC-DC converter is needed when the voltage requirements of users are not in conformity with those of the BIPV system outputs [\[11\]](#page-62-0). Moreover, maximum power point trackers (MPPTs) are always used to search for the optimal operation point of PV modules or arrays. These components together ensure efficient and healthy operation of the BIPV systems.

#### 3.3 BIPV System Design

When designing a BIPV system, both the technical and structural factors should be taken into account, to achieve the highest value for the system [\[8\]](#page-62-0). Technical factors include the location and weather condition, load requirement, solar access, system orientation and tilt, circuit structure, system sizing, life-cycle cost, safety requirements, etc. These factors may greatly affect the BIPV system's performance. Structural factors cover the construction and installation issues of the PV modules and related electrical components. All the above factors must be taken into consideration during the design and constructing stages [\[8\]](#page-62-0). Fig. 11 shows the design procedures of typical BIPV systems.

The typical design procedures of a BIPV system include the following aspects.

# (1) Site and suitability investigation

The geographical location of the candidate building for BIPV largely decides the power output, so it is important to select the proper site based onthe available solar resource. Duringthe planning stage, a site and suitability survey must be performed by carefully checking the site orientation, the total surface available for PV integration, the structure and form of the envelope, and the space available for cable, battery, and inverter installation.

![](_page_20_Figure_10.jpeg)

FIG. 11 Procedures of BIPV system design.

The most critical point is the identification of the PV installation location. The proper location should be shadow-free, which means that, after implementation of the BIPV system, no surrounding objects cast shadows on the PV arrays. Thereby, the proposed site for PV installation should be pre-checked before the design and installation to prevent the possibility of shading problems. Additionally, the environmental parameters directly affect the PV performance, such as the incident solar radiation, the temperature profiles, and the nearby wind velocities for the potential site, should also be collected and recorded, in order to carry out an optimal design for the BIPV system.

#### (2) Power load assessment

In BIPV system design, evaluating the electrical load is an important task, since it determines the sizing of the system components. Oversized systems may lead to a poor system performance and will increase the system costs, while low capacity systems may fail to provide enough power for all appliances.

In the process of power load estimation, all possible electrical consumers should be taken into account to find the peak load. The operating wattage of all the electrical appliances, as well as their running period, should be identified. Furthermore, based on the details of the load requirements, the load profile should also be studied and analyzed to identify the maximal load, the daytime average power demand and the nighttime average power demand of this BIPV system. The loads can be categorized according to their priorities such as essential load and nonessential load and can also be classified based on their profiles as peak loads and off-peak loads. The load classifications and categorizations are necessary for operation optimizations of all the electric appliances. Load management, which decides when to add certain appliances or power consumers to the load, helps to make the load profile more consistent with the supply profile of the BIPV system. So the load management helps to achieve a supply– demand balance in the BIPV system.

#### (3) Solar resource availability assessment

Assessing the solar resource availability is also an important task for BIPV system design, since the solar access determines the potential system output and helps to size the system and its components. Direct radiation, diffuse radiation and ground reflected radiation together make up the incident solar radiation of the PV arrays. Giving the site latitude and longitude, the solar radiation information can be found through NASA. While evaluating the solar resource availability, various information need to be identified, including the average annual/daily global solar radiation on horizontal surfaces and the number of annual sunshine hours.

### (4) System configuration determination

After accessing the power load and the solar resource availability, the overall system configuration also needs to be decided at the design stage considering both the load characteristics and the potential output profile. <span id="page-22-0"></span>The system should be chosen between the grid-connected type and the stand-alone type. The integration pattern of the PV has to be identified according to the building structure and the climate conditions. Roofs, fac¸ades, walls, shading and screen elements, or proper combinations of them can be treated as the foundation of BIPV systems. In accordance with the appliances and the storage strategies, the system may be designed as either a DC-based or an AC-based BIPV system. Furthermore, the possibility of a backup generator needs to be decided at this stage.

#### (5) Sizing of main components

Before specifying the system components, it is essential to size these components in detail through the electrical and mechanical design. There are various factors that affect the sizing of a BIPV system, such as the load size, the operation period, the system location, etc. Additionally, the available surface area of the building directly restricts the PV array size, thus greatly restricts the system size. Moreover, one factor that maximally influences system sizing is the available budget. Generally, available roof/facade area and potential budget are the key restrictions for BIPV system design.

After the system configuration is determined, the types and sizes of the system components should also be decided. In general, the components include the PV modules, the charge controller, the inverter, the batteries, and other elements, such as cables, connectors, safety elements, etc. Moreover in stand-alone BIPV systems, when the power output cannot meet the electrical demand, a backup generator must be designed and sized. [Fig. 12](#page-23-0) presents the steps of sizing a typical BIPV system.

#### (6) Selection of main components

Appropriate selection of BIPV system components is vitally important, as the mismatch between different components may result in huge performance, efficiency, and reliability declines. Thereby, the component selection and their overall integration are very critical for efficient operation of BIPV systems. The system components should be specified in accordance with the sizing results of the system and its components. The components should be specified in the order of modules, batteries, power conditioning equipment and inverter, backup generator, safety elements, and wires. After the selection and specification, a full list of the system components should be prepared for purchasing.

# 4. POTENTIAL, PERFORMANCE AND LIFE-CYCLE ASSESSMENT OF BIPV SYSTEMS

As stated above, BIPV systems offer multiple functions for a building. They act as part of the exterior building envelopes and produce electricity on-site. Therefore, the power output, the optical and thermal impacts are the most noteworthy aspects in BIPV performance. Additionally, the economic prospect of BIPV systems is also worthy of attention. This section therefore discusses the potential capacity, the performance, and the economy of BIPV systems.

<span id="page-23-0"></span>![](_page_23_Figure_2.jpeg)

FIG. 12 Procedures of BIPV system sizing.

# 4.1 Electricity Generation Capacity of BIPVs

#### 4.1.1 Potential BIPV Electricity Generation Capacity of a City or a Country

With the development of the building sector, the building area is becoming bigger and bigger, therefore the potential area available for BIPV application is becoming increasingly attractive. Investigations on the electricity potential of BIPVs in a city or a country will be supportive for promoting BIPV applications.

You and Yang [\[12\]](#page-62-0) preliminarily evaluated the available BIPV area and the corresponding electricity potential in Hong Kong. They concluded that there are more vertical wall areas than roof areas for PV integration in buildings due to more high-rise buildings in this city. Thus, from the available-area point of view, the vertical surfaces have more potential in BIPV application in Hong Kong. Accordingly, the roof-mounted PV modules with the slope of 22.3° would achieve a much higher electricity generation capacity than the walls. Considering the whole year, the capacities of electricity generation are nearly same from South, East, and West walls in Hong Kong. However, the annual average capacity of generating electricity in unit area of PV modules on roof is 87% higher than that on walls. Taken all potential areas in the roof and walls as a whole, the BIPV based on these areas can produce approximately 10.5 TWh electricity, which could satisfy about 35% of the total electricity requirement of Hong Kong in that year.

Peng and Lu [\[13\]](#page-62-0) performed an in depth study to investigate electricity production potential of rooftop PV systems in Hong Kong. The available area of rooftop PV integration was estimated to be 54 km<sup>2</sup> based on the modified solar-architectural rules of thumb. Accordingly, after deducting necessary array distance, the total potential capacity of PV systems on all these areas was 5.97GWp, and the annual potential electricity yield was predicted to be 5981 GWh, which could account for 14.2% of the total electricity consumption of Hong Kong in 2011. Later, they reported the available roof and fac¸ade area as well as the electricity generation potential in Hong Kong. The results showed that the available roof and fac¸ade areas of the residential, commercial, industrial, public housing, government, and school buildings are 40.4 and 15.15 km<sup>2</sup> , respectively. Accordingly, the annual electricity potentials of available roof and fac¸ade area for BIPV are 8494.8 and 3148 GWh, respectively.

Defaix et al. [\[14\]](#page-62-0) reported the technical potential for PVs on buildings in the various member states of the European Union. Based on building characteristics and irradiation from European databases, the BIPV potential capacity in the EU-27 was estimated to be 951 GWp. The annual electricity yield was calculated to be about 840 TWh, which satisfies more than 22% of the predicted European electricity demand in 2030.

Similarly, the International Energy Agency [\[69\]](#page-65-0) also reported the electricity potential of BIPV for some of its member countries. [Table 2](#page-25-0) presents the available roof and fac¸ade areas of residential, agriculture, industrial, commercial, and other buildings in some of the member countries of IEA, such as Australia, Austria, United Kingdom, United States, etc. [Table 3](#page-27-0) shows the corresponding electricity generation potentials and the potential-consumption ratios of the roof and fac¸ade areas in these countries.

[Tables 4 and 5](#page-28-0) illustrate that the available areas of these countries vary a lot, mainly due to their land areas, economic levels, architecture spaces, and the shapes. Accordingly, the solar electricity potentials show great difference in these countries. The United States has the greatest solar electricity potential, and if all potential areas are used for installing BIPVs, the electricity produced can make up 57.8% of the total electricity requirement recorded in 1998. Japan also enjoys a great electricity generation capacity of potential BIPVs, but owing to its high electricity demand, the potential-consumption ratio is only 14.5%. Nevertheless, in each country, the potential capacity of BIPV can balance a great proportion of the total electricity requirement.

Thus, through the above discussions, the potential capacity of BIPV electricity generation for a city or a country is quite huge and can contribute a lot in satisfying regional electricity requirement. As a result, promoting BIPV applications would be a great help for future produce and supply of electricity.

<span id="page-25-0"></span>**TABLE 2** Potential BIPV Areas for Selected Countries of IEA

| BIPV Potential<br>Area (km²) |        | Residential<br>Buildings | Agriculture<br>Buildings | Industrial<br>Buildings | Commercial<br>Buildings | Other<br>Buildings | All<br>Buildings |
|------------------------------|--------|--------------------------|--------------------------|-------------------------|-------------------------|--------------------|------------------|
| Australia                    | Roof   | 373.50                   | 22.50                    | 6.00                    | 16.50                   | 3.75               | 422.25           |
|                              | Façade | 140.06                   | 2.81                     | 2.25                    | 8.25                    | 1.41               | 158.34           |
| Austria                      | Roof   | 85.65                    | 17.13                    | 15.19                   | 17.45                   | 4.20               | 139.62           |
|                              | Façade | 32.12                    | 2.14                     | 5.70                    | 8.73                    | 1.58               | 52.36            |
| Canada                       | Roof   | 727.20                   | 36.36                    | 60.60                   | 133.32                  | 6.06               | 963.54           |
|                              | Façade | 272.70                   | 4.55                     | 22.73                   | 66.66                   | 2.72               | 361.33           |
| Denmark                      | Roof   | 50.88                    | 14.84                    | 10.60                   | 10.60                   | 1.06               | 87.98            |
|                              | Façade | 19.08                    | 1.86                     | 3.98                    | 5.30                    | 0.40               | 32.99            |
| Finland                      | Roof   | 78.28                    | 21.01                    | 19.16                   | 8.45                    | 0.41               | 127.31           |
|                              | Façade | 19.08                    | 1.86                     | 3.98                    | 5.30                    | 0.40               | 32.99            |
| Germany                      | Roof   | 721.78                   | 164.04                   | 229.66                  | 164.04                  | 16.40              | 1295.92          |
|                              | Façade | 270.67                   | 20.51                    | 86.12                   | 82.02                   | 6.15               | 485.97           |
| Italy                        | Roof   | 410.26                   | 113.96                   | 136.75                  | 91.17                   | 11.40              | 763.53           |
|                              | Façade | 153.85                   | 14.25                    | 51.28                   | 45.58                   | 4.27               | 286.32           |
| Japan                        | Roof   | 753.88                   | 40.48                    | 75.89                   | 91.07                   | 5.06               | 966.38           |
|                              | Façade | 282.71                   | 5.06                     | 28.46                   | 45.54                   | 1.90               | 362.39           |

| he<br>lan<br>ds<br>Ne<br>t<br>r           | f<br>Ro<br>o        | 1<br>2<br>7.<br>4<br>8      | 4<br>2.<br>7<br>0      | 5<br>2.<br>7<br>5      | 3<br>5.<br>8<br>0           | 0.<br>6<br>3           | 2<br>5<br>9.<br>3<br>6            |
|-------------------------------------------|---------------------|-----------------------------|------------------------|------------------------|-----------------------------|------------------------|-----------------------------------|
|                                           | de<br>Fa<br>c¸<br>a | 1<br>4<br>7.<br>8           | 5.<br>3<br>4           | 1<br>9.<br>7<br>8      | 1<br>7.<br>9<br>0           | 0.<br>2<br>4           | 9<br>7.<br>2<br>6                 |
| Sp<br>in<br>a                             | f<br>Ro<br>o        | 1.<br>2<br>5<br>9<br>7      | 7<br>8.<br>7<br>4      | 1<br>5<br>5.<br>2      | 1<br>5<br>5.<br>2           | 7.<br>8<br>7           | 4<br>4<br>8.<br>8<br>2            |
|                                           | de<br>Fa<br>c¸<br>a | 9<br>4.<br>4<br>9           | 9.<br>8<br>4           | 1<br>0.<br>6<br>7      | 2<br>7.<br>5<br>6           | 2.<br>9<br>5           | 1<br>1<br>6<br>8.<br>3            |
| de<br>Sw<br>e<br>n                        | f<br>Ro<br>o        | 1<br>3<br>4.<br>5<br>2      | 3<br>6.<br>1<br>1      | 3<br>2.<br>9<br>2      | 1<br>4.<br>5<br>1           | 0.<br>7<br>1           | 2<br>1<br>8.<br>7<br>7            |
|                                           | de<br>Fa<br>c¸<br>a | 5<br>0.<br>4<br>5           | 4.<br>5<br>1           | 1<br>2.<br>3<br>5      | 7.<br>2<br>6                | 0.<br>2<br>7           | 8<br>2.<br>0<br>4                 |
| lan<br>d<br>Sw<br>i<br>tze<br>r           | f<br>Ro<br>o        | 6<br>7.<br>1<br>2           | 2<br>1.<br>9<br>0      | 2<br>1.<br>0<br>5      | 1<br>2.<br>8<br>0           | 1<br>5.<br>3<br>6      | 1<br>3<br>8.<br>2<br>2            |
|                                           | de<br>Fa<br>c¸<br>a | 2<br>5.<br>1<br>7           | 2.<br>7<br>4           | 7.<br>8<br>9           | 6.<br>4<br>0                | 5.<br>7<br>6           | 5<br>1.<br>8<br>3                 |
| d<br>do<br>i<br>ing<br>Un<br>K<br>te<br>m | f<br>Ro<br>o        | 6<br>0<br>1.<br>8<br>8      | 7<br>1.<br>0<br>9      | 6<br>1.<br>6<br>1      | 1<br>6<br>8.<br>2<br>4      | 1<br>1.<br>8<br>5      | 9<br>1<br>4.<br>6<br>7            |
|                                           | de<br>Fa<br>c¸<br>a | 2<br>2<br>5.<br>7<br>0      | 8.<br>8<br>9           | 2<br>3.<br>1<br>0      | 8<br>4.<br>1<br>2           | 5.<br>7<br>6           | 3<br>4<br>3.<br>0<br>0            |
| i<br>d<br>S<br>Un<br>te<br>ta<br>tes      | f<br>Ro<br>o        | 6<br>7<br>9<br>1.<br>8<br>3 | 3<br>2<br>2.<br>9<br>1 | 6<br>0<br>2.<br>7<br>6 | 2<br>2<br>6<br>0.<br>3<br>6 | 1<br>1<br>8.<br>4<br>0 | 1<br>0,<br>0<br>9<br>6.<br>2<br>6 |
|                                           | de<br>Fa<br>c¸<br>a | 2<br>5<br>4<br>6.<br>9<br>4 | 4<br>0.<br>3<br>6      | 2<br>2<br>6.<br>0<br>4 | 1<br>1<br>3<br>0.<br>1<br>8 | 4<br>4.<br>4<br>0      | 3<br>7<br>8<br>6.<br>1<br>0       |

Source: International Energy Agency, <sup>2002</sup> [\[69\]](#page-65-0).

<span id="page-27-0"></span>TABLE 3 Potential Electricity Generation Capacity of BIPVs for Selected Countries of IEA

| Solar Electricity Potential of BIPVs | Potential of<br>Roofs (TWh/yr) | Potential of<br>Façades (TWh/yr) | Total Potential<br>(TWh/yr) | Actual<br>Consumption<br>(TWh) | Potential-<br>Demand ratio<br>(%) |
|--------------------------------------|--------------------------------|----------------------------------|-----------------------------|--------------------------------|-----------------------------------|
| Australia                            | 68.176                         | 15.881                           | 84.057                      | 182.24                         | 46.1                              |
| Austria                              | 15.197                         | 3.528                            | 18.725                      | 53.93                          | 34.7                              |
| Canada                               | 118.708                        | 33.054                           | 151.762                     | 495.31                         | 30.6                              |
| Denmark                              | 8.710                          | 2.155                            | 10.865                      | 34.43                          | 31.6                              |
| Finland                              | 11.763                         | 3.063                            | 14.827                      | 76.51                          | 19.4                              |
| Germany                              | 128.296                        | 31.745                           | 160.040                     | 531.64                         | 30.1                              |
| Italy                                | 103.077                        | 23.827                           | 126.904                     | 282.01                         | 45.0                              |
| Japan                                | 117.416                        | 29.456                           | 146.872                     | 1012.94                        | 14.5                              |
| Netherlands                          | 25.677                         | 6.210                            | 31.887                      | 99.06                          | 32.2                              |
| Spain                                | 70.689                         | 15.784                           | 86.473                      | 180.17                         | 48.0                              |
| Sweden                               | 21.177                         | 5.515                            | 26.692                      | 137.12                         | 19.5                              |
| Switzerland                          | 15.044                         | 3.367                            | 18.410                      | 53.17                          | 34.6                              |
| United Kingdom                       | 83.235                         | 22.160                           | 105.395                     | 343.58                         | 30.7                              |

Source: International Energy Agency, 2002. Potential for Building Integrated Photovoltaics. Report IEA-PVPST7-4:2002 (www.iea-pvps.org/index.php?id=9&eID=dam\_frontend\_push&docID=394)

<span id="page-28-0"></span>

| TABLE 4<br>Outstanding BIPV Projects in Hong Kong |                                |                   |                           |                        |
|---------------------------------------------------|--------------------------------|-------------------|---------------------------|------------------------|
| Project Name and Pic                              | Project Details                |                   |                           |                        |
|                                                   | Hong Kong<br>Science<br>Park   | Type of<br>panels | Total PV<br>area (m2<br>) | Rated<br>power<br>(kW) |
|                                                   | Sun Shading<br>BIPVs           | Mono-Si           | 129.8                     | 18.48                  |
| BIPVs of Hong Kong Science Park                   | Roof and<br>facade of<br>BIPVs | Mono-Si           | 2288                      | 120                    |
|                                                   | Roof rack<br>BIPVs             | Mono-Si           | 602                       | 60                     |
|                                                   | Wan Chai<br>Tower              | Type of<br>panels | Total PV<br>area (m2<br>) | Rated<br>power<br>(kW) |
|                                                   | Roof rack<br>BIPVs             | Poly -Si          | 164.7                     | 20.16                  |
|                                                   | Sun Shading<br>BIPVs           | Mono-Si           | 231.84                    | 25.80                  |
| BIPVs of Wan Chai Tower                           | Skylight<br>BIPVs              | Mono-Si           | 95.98                     | 10.08                  |
|                                                   | Wan Chai<br>Tower              | Type of<br>panels | Panel<br>number           | Rated<br>power<br>(kW) |
|                                                   | Roof light<br>BIPVs            | Poly-Si           | 52                        | 2.0                    |
| BIPVs of Ma Wan School                            | Deck<br>Shading<br>BIPVs       | CIS thin<br>film  | 480                       | 16.8                   |
|                                                   | Canopy<br>BIPVs                | a-Si              | 21                        | 2.4                    |
|                                                   |                                |                   |                           |                        |

# 4.1.2 Electricity Generation Capacity of BIPV in Buildings

Successful operations and promising electricity yields of existing BIPV systems would be an incentive for improving public awareness and clients' confidence on BIPV technology. Table 4 presents some outstanding BIPV projects in Hong Kong. The BIPV system in Hong Kong Science Park consists of sun shading-integrated PVs, roof and fac¸ade-integrated PVs, and roof rackintegrated PVs. The total active PV area is 3020m2 , which produces totally

TABLE 5Success Examples of BIPV Systems Around the World

| Pr<br>j<br>Na<br>t<br>o<br>ec<br>m<br>e                                        | f<br>du<br>Br<br>ie<br>In<br>io<br>tro<br>t<br>c<br>n                            |                                                   |                                            |                                                  |                                                                         |  |
|--------------------------------------------------------------------------------|----------------------------------------------------------------------------------|---------------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|--|
|                                                                                | S<br>i<br>te                                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |  |
| ive<br>Co<br>Ins<br>To<br>t<br>-o<br>p<br>er<br>a<br>ur<br>an<br>ce<br>we<br>r | he<br>M<br>te<br>an<br>c<br>s<br>r,<br>i<br>d<br>k<br>ing<br>do<br>Un<br>te<br>m | de<br>Fa<br>c¸<br>a<br>in<br>d<br>teg<br>te<br>ra | –                                          | 1<br>3<br>9                                      | 1<br>8<br>0                                                             |  |
|                                                                                | S<br>i<br>te                                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>r<br>y |  |
| he<br>T<br>V<br>is<br>io<br>ire<br>na                                          | ha<br>M<br>t<br>ta<br>an<br>n,<br>d<br>Un<br>i<br>te<br>ta<br>tes<br>s           | de<br>Fa<br>c¸<br>a<br>d<br>in<br>teg<br>te<br>ra | –                                          | 4<br>8                                           | 5<br>0                                                                  |  |
| do<br>l<br>l<br>C<br>i<br>Lo<br>Ha<br>ty<br>n<br>n                             | S<br>i<br>te                                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |  |
|                                                                                | do<br>d<br>Lo<br>Un<br>i<br>te<br>n<br>n,<br>do<br>K<br>ing<br>m                 | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra        | –                                          | 6<br>8.<br>8                                     | 4<br>9                                                                  |  |

|                                             | Site            | Integration mode               | Panel<br>type       | Active<br>area (m²) | PV power<br>(kWp)       | Power yield<br>(MWh/yr) |
|---------------------------------------------|-----------------|--------------------------------|---------------------|---------------------|-------------------------|-------------------------|
| Berlin Central Station                      | Berlin, Germany | Overhead integrated            | Mono-Si             | 1870                | 189                     | 160                     |
|                                             | Site            | Integration mode               | Panel<br>type       | Active<br>area (m²) | PV power<br>(kWp)       | Power yield<br>(MWh/yr) |
| Academy Mont-Cenis                          | Herne, Germany  | Overhead and façade integrated | Si                  | 8400                | 1000                    | 750                     |
| 31.                                         | Site            | Integration mode               | Panel<br>type       | Active<br>area (m²) | PV power<br>(kWp)       | Power yield<br>(MWh/yr) |
| Our Lady Hospital, Aalst                    | Aalst, Belgium  | Façade<br>integrated           | Mono-Si             | 480                 | 46                      | 31                      |
| The last last last last last last last last | Site            | Integration mode               | Active<br>area (m²) | PV power (kWp)      | Power yield<br>(MWh/yr) |                         |
|                                             | Mataró, Spain   | Façade<br>integration          | 603                 | 52.7                | 50                      |                         |
| Pompeu Fabra Library                        |                 |                                |                     |                     |                         |                         |

| j<br>Pr<br>t<br>Na<br>o<br>ec<br>m<br>e                                                 | f<br>ie<br>du<br>io<br>Br<br>In<br>tro<br>t<br>c<br>n                     |                                                                                  |                                            |                                                  |                                                                         |                                                                         |
|-----------------------------------------------------------------------------------------|---------------------------------------------------------------------------|----------------------------------------------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
|                                                                                         | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                     | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
| f<br>f<br>fa<br>M<br>in<br>is<br>Ec<br>ic<br>A<br>irs<br>try<br>o<br>on<br>om           | l<br>in,<br>Ge<br>Be<br>r<br>rm<br>an<br>y                                | fac<br>i<br>l<br>d<br>de<br>T<br>te<br>a<br>¸<br>in<br>io<br>teg<br>t<br>ra<br>n | 9<br>2<br>0                                | 1<br>0<br>0                                      | –                                                                       |                                                                         |
|                                                                                         | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                     | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
|                                                                                         | lon<br>Sp<br>in<br>Ba<br>rce<br>a,<br>a                                   | b<br>le<br>k<br>Do<br>in<br>P<br>V<br>u<br>s<br>fac<br>de<br>a<br>¸              | 1<br>2<br>5                                | 1<br>8                                           | –                                                                       |                                                                         |
| da<br>d<br>de<br>l<br>le<br>Un<br>ive<br>i<br>La<br>Sa<br>rs                            |                                                                           |                                                                                  |                                            |                                                  |                                                                         |                                                                         |
|                                                                                         | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                     | l<br>Pa<br>ne<br>ty<br>p<br>e              | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|                                                                                         | Sa<br>isc<br>Fra<br>n<br>nc<br>o,<br>d<br>Un<br>i<br>S<br>te<br>ta<br>tes | f<br>d<br>in<br>Ro<br>teg<br>te<br>o<br>ra                                       | S<br>i                                     | 1<br>8,<br>3<br>0<br>0                           | 1<br>7<br>2                                                             | 2<br>1<br>3                                                             |
| fo<br>f<br>l<br>de<br>Ca<br>i<br>ia<br>Ac<br>Sc<br>ien<br>rn<br>a<br>my<br>o<br>ce<br>s |                                                                           |                                                                                  |                                            |                                                  |                                                                         |                                                                         |

|                                                                                                                                  | S<br>i<br>te                                                       | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|----------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------|-------------------------------------------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|
| l<br>he<br>B<br>M<br>W<br>W<br>M<br>€<br>t<br>e<br>un<br>c<br>n                                                                  | h,<br>M<br>ic<br>un<br>ia,<br>Ba<br>va<br>r<br>Ge<br>rm<br>an<br>y | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra                                    | 1<br>6,<br>0<br>0<br>0                     | 8<br>2<br>4                                      | –                                                                       |
|                                                                                                                                  | S<br>i<br>te                                                       | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|                                                                                                                                  | €<br>b<br>ing<br>Tu<br>en<br>,<br>Ge<br>rm<br>an<br>y              | de<br>Fa<br>c¸<br>a<br>d<br>in<br>teg<br>te<br>ra                             | 5<br>2<br>0                                | 4<br>3.<br>7                                     | 3<br>0                                                                  |
| l<br>Pa<br>Ho<br>Ar<br>u<br>rn<br>en<br>a                                                                                        |                                                                    |                                                                               |                                            |                                                  |                                                                         |
|                                                                                                                                  | S<br>i<br>te                                                       | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| Ho<br>F<br>ire<br>S<br>io<br>te<br>ta<br>t<br>u<br>n<br>n                                                                        | Ho<br>te<br>u<br>n,<br>he<br>lan<br>ds<br>Ne<br>t<br>r             | f a<br>fac<br>d<br>de<br>Ro<br>o<br>n<br>a<br>¸<br>d<br>in<br>teg<br>te<br>ra | 4<br>0<br>0                                | 2<br>3.<br>9                                     | –                                                                       |
|                                                                                                                                  | S<br>i<br>te                                                       | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| lan<br>d<br>l<br>lw<br>l<br>l<br>Co<br>Is<br>S<br>i<br>Av<br>t<br>ne<br>y<br>e<br>e<br>bw<br>Su<br>S<br>io<br>ta<br>t<br>ay<br>n | k<br>ly<br>Br<br>oo<br>n,<br>d<br>Un<br>i<br>S<br>te<br>ta<br>tes  | f<br>d<br>in<br>Ro<br>teg<br>te<br>o<br>ra                                    | 7<br>0<br>6<br>0                           | 1<br>6<br>0                                      | 2<br>0<br>0                                                             |

| l<br>f<br>T<br>A<br>B<br>L<br>E<br>5<br>S<br>Ex<br>u<br>c<br>c<br>e<br>s<br>s<br>a<br>m<br>p<br>e<br>s<br>o | d<br>h<br>l<br>d—<br>'d<br>B<br>I<br>P<br>V<br>S<br>A<br>W<br>t<br>t<br>t<br>y<br>s<br>e<br>m<br>s<br>r<br>o<br>u<br>n<br>e<br>o<br>r<br>c<br>o<br>n |
|-------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                             |                                                                                                                                                      |

| Pr<br>j<br>Na<br>t<br>o<br>ec<br>m<br>e             | f<br>du<br>Br<br>ie<br>In<br>io<br>tro<br>t<br>c<br>n            |                                                   |                                            |                                                  |                                                                         |                                                                         |
|-----------------------------------------------------|------------------------------------------------------------------|---------------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
|                                                     | S<br>i<br>te                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
| lm<br>l<br>le<br>is<br>He<br>L<br>Ha<br>t<br>t<br>u | Gr<br>Au<br>ia<br>tr<br>az<br>s<br>,                             | de<br>Fa<br>c¸<br>a<br>d<br>in<br>teg<br>te<br>ra | 3<br>5<br>6                                | 3<br>5.<br>6                                     | 2<br>6                                                                  |                                                                         |
|                                                     | S<br>i<br>te                                                     | io<br>de<br>In<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | ie<br>l<br>d<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
| lar<br>Ca<br>So<br>sa<br>a                          | lan<br>d<br>Sw<br>i<br>tze<br>r                                  | de<br>Fa<br>c¸<br>a<br>d<br>in<br>teg<br>te<br>ra | 3<br>5<br>6                                | 3<br>4.<br>4                                     | 2<br>5                                                                  |                                                                         |
|                                                     | S<br>i<br>te                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
|                                                     | lan<br>d<br>Sw<br>i<br>tze<br>r                                  | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra        | 1<br>6<br>1                                | 2<br>0.<br>6                                     | 2<br>8                                                                  |                                                                         |
| l<br>De<br>Ze<br>ta<br>ro                           |                                                                  |                                                   |                                            |                                                  |                                                                         |                                                                         |
|                                                     | S<br>i<br>te                                                     | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o      | l<br>Pa<br>ne<br>ty<br>p<br>e              | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|                                                     | ina<br>ha<br>do<br>J<br>S<br>n,<br>n<br>ng<br>,<br>h<br>C<br>ina | f<br>in<br>d<br>Ro<br>teg<br>te<br>o<br>ra        | ly-<br>i<br>Po<br>S                        | 9<br>5<br>0<br>0                                 | 4<br>5<br>0                                                             | 5<br>6<br>0                                                             |
| ha<br>do<br>S<br>M<br>n<br>ng<br>us<br>eu<br>m      |                                                                  |                                                   |                                            |                                                  |                                                                         |                                                                         |

475

|                                                                                                            | S<br>i<br>te                                                            | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e              | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
| l<br>(<br>h<br>)<br>Ca<br>i<br>M<br>C<br>ina<br>ta<br>p<br>us<br>eu<br>m                                   | h<br>i<br>j<br>ing<br>C<br>ina<br>Be<br>,                               | f<br>d<br>in<br>Ro<br>teg<br>te<br>o<br>ra                                    | S<br>i<br>a-                               | 5<br>0<br>0<br>0                                 | 3<br>0<br>0                                                             | –                                                                       |
|                                                                                                            | S<br>i<br>te                                                            | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
|                                                                                                            | i<br>l<br>in,<br>Q<br>ing<br>ha<br>i,<br>X<br>h<br>C<br>ina             | f a<br>fac<br>d<br>de<br>Ro<br>o<br>n<br>a<br>¸<br>d<br>in<br>teg<br>te<br>ra | 1<br>6<br>0<br>0                           | 1<br>8<br>6.<br>6                                | 2<br>2<br>0                                                             |                                                                         |
| ha<br>d<br>Q<br>ing<br>i s<br>ien<br>c<br>ce<br>an<br>hn<br>log<br>Te<br>M<br>c<br>o<br>us<br>eu<br>m<br>y |                                                                         |                                                                               |                                            |                                                  |                                                                         |                                                                         |
|                                                                                                            | S<br>i<br>te                                                            | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e              | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| ho<br>l<br>bu<br>l<br>d<br>in<br>io<br>i<br>Z<br>te<br>t<br>n<br>rn                                        | ho<br>Ha<br>ng<br>z<br>u,<br>he<br>h<br>j<br>ian<br>C<br>ina<br>Z<br>g, | f a<br>d<br>fac<br>de<br>Ro<br>o<br>n<br>a<br>¸<br>d<br>in<br>teg<br>te<br>ra | M<br>S<br>i<br>on<br>o-                    | 1<br>2<br>1<br>0                                 | 0<br>0<br>4                                                             | 2<br>9<br>0                                                             |
| ing<br>ng<br>na<br>a<br>na<br>ls<br>ke<br>ia<br>te<br>t<br>ma<br>r<br>m<br>ar                              |                                                                         |                                                                               |                                            |                                                  |                                                                         |                                                                         |
|                                                                                                            | S<br>i<br>te                                                            | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>r<br>y |                                                                         |
|                                                                                                            | h<br>Be<br>i<br>j<br>ing<br>C<br>ina<br>,                               | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra                                    | 1<br>0<br>0<br>0                           | 1<br>0<br>2.<br>5                                | 2<br>6                                                                  |                                                                         |
| h<br>l<br>C<br>ina<br>Na<br>io<br>Gy<br>iu<br>t<br>na<br>m<br>na<br>s<br>m                                 |                                                                         |                                                                               |                                            |                                                  |                                                                         |                                                                         |

 TABLE 5 Success Examples of BIPV Systems Around the World—cont'd

| Project Name                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Brief Introduction                | Brief Introduction         |               |                     |                   |                         |  |  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------|----------------------------|---------------|---------------------|-------------------|-------------------------|--|--|
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Site                              | Integration mode           | Panel<br>type | Active<br>area (m²) | PV power (kWp)    | Power yield<br>(MWh/yr) |  |  |
| Suntech Eco Building                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Wuxi, Jiangsu,<br>China           | Roof and façade integrated | Si            | 6900                | 1010              | 1020                    |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Site                              | Integration mode           | Panel<br>type | Active<br>area (m²) | PV power (kWp)    | Power yield<br>(MWh/yr) |  |  |
| Canton Tower                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Guangzhou,<br>Guangdong,<br>China | Façade<br>integrated       | Thin film     | 1120                | 20                | 12.66                   |  |  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Site                              | Integration mode           | Panel<br>type | Active<br>area (m²) | PV power<br>(kWp) | Power yield<br>(MWh/yr) |  |  |
| A STATE OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PARTY OF THE PAR | Baoding, Hebei,<br>China          | Roof and façade integrated | Poly-Si       | -                   | 500               | 420                     |  |  |
| Power Valley Plaza Business<br>Conference Center                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                   |                            |               |                     |                   |                         |  |  |

477

|                                                                                                | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e                            | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|-------------------------------------------------------------------------------|----------------------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
| fac<br>As<br>M<br>Fa<br>tro<br>tu<br>to<br>ne<br>rg<br>y<br>an<br>u<br>re<br>c<br>ry           | ho<br>Ha<br>ng<br>z<br>u,<br>he<br>h<br>Z<br>j<br>ian<br>C<br>ina<br>g,   | f a<br>fac<br>d<br>de<br>Ro<br>o<br>n<br>a<br>¸<br>d<br>in<br>teg<br>te<br>ra | i,<br>M<br>S<br>on<br>o-<br>h<br>f<br>lm<br>in<br>i<br>t | –                                                | 5<br>1<br>0                                                             | 5<br>5<br>8.<br>8                                                       |
|                                                                                                |                                                                           |                                                                               |                                                          |                                                  |                                                                         |                                                                         |
|                                                                                                | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m               | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
|                                                                                                | ho<br>Ha<br>ng<br>z<br>u,<br>he<br>h<br>Z<br>j<br>ian<br>C<br>ina<br>g,   | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra                                    | 7<br>9,<br>0<br>0<br>0                                   | 1<br>0,<br>0<br>0<br>0                           | 1<br>0,<br>0<br>0<br>0                                                  |                                                                         |
| ho<br>lw<br>i<br>S<br>io<br>Ha<br>Ea<br>Ra<br>t<br>ta<br>t<br>ng<br>z<br>u<br>s<br>ay<br>n     |                                                                           |                                                                               |                                                          |                                                  |                                                                         |                                                                         |
|                                                                                                | S<br>i<br>te                                                              | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e                            | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| ha<br>b<br>l<br>l<br>l<br>i<br>i<br>ic<br>Cu<br>Ce<br>W<br>Pu<br>tu<br>te<br>e<br>ra<br>n<br>r | i<br>ha<br>i,<br>W<br>e<br>ha<br>do<br>h<br>S<br>C<br>ina<br>n<br>ng<br>, | f<br>in<br>d<br>Ro<br>teg<br>te<br>o<br>ra                                    | f<br>h<br>in<br>i<br>lm<br>T                             | 7<br>8<br>0<br>0                                 | 4<br>8<br>0                                                             | 3<br>3<br>0                                                             |
|                                                                                                | S<br>i<br>te                                                              | de<br>io<br>In<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e                            | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>ie<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| lw<br>ian<br>j<br>in<br>i<br>S<br>io<br>T<br>W<br>Ra<br>t<br>ta<br>t<br>es<br>ay<br>n          | h<br>T<br>ian<br>j<br>in,<br>C<br>ina                                     | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra                                    | S<br>i<br>a-                                             | 3<br>6,<br>0<br>0<br>0                           | 1<br>8<br>8<br>4                                                        | 2<br>0<br>0<br>0                                                        |

TABLE 5Success Examples of BIPV Systems Around the World—cont'd

| j<br>Pr<br>t<br>Na<br>o<br>ec<br>m<br>e                                                              | f<br>ie<br>du<br>io<br>Br<br>In<br>tro<br>t<br>c<br>n                             |                                                                               |                                                 |                                                  |                                                                         |                                                                         |
|------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|-------------------------------------------------------------------------------|-------------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
|                                                                                                      | S<br>i<br>te                                                                      | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e                   | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
|                                                                                                      | ha<br>ha<br>C<br>ng<br>s<br>,<br>h<br>Hu<br>C<br>ina<br>na<br>n,                  | f a<br>d<br>fac<br>de<br>Ro<br>o<br>n<br>a<br>¸<br>d<br>in<br>teg<br>te<br>ra | S<br>i,<br>M<br>on<br>o-<br>ly-<br>Po<br>S<br>i | –                                                | 9<br>6.<br>8<br>2                                                       | 3<br>7.<br>5                                                            |
| ha<br>ha<br>l<br>d<br>C<br>S<br>C<br>Ec<br>Bu<br>i<br>ing<br>ng<br>s<br>c                            |                                                                                   |                                                                               |                                                 |                                                  |                                                                         |                                                                         |
|                                                                                                      | S<br>i<br>te                                                                      | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o                                  | l<br>Pa<br>ne<br>ty<br>p<br>e                   | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| ho<br>h<br>lw<br>Gu<br>So<br>Ra<br>i<br>t<br>an<br>g<br>z<br>u<br>u<br>ay<br>S<br>io<br>ta<br>t<br>n | Gu<br>ho<br>an<br>g<br>z<br>u,<br>do<br>Gu<br>an<br>g<br>ng<br>,<br>h<br>C<br>ina | f<br>in<br>d<br>Ro<br>teg<br>te<br>o<br>ra                                    | S<br>i<br>M<br>on<br>o-                         | 5<br>0<br>1<br>6                                 | 2<br>5<br>3                                                             | 2<br>6<br>0                                                             |
| h<br>lw<br>Be<br>i<br>j<br>ing<br>So<br>Ra<br>i<br>S<br>io<br>t<br>ta<br>t<br>u<br>ay<br>n           | S<br>i<br>te                                                                      | io<br>de<br>In<br>teg<br>t<br>ra<br>n m<br>o                                  | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m      | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | ie<br>l<br>d<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>r<br>y |                                                                         |
|                                                                                                      | h<br>Be<br>i<br>j<br>ing<br>C<br>ina<br>,                                         | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra                                    | 7<br>0<br>0<br>0                                | 2<br>4<br>0                                      | 2<br>2<br>3.<br>6                                                       |                                                                         |

479

|                                                                                                                                                                                     | i<br>S<br>te                                                                 | io<br>de<br>In<br>teg<br>t<br>ra<br>n m<br>o | l<br>Pa<br>ne<br>ty<br>p<br>e              | ive<br>Ac<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | ie<br>l<br>d<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>r<br>y |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|----------------------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|
| ha<br>i<br>lw<br>S<br>io<br>W<br>Ra<br>ta<br>t<br>u<br>n<br>ay<br>n                                                                                                                 | ha<br>be<br>W<br>Hu<br>i,<br>n,<br>u<br>h<br>C<br>ina                        | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra   | S<br>i                                     | 1<br>5,<br>2<br>0<br>0                           | 2<br>2<br>0<br>0                                                        | 2<br>0<br>0<br>0                                                        |
|                                                                                                                                                                                     | S<br>i<br>te                                                                 | io<br>de<br>In<br>teg<br>t<br>ra<br>n m<br>o | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | ie<br>l<br>d<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>r<br>y |                                                                         |
| S<br>he<br>he<br>io<br>l<br>In<br>te<br>t<br>nz<br>n<br>rn<br>a<br>na<br>ds<br>low<br>La<br>F<br>Ex<br>i<br>io<br>t<br>n<br>ca<br>p<br>e<br>er<br>s<br>p<br>os<br>n<br>k<br>Pa<br>r | he<br>he<br>S<br>nz<br>n,<br>do<br>Gu<br>an<br>g<br>ng<br>,<br>h<br>C<br>ina | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra   | –                                          | 1<br>0<br>0<br>0                                 | 1<br>0<br>0<br>0                                                        |                                                                         |
|                                                                                                                                                                                     | S<br>i<br>te                                                                 | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o | l<br>Pa<br>ne<br>ty<br>p<br>e              | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m       | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p                        | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |
| h<br>lw<br>Na<br>j<br>ing<br>So<br>Ra<br>i<br>S<br>io<br>t<br>ta<br>t<br>n<br>u<br>ay<br>n                                                                                          | Na<br>j<br>ing<br>J<br>ian<br>n<br>g<br>su<br>,<br>,<br>C<br>h<br>ina        | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra   | S<br>i                                     | 8<br>2,<br>0<br>0<br>0                           | 1<br>0,<br>6<br>7<br>0                                                  | 9<br>2<br>3<br>0                                                        |
|                                                                                                                                                                                     | S<br>i<br>te                                                                 | de<br>In<br>io<br>teg<br>t<br>ra<br>n m<br>o | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>Po<br>ie<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |                                                                         |
|                                                                                                                                                                                     | ha<br>ha<br>h<br>S<br>i,<br>C<br>ina<br>ng                                   | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra   | 1,<br>6<br>0<br>0<br>0                     | 6<br>6<br>8<br>8                                 | 6<br>3<br>0<br>0                                                        |                                                                         |
| ha<br>ha<br>lw<br>S<br>i<br>Ho<br>iao<br>Ra<br>i<br>ng<br>ng<br>q<br>ay<br>S<br>io<br>ta<br>t<br>n                                                                                  |                                                                              |                                              |                                            |                                                  |                                                                         |                                                                         |

| j<br>Pr<br>t<br>Na<br>o<br>ec<br>m<br>e                                                   | ie<br>f<br>du<br>io<br>Br<br>In<br>tro<br>t<br>c<br>n                        |                                              |                               |                                            |                                                  |                                                                         |  |
|-------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|----------------------------------------------|-------------------------------|--------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|--|
| he<br>he<br>h<br>lw<br>S<br>No<br>Ra<br>i<br>S<br>io<br>t<br>ta<br>t<br>nz<br>n<br>r<br>n | S<br>i<br>te                                                                 | de<br>io<br>In<br>teg<br>t<br>ra<br>n m<br>o | l<br>Pa<br>ne<br>ty<br>p<br>e | Ac<br>ive<br>t<br>2)<br>(<br>ar<br>ea<br>m | P<br>V<br>p<br>ow<br>er<br>(<br>k<br>)<br>W<br>p | l<br>d<br>ie<br>Po<br>we<br>r y<br>(<br>h<br>/<br>)<br>M<br>W<br>y<br>r |  |
| ay                                                                                        | he<br>he<br>S<br>nz<br>n,<br>do<br>Gu<br>an<br>g<br>ng<br>,<br>h<br>C<br>ina | f<br>d<br>Ro<br>in<br>teg<br>te<br>o<br>ra   | S<br>i                        | 7<br>8<br>9<br>6                           | 5<br>0<br>1.<br>4                                | 5<br>3<br>7                                                             |  |

(Source: [www.bipvcn.org\)](http://www.bipvcn.org)

198 kW electricity by employing monocrystalline Si PV modules. The BIPV system of Wan Chai Tower also includes various PV components, including roof rack PVs, sun-shading PVs, and skylight PVs. Installing monocrystalline or polycrystalline Si modules on the active area of 492.52m<sup>2</sup> , the whole system can generate 56.04 kW electricity. The BIPV system in Ma Wan School is composed of roof light PVs, deck shading PVs, and canopy PVs. Polycrystalline Si, amorphous Si, and CIS thin-film PV modules are employed in this system. With the total area of 553m2 , the rated power of the whole BIPV system is 21.2 kW.

Around the world, there are a large number of publications that reported successfully implemented BIPV projects and advanced BIPV technologies and systems. [Table 6](#page-41-0) summarizes the location, integration mode, active area, PV power, and the electricity yield of some success examples of BIPV application around the world. The electricity generation capacities of the BIPV projects illustrated in [Table 4](#page-28-0) show great diversity depending on their building scale and active area. The active area of the PV modules varies from 161 to 82,000m2 ; accordingly, the rated electricity generation capacity ranges between 18 and 10,670 kWp. Obviously, BIPV technology brings great potential for modern buildings in terms of on-site electricity productions. The experiences and skills accumulated in these BIPV systems can not only provide technical supports for design and construction of new BIPV systems, but also strengthen designer and investor's confidence on this technology.

# 4.1.3 Available Software Programs for Predicting the Electricity Output

Along with the development of PV technologies and applications, various types of software programs have also been developed, as these simulation programs are required by every part of BIPV stakeholders. PV manufacturers employ software to perform economic analysis on their products; designers and researchers require software programs to conduct performance evaluation to support their design and research; clients and end users need software to perform output simulations and to compare the results to measured data for identifying system faults.

A number of software programs are now available for evaluating the energy output of grid-connected or stand-alone PV systems. Most of previous simulation programs are commercial tools which were developed to support the design or the comprehensive analysis of PV systems. [Table 6](#page-41-0) summarizes the most commonly used simulation programs for PV systems [\[15\]](#page-62-0).

Using these software programs, the potential power generation capacity of a PV system can be accurately predicted on the premise that the design details, including the site, size, module information, technical details of the system, etc. are imported into these programs. The simulation results can be the hourly, weekly, monthly, or yearly electricity output. The energy production and savings, the cost assessment, the emission reductions, the financial viability, and

Environmental Sciences, University of Geneva, Switzerland

Co. Ltd., Japan

Maui Solar Energy Software Corporation, Haik, United States

Solar Pro Laplace Systems

PV-Design Pro

<span id="page-41-0"></span>

| TABLE 6                           | Most Commonly Used PV Simulation Programs                                                                  |                                                                                    |                                          |
|-----------------------------------|------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------|------------------------------------------|
| Software<br>Name                  | Software<br>Developer                                                                                      | Cost/License                                                                       | Website                                  |
| ESP-r                             | Energy Systems<br>Research Unit of<br>the University of<br>Strathclyde, and<br>Natural Resources<br>Canada | Free                                                                               | www.esru.strath.ac.<br>uk/Programs/ESP-r |
| RETScreen                         | National<br>Resources Canada                                                                               | Free                                                                               | www.retscreen.net                        |
| PV F-Chart                        | University of<br>Wisconsin,<br>United States                                                               | \$400 for single<br>user, \$600 for<br>educational site                            | www.fchart.com                           |
| Solar<br>Design<br>Tool           | Verdiseno, Inc.,<br>Santa Cruz,<br>United States                                                           | Free version<br>available and<br>expert version<br>available with a<br>monthly fee | www.<br>solardesigntool.com              |
| INSEL                             | Insel Company,<br>Germany                                                                                  | €1700 for full<br>version; €85 full<br>version for students                        | www.insel.eu                             |
| TRNSYS                            | University of<br>Wisconsin,<br>United States                                                               | \$2520 for<br>Educational use                                                      | sel.me.wisc.edu/<br>trnsys/              |
| NREL<br>Solar<br>Advisor<br>Model | National<br>Renewable Energy<br>Laboratory,<br>United States                                               | Free                                                                               | sam.nrel.gov/                            |
| PVSyst                            | Institute of                                                                                               | 1300CHF for 1st                                                                    | www.pvsyst.com/en/                       |

license, 1000/ 700CHF for 2nd/ 3rd license

\$1900 for educational use

\$249 for solar design studio CD-ROM

[www.lapsys.co.jp/](http://www.lapsys.co.jp/english/)

[mauisolarsoftware.](http://www.mauisolarsoftware.com/)

[english/](http://www.lapsys.co.jp/english/)

[www.](http://www.mauisolarsoftware.com/)

[com/](http://www.mauisolarsoftware.com/)

<span id="page-42-0"></span>

| TABLE 6          |                                                              | Most Commonly Used PV Simulation Programs—cont'd                                                          |                                  |
|------------------|--------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|----------------------------------|
| Software<br>Name | Software<br>Developer                                        | Cost/License                                                                                              | Website                          |
| PV*SOL           | Dr. Valentin<br>Energie Software,<br>Germany                 | €895 for PV*SOL<br>and €1295 for<br>PV*SOL premium                                                        | www.valentin<br>software.com/en  |
| HOMER            | National<br>Renewable Energy<br>Laboratory,<br>United States | \$125/175/250 per<br>year for student<br>license, \$750/<br>1500/2250 per<br>year for academic<br>license | www.homerenergy.<br>com/         |
| pvPlanner        | GeoModel Solar s.<br>r.o., Slovak<br>Republic                | €1500/yr. for full<br>coverage                                                                            | solargis.info/<br>pvplanner      |
| Polysun          | Vela Solaris AG,<br>Switzerland                              | €199 educational<br>license;<br>€1999 for<br>professional                                                 | www.velasolaris.<br>com/english/ |

the risk assessment can be performed based on the simulation results of these software tools. Software programs enable modeling and analyzing the performance of PV projects for stakeholders, including architects, designers, engineers, researchers, financial planners, and investors.

Moreover, there are some other software programs available today, which are specially developed for system economic evaluation, system monitoring and controlling, site analysis and management, such as SOLinvest, Solmetric PV Designer, DDS-CAD PV, Meteodyn PV, Archelios, Solarius PV, REA System Sizing Tool, Meteocontrol, SolarEye, METEONORM, Shadow Analyser, Shadows, SKELION, BlueSol, Energy Periscope, GOSOL, BPS Asset Management, etc.

# 4.2 Effect of BIPVs on Heat Gain/Loss or Heating/Cooling Load

In BIPV systems, the shading effect of PV modules can reduce the heat gain through external envelopes significantly, thus can greatly affect the heating or cooling load, and can further reduce the energy requirement of indoor HVAC systems. Thus, the thermal performance is another research hotspot of BIPV systems. Many researchers have carried out both experimental and numerical studies on the impacts of BIPV on heat gain and indoor cooling load.

<span id="page-43-0"></span>Peng et al. [16–[18\]](#page-62-0) conducted an experimental study of the thermal performance of a novel PV-DSF in Hong Kong. The results revealed that the ventilated mode of the PV-DSF provides the lowest solar heat gain coefficient (SHGC), while the non-ventilated mode is effective in reducing heat loss. Peng et al. [\[16](#page-62-0)–18] also investigated the annual thermal performance of a multi-layer PV fac¸ade. The numerical results showed that, compared with a normal wall, a south-facing PV fac¸ade could reduce heat gain by 51% in summer under Hong Kong weather conditions, and the heat gain and heat loss through the PV wall in winter could be reduced by 69% and 32%, respectively.

Yang et al. [\[19\]](#page-62-0) studied the thermal performance of PV walls in different climates of China. They concluded that the cooling load can be reduced by 33%–50% when a PV wall is used to substitute a conventional wall system. Ji et al. [\[20\]](#page-62-0) investigated the dynamic thermal performance of a PV wall system in Hong Kong. The results demonstrated that the total heat gain can be reduced by 53%–59.2% during a summer period, when compare the PV wall system to normal external walls. Chow et al. [\[21\]](#page-62-0) investigated the cooling load reduction effect of a PV wall in Hong Kong. The results showed that the total heat gain through the PV wall was only 50.8% of that through a normal wall in summer.

Chow et al. [\[22,23\]](#page-63-0) conducted a comparative study on the performances of the single-glazed, double-glazed, naturally ventilated, and force-ventilated PV glazed windows. They concluded that the air-conditioning load could be reduced by 26% and 61% when single-glazed PV or naturally ventilated PV windows are employed to replace normal absorptive-glazed windows in a typical summer day. Later, a numerical study revealed that the air-conditioning power consumption could be reduced by 28% when applying the naturally ventilated PV double-glazing technology to a typical office building in Hong Kong [\[22,23\].](#page-63-0) He et al. [\[24\]](#page-63-0) comparatively studied the thermal performances of a single-glazed PV window and a double-glazed PV window. The experimental results showed that adding an air gap to PV modules can help to reduce the total heat gain and secondary heat gain of the double-glazed PV window by 78.3 and 51.8W, respectively.

Wang et al. [73] investigated the effects of four different types of roof-based PV systems on building's heating and cooling loads. The numerical results showed that PV roof with ventilated air-gap provides higher power efficiency and lower cooling load, thus, it is more appropriate for summer applications; while the non-ventilated PV roof is suitable to be used in winter since it provides a lower heating load in winter.

# 4.3 Overall Energy Performance of BIPV Systems

The overall performance of a BIPV includes the power performance, the thermal performance, and the optical performance for semitransparent BIPV systems. Unfortunately, in actual BIPV systems, stakeholders mainly focus on the power performance, while the thermal and optical impacts of BIPV systems are rarely studied. Investigations on the overall performance can only be traced in some literatures based on experimental or numerical studies. Some research institutes or groups have conducted a series of experimental and numerical research to evaluate the performance of BIPV system. This section reviews some literatures published by the Renewable Energy Research Group (RERG) of the Hong Kong Polytechnic University to show the overall energy performances of BIPV systems.

Peng et al. [\[25\]](#page-63-0) experimentally studied the power and thermal performances of a STPV double-skin fac¸ade. This BIPV system consists of an outer amorphous silicon PV laminate, an inner window and an internal airflow cavity, thus can achieve different operation modes (see Fig. 13). As the test results showed in [Fig. 14](#page-45-0), in accordance with the operating temperature, the electricity output of the PV-DSF under the ventilated mode is greater than that under non-ventilated modes by 3%. For the thermal performance, the average SHGCs of the ventilated and non-ventilated PV-DSFs were about 0.1 and 0.12, respectively, and the average U-values of the non-ventilated and ventilated PV-DSFs were 3.4 and 4.6, respectively. So the ventilated mode of the PV-DSF operating performs better in improving the electricity output and reducing solar heat gain, while the non-ventilated mode provides a better thermal insulation performance.

Later in 2016, Peng et al. [\[26\]](#page-63-0) numerically investigated the energy saving potential of the PV-DSF in Mediterranean climates. The schematic diagram of the PV-DSF in this research is illustrated in [Fig. 15](#page-45-0). The simulation results indicated that, using this south-facing PV-DSF in an office at Berkeley, the proposed PV-DSF was able to generate about 65 kWh/m2 electricity yearly. The direct solar heat gain coefficient (DSHGC) of the PV-DSF was as low

![](_page_44_Figure_5.jpeg)

FIG. 13 Cross-sectional structure of the semi-transparent PV double-skin fac¸ade. (Source: Peng J, Lu L, Yang H, et al. Comparative study of the thermal and power performances of a semi-transparent photovoltaic fac¸ade under different ventilation modes. Appl Energy 2015;138:572–83.)

<span id="page-45-0"></span>![](_page_45_Figure_2.jpeg)

FIG. 14 Operating temperatures and power outputs of PV-DSFs under ventilated and nonventilated mode. (Source: Peng J, Lu L, Yang H, et al. Comparative study of the thermal and power performances of a semi-transparent photovoltaic facade under different ventilation modes. Appl Energy 2015;138:572-83.)

![](_page_45_Picture_4.jpeg)

FIG. 15 Schematic diagram of the PV-DSF. (Source: Peng J, Curcija DC, Lu L, et al. Numerical investigation of the energy saving potential of a semi-transparent photovoltaic double-skin facade in a cool-summer Mediterranean climate. Appl Energy 2016;165:345–56.)

![](_page_46_Figure_2.jpeg)

**FIG. 16** Overall energy performance and net electricity use of the PV-DSF. (Source: Peng J, Curcija DC, Lu L, et al. Numerical investigation of the energy saving potential of a semi-transparent photovoltaic double-skin facade in a cool-summer Mediterranean climate. Appl Energy 2016;165:345–56.)

as 0.15, since a majority of the solar energy is blocked by the PV modules. The annual electricity output was about 185 kWh, which is higher than the annual lighting energy use (54 kWh). Thus, the electricity generated is sufficient to power the lighting system. Fig. 16 exhibits the overall energy performance and net electricity use of the PV-DSF. The annual net electricity use of the office room was only 54.5 kWh/m², and the minimum monthly net electricity use of the office room was only 2.6 kWh/m². Compared with other commonly used glazing systems, the use of PV-DSF saved about 50% of the net electricity use.

Wang et al. [27] numerically and experimentally evaluated the overall energy performance of an a-Si STPV insulating glass unit (IGU) (see Fig. 17). The annual energy performances of different windows in Hong Kong are shown in Fig. 17. The results indicated that when compared with single clear glass window and the Low-E glass window, the energy saving potential of PV-IGU was 25.3% and 10.7%, respectively, mainly by reducing the cooling energy use.

Later in 2017, Wang et al. [28] compared the overall energy performance of a PV double skin façade (PV-DSF) and a PV insulating glass unit (PV-IGU) through comparative experimental and numerical studies in Hong Kong, as presented in Fig. 18. The results in Fig. 19 showed that the energy conversion efficiency of PV-DSF is 1.8% better than PV-IGU, but their overall energy saving potentials are 28.4% and 30%, respectively, compared to the commonly used insulating glass window in five different climate zones.

<span id="page-47-0"></span>![](_page_47_Figure_1.jpeg)

FIG. 17 Energy performances of different windows. (Source: Wang M, Peng J, Li N, et al. Assessment of energy performance of semi-transparent PV insulating glass units using a validated simulation model. Energy 2016;112:538–48.)

<span id="page-48-0"></span>![](_page_48_Picture_2.jpeg)

FIG. 18 Cross-section diagrams and test rigs of the PV-DSF and the PV-IGU. (Source: Wang M, Peng J, Li N, et al. Comparison of energy performance between PV double skin facades and PV insulating glass units. Appl Energy 2017;194:148–60.)

Zhang et al. [\[29\]](#page-63-0) comparatively studied the thermal, daylighting, and power performance as well as overall energy performance of STPV windows and common energy-efficient windows in Hong Kong. [Fig. 20](#page-50-0) presents the key results of this study. Employingthe EnergyPlus software, the simulation results showedthat, the southwest orientation was the most suitable for electricity generation of the STPV window.More electricity can be producedin winterthanin summerin Hong Kong. The maximum monthly energy output is about 3.4 kWh/m2 in December. A STPV window can save 18% and 16% electricity consumption per year when compared with the clear single and double-pane windows in areas like Hong Kong.

# 4.4 Life-Cycle Assessment of BIPVs

Nowadays, PV technology has been generally recognized as the cleanest power generating technology, but there are still arguments that PV technologies may consume additional energy during their life cycles including the production, processing, and purification of raw materials, the manufacture of PV modules and BOS components, the installation, operation, and maintenance of PV systems, and the decommissioning, disposal, and recycling of the components. Therefore, people may doubt whether the energy produced during their life cycle can balance the total energy consumption in their whole life. Therefore, to thoroughly examine the life-cycle performances of PV systems, an life-cycle assessment (LCA) considering both resource investment and system output is helpful to measure the sustainability of PV systems [\[30\]](#page-63-0).

International Organization of Standardization has already recommended methodology guidelines for LCA of PV systems, which were reported by the IEA [\[31\].](#page-63-0) These guidelines could be summarized as three main steps: (1) identifying the technical specifications and characteristics of PV systems; (2) specifying the modeling approaches of LCA for PV system; and (3) reporting and sharing LCA results of PV systems.

<span id="page-49-0"></span>![](_page_49_Figure_1.jpeg)

FIG. 19 Annual energy performances of the PV windows in different climates. (Source: Wang M, Peng J, Li N, et al. Comparison of energy performance between PV double skin facades and PV insulating glass units. Appl Energy 2017;194:148–60.)

<span id="page-50-0"></span>![](_page_50_Figure_2.jpeg)

FIG. 20 Annual net electricity use of the office room per unit area with different south-oriented windows. (Source: Zhang W, Lu L, Peng J, Song A. Comparison of the overall energy performance of semi-transparent photovoltaic windows and common energy-efficient windows in Hong Kong. Energy Build 2016;128:511–8.)

For LCA of PV systems, the energy payback time (EPBT) and the greenhouse gas (GHG) emissions are recommended as the most frequently used indicators. EPBT is defined as the required period in which the PV system can produce the same amount of electricity (converted into equivalent primary energy) with the energy consumed over its life cycle. EPBT is considered to be a perfect indicator for evaluating PV sustainability, since it can definitely point out whether a PV system can achieve a net gain of energy over its life cycle and if so to what extent [\[30\].](#page-63-0)

Compared with the conventional fossil fuel-based electricity generation systems, one important benefit of PV systems is that they offer great potential for mitigating GHG emissions. Therefore, GHG emissions of PV systems during their life cycles are considered as another evaluation indicator of LCA of PV systems. In the LCA of PV systems, GHG emissions, include CO2, CH4, N2O, chlorofluorocarbons, etc., are converted into an equivalent of CO2 over the time horizon of 100 years [\[30\].](#page-63-0)

Many researchers investigated the sustainability of different types of PV systems using LCA. [Table 7](#page-51-0) illustrates previous studies on LCA of various PV systems, including mono-Si, multi-Si, thin-film, and some advanced PV systems, in terms of EPBT and GHG emissions.

<span id="page-51-0"></span>

| Investigator                 | Module Type                        | EPBT (year)                 | GHG Emission<br>(g CO2<br>eq./kWh) |
|------------------------------|------------------------------------|-----------------------------|------------------------------------|
| Peng et al.<br>[16–18]       | Mono-Si/Thin film                  | 1.7–2.7/<br>0.75–3.5        | 29.0–45.0/<br>10.5–50.0            |
| Hammond et al.<br>[32]       | Mono-Si                            | 4.5                         | –                                  |
| Held and Ilg [33]            | CdTe                               | 0.7–1.1                     | 19.0–30.0                          |
| Ito et al. [34]              | CdTe/CIS/Mono<br>Si/Multi-Si       | 2.1/1.8/2.0–<br>2.5/2.0     | 50.0/45.0/<br>43.0–55.0/43.0       |
| Lu and Yang [36]             | Mono-Si                            | 7.3                         | –                                  |
| Seng et al. [37]             | Mono-Si/Multi-Si/<br>Thin film     | 3.2–4.4/2.2–<br>3.0/1.9–2.6 | –                                  |
| Ito et al. [35]              | a-Si/CIS                           | 2.5/1.6                     | 15.6/10.5                          |
| Pacca et al. [38]            | Thin film/Multi-Si                 | 3.2/7.5                     | 34.3/72.4                          |
| Jangbluth [72]               | Mono-Si/Multi-Si/<br>a-Si/CdTe/CIS | 3.3/2.9/3.1/<br>2.5/2.9     | –                                  |
| Raugei et al. [39]           | Multi-Si/CIS/CdTe                  | 2.4/2.8/1.5                 | 72.0/95.0/48.0                     |
| Jungbluth [40]               | Multi-Si                           | 3.0–6.0                     | 39.0–110.0                         |
| Alsema [68]                  | Mono-Si                            | 2.6                         | 41.0                               |
| Fthenakis and<br>Kim [41]    | CdTe                               | 1.2                         | 23.6                               |
| Battisti and<br>Corrado [42] | Multi-Si                           | 3.3                         | –                                  |
| Ito et al. [43]              | Multi-Si                           | 1.7                         | 12.0                               |
| Keoleian and<br>Lewis [44]   | Thin film                          | 3.39–5.52                   |                                    |
| Alsema [45]                  | CdTe                               | 1.7                         | 14.0                               |

Table 7 illustrates that the LCA results by different researchers vary a lot; the reason may be that EPBT and GHG emission of a PV system are affected by various factors, including solar radiation level, installation location, climate condition, and other parameters that affect the system's electricity output. Generally, through horizontal contrasts between these PV systems, present mono-Si PV modules have the highest EPBT values, but produce more GHG emissions during their life cycles, while thin film PV modules have the lowest EPBT <span id="page-52-0"></span>value. It is expected that new emerging technologies may provide the potential for developing PV materials with higher efficiency and lower cost, thus can help to produce PV systems with lower EPBT and GHG values.

# 5. BENEFITS, BARRIERS, FUTURE OPPORTUNITIES, AND STRATEGIES FOR BIPV APPLICATION

### 5.1 Development Situation of PV Market Around the World

According to a report published by Sustainability on March 9, 2017 [\[46\],](#page-64-0) the annual and cumulative PV installations from 2010 to 2017 are counted and analyzed. The report showed a significantly growing PV market in recent years. In 2016, the global PV installation raised to at least 75 GW, with a 50% growth compared with 50 GW in 2015. The world's total solar PV electricity generation capacity grew up to 312 GW by the end of 2016.

After a period of stability in 2014, the Chinese PV market grew to around 15.2 GW in 2015 and to 34.45 GW in 2016 and became the leader in terms of total capacity of 78 GW. Japan ended its growth trend and experienced a 20% decline with around 8.6 GW installed in 2016.The US PV installations doubled from 7.3 to 14.7 GW in 2016. The market in Europe declined from 8 GW in 2015 to around 6 GW in 2016. The largest European market in 2016 was the United Kingdom with around 2 GW, followed by Germany (1.5 GW) and then French (0.56 GW).

[Table 8](#page-53-0) illustrates the top 10 countries of annual PV installations and cumulative PV installations in 2016 [\[71\].](#page-65-0) For the annual installed capacity in 2016, China installed most PVs (34.5 GW), and followed by the United States (14.7 GW) and Japan (8.6 GW). For the cumulative PV installed capacity, China now leads the cumulative capacities with 78.0 GW, followed by Japan (42.8 GW), Germany (41.2 GW), and the United States (40.3 GW).

[Figure 21](#page-53-0) presents the forecasted regional PV electricity generation capacities, which were reported by IEA in 2014 [\[70\]](#page-65-0). The results show that PV can produce 2370 TWh electricity in 2030 and 6300 TWh in 2050, which can provide 16% of global electricity by 2050. China is expected to be the world's largest PV electricity producer. By the year of 2050, China's share is anticipated to be 35%. By contrast, the United States' share is expected to be about 15%, and Europe's share to be 4% in 2050.

Since Energy Crisis erupted in last century, more attention was paid to the development of alternative sustainable energy sources. Many incentive polices have been developed to promote BIPV installation in different countries. Germany formulated and implemented "The Thousand Solar Roofs Program" in 1995. This is the first support scheme for the BIPV installation. Later, the Thousand Solar Roofs Program was granted in 1999. By the end of 2003, with loans at low interest rates provided for BIPV projects, the total installed capacity reached 435MW. The US government launched the "Ten Million Solar Roofs

<span id="page-53-0"></span>

| TABLE 8<br>Top 10 Countries for Annual PV Installations and Cumulative |
|------------------------------------------------------------------------|
| PV Capacity in 2016                                                    |

| Top 10 Countries of Annual Installed<br>Capacity in 2016 (GW) |             |      | Top 10 Countries of Cumulative<br>Installed Capacity in 2016 (GW) |           |      |  |
|---------------------------------------------------------------|-------------|------|-------------------------------------------------------------------|-----------|------|--|
| 1                                                             | China       | 34.5 | 1                                                                 | China     | 78.1 |  |
| 2                                                             | USA         | 14.7 | 2                                                                 | Japan     | 428  |  |
| 3                                                             | Japan       | 8.6  | 3                                                                 | Germany   | 41.2 |  |
| 4                                                             | India       | 4    | 4                                                                 | USA       | 40.3 |  |
| 5                                                             | UK          | 2    | 5                                                                 | Italy     | 19.3 |  |
| 6                                                             | Germany     | 1.5  | 6                                                                 | UK        | 11.6 |  |
| 7                                                             | Korea       | 0.9  | 7                                                                 | India     | 9    |  |
| 8                                                             | Australia   | 0.8  | 8                                                                 | France    | 7.1  |  |
| 9                                                             | Philippines | 0.8  | 9                                                                 | Australia | 5.9  |  |
| 10                                                            | Chile       | 0.7  | 10                                                                | Spain     | 5.5  |  |

Source: International Energy Agency, 2017 [\[71\].](#page-65-0)

![](_page_53_Figure_5.jpeg)

FIG. 21 Forecasted regional production of PV electricity. (Source: International Energy agency. IEA Technology Roadmaps Technology Roadmap: Solar Photovoltaic Energy, 2014. ([www.iea.org/](http://www.iea.org/publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy%26mdash%3B2014-edition) [publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy—](http://www.iea.org/publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy%26mdash%3B2014-edition) [2014-edition\)](http://www.iea.org/publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy%26mdash%3B2014-edition).)

Program" in 2010 to promote the BIPV application. A total of \$250 million has been invested for PV roof installation since 2012, and the budget was enlarged to 100 GW by 2021. Chinese government also strengthened support for BIPV development. In 2009, "The enforcement advice for promoting solar energy applications in buildings" and "The interim procedures for financial subsidy of solar PV application in buildings" were issued. In the same year, "The notice for implementation of golden sun program" and "The interim procedures for financial subsidy of golden sun program" were also launched. With the help of these programs, China's cumulative installed PV capacity increased from 300MW in 2009 to 17,800MW in 2013. In the 13th five-year plan, the Chinese government set a goal for BIPV application: the total BIPV installed capacity is expected to grow to 50 GW, which will occupy 33% of the total PV market, by the end of 2020.

The global BIPV market experiences a fast growing in recent years. The annual global BIPV installation is anticipated to grow to 1152.3 MWp by the end of 2019, from 343.1 MWp in 2012 with a CAGR of 18.7%, as reported by Transparency Market Research [\[47\]](#page-64-0). NanoMarkets [\[48\]](#page-64-0) also predicted that the BIPV market will increase from \$3 billion in 2015 to over \$9 billion by the end of 2019, and further to over \$26 billion by the end of 2022. Tabakovic et al. [\[49\]](#page-64-0) reported the status and outlook of global BIPV installation from 2014 to 2020 by region. As illustrated in Table 9, the global installation was estimated to be 2.3 GW in 2015, while the market was only 1.5 GW in 2014, thus the increasing rate reaches almost 50%. Europe, Asia, and the United States dominate the global BIPV market in the past decades. In the year of 2015, about 41.7% of the BIPV market was occupied by Europe. With a compounded annual growth rate (CAGR) of 39% during the period 2014–2020, the annual installation of BIPV market in 2020 is expected to be 11 GW. In future, the BIPV market is expected to grow fast due to the intensive demand of construction and refurbishment in the building sectors.

| Global BIPV Market Development and Forecast from 2014 to<br>TABLE 9<br>2020 (MW) |      |      |      |      |      |      |       |             |
|----------------------------------------------------------------------------------|------|------|------|------|------|------|-------|-------------|
| Region/<br>Country                                                               | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020  | CAGR<br>(%) |
| Asia/Pacific                                                                     | 300  | 492  | 772  | 1159 | 1672 | 2329 | 3.134 | 47.8        |
| Europe                                                                           | 650  | 967  | 1441 | 2103 | 2929 | 3807 | 4838  | 39.7        |
| USA                                                                              | 319  | 476  | 675  | 917  | 1200 | 1491 | 1766  | 33.0        |
| Canada                                                                           | 42   | 61   | 86   | 119  | 157  | 190  | 228   | 32.6        |
| Japan                                                                            | 143  | 201  | 268  | 349  | 434  | 520  | 612   | 27.5        |
| Rest of world                                                                    | 81   | 125  | 184  | 263  | 355  | 451  | 561   | 37.9        |
| Total (GW)                                                                       | 1.5  | 2.3  | 3.4  | 4.9  | 6.7  | 8.8  | 11.1  |             |

Source: Tabakovic M, Fechner H, Sark WV, Louwen A, Georghiou G, Makrides G, et al. Status and outlook for building integrated photovoltaics (BIPV) in relation to educational needs in the BIPV sector. Energy Procedia 2017;111:993–999.

#### <span id="page-55-0"></span>5.2 Benefits of BIPV Systems

Some of the benefits of BIPV systems have been discussed in the previous sections. From a lifetime point of view, BIPV systems bring various benefits to the society and their users. For the society, BIPV provides environmental and economic advantages; while for the users or clients, BIPV cuts down the costs on building materials and electricity bills.

#### 5.2.1 Benefits to Society

Compared with conventional electricity generation measures using nonrenewable resources, BIPV reduces the carbon emissions during the producing and transferring process of electricity, since the fossil fuel combustion process is substituted by converting solar energy, and the produced electricity can be consumed by on-site end users. The implementation of BIPV systems can help to alleviate the environmental and health problems related to carbon emission, such as greenhouse effect, sea-level rise, biodiversity threat, and human health problems [\[50\].](#page-64-0) Additionally, it will cost a lot to deal with the carbon emission. So BIPV can contribute to reduce this cost.

In conventional power plants, the fossil fuel-based generators are always located far from cities and towns, so the energy loss during the transfer and distribution process is often significant. In BIPV systems, there is no need for transmitting electricity over long distances; thus, they enjoy great potential in reducing the capital expenditure related to construction and maintenance of transmission systems and equipment. Moreover, compared with traditional electricity production methods, BIPV systems require no additional land; thus, the installation of BIPV offers a social benefit by reducing the occupation of land resources for electricity generation.

#### 5.2.2 Benefits to Client and End-Users

Implementing the BIPV system, not only reduces the material use in building construction by treating PV modules as part of building envelope, but also reduces the material consumed in PV systems by removing the need of supporting structures and PV frames. The costs of BIPV products, as well as their transportation and installation, are already included in the cost of building materials and building construction [\[51\].](#page-64-0) Therefore, the added cost of the BIPV system is reduced to the cost of the electricity storage and regulation components, that is, battery, inverter, wires and cables, etc. By providing dual-effects, the investment of the BIPV system can be split between the envelope function and power generation function. Thus, the total cost on building construction and electricity systems could be significantly reduced.

In BIPV systems, the on-site power generation offsets the electricity consumed in buildings [\[52\].](#page-64-0) For stand-alone BIPV systems, the electricity load of the building is fully satisfied by the system, so none electricity is imported <span id="page-56-0"></span>from the utility grid; while grid-connected BIPV systems interacts well with utility grid to balance the local electricity requirements. From an overall point of view, compared with buying electricity from the utility grid, BIPV systems provide potential savings on electricity bills. In commercial and office buildings, the peak load occurs at the same time with the maximal output of the BIPV system, thus can effectively alleviate the power supply pressure of the utility grid. Additionally, BIPV systems usually enjoy higher thermal insulation properties when compared with conventional building envelopes, which contribute to energy savings in space heating or air conditioning, thus further reduces the electricity consumption in buildings.

#### 5.3 Barriers for BIPV Applications

The development of BIPV technology has been ongoing for a long period in the past few decades, but this technology has not yet been large-scale applied. Currently the most widely adopted PV systems are the roof-mounted type. There are many barriers and challenges to get over to make BIPV more promising [\[53\].](#page-64-0)

### 5.3.1 Policy Barriers: Lack of Government Support

Nowadays, a number of policies have been established in many countries to support the research and development of PV technology. However, very few of them are aimed specially at BIPV [\[54\].](#page-64-0) Therefore, for BIPV, policies are still lacking for developing these applications. The incentive effect of support policies on BIPV development has been verified in some countries, such as France and Malaysia. In these two countries, the implementation of BIPV supportive policies has resulted in rapid increases in BIPV installations. Policy support can either promote the research of BIPV technologies to improve the energy efficiencies and reduce the installation and maintenance cost, or provide incentives and subsidies to clients or end users. Thus, the importance of support policies should be highlighted. Governments should enact policies to promote BIPV application.

# 5.3.2 Perception Barriers: Poor Public Understanding

According to some previous surveys, the public perception of BIPV is so limited [\[53\]](#page-64-0). The respondents of the survey showed their awareness of the high cost, but they always underestimated the added values and long-term benefits of BIPV systems. These misunderstandings hinder their willingness of using BIPV systems. It's obvious that advantages, multiple functions, and lifetime cost promises of BIPV are not generally realized or accepted by the clients, builders, architects, planners, and developers. Necessary measures should be taken to improve public's perception of BIPV technology, including policy incentives, demonstration building constructions, community engagements, etc.

# 5.3.3 Economic Barriers: High Cost of BIPV Modules, High Cost of Design and Construction

Due to the rapid development of PV technologies in recent years, the cost of PV modules has been declining. However, BIPV systems are still not considered in the initial building design because of their high capital costs. It is still a fact that PV modules are more expensive when compared with traditional building materials. The high costs of BIPV systems are considered to be the biggest barrier for BIPV installation. According to the survey result in 2009 [\[55\],](#page-64-0) most respondents regarded the high cost as the biggest barrier and risk for implementing BIPV systems in buildings. Koinegg et al. [\[51\]](#page-64-0) also indicated that the majority of BIPV-related stakeholders, including governmental and institutional professionals, PV manufacturers, clients and end users, held the attitude that BIPV systems are not financially beneficial considering their high capital costs.

One the other hand, the architecturally integration of PV modules into building envelopes adds considerable complexity to the design and construction process of both BIPV systems and buildings [\[53,56\].](#page-64-0) This will result in a much higher costs in the design and construction of a building and its BIPV system.

#### 5.3.4 Technical Barrier: Lack of Standards, Low Power Efficiency, Poor Power Reliability

Integrating PV modules into building envelopes results in inevitable sharing or replacement in structural elements. Therefore, decisions cannot be simply made on where and how PV modules can be incorporated into envelopes, there should be some restrictions. For BIPV design, there should be specific standards and codes, which can fit well with the existing building design and construction codes and can clearly indicate how to implement and optimize BIPV systems in buildings [\[57\]](#page-64-0). For now, BIPV awkwardly stands between the PV technology and the building areas, without an integrated set of standards and codes to carve out and guide the middle ground. The establishment of these middle ground standards and codes is essential for the development of BIPV industry [\[58\]](#page-64-0).

The low-energy conversion efficiency is an important influencing factor that hinders BIPV application. Currently, the BIPV system efficiency is usually lower than 20% [\[59\]](#page-64-0). The low power conversion efficiency not only reduces the electricity output of a BIPV system, but also extends the payback period of this power generation system, thus reduces its economic applicability.

The electricity production rate of PV modules is sensitive to the weather conditions. So many different parameters, such as solar radiations, clouds, dirt and particles, shadings, etc. may result in power losses to a BIPV system [\[60\].](#page-64-0) Under the combined effect of these influence factors, the current, voltage, and frequency of the electricity output of a BIPV system change all the time. The power generation may even stop when shadow is spread over a large area of the PV arrays in cloudy days. Thus, the stability and reliability of the BIPV <span id="page-58-0"></span>generation are relatively low. Without a backup or supplementary power generator, the BIPV system alone couldn't ensure a lasting and stable electricity supply.

#### 5.4 Future Opportunities of BIPV

The future of BIPV relies mainly on the development of new PV technologies and the improvement of existing BIPV products. New PV technologies will result in advances for BIPV applications with higher power efficiency and lower cost. Additionally, many of the existing BIPV products can achieve higher performance with updated materials and solutions.

#### 5.4.1 New Materials and Technologies

As discussed in [Section 2.2,](#page-5-0) there are various types of PV materials or technologies as yet. However, most of the PV products available in the market are based on the first- or second-generation PV cells. The third-generation PV technologies are at their beginning stage, that is, the research and development work on third-generation PV technology is still being processed in laboratories. There is still a long way to go before the third-generations PV products become commercially available.

The development of new emerging PV technologies is quite essential for future BIPV applications, since it is expected to be the most potential way to develop high efficiency and low-cost PV products. Dye-sensitized PV cells and organic polymer PV cells are suitable for fabricating low cost and low medium modules [\[61\]](#page-64-0). Quantum cells and nanocrystal PV technologies are the best alternatives for high-efficiency PV modules. CIGS and CdTe materials are appropriate for flexible PV modules, which allow building integration in structures without adding any additional loads. Other innovative PV technologies can upgrade the energy conversion efficiency of solar power generation. All the new technologies under development will provide BIPV systems with higher efficiencies and lower costs in the future, thus will lead to shorter energy and economic payback times and reduce the greenhouse gas emissions.

# 5.4.2 BIPV Product Development

As a result of the research and development activities on BIPV in the past few decades, many different types of PV products have been developed specially for BIPV implementation [\[62\]](#page-64-0). According to their characteristics and integration types with buildings, available BIPV products can be roughly categorized as BIPV foil, tile, module products, BIPV solar cell glazing products, and BAPV products, as demonstrated in [Fig. 22](#page-59-0). All these products involve the crystalline silicon and/or thin-film PV technologies. These products can be integrated into different parts of building envelopes, including the roof, wall, fac¸ades, windows, skylights, and shadings. The tile products are more suitable for roof applications; while the foil products enjoy extensive applications owing to their flexibility, but

<span id="page-59-0"></span>![](_page_59_Figure_2.jpeg)

FIG. 22 Types of BIPV Products.

their low efficiency leads to a relatively large applied area to achieve a promising output. The module products and the solar cell glazing products can be integrated into the roofs, fac¸ades, and other envelope components [\[31\].](#page-63-0)

The development of these products makes it easy and convenient to implement BIPV systems in buildings. But unfortunately, the available types of BIPV products are very limited, and their efficiencies are still far below the highest efficiencies achieved in laboratory conditions. Therefore, there is still much room for improving the energy conversion efficiencies of these BIPV products.

# 5.4.3 Further Integration Methods of PV Cells

Nowadays, the most common integration pattern of PV cells into buildings is to install PV cell involved modules or products into building envelopes. In future, the integration of PV cells can be realized in some other methods. A potential future option is to integrate the PV cells into building materials at an early stage. For instance, PV cells can be integrated into the surface of prefabricated concrete plates, which it the most widely used building materials all over the world [\[63\]](#page-64-0). This integration method is remained undeveloped, thus presenting a highly potential future alternative.

Thin laminate and paint layer PV materials can also be a future option. Using a handheld airbrush, Javier and Foos [\[64\]](#page-64-0) investigated the applicability of fabricating PV films from CdSe and CdTe nanorods, silver paint, and glass. They succeeded in producing smooth surfaces with the thickness of 20– 500 nm. Their attempt presents a new method for BIPV application.

# 5.4.4 Further Research Opportunities of BIPV

The previous discussions on BIPV technologies as well as the benefits, barriers, and future opportunities highlight the future research directions for this field. Future research can be conducted from the following aspects: developing new <span id="page-60-0"></span>materials and new technologies of BIPVs; life-cycle cost assessment of BIPV systems; quantifying the influence of government support and incentive policies on BIPV cost; quantifying environmental and social benefits of BIPV systems; optimized design of BIPV systems; investigating comprehensive benefits of BIPV to buildings considering the optical, electrical, and thermal performances.

### 5.5 Strategies for Promoting BIPV Applications

Suggestions can be made to governments, manufacturers, professionals, community groups, clients, and end users to promote BIPV applications [\[65\]](#page-64-0). Governments should propose and enact various policies, including financial policies, research and development policies, and educational policies, to reduce the BIPV cost and to improve public awareness for promoting BIPV implementation [\[54\]](#page-64-0). The capital cost of BIPV systems could be reduced due to the incentives and subsidies to end users and clients as well as the manufacturing technology improvement. Education policies can help to improve the public awareness and knowledge of BIPV technology and can also improve the design and construction skills of professionals. With these incentive policies, BIPV may become more competitive compared with conventional power systems.

Manufacturers should increase their investments in research and development of high efficiency and low-cost PV material and products [\[59\]](#page-64-0). Only when the PV materials and products become more efficient, more durable, and less difficult to be integrated into buildings, the BIPV technology can be more cost effective and more attractive for clients and end users.

Professionals should continue to improve their knowledge and professional skills of BIPV technology, since this can reduce the design, construction, and maintenance costs of BIPV systems [\[53\]](#page-64-0). Designers and architects need to improve their design skills; installers and site engineers need to improve their construction skills. Likewise, maintenance workers, facility managers, and technicians need to improve their knowledge and skills for system and component maintenance, repair, and replacement.

Community groups can organize education and training activities to show the public with the benefits of BIPV systems and the role of BIPV systems in national energy structure [\[53\]](#page-64-0). These activities help to educate the public by improving their awareness of BIPV technology.

Clients and end users should take active measures to improve their perceptions and knowledge of BIPV technology [\[66\]](#page-64-0). BIPV systems installed on residential buildings financially supported by personal users can act as smallscaled BIPV demonstration systems. BIPV systems also implemented on commercial buildings supported by investors can act as landmark buildings with BIPV technologies. These BIPV involved buildings can highlight the benefits and advances of this technology.

Moreover, for all the above-mentioned stakeholders, maintaining a close cooperation relationship between them would be extremely advantageous for <span id="page-61-0"></span>promoting BIPV applications. Collaborations between government and manufacturers play an important role in accelerating the research and development process of producing high-efficiency materials and technologies as well as improving the design and construction abilities [\[67\].](#page-64-0) Collaborations on education and training companions between government, professionals, and communities provide a communication platform, thus can help to propose operational policies, to develop professional skills and to improve public awareness. Professionals and manufacturers can cooperate to improve the design and construction process. Professionals can offer better suggestions for clients and end users to construct a better performed BIPV system [\[55\].](#page-64-0) A better product development can be achieved when manufacturers can receive requirements and advices from clients and end users. Governments should provide continuous support and incentive policies for clients and end users, while community groups need to provide education and training for clients and end-uses for improving their perception and knowledge of BIPV technology.

These collaborations can significantly reduce the capital cost of BIPV systems and improve the public perception and design and installation ability. Through these efforts, BIPV installations are anticipated to be greatly increased and the reliance on conventional power source can be reduced.

#### 6. SUMMARY

Integrating PV technologies into building envelopes not only introduces an onsite electricity producing opportunity, but also brings about some by-produced advantages related to architectural esthetics and energy efficiency aspects compared with conventional buildings. Although the added BIPV system may increase the capital cost on construction, operation, and maintenance of a building, significant benefits can be achieved for the stakeholders and the society. However, various barriers in terms of policy, perception, economic, and technology hinder the development and application of this technology. New technologies and products under development are expected to cut down on the energy and economic payback times by providing higher efficiencies and lower costs for BIPV applications. All stakeholders in the supply chain of BIPV, including governments, manufacturers, professionals, community groups, clients, and end users, should make their own efforts for promoting BIPV applications. This chapter provides a systematic introduction of BIPV technology and application, which helps to improve stakeholder's awareness and knowledge of the design, installation, operation, and maintenance processes of BIPV systems as well as their confidences of BIPV technology.

With high efficiency and low cost products, improved skills in system design, construction, operation, and maintenance; better social awareness of the life-cycle costs and benefits; and common efforts of all the stakeholders, BIPV is expected to have a bright future.

#### <span id="page-62-0"></span>REFERENCES

- [1] [Peng C, Huang Y, Wu Z. Building-integrated photovoltaics \(BIPV\) in architectural design in](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0005) [China. Energ Buildings 2011;43\(12\):3592](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0005)–8.
- [2] [Parida B, Iniyan S, Goic R. A review of solar photovoltaic technologies. Renew Sust Energ](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0010) [Rev 2011;15\(3\):1625](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0010)–36.
- [3] [Temby O, Kapsis K, Berton H, et al. Building-integrated photovoltaics: Distributed energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0015) [development for urban sustainability. Environ: Sci Policy Sustain Develop 2014;56\(6\):4](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0015)–16.
- [4] [Sharma S, Jain KK, Sharma A. Solar cells: in research and applications—a review. Mater Sci](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0020) [Appl 2015;06\(12\):1145](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0020)–55.
- [5] [Jacobson MZ. Evaluation of proposed solutions to global warming, air pollution, and energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0025) [security. Energy Environ Sci 2008;2\(2\):148](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0025)–73.
- [6] [Gul M, Kotak Y, Muneer T. Review on recent trend of solar photovoltaic technology. Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0030) [Explor Exploit 2016;34\(4\).](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0030)
- [7] [Zhao J, Wang A, Greea MA. High-efficiency PERL and PERT silicon solar cells on FZ and](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0035) [MCZ substrates. Sol Energy Mater Sol Cells 2011;65\(1](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0035)–4):429–35.
- [8] [Shukla AK, Sudhakar K, Baredar P. A comprehensive review on design of building integrated](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0040) [photovoltaic system. Energ Buildings 2016;128:99](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0040)–110.
- [9] [Scrosati B, Garche J. Lithium batteries: Status, prospects and future. J Power Sources 2010;195](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0045) [\(9\):2419](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0045)–30.
- [10] [Mohanty P, Muneer T, Gago EJ, et al. Solar radiation fundamentals and PV system compo](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0050)[nents. In: Solar photovoltaic system applications. Springer, Cham \(ZG\), Switzerland: Springer](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0050) [International Publishing; 2016.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0050)
- [11] [Farahat MA, Metwally HMB, Mohamed AE. Optimal choice and design of different topolo](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0055)gies of dc–[dc converter used in PV systems, at different climatic conditions in Egypt. Renew](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0055) [Energy 2012;43:393](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0055)–402.
- [12] You, S., & Yang, H. (1997). The potential electricity generating capacity of BIPV in Hong Kong. Photovoltaic Specialists Conference, 1997. Conference Record of the Twenty-Sixth IEEE, 1345–1348.
- [13] [Peng J, Lu L. Investigation on the development potential of rooftop PV system in Hong Kong](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0060) [and its environmental benefits. Renew Sust Energ Rev 2013;27\(6\):149](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0060)–62.
- [14] [Defaix PR, van Sark WGJHM, Worrell E, Visser ED. Technical potential for photovoltaics on](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0065) [buildings in the eu-27. Sol Energy 2012;86\(9\):2644](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0065)–53.
- [15] Suneel, D. (2016). Photovoltaic System Design Procedures, Tools and Applications. Print ISBN: 978–1–4822-5980-3; eBook ISBN: 978–1–4822-5981-0; [https://doi.org/10.1201/](https://doi.org/10.1201/9781315372181) [9781315372181.](https://doi.org/10.1201/9781315372181)
- [16] [Peng J, Lu L, Yang H. Review on life cycle assessment of energy payback and greenhouse gas](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0070) [emission of solar photovoltaic systems. Renew Sust Energ Rev 2013;19\(1\):255](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0070)–74.
- [17] [Peng J, Lin L, Yang H. An experimental study of the thermal performance of a novel photo](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0075)[voltaic double-skin facade in Hong Kong. Sol Energy 2013;97\(1\):293](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0075)–304.
- [18] [Peng J, Lu L, Yang H, et al. Investigation on the annual thermal performance of a photovoltaic](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0080) [wall mounted on a multi-layer fac](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0080)¸[ade. Appl Energy 2013;112:646](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0080)–56.
- [19] [Yang H, Burnett J, Ji J. Simple approach to cooling load component calculation through PV](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0085) walls. [Energ Buildings 2000;31\(3\):285](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0085)–90.
- [20] Ji [J, Chow T, He W. Dynamic performance of hybrid photovoltaic/thermal collector wall in](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0090) [Hong Kong. Build Environ 2003;38\(11\):1327](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0090)–34.
- [21] [Chow TT, He W, Ji J. An experimental study of fa](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0095)c¸[ade-integrated photovoltaic/water-heating](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0095) [system. Appl Therm Eng 2007;27\(1\):37](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0095)–45.

- <span id="page-63-0"></span>[22] [Chow TT, Pei G, Chan LS, et al. A comparative study of PV glazing performance in warm](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0100) [climate. Indoor Built Environ 2009;18\(1\):32](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0100)–40.
- [23] [Chow TT, Qiu Z, Li C. Potential application of "see-through" solar cells in ventilated glazing](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0105) [in Hong Kong. Sol Energy Mater Sol Cells 2009;93\(2\):230](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0105)–8.
- [24] [He W, Zhang YX, Sun W, et al. Experimental and numerical investigation on the performance](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0110) [of amorphous silicon photovoltaics window in East China. Build Environ 2011;46\(2\):363](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0110)–9.
- [25] [Peng J, Lu L, Yang H, et al. Comparative study of the thermal and power performances of a](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0115) [semi-transparent photovoltaic fa](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0115)c¸[ade under different ventilation modes. Appl Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0115) [2015;138:572](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0115)–83.
- [26] [Peng J, Curcija DC, Lu L, et al. Numerical investigation of the energy saving potential of a](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0120) [semi-transparent photovoltaic double-skin facade in a cool-summer Mediterranean climate.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0120) [Appl Energy 2016;165:345](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0120)–56.
- [27] [Wang M, Peng J, Li N, et al. Assessment of energy performance of semi-transparent PV insu](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0125)[lating glass units using a validated simulation model. Energy 2016;112:538](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0125)–48.
- [28] [Wang M, Peng J, Li N, et al. Comparison of energy performance between PV double skin](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0130) [facades and PV insulating glass units. Appl Energy 2017;194:148](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0130)–60.
- [29] [Zhang W, Lu L, Peng J, Song A. Comparison of the overall energy performance of semi](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0135)[transparent photovoltaic windows and common energy-efficient windows in Hong Kong.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0135) [Energ Buildings 2016;128:511](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0135)–8.
- [30] [Fthenakis VM, Kim HC. Photovoltaics: life-cycle analyses. Sol Energy 2009;85\(8\):1609](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0140)–28.
- [31] [Tripathy M, Sadhu PK, Panda SK. A critical review on building integrated photovoltaic prod](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0145)[ucts and their applications. Renew Sust Energ Rev 2016;61:451](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0145)–65.
- [32] [Hammond GP, Harajli HA, Jones CI, et al. Whole systems appraisal of a UK building inte](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0150)[grated photovoltaic \(BIPV\) system: energy, environmental, and economic evaluations. Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0150) [Policy 2012;40\(1\):219](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0150)–30.
- [33] [Held M, Ilg R. Update of environmental indicators and energy payback time of CdTe PV sys](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0155)[tems in Europe. Prog Photovolt Res Appl 2011;19\(5\):614](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0155)–26.
- [34] [Ito M, Kato K, Komoto K, et al. A comparative study on cost and life cycle analysis for 100](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0160) [MW very large-scale PV \(VLS-PV\) systems in deserts using m-Si, a-Si, CdTe, and CIS mod](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0160)[ules. Prog Photovolt Res Appl 2010;16\(1\):17](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0160)–30.
- [35] [Ito M, Komoto K, Kurokawa K. Life-cycle analyses of very-large scale PV systems using six](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0165) [types of pv modules. Curr Appl Phys 2010;10\(\(2\):S271](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0165)–3.
- [36] [Lu L, Yang HX. Environmental payback time analysis of a roof-mounted building-integrated](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0170) [photovoltaic \(BIPV\) system in Hong Kong. Appl Energy 2010;87\(12\):3625](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0170)–31.
- [37] [Seng LY, Lalchand G, Lin GMS. Economical, environmental and technical analysis of build](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0175)[ing integrated photovoltaic systems in Malaysia. Energy Policy 2008;36\(6\):2130](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0175)–42.
- [38] [Pacca S, Sivaraman D, Keoleian GA. Parameters affecting the life cycle performance of PV](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0180) [technologies and systems. Energy Policy 2007;35\(6\):3316](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0180)–26.
- [39] [Raugei M, Bargigli S, Ulgiati S. Life cycle assessment and energy pay-back time of advanced](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0185) [photovoltaic modules: CdTe and CIS compared to poly-Si. Energy 2007;32\(8\):1310](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0185)–8.
- [40] [Jungbluth N. Life cycle assessment of crystalline photovoltaics in the Swiss ecoinvent data](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0190)[base. Prog Photovolt Res Appl 2005;13\(5\):429](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0190)–46.
- [41] Fthenakis, V., Kim, H. C. (2004). Energy use and greenhouse gas emissions in the life cycle of CdTe photovoltaics Mrs Online Proceeding Library, 895.
- [42] [Battisti R, Corrado A. Evaluation of technical improvements of photovoltaic systems through](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0195) [life cycle assessment methodology. Energy 2005;30\(7\):952](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0195)–67.
- [43] [Ito M, Kato K, Sugihara H, et al. A preliminary study on potential for very large-scale pho](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0200)[tovoltaic power generation \(VLS-PV\) system in the Gobi desert from economic and environ](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0200)[mental viewpoints. Sol Energy Mater Sol Cells 2003;75\(3](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0200)–4):507–17.

- <span id="page-64-0"></span>[44] [Keoleian GA, Lewis GM. Modeling the life cycle energy and environmental performance of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0205) [amorphous silicon BIPV roofing in the US. Renew Energy 2003;28\(2\):271](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0205)–93.
- [45] [Alsema EA. Energy pay-back time and CO2 emissions of PV systems. Prog Photov Res Applic](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0210) [2000;8\(1\):17](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0210)–25.
- [46] [Arnulf JW. Snapshot of Photovoltaics-march 2017. Sustainability 2017;9\(5\):783.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0215)
- [47] Building Integrated Photovoltaics (BIPV) Market Global Industry Analysis, Size, Share, Growth, Trends and Forecast, 2013–2019[J]. Sensors, 2014.
- [48] [Nanomarkets. BIPV technologies and market, 2015-2022. In: Nano-839. 2015.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0225)
- [49] [Tabakovic M, Fechner H, Sark WV, Louwen A, Georghiou G, Makrides G, et al. Status and](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0230) [outlook for building integrated photovoltaics \(BIPV\) in relation to educational needs in the](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0230) [BIPV sector. Energy Procedia 2017;111:993](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0230)–9.
- [50] [Byrnes L, Brown C, Foster J, et al. Australian renewable energy policy: barriers and chal](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0235)[lenges. Renew Energy 2013;60\(1\):711](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0235)–21.
- [51] [Koinegg J, Brudermann T, Posch A, et al. It would be a shame if we did not take advantage of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0240) [the spirit of the times. In: An analysis of prospects and barriers of building integrated photo](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0240)[voltaics. 22\(22\):2013. p. 39](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0240)–45.
- [52] [Bazilian M, Onyeji I, Liebreich M, Macgill I, et al. Re-considering the economics of photo](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0245)[voltaic power. Renew Energy 2013;53\(9\):329](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0245)–38.
- [53] [Azadian F, Radzi MAM. A general approach toward building integrated photovoltaic systems](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0250) [and its implementation barriers: a review. Renew Sust Energ Rev 2013;22\(8\):527](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0250)–38.
- [54] [Moosavian SM, Rahim NA, Selvaraj J, et al. Energy policy to promote photovoltaic genera](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0255)[tion. Renew Sust Energ Rev 2013;25\(5\):44](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0255)–58.
- [55] [Taleb HM, Pitts AC. The potential to exploit use of building-integrated photovoltaics in coun](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0260)[tries of the gulf cooperation council. Renew Energy 2009;34\(4\):1092](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0260)–9.
- [56] [Sozer H, Elnimeiri M. Critical factors in reducing the cost of building integrated photovoltaic](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0265) [\(BIPV\) systems. Archit Sci Rev 2007;50\(2\):115](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0265)–21.
- [57] [Paul D, Mandal SN, Mukherjee D, Chaudhuri SRB. Optimization of significant insolation dis](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0270)[tribution parameters: a new approach towards BIPV system design. Renew Energy 2010;35](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0270) [\(10\):2182](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0270)–91.
- [58] [Yang RJ. Overcoming technical barriers and risks in the application of building integrated pho](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0275)[tovoltaics \(BIPV\): Hardware and software strategies. Autom Constr 2015;51:92](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0275)–102.
- [59] [Agrawal B, Tiwari GN. Life cycle cost assessment of building integrated photovoltaic thermal](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0280) [\(bipvt\) systems. Energ Buildings 2010;42\(9\):1472](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0280)–81.
- [60] [Rafeeu Y, Kadir MZAA. Thermal performance of parabolic concentrators under Malaysian](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0285) [environment: a case study. Renew Sust Energ Rev 2012;16\(6\):3826](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0285)–35.
- [61] [Jørgensen M, Norrman K, Krebs FC. Stability/degradation of polymer solar cells. Sol Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0290) [Mater Sol Cells 2008;92\(7\):686](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0290)–714.
- [62] [Jelle BP, Breivik C, Røkenes HD. Building integrated photovoltaic products: a state-of-the-art](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0295) [review and future research opportunities. Sol Energy Mater Sol Cells 2012;100\(5\):69](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0295)–96.
- [63] [Prasad DK, Snow MD. Designing with solar power: a source book for building integrated pho](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0300)[tovoltaics \(BiPV\). Hoboken, NJ, US: Taylor and Francis; 2005.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0300)
- [64] [Javier A, Foos EE. Nanocrystal photovoltaic paint sprayed with a handheld airbrush. IEEE](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0305) [Trans Nanotechnol 2009;8\(5\):569](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0305)–73.
- [65] [Yang RJ, Zou PXW. Building integrated photovoltaics \(BIPV\): Costs, benefits, risks, barriers](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0310) [and improvement strategy. Inter J Construc Manage 2016;16\(1\):39](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0310)–53.
- [66] Abdullah, A. S., Abdullah, M. P., Hassan, M. Y., et al. (2012). Renewable energy cost-benefit analysis under Malaysian feed-in-tariff. Research and Development (pp. 160–165). IEEE.
- [67] [Martin N, Rice J. The solar photovoltaic feed-in tariff scheme in New South Wales, Australia.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0315) [Energy Policy 2013;61\(10\):697](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0315)–706.

- <span id="page-65-0"></span>[68] [Alsema E, Wild MJD. Environmental impact of crystalline silicon photovoltaic module pro](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0320)[duction. MRS Proc 2005;895.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0320)
- [69] InternationalEnergyagency. Potential forBuilding Integrated Photovoltaics.Report IEA-PVPST7– 4:2002. [\(www.iea-pvps.org/index.php?id](http://www.iea-pvps.org/index.php?id=9&eID=dam_frontend_push&docID=394)¼[9&eID](http://www.iea-pvps.org/index.php?id=9&eID=dam_frontend_push&docID=394)¼[dam\\_frontend\\_push&docID](http://www.iea-pvps.org/index.php?id=9&eID=dam_frontend_push&docID=394)¼[394\)](http://www.iea-pvps.org/index.php?id=9&eID=dam_frontend_push&docID=394).
- [70] International Energy agency. IEA Technology Roadmaps Technology Roadmap: Solar Photovoltaic Energy, 2014. ([www.iea.org/publications/freepublications/publication/technology](http://www.iea.org/publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy---2014-edition)[roadmap-solar-photovoltaic-energy—2014-edition](http://www.iea.org/publications/freepublications/publication/technology-roadmap-solar-photovoltaic-energy---2014-edition)).
- [71] International Energy agency. Snapshot of global photovoltaic markets, Report IEA PVPS 2016;T1-31:2017. [http://www.iea-pvps.org/index.php?id](http://www.iea-pvps.org/index.php?id=363)¼[363](http://www.iea-pvps.org/index.php?id=363).
- [72] [Jungbluth N. Life cycle assessment of photovoltaics: update of the ecoinvent database. Mrs](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0335) [Online Proceeding Library 2007;1041.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0335)
- [73] [Wang Y, Tian W, Ren J, et al. Influence of a building's integrated-photovoltaics on heating and](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf9510) [cooling loads. Appl Energy 2006;83\(9\):989](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf9510)–1003.

#### FURTHER READING

- [74] [Athienitis AK, Bambara J, O'Neill B, Faille J. A prototype photovoltaic/thermal system inte](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0325)[grated with transpired collector. Sol Energy 2011;85\(1\):139](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0325)–53.
- [75] [Liu M, Johnston MB, Snaith HJ. Efficient planar heterojunction perovskite solar cells by](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0340) [vapour deposition. Nature 2013;501\(7467\):395](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0340)–8.
- [76] National Renewable Energy Laboratory (NREL), Best Research-Cell Efficiencies, ([https://](https://www.nrel.gov/pv/assets/images/efficiency-chart.png) [www.nrel.gov/pv/assets/images/efficiency-chart.png\)](https://www.nrel.gov/pv/assets/images/efficiency-chart.png).
- [77] [Rahman MM, Haur LK, Rahman HY. Building integrated photovoltaic \(BIPV\) in Malaysia: an](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0345) [economic feasibility study. J Inter Finance Manage Account 2012;45:7683](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0345)–8.
- [78] [Shahrestani M, Yao R, Essah E, et al. Experimental and numerical studies to assess the energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0350) [performance of naturally ventilated PV fac](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0350)¸[ade systems. Sol Energy 2017;147:37](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0350)–51.

#### <span id="page-66-0"></span>Chapter 7.2

# Solar Thermal Energy for Building Applications

Soteris A. Kalogirou and Rafaela A. Agathokleous

Cyprus University of Technology, Limassol, Cyprus

#### 1. INTRODUCTION

The Renewable Energy Framework Directive sets a 20% target for renewables by 2020. Buildings account for 40% of the total primary energy requirements in the EU [\[1\]](#page-91-0). Therefore, developing effective energy alternatives for buildings, used primarily for heating, cooling, and the provision of hot water, is imperative. One way to reduce fossil fuel dependence is the use of solar thermal systems (STS) which are generally environmentally benign. In various countries, STS and in particular solar water heating systems are used extensively.

This chapter deals with solar thermal energy systems, which are suitable for space heating and cooling systems. These concern solar systems with collectors which are permanently fixed in position or have low concentration ratio (C), defined as the ratio of the aperture area to the absorber area, less than about 5.

The major component of any STS is the solar collector. This is a device which absorbs the incoming solar radiation, converts it into heat, and transfers this heat to a fluid flowing through the collector. In this respect, solar energy collectors in general are special kind of heat exchangers that transform solar radiation energy to internal energy of the transport fluid. The solar energy collected is used either directly to the heating or cooling equipment or saved in a thermal energy storage tank from which can be used either at night or cloudy days [\[2\].](#page-91-0)

The collectors that can be used for such applications are usually steady, or operate with intermitted not very accurate tracking. Fixed concentrators are also very important because of the advantages enjoyed by fixed STS. Generally, by increasing the concentration ratio the frequency of tracking increases. Thus, a collector with C<3 requires only biannual adjustment whereas a collector with C of around 4–5 needs seasonal adjustment. In fact, the higher the concentration ratio the higher the temperature a thermal collector can attain but the higher are the tracking accuracy requirements. Both stationary and low concentration systems collect direct and diffuse solar radiation which is an added advantage for the winter time when mostly diffuse radiation is available.

<span id="page-67-0"></span>The aim of this chapter is to present briefly the various types of collectors that can be used in building applications, a new idea of building-integrated solar thermal collectors, the basic configurations of space heating and cooling systems and the latest research trends.

#### 2. SOLAR COLLECTORS

This section presents the various collectors that can be used for building applications. The types of collectors examined are the flat-plate collector (FPC), the FPC with fixed reflectors, the compound parabolic collector (CPC), and the evacuated tube collector (ETC) systems including the designs with either external or internal reflectors.

#### 2.1 Flat Plate Collectors

A photo of a typical flat-plate solar collector of the header and riser design is shown in Fig. 1. It is basically consists of an absorbing plate covered with glazing and insulated well at the back and sides. Solar radiation passing through the glazing is absorbed by the blackened absorber plate and then transferred to the transport fluid flowing through the tubes, called risers, carried away for use or stored for later use. The liquid tubes need to be securely fixed (or welded) to the absorbing plate. In some designs, they are an integral part of the plate. This is very important for the effective operation of the solar collector. The riser tubes are connected at both ends of the collector to two header tubes which have larger diameter than the risers. The absorber plate can be constructed as a single sheet of metal on which all riser pipes are fixed or each riser pipe can be fixed on an individual fin (see [Fig. 2](#page-68-0)) and subsequently the individual riser/fin assemblies are welded on the header pipe to form one flat surface which will be the absorber plate of the collector.

The transparent cover is used to reduce the convection losses due to wind from the absorber plate. The glass cover creates a stagnant air between the absorber plate and the cover so any convection losses are by natural convection

![](_page_67_Picture_8.jpeg)

FIG. 1 Photo of a typical flat-plate collector details.

<span id="page-68-0"></span>![](_page_68_Picture_2.jpeg)

FIG. 2 Riser pipe with an individual fin.

which has a much lower effect than the forced convection caused by wind blowing over the absorbing plate for a glassless collector. The cover also helps to trap the solar radiation using the advantage of greenhouse effect because the glass is transparent to the short-wave radiation coming from the sun but it is almost opaque to long-wave thermal radiation emitted by the hot absorber plate [\[3\].](#page-91-0)

The greatest advantage of FPCs is that they can be constructed easily with a relatively low manufacturing cost. An added advantage is that these collectors are permanently fixed in position so no tracking is required, and furthermore they collect both beam and diffuse radiation. The best installation of the collectors is to face the equator, that is, they face south in the northern hemisphere and north in the southern. The optimum tilt angle of the collector depends on the application. For applications that require heat all year round this is equal to the latitude of the location [\[3\]](#page-91-0). If the application is solar cooling only, then a lower inclination (latitude 10°) optimum angle is used, so as the sun would be more "perpendicular" to the collector during summertime when the thermal energy is mostly required. On the contrary if the application is space heating then the optimal angle is at a higher angle (latitude +10°) so as to have a better performance during wintertime when the heating is mostly required [\[2\]](#page-91-0).

The contact between the riser pipe and the absorbing plate is crucial for the effective operation of the collector. A typical attachment method of the pipes on the absorber plate is the embedded fixing in which a semi-circular groove is formed on the fin or absorbing plate in which the riser pipe is pressure fitted or welded. The plate is usually coated with a high absorptance and low emittance material. The back-insulation material of a FPC can be made from mineral fiber mat or fiberglass that does not out-gas at elevated temperatures. It should be noted that building-grade fiberglass is not suitable as its binders evaporate at high temperature and could condense on the collector cover and act as an opaque film for solar radiation.

Since they are first introduced in the market, about 60 years ago, FPCs have been constructed in a large variety of designs and materials. They can be used to heat a variety of fluids including mainly water, air, and water plus antifreeze solutions. Despite the problems associated with the effects of the sun's ultraviolet radiation, the collector should have a long life so usually metallic components are used, such as galvanized sheet metal for the casing and copper or aluminum for the absorber plate and piping. The collector should also be able to work with deposition of dust on the glazing. Dust is mostly collected during summertime where rainfall is less frequent due to the high magnitude of solar irradiation during this period; the dust protects the collector from overheating.

A common glazing material is low-iron content glass. This is widely used to glaze solar collectors because it can transmit about 90% of the incoming shortwave solar irradiation while it is practically opaque to the long-wave thermal radiation emitted by the absorber plate. Normal window glass usually has high-iron content and is not suitable for use in solar collectors.

The glazing should admit solar irradiation and reduce the loss of reradiating heat as much as possible. Usually absorption of that radiation by the glass causes an increase in its temperature and thus there is a loss of heat to the surrounding atmosphere mainly by convection.

A new development in the field is the use of low-cost transparent insulating glazing (TIG), which is a polymer-made material. These are called honeycomb covered collectors. This is because, it creates a layer of air that cannot circulate (because of the honeycomb structure), thus drastically reducing losses related to convection, which is the main cause of energy losses from FPCs.

The normal FPCs are by far the most used type of collectors although lately they experience a strong competition from the ETC, but these are more suitable for higher temperature applications. FPCs are usually employed for lowtemperature applications up to 80°C.

The collector plate must have appropriate optical and thermal properties so as to absorb as much of the irradiation as possible, while losing as little heat as possible to the atmosphere. Therefore, to maximize the energy collection, the absorber plate of a collector is usually coated with a material that has high absorptance for solar radiation and a low emittance for reradiated thermal energy. Such a surface is called selective surface. The absorptance of the collector surface for the solar radiation depends on the nature and color of the coating and on the incident angle. The usual color employed is black, but various other colors have been proposed by Tripanagnostopoulos et al. [\[4\],](#page-91-0) Wazwaz et al. [\[5\]](#page-91-0), and Orel et al. [\[6\]](#page-91-0), mainly for aesthetic reasons.

Using mainly electrolytic or various chemical methods, surfaces with low values of long-wave emittance (ε) and high values of solar radiation absorptance (α) can be produced. Selective surfaces thus produced usually consist of a thin upper layer, which is highly absorbent to shortwave solar radiation but relatively transparent to long-wave thermal radiation, deposited on a surface that has a high reflectance and a low emittance for long-wave radiation [\[2\]](#page-91-0). The use of selective coating is particularly important for collectors operating at high temperatures. The simplest and cheapest coating that can be used is matt black paint but this is not selective so it is suitable only for a collector operating at relatively low temperatures of a maximum of about Tamb+ 40°C.

Most frequently used material for collector absorbing plates is copper although aluminum and stainless steel have been used in the first attempt to reduce cost and the latter for specific corrosive applications. Copper tubes are used most often because of their superior resistance to corrosion and high thermal conductivity.

A basic absorber plate design is the semi-circular one with pipes used as risers which can be fixed in a groove as already described earlier. It should be noted that although no soldering is required in this case, if used, soft solder must be avoided because of the high-plate temperature encountered at stagnation conditions, which could melt the solder. Lately some modern manufacturing techniques have been applied, such as ultrasonic welding, which improve both the speed and the quality of welds and used for the welding of fins on risers in order to improve heat conduction. The advantage of ultrasonic welding is that the process is performed at room temperature therefore, deformation of the small-thickness fins is avoided.

For direct space-heating applications air collectors can be applied, heating the air with solar radiation before this is supplied to the space to be heated. The major difference between air and water-based collectors is the need to design an absorber that overcomes the reduced heat transfer caused by the lower heat transfer coefficients between air and the solar absorber. Therefore, when air is heated with FPCs, some type of extended surface needs to be used. Thin corrugated metal sheets or porous absorbers may be used and when a high level of performance is required, a selective coating is also applied on top of this surface. As the thermal capacity of air is much lower than water, larger volume flow rates of air are usually required which result in a higher parasitic cost for powering the fan.

Air systems have various advantages. The most important are that air does not need to be protected from freezing or boiling, is noncorrosive and does not suffer from heat transfer fluid degradation, which needs periodic replacement of the fluid. Additionally, the air systems are cheaper as no safety values and expansion vessel are required and the air is available from the atmosphere at no cost. The disadvantages are that air handling equipments (ducts and fans) need more space than pipes and pumps, air leaks are much more difficult to detect, parasitic power consumption, that is, electricity used to drive the fans, is generally higher than that of liquid systems and generally are noisier during operation. Another disadvantage is that air collectors are operated at lower fluid capacitance rates and thus with lower heat removal values (FR) than the liquid heating collectors [\[2\].](#page-91-0)

Another category of collectors is the uncovered or unglazed solar collectors but these are not suitable for space heating or cooling. These are usually <span id="page-71-0"></span>employed in low-temperature applications, such as water preheating for domestic or industrial use, heating of swimming pools [\[7\],](#page-91-0) and air heating for industrial or agricultural applications. UV-resistant plastic extrusions are usually used for these collectors for low-temperature applications. These collectors usually have a wide absorber sheet, made of plastic, containing closed-spaced fluid passages. Materials used for plastic panel collectors include polypropylene, polyethylene, acrylic, and polycarbonate [\[2\]](#page-91-0).

#### 2.2 FPCs with Diffuse Reflectors

A very simple way to increase the radiation falling (directly or by reflection) on a flat-plate solar collector is with the use of simple flat diffuse reflectors as shown in Fig. 3. This is actually a concentrator because the aperture area is bigger than the absorber area but the system is stationary, that is, it is permanently fixed in position. This enhancement of FPCs was initially suggested by Tabor [\[8\]](#page-91-0) and leads to higher operating temperatures. An analysis of such arrangement and a model of the system are presented by Garg and Hrishikesan [\[9\]](#page-92-0). The model can be used for the prediction of the total energy absorbed by the collector at any hour of the day for any latitude for any tilt and azimuth angles of the collector and reflectors.

The term "diffuse reflector" signifies a material which is not a specular mirror. It is important not to form an image of the sun on the absorber which could create uneven radiation distribution and unnecessary thermal stresses. Diffuse reflectors are usually made from galvanized sheets or stainless steel, for longer life, and their cost is usually a fraction compared to the cost of the collector.

Although not very practical, individual FPCs can be equipped with flat reflectors in the way shown in Fig. 3, usually on all four sides or if this is

![](_page_71_Figure_7.jpeg)

FIG. 3 Schematic of a normal flat-plate collector with diffuse reflectors.

<span id="page-72-0"></span>![](_page_72_Figure_2.jpeg)

FIG. 4 FPCs with reflectors in a saw-tooth arrangement.

problematic on just two opposite sides, however for multi-row collector installations a saw-tooth arrangement shown in Fig. 4 is more practical.

Extensive, mostly experimental studies, on this type of systems are presented by Tripanagnostopoulos et al. [\[4\]](#page-91-0) as part of his studies with collectors employing color absorbers and hybrid PV/T systems [\[10,11\]](#page-92-0).

# 2.3 Compound Parabolic Collectors

CPCs belong to the family of non-imaging concentrators because they do not form an image of the sun on the collector absorber. Because of their shape, they are capable of reflecting to the absorber all of the radiation incident on their aperture. The first designs of these collectors were suggested by Professor Ronald Winston [\[12\]](#page-92-0) and for this reason they are also called Winston-type collectors. The basic idea is that the necessity of moving the concentrator to accommodate the diurnal apparent motion of the sun can be reduced or eliminated using a trough with two sections of a parabola facing each other, as shown schematically in [Fig. 5.](#page-73-0)

Generally, compound parabolic concentrators can utilize any radiation that is entering the aperture, within the collector acceptance angle, which will hit the absorber surface located at the bottom of the collector, after one or more reflections. It is important to have a highly reflective surface otherwise if the reflectivity of the concentrating surface is not high, the collector optical losses may be significant [\[13\]](#page-92-0). The absorber of a CPC can take a variety of shapes and as can be seen from [Fig. 6](#page-73-0), that is, it can be flat, bi-facial, wedge, or cylindrical. The first three are fin type with pipes embedded on the fins (shown in details). Two basic types of CPCs have been developed; the symmetric, shown in [Fig. 6](#page-73-0), and the asymmetric, which have shapes similar to a snail shell.

These collectors, depending on the acceptance angle, can be stationary or tracking. When tracking is used, this is not very accurate as usually the concentration ratio is small. The higher the temperature required the higher concentration ratio that should be used which require more refined tracking.

<span id="page-73-0"></span>![](_page_73_Picture_1.jpeg)

FIG. 5 Design details of a flat receiver compound parabolic collector.

![](_page_73_Picture_3.jpeg)

FIG. 6 Various absorber types for CPCs including fin details.

CPCs can be designed either as one large unit with one opening and one receiver as shown in Fig. 6 or as a panel with many receivers, which looks like the riser tubes of a FPC, as shown in [Fig. 7](#page-74-0).

The way that a Winston-type CPC is constructed is shown in Fig. 5 [\[14\]](#page-92-0). As can be seen, this is a linear two-dimensional concentrator consisting of two parabolas X and Y axes of which are inclined at the collector half acceptance

<span id="page-74-0"></span>![](_page_74_Figure_2.jpeg)

FIG. 7 Detail of a panel CPC with cylindrical absorbers.

angle (θc) on each side of the collector optical axis. The collector halfacceptance angle (θc) is defined as the angle through which a source of light can be moved from the normal line passing through the collector axis and still converges at the absorber.

As was indicated before, the receiver of the CPC does not have to be flat and parallel but can be bi-facial, wedge, or cylindrical, as shown in [Fig. 6](#page-73-0). In the cylindrical receiver collector, the small lower portions of the reflector at the bottom of the collector are of circular shape while the upper main portions are of parabolic shape. The side-wall profile of fully developed CPCs may terminate when it becomes parallel to the optical axis. This is called CPC truncation. Usually very little concentration is lost by truncating a CPC by some fraction relative to its full height [\[13\]](#page-92-0). Therefore, a lower height CPC is obtained which needs much less reflective material that affects marginally the acceptance angle but changes the average number of reflections, the height-to-aperture ratio and the concentration ratio. As the reflectivity of all mirrored surfaces is affected by dust and other dirt deposits, CPCs are usually covered with a low-iron content glass.

The orientation of a CPC is related to its acceptance angle. A twodimensional CPC is an ideal concentrator, that is, it perfectly concentrates all rays within the acceptance angle 2θc. These collectors can be stationary or tracking depending on the acceptance angle. With respect to the orientation of its long axis, the collector can have a north–south or an east–west direction. In both cases the collector aperture is tilted directly toward the equator at an angle equal to the latitude of the location.

When the collector axis is orientated along the north–south direction, depending on the application, it must track the sun periodically by turning its axis so as solar incidence is within the acceptance angle of the concentrator. The collector can also be stationary, but radiation will only be received the hours when the sun is within the collector acceptance angle or a wide acceptance angle is used to allow collection of radiation for more hours [\[2\]](#page-91-0).

When the concentrator is orientated with its long axis along the east–west direction, the collector is able to utilize the sun's rays effectively through its acceptance angle. In this case usually the CPC is stationary and when mounted

<span id="page-75-0"></span>in this mode the minimum acceptance angle should be equal to 47°. This angle covers the declination of the sun from summer to winter solstices  $(2 \times 23.5^{\circ})$ . In fact a little bigger angle is used in practice with lower concentration ratio to enable the collector and also to collect substantial amounts of diffuse radiation. Collectors with small concentration ratio (<3) are of greatest practical interest [15] because are able to accept a large amount of diffuse radiation and concentrate the beam radiation incident on their apertures without the need of tracking the sun. As a general guideline, the required frequency of collector adjustment is related to the collector concentration ratio. A rough guide is that for  $C \le 2$  the collector can be steady, whereas for C=3 only biannual adjustment is needed while for C close to 10 the collector requires almost daily adjustment. The collectors falling in the last category are also called quasi-static [2].

#### **Evacuated Tube Collectors** 2.4

Evacuated tube solar collectors operate in a different way from the collectors presented so far. These usually consist of a heat pipe inside a vacuum-sealed glass tube. As the area of one tube is small, to increase the heat collection area a number of tubes are connected to one manifold although just one tube is shown in Fig. 8. Depending on the collector size 10-20 tubes are used. The ETC usually employs a fin with a tube as in FPC as shown in the cross-sectional detail of Fig. 8.

Compared to FPCs, higher temperatures can be obtained from ETCs due to the combination of selective surface which is more feasible to be used in these collectors due to the small size of the fin and the effective convection suppressor achieved because of the vacuum insulation. Like FPCs they collect both direct and diffuse radiation, their efficiency however compared to FPCs is higher at low incidence angles, which gives an advantage to the ETC in day-long performance [2].

ETCs use the liquid-vapor phase change as a heat pipe to transfer heat effectively from the collector to the heat transfer medium. The heat pipe is a sealed copper pipe, which is attached to a black thin copper fin and forms the collector absorber plate as shown in Fig. 8. Each tube is terminated to a metallic vessel which is attached to the sealed pipe and acts as a condenser. The heat pipe contains a small amount of volatile fluid (usually methanol or ethanol) which, as long as there is sunshine, undergoes an evaporating-condensing cycle. The solar heat evaporates the liquid and converts it into a vapor which due to its lower density risers to the heat sink (metallic vessel) where it condenses by transferring its latent heat to the flowing fluid, usually water. The condensed fluid then returns back to the solar collector due to gravity. The cycle is repeated as long as there is sunshine and thus solar heat to evaporate the fluid. Water or water-glycol mixture usually flows through the manifold heated up from the condensation of the vapor. The circulated heated liquid is then directed either through a heat exchanger to supply heat to a process or is stored in a storage tank for later use.

<span id="page-76-0"></span>![](_page_76_Picture_2.jpeg)

FIG. 8 Schematic diagram of an evacuated tube collector and cross-section detail.

Perhaps the greatest advantage, which is a unique feature of the evacuated heat pipe collector, is the fact that because no evaporation or condensation above the phase-change temperature is possible, the heat pipe offers inherent protection to the collector from freezing and overheating [\[2\]](#page-91-0).

Another important design of ETC that exists in the market, suitable for lowtemperature applications, consists of an all-glass Dewar-type ETC, also called a wet-tube ETC. In this design, two concentric glass tubes are used, like a thermos, separated by a vacuum space. The selective coating is deposited on the outside surface of the inner glass tube which is domed at one end. A second larger diameter domed glass tube is then inserted on the outside of the first tube and these are joined at the open end. This design has the advantage that it is made entirely from glass and avoids the necessity to penetrate the glass envelope for the riser tube supplying vapor to the condenser used to extract the heat from the tube. This eliminates possible leakage losses and the collector is cheaper than the single envelope system [\[2\].](#page-91-0)

The tubes are not usually installed very close to each other therefore some space is wasted between the tubes. It is thus very much cost effective to install a diffuse reflector at the back of the tubes either as a flat surface or as a gasp design as shown in [Fig. 7](#page-74-0) to utilize any, otherwise wasted, solar radiation.

<span id="page-77-0"></span>![](_page_77_Picture_2.jpeg)

FIG. 9 Integrated CPC tube collectors: (A) internal compound parabolic and (B) circular reflector with finned absorber.

For example, a diffuse reflector with reflectivity, <sup>ρ</sup>¼0.6, mounted behind the tubes spaced one tube diameter apart, increases the absorbed energy in each tube by >25% for normal incidence.

The use of involute or CPC-type reflectors instead of a flat surface is used to effectively concentrate the solar radiation onto the tubes. Evacuated tube arrays with this type of stationary concentrators may have operating temperatures exceeding 150°C.

In another design, evacuated tubes are made with internal, inside the glass tube, reflectors. This collector design is called integrated compound parabolic collector (ICPC). The design of an ETC is shown in [Fig. 8](#page-76-0) in which at the bottom part of the glass tube a reflective material is used [\[16\].](#page-92-0) To allow solar radiation to reach the reflector more efficiently, no fin is used in this case, Fig. 9A, or if it is used it is of a triangular shape as shown in Fig. 9B. Depending on the operating temperature required, either a CPC reflector or a cylindrical reflector is used, which is a much more cost-effective method as it is obtained by depositing a reflective coating on the bottom semicircle of the glass tube. The CPC-type ETC combines into a single unit the advantages of vacuum insulation and non-imaging stationary concentration. This can be steady or tracking ICPC which is suitable for higher temperature applications [\[17\].](#page-92-0)

ETCs are produced in sizes with outer diameters varying from 30mm to about 100mm. The usual length of these collectors is about 2m.

#### 3. BUILDING INTEGRATION OF RES

The benefits of STS are well known but one area of concern has been their integration. Most solar components are mounted on building roofs and they are frequently seen as a foreign element on the building's structure. Due to this fact alone and irrespective of the potential benefits, some architects object to this use of solar energy systems. Therefore, lately an effort is made to better integrate solar systems within the building envelope which is done in a way that blends into the esthetic appearance and form of the building architecture in the most cost-effective way.

In the last decade, the Energy Performance of Buildings Directive (EPBD) requires that renewable energy systems (RES) are actively promoted in offsetting conventional fossil fuel use in buildings. A better appreciation of STS integration will directly support this objective, leading to an increased uptake in the application of renewables in buildings, which is expected to rise dramatically in the coming years. This is further enhanced by the recast of EPBD which specifies that by the year 2020 the buildings in EU should have nearly zero-energy consumption. According to this, meeting building thermal loads will be primarily achieved through an extensive use of renewables, following standard building energy saving measures. Therefore, STS are expected to take a leading role in providing the thermal energy needs, as they can contribute directly to the provision of the heating, cooling, and domestic hot water requirements.

The advantages of building integration of STS are that more space is available on the building for the installation of the required area of collectors and that the traditional building component is replaced by the STS one, which increases the economic viability of the systems.

The adoption of this idea of building integration creates many aesthetic and architectural challenges, as well as many practical issues that need to be resolved, such as rain-water sealing and protection from overheating (avoiding increased cooling loads during summer).

The adoption of building integration of STS can fundamentally change the accepted solar system installation methodologies that can affect residential and commercial buildings. The most important benefit obtained from this idea is the increased adoption of STS in buildings.

A STS is considered to be building integrated, if for a building component this is a prerequisite for the integrity of the building's functionality. If the building-integrated STS is dismounted, dismounting includes or affects the adjacent building component which will have to be replaced partly or totally by a conventional/appropriate building component as for example in the case of replacing with building-integrated solar thermal systems (BISTS) one of the walls in a double-wall fac¸ade. Therefore, building integration must provide a combination of the following [\[18\]](#page-92-0):

- 1. Mechanical rigidity and structural integrity;
- 2. Weather impact protection from rain, snow, wind, and hail;
- 3. Energy economy, such as useful thermal energy, but also shading and thermal insulation;
- 4. Fire protection; and.
- 5. Noise protection.

The building integration of RES can pose a number of problems that will need to be considered such as:

- <span id="page-79-0"></span>1. Amount of thermal energy collected and at what temperature range;
- 2. Resistance to wind-driven rain penetration;
- 3. If the underlying base layer is transparent, calculation of light and solar energy characteristics;
- 4. Calculation of thermal resistance and thermal transmittance characteristics of the construction (overall heat transfer coefficient);
- 5. Fire protection from hot components in contact with flammable materials; and
- 6. Noise attenuation.

#### 4. SOLAR SPACE HEATING AND COOLING

The basic configuration of systems for space heating and cooling is very similar to those for water heating, with the difference in size, as the load is usually much higher, and the use of absorption chiller for the case of the cooling system. The most common heat transfer fluids are water, water with antifreeze mixtures and air. The load is the energy required for the building to be heated or cooled. Although it is technically possible to construct a solar heating or cooling system which can satisfy fully the design load, such a system would be nonviable since it would be oversized for most of the time. Therefore, the size of the solar system may be determined by a life-cycle cost analysis and optimized with respect to the total collection area to use, something which is beyond the scope of this chapter.

Solar space heating and cooling systems use collectors to heat a fluid, storage units to store solar energy until needed and distribution equipment to provide the solar energy to the heated spaces or to the absorption chiller and then to the air-conditioned spaces in a controlled manner. Additionally, a complete system includes pumps or fans for transferring the energy to storage or to the load which require a continuous availability of nonrenewable energy, generally in the form of electricity.

The load can be space heating, cooling, or a combination of these two with hot water supply. When it is combined with conventional heating or cooling equipment, solar systems provide the same levels of comfort, temperature stability, and reliability as the conventional systems.

Generally, during daytime the solar system absorbs solar radiation with collectors and conveys it to storage using a suitable fluid. As the building requires heat either for heating or cooling this is obtained from storage. Control of the solar system is exercised by differential temperature controllers. In locations where freezing conditions are possible to occur, a temperature sensor is installed on the collector which switches on the solar pump when a preset temperature is reached. This process wastes a quantity of the stored heat, but it prevents costly damages to the solar collectors. Alternatively, the drain-down and drain-back, which are described on other more appropriate books (e.g., [\[2\]](#page-91-0)), can be used depending on whether the system is closed or open.

<span id="page-80-0"></span>Solar cooling of buildings is an attractive idea as the cooling loads and availability of solar radiation are in phase. Additionally, the combination of solar cooling and heating greatly improves the use factors of collectors compared to heating alone. Solar air conditioning can be accomplished mainly by two types of systems: absorption cycles and adsorption (desiccant) cycles. Some of these cycles are also used in solar refrigeration systems. It should be noted that the same solar collectors are used for both space heating and cooling systems when both are present. Absorption chillers are described in other chapters of this book and may not be repeated again.

### 4.1 Space Heating and Service Hot Water

Depending on the conditions that exist in a system at a particular time, the solar systems usually have five following basic modes of operation [\[2\]](#page-91-0):

- 1. When solar energy is available and heat is not required in the building, solar energy is added to storage.
- 2. When solar energy is available and heat is required in the building, solar energy is used to supply the building load demand.
- 3. When solar energy is not available, heat is required in the building and the storage unit has stored energy, the stored energy is used to supply the building load demand.
- 4. When solar energy is not available, heat is required in the building and the storage unit has been depleted, auxiliary energy is used to supply the building load demand.
- 5. The storage unit is fully heated, there are no loads to meet and the collector is absorbing heat, thus solar energy needs to be discarded.

All these are combined usually with a smaller storage tank to provide domestic hot water. The last mode is achieved through the operation of 3-way valves, which direct the fluid heated by solar collectors to heat damping heat exchangers, or in the case of air collectors where the stagnant temperature is not damaging to the collector materials, the flow of air is turned off, thus the collector temperature will rise and reach a higher value at which the absorbed energy is equal to the thermal losses.

These modes are usually controlled by thermostats. So, depending on the load of each service, that is, heating, cooling or hot water, the thermostat which is not satisfied gives a signal to operate the appropriate pump. Therefore, using the thermostats it is possible to combine modes, that is, to operate in more than one mode at a time. Some kind of systems do not allow direct heating from solar collector to building but always transfer heat from collector to storage whenever this is available and from storage to load whenever this is needed.

In Europe, solar heating systems for combined space and water heating (no cooling is usually required) are known as combisystems and the storage tanks of these systems are called combistores. Many of these combistore tanks have heat <span id="page-81-0"></span>exchangers immersed directly in the storage fluid. The immersed heat exchangers are used for various functions including charging from the solar collectors or a boiler and discharging to satisfy domestic hot water and space heating needs.

The key component of a combisystem is the heat store, since it is used as a short-term store for solar energy and as a buffer store for the fuel or wood boiler. The storage medium used in solar combistores is usually the water plus chemicals (for corrosion and freezing) used in the space heating loop. The tap water is heated on-demand by passing through a heat exchanger, which can be placed either inside or outside the tank containing water of the heating loop. Therefore, when the heat exchanger is in direct contact with the storage medium, the maximum tap water temperature at the start of the draw-off is similar to the temperature of the water inside the store. The tap water volume inside the heat exchanger can vary from a few liters, for immersed heat exchangers, to several liters for a tank-in-tank (a smaller tank installed within the big tank) store.

At the initial stages of design of a solar space heating system, a number of factors need to be considered, such as whether the system would be direct or indirect and whether to use a different fluid in the solar system and the heat delivery system. The primary decision factor is according to the possibility of freezing conditions at the site of interest. Generally, the presence of a heat exchanger in a system imposes a penalty of 5%–10% in the effective energy delivered to the system, which usually leads to an extra percentage of collector area to enable the system to deliver the same quantity of energy as a system without a heat exchanger.

Generally, the load is not constant and varies from day to day throughout the year reaching zero during most of spring, fall, and summer seasons. Thus, a space heating system would not operate during many months of the year, which could create overheating problems mainly during summertime. To avoid this problem a solar space heating system needs to be combined with solar space cooling so as to utilize fully the solar system throughout the year.

A space heating system can use either air or liquid collectors but the energy delivery system may use either the same medium or a different one. Usually air systems use air for the collection, storage, and delivery systems. Liquid systems may use water or water plus antifreeze solution for the collection circuit, water for storage, and water or air for the heat delivery. The former is suitable for a floor heating system and the latter is usually employing a water-to-air heat exchanger and air handling unit for the distribution of air to the heated space.

# 4.2 Air Systems

A schematic of a basic solar air heating system, with pebble-bed storage unit and auxiliary heating source is shown in [Fig. 10](#page-82-0). The various operation modes are achieved using the 3-way dampers. In air systems, it is not practical to have simultaneous addition and removal of energy from the storage. If the energy

<span id="page-82-0"></span>![](_page_82_Figure_2.jpeg)

**FIG. 10** Detail schematic of a solar air heating system.

supplied from collector or storage is not adequate to meet the load, auxiliary energy can be used to increase the air temperature to cover the building load. As shown in Fig. 10, it is also possible to bypass the collector and storage unit when there is no sunshine and the storage tank is completely depleted and use the auxiliary system alone to provide the required heat. As can be seen, the system can incorporate provision of domestic hot water. For this purpose, an air-to-water heat exchanger is used. Furthermore, the system can use air collectors and hydronic space heating system using an air-water heat exchanger but usually an air supply system is preferred.

The advantages of using air as a heat transfer fluid are outlined earlier (Section 2.1). Other advantages include the high degree of stratification which occurs in the pebble bed which leads to lower collector inlet temperatures. Furthermore, the working fluid is air and warm air heating systems are common in building services industry. The same applies for the control equipment that can be applied to these systems which is also readily available from the building services industry. Further to the disadvantage of air systems outlined earlier in Section 2.1, is the difficulty of adding solar air conditioning to the systems, higher storage costs, and noisier operation.

Air heating collectors used in space heating systems are usually operated at fixed air flow rates; therefore the outlet temperature varies through the day. It is also possible to operate the collectors at a fixed outlet temperature by varying the flow rate. However, when flow rates are low they result in reduced  $F_R$  and therefore reduce the collector performance.

# 4.3 Water Systems

There are many variations of systems, which can be used for both solar space heating and domestic hot water production. Solar-heated water can be added to storage at the same time that hot water may be removed from storage to meet the hot water and/or building loads. Systems normally allow independent control of

the solar collector-storage and storage-auxiliary-load loops. Usually, a bypass is provided to avoid heating the storage tank with auxiliary energy as this can be of considerable size.

A generic schematic diagram of a solar heating and hot water system is shown in Fig. 11. The collector operates with a differential thermostat (DT). When the room thermostat senses low temperature, the load pump is activated, using heated water from the main storage tank to meet the demand. If the energy stored in the tank is not adequate to meet the load demand, the auxiliary heater is powered on to supply the remaining heat energy requirements. Usually, the controller operates also the two 3-way valves shown in Fig. 11 so that the flow is entirely through the auxiliary heater whenever the storage tank is depleted.

The solar heating system design shown in Fig. 11 is suitable for nonfreezing climates. If the climate is characterized by frequent subfreezing temperatures, positive freeze protection with the use of an antifreeze solution in a closed collector loop is necessary. To use such a system in locations where freezing is possible, provisions for complete drainage of the collector must be made. This can be done with a discharge valve, activated by the ambient air temperature sensor, and an air vent. This is the usual arrangement of the drain-down system, in which the collector water is drained out of the system to waste. Alternatively, a drain-back system can be used in which the collector water is drained back to the storage whenever the solar pump stops. When this system drains, air enters the collector through a vent.

A relief valve is also required so as to dump excess energy if overtemperature condition exists. It should be noted that the connections to the storage tank should be done in such a way so as the cold streams to be connected at the bottom and hot streams at the top so as to enhance stratification. In this way, a cooler fluid is supplied to the collectors which operate at the best possible efficiency.

A load heat exchanger is also required, as shown in Fig. 11, in order to transfer energy from the storage tank to the heated spaces, usually through an air heating system. It should be noted that the load heat exchanger must be adequately sized to avoid excessive temperature drop and an increase in the tank and collector temperatures.

![](_page_83_Figure_7.jpeg)

Schematic diagram of a solar space heating and hot water system.

<span id="page-84-0"></span>The advantages of liquid heating systems over the air heating systems are the high collector FR, small storage volume requirement and relatively easy combination with an absorption air conditioner for cooling.

# 5. SOLAR COOLING

The pursuit to accomplish a comfortable environment has always been one of the main concerns of the people. As late as the 1960s, though, house comfort conditions were only for the few. Subsequently however, central airconditioning systems became common in many countries, for many people, due to the development of mechanical refrigeration.

For cooling, vapor compression cooling systems are usually used, powered by electricity, which is expensive and its production depends mainly on fossil fuel, the burning of which create many environmental problems. In hot climates one of the sources abundantly available is solar energy, which could be used to power an active solar cooling system based on the absorption cycle. The problem with solar absorption machines is that they are expensive compared to vapor compression machines, and until recently, they were not readily available in the small-capacity range applicable to domestic cooling applications.

Solar cooling of buildings is an attractive idea as the cooling loads and availability of solar radiation are in phase. Additionally, the combination of solar cooling and heating greatly improves the use factors of collectors compared to heating alone.

There are many systems available which enable the integration of solar energy into the process of "cold" production. Solar refrigeration can be accomplished using either a thermal energy source supplied from a solar collector or electricity supplied from photovoltaics. This can be achieved using either thermal adsorption or absorption units or conventional vapor compression refrigeration equipment powered from photovoltaics.

Photovoltaic refrigeration, although uses standard refrigeration equipment, which is an advantage, has not achieved widespread use because of the low efficiency and high cost of the photovoltaic cells. Lately however a lot of feasibility studies were carried out as shown in [Section 7,](#page-87-0) some of which gave promising results.

The two main categories of solar cooling systems are using adsorption or absorption systems. Details of these systems are given in other chapters of the book so a brief description is only given here.

Porous solids, called adsorbents, can physically and reversibly adsorb large volumes of vapor, called the adsorbate. Although this phenomenon was recognized in 19th century its practical application in the field of refrigeration and solar air conditioning is relatively recent. The concentration of adsorbate vapors in a solid adsorbent is a function of the temperature of the pair, that is, the mixture of adsorbent and adsorbate and the vapor pressure of the latter. Therefore, the dependence of adsorbate concentration on temperature, under constant <span id="page-85-0"></span>pressure conditions, makes it possible to adsorb or desorb the adsorbate by varying the temperature of the mixture. This forms the basis of the application of this phenomenon in the solar-powered intermittent vapor sorption cycle.

Water-ammonia has been the most widely used sorption pair. A number of other solid adsorption working pairs, such as zeolite-water, zeolite-methanol, and activated carbon-methanol, have been studied in order to find the one that performed better. The activated carbon-methanol working pair was found to perform the best [\[19\].](#page-92-0)

Two basic types of absorption units are available: ammonia-water and lithium bromide (LiBr)-water units. The latter are more suitable for solar applications since their operating (generator) temperature is lower and thus more readily obtainable with low-cost solar collectors [\[20\]](#page-92-0).

#### 6. SOLAR COOLING WITH ABSORPTION REFRIGERATION

The greatest disadvantage of solar heating systems is that a large number of collectors need to be shaded or disconnected during summertime to reduce overheating of the solar system. A way to avoid this problem and increase the viability of the solar system is to employ a combination of space heating and cooling and domestic hot water production system.

This is economically viable when the same collector is used for both space heating and cooling. Flat-plate solar collectors are commonly used in solar space heating. High-efficiency FPCs can attain temperatures suitable for LiBr-water absorption systems. Another alternative is to use ETCs, which can give higher temperatures, thus ammonia-water systems can be used, which need higher temperatures to operate.

A schematic diagram of a solar-operated absorption system is shown in [Fig. 12.](#page-86-0) The difference between this system and the traditional fossil-fuel-fired units is that the energy supplied to the generator is from the solar collector system shown on the left side of [Fig. 12](#page-86-0). Due to the intermittent nature of available solar energy a hot water storage tank is needed, thus the collected energy is first stored in the tank and used as energy source in the generator when needed. This is the same tank that can be used for the heating system and can be used with different inlet and outlet ports from the tank or the same ports as the solar heating system can be used with 3-way valves, according to the mode of operation (heating or cooling). When the storage tank temperature is low the auxiliary heater is used to top-up to the required generator temperature. Again here the same auxiliary heater of the space heating system can be used, at different set temperature. As in the space heating mode, if the storage tank is completely depleted, the storage is bypassed to avoid boosting of storage temperature with auxiliary energy and the auxiliary heater is used to meet the heating load of the generator. A collector heat exchanger can also be used to keep the collector liquid separate from the storage tank water (indirect system).

<span id="page-86-0"></span>![](_page_86_Figure_2.jpeg)

FIG. 12 Schematic diagram of a solar-operated absorption refrigeration system.

It should be noted that the operating temperature range of the hot water supplied to the generator of a LiBr-water absorption refrigeration system is from 70°C to 95°C. The lower temperature limit is imposed from the fact that hot water must be at a temperature sufficiently high (at least 70°C) to be effective for boiling the water off the solution in the generator under vacuum. Also, the temperature of the concentrated lithium bromide solution returning to the absorber must be high enough to prevent crystallization of the lithium bromide. A water storage tank system which is not pressurized is usually employed in a solar system, thus an upper limit of about 95°C is used to prevent water from boiling.

Since in an absorption-refrigeration cycle heat must be rejected from the absorber and the condenser, a cooling water system must be employed in the cycle. Perhaps the most effective way of providing cooling water to the system is to use a cooling tower as shown on the right side of Fig. 12. As the absorber requires a lower temperature than the condenser, the cool water from the cooling tower is first directed to the absorber and then to the condenser. It should be noted that the use of a cooling tower in a small residential system is problematic both with respect to space and maintenance requirements; thus whenever possible water drawn from a well can be used. Recently, air-cooled absorption chillers are developed as shown in the next section.

A variation of the basic system shown in Fig. 12 is to remove the hot storage tank and the auxiliary heater and to supply the solar-heated fluid or the auxiliary energy directly to the generator of the absorption unit. The advantage of this arrangement is that the system can benefit from the higher temperatures <span id="page-87-0"></span>obtained on sunny days, which increase the performance of the generator. The disadvantages are the absence of stored energy to produce cooling during evenings and on cloudy days, and the variation of the cooling load due to the intensity of the solar energy input. One way to solve this problem and make this system more effective is to use cold storage. The advantage of such a system is the low cold storage thermal loses due to the smaller temperature difference between the chilled water and ambient temperature. As solar heating systems always employ a storage tank, the arrangement shown in [Fig. 12](#page-86-0) is preferred.

#### 7. RECENT RESEARCH

#### 7.1 Solar Heating and Cooling Systems

Montagnino [\[21\]](#page-92-0) discussed the most relevant solar cooling technologies and their possible combination and implementation in different contexts. Another review paper is presented by Siecker et al. [\[22\],](#page-92-0) on the solar photovoltaic systems cooling technologies. This review presents the various methods that can be used to minimize the negative impacts of the increased temperature while making an attempt to enhance the efficiency of photovoltaic solar panels operating beyond the recommended temperature of the standard test conditions (STC).

Infante Ferreira and Kim [\[23\]](#page-92-0) presented a techno-economic review of solar cooling technologies including solar electric and solar thermal routes. This paper gives an overview of the most promising alternatives and ranks the options according to their required investments for specific applications in Central Spain and the Netherlands. It is concluded that vapor compression cycles in combination with PV collectors is the best option while the second best option are vapor compression cycles driven by electricity delivered by parabolic dish collectors and Stirling engines. Additionally, the best thermally driven solution is the double-effect absorption cycle equipped with concentrating parabolic trough collectors closely followed by desiccant systems equipped with flatplate solar collectors.

Sarbu and Sebarchievici [\[24\]](#page-92-0) carried out a review of solar refrigeration and cooling systems. In this chapter, an extensive review of the technologies related to the better utilization of solar energy for the production of cool energy is presented. Among the numerous conclusions of the study, it is stated that the liquid desiccant system has a higher thermal COP than the solid desiccant system, the adsorption cycle needs a lower heat source temperature than the absorption cycle, and the ejector system has a higher COP, but needs a higher heat source temperature than other systems.

Al-Alili et al. [\[25\]](#page-92-0) presented a review on solar thermal air-conditioning technologies and provided overviews for working principles of the various technologies and reviews for advancements. It is stated that although many researches have been conducted for solar thermal cooling technologies, their overall efficiencies are lower than that of the vapor compression cycles.

<span id="page-88-0"></span>Ge et al. [\[26\]](#page-92-0) carried out a study to summarize the current situation of solar heating and cooling and it is found that the development of the solar hot water heating system is in fast lane in recent years with evacuated tube solar collector dominating the mass market. Apart from the technical development, economic analysis of solar heating and cooling systems is also discussed and the results reveal that low initial cost and advantageous allowance are the most efficient ways to make solar heating and cooling system economically attractive.

Lazzarin [\[27\]](#page-92-0) studied the solar cooling from PV and thermal systems in terms of thermodynamic and economic analysis. As mentioned, the most widespread options for solar cooling are the solar thermal-driven sorption and photovoltaic-driven compression chillers. The possible solar cooling systems are evaluated during a sunny day compared with the PV-driven system first with respect to the overall system efficiency. At the end of the comparative analysis, it is concluded that solar thermal technology must be appreciated for the service that can supply during the months when cooling is not requested for producing heating of the building and hot water. Additionally, it is concluded that PV systems should be evaluated coupled with a heat pump.

Li et al. [\[28\]](#page-92-0) carried out a performance study of a solar photovoltaic air conditioner in a hot summer and cold winter zone in Shanghai, China. The study investigated for various working modes of the systems; cooling in summer and heating in winter, both in daytime and nigh time. It is concluded that the COP for cooling was around 0.32 which is higher than the solar thermal driven cooling machine. The heating COP was around 0.37 which is lower than the thermal efficiency of conventional solar thermal collector.

Otanicar et al. [\[29\]](#page-92-0) presented a technical and economic comparison of existing solar cooling approaches, including both thermally and electrically driven. The projections made show that solar electric cooling will require the lowest capital investment in 2030 due to the high COPs of vapor compression refrigeration and strong cost reduction targets for PV technology.

# 7.2 Absorption Cooling, Adsorption Cooling, and Trigeneration

Abed et al. [\[30\]](#page-92-0) presented a review paper on the single-stage absorption cooling cycle in terms of the subcomponents, supported components added to the absorption cycle, internal energy recovery, and working fluids options. It is concluded that addition of nanoparticles into working fluid promotes separation of ammonia in vapor phase from ammonia/water mixture is highly recommended to reduce the generator thermal load and design optimization, adding new passive components to single-effect absorption cycle to work under low-grade energy sources that incorporate the latest alternative working fluids is highly recommended as well.

Aliane et al. [\[31\]](#page-92-0) presented an illustrated review on solar absorption cooling experimental studies. The aim was to highlight the operational aspects inherent to drive an absorption chiller by solar heat. The authors provided a summary of results and conclusions from different case studies and identified the shortcomings of these systems through a comparative study.

Lu et al. [32] studied a novel multi step sorption reaction cycles for airconditioning cooling and heating and temperature upgrading. It is concluded that in the multi-step sorption-reaction single-stage solar cooling cycle, the cold storage density can arrive at the high value of 1.24 kWh/kg, as the heat source temperature, condensation temperature, and the evaporating temperature are about 95°C, 35°C, and 12°C, respectively. Additionally, in the multi-step sorption-reaction single-stage heating cycle, the heat storage density can be improved significantly, reaching the value of 1252 kWh/m<sup>3</sup>, as the heat source temperature (charging temperature), condensation and cooling temperature (discharging temperature), the evaporating temperature are about 95°C, 35°C, and 5°C, respectively.

Palomba et al. [33] presented a design tool for mid-size thermal solar cooling systems. The tool combines a TRNSYS model validated with real system data in Shanghai. An energy analysis has been performed for six reference cities, differing for climates and latitudes, highlighting the possibility to use only renewable energy for cooling purposes. The comparison of the various systems of the analysis showed that savings in primary energy up to 0.97 MWh per installed square meter of solar collectors can be achieved. Additionally, savings in CO<sub>2</sub> emissions can be achieved up to 22 tons of CO<sub>2</sub> annually.

The effects of operation parameter on the performance of a solar-powered adsorption chiller are studied by Luo et al. [34]. A solar-powered adsorption chiller with heat and mass recovery cycle which consists of a solar water heating unit, a silica gel-water adsorption chiller, a cooling tower, and a fan coil unit was designed and constructed. Test results indicated that the COP and cooling power of the solar-powered adsorption chiller can be improved greatly by optimizing the key operation parameters, such as solar hot water temperature, heating/cooling time, mass recovery time, and chilled water temperature. It is concluded that under the climatic conditions of daily solar radiation being about 16-21 MJ/m<sup>2</sup>, this solar-powered adsorption chiller can produce a cooling capacity about 66-90 W per m<sup>2</sup> collector area, its daily solar cooling COP is about 0.1-0.13.

Deng et al. [35] presented an exergy cost analysis of a gas-fired microtrigeneration system, based on the structural theory of thermoeconomics. The results proved that the structural theory is a powerful and effective tool for performance evaluation of complex system. Additionally, it is shown that the micro-trigeneration system is efficient in utilizing the low-grade waste heat.

Askalany et al. [36] studied theoretically the effect of using metallic additives on thermal conductivity of granular activated carbon on the COP and specific cooling power of adsorption cooling system. Fillings of iron, copper, and aluminum at different mass concentrations ranging from 10% to 30% have been studied. The thermal conductivity has been increased with the increase in metal concentrations. It is shown that aluminum has the highest effect on raising the

thermal conductivity of the mixture comparing to copper or iron. Using aluminum fillings in 30% concentration has caused a decrease in cycle time by 50% and an increase in specific cooling power by 100%.

Mohammed et al. [37] carried out a parametric numerical study to propose a novel compact bed design for absorption cooling systems. The results showed that reducing particle diameter and adsorbent-bed thickness while enhancing the bed thermal conductivity can lead to a dramatic improvement in specific cooling power.

Haghighi Poshtiri and Jafari [38] carried out a study to present a theoretical investigation of the integration of phase change materials (PCMs) with an adsorption cooling system in order to provide 24-h air conditioning. The proposed system consists of a solar-driven adsorption chiller, a latent heat storage unit, and a cooling channel. It was found that rise of air change per hour (ACH) and fresh air ratios (FR) decreased solar fraction and increased auxiliary energy consumption. Reduction of FR from 100% to 20% increased the operation time of the chiller without PCM, for about 2.5h. In addition, ACH=3 instead of ACH = 12 increased the chiller's operation time, without PCM, for about 3h.

Baghernejad et al. [39] carried out an exergoeconomic optimization and environmental analysis of a novel solar trigeneration system for heating, cooling, and power production. The results show that by selecting final optimum solution for the trigeneration system, the unit cost of products reduced by 11.5% and exergy efficiency increased from 44.38% in the base case to 56.07% in the optimum case. Exergoeconomic analysis improved significantly the total performance of the trigeneration system in a way that fuel cost, exergy destruction cost, and environmental impacts (CO<sub>2</sub> emissions cost) are reduced by 24.17%, 38.87%, and 24.17%.

Yilmaz [40] carried out an economic analysis of a geothermal powered absorption cooling system for buildings, to assess cost structure, potential revenues, payback periods, and life-cycle cost analysis. It is concluded that the use of geothermal energy for cooling not only maximizes the potential revenue but also helps environment by eliminating the emission of pollutants associated with the combustion of fossil fuels and the generation of electricity. One of the greatest advantages is that the exhaust of a geothermal cooling and heating system does not contain hydrocarbons emissions.

Ibrahim et al. [41] presented an experimental performance testing of a solar absorption cooling system with ice storage. The system is used for cooling an office space and consists of ammonia-water absorption chiller, evacuated tube solar collectors, and ice storage. The average COP of the chiller for March and October was 0.43 and 0.47, respectively. Additionally, it was concluded that the ice storage can provide a backup time of about 5-6h, which is sufficient to cool the given space during the early hours of chiller warm-up.

Finally, Chen et al. [42] presented recently an experimental and analytical study on an air-cooled single effect LiBr-H<sub>2</sub>O absorption chiller driven by ETC for cooling application in residential buildings. This is very advantageous in <span id="page-91-0"></span>terms of the difficulty of employing cooling towers or well-cooling of chillers, especially in domestic applications. Other advantages include the saving of water, maintenance expense and space, due to the absence of cooling tower. They developed an air-cooled single-effect absorption chiller for which the cooling capacity is 6 kW. The chiller was proved successful for real application without crystallization risk and the influence of different operating conditions was analyzed. Furthermore, the performance of a solar air-conditioning system using the proposed chiller was investigated for residential cooling application. The results show that the studied absorption chiller can meet about 65% of the total cooling load of the building with an average COPth of about 0.61. Furthermore, 28% of the solar radiation is converted into cooling capacity by the solar air-conditioning system.

#### 8. CONCLUSIONS

A number of low-temperature solar collectors which are suitable for heating and cooling systems are presented in this chapter. These include the FPCs, FPCs with diffuse reflectors, CPC, and ETCs. Many more details and methods to design these systems are presented in the book of the first author "Solar Energy Engineering: Processes and Systems" [2].

Subsequently, the basic types of solar heating and cooling systems are presented together with some design characteristics. Finally, some latest research developments on this subject are presented in the form of a literature review.

Future trends in research and development in these type of collectors is focused on the use of improved material properties so as to increase the performance of the collectors and the use of nanofluids as heat transfer medium, which have shown to increase the heat transfer coefficients of the collectors.

#### REFERENCES

- [1] European Commission, (2005). Doing more with less. Green Paper on Energy Efficiency 2005 COM.
- [2] [Kalogirou SA. Solar energy engineering: Processes and systems. 2nd ed. Academic Press:](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0355) Elsevier Science; 2013. [ISBN: 978-0-12-397270-5.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0355)
- [3] [Kalogirou S. Solar thermal collectors and applications. Prog Energy Combust Sci 2004;30](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0360) [\(3\):231](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0360)–95.
- [4] [Tripanagnostopoulos Y, Souliotis M, Nousia T. Solar collectors with colored absorbers. Sol](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0365) [Energy 2000;68\(4\):343](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0365)–56.
- [5] [Wazwaz J, Salmi H, Hallak R. Solar thermal performance of a nickel-pigmented aluminum](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0370) [oxide selective absorber. Renew Energy 2002;27\(2\):277](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0370)–92.
- [6] [Orel ZC, Gunde MK, Hutchins MG. Spectrally selective solar absorbers in different non-black](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0375) [colors, proceedings of WREC VII; 2002](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0375) [Cologne on CD ROM].
- [7] [Molineaux B, Lachal B, Gusian O. Thermal analysis of five outdoor swimming pools heated by](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0380) [unglazed solar collectors. Sol Energy 1994;53\(1\):21](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0380)–6.
- [8] [Tabor H. Mirror boosters for solar collectors. Sol Energy 1966;10\(3\):111](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0385)–8.

- <span id="page-92-0"></span>[9] [Garg HP, Hrishikesan DS. Enhancement of solar energy on flat-plate collector by plane booster](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0390) [mirrors. Sol Energy 1998;40\(4\):295](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0390)–307.
- [10] [Tripanagnostopoulos Y, Nousia T, Souliotis M, Yianoulis P. Hybrid photovoltaic/thermal](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0395) [solar systems. Sol Energy 2002;72\(3\):217](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0395)–34.
- [11] [Tripanagnostopoulos Y. Aspects and improvements of hybrid photovoltaic/thermal solar](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0400) [energy systems. Sol Energy 2007;81\(9\):1117](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0400)–31.
- [12] [Winston R. Solar concentrators of novel design. Sol Energy 1974;16:89](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0405)–95.
- [13] [Winston R. Solar concentrators. In: Gordon J, editor. Solar energy: the state of the art. ISES;](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0410) [2001. p. 357](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0410)–436.
- [14] [Winston R, Hinterberger H. Principles of cylindrical concentrators for solar energy. Sol](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0415) [Energy 1975;17\(4\):255](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0415)–8.
- [15] [Pereira M. In: Design and performance of a novel non-evacuated 1.2x CPC type concentra](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0420)[tor. Proceedings of Intersol Biennial Congress of ISES, Montreal, Canada, 2; 1985.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0420) [p. 1199](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0420)–204.
- [16] Winston R., O'Gallagher J., Muschaweck J., Mahoney A., Dudley V., (1999). Comparison of predicted and measured performance of an integrated compound parabolic concentrator (ICPC), proceedings of ISES solar world congress on CD ROM, Jerusalem, Israel.
- [17] [Grass C, Benz N, Hacker Z, Timinger A. Tube collector with integrated tracking parabolic](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0425) [concentrator, proceedings of the Eurosun'2000 conference on CD ROM. Denmark: Copenha](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0425)[gen; 2000.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0425)
- [18] [Kalogirou SA. Building integration of solar renewable energy systems towards zero or nearly](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0430) [zero energy buildings. Int J Low-Carbon Technol 2013;379](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0430)–85.
- [19] [Norton B. Solar energy thermal technology. London: Springer-Verlag; 1992.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0435)
- [20] [Florides G, Kalogirou S, Tassou S, Wrobel L. Modelling and simulation of an absorption solar](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0440) [cooling system for Cyprus. Sol Energy 2001;72\(1\):43](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0440)–51.
- [21] [Montagnino FM. Solar cooling technologies. Design, application and performance of existing](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0445) [projects. Sol Energy 2016;1](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0445)–14.
- [22] [Siecker J, Kusakana K, Numbi BP. A review of solar photovoltaic systems cooling technol](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0450)[ogies. Renew Sust Energ Rev 2017;79:192](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0450)–203.
- [23] [Infante Ferreira C, Kim DS. Techno-economic review of solar cooling technologies based on](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0455) [location-specific data. Int J Refrig 2014;39:23](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0455)–37.
- [24] [Sarbu I, Sebarchievici C. Review of solar refrigeration and cooling systems. Energ Buildings](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0460) [2013;67:286](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0460)–97.
- [25] [Al-Alili A, Hwang Y, Radermacher R. Review of solar thermal air conditioning technologies.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0465) [Int J Refrig 2014;39:4](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0465)–22.
- [26] Ge, T.S., Wang, R.Z., Xu, Z.Y., Pan, Q.W., Du, S., Chen, X.M., Ma, T., Wu, X.N., Sun, X.L., Chen, J.F., (2017). Solar heating and cooling: Present and future development.
- [27] [Lazzarin RM. Solar cooling: PV or thermal? A thermodynamic and economical analysis. Int J](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0470) [Refrig 2014;39:38](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0470)–47.
- [28] [Li Y, Zhang G, Lv GZ, Zhang AN, Wang RZ. Performance study of a solar photovoltaic air](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0475) [conditioner in the hot summer and cold winter zone. Sol Energy 2015;117:167](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0475)–79.
- [29] [Otanicar T, Taylor RA, Phelan PE. Prospects for solar cooling—an economic and environmen](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0480)[tal assessment. Sol Energy 2012;86:1287](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0480)–99.
- [30] [Abed AM, Alghoul MA, Sopian K, Majdi HS, Al-Shamani AN, Muftah AF. Enhancement](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0485) [aspects of single stage absorption cooling cycle: A detailed review. Renew Sust Energ Rev](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0485) [2017;77:1010](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0485)–45.
- [31] [Aliane A, Abboudi S, Seladji C, Guendouz B. An illustrated review on solar absorption cooling](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0490) [experimental studies. Renew](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0490) Sust Energ Rev 2016;65:443–58.

- <span id="page-93-0"></span>[32] [Lu Z, Wang R, Gordeeva L. Novel multi-step sorption-reaction energy storage cycles for air](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0495) [conditioning and temperature upgrading. Energy 2017;118:464](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0495)–72.
- [33] [Palomba V, Vasta S, Freni A, Pan Q, Wang R, Zhai X. Increasing the share of renewables](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0500) [through adsorption solar cooling: A validated case study. Renew Energy 2017;110:126](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0500)–40.
- [34] [Luo H, Wang R, Dai Y. The effects of operation parameter on the performance of a solar](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0505)[powered adsorption chiller. Appl Energy 2010;87:3018](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0505)–22.
- [35] [Deng J, Wang R, Wu J, Han G, Wu D, Li S. Exergy cost analysis of a micro-trigeneration](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0510) [system based on the structural theory of thermoeconomics. Energy 2008;33:1417](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0510)–26.
- [36] [Askalany AA, Henninger SK, Ghazy M, Saha BB. Effect of improving thermal conductivity of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0515) [the adsorbent on performance of adsorption cooling system. Appl Therm Eng](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0515) [2017;110:695](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0515)–702.
- [37] [Mohammed RH, Mesalhy O, Elsayed ML, Chow LC. Novel compact bed design for adsorption](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0520) [cooling systems: Parametric numerical study. Int J Refrig 2017;80:238](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0520)–51.
- [38] [Haghighi Poshtiri A, Jafari A. 24-hour cooling of a building by a PCM-integrated adsorption](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0525) [system. Int J Refrig 2017;79:57](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0525)–75.
- [39] [Baghernejad A, Yaghoubi M, Jafarpur K. Exergoeconomic optimization and environmental](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0530) [analysis of a novel solar-trigeneration system for heating, cooling and power production pur](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0530)[pose. Sol Energy 2016;134:165](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0530)–79.
- [40] [Yilmaz C. Thermodynamic and economic investigation of geothermal powered absorption](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0535) [cooling system for buildings. Geothermics 2017;70:239](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0535)–48.
- [41] [Ibrahim NI, Khan MMA, Mahbubul IM, Saidur R, Al-Sulaiman FA. Experimental testing of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0540) [the performance of a solar absorption cooling system assisted with ice-storage for an office](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0540) [space. Energy Convers Manag 2017;148:1399](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0540)–408.
- [42] [Chen JF, Dai YJ, Wang RZ. Experimental and analytical study on an air-cooled single effect](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0545) [LiBr-H2O absorption chiller driven by evacuated glass tube solar collector for cooling appli](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0545)[cation in residential buildings. Sol Energy 2017;151:110](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0545)–8.

#### <span id="page-94-0"></span>Chapter 7.3

# Ground-Source Heat Pumps

Marc A. Rosen and Bale V. Reddy

University of Ontario Institute of Technology, Oshawa, ON, Canada

#### NOMENCLATURE

COP coefficient of performance

GHG greenhouse gas

GSHP ground source heat pump

#### 1. INTRODUCTION

Global energy demand is increasing due to industrial activity and advances in both developing and developed countries. Fossil fuel energy sources, such as coal, natural gas, and oil are used to meet energy demands for much of the world. But the share of renewable energy sources in the total energy utilized has increased in recent years. The use of fossil fuels leads to environmental emissions of greenhouse gases (GHGs) and pollutants [\[1\].](#page-115-0) Hammond [\[2\]](#page-115-0) notes that the depletion of fossil fuels and GHG emissions are important factors for sustainable development.

The earth is a reservoir of thermal energy and can be a significant thermal source for electricity generation and space and hot water heating. The U.S. Department of Energy [\[3\]](#page-115-0) has quantified the availability of ground based, or geothermal, energy and concluded that such energy resources offer great potential to meet part of the global energy demand. The GHGs from geothermal energy systems for electrical power production and space heating applications are much lower than those from conventional fossil fuel energy systems [\[3,4\].](#page-115-0)

Geothermal energy is currently used for electricity generation, as well as space heating, often through the application of ground-source heat pumps (GSHPs). High-temperature geothermal resources are usually classified as having a temperature of greater than 150°C, while moderate and low temperature resources, respectively, are at 90–150°C and below 90°C [\[4,5\]](#page-116-0). High and medium temperature geothermal resources are usually derived from thermal streams within the molten core of the earth, which collect in water or rock. Low-temperature geothermal resources are created by solar energy <span id="page-95-0"></span>incident on the ground [\[4\]](#page-116-0). GSHPs predominantly use the natural background temperature of the ground, rather than geothermal resources at elevated temperatures.

Many investigations have been reported on GSHP systems and applications, in part aimed at improving understanding of performance. Some research has provided general guidelines to assist in designing and implementing GSHP systems [\[6\].](#page-116-0) Heat pump technology has been in commercial use for more than 60 years, with the first successful commercial project installed in the Commonwealth Building in Portland, Oregon in 1946 [\[7\].](#page-116-0) Vapor-compression-type heat pumps are the most widely utilized today. Hwang et al. [\[8\]](#page-116-0) presented a basic vapor compression cycle that includes a method of cooling the compressor motor using the refrigerant, which allows the refrigerant to be heated before it encounters the heat exchanger connected to the ground loop. Ma and Chai [\[9\]](#page-116-0) presented a system that includes an economizer arrangement, providing primary and supplementary refrigerant flow paths, and two compression processes. A complete understanding of the practicality of a GSHP system arrangement requires consideration of various factors, including economics and environmental impact [\[10\].](#page-116-0)

In this chapter, details are presented on GSHPs, earth connections, the effects of system and operating parameters on GSHP performance, and associated carbon dioxide emissions. Differences between air-source heat pumps vs GSHPs are described. The chapter also outlines the global status of and recent advances in GSHPs.

#### 2. SPACE HEATING AND COOLING SYSTEMS

Depending on geographic location, buildings (residential, commercial, and industrial) need to be heated during cold seasons and cooled during hot seasons, especially in hot climates. Heating and cooling loads and their durations vary across the planet.

Various heating systems are used for space heating applications in residential, commercial and industrial buildings. For instance, natural gas furnace forced-air heating, GSHP systems, air-source heat pumps, wood burning systems, and radiant floor heating approaches are all employed. The contribution of each type varies by country and regionally. Natural gas and wood burning heating systems provide a significant share of space heating requirements.

There is growing interest in GSHPs for space heating for residential buildings and for large-scale applications, such as university buildings, hospitals, and school buildings. The share of heating provided by GSHP systems has increased in recent years, in large part because of the lower GHG emissions associated with them compared to natural gas heating and the beneficial economics of ground-based heat pump systems due to improved designs.

<span id="page-96-0"></span>The total cost of space heating buildings depends on the building air-tightness and insulation, the environmental conditions (especially the cold temperatures), and the controlled temperature setting inside the building.

In some countries, ground source and air-based cooling systems are employed for space cooling. They remove heat from the building space and transfer it to the surroundings or to the ground, depending on the type of system employed. Centralized air conditioning systems are also employed for space cooling applications.

#### 3. GSHP SYSTEMS

In a typical heat pump system for heating, the product, which is useful heat, is used to provide comfort through space heating of buildings (residential, industrial, etc.). The concepts of heat pumps for heating have been recognized since the 1800s and heat pumps have been applied since the middle of the 20th century [\[7\].](#page-116-0) A key advantage of a heat pump unit is that it has the ability to provide more thermal energy to a building than the energy input required to operate the unit [\[11\]](#page-116-0).

GSHP systems use the ground, at depths ranging from less than 1m to around 150m or more below the surface, as a thermal energy source (and sink) [\[12](#page-116-0)–14]. GSHPs are also referred to as geothermal heat pumps, earth energy systems, geo-exchange heat pumps, ground-coupled heat pumps, earth-coupled heat pumps, and ground-source systems [\[15,16\]](#page-116-0).

GSHP systems consist of three main components that work together to supply heat to or remove heat from buildings, as shown in Fig. 1. The components are as follows [\[17\]:](#page-116-0)

![](_page_96_Picture_8.jpeg)

FIG. 1 Main components of a GSHP system.

- <sup>l</sup> GSHP unit: The unit that moves heat between the building and the earth.
- <sup>l</sup> Earth connection: The heat exchanger loop used to exchange (input or output) thermal energy with the ground for use in the heat pump unit.
- <sup>l</sup> Interior heat distribution system: The heat distribution systems used to condition and distribute the heat throughout the space.

The heat pump is the main component of a GSHP system and it permits the use of ground heat for space heating or cooling. In modern heat pumps, electricity drives the main components of the system, facilitating the concentration and transport of thermal energy [\[4,11\]](#page-116-0) for space heating or cooling applications. Most heat pumps operate on a vapor-compression refrigeration cycle. The refrigerant or working fluid used in a heat pump system depends on the overall characteristics and requirements of the GSHP system. The refrigerant must boil and condense at temperatures appropriate to the application. Heat pumps drive heat flow between the heated space in buildings and the earth connection by controlling the pressure and temperature through compression and expansion [\[11,17\]](#page-116-0) processes.

Breaking down the three components in [Fig. 1](#page-96-0), it is seen that a GSHP system has five primary components (Fig. 2) [\[15,18\]:](#page-116-0) a compressor, an expansion valve, a reversing valve, and two heat exchangers. In addition, a GSHP system has various other minor components, including fans, piping, and system

![](_page_97_Figure_7.jpeg)

FIG. 2 Basic layout of a typical GSHP system.

<span id="page-98-0"></span>controls. One heat exchanger operates between the ground loop and heat pump, and the other between the heat pump and the space.

When a heat pump system is utilized for heating, the product is useful heat. When the heat pump is used for space heating of buildings (residential, industrial, etc.), it provides comfort through heating air.

When a heat pump system is used in a cooling mode, it that removes heat from the building space and transfers it to the surroundings. For a GSHP the heat is discharged into the ground. When in the cooling mode a reversing valve is used to move the fluid in the opposite direction around the cycle compared to the case for the heating mode. The purposes of the heat exchangers are reversed, and the heat exchanger between the earth connection and refrigerant becomes the condenser and the heat exchanger between the refrigerant and building becomes the evaporator [\[11,17\].](#page-116-0)

The "efficiency" of a heat pump is typically expressed in the form of a coefficient of performance (COP). In the heating mode, the COP is the ratio of product heat output to electrical energy consumption [\[15\].](#page-116-0) GSHPs typically have COPs ranging from 3 to 6 for heating [\[3,4,6\],](#page-115-0) depending on factors, such as the earth interface, system size, ground characteristics, installation depth, and local climate [\[19\].](#page-116-0) In the cooling mode, the COP is the ratio of product heat removed from the space being cooled to electrical energy consumption [\[15\]](#page-116-0). GSHPs for cooling typically have COPs lower than those for heating.

The heat distribution system is designed to move heat throughout the building. There are two main types of distribution systems, which use either air or water as the heat transport medium (i.e., water to air and water to water systems). For space heating applications, water to air ground heat pumps obtain heat from fluid passing through the ground loop and transfer it to air in a building through an air coil. That coil is heated by the condenser of the heat pump, and a fan blows air across it to increase its temperature. The air is moved throughout the building through air vents, as with a conventional forced air furnace [\[17,19\]](#page-116-0). Water to water systems (hydronic systems) are similar, but heat is distributed throughout the building using water as the carrier and radiators, in-floor radiant heaters or localized air coils. These systems heat using relatively low temperatures, for example, in-floor radiant heating has a typical design temperature range of 18–22°C [\[11,17,19,20\]](#page-116-0). In case of hybrid heat pump systems, which combine these distribution types, flexibility, and improved control of space temperature is provided.

#### 4. EARTH CONNECTIONS FOR GSHPs

The earth connection (or ground loop) of a GSHP is a collection of pipes through which fluid moves, transferring heat from or to the ground. GSHP systems are often classified by the ground loop arrangement. The selection of the type of loop system depends on the climatic conditions, soil conditions, land availability, and local installation costs [\[21\].](#page-116-0)

<span id="page-99-0"></span>The ambient air exhibits temperature variations throughout the year, on seasonal and daily bases, but ground temperatures exhibit significantly different temporal fluctuations. The temperature of the ground source does not change significantly over the course of a day or year, except near the surface, e.g., ground temperatures fluctuate significantly at depths of 0.3–0.8m on a daily basis, and the variations decrease at further depths [\[22\].](#page-116-0) The seasonal variations are more pronounced than the daily ones. GSHP systems exploit the relatively constant ground temperature, which is warmer than ambient air during winter and cooler during summer. Air-source heat pumps are subject to large differences between the ambient and desired building temperatures, requiring more work for the same heating and reducing the COP [\[18\]](#page-116-0). The depths at which temperatures stabilize temporally indicate the interface at which seasonal influences become minor or insignificant [\[4\]](#page-116-0). As the exact values of these parameters are spatially dependent, the use of a particular ground loop arrangement depends on the country, site characteristics, and applications.

The ground loop arrangements used by GSHP systems to transfer heat to the ground from a building or vice versa can be divided into four main types. Three of these types are closed and classified as closed-loop systems, while one is open and classified as open-loop systems. In the closed-loop classification, horizontal, vertical and pond/lake are the loop systems employed. The four types of ground loop arrangements are now described.

# 4.1 Closed-Loop Systems

Horizontal: The horizontal closed-loop type of installation is generally used and most effective for residential house heating applications, for which small to medium thermal loads exist. A horizontal closed loop requires that sufficient land area be available for heat transfer. This type of system generally utilizes trenches, usually of less than 2m below the surface, although horizontal trenches are placed below the frost line in areas that encounter frost. At such shallow depths most of the thermal recharge to the ground comes from solar radiation as opposed to heat flow from deep within the earth. To supply and remove enough thermal energy during seasonal extremes, increased pipe lengths are required for horizontal installations compared to vertical borehole arrangements. The size and design of a horizontal closed-loop arrangement depends on the heating capacity required and land availability. The commonly used horizontal-loop arrangements are basic, series, and parallel, as shown in [Figs. 3](#page-100-0)–5, respectively. The most commonly used piping layout is in series [\[15\].](#page-116-0)

Vertical: The vertical-loop arrangement is often used for large-scale groundsource heating systems (e.g., commercial buildings, hospitals, schools). Vertical systems are also preferred in situations having land limitations or where the soil is too shallow to bury the horizontal loops in the trenches. Vertical-loop systems have several advantages. For instance, they use less land area and

<span id="page-100-0"></span>![](_page_100_Figure_0.jpeg)

FIG. 3 Basic horizontal-loop configuration.

![](_page_100_Picture_2.jpeg)

FIG. 4 Horizontal ground loop with series configuration.

![](_page_100_Picture_4.jpeg)

FIG. 5 Horizontal ground loop with parallel configuration.

minimize disturbances to the existing environment. Such systems also have disadvantages, the main one being that they can be more costly than horizontal arrangements. The high installation cost of vertical systems is mainly due to the high cost of drilling relative to the cost for horizontal trenching for horizontal configurations. Nonetheless, vertical-loop systems are often found to be more economic for large applications [\[15\].](#page-116-0)

A vertical closed-loop heat exchange field consists of an array of vertically oriented pipes through which the heat transport fluid flows (Fig. 6). A hole is bored into the ground, called a borehole, often at depths of 45–75m but over 200m for larger applications (e.g., commercial, institutional, industrial) [12–[14\]](#page-116-0). Pairs of pipes connected at the bottom by a U-shaped connector are placed in each borehole. A heat transfer fluid thus exchanges heat with the ground over the pipe length that is twice the borehole depth [\[14\]](#page-116-0). A typical borehole has a diameter of approximately 10 cm. The number of boreholes depends on the building thermal requirements.

Pond/Lake: If the building site has an adequate water body, a closed pond or lake arrangement may be used. In such a system, a supply pipe runs underground from the building to the water and the loop is formed into coils under the surface to prevent freezing. The coils should are placed in a water source that meets the minimum required volume and depth criteria.

The heat transfer loop is normally submerged at least 1.8m, partly to assure sufficient thermal mass is available even during low water conditions like those that can occur during a prolonged draught. The depth also ensures that the temperature never drops below the freezing point of water. Rivers are not ideal for this application due to their unpredictable nature and the system damage that can be caused when rivers run dry or near dry [\[14,15\].](#page-116-0)

![](_page_101_Picture_6.jpeg)

FIG. 6 A vertical closed-loop heat exchange configuration for a GSHP system.

<span id="page-102-0"></span>A closed pond or lake arrangement can be the least expensive option when a suitable water body is available. Simultaneously, the main disadvantage of pond loops is the requirement of an adequate water body and the consequent limitations on its use for other purposes, such as boating and fishing.

# 4.2 Open-Loop Systems

Open-loop systems use well or surface waters as the heat exchange fluid that circulates directly through GSHP systems. The spent water returns to the ground through the same well or a recharge well, or via surface discharge. The type of system is practical only when sufficient relatively clean water is available, and if all codes and regulations (local as well as regional and national) regarding ground water discharge are satisfied.

There are three common open-loop configurations: extraction wells, extraction and reinjection wells, and surface water systems.

The most common open-loop configuration uses extraction and reinjection wells (Fig. 7). Water is extracted from the production well, which is drilled into the local water table, and used in the heat pump via a heat exchanger. The water is reinjected into the water table, at a distance from the production well that permits adequate heat transfer from the ground to the water between the wells [\[15\].](#page-116-0)

A reinjection well is not required when open drainage is used, since the water is released in such cases at the surface (e.g., into streams, rivers, lakes, ponds, ditches, drainage tiles). Open drainage is the least complex and costly way to discard used water, but it requires a large water source for sustained use [\[18\]](#page-116-0).

![](_page_102_Picture_8.jpeg)

FIG. 7 Open-loop heat exchange system with production and injection wells.

<span id="page-103-0"></span>Several advantages are derived through the use of open-loop configurations. First, the water temperature remains constant. Second, since the water is directly used after extraction, the fluid temperature entering the heat pump is typically higher than for closed-loop systems. Third, the COP of the overall heat pump system is higher due to the prior point, as a consequence of lowering the temperature difference between the water and space [\[15,22\].](#page-116-0) Fourth, open-loop systems can have the highest pumping loads of all systems, depending on the water extraction method employed, while maintaining a high overall COP. Fifth, open-loop systems usually have lower initial costs than vertical closedloop systems, mainly because they require less drilling. Sixth, open systems also tend to be simpler in design than systems with other earth connection configurations, making them more economic than closed-loop systems of similar capacities. Finally, the high COP of open-loop configurations reduces their energy utilization and operating costs [\[15\]](#page-116-0).

# 4.3 Ground Connection Pipe Lengths and Heat Transfer Details

Vertical closed borehole systems typically have wells bored to depths ranging from 75 to 300 ft. (23 to 91m) deep, although some systems extend to depths exceeding 1000m. Typical piping requirements for ground heat exchangers range from 200 to 600 ft. per system cooling ton (17.4–52.2m/kW), depending on soil and temperature conditions. A 300–500 ton capacity ground heat pump system can be installed on 1 acre (0.405 ha) of land, depending on soil conditions and ground temperature. Horizontal spiral-loop configuration heat exchangers generally require more piping, typically 500–1000 ft. per system cooling ton (43.3–86.6m/kW). Pond loop installations typically require around 300 ft. of heat-transfer piping per system cooling ton (26m/kW) and around 3000 ft2 of pond surface area per ton (79.2m2 /kW) with a recommended minimum one-half acre (0.2 ha) total surface area.

Open-loop systems typically require water flow rates of 1.5 and 3.0 gal per minute per system cooling ton (0.027 and 0.054 L/s-kW) through the primary heat exchanger between the refrigerant and the groundwater [\[15\]](#page-116-0).

Typical COPs for GSHP systems in heating mode are 3–6. COP values are dependent on the earth connection setup, system size, ground characteristics, installation depth, local climate, and other characteristics.

The thermal accumulation capacity and thermal conductivity of the ground are functions of the ground moisture content and the quantity of minerals present [\[23\].](#page-116-0) Values of the specific extraction/absorption power q<sup>E</sup> from the ground by a ground heat exchanger are listed in [Table 1](#page-104-0) for various types of ground.

#### 5. GLOBAL STATUS OF GSHPs

GSHP technology is being applied at an increasing rate and is considered one of the most rapidly expanding uses of renewable energy globally. This is in part

| Type of Ground          | Specific Extraction/Absorption<br>(W/m2<br>Power, qE<br>) |  |
|-------------------------|-----------------------------------------------------------|--|
| Dry sandy ground        | 10–15                                                     |  |
| Moist sandy ground      | 15–20                                                     |  |
| Dry clay ground         | 20–25                                                     |  |
| Moist clay ground       | 25–30                                                     |  |
| Ground with groundwater | 30–35                                                     |  |

<span id="page-104-0"></span>TABLE 1 Specific Extraction/Absorption Power by a Ground Heat Exchanger, for Various Ground Types [\[23\]](#page-116-0)

because such heat pumps utilize ground temperatures typically between 5°C and 30°C, a temperature range applicable in most countries [\[19\]](#page-116-0). Since 1994 the annual growth rate for GSHPs has been about 10%, and as of 2005, there were close to a 1.7 million applications globally [\[17\].](#page-116-0) The global installed GSHP thermal capacity was around 12 GW as of 2004, which required an annual electricity use of 20 TWh [\[24\].](#page-116-0)

As of 2004, approximately 30 countries were using heat pump systems significantly, led by the United States, Sweden, Germany, Switzerland, Canada, and Austria [\[19\].](#page-116-0) But utilization is growing in many other countries, including France, The Netherlands, China, Japan, Russia, United Kingdom, Norway, Denmark, Ireland, Australia, Poland, Romania, Turkey, Korea, Italy, Argentina, Chile, Iran, the United Kingdom, and Norway [\[19\]](#page-116-0).

The growth in GSHP applications has been slower than that for other renewable energy technologies. Reasons for this include nonstandardized system designs, higher capital cost compared to competing heating systems, infrequent exploitation of economies of scale, and lack of supportive government policies [\[22\]](#page-116-0). Research to improve performance and economics in various applications would likely further increase the utilization of GSHP systems.

The status of geothermal energy use for electricity generation and direct heating uses as of 2008 have been reported [\[25\]](#page-116-0). As of that year, the total installed global capacity was approximately 7700MW (electricity generation capacity) and 16,600MW (direct use, thermal capacity).

Recent global trends, up to 2015, in the use of GSHPs have been reported by Lund and Boyd [\[26\]](#page-117-0). They reviewed the global status of the direct utilization of geothermal energy for various applications as of 2015. The worldwide energy use through geothermal heat pumps between 1995 and 2015 is listed in [Table 2](#page-105-0) [\[26\].](#page-117-0) The five leading countries in the world in terms installed capacity (MWt) of geothermal heat pumps are as follows: United States, China, Sweden, Germany, and France and in terms of annual energy use (TJ/year) are as follows: China, United States, Sweden, Finland, and Germany [\(Table 3\)](#page-105-0) [\[26\]](#page-117-0).

<span id="page-105-0"></span>

| TABLE 2<br>Worldwide Use of Geothermal Energy Through GSHPs                                                              |                                                |  |  |
|--------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|--|--|
| Year                                                                                                                     | Ground Source Heat Pump<br>Utilization (TJ/yr) |  |  |
| 1995                                                                                                                     | 12,000                                         |  |  |
| 2000                                                                                                                     | 20,000                                         |  |  |
| 2005                                                                                                                     | 82,000                                         |  |  |
| 2010                                                                                                                     | 200,000                                        |  |  |
| 2015                                                                                                                     | 326,000                                        |  |  |
| (Source: Lund JW, Boyd TL. Direct utilization of geothermal energy 2015 worldwide review.<br>Geothermics 2016;60:66–93.) |                                                |  |  |

| TABLE 3<br>Worldwide Leaders in GSHPs, by Installed Capacity and by Use<br>[26] |                                                     |                                                                  |  |
|---------------------------------------------------------------------------------|-----------------------------------------------------|------------------------------------------------------------------|--|
| Rank                                                                            | Ground Source Heat Pump<br>Installed Capacity (MWt) | Annual Energy Use Through<br>Ground Source Heat Pumps<br>(TJ/yr) |  |
| 1                                                                               | USA (16,800)                                        | China (100,311)                                                  |  |
| 2                                                                               | China (11,781)                                      | USA (66,670)                                                     |  |
| 3                                                                               | Sweden (5600)                                       | Sweden (51,920)                                                  |  |
| 4                                                                               | Germany (2590)                                      | Finland (18,000)                                                 |  |
| 5                                                                               | France (2010)                                       | Germany (16,200)                                                 |  |
|                                                                                 |                                                     |                                                                  |  |

#### 6. RECENT ADVANCES IN GSHPs

Interestis growing in GSHP systems for heating and cooling, based on reportsin the literature.Mostwork onGSHPs appearsto be on use and operation andto be focused on vapor compression systems. Comparisons between ground- and air-source heat pumps have been reported. Energy and exergy analyses have been carried out for basic heat pump arrangement. Simulation and experimental studies have been reported. Some ofthe more notable investigations are highlighted below.

Numerous engineering related studies of GSHPs have been reported. Healy and Ugursal [\[18\]](#page-116-0) showed that GSHP performance is particularly affected by the ground loop parameters, via their investigation the effects on performance of a GSHP with a horizontal ground loop of various system parameters: ground loop depth and length, ground loop pipe size and horizontal spacing, heat pump capacity, heat transfer fluid type and flow rate, ground type.Wang et al.[\[8\]](#page-116-0)investigated the effects of compressor and motor cooling in a heat pump system, where the heat is transferred to the refrigerant for preheating, and the characteristics of different refrigerants for motor cooling. Ma and Chai [\[9\]](#page-116-0) proposed a heat pump that incorporates an economizer in the vapor compression cycle and uses two compression processes between the condenser and the evaporator. The new system was optimized and compared with a conventional heat pump system. This work was extended by Ma and Zhao [\[27\]](#page-117-0) by experimentally comparing the improved heat pump cycle to a similar cycle having a flash tank with vapor separation and two compression processes. Valizade [\[28\]](#page-117-0) examined operational factors, earth connections and heat exchanger loop combinations for GSHPs.

Many GSHP studies have focused on advanced thermodynamic methods like exergy analysis. Hepbasli and Balta [\[29\]](#page-117-0) experimentally investigated the performance of a heat pump system using low-temperature geothermal resources, and utilized energy and exergy analyses to determine the system COP and to identify the locations of the greatest irreversibilities. Hepbasli and Akdemir [\[30,31\]](#page-117-0) reported energy and exergy analyses for GSHP systems with a U-bend ground heat exchanger for district heating purposes.

The use of GSHPs has been examined for heating of domestic hot water. Yrjola and Laaksonen [\[32\]](#page-117-0) investigated the application of GSHP systems for domestic hot water production in apartment buildings.

Space cooling applications have been focused on some studies. Omer [\[25\]](#page-116-0) experimentally investigated GSHP systems for building heating and cooling applications, considering the effects of operating parameters and seasonal variations. Omer[\[33\]](#page-117-0) also reviewed direct expansion GSHPs for heating and cooling.

Some studies have examined related technologies that can support GSHPs. For instance, Rezaie et al. [\[34\]](#page-117-0) thermodynamically assessed the design of sensible thermal energy storages as well as the charging and discharging transient behavior of a fully mixed open thermal energy storage.

Kulcar et al. [\[35\]](#page-117-0) examined the economics of exploiting heat from lowtemperature geothermal sources for high-temperature heating of buildings using a heat pump and demonstrated for a specific system that district heating of buildings is viable economically. Arat and Aslam [\[36\]](#page-117-0) carried out an exergoeconomic analysis of district heating system enhanced by a GSHP.

Extending beyond economics, Wu [\[37\]](#page-117-0) compared air- and ground-source heat pumps, in terms of design criteria, costs, carbon dioxide emissions, and reliability. Also, Hanoval et al. [\[38\]](#page-117-0) outlined the status of GSHP systems in Canada, considering economics and GHG emissions reduction potential among other factors. Self et al. [\[39\]](#page-117-0) reviewed the status of GSHP systems and compared them with conventional heating systems in terms of costs, carbon dioxide emissions and other operating parameters.

Some studies have focused on geographic locations. Luo et al. [\[40\]](#page-117-0) reviewed investigations of the ground in which GSHP systems are placed, focusing on three aspects: the geological setting, the thermal properties of the ground based on both <span id="page-107-0"></span>laboratory and field tests, and strategies for organizing ground investigations for various types of GSHPs. Molavi andMcDaniel[\[41\]](#page-117-0)reviewed the benefits of GSHP systemsin retail buildingsand provided anin depth study of a system for retail stores in the northeast United States. Kara [\[42\]](#page-117-0) investigated experimentally the heating performance in Erzurum, Turkey of a GSHP system having a single U-tube ground heat exchanger made of polyethylene pipe. As pointed out earlier, Hanoval et al. [\[38\]](#page-117-0)have consideredGSHPsinCanada. An energy assessment of solartechnologies coupled with GSHP systems for residential energy supply in southern European climates is reported by Reda et al. [\[43\].](#page-117-0) The work focusses on the coupling of solar technologies (PV and solarthermal collectors) with a GSHP for several Italian sites.

The integration of GSHPs with other renewable technologies has also been considered. Emmi et al. [\[44\]](#page-117-0) analyzed solar-assisted GSHPs for space heating in cold climates and analyzed the effect of borehole length on the efficiency of the heat pump, noting that the solar-assisted GSHP extracts heat from the ground using borehole heat exchangers and injects excess solar thermal energy into the ground. Busato et al. [\[45\]](#page-117-0) presented from a case study to assess and contrast the performance for space heating of a GSHP and a solar source heat pump and demonstrated that the most energy efficient solution adopts a multi-source system (using both ground- and solar-based systems). As just noted, Reda et al. [\[43\]](#page-117-0) assessed coupling of GSHP and solar energy systems.

Numerous examinations related to optimization and parametric studies of GSHPs have been reported. Sivasakthivel et al. [\[46\]](#page-117-0) optimized ground heat exchanger parameters for a GSHP system for space heating using Taguchi and utility methods and considering eight important system parameters. Fan et al. [\[47\]](#page-118-0) carried out a thermal performance and operation strategy optimization for a practical hybrid GSHP system and showed that such a system can effectively solve problems associated with heat accumulation and decreased longterm system performance. Self et al. [\[48\]](#page-118-0) performed parametric energy analyses of GSHPs for heating that uses a vapor compression cycle and economizer arrangement and demonstrated that greatest effect on system COP is exhibited by condenser pressure, followed by evaporator pressure, degree of subcooling, and degree of superheating. Self et al. [\[49\]](#page-118-0) also carried out parametric performance analyses of a basic and two advanced GSHP system arrangements.

Limited research has been reported on advanced GSHP systems, on the impact of variations in components and arrangements in heat pump systems, and on the effects of varying the operating conditions of GSHPs. More work in these areas appears to be merited.

#### 7. GROUND-LOOP HEAT EXCHANGERS

Natural Resources Canada [\[6\]](#page-116-0) suggests that a vertical borehole with a U-tube arrangement is most advantageous for heating and cooling applications [\[6\].](#page-116-0) The borehole design consists of a main flow through the evaporator, a single pump, and multiple parallel loops. A cool water/glycol (brine) mixture flows <span id="page-108-0"></span>from the evaporator to the pump, where the pressure is increased to the required level. The brine flow is then split into the parallel loops and absorbs heat from the ground. The ground loop fluid considered by Self et al. [\[24,49\]](#page-116-0) is a mixture of water and propylene glycol, which is specified as a suitable antifreeze by Ochsner [\[50\]](#page-118-0). Natural Resources Canada [\[6,51\]](#page-116-0) and Ochsner [\[50\]](#page-118-0) specify an appropriate concentration of propylene glycol of between 15% and 40% by mass.

# 8. GROUND- VS AIR-SOURCE HEAT PUMP SYSTEMS

Ground- and air-source heat pump systems are compared and contrasted in this section, and advantages of each are detailed.

#### 8.1 Comparison of Ground- and Air-Source Heat Pumps

A GSHP uses the ground or water in the ground or both as the sources of heat for buildings in the winter and as sinks for heat removed in the summer. Heat is removed from the earth via a liquid, such as ground water or an antifreeze solution, and the temperature of the liquid is raised by the heat pump and the heat is transferred to indoor air. During summer months the process is reversed, with heat extracted from the indoor air and transferred to the ground [\[52\]](#page-118-0).

Air-source heat pumps draw heat from the outside air during the heating season and reject heat to the outside air during cooling season. There are two types of air-source heat pumps: air-to-air and air-to-water. The most common is the air-to-air heat pump, which extracts heat from the air and transfers it to either the inside or outside of the building, depending on the season. Air-source heat pumps can be add-on or all electric or bivalent. Add on heat pumps are designed to be used with another source of supplementary heat. Bivalent heat pumps are a special type, developed in Canada, that use a burner to increase the air temperature entering the outdoor coil, permitting operation at lower outdoor temperatures. Air-to-water heat pumps are typically used in residential buildings having hydronic heat distribution systems [\[52\].](#page-118-0)

Air-source heat pumps are relatively simple to install compared to GSHPs, and the earth connection in a GSHP is usually difficult to reach after installation. Although the cost of GSHP systems can vary, installation costs are normally lower for air source rather than GSHPs. But GSHP system operating costs tend to be lower than those for air-source heat pumps.

Both ground- and air-source heat pumps can provide heating in the winter and, through a reverse operation mode, cooling in summer.

# 8.2 Advantages of Ground- and Air-Source Heat Pumps

Environmentally, GSHP systems are advantageous to air-source units in many aspects. Lower refrigerant costs and reduced leakage are two major advantages compared to air-source heat pumps. However, GSHP systems can cause land <span id="page-109-0"></span>disturbances due to the ground coupling and water contamination problems if water sources and/or sinks are used [\[37\].](#page-117-0)

GSHPs require little regular maintenance. With GSHPs there are no corrosion or little degradation issues with the buried plastic pipes. GSHPs are advantageous due to the prolonged thermal retention qualities of the ground. The main disadvantage with GSHPs is the relatively high cost of equipment, material and installation, depending on the type of heat pump unit and the planned installation. GSHPs can provide winter heating and summer cooling.

Air-source heat pumps have few moving parts, which reduces maintenance requirements. The outdoor heat exchanger and fan should be kept free from leaves and debris. A disadvantage of air-source heat pumps is that they become less efficient when external temperatures become low. In fact, during periods of extreme cold temperatures or when cold temperatures persist for long periods, air-source heat pump systems are not superior for space heating. Air-source heat pumps are relatively simpler to install than GSHPs, due to complexities associated with the earth connection in GSHPs. Air-source heat pumps have lower installation costs, while GSHPs have lower operating costs [\[37\]](#page-117-0).

The discussion of the advantages of ground- over air-source heat pumps is extended in part in subsequent sections (e.g., reductions in carbon dioxide emissions achievable via GSHP systems when employed for space heating relative to those for air-source heat pump systems are described in [Section 8.1\)](#page-108-0).

# 9. EFFECTS OF SYSTEM AND OPERATING PARAMETERS ON GSHP PERFORMANCE

Self et al. [\[24,49\]](#page-116-0) investigated the effect of varying component efficiencies and operating parameters on the performance of GSHP systems, by considering three GSHP system configurations. The space heating performance characteristics of the three GSHP systems were examined in that study.

The heat pump in System 1 ([Fig. 8\)](#page-110-0) utilizes a basic vapor compression cycle [\[15,53\],](#page-116-0) including an evaporator, a compressor coupled with an electric motor, a condenser and an expansion valve and has a ground loop with a pump. System 2 is identical to System 1 except for a modified flow path used for motor cooling in the heat pump system. System 3 incorporates an economizer in the heat pump system, following the work of Ma and Chai [\[9\].](#page-116-0) Details on all three systems and their operating conditions are reported by Self et al. [\[24,49\]](#page-116-0).

In the diagram of System 1 in [Fig. 8](#page-110-0), refrigerant at state 1 is seen to enter the evaporator where it receives thermal energy from the ground loop. The refrigerant the evaporator exits at state 2 as a superheated vapor and enters the compressor, from which high-pressure refrigerant exits at state 3 as a superheated vapor. The refrigerant vapor then enters the condenser where it releases thermal energy to the space being heated. The subcooled liquid at the state 4 passes through an expansion valve, reducing its pressure to that of the evaporator.

<span id="page-110-0"></span>![](_page_110_Figure_2.jpeg)

FIG. 8 Heat pump configuration in System 1. (Source: Sivasakthivel T, Murugesan K, Sahoo PK. Optimization of ground heat exchanger parameters of ground source heat pump system for space heating applications. Energy 2014;78:573–586.)

#### 9.1 Effect of Compressor Efficiency

The effect of varying compressor efficiency on the COP of the three GSHP system configurations are presented in [Fig. 9](#page-111-0), based on the results of previous investigations [\[24,49\].](#page-116-0) The compressor isentropic efficiency is varied from 65% to 100% for each of the heat pump systems, following the range given by Cengel et al. [\[54\]](#page-118-0) for low to high efficiency compressors. The results indicate that the heat pump COP increases almost linearly with compressor efficiency. The COP increases more rapidly for System 3 with compressor efficiency. The differences in heat pump COPs range from as low as 3.81 to as high as 5.32 (or by 1.51) for Systems 1 and 2, and from 3.80 to 5.42 (or by 1.62) for Systems 1 and 3. The GSHP in System 3 is more sensitive to variations in compressor efficiency than that in Systems 1 and 2 [\[24,49\],](#page-116-0) primarily due to the design and operation of System 3 and its two stages of compression. As the compressor efficiency varies at higher compressor efficiencies, the specific enthalpy at state 3 (compressor exit) for Systems 1, 2, and 3 are identical.

The effects of varying compressor efficiency on compressor work requirement for Systems 1–3 are shown in [Fig. 10.](#page-111-0) As compressor efficiency increases, the work requirement reduces, with the compressor work being lower for System 3 than for the other two heat pump systems. The COP variations with compressor efficiency for the three heat pump systems are also shown in [Fig. 10.](#page-111-0) It is observed that the heat pump for System 3 exhibits a rising COP as compressor efficiency increases. Details on this observation are reported in Self et al. [\[24,49\].](#page-116-0)

<span id="page-111-0"></span>![](_page_111_Figure_2.jpeg)

FIG. 9 Effect of varying compressor efficiency on heat pump COP and specific enthalpy at condenser inlet for three systems. (Source: Self SJ, Reddy BV, Rosen MA. Ground-source heat pumps as clean energy systems: fundamentals, applications and parametric performance analyses. In Harris AM (Ed.), Clean energy: Resources, production and developments. New York, NY: Nova Science Publishers, 2011. p. 87–146; Self SJ, Reddy BV, Rosen MA. Parametric performance analyses of geothermal heat pump systems. Int J Energy, Environ Econ 2012;20:563–609.)

![](_page_111_Figure_4.jpeg)

FIG. 10 Effect of varying compressor efficiency on system COP and compressor work requirement for three systems. (Source: Self SJ, Reddy BV, Rosen MA. Ground-source heat pumps as clean energy systems: fundamentals, applications and parametric performance analyses. In Harris AM (Ed.), Clean energy: Resources, production and developments. New York, NY: Nova Science Publishers, 2011. p. 87–146; Self SJ, Reddy BV, Rosen MA. Parametric performance analyses of geothermal heat pump systems. Int J Energy, Environ Econ 2012;20:563–609.)

## <span id="page-112-0"></span>9.2 Effect of Condenser Pressure

The effect of varying operating condenser pressure on compressor work and COP were investigated by Self et al.[\[24,49\]](#page-116-0) for the three GSHP system configurations (Fig. 11). The condenser pressures considered range from 400 to 3000 kPa. The COP decreases with increasing condenser pressure for all three heat pump systems. System 3 exhibits a slightly higher sensitivity to variations in condenser pressure than the other two GSHP systems, while the compressor power requirement increases with condenser pressure for all systems [\[49\].](#page-118-0) More generally, it was determinedthat condenser pressure has a greater effect than other parameters examined in the work on the COPs of three heat pump systems.

#### 9.3 Effect of Other System Parameters

The effects on the three GSHP systems of varying several operating and other system parameters (evaporator pressure, degree of subcooling, degree of superheating, use of economizer, use of motor cooling/refrigerant preheating) have been investigated [\[24,49\]](#page-116-0). The following findings were made:

<sup>l</sup> The investigation of the effects of varying evaporator pressure on the COPs of the three GSHP systems, considering an evaporator pressure range of 178–305 kPa, demonstrated that the COP for each of the three heat pump

![](_page_112_Figure_7.jpeg)

FIG. 11 Effect of varying condenser pressure on compressor work and COP of heat pump (HP) for three systems. (Source: Self SJ, Reddy BV, Rosen MA. Ground-source heat pumps as clean energy systems: fundamentals, applications and parametric performance analyses. In Harris AM (Ed.), Clean energy: Resources, production and developments. New York, NY: Nova Science Publishers, 2011. p. 87–146; Self SJ, Reddy BV, Rosen MA. Parametric performance analyses of geothermal heat pump systems. Int J Energy, Environ Econ 2012;20:563–609).

<span id="page-113-0"></span>systems increases with evaporator pressure. The trends observed are similar to those for condenser pressure.

- <sup>l</sup> The examination of the effects of varying the degree of subcooling at the condenser on the COPs of three heat pump systems, which was carried out for a constant condenser pressure of 1000 kPa and considering a range for the degree of subcooling of 0–20°C, showed that the COPs increase linearly with the degree of subcooling.
- <sup>l</sup> The investigation of the effects of varying the degree of superheating on the COPs of the three GSHP systems, considering a superheating range between 0°C and 17°C, indicated that the COPs for the heat pump systems increase with degree of superheating.
- <sup>l</sup> The investigation of the use of an economizer revealed that GSHP designs incorporating an economizer were found to have the potential for high performance.
- <sup>l</sup> The utilization of motor cooling/refrigerant preheating in the heat pump systems was observed to reduce ground loop requirements without degrading performance relative to the basic vapor compression cycle.

# 10. CARBON DIOXIDE EMISSIONS AND OTHER ENVIRONMENTAL IMPACTS

A heat pump system itself does not directly contribute carbon dioxide emissions during operation. But the electricity utilized by the heat pump systems can result in carbon dioxide emissions, depending on how and from what the electricity is generated. If the electricity is produced from fossil fuels, then there are carbon dioxide emissions and these are associated with the electricity consuming components of the heat pump systems. If the electricity is generated through renewable energy sources, then there are no or little carbon dioxide emissions associated with heat pump systems.

For space heating, GSHP systems provide significant GHG emission reductions relative to fossil fuel (natural gas, oil) based space heating systems [\[22\].](#page-116-0) However, this advantage is dependent on the source of electricity (fossil fuel based or renewable) to drive the GSHP system. For instance, relative to high efficiency (95%) natural gas heating furnaces, GSHPs reduce carbon dioxide emission reductions when the emission intensity of the electricity produced is less than 0.76 kg/kWh [\[22\].](#page-116-0)

Relative to air-source heat pump systems, GSHP systems use less energy and consequently are responsible for less carbon dioxide emissions. The magnitude of this advantage again depends on the source of electricity supplied to the heat pump systems.

GSHP systems can cause other environmental impacts. The main one is land disturbance caused by the ground-coupled system. It can lead ground contamination, to water contamination problems if water source/sink is used, and to thermal effects on organisms in the ground [\[37\].](#page-117-0)

#### <span id="page-114-0"></span>11. **GSHP EXAMPLES**

#### **Example 1:** Metrus Building, Concord, Ontario, Canada [55].

The Metrus Building in Concord, Ontario, near Toronto, is one of the larger commercial office buildings in the province to use a GSHP system for heating and cooling. The two-story building has a total floor area of 3250 m<sup>2</sup> (35,000 ft<sup>2</sup>).

The system consists of 28 heat pump units, of three to five tons each, located in various zones throughout the building. They are placed out of sight inside a 76-cm (30-in) suspended ceiling. These heat pump units provide ventilation at a rate of 26 m<sup>3</sup>/h (15 cu. ft. per min) of fresh air per person, comfortably meeting American Society of Heating, Refrigerating and Air Conditioning Engineers (ASHRAE) standards.

The energy source for the heat pumps comes from the ground under the parking lot outside the Metrus Building. Under the parking lot, which has a surface area of almost 1800 m<sup>2</sup> (19,000 ft<sup>2</sup>), there are 88 boreholes, spaced at 4.6-m (15-ft) intervals. Each borehole is 54 m (175 ft) deep. A pipe loop placed in these holes draws energy for the heat pumps from the ground using water as the circulating fluid. The annual mean ground temperature is approximately 10°C (50°F).

The pipes, which are made of high-density polyethylene, are grouped into manifolds of three or four and placed underground, leading to a small mechanical room on the ground floor. Each heat pump has its own set of pumps that operates only as required for specific zone heating or cooling [55].

#### **Example 2:** UOIT, Oshawa, Ontario, Canada [56–58].

The University of Ontario Institute of Technology (UOIT), located in Oshawa, Ontario, Canada, utilizes one of the largest geothermal well fields in North America for heating and cooling its buildings. The geothermal well field is incorporates a borehole thermal energy storage system containing almost 400 boreholes, each over 200 m (700 ft) deep.

The borehole thermal energy storage system is used in conjunction heat pumps and other equipment to provide efficient and environmentally benign heating and cooling, capable of regulating the indoor climate of many of the university's buildings. The facility significantly reduces the energy consumption for heating and cooling, compared with what would be required using conventional technology.

The working fluid for the borehole heat exchangers is a glycol solution. It circulates in polyethylene U-tubes, through an interconnected, underground network.

The working fluid circulates through tubes into the wells and receives heat from the ground in winter. The working fluid transports the heat into the buildings. In summer, the system operates in a reverse manner, extracting heat from the building and transferring it to the ground.

The system has been operating since 2003, when drilling was completed (Fig. 12). The drilling was carried out over more than 100 days, by three drill rigs that each drilled one hole per day.

<span id="page-115-0"></span>![](_page_115_Picture_2.jpeg)

FIG. 12 Borehole thermal energy storage system at UOIT, highlighting almost 400 boreholes extending over 200m below the ground surface.

#### 12. CONCLUSIONS

GSHPs offer numerous advantages for space heating and cooling applications as well as heating domestic hot water and are therefore growing in popularity. The type and capacity of the GSHP and heating loop employed for a given application depends on the type of building(s), land availability and legal, and other requirements of relevant government bodies. The efficiencies of GSHP systems, as reflected in their coefficients of performance, are dependent on system and operating parameters. Some of these have a significant effect of the performance and coefficients of performance of GSHP systems. GSHPs offer potential to reduce GHG emissions for heating and cooling applications, compared to fossil fuel-based space heating systems as well as air-source heat pump systems. The growing interest in using GSHPs for space heating is observed in many countries and has led to significant annual growth in the number of GSHP units installed in recent years.

#### REFERENCES

- [1] [Ediger VS, Hosgor E, Surmeli AN, Tatlidil H. Fossil fuel sustainability index: an application of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0550) [resource management. Energy Policy 2007;35:2969](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0550)–77.
- [2] [Hammond GP. Energy, environment and sustainable Developement: A UK perspective. Trans](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0555) [Inst Chem Eng B: Process Saf Environ Protect 2000;78:304](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0555)–23.
- [3] U.S. Department of Energy. Geothermal Today: 2003 Geothermal Technologies Program highlights (revised) [information pamphlet]. Washington, USA, May 2004.

- <span id="page-116-0"></span>[4] Geothermal Energy Basics (course notes) [online]. Course R-1002, PDHengineer, Houston, TX [cited 2017.05.04]. Available from [PDHengineer.com.](http://PDHengineer.com)
- [5] Geothermal Resources Council. What is Geothermal? [online]. [cited 2017.05.04]. Available from <http://www.geothermal.org/what.html>.
- [6] Natural Resources Canada. Commercial Earth Energy Systems: a Buyer's guide, Canada, 2002.
- [7] [Bloomquist RG. Geothermal heat pumps four plus decades of experience. GHC Bulletin:](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0560) [Washington State University Energy Program; Dec. 2009.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0560)
- [8] [Hwang Y, Radermacher R, Wang X. Investigation of potential benefits of compressor cooling.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0565) [Appl Therm Eng 2008;28:1791](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0565)–7.
- [9] [Ma G-Y, Chai Q-H. Characteristics of an improved heat-pump cycle for cold regions. Appl](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0570) [Energy 2004;77:235](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0570)–47.
- [10] [World Bank Group. Economic analysis of environmental externalities. In: Pollution preven](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0575)[tion and abatement handbook. July 1998.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0575)
- [11] World Pumps. Heat pump technology for energy efficient building. Feature HVAC 2007, 22–25.
- [12] Darling, D. Vertical Ground Loop [online]. The Encyclopedia of Alternative Energy and Sustainable Living. [cited 2017.05.04]. Available from [http://www.daviddarling.info/](http://www.daviddarling.info/encyclopedia/G/AE_ground_loop.html) [encyclopedia/G/AE\\_ground\\_loop.html](http://www.daviddarling.info/encyclopedia/G/AE_ground_loop.html).
- [13] [Chiasson A. Geothermal heat pump systems: closed-loop design considerations. Oregon, U.S.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0580) [A.: Geo-Heat Centre; 2007.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0580)
- [14] U.S. Department of Energy: Office of Energy Efficiency and Renewable Energy. Geothermal Heat Pump Systems [online]. [cited 2017.05.04]. Available from [https://energy.gov/](https://energy.gov/energysaver/geothermal-heat-pumps) [energysaver/geothermal-heat-pumps](https://energy.gov/energysaver/geothermal-heat-pumps).
- [15] [Omer AM. Ground-source heat pumps systems and applications. Renew Sust Energ Rev](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0585) [2008;12:344](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0585)–71.
- [16] [Natural Resources Canada. Ground-Source Heat Pumps \(Earth-Energy Systems\). Section 5 of](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0590) [heating and cooling with a heat pump.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0590) Revised ed; 2004.
- [17] RETScreen International. Clean energy project analysis: RETScreen Engineering and Cases Textbook, Natural Resources Canada, 2005.
- [18] [Healy PF, Ugursal VI. Performance and economic feasibility of ground source heat pumps in](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0595) [cold climates. Int J Energy Res 1997;21:857](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0595)–70.
- [19] Curtis, R.; Lund, J.; Sanner, B.; Rybach, L.; Hellstr€om, G. Ground Source Heat Pumps— Geothermal Energy for Anyone, Anywhere: Current Worldwide Activity. Proceedings World Geothermal Congress 2005, Antalya, Turkey, 24–29.
- [20] Climate Master. Water to Water System Design Guide [Information Pamphlet]. Tranquility & Genesis Water-to-Water Systems, Next Energy Geothermal, CANA.
- [21] US Department of Energy, Energy Efficiency & Renewable Energy. DOE/EE 0395, February, 2011; [online]. [cited 2017.05.04]. [www.energysavers.gov](http://www.energysavers.gov).
- [22] [Dowlatabadi H, Hanova J. Strategic GHG reduction through the use of ground source heat](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0605) [pump technology. Environ Res Lett 2007;2:1](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0605)–8.
- [23] [Sarbu L, Sebarchievici C. General review of ground-source heat pump Systems for Heating](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0610) [and Cooling of buildings. Energ Buildings 2014;70:441](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0610)–54.
- [24] [Self SJ, Reddy BV, Rosen MA. Ground-source heat pumps as clean energy systems: funda](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0615)[mentals, applications and parametric performance analyses. In: Harris AM, editor. Clean](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0615) [energy: Resources, production and developments. New York, NY: Nova Science Publishers;](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0615) [2011. p. 87](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0615)–146.
- [25] [Omer AM. Experimental investigation of the performance of a ground-source heat pump sys](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0620)[tem for buildings heating and cooling. J Environ Res Manage 2015;6:204](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0620)–24.

- <span id="page-117-0"></span>
- [26] [Lund JW, Boyd TL. Direct utilization of geothermal energy 2015 worldwide review. Geother](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0625)[mics 2016;60:66](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0625)–93.
- [27] [Ma G-Y, Zhao H-X. Experimental study of a heat pump system with flash-tank coupled with](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0630) [scroll compressor. Energ Buildings 2008;40:697](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0630)–701.
- [28] [Valizade L. Ground source heat pumps. J Clean Energy Technol 2013;1:216](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0635)–9.
- [29] [Hepbasli A, Balta MT. A study on modeling and performance assessment of a heat pump sys](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0640)[tem for utilizing low temperature geothermal resources in buildings. Build Environ](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0640) [2007;42:3747](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0640)–56.
- [30] [Hepbasli A. Thermodynamic analysis of a ground-source heat pump system for district heat](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0645)[ing. Int J Energy Res 2005;29:671](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0645)–87.
- [31] [Akdemir O, Hepbasli A. Energy and exergy analysis of a ground source \(geothermal\) heat](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0650) [pump system. Energy Convers Manag 2004;45:737](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0650)–53.
- [32] [Yrjola J, Laaksonen E. Domestic hot water production with ground source heat pump in apart](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0655)[ment buildings. Energies 2015;8:8447](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0655)–66.
- [33] [Omer AM. Review: direct expansion ground source heat pumps for heating and cooling. Int](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0660) [Res J Eng 2013;1:27](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0660)–48.
- [34] [Rezaie B, Reddy BV, Rosen MA. Thermodynamic analysis and the design of sensible thermal](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0665) [energy storages. Int J Energy Res 2017;41:39](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0665)–48.
- [35] [Kulcar B, Goricanec D, Krope J. Economy of exploiting heat from low-temperature geother](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0670)[mal sources using a heat pump. Energ Buildings 2008;40:323](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0670)–9.
- [36] [Arat H, Arslan O. Exergoeconomic analysis of district heating system boosted by the geother](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0675)[mal heat pump. Energy 2017;119:1159](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0675)–70.
- [37] [Wu R. Energy efficiency technologies—air source heat pump vs ground source heat pump.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0680) [J Sustain Develop 2009;2:14](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0680)–23.
- [38] [Hanova J, Dowlatabadi H, Mueller L. Ground source heat pump Systems in Canada: econom](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0685)[ics and GHG reduction potential, discussion paper, RFF DP 07](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0685)–18. Washington, DC: [Resources for the Future; May 2007.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0685)
- [39] [Self SJ, Reddy BV, Rosen MA. Geothermal heat pump systems: status review and comparison](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0690) [with other heating options. Appl Energy 2013;101:341](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0690)–8.
- [40] [Luo J, Rohn J, Xiang W, Bertermann D, Blum P. A review of ground investigations for ground](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0695) [source heat pump \(GSHP\) systems. Energ Buildings 2016;117:160](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0695)–75.
- [41] [Molavi J, McDaniel J. A review of the benefits of geothermal heat pump systems in retail](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0700) [buildings. Procedia Eng 2016;145:1135](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0700)–43.
- [42] [Ali Kara Y. Experimental performance evaluation of a closed-loop vertical ground source](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0705) [heat pump in the heating mode using energy analysis method. Int J Energy Res](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0705) [2007;31:1504](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0705)–16.
- [43] [Reda F, Arcuri N, Loiacono P, Mazzeo D. Energy assessment of solar technologies coupled](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0710) [with a ground source heat pump system for residential energy supply in southern European](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0710) [climates. Energy 2015;9:294](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0710)–305.
- [44] [Emmi G, Zarrella A, De Carli M, Galgaro A. An analysis of solar assisted ground source heat](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0715) [pumps in cold climates. Energy Convers Manag 2015;106:660](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0715)–75.
- [45] [Busato F, Lazzarin R, Noro M. Ground or solar source heat pump Systems for Space Heating:](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0720) [Which is better? Energetic Assessment based on a Case Study. Energ Buildings](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0720) [2015;102:347](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0720)–56.
- [46] Sivasakthivel T, Murugesan K, Sahoo [PK. Optimization of ground heat exchanger](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0725) [parameters of ground source heat pump system for space heating applications. Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0725) [2014;78:573](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0725)–86.

- <span id="page-118-0"></span>[47] [Fan R, Gao Y, Hua L, Deng X, Shi J. Thermal performance and operation strategy optimization](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0730) [for a practical hybrid ground-source heat pump system. Energ Buildings 2014;78:238](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0730)–47.
- [48] [Self SJ, Reddy BV, Rosen MA. Ground source heat pumps for heating: parametric energy anal](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0735)[ysis of a vapor compression cycle utilizing an economizer arrangement. Appl Therm Eng](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0735) [2013;52:245](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0735)–54.
- [49] [Self SJ, Reddy BV, Rosen MA. Parametric performance analyses of geothermal heat pump](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0740) [systems. Int J Energy, Environ Econ 2012;20:563](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0740)–609.
- [50] [Ochsner K. Geothermal heat pumps: a guide for planning and installing. Earthscan: London,](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0745) [UK; 2008.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0745)
- [51] Natural Resources Canada. Survey 2000, Commercial and institutional building energy use: summary report. December 2003.
- [52] Natural Resources Canada, Details on Air Source Heat Pumps, Ground Source Heat Pumps; [online] [cited 2017.05.04], [www.nrcan.gc.ca/energy/publications/efficiency/heating-heat-pump.](http://www.nrcan.gc.ca/energy/publications/efficiency/heating-heat-pump)
- [53] [Esen H, Esen M, Inalli MA. Techno-economical comparison of ground-coupled and air](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0750) [coupled heat pump system for space cooling. Build Environ 2007;42:1955](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0750)–65.
- [54] [Cengel YA, Boles MA. Thermodynamics: an engineering approach. 8th ed. New York, NY:](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0755) [McGraw Hill; 2015.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0755)
- [55] [Ground-source heat pumps produce savings for commercial building. Earth Energy: Case](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0760) [study, Natural Resources Canada.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0760) ISBN 0–662-32756-X; 2002.
- [56] [Rosen MA, Koohi-Fayegh S. Geothermal energy: sustainable heating and cooling using the](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0765) [ground. London: Wiley; 2017.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0765)
- [57] [Dincer I, Rosen MA. Thermal energy storage: systems and applications. 2nd ed. London:](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0770) [Wiley; 2011.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0770)
- [58] [Sapi](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0775)[nska-S´liwa A, Rosen MA, Gonet A, S´liwa T. Deep borehole heat exchangers: a conceptual](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0775) [review. Int J Air-Cond Refrig 2016;24\(1\):1630001.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0775)

#### <span id="page-119-0"></span>Chapter 7.4

# CCHP for Buildings: Design Methodologies, Operational Strategies, and Optimization Schemes

Heejin Cho and Pedro J. Mago

Mississippi State University, Mississippi State, MS, United States

#### 1. INTRODUCTION

Conventional thermal power plants produce electricity with about 37% efficiency converting the fuel's available energy into electric power [\[1\].](#page-129-0) The majority of the fuel energy content is lost at the generation facility in a form of waste heat. Additional energy losses occur during the transmission and distribution of electric power to individual users. Inefficiencies and environmental issues associated with conventional power plants provide the thrust for developments in "onsite" and "near-site" power generation. Combined cooling, heating, and power (CCHP) systems<sup>1</sup> have the potential to increase resource energy efficiency and to reduce air pollutant emissions dramatically. CCHP systems produce both electric and usable thermal energy onsite or near site, converting 75%–80% of the fuel source into useful energy [\[2\]](#page-129-0). CCHP systems typically require only three-fourths of the primary energy that is required to operate separate heat and power systems [\[3\].](#page-129-0)

The International Energy Agency (IEA) [\[1\]](#page-129-0) reported that combined heat and power (CHP) systems, including CCHP systems, generate about 9% of the global power generation. The global capacity of CHP systems is estimated at around 330 GWe<sup>2</sup> [\[4\].](#page-129-0) According to IEA's scenario [\[4\],](#page-129-0) the G8 + 5 countries<sup>3</sup> have the potential to raise their CHP systems capacity over 830 GWe in 2030. In the United States, the total CHP systems capacity in 2012 was estimated at 85 GWe [\[5\].](#page-130-0) European CHP systems potential studies indicate that the total capacity in Europe can be raised to within the range of 150–250 GWe by 2025 [\[6\]](#page-130-0).

<sup>1.</sup> CCHP originally stands for Combined Cooling, Heating, and Power. In the literature, CCHP is also referred to by various names for slightly different applications such as CHP (combined heat, and power), CHCP (combined heating, cooling, and power), BCHP (building cooling, heating, and power), DER (distributed energy resources), cogeneration, and trigeneration. Throughout the study, CCHP is used to refer to applications of combined cooling, heating, and power for Buildings.

<sup>2.</sup> Gigawatt-electric (GWe) is one billion watts of electric capacity.

<sup>3.</sup> The G8 + 5 countries consist of G8 (Group of Eight) nations including Canada, France, Germany, Italy, Japan, Russia, the United Kingdom, and the United States and 5 nations of the leading emerging economies including Brazil, China, India, Mexico, and South Africa.

The application of CCHP systems also has great potential to reduce carbon dioxide (CO2) emissions: IEA [\[4\]](#page-129-0) reported that CHP systems, including CCHP systems, can potentially reduce CO2 emissions arising from new generation by more than 10% (950 Mt./year)<sup>4</sup> in 2030, which is equivalent to one and a half times of the total annual emissions of CO2 from power generation in India. By 2030 the implementation of CHP systems has the potential to reduce CO2 emissions in the United States by 70 Mt./year for buildings and 80 Mt./year for industries [\[7\].](#page-130-0) In Europe, CCHP systems has been estimated to have been responsible for about 15% of the greenhouse gas emissions reductions (57 Mt) between 1990 and 2005 [\[4\]](#page-129-0).

A typical CCHP system for a building consists of a power generation unit (PGU) working together with heating, ventilation, and air-conditioning (HVAC) components, such as heat pumps, absorption chillers, cooling towers, and/or air handling units (AHUs). A variety of PGUs can be used in CCHP systems. Some of them include microturbines, internal combustion (IC) engines, external combustion engines, fuel cells, etc. Fig. 1 illustrates a schematic of a CCHP system. As shown in the figure, fuel (FPGU) is supplied to the PGU, and it produces electric energy (ElPGU) and rejects heat as a byproduct, normally wasted in many applications. This electric energy is used to power appliances and lights in the building (Elbuilding) and to operate auxiliary cooling and heating components (Elcomp). If the PGU does not generate enough electricity to satisfy the demand, the difference (Elgrid) can be imported from the electric grid (EG). Both ElPGU and Elgrid can be stored using batteries and super-capacitors, when necessary. On the other hand, if the PGU generates more electricity than the one needed, the excess electricity (Elexcess) can be exported or sold to the EG in locations where this is option is available. The recovered waste heat (Qrcv) from the PGU is used to produce cooling or heating (Qcool or Qheat) to satisfy the building thermal demand. If the heat recovered from the PGU is not enough

![](_page_120_Figure_4.jpeg)

FIG. 1 Schematic of a building CCHP system [\[8\]](#page-130-0).

<sup>4.</sup> Megaton (Mt) is one million tons. Gas emissions are often expressed in terms of megatons.

<span id="page-121-0"></span>to fulfill the thermal energy requirements of the building, a boiler is used to offset the deficit heat (Qboiler). Both Qrcv and Qboiler can be stored using thermal energy storages (TESs) if necessary. For building space cooling and heating, either absorption chillers or heat pumps can be used depending on the building electric and thermal load requirements.

# 2. DESIGN METHODOLOGIES

Design of CCHP systems involves selection of the type and size of the system components, for example, prime movers, energy storages, heat exchangers, chillers, heat pumps, etc. The selection process must take into consideration the efficiencies of individual components, the system operating strategy, and the building demand for power, heating, and cooling [9–[12\].](#page-130-0) A well-designed CHP system should balance cost savings, real-energy savings based on primary energy consumption, and net emission of pollutants [\[13\]](#page-130-0).

The prime mover or PGU is one of the main components of a CCHP system. Therefore, it has to be carefully selected to guarantee the desired performance of the CCHP system. Different types of prime movers or PGUs can be used in CCHP systems. Some of them include reciprocating IC engines, steam turbines, combustion turbines, microturbines, fuel cells, Stirling engines, etc. The advantages, drawbacks, and analyses of prime movers used in various CCHP system designs are often discussed in many literatures [\[9,14](#page-130-0)–18]. Wu and Wang [\[18\]](#page-130-0) summarized the characteristics and parameters of prime movers in CCHP system designs. They identified that the characteristics of prime movers, such as system efficiency, capacity range, and power-to-heat ratio, are important factors to determine the optimal size and type of prime movers for CCHP applications. A comparative analysis of different prime movers used in CCHP systems and their selection criteria can be found in Al-Sulaiman et al. [\[19\]](#page-130-0). [Table 1](#page-122-0) summarizes the typical performance and cost of a selection of different prime movers, such as the prime mover efficiency, the overall CHP efficiency, typical capacity, and the installed cost and the operating and maintenance (O&M) cost, for different CHP technologies. This table is intended to serve as a reference to readers and a more accurate number must be estimated for any specific application and project location.

# 2.1 Optimal Sizing of CCHP

Once the type of a prime mover is selected, it is important to determine a rational capacity to maximize availability of the prime mover. This is a complicated task because it is necessary to take into account the systems' annual operational strategies that consider the variations of electric and thermal energy demands and the deviations of electricity and fuel prices throughout the year [\[20\]](#page-130-0). This problem can be effectively dealt with using an optimization programming technique, such as linear programming (LP). Yokoyama et al. [\[20\]](#page-130-0) proposed an

<span id="page-122-0"></span>TABLE 1 Summary of Typical Performance Characteristics and Cost for CHP Systems With Different Prime Movers [\[3\]](#page-129-0)

|                | Engines     | Turbine         | Microturbine | Fuel Cell       |
|----------------|-------------|-----------------|--------------|-----------------|
| 5%–40%         | 27%–41%     | 24%–36%         | 22%–28%      | 30%–63%         |
| 80%            | 77%–80%     | 66%–71%         | 63%–70%      | 55%–80%         |
| 0.5–<br>300    | 0.005–10    | 0.5–300         | 0.03–1.0     | 0.2–2.8         |
| 670–<br>1100   | 1500–2900   | 1200–<br>3300   | 2500–4300    | 5000–<br>6500   |
| 0.006–<br>0.01 | 0.009–0.025 | 0.009–<br>0.013 | 0.009–0.013  | 0.032–<br>0.038 |
|                |             |                 |              |                 |

optimal planning method for determining the sizes of cogeneration plants under consideration for their annual operational strategies. They demonstrated that sizes of prime movers can be effectively determined using mixed-integer linear programming (MILP) in an example of a gas turbine CHP plant. In the same manner, Weiding and Beihong [\[21\]](#page-130-0) develop an optimal sizing method to determine the size of a gas turbine cogeneration plant using mixed integer nonlinear programming (MINLP). They applied their method to a cogeneration plant used for a hospital in Shanghai, China to show the effectiveness of their method. Ren et al. [\[22\]](#page-130-0) demonstrated that a MINLP model of a CHP plant can be effectively used to determine the optimal size of a prime mover and storage tank for residential CHP systems. Maor and Reddy [\[23\]](#page-130-0) reported their research work to generate the "necessary data for certain characteristic building types with rationally designed and sized BCHP equipment" and Reddy and Maor [\[24\]](#page-130-0) presented "a methodology to select representative building types and geographic climates to perform careful design and sizing of the BCHP systems and equipment." The design of CCHP systems should consider the tradeoffs among cost-savings, real-energy savings based on primary energy consumption, and net emission of pollutants. A detailed technical description and analysis of PGUs and thermally activated components that can be used in CCHP systems can be found in Mississippi Micro-CHP and Bio-fuel Center [\[25,26\]](#page-131-0). The sizing of the PGU also depends on the desired operational strategy of the CCHP system, which is discussed in the next section.

#### <span id="page-123-0"></span>3. OPERATIONAL STRATEGIES

CHP systems can be controlled by several possible operation strategies. The most common kinds of operation strategies found in the literature are summarized as follows [\[13,27,28](#page-130-0)–36]:

- (1) Following the electric load (FEL): when the CCHP system operates under this strategy, the PGU generates all the electricity needed to satisfy the electric demand and the waste heat is used to satisfy all or part of the building's thermal load. If the recovered heat is not sufficient to satisfy the thermal demand an auxiliary boiler can be used to supplement the heat needed by the facility. On the other hand, if the recovered heat is more than the one required by the building, the excess could be stored or discarded. Some authors defined this strategy as electric demand management (EDM) [\[27\].](#page-131-0)
- (2) Following the thermal load (FTL): under this strategy, the system satisfies the building's thermal load, and the electricity generated by the PGU is used to satisfy part or all of the building's electric demand. If the electricity produced by the CCHP system cannot meet the electric requirements, additional electricity must be purchased from the grid. On the other hand, if the electricity produced is more than the amount needed by the building, the excess electricity can be stored or sold back to the electric grid. However, this option is not available at all locations. Some authors refer to this strategy as thermal demand management (TDM) [\[27\].](#page-131-0)
- (3) Base load operation: when the system covers only a constant amount of the electric load of the facility. In this case electricity has to be imported from the grid to completely satisfy the electric demand. In addition, an auxiliary boiler can be used if the recovered heat from the PGU is not sufficient to satisfy the thermal demand.

Although the above-mentioned strategies are the most common ones in CCHP system operation, they may not guarantee the best performance of the system, and the use of more than one strategy may be used through the year. Yokoyama et al. [\[20\]](#page-130-0) stated that the simple operational strategies may not result an economically feasible solution because the operation of cogeneration system is subjected not only to the variation of load demands, but also to the fuel prices. Sundberg and Henning [\[37\]](#page-131-0) addressed the influence of fuel price to operate CHP systems in an economically optimal condition. Chao-zhen et al. [\[38\]](#page-131-0) emphasized the importance of the studies on the energy load demands from the CHP facility to determine an optimal operation strategy. In the following sections, various methodologies that can be used in CCHP operations are discussed.

# 3.1 FEL and FTL Operations

Variations of the FEL and FTL operational strategies have been investigated by several authors to optimize the system based on energy, emission, or operational cost. Kavvadias et al. [\[32\]](#page-131-0) discussed the factors that affect the operation and the feasibility of investment in CCHP systems.

They proposed an electrical-equivalent load following strategy where the electrical demand includes only the portion of the cooling demand that the absorption chiller cannot meet. Their results indicated that the proposed strategy was superior to conventional strategies (FEL and FTL) from both the economic and energetic point of view, when applied with maximum demand tariffs, as it was proven to have two major benefits: better load coincidence and peak reduction. Mago and Chamra [\[34\]](#page-131-0) introduced an operational strategy in which a CCHP system follows a hybrid electric-thermal load strategy (HETS). Results indicated that the HETS was a good alternative for CCHP system operation since it provides reduction of operational cost, emissions, and primary energy consumption.

Gu et al. [\[39\]](#page-131-0) introduced an operational strategy called energy island mode, which is a variation on FEL in which the system is sized so that it can provide all of the electrical needs of a facility which is not grid connected. Liu et al. [\[40\]](#page-131-0) proposed a new CCHP system operational strategy based on the electric cooling to cool load ratio, which describes the portion of the cooling load that is met by the electric chiller, and they used an optimization algorithm to determine the optimal PGU capacity. Wang et al. (2011) discovered in their sensitivity analysis that the PGU capacity has more influence on performance than the ratio of electric cooling to cool load. Chicco and Mancarella [\[41\]](#page-131-0) developed a matrix modeling of small-scale trigeneration systems and applied the developed model to optimize the operation of the system. The proposed formulation provided the basic framework for formulating optimization problems that deal with management of trigeneration systems within an energy market perspective. Jing et al. [\[42\]](#page-132-0) optimized the operation strategy of a BCHP system operating FEL and FTL based on life-cycle assessment. Their optimization results indicated that FEL strategy provided more environmental benefits than FTL strategy. Fang et al. [\[43\]](#page-132-0) proposed an optimal operational strategy based on FEL and FTL strategies that depends on an integrated performance criterion (IPC). Using the proposed strategy, the operation of the CCHP system is divided into different regions by one to three border surfaces estimated by the CCHP system energy requirements and the IPC. The IPC simultaneously accounts for the reduction of primary energy consumption, operational cost, and CO2 emissions.

Fumo et al. [\[44\]](#page-132-0) presented an emission operational strategy with the objective of minimizing the CO2 emissions from CCHP systems. In their study, the CCHP system was operated FEL, guaranteeing that the CCHP system always generated less emission than the conventional case (separate production of electricity and heat). They reported that although the proposed strategy might not offer the best performance in terms of primary energy consumption or operational cost, it is valuable for facilities that are required to reduce their emissions. In another study, Fumo et al. [\[45\]](#page-132-0) introduced a building primary energy ratio <span id="page-125-0"></span>(BPER) parameter to evaluate the energy performance of CCHP systems. This parameter was used to measure the variation of the primary energy consumption of the CCHP system versus the conventional system, which allows controlling the CCHP system to operate only when primary energy is being saved. Smith and Mago [\[46\]](#page-132-0) compared with a hybrid method which either follows the thermal or the electric demand in a given time period, in order to minimize the amount of excess electrical or thermal energy produced by the CHP system. The proposed hybrid method showed higher CHP system efficiencies for the simulated building in a wide range of climate conditions.

# 3.2 Advanced Control for Real-Time Operation

Advanced control algorithms are becoming a subject of increasing interest in the CHP research community. For instance, reports [\[47](#page-132-0)–49] from pacific northwest national laboratory (PNNL) address a variety of control related tasks concerned with CHP operation. The objectives are to "ensure optimal performance, increase reliability, and lead to the goal of clean, efficient, reliable and affordable next generation energy systems" [\[48\]](#page-132-0). The algorithms are categorized into five major groups: (1) performance monitoring, (2) automated commissioning verification, (3) automated fault detection and diagnostics, (4) automated reconfiguration and correction, and (5) supervisory controls [\[49\].](#page-132-0) Cho et al. [\[8\]](#page-130-0) proposed a supervisory feed-forward control system as shown in [Fig. 2](#page-126-0) for CCHP system operation based on short-term weather forecasting. In their proposed system, electric and TES systems are included to enhance the electric and thermal energy management of the system. Yun et al. [\[50\]](#page-132-0) developed an optimal hierarchical CCHP system control algorithm to obtain real-time optimal decisions on the energy management of the CCHP equipment and building.

#### 4. OPTIMIZATION SCHEMES

CCHP system can be optimized based on different parameters. An optimal operation strategy of a CCHP system can be effectively determined using mathematical optimization techniques, such as genetic algorithms, linear programming, and stochastic optimization, with the objective of minimizing the operational cost, primary energy consumptions, and/or greenhouse gas emissions. For instance, an optimization problem can be formulated as shown in Eq. (1) to minimize the total operational cost of a CCHP system while satisfying the total energy demand [\[8\].](#page-130-0)

Minimize 
$$z(x) = \sum_{t=1}^{T} \left\{ c_1(t)x_1(t) + c_2(t)x_2(t) + c_3(t)x_3(t) - c_4(t)x_{13}(t) \right\}$$
 (1)

where variables Elgrid(t), Fpgu(t), and Fboiler(t) represent the electric energy from the electric grid, the fuel energy for the PGU, and the fuel energy to

<span id="page-126-0"></span>![](_page_126_Figure_2.jpeg)

FIG. 2 Feed-forward control loop with short-term forecasting for a CCHP system in an optimization framework [\[8\]](#page-130-0).

operate the boiler in time period <sup>t</sup> (t¼1, 2, …, <sup>n</sup>). The term cel(t) represents the cost of purchasing 1 kWh of electricity, cf\_pgu(t) represents the cost of fuel that is used to produce 1 kWh of energy in the PGU, and cf\_boiler(t) represents the cost of fuel that is used to produce 1 kWh of energy in the boiler. Variable Elexcess(t) represents the amount of electric energy sold back to the electric grid in period t, and cel\_ex(t) represents the selling price per kWh of electricity. There is an upper bound on the values for the decision variables Fpgu(t) and Fboiler(t). These bounds are equal to the maximum amount of energy that can be produced in a time period by the PGU and boiler, respectively, due to their production capacity. There is no such limit on the amount of electricity that can be purchased from the grid. Along with the objective function, a set of constraints are formulated to specify conditions for the decision variables that are required to be satisfied. The constraints are determined based on the equipment characteristics (e.g., efficiency of equipment), energy flow relationship, and the operational limitations [\[51\]](#page-132-0).

The effectiveness of using mathematical optimization techniques to determine optimized operations of CCHP systems has been demonstrated in the following studies. Yokoyama et al. [\[20\]](#page-130-0) demonstrated that an optimal operation planning can be achieved using MILP. Sakawa et al. [\[52\]](#page-132-0) formulated operational planning problems of district heating and cooling plants as mixed binary linear programming problems and demonstrated the economical feasibility and efficiency of the proposed method. Lahdelma and Hakonen [\[53\]](#page-132-0) modeled the hourly CHP operation as an LP problem to obtain cost-efficient solutions using their proposed Power Simplex algorithm. Rong and Lahdelma [\[54\]](#page-132-0) proposed the specialized Tri-Commodity Simplex algorithm to minimize the energy production and purchase costs as well as CO2 emission costs of CHP systems. Wang et al. [\[51\]](#page-132-0) optimized BCHP systems to maximize the energy savings and reduction of environmental impact using genetic algorithm. In another study, Wang et al. [\[55\]](#page-132-0) optimized a CCHP system using genetic algorithm based on three criteria: primary energy saving, annual total cost saving, and CO2 emission reduction. An optimal energy dispatch algorithm that minimizes the cost of energy based on energy efficiency constraints for each component can be used in CCHP operation [\[56\].](#page-132-0) This optimal energy dispatch algorithm can be further considered to optimize the operation of CCHP systems for different climate conditions based on operational cost, primary energy consumption, and emissions reduction [\[57\].](#page-132-0) In a recent study, Hu and Cho [\[58\]](#page-132-0) proposed a stochastic multi-objective optimization model to optimize the operation strategy of CCHP systems for different climate conditions based on operational cost, primary energy consumption, and CO2 emissions. They added the probability constraints into the stochastic model to guarantee the optimized CCHP operation strategy is reliable to satisfy the stochastic energy demand. Lozano et al. [\[59\]](#page-133-0) also used a linear programming model to determine the optimal operation strategy corresponding to the minimum variable cost. Likewise, Li et al. [\[60\]](#page-133-0) developed a mixed integer linear program optimal model to minimize the annual total cost, primary energy consumption, and CO2 emission of CCHP systems for a given commercial facility.

Uncertainty estimation and quantification can add significant values to increase the overall system efficiency and liability in CCHP system operations. The following studies demonstrate methodologies to conduct uncertainty analysis for optimal operations of CCHP systems. Li et al. [\[61\]](#page-133-0) proposed a mix-integer nonlinear programming (MINLP) model to study the impacts of the average, uncertainty, and peaks of energy demands on the economic performance of CCHP system. Smith et al. [\[62\]](#page-133-0) studied uncertainties in the thermal load, natural gas prices, electricity prices, and engine performance, and investigated the performance of CCHP system in terms of operational cost, PEC, and CDE under these uncertainties. An uncertain programming model which integrates the Monte-Carlo method (MCM) and mixed-integer nonlinear programming was developed to derive optimized CCHP operation strategy under energy demand uncertainty [\[63\].](#page-133-0) Wang and Singh [\[64\]](#page-133-0) developed a stochastic model for the CHP system economic dispatch which could simultaneously optimize the performance of CCHP in terms of production cost, power generation deviation, and heat generation deviation, and propose an improved PSO algorithm to study the stochastic model.

#### <span id="page-128-0"></span>4.1 Operation With Energy Storage

TESs are often used to help manage peak energy demand for better performance and economy or to storage excess energy resulting from the CCHP operational strategy used. According to Haeseldonckx and D'haeseleer [\[65\],](#page-133-0) the use of thermal storage tanks prolongs the yearly operation time of a CHP facility and allows the PGU to operate more continuously. In their investigation, it is shown that a small TES reduces CO2 emissions to about a one-third of the reference case without a heat buffer. Wang and Ma [\[66\]](#page-133-0) suggested that a proper optimization scheme is required when a system includes TESs. They stated that "the optimization related to the systems without storage is a quasi-steady, singlepoint optimization, while the optimization associated with the systems with storage is the dynamic optimization determining a trajectory of setpoints." Modified linear programming has been used in many studies to operate TESs effectively although nonlinear or dynamic programming techniques can also be used. The reason is that nonlinear or dynamic programming techniques may take relatively longer time or may not converge when a large number of variables are used. Yokoyama and Ito [\[67\]](#page-133-0) presented a revised decomposition method for solving large-scale MILP problems with block angular structure to efficiently conduct the operational planning of TESs. Henze et al. [\[68\]](#page-133-0) developed an optimization strategy for a chilled water plant using a thermal storage system: mixed integer programming is used to optimize the chiller dispatch, and dynamic programming is accommodated to optimize the charge/discharge strategy of the TES system. Ren et al. [\[22\]](#page-130-0) developed a mixed integer nonlinear programming model to operate CHP plant with a thermal storage tank. Smith et al. [\[69\]](#page-133-0) investigated the performance of a CHP system with and without a TES option for eight different commercial building types located in Ch nnicago, IL. They reported that for the majority of the buildings, adding thermal storage provides further reductions in operational cost, PEC, and CDE as compared to the CHP system without TES. Yongliang et al. [\[70\]](#page-133-0) presented a study of using a novel energy storage system that stores excess energy from a trigeneration system in the form of compressed air and thermal heat. They reported that the proposed system is very promising for practical applications especially for the use of renewable energy due to good flexibility and simplicity of the configuration.

#### 5. CASE STUDIES

A large number of CHP and CCHP systems have been installed and operated worldwide and several case studies have been introduced and discussed by different organizations. International Energy Agency [\[71\]](#page-133-0) reported a variety of best practices with respect to energy and environmental policies to promote the use of CHP from around the world. For example, their report introduced that the Netherlands was able to achieve over 4 Mt. CO2-eq. GHG emissions reductions in the 1990s by promoting CHP systems based <span id="page-129-0"></span>on a fiscal investment credit at a cost of EUR 9 per ton CO2-eq. The U.S. Department of Energy (DOE) and U.S. Environmental Protection Agency (EPA) provide information in their websites about CHP systems installed and currently operating in the United States The U.S. DOE has created a web database for the U.S. CHP installations [\[72\]](#page-133-0), where users can obtain information about current CHP systems installed in different states by city, organization, application, prime mover type, capacity, and fuel type. Furthermore, they have provided descriptions of several case studies of CHP and CCHP systems in their website [\[73\].](#page-133-0) For example, they highlighted a case study of an installed CCHP system that enables 100% reliability in a leading medical campus in Houston, Texas. The system consisted on a high-efficiency natural gas-fired CHP system capable of producing 48MW of on-site generation and 149,685 L/h (330,000lb./h) of steam, with a 264 MWh TES tank and a 123MW chilled water system. Similarly, the U. S. EPA has introduced various CHP case studies in its website [\[74\]](#page-133-0). They have highlighted CHP systems for several applications, such as campus buildings, a library, a waste water treatment plant, utility plants, and office buildings. A variety of European CHP case studies has been introduced by the European Union in a report called Cogeneration Case Studies Handbook [\[75\]](#page-133-0). Their report summarized numerous CHP systems in different capacities from several European regions and sectors and it provided key insights to promote successful CHP projects and implementations.

#### 6. CONCLUSIONS

This chapter presented a review of design methodologies, operational strategies, optimization schemes, and case studies on CCHP systems for buildings. The most current research and emerging trends in CCHP technologies were introduced and discussed. The information collected in this chapter could be a used as a valuable source, for researchers, designers, and engineers, for the design and implementation of CCHP systems.

#### REFERENCES

- [1] International Energy Agency. Tracking clean energy progress 2016—energy technology perspectives 2016 excerpt IEA input to the clean energy ministerial. In: Technology. 2016. p. 1–82. [https://doi.org/10.1787/energy\\_tech-2014-en](https://doi.org/10.1787/energy_tech-2014-en).
- [2] International Energy Agency. (2008). Combined heat & power and emissions trading: options for policy makers. Paris, France.
- [3] U.S. Environmental Protection Agency. (2015). Catalog of CHP Technologies. Retrieved from [https://www.epa.gov/sites/production/files/2015-07/documents/catalog\\_of\\_chp\\_technologies.pdf.](https://www.epa.gov/sites/production/files/2015-07/documents/catalog_of_chp_technologies.pdf)
- [4] International Energy Agency. (2008). Combined heat and power: evaluating the benefits of greater global investment. Paris, France.

- <span id="page-130-0"></span>[5] International Energy Agency. (2016). Tracking Clean Energy Progress 2016. Retrieved from http://www.iea.org/publications/freepublications/publication/TrackingCleanEnergyProgress 2016.pdf.
- [6] International Energy Agency. (2007). Tracking industrial energy efficiency and CO2 emissions. Paris, France.
- [7] McKinsey & Company. (2007). Reducing U.S. Greenhouse Gas Emissions: How Much at What Cost?, New York, USA.
- [8] Cho H, Luck R, Chamra LM. Supervisory feed-forward control for real-time topping cycle CHP operation. J Energy Resour Technol 2010;132(1):12401. Retrieved from, https://doi. org/10.1115/1.4000920.
- [9] Action Energy. (2004). Combined heat and power for buildings: Good practice guide (GPG388). London, UK.
- [10] Robert, A., Zogg, R. A., Hamilton, S. D., and Williams, R. C. (2002). Cooling, heating, and power (CHP) for commercial buildings benefits analysis. Cambridge, MA. Retrieved from https://www1.eere.energy.gov/manufacturing/distributedenergy/pdfs/chp\_ benefits\_commercial\_buildings.pdf.
- [11] Sanaye S, Shokrollahi S. Selection and sizing of prime movers in combined heat and power systems. In: Proceedings of the ASME Turbo Expo 2004. 4:2004. p. 613–21. https://doi.org/ 10.1115/GT2004-53715.
- [12] Zogg R, Roth KW, Brodrick J. Using CHP systems in commercial buildings. ASHRAE J 2005;47:33-6. Retrieved from, http://www.scopus.com/inward/record.url?eid=2-s2.0-27344450531&partnerID=40&md5=ee199ae1f93279777a4dd27bd228a436.
- [13] Mago PJ, Fumo N, Chamra LM. Performance analysis of CCHP and CHP systems operating following the thermal and electric load. Int J Energy Res 2009;33:852-64. https://doi.org/ 10.1002/er.1526.
- [14] Educogen. (2001). The European Educational Tool on Cogeneration.
- [15] National Renewable Energy Laboratory. (2003). Gas-fired distributed energy resource technology characterizations. Golden, CO.
- [16] Resource Dynamics Corporation. (2001). Assessment of distributed generation technology applications. Vienna, VA.
- [17] WADE (World Alliance of Decentralized Energy), (2003). Guide to Decentralized Energy Technologies.
- [18] Wu DW, Wang RZ. Combined cooling, heating and power: a review. Progr Energy Comb Sci 2006;32(5-6):459-95. https://doi.org/10.1016/j.pecs.2006.02.001.
- [19] Al-Sulaiman FA, Hamdullahpur F, Dincer I. Trigeneration: a comprehensive review based on prime movers. Int J Energy Res 2011;35(3):233-58. https://doi.org/10.1002/er.1687.
- [20] Yokoyama R, Matsumoto Y, Ito K. Optimal sizing of a gas turbine cogeneration Plant in Consideration of its operational strategy. J Eng Gas Turbines Power 1994. https://doi.org/10.1115/ 1.2906806.
- [21] Weiding L, Beihong Z. An optimal sizing method for cogeneration plants. Energ Buildings 2006. https://doi.org/10.1016/j.enbuild.2005.05.009.
- [22] Ren H, Gao W, Ruan Y. Optimal sizing for residential CHP system. Appl Therm Eng 2008. https://doi.org/10.1016/j.applthermaleng.2007.05.001.
- [23] Maor I, Reddy TA, Cost penalties of near-optimal scheduling control of BCHP systems: Part Iselection of case study scenarios and data generation. ASHRAE Trans 2009;115(1).
- [24] Reddy TA, Maor I. Cost penalties of near-optimal scheduling control of BCHP systems: Part II—modeling, optimization, and analysis results. ASHRAE Trans 2009;115(1).

- <span id="page-131-0"></span>[25] Mississippi Micro-CHP and Bio-fuel Center. (2005). Cooling, heating, and power for buildings (CHP-B) instructional module. Mississippi State, MS, USA.
- [26] Mississippi Micro-CHP and Bio-fuel Center. (2005). Micro-Cooling, Heating, and Power Instructional Module. Mississippi State, MS, USA.
- [27] Cardona E, Piacentino A, Cardona F. Matching economical, energetic and environmental benefits: An analysis for hybrid CHCP-heat pump systems. Energy Convers Manag 2006;47 (20):3530–42. <https://doi.org/10.1016/j.enconman.2006.02.027>.
- [28] Cardona E, Piacentino A. A methodology for sizing a trigeneration plant in mediterranean areas. Appl Therm Eng 2003. [https://doi.org/10.1016/S1359-4311\(03\)00130-3.](https://doi.org/10.1016/S1359-4311(03)00130-3)
- [29] Chicco G, Mancarella P. From cogeneration to trigeneration: profitable alternatives in a competitive market. IEEE Trans Energy Convers 2006. [https://doi.org/10.1109/](https://doi.org/10.1109/TEC.2005.858089) [TEC.2005.858089](https://doi.org/10.1109/TEC.2005.858089).
- [30] Fumo N, Mago PJ, Smith AD. Analysis of combined cooling, heating, and power systems operating following the electric load and following the thermal load strategies with no electricity export. Proc Inst Mech Eng A: J Power Energy 2011;225(8):1016–25. [https://doi.org/10.1177/](https://doi.org/10.1177/0957650911402737) [0957650911402737](https://doi.org/10.1177/0957650911402737).
- [31] Hueffed AK, Mago PJ. Influence of prime mover size and operational strategy on the performance of combined cooling, heating, and power systems under different cost structures. Proc Inst Mech Eng A: J Power Energy 2010;224(5):591–605. [https://doi.org/10.1243/](https://doi.org/10.1243/09576509JPE922) [09576509JPE922.](https://doi.org/10.1243/09576509JPE922)
- [32] Kavvadias KC, Tosios AP, Maroulis ZB. Design of a combined heating, cooling and power system: Sizing, operation strategy selection and parametric analysis. Energy Convers Manag 2010. [https://doi.org/10.1016/j.enconman.2009.11.019.](https://doi.org/10.1016/j.enconman.2009.11.019)
- [33] Kong X, Wang R, Li Y, Wu J. Performance research of a micro-CCHP system with adsorption chiller. J Shanghai Jiaotong Univ (Sci) 2010;15(6):671–5. [https://doi.org/10.1007/s12204-](https://doi.org/10.1007/s12204-010-1067-2) [010-1067-2.](https://doi.org/10.1007/s12204-010-1067-2)
- [34] Mago PJ, Chamra LM. Analysis and optimization of CCHP systems based on energy, economical, and environmental considerations. Energ Buildings 2009;41(10):1099–106. [https://doi.](https://doi.org/10.1016/j.enbuild.2009.05.014) [org/10.1016/j.enbuild.2009.05.014](https://doi.org/10.1016/j.enbuild.2009.05.014).
- [35] Wang J-J, Jing Y-Y, Zhang C-F, Zhai Z. Performance comparison of combined cooling heating and power system in different operation modes. Appl Energy 2011;88(12):4621–31. [https://](https://doi.org/10.1016/j.apenergy.2011.06.007) [doi.org/10.1016/j.apenergy.2011.06.007.](https://doi.org/10.1016/j.apenergy.2011.06.007)
- [36] Wang J, Zhai Z, Jing Y, Zhang X, Zhang C. Sensitivity analysis of optimal model on building cooling heating and power system. Appl Energy 2011;88(12):5143–52. [https://doi.org/](https://doi.org/10.1016/j.apenergy.2011.07.015) [10.1016/j.apenergy.2011.07.015.](https://doi.org/10.1016/j.apenergy.2011.07.015)
- [37] Sundberg G, Henning D. Investments in combined heat and power plants: influence of fuel price on cost minimised operation. Energy Convers Manag 2002;43(5):639–50. [https://doi.](https://doi.org/10.1016/S0196-8904(01)00065-6) [org/10.1016/S0196-8904\(01\)00065-6](https://doi.org/10.1016/S0196-8904(01)00065-6).
- [38] Chao-zhen L, Jian-ming G, Xing-hua H. Influence of energy demands ratio on the optimal facility scheme and feasibility of {BCHP} system. Energ Buildings 2008;40(10):1876–82. [https://doi.org/10.1016/j.enbuild.2008.04.004.](https://doi.org/10.1016/j.enbuild.2008.04.004)
- [39] Gu Q, Ren H, Gao W, Ren J. Integrated assessment of combined cooling heating and power systems under different design and management options for residential buildings in Shanghai. Energ Buildings 2012;51:143–52. <https://doi.org/10.1016/j.enbuild.2012.04.023>.
- [40] Liu M, Shi Y, Fang F. A new operation strategy for CCHP systems with hybrid chillers. Appl Energy 2012;95:164–73. [https://doi.org/10.1016/j.apenergy.2012.02.035.](https://doi.org/10.1016/j.apenergy.2012.02.035)
- [41] Chicco G, Mancarella P. Matrix modelling of small-scale trigeneration systems and application to operational optimization. Energy 2009;34(3):261–73. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.energy.2008.09.011) [energy.2008.09.011](https://doi.org/10.1016/j.energy.2008.09.011).

- <span id="page-132-0"></span>[42] Jing Y-Y, Bai H, Wang J-J. Multi-objective optimization design and operation strategy analysis of BCHP system based on life cycle assessment. Energy 2012;37(1):405–16. [https://doi.](https://doi.org/10.1016/j.energy.2011.11.014) [org/10.1016/j.energy.2011.11.014](https://doi.org/10.1016/j.energy.2011.11.014).
- [43] Fang F, Wang QH, Shi Y. A novel optimal operational strategy for the CCHP system based on two operating modes. IEEE Trans Power Syst 2012. [https://doi.org/10.1109/](https://doi.org/10.1109/TPWRS.2011.2175490) [TPWRS.2011.2175490](https://doi.org/10.1109/TPWRS.2011.2175490).
- [44] Fumo N, Mago PJ, Chamra LM. Emission operational strategy for combined cooling, heating, and power systems. Appl Energy 2009;86(11):2344–50. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2009.03.007) [apenergy.2009.03.007.](https://doi.org/10.1016/j.apenergy.2009.03.007)
- [45] Fumo N, Mago PJ, Chamra LM. Cooling, heating, and power energy performance for system feasibility. Proc Inst Mech Eng A: J Power Energy 2008;222(4):347–54. [https://doi.org/](https://doi.org/10.1243/09576509JPE561) [10.1243/09576509JPE561](https://doi.org/10.1243/09576509JPE561).
- [46] Smith AD, Mago PJ. Effects of load-following operational methods on combined heat and power system efficiency. Appl Energy 2014;115:337–51. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2013.10.063) [apenergy.2013.10.063.](https://doi.org/10.1016/j.apenergy.2013.10.063)
- [47] [Brambley MR, Katipamula S, Jiang W. Monitoring and commissioning verification algorithms](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0940) [for CHP systems. WA: Richland; 2008.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0940)
- [48] [Brambley MR, Katipamula S. Specification of selected performance monitoring and commis](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0945)[sioning verification algorithms for CHP systems. WA: Richland; 2006.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf0945)
- [49] Katipamula, S., and Brambley, M. R. (2006). Advanced CHP control algorithms: Scope specification. Richland, WA.
- [50] Yun K, Cho H, Luck R, Mago PJ. Real-time combined heat and power operational strategy using a hierarchical optimization algorithm. Proc Inst Mech Eng A: J Power Energy 2011;225(4):403–12. [https://doi.org/10.1177/2041296710394287.](https://doi.org/10.1177/2041296710394287)
- [51] Wang J, Zhai Z, Jing Y, Zhang C. Optimization design of BCHP system to maximize to save energy and reduce environmental impact. Energy 2010;35(8):3388–98. [https://doi.org/](https://doi.org/10.1016/j.energy.2010.04.029) [10.1016/j.energy.2010.04.029.](https://doi.org/10.1016/j.energy.2010.04.029)
- [52] Sakawa, M., Kato, K., & Ushiro, S. (2000). Operation planning of district heating and cooling plants using genetic algorithms for mined 0–1 linear programming. Industrial Electronics Society, 2000. IECON 2000. 26th Annual Confjerence of the IEEE. [https://doi.org/10.1109/](https://doi.org/10.1109/IECON.2000.972461) [IECON.2000.972461.](https://doi.org/10.1109/IECON.2000.972461)
- [53] Lahdelma R, Hakonen H. An efficient linear programming algorithm for combined heat and power production. Eur J Oper Res 2003;148(1):141–51. [https://doi.org/10.1016/S0377-2217](https://doi.org/10.1016/S0377-2217(02)00460-5) [\(02\)00460-5.](https://doi.org/10.1016/S0377-2217(02)00460-5)
- [54] Rong A, Lahdelma R. An efficient linear programming model and optimization algorithm for trigeneration. Appl Energy 2005;82(1):40–63. [https://doi.org/10.1016/j.apenergy.2004.07.013.](https://doi.org/10.1016/j.apenergy.2004.07.013)
- [55] Wang J-J, Jing Y-Y, Zhang C-F. Optimization of capacity and operation for CCHP system by genetic algorithm. Appl Energy 2010;87(4):1325–35. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2009.08.005) [apenergy.2009.08.005.](https://doi.org/10.1016/j.apenergy.2009.08.005)
- [56] Cho H, Luck R, Eksioglu SD, Chamra LM. Cost-optimized real-time operation of CHP systems. Energ Buildings 2009;41(4):445–51. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.enbuild.2008.11.011) [enbuild.2008.11.011](https://doi.org/10.1016/j.enbuild.2008.11.011).
- [57] Cho H, Mago PJ, Luck R, Chamra LM. Evaluation of CCHP systems performance based on operational cost, primary energy consumption, and carbon dioxide emission by utilizing an optimal operation scheme. Appl Energy 2009;86(12):2540–9. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2009.04.012) [apenergy.2009.04.012.](https://doi.org/10.1016/j.apenergy.2009.04.012)
- [58] Hu M, Cho H. A probability constrained multi-objective optimization model for CCHP system operation decision support. Appl Energy 2014;116:230–42. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2013.11.065) [apenergy.2013.11.065.](https://doi.org/10.1016/j.apenergy.2013.11.065)

- <span id="page-133-0"></span>[59] Lozano MA, Carvalho M, Serra LM. Operational strategy and marginal costs in simple trigeneration systems. Energy 2009;34(11):2001–8. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.energy.2009.08.015) [energy.2009.08.015](https://doi.org/10.1016/j.energy.2009.08.015).
- [60] Li H, Fu L, Geng K, Jiang Y. Energy utilization evaluation of CCHP systems. Energ Buildings 2006;38(3):253–7. [https://doi.org/10.1016/j.enbuild.2005.06.007.](https://doi.org/10.1016/j.enbuild.2005.06.007)
- [61] Li CZ, Shi YM, Huang XH. Sensitivity analysis of energy demands on performance of CCHP system. Energy Convers Manag 2008;49(12):3491–7. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.enconman.2008.08.006) [enconman.2008.08.006](https://doi.org/10.1016/j.enconman.2008.08.006).
- [62] Smith A, Luck R, Mago PJ. Analysis of a combined cooling, heating, and power system model under different operating strategies with input and model data uncertainty. Energ Buildings 2010;42(11):2231–40. <https://doi.org/10.1016/j.enbuild.2010.07.019>.
- [63] Li C-Z, Shi Y-M, Liu S, Zheng Z, Liu Y. Uncertain programming of building cooling heating and power (BCHP) system based on Monte-Carlo method. Energ Buildings 2010;42 (9):1369–75. <https://doi.org/10.1016/j.enbuild.2010.03.005>.
- [64] Wang, L., & Singh, C. (2008). Stochastic combined heat and power dispatch based on multiobjective particle swarm optimization. Int J Electr Power Energy Syst, 30(3), 226–234. [https://](https://doi.org/10.1016/j.ijepes.2007.08.002) [doi.org/10.1016/j.ijepes.2007.08.002](https://doi.org/10.1016/j.ijepes.2007.08.002)
- [65] Haeseldonckx D, D'haeseleer W. The environmental impact of decentralised generation in an overall system context. Renew Sust Energ Rev 2008;12(2):437–54. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.rser.2006.07.004) [rser.2006.07.004](https://doi.org/10.1016/j.rser.2006.07.004).
- [66] Wang, S., & Ma, Z. (2008). Supervisory and optimal control of building HVAC systems: a review. HVAC&R Res, 14(1), 3–32. [https://doi.org/10.1080/10789669.2008.10390991.](https://doi.org/10.1080/10789669.2008.10390991)
- [67] Yokoyama R, Ito K. A revised decomposition method for MILP problems and its application to operational planning of thermal storage systems, J Energy Resour Technol 1996;118 (4):277–84. Retrieved from, [https://doi.org/10.1115/1.2793874.](https://doi.org/10.1115/1.2793874)
- [68] Henze GP, Biffar B, Kohn D, Becker MP. Optimal design and operation of a thermal storage system for a chilled water plant serving pharmaceutical buildings. Energ Buildings 2008;40 (6):1004–19. <https://doi.org/10.1016/j.enbuild.2007.08.006>.
- [69] Smith AD, Mago PJ, Fumo N. Benefits of thermal energy storage option combined with CHP system for different commercial building types. Sustain Energy Tech Assess 2013;1:3–12. <https://doi.org/10.1016/j.seta.2012.11.001>.
- [70] Li Y, Wang X, Li D, Ding Y. A trigeneration system based on compressed air and thermal energy storage. Appl Energy 2012;99:316–23. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.apenergy.2012.04.048) [apenergy.2012.04.048.](https://doi.org/10.1016/j.apenergy.2012.04.048)
- [71] International Energy Agency. (2009). Cogeneration and Distric Energy.
- [72] U.S. Department of Energy. (2016). U.S. DOE combined heat and power installation database. Retrieved May 12, 2017, from <https://doe.icfwebservices.com/chpdb/>.
- [73] U.S. Department of Energy. (n.d.). Combined Heat and Power. Retrieved December 5, 2017, from <https://energy.gov/eere/amo/combined-heat-and-power>.
- [74] U.S. Environmental Protection Agency. (n.d.). CHP Partner Case Studies. Retrieved December 5, 2017, from [https://www.epa.gov/chp/chp-partner-case-studies.](https://www.epa.gov/chp/chp-partner-case-studies)
- [75] Cogeneration Observatory and Dissemination Europe. (2011). Cogeneration Case Studies Handbook. Retrieved from [http://www.code-project.eu/wp-content/uploads/2011/04/](http://www.code-project.eu/wp-content/uploads/2011/04/CODE_CS_Handbook_Final.pdf) [CODE\\_CS\\_Handbook\\_Final.pdf.](http://www.code-project.eu/wp-content/uploads/2011/04/CODE_CS_Handbook_Final.pdf)

#### <span id="page-134-0"></span>Chapter 7.5

# Efficient Heating Fan Coil Unit in Buildings

Peike Li, Xiaoqiang Zhai and Ruzhu Wang

Shanghai Jiao Tong University, Shanghai, China

#### 1. INTRODUCTION

Energy consumption and huge emission of waste heat have already caused serious problems like global warming and hot island effect in cities. According to the statistics result, China's building energy consumption accounts for more than 30% of the total energy consumption of the entire society [\[1\]](#page-154-0). With the urbanization process in China, it can be foreseen that this percentage will continue increasing. According to the US energy information administration's international energy outlook [\[2\]](#page-154-0), China's residential sector will consume up to 20 quadrillion Btu energy in 2040, occupying 24% of the total world use. Ecological and energy efficient heating and cooling distribution in building receives more and more attention from academia and industrial.

In recent years, the residential heating for hot summer and cold winter regions has been paid more and more attention in China [\[3\].](#page-154-0) There are several promising solutions to solve this issue which are listed as follows. The first choice is central heating mode by steam or water. From an energy efficiency standpoint, considerable heat gets lost if only a single room in building needs heating which is the main drawback of the central heating comparing with distribution systems. Meanwhile, the initial investment for the pipeline network of the whole supply system is huge and the quantity emission of boilers is quite large. The second choice is the distributed solar water heating (SWH) system. SWH is the conversion of sunlight into heat for water heating using a solar thermal collector. SWHs are widely used for residential and for some industrial applications. The disadvantage of SWH system is that the sunshine time is not quite enough and stable in winter causing a relative poor economic efficiency and unstable heat comfort. Moreover, the SWH system is not capable of cooling needs. The third option is either distributed electric heating or gas heating directly, but both of them use primary energy which is not energy efficient. The last but the most promising choice is the distributed air source heat pump (ASHP) cooling and heating system due to its good adaptability and energy saving.

The ASHP system is the most widely used distribution energy system in China due to its flexibility and feasibility [\[4\]](#page-154-0). However, the existing products have several serious problems under heating conditions in winter during the marketization promotion practice. A visible issue is that the air distribution is irrational in heating condition because the air-conditioners in room are usually installed in the upper space in room making users feel uncomfortable [\[5\].](#page-154-0) The heat transfer temperature difference of the indoor terminal is relatively high causing a large exergy loss is another noteworthy issue [\[6\].](#page-154-0) In addition, from the operating conditions of the ASHP in three typical cites in hot summer and cold winter region listed in Table 1, we could see that the nominal condition of the ASHP system deviates from the actual environment conditions which leads to defrost frequently problem and thus influence the heating comfort of the indoor environment [\[7\].](#page-154-0)

To solve the problems above, a small temperature difference air-conditioning fan coil unit terminal was proposed. Combining with the ASHP system, this fan coil unit terminal can both satisfy the heating and cooling demand under a high energy efficient and heat comfort. In this chapter, the contributions are listed below: the concept of the small temperature fan coil unit was proposed. The basic

TABLE 1 ASHP Operating Conditions of Several Cities in Hot Summer and Cold Winter Region

|                                           | Shanghai |        | Nanjing |        | Wuhan  |        |
|-------------------------------------------|----------|--------|---------|--------|--------|--------|
| Parameters                                | Summer   | Winter | Summer  | Winter | Summer | Winter |
| Average<br>temperature<br>(°C)            | 30       | 1.5    | 28.1    | 0.1    | 28.9   | 0.7    |
| Nominal<br>outdoor<br>temperature<br>(°C) | 35       | 7      | 35      | 7      | 35     | 7      |
| Indoor design<br>temperature<br>(°C)      | 25       | 20     | 25      | 20     | 25     | 20     |
| Condensing<br>temperature<br>(°C)         | 5        | 8.5    | 5       | 10.1   | 5      | 9.3    |
| Evaporating<br>temperature<br>(°C)        | 40       | 53     | 38.1    | 53     | 38.9   | 53     |
| R410A unit<br>compression<br>ratio        | 2.59     | 5.08   | 2.47    | 5.33   | 2.52   | 5.15   |
|                                           |          |        |         |        |        |        |

<span id="page-136-0"></span>design calculation was done. The performance of the terminal was simulated by computational fluid dynamics (CFD) method. The simulation based upon selfestablished software as well as some commercial software was performed from the view of point of enhancement of heat transfer. Thus, an optimistic structure for small temperature difference terminals was formed. After calculating and simulating, a three-dimensional (3D) mechanical model was built based on the design structure and component selection. Based on the operation requirements for small temperature heat exchanging units, new concept of heat exchanging analysis and measures for heat transfer enhancement was introduced, in consideration of the special condition for heating and cooling. The performance of the terminal was tested for the purpose of comparing the heat transfer and comprehensive behavior. Besides, combined with the ASHP, performance of the system, including indoor thermal comfort, system energy consumption, and coefficient of performance (COP), was compared by field measurement to obtain an optimized system combination and operation strategy by a study case. The proposed design scheme obtained above was studied theoretically and experimentally in order to validate its feasibility.

#### 2. CONCEPT DEFINITIONS

The ASHPs are widely used in residential, commercial, and industrial areas. The terminals that transfer heat to or from the conditioned space are usually fan coil units whose basic elements are a finned tube coil, a filter, and a fan unit. Fig. 1 shows the typical structure of a fan coil unit terminal. The fan recirculates air from the space through the coil, containing hot or chilled water. The unit should be equipped with an insulated drain pan if it will be used under cooling condition.

![](_page_136_Picture_5.jpeg)

FIG. 1 Schematic diagram of traditional fan coil unit.

<span id="page-137-0"></span>When the heating and cooling media is supplied to a common finned tube coil, it is called a two-pipe system, which has one supply and one return pipeline, or a heating/cooling changeover system. And, it can only operate under heating or cooling condition, depending on the temperature of supply water. Besides, there is also a four-pipe distribution system in which contains dedicated supply and return piping for heating and cooling separately and generally has a better system performance. It can provide all-season availability of heating and cooling at each unit. However, the four-pipe system has a relative higher initial cost and a more complex structure. When a fan coil system is applied to residential buildings and commercial buildings such as small offices, a two-pipe system is more popular due to its easier installation, more compact structure, and lower initial cost. Moreover, the residential and light commercial buildings often have a stable heating or cooling load which has consistency between different zones. That is to say, there is no need for simultaneous heating and cooling. Therefore, the two-pipe fan coil system is our main focus. Although two-pipe system has above-mentioned advantages, it has to be designed carefully when it is used for both heating and cooling in the whole year to achieve a high comprehensive performance.

For cooling mode, the normal fan coil unit is designed under the condition of 7°C supply water temperature, according to the Chinese national standards [\[8\].](#page-154-0) There are several reasons to choose this supply water temperature. First, the fan coil unit not only needs to undertake the task of cooling as well as dehumidifying. The method of dehumidification is condensation which means the supply water temperature has to be low enough to ensure the moisture water vapor in air can be removed. For heating mode in winter, fan coil unit only need to deal with the sensible heat to warm the air and there is nothing regarded with the dehumidification process. Therefore, the fan coil unit can be designed under a better condition without the limit of dehumidification. The ASHP system will benefit a lot if the supply water temperature can be lower in winter, which will be explained in detail below. These units designed under non-normal conditions are called small temperature difference fan coil units (STDFCUs).

The finned tube heat exchanger is the most important component in a fan coil unit. The heat transfer process of the finned tube heat exchanger could be taken as a counter flow problem. The heat transfer process is quantified in the following equation:

$$Q = KF\Delta T \tag{1}$$

where Q is the amount of the heat transferred. K is the heat transfer coefficient. F is the effective surface area of heat transfer. ΔT is the logarithm temperature difference across the coil surface. Increasing any one of these variables (heat transfer coefficient, surface area, or log-mean temperature difference) leads to more heat transfer amount. However, there are some differences among these three parameters. The surface area is completely a structural parameter, which is decided immediately when the terminal is designed. Heat transfer coefficient is influenced by different factors, some of the parameters are structural ones such as fin type and tube type, while the others are operation conditions such as the velocity of air and water. The logarithm mean temperature difference (LMTD) is totally controlled by the operation condition, supply water temperature, return water temperature, inlet air temperature, and outlet air temperature. The LMTD describes the differences between the temperatures of the air passing across the coil fins and the water flowing through the coil tubes

$$\Delta T_m = \frac{(T_{db1} - T_{w2}) - (T_{db2} - T_{w1})}{\ln \frac{T_{db1} - T_{w2}}{T_{db2} - T_{w1}}}$$
(2)

where  $T_{db1}$  and  $T_{db2}$  are the inlet and outlet air temperature, respectively and  $T_{w1}$  and  $T_{w2}$  are the inlet and outlet water temperature, respectively.

Considering the heating condition, we take the heating load needed as a constant, if the heat transfer performance or the total heat transfer area increases, according to Eq. (1), the supply water temperature can be lower which means the energy efficient of the ASHP unit will improve and thus bring lots of benefits. Based on these insights, we proposed the small temperature fan coil terminals, which means that the temperature difference (i.e., LMTD) between air and water is relatively lower than the conventional fan coil unit. The heat transfer characteristics of conventional fan coil unit (NFCU) and STDFCU are shown in Fig. 2. Here, the heat transfer process is simplified and therefore only the finned tube heat exchanger is shown. The inlet water temperature can be lower when the environmental temperatures are the same because the STDFCU has a higher heat transfer coefficient and a larger heat transfer area.

Temperature difference in heating mode between water and air is shown in Fig. 3. It can be seen that the inlet water temperature of NFCU is 45°C, while the inlet air temperature is 21°C (equal to the room air temperature). As a result, the outlet water temperature is 40°C, while the outlet air temperature is 38°C. The logarithm temperature difference across the heat exchanger surface can be calculated according to Eq. (2). The LMTD is 12°C. As for the STDFCU, the inlet water temperature can be lower, and we set it as 35°C in this case. The outlet air temperature is 32°C. In the same way, the outlet water temperature of the STDFCU is 30°C. At last, the LMTD can be calculated. The LMTD is 6.2°C which is only half of the conventional one indicating that the product of heat transfer coefficient and total area of the STDFCU is twice over NFCU. Thus,

![](_page_138_Picture_7.jpeg)

**FIG. 2** Schematic diagram of NFCU and STDFCU.

<span id="page-139-0"></span>![](_page_139_Figure_2.jpeg)

FIG. 3 Comparison of NFCU and STDFCU.

we need to apply heat enhancement method to increase the heat transfer coefficient and increase the total heat transfer area. In the end, one thing needs to be explained, the air flow rate of the STDFCU should be higher which will increase the power consumption of fan in principle. However, a cross-flow fan and DCdriven brushless motor system is adopted in the STDFCU as a compensation that will be introduced later. In the above comparison between the STDFCU and NFCU, we only discuss about the heat transfer process in heating mode. Similarly, the inlet water temperature can be higher in cooling mode.

After declaring the definition of the STDFCU, it is significant to show the reason why this concept is promising and beneficial over the conventional fan coil unit. In general, it is necessary and important to decrease the water temperature demand of fan coil units as low as possible in an ASHP system. Taking heating mode, for example, a lower water temperature can lead to a lower condensing temperature and a higher system COP. The heat pump cycle is illustrated in Fig. 4. The system with normal fan coil units operates through the cycle 1-2-3-4-5-1, while the system with the STDFCUs operates through the cycle 1-2'-3'-4'-5'-1. According to the heat pump cycle, the system COP can be calculated by the heating coefficient,

$$\varepsilon_c' = \frac{\overline{T}_c}{\overline{T}_c - \overline{T}_e} \tag{3}$$

For the system with NFCUs,

$$\varepsilon_c' = \frac{\overline{T}_{2-3-4}}{\overline{T}_{2-3-4} - \overline{T}_{1-5}} \tag{4}$$

For the system with the STDFCUs,

$$\varepsilon_c' = \frac{\overline{T}_{2'-3'-4'}}{\overline{T}_{2'-3'-4'} - \overline{T}_{1-5'}} \tag{5}$$

<span id="page-140-0"></span>![](_page_140_Figure_2.jpeg)

FIG. 4 Thermodynamic cycle of AHSP.

The average temperature from state 2 to 4 is higher than that from 20 to 40 . The average temperature from state 1 to 5 equals to that from 1 to 50 . According to Eqs. [\(4\) and \(5\),](#page-139-0) the heating coefficient of system with the STDFCU is higher than that with normal fan coil units which means that the STDFCUs can help to reduce system energy consumption under the same heating load.

The temperature of inlet water influences the theoretical COP of the ASHP system. For example, the COP is calculated at the outdoor temperature of 7°C. The evaporating and condensing temperatures are determined through empirical method [\[8\].](#page-154-0) If the water temperature is 60°C, the system COP is only about 1.6. However, if the water temperature decreases to 35°C, the system COP will increase to nearly 4, whichis a visual progress and can save much energy.Moreover, the lower demand of water temperature also alleviates the defrosting problem in winter.

To sum up, the concept of STDFCU compromises between initial cost and operation cost. With the development of the ASHP system, it becomes significant that the ASHP could be used both for heating in winter and cooling in summer. It is of great significant to consider the performance of the system both in summer and winter. The implementation of small temperature difference fan coil implies that more heat transfer enhancement technologies should apply to the indoor terminal and more heat transfer areas should be adopted. In other word, a more energy efficient terminal combined with the ASHP system will become a trend across the world.

# 3. DESIGN METHODOLOGIES

In the previous section, some basic concepts about the STDFCU are introduced. While, in this section, a mathematical design model of STDFCU is established. CFD simulation work is given. It is meaningful to study the heat and mass transfer by use of the computational fluid dynamics simulation technique. CFD simulation technique can provide the flexibility to construct the computational models that are easily adapted to wide variety of physical conditions without constructing a large-scale prototype or expensive test bench. Therefore, CFD can provide an effective platform where various design options can be tested and an optimal design can be determined at a relatively low cost. Using the design model, all the parameters needed to draw the 3D mechanical model and further manufacture the STDFCU are specified.

Finned tube heat exchanger is usually the most common type and the main part in a fan coil unit. Finned tube type heat exchangers have many applications in the field of thermal engineering, especially widely used in fan coil unit. All the geometry parameters of a finned tube heat exchanger are calculated as follows.

The unit surface area outside tube is

$$a_f = 2\left(s_1 s_2 - \frac{\pi}{4} d_3^2\right) \frac{1000}{s_f} \tag{6}$$

The unit surface area inside the tube is

$$a_b = \pi d_3 \left( s_f - \delta_f \right) \frac{1000}{s_f} \tag{7}$$

where  $s_1$  and  $s_2$  are the horizontal distance and vertical distance of the tube. And  $s_f$  means the fin spacing and  $\delta_f$  is the fin thickness.

The fin effectiveness is defined as

$$m = \sqrt{\frac{2K_a}{\lambda_{cp}\delta_f}}$$

$$\eta_f = \frac{thmh'}{mh'}$$

$$h' = \frac{d_0}{2}(\rho' - 1)(1 + 0.35 \ln \rho')$$

$$\rho' = 1.27 \frac{B}{d_0} \sqrt{\frac{A}{B}} - 0.3$$
(8)

where m is the fin parameter and h' is the conversion height.

The air side heat transfer coefficient is related with the tube arrangement of the heat exchanger (in-line pitching or staggered arrangement), fin type (flat fin, wavy fin, or slotted fin). In order to calculate the heat transfer coefficient, there exists some empirical correlation equations of air heat transfer coefficient with different fin types and different structures. In most cases, the waterside heat transfer coefficient is much larger than the air side one. Experiments [9] indicate that 20% error of the waterside heat transfer coefficient will lead to only 2% error of the total heat transfer coefficient. However, 20% error of the air side heat transfer coefficient will cause more than 15% error of the total error. It is of great importance to choose the proper air side heat transfer coefficient correlation equations in order to obtain an accurate result in the design model. The air side heat transfer coefficient can be calculated by the Nusselt number below.

$$Nu = \frac{K_a d_3}{\lambda_a} \tag{9}$$

where the Nusselt number of different fin type is listed in Table 2 [10].

The air side pressure drop is another one of the most important parameters in fan selection. In order to choose the fan type properly, it is important to have an accurate result. When the air flow passes through the heat exchanger, the pressure drop can be calculated as.

$$\Delta p_a = 9.81 A (L/d_{eq}) (\rho V_{\text{max}})^{1.7}$$
 (10)

where A is the surface roughness of the fin. Usually, A = 0.0113 for rough fin surface and A = 0.007 for smooth fin surface.

For the waterside heat transfer coefficient, the classical Dittus-Boelter formula is chosen [11].

$$Nu = 0.023Re^{0.8} Pr^n (11)$$

where for the cooling condition n=0.3 and n=0.4 for heating condition.

The unit water pressure drop could be calculated as

$$\Delta p_w = 0.0240965 w^{1.49849} / d_i \tag{12}$$

| <b>TABLE 2</b> Air Side Heat Transfer Heat Coefficient Equations |                                                                                                                |  |  |
|------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|--|--|
| Fin Type                                                         | Correlation Equation                                                                                           |  |  |
| Flat fin                                                         | $Nu_a = 0.982 Re_{air}^{0.424} \left(\frac{s_f}{d_3}\right)^{-0.0887} \left(\frac{Ns_2}{d_3}\right)^{-0.1590}$ |  |  |
| Slotted fin                                                      | $Nu_a = 0.772 Re_{air}^{0.477} \left(\frac{s_f}{d_3}\right)^{-0.3630} \left(\frac{Ns_2}{d_3}\right)^{-0.2170}$ |  |  |
| Triangular wavy fin                                              | $Nu_a = 0.687 Re_{air}^{0.518} \left(\frac{s_f}{d_3}\right)^{-0.0935} \left(\frac{Ns_2}{d_3}\right)^{-0.1990}$ |  |  |
| Sinusoidal wavy fin                                              | $Nu_a = 0.274Re_{air}^{0.556} \left(\frac{s_f}{d_3}\right)^{-0.2020} \left(\frac{Ns_2}{d_3}\right)^{-0.0372}$  |  |  |
| Note: N is the number of tube rows and d3 is the tube diameter.  |                                                                                                                |  |  |

The comprehensive heat transfer coefficient is

$$\frac{1}{K_s} = \frac{1}{\alpha_w} \frac{A_0}{A_i} + R_{wf} + \frac{\delta A_0}{\lambda A_l} + r_b + \frac{1}{\alpha_a} + R_m \tag{13}$$

where

$$\alpha_a = \alpha_d \left( 1 - \frac{A_f}{A_0} (1 - \eta_s) \right) \tag{14}$$

 $\eta_s$  is the fin effectiveness and  $R_m$  is the fouling resistance.

In above design calculation, the main parameter, that is, the heat transfer coefficient is calculated by empirical correlation equation. But for most cases, especially for some self-designed fin type, this equation does not always apply well. We introduce CFD simulation methods to pre-calculate the heat and mass transfer behavior before manufacturing the prototype in a more accurate way.

In engineering applications, the flow resistance increases at the same time when the convection heat transfer enhances. In order to consider the heat transfer and the flow resistance characteristics synthetically, here takes three types of the new pattern fin shown in Fig. 5 as an example to compare their heat transfer comprehensive performance.

In this computational fluid dynamics problem, both the heat conduction in the aluminum itself and the convection from the fin to the surrounding air are considered. The material of the tube is assumed to be aluminum. The physical properties of aluminum are taken as constant, while the air properties are taken as a function of temperature. The conservation equations of mass, momentum is solved using the finite volume method. There are several turbulence models available in the code. The turbulence flow was calculated by the SIMPLE method, and a second-order upwind differential scheme was applied for the approximation of the convective terms. A standard k-epsilon model was used to predict turbulent flow in the header.

All the relative parameters are given for evaluating the performance of the finned tube heat exchanger as follows. The Reynolds number and Nusselt number are given as

$$Re = \frac{\rho D_e u_{\text{max}}}{\mu} \tag{15}$$

$$Nu = \frac{hD_e}{\lambda} \tag{16}$$

where  $D_e$  is the characteristic diameter.

The performance of the heat exchanger is strongly dependent upon the heat transfer in terms of Colburn factor j and Fanning friction factor f which are given as follows:

$$f = \frac{2\Delta PD_e}{\rho u_{\text{max}}^2 L} \tag{17}$$

<span id="page-144-0"></span>![](_page_144_Picture_2.jpeg)

FIG. 5 Geometry model of three different types of fin (plate fins, louver fins, and slotted fins).

$$j = St \cdot Pr^{2/3} = \frac{Nu}{Re \cdot Pr} \cdot Pr^{2/3} = \frac{Nu}{Re \cdot Pr^{1/3}}$$
 (18)

The aim of heat transfer enhancement is not only to intense its heat transfer performance, but also to keep the resistance increasing relatively slow and to achieve a better overall performance. Using  $j/f^{1/3}$  as a comprehensive

![](_page_145_Figure_2.jpeg)

FIG. 6 The relation of comprehensive performance evaluation with respect to air velocity.

performance evaluation indicator is to measure whether the heat transfer increases more than the flow resistance under the equivalent pump power.

The simulation results are shown in Fig. 6.

In Fig. 6, it can be seen that the heat transfer capacity of the louver fins and the slotted fins is better than that of the flat fin under the same pump power condition. We finally choose the louver fins as the main heat exchanger which will be introduced later in the following section. By using CFD method, the heat exchanger coefficient can be calculated more accurate and then improve the design model by several iterations process.

After completing all the required design calculation, for the prototype, according to the heat transfer theory <sup>Q</sup>¼KFΔT, with the purpose of achieving a good heat transfer performance, there are basically two ways include increasing the heat transfer area or increasing the heat transfer coefficient. In the design process, we have to consider the total size of the whole product which means it is only possible to increase the heat transfer area to a limited extent, so the enhancement of heat transfer is the primary task. In order to enhance the heat transfer of the exchanger, the effect of several parameters including the spacing of fins, the fin thickness, and tube diameters should be taken into consideration.

In [Fig. 7](#page-146-0), the newly designed heat exchanger is made of super-fast conducting copper and aluminum. The arrangement of the exchanger with up to 16 copper tubes and the optimized corrugated shape of the aluminum fins ensures a good performance of the heat transfer from the water to the air.

<span id="page-146-0"></span>![](_page_146_Picture_2.jpeg)

FIG. 7 The 3D model of the heat exchanger unit.

Usually, the speed control of motors within a fan coil unit is effectively used to control the heating and cooling output. Some manufacturers accomplish speed control by adjusting the taps on an alternating current (AC) transformer supplying the power to the fan motor. This would require adjustment at the commissioning stage of the building construction process. Other manufacturers provide permanent split capacitor (PSC) motors with speed taps in the windings, set to the desired speed levels for the fan coil unit design. A simple speed selector switch (off-high-medium-low) is provided for the local room occupant to control the fan speed. Typically, this speed selector switch is integrated with the room thermostat, and is set manually or is controlled automatically by the digital thermostat. But the noise and energy consumption are not very satisfying. To improve these disadvantages, a brushless DC motor is a better option. The reason why we chose a brushless DC motor is, despite its apparent relative complexity, the energy efficiency level compared with an AC motor is improved. Moreover, in areas of the world where there are legally enforceable energy efficiency requirements for Fan Coils (such as the United Kingdom), DC fan coil units are rapidly becoming the only choice. This design of cross-flow fan unit is shown mainly consists of a cross-flow fan, a brushless DC motor, a flow deflector, etc. The cross-flow fan in [Fig. 8](#page-147-0) used to induce the air into the fan coil unit.

When the STDFCU is in cooling condition, depending upon the selected chilled water temperatures and the relative humidity of the space, it is likely that the cooling coil will dehumidify the air. As a byproduct of this process, it will produce condensate water which needs to be drained. The fan coil unit will contain a condensate plate with drain connection for this purpose [\(Fig. 9\)](#page-147-0). And the edge surface of the plate is specially design to be oblique to guide the air flow as a deflector.

<span id="page-147-0"></span>![](_page_147_Picture_2.jpeg)

FIG. 8 The 3D model of cross-flow fan unit.

![](_page_147_Picture_4.jpeg)

FIG. 9 The 3D model of the condensate plate.

Each single part and subassemblies in traditional assembly hierarchy model are united together to form the whole product assembly model. The main core of the STDFCU is shown in [Fig. 10](#page-148-0).

The new design of the STDFCU mainly contains a heat exchanger unit, an air supply unit which has one cross-flow fan, a condensation plate, the housing shell and the controller, etc. The heat transfer performance was specially optimized by the heat enhancement method optimization of the fin-tube heat exchanger. The aerodynamic optimization design technology based on CFD method was conducted. Due to the above principles, the air pressure drop and vibrating noise can be eliminated or decreased greatly, and the volume can be reduced. Meanwhile, we have also refined the exterior design to separate the STDFCU [\(Fig. 11\)](#page-148-0) from the conventional one.

#### 4. EXPERIMENT RESULTS

After manufacturing the prototype, the performance of the STDFCU has been tested based on Chinese national standard [\[8\].](#page-154-0) In the enthalpy testing lab shown

<span id="page-148-0"></span>![](_page_148_Picture_2.jpeg)

FIG. 10 The 3D model of the main core part of the STDFCU.

![](_page_148_Picture_4.jpeg)

FIG. 11 Photo of the STDFCU prototype.

in [Fig. 12,](#page-149-0) the rated cooling and heating capacity have been tested. Besides, the air and water flow rate under different conditions and the heating capacity under low-temperature heating conditions have also been tested.

Although the prototype is designed under low-temperature heating conditions, its rated heating and cooling capacity need to be tested under the standard condition and hence to make a comparison with the normal fan coil unit. The parameters of rated condition are shown in [Table 3.](#page-149-0)

Heat and mass transfer performance of the prototype are tested using the methods described above. For the rated cooling and heating capacity experiment, the results are shown in [Table 4.](#page-150-0)

According to the statistics, the STDFCU prototype has a cooling capacity of 1950W, a heating capacity of 3070W and an input power of 18.73W under the rated conditions. And, one phenomenon needs to be noticed is that the air flow rate under cooling condition is lower than what it is under heating condition. It's because that the cooling condition is a wet condition. Therefore, condensate water from air adheres to the surface of fins, which increases the air side resistance.

<span id="page-149-0"></span>![](_page_149_Picture_2.jpeg)

FIG. 12 Experiment environment of enthalpy lab.

| TABLE 3<br>Test Condition Parameters of Rated Condition |                                          |                              |  |
|---------------------------------------------------------|------------------------------------------|------------------------------|--|
| Items                                                   | Cooling                                  | Heating                      |  |
| Inlet air dry-bulb temperature (°C)                     | 27                                       | 21                           |  |
| Inlet air wet-bulb temperature (°C)                     | 19.5                                     | –                            |  |
| Supply water temperature (°C)                           | 7                                        | 60                           |  |
| Supply and return water<br>temperature difference (°C)  | 5                                        | –                            |  |
| Water flow rate (kg/h)                                  | Based on water<br>temperature difference | Same as cooling<br>condition |  |
| Fan speed                                               | High                                     |                              |  |
| Outlet static pressure (Pa)                             | 0                                        | 0                            |  |
|                                                         |                                          |                              |  |

The STDFCU is designed to combine with the ASHP in winter. Therefore, the temperature of supply water should be lower and hence to assure that the system will operate well and the energy consumption will be decreased. [Table 5](#page-150-0) shows the heating capacity tested when the design supply water is 45°C. Results show that the heating capacity satisfy the designing and requesting demand.

#### 5. CASE STUDIES

In order to figure out the demands of adopting the STDFCU with the ASHP system, the terminals manufactured above are tested for residence heating in

<span id="page-150-0"></span>TABLE 4 Results of Rated Cooling and Heating Capacity Experiment (Second-Generation)

| Items                                | Cooling | Heating |
|--------------------------------------|---------|---------|
| Inlet air dry-bulb temperature (°C)  | 26.97   | 20.97   |
| Inlet air wet-bulb temperature (°C)  | 20.01   | –       |
| Outlet air dry-bulb temperature (°C) | 17.54   | 42.01   |
| Outlet air wet-bulb temperature (°C) | 15.52   | –       |
| Inlet water temperature (°C)         | 7.19    | 60.04   |
| Outlet water temperature (°C)        | 12.69   | 51.11   |
| Water-side pressure loss (kPa)       | 35.96   | 35.96   |
| Water flow rate (m3<br>/h)           | 0.312   | 0.312   |
| Air flow rate (m3<br>/h)             | 415.6   | 440     |
| Input power (W)                      | 18.73   | 18.73   |
| Cooling/heating capacity (kW)        | 1.95    | 3.07    |
|                                      |         |         |

| TABLE 5<br>Results of Low-Temperature Heating Experiment |         |  |  |
|----------------------------------------------------------|---------|--|--|
| Items                                                    | Heating |  |  |
| Inlet air dry-bulb temperature (°C)                      | 17.99   |  |  |
| Outlet air dry-bulb temperature<br>(°C)                  | 32.84   |  |  |
| Inlet water temperature (°C)                             | 44.89   |  |  |
| Outlet water temperature (°C)                            | 38.81   |  |  |
| Water-side pressure loss (kPa)                           | 29.227  |  |  |
| Water flow rate (m3<br>/h)                               | 0.306   |  |  |
| Air flow rate (m3<br>/h)                                 | 440     |  |  |
| Heating capacity (kW)                                    | 2.09    |  |  |
|                                                          |         |  |  |

this part. The system performances under different conditions were studied. Besides, this research also studied the influence of water temperature on system energy consumption.

An ASHP system is installed in a 100m2 apartment in Shanghai Jiao Tong University combined with STDFCU developed above. According to the tested heating rate above, the four STDFCUs have been adopted in the system to satisfy the heating and cooling demands of the whole apartment. This apartment includes two bedrooms, a living room, a dining room, and a kitchen. The indoor temperatures are controlled by indoor temperature controllers. Moreover, five temperature and humidity loggers are allocated in different places of the apartment to collect data.

The ASHP system includes three major parts, including an ASHP unit with a rated heating capacity of 9.5 kW, a 200L water tank, and four STDFCUs. The water tank plays a critical role in the ASHP system. On one hand, it serves as a heat exchanger to combine the heat pump unit and the indoor terminals. On the other hand, it works as a buffer to stabilize the water temperature when the outdoor unit is in a floating state.

To study the effect of water temperature on the energy consumption of the ASHP system, a three-day experiment has been conducted under three different conditions. The outdoor air temperature during experiment is shown in Fig. 13. The average outdoor temperatures are 8.8°C, 7.3°C, and 6.4°C, respectively.

The return water temperatures are set to 30°C, 35°C, and 40°C, respectively. The air temperatures of different rooms are all set to 22°C. Temperatures of supply and return water during the test are shown in [Fig. 14.](#page-152-0)

Meanwhile, the system power consumptions under different conditions have been tested, including heat pump compressor, water pump, and terminals. The system heating capacity has also been calculated by testing the inlet and outlet water temperature of the ASHP and water mass flow rate. The energy consumptions and COP of the ASHP and the whole system under different conditions have been obtained in 24 h. The results are shown in [Fig. 15.](#page-152-0)

![](_page_151_Figure_7.jpeg)

FIG. 13 Outdoor temperature in three typical test days.

<span id="page-152-0"></span>![](_page_152_Figure_2.jpeg)

FIG. 14 Indoor temperature of different return water temperature.

![](_page_152_Figure_4.jpeg)

FIG. 15 The energy consumptions and COP of the ASHP under different conditions.

It can be seen that the energy consumption of heat pump is only 17 kWh when the return water is at the temperature of 30°C. This is less than half of the energy consumption when the temperature of the return water is 40°C. It indicates that the return water temperature has a great influence on the energy consumption of the ASHP. In addition, the air temperature of the room affects the building load a lot and thus influences the energy consumption indirectly. It can be concluded that a lower water temperature and room air temperature can lead to a great energy saving in practice.

#### <span id="page-153-0"></span>6. CONCLUSIONS

In this chapter, weintroduced and thoroughly studied an efficient heating and cooling fan terminal unit called the small temperature difference terminals. The STDFCUs mainly focus onthe problem of efficient and economical winter heating in South Chinameanwhile havethe ability of summer cooling. Combining withthe ASHP system, small temperature fan coil unit terminal can both satisfy the heating and cooling demand under a high energy efficient and heat comfort.

In the beginning, the concepts of STDFCUs were introduced. The concept of STDFCU makes a compromise between initial cost and operation cost. With the development of the ASHP system, it becomes normal that the ASHP is used for both heating and cooling in the whole year in hot summer and cold winter climate regions. The proposal of STDFCU means that more heat transfer enhancement technologies are applied to the terminal and more heat transfer areas are adopted. That is to say, the initial cost needs to be increased to make the terminal and the ASHP system more energy efficient, which is a trend across the world.

Then, the STDFCUs, which are composed of fin-tube heat exchanger, crossflow fan, brushless DC motor, and a condensate plate, were designed. A mathematical model to design the STDFCU was calculated. The influence of different structures and different working conditions in small temperature fan coil unit was investigated, respectively. The simulation model can be applied to different situations according to their characteristics and is useful in the designing process. After that, the CFD simulation work was done. CFD simulation provides an effective platform where various design options of the STDFCU can be tested and an optimal design can be determined at a relatively low cost. The comprehensive indicator j/f1/3 was used for evaluating the heat transfer enhancement effect under equivalent pump power constraint. In the engineering practice, two special types of fins, louvered fins and slotted fins were compared with the flat fins. The comprehensive performance of these three types of fins was analyzed and studied using CFD simulation.

After designing and simulating iteration, the prototype of STDFCUs was manufactured. The heat transfer performance is tested under rated condition and smalltemperature conditions. The results showthattheterminal has a heating capacity of 2090W under the condition of 45°C water, which can satisfy the design goal. Moreover, the designed prototype is improved in its appearance to be a real product and applied to a 100m2 apartment with an ASHP system as a study case. The system performance was tested under different conditions of different return water temperature. According to the result, it shows that the STDFCU can decrease its demand water temperature due to its better heat transfer performance. The system energy consumption can be reduced a half if return watertemperatureis decreased from 40°Cto 30°C whilethe room airtemperature is still in a comfort level and the air distribution in the room is more uniform in winter. In a word, the STDFCU is one of the most suitable and promising terminal in those climate regions that have demands of both heating and cooling.

#### <span id="page-154-0"></span>REFERENCES

- [1] [Ma L, Allwood JM, Cullen JM, Li Z. The use of energy in China: Tracing the flow of energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1040) [from primary source to demand drivers. Energy 2012;40\(1\):174](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1040)–88. Outlook A E. US Energy [Information Administration: Washington\[J\]. 2013.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1040)
- [2] Outlook, A. E (2013). US Energy Information Administration: Washington.
- [3] [Wang RZ, Yu X, Ge TS, Li TX. The present and future of residential refrigeration, power gen](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1045)[eration and energy storage. Appl Therm Eng 2013;53\(2\):256](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1045)–70.
- [4] [Zhang J, Wang RZ, Wu JY. System optimization and experimental research on air source heat](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1050) [pump water heater. Appl Therm Eng 2007;27\(5\):1029](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1050)–35.
- [5] [Melikov AK, Cermak R, Majer M. Personalized ventilation: Evaluation of different air termi](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1055)[nal devices. Energy Build 2002;34\(8\):829](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1055)–36.
- [6] [Byrne P, Miriel J, Lenat Y. Experimental study of an air-source heat pump for simultaneous](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1060) heating and cooling–[part 1: Basic concepts and performance verification. Appl Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1060) [2011;88\(5\):1841](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1060)–7.
- [7] [Hepbasli A, Kalinci Y. A review of heat pump water heating systems. Renew Sustain Energy](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1065) [Rev 2009;13\(6\):1211](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1065)–29.
- [8] General Administration of Quality Supervision, Inspection and Quarantine of the People's Republic of China (2004) Fan-coil unit: GB/T 19232–2003. Standard, Standards Press of China, Beijing. [In Chinese].
- [9] [Pei QQ, Zhou Z, Chen Y, et al. Experimental study on a fan-coil unit running in dry conditions.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1070) [Heating Ventilating & Air Conditioning 2009;39\(7\):1](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1070)–4[In Chinese].
- [10] [Lee H, Hwang Y, Radermacher R, et al. Experimental investigation of novel heat exchanger](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1075) [for low temperature lift heat pump. Energy 2013;51:468](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1075)–74.
- [11] [Bejan A, Kraus AD. Heat transfer handbook. 1. John Wiley & Sons; 2003.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1080)

#### FURTHER READING

- [12] [Ruzhu WJJMW, Peng XYS. Seasonal energy efficiency assessment of air source heat pump](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1085) [water heaters \[J\]. J Refrig 2009;5:005.](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1085)
- [13] [Pan CS, Chiang HC, Yen MC, Wang CC. Thermal comfort and energy saving of a personalized](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1090) [PFCU air-conditioning system. Energ Build 2005;37\(5\):443](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1090)–9.
- [14] [Lohani SP, Schmidt D. Comparison of energy and exergy analysis of fossil plant, ground and](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1095) [air source heat pump building heating system. Renew Energy 2010;35\(6\):1275](http://refhub.elsevier.com/B978-0-12-812817-6.00040-1/rf1095)–82.