#### Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/0038092X)

## Solar Energy

journal homepage: [www.elsevier.com/locate/solener](https://www.elsevier.com/locate/solener)

![](_page_0_Picture_5.jpeg)

# Comparison of absorption refrigeration cycles for efficient air-cooled solar cooling

![](_page_0_Picture_7.jpeg)

Z.Y. Xu[⁎](#page-0-0) , R.Z. Wang

Institute of Refrigeration and Cryogenics, Shanghai Jiao Tong University, Shanghai 200240, China

#### ARTICLE INFO

Keywords: Solar cooling Air cooled Absorption chiller Steady-state simulation

#### ABSTRACT

Absorption chiller is a widely used technology owing to its capability to utilize low grade thermal energy including solar thermal energy and waste heat. Yet, most solar absorption cooling systems need cooling tower to dissipate heat rejection into ambient. The use of cooling tower increases both the initial investment and water consumption, which can be improved by air-cooled solar absorption cooling system. In this paper, to give the best absorption cycle options under different conditions, five absorption refrigeration cycles suitable for aircooled solar cooling including three double lift absorption cycles and two semi-GAX (Generator-Absorber heat eXchange) absorption cycles were compared. Steady-state simulation is carried out. Efficiencies of these cycles were calculated with LiBr-water and water-ammonia working pairs in the scenario of air-cooled solar cooling. Heat source temperatures of 75–100 °C from non-concentrating solar collector and air temperatures of 20–40 °C were considered. Both air-conditioning condition with evaporation temperature of 5 °C and sub-zero condition with −10 °C were discussed. It is found that mass-coupled semi-GAX absorption cycle with ammonia-water is suitable for air-conditioning with higher heat source temperatures, mass-coupled double lift absorption cycle with water-LiBr is suitable for air-conditioning with lower heat source temperature and mass-coupled double lift absorption cycle with ammonia-water is suitable for sub-zero conditions.

## 1. Introduction

Utilization of low grade thermal energy including solar thermal power and waste heat is both environment benign and energy saving. The thermally driven absorption cycle is among the most popular choices for low grade thermal energy utilization. It can be applied to solar cooling [\(Kim and Ferreira, 2008; Wang et al., 2009](#page-9-0)), waste heat recovery [\(Ma et al., 2003; Popli et al., 2013; Sun et al., 2012](#page-9-1)) and CCHP ([Li and Hu, 2016; Zhao et al., 2015\)](#page-9-2) for either refrigeration or heat pumping. In typical solar absorption cooling systems, cooling towers are used to dissipate heat rejection to the ambient. The use of cooling tower will increase the initial investment and maintenance cost of solar absorption cooling system [\(Al-Alili et al., 2012\)](#page-9-3), especially for the small scale applications. In order to reduce the initial cost and avoid the water consumption, air-cooled solar absorption cooling system could be used. However, the use of air-cooled system rises two issues.

The first issue is about the absorption cycle. In typical solar absorption cooling, non-concentrating solar collectors and single effect water-LiBr absorption chillers are popular choices for the low initial investment and easy operation ([Assilzadeh et al., 2005; Lizarte et al.,](#page-9-4) [2012; Syed et al., 2005\)](#page-9-4). In the case of air-cooled solar absorption cooling system, non-concentrating solar collectors are not always enough to drive the single effect absorption cycle considering the high cooling temperature, which causes performance degradation or even shutdown of the absorption cooling system. Absorption refrigeration cycles with lower driving temperature should be considered. In the last two decades, various absorption cycles were developed for different driving temperatures, output temperatures, working pairs and efficiencies [\(Xu and Wang, 2016\)](#page-9-5). In general, there are two pursuits for the cycle improvement, i.e. larger temperature lift or higher efficiency ([Kang et al., 2000](#page-9-6)), and absorption cycles with larger temperature lift are proper for the air-cooled solar absorption cooling. [Ziegler and](#page-9-7) [Alefeld \(1987\)](#page-9-7) presented three configurations of double-lift cycles including mass-coupled cycle, heat-coupled cycle and resorption cycle. Superposition method was used for COP estimation. The heat pump efficiencies of 1.28, 1.20 and 1.23 were obtained with water-ammonia solution for the three configurations respectively. Kim and Ferreira ([Kim and Ferreira, 2009\)](#page-9-8) studied the air-cooled heat-coupled double lift absorption cycle with LiBr-water solution. COP of 0.37 was obtained with 90 °C hot water and 35 °C ambient condition. [Lin et al. \(2011\)](#page-9-9) and [Du et al. \(2012\)](#page-9-10) studied the air-cooled mass-coupled double lift absorption chiller with water-ammonia both theoretically and

<span id="page-0-0"></span><sup>⁎</sup> Corresponding author at: 800 Dongchuan Road, Shanghai, China. E-mail address: [xuzhy@sjtu.edu.cn](mailto:xuzhy@sjtu.edu.cn) (Z.Y. Xu).

| Nomenclature |                                  | h<br>m | enthalpy (kJ/kg)<br>mass flow rate (kg/s) |  |  |
|--------------|----------------------------------|--------|-------------------------------------------|--|--|
| GAX          | generator absorber heat exchange | Q      | heat exchange amount (kW)                 |  |  |
| DL           | double lift absorption cycle     | COP    | coefficient of performance (–)            |  |  |
| SGAX         | semi-GAX absorption cycle        | α      | workable range ratio (–)                  |  |  |
| A            | absorption                       |        |                                           |  |  |
| G            | generation                       |        | Subscripts and superscripts               |  |  |
| C            | condensation                     |        |                                           |  |  |
| E            | evaporation                      | G      | generation                                |  |  |
| R            | resorption                       | A      | ambient                                   |  |  |
| RE           | rectification                    | E      | evaporation                               |  |  |
| T            | temperature (°C)                 | i      | different streams                         |  |  |
| P            | pressure (kPa)                   | p      | solution pump                             |  |  |
| X            | concentration (g/g)              |        |                                           |  |  |

experimentally. Theoretical COP of 0.34 and experimental COP of 0.21 were obtained with 85 °C hot water for air-conditioning. Through heatcoupled configuration, [Aprile et al. \(2015\)](#page-9-11) improved the experimental COP of double lift absorption chiller with water-ammonia up to ∼0.3 for air-conditioning. They later extended the heat-coupled double lift absorption cycle with water-ammonia for sub-zero condition, and obtained experimental COP about 0.25 under brine outlet temperature of −5 °C ([Toppi et al., 2017\)](#page-9-12). Except for the conventional configurations, advanced configurations for double lift absorption cycle were studied for performance improvement. For instance, the combined single effect and double lift absorption cycles were ([Yan et al., 2013; Yattara et al.,](#page-9-13) [2003\)](#page-9-13) proposed to achieve both higher COP than double lift absorption cycle and more cooling output than single effect absorption cycle. The semi-GAX absorption cycles were studied to achieve higher COP than double lift cycle [\(Erickson and Tang, 1996; Toppi et al., 2016](#page-9-14)). Other options include the 2/3 effect cycles and triple lift cycles [\(Inoue, 2003](#page-9-15)). Among these absorption cycles, cycles like the double lift absorption cycles have lower driving temperatures but lower efficiencies, while cycles like semi-GAX absorption cycles have higher efficiencies but higher driving temperature. The tradeoff between working range and efficiency should be decided by the performance comparison.

The second issue is about the working fluid. Water-LiBr and ammonia-water are the most popular choices in commercial absorption chiller for air-conditioning and sub-zero conditions. In the air-cooled condition, the crystallization risk of water-LiBr solution is high which makes the water-ammonia working pair favorable. However, the ammonia-water system usually has lower efficiency than the water-LiBr system under the same condition. Besides, the crystallization risk of water-LiBr solution also varies with the absorption cycles even when the working conditions are the same. Detail analysis is needed to give the better option.

In order to find the better options for air-cooled solar absorption cooling, five absorption cycles suitable for air-cooled solar cooling system, i.e., three double lift absorption cycles and two semi-GAX absorption cycles with water-LiBr and ammonia-water working pairs, were studied and compared in this paper. Typical heat source temperatures and air temperatures for air-cooled solar cooling system were considered with evaporation temperatures of 5 °C for air-conditioning (with both water-LiBr and ammonia-water) and evaporation temperature of −10 °C for sub-zero condition (with only ammonia-water). Efficiency maps of these absorption cycles were calculated, and better options were given.

#### 2. Absorption refrigeration cycles for air-cooled solar absorption cooling

A typical solar absorption cooling system includes the solar collector, storage tank, absorption chiller, cooling tower, cooling load and the pumps. For air-conditioning purpose, single effect LiBr-water absorption chiller with driving temperature about 80–100 °C can be used with non-concentrating solar collector [\(Assilzadeh et al., 2005; Lizarte](#page-9-4) [et al., 2012; Syed et al., 2005\)](#page-9-4). However, if air-cooled system is used instead of cooling tower for heat dissipation as shown in [Fig. 1,](#page-1-0) the condensation temperature and absorption temperature will be increased, which requires higher temperature of heat source. Either solar collector with higher working temperature or absorption chiller with larger temperature lift at parity of evaporation and driving temperatures could be the solution. Since the cost of solar collector significantly

<span id="page-1-0"></span>![](_page_1_Picture_8.jpeg)

Fig. 1. Schematic of an air-cooled solar absorption cooling system.

affects the economic performance of solar absorption cooling system ([Al-Alili et al., 2012](#page-9-3)), the use of concentrating solar collector will increase the initial investment and maintenance cost [\(Cabrera et al.,](#page-9-16) [2013\)](#page-9-16). Besides, if the heat source temperature goes above 100 °C, either pressurized tank or thermal conductive oil will be used which also increases the initial investment. Absorption chillers with larger temperature lift is a better solution comparing with solar collector with higher working temperature.

Absorption refrigeration cycles with large temperature lift include the double lift absorption cycles, SE/DL absorption cycles, triple lift absorption cycles, semi-GAX absorption cycles and even the 3/4 effect absorption cycles. Among these cycles, the double lift absorption cycles and semi-GAX absorption cycles are simpler since they only have two circulation loops. In this case, three double lift absorption cycles and two semi-GAX absorption cycles shown in [Fig. 2](#page-2-0) are selected for aircooled solar cooling. In the figures, TG, TA and TE represent the generation temperature, absorption/condensation temperature and evaporation temperature respectively; generation, absorption, condensation, evaporation and resorption are abbreviated to G, A, C, E and R respectively; solid lines and dashed lines represent the liquid flow and vapor flow respectively.

There are three types of double lift absorption cycles including the mass-coupled double lift absorption cycle (DL-I), heat-coupled double lift cycle (DL-II) and resorption double lift absorption cycle (DL-III) as shown in [Fig. 2\(](#page-2-0)a)–(c). The DL-I shown in [Fig. 2](#page-2-0)(a) has two solution loops of with different pressures, i.e., G1-A1 and G2-A2. They are connected by the refrigerant vapor flow between G2 and A1. The large temperature lift comes from the pressure staged configuration. In this cycle, G1/G2 is heated by the heat source, C/A1/A2 is cooled by the ambient and E delivers cooling output. The DL-II shown in [Fig. 2](#page-2-0)(b) has two solution loops of G-A1 and G-A2 corresponding with evaporation of E1 and E2 respectively. They are coupled through the heat exchange between E2 and A1. Absorption A1 is cooled at temperature lower than the ambient that low refrigeration temperature is achieved in E1. In this cycle, G is heated by the heat source, C/A2 is cooled by the ambient and E1 delivers cooling output. The DL-III shown in [Fig. 2](#page-2-0)(c) has two solution loops of G1-A1 and G2-R. The cooling output from G2 is used to cool down the condensation C and low refrigeration temperature is achieved in E. In this cycle, G1 is heated by the heat source, A1/R is cooled by the ambient and E delivers cooling output.

<span id="page-2-0"></span>Double lift absorption cycles are able to work under low driving temperature due to its large temperature lift ability. This makes them suitable for solar cooling, but also decreases their efficiencies [\(Xu and](#page-9-5) [Wang, 2016](#page-9-5)). GAX absorption cycles obtain high efficiencies through internal heat recovery, but the internal heat recovery also requires high driving temperature ([Xu and Wang, 2016](#page-9-5)). The semi-GAX absorption cycles integrate GAX heat recovery into double lift configuration, and obtains better performance than the double lift absorption cycles. The mass-coupled semi-GAX absorption cycles (SGAX) proposed by Erikson ([Erickson and Tang, 1996\)](#page-9-14) are shown in [Fig. 2\(](#page-2-0)d) and (e). Both two cycles are improved from mass-coupled double lift absorption cycle DL-I. The DL-I has two solution loops, and SGAX-I and SGAX-II integrate the internal GAX heat recovery into one of the solution loops. The differences between SGAX-I and SGAX-II include the middle pressure P2 and the solution concentrations of two solution loops. SGAX-I has lower middle pressure and lower concentration in GAX loop.

Except for the SGAX-I and SGAX-II that integrate the GAX heat recovery into DL-I, semi-GAX absorption cycles can also be built by integrating the GAX heat recovery into DL-II and DL-III. However, the efficiency and adaptability of semi-GAX absorption cycles built from DL-II and DL-III are not as good as SGAX-I and SGAX-II according to our calculation. In this case, they are not introduced in detail.

#### 3. Performance calculation of the absorption cycles

In order to obtain the better options, the selected absorption cycles are compared with both LiBr-water and ammonia-water working pairs. [Fig. 3](#page-3-0) shows the schematics of LiBr-water absorption refrigeration cycles including DL-I and DL-II. Except for the main components, solution pumps, throttling valves and solution heat exchanger are also included. The DL-III is not studied with LiBr-water solution because it needs quite strong LiBr-water solution which is very easy to be crystalized. The SGAX-I and SGAX-II are also not studied with LiBr-water solution because the LiBr-water solution does not offer enough temperature overlap for GAX heat recovery.

[Fig. 4](#page-3-1) shows the schematics of water-ammonia absorption refrigeration cycles. Since there is no crystallization risk for water-ammonia solution, all the five selected absorption cycles shown in [Fig. 2](#page-2-0) are studied with water-ammonia. Considering the typical configuration of an ammonia-water absorption chiller, the solution heat exchangers, rectifiers, refrigerant pre-coolers, solution pumps and throttling valves are included.

The cycle performance is calculated according to the book ([Herold](#page-9-17) [et al., 1996\)](#page-9-17). State points at the inlet and outlet of each component are used for performance calculation. Pressure (P), temperature (T), concentration of ammonia (X), enthalpy (h) and mass flow rate (m) are used to describe the properties of water-LiBr solution [\(Pátek and](#page-9-18) [Klomfar, 2006](#page-9-18)) and ammonia-water solution [\(Ziegler and Trepp, 1984\)](#page-9-19)

![](_page_2_Figure_11.jpeg)

Fig. 2. Absorption refrigeration cycles suitable for air-cooled solar cooling: (a) Mass-coupled double lift cycle DL-I, (b) Heat-coupled double lift cycle DL-II, (c) Resorption double lift cycle DL-III, (d) Semi-GAX cycle SGAX-I, (d) Semi-GAX cycle SGAX-II.

<span id="page-3-0"></span>![](_page_3_Figure_1.jpeg)

Fig. 3. Schematics of the water-LiBr absorption cycles: (a) DL-I, (b) DL-II.

at each state point.

Following assumptions are made for the calculation.

- (1) The system operates in steady state condition,
- (2) Solution leaving generation and absorption, refrigerant leaving condensation and evaporation processes are saturated ([Herold](#page-9-17) [et al., 1996; Toppi et al., 2016\)](#page-9-17),
- (3) Pressure drop of vapor flow is neglected,
- (4) Pumping and throttling are isenthalpic,
- (5) The solution heat exchanger and pre-cooler have effectiveness of 0.75,
- (6) The rectified refrigerant vapor has an ammonia concentration of 0.99 ([Herold et al., 1996; Toppi et al., 2016](#page-9-17)).
- (7) The minimum temperature approaches in GAX, condensation-generation heat exchange and evaporation-absorption heat exchange are 5 °C.

The mass conservation, species conservation and energy conservation shown in Eqs. [\(1\)](#page-3-2)–(3) are considered for each component. MATLAB codes are developed based on the properties of working pair and these conservation equations.

<span id="page-3-2"></span>
$$\sum_{i} m_{i} = 0 \tag{1}$$

$$\sum_{i} m_i X_i = 0 \tag{2}$$

$$\sum_{i} m_i h_i + Q = 0 \tag{3}$$

where mi, Xi and hi refer to the mass flow rate, concentration and specific enthalpy of each stream flowing into the component respectively, and Q refers to the heat exchange amount with the external heat source of the component. COP of the absorption cycle is defined as the

<span id="page-3-1"></span>![](_page_3_Figure_17.jpeg)

Fig. 4. Schematics of the ammonia-water absorption cycles: (a) DL-I, (b) DL-II, (c) DL-III, (d) SGAX-I, (e) SGAX-II.

ratio between cooling output (Qoutput) and external heat input (Qinput) as shown below:

$$COP = Q_{output}/Q_{input}$$
 (4)

In order to validate the model, calculations based on parameters in literature are carried out. With evaporation temperature of 5 °C, condensation and absorption temperature of 40 °C, generation temperature of 163.3 °C, heat exchanger effectiveness of 0.8, GAX temperature approach of 0 K, the GAX cycle achieves COP of 1.110 in literature ([Herold et al., 1996](#page-9-17)). The calculated result in this paper is 1.107 with 0.3% difference coming from the property calculation, which proves the calculation in this paper is correct.

In air-cooled absorption chiller, the differences between air temperature and absorption/condensation temperature are important. According to the published data ([Chen et al., 2017; Du et al., 2012; Lin](#page-9-20) [et al., 2011\)](#page-9-20), the condensation temperature and absorption temperature are assumed to be 8 °C and 10 °C higher than the air temperature respectively. The generation temperature is assumed to be 5 °C lower than the heat source temperature; and the evaporation temperatures are set as 5 °C for air conditioning condition and -10 °C for sub-zero condition respectively. In order to avoid the crystallization risk in water-LiBr system, solution temperatures of 5 °C lower than its corresponding crystallization temperatures are set as the safe operation temperature. If one of the state points in water-LiBr system is too close to the crystallization (less than 5 °C temperature difference with the crystallization temperature), the system COP will be set to zero.

#### 4. Results and discussion

#### <span id="page-4-1"></span>4.1. COP optimization

The state equations of single stage absorption cycle can be solved by the external temperature conditions including generation temperature, absorption temperature, condensation temperature and evaporation temperature, and there is no optimization issue. However, state equations for double lift absorption cycles and semi-GAX absorption cycles have one more degree of freedom. Except for the external temperatures, another parameter is needed to solve the state equations. This parameter can be the flow rate ratio between two solution loops, the concentration glide, or the intermediate pressure. In the real operation of these cycles, the solution pump flow rates are easier to be controlled than other parameters. In this case, the pump flow rate ratio is used for COP optimization. As shown in [Figs. 3 and 4,](#page-3-0) the pump flow rate ratios in different absorption cycles are defined as the mass flow rate of pump P1 divided by the mass flow rate of pump P2.

The COP optimizations of the five selected absorption cycles with ammonia-water solution are carried out as shown in [Fig. 5.](#page-4-0) Heat source temperature of 90 °C, air temperature of 30 °C and evaporation temperature of 5 °C are used in calculation. The COP curves start with zero pump flow rate ratio and end when the absorption cycles cannot work. For all the five absorption cycles, the COPs increase with the pump flow rate ratios at first and then decrease. The optimized COPs of 0.374, 0.335, 0.317, 0.475 and 0.434 are obtained under pump flow rate ratios of 3.54, 2.31, 4.36, 2.39 and 4.05 for DL-I, DL-II, DL-III, SGAX-I and SGAX-II respectively. The influences of pump flow rate ratio on COP can be better explained by its effect on the heat losses as follows. All the five absorption cycles have two solution loop. When the pump flow rate ratio changes, the pressures and temperatures of the cycle change, the irreversible losses in solution heat exchanger reduce in one solution loop but increase in another solution loop. A balance of the heat losses in two solution loops will be achieved at a certain point where the COP is optimized.

#### 4.2. Performance under different working conditions

In order to better understand the influences of air temperatures,

heat source temperatures and evaporation temperatures on the performance of different absorption refrigeration cycles, optimized COPs are calculated and compared. The optimized COPs are obtained by varying the pump flow rate ratios as described in Section [4.1](#page-4-1). To ensure reasonable COP values, the optimized COP will be set as zero if the water-LiBr solution has high crystallization risk or the GAX internal heat recovery in semi-GAX cycle vanishes.

As shown in [Fig. 6,](#page-5-0) the optimized COPs of the five absorption cycles with both water-LiBr and ammonia-water are calculated under heat source temperature of 90 °C, evaporation temperature of 5 °C and air temperature from 20 °C to 40 °C. The optimized COPs of 0.419–0.315, 0.381–0.263, 0.338–0.204, 0.602–0.206, 0.494–0.183, 0.427–0.385 and 0.412–0.374 are obtained under optimized mass flow rate ratios of 4.42–17.6, 4.90–19.6, 0.194–4.72, 5.70–65.0, 4.42–83.3, 8.37–27.8 and 10.0–35.1 for the DL-I, DL-II, DL-III, SGAX-I, SGAX-II with ammonia-water and DL-I, DL-II with water-LiBr respectively.

It can be found from the figure that: (1) The semi-GAX absorption cycles have better performance than the double lift absorption cycles due to its internal GAX heat recovery; (2) The double lift water-LiBr absorption cycles have better performance than the double lift ammonia-water absorption cycles due to the better thermal properties of water-LiBr solution; (3) The DL-II with ammonia-water always has lower COP than the DL-I with ammonia-water and higher COP than the DL-III with ammonia-water, which is caused by that the evaporationabsorption thermal coupling in DL-II has more heat losses than generation-absorption mass coupling in DL-I but less heat losses than the condensation-generation thermal coupling in DL-III. (4) Under low air temperature, the DL-I and DL-II with water-LiBr cannot work because of high crystallization risk, and the DL-III with ammonia-water also cannot work due to the low temperature difference between air temperature and evaporation temperature.

When the air temperature increases, COPs of the semi-GAX absorption cycles decrease faster than that of the double lift absorption cycles due to the shrink of GAX temperature overlap. When the air temperature exceeds 34 °C, the DL-I and DL-II with water-LiBr have better performance than other cycles. This indicates that the semi-GAX absorption cycles are more sensitive to the air temperature than the double lift absorption cycles. This sensitivity comes from the need of large concentration glide in GAX heat recovery. When the air temperature increases, the concentration glide decreases and the temperature overlap in GAX heat recovery shrinks fast, resulting in a quick performance degradation.

The optimized COPs under heat source temperatures from 75 °C to 100 °C are shown in [Fig. 7.](#page-5-1) Air temperature of 30 °C and evaporation temperature of 5 °C are used in calculation. Optimized COPs of 0.364–0.380, 0.326–0.333, 0.274–0.319, 0.350–0.516, 0.350–0.448, 0.411–0.416 and 0.411–0.397 are obtained under mass flow rate ratios of 13.2–6.86, 13.2–7.53, 5.00–4.09, 19.1–9.03, 20.8–6.21, 21.1–10.1

<span id="page-4-0"></span>![](_page_4_Figure_16.jpeg)

Fig. 5. COP optimization of double lift absorption cycles and Semi-GAX absorption cycles with ammonia-water solution.

<span id="page-5-0"></span>![](_page_5_Figure_1.jpeg)

Fig. 6. Optimized COPs under air temperatures from 20 °C to 40 °C.

<span id="page-5-1"></span>![](_page_5_Figure_3.jpeg)

Fig. 7. Optimized COPs under heat source temperatures from 75 °C to 100 °C.

and 24.9–9.12 for the DL-I, DL-II, DL-III, SGAX-I, SGAX-II with ammonia-water and DL-I, DL-II with water-LiBr respectively.

When the heat source temperature is higher than 98.5 °C, the DL-I cannot work due to crystallization risk. For the same reason to avoid the crystallization risk, concentration glide in DL-II is limited and the optimized COP decreases when the heat source temperature is high. When the heat source temperature is higher than 81 °C, the SGAX-I with ammonia-water has better COP. When the heat source temperature is higher than 81 °C, the DL-I and DL-II with water-LiBr have better COPs. Compared with the results in Fig. 6, it can be found that the influences of increasing heat source temperature on COPs are similar but weaker compared to the decreasing air temperature. This is because the air temperature affects both the condensation temperature and absorption temperature, while the heat source temperature only affects the generation temperature.

The influences of evaporation temperatures on cycle performance are shown in Fig. 8. Since the water-LiBr absorption refrigeration cycles cannot work under sub-zero evaporation temperatures, they are not included in this figure. The five selected cycles with ammonia-water are calculated with heat source temperature of 90 °C and air temperature of 30 °C. In can be found from the figure that the evaporation temperatures have significant impact on the COPs, especially for the semi-GAX absorption cycles. The effect of low evaporation temperature is similar to that of high air temperature. Both high air temperature and low evaporation temperature decrease the concentration glide and temperature overlap in GAX heat recovery, resulting in fast performance degradation of semi-GAX absorption cycles. The reduction of evaporation temperatures from 5 °C to -10 °C decreases the COPs by 0.069-0.170. Besides, when the evaporation temperatures is decreased to -10 °C, COPs of DL-I, SGAX-I and SGAX-II are almost the same because the GAX overlaps in semi-GAX absorption cycles vanish and the semi-GAX absorption cycles become the same with DL-I.

#### <span id="page-5-3"></span>4.3. Optimized absorption cycles for air-conditioning conditions

In the air-cooled solar absorption cooling, both solar hot water temperature and air temperature vary a lot. It is important to evaluate both the efficiency and the operation range of the absorption cycles in the scenario of air-cooled solar cooling. In this section, the COP distributions of the selected cycles are calculated under the typical condition of air-cooled solar cooling, i.e., air temperature from 20  $^{\circ}\text{C}$  to 40  $^{\circ}\text{C}$  and heat source temperature from 75  $^{\circ}\text{C}$  to 100  $^{\circ}\text{C}$ . Evaporation temperature of 5  $^{\circ}\text{C}$  is considered for air-conditioning conditions.

Fig. 9 shows the COP distributions of five absorption cycles with either water-LiBr or ammonia-water. In these figures, different colors represent the levels of COP and the blue color represents non-workable area. The maximum COPs in Fig. 9(a)-(g) are 0.423, 0.384, 0.340, 0.604, 0.495, 0.439 and 0.437 respectively. It can be found that the SGAX-I with ammonia-water has better performance under high heat source temperatures with low air temperatures, and double lift absorption cycles with water-LiBr have better performance under low heat source temperature with high air temperature. The DL-I with ammoniawater occupies the largest workable area while DL-I with water-LiBr has the smallest. All the absorption cycles cannot work at the left-top corner with very high air temperature and very low heat source temperature. The DL-III cannot work with low air temperature because its resorption loop needs large temperature difference between the air temperature and evaporation temperature. The double lift absorption cycles with water-LiBr cannot work under high heat source temperature and low air temperature due to the crystallization risk.

In order to give clear overall evaluations of these absorption cycles, the working range and average COP of absorption cycles under heat source temperatures of 75–100 °C and air temperatures of 20–40 °C are calculated as follows. The ratio  $\alpha$  is calculated from the workable range divided by the whole calculation range, which describes the workable range of the cycle.  $\text{COP}_{ave}$  is the average COP in the workable range, which describes the average efficiency of the cycle. Symbolic function sgn is used to decide whether the COP at a certain condition is higher than zero, representing the cycle is workable or not.

$$\alpha = \frac{\sum\limits_{T_{source}} \sum\limits_{T_{air}} sgn(COP)}{\sum\limits_{T_{source}} \sum\limits_{T_{air}} 1}$$
(5)

$$COP_{ave} = \frac{\sum_{T_{source}} \sum_{T_{air}} COP}{\sum_{T_{source}} \sum_{T_{air}} sgn(COP)}$$
(6)

where  $T_{source}$  and  $T_{air}$  represent the heat source temperature and air temperature respectively.

The results of  $\alpha$  and  $COP_{ave}$  are shown in Table 1. It can be seen that the DL-I, DL-II and DL-III with ammonia-water have large workable areas but low efficiencies, the SGAX-I and SGAX-II with ammonia-water have medium workable areas and high efficiencies, and the DL-I and DL-II with water-LiBr have small workable areas and medium efficiencies. Low efficiency is the major drawback of double lift absorption cycles with ammonia-water. Small working area due to crystallization

<span id="page-5-2"></span>![](_page_5_Figure_17.jpeg)

Fig. 8. Optimized COPs under different evaporation temperatures from  $-10\,^{\circ}\text{C}$  to 5  $^{\circ}\text{C}.$ 

<span id="page-6-0"></span>![](_page_6_Figure_1.jpeg)

Fig. 9. COP distributions of absorption refrigeration cycles under typical air-cooled solar cooling conditions with Teva of 5 °C: (a) DL-I with ammonia-water, (b) DL-II with ammonia-water, (c) DL-III with ammonia-water, (d) SGAX-I with ammonia-water, (e) SGAX-II with ammonia-water, (f) DL-I with water-LiBr, (g) DL-II with water-LiBr. Scale bar: colors varies from red to blue with COP from 0.6 to 0.0. (For interpretation of the references to colour in this figure legend, the reader is referred to the web version of this article.)

<span id="page-7-0"></span>Table 1 Overall evaluation of the selected absorption cycles for air-conditioning conditions.

| Cycle    | DL-I    | DL-II   | DL-III  | SGAX-I  | SGAX-II | DL-I     | DL-II    |
|----------|---------|---------|---------|---------|---------|----------|----------|
| Solution | NH3-H2O | NH3-H2O | NH3-H2O | NH3-H2O | NH3-H2O | H2O-LiBr | H2O-LiBr |
| α        | 98.0%   | 97.4%   | 87.6%   | 86.1%   | 86.0%   | 79.5%    | 80.4%    |
| COPave   | 0.368   | 0.326   | 0.289   | 0.474   | 0.423   | 0.405    | 0.401    |

risk is the major drawback of double lift absorption cycles with water-LiBr. The SGAX-I has the best overall performance.

The analysis in [Table 1](#page-7-0) is the average evaluation on the whole range of air temperatures and heat source temperatures. In order to give the optimized options under different condition, the COPs of the seven options are compared and the optimized options are obtained in [Fig. 10](#page-7-1). In the figure, different colors represent different optimized options. It can be found that green color representing the SGAX-I with ammoniawater on the right-bottom side occupies the largest area. When the heat source temperature decreases and air temperature increases, the optimized option becomes the DL-II and DL-I with water-LiBr. This indicates that the SGAX-I with ammonia-water is better for air-cooled solar cooling if the solar thermal power could keep a high temperature, while the double lift absorption cycles with water-LiBr could be the better choice if the heat source temperature is not high. Of course, conditions with both high heat source temperature and low air temperature should be avoided for the water-LiBr systems.

#### 4.4. Optimized absorption cycles for sub-zero conditions

In order to evaluate the air-cooled solar absorption cooling systems for sub-zero conditions. The optimized COP distributions of selected absorption cycles are calculated with evaporation temperature of −10 °C. The ranges of heat source temperature and air temperature are the same with Section [4.3](#page-5-3). Since water-LiBr cannot work for sub-zero condition, the five selected absorption cycles are only studied with ammonia-water solution. Results are shown in [Fig. 11.](#page-8-0) The maximum COPs in [Fig. 11\(](#page-8-0)a)–(e) are 0.362, 0.311, 0.302, 0.494 and 0.431 respectively. The SGAX-I has the highest COP and the DL-I has the largest workable area. Compared with [Fig. 9,](#page-6-0) the workable areas shrink and the COPs decrease for all the cycles.

The workable area of semi-GAX absorption cycles are only near half of the whole considered area. The ratios α and average efficiencies COPave for sub-zero conditions are also calculated as shown in [Table 2](#page-8-1). Compared to air-conditioning condition, the workable areas of DL-I, DL-II and DL-III shrink 12.1%, 13.8% and 4% respectively, and the workable areas of semi-GAX absorption cycles shrink 30.1%. The DL-I is a better choice for its much larger workable area. Compared to the airconditioning condition, the COPs of DL-I, DL-II, SGAX-I and SGAX-II all decrease except for the DL-III. This is because the difference between evaporation temperature and air temperature is larger in sub-zero condition than in the air-conditioning condition, which is beneficial for the COP of DL-III.

Similar to Section [4.1,](#page-4-1) the distribution of optimized options is given in [Fig. 12.](#page-8-2) The SGAX-I is still the better option under high heat source temperature with low air temperature, and its occupied area in [Figs. 12](#page-8-2) and [11\(](#page-8-0)d) are the same. When the heat source is not enough to maintain the GAX overlap in semi-GAX absorption cycles, the DL-I becomes the best option. If the SGAX-I could be transferred to DL-I when its GAX heat recovery vanish, it will be the best choice.

In summary, 7 choices including 3 double lift absorption cycles and 2 semi-GAX absorption cycles with water-LiBr or ammonia-water have been analyzed for solar driven air-cooled cooling in this section. For airconditioning condition with evaporation temperature of 5 °C, 7 choices are all suitable. The crystallization risk of LiBr-water restricts its workable range and DL-I with ammonia-water has larger workable range. The possibility of generator-absorber heat exchange in ammoniawater coming from its large concentration glide could effectively increase the cycle efficiency, and SGAX-I with ammonia-water has higher average efficiency. However, DL-I with LiBr-water is still a good choice if the heat source temperature is not high and crystallization risk is low. For sub-zero condition with evaporation temperature of −10 °C, only 5 choices with ammonia-water are suitable and the results are similar, i.e. DL-I and SGAX-I have larger workable range and higher average efficiency respectively.

#### 5. Conclusions

In solar absorption cooling system, the cooling tower increases both the initial investment and water consumption. The air-cooled solar absorption cooling system is a good solution to avoid the use of cooling tower. However, the use of air-cooled system will increase the cooling temperature, which makes single effect absorption cycles hard to work efficiently. Besides, the crystallization risk of water-LiBr increases in the air-cooled systems. In order to find the better choice for air-cooled solar absorption cooling systems, three double lift absorption cycles and two semi-GAX absorption cycles were studied with both water-LiBr and ammonia-water. COP optimizations of these absorption cycles were achieved by adjusting the pump flow rates and the optimized options were given through the comparisons of COP and workable temperature range. The results presented in this paper could be helpful to the future design of solar driven air-cooled absorption cooling system, especially when the working temperature range could be estimated before the design.

- (1) Compared with the double lift absorption cycles, the semi-GAX absorption cycles achieve higher COP under low air temperature or high heat source temperature, but they are more sensitive to the external temperatures. The differences come from the GAX heat recovery in semi-GAX absorption cycles. Mass-coupled cycle DL-I has larger operation range and higher COP than the heat-coupled cycle DL-II and the resorption cycle DL-III due to less heat exchange processes and less internal heat losses.
- (2) For air-cooled solar cooling under air-conditioning condition, the DL-I, DL-II and DL-III with ammonia-water have large workable areas but low efficiencies, the SGAX-I and SGAX-II with ammoniawater have medium workable areas and high efficiencies, and the DL-I and DL-II with water-LiBr have small workable areas and medium efficiencies. The SGAX-I with ammonia-water is the better

<span id="page-7-1"></span>![](_page_7_Figure_15.jpeg)

Fig. 10. Optimized absorption refrigeration cycles under typical air-cooled solar driving conditions with Teva of 5 °C.

<span id="page-8-0"></span>![](_page_8_Figure_1.jpeg)

Fig. 11. COP distributions of absorption refrigeration cycles under air-cooled solar cooling conditions with Teva of −10 °C: (a) DL-I with ammonia-water, (b) DL-III with ammonia-water, (c) DL-III with ammonia-water, (d) SGAX-I with ammonia-water, (e) SGAX-II with ammonia-water.

<span id="page-8-1"></span>Table 2 Overall evaluation of the selected absorption cycles for sub-zero conditions.

| Cycle    | DL-I    | DL-II   | DL-III  | SGAX-I  | SGAX-II |
|----------|---------|---------|---------|---------|---------|
| Solution | NH3-H2O | NH3-H2O | NH3-H2O | NH3-H2O | NH3-H2O |
| α        | 85.9%   | 83.6%   | 78.4%   | 56.0%   | 55.9%   |
| COPave   | 0.362   | 0.311   | 0.302   | 0.494   | 0.431   |

option especially under both high heat source temperature and low air temperature. The double lift absorption cycles with water-LiBr are the better options when the heat source temperature is lower where crystallization risk is small.

(3) For air-cooled solar cooling under sub-zero condition, the SGAX-I has the highest COP and the DL-I has the largest workable area. However, the workable range of SGAX-I shrinks too much compared to the air-conditioning condition, and DL-I is the better choice.

<span id="page-8-2"></span>![](_page_8_Figure_7.jpeg)

Fig. 12. Optimized absorption refrigeration cycles under typical air-cooled solar driving conditions with Teva of −10 °C.

#### Acknowledgement

This research is supported by National Key Research and Development Program (Grant No. 2016YFB0601200). The support from the National Natural Science Foundation of China (Grant No. 51606124) and Foundation for Innovative Research Groups of the National Natural Science Foundation of China (Grant No. 51521004) were also appreciated.

### References

- <span id="page-9-3"></span>[Al-Alili, A., Islam, M.D., Kubo, I., Hwang, Y., Radermacher, R., 2012. Modeling of a solar](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0005) [powered absorption cycle for Abu Dhabi. Appl. Energy 93, 160](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0005)–167.
- <span id="page-9-11"></span>[Aprile, M., Toppi, T., Guerra, M., Motta, M., 2015. Experimental and numerical analysis](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0010) of an air-cooled double-lift NH3–[H2O absorption refrigeration system. Int. J. Refrig.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0010) [50, 57](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0010)–68.
- <span id="page-9-4"></span>[Assilzadeh, F., Kalogirou, S.A., Ali, Y., Sopian, K., 2005. Simulation and optimization of a](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0015) [LiBr solar absorption cooling system with evacuated tube collectors. Renew. Energy](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0015) [30, 1143](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0015)–1159.
- <span id="page-9-16"></span>[Cabrera, F., Fernández-García, A., Silva, R., Pérez-García, M., 2013. Use of parabolic](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0020) [trough solar collectors for solar refrigeration and air-conditioning applications.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0020) [Renew. Sustain. Energy Rev. 20, 103](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0020)–118.
- <span id="page-9-20"></span>[Chen, J.F., Dai, Y.J., Wang, R.Z., 2017. Experimental and analytical study on an air](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0025)cooled single eff[ect LiBr-H2O absorption chiller driven by evacuated glass tube solar](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0025) [collector for cooling application in residential buildings. Sol. Energy 151, 110](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0025)–118.
- <span id="page-9-10"></span>[Du, S., Wang, R.Z., Lin, P., Xu, Z.Z., Pan, Q.W., Xu, S.C., 2012. Experimental studies on an](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0030) [air-cooled two-stage NH3-H2O solar absorption air-conditioning prototype. Energy](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0030) [45, 581](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0030)–587.
- <span id="page-9-14"></span>[Erickson, D.C., Tang, J., 1996. Semi-GAX Cycles for Waste Heat Powered Refrigeration.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0035) [Inst. of Electrical and Electronics Engineers, Piscataway, NJ \(United States\).](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0035)
- <span id="page-9-17"></span>[Herold, K.E., Radermacher, R., Klein, S.A., 1996. Absorption Chillers and Heat Pumps.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0040) [CRC Press](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0040).
- <span id="page-9-15"></span>[Inoue, N., 2003. Static characteristics of various absorption cycle. Trans. Jpn. Soc. Refrig.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0045) [Air Condition. Eng. 20, 297](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0045)–308.
- <span id="page-9-6"></span>[Kang, Y.T., Kunugi, Y., Kashiwagi, T., 2000. Review of advanced absorption cycles:](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0050) [performance improvement and temperature lift enhancement. Int. J. Refrig. 23,](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0050) 388–[401](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0050).
- <span id="page-9-0"></span>[Kim, D., Ferreira, C.I., 2008. Solar refrigeration options](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0055)–a state-of-the-art review. Int. J. [Refrig. 31, 3](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0055)–15.
- <span id="page-9-8"></span>[Kim, D., Ferreira, C.I., 2009. Air-cooled LiBr](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0060)–water absorption chillers for solar air con[ditioning in extremely hot weathers. Energy Convers. Manage. 50, 1018](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0060)–1025.

- <span id="page-9-2"></span>[Li, Y., Hu, R., 2016. Exergy-analysis based comparative study of absorption refrigeration](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0065) [and electric compression refrigeration in CCHP systems. Appl. Therm. Eng. 93,](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0065) 1228–[1237](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0065).
- <span id="page-9-9"></span>[Lin, P., Wang, R.Z., Xia, Z.Z., 2011. Numerical investigation of a two-stage air-cooled](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0070) [absorption refrigeration system for solar cooling: cycle analysis and absorption](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0070) [cooling performances. Renew. Energy 36, 1401](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0070)–1412.
- [Lizarte, R., Izquierdo, M., Marcos, J.D., Palacios, E., 2012. An innovative solar-driven](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0075) directly air-cooled LiBr–[H2O absorption chiller prototype for residential use. Energy](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0075) [Build. 47, 1](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0075)–11.
- <span id="page-9-1"></span>[Ma, X., Chen, J., Li, S., Sha, Q., Liang, A., Li, W., Zhang, J., Zheng, G., Feng, Z., 2003.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0080) [Application of absorption heat transformer to recover waste heat from a synthetic](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0080) [rubber plant. Appl. Therm. Eng. 23, 797](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0080)–806.
- <span id="page-9-18"></span>[Pátek, J., Klomfar, J., 2006. A computationally e](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0085)ffective formulation of the thermodynamic properties of LiBr–[H2O solutions from 273 to 500 K over full composition](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0085) [range. Int. J. Refrig. 29, 566](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0085)–578.
- [Popli, S., Rodgers, P., Eveloy, V., 2013. Gas turbine e](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0090)fficiency enhancement using waste [heat powered absorption chillers in the oil and gas industry. Appl. Therm. Eng. 50,](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0090) 918–[931](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0090).
- [Sun, F., Fu, L., Zhang, S., Sun, J., 2012. New waste heat district heating system with](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0095) [combined heat and power based on absorption heat exchange cycle in China. Appl.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0095) [Therm. Eng. 37, 136](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0095)–144.
- [Syed, A., Izquierdo, M., Rodríguez, P., Maidment, G., Missenden, J., Lecuona, A., Tozer,](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0100) [R., 2005. A novel experimental investigation of a solar cooling system in Madrid. Int.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0100) [J. Refrig. 28, 859](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0100)–871.
- [Toppi, T., Aprile, M., Guerra, M., Motta, M., 2016. Numerical investigation on semi-GAX](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0105) NH3–[H2O absorption cycles. Int. J. Refrig. 66, 169](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0105)–180.
- <span id="page-9-12"></span>[Toppi, T., Aprile, M., Guerra, M., Motta, M., 2017. Performance assessment of a double](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0110)[lift absorption prototype for low temperature refrigeration driven by low-grade heat.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0110) [Energy 125, 287](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0110)–296.
- [Wang, R.Z., Ge, T.S., Chen, C.J., Ma, Q., Xiong, Z.Q., 2009. Solar sorption cooling systems](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0115) [for residential applications: options and guidelines. Int. J. Refrig. 32, 638](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0115)–660.
- <span id="page-9-5"></span>[Xu, Z.Y., Wang, R.Z., 2016. Absorption refrigeration cycles: categorized based on the](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0120) [cycle construction. Int. J. Refrig. 62, 114](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0120)–136.
- <span id="page-9-13"></span>[Yan, X., Chen, G., Hong, D., Lin, S., Tang, L., 2013. A novel absorption refrigeration cycle](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0125) [for heat sources with large temperature change. Appl. Therm. Eng. 52, 179](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0125)–186.
- [Yattara, A., Zhu, Y., Ali, M.M., 2003. Comparison between solar single-e](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0130)ffect and singleeff[ect double-lift absorption machines \(Part I\). Appl. Therm. Eng. 23, 1981](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0130)–1992.
- [Zhao, H., Jiang, T., Hou, H., 2015. Performance analysis of the SOFC](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0135)–CCHP system based on H2O/Li–[Br absorption refrigeration cycle fueled by coke oven gas. Energy 91,](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0135) 983–[993](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0135).
- <span id="page-9-19"></span>[Ziegler, B., Trepp, C., 1984. Equation of state for ammonia-water mixtures. Int. J. Refrig.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0140) [7, 101](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0140)–106.
- <span id="page-9-7"></span>Ziegler, F., Alefeld, G., 1987. Coeffi[cient of performance of multistage absorption cycles.](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0145) [Int. J. Refrig. 10, 285](http://refhub.elsevier.com/S0038-092X(18)30349-9/h0145)–295.