![](_page_0_Picture_1.jpeg)

Contents lists available at [ScienceDirect](www.sciencedirect.com/science/journal/2214157X)

# Case Studies in Thermal Engineering

journal homepage: [www.elsevier.com/locate/csite](https://www.elsevier.com/locate/csite)

![](_page_0_Picture_5.jpeg)

![](_page_0_Picture_6.jpeg)

# Key issues on the exergetic analysis of H2O/LiBr absorption cooling systems

Ana M. Blanco-Marigorta a,\* , J. Daniel Marcos <sup>b</sup>

- <sup>a</sup> *Universidad de Las Palmas de Gran Canaria, Departamento de Ingeniería de Procesos, Edificio de Ingenierías-Tafira Baja, 35017, Las Palmas, G. C., Spain*
- <sup>b</sup> *Universidad Nacional de Educaci*´ *on a Distancia, UNED, E.T.S. Ingenieros Industriales, Departamento de Ingeniería Energ*´*etica, C/ Juan del Rosal 12, 28040, Madrid, Spain*

#### ARTICLE INFO

#### *Keywords:* Exergy analysis Dead state Chemical exergy Exergetic efficiency H2O/LiBr Absorption machine

## ABSTRACT

This paper deals with the key aspects of the exergy analysis of H2O/LiBr absorption refrigeration cycles where, instead of agreement, disparity of opinion exists among researchers. As a result, comparisons with the literature are often difficult or meaningless. Based on an in-depth literature review, the key issues highlighted were: a) the identification of the dead state, b) the calculation of the exergy of the currents, and c) the definition of the exergy efficiency of the devices and of the overall system. This study clarifies controversial and divergent assumptions and proposes a coherent approach. In addition, a comparison with the literature is performed. As a case study, a single effect absorption cycle, refrigerated with water, has been considered here. Related to the dead state, consideration of different subsystems results in practical interest. The results highlight the importance of the correct calculation of the chemical exergy for the exergy analysis of the absorption refrigeration system. It is also described here how to define the rational exergetic efficiency, or fuel-product exergy, according to physical and chemical exergies of the streams. The comparison with the literature shows discrepancy specially in the exergy analysis of the desorber and the absorber, where the chemical exergy plays an important role.

# **1. Introduction**

Exergy analyses are very useful tools in the design, optimization and assessment of energy processes [\[1\]](#page-16-0) However, far from existing an agreement among researchers, there are several key points of the analysis where disparity of opinions is found [\[2\]](#page-16-0). As a result, comparisons with the literature are often difficult or not very meaningful. Plant analyses involving absorption systems are not an exception.

# *1.1. State of the art*

The scientific articles that somehow study or mention the exergy analysis of an absorption system are numerous. It is not the purpose of this paper to list them all. We will only refer to the really significant ones for our work, which are presented hereafter. We have focused on the works that include the methodology of exergy analysis of single H2O/LiBr absorption cooling systems, providing

*E-mail addresses:* [anamaria.blanco@ulpgc.es](mailto:anamaria.blanco@ulpgc.es) (A.M. Blanco-Marigorta), [jdmarcos@ind.uned.es](mailto:jdmarcos@ind.uned.es) (J.D. Marcos).

<https://doi.org/10.1016/j.csite.2021.101568>

<sup>\*</sup> Corresponding author.

some novel point of view or aspect.

One of the first works related to the topic, a joint work carried out by the University of Minnesota and the Technische Universitat ¨ München [\[3\]](#page-16-0) presented the availability analysis of a lithium bromide absorption heat pump. They applied the second law analysis to detect internal losses and to obtain a clear trend for design optimization. On the work of Arh and Gaspersic [[4](#page-16-0)], different advanced absorption cycles working between four temperature levels and two or three pressure levels were compared on the basis of the coefficient of performance COP and exergy efficiency. Results for the working mixture H2O/LiBr were there presented. Jernqvist et al. [\[5\]](#page-16-0) pointed out that the COP is not always adequate to describe the effectiveness of a sorption heat pump. They proposed the thermodynamic efficiency, the exergetic efficiency and the exergetic index, instead. They also stressed that exergy analysis should be used as a compliment to the First Law analysis. Oliveira and Le Goff [\[6\]](#page-16-0) identified the sources of entropy production within an absorption-desorption cycle trough energy, entropy and exergy balances. They also represented the exergy balances on two types of diagrams: exergy-composition and exergy-enthalpy, for the identification of exergy losses in the separation and mixing operations. Aprhornratana and Eames [[7](#page-16-0)] presented the results of the exergy analysis of a single effect absorption refrigerator cycle in a graphical format. In addition, they introduced a method for the calculation of entropy of water-lithium bromide solutions. Talbi and Agnew [\[8\]](#page-16-0) applied a design and optimization procedure where the exergy losses and the overall exergetic efficiency were taken as optimization parameters. In addition, an availability analysis was carried out for each component of the system. Sencan et al. [\[9\]](#page-16-0) calculated all exergy losses in a lithium bromide/water absorption system and they carried out the exergy analysis for different operating conditions. The exergetic efficiency for cooling and heating applications was also determined and shown graphically. Kilic and Kaynakli [\[10](#page-16-0)] used the first and second law of thermodynamics to analyze the performance of the cycle while varying some working parameters. A mathematical model based on the exergy method to evaluate the exergy loss of each component and total exergy loss of all the system components was introduced. Kaushik and Arora [[11\]](#page-16-0) developed a computational model for the parametric investigation of the cycle using new property equations of water-lithium bromide solution. Among the performance parameters computed were the exergy destruction and exergetic efficiency. Gebreslassie et al. [\[12](#page-16-0)] conducted an exergy analysis for single, double, triple and half effect cycles only considering the unavoidable exergy destruction. Thus, the obtained performances represented the maximum achievable performance under the given operation conditions. Palacios-Bereche et al. [\[13](#page-16-0)] presented a methodology to calculate the exergy of H2O/LiBr solution, they applied it to the evaluation of absorption refrigeration systems and compared some cases in the literature. Avanessian and Ameri [\[14](#page-16-0)] studied and compared different water-cooled systems under different operating and climatic conditions. They proved the effect of considering the chemical exergy of the H2O/LiBr solution on the exergetic analysis. Joybari and Haghighat [\[15](#page-16-0)] investigated absorption refrigeration systems with different heat exchanger designs having the same COP value. The effect on the outlet specific exergy and exergy destruction rate of each component was checked. Mussati et al. [\[16](#page-16-0)] applied a non linear mathematical model for the optimization of the cycle using the exergy loss rate, heat transfer area and cost as single objective functions. Pandya et al. [\[17](#page-16-0)] optimized the system from both the energy and the exergy point of view and focused on the generator temperature. The exergy destruction rate was selected as objective parameter and they evaluated the influence of the condenser and evaporator temperature on the optimum desorber temperature. Maryami and Dehghan [[18\]](#page-16-0) performed an exergy based comparative study between H2O/LiBr absorption refrigeration systems from half effect to triple effect. An optimum generator temperature, where the total exergy change was a minimum and the exergy efficiency a maximum, was found for all the configurations. A small capacity system was analyzed by Modi et al. [[19\]](#page-16-0) using a mathematical model. The rational efficiency and the exergy losses for all system components were obtained. Mohtaram et al. [\[20](#page-16-0)] compared the components of the cycle in terms of thermodynamic efficiency and rate of exergy destruction. Singh and Verma [[21\]](#page-16-0) used computational intelligence to perform the energy and exergy analysis of the system. The specific enthalpy and entropy were predicted through an artificial neural network and their results compared with published works. And, recently, Sala-Lizarraga ´ and Picallo-P´erez [[22\]](#page-16-0) described the simple cycle of an absorption refrigerator, with the exergy analysis of each one of its components. The irreversibilities and the exergy efficiency were calculated.

Interest in integrating H2O/LiBr absorption refrigeration cycles into more complex or polygeneration systems has grown exponentially in recent years. For example, Ghaebi et al. [[23\]](#page-16-0) carried out an exergoeconomic optimization of a trigeneration system for heating, cooling and power production, where cooling was produced by an absorption chiller. Godarzi et al. [[24\]](#page-16-0) designed a PCM storage system for a solar absorption chiller based on exergoeconomic analysis ans genetic algorithm. Guti´errez-Urueta et al. [[25\]](#page-16-0) analyzed a single effect system where two evaporators and a sub-cooler, in addition, were introduced. Cimsit et al. [[26](#page-16-0)] considered a R-134a compression – H2O/LiBr absorption cascade refrigeration cycle and performed an exergy-based thermoeconomic optimization. Rashidi and Yoo [\[27](#page-16-0)] performed both an exergetic and an exergoeconomic analysis of power-cooling cogeneration systems based on the kalina and absorption refrigeration cycles. Akrami et al. [\[28](#page-16-0)] used the same exergy approaches to assess a cogeneration hydrogen and cooling production plant equipped with concentrated PVT, an electrolyzer and an absorption chiller. Salhi et al. [\[29](#page-16-0)] studied a compression-absorption cascade refrigeration system powered by geothermal energy. Also a geothermal reservoir was used by Leveni et al. [\[30](#page-16-0)] to provide energy into a cascade organic Rankine Cycle and a water/lithium bromide absorption chiller. The integrated unit was analyzed trough an exergy analysis. Salehi et al. [[31\]](#page-16-0) carried out an exergoeconomic comparison of solar assisted absorption heat pumps, solar heaters and gas boilers for space heating. Behzadi et al. [[32\]](#page-16-0) optimized the production of electricity, cooling and hydrogen based on a solar system. A thermoelectric generator unit was used instead the condenser of the double effect H2O/LiBr absorption cooling system. The conventional and proposed systems were compared from energy, exergy and exergoeconomic points of view. Wu et al. [[33\]](#page-16-0) performed a thermoeconomic analysis of a composite district heating substation composed of an absorption heat pump. Agarwal et al. [[34\]](#page-16-0) presented an energy and exergy analysis of a vapor compression-triple effect absorption cascade refrigeration system. Recently, Sharifi et al. [[35\]](#page-16-0) maximized the exergetic and energetic efficiencies of a solar assisted absorption chiller. And Jain et al. [[36\]](#page-16-0) performed an advanced exergy analysis of a novel and integrated NH3/H2O and H2O/LiBr vapor absorption refrigeration system.

## <span id="page-2-0"></span>*1.2. Controversial and diverging hypotheses*

A careful inspection of the exergy analyses carried out in all these cited articles reveals a disparity of methodologies. This discrepancy is most pronounced on several points. One of them is related with the conditions of the dead state. Most of the articles take the ambient pressure [[3](#page-16-0),[25\]](#page-16-0) or similar values (1 bar [[11,28,36\]](#page-16-0), 1 atm [\[15,18,19,27\]](#page-16-0), 100 kPa [\[6,12,35](#page-16-0)], 101,3 kPa [\[13,14](#page-16-0),[26,30,33](#page-16-0), [34\]](#page-16-0)) as the dead state pressure. But, other authors do not mention this parameter [8–[10](#page-16-0),[20](#page-16-0),[21,23,31,32](#page-16-0)] and in the work of Salhi et al. [\[29](#page-16-0)] the value of 0.01 bar is considered without justification. The reference temperature also adopts different values around 20 ◦C [[7](#page-16-0), [25\]](#page-16-0), 25 ◦C [\[6,11,13,26](#page-16-0)–28[,30](#page-16-0),[32](#page-16-0)–34,[36\]](#page-16-0), 30 ◦C [[24,29\]](#page-16-0), or the ambient temperature [[3](#page-16-0),[35\]](#page-16-0). But Jernqvist et al. [[5](#page-16-0)] consider that T0 "*may be chosen at a level where heat energy is considered worthless for an actual application*" and they take the temperature of the medium on the heating side of the evaporator. The selection of a suitable reference state is important, as it is involved in the exergy calculation. Therefore, changing the values of the reference state will result in different exergy values. Authors state that it is usually the exergy differences that are of interest and not the absolute values, so this limitation is not considered too serious [[5\]](#page-16-0). In our paper we will show that it can be important, both conceptually and in terms of results.

Another point of divergence is the inclusion or not of the chemical exergy of the streams in the analysis. Misra et al. [\[37](#page-17-0)] calculates the chemical exergy of the refrigerant (water) but do not considers the chemical exergy of the solution, because there is no chemical reaction in the process. Other authors are of a similar opinion [\[15,24](#page-16-0)]. Agarwal et al. [[34\]](#page-16-0) think that kinetic, potential and chemical exergy are negligible for a flowing stream in control volume, though they are not. Gomri et al. [\[38](#page-17-0)] argue that "*because there is no departure of chemical substances from the cycle to the environment, the chemical exergy is zero*". Other authors do not calculate it because they do not need it for the analysis [\[4,](#page-16-0)8–[12,](#page-16-0)20–[22,30,36](#page-16-0)]. Some authors simply do not even mention it [\[5,7](#page-16-0),[9,17](#page-16-0)–19[,25](#page-16-0),[32,33\]](#page-16-0). In contrast, some articles carry out a detailed and in-depth calculation of the chemical exergy of all substances and streams, but using different approaches [[3,6,26](#page-16-0)[,39](#page-17-0)]. The methodology used by Palacios-Bereche et al. [\[13](#page-16-0)] has been cited later on [\[14,31](#page-16-0)[,40](#page-17-0),[41\]](#page-17-0). Avanessian and Ameri [\[14](#page-16-0)] calculate the error of neglecting chemical exergy and they obtain a value of 30% in the desorber and 50% in the absorber.

The definition of the exergetic efficiency is usually another controversial point regarding exergy analysis [\[2\]](#page-16-0). The different definitions of this parameter applied to absorption refrigeration systems have been detailed by Palacios-Bereche et al. [\[13](#page-16-0)]. Basically, two main definitions can be found. The first one relates exergy outflows to inflows. The second one is the so called rational efficiency, and relates exergetic gain (fuel exergy) to exergetic expenditure (product exergy). Actually, most of the literature articles cited here use this fuel-product exergetic efficiency definition. Some of them are just interested in the exergetic efficiency of the total system [\[10](#page-16-0)–12, 14–[16,18,20](#page-16-0),[21,25,29,30,34](#page-16-0)]. Other authors perform the exergy analysis of all the devices of the system, but they just provide the exergy destruction [\[7,8,17,22,29,36](#page-16-0)] or the exergy losses [\[9,33](#page-16-0)]. The exergetic efficiency of the different components of the system is analyzed by Refs. [[3](#page-16-0),[13,19,24,26](#page-16-0)–28[,31](#page-16-0),[32,35,](#page-16-0)[39](#page-17-0)], but the comparison of their results usually becomes difficult or complex due to the lack of uniformity in the methodology, as already pointed out.

# *1.3. Novelty and interest of the work*

From the literature review, three key points have been identified in the exergy analysis of the absorption cycle:

- a) the definition of the dead state,
- b) the calculation of the exergy of the material streams, and
- c) the definition of the exergy efficiency of the devices and of the overall system.

This paper takes a detailed look at all these key aspects from the point of view of the methodology and the concepts. As a case study, the single effect H2O/LiBr absorption refrigeration system [[42\]](#page-17-0) is used. The literature review shows a large discrepancy in the conceptual formulation of the exergy analysis of the absorption refrigeration cycle by various authors. This raises a problem when carrying out validations and formulating comparisons. In this paper, controversial and diverging hypothesys are cleared up and a comprehensive, coherent and consistent approach is proposed. In the practice, this proposal will ultimately lead to optimizing the design and operation of the system with much greater precision.

In addition, the comparison with the literature presenting a complete and original method of the exergetic calculation of the absorption machine, is performed.

# *1.4. Structure of the article*

The article is structured as follows: First, the key points in the exergy analysis of the absorption cycle are identified and defined. Each of these points is presented with the solution adopted in this work. Next, the exergy analysis of an absorption cycle is carried out following the proposed methodology. In the following section, other literature approaches are detailed and the analysis of the same cycle is conducted with each one of them. The results are compared with those of this study. Finally, the conclusions of the work are provided.

# **2. Methods: key issues in the exergy analysis of the absorption cycle**

From the literature review presented in the introduction, three key aspects were identified in the exergy analysis of the absorption

<span id="page-3-0"></span>cycle: a) the identification of the dead state, b) the calculation of the exergy of the streams, and c) the definition of the exergy efficiency of the devices and of the overall system. Each of these aspects and the solution adopted in this work are presented below.

# *2.1. Dead state*

In exergy analysis it is necessary to choose a reference environment. Usually the environmental conditions surrounding the system are chosen. However, for some systems, the external environmental conditions may not be the best choice as a dead state. This happens, for example, when the system has no or only partial interaction with the environment [[43\]](#page-17-0). In exergy analyses, it may be practical to divide a system into subsystems. This enables the analysis of the constraints affecting every subsystem and the choice of the appropriate dead state for each one individually, which may not be the same for all of them. The first step in establishing the appropriate dead states for each subsystem would be to state the parts of the universe that have a significant effect on the performance. Then, the practical and technological constraints on the interactions between the subsystems would be specified [[44\]](#page-17-0).

In this case study, the absorption cycle, the overall system can be considered as consisting of the following subsystems:(a) the absorption machine itself, confining the cooling fluid, H2O, and the solution with the absorbing fluid H2O/LiBr; (b) the heat source and the fluid circulating through it and exchanging heat with the absorption machine; (c) the evaporator and the fluid to be chilled; (d) the absorber and the condenser with the fluids that refrigerate the absorption machine.

Regarding the absorption machine itself, it is obvious that the working fluids confined in the machine do not exchange mass with the external fluids. The mass and total volume of these interior fluids are fixed, they are bounded. They can balance neither their pressure nor their composition with the environment surrounding the machine, they can only balance their temperature. Their equilibrium is therefore constrained.

Since a mechanical equilibrium with the environment cannot be reached, it makes not much sense to take the pressure of the external environment as the dead state pressure. And, since the chemical equilibrium with the environment cannot be reached, neither does it appear reasonable to consider as the chemical potential of these substances in the dead state that which corresponds to them in the external environment. For this case, Gagioli [\[44](#page-17-0)] proposes as dead state the state reached when the system is turned off, once the temperature reaches equilibrium with the environment.

For the heat source, it will be analyzed whether the fluid is confined in the system, where the above would apply. If the fluid is in contact with the environment at some point in the process, the ambient conditions can be taken as reference. The same reasoning applies to the external fluids flowing through the evaporator, absorber and condenser.

## *2.2. Estimation of the exergy of the working fluids*

In exergy analysis, the exergy of the working fluid at different points of the process has to be calculated. The exergy of a fluid, in the absence of electrical, magnetic, nuclear or surface tension effects, consists of four components: kinetic, potential, physical and chemical. And, when the kinetic and potential effects are negligible, it is enough to obtain the physical and chemical components of the exergy. Moreover, when the scope of the exergy analysis is limited to obtaining the destroyed exergy, the application of the Gouy-Stodola equation is sufficient and it is not necessary to calculate the chemical exergy of the working fluid. Similarly, if in a process there is no change in the composition of the fluid, no chemical reaction, and no separation of its components, the calculation of chemical exergy is not required since its value does not change.

In the case of the absorption machine, the exergy balances of some components, where the composition of the working fluid changes, require not only the values of the physical exergy, but also those of the chemical exergy. Although there are numerous exergy analyses of H2O/LiBr absorption machines in the literature, very few studies consider the calculation of the chemical exergy (see Introduction section). This has a significant influence on the value of some parameters, such as, for example, the exergy efficiency, as will be discussed below.

The physical component of the exergy of a stream of matter per unit mass, *exPH*, is given by Ref. [[45\]](#page-17-0):

$$ex^{PH} = (h - h_0) - T_0(s - s_0),$$
 (1)

where *h* and *s* are the specific enthalpy and entropy values of the fluid at the operating pressure and temperature, respectively. The subscript "0′′ indicates that the value of the properties is obtained at the dead state pressure and temperature conditions (*p*0 and *T*0).

Chemical exergy is "*the maximum work that can be achieved when a substance is driven from its equilibrium state at the environment pressure and temperature (dead restricted state) to the equilibrium state of equal chemical potentials (dead unrestricted state) by means of processes that involve heat, work and mass transfers with the environment*" [[13\]](#page-16-0). For a mixture or solution, it is obtained, at the pressure and temperature conditions of the dead state (*p*0 y *T*0), by means of [\[46](#page-17-0)]:

$$ex^{CH} = \sum_{i} \chi_{i} \left( \mu_{i,0} - \mu_{i,0}^{*} \right),$$
 (2)

where *μ*i,0 (kJ/kg) is the chemical potential of "*i*", at *p*0 y *T*0, when the composition is that of the state under consideration, *μ*\* *<sup>i</sup>,*0 (kJ/kg) is the chemical potential of "*i*" when, at *p*0 and *T*0, the system reaches chemical equilibrium with the environment, *χi* is the mass fraction of component "*i*".

As it follows from equations (1) and (2), for the calculation of exergy, it is essential to accurately obtain the thermodynamic

<span id="page-4-0"></span>properties of the fluid: enthalpy, entropy and chemical potential. There are several works in the literature providing these properties accurately over a wide range of temperatures and compositions (Yuan and Herold [\[47](#page-17-0)], Kim and Infante-Ferreira [\[48](#page-17-0)], Patek ´ and Klomfar [\[49](#page-17-0)], Palacios-Bereche et al. [[13\]](#page-16-0)). In this work we have used the correlations proposed by Yuan and Herold [[47](#page-17-0)], implemented in the Engineering Equation Solver v. 10.836, EES.

# *2.3. Exergetic efficiency*

Exergy efficiency is a parameter that can be tricky to calculate due to the lack of uniformity in the literature. Two are the most widespread definitions:

a) Input-output efficiency, *ηex*: where the exergy of the outflows is divided by the exergy of the inflows [\[50](#page-17-0)–52]:

$$\eta_{ex} = \frac{\sum Exergy \ out}{\sum Exergy \ in}.$$
(3)

Lior and Zhang [\[51](#page-17-0)] suggest the use of this expression for processes where most of the outputs can be considered as products. Moran [\[50](#page-17-0)] indicates its use also for dissipative elements, such as throttling valves.

b) Fuel-product Efficiency, ε: accounts for the relationship between the exergy of the desired product, *E*˙ *<sup>P</sup>*, and the exergy resources consumed to generate it, *E*˙ *<sup>F</sup>*, [\[45,53](#page-17-0),[54\]](#page-17-0):

$$\varepsilon = \frac{\dot{E}x_P}{\dot{E}x_F}.\tag{4}$$

This expression is more consistent with the conventional definition of energy efficiency, which relates energy produced to energy consumed, and will be used in this paper. It presents the difficulty of defining fuel and product, which depend on the operating purpose. To avoid ambiguities, Lazzareto and Tsatsaronis [\[55](#page-17-0)] define in detail, for a given device, which exergy terms are to be considered as part of the fuel or as part of the product:

"The product is defined to be equal to the sum of

- *all the exergy values to be considered at the outlet (including the exergy of energy streams generated in the component) plus*
- *all the exergy increases between inlet and outlet (i.e. the exergy additions to the respective material streams) that are in accord with the purpose of the component.*

Similarly, the fuel is defined to be equal to.

- *all the exergy values to be considered at the inlet (including the exergy of energy streams supplied to the component) plus*
- *all the exergy decreases between inlet and outlet (i.e. the exergy removals from the respective material streams) minus*
- *all the exergy increases (between inlet and outlet) that are not in accord with the purpose of the component."*

Exergy increases and decreases refer mainly to increments or reductions in the exergy of a mass flow, associated with a change either of the physical exergy or of the chemical exergy.

# *2.3.1. Dissipative components*

It could be argued that for some elements, such as expansion valves, it is not possible to obtain a "fuel-product" exergy efficiency value, since they are merely dissipative elements, without a product. But the fact is that it is not possible to define an energy efficiency for them either, precisely because their mission is to dissipate energy, not to produce it. Therefore, it may not make much sense to speak, in general, of exergy efficiency in these devices. One approach to addressing the inclusion of these elements in the exergy analysis and in the calculation of an exergy efficiency is proposed by Tsatsaronis [\[54\]](#page-17-0). This author indicates that, since expansion valves serve other devices, when formulating exergy efficiency, the valve and the device they serve should be considered together. This approach will be used in this paper regarding the two expansion valves in the absorption cycle, those that decrease the inlet pressure to the evaporator and the absorber, respectively.

## **3. Results**

# *3.1. Case study*

As a case study, the H2O/LiBr single effect absorption cycle analyzed by Herold et al. [\[42](#page-17-0)] has been adopted. The scheme of this cycle, with the operating conditions, is presented in [Fig. 1.](#page-5-0)

Main assumptions in the calculation of this absorption cycle are:

- <span id="page-5-0"></span>- Solution heat exchanger efficiency: 0.64.
- Vapor quality of points 1, 4, 8 set to 0.
- State 7: zero salt content.
- State 10: vapor quality set to 1.0.
- Pump: isoentropic.
- No chemical reactions occur between water and lithium bromide.
- The solution circulation ratio (liquid flow rate through the solution pump to vapor flow rate leaving the desorber: *f* = 10.94.
- Valves: adiabatic expansion. Kinetic energy effects are not included.
- Heat transfer coefficient-area product (*UA*):

Absorber: 1.8 kW/K Condenser: 1,2 kW/K Desorber: 1.0 kW/K Evaporator: 2.25 kW/K

With the operating conditions of Fig. 1, the energy transfers in the cycle are calculated:

- Pump power: *W*˙ = 0*.*205 *W*
- Heat transfer rate in the absorber: *Q*˙ *<sup>a</sup>* = 14*.*09 *kW*
- Heat transfer rate in the desorber: *Q*˙ *<sup>d</sup>* = 14*.*73 *kW*
- Heat transfer rate in the evaporator: *Q*˙ *<sup>e</sup>* = 10*.*67 *kW*
- Heat transfer rate in the condenser: *Q*˙ *<sup>c</sup>* = 11*.*31 *kW*
- Heat transfer rate in the solution heat exchanger: *Q*˙ *hx* = 3*.*11 *kW*
- Coefficient of performance: COP = 0.724

### *3.2. Exergy analysis of the case study*

The exergy analysis of the case study has been carried out taking into account the key aspects identified in this work (section [2](#page-2-0)). Their application to the present case is detailed as follows:

![](_page_5_Figure_22.jpeg)

**Fig. 1.** Schematic and operation conditions for the simple absorption H2O/LiBr refrigeration cycle [[42\]](#page-17-0).

## <span id="page-6-0"></span>a) Dead State.

As mentioned in the previous section (section [2.1.](#page-3-0)), an absorption machine can be divided into several subsystems. First, the absorption cycle itself, a closed system where the working fluid is the H2O/LiBr mixture. If this subsystem interacts with the environment until equilibrium, only a thermal equilibrium will be achieved, since the mechanical and chemical equilibrium is restricted by the limits of the system (closed and rigid). Following Paulus and Gaggioli [[43\]](#page-17-0), we take as dead state, for this subsystem, the state obtained when the machine is turned off, and the ambient temperature is attained (*T*0,1 = 25 ◦C). A company specialized on absorption chillers (Absorsistem) indicate that this state pressure can be taken as the pressure of state 1 (*p*0,1 = 0.676 kPa). This has been substantiated by Viswanathan et al., 2021 [\[56](#page-17-0)], in their dynamic analysis of a small-scale ammonia-water absorption chiller. Then, the composition of the dead state can be calculated when the chemical equilibrium is reached, it means that the chemical potential of water in the H2O/LiBr solution matches the Gibbs free energy of the water vapor [[47\]](#page-17-0); here, *χ*0,LiBr = 0.5186.

The heat source and the fluid outside the generator form another subsystem. In this paper, no specific heat source is taken and the external fluid is water. The dead state is the ambient pressure and temperature, *T*0,2 = 25 ◦C and *p*0,2 = 101.3 kPa. There is no need to define the composition of the dead state since the external fluid does not change its composition as it passes through the generator, nor, therefore, does its chemical energy.

Regarding the external fluids circulating through the evaporator, absorber and condenser, in this work the ambient conditions are taken as dead state conditions. In the evaporator water is cooled; and through the absorber and condenser circulates cooling water, which enters at ambient pressure and temperature. Again, the composition of the dead state does not need to be defined.

#### b) Calculation of the exergy values.

The thermodynamic properties have been obtained with the correlations proposed by Yuan and Herold [[47\]](#page-17-0), used in the EES calculation program, as stated in the previous section. For the refrigerant, H2O (states 7–10), and the H2O/LiBr solution (states 1–6), not only the physical exergy but also the chemical exergy has been calculated, since the fluid undergoes a change in composition as it passes through the absorber and the generator. Equations [\(1\) and \(2\)](#page-3-0) introduced in the previous section [2.2](#page-3-0) have been used for the calculations of the physical and the chemical exergy, respectively. For the external flows (states 11–18), as already indicated, the calculation of the chemical exergy is not required, since their composition does not change. The values of these thermodynamic properties, for all the streams of the system, are given in Table 1.

#### c) Exergetic efficiency.

In this work, the concept of rational exergy efficiency is used [\[45,53,54](#page-17-0)], as pointed out in section [2.3.](#page-4-0) This implies that, previously, the "*Fuel*" and the "*Product*", from the exergy point of view, must be identified for each device. Next, we analyze, from Lazzareto and Tsatsaronis's [\[55](#page-17-0)] perspective, (section [2.3\)](#page-4-0), every device of the cycle.

# *3.2.1. Desorber*

The function of the desorber is to provide the energy required to separate the refrigerant from the liquid working solution by a boiling process. The energy source in this case is water entering in liquid state at 100 ◦C. The H2O/LiBr solution (stream 3) enters diluted in the desorber (*χ*1 = 0.5648), releases the refrigerant (stream 7) and returns concentrated (stream 4, *χ*2 = 0.6216). Considering the values of physical and chemical exergies of the desorber input and output streams (Table 1), the following is observed:

**Table 1**  Specific values of de enthalpy, *h*, entropy, *s*, physical exergy, *exPH*, chemical exergy, *exCH*, and total exergy, *exTOT*, for all the material streams.

| Stream | h (kJ/kg) | s (kJ/k⋅kg) | exPH (kJ/kg) | exCH (kJ/kg) | exTOT (kJ/kg) |
|--------|-----------|-------------|--------------|--------------|---------------|
| 1      | 87.74     | 0.2010      | 0.195        | 2.849        | 3.044         |
| 2      | 87.74     | 0.2010      | 0.195        | 2.849        | 3.044         |
| 3      | 149.85    | 0.3943      | 4.640        | 2.849        | 7.489         |
| 4      | 223.32    | 0.4966      | 11.449       | 14.855       | 26.304        |
| 5      | 154.97    | 0.2980      | 2.317        | 14.855       | 17.172        |
| 6      | 154.97    | 0.2987      | 2.110        | 14.855       | 16.965        |
| 7      | 2643.62   | 8.4659      | 336.612      | 0.000        | 336.612       |
| 8      | 167.76    | 0.5731      | 213.999      | 0.000        | 213.999       |
| 9      | 167.76    | 0.6111      | 202.674      | 0.000        | 202.674       |
| 10     | 2503.46   | 9.1187      | 1.851        | 0.000        | 1.851         |
| 11     | 419.17    | 1.3072      | 33.982       |              | 33.982        |
| 12     | 404.46    | 1.2676      | 31.081       |              | 31.081        |
| 13     | 104.92    | 0.3672      | 0.000        |              | 0.000         |
| 14     | 155.20    | 0.5325      | 0.988        |              | 0.988         |
| 15     | 104.92    | 0.3672      | 0.000        |              | 0.000         |
| 16     | 145.26    | 0.5003      | 0.639        |              | 0.639         |
| 17     | 42.12     | 0.1511      | 1.636        |              | 1.636         |
| 18     | 15.40     | 0.0556      | 3.372        |              | 3.372         |

- <span id="page-7-0"></span>• The main exergy of fuel oil consists of the exergy decrease from stream (11) to (12), namely the heat source.
- The physical exergies of the output streams (4 and 7) are both higher than that of the input stream (stream 3), therefore, this exergy increase will be part of the product exergy.
- The chemical exergy of stream (4) is also higher than that of stream (3), so this exergy increase in the solution,  $\dot{m}_4(ex_4^{CH}-ex_3^{CH})$ , will be also part of the exergy of the product.
- However, the chemical exergy of stream (7) (refrigerant) is lower than that of stream (3). We have here an exergy decrease,  $m_7(ex_s^{CH} ex_s^{CH})$ , that should be part of the fuel.

$$\dot{E}x_{F,DES} = \left(\dot{E}_{11} - \dot{E}_{12}\right) + \dot{m}_7 \left(ex_3^{CH} - ex_7^{CH}\right). \tag{5}$$

$$\dot{E}x_{P,DES} = \dot{E}_{2}^{PH} + \dot{E}_{4}^{PH} - \dot{E}_{2}^{PH} + \dot{m}_{4}(ex_{4}^{CH} - ex_{2}^{CH}). \tag{6}$$

## 3.2.2. Absorber

In the absorber the refrigerant (stream 10) is absorbed by the concentrated H<sub>2</sub>O/LiBr solution (stream 6) in an exothermic process. As a consequence, energy is released to an external fluid (water) which enters at 25 °C. Considering the values of physical and chemical exergies (Table 1), the following is observed:

- The fuel consists of the decrease of physical and chemical exergy of the solution from stream (6) to stream (1).
- The product is the exergy increase of the cooling water from stream (13) to stream (14). And, there is also an exergy increase of the physical and chemical exergy of the refrigerant when it is absorbed by the solution, from stream (10) to stream (1).

$$\dot{E}x_{FABS} = \dot{m}_6 \left( ex_6^{TOT} - ex_1^{TOT} \right). \tag{7}$$

$$\dot{E}x_{P,ABS} = \left(\dot{E}_{14} - \dot{E}_{13}\right) + \dot{m}_{10}\left(ex_1^{TOT} - ex_{10}^{TOT}\right). \tag{8}$$

If the expansion valve is considered as an element that serves the absorber and its effect on the absorber's exergy efficiency is included, the fuel of the assembly absorber + valve should be calculated as:

$$\dot{E}x_{FABS+VAL} = m_6 \left( ex_5^{TOT} - ex_1^{TOT} \right). \tag{9}$$

Obviously, the product of the absorber would not change.

#### 3.2.3. Condenser

In the condenser the refrigerant (stream 7) transfers heat to the cooling water (stream 15), which enters at 25 °C, and, as a consequence, can be defined:

$$\dot{E}_{XFCON} = \dot{E}_7 - \dot{E}_8. \tag{10}$$

$$\dot{E}_{XP,CON} = \dot{E}_{16} - \dot{E}_{15}.$$
 (11)

#### 3.2.4. Evaporator

The function of the evaporator is to remove heat from an external fluid (stream 17), which enters at 3.6 °C:

$$\dot{E}x_{F,EVAP} = \dot{E}_9 - \dot{E}_{10}.$$
 (12)

$$\dot{E}_{XPEVAP} = \dot{E}_{18} - \dot{E}_{17}.$$
 (13)

If, as in the case of the absorber, the valve that serves the evaporator is included, the fuel of the set would be:

$$\dot{E}_{XF} = \dot{E}_{YA} + \dot{E}_{10}. \tag{14}$$

### 3.2.5. Heat exchanger

$$\dot{E}_{X_F HY} = \dot{E}_4 - \dot{E}_5. \tag{15}$$

$$\dot{E}x_{P,HX} = \dot{E}_3 - \dot{E}_2. \tag{16}$$

The pump has been considered isentropic, so its exergetic efficiency will be 100%.

The efficiency of the overall system depends on whether it works as a refrigeration machine or as a heat pump. Even a process in which both products are of interest could be considered. In this work we will deal only with the case where cooling is the desired product.

$$\dot{E}_{XF,TOT} = \dot{E}_{11} - \dot{E}_{12}.$$
 (17)

<span id="page-8-0"></span>
$$\dot{E}_{XP,TOT} = \dot{E}_{18} - \dot{E}_{17}.$$
 (18)

#### 4. Discussion

#### 4.1. Literature approaches

As we mentioned in the Introduction, an exhaustive search of published articles mentioning the exergy analysis of the absorption cycle with  $H_2O/LiBr$  was carried out. Among them, we have extracted those articles presenting a complete and original methodology of the exergetic calculation of the absorption machine, which could be compared with that of this work. For this reason, articles that do not mention or provide the calculation of the chemical exergy of the streams have not been included in the comparison. As indicated in section 2.2, the calculation of the chemical exergy in the absorption cycles is important because the solution changes its composition as it passes through some devices. Neither have been taken into account those articles whose only objective was the determination of the exergy destruction, since its value can be obtained by simply applying the Gouy-Stodola equation. Thus, only the articles published by Koehler et al. [3], Oliveira and Le Goff [6], and Palacios Bereche at al [13]. have been included in this comparison.

The methodology used by each of these authors [3,6,13] regarding the key aspects identified in this work is briefly described below in Table 2.

Although it was cited in the introduction as an alternative methodology for calculating the chemical exergy of streams, we have not included in our comparison the methodology proposed by Cimsit et al. [26]. The reason is that these authors calculate the chemical exergy just through the equation:

Table 2
Methodology used by several authors Koehler et al. [3], Oliveira and Le Goff [6], Palacios-Bereche et al. [13], for the exergy analysis of absorption machines with H<sub>2</sub>O/LiBr solution.

| Dead State                      |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |  |  |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|
| Koehler et al. [3]              | $T_0 = T_{environment}$ $p_0 = p_{environment}$ . For composition: they postulate that, due to the irreversible nature of any mixing process, the lowest potential for a mixture to do useful work is when it is in the saturation state at $T_0$ y $p_0$ . Then, $\chi_0 = \chi_{sat, LiBr}$ at $T_0$ , $p_0$ .                                                                                                                                                                                 |  |  |  |  |
| Oliveira and Le<br>Goff [6]     | $T_0 = 25  ^{\circ}\text{C}$ , $p_0 = 100  \text{kPa}$ .<br>For the composition: being a binary solution that undergoes composition change processes, they consider as reference conditions the conditions of chemical equilibrium at $p_0$ y $T_0$ . For the solution: $\chi_{0.\text{LiBr}} = 20  \text{wt}\%$ . For the refrigerant: $\chi_{0.\text{w}} = 0$ .                                                                                                                                |  |  |  |  |
| Palacios-Bereche<br>et al. [13] | Composition: Reference species, common components present in the environment, as proposed by Szargut [57].                                                                                                                                                                                                                                                                                                                                                                                       |  |  |  |  |
| Calculation of exerg            | y values                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |  |  |  |  |
| Koehler et al. [3]              | $\psi(T,p,\chi) = \psi_\chi(T,p) + \psi_0(\chi)$ . (19)                                                                                                                                                                                                                                                                                                                                                                                                                                          |  |  |  |  |
|                                 | The term $\psi_{\chi}(T,p)$ represents the physical exergy and $\psi_0(\chi)$ is the chemical exergy defined by:                                                                                                                                                                                                                                                                                                                                                                                 |  |  |  |  |
| Oliveira and Le<br>Goff [6]     | $\psi_0(\chi) = \frac{\chi_{sat} - \chi_s}{1 - \chi_{sat}} [h(T_0, p_0, \chi_{add}) - h(T_0, p_0, \chi_{sat}) - T_0[s(T_0, p_0, \chi_{add}) - s(T_0, p_0, \chi_{sat})] - [h(T_0, p_0, \chi_{sat}) - T_0s(T_0, p_0, \chi_{sat})] $ The chemical exergy is obtained by calculating the work of separation of the mixture at $p_0$ and $T_0$ from the state of composition considered, $\chi_M$ , to the reference state $\chi_0$ : $ex_M = (h_M - h_{M0}) - T_0(s_M - s_{M0}), (21) \text{ where}$ |  |  |  |  |
| Palacios-Bereche                | $h_{\text{MO}} = \frac{x_{\text{M}}}{x_0} h(p_0, T_0, x_{\text{M}}) + \left(1 - \frac{x_{\text{M}}}{x_0}\right) h(p_0, T_0, 0), (22) s_{\text{MO}} = \frac{x_{\text{M}}}{x_0} s(p_0, T_0, x_{\text{M}}) + \left(1 - \frac{x_{\text{M}}}{x_0}\right) s(p_0, T_0, 0). (23)$ They use the expression [58]:                                                                                                                                                                                          |  |  |  |  |
| et al. [13]                     | ex <sup>CH</sup> = $\left(\frac{1}{\overline{M}_{sol}}\right) \left[\sum_{i=1}^{n} y_i \overline{\epsilon}_i^0 + \overline{R} T_0 \sum_{i=1}^{n} y_i \ln a_i\right]$ . (24)                                                                                                                                                                                                                                                                                                                      |  |  |  |  |
|                                 | Applied to the H <sub>2</sub> O/LiBr solution:                                                                                                                                                                                                                                                                                                                                                                                                                                                   |  |  |  |  |
|                                 | $ex^{CH} = \left(\frac{1}{\overline{M}_{sol}}\right) \left[y_{H_2O}\overline{\epsilon}_{H_2O}^0 + y_{LiBr}\overline{\epsilon}_{LiBr}^0 + \overline{R}T_0(y_{H_2O} \ln a_{H_2O} + y_{LiBr} \ln a_{LiBr})\right], (25) \text{ where the standard chemical exergy, } \overline{\epsilon}_i^0, \text{ is calculated with}$                                                                                                                                                                           |  |  |  |  |
|                                 | Szargut's approach [57].                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |  |  |  |  |
| Exergetic efficiency            |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |  |  |  |
| Koehler et al. [3]              | The rational efficiency definition is used:                                                                                                                                                                                                                                                                                                                                                                                                                                                      |  |  |  |  |
|                                 | $arepsilon = rac{\psi_{profit}}{\psi_{finil}}.$ (26)                                                                                                                                                                                                                                                                                                                                                                                                                                            |  |  |  |  |
| Oliveira and Le                 | $\Psi_{fuel}$ They advocate the application of the fuel-product exergetic efficiency:                                                                                                                                                                                                                                                                                                                                                                                                            |  |  |  |  |
| Goff [6]                        | $\varepsilon = \frac{\text{Product}}{\text{Fuel}}$ . (4)                                                                                                                                                                                                                                                                                                                                                                                                                                         |  |  |  |  |
| Palacios-Bereche                | The rational efficiency concept is utilized:                                                                                                                                                                                                                                                                                                                                                                                                                                                     |  |  |  |  |
| et al. [13]                     | $\varepsilon = \frac{\text{Product}}{\text{Fuel}}$ . (4)                                                                                                                                                                                                                                                                                                                                                                                                                                         |  |  |  |  |
|                                 | For dissipative components, as the expansion valve, they use the Exergetic effectiveness, defined as:                                                                                                                                                                                                                                                                                                                                                                                            |  |  |  |  |
|                                 | $ \eta_{ex} = \frac{\text{Exergy Outlets}}{\text{Exergy inlets}}. $ (3)                                                                                                                                                                                                                                                                                                                                                                                                                          |  |  |  |  |

<span id="page-9-0"></span>
$$e^{CH} = RT_0 \ln y_i, \tag{27}$$

which, to the best of our knowledge, cannot be applied to a real solution [[1](#page-16-0)].

# *4.2. Comparison with literature regarding the calculation of exergy and the dead state*

Table 3 shows the physical and chemical exergy values for the case study streams using the methodology proposed in this work and the other methodologies published by Refs. [\[3,6](#page-16-0)], and [\[13](#page-16-0)].

Regarding the physical exergy, although its values are low, the following comments can be made. The values obtained by the different authors are the same in all streams, because they use the same dead state, *T*0,lit = 25 ◦C and *p*0,lit = 101.3 kPa. The physical exergy of the H2O/LiBr solution is the same regardless of the considered dead state. This is because the correlations used to calculate the specific enthalpy and entropy of the H2O/LiBr solution neglect the dependence of these properties on pressure, and, for this subsystem, the dead state of this work and the one used by the other authors have the same temperature. However, despite its low amounts, the physical exergy of the refrigerant, H2O (streams 7 to 10), presents significant differences from the dead state taken in this work, *p*0,1 = 0.676 kPa, and from that of other authors, *p*0,lit = 101.3 kPa. Our approach avoids the negative physical exergy values, which occur with literature methodologies when the working pressure is lower than that of the dead state (streams 9–10). The physical exergy of the external streams, obtained with the different methodologies, do not differ significantly.

The chemical exergy has been calculated only for the fluids confined in the machine (streams 1 to 10), since, when passing through some devices (absorber and desorber) their composition varies. As mentioned above, it is not necessary to calculate the chemical exergy of the external fluids, since their composition does not vary in the process.

It is evident that the chemical exergy values of the solution, H2O/LiBr (streams 1 to 6), and of the refrigerant, H2O (streams 7 to 10), show significant differences depending on the assumed dead state:

- Koehler et al. [[3\]](#page-16-0) consider that the minimum potential of a solution to perform useful work occurs when it is in a saturated state. The chemical exergy is calculated by supposing that the mixture at *T*0 and *p*0 evolves from a certain state of composition *χ* to the dead state, of composition *χ*sat, admitting a certain amount of solute. Thus, the minimum value of chemical exergy corresponds to the saturated solution and the highest value to pure water. The chemical exergy of pure water is calculated considering also as reference state the saturated state of the H2O/LiBr solution.
- Oliveira and Le Goff [[6](#page-16-0)] calculate the chemical exergy as the work required to separate the components of the mixture from the composition of the state under consideration to the composition of the chemical equilibrium state at *p*0 and *T*0. In the process, they follow a path that also considers *χ*0,w = 0 as a reference, thus canceling the chemical exergy of pure water.
- Palacios Bereche et al. [[13\]](#page-16-0) take into account both the standard chemical exergy of the components and the dissolution exergy to calculate the chemical exergy of the H2O/LiBr mixture. The standard chemical exergy of the elements of the solution, H2O, Li and Br is obtained by taking frequent components of the environment as reference species. Perhaps the only thing that could be pointed out is that, according to Szargut [\[57](#page-17-0)], in closed systems there is a certain freedom in choosing the state of reference. Since there is no material interaction with the environment, it does not seem meaningful to take as a dead state a state of the external environment that, due to physical restrictions, can never be reached.

**Table 3**  Physical and chemical exergy values for the single effect H2O/LiBr absorption machine obtained with the methodologies proposed in this work and in the literature.

| Stream | ExPH (kW) |          | ExCH (kW) |      |      |       |
|--------|-----------|----------|-----------|------|------|-------|
|        | This work | [3,6,13] | This work | [3]  | [6]  | [13]  |
| 1      | 0.01      | 0.01     | 0.14      | 1.30 | 6.08 | 25.71 |
| 2      | 0.01      | 0.01     | 0.14      | 1.30 | 6.08 | 25.71 |
| 3      | 0.23      | 0.23     | 0.14      | 1.30 | 6.08 | 25.71 |
| 4      | 0.52      | 0.52     | 0.67      | 0.00 | 8.14 | 27.02 |
| 5      | 0.11      | 0.11     | 0.67      | 0.00 | 8.14 | 27.02 |
| 6      | 0.10      | 0.10     | 0.67      | 0.00 | 8.14 | 27.02 |
| 7      | 1.54      | 0.57     | 0.00      | 2.90 | 0.00 | 0.23  |
| 8      | 0.98      | 0.01     | 0.00      | 2.90 | 0.00 | 0.23  |
| 9      | 0.93      | − 0.05   | 0.00      | 2.90 | 0.00 | 0.23  |
| 10     | 0.01      | − 0.96   | 0.00      | 2.90 | 0.00 | 0.23  |
| 11     | 34.04     | 34.04    |           |      |      |       |
| 12     | 31.14     | 31.14    |           |      |      |       |
| 13     | 0.00      | 0.00     |           |      |      |       |
| 14     | 0.28      | 0.28     |           |      |      |       |
| 15     | 0.00      | 0.00     |           |      |      |       |
| 16     | 0.18      | 0.18     |           |      |      |       |
| 17     | 0.65      | 0.65     |           |      |      |       |
| 18     | 1.35      | 1.35     |           |      |      |       |

#### 4.3. Comparison with the literature in terms of the calculation of exergy efficiency

As can be seen in Table 2, the authors we are considering have a common view of what should be defined as exergy efficiency, namely the fuel-product efficiency,  $\varepsilon$ , that considers the ratio between the exergy of the desired product,  $\dot{E}x_P$ , and the exergy resources spent on its generation,  $\dot{E}x_F$ . However, since the calculation of exergy differs between them, the values of the exergy efficiency of the devices and even, in some cases, their definition will also differ. The following tables and figures show a comparison between the results obtained with the methodology proposed by these authors and those obtained with the methodology used in this work.

First, it is necessary to review whether the definitions of fuel and product for the different devices proposed in equations (8)–(21) are applicable according to the results of physical and chemical energies obtained with the methodologies in the literature and presented in Table 3.

To understand the reasoning, let us detail, for example, the case of the desorber. Fig. 2 shows the schematic diagram of the desorber with indication of the input and output flows. The values of the physical and chemical exergies for each of the material streams entering and leaving the device, obtained with the different methodologies in the literature [3,6,13], have also been included in the figure. We take into account that the function of the desorber is to extract the refrigerant,  $H_2O$ , from the  $H_2O$ /LiBr solution, using energy from a thermal source.

Considering the values of physical and chemical exergies of the desorber input and output streams, obtained with the methodology presented by Koehler et al. [3], the following is observed:

- The main exergy of fuel oil consists of the exergy decrease from stream (11) to (12), namely the heat source.
- The dilute H<sub>2</sub>O/LiBr solution (stream 3) is split into a concentrated H<sub>2</sub>O/LiBr solution (stream 4) and a stream of H<sub>2</sub>O as a refrigerant (stream 7). The physical exergies of the output streams (4 and 7) are both higher than that of the input stream (stream 3), therefore, this exergy increase will be part of the product exergy.
- The chemical exergy of stream (7) is also higher than that of stream (3), so this exergy increase,  $\dot{m}_7(ex_7^{CH} ex_3^{CH})$ , will be also part of the exergy of the product.
- However, the chemical exergy of stream (4) is lower than that of stream (3). We have here an exergy decrease,  $\dot{m}_4(ex_3^{CH}-ex_4^{CH})$ , that should be part of the fuel.
- Thus, we have:

$$\dot{E}x_{F,DES,[3]} = \left(\dot{E}x_{11} - \dot{E}x_{12}\right) + \dot{m}_4\left(ex_3^{CH} - ex_4^{CH}\right). \tag{28}$$

![](_page_10_Figure_13.jpeg)

Fig. 2. Schematic of the desorber and values of the physical and chemical energies of the input and output streams, in mass units and per unit of time.

$$\dot{E}x_{P,DES,[3]} = \left(\dot{E}x_7^{PH} + \dot{E}x_4^{PH} - \dot{E}x_3^{PH}\right) + \dot{m}_7\left(ex_7^{CH} - ex_3^{CH}\right). \tag{29}$$

Regarding the values obtained with the methodology of Oliveira and Le Goff [6], the following is observed:

- The main fuel remains, logically, the exergy decreases from streams (11) to (12).
- The physical exergy of streams (7) and (4) is still higher than that of stream (3), so this exergy increase is part of the product.
- The chemical exergy of stream (7) is lower than that of stream (3), so now, this exergy decrease,  $\dot{m}_7(ex_3^{CH} ex_7^{CH})$ , is part of the fuel exergy.
- However, the chemical exergy of stream (4) is higher than that of stream (3), resulting in an exergy increase,  $m_4(ex_4^{CH} ex_3^{CH})$ , which will be part of the product.

And the following is obtained:

$$\dot{E}x_{F,DES,[6]} = \left(\dot{E}x_{11} - \dot{E}x_{12}\right) + \dot{m}_7\left(ex_3^{CH} - ex_7^{CH}\right),\tag{30}$$

$$\dot{E}x_{P,DES,[6]} = \left(\dot{E}x_7^{PH} + \dot{E}x_4^{PH} - \dot{E}x_3^{PH}\right) + \dot{m}_4\left(ex_4^{CH} - ex_3^{CH}\right). \tag{31}$$

The results with the methodology of Palacios-Bereche et al. [13] lead to the following reasoning:

- The exergy decrease of the heat source fluid,  $\dot{E}_{11} \dot{E}_{12}$ , is the main fuel of the device.
- The physical exergy of the output streams, (7) and (4), is higher than that of the dilute H<sub>2</sub>O/LiBr solution, therefore this difference accounts for the product.
- The chemical exergy of stream (4) is higher than that of stream (3), so that the exergy increase,  $m_4(ex_4^{CH} ex_5^{CH})$ , is also a product.
- The chemical exergy of stream (7) is lower than that of stream (3), so that the exergy decrease,  $\dot{m}_7(ex_3^{CH} ex_7^{CH})$ , is a fuel.

This results in:

$$\dot{E}x_{F,DES,[13]} = \left(\dot{E}x_{11} - \dot{E}x_{12}\right) + \dot{m}_7\left(ex_3^{CH} - ex_7^{CH}\right),\tag{32}$$

$$\dot{E}x_{P,DES,[13]} = \left(\dot{E}x_7^{PH} + \dot{E}x_4^{PH} - \dot{E}x_3^{PH}\right) + \dot{m}_4\left(ex_4^{CH} - ex_3^{CH}\right). \tag{33}$$

A similar analysis can be done for the absorber (see Fig. 3), where the concentrated  $H_2O/LiBr$  solution (6) absorbs the refrigerant,  $H_2O$  (10), and exits diluted, stream (1).

Thus, following the methodology of Koehler et al. [3], it is observed that the product is the exergy increase from stream (13) to stream (14). And, the fuel consists of:

$$\begin{array}{c|ccccccccccccccccccccccccccccccccccc$$

Fig. 3. Schematic of the absorber and values of the physical and chemical energies of the input and output streams, in mass units and per unit of time.

- The decrease of physical exergy from stream (6) to stream (1).
- The decrease of chemical exergy from stream (10) to stream (1).
- Minus the increase in physical exergy from stream (10) to stream (1) and the increase in chemical exergy from stream (6) to stream (1), which cannot be considered as products.

This results in:

$$\dot{E}x_{F,ABS,[3]} = \dot{m}_6(ex_6^{PH} - ex_1^{PH}) + \dot{m}_{10}(ex_{10}^{CH} - ex_1^{CH}) - \dot{m}_6(ex_1^{CH} - ex_6^{CH}) - \dot{m}_{10}(ex_1^{PH} - ex_{10}^{PH}) = \dot{E}x_{10} + \dot{E}x_6 - \dot{E}x_1, \tag{34}$$

$$\dot{E}x_{PABS,[3]} = \dot{E}x_{14} - \dot{E}x_{13}.$$
 (35)

Using values obtained with the methodologies of Oliveira and Le Goff [6], and Palacios Bereche et al. [13], the procedure would be:

- The product is again the exergy increase from stream (13) to stream (14).
- From stream (6) to stream (1) there is a reduction in both physical and chemical exergy, so these exergy decreases are part of the fuel.
- From stream (10) to stream (1) there is a non-productive increase in both physical and chemical exergy, so this difference must be subtracted from the fuel.

And, thus:

$$\dot{E}x_{F,ABS,[6,13]} = \dot{m}_6 \left( ex_6^{TOT} - ex_1^{TOT} \right) - \dot{m}_{10} \left( ex_1^{TOT} - ex_{10}^{TOT} \right) = \dot{E}x_{10} + \dot{E}x_6 - \dot{E}x_1, \tag{36}$$

$$\dot{E}_{XPARS}(6.13) = \dot{E}_{X14} - \dot{E}_{X13}.$$
 (37)

A certain discrepancy is observed with the expressions obtained in this work, where the fuel exergy is only due to the exergy decrease of the solution, Equation (7), and the product exergy also includes the increase of exergy of the refrigerant when it is absorbed by the solution, Equation (8).

In the other devices, evaporator, condenser and heat exchanger, these discrepancies in the definitions of fuel and product are not observed, since the variation of chemical exergy does not play an important role. Then, equations (9)–(16) should be used. Similarly, for the system as a whole, equations (17) and (18) apply.

Fig. 4 shows the values of the exergy of the fuel and the exergy of the product obtained by the different methodologies for the desorber and the absorber. The uncertainties of these calculations, following a simple Gauss law [59], are presented in Table 4.

In the desorber, significant mismatches are observed in the fuel exergy or product exergy calculations from the different methodologies. This is due to the fact that, in this case, chemical exergy has an important role and, as we have seen, it has a very different value according to the different methodologies. As a consequence, the expressions defining the value of fuel and product are different from each other, as we have seen above.

With the methodology proposed by Ref. [6], an important inconsistency is obtained, namely that the desorber product exergy results slightly higher than the fuel. This high value of the desorber product can only be due to an unbalanced calculation of the chemical exergy of the solution, as a consequence of the dead state composition, or of the formulation applied.

In the absorber, the differences between the fuel and product values obtained with the different methodologies are lower. Only some discrepancy is observed in the fuel obtained with [6].

In the other devices, and in the total system, the fuel and product values do not differ between the different methodologies. This is reasonable, since:

![](_page_12_Figure_22.jpeg)

Fig. 4. Exergy of the fuel and exergy of the product for the desorber and the absorber, using the methodology of this work and that proposed by other authors.

<span id="page-13-0"></span>**Table 4**  Uncertainties in the calculation of the exergy values.

| Parameter   | This work | Koehler et al. [3] | Oliveira and Le Goff [6] | Palacios Bereche et al. [13] |
|-------------|-----------|--------------------|--------------------------|------------------------------|
| T (⁰C)      | ±.0.05    | ±0.05              | ±0.05                    | ±0.05                        |
| p (kPa)     | ±0.1      | ±0.1               | ±0.1                     | ±0.1                         |
| h (kJ/kg)   | ±0.01     | ±0.01              | ±0.01                    | ±0.01                        |
| s (kJ/kg⋅K) | ±0.0002   | ±0.0002            | ±0.0002                  | ±0.0002                      |
| m ˙ (kg/s)  | ±0.005    | ±0.005             | ±0.005                   | ±0.005                       |
| Х           | ±0.001    | ±0.001             | ±0.001                   | ±0.001                       |
| μ (kJ/kg)   | ±0.002    | ±0.002             | ±0.002                   | ±0.002                       |
| Ex˙ PH (kW) | ±0.07     | ±0.07              | ±0.07                    | ±0.07                        |
| Ex˙ CH (kW) | ±0.02     | ±0.09              | ±0.08                    | ±0.05                        |
| Ex˙ F (kW)  | ±0.2      | ±0.3               | ±0.3                     | ±0.2                         |
| Ex˙ P (kW)  | ±0.2      | ±0.3               | ±0.3                     | ±0.2                         |

- In the evaporator and condenser, the definitions of fuel and product involve only differences in physical exergies. *Ex*˙ *<sup>F</sup>,EVAP* = 0*.*97 *kW, Ex*˙ *<sup>P</sup>,EVAP* = 0*.*69 *kW*; *Ex*˙ *<sup>F</sup>,COND* = 0*.*56 *kW, Ex*˙ *<sup>P</sup>,COND* = 0*.*18 *kW.*
- In the heat exchanger, the composition of the solution does not change while flowing through the device. *Ex*˙ *<sup>F</sup>,HX* = 0*.*41 *kW, Ex*˙ *<sup>P</sup>,HX* = 0*.*22 *kW*.
- In the total system, the total fuel is the exergetic decrease within the fluid used by the heat source, equation [\(17\),](#page-7-0) and the total product becomes the exergetic increase on the fluid to be cooled, equation [\(18\)](#page-8-0). In both definitions, only the physical exergy of the external streams is used, and this is the same in all cases because the dead state is practically the same. *Ex*˙ *<sup>F</sup>,TOT* = 2*.*91 *kW, Ex*˙ *<sup>P</sup>,TOT* = 0*.*69 *kW*.

Table 5 shows the exergy destroyed in the different devices, *Ex*˙ *<sup>F</sup>* − *Ex*˙ *<sup>P</sup>*, calculated in this work, with the methodology of other authors and with the Gouy-Stodola equation. In the case of the evaporator and the absorber, two values are included: those obtained considering only the device and those obtained by including the throttling valve. Obviously, in all cases, when the valve is included in the analysis of the evaporator and the absorber, the exergy destruction increases, due to the exergy destroyed in the valve.

The first aspect that stands out is the negative value obtained by Ref. [\[6\]](#page-16-0) for the desorber, as a consequence of the inconsistency noted above. Similarly, in the absorber, they obtain an extremely high exergy destruction. The value of exergy destruction in the desorber with the methodology of Koehler et al. [[3](#page-16-0)] is slightly low, and the value of the exergy destruction in the absorber is somewhat high. In the other devices, and in the overall system, no significant differences were observed.

With the methodology of this work, that of [\[3,13\]](#page-16-0), the exergy destruction is quite distributed and in no device is negligible. The device that destroys the highest amount of exergy is the desorber, with 29%. It is followed by the absorber and the condenser, where the exergy destroyed is almost a quarter of the total, 23 and 22% respectively. The condenser destroys 15% of the total and the heat exchanger 11%.

Following Oliveira and Le Goff's methodology [[6](#page-16-0)], the desorber does not destroy exergy. And the device that destroys the highest amount of exergy is the absorber, almost twice as much as the condenser. In the evaporator and heat exchanger the percentage destroyed is the same as with the other approaches.

Regarding the exergetic efficiency of the different devices of the absorption cycle, the only appreciable differences between the values obtained with the different methodologies are in the desorber and in the absorber. The comparison is shown in [Fig. 5.](#page-14-0)

In the desorber, the work of Oliveira and Le Goff [[6](#page-16-0)] indicates an efficiency of 100%. With the works of Koehler et al. [[3](#page-16-0)] and Palacios Bereche et al. [[13\]](#page-16-0), values around 89% are obtained, and with our work a value, perhaps more realistic, of 81% is obtained. In the system consisting of the absorber and the valve, our work indicates an exergy efficiency of 44%, while the other methodologies give a lower value: 41% [\[13](#page-16-0)], 38% [[3](#page-16-0)], and [\[6\]](#page-16-0) a nearly half value, 23%.

For the rest of the devices, no significant differences are observed between the values obtained with the different methodologies.

**Table 5**  Exergy destruction (kW) in the simple absorption cycle devices using the methodology of this work, that proposed by other authors and the Gouy-Stodola equation.

|                | This work | Koehler et al. [3], | Oliveira and Le Goff [6], | Palacios-Bereche et al. [13], | Gouy-Stodola |
|----------------|-----------|---------------------|---------------------------|-------------------------------|--------------|
| Desorber       | 0.55      | 0.45                | − 0.01                    | 0.50                          | 0.56         |
| Evaporator     | 0.22      | 0.22                | 0.22                      | 0.22                          | 0.21         |
| Evap + vale    | 0.27      | 0.27                | 0.27                      | 0.27                          | 0.26         |
| Absorber       | 0.35      | 0.45                | 0.91                      | 0.39                          | 0.33         |
| Abs + vale     | 0.36      | 0.46                | 0.91                      | 0.40                          | 0.34         |
| Condenser      | 0.38      | 0.38                | 0.38                      | 0.38                          | 0.36         |
| Heat exchanger | 0.19      | 0.19                | 0.19                      | 0.19                          | 0.19         |
| TOTAL          | 1.76      | 1.75                | 1.75                      | 1.75                          | 1.71         |

<span id="page-14-0"></span>![](_page_14_Figure_2.jpeg)

**Fig. 5.** Exergetic efficiency of the desorber and the absorber, using the methodology of this work and that of other authors.

Thus, for the evaporator + valve assembly, the energy efficiency reaches 72%; the heat exchanger offers 53% and the condenser 32%. In the overall system, no differences are observed between the different methodologies, as expected from the fuel and product calculations. The overall energy efficiency is 24%.

## **5. Conclusions**

In this paper, several key issues related to the exergy assessment of H2O/LiBr absorption cooling systems are identified and addressed. These core aspects are: a) the definition of the dead state b) the methodology and assumptions in the calculation of the physical and chemical exergy of the streams, and c) the definition of the exergy efficiency of the devices and of the overall system. As a case study, a single effect absorption cycle was studied.

The methodology proposed has been compared with other main approaches published in the literature [\[3,6,13\]](#page-16-0). Following conclusions have been drawn:

- 1. Consideration of different subsystems in the definition of the dead state of the absorption cycle results in practical interest. In particular, the working fluids confined in the machine can reach neither mechanical nor chemical equilibrium with the environment. Therefore, it does not appear reasonable to choose the environmental pressure and the chemical potential of the environmental as dead state conditions.
- 2. For the calculation of exergy, it is essential to accurately obtain the thermodynamic properties of the fluid: enthalpy, entropy and chemical potential. Chemical exergy does play an important role in the analysis of the absorption machine due to the chemical separation processes that occur.
- 3. For these systems, the fuel-product exergetic efficiency is more consistent with the conventional definition of energetic efficiency than the inlet-outlet approach. The identification of fuel and product is not straightforward, and ambiguities should be avoided.
- 4. The comparison with the literature shows:
  - The approach presented here avoids the negative physical exergy values, which occur with literature methodologies when the working pressure is lower than that of the dead state. Negative values of exergies in this situation, although commonly accepted, are meaningless from the point of view of the concept.
  - The definitions of fuel and product for the different devices should consider the results of physical and chemical exergies of the related fluids. Thus, we have obtained that the chemical exergy value of the fluids flowing through the desorber and the absorber is critical for obtaining the exergetic efficiency of these components.
  - Significant mismatches are observed in the calculation of the fuel and product exergy for the desorber and the absorber from the different methodologies. As a result, the values of the exergetic efficiencies of these components differ.
  - Also, the exergy destructions in the desorber and the absorber present some discrepancies depending on the methodology used to calculate it.

All these discrepancies show that the methodology used in the exergy analysis is not indifferent. The aspects identified in this work as key issues really have an important influence on the calculation of the properties and the thermodynamic analysis of the process. In subsequent works, this methodology will be applied to all types of absorption cycles, covering the full range of number of stages, absorber solutions and cooling system. A thorough critical review of the literature will also be carried out.

#### **Declaration of competing interest**

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## **Nomenclature**

COP Coefficient of performance HX Heat exchanger *a* activity

*ex* Specific exergy, kJ/kg *Ex* ˙ Exergy flow rate, kW *f* solution circulation ratio *h* Specific enthalpy, kJ/kg *m* ˙ Mass flow rate, kg/s

*M* Molar mass *p* Pressure, kPa

*R* Universal gas constant, kJ/(K⋅kmol)

*s* Specific entropy, kJ/kg⋅K

T Temperature, ◦C

*UA* Overall heat transfer coefficient-area product, kW/K

*W* ˙ Electric power, kW *y* Molar fraction

#### *Greek letters*

*ε* Rational exergetic efficiency *ε* Standard chemical exergy, kJ/kmol

*η* Efficiency

*μ* Chemical potential, kJ/kg

*χ* Mass fraction *Ψ* Exergy

# *Subscripts and superscripts*

0 Dead state *a, ABS* Absorber

*add* added (from actual state to saturation)

*CH* Chemical *c, CON* Condenser *D* Destruction *d, DES* Desorber *e, EVAP* Evaporator *ex* exergetic *F* Fuel

*HX* Heat exchanger *i* i-th substance k k-th component

*M* Mixture *P* Product *PH* Physical *sat* Saturation *sol* Solution *TOT* Total

*VAL* Expansion valve

# **Author contributions**

"Conceptualization, A.M.B.M. and J.D.M.; methodology, A.M.B.M. and J.D.M.; software, A.M.B.M.; validation, A.M.B.M. and J.D. M.; formal analysis, A.M.B.M. and J.D.M.; investigation, A.M.B.M. and J.D.M.; resources, A.M.B.M.; data curation, A.M.B.M.; writing—original draft preparation, A.M.B.M.; writing—review and editing, J.D.M.; visualization, A.M.B.M. and J.D.M.; supervision, J.D. M; project administration, A.M.B.M.; funding acquisition, A.M.B.M. All authors have read and agreed to the published version of the manuscript."

# **Funding**

"This research has been co-funded by ERDF funds, INTERREG MAC 2014–2020 programme, within the ACLIEMAC project (MAC2/

<span id="page-16-0"></span>3.5b/380)".

### **References**

- [1] [A. Bejan, G. Tsatsaronis, M. Moran, Thermal Design and Optimization, John Wiley](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref1) & Sons, New York, 1996.
- [2] G. Tsatsaronis, Definitions and nomenclature in exergy analysis and exergoeconomics, Energy 32 (2007) 249–253, [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.energy.2006.07.002)  [energy.2006.07.002](https://doi.org/10.1016/j.energy.2006.07.002).
- [3] W.J. Koehler, W.E. Ibele, J. Soltes, E.R. Winter, Availability simulation of a lithium bromide absorption heat pump, Heat Recovery Syst. CHP 8 (1988) 157–171, [https://doi.org/10.1016/0890-4332\(88\)90008-7](https://doi.org/10.1016/0890-4332(88)90008-7).
- [4] S. Arh, B. Gaˇsperˇsiˇc, Development and comparison of different advanced absorption cycles, Int. J. Refrig. 13 (1990) 41–50, [https://doi.org/10.1016/0140-7007](https://doi.org/10.1016/0140-7007(90)90053-Y) [\(90\)90053-Y](https://doi.org/10.1016/0140-7007(90)90053-Y).
- [5] Å. Jernqvist, K. Abrahamsson, G. Aly, On the efficiencies of absorption heat pumps, Heat Recovery Syst. CHP 12 (1992) 469–480, [https://doi.org/10.1016/](https://doi.org/10.1016/0890-4332(92)90015-A) [0890-4332\(92\)90015-A](https://doi.org/10.1016/0890-4332(92)90015-A).
- [6] [S. de Oliveira \(Jr\), P. Le Goff, Analyse exerg](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref6)´etique des processus de s´eparation et de m´elangeage.pdf, Rev. Gen. Therm. 21–9 (1994).
- [7] S. Aprhornratana, I.W. Eames, Thermodynamic analysis of absorption refrigeration cycles using the second law of thermodynamics method, Int. J. Refrig. (1995), [https://doi.org/10.1016/0140-7007\(95\)00007-X.](https://doi.org/10.1016/0140-7007(95)00007-X)
- [8] M.M. Talbi, B. Agnew, Exergy analysis: an absorption refrigerator using lithium bromide and water as the working fluids, Appl. Therm. Eng. 20 (2000) 619–630, [https://doi.org/10.1016/S1359-4311\(99\)00052-6.](https://doi.org/10.1016/S1359-4311(99)00052-6)
- [9] A. S¸ encan, K.A. Yakut, S.A. Kalogirou, Exergy analysis of lithium bromide/water absorption systems, Renew. Energy 30 (2005) 645–657, [https://doi.org/](https://doi.org/10.1016/j.renene.2004.07.006)  [10.1016/j.renene.2004.07.006](https://doi.org/10.1016/j.renene.2004.07.006).
- [10] M. Kilic, O. Kaynakli, Second law-based thermodynamic analysis of water-lithium bromide absorption refrigeration system, Energy (2007), [https://doi.org/](https://doi.org/10.1016/j.energy.2006.09.003)  [10.1016/j.energy.2006.09.003](https://doi.org/10.1016/j.energy.2006.09.003).
- [11] S.C. Kaushik, A. Arora, Energy and exergy analysis of single effect and series flow double effect water–lithium bromide absorption refrigeration systems, Int. J. Refrig. 32 (2009) 1247–1258, <https://doi.org/10.1016/J.IJREFRIG.2009.01.017>.
- [12] B.H. Gebreslassie, M. Medrano, D. Boer, Exergy analysis of multi-effect water-LiBr absorption systems: from half to triple effect, Renew. Energy 35 (2010) 1773–1782, [https://doi.org/10.1016/j.renene.2010.01.009.](https://doi.org/10.1016/j.renene.2010.01.009)
- [13] R. Palacios-Bereche, R. Gonzales, S.A. Nebra, Exergy calculation of lithium bromide–water solution and its application in the exergetic evaluation of absorption refrigeration systems LiBr-H2O, Int. J. Energy Res. 36 (2012) 166–181, [https://doi.org/10.1002/er.1790.](https://doi.org/10.1002/er.1790)
- [14] T. Avanessian, M. Ameri, Energy, exergy, and economic analysis of single and double effect LiBr–H2O absorption chillers, Energy Build. 73 (2014) 26–36, <https://doi.org/10.1016/J.ENBUILD.2014.01.013>.
- [15] M.M. Joybari, F. Haghighat, Exergy analysis of single effect absorption refrigeration systems: the heat exchange aspect, Energy Convers. Manag. 126 (2016) 799–810, <https://doi.org/10.1016/j.enconman.2016.08.029>.
- [16] S.F. Mussati, K.V. Gernaey, T. Morosuk, M.C. Mussati, NLP modeling for the optimization of LiBr-H2O absorption refrigeration systems with exergy loss rate, heat transfer area, and cost as single objective functions, Energy Convers. Manag. 127 (2016) 526–544,<https://doi.org/10.1016/J.ENCONMAN.2016.09.021>.
- [17] B. Pandya, J. Patel, A. Mudgal, Thermodynamic evaluation of generator temperature in LiBr-water absorption system for optimal performance, Energy Procedia 109 (2017) 270–278,<https://doi.org/10.1016/J.EGYPRO.2017.03.063>.
- [18] R. Maryami, A.A. Dehghan, An exergy based comparative study between LiBr/water absorption refrigeration systems from half effect to triple effect, Appl. Therm. Eng. 124 (2017) 103–123, [https://doi.org/10.1016/j.applthermaleng.2017.05.174.](https://doi.org/10.1016/j.applthermaleng.2017.05.174)
- [19] B. Modi, A. Mudgal, B. Patel, Energy and exergy investigation of small capacity single effect lithium bromide absorption refrigeration system, Energy Procedia 109 (2017) 203–210, [https://doi.org/10.1016/j.egypro.2017.03.040.](https://doi.org/10.1016/j.egypro.2017.03.040)
- [20] S. Mohtaram, W. Chen, J. Lin, A study on an absorption refrigeration cycle by exergy analysis approach, IOP Conf. Ser. Earth Environ. Sci. 182 (2018), [https://](https://doi.org/10.1088/1755-1315/182/1/012021) [doi.org/10.1088/1755-1315/182/1/012021](https://doi.org/10.1088/1755-1315/182/1/012021).
- [21] D.V. Singh, T.N. Verma, Energy and exergy analysis of LiBr-H2O-operated vapour absorption refrigeration system using the ANN approach, Int. J. Ambient Energy (2019), 0750, <https://doi.org/10.1080/01430750.2019.1670727>.
- [22] Lizarraga JMP. Sala, A. Picallo-Perez, Exergy analysis of thermal equipment in buildings (II), in: M.P. Jos´e, A.P.-P. Sala Lizarraga (Eds.), Exergy Anal. Thermoeconomics Build., Butterworth-Heinemann, 2020, pp. 455–553, [https://doi.org/10.1016/b978-0-12-817611-5.00006-0.](https://doi.org/10.1016/b978-0-12-817611-5.00006-0)
- [23] H. Ghaebi, M.H. Saidi, P. Ahmadi, Exergoeconomic optimization of a trigeneration system for heating, cooling and power production purpose based on TRR method and using evolutionary algorithm, Appl. Therm. Eng. 36 (2012) 113–125, <https://doi.org/10.1016/j.applthermaleng.2011.11.069>.
- [24] A.A. Godarzi, M. Jalilian, J. Samimi, A. Jokar, M.A. Vesaghi, Design of a PCM storage system for a solar absorption chiller based on exergoeconomic analysis and genetic algorithm, Int. J. Refrig. 36 (2013) 88–101, <https://doi.org/10.1016/J.IJREFRIG.2012.08.028>.
- [25] G. Guti´errez-Urueta, A. Huicochea, P. Rodríguez-Aumente, W. Rivera, Energy and exergy analysis of water-LiBr absorption systems with adiabatic absorbers for heating and cooling, Energy Procedia 57 (2014) 2676–2685, [https://doi.org/10.1016/J.EGYPRO.2014.10.279.](https://doi.org/10.1016/J.EGYPRO.2014.10.279)
- [26] C. Cimsit, I.T. Ozturk, O. Kincay, Thermoeconomic optimization of LiBr/H2O-R134a compression-absorption cascade refrigeration cycle, Appl. Therm. Eng. 76 (2015) 105–115,<https://doi.org/10.1016/J.APPLTHERMALENG.2014.10.094>.
- [27] J. Rashidi, C.K. Yoo, Exergetic and exergoeconomic studies of two highly efficient power-cooling cogeneration systems based on the Kalina and absorption refrigeration cycles, Appl. Therm. Eng. 124 (2017) 1023–1037, <https://doi.org/10.1016/J.APPLTHERMALENG.2017.05.195>.
- [28] E. Akrami, A. Nemati, H. Nami, F. Ranjbar, Exergy and exergoeconomic assessment of hydrogen and cooling production from concentrated PVT equipped with PEM electrolyzer and LiBr-H2O absorption chiller, Int. J. Hydrogen Energy 43 (2018) 622–633, [https://doi.org/10.1016/J.IJHYDENE.2017.11.007.](https://doi.org/10.1016/J.IJHYDENE.2017.11.007)
- [29] K. Salhi, M. Korichi, K.M. Ramadan, Thermodynamic and thermo-economic analysis of compression–absorption cascade refrigeration system using low-GWP HFO refrigerant powered by geothermal energy, Int. J. Refrig. 94 (2018) 214–229, [https://doi.org/10.1016/J.IJREFRIG.2018.03.017.](https://doi.org/10.1016/J.IJREFRIG.2018.03.017)
- [30] M. Leveni, G. Manfrida, R. Cozzolino, B. Mendecka, Energy and exergy analysis of cold and power production from the geothermal reservoir of Torre Alfina, Energy 180 (2019) 807–818, <https://doi.org/10.1016/J.ENERGY.2019.05.102>.
- [31] S. Salehi, M. Yari, M.A. Rosen, Exergoeconomic comparison of solar-assisted absorption heat pumps, solar heaters and gas boiler systems for district heating in Sarein Town, Iran, Appl. Therm. Eng. 153 (2019) 409–425, <https://doi.org/10.1016/J.APPLTHERMALENG.2019.03.022>.
- [32] A. Behzadi, A. Habibollahzade, P. Ahmadi, E. Gholamian, E. Houshfar, Multi-objective design optimization of a solar based system for electricity, cooling, and hydrogen production, Energy 169 (2019) 696–709, [https://doi.org/10.1016/J.ENERGY.2018.12.047.](https://doi.org/10.1016/J.ENERGY.2018.12.047)
- [33] Z. Wu, Y. Wang, S. You, H. Zhang, X. Zheng, J. Guo, et al., Thermo-economic analysis of composite district heating substation with absorption heat pump, Appl. Therm. Eng. (2019) 114659, [https://doi.org/10.1016/J.APPLTHERMALENG.2019.114659.](https://doi.org/10.1016/J.APPLTHERMALENG.2019.114659)
- [34] S. Agarwal, A. Arora, B.B. Arora, Energy and exergy analysis of vapor compression–triple effect absorption cascade refrigeration system, Eng Sci Technol an Int J (2019), [https://doi.org/10.1016/J.JESTCH.2019.08.001.](https://doi.org/10.1016/J.JESTCH.2019.08.001)
- [35] S. Sharifi, F. Nozad Heravi, R. Shirmohammadi, R. Ghasempour, F. Petrakopoulou, L.M. Romeo, Comprehensive thermodynamic and operational optimization of a solar-assisted LiBr/water absorption refrigeration system, Energy Rep. 6 (2020) 2309–2323, [https://doi.org/10.1016/j.egyr.2020.08.013.](https://doi.org/10.1016/j.egyr.2020.08.013)
- [36] V. Jain, A. Singhal, G. Sachdeva, S.S. Kachhwaha, Advanced exergy analysis and risk estimation of novel NH3-H2O and H2O-LiBr integrated vapor absorption refrigeration system, Energy Convers. Manag. 224 (2020) 113348, <https://doi.org/10.1016/j.enconman.2020.113348>.

- <span id="page-17-0"></span>[37] R.D. Misra, P.K. Sahoo, S. Sahoo, A. Gupta, Thermoeconomic optimization of a single effect water/LiBr vapour absorption refrigeration system, Int. J. Refrig. 26 (2003) 158–169, [https://doi.org/10.1016/S0140-7007\(02\)00086-5.](https://doi.org/10.1016/S0140-7007(02)00086-5)
- [38] R. Gomri, Second law comparison of single effect and double effect vapour absorption refrigeration systems, Energy Convers. Manag. 50 (2009) 1279–1287, [https://doi.org/10.1016/J.ENCONMAN.2009.01.019.](https://doi.org/10.1016/J.ENCONMAN.2009.01.019)
- [39] R. Palacios-Bereche, R. Gonzales, S.A. Nebra, Exergy calculation of lithium bromide–water solution and its application in the exergetic evaluation of absorption refrigeration systems, Int. J. Energy Res. 36 (2012) 161–181, [https://doi.org/10.1002/er.1790.](https://doi.org/10.1002/er.1790)
- [40] M. Zoghi, H. Habibi, A. Chitsaz, K. Javaherdeh, M. Ayazpour, Exergoeconomic analysis of a novel trigeneration system based on organic quadrilateral cycle integrated with cascade absorption-compression system for waste heat recovery, Energy Convers. Manag. 198 (2019) 111818, [https://doi.org/10.1016/J.](https://doi.org/10.1016/J.ENCONMAN.2019.111818) [ENCONMAN.2019.111818](https://doi.org/10.1016/J.ENCONMAN.2019.111818).
- [41] G. Shu, J. Che, H. Tian, X. Wang, P. Liu, A compressor-assisted triple-effect H2O-LiBr absorption cooling cycle coupled with a Rankine Cycle driven by hightemperature waste heat, Appl. Therm. Eng. 112 (2017) 1626–1637, [https://doi.org/10.1016/J.APPLTHERMALENG.2016.08.073.](https://doi.org/10.1016/J.APPLTHERMALENG.2016.08.073)
- [42] [K.E. Herold, R. Radermacher, A.K. Sanford, in: Absorption Chillers and Heat Pumps, second ed., CRC Press, Taylor](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref42) & Francis, London, 2016.
- [43] [D.M. Paulus, R.A. Gaggioli, The Dead State According to the Available Energy of Gibbs. AES, vol. 40, ASME, New York, 2000.](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref43)
- [44] R.A. Gaggioli, The dead state, Int. J. Therm. 15 (2012) 191–199, [https://doi.org/10.5541/ijot.423.](https://doi.org/10.5541/ijot.423)
- [45] [G. Hatsopoulous, J. Keenan, Principles of General Thermodynamics, Wiley, New York, 1965.](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref45)
- [46] [J. Ahrendts, Die Exergie Chemisch Reaktionsf](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref46)¨ ahiger System, 1977.
- [47] Z. Yuan, K.E. Herold, Thermodynamic properties of aqueous lithium bromide using a multiproperty free energy correlation thermodynamic properties of aqueous lithium bromide using a multiproperty free energy correlation, HVAC R Res. 11 (2005) 377–393, [https://doi.org/10.1080/10789669.2005.10391144.](https://doi.org/10.1080/10789669.2005.10391144)
- [48] D.S. Kim, C.A.I. Ferreira, A Gibbs energy equation for LiBr aqueous solutions, Int. J. Refrig. 29 (2006) 36–46, [https://doi.org/10.1016/j.ijrefrig.2005.05.006.](https://doi.org/10.1016/j.ijrefrig.2005.05.006)
- [49] J. P´ atek, J. Klomfar, A computationally effective formulation of the thermodynamic properties of LiBr-H2O solutions from 273 to 500 K over full composition range, Int. J. Refrig. 29 (2006) 566–578, [https://doi.org/10.1016/j.ijrefrig.2005.10.007.](https://doi.org/10.1016/j.ijrefrig.2005.10.007)
- [50] [M. Moran, in: Availability Analysis: a Guide to Efficient Energy Use, second ed., ASME Press, New York, 1989](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref50).
- [51] N. Lior, N. Zhang, Energy , exergy , and Second Law performance criteria, Energy 32 (2007) 281–296, <https://doi.org/10.1016/j.energy.2006.01.019>.
- [52] D. Marmolejo-correa, T. Gundersen, A comparison of exergy ef fi ciency de fi nitions with focus on low temperature processes, Energy 44 (2012) 477–489, [https://doi.org/10.1016/j.energy.2012.06.001.](https://doi.org/10.1016/j.energy.2012.06.001)
- [53] P.J. Petit, R.A. Gaggioli, Second Law Procedures for Evaluating Processes. Thermodyn. Second Law Anal, vol. 122, ACS Symposium Series, WASHINGTON, D.C, 1980, pp. 15–37,<https://doi.org/10.1021/bk-1980-0122.ch002>.
- [54] [G. Tsatsaronis, Thermoeconomic analysis and optimization of energy systems, Prog. Energy Combust. Sci. 19 \(1993\) 227](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref54)–257.
- [55] A. Lazzaretto, G. Tsatsaronis, Speco : a systematic and general methodology for calculating efficiencies and costs in thermal systems, Energy 31 (2006) 1257–1289, [https://doi.org/10.1016/j.energy.2005.03.011.](https://doi.org/10.1016/j.energy.2005.03.011)
- [56] [V.K. Viswanathan, A.S. Rattner, M.D. Determan, S. Garimella, Dynamic model for small-capacity ammonia-water absorption chiller, Int. Refrig. Air Cond. Conf.,](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref56) [Purdue \(2012\) 2494](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref56)–2503. July 16-19.
- [57] [J. Szargut, D. Morris, F. Steward, Exergy Analysis of Thermal, Chemical, and Metallurgical Processes, Hemisphere Publishing Corporation, New York, 1988.](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref57)
- [58] [T. Kotas, in: The Exergy Method of Thermal Plant Analysis, second ed., Krieger Publishing, Malabar, Florida, 1995](http://refhub.elsevier.com/S2214-157X(21)00731-0/sref58).
- [59] H.-J. Bartsch, in: Handbook of Mathematical Formulas, first ed., Elsevier, 1974 [https://doi.org/10.1016/C2013-0-10338-8.](https://doi.org/10.1016/C2013-0-10338-8)