#### [Skip to main content](#page-0-0)

Advertisement

[Advertisement](file://pubads.g.doubleclick.net/gampad/jump?iu=/270604982/springerlink/11708/article&sz=728x90&pos=top&articleid=s11708-017-0507-1)

```
Log in
  Menu
Find a journal Publish with us Track your research 
  Search
     Home
     Frontiers in Energy
Springer Nature Link
  Cart
   1. 
   2.
```

# **Absorption heat pump for waste heat reuse: current states and future development**

Review Article •

Article

<span id="page-0-0"></span>3.

- Published: 15 November 2017 •
- Volume 11, pages 414–436, (2017) •
- [Cite this article](#page-20-0) •

![](_page_1_Picture_1.jpeg)

- Section Strain
  - Zhenyuan Xu<sup>1</sup> &
  - Ruzhu Wang 1
  - 1131 Accesses
  - 67 Citations
  - Explore all metrics

#### **Abstract**

Absorption heat pump attracts increasing attention due to its advantages in low grade thermal energy utilization. It can be applied for waste heat reuse to save energy consumption, reduce environment pollution, and bring considerable economic benefit. In this paper, three important aspects for absorption heat pump for waste heat reuse are reviewed. In the first part, different absorption heat pump cycles are classified and introduced. Absorption heat pumps for heat amplification and absorption heat transformer for temperature upgrading are included. Both basic single effect cycles and advanced cycles for better performance are introduced. In the second part, different working pairs, including the water based working pairs, ammonia based working pairs, alcohol based working pairs, and halogenated hydrocarbon based working pairs, for absorption heat pump are classified based on the refrigerant. In the third part, the applications of the absorption heat pump and absorption heat transformer for waste heat reuse in different industries are introduced. Based on the reviews in the three aspects, essential summary and future perspective are presented at last.

This is a preview of subscription content, <u>log in via an institution</u> to check access.

### Access this article

Log in via an institution

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

#### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11708-017-0507-1                                                                                                        |
| 2095-1698                                                                                                                        |
| Absorption heat pump for waste heat reuse: current states and future development                                                 |
| 2017                                                                                                                             |
| 2017                                                                                                                             |
| Zhenyuan Xu, Ruzhu Wang                                                                                                          |
| Frontiers in Energy                                                                                                              |
| 74877ceca89ef9d913edff88f3ffebc38f5de6e2258368061ec6c8d0246b1eb48de0bdda9b6abad961b3c3274c057160c04aa26cad51034c262a0f3d7e8f48a1 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

### **Similar content being viewed by others**

![](_page_3_Picture_1.jpeg)

### **[Progress in the Application of Absorption Cycles](https://link.springer.com/10.1007/s11630-025-2100-y?fromPaywallRec=true)**

Article 19 March 2025

![](_page_3_Picture_4.jpeg)

## **[Optimization Potentials for the Waste Heat Recovery of a Gas-Steam](https://link.springer.com/10.1007/s11630-018-1055-7?fromPaywallRec=true) [Combined Cycle Power Plant Based on Absorption Heat Pump](https://link.springer.com/10.1007/s11630-018-1055-7?fromPaywallRec=true)**

Article 14 March 2019

![](_page_3_Picture_7.jpeg)

### **[Numerical study of a hybrid absorption-compression high temperature](https://link.springer.com/10.1007/s11708-017-0515-1?fromPaywallRec=true) [heat pump for industrial waste heat recovery](https://link.springer.com/10.1007/s11708-017-0515-1?fromPaywallRec=true)**

Article 22 November 2017

#### **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

• [Biogas](file:///subjects/biogas)

- [Energy Conservation](file:///subjects/energy-conservation) •
- [Thermal Process Engineering](file:///subjects/thermal-process-engineering) •
- [Thermodynamics](file:///subjects/thermodynamics) •
- [Thermophotovoltaics](file:///subjects/thermophotovoltaics) •
- [Engineering Thermodynamics, Heat and Mass Transfer](file:///subjects/engineering-thermodynamics-heat-and-mass-transfer) •

## **References**

Lu H, Price L, Zhang Q. Capturing the invisible resource: analysis of waste heat potential in Chinese industry. Applied Energy, 2016, 161: 497–511 1.

[Article](https://doi.org/10.1016%2Fj.apenergy.2015.10.060) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Capturing%20the%20invisible%20resource%3A%20analysis%20of%20waste%20heat%20potential%20in%20Chinese%20industry&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2015.10.060&volume=161&pages=497-511&publication_year=2016&author=Lu%2CH&author=Price%2CL&author=Zhang%2CQ)

Johnson I, Choate W T, Davidson A. Waste heat recovery. Technology and opportunities in US industry. Technical Report, 2008 2.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Waste%20heat%20recovery&publication_year=2008&author=Johnson%2CI&author=Choate%2CW%20T&author=Davidson%2CA)

Lecompte S, Huisseune H, van den Broek M, Vanslambrouck B, De Paepe M. Review of organic Rankine cycle (ORC) architectures for waste heat recovery. Renewable & Sustainable Energy Reviews, 2015, 47: 448–461 3.

[Article](https://doi.org/10.1016%2Fj.rser.2015.03.089) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Review%20of%20organic%20Rankine%20cycle%20%28ORC%29%20architectures%20for%20waste%20heat%20recovery&journal=Renewable%20%26%20Sustainable%20Energy%20Reviews&doi=10.1016%2Fj.rser.2015.03.089&volume=47&pages=448-461&publication_year=2015&author=Lecompte%2CS&author=Huisseune%2CH%20v%20d&author=Broek%2CM&author=Vanslambrouck%2CB%20D&author=Paepe%2CM)

Hatami M, Ganji D, Gorji-Bandpy M. A review of different heat exchangers designs for increasing the diesel exhaust waste heat recovery. Renewable & Sustainable Energy Reviews, 2014, 37: 168–181 4.

[Article](https://doi.org/10.1016%2Fj.rser.2014.05.004) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20review%20of%20different%20heat%20exchangers%20designs%20for%20increasing%20the%20diesel%20exhaust%20waste%20heat%20recovery&journal=Renewable%20%26%20Sustainable%20Energy%20Reviews&doi=10.1016%2Fj.rser.2014.05.004&volume=37&pages=168-181&publication_year=2014&author=Hatami%2CM&author=Ganji%2CD&author=Gorji-Bandpy%2CM)

Ebrahimi K, Jones G F, Fleischer A S. A review of data center cooling technology, operating conditions and the corresponding low-grade waste heat recovery opportunities. Renewable & Sustainable Energy Reviews, 2014, 31: 622–638 5.

Zhang H, Wang H, Zhu X, Qiu Y J, Li K, Chen R, Liao Q. A review of waste heat recovery technologies towards molten slag in steel industry. Applied Energy, 2013, 112: 956–966 6.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2013.02.019) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20review%20of%20waste%20heat%20recovery%20technologies%20towards%20molten%20slag%20in%20steel%20industry&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2013.02.019&volume=112&pages=956-966&publication_year=2013&author=Zhang%2CH&author=Wang%2CH&author=Zhu%2CX&author=Qiu%2CY%20J&author=Li%2CK&author=Chen%2CR&author=Liao%2CQ)

Brückner S, Liu S, Miró L, Radspieler M, Cabeza L F, Lävemann E. Industrial waste heat recovery technologies: an economic analysis of heat transformation technologies. Applied Energy, 2015, 151: 157–167 7.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2015.01.147) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Industrial%20waste%20heat%20recovery%20technologies%3A%20an%20economic%20analysis%20of%20heat%20transformation%20technologies&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2015.01.147&volume=151&pages=157-167&publication_year=2015&author=Br%C3%BCckner%2CS&author=Liu%2CS&author=Mir%C3%B3%2CL&author=Radspieler%2CM&author=Cabeza%2CL%20F&author=L%C3%A4vemann%2CE)

Centre IHP. Application of industrial heat pumps. IEA Heat Pump Programme Annex 35, 2014 8.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Application%20of%20industrial%20heat%20pumps&publication_year=2014&author=Centre%2CIHP)

Rivera W, Best R, Cardoso M, Romero R. A review of absorption heat transformers. Applied Thermal Engineering, 2015, 91: 654–670 9.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2015.08.021) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20review%20of%20absorption%20heat%20transformers&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2015.08.021&volume=91&pages=654-670&publication_year=2015&author=Rivera%2CW&author=Best%2CR&author=Cardoso%2CM&author=Romero%2CR)

Wu W, Wang B, Shi W, Li X. Absorption heating technologies: a review and perspective. Applied Energy, 2014, 130: 51–71 10.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2014.05.027) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Absorption%20heating%20technologies%3A%20a%20review%20and%20perspective&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2014.05.027&volume=130&pages=51-71&publication_year=2014&author=Wu%2CW&author=Wang%2CB&author=Shi%2CW&author=Li%2CX)

Sun J, Fu L, Zhang S. A review of working fluids of absorption cycles. Renewable & Sustainable Energy Reviews, 2012, 16(4): 1899–1906 11.

#### [Article](https://doi.org/10.1016%2Fj.rser.2012.01.011) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20review%20of%20working%20fluids%20of%20absorption%20cycles&journal=Renewable%20%26%20Sustainable%20Energy%20Reviews&doi=10.1016%2Fj.rser.2012.01.011&volume=16&issue=4&pages=1899-1906&publication_year=2012&author=Sun%2CJ&author=Fu%2CL&author=Zhang%2CS)

Takeshita I, Yamamoto Y, Harada T,Wakamatsu N. Residential gasfired absorption heat pump based on R22-DEGDME pair. Part 2 design, computer simulation and testing of a prototype. International Journal of Refrigeration, 1984, 7(5): 313–321 12.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Residential%20gasfired%20absorption%20heat%20pump%20based%20on%20R22-DEGDME%20pair&journal=Part%202%20design%2C%20computer%20simulation%20and%20testing%20of%20a%20prototype.%20International%20Journal%20of%20Refrigeration&volume=7&issue=5&pages=313-321&publication_year=1984&author=Takeshita%2CI&author=Yamamoto%2CY%20H&author=Wakamatsu%2CN)

Wu W, Wang B, You T, Shi W, Li X. A potential solution for thermal imbalance of ground source heat pump systems in cold regions: ground source absorption heat pump. Renewable Energy, 2013, 59: 39–48 13.

#### [Article](https://doi.org/10.1016%2Fj.renene.2013.03.020) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20potential%20solution%20for%20thermal%20imbalance%20of%20ground%20source%20heat%20pump%20systems%20in%20cold%20regions%3A%20ground%20source%20absorption%20heat%20pump&journal=Renewable%20Energy&doi=10.1016%2Fj.renene.2013.03.020&volume=59&pages=39-48&publication_year=2013&author=Wu%2CW&author=Wang%2CB&author=You%2CT&author=Shi%2CW&author=Li%2CX)

Zhu K, Xia J, Xie X, Jiang Y. Total heat recovery of gas boiler by absorption heat pump and direct-contact heat exchanger. Applied Thermal Engineering, 2014, 71(1): 213–218 14.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2014.06.047) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Total%20heat%20recovery%20of%20gas%20boiler%20by%20absorption%20heat%20pump%20and%20direct-contact%20heat%20exchanger&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2014.06.047&volume=71&issue=1&pages=213-218&publication_year=2014&author=Zhu%2CK&author=Xia%2CJ&author=Xie%2CX&author=Jiang%2CY)

Li X, Wu W, Zhang X, Shi W, Wang B. Energy saving potential of low temperature hot water system based on air source absorption heat pump. Applied Thermal Engineering, 2012, 48: 317–324 15.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2011.12.045) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Energy%20saving%20potential%20of%20low%20temperature%20hot%20water%20system%20based%20on%20air%20source%20absorption%20heat%20pump&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2011.12.045&volume=48&pages=317-324&publication_year=2012&author=Li%2CX&author=Wu%2CW&author=Zhang%2CX&author=Shi%2CW&author=Wang%2CB)

Abrahamsson K, Stenström S, Aly G, Jernqvist Å. Application of heat pump systems for energy conservation in paper drying. International Journal of Energy Research, 1997, 21(7): 631–642 16.

#### [Article](https://doi.org/10.1002%2F%28SICI%291099-114X%2819970610%2921%3A7%3C631%3A%3AAID-ER223%3E3.0.CO%3B2-W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Application%20of%20heat%20pump%20systems%20for%20energy%20conservation%20in%20paper%20drying&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2F%28SICI%291099-114X%2819970610%2921%3A7%3C631%3A%3AAID-ER223%3E3.0.CO%3B2-W&volume=21&issue=7&pages=631-642&publication_year=1997&author=Abrahamsson%2CK&author=Stenstr%C3%B6m%2CS&author=Aly%2CG%20J%20%C3%85)

Engler M, Grossman G, Hellmann H M. Comparative simulation and investigation of ammonia-water: absorption cycles for heat pump applications. International Journal of Refrigeration, 1997, 20 (7): 504–516 17.

#### [Article](https://doi.org/10.1016%2FS0140-7007%2897%2900038-8) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Comparative%20simulation%20and%20investigation%20of%20ammonia-water%3A%20absorption%20cycles%20for%20heat%20pump%20applications&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2FS0140-7007%2897%2900038-8&volume=20&issue=7&pages=504-516&publication_year=1997&author=Engler%2CM&author=Grossman%2CG&author=Hellmann%2CH%20M)

Jian S, Lin F, Zhang S. Performance calculation of single effect absorption heat pump using LiBr + LiNO + H O as working fluid. Applied Thermal Engineering, 2010, 30(17–18): 2680–2684 18. 3 2

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2010.07.018) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2643340) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20calculation%20of%20single%20effect%20absorption%20heat%20pump%20using%20LiBr%20%2B%20LiNO3%2B%20H2O%20as%20working%20fluid&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2010.07.018&volume=30&issue=17%E2%80%9318&pages=2680-2684&publication_year=2010&author=Jian%2CS&author=Lin%2CF&author=Zhang%2CS)

Qu M, Abdelaziz O, Yin H. New configurations of a heat recovery absorption heat pump integrated with a natural gas boiler for boiler efficiency improvement. Energy Conversion and Management, 2014, 87: 175–184 19.

Xu Z Y, Wang R Z. Absorption refrigeration cycles: categorized based on the cycle construction. International Journal of Refrigeration, 2016, 62: 114–136 20.

#### [Article](https://doi.org/10.1016%2Fj.ijrefrig.2015.10.007) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Absorption%20refrigeration%20cycles%3A%20categorized%20based%20on%20the%20cycle%20construction&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2Fj.ijrefrig.2015.10.007&volume=62&pages=114-136&publication_year=2016&author=Xu%2CZ%20Y&author=Wang%2CR%20Z)

Kang Y, Kunugi Y, Kashiwagi T. Review of advanced absorption cycles: performance improvement and temperature lift enhancement. International Journal of Refrigeration, 2000, 23(5): 388–401 21.

#### [Article](https://doi.org/10.1016%2FS0140-7007%2899%2900064-X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Review%20of%20advanced%20absorption%20cycles%3A%20performance%20improvement%20and%20temperature%20lift%20enhancement&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2FS0140-7007%2899%2900064-X&volume=23&issue=5&pages=388-401&publication_year=2000&author=Kang%2CY&author=Kunugi%2CY&author=Kashiwagi%2CT)

Alarcón-Padilla D C, García-Rodríguez L, Blanco-Gálvez J. Assessment of an absorption heat pump coupled to a multi-effect distillation unit within AQUASOL project. Desalination, 2007, 212 (1–3): 303–310 22.

#### [Article](https://doi.org/10.1016%2Fj.desal.2006.10.015) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Assessment%20of%20an%20absorption%20heat%20pump%20coupled%20to%20a%20multi-effect%20distillation%20unit%20within%20AQUASOL%20project&journal=Desalination&doi=10.1016%2Fj.desal.2006.10.015&volume=212&issue=1%E2%80%933&pages=303-310&publication_year=2007&author=Alarc%C3%B3n-Padilla%2CD%20C&author=Garc%C3%ADa-Rodr%C3%ADguez%2CL&author=Blanco-G%C3%A1lvez%2CJ)

Alarcón-Padilla D C, García-Rodríguez L, Blanco-Gálvez J. Experimental assessment of connection of an absorption heat pump to a multi-effect distillation unit. Desalination, 2010, 250(2): 500–505 23.

#### [Article](https://doi.org/10.1016%2Fj.desal.2009.06.056) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20assessment%20of%20connection%20of%20an%20absorption%20heat%20pump%20to%20a%20multi-effect%20distillation%20unit&journal=Desalination&doi=10.1016%2Fj.desal.2009.06.056&volume=250&issue=2&pages=500-505&publication_year=2010&author=Alarc%C3%B3n-Padilla%2CD%20C&author=Garc%C3%ADa-Rodr%C3%ADguez%2CL&author=Blanco-G%C3%A1lvez%2CJ)

Le Lostec B, Galanis N, Baribeault J, Millette J. Wood chip drying with an absorption heat pump. Energy, 2008, 33(3): 500–512 24.

#### [Article](https://doi.org/10.1016%2Fj.energy.2007.10.013) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Wood%20chip%20drying%20with%20an%20absorption%20heat%20pump&journal=Energy&doi=10.1016%2Fj.energy.2007.10.013&volume=33&issue=3&pages=500-512&publication_year=2008&author=Lostec%2CB&author=Galanis%2CN&author=Baribeault%2CJ&author=Millette%2CJ)

Garimella S, Christensen R N, Lacy D. Performance evaluation of a generatorabsorber heat-exchange heat pump. Applied Thermal Engineering, 1996, 16(7): 591– 604 25.

#### [Article](https://doi.org/10.1016%2F1359-4311%2895%2900041-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20evaluation%20of%20a%20generator-absorber%20heat-exchange%20heat%20pump&journal=Applied%20Thermal%20Engineering&doi=10.1016%2F1359-4311%2895%2900041-0&volume=16&issue=7&pages=591-604&publication_year=1996&author=Garimella%2CS&author=Christensen%2CR%20N&author=Lacy%2CD)

Kang Y T, Kashiwagi T. An environmentally friendly GAX cycle for panel heating: PGAX cycle. International Journal of Refrigeration, 2000, 23(5): 378–387 26.

Kang Y T, Hong H, Park K S. Performance analysis of advanced hybrid GAX cycles: HGAX. International Journal of Refrigeration, 2004, 27(4): 442–448 27.

#### [Article](https://doi.org/10.1016%2Fj.ijrefrig.2003.10.007) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20analysis%20of%20advanced%20hybrid%20GAX%20cycles%3A%20HGAX&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2Fj.ijrefrig.2003.10.007&volume=27&issue=4&pages=442-448&publication_year=2004&author=Kang%2CY%20T&author=Hong%2CH&author=Park%2CK%20S)

Phillips B. Development of a high-efficiency, gas-fired, absorption heat pump for residential and small-commercial applications. Oak Ridge National Lab., TN (USA); 1990 28.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Development%20of%20a%20high-efficiency%2C%20gas-fired%2C%20absorption%20heat%20pump%20for%20residential%20and%20small-commercial%20applications&publication_year=1990&author=Phillips%2CB)

Lazzarin R, Longo G, Piccininni F. An open cycle absorption heat pump. Heat Recovery Systems and CHP., 1992, 12(5): 391–396 29.

#### [Article](https://doi.org/10.1016%2F0890-4332%2892%2990060-U) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20open%20cycle%20absorption%20heat%20pump&journal=Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2892%2990060-U&volume=12&issue=5&pages=391-396&publication_year=1992&author=Lazzarin%2CR&author=Longo%2CG&author=Piccininni%2CF)

Westerlund L, Hermansson R, Fagerström J. Flue gas purification and heat recovery: a biomass fired boiler supplied with an open absorption system. Applied Energy, 2012, 96: 444–450 30.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2012.02.085) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Flue%20gas%20purification%20and%20heat%20recovery%3A%20a%20biomass%20fired%20boiler%20supplied%20with%20an%20open%20absorption%20system&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2012.02.085&volume=96&pages=444-450&publication_year=2012&author=Westerlund%2CL&author=Hermansson%2CR&author=Fagerstr%C3%B6m%2CJ)

Ye B, Liu J, Xu X, Chen G, Zheng J. A new open absorption heat pump for latent heat recovery from moist gas. Energy Conversion and Management, 2015, 94: 438–446 [Article](https://doi.org/10.1016%2Fj.enconman.2015.02.001) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20new%20open%20absorption%20heat%20pump%20for%20latent%20heat%20recovery%20from%20moist%20gas&journal=Energy%20Conversion%20and%20Management&doi=10.1016%2Fj.enconman.2015.02.001&volume=94&pages=438-446&publication_year=2015&author=Ye%2CB&author=Liu%2CJ&author=Xu%2CX&author=Chen%2CG&author=Zheng%2CJ) 31.

Romero R J, Rodríguez-Martínez A. Optimal water purification using low grade waste heat in an absorption heat transformer. Desalination, 2008, 220(1–3): 506–513 32.

#### [Article](https://doi.org/10.1016%2Fj.desal.2007.05.026) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optimal%20water%20purification%20using%20low%20grade%20waste%20heat%20in%20an%20absorption%20heat%20transformer&journal=Desalination&doi=10.1016%2Fj.desal.2007.05.026&volume=220&issue=1%E2%80%933&pages=506-513&publication_year=2008&author=Romero%2CR%20J&author=Rodr%C3%ADguez-Mart%C3%ADnez%2CA)

Rivera W, Cerezo J, Rivero R, Cervantes J, Best R. Single stage and double absorption heat transformers used to recover energy in a distillation column of butane and pentane. International Journal of Energy Research, 2003, 27(14): 1279–1292 33.

Mashimo K. Overview of heat transformers in Japan. Heat pumps: Prospects In Heat Pump Technology and Marking, 1987: 271–285 34.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Overview%20of%20heat%20transformers%20in%20Japan&pages=271-285&publication_year=1987&author=Mashimo%2CK)

- Riesch P, Scharfe J, Ziegler F, Volkl J, Alefeld G. Part load behaviour of an absorption heat transformer. Conference Part load behaviour of an absorption heat transformer, 155–160 35.
- Rivera W, Romero R, Best R, Heard C. Experimental evaluation of a single-stage heat transformer operating with the water/Carrol™ mixture. Energy, 1999, 24(4): 317– 326 36.

#### [Article](https://doi.org/10.1016%2FS0360-5442%2898%2900097-8) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20evaluation%20of%20a%20single-stage%20heat%20transformer%20operating%20with%20the%20water%2FCarrol%E2%84%A2%20mixture&journal=Energy&doi=10.1016%2FS0360-5442%2898%2900097-8&volume=24&issue=4&pages=317-326&publication_year=1999&author=Rivera%2CW&author=Romero%2CR&author=Best%2CR&author=Heard%2CC)

Ibarra-Bahena J, Romero R, Velazquez-Avelar L, Valdez-Morales C, Galindo-Luna Y. Experimental thermodynamic evaluation for a single stage heat transformer prototype build with commercial PHEs. Applied Thermal Engineering, 2015, 75: 1262–1270 37.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2014.05.018) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20thermodynamic%20evaluation%20for%20a%20single%20stage%20heat%20transformer%20prototype%20build%20with%20commercial%20PHEs&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2014.05.018&volume=75&pages=1262-1270&publication_year=2015&author=Ibarra-Bahena%2CJ&author=Romero%2CR&author=Velazquez-Avelar%2CL&author=Valdez-Morales%2CC&author=Galindo-Luna%2CY)

Ma X, Chen J, Li S, Sha Q, Liang A, Li W, Zhang J, Zheng G, Feng Z. Application of absorption heat transformer to recover waste heat from a synthetic rubber plant. Applied Thermal Engineering, 2003, 23(7): 797–806 38.

#### [Article](https://doi.org/10.1016%2FS1359-4311%2803%2900011-5) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Application%20of%20absorption%20heat%20transformer%20to%20recover%20waste%20heat%20from%20a%20synthetic%20rubber%20plant&journal=Applied%20Thermal%20Engineering&doi=10.1016%2FS1359-4311%2803%2900011-5&volume=23&issue=7&pages=797-806&publication_year=2003&author=Ma%2CX&author=Chen%2CJ&author=Li%2CS&author=Sha%2CQ&author=Liang%2CA&author=Li%2CW&author=Zhang%2CJ&author=Zheng%2CG&author=Feng%2CZ)

Sekar S, Saravanan R. Experimental studies on absorption heat transformer coupled distillation system. Desalination, 2011, 274 (1–3): 292–301 39.

#### [Article](https://doi.org/10.1016%2Fj.desal.2011.01.064) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20studies%20on%20absorption%20heat%20transformer%20coupled%20distillation%20system&journal=Desalination&doi=10.1016%2Fj.desal.2011.01.064&volume=274&issue=1%E2%80%933&pages=292-301&publication_year=2011&author=Sekar%2CS&author=Saravanan%2CR)

Abrahamsson K, Gidner A, Jernqvist Å. Design and experimental performance evaluation of an absorption heat transformer with selfcirculation. Heat Recovery Systems and CHP., 1995, 15(3): 257–272 40.

Hultén M, Berntsson T. The compression/absorption heat pump cycle—conceptual design improvements and comparisons with the compression cycle. International Journal of Refrigeration, 2002, 25 (4): 487–497 41.

#### [Article](https://doi.org/10.1016%2FS0140-7007%2802%2900014-2) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20compression%2Fabsorption%20heat%20pump%20cycle%E2%80%94conceptual%20design%20improvements%20and%20comparisons%20with%20the%20compression%20cycle&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2FS0140-7007%2802%2900014-2&volume=25&issue=4&pages=487-497&publication_year=2002&author=Hult%C3%A9n%2CM&author=Berntsson%2CT)

Tarique S M, Siddiqui MA. Performance and economic study of the combined absorption/compression heat pump. Energy Conversion and Management, 1999, 40(6): 575–591 42.

#### [Article](https://doi.org/10.1016%2FS0196-8904%2898%2900045-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20and%20economic%20study%20of%20the%20combined%20absorption%2Fcompression%20heat%20pump&journal=Energy%20Conversion%20and%20Management&doi=10.1016%2FS0196-8904%2898%2900045-4&volume=40&issue=6&pages=575-591&publication_year=1999&author=Tarique%2CS%20M&author=Siddiqui%2CMA)

Niang M, Cachot T, Le Goff P. Evaluation of the performance of an absorption– demixtion heat pump for upgrading thermal waste heat. Applied Thermal Engineering, 1998, 18(12): 1277–1294 43.

#### [Article](https://doi.org/10.1016%2FS1359-4311%2897%2900092-6) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Evaluation%20of%20the%20performance%20of%20an%20absorption%E2%80%93demixtion%20heat%20pump%20for%20upgrading%20thermal%20waste%20heat&journal=Applied%20Thermal%20Engineering&doi=10.1016%2FS1359-4311%2897%2900092-6&volume=18&issue=12&pages=1277-1294&publication_year=1998&author=Niang%2CM&author=Cachot%2CT%20L&author=Goff%2CP)

Alonso D, Cachot T, Hornut J M. Performance simulation of an absorption heat transformer operating with partially miscible mixtures. Applied Energy, 2002, 72(3–4): 583–597 44.

#### [Article](https://doi.org/10.1016%2FS0306-2619%2802%2900052-1) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20simulation%20of%20an%20absorption%20heat%20transformer%20operating%20with%20partially%20miscible%20mixtures&journal=Applied%20Energy&doi=10.1016%2FS0306-2619%2802%2900052-1&volume=72&issue=3%E2%80%934&pages=583-597&publication_year=2002&author=Alonso%2CD&author=Cachot%2CT&author=Hornut%2CJ%20M)

Privat R, Qian J W, Alonso D, Jaubert J N. Quest for an efficient binary working mixture for an absorption-demixing heat transformer. Energy, 2013, 55: 594–609 45.

#### [Article](https://doi.org/10.1016%2Fj.energy.2013.03.081) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Quest%20for%20an%20efficient%20binary%20working%20mixture%20for%20an%20absorption-demixing%20heat%20transformer&journal=Energy&doi=10.1016%2Fj.energy.2013.03.081&volume=55&pages=594-609&publication_year=2013&author=Privat%2CR&author=Qian%2CJ%20W&author=Alonso%2CD&author=Jaubert%2CJ%20N)

Alonso D, Cachot T, Hornut J M. Experimental study of an innovative absorption heat transformer using partially miscible working mixtures. International Journal of Thermal Sciences, 2003, 42(6): 631–638 46.

#### [Article](https://doi.org/10.1016%2FS1290-0729%2803%2900028-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20study%20of%20an%20innovative%20absorption%20heat%20transformer%20using%20partially%20miscible%20working%20mixtures&journal=International%20Journal%20of%20Thermal%20Sciences&doi=10.1016%2FS1290-0729%2803%2900028-0&volume=42&issue=6&pages=631-638&publication_year=2003&author=Alonso%2CD&author=Cachot%2CT&author=Hornut%2CJ%20M)

Romero R J, Martínez A R, Silva S, Cerezo J, Rivera W. Comparison of double stage heat transformer with double absorption heat transformer operating with Carrol– Water for industrial waste heat recovery. Chemical Engineering Transactions, 2011, 25: 129–134 47.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Comparison%20of%20double%20stage%20heat%20transformer%20with%20double%20absorption%20heat%20transformer%20operating%20with%20Carrol%E2%80%93Water%20for%20industrial%20waste%20heat%20recovery&journal=Chemical%20Engineering%20Transactions&volume=25&pages=129-134&publication_year=2011&author=Romero%2CR%20J&author=Mart%C3%ADnez%2CA%20R&author=Silva%2CS&author=Cerezo%2CJ&author=Rivera%2CW)

Ciambelli P, Tufano V. On the performance of advanced absorption heat transformers —I. The two stage configuration. Heat Recovery Systems and CHP., 1988, 8(5): 445– 450 48.

#### [Article](https://doi.org/10.1016%2F0890-4332%2888%2990049-X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20performance%20of%20advanced%20absorption%20heat%20transformers%E2%80%94I&journal=The%20two%20stage%20configuration.%20Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2888%2990049-X&volume=8&issue=5&pages=445-450&publication_year=1988&author=Ciambelli%2CP&author=Tufano%2CV)

Wang X, Shi L, Yin J, Zhu M S. A two-stage heat transformer with H O/LiBr for the first stage and 2,2,2-trifluoroethanol (TFE)/Nmethy1–2-pyrrolidone (NMP) for the second stage. Applied Energy, 2002, 71(3): 235–249 49. <sup>2</sup>

#### [Article](https://doi.org/10.1016%2FS0306-2619%2802%2900009-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20two-stage%20heat%20transformer%20with%20H2O%2FLiBr%20for%20the%20first%20stage%20and%202%2C2%2C2-trifluoroethanol%20%28TFE%29%2FNmethy1%E2%80%932-pyrrolidone%20%28NMP%29%20for%20the%20second%20stage&journal=Applied%20Energy&doi=10.1016%2FS0306-2619%2802%2900009-0&volume=71&issue=3&pages=235-249&publication_year=2002&author=Wang%2CX&author=Shi%2CL&author=Yin%2CJ&author=Zhu%2CM%20S)

Ji J, Ishida M. Behavior of a two-stage absorption heat transformer combining latent and sensible heat exchange modes. Applied Energy, 1999, 62(4): 267–281 50.

#### [Article](https://doi.org/10.1016%2FS0306-2619%2899%2900012-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Behavior%20of%20a%20two-stage%20absorption%20heat%20transformer%20combining%20latent%20and%20sensible%20heat%20exchange%20modes&journal=Applied%20Energy&doi=10.1016%2FS0306-2619%2899%2900012-4&volume=62&issue=4&pages=267-281&publication_year=1999&author=Ji%2CJ&author=Ishida%2CM)

Zhao Z, Ma Y, Chen J. Thermodynamic performance of a new type of double absorption heat transformer. Applied Thermal Engineering, 2003, 23(18): 2407–2414 [Article](https://doi.org/10.1016%2Fj.applthermaleng.2003.08.006) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20performance%20of%20a%20new%20type%20of%20double%20absorption%20heat%20transformer&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2003.08.006&volume=23&issue=18&pages=2407-2414&publication_year=2003&author=Zhao%2CZ&author=Ma%2CY&author=Chen%2CJ) 51.

Martínez H, Rivera W. Energy and exergy analysis of a double absorption heat transformer operating with water/lithium bromide. International Journal of Energy Research, 2009, 33(7): 662–674 52.

#### [Article](https://doi.org/10.1002%2Fer.1502) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Energy%20and%20exergy%20analysis%20of%20a%20double%20absorption%20heat%20transformer%20operating%20with%20water%2Flithium%20bromide&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2Fer.1502&volume=33&issue=7&pages=662-674&publication_year=2009&author=Mart%C3%ADnez%2CH&author=Rivera%2CW)

Saito K, Inoue N, Nakagawa Y, Fukusumi Y, Yamada H, Irie T. Experimental and numerical performance evaluation of double-lift absorption heat transformer. Science and Technology for the Built Environment, 2015, 21(3): 312–322 53.

#### [Article](https://doi.org/10.1080%2F23744731.2014.998937) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20and%20numerical%20performance%20evaluation%20of%20double-lift%20absorption%20heat%20transformer&journal=Science%20and%20Technology%20for%20the%20Built%20Environment&doi=10.1080%2F23744731.2014.998937&volume=21&issue=3&pages=312-322&publication_year=2015&author=Saito%2CK&author=Inoue%2CN&author=Nakagawa%2CY&author=Fukusumi%2CY&author=Yamada%2CH&author=Irie%2CT)

Barragán R R M, Arellano G V M, Heard C L. Performance study of a doubleabsorption water/calcium chloride heat transformer. International Journal of Energy Research, 1998, 22(9): 791–803 54.

Horuz I, Kurt B. Single stage and double absorption heat transformers in an industrial application. International Journal of Energy Research, 2009, 33(9): 787–798 55.

#### [Article](https://doi.org/10.1002%2Fer.1512) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Single%20stage%20and%20double%20absorption%20heat%20transformers%20in%20an%20industrial%20application&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2Fer.1512&volume=33&issue=9&pages=787-798&publication_year=2009&author=Horuz%2CI&author=Kurt%2CB)

Zhao Z, Zhang X, Ma X. Thermodynamic performance of a doubleeffect absorption heat-transformer using TFE/E181 as the working fluid. Applied Energy, 2005, 82(2): 107–116 56.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2004.10.012) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20performance%20of%20a%20doubleeffect%20absorption%20heat-transformer%20using%20TFE%2FE181%20as%20the%20working%20fluid&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2004.10.012&volume=82&issue=2&pages=107-116&publication_year=2005&author=Zhao%2CZ&author=Zhang%2CX&author=Ma%2CX)

Zhuo C, Machielsen C. Performance of high-temperature absorption heat transformers using Alkitrate as the working pair. Applied Thermal Engineering, 1996, 16(3): 255–262 57.

#### [Article](https://doi.org/10.1016%2F1359-4311%2895%2900069-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20of%20high-temperature%20absorption%20heat%20transformers%20using%20Alkitrate%20as%20the%20working%20pair&journal=Applied%20Thermal%20Engineering&doi=10.1016%2F1359-4311%2895%2900069-0&volume=16&issue=3&pages=255-262&publication_year=1996&author=Zhuo%2CC&author=Machielsen%2CC)

Donnellan P, Byrne E, Oliveira J, Cronin K. First and second law multidimensional analysis of a triple absorption heat transformer (TAHT). Applied Energy, 2014, 113: 141–151 58.

#### [Article](https://doi.org/10.1016%2Fj.apenergy.2013.06.049) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=First%20and%20second%20law%20multidimensional%20analysis%20of%20a%20triple%20absorption%20heat%20transformer%20%28TAHT%29&journal=Applied%20Energy&doi=10.1016%2Fj.apenergy.2013.06.049&volume=113&pages=141-151&publication_year=2014&author=Donnellan%2CP&author=Byrne%2CE&author=Oliveira%2CJ&author=Cronin%2CK)

Khamooshi M, Parham K, Egelioglu F, Yari M, Salati H. Simulation and optimization of novel configurations of triple absorption heat transformers integrated to a water desalination system. Desalination, 2014, 348: 39–48 59.

#### [Article](https://doi.org/10.1016%2Fj.desal.2014.06.006) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Simulation%20and%20optimization%20of%20novel%20configurations%20of%20triple%20absorption%20heat%20transformers%20integrated%20to%20a%20water%20desalination%20system&journal=Desalination&doi=10.1016%2Fj.desal.2014.06.006&volume=348&pages=39-48&publication_year=2014&author=Khamooshi%2CM&author=Parham%2CK&author=Egelioglu%2CF&author=Yari%2CM&author=Salati%2CH)

Rivera W, Cardoso M, Romero R. Theoretical comparison of single stage and advanced absorption heat transformers operating with water/lithium bromide and water/Carrol mixtures. International Journal of Energy Research, 1998, 22(5): 427– 442 60.

Best R, Rivera W, Cardoso M, Romero R, Holland F. Modelling of single-stage and advanced absorption heat transformers operating with the water/Carrol mixture. Applied Thermal Engineering, 1997, 17(11): 1111–1122 61.

[Article](https://doi.org/10.1016%2FS1359-4311%2896%2900090-7) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Modelling%20of%20single-stage%20and%20advanced%20absorption%20heat%20transformers%20operating%20with%20the%20water%2FCarrol%20mixture&journal=Applied%20Thermal%20Engineering&doi=10.1016%2FS1359-4311%2896%2900090-7&volume=17&issue=11&pages=1111-1122&publication_year=1997&author=Best%2CR&author=Rivera%2CW&author=Cardoso%2CM&author=Romero%2CR&author=Holland%2CF)

Rivera W, Martínez H, Cerezo J, Romero R, Cardoso M. Exergy analysis of an experimental single-stage heat transformer operating with single water/lithium bromide and using additives (1-octanol and 2-ethyl-1-hexanol). Applied Thermal Engineering, 2011, 31 (16): 3526–3532 62.

[Article](https://doi.org/10.1016%2Fj.applthermaleng.2011.07.006) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Exergy%20analysis%20of%20an%20experimental%20single-stage%20heat%20transformer%20operating%20with%20single%20water%2Flithium%20bromide%20and%20using%20additives%20%281-octanol%20and%202-ethyl-1-hexanol%29&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2011.07.006&volume=31&issue=16&pages=3526-3532&publication_year=2011&author=Rivera%2CW&author=Mart%C3%ADnez%2CH&author=Cerezo%2CJ&author=Romero%2CR&author=Cardoso%2CM)

Rivera W, Cerezo J. Experimental study of the use of additives in the performance of a single-stage heat transformer operating with water–lithium bromide. International Journal of Energy Research, 2005, 29(2): 121–130 63.

[Article](https://doi.org/10.1002%2Fer.1045) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20study%20of%20the%20use%20of%20additives%20in%20the%20performance%20of%20a%20single-stage%20heat%20transformer%20operating%20with%20water%E2%80%93lithium%20bromide&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2Fer.1045&volume=29&issue=2&pages=121-130&publication_year=2005&author=Rivera%2CW&author=Cerezo%2CJ)

Barragán R, Heard C, Arellano V, Best R, Holland F. Experimental performance of the water/calcium chloride system in a heat transformer. International Journal of Energy Research, 1996, 20 (8): 651–661 64.

[Article](https://doi.org/10.1002%2F%28SICI%291099-114X%28199608%2920%3A8%3C651%3A%3AAID-ER180%3E3.0.CO%3B2-U) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20performance%20of%20the%20water%2Fcalcium%20chloride%20system%20in%20a%20heat%20transformer&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2F%28SICI%291099-114X%28199608%2920%3A8%3C651%3A%3AAID-ER180%3E3.0.CO%3B2-U&volume=20&issue=8&pages=651-661&publication_year=1996&author=Barrag%C3%A1n%2CR&author=Heard%2CC&author=Arellano%2CV&author=Best%2CR&author=Holland%2CF)

Grover G, Devotta S, Holland F. Thermodynamic design data for absorption heat transformers—Part III. Operating on water-lithium chloride. Heat Recovery Systems and CHP., 1988, 8(5): 425–431 65.

[Article](https://doi.org/10.1016%2F0890-4332%2888%2990047-6) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20design%20data%20for%20absorption%20heat%20transformers%E2%80%94Part%20III&journal=Operating%20on%20water-lithium%20chloride.%20Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2888%2990047-6&volume=8&issue=5&pages=425-431&publication_year=1988&author=Grover%2CG&author=Devotta%2CS&author=Holland%2CF)

Reyes R M B, Gómez V M A, García-Gutiérrez A. Performance modelling of single and double absorption heat transformers. Current Applied Physics, 2010, 10(2): S244–S248 66.

Patil K, Chaudhari S, Katti S. Thermodynamic design data for absorption heat transformers—part III. Operating on water-lithium iodide. Heat Recovery Systems and CHP., 1991, 11(5): 361–369 67.

#### [Article](https://doi.org/10.1016%2F0890-4332%2891%2990004-N) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20design%20data%20for%20absorption%20heat%20transformers%E2%80%94part%20III&journal=Operating%20on%20water-lithium%20iodide.%20Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2891%2990004-N&volume=11&issue=5&pages=361-369&publication_year=1991&author=Patil%2CK&author=Chaudhari%2CS&author=Katti%2CS)

Patil H, Chaudhari S, Katti S. Thermodynamic design data for absorption heat pump systems operating on water-lithium iodide— part II. Heating. Heat Recovery Systems and CHP., 1991, 11 (5): 351–360 68.

#### [Article](https://doi.org/10.1016%2F0890-4332%2891%2990003-M) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20design%20data%20for%20absorption%20heat%20pump%20systems%20operating%20on%20water-lithium%20iodide%E2%80%94%20part%20II&journal=Heating.%20Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2891%2990003-M&volume=11&issue=5&pages=351-360&publication_year=1991&author=Patil%2CH&author=Chaudhari%2CS&author=Katti%2CS)

Bourouis M, Coronas A, Romero R, Siqueiros J. Purification of seawater using absorption heat transformers with water-(LiBr + LiI + LiNO3+ LiCl) and low temperature heat sources. Desalination, 2004, 166: 209–214 69.

#### [Article](https://doi.org/10.1016%2Fj.desal.2004.06.075) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Purification%20of%20seawater%20using%20absorption%20heat%20transformers%20with%20water-%28LiBr%20%2B%20LiI%20%2B%20LiNO3%2B%20LiCl%29%20and%20low%20temperature%20heat%20sources&journal=Desalination&doi=10.1016%2Fj.desal.2004.06.075&volume=166&pages=209-214&publication_year=2004&author=Bourouis%2CM&author=Coronas%2CA&author=Romero%2CR&author=Siqueiros%2CJ)

Barragan R, Arellano V, Heard C, Best R. Experimental performance of ternary solutions in an absorption heat transformer. International Journal of Energy Research, 1998, 22(1): 73–83 70.

#### [Article](https://doi.org/10.1002%2F%28SICI%291099-114X%28199801%2922%3A1%3C73%3A%3AAID-ER362%3E3.0.CO%3B2-R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20performance%20of%20ternary%20solutions%20in%20an%20absorption%20heat%20transformer&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2F%28SICI%291099-114X%28199801%2922%3A1%3C73%3A%3AAID-ER362%3E3.0.CO%3B2-R&volume=22&issue=1&pages=73-83&publication_year=1998&author=Barragan%2CR&author=Arellano%2CV&author=Heard%2CC&author=Best%2CR)

Ciambelli P, Tufano V. The upgrading of waste heat by means of water-sulphuric acid absorption heat transformers. Heat Recovery Systems and CHP., 1987, 7(6): 517– 524 71.

#### [Article](https://doi.org/10.1016%2F0890-4332%2887%2990060-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20upgrading%20of%20waste%20heat%20by%20means%20of%20water-sulphuric%20acid%20absorption%20heat%20transformers&journal=Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2887%2990060-3&volume=7&issue=6&pages=517-524&publication_year=1987&author=Ciambelli%2CP&author=Tufano%2CV)

Ciambelli P, Tufano V. On the performance of advanced absorption heat transformers —II. The double absorption configuration. Heat Recovery Systems and CHP., 1988, 8(5): 451–457 72.

#### [Article](https://doi.org/10.1016%2F0890-4332%2888%2990050-6) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20performance%20of%20advanced%20absorption%20heat%20transformers%E2%80%94II&journal=The%20double%20absorption%20configuration.%20Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2888%2990050-6&volume=8&issue=5&pages=451-457&publication_year=1988&author=Ciambelli%2CP&author=Tufano%2CV)

Stephan K, Schmitt M, Hebecker D, Bergmann T. Dynamics of a heat transformer working with the mixture NaOH H O. International Journal of Refrigeration, 1997, 20(7): 483–495 73. 2

Romero R, Rivera W, Gracia J, Best R. Theoretical comparison of performance of an absorption heat pump system for cooling and heating operating with an aqueous ternary hydroxide and water/ lithium bromide. Applied Thermal Engineering, 2001, 21(11): 1137–1147 74.

#### [Article](https://doi.org/10.1016%2FS1359-4311%2800%2900111-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Theoretical%20comparison%20of%20performance%20of%20an%20absorption%20heat%20pump%20system%20for%20cooling%20and%20heating%20operating%20with%20an%20aqueous%20ternary%20hydroxide%20and%20water%2F%20lithium%20bromide&journal=Applied%20Thermal%20Engineering&doi=10.1016%2FS1359-4311%2800%2900111-3&volume=21&issue=11&pages=1137-1147&publication_year=2001&author=Romero%2CR&author=Rivera%2CW&author=Gracia%2CJ&author=Best%2CR)

Kurem E, Horuz I. A comparison between ammonia-water and water-lithium bromide solutions in absorption heat transformers. International Communications in Heat and Mass Transfer, 2001, 28 (3): 427–438 75.

#### [Article](https://doi.org/10.1016%2FS0735-1933%2801%2900247-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20comparison%20between%20ammonia-water%20and%20water-lithium%20bromide%20solutions%20in%20absorption%20heat%20transformers&journal=International%20Communications%20in%20Heat%20and%20Mass%20Transfer&doi=10.1016%2FS0735-1933%2801%2900247-0&volume=28&issue=3&pages=427-438&publication_year=2001&author=Kurem%2CE&author=Horuz%2CI)

Mclinden M, Radermacher R. An experimental comparison of ammonia–water and ammonia–water–lithium bromide mixtures in an absorption heat pump. ASHRAE Technical Data Bulletin and ASHRAE Transactions, 1985, 91(2B): 1837–1846 76.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20experimental%20comparison%20of%20ammonia%E2%80%93water%20and%20ammonia%E2%80%93water%E2%80%93lithium%20bromide%20mixtures%20in%20an%20absorption%20heat%20pump&journal=ASHRAE%20Technical%20Data%20Bulletin%20and%20ASHRAE%20Transactions&volume=91&issue=2B&pages=1837-1846&publication_year=1985&author=Mclinden%2CM&author=Radermacher%2CR)

Cacciola G, Restuccia G, Rizzo G. Theoretical performance of an absorption heat pump using ammonia-water-potassium hydroxide solution. Heat Recovery Systems and CHP, 1990, 10(3): 177–185 77.

#### [Article](https://doi.org/10.1016%2F0890-4332%2890%2990001-Z) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Theoretical%20performance%20of%20an%20absorption%20heat%20pump%20using%20ammonia-water-potassium%20hydroxide%20solution&journal=Heat%20Recovery%20Systems%20and%20CHP&doi=10.1016%2F0890-4332%2890%2990001-Z&volume=10&issue=3&pages=177-185&publication_year=1990&author=Cacciola%2CG&author=Restuccia%2CG&author=Rizzo%2CG)

Wu W, Zhang X, Li X, Shi W, Wang B. Comparisons of different working pairs and cycles on the performance of absorption heat pump for heating and domestic hot water in cold regions. Applied Thermal Engineering, 2012, 48: 349–358 78.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2012.04.047) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Comparisons%20of%20different%20working%20pairs%20and%20cycles%20on%20the%20performance%20of%20absorption%20heat%20pump%20for%20heating%20and%20domestic%20hot%20water%20in%20cold%20regions&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2012.04.047&volume=48&pages=349-358&publication_year=2012&author=Wu%2CW&author=Zhang%2CX&author=Li%2CX&author=Shi%2CW&author=Wang%2CB)

Genssle A, Stephan K. Analysis of the process characteristics of an absorption heat transformer with compact heat exchangers and the mixture TFE–E181. International Journal of Thermal Sciences, 2000, 39(1): 30–38 79.

Zhang X, Hu D. Performance analysis of the single-stage absorption heat transformer using a new working pair composed of ionic liquid and water. Applied Thermal Engineering, 2012, 37: 129–135 80.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2011.11.006) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20analysis%20of%20the%20single-stage%20absorption%20heat%20transformer%20using%20a%20new%20working%20pair%20composed%20of%20ionic%20liquid%20and%20water&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2011.11.006&volume=37&pages=129-135&publication_year=2012&author=Zhang%2CX&author=Hu%2CD)

Coronas A, Vallés M, Chaudhari S K, Patil K R. Absorption heat pump with the TFE-TEGDME and TFE-H O-TEGDME systems. Applied Thermal Engineering, 1996, 16(4): 335–345 81. 2

#### [Article](https://doi.org/10.1016%2F1359-4311%2895%2900007-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Absorption%20heat%20pump%20with%20the%20TFE-TEGDME%20and%20TFE-H2O-TEGDME%20systems&journal=Applied%20Thermal%20Engineering&doi=10.1016%2F1359-4311%2895%2900007-0&volume=16&issue=4&pages=335-345&publication_year=1996&author=Coronas%2CA&author=Vall%C3%A9s%2CM&author=Chaudhari%2CS%20K&author=Patil%2CK%20R)

Zhuo C, Machielsen C. Thermodynamic assessment of an absorption heat transformer with TFE-Pyr as the working pair. Heat Recovery Systems and CHP., 1994, 14(3): 265–272 82.

#### [Article](https://doi.org/10.1016%2F0890-4332%2894%2990021-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermodynamic%20assessment%20of%20an%20absorption%20heat%20transformer%20with%20TFE-Pyr%20as%20the%20working%20pair&journal=Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2894%2990021-3&volume=14&issue=3&pages=265-272&publication_year=1994&author=Zhuo%2CC&author=Machielsen%2CC)

Zhuo C, Machielsen C. Thermophysical properties of the trifluoroethanol-pyrrolidone system for absorption heat transformers. International Journal of Refrigeration, 1993, 16(5): 357–363 83.

#### [Article](https://doi.org/10.1016%2F0140-7007%2893%2990009-W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Thermophysical%20properties%20of%20the%20trifluoroethanol-pyrrolidone%20system%20for%20absorption%20heat%20transformers&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2F0140-7007%2893%2990009-W&volume=16&issue=5&pages=357-363&publication_year=1993&author=Zhuo%2CC&author=Machielsen%2CC)

Yin J, Shi L, Zhu M S, Han L Z. Performance analysis of an absorption heat transformer with different working fluid combinations. Applied Energy, 2000, 67(3): 281–292 84.

#### [Article](https://doi.org/10.1016%2FS0306-2619%2800%2900024-6) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20analysis%20of%20an%20absorption%20heat%20transformer%20with%20different%20working%20fluid%20combinations&journal=Applied%20Energy&doi=10.1016%2FS0306-2619%2800%2900024-6&volume=67&issue=3&pages=281-292&publication_year=2000&author=Yin%2CJ&author=Shi%2CL&author=Zhu%2CM%20S&author=Han%2CL%20Z)

Iyoki S, Tanaka K, Uemura T. Theoretical performance analysis of absorption refrigerating machine, absorption heat pump and absorption heat transformer using alcohol as working medium. International Journal of Refrigeration, 1994, 17(3): 180– 190 85.

Kripalani V, Murthy S S, Murthy M K. Performance analysis of a vapour absorption heat transformer with different working fluid combinations. Journal of heat recovery systems, 1984, 4(3): 129–140 86.

#### [Article](https://doi.org/10.1016%2F0198-7593%2884%2990001-8) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20analysis%20of%20a%20vapour%20absorption%20heat%20transformer%20with%20different%20working%20fluid%20combinations&journal=Journal%20of%20heat%20recovery%20systems&doi=10.1016%2F0198-7593%2884%2990001-8&volume=4&issue=3&pages=129-140&publication_year=1984&author=Kripalani%2CV&author=Murthy%2CS%20S&author=Murthy%2CM%20K)

Ando E, Takeshita I. Residential gas-fired absorption heat pump based on R 22- DEGDME pair. Part 1 thermodynamic properties of the R 22-DEGDME pair. International Journal of Refrigeration, 1984, 7(3): 181–185 87.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Residential%20gas-fired%20absorption%20heat%20pump%20based%20on%20R%2022-DEGDME%20pair&journal=Part%201%20thermodynamic%20properties%20of%20the%20R%2022-DEGDME%20pair.%20International%20Journal%20of%20Refrigeration&volume=7&issue=3&pages=181-185&publication_year=1984&author=Ando%2CE&author=Takeshita%2CI)

Borde I, Jelinek M, Daltrophe N. Working fluids for an absorption system based on R124 (2-chloro-1, 1, 1, 2,-tetrafluoroethane) and organic absorbents. International Journal of Refrigeration, 1997, 20 (4): 256–266 88.

#### [Article](https://doi.org/10.1016%2FS0140-7007%2897%2900090-X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Working%20fluids%20for%20an%20absorption%20system%20based%20on%20R124%20%282-chloro-1%2C%201%2C%201%2C%202%2C-tetrafluoroethane%29%20and%20organic%20absorbents&journal=International%20Journal%20of%20Refrigeration&doi=10.1016%2FS0140-7007%2897%2900090-X&volume=20&issue=4&pages=256-266&publication_year=1997&author=Borde%2CI&author=Jelinek%2CM&author=Daltrophe%2CN)

Han X H, Xu Y J, Gao Z J, Wang Q, Chen G M. Vapor–liquid equilibrium study of an absorption heat transformer working fluid of (HFC-32 + DMF). Journal of Chemical & Engineering Data, 2011, 56(4): 1268–1272 89.

#### [Article](https://doi.org/10.1021%2Fje1011295) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Vapor%E2%80%93liquid%20equilibrium%20study%20of%20an%20absorption%20heat%20transformer%20working%20fluid%20of%20%28HFC-32%20%2B%20DMF%29&journal=Journal%20of%20Chemical%20%26%20Engineering%20Data&doi=10.1021%2Fje1011295&volume=56&issue=4&pages=1268-1272&publication_year=2011&author=Han%2CX%20H&author=Xu%2CY%20J&author=Gao%2CZ%20J&author=Wang%2CQ&author=Chen%2CG%20M)

Jelinek M, Borde I. Single-and double-stage absorption cycles based on fluorocarbon refrigerants and organic absorbents. Applied Thermal Engineering, 1998, 18(9–10): 765–771 90.

#### [Article](https://doi.org/10.1016%2FS1359-4311%2897%2900114-2) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Single-and%20double-stage%20absorption%20cycles%20based%20on%20fluorocarbon%20refrigerants%20and%20organic%20absorbents&journal=Applied%20Thermal%20Engineering&doi=10.1016%2FS1359-4311%2897%2900114-2&volume=18&issue=9%E2%80%9310&pages=765-771&publication_year=1998&author=Jelinek%2CM&author=Borde%2CI)

Keil C, Plura S, Radspieler M, Schweigler C. Application of customized absorption heat pumps for utilization of low-grade heat sources. Applied Thermal Engineering, 2008, 28(16): 2070–2076 91.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2008.04.012) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Application%20of%20customized%20absorption%20heat%20pumps%20for%20utilization%20of%20low-grade%20heat%20sources&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2008.04.012&volume=28&issue=16&pages=2070-2076&publication_year=2008&author=Keil%2CC&author=Plura%2CS&author=Radspieler%2CM&author=Schweigler%2CC)

Costa A, Bakhtiari B, Schuster S, Paris J. Integration of absorption heat pumps in a Kraft pulp process for enhanced energy efficiency. Energy, 2009, 34(3): 254–260 92.

Cortés E, Rivera W. Exergetic and exergoeconomic optimization of a cogeneration pulp and paper mill plant including the use of a heat transformer. Energy, 2010, 35(3): 1289–1299 93.

#### [Article](https://doi.org/10.1016%2Fj.energy.2009.11.011) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Exergetic%20and%20exergoeconomic%20optimization%20of%20a%20cogeneration%20pulp%20and%20paper%20mill%20plant%20including%20the%20use%20of%20a%20heat%20transformer&journal=Energy&doi=10.1016%2Fj.energy.2009.11.011&volume=35&issue=3&pages=1289-1299&publication_year=2010&author=Cort%C3%A9s%2CE&author=Rivera%2CW)

Zhang X, Hu D, Li Z. Performance analysis on a new multi-effect distillation combined with an open absorption heat transformer driven by waste heat. Applied Thermal Engineering, 2014, 62(1): 239–244 94.

#### [Article](https://doi.org/10.1016%2Fj.applthermaleng.2013.09.015) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Performance%20analysis%20on%20a%20new%20multi-effect%20distillation%20combined%20with%20an%20open%20absorption%20heat%20transformer%20driven%20by%20waste%20heat&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2013.09.015&volume=62&issue=1&pages=239-244&publication_year=2014&author=Zhang%2CX&author=Hu%2CD&author=Li%2CZ)

Aly G, Abrahamsson K, Jernqvist Å. Application of absorption heat transformers for energy conservation in the oleochemical industry. International Journal of Energy Research, 1993, 17(7): 571–582 95.

#### [Article](https://doi.org/10.1002%2Fer.4440170703) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Application%20of%20absorption%20heat%20transformers%20for%20energy%20conservation%20in%20the%20oleochemical%20industry&journal=International%20Journal%20of%20Energy%20Research&doi=10.1002%2Fer.4440170703&volume=17&issue=7&pages=571-582&publication_year=1993&author=Aly%2CG&author=Abrahamsson%2CK%20J%20%C3%85)

Currie J, Pritchard C. Energy recovery and plume reduction from an industrial spray drying unit using an absorption heat transformer. Heat Recovery Systems and CHP., 1994, 14(3): 239–248 96.

#### [Article](https://doi.org/10.1016%2F0890-4332%2894%2990019-1) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Energy%20recovery%20and%20plume%20reduction%20from%20an%20industrial%20spray%20drying%20unit%20using%20an%20absorption%20heat%20transformer&journal=Heat%20Recovery%20Systems%20and%20CHP.&doi=10.1016%2F0890-4332%2894%2990019-1&volume=14&issue=3&pages=239-248&publication_year=1994&author=Currie%2CJ&author=Pritchard%2CC)

Horuz I, Kurt B. Absorption heat transformers and an industrial application. Renewable Energy, 2010, 35(10): 2175–2181 97.

#### [Article](https://doi.org/10.1016%2Fj.renene.2010.02.025) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Absorption%20heat%20transformers%20and%20an%20industrial%20application&journal=Renewable%20Energy&doi=10.1016%2Fj.renene.2010.02.025&volume=35&issue=10&pages=2175-2181&publication_year=2010&author=Horuz%2CI&author=Kurt%2CB)

Zhang K, Liu Z, Li Y, Li Q, Zhang J, Liu H. The improved CO capture system with heat recovery based on absorption heat transformer and flash evaporator. Applied Thermal Engineering, 2014, 62(2): 500–506 98. 2

[Article](https://doi.org/10.1016%2Fj.applthermaleng.2013.10.007) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20improved%20CO2%20capture%20system%20with%20heat%20recovery%20based%20on%20absorption%20heat%20transformer%20and%20flash%20evaporator&journal=Applied%20Thermal%20Engineering&doi=10.1016%2Fj.applthermaleng.2013.10.007&volume=62&issue=2&pages=500-506&publication_year=2014&author=Zhang%2CK&author=Liu%2CZ&author=Li%2CY&author=Li%2CQ&author=Zhang%2CJ&author=Liu%2CH)

#### [Download references](https://citation-needed.springer.com/v2/references/10.1007/s11708-017-0507-1?format=refman&flavour=references)

### **Acknowledgments**

This research is supported by National Key Research and Development Program (Grant No. 2016YFB0601200). The support from the Foundation for Innovative Research Groups of the National Natural Science Foundation of China (Grant No. 51521004) is also appreciated.

## **Author information**

#### **Authors and Affiliations**

<span id="page-19-1"></span>Institute of Refrigeration and Cryogenics, Shanghai Jiao Tong University, Shanghai, 200240, China 1.

Zhenyuan Xu & Ruzhu Wang

#### Authors

<span id="page-19-0"></span>Zhenyuan Xu 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Zhenyuan%20Xu)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Zhenyuan%20Xu) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Zhenyuan%20Xu%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-19-2"></span>Ruzhu Wang 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Ruzhu%20Wang)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Ruzhu%20Wang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Ruzhu%20Wang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

### **Corresponding author**

Correspondence to [Ruzhu Wang](mailto:rzwang@sjtu.edu.cn).

### **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Absorption%20heat%20pump%20for%20waste%20heat%20reuse%3A%20current%20states%20and%20future%20development&author=Zhenyuan%20Xu%20et%20al&contentID=10.1007%2Fs11708-017-0507-1©right=Higher%20Education%20Press%20and%20Springer-Verlag%20GmbH%20Germany&publication=2095-1701&publicationDate=2017-11-15&publisherName=SpringerNature&orderBeanReset=true)

## **About this article**

![](_page_20_Picture_1.jpeg)

### <span id="page-20-0"></span>**Cite this article**

Xu, Z., Wang, R. Absorption heat pump for waste heat reuse: current states and future development. *Front. Energy* **11**, 414–436 (2017). https://doi.org/10.1007/ s11708-017-0507-1

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s11708-017-0507-1?format=refman&flavour=citation)

Received: 27 July 2017 •

Accepted: 20 September 2017 •

Published: 15 November 2017 •

Issue date: December 2017 •

DOI: https://doi.org/10.1007/s11708-017-0507-1 •

### **Keywords**

- [absorption](file:///search?query=absorption&facet-discipline=%22Energy%22) •
- [heat pump](file:///search?query=heat%20pump&facet-discipline=%22Energy%22) •
- [heat transformer](file:///search?query=heat%20transformer&facet-discipline=%22Energy%22) •
- [waste heat](file:///search?query=waste%20heat&facet-discipline=%22Energy%22) •
- [working pair](file:///search?query=working%20pair&facet-discipline=%22Energy%22) •

### **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11708-017-0507-1)

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

#### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11708-017-0507-1                                                                                                        |
| 2095-1698                                                                                                                        |
| Absorption heat pump for waste heat reuse: current states and future development                                                 |
| 2017                                                                                                                             |
| 2017                                                                                                                             |
| Zhenyuan Xu, Ruzhu Wang                                                                                                          |
| Frontiers in Energy                                                                                                              |
| 74877ceca89ef9d913edff88f3ffebc38f5de6e2258368061ec6c8d0246b1eb48de0bdda9b6abad961b3c3274c057160c04aa26cad51034c262a0f3d7e8f48a1 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

Advertisement

### <span id="page-22-1"></span>**Search**

| Search by keyword or author |  |  |  |
|-----------------------------|--|--|--|
|                             |  |  |  |
|                             |  |  |  |
|                             |  |  |  |

Search

### <span id="page-22-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature