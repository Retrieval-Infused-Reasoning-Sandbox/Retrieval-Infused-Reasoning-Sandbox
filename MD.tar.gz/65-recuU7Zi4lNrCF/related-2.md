Contents lists available at [ScienceDirect](www.sciencedirect.com/science/journal/13594311)

# Applied Thermal Engineering

journal homepage: [www.elsevier.com/locate/apthermeng](https://www.elsevier.com/locate/apthermeng)

![](_page_0_Picture_5.jpeg)

![](_page_0_Picture_6.jpeg)

# Hybrid absorption-compression heat pump with two-stage rectification and subcooler

Peng Gao a,b,\* , Chun Qing <sup>b</sup> , Meng-Meng Chang <sup>b</sup> , Liang-Liang Shao <sup>b</sup> , Chun-Lu Zhang <sup>b</sup>

- <sup>a</sup> *Institute of Refrigeration and Cryogenics, School of Energy and Power Engineering, University of Shanghai for Science and Technology, Shanghai 200093, China*
- <sup>b</sup> *Institute of Refrigeration and Cryogenics, School of Mechanical Engineering, Tongji University, Shanghai 201804, China*

#### ARTICLE INFO

*Keywords:*  Hybrid absorption-compression heat pump Two-stage rectification Subcooler High temperature heating Thermodynamic analysis

#### ABSTRACT

Conventional hybrid absorption-compression heat pumps are difficult to efficiently upgrade waste heat to a heating temperature of above 90 ◦C. In this paper, to solve this problem, two novel approaches, namely a twostage rectification and a subcooler, are specially proposed for the hybrid heat pump. By designing a two-stage rectification to reduce the suction temperature of compressor, thereby lowering its discharge temperature, commercially available normal-temperature compressors can be employed in the hybrid heat pump for hightemperature heating. By utilizing a subcooler proposed to reduce the irreversible loss during the throttling process, the energy efficiency of the hybrid heat pump is improved. Moreover, the hybrid heat pump with multistage subcoolers is also proposed and analyzed. Thermodynamic analysis exhibits that, at a heating temperature of 120 ◦C and a solution heat exchanger effectiveness of 0.8, the hybrid heat pump with a two-stage rectification and a subcooler brings about an energy efficiency improvement of 17.4% in comparison to the conventional one.

# **1. Introduction**

There is a large demand for high-temperature heating in industry [\[1\]](#page-8-0)  and agriculture [\[2\].](#page-8-0) Currently, high-temperature heating is mainly generated from the direct combustion of coal, natural gas or oil, even electrical heating. Consequently, the development of clean and efficient technologies has become extremely urgent. The heat pump is regarded as a clean and efficient heating technology. If the heat pump can be employed for the high-temperature heating by recovering waste heat, it will be quite beneficial [\[3\]](#page-8-0). Vapor compression heat pump (VCHP) [\[4,5\]](#page-8-0)  and absorption heat pump [\[6,7\]](#page-8-0) are quite mature heating technologies.

VCHPs are widely applied in the middle and low temperature heating for hot water and space heating [\[8\]](#page-8-0). For a heating temperature of above 90 ◦C, VCHP can hardly meet practical needs. To provide hightemperature heat, its condensing temperature needs to be raised to match the heating temperature. As a result, the large pressure ratio and high discharge temperature of compressor certainly will result in a low cycle efficiency, and even worse, conventional compressors aren't utilized [\[9\]](#page-8-0). Additionally, although the VCHP using water as the refrigerant could upgrade 85 ◦C-95 ◦C waste heat to a heating temperature of 130 ◦C, the compressor needed to be specially designed and

manufactured [\[10\].](#page-8-0)

For the absorption heat transformer, environmentally friendly working pairs such as NH3/H2O are employed, and industrial waste heat is utilized as the driving heat source [\[11\]](#page-8-0). The absorption heat transformer can upgrade industrial waste heat to a heating temperature of 100–150 ◦C, but the required driving heat source temperature is above 80 ◦C [\[12,13\]](#page-8-0) and restricts its application range.

To take advantages of the vapor compression heat pump and absorption heat transformer, the hybrid absorption-compression heat pump (HACHP) was proposed [\[14\],](#page-8-0) as exhibited in [Fig. 1](#page-1-0), and it has three advantages:

- 1) Compared with the absorption heat transformer, the HACHP can be driven by a lower temperature heat source, which is due to that the generation pressure is reduced by the compression process.
- 2) Thanks to the temperature glide of solution during the phase change [\[15\]](#page-8-0), the solution temperature in the generator/absorber can be matched with that of heat source / heat sink. Therefore, the irreversible loss during the heat transfer process decreases.
- 3) A mixture of refrigerant and absorbent with a large difference in the boiling points is employed as the working fluid, and the heat is obtained from the mixture of refrigerant vapor and absorbent in the

*E-mail address:* [1059781237@qq.com](mailto:1059781237@qq.com) (P. Gao).

1359-4311/© 2020 Elsevier Ltd. All rights reserved.

<sup>\*</sup> Corresponding author at: Institute of Refrigeration and Cryogenics, School of Energy and Power Engineering, University of Shanghai for Science and Technology, Shanghai 200093, China.

<span id="page-1-0"></span>

| Nomenclature                     |                                                                                                                                                                                   | gen<br>generator<br>inter<br>intermediate                                                                                                                                                                              |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| h<br>m<br>p                      | enthalpy, kJ/kg<br>mass flowrate, kg/s<br>pressure, MPa                                                                                                                           | main<br>main cycle<br>opt<br>optimum<br>pump<br>solution pump                                                                                                                                                          |
| q<br>Q                           | vapor mass fraction, kg/kg<br>heat, kW                                                                                                                                            | s<br>isentropic<br>sub<br>sub-cycle                                                                                                                                                                                    |
| T<br>v<br>W<br>x<br>η<br>ε<br>ΔT | temperature, o<br>C<br>specific volume, m3<br>/kg<br>power, kW<br>ammonia mass fraction, kg/kg<br>efficiency<br>effectiveness of heat exchanger<br>temperature difference, o<br>C | Abbreviations<br>Comp<br>compressor<br>COP<br>coefficient of performance<br>EV<br>expansion valve<br>HACHP<br>hybrid absorption-compression heat pump<br>HTF<br>high-temperature fluid<br>LTF<br>low-temperature fluid |
| Subscripts<br>abs<br>comp        | absorber<br>compressor                                                                                                                                                            | SHX<br>solution heat exchanger<br>VCHP<br>vapor-compression heat pump                                                                                                                                                  |

![](_page_1_Figure_3.jpeg)

**Fig. 1.** Schematic of the hybrid absorption-compression heat pump cycle.

absorber [\[16\]](#page-8-0). At the same heating temperature, the saturation pressure of solution is much lower than that of pure refrigerant, so the discharge pressure of compressor is significantly lowered [\[17\].](#page-8-0)

As a result, the HACHP cycle shown in Fig. 1 should be an efficient approach for high-temperature heating [\[18\].](#page-8-0) However, the maximum heating temperature of most hybrid heat pumps is below 90 ◦C. Kabelac et al. [\[19\]](#page-8-0) built an experimental system of NH3/H2O HACHP, and their results showed the maximum heating temperature was 80 ◦C and the heating COP (coefficient of performance) was 2.5 at a heat source temperature of 59 ◦C. Jung et al. [\[20\]](#page-8-0) also established a NH3/H2O HACHP system and the maximum outlet temperature of hot water was 80.7 ◦C.

Although some research indicated that the heating temperature of HACHP could reach 129 ◦C, but the ammonia compressor that could withstand a high discharge temperature of 160 ◦C should be specially designed and manufactured [\[21\]](#page-8-0). Therefore, the discharge temperature of compressor is a crucial limiting factor for the HACHP to obtain a high heating temperature.

One promising solution to reduce the discharge temperature of compressor is to employ the multi-stage compression with intercooling [\[22\]](#page-8-0). Kim et al.[\[23\]](#page-8-0) established a NH3/H2O HACHP system utilizing the two-stage compression with intercooling, and experimental results showed that the maximum outlet temperature of hot water was 90 ◦C at a heat source temperature of 50 ◦C.

Another method is to cool the suction vapor of compressor, especially for the heat pump utilizing ammonia as the refrigerant, because ammonia has a higher adiabatic exponent in comparison to other refrigerants. However, currently, for the HACHP, there is almost no research about the method for the reduction of compressor suction temperature. Additionally, although the solution heat exchanger is utilized to lower the solution temperature before the expansion valve, as presented in Fig. 1, it is still quite high even if the effectiveness of solution heat exchanger is 1, which will bring about a relatively large throttling loss. This is because there is a large difference in the mass flow rates between the two sides of solution heat exchanger.

In this paper, to solve these problems, we put forward the utilization of the two-stage rectification and subcooler in the HACHP cycle for the first time. A two-stage rectification is proposed for reducing the suction temperature of compressor, and a subcooler is utilized for lowering the solution temperature before the expansion valve. With these methods, heating temperatures of above 90 ◦C can be achieved in the HACHP cycle with a high efficiency. Under different operating conditions, the performance of the modified HACHP cycle is evaluated numerically. Additionally, the performance comparison between the modified and conventional cycles is also performed.

## **2. Principles of HACHP**

## *2.1. Conventional HACHP*

Before performance improvement methods are explained in detail, the performance analysis of the conventional HACHP cycle is conducted, and ammonia-water solution is chosen as the working fluid, which is due to that ammonia has excellent thermodynamic properties and rich experience has been gained in practical applications [\[24,25\]](#page-8-0). Its working principles are detailed as follows:

- 1) Generation process. The ammonia-water solution absorbs heat from the low-temperature fluid (LTF), and the vapor, which is rich in ammonia but still contains some water, is gradually separated from the ammonia-water solution. In this process, the ammonia-water solution concentration changes from strong to weak. After that, the compressor carries away the vapor from the generator and the solution pump takes away the weak solution.
- 2) Vapor compression and liquid pressurization processes. The vapor is compressed by compressor, and at the same time, the weak solution from the generator is pressurized by the solution pump. Finally, the vapor and weak solution reunite in the absorber.
- 3) Absorption process. In the absorber, the high-pressure vapor is gradually absorbed by the weak solution, and the absorption heat is released and transferred to the high-temperature fluid (HTF). After

**Table 1**  Thermodynamic parameters during the compression process using ammonia as the refrigerant.

| Parameters                           | HACHP | VCHP  |  |
|--------------------------------------|-------|-------|--|
| Discharge pressure of compressor/MPa | 2.03  | 9.51  |  |
| Suction pressure of compressor/MPa   | 0.34  | 2.47  |  |
| Discharge temperature/o<br>C         | 276.6 | 201.3 |  |
| Compression work (kJ/kg)             | 493.0 | 284.3 |  |
| Exergy destruction (kJ/kg)           | 86.1  | 55.9  |  |

Note: a). The mean heat transfer temperature difference in the absorber and generator is assumed to be 6 ◦C;

- b). Temperature ranges of HTF and LTF in the absorber and generator are 10 ◦C;
- c). The isentropic efficiency of compressor is 0.7;
- d). Exergy destruction during the compression process = *T*0 (*s*2 − *s*1), and *T*0 = 303.15 K.

**Table 2**  Thermodynamic parameters during the throttling process.

| Effectiveness of<br>SHX | Solution temperature before<br>EV/o<br>C | Exergy destruction of EV<br>(kJ/kg) |
|-------------------------|------------------------------------------|-------------------------------------|
| 1.0                     | 74.3                                     | 5.0                                 |
| 0.9                     | 78.1                                     | 6.2                                 |
| 0.8                     | 82.0                                     | 7.4                                 |
| 0.7                     | 86.0                                     | 9.2                                 |
| 0.6                     | 90.2                                     | 11.1                                |
| 0.5                     | 94.5                                     | 13.3                                |

Note: Exergy destruction during the throttling process = *T*0 (*s*6 - *s*5).

that, the strong solution flows to the generator via the solution heat exchanger and the expansion valve.

Table 1 exhibits thermodynamic parameters of compression process at a heat source temperature of 70 ◦C and a heating temperature of 120 ◦C. The strong solution concentration is 0.4, and the concentration difference between the weak and strong solutions is 0.1.

Compared with the VCHP cycle using ammonia as the refrigerant, although the discharge and suction pressures of compressor in the HACHP cycle are significantly reduced, as demonstrated in Table 1, a higher discharge temperature and a larger irreversible loss during the compression process are obtained. Conventional ammonia compressors can hardly withstand such a high discharge temperature, so they still cannot be utilized for high-temperature heating.

From Table 1, it is found that the suction pressure of compressor in the HACHP cycle decreases to 0.34 MPa, and according to the REFPROP [\[26\]](#page-9-0), the saturation temperature of pure ammonia is − 5.3 ◦C at this pressure. As mentioned previously, the suction temperature of compressor in the HACHP cycle is equal to the temperature of the weak solution leaving the generator, about 64.4 ◦C. Therefore, the suction vapor of compressor can be sufficiently cooled to lower its discharge temperature, which is completely different from the conventional vapor compression cycle. It should be noted that a small amount of condensed liquid is generated during the cooling process, and the mass fraction of ammonia in the suction vapor further increases.

Furthermore, although the solution heat exchanger (SHX) is utilized to reduce the solution temperature before the expansion valve (EV), it is still higher than the heat source temperature, even if the effectiveness of solution heat exchanger is 1, as shown in Table 2. This is because there is a large difference in the mass flow rates between two sides of solution heat exchanger.

From Table 2, it is found that the solution temperature before EV sharply increases as the effectiveness of solution heat exchanger decreases. When the effectiveness of solution heat exchanger deteriorates to 0.5, the solution temperature is up to 94.5 ◦C. As widely acknowledged, if the high-temperature and high-pressure solution directly flows through EV, it will result in the relatively large heat loss and throttling loss, as revealed in Table 2.

To reduce irreversible losses during the compression and throttling process, additional technical means are essential to lower the suction temperature of compressor and the solution temperature before the expansion valve. Thus, for the HACHP cycle, a two-stage rectification and a subcooler are specially proposed and utilized.

## *2.2. HACHP with two-stage rectification and subcooler*

The schematic of the modified HACHP cycle is shown in [Fig. 2.](#page-3-0) Main components of the modified HACHP cycle includes two absorbers, two solution heat exchangers, two solution pumps, two compressors, two expansion valves, four rectifiers, a generator and a subcooler.

The modified HACHP consists of two HACHP coupled to each other through a subcooler. The large HACHP cycle is known as the main cycle and the small HACHP cycle is referred as the sub-cycle. The sub-cycle extracts heat directly from the inlet solution of expansion valve of the main cycle, and releases heat to HTF. The solution temperature before EV and the irreversible loss during the throttling process in the main cycle effectively decrease. Consequently, a subcooler can improve the heating COP.

Additionally, to reduce the suction temperature of compressor, a two-stage rectification is proposed. In the rectifier 1, the vapor releases heat to the ambient. To further reduce the suction temperature, another rectifier is employed. A vapor-compression system serves as the rectifier 2. Through a two-stage rectification, a lower discharge temperature of compressor is obtained, so it becomes possible to utilize commercially available ammonia compressors in the HACHP for high-temperature heating, and the irreversible loss during the compression process decreases. Furthermore, the suction vapor of compressor is almost 100% ammonia, which is conducive to efficient and stable operation of compressor [\[21\].](#page-8-0)

## **3. Mathematical model**

To evaluate the performance improvement methods, a mathematical model of the HACHP cycle is developed. Before it is established, some assumptions are taken based on previous references [\[14,27\]](#page-8-0):

- a) The concentration difference between the weak and strong solutions is 0.1;
- b) The isentropic efficiency of compressor is assumed to be 0.7;
- c) Temperature ranges of HTF and LTF (Δ*T*HTF and Δ*T*LTF) in the absorber and generator are 10 ◦C, and the mean heat transfer temperature difference is 6 ◦C;
- d) Additionally, the mass flowrate of the strong solution at the absorber outlet is 1 kg/s;
- e) The liquid is incompressible.

For the absorber, the absorption heat transferred to HTF is

$$Q_{abs} = m_{abs} (h_{abs,in} - h_3) = m_{abs} (h_{abs,in} - h|_{p=p_{abs}, x=x_3, q=0})$$
 (1)

For the generator, the desorption heat supplied by LTF is

$$Q_{\text{gen}} = m_{\text{gen}} \left( h_{\text{gen,out}} - h_6 \right) = m_{\text{gen}} \left( h_{p=p_{\text{gen}}, x=x_6, q=q_{\text{gen,out}}} - h_6 \right)$$
 (2)

The heat released to the ambient in the rectifier 1 is

$$Q_{\text{rectifier 1}} = m_7 h_7 - m_{10} h_{10} - m_{11} h_{11} \tag{3}$$

where *m*10 is the mass flowrate of condensed liquid produced in the rectifier 1.

The heat released in the rectifier 2 is

$$Q_{\text{rectifier 2}} = m_{11}h_{11} - m_1h_1 - m_{12}h_{12} \tag{4}$$

where *m*12 is the mass flowrate of condensed liquid obtained in the

<span id="page-3-0"></span>![](_page_3_Figure_2.jpeg)

**Fig. 2.** Schematic of the modified HACHP cycle.

rectifier 2.

For the SHX, the energy equation is

$$T_9 - T_8 = \varepsilon_{\text{SHX}}(T_3 - T_8) \tag{5}$$

$$m_3(h_3 - h_4) = m_8(h_9 - h_8) (6)$$

The power consumption of compressor is

$$W_{\text{comp}} = m_1(h_{2s} - h_1)/\eta_{\text{comp}} \tag{7}$$

The power consumption of the solution pump is

$$W_{\text{pump}} = m_{13}v_{13}(p_{\text{abs}} - p_{\text{gen}})/\eta_{\text{pump}}$$
(8)

The power consumption in the rectifier 2 is

$$W_{\text{rectifier 2}} = m_{15} \left( h_{15,s} - h_{15} \right) / \eta_{\text{rectifier 2, comp}} \tag{9}$$

The temperature drop of solution in the subcooler is defined as

$$\Delta T_{\text{subcooler}} = T_4 - T_5 \tag{10}$$

The heating COP of the HACHP cycle without a subcooler is

$$COP = Q_{abs}/W_{total} = Q_{abs}/(W_{comp} + W_{pump} + W_{rectifier 2})$$
(11)

The heating COP of the HACHP cycle with a subcooler is

$$\begin{aligned} \text{COP} &= \left(Q_{\text{abs, main}} + Q_{\text{abs, sub}}\right) / \left(\frac{W_{\text{comp, main}} + W_{\text{pump, main}} + W_{\text{rectifier 2,main}}}{+W_{\text{comp, sub}} + W_{\text{pump, sub}} + W_{\text{rectifier 2,sub}}}\right) \end{aligned} \tag{12}$$

where *Q*abs,sub is the heat transferred to HTF from the sub-cycle; *W*comp, sub, *W*pump,sub and *W*rectifier 2, sub are the power consumption of the compressor, solution pump and rectifier 2 in the sub-cycle.

### **4. Performance analysis of HACHP**

In terms of the aforementioned model and assumptions, the performance of the modified cycle can be evaluated. In the following analysis, the optimum suction temperature of compressor is firstly determined, and at this time, the temperature drop of solution in the subcooler is 0 ◦C. Secondly, how the cycle performance is influenced by the subcooler is analyzed. Finally, the performance comparison between the modified and conventional cycles is conducted.

## *4.1. Two-stage rectification*

#### *4.1.1. Optimum suction temperature of compressor*

As mentioned before, for the conventional cycle, the discharge temperature of compressor is 276.6 ◦C at a heating temperature of 120 ◦C and a heat source temperature of 70 ◦C, and conventional ammonia compressors are extremely difficult to withstand such a high

![](_page_4_Figure_2.jpeg)

**Fig. 3.** Discharge temperature of compressor in the HACHP cycle.

discharge temperature. To reduce the discharge temperature of compressor, it is quite necessary to lower its suction temperature. However, theoretical analysis shows that even if the suction vapor of compressor is cooled to − 5.8 ◦C, which is the saturation temperature of pure ammonia at the generation pressure, the discharge temperature is still as high as 180 ◦C, as shown in Fig. 3. As a result, conventional ammonia compressors are unbearable. Eventually, to limit the final discharge temperature, the intermediate cooling such as oil cooling needs to be utilized. It is well known that the current maximum discharge temperature that compressors can withstand is usually 120 ◦C, so it is selected for the following analysis of optimum suction temperature.

Fig. 4(a) indicates that with the decrement of suction temperature, the COP gradually increases. The maximum COP of 2.26 is obtained at a suction temperature of 4.5 ◦C, and thermodynamic parameters of cycle at this condition are presented in [Table 3. Table 3](#page-5-0) shows that through a

two-stage rectification, the suction vapor of compressor is almost 100% ammonia.

Additionally, it is found that when the suction temperature of compressor is below − 0.8 ◦C, the COP drops sharply. This is because a large amount of condensed fluid will be formed in the rectifier 2 under this circumstance, engendering a significant increase in the heat dissipation, as shown in Fig. 4(b). As a result, the power consumption during this rectification process will dramatically increase. Eventually, the total power consumption of the cycle demonstrated in Fig. 4(c) is almost constant, although the power consumption of the main compressor decreases sharply at a suction temperature of below − 0.8 ◦C, as exhibited in Fig. 4(b). Simultaneously, the absorption heat decreases as the suction mass flowrate of compressor decreases, as indicated in Fig. 4(c), which eventually brings about a sharp drop in the heating COP.

Furthermore, the total exergy destruction during the compression process, including the rectifier 1, rectifier 2 and intermediate cooling, is also calculated, as revealed in Fig. 4(d). The total exergy destruction is

$$E_{\text{compression}} = T_0 \Delta S_{\text{compression}}$$

$$= T_0 \left( m_2 s_2 + m_{12} s_{12} + m_{10} s_{10} - m_7 s_7 + \frac{Q_{\text{rectifier1}} + Q_{\text{condenser}} + Q_{\text{inter,cooling}}}{T_0} \right)$$
(13)

The variation trend of exergy destruction is totally opposite to that of the heating COP, and the maximum COP is obtained at an almost minimum exergy destruction. When the suction temperature decreases from 64.4 ◦C to − 0.8 ◦C, the exergy destruction gradually decreases from 36.1 kW to 23.6 kW. A large suction temperature certainly will result in a high discharge temperature, and to control the final discharge temperature, the intermediate cooling will take away much more heat. Eventually, a large suction temperature causes a high exergy destruction during the compression process.

![](_page_4_Figure_11.jpeg)

**Fig. 4.** Performance of the modified HACHP cycle at different suction temperatures of compressor.

<span id="page-5-0"></span>**Table 3**  Thermodynamic parameters of the modified cycle.

| Position         | p/MPa | T/o<br>C | q     | x     |
|------------------|-------|----------|-------|-------|
| 1                | 0.35  | 4.5      | 1     | 0.999 |
| 2                | 2.10  | 120.0    | 1(+)  | 0.999 |
| 3                | 2.10  | 115.6    | 0     | 0.400 |
| 4                | 2.10  | 78.0     | 0(-)  | 0.400 |
| 5                | 2.10  | 78.0     | 0(-)  | 0.400 |
| 6                | 0.35  | 53.4     | 0.071 | 0.400 |
| 7                | 0.35  | 64.5     | 1     | 0.954 |
| 8                | 2.10  | 64.8     | 0(-)  | 0.300 |
| 9                | 2.10  | 110.6    | 0(-)  | 0.300 |
| 10               | 0.35  | 30       | 0     | 0.491 |
| 11               | 0.35  | 30       | 1     | 0.996 |
| 12               | 0.35  | 4.5      | 0     | 0.722 |
| 13               | 0.35  | 63.9     | 0     | 0.304 |
| 14               | 0.35  | 64.5     | 0     | 0.300 |
| Generator outlet | 0.35  | 64.5     | 0.153 | 0.400 |
| Absorber inlet   | 2.10  | 126.4    | 0.085 | 0.400 |
|                  |       |          |       |       |

Note: (-) stands for subcooled state; (+) stands for superheated state.

![](_page_5_Figure_5.jpeg)

**Fig. 5.** Working domain of the modified HACHP using a common compressor.

## *4.1.2. Working domain of the modified HACHP*

Through a two-stage rectification and an intermediate cooling, commercially available ammonia compressors can be employed in the HACHP for high-temperature heating, and its working domain is effectively extended.

To determine its working domain, the operating envelope of compressors should be taken into account. A real open screw ammonia compressor is chosen in this analysis, whose operating envelope is shown in Fig. 5. For this compressor, the maximum discharge saturation temperature is 60 ◦C, and the corresponding maximum discharge pressure can be determined, about 2.61 MPa.

According to the mathematical model, the suction and discharge pressures of compressor are gotten when the heat source temperature,

![](_page_5_Figure_11.jpeg)

**Fig. 6.** COP of the modified HACHP cycle at different Δ*T*subcooler.

strong solution concentration and heating temperature are given, so the saturation temperatures of pure ammonia at these pressures are obtained. For the legend of Fig. 5, 70-0.4 means that the heat source temperature and strong solution concentration are 70 ◦C and 0.4, respectively. Under the conditions of 70 ◦C heat source temperature, 0.4 strong solution concentration and 120 ◦C heating temperature, the corresponding saturation temperatures are − 5.8 ◦C and 51.9 ◦C, and this condition is within the operating envelope of this compressor. Consequently, this compressor can operate under this condition.

Fig. 5 exhibits that the maximum heating temperature that the modified HACHP outputs is about 130 ◦C. Additionally, restrained by the maximum discharge pressure that this compressor can withstand, the strong solution concentration should not be greater than 0.4 at a heating temperature of above 110 ◦C.

## *4.2. Subcooler*

In this section, how the performance of the cycle is influenced by a subcooler is analyzed. Firstly, the optimum temperature drop of solution in the subcooler is determined at different effectiveness of SHX. Secondly, the performance of the cycle with multi-stage subcoolers is investigated.

## *4.2.1. Optimum temperature drop*

At first, the performance of the modified cycle is calculated when the effectiveness of SHX is 1. Fig. 6 exhibits that the maximum heating COP of 3.36 is obtained at a temperature drop Δ*T*subcooler of 12 ◦C, which has 3.3% increase in comparison to the cycle without a subcooler. Owe to a large difference in mass flow rates between two sides of SHX, the subcooler can still improve the heating COP even if the effectiveness of SHX is 1. Consequently, a subcooler is quite necessary to obtain a high heating COP.

The main reason why a subcooler can improve heating COP is that

![](_page_5_Figure_20.jpeg)

![](_page_5_Figure_21.jpeg)

**Fig. 7.** Performance of main cycle and sub-cycle at different Δ*T*subcooler.

<span id="page-6-0"></span>![](_page_6_Figure_2.jpeg)

**Fig. 8.** Performance of modified HACHP cycle at different effectiveness of SHX.

the sub-cycle has a higher heating COP in comparison to the main cycle at a relatively low Δ*T*subcooler, as shown in [Fig. 7](#page-5-0)(a). Since the solution temperature *T*4, which is the heat source temperature of the sub-cycle, is larger than heat source temperature of the main cycle, the sub-cycle has a lower pressure ratio of compressor at a relatively low Δ*T*subcooler, as presented in [Fig. 7\(](#page-5-0)b). When a Δ*T*subcooler is 6 ◦C, the pressure ratios of the main cycle and sub-cycle are 5.53 and 4.88, respectively. Therefore, a higher heating COP is gotten in the sub-cycle.

Additionally, with the increment of the Δ*T*subcooler, the COPs of the main cycle and sub-cycle have opposite variation trends, so there probably exists an optimum Δ*T*subcooler.

Then, the COP of HACHP cycle with a subcooler at different effectiveness of SHX is calculated, as presented in Fig. 8(a). A lower effectiveness of SHX results in a higher solution temperature *T*4 in the main cycle, so much more heat can be recovered. From Fig. 8(a), it is found that when the effectiveness of SHX decreases from 1 to 0.5, the optimum Δ*T*subcooler in the subcooler increases from 11.7 ◦C to 21.9 ◦C. Additionally, there is an obvious characteristic line between the optimum Δ*T*subcooler and the effectiveness of SHX *ε*SHX, as shown in Fig. 8(b), and the characteristic line equation is

$$\Delta T_{\text{subcooler,opt}} = -19.8\varepsilon_{\text{SHX}} + 31.5 \tag{14}$$

![](_page_6_Picture_8.jpeg)

**Fig. 9.** Schematic of the HACHP cycle with multi-stage subcoolers.

![](_page_7_Figure_2.jpeg)

**Fig. 10.** COP of HACHP cycle with multi-stage subcoolers.

Based on this correlation, the optimum Δ*T*subcooler can be quickly determined. Furthermore, with the decrement of the effectiveness of SHX, the increase rate of COP induced by a subcooler dramatically increases, as demonstrated in [Fig. 8\(](#page-6-0)c). When the effectiveness of SHX is 0.5, the COP of the HACHP cycle with a subcooler has up to 86% increase in comparison to that without a subcooler. Additionally, at the same heat exchanger effectiveness, the increase rate of COP will increase as the concentration difference between the weak and strong solutions increases, because the difference in the mass flow rates between two sides of SHX will become larger at this condition.

Generally, the performance of SHX will gradually deteriorates with time elapsing. If the effectiveness of SHX decreases gradually from 0.8 to 0.7, the COP of HACHP without a subcooler drops from 2.26 to 1.76, a drop of as high as 22.5%, as depicted in [Fig. 8](#page-6-0)(a). If the HACHP is equipped with a subcooler, the COP will decrease to 2.13, a drop of only 6%. Therefore, a subcooler can reduce the impact of performance deterioration of SHX on the heat pump performance, and make the hybrid heat pump operate at a relatively high heating COP.

## *4.2.2. Performance of HACHP with multi-stage subcoolers*

Then, the performance analysis of HACHP with multi-stage subcoolers shown in [Fig. 9](#page-6-0) is conducted when the heat source temperature, heating temperature and effectiveness of SHX are 70 ◦C, 120 ◦C and 0.8. The upper stage extracts heat directly from the inlet solution of expansion valve of the lower stage, and all of them release high-temperature heat to HTF.

Fig. 10 indicates that the heating COP increases gradually as the stage number of subcooler increases. When the stage number is 5, the COP is 2.66, which has up to 17.2% increase in comparison to the HACHP without a subcooler. Additionally, with the increment of stage number, the increase rate of COP becomes slower and slower. An appropriate stage number should not be greater than 2, and the reason is as follows:

From Fig. 11(a), it is found that when the stage number is not greater than 2, the EV inlet solution temperature *T*5 and the vapor mass fraction at the EV outlet *q*6 in the main cycle decrease rapidly with the increment of the stage number. When the stage number is greater than 2, they are almost constant, so each stage can release less and less heat to HTF, as presented in Fig. 11(b). As a result, although the heating COP of each stage is higher than that of main cycle, the COP of HACHP cycle with multi-stage subcoolers will not dramatically increase with the increment of stage number, as exhibited in Fig. 11(c).

## *4.3. Performance comparison*

In this part, the performance comparison between the modified and conventional cycles is conducted under the conditions of 70 ◦C heat source temperature, 0.4 strong solution concentration, 0.8 effectiveness of SHX and 120 ◦C discharge temperature of compressor. [Fig. 12\(](#page-8-0)a) indicates that the COP of the modified cycle is always higher than that of the conventional cycle. At a HTF outlet temperature of 120 ◦C, the COP of the modified cycle is 2.54, while the COP of conventional cycle is 2.16. In this case, the COP of the modified cycle has about 17.4% increase in comparison to conventional one, as shown in [Fig. 12\(](#page-8-0)b).

![](_page_7_Figure_12.jpeg)

**Fig. 11.** Performance of each subcooler.

<span id="page-8-0"></span>![](_page_8_Figure_2.jpeg)

**Fig. 12.** Performance comparison between the conventional and modified cycles.

#### **5. Conclusions**

In this work, we develop two novel approaches to performance improvement of conventional hybrid absorption-compression heat pump, namely a two-stage rectification for reducing the suction temperature of compressor and a subcooler for lowering the solution temperature before the expansion valve. Main conclusions are drawn as follows:

- 1) By utilizing a two-stage rectification, commercially available normal-temperature ammonia compressors can be employed in the hybrid heat pump for high-temperature heating. When the discharge pressure of compressor is 2.61 MPa, the heating temperature reaches 130 ◦C.
- 2) A subcooler can improve the heating COP even if the effectiveness of solution heat exchanger is 1, and the maximum COP of the hybrid heat pump with a subcooler is 3.36 under the conditions of 70 ◦C heat source temperature and 120 ◦C heating temperature.
- 3) For the hybrid heat pump with multi-stage subcoolers, an appropriate stage number should not be greater than 2.
- 4) The modified hybrid heat pump cycle improves about 17.4% COP in comparison to the conventional one at a heating temperature of 120 ◦C and a solution heat exchanger effectiveness of 0.8.

In short, the two-stage rectification and subcooler not only effectively extend the application range of the hybrid heat pump, but also improve its heating COP. However, it should be noted that two novel approaches make the hybrid heat pump more complicated, and further research will focus on some simple methods. Additionally, although the empirical correlation of the optimum temperature drop of solution in the subcooler is proposed in this paper, there are still some constraints before widespread utilization, and further research will also concentrate on more universal empirical correlations.

## **Declaration of Competing Interest**

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## **Acknowledgements**

This work was sponsored by Shanghai Sailing Program (No. 20YF1431400).

## **References**

[1] [C. Arpagaus, F. Bless, M. Uhlmann, J. Schiffmann, S.S. Bertsch, High temperature](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0005)  [heat pumps: market overview, state of the art, research status, refrigerants, and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0005)  [application potentials, Energy 152 \(2018\) 985](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0005)–1010.

- [2] [R.O. Lamidi, L. Jiang, P.B. Pathare, Y.D. Wang, A.P. Roskilly, Recent advances in](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0010) [sustainable drying of agricultural produce: A review, Appl. Energy 233](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0010)–234 (2019) 367–[385.](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0010)
- [3] [J. Zhang, H.H. Zhang, Y.L. He, W.Q. Tao, A comprehensive review on advances and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0015)  [applications of industrial heat pumps based on the practices in China, Appl. Energy](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0015)  [178 \(2016\) 800](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0015)–825.
- [4] [V. Jain, G. Sachdeva, S.S. Kachhwaha, Comparative performance study and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0020) [advanced exergy analysis of novel vapor compression-absorption integrated](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0020)  [refrigeration system, Energy Convers. Manage. 172 \(2018\) 81](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0020)–97.
- [5] [M. Saikawa, S. Koyama, Thermodynamic analysis of vapor compression heat pump](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0025)  [cycle for tap water heating and development of CO2 heat pump water heater for](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0025) [residential use, Appl. Therm. Eng. 106 \(2016\) 1236](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0025)–1243.
- [6] M. Vall`[es, M. Bourouis, D. Boer, Solar-driven absorption cycle for space heating](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0030) [and cooling, Appl. Therm. Eng. 168 \(2020\)](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0030).
- [7] [W. Wu, X. Li, T. You, B. Wang, W. Shi, Combining ground source absorption heat](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0035)  [pump with ground source electrical heat pump for thermal balance, higher](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0035) [efficiency and better economy in cold regions, Renewable Energy 84 \(2015\) 74](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0035)–88.
- [8] [Q. Wang, W. He, Y.Q. Liu, G.F. Liang, J.R. Li, X.H. Han, G.M. Chen, Vapor](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0040)  [compression multifunctional heat pumps in China: A review of configurations and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0040)  [operational modes, Renew. Sustain. Energy Rev. 16 \(2012\) 6522](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0040)–6538.
- [9] [J. Sarkar, S. Bhattacharyya, Assessment of blends of CO2 with butane and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0045)  [isobutane as working fluids for heat pump applications, Int. J. Therm. Sci. 48](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0045)  [\(2009\) 1460](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0045)–1465.
- [10] [D. Wu, H. Yan, B. Hu, R.Z. Wang, Modeling and simulation on a water vapor high](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0050)  [temperature heat pump system, Energy \(2019\) 1063](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0050)–1072.
- [11] [S.J. Hong, C.H. Lee, S.M. Kim, I.G. Kim, O.K. Kwon, C.W. Park, Analysis of single](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0055)  [stage steam generating absorption heat transformer, Appl. Therm. Eng. 144 \(2018\)](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0055)  [1109](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0055)–1116.
- [12] [N. Merkel, M. Bücherl, M. Zimmermann, V. Wagner, K. Schaber, Operation of an](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0060)  [absorption heat transformer using water/ionic liquid as working fluid, Appl.](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0060) [Therm. Eng. 131 \(2018\) 370](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0060)–380.
- [13] [M. Wakim, R. Rivera-Tinoco, Absorption heat transformers: Sensitivity study to](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0065)  [answer existing discrepancies, Renewable Energy 130 \(2019\) 881](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0065)–890.
- [14] [L.G. Farshi, S. Khalili, A.H. Mosaffa, Thermodynamic analysis of a cascaded](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0070)  compression – [Absorption heat pump and comparison with three classes of](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0070) [conventional heat pumps for the waste heat recovery, Appl. Therm. Eng. 128](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0070) [\(2018\) 282](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0070)–296.
- [15] [S.B. Riffat, N. Shankland, Integration of absorption and vapour-compression](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0075) [systems, Appl. Energy 46 \(1993\) 303](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0075)–316.
- [16] [C.W. Jung, J.Y. Song, Y.T. Kang, Study on ammonia/water hybrid absorption/](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0080) [compression heat pump cycle to produce high temperature process water, Energy](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0080)  [145 \(2018\) 458](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0080)–467.
- [17] [P.K. Satapathy, M.R. Gopal, R.C. Arora, Studies on a compression-absorption heat](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0085)  [pump for simultaneous cooling and heating, Int. J. Energy Res. 28 \(2004\) 567](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0085)–580.
- [18] [W. Wu, B. Wang, W. Shi, X. Li, Absorption heating technologies: A review and](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0090)  [perspective, Appl. Energy 130 \(2014\) 51](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0090)–71.
- [19] [S. Kabelac, K.H. Hartmann, H. Kruse, T. Tokan, M. Loth, J. Stegmann,](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0095)  [B. Markmann, Experimental Results of an Absorption-Compression Heat Pump](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0095) [using the Working Fluid Ammonia/Water for Heat Recovery in Industrial](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0095)  [Processes, Int. J. Refrig \(2018\).](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0095)
- [20] [C.W. Jung, S.S. An, Y.T. Kang, Thermal performance estimation of ammonia-water](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0100)  [plate bubble absorbers for compression/absorption hybrid heat pump application,](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0100)  [Energy 75 \(2014\) 371](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0100)–378.
- [21] [J.K. Jensen, W.B. Markussen, L. Reinholdt, B. Elmegaard, On the development of](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0105)  [high temperature ammonia-water hybrid absorption-compression heat pumps, Int.](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0105)  [J. Refrig 58 \(2015\) 79](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0105)–89.
- [22] T.E. M.B. Wersland, I. Tolstorebrov, Investigation of a hybrid compression absorption heat pump system for high tempetatures, in: 13th IIR Gustav Lorentzen Conference, Valencia, 2018.
- [23] [J. Kim, S.R. Park, Y.J. Baik, K.C. Chang, H.S. Ra, M. Kim, Y. Kim, Experimental](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0115)  [study of operating characteristics of compression/absorption high-temperature](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0115) [hybrid heat pump using waste heat, Renewable Energy 54 \(2013\) 13](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0115)–19.
- [24] [S. Du, R.Z. Wang, P. Lin, Z.Z. Xu, Q.W. Pan, S.C. Xu, Experimental studies on an air](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0120)[cooled two-stage NH3-H2O solar absorption air-conditioning prototype, Energy 45](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0120)  [\(2012\) 581](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0120)–587.

- <span id="page-9-0"></span>[25] [S. Du, R.Z. Wang, X. Chen, Development and experimental study of an ammonia](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0125)  [water absorption refrigeration prototype driven by diesel engine exhaust heat,](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0125)  [Energy 130 \(2017\) 420](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0125)–432.
- [26] [E.W. Lemmon, M.L. Huber, M.O. McLinden, NIST Standard Reference Database 23:](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0130)  [Reference Fluid Thermodynamic and Transport Properties-REFPROP, Version 10.0,](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0130)
- [National Institute of Standards and Technology, Standard Reference Data Program,](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0130)  [Gaithersburg \(2018\)](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0130).
- [27] [O. Brunin, M. Feidt, B. Hivet, Comparison of the working domains of some](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0135)  [compression heat pumps and a compression-absorption heat pump, Int. J. Refrig 20](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0135)  [\(1997\) 308](http://refhub.elsevier.com/S1359-4311(20)33508-0/h0135)–318.