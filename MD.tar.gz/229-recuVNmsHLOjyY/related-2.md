### ORIGINAL PAPER

# Multiple scales analysis of wave-wave interactions in a cubically nonlinear monoatomic chain

Kevin Manktelow · Michael J. Leamy · Massimo Ruzzene

Received: 23 April 2010 / Accepted: 4 August 2010 / Published online: 28 August 2010 © Springer Science+Business Media B.V. 2010

Abstract The interaction of waves in nonlinear media is of practical interest in the design of acoustic devices such as waveguides and filters. This investigation of the monoatomic mass-spring chain with a cubic nonlinearity demonstrates that the interaction of two waves results in different amplitude and frequency dependent dispersion branches for each wave, as opposed to a single amplitude-dependent branch when only a single wave is present. A theoretical development utilizing multiple time scales results in a set of evolution equations which are validated by numerical simulation. For the specific case where the wavenumber and frequency ratios are both close to 1:3 as in the long wavelength limit, the evolution equations suggest that small amplitude and frequency modulations may be present. Predictable dispersion behavior for weakly nonlinear materials provides additional latitude in tunable metamaterial design. The general results developed herein may be extended to three or more wavewave interaction problems.

**Keywords** Nonlinear stiffness · Wave propagation · Dispersion · Bandgap materials · Metamaterials · Wave interactions

K. Manktelow · M.J. Leamy (⋈) · M. Ruzzene George W. Woodruff School of Mechanical Engineering, Georgia Institute of Technology, 771 Ferst Drive NW, Atlanta, GA 30332-0405, USA e-mail: michael.leamy@me.gatech.edu

### 1 Introduction

The development and use of metamaterials has been a growing area of interest in the last two decades. The term metamaterials refers to a broad class of systems with unique engineered properties not found in nature. Acoustic metamaterials, such as phononic crystals, are designed to manipulate the propagation of acoustic waves in order to achieve desirable properties such as band gaps, negative refractive indices, phonon tunneling, and phonon focusing [20]. Additional properties such as tunable band gaps are useful in engineering applications such as waveguides, acoustic filters, acoustic mirrors, transducers, and diodes [2, 8, 12, 18, 19, 24, 27].

Recent research has focused on wave propagation in nonlinear periodic media and its application to the design of novel metamaterials [1, 3, 7, 8, 13–15, 22]. Nonlinearities play an increasingly dominant role in the dynamics of small scale applications [5, 9, 10], such as periodic metamaterials with micro- or nanoscale unit cells. Precise design at these scales relies on a complete understanding of how nonlinearities affect operation and performance. Hence, a present goal of acoustic metamaterial research is to understand how nonlinearities influence operation and how they may be used to enhance and control material properties.

Acoustic devices may be subject to multi-harmonic excitations. In one-dimensional linear materials, the only wave—wave interactions expected are constructive and destructive interference. In nonlinear materi-

![](_page_0_Picture_12.jpeg)

als, additional wave–wave interactions take place such that the strength of the interaction causes dispersion to become both amplitude and frequency dependent. The interaction of harmonic waves that are commensurate[1](#page-1-0) with frequency ratios close to 1 : 3 may be of particular concern for cubically nonlinear materials where superharmonic generation may be present.

The propagation of multiple nonlinearly interacting waves has received considerably less attention than the propagation of a single wave. It is well known that oscillations in nonlinear systems tend to generate superharmonics and subharmonics [[7\]](#page-9-5). This characteristic behavior of nonlinear systems motivates the investigation of wave–wave interactions. Nayfeh and Mook explored these interactions using the method of multiple scales for transverse waves along a beam on an elastic foundation [[16\]](#page-10-7). Rushchitsky has been a primary investigator in the subject of wave–wave interaction and evolution in continuous solids [[6,](#page-9-10) [7,](#page-9-5) [23](#page-10-8)]. Rushchitsky and Saveleva also presented theoretical results on the interaction of harmonic elastic plane waves in a cubically nonlinear material using the method of multiple scales for a continuum model [[7\]](#page-9-5). They derived a theoretical model governing the transfer of energy from a stronger primary wave to a nearly-commensurate superharmonic.

Periodic materials are of particular interest in metamaterial research due to the presence of band gaps. Various types of periodic media have been studied in the past, including strongly nonlinear contact in beaded systems [[4\]](#page-9-11), kink dynamics [\[21](#page-10-9)], and weakly coupled layered systems [[25,](#page-10-10) [26](#page-10-11)]. One of the most commonly studied systems in the last few decades is the one-dimensional, undamped spring–mass chain [\[13](#page-9-6)[–15](#page-10-5), [17\]](#page-10-12). The dispersion relation of a linear chain relating the frequency and wavenumber is well known, and in one dimension the analysis may be confined to the first Brillouin Zone due to spatial periodicity [\[11](#page-9-12)]. Since band gaps are dictated by the maximum and minimum limits of the dispersion curves, it is of interest to understand the effects of nonlinearities there. Amplitude-dependent dispersion and band gap behavior has recently been explored in several discrete periodic systems characterized by cubic nonlinearities [\[14](#page-9-13)]. It is shown that the boundary of the dispersion curve may shift with amplitude in the presence of a

![](_page_1_Picture_5.jpeg)

In this work, the analysis presented in [[14\]](#page-9-13) is extended to include the propagation of multiple harmonic plane waves. It is shown that the method of multiple scales provides more generality than Lindstedt– Poincaré when wave–wave interactions occur due to commensurate or nearly-commensurate frequency ratios. The following development supports the interests being generated by the community by contributing a numerically verified theoretical framework in which the dispersion properties of discrete, periodic, cubically nonlinear systems undergoing harmonic wave– wave interactions may be determined.

The paper is organized as follows. In Sect. [2.1](#page-1-1) we describe the nonlinear model used for the perturbation analysis. For completeness, in Sect. [2.2.1](#page-2-0) we briefly reconsider the case of a single harmonic wave present in the far-field using Lindstedt–Poincaré perturbation and then recover the same result using the method of multiple scales in Sect. [2.2.2](#page-2-1). The method of multiple scales is applied to the same nonlinear spring–mass system under the influence of two waves in order to obtain theoretical dispersion relations and evolution equations in Sect. [2.3](#page-4-0). Finally, the dispersion relations generated by the method of multiple scales are numerically verified in Sect. [3.](#page-8-0)

## **2 Monoatomic chain perturbation analysis**

<span id="page-1-1"></span>In this paper, the method of multiple scales is used in lieu of the Lindstedt–Poincaré method in order to provide the necessary generality when the linear solution contains multiple, nearly-commensurate harmonic plane waves. An example chain illustrates the method for analyzing wave–wave interactions.

### <span id="page-1-2"></span>2.1 Model description

The monoatomic spring–mass chain with a cubic nonlinearity shown in Fig. [1](#page-2-2) is considered. The equation of motion for the monoatomic chain considered is

$$m\ddot{u}_j + k(2u_j - u_{j-1} - u_{j+1}) + \varepsilon \Gamma (u_j - u_{j-1})^3$$

![](_page_1_Picture_13.jpeg)

<span id="page-1-0"></span><sup>1</sup>Two frequencies *ωA* and *ωB* where two integers *n* and *m* can be chosen to satisfy *nωA* + *mωB* = 0.

<span id="page-2-2"></span>![](_page_2_Picture_2.jpeg)

**Fig. 1** Monoatomic mass-spring chain with cubic stiffness

$$+\varepsilon\Gamma(u_j-u_{j+1})^3=0, \quad \forall j\in\mathbb{Z},$$
 (1)

where *uj (t)* is the displacement from equilibrium of the *j* th mass, *ε* is a small parameter, *Γ* characterizes the cubic nonlinearity, and *m* and *k* denote the mass and linear stiffness. We non-dimensionalize the equation of motion [\(1](#page-1-2)) by first writing the equation of motion in canonical form, where *ω*<sup>2</sup> *<sup>n</sup>* = *k/m*:

$$\ddot{u}_j + \omega_n^2 (2u_j - u_{j-1} - u_{j+1}) + \frac{\varepsilon \Gamma}{m} (u_j - u_{j-1})^3 + \frac{\varepsilon \Gamma}{m} (u_j - u_{j+1})^3 = 0.$$

<span id="page-2-5"></span>We represent space and time by introducing characteristic parameters (*uc* and *tc*) and non-dimensional variables for space and time (*xj* and *τ* ) such that *uj* ≡ *uc xj* and *t* ≡ *tc τ* , where characteristic length is *uc* <sup>=</sup> <sup>√</sup>*k/Γ* and the characteristic time is *tc* <sup>=</sup> <sup>1</sup>*/ωn*. The equation of motion is then rewritten using nondimensional variables as

$$x_{j}'' + (2x_{j} - x_{j-1} - x_{j+1}) + \varepsilon (x_{j} - x_{j-1})^{3} + \varepsilon (x_{j} - x_{j+1})^{3} = 0, \quad \forall j \in \mathbb{Z}.$$
 (2)

Note that a prime ( ) corresponds to a derivative with respect to non-dimensional time *τ* .

### 2.2 Single wave dispersion analysis

<span id="page-2-0"></span>For the remainder of the paper, a single-wave analysis refers to calculations presuming the presence of only one harmonic plane wave, whereas a multi-wave analysis refers to the presence of two or more dominant harmonics present such that wave–wave interactions take place.

### <span id="page-2-4"></span>*2.2.1 Lindstedt–Poincaré analysis*

It was shown in [[14\]](#page-9-13) that a correction to the linear dispersion relation for the monoatomic chain could be obtained using Lindstedt–Poincaré perturbation as *ω(μ)* = *ω*0*(μ)* + *εω*1*(μ)* + *O(ε*2*)*, where

$$\omega_0 = \sqrt{2 - 2\cos\mu},\tag{3a}$$

<span id="page-2-3"></span>
$$\omega_1 = \frac{3\alpha^2(\cos 2\mu - 4\cos \mu + 3)}{4\omega_0},\tag{3b}$$

and *α* and *μ* denote the amplitude and non-dimensional wavenumber, respectively. The dispersion relation *ω(μ)* is periodic in wavenumber space such that only 0 *< μ* ≤ *π* is considered.

Equation [\(3b](#page-2-3)) provides a correction to the linear dispersion relation due to the presence of cubic nonlinearities. The same type of cubic nonlinearity in a spring–mass chain was considered in [[3\]](#page-9-4), where a correction to the dispersion relations was also found. The approach presented in [[3\]](#page-9-4) consists in the application of Bloch theorem directly to the nonlinear governing equations, while in [\[14](#page-9-13)] a perturbation method is applied to decouple linear and nonlinear terms. This leads to a set of linear equations for increasing order of the nonlinear parameter *ε*. Applying Bloch theorem to the lowest order equation, and imposing solvability conditions to the first order leads to the expressions presented in [\(3a\)](#page-2-4) and ([3b\)](#page-2-3).

We note that one simplification may be added to [\(3b](#page-2-3)) by substituting in the linear dispersion relation given by ([3a](#page-2-4)). After some manipulation, ([3b\)](#page-2-3) can be rewritten as

<span id="page-2-6"></span>
$$\omega_1 = \frac{3\alpha^2}{8} \underbrace{\frac{\omega_0^4}{(2 - 2\cos\mu)^2}}_{\omega_0} = \frac{3}{8}\alpha^2\omega_0^3. \tag{4}$$

Given a point on the linear dispersion relation *(μ,ω*0*)*, a frequency correction may be calculated as a function of *ω*0. The reconstituted dispersion relation is

<span id="page-2-1"></span>
$$\omega(\mu) = \sqrt{2 - 2\cos\mu} + \varepsilon \frac{3\alpha^2}{8} (2 - 2\cos\mu)^{3/2} + O(\varepsilon^2).$$
(5)

# *2.2.2 Dispersion relation using the method of multiple scales*

We begin with the equation of motion [\(2](#page-2-5)) and seek expressions for time-varying amplitude and phase. Slow time scales are introduced explicitly as *τn* = *εnτ* . As before, correction terms up to *O(ε*2*)* are sought so that the only time scales of interest are *τ*<sup>0</sup> = *τ* and *τ*<sup>1</sup> = *ετ* . An asymptotic expansion for the dependent variable *xj (τ)* is expressed in multiple time scales as

$$x_j(\tau) = \sum_n \varepsilon^n x_j^{(n)}(\tau_0, \tau_1, \dots \tau_n).$$

<span id="page-3-2"></span><span id="page-3-0"></span>Keeping terms up to and including  $O(\varepsilon^1)$  gives

$$x_j(\tau) = x_j^{(0)}(\tau_0, \tau_1) + \varepsilon x_j^{(1)}(\tau_0, \tau_1) + O(\varepsilon^2).$$
 (6)

<span id="page-3-1"></span>Substituting (6) into (2), and collecting terms in orders of  $\varepsilon$ , gives the first two ordered equations which may be written as

$$\varepsilon^{0}$$
:  $D_{0}^{2}x_{j}^{(0)} + (2x_{j}^{(0)} - x_{j-1}^{(0)} - x_{j+1}^{(0)}) = 0$  (7a)

$$\varepsilon^1$$
:  $D_0^2 x_j^{(1)} + (2x_j^{(1)} - x_{j-1}^{(1)} - x_{j+1}^{(1)})$ 

$$= -2D_0 D_1 x_j^{(0)} - F_{NL} (x_j^{(0)}, x_{j\pm 1}^{(0)}), \tag{7b}$$

where

$$F_{NL} = \left(x_i^{(0)} - x_{i-1}^{(0)}\right)^3 + \left(x_i^{(0)} - x_{i+1}^{(0)}\right)^3.$$

<span id="page-3-3"></span>In (7b),  $D_0$  and  $D_1$  represent partial derivatives with respect to the time scales  $\tau_0$  and  $\tau_1$ , respectively. In the presence of a single plane wave at frequency  $\omega$  and wavenumber  $\mu$ , the solution of (7a) is

$$x_{j}^{(0)}(\tau_{0}, \tau_{1}) = \frac{1}{2} A_{0}(\tau_{1}) e^{i(\mu j - \omega_{0} \tau_{0})} + \frac{1}{2} \overline{A_{0}}(\tau_{1}) e^{-i(\mu j - \omega_{0} \tau_{0})},$$
(8)

where  $A_0(\tau_1)$  is the complex quantity that permits slow time evolution of the amplitude and phase and an over-bar indicates a complex conjugate. The distinction may be made explicit by using polar form such that  $A_0(\tau_1) = \alpha(\tau_1)e^{-\mathrm{i}\beta(\tau_1)}$ , where both  $\alpha(\tau_1)$  and  $\beta(\tau_1)$  are real-valued functions. Substituting (8) into (7a) and simplifying gives the linear dispersion relation that was previously given in (3a).

<span id="page-3-4"></span>The linear kernel of the  $O(\varepsilon^1)$  equation is identical to the linear kernel of the  $O(\varepsilon^0)$  (7a), and thus the homogeneous solution has the same form as (8). Therefore, any terms appearing on the right-hand side of (7b) with similar spatial and temporal forms result in a non-uniform expansion. Removal of these secular terms by setting them equal to zero results in a system of *evolution equations* for the functions  $\alpha(\tau_1)$  and  $\beta(\tau_1)$ :

$$\alpha' = 0 \tag{9a}$$

$$\beta' = \frac{3\alpha^2(\cos 2\mu - 4\cos \mu + 3)}{4\omega_0} = \frac{3}{8}\alpha^2\omega_0^3,$$
 (9b)

where  $\alpha'$  and  $\beta'$  denote the derivatives with respect to the slow time scale  $\tau_1$ . It is clear from (9a) that

<span id="page-3-5"></span> $\alpha(\tau_1) = \alpha_0$  and  $\beta(\tau_1) = \beta_1 \tau_1 + \beta_0$ , where  $\alpha_0$  and  $\beta_0$  are arbitrary constants determined by imposing initial conditions on the plane wave given in (8). For the mass–spring chain in consideration,  $\beta_0$  may be set to zero without loss of generality. Equation (8) may be expressed using trigonometric functions as

$$x_j^{(0)}(\tau_0, \tau_1) = \alpha_0 \cos\left(\mu j - (\omega_0 + \omega_1 \varepsilon)\tau_0\right) + O(\varepsilon^2),$$
(10)

such that  $\beta_1 \varepsilon \equiv \omega_1 \varepsilon$  may be regarded as a first order frequency correction which results in a shift of the linear dispersion curve. The reconstituted dispersion relation is identical to (5). Hence, the method of multiple scales recovers the same results as the Lindstedt–Poincaré procedure.

# 2.2.3 Lindstedt–Poincaré vs. multiple scales for wave–wave interactions

It is well known that superharmonics are generated as a result of wave propagation in nonlinear media and that there exists nonlinear interaction between the waves [6, 16]. Therefore, it is of interest to extend the problem to the propagation of multi-harmonic plane waves to obtain closed-form relationships capturing these interactions.

The Lindstedt-Poincaré method provides a tool to capture nonlinear amplitude-frequency interaction in systems with time-invariant amplitude and phase, but fails to capture time-variant behavior such as in the long wavelength limit where amplitude or frequency modulation may occur. The failure in the Lindstedt-Poincaré method results from the requirement that wave amplitudes remain constant such that a single secular term may be used to obtain a single frequency correction term. When there are multiple secular terms, additional degrees of freedom are necessary to obtain a perturbation solution. Allowing for time-varying amplitude provides an additional degree of freedom to the problem.

The assumption implicit in the preceding singlewave analysis is that only a single harmonic plane wave exists for all time. However, when multiple waves are present with amplitudes that are the same order of magnitude, the single-wave analysis fails to accurately capture some nonlinear system behavior due to wave—wave interactions that are neglected.

![](_page_3_Picture_23.jpeg)

# <span id="page-4-0"></span>2.3 Wave–wave interaction analysis using the method of multiple scales

<span id="page-4-1"></span>Due to linearity of the  $O(\varepsilon^0)$  expression in (7a), a superposition of solutions in the form of (8) is also a solution, such that  $x_j^{(0)} \Rightarrow \sum_n x_{j,n}^{(0)}$ . When two waves are present, we superimpose two traveling wave solutions, labeled A and B, such that

<span id="page-4-2"></span>
$$x_{j}^{(0)}(\tau_{0}, \tau_{1}) = x_{j,A}^{(0)}(\tau_{0}, \tau_{1}) + x_{j,B}^{(0)}(\tau_{0}, \tau_{1}) + O(\varepsilon^{2}),$$
(11)

where

<span id="page-4-3"></span>
$$\begin{split} x_{j,A}^{(0)}(\tau_0,\tau_1) &= \frac{1}{2} A_0(\tau_1) e^{\mathrm{i}(\mu_A j - \omega_{A0} \tau_0)} + c.c. \\ &= \frac{1}{2} \alpha_A(\tau_1) e^{\mathrm{i}(\mu_A j - \omega_{A0} \tau_0 - \beta_A(\tau_1))} + c.c., \\ x_{j,B}^{(0)}(\tau_0,\tau_1) &= \frac{1}{2} B_0(\tau_1) e^{\mathrm{i}(\mu_B j - \omega_{B0} \tau_0)} + c.c. \\ &= \frac{1}{2} \alpha_B(\tau_1) e^{\mathrm{i}(\mu_B j - \omega_{B0} \tau_0 - \beta_B(\tau_1))} + c.c., \end{split}$$

and c.c. represents the complex conjugates of the preceding terms. Here,  $\alpha_A$ ,  $\alpha_B$ ,  $\beta_A$ , and  $\beta_B$  are functions for the amplitude and phase of each wave, which will be determined by imposing uniform asymptotic expansion conditions.

(12b)

<span id="page-4-4"></span>Substituting (11), (12a), and (12b) into (7b) and expanding the nonlinear terms denoted by  $F_{NL}$  allows for identification of secular terms. These terms are those which are proportional to  $e^{i\mu_A j}e^{i\omega_{A0}\tau_0}$  and  $e^{i\mu_B j}e^{i\omega_{B0}\tau_0}$ . Due to the arbitrary naming convention of the A and B waves, the secular terms arising from each wave are identical. For the A wave, secular terms are

$$\begin{split} e^{\mathrm{i}\mu_{A}j}e^{-\mathrm{i}\omega_{A0}\tau_{0}} & \left[ -\mathrm{i}A_{0}'\omega_{A0} + \frac{3}{4}A_{0}|B_{0}|^{2}e^{\mathrm{i}(\mu_{A}-\mu_{B})} \right. \\ & + \frac{3}{4}A_{0}|B_{0}|^{2}e^{\mathrm{i}(\mu_{B}-\mu_{A})} + \frac{3}{8}A_{0}|A_{0}|^{2}e^{\mathrm{i}2\mu_{A}} \\ & + \frac{3}{8}A_{0}|A_{0}|^{2}e^{-\mathrm{i}2\mu_{A}} - \frac{3}{2}A_{0}|B_{0}|^{2}e^{\mathrm{i}\mu_{A}} \\ & - \frac{3}{2}A_{0}|B_{0}|^{2}e^{-\mathrm{i}\mu_{A}} - \frac{3}{2}A_{0}|A_{0}|^{2}e^{\mathrm{i}\mu_{A}} \\ & - \frac{3}{2}A_{0}|A_{0}|^{2}e^{-\mathrm{i}\mu_{A}} + \frac{3}{4}A_{0}|B_{0}|^{2}e^{\mathrm{i}(\mu_{B}+\mu_{A})} \end{split}$$

$$+\frac{3}{4}A_{0}|B_{0}|^{2}e^{-\mathrm{i}(\mu_{B}+\mu_{A})} - \frac{3}{2}A_{0}|B_{0}|^{2}e^{\mathrm{i}\mu_{B}} -\frac{3}{2}A_{0}|B_{0}|^{2}e^{\mathrm{i}\mu_{B}} + \frac{9}{4}A_{0}|A_{0}|^{2} + 3A_{0}|B_{0}|^{2} + c.c..$$
(13)

<span id="page-4-5"></span>Additional secular terms may arise if  $(\mu_A, \omega_{A0})$  and  $(\mu_B, \omega_{B0})$  are related such that their combination results in a secular term. When  $\omega_{B0} \approx 3\omega_{A0}$  and  $\mu_B \approx 3\mu_A$ , these additional secular terms are

$$A_{0}^{3}e^{\mathrm{i}3\mu_{A}j}e^{-\mathrm{i}3\omega_{A0}\tau_{0}}\left[-\frac{3}{8}e^{-\mathrm{i}\mu_{A}} + \frac{1}{3} - \frac{1}{8}e^{\mathrm{i}3\mu_{A}} + \frac{3}{8}e^{\mathrm{i}2\mu_{A}} - \frac{3}{8}e^{\mathrm{i}\mu_{A}} - \frac{1}{8}e^{-\mathrm{i}3\mu_{A}} + \frac{3}{8}e^{\mathrm{i}2\mu_{A}}\right] + A_{0}^{2}\overline{B_{0}}e^{\mathrm{i}(\mu_{B}-2\mu_{A})j}e^{-\mathrm{i}(\omega_{B0}-2\omega_{A0})\tau_{0}} \times \left[-\frac{3}{8}e^{-\mathrm{i}\mu_{B}} + \frac{3}{8}e^{2\mathrm{i}\mu_{A}} - \frac{3}{8}e^{\mathrm{i}\mu_{B}} - \frac{3}{4}e^{-\mathrm{i}\mu_{A}} - \frac{3}{8}e^{\mathrm{i}(\mu_{B}-2\mu_{A})} - \frac{3}{8}e^{\mathrm{i}(\mu_{B}-2\mu_{A})} + \frac{3}{4}e^{\mathrm{i}(\mu_{B}+\mu_{A})} - \frac{3}{8}e^{-\mathrm{i}(\mu_{B}+2\mu_{A})} + \frac{3}{4}e^{-\mathrm{i}(\mu_{B}+\mu_{A})} + \frac{3}{8}e^{-2\mathrm{i}\mu_{A}}\right] + c.c..$$

$$(14)$$

The equivalent secular terms for the B wave may be obtained by letting  $\mu_A \to \mu_B$ ,  $\omega_{A0} \to \omega_{B0}$ , and  $A_0 \leftrightarrow B_0$ . In light of (13) and (14), there exist two possibilities for secularity when two harmonic plane waves are present:

Case 1.  $\{(\mu_B, \omega_{B0}) \in \mathbb{R}^2 : (\mu_B, \omega_{B0}) \neq a \cdot (\mu_A, \omega_{A0}) \}$  where a = 1/3 or 3, such that wave–wave interactions are produced due to amplitude products (the most general case); and

Case 2.  $\{(\mu_B, \omega_{B0}) \in \mathbb{R}^2 : (\mu_B, \omega_{B0}) = a \cdot (\mu_A, \omega_{A0}) \}$  where a = 1/3 or 3, such that wave–wave interactions are influenced by nonlinear frequency and wavenumber coupling, as in the long wavelength limit.

Case 1 is the most general case in which there are two waves present, and nonlinear coupling occurs only due to the products of amplitude coefficients  $A_0$  and  $B_0$ . Case 2 produces secular terms due to amplitude products *and* nonlinear coupling of both the frequency and wavenumber. The superharmonic (a = 3) and subharmonic cases (a = 1/3) are essentially the same due

![](_page_4_Picture_17.jpeg)

<span id="page-5-4"></span>to the arbitrary choice in naming the *A* and *B* waves. Due to additional secular terms arising in the long wavelength limit for the superharmonic (and subharmonic) case, a separate treatment is necessary.

### 2.3.1 Case 1: General wave-wave interactions

We suppose there are two waves A and B such that there is no wave—wave interaction due to special combinations of frequency and wavenumber (a=1/3 or 3). Then, two independent, complex secular terms arise which lead to a nonuniform expansion at  $O(\varepsilon^1)$  as in (13). Solvability conditions for a uniform expansion require these terms to vanish identically. Separating the real and imaginary components for each coefficient function and equating the resulting expressions to zero results in a set of four evolution equations:

<span id="page-5-0"></span>
$$\alpha'_{A} = 0,$$

$$\beta'_{A} = \frac{3}{8}\omega_{A0}^{3}\alpha_{A}^{2} + \frac{3}{4}\omega_{A0}\omega_{B0}^{2}\alpha_{B}^{2},$$

$$\alpha'_{B} = 0,$$

$$\beta'_{B} = \frac{3}{4}\omega_{A0}^{2}\omega_{B0}\alpha_{A}^{2} + \frac{3}{8}\omega_{B0}^{3}\alpha_{B}^{2}.$$
(15)

<span id="page-5-1"></span>Equations (15) lead to some interesting observations regarding the dispersion relationship when two waves interact. As with the single-wave case, the amplitudes  $\alpha_A$  and  $\alpha_B$  of both waves are constant at  $O(\varepsilon^1)$ . The separable equations  $\beta_A'$  and  $\beta_B'$ , when integrated, yield linear phase corrections that can be interpreted as frequency (and thus dispersion) corrections similar to (10). After integration, the expressions in (15) become

$$\alpha_{A} = \alpha_{A,0},$$

$$\beta_{A} = \beta_{A,1}\tau_{1} + \beta_{A,0},$$

$$\alpha_{B} = \alpha_{B,0},$$

$$\beta_{B} = \beta_{B,1}\tau_{1} + \beta_{B,0},$$
(16)

where, as before, one of the constants of integration  $\beta_{A,0}$  or  $\beta_{B,0}$  may be set to zero without any loss of generality, while the remaining constant controls the phase relationship between the two waves. The slopes of  $\beta_A$  and  $\beta_B$ , given by  $\beta_{A,1} = \beta_A'$  and  $\beta_{B,1} = \beta_B'$  in (16), determine the magnitude of the dispersion correction for each wave.

It is convenient to express the relationship between  $\omega_{A0}$  and  $\omega_{B0}$  by a single frequency on the linear dispersion curve  $\omega_0 \equiv \omega_{A0}$  and a frequency ratio r so that

both frequency corrections can be visualized on a single plot, and also so that r = 3 corresponds to Case 2 in the long wavelength limit:

$$r \equiv \frac{\omega_{B0}}{\omega_{A0}} \longrightarrow \omega_{B0} = r\omega_0.$$

<span id="page-5-3"></span><span id="page-5-2"></span>Furthermore, we assume without loss of generality that  $\omega_{A0} < \omega_{B0}$ , so that a single frequency  $\omega_0$  and ratio r > 1 describe the dispersion corrections rather than two frequencies. The frequency correction terms become

$$\omega_{A1} \equiv \beta_{A,1} = \frac{3}{8}\omega_0^3 \alpha_A^2 + \frac{3r^2}{4}\omega_0^3 \alpha_B^2,$$
 (17a)

$$\omega_{B1} \equiv \beta_{B,1} = \frac{3r}{4}\omega_0^3 \alpha_A^2 + \frac{3r^3}{8}\omega_0^3 \alpha_B^2.$$
 (17b)

The reconstituted dispersion relations, corrected to  $O(\varepsilon^1)$ , are given by

$$\omega_{A} = \sqrt{2 - 2\cos\mu_{A}} + \varepsilon \left(\frac{3}{8}\alpha_{A}^{2} + \frac{3r^{2}}{4}\alpha_{B}^{2}\right)$$

$$\times (2 - 2\cos\mu_{A})^{3/2} + O(\varepsilon^{2}), \qquad (18a)$$

$$\omega_{B} = \sqrt{2 - 2\cos\mu_{B}} + \varepsilon \left(\frac{3r}{4}\alpha_{A}^{2} + \frac{3r^{3}}{8}\alpha_{B}^{2}\right)$$

$$\times (2 - 2\cos\mu_{A})^{3/2} + O(\varepsilon^{2}), \qquad (18b)$$

so that each wave follows its own dispersion curve for a given frequency ratio r and given amplitudes  $\alpha_A$  and  $\alpha_B$ . Thus, when two waves nonlinearly interact, they form two amplitude and frequency dependent dispersion branches. In the absence of nonlinear wave—wave interaction, only a single dispersion curve exists.

Figure 2 shows two possible dispersion relation corrections for both hardening and softening chains. These dispersion curves were plotted using  $\alpha_A = \alpha_B = 4$ , r = 2.7 and  $\varepsilon = \pm 0.01$  to produce hardening and softening curves. Note that the dotted section of the  $\omega_A$  curve corresponds to values which would cause the superharmonic  $\omega_B = 2.7\omega_{A0} + \varepsilon\omega_{B1}$  to be in the band gap. This section of the curve is not explored here, but has been included as a visual aid to make the trends more apparent. At large amplitudes the single-wave corrected dispersion curve in (5), labeled  $\omega$  in Fig. 2, underestimates the magnitude of the correction to both  $\omega_A$  and  $\omega_B$ . The failure is especially evident at the edge of the Brillouin Zone.

![](_page_5_Picture_18.jpeg)

<span id="page-6-0"></span>Fig. 2 Multi-wave corrected dispersion curves compared with the linear curve  $\omega_0$  and the nonlinear single-wave corrected curve  $\omega$ 

![](_page_6_Figure_3.jpeg)

![](_page_6_Figure_4.jpeg)

<span id="page-6-2"></span>If the frequency correction terms  $\omega_{A1}$  and  $\omega_{B1}$  in (17a) and (17b) are interpreted as asymptotic frequency expansion terms as in the Lindstedt–Poincaré method, the ratios<sup>2</sup> of the  $O(\varepsilon^1)$  correction terms to specified  $O(\varepsilon^0)$  linear values  $(\omega_{A0}, \omega_{B0})$  for each wave provide an estimate for the expansion uniformity and a normalized measure of the dispersion correction. These ratios are

<span id="page-6-3"></span>
$$\rho_{A} = \left| \frac{\varepsilon \omega_{A1}}{\omega_{A0}} \right| \Rightarrow \left| \frac{\varepsilon \omega_{A1}}{\omega_{0}} \right| \\
= \frac{\left[ (3/8)\omega_{0}^{3}\alpha_{A}^{2} + (3r^{2}/4)\omega_{0}^{3}\alpha_{B}^{2} \right] |\varepsilon|}{\omega_{0}} \\
= \left[ \frac{3}{8}\alpha_{A}^{2} + \frac{3r^{2}}{4}\alpha_{B}^{2} \right] |\varepsilon|\omega_{0}^{2}, \tag{19}$$

$$\rho_{B} = \left| \frac{\varepsilon \omega_{B1}}{\omega_{B0}} \right| \Rightarrow \left| \frac{\varepsilon \omega_{B1}}{r\omega_{0}} \right| \\
= \frac{\left[ (3r/4)\omega_{0}^{3}\alpha_{A}^{2} + (3r^{3}/8)\omega_{0}^{3}\alpha_{B}^{2} \right] |\varepsilon|}{r\omega_{0}} \\
= \left[ \frac{3}{4}\alpha_{A}^{2} + \frac{3r^{2}}{8}\alpha_{B}^{2} \right] |\varepsilon|\omega_{0}^{2}. \tag{20}$$

<span id="page-6-1"></span>Hence,  $\alpha_A$ ,  $\alpha_B$ , r, and the quantity  $|\varepsilon|\omega_0^2$  determine the uniformity and magnitude of the correction terms. Uniform expansions correspond to when the ratios (19) and (20) are much less than one. Furthermore, since  $\rho_{A,B}$  represents a percentage of the linear frequency at specified point on the dispersion curve, we can calculate parameters to obtain a specific dispersion shift. Numerical simulations, presented in Sect. 3, have shown good agreement for  $\rho_{A,B}$  less than about 0.2.

# 2.3.2 Case 2: Long wavelength limit wave–wave interactions

<span id="page-6-5"></span>We previously mentioned in Case 2 that additional wave—wave interactions may be produced due to non-linear phase coupling when  $\omega_{B0} \approx 3\omega_{A0}$  and  $\mu_{B} \approx 3\mu_{A}$ . This corresponds to when the phase velocities of each wave are approximately equal so that the waves travel together. The closeness of  $(\mu_{B}, \omega_{B0})$  to  $3(\mu_{A}, \omega_{A0})$  can be formally represented using detuning quantities  $\bar{\sigma}_{\omega}$  and  $\bar{\sigma}_{\mu}$ , respectively, so that

$$\omega_{B0} = 3\omega_{A0} + \bar{\sigma}_{\omega} \text{ and } \mu_B = 3\mu_A + \bar{\sigma}_{\mu} \tag{21}$$

are exact relations. In the long wavelength limit,  $\bar{\sigma}_{\omega} = \bar{\sigma}_{\mu} = \bar{\sigma} \equiv \sigma \varepsilon$  to  $O(\varepsilon^3)$  where the detuning parameter  $\sigma$  is defined to be a real, positive number of order  $O(\varepsilon^0)$ . To show this, let  $\mu_A \to \varepsilon \hat{\mu}_A$  and  $\hat{\mu}_A \equiv O(\varepsilon^0)$ , so that  $\mu_A$  is in the long wavelength limit. Inverting the linear dispersion relation  $\omega_{B0}(\mu_B)$  gives

$$\mu_B(\omega_{B0}) = \cos^{-1}\left(1 - \frac{1}{2}\omega_{B0}^2\right).$$

<span id="page-6-4"></span>Substituting  $\omega_{B0} = 3\omega_{A0} + \sigma \varepsilon = 3\sqrt{2 - 2\cos(\varepsilon \hat{\mu}_A)} + \sigma \varepsilon$  in the previous expression and Taylor expanding  $\mu_B(\hat{\mu}_A; \varepsilon, \sigma)$  in the small parameter  $\varepsilon$  gives

$$\mu_B(\hat{\mu}_A; \varepsilon, \sigma) = (3\hat{\mu}_A + \sigma)\varepsilon + O(\varepsilon^3).$$

Thus.

$$\mu_B \approx 3\mu_A + \bar{\sigma}. \tag{22}$$

Hence, Case 2 may be realized for small  $\mu_A$  (and consequently small  $\omega_{A0}$ ) that are in the long wavelength limit. This one-to-one ratio of frequency to wavenumber is expected since the slope of the non-dimensional

![](_page_6_Picture_19.jpeg)

<sup>&</sup>lt;sup>2</sup>More specifically, the absolute value of the ratios in the event that  $\varepsilon < 0$ .

linear dispersion relation is approximately 1 in the long wavelength limit where  $\mu_A$  approaches zero.

One more implication of (22) arises when the substitutions (21) are made for  $\omega_{B0}$  and  $\mu_B$  in the  $O(\varepsilon^0)$  solution (12b)—an additional *long spatial scale*  $J_1 \equiv \varepsilon j$  arises. Equation (12b) for Case 2, after substitutions, becomes

$$x_{j,B}^{(0)}(\tau_{0}, \tau_{1}, J_{1})$$

$$= \frac{B_{0}(\tau_{1})}{2} e^{i(\mu_{B}j - \omega_{B0}\tau_{0})} + c.c.$$

$$= \frac{B_{0}(\tau_{1})}{2} e^{i(3\mu_{A} + \bar{\sigma})j} e^{-i(3\omega_{A0} + \bar{\sigma})\tau_{0}} + c.c.$$

$$= \frac{B_{0}(\tau_{1})}{2} e^{i(3\mu_{A}j + \sigma J_{1})} e^{-i(3\omega_{A0}\tau_{0} + \sigma \tau_{1})} + c.c..$$
(23)

From this point forward the procedure follows the development in Sect. 2.3.1. However, secular terms are instead proportional to  $\exp(i\mu_A j - i\omega_{A0}\tau_0)$  and  $\exp(i3\mu_A j - i3\omega_{A0}\tau_0)$  so that the secular terms arise from both (13) and (14). Separating the real and imaginary parts of the two solvability conditions yields a set of strongly coupled, nonlinear evolution equations with long spatial ( $J_1$ ) and temporal dependence ( $\tau_1$ ). It happens that the slow time variable  $\tau_1$  exists in each evolution equation such that they may be written autonomously via substitution of a new variable  $\gamma(\tau_1)$  and its differential equation

<span id="page-7-0"></span>
$$\gamma = -3\beta_A + \beta_B + \sigma \tau_1 - \sigma J_1, \tag{24a}$$

$$\gamma' = -3\beta_A' + \beta'B + \sigma. \tag{24b}$$

Using this fact, the evolution equations may be written in a fashion similar to (15) as

$$\alpha_A' = \frac{3}{2} \alpha_A^2 \alpha_B \xi \sin(\gamma), \tag{25a}$$

$$\alpha_B' = -\frac{1}{6}\alpha_A^3 \xi \sin(\gamma), \tag{25b}$$

<span id="page-7-1"></span>
$$\beta_A' = -\frac{3}{2}\alpha_A \alpha_B \xi \cos(\gamma) + a_1 \alpha_A^2 + a_2 \alpha_B^2, \qquad (25c)$$

$$\beta_B' = -\frac{1}{6} \frac{\alpha_A^3}{\alpha_B} \xi \cos(\gamma) + b_1 \alpha_A^2 + b_2 \alpha_B^2 - \sigma,$$
 (25d)

where the coefficients  $a_1$ ,  $a_2$ ,  $b_1$ ,  $b_2$  and  $\xi$  are most simply expressed as functions of  $\omega_{A0} \equiv \omega_0$  given by

$$a_1 = \frac{3}{8}\omega_0^3$$

![](_page_7_Picture_14.jpeg)

$$b_{1} = \frac{1}{4}\omega_{0}^{7} - \frac{3}{2}\omega_{0}^{5} + \frac{9}{4}\omega_{0}^{3}$$

$$a_{2} = \frac{3}{4}\omega_{0}^{7} - \frac{9}{2}\omega_{0}^{5} + \frac{27}{4}\omega_{0}^{3}$$

$$b_{2} = \frac{1}{8}\omega_{0}^{11} - \frac{3}{2}\omega_{0}^{9} + \frac{27}{4}\omega_{0}^{7} - \frac{27}{2}\omega_{0}^{5} + \frac{81}{8}\omega_{0}^{3}$$

$$\xi = -\frac{1}{4}\omega_{0}^{5} + \frac{3}{4}\omega_{0}^{3}$$
(26)

The large state space of (25) complicates the analysis. Some general observations can be made, though, about the character of the solution in certain limiting cases. The coefficients  $a_1$ ,  $a_2$ ,  $b_1$ , and  $b_2$  occur in the general form  $(a,b)_{1,2} = \sum_n c_n (-1)^{n+1} \omega_0^{2n+1}$ , where  $c_n > c_{n+1}$  by inspection. Thus, for low frequencies in the long wavelength limit the  $c_1\omega_0^3$  terms dominate. Comparison of (26) with (17a) and (17b) shows that these leading order terms are identical for r=3, and thus the primary difference in the resulting evolution equations of Case 1 and Case 2 is the existence of the  $\xi \sin(\gamma)$  and  $\xi \cos(\gamma)$  terms in (25). This term is responsible for coupling the  $\alpha'_A$  and  $\alpha'_B$  evolution equations with the  $\beta'_A$  and  $\beta'_B$  equations, and is usually negligible for small  $\omega_0$  (and hence small  $\xi$ ).

Numerical integration of the evolution equations in (25) provides additional insight and verification to the previous assertions. The solutions of the differential equations depend on the initial values  $\alpha_A(0) = \alpha_{A,0}$ ,  $\alpha_B(0) = \alpha_{B,0}$ ,  $\beta_A(0) = \beta_{A,0}$ , and  $\beta_B(0) = \beta_{B,0}$ , and the parameters  $\omega_0$ ,  $\sigma$ , and  $\varepsilon$ . Some possible solutions for the evolution equations are illustrated in Fig. 3 for  $\alpha_{A,0} = \alpha_{B,0} = \alpha_0 = [1,2,5]$ ,  $\beta_{A,0} = \beta_{B,0} = 0$ , and  $\omega_0 = 0.5$ ,  $\sigma = 0$ , and  $\varepsilon = 0.01$ .

The frequency was chosen to illustrate the oscillations clearly; however,  $\omega_0 = 0.5$  is at the edge of the long wavelength limit. The amplitudes  $\alpha_A$  and  $\alpha_B$ tend to oscillate periodically about some fixed point, while the phase corrections  $\beta_A$  and  $\beta_B$  tend to oscillate about some linear functions. Therefore, in the long wavelength limit the wave-wave interaction gives rise to amplitude and frequency modulation. Based on numerical observation, the modulations are negligible for small frequencies in the long wavelength limit so that  $\alpha'_A = 0$ ,  $\alpha'_B = 0$ , and  $\beta'_A$  and  $\beta'_B$  are both constant to  $O(\varepsilon^1)$ . Therefore, even when  $\omega_{A0}$  and  $\omega_{B0}$  are commensurate or nearly-commensurate, long wavelength limit wave-wave interactions may be negligible, and the corrected dispersion relations obtained for Case 1 provide a good (and potentially more useful) approximation.

<span id="page-8-1"></span>![](_page_8_Figure_2.jpeg)

<span id="page-8-2"></span><span id="page-8-0"></span>**Fig. 4** A 10% shift at *ωB*<sup>0</sup> = 1*.*8 can be achieved injecting high-amplitude, low-frequency waves, or low-amplitude, high-frequency waves

### **3 Numerical verification and discussion**

Numerical simulation of the mass–spring system depicted in Fig. [1](#page-2-2) and governed by ([2\)](#page-2-5) verifies the presented asymptotic approach [\[14](#page-9-13)]. In deriving corrections to the linear dispersion curve, it was assumed that two interacting waves with *O(ε*0*)* amplitudes existed in a one-dimensional, nonlinear medium away from any forcing. By imposing plane-wave initial conditions and allowing a simulation to run for 100–200 non-dimensional "seconds," a space-time matrix of displacements was produced. Points on the dispersion curve were located by performing a two-dimensional Fast Fourier Transform (2D FFT) on the displacement matrix.

Figure [4](#page-8-2) illustrates how the frequency ratio *r* may be considered as a design parameter in addition to the wave amplitudes for tunable acoustic metamaterials. We seek to obtain a 10% (*ρB* = 0*.*1) frequency shift for a *B* wave with amplitude *αA* = 2 and frequency *ωB*0*(μB)* = *rω*<sup>0</sup> = 1*.*8. Then, the parameters *αA* and *r* may be chosen freely to obtain *ρB* = 0*.*1 in ([20\)](#page-6-3) subject only to the restriction that *r >* 1 and *αA* ∈ R is of order *O(ε*0*)*. The parameter sets [*αA* = 4*.*36, *r* = 3] and [*αA* = 8, *r* = 5*.*5] were chosen such that these criteria were satisfied. The ratio *ρB* = 0*.*1 determines the dispersion curve of the *B* wave for *any* set of values *αA* and *r*. However, the dispersion curve for the *A* wave varies depending on the choice of parameters according to ([19\)](#page-6-2). Several simulations were run and overlaid in Fig. [4a](#page-8-2). The zoomed view in Fig. [4b](#page-8-2) plots the two different dispersion branches that the *A* wave follows for different choices of the parameters *αA* and *r*.

![](_page_8_Picture_8.jpeg)

The ratios  $\rho_A$  and  $\rho_B$  that were introduced earlier to estimate the uniformity of the expansion increase with  $\omega_0^2$ . As the frequency  $\omega_B = r\omega_0$  increases toward the cut-off frequency, the theoretical frequency corrections become less accurate. Numerical observation suggests that the propensity of the spring–mass chain to generate additional large-amplitude harmonics (comparable to the amplitude of the two injected waves) is responsible for this, owing to additional wave–wave interactions that are not accounted for herein

#### 4 Conclusion

A multiple time scales approach has been shown to yield accurate dispersion characteristics for wave—wave interactions in a discrete nonlinear medium with a cubic material nonlinearity. Evolution equations were derived for a monoatomic chain for both the single-wave and multi-wave scenarios.

The Lindstedt–Poincaré method and multiple time scales approach result in the same dispersion corrections when the resulting evolution equations are autonomous. However, the multiple time scales approach provides more generality than the Lindstedt-Poincaré method in dealing with time-varying amplitude and phase. In most cases, the two-wave interaction scenario results in a different time-invariant dispersion branch for each wave. These branches are parameterized by the wave amplitudes  $(\alpha_A, \alpha_B)$ , the frequency ratio r, and the magnitude of the nonlinearity. Additional interactions may take place in the long wavelength limit due to frequency and wavenumber coupling between two waves. These interactions result in amplitude and frequency modulations, although transient effects such as superharmonic generation may dominate such interactions.

Still, in the long wavelength limit and for small amplitudes, the single-wave dispersion correction in (10) provides a reasonable estimate for the dispersion behavior. Away from the long wavelength limit, such as near the edge of the Brillouin Zone and at larger amplitudes, the single-wave dispersion analysis fails to yield accurate frequency corrections. Hence, the wave-wave interaction analysis presented herein provides a more accurate and complete estimation of the monoatomic chain's dispersion in such cases.

Several directions may be pursued for follow-on work. A three-wave analysis (or more) may provide

more design latitude whereby additional wave—wave interactions allow for further tailoring of the dispersion curves. Other 1D chains with more complex unit cells, such as the diatomic chain, may exhibit further richness in behavior. In two- and three-dimensional periodic lattices the wave—wave interactions may significantly alter group velocity and beaming behavior.

<span id="page-9-3"></span><span id="page-9-0"></span>**Acknowledgements** The authors would like to thank Dr. Eduardo A. Misawa and the National Science Foundation for supporting this research under Grant No. (CMMI 0926776).

#### <span id="page-9-11"></span><span id="page-9-4"></span>References

- Asfar, O.R., Nayfeh, A.H.: The application of the method of multiple scales to wave propagation in periodic structures. SIAM Rev. 25(4), 455–480 (1983)
- <span id="page-9-7"></span> Bertoldi, K., Boyce, M.C.: Mechanically triggered transformations of phononic band gap elastomeric structures. Phys. Rev. B 77 (2008)
- <span id="page-9-10"></span> Chakraborty, G., Mallik, A.K.: Dynamics of a weakly nonlinear periodic chain. Int. J. Non-Linear Mech. 36(2), 375– 389 (2001)
- <span id="page-9-5"></span> Daraio, C., Nesterenko, V.F., Herbold, E.B., Jin, S.: Strongly nonlinear waves in a chain of Teflon beads. Phys. Rev. E 72(1), 016603 (2005)
- <span id="page-9-1"></span> Davis, W.O., Pisano, A.P.: Nonlinear mechanics of suspension beams for a micromachined gyroscope. In: International Conference on Modeling and Simulation of Microsystems, March (2001)
- <span id="page-9-8"></span> Rushchitsky, J.J., Cattani, C.: Evolution equations for plane cubically nonlinear elastic waves. Int. Appl. Mech. 40(1), 70–76 (2004)
- <span id="page-9-9"></span>Rushchitsky, J.J., Savel'eva, E.V.: On the interaction of cubically nonlinear transverse plane waves in an elastic material. Int. Appl. Mech. 42(6), 661–668 (2006)
- <span id="page-9-12"></span> Jang, J.-H., Ullal, C.K.U., Gorishnyy, T., Tsukruk, V.V., Thomas, E.L.: Mechanically tunable three-dimensional elastomeric network/air structures via interference lithography. Nano Lett. 6(4), 740–743 (2006)
- <span id="page-9-2"></span> Kaajakari, V., Mattila, T., Lipsanen, A., Oja, A.: Nonlinear mechanical effects in silicon longitudinal mode beam resonators. Sens. Actuators A Phys. 120(1), 64–70 (2005)
- <span id="page-9-6"></span> Kaajakari, V., Mattila, T., Oja, A., Seppä, H.: Nonlinear limits for single-crystal silicon microresonators. J. Microelectromech. Syst. 13(5), 715–724 (2004)
- <span id="page-9-13"></span>Kittel, C.: Introduction to Solid State Physics, 5th edn. Wiley, New York (1976)
- Liang, B., Yuan, B., Cheng, J.-C.: Acoustic diode: rectification of acoustic energy flux in one-dimensional systems. Phys. Rev. Lett. 103(10), 104301 (2009)
- Marathe, A., Chatterjee, A.: Wave attenuation in nonlinear periodic structures using harmonic balance and multiple scales. J. Sound Vib. 289(4–5), 871–888 (2006)
- Narisetti, R.K., Leamy, M.J., Ruzzene, M.: A perturbation approach for predicting wave propagation in onedimensional nonlinear periodic structures. ASME J. Vib. Acoustics 132(3), 031001 (2010)

![](_page_9_Picture_24.jpeg)

- <span id="page-10-12"></span><span id="page-10-7"></span><span id="page-10-5"></span><span id="page-10-1"></span>15. Narisetti, R.K., Ruzzene, M., Leamy, M.J.: A perturbation approach for analyzing dispersion and group velocities in two-dimensional nonlinear periodic lattices. ASME J. Vib. Acoustics (submitted)
- <span id="page-10-2"></span>16. Nayfeh, A.H., Mook, D.T.: Nonlinear Oscillations. Wiley, New York (1979)
- <span id="page-10-0"></span>17. Nayfeh, A.H., Rice, M.H.: On the propagation of disturbances in a semi-infinite one-dimensional lattice. Am. J. Phys. **40**(3), 469–470 (1972)
- <span id="page-10-9"></span>18. Olsson, R.H., El-Kady, I.: Microfabricated phononic crystal devices and applications. Meas. Sci. Technol. **20**(1), 012002 (2009)
- 19. Olsson, R.H. III, El-Kady, I.F., Su, M.F., Tuck, M.R., Fleming, J.G.: Microfabricated VHF acoustic crystals and waveguides. Sens. Actuators A, 87–93 (2008)
- 20. Page, J., Sukhovich, A., Yang, S., Cowan, M., van der Biest, F., Tourin, A., Fink, M., Liu, Z., Chan, C., Sheng, P.: Phononic crystals. Solid State Phys. **241**(15), 3454–3462 (2004)
- 21. Peyrard, M., Kruskal, M.D.: Kink dynamics in the highly discrete sine-Gordon system. Physica D **14**(1), 88–102 (1984)

- <span id="page-10-10"></span><span id="page-10-8"></span><span id="page-10-6"></span><span id="page-10-3"></span>22. Rothos, V., Vakakis, A.: Dynamic interactions of traveling waves propagating in a linear chain with an local essentially nonlinear attachment. Wave Motion **46**(3), 174–188 (2009)
- <span id="page-10-11"></span>23. Rushchitsky, J.J.: Interaction of waves in solid mixtures. Appl. Mech. Rev. **52**(2), 35–74 (1999)
- <span id="page-10-4"></span>24. Sigmund, O., Jensen, J.S.: Systematic design of phononic band-gap materials and structures by topology optimization. Philos. Tran., Math. Phys. Eng. Sci. **361**(1806), 1001– 1019 (2003)
- 25. Vakakis, A.F., King, M.E.: Nonlinear wave transmission in a monocoupled elastic periodic system. J. Acoust. Soc. Am. **98**(3), 1534–1546 (1995)
- 26. Vakakis, A.F., King, M.E.: Resonant oscillations of a weakly coupled, nonlinear layered system. Acta Mech. **128**(1), 59–80, 03 (1998)
- 27. Yun, Y., Miao, G., Zhang, P., Huang, K., Wei, R.: Nonlinear acoustic wave propagating in one-dimensional layered system. Phys. Lett. A **343**(5), 351–358 (2005)

![](_page_10_Picture_15.jpeg)