# **Internally resonant wave energy exchange in weakly nonlinear lattices and metamaterials**

Matthew D. Fronk\* and Michael J. Leam[y](https://orcid.org/0000-0002-9914-640X) †

*School of Mechanical Engineering, Georgia Institute of Technology, 771 Ferst Drive NW, Atlanta, Georgia 30332, USA*

![](_page_0_Picture_4.jpeg)

(Received 18 June 2019; published 20 September 2019)

This paper presents a multiple-scales analysis approach capable of capturing internally resonant wave interactions in weakly nonlinear lattices and metamaterials. Example systems considered include a diatomic chain and a locally resonant metamaterial-type lattice. At a number of regions in the band structure, both the frequency and wave number of one nonlinear plane wave may relate to another in a near-commensurate manner (such as in a 2:1 or 3:1 ratio) resulting in an internal resonance mechanism. As shown herein, nonlinear interactions in the lattice couple these waves and enable energy exchange. Near such internal resonances, previously derived higher-order dispersion corrections for single plane wave propagation may break down, leading to singularities in the predicted nonlinear dispersion relationships. Using the presented multiple-scales approach and the two example systems, this paper examines internal resonance occurring (i) within the same branch and (ii) between different branches of the band structure, resolving the aforementioned singularity issue while capturing energy exchange. The multiple-scales evolution equations, together with a local stability analysis, uncover multiple stable fixed points associated with periodic energy exchange between internally resonant propagating modes. Response results generated using direct numerical simulation verify the perturbation-based predictions for amplitude-dependent dispersion corrections and slow-scale energy exchange; importantly, these comparisons verify the exchange frequency predicted by the multiple-scales approach.

#### DOI: [10.1103/PhysRevE.100.032213](https://doi.org/10.1103/PhysRevE.100.032213)

## **I. INTRODUCTION**

Nonlinear periodic structures have been an area of increasing focus due to their ability to filter and guide waves as a function of their amplitude [\[1–6\]](#page-13-0). Key to analyzing wave propagation in these materials is their dispersion relationships, which quantify passbands in which temporal and spatial frequencies are related in a nontrivial manner, as well as frequency band gaps in which propagation is forbidden.

Several studies have derived expressions governing the amplitude-dependent shifting of band diagrams due to hardening- and softening-type nonlinearities in phononic and photonic systems. Vakakis and King developed an approach to studying both the propagation and attenuation zones of plane waves in nonlinear monocoupled lattices [\[7\]](#page-13-0). Propagating waves were assessed through a multiple-scales analysis in both space and time whereas attenuating waves in stop bands were investigated by studying the synchronous motion of unit cells and seeking the associated nonlinear normal modes. Chakraborty and Mallik employed small perturbations of a plane wave's complex propagation constant to develop amplitude-dependent bounds on the passband of an infinite monatomic lattice [\[8\]](#page-13-0). They analyzed the finite counterpart of the system through a phase closure principle. Other techniques for deriving band structures in nonlinear periodic media include invariant manifold [\[9\]](#page-13-0), mapping [\[10\]](#page-13-0), and hybrid multiple-scales and harmonic balance [\[11\]](#page-13-0) approaches. Analogously, the optics community has examined self- and cross Kerr shifts of plasma resonances in weakly nonlinear Josephson junction chains [\[12,13\]](#page-13-0). Recently, a multiple-timescales analysis has studied the self-interaction [\[14\]](#page-13-0) and wave-wave [\[15\]](#page-13-0) interaction of plane waves in weakly nonlinear lattices, developing closed-form, amplitude-dependent corrections to the underlying linear dispersion curves. When extended to higher orders, such corrections have been shown to become singular at frequencies associated with internal resonance, which causes uncertainty in the actual size of the dispersion shifting as well as the findings of stability and waveform invariance at these frequencies [\[16,17\]](#page-13-0). Nonlinearities in the constitutive equations governing phonon thermal transport have also received attention, notably alterations to their phase speed [\[18\]](#page-13-0) and stability [\[19\]](#page-13-0). The internal-resonance analysis reported in this work may inform the design of thermal systems that induce periodic heat exchange between modes at commensurate frequencies, or the proposed invariant plane waves may inspire technology capable of scattering-free phonon heat transfer.

Little attention has been given to internally resonant wave interactions in nonlinear media. Considering commensurate wave-wave interaction of bulk waves in continuous solids with cubic nonlinearities, Rushchitsky *et al.* employed the method of slowly varying amplitude to derive spatial evolution equations for the amplitude exchange and energy conservation laws for the interacting waves [\[20,21\]](#page-13-0). Manktelow *et al.* investigated wave-wave interactions in a nonlinear monatomic lattice, with the aim of controlling the frequency shift of a primary wave in the presence of a secondary wave, each occupying a unique space on the lattice's band structure [\[22\]](#page-13-0). A special case in which the two waves possess commensurate frequency content (in the long wavelength

<sup>\*</sup>mfronk3@gatech.edu

<sup>†</sup>Corresponding author: michael.leamy@me.gatech.edu

<span id="page-1-0"></span>limit) was examined, and their slow-scale energy exchange was remarked upon but was not of primary interest for their dispersion analysis. In [23,24], a series of studies focused on the harmonic excitation of a precompressed granular chain in the regime of weak quadratic stiffness with an extension to continuous layered systems in [25]. Using a perturbation expansion, the spatiotemporal higher-harmonic generation was derived, notably possessing a periodic amplitude exchange between the fundamental and second harmonic for the case of propagative driving frequencies. By contrast, this study introduces two waves at the zeroth-order anticipating internal resonance between them, seeking periodic plane wave solutions rather than the generation of higher harmonics from forcing, which appeared at higher-order spectral content in [23–25]. Additionally, this work considers the stability of the wave interactions and amplitude-dependent dispersion shifting at internally resonant frequencies. Frandsen and Jensen derived perturbation-based expressions for higher-harmonic amplitude generation from self-interacting waves in a diatomic lattice with weak cubic stiffness nonlinearities [26]. While they documented close agreement between analytical predictions and numerical simulations of higher-harmonic generation, they reported an inability to predict the large energy transfer for waves in the long wavelength limit that experience internal resonance. Panigrahi et al. explored internal resonances in the long wavelength limit of monatomic lattices with quadratic stiffness nonlinearities [27]. Their multiplescales approach yielded evolution equations governing the amplitudes and phases of the interacting waves. A phase portrait, aided by a local stability analysis, revealed transitions from oscillatory to emergent evolution of the interacting wave amplitudes which was validated qualitatively in numerical simulations. The study in [27] does not discuss the effect of internal resonance on dispersion relationships, which is explicitly addressed herein.

This work presents a multiple-scales analysis of internally resonant wave energy exchange in weakly nonlinear lattices, with the specific aim of capturing the energy exchange between propagating modes. This is a multiple-scales analysis approach that predicts the temporal modulation for internally resonant plane waves in discrete lattices with multiple degrees of freedom per unit cell, for both 2:1 and 3:1 internal resonance. Also, a dispersion analysis is carried out for internally resonance plane waves in nonlinear lattices, developing expressions that are valid for frequencies in which previous higher-order perturbation analyses for a single plane wave break down. The analysis is carried out for example nonlinear systems, to include periodic layered systems and periodic locally resonant systems (i.e., metamaterials). For these two classes of systems, using comparisons to direct numerical simulation, very good agreement is documented in (i) the perturbation-predicted exchange frequency and (ii) wave envelope amplitudes predicted by the presented approach.

### II. SYSTEM DESCRIPTION

Figure 1 displays a prototypical, weakly nonlinear layered system whose governing equations may admit internally resonant waves. Such a system can model wave propagation

![](_page_1_Picture_6.jpeg)

FIG. 1. Nonlinear diatomic chain considered in this work. Bimaterial rod that this system may model (a) and its mass-spring representation (b).

in three-dimensional NaCl crystals along the (100) direction [28], for example, and discretized bimaterial rods [29,30]. The corresponding unit cell contains alternating masses ( $m_a$  and  $m_b$ ) coupled with linear ( $k_1$ ), quadratic ( $k_2$ ), and cubic ( $k_3$ ) stiffness.

A locally resonant lattice is also considered in which a network of primary masses contains embedded resonators, as illustrated in Fig. 2. Coupling between the primary mass and its internal resonator, as well as between different primary masses, contains linear, quadratic, and cubic stiffness terms. Such a system is used for the analysis of elastic metamaterials with negative effective properties and enhanced attenuation capabilities [31–33].

For both lattices, the equation of motion governing the *j*th unit cell can be compactly represented in matrix form,

$$\mathbf{M}\ddot{\mathbf{x}}_{j} + \sum_{p=-1}^{+1} [\mathbf{K}^{(p)} \mathbf{x}_{j+p}] + \varepsilon \mathbf{f}_{NL}(\mathbf{x}_{j}, \mathbf{x}_{j-1}, \mathbf{x}_{j+1}) = \mathbf{0},$$

$$j = -\infty \cdots \infty,$$
(1)

where  $\mathbf{x}_j = [^{x_a(j,\,t)}_{x_b(j,\,t)}]$  represents the displacement from equilibrium of each degree of freedom and  $(\cdot)$  denotes time differentiation. For both cases in Figs. 1 and 2, the mass matrices simplify to

$$\mathbf{M} = \begin{bmatrix} m_a & 0\\ 0 & m_b \end{bmatrix} \tag{2}$$

![](_page_1_Picture_14.jpeg)

FIG. 2. Nonlinear locally resonant lattice. Plane wave propagation may occur perpendicular to the faces of the box-shaped unit cells containing spherical inclusions (a). Spring-mass representation for plane wave propagation along a single direction (b).

<span id="page-2-0"></span>Stiffness matrices for the lattice in Fig. 1 are given by

$$\mathbf{K}^{(0)} = \begin{bmatrix} 2k_1 & -k_1 \\ -k_1 & 2k_1 \end{bmatrix},\tag{3}$$

$$\mathbf{K}^{(-1)} = \begin{bmatrix} 0 & -k_1 \\ 0 & 0 \end{bmatrix},\tag{4}$$

$$\mathbf{K}^{(1)} = \begin{bmatrix} 0 & 0 \\ -k_1 & 0 \end{bmatrix}. \tag{5}$$

The associated stiffness matrices for the lattices with resonators in Fig. 2 are given by

$$\mathbf{K}^{(0)} = \begin{bmatrix} 2k_{1a} & -k_{1b} \\ -k_{1b} & k_{1b} \end{bmatrix},\tag{6}$$

$$\mathbf{K}^{(-1)} = \mathbf{K}^{(1)} = \begin{bmatrix} 0 & -k_{1a} \\ 0 & 0 \end{bmatrix}. \tag{7}$$

All interactions from nonlinear stiffness terms combine in the  $\mathbf{f}_{NL}$  vector, which is ordered to be small with the bookkeeping device  $\varepsilon$ . For the diatomic lattice, the nonlinear terms are

$$\mathbf{f_{NL}} = \begin{cases} -k_2 [x_b(j) - x_a(j)]^2 + k_2 [x_b(j-1) - x_a(j)]^2 - k_3 [x_b(j) - x_a(j)]^3 - k_3 [x_b(j-1) - x_a(j)]^3 \\ -k_2 [x_a(j+1) - x_b(j)]^2 + k_2 [x_a(j) - x_b(j)]^2 - k_3 [x_a(j+1) - x_b(j)]^3 - k_3 [x_a(j) - x_b(j)]^3 \end{cases}.$$
(8)

The locally resonant lattice possesses the following nonlinear terms:

$$\mathbf{f_{NL}} = \begin{cases} -k_{2a} [x_a(j+1) - x_a(j)]^2 + k_{2a} [x_a(j-1) - x_a(j)]^2 - k_{3a} [x_a(j+1) - x_a(j)]^3 - k_{3a} [x_a(j-1) - x_a(j)]^3 \\ -k_{2b} [x_b(j) - x_a(j)]^2 - k_{3b} [x_b(j) - x_a(j)]^3 \end{cases}.$$
(9)

In general, quadratic (i.e.,  $k_2$  or  $k_{2a}$ ,  $k_{2b}$ ) and cubic (i.e.,  $k_3$  or  $k_{3a}$ ,  $k_{3b}$ ) stiffness may arise from a Taylor series expansion of an arbitrary nonlinear interaction.

## III. ANALYSIS APPROACH

A multiple-scales technique is next proposed for investigating internal resonances appearing in Eq. (1). Timescales of successively slower progression are introduced,

$$t = T_0 + \varepsilon T_1 + \dots \varepsilon^n T_n, \tag{10}$$

with their associated time derivatives,

$$(\dot{}) = D_0() + \varepsilon D_1() + \ldots + \varepsilon^n D_n(), \tag{11}$$

where  $D_n()$  denotes differentiation with respect to  $T_n$ . Additionally, the solution is expanded in a power series:

$$\mathbf{x}_j = \mathbf{x}_j^{(0)} + \varepsilon \mathbf{x}_j^{(1)} + \ldots + \varepsilon^n \mathbf{x}_j^{(n)}. \tag{12}$$

Using the expansions in Eqs. (11) and (12), Eq. (1) can be separated into a series of cascading differential equations by collecting matching orders of  $\varepsilon$ . The first two equations are

$$\varepsilon^{0}: \mathbf{M}\ddot{\mathbf{x}}_{j}^{(0)} + \sum_{p=-1}^{+1} \left[ \mathbf{K}^{(p)} \mathbf{x}_{j+p}^{(0)} \right] = 0, \tag{13}$$

$$\varepsilon^{1}: \mathbf{M}\ddot{\mathbf{x}}_{j}^{(1)} + \sum_{p=-1}^{+1} \left[ \mathbf{K}^{(p)} \mathbf{x}_{j+p}^{(1)} \right] = -2D_{0}D_{1}\mathbf{M}\mathbf{x}_{j}^{(0)} - \mathbf{f}_{NL} \left( \mathbf{x}_{j}^{(0)}, \mathbf{x}_{j-1}^{(0)}, \mathbf{x}_{j+1}^{(0)} \right). \tag{14}$$

In general, Eq. (13) admits a linear combination of Bloch waves, each of the form

$$\mathbf{x}_{i}^{(0)} = \frac{1}{2} \mathbf{\Phi}(\omega_0) A e^{i\omega_0 T_0} e^{-i\mu j} + \text{c.c.}, \tag{15}$$

where A denotes the complex amplitude and c.c. denotes the complex conjugate of all preceding terms. The temporal frequency  $(\omega_0)$  and nondimensional wave number  $(\mu)$  are related by the lattice's dispersion curve, which is found by substituting Eq. (15)

<span id="page-3-0"></span>into (13) and then solving the resulting eigenvalue problem [16].

$$\omega_{0} = \sqrt{\frac{k_{1}(m_{b} + m_{a})}{m_{a}m_{b}}} \mp \frac{k_{1}}{2} \sqrt{\frac{4m_{b}^{2} + 4m_{a}^{2} + 8m_{a}m_{b}\cos\mu}{m_{a}^{2}m_{b}^{2}}},$$

$$\omega_{0} = \frac{1}{2} \left\{ \frac{2}{m_{a}m_{b}} \left[ (-2k_{1a}m_{b}\cos\mu + 2k_{1a}m_{b} + k_{1b}m_{a} + k_{1b}m_{b}) \right.$$

$$\mp \left( 4k_{1a}^{2}m_{b}^{2}\cos^{2}\mu - 8k_{1a}^{2}m_{b}^{2}\cos\mu + 4m_{a}m_{b}k_{1a}k_{1b}\cos\mu - 4m_{b}^{2}k_{1a}k_{1b}\cos\mu + 4k_{1a}^{2}m_{b}^{2} \right.$$

$$\left. -4k_{1a}k_{1b}m_{a}m_{b} + 4k_{1a}k_{1b}m_{b}^{2} + k_{1b}^{2}m_{a}^{2} + 2k_{1b}^{2}m_{a}m_{b} + k_{1b}^{2}m_{b}^{2} \right)^{\frac{1}{2}} \right]^{\frac{1}{2}}.$$

$$(16)$$

Equations (16) and (17) provide the zero-order dispersion relationships for the diatomic and locally resonant chains, respectively. Additionally, displacements within each unit cell take on synchronous motion associated with the wave propagation mode shape  $\phi$ ,

$$\mathbf{\Phi} = \begin{bmatrix} 1 \\ -\omega_0^2 m_a + 2k_1 \\ \frac{1}{k_1(1 + e^{i\mu})} \end{bmatrix}, \tag{18}$$

$$\mathbf{\Phi} = \begin{bmatrix} 1 \\ \frac{-m_a \omega_0^2 + 2k_{1a}(1 - \cos \mu) + k_{1b}}{k_{1b}} \end{bmatrix}, \tag{19}$$

which correspond to Eqs. (16) and (17), respectively. Figure 3 displays the zeroth-order dispersion relationships for the example systems. Since two degrees of freedom exist per unit cell, two distinct branches form their band structures: a lower, or acoustic branch and an upper, or optical branch, separated by a band gap.

In prior work, the authors noted that higher-order analysis of single-frequency nonlinear plane waves breaks down for frequencies associated with internal resonance [16,17]. This phenomenon occurs when the considered wave, represented by A, is in a nearly commensurate relationship with another wave, represented by B. This may occur whenever  $\mu_B \approx$ 

![](_page_3_Figure_9.jpeg)

FIG. 3. Zeroth-order dispersion curves for the diatomic (a,b) and locally resonant (c,d) lattices. Internal resonance can occur within the same branch or between different branches and commonly takes the form of 2:1 or 3:1.

 $\frac{n_2}{n_1}\mu_A$  and  $\omega_{0,B} \approx \frac{n_2}{n_1}\omega_{0,A}$ , where  $n_1$  and  $n_2$  are integers. As established herein, it can occur within the same branch or between different branches. Common forms of internal resonance are 2:1 and 3:1, which are enabled by quadratic and cubic stiffness interactions, respectively, and such forms are principally studied in this work. Figure 3 depicts these internal resonances as they appear in relation to band structure.

In the long wavelength limit, the near-linear slope of the dispersion curve technically produces many internal resonances. However, higher-order internal resonances, e.g., 5:3:1, can be expected to exhibit weaker interactions among the multiple wave propagation modes. Spectral content from weak stiffness nonlinearities naturally decreases at increasingly higher harmonics. Thus, the interaction exclusively between two waves will be considered herein as their amplitudes will be dominant.

Anticipating internal resonance among two waves, an A and B wave are introduced at the zeroth order:

$$\mathbf{x}_{j}^{(0)} = \frac{1}{2} \mathbf{\Phi}(\omega_{0,A}) A e^{i\omega_{0,A} T_{0}} e^{-i\mu_{A} j}$$

$$+ \frac{1}{2} \mathbf{\Phi}(\omega_{0,B}) B e^{i\omega_{0,B} T_{0}} e^{-i\mu_{B} j} + \text{c.c.}$$
(20)

For n:1 internal resonance, the frequencies of the A wave and B wave are related by

$$\omega_{0,B} = n\omega_{0,A} + \varepsilon\sigma_{\omega},\tag{21}$$

$$\mu_B = n\mu_A + \varepsilon \sigma_\mu, \tag{22}$$

where small detuning parameters  $\sigma_{\omega}$  and  $\sigma_{\mu}$  are introduced to also capture wave interactions in close proximity to the n:1 relationship. Since both  $(\mu_A, \omega_{0,A})$  and  $(\mu_B, \omega_{0,B})$  must satisfy the lattice's linear dispersion relationship, the detuning parameters cannot be set independently of each other. For example, if the A wave frequency and wave number are known and  $\sigma_{\mu}$  is prescribed, then  $\mu_B$  can be determined from Eq. (22). The B wave frequency  $\omega_{0,B}$  can then be readily identified such that Eq. (16) or (17) is satisfied and the associated  $\sigma_{\omega}$  can be found from Eq. (21).

The complex wave amplitudes *A* and *B* can be decomposed into polar form:

$$A = \alpha_A e^{i\beta_A},\tag{23}$$

$$B = \alpha_B e^{i\beta_B}. (24)$$

<span id="page-4-0"></span>By virtue of satisfying Eq. (13), the real quantities  $\alpha_A$ ,  $\alpha_B$ ,  $\beta_A$ , and  $\beta_B$  are functions of only the slower timescales:  $T_1$ ,  $T_2$ , etc. Once  $\mathbf{x}_j^{(0)}$  is defined, the right-hand side of Eq. (14) can be updated,

$$D_0^2 \mathbf{M} \mathbf{x}_j^{(1)} + \sum_{p=-1}^{+1} \left[ \mathbf{K}^{(p)} \mathbf{x}_j^{(1)} \right] = -\mathbf{M} D_1 (i\omega_{0,A} \mathbf{\Phi}(\omega_{0,A}) A e^{i\omega_{0,A} T_0})$$

$$\times e^{-i\mu_A j} + i\omega_{0,B} \mathbf{\Phi}(\omega_{0,B}) B e^{i\omega_{0,B} T_0} e^{-i\mu_B j}$$

$$+\sum_{u=0}^{3}\sum_{w=-3}^{3}\mathbf{a}_{\mathbf{u},\mathbf{w}}e^{ui(\omega_{0,A}T_{0}-\mu_{A}j)}e^{wi(\omega_{0,B}T_{0}-\mu_{B}j)}+\text{c.c.}, (25)$$

where  $\mathbf{a}_{\mathbf{u},\mathbf{w}}$  denotes the amplitude at each of the multiharmonic inhomogeneities and can be expected to be functions of the lattice parameters in addition to the A and B wave frequencies and amplitudes. All possible first-order frequency combinations that occur after inserting Eq. (16) into  $\mathbf{f}_{NL}$  are included in the double summation. Quadratic nonlinearities result in even-integer higher harmonics whereas those from cubic nonlinearities result in odd-integer higher harmonics. Additionally, cubic nonlinearities produce secular terms at  $e^{i\omega_{0,A}T_0}e^{-i\mu_{AJ}}$  and  $e^{i\omega_{0,B}T_0}e^{-i\mu_{BJ}}$ .

Due to the n:1 internal resonance, terms at  $e^{ni\omega_{0,A}T_0}e^{-ni\mu_A j}$  can be expressed in terms of  $e^{i\omega_{0,B}T_0}e^{-i\mu_B j}$  (and vice versa). This result is clear after manipulation of the relationships in Eqs. (21) and (22):

$$n(\omega_{0,A}T_0 - \mu_A j) = \omega_{0,B}T_0 - \mu_B j - \varepsilon \sigma_{\omega} T_0 + \varepsilon \sigma_{\mu} j$$
  

$$\equiv \omega_{0,B}T_0 - \mu_B j - \sigma_{\omega} T_1 + \sigma_{\mu} J_1.$$
 (26)

Note that a slow spatial scale,  $J_1 \equiv \varepsilon j$ , has been introduced analogous to the first slow timescale  $T_1 \equiv \varepsilon t$ , both of which appear with detuning parameters as phase shifts at a slower spatiotemporal scale.

Next, secular terms are removed from Eq. (21) in order to assure convergence of the imposed ordering approach. First, terms containing  $e^{i\omega_{0,A}T_0}e^{-i\mu_{A}j}$  (as well as their complex conjugates) are addressed. To identify all of these terms, the relationships in Eq. (26) must be invoked since, for example,  $\omega_{0,B} - \omega_{0,A} \approx \omega_{0,A}$  when n = 2. After premultiplying all terms with  $e^{i\omega_{0,A}T_0}e^{-i\mu_{A}j}$  dependence by  $\Phi^{\rm H}(\omega_{0,A})$  and separating real and imaginary parts, expressions for the slow-time amplitude and phase evolution for the A wave,  $D_1(\alpha_A)$  and  $D_1(\beta_A)$ , result. Considering 2:1 internal resonance from solely quadratic stiffness, these evolution equations can be written as

$$D_1(\alpha_A) = \alpha_A \alpha_B \operatorname{Re}(\bar{G}e^{i\gamma}), \tag{27}$$

$$D_1(\beta_A) = \alpha_B \operatorname{Im}(\bar{G}e^{i\gamma}), \tag{28}$$

where  $\bar{G}$  is a function of frequency and lattice parameters provided in the Supplemental Material [34] for both material systems. Additionally, a variable representing the relative phase between the A and B waves has been introduced,

$$\gamma \equiv \beta_B + \sigma_\omega T_1 - \sigma_\mu J_1 - n\beta_A,\tag{29}$$

which results in a set of autonomous evolution equations. The autonomous evolution equations associated with 3:1 internal

resonance and solely cubic stiffness are similar to Eqs. (23) and (24),

$$D_1(\alpha_A) = \text{Re}(\alpha_B \alpha_A^2 \bar{I} e^{i\gamma} + \alpha_B^2 \alpha_A \bar{L} + \alpha_A^3 \bar{N}), \tag{30}$$

$$D_1(\beta_A) = \operatorname{Im}(\alpha_B \alpha_A \bar{I} e^{i\gamma} + \alpha_B^2 \bar{L} + \alpha_A^2 \bar{N}), \tag{31}$$

where the Supplemental Material [34] provides expressions for  $\bar{I}$ ,  $\bar{L}$ , and  $\bar{N}$  for both material systems. Note that the presence of cubic stiffness will result in the appearance of additional terms in the evolution equations for 2:1 internal resonance, while the presence of quadratic stiffness will *not* result in additional terms in the evolution equations governing 3:1 internal resonance. The additional terms in the 2:1 evolution equations complicate the procedure (introduced next) for reducing the state space from  $(\alpha_A, \beta_A, \alpha_B, \beta_B)$  to  $(\alpha_B, \gamma)$ . However, numerical integration of the four-dimensional state space illustrates that cubic stiffness has a negligible effect on 2:1 energy exchange.

Likewise, terms appearing with  $e^{i\omega_{0,B}T_0}e^{-i\mu_B j}$  are also secular. To collect all terms at these frequencies requires application of Eq. (26) followed by premultiplying with  $\Phi^{\mathbf{H}}(\omega_{0,B})$ . Expressions for the slow-time amplitude and phase evolution for the B wave,  $D_1(\alpha_B)$  and  $D_1(\beta_B)$ , result. For a 2:1 internal resonance, the evolution equations are given by

$$D_1(\alpha_B) = \alpha_A^2 \text{Re}(\bar{H}e^{-i\gamma}), \tag{32}$$

$$D_1(\beta_B) = \frac{\alpha_A^2}{\alpha_B} \text{Im}(\bar{H}e^{-i\gamma}), \tag{33}$$

and for the 3:1 internal resonance by

$$D_1(\alpha_B) = \text{Re}\left(\alpha_A^2 \alpha_B \bar{P} + \alpha_B^3 \bar{Q} + \alpha_A^3 \bar{R} e^{-i\gamma}\right), \tag{34}$$

$$D_1(\beta_B) = \operatorname{Im}\left(\alpha_A^2 \bar{P} + \alpha_B^2 \bar{Q} + \frac{\alpha_A^3}{\alpha_B} \bar{R} e^{-i\gamma}\right), \tag{35}$$

where the Supplemental Material [34] again provides expressions for  $\bar{H}$ ,  $\bar{P}$ ,  $\bar{Q}$ , and  $\bar{R}$  for each material system. At this point in the development, the state space of response quantities is either governed by Eqs. (27) and (28), and (32) and (33), in the case of a 2:1 internal resonance, or Eqs. (30) and (31), and (34) and (35), in the case of a 3:1 internal resonance.

The dimension of the state space can be reduced from four quantities  $(\alpha_A, \alpha_B, \beta_A, \beta_B)$  to three  $(\alpha_A, \alpha_B, \gamma)$  by differentiating Eq. (29) with respect to  $T_1$  and substituting in the known expressions for  $D_1(\beta_A)$  and  $D_1(\beta_B)$ :

$$D_1(\gamma) = D_1(\beta_B) + \sigma_\omega - nD_1(\beta_A).$$
 (36)

Applying this procedure to the case of 2:1 internal resonance yields the following reduced set of evolution equations quadratic in the wave amplitudes,

$$D_1(\alpha_A) = \alpha_A \alpha_B G \cos(\psi_G + \gamma), \tag{37}$$

$$D_1(\alpha_R) = \alpha_A^2 H \cos(\psi_H + \gamma), \tag{38}$$

$$D_1(\gamma) = \sigma_{\omega} - 2\alpha_B G \sin(\psi_G + \gamma) - \frac{\alpha_A^2}{\alpha_B} H \sin(\psi_H + \gamma),$$

(39)

<span id="page-5-0"></span>where  $\bar{G} = Ge^{i\psi_G}$  and  $\bar{H} = He^{-i\psi_H}$ . The case of 3:1 internal resonance gives rise to a reduced set of evolution equations cubic in the wave amplitudes

$$D_1(\alpha_A) = \alpha_B \alpha_A^2 I \cos(\psi_I + \gamma), \tag{40}$$

$$D_1(\alpha_B) = \alpha_A^3 R \cos(\psi_R + \gamma), \tag{41}$$

$$D_1(\gamma) = \alpha_A^2 P + \alpha_B^2 Q - \frac{\alpha_A^3}{\alpha_B} R \sin(\psi_R + \gamma) + \sigma_\omega$$
$$-3 \left[ \alpha_B \alpha_A I \sin(\psi_I + \gamma) + \alpha_B^2 L + \alpha_A^2 N \right],$$

where  $\bar{I}=Ie^{i\psi_I},~\bar{L}=Le^{i\psi_L},~\bar{N}=Ne^{i\psi_N},~\bar{P}=Pe^{i\psi_P},~\bar{Q}=Qe^{i\psi_Q},~\mathrm{and}~\bar{R}=Re^{-i\psi_R}.$ 

Using the approach outlined in [27], solutions are sought on a hyperplane, reducing the phase space from  $(\alpha_A, \alpha_B, \gamma)$  to  $(\alpha_B, \gamma)$ . Key to this step is to seek out-of-phase evolution of the A and B wave amplitudes. For energy exchange which conserves total mechanical energy, it can be expected that the  $D_1(\alpha_A)$  and  $D_1(\alpha_B)$  are out of phase. The first step is to recognize a relationship between the phase terms from the secular term removal,

$$\psi_G - \psi_H = \pi, \tag{43}$$

$$\psi_I - \psi_R = \pi. \tag{44}$$

Although difficult to prove analytically due to the complexity of the expressions, numerical evaluation using multiple parameter sets has confirmed Eqs. (43) and (44) to machine precision. The relationships in Eqs. (43) and (44) do not define out-of-phase amplitude evolution but instead enable a reduction of the dimension of the state space. Accordingly,

$$\frac{D_1 \alpha_A}{D_1 \alpha_B} = -\frac{1}{r} \frac{\alpha_B}{\alpha_A}.$$
 (45)

Equation (45) simplifies to

$$r\alpha_A^2 + \alpha_B^2 = E, (46)$$

where  $r = \frac{H}{G}$  for 2:1 internal resonance and  $r = \frac{R}{I}$  for 3:1 internal resonance. While Eq. (46) is not a statement of conservation of energy, the solutions on such a hyperplane must conserve the energylike integration constant E. Thus, since the A and B waves are the only wave propagation modes present, each mode grows and decays at the expense of exchanging energy with the other when considering solutions on the ellipse in Eq. (46). Substituting Eq. (46) into the 2:1 expressions in Eqs. (37)–(39) gives

$$D_1(\alpha_B) = \left(E - \alpha_B^2\right)G\cos\left(\psi_H + \gamma\right),\tag{47}$$

$$D_{1}(\gamma) = \sigma_{\omega} + 2\alpha_{B}G\sin(\psi_{H} + \gamma)$$
$$-\frac{\left(E - \alpha_{B}^{2}\right)}{\alpha_{B}}G\sin(\psi_{H} + \gamma). \tag{48}$$

For 3:1 internal resonance, the energy-reduced phase space in Eqs. (40)–(42) simplifies to

$$D_1 \alpha_B = \left[ \frac{1}{r} \left( E - \alpha_B^2 \right) \right]^{\frac{3}{2}} R \cos \left( \psi_R + \gamma \right), \tag{49}$$

$$D_{1}(\gamma) = \left[\frac{1}{r}\left(E - \alpha_{B}^{2}\right)\right]P + \alpha_{B}^{2}Q - \frac{1}{\alpha_{B}}\left[\frac{1}{r}\left(E - \alpha_{B}^{2}\right)\right]^{\frac{3}{2}}$$

$$\times R\sin(\psi_{R} + \gamma) + \sigma_{\omega} - 3\left\{\alpha_{B}\left[\frac{1}{r}\left(E - \alpha_{B}^{2}\right)\right]^{\frac{1}{2}}\right\}$$

$$\times I\sin(\psi_{I} + \gamma) + \alpha_{B}^{2}L + \left[\frac{1}{r}\left(E - \alpha_{B}^{2}\right)\right]N\right\}. (50)$$

Local stability analysis. The evolution of the amplitudes and phases of the A and B waves defines the interaction of the internally resonant plane waves. The stability of their evolution must be assessed to predict if a given distribution of initial amplitudes and phases will persist for long spatial and temporal measures. To investigate stability, the temporal evolution of the two-dimensional reduced phase space is reconstituted to the original timescale:

$$\dot{\alpha}_B = \varepsilon D_1(\alpha_B),\tag{51}$$

$$\dot{\gamma} = \varepsilon D_1(\gamma). \tag{52}$$

The associated fixed points  $(\alpha_B^*, \gamma^*)$  satisfy  $\dot{\alpha}_B|_{(\alpha_B^*, \gamma^*)} = 0$  and  $\dot{\gamma}|_{(\alpha_B^*, \gamma^*)} = 0$ . Stability can then be determined local to each fixed point by examining their associated  $\lambda$  value,

$$\lambda = \det J,\tag{53}$$

where

(42)

$$J = \begin{cases} \frac{\partial}{\partial \alpha_B} [D_1(\alpha_B)] & \frac{\partial}{\partial \gamma} [D_1(\alpha_B)] \\ \frac{\partial}{\partial \alpha_B} [D_1(\gamma)] & \frac{\partial}{\partial \gamma} [D_1(\gamma)] \end{cases}_{(\alpha_B^*, \gamma^*)}.$$
 (54)

When  $\lambda$  is purely real,  $\lambda > 0$  denotes instability,  $\lambda < 0$  denotes stability, and  $\lambda = 0$  denotes neutral stability. When  $\lambda$  is purely imaginary (i.e.,  $\lambda = \pm i\omega_J$ ), the evolution of  $\alpha_A$ ,  $\alpha_B$ , and  $\gamma$  are oscillatory with frequency  $\omega_J$ . The fixed point equations arising from 2:1 resonance are quadratic with respect to  $\alpha_B$  and consequently the fixed point solutions can readily be determined in closed form. Table I summarizes the results. Note the existence of two fixed points associated with periodic orbits and two unstable fixed points.

Thus, fixed points 1 and 2 are centers, and initial amplitudes and phases in their vicinity should evolve periodically over time with frequency  $\omega_J$ . Applying Eq. (53), an expression can be derived that gives the frequency of the energy exchange for waves undergoing stable 2:1 internal resonance,

$$\omega_J = \frac{G}{\alpha_B^*} \sqrt{\left(E^2 + 2E\alpha_B^{*2} - 3\alpha_B^{*4}\right)},\tag{55}$$

where  $\alpha_B^*$  must be associated with fixed points 1 and 2 in Table I. For 3:1 internal resonance, no closed-form solutions were found for the fixed points and their associated  $\lambda$  values based on the cubic dependence of their fixed point equations. However, for a given parameter set, numerical root-finding techniques can be employed to compute the fixed point solutions and their associated stability. It is important to note that periodic orbits similar to those observed for 2:1 internal resonance also arise for the case of 3:1 internal resonance.

<span id="page-6-0"></span>TABLE I. Fixed points for 2:1 internal resonance valid for both lattices considered. The A-wave fixed point is not a direct component of the two-dimensional phase space of  $(\alpha_B, \gamma)$  but rather determined by the energy ellipse relationship.

| Fixed point           | $lpha_B^*$                                                                                            | $lpha_A^*$                                                                                                                                     | $\gamma^*$                                                                                     | λ                                                                      |
|-----------------------|-------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|
| FP 1 and 2 FP 3 and 4 | $\frac{-\sigma_{\omega} \mp \sqrt{\sigma_{\omega}^2 + 12EG^2}}{6G\sin(\psi_H + \gamma^*)}$ $\sqrt{E}$ | $\sqrt{\frac{1}{r}\left\{E - \left[\frac{-\sigma_{\omega} \mp \sqrt{\sigma_{\omega}^2 + 12EG^2}}{6G\sin(\psi_H + \gamma^*)}\right]^2\right\}}$ | $\cos(\gamma^* + \psi_H) = 0$<br>$\sin(\gamma^* + \psi_H) = -\frac{\sigma_\omega}{2\sqrt{E}G}$ | $\lambda = \pm i\omega_J$ (Periodic orbit)<br>$\lambda > 0$ (Unstable) |

#### IV. ENERGY EXCHANGE RESULTS

To numerically validate the periodic energy exchange predicted by the presented multiple-scales approach, direct numerical simulation of the equations of motion in Eq. (1) is carried out. Plane waves of the form in Eq. (20) with internally resonant frequency and wave number combinations are injected into the lattice as initial conditions. Initial amplitudes and phases of the A and B waves are selected to be sufficiently near centers. To replicate plane waves in infinite media, long chains are simulated (e.g., approximately 800–1000 wavelengths of the A wave). Viscous dampers are added near the chain's boundaries with coefficients increasing towards the ends of the structure to absorb reflections during the simulation. Such damping profile also dissipates initial displacements and velocities near the lattice's boundaries at the start of the simulation. Analysis is then restricted to the central region of the chain (e.g., the middle 100-200 wavelengths of the A wave). To track the energy exchange of the injected waves, spatial fast Fourier transforms (FFTs) are taken of the  $m_b$  masses in this central region. Thus, the magnitudes of the frequency content at  $\mu_A$  and  $\mu_B$  can be interpreted as  $\alpha_A$  and  $\alpha_B$ , respectively, which can, in turn, be compared to the predictions of the multiple-scales evolution equations in Eqs. (47) and (48), or (49) and (50), for 2:1 and 3:1 internal resonances, respectively. For a given value of E, fixed points associated with periodic orbits can be determined, either analytically, for the case of 2:1 internal resonance, or computationally, for the case of 3:1 internal resonance. The initial amplitudes and phases of the simulated A and B waves can then be selected to be sufficiently close to these fixed point predictions such that the simulated waves will be expected to exchange energy over time. Values of E are sufficiently small so as to eliminate or minimize the generation of still higher harmonics out of the A and B waves. Lastly, it is important to note that this study focuses on validating the orbits around

![](_page_6_Figure_7.jpeg)

FIG. 4. Frequency of energy exchange and strength of the nonlinearity associated with fixed points 1 and 2 for 2:1 internal resonance within the acoustic branch (a,b) and between the acoustic and optical branches (c,d) of the diatomic lattice: (a,b)  $m_a = 1$ ,  $m_b = 1.5$ ,  $k_1 = 1$ ,  $k_2 = 1$ ,  $k_3 = 0$ ,  $\epsilon = 0.1$ ,  $\mu_A = 0.5$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ ; (c,d)  $m_a = 1$ ,  $m_b = 1.5$ ,  $k_1 = 1$ ,  $k_2 = 1$ ,  $k_3 = 0$ ,  $\epsilon = 0.1$ ,  $\mu_A = \frac{\pi}{1.91}$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ .

![](_page_7_Figure_2.jpeg)

FIG. 5. Phase portrait for 2:1 internal resonance within the acoustic branch of the diatomic lattice. Centers are plotted in red.  $m_a = 1$ ,  $m_b = 1.5$ ,  $k_1 = 1$ ,  $k_2 = 1$ ,  $k_3 = 0$ ,  $\varepsilon = 0.1$ ,  $\mu_A = 0.5$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ , E = 0.5.

lower fixed values as they are more likely to satisfy the weak nonlinearity criterion required for multiple-scales validity.

#### A. Diatomic system

Figure 4 depicts the relationships between the frequency of the energy exchange,  $\omega_J$ , and energy level, E, for an example diatomic lattice (parameters provided in the caption), considering 2:1 internal resonance within the acoustic branch and between the acoustic and optical branches. For both cases, a higher energy level produces a higher frequency energy

exchange. Additionally, the strength of the quadratic nonlinearity at each fixed point, as measured by the dimensionless parameter  $\Pi_2 \equiv \frac{k_2 \alpha^*}{k_1}$ , is evaluated as a function of E. To satisfy a conservative weak nonlinearity criterion,  $\Pi_2$  should be roughly  $\leq 0.1$ . Note that as E transitions beyond 0.1 for interactions within the acoustic branch, a bifurcation occurs in fixed point 2 such that  $\alpha_B^*$  becomes real and nonzero. This result can be physically understood to be the minimum energy barrier needed to activate a periodic energy exchange for 2:1 internal resonance within the acoustic branch.

Long wavelengths are considered for investigating internal resonance within the acoustic branch of the diatomic lattice. Figure 5 displays a sample phase portrait for 2:1 internal resonance within the acoustic branch. As documented in Table I, there are two centers and two unstable fixed points. Validation of the lower amplitude center is of primary importance as it satisfies the weak nonlinearity criterion.

Figure 6 presents the results of simulating waves with 2:1 internally resonant frequency combinations within the acoustic branch of the diatomic lattice. Note the close agreement between the multiple-scales predictions and results from direct numerical simulation when viewing the energy exchange in the time domain. As expected, the *A* and *B* wave amplitudes oscillate out of phase. This energy exchange occurs at a single frequency and amplitude that matches well with the multiple-scales prediction. Their agreement is especially evident after taking an FFT of the time histories of the energy exchange signals and filtering out each of their zero frequency (dc) terms. The dc terms can be expected to be similar in magnitude to the fixed points, especially for the nearly circular trajectories close to the centers in the phase plane.

![](_page_7_Figure_10.jpeg)

FIG. 6. Direct numerical simulation of the lattice equations of motion compared to the multiple-scales predictions of the periodic energy exchange in the diatomic lattice. 2:1 internal resonance within the acoustic branch is considered. (a,b) Time histories of the amplitude modulation. (c,d) Dominant, slow-scale frequency content of the energy exchange, filtering out the dc component.  $m_a = 1$ ,  $m_b = 1.5$ ,  $k_1 = 1$ ,  $k_2 = 1$ ,  $k_3 = 0$ ,  $\varepsilon = 0.1$ ,  $\mu_A = 0.5$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ , E = 0.0106.

![](_page_8_Figure_2.jpeg)

FIG. 7. Phase portrait for 3:1 internal resonance between the acoustic and optical branches of the diatomic lattice. Centers are plotted in red.  $m_a=1$ ,  $m_b=1.1$ ,  $k_1=1$ ,  $k_2=0$ ,  $k_3=1$ ,  $\varepsilon=0.1$ ,  $\mu_A=\frac{\pi}{3.16}$ ,  $\sigma_{\mu}=0$ ,  $J_1=0$ , E=1.

Next, wave interactions associated with internal resonance between the acoustic and optical branches are simulated. Figure 7 presents a sample phase portrait for 3:1 interactions between the two branches. Note that there are three fixed points: two associated with periodic orbits and one associated with instability. It is desired to validate periodic orbits about sufficiently low amplitude fixed points.

Figure 8 compares the results from direct numerical simulation of the diatomic lattice to the multiple-scales predictions for 3:1 interactions between the acoustic and optical branches. An FFT of the time histories of  $\alpha_A$  and  $\alpha_B$  reveals that multiple scales again accurately predict the dominant frequency of the energy exchange. Their mean values are subtracted so as to determine the frequency content of the oscillations. High frequencies in the results from direct numerical simulation suggest that there is at least one additional wave with which the A and B waves may be exchanging energy. Clearly, the slow timescales introduced in Eq. (10) cannot be expected to predict amplitude modulation faster than the A wave's fundamental frequency. Reformulating the multiple-scales analysis to include both fast and slow timescales poses challenges that are left for future work. However, as evidenced in the figures, the dominant frequency of exchange and the exchange amplitudes are accurately predicted by the presented multiple-scales approach.

![](_page_8_Figure_7.jpeg)

FIG. 8. Direct numerical simulation of the lattice equations of motion compared to the multiple-scales predictions of the periodic energy exchange in the diatomic lattice. 3:1 internal resonance between the acoustic and optical branches is considered. (a,b) Time histories of the amplitude modulation. (c,d) Dominant, slow-scale frequency content of the energy exchange, filtering-out the dc component. (e,f) Frequency content of the energy exchange, presenting the small high frequency components identified in numerical simulations.  $m_a = 1$ ,  $m_b = 1.1$ ,  $k_1 = 1$ ,  $k_2 = 0$ ,  $k_3 = 1$ ,  $\epsilon = 0.1$ ,  $\mu_A = \frac{\pi}{3.16}$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ , E = 0.05.

![](_page_9_Figure_2.jpeg)

FIG. 9. Frequency of energy exchange and strength of the nonlinearity associated with fixed points 1 and 2 for 2:1 internal resonance within the acoustic branch (a,b) and between the acoustic and optical branches (c,d) of the locally resonant lattice: (a,b)  $m_a=1, m_b=0.1, k_{1a}=10, k_{1b}=2, k_{2a}=1, k_{2b}=1, k_{3a}=0, k_{3b}=0, \ \varepsilon=0.1, \mu_A=0.1, \sigma_\mu=0;$  (c,d)  $m_a=1, m_b=0.1, k_{1a}=10, k_{1b}=2, k_{2a}=1, k_{2b}=1, k_{3a}=0, k_{3b}=0, \ \varepsilon=0.1, \mu_A=\frac{\pi}{2.93}, \sigma_\mu=0.$ 

### B. Locally resonant metamaterial system

The expressions governing internal resonance in the locally resonant metamaterial-type lattice are considered next. Figure 9 documents the frequency of energy exchange and strength of the quadratic nonlinearity for 2:1 internal resonance within the acoustic branch, and between the acoustic and optical branches. For  $\Pi_2$ , the primary chain's quadratic stiffness is referenced:  $\Pi_{2a} \equiv \frac{k_{2a}\alpha^*}{k_1}$ . Informed by the relationships in Fig. 9, lattice parameters and initial conditions are selected such that a slow energy exchange (i.e.,  $\frac{\epsilon\omega_I}{\omega_{0A}} \leq 0.1$ ) with weak nonlinearities (i.e.,  $\Pi_{2a} \leq 0.1$ ) is numerically simulated.

Considering large wavelengths, Fig. 10 illustrates a sample phase portrait for 3:1 internal resonance between two waves within the acoustic branch. Both periodic orbits and unstable trajectories can be observed as well as a high degree of symmetry between positive and negative  $\gamma$  values.

Comparing the results from direct numerical simulation to the perturbation-based evolution equations for a locally resonant lattice with 3:1 internal resonance within the acoustic branch, Fig. 11 illustrates close agreement between theory and simulation for the dominant frequency and amplitude of the energy exchange. Additionally, the energy exchange of the waves consists of high frequency components, which

can be expected to take place with waves not considered in the zeroth-order solution of the perturbation framework. Nonetheless, as with the diatomic system, multiple-scales accurately predict the dominant frequency of the energy ex-

![](_page_9_Figure_9.jpeg)

FIG. 10. Phase portrait for 3:1 internal resonance within the acoustic branch of the locally resonant lattice. Centers are plotted in red.  $m_a=1, m_b=0.4, k_{1a}=1, k_{1b}=1, k_{2a}=0, k_{2b}=0, k_{3a}=1, k_{3b}=1, \ \varepsilon=0.1, \mu_A=\frac{\pi}{12}, \sigma_\mu=0, E=5.$ 

<span id="page-10-0"></span>![](_page_10_Figure_2.jpeg)

FIG. 11. Direct numerical simulation of the lattice equations of motion compared to the multiple-scales predictions of the periodic energy exchange in the locally resonant lattice. 3:1 internal resonance within the acoustic branch is considered. (a,b) Time histories of the amplitude modulation. (c,d) Dominant, slow-scale frequency content of the energy exchange, filtering-out the dc component. (e,f) Frequency content of the energy exchange, presenting the small high frequency components identified in numerical simulations.  $m_a = 1$ ,  $m_b = 0.4$ ,  $k_{1a} = 1$ ,  $k_{1b} = 1$ ,  $k_{2a} = 0$ ,  $k_{2b} = 0$ ,  $k_{3a} = 1$ ,  $k_{3b} = 1$ ,  $\epsilon = 0.1$ ,  $\mu_A = \frac{\pi}{12}$ ,  $\sigma_{\mu} = 0$ ,  $\epsilon = 0.5$ .

change, and overall exchange behavior, between the A and B waves.

Lastly, internal resonance between the acoustic and optical branches in the locally resonant lattice is investigated. Figure 12 displays a sample phase portrait and Fig. 13

 $\sqrt{E}$   $\alpha_B$  0 0 0  $\pi$ 

FIG. 12. Phase portrait for 2:1 internal resonance between the acoustic and optical branches of the locally resonant lattice. Centers are plotted in red.  $m_a=1, m_b=0.1, k_{1a}=10, k_{1b}=2, k_{2a}=1, k_{2b}=1, k_{3a}=0, k_{3b}=0, c=0, \varepsilon=0.1, \mu_A=\frac{\pi}{2.93}, \sigma_{\mu}=0, E=0.1.$ 

summarizes the results comparing simulations to analytical predictions for 2:1 internal resonance, again showing good agreement in the primary exchange frequency and amplitudes.

#### V. DISPERSION ANALYSIS

As documented in [16,17], higher-order multiple-scales analysis of a single-frequency plane wave does not provide valid dispersion shifts for frequencies near internal resonances. This stems from unaccounted-for secular terms arising from  $[n\mu, n\omega_0(\mu)]$ , that are instead treated as nonsecular with associated particular solutions. These first-order particular solutions become unbounded at frequencies associated with internal resonance, and consequently violate the asymptotic series expansion. Thus, singularities in dispersion corrections due to internal resonance for self-interacting cannot be seen until advancing to the second order. Note that first-order dispersion corrections do not exhibit singularities, and the natural question arises as to whether these lower-order approximations can be satisfactorily used near internal resonance.

Since quadratic stiffness interactions do not cause dispersion shifting until higher orders [i.e.,  $O(\varepsilon^2)$ ], cubic stiffness interactions are considered for this dispersion study. Additionally, internal resonance between the acoustic and optical branches is explored since there are negligible dispersion shifts at the long wavelengths at which internal resonance

<span id="page-11-0"></span>![](_page_11_Figure_2.jpeg)

FIG. 13. Direct numerical simulation of the lattice equations of motion compared to the multiple-scales predictions of the periodic energy exchange in the locally resonant lattice. 2:1 internal resonance between the acoustic and optical branches is considered. (a,b) Time histories of the amplitude modulation. (c,d) Dominant, slow-scale frequency content of the energy exchange, filtering-out the dc component. (e,f) Frequency content of the energy exchange, presenting the small high frequency components identified in numerical simulations.  $m_a = 1$ ,  $m_b = 0.4$ ,  $k_{1a} = 1$ ,  $k_{1b} = 1$ ,  $k_{2a} = 1$ ,  $k_{2b} = 1$ ,  $k_{3a} = 0$ ,  $k_{3b} = 0$ ,  $\epsilon = 0.1$ ,  $\sigma_{\mu} = 0$ ,  $J_1 = 0$ ,  $\mu_A = \frac{\pi}{1.68}$ , E = 0.1.

takes place solely within the acoustic branch. Recalling from [16,17,22] that evolution equations for phases directly provide the amplitude-dependent corrections to the band structure, Eqs. (31) and (35) are evaluated at the fixed points,

$$\omega_{1,A} = I\alpha_A^* \alpha_B^* \sin(\psi_I + \gamma^*) + L\alpha_B^{*2} + N\alpha_A^{*2}, \quad (56)$$

$$\omega_{1,B} = P\alpha_A^{*2} + Q\alpha_B^{*2} - R\frac{\alpha_A^{*3}}{\alpha_B^*}\sin(\psi_R + \gamma^*),$$
 (57)

where  $\omega_{1,A}$  and  $\omega_{1,B}$  denote the amplitude-dependent dispersion shifts for the A and B waves, respectively, for 3:1 internal resonance. The corrections in Eqs. (56) and (57) can be evaluated at any fixed point  $(\alpha_A^*, \alpha_B^*, \gamma)$ . To determine whether these expressions from internally resonant interactions are comparable to the first-order predictions from a single plane wave analysis, Eq. (56) is evaluated with  $E = r\alpha^2$ , where  $\alpha$  is the amplitude of the single-frequency plane wave to which results are compared.

Figure 14 compares the results for the internally resonant dispersion predictions to those from the first-order perturba-

tion predictions for a single plane wave in the diatomic chain. The frequency  $\omega$  and wave number  $\mu$  correspond to those of the single-frequency plane wave. The A-wave frequency and wave number are used for the comparison. When evaluated at fixed point 6, the internally resonant analysis gives results that would arise should the single plane wave analysis be interpolated through its singularities. Fixed point 5 converges to the single plane wave corrections as the wave number increases to values well above the frequency at which the singularity occurs. Fixed point 7 exists for a narrow range of frequencies about the singularity and slowly approaches the single plane wave results. The results evaluated at fixed point 6 give confidence that higher-order singularities can be avoided when studying a single plane wave by instead employing the first-order expressions.

Using the framework detailed in Sec. III A, the stability of fixed points 5–7 in Fig. 14 is analyzed as the wave number  $\mu$  is varied to ensure the stability of the solutions. Figure 15 presents the results. Since fixed point 6 is a center, it provides justification for employing its value to interpolate through single plane wave singularities. Fixed point 5 is also a center,

<span id="page-12-0"></span>![](_page_12_Figure_2.jpeg)

FIG. 14. Comparison of multiple-scales expressions for dispersion shifts in the diatomic chain. A single plane wave has singularities in its higher-order dispersion corrections at frequencies associated with internal resonance between branches (a). Dispersion corrections based on 3:1 energy exchange (b,c,d) exist at specific ranges of frequencies and the results evaluated at fixed point 6 pass through the singularity found in the single plane wave results. *ma* = 1, *mb* = 1.3, *k*<sup>1</sup> = 1, *k*<sup>2</sup> = 0, *k*<sup>3</sup> = 1, ε = 0.1, σμ = 0, *J*<sup>1</sup> = 0, α = 0.7.

which also can be used to approximate the dispersion shifts of a single plane wave at frequencies beyond the 3:1 singularity. Note that α<sup>∗</sup> *<sup>B</sup>* for fixed points 6 and 7 coalesce and subse-

quently vanish as the control parameter μ is varied just above the value giving a singularity. This behavior is indicative of a saddle-node bifurcation.

![](_page_12_Figure_6.jpeg)

FIG. 15. Bifurcation analysis of the multiple-scales fixed point expressions in the vicinity of the singularity due to 3:1 internal resonance in the diatomic chain. The wave number of the *A* wave μ*<sup>A</sup>* serves as the control parameter and the fixed points α<sup>∗</sup> *<sup>B</sup>* (a) and γ <sup>∗</sup> (b) are evaluated. Fixed points 5 and 6 are both centers giving confidence they can be used to interpolate through or approximate the singularity in the higherorder single plane wave dispersion correction. The vertical line represents the location of the singularity in the single plane wave dispersion correction.

### **VI. CONCLUSIONS**

<span id="page-13-0"></span>A multiple-scales approach has been presented to analyze internally resonant energy exchange in weakly nonlinear lattices with multiple degrees of freedom per unit cell. Both 2:1 and 3:1 internal resonances within the same branch, and between different branches, is considered for diatomic and locally resonant example systems. A local stability analysis reveals distributions of amplitudes and phases associated with a slow periodic exchange of energy between the internally resonant plane waves. These predictions are validated by direct numerical simulation of the lattices' equations of motion. A dispersion study reveals that first-order corrections from perturbation analysis of internally resonant interactions accurately characterize regions of the band structure at which dispersion corrections of a single-frequency plane wave break down. The results presented herein may inform technology capable of long-range coherent signal transmission and detection in nonlinear periodic media.

#### **ACKNOWLEDGMENT**

The authors would like to thank the National Science Foundation for support of this research under the Emerging Frontiers Research Initiative NewLAW through Grant No. 1741565.

- [1] O. R. Bilal, A. Foehr, and C. Daraio, Bistable metamaterial for [switching and cascading elastic vibrations,](https://doi.org/10.1073/pnas.1618314114) Proc. Natl. Acad. Sci. USA **[114](https://doi.org/10.1073/pnas.1618314114)**, [4603](https://doi.org/10.1073/pnas.1618314114) [\(2017\)](https://doi.org/10.1073/pnas.1618314114).
- [2] J. Bunyan, K. J. Moore, A. Mojahed, M. D. Fronk, M. Leamy, S. Tawfick, and A. F. Vakakis, Acoustic nonreciprocity in a lattice incorporating nonlinearity, asymmetry, and internal scale hierarchy: Experimental study, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.97.052211) **[97](https://doi.org/10.1103/PhysRevE.97.052211)**, [052211](https://doi.org/10.1103/PhysRevE.97.052211) [\(2018\)](https://doi.org/10.1103/PhysRevE.97.052211).
- [3] W. Jiao and S. Gonella, Mechanics of inter-modal tunneling in nonlinear waveguides, [J. Mech. Phys. Solids](https://doi.org/10.1016/j.jmps.2017.10.008) **[111](https://doi.org/10.1016/j.jmps.2017.10.008)**, [1](https://doi.org/10.1016/j.jmps.2017.10.008) [\(2018\)](https://doi.org/10.1016/j.jmps.2017.10.008).
- [4] M. Kurosu, D. Hatanaka, K. Onomitsu, and H. Yamaguchi, Onchip temporal focusing of elastic waves in a phononic crystal waveguide, [Nat. Commun.](https://doi.org/10.1038/s41467-018-03726-7) **[9](https://doi.org/10.1038/s41467-018-03726-7)**, [1331](https://doi.org/10.1038/s41467-018-03726-7) [\(2018\)](https://doi.org/10.1038/s41467-018-03726-7).
- [5] R. K. Pal, J. Vila, M. Leamy, and M. Ruzzene, Amplitudedependent topological edge states in nonlinear phononic lattices, [Phys. Rev. E](https://doi.org/10.1103/PhysRevE.97.032209) **[97](https://doi.org/10.1103/PhysRevE.97.032209)**, [032209](https://doi.org/10.1103/PhysRevE.97.032209) [\(2018\)](https://doi.org/10.1103/PhysRevE.97.032209).
- [6] H. Reda, K. Elnady, J. F. Ganghoffer, and H. Lakiss, Wave propagation in pre-deformed periodic network materials based on large strains homogenization, [Compos. Struct.](https://doi.org/10.1016/j.compstruct.2017.10.054) **[184](https://doi.org/10.1016/j.compstruct.2017.10.054)**, [860](https://doi.org/10.1016/j.compstruct.2017.10.054) [\(2018\)](https://doi.org/10.1016/j.compstruct.2017.10.054).
- [7] A. F. Vakakis and M. E. King, Nonlinear wave transmission in a monocoupled elastic periodic system, [J. Acoust. Soc. Am.](https://doi.org/10.1121/1.413419) **[98](https://doi.org/10.1121/1.413419)**, [1534](https://doi.org/10.1121/1.413419) [\(1995\)](https://doi.org/10.1121/1.413419).
- [8] G. Chakraborty and A. K. Mallik, Dynamics of a weakly non-linear periodic chain, [Int. J. Non-linear Mech.](https://doi.org/10.1016/S0020-7462(00)00024-X) **[36](https://doi.org/10.1016/S0020-7462(00)00024-X)**, [375](https://doi.org/10.1016/S0020-7462(00)00024-X) [\(2001\)](https://doi.org/10.1016/S0020-7462(00)00024-X).
- [9] I. T. Georgiou and A. F. Vakakis, An invariant manifold approach for studying waves in a one-dimensional array of nonlinear oscillators, [Int. J. Non-linear Mech.](https://doi.org/10.1016/S0020-7462(96)00104-7) **[31](https://doi.org/10.1016/S0020-7462(96)00104-7)**, [871](https://doi.org/10.1016/S0020-7462(96)00104-7) [\(1996\)](https://doi.org/10.1016/S0020-7462(96)00104-7).
- [10] F. Romeo and G. Rega, Wave propagation properties in oscillatory chains with cubic nonlinearities via nonlinear map approach, [Chaos, Solitons Fractals](https://doi.org/10.1016/j.chaos.2005.04.087) **[27](https://doi.org/10.1016/j.chaos.2005.04.087)**, [606](https://doi.org/10.1016/j.chaos.2005.04.087) [\(2006\)](https://doi.org/10.1016/j.chaos.2005.04.087).
- [11] A. Marathe and A. Chatterjee, Wave attenuation in nonlinear periodic structures using harmonic balance and multiple scales, [J. Sound Vibr.](https://doi.org/10.1016/j.jsv.2005.02.047) **[289](https://doi.org/10.1016/j.jsv.2005.02.047)**, [871](https://doi.org/10.1016/j.jsv.2005.02.047) [\(2006\)](https://doi.org/10.1016/j.jsv.2005.02.047).
- [12] T. Weißl, B. Küng, E. Dumur, A. K. Feofanov, I. Matei, C. Naud, O. Buisson, F. W. Hekking, and W. Guichard, Kerr coefficients of plasma resonances in Josephson junction chains, [Phys. Rev. B](https://doi.org/10.1103/PhysRevB.92.104508) **[92](https://doi.org/10.1103/PhysRevB.92.104508)**, [104508](https://doi.org/10.1103/PhysRevB.92.104508) [\(2015\)](https://doi.org/10.1103/PhysRevB.92.104508).
- [13] Y. Krupko, V. Nguyen, T. Weißl, É. Dumur, J. Puertas, R. Dassonneville, C. Naud, F. Hekking, D. Basko, and O. Buisson, Kerr nonlinearity in a superconducting Josephson metamaterial, [Phys. Rev. B](https://doi.org/10.1103/PhysRevB.98.094516) **[98](https://doi.org/10.1103/PhysRevB.98.094516)**, [094516](https://doi.org/10.1103/PhysRevB.98.094516) [\(2018\)](https://doi.org/10.1103/PhysRevB.98.094516).
- [14] R. K. Narisetti, M. J. Leamy, and M. Ruzzene, A perturbation approach for predicting wave propagation in one-dimensional

- nonlinear periodic structures, [J. Vibr. Acoust.](https://doi.org/10.1115/1.4000775) **[132](https://doi.org/10.1115/1.4000775)**, [031001](https://doi.org/10.1115/1.4000775) [\(2010\)](https://doi.org/10.1115/1.4000775).
- [15] K. L. Manktelow, M. J. Leamy, and M. Ruzzene, Weakly nonlinear wave interactions in multi-degree of freedom periodic structures, [Wave Motion](https://doi.org/10.1016/j.wavemoti.2014.03.003) **[51](https://doi.org/10.1016/j.wavemoti.2014.03.003)**, [886](https://doi.org/10.1016/j.wavemoti.2014.03.003) [\(2014\)](https://doi.org/10.1016/j.wavemoti.2014.03.003).
- [16] M. D. Fronk and M. J. Leamy, Higher-order dispersion, stability, and waveform invariance in nonlinear monoatomic and diatomic systems, [J. Vibr. Acoust.](https://doi.org/10.1115/1.4036501) **[139](https://doi.org/10.1115/1.4036501)**, [051003](https://doi.org/10.1115/1.4036501) [\(2017\)](https://doi.org/10.1115/1.4036501).
- [17] M. D. Fronk and M. J. Leamy, Direction-dependent invariant waveforms and stability in two-dimensional, weakly nonlinear lattices, [J. Sound Vibr.](https://doi.org/10.1016/j.jsv.2019.01.022) **[447](https://doi.org/10.1016/j.jsv.2019.01.022)**, [137](https://doi.org/10.1016/j.jsv.2019.01.022) [\(2019\)](https://doi.org/10.1016/j.jsv.2019.01.022).
- [18] V. Cimmelli, A. Sellitto, and D. Jou, Nonequilibrium tempera[tures, heat waves, and nonlinear heat transport equations,](https://doi.org/10.1103/PhysRevB.81.054301) Phys. Rev. B **[81](https://doi.org/10.1103/PhysRevB.81.054301)**, [054301](https://doi.org/10.1103/PhysRevB.81.054301) [\(2010\)](https://doi.org/10.1103/PhysRevB.81.054301).
- [19] V. Cimmelli, A. Sellitto, and D. Jou, Nonlinear evolution and stability of the heat flow in nanosystems: Beyond linear phonon hydrodynamics, [Phys. Rev. B](https://doi.org/10.1103/PhysRevB.82.184302) **[82](https://doi.org/10.1103/PhysRevB.82.184302)**, [184302](https://doi.org/10.1103/PhysRevB.82.184302) [\(2010\)](https://doi.org/10.1103/PhysRevB.82.184302).
- [20] J. Rushchitsky and C. Cattani, Evolution equations for plane cubically nonlinear elastic waves, [Int. Appl. Mech.](https://doi.org/10.1023/B:INAM.0000023812.41455.63) **[40](https://doi.org/10.1023/B:INAM.0000023812.41455.63)**, [70](https://doi.org/10.1023/B:INAM.0000023812.41455.63) [\(2004\)](https://doi.org/10.1023/B:INAM.0000023812.41455.63).
- [21] J. Rushchitsky and E. Savel'eva, On the interaction of cubically [nonlinear transverse plane waves in an elastic material,](https://doi.org/10.1007/s10778-006-0133-9) Int. Appl. Mech. **[42](https://doi.org/10.1007/s10778-006-0133-9)**, [661](https://doi.org/10.1007/s10778-006-0133-9) [\(2006\)](https://doi.org/10.1007/s10778-006-0133-9).
- [22] K. Manktelow, M. J. Leamy, and M. Ruzzene, Multiple scales analysis of wave–wave interactions in a cubically nonlinear monoatomic chain, [Nonlinear Dyn.](https://doi.org/10.1007/s11071-010-9796-1) **[63](https://doi.org/10.1007/s11071-010-9796-1)**, [193](https://doi.org/10.1007/s11071-010-9796-1) [\(2011\)](https://doi.org/10.1007/s11071-010-9796-1).
- [23] V. J. Sánchez-Morcillo, I. Pérez-Arjona, V. Romero-García, V. Tournat, and V. Gusev, Second-harmonic generation for [dispersive elastic waves in a discrete granular chain,](https://doi.org/10.1103/PhysRevE.88.043203) Phys. Rev. E **[88](https://doi.org/10.1103/PhysRevE.88.043203)**, [043203](https://doi.org/10.1103/PhysRevE.88.043203) [\(2013\)](https://doi.org/10.1103/PhysRevE.88.043203).
- [24] A. Mehrem, N. Jiménez, L. J. Salmerón-Contreras, X. García-Andrés, L. M. García-Raffi, R. Picó, and V. J. Sánchez-[Morcillo, Nonlinear dispersive waves in repulsive lattices,](https://doi.org/10.1103/PhysRevE.96.012208) Phys. Rev. E **[96](https://doi.org/10.1103/PhysRevE.96.012208)**, [012208](https://doi.org/10.1103/PhysRevE.96.012208) [\(2017\)](https://doi.org/10.1103/PhysRevE.96.012208).
- [25] N. Jiménez, A. Mehrem, R. Picó, L. M. García-Raffi, and V. J. Sánchez-Morcillo, Nonlinear propagation and control of acoustic waves in phononic superlattices, [C. R. Phys.](https://doi.org/10.1016/j.crhy.2016.02.004) **[17](https://doi.org/10.1016/j.crhy.2016.02.004)**, [543](https://doi.org/10.1016/j.crhy.2016.02.004) [\(2016\)](https://doi.org/10.1016/j.crhy.2016.02.004).
- [26] N. M. Frandsen and J. S. Jensen, Modal interaction and higher harmonic generation in a weakly nonlinear, periodic mass– spring chain, [Wave Motion](https://doi.org/10.1016/j.wavemoti.2016.09.002) **[68](https://doi.org/10.1016/j.wavemoti.2016.09.002)**, [149](https://doi.org/10.1016/j.wavemoti.2016.09.002) [\(2017\)](https://doi.org/10.1016/j.wavemoti.2016.09.002).
- [27] S. R. Panigrahi, B. F. Feeny, and A. R. Diaz, Wave–wave interactions in a periodic chain with quadratic nonlinearity, [Wave Motion](https://doi.org/10.1016/j.wavemoti.2016.11.008) **[69](https://doi.org/10.1016/j.wavemoti.2016.11.008)**, [65](https://doi.org/10.1016/j.wavemoti.2016.11.008) [\(2017\)](https://doi.org/10.1016/j.wavemoti.2016.11.008).

- <span id="page-14-0"></span>[28] L. Brillouin, *Wave Propagation in Periodic Structures: Electric Filters and Crystal Lattices* (Courier Corporation, Mineola, NY, 2003).
- [29] N. M. M. Frandsen, Design of advanced materials for linear and nonlinear dynamics, Ph.D. thesis, Technical University of Denmark, 2016.
- [30] A. Spadoni and C. Daraio, Vibration isolation via linear and nonlinear periodic devices, in *Proceedings of ASME 2009 International Design Engineering Technical Conference and Computers and Information in Engineering Conference, San Diego, CA* (American Society of Mechanical Engineers, New York, 2009), pp. 277–284.
- [31] Z. Liu, X. Zhang, Y. Mao, Y. Zhu, Z. Yang, C. T. Chan, and P. Sheng, Locally resonant sonic materials, [Science](https://doi.org/10.1126/science.289.5485.1734) **[289](https://doi.org/10.1126/science.289.5485.1734)**, [1734](https://doi.org/10.1126/science.289.5485.1734) [\(2000\)](https://doi.org/10.1126/science.289.5485.1734).
- [32] H. Huang and C. Sun, Wave attenuation mechanism in an acous[tic metamaterial with negative effective mass density,](https://doi.org/10.1088/1367-2630/11/1/013003) New J. Phys. **[11](https://doi.org/10.1088/1367-2630/11/1/013003)**, [013003](https://doi.org/10.1088/1367-2630/11/1/013003) [\(2009\)](https://doi.org/10.1088/1367-2630/11/1/013003).
- [33] K. T. Tan, H. Huang, and C. Sun, Blast-wave impact mitigation using negative effective mass density concept of elastic metamaterials, [Int. J. Impact Eng.](https://doi.org/10.1016/j.ijimpeng.2013.09.003) **[64](https://doi.org/10.1016/j.ijimpeng.2013.09.003)**, [20](https://doi.org/10.1016/j.ijimpeng.2013.09.003) [\(2014\)](https://doi.org/10.1016/j.ijimpeng.2013.09.003).
- [34] See Supplemental Material at [http://link.aps.org/supplemental/](http://link.aps.org/supplemental/10.1103/PhysRevE.100.032213) 10.1103/PhysRevE.100.032213 for several expressions too lengthy to appear in the main text.