```
Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

Cart

1. Home >

2. Nonlinear Dynamics >
```

# Funnel adaptive neural learning secure control for nonlinear cyber-physical systems under stochastic FDI attacks

Research

<span id="page-0-0"></span>3. Article

- Published: 31 August 2025
- (2025)
- Cite this article

![](_page_0_Picture_6.jpeg)

Nonlinear Dynamics Aims and scope Submit manuscript

![](_page_0_Picture_8.jpeg)

- Penghao Chen<sup>1,2</sup>,
- Hamid Reza Karimi <sup>2</sup>.
- Xiaoli Luan 1 &
- ...
- Fei Liu<sup>1</sup>

### Show authors

- 132 Accesses •
- [Explore all metrics](file:///article/10.1007/s11071-025-11737-5/metrics)  •

# **Abstract**

This paper discusses the funnel adaptive neural learning secure control for nonlinear cyber-physical systems with stochastic false data injection attacks. A new defense strategy based on reinforcement learning with an identifier-critic-actor structure is proposed. This strategy not only effectively estimate unknown dynamics, evaluate system performance, and execute control actions, but also improves the robustness of the controlled system, and ensures that the tracking errors converge within the funnel in the finite-time. The control scheme aims to design the actual control inputs for all virtual controls and dynamic surface controls as the optimal solution of the corresponding subsystems. The update law is derived using the negative gradient of a simple positive function, which is generated from the partial derivatives of the Hamilton-Jacobi-Bellman equation. In addition, the Nussbaum function is introduced to compensate for the negative impact of the unknown direction of false data injection attacks on the sensors. At the same time, the design can also alleviate the requirements of the current optimal control methods for continuous excitation conditions. A key innovation lies in the formulation of elastic functions with flexible capabilities, thereby providing a unified framework that can flexibly solve the situation of initial value constraints without changing the control structure. Stability analysis shows that all signals are probabilistically semi-globally uniformly ultimately bounded.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11071-025-11737-5) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11071-025-11737-5)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11071-025-11737-5                                                                                                       |
| 1573-269X                                                                                                                        |
| Funnel adaptive neural learning secure control for nonlinear cyber-physical systems under stochastic FDI attacks                 |
| 2025                                                                                                                             |
| 2025                                                                                                                             |
| Penghao Chen, et al.                                                                                                             |
| Nonlinear Dynamics                                                                                                               |
| b68a0ad6cbb05546788b0763abe569514e7ac95f3cf1d1696ab867f7e331f5139774d4457269d53c0e25e0ef1560afecb7f3bd02c6e9c607ba52868e8ac44131 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

### [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals)

**Fig. 1**

**Fig. 2**

**Fig. 3**

**Fig. 4**

**Fig. 5**

**Fig. 6**

**Fig. 7**

**Fig. 8**

**Fig. 9**

**Fig. 10**

**Fig. 11**

**Fig. 12**

**Fig. 13**

**Fig. 14**

**Fig. 15**

**Fig. 16**

## **Similar content being viewed by others**

![](_page_3_Figure_15.jpeg)

**[Observer-based Adaptive Funnel Dynamic Surface Control for Nonlinear](https://link.springer.com/10.1007/s11063-022-10827-4?fromPaywallRec=true) [Systems with Unknown Control Coefficients and Hysteresis Input](https://link.springer.com/10.1007/s11063-022-10827-4?fromPaywallRec=true)** 

# **[Event-Triggered Fuzzy Adaptive Asymptotic Consensus Control of](https://link.springer.com/10.1007/s40815-024-01869-y?fromPaywallRec=true) [Nonlinear Multi-agent Systems Against FDI Attacks](https://link.springer.com/10.1007/s40815-024-01869-y?fromPaywallRec=true)**

Article 15 October 2024

![](_page_4_Picture_5.jpeg)

**[Adaptive Neural Finite-time Output Feedback Compensated Control for](https://link.springer.com/10.1007/978-981-99-6886-2_52?fromPaywallRec=true) [Stochastic Nonstrict-feedback Systems with Prescribed Performance](https://link.springer.com/10.1007/978-981-99-6886-2_52?fromPaywallRec=true)** 

Chapter © 2023

### **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Computational Intelligence](file:///subjects/computational-intelligence) •
- [Control and Systems Theory](file:///subjects/control-and-systems-theory) •
- [Cyber-Physical Systems](file:///subjects/cyber-physical-systems) •
- [Stochastic Systems and Control](file:///subjects/stochastic-systems-and-control) •
- [Stochastic Learning and Adaptive Control](file:///subjects/stochastic-learning-and-adaptive-control) •
- [Systems Theory, Control](file:///subjects/systems-theory-control-) •

# **Data Availability**

No datasets were generated or analysed during the current study.

# **References**

- Jiang, B., Niu, F., Wu, Z., Qiu, J.: Robust adaptive sliding mode security control of markov jump cyber-physical systems with stochastic injection attacks through eventtriggered-based observer approach. IEEE Trans. Syst. Man Cybern. Syst. 1–14 (2025). <https://doi.org/10.1109/TSMC.2025.3547020> 1.
- Zhang, L., Zhao, Z., Ma, Z., Zhao, N.: Prescribed performance adaptive neural eventtriggered control for switched nonlinear cyber cphysical systems under deception attacks. Neural Netw. **179**, 106586 (2024). [https://doi.org/10.1016/j.neunet.](https://doi.org/10.1016/j.neunet.2024.106586) [2024.106586](https://doi.org/10.1016/j.neunet.2024.106586) 2.

### [Article](https://doi.org/10.1016%2Fj.neunet.2024.106586) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Prescribed%20performance%20adaptive%20neural%20event-triggered%20control%20for%20switched%20nonlinear%20cyber%20cphysical%20systems%20under%20deception%20attacks&journal=Neural%20Netw.&doi=10.1016%2Fj.neunet.2024.106586&volume=179&publication_year=2024&author=Zhang%2CL&author=Zhao%2CZ&author=Ma%2CZ&author=Zhao%2CN)

Cuan, Z., Ding, D., Liu, X., Wang, Y.: Adaptive fuzzy control for state-constrained nonlinear cyber-physical systems with unmodeled dynamics against malicious attacks. IEEE Trans. Ind. Cyber-Phys. Syst. **1**, 56–65 (2023). [https://doi.org/10.1109/](https://doi.org/10.1109/TICPS.2023.3283232) [TICPS.2023.3283232](https://doi.org/10.1109/TICPS.2023.3283232) 3.

### [Article](https://doi.org/10.1109%2FTICPS.2023.3283232) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20fuzzy%20control%20for%20state-constrained%20nonlinear%20cyber-physical%20systems%20with%20unmodeled%20dynamics%20against%20malicious%20attacks&journal=IEEE%20Trans.%20Ind.%20Cyber-Phys.%20Syst.&doi=10.1109%2FTICPS.2023.3283232&volume=1&pages=56-65&publication_year=2023&author=Cuan%2CZ&author=Ding%2CD&author=Liu%2CX&author=Wang%2CY)

Mishra, A., Jha, A.V., Appasani, B., Ray, A.K., Gupta, D.K., Ghazali, A.N.: Emerging technologies and design aspects of next generation cyber physical system with a smart city application perspective. Int. J. Syst. Assur. Eng. Manag. **14**, 699–721 (2023). <https://doi.org/10.1007/s13198-021-01523-y> 4.

### [Article](https://link.springer.com/doi/10.1007/s13198-021-01523-y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Emerging%20technologies%20and%20design%20aspects%20of%20next%20generation%20cyber%20physical%20system%20with%20a%20smart%20city%20application%20perspective&journal=Int.%20J.%20Syst.%20Assur.%20Eng.%20Manag.&doi=10.1007%2Fs13198-021-01523-y&volume=14&pages=699-721&publication_year=2023&author=Mishra%2CA&author=Jha%2CAV&author=Appasani%2CB&author=Ray%2CAK&author=Gupta%2CDK&author=Ghazali%2CAN)

Wolf, M., Serpanos, D.: Safety and security in cyber-physical systems and internet-ofthings systems. Proc. IEEE **106**(1), 9–20 (2018). [https://doi.org/10.1109/JPROC.](https://doi.org/10.1109/JPROC.2017.2781198) [2017.2781198](https://doi.org/10.1109/JPROC.2017.2781198) 5.

### [Article](https://doi.org/10.1109%2FJPROC.2017.2781198) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Safety%20and%20security%20in%20cyber-physical%20systems%20and%20internet-of-things%20systems&journal=Proc.%20IEEE&doi=10.1109%2FJPROC.2017.2781198&volume=106&issue=1&pages=9-20&publication_year=2018&author=Wolf%2CM&author=Serpanos%2CD)

Lian, Y., Yang, Q., Liu, Y., Xie, W.: A spatio-temporal constrained hierarchical scheduling strategy for multiple warehouse mobile robots under industrial cyber 6.

cphysical system. Adv. Eng. Inform. **52**, 101572 (2022). [https://doi.org/10.1016/j.aei.](https://doi.org/10.1016/j.aei.2022.101572) [2022.101572](https://doi.org/10.1016/j.aei.2022.101572)

### [Article](https://doi.org/10.1016%2Fj.aei.2022.101572) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20spatio-temporal%20constrained%20hierarchical%20scheduling%20strategy%20for%20multiple%20warehouse%20mobile%20robots%20under%20industrial%20cyber%20cphysical%20system&journal=Adv.%20Eng.%20Inform.&doi=10.1016%2Fj.aei.2022.101572&volume=52&publication_year=2022&author=Lian%2CY&author=Yang%2CQ&author=Liu%2CY&author=Xie%2CW)

Zhang, L., Che, W., Deng, C., Wu, Z.-G.: Prescribed performance fuzzy resilient control for nonlinear systems under dos attacks. IEEE Trans. Syst. Man Cybern. Syst. **53**(5), 3104–3116 (2023). <https://doi.org/10.1109/TSMC.2022.3221371> 7.

### [Article](https://doi.org/10.1109%2FTSMC.2022.3221371) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Prescribed%20performance%20fuzzy%20resilient%20control%20for%20nonlinear%20systems%20under%20dos%20attacks&journal=IEEE%20Trans.%20Syst.%20Man%20Cybern.%20Syst.&doi=10.1109%2FTSMC.2022.3221371&volume=53&issue=5&pages=3104-3116&publication_year=2023&author=Zhang%2CL&author=Che%2CW&author=Deng%2CC&author=Wu%2CZ-G)

Cuan, Z., Ding, D., Yang, Y., Xia, Y.: Adaptive neural network finite-time control for nonlinear cyber-physical systems with external disturbances under malicious attacks. Neurocomputing **518**, 133–141 (2023). <https://doi.org/10.1016/j.neucom.2022.11.012> [Article](https://doi.org/10.1016%2Fj.neucom.2022.11.012) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20neural%20network%20finite-time%20control%20for%20nonlinear%20cyber-physical%20systems%20with%20external%20disturbances%20under%20malicious%20attacks&journal=Neurocomputing&doi=10.1016%2Fj.neucom.2022.11.012&volume=518&pages=133-141&publication_year=2023&author=Cuan%2CZ&author=Ding%2CD&author=Yang%2CY&author=Xia%2CY) 8.

Chen, Z., Yu, Z., Li, S.: Output feedback adaptive inverse optimal security control for stochastic nonlinear cyber-physical systems under sensor and actuator attacks. Nonlinear Dyn. **112**, 19243–19259 (2024). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-024-10043-w) [s11071-024-10043-w](https://doi.org/10.1007/s11071-024-10043-w) 9.

### [Article](https://link.springer.com/doi/10.1007/s11071-024-10043-w) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Output%20feedback%20adaptive%20inverse%20optimal%20security%20control%20for%20stochastic%20nonlinear%20cyber-physical%20systems%20under%20sensor%20and%20actuator%20attacks&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-024-10043-w&volume=112&pages=19243-19259&publication_year=2024&author=Chen%2CZ&author=Yu%2CZ&author=Li%2CS)

Zhu, G., Xu, Z., Gao, Y., Yu, Y., Li, L.: Periodic event-triggered adaptive neural output feedback tracking control of unmanned surface vehicles under replay attacks. Eng. Appl. Artif. Intell. **146**, 110237 (2025). [https://doi.org/10.1016/j.engappai.](https://doi.org/10.1016/j.engappai.2025.110237) [2025.110237](https://doi.org/10.1016/j.engappai.2025.110237) 10.

### [Article](https://doi.org/10.1016%2Fj.engappai.2025.110237) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Periodic%20event-triggered%20adaptive%20neural%20output%20feedback%20tracking%20control%20of%20unmanned%20surface%20vehicles%20under%20replay%20attacks&journal=Eng.%20Appl.%20Artif.%20Intell.&doi=10.1016%2Fj.engappai.2025.110237&volume=146&publication_year=2025&author=Zhu%2CG&author=Xu%2CZ&author=Gao%2CY&author=Yu%2CY&author=Li%2CL)

Song, S., Park, J.H., Zhang, B., Song, X.: Event-based adaptive fuzzy fixed-time secure control for nonlinear cpss against unknown false data injection and backlashlike hysteresis. IEEE Trans. Fuzzy Syst. **30**(6), 1939–1951 (2022). [https://doi.org/](https://doi.org/10.1109/TFUZZ.2021.3070700) [10.1109/TFUZZ.2021.3070700](https://doi.org/10.1109/TFUZZ.2021.3070700) 11.

[Article](https://doi.org/10.1109%2FTFUZZ.2021.3070700) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Event-based%20adaptive%20fuzzy%20fixed-time%20secure%20control%20for%20nonlinear%20cpss%20against%20unknown%20false%20data%20injection%20and%20backlash-like%20hysteresis&journal=IEEE%20Trans.%20Fuzzy%20Syst.&doi=10.1109%2FTFUZZ.2021.3070700&volume=30&issue=6&pages=1939-1951&publication_year=2022&author=Song%2CS&author=Park%2CJH&author=Zhang%2CB&author=Song%2CX)

Lu, G., Li, K., Li, Y.: Predefined time fuzzy adaptive tracking control for nonlinear cyber physical systems with unmeasurable states and fdi attacks. Nonlinear Dyn. **113**, 3389–3404 (2025). <https://doi.org/10.1007/s11071-024-10374-8> [Article](https://link.springer.com/doi/10.1007/s11071-024-10374-8) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Predefined%20time%20fuzzy%20adaptive%20tracking%20control%20for%20nonlinear%20cyber%20physical%20systems%20with%20unmeasurable%20states%20and%20fdi%20attacks&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-024-10374-8&volume=113&pages=3389-3404&publication_year=2025&author=Lu%2CG&author=Li%2CK&author=Li%2CY) 12.

Miao, B., Wang, H., Liu, Y., Liu, L.: Adaptive security control against false data injection attacks in cyber-physical systems. IEEE J. Emerg. Sel. Top. Circuits Syst. **13**(3), 743–751 (2023).<https://doi.org/10.1109/JETCAS.2023.3253483> [Article](https://doi.org/10.1109%2FJETCAS.2023.3253483) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2023IJEST..13..743M) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20security%20control%20against%20false%20data%20injection%20attacks%20in%20cyber-physical%20systems&journal=IEEE%20J.%20Emerg.%20Sel.%20Top.%20Circuits%20Syst.&doi=10.1109%2FJETCAS.2023.3253483&volume=13&issue=3&pages=743-751&publication_year=2023&author=Miao%2CB&author=Wang%2CH&author=Liu%2CY&author=Liu%2CL) 13.

Zou, S., Sun, M., Zhong, G., He, X.: Fuzzy adaptive learning secure control for nonstrict-pure-feedback cyber-physical systems subject to malicious attacks. IEEE Trans. Ind. Cyber-Phys. Syst. **2**, 626–638 (2024). [https://doi.org/10.1109/TICPS.](https://doi.org/10.1109/TICPS.2024.3481375) [2024.3481375](https://doi.org/10.1109/TICPS.2024.3481375) 14.

### [Article](https://doi.org/10.1109%2FTICPS.2024.3481375) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Fuzzy%20adaptive%20learning%20secure%20control%20for%20nonstrict-pure-feedback%20cyber-physical%20systems%20subject%20to%20malicious%20attacks&journal=IEEE%20Trans.%20Ind.%20Cyber-Phys.%20Syst.&doi=10.1109%2FTICPS.2024.3481375&volume=2&pages=626-638&publication_year=2024&author=Zou%2CS&author=Sun%2CM&author=Zhong%2CG&author=He%2CX)

- Yue, H., Zhang, J., Xia, J., Park, J.H., Xie, X.: Adaptive intelligent control for nonlinear stochastic cyber-physical systems with unknown deception attacks: Switching eventtriggered scheme. IEEE Trans. Circuits Syst. I Regul. Pap. **71**(12), 5571–5581 (2024). <https://doi.org/10.1109/TCSI.2024.3399757> 15.
- Zhang, Q., He, D.: Adaptive neural control of nonlinear cyber cphysical systems against randomly occurring false data injection attacks. IEEE Trans. Syst. Man Cybern. Syst. **53**(4), 2444–2455 (2023).<https://doi.org/10.1109/TSMC.2022.3212391> [Article](https://doi.org/10.1109%2FTSMC.2022.3212391) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20neural%20control%20of%20nonlinear%20cyber%20cphysical%20systems%20against%20randomly%20occurring%20false%20data%20injection%20attacks&journal=IEEE%20Trans.%20Syst.%20Man%20Cybern.%20Syst.&doi=10.1109%2FTSMC.2022.3212391&volume=53&issue=4&pages=2444-2455&publication_year=2023&author=Zhang%2CQ&author=He%2CD) 16.
- Chen, C., Liu, Z., Zhang, Y., Chen, C.L.P., Xie, S.: Saturated nussbaum function based approach for robotic systems with unknown actuator dynamics. IEEE Trans. Cybern. **46**(10), 2311–2322 (2016). <https://doi.org/10.1109/TCYB.2015.2475363> [Article](https://doi.org/10.1109%2FTCYB.2015.2475363) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Saturated%20nussbaum%20function%20based%20approach%20for%20robotic%20systems%20with%20unknown%20actuator%20dynamics&journal=IEEE%20Trans.%20Cybern.&doi=10.1109%2FTCYB.2015.2475363&volume=46&issue=10&pages=2311-2322&publication_year=2016&author=Chen%2CC&author=Liu%2CZ&author=Zhang%2CY&author=Chen%2CCLP&author=Xie%2CS) 17.
- Gao, Y., Niu, B., Chen, W., Wang, H., Mu, C., Wen, G.: Adaptive control of constrained nonlinear cpss under deception attacks through sensor and actuator 18.

- networks. IEEE Trans. Circuits Syst. II Express Briefs **71**(3), 1241–1245 (2024). <https://doi.org/10.1109/TCSII.2023.3318523>
- Zhang, X., Shi, J., Liu, H., Chen, F.: Adaptive fuzzy event-triggered cooperative control for fractional-order delayed multi-agent systems with unknown control direction. Math. Comput. Simul. **220**, 552–566 (2024). [https://doi.org/10.1016/](https://doi.org/10.1016/j.matcom.2024.02.007) [j.matcom.2024.02.007](https://doi.org/10.1016/j.matcom.2024.02.007) 19.

[Article](https://doi.org/10.1016%2Fj.matcom.2024.02.007) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4708751) [MATH](http://www.emis.de/MATH-item?1540.93057) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20fuzzy%20event-triggered%20cooperative%20control%20for%20fractional-order%20delayed%20multi-agent%20systems%20with%20unknown%20control%20direction&journal=Math.%20Comput.%20Simul.&doi=10.1016%2Fj.matcom.2024.02.007&volume=220&pages=552-566&publication_year=2024&author=Zhang%2CX&author=Shi%2CJ&author=Liu%2CH&author=Chen%2CF)

Liu, Y., Hao, L.: Adaptive tracking control for constrained nonlinear nonstrict-feedback switched stochastic systems with unknown control directions. Appl. Math. Comput. **473**, 128666 (2024). <https://doi.org/10.1016/j.amc.2024.128666> 20.

[Article](https://doi.org/10.1016%2Fj.amc.2024.128666) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4719159) [MATH](http://www.emis.de/MATH-item?1545.93597) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20tracking%20control%20for%20constrained%20nonlinear%20nonstrict-feedback%20switched%20stochastic%20systems%20with%20unknown%20control%20directions&journal=Appl.%20Math.%20Comput.&doi=10.1016%2Fj.amc.2024.128666&volume=473&publication_year=2024&author=Liu%2CY&author=Hao%2CL)

Chen, P., Luan, X., Liu, F.: Reduced-order k-filters-based event-triggered adaptive command filtered tracking control for stochastic constrained nonlinear systems. J. Franklin Inst. **360**(7), 4519–4547 (2023). [https://doi.org/10.1016/j.jfranklin.](https://doi.org/10.1016/j.jfranklin.2023.02.026) [2023.02.026](https://doi.org/10.1016/j.jfranklin.2023.02.026) 21.

[Article](https://doi.org/10.1016%2Fj.jfranklin.2023.02.026) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4563562) [MATH](http://www.emis.de/MATH-item?1516.93026) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reduced-order%20k-filters-based%20event-triggered%20adaptive%20command%20filtered%20tracking%20control%20for%20stochastic%20constrained%20nonlinear%20systems&journal=J.%20Franklin%20Inst.&doi=10.1016%2Fj.jfranklin.2023.02.026&volume=360&issue=7&pages=4519-4547&publication_year=2023&author=Chen%2CP&author=Luan%2CX&author=Liu%2CF)

Ji, H., Xu, S., Zhang, H., Li, C., Xu, Y.: Stochastic stability of networked control systems with packet disordering via a gain-scheduling controller. Appl. Math. Comput. **494**, 129282 (2025). <https://doi.org/10.1016/j.amc.2025.129282> 22.

[Article](https://doi.org/10.1016%2Fj.amc.2025.129282) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4849806) [MATH](http://www.emis.de/MATH-item?08030344) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Stochastic%20stability%20of%20networked%20control%20systems%20with%20packet%20disordering%20via%20a%20gain-scheduling%20controller&journal=Appl.%20Math.%20Comput.&doi=10.1016%2Fj.amc.2025.129282&volume=494&publication_year=2025&author=Ji%2CH&author=Xu%2CS&author=Zhang%2CH&author=Li%2CC&author=Xu%2CY)

Zhang, L., Wang, P., Hua, C.: Event-triggered output feedback control for low-order stochastic nonlinear time-delay systems with stochastic inverse dynamics. ISA Trans. **158**, 11–20 (2025). <https://doi.org/10.1016/j.isatra.2024.12.031> 23.

[Article](https://doi.org/10.1016%2Fj.isatra.2024.12.031) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Event-triggered%20output%20feedback%20control%20for%20low-order%20stochastic%20nonlinear%20time-delay%20systems%20with%20stochastic%20inverse%20dynamics&journal=ISA%20Trans.&doi=10.1016%2Fj.isatra.2024.12.031&volume=158&pages=11-20&publication_year=2025&author=Zhang%2CL&author=Wang%2CP&author=Hua%2CC)

Liu, Y., Zhu, Q.: Adaptive neural network asymptotic tracking control for nonstrict feedback stochastic nonlinear systems. Neural Netw. **143**, 283–290 (2021). [https://](https://doi.org/10.1016/j.neunet.2021.06.011) [doi.org/10.1016/j.neunet.2021.06.011](https://doi.org/10.1016/j.neunet.2021.06.011) 24.

### [Article](https://doi.org/10.1016%2Fj.neunet.2021.06.011) [MATH](http://www.emis.de/MATH-item?1526.93124) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20neural%20network%20asymptotic%20tracking%20control%20for%20nonstrict%20feedback%20stochastic%20nonlinear%20systems&journal=Neural%20Netw.&doi=10.1016%2Fj.neunet.2021.06.011&volume=143&pages=283-290&publication_year=2021&author=Liu%2CY&author=Zhu%2CQ)

Qi, X., Liu, W., Lu, Y.: Event-triggered-based fuzzy adaptive tracking control for nonstrict-feedback asymmetric state constrained systems. Fuzzy Sets Syst. **470**, 108642 (2023). <https://doi.org/10.1016/j.fss.2023.108642> 25.

[Article](https://doi.org/10.1016%2Fj.fss.2023.108642) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4620657) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Event-triggered-based%20fuzzy%20adaptive%20tracking%20control%20for%20nonstrict-feedback%20asymmetric%20state%20constrained%20systems&journal=Fuzzy%20Sets%20Syst.&doi=10.1016%2Fj.fss.2023.108642&volume=470&publication_year=2023&author=Qi%2CX&author=Liu%2CW&author=Lu%2CY)

Zouari, F., Ibeas, A., Boulkroune, A., Cao, J.: Finite-time adaptive event-triggered output feedback intelligent control for noninteger order nonstrict feedback systems with asymmetric time-varying pseudo-state constraints and nonsmooth input nonlinearities. Commun. Nonlinear Sci. Numer. Simul. **136**, 108036 (2024). [https://](https://doi.org/10.1016/j.cnsns.2024.108036) [doi.org/10.1016/j.cnsns.2024.108036](https://doi.org/10.1016/j.cnsns.2024.108036) 26.

[Article](https://doi.org/10.1016%2Fj.cnsns.2024.108036) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4753362) [MATH](http://www.emis.de/MATH-item?1542.93358) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Finite-time%20adaptive%20event-triggered%20output%20feedback%20intelligent%20control%20for%20noninteger%20order%20nonstrict%20feedback%20systems%20with%20asymmetric%20time-varying%20pseudo-state%20constraints%20and%20nonsmooth%20input%20nonlinearities&journal=Commun.%20Nonlinear%20Sci.%20Numer.%20Simul.&doi=10.1016%2Fj.cnsns.2024.108036&volume=136&publication_year=2024&author=Zouari%2CF&author=Ibeas%2CA&author=Boulkroune%2CA&author=Cao%2CJ)

Xia, X., Zhang, T., Yi, Y., Shen, Q.: Adaptive prescribed performance control of output feedback systems including input unmodeled dynamics. Neurocomputing **190**, 226– 236 (2016). <https://doi.org/10.1016/j.neucom.2016.01.014> 27.

[Article](https://doi.org/10.1016%2Fj.neucom.2016.01.014) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20prescribed%20performance%20control%20of%20output%20feedback%20systems%20including%20input%20unmodeled%20dynamics&journal=Neurocomputing&doi=10.1016%2Fj.neucom.2016.01.014&volume=190&pages=226-236&publication_year=2016&author=Xia%2CX&author=Zhang%2CT&author=Yi%2CY&author=Shen%2CQ)

- Xu, Z., Zhou, X., Dong, Z., Hu, X., Sun, C., Shen, H.: Observer-based prescribed performance adaptive neural output feedback control for full-state-constrained nonlinear systems with input saturation. Chaos Solitons Fractals **173**, 113593 (2023). <https://doi.org/10.1016/j.chaos.2023.113593> 28.
- Wu, Z., Zhang, T., Xia, X., Hua, Y.: Finite-time adaptive neural command filtered control for non-strict feedback uncertain multi-agent systems including prescribed performance and input nonlinearities. Appl. Math. Comput. **421**, 126953 (2022). <https://doi.org/10.1016/j.amc.2022.126953> 29.

[Article](https://doi.org/10.1016%2Fj.amc.2022.126953) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4373330) [MATH](http://www.emis.de/MATH-item?1510.93162) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Finite-time%20adaptive%20neural%20command%20filtered%20control%20for%20non-strict%20feedback%20uncertain%20multi-agent%20systems%20including%20prescribed%20performance%20and%20input%20nonlinearities&journal=Appl.%20Math.%20Comput.&doi=10.1016%2Fj.amc.2022.126953&volume=421&publication_year=2022&author=Wu%2CZ&author=Zhang%2CT&author=Xia%2CX&author=Hua%2CY)

Kong, L., Reis, J., He, W., Yu, X., Silvestre, C.: On dynamic performance control for a quadrotor-slung-load system with unknown load mass. Automatica **162**, 111516 (2024). <https://doi.org/10.1016/j.automatica.2024.111516> 30.

### [Article](https://doi.org/10.1016%2Fj.automatica.2024.111516) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4689242) [MATH](http://www.emis.de/MATH-item?1536.93432) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20dynamic%20performance%20control%20for%20a%20quadrotor-slung-load%20system%20with%20unknown%20load%20mass&journal=Automatica&doi=10.1016%2Fj.automatica.2024.111516&volume=162&publication_year=2024&author=Kong%2CL&author=Reis%2CJ&author=He%2CW&author=Yu%2CX&author=Silvestre%2CC)

Kanellakopoulos, I., Kokotovic, P., Morse, A.: Systematic design of adaptive controllers for feedback linearizable systems. IEEE Trans. Autom. Control **36**(11), 1241–1253 (1991). <https://doi.org/10.1109/9.100933> 31.

[Article](https://doi.org/10.1109%2F9.100933) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1130494) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Systematic%20design%20of%20adaptive%20controllers%20for%20feedback%20linearizable%20systems&journal=IEEE%20Trans.%20Autom.%20Control&doi=10.1109%2F9.100933&volume=36&issue=11&pages=1241-1253&publication_year=1991&author=Kanellakopoulos%2CI&author=Kokotovic%2CP&author=Morse%2CA)

Swaroop, D., Hedrick, J., Yip, P., Gerdes, J.: Dynamic surface control for a class of nonlinear systems. IEEE Trans. Autom. Control **45**(10), 1893–1899 (2000). [https://](https://doi.org/10.1109/TAC.2000.880994) [doi.org/10.1109/TAC.2000.880994](https://doi.org/10.1109/TAC.2000.880994) 32.

[Article](https://doi.org/10.1109%2FTAC.2000.880994) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1795360) [MATH](http://www.emis.de/MATH-item?0991.93041) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Dynamic%20surface%20control%20for%20a%20class%20of%20nonlinear%20systems&journal=IEEE%20Trans.%20Autom.%20Control&doi=10.1109%2FTAC.2000.880994&volume=45&issue=10&pages=1893-1899&publication_year=2000&author=Swaroop%2CD&author=Hedrick%2CJ&author=Yip%2CP&author=Gerdes%2CJ)

Tong, S., Li, Y.: Robust adaptive fuzzy backstepping output feedback tracking control for nonlinear system with dynamic uncertainties. Sci. China Inf. Sci. **53**(307), C324 (2010). <https://doi.org/10.1007/s11432-010-0031-y> 33.

[Article](https://link.springer.com/doi/10.1007/s11432-010-0031-y) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2671665) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Robust%20adaptive%20fuzzy%20backstepping%20output%20feedback%20tracking%20control%20for%20nonlinear%20system%20with%20dynamic%20uncertainties&journal=Sci.%20China%20Inf.%20Sci.&doi=10.1007%2Fs11432-010-0031-y&volume=53&issue=307&publication_year=2010&author=Tong%2CS&author=Li%2CY)

- Wang, D., Huang, J.: Neural network-based adaptive dynamic surface control for a class of uncertain nonlinear systems in strict-feedback form. IEEE Trans. Neural Networks **16**(1), 195–202 (2005). <https://doi.org/10.1109/TNN.2004.839354> 34.
- Spall, J., Cristion, J.: A neural network controller for systems with unmodeled dynamics with applications to wastewater treatment. IEEE Trans. Syst. Man Cybern. B, Cybern. **27**(3), 369–375 (1997).<https://doi.org/10.1109/3477.584945> 35.
- Wang, N., Lv, S., Er, M.J., Chen, W.-H.: Fast and accurate trajectory tracking control of an autonomous surface vehicle with unmodeled dynamics and disturbances. IEEE Trans. Intell. Veh. **1**(3), 230–243 (2016). <https://doi.org/10.1109/TIV.2017.2657379> 36.
- Yu, Y., Guo, J., Ahn, C.K., Xiang, Z.: Neural adaptive distributed formation control of nonlinear multi-uavs with unmodeled dynamics. IEEE Trans. Neural Netw. Learn. Syst. **34**(11), 9555–9561 (2023). <https://doi.org/10.1109/TNNLS.2022.3157079> 37.

- Luo, R., Peng, Z., Hu, J., Ghosh, B.K.: Adaptive optimal control of affine nonlinear systems via identifier ccritic neural network approximation with relaxed pe conditions. Neural Netw. **167**, 588–600 (2023). <https://doi.org/10.1016/j.neunet.2023.08.044> [Article](https://doi.org/10.1016%2Fj.neunet.2023.08.044) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20optimal%20control%20of%20affine%20nonlinear%20systems%20via%20identifier%20ccritic%20neural%20network%20approximation%20with%20relaxed%20pe%20conditions&journal=Neural%20Netw.&doi=10.1016%2Fj.neunet.2023.08.044&volume=167&pages=588-600&publication_year=2023&author=Luo%2CR&author=Peng%2CZ&author=Hu%2CJ&author=Ghosh%2CBK) 38.
- Chen, G., Dong, J.: Approximate optimal adaptive prescribed performance control for uncertain nonlinear systems with feature information. IEEE Trans. Syst. Man Cybern. Syst. **54**(4), 2298–2308 (2024).<https://doi.org/10.1109/TSMC.2023.3342854> [Article](https://doi.org/10.1109%2FTSMC.2023.3342854) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Approximate%20optimal%20adaptive%20prescribed%20performance%20control%20for%20uncertain%20nonlinear%20systems%20with%20feature%20information&journal=IEEE%20Trans.%20Syst.%20Man%20Cybern.%20Syst.&doi=10.1109%2FTSMC.2023.3342854&volume=54&issue=4&pages=2298-2308&publication_year=2024&author=Chen%2CG&author=Dong%2CJ) 39.
- Zhu, B., Karimi, H.R., Zhang, L., Zhao, X.: Neural network-based adaptive reinforcement learning for optimized backstepping tracking control of nonlinear systems with input delay. Appl. Intell. **55**, 129 (2025). [https://doi.org/](https://doi.org/10.1007/510489-024-05932-x) [10.1007/510489-024-05932-x](https://doi.org/10.1007/510489-024-05932-x) 40.

### [Article](https://link.springer.com/doi/10.1007/510489-024-05932-x) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Neural%20network-based%20adaptive%20reinforcement%20learning%20for%20optimized%20backstepping%20tracking%20control%20of%20nonlinear%20systems%20with%20input%20delay&journal=Appl.%20Intell.&doi=10.1007%2F510489-024-05932-x&volume=55&publication_year=2025&author=Zhu%2CB&author=Karimi%2CHR&author=Zhang%2CL&author=Zhao%2CX)

- Wen, G., Chen, C.L.P., Ge, S.S., Yang, H., Liu, X.: Optimized adaptive nonlinear tracking control using actor ccritic reinforcement learning strategy. IEEE Trans. Industr. Inf. **15**(9), 4969–4977 (2019). <https://doi.org/10.1109/TII.2019.2894282> [Article](https://doi.org/10.1109%2FTII.2019.2894282) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optimized%20adaptive%20nonlinear%20tracking%20control%20using%20actor%20ccritic%20reinforcement%20learning%20strategy&journal=IEEE%20Trans.%20Industr.%20Inf.&doi=10.1109%2FTII.2019.2894282&volume=15&issue=9&pages=4969-4977&publication_year=2019&author=Wen%2CG&author=Chen%2CCLP&author=Ge%2CSS&author=Yang%2CH&author=Liu%2CX) 41.
- Zhang, T., Xu, H., Xia, X., Yi, Y.: Adaptive neural optimal control of uncertain nonlinear systems with output constraints. Neurocomputing **406**, 182–195 (2020). <https://doi.org/10.1016/j.neucom.2020.04.007> 42.

### [Article](https://doi.org/10.1016%2Fj.neucom.2020.04.007) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20neural%20optimal%20control%20of%20uncertain%20nonlinear%20systems%20with%20output%20constraints&journal=Neurocomputing&doi=10.1016%2Fj.neucom.2020.04.007&volume=406&pages=182-195&publication_year=2020&author=Zhang%2CT&author=Xu%2CH&author=Xia%2CX&author=Yi%2CY)

Chen, P., Luan, X., Wang, Z., Zhang, T., Ge, Y., Liu, F.: Adaptive neural optimal tracking control of stochastic nonstrict-feedback nonlinear systems with output constraints. J. Franklin Inst. **360**(16), 12299–12338 (2023). [https://doi.org/10.1016/](https://doi.org/10.1016/j.jfranklin.2023.09.006) [j.jfranklin.2023.09.006](https://doi.org/10.1016/j.jfranklin.2023.09.006) 43.

[Article](https://doi.org/10.1016%2Fj.jfranklin.2023.09.006) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4650765) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20neural%20optimal%20tracking%20control%20of%20stochastic%20nonstrict-feedback%20nonlinear%20systems%20with%20output%20constraints&journal=J.%20Franklin%20Inst.&doi=10.1016%2Fj.jfranklin.2023.09.006&volume=360&issue=16&pages=12299-12338&publication_year=2023&author=Chen%2CP&author=Luan%2CX&author=Wang%2CZ&author=Zhang%2CT&author=Ge%2CY&author=Liu%2CF)

Wen, G., Chen, C.L.P.: Optimized backstepping consensus control using reinforcement learning for a class of nonlinear strict-feedback-dynamic multi-agent systems. IEEE Trans. Neural Netw. Learn. Syst. **34**(3), 1524–1536 (2023) 44.

### [Article](https://doi.org/10.1109%2FTNNLS.2021.3105548) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4560649) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optimized%20backstepping%20consensus%20control%20using%20reinforcement%20learning%20for%20a%20class%20of%20nonlinear%20strict-feedback-dynamic%20multi-agent%20systems&journal=IEEE%20Trans.%20Neural%20Netw.%20Learn.%20Syst.&doi=10.1109%2FTNNLS.2021.3105548&volume=34&issue=3&pages=1524-1536&publication_year=2023&author=Wen%2CG&author=Chen%2CCLP)

Lan, J., Liu, Y., Yu, D., Wen, G., Tong, S., Liu, L.: Time-varying optimal formation control for second-order multiagent systems based on neural network observer and reinforcement learning. IEEE Trans. Neural Netw. Learn. Syst. **35**(3), 3144–3155 (2024) 45.

### [Article](https://doi.org/10.1109%2FTNNLS.2022.3158085) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4714057) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-varying%20optimal%20formation%20control%20for%20second-order%20multiagent%20systems%20based%20on%20neural%20network%20observer%20and%20reinforcement%20learning&journal=IEEE%20Trans.%20Neural%20Netw.%20Learn.%20Syst.&doi=10.1109%2FTNNLS.2022.3158085&volume=35&issue=3&pages=3144-3155&publication_year=2024&author=Lan%2CJ&author=Liu%2CY&author=Yu%2CD&author=Wen%2CG&author=Tong%2CS&author=Liu%2CL)

Hua, Y., Zhang, T.: Adaptive finite-time optimal fuzzy control for novel constrained uncertain nonstrict feedback mixed multiagent systems via modified dynamic surface control. Inf. Sci. **681**, 121216 (2024).<https://doi.org/10.1016/j.ins.2024.121216> 46.

### [Article](https://doi.org/10.1016%2Fj.ins.2024.121216) [MATH](http://www.emis.de/MATH-item?1542.93345) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Adaptive%20finite-time%20optimal%20fuzzy%20control%20for%20novel%20constrained%20uncertain%20nonstrict%20feedback%20mixed%20multiagent%20systems%20via%20modified%20dynamic%20surface%20control&journal=Inf.%20Sci.&doi=10.1016%2Fj.ins.2024.121216&volume=681&publication_year=2024&author=Hua%2CY&author=Zhang%2CT)

- Dao, P.N., Duc, H.A.N., Liu, Y.: Reinforcement-learning-based control framework for leader-following cascade formation of multiple perturbed surface vehicles. Syst. Control Lett. **200**, 106077 (2025) 47.
- Nguyen, K., Dang, V.T., Pham, D.D., Dao, P.N.: Formation control scheme with reinforcement learning strategy for a group of multiple surface vehicles. Int. J. Robust Nonlinear Control **34**(3), 2252–2279 (2024) 48.

### [Article](https://doi.org/10.1002%2Frnc.7083) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4693474) [MATH](http://www.emis.de/MATH-item?1533.93034) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Formation%20control%20scheme%20with%20reinforcement%20learning%20strategy%20for%20a%20group%20of%20multiple%20surface%20vehicles&journal=Int.%20J.%20Robust%20Nonlinear%20Control&doi=10.1002%2Frnc.7083&volume=34&issue=3&pages=2252-2279&publication_year=2024&author=Nguyen%2CK&author=Dang%2CVT&author=Pham%2CDD&author=Dao%2CPN)

Wu, R., Yao, Z., Si, J., Huang, H.H.: Robotic knee tracking control to mimic the intact human knee profile based on actor-critic reinforcement learning. IEEE/CAA J. Autom. Sin. **9**(1), 19–30 (2022) 49.

### [Article](https://doi.org/10.1109%2FJAS.2021.1004272) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4339325) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Robotic%20knee%20tracking%20control%20to%20mimic%20the%20intact%20human%20knee%20profile%20based%20on%20actor-critic%20reinforcement%20learning&journal=IEEE%2FCAA%20J.%20Autom.%20Sin.&doi=10.1109%2FJAS.2021.1004272&volume=9&issue=1&pages=19-30&publication_year=2022&author=Wu%2CR&author=Yao%2CZ&author=Si%2CJ&author=Huang%2CHH)

Cao, Z., Niu, Y., Song, J.: Finite-time sliding-mode control of markovian jump cyberphysical systems against randomly occurring injection attacks. IEEE Trans. Autom. Control **65**(3), 1264–1271 (2019) 50.

### [Article](https://doi.org/10.1109%2FTAC.2019.2926156) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4084069) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Finite-time%20sliding-mode%20control%20of%20markovian%20jump%20cyber-physical%20systems%20against%20randomly%20occurring%20injection%20attacks&journal=IEEE%20Trans.%20Autom.%20Control&doi=10.1109%2FTAC.2019.2926156&volume=65&issue=3&pages=1264-1271&publication_year=2019&author=Cao%2CZ&author=Niu%2CY&author=Song%2CJ)

Dawson, D., Carroll, J., Schneider, M.: Integrator backstepping control of a brush dc motor turning a robotic load. IEEE Trans. Control Syst. Technol. **2**(3), 233–244 (1994). <https://doi.org/10.1109/87.317980> 51.

[Article](https://doi.org/10.1109%2F87.317980) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Integrator%20backstepping%20control%20of%20a%20brush%20dc%20motor%20turning%20a%20robotic%20load&journal=IEEE%20Trans.%20Control%20Syst.%20Technol.&doi=10.1109%2F87.317980&volume=2&issue=3&pages=233-244&publication_year=1994&author=Dawson%2CD&author=Carroll%2CJ&author=Schneider%2CM)

Ma, Z., Tong, S.: Nonlinear filters-based adaptive fuzzy control of strict-feedback nonlinear systems with unknown asymmetric dead-zone output. IEEE Trans. Autom. Sci. Eng. **21**(4), 5099–5109 (2024). <https://doi.org/10.1109/TASE.2023.3308528> [Article](https://doi.org/10.1109%2FTASE.2023.3308528) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20filters-based%20adaptive%20fuzzy%20control%20of%20strict-feedback%20nonlinear%20systems%20with%20unknown%20asymmetric%20dead-zone%20output&journal=IEEE%20Trans.%20Autom.%20Sci.%20Eng.&doi=10.1109%2FTASE.2023.3308528&volume=21&issue=4&pages=5099-5109&publication_year=2024&author=Ma%2CZ&author=Tong%2CS) 52.

Cui, Y., Zhang, H., Wang, Y., Jiang, H.: A fuzzy adaptive tracking control for mimo switched uncertain nonlinear systems in strict-feedback form. IEEE Trans. Fuzzy Syst. **27**(12), 2443–2452 (2019) 53.

[Article](https://doi.org/10.1109%2FTFUZZ.2019.2900610) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20fuzzy%20adaptive%20tracking%20control%20for%20mimo%20switched%20uncertain%20nonlinear%20systems%20in%20strict-feedback%20form&journal=IEEE%20Trans.%20Fuzzy%20Syst.&doi=10.1109%2FTFUZZ.2019.2900610&volume=27&issue=12&pages=2443-2452&publication_year=2019&author=Cui%2CY&author=Zhang%2CH&author=Wang%2CY&author=Jiang%2CH)

[Download references](https://citation-needed.springer.com/v2/references/10.1007/s11071-025-11737-5?format=refman&flavour=references)

# **Funding**

This funding was supported by the National Natural Science Foundation of China under Grant 61991402 and Grant 62073154, in part by the China Scholarship Council under Grant 202306790017, in part by the Postgraduate Research & Practice Innovation Program of Jiangsu Province under Grant KYCX22\_2304, in part by the Horizon Europe program under the Marie Sklodowska-Curie under Grant 101073037, in part by the Italian Ministry of University and Research under Grant P2022EXP2W.

# **Author information**

### **Authors and Affiliations**

<span id="page-13-0"></span>Key Laboratory of Advanced Process Control for Light Industry (Ministry of Education), Institute of Automation, Jiangnan University, Wuxi, 214122, China 1.

Penghao Chen, Xiaoli Luan & Fei Liu

<span id="page-14-1"></span>Department of Mechanical Engineering, Politecnico di Milano, Milan, 20156, Italy 2.

Penghao Chen & Hamid Reza Karimi

### Authors

<span id="page-14-0"></span>Penghao Chen 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Penghao%20Chen)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Penghao%20Chen) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Penghao%20Chen%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-14-2"></span>Hamid Reza Karimi 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Hamid%20Reza%20Karimi)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Hamid%20Reza%20Karimi) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Hamid%20Reza%20Karimi%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-14-3"></span>Xiaoli Luan 3.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Xiaoli%20Luan)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xiaoli%20Luan) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xiaoli%20Luan%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-14-4"></span>Fei Liu 4.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Fei%20Liu)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Fei%20Liu) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Fei%20Liu%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

### **Contributions**

Penghao Chen wrote the main manuscript, conducted experiments, and prepared all the figures. Hamid Reza Karimi, Xiaoli Luan and Fei Liu edited the main manuscript and the figures. All authors reviewed the manuscript.

### **Corresponding authors**

Correspondence to [Hamid Reza Karimi](mailto:hamidreza.karimi@polimi.it) or [Xiaoli Luan.](mailto:xlluan@jiangnan.edu.cn)

# **Ethics declarations**

### **Competing interests**

The authors declare no competing interests.

# **Additional information**

### **Publisher's Note**

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

# **Appendices**

### **Lemmas**

### **Lemma 1**

( [[21](file:///article/10.1007/s11071-025-11737-5#ref-CR21)]): Consider the following stochastic nonlinear system

\$\$\begin{aligned} d\aleph =f(t,\aleph )dt+\psi (t,\aleph )dw \end{aligned}\$\$

where \(\aleph \in R^{n }\) is the state vector, *w* is an r-dimensional standard brownian motion, \(f(t,\aleph )\) and \(\psi (t,\aleph )\) are two locally Lipschitz bounded functions. Given arbitrary \(V(t,\aleph )\in C^{1,2}\) with respect to the stochastic nonlinear system, we have

\$\$\begin{aligned} dV(t,\aleph )=LV(t,\aleph )dt+\frac{\partial V(t,\aleph )}{\partial \aleph }\psi dw \end{aligned}\$\$

where the infinitesimal generator *L* is described as:

\$\$\begin{aligned} LV(t,\aleph )&=\frac{\partial V(t,\aleph )}{\partial t}+\frac{\partial V(t, \aleph )}{\partial \aleph ^T}f\\ &\quad +\frac{1}{2}Tr[\psi \frac{\partial ^2V(t,\aleph )}{\partial \aleph ^T\partial \aleph }\psi ^T]. \end{aligned}\$\$

### **Lemma 2**

( [[21](file:///article/10.1007/s11071-025-11737-5#ref-CR21)]): Suppose there exists a \(C^2\) positive definite function \(V(t,\aleph )\) along with two constants \(c\_1 >0,c\_2 \ge 0\) and two functions \(\chi \_1,\chi \_2 \in k\_\infty \) such that

\$\$\begin{aligned}&\chi \_1 (\left\| \aleph \right\| )\le V(t,\aleph )\le \chi \_2 (\left\| \aleph \right\| )\\&\quad LV\le -c\_1 V+c\_2 \end{aligned}\$\$

Then, for arbitrary initial state \(\aleph (0) \in R^n\), there exists a unique solution for stochastic nonlinear system, and the following inequality holds

\$\$\begin{aligned} E[V(t ,\aleph )]\le E[V(0 ,\aleph (0) )]e^{-c\_1 t}+\frac{c\_2 }{c\_1 },\forall t\ge 0. \end{aligned}\$\$

### **Lemma 3**

( [[17](file:///article/10.1007/s11071-025-11737-5#ref-CR17)]): Regarding arbitrary differentiable functions \(V(\cdot )>0\), \({K}\_{i} \ne 0\), \ (\lambda \_{i} (\cdot )\) defined on \([0,t\_f )\), and \(N(\lambda \_{i} (\cdot ))\) is the Nussbaum function, provided that a sufficient constant \(c\_0 \) exists such that

\$\$\begin{aligned} V(t)\le c\_0 +\sum \limits \_{i=1}^{n}{{\int \_{0}^{t}{({{K}\_{i}}N(\lambda \_{i} (\tau ) )+1)\dot{\lambda }\_{i}{{e}^{{{\alpha }\_{0}}(\tau -t)}}d\tau }}} \end{aligned}\$\$

thus, \(\int \_0^t {({K}\_{i}N(\lambda \_{i} (\tau ))+1)\dot{\lambda }\_{i}e^{\alpha \_{0} (\tau -t)} d\tau }\), \(\lambda \_{i}(t)\) and *V*(*t*) must be bounded on \([0,t\_f )\).

### **Lemma 4**

( [[34](file:///article/10.1007/s11071-025-11737-5#ref-CR34)]): For the unknown smooth continuous function \(h\_i (S\_i )\), \(W\_{hi} ^T S\_{hi} (S\_i ) \) is the approximation of RBFNNs over \(\Omega \_{S\_i } \). And, we get

\$\$\begin{aligned} h\_i (S\_i )=W\_{hi} ^T S \_{hi} (S\_i )+\varepsilon \_{hi} (S\_i ),\forall S\_i \in \Omega \_{S\_i } \end{aligned}\$\$

where \(S\_{hi} (S\_i )=[S \_{hi1} (S\_i ),\ldots ,S \_{hil\_i } (S\_i )]^T:\Omega \_{S\_i } \rightarrow R^{l\_i }\) is the basis function vector, \(l\_i \) denotes the number of neurons, each basis function \(S\_{hij}(S\_i )\) is selected as the following Gaussian function:

```
$$\begin{aligned} S_{hij} (S_i )=\exp (\frac{-\left\| {S_i -b_{hij} } \right\| ^2}{d_{hij}
^2}),j=1,\ldots ,l_i \end{aligned}$$
```

where \(b\_{hij} ,d\_{hij} \) are the center vector and width of the Gaussian function \(S\_{hij} (S\_i )\), respectively. \(S\_i \), \(h\_i (S\_i ), i=1,\ldots ,n\) are given separately in Section [4.](file:///article/10.1007/s11071-025-11737-5#Sec4) The optimal weight vector \(W\_{hi} =[W\_{hi1} ,\ldots ,W\_{hil\_i } ]^T\) is defined as

\$\$\begin{aligned} W\_{hi} =\arg \mathop {\min }\limits \_{W\_{hi} \in R^{l\_i }} \left\{ {\mathop {\sup }\limits \_{S\_i \in \Omega \_{S\_i } } \left| {h\_i (S\_i )-W\_{hi} ^T S \_{hi} (S\_i )} \right| } \right\} . \end{aligned}\$\$

### **The proof of Theorem 1**

To present the proof process more clearly, it is divided into four parts.

```
PART I: Choose the Lyapunov functions as \(V_1 =V_{z1} +\frac{1}{2}\tilde{W}_{h1}^T
\tilde{W}_{h1} +\frac{1}{2}\tilde{W}_{c1}^T \tilde{W}_{c1} +\frac{1}{2}\tilde{W}_{a1}^T
\tilde{W}_{a1}\), where \(V_{z1} =\frac{1}{4}z_1^4\). Taking the infinitesimal generator of \
(V_{z1}\), we have \( LV_{z1} = {\breve{z}} _1^3 h_1 (S_1 )-k_1 z_1^4 +k_1 M_{\epsilon }
g_1 (x)\varsigma _1^3 \varsigma _2 {\breve{z}} _1^4 +z_1^3 M_{\epsilon } g_1 (x)
\varsigma _2 ({\breve{z}} _2 +y_2 +\alpha _1 )-\frac{9z_1^4 }{8a_1 }M_{\epsilon }^4 \left\|
{\psi _1 } \right\| ^4+\frac{3z_1^2 }{2}M_{\epsilon }^2 \psi _1^T \psi _1+\dot{\lambda }_1 -
\dot{\lambda }_1 \). In view of \( N(\lambda _1 )\dot{\lambda }_1 ={\breve{z}} _1^3 {\alpha }
_1+k_1{\breve{z}} _1^4\), combined with the help of formulas (19), (20), (23), (24), (26) and
using Young's inequality, let \(K_1=M_{\epsilon } g_1 (x)\varsigma _1^3 \varsigma _2\), \
(a_1\) being a design positive constant, we have
```

\$\$\begin{aligned}&LV\_1 \le -(k\_1 -\frac{3}{2}M\_{\epsilon }^{\frac{4}{3}} )z\_1^4 +\frac{a\_1 } {2}+\frac{1}{4}g\_{1,1}^4 z\_2^4 \\&\quad +\frac{1}{4}y\_2^4 g\_{1,1}^4 \varsigma \_{2,1}^4 + {\breve{z}} \_1^3 \varepsilon \_{hX1} (S\_1 )-\rho \_1 \tilde{W}\_{c1}^T {\hat{W}}\_{c1} \nonumber \\&\quad +(K\_1 N(\lambda \_1 )+1)\dot{\lambda }\_1 -\frac{3}{2\beta \_1 } {\breve{z}} \_1^6 \\&\quad -\gamma \_{h1} S\_{h1} (X\_1 )S\_{h1}^T (X\_1 )\tilde{W}\_{h1}^T \ \&\quad \hat{W}\_{h1} -\rho \_1 \tilde{W}\_{h1}^T {\hat{W}}\_{h1} \nonumber \\&\quad - \gamma \_{c1} \tilde{W}\_{c1}^T S\_{J1} (X\_1 )S\_{J1}^T (X\_1 ){\hat{W}}\_{c1}\nonumber \ \&\quad -\gamma \_{a1} \tilde{W}\_{a1}^T S\_{J1} (X\_1 )S\_{J1}^T (X\_1 ){\hat{W}} \_{a1}\nonumber \\&\quad -\rho \_1 \tilde{W}\_{a1}^T {\hat{W}}\_{a1} \nonumber \\&-

{\breve{z}} \_1^3 W\_{J1}^{\*^T} S\_{J1} (X\_1 )+{\breve{z}} \_1^3 \tilde{W}\_{c1}^T S\_{J1} (X\_1 )\nonumber \\&\quad +(\gamma \_{a1} -\gamma \_{c1} )\tilde{W}\_{a1}^T S\_{J1} (X\_1 )S\_{J1}^T (X\_1 ){\hat{W}}\_{c1} \end{aligned}\$\$

Recalling the first-order filter [\(13](file:///article/10.1007/s11071-025-11737-5#Equ13)) and considering Lemma 1 as well as the infinitesimal generator of \(\alpha \_1\), that is, \(L{\alpha }\_1 =\frac{\partial {\alpha }\_1 }{\partial {\breve{x}} \_1 }(\frac{1}{\varsigma \_1 }f\_1 (x)+\frac{\varsigma \_2 }{\varsigma \_1 }g\_1 (x) {\breve{x}} \_2 -\frac{\dot{\varsigma }\_1^2 }{\varsigma \_1 }{\breve{x}} \_1 )+\frac{\partial {\alpha }\_1 }{\partial \omega \_1 }\dot{\omega }\_1 +\frac{\partial {\alpha }\_1 }{\partial {\hat{W}}\_{h1} }\dot{\hat{W}}\_{h1} +\frac{\partial {\alpha }\_1 }{\partial {\hat{W}}\_{a1} } \dot{{\hat{W}}}\_{a1} +\frac{1}{2\varsigma \_1^2 }\frac{\partial ^2 {\alpha }\_1 }{\partial {\breve{x}} \_1^2 }\psi \_1^T \psi \_1\) and \( d{\alpha }\_1 =L{\alpha }\_1 dt+\frac{\partial {\alpha }\_1 }{\partial {\breve{x}} \_1 }\frac{1}{\varsigma \_1 }\psi \_1^T dw \), yields the infinitesimal generator of \(y\_{2}\) can be obtained as \(Ly\_2 =\dot{\omega }\_2 -L {\alpha } \_1 =-\frac{y\_2 }{\tau \_2 }-L{\alpha }\_1\) and \(dy\_2 =Ly\_2 dt-\frac{\partial {\alpha }\_1 } {\partial {\breve{x}} \_1 }\frac{1}{\varsigma \_1 }\psi \_1^T dw\). Moreover, we get \( L(\frac{1} {4}y\_{2}^4 ) =-y\_{2}^3 (\frac{y\_{2} }{\tau \_{2} }+L {\alpha }\_1 )+\frac{3}{2\varsigma \_1^2 } y\_2^2 (\frac{\partial {\alpha }\_1 }{\partial {\breve{x}} \_1 })^2\psi \_1^T \psi \_1\). In view of \ (\frac{3}{2\varsigma \_1^2 }y\_2^2 (\frac{\partial {\alpha }\_1 }{\partial {\breve{x}} \_1 })^2\psi \_1^T \psi \_1 \le \eta \_{2} (\breve{x}\_1 ,y\_d ,{w}\_2 )\) and \( \left| {L {y}\_{2} +\frac{y\_{2} } {\tau \_{2} }} \right| \le \iota \_{2}(\breve{x}\_1 ,y\_d ,{w}\_2,\dot{w}\_2 ) \), where \(\iota \_{2} (\cdot ), \eta \_{2} (\cdot )\) are non-negative continuous functions. Then, it follows that \ ( L(\frac{1}{4}y\_{2}^4 ) \le -\frac{y\_{2} ^4}{\tau \_{2} }+\left| {y\_{2}^3 } \right| \iota \_{2}+\eta \_{2} \le -\frac{y\_{2} ^2}{\tau \_{2} }+\frac{3}{4}y\_{2} ^4+\frac{1}{4}\iota \_{2} ^4+\eta \_{2} \).

**PART II:** Choose the Lyapunov functions as \(V\_i =V\_{zi} +\frac{1}{2}\tilde{W}\_{hi}^T \tilde{W}\_{hi} +\frac{1}{2}\tilde{W}\_{ci}^T \tilde{W}\_{ci} +\frac{1}{2}\tilde{W}\_{ai}^T \tilde{W} \_{ai}\), where \(V\_{zi} =\frac{1}{4}z\_i^4\). Taking the infinitesimal generator of \(V\_{zi}\), we have \(LV\_{zi} =z\_i^3 g\_i (x)\varsigma \_{i+1} ({\breve{z}} \_{i+1} +y\_{i+1} +\alpha \_i )+ {\breve{z}} \_i^3 h\_i (S\_i )-k\_i z\_i^4 +k\_i g\_i (x)\varsigma \_i^3 \varsigma \_{i+1} {\breve{z}} \_i^4+\frac{3z\_i^2 }{2}\psi \_i^T \psi \_i-\frac{9z\_i^4 }{8a\_i }\left\| {\psi \_i } \right\| ^4+ \dot{\lambda }\_i -\dot{\lambda }\_i\). In view of \( N(\lambda \_i )\dot{\lambda }\_i ={\breve{z}} \_i^3 {\alpha }\_i+k\_i{\breve{z}} \_i^4 \), with the help of Equations [\(34\)](file:///article/10.1007/s11071-025-11737-5#Equ34), [\(35\)](file:///article/10.1007/s11071-025-11737-5#Equ35), [\(37\)](file:///article/10.1007/s11071-025-11737-5#Equ37), [\(38\)](file:///article/10.1007/s11071-025-11737-5#Equ38), [\(39\)](file:///article/10.1007/s11071-025-11737-5#Equ39)

and using Young's inequality, let \(K\_i=g\_i (x)\varsigma \_i^3 \varsigma \_{i+1}\), \(a\_i\) being a design positive constant, we have

```
$$\begin{aligned}&LV_i \le {\breve{z}} _i^3 \varepsilon _{hXi} (S_i )+\frac{a_i }{2}-\frac{3}
{2\beta _i }{\breve{z}} _i^6 -(k_i -\frac{3}{2})z_i^4\nonumber \\&\quad +\left( {K_i N(\lambda
_i )+1} \right) \dot{\lambda }_i \nonumber \\&\quad +\frac{1}{4}z_{i+1}^4 g_{i,1}^4 +\frac{1}
{4}y_{i+1}^4 g_{i,1}^4 \varsigma _{i+1,1}^4 -\rho _i \tilde{W}_{hi}^T {\hat{W}}_{hi}
\nonumber \\&\quad -\rho _i \tilde{W}_{ci}^T {\hat{W}}_{ci} -\rho _i \tilde{W}_{ai}^T
{\hat{W}}_{ai} \nonumber \\&\quad -{\breve{z}} _i^3 \tilde{W}_{ci}^T S_{Ji} (X_i ) \nonumber
\\&\quad -\gamma _{hi} \tilde{W}_{hi}^T S_{hi} (X_i )S_{hi}^T (X_i ){\hat{W}}_{hi}
\nonumber \\&\quad -\gamma _{ci} \tilde{W}_{ci}^T S_{Ji} (X_i )S_{Ji}^T (X_i ){\hat{W}}
_{ci} \nonumber \\&\quad -{\breve{z}} _i^3 W_{Ji}^{*^T} S_{Ji} (X_i ) \nonumber \\&-\gamma
_{ai} \tilde{W}_{ai}^T (S_{Ji} (X_i )S_{Ji}^T (X_i ){\hat{W}}_{ai} \nonumber \\&\quad +
(\gamma _{ai} -\gamma _{ci} )\tilde{W}_{ai}^T (S_{Ji} (X_i )S_{Ji}^T (X_i ){\hat{W}}_{ci}
\end{aligned}$$
```

Recalling the first-order filter [\(13](file:///article/10.1007/s11071-025-11737-5#Equ13)) and considering Lemma 1 as well as the infinitesimal generator of \(\alpha \_i\), that is, \(L{\alpha }\_i=-\sum \limits \_{j=1}^i \frac{\partial {\alpha } \_i }{\partial {\breve{x}} \_j }(\frac{1}{\varsigma \_i }f\_i (x)+\frac{\varsigma \_{i+1} }{\varsigma \_i }g\_i (x){\breve{x}} \_{i+1} -\frac{\dot{\varsigma }\_i^2 }{\varsigma \_i }{\breve{x}} \_i ) - \frac{\partial {\alpha }\_i}{\partial \omega \_i }\dot{\omega }\_i -\frac{\partial {\alpha }\_i } {\partial {\hat{W}}\_{hi} }\dot{\hat{W}}\_{hi} -\frac{\partial {\alpha }\_i }{\partial {\hat{W}}\_{ai} } \dot{{\hat{W}}}\_{ai} -\frac{1}{2\varsigma \_i^2 }\sum \limits \_{p,q=1}^i \frac{\partial ^2 {\alpha }\_i}{\partial {\breve{x}} \_p^T \partial {\breve{x}} \_q }\psi \_p^T \psi \_q \) and \( d {\alpha }\_i =L {\alpha }\_i dt+\sum \limits \_{j=1}^i {\frac{\partial {\alpha }\_i }{\partial {\breve{x}} \_j }\frac{1}{\varsigma \_j }\psi \_j^T dw} \), yields the infinitesimal generator of \ (y\_{i+1}\) can be obtained as \(Ly\_{i+1} =\dot{\omega }\_{i+1} -L {\alpha }\_i=-\frac{y\_{i+1} } {\tau \_{i+1} }-L{\alpha }\_i\) and \(dy\_{i+1} =Ly\_{i+1} dt-\sum \limits \_{j=1}^i {(\frac{\partial {\alpha }\_i }{\partial \breve{x} \_j })\frac{1}{\varsigma \_j }\psi \_j^T dw}\). Moreover, we get \ ( L(\frac{1}{4}y\_{i+1}^4 ) =-y\_{i+1}^3 (\frac{y\_{i+1} }{\tau \_{i+1} }+L {\alpha }\_i )+\frac{3}{2} y\_{i+1}^2 [\sum \limits \_{j=1}^i (\frac{\partial {\alpha }\_i }{\partial \breve{x} \_j })\frac{1} {\varsigma \_j }\psi \_j^T ] [\sum \limits \_{j=1}^i (\frac{\partial {\alpha }\_i }{\partial \breve{x} \_j })\frac{1}{\varsigma \_j }\psi \_j ]\). In view of \(\frac{3}{2}y\_{i+1}^2 [\sum \limits \_{j=1}^i (\frac{\partial {\alpha }\_i }{\partial \breve{x} \_j })\frac{1}{\varsigma \_j }\psi \_j^T ] [\sum \limits \_{j=1}^i {(\frac{\partial {\alpha }\_i }{\partial \breve{x} \_j })\frac{1}{\varsigma \_j }\psi \_j }] \le \eta \_{i+1} (\breve{x}\_1 ,\ldots , \breve{x}\_i,{\omega }\_i,{\omega }\_{i+1})\) and \( \left| {L {y} \_{i+1} +\frac{y\_{i+1} }{\tau \_{i+1} }} \right| \le \iota \_{i+1}(\breve{x}\_1 ,\ldots , \breve{x}\_i, {\omega }\_i,{\omega }\_{i+1},\dot{w}\_{i+1} ) \), where \(\iota \_{i+1} (\cdot ), \eta \_{i+1} (\cdot )\) are non-negative continuous functions. Then, it follows that \( L(\frac{1}{4}y\_{i+1} ^4 ) \le -\frac{y\_{i+1} ^4}{\tau \_{i+1} }+\left| {y\_{i+1}^3 } \right| \iota \_{i+1}+\eta \_{i+1} \le - \frac{y\_{i+1} ^2}{\tau \_{i+1} }+\frac{3}{4}y\_{i+1} ^4+\frac{1}{4}\iota \_{i+1} ^4+\eta \_{i+1} \).

**PART III:** Choose the Lyapunov functions as \(V\_n =V\_{zn} +\frac{1}{2}\tilde{W}\_{hn}^T \tilde{W}\_{hn} +\frac{1}{2}\tilde{W}\_{cn}^T \tilde{W}\_{cn} +\frac{1}{2}\tilde{W}\_{an}^T \tilde{W}\_{an}\), where \(V\_{zn} =\frac{1}{4}z\_n^4\). Taking the infinitesimal generator of \ (V\_{zn}\), we have \( LV\_{zn} =z\_n^3 g\_n (x)u+{\breve{z}} \_n^3 h\_n (S\_n )+\frac{a\_n }{2} k\_n z\_n^4 +k\_n \varsigma \_n^3 g\_n (x) {\breve{z}} \_n^4+\frac{3z\_n^2 }{2}\psi \_n^T \psi \_n- \frac{9z\_n^4 }{8a\_n }\left\| {\psi \_n } \right\| ^4+\dot{\lambda }\_n -\dot{\lambda }\_n \). In view of \( N(\lambda \_n )\dot{\lambda }\_n ={\breve{z}} \_n^3 u+k\_n{\breve{z}} \_n^4 \), with the help of Equations ([45](file:///article/10.1007/s11071-025-11737-5#Equ45)), ([46](file:///article/10.1007/s11071-025-11737-5#Equ46)), ([47](file:///article/10.1007/s11071-025-11737-5#Equ47)), ([49](file:///article/10.1007/s11071-025-11737-5#Equ49)), ([50](file:///article/10.1007/s11071-025-11737-5#Equ50)) and using Young's inequality, let \ (K\_n=\varsigma \_n^3 g\_n (x)\), \(a\_n\) be a design positive constant, we have

\$\$\begin{aligned} LV\_n&\le (K\_n N(\lambda \_n )+1)\dot{\lambda }\_n +{\breve{z}} \_n^3 \varepsilon \_{hXn} (S\_n )\\&\quad +\frac{a\_n }{2}-k\_n z\_n^4 -\rho \_n \tilde{W}\_{hn}^T {\hat{W}}\_{hn}-\rho \_n \tilde{W}\_{cn}^T {\hat{W}}\_{cn}\nonumber \\&\quad -\rho \_n \tilde{W} \_{an}^T {\hat{W}}\_{an} \nonumber \\&\quad -\frac{3}{2\beta \_n }{\breve{z}} \_n^6-{\breve{z}} \_n^3 \tilde{W}\_{cn}^T S\_{Jn} (X\_n ) \nonumber \\&\quad -\gamma \_{hn} \tilde{W}\_{hn}^T S\_{hn} (X\_n )S\_{hn}^T (X\_n ){\hat{W}}\_{hn} \nonumber \\&\quad -\gamma \_{cn} \tilde{W} \_{cn}^T S\_{Jn} (X\_n )S\_{Jn}^T (X\_n ){\hat{W}}\_{cn} \nonumber \\ &\quad -{\breve{z}} \_n^3 W\_{Jn}^{\*^T} S\_{Jn} (X\_n ) \nonumber \\&\quad -\gamma \_{an} \tilde{W}\_{an}^T (S\_{Jn} (X\_n )S\_{Jn}^T (X\_n ){\hat{W}}\_{an}\nonumber \\&\quad +(\gamma \_{an} -\gamma \_{cn} ) \tilde{W}\_{an}^T (S\_{Jn} (X\_n )S\_{Jn}^T (X\_n ){\hat{W}}\_{cn} \end{aligned}\$\$

**PART IV**: For \(\varpi >0\) and \(B\_0>0\) are arbitrarily given scalars, the set \(\Omega \_d =\{\left[ {y\_d ,\dot{y}\_d ,\ddot{y}\_d } \right] ^T:y\_d ^2+\dot{y}\_d ^2+\ddot{y}\_d ^2\le B\_0 \} \subset R^3\) and \(\Omega \_\varpi =\{ [{\bar{z}}\_n^T ,{\bar{y}}\_n^T ,\bar{{{\hat{W}}}}\_{hn} ^T ,\bar{{{\hat{W}}}}\_{cn}^T,\bar{{{\hat{W}}}}\_{an}^T]^T:V\le \varpi \}\subset R^{5n-1 }\) are compact. Over the compact set \(\Omega \_\varpi \times \Omega \_d\), for \(i=1,\ldots , n-1\), \(\left| {\iota \_{i+1} } \right| \) has a maximum \(O\_{i+1}\), \(\left| \eta \_{i+1} \right| \) has a

```
maximum \(M_{i+1}\), \(S_{hi} (X_i )S_{hi}^T (X_i )\) has a minimum \( \lambda _{S_{hi} }
^{\min } \), \(S_{Ji} (X_i )S_{Ji}^T (X_i )\) has a minimum \( \lambda _{S_{Ji} }^{\min }\).
Select the total Lyapunov function candidate as \( V=\sum \limits _{i=1}^n {(\frac{1}
{2}\tilde{W}_{hi}^T \tilde{W}_{hi} +\frac{1}{2}\tilde{W}_{ci}^T \tilde{W}_{ci} +\frac{1}
{2}\tilde{W}_{ai}^T \tilde{W}_{ai} )}+\sum \limits _{i=1}^n {\frac{1}{4}z_i^4 } +\sum \limits
_{i=1}^{n-1} {\frac{1}{4}y_{i+1}^4 }\). Take the infinitesimal generator of V, yields, \(LV=\sum
\limits _{i=1}^n {LV_i } +\sum \limits _{i=1}^{n-1} L ({\frac{1}{4}y_{i+1}^4)}\). In addition,
combined with \(LV_1\), \(LV_i\), \(LV_n\), \(L ({\frac{1}{4}y_{i+1}^4)}\) and the application of
Young's inequality, we can establish
```

```
$$\begin{aligned} LV&\le -(k_1 -\frac{3}{2}M_{\epsilon }^{\frac{4}{3}} )z_1^4 -\sum \limits
_{i=2}^{n-1} {(k_i -\frac{3}{2}-\frac{1}{4}g_{i-1,1}^4 )z_i^4 } \\&\quad -(k_n -\frac{1}{4}g_{n,
1}^4 )z_n^4 \\&\quad -\sum \limits _{i=1}^{n-1} {(\frac{1}{\tau _{i+1} }-\frac{3}{4}-\frac{1}{4}
g_{i,1}^4 \varsigma _{i+1,1}^4 )y_{i+1}^4 } \\&\quad +\sum \limits _{i=1}^n {\left( {K_i
N(\lambda _i )+1} \right) \dot{\lambda }_i } +\sum \limits _{i=1}^{n-1} {(\frac{1}{4}{O _{i+1}
^4}+M_{i+1}) }\\&\quad -\sum \limits _{i=1}^n {\frac{\gamma _{hi} }{2}\tilde{W}_{hi}^T S_{hi}
(X_i )S_{hi}^T (X_i )\tilde{W}_{hi} }\\&\quad -\sum \limits _{i=1}^n {\frac{\rho _i }{2}\tilde{W}
_{hi}^T \tilde{W}_{hi} } \nonumber \\&\quad +\sum \limits _{i=1}^n \left[ \frac{\gamma _{hi} }
{2}W_{hi}^{*^T} S_{hi} (X_i )S_{hi}^T (X_i )W_{hi}^*\right. \\&\quad \left. +\frac{\rho _i }{2}
W_{hi}^{*^T} W_{hi}^*\right] +\sum \limits _{i=1}^n {\left[ {\frac{a_i }{2}+\frac{\beta _i }
{2}\varepsilon _{hXi}^2 (M_i )} \right] } \\&\quad -\sum \limits _{i=1}^n (\frac{\rho _i }
{2}\tilde{W}_{ci}^T \tilde{W}_{ci} \\&\quad -\frac{\gamma _{ai} -2\gamma _{ci} +\beta _i }
{2}\tilde{W}_{ci}^T S_{Ji} (X_i )S_{Ji}^T (X_i )\tilde{W}_{ci} ) \\&\quad -\sum \limits _{i=1}^n
(\frac{\rho _i }{2}\tilde{W}_{ai}^T \tilde{W}_{ai}\\&\quad -\frac{\gamma _{ai} -2\gamma
_{ci} }{2}\tilde{W}_{ai}^T S_{Ji} (X_i )S_{Ji}^T (X_i )\tilde{W}_{ai} ) \\&\quad +\sum \limits
_{i=1}^n \left[ \frac{2\gamma _{ai} +\beta _i }{2}W_{Ji}^{*^T} S_{Ji} (X_i )S_{Ji}^T
(X_i )W_{Ji}^*\right. \\ &\quad \left. +\rho _i {W}_{Ji}^{*^T} {W}_{Ji}^*\right] \end{aligned}$$
```

Substituting [\(51](file:///article/10.1007/s11071-025-11737-5#Equ51)) into the above formula, the following results hold

```
$$\begin{aligned} LV\le -\alpha V+\mu _0 +\sum \limits _{i=1}^n {\left( {K_i N(\lambda _i )
+1} \right) \dot{\lambda }_i } \end{aligned}$$
```

where

\$\$\begin{aligned}&\mu \_0=\sum \limits \_{i=1}^{n-1} (\frac{1}{4}{O \_{i+1}^4} +M\_{i+1})+ \sum \limits \_{i=1}^n \\&\quad {\left[ {\frac{2\gamma \_{ai} +\beta \_i }{2}W\_{Ji}^{\*^T} S\_{Ji} (X\_i )S\_{Ji}^T (X\_i )W\_{Ji}^\*+\rho \_i {W}\_{Ji}^{\*^T} {W}\_{Ji}^\*} \right] } \nonumber \\&\quad +\sum \limits \_{i=1}^n {\left[ {\frac{a\_i }{2}+\frac{\beta \_i }{2}\varepsilon \_{hXi}^2 (M\_i )} \right] } +\sum \limits \_{i=1}^n\\&\quad {\left[ {\frac{\gamma \_{hi} }{2}W\_{hi}^{\*^T} S\_{hi} (X\_i )S\_{hi}^T (X\_i )W\_{hi}^\*+\frac{\rho \_i }{2}W\_{hi}^{\*^T} W\_{hi}^\*} \right] } \end{aligned} \$\$

If \(V\le \varpi \), then \({\bar{z}}\_n^T ,{\bar{y}}\_n^T ,\bar{\tilde{W}}\_{hn}^T,\bar{\tilde{W}} \_{cn}^T \) and \(\bar{\tilde{W}}\_{an}^T \) are bounded. Then, it yields \({\hat{W}}\_{h1} , \ldots ,{\hat{W}}\_{hn}\), \({\hat{W}}\_{c1} ,\ldots ,{\hat{W}}\_{cn}\), \({\hat{W}}\_{a1} ,\ldots , {\hat{W}}\_{an}\) are bounded. In addition, through formulas [\(19\)](file:///article/10.1007/s11071-025-11737-5#Equ19), [\(34\)](file:///article/10.1007/s11071-025-11737-5#Equ34), and ([45](file:///article/10.1007/s11071-025-11737-5#Equ45)), we obtain \ (\alpha \_i, u \in L\_\infty \). From \(z\_1 =\frac{\varsigma \_1 {\breve{\epsilon }} } {H(\varepsilon ,\zeta \_1 \mu (t),\zeta \_2 \mu (t))}\) and \(\varsigma \_1 \) are both bounded, we get \( \breve{\epsilon } \) is bounded. Noting \(\breve{x}\_1 =\breve{\epsilon } + {y}\_d \) and \( y\_d\in L\_\infty \), we have \(\breve{x}\_1 \in L\_\infty \). In view of \({x}\_1=\varsigma \_1\breve{x}\_1\), it gives \(x\_1 \in L\_\infty \), i.e., \(y\in L\_\infty \). On the basis of \({z} \_i=\varsigma \_i\breve{z}\_i\) and \(\varsigma \_i\in L\_\infty \), we deduce \(\breve{z}\_i\) are bounded. Since \(\breve{x}\_{i+1} =\breve{z}\_{i+1} +y\_{i+1} +\alpha \_i \) and \({x}\_i =\varsigma \_i\breve{x}\_i \), we acquire \(x\_i \) are bounded.

Furthermore, multiply both sides of the formula \(\frac{d(EV)}{dt}=E(LV)\le -\alpha EV+\mu \_0 +\sum \limits \_{i=1}^n {\left( {K\_i N(\lambda \_i )+1} \right) \dot{\lambda }\_i } \) by \ (e^{\alpha t}\) and integrate over [0, *t*], it yields \(0\le EV\le \frac{\mu \_0 }{\alpha }+(V(0)- \frac{\mu \_0 }{\alpha })e^{-\alpha t}+\frac{1}{\alpha }\sum \limits \_{i=1}^n \int \_0^t (K\_i N(\lambda \_i (\tau ))+1)\dot{\lambda }\_i e^{\alpha (\tau -t)}d\tau \). In view of Lemma 3, *V* , \(\lambda \_i (\tau )\) and \(\sum \limits \_{i=1}^n {\int \_0^t {(K\_i N(\lambda \_i (\tau )) +1)\dot{\lambda }\_i e^{\alpha (\tau -t)}d\tau } } \) are bounded within time interval \(\Phi (0,+ \infty )\). Combined with the help of bounded value \(\mu =\mu \_0 +\sum \limits \_{i=1}^n {\left( {K\_i N(\lambda \_i )+1} \right) \dot{\lambda }\_i } \), one gets

\$\$\begin{aligned} LV\le -\alpha V+\mu \end{aligned}\$\$

Additionally, multiply both sides of the formula \(\frac{d(EV)}{dt}=E(LV)\le -\alpha EV+\mu \) by \(e^{\alpha t}\) and integrate over \([t\_k ,t]\) with \(t\in [t\_k ,t\_{k+1} )\), it yields \(EV(t)\le

e^{-\alpha (t-t\_k )}EV(t\_k^+ )+\mu \int \_{t\_k }^t {e^{-\alpha (t-s)}} ds\le \beta e^{-\alpha (tt\_k )}EV(t\_k^- )+\mu \int \_{t\_k }^t {e^{-\alpha (t-s)}} ds\), and the detailed discussion on \ (\beta \) can be found in [\[53\]](file:///article/10.1007/s11071-025-11737-5#ref-CR53). For arbitrary \(t>t\_0 =0\), choose the *k* in the lower limit \(t\_k \) of the previous integral from 0 to *n*(0, *t*), with Young's inequality, the following inequality can be deduced

\$\$\begin{aligned}&EV(t) \le \beta e^{-\alpha (t-t\_{n(0,t)} )}\\&\quad [e^{-\alpha (t\_{n(0,t)} t\_{n(0,t)-1} )}EV(t\_{n(0,t)-1} )\\&\quad +\mu \int \_{t\_{n(0,t)-1} }^{t\_{n(0,t)} } {e^{-\alpha (t\_{n(0,t)} -s)}} ds]+\mu \int \_{t\_k }^t {e^{-\alpha (t-s)}} ds\\&\quad \le e^{-\alpha t+n(0,t)\ln \beta }V(0)+\mu \int \_0^t {e^{-\alpha (t-s)+n(s,t)\ln \beta }} ds \end{aligned}\$\$

According to average dwell time \(\wp \_0 >\frac{\ln \beta }{\alpha }\) and \(n(0,t)\le \frac{t} {\wp \_0 }\) with \(\eta \_0 =\wp =0\) in Assumption [2](file:///article/10.1007/s11071-025-11737-5#FPar2), we can determine that \(n(0,t)\ln \beta <\alpha t\) is content. In addition, we find that for arbitrary \(\vartheta \in (0,\alpha -\frac{\ln \beta }{\wp \_0 })\), \(\wp \_0 >\frac{\ln \beta }{\alpha -\vartheta }\) holds. Then, the following inequality can be obtained \(n(0,t)\le \frac{(\alpha -\vartheta )t}{\ln \beta }\), similarly, we can easily obtain \(n(s,t)\le \frac{(\alpha -\vartheta )(t-s)}{\ln \beta }\). Invoking the known result, we obtain

\$\$\begin{aligned} EV(t) \le e^{-\vartheta t} V(0) + \mu \int \_0^t e^{-\vartheta (t - s)} \, ds \end{aligned}\$\$

Since the energy of the Lyapunov function decays monotonically, i.e., the result can converge to a range smaller than the initial value *V*(0), it yields \(0\le EV\le \frac{\mu } {\vartheta }+(V(0)-\frac{\mu }{\vartheta })e^{-\vartheta t}\le V(0)\le \varpi \). Thus, all of the closed-loop system's signals are SGUUB, and the tracking error converge within the funnel. Therefore, the stability of the entire closed-loop CPSs is proved, completing the proof of Theorem 1.

# **Rights and permissions**

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author selfarchiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

### [Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Funnel%20adaptive%20neural%20learning%20secure%20control%20for%20nonlinear%20cyber-physical%20systems%20under%20stochastic%20FDI%20attacks&author=Penghao%20Chen%20et%20al&contentID=10.1007%2Fs11071-025-11737-5©right=The%20Author%28s%29%2C%20under%20exclusive%20licence%20to%20Springer%20Nature%20B.V.&publication=0924-090X&publicationDate=2025-08-31&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

![](_page_24_Picture_2.jpeg)

### <span id="page-24-0"></span>**Cite this article**

Chen, P., Karimi, H.R., Luan, X. *et al.* Funnel adaptive neural learning secure control for nonlinear cyber-physical systems under stochastic FDI attacks. *Nonlinear Dyn* (2025). https://doi.org/10.1007/s11071-025-11737-5

### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s11071-025-11737-5?format=refman&flavour=citation)

Received: 27 May 2025 •

Revised: 12 July 2025 •

Accepted: 20 August 2025 •

Published: 31 August 2025 •

DOI: https://doi.org/10.1007/s11071-025-11737-5 •

### **Keywords**

- [Funnel adaptive control](file:///search?query=Funnel%20adaptive%20control&facet-discipline=%22Physics%22) •
- [Reinforcement learning](file:///search?query=Reinforcement%20learning&facet-discipline=%22Physics%22) •
- [Stochastic FDI attacks](file:///search?query=Stochastic%20FDI%20attacks&facet-discipline=%22Physics%22) •
- [Cyber-physical systems](file:///search?query=Cyber-physical%20systems&facet-discipline=%22Physics%22) •

# **Associated Content**

Part of a collection:

### **[Control Systems and Synchronization](file:///collections/dgiiiafdia)**

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11071-025-11737-5)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11071-025-11737-5                                                                                                       |
| 1573-269X                                                                                                                        |
| Funnel adaptive neural learning secure control for nonlinear cyber-physical systems under stochastic FDI attacks                 |
| 2025                                                                                                                             |
| 2025                                                                                                                             |
| Penghao Chen, et al.                                                                                                             |
| Nonlinear Dynamics                                                                                                               |
| b68a0ad6cbb05546788b0763abe569514e7ac95f3cf1d1696ab867f7e331f5139774d4457269d53c0e25e0ef1560afecb7f3bd02c6e9c607ba52868e8ac44131 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

### [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals)

Advertisement

# <span id="page-26-1"></span>**Search**

| Search by keyword or author |  |  |  |
|-----------------------------|--|--|--|
|                             |  |  |  |
|                             |  |  |  |

Search

# <span id="page-26-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

[Our products](https://www.springernature.com/gp/products) •

- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature