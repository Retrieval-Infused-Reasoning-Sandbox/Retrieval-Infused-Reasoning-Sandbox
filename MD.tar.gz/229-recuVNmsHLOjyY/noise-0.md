Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- <span id="page-0-0"></span>1. Home >
- 2. Nonlinear Dynamics >
- 3. Article

# Advances in stability, bifurcations and nonlinear vibrations in mechanical systems

- Preface
- Published: 29 March 2021
- Volume 103, pages 2993–2995, (2021)
- · Cite this article

## Download PDF

![](_page_0_Picture_16.jpeg)

Nonlinear Dynamics Aims and scope Submit manuscript

![](_page_0_Picture_18.jpeg)

Advances in stability, bifurcations and nonlinear vibrations in mechanical systems

Download PDF

- Angelo Luongo <sup>1</sup>,
- Michael J. Leamy<sup>2</sup>,

- Stefano Lenci<sup>3</sup>.
- Giuseppe Piccardo 4 &
- ...
- Cyril Touzé<sup>5</sup>

## Show authors

- 2098 Accesses
- 9 Citations
- Explore all metrics

Use our pre-submission checklist

Avoid common mistakes on your manuscript.

The present Special Issue was initially conceived for presenting a survey of recent studies carried out by researchers participating in the Dynamics and Stability Group (GADeS) within the Italian Society of Theoretical and Applied Mechanics (AIMETA). GADeS was founded in 2011 thanks to the initiative of Prof. Angelo Luongo, under the umbrella of AIMETA, with the aim of sharing knowledge on the topics of dynamics and stability across different research fields, including applied mathematics, civil and mechanical engineering. Specifically, this Special Issue was supposed to present the developments of some of the research presented at the most recent GADeS symposium as part of the 2019 AIMETA Conference.

The breadth of the topics covered and their importance at an international level led us, in agreement and with the support of the Editor-in-Chief, Prof. Walter Lacarbonara, to enlarge the domestic viewpoint, and to consider a fully international Special Issue by inviting worldwide renowned scientists in order to give a broader view on recent advances in stability, bifurcations and nonlinear vibrations that may involve different kinds of mechanical systems. Actually, while having old and well-consolidated roots, this is a modern, active and challenging research field, with new applications in science and engineering and lots of new exciting developments.

The papers selected for the present Special Issue can be roughly collected into four broad areas, each collecting a certain number of papers, all related to the aforementioned topics.

A first grouping of papers deals with problems of stability and bifurcations arising in fluid/ structure problems with a special emphasis on aeroelastic systems. Problems related to flutter analysis in classical or supersonic conditions [[1](#page-3-0),[2](#page-3-1),[3](file:///article/10.1007/s11071-021-06404-4#ref-CR3)], vortex-induced vibrations [\[4,](file:///article/10.1007/s11071-021-06404-4#ref-CR4) [5](file:///article/10.1007/s11071-021-06404-4#ref-CR5)] and galloping instabilities [\[6,](file:///article/10.1007/s11071-021-06404-4#ref-CR6) [7](file:///article/10.1007/s11071-021-06404-4#ref-CR7)] are thoughtfully addressed, together with more theoretical problems related to the Ziegler column [[8](file:///article/10.1007/s11071-021-06404-4#ref-CR8)] and the existence of global attractors in subsonic flows [\[9\]](file:///article/10.1007/s11071-021-06404-4#ref-CR9).

A second grouping of papers addresses vibration control. One paper deals with a passive control method incorporating a nonlinear energy sink [[10](file:///article/10.1007/s11071-021-06404-4#ref-CR10)], while two papers address active control in sliding mode [\[11\]](file:///article/10.1007/s11071-021-06404-4#ref-CR11) or by command shaping [[12](file:///article/10.1007/s11071-021-06404-4#ref-CR12)]. The problems of time-delay dynamics with a perspective on control are also investigated with the development of a continuation method [[13\]](file:///article/10.1007/s11071-021-06404-4#ref-CR13) and the analysis of active control for a rotating beam [\[14\]](file:///article/10.1007/s11071-021-06404-4#ref-CR14).

A third grouping tackles problems arising in the field of reduced-order modeling for nonlinear vibration problems. Friction is addressed via adaptive basis [\[15\]](file:///article/10.1007/s11071-021-06404-4#ref-CR15) and substructuring [\[16\]](file:///article/10.1007/s11071-021-06404-4#ref-CR16). Nonconservative nonlinearities are treated with an extended energy balance method [\[17\]](file:///article/10.1007/s11071-021-06404-4#ref-CR17), while geometric nonlinearities are addressed by comparing modal derivatives to invariant manifolds obtained from normal form theory [\[18\]](file:///article/10.1007/s11071-021-06404-4#ref-CR18).

The last grouping of papers addresses new frontiers and emerging problems in the general theory of nonlinear vibrations. Stability and bifurcation problems have been addressed for a long time due to their importance in physics and engineering applications, and a large part of the theory, as well as dedicated applications, is now well covered in the literature. Research in this general area is nonetheless still very active with new frontiers and new problems appearing due to additional complexities. These new frontiers are covered in this Special Issue by addressing problems related to global bifurcations [\[19](file:///article/10.1007/s11071-021-06404-4#ref-CR19)], stability of nonlinear normal modes [\[20\]](file:///article/10.1007/s11071-021-06404-4#ref-CR20), localization of symmetric systems [\[21\]](file:///article/10.1007/s11071-021-06404-4#ref-CR21), identification of backbone curves [[22](file:///article/10.1007/s11071-021-06404-4#ref-CR22)], modal energy exchange [\[23](file:///article/10.1007/s11071-021-06404-4#ref-CR23)], vibro-impact [[24\]](file:///article/10.1007/s11071-021-06404-4#ref-CR24), internal resonance [[25\]](file:///article/10.1007/s11071-021-06404-4#ref-CR25) and hysteretic systems [[26](file:///article/10.1007/s11071-021-06404-4#ref-CR26)]. Gyroscopic effects are also addressed for continuous rotor systems [\[27](file:///article/10.1007/s11071-021-06404-4#ref-CR27)], and the nonlinear dynamics and stability of fiber reinforced polymer structures [\[28\]](file:///article/10.1007/s11071-021-06404-4#ref-CR28), and plates with nonlinear fractional damping [[29](file:///article/10.1007/s11071-021-06404-4#ref-CR29)], are also investigated. The

question of tailoring the nonlinear response of a mechanical system is also studied from a theoretical perspective [[30\]](file:///article/10.1007/s11071-021-06404-4#ref-CR30).

We thank all colleagues who enthusiastically contributed with their latest results. We also hope that our initiative is welcome and timely and that this Special Issue will stimulate new ideas and new challenges in the wide and fascinating research field of dynamics and stability of mechanical systems.

## **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Applied Dynamical Systems](file:///subjects/applied-dynamical-systems) •
- [Control and Systems Theory](file:///subjects/control-and-systems-theory) •
- [Dynamical Systems](file:///subjects/dynamical-systems) •
- [Mechatronics](file:///subjects/mechatronics) •
- [Multibody Systems and Mechanical Vibrations](file:///subjects/multibody-systems-and-mechanical-vibrations) •
- [Nonlinear Dynamics and Chaos Theory](file:///subjects/nonlinear-dynamics-and-chaos-theory) •

# **References**

<span id="page-3-0"></span>Lelkes, J., Kalmár-Nagy, T.: Analysis of a piecewise linear aeroelastic system with and without tuned vibration absorber. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-05725-0) [s11071-020-05725-0](https://doi.org/10.1007/s11071-020-05725-0) 1.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05725-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Analysis%20of%20a%20piecewise%20linear%20aeroelastic%20system%20with%20and%20without%20tuned%20vibration%20absorber&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05725-0&publication_year=2020&author=Lelkes%2CJ&author=Kalm%C3%A1r-Nagy%2CT)

<span id="page-3-1"></span>Freydin, M., Dowell, E.H., Spottswood, S.M., Perez, R.A.: Nonlinear dynamics and flutter of plate and cavity in response to supersonic wind tunnel start. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-05817-x> 2.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05817-x) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20dynamics%20and%20flutter%20of%20plate%20and%20cavity%20in%20response%20to%20supersonic%20wind%20tunnel%20start&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05817-x&publication_year=2020&author=Freydin%2CM&author=Dowell%2CEH&author=Spottswood%2CSM&author=Perez%2CRA)

Akhavan, H., Ribeiro, P.: Stability and bifurcations in oscillations of composite laminates with curvilinear fibres under a supersonic airflow. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-05838-6> 3.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05838-6) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Stability%20and%20bifurcations%20in%20oscillations%20of%20composite%20laminates%20with%20curvilinear%20fibres%20under%20a%20supersonic%20airflow&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05838-6&publication_year=2020&author=Akhavan%2CH&author=Ribeiro%2CP)

Qu, Y., Metrikine, A.V.: Modelling of coupled cross-flow and in-line vortex-induced vibrations of flexible cylindrical structures. Part I: model description and validation. Nonlinear Dyn. (2021).<https://doi.org/10.1007/s11071-020-06168-3> 4.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-06168-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Modelling%20of%20coupled%20cross-flow%20and%20in-line%20vortex-induced%20vibrations%20of%20flexible%20cylindrical%20structures.%20Part%20I%3A%20model%20description%20and%20validation&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06168-3&publication_year=2021&author=Qu%2CY&author=Metrikine%2CAV)

Qu, Y., Metrikine, A.V.: Modelling of coupled cross-flow and in-line vortex-induced vibrations of flexible cylindrical structures. Part II: on the importance of in-line coupling. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-06027-1> 5.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-06027-1) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Modelling%20of%20coupled%20cross-flow%20and%20in-line%20vortex-induced%20vibrations%20of%20flexible%20cylindrical%20structures.%20Part%20II%3A%20on%20the%20importance%20of%20in-line%20coupling&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06027-1&publication_year=2020&author=Qu%2CY&author=Metrikine%2CAV)

Han, P., Hémon, P., Pan, G., de Langre, E.: Nonlinear modeling of combined galloping and vortex-induced vibration of square sections under flow. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-06078-4> 6.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-06078-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20modeling%20of%20combined%20galloping%20and%20vortex-induced%20vibration%20of%20square%20sections%20under%20flow&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06078-4&publication_year=2020&author=Han%2CP&author=H%C3%A9mon%2CP&author=Pan%2CG&author=Langre%2CE)

Zulli, D., Piccardo, G., Luongo, A.: On the nonlinear effects of the mean wind force on the galloping onset in shallow cables. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-05886-y) [s11071-020-05886-y](https://doi.org/10.1007/s11071-020-05886-y) 7.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05886-y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20nonlinear%20effects%20of%20the%20mean%20wind%20force%20on%20the%20galloping%20onset%20in%20shallow%20cables&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05886-y&publication_year=2020&author=Zulli%2CD&author=Piccardo%2CG&author=Luongo%2CA)

D'Annibale, F., Ferretti, M.: On the effects of linear damping on the nonlinear Ziegler's column. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-05797-y> 8.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05797-y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20effects%20of%20linear%20damping%20on%20the%20nonlinear%20Ziegler%E2%80%99s%20column&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05797-y&publication_year=2020&author=D%E2%80%99Annibale%2CF&author=Ferretti%2CM)

Balakrishna, A., Webster, J.T.: Large deflections of a structurally damped panel in a subsonic flow. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-05805-1> 9.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05805-1) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Large%20deflections%20of%20a%20structurally%20damped%20panel%20in%20a%20subsonic%20flow&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05805-1&publication_year=2020&author=Balakrishna%2CA&author=Webster%2CJT)

Habib, G., Romeo, F.: Tracking modal interactions in nonlinear energy sink dynamics via high-dimensional invariant manifold. Nonlinear Dyn. (2020). [https://doi.org/](https://doi.org/10.1007/s11071-020-05937-4) [10.1007/s11071-020-05937-4](https://doi.org/10.1007/s11071-020-05937-4) 10.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05937-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Tracking%20modal%20interactions%20in%20nonlinear%20energy%20sink%20dynamics%20via%20high-dimensional%20invariant%20manifold&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05937-4&publication_year=2020&author=Habib%2CG&author=Romeo%2CF)

Yang, C., Xia, J., Park, J.H., Shen, H., Wang, J.: Sliding mode control for uncertain active vehicle suspension systems: an event-triggered control scheme. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05742-z> 11.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05742-z) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sliding%20mode%20control%20for%20uncertain%20active%20vehicle%20suspension%20systems%3A%20an%20event-triggered%20control%20scheme&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05742-z&publication_year=2020&author=Yang%2CC&author=Xia%2CJ&author=Park%2CJH&author=Shen%2CH&author=Wang%2CJ)

Alyukov, A., Leamy, M.J.: Two-scale command shaping for arresting motion in nonlinear systems. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-05923-w) [s11071-020-05923-w](https://doi.org/10.1007/s11071-020-05923-w) 12.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05923-w) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Two-scale%20command%20shaping%20for%20arresting%20motion%20in%20nonlinear%20systems&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05923-w&publication_year=2020&author=Alyukov%2CA&author=Leamy%2CMJ)

Wang, Z., Liang, S., Molnar, C.A., Insperger, T., Stepan, G.: Parametric continuation algorithm for time-delay systems and bifurcation caused by multiple characteristic roots. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05799-w> 13.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05799-w) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Parametric%20continuation%20algorithm%20for%20time-delay%20systems%20and%20bifurcation%20caused%20by%20multiple%20characteristic%20roots&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05799-w&publication_year=2020&author=Wang%2CZ&author=Liang%2CS&author=Molnar%2CCA&author=Insperger%2CT&author=Stepan%2CG)

Warminski, J., Kloda, L., Latalski, J., Mitura, A., Kowalczuk, M.: Nonlinear vibrations and time delay control of an extensible slowly rotating beam. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-06079-3> 14.

[Article](https://link.springer.com/doi/10.1007/s11071-020-06079-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20vibrations%20and%20time%20delay%20control%20of%20an%20extensible%20slowly%20rotating%20beam&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06079-3&publication_year=2020&author=Warminski%2CJ&author=Kloda%2CL&author=Latalski%2CJ&author=Mitura%2CA&author=Kowalczuk%2CM)

Yuan, J., Schwingshackl, C., Wong, C., Salles, L.: On an improved adaptive reducedorder model for the computation of steady-state vibrations in large-scale nonconservative systems with friction joints. Nonlinear Dyn. (2020). [https://doi.org/](https://doi.org/10.1007/s11071-020-05890-2) [10.1007/s11071-020-05890-2](https://doi.org/10.1007/s11071-020-05890-2) 15.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05890-2) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20an%20improved%20adaptive%20reduced-order%20model%20for%20the%20computation%20of%20steady-state%20vibrations%20in%20large-scale%20non-conservative%20systems%20with%20friction%20joints&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05890-2&publication_year=2020&author=Yuan%2CJ&author=Schwingshackl%2CC&author=Wong%2CC&author=Salles%2CL)

Brunetti, J., D'Ambrogio, W., Fregolent, A.: Friction-induced vibrations in the framework of dynamic substructuring. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-06081-9) [s11071-020-06081-9](https://doi.org/10.1007/s11071-020-06081-9) 16.

[Article](https://link.springer.com/doi/10.1007/s11071-020-06081-9) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Friction-induced%20vibrations%20in%20the%20framework%20of%20dynamic%20substructuring&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06081-9&publication_year=2020&author=Brunetti%2CJ&author=D%E2%80%99Ambrogio%2CW&author=Fregolent%2CA)

Sun, Y., Vizzaccaro, A., Yuan, J., Salles, L.: An extended energy balance method for resonance prediction in forced response of systems with non-conservative nonlinearities using damped nonlinear normal mode. Nonlinear Dyn. (2020). [https://](https://doi.org/10.1007/s11071-020-05793-2) [doi.org/10.1007/s11071-020-05793-2](https://doi.org/10.1007/s11071-020-05793-2) 17.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05793-2) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20extended%20energy%20balance%20method%20for%20resonance%20prediction%20in%20forced%20response%20of%20systems%20with%20non-conservative%20nonlinearities%20using%20damped%20nonlinear%20normal%20mode&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05793-2&publication_year=2020&author=Sun%2CY&author=Vizzaccaro%2CA&author=Yuan%2CJ&author=Salles%2CL)

Vizzaccaro, A., Salles, L., Touzé, C.: Comparison of nonlinear mappings for reducedorder modelling of vibrating structures: normal form theory and quadratic manifold method with modal derivatives. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-05813-1) [s11071-020-05813-1](https://doi.org/10.1007/s11071-020-05813-1) 18.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05813-1) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Comparison%20of%20nonlinear%20mappings%20for%20reduced-order%20modelling%20of%20vibrating%20structures%3A%20normal%20form%20theory%20and%20quadratic%20manifold%20method%20with%20modal%20derivatives&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05813-1&publication_year=2020&author=Vizzaccaro%2CA&author=Salles%2CL&author=Touz%C3%A9%2CC)

Hollander, E., Gottlieb, O.: Global bifurcations and homoclinic chaos in nonlinear panel optomechanical resonators under combined thermal and radiation stresses. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05977-w> 19.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05977-w) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Global%20bifurcations%20and%20homoclinic%20chaos%20in%20nonlinear%20panel%20optomechanical%20resonators%20under%20combined%20thermal%20and%20radiation%20stresses&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05977-w&publication_year=2020&author=Hollander%2CE&author=Gottlieb%2CO)

Mikhlin, Y.V., Rudnyeva, G.V.: Stability of similar nonlinear normal modes under random excitation. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-06093-5) [s11071-020-06093-5](https://doi.org/10.1007/s11071-020-06093-5) 20.

[Article](https://link.springer.com/doi/10.1007/s11071-020-06093-5) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Stability%20of%20similar%20nonlinear%20normal%20modes%20under%20random%20excitation&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06093-5&publication_year=2020&author=Mikhlin%2CYV&author=Rudnyeva%2CGV)

Fontanela, F., Vizzaccaro, A., Auvray, J., Niedergesäß, B., Grolet, A., Salles, L., Hoffmann, N.: Nonlinear vibration localisation in a symmetric system of two coupled beams. Nonlinear Dyn. (2020). <https://doi.org/10.1007/s11071-020-05760-x> 21.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05760-x) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20vibration%20localisation%20in%20a%20symmetric%20system%20of%20two%20coupled%20beams&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05760-x&publication_year=2020&author=Fontanela%2CF&author=Vizzaccaro%2CA&author=Auvray%2CJ&author=Niederges%C3%A4%C3%9F%2CB&author=Grolet%2CA&author=Salles%2CL&author=Hoffmann%2CN)

Urasaki, S., Yabuno, H.: Identification method for backbone curve of cantilever beam using van der Pol-type self-excited oscillation. Nonlinear Dyn. (2020). [https://doi.org/](https://doi.org/10.1007/s11071-020-05945-4) [10.1007/s11071-020-05945-4](https://doi.org/10.1007/s11071-020-05945-4) 22.

[Article](https://link.springer.com/doi/10.1007/s11071-020-05945-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Identification%20method%20for%20backbone%20curve%20of%20cantilever%20beam%20using%20van%20der%20Pol-type%20self-excited%20oscillation&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05945-4&publication_year=2020&author=Urasaki%2CS&author=Yabuno%2CH)

Mojahed, A., Liu, Y., Bergman, L.A., Vakakis, A.F.: Modal energy exchanges in an impulsively loaded beam with a geometrically nonlinear boundary condition: computation and experiment. Nonlinear Dyn. (2021). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-06156-7) [s11071-020-06156-7](https://doi.org/10.1007/s11071-020-06156-7) 23.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-06156-7) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Modal%20energy%20exchanges%20in%20an%20impulsively%20loaded%20beam%20with%20a%20geometrically%20nonlinear%20boundary%20condition%3A%20computation%20and%20experiment&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06156-7&publication_year=2021&author=Mojahed%2CA&author=Liu%2CY&author=Bergman%2CLA&author=Vakakis%2CAF)

Stefani, G., De Angelis, M., Andreaus, U.: Scenarios in the experimental response of a vibro-impact single-degree-of-freedom system and numerical simulations. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05791-4> 24.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05791-4) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Scenarios%20in%20the%20experimental%20response%20of%20a%20vibro-impact%20single-degree-of-freedom%20system%20and%20numerical%20simulations&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05791-4&publication_year=2020&author=Stefani%2CG&author=Angelis%2CM&author=Andreaus%2CU)

Lenci, S., Clementi, F., Kloda, L., Warminski, J., Rega, G.: Longitudinal–transversal internal resonances in Timoshenko beams with an axial elastic boundary condition. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05912-z> 25.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05912-z) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Longitudinal%E2%80%93transversal%20internal%20resonances%20in%20Timoshenko%20beams%20with%20an%20axial%20elastic%20boundary%20condition&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05912-z&publication_year=2020&author=Lenci%2CS&author=Clementi%2CF&author=Kloda%2CL&author=Warminski%2CJ&author=Rega%2CG)

- Formica, G., Vaiana, N., Rosati, L., Lacarbonara, W.: Path following of highdimensional hysteretic systems under periodic forcing. Nonlinear Dyn. (2020). [https://](https://doi.org/10.1007/s11071-021-06374-7) [doi.org/10.1007/s11071-021-06374-7](https://doi.org/10.1007/s11071-021-06374-7) 26.
- De Felice, A., Sorrentino, S.: Damping and gyroscopic effects on the stability of parametrically excited continuous rotor systems. Nonlinear Dyn. (2021). [https://](https://doi.org/10.1007/s11071-020-06106-3) [doi.org/10.1007/s11071-020-06106-3](https://doi.org/10.1007/s11071-020-06106-3) 27.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-06106-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Damping%20and%20gyroscopic%20effects%20on%20the%20stability%20of%20parametrically%20excited%20continuous%20rotor%20systems&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06106-3&publication_year=2021&author=Felice%2CA&author=Sorrentino%2CS)

Coaquira, J.C., Cardoso, D.C.T., Gonçalves, P.B., Orlando, D.: Parametric instability and nonlinear oscillations of an FRP channel section column under axial load. Nonlinear Dyn. (2020).<https://doi.org/10.1007/s11071-020-05663-x> 28.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05663-x) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Parametric%20instability%20and%20nonlinear%20oscillations%20of%20an%20FRP%20channel%20section%20column%20under%20axial%20load&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05663-x&publication_year=2020&author=Coaquira%2CJC&author=Cardoso%2CDCT&author=Gon%C3%A7alves%2CPB&author=Orlando%2CD)

Amabili, M., Balasubramanian, P., Ferrari, G.: Nonlinear vibrations and damping of fractional viscoelastic rectangular plates. Nonlinear Dyn. (2020). [https://doi.org/](https://doi.org/10.1007/s11071-020-05892-0) [10.1007/s11071-020-05892-0](https://doi.org/10.1007/s11071-020-05892-0) 29.

## [Article](https://link.springer.com/doi/10.1007/s11071-020-05892-0) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonlinear%20vibrations%20and%20damping%20of%20fractional%20viscoelastic%20rectangular%20plates&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-05892-0&publication_year=2020&author=Amabili%2CM&author=Balasubramanian%2CP&author=Ferrari%2CG)

Detroux, T., Noël, J.P., Kerschen, G.: Tailoring the resonances of nonlinear mechanical systems. Nonlinear Dyn. (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-06002-w) [s11071-020-06002-w](https://doi.org/10.1007/s11071-020-06002-w) 30.

[Article](https://link.springer.com/doi/10.1007/s11071-020-06002-w) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Tailoring%20the%20resonances%20of%20nonlinear%20mechanical%20systems&journal=Nonlinear%20Dyn.&doi=10.1007%2Fs11071-020-06002-w&publication_year=2020&author=Detroux%2CT&author=No%C3%ABl%2CJP&author=Kerschen%2CG)

## [Download references](https://citation-needed.springer.com/v2/references/10.1007/s11071-021-06404-4?format=refman&flavour=references)

# **Author information**

## **Authors and Affiliations**

<span id="page-8-0"></span>Dept. of Civil, Construction-Architectural and Environmental Engineering (DICEAA), M&MoCS, University of L'Aquila, L'Aquila, Italy 1.

Angelo Luongo

<span id="page-8-1"></span>School of Mechanical Engineering, Georgia Tech, Atlanta, USA 2.

Michael J. Leamy

<span id="page-8-2"></span>Department of Civil and Building Engineering, and Architecture, Università Politecnica delle Marche, Ancona, Italy 3.

Stefano Lenci

<span id="page-8-3"></span>Dept. of Civil, Chemical and Environmental Engineering (DICCA), University of Genoa, Genoa, Italy 4.

Giuseppe Piccardo

<span id="page-8-4"></span>Institute of Mechanical Sciences and Industrial Applications (IMSIA), ENSTA Paris, CNRS, EDF, CEA, Institut Polytechnique de Paris, Palaiseau, France 5.

Cyril Touzé

## Authors

#### <span id="page-9-0"></span>Angelo Luongo 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Angelo%20Luongo)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Angelo%20Luongo) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Angelo%20Luongo%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-9-1"></span>Michael J. Leamy 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Michael%20J.%20Leamy)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Michael%20J.%20Leamy) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Michael%20J.%20Leamy%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-9-2"></span>Stefano Lenci 3.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Stefano%20Lenci)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Stefano%20Lenci) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Stefano%20Lenci%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-9-3"></span>Giuseppe Piccardo 4.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Giuseppe%20Piccardo)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Giuseppe%20Piccardo) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Giuseppe%20Piccardo%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-9-4"></span>Cyril Touzé 5.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Cyril%20Touz%C3%A9)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Cyril%20Touz%C3%A9) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Cyril%20Touz%C3%A9%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

## **Corresponding author**

Correspondence to [Angelo Luongo.](mailto:angelo.luongo@univaq.it)

# **Additional information**

## **Publisher's Note**

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Advances%20in%20stability%2C%20bifurcations%20and%20nonlinear%20vibrations%20in%20mechanical%20systems&author=Angelo%20Luongo%20et%20al&contentID=10.1007%2Fs11071-021-06404-4©right=The%20Author%28s%29%2C%20under%20exclusive%20licence%20to%20Springer%20Nature%20B.V.&publication=0924-090X&publicationDate=2021-03-29&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

![](_page_10_Picture_3.jpeg)

## <span id="page-10-0"></span>**Cite this article**

Luongo, A., Leamy, M.J., Lenci, S. *et al.* Advances in stability, bifurcations and nonlinear vibrations in mechanical systems. *Nonlinear Dyn* **103**, 2993–2995 (2021). https://doi.org/ 10.1007/s11071-021-06404-4

## [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s11071-021-06404-4?format=refman&flavour=citation)

Accepted: 22 March 2021 •

Published: 29 March 2021 •

Issue date: March 2021 •

DOI: https://doi.org/10.1007/s11071-021-06404-4 •

[Use our pre-submission checklist](https://beta.springernature.com/pre-submission?journalId=11071)

Avoid common mistakes on your manuscript.

# **Associated Content**

Part of a collection:

# **[Special Issue: Advances in stability, bifurcations and nonlinear](file:///collections/dfibbbiaif) [vibrations in mechanical systems](file:///collections/dfibbbiaif)**

Advertisement

<span id="page-11-1"></span>

| Search by keyword or author |  |
|-----------------------------|--|
|                             |  |
|                             |  |
|                             |  |

Search

# <span id="page-11-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

## **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

## **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

## **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •

- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

## **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature