#### ORIGINAL PAPER

![](_page_0_Picture_2.jpeg)

# Wave propagation in fractionally damped nonlinear phononic crystals

Soroush Sepehri · Mahmoud Mosavi Mashhadi · Mir Masoud Seyyed Fakhrabadi D

Received: 22 February 2022/Accepted: 6 July 2022/Published online: 22 July 2022 © The Author(s), under exclusive licence to Springer Nature B.V. 2022

Abstract Studying wave propagation in phononic crystals (PCs) in the presence of energy dissipation is a crucial step toward the precise dynamic modeling of periodic structures. Fractional calculus is an appropriate tool to reach a more perceptive idea of energy dissipation compared to other damping models. Therefore, in this work, we aim to provide a semianalytical model for wave propagation in fractionally damped nonlinear PCs. For this purpose, the method of multiple scales is used to solve the governing equations of PCs, and the nonlinear dispersion relations of fractionally damped monoatomic chains and lattices are obtained. The Caputo definition of fractional derivatives is used to model damping. Besides providing new insight into the energy dissipation in PCs, the results of this research emphasize the importance of considering nonlinearities in modeling periodic materials, especially because the propagation frequency in nonlinear crystals is amplitude-dependent. The obtained results are validated with numerical modeling of fractionally damped PCs.

**Keywords** Fractional damping · Nonlinear phononic crystal · Wave propagation · Acoustic metamaterial · Method of multiple scales

S. Sepehri · M. M. Mashhadi · M. M. S. Fakhrabadi (🖂) School of Mechanical Engineering, College of Engineering, University of Tehran, Tehran, Iran e-mail: mfakhrabadi@ut.ac.ir

#### 1 Introduction

Many research studies have recently been devoted to studying phononic crystals (PCs), due to their phenomenal characteristics such as their ability to manipulate waves [1]. PCs can mitigate or stop the propagation of waves in certain frequency ranges known as stop-bands, while the propagation can occur freely in other frequencies. More interestingly, the frequency range of stop-bands can be tuned based on geometrical, material, or mechanical specifications of the structure [2–4]. Hence, PCs can be used as wave filters [5, 6], waveguides [7, 8], switches [9, 10], sensors [11], acoustic cloaks [12, 13], diodes [14], etc.

Additionally, nonlinear phenomena such as amplitude-induced stop-bands [15, 16], modal interaction [17], subharmonic wave attenuation [18], and internal resonance [19] further enriched the engineering significance of PCs and their applications [20]. In the previous years, valuable contributions were made to study wave propagation in nonlinear PCs and investigate different aspects of phononic behavior in nonlinear chains. The pioneering work of Vakakis and King [21] in finding the nonlinear attenuation zones in infinitely continuous elastic layers with material nonlinearities opened a door for researchers to focus their attention on the extraordinary effect of nonlinearity in wave-filtering capabilities of such structures. This path was later continued by performing a semi-analytical study of wave propagation in

![](_page_0_Picture_12.jpeg)

weakly nonlinear periodic structures using perturbation techniques [\[22](#page-23-0)], investigating the wave–wave interactions in chains with cubic nonlinearity [[23\]](#page-23-0), and spectro-spatial analysis of wave propagation in nonlinear PCs [[24\]](#page-23-0). Additionally, exploration of more sophisticated phenomena such as internal resonance in weakly nonlinear lattices [\[19](#page-23-0)] and non-reciprocity in nonlinear chains [\[25](#page-23-0)] are other examples.

Due to the recent advancements in manufacturing techniques and measurement technologies, the application of 2D nonlinear PCs has also raised significantly [[26,](#page-23-0) [27\]](#page-23-0). Thus, the necessity of investigating the mechanical behavior of 2D nonlinear lattices has led to many valuable experimental efforts to understand their mechanical behavior and study the phenomenal effects of nonlinearity on their characteristics [\[28](#page-23-0)]. Correspondingly, modeling 2D nonlinear PCs has also faced growing interest among the community. Hence, various methods were developed in the previous years to model 2D nonlinear lattices and study different aspects of their behavior [\[29](#page-23-0), [30](#page-23-0)]. As an example, the semi-analytical approaches to study wave propagation in nonlinear PCs were successfully expanded to 2D lattices of different materials and geometrical specifications [\[31](#page-23-0)]. In addition, wave propagation in 2D nonlinear lattices with bistable elements [\[32](#page-23-0)], investigation on the solitary waves in 2D nonlinear lattices [\[33](#page-23-0)], wave interactions in nonlinear lattices with two degrees of freedom [\[34](#page-24-0)], and wave propagation in 2D nonlocal nonlinear lattices [\[35](#page-24-0)] are among the recent achievements in exploring the nonlinearity-induced phenomena in 2D lattices.

While the periodic materials and their wavepropagation behavior have been widely studied [\[36–39](#page-24-0)], there are still some inadequately investigated subjects to fully characterize the dynamic behavior of PCs. One of them is the energy dissipation and damping effects on the behavior of PCs. Despite the efforts of the community to reduce the energy dissipation in phononic structures, there is still a long way toward reaching ideal systems, in which, no considerable energy is dissipated. Hence, it is necessary to carefully investigate the damped periodic structures and investigate their damping-induced characteristics. In previous years, studies have been done to investigate the wave propagation in PCs with energy dissipation. Examples include the comprehensive demonstration of damping effect in various types of PCs [\[40](#page-24-0)], analytical, numerical, and experimental analysis of wave propagation in dissipative diatomic lattices [[41\]](#page-24-0), a more application-centered study of damping effects in microtubule-based nano-metamaterials [[42\]](#page-24-0), as well as measuring the energy absorption capacity of dissipative multi-resonators PCs [\[43](#page-24-0)]. However, these studies were mainly focused on linear PCs neglecting the nonlinearities. Over the years, investigations on the dissipative nonlinear PCs also emerged to broaden our vision of the different aspects and potentials of such structures. These studies led to a more perceptive understanding of the characteristics of damped PCs. For example, successful generation of broader stop-bands in nonlinear triatomic chains in the presence of damping [\[44](#page-24-0)], as well as obtaining perturbation-based nonlinear dispersion solutions for linearly damped 1D [\[45](#page-24-0), [46\]](#page-24-0) and 2D chains [\[47](#page-24-0)], and studying the wave propagation characteristics of damped nonlinear lattices made of rubber [\[48](#page-24-0)] are among the most noticeable achievements in this field. However, all of the aforementioned efforts dealt with the simplest type of energy dissipation models, namely viscous damping. Nonetheless, based on the different conditions and characteristics of real-life physical problems, various concepts and formulations for other types of energy dissipation in mechanical and structural engineering were developed over the years. Fractional damping is one of the more general types of energy dissipation models which is the main focus of the current work [[49\]](#page-24-0).

Generally considered more thorough than many well-established damping mechanisms, fractional models can facilitate the representation of dynamic systems with complex energy dissipation mechanisms, which will otherwise require tedious formulations. Fractional derivative models are best suited for modeling the dynamic behavior of some polymeric materials [[50\]](#page-24-0) with viscoelastic material properties [\[51](#page-24-0)]; More specifically, while the application of viscous [\[52](#page-24-0), [53\]](#page-24-0), quadratic [[54\]](#page-24-0), or cubic [[55](#page-24-0)] damping cannot affect the stiffness of a dynamic structure, there is a relation between the parameters of the fractional damper and the stiffness of the system [[49\]](#page-24-0). Furthermore, the fractional-order models of viscoelasticity are consistent with the thermodynamical constraints of viscoelastic media [[56\]](#page-24-0) and their foundation lies in the accepted molecular theories governing the macromechanical behavior of viscoelastic materials [[50\]](#page-24-0). The variation of stiffness in time for a fractionally damped system can also lead to more unique phenomena such

![](_page_1_Picture_6.jpeg)

as the appearance of non-oscillatory terms decaying in time [\[57\]](#page-24-0). Another advantage of fractional derivative models for damping is their ability to model damping in systems whose response crosses the equilibrium at least once. This is due to the nature of the poles in fractionally damped systems [\[58](#page-24-0), [59](#page-24-0)]. A three-parameter fractional derivative model was used to validate the experimental results of the transient response of a viscoelastic single-degree-of-freedom system to an impulse, where it showed a closer agreement with the experiment than the Voigt model [[60\]](#page-24-0). Other applications of fractional damping in analyzing the dynamic behavior of mechanical systems include some other systems with frequency-dependent behavior, such as some phenomena in Newtonian fluids. In fact, the stress-velocity relation of the motion of a half-space Newtonian fluid induced by the motion of a plate was shown to follow the exact fractional derivative expression with the order of 1/2 [\[60\]](#page-24-0). In addition, the fractional derivatives appear in the equation of motion of a rigid plate immersed in a Newtonian fluid and connected to a fixed end [[60\]](#page-24-0). Furthermore, the relation between the current and the voltage in a semi-infinite lossy transmission line [[61\]](#page-24-0) is another instance, in which inherent fractional-order behavior is observed. Moreover, fractional-order models are proved to be ideal candidates for predicting the behavior of biomimetic materials and systems [\[62](#page-24-0)]. More applications of fractional derivatives in dynamic systems include the linear and nonlinear investigation of the vibration of fractionally damped duffing oscillators [[63–](#page-24-0)[65\]](#page-25-0), van der Pol oscillators [[66\]](#page-25-0), Helmholtz oscillators [\[67](#page-25-0)], chaotic vibration of fractionally damped duffing oscillators [\[68](#page-25-0)], and dynamic response of fractionally damped active suspension control [[69\]](#page-25-0). Furthermore, control methods based on fractional-order controllers have gained widespread popularity in recent years [[70–73\]](#page-25-0). Their results revealed that fractional-order controllers can outperform integer-order controllers, especially when the dynamic system has a distributed-parameter nature [\[71](#page-25-0)].

However, fractional damping has received drastically less attention in the field of phononic materials. A numerical solution for the wave propagation in 2D viscoelastic PCs based on fractional derivatives [[74\]](#page-25-0) as well as a fractional calculus approach to study damping in acoustic metamaterials and PCs [\[75](#page-25-0)] are a few existing research studies in the field. To the best of our knowledge, no previous effort has been made to apply the fractional damping models in predicting the dissipative behavior of nonlinear PCs.

Therefore, in this work, nonlinear fractionally damped monoatomic PCs are modeled analytically, and their wave-propagation behaviors are studied. The nonlinearity is assumed to be of the cubic type, and the Caputo assumption [[76\]](#page-25-0) is considered for the fractional damping. The equation of motion of the chain is solved by implementing the multiple scales method, and the nonlinear dispersion curves and time histories are obtained to investigate the effects of fractional damping. After establishing the fundamental concepts of modeling wave propagation in fractionally damped 1D PCs, the mathematical model is expanded to nonlinear 2D lattices and the effects of nonlinearity and fractional damping on the nonlinear dispersion curve of a monoatomic lattice of square topology are studied in detail. The outcomes can broaden our vision of energy dissipation in nonlinear PCs and present a more comprehensive analysis of wave propagation in dissipative periodic lattices.

#### 2 Formulation

#### 2.1 One-dimensional fractionally damped nonlinear chains

Consider the nonlinear phononic chain shown in Fig. [1.](#page-3-0) The chain consists of an infinite number of masses m connected together by nonlinear springs with linear coefficient k and cubic coefficient a~. Hence, the force–displacement (f u) relationship of the springs can be described by f ¼ ku þ ea~u3, where e is a small bookkeeping parameter [\[77](#page-25-0)]. Additionally, there exists a fractional damper with a damping coefficient cf between each pair of adjacent masses. The displacement corresponding to the nth mass is designated by un, whereas un<sup>1</sup> denotes the displacement of the (n - 1)th mass and unþ<sup>1</sup> designates the displacement of the (n ? 1)th mass. Also, the red dashed box in Fig. [1](#page-3-0) represents the unit cell. The proposed model is the simplest form of discretization for more complex continuum PCs. It can efficiently model weakly nonlinear 1D chains made of an infinite number of identical unit cells which are made of polymers and possess weak viscoelastic properties.

![](_page_2_Picture_9.jpeg)

<span id="page-3-0"></span>![](_page_3_Figure_1.jpeg)

Fig. 1 The schematic view of a one-dimensional fractionally damped weakly nonlinear monoatomic chain

The so-called monoatomic 1D spring-mass model was previously used to model PCs in some experimental studies [78].

For the described chain, the governing equation of motion of the *n*th unit cell can be written as:

$$m\ddot{u}_{n} + k(2u_{n} - u_{n-1} - u_{n+1}) + \varepsilon\tilde{\alpha}(u_{n} - u_{n-1})^{3} + \varepsilon\tilde{\alpha}(u_{n} - u_{n+1})^{3} + \varepsilon c_{f} D_{t}^{\gamma}(2u_{n} - u_{n-1} - u_{n+1}) = 0,$$
(1)

where  $\ddot{u}_n$  is the acceleration of the *n*th mass.

For the investigation of the fractional derivatives in a dynamic system, two different forms are usually considered: Riemann-Liouville [79, 80] and Caputo forms [51, 81]. While the Riemann–Liouville form has applications in pure mathematics, the Caputo form is usually utilized in engineering applications. The reason is that the Caputo form has a more tangible physical interpretation. The Riemann-Liouville approach leads to the appearance of initial values in the form of lower-order fractional derivatives. Although using these initial conditions can lead to solving the problem, they have much more complex physical interpretations than the Caputo form [82]. However, the initial conditions for solving the differential equations of the Caputo form are similar to that of a conventional nth-order function, for which there exists a physical interpretation [83, 84]. Based on the above discussion, we use the Caputo form of fractional derivatives in this work. Consequently,  $D_t^{\gamma}$  denotes the fractional derivative in the Caputo form, which is defined by [85]:

$$D_t^{\gamma}(u(t)) = \frac{1}{\Gamma(1-\gamma)} \int_0^t \frac{\dot{u}(s)}{(t-s)^{\gamma}} \mathrm{d}s, \tag{2}$$

![](_page_3_Picture_9.jpeg)

Using the following normalized parameters  $\omega_{\text{nat}} = \sqrt{\frac{k}{m}}$  and  $\tau = \omega_{\text{nat}}t$ , the normalized form of the governing equation of motion (1) becomes:

$$u_n'' + (2u_n - u_{n-1} - u_{n+1}) + \varepsilon \alpha (u_n - u_{n-1})^3 + \varepsilon \alpha (u_n - u_{n+1})^3 + \varepsilon \mu D_{\tau}^{\gamma} (2u_n - u_{n-1} - u_{n+1}) = 0,$$
(3)

where  $\alpha = \frac{\tilde{\alpha}}{k}$ ,  $\mu = \frac{c_f}{m\omega_{\text{nat}}^{2-\gamma}}$ . Note that ' denotes the derivative with respect to  $\tau$ . To obtain  $\mu$ , it is noted that the non-normalized and normalized forms of the fractional damping, i. e.,  $D_t^{\gamma}(u(t))$  and  $D_{\tau}^{\gamma}(u(\tau))$ , are related together by Eq. (4) [86]:

$$D_{t}^{\gamma}(u(t)) = \frac{1}{\Gamma(1-\gamma)} \int_{0}^{\tau/\omega_{\text{nat}}} \left(\frac{\tau}{\omega} - s\right)^{-\gamma} \dot{u}(s) ds$$
$$= \omega_{\text{nat}}^{\gamma} D_{\tau}^{\gamma}(u(\tau)). \tag{4}$$

The following asymptotic expansion for the solution of the governing Eq. (3) can be described as:

$$u_n(\tau, \varepsilon) = u_n^{(0)}(T_0, T_1) + \varepsilon u_n^{(1)}(T_0, T_1)$$
 (5)

where  $T_n = \varepsilon^n \tau$  are the independent time scales. Hence, the following relations can be obtained for the time derivatives in Eq. (3) [85]:

$$()'' = D_0^2 + 2\varepsilon D_0 D_1,$$
  

$$D_{\tau}^{\gamma} = (D_0 + \varepsilon D_1)^{\gamma} = D_C^{\gamma} + \varepsilon \gamma D_C^{\gamma - 1} D_1,$$
(6)

where  $D_0$  denotes the derivative with respect to  $T_0$  (fast time scale) and  $D_1$  is the derivative with respect

![](_page_3_Picture_19.jpeg)

<span id="page-4-0"></span>to  $T_1$  (slow time scale). Also,  $D_C^{\gamma}$  and  $D_C^{\gamma-1}$  are the Caputo fractional derivatives in time  $\tau$ .

Substituting the displacement  $u_n$  from Eq. (5) in governing Eq. (3), and defining the derivatives from Eq. (6), the first two orders of perturbation terms are described as:

$$\varepsilon^{(0)}: D_0^2 u_n^{(0)} + 2 u_n^{(0)} - u_{n-1}^{(0)} - u_{n+1}^{(0)} = 0, \tag{7}$$

$$\begin{split} \varepsilon^{(1)} &: D_0^2 u_n^{(1)} + 2 u_n^{(1)} - u_{n-1}^{(1)} - u_{n+1}^{(1)} \\ &= -2 D_0 D_1 u_n^{(0)} - \alpha \left( u_n^{(0)} - u_{n-1}^{(0)} \right)^3 - \alpha \left( u_n^{(0)} - u_{n+1}^{(0)} \right)^3 \\ &- \mu D_C^{\gamma} \left( 2 u_n^{(0)} - u_{n-1}^{(0)} - u_{n+1}^{(0)} \right). \end{split} \tag{8}$$

The  $\varepsilon^{(0)}$ -order term in Eq. (7) is an ordinary differential equation with the following solution:

$$u_n^{(0)}(T_0, T_1) = \frac{1}{2} A(T_1) e^{i\omega_0 T_0} e^{i\kappa^* n} + \frac{1}{2} \overline{A}(T_1) e^{-i\omega_0 T_0} e^{-i\kappa^* n},$$
(9)

where  $A(T_1)$  is the time-dependent amplitude and  $\overline{A}(T_1)$  is its complex conjugate. Also,  $\kappa^*$  designates the normalized wavenumber, which is defined as  $\kappa^* = \kappa d$ , where  $\kappa$  and d are the wavenumber and lattice spacing, respectively.

Substituting  $u_n^{(0)}$  from Eq. (9) in the zeroth-order governing equation (Eq. 7), the following relation is obtained for the linear dispersion frequency:

$$\omega_0 = \sqrt{2(1 - \cos \kappa^*)}.\tag{10}$$

According to the previous calculations by Rossikhin and Shitikova [85], the Caputo derivative can be expressed as:

$$D_C^{\gamma} e^{\mathrm{i}\omega_0 t} = (\mathrm{i}\omega_0)^{\gamma} e^{\mathrm{i}\omega_0 t} + \mathrm{i}\omega_0 \sin\frac{\pi\gamma}{\pi} \int_0^{\infty} \frac{p^{\gamma - 1}}{p + \mathrm{i}\omega_0} e^{-pt} \mathrm{d}p$$
(11)

Thus, by substituting  $u_n^{(0)}$  and  $D_C^{\gamma}$  from Eq. (9) and Eq. (11) in the  $\varepsilon^{(1)}$ -order governing equation (Eq. 8), it can be expressed in the following form:

$$\begin{split} \varepsilon^{1} &: D_{0}^{2} u_{n}^{(1)} + 2 u_{n}^{(1)} - u_{n-1}^{(1)} - u_{n+1}^{(1)} \\ &= e^{\mathrm{i}\omega_{0}T_{0}} e^{\mathrm{i}\kappa^{*}n} [-\mathrm{i}\omega_{0}D_{1}A - \mu A(\mathrm{i}\omega_{0})^{\gamma} (1 - \cos\kappa^{*}) \\ &- \frac{3}{8} \alpha A^{2} \overline{A} \big( 6 - 4 e^{\mathrm{i}\kappa^{*}} - 4 e^{-\mathrm{i}\kappa^{*}} + e^{-2\mathrm{i}\kappa^{*}} + e^{2\mathrm{i}\kappa^{*}} \big) \Big] \\ &- e^{3\mathrm{i}\omega_{0}T_{0}} e^{3\mathrm{i}\kappa^{*}n} \Big[ \frac{A^{3}}{8} \big( 1 - 3 e^{-\mathrm{i}\kappa^{*}} + 3 e^{-2\mathrm{i}\kappa^{*}} - e^{-3\mathrm{i}\kappa^{*}} \big) \Big] \\ &- 2\mu A\mathrm{i}\omega_{0} (1 - \cos\kappa^{*}) \sin\frac{\pi\gamma}{\pi} \int_{0}^{\infty} \frac{p^{\gamma-1}}{p + \mathrm{i}\omega_{0}} e^{-pT_{0}} \mathrm{d}p + c.c. \end{split}$$

The solvability condition for Eq. (12) requires that the coefficients of  $e^{i\omega_0 T_0}e^{i\kappa^*n}$  are omitted. Otherwise, the solution would become unbounded as time increases. To remove the secular terms, Eq. (13) is reached:

$$i\omega_0 D_1 A + \mu A (i\omega_0)^{\gamma} (1 - \cos \kappa^*) + \frac{3}{8} \alpha A^2 \overline{A} \omega_0^4 = 0.$$

$$(13)$$

One should note that the last term in Eq. (12) does not contribute to the secular terms and therefore, cannot affect the solvability condition. Previous studies revealed that this integral term results in the part of the solution which determines the drift of the equilibrium position of the mass [63]. It is neglected here because this integral term decays much more rapidly in time [87, 88].

To solve Eq. (13), the polar form in Eq. (14) can is used for  $A(T_1)$ :

$$A(T_1) = a(T_1)e^{i\beta(T_1)}. (14)$$

Also, it should be noted that:

$$i^{\gamma} = \cos\left(\frac{\gamma\pi}{2}\right) + i\sin\left(\frac{\gamma\pi}{2}\right). \tag{15}$$

Substituting the trigonometric form of  $i^{\gamma}$  from Eq. (15) and the amplitude A from Eq. (14) in Eq. (13), and separating the real parts from the imaginary parts, Eqs. (15) and (16) are reached:

$$\frac{\mathrm{d}a}{\mathrm{d}T_1} = -\mathcal{H}_1 a,\tag{16}$$

$$\frac{\mathrm{d}\beta}{\mathrm{d}T_1} = \frac{3}{8}\alpha a^2 \omega_0^3 + \mathcal{H}_2,\tag{17}$$

where

![](_page_4_Picture_26.jpeg)

<span id="page-5-0"></span>![](_page_5_Picture_1.jpeg)

Fig. 2 The schematic illustration of a two-dimensional fractionally damped weakly nonlinear monoatomic lattice

$$\mathcal{H}_1 = \mu \omega_0^{\gamma - 1} \sin\left(\frac{\gamma \pi}{2}\right) (1 - \cos \kappa^*), \tag{18}$$

$$\mathcal{H}_2 = \mu \omega_0^{\gamma - 1} \cos\left(\frac{\gamma \pi}{2}\right) (1 - \cos \kappa^*). \tag{19}$$

Equation (16) is a differential equation that yields the analytical expression for the time-dependent amplitude of the nonlinear PC with fractional damping. Solving this equation leads to the following formulation for a:

$$a = a_0 \exp(-\mathcal{H}_1 T_1), \tag{20}$$

Further, by substituting this amplitude in Eq. (17), the nonlinear frequency correction term  $\beta$  can be found as:

$$\beta = \frac{3}{16} \frac{\alpha a_0^2 \omega_0^3}{\mathcal{H}_1} (1 - \exp(-2\mathcal{H}_1 T_1)) + \mathcal{H}_2 T_1$$
 (21)

As a result, the nonlinear dispersion frequency of a fractionally damped PC is found in Eq. (22):

$$\Omega = \omega_0 + \frac{3}{16} \frac{\epsilon \alpha a_0^2 \omega_0^3}{\mathcal{H}_1 T_1} (1 - \exp(-2\mathcal{H}_1 T_1)) + \epsilon \mathcal{H}_2.$$
(22)

It should also be noted that for the case of  $\gamma=1$ , the parameters  $\mathcal{H}_1$  and  $\mathcal{H}_2$  are reduced to  $\mathcal{H}_1=\mu(1-\cos\kappa^*)$  and  $\mathcal{H}_2=0$  yielding the nonlinear

correction factor corresponding to a phononic chain with linear damping [45].

## 2.2 Two-dimensional fractionally damped nonlinear chains

Figure 2 depicts a schematic fractionally damped 2D nonlinear lattice. It consists of identical masses m connected to their neighboring masses by nonlinear springs and fractional dampers. The parameters  $k_1$  and  $\tilde{\alpha}_1$  are the linear and nonlinear stiffness of the springs in the  $\mathbf{a}_1$  direction, respectively. Also, the linear and nonlinear spring coefficients in  $\mathbf{a}_2$  direction are  $k_2$  and  $\tilde{\alpha}_2$ , respectively. Similarly, the coefficients of the fractional damping are  $c_{f1}$  and  $c_{f2}$  in  $\mathbf{a}_1$  and  $\mathbf{a}_2$  directions, respectively. Each mass of the lattice has one degree of freedom, namely  $u_{i,j}$ , which is in the  $\mathbf{a}_3$  direction. As a result, the present spring-mass model is considered as a discretization for the out-of-plane motion of more complex continuous nonlinear lattices with weak viscoelastic properties.

For the presented square lattice, the equation for the motion of mass m with the out-of-plane degree of freedom  $u_{i,j}$  is described by:

![](_page_5_Picture_16.jpeg)

<span id="page-6-0"></span>
$$\begin{split} m\frac{\mathrm{d}^{2}u_{i,j}}{\mathrm{d}t^{2}} + k_{1}\left(2u_{i,j} - u_{i-1,j} - u_{i+1,j}\right) + k_{2}\left(2u_{i,j} - u_{i,j-1} - u_{i,j+1}\right) \\ + & \epsilon\tilde{\alpha}_{1}\left(u_{i,j} - u_{i-1,j}\right)^{3} + \epsilon\tilde{\alpha}_{1}\left(u_{i,j} - u_{i+1,j}\right)^{3} + \epsilon\tilde{\alpha}_{2}\left(u_{i,j} - u_{i,j-1}\right)^{3} \\ + & \epsilon\tilde{\alpha}_{2}\left(u_{i,j} - u_{i,j+1}\right)^{3} + \epsilon c_{f1}D_{t}^{\gamma}\left(2u_{i,j} - u_{i-1,j} - u_{i+1,j}\right) \\ + & \epsilon c_{f2}D_{t}^{\gamma}\left(2u_{i,j} - u_{i,j-1} - u_{i,j+1}\right) = 0. \end{split}$$

$$(23)$$

Following the same procedure in Sect. 3.1, the normalized governing equation is obtained as:

$$\begin{split} u_{i,j}'' + \left(2u_{i,j} - u_{i-1,j} - u_{i+1,j}\right) + r\left(2u_{i,j} - u_{i,j-1} - u_{i,j+1}\right) \\ + & \epsilon \alpha_1 \left(u_{i,j} - u_{i-1,j}\right)^3 + \epsilon \alpha_1 \left(u_{i,j} - u_{i+1,j}\right)^3 + \epsilon \alpha_2 \left(u_{i,j} - u_{i,j-1}\right)^3 \\ + & \epsilon \alpha_2 \left(u_{i,j} - u_{i,j+1}\right)^3 + \epsilon \mu_1 D_{\tau}^{\gamma} \left(2u_{i,j} - u_{i-1,j} - u_{i+1,j}\right) \\ + & \epsilon \mu_2 D_{\tau}^{\gamma} \left(2u_{i,j} - u_{i,j-1} - u_{i,j+1}\right) \\ = & 0, \end{split}$$

(24)

with 
$$\alpha_p = \frac{\tilde{\alpha}_p}{k_1}$$
,  $\mu_p = \frac{c_{fp}}{m\omega_{\rm nat}^7}(p=1,2)$ ,  $\omega_{\rm nat} = \sqrt{\frac{k_1}{m}}$  and  $r = \frac{k_2}{k_1}$ .

Utilizing the method of multiple scales, the following expansion can be expressed for the displacement  $u_{i,i}$ :

$$u_{i,j}(\tau,\varepsilon) = u_{i,j}^{(0)}(T_0, T_1) + \varepsilon u_{i,j}^{(1)}(T_0, T_1)$$
(25)

Substituting the above equation in the governing equation of motion, the  $\varepsilon^0$  and  $\varepsilon^1$  orders of the equation of motion are found as:

$$\varepsilon^{0}: D_{0}^{2} u_{i,j}^{(0)} + \left(2u_{i,j}^{(0)} - u_{i-1,j}^{(0)} - u_{i+1,j}^{(0)}\right) 
+ r \left(2u_{i,j}^{(0)} - u_{i,j-1}^{(0)} - u_{i,j+1}^{(0)}\right) 
= 0,$$
(26)

$$\begin{split} \varepsilon^{1} : D_{0}^{2} u_{i,j}^{(1)} + \left( 2u_{i,j}^{(1)} - u_{i-1,j}^{(1)} - u_{i+1,j}^{(1)} \right) \\ + r \left( 2u_{i,j}^{(1)} - u_{i,j-1}^{(1)} - u_{i,j+1}^{(1)} \right) \\ = -2D_{0} D_{1} u_{i,j}^{(0)} - \alpha_{1} \left( u_{i,j}^{(0)} - u_{i-1,j}^{(0)} \right)^{3} \\ - \alpha_{1} \left( u_{i,j}^{(0)} - u_{i+1,j}^{(0)} \right)^{3} \\ - \alpha_{2} \left( u_{i,j}^{(0)} - u_{i,j-1}^{(0)} \right)^{3} - \alpha_{2} \left( u_{i,j}^{(0)} - u_{i,j+1}^{(0)} \right)^{3} \\ - \mu_{1} D_{\tau}^{\gamma} \left( 2u_{i,j}^{(0)} - u_{i-1,j}^{(0)} - u_{i+1,j}^{(0)} \right) \\ - \mu_{2} D_{\tau}^{\gamma} \left( 2u_{i,j}^{(0)} - u_{i,j-1}^{(0)} - u_{i,j+1}^{(0)} \right), \end{split}$$

$$(27)$$

The solution to the linear differential Eq. (26) can be obtained by assuming the displacement  $u_{i,j}$  in the following form [31]:

$$u_{i,j}^{(0)} = \frac{1}{2} A e^{i\left(\omega_0 T_0 + \mathbf{\kappa} \cdot \mathbf{r}_{i,j}\right)},\tag{28}$$

where A is the amplitude of the motion and  $\mathbf{\kappa}$  is the wave vector. Furthermore,  $\mathbf{r}_{i,j} = n_1 \mathbf{a}_1 + n_2 \mathbf{a}_2$  describes the position vector of a mass in a unit cell which is tessellated by  $n_1$  units in the direction of  $\mathbf{a}_1$  and  $n_2$  units in the direction of  $\mathbf{a}_2$ . The wave vectors are defined inside the irreducible part of the first Brillouin zone (FBZ) inside the reciprocal lattice as  $\mathbf{\kappa} = \kappa_1 \mathbf{b}_1 + \kappa_2 \mathbf{b}_2$ . It is noted that  $(\mathbf{b}_1, \mathbf{b}_2)$  are the reciprocal vectors, which are related to the lattice vectors  $(\mathbf{a}_1, \mathbf{a}_2)$  by  $\mathbf{a}_i.\mathbf{b}_j = \delta_{ij}$ , with  $\delta_{ij}$  being the Kronecker delta. The FBZ and the irreducible Brillouin zone (IBZ) corresponding to the square lattice are presented in "Appendix 1".

Equation (28) can, therefore, be rewritten as:

$$u_{i,j}^{(0)} = \frac{1}{2} A e^{i(\omega_0 T_0 + \kappa_1 n_1 + \kappa_2 n_2)} + \frac{1}{2} A e^{-i(\omega_0 T_0 + \kappa_1 n_1 + \kappa_2 n_2)}.$$
(29)

Substituting Eq. (29) in the  $\varepsilon^{(0)}$ -order Eq. (26), the linear dispersion relation is obtained as:

$$\omega_0 = \sqrt{2(1 - \cos \kappa_1) + 2r(1 - \cos \kappa_2)}.$$
 (30)

A similar procedure to remove the secular terms leads to the following relation:

$$i\omega_{0}D_{1}A + \frac{3}{4}A^{3}\Gamma + \mu_{1}A(i\omega_{0})^{\gamma}(1 - \cos\kappa_{1}) + \mu_{2}A(i\omega_{0})^{\gamma}(1 - \cos\kappa_{2}) = 0,$$
 (31)

where

$$\Gamma = \alpha_1 [\cos(2\kappa_1) - 4\cos(\kappa_1) + 3] + \alpha_2 [\cos(2\kappa_2) - 4\cos(\kappa_2) + 3].$$
 (32)

Writing the amplitude in the polar form of  $A = \frac{1}{2}a(T_1)e^{i\beta(T_1)}$  and separating the real and imaginary parts of Eq. (31), the following equations are obtained:

$$\frac{\mathrm{d}a}{\mathrm{d}T_1} = -\aleph_1,\tag{33}$$

![](_page_6_Picture_25.jpeg)

<span id="page-7-0"></span>
$$\frac{\mathrm{d}\beta}{\mathrm{d}T} = \frac{3a^2}{4\omega_0^2}\Gamma + \aleph_2,\tag{34}$$

where

$$\aleph_1 = \left[\mu_1(1 - \cos \kappa_1) + \mu_2(1 - \cos \kappa_2)\right] \omega_0^{\gamma - 1} \sin\left(\frac{\gamma \pi}{2}\right),\tag{35}$$

$$\aleph_2 = [\mu_1(1 - \cos \kappa_1) + \mu_2(1 - \cos \kappa_2)]\omega_0^{\gamma - 1}\cos\left(\frac{\gamma \pi}{2}\right)$$
(36)

Similar to the one-dimensional case, the expression for amplitude a can be reached by solving Eq. (33). Hence, the time-dependent amplitude is expressed as:

$$a = a_0 e^{-\aleph_1 T_1},\tag{37}$$

and the nonlinear correction factor is found as:

$$\beta = \frac{3a_0^2\Gamma}{8\omega_0^2\aleph_1}(1 - e^{-2\aleph_1T_1}) + \aleph_2T_1.$$
 (38)

Hence, the nonlinear frequency is:

$$\Omega = \omega_0 + \frac{3\varepsilon a_0^2 \Gamma}{8\omega_0^2 \aleph_1 T_1} \left( 1 - e^{-2\aleph_1 T_1} \right) + \varepsilon \aleph_2. \tag{39}$$

#### 3 Results and discussion

The results of our perturbation analysis on the fractionally damped 1D and 2D nonlinear PCs are presented in this section. The analysis begins with the study of the amplitude of the propagating wave in 1D chains, which is time- and wavenumber-dependent. It is then continued by exploring the effect of fractional order and damping coefficient on the nonlinear dispersion frequency as well as the time history of the motion. Then, similar results for 2D nonlinear lattices are presented and discussed in detail.

#### 3.1 1D chains

The evolution of the amplitude in a nonlinear fractionally damped monoatomic 1D chain in both space and time domains is presented in Fig. 3a. Unlike the undamped PCs, the amplitude decays as the time or wavenumber is increased. In other terms, the amplitude of the wave propagation in a nonlinear

![](_page_7_Figure_15.jpeg)

**Fig. 3** a The evolution of the amplitude of a 1D nonlinear PC with fractional damping for different values of normalized time  $(T^*)$  and wavenumber  $(\kappa^*)$ , for the fractional order  $\gamma=0.5$ , and **b** the decay in the amplitude of a fractionally damped nonlinear PC for different values of fractional order  $(\gamma)$ .  $(A_0=4)$ 

**(b)** 

0.5

fractionally damped chain not only decreases in time but also damps with progressing along the FBZ. However, the dependence of the amplitude on the wavenumber is more obvious in larger values of the time. The evolution of the amplitude as a function of space and time is governed by Eq. (20). Therefore, any progress in time or wavenumber can decrease the term  $\exp(-\mathcal{H}_1 T_1)$  in Eq. (20), which in turn, decreases the amplitude.

On the other hand, the effect of fractional order  $\gamma$  on the evolution of the amplitude is illustrated in Fig. 3b. It is inferred from this illustration that higher values of  $\gamma$  result in stronger damping in a nonlinear PC. Therefore, the amplitude decays more with higher values of fractional order. According to Fig. 3, for

![](_page_7_Picture_19.jpeg)

extremely low times  $(T_1 \rightarrow 0)$  as well as small values of wavenumber  $(\kappa^* \rightarrow 0)$ , the effect of  $\gamma$  is almost negligible. Hence, for such conditions, the amplitude of the propagating wave is almost identical for all values of  $\gamma$ . However, as the time is elapsed or larger wavenumbers along the FBZ are crossed, the difference in the amplitudes becomes significant.

It should further be noted that when the fractional order is equal to zero ( $\gamma = 0$ ), the governing equation is reduced to:

$$\ddot{u}_{n} + (\omega_{\text{nat}}^{2} + \varepsilon \mu) (2u_{n} - u_{n-1} - u_{n+1}) + \varepsilon \alpha (u_{n} - u_{n-1})^{3} + \varepsilon \alpha (u_{n} - u_{n+1})^{3} = 0,$$
(40)

which indicates the undamped motion of a cubically nonlinear chain with the equivalent normalized stiffness of  $\omega_{\rm nat}^2 + \varepsilon \mu$ . On the other hand, for the case of  $\gamma = 1$ , the fractionally damped system can resemble the behavior of a weakly nonlinear chain with small viscous damping.

It should be noted that to perform a non-dimensional analysis of the evolution of time-dependent amplitude and nonlinear frequency in Fig. 3, the time is presented as a normalized value. More specifically, the time axis demonstrates a normalized time  $T^*$ , defined as  $T^* = T_1/\tau_{\text{undamped}}$  where  $\tau_{\text{undamped}}$  is the time period of wave propagation of an undamped nonlinear chain expressed  $\tau_{\rm undamped} = 2\pi/\Omega_{\rm undamped}$ . Furthermore,  $\Omega_{\rm undamped}$ denotes the maximum frequency of the nonlinear undamped chain, which can be found by setting  $\mathcal{H}_1 = \mathcal{H}_2 = 0$ , as well as  $\kappa^* = \pi$  in Eq. (22).

The time- and wavenumber-dependent dispersion curves of a fractionally damped weakly nonlinear monoatomic chain are presented in Fig. 4a. Due to the time-dependent decay in the amplitude in the nonlinear fractionally damped chain, the dispersion curve is also time-dependent. This is in contrast to undamped wave propagation, for which the dispersion curves rely only on the wavenumber. It is indicated in Fig. 4a that for a constant wavenumber  $(\kappa^*)$ , the frequency of a fractionally damped weakly nonlinear chain reduces in time. This peculiar phenomenon is exclusive to the nonlinear chain and occurs due to the frequencyamplitude coupling owing to the weak cubic nonlinearity of the system. In other words, since the amplitudes of the propagating waves decrease in time due to the energy dissipation, the nonlinear frequency

![](_page_8_Figure_8.jpeg)

![](_page_8_Figure_9.jpeg)

Fig. 4 a The time-dependent dispersion curve of a fractionally damped nonlinear 1D PC with  $\gamma=0.5$  compared to its linear counterpart. b The frequency difference of a fractionally damped nonlinear 1D PC compared to the linear dispersion curve

reduces as well. The time-dependent nonlinear frequency of the chain is governed by Eq. (22). In mathematical terms, as time elapses, the second term on the right-hand side of Eq. (22) reduces. Thus, the frequency of the nonlinear chain eventually converges to the value of  $\Omega = \omega_0 + \varepsilon \mathcal{H}_2$ . For the sake of comparison, the linear dispersion curves are also illustrated in Fig. 4a as a gray surface. The convergence of the linear and nonlinear dispersion curves in higher times can be observed in Fig. 4a.

For a better elaboration, the deviation of the nonlinear frequency of the 1D chain from the linear frequency is illustrated in Fig. 4b. It is seen that the frequency of the nonlinear chain diverges from its linear counterpart for higher wavenumbers and lower times. Consequently, the maximum deviation of the

![](_page_8_Picture_13.jpeg)

nonlinear frequencies from their linear counterpart is observed at the edge of the FBZ (j ¼ p) at T<sup>1</sup> ¼ 0. However, as we progress through time, the difference reduces, so that it can ultimately converge to the value of X ¼ x<sup>0</sup> þ eH2. The difference between linear and nonlinear frequencies is also minimal for smaller values of wavenumber. The obtained analytical values for dispersion curves at very large times are verified numerically in ''Appendix [2'](#page-21-0)'.

The effect of fractional order on the time history and dispersion curve of a weakly nonlinear 1D chain at different times is depicted in Fig. [6](#page-11-0). To obtain the time history, the time-dependent amplitude A (Eq. [14](#page-4-0)) is substituted in the zeroth-order solution (Eq. [9](#page-4-0)) for a sample mass. For the numerical calculations, the 100th mass of an infinite chain is chosen. Therefore, Fig. [6a](#page-11-0) illustrates u<sup>100</sup> for a sample wavenumber of j ¼ <sup>p</sup> 2. Figure [6](#page-11-0)a illustrates the two limiting cases of c ¼ 0 (undamped wave propagation) and c ¼ 1 (linearly damped wave propagation) for the fractionally damped wave motion in a nonlinear 1D monoatomic chain, as well as the case with fractional order c ¼ 0:5. By comparing the time history of the motion of the fractionally damped and undamped chains, the decrease in both of the amplitude and frequency of the propagating waves can be observed for dissipative chains. More specifically, while the wave propagates with a constant amplitude for the c ¼ 0 case, each peak of the linearly damped motion possesses a lower amplitude compared to the fractionally damped motion with c ¼ 0:5. In addition, the higher period of wave motion in damped cases indicates lower frequency due to the fractional damping.

To perform a more clear investigation of the effect of fractional damping on the frequency of wave propagation, the frequency-domain responses corresponding to each of the three cases are presented in Fig. [5b](#page-10-0)–d. These responses are obtained by performing a fast Fourier transform (FFT) on the time history of the motion. Increasing the fractional order leads to a lower frequency in a propagating wave through the chain.

To investigate the effect of fractional order on the nonlinear frequency of wave propagation in an infinite chain, the nonlinear dispersion curves corresponding to normalized times of T<sup>1</sup> ¼ 0:5, T<sup>1</sup> ¼ 2 and T<sup>1</sup> ¼ 10 are illustrated in Fig. [6a](#page-11-0)–c, respectively. As explained before, nonlinear chains with higher values of fractional order exhibit stronger damping performance. In fact, the higher the value of fractional order c, the more resemblance the system shows to a monoatomic chain with viscous damping. This fact can also be observed in Fig. [6](#page-11-0)a–c, where smaller dispersion frequencies are identified at higher values of fractional order. To compare, the dispersion curves of a linear monoatomic chain, i.e., e ¼ 0, as well as a nonlinear undamped chain, i.e., e 6¼ 0; c ¼ 0; are also plotted, respectively, as dashed and dotted curves in Fig. [6a](#page-11-0)–c. It is noted that as the value of c increases, the dispersion branches deviate from the nonlinear undamped dispersion branch and lie closer to the one corresponding to the linear chain. This phenomenon is more noticeable in larger wavenumbers, whereas the dispersion branches of fractionally damped chains with various values of c are coincident at lower wavenumbers.

In addition, comparing Fig. [6](#page-11-0)a–c, the reduction in the frequency of the nonlinear chains can also be noticed by progressing through time. In other words, as time elapses, the dispersion curves of a fractionally damped nonlinear chain deviate from the ones corresponding to the undamped curves. For larger times, regardless of the value of c, the dispersion curves of nonlinear chains lie very close to the linear chain. This is shown in Fig. [6c](#page-11-0), which depicts the dispersion curves of the nonlinear chain for the rather large time of T<sup>1</sup> ¼ 10.

Similar to the previous figure, the effect of damping coefficient l on the time history of the motion of the 100th mass is illustrated in Fig. [7a](#page-12-0). It is inferred that by increasing the damping coefficient, the rate of amplitude decay also increases. In other words, for a constant value of the fractional-order c, higher damping can be achieved by increasing the damping coefficient. However, due to the weak energy dissipation of the nonlinear chain, investigating the influence of the damping coefficient on the nonlinear frequency is difficult to perform solely based on the time history.

Therefore, the dispersion curves of a weakly nonlinear monoatomic chain with fractional damping are presented in Fig. [8b](#page-13-0)–d at various normalized times and different damping coefficients. It is understood from these illustrations that the dispersion curves can be further tuned by manipulating the damping coefficient. In other words, increasing the damping coefficient leads to lower frequencies in the dispersion curves. Similar to the previous figure, the systems with

![](_page_9_Picture_9.jpeg)

<span id="page-10-0"></span>![](_page_10_Figure_2.jpeg)

**Fig. 5** a The effect of the fractional-order  $\gamma$  on the time history of oscillation of the 100th mass in a fractionally damped 1D PC, as well as the frequency domain response corresponding to  $\mathbf{b}$   $\gamma = 0$ ,  $\mathbf{c}$   $\gamma = 0.5$ , and  $\mathbf{d}$   $\gamma = 1 \cdot \left(\kappa^* = \frac{\pi}{2}\right)$ 

higher damping diverge further from the dispersion curves corresponding to the nonlinear undamped chain and move toward the ones for the linear chain. This divergence occurs at higher times, whereas at the beginning of the motion (smaller values of  $T_1$ ), dispersion curves are closer to the one corresponding to the nonlinear undamped chain.

#### 3.2 2D chains

After the establishment of the concepts of fractionally damped nonlinear PCs in one dimension, the results of the nonlinear wave propagation are expanded to the square lattices in the present section. The variation of the time-dependent amplitude on the edges of the IBZ is illustrated in Fig. 9. Unlike the 1D lattices, for which, the amplitude reduced monotonically as the wavenumber was increased, in 2D lattices, the evolution of the amplitude has a more complex trend. In other terms, while the amplitude decreases while progressing through time for each wave vector, the definition of the wave vectors on the edges of the IBZ implies that the amplitude should be investigated in the three distinct paths of *GX*, *XM*, and *MG*. Once again, the variations of the amplitude are small in lower times, regardless of the wave vector. However, the spatial effects are more noticeable for larger times. Also, since the IBZ is defined as a loop (starting from

![](_page_10_Picture_8.jpeg)

<span id="page-11-0"></span>![](_page_11_Figure_1.jpeg)

Fig. 6 Effect of the fractional-order c on the dispersion curve of a fractionally damped 1D PC in the normalized times of a T<sup>1</sup> ¼ 0:5, b T<sup>1</sup> ¼ 2, c T<sup>1</sup> ¼ 10

the high symmetry point G and returning to this point at the end), it is expected that the values of amplitude become similar at the beginning and end of the contour. This is observed in Fig. [9](#page-13-0), as the amplitude is higher around the high-symmetry point G along the wave-vector axis.

Based on the variation of the amplitudes on the edge of the IBZ for different times, a schematic timedependent dispersion curve for nonlinear wave propagation in fractionally damped square lattices is illustrated in Fig. [10](#page-13-0). Also, to study the effects of nonlinearity and fractional damping qualitatively, the dispersion curves of a linear undamped lattice are also plotted in this figure. As the amplitude faces smaller variations for lower wave-vectors (close to the high symmetry point G), it is expected that the fractionally damped nonlinear curves are formed closer to their linear counterparts. However, in the remainder of the G X M G contour, noticeable deviations can be observed from the linear dispersion curves, which are due to the effect of weak hardening nonlinearity in the springs. Furthermore, due to the existence of energy dissipation (fractional damping), the amplitudes decay in time, and as a result, the dispersion curves are also formed at lower frequencies. This trend continues up to a point where the nonlinear dispersion frequency converges to X ¼ x<sup>0</sup> þ e@<sup>2</sup> at each wave vector. This relation is found by assuming T<sup>1</sup> ! 1 in Eq. [\(39](#page-7-0)). The time-dependent decreasing trend of the peak frequencies is noticed in Fig. [10](#page-13-0) by comparing the frequency values of points A corresponding to the peak frequency at T<sup>1</sup> ¼ 0 and B corresponding to the peak frequency at T<sup>1</sup> ¼ 1:5.

![](_page_11_Picture_6.jpeg)

<span id="page-12-0"></span>![](_page_12_Figure_2.jpeg)

Fig. 7 a The effect of the damping coefficient  $\mu$  on the time history of oscillation of the 100th mass in a fractionally damped 1D PC, as well as the frequency domain response corresponding to  $\mathbf{b}$   $\mu = 0.5$ ,  $\mathbf{c}$   $\mu = 1$ , and  $\mathbf{d}$   $\mu = 5 \cdot \left(\kappa^* = \frac{\pi}{2}\right)$ 

To investigate the effects of the fractional coefficient  $\gamma$  on the wave-propagation behavior of nonlinear 2D PCs with square topology, the dispersion curves for different values of the fractional coefficient  $\gamma$  are presented in Fig. 11a–c, for normalized times of  $T_1=0.1,0.5,3$ , respectively. Moreover, for the comparison, the dispersion curves corresponding to the nonlinear undamped ( $\mu_i=0$ ) lattices and linear lattices ( $\alpha_i=\mu_i=0$ ) are also plotted as dotted and dashed curves, respectively. Similar to the 1D case, including fractional damping yields lower frequencies for the propagation of waves on the lattice. Furthermore, increasing the fractional coefficient  $\gamma$  leads to a stronger energy dissipation, and consequently, lower

frequencies. As indicated in Fig. 9, in the wave-vectors close to the high symmetry point G, the effect of damping is negligible. Hence, the dispersion curves almost converge at such wave-vectors. However, the deviation begins in the GX path, as the amplitude starts decaying. The dispersion curves for different values of  $\gamma$  later converge again as the amplitude rises again along the MG path. Furthermore, comparing Fig. 11 (a) to (c), the decay of the propagation frequency for elapsed time is noticed. Using the fractional dampers in a nonlinear lattice, the upper bound for the dispersion frequency at each wave-vector is the one corresponding to the nonlinear undamped lattice,

![](_page_12_Picture_6.jpeg)

<span id="page-13-0"></span>Fig. 8 Effect of the damping coefficient  $(\mu)$  on the dispersion curves of a fractionally damped 1D PC in the normalized times of a  $T_1 = 0.5$ , **b**  $T_1 = 2$ , **c**  $T_1 = 10(\kappa^* = \frac{\pi}{2})$ 

![](_page_13_Figure_2.jpeg)

Fig. 9 The evolution of the amplitude of a 2D nonlinear PC with fractional damping for various values of normalized time  $(T_1)$  and wave-vector ( $\kappa$ ). ( $\gamma = 0.5$ ,  $\mu_i = 0.5$ )

Fig. 10 The time-dependent dispersion curve of a 2D fractionally damped nonlinear PC with  $\gamma = 0.5$  compared to its linear counterpart ( $\mu_i = 0.5$ )

![](_page_13_Picture_5.jpeg)

<span id="page-14-0"></span>Fig. 11 Effect of the fractional-order c on the dispersion curves of a 2D PC with fractional damping in the normalized times of a T<sup>1</sup> ¼ 0:1, b T<sup>1</sup> ¼ 0:5, c T<sup>1</sup> ¼ 3 (l<sup>i</sup> ¼ 0:5)

![](_page_14_Figure_3.jpeg)

whereas the lower bound is determined by X ¼ x<sup>0</sup> þ e@<sup>2</sup> for T<sup>1</sup> ! 1.

The dispersion curves of a fractionally damped nonlinear square lattice with different values of damping ratio l are presented in Fig. [12](#page-15-0)a–c. Typically, a higher damping ratio leads to a lower frequency in lattices with hardening nonlinearity. As a result, the dispersion branches of the lattices with higher damping ratios are formed at frequencies closer to the ones corresponding to the linear chain. Similar to the effect of fractional order (c), the effect of damping ratio (l) is also less noticeable in the wavevectors close to the high symmetry point G and more prominent in the XM path along the IBZ. Furthermore, as time elapses, the amplitude faces more decay. Consequently, the dispersion branches are also formed at lower frequencies. Nonetheless, the decreasing effect of the damping ratio on the dispersion curves can still be noticed at each specified time. It should, however, be noted that the decreasing effect of the fractional damping is specific to the lattices with hardening nonlinearities. On the contrary, the dispersion curves of the chain with softening nonlinearity are naturally formed in lower frequencies compared to the branches of the linear chains, and increasing the fractional order of damping results in a higher frequency for the dispersion curves. Analytical investigation of wave propagation in phononic chains with softening nonlinearities has previously been studied extensively for conservative structures [[31\]](#page-23-0), as well as linearly and quadratically damped systems [\[46](#page-24-0)]. Therefore, it is not investigated here again.

While in previous sections, we investigated the effects of fractional damping on the dispersion curves of nonlinear monoatomic lattices, the damping was assumed isotropic, i.e., the damping coefficient was the same in both a<sup>1</sup> and a<sup>2</sup> directions (l<sup>1</sup> ¼ l2). However, considering anisotropic damping in a 2D lattice can lead to interesting results. To explore wave propagation in 2D nonlinear lattices with anisotropic damping, the effect of each damping coefficient l<sup>1</sup> and l<sup>2</sup> on the dispersion curves is illustrated individually

![](_page_14_Picture_8.jpeg)

<span id="page-15-0"></span>Fig. 12 Effect of the damping coefficient l on the dispersion curve of a 2D fractionally damped PC in the normalized times of a T<sup>1</sup> ¼ 0:1, b T<sup>1</sup> ¼ 0:5, c T<sup>1</sup> ¼ 3 (c<sup>i</sup> ¼ 0:5)

![](_page_15_Figure_2.jpeg)

in Fig. [13](#page-16-0). Figure [13a](#page-16-0) presents a comparative view of the nonlinear dispersion curves in the presence of anisotropic and isotropic fractional damping. Notably, damping in a<sup>1</sup> direction has a negligible effect on the dispersion curves along the GX path on the edges of the irreducible Brillouin zone. The reason is due to the definition of the GX path which is expressed as GX ¼ <sup>1</sup> <sup>2</sup> b2, independent of b1. As a result, variations in the damping coefficients along a<sup>1</sup> direction does not affect the dispersion behavior and the dispersion curves corresponding to l<sup>1</sup> ¼ 0:2; l<sup>2</sup> ¼ 0 overlaps the undamped case (l<sup>1</sup> ¼ l<sup>2</sup> ¼ 0) along the GX path. However, as a<sup>1</sup> becomes involved in the definition of the Brillouin zone, the effect of l<sup>1</sup> becomes more evident and the dispersion curves are formed at lower frequencies.

Furthermore, a comparison of the cases with l<sup>1</sup> ¼ 0; l<sup>2</sup> 6¼ 0 and l<sup>1</sup> 6¼ 0; l<sup>2</sup> ¼ 0 can further shed light on the details of anisotropic fractional damping in nonlinear 2D lattices. More specifically, while the dispersion curve of the case with damping in a<sup>2</sup> direction is below the dispersion curves of the one in a<sup>1</sup> direction along GX and XM paths, the two branches coincide on the MG path because, along this path, the values of j<sup>1</sup> and j<sup>2</sup> are identical. Therefore, the general effects of damping for the two cases are similar. Finally, the case with an isotropic damping (l<sup>1</sup> ¼ l<sup>2</sup> 6¼ 0) decreases the frequency in all of the paths, leading to the formation of dispersion curves at lower frequencies.

To investigate the effect of each damping coefficient on the nonlinear dispersion curves, Fig. [13](#page-16-0) (b) and (c) is presented. Consistent with the previous explanations, damping in a<sup>1</sup> direction decreases the

![](_page_15_Picture_6.jpeg)

<span id="page-16-0"></span>![](_page_16_Figure_2.jpeg)

Fig. 13 a Effects of damping coefficients l<sup>1</sup> and l<sup>2</sup> on the dispersion curves of a fractionally damped nonlinear lattice, b effects of damping in a<sup>1</sup> direction (l1) on the dispersion curves

(l<sup>2</sup> ¼ 0), c effects of damping in a<sup>2</sup> direction (l2) on the dispersion curves (l<sup>1</sup> ¼ 0)

frequency in X M G path along the irreducible Brillouin zone while does not affect the dispersion curves in G X path. Moreover, as the damping coefficient increases, a sharper decrease in the dispersion curves can be noticed. Figure 13b also shows that higher values of l<sup>1</sup> can reduce the group velocity in the band diagram. This is most noticeable at the beginning of the X M path, where higher damping can lead to the generation of a local minimum in the dispersion curve in X M direction, which was increasing monotonically in the undamped case. Such an exquisite phenomenon was previously noticed in nonlocal 1D chains and a great potential was found for the wave-attenuation performance of such chains [\[89](#page-25-0), [90\]](#page-25-0). Note that the group velocity is defined as the gradient of the dispersion curves at each point [\[31](#page-23-0)].

In addition, the effect of the damping coefficient in a<sup>2</sup> direction is illustrated in Fig. 13c. It is noticed that unlike l1, the damping coefficient l<sup>2</sup> can reduce the frequency of all the points on the dispersion curves along the whole irreducible Brillouin zone. However, the effect of damping can be amplified by applying it in both a<sup>1</sup> and a<sup>2</sup> directions. This is observable in Fig. 13a by comparing the dispersion curves corresponding to l<sup>1</sup> ¼ l<sup>2</sup> 6¼ 0 and l<sup>1</sup> ¼ 0; l<sup>2</sup> 6¼ 0 cases.

![](_page_16_Picture_8.jpeg)

#### <span id="page-17-0"></span>4 Numerical validation

The present section is devoted to the validation of the obtained theoretical results with the ones obtained from the numerical simulation of a 1D PC. The simulated model is a finite chain with 200 springs and masses. The initial conditions are imposed on each mass in the form of displacements and velocities so

that we can write 
$$\begin{bmatrix} u_n \\ v_n \end{bmatrix}_{t=0}^{T} = \begin{bmatrix} A\cos(\kappa_0 n) \\ A\omega\sin(\kappa_0 n) \end{bmatrix}$$
, in which

A is the initial amplitude and  $\kappa_0$  is the wavenumber. In addition,  $\omega$  is the frequency corresponding to the wavenumber  $\kappa_0$  in the linearized chain. Also, the Grünwald–Letnikov definition of the fractional damping is expressed as [65, 91]:

$$D_t^{\gamma}(u(t_l)) \approx \left(\frac{1}{h}\right)^{\gamma} \sum_{i=0}^{l} a_j^{\gamma} u(t_{l-j}). \tag{41}$$

In the previous equation, h is the time step, and  $t_l = lh$  is the computation time. In addition,  $a_j^{\gamma}$  is the binomial coefficient of fractional damping, defined in a recursive way as:

$$a_0^{\gamma} = 1, a_j^{\gamma} = \left(1 - \frac{1 + \gamma}{j}\right) a_{j-1}^{\gamma}.$$
 (42)

The nonlinear coefficient  $\alpha$  is assumed 0.1, and the mass and stiffness of each spring-mass are taken one. Moreover, the fractional-order  $\gamma$  is assumed 0.5, the damping coefficient  $\mu$  is 1, and the initial amplitude is A=2. The present initial value problem is solved using the fourth-order Runge-Kutta method. Then, a fast Fourier transform (FFT) in space and time yields the points on the numerical dispersion curves. Also, by changing the initial conditions, different points on the dispersion curves are obtained. It is found that our theoretical calculations are in very good agreement with the numerical estimations of the dispersion curves of 1D lattices, which can verify the credibility of the presented results in the current paper. It should be noted that the wavenumber-frequency pair should be carefully calculated by performing FFT on the spatial and temporal profiles in the regions closer to the center of the chain where the wave profile is undistorted. To specify the distorted and undistorted regions of the wave propagation, the spatial profile of the motion for a predefined set of initial conditions is illustrated in Fig. 14b. It is emphasized again in this

![](_page_17_Picture_9.jpeg)

As a different scheme for validating the semi-analytical results, the numerical and semi-analytical time histories of the motion of the 100th mass in a chain are compared in Fig. 15, where a perfect agreement can be observed between the results obtained by perturbation methods and numerical simulations. This can further validate the credibility of the semi-analytical formulations that we used in this work. The semi-analytical time history is found by obtaining  $A(T_1)$  using Eq. (20) and substituting it in Eq. (9).

Furthermore, to complete the numerical validation of the results of the semi-analytical study on 1D chains, the effects of nonlinear stiffness ( $\alpha$ ), fractional order ( $\gamma$ ), and damping coefficient ( $\mu$ ) on the dispersion curves are validated numerically in Fig. 16a–c, respectively. Once again, the numerically obtained points on the dispersion curves are found to be very close to the multiple-scale prediction results in each case, suggesting the applicability of the semi-analytical solutions for a wider range of parameters.

Moreover, the accuracy of the semi-analytical solutions for the 2D nonlinear fractionally damped lattice is also validated with numerical simulations, here. For this purpose, the time-domain finite element method [34, 92] is utilized and the numerical dispersion curves are obtained for different initial wave vectors. More specifically, a finite  $61 \times 61$  square lattice chain is considered with parameters of  $m = 1, k_1 = k_2 = 1, \alpha_1 =$ 

 $\alpha_2 = 0.1$ ,  $\mu_1 = \mu_2 = 1$ ,  $\gamma_1 = \gamma_2 = 0.5$ . Furthermore,  $\varepsilon = 0.05$ , A = 2, h = 0.005,  $t_l = 100$  are adopted to obtain numerical dispersion curves. Similar to the 1D chain, the following initial conditions are imposed on the whole system:

$$u_{(p_1,p_2)_{t=0}} = A_0 \cdot \cos(\kappa_{1,0}(p_1 - p_n) - \kappa_{2,0}(p_2 - p_n))$$
(43)

where  $(p1, p2) \in [1, 61]$  denote the position of masses in the finite chain and  $p_n$  designates the position of a specified mass, for which the numerical results are

![](_page_17_Picture_16.jpeg)

<span id="page-18-0"></span>![](_page_18_Figure_2.jpeg)

![](_page_18_Figure_3.jpeg)

Fig. 14 a The numerical validation of the dispersion curve of a weakly nonlinear chain with fractional damping. (m ¼ 1; k ¼ 1; a ¼ 0:1; l ¼ 1; c ¼ 0:5;e

¼ 0:05; A ¼ 2; h ¼ 0:005; tl ¼ 100), b the spatial profile of a 1D nonlinear fractionally damped chain with 200 masses at t ¼ 5T<sup>0</sup>

reported. Furthermore, j1;<sup>0</sup> and j2;<sup>0</sup> are the components of the imposed initial wave vector in b<sup>1</sup> and b<sup>2</sup> directions, respectively. To stay away from boundary reflections, the numerical calculations should be performed in regions closer to the center of the lattice. As a result, the center mass of the chain, located in the position of 30 ð Þ ; 30 , i. e. pn ¼ 30, is selected for the investigation.

Solving the differential equation of motion (Eq. [23\)](#page-5-0) for different values of imposed wave vectors, the temporal and spatial histories of wave propagation in the lattice can be found. The simulation is performed for a time of t ¼ 20T0, where T<sup>0</sup> is the period of vibration for a mass in a linear lattice. Then, performing FFT on the history of motion can generate the numerical dispersion curves for the provided lattice. The comparison is provided in Fig. [17a](#page-20-0). It is observed that numerical and semi-analytical results exhibit a close match, proving the accuracy and applicability of multiple-scale analysis for fractionally damped nonlinear lattices. For the sake of comparison, the semi-analytical dispersion curves of a 2D linear chain are also numerically validated in Fig. [17](#page-20-0)a.

For more elaboration, the numerically obtained FFT results of the temporal profile of the wave propagation at two different points on the dispersion curves are also presented in Fig. [17b](#page-20-0), c. Figure [17](#page-20-0)b denotes the FFT results for the linear lattice for j ¼ ð Þ 0; 1:94 , while Fig. [17c](#page-20-0) shows the FFT results of

![](_page_18_Picture_10.jpeg)

<span id="page-19-0"></span>![](_page_19_Figure_2.jpeg)

Fig. 15 Semi-analytical and numerical time histories of the motion of the 100th mass in a fractionally damped nonlinear chain (m ¼ 1; k ¼ 1; a ¼ 1; l ¼ 1; c ¼ 0:5;e ¼ 0:05; A ¼ 2; h ¼ 0:005; tl ¼ 100)

![](_page_19_Figure_4.jpeg)

Fig. 16 Comparison of the multiple scales and numerical dispersion curves for different values of a nonlinear stiffness (a), b fractional order (c), and c damping coefficient (l) for (m ¼ 1; k ¼ 1;e ¼ 0:05; A ¼ 4; h ¼ 0:005; tl ¼ 100)

![](_page_19_Picture_6.jpeg)

- <span id="page-20-0"></span>

![](_page_20_Figure_6.jpeg)

![](_page_20_Figure_7.jpeg)

**(c)**

Fig. 17 a The numerical validation of the dispersion curve of a 2D weakly nonlinear lattice with fractional damping for (m ¼ 1; k<sup>1</sup> ¼ k<sup>2</sup> ¼ 1; a<sup>1</sup> ¼ a<sup>2</sup> ¼ 0:1; l<sup>1</sup> ¼ l<sup>2</sup> ¼ 1; c<sup>1</sup> ¼ c<sup>2</sup> ¼ 0:5;e ¼ 0:05; A ¼ 2; h ¼ 0:005; tl ¼ 100). The numerical

frequency domain response of the mass located at 30 ð Þ ; 30 for b j ¼ ð Þ 0; 1:94 in the linear undamped lattice and c j ¼ ð Þ 1:58; 1:58 in the fractionally damped nonlinear lattice

Fig. 18 FBZ (black dots) and IBZ (gray triangle) for a square lattice

![](_page_20_Picture_12.jpeg)

the nonlinear fractionally damped case at j ¼ ð Þ 1:58; 1:58 .

### 5 Conclusion

In this work, wave propagation in fractionally damped weakly nonlinear monoatomic 1D chains and 2D lattices was studied. Method of multiple scales was implemented, and the semi-analytical expressions for the propagation of waves in fractionally damped PCs were obtained. The unique phenomenon of frequencyamplitude coupling, exclusive for nonlinear PCs, played a crucial role in the estimation of the fractionally damped frequencies for each wavenumber since the amplitude decayed in time due to the energy dissipation.

The results indicated that as the amplitude of the propagating wave in a fractionally damped PC changes in time, the dispersion curve also becomes

![](_page_20_Picture_17.jpeg)

<span id="page-21-0"></span>time-dependent. More specifically, due to the amplitude dependency of the nonlinear frequency in a fractionally damped phononic chain, the reduced amplitudes of the chains result in lower frequencies. Furthermore, the results showed that increasing the fractional order of damping increases energy dissipation in the PC leading to lower frequencies of the wave propagation. However, the effect of fractional order was constrained by its lower and upper limits of  $\gamma = 0$ and  $\gamma = 1$ , for which the structure resembles a nonlinear chain without damping and with viscous damping, respectively. The semi-analytical approach was then extended to 2D lattices, and the nonlinear dispersion relations for a fractionally damped square lattice were also obtained. The results showed that the evolution of the amplitude for a fractionally damped 2D square lattice had a more complex trend.

Implementing fractional derivatives in modeling nonlinear PCs is considered a breakthrough on the path of predicting the dynamic behavior of PCs, as it provides a more general idea on the energy dissipation. The results of this work can be further expanded to nonlinear continuous periodic structures to model viscoelastic behavior more properly.

**Funding** The authors declare that no funds, grants, and other support were received during the preparation of this manuscript.

**Data availability** The datasets generated during and/or analyzed during the current study are available from the corresponding author on reasonable request.

#### **Declarations**

**Conflict of interest** The authors declare that they have no conflict of interest.

# Appendix 1: First Brillouin zone (FBZ) and irreducible Brillouin zone (IBZ) of a square lattice

The high symmetry points of G, X, and M along the edges of the IBZ are defined in Table 1.

The wave vectors are then defined on the closed-loop of G - X - M - G along the edges of the IBZ. Also, FBZ and IBZ of a square lattice are depicted in Fig. 18.

## Appendix 2: Numerical validation of dispersion curves when $t \to \infty$

To validate the analytic dispersion curve at very large times  $(t \to \infty)$  numerically, several simulations similar to Sect. 4 are performed. The analytic dispersion curves are obtained using a very large value of  $T_1$  in Eq. (22), reducing the dispersion frequency to  $\Omega \cong \omega_0 + \varepsilon \mathcal{H}_2$ . The numerical validation is presented in Fig. 19. For a better comparative view, the dispersion curve of a linear undamped chain is also illustrated in a red dashed line. It is numerically verified that unlike the PCs with linear damping, the dispersion curve of a fractionally damped nonlinear chain does not converge to the dispersion curve of the linear chain even at very large times. However, due to the weak nature of the nonlinearities of the system, the curves are formed very close to each other. Therefore, the magnified dispersion curves at larger wavenumbers are also plotted separately.

## Appendix 3: The $\Omega - T^*$ planes of dispersion curves of 1D and 2D structures

More detailed information about the time-dependent behavior of the dispersion curves in 1D and 2D crystals can be obtained by investigating the

Table 1 The coordinates of high symmetry points for a 2D lattice with square topology in Cartesian and reciprocal coordinates

| Cartesian coordinates  | G = (0,0) | $X = \frac{1}{d} \left( 0, \frac{1}{2} \right)$ | $M = \frac{1}{d} \left( \frac{1}{2}, \frac{1}{2} \right)$ |
|------------------------|-----------|-------------------------------------------------|-----------------------------------------------------------|
| Reciprocal coordinates | G = (0,0) | $X = \left(0, \frac{1}{2}\right)$               | $M=\left(\frac{1}{2},\frac{1}{2}\right)$                  |

![](_page_21_Picture_16.jpeg)

<span id="page-22-0"></span>![](_page_22_Figure_2.jpeg)

Fig. 19 The numerical validation of the dispersion curve of a weakly nonlinear chain with fractional damping when t ! 1 for (m ¼ 1; k ¼ 1; a ¼ 0:1; l ¼ 1; c ¼ 0:5; e ¼ 0:05; A ¼

2; h ¼ 0:005; tl ¼ 100) along with the magnified frequency range of X ¼ ½ 1:85; 2

Fig. 20 The X T planes of 3D dispersion curves of a 1D and b 2D nonlinear fractionally damped PCs

![](_page_22_Figure_6.jpeg)

![](_page_22_Figure_7.jpeg)

corresponding planes of X T of the schematic 3D dispersion curves. They are presented in Fig. 20a, b, respectively. The gray lines in Fig. 20a, b denote the maximum frequency of the linear PC without considering the effect of fractional damping. It is observed that the peak point exhibits a time-independent behavior, attaining constant values at different times. On the other hand, the time-dependent evolution of the dispersion curves of the fractionally damped nonlinear chain can be clearly noticed by comparing the frequencies at points A and B. It is observed that as the time passes, the dispersion curves of the fractionally damped nonlinear PCs are converged to the ones corresponding to the linear undamped chains/lattices.

#### References

- 1. Wang, Z., Liu, Z., Lee, J.: Tuning the working frequency of elastic metamaterials by heat. Acta Mech. 231, 1477–1484 (2020). <https://doi.org/10.1007/s00707-019-02599-1>
- 2. Wei, Y.-L.L., Yang, Q.-S.S., Tao, R.: SMP-based chiral auxetic mechanical metamaterial with tunable bandgap function. Int. J. Mech. Sci. 195, 106267 (2021). [https://doi.](https://doi.org/10.1016/j.ijmecsci.2021.106267) [org/10.1016/j.ijmecsci.2021.106267](https://doi.org/10.1016/j.ijmecsci.2021.106267)
- 3. Li, Y., Dong, X., Li, H., Yao, S.: Hybrid multi-resonators elastic metamaterials for broad low-frequency bandgaps. Int. J. Mech. Sci. 202–203, 106501 (2021). [https://doi.org/](https://doi.org/10.1016/j.ijmecsci.2021.106501) [10.1016/j.ijmecsci.2021.106501](https://doi.org/10.1016/j.ijmecsci.2021.106501)
- 4. Hedayatrasa, S., Kersemans, M., Abhary, K., Uddin, M., Guest, J.K., Van Paepegem, W.: Maximizing bandgap width and in-plane stiffness of porous phononic plates for tailoring flexural guided waves: Topology optimization and experimental validation. Mech. Mater. 105, 188–203 (2017). <https://doi.org/10.1016/j.mechmat.2016.12.003>

![](_page_22_Picture_14.jpeg)

<span id="page-23-0"></span>5. Jensen, J.S.: Phononic band gaps and vibrations in one- and two-dimensional mass-spring structures. J. Sound Vib. 266, 1053–1078 (2003). [https://doi.org/10.1016/S0022-](https://doi.org/10.1016/S0022-460X(02)01629-2) [460X\(02\)01629-2](https://doi.org/10.1016/S0022-460X(02)01629-2)

- 6. Jiang, W., Yin, M., Liao, Q., Xie, L., Yin, G.: Three-dimensional single-phase elastic metamaterial for low-frequency and broadband vibration mitigation. Int. J. Mech. Sci. 190, 106023 (2021). [https://doi.org/10.1016/j.ijmecsci.](https://doi.org/10.1016/j.ijmecsci.2020.106023) [2020.106023](https://doi.org/10.1016/j.ijmecsci.2020.106023)
- 7. Hatanaka, D., Mahboob, I., Onomitsu, K., Yamaguchi, H.: Phonon waveguides for electromechanical circuits. Nat. Nanotechnol. 9, 520–524 (2014). [https://doi.org/10.1038/](https://doi.org/10.1038/nnano.2014.107) [nnano.2014.107](https://doi.org/10.1038/nnano.2014.107)
- 8. Andreassen, E., Manktelow, K., Ruzzene, M.: Directional bending wave propagation in periodically perforated plates. J. Sound Vib. 335, 187–203 (2015). [https://doi.org/10.1016/](https://doi.org/10.1016/j.jsv.2014.09.035) [j.jsv.2014.09.035](https://doi.org/10.1016/j.jsv.2014.09.035)
- 9. Li, F., Anzel, P., Yang, J., Kevrekidis, P.G., Daraio, C.: Granular acoustic switches and logic elements. Nat. Commun. 5, 1–6 (2014). <https://doi.org/10.1038/ncomms6311>
- 10. Alinejad-Naini, M., Bahrami, A.: Thermal switching of ultrasonic waves in two-dimensional solid/fluid phononic crystals. Phys. Scr. 94, 125705 (2019). [https://doi.org/10.](https://doi.org/10.1088/1402-4896/ab3833) [1088/1402-4896/ab3833](https://doi.org/10.1088/1402-4896/ab3833)
- 11. Khateib, F., Mehaney, A., Amin, R.M., Aly, A.H.: Ultrasensitive acoustic biosensor based on a 1D phononic crystal. Phys. Scr. 95, 75704 (2020). [https://doi.org/10.1088/1402-](https://doi.org/10.1088/1402-4896/ab8e00) [4896/ab8e00](https://doi.org/10.1088/1402-4896/ab8e00)
- 12. Ning, L., Wang, Y.Z., Wang, Y.S.: Active control cloak of the elastic wave metamaterial. Int. J. Solids Struct. 202, 126–135 (2020). [https://doi.org/10.1016/j.ijsolstr.2020.06.](https://doi.org/10.1016/j.ijsolstr.2020.06.009) [009](https://doi.org/10.1016/j.ijsolstr.2020.06.009)
- 13. Ning, L., Wang, Y.-Z., Wang, Y.-S.: Active control of a black hole or concentrator for flexural waves in an elastic metamaterial plate. Mech. Mater. 142, 103300 (2020). <https://doi.org/10.1016/j.mechmat.2019.103300>
- 14. Sun, H.X., Zhang, S.Y., Shui, X.J.: A tunable acoustic diode made by a metal plate with periodical structure. Appl. Phys. Lett. 100, 103507 (2012). [https://doi.org/10.1063/1.](https://doi.org/10.1063/1.3693374) [3693374](https://doi.org/10.1063/1.3693374)
- 15. Meaud, J., Che, K.: Tuning elastic wave propagation in multistable architected materials. Int. J. Solids Struct. 122–123, 69–80 (2017). [https://doi.org/10.1016/j.ijsolstr.](https://doi.org/10.1016/j.ijsolstr.2017.05.042) [2017.05.042](https://doi.org/10.1016/j.ijsolstr.2017.05.042)
- 16. Bera, K.K., Banerjee, A.: Ultra-wide bandgap in active metamaterial from feedback control. J. Vib. Control (2021). <https://doi.org/10.1177/10775463211035890>
- 17. Frandsen, N.M.M., Jensen, J.S.: Modal interaction and higher harmonic generation in a weakly nonlinear, periodic mass–spring chain. Wave Motion 68, 149–161 (2017). <https://doi.org/10.1016/j.wavemoti.2016.09.002>
- 18. Silva, P.B., Leamy, M.J., Geers, M.G.D., Kouznetsova, V.G.: Emergent subharmonic band gaps in nonlinear locally resonant metamaterials induced by autoparametric resonance. Phys. Rev. E 99, 1–14 (2019). [https://doi.org/10.](https://doi.org/10.1103/PhysRevE.99.063003) [1103/PhysRevE.99.063003](https://doi.org/10.1103/PhysRevE.99.063003)
- 19. Fronk, M.D., Leamy, M.J.: Internally resonant wave energy exchange in weakly nonlinear lattices and metamaterials. Phys. Rev. E 100, 32213 (2019). [https://doi.org/10.1103/](https://doi.org/10.1103/PhysRevE.100.032213) [PhysRevE.100.032213](https://doi.org/10.1103/PhysRevE.100.032213)

- 20. Bukhari, M., Barry, O.: Simultaneous energy harvesting and vibration control in a nonlinear metastructure: a spectrospatial analysis. J. Sound Vib. 473, 115215 (2020). [https://](https://doi.org/10.1016/j.jsv.2020.115215) [doi.org/10.1016/j.jsv.2020.115215](https://doi.org/10.1016/j.jsv.2020.115215)
- 21. Vakakis, A.F., King, M.E.: Nonlinear wave transmission in a monocoupled elastic periodic system. J. Acoust. Soc. Am. 98, 1534–1546 (1995). <https://doi.org/10.1121/1.413419>
- 22. Narisetti, R.K., Leamy, M.J., Ruzzene, M.: A perturbation approach for predicting wave propagation in one-dimensional nonlinear periodic structures. J. Vib. Acoust. Trans. ASME 132, 0310011–03100111 (2010). [https://doi.org/10.](https://doi.org/10.1115/1.4000775) [1115/1.4000775](https://doi.org/10.1115/1.4000775)
- 23. Manktelow, K., Leamy, M.J., Ruzzene, M.: Multiple scales analysis of wave-wave interactions in a cubically nonlinear monoatomic chain. Nonlinear Dyn. 63, 193–203 (2011). <https://doi.org/10.1007/s11071-010-9796-1>
- 24. Zhou, W.J., Li, X.P., Wang, Y.S., Chen, W.Q., Huang, G.L.: Spectro-spatial analysis of wave packet propagation in nonlinear acoustic metamaterials. J. Sound Vib. 413, 250–269 (2018). <https://doi.org/10.1016/j.jsv.2017.10.023>
- 25. Fang, L., Darabi, A., Mojahed, A., Vakakis, A.F., Leamy, M.J.: Broadband non-reciprocity with robust signal integrity in a triangle-shaped nonlinear 1D metamaterial. Nonlinear Dyn. 100, 1–13 (2020). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-020-05520-x) [s11071-020-05520-x](https://doi.org/10.1007/s11071-020-05520-x)
- 26. Patil, G.U., Matlack, K.H.: Review of exploiting nonlinearity in phononic materials to enable nonlinear wave responses. Acta Mech. (2022). [https://doi.org/10.1007/](https://doi.org/10.1007/s00707-021-03089-z) [s00707-021-03089-z](https://doi.org/10.1007/s00707-021-03089-z)
- 27. Ganesh, R., Gonella, S.: From modal mixing to tunable functional switches in nonlinear phononic crystals. Phys. Rev. Lett. 54302, 1–5 (2015). [https://doi.org/10.1103/](https://doi.org/10.1103/PhysRevLett.114.054302) [PhysRevLett.114.054302](https://doi.org/10.1103/PhysRevLett.114.054302)
- 28. Shin, D., Cupertino, A., de Jong, M.H.J., Steeneken, P.G., Bessa, M.A., Norte, R.A.: Spiderweb nanomechanical resonators via Bayesian optimization: inspired by nature and guided by machine learning. Adv. Mater. 34, 2106248 (2022). <https://doi.org/10.1002/adma.202106248>
- 29. Eynbeygui, M., Arghavani, J., Akbarzadeh, A.H., Naghdabadi, R.: Anisotropic elastic–plastic behavior of architected pyramidal lattice materials. Acta Mater. 183, 118–136 (2020). [https://doi.org/10.1016/j.actamat.2019.10.](https://doi.org/10.1016/j.actamat.2019.10.038) [038](https://doi.org/10.1016/j.actamat.2019.10.038)
- 30. Meaud, J.: Nonlinear wave propagation and dynamic reconfiguration in two-dimensional lattices with bistable elements. J. Sound Vib. (2020). [https://doi.org/10.](https://doi.org/10.1016/j.jsv.2020.115239) [1016/j.jsv.2020.115239](https://doi.org/10.1016/j.jsv.2020.115239)
- 31. Narisetti, R.K., Ruzzene, M., Leamy, M.J.: A perturbation approach for analyzing dispersion and group velocities in two-dimensional nonlinear periodic lattices. J. Vib. Acoust. Trans. ASME 133, 1–12 (2011). [https://doi.org/10.1115/1.](https://doi.org/10.1115/1.4004661) [4004661](https://doi.org/10.1115/1.4004661)
- 32. Meaud, J.: Multistable two-dimensional spring-mass lattices with tunable band gaps and wave directionality. J. Sound Vib. 434, 44–62 (2018). [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.jsv.2018.07.032) [jsv.2018.07.032](https://doi.org/10.1016/j.jsv.2018.07.032)
- 33. Zaera, R., Vila, J., Fernandez-Saez, J., Ruzzene, M.: Propagation of solitons in a two-dimensional nonlinear square lattice. Int. J. Non Linear Mech. 106, 188–204 (2018). <https://doi.org/10.1016/j.ijnonlinmec.2018.08.002>

![](_page_23_Picture_30.jpeg)

- <span id="page-24-0"></span>34. Manktelow, K.L., Leamy, M.J., Ruzzene, M.: Weakly nonlinear wave interactions in multi-degree of freedom periodic structures. Wave Motion 51, 886–904 (2014). <https://doi.org/10.1016/j.wavemoti.2014.03.003>
- 35. Wang, J., Huang, Y., Chen, W., Zhu, W.: Abnormal wave propagation behaviors in two-dimensional mass–spring structures with nonlocal effect. Math. Mech. Solids 24, 3632–3643 (2019). [https://doi.org/10.1177/](https://doi.org/10.1177/1081286519853606) [1081286519853606](https://doi.org/10.1177/1081286519853606)
- 36. Li, Z.N., Wang, Y.Z., Wang, Y.S.: Tunable nonreciprocal transmission in nonlinear elastic wave metamaterial by initial stresses. Int. J. Solids Struct. 182–183, 218–235 (2020). <https://doi.org/10.1016/j.ijsolstr.2019.08.020>
- 37. Das, S., Bohra, M., Geetha Rajasekharan, S., Daseswara Rao, Y.V.: Investigations on the band-gap characteristics of one-dimensional flexural periodic structures with varying geometries. JVC/J. Vib. Control (2021). [https://doi.org/10.](https://doi.org/10.1177/10775463211036818) [1177/10775463211036818](https://doi.org/10.1177/10775463211036818)
- 38. Gan, C., Wei, Y., Yang, S.: Longitudinal wave propagation in a multi-step rod with variable cross-section. JVC/J. Vib. Control 22, 837–852 (2016). [https://doi.org/10.1177/](https://doi.org/10.1177/1077546314531806) [1077546314531806](https://doi.org/10.1177/1077546314531806)
- 39. Ghavanloo, E., Fazelzadeh, S.A.: Wave propagation in onedimensional infinite acoustic metamaterials with long-range interactions. Acta Mech. 230, 4453–4461 (2019). [https://](https://doi.org/10.1007/s00707-019-02514-8) [doi.org/10.1007/s00707-019-02514-8](https://doi.org/10.1007/s00707-019-02514-8)
- 40. Farzbod, F., Leamy, M.J.: Analysis of Bloch's method in structures with energy dissipation. J. Vib. Acoust. Trans. ASME 133, 1–8 (2011). <https://doi.org/10.1115/1.4003943>
- 41. Alamri, S., Li, B., Mchugh, G., Garafolo, N., Tan, K.T.: Dissipative diatomic acoustic metamaterials for broadband asymmetric elastic-wave transmission. J. Sound Vib. 451, 120–137 (2019). <https://doi.org/10.1016/j.jsv.2019.03.018>
- 42. Jafari, H., Yazdi, M.H., Fakhrabadi, M.M.S.: Damping effects on wave-propagation characteristics of microtubulebased bio-nano-metamaterials. Int. J. Mech. Sci. 184, 105844 (2020). [https://doi.org/10.1016/j.ijmecsci.2020.](https://doi.org/10.1016/j.ijmecsci.2020.105844) [105844](https://doi.org/10.1016/j.ijmecsci.2020.105844)
- 43. He, Q.Q.L.Z.C., Li, E.: Dissipative multi-resonator acoustic metamaterials for impact force mitigation and collision energy absorption. Acta Mech. 2935, 2905–2935 (2019). <https://doi.org/10.1007/s00707-019-02437-4>
- 44. Xu, X., Barnhart, M.V., Fang, X., Wen, J., Chen, Y., Huang, G.: A nonlinear dissipative elastic metamaterial for broadband wave mitigation. Int. J. Mech. Sci 164, 105159 (2019). <https://doi.org/10.1016/j.ijmecsci.2019.105159>
- 45. Fronk, M.D., Leamy, M.J.: Higher-order dispersion, stability, and waveform invariance in nonlinear monoatomic and diatomic systems. J. Vib. Acoust. Trans. ASME 139, 1–13 (2017). <https://doi.org/10.1115/1.4036501>
- 46. Sepehri, S., Mashhadi, M.M., Fakhrabadi, M.M.S.: Wave propagation in nonlinear monoatomic chains with linear and quadratic damping. Nonlinear Dyn. (2022). [https://doi.org/](https://doi.org/10.1007/s11071-021-07184-7) [10.1007/s11071-021-07184-7](https://doi.org/10.1007/s11071-021-07184-7)
- 47. Fronk, M.D., Leamy, M.J.: Direction-dependent invariant waveforms and stability in two-dimensional, weakly nonlinear lattices. J Sound Vib. 447, 137–154 (2019). [https://](https://doi.org/10.1016/j.jsv.2019.01.022) [doi.org/10.1016/j.jsv.2019.01.022](https://doi.org/10.1016/j.jsv.2019.01.022)
- 48. Ning, S., Chu, D., Jiang, H., Yang, F., Liu, Z., Zhuang, Z.: The role of material and geometric nonlinearities and damping effects in designing mechanically tunable acoustic

- metamaterials. Int. J. Mech. Sci. 197, 106299 (2021). <https://doi.org/10.1016/j.ijmecsci.2021.106299>
- 49. Zarraga, O., Sarrı´a, I., Garcı´a-Barruetaben˜a, J., Corte´s, F.: An analysis of the dynamical behaviour of systems with fractional damping for mechanical engineering applications. Symmetry (Basel) 11, 1–15 (2019). [https://doi.org/10.](https://doi.org/10.3390/SYM11121499) [3390/SYM11121499](https://doi.org/10.3390/SYM11121499)
- 50. Bagley, R.L., Torvik, P.J.: A theoretical basis for the application of fractional calculus to viscoelasticity. J. Rheol. 27, 201–210 (1983). <https://doi.org/10.1122/1.549724>
- 51. Di Paola, M., Pirrotta, A., Valenza, A.: Visco-elastic behavior through fractional calculus: an easier method for best fitting experimental results. Mech. Mater. 43, 799–806 (2011). <https://doi.org/10.1016/j.mechmat.2011.08.016>
- 52. Lv, Q., Yao, Z.: Analysis of the effects of nonlinear viscous damping on vibration isolator. Nonlinear Dyn. 79, 2325–2332 (2015). [https://doi.org/10.1007/s11071-014-](https://doi.org/10.1007/s11071-014-1814-2) [1814-2](https://doi.org/10.1007/s11071-014-1814-2)
- 53. Rusinek, R., Weremczuk, A., Kecik, K., Warminski, J.: Dynamics of a time delayed Duffing oscillator. Int. J. Non Linear Mech. 65, 98–106 (2014). [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.ijnonlinmec.2014.04.012) [ijnonlinmec.2014.04.012](https://doi.org/10.1016/j.ijnonlinmec.2014.04.012)
- 54. Fangnon, R., Ainamon, C., Monwanou, A.V., Miwadinou, C.H., Chabi Orou, J.B.: Nonlinear dynamics of the quadratic-damping Helmholtz oscillator. Complexity 2020, 1–17 (2020). <https://doi.org/10.1155/2020/8822534>
- 55. Peng, Z.K., Meng, G., Lang, Z.Q., Zhang, W.M., Chu, F.L.: Study of the effects of cubic nonlinear damping on vibration isolations using Harmonic Balance Method. Int. J. Non Linear Mech. 47, 1073–1080 (2012). [https://doi.org/10.](https://doi.org/10.1016/j.ijnonlinmec.2011.09.013) [1016/j.ijnonlinmec.2011.09.013](https://doi.org/10.1016/j.ijnonlinmec.2011.09.013)
- 56. Bagley, R.L., Torvik, P.J.: On the fractional calculus model of viscoelastic behavior. J. Rheol. 30, 133–155 (1986). <https://doi.org/10.1122/1.549887>
- 57. Shokooh, A., Sua´rez, L.: A comparison of numerical methods applied to a fractional model of damping materials. JVC/J. Vib. Control 5, 331–354 (1999). [https://doi.org/10.](https://doi.org/10.1177/107754639900500301) [1177/107754639900500301](https://doi.org/10.1177/107754639900500301)
- 58. Yuan, L., Agrawal, O.P.: A numerical scheme for dynamic systems containing fractional derivatives. J. Vib. Acoust. Trans. ASME 124, 321–324 (2002). [https://doi.org/10.](https://doi.org/10.1115/1.1448322) [1115/1.1448322](https://doi.org/10.1115/1.1448322)
- 59. Suarez, L.E., Shokooh, A.: An eigenvector expansion method for the solution of motion containing fractional derivatives. J. Appl. Mech. Trans. ASME 64, 629–635 (1997). <https://doi.org/10.1115/1.2788939>
- 60. Torvik, P.J., Bagley, R.L.: On the appearance of the fractional derivative in the behavior of real materials. J. Appl. Mech. Trans. ASME 51, 294–298 (1984). [https://doi.org/10.](https://doi.org/10.1115/1.3167615) [1115/1.3167615](https://doi.org/10.1115/1.3167615)
- 61. Wang, J.C.: Realizations of generalized Warburg impedance with RC ladder networks and transmission lines. J. Electrochem. Soc. 134, 1915–1920 (1987). [https://doi.](https://doi.org/10.1149/1.2100789) [org/10.1149/1.2100789](https://doi.org/10.1149/1.2100789)
- 62. Chen, Y.Q.: Ubiquitous fractional order controls? IFAC Proc. 2, 481–492 (2006). [https://doi.org/10.3182/20060719-](https://doi.org/10.3182/20060719-3-pt-4902.00081) [3-pt-4902.00081](https://doi.org/10.3182/20060719-3-pt-4902.00081)
- 63. Rossikhin, Y.A., Shitikova, M.V.: New approach for the analysis of damped vibrations of fractional oscillators. Shock Vib. 16, 365–387 (2009). [https://doi.org/10.3233/](https://doi.org/10.3233/SAV-2009-0475) [SAV-2009-0475](https://doi.org/10.3233/SAV-2009-0475)

![](_page_24_Picture_33.jpeg)

<span id="page-25-0"></span>64. Padovan, J.O.E., Sawicki, J.T.: Nonlinear vibrations of fractionally damped systems. Nonlinear Dyn. 16, 321–336 (1998). <https://doi.org/10.1023/A:1008289024058>

- 65. Cao, J., Ma, C., Xie, H., Jiang, Z.: Nonlinear dynamics of duffing system with fractional order damping. J. Comput. Nonlinear Dyn. 5, 1–6 (2010). [https://doi.org/10.1115/1.](https://doi.org/10.1115/1.4002092) [4002092](https://doi.org/10.1115/1.4002092)
- 66. Xie, F., Lin, X.: Asymptotic solution of the van der Pol oscillator with small fractional damping. Phys. Scr. T T136, 14033 (2009). [https://doi.org/10.1088/0031-8949/2009/](https://doi.org/10.1088/0031-8949/2009/T136/014033) [T136/014033](https://doi.org/10.1088/0031-8949/2009/T136/014033)
- 67. Ortiz, A., Yang, J., Coccolo, M., Seoane, J.M., Sanjua´n, M.A.F.: Fractional damping enhances chaos in the nonlinear Helmholtz oscillator. Nonlinear Dyn. 102, 2323–2337 (2020). <https://doi.org/10.1007/s11071-020-06070-y>
- 68. Syta, A., Litak, G., Lenci, S., Scheffler, M.: Chaotic vibrations of the Duffing system with fractional damping. Chaos 24, 1–6 (2014). <https://doi.org/10.1063/1.4861942>
- 69. Wang, P., Wang, Q., Xu, X., Chen, N.: Fractional critical damping theory and its application in active suspension control. Shock Vib. (2017). [https://doi.org/10.1155/2017/](https://doi.org/10.1155/2017/2738976) [2738976](https://doi.org/10.1155/2017/2738976)
- 70. Dastjerdi, A.A., Vinagre, B.M., Chen, Y.Q., HosseinNia, S.H.: Linear fractional order controllers; a survey in the frequency domain. Annu. Rev. Control 47, 51–70 (2019). <https://doi.org/10.1016/j.arcontrol.2019.03.008>
- 71. Chen, Y.Q., Petra´sˇ, I., Xue, D.: Fractional order control—a tutorial. Proc. Am. Control Conf. (2009). [https://doi.org/10.](https://doi.org/10.1109/ACC.2009.5160719) [1109/ACC.2009.5160719](https://doi.org/10.1109/ACC.2009.5160719)
- 72. Feliu-Talegon, D., Feliu-Batlle, V., Tejado, I., Vinagre, B.M., HosseinNia, S.H.: Stable force control and contact transition of a single link flexible robot using a fractionalorder controller. ISA Trans. 89, 139–157 (2019). [https://doi.](https://doi.org/10.1016/j.isatra.2018.12.031) [org/10.1016/j.isatra.2018.12.031](https://doi.org/10.1016/j.isatra.2018.12.031)
- 73. Karbasizadeh, N., Saikumar, N., HosseinNia, S.H.: Fractional-order single state reset element. Nonlinear Dyn. 104, 413–427 (2021). [https://doi.org/10.1007/s11071-020-](https://doi.org/10.1007/s11071-020-06138-9) [06138-9](https://doi.org/10.1007/s11071-020-06138-9)
- 74. Liu, Y., Yu, D., Zhao, H., Wen, J., Wen, X.: Theoretical study of two-dimensional phononic crystals with viscoelasticity based on fractional derivative models. J. Phys. D Appl. Phys. 41, 65503 (2008). [https://doi.org/10.1088/](https://doi.org/10.1088/0022-3727/41/6/065503) [0022-3727/41/6/065503](https://doi.org/10.1088/0022-3727/41/6/065503)
- 75. Cajic´, M., Karlicˇic´, D., Paunovic´, S., Adhikari, S.: A fractional calculus approach to metadamping in phononic crystals and acoustic metamaterials. Theor. Appl. Mech. 47, 81–97 (2020). <https://doi.org/10.2298/TAM200117003C>
- 76. Petra´sˇ, I.: Fractional-Order Nonlinear Systems, vol. 1. Springer, Berlin (2011). [https://doi.org/10.1007/978-3-642-](https://doi.org/10.1007/978-3-642-18101-6) [18101-6](https://doi.org/10.1007/978-3-642-18101-6)
- 77. Nayfeh, A.H., Mook, D.T.: Nonlinear Oscillations. Wiley (1995). <https://doi.org/10.1002/9783527617586>
- 78. Yin, J., Ruzzene, M., Wen, J., Yu, D., Cai, L., Yue, L.: Band transition and topological interface modes in 1D elastic phononic crystals. Sci. Rep. (2018). [https://doi.org/10.1038/](https://doi.org/10.1038/s41598-018-24952-5) [s41598-018-24952-5](https://doi.org/10.1038/s41598-018-24952-5)
- 79. Rossikhin, Y.A., Shitikova, M.V., Shcheglova, T.: Forced vibrations of a nonlinear oscillator with weak fractional

- damping. J. Mech. Mater. Struct. 4, 1619–1636 (2009). <https://doi.org/10.2140/jomms.2009.4.1619>
- 80. Bagley, R.L., Calico, R.A.: Fractional order state equations for the control of viscoelasticallydamped structures. J. Guid. Control Dyn. 14, 304–311 (1991). [https://doi.org/10.2514/](https://doi.org/10.2514/3.20641) [3.20641](https://doi.org/10.2514/3.20641)
- 81. Zaslavsky, G.M., Stanislavsky, A.A., Edelman, M.: Chaotic and pseudochaotic attractors of perturbed fractional oscillator. Chaos (2006). <https://doi.org/10.1063/1.2126806>
- 82. Heymans, N., Podlubny, I.: Physical interpretation of initial conditions for fractional differential equations with Riemann–Liouville fractional derivatives. Rheol. Acta 45, 765–771 (2006). [https://doi.org/10.1007/s00397-005-0043-](https://doi.org/10.1007/s00397-005-0043-5) [5](https://doi.org/10.1007/s00397-005-0043-5)
- 83. Naber, M.: Linear fractionally damped oscillator. Int. J. Differ. Equ. (2010). <https://doi.org/10.1155/2010/197020>
- 84. Li, C., Qian, D., Chen, Y.: On Riemann–Liouville and Caputo derivatives. Discrete Dyn. Nat. Soc. (2011). [https://](https://doi.org/10.1155/2011/562494) [doi.org/10.1155/2011/562494](https://doi.org/10.1155/2011/562494)
- 85. Rossikhin, Y.A., Shitikova, M.V.: On fallacies in the decision between the Caputo and Riemann–Liouville fractional derivatives for the analysis of the dynamic response of a nonlinear viscoelastic oscillator. Mech. Res. Commun. 45, 22–27 (2012). [https://doi.org/10.1016/j.mechrescom.2012.](https://doi.org/10.1016/j.mechrescom.2012.07.001) [07.001](https://doi.org/10.1016/j.mechrescom.2012.07.001)
- 86. Xu, Y., Li, Y., Liu, D.: A method to stochastic dynamical systems with strong nonlinearity and fractional damping. Nonlinear Dyn. 83, 2311–2321 (2016). [https://doi.org/10.](https://doi.org/10.1007/s11071-015-2482-6) [1007/s11071-015-2482-6](https://doi.org/10.1007/s11071-015-2482-6)
- 87. Rossikhin, Y.A., Shitikova, M.V.: Application of fractional calculus for dynamic problems of solid mechanics: novel trends and recent results. Appl. Mech. Rev. 63, 1–52 (2010). <https://doi.org/10.1115/1.4000563>
- 88. Caputo, M.: Vibrations of an infinite viscoelastic layer with a dissipative memory. J. Acoust. Soc. Am. 56, 897–904 (1974). <https://doi.org/10.1121/1.1903344>
- 89. Chen, Y., Kadic, M., Wegener, M.: Roton-like acoustical dispersion relations in 3D metamaterials. Nat. Commun. (2021). <https://doi.org/10.1038/s41467-021-23574-2>
- 90. Martı´nez, J.A.I., Groß, M.F., Chen, Y., Frenzel, T., Laude, V., Kadic, M., et al.: Experimental observation of roton-like dispersion relations in metamaterials. Sci. Adv. (2021). <https://doi.org/10.1126/sciadv.abm2189>
- 91. Shen, Y., Yang, S., Xing, H., Gao, G.: Primary resonance of Duffing oscillator with fractional-order derivative. Commun. Nonlinear Sci. Numer. Simul. 17, 3092–3100 (2012). <https://doi.org/10.1016/j.cnsns.2011.11.024>
- 92. Zhao, C., Zhang, K., Zhao, P., Deng, Z.: Elastic wave propagation in nonlinear two-dimensional acoustic metamaterials. Nonlinear Dyn. (2022). [https://doi.org/10.1007/](https://doi.org/10.1007/s11071-022-07259-z) [s11071-022-07259-z](https://doi.org/10.1007/s11071-022-07259-z)

Publisher's Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

![](_page_25_Picture_32.jpeg)