## Theory of Micropolar Fluids

## A. CEMAL ERINGEN

Communicated by T. Y. THOMAS

**Abstract.** Equations of motion, constitutive equations and boundary conditions are derived for a class of fluids named micropolar fluids. These fluids respond to micro-rotational motions and spin inertia and therefore, can support couple stress and distributed body couples. Thermodynamical restrictions are studied in detail and field equations are obtained for the density, velocity vector and micro-rotation vector. The system is solved for a channel flow exhibiting certain interesting phenomena.

1. Introduction. The theory of microfluids introduced by Eringen [1], [2] deals with a class of fluids which exhibit certain microscopic effects arising from the local structure and micro-motions of the fluid elements. These fluids can support stress moments and body moments and are influenced by the spin inertia. The theory of microfluids are, however, too complicated even in the case of constitutively linear theory and the underlying mathematical problem is not easily amenable to the solution of non-trivial problems in this field.

A subclass of these fluids is the *micropolar fluids* which exhibit the microrotational effects and micro-rotational inertia. This class of fluids possesses certain simplicity and elegance in their mathematical formulation which should appeal to mathematicians. The micropolar fluids can support couple stress and body couples only. Physically they may represent adequately the fluids consisting of bar-like elements. Certain anisotropic fluids, *e.g.* liquid crystals which are made up of dumbbell molecules, are of this type. In fact, animal blood happens to fall into this category. Other polymeric fluids and fluids containing certain additives may be represented by the mathematical model underlying micropolar fluids.

Recent experiments [3], [4] with fluids containing extremely small amount of polymeric additives indicate that the skin friction near a rigid body in such fluids are considerably lower (up to 30–35%) than the same fluids without additives. The classical Navier–Stokes theory is incapable of predicting these findings since it contains no mechanism to explain this new physical phenomena. At the Naval Hydrodynamic Conference at Bergen last year, September 1964, the author [5] suggested that the microfluid theory may contain just the right mechanism.

anism required. While it is too early to make the final conclusion on this question, the problem of channel flow worked out in this paper is a positive indication of this conjecture.

In Arts. 2 and 3 we give a resume of the theory of microfluids formulated in Ref. 1. The theory of micropolar fluids is developed in Art. 4. In Art. 5 the thermodynamics of such fluids are studied and the restriction on the viscosity coefficients are obtained. In Art. 6 we give the field equations and boundary conditions and present the similarity parameters. The last section of the paper (Art. 7) is devoted to the solution of the problem of channel flow of micropolar fluids.

2. Laws of motion. In our previous work, Ref. 1, we formulated a theory of microfluids whose behavior is governed by a set of laws of motion and a constitutive theory. Some of these laws are new to the mechanics of continua and others are modifications and extension of the well-known principles of mechanics. These are

Conservation of mass:

(2.1) 
$$\frac{\partial \rho}{\partial t} + (\rho v_k)_{,k} = 0 \quad \text{in} \quad \mathfrak{V};$$

Balance of momentum:

(2.2) 
$$t_{kl,k} + \rho(f_l - \dot{v}_l) = 0 \text{ in } V;$$

Balance of first stress moments:

(2.3) 
$$t_{ml} - s_{ml} + \lambda_{klm,k} + \rho(l_{lm} - \dot{\sigma}_{lm}) = 0 \quad \text{in} \quad \forall;$$

Conservation of energy:

(2.4) 
$$\rho \dot{\epsilon} = t_{kl} v_{l,k} + (s_{kl} - t_{kl}) v_{kl} + \lambda_{klm} v_{ml,k} + q_{k,k} + \rho h \quad \text{in} \quad \nabla;$$

![](_page_1_Picture_13.jpeg)

FIGURE 1. Coordinates

Principle of entropy:

(2.5) 
$$\rho\Gamma \equiv \rho\dot{\eta} - \left(\frac{q_k}{\theta}\right)_k - \frac{\rho h}{\theta} \geq 0 \quad \text{in } \quad \forall;$$

Inequality (2.5) is axiomatized to be valid for all independent processes. In these equations

 $\rho$  = mass density,

 $v_k$  = velocity vector,

 $t_{kl}$  = stress tensor,

 $f_i$  = body force per unit mass,

 $s_{kl} = \text{micro-stress average},$ 

 $\lambda_{klm}$  = the first stress moments,

 $l_{lm}$  = the first body moments per unit mass,

 $\dot{\sigma}_{lm}$  = inertial spin,

 $\epsilon$  = internal energy density per unit mass,

 $\nu_{kl}$  = gyration tensor,

 $q_k$  = heat vector directed outward of the body,

h = heat source per unit mass,

 $\eta$  = entropy per unit mass,

 $\theta$  = temperature.

Throughout this paper we employ a rectangular coordinate system  $x_1$ ,  $x_2$ ,  $x_3$  and the Eulerian representation, Fig. 1. All vectors and tensors are referred to a set of spatial rectangular coordinates so that no need arises for differentiating their covariant, contravariant and mixed components from each other. An index followed by a comma represents partial differentiation with respect to space variable  $x_k$  and a superposed dot indicates material differentiation, e.g.

$$(2.6) v_{k,l} \equiv \frac{\partial v_k}{\partial x_l}, \dot{\nu}_k = \frac{\partial \nu_k}{\partial t} + \nu_{k,l} v_l.$$

Here and throughout this paper repeated indices denote summation over the range (1, 2, 3).

For the spin inertia we have the kinematical relation (Ref. 1, eq. 5.5),

$$\dot{\sigma}_{kl} \equiv i_{ml}(\dot{\nu}_{mk} + \nu_{nk}\nu_{mn}),$$

where  $i_{mi} = i_{lm}$  is called micro-inertia moments and according to the law of conservation of micro-inertia, they satisfy the partial differential equations (Ref. 1, eq. 2.16),

(2.8) 
$$\frac{\partial i_{km}}{\partial t} + i_{km,r} v_r - i_{rm} v_{rk} - i_{kr} v_{rm} = 0, \text{ in } v.$$

Expressions (2.1) to (2.5) and (2.8) are valid at all parts of the body B having volume  $\mathcal{U}$  and surface S, except at finite number of discontinuity surfaces, lines

and points. At the surface S of the body we have the boundary conditions,

$$(2.9) t_{kl}n_k = t_l , on S,$$

$$\lambda_{klm}n_k=\lambda_{lm}, \quad \text{on} \quad S,$$

where **n** is the exterior normal to S and  $t_l$  and  $\lambda_{lm}$  are respectively the surface tractions and surface moments acting on S.

We note that while equations (2.1), (2.2) are well-known from the classical continuum mechanics, equations (2.3), (2.4) and (2.8) are new. The first two of these equations (eq. 2.3 and 2.4) reduct to classical results [6],

(2.11) 
$$t_{kl} = t_{lk},$$

$$\rho \dot{\epsilon} = t_{kl} v_{l,k} + q_{k,k} + \rho h,$$

when  $\lambda_{klm} = l_{lm} = \nu_{lm} = 0$ . Equation (2.3) is, however, much more general than (2.11)<sub>1</sub> and is the result of the new principle of balance of first stress moments as against the limited axiom of balance of moment of momentum of the classical theory. Equations (2.8) have, of course, no counterpart in the classical continuum theory.

If we exclude the heat conduction phenomena, in the present theory, the determination of motion requires the determination of the nineteen unknowns,

(2.12) 
$$\rho(\mathbf{x}, t), \quad i_{km}(\mathbf{x}, t), \quad v_k(\mathbf{x}, t), \quad v_{kl}(\mathbf{x}, t),$$

as against the four unknowns  $v_k$  and  $\rho$  of the classical theory.

3. Constitutive equations of microfluids. In Ref. 1 we also gave a set of constitutive equations for microfluids. For a non-heat conducting medium these are expressed as relations between  $(t_{kl}, s_{kl}, \lambda_{klm})$  and the *objective* quantities

$$(3.1) d_{kl} \equiv \frac{1}{2} (v_{kl} + v_{l,k}),$$

$$(3.2) b_{kl} \equiv v_{k,l} + \nu_{kl} ,$$

$$a_{klm} \equiv \nu_{kl,m} ,$$

and  $\rho$  and  $i_{km}$ . Of these **d** is the rate of deformation tensor and **b** and **a** are two new tensors respectively called *micro-deformation rate tensor* of second order and *gyration gradient*. Both of these latter quantities transform like absolute tensors under any rigid motion of the frame of reference, *i.e.* they are objective. Hence they are suitable for use as the independent constitutive variables.

For the present work we produce here only the results of the linear constitutive theory of micro-isotropic fluids (i.e.  $i_{km} = i\delta_{km}$ ). For the nonlinear theories the reader is referred to Ref. 1.

(3.4) 
$$\mathbf{t} = [-\pi + \lambda \operatorname{tr} \mathbf{d} + \lambda_0 \operatorname{tr} (\mathbf{b} - \mathbf{d})] \mathbf{I} + 2\mu \mathbf{d} + 2\mu_0 (\mathbf{b} - \mathbf{d}) + 2\mu_1 (\mathbf{b}^T - \mathbf{d}),$$
(3.5) 
$$\mathbf{s} = [-\pi + \lambda \operatorname{tr} \mathbf{d} + \eta_0 \operatorname{tr} (\mathbf{b} - \mathbf{d})] \mathbf{I} + 2\mu \mathbf{d} + \zeta_1 (\mathbf{b} - \mathbf{b}^T - 2 \mathbf{d}),$$

(3.6) 
$$\lambda_{klm} = (\gamma_1 a_{mrr} + \gamma_2 a_{rmr} + \gamma_3 a_{rrm}) \ \delta_{kl} + (\gamma_4 a_{lrr} + \gamma_5 a_{rlr} + \gamma_6 a_{rrl}) \delta_{km}$$
$$+ (\gamma_7 a_{krr} + \gamma_8 a_{rkr} + \gamma_9 a_{rrk}) \delta_{lm}$$
$$+ \gamma_{10} a_{klm} + \gamma_{11} a_{kml} + \gamma_{12} a_{lkm} + \gamma_{13} a_{mkl} + \gamma_{14} a_{lmk} + \gamma_{15} a_{mlk} ,$$

where **I** is the unit tensor and  $\lambda$ ,  $\lambda_0$ ,  $\mu$ ,  $\mu_0$ ,  $\mu_1$ ,  $\eta_0$ ,  $\zeta_1$ , and  $\gamma_1$  to  $\gamma_{15}$  are the viscosity coefficients. Also tr denotes trace and a superscript T indicates transpose, e.g.,

$$\mathbf{I} = egin{bmatrix} 1 & 0 & 0 \ 0 & 1 & 0 \ 0 & 0 & 1 \end{bmatrix}, \qquad \mathrm{tr} \; b_{kl} \equiv b_{kk} \;, \qquad b_{kl}^{\, T} \equiv b_{lk} \;.$$

The equation of state for these fluids can be shown to have the form (For a detailed treatment on thermodynamics see Ref. 1. For the thermodynamics of micropolar fluids see section 5 below.)

$$\epsilon = \epsilon(\eta, \, \rho^{-1}),$$

so that the thermodynamic pressure  $\pi$  and the temperature  $\theta$  are defined by

(3.8) 
$$\pi \equiv -\frac{\partial \epsilon}{\partial \rho^{-1}} \bigg|_{\eta,i} , \qquad \theta \equiv \frac{\partial \epsilon}{\partial \eta} \bigg|_{\rho,i} .$$

For non-heat conducting media, the nineteen unknowns (2.12) must satisfy the thirteen partial differential equations obtained by substituting (2.7) and (3.4) to (3.6) into (2.1) to (2.3) and the six equations (2.8) so that the number of independent equations are equal to that of unknowns. Equations so obtained are nonlinear in the inertia terms and highly complicated otherwise. The purpose of the present paper is to give a new theory applicable to a large class of fluids falling within the framework of the microfluid theory presented above, however possessing adequate mathematical simplicity to make the engineering problems tractable.

4. Micropolar fluids. A microfluid will be called micropolar if for all motions

$$\lambda_{klm} = -\lambda_{kml} , \quad \nu_{kl} = -\nu_{lk} .$$

Micropolar fluids exhibit only micro-rotational effects and can support surface and body couples. Fluid points contained in a small volume element, in addition to its usual rigid motion, can rotate about the centroid of the volume element in an average sense described by the gyration tensor  $\mathbf{v}$ . No micro-stretch of particles are, however, allowed ( $\nu_{kl}$  is skew-symmetric). Thus micropolar fluids consist of a kind of dumbbell molecules. (The present work complements our previous work, Ref. 2, on a similar subject.)

We now proceed to show that a class of microfluids satisfying (4.1) exists. The theory of such fluids is the subject of the remainder of this paper.

Condition (4.1)<sub>2</sub> implies that

$$a_{klm} = -a_{lkm}.$$

Calculating  $\lambda_{klm}$  and  $-\lambda_{kml}$  from (3.6) and equating them and using (4.1)<sub>2</sub> and (4.2) we find that if (4.1) is to be valid for all motions we must have

(4.3) 
$$\begin{aligned} \gamma_1 - \gamma_2 + \gamma_4 - \gamma_5 &= 0, \\ \gamma_7 - \gamma_8 &= 0, \\ \gamma_{10} - \gamma_{12} + \gamma_{11} - \gamma_{13} &= 0, \end{aligned}$$

so that

$$(4.4) \qquad \lambda_{klm} = (\gamma_1 - \gamma_2)(a_{mrr} \ \delta_{kl} - a_{lrr} \ \delta_{km}) + (\gamma_{10} - \gamma_{12})(a_{klm} - a_{kml}) + (\gamma_{14} - \gamma_{15})a_{lmk}.$$

In view of skew-symmetry conditions (4.1) the independent number of  $\nu_{kl}$  and  $\lambda_{klm}$  are respectively 3 and 9. Thus it is natural to introduce two new sets of variables  $\nu_k$  and  $m_{kl}$  by

$$(4.5) \nu_r \equiv \frac{1}{2} \epsilon_{rkl} \nu_{kl} , \nu_{kl} = \epsilon_{rkl} \nu_r ,$$

$$(4.6) m_{kr} \equiv -\epsilon_{rlm} \lambda_{klm} , \lambda_{klm} = -2\epsilon_{lmr} m_{kr} ,$$

where  $\epsilon_{klm}$  is the alternating tensor. Here the axial vector  $\nu_r$  will be called *micro-rotation* vector and  $m_{kr}$  the *couple stress* tensor. The sign convention for  $m_{kr}$  is identical to that of the stress tensor and is shown on Fig. 2. Similarly we intro-

![](_page_5_Picture_12.jpeg)

FIGURE 2. Positive Couple Stress Components

duce micro-inertial rotation  $\dot{\sigma}_k$  and body couple  $l_k$  by (The couple stress and body couple introduced here are identical to those defined in Ref. 6, Art. 31.)

$$\dot{\sigma}_r \equiv -\epsilon_{rkl}\dot{\sigma}_{kl} , \qquad \dot{\sigma}_{kl} = -2\epsilon_{rkl}\dot{\sigma}_r ,$$

$$(4.8) l_r \equiv -\epsilon_{rkl}l_{kl} , l_{kl} = -2\epsilon_{rkl}l_r .$$

Now multiply (2.3) by  $\epsilon_{rlm}$  and use (4.5) to (4.8) Since  $s_{ml} = s_{lm}$  this results in

$$(4.9) m_{rk,r} + \epsilon_{klr} t_{lr} + \rho(l_k - \dot{\sigma}_k) = 0.$$

Similarly using (4.5) and (4.6) in (2.4) we may replace the equation of energy by

$$(4.10) \rho\dot{\epsilon} = t_{kl}(v_{l,k} - \epsilon_{klr}v_r) + m_{kl}v_{l,k} + q_{k,k} + \rho h.$$

An alternative but useful form to (4.10) is obtained by using

$$v_{k,l} = d_{kl} + \omega_{kl} = d_{kl} - \epsilon_{klm}\omega_m,$$

where

$$(4.11) \omega_{kl} = \frac{1}{2}(v_{k,l} - v_{l,k}),$$

is the classical spin tensor and  $\omega_r$  is the vorticity vector. Hence,

$$(4.12) \rho \dot{\epsilon} = t_{kl} d_{lk} + t_{kl} \epsilon_{klr} (\omega_r - \nu_r) + m_{kl} \nu_{l,k} + q_{k,k} + \rho h.$$

The boundary conditions (2.10) are similarly replaced by

$$(4.13) m_{rk}n_r = m_k , on S,$$

where  $m_k \equiv -\frac{1}{4}\epsilon_{klm}\lambda_{lm}$  is the surface couple vector acting on S. Next we turn our attention to the constitutive equations. Equation (3.4) can be put into the form

$$(4.14) t_{kl} = (-\pi + \lambda_{r} v_{r,r}) \delta_{kl} + \mu_{r} (v_{k,l} + v_{l,k}) + \kappa_{r} (v_{l,k} - \epsilon_{klr} v_{r}),$$

where we set

$$(4.15) \mu + \mu_0 - \mu_1 \equiv \mu_r , 2(\mu_1 - \mu_0) \equiv \kappa_r .$$

An alternative form to (4.14) is

$$(4.16) t_{kl} = (-\pi + \lambda_v d_{rr}) \delta_{kl} + (2\mu_v + \kappa_v) d_{kl} + \kappa_v \epsilon_{klr} (\omega_r - \nu_r).$$

If we multiply (4.4) by  $\epsilon_{rlm}$  and use (4.5) and (4.6) this equation can be transformed into

$$(4.17) m_{kl} = \alpha_{\nu} \nu_{r,r} \, \delta_{kl} + \beta_{\nu} \nu_{k,l} + \gamma_{\nu} \nu_{l,k} \,,$$

where

(4.18) 
$$\alpha_{\tau} \equiv 2(\gamma_{12} - \gamma_{10}), \qquad \beta_{\tau} \equiv 2(\gamma_{2} - \gamma_{1}), \\ \gamma_{\tau} \equiv 2(\gamma_{1} - \gamma_{2} + \gamma_{10} - \gamma_{12} - \gamma_{14} + \gamma_{15}).$$

We now substitute (4.16) and (4.17) into (4.12) to calculate the rate of internal energy.

(4.19) 
$$\rho \dot{\epsilon} = -\pi \ d_{kk} + \lambda_{\nu} \ d_{ll} \ d_{kk} + (2\mu_{\nu} + \kappa_{\nu}) \ d_{kl} \ d_{lk} + 2\kappa_{\nu}(\omega_{k} - \nu_{k})(\omega_{k} - \nu_{k}) + \alpha_{\nu}\nu_{k,l}\nu_{l,l} + \beta_{\nu}\nu_{k,l}\nu_{l,k} + \gamma_{\nu}\nu_{l,k}\nu_{l,k} + q_{k,h} + \rho h.$$

The assumptions of micro-isotropy and the skew-symmetry of  $\nu_{kl}$  when used in (2.8) gives

(4.20) 
$$\frac{Di}{Dt} = 0$$
, or,  $i = \text{const} = j/2$ , on material lines.

Finally we give an expression of the inertial rotation

$$\dot{\sigma}_r = -\epsilon_{rkl}\dot{\sigma}_{kl} = -\epsilon_{rkl}i(\dot{\nu}_{lk} + \nu_{nk}\nu_{ln});$$

using (4.1)<sub>2</sub> this reduces to

$$\dot{\sigma}_k = \dot{j}\dot{\nu}_k .$$

Summarizing the results: Basic equations of motion (2.1), (2.2), (4.9) energy (4.10) and the constitutive equations (4.14) and (4.17) constitute a proof that the micropolar fluids may exist as a subclass of microfluids whenever (4.3) is satisfied. The thermodynamic restrictions on the viscosities are studied in the following article.

5. Thermodynamics of micropolar fluids. In this paper we are primarily concerned with the non-heat conducting microfluids. In accordance with the principle of equipresence (Ref. 6, Art. 44) every constitutive dependent variable must be a function of the same list of variables until contrary is shown to be the case. In harmony with this practice then the equation of state of micropolar fluids must have the general form

(5.1) 
$$\epsilon = \epsilon(\eta, \rho^{-1}, d_{kl}, b_{kl}, a_{klm}).$$

The dependence on i is dropped since i = const. along a material line. We proceed to show that the dependence of  $\epsilon$  on d, b and a can be eliminated on the ground of the second law of thermodynamics (2.5). Eliminating  $(q_{k,k} + \rho h)/\theta$  between (4.10) and (2.5) we get

$$(5.2) \rho\left(\dot{\eta}-\frac{\dot{\epsilon}}{\theta}\right)+\frac{1}{\theta}t_{kl}(v_{l,k}-\epsilon_{klr}v_r)+\frac{1}{\theta}m_{kl}v_{l,k}+\frac{q_k\theta_{,k}}{\theta^2}\geq 0.$$

Using (5.1) this becomes

$$\rho\Gamma \equiv \rho\dot{\eta}\left(1 - \frac{1}{\theta}\frac{\partial\epsilon}{\partial\eta}\right) + \frac{1}{\theta}\frac{\partial\epsilon}{\partial\rho^{-1}}\frac{\dot{\rho}}{\rho} - \frac{\rho}{\theta}\left(\frac{\partial\epsilon}{\partial d_{kl}}d_{kl} + \frac{\partial\epsilon}{\partial b_{kl}}\dot{b}_{kl} + \frac{\partial\epsilon}{\partial a_{klm}}\dot{a}_{klm}\right) \\
+ \frac{1}{\theta}t_{kl}(v_{l,k} - \epsilon_{kl}, v_r) + \frac{1}{\theta}m_{kl}v_{l,k} + \frac{q_k\theta_{,k}}{\theta^2} \geq 0.$$

This inequality must be satisfied for all independent changes of  $\dot{\eta}$ ,  $\dot{\mathbf{d}}$ ,  $\dot{\mathbf{b}}$ ,  $\dot{\mathbf{a}}$  and  $\theta_{,k}$ . Since it is linear in these quantities, it cannot be maintained for all independent variations of these quantities unless

(5.3) 
$$\frac{\partial \epsilon}{\partial d_{(kl)}} = \frac{\partial \epsilon}{\partial b_{kl}} = 0, \qquad \frac{\partial \epsilon}{\partial a_{klm}} = 0,$$

$$(5.4) q_k = 0,$$

(5.5) 
$$\theta = \frac{\partial \epsilon}{\partial \eta} \bigg|_{\theta^{-1}},$$

(5.6) 
$$\rho\Gamma \equiv -\frac{1}{\theta} \frac{\partial \epsilon}{\partial \rho^{-1}} d_{kk} + \frac{1}{\theta} t_{kl} (v_{l,k} - \epsilon_{klr} \nu_r) + \frac{1}{\theta} m_{kl} \nu_{l,k} \geq 0,$$

where through (2.1) we replace  $\dot{\rho}$  by  $-\rho d_{kk}$ . In (5.3) a parenthesis enclosing indices indicates the symmetric part, e.g.

$$\frac{\partial \epsilon}{\partial d_{(kl)}} \equiv \frac{1}{2} \left( \frac{\partial \epsilon}{\partial d_{kl}} + \frac{\partial \epsilon}{\partial d_{lk}} \right).$$

Since any function  $\epsilon$  of a symmetric tensor  $d_{kl}$  can always be expressed as a function  $d_{(kl)}$  we see from (5.3) that  $\epsilon$  must be independent of  $\mathbf{d}$ ,  $\mathbf{b}$  and  $\mathbf{a}$ . Using (4.16) and (4.17) the inequality (5.6) is further reduced to

(5.7) 
$$\rho\Gamma \equiv \frac{1}{\theta} \left[ \lambda_{\nu} d_{kk} d_{ll} + (2\mu_{\nu} + \kappa_{\nu}) d_{kl} d_{lk} + 2\kappa_{\nu} (\omega_{k} - \nu_{k}) (\omega_{k} - \nu_{k}) + \alpha_{\nu} \nu_{k,k} \nu_{l,l} + \beta_{\nu} \nu_{k,l} \nu_{l,k} + \gamma_{\nu} \nu_{l,k} \nu_{l,k} \right] \geq 0.$$

We have thus proved

**Theorem 1.** The necessary and sufficient conditions for the local Clausius–Duhem inequality (2.5) to be satisfied for all independent processes are: (i)  $\epsilon$  must be independent of  $\mathbf{d}$ ,  $\mathbf{b}$  and  $\mathbf{a}$ ; (ii) temperature  $\theta$  and pressure  $\pi$  must be defined by (3.8) and (iii) inequality (5.7) must be satisfied for all possible motions.

We now investigate the restrictions emanating from the satisfaction of (5.7) for all independent  $\mathbf{d}$ ,  $\boldsymbol{\omega} - \boldsymbol{v}$  and  $\nu_{l,k}$ . It is clear that for all values of  $\mathbf{d}$  irrespective of  $\boldsymbol{\omega} - \boldsymbol{v}$  and  $\nu_{l,k}$  we must have the classical conditions

$$\frac{1}{\theta} (3\lambda_v + 2\mu_v + \kappa_v) \ge 0, \qquad \frac{\mu_v}{\theta} \ge 0,$$

which are necessary and sufficient for the non-negativeness of the terms containing d. Similarly we must also have

$$\kappa_n/\theta \geq 0$$

in order that  $\rho\Gamma$  be non-negative for all values of  $\omega - \nu$ . Finally the conditions, in  $\alpha_{\nu}$ ,  $\beta_{\nu}$  and  $\gamma_{\nu}$  are obtained by making the last three terms in (5.7) non-negative, *i.e.* 

$$\frac{1}{\theta} \left( \alpha_{v} \nu_{k,k} \nu_{l,l} + \beta_{v} \nu_{k,l} \nu_{l,k} + \gamma_{v} \nu_{l,k} \nu_{l,k} \right) \ge 0.$$

This expression can be written as a quadratic form in a nine dimensional space, i.e.

$$a_{ij}y_iy_j \geq 0, \qquad a_{ij} = a_{ji},$$

where

$$y_1 \equiv \nu_{1,1}$$
,  $y_2 \equiv \nu_{2,2}$ ,  $y_3 \equiv \nu_{3,3}$ ,  $y_4 \equiv \nu_{1,2}$ ,  $y_5 \equiv \nu_{2,1}$ ,  $y_6 \equiv \nu_{2,3}$ ,  $y_7 \equiv \nu_{3,2}$ ,  $y_8 \equiv \nu_{3,1}$ ,  $y_9 \equiv \nu_{1,3}$ ,  $a_{11} = a_{22} = a_{33} = \frac{1}{\theta} (\alpha_v + \beta_v + \gamma_v)$ ,  $a_{12} = a_{13} = \alpha_{23} = \alpha_v/\theta$ ,  $a_{45} = a_{67} = a_{89} = \beta_v/\theta$ ,  $a_{44} = a_{55} = a_{66} = a_{77} = a_{88} = a_{99} \equiv \gamma_v/\theta$ , all other  $a_{ij} = 0$ .

The characteristic values  $a_i$  of  $a_{ij}$  are obtained by solving the equation

$$\det (a_{ij} - a \delta_{ij}) = 0.$$

The nine roots for a are

$$a_1=a_2=a_3=\gamma_{
m v}-\beta_{
m v}$$
 ,  $a_4=a_5=a_6=a_7=a_8=\gamma_{
m v}+\beta_{
m v}$  ,  $a_9=3\alpha_{
m v}+\beta_{
m v}+\gamma_{
m v}$  .

In order that the  $a_{ij}y_iy_i \geq 0$  to be satisfied for all  $y_i$  we must have

$$(\gamma_{\mathfrak{v}} - \beta_{\mathfrak{v}})/\theta \geq 0, \qquad (\gamma_{\mathfrak{v}} + \beta_{\mathfrak{v}})/\theta \geq 0, \qquad (3\alpha_{\mathfrak{v}} + \beta_{\mathfrak{v}} + \gamma_{\mathfrak{v}})/\theta \geq 0.$$

Hence

**Theorem 2.** The necessary and sufficient conditions for the inequality (5.7) to be satisfied for all motion are

(5.8) 
$$(3\lambda_{\nu} + 2\mu_{\nu} + \kappa_{\nu})/\theta \ge 0, \qquad \mu_{\nu}/\theta \ge 0, \qquad \kappa_{\nu}/\theta \ge 0,$$

$$(3\alpha_{\nu} + 2\gamma_{5})/\theta \ge 0, \qquad -\gamma_{\nu}/\theta \le \beta_{\nu}/\theta \le \gamma_{\nu}/\theta, \qquad \gamma_{\nu}/\theta \ge 0.$$

These are the conditions on the viscosity coefficients. In general we also have  $\theta > 0$ .

**Corollary.** The necessary and sufficient condition for the local Clausius- Duhem inequality to be satisfied for all independent processes are (5.8).

This result is clear as a combination of Theorems 1 and 2.

6. Field equations. The differential equations satisfied by  $\rho$ ,  $v_k$  and  $v_k$  are given by (2.1) and combinations of (4.14) and (4.17) with (2.2) and (4.9), *i.e.*,

(6.1) 
$$\frac{\partial \rho}{\partial t} + (\rho v_k)_{,k} = 0,$$

$$(6.2) -\pi_{.k} + (\lambda_{r} + \mu_{r})v_{l.kl} + (\mu_{r} + \kappa_{r})v_{k.ll} + \kappa_{r}\epsilon_{klm}\nu_{m.l} + \rho(f_{k} - \dot{v}_{k}) = 0,$$

(6.3) 
$$(\alpha_* + \beta_*) \nu_{l,kl} + \gamma_{\nu} \nu_{k,ll} + \kappa_{\nu} \epsilon_{klm} \nu_{m,l} - 2\kappa_{\nu} \nu_k + \rho(l_k - j \dot{\nu}_k) = 0,$$

where a superposed dot indicates the material differentiation, i.e.

(6.4) 
$$\dot{v}_k \equiv \frac{\partial v_k}{\partial t} + v_{k,l} v_l , \qquad \dot{v}_k \equiv \frac{\partial v_k}{\partial t} + v_{k,l} v_l .$$

The partial differential equations (6.1) to (6.3) are the field equations of the micropolar fluids. Under appropriate initial and boundary conditions they are capable of predicting the behavior of such fluids in full. The existence and uniqueness theorems must of course be proven in order for the underlying mathematical problem to be "well-posed." Presently we only suggest some initial and boundary conditions.

Initial conditions at t = 0

(6.5) 
$$\rho(\mathbf{x}, 0) = \rho_0(\mathbf{x}),$$

$$v_k(\mathbf{x}, 0) = v_{0k}(\mathbf{x}),$$

$$v_k(\mathbf{x}, 0) = v_{0k}(\mathbf{x}),$$

where  $\rho_0$ ,  $\mathbf{v}_0$  and  $\mathbf{v}_0$  are to be prescribed throughout.

Boundary conditions at a rigid boundary

(6.6) 
$$\mathbf{v}(\mathbf{x}_B, t) = \mathbf{v}_B,$$

$$\mathbf{v}(\mathbf{x}_B, t) = \mathbf{v}_B,$$

where  $\mathbf{x}_B$  is a point on a rigid boundary having prescribed velocity  $\mathbf{v}_B$  and prescribed micro-rotation vector  $\mathbf{v}_B$ . Conditions (6.6) express the assumption of adherence of the fluid to the solid boundary.

Boundary conditions involving prescribed forces and moments

In place of (6.6) we may prescribe boundary forces and moments as expressed by (2.9) and (4.13), *i.e.* 

$$t_{kl}n_k = t_l,$$

$$m_{kl}n_k = m_l.$$

Other types of mixed conditions are possible. The final judgement on these questions requires theoretical work on the question of existence and uniqueness and experimental work on the flow conditions.

Equations (6.1) to (6.3) are expressed in rectangular coordinates. Vector expressions of these equations useful for work in other systems of coordinates are

(6.8) 
$$\frac{\partial \rho}{\partial t} + \nabla \cdot (\rho \mathbf{v}) = 0,$$

(6.9) 
$$(\lambda_v + 2\mu_v + \kappa_v) \nabla \nabla \cdot \mathbf{v} - (\mu_v + \kappa_v) \nabla \times \nabla \times \mathbf{v} + \kappa_v \nabla \times \mathbf{v} - \nabla \pi + \rho \mathbf{f}$$

$$= \rho \left[ \frac{\partial \mathbf{v}}{\partial t} - \mathbf{v} \times (\nabla \times \mathbf{v}) + \frac{1}{2} \nabla (\mathbf{v}^2) \right],$$

(6.10) 
$$(\alpha_n + \beta_n + \gamma_n) \nabla \nabla \cdot \mathbf{v} - \gamma_n \nabla \times \nabla \times \mathbf{v} + \kappa_n \nabla \times \mathbf{v} - 2\kappa_n \mathbf{v} + \rho \mathbf{1} = \rho \ddot{\mathbf{v}},$$

where  $\dot{\mathbf{v}}$  does not possess as simple an expression as  $\dot{\mathbf{v}}$ . There is, however, no particular difficulty in calculating it through its tensorial form, cf. [2, 17, also Appendix].

We note that for  $\kappa_{\bullet} = \alpha_{\bullet} = \beta_{\bullet} = \gamma_{\bullet} = 0$  and vanishing 1 through (6.3) we get  $\nu_{k} = 0$  and (6.2) reduce to the celebrated Navier–Stokes equations. Note also that for  $\kappa_{\bullet} = 0$  the velocity  $\mathbf{v}$  and the micro-rotation are uncoupled and the global motion is unaffected by the micro-rotations.

The classical Stokes conditions  $3\lambda_{\nu} + 2\mu_{\nu} = 0$  for the micropolar fluids have the corresponding form

$$(6.11) 3\lambda_{\nu} + 2\mu_{\nu} + \kappa_{\nu} = 0,$$

to which we place no great faith.

For an *incompressible fluids*  $\rho = \text{const}$ ,  $\nabla \cdot \mathbf{v} = 0$  and  $\pi$  is replaced by an unknown pressure p to be determined from the boundary conditions.

The *similarity parameters* of the micropolar fluids are obtained by non-dimensionalizing equations (6.1) to (6.3). Thus let L and T be respectively some characteristic length and time and

(6.12) 
$$\bar{\mathbf{x}} \equiv \mathbf{x}/L, \qquad \bar{t} \equiv t/T, \qquad \bar{\mathbf{v}} = \mathbf{v}/v_0, \qquad \bar{\mathbf{v}} = \mathbf{v}/\nu_0,$$

$$\bar{\pi} = \pi/\pi_0, \qquad \bar{\rho} = \rho/\rho_0, \qquad \bar{\mathbf{f}} = \mathbf{f}/f_0, \qquad \bar{\jmath} = j/j_0,$$

where  $\pi_0$ ,  $\rho_0$ ,  $\nu_0$ ,  $\nu_0$ ,  $\rho_0$  and  $\rho_0$  are some reference values of  $\pi$ ,  $\rho$ ,  $|\mathbf{v}|$ ,  $|\mathbf{f}|$  and  $\rho_0$  respectively. Substituting (6.12) into (6.1) to (6.3) and using (6.4) we get the non-dimensional equations

(6.13) 
$$n_5 \frac{\partial \overline{\rho}}{\partial \overline{t}} + (\overline{\rho} \overline{v}_k)_{,k} = 0,$$

$$(6.14) n_1 \bar{v}_{1,kl} + n_2 \bar{v}_{k,ll} + n_3 \epsilon_{klm} \bar{v}_{m,l} - n_4 \bar{\pi}_{,k} + \bar{\rho} \left( n_6 \bar{f}_k - n_5 \frac{\partial \bar{v}_k}{\partial \bar{t}} - \bar{v}_{k,l} \bar{v}_l \right) = 0,$$

$$(6.15) \ m_1 \overline{\nu}_{l,kl} + m_2 \overline{\nu}_{k,ll} + m_3 \epsilon_{klm} \overline{\nu}_{m,l} - 2 m_4 \overline{\nu}_k + \overline{\rho} \overline{j} \left( m_6 \overline{l}_k - n_5 \frac{\partial \overline{\nu}}{\partial \overline{l}} - \overline{\nu}_{k,l} \overline{\nu}_l \right) = 0,$$

where

$$n_{1} \equiv (\lambda_{*} + \mu_{*})/\rho_{0}v_{0}L, \qquad n_{2} \equiv (\mu_{*} + \kappa_{*})/\rho_{0}v_{0}L, \qquad n_{3} \equiv \kappa_{*}\nu_{0}/\rho_{0}v_{0}^{2},$$

$$n_{4} \equiv \pi_{0}/\rho_{0}v_{0}^{2}, \qquad n_{5} \equiv L/Tv_{0}, \qquad n_{6} \equiv f_{0}L/v_{0}^{2},$$

$$m_{1} \equiv (\alpha_{*} + \beta_{*})/\rho_{0}j_{0}v_{0}L, \qquad m_{2} \equiv \gamma_{*}/\rho_{0}j_{0}v_{0}L, \qquad m_{3} \equiv \kappa_{*}/\rho_{0}j_{0}\nu_{0},$$

$$m_{4} \equiv \kappa_{*}L/\rho_{0}j_{0}v_{0}, \qquad m_{5} \equiv n_{5}, \qquad m_{6} \equiv l_{0}L/j_{0}\bar{\gamma}v_{0}v_{0}.$$

Of these  $n_1$ ,  $n_2$  are the reciprocal Reynolds numbers,  $n_4$ ,  $n_5$  and  $n_6$  are well-known from the Navier–Stokes theory. The present theory introduces six new numbers namely  $n_3$ ,  $m_1$ ,  $m_2$ ,  $m_3$ ,  $m_4$  and  $m_6$ . For a given fluid  $m_1$  is proportional to  $m_2$  so that the only new parameters are

(6.17) 
$$n_3 \equiv \kappa_v \nu_0 / \rho_0 v_0^2 , \qquad m_2 = \gamma_v / \rho_0 j_0 v_0 , \qquad m_4 \equiv \kappa_v L / \rho_0 j_0 v_0 ,$$

$$\bar{m}_3 = m_4 / m_3 = \nu_0 L / v_0 , \qquad m_6 = l_0 L / j_0 \bar{j} v_0 v_0 .$$

The four of these new similarity parameters represents the relative importance of rotational viscosities to the inertia terms and the fifth  $\bar{m}_3$  the relative microrotation velocity to the velocity.

Finally an *indeterminate couple stress theory of fluids* may be obtained as a special case of the theory of micropolar fluids when the microrotation is *constrained* by

$$(6.18) v_k = \omega_k.$$

The development here is parallel to the one given in [7] so that the details are omitted. In this case the stress is decomposed into two parts

$$(6.19) t_{kl} = t_{(kl)} + t_{[kl]},$$

where the symmetric part  $t_{(kl)}$  is understood to be given by (4.16) subject to (6.17) and the skew-symmetric part  $t_{(kl)}$  is calculated from (4.9) and (6.17), *i.e.*,

(6.20) 
$$t_{[kl]} = \frac{\gamma_v}{4} \left( v_{k,lnn} - v_{l,knn} \right) + \rho \left( l_{[kl]} - \frac{j}{2} \frac{D}{Dt} v_{[k,l]} \right) .$$

Using (6.18) in (2.2) we obtain the field equations of the theory.

(6.21) 
$$\left(\lambda_{\nu} + \mu_{\nu} + \frac{\kappa_{\nu}}{2} + \frac{\gamma_{\nu}}{4} \nabla^{2}\right) v_{k, lk} + \left(\mu_{\nu} + \frac{\kappa_{\nu}}{2} - \frac{\gamma_{\nu}}{4} \nabla^{2}\right) v_{l, kk}$$

$$- \pi_{,l} + \rho f_{l} + \frac{\rho}{2} \left(l_{kl,k} - l_{lk,k}\right) = \rho \dot{v}_{l} + \frac{\rho \dot{j}}{4} \left[\frac{D}{Dt} \left(v_{k,l} - v_{l,k}\right)\right]_{k},$$

where D/Dt is the material derivative operator.

7. Flow of micropolar fluids in a circular pipe. Here we give the solution of the field equations (6.8) to (6.10) for a steady motion of micropolar fluids in a circular channel. The appropriate coordinate system for this problem is the cylindrical coordinates  $(r, \theta, z)$  with z taken along the axis of the pipe. For a steady flow we seek to determine the velocity and micro-rotation velocity components

(7.1) 
$$v_r = v_\theta = 0, \qquad v_z = w(r),$$
$$v_r = v_z = 0, \qquad v_\theta = v(r).$$

Equation of continuity (6.8) is satisfied identically for  $\rho = \text{const.}$  and (6.9) and (6.10) with  $\mathbf{f} = \mathbf{1} = 0$  give  $p_{,r} = p_{,\theta} = 0$  and

$$(7.2) \qquad (\mu_{\nu} + \kappa_{\nu})(rw')' + \kappa(r\nu)' = rp_{,s},$$

(7.3) 
$$\gamma_{\nu}(\nu' + r^{-1}\nu)' - \kappa_{\nu}w' - 2\kappa_{\nu}\nu = 0,$$

where a superposed prime indicates differentiation with respect to r. We also used p to denote hydrostatic pressure in place of  $\pi$ .

From (7.2) we solve for w'. Hence

(7.4) 
$$w' = (\mu_v + \kappa_v)^{-1} \left( -\kappa_v \nu + \frac{r}{2} p_{,z} \right) + C_1 r^{-1}.$$

Next substitute w' into (7.3). This gives

(7.5) 
$$\nu'' + \frac{1}{r}\nu' - \left(k^2 + \frac{1}{r^2}\right)\nu = Pr + \frac{\kappa_*}{\gamma} \frac{C_1}{r},$$

where,

(7.6) 
$$k \equiv \left(\frac{2\mu_{\nu} + \kappa_{\nu}}{\mu_{\nu} + \kappa_{\nu}} \cdot \frac{\kappa_{\nu}}{\gamma_{\nu}}\right)^{1/2}, \qquad P \equiv \frac{\kappa_{\nu}}{2(\mu_{\nu} + \kappa_{\nu})\gamma_{\nu}} \frac{dp}{dz}.$$

The general solution of (7.5) is found to be

(7.7) 
$$\nu = AI_1(kr) + BK_1(kr) - Pk^{-2}r + \frac{\kappa_v}{\gamma k^2} \frac{C_1}{r},$$

where  $I_1(\rho)$  and  $K_1(\rho)$  are modified Bessel functions of first order and first and second kind respectively. Substituting this into (7.4), and integrating the result we obtain

(7.8) 
$$w = \kappa_{\nu}(\mu_{\nu} + \kappa_{\nu})^{-1}k^{-1}[-AI_{0}(kr) + BK_{0}(kr)]$$

$$+ \frac{1}{2}(2\mu_{\nu} + \kappa_{\nu})^{-1}p_{,z}r^{2} + \frac{2\mu_{\nu}}{2\mu_{\nu} + \kappa_{\nu}}C_{1}\log r + C,$$

where  $I_0$  and  $K_0$  are modified Bessel functions of zeroth order and first and second kind respectively A, B, C and  $C_1$  are arbitrary constants.

Both w and  $\nu$  must be bounded at r = 0. Since  $K_0(kr)$ ,  $K_1(kr)$  and  $\log r$  become infinite for r = 0 we must have  $B = C_1 = 0$ . We assume that the fluid sticks to the boundary r = a, *i.e.*,

$$(7.9) w(a) = 0, \nu(a) = 0.$$

Using (7.7) and (7.8) we determine A and C leading to the solution

(7.10) 
$$w/w_0 = 1 - \rho^2 + \frac{\kappa_v}{\mu_v + \kappa_v} \frac{1}{\lambda} \frac{I_0(\lambda)}{I_1(\lambda)} \left[ \frac{I_0(\lambda \rho)}{I_0(\lambda)} - 1 \right].$$

(7.11) 
$$\nu a/w_0 = \rho - \frac{I_1(\lambda \rho)}{I_1(\lambda)} ,$$

where

(7.12) 
$$w_0 \equiv -\frac{1}{2}a^2(2\mu_* + \kappa_*)^{-1} \frac{dp}{dz},$$

$$\rho \equiv r/a,$$

$$\lambda \equiv ka \equiv \left(\frac{2\mu_* + \kappa_*}{\mu_* + \kappa_*} \cdot \frac{\kappa_*}{\gamma_*}\right)^{1/2} a.$$

Here  $w_0$  is the maximum velocity in the classical Poiseuille flow which occurs

at r=0. The solution (7.10) goes into the classical Poiseuille flow for  $\kappa_{\nu}=0$  and (7.11) gives  $\nu=0$ .

According to (5.8) with  $\theta > 0$  we have  $\mu_{\bullet}$ ,  $\kappa_{\bullet}$  and  $\gamma_{\bullet}$  non-negative. Thus  $\lambda$  is a real number. For various values of  $\lambda$  we give on Fig. 4 plots of velocity difference from the classical Poiseuille flow and on Fig. 5  $\nu h/w_0$ . From Fig. 4 as well as Fig. 3 we see that the velocity profile is no longer parabolic. Moreover

![](_page_14_Figure_4.jpeg)

FIGURE 3. Velocity Profile for  $\lambda = 1$ 

![](_page_14_Figure_6.jpeg)

FIGURE 4. Adverse Microflow

![](_page_15_Figure_2.jpeg)

FIGURE 5. Micro-Rotation

the velocity here is smaller than that of the classical Navier-Stokes fluids. Of course, micro-rotation  $\nu$  is altogether missing in the Navier-Stokes theory.

The non-vanishing components of the stress tensor and those of the couple stress are obtained through expressing (4.14) and (4.17) in cylindrical coordinates. Hence

$$t_{rr} = t_{\theta\theta} = t_{zz} = -p,$$

$$t_{rz} = \frac{1}{2} \frac{dp}{dz} a\rho,$$

$$t_{zr} = \frac{1}{2} \frac{dp}{dz} a \left[ \rho - \frac{\kappa_v}{\mu_v + \kappa_v} \frac{I_1(\lambda \rho)}{I_1(\lambda)} \right],$$

$$m_{\theta r} = (\beta_v w_0 / a^2) \left[ 1 + \frac{I_1(\lambda \rho)}{\rho I_1(\lambda)} - \frac{\lambda I_0(\lambda \rho)}{I_1(\lambda)} \right] = (\gamma_v / \beta_v) m_{r\theta}.$$

We note that  $t_{rz} \neq t_{zr}$  whenever  $\kappa_v \neq 0$ .

On Figs 6 and 7 are shown the surface tractions and couples on the fluid surface adjacent to the wall at  $\rho = 1$  for dp/dz < 0,  $\beta_{\tau} < 0$  and of course  $\gamma_{\tau} > 0$ . The shearing stress  $t_{\tau z}$  has the same expression as in the classical theory. However the existence of the distributed couples  $m_{\theta \tau}$  on the fluid surface (Fig. 3) will produce an effect in a thin layer near the wall, equivalent to reduction of the surface shear. Clearly then the present theory gives rise to a boundary layer phenomena not present in the Navier–Stokes theory. This new boundary layer is controlled with the parameter  $\lambda$ .

We believe that the theory of micropolar fluids opens up a very worthwhile

![](_page_16_Figure_2.jpeg)

FIGURE 6. Shear Stress Difference

![](_page_16_Figure_4.jpeg)

FIGURE 7. Couple Stress

branch of fluid mechanics. It should find important applications dealing with a variety of fluids. It should, in particular cast new directions in the theory of turbulence. Rich theoretical and experimental studies are awaiting the future workers.

**Acknowledgment.** The author is indebted to Dr. T. Areman for help in numerical calculations.

## REFERENCES

- [1] ERINGEN, A. C., Int. J. Engng. Sci., 2 (1964) 205.
- [2] ERINGEN, A. C., Proc. XI Intern. Congress of Appl. Mech. Springer-Verlag (1965).
- [3] HOYT, J. W., & FABULA, A. G., The Effect of Additives on Fluid Friction, U. S. Naval Ordnance Test Station Report, 1964.
- [4] VOGEL, W. M., & PATTERSON, A. M., An Experimental Investigation of the Effect of Additives Injected into the Boundary Layer of an Underwater Body, Pacific Naval Lab. of the Defense Res. Board of Canada, Rpt. 64-2.
- [5] Eringen, A. C., Proc. 5th Symposium on Naval Hydrodynamics, Bergen, September 10, 1964.
- [6] Eringen, A. C., Nonlinear Theory of Continuous Media, McGraw-Hill, 1962.
- [7] ERINGEN, A. C., "Linear Theory of Micropolar Elasticity," ONR Tech. Report 29, School of Aeronautics, Astronautics and Engineering Sciences, Purdue U., Sept. 1965; scheduled for publication in J. Math. and Mech.

Purdue University

Date Communicated: December 2, 1965