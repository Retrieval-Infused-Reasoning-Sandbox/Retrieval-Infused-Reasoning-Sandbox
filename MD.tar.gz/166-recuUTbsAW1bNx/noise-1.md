Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- <span id="page-0-0"></span>1. <u>Home</u> >
- 2. Archive for Rational Mechanics and Analysis
- 3. Article

# L<sup>2</sup> decay for weak solutions of the Navier-Stokes equations

- Published: September 1985
- Volume 88, pages 209-222, (1985)
- · Cite this article

![](_page_0_Picture_14.jpeg)

Archive for Rational Mechanics and Analysis Aims and scope Submit

manuscript

- Maria Elena Schonbek<sup>1</sup>
- 1556 Accesses
- 434 Citations
- 3 Altmetric

[Explore all metrics](file:///article/10.1007/BF00752111/metrics)  •

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00752111) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00752111)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

#### [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals)

# **References**

Caffarelli, L.,Kohn, R. &Nirenberg, L., Partial regularity of suitably weak solutions of the Navier-Stokes equations, Comm. on Pure and Applied Math.**25** (1982), 771–831. 1.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Partial%20regularity%20of%20suitably%20weak%20solutions%20of%20the%20Navier-Stokes%20equations&journal=Comm.%20on%20Pure%20and%20Applied%20Math.&volume=25&pages=771-831&publication_year=1982&author=Caffarelli%2CL.&author=Kohn%2CR.&author=Nirenberg%2CL.)

Heywood, J., The Navier-Stokes equations: On the existence, regularity and decay of solutions, Indiana University Math. J.**29** (1980), 639–681. 2.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Navier-Stokes%20equations%3A%20On%20the%20existence%2C%20regularity%20and%20decay%20of%20solutions&journal=Indiana%20University%20Math.%20J.&volume=29&pages=639-681&publication_year=1980&author=Heywood%2CJ.)

- Kato, T., On the Navier-Stokes equations, preprint. 3.
- Kawashima, S.,Matsumura, A., &Nishida, T., On the fluiddynamical approximations to the Boltzmann equation at the level of the Navier-Stokes equation, Comm. Math. Phys.**70** (1979), 97–124. 4.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20fluiddynamical%20approximations%20to%20the%20Boltzmann%20equation%20at%20the%20level%20of%20the%20Navier-Stokes%20equation&journal=Comm.%20Math.%20Phys.&volume=70&pages=97-124&publication_year=1979&author=Kawashima%2CS.&author=Matsumura%2CA.&author=Nishida%2CT.)

- Ladyzenskaya, O. A., The mathematical theory of viscous incompressible flows, 2nd ed. Gordon and Breach, New York, 1969. 5.
- Leray, J., Sur le mouvement d'un liquide visqueux emplissant l'espace, Acta Math.**63** (1934), 193–248. 6.

### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sur%20le%20mouvement%20d%27un%20liquide%20visqueux%20emplissant%20l%27espace&journal=Acta%20Math.&volume=63&pages=193-248&publication_year=1934&author=Leray%2CJ.)

Masuda, K., On the stability of incompressible viscous fluid motions past objects, J. Math. Soc. Japan**27** (1975), 294–327. 7.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20the%20stability%20of%20incompressible%20viscous%20fluid%20motions%20past%20objects&journal=J.%20Math.%20Soc.%20Japan&volume=27&pages=294-327&publication_year=1975&author=Masuda%2CK.)

- Schonbek, M., Uniform decay rates for parabolic conservation laws, Journal of Nonlinear Analysis: Theory, Methods and Applications, to appear. 8.
- Temam, R., Navier-Stokes equations. Theory and numerical analysis, North-Holland, Amsterdam and New York, 1979. 9.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Navier-Stokes%20equations.%20Theory%20and%20numerical%20analysis&publication_year=1979&author=Temam%2CR.)

[Download references](https://citation-needed.springer.com/v2/references/10.1007/BF00752111?format=refman&flavour=references)

# **Author information**

### **Authors and Affiliations**

<span id="page-3-1"></span>Department of Mathematics, Duke University, Durham, North Carolina 1.

Maria Elena Schonbek

#### Authors

<span id="page-3-0"></span>Maria Elena Schonbek 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Maria%20Elena%20Schonbek)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Maria%20Elena%20Schonbek) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Maria%20Elena%20Schonbek%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Additional information**

*Communicated by* C.Dafermos

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=L2%20decay%20for%20weak%20solutions%20of%20the%20Navier-Stokes%20equations&author=Maria%20Elena%20Schonbek&contentID=10.1007%2FBF00752111©right=Springer-Verlag%20GmbH%20%26%20Co.&publication=0003-9527&publicationDate=1985-09&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

### <span id="page-4-0"></span>**Cite this article**

Schonbek, M.E. L<sup>2</sup> decay for weak solutions of the Navier-Stokes equations. *Arch. Rational Mech. Anal.* **88**, 209–222 (1985). https://doi.org/10.1007/BF00752111

### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/BF00752111?format=refman&flavour=citation)

Received: 18 June 1984 •

Issue date: September 1985 •

DOI: https://doi.org/10.1007/BF00752111 •

### **Keywords**

- [Neural Network](file:///search?query=Neural%20Network&facet-discipline=%22Physics%22) •
- [Complex System](file:///search?query=Complex%20System&facet-discipline=%22Physics%22) •
- [Weak Solution](file:///search?query=Weak%20Solution&facet-discipline=%22Physics%22) •
- [Nonlinear Dynamics](file:///search?query=Nonlinear%20Dynamics&facet-discipline=%22Physics%22) •
- [Electromagnetism](file:///search?query=Electromagnetism&facet-discipline=%22Physics%22) •

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00752111)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

| View plans |
|------------|
|------------|

### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/BF00752111                                                                                                               |
| 1432-0673                                                                                                                        |
| L2 decay for weak solutions of the Navier-Stokes equations                                                                       |
| 1985                                                                                                                             |
|                                                                                                                                  |
| Maria Elena Schonbek                                                                                                             |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 0fb824f829181a83d270c96d80885574481c1e7d1284cf654cffc89c391f48b5d14293c888434fc3b173789e5cf6967219218c32e6e103eae115be3356a205b7 |
| Buy article PDF 39,95 €                                                                                                          |
| Price includes VAT (China (P.R.))                                                                                                |
|                                                                                                                                  |
| Instant access to the full article PDF.                                                                                          |
|                                                                                                                                  |
|                                                                                                                                  |
| Institutional subscriptions                                                                                                      |
|                                                                                                                                  |
| Advertisement                                                                                                                    |
|                                                                                                                                  |
| Search                                                                                                                           |
|                                                                                                                                  |
| Search by keyword or author                                                                                                      |
|                                                                                                                                  |

Search

### <span id="page-5-1"></span><span id="page-5-0"></span>**Navigation**

[Find a journal](https://link.springer.com/journals/)  •

- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •

- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature