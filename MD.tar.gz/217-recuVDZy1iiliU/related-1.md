# Rayleigh quotient

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

In mathematics, the Rayleigh quotient () for a given complex Hermitian matrix

![](_page_0_Picture_4.jpeg)

and nonzero vector

 $\boldsymbol{x}$ 

is defined as:

$$R(M,x)=rac{x^*Mx}{x^*x}.$$

For real matrices and vectors, the condition of being Hermitian reduces to that of being symmetric, and the conjugate transpose

 $x^*$ 

to the usual transpose

x'

. Note that

![](_page_0_Picture_14.jpeg)

$$R(M, cx) = R(M, x)$$

for any non-zero scalar

c

. Recall that a Hermitian (or real symmetric) matrix is <u>diagonalizable with only real</u> eigenvalues. It can be shown that, for a given matrix, the Rayleigh quotient reaches its

minimum value  $\lambda_{\min}$  (the smallest  $\underline{ ext{eigenvalue}}$  of

[Image]

M

) when

 $\boldsymbol{x}$ 

is

 $v_{\mathrm{min}}$ 

(the corresponding eigenvector). Similarly,

$$R(M,x) \leq \lambda_{\max}$$

and

$$R(M,v_{ ext{max}}) = \lambda_{ ext{max}}$$

The Rayleigh quotient is used in the <u>min-max theorem</u> to get exact values of all eigenvalues. It is also used in <u>eigenvalue algorithms</u> (such as <u>Rayleigh quotient iteration</u>) to obtain an eigenvalue approximation from an eigenvector approximation.

The range of the Rayleigh quotient (for any matrix, not necessarily Hermitian) is called a <u>numerical range</u> and contains its <u>spectrum</u>. When the matrix is Hermitian, the numerical radius is equal to the <u>spectral norm</u>. Still in <u>functional analysis</u>,

![](_page_1_Picture_14.jpeg)

 $\lambda_{
m max}$ 

is known as the spectral radius. In the context of

C

-algebras or algebraic quantum mechanics, the function that to

![](_page_2_Figure_0.jpeg)

If we fix the complex matrix

![](_page_3_Figure_0.jpeg)

### **Bounds for Hermitian M**

[edit]

As stated in the introduction, for any vector x, one has

$$R(M,x) \in [\lambda_{\min},\lambda_{\max}]$$

, where

$$\lambda_{\min}, \lambda_{\max}$$

are respectively the smallest and largest eigenvalues of

![](_page_4_Picture_9.jpeg)

M

. This is immediate after observing that the Rayleigh quotient is a weighted average of eigenvalues of M:

$$R(M,x) = rac{x^*Mx}{x^*x} = rac{\sum_{i=1}^n \lambda_i y_i^2}{\sum_{i=1}^n y_i^2}$$

where

$$(\lambda_i,v_i)$$

is the

-th eigenpair after orthonormalization and

$$y_i = v_i^* x$$

is the

th coordinate of x in the eigenbasis. It is then easy to verify that the bounds are attained at the corresponding eigenvectors

 $v_{\min}, v_{\max}$ 

The fact that the quotient is a weighted average of the eigenvalues can be used to identify

the second, the third, ... largest eigenvalues. Let

$$\lambda_{ ext{max}} = \lambda_1 \geq \lambda_2 \geq \cdots \geq \lambda_n = \lambda_{ ext{min}}$$

be the eigenvalues in decreasing order. If

$$n = 2$$

and

 $\boldsymbol{x}$ 

is constrained to be orthogonal to

 $v_1$ 

, in which case

$$y_1 = v_1^* x = 0$$

, then

has maximum value

![](_page_5_Picture_13.jpeg)

 $\lambda_2$ 

, which is achieved when

$$x = v_2$$

## Special case of covariance matrices

[edit]

An empirical covariance matrix

![](_page_5_Picture_21.jpeg)

M

can be represented as the product

of the normalized data matrix

[Image]

 $\boldsymbol{A}$ 

pre-multiplied by its transpose

A'

. Being a positive semi-definite matrix,

![](_page_6_Picture_6.jpeg)

M

has non-negative eigenvalues, and orthogonal (or orthogonalisable) eigenvectors, which can be demonstrated as follows.

Firstly, that the eigenvalues

 $\lambda_i$ 

are non-negative:

$$egin{aligned} Mv_i &= A'Av_i = \lambda_i v_i \ \Rightarrow v_i'A'Av_i &= v_i'\lambda_i v_i \ \Rightarrow \left\|Av_i
ight\|^2 &= \lambda_i \left\|v_i
ight\|^2 \ \Rightarrow \lambda_i &= rac{\left\|Av_i
ight\|^2}{\left\|v_i
ight\|^2} \geq 0. \end{aligned}$$

Secondly, that the eigenvectors

 $v_i$ 

are orthogonal to one another:

$$egin{aligned} Mv_i &= \lambda_i v_i \ \Rightarrow v_j' M v_i &= v_j' \lambda_i v_i \ \Rightarrow (Mv_j)' v_i &= \lambda_j v_j' v_i \end{aligned}$$

$$\Rightarrow \lambda_j v_j' v_i = \lambda_i v_j' v_i$$
  
 $\Rightarrow (\lambda_j - \lambda_i) v_j' v_i = 0$   
 $\Rightarrow v_j' v_i = 0$ 

if the eigenvalues are different – in the case of multiplicity, the basis can be orthogonalized.

To now establish that the Rayleigh quotient is maximized by the eigenvector with the largest eigenvalue, consider decomposing an arbitrary vector

on the basis of the eigenvectors

 $v_i$ 

:

$$x = \sum_{i=1}^n lpha_i v_i,$$

where

$$lpha_i = rac{x'v_i}{v_i'v_i} = rac{\langle x, v_i 
angle}{\left\|v_i
ight\|^2}$$

is the coordinate of

 $\boldsymbol{x}$ 

orthogonally projected onto

 $v_i$ 

. Therefore, we have:

$$egin{aligned} R(M,x) &= rac{x'A'Ax}{x'x} \ &= rac{\left(\sum_{j=1}^n lpha_j v_j
ight)' \left(A'A
ight) \left(\sum_{i=1}^n lpha_i v_i
ight)}{\left(\sum_{j=1}^n lpha_j v_j
ight)' \left(\sum_{i=1}^n lpha_i v_i
ight)} \ &= rac{\left(\sum_{j=1}^n lpha_j v_j
ight)' \left(\sum_{i=1}^n lpha_i (A'A) v_i
ight)}{\left(\sum_{i=1}^n lpha_i^2 v_i' v_i
ight)} \ &= rac{\left(\sum_{j=1}^n lpha_j v_j
ight)' \left(\sum_{i=1}^n lpha_i \lambda_i v_i
ight)}{\left(\sum_{i=1}^n lpha_i^2 \|v_i\|^2
ight)} \end{aligned}$$

which, by orthonormality of the eigenvectors, becomes:

$$egin{aligned} R(M,x) &= rac{\sum_{i=1}^{n} lpha_{i}^{2} \lambda_{i}}{\sum_{i=1}^{n} lpha_{i}^{2}} \ &= \sum_{i=1}^{n} \lambda_{i} rac{(x'v_{i})^{2}}{(x'x)(v'_{i}v_{i})^{2}} \ &= \sum_{i=1}^{n} \lambda_{i} rac{(x'v_{i})^{2}}{(x'v_{i})^{2}} \end{aligned}$$

$$\sum_{i=1}^{\infty} (x'x)^{i}$$

The last representation establishes that the Rayleigh quotient is the sum of the squared cosines of the angles formed by the vector

 $\boldsymbol{x}$ 

and each eigenvector

 $v_i$ 

, weighted by corresponding eigenvalues.

If a vector

 $\boldsymbol{x}$ 

maximizes

, then any non-zero scalar multiple

kx

also maximizes

![](_page_8_Picture_13.jpeg)

R

, so the problem can be reduced to the Lagrange problem of maximizing

$$\sum_{i=1}^n lpha_i^2 \lambda_i$$

under the constraint that

$$\sum_{i=1}^n lpha_i^2 = 1$$

Define:

$$eta_i = lpha_i^2$$

. This then becomes a <u>linear program</u>, which always attains its maximum at one of the corners of the domain. A maximum point will have

$$lpha_1=\pm 1$$

and

$$\alpha_i = 0$$

for all

(when the eigenvalues are ordered by decreasing magnitude).

Thus, the Rayleigh quotient is maximized by the eigenvector with the largest eigenvalue.

## Formulation using Lagrange multipliers

#### [edit]

Alternatively, this result can be arrived at by the method of <u>Lagrange multipliers</u>. The first part is to show that the quotient is constant under scaling

, where

c

is a scalar

$$R(M,cx)=rac{(cx)^*Mcx}{(cx)^*cx}=rac{c^*c}{c^*c}rac{x^*Mx}{x^*x}=R(M,x).$$

Because of this invariance, it is sufficient to study the special case

$$\|x\|^2 = x^T x = 1$$

. The problem is then to find the **critical points** of the function

$$R(M, x) = x^{\mathsf{T}} M x,$$

subject to the constraint

$$||x||^2 = x^T x = 1.$$

In other words, it is to find the critical points of

$$\mathcal{L}(x) = x^\mathsf{T} M x - \lambda \left( x^\mathsf{T} x - 1 
ight),$$

where

 $\lambda$ 

is a Lagrange multiplier. The stationary points of

$$\mathcal{L}(x)$$

occur at

$$\frac{d\mathcal{L}(x)}{dx} = 0$$

$$\Rightarrow 2x^{\mathsf{T}}M - 2\lambda x^{\mathsf{T}} = 0$$

 $\Rightarrow 2Mx - 2\lambda x = 0$  (taking the transpose of both sides and noting that M is Hermitian)

$$\Rightarrow Mx = \lambda x$$

and

$$\therefore R(M,x) = rac{x^\mathsf{T} M x}{x^\mathsf{T} x} = \lambda rac{x^\mathsf{T} x}{x^\mathsf{T} x} = \lambda.$$

Therefore, the eigenvectors

![](_page_9_Picture_28.jpeg)

| C                                                                                                                                   | $x_1,\dots,x_n$             |                        |  |  |  |  |
|-------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|------------------------|--|--|--|--|
| of                                                                                                                                  |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     | [Image]                     |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
| 1                                                                                                                                   | M                           |                        |  |  |  |  |
| are the critical points of the Ra                                                                                                   |                             | responding eigenvalues |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     | [Image]                     |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
| and the station arrayalizes of                                                                                                      | $\lambda_1,\dots,\lambda_n$ |                        |  |  |  |  |
| are the stationary values of                                                                                                        |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     | [Image]                     |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
|                                                                                                                                     |                             |                        |  |  |  |  |
| $\mathcal{L}$                                                                                                                       |                             |                        |  |  |  |  |
| . This property is the basis for $\underline{\text{principal components analysis}}$ and $\underline{\text{canonical correlation}}.$ |                             |                        |  |  |  |  |
| Use in Sturm Lieuwille theory                                                                                                       |                             |                        |  |  |  |  |

[edit]

$$L(y) = rac{1}{w(x)} \left( -rac{d}{dx} \left[ p(x) rac{dy}{dx} 
ight] + q(x) y 
ight)$$

on the inner product space defined by

$$\langle y_1,y_2
angle = \int_a^b w(x)y_1(x)y_2(x)\,dx$$

of functions satisfying some specified <u>boundary conditions</u> at a and b. In this case the Rayleigh quotient is

$$rac{\langle y, Ly
angle}{\langle y, y
angle} = rac{\int_a^b y(x) \left(-rac{d}{dx} \left[p(x)rac{dy}{dx}
ight] + q(x)y(x)
ight) dx}{\int_a^b w(x)y(x)^2 dx}.$$

This is sometimes presented in an equivalent form, obtained by separating the integral in the numerator and using integration by parts:

$$egin{aligned} rac{\langle y, Ly 
angle}{\langle y, y 
angle} &= rac{\left\{ \int_a^b y(x) \left( -rac{d}{dx} \left[ p(x) y'(x) 
ight] 
ight) dx 
ight\} + \left\{ \int_a^b q(x) y(x)^2 \, dx 
ight\}}{\int_a^b w(x) y(x)^2 \, dx} \ &= rac{\left\{ -y(x) \left[ p(x) y'(x) 
ight] 
ight|_a^b 
ight\} + \left\{ \int_a^b y'(x) \left[ p(x) y'(x) 
ight] \, dx 
ight\} + \left\{ \int_a^b q(x) y(x)^2 \, dx 
ight\}}{\int_a^b w(x) y(x)^2 \, dx} \ &= rac{\left\{ -p(x) y(x) y'(x) 
ight|_a^b 
ight\} + \left\{ \int_a^b \left[ p(x) y'(x)^2 + q(x) y(x)^2 
ight] \, dx 
ight\}}{\int_a^b w(x) y(x)^2 \, dx}. \end{aligned}$$

<sup>1.</sup> For a given pair (*A*, *B*) of matrices, and a given non-zero vector *x*, the **generalized Rayleigh quotient** is defined as:

$$R(A,B;x) := rac{x^*Ax}{x^*Bx}.$$

The generalized Rayleigh quotient can be reduced to the Rayleigh quotient

$$R(D, C^*x)$$

through the transformation

$$D = C^{-1}AC^{*-1}$$

where

$$CC^{\circ}$$

is the Cholesky decomposition of the Hermitian positive-definite matrix B.

<sup>2</sup>· For a given pair (*x*, *y*) of non-zero vectors, and a given Hermitian matrix *H*, the **generalized Rayleigh quotient** or sometimes **two-sided Rayleigh quotient** can be defined as:

$$R(H;x,y):=\frac{y^*Hx}{\sqrt{y^*y\cdot x^*x}}$$

which coincides with R(H,x) when x = y. In quantum mechanics, this quantity is called a "matrix element" or sometimes a "transition amplitude".

• xt..... 1 .....

#### Numericai range

- Courant minimax principle
- Min-max theorem
- \* Rayleigh's quotient in vibrations analysis
- \* Dirichlet eigenvalue
- <sup>1.</sup> Also known as the **Rayleigh–Ritz ratio**; named after <u>Walther Ritz</u> and <u>Lord Rayleigh</u>.
- <sup>2</sup>· <u>Horn, R. A.</u>; <u>Johnson, C. A.</u> (1985). Matrix Analysis. Cambridge University Press. pp. 176–180. <u>ISBN 0-521-30586-1</u>.
- <sup>3.</sup> <u>Parlett, B. N.</u> (1998). The Symmetric Eigenvalue Problem. Classics in Applied Mathematics. SIAM. ISBN 0-89871-402-8.
- <sup>4.</sup> Costin, Rodica D. (2013). "Midterm notes" (PDF). Mathematics 5102 Linear Mathematics in Infinite Dimensions, lecture notes. The Ohio State University.
  - Shi Yu, Léon-Charles Tranchevent, Bart Moor, <u>Yves Moreau</u>, <u>Kernel-based Data</u>

    <u>Fusion for Machine Learning: Methods and Applications in Bioinformatics and</u>

    <u>Text Mining</u>, Ch. 2, Springer, 2011.