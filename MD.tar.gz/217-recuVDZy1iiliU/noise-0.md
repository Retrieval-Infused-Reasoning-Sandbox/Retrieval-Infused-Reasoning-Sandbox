[Skip to main content](#page-0-0)

[Springer Nature Link](https://link.springer.com)

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/article/10.1007/BF00250468)

[Menu](#page-4-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-4-1)

[Cart](https://order.springer.com/public/cart)

- <span id="page-0-0"></span>[Home](file:///) 1.
- [Archive for Rational Mechanics and Analysis](file:///journal/205) 2.
- Article 3.

# **A symmetry problem in potential theory**

- Published: January 1971 •
- Volume 43, pages 304–318, (1971) •
- [Cite this article](#page-3-0) •

![](_page_0_Picture_14.jpeg)

[Archive for Rational Mechanics and Analysis](file:///journal/205) [Aims and scope](file:///journal/205/aims-and-scope) [Submit](https://www.editorialmanager.com/arma)

[manuscript](https://www.editorialmanager.com/arma) 

- [James Serrin](#page-2-0)[1](#page-2-1) •
- 3013 Accesses •
- 961 Citations •
- 6 Altmetric •
- [Explore all metrics](file:///article/10.1007/BF00250468/metrics)  •

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250468) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250468)

## **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

## **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/BF00250468                                                                                                               |
| 1432-0673                                                                                                                        |
| A symmetry problem in potential theory                                                                                           |
| 1971                                                                                                                             |
|                                                                                                                                  |
| James Serrin                                                                                                                     |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 81ec645b94b39dbd7db8f6f081c2a485aa47e94db777c6168c29ce114d6dc7c63378a709dc9f9e65124b26b94e13795fdf1ad2e63065094b5502af548643c2f7 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

# **References**

Hopf, E., Elementare Bemerkungen über die Lösungen partieller Differentialgleichungen zweiter Ordnung vom elliptischen Typus. Berlin, Sber. Preuss. Akad. Wiss. **19**, 147–152 (1927). 1.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Elementare%20Bemerkungen%20%C3%BCber%20die%20L%C3%B6sungen%20partieller%20Differentialgleichungen%20zweiter%20Ordnung%20vom%20elliptischen%20Typus&journal=Berlin%2C%20Sber.%20Preuss.%20Akad.%20Wiss.&volume=19&pages=147-152&publication_year=1927&author=Hopf%2CE.)

Protter, M. H., & H. F., Weinberger, Maximum Principles in Differential Equations. New Jersey: Prentice-Hall 1967. 2.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Maximum%20Principles%20in%20Differential%20Equations&publication_year=1967&author=Protter%2CM.%20H.&author=Weinberger%2CH.%20F.)

Sokolnikoff, I. S., Mathematical Theory of Elasticity. New York: McGraw-Hill 1956. 3.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Mathematical%20Theory%20of%20Elasticity&publication_year=1956&author=Sokolnikoff%2CI.%20S.)

[Download references](https://citation-needed.springer.com/v2/references/10.1007/BF00250468?format=refman&flavour=references)

# **Author information**

### **Authors and Affiliations**

<span id="page-2-1"></span>Department of Mathematics, University of Minnesota, Minneapolis 1.

James Serrin

### Authors

<span id="page-2-0"></span>James Serrin 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=James%20Serrin)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=James%20Serrin) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22James%20Serrin%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=A%20symmetry%20problem%20in%20potential%20theory&author=James%20Serrin&contentID=10.1007%2FBF00250468©right=Springer-Verlag&publication=0003-9527&publicationDate=1971-01&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

# <span id="page-3-0"></span>**Cite this article**

Serrin, J. A symmetry problem in potential theory. *Arch. Rational Mech. Anal.* **43**, 304–318 (1971). https://doi.org/10.1007/BF00250468

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/BF00250468?format=refman&flavour=citation)

Received: 04 May 1971 •

Issue date: January 1971 •

DOI: https://doi.org/10.1007/BF00250468 •

# **Keywords**

- [Neural Network](file:///search?query=Neural%20Network&facet-discipline=%22Physics%22) •
- [Complex System](file:///search?query=Complex%20System&facet-discipline=%22Physics%22) •
- [Nonlinear Dynamics](file:///search?query=Nonlinear%20Dynamics&facet-discipline=%22Physics%22) •
- [Electromagnetism](file:///search?query=Electromagnetism&facet-discipline=%22Physics%22) •
- [Potential Theory](file:///search?query=Potential%20Theory&facet-discipline=%22Physics%22) •

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250468)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

| View plans |
|------------|
|------------|

# **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/BF00250468                                                                                                               |
| 1432-0673                                                                                                                        |
| A symmetry problem in potential theory                                                                                           |
| 1971                                                                                                                             |
|                                                                                                                                  |
| James Serrin                                                                                                                     |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 81ec645b94b39dbd7db8f6f081c2a485aa47e94db777c6168c29ce114d6dc7c63378a709dc9f9e65124b26b94e13795fdf1ad2e63065094b5502af548643c2f7 |
| Buy article PDF 39,95 €                                                                                                          |
| Price includes VAT (China (P.R.))                                                                                                |
| Instant access to the full article PDF.                                                                                          |
| Institutional subscriptions                                                                                                      |
| Advertisement                                                                                                                    |
| Search                                                                                                                           |

Search

# <span id="page-4-0"></span>**Navigation**

[Find a journal](https://link.springer.com/journals/)  •

<span id="page-4-1"></span>Search by keyword or author

- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •

- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature