# NEARLY OPTIMAL STABILITY FOR SERRIN'S PROBLEM AND THE SOAP BUBBLE THEOREM

#### ROLANDO MAGNANINI AND GIORGIO POGGESI

ABSTRACT. We present new quantitative estimates for the radially symmetric configuration concerning Serrin's overdetermined problem for the torsional rigidity, Alexandrov's Soap Bubble Theorem, and other related problems. The new estimates improve on those obtained in [MP1, MP2] and are in some cases optimal.

#### <span id="page-0-2"></span>1. Introduction

Serrin's symmetry result for the torsional rigidity ([Se]) states that the overdetermined boundary value problem

(1.1) 
$$\Delta u = N \text{ in } \Omega, \quad u = 0 \text{ on } \Gamma,$$

$$(1.2) u_{\nu} = R \text{ on } \Gamma,$$

admits a solution for some positive constant R if and only if  $\Omega$  is a ball of radius R and, up to translations,  $u(x) = (|x|^2 - R^2)/2$ . Here,  $\Omega$  denotes a bounded domain in  $\mathbb{R}^N$ ,  $N \geq 2$ , with sufficiently smooth boundary  $\Gamma$ , say  $C^2$ , and  $u_{\nu}$  is the outward normal derivative of u on  $\Gamma$ .

Alexandrov's Soap Bubble Theorem ([Al1], [Al2]) states that if the mean curvature H of a compact hypersurface  $\Gamma$  embedded in  $\mathbb{R}^N$  is constant, then  $\Gamma$  must be a sphere.

In the present paper we consider the stability issue for those two pioneering symmetry theorems. Technically speaking, we will find two concentric balls  $B_{\rho_i}(z)$  and  $B_{\rho_e}(z)$ , centered at  $z \in \Omega$  with radii  $\rho_i$  and  $\rho_e$ , such that

<span id="page-0-1"></span><span id="page-0-0"></span>
$$B_{\rho_i}(z) \subseteq \Omega \subseteq B_{\rho_e}(z)$$
 and  $\rho_e - \rho_i \le \psi(\eta)$ ,

where  $\psi : [0, \infty) \to [0, \infty)$  is a continuous function vanishing at 0 and  $\eta$  is a suitable measure of the deviation of  $u_{\nu}$  or H from being a constant. The landmark results of the present paper are the following new stability estimates:

(1.3) 
$$\rho_e - \rho_i \le C \|u_{\nu} - R\|_{2, \Gamma}^{\tau_N}$$

and

$$(1.4) \rho_e - \rho_i \le C \|H_0 - H\|_{2\Gamma}^{\tau_N}.$$

In (1.3) (see Theorem 3.1 for details),  $\tau_2 = 1$ ,  $\tau_3$  is arbitrarily close to one, and  $\tau_N = 2/(N-1)$  for  $N \geq 4$ . In (1.4) (see Theorem 3.5 for details),  $\tau_N = 1$  for  $N = 2, 3, \tau_4$  is arbitrarily close to one, and  $\tau_N = 2/(N-2)$  for  $N \geq 5$ .

The constants C depend on the dimension N, the diameter  $d_{\Omega}$ , and the radii  $r_i$ ,  $r_e$  of the uniform interior and exterior sphere conditions. The dependence on  $r_e$  can be removed when  $\Gamma$  is mean convex.

The new estimate (1.3) improves (for every  $N \ge 2$ ) on [MP2, Theorem 1.1] – where (1.3) was obtained with  $\tau_N = 2/(N+2)$ , for every  $N \ge 2$  – to the

<sup>1991</sup> Mathematics Subject Classification. Primary 35N25, 53A10, 35B35; Secondary 35A23. Key words and phrases. Serrin's overdetermined problem, Alexandrov Soap Bubble Theorem, torsional rigidity, constant mean curvature, integral identities, stability, quantitative estimates.

extent that it gains the (optimal) Lipschitz stability in the case N=2. The estimates obtained in [MP2] were already better than those obtained previously in [ABR, CMV, BNST]. Optimal stability for Serrin's problem has been obtained in [Fe], but based on a weaker measure of closeness to spherical symmetry. A more detailed overview and comparison of those results can be found in [MP2, Ma, Po2].

The new estimate (1.4) improves (for every  $N \geq 4$ ) on [MP2, Theorem 1.2], where (1.4) was obtained with  $\tau_N = 1$  for N = 2, 3, and  $\tau_N = 2/(N+2)$  for  $N \geq 4$ . If we compare the exponents in (1.4) to those obtained in [MP2, Theorem 1.2], we notice that the dependence of  $\tau_N$  on N has become virtually continuous, in the sense that  $\tau_N \to 1$ , if N "approaches" 4 from below or from above.

We refer to [MP1, MP2, Ma, Po2] for a more detailed overview on other stability results present in the literature for Alexandrov's theorem. Here, we only comment and compare the optimal Lipschitz stability (i.e. with  $\tau_N = 1$ ) for Alexandrov's theorem obtained in general dimension in [CV], [MP2, Theorem 4.6], and [KM]. [MP2, Theorem 4.6] is based on the same weaker measure of closeness to spherical symmetry used in [Fe] for Serrin's problem. [CV] and [KM, Theorem 1.9] assume the stronger uniform measure for the deviation of H from being constant. [KM, Theorem 1.10] holds for surfaces that are  $C^1$ -small normal deformations of spheres.

At present, we do not know if the estimate (1.4) (or (1.3)) is optimal in general dimension. In fact, even if the exponent 1 obtained in low dimensions is optimal — as can be verified by direct computations for ellipsoids — a proof of optimality (or of non-optimality) in higher dimensions is still elusive.

In this paper we will also consider weaker deviations (see Theorems 3.2 and 3.7). Theorem 3.2 provides the inequality

(1.5) 
$$\rho_e - \rho_i \le C \|u_\nu - R\|_{1,\Gamma}^{\tau_N/2},$$

where  $\tau_N$  is the same appearing in (1.3). Also this inequality is new and refines one stated in [MP2, Theorem 3.6] in which  $\tau_N/2$  was replaced by 1/(N+2).

<span id="page-1-0"></span>In Theorem 3.7 we prove the inequality

(1.6) 
$$\rho_e - \rho_i \le C \left\{ \int_{\Gamma} (H_0 - H)^+ dS_x \right\}^{\tau_N/2},$$

where  $\tau_N$  is the same appearing in (1.4). The last estimate improves (for every  $N \geq 4$ ) on that obtained in [MP1, Theorem 4.1], where (1.6) was obtained with  $\tau_N = 1$  for N = 2, 3, and  $\tau_N = 2/(N+2)$  for  $N \geq 4$ .

All the aforementioned estimates are based on two integral identities obtained in [MP1, MP2]:

<span id="page-1-1"></span>(1.7) 
$$\int_{\Omega} (-u) \left\{ |\nabla^2 u|^2 - \frac{(\Delta u)^2}{N} \right\} dx = \frac{1}{2} \int_{\Gamma} \left( u_{\nu}^2 - R^2 \right) (u_{\nu} - q_{\nu}) dS_x$$

and

<span id="page-1-2"></span>
$$(1.8) \quad \frac{1}{N-1} \int_{\Omega} \left\{ |\nabla^2 u|^2 - \frac{(\Delta u)^2}{N} \right\} dx + \frac{1}{R} \int_{\Gamma} (u_{\nu} - R)^2 dS_x = \int_{\Gamma} (H_0 - H) (u_{\nu})^2 dS_x.$$

Here, R and  $H_0$  are reference constants given by

<span id="page-1-4"></span>(1.9) 
$$R = \frac{N|\Omega|}{|\Gamma|}, \quad H_0 = \frac{1}{R} = \frac{|\Gamma|}{N|\Omega|},$$

and q is a quadratic polynomial of the form

<span id="page-1-3"></span>(1.10) 
$$q(x) = \frac{1}{2} (|x - z|^2 - a),$$

for some choice of  $z \in \mathbb{R}^N$  and  $a \in \mathbb{R}$ .

Identities (1.7) and (1.8) hold regardless of how the point z or the constant a are chosen. Identity (1.7), proved in [MP2, Theorem 2.1], puts together and refines Weinberger's argument for symmetry [We] and some remarks of Payne and Schaefer [PS]. Identity (1.8) was proved in [MP1, Theorem 2.2] by polishing the arguments contained in [Re1] (see also [Re2]).

The term in the braces in (1.7) and (1.8), that we call Cauchy-Schwarz deficit, plays the role of spherical detector. In fact, by Cauchy-Schwarz inequality, we have that

$$(1.11) (\Delta u)^2 \le N |\nabla^2 u|^2 \text{in } \Omega,$$

and the equality sign is identically attained in  $\Omega$  if and only if u is a quadratic polynomial of the form (1.10), and hence  $\Gamma$  is a sphere centered at z, by the boundary condition in (1.1).

It is thus evident that each of the two identities gives spherical symmetry if respectively  $u_{\nu} = R$  or  $H = H_0$  on  $\Gamma$ , since Newton's inequality (1.11) holds with the equality sign (notice that in (1.7) -u > 0 by the strong maximum principle). The same conclusion is also achieved if we only assume that  $u_{\nu}$  or H are constant on  $\Gamma$ , since those constants must equal R and  $H_0$  by the identities

<span id="page-2-0"></span>
$$\int_{\Gamma} u_{\nu} \, dS_x = N |\Omega| \quad \text{and} \quad \int_{\Gamma} H \, q_{\nu} \, dS_x = |\Gamma|.$$

Thus, (1.7) and (1.8) give new elegant proofs of Alexandrov's and Serrin's results. Moreover, they lead to several advantages and generalizations that have been discussed in [MP1, MP2, Po1, Po2, Ma]. The greatest benefits yielded by (1.7) and (1.8) are undoubtedly the optimal or quasi-optimal stability results for the Soap Bubble Theorem, Serrin's problem, and other related overdetermined problems.

In order to prove (1.3) and (1.4), the harmonic function h = q - u plays a key role. This fact becomes visible when we observe that

<span id="page-2-5"></span>(1.12) 
$$|\nabla^2 u|^2 - \frac{(\Delta u)^2}{N} = |\nabla^2 h|^2$$

and, if we choose z in  $\Omega$ ,

<span id="page-2-1"></span>(1.13) 
$$\max_{\Gamma} h - \min_{\Gamma} h = \frac{1}{2} (\rho_e^2 - \rho_i^2) \ge \frac{r_i}{2} (\rho_e - \rho_i).$$

In (1.13) we used that h = q on  $\Gamma$ .

Now, since (1.7) and (1.8) hold regardless of the choice of the parameters z and a defining q, we will thus complete the first step of our argument by choosing  $z \in \Omega$  in a way such that the oscillation of h on  $\Gamma$  is bounded in terms of the integrals

<span id="page-2-3"></span>(1.14) 
$$\int_{\Omega} \delta_{\Gamma} |\nabla^2 h|^2 dx \quad \text{or} \quad \frac{1}{N-1} \int_{\Omega} |\nabla^2 h|^2 dx,$$

where  $\delta_{\Gamma}$  denotes the distance to  $\Gamma$ . In fact, we know that the factor -u appearing in the left-hand side of (1.7) can be bounded from below by the function  $\delta_{\Gamma}$ , by means of the following inequality proved in [MP2, Lemma 3.1]:

<span id="page-2-4"></span>(1.15) 
$$-u(x) \ge \frac{r_i}{2} \delta_{\Gamma}(x) \text{ for every } x \in \overline{\Omega}.$$

We describe how this task is accomplished. First, as done in Lemmas 2.6 and 2.7, we show that the oscillation of h on  $\Gamma$ , and hence  $\rho_e - \rho_i$  can be bounded from above in the following way:

<span id="page-2-2"></span>(1.16) 
$$\rho_e - \rho_i \le C(N, p, d_{\Omega}, r_i, r_e) \|h - h_{\Omega}\|_{p, \Omega}^{p/(N+p)},$$

where  $h_{\Omega}$  is the mean value of h on  $\Omega$  and  $p \in [1, \infty)$ . We stress that this inequality is new and generalizes to any p the estimate obtained in [MP1, Lemma 3.3] for p = 2.

Next, to relate the right-hand side of (1.16) to the integrals in (1.14) we proceed as follows. We choose  $z \in \Omega$  as a global minimum point of u (notice that this is always attained in  $\Omega$ ) and we apply two integral inequalities to h and its first (harmonic) derivatives. One is the Hardy-Poincaré-type inequality

<span id="page-3-1"></span>(1.17) 
$$||v||_{r,\Omega} \le C(N,r,p,\alpha,d_{\Omega},r_i) ||\delta_{\Gamma}^{\alpha} \nabla v||_{p,\Omega},$$

that is applied to the first (harmonic) derivatives of h. It holds for any harmonic function v in  $\Omega$  that is zero at the point z (notice that our choice of z guarantees  $\nabla h(z)=0$ ). The three numbers  $r,p,\alpha$  are such that  $0\leq \alpha\leq 1$  and either  $1\leq p\leq r\leq \frac{Np}{N-p(1-\alpha)},\ p(1-\alpha)< N$ , or  $1\leq r=p<\infty$  (see Lemma 2.1 and Remark 2.2). The other one is applied to  $h-h_{\Omega}$  and is the Poincaré-type inequality

<span id="page-3-0"></span>(1.18) 
$$||v||_{r,\Omega} \le C(N, r, p, d_{\Omega}, r_i) ||\nabla v||_{p,\Omega},$$

that holds for any function  $v \in W^{1,p}(\Omega)$  with zero mean value on  $\Omega$ . This holds for r and p as above, with  $\alpha = 0$  (see Lemma 2.1).

If we put together (1.16)-(1.18) and choose  $\alpha = 1/2$  and  $\alpha = 0$  in (1.17) we obtain respectively that

<span id="page-3-2"></span>(1.19) 
$$\rho_e - \rho_i \le C(N, d_{\Omega}, r_i, r_e) \left( \int_{\Omega} (-u) |\nabla^2 h|^2 dx \right)^{\tau_N/2},$$

with  $\tau_N$  as in (1.3), and

(1.20) 
$$\rho_e - \rho_i \le C(N, d_{\Omega}, r_i, r_e) \|\nabla^2 h\|_{2\Omega}^{r_N},$$

with  $\tau_N$  as in (1.4). All the details about (1.19) and (1.20) can be found in Theorems 2.8 and 2.10.

We mention that in low dimensions – N=2 for (1.19) and N=2,3 for (1.20) – there is no need to use (1.16), thanks to the Sobolev imbedding theorem (see item (i) of Theorems 2.8 and 2.10).

The proofs of (1.3) and (1.4) are then completed by the inequalities:

<span id="page-3-3"></span>
$$\int_{\Omega} (-u) |\nabla^2 h|^2 dx \le C(N, d_{\Omega}, r_i, r_e) \|u_{\nu} - R\|_{2, \Gamma}^2,$$
$$\|\nabla^2 h\|_{2, \Omega} \le C(N, d_{\Omega}, r_i, r_e) \|H_0 - H\|_{2, \Gamma},$$

<span id="page-3-4"></span>that can be deduced by working on the right-hand side of (1.7) and (1.8) with arguments taken from [MP2] (see the proof of Theorems 3.1 and 3.5 respectively).

## 2. Some estimates for harmonic functions

We begin by setting some relevant notations.

By  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , we shall denote a bounded domain, that is a connected bounded open set, and call  $\Gamma$  its boundary. By  $|\Omega|$  and  $|\Gamma|$ , we will denote indifferently the N-dimensional Lebesgue measure of  $\Omega$  and the surface measure of  $\Gamma$ . When  $\Gamma$  is of class  $C^1$ ,  $\nu$  will denote the (exterior) unit normal vector field to  $\Gamma$  and, when  $\Gamma$  is a hypersurface of class  $C^2$ , H(x) will denote its mean curvature (with respect to  $-\nu(x)$ ) at  $x \in \Gamma$ .

As already mentioned in the introduction, the diameter of  $\Omega$  is indicated by  $d_{\Omega}$ , while  $\delta_{\Gamma}(x)$  denotes the distance of a point x to the boundary  $\Gamma$ .

We will also use the letter q to denote the quadratic polynomial defined in (1.10), where z is any point in  $\mathbb{R}^N$  and a is any real number; furthermore, we will always use the letter h to denote the harmonic function

$$h = q - u$$

where u is the solution of (1.1) and q is the quadratic polynomial defined in (1.10). For a point  $z \in \Omega$ ,  $\rho_i$  and  $\rho_e$  shall denote the radius of the largest ball contained in  $\Omega$  and that of the smallest ball that contains  $\Omega$ , both centered at z; in formulas,

(2.1) 
$$\rho_i = \min_{x \in \Gamma} |x - z| \text{ and } \rho_e = \max_{x \in \Gamma} |x - z|.$$

Notice that  $\rho_i = \delta_{\Gamma}(z)$ .

We recall that if  $\Gamma$  is of class  $C^2$ ,  $\Omega$  has the properties of the uniform interior and exterior sphere condition, whose respective radii we have designated by  $r_i$  and  $r_e$ . In other words, there exists  $r_e > 0$  (resp.  $r_i > 0$ ) such that for each  $p \in \Gamma$  there exists a ball contained in  $\mathbb{R}^N \setminus \overline{\Omega}$  (resp. contained in  $\Omega$ ) of radius  $r_e$  (resp.  $r_i$ ) such that its closure intersects  $\Gamma$  only at p.

Also, if  $\Gamma$  is of class  $C^2$ , the unique solution of (1.1) is of class at least  $C^{1,\alpha}(\overline{\Omega})$ . Thus, we can define

<span id="page-4-2"></span>(2.2) 
$$M = \max_{\overline{\Omega}} |\nabla u| = \max_{\Gamma} u_{\nu}.$$

As shown in [MP1, Theorem 3.10], the following bound holds for M:

<span id="page-4-0"></span>
$$(2.3) M \le c_N \frac{d_{\Omega}(d_{\Omega} + r_e)}{r_e},$$

where  $c_N=3/2$  for N=2 and  $c_N=N/2$  for  $N\geq 3$ . Notice that, when  $\Omega$  is convex, we can choose  $r_e=+\infty$  in (2.3) and obtain

$$(2.4) M \le c_N d_{\Omega}.$$

More in general, up to a change of the constant  $c_N$ , (2.4) still holds true if  $\Gamma$  is a mean convex (i.e.,  $H \geq 0$ ) surface. This is a consequence of [CM, Lemma 2.2] and a trivial bound. Notice that even if [CM, Lemma 2.2] is stated for strictly mean convex surfaces (i.e., H > 0), the same proof still works under the weaker assumption  $H \geq 0$ .

For other similar estimates present in the literature, see [MP1, Remark 3.11]. For a set A and a function  $v: A \to \mathbb{R}$ ,  $v_A$  denotes the mean value of v in A that

<span id="page-4-1"></span>
$$v_A = \frac{1}{|A|} \int_A v \, dx.$$

Also, for a function  $v:\Omega\to\mathbb{R}$  we define

$$\|\delta^{\alpha}_{\Gamma} \nabla v\|_{p,\Omega} = \left(\sum_{i=1}^{N} \|\delta^{\alpha}_{\Gamma} v_i\|_{p,\Omega}^p\right)^{\frac{1}{p}} \quad \text{and} \quad \|\delta^{\alpha}_{\Gamma} \nabla^2 v\|_{p,\Omega} = \left(\sum_{i,j=1}^{N} \|\delta^{\alpha}_{\Gamma} v_{ij}\|_{p,\Omega}^p\right)^{\frac{1}{p}},$$

for  $0 \le \alpha \le 1$  and  $p \in [1, \infty)$ .

is

In the present section we prove the estimates (1.19) and (1.20). In order to fulfill this agenda, we first collect some useful estimates for harmonic functions that have their own interest. Then, we will deduce the desired inequalities for the particular harmonic function h = q - u.

The following lemma contains Hardy-Poincaré inequalities that can be deduced from the works of Hurri-Syrjänen [H1, H2]. We mention that [H2] was stimulated by the work of Boas and Straube [BS], which, in turn, improved on a result of Ziemer [Zi].

In order to state these results, we introduce the notions of  $b_0$ -John domain and  $L_0$ -John domain with base point  $z \in \Omega$ . Roughly speaking, a domain is a  $b_0$ -John domain (resp. a  $L_0$ -John domain with base point z) if it is possible to travel from one point of the domain to another (resp. from z to another point of the domain) without going too close to the boundary.

A domain  $\Omega$  in  $\mathbb{R}^N$  is a  $b_0$ -John domain,  $b_0 \geq 1$ , if each pair of distinct points a and b in  $\Omega$  can be joined by a curve  $\gamma : [0,1] \to \Omega$  such that

$$\delta_{\Gamma}(\gamma(t)) \ge b_0^{-1} \min\{|\gamma(t) - a|, |\gamma(t) - b|\}.$$

A domain  $\Omega$  in  $\mathbb{R}^N$  is a  $L_0$ -John domain with base point  $z \in \Omega$ ,  $L_0 \geq 1$ , if each point  $x \in \Omega$  can be joined to z by a curve  $\gamma : [0,1] \to \Omega$  such that

$$\delta_{\Gamma}(\gamma(t)) \geq L_0^{-1}|\gamma(t) - x|.$$

It is known that, for bounded domains, the two definitions are quantitatively equivalent (see [Va, Theorem 3.6]). The two notions could be also defined respectively through the so-called  $b_0$ -cigar and  $L_0$ -carrot properties (see [Va]).

<span id="page-5-0"></span>**Lemma 2.1.** Let  $\Omega \subset \mathbb{R}^N$  be a bounded  $b_0$ -John domain, and consider three numbers  $r, p, \alpha$  such that, either

<span id="page-5-1"></span>(2.5) 
$$1 \le p \le r \le \frac{N p}{N - p(1 - \alpha)}, \quad p(1 - \alpha) < N, \quad 0 \le \alpha \le 1,$$

or

$$(2.6) r = p \in [1, \infty), \quad \alpha = 0.$$

Then.

<span id="page-5-3"></span><span id="page-5-2"></span>(i) there exists a positive constant  $\mu_{r,p,\alpha}(\Omega,z)$ , such that

(2.7) 
$$||v||_{r,\Omega} \le \mu_{r,p,\alpha}(\Omega,z)^{-1} ||\delta_{\Gamma}^{\alpha} \nabla v||_{p,\Omega},$$

for every function v which is harmonic in  $\Omega$  and such that v(z) = 0;

<span id="page-5-4"></span>(ii) there exists a positive constant,  $\overline{\mu}_{r,p,\alpha}(\Omega)$  such that

(2.8) 
$$||v - v_{\Omega}||_{r,\Omega} \le \overline{\mu}_{r,p,\alpha}(\Omega)^{-1} ||\delta_{\Gamma}^{\alpha} \nabla v||_{p,\Omega},$$

for every function v which is harmonic in  $\Omega$ .

*Proof.* In [H2, Theorem 1.3] and [H1, Theorem 8.5] it is proved – if  $r, p, \alpha$  are as in (2.5) and (2.6), respectively – that there exists a constant  $c = c(N, r, p, \alpha, \Omega)$  such that

$$(2.9)$$

for every  $v \in L^1_{loc}(\Omega)$  such that  $\delta^{\alpha}_{\Gamma} \nabla v \in L^p(\Omega)$ . Here,  $v_{r,\Omega}$  denotes the r-mean of v in  $\Omega$  which is defined – following [IMW] – as the unique minimizer of the problem

<span id="page-5-5"></span>
$$\inf_{\lambda \in \mathbb{R}} \|v - \lambda\|_{r,\Omega}.$$

Notice that, in the case  $r=2, v_{2,\Omega}$  is the classical mean value of v in  $\Omega$ , i.e.  $v_{2,\Omega}=v_{\Omega}$ , as can be easily verified.

In order to obtain (2.7) and (2.8), we have just to manipulate the left-hand side of (2.9). To this aim, we exploit the following inequality

(2.10) 
$$||v - v_A||_{p,\Omega} \le \left[ 1 + \left( \frac{|\Omega|}{|A|} \right)^{\frac{1}{p}} \right] ||v - \lambda||_{p,\Omega},$$

that holds for every  $\lambda \in \mathbb{R}$ , if  $\Omega$  is a domain with finite measure,  $v \in L^p(\Omega)$ , and  $A \subseteq \Omega$  is a set of positive measure. Inequality (2.10) can be easily proved as follows. By Hölder's inequality, we have that

<span id="page-5-6"></span>
$$|v_A - \lambda| \le \frac{1}{|A|} \int_A |v - \lambda| \, dx \le |A|^{-1/p} ||v - \lambda||_{p,A} \le |A|^{-1/p} ||v - \lambda||_{p,\Omega}.$$

Since  $|v_A - \lambda|$  is constant, we then infer that

$$||v_A - \lambda||_{p,\Omega} = |\Omega|^{1/p} |v_A - \lambda| \le \left(\frac{|\Omega|}{|A|}\right)^{\frac{1}{p}} ||v - \lambda||_{p,\Omega}.$$

Thus, (2.10) follows by an application of the triangular inequality.

By using (2.10) with  $A = \Omega$  and  $\lambda = v_{r,\Omega}$ , from (2.9) we thus prove (2.8) for every  $v \in L^1_{loc}(\Omega)$  such that  $\delta^{\alpha}_{\Gamma} \nabla v \in L^p(\Omega)$ . The assumption of the harmonicity of v in (2.8) clearly gives a better constant.

Inequality (2.7) can be deduced from (2.8) by applying (2.10) with  $A = B_{\delta_{\Gamma}(z)}(z)$  and  $\lambda = v_{\Omega}$  and recalling that, since v is harmonic, by the mean value property it holds that  $v(z) = v_{B_{\delta_{\Gamma}(z)}(z)}$ .

The (solvable) variational problems

$$\mu_{r,p,\alpha}(\Omega,z) = \min \left\{ \|\delta_{\Gamma}^{\alpha} \nabla v\|_{p,\Omega} : \|v\|_{r,\Omega} = 1, \, \Delta v = 0 \text{ in } \Omega, \, v(z) = 0 \right\}$$

and

$$\overline{\mu}_{r,p,\alpha}(\Omega) = \min \left\{ \|\delta^{\alpha}_{\Gamma} \nabla v\|_{p,\Omega} : \|v\|_{r,\Omega} = 1, \, \Delta v = 0 \text{ in } \Omega, v_{\Omega} = 0 \right\}$$

then characterize the two constants.

<span id="page-6-0"></span>Remark 2.2. Notice that, by choosing r = p in (2.5) one has the restriction  $p(1-\alpha) < N$ , that does not appear in (2.6) (when  $\alpha = 0$ ). We point out that, as proved in [BS], if  $\Gamma$  is locally the graph of a function of class  $C^{0,\overline{\alpha}}$ ,  $0 \le \overline{\alpha} \le 1$ , then (2.7) and (2.8) still hold true when  $r = p \in [1, \infty)$  and  $0 \le \alpha \le \overline{\alpha}$  (again without the restriction  $p(1-\alpha) < N$ ). Anyway, in this paper we do not need this generalization. Also, exploiting the proofs of [H2, H1] has the benefit of building explicit estimates for the constants  $\mu_{r,p,\alpha}(\Omega,z)^{-1}$  and  $\overline{\mu}_{r,p,\alpha}(\Omega)^{-1}$  (see Remark 2.4).

From Lemma 2.1 we can derive estimates for the derivatives of harmonic functions, as follows.

<span id="page-6-2"></span>Corollary 2.3. Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded  $b_0$ -John domain and let v be a harmonic function in  $\Omega$ . Consider three numbers  $r, p, \alpha$  satisfying either (2.5) or (2.6).

(i) If z is a critical point of v in  $\Omega$ , then it holds that

$$\|\nabla v\|_{r,\Omega} \le \mu_{r,p,\alpha}(\Omega,z)^{-1} \|\delta_{\Gamma}^{\alpha} \nabla^2 v\|_{p,\Omega}.$$

(ii) If

$$\int_{\Omega} \nabla v \, dx = 0,$$

then it holds that

$$\|\nabla v\|_{r,\Omega} \leq \overline{\mu}_{r,n,\alpha}(\Omega)^{-1} \|\delta^{\alpha}_{\Gamma} \nabla^2 v\|_{p,\Omega}.$$

*Proof.* Since  $\nabla v(z) = 0$  (respectively  $\int_{\Omega} \nabla v \, dx = 0$ ,), we can apply (2.7) (respectively (2.8)) to each first partial derivative  $v_i$  of v, i = 1, ..., N. If we raise to the power of r those inequalities and sum over i = 1, ..., N, the conclusion easily follows in view of the inequality

$$\sum_{i=1}^{N} x_i^{\frac{r}{p}} \le \left(\sum_{i=1}^{N} x_i\right)^{\frac{r}{p}}$$

that holds for every  $(x_1, \ldots, x_N) \in \mathbb{R}^N$  with  $x_i \geq 0$  for  $i = 1, \ldots, N$ , since  $r/p \geq 1$ .

<span id="page-6-1"></span>Remark 2.4 (Tracing the geometric dependence of the constants). In this remark, we explain how to trace the dependence on a few geometrical parameters of the constants in the relevant inequalities.

(i) When  $r, p, \alpha$  are as in (2.5), the proof of [H2] gives an explicit upper bound for the constant c appearing in (2.9), from which, by following the steps of our

proof, we can deduce explicit estimates for  $\mu_{r,p,\alpha}(\Omega,z)^{-1}$  and  $\overline{\mu}_{r,p,\alpha}(\Omega)^{-1}$ . In fact, we easily show that

$$\overline{\mu}_{r,p,\alpha}(\Omega)^{-1} \le k_{N,\,r,\,p,\,\alpha} \, b_0^N |\Omega|^{\frac{1-\alpha}{N} + \frac{1}{r} - \frac{1}{p}},$$

$$\mu_{r,p,\alpha}(\Omega,z)^{-1} \le k_{N,\,r,\,p,\,\alpha} \, \left(\frac{b_0}{\delta_{\Gamma}(z)^{\frac{1}{r}}}\right)^N |\Omega|^{\frac{1-\alpha}{N} + \frac{2}{r} - \frac{1}{p}}.$$

A better estimate for  $\mu_{r,p,\alpha}(\Omega,z)$  can be obtained for  $L_0$ -John domains with base point z. Since the computations are tedious and technical we refer to [Po2, Lemma A.2 in Appendix A] and here we just report the final estimate, that is,

(2.11) 
$$\mu_{r,p,\alpha}(\Omega,z)^{-1} \le k_{N,r,p,\alpha} L_0^N |\Omega|^{\frac{1-\alpha}{N} + \frac{1}{r} - \frac{1}{p}}.$$

(ii) When  $r, p, \alpha$  are as in (2.6), then the proof of [H1, Theorem 8.5] gives an explicit upper bound for  $\overline{\mu}_{p,p,0}(\Omega)^{-1}$ , in terms of  $b_0$  and  $d_{\Omega}$  only. We warn the reader that the definition of John domain used there is different from the definitions that we gave in this paper, but it is equivalent in view of [MrS, Theorem 8.5]. Explicitly, by putting together [H1, Theorem 8.5] and [MrS, Theorem 8.5] one finds that

$$\overline{\mu}_{p,p,0}(\Omega)^{-1} \le k_{N,p} b_0^{3N(1+\frac{N}{p})} d_{\Omega}.$$

Reasoning as in the proof of (2.7), from this estimate one can also deduce a bound for  $\mu_{p,p,0}(\Omega,z)$ . In fact, by applying (2.10) with  $A=B_{\delta_{\Gamma}(z)}(z)$  and  $\lambda=v_{\Omega}$  and recalling the mean value property of v, from (2.8) and the bound for  $\overline{\mu}_{p,p,0}(\Omega)$ , we easily compute that

<span id="page-7-0"></span>
$$\mu_{p,p,0}(\Omega,z)^{-1} \le k_{N,p} \left(\frac{|\Omega|}{\delta_{\Gamma}(z)^N}\right)^{\frac{1}{r}} b_0^{3N(1+\frac{N}{p})} d_{\Omega}.$$

A better estimate for  $\mu_{p,p,0}(\Omega,z)$  can be obtained for  $L_0$ -John domains with base point z, that is,

(2.12) 
$$\mu_{p,p,0}(\Omega,z)^{-1} \le k_{N,p} L_0^{3N(1+\frac{N}{p})} d_{\Omega}.$$

Complete computations to obtain (2.12) can be found in [Po2, Lemma A.4 in Appendix A].

(iii) A domain of class  $C^2$  is obviously a  $b_0$ -John domain and a  $L_0$ -John domain with base point z for every  $z \in \Omega$ . In fact, by the definitions, it is not difficult to prove the following bounds

$$b_0 \le \frac{d_{\Omega}}{r_i},$$

$$L_0 \le \frac{d_{\Omega}}{\min[r_i, \delta_{\Gamma}(z)]}.$$

Thus, for  $C^2$ -domains items (i) and (ii) inform us that: when  $r, p, \alpha$  are as in (2.5), we have that

$$\overline{\mu}_{r,p,\alpha}(\Omega)^{-1} \le k_{N,r,p,\alpha} \left(\frac{d_{\Omega}}{r_i}\right)^N |\Omega|^{\frac{1-\alpha}{N} + \frac{1}{r} - \frac{1}{p}},$$

$$\mu_{r,p,\alpha}(\Omega,z)^{-1} \le k_{N,r,p,\alpha} \left(\frac{d_{\Omega}}{\min[r_i,\delta_{\Gamma}(z)]}\right)^N |\Omega|^{\frac{1-\alpha}{N} + \frac{1}{r} - \frac{1}{p}};$$

when  $r, p, \alpha$  are as in (2.6), we have that

$$\overline{\mu}_{p,p,0}(\Omega)^{-1} \le k_{N,p} \frac{d_{\Omega}^{3N(1+\frac{N}{p})+1}}{r_i^{3N(1+\frac{N}{p})}},$$

$$\mu_{p,p,0}(\Omega,z)^{-1} \le k_{N,p} \frac{d_{\Omega}^{3N(1+\frac{N}{p})+1}}{\min[r_i,\delta_{\Gamma}(z)]^{3N(1+\frac{N}{p})}}.$$

The next lemma, that modifies for our purposes an idea of W. Feldman [Fe], will be useful to bound the right-hand side of (1.7). We mention that the proof that we report here comes from [MP2].

<span id="page-8-2"></span>**Lemma 2.5** (A trace inequality for harmonic functions). Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$  and let v be a harmonic function in  $\Omega$ 

(i) If z is a critical point of v in  $\Omega$ , then it holds that

$$\int_{\Gamma} |\nabla v|^2 dS_x \le \frac{2}{r_i} \left( 1 + \frac{N}{r_i \, \mu_{2,2,\frac{1}{2}}(\Omega,z)^2} \right) \int_{\Omega} (-u) |\nabla^2 v|^2 dx.$$

(ii) If

$$\int_{\Omega} \nabla v \, dx = 0,$$

then it holds that

$$\int_{\Gamma} |\nabla v|^2 dS_x \le \frac{2}{r_i} \left( 1 + \frac{N}{r_i \, \overline{\mu}_{2,2,\frac{1}{2}}(\Omega)^2} \right) \int_{\Omega} (-u) |\nabla^2 v|^2 dx.$$

*Proof.* We begin with the following differential identity:

$$\operatorname{div} \{v^2 \nabla u - u \, \nabla(v^2)\} = v^2 \Delta u - u \, \Delta(v^2) = N \, v^2 - 2u \, |\nabla v|^2,$$

that holds for any v harmonic function in  $\Omega$ , if u is satisfies (1.1). Next, we integrate on  $\Omega$  and, by the divergence theorem, we get:

$$\int_{\Gamma} v^2 u_{\nu} dS_x = N \int_{\Omega} v^2 dx + 2 \int_{\Omega} (-u) |\nabla v|^2 dx.$$

We use this identity with  $v = v_i$ , and hence we sum up over i = 1, ..., N to obtain:

$$\int_{\Gamma} |\nabla v|^2 u_{\nu} dS_x = N \int_{\Omega} |\nabla v|^2 dx + 2 \int_{\Omega} (-u) |\nabla^2 v|^2 dx.$$

Since the term  $u_{\nu}$  at the left-hand side of the last identity can be bounded from below by  $r_i$ , by an adaptation of Hopf's lemma (see [MP1, Theorem 3.10]), it holds that

$$r_i \int_{\Gamma} |\nabla v|^2 dS_x \le N \int_{\Omega} |\nabla v|^2 dx + 2 \int_{\Omega} (-u) |\nabla^2 v|^2 dx.$$

Thus, the conclusion follows from this last formula, Corollary 2.3 with r=p=2 and  $\alpha=1/2$ , and (1.15).

We now single out the key lemma that will produce (1.19) and (1.20). It contains an inequality for the oscillation of a harmonic function v in terms of its  $L^p$ -norm and of a bound for its gradient. We point out that the following lemma is new and generalizes the estimates proved and used in [MP1, MP2] for p = 2.

To this aim, we define the parallel set as

<span id="page-8-1"></span>
$$\Omega_{\sigma} = \{ y \in \Omega : \delta_{\Gamma}(y) > \sigma \} \quad \text{for} \quad 0 < \sigma \le r_i.$$

<span id="page-8-0"></span>**Lemma 2.6.** Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$  and let v be a harmonic function in  $\Omega$  of class  $C^1(\overline{\Omega})$ . Let G be an upper bound for the gradient of v on  $\Gamma$ .

Then, there exist two constants  $a_{N,p}$  and  $\alpha_{N,p}$  depending only on N and p such that if

(2.13) 
$$||v - v_{\Omega}||_{p,\Omega} \le \alpha_{N,p} r_i^{\frac{N+p}{p}} G$$

holds, we have that

<span id="page-9-2"></span>(2.14) 
$$\max_{\Gamma} v - \min_{\Gamma} v \le a_{N,p} G^{\frac{N}{N+p}} \|v - v_{\Omega}\|_{p,\Omega}^{p/(N+p)}.$$

*Proof.* Since v is harmonic it attains its extrema on the boundary  $\Gamma$ . Let  $x_i$  and  $x_e$  be points in  $\Gamma$  that respectively minimize and maximize v on  $\Gamma$  and, for

$$0 < \sigma < r_i$$

define the two points in  $y_i, y_e \in \partial \Omega_{\sigma}$  by  $y_j = x_j - \sigma \nu(x_j), j = i, e$ .

<span id="page-9-1"></span>By the fundamental theorem of calculus we have that

(2.15) 
$$v(x_j) = v(y_j) + \int_0^\sigma \langle \nabla v(x_j - t\nu(x_j)), \nu(x_j) \rangle dt.$$

Since v is harmonic and  $y_j \in \overline{\Omega}_{\sigma}$ , j = i, e, we can use the mean value property for the balls with radius  $\sigma$  centered at  $y_j$  and obtain:

$$|v(y_j) - v_{\Omega}| \le \frac{1}{|B| \sigma^N} \int_{B_{\sigma}(y_j)} |v - v_{\Omega}| \, dy \le \frac{1}{[|B| \sigma^N]^{1/p}} \left[ \int_{B_{\sigma}(y_j)} |v - v_{\Omega}|^p \, dy \right]^{1/p} \le \frac{1}{[|B| \sigma^N]^{1/p}} \left[ \int_{\Omega} |v - v_{\Omega}|^p \, dy \right]^{1/p}$$

after an application of Hölder's inequality and by the fact that  $B_{\sigma}(y_j) \subseteq \Omega$ . This and (2.15) then yield that

$$\max_{\Gamma} v - \min_{\Gamma} v \leq 2 \, \left\lceil \frac{\|v - v_{\Omega}\|_{p,\Omega}}{|B|^{1/p} \, \sigma^{N/p}} + \sigma \, G \right\rceil,$$

for every  $0 < \sigma \le r_i$ . Here we used that  $|\nabla v|$  attains its maximum on  $\Gamma$ , being v harmonic.

Therefore, by minimizing the right-hand side of the last inequality, we can conveniently choose

$$\sigma = \left(\frac{N \|v - v_{\Omega}\|_{p,\Omega}}{p |B|^{1/p} G}\right)^{p/(N+p)}$$

and obtain (2.14), if  $\sigma \leq r_i$ ; (2.13) will then follow. The explicit computation immediately shows that

<span id="page-9-4"></span>(2.16) 
$$a_{N,p} = \frac{2(N+p)}{N^{\frac{N}{N+p}} p^{\frac{p}{N+p}} |B|^{\frac{1}{N+p}}} \quad \text{and} \quad \alpha_{N,p} = \frac{p}{N} |B|^{\frac{1}{p}}.$$

Notice that, the fact that (2.14) holds if (2.13) is verified, remains true even if we replace in (2.13) and (2.14)  $v_{\Omega}$  by any  $\lambda \in \mathbb{R}$ .

We now turn back our attention to the harmonic function h = q - u, and by exploiting (1.13) we now modify Lemma 2.6 to directly link  $\rho_e - \rho_i$  to the  $L^p$ -norm of h. We do it in the following lemma which generalizes to the case of any  $L^p$ -norm [MP1, Lemma 3.3], that holds for p = 2.

<span id="page-9-0"></span>**Lemma 2.7.** Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary of class  $C^2$ . Set h = q - u, where u is the solution of (1.1) and q is any quadratic polynomial as in (1.10) with  $z \in \Omega$ .

<span id="page-9-3"></span>Then, there exists a positive constant C such that

(2.17) 
$$\rho_e - \rho_i \le C \|h - h_\Omega\|_{p,\Omega}^{p/(N+p)}.$$

The constant C depends on N, p,  $d_{\Omega}$ ,  $r_i$ ,  $r_e$ . If  $\Gamma$  is mean convex the dependence on  $r_e$  can be removed.

*Proof.* By direct computations it is easy to check that

$$|\nabla h| \le M + d_{\Omega}$$
 on  $\overline{\Omega}$ ,

where M is the maximum of  $|\nabla u|$  on  $\overline{\Omega}$ , as defined in (2.2). Thus, we can apply Lemma 2.6 with v = h and  $G = M + d_{\Omega}$ . By means of (1.13) we deduce that (2.17) holds with

(2.18) 
$$C = 2 a_{N,p} \frac{(M + d_{\Omega})^{\frac{N}{N+p}}}{r_i}$$

if

<span id="page-10-1"></span>
$$||h - h_{\Omega}||_{p,\Omega} \le \alpha_{N,p} (M + d_{\Omega}) r_i^{\frac{N+p}{p}}.$$

Here,  $a_{N,p}$  and  $\alpha_{N,p}$  are the constants defined in (2.16). On the other hand, if

$$||h - h_{\Omega}||_{p,\Omega} > \alpha_{N,p} (M + d_{\Omega}) r_i^{\frac{N+p}{p}},$$

it is trivial to check that (2.17) is verified with

$$C = \frac{d_{\Omega}}{\left[\alpha_{N,p} \left(M + d_{\Omega}\right)\right]^{\frac{p}{N+p}} r_{i}}.$$

Thus, (2.17) always holds true if we choose the maximum between this constant and that in (2.18). We then can easily see that the following constant will do:

$$C = \max\left\{2 \, a_{N,p}, \alpha_{N,p}^{-\frac{p}{N+p}}\right\} \frac{d_{\Omega}^{\frac{N}{N+p}}}{r_i} \left(1 + \frac{M}{d_{\Omega}}\right)^{\frac{N}{N+p}}.$$

Now, by means of (2.3), we obtain the constant

$$C = \max\left\{2 \, a_{N,p}, \alpha_{N,p}^{-\frac{p}{N+p}}\right\} \frac{d_{\Omega}^{\frac{N}{N+p}}}{r_i} \left(1 + c_N \, \frac{d_{\Omega} + r_e}{r_e}\right)^{\frac{N}{N+p}}.$$

If  $\Gamma$  is mean convex, the dependence on  $r_e$  can be avoided and we can choose

$$C = (1 + c_N)^{\frac{N}{N+p}} \max \left\{ 2 a_{N,p}, \alpha_{N,p}^{-\frac{p}{N+p}} \right\} \frac{d_{\Omega}^{\frac{N}{N+p}}}{r_i},$$

in light of (2.4).

For Serrin's overdetermined problem, Theorem 2.8 below will be crucial. There, we associate the oscillation of h, and hence  $\rho_e - \rho_i$ , with the weighted  $L^2$ -norm of its Hessian matrix.

To this aim, we now choose the center z of the quadratic polynomial q in (1.10) to be a global minimum point of u, that is always attained in  $\Omega$ . With this choice we have that  $\nabla h(z) = 0$ . We emphasize that the result that we present here improves (for every  $N \geq 2$ ) the exponents of estimates obtained in [MP2].

<span id="page-10-0"></span>**Theorem 2.8.** Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$  and  $z \in \Omega$  be a global minimum point of the solution u of (1.1). Consider the function h = q - u, with q given by (1.10).

<span id="page-10-2"></span>There exists a positive constant C such that

(2.19) 
$$\rho_e - \rho_i \le C \|\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h\|_{2,\Omega}^{\tau_N},$$

with the following specifications:

- (i)  $\tau_2 = 1$ ;
- (ii)  $\tau_3$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (2.19) holds with  $\tau_3 = 1 \theta$ ;
- (iii)  $\tau_N = 2/(N-1)$  for  $N \ge 4$ .

The constant C depends on N,  $r_i$ ,  $r_e$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=3). If  $\Gamma$  is mean convex the dependence on  $r_e$  can be removed.

*Proof.* For the sake of clarity, we will always use the letter c to denote the constants in all the inequalities appearing in the proof. Their explicit computation will be clear by following the steps of the proof.

(i) Let N=2. By the Sobolev immersion theorem (for instance we apply [Fr, Theorem 9.1] to  $h-h_{\Omega}$ ), we deduce that there is a constant c such that,

(2.20) 
$$\max_{\overline{\Omega}} |h - h_{\Omega}| \le c \|h - h_{\Omega}\|_{W^{1,4}(\Omega)}.$$

Applying (2.8) with v = h, r = p = 4, and  $\alpha = 0$  leads to

<span id="page-11-0"></span>
$$||h - h_{\Omega}||_{W^{1,4}(\Omega)} \le c ||\nabla h||_{4,\Omega}.$$

Since  $\nabla h(z) = 0$ , we can apply item (i) of Corollary 2.3 with r = 4, p = 2, and  $\alpha = 1/2$  to h and obtain that

$$\|\nabla h\|_{4,\Omega} \le c \, \|\delta_{\Gamma}^{\frac{1}{2}} \, \nabla^2 h\|_{2,\Omega}.$$

Thus, we have that

$$||h - h_{\Omega}||_{W^{1,4}(\Omega)} \le c ||\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h||_{2,\Omega}.$$

By using the last inequality together with (2.20) we have that

$$\max_{\Gamma} h - \min_{\Gamma} h \le c \|\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h\|_{2,\Omega}.$$

Thus, by recalling (1.13) we get that (2.19) holds with  $\tau_2 = 1$ .

(ii) Let N=3. By applying to the function h (2.8) with  $r=\frac{3(1-\theta)}{\theta}, p=3(1-\theta),$   $\alpha=0$ , and item (i) of Corollary 2.3 with  $r=3(1-\theta), p=2, \alpha=1/2$ , we get

$$||h - h_{\Omega}||_{\frac{3(1-\theta)}{\Omega}} \le c ||\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h||_{2,\Omega}.$$

Thus, by recalling Lemma 2.7 we have that (2.19) holds true with  $\tau_3 = 1 - \theta$ .

(iii) Let  $N \ge 4$ . Since  $\nabla h(z) = 0$ , we can apply to h item (i) of Corollary 2.3 with  $r = \frac{2N}{N-1}$ , p = 2,  $\alpha = 1/2$ , and obtain that

$$\|\nabla h\|_{\frac{2N}{N-1},\Omega} \le c \|\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h\|_{2,\Omega}.$$

Being  $N \ge 4$ , we can apply (2.8) with  $v = h, r = \frac{2N}{N-3}, p = \frac{2N}{N-1}, \alpha = 0$ , and get

$$||h - h_{\Omega}||_{\frac{2N}{N-3}} \le c ||\nabla h||_{\frac{2N}{N-1},\Omega}.$$

Thus,

$$||h - h_{\Omega}||_{\frac{2N}{N-3}} \le c ||\delta_{\Gamma}^{\frac{1}{2}} \nabla^2 h||_{2,\Omega},$$

and by Lemma 2.7 we get that (2.19) holds with  $\tau_N = 2/(N-1)$ .

<span id="page-11-2"></span>**Remark 2.9** (On the constant C). The constant C can be shown to depend only on the parameters mentioned in the statement of Theorem 2.8. In fact, the parameters  $\mu_{r,p,\alpha}(\Omega,z)$  and  $\overline{\mu}_{r,p,\alpha}(\Omega)$ , can be estimated by using item (iii) of Remark 2.4. To remove the dependence on the volume, then one can use the trivial bound

<span id="page-11-1"></span>
$$|\Omega|^{1/N} \le |B|^{1/N} d_{\Omega}/2.$$

The dependence on  $\delta_{\Gamma}(z)$  can instead be removed by means of the bound

(2.21) 
$$\delta_{\Gamma}(z) \ge \frac{r_i^2}{2M}.$$

To prove (2.21), we choose  $x \in \Omega$  such that  $\delta_{\Gamma}(x) = r_i$ ,  $y \in \Gamma$  such that  $\delta_{\Gamma}(z) = |y - z|$ , and obtain the chain of inequalities

$$\frac{r_i^2}{2} \le -u(x) \le \max_{\overline{\Omega}}(-u) = -u(z) = u(y) - u(z) \le M \,\delta_{\Gamma}(z).$$

Here, the first inequality follows from (1.15) and, as usual, M is defined by (2.2) and can be estimated with the help of (2.3) (or (2.4) if  $\Gamma$  is mean convex). We mention that in the convex case an alternative estimate for  $\delta_{\Gamma}(z)$  could also be obtained by exploiting [BMS], as explained in [Po2, Remark 3.21].

We recall that if  $\Omega$  satisfies the cone property (for the definition see [Fr, Chapter 9]), the immersion constant (appearing in (2.20)) depends only on N and the two parameters of the cone property (see [Fr, Theorem 9.1]). In our case  $\Omega$  satisfies the uniform interior sphere condition, and hence the two parameters of the cone property can be easily estimated in terms of  $r_i$ .

In the case of Alexandrov's Soap Bubble Theorem, we have to deal with (1.8) or (3.4), which simply entail the unweighted  $L^2$ -norm of the Hessian of h. Thus, the appropriate result in this case is Theorem 2.10 below, in which we improve (for every  $N \geq 4$ ) the exponents of estimates obtained in [MP1].

<span id="page-12-0"></span>**Theorem 2.10.** Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$  and  $z \in \Omega$  be a global minimum point of the solution u of (1.1). Consider the function h = q - u, with q given by (1.10).

<span id="page-12-1"></span>There exists a positive constant C such that

$$(2.22)$$

with the following specifications:

- (i)  $\tau_N = 1 \text{ for } N = 2 \text{ or } 3;$
- (ii)  $\tau_4$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (2.22) holds with  $\tau_4 = 1 \theta$ ;
- (iii)  $\tau_N = 2/(N-2)$  for  $N \ge 5$ .

The constant C depends on N,  $r_i$ ,  $r_e$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=4). If  $\Gamma$  is mean convex the dependence on  $r_e$  can be removed.

*Proof.* As done in the proof of Theorem 2.8, for the sake of clarity, we will always use the letter c to denote the constants in all the inequalities appearing in the proof. Their explicit computation will be clear by following the steps of the proof. By reasoning as described in Remark 2.9, one can easily check that those constants depend only on the geometric parameters of  $\Omega$  mentioned in the statement of the theorem.

(i) Let N=2 or 3. By the Sobolev immersion theorem (for instance we apply [Fr, Theorem 9.1] to  $h-h_{\Omega}$ ), we deduce that there is a constant c such that,

(2.23) 
$$\max_{\overline{\Omega}} |h - h_{\Omega}| \le c \|h - h_{\Omega}\|_{W^{2,2}(\Omega)}.$$

Since  $\nabla h(z) = 0$ , we can apply item (i) of Corollary 2.3 with r = p = 2 and  $\alpha = 0$  to h and obtain that

<span id="page-12-2"></span>
$$\int_{\Omega} |\nabla h|^2 dx \le c \int_{\Omega} |\nabla^2 h|^2 dx.$$

Using this last inequality together with (2.8) with  $v=h,\,r=p=2,\,\alpha=0,$  leads to

$$||h - h_{\Omega}||_{W^{2,2}(\Omega)} \le c ||\nabla^2 h||_{2,\Omega}.$$

Hence, by using (2.23) we get that

$$\max_{\Gamma} h - \min_{\Gamma} h \le c \, \|\nabla^2 h\|_{2,\Omega}.$$

Thus, by recalling (1.13) we get that (2.22) holds with  $\tau_N = 1$ .

(ii) Let N=4. By applying (2.8) with  $r=\frac{4(1-\theta)}{\theta},\ p=4(1-\theta),\ \alpha=0,$  and item (i) of Corollary 2.3 with  $r=4(1-\theta),\ p=2,\ \alpha=0,$  for v=h we get

$$||h - h_{\Omega}||_{\frac{4(1-\theta)}{\alpha},\Omega} \le c ||\nabla^2 h||_{2,\Omega}.$$

Thus, by Lemma 2.7 we conclude that (2.22) holds with  $\tau_4=1-\theta$ . (iii) Let  $N\geq 5$ . Applying (2.8) with  $r=\frac{2N}{N-4},\ p=\frac{2N}{N-2},\ \alpha=0,$  and item (i) of Corollary 2.3 with  $r=\frac{2N}{N-2},\ p=2,\ \alpha=0,$  by choosing v=h we get that

$$||h - h_{\Omega}||_{\frac{2N}{N-4}, \Omega} \le c ||\nabla^2 h||_{2,\Omega}.$$

By Lemma 2.7, we have that (2.22) holds true with  $\tau_N = 2/(N-2)$ . 

Other possible choices for the point z are described in the next remark.

**Remark 2.11.** (i) We can choose z as the center of mass of  $\Omega$ . In fact, if z is the center of mass of  $\Omega$ , we have that

$$\int_{\Omega} \nabla h(x) dx = \int_{\Omega} [x - z - \nabla u(x)] dx =$$

$$\int_{\Omega} x dx - |\Omega| z - \int_{\Gamma} u(x) \nu(x) dS_x = 0.$$

Thus, we can use item (ii) of Corollary 2.3 instead of item (i). In this way, in the estimates of Theorems 2.8 and 2.10 we simply obtain the same constants with  $\mu_{r,p,\alpha}(\Omega,z)$  replaced by  $\overline{\mu}_{r,p,\alpha}(\Omega)$ .

It should be noticed that, in this case the extra assumption that  $z \in \Omega$  is needed, since we want that the ball  $B_{\rho_i}(z)$  be contained in  $\Omega$ .

(ii) Following [Fe], another possible way to choose z is  $z = x_0 - \nabla u(x_0)$ , where  $x_0 \in \Omega$  is any point such that  $\delta_{\Gamma}(x_0) \geq r_i$ . In fact, we obtain that  $\nabla h(x_0) = 0$  and we can thus use (2.7), with  $\mu_{r,p,\alpha}(\Omega,z)$  replaced by  $\mu_{r,p,\alpha}(\Omega,x_0)$ .

As in item (i), we should additionally require that  $z \in \Omega$ , to be sure that the ball  $B_{\rho_i}(z)$  be contained in  $\Omega$ .

### 3. Stability results

In this section, we collect our results on the stability of the spherical configuration by putting together the identities presented in the introduction and already obtained in [MP1, MP2] with the new estimates obtained in Section 2.

3.1. Stability for Serrin's overdetermined problem. By using (1.12), (1.7) can be rewritten in terms of the harmonic function h as

<span id="page-13-1"></span>(3.1) 
$$\int_{\Omega} (-u) |\nabla^2 h|^2 dx = \frac{1}{2} \int_{\Gamma} (R^2 - u_{\nu}^2) h_{\nu} dS_x.$$

In light of (1.15), Theorem 2.8 gives an estimate from below of the left-hand side of (3.1). Now, we will take care of its right-hand side and prove our main result for Serrin's problem. The result that we present here, improves (for every N > 2) the exponents in the estimate obtained in [MP2, Theorem 1.1].

<span id="page-13-0"></span>**Theorem 3.1** (Stability for Serrin's problem). Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$  and R be the constant defined in (1.9). Let ube the solution of problem (1.1) and  $z \in \Omega$  be a global minimum point.

<span id="page-13-2"></span>There exists a positive constant C such that

(3.2) 
$$\rho_e - \rho_i \le C \|u_\nu - R\|_{2,\Gamma}^{\tau_N},$$

with the following specifications:

(i) 
$$\tau_2 = 1$$
;

(ii)  $\tau_3$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (3.2) holds with  $\tau_3 = 1 - \theta$ ;

(iii) 
$$\tau_N = 2/(N-1)$$
 for  $N \ge 4$ .

The constant C depends on N,  $r_i$ ,  $r_e$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=3). If  $\Gamma$ is mean convex the dependence on  $r_e$  can be removed.

*Proof.* We have that

$$\int_{\Gamma} (R^2 - u_{\nu}^2) h_{\nu} dS_x \le (M + R) \|u_{\nu} - R\|_{2,\Gamma} \|h_{\nu}\|_{2,\Gamma},$$

after an an application of Hölder's inequality. Thus, by item (i) of Lemma 2.5 with v = h, (3.1), and this inequality, we infer that

$$||h_{\nu}||_{2,\Gamma}^{2} \leq \frac{2}{r_{i}} \left( 1 + \frac{N}{r_{i} \mu_{2,2,\frac{1}{2}}(\Omega,z)^{2}} \right) \int_{\Omega} (-u) |\nabla^{2}h|^{2} dx \leq \frac{M+R}{r_{i}} \left( 1 + \frac{N}{r_{i} \mu_{2,2,\frac{1}{2}}(\Omega,z)^{2}} \right) ||u_{\nu} - R||_{2,\Gamma} ||h_{\nu}||_{2,\Gamma},$$

and hence

<span id="page-14-1"></span>(3.3) 
$$||h_{\nu}||_{2,\Gamma} \leq \frac{M+R}{r_i} \left( 1 + \frac{N}{r_i \, \mu_{2,2,\frac{1}{2}}(\Omega,z)^2} \right) ||u_{\nu} - R||_{2,\Gamma}.$$

Therefore,

$$\int_{\Omega} |\nabla^2 h|^2 \delta_{\Gamma}(x) \, dx \le \frac{2}{r_i} \int_{\Omega} (-u) |\nabla^2 h|^2 dx \le \left( \frac{M+R}{r_i} \right)^2 \left( 1 + \frac{N}{r_i \, \mu_{2,2,\frac{1}{2}}(\Omega,z)^2} \right) \|u_{\nu} - R\|_{2,\Gamma}^2,$$

by (1.15). These inequalities and Theorem 2.8 then give the desired conclusion. We recall that  $\mu_{2,2,\frac{1}{2}}(\Omega,z)$  appearing in the constant in the last inequality can be estimated in terms of  $d_{\Omega}$  and  $r_i$  by proceeding as described in Remark 2.9. The ratio R can be estimated (from above) in terms of  $|\Omega|^{1/N}$  – just by using the isoperimetric inequality; in turn,  $|\Omega|^{1/N}$  can be bounded in terms of  $d_{\Omega}$  by proceeding as described in Remark 2.9. Finally, as usual, M can be estimated by means of (2.3).

If we want to measure the deviation of  $u_{\nu}$  from R in L<sup>1</sup>-norm, we get a smaller (reduced by one half) stability exponent. The following result improves [MP2, Theorem 3.6].

<span id="page-14-0"></span>**Theorem 3.2** (Stability with  $L^1$ -deviation). Theorem 3.1 still holds with (3.2) replaced by

$$\rho_e - \rho_i \le C \|u_\nu - R\|_{1,\Gamma}^{\tau_N/2}.$$

*Proof.* Instead of applying Hölder's inequality to the right-hand side of (3.1), we just use the rough bound:

$$\int_{\Omega} (-u) |\nabla^2 h|^2 dx \le \frac{1}{2} (M+R) (M+d_{\Omega}) \int_{\Gamma} |u_{\nu} - R| dS_x,$$

since  $(u_{\nu}+R)|h_{\nu}| \leq (M+R)(M+d_{\Omega})$  on  $\Gamma$ . The conclusion then follows from similar arguments.

Remark 3.3. The estimates presented in Theorems 3.1, 3.2 may be interpreted as stability estimates, once that we fixed some a priori bounds on the relevant parameters: here, we just illustrate the case of Theorem 3.1. Given two positive constants  $\overline{d}$  and  $\underline{r}$ , let  $\mathcal{D} = \mathcal{D}(\overline{d},\underline{r})$  be the class of bounded domains  $\Omega \subset \mathbb{R}^N$  with boundary of class  $C^2$ , such that

$$d_{\Omega} \leq \overline{d}, \quad r_i(\Omega), \ r_e(\Omega) \geq \underline{r}.$$

Then, for every  $\Omega \in \mathcal{D}$ , we have that

$$\rho_e - \rho_i \le C \|u_\nu - R\|_{2,\Gamma}^{\tau_N},$$

where  $\tau_N$  is that appearing in (3.2) and C is a constant depending on N,  $\overline{d}$ ,  $\underline{r}$  (and  $\theta$  only in the case N=3).

If we relax the a priori assumption that  $\Omega \in \mathcal{D}$  (in particular if we remove the lower bound  $\underline{r}$ ), it may happen that, as the deviation  $||u_{\nu} - R||_{2,\Gamma}$  tends to 0,  $\Omega$  tends to the ideal configuration of two or more disjoint balls, while C diverges since  $\underline{r}$  tends to 0. The configuration of more balls connected with tiny (but arbitrarily long) tentacles has been quantitatively studied in [BNST].

3.2. Stability for Alexandrov's Soap Bubble Theorem. This section is devoted to the stability issue for the Soap Bubble Theorem.

As we have already noticed in [MP2, Theorem 2.4], the right-hand side of (1.8) can be rewritten as

$$\int_{\Gamma} (H_0 - H) (u_{\nu} - q_{\nu}) u_{\nu} dS_x + \int_{\Gamma} (H_0 - H) (u_{\nu} - R) q_{\nu} dS_x.$$

Hence, by recalling (1.12), (1.8) becomes

<span id="page-15-0"></span>(3.4) 
$$\frac{1}{N-1} \int_{\Omega} |\nabla^2 h|^2 dx + \frac{1}{R} \int_{\Gamma} (u_{\nu} - R)^2 dS_x = -\int_{\Gamma} (H_0 - H) h_{\nu} u_{\nu} dS_x + \int_{\Gamma} (H_0 - H) (u_{\nu} - R) q_{\nu} dS_x.$$

Next, we derive the following lemma, that parallels and is a useful consequence of Lemma 2.5.

<span id="page-15-2"></span>**Lemma 3.4.** Let  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ , be a bounded domain with boundary  $\Gamma$  of class  $C^2$ . Denote by H the mean curvature of  $\Gamma$  and let  $H_0$  be the constant defined in (1.9).

<span id="page-15-1"></span>Then, the following inequality holds:

$$(3.5) \|u_{\nu} - R\|_{2,\Gamma} \le R \left\{ d_{\Omega} + \frac{M(M+R)}{r_i} \left( 1 + \frac{N}{r_i \,\mu_{2,2,\frac{1}{2}}(\Omega,z)^2} \right) \right\} \|H_0 - H\|_{2,\Gamma}.$$

*Proof.* Discarding the first summand on the left-hand side of (3.4) and applying Hölder's inequality on its right-hand side gives that

$$\frac{1}{R} \|u_{\nu} - R\|_{2,\Gamma}^2 \le \|H_0 - H\|_{2,\Gamma} \left(M \|h_{\nu}\|_{2,\Gamma} + d_{\Omega} \|u_{\nu} - R\|_{2,\Gamma}\right),\,$$

since  $u_{\nu} \leq M$  and  $|q_{\nu}| \leq d_{\Omega}$  on  $\Gamma$ . Thus, inequality (3.3) implies that

$$||u_{\nu} - R||_{2,\Gamma}^2 \le$$

$$R\left\{d_{\Omega} + \frac{M(M+R)}{r_i}\left(1 + \frac{N}{r_i\,\mu_{2,2,\frac{1}{2}}(\Omega,z)^2}\right)\right\} \|H_0 - H\|_{2,\Gamma} \|u_{\nu} - R\|_{2,\Gamma},$$

from which (3.5) follows at once.

We are now ready to prove our main result for Alexandrov's Soap Bubble Theorem. The result that we present here, improves (for every  $N \ge 4$ ) the exponents of estimates obtained in [MP2, Theorem 1.2].

<span id="page-16-0"></span>**Theorem 3.5** (Stability for the Soap Bubble Theorem). Let  $N \geq 2$  and let  $\Gamma$  be a surface of class  $C^2$ , which is the boundary of a bounded domain  $\Omega \subset \mathbb{R}^N$ . Denote by H the mean curvature of  $\Gamma$  and let  $H_0$  be the constant defined in (1.9).

<span id="page-16-2"></span>Then, for some point  $z \in \Omega$  there exists a positive constant C such that

(3.6) 
$$\rho_e - \rho_i \le C \|H_0 - H\|_{2.\Gamma}^{\tau_N},$$

with the following specifications:

- (i)  $\tau_N = 1 \text{ for } N = 2 \text{ or } 3;$
- (ii)  $\tau_4$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (3.6) holds with  $\tau_4 = 1 \theta$ ;
- (iii)  $\tau_N = 2/(N-2)$  for  $N \ge 5$ .

The constant C depends on N,  $r_i$ ,  $r_e$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=4). If  $\Gamma$  is mean convex the dependence on  $r_e$  can be removed.

*Proof.* As before, we choose  $z \in \Omega$  to be a global minimum point of u. Discarding the second summand on the left-hand side of (3.4) and applying Hölder's inequality on its right-hand side, as in the previous proof, gives that

$$\frac{1}{N-1} \int_{\Omega} |\nabla^{2} h|^{2} dx \leq R \left\{ d_{\Omega} + \frac{M(M+R)}{r_{i}} \left( 1 + \frac{N}{r_{i} \mu_{2,2,\frac{1}{2}}(\Omega,z)^{2}} \right) \right\} \|H_{0} - H\|_{2,\Gamma} \|u_{\nu} - R\|_{2,\Gamma}, \leq R^{2} \left\{ d_{\Omega} + \frac{M(M+R)}{r_{i}} \left( 1 + \frac{N}{r_{i} \mu_{2,2,\frac{1}{2}}(\Omega,z)^{2}} \right) \right\}^{2} \|H_{0} - H\|_{2,\Gamma}^{2},$$

where the second inequality follows from Lemma 3.4.

The conclusion then follows from Theorem 2.10.

**Remark 3.6.** Estimates similar to those of Theorem 3.5 can also be obtained as a direct corollary of Theorem 3.1, by means of (3.5). As it is clear, in this way the exponents  $\tau_N$  would be worse than those obtained in Theorem 3.5.

We now present a stability result with a weaker deviation (at the cost of getting a smaller stability exponent), analogous to Theorem 3.2. To this aim, we notice that from (1.8) and (1.12) we can easily deduce the following inequality

<span id="page-16-4"></span>
$$(3.7) \quad \frac{1}{N-1} \int_{\Omega} |\nabla^2 h|^2 dx + \int_{\Gamma} (H_0 - H)^- (u_{\nu})^2 dS_x \le \int_{\Gamma} (H_0 - H)^+ (u_{\nu})^2 dS_x$$

(here, we use the positive and negative part functions  $(t)^+ = \max(t,0)$  and  $(t)^- = \max(-t,0)$ ). That inequality tells us that, if we have an *a priori* bound M for  $u_{\nu}$  on  $\Gamma$ , then its left-hand side is small if the integral

$$(3.8) \qquad \int_{\Gamma} (H_0 - H)^+ dS_x$$

is also small. It is clear that (3.8) is a deviation weaker than  $||H_0 - H||_{1,\Gamma}$ .

The result that we present here, improves (for every  $N \geq 4$ ) the estimates obtained in [MP1, Theorem 4.1].

<span id="page-16-1"></span>**Theorem 3.7** (Stability with  $L^1$ -type deviation). Theorem 3.5 still holds with (3.6) replaced by

<span id="page-16-3"></span>
$$\rho_e - \rho_i \le C \left\{ \int_{\Gamma} (H_0 - H)^+ dS_x \right\}^{\tau_N/2}.$$

*Proof.* From (3.7), we infer that

$$\|\nabla^2 h\|_{2,\Omega} \le M\sqrt{N-1} \left\{ \int_{\Gamma} (H_0 - H)^+ dS_x \right\}^{1/2}$$

The conclusion then follows from Theorem 2.10.

**Remark 3.8.** The estimates presented in Theorems 3.5, 3.7 may be interpreted as stability estimates, once some a priori information is available: here, we just illustrate the case of Theorem 3.5. Given two positive constants  $\overline{d}$  and  $\underline{r}$ , let  $S = S(\overline{d},\underline{r})$  be the class of connected surfaces  $\Gamma \subset \mathbb{R}^N$  of class  $C^2$ , where  $\Gamma$  is the boundary of a bounded domain  $\Omega$ , such that

$$d_{\Omega} \leq \overline{d}, \quad r_i(\Omega), \ r_e(\Omega) \geq \underline{r}.$$

Then, for every  $\Gamma \in \mathcal{S}$  we have that

$$\rho_e - \rho_i \le C \|H_0 - H\|_{2,\Gamma}^{\tau_N},$$

where  $\tau_N$  is that appearing in (3.6) and the constant C depends on N,  $\overline{d}$ ,  $\underline{r}$  (and  $\theta$  only in the case N=4).

If we relax the a priori assumption that  $\Gamma \in \mathcal{S}$  (in particular if we remove the lower bound  $\underline{r}$ ), it may happen that, as the deviation  $\|H_0 - H\|_{2,\Gamma}$  tends to 0,  $\Omega$  tends to the ideal configuration of two or more mutually tangent balls, while C diverges since  $\underline{r}$  tends to 0. Such a configuration can be observed, for example, as limit of sets created by truncating (and then smoothly completing) unduloids with very thin necks. This phenomenon (called bubbling) has been quantitatively studied in [CM] by considering strictly mean convex surfaces and by using the uniform deviation  $\|H_0 - H\|_{\infty,\Gamma}$ .

3.3. Other related stability results. As already noticed in [MP1, Theorem 2.6], if  $\Gamma$  is mean-convex, that is  $H \geq 0$ , (1.8) can also be rearranged into the following identity:

<span id="page-17-0"></span>
$$(3.9) \quad \frac{1}{N-1} \int_{\Omega} \left\{ |\nabla^2 u|^2 - \frac{(\Delta u)^2}{N} \right\} dx + \int_{\Gamma} \frac{(1-Hu_{\nu})^2}{H} dS_x = \int_{\Gamma} \frac{dS_x}{H} - N|\Omega|.$$

Such identity leads to Heintze-Karcher's inequality ([HK]):

<span id="page-17-1"></span>
$$(3.10) \qquad \int_{\Gamma} \frac{dS_x}{H} \ge N|\Omega|.$$

In fact, since both summands at the left-hand side of (3.9) are non-negative, Heintze-Karcher's inequality (3.10) holds and the equality sign is attained if and only if  $\Omega$  is a ball. In fact, if the right-hand side of (3.9) is zero, both summands at the left-hand side must be zero, and the vanishing of the first summand implies that  $\Omega$  is a ball, as already noticed.

Thus, by putting together the identity (3.9) and the tools developed in Section 2 we obtain a stability result for Heintze-Karcher's inequality. The following theorem improves (for every  $N \ge 4$ ) the exponents obtained in [MP1, Theorem 4.5].

<span id="page-17-3"></span>**Theorem 3.9** (Stability for Heintze-Karcher's inequality). Let  $\Gamma$  be a surface of class  $C^2$ , which is the boundary of a bounded domain  $\Omega \subset \mathbb{R}^N$ ,  $N \geq 2$ . Denote by H its mean curvature and suppose that H > 0 on  $\Gamma$ .

<span id="page-17-2"></span>Then, there exist a point  $z \in \Omega$  and a positive constant C such that

(3.11) 
$$\rho_e - \rho_i \le C \left( \int_{\Gamma} \frac{dS_x}{H} - N |\Omega| \right)^{\tau_N/2},$$

with the following specifications:

(i) 
$$\tau_N = 1 \text{ for } N = 2 \text{ or } 3;$$

(ii)  $\tau_4$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (3.11) holds with  $\tau_4 = 1 - \theta$ ;

(iii) 
$$\tau_N = 2/(N-2)$$
 for  $N \ge 5$ .

The constant C depends on N,  $r_i$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=4).

*Proof.* As before, we choose  $z \in \Omega$  to be a global minimum point of u. Moreover, by (3.9) and (3.10), we have that

$$\frac{1}{N-1} \int_{\Omega} |\nabla^2 h|^2 dx \le \int_{\Gamma} \frac{dS_x}{H} - N |\Omega|.$$

Thus, the conclusion follows from Theorem 2.10.

Since the deficit of Heintze-Karcher's inequality can be written as

$$\int_{\Gamma} \frac{dS_x}{H} - N |\Omega| = \int_{\Gamma} \left( \frac{1}{H} - u_{\nu} \right) dS_x,$$

where u is always the solution of (1.1), Theorem 3.9 also gives symmetry and stability for the boundary value problem (1.1) under the overdetermination

$$(3.12) u_{\nu} = \frac{1}{H},$$

as stated next. It is clear that the deviation  $\int_{\Gamma} (1/H - u_{\nu}) dS_x$  is weaker than  $||1/H - u_{\nu}||_{1,\Gamma}$ . The following theorem improves [MP1, Theorem 4.8].

**Theorem 3.10** (Stability for a related overdetermined problem). Let  $\Gamma$ ,  $\Omega$ , and H be as in Theorem 3.9. Let u be the solution of problem (1.1) and  $z \in \Omega$  be a global minimum point of u.

<span id="page-18-5"></span>There exists a positive constant C such that

(3.13) 
$$\rho_e - \rho_i \le C \left\{ \int_{\Gamma} \left( \frac{1}{H} - u_{\nu} \right) dS_x \right\}^{\tau_N/2},$$

with the following specifications:

- (i)  $\tau_N = 1 \text{ for } N = 2 \text{ or } 3;$
- (ii)  $\tau_4$  is arbitrarily close to one, in the sense that for any  $\theta > 0$ , there exists a positive constant C such that (3.13) holds with  $\tau_4 = 1 \theta$ ;
- (iii)  $\tau_N = 2/(N-2)$  for  $N \ge 5$ .

The constant C depends on N,  $r_i$ ,  $d_{\Omega}$ , and  $\theta$  (only in the case N=4).

## ACKNOWLEDGEMENTS

The authors wish to thank the anonymous referee, who hinted the estimate (2.21) and whose suggestions contributed to a better presentation of this article.

The paper was partially supported by the Gruppo Nazionale Analisi Matematica Probabilità e Applicazioni (GNAMPA) of the Istituto Nazionale di Alta Matematica (INdAM).

## References

- <span id="page-18-2"></span>[ABR] A. Aftalion, J. Busca and W. Reichel, Approximate radial symmetry for overdetermined boundary value problems, Adv. Diff. Eq. 4 (1999), 907-932.
- <span id="page-18-0"></span>[Al1] A. D. Alexandrov, Uniqueness theorem for surfaces in the large, V. Vestnik, Leningrad Univ. 13, 19 (1958), 5-8, Amer. Math. Soc. Transl. 21, Ser. 2, 412–416.
- <span id="page-18-1"></span>[Al2] A. D. Alexandrov, A characteristic property of spheres, Ann. Math. Pura Appl. 58 (1962), 303–315.
- <span id="page-18-3"></span>[BNST] B. Brandolini, C. Nitsch, P. Salani and C. Trombetti, On the stability of the Serrin problem, J. Differential Equations, 245 (2008), 1566–1583.
- <span id="page-18-4"></span>[BMS] L. Brasco, R. Magnanini and P. Salani, The location of the hot spot in a grounded convex conductor, Indiana Univ. Math. Jour. 60 (2011), 633-660.

- <span id="page-19-17"></span>[BS] H. B. Boas and E. J. Straube, Integral inequalities of Hardy and Poincaré type, Proc. Amer. Math. Soc. 103 (1998), 172–176.
- <span id="page-19-14"></span>[CM] G. Ciraolo and F. Maggi, On the shape of compact hypersurfaces with almost constant mean curvature, Comm. Pure Appl. Math. 70 (2017), 665–716.
- <span id="page-19-3"></span>[CMV] G. Ciraolo, R. Magnanini and V. Vespri, Hölder stability for Serrin's overdetermined problem, Ann. Mat. Pura Appl. 195 (2016), 1333–1345.
- <span id="page-19-7"></span>[CV] G. Ciraolo and L. Vezzoni, A sharp quantitative version of Alexandrov's theorem via the method of moving planes, J. Eur. Math. Soc. 20 (2018), 261–299.
- <span id="page-19-4"></span>[Fe] W. M. Feldman, Stability of Serrin's problem and dynamic stability of a model for contact angle motion, SIAM J. Math. Anal. 50-3 (2018), 3303–3326.
- <span id="page-19-22"></span>[Fr] A. Friedman, Partial Differential Equations, Krieger, 1983.
- <span id="page-19-23"></span>[HK] E. Heintze, H. Karcher, A general comparison theorem with applications to volume estimates for submanifolds, Ann. Sci. École Norm. Sup. 11(1978), 451-470.
- <span id="page-19-15"></span>[H1] R. Hurri, *Poincaré domains in*  $\mathbb{R}^n$ , Ann. Acad. Sci. Fenn. Ser. A Math. Dissertationes 71 (1988), 1–41.
- <span id="page-19-16"></span>[H2] R. Hurri-Syrjänen, An improved Poincaré inequality, Proc. Amer. Math. Soc. 120 (1994), 213–222.
- <span id="page-19-20"></span>[IMW] M. Ishiwata, R. Magnanini, H. Wadade, A natural approach to the asymptotic mean value property for the p-Laplacian, Calc. Var. (2017) 56:97, 22 pp.
- <span id="page-19-8"></span>[KM] B. Krummel and F. Maggi, Isoperimetry with upper mean curvature bounds and sharp stability estimates, Calc. Var. Part. Diff. Eqs. (2017), 56:53.
- <span id="page-19-5"></span>[Ma] R. Magnanini, Alexandrov, Serrin, Weinberger, Reilly: symmetry and stability by integral identities, Bruno Pini Mathematical Seminar (2017), 121–141.
- <span id="page-19-0"></span>[MP1] R. Magnanini and G. Poggesi, On the stability for Alexandrov's Soap Bubble theorem, in print in J. Anal. Math., preprint (2016), arXiv:1610.07036.
- <span id="page-19-1"></span>[MP2] R. Magnanini, G. Poggesi, Serrin's problem and Alexandrov's Soap Bubble Theorem: stability via integral identities, to appear in Indiana Univ. Math. J., preprint (2017) arxiv:1708.07392.
- <span id="page-19-21"></span>[MrS] O. Martio, J. Sarvas, Injectivity theorems in plane and space, Ann. Acad. Sci. Fenn. Ser. A I Math. 4 (1979), 383–401.
- <span id="page-19-10"></span>[PS] L. Payne and P. W. Schaefer, Duality theorems un some overdetermined boundary value problems, Math. Meth. Appl. Sciences 11 (1989), 805–819.
- <span id="page-19-13"></span>[Po1] G. Poggesi, Radial symmetry for p-harmonic functions in exterior and punctured domains, Appl. Anal. 98 (2019), 1785–1798.
- <span id="page-19-6"></span>[Po2] G. Poggesi, The Soap Bubble Theorem and Serrin's problem: quantitative symmetry, PhD Thesis, Università di Firenze, defended on February 2019, preprint arxiv:1902.08584.
- <span id="page-19-11"></span>[Re1] R. C. Reilly, Applications of the Hessian operator in a Riemannian manifold, Indiana Univ. Math. J. 26 (1977), 459–472.
- <span id="page-19-12"></span>[Re2] R. C. Reilly, Mean curvature, the Laplacian, and soap bubbles, Amer. Math. Monthly, 89 (1982), 180–188.
- <span id="page-19-2"></span>[Se] J. Serrin, A symmetry problem in potential theory, Arch. Ration. Mech. Anal. 43 (1971), 304–318
- <span id="page-19-19"></span>[Va] J. Väisälä, Exhaustions of John domains, Ann. Acad. Sci. Fenn. Ser. A I Math. 19 (1994), 47–57.
- <span id="page-19-9"></span>[We] H. F. Weinberger, Remark on the preceding paper of Serrin, Arch. Ration. Mech. Anal. 43 (1971), 319–320.
- <span id="page-19-18"></span>[Zi] W. P. Ziemer, A Poincaré type inequality for solutions of elliptic differential equations, Proc. Amer. Math. Soc. 97 (1986), 286–290.

Dipartimento di Matematica ed Informatica "U. Dini", Università di Firenze, viale Morgagni 67/A, 50134 Firenze, Italy.

E-mail address: magnanini@unifi.it

 $\mathit{URL}$ : http://web.math.unifi.it/users/magnanin

DEPARTMENT OF MATHEMATICS AND STATISTICS, THE UNIVERSITY OF WESTERN AUSTRALIA, 35 STIRLING HIGHWAY, CRAWLEY, PERTH, WA 6009, AUSTRALIA

 $E ext{-}mail\ address: giorgio.poggesi@uwa.edu.au}$