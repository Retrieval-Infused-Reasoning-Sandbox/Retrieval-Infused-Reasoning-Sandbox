[Skip to main content](#page-0-0)

[Springer Nature Link](https://link.springer.com)

[Log in](https://idp.springer.com/auth/personal/springernature?redirect_uri=https://link.springer.com/article/10.1007/BF00250469)

[Menu](#page-4-0)

[Find a journal](https://link.springer.com/journals/) [Publish with us](https://www.springernature.com/gp/authors) [Track your research](https://link.springernature.com/home/)

[Search](#page-4-1)

[Cart](https://order.springer.com/public/cart)

- <span id="page-0-0"></span>[Home](file:///) 1.
- [Archive for Rational Mechanics and Analysis](file:///journal/205) 2.
- Article 3.

# **Remark on the preceding paper of Serrin**

- Published: January 1971 •
- Volume 43, pages 319–320, (1971) •
- [Cite this article](#page-2-0) •

![](_page_0_Picture_14.jpeg)

[Archive for Rational Mechanics and Analysis](file:///journal/205) [Aims and scope](file:///journal/205/aims-and-scope) [Submit](https://www.editorialmanager.com/arma)

[manuscript](https://www.editorialmanager.com/arma) 

- [H. F. Weinberger](#page-2-1)[1](#page-2-2) •
- 893 Accesses •
- 204 Citations •
- [Explore all metrics](file:///article/10.1007/BF00250469/metrics)  •

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250469) to check access.

### **Access this article**

#### [Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250469)

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

#### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/BF00250469                                                                                                               |
| 1432-0673                                                                                                                        |
| Remark on the preceding paper of Serrin                                                                                          |
| 1971                                                                                                                             |
|                                                                                                                                  |
| H. F. Weinberger                                                                                                                 |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 3babe57f7f06896747ee076183b5a166cbb9cb6c06b2360192ae58b59ea3337ba6dd198780e7a8370d639e88d716104f3a101c664ef79fc246f718126c15150f |
|                                                                                                                                  |

Buy article PDF 39,95 €

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

### **Reference**

Serrin, J., A symmetry problem in potential theory. Preceding in this journal. 1.

[Download references](https://citation-needed.springer.com/v2/references/10.1007/BF00250469?format=refman&flavour=references)

### **Author information**

#### **Authors and Affiliations**

- <span id="page-2-2"></span>Department of Mathematics, University of Minnesota, Minneapolis 1.
  - H. F. Weinberger

#### Authors

<span id="page-2-1"></span>H. F. Weinberger 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=H.%20F.%20Weinberger)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=H.%20F.%20Weinberger) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22H.%20F.%20Weinberger%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

## **Additional information**

*Communicated by* J. Serrin

### **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Remark%20on%20the%20preceding%20paper%20of%20Serrin&author=H.%20F.%20Weinberger&contentID=10.1007%2FBF00250469©right=Springer-Verlag&publication=0003-9527&publicationDate=1971-01&publisherName=SpringerNature&orderBeanReset=true)

### **About this article**

#### <span id="page-2-0"></span>**Cite this article**

Weinberger, H.F. Remark on the preceding paper of Serrin. *Arch. Rational Mech. Anal.* **43**, 319–320 (1971). https://doi.org/10.1007/BF00250469

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/BF00250469?format=refman&flavour=citation)

Received: 14 July 1971 •

Issue date: January 1971 •

DOI: https://doi.org/10.1007/BF00250469 •

### **Keywords**

- [Neural Network](file:///search?query=Neural%20Network&facet-discipline=%22Physics%22) •
- [Complex System](file:///search?query=Complex%20System&facet-discipline=%22Physics%22) •
- [Nonlinear Dynamics](file:///search?query=Nonlinear%20Dynamics&facet-discipline=%22Physics%22) •
- [Electromagnetism](file:///search?query=Electromagnetism&facet-discipline=%22Physics%22) •
- [Preceding Paper](file:///search?query=Preceding%20Paper&facet-discipline=%22Physics%22) •

### **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2FBF00250469)

#### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

#### **Buy Now**

| article            |
|--------------------|
| 10.1007/BF00250469 |
| 1432-0673          |

| Remark on the preceding paper of Serrin                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 1971                                                                                                                             |
|                                                                                                                                  |
| H. F. Weinberger                                                                                                                 |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 3babe57f7f06896747ee076183b5a166cbb9cb6c06b2360192ae58b59ea3337ba6dd198780e7a8370d639e88d716104f3a101c664ef79fc246f718126c15150f |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

Advertisement

### <span id="page-4-1"></span>**Search**

| Search by keyword or author |  |
|-----------------------------|--|
|                             |  |
|                             |  |

Search

### <span id="page-4-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

#### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

#### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

#### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

#### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature