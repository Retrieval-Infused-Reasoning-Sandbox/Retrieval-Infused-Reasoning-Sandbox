#### Skip to main content

#### Advertisement

### Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

<u> </u>

- 1. Home >
- 2. Elliptic Partial Differential Equations of Second Order
- 3. Chapter

# **Boundary Gradient Estimates**

- Chapter
- First Online: 01 January 2011
- pp 333–358
- Cite this chapter

![](_page_0_Picture_16.jpeg)

Elliptic Partial Differential Equations of Second Order

- <span id="page-0-0"></span>• David Gilbarg<sup>3</sup> &
- Neil S. Trudinger<sup>4</sup>

Part of the book series: Classics in Mathematics ((CLASSICS, volume 224))

17k Accesses

## **Abstract**

An examination of the proof of Theorem 11.5 shows that for elliptic operators of the forms (11.7) or (11.8) the solvability of the classical Dirichlet problem with smooth data depends only upon the fulfillment of Step II of the existence procedure, that is, upon the existence of a boundary gradient estimate. In this chapter we provide a variety of hypotheses for the general equation,

```
\Qu = a^{ij}}\left( \{x,u,Du\} \right) D_{ij}u + b\left( \{x,u,Du\} \right) = 0
(14.1)
```

in  $\Omega \subset \mathbb{R}^n$ , that guarantee a boundary gradient estimate for solutions. These hypotheses are combinations of structural conditions on Q and geometric conditions on the domain  $\Omega$ . It will be seen that the gradient bound aspect of the theory of quasilinear elliptic equations is not as profound as other aspects such as the Holder estimates of Chapters 6 and 13. The boundary gradient estimates are tied through the classical maximum principle to judicious and generally natural choices of barrier functions. Nevertheless these estimates are of considerable importance since they seem to be the principal factor in determining the solvability character of the Dirichlet problem. This will be evidenced by the non-existence results at the end of the chapter.

This is a preview of subscription content, log in via an institution to check access.

# **Access this chapter**

Log in via an institution

#### Subscribe and save

Springer+

from €37.37 /Month

Starting from 10 chapters or articles per month

- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

# **Buy Now**

**Chapter EUR 29.95**

Price includes VAT (China (P.R.))

| chapter |
|---------|
|---------|

10.1007/978-3-642-61798-0\_14

978-3-642-61798-0

Boundary Gradient Estimates

2001

2011

David Gilbarg, Neil S. Trudinger

Elliptic Partial Differential Equations of Second Order

97e0facef60f8890f0039e77a67b5f115422ecdaf1294fefe6028e5a30b904bb3a1eafe2c9027f468353053089165d4ec98e196667aea541c669133d2de6574e

- Available as PDF
- Read on any device
- Instant download
- Own it forever

#### Buy Chapter

**eBook EUR 46.00**

Price includes VAT (China (P.R.))

ebook

10.1007/978-3-642-61798-0

978-3-642-61798-0

Elliptic Partial Differential Equations of Second Order

51ed38eb1aa4936cff7736e97c298fff05cad94db74758de6461743846a252912e509ba93f4ca4b476048f68b104f7aca63ccecb709d70463aba78d46e3d8b40

- Available as PDF
- Read on any device
- Instant download
- Own it forever

Buy eBook

# **Softcover Book EUR 54.99**

Price excludes VAT (China (P.R.))

book

10.1007/978-3-642-61798-0

978-3-540-41160-4

Elliptic Partial Differential Equations of Second Order

465d2897d44db50e8b1d379f390b8aabe05e8b57c52f269729d5424705b61c87de733709e813dd21a4e08a315c942c3ee1e0b816b84816e3ea9a364ac6738ceb

- Compact, lightweight edition
- Dispatched in 3 to 5 business days
- Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Buy Softcover Book

Tax calculation will be finalised at checkout

**Purchases are for personal use only**

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks) 

# **Preview**

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/978-3-642-61798-0_14)

Unable to display preview. [Download preview PDF.](file://page-one.springer.com/pdf/preview/10.1007/978-3-642-61798-0_14)

# **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Mathematical Physics](file:///subjects/mathematical-physics) •
- [Partial Differential Equations](file:///subjects/partial-differential-equations) •
- [Diffusion Processes and Stochastic Analysis on Manifolds](file:///subjects/diffusion-processes-and-stochastic-analysis-on-manifolds) •
- [Functional Analysis](file:///subjects/functional-analysis) •
- [Partial Differential Equations on Manifolds](file:///subjects/partial-differential-equations-on-manifolds) •
- [Calculus of Variations and Optimization](file:///subjects/calculus-of-variations-and-optimization) •

# **Author information**

# **Authors and Affiliations**

- <span id="page-6-1"></span>Department of Mathematics, Stanford University, Stanford, CA, 94305-2125, USA David Gilbarg 1.
- <span id="page-6-3"></span>School of Mathematical Sciences, The Australian National University, Canberra, ACT 0200, Australia 2.

Neil S. Trudinger

### Authors

<span id="page-6-0"></span>David Gilbarg 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=David%20Gilbarg)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=David%20Gilbarg) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22David%20Gilbarg%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-6-2"></span>Neil S. Trudinger 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Neil%20S.%20Trudinger)

Search author on[:PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Neil%20S.%20Trudinger) [Google Scholar](http://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Neil%20S.%20Trudinger%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?publisherName=SpringerNature&orderBeanReset=true&orderSource=SpringerLink&title=Boundary%20Gradient%20Estimates&author=David%20Gilbarg%2C%20Neil%20S.%20Trudinger&contentID=10.1007%2F978-3-642-61798-0_14©right=Springer-Verlag%20Berlin%20Heidelberg&publication=eBook&publicationDate=2001&startPage=333&endPage=358&imprint=Springer-Verlag%20Berlin%20Heidelberg)

# **Copyright information**

© 2001 Springer-Verlag Berlin Heidelberg

# **About this chapter**

## <span id="page-7-0"></span>**Cite this chapter**

Gilbarg, D., Trudinger, N.S. (2001). Boundary Gradient Estimates. In: Elliptic Partial Differential Equations of Second Order. Classics in Mathematics, vol 224. Springer, Berlin, Heidelberg. https://doi.org/10.1007/978-3-642-61798-0\_14

## **Download citation**

- [.RIS](https://citation-needed.springer.com/v2/references/10.1007/978-3-642-61798-0_14?format=refman&flavour=citation) •
- [.ENW](https://citation-needed.springer.com/v2/references/10.1007/978-3-642-61798-0_14?format=endnote&flavour=citation) •
- [.BIB](https://citation-needed.springer.com/v2/references/10.1007/978-3-642-61798-0_14?format=bibtex&flavour=citation) •
- DOI: https://doi.org/10.1007/978-3-642-61798-0\_14 •
- Published: 27 September 2011 •
- Publisher Name: Springer, Berlin, Heidelberg •
- Print ISBN: 978-3-540-41160-4 •
- Online ISBN: 978-3-642-61798-0 •
- eBook Packages: [Springer Book Archive](https://metadata.springernature.com/metadata/books) •

# **Keywords**

[Structure Condition](file:///search?query=Structure%20Condition&facet-discipline=%22Mathematics%22) •

- [Dirichlet Problem](file:///search?query=Dirichlet%20Problem&facet-discipline=%22Mathematics%22) •
- [Principal Curvature](file:///search?query=Principal%20Curvature&facet-discipline=%22Mathematics%22) •
- [Convex Domain](file:///search?query=Convex%20Domain&facet-discipline=%22Mathematics%22) •
- [Minimal Surface Equation](file:///search?query=Minimal%20Surface%20Equation&facet-discipline=%22Mathematics%22) •

*These keywords were added by machine and not by the authors. This process is experimental and the keywords may be updated as the learning algorithm improves.*

# **Publish with us**

[Policies and ethics](https://www.springernature.com/gp/policies/book-publishing-policies)

# **Access this chapter**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Fchapter%2F10.1007%2F978-3-642-61798-0_14)

## **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

# **Buy Now**

**Chapter EUR 29.95**

Price includes VAT (China (P.R.))

| chapter |
|---------|
|---------|

10.1007/978-3-642-61798-0\_14

978-3-642-61798-0

Boundary Gradient Estimates

2001

2011

David Gilbarg, Neil S. Trudinger

Elliptic Partial Differential Equations of Second Order

97e0facef60f8890f0039e77a67b5f115422ecdaf1294fefe6028e5a30b904bb3a1eafe2c9027f468353053089165d4ec98e196667aea541c669133d2de6574e

- Available as PDF
- Read on any device
- Instant download
- Own it forever

#### Buy Chapter

**eBook EUR 46.00**

Price includes VAT (China (P.R.))

ebook

10.1007/978-3-642-61798-0

978-3-642-61798-0

Elliptic Partial Differential Equations of Second Order

51ed38eb1aa4936cff7736e97c298fff05cad94db74758de6461743846a252912e509ba93f4ca4b476048f68b104f7aca63ccecb709d70463aba78d46e3d8b40

- Available as PDF
- Read on any device
- Instant download
- Own it forever

![](_page_11_Picture_0.jpeg)

**Softcover Book EUR 54.99** Price excludes VAT (China (P.R.)) Buy Softcover Book Tax calculation will be finalised at checkout **Purchases are for personal use only** [Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/ebooks)  **Search** book 10.1007/978-3-642-61798-0 978-3-540-41160-4 Elliptic Partial Differential Equations of Second Order 465d2897d44db50e8b1d379f390b8aabe05e8b57c52f269729d5424705b61c87de733709e813dd21a4e08a315c942c3ee1e0b816b84816e3ea9a364ac6738ceb Compact, lightweight edition Dispatched in 3 to 5 business days Free shipping worldwide - [see info](https://support.springernature.com/en/support/solutions/articles/6000233448-coronavirus-disease-covid-19-delivery-information)

Search

<span id="page-11-0"></span>Search by keyword or author

# <span id="page-12-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

# **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

# **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •

- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature