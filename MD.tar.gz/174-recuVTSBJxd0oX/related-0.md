![](_page_0_Picture_0.jpeg)

Einstein-AdS gravity coupled to nonlinear electrodynamics, magnetic black holes, thermodynamics in an extended phase space and Joule–Thomson expansion

S. I. Kruglov <sup>1</sup>

Department of Physics, University of Toronto, 60 St. Georges St., Toronto, ON M5S 1A7, Canada Canadian Quantum Research Center, 204-3002 32 Ave Vernon, BC V1T 2L7, Canada

#### Abstract

We study Einstein's gravity with negative cosmological constant coupled to nonlinear electrodynamics proposed earlier. The metric and mass functions and corrections to the Reissner–Nordstr¨om solution are obtained. Black hole solutions can have one or two horizons. Thermodynamics and phase transitions of magnetically charged black holes in Anti-de Sitter spacetime are investigated. The first law of black hole thermodynamics is formulated and the generalized Smarr relation is proofed. By calculating the Gibbs free energy and heat capacity we study the black hole stability. The Joule–Thomson expansion is considered showing the cooling and heating phase transitions.

# 1 Introduction

Black holes behave as the thermodynamic systems [1, 2, 3] and it has the entropy connected with surface area and surface gravity defines the temperature [4, 5]. Black holes phase transitions occur in Anti-de Sitter (AdS) spacetime, where the cosmological constant is negative [6]. It was discovered that gravity in AdS spacetime is linked with the conformal field theory (the holographic principle) [7] which has an application in condensed matter physics. In black hole thermodynamics (in an extended phase space) the negative cosmological constant being a thermodynamic pressure which is conjugated to a black hole volume [8, 9, 10, 11]. In Einstein-AdS gravity coupled to nonlinear electrodynamics (NED) (with coupling β) the constant β is conjugated to the vacuum polarization. Black hole thermodynamics in Einstein-AdS gravity coupled to

<sup>1</sup>E-mail: serguei.krouglov@utoronto.ca

Born–Infeld electrodynamics was considered by [12, 13, 14, 15, 16, 17, 18] (see also [19, 20]). Born–Infeld-AdS thermodynamics of black holes in extended phase space was studied in [21, 22, 23, 24, 25]. The Joule–Thomson expansion of black holes was investigated in [26, 27, 28, 29, 30, 31, 32, 33, 34, 35].

In section 2 we obtain the metric function and its asymptotic with corrections to the Reissner–Nordstr¨om solution. The first law of black hole thermodynamics in the extended phase space is studied in section 3. We calculate the thermodynamic magnetic potential and the thermodynamic conjugate to the NED coupling (the vacuum polarization). We show that the generalized Smarr relation holds. In section 4, the critical temperature and critical pressure are obtained. By analysing the Gibbs free energy and heat capacity we show that phase transitions take place. It is demonstrated that black hole thermodynamics is similar to Van der Waals thermodynamics. The Joule–Thomson adiabatic expansion is studied in section 5. The Joule– Thomson coefficient and the inversion temperature are calculated. Section 6 is a summary.

We use the units c = ¯h = 1, k<sup>B</sup> = 1.

# 2 Einstein-AdS black hole solution

The Einstein-AdS action with the matter is given by

$$I = \int d^4x \sqrt{-g} \left( \frac{R - 2\Lambda}{16\pi G_N} + \mathcal{L}(\mathcal{F}) \right), \tag{1}$$

where Λ = −3/l<sup>2</sup> is negative cosmological constant with l being the AdS radius. Here, we use the matter Lagrangian in the form of NED [36]

$$\mathcal{L}(\mathcal{F}) = -\frac{\mathcal{F}}{4\pi \left(1 + (2\beta \mathcal{F})^{3/4}\right)},\tag{2}$$

with F = F µνFµν/4 = (B<sup>2</sup> − E 2 )/2, where E and B are the electric and magnetic fields, respectively. As β → 0 Lagrangian (2) becomes the Maxwell Lagrangian L<sup>M</sup> = −F/(4π). From action (1) one obtains the field equations

$$R_{\mu\nu} - \frac{1}{2}g_{\mu\nu}R + \Lambda g_{\mu\nu} = 8\pi G_N T_{\mu\nu},\tag{3}$$

$$\partial_{\mu} \left( \sqrt{-g} \mathcal{L}_{\mathcal{F}} F^{\mu\nu} \right) = 0, \tag{4}$$

where  $\mathcal{L}_{\mathcal{F}} = \partial \mathcal{L}(\mathcal{F})/\partial \mathcal{F}$ . The energy-momentum tensor reads

$$T_{\mu\nu} = F_{\mu\rho} F_{\nu}^{\ \rho} \mathcal{L}_{\mathcal{F}} + g_{\mu\nu} \mathcal{L} \left( \mathcal{F} \right). \tag{5}$$

The line element squared with spherical symmetry is

$$ds^{2} = -f(r)dt^{2} + \frac{1}{f(r)}dr^{2} + r^{2}\left(d\theta^{2} + \sin^{2}(\theta)d\phi^{2}\right).$$
 (6)

We treat the black hole as a magnetic monopole with the magnetic field  $B = q/r^2$ , where q is the magnetic charge. The metric function is given by [37]

$$f(r) = 1 - \frac{2m(r)G_N}{r},\tag{7}$$

with the mass function

$$m(r) = m_0 + 4\pi \int_0^r \rho(r)r^2 dr.$$
 (8)

Here,  $m_0$  an integration constant (the Schwarzschild mass), and  $\rho$  is the energy density. Making use of Eq. (5) the magnetic energy density plus energy density due to AdS spacetime is given by

$$\rho = \frac{q^2}{8\pi r \left(r^3 + (\beta q^2)^{3/4}\right)} - \frac{3}{8\pi G_N l^2}.$$
(9)

From Eqs. (8) and (9) one obtains the mass function

$$m(r) = m_0 + \frac{q^{3/2}}{12\sqrt[4]{\beta}} \left[ \ln \frac{r^2 - \sqrt[4]{\beta}q^2 r + \sqrt{\beta}q}{(r + \sqrt[4]{\beta}q^2)^2} - 2\sqrt{3} \arctan \left( \frac{1 - 2r/\sqrt[4]{\beta}q^2}{\sqrt{3}} \right) + \frac{\pi}{\sqrt{3}} \right] - \frac{r^3}{2G_N l^2}.$$
 (10)

The magnetic energy of the black hole becomes

$$m_M = \frac{q^2}{2} \int_0^\infty \frac{r}{r^3 + (\beta q^2)^{3/4}} dr = \frac{\pi q^{3/2}}{3\sqrt{3}\sqrt[4]{\beta}}.$$
 (11)

The magnetic energy, which can be considered as a magnetic mass, is finite. Thus, the coupling  $\beta$  smoothes singularities. Making use of Eqs. (7) and (10) we obtain the metric function

$$f(r) = 1 - \frac{2m_0 G_N}{r} - \frac{q^{3/2} G_N}{6\sqrt[4]{\beta}r} \left[ \ln \frac{r^2 - \sqrt[4]{\beta}q^2 r + \sqrt{\beta}q}{(r + \sqrt[4]{\beta}q^2)^2} \right]$$

$$-2\sqrt{3}\arctan\left(\frac{1-2r/\sqrt[4]{\beta q^2}}{\sqrt{3}}\right) + \frac{\pi}{\sqrt{3}}\right] + \frac{r^2}{l^2}.$$
 (12)

As r → 0, when the Schwarzschild mass is zero (m<sup>0</sup> = 0), one finds

$$f(r) = 1 - \frac{G_N \sqrt{qr}}{2\beta^{3/4}} + \frac{r^2}{l^2} + \frac{G_N r^4}{5\beta^{3/2} q} + \mathcal{O}(r^6).$$
 (13)

As a result, the black hole is regular, f(0) = 1. Making use of Eq. (12) (when Λ = 0) as r → ∞, we obtain

$$f(r) = 1 - \frac{2MG_N}{r} + \frac{q^2G_N}{r^2} - \frac{q^{7/2}\beta^{3/4}G_N}{4r^5} + \mathcal{O}(r^{-6}).$$
 (14)

We define M = m<sup>0</sup> +m<sup>M</sup> being the ADM mass. According to Eq. (14) black holes have corrections to the Reissner–Nordstr¨om solution. When β = 0 the metric (14) becomes the Reissner–Nordstr¨om metric. The plot of metric function (12) is depicted in Fig. 1 (at m<sup>0</sup> = 0, G<sup>N</sup> = 1, l = 10). According to Fig. 1 black holes may have one or two horizons. When coupling β increases the event horizon radius is decreasing. If magnetic charge q is increasing, the event horizon radius increases.

# 3 First law of black hole thermodynamics

We will consider the first law of black hole thermodynamics in extended phase space, where the pressure is P = −Λ/(8π) [38, 39, 40, 41, 42] and coupling β is a thermodynamic value. In this approach mass M is a chemical enthalpy (M = U + P V with U being the internal energy). By using the Euler's dimensional analysis with G<sup>N</sup> = 1 [43], [38], we obtain dimensions as follows [M] = L, [S] = L 2 , [P] = L −2 , [J] = L 2 , [q] = L, [β] = L 2 . Then one finds

$$M = 2S\frac{\partial M}{\partial S} - 2P\frac{\partial M}{\partial P} + 2J\frac{\partial M}{\partial J} + q\frac{\partial M}{\partial q} + 2\beta\frac{\partial M}{\partial \beta}.$$
 (15)

The thermodynamic conjugate to coupling β is the vacuum polarization [11] B = ∂M/∂β. The black hole entropy S, volume V and pressure P are defined as follows

$$S = \pi r_+^2, \quad V = \frac{4}{3}\pi r_+^3, \quad P = -\frac{\Lambda}{8\pi} = \frac{3}{8\pi l^2}.$$
 (16)

![](_page_4_Figure_0.jpeg)

Figure 1: The function f(r) at  $m_0 = 0$ ,  $G_N = 1$ , l = 10. Figure 1 shows that black holes could have one or two horizons. In accordance with subplot 1, if coupling  $\beta$  is increasing the event horizon radius decreases. According to subplot 2 when magnetic charge q increases the event horizon radius also increases.

Making use of Eq. (12) for non-rotating black holes we obtain

$$M(r_{+}) = \frac{r_{+}}{2G_{N}} + \frac{r_{+}^{3}}{2G_{N}l^{2}} + \frac{\pi q^{3/2}}{4\sqrt{3}\sqrt[4]{\beta}} - \frac{q^{3/2}g(r_{+})}{12\sqrt[4]{\beta}},$$

$$g(r_{+}) = \ln\frac{r_{+}^{2} - \sqrt[4]{\beta}q^{2}r_{+} + \sqrt{\beta}q}{(r_{+} + \sqrt[4]{\beta}q^{2})^{2}} - 2\sqrt{3}\arctan\left(\frac{1 - 2r_{+}/\sqrt[4]{\beta}q^{2}}{\sqrt{3}}\right), \quad (17)$$

where  $r_{+}$  is the event horizon radius,  $f(r_{+}) = 0$ . With the help of Eq. (17) we find

$$dM(r_{+}) = \left[\frac{1}{2} + \frac{3r_{+}^{2}}{2l^{2}} - \frac{q^{2}r_{+}}{2(r_{+}^{3} + (\beta q^{2})^{3/4})}\right]dr_{+} - \frac{r_{+}^{3}}{l^{3}}dl$$
$$+ \left[-\frac{\sqrt{q}g(r_{+})}{8\beta^{1/4}} + \frac{\sqrt{3q}\pi}{8\beta^{1/4}} + \frac{qr_{+}^{2}}{4[r_{+}^{3} + (\beta q^{2})^{3/4}]}\right]dq$$

$$+ \left[ \frac{q^{3/2}g(r_{+})}{48\beta^{5/4}} - \frac{q^{3/2}\pi}{16\sqrt{3}\beta^{5/4}} + \frac{q^{2}r_{+}^{2}}{8\beta[r_{+}^{3} + (\beta q^{2})^{3/4}]} \right] d\beta.$$
 (18)

The Hawking temperature is given by

$$T = \frac{f'(r)|_{r=r_{+}}}{4\pi},\tag{19}$$

where  $f'(r) = \partial f(r)/\partial r$ . By virtue of Eqs. (12), (19), one obtains the Hawking temperature

$$T = \frac{1}{4\pi} \left[ \frac{1}{r_{+}} + \frac{3r_{+}}{l^{2}} - \frac{q^{2}}{r_{+}^{3} + (\beta q^{2})^{3/4}} \right]. \tag{20}$$

Equation (20) is converted into the Hawking temperature of Maxwell-AdS black hole as  $\beta \to 0$ . Making use Eqs. (15), (18) and (20) we find the first law of black hole thermodynamics

$$dM = TdS + VdP + \Phi dq + \mathcal{B}d\beta. \tag{21}$$

Comparing Eq. (18) with (21) we obtain the magnetic potential  $\Phi$  and the vacuum polarization  $\mathcal{B}$ 

$$\Phi = -\frac{\sqrt{q}g(r_{+})}{8\beta^{1/4}} + \frac{\sqrt{3q}\pi}{8\beta^{1/4}} + \frac{qr_{+}^{2}}{4[r_{+}^{3} + (\beta q^{2})^{3/4}]},$$

$$\mathcal{B} = \frac{q^{3/2}g(r_{+})}{48\beta^{5/4}} - \frac{q^{3/2}\pi}{16\sqrt{3}\beta^{5/4}} + \frac{q^{2}r_{+}^{2}}{8\beta[r_{+}^{3} + (\beta q^{2})^{3/4}]}.$$
(22)

The plots of  $\Phi$  and  $\mathcal{B}$  vs  $r_+$  are depicted in Fig. 2. According to Fig. 2 (subplot 1) when parameter  $\beta$  increases the magnetic potential  $\Phi$  is decreasing. As  $r_+ \to \infty$  the magnetic potential vanishes  $(\Phi(\infty) = 0)$ , but at  $r_+ = 0$   $\Phi$  is finite. Figure 2 (subplot 2) shows that at  $r_+ = 0$  the vacuum polarization is finite and when  $r_+ \to \infty$ ,  $\mathcal{B}$  is zero  $(\mathcal{B}(\infty) = 0)$ .

Making use of Eqs. (15), (16) and (22) one can verify that the generalized Smarr relation

$$M = 2ST - 2PV + q\Phi + 2\beta\mathcal{B} \tag{23}$$

holds.

![](_page_6_Figure_0.jpeg)

Figure 2: The functions Φ and B vs r<sup>+</sup> at q = 1. The solid curve in subplot 1 is for β = 0.05, the dashed curve is for β = 0.2, and the dashed-doted curve is for β = 0.5. It follows that the magnetic potential Φ is finite at r<sup>+</sup> = 0 and becomes zero at r<sup>+</sup> → ∞. If coupling β is increasing the magnetic potential decreases. The function B in subplot 2 vanishes as r<sup>+</sup> → ∞ and is finite at r<sup>+</sup> = 0.

# 4 Thermodynamics of black hole

With the help of Eq. (20) one finds the black hole equation of state

$$P = \frac{T}{2r_{+}} - \frac{1}{8\pi r_{+}^{2}} + \frac{q^{2}}{8\pi r_{+}[r_{+}^{3} + (\beta q^{2})^{3/4}]}.$$
 (24)

Equation (24) as β → 0 is converted into charged Maxwell-AdS black hole equation of state [41]. Equation (24) is similar to the Van der Waals equation of state if the specific volume reads v = 2l<sup>P</sup> r<sup>+</sup> (l<sup>P</sup> = √ G<sup>N</sup> = 1) [41]. Then Eq. (24) becomes

$$P = \frac{T}{v} - \frac{1}{2\pi v^2} + \frac{2q^2}{\pi v[v^3 + 8(\beta q^2)^{3/4}]}.$$
 (25)

The inflection points in the P −v diagrams (critical points) may be obtained by equations

$$\frac{\partial P}{\partial v} = -\frac{T}{v^2} + \frac{1}{\pi v^3} + \frac{8q^2(-v^6 + (q\sqrt{\beta})^3)}{\pi v^2[v^3 + 8(\beta q^2)^{3/4}]^2} = 0,$$

$$\frac{\partial^2 P}{\partial v^2} = \frac{2T}{v^3} - \frac{3}{\pi v^4} + \frac{8q^2[5v^6 + 8(\beta q^2)^{3/4}v^3 + 32(\beta q^2)^{3/2}]}{\pi v^3[v^3 + 8(\beta q^2)^{3/4}]^3} = 0.$$
(26)

By virtue of Eq. (26) one finds the critical points equation

$$[v_c^3 + 8(\beta q^2)^{3/4}]^3 - 24q^2v_c^4[v_c^3 - 4(\beta q^2)^{3/4}] = 0.$$
 (27)

Making use of Eq. (26) we obtain the critical temperature and pressure equations

$$T_c = \frac{1}{\pi v_c} - \frac{8q^2[v^3 + 2(\beta q^2)^{3/4}]}{\pi [v^3 + 8(\beta q^2)^{3/4}]^2},$$
(28)

$$P_c = \frac{1}{2\pi v_c^2} - \frac{6q^2 v_c^2}{\pi (v_c^3 + 8(\beta q^2)^{3/4})^2}.$$
 (29)

The solutions (approximate) v<sup>c</sup> to Eq. (27), critical temperatures T<sup>c</sup> and pressures P<sup>c</sup> are presented in Table 1. The P − v diagrams are given in Fig.

Table 1: Critical values of the specific volume, temperatures and pressures at q = 1

| β  | 0.1    | 0.2    | 0.4    | 0.5    | 07     | 0.8    | 0.9    | 1      |
|----|--------|--------|--------|--------|--------|--------|--------|--------|
| vc | 4.790  | 4.708  | 4.552  | 4.472  | 4.297  | 4.196  | 4.080  | 3.936  |
| Tc | 0.0438 | 0.0442 | 0.0448 | 0.0452 | 0.0459 | 0.0463 | 0.0467 | 0.0472 |
| Pc | 0.0034 | 0.0035 | 0.0036 | 0.0037 | 0.0038 | 0.0039 | 0.0040 | 0.0041 |

3. At q = 1, β = 0.5 the critical specific volume is v<sup>c</sup> ≈ 4.472 and the critical temperature is T<sup>c</sup> = 0.0452. Figure 3 shows that at some point the pressure is zero corresponding to the black hole remnant. Then if the specific volume is increasing the pressure increases and the pressure has a maximum. Then the pressure decreases that is similar to ideal gas. At the critical values we

![](_page_8_Figure_0.jpeg)

Figure 3: The function P(v) at q = 1, β = 0.5. The critical isotherm corresponds to T<sup>c</sup> ≈ 0.0452 possessing the inflection point.

have similarities with Van der Waals liquid behavior having the inflection point. Making use of Eqs. (27), (28) and (29) and for small β one finds

$$v_c^2 = 24q^2 + \mathcal{O}(\beta), \quad T_c = \frac{1}{3\sqrt{6}\pi q} + \mathcal{O}(\beta), \quad P_c = \frac{1}{96\pi q^2} + \mathcal{O}(\beta).$$
 (30)

At β = 0 in Eq. (30) we obtain the critical points of charged AdS black hole [21]. Then the critical ratio becomes

$$\rho_c = \frac{P_c v_c}{T_c} = \frac{3}{8} + \mathcal{O}(\beta), \tag{31}$$

with the value ρ<sup>c</sup> = 3/8 corresponding to the Van der Waals fluid.

The Gibbs free energy for fixed charge q, coupling β and pressure P is given by

$$G = M - TS, (32)$$

where M is considered as a chemical enthalpy. Making use of Eqs. (16), (17), (20) and (32) we obtain

$$G = \frac{r_{+}}{4} - \frac{2\pi r_{+}^{3} P}{3} + \frac{\pi q^{3/2}}{4\sqrt{3}\beta^{1/4}} + \frac{q^{2}r_{+}^{2}}{4[r_{+}^{3} + (\beta q^{2})^{3/4}]} - \frac{q^{3/2}g(r_{+})}{12\beta^{1/4}}.$$
 (33)

The plot of the Gibbs free energy G versus T for β = 0.5 and v<sup>c</sup> ≈ 4.472, T<sup>c</sup> ≈ 0.0452 is depicted in Fig. 4. We took into consideration that r<sup>+</sup> is the function of P and T (see Eq. (24)). Subplots 1 and 2 at P < P<sup>c</sup> show first-

![](_page_9_Figure_3.jpeg)

Figure 4: The plots of the Gibbs free energy G vs. T at q = 1, β = 0.5. According to subplots 1 and 2 we have the 'swallowtail' plots with firstorder phase transitions. Subplot 3 shows to second-order phase transition with P = P<sup>c</sup> ≈ 0.0037. Subplot 4 shows the case P > P<sup>c</sup> with non-critical behavior of the Gibbs free energy.

order phase transitions similar to liquid-gas transitions with the 'swallowtail' behaviour. In accordance with subplot 3 the second order phase transition for P = P<sup>c</sup> takes place. Subplot 4 corresponds to the case P > Pc, where there are not phase transitions.

The entropy S vs temperature T at q = β = 1 is given in Fig. 5. Figure 5 (subplots 1 and 2) show that entropy is ambiguous function of the temperature and, therefore, first-order phase transitions take place. According to subplot 3 the second-order phase transition occurs. The critical point separates low and high entropy states. In accordance with subplot 4 there are not phase transitions at q = β = 1, P = 0.005.

![](_page_10_Figure_1.jpeg)

Figure 5: The plots of entropy S vs. temperature T at q = 1, β = 0.5. According to subplots 1 and 2 (in some range of T) entropy is ambiguous function of the temperature and first-order phase transitions occur. In accordance with subplot 3 the second-order phase transition takes place.

Let us study local stability of black holes by considering the heat capacity which is given by

$$C_q = T \left( \frac{\partial S}{\partial T} \right)_q = \frac{T \partial S / \partial r_+}{\partial T / \partial r_+} = \frac{2\pi r_+ T}{G_N \partial T / \partial r_+}.$$
 (34)

Equation (34) shows that when the Hawking temperature has an extremum the heat capacity diverges and the black hole phase transition occurs. The plot of the Hawking temperature is given in Fig. 6 for parameters β = 0.1, 0.3, 1 (l = q = 1). In accordance with Fig. 6, the Hawking temperature

![](_page_11_Figure_1.jpeg)

Figure 6: The plots of the Hawking temperature T versus horizon radius r<sup>+</sup> at l = q = 1, β = 0.1, 0.3, 1. Figure shows that the Hawking temperature has a minimum.

possesses a minimum and the heat capacity diverges. The plot of the heat capacity (34) at q = l = 1, β = 0.1 (G<sup>N</sup> = 1) is depicted in Fig. 7. In accordance with Fig. 7 the heat capacity has a singularity in the point where the Hawking temperature has a minimum. One can see from Eq. (34) that when the Hawking temperature is zero the heat capacity vanishes. For the case l = q = 1, β = 0.1, equation T = 0 has two real roots r<sup>1</sup> ≈ 0.213 and r<sup>2</sup> ≈ 0.472. The heat capacity diverges (∂T/∂r+=0) at r<sup>3</sup> ≈ 0.318 and the black hole undergoes the phase transition from small black hole to large black hole. In the region where the heat capacity is positive the black hole is stable, otherwise the black hole is unstable. Thus, at r<sup>3</sup> > r<sup>+</sup> > r<sup>1</sup> and at r<sup>+</sup> > r<sup>2</sup> the black hole is stable but at r<sup>2</sup> > r<sup>+</sup> > r<sup>3</sup> and r<sup>1</sup> > r<sup>+</sup> the black hole is unstable.

![](_page_12_Figure_0.jpeg)

Figure 7: The plot of the heat capacity C<sup>q</sup> versus horizon radius r<sup>+</sup> at l = q = 1, β = 0.1. According to the figure, the heat capacity has a singularity where the Hawking temperature possesses a minimum.

# 5 Joule–Thomson expansion

During the Joule–Thomson isenthalpic expansion the enthalpy (the mass M) is constant. The cooling-heating phases are described by the Joule–Thomson coefficient

$$\mu_J = \left(\frac{\partial T}{\partial P}\right)_M = \frac{1}{C_P} \left[ T \left(\frac{\partial V}{\partial T}\right)_P - V \right] = \frac{(\partial T/\partial r_+)_M}{(\partial P/\partial r_+)_M}.$$
 (35)

Equation (35) shows that the Joule–Thomson coefficient is the slope of the P − T function. At the inversion temperature T<sup>i</sup> the sign of µ<sup>J</sup> is changed, and T<sup>i</sup> can be found by equation µ<sup>J</sup> (Ti) = 0. In the cooling phase (µ<sup>J</sup> > 0) initial temperature is higher than inversion temperature T<sup>i</sup> and the final temperature decreases. If the initial temperature is lower than T<sup>i</sup> then the final temperature increases in accordance with the heating phase (µ<sup>J</sup> < 0). Making use of Eq. (35) and taking into account equation µ<sup>J</sup> (Ti) = 0, we obtain

$$T_i = V \left(\frac{\partial T}{\partial V}\right)_P = \frac{r_+}{3} \left(\frac{\partial T}{\partial r_+}\right)_P.$$
 (36)

The inversion temperature separates cooling and heating processes. The inversion temperature line goes through P − T diagrams maxima [27, 28]. Equation (24) may be represented as equation of state

$$T = \frac{1}{4\pi r_{+}} + 2Pr_{+} - \frac{q^{2}}{4\pi \left(r_{+}^{3} + (\beta q^{2})^{3/4}\right)}.$$
 (37)

At β = 0 Eq. (37) is converted into equation of state of Maxwell-AdS black holes. From Eq. (17) and using equation P = 3/(8πl<sup>2</sup> ) one obtains

$$P = \frac{3}{4\pi r_{+}^{3}} \left[ M(r_{+}) - \frac{r_{+}}{2} - \frac{\pi q^{3/2}}{4\sqrt{3}\beta^{1/4}} + \frac{q^{3/2}g(r_{+})}{12\beta^{1/4}} \right].$$
 (38)

We depicted the P −T isenthalpic diagrams in Fig. 6 by taking into account Eqs. (37) and (38). Figure 6 shows that the inversion Pi−T<sup>i</sup> diagram crosses maxima of isenthalpic curves. Making use of Eqs. (24), (36) and (37) we find the inversion pressure P<sup>i</sup>

$$P_i = \frac{3q^2(2r_+^3 + (\beta q^2)^{3/4})}{16\pi r_+ (r_+^3 + (\beta q^2)^{3/4})^2} - \frac{1}{4\pi r_+^2}.$$
 (39)

By virtue of Eqs. (37) and (39) one obtains the inversion temperature

$$T_i = \frac{q^2 (4r_+^3 + (q^2\beta)^{3/4})}{8\pi (r_+^3 + (q^2\beta)^{3/4})^2} - \frac{1}{4\pi r_+}.$$
 (40)

Substituting P<sup>i</sup> = 0 in Eq. (39), we find the equation for the minimum of the event horizon radius rmin

$$3q^{2}r_{min}(2r_{min}^{3} + (\beta q^{2})^{3/4}) - 4\left(r_{min}^{3} + (\beta q^{2})^{3/4}\right)^{2} = 0.$$
 (41)

From Eqs. (40) and (41) at β = 0, one obtains minimum of the inversion temperature corresponding to Maxwell-AdS magnetic black holes

$$T_i^{min} = \frac{1}{6\sqrt{6}\pi q}, \quad r_h^{min} = \frac{\sqrt{6}q}{2}.$$
 (42)

![](_page_14_Figure_0.jpeg)

Figure 8: The plots of the temperature T vs. pressure P for q = 30, β = 0.5. The Pi−T<sup>i</sup> diagram goes via maxima of isenthalpic curves. The solid curve is for mass M = 90, the dashed curve corresponds to M = 100, and the dasheddoted curve is for M = 110. The inversion temperature T<sup>i</sup> vs. pressure P<sup>i</sup> (q = 30, β = 0.5) is depicted by solid line. If black hole masses are increasing the inversion temperature T<sup>i</sup> increases.

Making use of Eqs. (30) and (42) at β = 0 we find the relation T min <sup>i</sup> = Tc/2 which corresponds to electrically charged AdS black holes [26]. With the help of Eqs. (39) and (40) we plotted P<sup>i</sup> − T<sup>i</sup> diagrams in Fig. 6. According to Fig. 6. the inversion point increases when the black hole mass increases. The inversion diagrams P<sup>i</sup> − T<sup>i</sup> are depicted in Figs. 9 and 10. According to Fig. 9 when magnetic charge q increases then the inversion temperature increases. Figure 8 shows that when the coupling β increases the inversion temperature decreases. From Eqs. (35), (37) and (38) we find

$$\left(\frac{\partial T}{\partial r_+}\right)_M = -\frac{1}{4\pi r_+^2} + 2P|_M + 2r_+ \left(\frac{\partial P}{\partial r_+}\right)_M + \frac{3q^2r_+^2}{4\pi[r_+^3 + (q^2\beta)^{3/4}]^2},$$

![](_page_15_Figure_0.jpeg)

Figure 9: The inversion temperature T<sup>i</sup> vs. pressure P<sup>i</sup> at q = 25, 30 and 35, β = 0.1. When magnetic charge q increases the inversion temperature is increasing.

$$\left(\frac{\partial P}{\partial r_{+}}\right)_{M} = \frac{3}{4\pi r_{+}^{4}} \left[ \frac{\sqrt{3}q^{3/2}\pi}{4\beta^{1/4}} - 3M + r_{+} - \frac{q^{3/2}g(r_{+})}{4\beta^{1/4}} + \frac{q^{2}r_{+}^{2}}{2[r_{+}^{3} + (\beta q^{2})^{3/4}]} \right], (43)$$

where P|<sup>M</sup> is given in Eq. (38). Equations (35) and (43) define the Joule– Thomson coefficient as the function of the magnetic charge q, coupling β, black hole mass M and event horizon radius r+. When the Joule–Thomson coefficient is positive (µ<sup>J</sup> > 0) a cooling process occurs. If µ<sup>J</sup> < 0 a heating process takes place.

# 6 Summary

We obtained new magnetic black hole solution in Einstein-AdS gravity coupled to NED. The metric and mass functions and corrections to the Reissner– Nordstr¨om solution were found. When coupling β is increasing (at constant magnetic charge) the event horizon radius decreases. If magnetic charge in-

![](_page_16_Figure_0.jpeg)

Figure 10: The inversion temperature T<sup>i</sup> vs. pressure P<sup>i</sup> at β = 0.1, 0.2 and 0.4, q = 20. Figure shows that if the coupling β increases the inversion temperature decreases.

creases (at constant coupling β) the event horizon radius is increasing. The black holes thermodynamics in an extended phase space with negative cosmological constant (which is a thermodynamic pressure) was studied. In this approach the mass of the black hole is the chemical enthalpy. The vacuum polarization, which is a thermodynamic quantity conjugated to coupling β, and thermodynamic potential, conjugated to magnetic charge, were obtained. We showed that the first law of black hole thermodynamics and the generalized Smarr formula take place. It was demonstrated that black hole thermodynamics is similar to the Van der Waals liquid–gas thermodynamics. We analysed the Gibbs free energy and heat capacity showing phase transitions. The critical ratio ρ<sup>c</sup> obtained is different from the Van der Waals value 3/8. We studied the black hole Joule–Thomson isenthalpic expansion and cooling and heating phase transitions. We found the inversion temperature which separates cooling and heating processes of black holes.

# References

- [1] J. M. Bardeen, B. Carter and S. W. Hawking, The Four laws of black hole mechanics, Commun. Math. Phys. 31 (1973), 161-170.
- [2] T. Jacobson, Thermodynamics of space-time: The Einstein equation of state, Phys. Rev. Lett. 75 (1995), 1260-1263, [arXiv:gr-qc/9504004].
- [3] T. Padmanabhan, Thermodynamical Aspects of Gravity: New insights, Rept. Prog. Phys. 73 (2010), 046901, [arXiv:0911.5004].
- [4] J. D. Bekenstein, Black holes and entropy, Phys. Rev. D 7 (1973), 2333- 2346.
- [5] S. W. Hawking, Particle Creation by Black Holes, Commun. Math. Phys. 43 (1975), 199-220.
- [6] S. W. Hawking and D. N. Page, Thermodynamics of Black Holes in anti-De Sitter Space, Commun. Math. Phys. 87 (1983), 577.
- [7] J. M. Maldacena, The Large N limit of superconformal field theories and supergravity, Int. J. Theor. Phys. 38 (1999), 1113-1133, [arXiv:hepth/9711200].
- [8] B. P. Dolan, Black holes and Boyle's law? The thermodynamics of the cosmological constant, Mod. Phys. Lett. A 30 (2015), 1540002, [arXiv:1408.4023].
- [9] D. Kubiznak and R. B. Mann, Black hole chemistry, Can. J. Phys. 93 (2015), 999-1002, [arXiv:1404.2126].
- [10] R. B. Mann, The Chemistry of Black Holes, Springer Proc. Phys. 170 (2016), 197-205.
- [11] D. Kubiznak, R. B. Mann, M. Teo, Black hole chemistry: thermodynamics with Lambda, Class. Quant. Grav. 34 (2017), 063001, [arXiv:1608.06147].
- [12] S. Fernando and D. Krug, Charged black hole solutions in Einstein– Born–Infeld gravity with a cosmological constant, Gen. Rel. Grav. 35 (2003), 129–137, [arXiv:hep-th/0306120].

- [13] T. K. Dey, Born–Infeld black holes in the presence of a cosmological constant, Phys. Lett. B 595 (2004), 484–490, [arXiv:hep-th/0406169].
- [14] R.-G. Cai, D.-W. Pang and A. Wang, Born–Infeld black holes in (A)dS spaces, Phys. Rev. D 70 (2004), 124034, [arXiv:hep-th/0410158].
- [15] S. Fernando, Thermodynamics of Born–Infeld-anti-de Sitter black holes in the grand canonical ensemble, Phys. Rev. D 74 (2006), 104032, [arXiv:hep-th/0608040].
- [16] Y. S. Myung, Y.-W. Kim and Y.-J. Park, Thermodynamics and phase transitions in the Born–Infeld-anti-de Sitter black holes, Phys. Rev. D 78 (2008), 084002, [arXiv:arXiv:0805.0187].
- [17] R. Banerjee and D. Roychowdhury, Critical phenomena in Born-Infeld AdS black holes, Phys. Rev. D 85 (2012), 044040, [arXiv:1111.0147].
- [18] O. Miskovic and R. Olea, Thermodynamics of Einstein–Born–Infeld black holes with negative cosmological constant, Phys. Rev. D 77 (2008), 124048, [arXiv:0802.2081].
- [19] Behnam Pourhassan, M. Dehghani, Mir Faizal, Sanjib Dey, Non-Pertubative Quantum Corrections to a Born–Infeld Black Hole and its Information Geometry, Class. Quantum Grav. 38 (2021), 105001, [arXiv:2012.14428].
- [20] B. Pourhassan, M. Dehghani, S. Upadhyay, Izzet Sakalli, D. V. Singh, Exponential corrected thermodynamics of quantum Born–Infeld BTZ black holes in massive gravity, Modern Physics Letters A 37 (2022), 2250230, [arXiv:2301.01603].
- [21] S. Gunasekaran, R. B. Mann and D. Kubiznak, Extended phase space thermodynamics for charged and rotating black holes and Born—Infeld vacuum polarization, JHEP 1211 (2012), 110, [arXiv:1208.6251].
- [22] D.-C. Zou, S.-J. Zhang and B. Wang, Critical behavior of Born-Infeld AdS black holes in the extended phase space thermodynamics, Phys. Rev. D 89 (2014), 044002, [arXiv:1311.7299].
- [23] S. H. Hendi and M. H. Vahidinia, Extended phase space thermodynamics and P-V criticality of black holes with a nonlinear source, Phys. Rev. D 88 (2013), 084045, [arXiv:1212.6128].

- [24] S. H. Hendi, S. Panahiyan and B. Eslam Panah, P-V criticality and geometrical thermodynamics of black holes with Born-Infeld type nonlinear electrodynamics, Int. J. Mod. Phys. D 25 (2015), 1650010, [arXiv:1410.0352].
- [25] X.-X. Zeng, X.-M. Liu and L.-F. Li, Phase structure of the Born–Infeldanti-de Sitter black holes probed by non-local observables, Eur. Phys. J. C 76 (2016), 616, [arXiv:1601.01160].
- [26] O. ¨ Okc¨u and E. Aydiner, Joule–Thomson expansion of the charged AdS ¨ black holes, Eur. Phys. J. C 77 (2017), 24, [arXiv:1611.06327].
- [27] H. Ghaffarnejad, E. Yaraie and M. Farsam, Quintessence Reissner– Nordstrom anti de Sitter black holes and Joule–Thomson effect, Int. J. Theor. Phys. 57 (2018), 1671, [arXiv:1802.08749].
- [28] C. L. A. Rizwan, A. N. Kumara, D. Vaid and K. M. Ajith, Joule– Thomson expansion in AdS black hole with a global monopole, Int. J. Mod. Phys. A 33 (2018), 1850210, [arXiv:1805.11053].
- [29] M. Chabab, H. El Moumni, S. Iraoui, K. Masmar and S. Zhizeh, Joule-Thomson Expansion of RN-AdS Black Holes in f(R) gravity, Lett. High Energy Phys. 05 (2018), 02, [arXiv:1804.10042].
- [30] B. Mirza, F. Naeimipour and M. Tavakoli, Joule-Thomson expansion of the quasitopological black holes, Frontiers in Physics 9 (2021), 628727, [arXiv:2105.05047].
- [31] S. I. Kruglov, NED-AdS black holes, extended phase space thermodynamics and Joule—Thomson expansion, Nucl. Phys. B 984 (2022), 115949, [arXiv:2209.10524].
- [32] S. I. Kruglov, Magnetic black holes in AdS space with nonlinear electrodynamics, extended phase space thermodynamics and Joule—Thomson expansion, Int. J. Geom. Meth. Mod. Phys. 20 (2023), 2350008, [arXiv:2210.10627].
- [33] Sergey Il'ich Kruglov, AdS Black Holes in the Framework of Nonlinear Electrodynamics, Thermodynamics, and Joule—Thomson Expansion, Symmetry 14 (2022), 1597, [arXiv:2209.05394].

- [34] S. I. Kruglov, Nonlinearly charged AdS black holes, extended phase space thermodynamics and Joule—Thomson expansion, Ann. Phys. 441 (2022) 168894, [arXiv:2208.13662].
- [35] S. I. Kruglov, Magnetically Charged AdS Black Holes and Joule— Thomson Expansion, Grav. Cosm. 28, (2023) 57.
- [36] S. I. Kruglov, Nonlinear Electrodynamics and Magnetic Black Holes, Annalen Phys. (Berlin) 529 (2017), 1700073 [arXiv:1708.07006].
- [37] K. A. Bronnikov, Regular magnetic black holes and monopoles from nonlinear electrodynamics, Phys. Rev. D 63 (2001), 044005, [arXiv:grqc/0006014].
- [38] D. Kastor, S. Ray and J. Traschen, Enthalpy and the Mechanics of AdS Black Holes, Class. Quant. Grav. 26 (2009), 195011, [arXiv:0904.2765].
- [39] B. P. Dolan, The cosmological constant and the black hole equation of state, Class. Quant. Grav. 28 (2011), 125020, [arXiv:1008.5023].
- [40] M. Cvetic, G. W. Gibbons, D. Kubiznak and C. N. Pope, Black Hole Enthalpy and an Entropy Inequality for the Thermodynamic Volume, Phys. Rev. D 84 (2011), 024037, [arXiv:1012.2888].
- [41] D. Kubiznak, R. B. Mann, P-V criticality of charged AdS black holes, JHEP 07 (2012), 033, [arXiv:1205.0559].
- [42] Wan Cong, D. Kubiznak, R. B. Mann and M. Visser, Holographic CFT Phase Transitions and Criticality for Charged AdS Black Holes, JHEP 08 (2022), 174, [arXiv:2112.14848].
- [43] L. Smarr, Mass formula for Kerr black holes, Phys. Rev. Lett. 30 (1973), 71-73.