# Black hole collapse and bounce in effective loop quantum gravity

Jarod George Kelly,\* Robert Santacruz,<sup>†</sup> and Edward Wilson-Ewing<sup>‡</sup>
Department of Mathematics and Statistics, University of New Brunswick, Fredericton, NB, Canada E3B 5A3

We derive effective equations with loop quantum gravity corrections for the Lemaître-Tolman-Bondi family of space-times, and use these to study quantum gravity effects in the Oppenheimer-Snyder collapse model. For this model, after the formation of a black hole with an apparent horizon, quantum gravity effects become important in the space-time region where the energy density and space-time curvature scalars become comparable to the Planck scale. These quantum gravity effects first stop the collapse of the dust matter field when its energy density reaches the Planck scale, and then cause the dust field to begin slowly expanding. Due to this continued expansion, the matter field will eventually extend beyond the apparent horizon, at which point the horizon disappears and there is no longer a black hole. There are no singularities anywhere in this space-time. In addition, in the limit that edge effects are neglected, we show that the dynamics for the interior of the star of uniform energy density follow the loop quantum cosmology effective Friedman equation for the spatially flat Friedman-Lemaître-Robertson-Walker space-time. Finally, we estimate the lifetime of the black hole, as measured by a distant observer, to be  $\sim (GM)^2/\ell_{\rm Pl}$ .

### I. INTRODUCTION

General relativity is typically expected to break down when the curvature reaches the Planck scale, at which point a theory of quantum gravity becomes necessary. One important example is a black hole of mass M: in the simplest case of the Schwarzschild vacuum spherically symmetric space-time, the Kretschmann scalar  $R_{\mu\nu\rho\sigma}R^{\mu\nu\rho\sigma}\sim (2GM)^2/r^6$  reaches the Planck scale at the radius  $r\sim (2GM\ell_{\rm Pl}^2)^{1/3}$ , suggesting that quantum gravity effects may become important not only close to the singularity at r=0, but as far away from the black hole center as  $(2GM\ell_{\rm Pl}^2)^{1/3}$ .

In addition to quantum gravity effects being presumably important in vacuum black hole solutions, quantum gravity is also expected to play an important role during black hole collapse. While the matter forming the star is classically predicted to reach the central singularity, quantum gravity effects could resolve the singularity and modify the dynamics of infalling matter.

In spherically symmetric space-times, there are no gravitational waves and therefore to study black hole collapse a matter field is needed. A simple choice is pressureless dust; spherically symmetric space-times minimally coupled to dust are known as the Lemaître-Tolman-Bondi (LTB) solutions [1–3].

To explore how quantum gravity effects may modify black hole collapse, we will consider the effect of expressing the (classical) Hamiltonian in terms of area and holonomy variables, as suggested by loop quantum gravity (LQG) [4]. (For the quantization of LTB space-times in other contexts, see [5–7].) In this approach, the Hamiltonian depends on holonomies of the Ashtekar-Barbero connection along paths of physical length  $\sim \ell_{\rm Pl}$ , rather

than the connection itself. The resulting 'effective' equations of motion include quantum gravity effects due to the presence of these Planck-length holonomies in the Hamiltonian. For cosmology, the effective equations derived in this manner have been shown to give an excellent approximation to the leading order quantum gravity effects for sharply-peaked states in loop quantum cosmology (LQC) [8]. Note that to ensure the physical length of the holonomy paths is  $\sim \ell_{\rm Pl}$ , the coordinate length has to be related to the physical length through the metric; this step is essential to obtain physical results (otherwise an unphysical coordinate length is related to the physical Planck scale, resulting in inconsistencies) and this procedure is called, for historical reasons, the 'improved dynamics' or ' $\bar{\mu}$ -scheme' [9].

There has been considerable work studying various LQG effects in spherically symmetric space-times. For vacuum space-times, most studies are based on the isometry between the classical Schwarzschild interior and the Kantowski-Sachs space-time [10–24], but this isometry is based on results in classical general relativity and may not hold in LQG (it is also unclear how to properly carry out the  $\bar{\mu}$  scheme when a spatial coordinate becomes null at a horizon). The full vacuum space-time (interior and exterior) was first studied without using the  $\bar{\mu}$  scheme [25–31], and more recent work has shown how to include that missing step and implement the  $\bar{\mu}$  scheme in vacuum spherically symmetric space-times [32–34].

To study black hole collapse, it is necessary to include a matter field. For previous work on the inclusion of matter fields in spherical symmetry in the context of LQG, see [27, 35–38], and for studies of black hole collapse based on this approach, see [38–42]. (And for other LQG/LQC-based studies of black hole collapse, see [43–51]). Although these studies provide interesting insights into potential quantum gravity effects in black hole collapse—in particular, many predict that the black hole singularity is resolved and that the black hole bounces into a white-hole-like solution—none use the  $\bar{\mu}$  scheme throughout the entire space-time. (Some of these studies do not use the

<span id="page-0-0"></span><sup>\*</sup> jarod.kelly@unb.ca

<span id="page-0-1"></span><sup>†</sup> robert.santacruz@unb.ca

<span id="page-0-2"></span><sup>&</sup>lt;sup>‡</sup> edward.wilson-ewing@unb.ca

 $\bar{\mu}$  scheme at all, while others use it only for the interior of the star and use the equations of general relativity for the vacuum region outside the star.) Finally, there have also been some studies of LQG-motivated inverse triad effects in spherical symmetry, for details see [52–56].

In this paper we will show how to implement the  $\bar{\mu}$  scheme for the full family of LTB space-times and then use this framework to derive effective equations of motion. These equations will hold both in the presence and absence of matter, as well as inside and outside a horizon. We then use the resulting effective equations to study LQG effects in the Oppenheimer-Snyder black hole collapse model. Note that we will refer to a black hole being present if there is, at that instant of (coordinate) time, an apparent horizon; we do not require an event horizon to exist since we do not necessarily expect an event horizon to be present in a non-singular black hole space-time.

#### <span id="page-1-1"></span>II. CLASSICAL THEORY

The line element for a spherically symmetric spacetime can be put in the form

$$ds^{2} = -N^{2}dt^{2} + \frac{(E^{b})^{2}}{E^{a}}(dx + N^{x}dt)^{2} + E^{a}d\Omega^{2}, \quad (1)$$

where N(x,t) and  $N^x(x,t)$  are the lapse and the radial component of the shift vector,  $E^a(x,t)$  and  $E^b(x,t)$  are the densitized triad in the radial and angular directions, and  $d\Omega^2 = d\theta^2 + \sin^2\theta \ d\phi^2$ .

The densitized triads are conjugate to the Ashtekar-Barbero connection whose components are [34]

$$A_a^i \tau_i dx^a = a \tau_1 dx + \left( b \tau_2 + \frac{\partial_x E^a}{2E^b} \tau_3 \right) d\theta + \left( \cot \theta \tau_1 - \frac{\partial_x E^a}{2E^b} \tau_2 + b \tau_3 \right) \sin \theta d\phi.$$
 (2)

Here a(x,t) and b(x,t) capture the extrinsic curvature in the radial and angular directions respectively, while  $\tau^{j} = -i\sigma^{j}/2$ , with  $\sigma^{j}$  the Pauli matrices.

For the Lemaître-Tolman-Bondi (LTB) space-times the matter content is a pressureless dust field and, after integrating over  $d\Omega$ , the action is [57]

$$S = \int dt \int dx \left[ \frac{\dot{a}E^a + 2\dot{b}E^b}{2G\gamma} + 4\pi \dot{T}p_T - N\left(\mathcal{H}^{(g)} + \mathcal{H}^{(d)}\right) - N^x \left(\mathcal{H}_x^{(g)} - 4\pi p_T \partial_x T\right) \right]. \tag{3}$$

Here T denotes the dust field and  $p_T$  is its conjugate momentum, while the dots denote derivatives with respect to t. The contributions to the scalar constraint from the

gravitational and dust sectors are

$$\mathcal{H}^{(g)} = -\frac{1}{2G\gamma^2} \left( 2ab\sqrt{E^a} + \frac{E^b}{\sqrt{E^a}} (b^2 + \gamma^2) \right) + \frac{1}{8G} \frac{(\partial_x E^a)^2}{E^b \sqrt{E^a}} + \frac{\sqrt{E^a}}{2G} \partial_x \left( \frac{\partial_x E^a}{E^b} \right), \quad (4)$$

$$\mathcal{H}^{(d)} = 4\pi \sqrt{p_T^2 + \frac{E^a}{(E^b)^2} p_T^2 (\partial_x T)^2},$$
 (5)

and the gravitational term in the diffeomorphism constraint is  $\mathcal{H}_x^{(g)} = (2G\gamma)^{-1} \cdot (2E^b\partial_x b - a\partial_x E^a)$ .

The Hamiltonian framework can be simplified by using the dust-time gauge to fix the scalar constraint [57] and the areal gauge to fix the diffeomorphism constraint [13, 34]. After this gauge-fixing there will remain a true Hamiltonian, with no constraints left. Note that due to this gauge-fixing procedure, the resulting effective theory does not fall within the class of (vacuum) models studied in [58].

The benefit of the dust-time gauge T=t is clear, as then  $\partial_x T=0$ . The gauge-fixing condition  $\chi_1=T-t=0$  is second-class with the scalar constraint, so  $\chi_1$  can be used to gauge-fix it. Solving the scalar constraint gives  $4\pi p_T=-\mathcal{H}^{(g)}$ , while requiring that the gauge-fixing condition be preserved by the dynamics imposes N=1. Further, the symplectic term in the action  $4\pi p_T \dot{T}$  simplifies to  $4\pi p_T=-\mathcal{H}^{(g)}$ , which becomes a true physical Hamiltonian  $\mathcal{H}_{\rm phys}=\mathcal{H}^{(g)}$  [57].

The next simplification is to impose the areal gauge through the condition  $\chi_2 = E^a - x^2 = 0$ , which imposes that a sphere at radius x has surface area  $4\pi x^2$ . The condition  $\chi_2$  is second-class with the diffeomorphism constraint, which can be solved giving  $a = E^b(\partial_x b)/x$ , and requiring that  $\chi_2$  be preserved dynamically gives  $N^x = -b/\gamma$  [34]. Since  $E^a$  is independent of time, the  $\dot{a}E^a$  term is a total time derivative and can be dropped from the action, while  $\mathcal{H}_{\text{phys}}$  simplifies considerably after substituting for  $E^a$  and a:

$$S_{GF} = \int dt \int dx \left( \frac{\dot{b}E^b}{G\gamma} - \mathcal{H}_{phys} \right), \tag{6}$$

$$\mathcal{H}_{phys} = -\frac{1}{2G\gamma} \left[ \frac{E^b}{\gamma x} \left( b^2 + x \partial_x b^2 \right) + \frac{\gamma E^b}{x} + \frac{2\gamma x^2}{(E^b)^2} \partial_x E^b - \frac{3\gamma x}{E^b} \right]. \tag{7}$$

After fixing these two gauges, the metric reduces to

<span id="page-1-0"></span>
$$ds^{2} = -dt^{2} + \frac{(E^{b})^{2}}{x^{2}} (dx + N^{x} dt)^{2} + x^{2} d\Omega^{2}, \quad (8)$$

with  $N^x = -b/\gamma$  for classical general relativity, and it is clear that there is one physical degree of freedom at each point due to the dust field (there are no gravitational waves in spherically symmetric space-times). The energy

density  $\rho(x,t)$  of the dust field, related to the dust contribution to the scalar constraint by  $\mathcal{H}^{(d)} = \int d\Omega \sqrt{q} \rho$ , where  $\sqrt{q}$  is the determinant of the spatial metric, is

<span id="page-2-3"></span>
$$\rho = \frac{p_T}{\sqrt{E^a} E^b} = -\frac{\mathcal{H}_{\text{phys}}}{4\pi x E^b},\tag{9}$$

and the remaining non-trivial Poisson bracket is

<span id="page-2-0"></span>
$$\{b(x_1, t), E^b(x_2, t)\} = G\gamma \,\delta(x_1 - x_2). \tag{10}$$

The dynamics follow from  $\dot{f} = \{f, \int dx \, \mathcal{H}_{phys}\}$ , giving

$$\dot{E}^b = \frac{bE^b}{\gamma x} - \frac{b}{\gamma} \,\partial_x E^b,\tag{11}$$

$$\dot{b} = \frac{\gamma x}{2(E^b)^2} - \frac{1}{2\gamma x} \left( 2xb\partial_x b + b^2 + \gamma^2 \right). \tag{12}$$

These are the usual equations of motion for the LTB family of metrics, for the Painlevé-Gullstrand coordinates (8) of the metric [59, 60], and in a form convenient to include holonomy corrections as motivated by LQG.

### LTB EFFECTIVE EQUATIONS

One of the main features of LQG is that the fundamental operators, out of which all other operators are constructed, are holonomies of  $A_a$  and the areas  $E^a$ . In LQC, it has been shown that there exist 'effective equations' that provide a good approximation to the dynamics of expectation values of observables, at least for wave functions that are sharply peaked and whose expectation value for the spatial volume satisfies  $\langle V \rangle \gg \ell_{\rm Pl}^3$  [61, 62]. These effective equations can be derived as the Hamilton equations of an effective Hamiltonian that includes modifications proportional to  $\hbar$  which ensure the resulting dynamics track sharply-peaked wave functions in the full quantum theory.

To derive an effective Hamiltonian for (gauge-fixed) LTB space-times, the main step is to replace the connection component b by minimal length holonomies of b in the classical gauge-fixed Hamiltonian. (Recall that after the gauge-fixing imposed in Sec. II, the system is described by a single true Hamiltonian—there are no constraints left.) It is necessary that these holonomies give trigonometric functions of b (without b-dependent prefactors) for it to be possible to promote the holonomies to operators in LQC. This condition is satisfied by holonomies of the extrinsic curvature 1-form in the  $\theta$  direction,

$$h_{\theta}(2\delta_b) = \exp\left(\int_0^{2\delta_b} b\tau_2 d\theta\right)$$
$$= \cos(\delta_b b) \mathbb{I} + 2\sin(\delta_b b) \tau_2. \tag{13}$$

This is known as the 'K' loop quantization, for details see [63, 64]. (The path could be a portion of any great circle on the sphere, for simplicity we took  $\phi = \text{const.}$ )

Still following [63, 64], the coordinate length  $2\delta_b$  must be chosen so that the physical length of the path is  $\sqrt{\Delta}$ , where  $\Delta \sim \ell_{\rm Pl}^2$  is the smallest non-zero eigenvalue of the area operator in LQG. (The factor of 2 is to ensure consistency with expressions of the curvature in terms of holonomies [65].) For this path, x and  $\phi$  are constant, so the metric (8) implies  $ds = x d\theta$ . Integrating and requiring that the physical length be  $\sqrt{\Delta}$  gives  $\int_0^{\sqrt{\Delta}} ds = \int_0^{2\delta_b} x \, d\theta$ , so  $2\delta_b = \sqrt{\Delta}/x$ , see also [32–34]. Finally, b must be replaced in  $\mathcal{H}_{\text{phys}}$  by an appropriate

expression in terms of  $h_{\theta}(2\delta_b)$  [63, 64],

$$b \to \frac{-2\operatorname{Tr}(h_{\theta}(2\delta_b) \cdot \tau_2)}{2\delta_b} = \frac{x}{\sqrt{\Delta}}\sin\left(\frac{\sqrt{\Delta}}{x}b\right).$$
 (14)

This substitution gives the effective physical Hamiltonian for LTB space-times,

<span id="page-2-4"></span>
$$\mathcal{H}_{\text{phys}}^{LQG} = -\frac{1}{2G\gamma} \left[ \frac{E^b}{\gamma x} \partial_x \left( \frac{x^3}{\Delta} \sin^2 \frac{\sqrt{\Delta} b}{x} \right) - \frac{3\gamma x}{E^b} + \frac{2\gamma x^2}{(E^b)^2} \partial_x E^b + \frac{\gamma E^b}{x} \right]. \tag{15}$$

To reconstruct the space-time metric from the phase space variables it is necessary to find the shift  $N^x$ , and this requires rewriting the relation between  $N^x$  and b in terms of holonomies (as before, this step is required since there is no operator corresponding to b in the quantum theory). Following earlier work in vacuum spherically symmetric space-times gives [33, 34]

<span id="page-2-5"></span><span id="page-2-1"></span>
$$N^{x} = -\frac{x}{\gamma\sqrt{\Delta}}\sin\frac{\sqrt{\Delta}\,b}{x}\cos\frac{\sqrt{\Delta}\,b}{x}.\tag{16}$$

Note that the form of the metric (8) remains unchanged. The effective dynamics for general LTB space-times follow directly from  $\mathcal{H}^{LQG}_{\mathrm{phys}}$  and the (unchanged) Poisson

<span id="page-2-2"></span>
$$\dot{E}^b = -\frac{x^2}{\gamma\sqrt{\Delta}}\partial_x \left(\frac{E^b}{x}\right) \sin\frac{\sqrt{\Delta}\,b}{x} \cos\frac{\sqrt{\Delta}\,b}{x},\tag{17}$$

$$\dot{b} = \frac{\gamma}{2} \left( \frac{x}{(E^b)^2} - \frac{1}{x} \right) - \frac{1}{2\gamma \Delta x} \partial_x \left( x^3 \sin^2 \frac{\sqrt{\Delta} b}{x} \right). \tag{18}$$

These effective equations can be used to study LQG effects in LTB space-times, and in particular in black hole collapse models.

The vacuum solutions  $\rho = 0$  correspond to  $\mathcal{H}_{\mathrm{phys}}^{LQG} = 0$ and have already been studied [33, 34]. In Painlevé-Gullstrand coordinates, the metric for the vacuum solution has the form

<span id="page-2-6"></span>
$$ds^{2} = -\left(1 - \frac{R_{S}}{x} + \frac{\gamma^{2} \Delta R_{S}^{2}}{x^{4}}\right) dt^{2} + dx^{2} + 2\sqrt{\frac{R_{S}}{x} \left(1 - \frac{\gamma^{2} \Delta R_{S}}{x^{3}}\right)} dt dx + x^{2} d\Omega^{2}, \quad (19)$$

where  $R_S = 2GM$  is the Schwarzschild radius, and the quantum gravity corrections are proportional to  $\Delta$ . Note that for the vacuum case M=0, the result is the classical Minkowski solution without any quantum gravity corrections. Interestingly, this metric is only valid for  $x \ge x_{\min} = (\gamma^2 \Delta R_S)^{1/3}$  [33, 34]. This is not surprising, since in spherical symmetry there are no gravitational waves and therefore a central potential must be generated by some distribution of matter. Since LQC effects are known to bound  $\rho \lesssim \rho_{\rm Pl}$  by the Planck scale, this suggests that to have a source of mass M, there must be some matter content out to (assuming maximal density)  $x \sim (M/\rho_{\rm Pl})^{1/3}$ , in qualitative agreement with the bound  $x \geq x_{\min}$  for the vacuum solution. In the simple model for black hole collapse considered next, this expectation will be shown to be precisely correct.

This vacuum solution has an outer apparent horizon located at  $x_{\rm outer} \sim R_S - \gamma^2 \Delta/R_S$  and an inner apparent horizon at  $x_{\rm inner} \sim x_{\rm min} + (\gamma^4 \Delta^2/27R_S)^{1/3}$  [34]; matter that lies inside the inner horizon can remain at rest, or bounce and start to expand as required for a transition from a black hole to a white hole [50]. In the Planck regime, quantum gravity repulsive effects counteract the classical gravitational attractive force, and the outgoing expansion becomes positive again for  $x < x_{\rm inner}$ .

#### IV. BLACK HOLE COLLAPSE AND BOUNCE

A simple model for black hole collapse is the Oppenheimer-Snyder model [66]. This space-time belongs to the family of LTB solutions, and corresponds to a 'star' of radius L(t), with vacuum outside. The star is composed of pressureless dust, and it is further assumed that the star has a spatially constant density  $\rho$  within its interior:  $\rho(x,t) = \rho(t)$  if  $x \leq L(t)$  and  $\rho(x,t) = 0$  for x > L(t). As the star collapses, L(t) will decrease and  $\rho(t)$  will increase. To simplify the analysis, for now we neglect edge effects due to the discontinuity in  $\rho$  at the surface L of the star. Note that the interior of the Oppenheimer-Snyder model is a Friedman-Lemaître-Robertson-Walker (FLRW) cosmology, while the exterior is vacuum.

For a spatially flat interior, we set  $E^b = x$  which is clearly a solution of (17). Then (18) and (9) simplify to

$$\dot{b} = -\frac{1}{2\gamma\Delta x}\,\partial_x \left(x^3\sin^2\frac{\sqrt{\Delta}\,b}{x}\right),\tag{20}$$

$$\rho = \frac{1}{8\pi G \gamma^2 \Delta x^2} \, \partial_x \left( x^3 \, \sin^2 \frac{\sqrt{\Delta} \, b}{x} \right), \tag{21}$$

and conservation of energy implies that  $M = 4\pi\rho L^3/3$  is constant. The relation (21) is easily inverted, and for the collapsing Oppenheimer-Snyder model this gives

<span id="page-3-2"></span>
$$\sin \frac{\sqrt{\Delta b}}{x} = \begin{cases} -\sqrt{\rho(t)/\rho_c} & \text{if } x \le L(t), \\ -\sqrt{3M/4\pi\rho_c x^3} & \text{if } x > L(t), \end{cases}$$
 (22)

where the critical energy density is  $\rho_c = 3/(8\pi G\gamma^2\Delta)$ . Note that the overall minus sign is chosen so  $N^x > 0$  and the star collapses (for  $\cos(\sqrt{\Delta b}/x) \ge 0$ ).

Combining (20) and the interior solution (22) gives an equation for  $\dot{\rho}$ , and using  $\rho = 3M/4\pi L^3$  this becomes

$$\left(\frac{\dot{L}}{L}\right)^2 = \frac{8\pi G}{3}\rho\left(1 - \frac{\rho}{\rho_c}\right),\tag{23}$$

exactly the LQC effective Friedmann equation for spatially flat FLRW space-times with scale factor L [9]. This is easily solved, with the result

<span id="page-3-4"></span>
$$L(t) = \left[\gamma^2 \Delta R_S \left(\frac{9t^2}{4\gamma^2 \Delta} + 1\right)\right]^{1/3}, \qquad (24)$$

and  $\rho = 3M/4\pi L^3$ .

This solution shows that the star contracts until it reaches  $L = x_{\min} = (\gamma^2 \Delta R_S)^{1/3} \sim (\ell_{\rm Pl}^2 R_S)^{1/3}$  at t = 0, when there is a bounce, and after this the radius L of the star begins to expand: quantum gravity effects generate a non-singular transition from a black hole to something similar to a white hole, as has previously been suggested [67–69]. The difference between the white hole solution proposed in these works and the post-bounce t>0 solution derived here is subtle, but important. In the white hole solution for vacuum general relativity, the whole interior of the white hole is anti-trapped. For this solution, it is only part of the region inside x < L(t)that is anti-trapped, while on the other hand the region  $L(t) < x < R_S$  is trapped, like for a black hole; see Fig. 1. L will move outwards, and once L reaches a value  $L(t) > x_{\text{outer}} \sim R_S$ , the apparent horizon will go away and so at this time there is no longer a black hole—this Oppenheimer-Snyder space-time only contains a black hole for the time interval between when  $L = x_{\text{outer}}$  during the contracting phase and when  $L = x_{\text{outer}}$  after the bounce.

Importantly, the minimal value of the radius of the star is  $L=x_{\min}$ . This fits exactly with the constraint that the vacuum solution is only valid for  $x \geq x_{\min}$ : the curvature of the space-time (in the absence of gravitational waves) must be generated by a matter field, and since  $\rho$  is bounded in LQC, matter must extend out at least to the minimal radius  $x_{\min}$  (that depends on M).

<span id="page-3-1"></span><span id="page-3-0"></span>The metric describing this collapse and bounce of a black hole is (8), with  $E^b = x$  and the shift vector

<span id="page-3-3"></span>
$$N^{x} = \begin{cases} -\frac{6xt}{9t^{2} + 4\gamma^{2}\Delta} & \text{if } x \leq L(t), \\ \sqrt{\frac{R_{S}}{x} \left(1 - \frac{\gamma^{2}\Delta R_{S}}{x^{3}}\right)} & \text{if } x > L(t). \end{cases}$$
 (25)

For the interior, the coordinate transformation  $x=L(t)\chi$  gives the flat FLRW metric

$$ds^{2} = -dt^{2} + L^{2}(t) \left( d\chi^{2} + \chi^{2} d\Omega^{2} \right). \tag{26}$$

![](_page_4_Figure_1.jpeg)

Figure 1. This shows a snapshot of the lightcones on a spatial slice of the effective Oppenheimer-Snyder space-time at an instant of time, after the bounce has occurred and L is moving outwards. The dust field is shown in gray, and the energy density of the dust field will be larger near L than in the interior. The dust field is coupled to gravity, and will act on the space-time geometry of the outer neighbourhood of L with the ultimate effect of rotating the lightcone in that neighbourhood upwards. This in turn will allow the dust to move outwards, little by little, as the outer neighbourhood of L stops being trapped. An estimate of the rate of expansion of L is given in Sec. V.

It is easy to verify that  $N^x$  is continuous at x = L when the star is contracting, but these terms differ by a sign after the bounce: for t > 0, there will be a shock wave in the gravitational field with a discontinuity at x = L in b(x) and in the effective metric.

The presence of a discontinuity in the gravitational field variable b (and also in the space-time metric) shows that the assumption that edge effects can be neglected (which the calculations giving (22)–(25) rely upon) fails after the bounce at t=0, and therefore the solution (22)– (25) cannot be expected to be correct for the expanding post-bounce phase. To correctly describe the expanding phase and the effect of the shock wave that appears then, it is necessary to include the edge effects which have been ignored so far. Note that this shock wave, i.e., the discontinuity in b, will persist when edge effects are included—so the importance of including edge effects is not to remove the shock wave (which is predicted to form whether edge effects are included in the analysis or not), but rather to be able to accurately calculate the rate at which the shock wave moves outwards after the bounce.

### <span id="page-4-0"></span>V. THE WHITE HOLE SHOCK WAVE

Since  $E^b = x$ , as assumed at the onset of the Oppenheimer-Snyder collapse, the dynamics of the shock wave are given by  $\dot{E}^b = 0$ , due to (17), and

$$\dot{b} = -4\pi G \gamma x \rho, \tag{27}$$

$$\dot{\rho} = \frac{1}{3\gamma \Delta x^2} \partial_x \left( x^4 N^x \rho \right), \tag{28}$$

which follow from (9), (15), (16), and (18). Note that these equations hold even if  $\rho$  is not (piecewise) spatially homogeneous.

The first equation clearly shows that b is monotonically decreasing, and constant outside the star where  $\rho = 0$  (this is why  $N^x$  remains constant for x > L). Away from the edge x = L, the second equation shows that  $\rho$  increases for  $N^x > 0$  (a collapsing star) while  $\rho$  decreases for  $N^x < 0$  (the post-bounce expanding white hole).

One way to explore the edge dynamics near x=L is to do a simple discretization of (28) on a lattice with spacing  $\delta x$ , replacing  $\partial_x f(x_i) \to [f(x_{i+1}) - f(x_{i-1})]/2\delta x$ . During collapse,  $N^x > 0$  everywhere and at the edge  $x_i = L$ , the discretized derivative is negative since  $\rho(x_{i+1}) = 0$  and  $\rho(x_{i-1}) > 0$ , so  $\dot{\rho}(x_i) < 0$ . As expected, in a collapse the density increases inside the star, and decreases at  $x_i$  precisely as the edge L becomes smaller than  $x_i$ . This agrees with (25), which can be trusted for the collapse phase as there is no shock wave then.

On the other hand, after the bounce  $N^x < 0$  inside the expanding star, but  $N^x > 0$  in the surrounding vacuum region. If the edge is at  $x_i = L$  (assuming  $N^x < 0$  for  $x_j \leq x_i$  and  $N^x > 0$  for  $x_j \geq x_{i+1}$ , it is easy to see that  $\dot{\rho}(x_{i+1}) > 0$  since  $\rho(x_{i+2}) = 0$  and  $N^x(x_i) < 0$ . However, at the next time step the dust field cannot (yet) go beyond  $x_{i+1}$ : this is because  $\dot{\rho}(x_{i+2}) < 0$  due to  $N^{x}(x_{i+1}) > 0$ , even though now  $\rho(x_{i+1}) > 0$ . (Of course,  $\rho$  cannot decrease below 0,  $\dot{\rho}$  < 0 occurring in this context is an artefact of the simple discretization.) Instead, the white hole cannot expand further until  $N^x(x_{i+1})$  becomes negative, i.e., when  $\sin(\sqrt{\Delta}b(x_{i+1})/x_{i+1}) = -1$ . So the discontinuity in  $N^x$  will cause the white hole to expand at a much slower rate than it collapsed. Also, the dust field will accumulate near the edge x = L (since  $\dot{\rho}(x_i), \ \dot{\rho}(x_{i+1}) > 0$  as long as L does not move), so  $\rho$  will become greater at the wave front than inside the star. Results obtained neglecting edge effects can be trusted far from the white hole edge, but the wave front location L will move outwards at a slowed rate and  $\rho$  will be greater near L than for  $x \ll L$ .

<span id="page-4-2"></span><span id="page-4-1"></span>From a physical perspective, the dust field in the vicinity of x=L is caught between an outside trapped region and an inside anti-trapped region, as shown in Fig. 1. Although the matter field located at L initially cannot move, it is of course coupled to gravity and changes the geometry of the space-time in its neighbourhood. In particular, in the outer neighbourhood of L, the orientation of the lightcones will change so that this region is no longer trapped, and then the dust field will be able to move outwards into this region. This slow process will end once L reaches the outer horizon, at which point the

matter fields will be able to freely move outwards. In the following, we estimate the time required for L to reach  $T_{\text{outer}}$ 

This calculation can be used to obtain an estimate for the lifetime T of a black hole (as measured by a distant observer detecting light signals emitted from the surface of the star), which is given by the coordinate time t elapsed between the instants when  $L = x_{\text{outer}} \sim R_S$  before and after the bounce, as shown in the Appendix.

From (24), the duration of the contracting portion (from  $L = x_{\text{outer}}$  to  $L = x_{\text{min}}$ ) is  $\sim R_S$ , so the last step to find T is to calculate the duration of the expanding phase, from  $L = x_{\text{min}}$  to when  $L = x_{\text{outer}}$  once more. A precise determination of the white hole's lifetime T will require a considerably more detailed analysis, likely including high-resolution numerics, but it is possible to obtain a simple estimate for T by using (27) to calculate the time  $\delta t_i$ , for each location of the shock-wave front L, it takes for  $N^x$  to change sign, and then sum over all x from  $x_{\text{min}}$  to  $R_S$ , assuming  $\delta x \sim \ell_{\text{Pl}}$ .

It is enough to start the calculation at, say,  $x_i \sim \sqrt{\ell_{\rm Pl}R_S} \gg x_{\rm min}$ . (The following calculation can also be used to estimate the contribution to T for the time elapsed while  $x_{\rm min} < L(t) < x_i$ , which shows that it is subleading compared to the contribution from  $x_i < L < x_{\rm outer}$  and so can safely be ignored for an estimate of the leading contribution to T.) When the front L of the shock wave first reaches the radius x, then  $|\sin(\sqrt{\Delta}b/x)| \ll 1$  for  $x \ge x_i$  and therefore, for  $N^x$  to change signs, b must change by  $\sim -\pi x/2\sqrt{\Delta}$ . Then, from (27) it follows that (dropping numerical prefactors of order 1)  $\delta t_i \sim 1/(G\sqrt{\Delta}\rho(x_i))$ .

At the bounce,  $\rho = \rho_c$  but  $\rho$  will decrease as the shock wave expands. The leading edge of the shock wave will have a greater  $\rho$  than the center (where  $\rho$  evolves in a symmetric fashion around the bounce) since the dust field will be pushed towards the edge where it will accumulate due to the slow expansion of the front of the shock wave. After some time, it can be expected that a significant fraction of the dust field will lie within a short distance w of the leading front, in which case the energy density at the edge  $\rho_e$  will scale as  $\rho_e \sim M/(x^2w)$ . Evaluating  $\rho$  at the bounce gives  $\rho_c \sim M/x_{\rm min}^3$  so  $M \sim \Delta \rho_c R_S$  and  $\rho_e \sim \Delta \rho_c R_S/x^2w$ . Then,  $\delta t_i \sim wx^2/(G\Delta^{3/2}R_S\rho_c)$  and, since the pre-bounce phase is much shorter than the post-bounce expansion,

$$T \sim \sum_{i} \delta t_{i} \sim \int_{x_{i}}^{R_{S}} \frac{\delta t_{i}}{\ell_{\text{Pl}}} dx \sim \frac{wR_{S}^{2}}{\ell_{\text{Pl}}^{2}},$$
 (29)

similar what is suggested in [48]. If w is independent of  $R_S$ , then  $w/\ell_{\rm Pl}$  is a (potentially large) dimensionless constant and the black hole lifetime  $T \sim R_S^2/\ell_{\rm Pl}$  is significantly shorter than the Page time [70] in which case the standard black hole information loss problem is avoided.

### VI. DISCUSSION

The LTB space-times are spherically symmetric spacetimes coupled to pressureless dust. After imposing some convenient gauges, we constructed an effective Hamiltonian following the standard LQC procedure of replacing components of the Ashtekar-Barbero connection by holonomies using the  $\bar{\mu}$  scheme, and derived the effective equations for LTB space-times. A particularly interesting case is the Oppenheimer-Snyder model for black hole collapse, which can be solved exactly if edge effects are neglected; the result is that the star contracts until the density reaches the LQC critical density  $\rho_c \sim \rho_{\rm Pl}$ and then bounces; for the post-bounce phase it is necessary to include edge effects which become important. Although the post-bounce phase does not exactly correspond to a white hole, there are some significant similarities which lead us to view this model as a specific realization of quantum gravity generating a non-singular transition from a black hole to a 'white hole', as proposed in [67–69], with this general picture also found in [46, 47, 50, 71, 72]. Also, since the effective equations in this case are known for both the interior and exterior regions, as well as at the discontinuity at the surface of the star, it is now possible to properly include the edge effects that become large after the bounce.

The dynamics of the LQG Oppenheimer-Snyder spacetime can be split in two main phases: the black hole collapse and the white hole shock wave. First, the star collapses until its surface L(t) reaches  $x_{\text{outer}} \sim R_S$ , at which point an apparent horizon appears and the star forms a black hole. Then, quantum gravity effects become important when L nears  $x_{\min} \sim (\ell_{\rm Pl}^2 R_S)^{1/3}$ . The quantum gravity effects are sufficiently strong to stop the collapse of the star and cause a bounce. Note that the region inside  $x_{\min}$  is never trapped as there is an interior horizon at  $x = x_{\text{inner}} \sim x_{\text{min}} + (\gamma^4 \Delta^2 / 27 R_S)^{1/3}$ . Then, after the bounce, edge effects become important and slow the expansion of the star. These edge effects can be understood qualitatively to arise from the surface L being caught between an anti-trapped region lying within part of the interior of the star, and the trapped region outside the star for  $L < x < x_{\text{outer}}$ . As the surface of the star L slowly moves outwards, the trapped region becomes smaller, until  $L = x_{\text{outer}}$  and the apparent horizon vanishes; at this point the solution no longer corresponds to a black hole. We estimate that due to these edge effects, the lifetime of the black hole (as measured by a distant observer detecting light signals emitted from the surface of the star) is  $T \sim R_S^2/\ell_{\rm Pl}$ . Note that matter plays an important role in this context, giving a much shorter lifetime than what spin foam calculations have found for vacuum space-times [49, 51]. After the surface L of the star has once more passed  $x = x_{\text{outer}}$ , high-energy photons could be emitted by the expanding star, producing a potentially observable astronomical signature.

There are two results that show a remarkable unity between LQG holonomy corrections applied to different

families of space-times. First, the equation of motion for the Oppenheimer-Snyder (flat FLRW) interior is identical to the LQC effective Friedmann equation for flat FLRW space-times in the limit that edge effects are neglected. Although the derivation of the two equations is quite different, they describe the same physics, so it is reassuring that both procedures give the same dynamics. Second, the vacuum spherically symmetric solution for a black hole of mass M is only valid to a minimal radius  $x_{\min} \sim (R_S \ell_{\rm Pl}^2)^{1/3}$  [33, 34]. This vacuum solution corresponds to the exterior of the Oppenheimer-Snyder solution, and it turns out that the minimal radius of the interior is exactly  $x_{\min}$ : to generate a Schwarzschild-like exterior of mass M, there must be a matter field extending to at least the radius  $x_{\min}$ . Once again, the consistency between LQG results in vacuum and LTB space-times is remarkable.

There remain a number of important open problems that we leave for future work. First, a better understanding of the physics of the white hole shock wave could be used to calculate the lifetime of a black hole more accurately, and could also give predictions concerning the light emitted by a white hole that could be seen by distant observers. It would also be interesting to study more realistic black hole collapse models by including matter fields with pressure and/or a radially-varying density, and also to determine the stability of the solution to further infalling matter. We point out that since the expanding solution that we obtain is not exactly a white hole (although it does share some qualitative similarities), the instability results for white holes [73, 74] are not directly applicable here. Nonetheless, despite their differences, it does seem likely that at least some of the phenomenology of this model could be similar to what has been found for transitions from a black hole to a white hole [75–77]. Finally, it will also be important to include other quantum effects, most notably Hawking radiation, to obtain a complete picture of quantum gravity effects in black hole space-times.

## Appendix A: Lifetime of a Quantum Black Hole

The lifetime of the black hole is of course observer-dependent. Here we consider the lifetime as measured by a distant observer (located at a fixed radius  $x=R\gg R_S$ ), who measures the proper time elapsed between receiving two light signals; the first sent during the collapse of the star just before the black hole forms, and the second sent shortly after the surface of the star L exits the apparent horizon after the bounce.

<span id="page-6-0"></span>Here, for the sake of concreteness we assume that the two light signals are emitted from the x = L surface of the Oppenheimer-Snyder star when L = 3GM, but other

choices will give similar results. Explicitly, the first light signal is emitted when L=3GM during the contracting phase, and the second light signal is emitted when L=3GM after the bounce.

Using the coordinate system (19) for the vacuum exterior of the star, null radial geodesics satisfy

$$0 = -\dot{t}^2 + 2N^x \dot{t}\dot{x} + \dot{x}^2,\tag{A1}$$

with dots denoting a derivative with respect to an affine parameter. Note that the explicit form of  $N^x$  is not necessary here, all that matters is that  $N^x$  depends only the radial coordinate x but not on the time coordinate t; this condition will always be satisfied for the exterior of the Oppenheimer-Snyder star in spherical symmetry, even without assuming the Einstein equations (in classical general relativity,  $N^x = \sqrt{R_S/x}$ ).

By solving for  $\dot{t}/\dot{x} = dt/dx$  and integrating, it follows that the t and x coordinates for outgoing null radial geodesics (passing through  $x = x_o > R_S$  at the coordinate time  $t = t_o$ ) satisfy

<span id="page-6-1"></span>
$$t(x) = t_o + f(x) - f(x_o),$$
 (A2)

with 
$$f(x) = \int dx \left[ N^x + \sqrt{(N^x)^2 + 1} \right]$$
.

Therefore, if two light signals are emitted at x = 3GM at times  $t_1(3GM) = 0$  and  $t_2(3GM) = \Delta t_L$ , then the elapsed time (as measured by a distant observer located at  $x = R \gg R_S$ ) will be, using (A2),

$$\Delta t_{\rm d} = t_2(R) - t_1(R)$$

$$= t_2(3GM) + f(R) - f(3GM)$$

$$- [t_1(3GM) + f(R) - f(3GM)]$$

$$= \Delta t_L. \tag{A3}$$

Finally, the elapsed proper time for an observer at constant radius  $x = R \gg R_S$  is  $\Delta \tau_d \approx \Delta t_d$  for the metric (19) (up to small corrections of the order  $R_S/R$  that can safely be neglected), therefore

$$\Delta \tau_{\rm d} \approx \Delta t_{\rm d} = \Delta t_L.$$
 (A4)

So the lifetime of a quantum black hole is simply given by the difference in coordinate time, in terms of the metric (19), between the times the first and second light signals were emitted for some  $x_{\text{emission}} > R_S$ , respectively from the collapse and from the shock wave after the bounce.

### ACKNOWLEDGMENTS

We thank Viqar Husain for helpful discussions. This work was supported in part by the Natural Sciences and Engineering Research Council of Canada.

- [2] R. C. Tolman, "Effect of inhomogeneity on cosmological models," Proc. Nat. Acad. Sci. 20 (1934) 169–176. Republished in Gen. Rel. Grav. 29 (1997) 935.
- <span id="page-7-0"></span>[3] H. Bondi, "Spherically symmetrical models in general relativity," Mon. Not. Roy. Astron. Soc. 107 (1947) 410–425.
- <span id="page-7-1"></span>[4] T. Thiemann, Modern Canonical Quantum General Relativity. Cambridge Monographs on Mathematical Physics. Cambridge University Press, 2007.
- <span id="page-7-2"></span>[5] C. Vaz, L. Witten and T. Singh, "Toward a midisuperspace quantization of Lemaitre-Tolman-Bondi collapse models," Phys. Rev. D 63 (2001), 104020, [arXiv:gr-qc/0012053](http://arxiv.org/abs/gr-qc/0012053).
- [6] C. Kiefer, J. Muller-Hill and C. Vaz, "Classical and quantum LTB model for the non-marginal case," Phys. Rev. D 73 (2006) 044025, [arXiv:gr-qc/0512047](http://arxiv.org/abs/gr-qc/0512047).
- <span id="page-7-3"></span>[7] C. Kiefer and T. Schmitz, "Singularity avoidance for collapsing quantum dust in the Lemaˆıtre-Tolman-Bondi model," Phys. Rev. D 99 (2019) 126010, [arXiv:1904.13220](http://arxiv.org/abs/1904.13220).
- <span id="page-7-4"></span>[8] A. Ashtekar and P. Singh, "Loop Quantum Cosmology: A Status Report," Class. Quant. Grav. 28 (2011) 213001, [arXiv:1108.0893](http://arxiv.org/abs/1108.0893).
- <span id="page-7-5"></span>[9] A. Ashtekar, T. Pawlowski, and P. Singh, "Quantum Nature of the Big Bang: Improved dynamics," Phys. Rev. D74 (2006) 084003, [arXiv:gr-qc/0607039](http://arxiv.org/abs/gr-qc/0607039).
- <span id="page-7-6"></span>[10] L. Modesto, "Disappearance of black hole singularity in quantum gravity," Phys. Rev. D70 (2004) 124009, [arXiv:gr-qc/0407097](http://arxiv.org/abs/gr-qc/0407097).
- [11] A. Ashtekar and M. Bojowald, "Quantum geometry and the Schwarzschild singularity," Class. Quant. Grav. 23 (2006) 391–411, [arXiv:gr-qc/0509075](http://arxiv.org/abs/gr-qc/0509075).
- [12] C. G. Boehmer and K. Vandersloot, "Loop Quantum Dynamics of the Schwarzschild Interior," Phys. Rev. D76 (2007) 104030, [arXiv:0709.2129](http://arxiv.org/abs/0709.2129).
- <span id="page-7-14"></span>[13] M. Campiglia, R. Gambini, and J. Pullin, "Loop quantization of spherically symmetric midi-superspaces: The Interior problem," AIP Conf. Proc. 977 (2008) 52–63, [arXiv:0712.0817](http://arxiv.org/abs/0712.0817).
- [14] D.-W. Chiou, "Phenomenological loop quantum geometry of the Schwarzschild black hole," Phys. Rev. D78 (2008) 064040, [arXiv:0807.0665](http://arxiv.org/abs/0807.0665).
- [15] J. Brannlund, S. Kloster, and A. DeBenedictis, "The Evolution of Lambda Black Holes in the Mini-Superspace Approximation of Loop Quantum Gravity," Phys. Rev. D 79 (2009) 084023, [arXiv:0901.0010](http://arxiv.org/abs/0901.0010).
- [16] A. Joe and P. Singh, "Kantowski-Sachs spacetime in loop quantum cosmology: bounds on expansion and shear scalars and the viability of quantization prescriptions," Class. Quant. Grav. 32 (2015) 015009, [arXiv:1407.2428](http://arxiv.org/abs/1407.2428).
- [17] A. Corichi and P. Singh, "Loop quantization of the Schwarzschild interior revisited," Class. Quant. Grav. 33 (2016) 055006, [arXiv:1506.08015](http://arxiv.org/abs/1506.08015).
- [18] J. Cortez, W. Cuervo, H. A. Morales-T´ecotl, and J. C. Ruelas, "Effective loop quantum geometry of Schwarzschild interior," Phys. Rev. D 95 (2017) 064041, [arXiv:1704.03362](http://arxiv.org/abs/1704.03362).
- [19] J. Olmedo, S. Saini, and P. Singh, "From black holes to white holes: a quantum gravitational, symmetric bounce," Class. Quant. Grav. 34 (2017) 225011, [arXiv:1707.07333](http://arxiv.org/abs/1707.07333).

- [20] J. Ben Achour, F. Lamy, H. Liu, and K. Noui, "Polymer Schwarzschild black hole: An effective metric," EPL 123 (2018) 20006, [arXiv:1803.01152](http://arxiv.org/abs/1803.01152).
- [21] A. Ashtekar, J. Olmedo, and P. Singh, "Quantum Transfiguration of Kruskal Black Holes," Phys. Rev. Lett. 121 (2018) 241301, [arXiv:1806.00648](http://arxiv.org/abs/1806.00648).
- [22] N. Bodendorfer, F. M. Mele, and J. M¨unch, "Effective Quantum Extended Spacetime of Polymer Schwarzschild Black Hole," Class. Quant. Grav. 36 (2019) 195015, [arXiv:1902.04542](http://arxiv.org/abs/1902.04542).
- [23] E. Alesci, S. Bahrami, and D. Pranzetti, "Quantum gravity predictions for black hole interior geometry," Phys. Lett. B797 (2019) 134908, [arXiv:1904.12412](http://arxiv.org/abs/1904.12412).
- <span id="page-7-7"></span>[24] M. Assanioussi, A. Dapor, and K. Liegener, "Perspectives on the dynamics in a loop quantum gravity effective description of black hole interiors," Phys. Rev. D 101 (2020) 026002, [arXiv:1908.05756](http://arxiv.org/abs/1908.05756).
- <span id="page-7-8"></span>[25] M. Bojowald and R. Swiderski, "Spherically symmetric quantum geometry: Hamiltonian constraint," Class. Quant. Grav. 23 (2006) 2129–2154, [arXiv:gr-qc/0511108](http://arxiv.org/abs/gr-qc/0511108).
- [26] R. Gambini and J. Pullin, "Black holes in loop quantum gravity: The Complete space-time," Phys. Rev. Lett. 101 (2008) 161301, [arXiv:0805.1187](http://arxiv.org/abs/0805.1187).
- <span id="page-7-12"></span>[27] J. D. Reyes, "Spherically Symmetric Loop Quantum Gravity: Connection to Two-Dimensional Models and Applications to Gravitational Collapse,". PhD thesis, The Pennsylvania State University, 2009. Available online at [https://etda.libraries.psu.edu/catalog/10349.](https://etda.libraries.psu.edu/catalog/10349)
- [28] R. Gambini and J. Pullin, "Loop quantization of the Schwarzschild black hole," Phys. Rev. Lett. 110 (2013) 211301, [arXiv:1302.5265](http://arxiv.org/abs/1302.5265).
- [29] R. Gambini, J. Olmedo, and J. Pullin, "Quantum black holes in Loop Quantum Gravity," Class. Quant. Grav. 31 (2014) 095009, [arXiv:1310.5996](http://arxiv.org/abs/1310.5996).
- [30] J. Ben Achour, S. Brahma, and A. Marciano, "Spherically symmetric sector of self dual Ashtekar gravity coupled to matter: Anomaly-free algebra of constraints with holonomy corrections," Phys. Rev. D96 (2017) 026002, [arXiv:1608.07314](http://arxiv.org/abs/1608.07314).
- <span id="page-7-9"></span>[31] M. Bojowald, S. Brahma, and D.-h. Yeom, "Effective line elements and black-hole models in canonical loop quantum gravity," Phys. Rev. D98 (2018) 046015, [arXiv:1803.01119](http://arxiv.org/abs/1803.01119).
- <span id="page-7-10"></span>[32] D.-W. Chiou, W.-T. Ni, and A. Tang, "Loop quantization of spherically symmetric midisuperspaces and loop quantum geometry of the maximally extended Schwarzschild spacetime," [arXiv:1212.1265](http://arxiv.org/abs/1212.1265).
- <span id="page-7-15"></span>[33] R. Gambini, J. Olmedo, and J. Pullin, "Spherically symmetric loop quantum gravity: analysis of improved dynamics," [arXiv:2006.01513](http://arxiv.org/abs/2006.01513).
- <span id="page-7-11"></span>[34] J. G. Kelly, R. Santacruz and E. Wilson-Ewing, "Effective loop quantum gravity framework for vacuum spherically symmetric space-times," [arXiv:2006.09302](http://arxiv.org/abs/2006.09302).
- <span id="page-7-13"></span>[35] R. Gambini, J. Pullin, and S. Rastgoo, "Quantum scalar field in quantum gravity: The vacuum in the spherically symmetric case," Class. Quant. Grav. 26 (2009) 215011, [arXiv:0906.1774](http://arxiv.org/abs/0906.1774).
- [36] R. Gambini, E. M. Capurro, and J. Pullin, "Quantum spacetime of a charged black hole," Phys. Rev. D91 (2015) 084006, [arXiv:1412.6055](http://arxiv.org/abs/1412.6055).
- [37] M. Bojowald, S. Brahma, and J. D. Reyes, "Covariance in models of loop quantum gravity: Spherical symmetry," Phys. Rev. D92 (2015) 045043,

- [arXiv:1507.00329](http://arxiv.org/abs/1507.00329).
- <span id="page-8-0"></span>[38] M. Campiglia, R. Gambini, J. Olmedo, and J. Pullin, "Quantum self-gravitating collapsing matter in a quantum geometry," Class. Quant. Grav. 33 (2016) 18LT01, [arXiv:1601.05688](http://arxiv.org/abs/1601.05688).
- [39] V. Husain and O. Winkler, "Quantum Hamiltonian for gravitational collapse," Phys. Rev. D 73 (2006) 124007, [arXiv:gr-qc/0601082](http://arxiv.org/abs/gr-qc/0601082).
- [40] V. Husain, "Critical behaviour in quantum gravitational collapse," Adv. Sci. Lett. 2 (2009) 214, [arXiv:0808.0949](http://arxiv.org/abs/0808.0949).
- [41] S. Hossenfelder, L. Modesto, and I. Premont-Schwarz, "A Model for non-singular black hole collapse and evaporation," Phys. Rev. D81 (2010) 044036, [arXiv:0912.1823](http://arxiv.org/abs/0912.1823).
- <span id="page-8-1"></span>[42] F. Benitez, R. Gambini, L. Lehner, S. Liebling, and J. Pullin, "Critical collapse of a scalar field in semiclassical loop quantum gravity," Phys. Rev. Lett. 124 (2020) 071301, [arXiv:2002.04044](http://arxiv.org/abs/2002.04044).
- <span id="page-8-2"></span>[43] A. Ashtekar, V. Taveras, and M. Varadarajan, "Information is Not Lost in the Evaporation of 2-dimensional Black Holes," Phys. Rev. Lett. 100 (2008) 211302, [arXiv:0801.1811](http://arxiv.org/abs/0801.1811).
- [44] A. Ashtekar, F. Pretorius, and F. M. Ramazanoglu, "Evaporation of 2-Dimensional Black Holes," Phys. Rev. D 83 (2011) 044040, [arXiv:1012.0077](http://arxiv.org/abs/1012.0077).
- [45] Y. Tavakoli, J. Marto, and A. Dapor, "Semiclassical dynamics of horizons in spherically symmetric collapse," Int. J. Mod. Phys. D 23 (2014) 1450061, [arXiv:1303.6157](http://arxiv.org/abs/1303.6157).
- <span id="page-8-21"></span>[46] C. Bambi, D. Malafarina and L. Modesto, "Non-singular quantum-inspired gravitational collapse," Phys. Rev. D 88 (2013), 044009, [arXiv:1305.4790](http://arxiv.org/abs/1305.4790).
- <span id="page-8-22"></span>[47] Y. Liu, D. Malafarina, L. Modesto and C. Bambi, "Singularity avoidance in quantum-inspired inhomogeneous dust collapse," Phys. Rev. D 90 (2014) 044040, [arXiv:1405.7249](http://arxiv.org/abs/1405.7249).
- <span id="page-8-19"></span>[48] M. Christodoulou, C. Rovelli, S. Speziale, and I. Vilensky, "Planck star tunneling time: An astrophysically relevant observable from background-free quantum gravity," Phys. Rev. D 94 (2016) 084035, [arXiv:1605.05268](http://arxiv.org/abs/1605.05268).
- <span id="page-8-25"></span>[49] M. Christodoulou and F. D'Ambrosio, "Characteristic Time Scales for the Geometry Transition of a Black Hole to a White Hole from Spinfoams," [arXiv:1801.03027](http://arxiv.org/abs/1801.03027).
- <span id="page-8-15"></span>[50] J. Ben Achour, S. Brahma, S. Mukohyama, and J.-P. Uzan, "Consistent black-to-white hole bounces from matter collapse," [arXiv:2004.12977](http://arxiv.org/abs/2004.12977).
- <span id="page-8-3"></span>[51] E. Bianchi, M. Christodoulou, F. D'Ambrosio, H. Haggard, C. Rovelli, "White Holes as Remnants: A Surprising Scenario for the End of a Black Hole," Class. Quant. Grav. 35 (2018) 225003, [arXiv:1802.04264](http://arxiv.org/abs/1802.04264).
- <span id="page-8-4"></span>[52] V. Husain and O. Winkler, "Quantum resolution of black hole singularities," Class. Quant. Grav. 22 (2005) L127–L134, [arXiv:gr-qc/0410125](http://arxiv.org/abs/gr-qc/0410125).
- [53] J. Ziprick and G. Kunstatter, "Dynamical Singularity Resolution in Spherically Symmetric Black Hole Formation," Phys. Rev. D 80 (2009) 024032, [arXiv:0902.3224](http://arxiv.org/abs/0902.3224).
- [54] M. Bojowald, J. D. Reyes, and R. Tibrewala, "Non-marginal LTB-like models with inverse triad corrections from loop quantum gravity," Phys. Rev. D 80 (2009) 084002, [arXiv:0906.4767](http://arxiv.org/abs/0906.4767).

- [55] A. Kreienbuehl, V. Husain, and S. S. Seahra, "Modified general relativity as a model for quantum gravitational collapse," Class. Quant. Grav. 29 (2012) 095008, [arXiv:1011.2381](http://arxiv.org/abs/1011.2381).
- <span id="page-8-5"></span>[56] M. Bojowald, G. M. Paily, J. D. Reyes, and R. Tibrewala, "Black-hole horizons in modified space-time structures arising from canonical quantum gravity," Class. Quant. Grav. 28 (2011) 185006, [arXiv:1105.1340](http://arxiv.org/abs/1105.1340).
- <span id="page-8-6"></span>[57] V. Husain and T. Pawlowski, "Time and a physical Hamiltonian for quantum gravity," Phys. Rev. Lett. 108 (2012) 141301, [arXiv:1108.1145](http://arxiv.org/abs/1108.1145).
- <span id="page-8-7"></span>[58] D. Arruga, J. Ben Achour and K. Noui, "Deformed General Relativity and Quantum Black Holes Interior," Universe 6 (2020) 39, [arXiv:1912.02459](http://arxiv.org/abs/1912.02459).
- <span id="page-8-8"></span>[59] P. D. Lasky, A. W. Lun, and R. B. Burston, "Initial value formalism for dust collapse," ANZIAM Journal 49 (2007) 205, [arXiv:gr-qc/0606003](http://arxiv.org/abs/gr-qc/0606003).
- <span id="page-8-9"></span>[60] K. Giesel, J. Tambornino, and T. Thiemann, "LTB spacetimes in terms of Dirac observables," Class. Quant. Grav. 27 (2010) 105013, [arXiv:0906.0569](http://arxiv.org/abs/0906.0569).
- <span id="page-8-10"></span>[61] V. Taveras, "Corrections to the Friedmann Equations from LQG for a Universe with a Free Scalar Field," Phys. Rev. D 78 (2008) 064072, [arXiv:0807.3325](http://arxiv.org/abs/0807.3325).
- <span id="page-8-11"></span>[62] C. Rovelli and E. Wilson-Ewing, "Why are the effective equations of loop quantum cosmology so accurate?," Phys. Rev. D 90 (2014) 023538, [arXiv:1310.8654](http://arxiv.org/abs/1310.8654).
- <span id="page-8-12"></span>[63] K. Vandersloot, "Loop quantum cosmology and the k = - 1 RW model," Phys. Rev. D 75 (2007) 023523, [arXiv:gr-qc/0612070](http://arxiv.org/abs/gr-qc/0612070).
- <span id="page-8-13"></span>[64] P. Singh and E. Wilson-Ewing, "Quantization ambiguities and bounds on geometric scalars in anisotropic loop quantum cosmology," Class. Quant. Grav. 31 (2014) 035010, [arXiv:1310.6728](http://arxiv.org/abs/1310.6728).
- <span id="page-8-14"></span>[65] A. Ashtekar and E. Wilson-Ewing, "Loop quantum cosmology of Bianchi type II models," Phys. Rev. D 80 (2009) 123532, [arXiv:0910.1278](http://arxiv.org/abs/0910.1278).
- <span id="page-8-16"></span>[66] J. R. Oppenheimer and H. Snyder, "On Continued gravitational contraction," Phys. Rev. 56 (1939) 455–459.
- <span id="page-8-17"></span>[67] C. Rovelli and F. Vidotto, "Planck stars," Int. J. Mod. Phys. D23 (2014) 1442026, [arXiv:1401.6562](http://arxiv.org/abs/1401.6562).
- [68] H. M. Haggard and C. Rovelli, "Quantum-gravity effects outside the horizon spark black to white hole tunneling," Phys. Rev. D92 (2015) 104020, [arXiv:1407.0989](http://arxiv.org/abs/1407.0989).
- <span id="page-8-18"></span>[69] C. Barcelo, R. Carballo-Rubio, L. J. Garay and G. Jannes, "The lifetime problem of evaporating black holes: mutiny or resignation," Class. Quant. Grav. 32 (2015) 035012, [arXiv:1409.1501](http://arxiv.org/abs/1409.1501).
- <span id="page-8-20"></span>[70] D. N. Page, "Average entropy of a subsystem," Phys. Rev. Lett. 71 (1993) 1291–1294, [arXiv:gr-qc/9305007](http://arxiv.org/abs/gr-qc/9305007).
- <span id="page-8-23"></span>[71] T. Schmitz, "Towards a quantum Oppenheimer-Snyder model," Phys. Rev. D 101 (2020) 026016, [arXiv:1912.08175](http://arxiv.org/abs/1912.08175).
- <span id="page-8-24"></span>[72] W. Piechocki and T. Schmitz, "Quantum Oppenheimer-Snyder model," [arXiv:2004.02939](http://arxiv.org/abs/2004.02939).
- <span id="page-8-26"></span>[73] D. M. Eardley, "Death of White Holes in the Early Universe," Phys. Rev. Lett. 33 (1974) 442–444.
- <span id="page-8-27"></span>[74] C. Barcel´o, R. Carballo-Rubio, and L. J. Garay, "Black holes turn white fast, otherwise stay black: no half measures," JHEP 01 (2016) 157, [arXiv:1511.00633](http://arxiv.org/abs/1511.00633).
- <span id="page-8-28"></span>[75] A. Barrau, B. Bolliet, F. Vidotto and C. Weimer, "Phenomenology of bouncing black holes in quantum

- gravity: a closer look," JCAP 02 (2016) 022, [arXiv:1507.05424](http://arxiv.org/abs/1507.05424).
- [76] F. Vidotto, "Measuring the last burst of non-singular black holes," Found. Phys. 48 (2018) 1380,
- [arXiv:1803.02755](http://arxiv.org/abs/1803.02755).
- <span id="page-9-0"></span>[77] R. Carballo-Rubio, F. Di Filippo, S. Liberati and M. Visser, "Phenomenological aspects of black holes beyond general relativity," Phys. Rev. D 98 (2018) 124009, [arXiv:1809.08238](http://arxiv.org/abs/1809.08238).