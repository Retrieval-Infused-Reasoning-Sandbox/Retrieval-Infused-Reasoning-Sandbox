# Properties of a recent quantum extension of the Kruskal geometry

Abhay Ashtekar<sup>1</sup> , Javier Olmedo<sup>2</sup>,<sup>3</sup> ,

- *1. Institute for Gravitation and the Cosmos, Penn State University, University Park, PA 16801*
- *2. Department of Physics and Astronomy, Louisiana State University, Baton Rouge, LA 70803 3. Departamento de F´ısica Te´orica y del Cosmos, Universidad de Granada, Granada-18071, Spain*

Recently it was shown that, in an effective description motivated by loop quantum gravity, singularities of the Kruskal space-time are naturally resolved [1, 2]. In this note we explore a few properties of this quantum corrected effective metric. In particular, we (i) calculate the Hawking temperature associated with the horizon of the effective geometry and show that the quantum correction to the temperature is completely negligible for macroscopic black holes, just as one would hope; (ii) discuss the subtleties associated with the asymptotic properties of the space-time metric, and show that the metric is asymptotically flat in a precise sense; (iii) analyze the asymptotic fall-off of curvature; and, (iv) show that the ADM energy is well-defined (and agrees with that determined by the horizon area), even though the curvature falls off less rapidly than in the standard asymptotically flat context.

# I. INTRODUCTION

It has long been suggested, especially by John Wheeler, that the reason why singularities can result from dynamics of general relativity is simply that the theory ignores quantum effects. However, in recent years, there has been some debate as to whether inclusion of quantum gravity effects by itself would be sufficient. For example, motivated by the AdS/CFT correspondence, it has been argued that quantum gravity will/should not resolve certain (bulk) singularities, including those of the classical Schwarzschild-Anti-de Sitter space-times [3]. More recently, it was found that plausible counter examples to cosmic censorship [4, 5] would be removed if the weak gravity conjecture (WGC) holds. These results are then sometimes interpreted as implying that a quantum gravity theory that does not include some version of the WGC would not be physically viable. Wheeler's argument, on the other hand, suggests otherwise: violation of cosmic censorship in classical general relativity may simply be an artifact of ignoring the quantum nature of geometry. In this view, the focus shifts away from possible constraints on matter to make the classical theory satisfactory, to whether the quantum theory is singularity-free and predictive.

Loop quantum gravity (LQG) provides a concrete illustration of how the quantum nature of geometry could play the crucial role. The theory has a fundamental discreteness, encapsulated in an area gap ∆ –the lowest non-zero eigenvalue of the area operator– that dictates the quantum corrections to Einstein's equations. These modifications have been worked out in great detail in loop quantum cosmology (LQC) (see, e.g., [6–8]). In this context, Einstein's equations provide an excellent approximation to LQC away from the Planck regime but then the LQC corrections dominate once curvature approaches the Planck scale, resolving the singularity. In particular, these modifications naturally provide upper bounds to curvature scalars that go as inverse powers of ∆. Therefore, while all physical quantities are bounded in the quantum theory, since ∆ → 0 in the classical limit, the upper bounds go to infinity and we are back to classical singularities. In all cases studied in detail so far, it is the quantum nature of geometry that plays the decisive role in making the quantum theory singularity-free, without any additional constraints on matter fields.

It is natural to ask whether the black hole singularities are also naturally resolved by the same quantum gravity effects. The simplest context is provided by the Schwarzschild-Kruskal space-time. To analyze whether this singularity is resolved, it suffices to restrict oneself to the black hole region that is bounded by the singularity in the future and event horizons in the past, often referred to as the Schwarzschild interior. Now, since this interior is isometric to the (vacuum) Kantowski-Sachs cosmological model, one can adopt procedures that have been used to analyze homogeneous but anisotropic cosmologies in LQC. Therefore, there has been considerable work on the Schwarzschild interior over the last 15 years or so (see, e.g. [9–20] for investigations relevant for this note). In all these treatments, the space-like singularity was resolved but detailed examination showed that the resulting quantum extension of the classical Schwarzschild interior had some undesirable or puzzling features. For example, one generally begins by introducing certain fiducial structures in the construction of the classical phase space for mathematical convenience, with the expectation that the final physical results would be independent of the specific choices made. This was not always the case (see, e.g., [9, 10, 14]). While the final results in [11, 12, 17, 18] are free of this drawback, one finds that there are large quantum gravity effects in low curvature regions. For example, for large black holes, the quintessentially quantum transition from a trapped to an anti-trapped region can occur in regions with arbitrarily small curvature in [17], while quantum dynamics drives the effective trajectories to regions of phase space where the basic underlying assumptions are violated in [11, 12, 19]. (A succinct discussion of all these limitations can be found in Section IV.D of [2].) This situation was analyzed in some detail more recently and it was shown that all known limitations of the LQG description of Schwarzschild interior can be overcome by suitably modifying a key step in the quantization procedure [1, 2].

This recent analysis also extended the previous work in two directions. First, the emphasis in the previous works was generally on issues rooted in anisotropic cosmologies, suggested by the Kantowski-Sachs space-time –such as bounces of various scale factors [11, 15–17, 19, 21], behavior of the energy density, expansion scalar, shear potentials of the Weyl curvature [22], and, geodesic completeness and generic resolution of strong singularities [23]. By contrast, the analysis in [1, 2] focused on issues that are central to black holes, such as trapped and anti-trapped regions, black hole type and white hole type horizons, and the behavior of the static Killing field as one passes from the original Kruskal space-time to its quantum extension. Second, while the previous analysis was confined to the Schwarzschild interior, Refs [1, 2] also contained a specific proposal to extend the quantum corrected, effective description to the asymptotic regions (see also [24]).

The purpose of this note is to discuss a few properties of the effective space-time constructed in [2] that shed further light on its viability. In broad terms, there are three aspects of the effective geometry of interest: (i) singularity resolution; (ii) near horizon geometry; and (iii) asymptotic behavior. While all three aspects were discussed in Refs [1, 2], the focus was on the possibility of overcoming limitations of previous investigations which were confined to the Schwarzschild interior. Therefore, issues related to the singularity resolution were analyzed in detail. In particular, it was shown that not only do curvature invariants remain bounded in the quantum corrected effective space-time, but the bounds are universal. More precisely, to the leading order, upper bounds on the curvature scalars  $R^2$ ,  $R_{ab}R^{ab}$ ,  $R_{abcd}R^{abcd}$  are numerical multiples of  $1/\Delta^2$ , where  $\Delta$  is the area gap, showing that the origin of the singularity resolution lies firmly in the quantum nature of geometry. The bounds are universal in the sense that they are insensitive to the mass of the macroscopic black holes considered. This upper bound is reached on the transition surface  $\mathcal{T}$  which separates the trapped (i.e., black hole type) region, which the effective metric shares with the classical metric, and the untrapped (i.e. white hole type) region that represents the quantum extension. This surface  $\mathcal{T}$  replaces the classical singularity. In the classical limit, we have  $\Delta \to 0$  whence the upper bound diverges, and we have a singularity in place of the transition surface. These general features are the same as in the resolution of the big-bang singularity in LQC, where the bounce-surface replaces  $\mathcal{T}$ , and the upper bound on curvature is again governed only by the area gap, being insensitive to the specific matter content of the universe. Thus, there is a certain underlying unity in the manner in which space-like singularities are resolved due to quantum geometry effects.

In this note we further investigate aspects (ii) and (iii). Specifically, although the analytical form of the effective metric is quite complicated, one can still calculate the temperature associated with the black hole using Euclidean methods (see, e.g. [25]). Thus, one exploits the fact that the temperature associated with a thermal state of a (test) quantum field is succinctly captured by the periodicity in imaginary time of the Green's function of that field [26]. We will find that the quantum correction to the Hawking temperature is minute for macroscopic black holes; it is  $\mathcal{O}(10^{-106})$  for a solar mass black hole! In [2] it was found that the quantum modification of the near horizon curvature is extremely small for macroscopic black holes. The result on the Hawking temperature translates those considerations to more direct physical terms.

Aspect (iii) –the asymptotic behavior of the effective geometry— was not analyzed in as much detail as the first two aspects. This was largely because –as discussed in sections III and IV- the effective metric is in excellent agreement with the classical theory near horizons, and calculations reported in [2] showed that the agreement improves as one moves away from the horizons in the outward direction. Therefore, it was assumed that the agreement with the Schwarzschild geometry would continue to get better as one recedes even further. However, soon afterwards it was realized that the issue of comparison requires greater care. The effective metric  $g_{ab}$  does approach a flat metric ("as 1/r") –the precise sense is spelled out in Section IV- but the curvature invariants do not fall-off as fast as they do in standard treatments of asymptotics (e.g., [27–30]). However, it is well-known that the ADM energy can remain well-defined even if the asymptotic fall-off is much slower than what is generally assumed (see, e.g., [31]). We will show that the same is true for the weaker asymptotic fall-off of the effective metric. More precisely, the situation is as follows. With the standard fall-off, various expressions of the ADM energy –those involving just the spatial metric, those involving the Ricci curvature of this metric, the one in terms of the electric part of the Weyl curvature, the one involving asymptotic time-translational Killing field, etc – all agree [32, 33]. This is no longer true if we have a weaker fall-off and the ADM energy has to be defined with greater care. When this is done using the effective metric, the ADM energy is well-defined and its value is the expected one. Therefore, although the asymptotic curvature of the effective metric falls-off more slowly than that of the Schwarzschild metric of classical general relativity, the main conclusions of [1, 2] still hold. Furthermore, as we show, to find a discernible deviation from the Schwarzschild metric for macroscopic black holes (for which the effective theory was developed) one would have to move away from the black hole a distance that is orders of magnitude greater than the radius of the observable universe.

The paper is organized as follows. In Section II, we recall the effective metric and discuss some of its properties. In Section III, we discuss the Hawking temperature and in Section IV, asymptotic properties of the quantum corrected effective metric. In Section V we summarize the main results as well as work by others that extends the findings of [1, 2], and point out limitations of this effective description which in turn suggest directions in which it can be improved. We also have taken this opportunity to address two comments [34, 35] on the results of [2]. Specifically, in Sections IV B and V we explain why the concerns expressed there are misplaced.

# II. EFFECTIVE EQUATIONS AND THE NEAR HORIZON GEOMETRY

For convenience of the reader, we will begin by recalling the effective metric obtained in [1, 2], first in the interior region bounded by the trapping (i.e. black hole type) and anti-trapping (i.e. white hole type) horizons, and then in the exterior region. We then introduce Eddington-Finkelstein coordinates in neighborhoods of these horizons to make it explicit that the interior metric is smoothly related to the exterior.

#### A. Effective metric

As is common in LQC, the effective solution was first obtained in a symmetry reduced phase space framework and then expressed as a quantum corrected space-time metric. The interior region is foliated by a family of space-like homogeneous 3-surfaces and the exterior region, by a family of homogeneous time-like surfaces (in both cases the metric on the 3-surfaces is anisotropic). Because of homogeneity, the phase space  $\Gamma$  is only 4 dimensional, coordinatized by b, c;  $p_b, p_c$  in the interior region and their tilde version in the exterior. Quantum corrections are encapsulated in two 'quantum parameters'  $\delta_b, \delta_c$  (that are the same in both regions, but the subscripts carry a tilde in the exterior region just for notational consistency). Their specific form is motivated by the fact that in LQG the curvature operator is constructed by dividing the holonomy around suitable closed plaquettes by the area enclosed by those plaquettes, and then shrinking the loop till it attains the minimum non-zero eigenvalue of the area operator,  $\Delta \approx 5.17 \ell_{\rm Pl}^2$ , in LQG. In the present approach [1, 2], the plaquettes are chosen to lie on the transition surface  $\mathcal{T}$  that replaces the classical singularity, and separates the trapped region from the anti-trapped region in the quantum extension of the Schwarzschild interior. The quantum parameters are then given by:

$$\delta_b = \left(\frac{\sqrt{\Delta}}{\sqrt{2\pi}\gamma^2 m}\right)^{1/3} \quad \text{and} \quad L_o \delta_c = \frac{1}{2} \left(\frac{\gamma \Delta^2}{4\pi^2 m}\right)^{1/3}, \tag{2.1}$$

where  $\gamma \approx 0.2375$  is the Barbero-Immirzi parameter of LQG and  $L_o$  is an infrared regulator introduced to make the phase space description well-defined.<sup>1</sup> In the classical limit both

<sup>&</sup>lt;sup>1</sup> None of the final physical results depend on  $L_o$ . They depend only on combinations of b,  $L_o^{-1}c$ ,  $L_o^{-1}p_b$ ,  $p_c$ , which are all independent of the choice of  $L_o$ .

quantum parameters go to zero and one recovers the standard Schwarzschild geometry; it is the quantum geometry induced corrections involving  $\delta_b$ ,  $\delta_c$  that resolve the singularities of the Kruskal space-time. Finally, the parameter m that characterizes the solution is a constant of motion, i.e., a Dirac observable, of the effective solution. In the interior region, the effective metric is given by:

$$g_{ab} dx^a dx^b \equiv ds^2 = -\frac{\gamma^2 p_c \delta_b^2}{\sin^2(\delta_b b)} dT^2 + \frac{p_b^2}{p_c L_o^2} dx^2 + p_c d\omega^2,$$
 (2.2)

where  $d\omega^2$  is the metric on a unit 2-sphere. T plays the role of time, and the translational Killing vector is  $\partial/\partial x$ ; thus the phase space variables depend only on T. One can think of x as the standard Schwarzschild coordinate t which is space-like in the interior region, and  $(2m) e^T$  as the Schwarzschild coordinate r.

Solutions of the effective equations are given by:

$$\tan\left(\frac{\delta_{c}c\left(T\right)}{2}\right) = \frac{\gamma L_{0}\delta_{c}}{8m}e^{-2T}, \qquad p_{c}\left(T\right) = 4m^{2}\left(e^{2T} + \frac{\gamma^{2}L_{0}^{2}\delta_{c}^{2}}{64m^{2}}e^{-2T}\right), \tag{2.3}$$

$$\cos(\delta_b b(T)) = b_0 \tanh\left(\frac{1}{2} \left(b_0 T + 2 \tanh^{-1}(b_0^{-1})\right)\right), \tag{2.4}$$

$$p_b(T) = -2m\gamma L_0 \frac{\sin(\delta_b b(T))}{\delta_b} \frac{1}{\gamma^2 + \frac{\sin^2(\delta_b b(T))}{\delta_b^2}},$$
(2.5)

where  $b_o^2 = 1 + \gamma^2 \delta_b^2$ . The black hole horizon lies at T = 0 where b and  $p_b$  vanish. T decreases as we move to the future from the horizon towards the transition surface  $\mathcal{T}$ . The area  $4\pi p_c$  of the horizon in the effective theory is slightly larger than the classical value  $4\pi(2m)^2$ , but the increase is completely negligible for a macroscopic black hole –the fractional change is  $\sim 10^{-21}$  for a black hole of a million Planck masses and  $\sim 10^{-106}$  for a solar mass black hole.

Next, let us consider the exterior region. Now the Killing vector  $\partial/\partial x$  is time-like and the metric is given by

$$\tilde{g}_{ab} dx^a dx^b = -\frac{\tilde{p}_b^2}{\tilde{p}_c L_o^2} dx^2 + \frac{\gamma^2 \, \tilde{p}_c \, \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}}\tilde{b})} dT^2 + \tilde{p}_c \, d\omega^2.$$
(2.6)

The explicit solutions for  $c, p_c$  have the same form as (2.3), with  $c, p_c$  replaced by  $\tilde{c}, \tilde{p}_c$ . In solutions for  $\tilde{b}$  and  $\tilde{p}_b$ , on the other hand, the trigonometric functions of  $(b \delta_b)$  are replaced by their hyperbolic analogs:

$$\cosh\left(\delta_{\tilde{b}}\,\tilde{b}(T)\right) = \tilde{b}_o \tanh\left(\frac{1}{2}\left(\tilde{b}_o T + 2\tanh^{-1}\left(\frac{1}{\tilde{b}_o}\right)\right)\right),\tag{2.7}$$

$$\tilde{p}_b(T) = -2m\gamma L_0 \frac{\sinh(\delta_{\tilde{b}}\tilde{b}(T))}{\delta_{\tilde{b}}} \frac{1}{\gamma^2 - \frac{\sinh^2(\delta_{\tilde{b}}\tilde{b}(T))}{\delta_{\tilde{b}}^2}},$$
(2.8)

where  $\tilde{b}_o^2 = 1 + \gamma^2 \delta_{\tilde{b}}^2$ . The horizon lies at T = 0 where  $\tilde{b}$  and  $\tilde{p}_b$  vanish, and T increases as we go outward to spatial infinity. Note that the equation of motion (2.7) implies that  $\gamma^2 - \frac{\sinh^2(\delta_{\tilde{b}}\,\tilde{b}(T))}{\delta_{\tilde{b}}^2}$  never vanishes in the exterior region where  $T \in (0, \infty)$ .

# B. The near-horizon geometry

In this sub-section, we will discuss the issue of matching the interior metric with the exterior one. Now, as we approach the horizon (i.e., T=0) either from the interior region or the exterior, the metric component  $g_{xx}$  associated with the Killing vector vanishes and  $g_{TT}$  diverges (just as  $g_{tt}$  vanishes and  $g_{rr}$  diverges at the horizon of the Schwarzschild solution). The coordinate T is well-defined; T=0 at the horizon, monotonically decreases in the interior and monotonically increases in the exterior. The problem is that the coordinate x, the affine parameter of the Killing field, becomes ill-defined (just as in the Schwarzschild case). The question then is if one can introduce Eddington-Finkelstein-type coordinates—bridging the interior and the exterior regions—in which the metric is well-defined across the horizon. This is indeed possible and we will now spell out the procedure. As in the Schwarzschild case, it suffices to focus on the (x, T) plane. We can write the exterior and interior metrics, respectively, as

$$d\tilde{S}_{2}^{2} = -\tilde{f}_{1}(T)dx^{2} + \tilde{f}_{2}(T)dT^{2}, \text{ and } dS_{2}^{2} = f_{1}(T)dx^{2} - f_{2}(T)dT^{2};$$
 (2.9)

where

$$\tilde{f}_1(T) = \frac{\tilde{p}_b^2}{\tilde{p}_c L_o^2}, \quad \tilde{f}_2(T) = \frac{\gamma^2 \tilde{p}_c \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}}\tilde{b})} \quad \text{and} \quad f_1(T) = \frac{p_b^2}{p_c L_o^2}, \quad f_2(T) = \frac{\gamma^2 p_c \delta_b^2}{\sin^2(\delta_b b)}.$$
 (2.10)

Then, following Eddington and Finkelstein, we are led to define  $\tilde{T}_{\star}$  such that

$$d\tilde{T}_{\star} = \left(\tilde{f}_2/\tilde{f}_1\right)^{\frac{1}{2}} dT \quad \text{and set} \quad v = x + \tilde{T}_{\star}. \tag{2.11}$$

Then, the metric in the exterior region becomes

$$d\tilde{S}_{2}^{2} = \tilde{f}_{1} dv^{2} - 2 (\tilde{f}_{1} \,\tilde{f}_{2})^{\frac{1}{2}} dv dT.$$
 (2.12)

Now,  $\hat{f}_1$  vanishes at T=0. Therefore, for the metric to be well-defined at the horizon, we need  $\tilde{f}_1\tilde{f}_2$  be smooth and positive in a neighborhood of the horizon. As shown below in Section III, this is indeed the case. In particular,  $\lim_{T\to 0} \tilde{f}_1\tilde{f}_2 = 4m^2$  exactly as in the classical theory; quantum corrections to  $\tilde{f}_1\tilde{f}_2$  vanish at the horizon. Limits of first two derivatives of  $\tilde{f}_1$  and  $(\tilde{f}_1\tilde{f}_2)^{\frac{1}{2}}$  are also well-defined. For the metric coefficient  $\tilde{f}_1$ , they are given by

$$\frac{1}{1+\epsilon_m}$$
, and,  $\frac{\frac{1}{2}\gamma^2\delta_{\tilde{b}}^2 + 3 - 4\frac{1-\epsilon_m}{1+\epsilon_m}}{1+\epsilon_m}$ , (2.13)

respectively, where

$$\epsilon_m = \frac{\gamma^2 L_0^2 \delta_c^2}{64m^2} = \frac{1}{256} \left( \frac{\gamma \Delta^{\frac{1}{2}}}{\sqrt{2\pi}m} \right)^{8/3} , \qquad (2.14)$$

where  $\Delta$  is again the LQG area gap. For the metric coefficient  $(\tilde{f}_1 \, \tilde{f}_2)^{\frac{1}{2}}$ , they are given by

$$2m$$
 and  $m\left(2+\gamma^2\delta_{\tilde{b}}^2\right)$ , (2.15)

respectively. We can repeat the procedure starting from the interior. Again, the limits exist and values of metric coefficients and their first two derivatives match with those coming from the exterior. Thus, the effective metric is (at least)  $C^2$  across the horizon T = 0.

To summarize, although the effective metric was constructed separately in the interior region (using homogeneity of a space-like foliation) and exterior region (using homogeneity of a time-like foliation), it is in fact well defined across the horizon as in the classical case.

### III. THE HAWKING TEMPERATURE

Let us begin by recalling how Euclidean methods are used to calculate the temperature associated with a Killing horizon (see, e.g., [25]). The premise of this calculation is that we have a test quantum field propagating on a given static space-time. Thus, field equations satisfied by the metric do not play any role, nor do considerations of quantum gravity proper.

Let us first consider a general spherically symmetric, static Lorentzian space-time  $(M, \tilde{g}_{ab})$  with a smooth metric

$$\tilde{g}_{ab} dx^a dx^b = -\tilde{f}_1(r) dt^2 + \tilde{f}_2(r) dr^2 + r^2 d\omega^2,$$
(3.1)

where  $d\omega^2$  again denotes the line element on a unit 2-sphere, and  $r \in (r_o, \infty)$  is the area radius. Suppose the static Killing field  $t^a$  (with  $t^a\partial_a = \partial/\partial_t$ ) becomes null at  $r = r_o$  and is time-like for  $r > r_o$ . Then  $\tilde{f}_1(r) \ge 0$  and vanishes only at  $r = r_o$ , which is a Killing horizon. Let us now carry out a Wick rotation. Setting  $t_E = -it$ , we obtain a Riemannian metric  $\tilde{\mathfrak{g}}_{ab}$ :

$$\tilde{\mathfrak{g}}_{ab} dx^a dx^b = \tilde{f}_1(r) dt_E^2 + \tilde{f}_2(r) dr^2 + r^2 d\omega^2.$$
(3.2)

Since  $\tilde{\mathfrak{g}}_{ab}$  is Riemannian and  $\tilde{f}_1(r_\circ) = 0$ , it follows that the Killing field  $t_{\rm E}^a$  itself vanishes at  $r = r_o$ . Since a Killing field  $t_{\rm E}^a$  and its derivative  $\nabla_a t_{\rm E}^b$  cannot both vanish simultaneously at any point in space-time [36], it follows that  $\tilde{f}'_1(r_\circ) \neq 0$ , where the 'prime' denotes derivative with respect to r. Furthermore, vanishing of  $t_{\rm E}^a$  at  $r = r_\circ$  implies that, under the isometry generated by  $t_{\rm E}^a$ , each point on the 2-sphere  $r = r_\circ$  is left invariant and the tangent space at that point is rotated in the  $r - t_{\rm E}$  plane. Thus in a neighborhood of  $r = r_o$ , the Killing field  $t_{\rm E}^a$  resembles a rotation.

From now on, it will suffice to focus just on the manifold of orbits of the rotational Killing fields, i.e., the  $r-t_{\rm E}$  plane. The 'rotational' character of  $t_{\rm E}^a$  becomes manifest if we set  $R=(\tilde{f}_1(r))^{\frac{1}{2}}$  so that the metric on the  $r-t_{\rm E}$  plane becomes

The (r, t) chart breaks down at  $r = r_o$ . However, as we saw in Section IIB, conditions that limits of  $f'_1$  and  $f_1f_2$  do not vanish as  $r \to r_o$  ensure that one can pass to a new chart in which the metric is regular at  $r = r_o$ . In the Euclidean sector discussed below, the period of the affine parameter t of  $t^a$  has also to be chosen appropriately. Under these conditions, the breakdown of coordinates (r, t) is similar to that of the  $(r, \theta)$  chart at the origin in flat space. For our purposes, it will suffice to use the  $r > r_o$  part of the manifold and then take the limit as  $r \to r_o$ , making sure that the fields in question are such that limits are well-defined.

$$\tilde{\mathfrak{g}}_{ab} dx^a dx^b = R^2 dt_E^2 + 4 \frac{\tilde{f}_1 \tilde{f}_2}{(\tilde{f}'_1)^2} dR^2.$$
 (3.3)

We want to ensure that the metric does not have a conical singularity at R=0, i.e,  $r=r_o$ . Consider then a small circle with radius  $\delta R$  and ask that the ratio of its circumference to radius is  $2\pi$  in the limit  $r \to r_o$ . Assuming that  $t_E$  is periodic with period  $\mathcal{P}$  we obtain

$$2\pi = \lim_{R \to 0} \frac{\text{Circumference}}{\text{radius}} = \frac{P \tilde{f}'_1}{2(\tilde{f}_2 \tilde{f}_1)^{\frac{1}{2}}}.$$
 (3.4)

Note that for the limit of the ratio to exist, the metric has to satisfy the condition  $\lim_{r\to r_o} \tilde{f}_1 \tilde{f}_2 > 0$ , which —unlike the property  $\tilde{f}'|_{r_o} \neq 0$ — is not guaranteed by symmetry conditions. When this condition is satisfied, our requirement that the metric be regular—i.e. have no conical singularity at  $r = r_o$ — determines the period  $\mathcal{P}$ . One can also express it invariantly using the norm  $\tilde{\mathfrak{g}}_{ab} t_{\rm E}^a t_{\rm E}^b = \tilde{f}_1$  of the Killing field:

$$\mathcal{P} = \lim_{R \to 0} \frac{4\pi (\tilde{f}_1 \tilde{f}_2)^{\frac{1}{2}}}{\tilde{f}'_1} = \lim_{R \to 0} \frac{4\pi (\tilde{f}_1)^{\frac{1}{2}}}{||D\tilde{f}_1||}.$$
 (3.5)

Thus, the metric  $\tilde{\mathfrak{g}}_{ab}$  is well-defined at R=0, only if the coordinate  $t_{\rm E}$  is periodic with period  $\mathcal{P}$ . (If  $\tilde{g}_{ab}$  is the Schwarzschild metric, then one recovers the well-known result  $\mathcal{P}=8\pi GM$ , where M is the Schwarzschild mass.) Let us consider quantum fields propagating on the Lorentzian space-time given by the metric (3.1). Periodicity in the Euclidean time naturally leads to a thermal state of this field at temperature  $T_{\rm H}=\frac{\hbar}{K\mathcal{P}}$ , associated with the horizon [26]. (Here K is the Boltzmann constant.)

We can now use this method to calculate the Hawking temperature of the quantum corrected black hole described by the effective metric. The first step is to carry out the Wick rotation of the effective metric in the exterior region. The effective metric (2.6) has the form:

$$\tilde{g}_{ab} dx^a dx^b = -\frac{\tilde{p}_b^2}{\tilde{p}_c L_o^2} dx^2 + \frac{\gamma^2 \tilde{p}_c \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}}\tilde{b})} dT^2 + \tilde{p}_c d\omega^2,$$
(3.6)

where the Killing field is  $\partial/\partial x$ . Thus, we have to make the following changes in the symbols used in the general discussion above:  $t \to x$  and  $r \to T$  and replace the coefficient  $r^2$  of  $d\omega^2$  by  $\tilde{p}_c$ . The Wick rotated, positive-definite metric in the (r, t) plane —i.e., now in the (T, x) plane—becomes:

$$\tilde{\mathfrak{g}}_{ab} \mathrm{d}x^a \mathrm{d}x^b = \tilde{f}_1(T) \mathrm{d}x^2 + \tilde{f}_2(T) \mathrm{d}T^2 \quad \text{with} \quad \tilde{f}_1 = \frac{\tilde{p}_b^2}{\tilde{p}_c L_o^2} \quad \text{and} \quad \tilde{f}_2 = \frac{\gamma^2 \tilde{p}_c \, \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}}\tilde{b})} \,. \tag{3.7}$$

The horizon is at T=0, where  $\tilde{p}_b$  and  $\tilde{b}$  vanish in the effective solution. To check if the 2-metric  $\tilde{\mathfrak{g}}_{ab}$  is regular there, we first need to verify that  $\tilde{f}_1 \tilde{f}_2 > 0$  in a neighborhood of the horizon. Eq. (3.7) immediately implies

$$\tilde{f}_1 \tilde{f}_2 = \frac{\tilde{p}_b^2 \, \gamma^2 \, \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}} \tilde{b}) \, L_o^2}.\tag{3.8}$$

Thus, we do have  $\tilde{f}_1 \tilde{f}_2 > 0$  away from the 'horizon' T = 0. But since  $\tilde{b}$  and  $\tilde{p}_b$  both vanish there, we need to evaluate the limit  $T \to 0$  to make sure that  $\tilde{f}_1 \tilde{f}_2$  does not vanish in the limit. It is straightforward to carry out this calculation using the explicit expressions of  $\tilde{p}_b$ ,  $\tilde{p}_c$  and  $\delta_{\tilde{c}}\tilde{c}$  in the exterior region given in Section II. One obtains:

$$\lim_{T \to 0} \tilde{f}_1(T)\tilde{f}_2(T) = 4m^2, \text{ exactly as in the classical theory.}$$
 (3.9)

(In the classical theory, the product is 1 in the (r, t) coordinates, and since T is related to the Schwarzschild coordinate r via  $e^T = r/2m$ , it is  $4m^2$  in the (T, x) coordinates.) Thus  $f_1f_2$  is manifestly positive also in the effective theory and we can use (3.5) to calculate the period  $\mathcal{P}$ . One obtains:

$$\mathcal{P} = 8\pi m (1 + \epsilon_m), \text{ where } \epsilon_m = \frac{1}{256} \left( \frac{\gamma \Delta^{\frac{1}{2}}}{\sqrt{2\pi}m} \right)^{8/3}, \text{ as in Eq. (2.14).}$$
 (3.10)

This expression is exact for the effective metric under consideration, whence the Hawking temperature of this quantum corrected black hole horizon is

$$T_{\rm H} = \frac{\hbar}{8\pi Km} \frac{1}{(1+\epsilon_m)},$$
 (3.11)

rather than  $\frac{\hbar}{8\pi Km}$ , the temperature associated with the horizon of the classical Schwarzschild black hole. The mass dependent term  $\epsilon_m$  gives the quantum correction to the Hawking temperature. It is very small for macroscopic black holes. For a solar mass black hole it is of the order of  $\sim 4 \times 10^{-106}$ . Indeed, even for a black hole of  $\sim 10^6 M_{\rm Pl}$ , the correction is of the order  $10^{-21}$ . (Because there are inherent approximations in arriving at the effective theory, further extrapolation to even smaller black holes would not be appropriate.)

Results in [2] showed that the quantum corrections to various curvature invariants are small near the horizon of macroscopic black holes. The correction  $\epsilon_m$  to the Hawking temperature provides another facet of that general phenomenon, but one that tests the near horizon properties of the metric itself. More importantly, nature of this correction brings out the viability of the effective description vis a vis a key quantum property of black holes.

Remark: There exists in the literature a discussion of the so-called 'dirty' spherical, static black holes [37]—'dirty' in the sense that they allow matter fields also outside the horizon. This analysis relates the horizon surface gravity with integrals involving components of the stress-energy tensor of the matter field from the horizon to infinity, and the radius and the energy density at the horizon. Then, assuming that the matter content satisfies the weak energy condition and that the space-time metric has the standard asymptotic fall-off, one concludes that the surface gravity must satisfy an inequality. Finally, using the same Euclidean arguments as in the discussion of this section surface gravity is related to the Hawking temperature  $T_H$ , to transfer this inequality to the Hawking temperature:

$$T_{\rm H} \le \frac{\hbar}{\sqrt{4\pi A_H}}$$
 with  $A_H$ , the horizon area. (3.12)

Does this inequality hold in our case? Using the fact that the horizon area is given by

 $A_H = 4\pi \tilde{p}_c |_H = 16\pi m^2 (1 + \epsilon_m)$  and  $T_H$  is given by (3.11), it is trivial to verify that it does hold. It is therefore tempting to inquire if the temperature can be related to the effective matter stress-energy tensor as in [37]. However, as was emphasized in [37], that derivation was meant only for classical black holes since the weak energy condition is violated at the semi-classical level. This is indeed the case of the effective metric now under consideration. Furthermore, as discussed below in Section IV, the effective metric is asymptotically flat in a somewhat weaker sense than required in [37]. Therefore the derivation does not go through and the explicit expressions relating surface gravity to matter fields do not hold in our effective geometry. But since the final result does hold, it may well be that there is a non-trivial generalization of that analysis, applicable to our effective metric  $\tilde{g}_{ab}$ .

### IV. ASYMPTOTIC STRUCTURE

As explained in Section I, the asymptotic behavior of the effective geometry was not analyzed in detail in [2] largely because (i) it was found that the effective metric is in excellent agreement with the classical theory near horizons of macroscopic black holes, and, (ii) calculations with MATHEMATICA showed that for curvature scalars the agreement improves as one moves away from the horizons in the outward direction.<sup>3</sup> Therefore it was assumed in [2] that quantum effects would become totally negligible as one moves even further away from the horizon. However, it was realized soon thereafter –and independently pointed out in [34]– that the situation is not as simple. Therefore, in this section we will analyze the asymptotic properties of the effective metric in greater detail. We will find that the metric is asymptotically flat in the sense that it approaches a Minkowski metric as 1/r, but its curvature does not fall off as fast as it does in the standard treatments of asymptotics [27–30]. This specific asymptotic behavior is of some interest in its own right because, on the one hand it is sufficient to lead to a well-defined Arnowitt-Deser-Misner (ADM) energy, and on the other hand it brings out the richer structure made available by the stronger fall-off conditions used in the standard treatments.

#### A. Approximate expression of the exterior metric

Recall that the metric in the exterior region is given by (2.6):

$$\tilde{g}_{ab} dx^a dx^b = -\frac{\tilde{p}_b^2}{\tilde{p}_c L_o^2} dx^2 + \frac{\gamma^2 \tilde{p}_c \delta_{\tilde{b}}^2}{\sinh^2(\delta_{\tilde{b}})} dT^2 + \tilde{p}_c d\omega^2.$$
(4.1)

To facilitate comparison with the standard form of the Schwarzschild metric, let us change notation as follows. Set

$$t := x, \quad r_S := 2m, \quad r := r_S e^T \quad b_0 \equiv (1 + \gamma^2 \delta_{\tilde{t}}^2)^{\frac{1}{2}} =: 1 + \epsilon,$$
 (4.2)

For example, even for a black hole with mass as small as  $m=10^6\ell_{\rm Pl}$ , the square of the scalar curvature  $R^2$ —which vanishes in the classical theory—is very small at the horizon with  $R^2/K\approx 2.7\times 10^{-11}$ , where K is the Kretschmann scalar, and the ratio decreases as m increases.  $R^2$  increases slightly as one moves outward, reaches a maximum at  $T\approx 0.13$  and then starts decreasing. (Recall that the horizon is at T=0.)

and

$$R^{2} := \tilde{p}_{c} = 4m^{2} \left( e^{2T} + \frac{\gamma^{2} L_{0}^{2} \delta_{\tilde{c}}^{2}}{64m^{2}} e^{-2T} \right) \equiv r^{2} \left( 1 + \frac{\gamma^{2} L_{0}^{2} \delta_{\tilde{c}}^{2} r_{S}^{2}}{16r^{4}} \right). \tag{4.3}$$

Note that now the quantum parameters are  $\delta_{\tilde{c}}$  and  $\epsilon$ . (We switched from  $\delta_{\tilde{b}}$  to  $\epsilon$  because it is  $b_0 = 1 + \epsilon$ , rather than  $\delta_{\tilde{b}}$ , which appears in some of the key equations.) The exterior metric now takes the form:

$$\tilde{q}_{ab} \mathrm{d}x^a \mathrm{d}x^b = \tilde{q}_{tt} \mathrm{d}t^2 + \tilde{q}_{rr} \mathrm{d}r^2 + \tilde{R}^2 \mathrm{d}\omega^2. \tag{4.4}$$

One can now substitute the solutions (2.3), (2.7) and (2.8) in the expression of the metric coefficients and cast them in terms of the newly introduced variables  $t, r, r_S, \epsilon$ . The result is:

$$\tilde{g}_{tt} = -\left(\frac{r}{r_S}\right)^{2\epsilon} \frac{\left(1 - \left(\frac{r_S}{r}\right)^{1+\epsilon}\right) \left(2 + \epsilon + \epsilon \left(\frac{r_S}{r}\right)^{1+\epsilon}\right)^2 \left((2+\epsilon)^2 - \epsilon^2 \left(\frac{r_S}{r}\right)^{1+\epsilon}\right)}{16\left(1 + \frac{\delta_{\tilde{c}}^2 L_0^2 \gamma^2 r_S^2}{16r^4}\right) (1+\epsilon)^4}, \tag{4.5}$$

and

$$\tilde{g}_{rr} = \left(1 + \frac{\delta_{\tilde{c}}^2 L_0^2 \gamma^2 r_S^2}{16r^4}\right) \frac{\left(\epsilon + \left(\frac{r}{r_S}\right)^{1+\epsilon} (2+\epsilon)\right)^2}{\left(\left(\frac{r}{r_S}\right)^{1+\epsilon} - 1\right) \left(\left(\frac{r}{r_S}\right)^{1+\epsilon} (2+\epsilon)^2 - \epsilon^2\right)}.$$
(4.6)

These expressions of the effective metric coefficients are exact; we have not make any approximations or asymptotic expansions. Note that if quantum geometry effects are ignored, i.e. if we set  $\delta_{\tilde{c}} = 0$  and  $\epsilon = 0$ , we recover the Schwarzschild metric in the standard form.

We will now simplify these expressions by exploiting the smallness of quantum parameters (for example,  $\epsilon \approx 10^{-26}$  for a solar mass black hole) and the property  $r/r_S > 1$  that holds outside the horizon. Thus, using approximations

$$\left(2+\epsilon+\epsilon\left(\frac{r_S}{r}\right)^{1+\epsilon}\right)\approx 2, \quad \left((2+\epsilon)^2-\epsilon^2(\frac{r_S}{r})^{1+\epsilon}\right)\approx 4, \quad \text{and} \quad \left(1+\frac{\delta_c^2L_0^2\gamma^2r_S^2}{16r^4}\right)\approx 1, \ (4.7)$$

we obtain:

$$\tilde{g}_{tt} \approx -\left(\frac{r}{r_S}\right)^{2\epsilon} \left(1 - \left(\frac{r_S}{r}\right)^{1+\epsilon}\right) =: \tilde{g}_{tt}^{\circ},$$
(4.8)

and analogous approximations yield

$$\tilde{g}_{rr} \approx \left(1 - \left(\frac{r_S}{r}\right)^{1+\epsilon}\right)^{-1} =: \tilde{g}_{rr}^{\circ} \quad \text{and} \quad \tilde{R}^2 \approx r^2.$$
 (4.9)

Thus, in the asymptotic region, the effective metric is extremely well approximated by

$$\tilde{g}_{ab}^{\circ} dx^a dx^b = \tilde{g}_{tt}^{\circ} dt^2 + \tilde{g}_{rr}^{\circ} dr^2 + r^2 d\omega^2. \tag{4.10}$$

Now, these expressions –particularly the factor  $(r/r_S)^{2\epsilon}$  in  $\tilde{g}_{tt}^{\circ}$  that diverges as  $r \to \infty$  if  $\epsilon \neq 0$ – bring out the fact that the effective metric  $\tilde{g}_{ab}$  does not approach the flat metric  $\eta_{ab}$  with the line element  $\eta_{ab} \mathrm{d} x^a \mathrm{d} x^b = -\mathrm{d} t^2 + \mathrm{d} r^2 + r^2 \mathrm{d} \omega^2$ . This feature led authors of [34] to conclude that the metric is not asymptotically flat and its ADM energy is not well defined. We will show in the next subsections that these conclusions are unwarranted.

The key point is that while  $\eta_{ab}$  is an obvious choice to test asymptotic flatness, it is not sacrosanct. Consider, for example, the 2-dimensional metric  $\bar{g}_{ab}$  with the line element  $d\bar{s}^2 = -r^2dt^2 + dr^2$ , which again has  $\partial/\partial t$  as the Killing vector, whose norm  $\bar{g}_{tt}$  diverges as  $r \to \infty$ . Clearly, it does not approach the flat metric  $\bar{\eta}_{ab}$  in the 'natural coordinates' with line element  $\bar{\eta}_{ab}dx^adx^b = -dt^2 + dr^2$ . But not only is  $\bar{g}_{ab}$  asymptotically flat, it is in fact flat! Indeed,  $\bar{g}_{ab}$  is just the Minkowski metric in the Rindler wedge.<sup>4</sup> Returning to the effective metric, we will show that although  $\tilde{g}_{ab}$  does not approach the  $\eta_{ab}$  defined above, it does approach a Minkowski metric  $\eta_{ab}^o$  as 1/r at spatial infinity.

# B. Asymptotic flatness

The question then is whether the effective metric  $\tilde{g}_{ab}$  is asymptotically flat in spite of appearances. Let us begin by sharpening the notion of asymptotic flatness. We will say a given metric  $g_{ab}$  is asymptotically flat in the elementary sense at spatial infinity, if there exists a flat metric  $\eta_{ab}^o$  such that in a Cartesian chart defined by  $\eta_{ab}^o$ , components of  $g_{ab}$  approach the components of  $\eta_{ab}^o$  at least as fast as 1/r, as  $r \to \infty$  keeping  $t, \theta, \varphi$  constant (where  $(t, r, \theta, \varphi)$  refer to  $\eta_{ab}^o$ ). Thus, if a given metric  $g_{ab}$  is asymptotically flat in this sense, it does approach the Minkowski metric  $\eta_{ab}^o$ . However, as the example of the Rindler wedge explicitly shows,  $g_{ab}$  need not approach another Minkowski metric  $\eta_{ab}$  on the same manifold.

Let us return to the asymptotic form  $\tilde{g}_{ab}^{\circ}$  of the effective metric and examine its components in a chart that is better adapted to the issue of asymptotic flatness. Let us set

$$\tau = t \left(\frac{r}{r_S}\right)^{\epsilon},\tag{4.11}$$

so that for  $\epsilon=0$  –i.e. if we ignore quantum geometry corrections– $\tau$  reduces to the standard Schwarzschild time coordinate t. Now, as Eq. (2.1) shows, values of the quantum parameters  $\delta_{\tilde{b}}$ ,  $\delta_{\tilde{c}}$  –and hence of  $\epsilon$ – depend on the value of m of the Dirac observable on that solution. Thus, as one might expect, the transformation  $t \to \tau$  depends on the effective metric under consideration. To test asymptotic flatness of a given solution,  $\tau$  is defined using the  $\epsilon$  of that solution.

It is easy to verify that in the  $(\tau, r, \theta, \varphi)$  chart, the asymptotic metric assumes the form:

$$\tilde{g}_{ab}^{\circ} dx^{a} dx^{b} = \left( -d\tau^{2} + dr^{2} + r^{2} d\omega^{2} \right) + \left( \frac{r_{S}}{r} \right)^{1+\epsilon} d\tau^{2} + 2\epsilon \frac{\tau}{r} \left( 1 - \left( \frac{r_{S}}{r} \right)^{1+\epsilon} \right) dr d\tau 
- \left[ \left( 1 - \frac{1}{1 - \left( \frac{r_{S}}{r} \right)^{1+\epsilon}} \right) - \epsilon^{2} \frac{\tau^{2}}{r^{2}} \left( 1 - \left( \frac{r_{S}}{r} \right)^{1+\epsilon} \right) \right] dr^{2}.$$
(4.12)

This form implies that the Cartesian components of  $\tilde{g}_{ab}^{\circ}$  approach those of the flat metric  $\tilde{\eta}_{ab}^{\circ}$  with line element

$$\tilde{\eta}_{ab}^{\circ} dx^a dx^b = \left( -d\tau^2 + dr^2 + r^2 d\omega^2 \right), \tag{4.13}$$

<sup>&</sup>lt;sup>4</sup> A curved space, 4-dimensional analog of this situation occurs in the case of the Levi-Civita solution to Einstein's equation (known as the 'c-metric') [38] that, it turned out, represents the gravitational field of two accelerating black holes [39, 40]. In this solution, the norm of the Killing field  $\partial/\partial t$  also diverges at spatial infinity, although the metric is asymptotically flat in the standard sense [40].

at lease as fast as 1/r, as  $r \to \infty$  keeping  $\tau, \theta, \varphi$  constant. Thus,  $\tilde{g}_{ab}^{\circ}$  –and hence also the full effective metric  $\tilde{g}_{ab}$  – is indeed asymptotically flat at spatial infinity in the elementary sense.<sup>5</sup> The norm of the Killing field  $t^a$  of the effective metric  $\tilde{g}_{ab}$  is of course an intrinsic property of  $\tilde{g}_{ab}$  –insensitive to our choice of  $\eta_{ab}^{\circ}$  – and it does diverge at spatial infinity. As we mentioned already, this is similar to what happens in the Rindler wedge. But in that case the metric also admits another time-like Killing field with finite norm at spatial infinity. What is the situation in the present case? Since we are now dealing with a curved metric, the result is correspondingly weaker. The time-like vector field  $\tau^a$  –with unit norm– (defined by  $\tau^a \partial_a = \partial/\partial \tau$ ) is now only an asymptotic Killing vector of the metric  $\tilde{g}_{ab}$ , exactly as in the case of the Levi-Civita c-metric [38, 39].

However, asymptotic flatness of  $\tilde{g}_{ab}$  is weaker than in the standard treatments [27–30] because the usual conditions assume that not only does the physical metric approach those of a Minkowski metric as 1/r but the *n*th derivatives  $\mathring{\nabla}_{a_1} \dots \mathring{\nabla}_{a_n} g_{bc}$  also fall off at least as fast as  $1/r^{n+1}$  for a suitable  $n \ (\geq 2)$ . (Here  $\mathring{\nabla}$  is the derivative operator of  $\eta_{ab}^o$ .) In our case, while the (Cartesian) components of  $\tilde{g}_{ab}$  do approach those of  $\tilde{\eta}_{ab}^o$  as 1/r as required, components of  $\mathring{\nabla}_a \tilde{g}_{bc}$  do not all fall-off as  $1/r^2$  because of the presence of  $\tau/r$  terms; some fall-off only as 1/r. Therefore, while (Cartesian) components of the curvature tensor do fall off at least as fast as  $1/r^2$ , not all components fall-off as fast as  $1/r^3$  as in the standard treatments. Indeed, explicit calculations show that curvature invariants have the following asymptotic behavior:

$$(\tilde{R}_{ab}\tilde{g}^{ab})^2 = \frac{4\epsilon^2 \left( (\epsilon+1) + \left(\frac{r}{r_S}\right)^{-1-\epsilon} \right)^2}{r^4},\tag{4.14}$$

$$\tilde{R}_{ab}\tilde{R}^{ab} = \frac{2\epsilon^2 \left( (\epsilon^2 + 2) + 2(\epsilon - 1) \left( \frac{r}{r_S} \right)^{-1 - \epsilon} + 2 \left( \frac{r}{r_S} \right)^{-2 - 2\epsilon} \right)}{r^4},\tag{4.15}$$

$$\tilde{C}_{abcd}\tilde{C}^{abcd} = \frac{4\left((\epsilon - 2)\epsilon + (\epsilon - 3)\left(\frac{r}{r_S}\right)^{-1 - \epsilon}\right)^2}{3r^4}, \quad \text{and}$$
(4.16)

$$\tilde{K} = \frac{4\left(\epsilon^2((\epsilon - 2)\epsilon + 3) + (2(\epsilon - 1)\epsilon + 3)\left(\frac{r}{r_S}\right)^{-2 - 2\epsilon} + 2(\epsilon - 2)(\epsilon - 1)\epsilon\left(\frac{r}{r_S}\right)^{-1 - \epsilon}\right)}{r^4}, \quad (4.17)$$

where  $\tilde{K}$  is the Kretschmann scalar. (Throughout, we have given only the leading order terms.)

The question then is if the asymptotic fall-off of  $\tilde{g}_{ab}$  is nonetheless sufficient for the ADM energy to be well-defined. To address this issue, let us first recall a few facts about the ADM energy  $E_{\rm ADM}$ . In the literature there are several apparently distinct definitions of  $E_{\rm ADM}$ . The most widely used is the original one involving the Cartesian components of the (asymptotic) spatial metric, and in recent years another, involving the (asymptotic) spatial Ricci tensor, is also often used in the geometric analysis literature [31]. While these notions are distinct to start with, it is known that if the metric has the standard fall-off, all these definitions agree [32, 33]. In the geometric analysis literature it is also known that *some* of these definitions lead to a well-defined ADM energy even if the asymptotic fall-off is significantly weaker than

<sup>&</sup>lt;sup>5</sup> Indeed, throughout this calculation we could have worked directly with  $\tilde{g}_{ab}$  in place of  $\tilde{g}^o_{ab}$  with minor algebraic changes. But the simple reason behind asymptotic flatness would then have been obscured by the fact that the metric coefficients  $\tilde{g}_{tt}$  and  $\tilde{g}^o_{rr}$  are much more complicated than  $\tilde{g}^o_{tt}$  and  $\tilde{g}^o_{rr}$ .

in standard treatments. Finally, even though the curvature of  $\tilde{g}_{ab}$  falls-off more slowly than in standard treatments, the effective energy density  $\rho = \frac{1}{8\pi G}(\tilde{R}_{ab} - (1/2)\tilde{R}\tilde{g}_{ab})\hat{t}^a\hat{t}^b$  of the space-time has the desired fall-off,

$$\rho = -\frac{\epsilon}{8\pi G} \frac{r_S^{1+\epsilon}}{r^{3+\epsilon}},\tag{4.18}$$

making its integral over a spatial slice well-defined. (Here  $\hat{t}^a$  is the unit time-like vector field along  $t^a$ , or equivalently along  $\tau^a$ , since the two are parallel.) In light of these known results, one might hope that some of the standard definitions may assign a well-defined ADM energy to the effective metric  $\tilde{g}_{ab}$ . In Section IV C we will show that this is indeed the case. Furthermore, the calculation is carried out using the notion of time translation provided by the exact Killing field  $t^a$  of  $\tilde{g}_{ab}$ , since the notion of energy refers to the physical time-translation.

# Remarks:

1. As we emphasized at the end of Section IV A, to test if a given physical space-time  $(M, g_{ab})$  is asymptotically flat, one has to ask whether the (asymptotic region of the) manifold M admits a Minkowski metric  $\eta_{ab}^o$  to which the  $g_{ab}$  approaches as 1/r, and not whether  $g_{ab}$  approaches a pre-specified Minkowski metric  $\eta_{ab}$  on M as 1/r. This basic point is overlooked in the note added in the most recent version of [34] (version 3). Therefore, we will elaborate on it further.

Consider again the 2-metric  $\bar{g}_{ab} dx^a dx^b = -r^2 dt^2 + dr^2$  where  $r \in [0, \infty)$  and  $t \in (-\infty, \infty)$ . The norm of the Killing field  $\partial/\partial t$  diverges as  $r \to \infty$  and so if one were to insist on using the Minkowski metric  $\bar{\eta}_{ab} dx^a dx^b = -dt^2 + dr^2$  to test asymptotic flatness of  $\bar{g}_{ab}$ , one would conclude that it is *not* asymptotically flat at spatial infinity. But let us consider coordinates  $\tau, \mathfrak{r}$  defined via

$$\tau = r \sinh t$$
, and  $\mathfrak{r} = r \cosh t$ , (4.19)

so, that we have  $\mathfrak{r} \in [0, \infty)$  and  $\tau \in (-\infty, \infty)$  with  $\mathfrak{r}^2 - \tau^2 \geq 0$ , explicitly showing that the space-time under consideration is the Rindler wedge. Indeed, the line element defined by  $\bar{g}_{ab}$  becomes  $-\mathrm{d}\tau^2 + \mathrm{d}\mathfrak{r}^2$ ;  $\bar{g}_{ab}$  is clearly asymptotically flat at spatial infinity because it is flat! Thus, in place of the naive choice  $\bar{\eta}_{ab}$ , we have to use the Minkowski metric  $\bar{\eta}_{ab}^o \mathrm{d} x^a \mathrm{d} x^b = -\mathrm{d}\tau^2 + \mathrm{d}\mathfrak{r}^2$  to test asymptotic flatness of  $\bar{g}_{ab}$ . It is simply incorrect to declare that a metric is not asymptotically flat because it does not approach a *pre-specified* Minkowski metric.<sup>6</sup> This is the simple but key conceptual point that continues to be overlooked in various versions of [34].

Our construction of the Minkowski metric (4.13) through the introduction (4.11) of  $\tau$  is considered in [34] to be "problematic to examine the asymptotic limit" because "in this limit  $r \to \infty$ , the new coordinate is finite only when  $t \to 0$ ." By this logic, then, the passage (4.19) from t to  $\tau$  in the Rindler wedge would also have to be regarded as "problematic to examine the asymptotic limit" for exactly the same reason. Hence, the reasoning of [34] would lead to the conclusion that it is incorrect to use  $\bar{\eta}_{ab}^o$  to test asymptotic flatness of the Rindler metric  $\bar{g}_{ab}$  at spatial infinity; we have to stick to  $\bar{\eta}_{ab}$  and conclude that the metric is

<sup>&</sup>lt;sup>6</sup> The Levi-Civita c-metric [38, 39] referred to in footnote 4 provides a more sophisticated example. Although the metric is asymptotically flat [40], it took decades to recognize this fact because the metric is presented in coordinates which obscure the Minkowski metric it approaches.

not asymptotically flat!

2. In light of Remark 1 it is natural to ask if, in place of our  $\tilde{\eta}_{ab}^{\circ}$ , we can make an even better choice  $\mathring{\eta}_{ab}$  of the Minkowski metric such that the physical metric  $\tilde{g}_{ab}$  approaches  $\mathring{\eta}_{ab}$  in the standard sense of asymptotic flatness (e.g., as in [27, 29]). The answer is in the negative.<sup>7</sup> For, the standard asymptotic conditions require the Cartesian component of the effective stress-energy tensor  $T_{ab}$  to fall-off as  $1/\mathring{r}^4$ , where 'Cartesian coordinates' and  $\mathring{r}$  refer to  $\mathring{\eta}_{ab}$ . These conditions then imply that the Cartesian component of the Weyl tensor  $C_{abcd}$  would fall-off only as  $GM/\mathring{r}^3$ . Thus, if  $\mathring{\eta}_{ab}$  were to exist, the curvature invariant  $(R_{ab}R^{ab}/C_{abcd}C^{abcd})$  of the effective metric would have to go to zero at infinity. However, as Eqs. (4.15) and (4.16) show, this is not the case for  $\epsilon \neq 0$ . Thus, the putative  $\mathring{\eta}_{ab}$  does not exist; the effective metric  $\tilde{g}_{ab}$  is not asymptotically flat in the standard sense.

# C. The ADM energy

The ADM energy refers to an asymptotic time translation. In the present case, the metric  $\tilde{g}_{ab}$  has an exact time-like Killing field in the asymptotic region and so the energy should refer to this symmetry. Recall, however, that the norm of the Killing field  $t^a$  –and hence the lapse– diverges at infinity. Therefore, there is a clear danger that one would obtain an infinite answer using any of the definitions. We will now show that this is not the case.

Let us first consider the standard notion of ADM energy in terms of the spatial metric. It follows from Eq. (4.4) that the spatial metric  $\tilde{q}_{ab}$  can be taken to be:

$$\tilde{q}_{ab} dx^a dx^b = \tilde{g}_{rr} dr^2 + \tilde{R}^2 d\omega^2, \qquad (4.20)$$

with  $\tilde{g}_{rr}$  given by (4.6). The lapse N adapted to the Killing field  $t^a$  is given by  $N = (-\tilde{g}_{tt})^{\frac{1}{2}}$ . The ADM energy is then defined by (see, e.g., [41]):

$$E_{\text{ADM}} = \lim_{r \to \infty} \frac{1}{16\pi G} \oint_r dS_d \left( \det \tilde{q} \right)^{\frac{1}{2}} \tilde{q}^{ac} \tilde{q}^{bd} \left[ N \partial_{[c} \tilde{q}_{b]a} - \left( \tilde{q}_{a[b} - \delta_{a[b}) \left( \partial_{c]} N \right) \right], \tag{4.21}$$

where partial derivatives refer to the spatial Cartesian coordinates of  $\tilde{\eta}_{ab}^o$ . Substituting for  $\tilde{q}_{ab}$  from (4.20) we obtain

$$\lim_{r \to \infty} \frac{1}{16\pi G} \oint_r dS_d \left( \det \tilde{q} \right)^{\frac{1}{2}} \tilde{q}^{ac} \tilde{q}^{bd} \left[ N \partial_{[c} \tilde{q}_{b]a} \right] = \frac{m}{G} \equiv M, \tag{4.22}$$

and

$$\lim_{r \to \infty} \frac{1}{16\pi G} \oint_r dS_d \left( \det \tilde{q} \right)^{\frac{1}{2}} \tilde{q}^{ac} \tilde{q}^{bd} \left[ \left( \tilde{q}_{a[b} - \delta_{a[b]} \right) (\partial_{c]} N) \right] = 0, \tag{4.23}$$

That  $\tilde{g}_{ab}$  is not asymptotically flat in the standard sense was implicit in the first version of the paper. We thank the referee for raising this possibility of existence of another Minkowski metric  $\mathring{\eta}_{ab}$ , which led to the explicit argument in this remark. Note that some treatments of asymptotic flatness impose a stronger condition requiring that the physical metric should satisfy vacuum equations near infinity (see, e.g. [28, 30]). This stronger condition is trivially violated by the effective metric, just as it is violated by the Reissner-Nordstrom metric. Therefore in this remark we focus on treatments such as [27, 29] which do not require this stronger condition.

since  $(\tilde{q}_{ab} - \delta_{ab}) \propto D_a r D_b r$  and  $D_c N \propto D_c r$  everywhere on the spatial hypersurface. Therefore, we obtain  $E_{\rm ADM} = M$ .

Recall that there is a second expression of the energy in terms of the Ricci tensor  $\mathcal{R}_{ab}$  of the spatial metric  $\tilde{q}_{ab}$  [33] that is often used in the more recent geometric analysis literature [31]:

$$E_{\text{Ricci}} = \lim_{r \to \infty} \frac{1}{8\pi G} \oint_{r} d^{2}V \ r \ N \ \tilde{\mathcal{R}}_{ab} \hat{r}^{a} \hat{r}^{b} \,, \tag{4.24}$$

where  $d^2V$  is the area element of the r = const 2-sphere of integration, and  $\hat{r}^a$  a unit radial vector. Under standard asymptotic fall-off, we have  $E_{\text{Ricci}} = E_{\text{ADM}}$  [33]. What is the situation for the effective metric? An explicit calculation shows that  $E_{\text{Ricci}}$  is also well-defined. Its value is given by:

$$E_{\text{Ricci}} = (1 + \epsilon) M \quad \text{where} \quad 1 + \epsilon = \left[1 + \left(\frac{\gamma^2 \Delta}{2\pi m^2}\right)^{\frac{1}{3}}\right]^{\frac{1}{2}}.$$
 (4.25)

As already remarked, for macroscopic black holes  $\epsilon$  is extremely small; for a solar mass black hole,  $\epsilon = 10^{-26}$ . Both these values are essentially the same as the horizon energy,  $GE_H := \left(\frac{A_H}{16\pi}\right)^{\frac{1}{2}}$ , defined by the geometrical radius of the horizon, but differ by a quantum correction:

$$E_H = E_{\text{ADM}} \left( 1 + \frac{\gamma^2 L_0^2 \delta_c^2}{64m^2} \right)^{\frac{1}{2}} \equiv E_{\text{ADM}} \left( 1 + \epsilon_m \right).$$
 (4.26)

As we saw in Section II A, for a solar mass black hole this quantum correction is  $\sim 10^{-106}!$  Thus, for macroscopic black holes three quite different notions of energy associated by the effective space-time turn out to have essentially the same value. Note that the fact that the answers are not exactly the same is not surprising, but it is instructive. It is not surprising because notions that all agree in a given theory often differ when we pass to a more general theory with richer physics. We encounter numerous examples of this phenomena in planetary astronomy as we move from Newtonian gravity to general relativity, or in atomic physics as we transit from non-relativistic quantum mechanics to relativistic quantum mechanics and then to quantum field theory. The phenomenon is instructive because: (i) it brings out the fine balance struck by the standard notion of asymptotic flatness, where these apparently disjoint expressions agree exactly [33], and, (ii) it invites us to better understand the physics behind the differences in quantum corrections, which would in turn strengthen our intuition on the quantum nature of geometry.

To summarize, even though the  $\tilde{g}_{tt}$  component of the asymptotic form of the effective metric  $\tilde{g}_{ab}$  in the  $(t, r, \theta, \varphi)$  chart diverges as  $r \to \infty$ , we showed explicitly that  $\tilde{g}_{ab}$  is in fact asymptotically flat in the precise sense defined in Section IV B; it is just that the Minkowski metric it approaches is not the 'obvious' Minkowski metric associated with the  $(t, r, \theta, \varphi)$  chart. In addition, although the asymptotic fall-off of  $\tilde{g}_{tt}$  is weaker than that in standard treatments in that several components of the space-time curvature have weaker fall-off than in the standard context, the ADM energy associated with the time translation symmetry  $t^a$  is nonetheless well-defined. These results could be taken as an indication that, even though the norm of the time-like Killing field grows unboundedly as we approach spatial infinity, the effective metric  $\tilde{g}_{ab}$  manages to capture correct physics.

We will conclude this discussion with a few remarks.

1. The surprising element in the asymptotic properties of  $\tilde{g}_{ab}$  is that the norm of its time translation Killing field  $t^a$  grows as  $(r/r_s)^{\epsilon}$  even though  $\tilde{g}_{ab}$  approaches a flat metric  $\tilde{\eta}_{ab}^o$  as

- 1/r. This unforeseen behavior of  $t^a$  can be 'understood' as follows. Consider two situations: (i) a static black hole with horizon radius  $r_H$ , and, (ii) a black hole surrounded by a thick shell of matter between  $r_1$  and  $r_2$  with  $r_H < r_1 < r_2$ . Then, if the shell has positive energy density the norm of the Killing field at some given radius  $r = r_o > r_2$  in the second spacetime would be smaller than that for the first space-time. Reciprocally, if the energy density of the shell were negative, the norm in the second space-time at  $r = r_o > r_2$  would be greater than in the first space-time without any matter shell. In the effective space-time under consideration, as we saw in Eq. (4.18), we have an effective energy density  $\rho$  in the asymptotic region, which falls off as  $\rho \propto \epsilon / r^{3+\epsilon}$  but is negative. Had we switched off quantum gravity effects, we would have  $\epsilon = 0$  and  $\rho = 0$ . Thus, it is because the quantum corrected space-time has a negative effective energy density that the norm of the static Killing field at any given radius  $r_o$  in the asymptotic region is greater in the quantum corrected space-time than in its classical counterpart.
- 2. The ADM energy  $E_{\text{ADM}}$  we calculated refers to the time translation  $t^a$  of the physical metric. Had we calculated the generator of the asymptotic time translation  $\tau^a$ , we would have obtained zero. This is because a time evolution that corresponds to the change in  $\tau$  by a finite amount  $\tau_o$  amounts to a change in the affine parameter of  $t^a$  by  $r^{-\epsilon}\tau_o$ , which vanishes at infinity. Thus, this would be a 'bubble time evolution' vis a vis the affine parameter t of  $t^a$ , whence we would expect its generator to vanish, just as it does.
- 3. Even though the effective metric passes these tests, it may still be unsettling that if one goes further and further in the asymptotic region, the metric components in the  $(t, r, \theta, \varphi)$ -chart deviate more and more from those of the Schwarzschild metric of mass M. Note, however, that since we are comparing two different metrics, there is some ambiguity in saying what one means by 'the same point' in these different space-times. Instead of identifying points with the same values of  $(t, r, \theta, \varphi)$  in the effective space-time ( $\epsilon \neq 0$ ) and the Schwarzschild space-time ( $\epsilon = 0$ ), if we first introduce the coordinates  $(\tau, r, \theta, \varphi)$  in each of these space-times, and then identify points with same values of these coordinates, the two metrics would approach each other (see Eq. (4.12)).

But one could still insist on using  $(t, r, \theta, \varphi)$  in this comparison, say, by appealing to the fact that these coordinates have a natural geometrical interpretation. Suppose we do so and ask when the deviations would become important. Then, for the deviation to be, say, 10%, for a solar mass black hole one would have to move away from the horizon  $\sim 10^{10^{24}} r_S$  because  $\epsilon \approx 10^{-26}$  in this case. Note that this distance is overwhelmingly larger than the radius of observable universe which is  $\sim 5 \text{Gpc} \approx 10^{22} r_S$  (since  $r_S \approx 3 \text{km}$  in this case). Even for a black hole of  $10^6 \text{M}_{\text{Pl}}$ , one would have to move away  $\sim 10^{1158} \ell_{\text{Pl}}$ , while  $5 \text{Gpc} \approx 10^{61} \ell_{\text{Pl}}$ . We can also ask a reciprocal question. Suppose for a solar mass black hole we move away from the horizon by 5 Gpc, i.e. all the way to the edge of the observable universe. How big a deviation would there be for  $g_{tt}$  from the Schwarzschild metric? It would be of the order  $10^{-23}$ . Thus, even if we insist on using the  $(t, r, \theta, \varphi)$ -chart in the comparison, from a physical view point, there is little reason to be concerned about viability of the effective metric.

# V. DISCUSSION

The issue of singularity resolution has drawn considerable attention in all major approaches to quantum gravity. As we explained in Section I, in contradistinction to views sometimes expressed in the literature on string theory, and on the 'weak gravity conjecture',

the viewpoint in LQG is that it is the quantum nature of geometry that leads to a natural resolution of space-time singularities. This viewpoint is realized in a concrete manner in LQC, where the issue has been discussed extensively from various angles (see, e.g., [7, 8]). In particular, the effective equations have been derived quite systematically starting from the dynamics of sharply peaked quantum states in LQC [6, 42, 43]. For black holes, on the other hand, the situation is less satisfactory. While effective equations have been introduced taking inspiration from LQC, so far there is no systematic derivation starting from (a symmetry-reduced version of) LQG. Rather, just as effective equations provided a powerful tool in an earlier phase of LQC, providing guidance for full quantum theory beyond the FLRW models, the hope is that effective equations would serve the same purpose for the ongoing efforts (see, e.g.[44–49]) to construct a more complete quantum description of the singularity resolution for black holes.

The approach to effective dynamics presented in [1, 2] was in this spirit. Therefore, the focus was largely on overcoming the limitations of the previous effective descriptions of the Schwarzschild interior (see, e.g. [9–20]) by using a new prescription –with plausible theoretical underpinnings– to fix the quantum parameters δb, δc. This strategy provided a satisfactory effective description of the quantum extension of the space-time beyond the classical singularity in the sense that it succeeded in overcoming all known limitations of the previous approaches to the Schwarzschild interior. However, being an effective description, its scope only covers macroscopic black holes, say with M > 10<sup>6</sup>MPl; it does not incorporate the full quantum gravity effects that are needed to handle Planck mass ones. Nonetheless, its attractive features –e.g., on absolute bounds on curvature– suggest that it probably captures some of the essential features of the mechanisms that are expected to lead to the resolution of black hole singularities in full LQG. Because of these features, it has already served as a point of departure for some generalizations –e.g., to include physical matter fields in the model [50], and to extend it to dynamical situations involving collapse [51].

The approach in [1, 2] also provided a proposal to extend previous investigations of the symmetry reduced Schwarzschild interior to the exterior region by exploiting the fact that the exterior geometry of the Schwarzschild solution also admits 3-surfaces with homogeneous geometries, although they are now time-like. However, in [1, 2] the effective geometry of the exterior region was not investigated in as much detail as that of the interior. Therefore, in this note we analyzed some features of the exterior. First of all, since the effective metric was constructed separately in the interior and exterior region, a priori it is not obvious that it would match smoothly across the horizons that separate these regions. We provided Eddington-Finkelstein type coordinates in Section II B to explicitly show that this is the case. More importantly, having a candidate effective metric for the exterior region, one could perform a Wick transform and compute the quantum gravity correction to the Hawking temperature. We calculated this correction exactly in Section III. It is negligibly small for macroscopic black holes, as hoped from the general LQG perspective.

In Section IV we investigated the asymptotic properties of the effective geometry. We showed that the metric does approach a Minkowski metric as 1/r in a precise sense and the ADM energy is well-defined and agrees –within small quantum corrections– with the horizon energy, computed using the horizon area. However, we also found that the curvature of the effective metric goes to zero at a rate that is slower than in the standard treatments of asymptotic flatness. As we discussed in Section IV C, for the macroscopic black holes considered in this paper, this feature has no observational consequences within our cosmological radius. Nonetheless, it could well be that there is a more astute choice of the quantum parameters  $\delta_b$ ,  $\delta_c$  –or a modification of the treatment of the exterior effective geometry– that yields the standard fall-off of curvature at infinity while retaining the merits of the current effective descriptions. While interesting ideas in this direction are available (see, e.g., [52]), their conceptual underpinning is not transparent. Perhaps the detailed analysis of the asymptotic structure presented in this note will clarify the type of modifications that are likely to lead to the desired results both in the interior and in the exterior, and serve as guidelines for new proposals that are also conceptually well-motivated.

A limitation of the effective equations discussed in this note is that because they are obtained starting with a symmetry reduced theory, it is not known if there is a 4-dimensional covariant action whose symmetry reduction yields these equations. However, this is a limitation only of the present status of the program: contrary to the suggestion made in [35], there is no viable obstruction. Because of spherical symmetry, one may be tempted to use known results in 2-dimensional metric theories of gravity to probe this issue. But note that there is no a priori requirement that the full theory, without symmetry reduction, must be a metric theory. Indeed, already in the simpler homogeneous isotropic cosmology (Friedmann-Lemaitre-Robertson-Walker models), it was initially far from being obvious that the (now widely used) effective equations of LQC arise from the symmetry reduction of a covariant 4-dimensional field theory. It turned out that there is such a covariant action and, furthermore, the full (symmetry-unreduced) theory has the same degrees of freedom as general relativity. However, it is based on a Palatini action, that uses both a metric  $g_{ab}$ , and an independent affine connection  $\nabla_a$  (that is distinct from the metric connection  $\nabla_a^{(g)}$ ) [53]. The situation may be similar with the effective equations used in this note. Another possibility is that the desired (symmetry-unreduced) covariant equations do exist but they involve variables that are non-local in the metric. For example, in semi-classical gravity describing 1+1 dimensional black holes including back reaction, one often solves for the conformal factor  $e^{2\rho}$  that relates the physical metric to the flat metric (so  $2 \square \rho = -R$ , the physical scalar curvature), and derivatives of  $\rho = -\frac{1}{2}\Box^{-1}R$  feature in the quantum corrected equations which are fully covariant (see, e.g., [54]). Finally, the symmetry-unreduced, general covariant equations could involve additional non-dynamical variables –e.g., gauge fields which are non-dynamical in 1+1 dimension. Indeed, a decade long puzzle [55, 56] that equations for a 1+1 stringy black hole were not of the form of a dilaton gravity theory was resolved by introducing such fields [57]. It would be of considerable interest if one could use an avenue along these lines to construct a covariant action for the current effective equations (or, for a more satisfactory modification thereof). Such a discovery would enable one to address several important questions -e.g., the issue of stability, details of gravitational collapse, Hawking radiation and its back reaction, in the regime in which the black hole remains macroscopic, and space-time dynamics beyond the Page time. As we mentioned above, there are several works in progress within LQG to better understand the physics of black holes beyond effective descriptions [44–49, 59]. Just as the present effective equations can provide guidance to these investigations, results obtained in the broader context of LQC could also suggest strategies to embed effective equations in a more complete framework.

<sup>&</sup>lt;sup>8</sup> Furthermore, in general Palatini theories, action can contain traces of products of the Ricci tensor  $R_a{}^c = R_{ac}g^{cb}$  and still the theory has no additional degrees of freedom if  $R_{[ab]} = 0$ . These are not known to be equivalent to scalar tensor theories [58]. Therefore arguments that appeal to scalar tensor theories [35] are also inconclusive.

# Acknowledgments

We would like to thank Tommaso De Lorenzo and especially Amos Ori and Parampreet Singh for stimulating discussions, Jim Bardeen for useful correspondence, and an anonymous referee for informing us of Ref. [37]. This work was supported in part by the NSF grants PHY-1505411 and PHY-1806356, grant UN2017-9945 from the Urania Stott Fund of the Pittsburgh Foundation, the Eberly research funds of Penn State, and by Project. No. FIS2017-86497-C2-2-P of MICINN from Spain. J.O. acknowledges the Operative Program FEDER 2014-2020 and the Consejer´ıa de Econom´ıa y Conocimiento de la Junta de Andaluc´ıa.

- [1] A. Ashtekar, J. Olmedo and P. Singh, Quantum Transfiguration of Kruskal Black Holes, Journal-ref: Phys. Rev. Lett. 121, 241301 (2018).
- [2] A. Ashtekar, J. Olmedo and P. Singh, Quantum Extension of the Kruskal Space-time, Phys. Rev. D 98, 126003 (2018).
- [3] N. Englehardt and G. T. Horowitz, New insights into quantum gravity from gauge/gravity duality, Int. J. Mod. Phys. D 25, 1643002 (2016).
- [4] T. Crisford, G. T. Horowitz and J. E. Santos, Testing the Weak Gravity Cosmic Censorship Connection, Phys. Rev. D 97, 066005 (2018).
- [5] F. C. Eperon, B. Ganchev and J. E. Santos, Plausible scenario for a generic violation of the weak cosmic censorship conjecture in asymptotically flat four dimensions, Phys. Rev. D 101, 041502 (2020).
- [6] A. Ashtekar and P. Singh, Loop Quantum Cosmology: A Status Report, Class. Quant. Grav. 28, 213001 (2011).
- [7] P. Singh, Are loop quantum cosmologies never singular? Class. Quant. Grav. 26 125005 (2009).
- [8] I. Agullo and P. Singh, Loop Quantum Cosmology: A brief review, in *Loop Quantum Gravity: The first 30 years*, (World Scientific, Singapore, (2017)), Chapter 6.
- [9] A. Ashtekar and M. Bojowald, Quantum Geometry and the Schwarzschild singularity, Class. Quant. Grav. 23 391-411 (2006).
- [10] L. Modesto, Loop quantum black hole, Class. Quant. Grav. 23 5587-5602 (2006).
- [11] C. G. Boehmer and K. Vandersloot, Loop quantum dynamics of Schwarzschild interior, Phys. Rev. D 76, 1004030 (2007).
- [12] D. W. Chiou, Phenomenological loop quantum geometry of the Schwarzschild black hole, Phys. Rev. D 78, 064040 (2008).
- [13] D. Cartin and G. Khanna, Wave functions for the Schwarzschild black hole interior, Phys. Rev. D 73 104009 (2006).
- [14] M. Campiglia, R. Gambini and J. Pullin, Loop quantization of a spherically symmetric midsuperspaces: The interior problem, AIP Conf. Proc. 977, 52-63 (2008).
- [15] J. Brannlund, S. Kloster and A. DeBenedictis, The Evolution of Λ Black Holes in the Mini-Superspace Approximation of Loop Quantum Gravity, Phys. Rev. D 79, 084023 (2009).
- [16] N. Dadhich, A. Joe and P. Singh, Emergence of the product of constant curvature spaces in loop quantum cosmology, Class. Quant. Grav. 32, 185006 (2015).
- [17] A. Corichi and P. Singh, Loop quantum dynamics of Schwarzschild interior revisited, Class.

- Quant. Grav. 33, 055006 (2016).
- [18] J. Olmedo, S. Saini and P. Singh, From black holes to white holes: a quantum gravitational symmetric bounce, Class. Quant. Grav. 34, 225011 (2017).
- [19] J. Cortez, W. Cuervo, H. A. Morales-T´ecotl and J. C. Ruelas, On effective loop quantum geometry of Schwarzschild interior, Phys. Rev. D 95, 064041 (2017).
- [20] A. Yonika, G. Khanna and P. Singh, Von-Neumann stability and singularity resolution in loop quantized Schwarzschild black hole, Class. Quant. Grav. 35, 045007 (2018).
- [21] D-W. Chiou, Phenomenological dynamics of loop quantum cosmology in Kantowski-Sachs spacetime, Phys. Rev. D 78, 044019 (2008).
- [22] A. Joe and P. Singh, Kantowski-Sachs spacetime in loop quantum cosmology: bounds on expansion and shear scalars and viability of quantization prescriptions, Class. Quant. Grav. 32, 015009 (2015).
- [23] S. Saini, P. Singh, Geodesic completeness and the lack of strong singularities in effective loop quantum Kantowski-Sachs spacetime, Class. Quant. Grav. 33, 245019 (2016).
- [24] H. Liu and K. Noui, Gravity as an su(1, 1) gauge theory in four dimensions, Class. Quant. Grav. 34, 135008 (2017).
- [25] S. A. Fulling and S. N. M. Ruijsenaars, Temperature, periodicity and horizons, Phys. Rep. 152, 135-176 (1987).
- [26] G. W. Gibbons, M. J. Perry, Black holes and thermal Green's functions, Proc. Roy. Soc. Lond. A358, 467-494 (1978).
- [27] R. Geroch, In: *Asymptotic Structure of Space-time*, edited by F. P. Esposito and L. Witten, (Plenum, New York (1976)); Chapter 1.
- [28] A. Ashtekar and R. O. Hansen, A unified treatment of spatial and null infinity in general relativity: Universal structure, asymptotic symmetries and conserved quantities at spatial infinity, J. Math. Phys. 19, 1542-1566 (1978).
- [29] A. Ashtekar, Asymptotic structure of the gravitational field at spatial infinity, In: *General Relativity and Gravitation: One Hundred Years After the Birth of Albert Einstein*, edited by A. Held (Plenum, New York (1980)).
- [30] R. M. Wald, *General Relativity*, (U. Chicago Press, Chicago, (1984), Chapter 11.
- [31] R. Schoen, Localizing solutions of the Einstein equations, Lectures at the Institut Henri Poincar´e, General Relativity: A Celebration of the 100th Anniversary, https://philippelefloch.files.wordpress.com/2015/11/2015-ihp-richardschoen.pdf (2015).
- [32] A. Ashtekar and A. Magnon, On conserved quantities in general relativity, J. Math. Phys. 20, 793-800 (1979).
- [33] A. Ashtekar and A. Magnon, From i ◦ to 3+1 description of spatial infinity, J. Math. Phys. 25, 2682-2690 (1984).
- [34] M. Bouhmadi-L´opez S. Brahma, C-Y Chen, P. Chen and D-h Chen, Comment on "Quantum Transfiguration of Kruskal Black Holes" arXiv:1902.07874.
- [35] M. Bojowald, Comment (2) on "Quantum transfiguration of Kruskal black holes", arXiv:1906.04650.
- [36] A. Ashtekar and A. Magnon, A technique for analyzing the structure of isometries, J. Math. Phys. 18, 1567-1572 (1978).
- [37] M. Visser, Dirty black holes: Thermodynamics and horizon structure, Phys. Rev. D 46, (1992) 2445-2451.
- [38] T. Levi-Civita, Il sottocaso B2: soluzioni oblique, Atti. Accad. Naz. Lincei Cl. Sci. Fis. Mat. Nat. Rend. 27, 343 (1918).

- [39] William Kinnersley and M. Walker, Uniformly accelerating charged mass in general relativity, Phys. Rev. D 2, 1359-1370 (1970).
- [40] A. Ashtekar and T. Dray, On the existence of solutions to Einstein's equations with non-zero Bondi news, Commun. Math. Phys. 79, 581-589 (1981).
- [41] T. Thiemann, Generalized boundary conditions for general relativity for the asymptotically flat case in terms of Ashtekar's variables, Class. Quant. Grav. 12 181-198 (1995).
- [42] J. Willis, On the low energy ramifications and a mathematical extension of loop quantum gravity; Ph.D. Dissertation, The Pennsylvaina State University (2004).
- [43] V. Taveras, LQC corrections to the Friedmann equations for a universe with a free scalar field, Phys. Rev. D 78, 064072 (2008).
- [44] R. Gambini, J. Omedo and J. Pullin, Quantum black holes in loop quantum gravity, Class. Quant. Grav. 31, 095009 (2014).
- [45] H. M. Haggard and C. Rovelli, Black hole fireworks: quantum-gravity effects outside the horizon spark black to white hole tunneling, Phys. Rev. D 92, 104020 (2015).
- [46] R. Gambini and J. Pullin, Hawking radiation from a spherical loop quantum gravity black hole, Class.Quant.Grav. 31 115003 (2014).
- [47] M. Campiglia, R. Gambini, J. Olmedo and J. Pullin, Quantum self-gravitating collapsing matter in a quantum geometry, Class. Quant. Grav. 33, 18LT01 (2016).
- [48] E. Bianchi, M. Christodoulou, F. D'Ambrosio, H. M. Haggard and C. Rovelli, White holes as remnants: A surprising scenario for the end of a black hole, arXiv:1802.04264.
- [49] F. Benitez, R. Gambini, L. Lehner, S. Liebling, and J. Pullin, Critical collapse of a scalar field in semiclassical loop quantum gravity, Phys. Rev. Lett. 124, 071301 (2020).
- [50] C. Zhang and X. Zhang, Quantum geometry and effective dynamics of Janis-Newman-Winicour singularities, Phys. Rev. D 101, 086002 (2020).
- [51] K. Rama, Black hole or fuzz ball or a loop quantum star? Assessing the fate of a massive collapsing star, arXiv:1912.05300.
- [52] L. Modesto, Space-time structure of loop quantum black hole, Int. J. Theor. Phys. 49, 1649-83 (2010).
- [53] G. J. Olmo and P. Singh, Covariant effective action for loop quantum cosmology ´a la Palatini, JCAP, 0901:030 (2009).
- [54] A. Strominger, Les Houches lectures on black holes, hep-th/9501071.
- [55] R. Dijkgraaf, H. Verlinde, E. Verlinde, String propagation in a black hole geometry, Nucl. Phys. B 371 269-314 (1992).
- [56] D. Grumiller, D. Vassilevich, Non-existence of a dilaton gravity action for the exact string black hole, JHEP 0211, 018 (2002).
- [57] D. Grumiller, An action for the exact string black hole, JHEP 0505, 028 (2005).
- [58] G. J. Olmo, Communication transmitted to the authors (2019).
- [59] M. Han, Improved (¯µ-scheme) effective dynamics of full loop quantum gravity, arXiv-1912.08668