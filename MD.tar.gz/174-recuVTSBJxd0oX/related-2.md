# A note on electromagnetic and gravitational perturbations of the Bardeen de Sitter black hole: quasinormal modes and greybody factors

Sahel Dey<sup>∗</sup><sup>1</sup> and Sayan Chakrabarti†<sup>2</sup>

<sup>1</sup>Joint Astronomy Programme and Department of Physics, Indian Institute of Science, Bangalore-560012, India <sup>2</sup>Department of Physics, Indian Institute of Technology Guwahati, Guwahati-781039, India

#### Abstract

Bardeen de-Sitter (BdS) black hole is a spherically symmetric solution of Einstein's equation which is coupled to nonlinear electromagnetic field in a way that one gets a regular solution, devoid of any singularity at the origin. We compute the quasinormal (QN) frequencies for BdS black hole due to electromagnetic and gravitational perturbations. We analyse the behaviour of both real and imaginary parts of BdS QN frequencies by varying the black hole parameters and compare frequencies with Reissner-Nordstr¨om de-Sitter (RN-dS) black hole. Interestingly, we find that the response of BdS and RN-dS black holes under electromagnetic and gravitational perturbations are different when the charge parameter is varied, which can be used to understand nonlinear and linear electromagnetic fields in curved spacetime separately. A study on the dynamics of perturbation as well as the scattering from the BdS black holes using WKB approach is performed. Greybody factors and their variations with black hole parameters are investigated.

### 1 Introduction

It is very well known that general relativity is a theory which is plagued with the appearance of singularities. The invariant scalar curvature which necessarily tells about the gravitational field strength diverges at those spacetime singularities. Gravitational singularities appear in general relativity in the context of black holes. Black holes are objects which have singularities at the origin hidden by the event horizons. However, appearance of singularities in a theory means that the theory breaks down at the point where the singularity is present. Hence, the task of avoiding the singularities in general theory of relativity is one of the most fundamental ones and a set of solutions known as "regular black holes" play an important role in this context. As the name suggests, when the black hole does not have a spacetime singularity at the origin, it is termed as a "regular black hole". Bardeen [\[1\]](#page-18-0) obtained the first solution of regular black holes with non-singular geometry satisfying the weak energy condition. The solutions is known as the Bardeen black hole in the literature. The solution Bardeen obtained was not a vacuum solution rather gravity was modified by introducing some form of matter. Therefore an energy momentum tensor was introduced in the Einstein's equation in order to achieve that goal. The introduction of the energy momentum tensor was done in an ad hoc manner and hence the Bardeen solution lacked physical motivation. After a long time, Ay´on-Beato and Garc´ıa [\[2\]](#page-18-1) showed that the energy momentum tensor necessary to obtain regular black hole solution is essentially the gravitational field of some magnetic monopole arising out of a specific form of non-linear electrodynamics.

<sup>∗</sup>Email: saheldey917@gmail.com †Email: sayan.chakrabarti@iitg.ac.in Many other solutions [\[3\]](#page-18-2)-[\[13\]](#page-19-0), motivating the avoidance of singularity was proposed thereafter. Stability properties [\[14,](#page-19-1) [15,](#page-19-2) [16\]](#page-19-3) and quasinormal modes [\[17,](#page-19-4) [18\]](#page-19-5), thermodynamics [\[19\]](#page-19-6) and geodesic structure [\[20\]](#page-19-7) of such regular black holes were studied in detail. On another front, Fernando [\[21\]](#page-19-8) has recently found out a de Sitter branch for the regular Bardeen black hole and corresponding grey body factors for such a black hole were calculated. The stability analysis and quasinormal modes due to scalar and Fermionic perturbations were also studied [\[22\]](#page-19-9) for this background. The motivations for studying regular black holes in de Sitter space comes from the fact that our universe looks like asymptotically de Sitter at very early and late times. Observational data also indicates that our universe is going through a phase of accelerated expansion [\[23,](#page-19-10) [24,](#page-19-11) [25\]](#page-19-12), which, along with many other explanations also indicates the existence of a positive cosmological constant. Hence, the study of black holes and its various features in de Sitter space is by itself an increasingly demanding area of research. In continuation of our earlier work [\[22\]](#page-19-9), we will study the gravitational and electromagnetic perturbations of the regular Bardeen dS black hole in this paper.

The stability of a black hole spacetime is one of the most intriguing questions that one can ask in general relativity: the answer to the question of black hole stability under certain perturbation can answer many questions related to the black hole itself. The study of black hole perturbations is an active area of research and has immense effect on various important properties of black holes [\[26,](#page-19-13) [27,](#page-19-14) [28,](#page-19-15) [29\]](#page-19-16). Generally one studies the evolution of a field (scalar, Fermionic, electromagnetic or gravitational) in a black hole background or in a black hole-black hole collision process in order to understand the stability of that particular black hole spacetime under the specific field perturbation. It is well know that the dynamical evolution of perturbations of a black hole background can be classified into three distinct stages, the first stage consists of an initial outburst of wave which depends completely on the initial perturbing field, the second one consists of damped oscillations, known in the literature as the quasinormal modes (QNM) whose frequencies are complex numbers. The real part of these frequencies represent the real oscillation frequency of the black hole under the perturbation and the imaginary part represents damping. The final stage is a power law tail behaviour at very late times. QN frequencies not only provide us with the information about the stability of the black hole spacetime, they are used to determine the black hole parameters (mass, charge and angular momentum) too. Numerical simulations depicting formation of a black holes in a gravitational collapses as well as that of collision of two black holes exclusively show that irrespective of the nature of the perturbations, the black hole's response will be dominated by the QNMs [\[30\]](#page-19-17). One important aspect of studying black hole stability is the fact that equations governing the black hole perturbations in most of the cases can be cast into a Schr¨odinger like equation. The QNMs are solutions to that Schr¨odinger like wave equation with complex frequencies for boundary conditions which are completely ingoing at the horizon and purely outgoing at asymptotic infinity (for the asymptotically flat or de Sitter black holes). It is to be noted that apart from the fact that the QN frequencies contain important information about the black hole parameters, they were also of importance from the point of view of AdS/CFT correspondence. It has been found [\[32,](#page-19-18) [33\]](#page-19-19) that QNMs in AdS space time appear naturally in the description of the dual conformal field theory on the boundary. This observation has motivated the study of QNMs towards asymptotically AdS black holes [\[34,](#page-19-20) [35\]](#page-19-21) too. On another front, despite their classical in origin, QNMs have been shown to provide glimpses to quantum nature of black holes [\[36,](#page-19-22) [37,](#page-19-23) [38\]](#page-19-24).

A lot of work [\[42\]](#page-19-25)-[\[51\]](#page-20-0) has been done on QNMs of scalar, electromagnetic, gravitational, Dirac perturbations, decay of charged fields, asymptotic QNMs and signature of quantum gravity etc in de Sitter space. However, the regular black holes in de Sitter space is comparatively a less studied regime. In this paper, we will try to fill up the gap in the literature by discussing the QNMs of the Bardeen de Sitter (henceforth BdS) black hole due to electromagnetic and gravitational perturbations. The plan of the paper is as follows: in the next section we give a brief discussion on the BdS black hole. In section 3 we present a discussion of WKB method for calculating the QNMs along with a study of the Electromagnetic QNMs of the BdS black holes. Section 4 deals with the Gravitational quasinormal modes of the BdS black hole. In section 5 we give a comparative discussion about the dynamics of the perturbations. Section 6 contains a discussion about the greybody factor and its variation with the black hole parameters. Finally, in section 7 we conclude the paper with a brief discussion on future directions.

#### 2 A brief discussion on BdS black hole

This section deals with a very brief introduction to the Bardeen de Sitter (BdS) black hole following the works in [21]. The authors of [21] has modified the works of [2] to incorporate a positive cosmological constant in the action. The action therefore looks like:

<span id="page-2-2"></span>
$$S = \int d^4x \sqrt{-g} \left( \frac{R - 2\Lambda}{16\pi} - \frac{1}{4\pi} \mathcal{L}(F) \right) \tag{1}$$

In the above, R is the Ricci Scalar and  $\mathcal{L}(F) = \frac{3}{2\alpha q^2} \left(\frac{\sqrt{2q^2F}}{1+\sqrt{2q^2F}}\right)^{5/2}$  is a function of the field

strength F of the non-linear electrodynamics. Here field strength(F) is defined as  $F = \frac{1}{4}F^{\mu\nu}F_{\mu\nu}$  where  $F_{\mu\nu} = 2(\nabla_{\mu}A_{\nu} - \nabla_{\nu}A_{\mu})$ . The parameter  $\alpha$  in  $\mathcal{L}(F)$  is related to the magnetic charge (q) and the mass (M) of the space time as follows:  $\alpha = \frac{q}{2M}$ . The equations of motion from the above action comes out to be [21]:

$$G_{\mu\nu} + \Lambda g_{\mu\nu} = 2\left(\frac{\partial \mathcal{L}(F)}{\partial F} F_{\mu\lambda} F_{\nu}^{\lambda} - g_{\mu\nu} \mathcal{L}(F)\right)$$
 (2)

$$\nabla_{\mu} \left( \frac{\partial \mathcal{L}(F)}{\partial F} F^{\nu\mu} \right) = 0 \tag{3}$$

$$\nabla_{\mu}(*F^{\nu\mu}) = 0 \tag{4}$$

A static spherically symmetric solution for the above set of equations exist [21]:

<span id="page-2-0"></span>
$$ds^{2} = -\left(1 - \frac{2Mr^{2}}{(r^{2} + q^{2})^{3/2}} - \frac{\Lambda r^{2}}{3}\right)dt^{2} + \left(1 - \frac{2Mr^{2}}{(r^{2} + q^{2})^{3/2}} - \frac{\Lambda r^{2}}{3}\right)^{-1}dr^{2} + r^{2}(d\theta^{2} + \sin^{2}\theta d\phi^{2})$$
(5)

The zeros of the function  $f(r) = 1 - \frac{2Mr^2}{(r^2+q^2)^{3/2}} - \frac{\Lambda r^2}{3}$  gives the horizon. The BdS black hole there can have at most three horizons corresponding to three real roots of the function f(r): the black hole inner $(r_i)$  and outer horizons $(r_h)$  along with the cosmological horizon $(r_c)$ . It is to be noted that the BdS black hole is structurally similar to the Reissner-Nordström-de Sitter (RNdS) or Born-Infeld de Sitter (BIdS) black holes which also admits a possibility of three distinct horizons as well as a single or degenerate horizons too (corresponding to extremal case). However, the event horizon is much larger for RNdS black hole as compared to a BdS one [21]. The non-singular structure of the BdS geometry can be checked by direct calculation of the scalar curvatures R,  $R_{\mu\nu}R^{\mu\nu}$ ,  $R_{\mu\nu\lambda\sigma}R^{\mu\nu\lambda\sigma}$ , which are finite everywhere as compared to divergences at r=0 in case of Einstein black holes except the electromagnetic field invariant F which is singular at r=0 [21].

## 3 Electromagnetic perturbations and QNMs of the BdS black hole

In this paper we focus our attention on the behaviour of the dynamical response of the spherically symmetric regular black hole in de Sitter space under electromagnetic and gravitational perturbations. In this section we will be discussing the electromagnetic field perturbations of the BdS black hole in order to study the behaviour of the QNMs in this background by varying a set of black hole parameters. Since our system is an open one, the black hole, after a small perturbation, relaxes to its equilibrium state by losing energy by emitting electromagnetic or gravitational radiation, depending on the nature of the underlying perturbations.

As discussed in Section 2, BdS background metric is given by Eqn.(5). Now we decompose 4-vector potential of the electromagnetic field in two parts. One is unperturbed background potential  $(\bar{A}_{\mu})$  and another is perturbed part  $(\delta A_{\mu})$ .

<span id="page-2-1"></span>
$$A_{\mu} = \bar{A}_{\mu} + \delta A_{\mu} \tag{6}$$

In static and spherically symmetric background, ansatz for unperturbed 4-vector potential of magnetically charged black hole is given by

$$\bar{A}_{\mu} = -q\cos\theta\delta^{\phi}_{\mu} \tag{7}$$

Considering spherically symmetric BdS background, perturbation in vector potential can be written as a superposition of vector spherical harmonics, where  $Y_{\ell m}(\theta, \phi)$  are standard scalar spherical harmonics:

$$\delta A_{\mu_{\text{axial}}} = \sum_{\ell=0}^{\infty} \sum_{m=-\ell}^{\ell} \begin{bmatrix} 0 \\ 0 \\ a_0(t,r) \frac{1}{\sin \theta} \frac{\partial Y_{\ell m}}{\partial \phi} \\ -a_0(t,r) \sin \theta \frac{\partial Y_{\ell m}}{\partial \theta} \end{bmatrix}, \ \delta A_{\mu_{\text{polar}}} = \sum_{\ell=0}^{\infty} \sum_{m=-\ell}^{\ell} \begin{bmatrix} a_1(t,r) Y_{\ell m} \\ a_2(t,r) Y_{\ell m} \\ a_3(t,r) \frac{\partial Y_{\ell m}}{\partial \theta} \\ a_3(t,r) \frac{\partial Y_{\ell m}}{\partial \phi} \end{bmatrix}$$

It is well known that, under the angular space inversion transformation  $(\theta, \phi) \to (\pi - \theta, \pi + \phi)$ , first part of the transformation changes sign as  $(-1)^{(\ell+1)}$  termed as axial or odd part and second part changes sign as  $(-1)^{(\ell)}$  termed as polar or even part. As  $\delta A_{\mu}$  is decoupled under parity transformation, we have only focused on the axial modes which is the first part of perturbed potential. The Electromagnetic (EM) field tensor is defined in terms of the general 4-vector potential as follows:

$$F_{\mu\nu} = 2\left(\nabla_{\mu}A_{\nu} - \nabla_{\nu}A_{\mu}\right) \tag{8}$$

and generalized Maxwell's equations for nonlinear electrodynamics are represented by

<span id="page-3-0"></span>
$$\nabla_{\nu} \left( \mathcal{L}_F F^{\mu\nu} \right) = 0 \tag{9}$$

Where  $\mathcal{L}_F = \frac{\partial \mathcal{L}(F)}{\partial F}$ . Considering only background field  $(\bar{A}_{\mu})$ , non vanishing terms of EM field tensor are  $F_{\theta\phi} = -F_{\phi\theta} = q \sin \theta$  and strength (F) of the EM field becomes  $2q^2/r^4$ .

Taking into account the perturbation part  $(\delta A_{\mu})$  along with background 4-potential, non zero field tensor components are as follows:

$$F_{t\theta} = \frac{1}{\sin \theta} \frac{\partial a_0}{\partial t} \frac{\partial Y_{\ell m}}{\partial \phi}$$

$$F_{t\phi} = -\sin \theta \frac{\partial a_0}{\partial t} \frac{\partial Y_{\ell m}}{\partial \theta}$$

$$F_{r\theta} = \frac{1}{\sin \theta} \frac{\partial a_0}{\partial r} \frac{\partial Y_{\ell m}}{\partial \phi}$$

$$F_{r\phi} = -\sin \theta \frac{\partial a_0}{\partial r} \frac{\partial Y_{\ell m}}{\partial \theta}$$

$$F_{\theta\phi} = \sin \theta \left( q + \ell(\ell + 1) a_0 Y_{\ell m} \right)$$
(10)

All non zero contravariant components of EM field tensor are following:

$$F^{t\theta} = -\frac{1}{fr^2 \sin \theta} \frac{\partial a_0}{\partial t} \frac{\partial Y_{\ell m}}{\partial \phi}$$

$$F^{t\phi} = \frac{1}{fr^2 \sin \theta} \frac{\partial a_0}{\partial t} \frac{\partial Y_{\ell m}}{\partial \theta}$$

$$F^{r\theta} = \frac{f}{r^2 \sin \theta} \frac{\partial a_0}{\partial r} \frac{\partial Y_{\ell m}}{\partial \phi}$$

$$F^{r\phi} = -\frac{f}{r^2 \sin \theta} \frac{\partial a_0}{\partial r} \frac{\partial Y_{\ell m}}{\partial \theta}$$

$$F^{\theta\phi} = \frac{1}{r^4 \sin \theta} (q + \ell(\ell + 1)a_0 Y_{\ell m})$$

$$(11)$$

For the total 4-vector potential  $A_{\mu}$ , field strength (F) remains same at zeroth-order but has components in first order, which depends on all coordinates  $(t, r, \theta \text{ and } \phi)$ . At each step of our analysis, we have only considered 1st order terms in perturbation to be in linear regime.

$$F\left(\bar{A}_{\mu} + \delta A_{\mu}\right) \approx \frac{2q^2}{r^4} + \frac{4ql(l+1)a_0(t,r)Y_{lm}}{r^4}$$
 (12)

This is the crucial point to note in eletromagnetic perturbation for electrically and magnetically charged black holes in nonlinear electrodynamics, where perturbation can not alter field strength

at first order approximation. We write total field strength as  $F = \bar{F} + \delta F$  where  $\bar{F}(r) = 2q^2/r^4$  and  $\delta F(t,r,\theta,\phi) = \frac{4ql(l+1)a_0(t,r)Y_{lm}}{r^4}$ . We expand  $\mathcal{L}_F$  in the vicinity of  $\bar{F}$  using Taylor series upto first order term.  $\mathcal{L}_F \approx \bar{\mathcal{L}}_{\bar{F}} \left(\bar{F}\right) + \bar{\mathcal{L}}_{\bar{F}\bar{F}}\delta F$ . Here  $\bar{\mathcal{L}}_{\bar{F}} = \frac{d\bar{\mathcal{L}}}{d\bar{F}}, \bar{\mathcal{L}}_{\bar{F}\bar{F}} = \frac{d\bar{\mathcal{L}}_{\bar{F}}}{d\bar{F}}$ . We also define  $\bar{\mathcal{L}}_{\bar{F}}' = \frac{d\bar{\mathcal{L}}_{\bar{F}}}{dr}$ .

For any free index  $\mu$ , Eqn. 9 becomes

<span id="page-4-0"></span>
$$\frac{\partial \left(\mathcal{L}_{F}F^{\mu t}\right)}{\partial t} + \frac{1}{r^{2}} \frac{\partial \left(r^{2}\mathcal{L}_{F}F^{\mu r}\right)}{\partial r} + \frac{1}{\sin \theta} \frac{\partial \left(\sin \theta \mathcal{L}_{F}F^{\mu \theta}\right)}{\partial \theta} + \frac{\partial \left(\mathcal{L}_{F}F^{\mu \phi}\right)}{\partial \phi} = 0 \tag{13}$$

For  $\mu = \theta$  and  $\phi$ , Eqn.13 simplifies to

<span id="page-4-1"></span>
$$-\frac{\partial^2 a_0}{\partial t^2} + \frac{f}{\bar{\mathcal{L}}_{\bar{F}}} \frac{\partial \left( f \bar{\mathcal{L}}_{\bar{F}} \frac{\partial a_0}{\partial r} \right)}{\partial r} + \frac{f \ell \left( \ell + 1 \right)}{r^2} \left( 1 - \frac{4q^2 \bar{\mathcal{L}}_{\bar{F}\bar{F}}}{r^4 \bar{\mathcal{L}}_{\bar{F}}} \right) a_0 = 0 \tag{14}$$

To remove first order derivative term of  $a_0(t,r)$  from Eqn.14, we use standard tortoise coordinate $(r_*)$  transformation  $dr_* = \frac{dr}{f(r)}$  and scale the variable  $a_0(t,r)$  to  $\Psi(t,r) = \frac{a_0(t,r)}{\sqrt{\bar{\mathcal{L}}_{\bar{F}}}}$ . Now  $\Psi$  represents solution of wave Eqn.15 with an effective potential profile V(r)

<span id="page-4-2"></span>
$$\frac{\partial^2 \Psi(t, r_*)}{\partial t^2} - \frac{\partial^2 \Psi(t, r_*)}{\partial r_*^2} + \Psi(t, r_*) V(r) = 0$$
(15)

$$V(r) = f \left[ \frac{\ell(\ell+1)}{r^2} \left( 1 + \frac{4q^2 \bar{\mathcal{L}}_{\bar{F}\bar{F}}}{r^4 \bar{\mathcal{L}}_{\bar{F}}} \right) - \left( \frac{f \bar{\mathcal{L}}_{\bar{F}}^{'2} - 2\bar{\mathcal{L}}_{\bar{F}}}{4\bar{\mathcal{L}}_{\bar{F}}^2} \right) \right]$$

$$\tag{16}$$

The advantage of using the tortoise coordinate lies in the fact that the range of the coordinate now extends between  $-\infty$  to  $\infty$ , whereas in the old radial coordinate r, the physically accessible region lies only between the black hole's outer  $\operatorname{horizon}(r_h)$  and the cosmological  $\operatorname{horizon}(r_c)$ . Note also that the potential  $V(r) \to 0$  as  $r_* \to \pm \infty$ . In [53], the authors have also computed all field components and eventually calculated the potential for electromagnetic perturbation in nonlinear electrodynamics. Apart from a few typographical errors in some of the equations (for example eqns. (36)-(38)) in that paper, the final form of the potential matches with ours in the flat space limit. In Fig.1, we have examined the nature of the axial potential V(r) with radial coordinate r and compared BdS potential with Reissner-Nordström (RN-dS) potential. For (RN-dS) black hole,  $\mathcal{L}(F)$  linearly depends on field strength F which means  $\overline{\mathcal{L}}_F = \overline{\mathcal{L}}_{FF} = 0$ . Importantly, it is to be noted that the overall nature of both potentials are the same, viz. (a) V(r) is positive definite between the event and cosmological horizons, (b) V(r) has a single maxima, which increases its height with increasing  $\ell$ . But for a fixed set of parameters, height of the BdS potential is larger than the RN-dS one which indicates BdS black hole has smaller absorption coefficient than RN-dS black hole. As already mentioned, our target in this work is to solve the wave equation with proper

![](_page_4_Figure_9.jpeg)

<span id="page-4-3"></span>Figure 1: Effective potential V for BdS and RN-dS black holes for q = 0.40,  $\ell = 2$  and  $\Lambda = 0.01$ . boundary conditions for complex QN frequencies using the sixth order WKB method developed

in [55]. It is already established in the literature that sixth order WKB method is more accurate than the third order one and the former in fact gives results coinciding with those obtained from full numerical integration of the wave equation [55] for low overtones, i.e. for modes with small imaginary parts, and for all multipole numbers  $\ell \geq 1$ . The sixth order formula for a general black hole potential V(r) is given by

<span id="page-5-3"></span><span id="page-5-2"></span><span id="page-5-0"></span>
$$\frac{i(\omega^2 - V(r_0))}{\sqrt{-2V''(r_0)}} - \Lambda_2 - \Lambda_3 - \Lambda_4 - \Lambda_5 - \Lambda_6 = n + \frac{1}{2}$$
(17)

where  $V(r_0)$  is peak value of V(r),  $V^{''}(r_0) = \frac{d^2V}{dr_*^2}|_{r=r_0}$ ,  $r_0$  is the value of the radial coordinate corresponding to the maximum of the potential V(r) and n is the overtone number. In general QN frequencies  $\omega$  take the form  $\omega = \omega_R - i\omega_I$ , where, as mentioned earlier, the real part of  $\omega$  represents actual field oscillation and imaginary part corresponds to damping of the perturbation. In eqn.(17),  $\Lambda_2$  and  $\Lambda_3$  are given by [54]

$$\Lambda_{2} = \frac{1}{\sqrt{2V''(r_{0})}} \left[ \frac{1}{8} \left( \frac{V_{0}^{(4)}}{V''(r_{0})} \right) (b^{2} + \frac{1}{4}) - \frac{1}{288} \left( \frac{V_{0}^{(3)}}{V''(r_{0})} \right)^{2} (7 + 60b^{2}) \right]$$

$$\Lambda_{3} = \frac{(n + \frac{1}{2})}{2V''(r_{0})} \left[ \frac{5}{6912} \left( \frac{V_{0}^{(3)}}{V''(r_{0})} \right)^{4} (77 + 188b^{2}) - \frac{1}{384} \left( \frac{(V_{0}^{(3)})^{2}V_{0}^{(4)}}{(V''(r_{0}))^{3}} \right) (51 + 100b^{2}) \right]$$

$$+ \frac{(n + \frac{1}{2})}{2V''(r_{0})} \left[ \frac{1}{2304} \left( \frac{V_{0}^{(4)}}{V''(r_{0})} \right)^{2} (67 + 68b^{2}) + \frac{1}{288} \left( \frac{V_{0}^{(3)}V_{0}^{(5)}}{(V''(r_{0}))^{2}} \right) (19 + 28b^{2})$$

$$- \frac{1}{288} \left( \frac{V_{0}^{(6)}}{V''(r_{0})} \right) (5 + 4b^{2}) \right].$$
(19)

In the above expression  $b=n+\frac{1}{2}$ ,  $V_0^{(n)}=d^nV/dr_*^n$  at  $r=r_0$  and  $\Lambda_4$ ,  $\Lambda_5$  and  $\Lambda_6$  can be found in the Appendix of [55]. The above method also works extremely well in the eikonal limit of large  $\ell$  corresponding to large quality factors.

In Fig.2, the QNMs are plotted as a function of multipole index  $\ell$  for  $\Lambda = 0.003$ , charge q = 0.4 and overtone number n = 0. It is found that Re  $\omega$  increases linearly with  $\ell$ , while magnitude of Im  $\omega$  initially increases rapidly with  $\ell$  and later on, it saturates.

![](_page_5_Figure_6.jpeg)

<span id="page-5-1"></span>Figure 2: Variation of Re  $\omega$  and -Im  $\omega$  with multipole number  $\ell$  for  $\Lambda=0.003$ .

Utilising the master eqn. (17), we have determined the QNMs for different set of parameters in this work. One can define the quality factor (Q.F.) to look at the strength of the field oscillation over damping as follows: Q.F. =  $\frac{\text{Re}(\omega)}{2|\text{Im}(\omega)|}$ . It is well known that the quality factor is essentially a dimensionless parameter that describes how underdamped an oscillator is. In Fig.3, we have plotted the Q.F. versus the charge q and cosmological constant  $\Lambda$ . It is easy to check that field oscillation initially increases and finally decreases with q for  $\ell=2$  and n=0 but it decreases throughout the variation of  $\Lambda$ . This implies that the BdS black hole system becomes over-damped with the increase of cosmological constant. Next, we plot the variation of QN frequencies with

![](_page_6_Figure_0.jpeg)

<span id="page-6-0"></span>Figure 3: Q-Factor vs magnetic charge q and cosmological constant  $\Lambda$ .

![](_page_6_Figure_2.jpeg)

<span id="page-6-1"></span>Figure 4: Variation of  $\text{Re}(\omega)$  and  $-\text{Im}(\omega)$  vs. charge q for a fixed value of  $\Lambda=0.01$  for BdS black holes. The inset shows the same plott for RN-dS with the same values of the parameter.

respect to charge q and cosmological constant  $\Lambda$  for different multipole numbers ( $\ell$ ). Fig.4 specifically suggests the nature of QNMs as a function of q. Here for BdS, Re  $\omega$  decreases constantly with q but for RN-dS black hole (shown at the inset of the plot), it increases rapidly for the same parameter space. For Bds black hole, Im  $\omega$  declines abruptly with increasing q. On the contrary, it increases for RN-dS, which implies with smaller charge, BdS black hole is more stable than RN-dS. Whereas, Fig.5 demonstrates linear decrement in both real and imaginary part of QNMs with increasing  $\Lambda$  for all sets of multipole numbers  $\ell=1$  and 2. Nature of the response from RN-dS black hole is same as BdS but its oscillation frequency is much smaller than BdS black hole keeping the nature of damping with respect to the parameters the same. Finally, in Table [1], we have listed the numerical values of QN frequencies which are obtained using sixth order WKB approach for the parameter  $\Lambda = 0.007$  and q = 0.57. As it is well known that WKB method is accurate for  $n < \ell$ , we have tabulated the QN frequencies considering this condition. Data of Table[1] shows as  $\ell$  increases both Re  $\omega$  and Im  $\omega$  increase for a fixed overtone number (n). Another aspect of listed QNMs is that real oscillation frequency and imaginary part of the frequency representing damping are decreasing and increasing respectively with increasing overtone number n for fixed  $\ell$  values. This behaviour of QN frequencies with n and  $\ell$  is same amongst all different types of perturbations: electromagnetic, gravitation, massless and massive scalar perturbations [22]. is worth mentioning here that by computing inverse of the instability timescale which is associated with the geodesic motion, it is possible to show that in the eikonal limit, parameters of the circular null geodesics can determine the QNMs of black holes in any dimensions [56]. This is a very important and strong result since the parameters of null geodesics can throw some light on the stability of a black hole. It has also been shown to be independent of the field equations. The only assumption which went into the consideration of the authors of [56], is the fact that the black hole spacetime is static, spherically symmetric and asymptotically flat. However as a non-trivial example, they have discussed non-asymptotically flat near extremal Schwarzschild de Sitter black hole space time in this context. Therefore, the same analysis can be applied for BdS black holes in the limit of near extremal regime (Nariai or cold black holes) where either the black hole horizon

![](_page_7_Figure_0.jpeg)

Figure 5: Variation of  $Re(\omega)$  and  $-Im(\omega)$  vs  $\Lambda$  with a fixed value of magnetic charge q=0.4

<span id="page-7-0"></span>

| Multipole number | Overtone | QN frequencies using 6th order WKB |
|------------------|----------|------------------------------------|
| $\ell = 2$       | n=0      | 0.521390 - 0.084842i               |
|                  | n=1      | 0.507453 - 0.256951i               |
|                  | n=0      | 0.753028 - 0.086184i               |
| $\ell = 3$       | n=1      | 0.742394 - 0.259872i               |
|                  | n=2      | 0.721758 - 0.437509i               |
|                  | n=0      | 0.978881 - 0.086878i               |
|                  | n=1      | 0.970469 - 0.261448i               |
| $\ell = 4$       | n=2      | 0.953945 - 0.438453i               |
|                  | n=3      | 0.929943 - 0.619473i               |
|                  | n=0      | 1.202785 - 0.087246i               |
|                  | n=1      | 1.195857 - 0.262286i               |
| $\ell = 5$       | n=2      | 1.182170 - 0.438968i               |
|                  | n=3      | 1.162055 - 0.618374i               |
|                  | n=4      | 1.136057 - 0.801537i               |

<span id="page-7-1"></span>Table 1: Electromagnetic QN frequencies for the Bardeen de-Sitter black hole spacetime as a function of  $\ell$  and n for q=0.57 and  $\Lambda=0.007$ .

and the cosmological horizon coincides or the inner and outer horizon merges.

### 4 Gravitational perturbations and QNMs of the BdS black hole

It has to be mentioned here that generally there are two different categories of perturbations of black holes that are considered within the regime of general theory of relativity. In the first method, one adds a test field in a black hole background and the system is studied by solving the dynamical equation for the particular test field in the background of the black hole. The second one is to perturb the metric itself and in order to find the evolution equations, one linearises the Einstein's equations. This is the gravitational perturbation and is the most important one amongst all types of perturbations since the gravitational radiation is much stronger than strength of any external fields decaying near the black hole. It is also important because the metric perturbations gives us tools to study about the gravitational stability of a black hole. The investigation of black hole perturbations was first carried out by Regge and Wheeler [31] for the odd parity type of the spherical harmonics and was extended to the even parity type by Zerilli [57]. A brief discussion about the calculations involved in gravitational perturbation is given in the appendix. The form of the potential due to gravitational perturbation is given by

$$V(r) = f \left[ \frac{\ell(\ell+1) + r(rf')' + 2(f-1) + 2r^2(2\mathcal{L} + \Lambda)}{r^2} \right]$$
 (20)

where,  $\mathcal{L}$  denotes lagrangian of the field and  $\Lambda$  is cosmological constant.

![](_page_8_Figure_0.jpeg)

<span id="page-8-0"></span>Figure 6: Variation of gravitational potential V in Regge-Wheeler gauge with r for ` = 2, Λ = 0.003 and q = 0.40.

![](_page_8_Figure_2.jpeg)

<span id="page-8-1"></span>Figure 7: Variation of Re ω and -Im ω with multipole number ` for Λ = 0.002 and n = 0.

In Fig[.6](#page-8-0) , we have shown the nature of the effective potential V for BdS black hole with fixed values of the parameters Λ = 0.003, ` = 2 and q = 0.2. For comparison between black holes in linear and nonlinear electromagnetic field, we have studied RN-dS and BdS black holes respectively. As before, the value of the mass of the black hole is taken as unity throughout this paper. Like the electromagnetic, here V is also positive, finite which increases its height with increasing ` and almost same spatial extent for both BdS and RN-dS black hole. But height of the BdS potential is always larger than RN-dS for which total absorption cross-section of BdS black hole is always less than its counter part in linear electromagnetic field. With ` = 0, V has more than one extremum which prevents us to apply the WKB approach. Therefore, like electromagnetic perturbation, here also we will be considering ` 6= 0 modes. In Fig.[\(7\)](#page-8-1), the QNMs are plotted as a function of multipole index ` for Λ = 0.002, magnetic charge q = 0.2 and overtone number n = 0. It is found that Re ω increases linearly with ` while magnitude of Im ω initially increases rapidly with ` and later on, it saturates and becomes almost a constant. Although the behaviour of the frequencies remains similar to those of electromagnetic ones as we vary the multipole index, the rapidity with which the imaginary parts of the frequency change with ` in case of the gravitational perturbation is much higher than that of the electromagnetic case. To understand the strength of the gravitational perturbation, we plot the quality factor (Q.F.) versus cosmological constant Λ and magnetic charge q in Fig[.8](#page-9-0) . It is clear from the plot that field oscillation is almost same in a with variation of Λ making a significant difference with it's electromagnetic counterpart for q = 0.4. At the same time, variation of Q.F. with magnetic charge(q) shows us a nonlinear increment behaviour as we increase q for a fixed value of Λ = 0.002. Next, we plot QN frequencies of the BdS black hole for gravitational perturbation vs magnetic charge parameter (q) and cosmological constant (Λ) with different ` values. Fig[.9](#page-9-1) precisely suggests the nature of QNMs as a function of q. For BdS, Re ω follows non-linear relation with q keeping similarity with its linear electromagnetic counterpart(RN-dS). However, the magnitude of Im ω falls with increasing magnetic charge q. It

![](_page_9_Figure_0.jpeg)

<span id="page-9-0"></span>Figure 8: Q-factor vs parameters  $\Lambda$  and q

![](_page_9_Figure_2.jpeg)

<span id="page-9-1"></span>Figure 9: Variation of  $\text{Re}(\omega)$  and  $-\text{Im}(\omega)$  vs q, for  $\Lambda=0.002$ .

clearly shows difference in nature of dependence between BdS and RN-dS black hole. For the same set of parameters, with increasing magnetic charge (q) BdS black hole becomes unstable than RN-dS black hole.

![](_page_9_Figure_5.jpeg)

<span id="page-9-2"></span>Figure 10: Variation of  $Re(\omega)$  and  $-Im(\omega)$  vs  $\Lambda$  for q = 0.2.

Fig.10 shows Re  $\omega$  and |Im  $\omega$ | decreases steadily for increasing  $\Lambda$  for q=0.4 in both BdS and RN-dS black holes. Finally, In Table 2, we have listed the numerical values of QN frequencies with corresponding parameters considering  $n<\ell$ . Like electromagnetic class (see Table 1), tabulated QNMs indicate that as  $\ell$  increases both real and modulus of imaginary  $\omega$  increase for a fixed overtone number (n). Another feature of listed QNMs is that oscillation frequency and damping of perturbation are decreasing and increasing respectively when we increase n keeping  $\ell$  fixed. This behaviour is same irrespective of the class of perturbations.

| Multipole number | Overtone | QN frequencies using 6th order WKB |
|------------------|----------|------------------------------------|
|                  | n= 0     | 0.679040 − 0.089022i               |
| ` = 3            | n= 1     | 0.638172 − 0.274874i               |
|                  | n= 2     | 0.357253 − 0.622339i               |
|                  | n= 0     | 0.891988 − 0.089235i               |
| ` = 4            | n= 1     | 0.879436 − 0.271288i               |
|                  | n= 2     | 0.779455 − 0.472025i               |
|                  | n= 3     | 0.363485 − 0.966099i               |
|                  | n= 0     | 1.098212 − 0.092047i               |
|                  | n= 1     | 1.057292 − 0.308499i               |
| ` = 5            | n= 2     | 0.785209 − 0.807262i               |
|                  | n= 3     | 0.487847 − 2.307081i               |
|                  | n= 4     | 0.409467 − 4.815479i               |

<span id="page-10-0"></span>Table 2: The list of gravitational QNMs in the Bardeen de-Sitter black hole space time as a function of ` and n for q = 0.60 and Λ = 0.003.

### 5 Dynamics of perturbation

Our initial motivation was to study black hole stability under an external perturbation. C. V. Vishveshwara was the first person to realize that we may observe a solitary black hole by observation of scattering of radiation from the black hole, provided the black hole left its fingerprint on the scattered wave [\[58\]](#page-20-6). Realising this, he started pelting the black hole with Gaussian wave packets and found that the black hole responds by ringing in a very unique decay mode: the lowest damped one of the black hole QNMs. Following this, here we will demonstrate a complete evolution picture of the BdS space time from a single master equation (see Eqn. [43](#page-18-3) discussed in the appendix). This is a wave equation with a schr¨odinger like form.

<span id="page-10-1"></span>
$$\frac{\partial^2 \psi}{\partial t^2} - \frac{\partial^2 \psi}{\partial r_*^2} + V\psi = 0 \tag{21}$$

We have used finite difference method to numerically integrate this wave equation[\(21\)](#page-10-1). As a boundary condition we have Eqn. [\(22\)](#page-10-2) which describes asymptotic behaviour with pure ingoing and outgoing waves at r<sup>∗</sup> → ∓∞ respectively. We assume a solution of Eqn.[\(21\)](#page-10-1) with oscillatory factor e <sup>−</sup>iωt in time.

<span id="page-10-2"></span>
$$\lim_{r_* \to \pm \infty} \psi e^{\mp i\omega r_*} = 1 \tag{22}$$

To give the first external "kick" in the field we use two Gaussian waves [\(23\)](#page-10-3) and [\(24\)](#page-10-4) as initial conditions for the second order differential equation[\(21\)](#page-10-1):

<span id="page-10-3"></span>
$$\psi(r_*,0) = a_1 e^{-\sigma_1(r_* - \mu)^2},\tag{23}$$

<span id="page-10-4"></span>
$$\frac{\partial \psi(r_*, 0)}{\partial t} = a_2 e^{-\sigma_2(r_* - \mu)^2},\tag{24}$$

![](_page_11_Figure_0.jpeg)

<span id="page-11-0"></span>Figure 11: (x-t) plane for Integration scheme.

![](_page_11_Figure_2.jpeg)

<span id="page-11-1"></span>Figure 12: Variation of  $\psi$  in linear scale with t for q = 0.2,  $\Lambda = 0.0005$ .

where  $\sigma_1$  and  $\sigma_2$  represents width of the Gaussian packet and  $\mu$  denotes position of the peak of the curves. It is found that broad Gaussian waves can not excite the background sufficiently to observe the dynamical features [60]. On the other hand, using sharp localised packet, one can get maximum number of extrema in field oscillation. First we have discretized the domain of integration  $(r_* - t)$  plane by using

$$x_i = x_0 + i\Delta x, i = 0, 1, 2, 3...$$
 (25)  
 $t_j = j\Delta t, j = 0, 1, 2, 3...$  (26)

$$t_j = j\Delta t, j = 0, 1, 2, 3...$$
 (26)

Here x is same as  $r_*$ .  $\Delta t$  and  $\Delta x$  are grid size of y axis and x axis respectively.  $x_0$  is a point on boundary of x axis. To determine the perturbation  $\psi$  in advanced time, we use Taylor theorem in Eqn.(21) and get a discretized version of it:

$$\psi_F = \frac{\Delta t^2}{\Delta x^2} (\psi_C - 2\psi_E + \psi_A) + (2 - \Delta t^2 V_E) \psi_E - \psi_D, \tag{27}$$

where, in general, F, C, E, A, D points are defined as :  $\psi_F = \psi(x_i, t_{j+1}), \ \psi_C = \psi(x_{i+1}, t_j),$  $\psi_E = \psi(x_i, t_j), \ \psi_A = \psi(x_{i-1}, t_j), \ \psi_D = \psi(x_i, t_{j-1}), \ V_E = V(x_i, t_j).$ 

![](_page_12_Figure_0.jpeg)

<span id="page-12-0"></span>Figure 13: Variation of  $\psi$  in log scale with t for q=0.2 and  $\Lambda=0.0005$ .

With the initial conditions Eqn (23) and Eqn(24), we also specify all values of  $\psi$  at t=0 and  $t=\Delta t$  grid line of Fig.11 . To determine the perturbation in one step advance (in time) at the point F, we need to know value of the perturbation in four neighbourhood points of F, which are represented by A, C, D and E. By applying this procedure repeatedly, one can determine the dynamics of perturbation over a complete domain. During this numerical integration scheme, one dimensional version of Courant-Friedrichs-Lewy (CFL) condition is satisfied which is a necessary condition for convergence of an explicit finite difference method of a hyperbolic PDE. Other parameters on which convergence depends are discussed in [52].

![](_page_12_Figure_3.jpeg)

<span id="page-12-1"></span>Figure 14: Variation in power spectrum  $|G(\omega)|^2$  with  $\omega$  for q=0.2 and  $\Lambda=0.0005$ .

In Fig.12 we show the evolution of  $\psi$  for two integral spin  $(s=1 \text{ and } s=2 \text{ representing electromagnetic and gravitational perturbations respectively) perturbations with different <math>\ell$  values. It is quiet evident from plots that one of our motivations of studying stability feature of the scattered wave is fulfilled as it shows characteristic decay modes in late time. On the same time Fig.13 exhibits evolution of perturbation in log scale. It is clear from the applied numerical scheme that to find late time dynamics of  $\psi$ , we need initial conditions (23), (24) on more number of grid points. As our integration domain is limited between finite values of  $-r_*$  and  $r_*$  because of finite value of cosmological horizon  $r_c$ , we were unable to generate numerical values of  $\psi$  at very late time and therefore any power law tail is absent in the dynamics. In real world, it is well known that  $\Lambda$  is very small, of the order of  $10^{-52}$ . Use of this small value of  $\Lambda$  in numerical computation has its own challenges. So we choose a small, finite value for  $\Lambda = 0.0005$  here, which, of course is not as small as the cosmological constant itself. To capture feature of small value of cosmological constant, one can decrease  $\Lambda$  and recalculate it further. Using Eqn.(5), it is found that as  $\Lambda \to 0$ ,  $r_c \to \infty$ . Therefore numerically domain of integration also becomes large enough and finally one can get very late time dynamics.

Fig.14 is a power spectrum of Fourier transformation for the same perturbing wave of Fig.12. Here we find independently oscillation frequency of perturbing wave from the frequency  $\omega_0$  corresponding to maximum of  $|G(\omega)|^2$ . In s=1 and s=2 condition, maximum power containing frequencies are  $0.9617\pm0.1068$  and  $0.7479\pm0.1068$  respectively. Scattered waves with these frequencies are dominant in Fig.12. Although there is no way to find specific overtone no(n) of oscillation

from the variation of ψ but in late time it is expected that system will oscillate in fundamental mode [\[59\]](#page-20-9). By that time all higher modes will be damped out because of their large damping factors in frequencies (Table [1](#page-7-1) [-2\)](#page-10-0). With s = 1 and s = 2, oscillation frequencies (ω0) from the WKB method are 1.0398 and 0.8151 for ` = 4 and n = 0 respectively. These oscillation frequencies are in good agreement with frequencies obtained from Fourier transformation technique.

### 6 Greybody factors and Absorption coefficients

#### 6.1 Nature of the greybody factor

In this subsection we will discuss Reflection coefficients R(ω) and Transmission coefficients T(ω) for different parameter spaces as well as in different type of perturbations. In [\[21\]](#page-19-8) coefficients for scalar type perturbation is discussed for Bds black holes in detail. Here, in order to fill the gap in the present literature, we will concentrate on the electromagnetic and gravitational perturbation part for this black hole. The use of WKB method to compute reflection and transmission coefficients(greybody factors) are not new. It has already been employed in various scenarios [\[61\]](#page-20-10)-[\[64\]](#page-20-11), which includes the calculation of greybody factors of black holes in braneworld models, in the context of calculations of these coefficients for wormholes. By another analytical approach which was originally proposed by Unruh [\[65\]](#page-20-12), greybody factors can also be calculated [\[66\]](#page-20-13). Here we have already seen that for both s = 1 and s = 2, finite potential barrier (Fig[.1](#page-4-3) , Fig[.6](#page-8-0) ) exists between cosmological horizon(rc) and event horizon(rh). Now, any wave travelling past the cosmological horizon will face these finite positive potential barriers as obstacles. Therefore some part of the wave will be reflected back towards r<sup>c</sup> and some parts will be transmitted towards rh. Following [\[21\]](#page-19-8), we can represent them as

$$\psi(r_*) = T(\omega)e^{-i\omega r_*}; r_* \to -\infty$$
 (28)

$$\psi(r_*) = e^{-i\omega r_*} + R(\omega)e^{i\omega r_*}; r_* \to +\infty$$
 (29)

In general the reflection and transmission coefficients are functions of oscillation frequency (ω) of the wave. The reflection coefficient R(ω) in the WKB approximation is defined as,

$$R(\omega) = (1 + e^{-2\pi i\alpha})^{-\frac{1}{2}},\tag{30}$$

where α is given by

$$\alpha = \frac{i(\omega^2 - V(r_0))}{\sqrt{-2V''(r_0)}} - \Lambda_2 - \Lambda_3,$$
(31)

and expression for Λ2, Λ<sup>3</sup> can be found out from Eqns.[\(18\)](#page-5-2) and [\(19\)](#page-5-3) respectively. Conservation of probability requires:

<span id="page-13-0"></span>
$$|R(\omega)|^2 + |T(\omega)|^2 = 1$$
 (32)

Finally, the greybody factor is defined as

$$\gamma_{\ell} = |T(\omega)|^2 \tag{33}$$

Depending on the frequency and height of the potential barrier, there may be different cases which can arise: when ω <sup>2</sup> V (r0), i.e. when a wave with frequency larger than the height of the barrier comes, it will not be reflected by the barrier classically. In this case, one should expect the reflection coefficient to be close to zero, because the frequency of the wave is large enough to cross the barrier. Therefore we expect that under this conditions, |T| <sup>2</sup> will be close to 1. When ω <sup>2</sup> V (r0), i.e. square of the frequency is very small compared to barrier height, wave will be reflected back from the barrier and some part may be transmitted through the barrier by tunnelling effect depending on the values of ω and V (r0). We should get exactly opposite behaviour of R(ω) and T(ω) compared to previous case. In this case, the WKB method does not have very high accuracy. When ω <sup>2</sup> ≈ V (r0), we have to take help of numerical techniques to understand the nature of R(ω) and T(ω). Here we can apply WKB approximation method because of the small distance between the turning points.

Fig[.15](#page-14-0) shows variation of |R(ω)| <sup>2</sup> with ω for different class of perturbations with different ` values. In electromagnetic perturbations, i.e.(s = 1), it is almost one for low frequency and for high frequency it is close to zero. For a fixed frequency, |R| 2 is larger for multipole number ` = 4 than ` = 3. It can be explained easily from the dependency of effective potential V (r) on `. Gravitational perturbation (s = 2) has also same nature and features like that of the electromagnetic type (s = 1). On the contrary Fig[.16](#page-14-1) shows variation of |T(ω)| <sup>2</sup> with ω for both (s = 1) and (s = 2) type. Following Eqn.[\(32\)](#page-13-0), it shows exactly opposite nature to Fig[.15](#page-14-0) for both the limits.

![](_page_14_Figure_1.jpeg)

<span id="page-14-0"></span>Figure 15: |R| <sup>2</sup> vs ω for q = 0.4, Λ = 0.02.

![](_page_14_Figure_3.jpeg)

<span id="page-14-1"></span>Figure 16: |T| <sup>2</sup> vs ω for q = 0.4, Λ = 0.02.

Next we study the behaviour of |R(ω)| <sup>2</sup> with ω by varying black hole magnetic charge q and keeping other parameters fixed in Fig[.17](#page-14-2) . Larger q values decreases reflection coefficient compared to smaller q values for s = 1. Although for s = 2, response of |R(ω)| <sup>2</sup> under different q is much larger than s = 1. In gravitational perturbation, for higher charge parameter, reflection coefficient is also larger which is exactly opposite to electromagnetic perturbation. This nature is prominent from the potential behaviour of different class of perturbation under variation of charge parameter. Fig[.18](#page-15-0) shows |T(ω)| <sup>2</sup> with ω with the same parameter values.

![](_page_14_Figure_6.jpeg)

<span id="page-14-2"></span>Figure 17: |R| <sup>2</sup> vs ω with ` = 3 and Λ = 0.02 for different magnetic charge (q) values.

![](_page_15_Figure_0.jpeg)

<span id="page-15-0"></span>Figure 18: |T| <sup>2</sup> vs ω with ` = 3 and Λ = 0.02 for different magnetic charge (q) values.

Next we plot |R(ω)| <sup>2</sup> vs ω by varying the cosmological constant Λ in Fig[.19](#page-15-1) . For s = 1, response of |R(ω)| <sup>2</sup> under different q is much larger than s = 2. With increasing Λ for both s = 1 and s = 2, |R(ω)| <sup>2</sup> value decreases. Therefore in space time with larger cosmological constant, black holes can less scatter the incoming waves. Fig[.20](#page-15-2) shows the variation of |T(ω)| <sup>2</sup> with ω with the same set of parameter values following Eqn. [\(32\)](#page-13-0).

![](_page_15_Figure_3.jpeg)

<span id="page-15-1"></span>Figure 19: |R| <sup>2</sup> vs ω for ` = 3 and q = 0.2 for different Λ values.

![](_page_15_Figure_5.jpeg)

<span id="page-15-2"></span>Figure 20: |T| <sup>2</sup> vs ω for ` = 3 and q = 0.2 for different Λ values.

#### 6.2 Absorption Cross-section

In this subsection we will discuss partial and total absorption cross section in the context of electromagnetic and gravitational perturbation for different parameter spaces in the BdS background. Partial  $(\sigma_{\ell})$  and total absorption cross sections  $(\sigma)$  are defined respectively as:

$$\sigma_{\ell} = \frac{\pi(2\ell+1)}{\omega^2} |T_{\ell}(\omega)|^2, \tag{34}$$

$$\sigma = \sum_{\ell} \frac{\pi(2\ell+1)}{\omega^2} |T_{\ell}(\omega)|^2. \tag{35}$$

In Fig.21, variation of  $\sigma$  are plotted with different q and  $\Lambda$  values where individual peak represents  $\sigma_{\ell}$ . For both s=1 and s=2, Total absorption cross sections have similar feature.

![](_page_16_Figure_4.jpeg)

<span id="page-16-0"></span>Figure 21: Total absorption cross section( $\sigma$ ) vs  $\omega$  for q=0.4 and  $\Lambda=0.002$ 

Variation of  $\sigma$  in Fig.21 can be classified into three distinct regions, the first region consists of a growing phase which is the signature of increasing  $|T(\omega)|$  with  $\omega$ . The second region shows oscillations in  $\sigma$  which comes considering different  $\ell$  modes. In this particular example, we have added upto  $\ell=8$  modes to determine  $\sigma$ . The last part is a power law fall-off. The reason behind this fall-off is following: after certain critical frequency  $(\omega_0)$ , the transmission coefficient attains maximum value to 1. Afterwards, with further increase in  $\omega$ ,  $\sigma$  becomes proportional to  $\frac{1}{\omega^2}$  irrespective of the type of the perturbation or the values of the parameters of the black hole space-time. The electromagnetic (s=1) and the gravitational (s=2) part shows two different branches which merges on top of each other in the fall-off region. For a fixed frequency, absorption cross section is always larger for gravitational perturbation w.r.t electromagnetic one.

### 7 Summary and Conclusion

In this paper, we have focused on two most important types of black hole perturbations: electromagnetic and gravitational, for a regular BdS black hole. We have used sixth order WKB approximation method to compute the QN frequencies of the BdS black hole under these perturbations and found out the response of the black hole to these perturbations by varying different parameters of the space-time. It is easy to see that from one type to another type of perturbation, only the potential profile changes in the Schrödinger-like wave equations, while keeping forms of all the relevant equations intact. We studied how the frequencies vary as a function of multipole number  $(\ell)$  as well as with the parameters like the cosmological constant  $(\Lambda)$ , magnetic charge (q) and overtone number (n). As the multipole number  $(\ell)$  increases, both Re  $(\omega)$  and -Im  $(\omega)$ increase for a fixed overtone number (n). The real oscillation frequency and imaginary part of the frequency representing damping are decreasing and increasing respectively with increasing overtone number n for fixed  $\ell$  values for the axial EM perturbations. It was observed that the real part of the QN frequency increases monotonically with the multipole number whereas the imaginary part at the beginning starts to increase but then it saturates after reaching for a certain  $\ell$  value. While for the imaginary part of the gravitational QN frequency, the frequency initially increases and then falls down before finally saturation occurs. This behaviour of imaginary part being constant with the variation of multipole number is a common feature of both the electromagnetic as well as gravitational perturbations, although the rapidity with which the imaginary part of the frequency increases is more in the case of electromagnetic one as compared with gravitational perturbations. We have also conducted a study to find out the Q-factor of the BdS black hole system and found that through Q-factor one can differentiate between electromagnetic and gravitational perturbation. The Q-factor increases rapidly with charge q and falls down after a critical value of the charge, while it decreases slightly with the increase of  $\Lambda$  for electromagnetic perturbations. It increases non-linearly with q and decreases very slowly with  $\Lambda$  for gravitational perturbation. In both the cases of electromagnetic and gravitational perturbations, the negative imaginary part shows similar behaviour with increasing q, namely, they decrease with an increase in the magnetic charge. However, for the real part, although it decreases with charge for EM perturbations, opposite behaviour is found for the gravitational perturbations. In all these cases, we did a comparative study with respect to the RN-dS background also and showed the effect of non-linear electrodynamics on the nature of QN frequencies when studied with respect to different parameters. We have further studied the dynamics of the perturbations using a standardised numerical integration method. Finally, we investigate the reflection and transmission coefficients from the BdS black hole due to electromagnetic and gravitational perturbations. In both the cases, behaviour of the greybody factor were studied by varying the black hole parameters. The total absorption cross section for different multipole values (upto  $\ell=8$ ) was studied.

For future directions, it would be interesting to study whether isospectrality of the QN spectrum holds in BdS spacetime or not. It is already known that both the axial and polar perturbations (electromagnetic as well as gravitational) gives rise to same QN frequencies. The well known example being the Reissner-Nordström black hole arising out of Einstein's general theory of relativity coupled to Maxwell's electrodynamics. However, to our knowledge, no such works in case of regular black holes in de Sitter space time exist. It would therefore be interesting to study the isospectrality of different types of perturbations in regular black holes in de Sitter space. Another important area of study would be to look at the circular null geodesics of the near extremal BdS black holes and find out whether there can be any relation between the Lyapunov exponents and the QNMs of the BdS background. Finally we would like to mention that, although many works have been done on the electromagnetic and gravitational perturbations of black holes in the regime of Einstein's general theory of relativity, not many examples are present in the context of regular black holes. Particularly, the stability and QN properties of regular black holes in de Sitter universe remains a very less studied area in the literature so far. We believe that this work will fill the gap.

# A Appendix: The gravitational perturbation

In this appendix we will briefly discuss about the gravitational perturbation in general. The spherically symmetric, static background metric is represented by  $g^0_{\mu\nu}$  and the small perturbation to the background metric is denoted by  $h_{\mu\nu}$ . In order to perform the calculation to linearise the Einstein equation, we follow  $|h_{\mu\nu}| \ll 1$ . Then  $R_{\mu\nu}$  is evaluated from  $g^0_{\mu\nu}$  and  $R_{\mu\nu} + \delta R \mu\nu$  from  $g_{\mu\nu} = g^0_{\mu\nu} + h_{\mu\nu}$ .

$$\delta R_{\mu\nu} = \delta \Gamma^{\alpha}_{\mu\alpha;\nu} - \delta \Gamma^{\alpha}_{\mu\nu;\alpha} \tag{36}$$

where

$$\delta\Gamma^{k}_{\ \mu\nu} = \frac{1}{2}g^{k\alpha}(h_{\alpha\nu;\mu} + h_{\alpha\mu;\nu} - h_{\mu\nu;\alpha}) \tag{37}$$

Now using Regge-Wheeler gauge for Axial type perturbation, the canonical form for the perturbation takes [27, 31]

$$h_{\mu\nu} = \sum_{\ell=0}^{\infty} \sum_{m=-\ell}^{\ell} \begin{pmatrix} 0 & 0 & -h_0(t,r) \frac{1}{\sin\theta} \frac{\partial Y_{lm}}{\partial \phi} & h_0(t,r) \sin\theta \frac{\partial Y_{lm}}{\partial \theta} \\ * & 0 & -h_1(t,r) \frac{1}{\sin\theta} \frac{\partial Y_{lm}}{\partial \phi} & h_1(t,r) \sin\theta \frac{\partial Y_{lm}}{\partial \theta} \\ * & * & 0 & 0 \\ * & * & * & 0 \end{pmatrix}$$

where, \* marked components of the metric are determined by symmetry property of  $h_{\mu\nu}$ . Now we substitute the total metric  $g_{\mu\nu}$  to the left side of Eqn.(38) and calculate right hand side using Eqn.(6). Here we have taken into account the perturbation in the energy–momentum tensor and get linearized Einstein's equation.

<span id="page-17-0"></span>
$$G_{\mu\nu} + \Lambda g_{\mu\nu} = 2\left(\frac{\partial \mathcal{L}(F)}{\partial F} F_{\mu\lambda} F_{\nu}^{\lambda} - g_{\mu\nu} \mathcal{L}(F)\right)$$
(38)

We get coupled second order partial differential equations from  $r\phi$ ,  $\theta\phi$  and  $t\phi$  components of Einstein's equation as Eqn.(39), (40) and (41) respectively. These equations are generalised equations for evolution of axial gravitational perturbation in Regge-Wheeler gauge. They are derived without any loss of generality.

<span id="page-18-4"></span>
$$\left(\frac{\partial^2 h_1}{\partial t^2} - \frac{\partial^2 h_0}{\partial t \partial r} + \frac{2}{r} \frac{\partial h_0}{\partial t}\right) + \frac{f h_1}{r^2} \left(K + 2r^2 (2\mathcal{L} + \Lambda) + r \left(f' + (rf')'\right)\right) = 0$$
(39)

$$\frac{\partial h_0}{\partial t} - f \frac{\partial (h_1 f)}{\partial r} = 0 \tag{40}$$

$$\left(\frac{\partial^2 h_0}{\partial r^2} - \frac{\partial^2 h_1}{\partial t \partial r} - \frac{2}{r} \frac{\partial h_1}{\partial t}\right) - \frac{h_0}{fr^2} \left(K + 2r^2 (2\mathcal{L} + \Lambda) + 2f + r \left(f' + (rf')'\right)\right) = 0$$
(41)

Here  $K = (\ell - 1)(\ell + 2)$ . Next, as a standard method, one defines

$$Q(t,r) = \frac{f(r)h_1(t,r)}{r},\tag{42}$$

and after substituting  $\frac{\partial h_0(t,r)}{\partial t}$  from Eqn. (40) to Eqn. (39), we get the Schrödinger-like equation and the generalized effective potential for the gravitational perturbation, which is denoted by V.

<span id="page-18-3"></span>
$$\frac{\partial^2 Q(t, r_*)}{\partial t^2} - \frac{\partial^2 Q(t, r_*)}{\partial r_*^2} + Q(t, r_*)V(r) = 0, \tag{43}$$

where,

<span id="page-18-5"></span>
$$V(r) = f \left[ \frac{\ell(\ell+1) + r(rf')' + 2(f-1) + 2r^2(2\mathcal{L} + \Lambda)}{r^2} \right]$$
(44)

Here 'denotes derivative with respect to the radial coordinate r. In [67], Eqn. (39), (40) and (41) are derived for asymptotically flat space time. They are same as our set of equations and finally the effective potential due to gravitational perturbation turns out to be also same as was found in Eqn.(44) in the limit  $\Lambda=0$ . However, there is a difference in numerical factor (coefficint of  $\mathcal{L}$ ) in the effective potential, which is an artefact of the two different coefficients of  $\mathcal{L}$  in our (1) compared to the one used in [67].

#### Acknowledgement

SD would like to thank Nilanjandev Bhaumik, Sambrito Ghatak, Ranjini Mandal and Andrea Maselli for discussions on the numerical solution of PDE, CFL condition and technique of computing first order perturbations in the domain of General Relativity.

#### References

- <span id="page-18-0"></span>[1] Bardeen J M 1968 Proceedings of GR5 (Tbilisi) 174
- <span id="page-18-1"></span>[2] Ayón-Beato E and Garcia A 2000 Phys. Lett. B493 149
- <span id="page-18-2"></span>[3] Ayón-Beato and García A 1998 Phys. Rev. Lett. 80 5056
- [4] Bronnikov K A 2001 Phys. Rev. **D63** 044005
- [5] Hayward S A 2006 Phys. Rev. Lett. 96 031103
- [6] Dymnikova I 2004 Class. Quant. Grav. 21 4417
- [7] Cataldo M and Garcia A, 2000 Phys. Rev. **D** 61 084003
- [8] Bronnikov K A and Fabris J A 2006 Phys. Rev. Lett. 96 251101
- [9] Berej W, Matyjasek J, Tryniecki D and Woronowicz M 2006 Gen. Relativ. Gravit. 38 885
- [10] Ghosh S G and Maharaj S D 2015 Eur. Phys. J. C 75 7
- [11] Burinskii A and Hildebrandt S R 2002 Phys. Rev. D 65 104017

- [12] Nam C H 2018 Gen. Rel. Grav. 50 57
- <span id="page-19-0"></span>[13] Toshmatov B, Stuchl´ık Z and Ahmedov B 2017 Phys.Rev. D95 084037
- <span id="page-19-1"></span>[14] Moreno C and Sarbach O 2003 Phys. Rev. D67 024028
- <span id="page-19-2"></span>[15] Toshmatov B, Bambi C, Ahmedov B, Stuchl´ık Z and Schee J 2017 Phys.Rev. D96 064028
- <span id="page-19-3"></span>[16] Toshmatov B, Stuchl´ık Z, Schee J and Ahmedov B 2018 Phys.Rev. D97 084058
- <span id="page-19-4"></span>[17] Flachi A and Lemos J 2013 Phys. Rev. D87 024034
- <span id="page-19-5"></span>[18] Fernando S and Correa J 2012 Phys. Rev. D86 64039
- <span id="page-19-6"></span>[19] Man J and Cheng H 2014 Gen. Rel. Grav. 46 1559
- <span id="page-19-7"></span>[20] Zhou S, Chen J and Wang Y 2012 Int. Jour. Mod. Phys. D21 1250077
- <span id="page-19-8"></span>[21] Fernando S, 2017 Int. J. Mod. Phys. D26 1750071
- <span id="page-19-9"></span>[22] Wahlang W, Jeena P A and Chakrabarti S 2017 Int. J. Mod. Phys. D26 1750160
- <span id="page-19-10"></span>[23] Perlmutter S etal 1997 Astrophys. J. 483 565
- <span id="page-19-11"></span>[24] Riess A G et al. 1998 Astron. J. 116 1009
- <span id="page-19-12"></span>[25] Tegmark M et al. 2004 Phys. Rev. D69 103501
- <span id="page-19-13"></span>[26] Kokkotas K D and Schmidt B G 1999 Living Rev. Rel. 2 2
- <span id="page-19-14"></span>[27] Nollert H-P 1999 Class. Quantum Grav. 16 R159
- <span id="page-19-15"></span>[28] Berti E, Cardoso V and Starinets A O 2009 Class.Quant.Grav. 26 163001
- <span id="page-19-16"></span>[29] Konoplya R A and Zhidenko A 2011 Rev.Mod.Phys. 83 793-836
- <span id="page-19-17"></span>[30] Anninos P, Hobill D, Seidel E, Smarr L and Suen W-M 1993 Phys. Rev. Lett. 71, 2851
- <span id="page-19-26"></span>[31] Regge T and Wheeler J A 1957 Phys. Rev. 108 1063
- <span id="page-19-18"></span>[32] Birmingham D, Sachs I and Solodukhin S N 2002 Phys. Rev. Lett. 88 151301
- <span id="page-19-19"></span>[33] Birmingham D, Sachs I and Solodukhin S N 2003 Phys. Rev. D67 104026
- <span id="page-19-20"></span>[34] Horowitz G T and Hubeny V E 2000 Phys. Rev. D62 024027; Konoplya R A 2002 Phys. Rev. D66 044009
- <span id="page-19-21"></span>[35] Cardoso V and Lemos J P S 2001 Phys. Rev. D63 124015
- <span id="page-19-22"></span>[36] Hod S 1998 Phys. Rev. Lett. 81 4293
- <span id="page-19-23"></span>[37] Motl L and Neitzke A 2003 Adv. Theor. Math. Phys. 7 307
- <span id="page-19-24"></span>[38] Maggiore M 2008 Phys.Rev.Lett. 100 141301
- [39] Strominger A 2001 JHEP 0110 034
- [40] Strominger A 2001 JHEP 0111 049
- [41] Abdalla E, Castello-Branco K H C and Lima-Santos A 2002 Phys.Rev. D66 104018
- <span id="page-19-25"></span>[42] Konoplya R A 2003 Phys. Rev. D68 124017
- [43] Konoplya R A and Zhidenko A 2004 JHEP 06 037;
- [44] Zhidenko A 2004 Class. Quant. Grav. 21 273
- [45] Cardoso V and Lemos J P S 2003 Phys. Rev. D67 084020
- [46] Molina C 2003 Phys. Rev. D68 064007

- [47] Lopez-Ortega A 2006 Gen. Rel. Grav. 38 1565
- [48] Lopez-Ortega A 2006 Gen. Rel. Grav. 38 743
- [49] Lopez-Ortega A 2007 Gen. Rel. Grav. 39 1011
- [50] Lopez-Ortega A 2008 Gen. Rel. Grav. 40 1379
- <span id="page-20-0"></span>[51] Smirnov A A 2005 Class. Quant. Grav 22 4021
- <span id="page-20-8"></span>[52] Molina C, Pavan A B, Medina Torrej´on T E 2016 Phys. Rev D93 124068
- <span id="page-20-1"></span>[53] Toshmatov B, Stuchlik Z, Schee J. and Ahmedov B. 2018 Phys. Rev. D97 084058
- <span id="page-20-3"></span>[54] Iyer S and Will C M 1987 Phys. Rev D35 3621
- <span id="page-20-2"></span>[55] Konoplya R A 2003 Phys. Rev.D68 024018
- <span id="page-20-4"></span>[56] Cardoso V, Berti E, Witek H, Zanchin V T 2009 Phys.Rev. D79 064016
- <span id="page-20-5"></span>[57] Zerilli F J 1970 Phys. Rev. Lett. 24 737
- <span id="page-20-6"></span>[58] Vishveshwara C V 1970 Nature 227 936
- <span id="page-20-9"></span>[59] Abrahams, Andrew and Bernstein, David and Hobill, David and Seidel, Edward and Smarr, Larry, 1992 Phys. Rev. D 45 3544
- <span id="page-20-7"></span>[60] Andersson N 1999 J. Astrophys. Astr. 20 269
- <span id="page-20-10"></span>[61] Grain J and Barrau A 2006 Nucl.Phys. B 742 253
- [62] Toshmatov B, Stuchlik Z, Schee J and Ahmedov B 2016 Phys. Rev. D93 124017
- [63] Konoplya R A and Zhidenko A 2010 Phys. Rev.D81 124036
- <span id="page-20-11"></span>[64] Nazir S and Faridi M A 2017 arXiv:1707.00515v1
- <span id="page-20-12"></span>[65] Unruh, W. G. 1976 Phys. Rev. D 14 3251
- <span id="page-20-13"></span>[66] Sporea, Ciprian A. and Borowiec, Andrzej 2016 Int. J. Mod. Phys. D25 1650043
- <span id="page-20-14"></span>[67] Toshmatov B, and Stuchik Z, Ahmedov B. and Malafarina D. 2019 Phys. Rev. D99 064043