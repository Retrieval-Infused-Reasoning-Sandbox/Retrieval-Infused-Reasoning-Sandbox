### Skip to main content

Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.

#### Advertisement

### Advertisement Nature Photonics

- View all journals
- Qsearch
- Log in
- Content Explore content
- About the journal
- Publish with us >
- Subscribe
- Sign up for alerts
- RSS feed
- 1. nature >
- 2. nature photonics >
- 3. review articles >
- 4. article
- <span id="page-0-0"></span>Review Article
- Published: 30 November 2017

# Non-reciprocal photonics based on time modulation

- <u>Dimitrios L. Sounas</u> &
- Andrea Alù 1

Nature Photonics volume 11, pages 774–783 (2017)Cite this article

- 22k Accesses
- 865 Citations
- 22 Altmetric
- Metrics details

# **Subjects**

- [Nanophotonics and plasmonics](file:///subjects/nanophotonics-and-plasmonics) •
- [Optics and photonics](file:///subjects/optics-and-photonics) •

# **Abstract**

Reciprocity is a fundamental principle in optics, requiring that the response of a transmission channel is symmetric when source and observation points are interchanged. It is of major significance because it poses fundamental constraints on the way we process optical signals. Non-reciprocal devices, which break this symmetry, have become fundamental in photonic systems. Today they require magnetic materials that are bulky, costly and cannot be integrated. This is in stark contrast with most photonic devices, including sources, modulators, switches, waveguides, interconnects and antennas, which may be realized at the nanoscale. Here, we review recent progress and opportunities offered by temporal modulation to break reciprocity, revealing its potential for compact, low-energy, integrated non-reciprocal devices, and discuss the future of this exciting research field.

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41566-017-0051-x) [Buy or subscribe](#page-1-0)

This is a preview of subscription content, [access via your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41566-017-0051-x)

# <span id="page-1-0"></span>**Access options**

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41566-017-0051-x)

# Access Nature and 54 other Nature Portfolio journals

Get Nature+, our best-value online-access subscription

27,99 € / 30 days cancel any time

[Learn more](https://shop.nature.com/products/plus/?region=ROW)

# Buy this article

- Purchase on SpringerLink
- Instant access to full article PDF

[Buy now](file://link.springer.com/article/10.1038/s41566-017-0051-x?utm_source=nature&utm_medium=referral&utm_campaign=buyArticle)

# Subscription info for Chinese customers

We have a dedicated website for our Chinese customers. Please go to [naturechina.com](http://www.naturechina.com/subscribe?utm_source=nature) to subscribe to this journal.

[Go to naturechina.com](http://www.naturechina.com/subscribe?utm_source=nature)

Prices may be subject to local taxes which are calculated during checkout

### **Additional access options:**

- [Log in](https://idp.nature.com/authorize/natureuser?client_id=grover&redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41566-017-0051-x) •
- [Learn about institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/license-options) •
- [Read our FAQs](https://support.nature.com/en/support/home) •
- [Contact customer support](https://www.springernature.com/gp/contact) •

### **Fig. 1: Non-reciprocal devices based on travelling-wave modulation.**

- **Fig. 2: Non-reciprocal devices based on angular momentum biasing.**
- **Fig. 3: Non-reciprocal devices based on direct photonic transitions.**
- **Fig. 4: Non-reciprocal devices based on optomechanical effects.**
- **Fig. 5: Topological insulators for light.**

### **Similar content being viewed by others**

![](_page_3_Figure_5.jpeg)

**[Passive bias-free non-reciprocal metasurfaces based on](https://www.nature.com/articles/s41566-023-01333-7?fromPaywallRec=true) [thermally nonlinear quasi-bound states in the continuum](https://www.nature.com/articles/s41566-023-01333-7?fromPaywallRec=true)** 

Article 30 November 2023

![](_page_3_Figure_8.jpeg)

**[All-optical nonreciprocity due to valley polarization](https://www.nature.com/articles/s41467-021-24138-0?fromPaywallRec=true) [pumping in transition metal dichalcogenides](https://www.nature.com/articles/s41467-021-24138-0?fromPaywallRec=true)** 

Article Open access 18 June 2021

![](_page_3_Picture_11.jpeg)

## **[Self-induced optical non-reciprocity](https://www.nature.com/articles/s41377-024-01692-y?fromPaywallRec=true)**

Article Open access 02 January 2025

# **References**

1. Potton, R. J. Reciprocity in optics. Rep. Prog. Phys. **67**, 717–754 (2004).

### [Article](https://doi.org/10.1088%2F0034-4885%2F67%2F5%2FR03) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2004RPPh...67..717P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reciprocity%20in%20optics&journal=Rep.%20Prog.%20Phys.&doi=10.1088%2F0034-4885%2F67%2F5%2FR03&volume=67&pages=717-754&publication_year=2004&author=Potton%2CR%C2%A0J)

Jalas, D. et al. What is — and what is not — an optical isolator. Nat. Photon **7**, 579–582 (2013). 2.

### [Article](https://doi.org/10.1038%2Fnphoton.2013.185) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013NaPho...7..579J) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=What%20is%20%E2%80%94%20and%20what%20is%20not%20%E2%80%94%20an%20optical%20isolator&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2013.185&volume=7&pages=579-582&publication_year=2013&author=Jalas%2CD)

Fan, S. et al. Comment on 'Nonreciprocal light propagation in a silicon photonic circuit'. Science **335**, 38–38 (2012). 3.

#### [Article](https://doi.org/10.1126%2Fscience.1216682) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Comment%20on%20%E2%80%98Nonreciprocal%20light%20propagation%20in%20a%20silicon%20photonic%20circuit%E2%80%99&journal=Science&doi=10.1126%2Fscience.1216682&volume=335&pages=38-38&publication_year=2012&author=Fan%2CS)

- Dutton, H. J. R. Understanding Optical Communications (Prentice Hall PTR, Upper Saddle River, New Jersey, 1998). 4.
- Devoret, M. H. & Schoelkopf, R. J. Superconducting circuits for quantum information: an outlook. Science **339**, 1169–1174 (2013). 5.

### [Article](https://doi.org/10.1126%2Fscience.1231930) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013Sci...339.1169D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Superconducting%20circuits%20for%20quantum%20information%3A%20an%20outlook&journal=Science&doi=10.1126%2Fscience.1231930&volume=339&pages=1169-1174&publication_year=2013&author=Devoret%2CM%C2%A0H&author=Schoelkopf%2CR%C2%A0J)

Bharadia, D., McMilin, E. & Katti, S. Full duplex radios. ACM SIGCOMM Comp. Commun. Rev. **43**, 375–386 (2013). 6.

### [Article](https://doi.org/10.1145%2F2534169.2486033) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Full%20duplex%20radios&journal=ACM%20SIGCOMM%20Comp.%20Commun.%20Rev&doi=10.1145%2F2534169.2486033&volume=43&pages=375-386&publication_year=2013&author=Bharadia%2CD&author=McMilin%2CE&author=Katti%2CS)

Lu, L., Joannopoulos, J. D. & Soljačić, M. Topological photonics. Nat. Photon **8**, 821–829 (2014). 7.

#### [Article](https://doi.org/10.1038%2Fnphoton.2014.248) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014NaPho...8..821L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Topological%20photonics&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2014.248&volume=8&pages=821-829&publication_year=2014&author=Lu%2CL&author=Joannopoulos%2CJ%C2%A0D&author=Solja%C4%8Di%C4%87%2CM)

Rechtsman, M. et al. Photonic Floquet topological insulators. Nature **496**, 196–200 (2013). 8.

#### [Article](https://doi.org/10.1038%2Fnature12066) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013Natur.496..196R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Photonic%20Floquet%20topological%20insulators&journal=Nature&doi=10.1038%2Fnature12066&volume=496&pages=196-200&publication_year=2013&author=Rechtsman%2CM)

Hafezi, M., Mittal, S., Fan, J., Migdall, A. & Taylor, J. Imaging topological edge states in silicon photonics. Nat. Photon **7**, 1001–1005 (2013). 9.

#### [Article](https://doi.org/10.1038%2Fnphoton.2013.274) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013NaPho...7.1001H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Imaging%20topological%20edge%20states%20in%20silicon%20photonics&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2013.274&volume=7&pages=1001-1005&publication_year=2013&author=Hafezi%2CM&author=Mittal%2CS&author=Fan%2CJ&author=Migdall%2CA&author=Taylor%2CJ)

Adam, J. D. et al. Ferrite devices and materials. IEEE Trans. Microw. Theory Technol. **50**, 721–737 (2002). 10.

### [Article](https://doi.org/10.1109%2F22.989957) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2002ITMTT..50..721A) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Ferrite%20devices%20and%20materials&journal=IEEE%20Trans.%20Microw.%20Theory%20Technol&doi=10.1109%2F22.989957&volume=50&pages=721-737&publication_year=2002&author=Adam%2CJ%C2%A0D)

Dötsch, H. et al. Applications of magneto-optical waveguides in integrated optics: review. J. Opt. Soc. Am. B **22**, 240–253 (2005). 11.

#### [Article](https://doi.org/10.1364%2FJOSAB.22.000240) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2005OSAJB..22..240D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Applications%20of%20magneto-optical%20waveguides%20in%20integrated%20optics%3A%20review&journal=J.%20Opt.%20Soc.%20Am.%20B&doi=10.1364%2FJOSAB.22.000240&volume=22&pages=240-253&publication_year=2005&author=D%C3%B6tsch%2CH)

Shi, Y., Yu, Z. & Fan, S. Limitations of nonlinear optical isolators due to dynamic reciprocity. Nat. Photon. **9**, 388–392 (2015). 12.

Aleahmad, P., Khajavikhan, M., Christodoulides, D. & LiKamWa, P. Integrated multi-port circulators for unidirectional optical information transport. Sci. Rep. **7**, 2129 (2017). 13.

[Article](https://doi.org/10.1038%2Fs41598-017-02340-9) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017NatSR...7.2129A) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Integrated%20multi-port%20circulators%20for%20unidirectional%20optical%20information%20transport&journal=Sci.%20Rep&doi=10.1038%2Fs41598-017-02340-9&volume=7&publication_year=2017&author=Aleahmad%2CP&author=Khajavikhan%2CM&author=Christodoulides%2CD&author=LiKamWa%2CP)

Sounas, D. L. & Alù, A. Time-reversal symmetry bounds on the electromagnetic response of asymmetric structures. Phys. Rev. Lett. **118**, 154302 (2017). 14.

[Article](https://doi.org/10.1103%2FPhysRevLett.118.154302) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017PhRvL.118o4302S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-reversal%20symmetry%20bounds%20on%20the%20electromagnetic%20response%20of%20asymmetric%20structures&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.118.154302&volume=118&publication_year=2017&author=Sounas%2CD%C2%A0L&author=Al%C3%B9%2CA)

Casimir, H. B. G. On Onsager's principle of microscopic reversibility. Rev. Mod. Phys. **17**, 343–350 (1945). 15.

[Article](https://doi.org/10.1103%2FRevModPhys.17.343) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1945RvMP...17..343C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20Onsager%E2%80%99s%20principle%20of%20microscopic%20reversibility&journal=Rev.%20Mod.%20Phys.&doi=10.1103%2FRevModPhys.17.343&volume=17&pages=343-350&publication_year=1945&author=Casimir%2CH%C2%A0B%C2%A0G)

Fleury, R., Sounas, D. L., Sieck, C. F., Haberman, M. R. & Alù, A. Sound isolation and giant linear nonreciprocity in a compact acoustic circulator. Science **343**, 516–519 (2014). 16.

[Article](https://doi.org/10.1126%2Fscience.1246957) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014Sci...343..516F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sound%20isolation%20and%20giant%20linear%20nonreciprocity%20in%20a%20compact%20acoustic%20circulator&journal=Science&doi=10.1126%2Fscience.1246957&volume=343&pages=516-519&publication_year=2014&author=Fleury%2CR&author=Sounas%2CD%C2%A0L&author=Sieck%2CC%C2%A0F&author=Haberman%2CM%C2%A0R&author=Al%C3%B9%2CA)

Kodera, T., Sounas, D. L. & Caloz, C. Artificial Faraday rotation using a ring metamaterial structure without static magnetic field. Appl. Phys. Lett. **99**, 031114 (2011). 17.

[Article](https://doi.org/10.1063%2F1.3615688) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011ApPhL..99c1114K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Artificial%20Faraday%20rotation%20using%20a%20ring%20metamaterial%20structure%20without%20static%20magnetic%20field&journal=Appl.%20Phys.%20Lett.&doi=10.1063%2F1.3615688&volume=99&publication_year=2011&author=Kodera%2CT&author=Sounas%2CD%C2%A0L&author=Caloz%2CC)

Kodera, T., Sounas, D. L. & Caloz, C. Magnetless nonreciprocal metamaterial (MNM) technology: application to microwave components. IEEE Trans. Microw. Theory Technol. **61**, 1030–1042 (2013). 18.

[Article](https://doi.org/10.1109%2FTMTT.2013.2238246) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013ITMTT..61.1030K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Magnetless%20nonreciprocal%20metamaterial%20%28MNM%29%20technology%3A%20application%20to%20microwave%20components&journal=IEEE%20Trans.%20Microw.%20Theory%20Technol.&doi=10.1109%2FTMTT.2013.2238246&volume=61&pages=1030-1042&publication_year=2013&author=Kodera%2CT&author=Sounas%2CD%C2%A0L&author=Caloz%2CC)

Wang, Z. et al. Gyrotropic response in the absence of a bias field. Proc. Natl Acad. Sci. USA **109**, 13194–13197 (2012). 19.

[Article](https://doi.org/10.1073%2Fpnas.1210923109) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012PNAS..10913194W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Gyrotropic%20response%20in%20the%20absence%20of%20a%20bias%20field&journal=Proc.%20Natl%20Acad.%20Sci.%20USA&doi=10.1073%2Fpnas.1210923109&volume=109&pages=13194-13197&publication_year=2012&author=Wang%2CZ)

Cullen, A. L. A travelling-wave parametric amplifier. Nature **181**, 332 (1958). 20.

[Article](https://doi.org/10.1038%2F181332a0) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1958Natur.181..332C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20travelling-wave%20parametric%20amplifier&journal=Nature&doi=10.1038%2F181332a0&volume=181&publication_year=1958&author=Cullen%2CAL)

Kamal, A. K. A parametric device as a nonreciprocal element. Proc. IRE **48**, 1424–1430 (1960). 21.

[Article](https://doi.org/10.1109%2FJRPROC.1960.287569) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20parametric%20device%20as%20a%20nonreciprocal%20element&journal=Proc.%20IRE&doi=10.1109%2FJRPROC.1960.287569&volume=48&pages=1424-1430&publication_year=1960&author=Kamal%2CA%C2%A0K)

Anderson, B. D. O. & Newcomb, R. W. On reciprocity and time-variable networks. Proc. IEEE **53**, 1674–1674 (1965). 22.

Wentz, J. L. A nonreciprocal electrooptic device. Proc. IEEE **54**, 96–97 (1966). 23.

[Article](https://doi.org/10.1109%2FPROC.1966.4617) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20nonreciprocal%20electrooptic%20device&journal=Proc.%20IEEE&doi=10.1109%2FPROC.1966.4617&volume=54&pages=96-97&publication_year=1966&author=Wentz%2CJ%C2%A0L)

Brenner, H. E. A unilateral parametric amplifier. IEEE Trans. Microw. Theory Technol **15**, 301–306 (1967). 24.

[Article](https://doi.org/10.1109%2FTMTT.1967.1126456) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1967ITMTT..15..301B) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20unilateral%20parametric%20amplifier&journal=IEEE%20Trans.%20Microw.%20Theory%20Technol&doi=10.1109%2FTMTT.1967.1126456&volume=15&pages=301-306&publication_year=1967&author=Brenner%2CH%C2%A0E)

Turner, E. H. A nonreciprocal optical device employing birefringent elements with rotating birefringent axes. US patent 3,484,151 (1969). 25.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20nonreciprocal%20optical%20device%20employing%20birefringent%20elements%20with%20rotating%20birefringent%20axes&journal=US%20patent&volume=3&publication_year=1969&author=Turner%2CE%C2%A0H)

Koch, T. L., Koyama, F. & Liou, K.-Y. Optical modulators as monolithically integrated optical isolators. US patent 5,663,824 (1997). 26.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optical%20modulators%20as%20monolithically%20integrated%20optical%20isolators&journal=US%20patent&volume=5&publication_year=1997&author=Koch%2CT%C2%A0L&author=Koyama%2CF&author=Liou%2CK-Y)

Bhandare, S. et al. Novel nonmagnetic 30-dB traveling-wave singlesideband optical isolator integrated in III/V material. IEEE J. Sel. Top. Quant. Electron **11**, 417–421 (2005). 27.

[Article](https://doi.org/10.1109%2FJSTQE.2005.845620) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Novel%20nonmagnetic%2030-dB%20traveling-wave%20single-sideband%20optical%20isolator%20integrated%20in%20III%2FV%20material&journal=IEEE%20J.%20Sel.%20Top.%20Quant.%20Electron&doi=10.1109%2FJSTQE.2005.845620&volume=11&pages=417-421&publication_year=2005&author=Bhandare%2CS)

Xu, Q., Schmidt, B., Pradhan, S. & Lipson, M. Micrometre-scale silicon electro-optic modulator. Nature **435**, 325–327 (2005). 28.

[Article](https://doi.org/10.1038%2Fnature03569) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2005Natur.435..325X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Micrometre-scale%20silicon%20electro-optic%20modulator&journal=Nature&doi=10.1038%2Fnature03569&volume=435&pages=325-327&publication_year=2005&author=Xu%2CQ&author=Schmidt%2CB&author=Pradhan%2CS&author=Lipson%2CM)

Phare, C. T., Daniel Lee, Y.-H., Cardenas, J. & Lipson, M. Graphene electro-optic modulator with 30 GHz bandwidth. Nat. Photon. **9**, 511–514 (2015). 29.

[Article](https://doi.org/10.1038%2Fnphoton.2015.122) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015NaPho...9..511P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Graphene%20electro-optic%20modulator%20with%2030%20GHz%20bandwidth&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2015.122&volume=9&pages=511-514&publication_year=2015&author=Phare%2CC%C2%A0T&author=Daniel%20Lee%2CY-H&author=Cardenas%2CJ&author=Lipson%2CM)

Yu, Z. & Fan, S. Complete optical isolation created by indirect interband photonic transitions. Nat. Photon. **3**, 91–94 (2009). 30.

[Article](https://doi.org/10.1038%2Fnphoton.2008.273) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2009NaPho...3...91Y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Complete%20optical%20isolation%20created%20by%20indirect%20interband%20photonic%20transitions&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2008.273&volume=3&pages=91-94&publication_year=2009&author=Yu%2CZ&author=Fan%2CS)

Lira, H., Yu, Z., Fan, S. & Lipson, M. Electrically driven nonreciprocity induced by interband photonic transition on a silicon chip. Phys. Rev. Lett. **109**, 033901 (2012). 31.

[Article](https://doi.org/10.1103%2FPhysRevLett.109.033901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012PhRvL.109c3901L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Electrically%20driven%20nonreciprocity%20induced%20by%20interband%20photonic%20transition%20on%20a%20silicon%20chip&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.109.033901&volume=109&publication_year=2012&author=Lira%2CH&author=Yu%2CZ&author=Fan%2CS&author=Lipson%2CM)

Qin, S., Xu, Q. & Wang, Y. E. Nonreciprocal components with distributedly modulated capacitors. IEEE Trans. Microw. Theory Technol. **62**, 2260– 2272 (2014). 32.

Hadad, Y., Soric, J. C. & Alù, A. Breaking temporal symmetries for emission and absorption. Proc. Natl Acad. Sci. USA **113**, 3471–3475 (2016). 33.

[Article](https://doi.org/10.1073%2Fpnas.1517363113) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016PNAS..113.3471H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Breaking%20temporal%20symmetries%20for%20emission%20and%20absorption&journal=Proc.%20Natl%20Acad.%20Sci.%20USA&doi=10.1073%2Fpnas.1517363113&volume=113&pages=3471-3475&publication_year=2016&author=Hadad%2CY&author=Soric%2CJ%C2%A0C&author=Al%C3%B9%2CA)

Taravati, S. & Caloz, C. Mixer-duplexer-antenna leaky-wave system based on periodic space–time modulation. IEEE Trans. Antennas Propag. **65**, 442–452 (2017). 34.

[Article](https://doi.org/10.1109%2FTAP.2016.2632735) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017ITAP...65..442T) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Mixer-duplexer-antenna%20leaky-wave%20system%20based%20on%20periodic%20space%E2%80%93time%20modulation&journal=IEEE%20Trans.%20Antennas%20Propag&doi=10.1109%2FTAP.2016.2632735&volume=65&pages=442-452&publication_year=2017&author=Taravati%2CS&author=Caloz%2CC)

Hadad, Y., Sounas, D. & Alù, A. Space–time gradient metasurfaces. Phys. Rev. B **92**, 100304(R) (2015). 35.

[Article](https://doi.org/10.1103%2FPhysRevB.92.100304) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015PhRvB..92j0304H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Space%E2%80%93time%20gradient%20metasurfaces&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.92.100304&volume=92&publication_year=2015&author=Hadad%2CY&author=Sounas%2CD&author=Al%C3%B9%2CA)

Shaltout, A., Kildishev, A. & Shalaev, V. Time-varying metasurfaces and Lorentz non-reciprocity. Opt. Mater. Express **5**, 2459–2467 (2015). 36.

[Article](https://doi.org/10.1364%2FOME.5.002459) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-varying%20metasurfaces%20and%20Lorentz%20non-reciprocity&journal=Opt.%20Mater.%20Express&doi=10.1364%2FOME.5.002459&volume=5&pages=2459-2467&publication_year=2015&author=Shaltout%2CA&author=Kildishev%2CA&author=Shalaev%2CV)

Correas-Serrano, D. et al. Non-reciprocal graphene devices and antennas based on spatio-temporal modulation. IEEE Antenn. Wireless Propag. Lett. **15**, 1529–1532 (2015). 37.

[Article](https://doi.org/10.1109%2FLAWP.2015.2510818) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016IAWPL..15.1529C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Non-reciprocal%20graphene%20devices%20and%20antennas%20based%20on%20spatio-temporal%20modulation&journal=IEEE%20Antenn.%20Wireless%20Propag.%20Lett&doi=10.1109%2FLAWP.2015.2510818&volume=15&pages=1529-1532&publication_year=2015&author=Correas-Serrano%2CD)

Yu, Z. & Fan, S. Optical isolation based on nonreciprocal phase shift induced by interband photonic transitions. Appl. Phys. Lett. **94**, 171116 (2009). 38.

[Article](https://doi.org/10.1063%2F1.3127531) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2009ApPhL..94q1116Y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optical%20isolation%20based%20on%20nonreciprocal%20phase%20shift%20induced%20by%20interband%20photonic%20transitions&journal=Appl.%20Phys.%20Lett.&doi=10.1063%2F1.3127531&volume=94&publication_year=2009&author=Yu%2CZ&author=Fan%2CS)

Dong, P. Travelling-wave Mach–Zehnder modulators functioning as optical isolators. Opt. Express **23**, 10498–10505 (2015). 39.

[Article](https://doi.org/10.1364%2FOE.23.010498) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015OExpr..2310498D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Travelling-wave%20Mach%E2%80%93Zehnder%20modulators%20functioning%20as%20optical%20isolators&journal=Opt.%20Express&doi=10.1364%2FOE.23.010498&volume=23&pages=10498-10505&publication_year=2015&author=Dong%2CP)

Wang, D.-W. et al. Optical diode made from a moving photonic crystal. Phys. Rev. Lett. **110**, 093901 (2013). 40.

[Article](https://doi.org/10.1103%2FPhysRevLett.110.093901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013PhRvL.110i3901W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optical%20diode%20made%20from%20a%20moving%20photonic%20crystal&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.110.093901&volume=110&publication_year=2013&author=Wang%2CD-W)

Horsley, S. A. R., Wu, J.-H., Artoni, M. & La Rocca, G. C. Optical nonreciprocity of cold atom Bragg mirrors in motion. Phys. Rev. Lett. **110**, 223602 (2013). 41.

[Article](https://doi.org/10.1103%2FPhysRevLett.110.223602) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013PhRvL.110v3602H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optical%20nonreciprocity%20of%20cold%20atom%20Bragg%20mirrors%20in%20motion&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.110.223602&volume=110&publication_year=2013&author=Horsley%2CS%C2%A0A%C2%A0R&author=Wu%2CJ-H&author=Artoni%2CM&author=Rocca%2CG%C2%A0C)

Traitini, G. & Ruzzene, M. Non-reciprocal elastic wave propagation in spatiotemporal periodic structures. New J. Phys. **18**, 083047 (2016). 42.

Post, E. J. Sagnac effect. Rev. Mod. Phys. **39**, 475–493 (1967). 43.

#### [Article](https://doi.org/10.1103%2FRevModPhys.39.475) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1967RvMP...39..475P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sagnac%20effect&journal=Rev.%20Mod.%20Phys.&doi=10.1103%2FRevModPhys.39.475&volume=39&pages=475-493&publication_year=1967&author=Post%2CE%C2%A0J)

Sounas, D. L., Caloz, C. & Alù, A. Giant non-reciprocity at the subwavelength scale using angular momentum-biased metamaterials. Nat. Commun. **4**, 2407 (2013). 44.

### [Article](https://doi.org/10.1038%2Fncomms3407) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013NatCo...4E2407S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Giant%20non-reciprocity%20at%20the%20subwavelength%20scale%20using%20angular%20momentum-biased%20metamaterials&journal=Nat.%20Commun.&doi=10.1038%2Fncomms3407&volume=4&publication_year=2013&author=Sounas%2CD%C2%A0L&author=Caloz%2CC&author=Al%C3%B9%2CA)

Sounas, D. L. & Alù, A. Angular-momentum-biased nanorings to realize magnetic-free integrated optical isolation. ACS Photon. **1**, 198–204 (2014). 45.

#### [Article](https://doi.org/10.1021%2Fph400058y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Angular-momentum-biased%20nanorings%20to%20realize%20magnetic-free%20integrated%20optical%20isolation&journal=ACS%20Photon&doi=10.1021%2Fph400058y&volume=1&pages=198-204&publication_year=2014&author=Sounas%2CD%C2%A0L&author=Al%C3%B9%2CA)

Estep, N. A., Sounas, D. L., Soric, J. & Alù, A. Magnetic-free nonreciprocity and isolation based on parametrically modulated coupled resonator loops. Nat. Phys. **10**, 923–927 (2014). 46.

### [Article](https://doi.org/10.1038%2Fnphys3134) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Magnetic-free%20nonreciprocity%20and%20isolation%20based%20on%20parametrically%20modulated%20coupled%20resonator%20loops&journal=Nat.%20Phys&doi=10.1038%2Fnphys3134&volume=10&pages=923-927&publication_year=2014&author=Estep%2CN%C2%A0A&author=Sounas%2CD%C2%A0L&author=Soric%2CJ&author=Al%C3%B9%2CA)

Estep, N. A., Sounas, D. L. & Alù, A. Magnet-less microwave circulators based on spatiotemporally-modulated rings of coupled resonators. IEEE Trans. Microw. Theory Technol. **64**, 502–518 (2016). 47.

#### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Magnet-less%20microwave%20circulators%20based%20on%20spatiotemporally-modulated%20rings%20of%20coupled%20resonators&journal=IEEE%20Trans.%20Microw.%20Theory%20Technol&volume=64&pages=502-518&publication_year=2016&author=Estep%2CN%C2%A0A&author=Sounas%2CD%C2%A0L&author=Al%C3%B9%2CA)

Little, B. E., Chu, S. T., Haus, H. A., Foresi, J. & Laine, J.-P. Microring resonator channel dropping filters. J. Lightwave Technol. **15**, 998–1005 (1997). 48.

### [Article](https://doi.org/10.1109%2F50.588673) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1997JLwT...15..998L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Microring%20resonator%20channel%20dropping%20filters&journal=J.%20Lightwave%20Technol.&doi=10.1109%2F50.588673&volume=15&pages=998-1005&publication_year=1997&author=Little%2CB%C2%A0E&author=Chu%2CS%C2%A0T&author=Haus%2CH%C2%A0A&author=Foresi%2CJ&author=Laine%2CJ-P)

Fleury, R., Sounas, D. L. & Alù, A. Subwavelength ultrasonic circulator based on spatio-temporal modulation. Phys. Rev. B **91**, 174306 (2015). 49.

#### [Article](https://doi.org/10.1103%2FPhysRevB.91.174306) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015PhRvB..91q4306F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Subwavelength%20ultrasonic%20circulator%20based%20on%20spatio-temporal%20modulation&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.91.174306&volume=91&publication_year=2015&author=Fleury%2CR&author=Sounas%2CD%C2%A0L&author=Al%C3%B9%2CA)

Kerckhoff, J., Lalumière, K., Chapman, B. J., Blais, A. & Lehnert, K.W. Onchip superconducting microwave circulator from synthetic rotation. Phys. Rev. Appl **4**, 034002 (2015). 50.

#### [Article](https://doi.org/10.1103%2FPhysRevApplied.4.034002) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015PhRvP...4c4002K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On-chip%20superconducting%20microwave%20circulator%20from%20synthetic%20rotation&journal=Phys.%20Rev.%20Appl&doi=10.1103%2FPhysRevApplied.4.034002&volume=4&publication_year=2015&author=Kerckhoff%2CJ&author=Lalumi%C3%A8re%2CK&author=Chapman%2CB%C2%A0J&author=Blais%2CA&author=Lehnert%2CK%C2%A0W)

Fang, K., Yu, Z. & Fan, S. Photonic Aharonov–Bohm effect based on dynamic modulation. Phys. Rev. Lett. **108**, 153901 (2012). 51.

#### [Article](https://doi.org/10.1103%2FPhysRevLett.108.153901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012PhRvL.108o3901F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Photonic%20Aharonov%E2%80%93Bohm%20effect%20based%20on%20dynamic%20modulation&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.108.153901&volume=108&publication_year=2012&author=Fang%2CK&author=Yu%2CZ&author=Fan%2CS)

Tzuang, L. D., Feng, K., Nussenzveig, P., Fan, S. & Lipson, M. Nonreciprocal phase shift induced by an effective magnetic flux for light. Nat. Photon. **8**, 701–705 (2014). 52.

### [Article](https://doi.org/10.1038%2Fnphoton.2014.177) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014NaPho...8..701T) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Non-reciprocal%20phase%20shift%20induced%20by%20an%20effective%20magnetic%20flux%20for%20light&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2014.177&volume=8&pages=701-705&publication_year=2014&author=Tzuang%2CL%C2%A0D&author=Feng%2CK&author=Nussenzveig%2CP&author=Fan%2CS&author=Lipson%2CM)

Li, E., Eggleton, B. J., Fang, K. & Fan, S. Photonic Aharonov–Bohm effect in photon–phonon interactions. Nat. Commun. **5**, 3225 (2014). 53.

[ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014NatCo...5E3225L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Photonic%20Aharonov%E2%80%93Bohm%20effect%20in%20photon%E2%80%93phonon%20interactions&journal=Nat.%20Commun.&volume=5&publication_year=2014&author=Li%2CE&author=Eggleton%2CB%C2%A0J&author=Fang%2CK&author=Fan%2CS)

Fang, K., Yu, Z. & Fan, S. Experimental demonstration of a photonic Aharonov–Bohm effect at radio frequencies. Phys. Rev. B **87**, 060301 (2013). 54.

[Article](https://doi.org/10.1103%2FPhysRevB.87.060301) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013PhRvB..87f0301F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20demonstration%20of%20a%20photonic%20Aharonov%E2%80%93Bohm%20effect%20at%20radio%20frequencies&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.87.060301&volume=87&publication_year=2013&author=Fang%2CK&author=Yu%2CZ&author=Fan%2CS)

Doerr, C. R., Chen, L. & Vermeulen, D. Silicon photonics broadband modulation-based isolator. Opt. Express **22**, 4493–4498 (2014). 55.

[Article](https://doi.org/10.1364%2FOE.22.004493) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014OExpr..22.4493D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Silicon%20photonics%20broadband%20modulation-based%20isolator&journal=Opt.%20Express&doi=10.1364%2FOE.22.004493&volume=22&pages=4493-4498&publication_year=2014&author=Doerr%2CC%C2%A0R&author=Chen%2CL&author=Vermeulen%2CD)

Bergeal, N. et al. Phase-preserving amplification near the quantum limit with a Josephson ring modulator. Nature **465**, 64–68 (2010). 56.

[Article](https://doi.org/10.1038%2Fnature09035) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2010Natur.465...64B) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Phase-preserving%20amplification%20near%20the%20quantum%20limit%20with%20a%20Josephson%20ring%20modulator&journal=Nature&doi=10.1038%2Fnature09035&volume=465&pages=64-68&publication_year=2010&author=Bergeal%2CN)

Abdo, B., Sliwa, K., Frunzio, L. & Devoret, M. Directional amplification with a Josephson circuit. Phys. Rev. X **3**, 031001 (2013). 57.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Directional%20amplification%20with%20a%20Josephson%20circuit&journal=Phys.%20Rev.%20X&volume=3&publication_year=2013&author=Abdo%2CB&author=Sliwa%2CK&author=Frunzio%2CL&author=Devoret%2CM)

Sliwa, K. M. et al. Reconfigurable Josephson circulator/directional amplifier. Phys. Rev. X **5**, 041020 (2015). 58.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reconfigurable%20Josephson%20circulator%2Fdirectional%20amplifier&journal=Phys.%20Rev.%20X&volume=5&publication_year=2015&author=Sliwa%2CK%C2%A0M)

Lecocq, F. et al. Nonreciprocal microwave signal processing with a fieldprogrammable Josephson amplifier. Phys. Rev. Appl. **7**, 024028 (2017). 59.

[Article](https://doi.org/10.1103%2FPhysRevApplied.7.024028) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017PhRvP...7b4028L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20microwave%20signal%20processing%20with%20a%20field-programmable%20Josephson%20amplifier&journal=Phys.%20Rev.%20Appl&doi=10.1103%2FPhysRevApplied.7.024028&volume=7&publication_year=2017&author=Lecocq%2CF)

Kamal, A., Clarke, J. & Devoret, M. H. Noiseless non-reciprocity in a parametric active device. Nat. Phys. **7**, 311–315 (2011). 60.

[Article](https://doi.org/10.1038%2Fnphys1893) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Noiseless%20non-reciprocity%20in%20a%20parametric%20active%20device&journal=Nat.%20Phys&doi=10.1038%2Fnphys1893&volume=7&pages=311-315&publication_year=2011&author=Kamal%2CA&author=Clarke%2CJ&author=Devoret%2CM%C2%A0H)

Ranzani, L. & Aumentado, J. Graph-based analysis of nonreciprocity in coupled-mode systems. New J. Phys. **17**, 023024 (2015). 61.

[Article](https://doi.org/10.1088%2F1367-2630%2F17%2F2%2F023024) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015NJPh...17b3024R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Graph-based%20analysis%20of%20nonreciprocity%20in%20coupled-mode%20systems&journal=New%20J.%20Phys.&doi=10.1088%2F1367-2630%2F17%2F2%2F023024&volume=17&publication_year=2015&author=Ranzani%2CL&author=Aumentado%2CJ)

Rayleigh, J. W. On the magnetic rotation of light and the second law of thermodynamics. Nature **64**, 577 (1901). 62.

- Ishimaru, A. Unidirectional waves in anisotropic media and the resolution of the thermodynamic paradox. Technical Report No. 69 (US Air Force, 1962). 63.
- Barzilai, G. & Gerosa, G. Rectangular waveguides loaded with magnetise ferrite and the so-called thermodynamic paradox. Proc. IEE **113**, 285– 288 (1966). 64.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Rectangular%20waveguides%20loaded%20with%20magnetise%20ferrite%20and%20the%20so-called%20thermodynamic%20paradox&journal=Proc.%20IEE&volume=113&pages=285-288&publication_year=1966&author=Barzilai%2CG&author=Gerosa%2CG)

Reiskarimian, N. & Krishnaswamy, H. Magnetic-free non-reciprocity based on staggered commutation. Nat. Commun. **7**, 11217 (2016). 65.

[Article](https://doi.org/10.1038%2Fncomms11217) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016NatCo...711217R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Magnetic-free%20non-reciprocity%20based%20on%20staggered%20commutation&journal=Nat.%20Commun.&doi=10.1038%2Fncomms11217&volume=7&publication_year=2016&author=Reiskarimian%2CN&author=Krishnaswamy%2CH)

Biedka, M. M., Zhu, R., Xu, Q. M. & Wang, Y. E. Ultra-wide band nonreciprocity through sequentially-switched delay lines. Sci. Rep. **7**, 40014 (2017). 66.

[Article](https://doi.org/10.1038%2Fsrep40014) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017NatSR...740014B) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Ultra-wide%20band%20non-reciprocity%20through%20sequentially-switched%20delay%20lines&journal=Sci.%20Rep&doi=10.1038%2Fsrep40014&volume=7&publication_year=2017&author=Biedka%2CM%C2%A0M&author=Zhu%2CR&author=Mark%20Xu%2CQ&author=Wang%2CY%C2%A0E)

Dinc, T. et al. Synchronized conductivity modulation to realize broadband lossless magnetic-free non-reciprocity. Nat. Commun. **8**, 795 (2017). 67.

[Article](https://doi.org/10.1038%2Fs41467-017-00798-9) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Synchronized%20conductivity%20modulation%20to%20realize%20broadband%20lossless%20magnetic-free%20non-reciprocity&journal=Nat.%20Commun.&doi=10.1038%2Fs41467-017-00798-9&volume=8&publication_year=2017&author=Dinc%2CT)

Galland, C., Ding, R., Harris, N. C., Baehr-Jones, T. & Hochberg, M. Broadband on-chip optical non-reciprocity using phase modulators. Opt. Express **21**, 14500–14511 (2013). 68.

[Article](https://doi.org/10.1364%2FOE.21.014500) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013OExpr..2114500G) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Broadband%20on-chip%20optical%20non-reciprocity%20using%20phase%20modulators&journal=Opt.%20Express&doi=10.1364%2FOE.21.014500&volume=21&pages=14500-14511&publication_year=2013&author=Galland%2CC&author=Ding%2CR&author=Harris%2CN%C2%A0C&author=Baehr-Jones%2CT&author=Hochberg%2CM)

Poulton, C. G. et al. Design for broadband on-chip isolator using stimulated Brillouin scattering in dispersion-engineered chalcogenide waveguides. Opt. Express **20**, 2135–2156 (2012). 69.

[Article](https://doi.org/10.1364%2FOE.20.021235) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Design%20for%20broadband%20on-chip%20isolator%20using%20stimulated%20Brillouin%20scattering%20in%20dispersion-engineered%20chalcogenide%20waveguides&journal=Opt.%20Express&doi=10.1364%2FOE.20.021235&volume=20&pages=2135-2156&publication_year=2012&author=Poulton%2CC%C2%A0G)

Pant, R. et al. On-chip stimulated Brillouin scattering. Opt. Express **19**, 8285–8290 (2011). 70.

[Article](https://doi.org/10.1364%2FOE.19.008285) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011OExpr..19.8285P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On-chip%20stimulated%20Brillouin%20scattering&journal=Opt.%20Express&doi=10.1364%2FOE.19.008285&volume=19&pages=8285-8290&publication_year=2011&author=Pant%2CR)

- Haus, H. A. Waves and Fields in Optoelectronics (Prentice-Hall, Englewood Cliffs, New Jersey, 1984). 71.
- Kang, M. S., Butsch, A. & Russell, P. S. J. Reconfigurable light-driven optoacoustic isolators in photonic crystal fibre. Nat. Photon **5**, 549–553 (2011). 72.

[Article](https://doi.org/10.1038%2Fnphoton.2011.180) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011NaPho...5..549K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reconfigurable%20light-driven%20opto-acoustic%20isolators%20in%20photonic%20crystal%20fibre&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2011.180&volume=5&pages=549-553&publication_year=2011&author=Kang%2CM%C2%A0S&author=Butsch%2CA&author=Russell%2CP%C2%A0S%C2%A0J)

Eggleton, B. J., Luther-Davies, B. & Richardson, K. Chalcogenide photonics. Nat. Photon. **5**, 141–148 (2011). 73.

### [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011NaPho...5..141E) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Chalcogenide%20photonics&journal=Nat.%20Photon&volume=5&pages=141-148&publication_year=2011&author=Eggleton%2CB%C2%A0J&author=Luther-Davies%2CB&author=Richardson%2CK)

Rakich, P. T. et al. Giant enhancement of stimulated Brillouin scattering in the subwavelength limit. Phys. Rev. X **2**, 011008 (2012). 74.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Giant%20enhancement%20of%20stimulated%20Brillouin%20scattering%20in%20the%20subwavelength%20limit&journal=Phys.%20Rev.%20X&volume=2&publication_year=2012&author=Rakich%2CP%C2%A0T)

Hafezi, M. & Rabl, P. Optomechanically induced non-reciprocity in microring resonators. Opt. Express **20**, 7672–7684 (2012). 75.

[Article](https://doi.org/10.1364%2FOE.20.007672) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012OExpr..20.7672H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optomechanically%20induced%20non-reciprocity%20in%20microring%20resonators&journal=Opt.%20Express&doi=10.1364%2FOE.20.007672&volume=20&pages=7672-7684&publication_year=2012&author=Hafezi%2CM&author=Rabl%2CP)

Dong, C.-H. et al. Brillouin-scattering-induced transparency and nonreciprocal light storage. Nat. Commun. **6**, 6193 (2015). 76.

[Article](https://doi.org/10.1038%2Fncomms7193) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Brillouin-scattering-induced%20transparency%20and%20non-reciprocal%20light%20storage&journal=Nat.%20Commun.&doi=10.1038%2Fncomms7193&volume=6&publication_year=2015&author=Dong%2CC-H)

Kim, J., Kuzyk, M. C., Han, K., Wang, H. & Bahl, G. Non-reciprocal Brillouin scattering induced transparency. Nat. Phys. **11**, 275–280 (2015). 77.

[Article](https://doi.org/10.1038%2Fnphys3236) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Non-reciprocal%20Brillouin%20scattering%20induced%20transparency&journal=Nat.%20Phys&doi=10.1038%2Fnphys3236&volume=11&pages=275-280&publication_year=2015&author=Kim%2CJ&author=Kuzyk%2CM%C2%A0C&author=Han%2CK&author=Wang%2CH&author=Bahl%2CG)

Shen, Z. et al. Experimental realization of optomechanically induced non-reciprocity. Nat. Photon. **10**, 657–661 (2016). 78.

[Article](https://doi.org/10.1038%2Fnphoton.2016.161) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016NaPho..10..657S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20realization%20of%20optomechanically%20induced%20non-reciprocity&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2016.161&volume=10&pages=657-661&publication_year=2016&author=Shen%2CZ)

Ruesink, F., Miri, M.-A., Alù, A. & Verhagen, E. Nonreciprocity and magnetic-free isolation based on optomechanical interactions. Nat. Commun. **7**, 13662 (2016). 79.

[Article](https://doi.org/10.1038%2Fncomms13662) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016NatCo...713662R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocity%20and%20magnetic-free%20isolation%20based%20on%20optomechanical%20interactions&journal=Nat.%20Commun.&doi=10.1038%2Fncomms13662&volume=7&publication_year=2016&author=Ruesink%2CF&author=Miri%2CM-A&author=Al%C3%B9%2CA&author=Verhagen%2CE)

Kim, J. H., Kim, S. & Bahl, G. Complete linear optical isolation at the microscale with ultralow loss. Sci. Rep. **7**, 1647 (2017). 80.

[Article](https://doi.org/10.1038%2Fs41598-017-01494-w) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017NatSR...7.1647K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Complete%20linear%20optical%20isolation%20at%20the%20microscale%20with%20ultralow%20loss&journal=Sci.%20Rep&doi=10.1038%2Fs41598-017-01494-w&volume=7&publication_year=2017&author=Kim%2CJ%C2%A0H&author=Kim%2CS&author=Bahl%2CG)

Miri, M.-A., Ruesink, F., Verhagen, E. & Alù, A. Optical non-reciprocity based on optomechanical coupling. Phys. Rev. Appl. **7**, 064014 (2017). 81.

[Article](https://doi.org/10.1103%2FPhysRevApplied.7.064014) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017PhRvP...7f4014M) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optical%20non-reciprocity%20based%20on%20optomechanical%20coupling&journal=Phys.%20Rev.%20Appl&doi=10.1103%2FPhysRevApplied.7.064014&volume=7&publication_year=2017&author=Miri%2CM-A&author=Ruesink%2CF&author=Verhagen%2CE&author=Al%C3%B9%2CA)

Metelmann, A. & Clerk, A. A. Nonreciprocal photon transmission and amplification via reservoir engineering. Phys. Rev. X **5**, 021025 (2015). 82.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20photon%20transmission%20and%20amplification%20via%20reservoir%20engineering&journal=Phys.%20Rev.%20X&volume=5&publication_year=2015&author=Metelmann%2CA&author=Clerk%2CA%C2%A0A)

Fang, K. et al. Generalized non-reciprocity in an optomechanical circuit via synthetic magnetism and reservoir engineering. Nat. Phys. **13**, 465– 471 (2017). 83.

- Peterson, G. A. et al. Demonstration of efficient nonreciprocity in a microwave optomechanical circuit. Phys. Rev. X **7**, 031001 (2017). 84.
- Bernier, N. R. et al. Nonreciprocal reconfigurable microwave optomechanical circuit. Nat. Commun. **8**, 604(2017). 85.
- Barzanjeh, S. et al. Mechanical on-chip microwave circulator. Nat. Commun. **8**, 953 (2017). 86.
- Khanikaev, A. B. et al. Photonic topological insulators. Nat. Mater. **12**, 233–239 (2013). 87.

[Article](https://doi.org/10.1038%2Fnmat3520) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013NatMa..12..233K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Photonic%20topological%20insulators&journal=Nat.%20Mater.&doi=10.1038%2Fnmat3520&volume=12&pages=233-239&publication_year=2013&author=Khanikaev%2CA%C2%A0B)

Fang, K., Yu, Z. & Fan, S. Realizing effective magnetic field for photons by controlling the phase of dynamic modulation. Nat. Photon. **6**, 782–787 (2012). 88.

[Article](https://doi.org/10.1038%2Fnphoton.2012.236) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012NaPho...6..782F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Realizing%20effective%20magnetic%20field%20for%20photons%20by%20controlling%20the%20phase%20of%20dynamic%20modulation&journal=Nat.%20Photon&doi=10.1038%2Fnphoton.2012.236&volume=6&pages=782-787&publication_year=2012&author=Fang%2CK&author=Yu%2CZ&author=Fan%2CS)

Roushan, P. et al. Chiral ground-state currents of interacting photons in a synthetic magnetic field. Nat. Phys. **13**, 146–151 (2016). 89.

[Article](https://doi.org/10.1038%2Fnphys3930) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=3489219) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Chiral%20ground-state%20currents%20of%20interacting%20photons%20in%20a%20synthetic%20magnetic%20field&journal=Nat.%20Phys&doi=10.1038%2Fnphys3930&volume=13&pages=146-151&publication_year=2016&author=Roushan%2CP)

Schmidt, M., Kessler, S., Peano, V., Painter, O. & Marquardt, F. Optomechanical creation of magnetic fields for photons on a lattice. Optica **2**, 635–641 (2015). 90.

[Article](https://doi.org/10.1364%2FOPTICA.2.000635) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Optomechanical%20creation%20of%20magnetic%20fields%20for%20photons%20on%20a%20lattice&journal=Optica&doi=10.1364%2FOPTICA.2.000635&volume=2&pages=635-641&publication_year=2015&author=Schmidt%2CM&author=Kessler%2CS&author=Peano%2CV&author=Painter%2CO&author=Marquardt%2CF)

Peano, V., Brendel, C., Schmidt, M. & Marquardt, F. Topological phases of sound and light. Phys. Rev. X **5**, 031011 (2015). 91.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Topological%20phases%20of%20sound%20and%20light&journal=Phys.%20Rev.%20X&volume=5&publication_year=2015&author=Peano%2CV&author=Brendel%2CC&author=Schmidt%2CM&author=Marquardt%2CF)

Walter, S. & Marquardt, F. Classical dynamical gauge fields in optomechanics. New J. Phys. **18**, 113029 (2016). 92.

[Article](https://doi.org/10.1088%2F1367-2630%2F18%2F11%2F113029) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016NJPh...18k3029W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Classical%20dynamical%20gauge%20fields%20in%20optomechanics&journal=New%20J.%20Phys.&doi=10.1088%2F1367-2630%2F18%2F11%2F113029&volume=18&publication_year=2016&author=Walter%2CS&author=Marquardt%2CF)

Oka, T. & Aoki, H. Photovoltaic Hall effect in graphene. Phys. Rev. B **79**, 081406 (2009). (R). 93.

[Article](https://doi.org/10.1103%2FPhysRevB.79.081406) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2009PhRvB..79h1406O) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Photovoltaic%20Hall%20effect%20in%20graphene&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.79.081406&volume=79&publication_year=2009&author=Oka%2CT&author=Aoki%2CH)

Kitagawa, T., Berg, E., Rudner, M. & Demler, E. Topological characterization of periodically driven quantum systems. Phys. Rev. B **82**, 235114 (2010). 94.

Gu, Z., Fertig, H. A., Arovas, D. P. & Auerbach, A. Floquet spectrum and transport through an irradiated graphene ribbon. Phys. Rev. Lett. **107**, 216601 (2011). 95.

[Article](https://doi.org/10.1103%2FPhysRevLett.107.216601) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011PhRvL.107u6601G) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Floquet%20spectrum%20and%20transport%20through%20an%20irradiated%20graphene%20ribbon&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.107.216601&volume=107&publication_year=2011&author=Gu%2CZ&author=Fertig%2CH%C2%A0A&author=Arovas%2CD%C2%A0P&author=Auerbach%2CA)

Fang, K. & Fan, S. Controlling the flow of light using the inhomogeneous effective gauge field that emerges from dynamic modulation. Phys. Rev. Lett. **111**, 203901 (2013). 96.

[Article](https://doi.org/10.1103%2FPhysRevLett.111.203901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013PhRvL.111t3901F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Controlling%20the%20flow%20of%20light%20using%20the%20inhomogeneous%20effective%20gauge%20field%20that%20emerges%20from%20dynamic%20modulation&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.111.203901&volume=111&publication_year=2013&author=Fang%2CK&author=Fan%2CS)

Lin, Q. & Fan, S. Light guiding by effective gauge field for photons. Phys. Rev. X **4**, 031031 (2014). 97.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=Light%20guiding%20by%20effective%20gauge%20field%20for%20photons&journal=Phys.%20Rev.%20X&volume=4&publication_year=2014&author=Lin%2CQ&author=Fan%2CS)

Fleury, R., Khanikaev, A. B. & Alù, A. Floquet topological insulators for sound. Nat. Commun. **7**, 11744 (2016). 98.

[Article](https://doi.org/10.1038%2Fncomms11744) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2016NatCo...711744F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Floquet%20topological%20insulators%20for%20sound&journal=Nat.%20Commun.&doi=10.1038%2Fncomms11744&volume=7&publication_year=2016&author=Fleury%2CR&author=Khanikaev%2CA%C2%A0B&author=Al%C3%B9%2CA)

Miller, D. A. B. Energy consumption in optical modulators for interconnects. Opt. Express **20**, A293–A308 (2012). 99.

[Article](https://doi.org/10.1364%2FOE.20.00A293) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2012OExpr..20A.293M) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Energy%20consumption%20in%20optical%20modulators%20for%20interconnects&journal=Opt.%20Express&doi=10.1364%2FOE.20.00A293&volume=20&pages=A293-A308&publication_year=2012&author=Miller%2CD%C2%A0A%C2%A0B)

[Download references](https://citation-needed.springer.com/v2/references/10.1038/s41566-017-0051-x?format=refman&flavour=references)

# **Author information**

### **Authors and Affiliations**

<span id="page-13-1"></span>Department of Electrical and Computer Engineering, University of Texas at Austin, Austin, TX, USA 1.

Dimitrios L. Sounas & Andrea Alù

#### Authors

<span id="page-13-0"></span>Dimitrios L. Sounas [View author publications](file:///search?author=Dimitrios%20L.%20Sounas) 1.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Dimitrios%20L.%20Sounas) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Dimitrios%20L.%20Sounas%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-13-2"></span>Andrea Alù 2.

[View author publications](file:///search?author=Andrea%20Al%C3%B9)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Andrea%20Al%C3%B9) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Andrea%20Al%C3%B9%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

### **Contributions**

This work was supported by the National Science Foundation, the Air Force Office of Scientific Research, and the Defense Advanced Research Projects Agency. We thank E. Verhagen for useful comments on an earlier version of the manuscript.

### **Corresponding author**

Correspondence to [Andrea Alù.](mailto:alu@mail.utexas.edu)

# **Ethics declarations**

### **Competing interests**

The authors declare no competing financial interests.

# **Additional information**

**Publisher's note:** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Non-reciprocal%20photonics%20based%20on%20time%20modulation&author=Dimitrios%20L.%20Sounas%20et%20al&contentID=10.1038%2Fs41566-017-0051-x©right=The%20Author%28s%29&publication=1749-4885&publicationDate=2017-11-30&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

![](_page_14_Picture_12.jpeg)

### <span id="page-14-0"></span>**Cite this article**

Sounas, D.L., Alù, A. Non-reciprocal photonics based on time modulation. Nature Photon **11**, 774–783 (2017). https://doi.org/10.1038/ s41566-017-0051-x

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1038/s41566-017-0051-x?format=refman&flavour=citation)

Received: 22 June 2017 •

Accepted: 20 October 2017 •

Published: 30 November 2017 •

Issue date: December 2017 •

DOI: https://doi.org/10.1038/s41566-017-0051-x •

# **This article is cited by**

- **[Non-reciprocal frequency conversion in a non-](https://doi.org/10.1038/s41467-025-62853-0)[Hermitian multimode nonlinear system](https://doi.org/10.1038/s41467-025-62853-0)**  •
  - Sahil Pontula ◦
  - Sachin Vaidya ◦
  - Yannick Salamin ◦

Nature Communications (2025)

- **[Nonreciprocal quantum synchronization](https://doi.org/10.1038/s41467-025-63408-z)**  •
  - Deng-Gao Lai ◦
  - Adam Miranowicz ◦
  - Franco Nori ◦

Nature Communications (2025)

- **[Electrodynamics of photonic temporal interfaces](https://doi.org/10.1038/s41377-025-01947-2)**  •
  - Emanuele Galiffi ◦
  - Diego Martínez Solís ◦
  - Andrea Alù ◦

Light: Science & Applications (2025)

- **[A terahertz-bandwidth non-magnetic isolator](https://doi.org/10.1038/s41566-025-01663-8)**  •
  - Haotian Cheng ◦
  - Yishu Zhou ◦
  - Peter T. Rakich ◦

Nature Photonics (2025)

- **[Chiral exceptional point enhanced active tuning and](https://doi.org/10.1038/s41377-024-01686-w) [nonreciprocity in micro-resonators](https://doi.org/10.1038/s41377-024-01686-w)**  •
  - Hwaseob Lee ◦
  - Lorry Chang ◦
  - Tingyi Gu ◦

Light: Science & Applications (2025)

[Access through your institution](https://wayf.springernature.com?redirect_uri=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41566-017-0051-x) [Buy or subscribe](#page-1-0)

# **Associated content**

Focus

### **[PT symmetry](https://www.nature.com/collections/xccgzqcjlv)**

Advertisement

[Advertisement](file://pubads.g.doubleclick.net/gampad/jump?iu=/285/photonics.nature.com/article&sz=300x250&c=-1624460950&t=pos%3Dright%26type%3Darticle%26artid%3Ds41566-017-0051-x%26doi%3D10.1038/s41566-017-0051-x%26subjmeta%3D1021,624,639,925,927%26kwrd%3DNanophotonics+and+plasmonics,Optics+and+photonics)

# <span id="page-16-0"></span>**Explore content**

- [Research articles](file:///nphoton/research-articles) •
- [Reviews & Analysis](file:///nphoton/reviews-and-analysis)  •
- [News & Comment](file:///nphoton/news-and-comment) •
- [Current issue](file:///nphoton/current-issue)  •
- [Collections](file:///nphoton/collections)  •
- [Follow us on Twitter](https://twitter.com/NaturePhotonics) •
- [Subscribe](https://www.nature.com/nphoton/subscribe) •
- [Sign up for alerts](https://journal-alerts.springernature.com/subscribe?journal_id=41566) •
- [RSS feed](https://www.nature.com/nphoton.rss) •

# <span id="page-16-1"></span>**About the journal**

- [Aims & Scope](file:///nphoton/aims) •
- [Journal Information](file:///nphoton/journal-information) •
- [Journal Metrics](file:///nphoton/journal-impact) •
- [About the Editors](file:///nphoton/editors)  •
- [Research Cross-Journal Editorial Team](file:///nphoton/research-cross-journal-editorial-team) •
- [Reviews Cross-Journal Editorial Team](file:///nphoton/reviews-cross-journal-editorial-team) •
- [Our publishing models](file:///nphoton/our-publishing-models) •
- [Editorial Values Statement](file:///nphoton/editorial-values-statement)  •
- [Editorial Policies](file:///nphoton/editorial-policies) •
- [Content Types](file:///nphoton/content)  •
- [Web Feeds](file:///nphoton/web-feeds) •
- [Contact](file:///nphoton/contact)  •

# <span id="page-16-2"></span>**Publish with us**

- [Submission Guidelines](file:///nphoton/submission-guidelines)  •
- [For Reviewers](file:///nphoton/for-reviewers) •
- [Language editing services](https://authorservices.springernature.com/go/sn/?utm_source=For+Authors&utm_medium=Website_Nature&utm_campaign=Platform+Experimentation+2022&utm_id=PE2022)  •
- [Open access funding](file:///nphoton/open-access-funding) •
- [Submit manuscript](https://mts-nphot.nature.com/cgi-bin/main.plex) •

# <span id="page-17-0"></span>**Search**

Search articles by subject, keyword or author

Show results from All journals ˅

Search

[Advanced search](file:///search/advanced)

### **Quick links**

- [Explore articles by subject](file:///subjects) •
- [Find a job](file:///naturecareers) •
- [Guide to authors](file:///authors/index.html) •
- [Editorial policies](file:///authors/editorial_policies/) •

Nature Photonics (Nat. Photon.)

ISSN 1749-4893 (online)

ISSN 1749-4885 (print)

# **nature.com sitemap**

## **About Nature Portfolio**

- [About us](https://www.nature.com/npg_/company_info/index.html) •
- [Press releases](https://www.nature.com/npg_/press_room/press_releases.html) •
- [Press office](https://press.nature.com/) •
- [Contact us](https://support.nature.com/support/home) •

### **Discover content**

- [Journals A-Z](https://www.nature.com/siteindex) •
- [Articles by subject](https://www.nature.com/subjects) •
- [protocols.io](https://www.protocols.io/) •
- [Nature Index](https://www.natureindex.com/) •

### **Publishing policies**

- [Nature portfolio policies](https://www.nature.com/authors/editorial_policies) •
- [Open access](https://www.nature.com/nature-research/open-access) •

### **Author & Researcher services**

- [Reprints & permissions](https://www.nature.com/reprints) •
- [Research data](https://www.springernature.com/gp/authors/research-data) •
- [Language editing](https://authorservices.springernature.com/language-editing/) •
- [Scientific editing](https://authorservices.springernature.com/scientific-editing/) •
- [Nature Masterclasses](https://masterclasses.nature.com/) •

[Research Solutions](https://solutions.springernature.com/) •

### **Libraries & institutions**

- [Librarian service & tools](https://www.springernature.com/gp/librarians/tools-services) •
- [Librarian portal](https://www.springernature.com/gp/librarians/manage-your-account/librarianportal) •
- [Open research](https://www.nature.com/openresearch/about-open-access/information-for-institutions) •
- [Recommend to library](https://www.springernature.com/gp/librarians/recommend-to-your-library) •

### **Advertising & partnerships**

- [Advertising](https://partnerships.nature.com/product/digital-advertising/) •
- [Partnerships & Services](https://partnerships.nature.com/) •
- [Media kits](https://partnerships.nature.com/media-kits/) •
- [Branded content](https://partnerships.nature.com/product/branded-content-native-advertising/) •

### **Professional development**

- [Nature Awards](https://www.nature.com/immersive/natureawards/index.html) •
- [Nature Careers](https://www.nature.com/naturecareers/) •
- Nature [Conferences](https://conferences.nature.com) •

### **Regional websites**

- [Nature Africa](https://www.nature.com/natafrica) •
- [Nature China](http://www.naturechina.com) •
- [Nature India](https://www.nature.com/nindia) •
- [Nature Japan](https://www.natureasia.com/ja-jp) •
- [Nature Middle East](https://www.nature.com/nmiddleeast) •
- [Privacy Policy](https://www.nature.com/info/privacy) •
- [Use of cookies](https://www.nature.com/info/cookies) •
- Your privacy choices/Manage cookies •
- [Legal notice](https://www.nature.com/info/legal-notice) •
- [Accessibility statement](https://www.nature.com/info/accessibility-statement) •
- [Terms & Conditions](https://www.nature.com/info/terms-and-conditions) •
- [Your US state privacy rights](https://www.springernature.com/ccpa) •

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature Limited

| Close |  |
|-------|--|

### Nature Briefing

Sign up for the Nature Briefing newsletter — what matters in science, free to your inbox daily.

| MainBriefingBanner                                                         |  |  |  |
|----------------------------------------------------------------------------|--|--|--|
| DirectEmailBanner                                                          |  |  |  |
| false                                                                      |  |  |  |
| false                                                                      |  |  |  |
| false                                                                      |  |  |  |
| MainBriefingBanner                                                         |  |  |  |
| Email address                                                              |  |  |  |
|                                                                            |  |  |  |
| true                                                                       |  |  |  |
| Sign up                                                                    |  |  |  |
|                                                                            |  |  |  |
| I agree my information will be processed in accordance with the Nature and |  |  |  |
| Springer Nature Limited Privacy Policy.                                    |  |  |  |

Close

Get the most important science stories of the day, free in your inbox. [Sign up](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner) [for Nature Briefing](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner)