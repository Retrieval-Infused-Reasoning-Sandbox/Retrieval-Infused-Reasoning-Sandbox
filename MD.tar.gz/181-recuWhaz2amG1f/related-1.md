## Eigenpulses of Dispersive Time-Varying Media

S. A. R. Horsley [\\*](#page-4-0)

<span id="page-0-0"></span>School of Physics and Astronomy, University of Exeter, Stocker Road, Exeter EX4 4QL, United Kingdom

E. Galiffi[†](#page-4-1) and Y.-T. Wang

<span id="page-0-1"></span>Photonics Initiative, Advanced Science Research Center, City University of New York, New York 10027, USA

(Received 7 September 2022; accepted 31 March 2023; published 19 May 2023)

We develop a compact theory that can be applied to a variety of time-varying dispersive materials. The continuous-wave reflection and transmission coefficients are replaced with equivalent operator expressions. In addition to comparing this approach to existing numerical and analytical techniques, we find that the eigenfunctions of these operators represent pulses that do not change their spectra after interaction with the time-varying, dispersive material. In addition, the poles of these operators represent the nontime harmonic bound states of the system.

DOI: [10.1103/PhysRevLett.130.203803](https://doi.org/10.1103/PhysRevLett.130.203803)

Typical electromagnetic parameters (e.g., refractive index, or impedance) are constant in time, deriving from both the dispersive response and spatial arrangement of the constituent atoms, or meta-atoms. Designing such composite materials (metamaterials) with specified behavior has been the subject of intense research for decades, with recent developments including one-way propagation [\[1\]](#page-4-2), parity-time symmetric lasing [\[2](#page-4-3)], and a variety of methods for invisibility cloaking [\[3\]](#page-4-4). Yet many fundamental limitations can be overcome if the material properties are additionally structured in time as well as space [\[4\]](#page-4-5). For example, a lossless time-varying grating can amplify waves [\[5](#page-4-6)], something impossible with a static grating. The Kramers-Kronig relations [\[6\]](#page-4-7) also restrict the available palette of static materials (limiting, e.g., the thickness-to-bandwidth ratio of an absorber [[7](#page-4-8)]), but do not apply to time-varying media (TVM) [[8](#page-4-9)]. In addition, TVM exhibit fundamentally new phenomena such as "time refraction" [\[9](#page-4-10)[,10](#page-4-11)], "time reflection' [\[11](#page-4-12)–[14](#page-4-13)], and "temporal aiming" [\[15](#page-4-14)], where wave energy can be redirected in the absence of spatial inhomogeneity.

While many of the properties of TVM are yet to be experimentally explored, one promising platform is the conducting compound indium tin oxide (ITO) [[16\]](#page-4-15). Close to the epsilon-near-zero frequency of ITO, it exhibits a large nonlinear susceptibility [\[17](#page-5-0)], leading to an effective permittivity that is switchable on a subpicosecond timescale [[18](#page-5-1)]. This rapid switchability has been used to demonstrate time

Published by the American Physical Society under the terms of the [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/) license. Further distribution of this work must maintain attribution to the author(s) and the published article's title, journal citation, and DOI.

refraction [[9](#page-4-10),[10](#page-4-11)] and time diffraction [[19\]](#page-5-2) as well as to implement both time-varying metasurfaces [\[20\]](#page-5-3), and spectrum-modifying mirrors [\[21\]](#page-5-4).

As most materials are static, the theoretical tools for treating TVM are not well developed. In spatially homogeneous media, transfer-matrix methods are often used, based on the subsequent stacking of temporal "layers." While very successful for problems such as time interfaces [[22](#page-5-5)], in the case of continuous modulations such methods effectively act as finite differencing and hence suffer from high computational costs in the presence of nontrivial spatial structure. In addition, different sources of dispersion present significant modeling challenges. Typical TVM are highly dispersive in the frequency regimes where their nonlinearities are strongest, making the susceptibility a two-time function. Moreover, the poor impedance matching to vacuum exhibited by epsilon-near-zero media implies that resonant coupling mechanisms are needed to maximize their effects within compact metastructures [\[21\]](#page-5-4), contributing an additional degree of dispersion. This is difficult to incorporate into existing analytical results or numerical schemes, particularly in the regimes of highest phenomenological interest, where the material-response timescale is similar to the timescale of its modulation. Several works have developed methods to tackle these difficulties. For instance, Zhou et al. [\[9](#page-4-10)] introduced an effective nondispersive time-varying response that was optimized to fit the experimental data. Many current predictions alternatively integrate the full Maxwell's equations over time using, e.g., COMSOL Multiphysics [\[23](#page-5-6)] (see, e.g., [\[15](#page-4-14)]). However, this becomes computationally intensive for the dispersive structured materials discussed in, e.g., [\[19](#page-5-2)–[21](#page-5-4)].

In this Letter, we develop a compact semianalytical theoretical approach that can be applied to a variety of timevarying dispersive materials and is particularly well suited to describe the thin film ITO experiments discussed above. We find that the continuous-wave reflection and transmission coefficients can be replaced with equivalent operator expressions that are simple to evaluate numerically and act on the spectrum of the incident wave. Although distinct from this work, aspects of our operator-based approach (where, e.g., the wave vector is treated as an operator) appear in the recent extension of Mie theory given by Ptitcyn et al. [24]. We find that the eigenfunctions of these operators represent spectra of incident waves that are, e.g., unchanged on reflection from a TVM. Furthermore, when an eigenvalue of, e.g., the reflection operator is zero or diverges, we find respectively the time-varying analogs of a reflectionless medium or a bound state, which we term the "eigenpulses" of the system. In addition, we compare this approach to existing numerical and semianalytical techniques, evaluating the superior performance of this method in terms of both accuracy and efficiency.

For a static material, the electric current j is linked to the electric field E through the conductivity  $\sigma(t-t')$  that represents the movement of charge in response to the past behavior of the electric field and depends only on the time difference t-t'. When the material is explicitly time-dependent, due, e.g., to a pump pulse [17] (at optical frequencies) or electronic modulation (at radio frequencies), the conductivity can be replaced with a two-time function such that

<span id="page-1-0"></span>
$$\mathbf{j}(t) = \int_{-\infty}^{\infty} dt' \, \sigma(t, t - t') \mathbf{E}(t'). \tag{1}$$

The second time argument t - t' of the conductivity represents the usual retarded response mentioned above. Meanwhile the first argument t represents the change in the instantaneous current due to the external modulation. As in the static case, causality requires  $\sigma(t, t - t') = 0$  when t' > t. We can also develop the same formalism by taking the first argument of  $\sigma$  as t' instead of t. As the two times are related by t' = t - (t - t'), our results can be applied to either form of Eq. (1), with only minor modifications. We could also equally develop the formalism in terms of the permittivity and/or permeability instead of the conductivity.

Performing a Fourier transform of Eq. (1),  $\tilde{j}(\omega) = \int dt j(t) \exp(i\omega t)$ , the frequency dependent current can be written as

$$\tilde{\mathbf{j}}(\omega) = \int_{-\infty}^{\infty} \frac{d\omega'}{2\pi} \tilde{\mathbf{E}}(\omega') \int_{-\infty}^{\infty} dt \, \sigma(t, \omega') e^{i(\omega - \omega')t} 
= \int_{-\infty}^{\infty} d\omega' \, \tilde{\mathbf{E}}(\omega') \hat{\sigma}(-i\partial_{\omega}, \omega') \delta(\omega - \omega')$$
(2)

$$= \hat{\sigma}(-i\partial_{\omega}, \omega)\tilde{E}(\omega), \tag{3}$$

<span id="page-1-1"></span>where  $\hat{\sigma}$  is the operator obtained by replacing the first argument t' with the operator  $-i\partial_{\omega}$ . We note that an

analogous operator could also be used in inhomogeneous spatially nonlocal media [25], where the spatial dependence of the material parameters would be replaced by a *k*-space derivative. Following the line of reasoning given here may illuminate the general problem of additional boundary conditions between nonlocal media [26,27].

In the final line of Eq. (3), all derivatives  $\partial_{\omega}$  within  $\hat{\sigma}$  must be ordered such that they appear to the left of all the frequency dependence of  $\hat{\sigma}$  [28]. This prescription is reminiscent of the antinormal operator ordering adopted in quantum mechanics [29]. To use Eq. (3) we write the operator as  $\hat{\sigma} = \sum_{n} a_n(-i\partial_{\omega})b_n(\omega)$ , a decomposition that is generally possible through representing the conductivity in terms of a complete set of functions  $P_n(\omega)$  (e.g., the classical orthogonal polynomials [30]) with time-dependent expansion coefficients  $c_n(t)$ :  $\sigma(t,\omega) = \sum_n c_n(t) P_n(\omega)$ . The derivative  $\partial_{\omega}$  is numerically constructed as an  $N \times N$ matrix acting on N frequency points, via the finite difference approximation or a Fourier transform. The operators  $a_n$  are then evaluated as matrix-valued functions, and  $b_n(\omega)$  is a diagonal matrix (see the Supplemental Material [31] for an example of this, with some further details). This idea of using an operator-valued function is similar to the exponential function of the Hamiltonian operator used as the time evolution operator in quantum mechanics [34].

<span id="page-1-3"></span>In this Letter, we assume the magnetic permeability is unity, and use the Drude model with a time-varying plasma frequency  $\omega_p$  (see Supplemental Material for motivation),

$$\hat{\sigma}(-i\partial_{\omega},\omega) = \omega_p^2(-i\partial_{\omega})\frac{i\epsilon_0}{\omega + i\gamma},\tag{4}$$

where we have imposed the aforementioned antinormal ordering, and  $1/\gamma$  is the collision time. Note that throughout this Letter, we use the symbol  $\omega_0 = \omega_p(-\infty)$ , i.e., the plasma frequency before the time variation.

<span id="page-1-2"></span>The simplest application of Eq. (3) is where the medium is homogeneous, propagation is along x, and the field is polarized such that  $\tilde{\boldsymbol{H}} = H\boldsymbol{e}_z$ . In this case, Maxwell's equations become  $\partial_x^2 H + \hat{K}_p^2 H = 0$ , the solutions to which are

$$H(x,\omega) = \exp(\pm i\hat{K}_p x) H_0(0,\omega), \tag{5}$$

where  $k_0 = \omega/c$  and  $\hat{K}_p$  is the matrix square root of  $\hat{K}_p^2 = i\eta_0\hat{\sigma}k_0 + k_0^2$ ,  $H(0,\omega)$  is the Fourier amplitude of the wave at x=0, and the quantity  $\eta_0 = \sqrt{\mu_0/\epsilon_0}$  is the impedance of free space.

The aforementioned operator square root calculation is subtle. We perform it by first diagonalizing  $\hat{K}_p^2 = \hat{T}^{-1}\hat{D}\,\hat{T}$ , and then taking the square root of the eigenvalues,  $\hat{K}_p = \hat{T}^{-1}\hat{D}^{1/2}\hat{T}$ . The question is whether the positive or negative root should be taken in each eigenvalue, leaving us with N possible roots for  $N \times N$  operators. The problem of

determining the correct root is identical to that encountered in active media, where the sign of the refractive index can be determined from the  $d \to \infty$  limit of a finite slab provided it does not exhibit any instabilities [35]. In our case we fix the imaginary parts of the eigenvalues of  $\hat{K}_{s,p}$  to be positive. Further details are given in the Supplemental Material.

Although the solutions, Eq. (5), have the appearance of plane waves, the operator  $\exp(\pm i\hat{K}_p x)$  modifies the spectral content of the wave as the observation point x is changed, describing the expected temporal reshaping of the pulse during propagation. Equation (5) shows that those spectra  $H(0,\omega)$  that are eigenfunctions of  $\hat{K}_n$  with eigenvalue  $\lambda$  have a plane wave spatial dependence  $\exp(\pm i\lambda x)$ and retain the same spectrum during propagation, despite the time variation of the material parameters. Note also that Eq. (5) is similar to the aforementioned time evolution operator in quantum mechanics, where a state  $|\psi\rangle$  evolves in time as  $|\psi(t)\rangle = \exp(-i\hat{H}t/\hbar)|\psi(0)\rangle$ , where  $\hat{H}$  is the Hamiltonian operator. Figure 1 illustrates the basic idea of our formalism, and gives the form of the operator  $\hat{K}_n$  for a typical time variation of the material parameters, Eq. (4) (see Supplemental Material for further details).

Fresnel coefficients for a dispersive, time-varying interface.—Consider a pulse incident from vacuum onto a dispersive time-varying half-space (x > 0). Using the operator formalism described above, we calculate the reflection  $\hat{r}$  and transmission  $\hat{t}$  operators for an incident pulse. Just as for static materials, this calculation must be done separately for transverse electric (TE) and transverse magnetic (TM) polarizations.

Assuming incidence in the x-y plane with in-plane wave vector  $\mathbf{k}_{\parallel}$ , TE polarized waves have an electric field  $\tilde{\mathbf{E}} = E\mathbf{e}_z$  obeying the operator Helmholtz equation  $\partial_x^2 E + \hat{K}_s^2 E = 0$  where  $\hat{K}_s^2 = i\eta_0 k_0 \hat{\sigma} + k_0^2 - k_{\parallel}^2$ . Inside the TVM (x>0) the solution is given by Eq. (5),  $E(x>0,\omega) = \exp(i\hat{K}_s x)C_s(\omega)$ . Meanwhile, on the entrance side the field is a sum of plane waves for each frequency  $E(x<0,\omega) = A_s(\omega) \exp(ik_x x) + B_s(\omega) \exp(-ik_x x)$  where  $k_x = [k_0^2 - k_{\parallel}^2]^{1/2}$ . The spatial boundary conditions are the same as for static media, with both electric E and magnetic  $\eta_0 H_y = ik_0^{-1} \partial_x E$  fields continuous across x=0. Substituting the forms of the fields in the respective regions leads to the following reflection and transmission operators:

<span id="page-2-1"></span>
$$\hat{r}_s = (1 - \hat{Z}_s)(1 + \hat{Z}_s)^{-1}$$

$$\hat{t}_s = 2(1 + \hat{Z}_s)^{-1},$$
(6)

where  $\hat{Z}_s = k_x^{-1} \hat{K}_s$ ,  $B_s = \hat{r}_s A_s$ , and  $C_s = \hat{t}_s A_s$ . Equations (6) are the TE Fresnel coefficients [36], with an operator replacing the usual expression for the wave vector in the material.

<span id="page-2-0"></span>![](_page_2_Figure_7.jpeg)

FIG. 1. Scattering from a time-varying dispersive medium. (a) Our theory treats this as a generalization of a time-independent problem, with operators  $\hat{r}$  and  $\hat{t}$  replacing the usual reflection and transmission coefficients. (b) Here, we assume the Drude model permittivity, Eq. (4), with an asymmetric time variation of the plasma frequency, shown here in white. (c) The operator  $\hat{K}_p$ , here shown as a phase plot (color phase and saturation magnitude), determines the spatial evolution of the spectral content of the wave via Eq. (5). For the time dependence shown in panel (b), the operator causes a spectral broadening (the smearing around  $\omega = \omega'$ , with this largest close to the plasma frequency) and reversal of propagation direction (the line around  $\omega = -\omega'$ ). The absence of +ve to -ve frequency coupling below the plasma frequency stems from our choice of boundary conditions (see Supplemental Material), although a full understanding requires further work.

The derivation is slightly different for TM polarization, revealing the importance of operator ordering in these calculations. Taking the magnetic field as  $\mathbf{H} = H\mathbf{e}_z$ , it obeys the operator Helmholtz equation  $\partial_x^2 H + \hat{K}_p^2 H = 0$ . The square of the wave vector is as above  $\hat{K}_p^2 = i\eta_0\hat{\sigma}k_0 + k_0^2 - k_\parallel^2$ , differing from the TE expression due to the noncommuting nature of  $\hat{\sigma}$  and  $\omega$ . Applying the continuity of the magnetic H, and electric  $E = -i[k_0 + i\eta_0\hat{\sigma}]^{-1}\partial_x\eta_0H$  fields at the x = 0 interface leads to the reflection and transmission operators

<span id="page-2-2"></span>
$$\hat{r}_p = (1 - \hat{Z}_p)(1 + \hat{Z}_p)^{-1}$$

$$\hat{t}_p = 2(1 + \hat{Z}_p)^{-1},$$
(7)

where  $\hat{Z}_p = k_x^{-1}[1 + i\eta_0\hat{\sigma}k_0^{-1}]^{-1}\hat{K}_p$ . These are again operator analogs of the TM Fresnel coefficients, although in this case the operator ordering would not be obvious without

applying the boundary conditions. Importantly, at normal incidence the two wave vector operators differ by a similarity transformation:  $\hat{K}_p = k_0^{-1} \hat{K}_s k_0$ . The two impedance operators are then simply related by  $\hat{Z}_p = \hat{K}_s^{-1} k_0 = \hat{Z}_s^{-1}$ , making the reflection operators, Eqs. (6) and (7), differ by a minus sign  $\hat{r}_s = -\hat{r}_p$  as expected for the two polarizations at normal incidence [37].

As discussed above, it is again interesting to examine the eigenvalues and eigenvectors of the reflection and transmission operators. These reveal that there are pulse spectra ("eigenpulses") that retain an identical spectrum after interaction with the TVM (bar an overall multiplicative factor). Alternatively, taking a singular value decomposition of the reflection and transmission operators, we can find pulse spectra that are scaled by a set level (the singular value), but have a different spectral content after interaction with the material. We can see from Eqs. (6) and (7) that, in the case of a single interface, the eigenpulses are the eigenfunctions of the impedance operators  $\hat{Z}_{s,p}$  and thus both transmitted and reflected spectra are unchanged. Figure 2 shows a comparison between the reflection of a Gaussian pulse and an eigenpulse from a TVM (plots show the incident field just before the interface). While the Gaussian pulse is significantly broadened and reshaped by the interaction with the TVM, the eigenpulse reduces in frequency in tandem with the plasma frequency, retaining an identical spectrum upon reflection. In this case (modulus of eigenvalue |r|=1), the eigenpulse is also entirely reflected by the medium, as if it were a mirror.

In addition, the scattering operators can also exhibit poles. For example, in Eqs. (6) and (7) these poles occur where  $\det(1+\hat{Z}_{s,p})=0$ . The vectors in the null space of  $(1+\hat{Z}_{s,p})$  then represent nontime harmonic modes that are, in this case, confined to the interface of the material. In the Supplemental Material we find the surface plasmonlike eigenpulses that are confined to the interface of a TVM.

Time-varying layer.—We can straightforwardly extend this approach to any multilayer and any simple geometry (e.g., a spherical, cylindrical, or ellipsoidal object) that admits an analytic solution to Maxwell's equations in the static case. Broadly speaking, the results for the scattering operators will have an identical form but with an operator replacing the material parameters. To illustrate this in a nontrivial case we calculate the reflection and transmission operators for a slab of thickness *d*, which is relevant to the experiments reported in [9,10,18,19,21].

Assuming TM polarization, the magnetic field within the layer is taken to be of the form

$$H(0 < x < d, \omega) = e^{i\hat{K}_p x} C_p(\omega) + e^{-i\hat{K}_p x} D_p(\omega), \quad (8)$$

with the field in the external regions equal to  $H(x < 0) = \exp(ik_x x)A_p(\omega) + \exp(-ik_x x)B_p(\omega)$  and  $H(x > d) = \exp[ik_x (x-d)]F_p(\omega)$ . Imposing the same boundary

<span id="page-3-0"></span>![](_page_3_Figure_8.jpeg)

FIG. 2. Reflection of an eigenpulse from a time-varying dispersive half-space. (a) We compare the reflection of two different incident pulses: a Gaussian pulse (upper curve), and an eigenpulse (lower curve) computed from the reflection operator, Eq. (7), with eigenvalue |r|=1.00 (the zero level is displaced to aid visualization). (b) Time variation of  $N(t)=\omega_p^2(t)/\omega_0^2$  in Eq. (4). (c),(d) Magnitude of incident and reflected Fourier spectra computed via a numerical integration of Maxwell's equations (see Supplemental Material) for an incident (c) eigenpulse and (d) Gaussian pulse.

<span id="page-3-1"></span>conditions described above we obtain the reflection and transmission coefficients for the slab

$$\hat{r}_{\text{slab}} = [\hat{A}_{-} - \hat{A}_{+} \Gamma] [\hat{A}_{+} - \hat{A}_{+} \Gamma]^{-1}$$
 (9)

<span id="page-3-2"></span>and

$$\hat{t}_{\text{slab}} = 4\hat{Z}_p \hat{A}_+^{-1} e^{i\hat{K}_p d} [\hat{A}_+ - \hat{A}_- \Gamma]^{-1} \quad , \tag{10}$$

where  $\hat{A}_{\pm} = 1 \pm \hat{Z}_p$ , and  $\Gamma = \exp(i\hat{K}_p d)A_-A_+^{-1} \exp(i\hat{K}_p d)$ . Equations (9) and (10) reduce to the familiar reflection and transmission coefficients of a dielectric slab [36] when the operators are replaced with their scalar counterparts. When d=0 the reflection operator, Eq. (9), is identically zero, and the transmission operator, Eq. (10), becomes the identity, as they should.

In Fig. 3, we give a comparison between results obtained using COMSOL Multiphysics (see Supplemental Material), and calculations made using the reflection and transmission operators, Eqs. (9) and (10). We plot the normalized transmitted spectra as a function of pulse delay time  $\Delta t$ . As shown in the lower panel of this figure, there is excellent agreement between the finite element calculation and our operator approach. Additional comparisons to an adiabatic multiple-timescale approach used to model past

<span id="page-4-16"></span>![](_page_4_Figure_1.jpeg)

FIG. 3. Comparison between the proposed theory and COMSOL Multiphysics [[23](#page-5-6)]. The figures demonstrate normalized Fourier transmitted spectra for a time-modulated Drude slab excited by a 45° incident probe wave. (See Supplemental Material for more details).

experiments [[18](#page-5-1),[21](#page-5-4)] are also available in the Supplemental Material. Importantly, these tests demonstrate the advantage of this method for the efficient modeling of structures that feature extremely subwavelength layers, circumventing the need for expensive numerical calculations.

Summary and conclusions.—We have developed a compact theoretical approach for treating the problem of scattering from dispersive TVM. We have shown that our analytic expressions match full wave numerical simulations well. Although the theory is formally similar to the case of static materials, the TVM parameters are given in terms of operators that depend on both the frequency and frequency derivatives, which must be carefully ordered. The advantage of our theory is that it is semianalytical, allowing us to give explicit operator expressions for scattering coefficients from the TVM, and thus determine conditions for, e.g., incoming modes that are bound, not reflected, or completely reflected by the material. We have numerically constructed these operators and found the "eigenpulses" of a time-modulated Drude half-space, numerically verifying that there are input pulse spectra that, e.g., reflect as if the TVM was a dispersionless mirror. This approach may be readily extended to other areas of wave physics such as pressure acoustics [\[38\]](#page-5-19) and elasticity and may be of interest to those working on TVM as well as multiple scattering, where our reflectionless eigenpulses are analogous to the concept of open scattering channels in disordered media (see, e.g., [\[39\]](#page-5-20)).

S. A. R. H. acknowledges the Royal Society and TATA for financial support through grant URF\R\211033, and thanks Riccardo Sapienza, Euan Hendry, James Capers, and Dean Patient for useful conversations. E. G. acknowledges funding from the Simons Foundation through a Junior Fellowship of the Simons Society of Fellows (855344,EG).

- <span id="page-4-1"></span><span id="page-4-0"></span>[\\*](#page-0-0) Corresponding author. s.horsley@exeter.ac.uk Corresponding author. egaliffi@gc.cuny.edu
- <span id="page-4-3"></span><span id="page-4-2"></span>[1] M. Segev and M. A. Bandres, Topological photonics: Where do we go from here?, [Nanophotonics](https://doi.org/10.1515/nanoph-2020-0441) 10, 425 (2021).
- [2] R. El-Ganainy, K. G. Makris, M. Khajavikhan, Z. H. Musslimani, S. Rotter, and D. N. Christodoulides, Non-Hermitian physics and PT symmetry, [Nat. Phys.](https://doi.org/10.1038/nphys4323) 14, 11 [\(2018\).](https://doi.org/10.1038/nphys4323)
- <span id="page-4-4"></span>[3] K.-T. Lee, C. Ji, H. Iizuka, and D. Banerjee, Optical cloaking and invisibility: From fiction toward a technological reality, J. Appl. Phys. 129[, 231101 \(2021\)](https://doi.org/10.1063/5.0048846).
- <span id="page-4-5"></span>[4] E. Galiffi, R. Tirole, S. Yin, H. Li, S. Vezzoli, P. A. Huidobro, M. G. Silveirinha, R. Sapienza, A. Alú, and J. B. Pendry, Photonics of time-varying media, [Adv. Opt.](https://doi.org/10.1117/1.AP.4.1.014002) Photonics 4[, 014002 \(2022\).](https://doi.org/10.1117/1.AP.4.1.014002)
- <span id="page-4-7"></span><span id="page-4-6"></span>[5] E. Galiffi, P. Huidobro, and J. Pendry, An Archimedes' screw for light, [Nat. Commun.](https://doi.org/10.1038/s41467-022-30079-z) 13, 2523 (2022).
- <span id="page-4-8"></span>[6] L. D. Landau and E. M. Lifshitz, Statistical Physics: Part 1 (Butterworth-Heinemann, London, 2005).
- <span id="page-4-9"></span>[7] K. N. Rozanov, Ultimate thickness to bandwidth ratio of radar, [IEEE Trans. Antennas Propag.](https://doi.org/10.1109/8.884491) 48, 1230 (2000).
- [8] D. M. Solis and N. Engheta, Functional analysis of the polarization response in linear time-varying media: A generalization of the Kramers-Kronig relations, [Phys.](https://doi.org/10.1103/PhysRevB.103.144303) Rev. B 103[, 144303 \(2021\).](https://doi.org/10.1103/PhysRevB.103.144303)
- <span id="page-4-10"></span>[9] Y. Zhou, M. Z. Alam, M. Karimi, J. Upham, O. Reshef, C. Liu, A. E. Willner, and R. W. Boyd, Broadband frequency translation through time refraction in an epsilon-near-zero material, [Nat. Commun.](https://doi.org/10.1038/s41467-020-15682-2) 11, 2180 (2020).
- <span id="page-4-11"></span>[10] J. Bohn, T. S. Luk, S. A. R. Horsley, and E. Hendry, Spatiotemporal refraction of light in an epsilon-near-zero indium tin oxide layer: Frequency shifting effects arising from interfaces, Optica 8[, 1532 \(2021\).](https://doi.org/10.1364/OPTICA.436324)
- <span id="page-4-12"></span>[11] F. R. Morgenthaler, Velocity modulation of electromagnetic waves, [IRE Trans. Microwave Theory Tech.](https://doi.org/10.1109/TMTT.1958.1124533) 6, 167 (1958).
- [12] J. T. Mendonça and P. K. Shukla, Time refraction and time reflection: Two basic concepts, Phys. Scr. 65[, 160 \(2002\).](https://doi.org/10.1238/Physica.Regular.065a00160)
- [13] V. Bacot, M. Labousse, A. Eddi, M. Fink, and E. Fort, Time reversal and holography with spacetime transformations, Nat. Phys. 12[, 972 \(2016\)](https://doi.org/10.1038/nphys3810).
- <span id="page-4-13"></span>[14] H. Moussa, G. Xu, S. Yin, E. Galiffi, Y. Radi, and A. Alù, Observation of temporal reflections and broadband frequency translations at photonic time-interfaces, [arXiv:](https://arXiv.org/abs/2208.07236) [2208.07236.](https://arXiv.org/abs/2208.07236)
- <span id="page-4-15"></span><span id="page-4-14"></span>[15] V. Pacheco-Peña and N. Engheta, Temporal aiming, [Light](https://doi.org/10.1038/s41377-020-00360-1) Sci. Appl. 9[, 129 \(2020\)](https://doi.org/10.1038/s41377-020-00360-1).
- [16] W. Jaffray, S. Saha, V. M. Shalaev, A. Boltasseva, and M. Ferrera, Transparent conducting oxides: From all-dielectric

- plasmonics to a new paradigm in integrated photonics, Adv. Opt. Photonics **14**, 148 (2022).
- <span id="page-5-0"></span>[17] M. Z. Alam, I. De Leon, and R. W. Boyd, Large optical nonlinearity of indium tin oxide in its epsilon-near-zero region, Science 352, 795 (2016).
- <span id="page-5-1"></span>[18] T. S. Bohn, J. ans Luk, C. Tollerton, S. W. Hutchings, I. Brener, S. A. R. Horsley, W. L. Barnes, and E. Hendry, Alloptical switching of an epsilon-near-zero plasmon resonance in indium tin oxide, Nat. Commun. 12, 1017 (2021).
- <span id="page-5-2"></span>[19] R. Tirole, S. Vezzoli, E. Galiffi, I. Robertson, D. Maurice, B. Tilmann, S. A. Maier, J. B. Pendry, and R. Sapienza, Double-slit time diffraction at optical frequencies, arXiv: 2206.04362.
- <span id="page-5-3"></span>[20] C. Liu, M. Z. Alam, K. Pang, K. Manukyan, O. Reshef, Y. Zhou, S. Choudhary, J. Patrow, A. Pennathurs, H. Song, Z. Zhao, R. Zhang, F. Alishahi, A. Fallahpour, Y. Cao, A. Almaiman, J. M. Dawlaty, M. Tur, R. W. Boyd, and A. E. Willner, Photon acceleration using a time-varying epsilonnear-zero metasurface, ACS Photonics 8, 716 (2021).
- <span id="page-5-4"></span>[21] R. Tirole, E. Galiffi, J. Dranczewski, T. Attavar, B. Tilmann, Y.-T. Wang, P. A. Huidobro, A. Alú, J. B. Pendry, S. A. Maier et al., Saturable Time-Varying Mirror Based on an Epsilon-Near-Zero Material, Phys. Rev. Appl. 18, 054067 (2022).
- <span id="page-5-5"></span>[22] D. Ramaccia, A. Alù, A. Toscano, and F. Bilotti, Temporal multilayer structures for designing higher-order transfer functions using time-varying metamaterials, Appl. Phys. Lett. 118, 101901 (2021).
- <span id="page-5-6"></span>[23] C. Multiphysics, Introduction to comsol multiphysics®, COMSOL Multiphysics, Burlington, MA, accessed Feb 9, 2018 (1998).
- <span id="page-5-7"></span>[24] G. Ptitcyn, A. G. Lamprianidis, T. Karamanos, V. S. Asadchy, R. Alaee, M. Müller, M. Albooyeh, M. S. Mirmoosa, S. Fan, S. A. Tretyakov, and C. Rockstuhl, Scattering of light by spheres made from a time-modulated and dispersive material, .
- <span id="page-5-8"></span>[25] V. M. Agranovich and V. L. Ginzburg, Crystal Optics with Spatial Dispersion, and Excitons (Springer-Verlag, Berlin, 2013).
- <span id="page-5-9"></span>[26] G. S. Agarwal, D. N. Pattanayak, and E. Wolf, Electromagnetic fields in spatially dispersive media, Phys. Rev. B 10, 1447 (1974).

- <span id="page-5-10"></span>[27] M. G. Silveirinha, Additional boundary conditions for nonconnected wire media, New J. Phys. 11, 113016 (2009).
- <span id="page-5-11"></span>[28] The opposite (normal) operator ordering (where the  $\partial_{\omega}$  sit on the *right* of the factors of frequency in  $\hat{\sigma}$ ) is required if we specify the conductivity in Eq. (1) as  $\sigma(t', t - t')$ .
- <span id="page-5-12"></span>[29] J. R. Shewell, On the formation of quantum-mechanical operators, Am. J. Phys. 27, 16 (1959).
- <span id="page-5-13"></span>[30] DLMF, NIST Digital Library of Mathematical Functions, http://dlmf.nist.gov/, Release 1.1.8 of 2022-12-15, edited by f. W. J. Olver, A. B. Olde Daalhuis, D. W. Lozier, B. I. Schneider, R. F. Boisvert, C. W. Clark, B. R. Miller, B. V. Saunders, H. S. Cohl, and M. A. McClain.
- <span id="page-5-14"></span>[31] See Supplemental Material at http://link.aps.org/ supplemental/10.1103/PhysRevLett.130.203803 for additional details, which includes additional Refs. [32,33].
- [32] B. Nistad and J. Skaar, Causality and electromagnetic properties of active media, Phys. Rev. E **78**, 036603 (2008).
- [33] P. Virtanen, R. Gommers, T. E. Oliphant *et al.*, SciPy 1.0: fundamental algorithms for scientific computing in Python, Nat. Methods **17**, 261 (2020).
- <span id="page-5-15"></span>[34] J. J. Sakurai and J. Napolitano, Modern Quantum Mechanics (Cambridge University Press, Cambridge, England, 2018).
- <span id="page-5-16"></span>[35] Note that for any finite medium, where we treat both entry and exit boundaries, the ambiguity in the square root is inconsequential; we automatically include both signs of the eigenvalues in both  $\exp(\pm \hat{K}_p x)$  operators.
- <span id="page-5-17"></span>[36] L. D. Landau, E. M. Lifshitz, and L. P. Pitaevskii, *Electro-dynamics of Continuous Media* (Butterworth-Heinemann, London, 2004).
- <span id="page-5-18"></span>[37] We define the TM reflection coefficients in terms of the *magnetic* field amplitude, and the TE reflection coefficient in terms of the *electric* field amplitude, hence their difference by a sign at normal incidence.
- <span id="page-5-19"></span>[38] C. Cho, X. Wen, N. Park, and J. Li, Digitally virtualized atoms for acoustic metamaterials, Nat. Commun. 11, 251 (2020).
- <span id="page-5-20"></span>[39] W. Choi, A. P. Mosk, Q.-H. Park, and W. Choi, Transmission eigenchannels in a disordered medium, Phys. Rev. B **83**, 134207 (2011).