#### Skip to main content

Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.

#### Advertisement

#### Advertisement

#### communications

physics

- View all journals
- Q<sub>Search</sub>
- Log in
- Content Explore content >
- About the journal ~
- Publish with us ~
- Sign up for alerts Q
- RSS feed
- 1. nature >
- 2. communications physics >
- 3. articles >
- 4. article

<span id="page-0-0"></span>Unidirectional amplification with acoustic non-Hermitian space—time varying metamaterial

Download PDF
Download PDF

- Article
- Open access
- Published: 11 January 2022

# Unidirectional amplification with acoustic non-Hermitian space—time varying metamaterial

- \* Xinhua Wen<sup>1</sup>
- Xinghong Zhu<sup>1</sup>
- Alvin Fan<sup>1</sup>,
- Wing Yim Tam<sup>1</sup>,

- lie Zhu<sup>2</sup>
- Hong Wei Wu<sup>1</sup>,
- Fabrice Lemoult<sup>3</sup>
- Mathias Fink 3 &
- ...
- <u>lensen Li</u> 1

Show authors

<u>Communications Physics</u> **volume 5**, Article number: 18 (2022) <u>Cite this</u> article

- 7902 Accesses
- 65 Citations
- 2 Altmetric
- Metrics details

#### Subjects

- Acoustics
- Electronic devices

## **Abstract**

Space—time modulated metamaterials support extraordinary rich applications, such as parametric amplification, frequency conversion, and non-reciprocal transmission. The non-Hermitian space—time varying systems combining non-Hermiticity and space—time varying capability, have been proposed to realize wave control like unidirectional amplification, while its experimental realization still remains a challenge. Here, based on metamaterials with software-defined impulse responses, we experimentally demonstrate non-Hermitian space—time varying metamaterials in which the material gain and loss can be dynamically controlled and balanced in the time domain instead of spatial domain, allowing us to suppress scattering at the incident frequency and to increase the efficiency of frequency conversion at the same time. An additional modulation phase delay between different meta-atoms results in unidirectional amplification in frequency conversion. The realization of non-Hermitian space—time varying metamaterials will offer further opportunities in studying non-Hermitian topological physics in dynamic and nonreciprocal systems.

## **Similar content being viewed by others**

![](_page_2_Picture_1.jpeg)

## **[Demonstration of a tunable non-Hermitian nonlinear](https://www.nature.com/articles/s41467-025-62620-1?fromPaywallRec=false) [microwave dimer](https://www.nature.com/articles/s41467-025-62620-1?fromPaywallRec=false)**

Article Open access 05 August 2025

![](_page_2_Picture_4.jpeg)

### **[Topology and broken Hermiticity](https://www.nature.com/articles/s41567-020-01093-z?fromPaywallRec=false)**

![](_page_2_Picture_6.jpeg)

## **[Second harmonic generation at a time-varying interface](https://www.nature.com/articles/s41467-024-51588-z?fromPaywallRec=false)**

Article Open access 05 September 2024

## **Introduction**

In the past two decades, metamaterials with spatial modulation (with spatially varying parameters) have opened an emerging paradigm to manipulate classical waves, and have been used to achieve many intriguing physical phenomena like negative refraction, lensing, hologram, and invisibility cloaking[1](#page-13-0),[2,](#page-13-1)[3,](#page-13-2)[4](#page-13-3)[,5](#page-13-4)[,6](file:///articles/s42005-021-00790-2#ref-CR6) . To endow metamaterials more tunability, numerous efforts have been made to construct reconfigurable metamaterials whose material parameters can be changed adiabatically from one set to another set, such as coding metamaterials and electronically-controlled active metamaterials, to realize tunable lensing, beam-steering, and topological edge states[7](#page-14-0),[8](#page-14-1),[9,](#page-14-2)[10,](#page-14-3)[11,](#page-14-4)[12](#page-14-5),[13](#page-14-6),[14](#page-14-7),[15](file:///articles/s42005-021-00790-2#ref-CR15). Temporal modulation of material parameters has been applied on metamaterials to further extend the degrees of freedom in wave control[16](#page-15-0),[17](#page-15-1),[18](#page-15-2),[19](#page-15-3),[20](#page-15-4),[21](#page-15-5)[,22](#page-15-6)[,23](#page-15-7)[,24](#page-15-8)[,25](#page-15-9)[,26](#page-16-0)[,27](#page-16-1)[,28](#page-16-2)[,29,](#page-16-3)[30](file:///articles/s42005-021-00790-2#ref-CR30) , which also opens further possibilities for extraordinary physics like tunable frequency conversion[18](file:///articles/s42005-021-00790-2#ref-CR18),[19](file:///articles/s42005-021-00790-2#ref-CR19), non-reciprocal propagation[20,](#page-15-4)[21,](#page-15-5)[22,](#page-15-6)[23,](#page-15-7)[24](#page-15-8),[25](#page-15-9),[26](#page-16-0),[27](#page-16-1), [28](#page-16-2)[,29](file:///articles/s42005-021-00790-2#ref-CR29), time reversal mirror[31](file:///articles/s42005-021-00790-2#ref-CR31)[,32](file:///articles/s42005-021-00790-2#ref-CR32), parametric amplification[33,](file:///articles/s42005-021-00790-2#ref-CR33)[34](file:///articles/s42005-021-00790-2#ref-CR34), and topological pumping[35,](#page-17-0)[36,](#page-17-1)[37](file:///articles/s42005-021-00790-2#ref-CR37). Furthermore, analog concepts originally defined for spatially inhomogeneous materials can be explored in the temporal domain now, including the concept of temporal effective media[38,](file:///articles/s42005-021-00790-2#ref-CR38)[39](file:///articles/s42005-021-00790-2#ref-CR39), and time-gradient metasurfaces[40](file:///articles/s42005-021-00790-2#ref-CR40), as well as the analogy of bandgap concept in temporal domain for frequency filtering[41](file:///articles/s42005-021-00790-2#ref-CR41) .

Recently, it has been proposed to add non-Hermiticity into time-varying systems to achieve phenomena such as unidirectional amplification[42](file:///articles/s42005-021-00790-2#ref-CR42)[,43](file:///articles/s42005-021-00790-2#ref-CR43) , bidirectional invisibility[34](file:///articles/s42005-021-00790-2#ref-CR34), tunable exceptional points by modulation[44](file:///articles/s42005-021-00790-2#ref-CR44), and nonreciprocal edge state propagating in non-Hermitian Floquet insulators[45](file:///articles/s42005-021-00790-2#ref-CR45) . In the non-Hermitian space−time varying systems, unidirectional amplification, referring to signal amplification in only one incident direction, can be achieved by temporally modulating the coupling terms (both the real and imaginary part) between two resonators[42](file:///articles/s42005-021-00790-2#ref-CR42) or modulating gain and loss in both space and time[43](file:///articles/s42005-021-00790-2#ref-CR43). Specifically, in ref. [42](file:///articles/s42005-021-00790-2#ref-CR42), the non-Hermitian coupling terms can be used to control not only the target frequency-converted modes, but also other higher-order harmonics, to realize a one-way amplifier. However, the experimental realization of unidirectional amplification in these non-Hermitian time-varying systems still remains a challenge.

Here, we construct meta-atoms with software-defined impulse responses in mimicking the resonating responses of physical metamaterials[12](file:///articles/s42005-021-00790-2#ref-CR12). The approach allows a huge flexibility in defining the metamaterial responses and we experimentally realize non-Hermitian space−time varying metamaterials by applying a non-Hermitian (gain and loss) space−time modulation. In such a non-Hermitian space−time varying metamaterial, the material gain and loss can be dynamically modulated and balanced in the temporal domain instead of the spatial domain. It generates multiple harmonics while suppresses scattering at the incident frequency due to the elimination of the corresponding Fourier component. Consequently, efficient frequency conversion to the first-order harmonics can be achieved and unidirectional amplification in frequency conversion with amplification ratio up to 151% in signal amplitude is experimentally demonstrated. Moreover, due to the flexibility of our software-defined metamaterial platform, we can arbitrarily define the "energy-level" diagrams to manipulate the frequency-converted modes, in analogy to quantum interference effect.

# **Results and discussion**

## **Non-Hermitian space−time varying metamaterial platform**

Recently, research works on breaking time-reversal symmetry to achieve temporal modulation of system parameters is a growing area in both

acoustics and optics. For example, to realize nonreciprocal acoustic transmission, a mechanical driver is used to temporally modulate the volume or the physical boundary of resonators[21,](file:///articles/s42005-021-00790-2#ref-CR21)[35](file:///articles/s42005-021-00790-2#ref-CR35). However, the modulation frequency and strength induced by the mechanical driver may be restricted in practical applications, e.g., the modulation strength decreases with increasing frequency[21](file:///articles/s42005-021-00790-2#ref-CR21). To get more flexible control, here we use a softwaredefined metamaterial with digital feedback circuits to experimentally realize non-Hermitian space−time modulation. Figure [1a](file:///articles/s42005-021-00790-2#Fig1) schematically shows our time-varying platform in a 1D acoustic waveguide. It consists of two metaatoms (termed as atom n = 1,2) separated by a small distance \(\ell\) (0.04 m), and each of them is constructed by one microphone (\(D\_n\)) and one speaker (\(S\_n\)) with a feedback between them through an external microcontroller (Adafruit ItsyBitsy M4 Express). For a single meta-atom, the microcontroller is instructed to perform a modulated digital convolution \ (S\left( t \right) = \partial \_t{\int} {a(t)y\left( {t^{\prime}} \right)D\left( {t t^{\prime}} \right){{{{{\rm{d}}}}}}t^\prime}\) with \(y\left( t \right) = g\sin \left( {2\pi f\_{{{{{{{{\mathrm{res}}}}}}}}}\left( {t - \delta t} \right)} \right){{{{{\rm{e}}}}}}^{ - 2\pi \gamma \left( {t - \delta t} \right)} \) for \(t > \delta t\) and 0 for \(t < \delta t\). \ (f\_{{{{{{{{\mathrm{res}}}}}}}}}\), g and \(\gamma\) are the resonating frequency, strength, and linewidth respectively. While the modulation \(a(t)\) is generally time-dependent, we start with the static case where it is a constant one at the moment. \({\updelta}t\) includes a programmable timedelay and the time delay of all the electronic components. Here, we purposely choose \(\delta t\) in satisfying \(2\pi f\_{{{{{{{{\mathrm{res}}}}}}}}}{\updelta}t \approx \pi\). Then, the feedback from the microphone to the speaker of each meta-atom implements a harmonic response with \(S\left( f \right) = Y\left( f \right)D(f)\) where \(Y(f)\) can be approximated by the following resonating form:

```
$$Y\left( f \right) \cong \frac{{igf_{{{{{{{{\mathrm{res}}}}}}}}}f}}
{{f_{{{{{{{{\mathrm{res}}}}}}}}}^2 - \left( {f + {{{{{\rm{i}}}}}}
\gamma } \right)^2}},$$
(1)
```

**Fig. 1: Non-Hermitian space−time varying metamaterial platform.** [figure 1](file:///articles/s42005-021-00790-2/figures/1)

**a** Schematic of the space−time varying metamaterials platform in a 1D acoustic waveguide. The microphones (speakers) for the two atoms are labeled as \(D\_1\), \(D\_2\) (\(S\_1,S\_2\)). **b** A square-wave amplitude modulation \(a(t)\) is applied on the meta-atoms with a modulation period \(T\) and duty-cycle \(\xi\). An additional modulation time delay \({{\Delta }}t\) can be applied on atom 2. The convolution kernel \(Y(f)/i\) for a lossy meta-atom (**c**) and active meta-atom (**d**), corresponds to the Lorentzian and anti-Lorentzian line-shape respectively. Real and imaginary parts are plotted in solid and dashed lines respectively.

The corresponding transmission coefficient  $t_{\rm f}/t_{\rm b}$  in the forward/backward direction and the reflection coefficient r (common for both directions) can be found as

```
 $$\left\{ {\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{\{
```

with reference plane set at the center between the microphone and speaker,  $(k \ 0) = 2 \pi f(c)$  being the free-space wavenumber and c being the sound speed in air. More details in deriving the operation are given in Supplementary Notes 1, 2. We note that in the limit of small \(\ell \to 0\), passivity (condition of meta-atom to be lossy) means  $(\left| \{1+r\}\right|^2)$ + \left| r \right|^2 \le 1\), equivalently \(\{\{\{\{\\mathrm\lm\}\}\}\}\}\}  $\left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left( \left$ (\gamma\) are positive numbers. We call such a configuration Lorentzian, being approximately lossy and having a Lorentzian line-shape in \(Y(f)/i\) or \ (r(f)/i) around the resonating frequency, as schematically shown in Fig. 1c. On the other hand, to achieve gain, i.e., power is being injected into the meta-atom through the power supply of the microcontroller, one might want to flip the sign of \(\gamma\) but the envelope of the convolution kernel \(\(y(t)\) \) will keep increasing in time, stopping a digital implementation of the convolution to be finished within one signal sampling period (chosen as  $T_s =$ 138.7 µs here). Here, we choose a negative value of \(g\) (equivalently positive \(g\) but negative \(a\) multiplying to it), meeting the gain condition \  $(\{\{\{\{\{\{\{\{\{\{\{\{\{\{\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}\}$ a configuration anti-Lorentzian in realizing an active meta-atom. We also call such a realization approach as digital virtualization of the impulse response as it can mimic Lorentzian resonating response coming from a physical metamaterial atom, such as a Helmholtz resonator 12,46.

For implementing a time-varying response function of the meta-atoms, the modulation (a(t)) changes with time (t). In this work, we consider a periodic square-wave modulation defined by two constant amplitudes \(a 1\) and \(a 2\) with modulation period \(T\) (equivalently modulation frequency \  $(F = 1/\overline{T})$  and duty cycle  $(\dot x : 1 - \dot x)$  between the two static configurations. Figure 1b shows the modulation in alternating between a Lorentzian configuration with positive \(a 1\) and an anti-Lorentzian configuration with negative \(a 2\). The metamaterial is therefore being modulated between a lossy and a gain configuration. As a result, the meta-atom not only constitutes a frequency-dispersive time-varying polarizability 47,48, but also includes temporally controlled material gain and loss. Moreover, we can apply the same \(a(t)\) on the next atom (atom 2) but with an additional time delay \({{\Delta }}t\) in the modulation. We define a modulation phase delay between adjacent atoms as  $({\{\Delta\}}\$  =  $2\pi {\{\Delta\}\}\$ , ranging from 0 to \(2\pi\) for a full cycle delay. It generally describes a space—time  $modulation (a) \{ t - \left( \{n - 1\} \right) \{ \Delta \} \} \}$  \right) at different

atoms. As \(a(t)\) is chosen as a periodic modulation, one can decompose all the signals in terms of Fourier series, e.g., \(D\_n\left( t \right) = {{\Sigma }} \_mD\_{nm}{{{{{\rm{e}}}}}}^{ - {{{{{\rm{i}}}}}}2\pi f\_mt}\), \(a\left( t \right) = {{\Sigma }}\_mA\_m{{{{{\rm{e}}}}}}^{ - {{{{{\rm{i}}}}}}2\pi mFt}\), where the m-th harmonics is defined by \(f\_m = f + mF\), with integer \(m\) labeling the order of the harmonics and f being the reference frequency, taken as the incident waves. Then, there can be frequency conversions between the different frequency harmonics at atom \(n\) by

```
$$S_{nm} = Y_{m,m^{\prime}}^{\left( n \right)}\left( f
\right)D_{nm^{\prime}},\,\quad Y_{m,m^{\prime}}^{(n)}\left( f \right)
\cong \frac{{igf_{{{{{{{{\mathrm{res}}}}}}}}}A_{m - m^{\prime}}
f_m}}{{f_{{{{{{{{\mathrm{res}}}}}}}}}^2 - \left( {f_{m^{\prime}} +
{{{{{\rm{i}}}}}}\gamma } \right)^2}}{{{{{\rm{e}}}}}}
^{{{{{{\rm{i}}}}}}\left( {m - m^{\prime}} \right)\left( {n - 1} \right)
{{\Delta }}\phi }.$$
(3)
```

The radiation from the speakers, together with the background incident waves represented by the Fourier components of the microphone signal \ (D\_{nm}^{(0)}\), becomes the local fields detected by the microphones:

```
$$D_{nm} = D_{nm}^{\left( 0 \right)} + {{{{{\rm{e}}}}}}
^{{{{{{\rm{i}}}}}}k_0\left( {f_m} \right)L_{nn^{\prime}}}
S_{n^{\prime}m}.$$
(4)
```

where \(L\_{nn^{\prime}}\) is the distance between the microphone of atom \ (n\) from the speaker of atom \(n^{\prime}\). The repeated indices in formula imply summation. Then, combining Eqs. [3](file:///articles/s42005-021-00790-2#Equ3) and [4](file:///articles/s42005-021-00790-2#Equ4) gives the microphones signals by solving

```
$$\left( {\delta _{nn^{\prime}}\delta _{mm^{\prime}} -
{{{{{{{\mathcal{T}}}}}}}}_{nm,n^{\prime}m^{\prime}}\left( f \right)}
\right)D_{n^{\prime}m^{\prime}} = D_{nm}^{\left( 0 \right)},$$
(5)
```

where the loop transfer function is a matrix with elements \ ({{{{{{{\mathcal{T}}}}}}}}\_{nm,n^{\prime}m^{\prime}}\left( f \right) = {{{{{\rm{e}}}}}}^{{{{{{\rm{i}}}}}}k\_0\left( {f\_m} \right)L\_{nn^{\prime}}}Y\_{m,m^{\prime}}^{\left( {n^{\prime}} \right)} (f)\). The total fields, including the transmitted and the reflected signals, can then be obtained by summing the incident waves and the secondary radiation from the speakers. As we shall see, the tuning of the modulation phase delay allows us to achieve unidirectional amplification on the reflected signal. From Eqs. [3](file:///articles/s42005-021-00790-2#Equ3) to [5,](file:///articles/s42005-021-00790-2#Equ5) we can see that the frequency conversion is mainly enabled by the Fourier component of the \(a(t)\) as the term \(A\_{m m^{\prime}}\) for a conversion from \(m^{\prime}\)-th harmonics to m-th harmonics. The signal at the incident frequency is controlled by the direct current (DC) component: \(A\_0\). We note that in the above harmonic model for simplicity, we have omitted the broadband response of the speaker and microphone, effectively lumped into g as a frequency-independent constant as approximation. The harmonic model and time-domain simulation model

with frequency dispersive speaker and microphone response are detailed in Supplementary Notes [1−3](file:///articles/s42005-021-00790-2#MOESM1) while the above harmonic model is presented in brevity.

## **Unidirectional amplification**

With the reference static meta-atom, we apply an amplitude modulation \(a(t) \) to obtain a time-varying meta-atom. Figure [2a](file:///articles/s42005-021-00790-2#Fig2) shows the experimental results of forward reflection spectrum \(r\_{{{{{{{\mathrm{f}}}}}}}}/i\) (revealing polarizability of a meta-atom) along the 1D waveguide for three amplitude-modulated cases (symbols) with fixed duty-cycle \(\xi = 0.5\) and modulation frequency \(F = 90\,{{{{{{{\mathrm{Hz}}}}}}}}\). The first case is a square-wave modulation with \(a\_1 = 1\) and \(a\_2 = 0.6\) on the meta-atom, and the measured reflection spectra \ (r\_{{{{{{{\mathrm{f}}}}}}}}/i\) are plotted as symbols in black color in Fig. [2a.](file:///articles/s42005-021-00790-2#Fig2) Here, the measurement is done on the same frequency as the incident frequency (\(f\_{{{{{{{{\mathrm{out}}}}}}}}} = f\_{{{{{{{{\mathrm{in}}}}}}}}}\)). Both the real and imaginary part of reflection spectrum for such a time-varying meta-atom shows a Lorentzian line shape and match well with the reflection spectrum for a static meta-atom (black line) with an effective amplitude \(\bar a = (a\_1 + a\_2)/2 = 0.8\) (black line). Such an average effect has also been verified in the same figure for the case involved the material gain: an amplitude modulation with \(a\_1 = 1.4\) and \(a\_2 = - 0.6\) (red symbols) to give an effective strength \(\bar a = 0.4\) (red line). Such an equivalence can be derived from the harmonic model (Eqs. [3−](file:///articles/s42005-021-00790-2#Equ3)[5\)](file:///articles/s42005-021-00790-2#Equ5) with the approximation that if the incident frequency is around resonance, the frequency-converted signal has only a small chance by another frequency conversion back to the incident frequency. Then, the harmonic response at the incidence frequency is dominated by \(A\_0 = \bar a\). Based on this effect, we can obtain a time-varying meta-atom with nearly zero reflection spectrum at the incident frequency (blue symbols) by applying an amplitude modulation with \(a\_1 = 1\) and \(a\_2 = - 1\) (effective strength \(\bar a = 0\): zero DC value of the modulation). In such a case, the reflection amplitude at the m-th harmonics approximately come from the \(Y\_{m,0}\) or the \(A\_m\) term in Eq. [3](file:///articles/s42005-021-00790-2#Equ3).

**Fig. 2: Efficient frequency conversion for a single timevarying meta-atom with temporally balanced gain and loss.** [figure 2](file:///articles/s42005-021-00790-2/figures/2)

**a** The experimentally extracted forward reflection coefficient (\ (r\_{{{{{{{\mathrm{f}}}}}}}}/i\)) for a time-varying meta-atom with different modulation amplitudes (symbols) or the static counterpart with effectively averaged resonance strength (lines). The filled (empty) symbols and solid (dashed) lines denote the real (imaginary) parts. **b** The 2D map of the forward reflection amplitude \(|r\_{{{{{{{\mathrm{f}}}}}}}}|\) (plotted against input and output frequencies \(f\_{{{{{{{{\mathrm{in}}}}}}}}}\) and \(f\_{{{{{{{{\mathrm{out}}}}}}}}}\)) for a time-varying meta-atom, where the dimensionless reflection amplitude for each harmonics is normalized to the amplitude of the incident field at input frequency. **c** The amplitude of forward reflection amplitude for different order harmonics against the modulation duty-cycle \(\xi\) at a fixed input frequency \(f\_{{{{{{{{\mathrm{in}}}}}}}}} = 1\,{{{{{{{\mathrm{kHz}}}}}}}}\).

#### [Full size image](file:///articles/s42005-021-00790-2/figures/2)

Figure [2b](file:///articles/s42005-021-00790-2#Fig2) shows the whole spectrum for such a time-varying meta-atom for \ (f\_{{{{{{{{\mathrm{in}}}}}}}}}\) from 750 Hz to 1250 Hz while \ (f\_{{{{{{{{\mathrm{out}}}}}}}}}\) is measured from 650 Hz to 1350 Hz. It clearly shows a diminished the harmonic at incident frequency (\(m = 0\)) due to the temporally balanced gain and loss. In addition, the harmonics of \ (m = \pm 1,3\) generated by frequency conversion \ (f\_{{{{{{{{\mathrm{out}}}}}}}}} = f\_{{{{{{\rm{in}}}}}}} + mF\) (dashed lines labeling the different \(m\)) show significant reflectance amplitude. It is observed that the 1-st order harmonics (\(m = \pm 1\)) are more prominent, and the presence of resonance greatly enhances the conversion efficiency (reaching around 60% near the resonating frequency at 1 kHz). As shown in Fig. [2c](file:///articles/s42005-021-00790-2#Fig2), when duty cycle \(\xi\) varies from 0 to 1 for incident frequency at 1 kHz while the modulation frequency is still kept at constant 90 Hz, the gain-loss balance only happens at \(\xi = 0.5\) to get diminished at the 0-th order harmonics (\ (f\_{{{{{{{{\mathrm{out}}}}}}}}} = f\_{{{{{{{{\mathrm{in}}}}}}}}} = 1\,{{{{{{{\mathrm{kHz}}}}}}}}\)) and most prominent converted harmonics (see more gain-loss balance case in Supplementary Note [4](file:///articles/s42005-021-00790-2#MOESM1)). At \ (\xi = 0\) (\(\xi = 1\)), the atom goes back to the static atom with gain (loss), no frequency conversion occurs as expected. We note that the up-converted mode has a larger amplitude than the down-converted mode due to the frequency dispersive response of the speaker and detector (see Supplementary Note [1\)](file:///articles/s42005-021-00790-2#MOESM1).

With such time-varying meta-atoms, we now design the non-Hermitian space−time varying metamaterials. Figure [3a](file:///articles/s42005-021-00790-2#Fig3) shows such a configuration of two meta-atoms, captured in terms of an "energy-level" diagram for two meta-atoms with the same resonating frequency (1 kHz) and modulation frequency (90 Hz). The yellow bars describe the levels with resonance, and the levels with black color denote those allowed levels satisfying frequency transition rule: \(f\_{{{{{{{{\mathrm{out}}}}}}}}} = f\_{{{{{{{{\mathrm{in}}}}}}}}} + mF\). The thin arrows indicate the allowed frequency transitions in the presence of resonating mode, starting from a resonating level (yellow bar) to the converted levels (black bars). In the current case, we only focus on the m = 1 and m = −1 transitions by fixing the incident wave at 1 kHz (thick red arrow). Different from the case of a single meta-atom, there can be more than one path to get a specific frequency conversion performed. Take the harmonics of m = −1 as an example, the incident wave at 1 kHz resonantly excites atom 1 and has a frequency transition to 910 Hz by a first order down conversion (red arrow). On the other hand, the incident wave equivalently excites atom 2 and have the same frequency down conversion (gray arrow). These two paths can now undergo interference with each other.

**Fig. 3: Unidirectional amplification in a non-Hermitian space−time varying metamaterial.**

#### [figure 3](file:///articles/s42005-021-00790-2/figures/3)

**a** The "energy-level" diagram for two time-varying meta-atoms with the same resonance frequency (yellow bars) and modulation frequency, and a modulation phase delay \({{\Delta }}\phi\) is applied on atom 2. **b** The 2D map of the \(\left| {r\_{{{{{{{\mathrm{f}}}}}}}}} \right|\) against the modulation phase delay \({{\Delta }}\phi\) and the output frequency, where arrows indicate the destructive dip position calculated from the harmonic model. The forward and backward reflection amplitudes spectra with different interference conditions reveal the asymmetric scattering property for both m = −1 (**c**) and m = 1 harmonics (**d**). Particularly, unidirectional amplification occurs around \({{\Delta }}\phi = 1.4\pi\) for the harmonic with m = 1. Here symbols represent the experimental results, and dashed lines represent the numerical simulation results.

#### [Full size image](file:///articles/s42005-021-00790-2/figures/3)

The modulation phase delay \({{\Delta }}\phi\) between the two meta-atoms provides us a flexible knob to control such an analogy of quantum interference. Figure [3b](file:///articles/s42005-021-00790-2#Fig3) shows the experimentally extracted forward reflection amplitude \(\left| {r\_{{{{{{{\mathrm{f}}}}}}}}} \right|\), the reflection of the harmonic at incident frequency (\(f\_{{{{{{{{\mathrm{out}}}}}}}}} = f\_{{{{{{{{\mathrm{in}}}}}}}}} = 1\,{{{{{{{\mathrm{kHz}}}}}}}}\)) remains low in magnitude due to the gain-loss balance in temporal domain, and the amplitude of converted harmonics (for both m = −1 and m = 1) varies with \({{\Delta }}\phi\), which are also shown in details in Fig. [3c](file:///articles/s42005-021-00790-2#Fig3) and [3d](file:///articles/s42005-021-00790-2#Fig3) respectively. Taking m = 1 as example (\(1000\, {{{{{{{\mathrm{Hz}}}}}}}} \to 1090\,{{{{{{{\mathrm{Hz}}}}}}}}\), Fig. [3d](file:///articles/s42005-021-00790-2#Fig3)), the experiment results (symbols) match well with the numerical results based on the harmonic model (lines) (see details in Supplementary Note [3](file:///articles/s42005-021-00790-2#MOESM1)). The interference dips indicated by arrows in Fig. [3d](file:///articles/s42005-021-00790-2#Fig3) are obtained from the destructive interference condition (see details in Supplementary Note [5](file:///articles/s42005-021-00790-2#MOESM1)):

```
$$\, \pm {{\Delta }}\phi + \frac{{2\pi f_{{{{{{{{\mathrm{in}}}}}}}}}
\ell }}{c} + \frac{{2\pi f_{{{{{{{{\mathrm{out}}}}}}}}}\ell }}{c} =
\left( {2n + 1} \right)\pi ,\,n \in {\Bbb Z}$$
(6)
```

where \(+ ( - )\) sign indicates for the case of forward (backward) incidence. At \({{\Delta }}\phi = 1.4\pi\) where the measured backward reflection amplitude \(\left| {r\_{{{{{{{\mathrm{b}}}}}}}}} \right| = 0.06\) is minimum (destructive interference), the measured forward reflection amplitude can actually achieve a maximum at \(\left| {r\_{{{{{{{\mathrm{f}}}}}}}}} \right| = 1.51\) (constructive interference), giving us a unidirectional amplification phenomenon. Huge contrast in reflection amplitude is also found in other phenomena like unidirectional invisibility and non-Hermitian exceptional point[49](file:///articles/s42005-021-00790-2#ref-CR49)[,50](file:///articles/s42005-021-00790-2#ref-CR50), while the combination of non-Hermiticity and time-varying capability allows us to generalize it to frequency-converted signals and the contrast can be even made larger with

amplification on one side incidence. The demonstrated unidirectional amplification comes from the ability of having gain in one direction but not the other direction. In fact, the system also needs to work in the regime of stability, which is particularly important when we have gain in the system. For the current case of two time-varying meta-atoms, the stability condition can be obtained by requesting all the poles of the system response matrix from Eq. [5](file:///articles/s42005-021-00790-2#Equ5), equivalently the zeros of \(\det \left( {I - {{{{{{{\mathcal{T}}}}}}}}(f)} \right) = 0\), lying on the lower half of the complex frequency plane. Detailed theoretical analysis (in Supplementary Note [6](file:///articles/s42005-021-00790-2#MOESM1)) confirms the stability of the system, until we increase the resonating strength of the meta-atoms to at least 4.8 times of the current value. In reality, the frequency-dispersive speaker and microphone responses complicate the analysis while experimentally, the resonating strength can be increased to around 5.7 times of the current value until sound in audible level is observed with no incident waves to indicate the stability threshold.

## **Analogy of quantum interference with design capability**

The interference between different pathways in the "energy-level" diagram mimics quantum interference, which is the fundamental building block in many quantum phenomena, such as electromagnetically induced transparency[51](file:///articles/s42005-021-00790-2#ref-CR51). Our system allows very flexible control on these interference pathways with tailor-made energy levels. Figure [4a](file:///articles/s42005-021-00790-2#Fig4) shows a representative example that atom 2 has doubled modulation frequency (\(F\_2 = 2F\_1 = 180\,{{{{{{{\mathrm{Hz}}}}}}}}\)), an additional modulation phase delay induced by the time delay Δt, defined as \({{\Delta }}\phi = 2\pi F\_1{{\Delta }}t\). For this configuration, two meta-atoms have different resonating frequencies, as shown in the "energy level" diagram in Fig. [4b](file:///articles/s42005-021-00790-2#Fig4). Here we take the frequency conversion process from 910 Hz to 1180 Hz as an example to illustrate the interference: an up-conversion of m = 3 at atom 1 (red arrow) is competing with an up-conversion of m = 1 at atom 1 and a successive up-conversion of m = 1 at atom 2 (two gray arrows). Two different pathways to the same level interference with each other, and such an interference can be controlled by varying \({{\Delta }}\phi\), as shown in Fig. [4c](file:///articles/s42005-021-00790-2#Fig4) (green symbols for experimental data and line for numerical results). Similar interference also occurs for frequency conversion 910 Hz to 820 Hz (black symbols and line).

#### **Fig. 4: Analogy of quantum interference with design capability.** [figure 4](file:///articles/s42005-021-00790-2/figures/4)

**a** The schematic of amplitude modulation for two time-varying meta-atoms, where atom 2 has doubled modulation frequency (\ (F\_2 = 2\,F\_1 = 180\,{{{{{{{\mathrm{Hz}}}}}}}}\)) and an additional modulation time delay Δt. **b** The "energy-level" diagram for two time-varying meta-atoms with asymmetric frequency coupling. **c** Forward transmission amplitude \(| t\_{{{{{{{\mathrm{f}}}}}}}}|\) spectra for input frequency at 910 Hz. **d** Backward transmission amplitude \(|

t\_{{{{{{{\mathrm{b}}}}}}}}|\) for input frequency at 1 kHz, with the interference "turned off". In **c** and **d**, symbols represent the

experimental results, dashed lines represent the numerical simulation results, and arrows in **c** indicate the dip positions predicted from destructive interference conditions (see details in Supplementary Note [5\)](file:///articles/s42005-021-00790-2#MOESM1).

#### [Full size image](file:///articles/s42005-021-00790-2/figures/4)

In this example, two different resonating frequencies of two meta-atoms can be used to achieve asymmetric coupling between the two meta-atoms for the transition selectivity at resonance. For an incident wave at 910 Hz, resonating at atom 1, the transition of m = 1 brings it to 1 kHz and then resonantly excites atom 2. However, in the reverse direction in frequency, for an incident wave at 1 kHz, resonating at atom 2, the transition of \(m = \pm 1\) can only bring it to 1180 Hz or 820 Hz with significant efficiency, but leaving nearly no waves emitted at 910 Hz to interact with atom 1. This leads to asymmetric frequency coupling from atom 1 to atom 2 (\(910\, {{{{{{{\mathrm{Hz}}}}}}}} \to 1000\,{{{{{{{\mathrm{Hz}}}}}}}}\)) versus no coupling from atom 2 to atom 1 (\(1000\, {{{{{{{\mathrm{Hz}}}}}}}} \to 910\,{{{{{{{\mathrm{Hz}}}}}}}}\)). Figure [4c](file:///articles/s42005-021-00790-2#Fig4) shows the forward transmission amplitude (blue color) around 0.35 for conversion 910 Hz→1000 Hz, while Fig. [4d](file:///articles/s42005-021-00790-2#Fig4) shows a much smaller backward transmission amplitude (red color, around 0.03) for conversion \(1000\,{{{{{{{\mathrm{Hz}}}}}}}} \to 910\, {{{{{{{\mathrm{Hz}}}}}}}}.\) Such a transmission amplitude contrast between forward and backward directions in converting between two modes shares similar features with non-reciprocal transmission[23](file:///articles/s42005-021-00790-2#ref-CR23),[27](file:///articles/s42005-021-00790-2#ref-CR27)[,40](file:///articles/s42005-021-00790-2#ref-CR40)[,42](file:///articles/s42005-021-00790-2#ref-CR42) .

## **Conclusions**

In this work, we have established a non-Hermitian space−time varying metamaterial with alternating gain and loss material parameters in the temporal domain. The temporally balanced gain and loss diminishes the reflected signal for the harmonic with incident frequency while the modulation with gain allows us to put the power into the frequency-converted signal instead. A modulation phase delay between different meta-atoms further adds asymmetric control to the system[21,](file:///articles/s42005-021-00790-2#ref-CR21)[52](file:///articles/s42005-021-00790-2#ref-CR52). In our case, unidirectional amplification in the frequency-converted signal is realized by tuning the modulation phase delay. In forward incidence, the signal amplitude is amplified by more than 1.5 times for up conversion from 1 kHz to 1090 Hz in reflection, while in backward direction for the same up conversion, the reflection remains nearly zero. We can easily change from unidirectional amplification in the forward direction to backward direction or turn it off simply by varying the modulation phase delay between the two atoms. It is worth to mention that the amplification ratio is only limited by the gain provided by the external power to the meta-atoms through the microcontrollers subject to system stability. Our platform can be readily extended to time-varying systems with more meta-atoms like space−time modulated gradient metasurfaces[53](file:///articles/s42005-021-00790-2#ref-CR53) and offers further opportunities in studying non-Hermitian topological physics in dynamic and nonreciprocal systems. Increasing the modulation frequency to work in the temporal effective medium regime, our metamaterial can also be readily extended to

explore the spatiotemporal effective medium incorporating with gain and loss[17](file:///articles/s42005-021-00790-2#ref-CR17)[,39](file:///articles/s42005-021-00790-2#ref-CR39)[,54](file:///articles/s42005-021-00790-2#ref-CR54). In addition, our non-Hermitian space−time varying metamaterials, with the unit-cell size less than λ/8(0.04 m) with unidirectional amplification, provide great potential for ultra-compact acoustic devices.

# **Methods**

## **Experiment setup and measurement**

```
The 1D acoustic waveguide, made of acryl material, has multiple holes on the
top cover for the insertion of microphones and speakers of the active
metamaterial atoms. The distance between two neighboring holes is 0.02 m,
the distance \(\ell\) between two meta-atoms is 0.04 m (less than \(\lambda /
8\)). Each meta-atom consists of one speaker (ESE Audio Speaker, with a size
of \(15\,{{{{{{{\mathrm{mm}}}}}}}} \times 25\,
{{{{{{{\mathrm{mm}}}}}}}}\)) and one microphone (Sound Sensor V2
Waveshare, with a size of \(18.7\,{{{{{{{\mathrm{mm}}}}}}}} \times
34.4\,{{{{{{{\mathrm{mm}}}}}}}}\)) interconnecting by a microprocessor
(Adafruit ItsyBitsy M4 Express, with a size of \(17.8\,
{{{{{{{\mathrm{mm}}}}}}}} \times 35.8\,
{{{{{{{\mathrm{mm}}}}}}}}\)) for digital feedback. For the digital
convolution, the microprocessor is programmed to operate at a sampling
frequency of 7.2 kHz (with sampling period Ts
                                             = 138.7 μs). For the
implementation, a time domain convolution kernel \(y\left( t \right) = g\sin
( {2\pi f_{{{{{{{{\mathrm{res}}}}}}}}}( {t - \delta
t_{{{{{{{{\mathrm{prog}}}}}}}}}} )} ){{{{{\rm{e}}}}}}^{ - 2\pi
\gamma \left( {t - \delta t_{{{{{{{{\mathrm{prog}}}}}}}}}} \right)}\) for \
(t \, > \, \delta t_{{{{{{{{\mathrm{prog}}}}}}}}}\) and \(0\) for \(t < \delta
t_{{{{{{{{\mathrm{prog}}}}}}}}}\) is defined in the program, with \
(\delta t_{{{{{{{{\mathrm{prog}}}}}}}}}\) being the time delay set in the
program. The convolution kernel \(y(t)\) and microphone signal \(D(t)\) are
sampled at every sampling period, and performs convolution operation in a
discretized form: \(y\left( t \right) \ast D\left( t \right) \cong
T_{{{{{{{\mathrm{s}}}}}}}}\mathop {\sum}\nolimits_{j = 0}^{N - 1}
{y\left( {jT_{{{{{{{\mathrm{s}}}}}}}}} \right)D\left( {t -
jT_{{{{{{{\mathrm{s}}}}}}}}} \right)}\), where N = 400 samples are
taken in the convolution as an approximation in which \(y\) decays to small
values after N samples. A periodic amplitude modulation \(a(t)\) is then
applied on the convoluted results, and the difference between the current
and the last output (and divided by \(T_{{{{{{{\mathrm{s}}}}}}}}\)) is put
to the speaker in approximating a continuous operation \(\partial
_t\left( {a(t)y\left( {{{{{{{\mathrm{t}}}}}}}} \right)^\ast D\left( t \right)}
\right)\). For static atoms, \(a\left( t \right) = 1\) is time-independent.
Consequently, the discrete signal processing in the program can be written
as: \(S\left[ k \right] = a\left[ k \right]\mathop {\sum}\nolimits_{j = 0}^{N-1}
{y\left[ j \right]D\left[ {k - j} \right] - a\left[ {k - 1} \right]} \mathop {\sum}
\nolimits_{j = 0}^{N-1} {y\left[ j \right]D\left[ {k - j - 1} \right]}\). Moreover,
such an operation has to be corrected by the combined speaker and
microphone response (see details in Supplementary Notes 1−3).
```

For the measurement, we use the 4-point measurement method with four Brüel & Kjær microphone (Type 4958), a National Instruments DAQ device, and LabVIEW. An incident pulse coming from the speaker located at either end propagates to the other end of the waveguide with an absorptive boundary made of acoustic foams. Each experiment lasts for one second, while the incident pulse has center frequency \

(f\_{{{{{{{{\mathrm{in}}}}}}}}}\) and pulse width 0.16 s. We scan the center frequency of an input cosine-squared pulse with a pulse width of 0.16 s and with a center frequency from 750 to 1250 Hz with a step 10 Hz to generate 2D map of reflection amplitude spectra in Fig. [2b](file:///articles/s42005-021-00790-2#Fig2). For the atoms in Figs. [3](file:///articles/s42005-021-00790-2#Fig3) and [4](file:///articles/s42005-021-00790-2#Fig4), we launch the same input pulse with a particular incident frequency from forward and backward direction respectively to obtain the corresponding scattering parameters.

# **Code availability**

The codes used in making the plots in this paper and other findings of this study are available from the corresponding author upon reasonable request.

# **Data availability**

The data that support the plots in this paper and other findings of this study are available from the corresponding author upon reasonable request.

# **References**

<span id="page-13-0"></span>Yu, N. et al. Light propagation with phase discontinuities: Generalized laws of reflection and refraction. Science **334**, 333–337 (2011). 1.

[Article](https://doi.org/10.1126%2Fscience.1210713) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011Sci...334..333Y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Light%20propagation%20with%20phase%20discontinuities%3A%20Generalized%20laws%20of%20reflection%20and%20refraction&journal=Science&doi=10.1126%2Fscience.1210713&volume=334&pages=333-337&publication_year=2011&author=Yu%2CN)

<span id="page-13-1"></span>Liu, B. et al. Experimental realization of all-angle negative refraction in acoustic gradient metasurface. Appl. Phys. Lett. **111**, 221602 (2017). 2.

[Article](https://doi.org/10.1063%2F1.5004005) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017ApPhL.111v1602L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20realization%20of%20all-angle%20negative%20refraction%20in%20acoustic%20gradient%20metasurface&journal=Appl.%20Phys.%20Lett.&doi=10.1063%2F1.5004005&volume=111&publication_year=2017&author=Liu%2CB)

<span id="page-13-2"></span>Roy, T., Rogers, E. T. & Zheludev, N. I. Sub-wavelength focusing metalens. Opt. Express **21**, 7577–7582 (2013). 3.

[Article](https://doi.org/10.1364%2FOE.21.007577) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013OExpr..21.7577R) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Sub-wavelength%20focusing%20meta-lens&journal=Opt.%20Express&doi=10.1364%2FOE.21.007577&volume=21&pages=7577-7582&publication_year=2013&author=Roy%2CT&author=Rogers%2CET&author=Zheludev%2CNI)

<span id="page-13-3"></span>Ren, H. et al. Metasurface orbital angular momentum holography. Nat. Commun. **10**, 1–8 (2019). 4.

[Article](https://doi.org/10.1038%2Fs41467-019-11030-1) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019NatCo..10....1K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Metasurface%20orbital%20angular%20momentum%20holography&journal=Nat.%20Commun.&doi=10.1038%2Fs41467-019-11030-1&volume=10&pages=1-8&publication_year=2019&author=Ren%2CH)

<span id="page-13-4"></span>Alù, A. Mantle cloak: Invisibility induced by a surface. Phys. Rev. B **80**, 245115 (2009). 5.

Ni, X., Wong, Z. J., Mrejen, M., Wang, Y. & Zhang, X. An ultrathin invisibility skin cloak for visible light. Science **349**, 1310–1314 (2015). 6.

[Article](https://doi.org/10.1126%2Fscience.aac9411) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015Sci...349.1310N) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20ultrathin%20invisibility%20skin%20cloak%20for%20visible%20light&journal=Science&doi=10.1126%2Fscience.aac9411&volume=349&pages=1310-1314&publication_year=2015&author=Ni%2CX&author=Wong%2CZJ&author=Mrejen%2CM&author=Wang%2CY&author=Zhang%2CX)

<span id="page-14-0"></span>Tao, H. et al. Reconfigurable terahertz metamaterials. Phys. Rev. Lett. **103**, 147401 (2009). 7.

[Article](https://doi.org/10.1103%2FPhysRevLett.103.147401) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2009PhRvL.103n7401T) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reconfigurable%20terahertz%20metamaterials&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.103.147401&volume=103&publication_year=2009&author=Tao%2CH)

<span id="page-14-1"></span>Popa, B. I., Shinde, D., Konneker, A. & Cummer, S. A. Active acoustic metamaterials reconfigurable in real time. Phys. Rev. B **91**, 220303 (2015). 8.

[Article](https://doi.org/10.1103%2FPhysRevB.91.220303) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015PhRvB..91v0303P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Active%20acoustic%20metamaterials%20reconfigurable%20in%20real%20time&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.91.220303&volume=91&publication_year=2015&author=Popa%2CBI&author=Shinde%2CD&author=Konneker%2CA&author=Cummer%2CSA)

<span id="page-14-2"></span>Popa, B. I., Zhai, Y. & Kwon, H. S. Broadband sound barriers with bianisotropic metasurfaces. Nat. Commun. **9**, 1–7 (2018). 9.

[Article](https://doi.org/10.1038%2Fs41467-018-07809-3) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Broadband%20sound%20barriers%20with%20bianisotropic%20metasurfaces&journal=Nat.%20Commun.&doi=10.1038%2Fs41467-018-07809-3&volume=9&pages=1-7&publication_year=2018&author=Popa%2CBI&author=Zhai%2CY&author=Kwon%2CHS)

<span id="page-14-3"></span>Chen, Y., Li, X., Nassar, H., Hu, G. & Huang, G. A programmable metasurface for real time control of broadband elastic rays. Smart Mater. Struct. **27**, 115011 (2018). 10.

[Article](https://doi.org/10.1088%2F1361-665X%2Faae27b) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2018SMaS...27k5011C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20programmable%20metasurface%20for%20real%20time%20control%20of%20broadband%20elastic%20rays&journal=Smart%20Mater.%20Struct.&doi=10.1088%2F1361-665X%2Faae27b&volume=27&publication_year=2018&author=Chen%2CY&author=Li%2CX&author=Nassar%2CH&author=Hu%2CG&author=Huang%2CG)

<span id="page-14-4"></span>Chen, Y., Li, X., Hu, G., Haberman, M. R. & Huang, G. An active mechanical Willis meta-layer with asymmetric polarizabilities. Nat. Commun. **11**, 3681 (2020). 11.

[Article](https://doi.org/10.1038%2Fs41467-020-17529-2) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2020NatCo..11.3681C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20active%20mechanical%20Willis%20meta-layer%20with%20asymmetric%20polarizabilities&journal=Nat.%20Commun.&doi=10.1038%2Fs41467-020-17529-2&volume=11&publication_year=2020&author=Chen%2CY&author=Li%2CX&author=Hu%2CG&author=Haberman%2CMR&author=Huang%2CG)

<span id="page-14-5"></span>Cho, C., Wen, X., Park, N. & Li, J. Digitally virtualized atoms for acoustic metamaterials. Nat. Ccommun. **11**, 251 (2020). 12.

[Article](https://doi.org/10.1038%2Fs41467-019-14124-y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Digitally%20virtualized%20atoms%20for%20acoustic%20metamaterials&journal=Nat.%20Ccommun.&doi=10.1038%2Fs41467-019-14124-y&volume=11&publication_year=2020&author=Cho%2CC&author=Wen%2CX&author=Park%2CN&author=Li%2CJ)

<span id="page-14-6"></span>Cui, T. J., Qi, M. Q., Wan, X., Zhao, J. & Cheng, Q. Coding metamaterials, digital metamaterials, and programmable metamaterials. Light Sci. Appl. **3**, e218–e218 (2014). 13.

[Article](https://doi.org/10.1038%2Flsa.2014.99) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014LSA.....3E.218C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Coding%20metamaterials%2C%20digital%20metamaterials%2C%20and%20programmable%20metamaterials&journal=Light%20Sci.%20Appl.&doi=10.1038%2Flsa.2014.99&volume=3&pages=e218-e218&publication_year=2014&author=Cui%2CTJ&author=Qi%2CMQ&author=Wan%2CX&author=Zhao%2CJ&author=Cheng%2CQ)

<span id="page-14-7"></span>Popa, B. I. & Cummer, S. A. Non-reciprocal and highly nonlinear active acoustic metamaterials. Nat. Commun. **5**, 3398 (2014). 14.

[Article](https://doi.org/10.1038%2Fncomms4398) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2014NatCo...5.3398P) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Non-reciprocal%20and%20highly%20nonlinear%20active%20acoustic%20metamaterials&journal=Nat.%20Commun.&doi=10.1038%2Fncomms4398&volume=5&publication_year=2014&author=Popa%2CBI&author=Cummer%2CSA)

Xia, J. P. et al. Programmable coding acoustic topological insulator. Adv. Mater. **30**, 1805002 (2018). 15.

<span id="page-15-0"></span>Ptitcyn, G., Mirmoosa, M. S. & Tretyakov, S. A. Time-modulated metaatoms. Phys. Rev. Res. **1**, 023014 (2019). 16.

[Article](https://doi.org/10.1103%2FPhysRevResearch.1.023014) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-modulated%20meta-atoms&journal=Phys.%20Rev.%20Res.&doi=10.1103%2FPhysRevResearch.1.023014&volume=1&publication_year=2019&author=Ptitcyn%2CG&author=Mirmoosa%2CMS&author=Tretyakov%2CSA)

<span id="page-15-1"></span>Huidobro, P. A., Galiffi, E., Guenneau, S., Craster, R. V. & Pendry, J. B. Fresnel drag in space−time-modulated metamaterials. Proc. Natl Acad. Sci. USA **116**, 24943–24948 (2019). 17.

[Article](https://doi.org/10.1073%2Fpnas.1915027116) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PNAS..11624943H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Fresnel%20drag%20in%20space%E2%88%92time-modulated%20metamaterials&journal=Proc.%20Natl%20Acad.%20Sci.%20USA&doi=10.1073%2Fpnas.1915027116&volume=116&pages=24943-24948&publication_year=2019&author=Huidobro%2CPA&author=Galiffi%2CE&author=Guenneau%2CS&author=Craster%2CRV&author=Pendry%2CJB)

<span id="page-15-2"></span>Zhao, J. et al. Programmable time-domain digital-coding metasurface for non-linear harmonic manipulation and new wireless communication systems. Natl Sci. Rev. **6**, 231–238 (2019). 18.

[Article](https://doi.org/10.1093%2Fnsr%2Fnwy135) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Programmable%20time-domain%20digital-coding%20metasurface%20for%20non-linear%20harmonic%20manipulation%20and%20new%20wireless%20communication%20systems&journal=Natl%20Sci.%20Rev.&doi=10.1093%2Fnsr%2Fnwy135&volume=6&pages=231-238&publication_year=2019&author=Zhao%2CJ)

<span id="page-15-3"></span>Lee, K. et al. Linear frequency conversion via sudden merging of metaatoms in time-variant metasurfaces. Nat. Photonics **12**, 765–773 (2018). 19.

[Article](https://doi.org/10.1038%2Fs41566-018-0259-4) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2018NaPho..12..765L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Linear%20frequency%20conversion%20via%20sudden%20merging%20of%20meta-atoms%20in%20time-variant%20metasurfaces&journal=Nat.%20Photonics&doi=10.1038%2Fs41566-018-0259-4&volume=12&pages=765-773&publication_year=2018&author=Lee%2CK)

<span id="page-15-4"></span>Yu, Z. & Fan, S. Complete optical isolation created by indirect interband photonic transitions. Nat. Photonics **3**, 91–94 (2009). 20.

[Article](https://doi.org/10.1038%2Fnphoton.2008.273) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2009NaPho...3...91Y) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Complete%20optical%20isolation%20created%20by%20indirect%20interband%20photonic%20transitions&journal=Nat.%20Photonics&doi=10.1038%2Fnphoton.2008.273&volume=3&pages=91-94&publication_year=2009&author=Yu%2CZ&author=Fan%2CS)

<span id="page-15-5"></span>Shen, C., Zhu, X., Li, J. & Cummer, S. A. Nonreciprocal acoustic transmission in space−time modulated coupled resonators. Phys. Rev. B **100**, 054302 (2019). 21.

[Article](https://doi.org/10.1103%2FPhysRevB.100.054302) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvB.100e4302S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20acoustic%20transmission%20in%20space%E2%88%92time%20modulated%20coupled%20resonators&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.100.054302&volume=100&publication_year=2019&author=Shen%2CC&author=Zhu%2CX&author=Li%2CJ&author=Cummer%2CSA)

<span id="page-15-6"></span>Sounas, D. L. & Alù, A. Non-reciprocal photonics based on time modulation. Nat. Photonics **11**, 774–783 (2017). 22.

[Article](https://doi.org/10.1038%2Fs41566-017-0051-x) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017NaPho..11..774S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Non-reciprocal%20photonics%20based%20on%20time%20modulation&journal=Nat.%20Photonics&doi=10.1038%2Fs41566-017-0051-x&volume=11&pages=774-783&publication_year=2017&author=Sounas%2CDL&author=Al%C3%B9%2CA)

<span id="page-15-7"></span>Zang, J. W. et al. Nonreciprocal wavefront engineering with timemodulated gradient metasurfaces. Phys. Rev. Appl. **11**, 054054 (2019). 23.

[Article](https://doi.org/10.1103%2FPhysRevApplied.11.054054) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvP..11e4054Z) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20wavefront%20engineering%20with%20time-modulated%20gradient%20metasurfaces&journal=Phys.%20Rev.%20Appl.&doi=10.1103%2FPhysRevApplied.11.054054&volume=11&publication_year=2019&author=Zang%2CJW)

<span id="page-15-8"></span>Wang, Y. et al. Observation of nonreciprocal wave propagation in a dynamic phononic lattice. Phys. Rev. Lett. **121**, 194301 (2018). 24.

[Article](https://doi.org/10.1103%2FPhysRevLett.121.194301) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2018PhRvL.121s4301W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Observation%20of%20nonreciprocal%20wave%20propagation%20in%20a%20dynamic%20phononic%20lattice&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.121.194301&volume=121&publication_year=2018&author=Wang%2CY)

<span id="page-15-9"></span>Marconi, J. et al. Experimental observation of nonreciprocal band gaps in a space−time-modulated beam using a shunted piezoelectric array. Phys. Rev. Appl. **13**, 031001 (2020). 25.

<span id="page-16-0"></span>Taravati, S., Chamanara, N. & Caloz, C. Nonreciprocal electromagnetic scattering from a periodically space−time modulated slab and application to a quasisonic isolator. Phys. Rev. B **96**, 165144 (2017). 26.

[Article](https://doi.org/10.1103%2FPhysRevB.96.165144) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2017PhRvB..96p5144T) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20electromagnetic%20scattering%20from%20a%20periodically%20space%E2%88%92time%20modulated%20slab%20and%20application%20to%20a%20quasisonic%20isolator&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.96.165144&volume=96&publication_year=2017&author=Taravati%2CS&author=Chamanara%2CN&author=Caloz%2CC)

<span id="page-16-1"></span>Guo, X., Ding, Y., Duan, Y. & Ni, X. Nonreciprocal metasurface with space−time phase modulation. Light Sci. Appl. **8**, 1–9 (2019). 27.

[Article](https://doi.org/10.1038%2Fs41377-019-0225-z) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20metasurface%20with%20space%E2%88%92time%20phase%20modulation&journal=Light%20Sci.%20Appl.&doi=10.1038%2Fs41377-019-0225-z&volume=8&pages=1-9&publication_year=2019&author=Guo%2CX&author=Ding%2CY&author=Duan%2CY&author=Ni%2CX)

<span id="page-16-2"></span>Chen, Y. et al. Nonreciprocal wave propagation in a continuum-based metamaterial with space−time modulated resonators. Phys. Rev. Appl. **11**, 064052 (2019). 28.

[Article](https://doi.org/10.1103%2FPhysRevApplied.11.064052) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvP..11f4052C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20wave%20propagation%20in%20a%20continuum-based%20metamaterial%20with%20space%E2%88%92time%20modulated%20resonators&journal=Phys.%20Rev.%20Appl.&doi=10.1103%2FPhysRevApplied.11.064052&volume=11&publication_year=2019&author=Chen%2CY)

<span id="page-16-3"></span>Li, J., Shen, C., Zhu, X., Xie, Y. & Cummer, S. A. Nonreciprocal sound propagation in space−time modulated media. Phys. Rev. B **99**, 144311 (2019). 29.

[Article](https://doi.org/10.1103%2FPhysRevB.99.144311) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvB..99n4311L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20sound%20propagation%20in%20space%E2%88%92time%20modulated%20media&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.99.144311&volume=99&publication_year=2019&author=Li%2CJ&author=Shen%2CC&author=Zhu%2CX&author=Xie%2CY&author=Cummer%2CSA)

Li, J., Zhu, X., Shen, C., Peng, X. & Cummer, S. A. Transfer matrix method for the analysis of space−time-modulated media and systems. Phys. Rev. B **100**, 144311 (2019). 30.

[Article](https://doi.org/10.1103%2FPhysRevB.100.144311) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvB.100n4311L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Transfer%20matrix%20method%20for%20the%20analysis%20of%20space%E2%88%92time-modulated%20media%20and%20systems&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.100.144311&volume=100&publication_year=2019&author=Li%2CJ&author=Zhu%2CX&author=Shen%2CC&author=Peng%2CX&author=Cummer%2CSA)

Bacot, V., Labousse, M., Eddi, A., Fink, M. & Fort, E. Time reversal and holography with spacetime transformations. Nat. Phys. **12**, 972–977 (2016). 31.

[Article](https://doi.org/10.1038%2Fnphys3810) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time%20reversal%20and%20holography%20with%20spacetime%20transformations&journal=Nat.%20Phys.&doi=10.1038%2Fnphys3810&volume=12&pages=972-977&publication_year=2016&author=Bacot%2CV&author=Labousse%2CM&author=Eddi%2CA&author=Fink%2CM&author=Fort%2CE)

Bacot, V., Durey, G., Eddi, A., Fink, M. & Fort, E. Phase-conjugate mirror for water waves driven by the Faraday instability. Proc. Natl Acad. Sci. USA **116**, 8809–8814 (2019). 32.

[Article](https://doi.org/10.1073%2Fpnas.1818742116) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PNAS..116.8809B) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Phase-conjugate%20mirror%20for%20water%20waves%20driven%20by%20the%20Faraday%20instability&journal=Proc.%20Natl%20Acad.%20Sci.%20USA&doi=10.1073%2Fpnas.1818742116&volume=116&pages=8809-8814&publication_year=2019&author=Bacot%2CV&author=Durey%2CG&author=Eddi%2CA&author=Fink%2CM&author=Fort%2CE)

Cullen, A. L. A travelling-wave parametric amplifier. Nature **181**, 332– 332 (1958). 33.

[Article](https://doi.org/10.1038%2F181332a0) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1958Natur.181..332C) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20travelling-wave%20parametric%20amplifier&journal=Nature&doi=10.1038%2F181332a0&volume=181&pages=332-332&publication_year=1958&author=Cullen%2CAL)

Koutserimpas, T. T., Alù, A. & Fleury, R. Parametric amplification and bidirectional invisibility in PT-symmetric time-Floquet systems. Phys. Rev. A **97**, 013839 (2018). 34.

<span id="page-17-0"></span>Xu, X. et al. Physical observation of a robust acoustic pumping in waveguides with dynamic boundary. Phys. Rev. Lett. **125**, 253901 (2020). 35.

[Article](https://doi.org/10.1103%2FPhysRevLett.125.253901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2020PhRvL.125y3901X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Physical%20observation%20of%20a%20robust%20acoustic%20pumping%20in%20waveguides%20with%20dynamic%20boundary&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.125.253901&volume=125&publication_year=2020&author=Xu%2CX)

<span id="page-17-1"></span>Darabi, A., Ni, X., Leamy, M. & Alù, A. Reconfigurable Floquet elastodynamic topological insulator based on synthetic angular momentum bias. Sci. Adv. **6**, eaba8656 (2020). 36.

[Article](https://doi.org/10.1126%2Fsciadv.aba8656) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2020SciA....6.8656D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reconfigurable%20Floquet%20elastodynamic%20topological%20insulator%20based%20on%20synthetic%20angular%20momentum%20bias&journal=Sci.%20Adv.&doi=10.1126%2Fsciadv.aba8656&volume=6&publication_year=2020&author=Darabi%2CA&author=Ni%2CX&author=Leamy%2CM&author=Al%C3%B9%2CA)

Xia, Y. et al. Experimental observation of temporal pumping in electromechanical waveguides. Phys. Rev. Lett. **126**, 095501 (2021). 37.

[Article](https://doi.org/10.1103%2FPhysRevLett.126.095501) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2021PhRvL.126i5501X) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20observation%20of%20temporal%20pumping%20in%20electromechanical%20waveguides&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.126.095501&volume=126&publication_year=2021&author=Xia%2CY)

Pacheco-Peña, V. & Engheta, N. Effective medium concept in temporal metamaterials. Nanophotonics **9**, 379–391 (2020). 38.

[Article](https://doi.org/10.1515%2Fnanoph-2019-0305) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Effective%20medium%20concept%20in%20temporal%20metamaterials&journal=Nanophotonics&doi=10.1515%2Fnanoph-2019-0305&volume=9&pages=379-391&publication_year=2020&author=Pacheco-Pe%C3%B1a%2CV&author=Engheta%2CN)

Wen, X., Zhu, X., Wu, H. W. & Li, J. Realizing spatiotemporal effective media for acoustic metamaterials. Phys. Rev. B **104**, L060304 (2021). 39.

[Article](https://doi.org/10.1103%2FPhysRevB.104.L060304) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2021PhRvB.104f0304W) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Realizing%20spatiotemporal%20effective%20media%20for%20acoustic%20metamaterials&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.104.L060304&volume=104&publication_year=2021&author=Wen%2CX&author=Zhu%2CX&author=Wu%2CHW&author=Li%2CJ)

Shaltout, A., Kildishev, A. & Shalaev, V. Time-varying metasurfaces and Lorentz non-reciprocity. Opt. Mater. Exp. **5**, 2459–2467 (2015). 40.

[Article](https://doi.org/10.1364%2FOME.5.002459) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015OMExp...5.2459S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-varying%20metasurfaces%20and%20Lorentz%20non-reciprocity&journal=Opt.%20Mater.%20Exp.&doi=10.1364%2FOME.5.002459&volume=5&pages=2459-2467&publication_year=2015&author=Shaltout%2CA&author=Kildishev%2CA&author=Shalaev%2CV)

Trainiti, G. et al. Time-periodic stiffness modulation in elastic metamaterials for selective wave filtering: Theory and experiment. Phys. Rev. Lett. **122**, 124301 (2019). 41.

[Article](https://doi.org/10.1103%2FPhysRevLett.122.124301) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvL.122l4301T) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-periodic%20stiffness%20modulation%20in%20elastic%20metamaterials%20for%20selective%20wave%20filtering%3A%20Theory%20and%20experiment&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.122.124301&volume=122&publication_year=2019&author=Trainiti%2CG)

Koutserimpas, T. T. & Fleury, R. Nonreciprocal gain in non-Hermitian time-Floquet systems. Phys. Rev. Lett. **120**, 087401 (2018). 42.

[Article](https://doi.org/10.1103%2FPhysRevLett.120.087401) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2018PhRvL.120h7401K) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Nonreciprocal%20gain%20in%20non-Hermitian%20time-Floquet%20systems&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.120.087401&volume=120&publication_year=2018&author=Koutserimpas%2CTT&author=Fleury%2CR)

Song, A. Y., Shi, Y., Lin, Q. & Fan, S. Direction-dependent parity-time phase transition and nonreciprocal amplification with dynamic gain-loss modulation. Phys. Rev. A **99**, 013824 (2019). 43.

[Article](https://doi.org/10.1103%2FPhysRevA.99.013824) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvA..99a3824S) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Direction-dependent%20parity-time%20phase%20transition%20and%20nonreciprocal%20amplification%20with%20dynamic%20gain-loss%20modulation&journal=Phys.%20Rev.%20A&doi=10.1103%2FPhysRevA.99.013824&volume=99&publication_year=2019&author=Song%2CAY&author=Shi%2CY&author=Lin%2CQ&author=Fan%2CS)

Chitsazi, M., Li, H., Ellis, F. M. & Kottos, T. Experimental realization of Floquet PT-symmetric systems. Phys. Rev. Lett. **119**, 093901 (2017). 44.

Li, M., Ni, X., Weiner, M., Alù, A. & Khanikaev, A. B. Topological phases and nonreciprocal edge states in non-Hermitian Floquet insulators. Phys. Rev. B **100**, 045423 (2019). 45.

[Article](https://doi.org/10.1103%2FPhysRevB.100.045423) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2019PhRvB.100d5423L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Topological%20phases%20and%20nonreciprocal%20edge%20states%20in%20non-Hermitian%20Floquet%20insulators&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.100.045423&volume=100&publication_year=2019&author=Li%2CM&author=Ni%2CX&author=Weiner%2CM&author=Al%C3%B9%2CA&author=Khanikaev%2CAB)

Fang, N. et al. Ultrasonic metamaterials with negative modulus. Nat. Mater. **5**, 452–456 (2006). 46.

[Article](https://doi.org/10.1038%2Fnmat1644) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2006NatMa...5..452F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Ultrasonic%20metamaterials%20with%20negative%20modulus&journal=Nat.%20Mater.&doi=10.1038%2Fnmat1644&volume=5&pages=452-456&publication_year=2006&author=Fang%2CN)

- Mirmoosa, M. S., Koutserimpas, T. T., Ptitcyn, G. A., Tretyakov, S. A., & Fleury, R. Dipole polarizability of time-varying particles. Preprint at <https://arxiv.org/abs/2002.12297> (2020). 47.
- Solís, D. M., Kastner, R., & Engheta, N. Time-varying materials in presence of dispersion: Plane-wave propagation in a Lorentzian medium with temporal discontinuity. Photon. Res. 9,1842–1853 (2021). 48.

[Article](https://doi.org/10.1364%2FPRJ.427368) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Time-varying%20materials%20in%20presence%20of%20dispersion%3A%20Plane-wave%20propagation%20in%20a%20Lorentzian%20medium%20with%20temporal%20discontinuity&journal=Photon.%20Res&doi=10.1364%2FPRJ.427368&volume=9&pages=1842-1853&publication_year=2021&author=Sol%C3%ADs%2CDM&author=Kastner%2CR&author=Engheta%2CN)

Lin, Z. et al. Unidirectional invisibility induced by PT-symmetric periodic structures. Phys. Rev. Lett. **106**, 213901 (2011). 49.

[Article](https://doi.org/10.1103%2FPhysRevLett.106.213901) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2011PhRvL.106u3901L) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Unidirectional%20invisibility%20induced%20by%20PT-symmetric%20periodic%20structures&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.106.213901&volume=106&publication_year=2011&author=Lin%2CZ)

Feng, L. et al. Experimental demonstration of a unidirectional reflectionless parity-time metamaterial at optical frequencies. Nat. Mater. **12**, 108–113 (2013). 50.

[Article](https://doi.org/10.1038%2Fnmat3495) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2013NatMa..12..108F) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Experimental%20demonstration%20of%20a%20unidirectional%20reflectionless%20parity-time%20metamaterial%20at%20optical%20frequencies&journal=Nat.%20Mater.&doi=10.1038%2Fnmat3495&volume=12&pages=108-113&publication_year=2013&author=Feng%2CL)

Boller, K. J., Imamoğlu, A. & Harris, S. E. Observation of electromagnetically induced transparency. Phys. Rev. Lett. **66**, 2593 (1991). 51.

[Article](https://doi.org/10.1103%2FPhysRevLett.66.2593) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=1991PhRvL..66.2593B) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Observation%20of%20electromagnetically%20induced%20transparency&journal=Phys.%20Rev.%20Lett.&doi=10.1103%2FPhysRevLett.66.2593&volume=66&publication_year=1991&author=Boller%2CKJ&author=Imamo%C4%9Flu%2CA&author=Harris%2CSE)

Williamson, I. A. et al., Integrated nonreciprocal photonic devices with dynamic modulation. Proc. IEEE, 108, 1759–1784 (2020). 52.

[Article](https://doi.org/10.1109%2FJPROC.2020.3023959) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Integrated%20nonreciprocal%20photonic%20devices%20with%20dynamic%20modulation&journal=Proc.%20IEEE&doi=10.1109%2FJPROC.2020.3023959&volume=108&pages=1759-1784&publication_year=2020&author=Williamson%2CIA)

Hadad, Y., Sounas, D. L. & Alu, A. Space−time gradient metasurfaces. Phys. Rev. B **92**, 100304 (2015). 53.

[Article](https://doi.org/10.1103%2FPhysRevB.92.100304) [ADS](http://adsabs.harvard.edu/cgi-bin/nph-data_query?link_type=ABSTRACT&bibcode=2015PhRvB..92j0304H) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Space%E2%88%92time%20gradient%20metasurfaces&journal=Phys.%20Rev.%20B&doi=10.1103%2FPhysRevB.92.100304&volume=92&publication_year=2015&author=Hadad%2CY&author=Sounas%2CDL&author=Alu%2CA)

Pacheco-Peña, V. & Engheta, N. Temporal metamaterials with gain and loss. Preprint at<https://arxiv.org/abs/2108.01007>(2021). 54.

[Download references](https://citation-needed.springer.com/v2/references/10.1038/s42005-021-00790-2?format=refman&flavour=references)

# **Acknowledgements**

The work is supported by Hong Kong Research Grants Council (RGC) grant (Project Nos. 16303019, C6013-18G, AoE/P-502/20) and by the Croucher Foundation. M.F. and F.L. acknowledge partial support from the Simons Foundation/Collaboration on Symmetry-Driven Extreme Wave Phenomena. T.W.Y. acknowledges support from the Hong Kong RGC Grant AoE P-02/12 and the support from the College of Mathematics and Physics at QUST.

# **Author information**

## **Authors and Affiliations**

<span id="page-19-1"></span>Department of Physics, The Hong Kong University of Science and Technology, Clear Water Bay, Kowloon, Hong Kong, China 1.

Xinhua Wen, Xinghong Zhu, Alvin Fan, Wing Yim Tam, Hong Wei Wu & Jensen Li

<span id="page-19-5"></span>Department of Mechanical Engineering, the Hong Kong Polytechnic University, Hung Hom, Kowloon, Hong Kong, China 2.

Jie Zhu

<span id="page-19-6"></span>Institut Langevin, ESPCI Paris, PSL University, CNRS, 1 rue Jussieu, 75005, Paris, France 3.

Fabrice Lemoult & Mathias Fink

#### Authors

<span id="page-19-0"></span>Xinhua Wen [View author publications](file:///search?author=Xinhua%20Wen) 1.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xinhua%20Wen) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xinhua%20Wen%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-19-2"></span>Xinghong Zhu [View author publications](file:///search?author=Xinghong%20Zhu) 2.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Xinghong%20Zhu) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Xinghong%20Zhu%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-19-3"></span>Alvin Fan [View author publications](file:///search?author=Alvin%20Fan) 3.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Alvin%20Fan) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Alvin%20Fan%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-19-4"></span>Wing Yim Tam [View author publications](file:///search?author=Wing%20Yim%20Tam) 4.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Wing%20Yim%20Tam) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Wing%20Yim%20Tam%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-20-0"></span>Jie Zhu 5.

[View author publications](file:///search?author=Jie%20Zhu)

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Jie%20Zhu) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Jie%20Zhu%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-20-1"></span>Hong Wei Wu [View author publications](file:///search?author=Hong%20Wei%20Wu) 6.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Hong%20Wei%20Wu) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Hong%20Wei%20Wu%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-20-2"></span>Fabrice Lemoult [View author publications](file:///search?author=Fabrice%20Lemoult) 7.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Fabrice%20Lemoult) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Fabrice%20Lemoult%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-20-3"></span>Mathias Fink [View author publications](file:///search?author=Mathias%20Fink) 8.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Mathias%20Fink) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Mathias%20Fink%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-20-4"></span>Jensen Li [View author publications](file:///search?author=Jensen%20Li) 9.

Search author on:[PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Jensen%20Li) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Jensen%20Li%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

## **Contributions**

J.L. and M.F. conceived the idea of time-varying metamaterials on efficient side-band conversion with amplification and effective responses. J.L. and F.L. initiated the setup of the time-varying design. X.W. and X.Z. completed the setup and conducted the experiments. X.W., J.Z., H.W., and J.L. did the data analysis and the numerical models. A.F., W.Y.T., and H.W. provided insightful comments on the theoretical explanation. All authors contributed to scientific discussions of the results, explanations and wrote the manuscript.

## **Corresponding authors**

Correspondence to [Mathias Fink](mailto:mathias.fink@espci.fr) or [Jensen Li](mailto:jensenli@ust.hk).

# **Ethics declarations**

## **Competing interests**

The authors declare no competing interests.

# **Peer review information**

Communications Physics thanks Junfei Li and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available.

# **Additional information**

**Publisher's note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

# **Supplementary information**

**[Supplementary Information](https://static-content.springer.com/esm/art%3A10.1038%2Fs42005-021-00790-2/MediaObjects/42005_2021_790_MOESM1_ESM.pdf)**

**[Peer Review File](https://static-content.springer.com/esm/art%3A10.1038%2Fs42005-021-00790-2/MediaObjects/42005_2021_790_MOESM2_ESM.pdf)**

# **Rights and permissions**

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article's Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article's Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit [http://creativecommons.org/](http://creativecommons.org/licenses/by/4.0/) [licenses/by/4.0/](http://creativecommons.org/licenses/by/4.0/).

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=Unidirectional%20amplification%20with%20acoustic%20non-Hermitian%20space%E2%88%92time%20varying%20metamaterial&author=Xinhua%20Wen%20et%20al&contentID=10.1038%2Fs42005-021-00790-2©right=The%20Author%28s%29&publication=2399-3650&publicationDate=2022-01-11&publisherName=SpringerNature&orderBeanReset=true&oa=CC%20BY)

# **About this article**

![](_page_21_Picture_9.jpeg)

### <span id="page-21-0"></span>**Cite this article**

Wen, X., Zhu, X., Fan, A. et al. Unidirectional amplification with acoustic non-Hermitian space−time varying metamaterial. Commun Phys **5**, 18 (2022). https://doi.org/10.1038/s42005-021-00790-2

#### [Download citation](https://citation-needed.springer.com/v2/references/10.1038/s42005-021-00790-2?format=refman&flavour=citation)

Received: 29 June 2021 •

Accepted: 16 December 2021 •

Published: 11 January 2022 •

DOI: https://doi.org/10.1038/s42005-021-00790-2 •

# **This article is cited by**

- **[Active control of electroacoustic resonators in the](https://doi.org/10.1038/s44384-025-00006-9) [audible regime: control strategies and airborne](https://doi.org/10.1038/s44384-025-00006-9) [applications](https://doi.org/10.1038/s44384-025-00006-9)**  •
  - Matthieu Malléjac ◦
  - Maxime Volery ◦
  - Romain Fleury ◦

npj Acoustics (2025)

- **[Non-Hermitian delocalization induced by residue](https://doi.org/10.1038/s42005-025-02196-w) [imaginary velocity](https://doi.org/10.1038/s42005-025-02196-w)**  •
  - Shi-Xin Hu ◦
  - Yongxu Fu ◦
  - Yi Zhang ◦

Communications Physics (2025)

- **[Observation of dynamic non-Hermitian skin effects](https://doi.org/10.1038/s41467-024-50776-1)**  •
  - Zhen Li ◦
  - Li-Wei Wang ◦
  - Jian-Hua Jiang ◦

Nature Communications (2024)

- **[Observation of non-reciprocal harmonic conversion in](https://doi.org/10.1038/s42005-023-01217-w) [real sounds](https://doi.org/10.1038/s42005-023-01217-w)**  •
  - Xinxin Guo ◦
  - Hervé Lissek ◦
  - Romain Fleury ◦

Communications Physics (2023)

- **[Acoustic resonances in non-Hermitian open systems](https://doi.org/10.1038/s42254-023-00659-z)**  •
  - Lujun Huang ◦
  - Sibo Huang ◦
  - Andrey E. Miroshnichenko ◦

Nature Reviews Physics (2023)

[Download PDF](file:///articles/s42005-021-00790-2.pdf)

#### [Advertisement](file://pubads.g.doubleclick.net/gampad/jump?iu=/285/commsphys.nature.com/article&sz=300x250&c=213153767&t=pos%3Dright%26type%3Darticle%26artid%3Ds42005-021-00790-2%26doi%3D10.1038/s42005-021-00790-2%26subjmeta%3D1005,1007,25,301,3927,639,766%26kwrd%3DAcoustics,Electronic+devices)

# <span id="page-23-1"></span>**Explore content**

- [Research articles](file:///commsphys/research-articles) •
- [Reviews & Analysis](file:///commsphys/reviews-and-analysis)  •
- [News & Comment](file:///commsphys/news-and-comment) •
- [Collections](file:///commsphys/collections)  •
- [Follow us on Twitter](https://twitter.com/CommsPhys) •
- [Sign up for alerts](https://journal-alerts.springernature.com/subscribe?journal_id=42005) •
- [RSS feed](https://www.nature.com/commsphys.rss) •

# <span id="page-23-2"></span>**About the journal**

- [Aims & Scope](file:///commsphys/aims) •
- [Journal Information](file:///commsphys/journal-information) •
- [Open Access Fees and Funding](file:///commsphys/open-access) •
- [Journal Metrics](file:///commsphys/journal-impact) •
- [Editors](file:///commsphys/editors) •
- [Editorial Board](file:///commsphys/editorial-board)  •
- [Calls for Papers](file:///commsphys/calls-for-papers) •
- [Editorial Values Statement](file:///commsphys/editorial-values-statement)  •
- [Editorial policies](file:///commsphys/editorial-policies)  •
- [Referees](file:///commsphys/referees)  •
- [Conferences](file:///commsphys/conferences) •
- [Contact](file:///commsphys/contact)  •

# <span id="page-23-3"></span>**Publish with us**

- [For authors](file:///commsphys/submit)  •
- [Language editing services](https://authorservices.springernature.com/go/sn/?utm_source=For+Authors&utm_medium=Website_Nature&utm_campaign=Platform+Experimentation+2022&utm_id=PE2022)  •
- [Open access funding](file:///commsphys/open-access-funding) •
- [Submit manuscript](https://mts-commsphys.nature.com) •

# <span id="page-23-0"></span>**Search**

Search articles by subject, keyword or author Show results from Search [Advanced search](file:///search/advanced) All journals ˅

# **Quick links**

[Explore articles by subject](file:///subjects) •

- [Find a job](file:///naturecareers) •
- [Guide to authors](file:///authors/index.html) •
- [Editorial policies](file:///authors/editorial_policies/) •

Communications Physics (Commun Phys)

ISSN 2399-3650 (online)

# **nature.com sitemap**

## **About Nature Portfolio**

- [About us](https://www.nature.com/npg_/company_info/index.html) •
- [Press releases](https://www.nature.com/npg_/press_room/press_releases.html) •
- [Press office](https://press.nature.com/) •
- [Contact us](https://support.nature.com/support/home) •

## **Discover content**

- [Journals A-Z](https://www.nature.com/siteindex) •
- [Articles by subject](https://www.nature.com/subjects) •
- [protocols.io](https://www.protocols.io/) •
- [Nature Index](https://www.natureindex.com/) •

## **Publishing policies**

- [Nature portfolio policies](https://www.nature.com/authors/editorial_policies) •
- [Open access](https://www.nature.com/nature-research/open-access) •

## **Author & Researcher services**

- [Reprints & permissions](https://www.nature.com/reprints) •
- [Research data](https://www.springernature.com/gp/authors/research-data) •
- [Language editing](https://authorservices.springernature.com/language-editing/) •
- [Scientific editing](https://authorservices.springernature.com/scientific-editing/) •
- [Nature Masterclasses](https://masterclasses.nature.com/) •
- [Research Solutions](https://solutions.springernature.com/) •

## **Libraries & institutions**

- [Librarian service & tools](https://www.springernature.com/gp/librarians/tools-services) •
- [Librarian portal](https://www.springernature.com/gp/librarians/manage-your-account/librarianportal) •
- [Open research](https://www.nature.com/openresearch/about-open-access/information-for-institutions) •
- [Recommend to library](https://www.springernature.com/gp/librarians/recommend-to-your-library) •

## **Advertising & partnerships**

- [Advertising](https://partnerships.nature.com/product/digital-advertising/) •
- [Partnerships & Services](https://partnerships.nature.com/) •
- [Media kits](https://partnerships.nature.com/media-kits/) •

[Branded content](https://partnerships.nature.com/product/branded-content-native-advertising/) •

## **Professional development**

- [Nature Awards](https://www.nature.com/immersive/natureawards/index.html) •
- [Nature Careers](https://www.nature.com/naturecareers/) •
- Nature [Conferences](https://conferences.nature.com) •

## **Regional websites**

- [Nature Africa](https://www.nature.com/natafrica) •
- [Nature China](http://www.naturechina.com) •
- [Nature India](https://www.nature.com/nindia) •
- [Nature Japan](https://www.natureasia.com/ja-jp) •
- [Nature Middle East](https://www.nature.com/nmiddleeast) •
- [Privacy Policy](https://www.nature.com/info/privacy) •
- [Use of cookies](https://www.nature.com/info/cookies) •
- Your privacy choices/Manage cookies •
- [Legal notice](https://www.nature.com/info/legal-notice) •
- [Accessibility statement](https://www.nature.com/info/accessibility-statement) •
- [Terms & Conditions](https://www.nature.com/info/terms-and-conditions) •
- [Your US state privacy rights](https://www.springernature.com/ccpa) •

#### [Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature Limited

Close

#### Nature Briefing

Sign up for the Nature Briefing newsletter — what matters in science, free to your inbox daily.

|  | MainBriefingBanner |
|--|--------------------|
|  | DirectEmailBanner  |
|  | false              |
|  | false              |

| false                                                                                                                 |  |
|-----------------------------------------------------------------------------------------------------------------------|--|
| MainBriefingBanner                                                                                                    |  |
| Email address                                                                                                         |  |
|                                                                                                                       |  |
| true                                                                                                                  |  |
| Sign up                                                                                                               |  |
| I agree my information will be processed in accordance with the Nature and<br>Springer Nature Limited Privacy Policy. |  |

Close

Get the most important science stories of the day, free in your inbox. [Sign up](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner) [for Nature Briefing](https://www.nature.com/briefing/signup/?brieferEntryPoint=MainBriefingBanner)