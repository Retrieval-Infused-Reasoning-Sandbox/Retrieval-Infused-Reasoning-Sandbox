#### [Academia.eduAcademia.edu](https://www.academia.edu/)

![](_page_0_Figure_1.jpeg)

- [Log In](https://www.academia.edu/login) •
- [Sign Up](https://www.academia.edu/signup) •
- •

![](_page_0_Picture_5.jpeg)

#### more

- [About](https://www.academia.edu/about) • ◦
  - [Press](https://www.academia.edu/press) ◦
  - [Papers](https://www.academia.edu/documents) ◦
  - [Terms](https://www.academia.edu/terms) ◦
  - [Privacy](https://www.academia.edu/privacy) ◦
  - [Copyright](https://www.academia.edu/copyright) ◦

![](_page_1_Picture_1.jpeg)

We're Hiring!

![](_page_2_Picture_0.jpeg)

![](_page_2_Picture_1.jpeg)

**Help Center** 

![](_page_3_Picture_1.jpeg)

#### less

#### Outline

### keyboard\_arrow\_down

[Title](#page-4-0)

[Abstract](#page-4-1)

[Key Takeaways](#page-5-0)

Introduction

Proof of the Main Result

[References](#page-15-0)

[FAQs](#page-16-0)

[All Topics](https://www.academia.edu/topics)

[Mathematics](https://www.academia.edu/Documents/in/Mathematics)

[Pure Mathematics](https://www.academia.edu/Documents/in/Pure_Mathematics)

<span id="page-4-0"></span>![](_page_4_Picture_0.jpeg)

![](_page_4_Picture_1.jpeg)

2021, Proceedings of the American Mathematical Society <https://doi.org/10.1090/PROC/15478>

PDF Icon

# <span id="page-4-1"></span>**Abstract** download

Download Free PDF

Download Free PDF For any prime number p, and integer k 1, let F p k be the finite field of p k elements. A famous problem in the theory of polynomials over finite fields is the characterization of all nonconstant polynomials F ∈ F p k [x] for which the value set {F (α) : α ∈ F p k } has the minimum possible size (p k − 1)/ deg…

## <span id="page-5-0"></span>**Key takeaways sparkles**

## **AI**

- This paper resolves the classification of minimal value set polynomials (mvsp) for finite fields of size \$p^3\$. 1.
- It establishes that an mvsp in \$F\_{p^3}[x]\$ has a value set size of at least 2. 2.
- Theorem 1.1 details the specific forms of polynomials that qualify as mvsp for \$k=3\$. 3.
- The work builds upon previous classifications for \$k=2\$ by Carlitz et al. from the 1960s. 4.
- The study connects mvsp theory to Frobenius nonclassical curves, enhancing applications in coding theory. 5.

## **Related papers**

[On the value set of small families of polynomials over a finite field, I](https://www.academia.edu/101404753/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_I) [Melina Privitelli](https://independent.academia.edu/MelinaPrivitelli)

Journal of Combinatorial Theory, Series A, 2014

We obtain an estimate on the average cardinality of the value set of any family of monic polynomials of F q [T ] of degree d for which s consecutive coefficients a d−1 ,. .. , a d−s are fixed. Our estimate holds without restrictions on the characteristic of F q and asserts that V(d, s, a) = µ d q + O(1), where V(d, s, a) is such an average cardinality, µ d := d r=1 (−1) r−1 /r! and a := (a d−1 ,. .. , d d−s). We provide an explicit upper bound for the constant underlying the O-notation in terms of d and s with "good" behavior. Our approach reduces the question to estimate the number of F q-rational points with pairwise-distinct coordinates of a certain family of complete intersections defined over F q. We show that the polynomials defining such complete intersections are invariant under the action of the symmetric group of permutations of the coordinates. This allows us to obtain critical information concerning the singular locus of the varieties under consideration, from which a suitable estimate on the number of F q-rational points is established.

downloadDownload free PDF[View PDF](https://www.academia.edu/101404753/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_I)[chevron\\_right](https://www.academia.edu/101404753/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_I) [On the value set of small families of polynomials over a finite field, III](https://www.academia.edu/112477368/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_III) [Melina Privitelli](https://independent.academia.edu/MelinaPrivitelli)

arXiv (Cornell University), 2015

We estimate the average cardinality V(A) of the value set of a general family A of monic univariate polynomials of degree d with coefficients in the finite field Fq. We establish conditions on the family A under which V(A) = µ d q + O(q 1/2), where µ d := d r=1 (−1) r−1 /r!. The result holds without any restriction on the characteristic of Fq and provides an explicit expression for

the constant underlying the O-notation in terms of d. We reduce the question to estimating the number of Fq-rational points with pairwise-distinct coordinates of a certain family of complete intersections defined over Fq. For this purpose, we obtain an upper bound on the dimension of the singular locus of the complete intersections under consideration, which allows us to estimate the corresponding number of Fq-rational points.

downloadDownload free PDF[View PDF](https://www.academia.edu/112477368/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_III)[chevron\\_right](https://www.academia.edu/112477368/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_III) [N T \] 1 1 O ct 2 01 3 ON THE VALUE SET OF SMALL FAMILIES OF POLYNOMIALS](https://www.academia.edu/101404771/N_T_1_1_O_ct_2_01_3_ON_THE_VALUE_SET_OF_SMALL_FAMILIES_OF_POLYNOMIALS_OVER_A_FINITE_FIELD) [OVER A FINITE FIELD](https://www.academia.edu/101404771/N_T_1_1_O_ct_2_01_3_ON_THE_VALUE_SET_OF_SMALL_FAMILIES_OF_POLYNOMIALS_OVER_A_FINITE_FIELD) [Melina Privitelli](https://independent.academia.edu/MelinaPrivitelli)

We obtain an estimate on the average cardinality of the value set of any family of monic polynomials of F q [T ] of degree d for which s consecutive coefficients a d−1 ,. .. , a d−s are fixed. Our estimate holds without restrictions on the characteristic of F q and asserts that V(d, s, a) = µ d q + O(1), where V(d, s, a) is such an average cardinality, µ d := d r=1 (−1) r−1 /r! and a := (a d−1 ,. .. , d d−s). We provide an explicit upper bound for the constant underlying the O-notation in terms of d and s with "good" behavior. Our approach reduces the question to estimate the number of F q-rational points with pairwise-distinct coordinates of a certain family of complete intersections defined over F q. We show that the polynomials defining such complete intersections are invariant under the action of the symmetric group of permutations of the coordinates. This allows us to obtain critical information concerning the singular locus of the varieties under consideration, from which a suitable estimate on the number of F q-rational points is established.

downloadDownload free PDF[View PDF](https://www.academia.edu/101404771/N_T_1_1_O_ct_2_01_3_ON_THE_VALUE_SET_OF_SMALL_FAMILIES_OF_POLYNOMIALS_OVER_A_FINITE_FIELD)[chevron\\_right](https://www.academia.edu/101404771/N_T_1_1_O_ct_2_01_3_ON_THE_VALUE_SET_OF_SMALL_FAMILIES_OF_POLYNOMIALS_OVER_A_FINITE_FIELD) [On the Value Sets of Special Polynomials over Finite Fields](https://www.academia.edu/29532131/On_the_Value_Sets_of_Special_Polynomials_over_Finite_Fields) [Abramo Hefez](https://independent.academia.edu/AbramoHefez)

Finite Fields and Their Applications, 1996

downloadDownload free PDF[View PDF](https://www.academia.edu/29532131/On_the_Value_Sets_of_Special_Polynomials_over_Finite_Fields)[chevron\\_right](https://www.academia.edu/29532131/On_the_Value_Sets_of_Special_Polynomials_over_Finite_Fields) [On a conjecture of polynomials with prescribed range](https://www.academia.edu/79639194/On_a_conjecture_of_polynomials_with_prescribed_range) [Amela Muratović-Ribić](https://unsa-ba.academia.edu/AmelaMuratovi%C4%87Ribi%C4%87)

Finite Fields and Their Applications, 2012

We show that, for any integer ℓ with q − √ p − 1 ≤ ℓ < q − 3 where q = p n and p > 9, there exists a multiset M satisfying that 0 ∈ M has the highest multiplicity ℓ and b∈M b = 0 such that every polynomial over finite fields Fq with the prescribed range M has degree greater than ℓ. This implies that Conjecture 5.1. in [1] is false over finite field Fq for p > 9 and k := q − ℓ − 1 ≥ 3.

downloadDownload free PDF[View PDF](https://www.academia.edu/79639194/On_a_conjecture_of_polynomials_with_prescribed_range)[chevron\\_right](https://www.academia.edu/79639194/On_a_conjecture_of_polynomials_with_prescribed_range) [The additive index of polynomials over finite fields](https://www.academia.edu/93823457/The_additive_index_of_polynomials_over_finite_fields) [Lucas Reis](https://independent.academia.edu/LucasReis378)

Finite Fields and Their Applications, 2022

In this paper we introduce the additive analogue of the index of a polynomial over finite fields. We study several problems in the theory of polynomials over finite fields in terms of their additive indices, such as value set sizes, bounds on multiplicative character sums, and characterizations of permutation polynomials.

downloadDownload free PDF[View PDF](https://www.academia.edu/93823457/The_additive_index_of_polynomials_over_finite_fields)[chevron\\_right](https://www.academia.edu/93823457/The_additive_index_of_polynomials_over_finite_fields) [On coefficients of polynomials over finite fields](https://www.academia.edu/79639195/On_coefficients_of_polynomials_over_finite_fields) [Amela Muratović-Ribić](https://unsa-ba.academia.edu/AmelaMuratovi%C4%87Ribi%C4%87)

Finite Fields and Their Applications, 2011

In this paper we study the relation between coefficients of a polynomial over finite field F q and the moved elements by the mapping that induces the polynomial. The relation is established by a special system of linear equations. Using this relation we give the lower bound on the number of nonzero coefficients of polynomial that depends on the number m of moved elements. Moreover we show that there exist permutation polynomials of special form that achieve this bound when m | q − 1. In the other direction, we show that if the number of moved elements is small then there is an recurrence relation among these coefficients. Using these recurrence relations, we improve the lower bound of nonzero coefficients when m q−1 and m ≤ q−1 2. As a byproduct, we show that the moved elements must satisfy certain polynomial equations if the mapping induces a polynomial such that there are only two nonzero coefficients out of 2m consecutive coefficients. Finally we provide an algorithm to compute the coefficients of the polynomial induced by a given mapping with O(q 3/2) operations.

downloadDownload free PDF[View PDF](https://www.academia.edu/79639195/On_coefficients_of_polynomials_over_finite_fields)[chevron\\_right](https://www.academia.edu/79639195/On_coefficients_of_polynomials_over_finite_fields) [Distinct values of a polynomial in subsets of a finite field](https://www.academia.edu/127294526/Distinct_values_of_a_polynomial_in_subsets_of_a_finite_field) [Kenneth Williams](https://independent.academia.edu/KennethWilliams109)

Canadian Journal of Mathematics, 1969

If A is a set with only a finite number of elements, we write |A| for the number of elements in A. Let p be a large prime and let m be a positive integer fixed independently of p. We write [pm ] for the finite field with pm elements and [pm ]′ for [pm ] – {0}. We consider in this paper only subsets H of [pm ] for which |H| = h satisfies 1.1 If f(x) ∈ [pm, x] we let N(f; H) denote the number of distinct values of y in H for which at least one of the roots of f(x) = y is in [pm ]. We write d(d ≥ 1) for the degree of f and suppose throughout that d is fixed and that p ≧ p 0(d), for some prime p 0, depending only on d, which is greater than d.

downloadDownload free PDF[View PDF](https://www.academia.edu/127294526/Distinct_values_of_a_polynomial_in_subsets_of_a_finite_field)[chevron\\_right](https://www.academia.edu/127294526/Distinct_values_of_a_polynomial_in_subsets_of_a_finite_field) [Topics in Finite Fields](https://www.academia.edu/126310201/Topics_in_Finite_Fields) [Alfan Alfian](https://independent.academia.edu/AlfanAlfian19)

Contemporary Mathematics, 2015

downloadDownload free PDF[View PDF](https://www.academia.edu/126310201/Topics_in_Finite_Fields)[chevron\\_right](https://www.academia.edu/126310201/Topics_in_Finite_Fields) [Restricted sums in a field](https://www.academia.edu/72730068/Restricted_sums_in_a_field)

#### [Qing-hu Hou](https://tju.academia.edu/QinghuHou)

Acta Arithmetica, 2002

downloadDownload free PDF[View PDF](https://www.academia.edu/72730068/Restricted_sums_in_a_field)[chevron\\_right](https://www.academia.edu/72730068/Restricted_sums_in_a_field)

See full PDF downloadDownload PDF

Herivelto Borges, Lucas Reis Minimal value set polynomials over fields of size p3 Proceedings of the American Mathematical Society DOI: 10.1090/proc/ 15478 Accepted Manuscript This is a preliminary PDF of the author-produced manuscript that has been peer-reviewed and accepted for publication. It has not been copyedited, proofread, or finalized by AMS Production staff. Once the accepted manuscript has been copyedited, proofread, and finalized by AMS Production staff, the article will be published in electronic form as a "Recently Published Article" before being placed in an issue. That electronically published article will become the Version of Record. This preliminary version is available to AMS members prior to publication of the Version of Record, and in limited cases it is also made accessible to everyone one year after the publication date of the Version of Record. The Version of Record is accessible to everyone five years after publication in an issue. PROCEEDINGS OF THE AMERICAN MATHEMATICAL SOCIETY Volume 00, Number 0, Pages 000–000 S 0002-9939(XX)0000-0 MINIMAL VALUE SET POLYNOMIALS OVER FIELDS OF SIZE p3 HERIVELTO BORGES AND LUCAS REIS (Communicated by ) Abstract. For any prime number p, and integer k > 1, let Fpk be the finite field of pk elements. A famous problem in the theory of polynomials over finite fields is the characterization of all nonconstant polynomials F ∈ Fpk [x] for which the value set {F (α) : α ∈ Fpk } has the minimum possible size k (p − 1)/ deg F + 1. For k 6 2, the problem was solved in the early 1960s by Carlitz, Lewis, Mills, and Straus. This paper solves the problem for k = 3. 1. Introduction Let p be a power of a prime p, and let Fpk be the finite field of pk elements. For k any nonconstant polynomial F ∈ Fpk [x], let VF = {F (α) : α ∈ Fpk } be its value set. Since F has no more than deg F roots, one has the following trivial bound k p −1 (1.1) + 1 6 |VF | 6 pk . deg F If the lower bound in (1.1) is achieved, then F is called a minimal value set poly- nomial. Hereafter, such polynomials will be referred to by the abbreviation mvsps. In the early 1960s, motivated by a generalization of Waring's problem modulo p, Carlitz, Lewis, Mills, and Straus presented major results on the theory of minimal value set polynomials [5], [10]. In particular, they provided a complete classification of mvsps in Fpk [x] when k 6 2. Over the past decades, several authors investigated polynomials with small value sets [3], [7], [8], [14]. For instance in [3], all mvsps in Fpk [x] whose value set is a subfield of Fpk are determined. As a consequence, new mvsps, which Mills suspected did not exist, were presented in [3, Section 6]. Recently, the first author established a connection between minimal value set polynomials and Frobenius nonclassical curves [1]. These curves, introduced by Stöhr and Voloch in [13], are known for their unusual geometric and arithmetic properties, which make them suitable for applications in Coding Theory and Finite Geometry [2], [4]. Clearly, this further motivates the investigation of mvsps. Despite the significant progress over past years, the problem of determining all mvsps in Fpk [x] for k > 2 is still open (see [11, Problem 8.3.10]). This work aims to solve the problem for case k = 3. More precisely, the paper proves the following main result. Received by the editors

December 23, 2020. 2010 Mathematics Subject Classification. Primary 11T06, Secondary 11G20. The second authors was supported by FAPESP under grant 2018/03038-2. XXXX c American Mathematical Society 1 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. 2 HERIVELTO BORGES AND LUCAS REIS Theorem 1.1. Up to pre- and postcompositions with affine maps x 7→ ax + b, a polynomial F ∈ Fp3 [x] is an mvsp with value set VF satisfying r := |VF | − 1 ≥ 2 if and only if F is of one of the following types. p3 −1 (I) F (x) = x r , where r > 1 divides p3 − 1 2 (II) F (x) = (xp − bx)v , where v divides p − 1 and bp +p+1 = 1 (III) F (x) = G(x)v , where v is a proper divisor of p − 1, and G ∈ Fp3 [x] is an mvsp with value set Fp . That is, G is a nonconstant polynomial of the form 2 2 2 2 2 2 axp +p+1 + bxp +p + bp x p +1 + bp xp+1 + cxp + cp xp + cp x + d, where a, d ∈ Fp and b, c ∈ Fp3 . As a direct consequence of Theorem 1.1, the full list of Fp3 -Frobenius nonclassical curves of type y n = f (x) is obtained. This paper is organized as follows. Section 2 establishes notation and collects some preliminary results. Section 3 proves the main result. Finally, Section 4 presents some immediate consequences for the theory of Frobenius nonclassical curves. 2. Preliminaries This section provides background data used throughout the paper. In what follows, q denotes a power of a prime p, and all mvsps F ∈ Fq [x] in this paper have a value set of size |VF | > 2. The cases |VF | ≤ 2, which do not fit it in the general pattern, were handled separately in [5]. The following result is proved in [10, Theorem 1]. Theorem 2.1 (Mills). Let F be an mvsp over Fq with value set VF = {γ0 , . . . , γr }, where |VF | = r + 1 ≥ 3, and the number of pre-images of γ0 by F over Fq is at most the number of pre-images of any γi for 1 ≤ i ≤ r. Set L = gcd(F − γ0 , xq − x) Qr and T = (x − γi ). Then there exist positive integers m, k, v and polynomials i=0 A, B, N ∈ Fq [x], where L - N , such that the following hold. (1) v divides pk − 1 and vr + 1 = pmk mk (2) F = Lv N p + γ0 mk (3) L = Ap x + B p m pki −1 (4) T (x+γ 0) P x = wi x v for some w0 , . . . , wm ∈ Fq with w0 6= 0. i=0 The following result is proved in [3, Theorem 3.1], and in Theorem 2.2 and Lemma 2.4 of [2]. Theorem 2.2. Let F ∈ Fq [x] be a polynomial with value set VF = {γ0 , . . . , γr }, r > 1. Then F is an mvsp if and only if there exist a monic polynomial T ∈ Fq [x] and θ ∈ F∗q such that (2.1) T (F ) = θ(xq − x)F 0 . Qr In addition, the polynomial T is such that T = (x − γi ), and if γ0 , . . . , γr are i=0 ordered as in Theorem 2.1, then θ = −T 0 (γi ) for all γi ∈ VF \{γ0 }. The following proposition is a direct consequence of Theorem 2.2. 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. MINIMAL VALUE SET POLYNOMIALS OVER FIELDS OF SIZE p3 3 Proposition 2.3. Let F ∈ Fq [x] be an mvsp whose value set is comprised by the roots of T (x) = xr+1 − x. Then F r+1 − F = −r(xq − x)F 0 . Lemma 2.4. [10, Lemma 7] Notation as in Theorem 2.1. Suppose that L0 and N are constants. Then q is a power of pk , and F is of the form d X kj F = αLv + γ, L = β + ϕj xp , j=0 k where L splits completely over Fq , and v | (p − 1). The following result is a particular case of Theorem 2.5. in [2]. Theorem 2.5. The mvsps G ∈ Fp3 [x] with value set VG = Fp are the nonconstant polynomials of the form 2 2 2 2 2 2 axp +p+1 + bxp +p + bp x p +1 + bp xp+1 + cxp + cp xp + cp x + d, where a, d ∈ Fp and b, c ∈ Fp3 . The following is the well-known polynomial analogue of the famous abc

Conjec- ture for integers. Theorem 2.6 (Mason-Stothers). Let k be an algebraically closed field and a, b, c ∈ k[x] pairwise relatively prime polynomials such that a + b = c. If the derivative of these polynomials are not all vanishing, then max{deg(a), deg(b), deg(c)} ≤ deg(rad(abc)) − 1, where rad(abc) denotes the square-free part of abc. For convenience, we also state the following fact. Its proof is simple (see e.g. [12, Theorem 3.62]). 2 Proposition 2.7. If T = xp − αx and L = xp + βxp + γx are polynomials in Fp3 [x], then 3 (i) T divides xp − x if and only if α = µp−1 for some µ ∈ F∗p3 3 (ii) L divides xp − x if and only if β = γ p+1 , and γ = µp−1 for some µ ∈ F∗p3 . We end this section by recalling some rudiments of the Stöhr-Voloch Theory. For more details, we refer to [9, Chapter 8] and [13]. An irreducible plane curve C, defined over Fq , is called q-Frobenius nonclassical if the q-Frobenius map takes each simple point P ∈ C to the tangent line to C at P . For d := deg C > 1, there exist an exponent h with p ≤ ph ≤ d so that the intersection multiplicity i(C · TP (C); P ) of C and the tangent line TP (C) at a simple point P ∈ C is at least ph . In this setting, the number ( ph if C is q-Frobenius nonclassical (2.2) ν= 1 if C is q-Frobenius classical is called the q-Frobenius order of C. The following result follows from [13, Theorem 2.3]. Theorem 2.8 (Stöhr-Voloch). Let C be an irreducible plane curve of degree d > 1 and genus g defined over Fq . If C(Fq ) denotes the set of Fq -rational points on C, then ν(2g − 2) + (q + 2)d (2.3) #C(Fq ) ≤ . 2 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. 4 HERIVELTO BORGES AND LUCAS REIS 3. Proof of the main result Let VF = {γ0 , . . . , γr } be the value set of F , r > 1, in a way that the number of preimages of γ0 by F over Fp3 is at most the number of pre-images of any γi for 1 ≤ i ≤ r. We observe that up to pre- and post-compositions of F with affine changes of variable x 7→ ax + b, a, b ∈ Fp3 where a 6= 0, the degree and size of the value set of F is not affected. In particular, we can make the following assumption. Assumption 1: F ∈ Fp3 [x] is a monic mvsp such that F (0) = 0 = γ0 . In particular, Theorems 2.1 and 2.2 imply the following result. 3 Corollary 3.1. For L = gcd(F, xp − x), there exist positive integers m, k, v and polynomials A, B, N ∈ Fp3 [x] such that L - N , and the following hold: mk (i) v = p r −1 divides pk − 1 mk (ii) F = Lv N p mk (iii) L = Ap x + B p m pki −1 wi x v +1 for some w0 , . . . , wm ∈ Fp3 , with wm = 1 and w0 6= 0 P (iv) T = i=0 3 (v) T (F ) = θ(xp − x)F 0 , where θ = −T 0 (γi ) for all γi ∈ VF \{γ0 }. 3 p −1 Remark 3.2. Note that if F ∈ Fp3 [x] is an mvsp with |VF | = r + 1, then r = b deg Fc gives p3 − 1 (3.1) deg F 6 . r Lemma 3.3. Notation as in Corollary 3.1. (i) If deg N > 1, then m = 1. (ii) If deg L0 > 1, then m = k = 1. Proof. (i) Suppose deg N > 1 and m > 2. From Corollary 3.1 (ii) and Remark 3.2, we have p3 − 1 (3.2) pmk + v 6 deg F 6 , r and then mk = 2. That is, m = 2 and k = 1. In particular, Corollary 3.1 (i) gives that r > p + 1, and this clearly contradicts (3.2). (ii) if L0 is not constant, then Corollary 3.1 (ii, iii) and Remark 3.2 imply p3 − 1 v(pmk + 1) 6 deg F 6 . r Therefore, p2mk − 1 = vr(pmk + 1) 6 p3 − 1, and then m = k = 1. In view of Lemma 3.3, we split the proof of Theorem 1.1 into two main cases, N is constant or deg N > 1 and m = 1, which are considered separately. 3.1. The case N is constant. This subsection proves Theorem 1.1 for the case where N is constant, that is, N (x) = 1. The proof will be under Assumption 1, and the mvsp F ∈ Fp3 [x] will be presented up to post-composition with an affine map x 7→ ax. 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final

published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. MINIMAL VALUE SET POLYNOMIALS OVER FIELDS OF SIZE p3 5 (i) Suppose L0 is constant. From Lemma 2.4, either k = 3 and F = xv , where 3 v | (p3 − 1) or k = 1 and F = Lv , where v | (p − 1) and L is a factor of xp − x of the form 2 (3.3) L = ϕ2 xp + ϕ1 xp + ϕ0 x. Note that for case k = 3, the polynomial F is of type (I) in Theorem 1.1. The case k = 1 will depend on polynomial L, and we proceed as follows. 3 • If ϕ2 6= 0, we may assume ϕ2 = 1. Since L | xp − x, from Proposition 2.7, 2 (3.4) L = xp + ϕp+1 0 xp + ϕ0 x, where ϕ0 = µp−1 for some µ ∈ F∗p3 . 2 Since µ = (µϕp+1 0 )p = (µϕ0 )p , it follows that 2 G := µϕ0 x + µϕp+1 0 xp + µxp is an mvsp whose value set is Fp . Hence µv F = Gv , and then F is of type (III) in Theorem 1.1. • Suppose ϕ2 = 0. If ϕ1 = 0, then we may assume ϕ0 = 1, and so F = xv is of type (I) in Theorem 1.1. Now let us assume L = ϕ0 x + xp . Since 3 2 L | xp − x, Proposition 2.7 gives that b := −ϕ0 is such that bp +p+1 = 1, and then F (x) = (xp − bx)v is of type (II). (ii) Suppose L0 is not constant. From Lemma 3.3, k = m = 1, and then Corollary 3.1 (iv, v) yield 3 L(x)p + w0 L(x) = θv(xp − x)L0 (x). In particular, L is an mvsp with value set comprised by the roots of T1 := xp + w0 x. From Proposition 2.7, w0 = −δ 1−p for some δ ∈ F∗p3 , and then T1 (λ) = 0 ⇐⇒ (δλ)p − (δλ) = 0. Therefore, δL is an mvsp whose value set is Fp . Since δ v F = (δL)v , it follows that F is of type (III). mk 3.2. The case N is not constant, and m = 1 < k. Since F = Lv N p and deg F < p3 , the conditions deg N > 1 and m = 1 < k imply k = 2. Therefore, 2 3 p −1 • F = Lv N p gives deg F > p2 , and then Remark 3.2 gives r 6 deg F 6 p−1 2 • vr = p − 1, and then v > p + 1 • L0 is a p2 -th power, and then L0 is a constant. Otherwise, deg Lv > (p2 + 1)(p + 1) , which contradicts deg F < p3 . 2 Let us write L0 (x) = β. Thus F 0 = vβLv−1 N p , and Corollary 3.1 (iv, v) give 2 2 3 (3.5) w0 L + Lp N p r = θ(xp − x), for some θ ∈ Fp3 . Comparing degrees on both sides of Eq. (3.5) yields deg(L) + r · deg(N ) = p. Since L0 is constant and deg N > 1, we have that deg(L) = 1. Hence L(x) = x, as F is monic and F (0) = 0, and then Eq. (3.5) further gives N (x)r = θp xp−1 . Since N (x) is monic, N (x) = x(p−1)/ r , and so 2 2 3 −1)/r F = Lv N p = xv xp (p−1)/r = x(p is of type (I). 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. 6 HERIVELTO BORGES AND LUCAS REIS 3.3. The case N is not a constant, and m = k = 1. For this case, Corollary 3.1 3 (iv) gives T (x) = w0 x + xr+1 . Since T (x) | xp − x, it follows that w0 = −ur for ∗ some u ∈ Fp3 . Thus the vanishing polynomial of the value set of uF is xr+1 − x. We have assumed that F (0) = 0. Since |VF | > 2, there exists β ∈ Fp3 such that F (β) 6= 0. In particular, considering the substitution F 7→ uF (x + β), we can make the following assumption Assumption 2: F ∈ Fp3 [x] is an mvsp with vanishing polynomial T (x) = xr+1 − x and F (0) 6= 0 = γ0 . Note that Corollary 3.1 still holds for the polynomial F under Assumption 2. Since F 0 = v · Lv−1 · Ap N p and vr + 1 = p, Proposition 2.3 and Corollary 3.1 (iv, v) entail that 3 Lp−1+v N p(r+1) − Lv N p = −r(xp − x)v · Lv−1 · Ap N p , hence 3 Lp N rp − Ap · x − B p = (xp − x)Ap , and so 2 (3.6) (Ap · x + B p )N r = Axp + B . | {z } | {z } P1 P2 The following lemma compiles some properties of the polynomials appearing in Eq. (3.6), which are frequently noted in this paper. Lemma 3.4. Let A, B, N ∈ Fp3 [x] be as above. The following hold. (i) N (0), B(0) 6= 0, and the polynomials A, B, and N are pairwise coprime (ii) d := max{deg A, deg B} 6 p and r · deg N + (p − 1)d 6 p2 (iii) the formal

derivative N 0 of N does not vanish. Proof. (i) We have that F (0) 6= 0 gives N (0) 6= 0, and from L = Ap x + B p = 3 gcd(F, xp − x), it follows that L(0) 6= 0, and then B(0) 6= 0. In addition, since L is separable, A and B are relatively prime. Finally, from gcd(A, B) = gcd(N, x) = 1 and Eq. (3.6), it follows that gcd(N, A) = gcd(N, B) = 1. (ii) Since deg N > 1 and r > 2, comparing degrees on Eq. (3.6) yields dp + 1 < dp + r · deg N 6 d + p2 , and the assertion follows. (iii) Suppose that N has vanishing derivative. Since N is not the constant poly- nomial, deg N > p is divisible by p. Differentiating both sides of Eq. (3.6) 2 yields Ap N r = A0 xp + B 0 . A comparison of the monomials on both sides of this equation implies that A0 and B 0 are p-th powers. However, since deg A, deg B 6 p, A0 and B 0 must be constant polynomials. Moreover, since deg N > deg B, A0 must be a nonzero constant. In particular, the polynomial 2 A0 xp + B 0 is the p2 -th power of a linear polynomial. This contradicts the 2 equality Ap N r = A0 xp + B 0 , as A and N are relatively prime. Lemma 3.5. For a prime p > 5, let N ∈ Fp3 [x] be as in Lemma 3.4. If β is any root of N of multiplicity k ≥ 1, then either k ≡ 0 (mod p) or k ≡ v (mod p). 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. MINIMAL VALUE SET POLYNOMIALS OVER FIELDS OF SIZE p3 7 Proof. . Observe that if A and B were constant, then Eq. (3.6) would imply that L = Ap x + B p divides N , which contradicts Corollary 3.1. Thus we may assume that at least one of the polynomials A or B is not constant. In particular, d = max{deg A, deg B} > 0. For the Wronskian map W : Fq [x] × Fq [x] −→ Fq [x] (P, Q) 7−→ P 0 Q − P Q0 , we have that the polynomials P1 and P2 in Eq. (3.6) satisfy W (P1 , N r ) = W (P2 , N r ), and then 2 (3.7) Ap N r+1 = S · xp + T, where S = A0 N − rAN 0 and T = B 0 N − rBN 0 . Lemma 3.4 gives N 0 6= 0 and gcd(N, A) = gcd(N, B) = 1, and this readily implies that neither S nor T is van- ishing. Moreover, since gcd(N, xA) = 1, we have 2 G = gcd(Sxp , T ) = g1 g2 , p2 p2 where g1 = gcd(N r+1 , T, S) and g2 = gcd Sxg1 , gT1 , Ap = gcd Sxg1 , Ap . Since g2 divides Ap , Eq. (3.7) yields 2 Ap N r+1 Sxp T (3.8) · = + . g g g1 g2 g1 g2 | 2 {z 1 } | {z } | {z } R S1 T1 By construction, the polynomials R, S1 , and T1 are pairwise relatively prime. We claim that R is a polynomial of vanishing derivative. Our proof relies on The- orem 2.6. Set ∆ = max{deg R, deg S1 , deg T1 } and ε = deg rad(RS1 T1 ). We claim that ∆ > ε − 1. Write A(x) = xk · A0 (x), where 0 ≤ k ≤ p, and 2 Sxp p A0 ∈ Fp3 [x] is not divisible by x. Since g2 = gcd g1 , A , it follows that g2 is of the form xpk · G2 , with G2 ∈ Fp3 [x] not divisible by x. Thus equation (3.8) yields the following inequalities. deg rad(R) 6 deg A0 + deg N = deg A + deg N − k deg rad(S1 ) 6 deg S1 − (p2 − pk − 1) deg rad(T1 ) 6 deg T − pk. Therefore, ε = deg rad(R) + deg rad(S1 ) + deg rad(T1 ) 6 deg A + deg N − k + deg S1 + 1 − p2 + deg T. Since ∆ ≥ deg S1 , to prove the claim it suffices to prove that (3.9) deg A + deg N + deg T < p2 . 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409- Borges Version 2 - Submitted to Proc. Amer. Math. Soc. 8 HERIVELTO BORGES AND LUCAS REIS Note that deg T 6 deg B + deg N , and then for d = max{deg A, deg B} > 0 and p > 5, we have deg A + deg N + deg T 6 deg A + deg B + 2 deg N 6 r deg N + 2d < r deg N + (p − 1)d 6 p2 , where the last inequality follows from Lemma 3.4 (ii). This completes the proof p r+1 of ∆ > ε − 1. Now, from Theorem 2.6, R = Ag2 · Ng1 is a p-th power, and then r+1

so is Ng1 . Let β be a root of N of positive multiplicity j 6≡ 0 (mod p). Then the multiplicity of β as a root of g1 = gcd(S, T, N r+1 ) is the same as that of N r+1 gcd(N, N 0 ), which is j − 1. In particular, gcd(N,N 0 ) is a p-th power vanishing at β with multiplicity jr + 1. Therefore, jr ≡ −1 (mod p), and then vr + 1 = p gives j ≡ v (mod p). Proposition 3.6. Under Assumption 2, F = Gv for some polynomial G ∈ Fp3 [x]. In other words, N = H v for some polynomial H ∈ Fp3 [x]. Proof. We will prove that any root of N has multiplicity divisible by v. Since r > 2 and vr + 1 = p, we have that p > 3. In addition, for p = 3 we have that v = 1, and the result follows trivially. Let us assume p > 5. From Lemma 3.5, it suffices to prove that N has no root of multiplicity greater than v. Suppose N has a root with multiplicity greater than v. Since N 0 6= 0 (Lemma 3.4 (iii)), it follows that deg N > p + v. Moreover, since any root of N has a multiplicity j > v, gcd(N, N 0 ) has degree at least 1 − v1 deg N . Differentiating both sides of 2 2 Eq. (3.6), we conclude that gcd(N, N 0 ) · N r−1 divides Axp + B and A0 xp + B 0 , and then gcd(N, N 0 ) · N r−1 divides the polynomial P = A0 B − AB 0 . Since A and B are relatively prime and not both constant, it follows that P is not vanishing. Furthermore, deg A, deg B 6 p gives deg P 6 2p − 2, and then 1 (p + v) 6 deg gcd(N, N 0 ) · N r−1 6 2p − 2. r− v The latter implies that p(r + 1) − vp 6 2p, that is, r − 1 6 v1 . Since r > 2, r = 2 and v = 1. But this implies that 3 = vr + 1 = p, a contradiction with p > 5. Therefore, N (x) = uH(x)v for some H ∈ Fp3 [x] and u ∈ Fp3 . Recall that the following conditions apply: F (x) = L(x)v N (x)p has value set comprising the roots of T = x(xr − 1), where vr = p − 1. Let λ ∈ Fp3 be such that F (λ) 6= 0. Thus F (λ)r = 1, that is, upr (L(λ) · H(λ)p )p−1 = 1. Thus u = δ v for some δ ∈ F∗p3 , which gives F (x) = G(x)v for some G ∈ Fp3 [x]. 3 We now conclude the proof of Theorem 1.1. Since F r+1 −F = −r(xp −x)F 0 , we 3 have that Gp − G = (xp − x)G0 . That is, G is an mvsp whose value set is Fp , and then F is of type (III). Finally, a straightforward check shows that all polynomials listed in Theorem 1.1 are mvsps. This and Theorem 2.5 finish the proof. 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc. MINIMAL VALUE SET POLYNOMIALS OVER FIELDS OF SIZE p3 9 4. The Frobenius nonclassical curves y n = f (x) over Fp3 The Fp3 -Frobenius nonclassical curves of type y n = f (x) were partially charac- terized in [1] and [6]. In particular, for n > p3 − 1, an explicit description of such curves can be found in [1, Sections 4 and 5]. This section uses Theorem 1.1 to com- plete the characterization of Fp3 - Frobenius nonclassical curves of type y n = f (x). Let us begin with the following. Lemma 4.1. Let p be a prime and d be a proper divisor of p − 1. If a, b ∈ F∗p are such that the plane curve C : y d = axd + b has at least d(p + 1 − d) Fp -rational affine points, then d = 1. Proof. Let #C(Fp ) denote the number of Fp -rational points on C, and suppose d > 1. Since d < p, the curve C is p-Frobenius classical, and Theorem 2.8 yields d(p + d − 1) d(p + 1 − d) 6 #C(Fp ) 6 , 2 and then d > p+3 p−1 3 . Since d is a proper divisor of p − 1, d = 2 . Thus p > 3, and we can clearly assume p > 5. Note that C must have an affine point (x0 , y0 ) ∈ Fp × Fp with x0 y0 6= 0. For any such point, we have that (xd0 , y0d ) = (±1, ±1), and then b ∈ {a + 1, a − 1, −a + 1, −a − 1}. From this observation, one can easily compute the number of Fp -rational points on C, and see that p > 5 gives #C(Fp ) 6 d2 + d , which contradicts #C(Fp ) > d(p + 1 − d) = d2 + 2d. Therefore d = 1. Theorem 4.2. Let p be a prime, and let F : y n = f (x) be an irreducible plane curve of degree d > 1

defined over the finite field Fp3 . If n < p3 − 1, then F is p3 -Frobenius nonclassical if and only if the following hold. (i) n = p2 + p + 1, and 2 2 2 2 2 2 (ii) f (x) = axp +p+1 + bxp +p + bp xp +1 + bp xp+1 + cxp + cp xp + cp x + d, where a, d ∈ Fp and b, c ∈ Fp3 . 2 Proof. If an f (x) given in (ii) is such that the polynomial y p +p+1 − f (x) is ir- 2 reducible, then the Fp3 - Frobenius nonclassicality of F : y p +p+1 = f (x) follows 2 from [1, Corollary 3.5], as f (x) and y p +p+1 are mvsps with the same value set V = Fp . Conversely, suppose y n = f (x) is p3 -Frobenius nonclassical. From [1, Corollary 3.5], it follows that xn and f (x) are mvsps in Fp3 [x] with the same value 3 set. In particular, n|(p3 − 1) and |Vf | = p n−1 + 1 > 2. Thus, up to pre- and post-compositions, f (x) must be a polynomial of one of the three types given in Theorem 1.1. Proceeding to the analysis of each case, (1) if f (x) arises from a polynomial of type (I) in Theorem 1.1, then f (x) = t(rx + s)n + u, with r, s, t, u ∈ Fp3 , and F : y n = t(rx + s)n + u is a p3 -Frobenius nonclassical curve of Fermat type. From [1, Corollary 5.5], it follows that n = p2 + p + 1, and t, u ∈ F∗p . Thus f (x) is a polynomial given in (ii). (2) Note that f (x) cannot arise from a polynomial of type (II) F (x) = (xp − 2 bx)v , as | VF | − 1 = p v−1 does not divide p3 − 1. 23 isDec This 2020 06:39:31 a prepublication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409- Borges Version 2 - Submitted to Proc. Amer. Math. Soc. 10 HERIVELTO BORGES AND LUCAS REIS (3) If f (x) arises from a polynomial of type (III) in Theorem 1.1, then f (x) = t(G(rx + s))v + u, where r, s, t, u ∈ Fp3 , and G(x) and v are given as in 2 Theorem 1.1. Thus n = v(p2 + p + 1), and the curve F : y v(p +p+1) = t(G(rx + s))v + u is p3 -Frobenius nonclassical, and then so is the curve 2 (4.1) F̃ : y v(p +p+1) = t(G(x))v + u. 2 Since G(x) and y p +p+1 have the same value set V = Fp , it follows that t, u ∈ Fp . Note that if tu = 0, then the curve F̃ would be reducible. Thus t, u ∈ F∗p , and then (4.1) gives rise to a Fermat curve o degree v < p − 1 y v = txv + u which has at least v(p − v) + v Fp -rational points. From Lemma 4.1, we have v = 1, and since G(rx + s) still of the same type as G(x), the result follows. References [1] H. Borges. Frobenius nonclassical components of curves with separated variables. J. Number Theory, 159, (2016), 402–426. [2] H. Borges, R. Conceição. A new family of Castle and Frobenius nonclassical curves. Journal of Pure and Applied Algebra, 222, (2018), 994–1002. [3] H. Borges, R. Conceição. On the characterization of minimal value set polynomials. J. Number Theory, 133, (2013), 2021–2035. [4] H. Borges, A. Sepúlveda, G. Tizzotti. Weierstrass semigroup and automorphism group of the Xn,r curves. Finite Fields and Their Applications, 36, (2015), 121–132. [5] L. Carlitz, D. J. Lewis, W. H. Mills, and E. G. Straus. Polynomials over finite fields with minimal value sets. Mathematika, 8, (1961), 121–130. [6] A. Garcia. The curves y n = f (x) over finite fields. Arch. Math. (Basel), 54 (1), (1990), 36–44. [7] J. Gomez-Calderon. A note on polynomials with minimal value set over finite fields. Mathe- matika, 35, (1988), 144–148. [8] J. Gomez-Calderon and D. J. Madden. Polynomials with small value sets over finite fields. J. Number Theory, 28, (1988), 167–188. [9] J.W.P. Hirschfeld, G. Korchmáros and F. Torres. Algebraic curves over finite fields. Princeton University Press, Princeton and Oxford, 2008. [10] W. H. Mills. Polynomials with minimal value sets. Pacific J. Math., 14, (1964), 225–241. [11] G.L. Mullen, D. Panario. Handbook of Finite Fields. Series on Discrete Mathematics and Its Applications. CRC Press, Boca Raton (2013). [12] Lidl, R., Niederreiter, H. Finite fields, 2nd Edition Encyclopedia of Mathematics and its Applications. Cambridge University. Press, Cambridge,

with a foreword by P. M. Cohn.1997 [13] K.-O. Stöhr and J. F. Voloch. Weierstrass points and curves over finite fields. Proc. London Math. Soc., 3rd Ser. 52, (1986), 1–19. [14] D. Wan, P. Shiue, C.S. Chen. Value sets of polynomials over finite fields. Proc. Amer. Math. Soc. 119, (1993), 711–717. Universidade de São Paulo, Instituto de Ciências Matemáticas e de Computação, São Carlos, SP 13560-970, Brazil E-mail address: hborges@icmc.usp.br Departamento de Matemática, Universidade Federal de Minas Gerais, UFMG, Belo Horizonte, MG, 31270-901, Brazil. E-mail address: lucasreismat@mat.ufmg.br 23 isDec This 2020 06:39:31 a pre-publication PSTarticle, which may differ from the final published version. Copyright version of this Alg+NT+Comb+Logi restrictions may apply. 200409-Borges Version 2 - Submitted to Proc. Amer. Math. Soc.

## <span id="page-15-0"></span>**References (14)**

- H. Borges. Frobenius nonclassical components of curves with separated variables. J. Number Theory, 159, (2016), 402-426. 1.
- H. Borges, R. Conceição. A new family of Castle and Frobenius nonclassical curves. Journal of Pure and Applied Algebra, 222, (2018), 994-1002. 2.
- H. Borges, R. Conceição. On the characterization of minimal value set polynomials. J. Number Theory, 133, (2013), 2021-2035. 3.
- H. Borges, A. Sepúlveda, G. Tizzotti. Weierstrass semigroup and automorphism group of the Xn,r curves. Finite Fields and Their Applications, 36, (2015), 121-132. 4.
- L. Carlitz, D. J. Lewis, W. H. Mills, and E. G. Straus. Polynomials over finite fields with minimal value sets. Mathematika, 8, (1961), 121-130. 5.
- A. Garcia. The curves y n = f (x) over finite fields. Arch. Math. (Basel), 54 (1), (1990), 36-44. 6.
- J. Gomez-Calderon. A note on polynomials with minimal value set over finite fields. Mathe- matika, 35, (1988), 144-148. 7.
- J. Gomez-Calderon and D. J. Madden. Polynomials with small value sets over finite fields. J. Number Theory, 28, (1988), 167-188. 8.
- J.W.P. Hirschfeld, G. Korchmáros and F. Torres. Algebraic curves over finite fields. Princeton University Press, Princeton and Oxford, 2008. 9.
- W. H. Mills. Polynomials with minimal value sets. Pacific J. Math., 14, (1964), 225-241. 10.
- G.L. Mullen, D. Panario. Handbook of Finite Fields. Series on Discrete Mathematics and Its Applications. CRC Press, Boca Raton (2013). 11.
- Lidl, R., Niederreiter, H. Finite fields, 2nd Edition Encyclopedia of Mathematics and its Applications. Cambridge University. Press, Cambridge, with a foreword by P. M. Cohn.1997 12.
- K.-O. Stöhr and J. F. Voloch. Weierstrass points and curves over finite fields. Proc. London Math. Soc., 3rd Ser. 52, (1986), 1-19. 13.
- D. Wan, P. Shiue, C.S. Chen. Value sets of polynomials over finite fields. Proc. Amer. Math. Soc. 119, (1993), 711-717. 14.

View morearrow\_downward

## <span id="page-16-0"></span>**FAQs**

sparkles

AI

What specific conditions define a minimal value set polynomial (mvsp)?add

The paper defines an mvsp in F\_{p^3}[x] if its value set satisfies |V\_F| - 1 ≥ 2. The conditions include polynomial F being nonconstant, and specific degrees related to Frobenius properties.

How does the classification of mvsps for k=3 extend previous findings?add

The study extends the existing classification of mvsps from k=2 to k=3 by proving new forms. It identifies distinct polynomial types that achieve minimal value sets, notably G having a value set comprising F\_p.

What role do Frobenius nonclassical curves play in this research?add

Frobenius nonclassical curves connect to mvsps through unique geometric and arithmetic properties. The study establishes that specific mvsps correspond with these curves, enhancing their application in Coding Theory and Finite Geometry.

What results are derived from Theorem 2.5 regarding mvsps?add

Theorem 2.5 shows that mvsps in F\_{p^3}[x] are characterized as nonconstant polynomials of certain forms involving variables from F\_p. This characterization is critical for identifying curves with specific rational points.

Which methodologies are utilized to determine mvsps in the paper?add

The paper employs algebraic geometry principles, particularly Stöhr-Voloch Theory, alongside polynomial degree constraints. Techniques involve analyzing value sets and pre-images, providing structural insights into polynomial functions.

## **Related papers**

[On polynomials over finite fields with particular value sets](https://www.academia.edu/81073265/On_polynomials_over_finite_fields_with_particular_value_sets) [Tuğba Yesin](https://independent.academia.edu/Tu%C4%9FbaYesin)

2017

A classical result on value sets of non-permutation polynomials over finite fields is due to Wan (1993). Denoting the cardinality of the value set of f 2 Fq[x] by jVf j, Wan's result gives the upper bound JVx, where d is the degree of f. A proof of this bound due to Turnwald, which was obtained by the use of symmetric polynomials is given in Chapter 2. A generalization of this result was obtained by Aitken that we also describe here. The work of Aitken focuses on value sets of pairs of polynomials in Fq[x], in particular, he studies the size of the intersection of their value sets. We present pairs of particular polynomials whose value sets do not only have the same size but are actually identical. Clearly, a permutation polynomial f of Fq[x] satisfies jVf j = q. In Chapter 3, we discuss permutation behaviour of pairs of polynomials in Fq[x].

downloadDownload free PDF[View PDF](https://www.academia.edu/81073265/On_polynomials_over_finite_fields_with_particular_value_sets)[chevron\\_right](https://www.academia.edu/81073265/On_polynomials_over_finite_fields_with_particular_value_sets) [A Note on Value Sets of Polynomials over Finite Fields](https://www.academia.edu/67459887/A_Note_on_Value_Sets_of_Polynomials_over_Finite_Fields) [Leyla Işık](https://independent.academia.edu/LeylaI%C5%9F%C4%B1k)

2017

Most results on the value sets \$V\_f\$ of polynomials \$f \in \mathbb{F}\_q[x]\$ relate the cardinality \$|V\_f|\$ to the degree of \$f\$. In particular, the structure of the spectrum of the class of polynomials of a fixed degree \$d\$ is rather well known. We consider a class \$\mathcal{F}\_{q,n}\$ of polynomials, which we obtain by modifying linear permutations at \$n\$ points. The study of the spectrum of \$\mathcal{F}\_{q,n}\$ enables us to obtain a simple description of polynomials \$F \in \mathcal{F}\_{q,n}\$ with prescribed \$V\_F\$, especially those avoiding a given set, like cosets of subgroups of the multiplicative group \$\mathbb{F}\_q^\*\$. The value set count for such \$F\$ can also be determined. This yields polynomials with evenly distributed values, which have small maximum count.

downloadDownload free PDF[View PDF](https://www.academia.edu/67459887/A_Note_on_Value_Sets_of_Polynomials_over_Finite_Fields)[chevron\\_right](https://www.academia.edu/67459887/A_Note_on_Value_Sets_of_Polynomials_over_Finite_Fields) [Value sets of polynomials over finite fields](https://www.academia.edu/49445130/Value_sets_of_polynomials_over_finite_fields) [Peter Shiue](https://independent.academia.edu/PeterShiue)

Proceedings of the American Mathematical Society, 1993

Let ¥q be the finite field of q elements, and let Vf be the number of values taken by a polynomial f{x) over ¥q. We establish a lower bound and an upper bound of Vf in terms of certain invariants of f(x). These bounds improve and generalize some of the previously known bounds of Vf. In particular, the classical Hermite-Dickson criterion is improved. Our bounds also give a new proof of a recent theorem of Evans, Greene, and Niederreiter. Finally, we give some examples which show that our bounds are sharp.

downloadDownload free PDF[View PDF](https://www.academia.edu/49445130/Value_sets_of_polynomials_over_finite_fields)[chevron\\_right](https://www.academia.edu/49445130/Value_sets_of_polynomials_over_finite_fields) [On the characterization of minimal value set polynomials](https://www.academia.edu/11271827/On_the_characterization_of_minimal_value_set_polynomials) [Ricardo Conceição](https://independent.academia.edu/RicardoConcei%C3%A7%C3%A3o1)

Journal of Number Theory, 2013

We give an explicit characterization of all minimal value set polynomials in F q [x] whose set of values is a subfield F q ′ of F q . We show that the set of such polynomials, together with the constants of F q ′ , is an F q ′ -vector space of dimension 2 [Fq:F q ′ ] . Our approach not only provides the exact number of such polynomials, but also yields a construction of new examples of minimal value set polynomials for some other fixed value sets. In the latter case, we also derive a non-trivial lower bound for the number of such polynomials.

downloadDownload free PDF[View PDF](https://www.academia.edu/11271827/On_the_characterization_of_minimal_value_set_polynomials)[chevron\\_right](https://www.academia.edu/11271827/On_the_characterization_of_minimal_value_set_polynomials)

[On the value set of small families of polynomials over a finite field, II](https://www.academia.edu/112477372/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_II) [Melina Privitelli](https://independent.academia.edu/MelinaPrivitelli)

Acta Arithmetica, 2014

downloadDownload free PDF[View PDF](https://www.academia.edu/112477372/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_II)[chevron\\_right](https://www.academia.edu/112477372/On_the_value_set_of_small_families_of_polynomials_over_a_finite_field_II) [On Waring's problem in finite fields](https://www.academia.edu/49554541/On_Warings_problem_in_finite_fields) [Arne Winterhof](https://oeaw.academia.edu/ArneWinterhof)

Acta Arithmetica

downloadDownload free PDF[View PDF](https://www.academia.edu/49554541/On_Warings_problem_in_finite_fields)[chevron\\_right](https://www.academia.edu/49554541/On_Warings_problem_in_finite_fields) [A problem on polynomial maps over finite fields](https://www.academia.edu/56749346/A_problem_on_polynomial_maps_over_finite_fields) [S. Maubach](https://independent.academia.edu/SMaubach)

Arxiv preprint arXiv:0802.0630, 2008

Recently I noticed that an old conjecture of mine got quite some interest of peo-ple working outside of my field, especially people who work in discrete mathematics, number theory, code theory, combinatorics, even cryptographers. Due to that inter-est, I thought it might be a ...

downloadDownload free PDF[View PDF](https://www.academia.edu/56749346/A_problem_on_polynomial_maps_over_finite_fields)[chevron\\_right](https://www.academia.edu/56749346/A_problem_on_polynomial_maps_over_finite_fields) [Polynomials over Finite Fields and Applications](https://www.academia.edu/69081857/Polynomials_over_Finite_Fields_and_Applications) [Ian Blake](https://independent.academia.edu/IanBlake4)

2006

Self-reciprocal irreducible monic (srim) polyn omials over finite fields have been studied in the past. These polynomials can be studied in the context of quad ratic transformation of irreducible polynomials over finite fields. In this talk we present the generalization of some of the results known about srim polynomials to polynomials obtained by quadratic transformation of irreducible polynomials over finite fields. Speaker:Dan Bernstein (University of Illinois at Chicago) Title: Faster factorization into coprimes Abstract: How quickly can we factor a set of univariate polyn mials into coprimes? See http://cr.yp.to/coprimes.html for examples and applications. Bach, Driscoll, and Shallit chieved time n in 1990, wheren is the number of input coefficients; I achieved time n(lg n) in 1995; much more recently I achieved time n(lg n). Speaker:Antonia Bluher (National Security Agency) Title: Hyperquadratic elements of degree 4 Abstract: I will describe joint work with Alain Lasjaunias a ...

downloadDownload free PDF[View PDF](https://www.academia.edu/69081857/Polynomials_over_Finite_Fields_and_Applications)[chevron\\_right](https://www.academia.edu/69081857/Polynomials_over_Finite_Fields_and_Applications) [A note on Waring's problem in finite fields](https://www.academia.edu/49554481/A_note_on_Warings_problem_in_finite_fields) [Arne Winterhof](https://oeaw.academia.edu/ArneWinterhof)

Acta Arithmetica, 2001

downloadDownload free PDF[View PDF](https://www.academia.edu/49554481/A_note_on_Warings_problem_in_finite_fields)[chevron\\_right](https://www.academia.edu/49554481/A_note_on_Warings_problem_in_finite_fields) [On the Size of Sets in a Polynomial Variant of a Problem of Diophantus](https://www.academia.edu/86223350/On_the_Size_of_Sets_in_a_Polynomial_Variant_of_a_Problem_of_Diophantus) [Andrej Dujella](https://unizg.academia.edu/AndrejDujella)

International Journal of Number Theory, 2010

In this paper, we prove that there does not exist a set of 8 polynomials (not all constant) with coefficients in an algebraically closed field of characteristic 0 with the property that the product of any two of its distinct elements plus 1 is a perfect square.

downloadDownload free PDF[View PDF](https://www.academia.edu/86223350/On_the_Size_of_Sets_in_a_Polynomial_Variant_of_a_Problem_of_Diophantus)[chevron\\_right](https://www.academia.edu/86223350/On_the_Size_of_Sets_in_a_Polynomial_Variant_of_a_Problem_of_Diophantus) keyboard\_arrow\_downView more papers

## **Related topics**

- [Mathematics](https://www.academia.edu/Documents/in/Mathematics) addFollow •
- [Pure Mathematics](https://www.academia.edu/Documents/in/Pure_Mathematics) addFollow • [Academia](https://www.academia.edu/?source=footer)
  - Explore •
  - [Papers](https://www.academia.edu/documents) •
  - [Topics](https://www.academia.edu/topics) •
  - Features •
  - [Mentions](https://www.academia.edu/mentions) •
  - [Analytics](https://www.academia.edu/analytics) •
  - [PDF Packages](https://www.academia.edu/research) •
  - [Advanced Search](https://www.academia.edu/search/advanced) •
  - [Search Alerts](https://www.academia.edu/saved_searches) •
  - Journals •
  - [Academia.edu Journals](https://www.academia.edu/journals) •
  - [My submissions](https://www.academia.edu/journals/submissions) •
  - [Reviewer Hub](https://www.academia.edu/journals/submissions#reviewer/invitations) •
  - [Why publish with us](https://www.academia.edu/journals/about/why-publish-with-us) •
  - [Testimonials](https://www.academia.edu/journals/about/testimonials) •
  - Company •
  - [About](https://www.academia.edu/about) •
  - [Careers](https://www.academia.edu/careers) •
  - [Press](https://www.academia.edu/press) •
  - [Help Center](https://support.academia.edu/hc/en-us) •
  - [Terms](https://www.academia.edu/terms) •
  - [Privacy](https://www.academia.edu/privacy) •
  - [Copyright](https://www.academia.edu/copyright) •
  - [Content Policy](https://www.academia.edu/content_policy) •

#### [Academia](https://www.academia.edu/?source=footer)

580 California St., Suite 400 San Francisco, CA, 94104 [© 2025 Academia. All rights reserved](https://www.academia.edu/copyright)