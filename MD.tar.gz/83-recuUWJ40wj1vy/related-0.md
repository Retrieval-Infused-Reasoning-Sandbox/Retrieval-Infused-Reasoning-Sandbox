# On the characterization of minimal value set polynomials

Herivelto Borges<sup>a</sup>, Ricardo Conceição<sup>b</sup>

<sup>a</sup> Universidade de São Paulo, Inst. de Ciências Matemáticas e de Computação, São Carlos, SP 13560-970, Brazil.

### Abstract

We give an explicit characterization of all minimal value set polynomials in  $\mathbb{F}_q[x]$  whose set of values is a subfield  $\mathbb{F}_{q'}$  of  $\mathbb{F}_q$ . We show that the set of such polynomials, together with the constants of  $\mathbb{F}_{q'}$ , is an  $\mathbb{F}_{q'}$ -vector space of dimension  $2^{[\mathbb{F}_q:\mathbb{F}_{q'}]}$ . Our approach not only provides the exact number of such polynomials, but also yields a construction of new examples of minimal value set polynomials for some other fixed value sets. In the latter case, we also derive a non-trivial lower bound for the number of such polynomials.

Key words: Polynomials, Value set, Finite Field

## 1. Introduction

Let q be a power of a prime p, and for any non-constant polynomial  $F \in \mathbb{F}_q[x]$ , let  $V_F = \{F(\alpha) : \alpha \in \mathbb{F}_q\}$  be its value set. Since F has no more than deg F zeroes, one can easily show that  $V_F$  satisfies

<span id="page-0-0"></span>
$$\left| \frac{q-1}{\deg F} \right| + 1 \le |V_F| \le q,\tag{1}$$

where  $\lfloor t \rfloor$  is the greatest integer  $\leq t$ , and  $|\mathcal{S}|$  denotes the cardinality of the set  $\mathcal{S}$ . If  $|V_F|$  attains the lower bound in (1), then F is called a *minimal value set polynomial*. Throughout this text, a polynomial of this kind will be referred to by the abbreviation m. v. s. p..

In 1961, motivated by a generalization of the Waring's problem modulo p, the authors of [1] characterized m. v. s. p. 's of degree < 2p + 2. They also remarked that for any polynomial  $F \in \mathbb{F}_{q^n}[x]$ , with  $0 < \deg F \le (q^n - 1)/(q - 1)$  and  $V_F \subset \mathbb{F}_q$ , the polynomial  $G = F^a$ , where a|(q-1), is an m. v. s. p. in  $\mathbb{F}_{q^n}[x]$  (see [1, Section 5]).

<sup>&</sup>lt;sup>b</sup>Oxford College of Emory University. 100 Hamill Street, Oxford, Georgia 30054.

In 1963, W. Mills [5] provided additional results on m. v. s. p. 's and managed to characterize all m. v. s. p. 's in  $\mathbb{F}_q[x]$  of degree  $\leq \sqrt{q}$ . Such polynomials (see Theorem 2.2) turned out to be part of a larger class of m. v. s. p. 's previously presented in [1]. Mills also provided a complete classification of m. v. s. p. 's in  $\mathbb{F}_{p^2}[x]$  and remarked that for  $q > p^2$ , an m. v. s. p. different from the ones already mentioned in [1] would be unlikely to exist.

In the first part of this paper (section 2), we extend the work of Mills in two ways. First we characterize m. v. s. p. 's over  $\mathbb{F}_q$  of degree  $\sqrt{q} + 1$ ; second we show that, up to composition with degree one polynomials, there is a unique m. v. s. p. in  $\mathbb{F}_q[x]$  of degree  $\leq \sqrt{q}$  for a given set of values.

Despite the remarkable work of Mills in [5], which provides a great deal of information on m. v. s. p. 's, there exists no complete solution to the following fundamental problem:

<span id="page-1-0"></span>**Problem 1.** Given  $S \subset \mathbb{F}_q$ , can we find an m. v. s. p.  $F \in \mathbb{F}_q[x]$  with  $V_F = S$ ? If so, how many such polynomials are there? Can they be characterized?

The second part of this work is built around these questions and is organized as follows: In Section 4 we will provide a complete solution to this problem in a special but very important case: when  $\mathcal{S} = \mathbb{F}_{q'}$  is a subfield of  $\mathbb{F}_q$ . The general case is treated in Section 3, where we show how the work of Mills imposes some very restrictive and necessary conditions on  $\mathcal{S}$ . For the sets  $\mathcal{S}$  satisfying such conditions, in Section 5 we will be able to provide a partial answer to the question of the existence of m. v. s. p. 's with  $\mathcal{S}$  as its set of values and give a lower bound to the number of such polynomials. As a by-product of our constructions, we show that m. v. s. p. 's other than the ones expected by Mills do exist: a simple example being the polynomial  $F = x^{q^4+q} - x^{q^3+1}$  in  $\mathbb{F}_{q^6}[x]$ , which is addressed in Section 6.

The characterization of special classes of polynomials over finite fields, and the determination of its cardinal number are fundamental theoretical problems, which are not only worthy of study in their own right, but also because of their applications. Our interest in investigating m. v. s. p. 's is related to its potential application to the construction of new curves with many rational points, the characterization of certain Frobenius non-classical curves and the construction of elliptic curves over  $\mathbb{F}_q(t)$  with many integral points. The study connecting special aspects of such polynomials and the aforementioned applications is being handled in companion papers.

**Notation:** Throughout the text, q will denote a power of a prime p.

#### <span id="page-2-1"></span>2. Preliminaries

The content of this section is mostly based on [5], from where a large amount of notations and results are borrowed. Therefore, we believe that some familiarity with Sections 1 and 2 of that paper would be desirable for our reader.

We begin by pointing out that m. v. s. p. 's F with  $|V_F| \leq 2$  do not fit in the general pattern and were handled separately in [1]. Mills [5] proved the following important result that presents necessary conditions for a polynomial  $F \in \mathbb{F}_q[x]$  with  $|V_F| > 2$  to be an m. v. s. p. and encloses other valuable information about such polynomials.

<span id="page-2-2"></span>**Theorem 2.1** (Mills). Let  $F \in \mathbb{F}_q[x]$  be a polynomial of positive degree. Let  $V_F = \{\gamma_0, \gamma_1, \cdots, \gamma_r\}$  be its set of values, and let  $l_i$  be the number of distinct roots in  $\mathbb{F}_q$  of the polynomial  $F - \gamma_i$ . Let  $\gamma_i$  be arranged in such way that  $l_0 \leq l_i$ ,  $1 \leq i \leq r$ . Set  $L = \prod (x - \pi)$  where the product is over the distinct roots of  $F - \gamma_0$  that lie in  $\mathbb{F}_q$ .

Suppose that F is an m.v.s.p. and r > 1. Then there exist positive integers v, m, k; a polynomial N over  $\mathbb{F}_q$ , and  $\omega_0, \omega_1, \cdots, \omega_r$  in  $\mathbb{F}_q$  such that  $L \nmid N, v \mid (p^k - 1), 1 + vr = p^{mk}, L'$  is a  $p^{mk}$ -th power,  $\omega_0 \neq 0, \omega_m = 1$ ,

<span id="page-2-3"></span>
$$F = L^v N^{p^{mk}} + \gamma_0, \tag{2}$$

<span id="page-2-5"></span>
$$\prod_{i=1}^{r} (x - \gamma_i + \gamma_0) = \sum_{i=0}^{m} \omega_i x^{(p^{ki} - 1)/v},$$
(3)

<span id="page-2-4"></span>
$$\sum_{i=0}^{m} \omega_i L^{p^{ki}} N^{p^{mk}(p^{ki}-1)/v} = -\omega_0(x^q - x) L'.$$
 (4)

*Proof.* See [5, Theorem 1].

As a consequence of this theorem, Mills presented the following characterization of all m. v. s. p. 's over  $\mathbb{F}_q$  of degree  $\leq \sqrt{q}$ .

<span id="page-2-0"></span>**Theorem 2.2** (Mills). Let  $F \in \mathbb{F}_q[x]$  be a polynomial with  $0 < \deg F \le \sqrt{q}$ . Then F is an m. v. s. p. if and only if F is of the form

$$F = \alpha L^{v} + \gamma, \tag{5}$$

where L is a polynomial that factors into distinct linear factors over  $\mathbb{F}_q$  and that has the form

$$L = \sum_{i=0}^{d} \varphi_i x^{p^{ki}} + \beta, \tag{6}$$

where v and k are integers such that  $v|(p^k-1)$ , q is a power of  $p^k$ , and  $\alpha$ ,  $\beta$ ,  $\gamma$  and the  $\varphi_i$  are elements of  $\mathbb{F}_q$ .

*Proof.* See 
$$[5, Theorem 2]$$
.

In the following result, we show how Theorem 2.1 can also be used to extend Mills' characterization to the case of degree  $\sqrt{q} + 1$ .

<span id="page-3-0"></span>**Theorem 2.3.** Let F be a polynomial over  $\mathbb{F}_q$  with  $|V_F| > 2$  and of degree  $\sqrt{q} + 1$ . F is an m. v. s. p. if and only if there exist  $\alpha, \beta, \gamma \in \mathbb{F}_q$ , with  $\alpha \neq 0$ , such that

$$F = \alpha(x+\beta)^{\sqrt{q}+1} + \gamma.$$

*Proof.* We use the notation of Theorem 2.1.

Suppose that  $q = p^n$  and that F is an m. v. s. p.. Since  $\deg F = p^{n/2} + 1$ , it follows from the definition of m. v. s. p. that  $|V_F| = \frac{p^n - 1}{p^{n/2} + 1} + 1 = p^{n/2}$ .

Thus  $r = p^{n/2} - 1$  and  $1 + vr = p^{mk}$  give  $v = \frac{p^{mk} - 1}{p^{n/2} - 1}$ . Therefore n/2 divides mk, and since  $mk \le n$  (implicitly given by (2) and (4)) we have that either mk = n/2 or mk = n. If mk = n, then  $v = p^{n/2} + 1$  and (2) gives

$$F = L^{p^{n/2} + 1} N^{p^n} + \gamma_0.$$

Since  $\deg F = p^{n/2} + 1$  and  $\deg L \ge 1$ , we have that  $\alpha := N^{p^n} \in \mathbb{F}_q^*$  and  $L = x + \beta$  for some  $\beta \in \mathbb{F}_q$ . We set  $\gamma := \gamma_0$  and obtain

$$F = \alpha (x+\beta)^{p^{n/2}+1} + \gamma, \tag{7}$$

as desired.

If mk = n/2 then v = 1, and we will show that such case does not occur. In fact, we suppose it does occur and use (2) to write

$$F = LN^{p^{n/2}} + \gamma_0. (8)$$

This implies that either

- (i) L and N are polynomials of degree 1; or
- (ii)  $\deg L = p^{n/2} + 1$  and N is constant.

If we assume that L and N have degree 1, then  $F - \gamma_0 = LN^{p^{n/2}}$  has all of its roots defined over  $\mathbb{F}_q$ . Since  $L = \gcd(F - \gamma_0, x^q - x)$  has degree 1, it follows that  $F - \gamma_0$  cannot have two distinct roots. Therefore L|N, and this contradicts Theorem 2.1.

If we assume that (ii) is true, then  $F - \gamma_0$  has  $p^{n/2} + 1$  distinct roots over  $\mathbb{F}_{p^n}$ . For all  $0 \le i \le r$ , recall that in Theorem 2.1 it is assumed that  $l_0 \le l_i$ . Therefore,  $F - \gamma_i$  also has  $p^{n/2} + 1$  distinct roots over  $\mathbb{F}_{p^n}$ . This implies that  $\prod_{i=0}^r (F - \gamma_i)$  is a polynomial over  $\mathbb{F}_{p^n}$  with  $(r+1)(p^{n/2}+1) = p^n + p^{n/2}$  distinct roots defined over  $\mathbb{F}_{p^n}$ . This clear contradiction implies that neither (i) nor (ii) can hold and the result follows. The converse is trivial.

Observe that this result can be rephrased as follows: up to an affine composition<sup>1</sup>,  $x^{\sqrt{q}+1}$  is the only m. v. s. p. of degree  $\sqrt{q}+1$ . A similar statement is true for m. v. s. p. 's of degree  $\leq \sqrt{q}$  with a given set of values: they are also unique up to affine compositions. Our proof of this fact relies in part on the following consequence of the results in [5].

<span id="page-4-1"></span>**Lemma 2.4.** If  $F \in \mathbb{F}_q[x]$  is an m.v.s.p. with  $V_F = \{\gamma_0, \gamma_1, \dots, \gamma_r\}$  and r > 1, then

- (i) A root of  $F_i = F \gamma_i = 0$  is not in  $\mathbb{F}_q$  if and only if its multiplicity is divisible by p.
- (ii)  $F \gamma_i = 0$  has a simple root for at least r values  $\gamma_i \in V_F$ .

Proof. This proof uses notations and results of [5]. Item (i) follows directly from Lemmas 2 and 3 in [5]. In fact, since  $F_i = L_i U_i$  where  $L_i = \gcd(F_i, x^q - x)$ , Lemma 2 in [5] implies  $F_i = L_i^{w_i+1} H_i^p$ , which proves the "only if" part of (i). The other part of (i) follows from the fact that  $F_i$  is not a p-power; that is  $F_i' = F' \neq 0$ , which can be read off Theorem 2.1.

Lemma 2 in [5] also gives  $L_i \nmid H_i$  which, together with Lemma 3 in [5], implies (ii).

As remarked in footnote 1, given  $a \in \mathbb{F}_q^*$ ,  $b \in \mathbb{F}_q$  and a non-constant polynomial F, the polynomials F and G := F(ax + b) have the same set of values. In what follows, we will show that any two m.v.s.p.'s of degree  $\leq \sqrt{q}$  and with the same value set are related in this way.

<span id="page-4-2"></span>**Proposition 2.5.** Let  $F \in \mathbb{F}_q[x]$  be an m.v.s.p. such that  $|V_F| > 2$  and  $\deg F \leq \sqrt{q}$ . If  $G \in \mathbb{F}_q[x]$  is an m.v.s.p. such that  $\deg G \leq \sqrt{q}$  and  $V_F = V_G$  then G = F(ax + b) for some  $a, b \in \mathbb{F}_q$ .

<span id="page-4-0"></span><sup>&</sup>lt;sup>1</sup> It is worth mentioning that if  $F \in \mathbb{F}_q[x]$  is an m. v. s. p. and  $G = \alpha x + \beta \in \mathbb{F}_q[x]$  is non-constant, then  $F_1 = F(G(x))$  and  $F_2 = G(F(x))$  are m. v. s. p. 's with  $V_{F_1} = V_F$  and  $V_{F_2} = \alpha V_F + \beta$ . The polynomials  $F_1$  and  $F_2$  will be referred to as affine compositions of F

Proof. Without loss of generality, we may assume  $d := \deg F \ge \deg G$ . Suppose  $G(x) \ne F(ax+b)$  for all  $a,b \in \mathbb{F}_q$ ; that is, F(x) - G(y) has no  $\mathbb{F}_q$ -linear factors (in particular  $d \ge 2$ ). Since  $d \le \sqrt{q}$ , Theorem 2.2 implies  $F = \alpha L^v + \gamma_0$  and so  $F - \gamma = 0$  has d distinct roots for all  $\gamma \in \{\gamma_1, \gamma_2, \dots, \gamma_r\} = V_F \setminus \{\gamma_0\}$ , and by Lemma 2.4.(i), all such roots lie in  $\mathbb{F}_q$ . Therefore, if n is the number of times  $G(\lambda)$  assumes  $\gamma_0$  as  $\lambda$  ranges over  $\mathbb{F}_q$  then the number N of  $\mathbb{F}_q$ -solutions to F(y) = G(x) is given by  $N = d(q-n) + n \cdot \deg L$ . But since  $1 \le n \le d \le \sqrt{q}$  we have

<span id="page-5-1"></span>
$$N = d(q - n) + n \cdot \deg L \ge d(q - d) + \deg L \ge q(d - 1) + 1 \tag{9}$$

Notice that if N = q(d-1) + 1, then (9) gives 1 = n = d, contradicting d > 2. Therefore we have

$$N > q(d-1) + 1$$
,

which contradicts the main result (Theorem 3.1) of [3]. This completes the proof.

The results in this section show that m. v. s. p. 's with degree  $\leq \sqrt{q} + 1$  are unique (up to affine compositions) if their set of values are fixed. However, this is far from the truth in the general case. As we will see in the following sections, the set of m. v. s. p. 's with a fixed set of values S can be quite large.

## <span id="page-5-0"></span>3. On m.v.s.p.'s with a given set of values

Our discussion of Problem 1 starts with the following criterion to decide whether or not a polynomial F is an m. v. s. p. with  $V_F = \mathcal{S}$ , for a given set  $\mathcal{S} \subset \mathbb{F}_q$ . The following theorem, which can be read off the work of [1] and [5], will be used to restate Problem 1 in terms of the polynomial  $T = \prod_{\gamma \in \mathcal{S}} (x - \gamma)$  of values of F.

<span id="page-5-3"></span>**Theorem 3.1.** Let F be a polynomial in  $\mathbb{F}_q[x]$ , and let S be a subset of  $\mathbb{F}_q$ . If |S| > 2 and  $T = \prod_{\gamma \in S} (x - \gamma)$ , then the following are equivalent:

- (A) F is an m. v. s. p. with  $V_F = S$ .
- (B) There exists  $\theta \in \mathbb{F}_q^*$  such that

<span id="page-5-2"></span>
$$T(F) = \theta(x^q - x)F'. \tag{10}$$

Moreover,  $\theta = -T'(\gamma)$  for some  $\gamma \in \mathcal{S}$ .

*Proof.* If F satisfies (B), then we clearly have  $V_F \subset \mathcal{S}$ , and thus  $|V_F| \leq |\mathcal{S}|$ . Equating degrees in (10), we obtain  $|\mathcal{S}| \cdot \deg F \leq q + \deg F - 1$ , i.e.

<span id="page-6-2"></span><span id="page-6-0"></span>
$$|\mathcal{S}| - 1 \le \frac{q - 1}{\deg F} \tag{11}$$

and thereby

$$|\mathcal{S}| \le \left\lfloor \frac{q-1}{\deg F} \right\rfloor + 1 \le |V_F| \le |\mathcal{S}|,$$

which implies (A).

That (A) implies (B) follows from Lemma 1 in [5].

The fact that  $\theta = -T'(\gamma)$ , for some  $\gamma \in \mathcal{S}$ , can be proved by differentiating both sides of (10) and using the fact that  $F' \neq 0$ .

**Remark 3.1.1.** Using Lemmas 1, 2 and 3 in [5], one can actually prove that  $\theta = -T'(\gamma_i)$  for all  $i \neq 0$  (notation as in Theorem 2.1).

For our convenience, let us label the following assumption

separable monic polynomial of degree > 2 which splits over  $\mathbb{F}_q$  (\*)

<span id="page-6-1"></span>which will be used several times throughout the text.

**Definition 1.** Let T be a polynomial satisfying (\*). The set of T-m. v. s. p. 's over  $\mathbb{F}_q$  is defined to be

$$\mathcal{W}(T|\mathbb{F}_q) := \{ F \in \mathbb{F}_q[x] : T(F) = \theta(x^q - x)F', \text{ for some } \theta \in \mathbb{F}_q^* \}.$$

We will say that  $\mathcal{W}(T|\mathbb{F}_q)$  is non-trivial if it contains a non-constant element.

It follows from Theorem 3.1 that F is a T-m.v.s.p. over  $\mathbb{F}_q$  if either  $F=\alpha$  is a root of T or F is an m.v.s.p. whose set of values is the set of roots of T. Therefore, our investigation on m.v.s.p.'s with given set of values can be done via the sets  $\mathcal{W}(T|\mathbb{F}_q)$  and we can deal with the following restatement of Problem 1:

**Problem 1a.** Given a polynomial T satisfying (\*), is  $W(T|\mathbb{F}_q)$  non-trivial? How large is  $|W(T|\mathbb{F}_q)|$ ? Can we determine the whole of  $W(T|\mathbb{F}_q)$ ?

**Remark 3.1.2.** Notice that, according to footnote 1, it suffices to solve Problem 1a in the case where x|T(x).

The following consequence of Theorem 2.1 points out a necessary condition for the non-triviality of the sets  $W(T|\mathbb{F}_q)$ , further restricting the class of polynomials T, as well as the sets S that can be the value set of an m. v. s. p..

<span id="page-7-2"></span>**Proposition 3.2.** Let T be a polynomial satisfying (\*). If  $W(T|\mathbb{F}_q)$  is non-trivial, then there exist positive integers k, m and v, with  $v|(p^k-1)$ , and elements  $\gamma, \omega_1, \ldots, \omega_m \in \mathbb{F}_q$  such that

<span id="page-7-0"></span>
$$A(x) := T(x^{v} + \gamma)/x^{v-1} = \sum_{i=0}^{m} \omega_{i} x^{p^{ki}}.$$
 (12)

Proof. Let  $\{\gamma_0, \ldots, \gamma_r\}$  be the set of roots of T. By Theorem 3.1, any non-constant  $F \in \mathcal{W}(T|\mathbb{F}_q)$  is an m.v.s.p. with  $V_F = \{\gamma_0, \ldots, \gamma_r\}$  and r > 1. Therefore, F satisfies the hypotheses of Theorem 2.1. In particular, we can guarantee the existence of positive integers v, k and m, and elements  $\omega_1, \ldots, \omega_m \in \mathbb{F}_q$  such that (3) holds. Our conclusion is just a restatement of (3) with  $\gamma = \gamma_0$ .

Polynomials given by the right-hand side of (12) are called  $p^k$ -additive polynomials and have been extensively studied (see [4, Section 3.4])<sup>2</sup>. As we will see, the class of additive polynomials plays a crucial role in the construction (and possibly in the complete characterization) of m. v. s. p. 's with a given set of values. Most notably is the following result which is a first step towards a proof of a partial converse to the previous proposition.

<span id="page-7-3"></span>**Proposition 3.3.** Let v be a positive divisor of  $p^k - 1$  and T be a polynomial satisfying (\*). Assume x|T(x) and  $A(x) = T(x^v)/x^{v-1}$  is a  $p^k$ -additive polynomial satisfying (\*). Then

$$\mathcal{W}(A|\mathbb{F}_q) \longrightarrow \mathcal{W}(T|\mathbb{F}_q)$$

$$F \longmapsto F^v$$

is a well-defined map. In particular,

$$|\mathcal{W}(T|\mathbb{F}_q)| \ge \frac{|\mathcal{W}(A|\mathbb{F}_q)| - 1}{v} + 1.$$

*Proof.* For  $F \in \mathcal{W}(A|\mathbb{F}_q)$ , we have

$$T(F^{v}) = F^{v-1}A(F) = F^{v-1}(-A'(x^{q} - x)F') = -\frac{A'}{v}(x^{q} - x)(F^{v})'.$$

Thus  $F^v \in \mathcal{W}(T|\mathbb{F}_q)$ , by definition.

<span id="page-7-1"></span><sup>&</sup>lt;sup>2</sup>In [4],  $p^k$ -additive polynomials are called  $p^k$ -linearized polynomials.

Propositions 3.2 and 3.3 indicate that a solution to Problem 1a in the particular case of  $p^k$ -additive polynomials will provide a partial solution to the general problem. It turns out that whenever A is  $p^k$ -additive polynomial satisfying (\*), we are able to show that  $\mathcal{W}(A|\mathbb{F}_q)$  is non-trivial and find a lower bound for its cardinal number. This is accomplished in the following way:

For any  $p^k$ -additive polynomial A satisfying (\*), it is easily verified that the set  $\mathcal{W}(A|\mathbb{F}_q)$  is a finite  $\mathbb{F}_{p^k}$ -vector space. In Section 5 we will use this extra structure to show that for any such A, there exist a polynomial  $x^{p^{kd}} - \alpha x \in \mathbb{F}_q[x]$  satisfying (\*) and a  $\mathbb{F}_{p^k}$ -linear map  $\phi: \mathcal{W}(x^{p^{kd}} - \alpha x|\mathbb{F}_q) \longrightarrow \mathcal{W}(A|\mathbb{F}_q)$  with  $\ker \phi \subset \mathbb{F}_q$ . In particular, the non-triviality of  $\mathcal{W}(A|\mathbb{F}_q)$  and ultimately  $\mathcal{W}(T|\mathbb{F}_q)$ , for T as in Proposition 3.3, will follow from that of  $\mathcal{W}(x^{p^{kd}} - \alpha x|\mathbb{F}_q)$ . The next section will be used to show that not only the sets  $\mathcal{W}(x^{p^{kd}} - \alpha x|\mathbb{F}_q)$  are non-trivial, but that they can be described very explicitly.

# <span id="page-8-0"></span>4. Characterization of $\mathcal{W}(x^{p^{kd}} - \alpha x | \mathbb{F}_q)$

Let us start our study of the vector spaces  $\mathcal{W}(x^{p^{kd}} - \alpha x | \mathbb{F}_q)$  by noticing that since  $x^{p^{kd}} - \alpha x$  satisfies (\*), it follows that  $q = (p^{kd})^n$  for some integer  $n \geq 1$  and that  $\mathcal{W}(x^{p^{kd}} - \alpha x | \mathbb{F}_q)$  is isomorphic to  $\mathcal{W}(x^{p^{kd}} - x | \mathbb{F}_q)$ . Therefore, it is sufficient to consider the set  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ . Observe that Theorem 3.1 implies that

<span id="page-8-1"></span>
$$\mathcal{W}(x^q - x | \mathbb{F}_{q^n}) = \{ F \in \mathbb{F}_{q^n}[x] : F^q - F = (x^{q^n} - x)F' \}, \tag{13}$$

since  $\theta = -T'(\gamma) = 1$ , for some  $\gamma \in \mathbb{F}_q$ .

Recall that deg T > 2 was required in the definition of  $\mathcal{W}(T|\mathbb{F}_q)$ , and that was motivated by the condition r > 2 in Theorem 3.1. However, we want to stress that q = 2 will be allowed in (13), and the reason why this can be done is just one of the facts given by the following Lemma.

<span id="page-8-3"></span>**Lemma 4.1.** If  $F \in \mathbb{F}_{q^n}[x]$  is non-constant with  $V_F \subseteq \mathbb{F}_q$ , then the following are equivalent:

- (1) F is an m. v. s. p. with  $V_F = \mathbb{F}_q$ .
- (2)  $F^q F = (x^{q^n} x)F'$ .
- (3)  $q^{n-1} < \deg F < (q^n 1)/(q 1)$ .
- (4)  $0 < \deg F \le (q^n 1)/(q 1)$ .

*Proof.* •  $(1) \Longrightarrow (2)$ : In the notation of Theorem 3.1 we have  $T = x^q - x$ , and the result will follow if q > 2. Assuming q = 2, we have

<span id="page-8-2"></span>
$$F^2 - F = (x^{2^n} - x)G (14)$$

for some  $G \in \mathbb{F}_{2^n}[x]$ , and we claim that G = F'. In fact, differentiating both sides of (14) gives  $F' = G + (x^{2^n} - x)G'$ , and the result will follow if G' = 0. By hypothesis, we have  $\lfloor (2^n - 1)/\deg F \rfloor + 1 = |V_F| = 2$  which implies

<span id="page-9-0"></span>
$$\deg F \le 2^n - 1,\tag{15}$$

and thus (14) gives  $\deg G \leq 2^n - 2$ ; that is,  $\deg xG \leq 2^n - 1$ . So if  $G' \neq 0$ , then a monomial of G of odd degree, say  $\alpha x^{2t+1}$ , will give rise to a monomial  $\alpha x^{2^n+2t+1}$  on the right side of (14). But this will imply  $\deg F > 2^n$ , contradicting (15). Therefore G = F'.

- (2)  $\Longrightarrow$  (3): Since  $F^q F = (x^{q^n} x)F'$  gives  $q \cdot \deg F = q^n + \deg F'$ , the result will follow from  $0 \le \deg F' \le \deg F 1$ .
- $(3) \Longrightarrow (4)$ : obvious.
- $(4) \Longrightarrow (1)$ :  $0 < \deg F \le (q^n 1)/(q 1)$  gives  $(q^n 1)/(\deg F) \ge q 1$ , and thus  $\lfloor (q^n 1)/\deg F \rfloor + 1 \ge q \ge |V_F|$ . But since  $|V_F| \ge \lfloor (q^n 1)/\deg F \rfloor + 1$  always holds we have  $|V_F| = \lfloor (q^n 1)/\deg F \rfloor + 1$ .  $\square$

Now we proceed to characterize the polynomials  $F \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ . We begin with the larger set of polynomials F over  $\mathbb{F}_{q^n}$  satisfying

<span id="page-9-1"></span>
$$F^q \equiv F \mod (x^{q^n} - x) \text{ and } \deg F \le q^n - 1.$$
 (16)

If we write  $F = m_1 + m_2 + \cdots + m_l$ , where  $m_i$  are monomials of F with distinct degrees, then

$$F = (m_1^q \mod (x^{q^n} - x)) + (m_2^q \mod (x^{q^n} - x)) + \dots + (m_l^q \mod (x^{q^n} - x)).$$

In other words, if  $M = \{m_1, m_2, \dots, m_l\}$ , then the map  $\sigma : M \longrightarrow M$  given by  $\sigma(m_i) = m_i^q \mod (x^{q^n} - x)$  is a permutation on M. Moreover, the following holds:

<span id="page-9-2"></span>**Proposition 4.2.** Let F be a polynomial satisfying (16) and let M be the set of all monomials of F with distinct degrees. If g is a generator of  $Gal(\mathbb{F}_{q^n}|\mathbb{F}_q)$  then

$$g^j(m) := m^{q^j} \mod (x^{q^n} - x),$$

defines an action of  $Gal(\mathbb{F}_{q^n}|\mathbb{F}_q)$  on M.

*Proof.* It is a routine check and we leave it to the reader.  $\Box$ 

The following simple but useful fact is a consequence of the previous result:

<span id="page-10-0"></span>**Lemma 4.3.** Let F be a polynomial satisfying (16). Then:

- (a) If  $m^q \mod (x^{q^n} x)$  is a monomial of F, then so is  $m \mod (x^{q^n} x)$ .
- (b) If  $m = \alpha x^{kq+1}$  is a monomial of F, then so is  $\tilde{m} = \alpha^{1/q} x^{k+q^{n-1}}$ .

*Proof.* Both cases follow directly from that fact that if m is a monomial of F, then so is  $m^{q^{n-1}} \mod (x^{q^n} - x)$ .

Let  $O_m$  denote the orbit of a monomial  $m = \alpha x^k$  of F by the action of  $Gal(\mathbb{F}_{q^n}|\mathbb{F}_q)$ . Let s(m) denote the size of  $O_m$ . Then

$$(\alpha x^k)^{q^{s(m)}} \mod (x^{q^n} - x) = \alpha x^k,$$

implies that for any  $m_0 \in O_m$ ,  $m_0$  is defined over  $\mathbb{F}_{q^{s(m)}}$ . This observation is the last ingredient in the characterization of the polynomials F over  $\mathbb{F}_{q^n}$  satisfying  $F^q \equiv F \mod (x^{q^n} - x)$  and  $\deg F \leq q^n - 1$ .

<span id="page-10-1"></span>**Proposition 4.4.** Every F satisfying (16) can be written as  $F = \sum_{i=1}^{e} F_i$ , where

$$F_i = \sum_{m \in O_{m_i}} m \tag{17}$$

and  $m_1, \ldots, m_e$  are certain monomials of F. Moreover, for all  $1 \le i \le e$ ,  $F_i$  is defined over  $\mathbb{F}_{q^{s(m_i)}}$ .

Proof. Pick a monomial  $m_1$  of F. The orbit  $O_{m_1}$  is a set of distinct monomials of F. Let  $F_1$  be the sum of all such monomials. If those are all the monomials of F, then we are done; otherwise we can pick a monomial  $m_2$  of F not lying on the set  $O_{m_1}$ , and consider the polynomial  $F_2$ , sum of the monomials in the orbit  $O_{m_2}$ . We keep repeating this process, and it is clear that we will finish it after a finite number of steps, let us say e steps. Now  $F = \sum_{i=1}^{e} F_i$  follows from the construction and from the fact that the sets  $O_{m_i}$ 's are mutually disjoint.

**Remark 4.4.1.** Notice that a polynomial F satisfies  $F^q \equiv F \mod (x^{q^n} - x)$  if, and only if,  $V_F \subset \mathbb{F}_q$ . Therefore the previous result characterizes all polynomials F over  $\mathbb{F}_{q^n}$  with  $V_F \subset \mathbb{F}_q$  and  $\deg F \leq q^n - 1$ .

The complete description of  $F \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$  will follow once we know what the monomials of such an F look like. The additional information, namely  $F^q - F = (x^{q^n} - x)F'$ , will answer this question.

**Lemma 4.5.** For all  $F \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ , there exist polynomials A and B such that F = A + B and

<span id="page-11-0"></span>
$$F = x \left(\frac{A}{x^{q^{n-1}}}\right)^q + B^q \tag{18}$$

*Proof.* Let  $A, B \in \mathbb{F}_{q^n}[x]$  be such that F = A + B and A is formed by all the monomials of F of degree at least  $q^{n-1}$ . Note that Lemma 4.1.(3) implies  $A \neq 0$ . Then  $A^q + B^q - F = x^{q^n}F' - xF'$ , and after comparing degrees we have

(a) 
$$A^q = x^{q^n} F'$$
, which gives  $F' = \left(\frac{A}{x^{q^{n-1}}}\right)^q$ , and

(b) 
$$(B^q - F) = -xF'$$
, which gives  $F = xF' + B^q$ .

Combining (a) and (b), we obtain the desired result.

<span id="page-11-2"></span>**Lemma 4.6.** If  $\alpha x^k$  is a non-zero monomial of  $F \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ , then

$$k = a_{n-1}q^{n-1} + a_{n-2}q^{n-2} + \dots + a_1q + a_0$$

where  $a_i \in \{0, 1\}$ .

Proof. We can certainly write  $k = \sum_{i=1}^{n} a_i q^i$ , where  $a_i \in \{0, 1, \dots, q-1\}$ . From (18) we clearly have  $a_0 \in \{0, 1\}$ . If  $a_0 = 0$  then Lemma 4.3 implies that  $\alpha^{q^{n-1}} x^{\frac{k}{q}}$  is a term of F and then we fall into an equivalent problem with fewer variables  $a_i$ . Therefore, we may assume  $a_0 = 1$  and again Lemma 4.3 implies that  $\tilde{\alpha} x^{q^{n-1} + \frac{k-1}{q}}$  is a term of F. The new term  $\tilde{\alpha} x^{q^{n-1} + a_{n-1}q^{n-2} + \dots + a_2q + a_1}$  gives  $a_1 \in \{0, 1\}$  and we repeat the process to reach  $a_2$ . After at most n iterations, we find that all  $a_i$  are either zero or one.

Before finishing the complete description of  $W(x^q - x | \mathbb{F}_{q^n})$ , let us recall that s(m) denotes the size of the orbit of the monomial m by the action of  $Gal(\mathbb{F}_{q^n}|\mathbb{F}_q)$  as described in Proposition 4.2.

<span id="page-11-3"></span>**Theorem 4.7.** A polynomial F lies in  $W(x^q - x | \mathbb{F}_{q^n})$  if, and only if, it can be written as a sum of polynomials of the form

<span id="page-11-1"></span>
$$\sum_{i=0}^{s(m)-1} [m^{q^i} \mod (x^{q^n} - x)], \tag{19}$$

where  $m \in \mathbb{F}_{q^{s(m)}}[x]$  is a monomial and deg  $m = a_{n-1}q^{n-1} + a_{n-2}q^{n-2} + \cdots + a_1q + a_0$  with  $a_i \in \{0, 1\}$ .

*Proof.* That such an  $F \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$  can be written as sum of polynomials given by (19) is a consequence of Proposition 4.4 and Lemma 4.6. To prove the converse, we can use the fact that  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n})$  is an  $\mathbb{F}_q$ -vector space and just prove that the polynomials given by (19) lie in  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ .

Let H be a polynomial given by (19). If  $\deg H = 0$  then  $H \in \mathbb{F}_q$ . Thus we may assume that  $\deg H > 0$ . We know that H satisfies (16) and thereby  $V_H \subset \mathbb{F}_q$ . Moreover,  $0 < \deg H \le 1 + q + q^2 + \ldots + q^{n-1} = \frac{q^{n-1}}{q-1}$  and Lemma 4.1.(4) implies  $H \in \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ .

## <span id="page-12-0"></span>4.1. The dimension of $W(x^q - x | \mathbb{F}_{q^n})$

Let g be a generator of  $\operatorname{Gal}(\mathbb{F}_{q^n}|\mathbb{F}_q)$  and  $(a_0,\ldots,a_{n-1})\in\{0,1\}^n$ . Then the map given by  $g(a_0,\ldots,a_{n-2},a_{n-1})=(a_{n-1},a_0,\ldots,a_{n-2})$  defines an action of  $\operatorname{Gal}(\mathbb{F}_{q^n}|\mathbb{F}_q)$  on the set  $\{0,1\}^n$ . Let us identify the n-tuple  $(a_0,\ldots,a_{n-2},a_{n-1})$  with the q-ary expansion of an integer  $k=a_{n-1}q^{n-1}+\cdots+a_1q+a_0$ , and choose representatives  $k_1,\ldots,k_b$  on each orbit of the set  $\{0,1\}^n$ . For each  $i\in\{1,\ldots,b\}$ , let  $d_i$  be the size of the orbit  $O_{k_i}$  and

$$\mathcal{V}_i := \left\{ \sum_{j=0}^{d_i - 1} (\alpha x^{k_i})^{q^j} \mod (x^{q^n} - x) : \alpha \in \mathbb{F}_{q^{d_i}} \right\}.$$

<span id="page-12-1"></span>**Theorem 4.8.** For  $i \in \{1, \dots, b\}$ , the set  $V_i$  is an  $\mathbb{F}_q$ -vector subspace of  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n})$  of dimension  $d_i$ . Moreover,

$$\mathcal{W}(x^q - x | \mathbb{F}_{q^n}) = \bigoplus_{i=1}^b \mathcal{V}_i.$$

and

$$\dim_{\mathbb{F}_q} \mathcal{W}(x^q - x | \mathbb{F}_{q^n}) = 2^n.$$

*Proof.* Theorem 4.7 implies that each  $\mathcal{V}_i \subset \mathcal{W}(x^q - x | \mathbb{F}_{q^n})$ . Also, it can be easily verified that  $\mathcal{V}_i$  is an  $\mathbb{F}_q$ -vector space and that  $|V_i| = q^{d_i}$ . Consequently  $\dim_{\mathbb{F}_q} \mathcal{V}_i = d_i$ .

Notice that if  $k = a_{n-1}q^{n-1} + a_{n-2}q^{n-2} + \cdots + a_1q + a_0$  is identified with an n-tuple  $(a_0, a_1, \ldots, a_{n-1}) \in \{0, 1\}^n$ , then the degree of  $(\alpha x^k)^q \mod (x^{q^n} - x)$  is equal to  $a_nq^{n-1} + a_1q^{n-2} + \ldots + a_{n-1}$ ; and, under the above identification, it is given by the cyclic permutation  $(a_{n-1}, a_0, a_1, \ldots, a_{n-2})$ .

Therefore the set of exponents of monomials of elements in  $\mathcal{V}_i$  is equal to the orbit of  $k_i$  (identified with an *n*-tuple) by the action of  $\operatorname{Gal}(\mathbb{F}_{q^n}|\mathbb{F}_q)$  on  $\{0,1\}^n$ . This implies that all elements of  $\mathcal{V}_i$  will not share any monomial with any element in a distinct  $\mathcal{V}_j$ . Thus for all i,

$$\mathcal{V}_i \cap (\mathcal{V}_1 + \ldots + \mathcal{V}_{i-1} + \mathcal{V}_i + \ldots + \mathcal{V}_b) = 0.$$

Theorem 4.7 implies that every element of  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n})$  can be written as sum of elements in distinct  $\mathcal{V}_i$ 's. Therefore,  $\mathcal{W}(x^q - x | \mathbb{F}_{q^n}) = \bigoplus_{i=1}^b \mathcal{V}_i$ .

Now, if we let o(d) denote the number of  $\mathcal{V}_i$ 's of dimension d, then

$$\dim_{\mathbb{F}_q} \mathcal{W}(x^q - x | \mathbb{F}_{q^n}) = \sum_{d|n} d \cdot o(d).$$

Notice that by construction o(d) also counts the number of orbits of  $\{0,1\}^n$  of size d. Thus,  $d \cdot o(d)$  is equal to the cardinality of the union of all orbits of  $\{0,1\}^n$  with size d. Since  $\{0,1\}^n$  can be partitioned into orbits of size dividing n, we conclude that  $\sum_{d|n} d \cdot o(d) = 2^n$ .

<span id="page-13-2"></span>Corollary 4.9. If  $x^{q^d} - \alpha x$  satisfies (\*) then

$$\dim_{\mathbb{F}_q} \mathcal{W}(x^{q^d} - \alpha x | \mathbb{F}_{q^n}) = d2^{n/d}.$$

*Proof.* We leave the verification to the reader.

## <span id="page-13-0"></span>5. On the vector spaces $\mathcal{W}(A|\mathbb{F}_q)$

Let A be a  $p^k$ -additive polynomial satisfying (\*). The aim of this section is to provide a method to construct non-constant elements of  $\mathcal{W}(A|\mathbb{F}_q)$ , compute a lower bound for its dimension, and point out cases where this bound is sharp. As before, it is enough to consider the  $\mathbb{F}_q$ -vector spaces  $\mathcal{W}(A|\mathbb{F}_{q^n})$ , where A is a q-additive polynomial.

The following two lemmas will be used to construct  $\mathbb{F}_q$ -linear maps  $\phi$ :  $\mathcal{W}(x^{q^d} - \alpha x | \mathbb{F}_{q^n}) \longrightarrow \mathcal{W}(A | \mathbb{F}_{q^n})$ . As discussed briefly in the end of Section 3, we will take advantage of our understanding of  $\mathcal{W}(x^{q^d} - \alpha x | \mathbb{F}_{q^n})$  to give information on  $\mathcal{W}(A | \mathbb{F}_{q^n})$ .

Let  $\mathcal{R}(A)$  denote the set of roots of a polynomial A. Then  $\mathcal{R}(A)$  is an  $\mathbb{F}_q$ -vector subspace of  $\mathbb{F}_{q^n}$  of dimension t, whenever A is a q-additive polynomial satisfying (\*) with deg  $A = q^t$ .

<span id="page-13-1"></span>**Lemma 5.1.** Let A, L and M be q-additive polynomials. Suppose that A and L satisfy (\*) and that  $L = \gamma A(M(x))$ , for some  $\gamma \in \mathbb{F}_{q^n}^*$ . Then the map  $\phi_M : \mathcal{W}(L|\mathbb{F}_{q^n}) \longrightarrow \mathcal{W}(A|\mathbb{F}_{q^n})$  given by  $\phi_M(F) := M(F)$  is  $\mathbb{F}_q$ -linear with kernel  $\mathcal{R}(M)$ .

*Proof.* The assertions are simple and can be easily checked.  $\Box$ 

<span id="page-14-0"></span>**Lemma 5.2.** Let A and  $x^{q^d} - \alpha x$  be q-additive polynomials satisfying (\*). If A divides  $x^{q^d} - \alpha x$  then there exists a q-additive polynomial M splitting over  $\mathbb{F}_{q^d}$  and an element  $\gamma$  of  $\mathbb{F}_{q^n}^*$  such that

$$x^{q^d} - \alpha x = \gamma A(M(x)).$$

Proof. Suppose  $\deg A = q^t$ , and assume  $\alpha = 1$ . By assumption, the set  $\mathcal{R}(A)$  is an  $\mathbb{F}_q$ -vector subspace of codimension d-t in  $\mathbb{F}_{q^d}$ . Therefore, from Corollary 2.5 of [2], there exists a unique monic q-additive polynomial  $M \in \mathbb{F}_{q^d}[x]$  splitting over  $\mathbb{F}_{q^d}$  and of degree  $q^{d-t}$ , such that  $\mathcal{R}(A) = \{M(y) : y \in \mathbb{F}_{q^n}\}$ . But this implies that  $A(M(x)) \in \mathbb{F}_{q^d}[x]$  is monic of degree  $q^d$  and vanishes in  $\mathbb{F}_{q^d}$ . That is,

$$A(M(x)) = x^{q^d} - x.$$

For  $\alpha \neq 1$ , we consider  $\beta \in \mathbb{F}_q^*$  such that  $\alpha = \beta^{q^d-1}$ . Since A(x) divides  $x^{q^d} - \alpha x$ , we have that  $\beta^{-q^t} A(\beta x)$  is monic and divides  $x^{q^d} - x$ . As proved above, there exists a unique monic q-additive polynomial L such that  $x^{q^d} - x = \beta^{-q^t} A(\beta L(x))$ . If we take  $M(x) = \beta L(\beta^{-1}x)$  and  $\gamma = \beta^{q^d-q^t}$ , then the result follows.

We are ready to derive the main result of this section.

<span id="page-14-1"></span>**Theorem 5.3.** Suppose A and  $x^{q^d} - \alpha x$  are q-additive polynomials satisfying (\*) and that deg  $A = q^t$ .

If A divides  $x^{q^d} - \alpha x$  then there exists a q-additive polynomial M with  $\deg M = q^{d-t}$  such that the sequence

$$0 \longrightarrow \mathcal{R}(M) \xrightarrow{\iota} \mathcal{W}(x^{q^d} - \alpha x | \mathbb{F}_{q^n}) \xrightarrow{\phi_M} \mathcal{W}(A | \mathbb{F}_{q^n})$$
 (20)

is exact, where  $\iota$  is the inclusion map and  $\phi_M$  is defined by  $\phi_M(F) = M(F)$ . Moreover,

$$\dim_{\mathbb{F}_q} \mathcal{W}(A|\mathbb{F}_{q^n}) \ge d2^{n/d} - d + t,$$

with equality if and only if  $\phi_M$  is surjective.

*Proof.* Since A divides  $x^{q^d} - \alpha x$ , Lemma 5.2 guarantees the existence of a q-additive polynomial M satisfying

$$x^{q^d} - \alpha x = \gamma A(M(x)),$$

for some  $\gamma \in \mathbb{F}_{q^d}^*$ . Thus, Lemma 5.1 gives us the desired exact sequence.

The statement about the dimension follows from the Rank-nullity theorem and Corollary 4.9.

Let us recall that our study of the vector spaces  $W(A|\mathbb{F}_{q^n})$  was motivated by Problem 1. The previous result, footnote 1 and Theorem 3.1 show that if S is any affine transformation of an  $\mathbb{F}_q$ -vector space V, then we have a positive solution to part of Problem 1: there are m. v. s. p. 's F over  $\mathbb{F}_{q^n}$  such that  $V_F = S$ . Moreover, these results provide the lower bound  $q^{d2^{n/d}-d+t}$  for the number of such polynomials, where d > 0 is an integer depending on the monic q-additive polynomial A of degree t > 2 such that  $V = \mathcal{R}(A)$ . In many cases this lower bound can be attained if, in Theorem 5.3, we choose the unique multiple of A of the form  $x^{q^d} - \alpha x$  satisfying (\*) and with minimal degree. When A itself is of the form  $x^{q^d} - \alpha x$ , this is a consequence of Corollary 4.9. The next result shows that it also holds if  $\dim_{\mathbb{F}_q} V \geq n/2$ .

**Theorem 5.4.** Suppose A and  $x^{q^d} - \alpha x$  are q-additive polynomials satisfying (\*) and that deg  $A = q^t \ge q^{n/2}$ .

If among all multiples of A of the form  $x^{q^d} - \alpha x$  we choose the one with minimal degree, then the sequence given by Theorem 5.3 can be extended to the exact sequence

$$0 \longrightarrow \mathcal{R}(M) \xrightarrow{\iota} \mathcal{W}(x^{q^d} - \alpha x | \mathbb{F}_{q^n}) \xrightarrow{\phi_M} \mathcal{W}(A | \mathbb{F}_{q^n}) \longrightarrow 0.$$

In particular,

$$\dim_{\mathbb{F}_a} \mathcal{W}(A|\mathbb{F}_{a^n}) = d2^{n/d} - d + t.$$

*Proof.* Let  $G \in \mathcal{W}(A|\mathbb{F}_{q^n})$ . From (11) and  $\deg A \geq q^{n/2}$ , it follows that  $\deg G \leq \frac{q^{n-1}}{\deg A-1} \leq q^{n/2}+1$ .

First assume that  $\deg G = q^{n/2} + 1$  for some  $G \in \mathcal{W}(A|\mathbb{F}_{q^n})$ . Theorem 2.3 implies that there exist  $\alpha, \beta, \gamma \in \mathbb{F}_{q^n}$  such that  $G = \alpha(x+\beta)^{q^{n/2}+1} + \gamma$ . Since  $\mathcal{R}(A) = V_G = \alpha \mathbb{F}_{q^{n/2}} + \gamma$  is a vector space, we can conclude that  $\gamma = 0$  and  $A = x^{q^{n/2}} - \alpha^{q^{n/2}-1}x$ . As observed above, for q-additive polynomials of this form the result is a consequence of Proposition 4.9.

Now suppose that  $\deg G < q^{n/2} + 1$  for all  $G \in \mathcal{W}(A|\mathbb{F}_{q^n})$ . The fact that  $\mathcal{W}(x^{q^{n/2}} - \alpha x|\mathbb{F}_{q^n})$  is  $\mathbb{F}_q$ -isomorphic to  $\mathcal{W}(x^{q^{n/2}} - x|\mathbb{F}_{q^n})$  and Theorem 4.7 imply that A is not of the form  $x^{q^{n/2}} - \alpha x$ . Therefore  $x^{q^n} - x$  is the multiple of A of such form and with minimal degree. Theorem 5.3 guarantees the existence of a q-linear polynomial M and an exact sequence

$$0 \longrightarrow \mathcal{R}(M) \longrightarrow \mathcal{W}(x^{q^n} - x | \mathbb{F}_{q^n}) \xrightarrow{\phi_M} \mathcal{W}(A | \mathbb{F}_{q^n}).$$

We would like to show that the map  $\phi_M(F) := M(F)$  is surjective. Since  $\mathcal{W}(x^{q^n} - x | \mathbb{F}_{q^n}) = \{\alpha x + \beta : \alpha, \beta \in \mathbb{F}_{q^n}\}$ , it follows that  $\phi_M$  is surjective if  $G \in \mathcal{W}(A | \mathbb{F}_{q^n})$  implies that  $G(x) = M(\alpha x + \beta)$  for some  $\alpha, \beta \in \mathbb{F}_{q^n}$ . This last assertion follows from Lemma 2.5.

## <span id="page-16-0"></span>6. Some Examples

As described in the introduction, the authors of [1] identified two classes of m. v. s. p. 's over  $\mathbb{F}_{q^n}$ . Let G be one of the following polynomials over  $\mathbb{F}_{q^n}$ :

- a polynomial satisfying  $0 < \deg G \le \frac{q^n 1}{q 1}$  and  $V_G \subset \mathbb{F}_q$ ; or
- a q-additive polynomial that splits over  $\mathbb{F}_{q^n}$ .

If v is a positive divisor of q-1,  $\alpha \in \mathbb{F}_q^*$  and  $\beta, \gamma \in \mathbb{F}_q$ , then  $\alpha G(x+\beta)^v + \gamma$  is an m. v. s. p..

At the end of [5], the author says that "it seems unlikely that there are any more" m. v. s. p. 's other than the ones above. In this section we show how the previous results can be used to construct many examples of m. v. s. p. 's; some of which are not of the form given above.

(1) Obtaining the elements of  $W(x^q - x | \mathbb{F}_{a^n})$  for n = 3.

Let us consider the action of  $Gal(\mathbb{F}_{q^3}|\mathbb{F}_q)$  on the set of 3-uples  $(a_0, a_1, a_2) \in \{0, 1\}^3$  via cyclic permutation. The orbits of this action are given by

- $O_0 := \{(0,0,0)\},\$
- $O_1 := \{(1,0,0), (0,1,0), (0,0,1)\},\$
- $O_{q+1} := \{(1,1,0), (0,1,1), (1,0,1)\},\$
- $O_{a^2+a+1} := \{(1,1,1)\}.$

As discussed in Section 4.1, if we identify a 3-uple  $(a_0, a_1, a_2)$  with the q-ary expansion of a number  $a_2q^2 + a_1q + a_0$ , then to each of these orbits we associate the following  $\mathbb{F}_q$ -vector spaces

- $\mathcal{V}_0 := \mathbb{F}_a$ ,
- $\mathcal{V}_1 := \{\alpha x + (\alpha x)^q + (\alpha x)^{q^2} : \alpha \in \mathbb{F}_{q^3}\},$
- $\mathcal{V}_{q+1} := \{ \alpha x^{q+1} + \alpha^q x^{q^2+q} + \alpha^{q^2} x^{q^2+1} : \alpha \in \mathbb{F}_{q^3} \},$
- $\mathcal{V}_{q^2+q+1} := \{\alpha x^{q^2+q+1} : \alpha \in \mathbb{F}_q\}.$

Theorem 4.8 implies that every element of  $W(x^q - x | \mathbb{F}_{q^3})$  can be uniquely written as a sum of elements in distinct  $\mathcal{V}_i$ 's. Notice that the sum of the  $\mathbb{F}_q$ -dimensions of the  $\mathcal{V}_i$ 's is given by  $1+3+3+1=2^3$  and is equal to the dimension of  $W(x^q - x | \mathbb{F}_{q^3})$ .

(2) Constructing elements in  $W(A|\mathbb{F}_{q^6})$  for  $A = x^{q^2} + x^q + x$ .

Observe that  $A = x^{q^2} + x^q + x$  is a q-additive polynomial dividing  $x^{q^3} - x$ . By Theorem 5.3, we can find a q-additive polynomial M satisfying  $A(M(x)) = x^{q^3} - x$ , namely  $M = x^q - x$ .

This polynomial defines a linear map

$$\mathcal{W}(x^{q^3} - x | \mathbb{F}_{q^6}) \xrightarrow{\phi_M} \mathcal{W}(x^{q^2} + x^q + x | \mathbb{F}_{q^6})$$

given by  $\phi_M(F) = M(F)$ . In other words,

$$F^q - F \in \mathcal{W}(x^{q^2} + x^q + x | \mathbb{F}_{q^6}),$$

for all  $F \in \mathcal{W}(x^{q^3} - x|\mathbb{F}_{q^6})$ . Following the strategy of the previous example, we can show that

$$\mathcal{W}(x^{q^3} - x | \mathbb{F}_{q^6}) = \mathbb{F}_{q^3} \oplus \{\alpha x + (\alpha x)^{q^3} | \alpha \in \mathbb{F}_{q^6}\} \oplus \{\alpha x^{1+q^3} | \alpha \in \mathbb{F}_{q^3}\}.$$

In particular,  $\dim_{\mathbb{F}_q} \mathcal{W}(x^{q^3} - x | \mathbb{F}_{q^6}) = 12$ , and  $\left| \mathcal{W}(x^{q^3} - x | \mathbb{F}_{q^6}) \right| = q^{12}$ . Since  $\ker \phi_A = \mathbb{F}_q$ , we have that

$$\left| \mathcal{W}(x^{q^2} + x^q + x | \mathbb{F}_{q^6}) \right| \ge q^{11}.$$

(3) An m. v. s. p. different from the ones considered in [1, 5].

Take  $G = x^{q^4+q} - x^{q^3+1}$ . Notice that  $G = M(x^{q^3+1})$  is an element of  $\mathcal{W}(x^{q^2} + x^q + x | \mathbb{F}_{q^6})$ . In particular, G is an m. v. s. p. with  $V_G \subset \mathbb{F}_{q^3}$  and  $\deg G > (q^6 - 1)/(q^3 - 1)$ .

Also it is not hard to see that for any q-additive polynomial L, G is neither a power of L nor of the form  $\alpha^{-\deg L}L(\alpha x) + \beta$ , for some  $\alpha, \beta \in \mathbb{F}_{q^6}^*$ .

(4) Now assuming that q is odd, we use  $\mathcal{W}(x^{q^2} + x^q + x|\mathbb{F}_{q^6})$  to construct elements of  $\mathcal{W}(x^{\frac{q^2+1}{2}} + x^{\frac{q+1}{2}} + x|\mathbb{F}_{q^6})$ .

For  $T=x^{\frac{q^2+1}{2}}+x^{\frac{q+1}{2}}+x$ , we have  $x^{q^2}+x^q+x=T(x^2)/x$ . Therefore, Proposition 3.3 shows that  $F^2\in \mathcal{W}(x^{\frac{q^2+1}{2}}+x^{\frac{q+1}{2}}+x|\mathbb{F}_{q^6})$  for  $F\in \mathcal{W}(x^{q^2}+x^q+x|\mathbb{F}_{q^6})$ . Using the results obtained in example (2), we conclude that

$$\left| \mathcal{W}(x^{\frac{q^2+1}{2}} + x^{\frac{q+1}{2}} + x | \mathbb{F}_{q^6}) \right| \ge (q^{11} - 1)/2.$$

It is worth mentioning that a computer check for  $q \leq 7$  and  $q = 2^n$  for  $n \leq 11$  shows that the lower bound obtained in example (2) is in fact the actual number of m. v. s. p. 's in the corresponding set  $\mathcal{W}(A|\mathbb{F}_{q^6})$ .

## References

- <span id="page-18-0"></span>[1] Carlitz, L., Lewis, D. J., Mills, W. H., Straus, E. G., 1961. Polynomials over finite fields with minimal value sets. Mathematika 8, 121–130.
- <span id="page-18-4"></span>[2] Garcia, A., Ozbudak, F., 2007. Some maximal function fields and additive ¨ polynomials. Comm. Algebra 35 (5), 1553–1566. URL <http://dx.doi.org/10.1080/00927870601169218>
- <span id="page-18-2"></span>[3] Homma, M., Kim, S. J., 2010. Sziklai's conjecture on the number of points of a plane curve over a finite field III. Finite Fields Appl. 16 (5), 315–319. URL <http://dx.doi.org/10.1016/j.ffa.2010.05.001>
- <span id="page-18-3"></span>[4] Lidl, R., Niederreiter, H., 1997. Finite fields, 2nd Edition. Vol. 20 of Encyclopedia of Mathematics and its Applications. Cambridge University Press, Cambridge, with a foreword by P. M. Cohn.
- <span id="page-18-1"></span>[5] Mills, W. H., 1964. Polynomials with minimal value sets. Pacific J. Math. 14, 225–241.