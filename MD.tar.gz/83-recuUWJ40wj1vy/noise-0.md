# Minimal value set polynomials and a generalization of the Hermitian curve

Herivelto Borges<sup>a</sup> , Ricardo Concei¸c˜ao<sup>b</sup>

<sup>a</sup>Universidade de S˜ao Paulo, Inst. de Ciˆencias Matem´aticas e de Computa¸c˜ao, S˜ao Carlos, SP 13560-970, Brazil.

### Abstract

We use a recent characterization of minimal value set polynomials and q-Frobenius nonclassical curves to construct curves that generalize the Hermitian curve. The genus g and the number N of Fq-rational points of the curves are computed and, for a special family of these curves, we determine the Weierstrass semigroup at the unique point at infinity. These special curves yield new examples of Castle curves and improve on a previous example of Garcia-Stichtenoth of curves with large ratio N/g.

*Keywords:* Minimal value set polynomials, Value set, Finite Field, Hermitian curve, Frobenius nonclassical curve.

### 1. Introduction

One of the fundamental results in the theory of curves over a finite field is the Hasse-Weil bound

$$|N - (q+1)| \le 2g\sqrt{q},$$

which relates the number N of Fq-rational points on (smooth, geometrically irreducible projective) curves to its genus g and the size of the finite field. This result has inspired a great amount of work in the area, specially after a construction by Goppa [\[Gop81](#page-18-0)] of linear codes with good parameters from curves with many rational points, that is, curves with somewhat large ratio N/g.

In addition to coding theory, curves over finite fields with many rational points have found applications in areas such as finite geometry [\[Hir98](#page-18-1)], correlation of shift register sequences [\[LN97](#page-18-2)], and number theory [\[Mor91,](#page-18-3) [Ste94\]](#page-19-0), among others.

<sup>b</sup>Oxford College of Emory University. 100 Hamill Street, Oxford, Georgia 30054.

Central to the theory of curves over finite fields and its applications is the notion of a maximal curve – a curve that attains the Hasse-Weil upper bound. The Hermitian curve, defined over  $\mathbb{F}_{q^2}$  by

$$y^q + y = x^{q+1},$$

is the classical and most important example of a curve with this property. Due to its many nice arithmetic and geometric properties, there has been substantial interest in finding curves over  $\mathbb{F}_{q^n}$ ,  $n \geq 2$ , that generalizes the Hermitian curve. The simplest generalization of the Hermitian curve is the so-called *norm-trace* curve, which is defined over  $\mathbb{F}_{q^n}$  by

<span id="page-1-0"></span>
$$y^{q^{n-1}} + \dots + y^q = x^{1+q+q^2+\dots+q^{n-1}}.$$
 (1)

Note that when n=2 the curve is just the Hermitian curve. Its genus g is  $(q^{n-1}-1)(q^{n-1}+q^{n-2}+\cdots+q)/2$  and the number N of  $\mathbb{F}_{q^n}$ -rational points of this curve is  $q^{2n-1}+1$ . As demonstrated by Geil [Gei03], the norm-trace curve can be used to construct AG codes with good parameters. In addition, AG codes from the norm-trace curve have been used in different applications to coding theory, see for instance [BR13, FMTT13, Mat09, And07].

In 1999, Garcia and Stichtenoth [GS99] constructed a generalization of the Hermitian curve for which the ratio N/g is larger than the corresponding one for the norm-trace curve. More specifically, for  $n \geq 2$ , they show that the curve defined over  $\mathbb{F}_{q^n}$  by

<span id="page-1-1"></span>
$$\mathcal{GS}: y^{q^{n-1}} + \dots + y^q + y = x^{q+1} + x^{1+q^2} + \dots + x^{q^{n-1}+q^{n-2}}$$
 (2)

has  $N = q^{2n-1} + 1$   $\mathbb{F}_{q^n}$ -rational points and genus  $g = (q^{n-1} - 1)q^{n-1}/2$ . Such curve, that is now commonly known as the generalized Hermitian curve, not only possess a large set of rational points, but also shares many other interesting properties with the norm-trace curve. For instance, Bulygin [Bul06] (for p = 2) and Munuera et al. [MST12] (for p > 2) determined the Weierstrass semigroup  $H(P_{\infty})$  at the only point at infinity  $P_{\infty} = (0:1:0) \in \mathcal{GS}$ . This information is crucial to the construction of algebraic geometric codes (AG codes, for short) with good parameters. Furthermore, Munuera et al. [MST08] proves that the norm-trace curve and the generalized Hermitian curve belong to a class of curves that they call "Castle curves" (see Section 3.2 for definition). Such curves possess certain arithmetic properties that make them suitable for the construction of AG codes with good parameters.

The main purpose of this paper is to introduce a class of curves that generalizes not only the Hermitian curve but also the norm-trace curve and the generalized Hermitian curve  $\mathcal{GS}$ . Similar to the previous generalizations,

our alternative generalization of the Hermitian curve are irreducible curves defined over  $\mathbb{F}_{q^n}$   $(n \geq 2)$  by

<span id="page-2-0"></span>
$$y^{q^{n-1}} + \dots + y^q + y = f(x), \tag{3}$$

where f(x) is a polynomial over  $\mathbb{F}_{q^n}$ . In our construction we consider f(x) to be an element of a large but proper subset of

$$\mathcal{W} := \{ \text{minimal value set polynomials } F(x) \text{ over } \mathbb{F}_{q^n} \text{ with } V_F = \mathbb{F}_q \}, \quad (4)$$

where  $V_F := \{F(\alpha) : \alpha \in \mathbb{F}_{q^n}\}$ , and minimal value set polynomials (MVSPs) are non-constant polynomials F satisfying

$$\#V_F = \left\lfloor \frac{q^n - 1}{\deg F} \right\rfloor + 1.$$

We denote by  $\mathcal{X}$  any curve defined by (3) with  $f(x) \in \mathcal{W}$ . We note that  $\mathcal{X}$  maybe considered as a generalization of the norm-trace curve, the curve  $\mathcal{GS}$  and (consequently) the Hermitian curve. Indeed, for the norm-trace curve it is easy to see that the polynomial on the right-hand side of (1) is in  $\mathcal{W}$ . For the generalized Hermitian curve, our recent progress in the characterization of MVSPs in [BC13] shows that the polynomial on the right-hand side of (2) is in  $\mathcal{W}$  (for more details, see [Bor13, Section 6]).

Our choice of f(x) is inspired by the close connection between MVSPs and q-Frobenius nonclassical curves recently discovered by the second author in [Bor13]. Apart from few special cases, the results in [Bor13, Section 3] imply that an irreducible curve

$$q(y) = f(x), (5)$$

defined over  $\mathbb{F}_q$ , is q-Frobenius nonclassical if and only if  $f(x), g(x) \in \mathbb{F}_q[x]$  are MVSPs with  $V_f = V_g$ . Since  $y^{q^{n-1}} + \cdots + y^q + y \in \mathcal{W}$ , this result shows that  $\mathcal{X}$  is a q-Frobenius nonclassical curve. As such,  $\mathcal{X}$  is worthy of further investigation since the class of q-Frobenius nonclassical curves is well-regarded as a potential source of curves with many rational points and interesting arithmetic and geometric properties, cf. [SV86, HV90].

After a preliminary analysis of some curves of type

$$y^{q^{n-1}} + \dots + y^q + y = f(x),$$

a judicious choice of  $f(x) \in \mathcal{W}$  yields a particular generalization  $\mathcal{H}$  (Section 3) of the Hermitian curve that not only shares many of the nice properties satisfied by the Hermitian curve and its previous generalizations, but also has

a ratio N/g at least  $q^{\frac{n}{2}-3}$  times bigger than the corresponding ratio for the curve  $\mathcal{GS}$ . Just as in the case of the norm-trace and the Garcia-Stichtenoth curves, we are able to compute the genus and the number of rational points of  $\mathcal{H}$  (Proposition 3.1); compute the Weierstrass semigroup of its unique point at infinity  $Q_{\infty}$  (Theorem 3.3); and show that  $\mathcal{H}$  provides new examples of Castle curves (Corollary 3.4). We should mention that, in a companion paper [HBT14], the present generalization of the Hermitian curve is investigated from the perspective of Finite Geometry. In [HBT14], it is shown that some of these curves yield new complete (N, d)-arcs which are closely related to the Artin-Schreier curves studied by Coulter in [Cou02].

To finish, we would like to say a few words about the organization of this work and the techniques used. In Section 2, we discuss some key properties of the underlying polynomials of some of the curves  $\mathcal{X}$ , establish its irreducibility and compute its genus. Here we follow the method used by Garcia-Stichtenoth for the curve  $\mathcal{GS}$  which in turn relies on the theory of Artin-Schreier extensions and on the genus formula for elementary abelian p-extensions of the rational function field. However, as we are dealing with a larger family of curves, the process here will be quite involved. In Section 3, we specialize the results of Section 2 to the particular generalization of the Hermitian curve  $\mathcal{H}$  discussed briefly above. With an eye towards future application to AG codes with good parameters, we also compute in ad hoc manner the Weierstrass semigroup  $H(Q_{\infty})$  at the point at infinity of  $\mathcal{H}$  and show that  $H(Q_{\infty})$  is telescopic (see [KP95, Definition 6.1]). As a consequence of this computation, we show that our present work enlarges the class of Castle curves.

#### <span id="page-3-0"></span>2. Frobenius nonclassical curves from MVSPs

Let  $n \geq 2$  be an integer. As discussed in the introduction, we are interested in the curves  $\mathcal{X}$  defined over  $\mathbb{F}_{q^n}$  by

$$y^{q^{n-1}} + \dots + y^q + y = f(x),$$

where f(x) is an element of

$$\mathcal{W} := \{ \text{MVSPs } F \in \mathbb{F}_{q^n}[x] : V_F = \mathbb{F}_q \}.$$

As noted before,  $\mathcal{X}$  is a q-Frobenius nonclassical curve that generalizes the Hermitian curve. In addition, the following lemma shows that the polynomials in  $\mathcal{W}$  satisfy some of the properties that Garcia-Stichtenoth [GS99, Section 1] observed to be key in the construction of curves with many rational points.

<span id="page-4-1"></span>**Lemma 2.1.** Let f(x) be a polynomial in W. Then:

- (a) The value set of f(x) satisfies  $V_f \subseteq \mathbb{F}_q$ .
- (b)  $f(x) \gamma = 0$  has a simple root for all but possibly one  $\gamma \in \mathbb{F}_q$ .
- (c) Let  $\gamma \in \mathbb{F}_q$ . A root of  $f(x) \gamma = 0$  is not in  $\mathbb{F}_q$  if and only if its multiplicity is divisible by p.

*Proof.* The polynomial f(x) is an MVSP with value set  $\mathbb{F}_q$  by definition. This proves the first item. Items (b) and (c) are just a restatement of Lemma 2.4 in [BC13].

This result provides more evidence that the curves defined by polynomials in  $\mathcal{W}$  may play an important role in the theory of curves over finite fields. Not incidentally, in [BC13] we extended the characterization of MVSPs initiated in [CLMS61, Mil64], and provided a construction of MVSPs over  $\mathbb{F}_{q^n}$  with a given set of values. More importantly, the results in [BC13] allow us to describe the elements of  $\mathcal{W}$  very explicitly. Thus combining the results in [BC13] and [Bor13] we obtain a large source of curves that (potentially) have many rational points. Our goal in this section is to consider a large set of polynomials f(x) in  $\mathcal{W}$  for which we can prove that the associated  $\mathcal{X}$  is absolutely irreducible, and compute its number of  $\mathbb{F}_{q^n}$  rational points and the genus of its non-singular projective model. But before reaching such goal, we take a necessary detour to describe the elements of  $\mathcal{W}$  more explicitly.

<span id="page-4-2"></span>**Definition 1.** •  $t \ge 0$  is an integer.

- $\overline{r} = (r_0, r_1, \dots, r_t)$  is a strictly increasing (t+1)-uple of integers.
- $r_0 = 0$  and  $r_{t+1} = n$ .
- $T_n(x) = x + x^q + \ldots + x^{q^{n-1}}$  is the trace polynomial.

As an extension of [BC13, Theorem 4.7], one can show that any element of W is an  $\mathbb{F}_{q^n}$ -linear combination of polynomials of the form

<span id="page-4-0"></span>
$$\tilde{f}_{\overline{r}}(x) := T_n \left( x^{1+q^{r_1}+q^{r_2}+\dots+q^{r_t}} \right) \mod (x^{q^n} - x),$$
 (6)

see [Bor13, Theorem 2.5] for more details. In fact, we can be more precise: the set  $W \cup \mathbb{F}_q$  is an  $\mathbb{F}_q$ -vector space of dimension  $2^n$  for which an explicit set of generators can be computed (see [BC13, Theorem 4.8]). Notice that W can be quite large since  $\#W = q^{2^n} - q$ . Therefore, we expect that the study of the curves  $\mathcal{X}$  associated to a general polynomial  $f(x) \in W$  to be computationally hard. For that reason in what follows we restrict our attention only to those polynomials in W defined by (6). As we will see, even in this particular case the required computations are quite involved.

### 2.1. The polynomials

Although the right-hand side of (6) is a convenient way of representing the polynomials that generate W, it is not well-suited for computations and for our construction of a generalization of the Hermitian curve. For instance, if we specialize to the case where  $\overline{r} = (0, 1, 2, ..., n-1)$  then  $f_{\overline{r}}(x) = nx^{1+q+q^2+\cdots+q^{n-1}}$  is equal to zero if  $p \mid n$ . In general, it is not clear from (6) what the degree of  $\tilde{f}_{\overline{r}}(x)$  is, or even if  $\tilde{f}_{\overline{r}}(x)$  is non-zero. As we prove below,  $\tilde{f}_{\overline{r}}(x) = \eta f_{\overline{r}}(x)$  for some non-zero integer  $\eta$  and some monic polynomial  $f_{\overline{r}}(x)$ . It is not only more convenient to work with the latter polynomials, but additionally there is no loss in doing so. When  $\tilde{f}_{\overline{r}}(x) \neq 0$ , most of its interesting properties, including the ones discussed in Lemma 2.1, are also satisfied by  $f_{\overline{r}}(x)$ . The aim of this section is to rewrite  $f_{\overline{r}}(x)$  in a form that is more suitable for computations.

<span id="page-5-0"></span>Hereafter, we fix a (t+1)-uple  $\bar{r}$  as in Definition 1 and write  $\tilde{f}(x) = \tilde{f}_{\bar{r}}(x)$ , for simplicity of notation.

**Definition 2.** For each  $i \in \{0, ..., t\}$ , we define

- (1)  $\delta_i = r_{t+1-i} r_{t-i}$  and  $\delta = \min\{\delta_j : j = 0, \dots, t\}$ .
- (2)  $f_0(x) := x^{1+q^{r_1}+q^{r_2}+\cdots+q^{r_t}}$  and let  $f_i(x) := f_{i-1}(x)^{\delta_{i-1}} \mod (x^{q^n}-x)$ , for  $1 \le i \le t$ .
- (3)  $I_i := \{j : f_i(x) = f_i(x)\}$  and  $I := \{\min I_i : i = 0, \dots, t\}$ .
- (4)  $\eta_i = \#I_i \text{ and } \eta = \eta_0.$
- (5)  $f(x) = f_{\bar{r}}(x) := \sum_{e \in I} T_{\delta_e}(f_e(x)).$

**Lemma 2.2.** Following the notation in Definition 2, we have that

(a) For  $i \in \{1, ..., t\}$ ,

$$\deg f_i(x) = 1 + q^{\delta_{i-1}} + \dots + q^{\delta_{i-1} + \delta_{i-2} + \dots + \delta_0} (1 + q^{r_1} + \dots + q^{r_{t-i}})$$

$$= 1 + q^{r_{t-i+2} - r_{t-i+1}} + \dots + q^{r_{t+1} - r_{t-i+1}} (1 + q^{r_1} + \dots + q^{r_{t-i}}).$$

- (b)  $\eta = \eta_0 = \cdots = \eta_t$  and  $\eta$  is a divisor of n.
- (c)  $\tilde{f}(x) = \eta f(x)$ .

*Proof.* The first equality in part (a) follows by induction on i. The second is a consequence of the fact that a sum of the form  $\sum_{k=i}^{j} \delta_{k \mod (t+1)}$  reduces to a sum of one, two or three terms. We leave the details to the reader.

To prove part (b) first note that from part (a)

<span id="page-6-2"></span>
$$\deg f_i(x) = q^{n-\delta_i} + \underbrace{\cdots}_{\text{powers of } q < q^{n-\delta_i}}, \tag{7}$$

for any  $i \in \{0, \dots, t\}$ . This implies that for  $0 \le j \le \delta_i - 1$  we have  $q^j \deg f_i(x) < q^n$ . Therefore  $T_{\delta_i}(f_i(x))$  contains  $\delta_i$  terms of degree  $< q^n$ . By the definition of the  $f_i$ 's, the polynomial  $\sum_{i=0}^t T_{\delta_i}(f_i(x))$  contains the monomial  $f_0(x)^{q^j} \mod (x^{q^n} - x)$ , for  $0 \le j < \sum_{i=0}^t \delta_i$ . Since  $n = \sum_{i=0}^t \delta_i$ , it follows that

<span id="page-6-0"></span>
$$\tilde{f}(x) = \sum_{i=0}^{t} T_{\delta_i}(f_i(x)). \tag{8}$$

If m is a monomial of  $\tilde{f}(x)$ , then the operation  $m^{q^k} \mod (x^{q^n} - x)$  defines an action of  $G := \operatorname{Gal}(\mathbb{F}_{q^n}|\mathbb{F}_q)$  on the set of monomials of  $\tilde{f}(x)$  (cf. [BC13, Proposition 4.2]). Under this action, we identify the stabilizer of  $f_i(x)$  with

$$G_i := \{k \mod n : f_i(x) = f_0(x)^{q^k} \mod (x^{q^n} - x)\}.$$

Now observe that (8) implies that the only monomials of f(x) with degree coprime to p are the  $f_i(x)$ 's. As a consequence  $G_i \subseteq \{\delta_0, \delta_0 + \delta_1, \dots, \sum_{j=0}^t \delta_j\}$ . Therefore,  $G_i = I_i$  and  $\eta_i = \#G_i$ . This shows that  $\eta_i$  divides n = #G. Since any  $f_i(x)$  is, by definition, on the orbit of  $f_0(x)$  by the action of G, we have that  $\eta = \eta_i$  for all  $i \in \{1, \dots, t\}$ . This concludes the proof of part (b).

Part (c) is an easy consequence of 
$$(8)$$
 and part (b).

Observe that the above lemma shows that f(x) is not identically zero and  $\deg f(x) = \max\{\deg T_{\delta_e}(f_e(x)) : e \in I\}$ . The next definition and lemma provide a more explicit way of computing such degree.

**Definition 3.** For  $i, j \in \{0, ..., t\}$  we define

• 
$$\Delta_{i,j} := \sum_{\lambda=0}^{j} \delta_{(i-1-\lambda) \mod (t+1)}$$
.

<span id="page-6-1"></span>• 
$$S_i := (\Delta_{i,0}, \dots, \Delta_{i,t}).$$

**Remark 2.1.** Notice that with these definitions we can write deg  $f_i(x)$  $\sum_{i=0}^t q^{\Delta_{i,j}-\delta_i} \text{ and } \deg T_{\delta_i}(f_i(x)) = \sum_{i=0}^t q^{\Delta_{i,j}-1}.$ 

<span id="page-7-0"></span>Corollary 2.3. Let M be such that  $S_M$  is the largest sequence, in the lexicographic order, amongst the distinct sequences  $\{S_e : e \in I\}$ . Then  $\deg f(x) =$  $\sum_{j=0}^{\iota} q^{\Delta_{M,j}-1}.$ 

*Proof.* This is a consequence of Remark 2.1 and the fact that the entries of the sequence  $S_i$  are increasing. 

The next result presents a case where we can compute deg f(x) exactly.

<span id="page-7-3"></span>Corollary 2.4. If 
$$\delta_0 < \cdots < \delta_t$$
, then deg  $f(x) = q^{r_1 - 1} + \cdots + q^{r_t - 1} + q^{n-1}$ .

*Proof.* Notice that  $S_i = (\delta_{i-1 \mod (t+1)}, \ldots, n - \delta_i)$ . The hypotheses on  $\delta_i$  imply that  $S_0$  is the largest sequence in lexicographic order. Then by Corollary 2.3,  $\deg f(x) = \sum_{i=0}^t q^{\sum_{i=0}^j \delta_{t-i}-1} = \sum_{i=0}^t q^{r_{j+1}-1}$  as desired.

2.3, 
$$\deg f(x) = \sum_{j=0} q^{\sum_{i=0}^{s} o_{t-i}-1} = \sum_{j=0} q^{r_{j+1}-1}$$
 as desired.

We end this section by proving a sequence of lemmata that is used in the computation of the genus of curves to be defined in the next section.

<span id="page-7-1"></span>**Lemma 2.5.** If  $m \in \{0, \dots, t\}$  is such that deg  $f_m(x)$  is maximal, that is

$$\deg f_m(x) = \max\{\deg f_i(x) : i = 0, \dots, t\},\$$

Moreover, if deg  $f_i(x)$  is not maximal then deg  $f_m(x)$ then  $\delta_m = \delta$ .  $q^{\delta_i-\delta-1} \operatorname{deg} f_i(x)$ .

*Proof.* From (7), it follows that deg  $f_m(x) \ge \deg f_i(x)$  implies  $q^{n-\delta_m} \ge q^{n-\delta_i}$ , which gives  $\delta_m \leq \delta_i$  for all  $i \in \{0, \dots, t\}$ . This proves the first assertion. For the second one, since

$$q^{\delta_i - \delta - 1} \operatorname{deg} f_i(x) = q^{n - \delta - 1} + \underbrace{\cdots}_{\text{powers of } q < q^{n - \delta - 1}},$$

we have  $q^{\delta_i - \delta - 1} \deg f_i(x) < \deg f_m(x)$ , which finishes the proof. 

<span id="page-7-2"></span>**Lemma 2.6.** There exist polynomials u(x) and v(x) such that

$$f(x) = T_{\delta}(u(x)) + v(x)^{q^{\delta}}, \tag{9}$$

 $\deg u(x) \equiv 1 \mod p$ , and  $\deg v(x) < \deg u(x)$ . Moreover,  $\deg u(x) = \deg f_M(x)$ where M is such that  $S_M$  is the largest sequence, amongst the distinct sequences  $\{S_e : e \in I\}$ .

*Proof.* Using the minimality of  $\delta$  we are able to write

$$f(x) = \sum_{e \in I} T_{\delta_e}(f_e(x)) = T_{\delta} \left( \sum_{e \in I} f_e(x) \right) + \left( \sum_{e \in I} T_{\delta_e - \delta}(f_i(x)) \right)^{q^{\delta}},$$

with the assumption that  $T_0 \equiv 0$ . We set  $u(x) := \sum_{e \in I} f_e(x)$  and  $v(x) := \sum_{e \in I} T_{\delta_e - \delta}(f_e(x))$ . Note that u(x) is not identically zero, since  $f_{e_1}(x) \neq f_{e_2}(x)$  for distinct  $e_1, e_2 \in I$ . Considering m as given in Lemma 2.5, then  $\deg u(x) = \deg f_m(x)$ . Observe that this also shows that  $\deg u(x) \equiv 1$  mod p. As for the polynomial v(x), one can see that

$$\deg v(x) = \max\{q^{\delta_e - \delta - 1} \deg f_e(x) : \delta_e \neq \delta, e \in I\}.$$

Now, since  $\delta_e \neq \delta$ , it follows from Lemma 2.5 that  $\deg f_e(x)$  is not maximal, and then that  $q^{\delta_e - \delta - 1} \deg f_e(x) \leq \deg f_m(x)$ . Hence  $\deg v(x) < \deg u(x)$ .  $\square$ 

### 2.2. The curves

Similar to the case of the curves  $\mathcal{GS}$  defined by (2), our generalization of the Hermitian curve is given by certain elementary abelian p-extensions of a rational function field  $\bar{\mathbb{F}}_q(x)$ . Namely, we consider the curves defined over  $\mathbb{F}_{q^n}$  by

<span id="page-8-0"></span>
$$y^{q^{n-1}} + \ldots + y^q + y = f(x), \tag{10}$$

where  $f(x) := f_{\bar{r}}(x)$  is given by Definition 2(5). The goal of this section is to compute the genus of a non-singular projective model  $\mathcal{F}$  of such curve and its number of rational points.

The following two lemmas are used in the proof of the absolute irreducibility of the curve given by (10).

<span id="page-8-1"></span>**Lemma 2.7.** Let  $\alpha \in \overline{\mathbb{F}}_q$  and suppose  $T_m(\alpha) = T_n(\alpha) = 0$ . If gcd(m, n) = 1 then  $\alpha = 0$ .

Proof. Note that  $T_m(\alpha) = T_n(\alpha) = 0$  implies  $\alpha \in \mathbb{F}_{q^m} \cap \mathbb{F}_{q^n} = \mathbb{F}_q$ , by the coprimality condition. But then  $0 = T_m(\alpha) = m\alpha$  and  $0 = T_n(\alpha) = n\alpha$ . Thus  $\alpha = 0$ , otherwise we arrive at the contradiction  $p \mid \gcd(m, n) = 1$ .

<span id="page-8-2"></span>**Lemma 2.8.** Let n and m be non-negative integers, with  $n \geq m$ . The polynomial in  $\mathbb{F}_q[x,y]$  defined by

$$S = S_{m,n}(x,y) := \begin{cases} 0, & \text{if } m = 0\\ \sum_{i=0}^{m-1} y^{q^{n-1-i}} T_{m-i}(x), & \text{if } m > 0 \end{cases}$$

satisfies 
$$S^{q} - S = y^{q^{n}} T_{m+1}(x) - x T_{m+1}(y^{q^{n-m}}).$$

*Proof.* The case m=0 is trivial, thus we assume that m>0. Since  $S=y^{q^{n-1}}T_m(x)+y^{q^{n-2}}T_{m-1}(x)+\cdots+y^{q^{n-m}}T_1(x)$ , we have

$$S^{q} = y^{q^{n}}(T_{m+1}(x) - x) + y^{q^{n-1}}(T_{m}(x) - x) + \dots + y^{q^{n-m+1}}(T_{2}(x) - x)$$

$$= y^{q^{n}}T_{m+1}(x) + \dots + y^{q^{n-m+1}}T_{2}(x) - xT_{m+1}(y^{q^{n-m}}) + y^{q^{n-m}}x$$

$$= y^{q^{n}}T_{m+1}(x) + S - y^{q^{n-m}}T_{1}(x) - xT_{m+1}(y^{q^{n-m}}) + y^{q^{n-m}}x$$

$$= y^{q^{n}}T_{m+1}(x) + S - xT_{m+1}(y^{q^{n-m}}),$$

which gives  $S^q - S$  as claimed.

We are ready to prove the main result of this section.

<span id="page-9-0"></span>**Theorem 2.9.** Let  $n \geq 2$  be an integer, and  $\delta$  be given as in Definition 2. Let u(x) be the polynomial over  $\mathbb{F}_{q^n}$  given as in Lemma 2.6. If  $gcd(\delta, n) = 1$  then the curve defined by (10) is irreducible and its non-singular projective model  $\mathcal{F}$  has genus

$$g(\mathcal{F}) = \frac{(q^{n-1} - 1)(\deg u(x) - 1)}{2},$$

and

$$\#\mathcal{F}(\mathbb{F}_{q^n}) = q^{2n-1} + 1.$$

*Proof.* Our proof relies on few facts of the Artin-Schreier theory. For more details, we refer to the introduction of [GS91, Section 1] and the reference therein.

Denote by F = K(x) the rational function field over  $K = \overline{\mathbb{F}}_q$ , and consider the field extension E/F, where E = K(x,y) and x and y satisfy (10). We will prove that (10) is absolutely irreducible, by showing that  $[E:F] = q^{n-1}$ . For this matter, define  $\wp: X \mapsto X^p - X$  to be the Artin-Schreier operator on K(x) and

$$A := \left\{ -T_{\delta}(\alpha^{q^{n-\delta+1}})u(x) - \alpha^{q^{n-\delta}}v(x) : T_n(\alpha) = 0 \right\} \subseteq K(x),$$

where the polynomials u(x) and v(x) are such that  $f(x) = T_{\delta}(u(x)) + v(x)^{q^{\delta}}$ , deg  $u(x) \equiv 1 \mod p$  and deg  $v(x) < \deg u(x)$  (cf. Lemma 2.6). It is clear that  $A \subseteq K[x]$  is an additive subgroup, and that  $\gcd(\delta, n) = 1$  and Lemma 2.7 imply  $|A| = q^{n-1}$ . We claim that

$$A \cap \wp(K(x)) = \{0\}.$$

In fact, suppose that  $w := -T_{\delta}(\alpha^{q^{n-\delta+1}})u(x) - \alpha^{q^{n-\delta}}v(x)$  is such that  $w \in A \cap \wp(K(x))$ . That is, the polynomial  $X^p - X - w \in K[x][X]$  has a root in

K(x). Since UFDs are integrally closed, such a root must be a polynomial and then  $p \mid \deg w$ . On the other hand, since  $\deg u(x) \equiv 1 \mod p$  and  $\deg v(x) < \deg u(x)$ , it follows that  $T_{\delta}(\alpha^{q^{n-\delta+1}}) = 0$ , and then  $T_{\delta}(\alpha) = 0$ . But since  $T_n(\alpha) = 0$  and  $\gcd(\delta, n) = 1$ , Lemma 2.7 implies  $\alpha = 0$  and consequently w = 0.

From Artin-Schreier theory,  $F(\wp^{-1}(A))$  is an abelian extension of F of degree  $|A| = q^{n-1}$ . Therefore,  $[E:F] = q^{n-1}$  and (10) is absolutely irreducible, as desired, if we can show that  $F(\wp^{-1}(A)) \subset E$ .

In order to prove that  $F(\wp^{-1}(A)) \subset E$ , we chose an element  $\alpha \in K^*$  such that  $T_n(\alpha) = 0$ , and let  $S_{m,n}(x,y)$  be the polynomial given in Lemma 2.8. Consider the element  $z \in E$  given by

$$z = S_{n-1,n-1}(\alpha, y) + S_{\delta-1,n}(u(x), \alpha) + T_{\delta}(\alpha^{q^{n-\delta}}v(x)).$$

Lemma 2.8 gives

$$z^{q} - z = -\alpha T_{n}(y) + \alpha^{q^{n}} T_{\delta}(u(x)) - u(x) T_{\delta}(\alpha^{q^{n-\delta+1}}) + (\alpha^{q^{n-\delta}} v(x))^{q^{\delta}} - \alpha^{q^{n-\delta}} v(x)$$

$$= -\alpha f(x) + \alpha T_{\delta}(u(x)) + \alpha v(x)^{q^{\delta}} - T_{\delta}(\alpha^{q^{n-\delta+1}}) u(x) - \alpha^{q^{n-\delta}} v(x)$$

$$= -T_{\delta}(\alpha^{q^{n-\delta+1}}) u(x) - \alpha^{q^{n-\delta}} v(x).$$

Write  $q = p^e$ . If we let  $z_t := z^{p^{e-1}} + \cdots + z^p + z$  then  $z_t \in E$  and

$$z_t^p - z_t = z^q - z = -T_\delta(\alpha^{q^{n-\delta+1}})u(x) - \alpha^{q^{n-\delta}}v(x).$$

Therefore, E contains the splitting fields of  $X^p - X - a$ , with  $a \in A$  and consequently  $F(\wp^{-1}(A)) \subset E$  as desired.

We now use the fact that E is an elementary abelian p-extension to compute its genus. It is known from Artin-Schreier theory that E contains  $\nu = (q^n - 1)/(p - 1)$  distinct degree-p sub-extensions  $E_i \subseteq E$  given by the splitting fields of  $X^p - X = a$ , with  $a \in A^*$ . Note that since  $p \nmid \deg u(x)$ , the genus of each such extension is  $g(E_i) = (p - 1)(\deg u(x) - 1)/2$ . By [GS91, Theorem 2.1], the genus of the curve  $\mathcal{F}$  can be computed by the formula

$$g(\mathcal{F}) = g(E) = \sum_{i=1}^{\nu} g(E_i) - \frac{p}{p-1}g(F).$$

Note that in our case g(F) = g(K(x)) = 0. Therefore

$$g(\mathcal{F}) = \frac{q^{n-1} - 1}{n-1} \cdot \frac{(\deg u(x) - 1)(p-1)}{2} = \frac{(\deg u(x) - 1)(q^{n-1} - 1)}{2}.$$

To compute the number of  $\mathbb{F}_{q^n}$ -rational points of  $\mathcal{F}$ , we first note that the pole of x is totally ramified in E/F (see e.g. [Deo02, Theorem 3.3]).

That gives us one rational point of  $\mathcal{F}$ , namely Q = (0:1:0). Lemma 2.1(1) implies that for any  $\alpha \in \mathbb{F}_{q^n}$  we have  $\beta := f(\alpha) \in \mathbb{F}_q$ . There are  $q^{n-1}$  elements  $\gamma \in \mathbb{F}_{q^n}$  satisfying

$$\gamma^{q^{n-1}} + \dots + \gamma^q + \gamma = \beta = f(\alpha).$$

This shows that there are  $q^n \cdot q^{n-1} + 1 = q^{2n-1} + 1 \mathbb{F}_{q^n}$ -rational points on  $\mathcal{F}$ .

<span id="page-11-1"></span>Corollary 2.10. If  $\delta_0 \leq \cdots \leq \delta_t$  then  $\deg f(x) = q^{r_1-1} + \cdots + q^{r_t-1} + q^{n-1}$ . Moreover, the curve  $\mathcal{F}$  has genus

$$g = \frac{1}{2}(q^{n-1} - 1) \sum_{i=0}^{t-1} q^{\sum_{j=0}^{i} \delta_{t-j}}.$$

*Proof.* See Corollary 2.4 for the computation of  $\deg f(x)$ . From Theorem 2.9, the formula for the genus will follow if we can show that  $\deg u(x) = \sum_{i=0}^{t-1} q^{\sum_{j=0}^{i} \delta_{t-j}}$ . But the latter equality is just an immediate consequence of Lemma 2.6 in the case  $\delta_0 \leq \cdots \leq \delta_t$ . This finishes the proof.

# <span id="page-11-0"></span>3. An alternative generalization of the Hermitian curve and its properties

#### 3.1. Curves with many rational points

As discussed in the introduction and the references therein, the construction of curves with large ratio N/g is usually very challenging and have applications to coding theory. In the previous section we have proved that our generalization  $\mathcal{F}$  of the Hermitian curve has  $N = q^{2n-1} + 1 \mathbb{F}_{q^n}$ -rational points. Their genus g, however, is directly proportional to  $\deg u(x) = \mathcal{O}(q^{n-\delta})$ , where  $\delta = \min\{\delta_i : i = 0, \dots, t\}$ . Therefore the largest ratio N/g will be achieved when  $\delta$  is large compared to n. Clearly the best case scenario is when  $\delta \approx n/2$ , and that can only happen when t = 1. Such conditions lead us to highlight the following particular case of the curves discussed in the previous section.

Let  $n \ge 2$  be an integer and define  $r = r(n) \ge n/2$  as being the smallest integer such that gcd(n,r) = 1, i.e.,

$$r = \begin{cases} 1, & \text{if} & n = 2\\ n/2 + 1, & \text{if} & n \equiv 0 \pmod{4}\\ n/2 + 2, & \text{if} & n \ge 6, n \equiv 2 \pmod{4}\\ (n+1)/2, & \text{if} & n \text{ is odd} \,. \end{cases}$$
(11)

Let  $\mathcal{H}$  be the projective plane curve defined by the affine equation

<span id="page-12-2"></span>
$$y^{q^{n-1}} + \ldots + y^q + y = f_{\bar{r}}(x), \tag{12}$$

where  $\bar{r} = (0, r)$  and  $f_{\bar{r}}(x)$  is given as in Definition 2(5).

### <span id="page-12-1"></span>**Proposition 3.1.** If $\mathcal{H}$ is as defined above, then:

- 1.  $\mathcal{H}$  has degree  $q^{n-1} + q^{r-1}$ , genus  $q^r(q^{n-1} 1)/2$  and its number of  $\mathbb{F}_{q^n}$ -rational points is  $q^{2n-1} + 1$ .
- 2.  $\mathcal{H}$  has just one point at infinity, namely Q = (0:1:0), which is also its only singular point whenever  $n \geq 3$ .
- 3. Furthermore, the curve is  $q^n$ -Frobenius nonclassical.

Proof. We follow the notation in Section 2. Since  $\bar{r} = (0, r)$  and r > n/2 we have  $\delta_0 = n - r < r = \delta_1$ . That gives us the two distinct sequences  $S_0 = (\delta_1, \delta_1 + \delta_0)$  and  $S_1 = (\delta_0, \delta_0 + \delta_1)$  with  $S_1 < S_0$  in the lexicographical ordering. Also note that  $\gcd(r, n) = 1$  implies that  $n - r = \delta = \min\{\delta_0, \delta_1\}$  is coprime to n.

Part (1) is a direct consequence of Theorem 2.9 and Corolary 2.10. Part (2) follows from the proof of Theorem 2.9 and the Jacobian criterion, while part (3) follows from [Bor13, Corollary 3.8].

The generalized Hermitian curve  $\mathcal{GS}$  has  $N = q^{2n-1} + 1$   $\mathbb{F}_{q^n}$ -rational points and genus  $g = (q^{n-1} - 1)q^{n-1}/2$ . Note that our curve  $\mathcal{H}$  has the same number of  $\mathbb{F}_{q^n}$ -rational points, but a genus  $(q^{n-1} - 1)q^r/2$ , which is considerably smaller than  $(q^{n-1} - 1)q^{n-1}/2$  (since  $r \approx n/2$ ). For example, for q = 2 and n = 5 the curve  $\mathcal{GS}$  has 513  $\mathbb{F}_{32}$ -rational points and genus  $g(\mathcal{GS}) = 120$ , while the curve  $\mathcal{H}$  has 513  $\mathbb{F}_{32}$ -rational points, but genus  $g(\mathcal{H}) = 60$ . We should mention that, by the Osterlé bound (see e.g. [Ser83]), a curve over  $\mathbb{F}_{32}$  and with 512 rational points has genus  $g \geq 57$ .

# <span id="page-12-0"></span>3.2. Castle curves and the Weierstrass semigroup at the point at infinity of $\mathcal{H}$

Let Q be an  $\mathbb{F}_{q^n}$ -rational point in a curve X over  $\mathbb{F}_{q^n}$  and write its Weierstrass semigroup as  $H(Q) = \{m_1 = 0 < m_2 < \ldots\}$ . The curve X is called a Castle curve if H(Q) is symmetric and  $\#X(\mathbb{F}_{q^n}) = q^n m_2 + 1$ . As discussed in the introduction of [MST08], AG codes are usually difficult to handle if the geometry of the associated curve is not well understood. Because Castle curves possess some geometric properties that provide a good handling of the parameters of the associated code, they are well suited for constructing AG codes. In fact, many of the examples of curves yielding AG codes with good parameters are Castle curves. As proved by Bulygin [Bul06], in the case

q=2, and Munuera, Sepúlveda, and Torres [MST12] in the general case, the curve  $\mathcal{GS}$  yields linear codes with new records on the parameters. Not incidentally, [MST08] proves that  $\mathcal{GS}$  is a Castle curve. As is usual in this kind of application, the starting point of such results was the computation of the Weierstrass semigroup at  $P=(0:1:0)\in\mathcal{GS}$ .

**Theorem 3.2** ([MST12, Proposition 2.2]). The Weierstrass semigroup at P is

$$H(P) = \langle q^{n-1}, q^{n-1} + q^{n-2}, q^n + 1 \rangle.$$

In particular it is symmetric.

Given that the norm-trace and the generalized Hermitian curves are Castle curves, it is tempting to suspect that many of the curves  $\mathcal{X}$  (as defined in Section 2) are also Castle Curves, and may be used for the construction of AG codes with good parameters. The aim of this section is to use the curve  $\mathcal{H}$  to provide more evidence to support this idea. For this matter, we compute the Weierstrass semigroup at the unique point at infinity of  $\mathcal{H}$ .

Following the notation in the proof of Theorem 2.9, we let E = K(x, y) be the function field of the curve defined by (12), and Q = (0:1:0) be the only pole of the function  $x \in E$ .

<span id="page-13-0"></span>**Theorem 3.3.** Suppose  $n \geq 3$ , and let H(Q) be the Weierstrass semigroup at Q. Then

$$H(Q) = \left\langle q^{n-1}, q^{n-1} + q^{r-1}, q^n + q^{n-r}, q^{2r-1} + q^{n-r-1}, q^{2r} - q^n + q^r + 1 \right\rangle.$$

Moreover, H(Q) is a telescopic semigroup and, in particular, symmetric.

<span id="page-13-1"></span>Corollary 3.4.  $\mathcal{H}$  is a Castle curve.

*Proof.* It follows directly from the fact that

$$H(Q) = \left\langle q^{n-1}, q^{n-1} + q^{r-1}, q^{2r-1} + q^{n-r-1}, q^{2r} - q^n + q^r + 1 \right\rangle$$

is symmetric, 
$$m_2 = q^{n-1}$$
 and  $\mathcal{F}(\mathbb{F}_{q^n}) = q^{2n-1} + 1 = q^n m_2 + 1$ .

The reminder of this section is used to prove Theorem 3.3 via a collection of partial results. The following remark is key in most of our computations.

Remark 3.1. It follows from (12) that

<span id="page-13-2"></span>
$$y^{q^n} = y - x^{q^{n-r}+1} - x^{q^r+1} + x^{q^{n-r}+q^n} + x^{q^n+q^r}.$$
 (13)

**Lemma 3.5.** Let  $s = x^{q^{2r-n}-1}y - x^{1+q^r} + y^{q^r} - x^{q^{2r-n}+q^r}$  be a function in E. Then:

- $\operatorname{div}_{\infty}(x) = q^{n-1}Q$ ;
- $\operatorname{div}_{\infty}(y) = (q^{n-1} + q^{r-1})Q$ ; and
- $\operatorname{div}_{\infty}(s) = (q^{2r-1} + q^{n-r-1})Q$ .

*Proof.* See proof of Theorem 2.9, for the fact that  $\operatorname{div}_{\infty}(x) = q^{n-1}Q$ . From (12), it follows that Q is the only pole of y. To compute its order, let  $v_Q$  be the valuation at Q and notice that

$$q^{n-1}v_Q(y) = v_Q(f(x)) = (q^{n-1} + q^{r-1})v_Q(x).$$

This implies  $\operatorname{div}_{\infty}(y) = (q^{n-1} + q^{r-1})Q$ . For the function s, note that (13) gives

$$s^{q^{n}} = x^{q^{2r}-q^{n}}(y - x^{q^{r}+1} - x^{q^{n-r}+1} + x^{q^{n}+q^{r}} + x^{q^{n-r}+q^{n}}) - x^{q^{n+r}+q^{n}} + (y - x^{q^{r}+1} - x^{q^{n-r}+1} + x^{q^{n}+q^{r}} + x^{q^{n-r}+q^{n}})^{q^{r}} - x^{q^{2r}+q^{n+r}}.$$

Therefore,

<span id="page-14-0"></span>
$$s^{q^n} = x^{q^{2r} - q^n} (y - x^{q^r + 1} - x^{q^{n-r} + 1} + x^{q^n + q^{n-r}}) + (y - x^{q^{n-r} + 1})^{q^r}.$$
 (14)

Since we know the order of each term on the right-hand side of the above equation, the triangle inequality gives us

$$v_Q(s^{q^n}) = v_Q(x^{q^{2r}+q^{n-r}}) = -q^{n-1}(q^{2r}+q^{n-r}).$$

Thus

$$\operatorname{div}_{\infty}(s) = (q^{2r-1} + q^{n-r-1})Q.$$

**Lemma 3.6.** For  $n \geq 3$ , define the following functions in E:

• 
$$w_0 = y + y^{q^r} - x^{1+q^r} - x^{q^{2r-n}+q^r}$$

$$\bullet \ w_1 = \begin{cases} y^{q^{n-r}} - x^{1+q^{n-r}} + \sum_{i=0}^{\frac{2n-3r-1}{2r-n}} w_0^{q^{1+(2r-n)i}}, & if \ r \not\equiv 3 \mod 4 \\ y^{q^{n-r+1}} - x^{q+q^{n-r+1}} + \sum_{i=0}^{\frac{2n-3r+1}{2r-n}} w_0^{q^{(2r-n)i}}, & if \ r \not\equiv 1 \mod 4 \end{cases}$$

• 
$$w_2 := x^{q^{2r-n+1}-q}w_1 - s^q + x^{q^{2r-n+1}-q^{2r-n}-q+1}s$$
.

Then  $\operatorname{div}_{\infty}(w_1) = (q^n + q^{n-r})Q$  and  $\operatorname{div}_{\infty}(w_2) = (q^{2r} - q^n + q^r + 1)Q$ .

(i) We will prove the case  $r \not\equiv 3 \mod 4$ ; the other one is analogous. To find the order of  $w_1^{q^n}$ , first note that from (13)

• 
$$(y^{q^{n-r}} - x^{1+q^{n-r}})^{q^n} = y^{q^{n-r}} - x^{q^{n-r} + q^{2n-2r}} - x^{q^{n-r} + q^n} + x^{q^{2n-r} + q^{2n-2r}},$$
  
and

• 
$$w_0^{q^n} = y + y^{q^r} - x^{1+q^{n-r}} - x^{1+q^r} + x^{q^{n-r}+q^n} - x^{q^r+q^{2r}}$$

The assumption on r implies that t := (n-r-1)/(2r-n) is an integer. Thus we have

$$w_1^{q^n} = y^{q^{n-r}} - x^{q^{n-r}+q^{2n-2r}} - x^{q^{n-r}+q^n} + x^{q^{2n-r}+q^{2n-2r}} + \sum_{i=0}^{t-1} (y + y^{q^r} - x^{1+q^r})^{q^{1+(2r-n)i}} - \sum_{i=0}^{t-1} (x^{1+q^{n-r}})^{q^{1+(2r-n)i}} + \sum_{i=0}^{t-1} (x^{q^{n-r}+q^n})^{q^{1+(2r-n)i}} - \sum_{i=0}^{t-1} (x^{q^r+q^{2r}})^{q^{1+(2r-n)i}}.$$

It can be easily checked that

$$\sum_{i=0}^{t-1} (x^{1+q^{n-r}})^{q^{1+(2r-n)i}} = x^{q+q^{n-r+1}} - x^{q^{n-r}+q^{2n-2r}} + \sum_{i=0}^{t-1} (x^{q^{2r-n}+q^r})^{q^{1+(2r-n)i}}$$
 and

$$\bullet \ \sum_{i=0}^{t-1} (x^{q^{n-r}+q^n})^{q^{1+(2r-n)i}} - \sum_{i=0}^{t-1} (x^{q^r+q^{2r}})^{q^{1+(2r-n)i}} = x^{q^{n-r+1}+q^{n+1}} - x^{q^{2n-2r}+q^{2n-r}}$$

Therefore

<span id="page-15-0"></span>
$$w_1^{q^n} = w_1 - x^{q+q^{n-r+1}} + x^{q^{n-r+1}+q^{n+1}} + x^{1+q^{n-r}} - x^{q^{n-r}+q^n},$$
 (15)

and since  $v_Q(w_1^{q^n} - w_1) = v_Q(-x^{q+q^{n-r+1}} + x^{q^{n-r+1}+q^{n+1}} + x^{1+q^{n-r}} - x^{q^{n-r}+q^n})$ , triangle inequality gives  $q^n v_Q(w_1) = v_Q(x^{q^{n-r+1}+q^{n+1}})$ . Hence  $v_Q(w_1) = -(q^{n-r} + q^n).$ (ii) From  $w_2^{q^n} = x^{q^{2r+1} - q^n} w_1^{q^n} - s^{q^{n+1}} + x^{q^{2r+1} - q^{2r} - q^{n+1} + q^n} s^{q^n}$ , and equations

(14) and (15), we obtain

$$\begin{split} w_2^{q^n} &= x^{q^{2r+1}-q^{n+1}} w_1 + x^{q^{2r+1}-q^{n+1}} \big( -x^{q+q^{n-r+1}} + x^{q^{n-r+1}+q^{n+r}} + x^{\frac{1+q^{n-r}}{2r}} - x^{\frac{q^{n-r}+q^n}{2r}} \big) \\ &- x^{q^{2r+1}-q^{n+1}} \big( y^q - x^{q^{r+1}+q} - x^{\frac{q^{n-r}+1+q}} + x^{\frac{q^{n+1}+q^{n-r+1}}{2r}} \big) + \big( y - x^{q^{n-r}+1} \big)^{q^{r+1}} \\ &+ x^{q^{2r+1}-q^{n+1}} \big( y - x^{q^{r}+1} - x^{\frac{q^{n-r}+1}{2r}} + x^{\frac{q^{n}+q^{n-r}}{2r}} \big) + x^{q^{2r+1}-q^{2r}-q^{n+1}+q^n} \big( y - x^{q^{n-r}+1} \big)^{q^r}. \end{split}$$

After rearranging terms, we have

$$w_2^{q^n} = x^{q^{2r+1}-q^{n+1}} (w_1 + y - y^q - x^{q^r+1} - x^{q^{n-r}+1})$$

$$+ (y - x^{q^{n-r}+1})^{q^{r+1}} + x^{q^{2r+1}-q^{2r}-q^{n+1}+q^n} (y - x^{q^{n-r}+1})^{q^r}$$

$$+ x^{q^{2r+1}-q^{n+1}+q^{r+1}+q}.$$

It can be checked that all terms of such sum have different order at Q. The triangle inequality gives  $v_Q(w_2^{q^n}) = v_Q(x^{q^{2r+1}-q^{n+1}+q^{r+1}+q})$ , and then  $v_Q(w_2) = -(q^{2r} - q^n + q^r + 1)$ .

We are ready to prove the main result of this section.

Proof of Theorem 3.3. The inclusion

$$H(Q) \supseteq \langle q^{n-1}, q^{n-1} + q^{r-1}, q^n + q^{n-r}, q^{2r-1} + q^{n-r-1}, q^{2r} - q^n + q^r + 1 \rangle$$

follows immediately from the previous lemmas.

To prove equality, we first show that the semigroup  $S = \langle q^{n-1}, q^{n-1} + q^{r-1}, q^{2r-1} + q^{n-r-1}, q^{2r} - q^n + q^r + 1 \rangle$  is telescopic, see [KP95, Definition 6.1]. Using the notation therein we find that

- $d_1 = q^{n-1}$  and  $S_1 = \langle 1 \rangle$ ;
- $d_2 = q^{r-1}$  and  $S_2 = \langle q^{n-r}, q^{n-r} + 1 \rangle$ ;
- $d_3 = q^{n-r}$  and  $S_3 = \langle q^{r-1}, q^{r-1} + q^{2r-n-1}, q^r + 1 \rangle$ ; and
- $d_4 = q^{n-r-1}$  and  $S_4 = \langle q^r, q^r + q^{2r-n}, q^{r+1} + q, q^{3r-n} + 1 \rangle$ .
- $d_5 = 1$  and  $S_5 = S$ .

Clearly,  $q^{n-r} + 1 \in S_1$  and  $q^r + 1 \in S_2$ . Also,

$$q^{3r-n} + 1 = (q^{2r-n+1} - q)q^{r-1} + (q^r + 1) \in S_3,$$

and

$$q^{2r} - q^n + q^r + 1 = (q^r - q^{n-r} - q^{2r-n} + 1)q^r + (q^{3r-n} + 1) \in S_4.$$

Therefore, S is telescopic. In particular it is symmetric (see [KP95, Lemma 6.5]). To finish the proof of the theorem, all we are left to show is that the genus of S is equal to the genus of the curve given by (12). To compute the genus of S we use the formula (see [KP95, Lemma 6.5])

$$g(S) = \left(\sum_{i=1}^{5} (d_{i-1}/d_i - 1)a_i + 1\right)/2,$$

for the genus of a telescopic semigroup. This shows that  $g(S) = q^r(q^{n-1} + 1)/2$ , which is indeed the genus of our curve (see Theorem 2.9).

# 4. Acknowledgments

The first author was partially supported by FAPESP-Brazil grant 2011/19446- 3.

## References

- <span id="page-17-3"></span>[And07] Henning E. Andersen, *On puncturing of codes from norm-trace curves*, Finite Fields Appl. 13 (2007), no. 1, 136–157. MR 2287392 (2007j:94083)
- <span id="page-17-5"></span>[BC13] Herivelto Borges and Ricardo Concei¸c˜ao, *On the characterization of minimal value set polynomials*, Journal of Number Theory 133 (2013), no. 6, 2021 – 2035.
- <span id="page-17-6"></span>[Bor13] Herivelto Borges, *Frobenius nonclassical components of curves with separated variables*, http://arxiv.org/abs/1311.4438 (2013).
- <span id="page-17-1"></span>[BR13] Edoardo Ballico and Alberto Ravagnani, *On the duals of geometric Goppa codes from norm-trace curves*, Finite Fields Appl. 20 (2013), 30–39. MR 3015349
- <span id="page-17-4"></span>[Bul06] S. V. Bulygin, *Generalized Hermitian codes over* GF(2<sup>r</sup> ), IEEE Trans. Inform. Theory 52 (2006), no. 10, 4664–4669. MR 2300850 (2008a:94183)
- <span id="page-17-8"></span><span id="page-17-7"></span>[CLMS61] L. Carlitz, D. J. Lewis, W. H. Mills, and E. G. Straus, *Polynomials over finite fields with minimal value sets*, Mathematika 8 (1961), 121–130. MR MR0139606 (25 #3038)
  - [Cou02] Robert S. Coulter, *The number of rational points of a class of Artin-Schreier curves*, Finite Fields Appl. 8 (2002), no. 4, 397– 413. MR 1933612 (2003i:11080)
  - [Deo02] Vinay Deolalikar, *Determining irreducibility and ramification groups for an additive extension of the rational function field*, J. Number Theory 97 (2002), no. 2, 269–286. MR 1942960 (2004d:11114)
- <span id="page-17-9"></span><span id="page-17-2"></span><span id="page-17-0"></span>[FMTT13] J. I. Farr´an, C. Munuera, G. Tizziotti, and F. Torres, *Gr¨obner basis for norm-trace codes*, J. Symbolic Comput. 48 (2013), 54– 63. MR 2980466
  - [Gei03] Olav Geil, *On codes from norm-trace curves*, Finite Fields Appl. 9 (2003), no. 3, 351–371. MR 1983054 (2004g:94092)

- <span id="page-18-0"></span>[Gop81] V. D. Goppa, *Codes on algebraic curves*, Dokl. Akad. Nauk SSSR 259 (1981), no. 6, 1289–1290. MR 628795 (82k:94017)
- <span id="page-18-10"></span>[GS91] Arnaldo Garc´ıa and Henning Stichtenoth, *Elementary abelian* p*-extensions of algebraic function fields*, Manuscripta Math. 72 (1991), no. 1, 67–79. MR MR1107453 (92j:11139)
- <span id="page-18-5"></span>[GS99] Arnaldo Garcia and Henning Stichtenoth, *A class of polynomials over finite fields*, Finite Fields and Their Applications 5 (1999), no. 4, 424 – 435.
- <span id="page-18-7"></span><span id="page-18-6"></span><span id="page-18-1"></span>[HBT14] Beatriz Motta Herivelto Borges and Fernando Torres, *Complete arcs arising from a generalizations of the hermitian curve*, http://arxiv.org/abs/ (2014).
  - [Hir98] J. W. P. Hirschfeld, *Projective geometries over finite fields*, second ed., Oxford Mathematical Monographs, The Clarendon Press Oxford University Press, New York, 1998. MR 1612570 (99b:51006)
  - [HV90] Abramo Hefez and Jos´e Felipe Voloch, *Frobenius nonclassical curves*, Arch. Math. (Basel) 54 (1990), no. 3, 263–273. MR 1037617 (91e:14018)
  - [KP95] Christoph Kirfel and Ruud Pellikaan, *The minimum distance of codes in an array coming from telescopic semigroups*, IEEE Trans. Inform. Theory 41 (1995), no. 6, part 1, 1720–1732, Special issue on algebraic geometry codes. MR 1391031 (97e:94015)
  - [LN97] Rudolf Lidl and Harald Niederreiter, *Finite fields*, second ed., Encyclopedia of Mathematics and its Applications, vol. 20, Cambridge University Press, Cambridge, 1997, With a foreword by P. M. Cohn. MR MR1429394 (97i:11115)
- <span id="page-18-8"></span><span id="page-18-4"></span><span id="page-18-2"></span>[Mat09] Gretchen L. Matthews, *On Weierstrass semigroups of some triples on norm-trace curves*, Coding and cryptology, Lecture Notes in Comput. Sci., vol. 5557, Springer, Berlin, 2009, pp. 146– 156. MR 2836238 (2012k:14029)
- <span id="page-18-9"></span>[Mil64] W. H. Mills, *Polynomials with minimal value sets*, Pacific J. Math. 14 (1964), 225–241. MR MR0159813 (28 #3029)
- <span id="page-18-3"></span>[Mor91] Carlos Moreno, *Algebraic curves over finite fields*, Cambridge Tracts in Mathematics, vol. 97, Cambridge University Press, Cambridge, 1991. MR 1101140 (92d:11066)

- <span id="page-19-2"></span>[MST08] Carlos Munuera, Alonso Sep´ulveda, and Fernando Torres, *Algebraic geometry codes from castle curves*, Coding Theory and Applications (Angela Barbero, ed.), Lecture Notes in Computer ˆ Science, vol. 5228, Springer Berlin Heidelberg, 2008, pp. 117–127.
- <span id="page-19-4"></span><span id="page-19-3"></span><span id="page-19-1"></span><span id="page-19-0"></span>[MST12] C. Munuera, Alonso Sep´ulveda, and F. Torres, *Generalized hermitian codes*, Designs, Codes and Cryptography (2012), 1–8 (English).
  - [Ser83] Jean-Pierre Serre, *Sur le nombre des points rationnels d'une courbe alg´ebrique sur un corps fini*, C. R. Acad. Sci. Paris S´er. I Math. 296 (1983), no. 9, 397–402. MR 703906 (85b:14027)
  - [Ste94] Serguei A. Stepanov, *Arithmetic of algebraic curves*, Monographs in Contemporary Mathematics, Consultants Bureau, New York, 1994, Translated from the Russian by Irene Aleksanova. MR 1321599 (95j:11055)
  - [SV86] Karl-Otto St¨ohr and Jos´e Felipe Voloch, *Weierstrass points and curves over finite fields*, Proc. London Math. Soc. (3) 52 (1986), no. 1, 1–19. MR 812443 (87b:14010)