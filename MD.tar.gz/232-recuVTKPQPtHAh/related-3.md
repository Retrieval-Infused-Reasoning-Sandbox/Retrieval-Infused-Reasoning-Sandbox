|        | . , .     | $\sim$ | <b>1</b> • , |
|--------|-----------|--------|--------------|
| Commun | ncation   | Comp   | lexity       |
| Commun | iicatioii | COLLIP | 102110.9     |

23 Sept, 2011 (@ TIFR)

### 12. Hellinger distance

Lecturer: Prahladh Harsha Scribe: Girish Varma

In this lecture, we will introduce a new notion of distance between probability distributions called *Hellinger distance*. Using some of the nice properties of this distance, we will generalize the fooling set argument for deterministic protocols to the randomized setting. We will then use this to prove a  $\Omega(n)$  lower bound for the communication complexity of Disjointness. We will also see how this proof easily extends to the multi party setting, thereby proving Theorem 5.7 from Lecture 5.

#### 12.1 Hellinger Distance

Let  $P = \{p_i\}_{i \in [n]}, Q = \{q_i\}_{i \in [n]}$  be two probability distributions supported on [n]. A natural way of defining a distance between them is to consider the  $\ell_1$ -distance between the probability vectors P and Q.

<span id="page-0-0"></span>
$$||P - Q||_1 = \sum_{i \in [n]} |p_i - q_i|.$$

The total variation distance, denoted by  $\Delta(P,Q)$  (and sometimes by  $||P-Q||_{TV}$ ), is half the above quantity. It is an easy exercise to check that

$$\Delta(P,Q) = \max_{S \subseteq [n]} |P(S) - Q(S)|. \tag{12.1.1}$$

Because of the above equality, this is also referred to as the *statistical distance*.

Taking the  $\ell_1$  norm of the difference made sense because P and Q where unit vectors according to the  $\ell_1$  norm. Since  $\sqrt{P} = (\sqrt{p_1}, \sqrt{p_2}, \dots, \sqrt{p_n})$  is a unit vector according to  $\ell_2$  norm, we can also consider the  $\ell_2$  norm of the difference of the square root vectors.

**Definition 12.1** (Hellinger Distance). For probability distributions  $P = \{p_i\}_{i \in [n]}, Q = \{q_i\}_{i \in [n]}$  supported on [n], the Hellinger distance between them is defined as

$$h(P,Q) = \frac{1}{\sqrt{2}} \cdot ||\sqrt{P} - \sqrt{Q}||_2.$$

By definition, the Hellinger distance is a metric satisfying triangle inequality. The  $\sqrt{2}$  in the definition is for ensuring that  $h(P,Q) \leq 1$  for all probability distributions. It is closely related to a quantity known as Fidelity or the Bhattacharya coefficient of two probability distributions  $F(P,Q) = \sum_{i \in [n]} \sqrt{p_i q_i}$  by the relation:

$$h^2(P,Q) = 1 - F(P,Q).$$

#### 12.1.1 Properties of Hellinger distance

<span id="page-1-1"></span>Lemma 12.2 (Hellinger vs. total variation).

$$h^{2}(P,Q) \le \Delta(P,Q) \le \sqrt{h^{2}(P,Q)(2-h^{2}(P,Q))} \le \sqrt{2}h(P,Q)$$

Proof. For the first inequality,

$$h^{2}(P,Q) = \frac{1}{2} \sum_{i} |\sqrt{p_{i}} - \sqrt{q_{i}}| |\sqrt{p_{i}} - \sqrt{q_{i}}| \le \frac{1}{2} \sum_{i} |\sqrt{p_{i}} - \sqrt{q_{i}}| (\sqrt{p_{i}} + \sqrt{q_{i}})$$

$$\le \frac{1}{2} \sum_{i} |p_{i} - q_{i}| = \Delta(P,Q).$$

For the last two inequalities,

$$\Delta^{2}(P,Q) = \frac{1}{4} \left( \sum_{i \in [n]} |p_{i} - q_{i}| \right)^{2} = \frac{1}{4} \left( \sum_{i \in [n]} \left( \sqrt{p_{i}} - \sqrt{q_{i}} \right) \left( \sqrt{p_{i}} + \sqrt{q_{i}} \right) \right)^{2}$$

$$\leq \frac{1}{4} \left( \sum_{i \in [n]} \left( \sqrt{p_{i}} - \sqrt{q_{i}} \right)^{2} \right) \left( \sum_{i \in [n]} \left( \sqrt{p_{i}} + \sqrt{q_{i}} \right)^{2} \right) \qquad \text{[By Cauchy Schwarz]}$$

$$\leq \frac{1}{2} \cdot h^{2} \left( P, Q \right) \cdot \left( 2 + 2 \sum_{i \in [n]} \sqrt{p_{i}} \sqrt{q_{i}} \right)$$

$$\leq h^{2} \left( P, Q \right) \cdot \left( 2 - h^{2} \left( P, Q \right) \right) \leq \sqrt{2} h \left( P, Q \right).$$

Cut and paste property: In the fooling set argument, we saw that if inputs (x, y) and (x 0 , y<sup>0</sup> ) have the same transcript in a deterministic communication protocol, then (x 0 , y) and (x, y<sup>0</sup> ) must have the same transcript. This rectangle property can be extended to private coins randomized protocols using Hellinger distance in the follows sense: if the transcript distributions for inputs (x, y) and (x 0 , y<sup>0</sup> ) are close in Hellinger distance, then so are the transcript distributions for (x 0 , y) and (x, y<sup>0</sup> ).

<span id="page-1-0"></span>Lemma 12.3 (Cut-and-Paste). Let P be a randomized private coins protocol and Πx,y denote the (randomized) transcript on input x, y. Then,

$$h^2(\Pi_{x,y}, \Pi_{x',y'}) = h^2(\Pi_{x',y}, \Pi_{x,y'}).$$

Proof. We can think of a randomized private coin protocol working on input (x, y) as a deterministic protocol on the extended inputs ((x, RA),(y, RB)), where the additional inputs R<sup>A</sup> and R<sup>B</sup> are chosen according to the suitable private coins distribution. From the rectangle property of deterministic protocols, we have that for any fixed transcript τ , the set of extended inputs that gives rise to it form a rectangle, say Rect<sup>τ</sup> = S<sup>τ</sup> × T<sup>τ</sup> . Now, let's consider the probability that transcript τ arises for inputs x and y.

$$\begin{split} \Pr_{R_A, R_B}[\Pi(x, y, R_A, R_B) = \tau] &= \Pr_{R_A, R_B}[((x, R_A), (y, R_B)) \in \mathsf{Rect}_\tau] \\ &= \Pr_{R_A, R_B}[(x, R_A) \in S_\tau \text{ and } (y, R_B) \in T_\tau] \\ &= \Pr_{R_A}[(x, R_A) \in S_\tau] \cdot \Pr_{R_B}[(y, R_B) \in T_\tau]. \end{split}$$

This splitting of probabilities follows from the independence of Alice and Bob's private coins R<sup>A</sup> and R<sup>B</sup> and is used to proved the lemma as follows.

$$\begin{split} &1 - h^{2}(\Pi_{x,y}, \Pi_{x',y'})) = F(\Pi_{x,y}, \Pi_{x',y'}) \\ &= \sum_{\tau} \sqrt{\Pr_{R_{A},R_{B}}[\Pi_{x,y} = \tau] \cdot \Pr_{R_{A},R_{B}}[\Pi_{x',y'} = \tau]} \\ &= \sum_{\tau} \sqrt{\Pr_{R_{A}}[(x,R_{A}) \in S_{\tau}] \cdot \Pr_{R_{B}}[(y,R_{B}) \in T_{\tau}] \cdot \Pr_{R_{A}}[(x',R_{A}) \in S_{\tau}] \cdot \Pr_{R_{B}}[(y',R_{B}) \in T_{\tau}]} \\ &= \sum_{\tau} \sqrt{\Pr_{R_{A}}[(x,R_{A}) \in S_{\tau}] \cdot \Pr_{R_{B}}[(y',R_{B}) \in T_{\tau}] \cdot \Pr_{R_{A}}[(x',R_{A}) \in S_{\tau}] \cdot \Pr_{R_{B}}[(y,R_{B}) \in T_{\tau}]} \\ &= \sum_{\tau} \sqrt{\Pr_{R_{A},R_{B}}[\Pi_{x,y'} = \tau] \cdot \Pr_{R_{A},R_{B}}[\Pi_{x',y} = \tau]} \\ &= F(\Pi_{x,y'},\Pi_{x',y}) = 1 - h^{2}(\Pi_{x,y'},\Pi_{x',y}). \end{split}$$

The above cut-and-paste lemma can be extended to communication protocols for t parties.

<span id="page-2-1"></span>Lemma 12.4 (multiparty cut-and-paste). For any v ∈ {x1, y1} × {x2, y2} · · · × {x<sup>t</sup> , yt}

$$h^2(\Pi_{x_1, x_2, \dots x_t}, \Pi_{y_1, y_2, \dots y_t}) = h^2(\Pi_v, \Pi_{\overline{v}}).$$

<span id="page-2-0"></span>Lemma 12.5 (Hellinger vs. Information [\[Lin91\]](#page-7-0)). Let Z be a random variable taking values in {z1, z2} equally likely and Π a randomized function of Z. Then,

$$I[Z:\Pi(Z)] \ge h^2(\Pi_{z_1}, \Pi_{z_2}).$$

A proof of a slightly weaker theorem is presented in [Appendix A.](#page-7-1)

# 12.2 Lower bound for Disjointness

In this section, we will prove the Ω(n) lower bound for the randomized private coins communication complexity of Disjointness, using the above properties of Hellinger distance. Recall that

$$\mathsf{DISJ}(x,y) = \bigwedge_i \overline{x_i} \vee \overline{y_i} = \bigwedge_i \mathsf{NAND}(x_i,y_i).$$

Let's quickly recall the steps in the proof of the disjointness lower bound from last lecture.

Suppose there exists a  $(1/2 - \varepsilon)$ -error private coin randomized protocol  $\Pi$  for computing the Disjointness problem of length at most  $\delta n$  for some  $\delta > 0$ . Define two distribution  $\eta_A$  and  $\eta_B$  on  $\{0,1\}^2$  (in fact, on the YES instances of NAND) as follows.

$$\Pr_{(X,Y) \sim \eta_A} [(X,Y) = (1,0)] = \Pr_{(X,Y) \sim \eta_A} [(X,Y) = (0,0)] = \frac{1}{2}$$

$$\Pr_{(X,Y) \sim \eta_B} [(X,Y) = (0,1)] = \Pr_{(X,Y) \sim \eta_B} [(X,Y) = (0,0)] = \frac{1}{2}$$

For every  $\sigma \in \{A, B\}^n$ , we define joint random variables  $(X^{\sigma}, Y^{\sigma})$  with distribution  $\mu_{\sigma}$  on  $(\{0, 1\}^n)^2$  as follows: for each  $i \in [n]$  independently do the following, if  $\sigma_i = A$ , set  $(X_i^{\sigma}, Y_i^{\sigma}) \sim \eta_A$  and otherwise (i.e.,  $\sigma_i = B$ ), set  $(X_i^{\sigma}, Y_i^{\sigma}) \sim \eta_B$ . Using, sub-additivity of mutual information and independence of  $(X_i^{\sigma}, Y_i^{\sigma})$  across the different i's, we showed that

$$\delta n \geq |\Pi(X^{\sigma}, Y^{\sigma})| \geq I[X^{\sigma}, Y^{\sigma}: \Pi(X^{\sigma}, Y^{\sigma})] \geq \sum_{i} I[X_{i}^{\sigma}, Y_{i}^{\sigma}: \Pi(X^{\sigma}, Y^{\sigma})].$$

Averaging over i's and all possible  $\sigma$ 's we get,

$$\delta \ge \mathbb{E}_{\sigma} E_k I[X_k^{\sigma} Y_k^{\sigma} : \Pi(X^{\sigma}, Y^{\sigma})] = E_k E_{\sigma_{-k}} E_{\sigma_k} I[X_k^{\sigma} Y_k^{\sigma} : \Pi].$$

Hence, there exists a k and a  $\sigma_{-k}$ , such that  $\mathbb{E}_{\sigma_k}I[X_k^{\sigma}Y_k^{\sigma}:\Pi] \leq \delta$ . Expanding this expectation, we obtain

<span id="page-3-0"></span>
$$\frac{1}{2} (I_A[X_k Y_k : \Pi] + I_B[X_k Y_k : \Pi]) \le \delta, \tag{12.2.1}$$

where  $I_A[\cdot,\cdot]$  denotes the mutual information when when the k-coordinates are chosen according to  $\eta_A$  and the remaining coordinates are chosen as dictated by the  $\sigma_{-k}$  that we had fixed earlier in the proof (similarly for  $I_B[\cdot,\cdot]$ ).

This gives a protocol  $\pi$  for computing the NAND function which works as follows: On input x and y, Alice and Bob construct n bit inputs X and Y for  $\mathsf{DISJ}_n$  function from x and y respectively as follows: Alice and Bob set the k-bit of X and Y to be x and y respectively (i.e.,  $X_k = x$  and  $Y_k = y$ ). For each  $i \neq k$ ,  $\sigma_{-k}|_i$  tells if Alice or Bob is active. If Alice is active (ie.,  $\sigma_{-k}(i) = A$ ), then Alice sets  $X_i$  with equal probability to 0 or 1, while Bob sets  $Y_i$  to be 0. Similarly, if Bob is active, then Bob sets  $Y_i$  with equal probability to 0 or 1, while Alice sets  $X_i$  to be 0. Observe, that all of this can be done by Alice and Bob independently using their private randomness and the knowledge of k and  $\sigma_{-k}$ . They, then run the protocol  $\Pi$  on this input (X,Y). Since  $\mathsf{DISJ}_n(X,Y) = \mathsf{NAND}(x,y)$  and  $\Pi$  is a protocol that computes  $\mathsf{DISJ}_n$  correctly on every input with error at most  $1/2 - \varepsilon$ , we have that  $\pi$  is a protocol that computes  $\mathsf{NAND}$  correctly on every input with error at most  $1/2 - \varepsilon$ . Rewriting (12.2.1) in terms of protocol  $\pi$ , we have

<span id="page-3-1"></span>
$$I[Z:\pi_{Z,0}] + I[Z:\pi_{0,Z}] \le 2\delta,$$
 (12.2.2)

where Z is a random bit that takes 0 and 1 with equal probability.

We can now complete the lower bound using the properties of the Hellinger distance proved in the beginning of the lecture.

$$2\delta \geq I[Z:\pi_{Z,0}] + I[Z:\pi_{0,Z}] \qquad \text{[from (12.2.2)]}$$

$$\geq h^2(\pi_{0,0}, \pi_{1,0}) + h^2(\pi_{0,0}, \pi_{0,1}) \qquad \text{[from Lemma 12.5]}$$

$$\geq \frac{1}{2} \cdot (h(\pi_{0,0}, \pi_{1,0}) + h(\pi_{0,0}, \pi_{0,1}))^2 \qquad \text{[By Cauchy-Schwarz]}$$

$$\geq \frac{1}{2} \cdot h^2(\pi_{1,0}, \pi_{0,1}) \qquad \text{[triangle inequality, since } h \text{ is a metric]}$$

$$= \frac{1}{2} \cdot h^2(\pi_{0,0}, \pi_{1,1}) \qquad \text{[by Cut-and-Paste lemma 12.3]}$$

$$\geq \frac{1}{4} \cdot \Delta^2(\pi_{0,0}, \pi_{1,1}) \qquad \text{[by Lemma 12.2]}$$

$$\geq \varepsilon^2$$

The last inequality follows from the fact that NAND takes different answers on inputs (1,1) and (0,0). More precisely, if the protocol was correct with probability  $1/2 + \varepsilon$ , using Equation (12.1.1) we obtain:

$$\begin{split} \Delta(\pi_{1,1},\pi_{0,0}) &\geq |\text{Pr}\left[\text{Output of transcript } \pi_{1,1} = 0\right] - \text{Pr}\left[\text{Output of transcript } \pi_{0,0} = 0\right]| \\ &\geq \left|\left(\frac{1}{2} + \varepsilon\right) - \left(\frac{1}{2} - \varepsilon\right)\right| \\ &\geq 2\varepsilon \end{split}$$

Hence,  $\delta \geq \varepsilon^2/2$ . We have thus, proved the following theorem.

Theorem 12.6 (Disjointness lower bound [KS92, Raz92, BJKS04]).

$$R_{1/2-\varepsilon}(\mathsf{DISJ}_n) \ge \varepsilon^2 n/2.$$

# 12.3 Lower bound for Multi-party Disjointness

In this section, we will generalize the proof for disjointness to the multi-party setting. Recall the promise problem of  $\mathsf{UDISJ}_{n,t}$  from Lecture 5, given by:

YES = 
$$\{(x_1, x_2, \dots x_t) \in \{0, 1\}^{nt} \mid \forall i \neq j, x_i, x_j \text{ are pairwise disjoint }\}$$
  
NO =  $\{(x_1, x_2, \dots x_t) \in \{0, 1\}^{nt} \mid \exists a \in [n], \ \forall i \neq j, \ x_i \cap x_j = \{a\}\}$ 

Note that we are using  $x_i$  to denote subsets of [n] as well as the characteristic vectors of these subsets.

As in the last section, we will start with the observation that

$$\mathsf{UDISJ}_{n,t}(x_1,\ldots,x_t) = \bigwedge_{i=1}^n \left(\bigvee_{j=1}^t \overline{x_{j,i}}\right) = \bigwedge_{i=1}^n \mathsf{NAND}_t(x_{1,i},x_{2,u},\ldots,x_{t,i}).$$

Just as UDISJ is a promise problem, the t-wise NAND $_t$  is also a promise problem whose only NO instance is the all 1's vector  $\mathbf{1}$  and YES instances are the unit vectors  $\mathbf{e_i}$  and the all zeros vector  $\mathbf{0}$ . Here,  $\mathbf{e_i}$  represents the unit vector with 1 in the  $i^{th}$  coordinate.

We consider the number-in-hand and broadcast model and prove the following theorem.

<span id="page-5-1"></span>**Theorem 12.7** ([BJKS04]). The communication complexity of UDISJ<sub>n,t</sub> under number in hand and broadcast communication is  $\Omega(n/t^2)$ .

As in the case of DISJ, we will show that communication complexity of UDISJ<sub>n,t</sub> is at least n times the information complexity of multi-party NAND<sub>t</sub>, which we will lower bound by  $\Omega(1/t^2)$ , again using properties of Hellinger distance.

*Proof.* Suppose there exists a  $(1/2 - \varepsilon)$ -error private coin multi-party NIH randomized broadcast protocol  $\Pi$  for computing  $\mathsf{UDISJ}_{n,t}$  of total broadcast length at most  $\delta n$  for some  $\delta > 0$ . Define t distributions  $\eta_i, i \in [t]$  on  $\{0,1\}^t$  (in fact, on the YES instances of  $\mathsf{NAND}_t$ ) as follows.

$$\Pr_{(X_1,\dots,X_t)\sim\eta_i}[(X_1,X_2,\dots,X_t)=\mathbf{e_i}]=\Pr_{(X_1,\dots,X_t)\sim\eta_i}[(X_1,X_2,\dots,X_t)=\mathbf{0}]=\frac{1}{2}.$$

For every  $\sigma \in \{A_1, \ldots, A_t\}^n$ , we define joint random variables  $(X_1^{\sigma}, \ldots, X_t^{\sigma})$  with distribution  $\mu_{\sigma}$  on  $(\{0,1\}^n)^t$  as follows: for each  $i \in [n]$  independently do the following, if  $\sigma_i = A_i$ , set  $(X_{1,i}^{\sigma}, \ldots, X_{t,i}^{\sigma}) \sim \eta_i$ . Using, sub-additivity of mutual information and independence of  $(X_{1,i}^{\sigma}, \ldots, X_{t,i}^{\sigma})$  across the different i's, we infer that

$$\delta n \geq |\Pi(X_1^\sigma,\dots,X_t^\sigma)| \geq I[X_1^\sigma,\dots,X_t^\sigma:\Pi(X_1^\sigma,\dots,X_t^\sigma)] \geq \sum_i I[X_{1,i}^\sigma,\dots,X_{t,i}^\sigma:\Pi(X_1^\sigma,\dots,X_t^\sigma)].$$

Averaging over i's and all possible  $\sigma$ 's we get,

$$\delta \geq \mathbb{E}_{\sigma} E_k I[X_{1,k}^{\sigma}, \dots, X_{t,k}^{\sigma} : \Pi(X_1^{\sigma}, \dots, X_t^{\sigma})] = E_k E_{\sigma_{-k}} E_{\sigma_k} I[X_{1,k}^{\sigma}, \dots, X_{t,k}^{\sigma} : \Pi].$$

Hence, there exists a k and a  $\sigma_{-k}$ , such that

<span id="page-5-0"></span>
$$\mathbb{E}_{\sigma_k} I[X_{1,k}^{\sigma}, \dots, X_{t,k}^{\sigma} : \Pi] \le \delta. \tag{12.3.1}$$

We now give a protocol  $\pi$  for computing the multi-party NAND<sub>t</sub> function as follows: On inputs  $x_1, \ldots, x_t$ , the t parties  $A_1, \ldots, A_t$  construct n bit inputs  $X_1, \ldots, X_t$  for UDISJ<sub>n,t</sub> function from  $x_1, \ldots, x_t$  as follows: party  $A_i$  set the k-bit of  $X_i$  to be  $x_i$  (i.e.,  $X_{i,k} = x_i$ ). For each  $i \neq k, \sigma_{-k}|_i$  tells which party is active. If  $\sigma_{-k}(i) = A_j$ , then party  $A_j$  sets  $X_{j,i}$  with equal probability to 0 or 1, while all other parties  $(j' \neq j)$  sets  $X_{j',i}$  to be 0. Observe, that all of this can be done by the t parties independently using their private randomness and the knowledge of k and  $\sigma_{-k}$ . They, then run the protocol  $\Pi$  on this input  $(X_1, \ldots, X_t)$ . Since UDISJ<sub>n,t</sub> $(X_1, \ldots, X_t) = \mathsf{NAND}_t(x_1, \ldots, x_t)$  and  $\Pi$  is a protocol that computes UDISJ<sub>n,t</sub> correctly on every legal input with error at most  $1/2 - \varepsilon$ , we have that  $\pi$  is a protocol that computes  $\mathsf{NAND}_t$  correctly on every legal input with error at most  $1/2 - \varepsilon$ . Rewriting (12.3.1) in terms of protocol  $\pi$ , we have

$$\frac{1}{t} \cdot \sum_{i=1}^{t} I[Z_i : \pi_{Z_i}] \le \delta,$$

where  $Z_i$  is a random vector defined as follows:

$$Z_i = \begin{cases} \mathbf{0} & \text{with probability } \frac{1}{2} \\ \mathbf{e_i} & \text{the } i \text{th unit vector with probability } \frac{1}{2} \end{cases}$$

We can now complete the lower bound using the properties of the Hellinger distance just as in the case of the disjointness lower bound.

<span id="page-6-3"></span><span id="page-6-2"></span>
$$\delta \geq \frac{1}{t} \cdot \sum_{i=1}^{t} I[Z_i : \pi_{Z_i}]$$

$$\geq \frac{1}{t} \cdot \sum_{i=1}^{t} h^2(\pi_{\mathbf{0}}, \pi_{\mathbf{e_i}}) \qquad [from Lemma 12.5]$$

$$\geq \frac{1}{t^2} \cdot \left(\sum_{i=1}^{t} h(\pi_{\mathbf{0}}, \pi_{\mathbf{e_i}})\right)^2 \qquad [By Cauchy-Schwarz]$$

$$= \frac{1}{t^2} \cdot h^2(\pi_{\mathbf{0}}, \pi_{\mathbf{1}}) \qquad [by Claim 12.8] \qquad (12.3.2)$$

$$\geq \frac{1}{2t^2} \cdot \Delta^2(\pi_{\mathbf{0}}, \pi_{\mathbf{1}}) \qquad [by Lemma 12.2] \qquad (12.3.3)$$

$$\geq \frac{2\varepsilon^2}{t^2}$$

The only difference from the disjointness proof is Inequality [\(12.3.2\)](#page-6-2) which is proved in [Claim 12.8.](#page-6-1) This is proved by repeated application of the multi-party [Cut-and-Paste](#page-2-1) [Lemma 12.4](#page-2-1) and the triangle inequality. The last inequality [\(12.3.3\)](#page-6-3) follows from the fact that NAND<sup>t</sup> takes different answers on inputs 0 and 1 and hence ∆(π0, π1) ≥ 2ε. This completes the proof of [Theorem 12.7.](#page-5-1)

This theorem was improved by Gronemeier who proved a Ω(n/t) lower bound [\[Gro09\]](#page-7-4).

<span id="page-6-1"></span>Claim 12.8. 
$$\sum_{i=1}^{t} h(\pi_0, \pi_{e_i}) \ge h(\pi_0, \pi_1)$$
.

Proof. We will illustrate the proof for the case t = 4. The general case follows by induction.

LHS = 
$$h(\pi_{0000}, \pi_{1000}) + h(\pi_{0000}, \pi_{0100})$$
  
+  $h(\pi_{0000}, \pi_{0010}) + h(\pi_{0000}, \pi_{0001})$   
 $\geq h(\pi_{1000}, \pi_{0100}) + h(\pi_{0010}, \pi_{0001})$  [By Triangle inequality]  
=  $h(\pi_{0000}, \pi_{1100}) + h(\pi_{0000}, \pi_{0011})$  [By Cut-and-Paste Lemma 12.4]  
 $\geq h(\pi_{1100}, \pi_{0011})$  [By Triangle inequality]  
=  $h(\pi_{0000}, \pi_{1111})$  [By Cut-and-Paste Lemma 12.4]

## References

<span id="page-6-0"></span>[BJKS04] Ziv Bar-Yossef, T. S. Jayram, Ravi Kumar, and D. Sivakumar. An information statistics approach to data stream and communication complexity. J. Computer and System Sciences, 68(4):702–732, June 2004. (Preliminary Version in 43rd FOCS, 2002). [doi:10.1016/j.jcss.2003.11.006](http://dx.doi.org/10.1016/j.jcss.2003.11.006).

- <span id="page-7-4"></span>[Gro09] Andre Gronemeier. Asymptotically optimal lower bounds on the NIH-multi-party information complexity of the AND-function and disjointness. In Susanne Albers and Jean-Yves Marion, eds., Proc. 26th Annual Symposium on Theoretical Aspects of Computer Science (STACS), volume 3 of LIPIcs, pages 505–516. Schloss Dagstuhl - Leibniz-Zentrum fuer Informatik, Germany, 2009. doi:10.4230/LIPIcs.STACS.2009.1846.
- <span id="page-7-2"></span>[KS92] BALA KALYANASUNDARAM and GEORG SCHNITGER. The probabilistic communication complexity of set intersection. SIAM J. Discrete Math., 5(4):545–557, 1992. (Preliminary Version in 2nd Structure in Complexity Theory Conference, 1987). doi:10.1137/0405044.
- <span id="page-7-0"></span>[Lin91] JIANHUA LIN. Divergence measures based on the shannon entropy. IEEE Transaction on Information Theory, 37(1):145–151, jan 1991. doi:10.1109/18.61115.
- <span id="page-7-3"></span>[Raz92] ALEXANDER A. RAZBOROV. On the distributional complexity of disjointness. Theoretical Comp. Science, 106(2):385–390, 1992. doi:10.1016/0304-3975(92)90260-M.

#### <span id="page-7-1"></span>A Weaker proof of Lin's Lemma 12.5

**Lemma 12.9.** Let Z be a random variable taking values in  $\{z_1, z_2\}$  equally likely and  $\Pi$  a randomized function of Z. Then,

$$I[Z:\Pi(Z)] \ge \frac{\log_2 e}{2} \cdot h^2(\Pi_{z_1}, \Pi_{z_2}).$$

*Proof.* Since  $x \leq e^x - 1$ , we have  $\ln y \leq y - 1$ . Substituting  $y = \sqrt{\frac{p_i}{q_i}}$ , we get

$$\frac{1}{2} \cdot \ln \frac{p_i}{q_i} \le \sqrt{\frac{p_i}{q_i}} - 1.$$

Multiplying by  $q_i$  and summing over i, we obtain

$$-\frac{1}{2\log_2 e} \cdot D(Q||P) \le \left(\sum \sqrt{p_i q_i} - 1\right) = -h^2(Q, P).$$

Using the above bound on divergence, we get

$$\begin{split} I[Z:\Pi_Z] &= \mathbb{E}_{z \leftarrow Z} \left[ D(\Pi_z \| \Pi) \right] \\ &= \frac{1}{2} (D(\Pi_{z_1} \| \Pi) + D(\Pi_{z_2} \| \Pi)) \\ &\geq \log e \cdot (h^2(\Pi_{z_1}, \Pi) + h^2(\Pi_{z_2}, \Pi)) \\ &\geq \frac{\log e}{2} \cdot (h(\Pi_{z_1}, \Pi) + h(\Pi_{z_2}, \Pi))^2 & \quad \text{[By Cauchy Schwarz]} \\ &\geq \frac{\log e}{2} \cdot h^2(\Pi_{z_1}, \Pi_{z_2}) & \quad \text{[By triangle inequality]} \end{split}$$