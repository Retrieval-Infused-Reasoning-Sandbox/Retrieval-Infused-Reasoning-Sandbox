# Quantum Communication With Zero-Capacity Channels

Graeme Smith<sup>1</sup> and Jon Yard<sup>2</sup>

1 IBM TJ Watson Research Center 1101 Kitchawan Road, Yorktown Heights, NY 10598

<sup>2</sup>Quantum Institute Center for Nonlinear Studies (CNLS) Computer, Computational and Statistical Sciences (CCS-3) Los Alamos National Laboratory Los Alamos, NM 87545

Communication over a noisy quantum channel introduces errors in the transmission that must be corrected. A fundamental bound on quantum error correction is the quantum capacity, which quantifies the amount of quantum data that can be protected. We show theoretically that two quantum channels, each with a transmission capacity of zero, can have a nonzero capacity when used together. This unveils a rich structure in the theory of quantum communications, implying that the quantum capacity does not uniquely specify a channel's ability for transmitting quantum information.

Noise is the enemy of all modern communication links. Cellular, internet and satellite communications all depend crucially on active steps taken to mitigate and correct for noise. The study of communication in the presence of noise was formalized by Shannon ([1](#page-8-0) ), who simplified the analysis by making probabilistic assumptions about the nature of the noise. By modeling a noisy channel N as a probabilistic map from input signals to output signals, the capacity C(N ) of N is defined as the number of bits which can be transmitted per channel use, with vanishing errors in the limit of many transmissions. This capacity is computed via the formula C(N ) = max<sup>X</sup> I(X; Y ) where the maximization is over random variables X at the input of the channel, Y is the resulting output of the channel and the mutual information I(X; Y ) = H(X) + H(Y ) − H(X, Y ) quantifies the correlation between input and output. H(X) = − P x p<sup>x</sup> log<sup>2</sup> p<sup>x</sup> denotes the 'Shannon entropy', which quantifies the amount of randomness in X. The capacity, measured in bits per channel use, is the fundamental bound between communication rates that are achievable in principle, and those which are not. The capacity formula guides the design of practical error correction techniques by providing a benchmark against which engineers can test the performance of their systems. Practical implementations guided by the capacity result now come strikingly close to the Shannon limit ([2](#page-8-1) ).

A fundamental prediction of the capacity formula is that the only channels with zero capacity are precisely those for which the input and output are completely uncorrelated. Furthermore, suppose one is given simultaneous access to two noisy channels N<sup>1</sup> and N2. The capacity of the product channel N1×N2, where the channels are used in parallel, takes the simple form C(N<sup>1</sup> × N2) = C(N1) + C(N2), i.e., the capacity is additive. Additivity shows that capacity is an intrinsic measure of the information conveying properties of a channel.

Quantum data is an especially delicate form of information and is particularly suscepti-

ble to the deleterious effects of noise. Because quantum communication promises to allow unconditionally secure communication ([3](#page-8-2) ), and a quantum computer could dramatically speed up some computations ([4](#page-8-3) ), there is tremendous interest in techniques to protect quantum data from noise. A quantum channel N models a physical process which adds noise to a quantum system via an interaction with an unobservable environment (Fig. 1), generalizing Shannon's model and enabling a more accurate depiction of the underlying physics. In this setting, it is natural to ask for the capacity of a quantum channel for transmitting quantum mechanical information ([5](#page-8-4) ), and whether it has a simple formula in analogy with Shannon's.

Just as any classical message can be reversibly expressed as a sequence of bits, a quantum message, i.e. an arbitrary state of a given quantum system, can be reversibly transferred to a collection of two-level quantum systems, or 'qubits', giving a measure of the size of the system. The goal of quantum communication is to transfer the joint state of a collection of qubits from one location to another (Fig. 2). The quantum capacity Q(N ) of a quantum channel N is the number of qubits per channel use that can be reliably transmitted via many noisy transmissions, where each transmission is modeled by N . Although noiseless quantum communication with a noisy quantum channel is one of the simplest and most natural communication tasks one can imagine for quantum information, it is not nearly as well understood as its classical counterpart.

An analogue for mutual information in the quantum capacity has been proposed ([6](#page-8-5) ) and called the 'coherent information':

<span id="page-2-0"></span>
$$Q^{(1)}(\mathcal{N}) = \max_{\rho^A} \left( H(B) - H(E) \right). \tag{1}$$

The entropies are measured on the states induced at the output and environment of the channel (Fig. 2) by the input state ρ <sup>A</sup>, where H(B) is the 'von Neumann entropy' of the state ρ <sup>B</sup> at the output. Coherent information is rather different from mutual information. This difference is closely related to the no-cloning theorem ([7](#page-8-6) ), which states that quantum information cannot be copied, as the coherent information roughly measures how much more information B holds than E. The no-cloning theorem itself is deeply tied to the fundamentally quantum concept of entanglement, in which the whole of a quantum system can be in a definite state while the states of its parts are uncertain.

The best known expression for the quantum capacity Q is given ([8](#page-8-7) , [9](#page-8-8) , [10](#page-8-9) ) by the 'regularization' of Q(1):

$$\mathcal{Q}(\mathcal{N}) = \lim_{n \to \infty} \frac{1}{n} \mathcal{Q}^{(1)}(\mathcal{N}^{\times n}).$$

Here N <sup>×</sup><sup>n</sup> represents the parallel use of n copies of N . The asymptotic nature of this expression prevents one from determining the quantum capacity of a given channel in any effective way, while also making it difficult to reason about its general properties. In contrast to Shannon's capacity, where regularization is unnecessary, here it cannot be removed in general ([11](#page-8-10) , [12](#page-8-11) ). Consequently, even apparently simple questions, such as determining from a channel's description whether it can be used to send any quantum information, are currently unresolved. We find that the answer to this question depends on context; there are pairs of zero-capacity channels which, used together, have a positive quantum capacity (Fig. 3). This shows the quantum capacity is not additive, and thus the quantum capacity of a channel does not completely specify its capability for transmitting quantum information.

While a complete characterization of zero-capacity channels is unknown, certain classes of zero-capacity channels are known. One class consists of channels for which the joint quantum state of the output and environment is symmetric under interchange. These 'symmetric channels' are quite different from Shannon's zero-capacity channels, as they display correlations between the input and output. However, they are useless by themselves for quantum communication because their symmetry implies that any capacity would lead to a violation of the no cloning theorem (7, 13). Another class of zero-capacity channels are entanglement-binding channels (14, 15), also called 'Horodecki channels', which can only produce very weakly entangled states satisfying a condition called positive partial transposition (16).

Even though channels from one or the other of these classes cannot be combined to faithfully transmit quantum data, we find that when one combines a channel from each class, it is sometimes possible to obtain a positive quantum capacity. We do this by proving a new relationship between two further capacities of a quantum channel: the private capacity (10) and the assisted capacity (17).

The private capacity  $\mathcal{P}(\mathcal{N})$  of a quantum channel  $\mathcal{N}$  is the rate at which it can be used to send classical data that is secure against an eavesdropper with access to the environment of the channel. This capacity is closely related to quantum key distribution protocols (3) and was shown (10) to equal the regularization of the 'private information':

<span id="page-4-0"></span>
$$\mathcal{P}^{(1)}(\mathcal{N}) = \max_{X, \rho_x^A} (I(X; B) - I(X; E)), \qquad (2)$$

where the maximization is over classical random variables X and quantum states  $\rho_x^A$  on the input of  $\mathcal{N}$  depending on the value x of X.

In order to find upper bounds on the quantum capacity, an 'assisted capacity' was recently introduced (17) where one allows the free use of arbitrary symmetric channels to assist quantum communication over a given channel. Letting  $\mathcal{A}$  denote a symmetric channel of unbounded dimension (the strongest such channel), the assisted capacity  $\mathcal{Q}_{\mathcal{A}}(\mathcal{N})$  of a quantum channel  $\mathcal{N}$  satisfies (17)

$$\mathcal{Q}_{\mathcal{A}}(\mathcal{N}) = \mathcal{Q}(\mathcal{N} \times \mathcal{A}) = \mathcal{Q}^{(1)}(\mathcal{N} \times \mathcal{A}).$$

Because the dimension of the input to A is unbounded, we cannot evaluate the assisted

capacity in general. Nonetheless, the assisted capacity helps to reason about finitedimensional channels.

While Horodecki channels have zero quantum capacity, examples of such channels with nonzero private capacity are known ([18](#page-9-3) , [19](#page-9-4) ). One of the two zero-capacity channels we will combine to give positive joint capacity is such a 'private Horodecki channel' NH, and the other is the symmetric channel A. Our key tool is the following new relationship between the capacities of any channel N (Fig. 4):

<span id="page-5-0"></span>
$$\frac{1}{2}\mathcal{P}(\mathcal{N}) \le \mathcal{Q}_{\mathcal{A}}(\mathcal{N}). \tag{3}$$

A channel's assisted capacity is at least as large as half its private capacity. It follows that any private Horodecki channel N<sup>H</sup> has a positive assisted capacity, and thus the two zero-capacity channels N<sup>H</sup> and A satisfy

$$Q_{\mathcal{A}}(\mathcal{N}_H) = \mathcal{Q}(\mathcal{N}_H \times \mathcal{A}) > 0.$$

Although our construction involves systems of unbounded dimension, one can show that any private Horodecki channel can be combined with a finite symmetric channel to give positive quantum capacity. In particular, there is a private Horodecki channel acting on a four-level system ([19](#page-9-4) ). This channel gives positive quantum capacity when combined with a small symmetric channel – a 50% erasure channel A<sup>e</sup> with a four-level input which half of the time delivers the input state to the output, otherwise telling the receiver that an erasure has occurred. We show ([20](#page-9-5) ) that the parallel combination of these channels has a quantum capacity greater than 0.01.

We find this 'superactivation' to be a startling effect. One would think that the question, "can this communication link transmit any information?" would have a straightforward answer. However, with quantum data, the answer may well be "it depends on the context". Taken separately, private Horodecki channels and symmetric channels are useless for transmitting quantum information, albeit for entirely different reasons. Nonetheless, each channel has the potential to "activate" the other, effectively canceling the other's reason for having zero capacity. We know of no analogue of this effect in the classical theory. Perhaps each channel transfers some different, but complementary kind of quantum information. If so, can these kinds of information be quantified in an operationally meaningful way? Are there other pairs of zero-capacity channels displaying this effect? Are there triples? Does the private capacity also display superactivation? Can all Horodecki channels be superactivated, or just those with positive private capacity? What new insights does this yield for computing the quantum capacity in general?

Besides additivity, our findings resolve two open questions about the quantum capacity. First we find ([20](#page-9-5) ) that the quantum capacity is not a convex function of the channel. Convexity of a capacity means that a probabilistic mixture of two channels never has a higher capacity than the corresponding average of the capacities of the individual channels. Violation of convexity leads to a counterintuitive situation where it can be beneficial to forget which channel is being used. We also find ([20](#page-9-5) ) channels with an arbitrarily large gap between Q(1) – the so-called 'hashing rate' ([8](#page-8-7) , [9](#page-8-8) [, 10](#page-8-9) ) – and the quantum capacity. It had been consistent with previous results ([11](#page-8-10) , [12](#page-8-11) ) to believe that Q and Q(1) would be equal up to small corrections. Our work shows this is not the case and indicates that the hashing rate is an overly pessimistic benchmark against which to measure the performance of practical error-correction schemes. This could be good news for the analysis of fault tolerant quantum computation in the very noisy regime.

Forms of this sort of superactivation are known in the multiparty setting, where several separated parties communicate via a quantum channel with multiple inputs or outputs ([21](#page-9-6) , [22](#page-9-7) , [23](#page-9-8) , [24](#page-9-9) ), and have been conjectured for a quantum channel assisted by classical communication between the sender and receiver ([25](#page-9-10) , [26](#page-9-11) ). Because these settings are rather complex, it is perhaps unsurprising to find exotic behavior. In contrast, the problem of noiseless quantum communication with a noisy quantum channel is one of the simplest and most natural communication tasks imaginable in a quantum mechanical context. Our findings uncover a level of complexity in this simple problem that had not been anticipated and point towards several fundamentally new questions about information and communication in the physical world.

# <span id="page-8-0"></span>References and Notes

- 1. C. E. Shannon, Bell Syst. Tech. J. 27, 379 (1948).
- <span id="page-8-2"></span><span id="page-8-1"></span>2. T. Richardson, R. Urbanke, IEEE Communications Magazine 41, 126 (2003).
- 3. C. H. Bennett, G. Brassard, Proceedings of the IEEE International Conference on Computers, Systems and Signal Processing p. 175 (1984).
- <span id="page-8-3"></span>4. P. W. Shor, Proceedings of the 35th Annual Symposium on Foundations of Computer Science (1994), pp. 124–134.
- <span id="page-8-5"></span><span id="page-8-4"></span>5. C. H. Bennett, P. W. Shor, Science 303, 1784 (2004).
- 6. B. Schumacher, M. A. Nielsen, Phys. Rev. A 54, 2629 (1996).
- <span id="page-8-6"></span>7. W. Wootters, W. Zurek, Nature 299, 802 (1982).
- <span id="page-8-8"></span><span id="page-8-7"></span>8. S. Lloyd, Phys. Rev. A 55, 1613 (1997).
- 9. P. W. Shor, Quantum error correction. Lecture notes, MSRI Workshop on Quantum Computation, 2002. Available online at <http://www.msri.org/publications/ln/msri/2002/quantumcrypto/shor/1/>.
- <span id="page-8-10"></span><span id="page-8-9"></span>10. I. Devetak, IEEE Trans. Inform. Theory 51, 44 (2005).
- 11. D. DiVincenzo, P. W. Shor, J. A. Smolin, Phys. Rev. A 57, 830 (1998).
- <span id="page-8-11"></span>12. G. Smith, J. A. Smolin, Phys. Rev. Lett. 98, 030501 (2007).
- <span id="page-8-12"></span>13. C. H. Bennett, D. P. DiVincenzo, J. A. Smolin, Phys. Rev. Lett. 78, 3217 (1997).
- <span id="page-8-13"></span>14. M. Horodecki, P. Horodecki, R. Horodecki, Phys. Lett. A 223, 1 (1996).

- <span id="page-9-1"></span><span id="page-9-0"></span>15. P. Horodecki, Phys. Lett. A 232, 333 (1997).
- 16. A. Peres, Phys. Rev. Lett. 77, 1413 (1996).
- <span id="page-9-2"></span>17. G. Smith, J. Smolin, A. Winter, The quantum capacity with symmetric side channels. arXiv[:quant-ph/0607039](http://arxiv.org/abs/quant-ph/0607039).
- <span id="page-9-3"></span>18. K. Horodecki, M. Horodecki, P. Horodecki, J. Oppenheim, Phys. Rev. Lett. 94, 160502 (2005).
- <span id="page-9-4"></span>19. K. Horodecki, L. Pankowski, M. Horodecki, P. Horodecki, IEEE Trans. Inform. Theory 54, 2621 (2008).
- <span id="page-9-6"></span><span id="page-9-5"></span>20. Further details can be found in Supporting Online Material.
- <span id="page-9-7"></span>21. P. Shor, J. Smolin, A. Thapliyal, Phys. Rev. Lett. 90, 107901 (2003).
- <span id="page-9-8"></span>22. W. Dur, J. Cirac, P. Horodecki, Phys. Rev. Lett. 93, 020503 (2004).
- 23. R. Duan, Y. Shi, Phys. Rev. Lett. 101 (2008).
- <span id="page-9-9"></span>24. L. Czekaj, P. Horodecki, Nonadditivity effects in classical capacities of quantum multiple-access channels. arXiv:0807.3977.
- <span id="page-9-11"></span><span id="page-9-10"></span>25. P. Horodecki, M. Horodecki, R. Horodecki, Phys. Rev. Lett. 82, 1056 (1999).
- 26. P. Shor, J. Smolin, B. Terhal, Phys. Rev. Lett. 86, 2681 (2001).
- 27. We are indebted to Charlie Bennett, Clifton Callaway, Eddy Timmermans, Ben Toner and Andreas Winter for encouragement and comments on an earlier draft. JY is supported by the Center for Nonlinear Studies (CNLS) and the Quantum Institute through grants provided by the LDRD program of the U.S. Department of Energy.

![](_page_10_Picture_0.jpeg)

Figure 1: Representation of a quantum channel. A channel reversibly transfers the state of a physical system in the laboratory of the sender to the combination of the system possessed by the receiver and an 'environment' which is inaccessible to the users of the channel. Discarding the environment results in a noisy evolution of the state. The input and output denote separate places in space and or time, modeling for example a leaky optical fiber or the irreversible evolution of the state of a quantum dot.

![](_page_11_Figure_0.jpeg)

Figure 2: The quantum capacity of a quantum channel. Quantum data is held by a sender (traditionally called Alice), who would like to transmit it to a reciever (Bob) with many parallel uses of a noisy quantum channel N . Alice encodes the data with a collective encoding operation E which results in a joint quantum state on the inputs of the channels N <sup>×</sup><sup>n</sup> . The encoded state is sent through the noisy channels. When Bob receives the state, he applies a decoding operation D which acts collectively on the many outputs of the channels. After decoding, Bob holds the state which Alice wished to send. The quantum capacity is the total number of qubits in the state Alice sends divided by the number of channel uses.

![](_page_12_Figure_0.jpeg)

Figure 3: (A) Alice and Bob attempt to separately use two zero-capacity channels N<sup>1</sup> and N<sup>2</sup> to transfer quantum states. Alice uses separate encoders E<sup>1</sup> and E<sup>2</sup> for each group of channels and Bob uses separate decoders D<sup>1</sup> and D2. Any attempt will fail because the capacity of each channel is zero. (B) The same two channels being used in parallel for the same task. Alice's encoder E now has simultaneous access to the inputs of all channels being used and Bob's decoding D is also performed jointly. Noiseless communication is nonetheless possible because Q is not additive.

![](_page_13_Figure_0.jpeg)

Figure 4: Relating the private capacity and the assisted capacity. A straightforward proof of Eq. 3 uses the expression (17)  $\mathcal{Q}_{\mathcal{A}}(\mathcal{N}) = \frac{1}{2} \max_{\rho^{XAC}} (I(X;B|C) - I(X;E|C))$ . Here, I(X;B|C) is the 'conditional mutual information': H(XC) + H(BC) - H(XBC) - H(C). It is evaluated on the state obtained by putting the A part of a state  $\rho^{XAC}$  into the channel  $\mathcal{N}$ , which can be thought of as mapping  $A \to BE$  as in Fig. 2. The maximization here is similar in form to Eq. 2, but is over a less constrained type of state. Therefore,  $\frac{1}{2}\mathcal{P}^{(1)}(\mathcal{N}) \leq \mathcal{Q}_{\mathcal{A}}(\mathcal{N})$ . This bound holds for the associated regularized quantities and since regularization does not change  $\mathcal{Q}_{\mathcal{A}}$ , Eq. 3 follows.

# Quantum Communication with Zero-Capacity Channels

(Supporting Online Material)

### Graeme Smith and Jon Yard

In this supporting material, we assume a basic knowledge of quantum information theory at the level of ([1](#page-20-0) ). We denote the dimension of a Hilbert space A as |A| while abbreviating tensor products as AB = A⊗B and the restriction of a density matrix ρ AB to the subsystem A as ρ <sup>A</sup>. By an ensemble of states {px, ρ<sup>A</sup> <sup>x</sup> }, we mean that the density matrix ρ A x on A occurs with probability px. We freely associate such ensembles with the joint state P x px|xihx| <sup>X</sup> ⊗ρ A x , where {|xi <sup>X</sup>} denotes an orthonormal basis for X. For a channel with input A, output B and environment E, we abbreviate Ic(N , ρ<sup>A</sup>) = H(B) − H(E) so that Q(1)(N ) = maxρ<sup>A</sup> Ic(N , ρ<sup>A</sup>).

#### Superactivation with finite dimensional channels

Our key tool in this work was the relationship <sup>1</sup> <sup>2</sup>P(N ) ≤ Q(N ⊗ A) = QA(N ), which is valid for any quantum channel N . A disadvantage of this result is that the input and output systems of the channel A are infinite. Guided by that result, we now give a weaker, more manageable bound in which a 50%-erasure channel A<sup>e</sup> with finite-dimensional input and output systems plays the role of A.

Consider a channel N with input A, output B and environment E. By Eq. [2](#page-4-0) in the main text, observe that every ensemble {px, ρ<sup>A</sup> <sup>x</sup> } yields the lower bound

$$I(X; B) - I(X; E) \le \mathcal{P}^{(1)}(\mathcal{N})$$

where the mutual informations are evaluated on the state

$$\rho^{XBE} = \sum_{x} p_x |x\rangle\langle x|^X \otimes \rho_x^{BE}$$

and ρ BE x is the joint state of the output and environment when ρ A x is sent through the channel. Furthermore, if the input to N is finite, this bound is achievable using a finite ensemble ([2](#page-20-1) ).

Currently, every known private Horodecki channel N<sup>H</sup> also satisfies P (1)(NH) > 0. Therefore, for such a channel, there is a finite ensemble for which I(X; B) − I(X; E) > 0. With this in mind, we will demonstrate the following:

Theorem: Given an ensemble {px, ρ<sup>A</sup> <sup>x</sup> } and a channel N with input A, output B and environment E, let A<sup>e</sup> be a 50%-erasure channel with input space C of dimension equal to the sum of the ranks of the states ρ A x . Then there is a state ρ AC such that

$$I_c(\mathcal{N} \otimes \mathcal{A}_e, \rho^{AC}) = \frac{1}{2} (I(X, B) - I(X; E)).$$

The next section describes a private Horodecki channel ([3](#page-20-2) ) N (4) <sup>H</sup> with a four-dimensional input and an ensemble with two rank-two states such that I(X; B) − I(X; E) > 0.02. Therefore, there is an erasure channel A (4) <sup>e</sup> with a four-dimensional input C and a state ρ AC such that Q(N<sup>H</sup> ⊗ Ae) ≥ Ic(N ⊗ Ae, ρAC) > 0.01.

Our strategy of proof is as follows. When the states in the ensemble are pure, i.e. ρ A <sup>x</sup> = |ρxihρx| <sup>A</sup>, we have the identity ([2](#page-20-1) )

$$I_c(\mathcal{N}, \rho^A) = I(X; B) - I(X; E)$$

where ρ <sup>A</sup> = P x px|ρxihρx|. Consequently, the coherent information is obtained by restricting the maximization for the private information to pure state ensembles. Since we begin with a mixed state ensemble, we consider a related ensemble of purified states and send the purifying system through a 50%-erasure channel.

Proof of Theorem: Define purifications |ρxi AC of the states ρ A x such that the supports of the ρ C x are disjoint. Then the pure state

$$|\rho\rangle^{XAC} = \sum_{x} \sqrt{p_x} |x\rangle^X |\rho_x\rangle^{AC}$$

is a purification of the state P x px|xihx| <sup>X</sup> ⊗ ρ A x associated to the ensemble. We will evaluate the coherent information resulting from sending A through N and C through Ae. Denoting the output of A<sup>e</sup> by D and the environment of A<sup>e</sup> by F, we obtain the following chain of inequalities:

$$I_c(\mathcal{N} \otimes \mathcal{A}_e, \rho^{AC}) = H(BD) - H(EF)$$
 (S1)

$$= \frac{1}{2} (H(B) - H(EC)) + \frac{1}{2} (H(BC) - H(E))$$
 (S2)

$$= \frac{1}{2} (H(B) - H(XB)) + \frac{1}{2} (H(XE) - H(E))$$
 (S3)

$$= \frac{1}{2} (I(X;B) - I(X;E)).$$
 (S4)

In Eq. [S1,](#page-2-0) the entropies are evaluated on the state obtained by sending the AC parts of |ρi XAC through the respective channels. Eq. [S2](#page-2-0) holds because with equal probability, N<sup>e</sup> either delivers C to its output D or to its environment F, so this difference of entropies can be rewritten in terms of quantities evaluated on the state on XBEC obtained by sending only the A part of |ρi XAC through N . Eq. [S3](#page-2-0) is true because bipartitions of any pure state have the same entropy and Eq. [S4](#page-2-0) uses the definition of mutual information after adding H(X) to the first term and subtracting it from the second. ut

#### A four-dimensional private Horodecki channel

For convenience we give an explicit description of the four-dimensional private Horodecki channel N (4) <sup>H</sup> from ([3](#page-20-2) ). The action of any channel N can be written in Kraus form as

$$\mathcal{N}(\rho) = \sum_{k} N_k \rho N_k^{\dagger},$$

where the Kraus matrices N<sup>k</sup> satisfy P <sup>k</sup> N † <sup>k</sup>N<sup>k</sup> = I. We denote the input of N (4) <sup>H</sup> as a tensor product of two qubits A = A1A<sup>2</sup> and denote the output as B. This channel is specified by the following six Kraus matrices:

$$\sqrt{\frac{q}{2}}I\otimes |0\rangle\langle 0|, \sqrt{\frac{q}{2}}Z\otimes |1\rangle\langle 1|, \sqrt{\frac{q}{4}}Z\otimes Y, \sqrt{\frac{q}{4}}I\otimes X, \sqrt{1-q}X\otimes M_0, \sqrt{1-q}Y\otimes M_1.$$

Here, q = 2 1+<sup>√</sup> 2 , while X,Y and Z are the usual Pauli matrices and

$$M_0 = \begin{pmatrix} \frac{1}{2}\sqrt{2+\sqrt{2}} & 0\\ 0 & \frac{1}{2}\sqrt{2-\sqrt{2}} \end{pmatrix}, \quad M_1 = \begin{pmatrix} \frac{1}{2}\sqrt{2-\sqrt{2}} & 0\\ 0 & \frac{1}{2}\sqrt{2+\sqrt{2}} \end{pmatrix}.$$

A lower bound of 0.02 on the private capacity P(N (4) <sup>H</sup> ) is obtained via the ensemble consisting of two equiprobable states ρ A <sup>x</sup> = |xihx| <sup>A</sup>1⊗ 2 I <sup>A</sup><sup>2</sup> because the state ρ XBE resulting from putting A into the channel N (4) <sup>H</sup> satisfies ([3](#page-20-2) )

$$I(X; B) - I(X; E) \ge 1 - q \log_2 q - (1 - q) \log_2 (1 - q) > 0.02.$$

#### Nonconvexity of quantum capacity

We now use the results of the first section to show that Q is not convex. Fix a private Horodecki channel N<sup>H</sup> and a 50%-erasure channel A<sup>e</sup> such that the input A to N<sup>H</sup> and the input C to A<sup>e</sup> have the same dimension, and such that there is a state ρ AC which is symmetric under interchanging A and C satisfying Ic(N<sup>H</sup> ⊗ Ae, ρAC) > 0. In particular, the channel N (4) <sup>H</sup> from the previous section and a four-dimensional erasure channel A (4) e satisfy these criteria with respect to the state

$$\rho^{AC} = \frac{1}{2} (|0\rangle\langle 0|^{A_1} \otimes |0\rangle\langle 0|^{C_1} + |1\rangle\langle 1|^{A_1} \otimes |1\rangle\langle 1|^{C_1}) \otimes |\phi_+\rangle\langle \phi_+|^{A_2C_2}$$

where |φ+i = <sup>√</sup> 1 2 (|00i + |11i), A = A1A<sup>2</sup> and C = C1C2. Identifying A ' C, we define the channel

$$\mathcal{M}_p = p\mathcal{N}_H \otimes |0\rangle\langle 0| + (1-p)\mathcal{A}_e \otimes |1\rangle\langle 1|$$

where 0 ≤ p ≤ 1. With probability p, this channel applies N<sup>H</sup> to the input and otherwise applies Ae, while telling the receiver which channel was applied. Although M<sup>p</sup> is a convex combination of the zero-capacity channels N<sup>H</sup> ⊗ |0ih0| and A<sup>e</sup> ⊗ |1ih1|, we will show that for small enough values of p, their convex combination M<sup>p</sup> has a positive capacity. On any input state ρ, we have

$$I_c(\mathcal{M}_p \otimes \mathcal{M}_p, \rho) = p^2 I_c(\mathcal{N}_H \otimes \mathcal{N}_H, \rho) + p(1-p) I_c(\mathcal{N}_H \otimes \mathcal{A}_e, \rho)$$
$$+ p(1-p) I_c(\mathcal{A}_e \otimes \mathcal{N}_H, \rho) + (1-p)^2 I_c(\mathcal{A}_e \otimes \mathcal{A}_e, \rho).$$

Since A<sup>e</sup> ⊗ A<sup>e</sup> is a symmetric channel, the last term is always zero. Choosing the state ρ = ρ AC, which was assumed to be symmetric, we find that

$$I_c(\mathcal{M}_p \otimes \mathcal{M}_p, \rho^{AC}) = 2p(1-p)I_c(\mathcal{N}_H \otimes \mathcal{A}_e, \rho^{AC}) + p^2I_c(\mathcal{N}_H \otimes \mathcal{N}_H, \rho^{AC}).$$

For 0 < p < 1, the first term is positive by assumption. The second term can never be greater than zero because Q(NH) = 0, although it is lower bounded by −2p 2 c, where c = log<sup>2</sup> |E|. Here c is finite because |E| is finite when the input and output of N<sup>H</sup> have finite dimension. Simple algebra reveals that Ic(M<sup>p</sup> ⊗ Mp, ρAC) > 0 for all p satisfying

$$0$$

For the four-dimensional example of the previous section, one has c = log<sup>2</sup> 6 so the corresponding convex combination has a positive capacity if 0 < p < 0.0041. Stronger violations are expected to be found in larger examples.

### Arbitrarily large gap between Q(1) and Q

Although it has long been known that Q can be strictly greater than Q(1), there has been speculation that deviations of Q from Q(1) may be fairly small. Thus, while the regularized nature of the capacity expression is unwieldy, we might hope that for practical purposes the quantum capacity is well approximated by Q(1) and analysis could proceed by considering the computable function Q(1). Our work shows that this is not true, as there exist channels M with Q(1)(M) = 0 for which the actual capacity can be arbitrarily large. Let N<sup>H</sup> be a private Horodecki channel and let A<sup>e</sup> be a 50%-erasure channel with the same input dimension for which Q(1)(N<sup>H</sup> ⊗Ae) > 0. For example, the four-dimensional channels discussed above would work. Define M to be a channel with input A = A1A2, where A<sup>1</sup> is a qubit and A<sup>2</sup> is the input space of N<sup>H</sup> and Ae. The channel measures the first qubit A<sup>1</sup> in the {|0i, |1i} basis and, depending on the outcome, applies one of the channels N<sup>H</sup> or A<sup>e</sup> to A2. The outcome of the measurement is revealed to the receiver. This channel can be seen to have Q(1)(M) = 0 because Q(1)(NH) = Q(1)(Ae) = 0. However, the sender has control over which channel is applied to which input, so Q(1)(M ⊗M) ≥ Q(1)(N<sup>H</sup> ⊗ Ae) > 0. By replacing N<sup>H</sup> in the above discussion with n instances of NH, and similarly for Ae, this violation can be made arbitrarily large.

# References and Notes

- <span id="page-20-0"></span>1. M. Nielsen, I. Chuang, Quantum Information and Computation (Cambridge University Press, 2000).
- <span id="page-20-2"></span><span id="page-20-1"></span>2. I. Devetak, IEEE Trans. Inform. Theory 51, 44 (2005).
- 3. K. Horodecki, L. Pankowski, M. Horodecki, P. Horodecki, IEEE Trans. Info. Theory 54, 2621 (2008).