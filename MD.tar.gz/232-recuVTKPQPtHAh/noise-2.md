# The Shannon Capacity of a union

Noga Alon <sup>∗</sup>

To the memory of Paul Erd˝os

#### Abstract

For an undirected graph G = (V, E), let G<sup>n</sup> denote the graph whose vertex set is V <sup>n</sup> in which two distinct vertices (u1, u2, . . . , un) and (v1, v2, . . . , vn) are adjacent iff for all i between 1 and n either u<sup>i</sup> = v<sup>i</sup> or uiv<sup>i</sup> ∈ E. The Shannon capacity c(G) of G is the limit limn→∞(α(G<sup>n</sup>))<sup>1</sup>/n, where α(G<sup>n</sup>) is the maximum size of an independent set of vertices in G<sup>n</sup>. We show that there are graphs G and H such that the Shannon capacity of their disjoint union is (much) bigger than the sum of their capacities. This disproves a conjecture of Shannon raised in 1956.

## 1 Introduction

For an undirected graph G = (V, E), let G<sup>n</sup> denote the graph whose vertex set is V n in which two distinct vertices (u1, u2, . . . , un) and (v1, v2, . . . , vn) are adjacent iff for all i between 1 and n either u<sup>i</sup> = v<sup>i</sup> or uiv<sup>i</sup> ∈ E. The Shannon capacity c(G) of G is the limit limn→∞(α(G<sup>n</sup> ))1/n, where α(G<sup>n</sup> ) is the maximum size of an independent set of vertices in G<sup>n</sup> . This limit exists, by super-multiplicativity, and it is always at least α(G). (It is worth noting that it is sometimes customary to call log c(G) the Shannon capacity of G, but we prefer to use here the above definition, following Lov´asz [12].)

The study of this parameter was introduced by Shannon in [14], motivated by a question in Information Theory. Indeed, if V is the set of all possible letters a channel can transmit in one use, and two letters are adjacent if they may be confused, then α(G<sup>n</sup> ) is the maximum number of messages that can be transmitted in n uses of the channel with no danger of confusion. Thus c(G) represents the number of distinct messages per use the channel can communicate with no error while used many times.

The (disjoint) union of two graphs G and H, denoted G + H, is the graph whose vertex set is the disjoint union of the vertex sets of G and of H and whose edge set is the (disjoint) union of the

<sup>∗</sup>Department of Mathematics, Raymond and Beverly Sackler Faculty of Exact Sciences, Tel Aviv University, Tel Aviv, Israel. Part of this work was done at DIMACS and at the Institute for Advanced Study, Princeton, NJ 08540, USA. Research supported in part by a grant from the the Israel Science Foundation, by a State of New Jersey grant and by the Hermann Minkowski Minerva Center for Geometry at Tel Aviv University. Email: noga@math.tau.ac.il. AMS Subject Classification: 05C35,05D10,94C15.

edge sets of G and H. If G and H are graphs of two channels, then their union represents the *sum* of the channels corresponding to the situation where either one of the two channels may be used, a new choice being made for each transmitted letter.

Shannon [14] proved that for every G and H,  $c(G+H) \ge c(G) + c(H)$  and that equality holds if the vertex set of one of the graphs, say G, can be covered by  $\alpha(G)$  cliques. He conjectured that in fact equality always holds. In this paper we prove that this is false in the following strong sense.

**Theorem 1.1** For every k there is a graph G so that the Shannon capacity of the graph and that of its complement  $\overline{G}$  satisfy  $c(G) \leq k$ ,  $c(\overline{G}) \leq k$ , whereas  $c(G + \overline{G}) \geq k^{(1+o(1))\frac{\log k}{8\log\log k}}$  and the o(1)-term tends to zero as k tends to infinity.

The proof, (which contains an explicit description of G) is based on some of the ideas of Frankl and Wilson [6], the basic approach of [1] (see also [4] for a similar technique), and one of the ideas in [3] (see also [2]).

A simpler, small counterexample to the conjecture of Shannon can be given using similar ideas together with a construction of Haemers [8], [9]. This gives the following.

**Theorem 1.2** There exists a graph G on 27 vertices so that  $c(G) \le 7$ ,  $c(\overline{G}) = 3$ , whereas  $c(G + \overline{G}) \ge 2\sqrt{27}$  ( > 10).

As a byproduct of our proof of Theorem 1.1 we obtain, for every fixed integer  $g \ge 2$ , and for every integer  $k > k_0(g)$ , an explicit edge coloring of a complete graph on  $k^{\Omega((\log k/\log \log k)^{g-1})}$  vertices with g colors, containing no monochromatic complete subgraph on k vertices. This extends the construction of [6] which provides such a coloring for g = 2.

# 2 Bounding the capacity

The following simple proposition supplies a lower bound for the Shannon capacity of the union of any graph with its complement.

**Theorem 2.1** Let G=(V,E) be a graph on |V|=m vertices, and let  $\overline{G}$  denote its complement. Then  $c(G+\overline{G})\geq 2\sqrt{m}$ .

**Proof.** Denote the set of vertices of  $G + \overline{G}$  by  $A \cup B$  where  $A = \{a_1, a_2, \ldots, a_m\}$  and  $B = \{b_1, b_2, \ldots, b_m\}$  are the vertex sets of the copy of G and of that of  $\overline{G}$ , respectively, and where  $a_i a_j$  is an edge iff  $b_i b_j$  is not an edge. Thus there are no edges of the form  $a_i b_j$ . Let n be a positive integer, and let S denote the set of all vectors  $\mathbf{v} = (v_1, v_2, \ldots, v_{2n})$  of length 2n of  $G + \overline{G}$  satisfying the following two properties:

- 1.  $|\{i: v_i \in A\}| = |\{j: v_j \in B\}| = n$ .
- 2. For each index i,  $1 \le i \le n$ , if in v,  $a_r$  is the i-th coordinate from the left that belongs to A, and  $b_s$  is the i-th coordinate from the left that belongs to B, then r = s.

Obviously, |S| = 2n n m<sup>n</sup> , since there are 2n n ways to choose the location of the coordinates of A in v, and once these are chosen there are m<sup>n</sup> ways to choose the actual coordinates, thus determining the coordinates of B as well. In addition, S is an independent set in G<sup>n</sup> . Indeed, if v and u = (u1, u2, . . . , u2n) are two distinct members of S, then if there is a coordinate t such that u<sup>t</sup> ∈ A and v<sup>t</sup> ∈ B (or vice versa), then clearly u and v are not adjacent in (G+G) n . Otherwise, there must be r and s between 1 and 2n and two distinct indices 1 ≤ i, j ≤ n such that u<sup>r</sup> = a<sup>i</sup> , u<sup>s</sup> = b<sup>i</sup> and v<sup>r</sup> = a<sup>j</sup> , v<sup>s</sup> = b<sup>j</sup> . Since a<sup>i</sup> and a<sup>j</sup> are adjacent iff b<sup>i</sup> and b<sup>j</sup> are not, it follows that in this case as well u and v are not adjacent. Therefore for every n, α((G + G) 2n ) ≥ |S| = 2n n m<sup>n</sup> , implying that

$$c((G + \overline{G}) \ge \lim_{n \to \infty} \left[ \binom{2n}{n} m^n \right]^{1/(2n)} = 2\sqrt{m}.$$

✷

Remark: It is worth noting that trivially, the set {(a<sup>i</sup> , bi) : 1 ≤ i ≤ m} ∪ {(b<sup>i</sup> , ai) : 1 ≤ i ≤ m}, is an independent set of vertices in the square of G + G, showing that c((G + G) ≥ √ 2m. Although this suffices for the lower bound in the proof of our main result, we prefer to include the proof of the stronger result. The stronger assertion is tight for any vertex transitive, self-complementary graph, as follows from the result of Lov´asz [12] that for each such graph on <sup>m</sup> vertices, <sup>c</sup>(G) = <sup>√</sup> m.

We next describe an upper bound for the Shannon capacity of any graph. This bound is strongly related to the one described by Haemers in [8], but for our propose here it is more convenient to formulate it using polynomials rather than matrices as in [8]. For two graphs G = (V, E) and H = (U, T), the product G · H is the graph whose vertex set is the Cartesian product V × U in which two distinct vertices (v, u) and (v 0 , u0 ) are adjacent iff v, v<sup>0</sup> are either equal or adjacent in G and u, u<sup>0</sup> are either equal or adjacent in H. Note that this product is associative and G<sup>n</sup> is simply the product of n copies of G.

Let G = (V, E) be a graph and let F be a subspace of the space of polynomials in r variables over a field F. A representation of G over F is an assignment of a polynomial f<sup>v</sup> in F to each vertex v ∈ V and an assignment of a point c<sup>v</sup> ∈ F r to each v ∈ V such that the following two conditions hold:

- 1. For each v ∈ V , fv(cv) 6= 0.
- 2. If u and v are distinct nonadjacent vertices of G then fv(cu) = 0.

Lemma 2.2 Let G = (V, E) be a graph and let F be a subspace of the space of polynomials in r variables over a field F. If G has a representation over F then α(G) ≤ dim(F).

Proof. Let {fv(x1, . . . , xr) : v ∈ V } and {c<sup>v</sup> : v ∈ V } be the representation, and let S be an independent set of vertices of G. We claim that the polynomials {f<sup>v</sup> : v ∈ S} are linearly independent in F. Here is the short, standard argument: if P <sup>v</sup>∈<sup>S</sup> βvfv(x1, . . . , xr) = 0 then, if u ∈ S, by substituting (x1, . . . , xr) = c<sup>u</sup> we conclude that β<sup>u</sup> = 0. Therefore |S| ≤ dim(F), completing the proof. ✷

The tensor product  $\mathcal{F} \otimes \mathcal{H}$  of two spaces of polynomials  $\mathcal{F}$  and  $\mathcal{H}$  over the same field, is the space spanned by all polynomials  $f(x_1, \ldots, x_r) \cdot h(y_1, \ldots, y_s)$  where  $f \in \mathcal{F}$ ,  $h \in \mathcal{H}$ .

**Lemma 2.3** Let G = (V, E) and H = (U, T) be two graphs. Suppose G has a representation  $\{f_v(x_1, \ldots, x_r), c_v : v \in V\}$  over  $\mathcal{F}$  and H has a representation  $\{h_u(y_1, \ldots, y_s), d_u : u \in U\}$  over  $\mathcal{H}$ , where  $\mathcal{F}$  and  $\mathcal{H}$  are spaces of polynomials over the same field F. Then  $\{f_v \cdot h_u, c_v d_u : (v, u) \in V \times U\}$  is a representation of  $G \cdot H$  over  $\mathcal{F} \otimes \mathcal{H}$ , where  $c_v d_u$  denotes the concatenation of the vectors  $c_v$  and  $d_u$ . Therefore,  $\alpha(G \cdot H) \leq dim(\mathcal{F})dim(\mathcal{H})$ .

**Proof.** By definition, for every  $(v, u), (v', u') \in V \times U$ ,

$$f_v \cdot h_u(c_{v'}d_{u'}) = f_v(c_{v'}) \cdot h_u(d_{u'}).$$

This product is nonzero for (v, u) = (v', u') and is zero for every two distinct nonadjacent vertices (v, u) and (v', u'). Therefore, this is indeed a representation of  $G \cdot H$  over  $\mathcal{F} \otimes \mathcal{H}$ . Since the dimension of  $\mathcal{F} \otimes \mathcal{H}$  is  $dim(\mathcal{F})dim(\mathcal{H})$ , it follows by Lemma 2.2 that  $\alpha(G \cdot H) \leq dim(\mathcal{F})dim(\mathcal{H})$ .  $\square$ 

**Theorem 2.4** Let G = (V, E) be a graph and let  $\mathcal{F}$  be a subspace of the space of polynomials in r variables over a field F. If G has a representation over  $\mathcal{F}$  then  $c(G) \leq dim(\mathcal{F})$ .

**Proof.** By Lemma 2.3 and induction on n, for every integer n,  $\alpha(G^n) \leq dim(\mathcal{F})^n$ , implying the desired result.  $\square$ 

## 3 Unions with large capacities

In this section we describe the proofs of Theorems 1.1 and 1.2 using Theorems 2.1 and 2.4. Note that for any graph G on m vertices, the product  $G \cdot \overline{G}$  is a graph on  $m^2$  vertices whose independence number is at least m. Therefore, by Lemma 2.3, if there is a representation of G over  $\mathcal{F}$  and one of  $\overline{G}$  over  $\mathcal{H}$ , where both  $\mathcal{F}$  and  $\mathcal{H}$  are over the same field, then  $dim(\mathcal{F})dim(\mathcal{H}) \geq m$ . This implies  $dim(\mathcal{F}) + dim(\mathcal{H}) \geq 2\sqrt{m}$ . Note that the assertion of Theorem 2.1 shows that  $c(G + \overline{G}) \geq 2\sqrt{m}$  and that of Theorem 2.4 gives  $c(G) + c(\overline{G}) \leq \dim(\mathcal{F}) + \dim(\mathcal{H})$ . Therefore, this way we **cannot** get a proof that for an appropriate G,  $c(G + \overline{G}) > c(G) + c(\overline{G})$ .

The crucial point that enables us to prove such a statement from the above theorems is that we can apply Theorem 2.4 for G and for  $\overline{G}$  using representations over spaces of polynomials over different fields.

To prove Theorem 1.1 consider the following construction. Let p and q be two primes, put s = pq - 1 and let r > s be an integer. Let G = G = G(p,q,r) be the graph whose vertices are all subsets of cardinality s of the set  $\{1,2,\ldots,r\}$ , where two are adjacent iff the cardinality of their intersection is -1 modulo p. Note that G has  $m = \binom{r}{s}$  vertices. Let  $\mathcal{F}$  denote the space of all multilinear polynomials of degree at most p-1 with r variables over GF(p).

**Lemma 3.1** G has a representation over  $\mathcal{F}$ .

**Proof.** For each vertex of  $G_p$  represented by a subset A of cardinality s of  $\{1, 2, ..., r\}$ , let  $P_A$  be the following polynomial over GF(p)

$$P_A(x_1, x_2, \dots, x_r) = \prod_{i=0}^{p-2} [(\sum_{j \in A} x_j) - i],$$

and let  $c_A \in (GF(p))^r$  denote the characteristic vector of A. Note that  $P_A(c_A) = \prod_{i=0}^{p-2} (pq-1-i) \not\equiv 0 \pmod{p}$ . On the other hand, if A and B are nonadjacent, then  $P_A(c_B) = \prod_{i=0}^{p-2} (|A \cap B| - i) \equiv 0 \pmod{p}$ . Let  $f_A$  be the multilinear polynomial obtained from the standard representation of  $P_A$  as a sum of monomials by using, repeatedly, the relations  $x_i^2 = x_i$ . Since the vectors  $c_A$  have  $\{0,1\}$  coordinates,  $f_A(c_B) = P_A(c_B)$  for all A and B, completing the proof.  $\Box$ 

Let  $\mathcal{H}$  denote the space of all multilinear polynomials of degree at most q-1 with r variables over GF(q).

**Lemma 3.2** The complement  $\overline{G}$  of G has a representation over  $\mathcal{H}$ .

**Proof.** For each vertex of G represented by a subset A of cardinality s of  $\{1, 2, ..., r\}$ , let  $Q_A$  be the polynomial

$$Q_A(x_1, x_2, \dots, x_r) = \prod_{i=0}^{q-2} [(\sum_{j \in A} x_j) - i],$$

and let  $c_A$  denote the characteristic vector of A. As before,  $Q_A(c_A) = \prod_{i=0}^{q-2} (pq-1-i) \not\equiv 0 \pmod{q}$ . Similarly, if A and B are nonadjacent in  $\overline{G}$ , then the cardinality of their intersection is -1 modulo p and hence cannot be -1 modulo q, (since it is strictly smaller than pq-1). Thus, in this case  $Q_A(c_B) = \prod_{i=0}^{q-2} [|A \cap B| - i] \equiv 0 \pmod{q}$ . Let  $h_A$  be the multilinear polynomial obtained from the standard representation of  $Q_A$  as a sum of monomials by using, repeatedly, the relations  $x_i^2 = x_i$ . As before  $h_A(c_B) = Q_A(c_B)$  for all A and B, completing the proof.  $\Box$ 

**Proof of Theorem 1.1.** Let p,q be two primes satisfying q (by the results in [10] there is such a <math>p for each choice of q) and define  $r = p^3$ , G = G(p,q,r). The dimension of the space of all multilinear polynomials of degree at most q with q variables over any field is clearly  $\sum_{i=0}^{g} \binom{r}{i}$ , showing, by Theorem 2.4 and the last two lemmas, that  $c(G) \leq \sum_{i=0}^{p-1} \binom{r}{i} < 2\binom{p^3}{p-1}$  and that  $c(\overline{G}) \leq \sum_{i=0}^{q-1} \binom{r}{i} < 2\binom{p^3}{q-1}$ . On the other hand, by Theorem 2.1,

$$c(G + \overline{G}) \ge 2\sqrt{\binom{p^3}{pq-1}}.$$

This (and the standard facts about the distribution of primes) implies the desired result.  $\Box$ 

**Remark:** The above construction is motivated by a similar, well known construction of Frankl and Wilson [6], and in fact it is possible to use their graph in the proof. Here is their graph and the

modifications needed in the above argument to show it also suffices to prove Theorem 1.1. Let p be a prime, put r = p <sup>3</sup> and s = p <sup>2</sup> − 1, and let G<sup>p</sup> be the graph whose vertices are all subsets of cardinality s of the set {1, 2, . . . , r}, where two are adjacent iff the cardinality of their intersection is congruent to −1 modulo p. Then G<sup>p</sup> has m = r s vertices. It is easy to prove, as in the proof of Lemma 3.1, that G<sup>p</sup> has a representation over the space of all multilinear polynomials of degree at most p − 1 with r variables over GF(p). Similarly, the complement G<sup>p</sup> of G<sup>p</sup> has a representation over the space of all multilinear polynomials of degree at most p − 1 with r variables over the reals. Indeed, for each vertex of G<sup>p</sup> represented by a subset A of cardinality s of {1, 2, . . . , r}, let Q<sup>A</sup> be the polynomial

$$Q_A(x_1, x_2, \dots, x_r) = \prod_{i=1}^{p-1} [(\sum_{j \in A} x_j) - (p^2 - 1 - ip)],$$

and let c<sup>A</sup> denote the characteristic vector of A. Let h<sup>A</sup> be the multilinear polynomial obtained from the standard representation of Q<sup>A</sup> as a sum of monomials by using, repeatedly, the relations x 2 <sup>i</sup> = x<sup>i</sup> . The polynomials h<sup>A</sup> and the vectors c<sup>A</sup> form the required representation.

Since the dimension of the space of all multilinear polynomials of degree at most p − 1 with r variables over any field is <sup>P</sup>p−<sup>1</sup> <sup>i</sup>=0 r i < 2 p 3 p−1 , the conclusions that c(Gp) and c(Gp) are both smaller than 2 p 3 p−1 and that

$$c(G_p + \overline{G_p}) \ge 2\sqrt{\binom{p^3}{p^2 - 1}},$$

follow as before.

The advantage of the construction given by the graphs G(p, q, r) is that unlike the one of Frankl and Wilson it extends easily to provide examples of unions of more than two graphs with large capacities. As described in the next section this also yields new results concerning the Ramsey type question of describing explicitly g-edge colorings of large complete graphs, with no large monochromatic complete subgraphs.

Proof of Theorem 1.2. In [8] Haemers describes explicitly a graph G on m = 27 vertices satisfying c(G) ≤ 7 and c(G) = 3. This graph is the complement of the so-called Schl¨afli graph. For the sake of completeness we describe it here. The vertices are all edges of the complete graph on {1, 2, . . . , 8} except the edge 12. Call an edge a type 1 edge iff it contains either 1 or 2, otherwise, call it a type 2 edge. The adjacency relations are the following: two vertices represented by edges as above are adjacent iff either they are of the same type and are disjoint or they are of different types and are not disjoint. In [8] the author computes the eigenvalues of G and deduces from them the above mentioned bounds for its capacity and the capacity of its complement. The assertion of Theorem 1.2 thus follows from Theorem 2.1. ✷

Remark: In a subsequent paper, Haemers ([9], see also [13]) gave an infinite class of examples of graphs on n vertices G for which c(G)c(G) < n, and many of these can replace the Schl¨afli graph and provide examples similar to the one in the last theorem. In all these examples, however, the capacity of the union is still smaller than the sum of the capacities raised to the power 3/2, whereas the construction in Theorem 1.1 shows that the gap can in fact be much bigger.

#### 4 Explicit Ramsey colorings

Let  $r_g(k)$  denote the smallest integer r so that in every coloring of all edges of the complete graph on r vertices with g colors there is a monochromatic complete subgraph (=clique) on k vertices. The fact that these numbers are finite for all g and k is a special case of Ramsey's well known theorem (see, e.g., [7]), and it is easy and known that  $r_g(k) \leq g^{kg}$ . In one of the first applications of the probabilistic method in combinatorics, Erdős [5] proved that  $r_2(k) \geq \Omega(k2^{k/2})$ . As shown in [11] this can be used to show that  $r_g(k) \geq 2^{\Omega(gk)}$ . The problem of finding explicit edge colorings yielding a similar estimate is still open, despite a considerable amount of efforts by various researchers, and the best known explicit construction is due to Frankl and Wilson [6], who gave an explicit 2-edge coloring of the complete graph on  $k^{(1+o(1))\frac{\log k}{4\log\log k}}$  vertices with no monochromatic clique on k vertices. Their construction is, in fact, the one described in the remark following the proof of Theorem 1.1: if  $G_p$  denotes the graph described there, than neither  $G_p$  nor its complement contain a clique on more than  $2\binom{p^3}{p-1}$  vertices. It seems that this construction does not extend to the case of more than 2 colors. On the other hand, the construction of the graphs G(p,q,r) used in the proof of Theorem 1.1 easily yields such an extension, as we describe next.

Let  $\mathcal{P} = \{p_1, p_2, \dots, p_g\}$  denote a set of g distinct primes, define  $s = p_1 p_2 \dots p_g - 1$ , and let r > s be an integer. Let  $K(\mathcal{P}, r)$  denote the following edge-colored complete graph on the  $\binom{r}{s}$  vertices indexed by all subsets of cardinality s of the set  $X = \{1, 2, \dots, r\}$ . For two vertices represented by the sets A and B, let  $i \leq g$  be the smallest index such that the cardinality of the intersection  $|A \cap B|$  is not -1 modulo  $p_i$ . (Clearly, there is such an i, since this cardinality is strictly smaller than  $p_1 p_2 \cdots p_g - 1$ .) Then the color of the edge connecting A and B is i. Therefore,  $K(\mathcal{P}, r)$  is colored by g colors. The following result bounds the size of the maximum monochromatic complete subgraph in this graph.

**Proposition 4.1** Let  $G_i$  denote the subgraph of  $K = K(\mathcal{P}, r)$  consisting of all edges of K whose color is **not** i. Then the Shannon capacity of  $G_i$  does not exceed  $\sum_{i=0}^{p_i-1} {r \choose i}$ . Thus, the size of the maximum clique of color i in K is at most the above sum.

**Proof.** By Theorem 2.4, it suffices to prove that the graph  $G_i$  has a representation over the space of all multilinear polynomials of degree at most  $p_i - 1$  in r variables over  $GF(p_i)$ . Indeed, for each vertex corresponding to a subset A of X, let  $P_A(x_1, \ldots, x_r)$  be the polynomial

$$P_A(x_1, x_2, \dots, x_r) = \prod_{i=0}^{p-2} [(\sum_{j \in A} x_j) - i],$$

and let c<sup>A</sup> denote the characteristic vector of A. Let f<sup>A</sup> be the multilinear polynomial obtained from the standard representation of P<sup>A</sup> as a sum of monomials by using, repeatedly, the relations x 2 <sup>i</sup> = x<sup>i</sup> . As in the proof of Theorem 1.1, the polynomials f<sup>A</sup> and the vectors c<sup>A</sup> form the required representation. ✷

For a fixed g, let p<sup>1</sup> < p<sup>2</sup> < . . . < p<sup>g</sup> denote g consecutive large primes. By [10], p<sup>g</sup> < (1+o(1))p1. Put P = {p1, . . . , pg}, s = p<sup>1</sup> · . . . · p<sup>g</sup> − 1 and r = p g+1 g . Then, if k denotes 2 r pg−1 , one can easily check that the number of vertices of G(P, r) is

$$\begin{pmatrix} r \\ s \end{pmatrix} = k^{\frac{(1+o(1))(\log k)^{g-1}}{g^g(\log\log k)^{g-1}}}.$$

We have thus proved the following.

Proposition 4.2 For every fixed integer g ≥ 2 and k > k0(g), the g-edge colored complete graph K(P, r) described above has

$$k^{\frac{(1+o(1))(\log k)^{g-1}}{g^g(\log\log k)^{g-1}}}$$

vertices and contains no monochromatic clique on k vertices.

## 5 Concluding remarks

- The upper estimate <sup>P</sup>p−<sup>1</sup> <sup>i</sup>=0 r i for the Shannon capacity of G(p, q, r) can in fact be slightly improved to r p−1 , using the methods of [1]. Since this makes no essential difference here we do not include the details. A similar remark applies, of course, to the estimates in Proposition 4.1.
- Using the graphs G<sup>i</sup> described in Proposition 4.1 together with the arguments in the proof of Theorem 1.1 we can prove that for every fixed integer g ≥ 2 there are g graphs G1, . . . , G<sup>g</sup> satisfying c(Gi) ≤ k for every i, such that the capacity of their disjoint union is at least k Ω((log k/ log log k) g−1 ) .
- Haemers used his examples in [8], [9] to answer a problem of Lov´asz (also mentioned by Shannon [14]) and show that there are graphs G and H for which c(G · H) > c(G) · c(H) (and in fact there are such graphs with H being the complement of G.) Theorem 1.1 provides another family of such examples and shows that in fact c(G · G) may be bigger than any fixed power of c(G) · c(G).
- The normalized Shannon capacity of a graph H on m vertices is defined in [3] as C(H) = log <sup>c</sup>(H) log m . This invariant measures the capacity of the channel as related to its size. By the examples described in the proof of Theorem 1.1 it follows that for every > 0 there are graphs G and G0 satisfying C(G) < and C(G<sup>0</sup> ) < whereas C(G + G<sup>0</sup> ) ≥ 1/2. It would be interesting

to decide if for every  $\epsilon > 0$  there are graphs G and G' satisfying  $C(G) < \epsilon$ ,  $C(G') < \epsilon$  and  $C(G+G') > 1 - \epsilon$ . This question remains open.

• Let G(n, 1/2) denote, as usual, the random graph on n labelled vertices obtained by choosing each pair of vertices, randomly and independently, to be an edge with probability 1/2. The following conjecture seems plausible.

**Conjecture 5.1** There exists an absolute constant b > 0 such that the probability that the Shannon capacity of G(n, 1/2) is bigger than  $b \log_2 n$  tends to 0 as n tends to infinity.

Note that this, if true, would imply that for the random graph G(n, 1/2) (whose complement is obviously also a random graph), it is likely to have an exponential gap between  $c(G) + c(\overline{G})$  and  $c(G+\overline{G})$ . A related question is the problem of estimating the minimum possible value of  $c(G) + c(\overline{G})$  over all graphs of n vertices. By Theorem 1.1 this minimum is at most  $e^{O(\sqrt{\log n \log \log n})}$ , and it is easy to see, using the known bounds for the usual Ramsey numbers, that it is at least  $\Omega(\log n)$ . The problem of estimating the maximum possible value of the capacity of the disjoint union of two graphs G and H each of which has capacity at most k is another intriguing open problem. By Theorem 1.1, this maximum is at least  $k^{\Omega(\frac{\log k}{\log \log k})}$ , but at the moment we are not even able to show that it is upper bounded by any function of k.

Acknowledgment I would like to thank Benny Sudakov and Mario Szegedy for helpful discussions.

#### References

- [1] N. Alon, L. Babai and H. Suzuki, Multilinear polynomials and Frankl-Ray-Chaudhuri-Wilson type intersection theorems, J. Combinatorial Theory, Ser. A **58** (1991), 165–180.
- [2] N. Alon, On the capacity of digraphs, European J. Combinatorics 19 (1998), 1-5.
- [3] N. Alon and A. Orlitsky, Repeated communication and Ramsey graphs, IEEE Transactions on Information Theory 41 (1995), 1276–1289.
- [4] A. Blokhuis, On the Sperner capacity of the cyclic triangle, J. Algebraic Combin. 2 (1993), 123–124.
- [5] P. Erdős, Some remarks on the theory of graphs, Bulletin of the Amer. Math. Soc. **53** (1947), 292–294.
- [6] P. Frankl and R. Wilson, Intersection theorems with geometric consequences, Combinatorica 1 (1981), 357–368.

- [7] R. L. Graham, B. L. Rothschild and J. H. Spencer, Ramsey Theory, Second Edition, Wiley, New York, 1990.
- [8] W. Haemers, On some problems of Lov´asz concerning the Shannon capacity of a graph, IEEE Trans. Inform. Theory 25 (1979), 231–232.
- [9] W. Haemers, An upper bound for the Shannon capacity of a graph, Colloq. Math. Soc. J´anos Bolyai 25, Algebraic Methods in Graph Theory, Szeged, Hungary (1978), 267–272.
- [10] M. N. Huxley, On the difference between consecutive primes, Invent. Math. 15 (1972), 164–170.
- [11] H. Lefmann and V. R¨odl, On canonical Ramsey numbers for complete graphs versus paths, J. Combinatorial Theory, Ser. B 58 (1993), 1–13.
- [12] L. Lov´asz, On the Shannon capacity of a graph, IEEE Trans. Inform. Theory 25 (1979), 1–7.
- [13] R. Peeters, Orthogonal representations over finite fields and the chromatic number of graphs, Combinatorica 16 (1996), 417–431.
- [14] C. E. Shannon, The zero–error capacity of a noisy channel, IRE Trans. Inform. Theory 2 (1956), 8–19.