![](_page_0_Picture_2.jpeg)

![](_page_0_Picture_3.jpeg)

# Mitochondrial dysfunction remodels onecarbon metabolism in human cells

Xiaoyan Robert Bao<sup>1,2,3†</sup>, Shao-En Ong<sup>3‡</sup>, Olga Goldberger<sup>1</sup>, Jun Peng<sup>1,3</sup>, Rohit Sharma<sup>1</sup>, Dawn A Thompson<sup>3</sup>, Scott B Vafai<sup>1,3</sup>, Andrew G Cox<sup>4</sup>, Eizo Marutani<sup>5</sup>, Fumito Ichinose<sup>5</sup>, Wolfram Goessling<sup>3,4</sup>, Aviv Regev<sup>3,6</sup>, Steven A Carr<sup>3</sup>, Clary B Clish<sup>3</sup>, Vamsi K Mootha<sup>1,2,3\*</sup>

<sup>1</sup>Department of Molecular Biology, Howard Hughes Medical Institute, Massachusetts General Hospital, Boston, United States; <sup>2</sup>Department of Systems Biology, Harvard Medical School, Boston, United States; <sup>3</sup>Broad Institute of MIT and Harvard, Cambridge, United States; <sup>4</sup>Genetics Division, Brigham and Women's Hospital, Harvard Medical School, Boston, United States; <sup>5</sup>Department of Anesthesia, Critical Care, and Pain Medicine, Massachusetts General Hospital, Boston, United States; <sup>6</sup>Department of Biology, Howard Hughes Medical Institute, Massachusetts Institute of Technology, Cambridge, United States

**Abstract** Mitochondrial dysfunction is associated with a spectrum of human disorders, ranging from rare, inborn errors of metabolism to common, age-associated diseases such as neurodegeneration. How these lesions give rise to diverse pathology is not well understood, partly because their proximal consequences have not been well-studied in mammalian cells. Here we provide two lines of evidence that mitochondrial respiratory chain dysfunction leads to alterations in one-carbon metabolism pathways. First, using hypothesis-generating metabolic, proteomic, and transcriptional profiling, followed by confirmatory experiments, we report that mitochondrial DNA depletion leads to an ATF4-mediated increase in serine biosynthesis and transsulfuration. Second, we show that lesioning the respiratory chain impairs mitochondrial production of formate from serine, and that in some cells, respiratory chain inhibition leads to growth defects upon serine withdrawal that are rescuable with purine or formate supplementation. Our work underscores the connection between the respiratory chain and one-carbon metabolism with implications for understanding mitochondrial pathogenesis.

DOI: 10.7554/eLife.10575.001

\*For correspondence: vamsi@ hms.harvard.edu

Present address: <sup>†</sup>Berkeley Lights, Inc., Emeryville, United States; <sup>‡</sup>Department of Pharmacology, University of Washington School of Medicine, Seattle, United States

Competing interest: See page 20

Funding: See page 20

Received: 03 August 2015 Accepted: 04 May 2016 Published: 16 June 2016

**Reviewing editor:** Utpal Banerjee, University of California, Los Angeles, United States

© Copyright Bao et al. This article is distributed under the terms of the Creative Commons Attribution License, which permits unrestricted use and redistribution provided that the original author and source are credited.

#### Introduction

Damaged mitochondrial respiratory chains play a key role in the pathogenesis of rare congenital metabolic disorders, as well as in a number of age-associated disorders such as diabetes (*Szendroedi et al., 2012*), neurodegenerative disease (*Schapira et al., 1989*), and aging. Mitochondrial respiratory chain components are encoded by two genomes; respiratory chain proteins encoded by mitochondrial DNA (mtDNA) are expressed in all tissues, yet inherited lesions within mtDNA can lead to varying tissue pathology (*Koopman et al., 2012*; *Vafai and Mootha, 2012*), suggesting a complex interplay between the primary respiratory chain dysfunction and the compensatory adaptations to that dysfunction. Improved understanding of cellular responses to respiratory chain dysfunction promises to deepen our understanding of mitochondrial disease pathogenesis, nominate new biomarkers (*Suomalainen et al., 2011*), and motivate new therapeutic strategies (*Zhang et al., 2013*).

Cellular responses to respiratory chain dysfunction, collectively known as the mitochondrial retrograde response, have been studied in a number of organisms (Haynes et al., 2013; Liu and Butow,

![](_page_1_Picture_1.jpeg)

eLife digest Mitochondria are found within virtually all of our body's cells and are best known as their power plants. Damaged mitochondria cause many diseases in humans – from rare, inherited metabolic disorders that cause symptoms including muscle weakness and developmental problems, to age-related diseases such as diabetes and Parkinson's disease.

How does mitochondrial damage lead to such a variety of symptoms and conditions? To answer this question, researchers must understand how cells respond to and compensate for such damage.

To mimic mitochondrial failure, Bao et al. reduced the amount of DNA in the mitochondria of human cells and observed that this caused the cells to accumulate more of an amino acid called serine. Further investigation showed that this accumulation comes in part from cells producing more serine, and that a protein called Activating Transcription Factor 4 is responsible for increasing the expression of the genes needed to produce serine in the cells.

Bao et al. also found that damaged mitochondria are less able to consume serine to produce a compound called formate, which is a precursor for DNA building blocks. If cells cannot acquire enough extra serine to compensate for this inefficiency, they cannot produce some of the building blocks required to make DNA and other critical compounds in the cell. Supplementing the cells with formate or the DNA building blocks enabled the cells to recover, which suggests that formate supplements may help to treat some mitochondrial disorders.

At a higher level, these results suggest that the mitochondrion's role as a major chemical factory in the cell, and not just as the power plant, may also contribute to disease when the mitochondria are broken. Further work is now needed to investigate how cells know to turn on Activating Transcription Factor 4 when their mitochondria are damaged. It also remains to be discovered whether this reduces or exacerbates the symptoms of mitochondrial disease.

DOI: 10.7554/eLife.10575.002

2006). In yeast, early application of genomic profiling and genetic studies identified a transcriptional program (Liu and Butow, 2006) that senses respiratory chain dysfunction, rewires metabolism to bypass a congested tricarboxylic acid (TCA) cycle, and promotes cellular survival. In worms, errors in mitochondrial biosynthesis trigger the mitochondrial unfolded protein response (UPRmt) to activate transcription of mitochondrial proteases and chaperones, proteins that reduce oxidative stress, and glycolytic enzymes (Nargund et al., 2012). In flies, respiratory chain dysfunction signals to the nucleus and cytosol via reactive oxygen species (ROS) and altered energetics to JNK and AMPK, respectively, to place a checkpoint on cell division (Owusu-Ansah et al., 2008). Induction of a mitochondrial retrograde response in flies has recently been shown to suppress age-dependent degradation of mitochondria (Owusu-Ansah et al., 2013).

Studies of mammalian cells have identified a small collection of cellular responses to respiratory chain dysfunction. Classic studies showed that loss of mtDNA gives rise to uridine and pyruvate dependency (King and Attardi, 1989). Altered mitochondrial calcium uptake stemming from collapse of the mitochondrial membrane potential triggers metabolic alterations (Amuthan et al., 2001). Loss of the mtDNA induces expression of mitochondrial chaperones (Martinus et al., 1996). Recently, a mouse model of mitochondrial respiratory chain disease has been shown to mount an ATF4-mediated, starvation-like transcriptional response (Tyynismaa et al., 2010), though the functional relevance of this response remains unclear. At present, a systematic picture of how mammalian cells respond to respiratory chain dysfunction at the levels of both gene expression and metabolism is lacking; such a picture could help to unify the above observations, while also pointing to novel responsive and adaptive pathways.

We modeled mitochondrial respiratory chain dysfunction in human HEK-293 cells by depleting them of mtDNA. In human cells, mtDNA is required for expression of 13 structural subunits of the oxidative phosphorylation (OXPHOS) complexes that make up the respiratory chain; human patients with mtDNA depletion exhibit severe multicomplex respiratory chain deficiency (Shoffner, 2005). To generate hypotheses about pathways remodeling in respons to mitochondrial dysfunction, we systematically characterized the response of HEK-293 cells to mtDNA depletion using complementary metabolite, RNA, and protein profiling.

![](_page_2_Picture_1.jpeg)

Integrated analysis of the profiles raised the hypothesis that one carbon metabolism, especially serine biosynthesis and transsulfuration, remodels in response to mitochondrial dysfunction. We confirmed this hypothesis with mechanistic follow-up experiments. We then explored alterations in serine metabolism in greater detail, and discovered that cells experience impairment of mitochondrial one-carbon synthesis upon respiratory chain dysfunction. In some cell lines, this leads to dependence on exogenously provided serine in the presence of mitochondrial dysfunction. Thus, our study identifies a new metabolic vulnerability of cells facing mitochondrial stress, with implications for our understanding and treatment of human mitochondrial disorders.

### Results

### A cellular model of mitochondrial dysfunction

We stably transfected T-REx-293 cells, a HEK-293-derived cell line expressing the tet repressor, with a plasmid that expresses a dominant-negative mutant of DNA polymerase gamma (POLGdn) (Jazayeri et al., 2003) under tet repressor control. Doxycycline-triggered expression of POLGdn halts replication of mtDNA, which is then diluted as cells continue to divide (Figure 1a). mtDNA-encoded OXPHOS complex components become depleted (Figure 1a) (Jazayeri et al., 2003), cellular respiratory capacity becomes compromised (Figure 1—figure supplement 2), and after several

![](_page_2_Figure_6.jpeg)

**Figure 1.** Integrated RNA, protein, and metabolite profiling of mtDNA depletion. (a) Experimental model. Doxycycline treatment induces PolGdn expression, mtDNA depletion, and reduction in oxidative phosphorylation complexes (n = 1 for all data). Arrowheads indicate time points analyzed by metabolite, proteomic, and transcriptional profiling. (b) Results from hypothesis-generating integrated profiling (n = 2 for metabolites; n = 1 for transcripts and proteins) showing serine- and homocysteine-related measurements. Numbers in parentheses represent ranks of the respective measurements. (c) Serine biosynthesis and transsulfuration pathways.

DOI: 10.7554/eLife.10575.003

The following figure supplements are available for figure 1:

Figure supplement 1. mtDNA depletion time courses using PolGdn overexpression or EtBr treatment.

DOI: 10.7554/eLife.10575.004

Figure supplement 2. Changes in oxygen consumption induced by mtDNA depletion.

DOI: 10.7554/eLife.10575.005

Figure supplement 3. Metabolite profiling results.

DOI: 10.7554/eLife.10575.006

Figure supplement 4. Spent media metabolite levels shown relative to levels in base media.

DOI: 10.7554/eLife.10575.007

Figure supplement 5. Transcriptional profiling results.

DOI: 10.7554/eLife.10575.008

Figure supplement 6. Protein profiling results (n = 1) at 2 d (yellow) and 5 d (red) of mtDNA depletion.

DOI: 10.7554/eLife.10575.009

![](_page_3_Picture_1.jpeg)

days, cell growth also slows. Removal of doxycycline allows recovery of mtDNA content and cell growth (Figure 1—figure supplement 1). Some of the recovery could be due to selection of cells that lose tet-inducible POLGdn expression (see Materials and methods), so we repeated these experiments using 100 ng/ml ethidium bromide treatment. Ethidium bromide directly inhibits mitochondrial DNA replication, and gave similar results as POLGdn expression (Figure 1—figure supplement 1).

# Integrated profiling of cells during mtDNA depletion

To generate hypotheses as to what biochemical changes arise from POLGdn-induced mtDNA depletion, we performed initial studies using three profiling modalities. We performed metabolite profiling using targeted mass spectrometry (control and days 2 and 3; Figure 1—figure supplement 3; Figure 1—figure supplement 4; and Supplementary file 1), transcriptional profiling using microarrays (selected days between 1 and 25, with two untreated controls; Figure 1—figure supplement 5 and Supplementary file 2), and protein profiling using mass spectrometry (control and days 2 and 5; Figure 1—figure supplement 6 and Supplementary file 3).

We stress that these experiments were performed with limited numbers of replicates: one transcriptional profiling replicate for each of 18 time points; one protein profiling replicate for each of 3 time points; and two metabolite profiling replicates for each of 3 time points and 2 different sample types. The paucity of replicates prevents us from drawing definitive conclusions from the individual profiles. Any hypotheses posed by analyzing these profiles must be considered preliminary and subject to confirmation and validation.

When jointly analyzed, the profiling methodologies suggest increases in transsulfuration and serine biosynthesis (Figure 1b and Figure 1c). Serine itself is the most strongly increased metabolite in all of our analyses, and the serine biosynthesis enzymes are among the most strongly upregulated proteins in our proteomic data. Transcriptional profiling reveals elevation of the entire serine biosynthetic pathway and two high-affinity human serine transporters (SLC1A4 and SLC1A5; Supplementary Table 2a). While our metabolite profiling did not measure cysteine, we did find that the precursor for transsulfuration, homocysteine, was the most strongly decreased metabolite in all of our analysis. Further, we observed increased taurine, a known product of cysteine breakdown, and increased a-hydroxybutyrate, a byproduct of transsulfuration, in metabolite profiling of spent media (Figure 1—figure supplement 3). Finally, we observed transcriptional activation of transsulfuration genes as well as SLC7A11, the dominant cystine transporter of the plasma membrane.

We next performed experiments to confirm the hypothesis that serine metabolism and transsulfuration are altered upon mtDNA depletion, and to understand the molecular basis of these alterations.

### Transcriptional changes arise from ATF4 activation

To discover *cis*-regulatory motifs and factors that might be responsible for our observed transcriptional changes, we performed motifADE analysis (Mootha et al., 2004) on our transcriptional profiles. motifADE scores evolutionarily conserved *cis*-motifs for their relative enrichment within the vicinity of the transcription start sites of genes that are differentially expressed. Among all possible 6, 7, 8-mer, and gapped 9-mer motifs (Figure 2a, Supplementary file 2), the highest-scoring motif was the 8-mer 5'-TGATGCAA-3' (*p* » 1.8-10<sup>4</sup> , Mann-Whitney U test, adjusted for number of motifs tested), which is strikingly similar to consensus ATF4-C/EBP binding site TGATGHAAH (Kilberg et al., 2009). Indeed 26 of the 50 genes (52%) most upregulated in response to mtDNA depletion contain this consensus ATF4-C/EBP binding site near their transcription start sites (Supplementary file 2), representing a strong enrichment over the 14% seen across the genome (p<10–9, binomial test).

We confirmed ATF4 involvement in mtDNA depletion-elicited transcriptional changes by overexpressing an N terminally truncated GADD34 protein (GADD344N), which inhibits ATF4 activation (Novoa et al., 2001), in the parent T-REx-293 cell line. We tested four genes that were among the most highly up-regulated in our microarray dataset. We confirmed that these genes were also highly upregulated upon mtDNA depletion with EtBr, and that GADD344N overexpression inhibits this upregulation (Figure 2b).

![](_page_4_Picture_1.jpeg)

![](_page_4_Figure_2.jpeg)

**Figure 2.** mtDNA depletion activates ATF4. (a) Volcano plot of motifADE analysis results (see Results). Δ median denotes the normalized rank of the median gene associated with each motif. (b) Fold changes of four of the most-upregulated genes in microarray data, in response to mtDNA depletion by ethidium bromide (EtBr) treatment (100 ng/ml, 9 d), and with expression of either GFP or GADD34ΔN. (c) Activation of serine and homocysteine biosynthesis genes, compared to that of genes at the 1<sup>st</sup>, 10<sup>th</sup>, 90<sup>th</sup>, and 99<sup>th</sup> percentiles in each transcriptional profiling timepoint. (d) Activation of serine and cysteine biosynthesis genes in response to mtDNA depletion, with and without GADD34ΔN expression. (e) Activation of ATF4 target genes in response to mitochondrial inhibitors. (f) Activation of ATF4 target genes in response to cytoplasmic redox imbanace elicited by lactate. n = 3 for b, d, e, and f.

DOI: 10.7554/eLife.10575.010

The following figure supplement is available for figure 2:

Figure supplement 1. Doxycycline control treatment data.

DOI: 10.7554/eLife.10575.011

We performed a similar analysis of serine and cysteine biosynthesis genes. In the preliminary transcriptional profiling dataset, five of these genes were upregulated in nearly all the early mtDNA depletion time points (*Figure 2c*). GADD34 $\triangle$ N overexpression blunted activation of all five genes in response to EtBr-induced mtDNA depletion (*Figure 2d*). ATF4 has previously been shown to activate expression of serine biosynthesis genes (*Ye et al., 2012*) and transsulfuration genes (*Dickhout et al., 2012*). Furthermore, chromatin immunoprecipitation experiments have shown

![](_page_5_Picture_1.jpeg)

direct ATF4 protein binding to the promoter regions of PHGDH, PSAT1, and CTH (Han et al., 2013).

We used a series of mitochondrial inhibitors to determine what bioenergetic parameters might be upstream of ATF4 activation (Figure 2e). Inhibition of OXPHOS complexes III and V using antimycin and oligomycin, respectively, gives the strongest activation of genes shown above to be ATF4 responsive. Inhibition of complex I using rotenone gives subtle activation. Membrane potential dissipation using the uncoupler carbonyl cyanide *m*-chlorophenyl hydrazone (CCCP) fails to elicit activation of these genes, and indeed partially reversed ATF4 activation from mtDNA depletion. These results suggest that mtDNA depletion-triggered activation of ATF4 arises from redox stress due to a stalled respiratory chain, and not from defects in ATP synthesis or membrane depolarization.

To further investigate redox effects on ATF4 activation, we manipulated NAD+/NADH in cells by growing them in media with either 1 mM pyruvate or 1 mM lactate. Pyruvate and lactate are known to freely cross the plasma membrane, and altering the extracellular pyruvate:lactate ratio allows control over the cytoplasmic NAD+/NADH ratio through the action of lactate dehydrogenase (Bu¨cher et al., 1972; Williamson et al., 1967). Cells grown in media for 24 hrs with 1 mM lactate showed significantly higher expression of ATF4 target genes than with 1 mM pyruvate (Figure 2f). However, the magnitude of the changes is modest compared to those seen with either antimycin treatment or with mtDNA depletion. Therefore, while altered cellular redox balance appears to contribute to ATF4 activation, other factors, such as oxidative stress from stalling of the respiratory chain, may also be important when mtDNA is depleted.

# Transcriptional and metabolic changes are independent of doxycycline toxicity

Because doxycycline can itself inhibit mitochondrial translation (Ugalde et al., 2004; Wang et al., 2015), we wondered whether direct doxycycline toxicity, and not doxycycline-induced POLGdn, was responsible for the transcriptional effects we observe in our profiling experiments. We used microarrays to measure the effect of 6 d doxycycline treatment on T-REx-293 cells that did not express POLGdn. ATF4 target genes showed much lower activation in doxycycline-treated T-REx-293 cells than in cells with POLGdn induction (Figure 2—figure supplement 1a). When we performed motifADE on the doxycycline control data and considered Bonferroni corrected *p*-values, the ATF4 motif TTGCATCA was not significant (Figure 2—figure supplement 1b).

# Increased H2S production

Transsulfuration is important for generating H2S, an emerging gaseous signaling molecule important for many aspects of mammalian physiology (Kabil et al., 2014). Given our transcriptional and metabolic profiles suggest an activation of transsulfuration, we wondered if mtDNA depletion could also increase H2S production.

To confirm that mtDNA depletion leads to decreased homocysteine abundance, we performed focused measurements of homocysteine levels in T-Rex-293 cells depleted of mtDNA using ethidium bromide (Figure 3a). Next, we used two different methods to detect H2S. First, we reacted cell extracts with monobromobimane (MBB) and detected H2S adducts using HPLC (Tokuda et al., 2012). Second, we detected sulfane sulfur species in cell extracts using SSP4, a fluorescent probe (Marutani et al., 2014). H2S degradation requires a functioning respiratory chain (Hildebrandt and Grieshaber, 2008), so we used acute antimycin A treatment as a control for changes in H2S degradation rate. Both methods revealed increased H2S accumulation as a consequence of mtDNA depletion, greater than the amount induced by acute treatment with antimycin A (Figure 3b). These data support the notion that transcriptional changes elicited by mtDNA depletion have the effect of increasing cellular H2S production.

### Increased serine synthesis and decreased serine consumption

We confirmed alterations in serine using EtBr-treated T-Rex-293 cells, ruling out possible side effects due to doxycycline toxicity as well as statistical anomalies arising from the small sample size used in the initial metabolite profiling (Figure 4a).

In the initial metabolite profiling data, serine was the most strongly consumed metabolite, by fold change compared to base media, in untreated cells (Figure 1—figure supplement 4). Therefore,

![](_page_6_Picture_1.jpeg)

![](_page_6_Figure_2.jpeg)

**Figure 3.** Alterations in transsulfuration-associated metabolites upon mtDNA depletion. (a) Confirmation of decreased homocysteine abundance in spent media with EtBr-induced mtDNA depletion. n = 3. (b) Hydrogen sulfide levels in cells measured either directly (sulfide) or indirectly by its sulfane products (SSP4). Acute antimycin treatment (1 hr) was used to control for increased H<sub>2</sub>S levels arising from decreased H<sub>2</sub>S degradation due to loss of the respiratory chain. n = 6 for both plots.

DOI: 10.7554/eLife.10575.012

increased endpoint serine in the spent media atop mtDNA-depleted cells could reflect either increased synthesis or decreased consumption. To determine the contribution of serine biosynthesis to our observed increase in serine abundance, we performed isotopic tracer analysis using  $^{13}\text{C}$  labeled glucose (*Chaneton et al., 2012*). To avoid product inhibition of serine biosynthesis (*Fell and Snell, 1988*), we used a low (50  $\mu\text{M}$ ) concentration of unlabeled serine in the labeled glucose media. The analysis (*Figure 4b*) shows that in response to mtDNA depletion, cells both produce more serine from glucose and take up less serine from the media. We estimate that the cell volume is at least 1000 fold smaller than the media volume in our experiments. Therefore, decreased serine uptake implies decreased overall serine consumption and not simply decreased serine accumulation in the cytoplasm.

# Respiratory chain dysfunction compromises mitochondrial formate production

To explain why serine consumption decreases, we considered the metabolic roles of serine in mammalian cells. In addition to its role in protein synthesis, serine is also a precursor for phospholipid biosynthesis and a major source of one-carbon (1C) units in folate metabolism, which supports purine and thymidylate synthesis as well as cellular methylation reactions (*Tibbetts and Appling*, 2010). Serine can allosterically activate PKM2 (*Chaneton et al.*, 2012) and thereby regulate the exit of carbons from glycolysis (*Ye et al.*, 2012). Serine is also a precursor for cysteine and glutathione biosynthesis via transsulfuration, and HCT116 cells lacking p53 exhibit serine dependency that is rescuable with glutathione supplementation (*Maddocks et al.*, 2013).

We became interested in the role of serine in 1C metabolism because mitochondria are the source of most of the 1C units used in cellular biosynthesis, and because consumption of serine for 1C metabolism involves an oxidation step that requires an NAD+ cofactor (*Tibbetts and Appling*, 2010). Thus, loss of NAD+ reoxidation due to the loss of the mitochondrial respiratory chain could conceivably lead to impairment of mitochondrial 1C metabolism, as theorized previously (*Desler et al.*, 2010).

To test this model of 1C metabolism blockade in intact cells, we note that the NAD+-dependent step in mitochondrial metabolism is the oxidation of methylene-THF to formyl-THF by MTHFD2. Our model thus predicts an increase in abundance of methylene-THF. We inferred increased methylene-THF abundance by determining rates of serine isotopic scrambling (*Figure 4—figure supplement* 1). Briefly, <sup>13</sup>C<sub>3</sub>-labeled serine generates <sup>13</sup>C<sub>2</sub>-glycine and a <sup>13</sup>C labeled methylene-THF in mitochondria by the action of SHMT2. This labeled methylene-THF can recombine with an unlabeled glycine –

![](_page_7_Picture_1.jpeg)

![](_page_7_Figure_2.jpeg)

**Figure 4.** Respiratory chain dysfunction impairs mitochondrial 1C metabolism. (a) Confirmation of altered serine levels in spent media with EtBr-induced mtDNA depletion. n = 3. (b) Tracing serine metabolism using  $^{13}$ C-labeled glucose. Serine synthesis rates are inferred by labeling cells for 30 min with  $^{13}$ C<sub>6</sub>-glucose and measuring the amount of  $^{13}$ C<sub>3</sub>-serine that emerges. Simultaneously, serine consumption rates can be inferred by the amount of unlabeled serine that disappears during the labeling. n = 3. (c) Testing impairment of mitochondrial 1C metabolism using serine isotope scrambing in SHMT1 KO cells. Impairments in mitochondrial 1C metabolism downstream of  $^{13}$ CH<sub>2</sub>-THF are reflected in increased generation of  $^{13}$ C<sub>1</sub>-serine (see **Figure 4—figure supplement 1**). n = 2. (d) Testing impairment of mitochondrial 1C metabolism by assaying formate production from serine using isolated mitochondria with acute RC inhibition. n = 3.

DOI: 10.7554/eLife.10575.013

The following figure supplements are available for figure 4:

Figure supplement 1. Rationale of serine isotope scrambling assay.

DOI: 10.7554/eLife.10575.014

**Figure supplement 2.** Alterations in cellular NAD+/NADH ratio elicited by mitochondrial manipulations.

DOI: 10.7554/eLife.10575.015

**Figure supplement 3.** Serine isotope scrambling in other cell types. \*, different from 0 day EtBr with p<0.05 (n = 3).

DOI: 10.7554/eLife.10575.016

Figure supplement 4. Determination of homocysteine remethylation.

DOI: 10.7554/eLife.10575.017

which is present in excess – by the reverse action of SHMT2 to generate  $^{13}$ C<sub>1</sub>-serine. The rate of emergence of  $^{13}$ C<sub>1</sub>-serine thus reads out methylene THF abundance. We performed these experiments in SHMT1 knockout cells (see below) to avoid interference from cytoplasmic folate reactions, and found increased emergence of  $^{13}$ C<sub>1</sub>-serine upon mtDNA depletion (*Figure 4c*). We observed similarly increased serine scrambling by treatment with rotenone, which directly inhibits NADH reoxidation through respiratory complex I. Measurement of cellular NAD+:NADH ratios confirms that these are altered with both mtDNA depletion and rotenone treatment (*Figure 4—figure* 

![](_page_8_Picture_1.jpeg)

supplement 2). Therefore, inhibition of mitochondrial respiration likely shifts the redox state of the mitochondrial folate pool in favor of reduced species such as methylene-THF.

To determine whether the shift in the mitochondrial redox state could inhibit mitochondrial 1C metabolism, we performed formate synthesis assays on isolated mitochondria treated with respiratory chain poisons. As shown in Figure 4d, both rotenone and antimycin A partially inhibit mitochondrial synthesis of formate from serine. Garcı´a-Martı´nez and Appling performed similar experiments with mitochondria isolated from rat liver (Garcı´a-Martı´nez and Appling, 1993), and also observed partial inhibition of formate synthesis with rotenone treatment.

### 1C units are not used for homocysteine remethylation in T-REx-293 cells

Elevations in homocysteine often signify insufficient one carbon pools. Hence, an important question is the degree to which mitochondrial 1C compromise is compatible with our observation of decreased homocysteine (Figure 1b). In mammals, homocysteine has two major fates: conversion to cysteine via transsulfuration, and conversion to methionine via remethylation; the latter process consumes cytoplasmic 1C units. Our hypothesized mitochondrial 1C compromise might therefore lead to increased homocysteine abundance and be in direct conflict with the strong observed decrease in homocysteine levels in both spent media and cell extract.

To examine this issue more closely, we performed deuterium tracer experiments to determine the extent of homocysteine remethylation in T-REx-293 cells. As shown in Figure 4—figure supplement 4, homocysteine remethylation using exogenously supplied, deuterated formate was nearly 1000-fold slower than synthesis of serine from deuterated formate. We conclude that remethylation is not a major fate for homocysteine in T-REx-293 cells, regardless of 1C availability. The observation of decreased homocysteine in our experiments, which we attribute to increased transsulfuraton, is therefore compatible with our model of mitochondrial 1C impairment.

# Mitochondrial dysfunction induces serine dependency in 293 cells

1C units are required for cellular biosynthesis, but treating T-REx-293 cells with either rotenone or antimycin, both of which impair mitochondrial 1C generation (Figure 5a), only gave subtle growth rates changes. To test the robustness of 1C metabolism in T-REx-293 cells undergoing mitochondrial dysfunction, we withdrew serine from cells treated with inhibitors. Antimycin- or rotenone-treated cells, but not control DMSO-treated cells, showed strongly impaired growth when serine was withdrawn (Figure 5a, Figure 5—figure supplement 1a). We observed a similar effect with serine withdrawal in cells depleted of mtDNA using EtBr (Figure 5b). A serine dose-response curve in the presence of antimycin (Figure 5—figure supplement 1c) shows optimal cell growth above about 100 mM serine in the media.

We note that this phenomenon is not a true auxotrophy, since cells are still able to synthesize serine. Indeed, if cells with mitochondrial dysfunction were truly serine auxotrophs, they would show increased serine consumption. Instead, we observed the opposite (Figure 4b). We surmise that these cells can overcome blockade of mitochondrial serine metabolism by mass action, but only at high cytoplasmic serine concentrations. Such a bypass mechanism would give rise to serine dependency if cells lose the cytoplasmic serine that they synthesize by diffusion to the media when exogenous serine is withheld, as has been observed for many cell types (Eagle and Piez, 1962).

We also observed serine dependency with oligomycin (Figure 5—figure supplement 1a), which others (Maddocks et al., 2013) have reported in HCT116 cells and attributed to serine involvement in energy metabolism. To distinguish the two models of serine dependency, we tested the effect of the mitochondrial uncoupler CCCP, which impairs energy production (Figure 5—figure supplement 1b) but increases NADH oxidation (Figure 4—figure supplement 2). CCCP did not give rise to serine dependency, and indeed a low dose of CCCP could rescue both the growth defect and the serine dependency arising from oligomycin treatment (Figure 5—figure supplement 1a). These data suggest that the mitochondrial dysfunction-induced serine dependency that we observe is related to the redox state of NAD cofactors, and not to energy impairment.

![](_page_9_Picture_1.jpeg)

![](_page_9_Figure_2.jpeg)

**Figure 5.** Serine dependence in cells with compromised mitochondrial function. (a) Growth of T-REx-293 cells treated with OXPHOS inhibitors, with and without serine, and with serine replaced by formate or hypoxanthine. (b) Same, but of T-REx-293 cells depleted of mtDNA using EtBr. (c) Growth of T-REx-293 cells with knockouts of SHMT1 or SHMT2, with and without serine, and with serine replaced by formate. (d) Growth of *S. cerevisiae* in nonfermentable media with 5 nM antimycin (see Materials and methods), in the presence or absence of serine and adenine. n = 3 for panels a-c; n = 4 for panel d.

DOI: 10.7554/eLife.10575.018

The following figure supplements are available for figure 5:

Figure supplement 1. Additional data on RC inhibition-induced serine dependency in T-REx-293 cells.

DOI: 10.7554/eLife.10575.019

Figure supplement 2. SHMT1 and SHMT2 single and double knockouts.

DOI: 10.7554/eLife.10575.020

Figure supplement 3. RC inhibition-induced serine dependence in other cell types.

DOI: 10.7554/eLife.10575.021

# Serine dependency can be rescued using 1C related metabolites

To further implicate 1C metabolism in serine dependency, we rescued this dependency using 1C related metabolites. Knockouts of MTHFD2 and MTHFD1L, two enzymes involved in mitochondrial formate synthesis, are embryonic lethal in mammals (*Di Pietro et al., 2002; Momb et al., 2013*), but some knockout phenotypes are rescuable with formate or hypoxanthine supplementation (*Momb et al., 2013; Patel et al., 2003*). Exogenous formate bypasses the need for its mitochondrial synthesis, and hypoxanthine is an alternate source of purines, the *de novo* synthesis of which requires 1C units. Experiments on OXPHOS-inhibited T-REx-293 cells with serine withdrawal showed near-complete rescue of growth when media was supplement with either 30 µM hypoxanthine or 3 mM sodium formate (*Figure 5a*). These concentrations of hypoxanthine and formate also gave strong rescue of growth defects in the absence of serine in mtDNA-depleted cells (*Figure 5b*). These data further support the notion that serine dependence in the face of mitochondrial dysfunction is related to 1C metabolism.

![](_page_10_Picture_1.jpeg)

# Exploring compartment specificity using SHMT knockouts

Parallel folate pathways exist in the cytoplasm and the mitochondria (Tibbetts and Appling, 2010). To further determine the compartment specificity of serine fluxes, we used CRISPR/Cas9 (Ran et al., 2013) to knock out serine hydroxymethyltransferase (SHMT) genes in T-REx-293 cells (Figure 5—figure supplement 2). SHMT catalyzes the first step in folate-mediated production of formate from serine. Two isoforms exist in mammals: SHMT1, which is exclusively cytoplasmic, and SHMT2, which is mostly mitochondrial but has a cytoplasmic splice variant (Anderson and Stover, 2009). As expected, knockout of SHMT2, but not SHMT1, abolished formate synthesis from serine in isolated mitochondria (Figure 5—figure supplement 2c). In the presence of serine, neither SHMT1 KO nor SHMT2 KO cell lines required formate or hypoxanthine for growth, indicating that serine can be used to generate 1C units in either compartment. Without serine in the culturing media, SHMT2 KO cells showed strongly suppressed growth that could be rescued with formate, similarly to cells treated with RC inhibitors (Figure 5c), whereas SHMT1 KO cells did not. We hypothesize that high levels of exogenous serine are required to drive conversion of serine to formyl-THF in the cytoplasm via SHMT1, likely because MTHFD1, the cytoplasmic enzyme that makes formate, is coupled to NADPH and thus favors formyl-THF consumption rather than generation (Tibbetts and Appling, 2010). This provides a possible explanation for why high levels of serine can rescue 1C synthesis in T-REx-293 cells with compromised RC function.

Mammalian cells can also derive 1C units from breakdown of choline and glycine, which could in principle support growth in the absence of serine (Tibbetts and Appling, 2010). To investigate the roles of these other 1C precursors, we generated T-REx-293 cells with simultaneous knockout of both SHMT1 and SHMT2 genes. Supplementation with hypoxanthine and thymidine (HT) is required for cell growth in the absence of 1C metabolism (Hakala, 1957), since 1C units are used for the synthesis of purines and of thymidylate (Tibbetts and Appling, 2010). Therefore, we supplemented media with HT when we generated these double-KO (DKO) clones. DKO cells so generated were unable to grow on unsupplemented media, whereas most single knockouts and WT cells were able to grow (Figure 5—figure supplement 2a). In all cases, formate (3 mM) could replace HT to support DKO cell growth (not shown). We conclude from this that other sources of 1C are unable to completely replace serine-derived 1C units. Interestingly, hypoxanthine alone was also able to partially rescue DKO cell growth (Figure 5—figure supplement 2e), suggesting that an alternative pathway might be sufficient to supply 1C for thymidylate synthesis. Finally, DKO cells, when rescued using either formate or hypoxanthine, were no longer serine dependent even with antimycin treatment (Figure 5—figure supplement 2f), indicating that no other functions of serine account for its requirement in cells undergoing RC inhibition.

# Other cell types

We performed serine scrambling assays in five cell lines – T-Rex293, 293T, HeLa, C2C12, and MCH58 – to determine whether mtDNA depletion could induce 1C deficits in each of them. Instead of using SHMT1 knockout cells, we sought to suppress cytoplasmic SHMT activity by using lower concentrations of serine in the labeling media. Except with MCH58 cells, where high variance in the untreated samples prevented us from reaching any conclusions, we consistently observed increased ratios of <sup>13</sup>C1-serine to <sup>13</sup>C3-serine, with at least one time point showing a statistically significant increase for all the other cell lines tested (Figure 4—figure supplement 3).

However, impairment of 1C metabolism only led to serine dependence, manifesting as a proliferation defect upon serine withdrawal, in a small handful of cell lines: besides T-Rex293, we only observed similar results in 293MSR and U251 cells (Figure 5—figure supplement 3); a recent report (Maddocks et al., 2013) additionally shows serine dependence of HCT116 cells treated with oligomycin. We failed to observe serine dependence in many other cell lines, including 293T cells which, like T-Rex293 and 293MSR cells, are derived from HEK-293 cells. We surmise that expression of the large or small T antigen in 293T cells enables them to better cope with respiratory chain dysfunction-induced 1C compromise.

Although few mammalian cells demonstrate serine dependence in the presence of respiratory chain inhibition, we have observed similar phenomena in *S. cerevisiae* grown in nonfermentable media with sub-lethal doses of antimycin: serine withdrawal exacerbates antimycin-induced growth defects in a manner rescuable with purine supplementation (Figure 5d).

![](_page_11_Picture_1.jpeg)

# Discussion

Classic inborn errors of metabolism are due to lesions within linear pathways, leading to accumulation of upstream substrates (that can be toxic) or depletion of essential downstream molecules. Therapeutic strategies for these diseases are often aimed at limiting substrate accumulation or replenishing of downstream factors. In respiratory chain dysfunction, however, the resultant metabolic derangements are manifold because of the numerous mitochondrial and cytoplasmic processes that are intimately coupled to the respiratory chain (Vafai and Mootha, 2012). Well-known metabolic alterations associated with mitochondrial disease include increased reliance on glycolysis as a source of ATP (Robinson et al., 1992), dependence on pyruvate to support aspartate biosynthesis (Sullivan et al., 2015; Birsoy et al., 2015; Cardaci et al., 2015), and inability to synthesize pyrimidines (King and Attardi, 1989).

In this paper, we offer two lines of evidence to support the idea that cellular 1C metabolism is also altered upon respiratory chain dysfunction. First, generating hypotheses with metabolic, proteomic, and transcriptional profiling and following these observations up with focused validation experiments, we report that cells activate serine biosynthesis and transsulfuration in response to mtDNA depletion. Second, we show in separate experiments that lesioning the respiratory chain impairs mitochondrial production of formate from serine. In a small number of cell types, this leads to growth defects upon serine withdrawal that is rescuable with purine or formate supplementation.

An important question is the degree to which our observations of one-carbon metabolism remodeling in proliferating cells are relevant to in vivo mitochondrial disease, which mostly affects postproliferative tissue.

We note that our observation of ATF4 activation and alterations in serine metabolism and transsulfuration is richly supported by recent studies of mitochondrial disease. These have shown ATF4 activation by mitochondrial dysfunction in human cells lines (Martı´nez-Reyes et al., 2012; Silva et al., 2009), rodent models (Tyynismaa et al., 2010), and humans (Crimi et al., 2005). Increased transsulfuration has been observed following ATF4 activation in general (Dickhout et al., 2012), and mitochondrial dysfunction in particular (Krug et al., 2014). One of the byproducts of transsulfuration, a-hydroxybutyrate, has been recently identified as a promising biomarker for mitochondrial disease in humans (Thompson Legault et al., 2015) and mice (Jain et al., 2016). ATF4 is known to activate serine biosynthesis (Ye et al., 2012), and increased serine has been observed in a number of mitochondrial disease settings, albeit with less consistency. Muscle from male mice (but not female ones) with mitochondrial myopathy show increased serine levels (Tyynismaa et al., 2010). Serine was found to be highly elevated in urine from mitochondrial disease patients (Smuts et al., 2013) and proposed as a component of a novel biosignature for mitochondrial disease, but not found to be increased in the blood of a different cohort of mitochondrial disease patients (Clarke et al., 2013). Serine levels are increased in a mitochondrial Parkinson's disease model in *Drosophila* (Tufi et al., 2014), but not in *C. elegans* genetic models of mitochondrial disease (Falk et al., 2008; Morgan et al., 2015).

Furthermore, while serine dependency appears to be cell type specific, 1C compromise as evidenced by altered serine scrambling appears to be more general. We note that a recent report on the effect of mitochondrial inhibitors showed impaired serine uptake and formate release in differentiated C2C12 myotubes (Xu et al., 2011). Therefore, 1C compromise does not appear to be limited to proliferating cells. More recently, studies of mouse mitochondrial disease models have also noted imbalanced nucleotide pools and altered 1C-related metabolites (Nikkanen et al., 2016). Taken together, these data suggest that 1C metabolism is more efficient in the presence of a functioning respiratory chain in a variety of in vivo and in vitro contexts, and argues that the 1C compromise seen with respiratory chain dysfunction might be generalizable to whole body metabolism.

Whether the ATF4 response is adaptive in this context has not been clear. Our study shows ATF4-dependent activation of serine synthesis (Ye et al., 2012) following respiratory chain blockade, and poses the hypothesis that the serine synthesis-activating aspect of ATF4 might be adaptive by helping maintain cellular 1C availability. Indeed, ATF4 has recently been shown to mediate purine synthesis induction by mTORC1 (Ben-Sahra et al., 2016). Transsulfuration constitutes another potentially adaptive element of the ATF4 response program, since it supports synthesis of glutathione, a key cellular ROS scavenger. However, we have so far failed to observe deleterious effects of ablating the ATF4 response in T-REx-293 cells. Since the ATF4 integrated stress response program

![](_page_12_Picture_1.jpeg)

encompasses a number of different genes and functions, we hypothesize that it contains both adaptive and maladaptive components. In support of this notion, a recent paper showed that inhibition of ATF4 activation is protective in rodent models of intracerebral hemorrhage (Karuppagounder et al., 2016).

Our work may provide mechanistic insights into the folate deficiency in mitochondrial disease, with therapeutic implications. Mitochondrial disorders are occasionally associated with cerebral folate deficiency (CFD), and some of these patients are known to respond to treatment with folinic acid (Garcia-Cazorla et al., 2008). No proven mechanism yet connects mitochondrial disease to CFD, but given that brain expresses very little SHMT1 (Girgis et al., 1998), our results pose the hypothesis that CFD may result from impaired mitochondrial formate synthesis (Figure 4). Formate supplementation has been shown to ameliorate defects associated with 1C gene knockout (Momb et al., 2013), and a recent report demonstrated that the bioenergetics defects of a fly model of Parkinson's disease could be reversed with supplementation of nucleotides (Tufi et al., 2014). Mitochondrial disease patients are commonly given folic acid as part of the 'mito cocktail,' with no proven efficacy. Our results suggests that these patients might lack the 1C units that are bound by the folate cofactors, and not the co-factors themselves. Our work raises the hypothesis that formate or nucleotide supplementation may be of benefit in some of respiratory chain diseases.

One of the most puzzling characteristics of mitochondrial diseases is their phenotypic heterogeneity and tissue-specific pathology (Vafai and Mootha, 2012). Our identification of 1C metabolism and transsulfuration as metabolic alterations associated with mitochondrial disease presents a new set of hypotheses that could help explain this heterogeneity. Different organs in the body differ in which 1C donors they utilize, in their ability to metabolize those 1C units (Yoshida and Kikuchi, 1973), and in their transsulfuration activity (Mudd et al., 1965). Because many of these one-carbon pathways are coupled to the respiratory chain, a lesion within the mitochondrion could in principle ripple out to 1C defects that could manifest in many different ways depending on the tissue and cell state. Rapidly proliferating cells might be unable to replicate their DNA due to nucleotide imbalances, whereas metabolically active cells in the liver and kidney might be deprived of essential purinecontaining cofactors such as NAD+. Tissue-specific variations in 1C metabolism may contribute to the remarkable phenotypic variation of mitochondrial disease.

# Materials and methods

# Cell culture

T-REx-293 cells were obtained from Thermo Fisher (Waltham, MA). POLGdn cells were generated as in Jazayeri et al. (2003). U251 cells were obtained from the National Cancer Institute. 293T, HeLa, and C2C12 were obtained from ATCC. MCH58 cells were a generous gift from Eric Shoubridge. We did not authenticate cell lines. However, we were able to differentiate C2C12 myoblasts into myotubes, and were able to PCR the SV40 small and large T antigens from 293T cell genomic DNA. All cells were cultured with DMEM (11995, Thermo Fisher) supplemented with 10% FBS (F6178, Sigma-Aldrich, St. Louis, MO) and grown at 37˚C with 5% CO2. DMEM without serine or glycine, but with 1 mM pyruvate and in every other respect identical to the DMEM obtained from Thermo Fisher, was custom-made (U.S. Biological, Salem, MA) and supplemented with 10% dialyzed serum (F0392, Sigma-Aldrich). All cell cultures were tested for mycoplasma contamination monthly and confirmed to be free of mycoplasma.

# mtDNA analysis

DNA was extracted from cells and analyzed by multiplex real time quantitative PCR as in Baughman (2011). Briefly, samples of 5-10<sup>4</sup> cells were pelleted, aspirated, and suspended in 50 ml lysis buffer (25 mM NaOH, 0.2 mM EDTA). Cell lysate was heated to 95˚C for 15 min to hydrolyze protein and RNA, and neutralized with addition of 50 ml neutralization buffer (40 mM Tris-HCl). 5 ml of 1:50 diluted neutralized cell lysate was analyzed using multiplexed TaqMan real-time quantitative PCR in 20 ml reactions, with a custom-synthesized assay for the AluYb8 repeat element to quantitate nuclear DNA copy number and a custom-synthesized assay for MT-ND2 to quantitate mitochondrial DNA copy number. The custom-synthesized AluYb8 Taqman assay consisted of the forward primer 5'-C TTGCAGTGAGCCGAGATT-3', the reverse primer 5'-GAGACGGAGTC-TCGCTCTGTC-3', and the

![](_page_13_Picture_1.jpeg)

probe 5'-VIC-ACTGCAGTCCGCAGTCCGGCCT-MGBNFQ-3'. The custom-synthesized MT-ND2 assay consisted of the forward primer 5'-TGTTGGTTATACCCTTCCCGTACTA-3', the reverse primer 5'-CCTGCAAAG-ATGGTAGAGTAGATGA-3', and the probe 5'-6FAM-CCCTGGCCCAACCC-MGBNFQ-3'. To calibrate MT-ND2 PCR Ct values, we used dilution ladders of a chemically synthesized primer corresponding to the target of the quantitative PCR assay. To calibrate AluYb8 PCR Ct values, we used dilution ladders of total DNA extracted from human cells.

### mtDNA depletion growth curves and RNA extraction

PolGdn cells were split every 3 d. On each split, two 10 cm plates were seeded with 2.0, 1.0, and 0.5 M each for RNA and protein collection after 1, 2, and 3 d. RNA was extracted from cell plates using RNeasy columns (Qiagen, Germany) with DNase treatment to remove DNA contamination. For protein collection, cells were first trypsinized, suspended, and counted. Counts derived from protein collection were used for growth curve computation. 5-10<sup>4</sup> cell were used for mtDNA analysis. The remaining cells were then pelleted and lysed using RIPA buffer with cOmplete protease inhibitor (Roche, Switzerland). Ethidium bromide growth curves were generated in similar fashion, without plates for RNA samples. We note that continuous doxycycline treatment also gave rise to mtDNA repletion, albeit more slowly than when doxycycline was removed, raising the possibility that the strong selective pressure against POLGdn expression could yield mutant cells that lost POLGdn expression.

# Oxygen consumption measurements

Oxygen consumption measurements were performed in a Seahorse XF24 Analyzer (Agilent, Santa Clara, CA). Untreated and mtDNA-depleted POLGdn-expressing cells, suspended by trypsinization, were seeded at 10<sup>5</sup> per well into Seahorse cell plates pre-treated with Cell-Tak (Becton Dickinson, Santa Clara, CA) according to manufacturer's recommendations. Cells were incubated in DMEM in Seahorse cell plates for 1 hr before oxygen consumption measurement.

# Metabolite profiling

PolGdn-expressing cells were seeded to twelve 6-cm plates at 5-10<sup>5</sup> ea in 3 ml DMEM + 10% FBS. Four of these plates had 1 mg/ml doxycycline, and another four had 1 mg/ml doxycycline added 1 d after seeding. 3 d after seeding, media was collected from plates. Plates were washed once with icecold PBS and aspirated. Polar metabolites were extracted from two plates of each condition using 1 ml -80˚C 80% methanol:20% water. Nonpolar metabolites were extracted from two plates of each condition using 1 ml -80˚C isopropanol.

A combination of three liquid chromatography tandem mass spectrometry (LC-MS) methoda was used to measure metabolites in cell extracts and spent media as described previously (Townsend et al., 2013). Briefly, polar metabolites were profiled using a 4000 QTRAP triple quadrupole mass spectrometer (SCIEX; Framingham, MA) coupled to a 1200 Series pump (Agilent Technologies; Santa Clara, CA) and an HTS PAL autosampler (Leap Technologies; Carrboro, NC). Media samples (10 mL) were extracted using 90 mL of 74.9:24.9:0.2 v/v/v acetonitrile/methanol/formic acid containing stable isotope-labeled internal standards (valine-d8, Isotec; and phenylalanine-d8, Cambridge Isotope Laboratories; Andover, MA) and centrifuged (10 min, 9000 x g, 4˚C). Cell extracts and media extraction supernatants (10 mL) were injected directly onto a 150 x 2 mm Atlantis HILIC column (Waters; Milford, MA). The column was eluted isocratically at a flow rate of 250 mL/min with 5% mobile phase A (10 mM ammonium formate and 0.1% formic acid in water) for 1 min followed by a linear gradient to 40% mobile phase B (acetonitrile with 0.1% formic acid) over 10 min. MS analyses were carried out using electrospray ionization and selective multiple reaction monitoring scans in the positive ion mode. Declustering potentials and collision energies were optimized for each metabolite by infusion of reference standards before sample analyses. The ion spray voltage was 4.5 kV and the source temperature was 450˚C. Polar metabolite were profiling in the negative ion mode using a 5500 QTRAP triple quadrupole mass spectrometer (SCIEX; Framingham, MA) coupled to an ACQUITY UPLC (Waters; Milford, MA). Media samples (30 mL) were extracted using 120 mL of 80% methanol containing inosine-15N4, thymine-d4 and glycocholate-d4 internal standards (Cambridge Isotope Laboratories; Andover, MA) and were centrifuged (10 min, 9000 x g, 4˚C). Cell and media extract supernatents (10 mL) were injected directly onto a 150 x 2.0 mm Luna NH2 column

![](_page_14_Picture_1.jpeg)

(Phenomenex; Torrance, CA) that was eluted at a flow rate of 400 µL/min with initial conditions of 10% mobile phase A (20 mM ammonium acetate and 20 mM ammonium hydroxide in water) and 90% mobile phase B (10 mM ammonium hydroxide in 75:25 v/v acetonitrile/methanol) followed by a 10 min linear gradient to 100% mobile phase A. The ion spray voltage was -4.5 kV and the source temperature was 500°C. Lipid profiling was performed in the positive ion mode using a 4000 QTRAP triple quadrupole mass spectrometer (SCIEX; Framingham, MA) coupled to a 1100 Series pump (Agilent Technologies; Santa Clara, CA) and an HTS PAL autosampler (Leap Technologies; Carrboro, NC). Lipids were extracted from media (10 µL) using 190 µL of isopropanol containing 1-dodecanoyl-2-tridecanoyl-sn-glycero-3-phosphocholine (Avanti Polar Lipids; Alabaster, AL). Cell and media extracts (10 µL) were injected directly onto a 150 x 3.0 mm Prosphere HP C4 column (Grace, Columbia, MD). The column was eluted isocratically with 80% mobile phase A (95:5:0.1 vol/vol/vol 10 mM ammonium acetate/methanol/acetic acid) for 2 min followed by a linear gradient to 80% mobilephase B (99.9:0.1 vol/vol methanol/acetic acid) over 1 min, a linear gradient to 100% mobile phase B over 12 min, then 10 min at 100% mobile-phase B. MS analyses were carried out using electrospray ionization and Q1 scans in the positive ion mode. Ion spray voltage was 5.0 kV and source temperature was 400°C. For each lipid analyte, the first number denotes the total number of carbons in the lipid acyl chain(s) and the second number (after the colon) denotes the total number of double bonds in the lipid acyl chain(s).

For each method, internal standard peak areas were monitored for quality control. MultiQuant software (Version 1.1; AB SCIEX; Foster City, CA) was used for automated peak integration and metabolite peaks were manually reviewed for quality of integration and compared against a known standard to confirm identity.

Cell extract metabolite abundances were normalized to sample geometric means to adjust for cell number differences. We used a multi-step protocol to adjust spent media metabolite abundances. First, we measured a media volume change of 12.0% in 6 cm plates with 3 ml media over the course of 3 d, and re-scaled media metabolite measurements accordingly. Then, we used the log mean cell extract metabolite differences between the different samples to estimate the per-day growth rate difference due to doxycycline treatment. We then used the growth rate difference to estimate changes in the area-under-the-curve (AUC) exposure of media to cells and adjusted accordingly. While this adjustment entailed straightforward flux multiplication in the case of metabolites released to the media, metabolites strongly absorbed from the media were more difficult to treat because multiplication would give rise to cells absorbing more metabolite than was present in the base media. We therefore used an ad-hoc adjustment function for uptaken metabolites that satisfied three criteria: (1) its value and slope would match that for released metabolites at the zero flux boundary case; (2) it would be continuous for all uptake fluxes; (3) measurements of near-100% uptake would adjust to yield near-100% uptake. Our final adjustment function was

$$R_{adj} = \begin{cases} 1 + \alpha(R-1), & R > 1 \\ \frac{R}{\alpha - R(\alpha - 1)}, & 0 < R < 1 \end{cases}$$

where R is the evaporation-adjusted abundance ratio compared to base media,  $\alpha$  the AUC adjustment factor, and R<sub>adj</sub> the growth-adjusted metabolite abundance ratio used in **Figure 1—figure supplement 3** and **Figure 1—figure supplement 4**.

### RNA profiling

RNA from 18 time points (*n* = 1 for each time point) were analyzed using Affymetrix (Santa Clara, CA) Human Genome U133 Plus 2.0 arrays. RNA sample processing, hybridization to Affymetrix U133 Plus 2.0 microarrays, and microarray imaging were performed according to manufacturer's recommendations. Raw microarray data were analyzed using the RMA algorithm with manufacturer-provided probeset definitions. Probesets were filtered in an ad-hoc manner according to three criteria: (a) probeset standard deviation across all the timepoint samples were required to be at least 7.5% of the probeset mean, to remove unchanging probesets; (b) maximum values for probesets were required to be at least 50, to remove probesets with insufficient signal; (c) total power in the second through sixth coefficients of the Fourier transform of the data were required to be at least as strong as the total power in the seventh through twelfth, to remove probesets with high frequency noise that we considered unlikely to be informative. Probesets that did not survive these filters were not

![](_page_15_Picture_1.jpeg)

considered for any downstream analysis. To estimate the number of transcripts with significant changes at day 6, we pooled data from days 5–7 and compared these to data from one and zero days prior to initiation of doxycycyline treatment.

Full microarray data have been deposited to GEO: http://www.ncbi.nlm.nih.gov/geo/query/acc. cgi?acc=GSE55311

# motifADE analysis

(Mootha et al., 2004) was performed using publicly available code (Broad Institute). Genes were ordered by the ratio of the average value from days 1 through 10 of dox treatment, to the average of untreated samples. Sequences flanking transcription start sites, with repeat sequences masked, were obtained from the UCSC genome browser. Mouse-human homology was used to improve detection of conserved transcription factor binding sites. We looked for all ungapped motifs between 6 and 8 in length, as well as 9mer motifs with single gaps. We observed the ATF4 signal regardless of whether we looked for bidirectional occurrence of the motifs or considered each direction separately; the results shown in Figure 2a and Supplementary file 2 are for bidirectional searching.

# Protein overexpression

The N-terminal truncation of GADD34 reported in Novoa et al. (2001) was from CHO-K1 cells; we wished to obtain the analogous human version of the protein. We BLASTed the C. griseus GADD34 protein sequence against the human, and determined that the truncation point corresponded to position 308 in the H. sapiens GADD34 protein sequence (NCBI reference sequence symbol PPP1R15A). We amplified this fragment from T-REx-293-derived complementary DNA using the PCR primers GATGAAGAGGAGGGTGAGGTCAAG and GCCACGCCTCCCACTGAGG, performed an additional 30 cycles of PCR using Gateway-flanked primers that also incorporated an ATG start codon, and recombined the resulting PCR product into the pDONR221 Gateway entry vector using BP Clonase II (Thermo Fisher). We call the protein product of this insert GADD344N. We encountered difficulties in selecting for lentivirally-transduced GADD344N expression using puromycin resistance, and suspected that inhibition of the ATF4 response might make cells more susceptible to puromycin treatment. To work around this, we used restriction digestion to remove the puromycin resistance open reading frame from the pLX302 lentiviral expression vector (Addgene, Cambridge, MA) and used Gibson isothermal assembly (Gibson et al., 2009) to replace it with GFP. We recombined the GADD344N insert into this new vector (which we call pLX-GFP), made virus with psPAX2 (Addgene) and pCMV-VSVG (Broad Institute) helper plasmids, and infected T-Rex293 cells at MOI < 1. We then selected for GFP expression with two rounds of fluorescenceactivated cell sorting on a FACSAria II (Becton Dickinson). Control infections were done similarly, except with an additional copy of GFP instead of GADD344N inserted using Gateway recombination.

### Protein profiling

We characterized protein changes (*n* = 1) for two different time points, plus a control. PolGdn cells were grown in SILAC labeled DMEM (Caisson Labs, Logan, UT) with 10% dialyzed FBS (Sigma). They were first seeded at 4.0-10<sup>6</sup> each into three sets of replicate 15-cm plates with heavy (R10K8), medium (R6K4), and light (R0K0) SILAC media and grown for 3 d. They were then split into eight 15 cm plates for each condition. Doxycycline was added at 1 mg/ml 2 d before the split to heavy labeled cells, and 1 d after the split to medium labeled cells. 3 d after the split, cells were trypsinized, and cells from replicate plates pooled and counted. 7-10<sup>6</sup> cells from each condition were mixed, pelleted, aspirated, suspended in 8 M urea and sonicated. This sample was treated with dithiothreitol (1 mM final), and iodoacetamide (6 mM final) and proteins fractionated by SDS-PAGE. Each gel lane was cut into ten slices of approximately equal staining intensity, in-gel digested with trypsin, and analyzed by liquid chromatography-mass spectrometry on a LTQ-Orbitrap (Thermo, Inc.) following the procedure in Sancak et al. (2013). SILAC data were analyzed using MaxQuant ver.1.0.13.13 according to the procedure described in Cox et al. (2009). A minimum of two quantified peptides was required for each quantified protein. The FDR for protein and peptide identification was set at 0.01. The IPI human database ver 3.65 was used and supplemental sequences from

![](_page_16_Picture_1.jpeg)

mitochondrial DNA and common contaminants such as keratins and serum proteins were included at search time. Raw data are publicly available at www.broadinstitute.org/proteomics

# H2S assays

Sulfide (sum of H2S, HS- , and S2-) levels in the T-REx-293 cells were measured using monobromobimane (MBB)-based high performance liquid chromatography (HPLC) analysis as reported previously (Marutani et al., 2012; Tokuda et al., 2012). Briefly, cells were washed with ice-cold Tris-HCl (100 mM, pH 9.5, 0.1 mM DTPA) buffer, scraped, transfered to an eppendorf tube, and centrifuged to obtain the supernatant. MBB (10 mM in acetonitrile, 50 ml) was added to 100 ml of supernatant. After 30 min of incubation at room temperature in dark, 50 ml of 200 mM 5-sulfosalicylic acid (SSA) was added. After centrifugation, supernatant was analyzed by HPLC equipped with Agilent HPLC column C18 and Waters 2475 Multi l fluorescence detector.

Sulfane sulfur levels in T-REx-293 cells were measured using a sulfane sulfur-specific fluorescent probe SSP4 (generous gift from Dr. Ming Xian, Washington State University) as reported previously (Marutani et al., 2014). Briefly, cells were washed with ice-cold Tris-HCl (100 mM, pH 9.5, 0.1 mM DTPA) buffer, scraped, transfered to an eppendorf tube, and centrifuged to obtain the supernatant. The supernatant was transferred into a 96 well-plate, incubated with SSP4 at 20 mM at 37˚C for 30 min, and fluorescent intensity was read by a microplate reader (SpectraMax M5 Microplate reader, Molecular Devices, Sunnyvalem CA).

# <sup>13</sup>C labeling to determine serine synthesis

PolGdn cells, treated for 0, 3, and 6 d with doxycycline to induce mtDNA depletion, were in triplicate 35 mm plates at approximately 2-10<sup>6</sup> cells per plate. Each plate was washed with warm PBS and aspirated. To each plate was then added 1 ml of warm <sup>13</sup>C glucose media, which was glucoseand serine-free DMEM + 10% dialyzed FBS, supplemented with 25 mM [U-13C]glucose (Cambridge Isotope Labs) and 50 mM unlabeled serine (Sigma). We used this lower concentration of serine (DMEM normally contains 400 mM) to avoid potential product-inhibition of serine synthesis (Fell and Snell, 1988). Cells were incubated with labeling media at 37˚C for 30 min, after which labeling media was removed, pelleted at 2000 g for 20 s, and supernatant taken for LC-MS/MS quantitaton (see below). The cell pellet and cells on plates were trypsinized, pooled, resuspended, and counted to adjust serine fluxes for cell number.

# LC-MS/MS quantitation of <sup>12</sup>C and <sup>13</sup>C serine in media

Cell medium samples (previous paragraph) were prepared using nine volumes (1:9 v/v) of extraction solution containing 75% acetonitrile, 25% methanol, and 0.2% formic acid, and vortexed. Samples were then centrifuged at 11,000 rpm at 4ºC for 8 min, and the supernatant was injected into LC-MS/ MS. A series of <sup>12</sup>C serine (BioUltra 99.5%, Sigma) and <sup>13</sup>C serine (13C3, 99%, Cambridge Isotope Labs) standard solutions at concentrations of 0.1, 0.5, 1, 5, 10, 50 mM were prepared in serine-free base medium to generate a calibration curve. An Agilent 1260 HPLC system coupled with Q Exactive (Thermo Fisher) was used perform LC-MS/MS quantitation. LC Column was Atlantis HILIC Silica 2.1 - 150 mm column and particle size was 3 m m. Mobile Phase A was 0.1% formic acid, 10 mM ammonium formate. Mobile Phase B was 0.1% formic acid in acetonitrile. Column was at room temperature. 10 uL volume of samples was injected into LC-MS/MS. The flow rate was 0.25 mL/min. The LC gradient was as follows: 95% B was held from 0 to 0.5 min, then from 0.5 to 10.5 min, 95% B was linearly changed to 40%. From 10.5 to 15 min, 40% B was held. From 15 min to 17 min 40% B was changed to 95%. From 17 to 32 min, 95% B was held to equilibrate the column. Serine was quantified using the targeted MS2 method. For <sup>12</sup>C serine, the precursor ion was 106.0506 and the fragment ion 60.0454 was used for extraction ion chromatogram. For <sup>13</sup>C serine, the parent ion was 109.0606 and the fragment ion 62.0521 was used for extraction ion chromatogram. The extraction ion mass window was 10 ppm. The NCE was 20.

# Serine and homocysteine measurements

To confirm that mtDNA depletion from EtBr treatment could also give rise to increased serine and decreased homocysteine, we seeded T-REx-293 cells to 6-cm plates at 5-10<sup>5</sup> ea in 3 ml DMEM + 10% FBS, with and without 100 ng/ml EtBr, and collected spent media samples after 3 d incubation.

![](_page_17_Picture_1.jpeg)

To measure total homocysteine (i.e., both oxidized and reduced), 200  $\mu$ l spent media was reduced (*Magera et al., 1999*) by addition of 40  $\mu$ l DTT (0.5 M), vortexed, centrifuged at 2000×g for 1 min to remove any cell debris, and the supernatant incubated at room temperature for 15 min. 120  $\mu$ l of the supernatant was extracted by adding 200  $\mu$ l 0.1% formic acid in ACN, vortexing for 15 s, incubating on ice for 30 min, and centrifuging at 13000×g for 20 min. The resulting supernatant was analyzed by LC-MS for homocysteine abundance as above. Homocysteine signal was acquired in SIM mode.

To measure serine, 200  $\mu$ l spent media was pelleted at 2000 $\times$ g for 1 min to remove cell debris, and 100  $\mu$ l the supernatant extracted by adding 900  $\mu$ l 0.1% formic acid in 75% ACN: 25% methanol, vortexing for 15 s, incubating on ice for 30 min, and centrifuging at 13000 $\times$ g for 20 min. The resulting supernatant was analyzed by LC-MS for serine abundance as above. Serine signal was acquired in full scan mode.

#### **CRISPR** knockouts

For single SHMT knockouts,  $6\times10^5$  T-Rex293 cells in 6-wells were transfected with 300 ng U6-sgRNA PCR product (*Ran et al., 2013*) and 1  $\mu$ g pCas9\_GFP (Addgene #44719) using Roche X-tremeGENE 9. We used the guide sequence CATCTGCAATCTTCCGTAGC for SHMT1 and GCAACCTCAC-GACCGGATCA for SHMT2. 2–3 d after transfection, single cells from the top 5% of GFP expressors were deposited by FACS into 96-wells containing 50% spent media and 50% fresh media, supplemented with 200  $\mu$ M serine and 1:500 normocin (InvivoGen). Single cell colonies were analyzed for SHMT1 and SHMT2 expression by Western blotting; SHMT1 antibodies were Cell Signaling Tech (Danvers, MA) #12612, and SHMT2 antibodies were Thermo Scientific #PA5-32228. Double SHMT knockouts were generated likewise, except transfections were with 225 ng of each U6-sgRNA PCR product, and FACS sorted cells were grown in media further supplemented with 1x HT (100x solution from Thermo Fisher; 16  $\mu$ M thymidine and 100  $\mu$ M hypoxanthine final). We also repeated SHMT1 and SHMT2 single knockout generation with 1x HT supplementation, and none of the knockout lines so generated were hypoxanthine or formate auxotrophs.

# Serine scrambling

Untreated and EtBr-treated SHMT1 KO T-REx-293 cells were seeded in 35 mm plates at  $10^6$  and allowed to attach for 1 d. They were then washed with warm PBS and treated with labeling media (DMEM with 400 uM  $^{13}$ C<sub>3</sub>-serine, 10% dialyzed FBS) for 1 hr. Cells were then washed with ice-cold PBS, and metabolites extracted using 750 ul 80% acetonitrile: 20% water.  $^{13}$ C<sub>3</sub>-serine and  $^{13}$ C<sub>1</sub>-serine were quantitated using the same procedure as for serine synthesis determination.

In follow-up studies, we used 50 uM  $^{13}$ C<sub>3</sub>-serine on wild type cells. T-REx-293, 293T, and HeLa cells were seeded at  $10^6$ ; C2C12 cells at  $2.5 \times 10^5$ ; MCH58 at  $5 \times 10^5$ .

#### NAD+/NADH assays

Cellular NAD+ and NADH content were determined as previously described (Sullivan et al., 2015).

#### Formate synthesis in isolated mitochondria

We used a hybrid cavitation chamber (*Kristián et al., 2006*) / homogenizer (*Mootha et al., 1997*) technique to disrupt cells, followed by differential centrifugation to isolate mitochondria (*Mootha et al., 1997*). All steps for mitochondrial isolation were performed at 4°C. Briefly, 2–4 confluent 15 cm plates of T-REx-293 cells were washed with PBS (room temp) and scraped into a conical tube. These were pelleted at 600g for 10 min, aspirated, and resuspended in 11 ml  $IB_c$  (200 mM sucrose, 10 mM Tris/MOPS, 1 mM EGTA/Tris, Roche cOmplete protease inhibitor, pH 7.4) (*Frezza et al., 2007*). The cell suspension was pressurized to 800 psi with nitrogen in a pre-chilled cavitation chamber (Parr Instruments, Moline, IL) for 15 min, and rapidly decompressed into a Potter-Elvehjem homogenizer. The cell suspension was then homogenized with 5 strokes at 1000 rpm. This lysate was centrifuged at 600 g to remove nuclei and intact cells. Mitochondria in the supernatant were then pelleted at 8000 g, and the supertatant aspirated. Mitochondria were resuspended in  $IB_c$ , and the differential centrifugation procedure repeated. After the second round, mitochondria were suspended in 300–400  $\mu$ I  $IB_c$ , and quantitated by BCA assay (Thermo Fisher). Mitochondria were then pelleted and resuspended to 5.71 mg/ml in experiment buffer EB (137 mM KCI, 2.5 mM

![](_page_18_Picture_1.jpeg)

MgCl2, 10 mM HEPES, 1 mg/ml BSA, pH 7.4). Formate production assays were performed in 105 ml of EB with 150 mg mitochondria, 3 mM Pi, 1 mM serine, and 1 mM ADP, at 37˚C for 20 min. Formate production was stopped by centrifuging the mixture at 8000 g for 10 min (4˚C) and removal of supernatant. Replicate wells of 40 ul supernatant were analyzed using a formate assay kit (Sigma), where one well did not contain enzyme and was used as a background NAD(P)H control. Antimycin and rotenone were used at 1 mM, and the corresponding vehicle control was 0.1% (w/v) DMSO. When drug treatment was used, mitochondria were incubated with drugs for 2 min at 37˚C prior to addition of serine, Pi, and ADP.

# Measurement of remethylation using deuterated formate

T-REx-293 cells were seeded to 6 cm plates at 2-10<sup>6</sup> and allowed to attach and grow for 1 d. They were then washed with warm PBS and treated with serine-free DMEM supplemented with 3 mM Dformate (Sigma) and 10% dialyzed FBS. After 12 hr treatment, cells were aspirated, washed with icecold PBS, and metabolites extracted using 1 ml 80% methanol: 20% water. Deuterated serine and methionine were quantitated as described previously (Mascanfroni et al., 2015). Briefly, cell extracts (10 mL) were diluted using 90 mL of 74.9:24.9:0.2 vol/vol/vol acetonitrile/methanol/formic acid containing stable isotope-labeled internal standards (valine-d8, Isotec; and phenylalanine-d8, Cambridge Isotope Laboratories; Andover, MA). The samples were centrifuged (10 min, 9000 g, 4˚C) and the supernatants were injected directly onto a 150 - 2 mm Atlantis HILIC column (Waters; Milford, MA). The column was eluted isocratically at a flow rate of 250 ml/min with 5% mobile phase A (10 mM ammonium formate and 0.1% formic acid in water) for 1 min followed by a linear gradient to 40% mobile phase B (acetonitrile with 0.1% formic acid) over 10 min. The electrospray ionization voltage was 3.5 kV and data were acquired using full scan analysis over m/z 70–800 at 70,000 resolution. LC-MS data were processed and visually inspected using TraceFinder 3.1 software (Thermo Fisher Scientific; Waltham, MA).

### Growth curves

For each experimental condition, T-Rex293 cells were seeded in triplicate, either at 1.5-10<sup>5</sup> /well in 12-well plates or at 3-10<sup>5</sup> /well in 6-well plates, in DMEM + 10% dialyzed FBS, and split at 2 d or 3d intervals. Ethidium bromide was applied at 100 ng/ml, antimycin at 500 nM, rotenone at 100 nM, and oligomycin at 500 nM. CCCP was used at 5 mM when alone and 3 mM to rescue oligomycin treatment. On each split, cells were trypsinized, counted, and re-seeded to the original density. We used the cell counts to compute growth curves. Growth rates shown in Figure 5—figure supplement 1a and Figure 5—figure supplement 1c were computed by performing least-squares line fits to individual log-transformed growth traces from days 2–6. We omitted growth between days 0 and 2 because the drug-induced growth effects did not appear fully developed before day 2. 293MSR cells were grown identically. U251 cells were grown in triplicate in 6-cm plates at 1.2-10<sup>5</sup> per plate, and rotenone treatment on U251 was at 50 nM. U251 cells were split at 2 d intervals, and the growth rates shown in Figure 5—figure supplement 3 are from days 2–10 in the U251 growth curves and days 0–6 in the 293MSR growth curves.

### Yeast

To revive the *S. cerevisiae* BY4741 strain, cells were plated onto YPD (rich medium) plates from frozen glycerol stocks. After 2 days, cells were taken from plates, re-suspended into liquid YPD, and counted. Next, an appropriate amount of cells were taken to inoculate a 3 mL culture of SD +2% Dextrose (Sunrise Science, San Diego, CA) at 1x10<sup>6</sup> cells/ml. The resulting 3 mL culture was placed in a New Brunswick Scientific (Edison, NJ) model TC-7 roller drum on the fastest rotation until saturated (16 hr). The cells were then counted and diluted back to 1x10<sup>6</sup> cells/ml in SD-serineadenine+2% glycerol+2% ethanol with 5 nm Antimycin A. For the serine and adenine additions, 1X corresponds to 85.6 mg/L and 21 mg/L, respectively. To monitor growth in each condition, 150 uL of culture was placed in the wells of a 96-well plate and growth curves were done using the Bio Tek (Winooski, VT) Synergy H1 multi-mode plate reader. The growth conditions were 30˚C with continuous low shaking. OD<sup>600</sup> was measured every 15 min for 48 hr.

![](_page_19_Picture_1.jpeg)

# Statistics

All significance values were computed using Student's *t*-test (two-tailed) unless otherwise specified. All error bars shown in figures denote standard errors of the mean. *n* values denote biological replicates, *i.e.* measurements performed on independent biological samples.

# Acknowledgements

We thank Josh Baughman, Hany Girgis, Sarah Calvo, Denis Titov, Eran Mick, and other members of the Mootha lab for helpful discussions and technical assistance. We thank the MGH CRM Flow Cytometry Core and the DFCI Microarray Core for technical services, and David Thorburn, Vipin Suri, and Michael Baym for helpful discussions. This work was supported by NIH grant R01DK081457. VKM is an Investigator of the Howard Hughes Medical Institute.

# Additional information

#### Competing interests

AR: is a senior editor at eLife. VKM: is a founder and holds a financial interest in Raze Therapeutics, which is targeting one-carbon metabolism for cancer. The other authors declare that no competing interests exist.

#### Funding

| Funder                             | Grant reference number | Author                                                                                                                                |
|------------------------------------|------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| Howard Hughes Medical<br>Institute |                        | Xiaoyan Robert Bao<br>Olga Goldberger<br>Jun Peng<br>Rohit Sharma<br>Dawn A Thompson<br>Scott B Vafai<br>Aviv Regev<br>Vamsi K Mootha |
| National Institutes of Health      | R01DK081457            | Xiaoyan Robert Bao<br>Vamsi K Mootha                                                                                                  |
| National Institutes of Health      | 2R01CA119176           | Aviv Regev                                                                                                                            |
| National Institutes of Health      | R01HL101930            | Fumito Ichinose                                                                                                                       |
|                                    |                        |                                                                                                                                       |

The funders had no role in study design, data collection and interpretation, or the decision to submit the work for publication.

#### Author contributions

XRB, VKM, Conception and design, Acquisition of data, Analysis and interpretation of data, Drafting or revising the article; S-EO, JP, RS, DAT, SBV, AGC, EM, CBC, Acquisition of data, Analysis and interpretation of data, Drafting or revising the article; OG, Acquisition of data, Drafting or revising the article; FI, WG, AR, SAC, Analysis and interpretation of data, Drafting or revising the article

#### Author ORCIDs

Xiaoyan Robert Bao, http://orcid.org/0000-0001-7931-2944 Vamsi K Mootha, http://orcid.org/0000-0001-9924-642X

# Additional files

#### Supplementary files

. Supplementary file 1. Metabolite profiling data, showing raw mass spectrometry counts as well as adjusted abundance ratios (see Materials and methods).

DOI: 10.7554/eLife.10575.022

. Supplementary file 2. Analysis of microarray data. (a) 100 most upregulated genes. Filtered probesets (see Materials and methods) were sorted according to mean upregulation between days 1 and

![](_page_20_Picture_1.jpeg)

10 of mtDNA depletion. They were then mapped to genes, and redundant probesets were removed leaving only the most strongly upregulated for each gene. (b) 100 most downregulated genes. (c) motifADE results. Shown are all motifs showing an adjusted *p* value of 10-3 or less.

DOI: 10.7554/eLife.10575.023

. Supplementary file 3. Protein profiling data. (a) Full SILAC data, summarized by protein. (b-e) 100 most enriched and depleted proteins (nominal p<0.05, *z*-test) with 2d mtDNA depletion (M/L SILAC ratio) and 5d mtDNA depletion (H/L SILAC ratio). (f) GSEA results, using 'weighted' enrichment statistic on log fold changes. Shown are top 10 gene sets associated with enriched and depleted proteins with 2 d and 5 d mtDNA depletion.

DOI: 10.7554/eLife.10575.024

#### Major datasets

The following datasets were generated:

| Author(s)                             |      | Year Dataset title                                                            | Dataset URL                                                        | Database, license,<br>and accessibility<br>information                                                                              |
|---------------------------------------|------|-------------------------------------------------------------------------------|--------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|
| Bao XR, Goldber<br>ger O, Mootha VK   | 2014 | Gene expression response to<br>mitochondrial DNA depletion                    | http://www.ncbi.nlm.nih.<br>gov/geo/query/acc.cgi?<br>acc=GSE55311 | Publicly available at<br>the NCBI Gene<br>Expression Omnibus<br>(accession no:<br>GSE55311).                                        |
| Bao XR, Ong SE,<br>Carr SA, Mootha VK | 2016 | Mitochondrial dysfunction<br>remodels one-carbon metabolism<br>in human cells | ftp://massive.ucsd.edu/<br>MSV000079791                            | Publicly available at<br>the Mass<br>spectrometry<br>Interactive Virtual<br>Environment<br>(MassIVE, accession<br>no: MSV000079791) |

# References

- Amuthan G, Biswas G, Zhang SY, Klein-Szanto A, Vijayasarathy C, Avadhani NG. 2001. Mitochondria-to-nucleus stress signaling induces phenotypic changes, tumor progression and cell invasion. *The EMBO Journal* 20:1910– 1920. doi: 10.1093/emboj/20.8.1910
- Anderson DD, Stover PJ. 2009. SHMT1 and SHMT2 are functionally redundant in nuclear de novo thymidylate biosynthesis. *PLoS ONE* 4:e5839. doi: 10.1371/journal.pone.0005839
- Baughman JM. 2011. *Computational and Genetic Screens for Regulators of Oxidative Phosphorylation*. Harvard University.
- Ben-Sahra I, Hoxhaj G, Ricoult SJH, Asara JM, Manning BD. 2016. mTORC1 induces purine synthesis through control of the mitochondrial tetrahydrofolate cycle. *Science* 351:728–733. doi: 10.1126/science.aad0489
- Birsoy K, Wang T, Chen WW, Freinkman E, Abu-Remaileh M, Sabatini DM. 2015. An Essential Role of the Mitochondrial Electron Transport Chain in Cell Proliferation Is to Enable Aspartate Synthesis. *Cell* 162:540–591. doi: 10.1016/j.cell.2015.07.016
- Bu¨ cher T, Brauser B, Conze A, Klein F, Langguth O, Sies H. 1972. State of oxidation-reduction and state of binding in the cytosolic nadh-system as disclosed by equilibration with extracellular lactate-pyruvate in hemoglobin-free perfused rat liver. *European Journal of Biochemistry / FEBS* 27:301–317 . doi: 10.1111/j.1432- 1033.1972.tb01840.x
- Cardaci S, Zheng L, MacKay G, van den Broek NJ, MacKenzie ED, Nixon C, Stevenson D, Tumanov S, Bulusu V, Kamphorst JJ, Vazquez A, Fleming S, Schiavi F, Kalna G, Blyth K, Strathdee D, Gottlieb E. 2015. Pyruvate carboxylation enables growth of SDH-deficient cells by supporting aspartate biosynthesis. *Nature Cell Biology* 17:1317–1343. doi: 10.1038/ncb3233
- Chaneton B, Hillmann P, Zheng L, Martin ACL, Maddocks ODK, Chokkathukalam A, Coyle JE, Jankevics A, Holding FP, Vousden KH, Frezza C, O'Reilly M, Gottlieb E. 2012. Serine is a natural ligand and allosteric activator of pyruvate kinase M2. *Nature* 491:458–462. doi: 10.1038/nature11540
- Clarke C, Xiao R, Place E, Zhang Z, Sondheimer N, Bennett M, Yudkoff M, Falk MJ. 2013. Mitochondrial respiratory chain disease discrimination by retrospective cohort analysis of blood metabolites. *Molecular Genetics and Metabolism* 110:145–152. doi: 10.1016/j.ymgme.2013.07.011
- Cox J, Matic I, Hilger M, Nagaraj N, Selbach M, Olsen JV, Mann M. 2009. A practical guide to the maxquant computational platform for silac-based quantitative proteomics. *Nature Protocols* 4:698–705. doi: 10.1038/ nprot.2009.36
- Crimi M, Bordoni A, Menozzi G, Riva L, Fortunato F, Galbiati S, Del Bo R, Pozzoli U, Bresolin N, Comi GP. 2005. Skeletal muscle gene expression profiling in mitochondrial disorders. *FASEB Journal : Official Publication of the Federation of American Societies for Experimental Biology* 19:866–868. doi: 10.1096/fj.04-3045fje

![](_page_21_Picture_1.jpeg)

- Desler C, Lykke A, Rasmussen LJ. 2010. The effect of mitochondrial dysfunction on cytosolic nucleotide metabolism. *Journal of Nucleic Acids* 2010. doi: 10.4061/2010/701518
- Di Pietro E, Sirois J, Tremblay ML, MacKenzie RE. 2002. Mitochondrial NAD-dependent methylenetetrahydrofolate dehydrogenase-methenyltetrahydrofolate cyclohydrolase is essential for embryonic development. *Molecular and Cellular Biology* 22:4158–4166. doi: 10.1128/MCB.22.12.4158-4166.2002
- Dickhout JG, Carlisle RE, Jerome DE, Mohammed-Ali Z, Jiang H, Yang G, Mani S, Garg SK, Banerjee R, Kaufman RJ, Maclean KN, Wang R, Austin RC. 2012. Integrated stress response modulates cellular redox state via induction of cystathionine g-lyase: Cross-talk between integrated stress response and thiol metabolism. *The Journal of Biological Chemistry* 287:7603–7614. doi: 10.1074/jbc.M111.304576
- Eagle H, Piez K. 1962. The population-dependent requirement by cultured mammalian cells for metabolites which they can synthesize. *The Journal of Experimental Medicine* 116:29–43 . doi: 10.1084/jem.116.1.29
- Falk MJ, Zhang Z, Rosenjack JR, Nissim I, Daikhin E, Nissim I, Sedensky MM, Yudkoff M, Morgan PG. 2008. Metabolic pathway profiling of mitochondrial respiratory chain mutants in C. elegans. *Molecular Genetics and Metabolism* 93:388–397. doi: 10.1016/j.ymgme.2007.11.007
- Fell DA, Snell K. 1988. Control analysis of mammalian serine biosynthesis. feedback inhibition on the final step. *The Biochemical Journal* 256:97–101 . doi: 10.1042/bj2560097
- Frezza C, Cipolat S, Scorrano L. 2007. Organelle isolation: Functional mitochondria from mouse liver, muscle and cultured fibroblasts. *Nature Protocols* 2:287–295. doi: 10.1038/nprot.2006.478
- Garcia-Cazorla A, Quadros EV, Nascimento A, Garcia-Silva MT, Briones P, Montoya J, Ormaza´ bal A, Artuch R, Sequeira JM, Blau N, Arenas J, Pineda M, Ramaekers VT. 2008. Mitochondrial diseases associated with cerebral folate deficiency. *Neurology* 70:1360–1362. doi: 10.1212/01.wnl.0000309223.98616.e4
- Garcı´a-Martı´nez LF, Appling DR. 1993. Characterization of the folate-dependent mitochondrial oxidation of carbon 3 of serine. *Biochemistry* 32:4671–4676 . doi: 10.1021/bi00068a027
- Gibson DG, Young L, Chuang RY, Venter JC, Hutchison CA, Smith HO. 2009. Enzymatic assembly of DNA molecules up to several hundred kilobases. *Nature Methods* 6:343–345. doi: 10.1038/nmeth.1318
- Girgis S, Nasrallah IM, Suh JR, Oppenheim E, Zanetti, KA, Mastri MG, Stover PJ. 1998. Molecular cloning, characterization and alternative splicing of the human cytoplasmic serine hydroxymethyltransferase gene. *Gene* 210:315–324 . doi: 10.1016/s0378-1119(98)00085-7
- Gohil VM, Sheth SA, Nilsson R, Wojtovich AP, Lee JH, Perocchi F, Chen W, Clish CB, Ayata C, Brookes PS, Mootha VK. 2010. Nutrient-sensitized screening for drugs that shift energy metabolism from mitochondrial respiration to glycolysis. *Nature Biotechnology* 28:249–255. doi: 10.1038/nbt.1606
- Hakala MT. 1957. Prevention of toxicity of amethopterin for sarcoma-180 cells in tissue culture. *Science* 126:255. doi: 10.1126/science.126.3267.255
- Han J, Back SH, Hur J, Lin YH, Gildersleeve R, Shan J, Yuan CL, Krokowski D, Wang S, Hatzoglou M, Kilberg MS, Sartor MA, Kaufman RJ. 2013. ER-stress-induced transcriptional regulation increases protein synthesis leading to cell death. *Nature Cell Biology* 15:481–490. doi: 10.1038/ncb2738
- Haynes CM, Fiorese CJ, Lin YF. 2013. Evaluating and responding to mitochondrial dysfunction: The mitochondrial unfolded-protein response and beyond. *Trends in Cell Biology* 23:311–318. doi: 10.1016/j.tcb. 2013.02.002
- Hildebrandt TM, Grieshaber MK. 2008. Three enzymatic activities catalyze the oxidation of sulfide to thiosulfate in mammalian and invertebrate mitochondria. *The FEBS Journal* 275:3352–3361. doi: 10.1111/j.1742-4658. 2008.06482.x
- Jain IH, Zazzeron L, Goli R, Alexa K, Schatzman-Bone S, Dhillon H, Goldberger O, Peng J, Shalem O, Sanjana NE, Zhang F, Goessling W, Zapol WM, Mootha VK. 2016. Hypoxia as a therapy for mitochondrial disease. *Science* 352:54–61. doi: 10.1126/science.aad9642
- Jazayeri M, Andreyev A, Will Y, Ward M, Anderson CM, Clevenger W. 2003. Inducible expression of a dominant negative DNA polymerase-gamma depletes mitochondrial DNA and produces a rho0 phenotype. *The Journal of Biological Chemistry* 278:9823–9830 . doi: 10.1074/jbc.m211730200
- Kabil O, Vitvitsky V, Banerjee R. 2014. Sulfur as a signaling nutrient through hydrogen sulfide. *Annual Review of Nutrition* 34:171–205. doi: 10.1146/annurev-nutr-071813-105654
- Karuppagounder SS, Alim I, Khim SJ, Bourassa MW, Sleiman SF, John R, Thinnes CC, Yeh TL, Demetriades M, Neitemeier S, Cruz D, Gazaryan I, Killilea DW, Morgenstern L, Xi G, Keep RF, Schallert T, Tappero RV, Zhong J, Cho S, et al. 2016. Therapeutic targeting of oxygen-sensing prolyl hydroxylases abrogates atf4-dependent neuronal death and improves outcomes after brain hemorrhage in several rodent models. *Science Translational Medicine* 8:328ra29. doi: 10.1126/scitranslmed.aac6008
- Kilberg MS, Shan J, Su N. 2009. ATF4-dependent transcription mediates signaling of amino acid limitation. *Trends in Endocrinology and Metabolism* 20. doi: 10.1016/j.tem.2009.05.008
- King M, Attardi G. 1989. Human cells lacking mtdna: Repopulation with exogenous mitochondria by complementation. *Science* 246:500–503. doi: 10.1126/science.2814477
- Koopman WJ, Willems PH, Smeitink JA. 2012. Monogenic mitochondrial disorders. *The New England Journal of Medicine* 366:1132–1141. doi: 10.1056/NEJMra1012478
- Kristia´n T, Hopkins IB, McKenna MC, Fiskum G. 2006. Isolation of mitochondria with high respiratory control from primary cultures of neurons and astrocytes using nitrogen cavitation. *Journal of Neuroscience Methods* 152:136–143. doi: 10.1016/j.jneumeth.2005.08.018
- Krug AK, Gutbier S, Zhao L, Po¨ ltl D, Kullmann C, Ivanova V, Fo¨ rster S, Jagtap S, Meiser J, Leparc G, Schildknecht S, Adam M, Hiller K, Farhan H, Brunner T, Hartung T, Sachinidis A, Leist M, Po¨ ltl, D., Leist, M.

![](_page_22_Picture_1.jpeg)

- 2014. Transcriptional and metabolic adaptation of human neurons to the mitochondrial toxicant MPP(+). *Cell Death & Disease* 5:e1222. doi: 10.1038/cddis.2014.166
- Liu Z, Butow RA. 2006. Mitochondrial retrograde signaling. *Annual Review of Genetics* 40:159–185. doi: 10.1146/ annurev.genet.40.110405.090613
- Maddocks ODK, Berkers CR, Mason SM, Zheng L, Blyth K, Gottlieb E, Vousden KH. 2013. Serine starvation induces stress and p53-dependent metabolic remodelling in cancer cells. *Nature* 493:542–546. doi: 10.1038/ nature11743
- Magera MJ, Lacey JM, Casetta B, Rinaldo P. 1999. Method for the determination of total homocysteine in plasma and urine by stable isotope dilution and electrospray tandem mass spectrometry. *Clinical Chemistry* 45: 1517–1522.
- Martinus RD, Garth GP, Webster TL, Cartwright P, Naylor DJ, Høj PB, Hoogenraad NJ. 1996. Selective induction of mitochondrial chaperones in response to loss of the mitochondrial genome. *European Journal of Biochemistry / FEBS* 240:98–103. doi: 10.1111/j.1432-1033.1996.0098h.x
- Martı´nez-Reyes I, Sa´ nchez-Arago´ M, Cuezva JM. 2012. AMPK and GCN2-ATF4 signal the repression of mitochondria in colon cancer cells. *The Biochemical Journal* 444:249–259. doi: 10.1042/BJ20111829
- Marutani E, Kosugi S, Tokuda K, Khatri A, Nguyen R, Atochin DN, Kida K, Van Leyen K, Arai K, Ichinose F. 2012. A novel hydrogen sulfide-releasing n-methyl-d-aspartate receptor antagonist prevents ischemic neuronal death. *The Journal of Biological Chemistry* 287:32124–32135. doi: 10.1074/jbc.M112.374124
- Marutani E, Sakaguchi M, Chen W, Sasakura K, Liu J, Xian M, Hanaoka K, Nagano T, Ichinose F. 2014. Cytoprotective effects of hydrogen sulfide-releasing n-methyl-d-aspartate receptor antagonists are mediated by intracellular sulfane sulfur. *MedChemComm* 5:1577–1583. doi: 10.1039/C4MD00180J
- Mascanfroni ID, Takenaka MC, Yeste A, Patel B, Wu Y, Kenison JE, Siddiqui S, Basso AS, Otterbein LE, Pardoll DM, Pan F, Priel A, Clish CB, Robson SC, Quintana FJ. 2015. Metabolic control of type 1 regulatory T cell differentiation by AHR and hif1-a. *Nature Medicine* 21:638–646. doi: 10.1038/nm.3868
- Momb J, Lewandowski JP, Bryant JD, Fitch R, Surman DR, Vokes SA, Appling DR. 2013. Deletion of mthfd1l causes embryonic lethality and neural tube and craniofacial defects in mice. *Proceedings of the National Academy of Sciences of the United States of America* 110:549–554. doi: 10.1073/pnas.1211199110
- Mootha VK, Arai AE, Balaban RS. 1997. Maximum oxidative phosphorylation capacity of the mammalian heart. *The American Journal of Physiology* 272:H769–775.
- Mootha VK, Handschin C, Arlow D, Xie X, St Pierre J, Sihag S, Yang W, Altshuler D, Puigserver P, Patterson N, Willy PJ, Schulman IG, Heyman RA, Lander ES, Spiegelman BM. 2004. Erralpha and gabpa/b specify pgc-1alpha-dependent oxidative phosphorylation gene expression that is altered in diabetic muscle. *Proceedings of the National Academy of Sciences of the United States of America* 101:6570–6575. doi: 10.1073/pnas. 0401401101
- Morgan PG, Higdon R, Kolker N, Bauman AT, Ilkayeva O, Newgard CB, Kolker E, Steele LM, Sedensky MM. 2015. Comparison of proteomic and metabolomic profiles of mutants of the mitochondrial respiratory chain in caenorhabditis elegans. *Mitochondrion* 20:95–102. doi: 10.1016/j.mito.2014.12.004
- Mudd SH, Finkelstein JD, Irreverre F, Laster L. 1965. Transsulfuration in mammals. microassays and tissue distributions of three enzymes of the pathway. *The Journal of Biological Chemistry* 240:4382–4392.
- Nargund AM, Pellegrino MW, Fiorese CJ, Baker BM, Haynes CM. 2012. Mitochondrial import efficiency of ATFS-1 regulates mitochondrial UPR activation. *Science* 337:587–590. doi: 10.1126/science.1223560
- Nikkanen J, Forsstro¨ m S, Euro L, Paetau I, Kohnz RA, Wang L, Chilov D, Viinama¨ ki J, Roivainen A, Marjama¨ ki P, Liljenba¨ ck H, Ahola S, Buzkova J, Terzioglu M, Khan NA, Pirnes-Karhu S, Paetau A, Lo¨ nnqvist T, Sajantila A, Isohanni P, et al. 2016. Mitochondrial DNA replication defects disturb cellular dntp pools and remodel onecarbon metabolism. *Cell Metabolism* 23. doi: 10.1016/j.cmet.2016.01.019
- Novoa I, Zeng H, Harding HP, Ron D. 2001. Feedback inhibition of the unfolded protein response by gadd34 mediated dephosphorylation of eif2alpha. *The Journal of Cell Biology* 153:1011–1022. doi: 10.1083/jcb.153.5.
- Owusu-Ansah E, Song W, Perrimon N. 2013. Muscle mitohormesis promotes longevity via systemic repression of insulin signaling. *Cell* 155:699–712. doi: 10.1016/j.cell.2013.09.021
- Owusu-Ansah E, Yavari A, Mandal S, Banerjee U. 2008. Distinct mitochondrial retrograde signals control the G1- S cell cycle checkpoint. *Nature Genetics* 40:356–361. doi: 10.1038/ng.2007.50
- Patel H, Pietro ED, MacKenzie RE. 2003. Mammalian fibroblasts lacking mitochondrial nad+-dependent methylenetetrahydrofolate dehydrogenase-cyclohydrolase are glycine auxotrophs. *The Journal of Biological Chemistry* 278:19436–19441. doi: 10.1074/jbc.M301718200
- Ran FA, Hsu PD, Wright J, Agarwala V, Scott DA, Zhang F. 2013. Genome engineering using the crispr-cas9 system. *Nature Protocols* 8:2281–2308. doi: 10.1038/nprot.2013.143
- Robinson BH, Petrova-Benedict R, Buncic JR, Wallace DC. 1992. Nonviability of cells with oxidative defects in galactose medium: a screening test for affected patient fibroblasts. *Biochemical Medicine and Metabolic Biology* 48:122–126. doi: 10.1016/0885-4505(92)90056-5
- Sancak Y, Markhard AL, Kitami T, Kovacs-Bogdan E, Kamer KJ, Udeshi ND, Carr SA, Chaudhuri D, Clapham DE, Li AA, Calvo SE, Goldberger O, Mootha VK. 2013. EMRE is an essential component of the mitochondrial calcium uniporter complex. *Science* 342:1379–1382. doi: 10.1126/science.1242993
- Schapira AH, Cooper JM, Dexter D, Jenner P, Clark JB, Marsden CD. 1989. Mitochondrial complex I deficiency in parkinson's disease. *Lancet* 1. doi: 10.1016/S0140-6736(89)92366-0
- Shoffner J. 2005. Oxidative Phosphorylation Disease. In: Berdanier C. D eds *Mitochondria in Health and Disease*. boca raton: CRC Press 06 . p247–300. doi: 10.1201/9781420028843.ch4

![](_page_23_Picture_1.jpeg)

- Silva JM, Wong A, Carelli V, Cortopassi GA. 2009. Inhibition of mitochondrial function induces an integrated stress response in oligodendroglia. *Neurobiology of Disease* 34:357–365. doi: 10.1016/j.nbd.2009.02.005
- Smuts I, van der Westhuizen FH, Louw R, Mienie LJ, Engelke UFH, Wevers RA, Mason S, Koekemoer G, Reinecke CJ. 2013. Disclosure of a putative biosignature for respiratory chain disorders through a metabolomics approach. *Metabolomics* 9:379–391. doi: 10.1007/s11306-012-0455-z
- Sullivan LB, Gui DY, Hosios AM, Bush LN, Freinkman E, Vander Heiden MG. 2015. Supporting aspartate biosynthesis is an essential function of respiration in proliferating cells. *Cell* 162:552–563. doi: 10.1016/j.cell. 2015.07.017
- Suomalainen A, Elo JM, Pietila¨ inen KH, Hakonen AH, Sevastianova K, Korpela M, Isohanni P, Marjavaara SK, Tyni T, Kiuru-Enari S, Pihko H, Darin N, O˜ unap K, Kluijtmans LA, Paetau A, Buzkova J, Bindoff LA, Annunen-Rasila J, Uusimaa J, Rissanen A, et al. 2011. FGF-21 as a biomarker for muscle-manifesting mitochondrial respiratory chain deficiencies: A diagnostic study. *The Lancet. Neurology* 10:806–818. doi: 10.1016/S1474-4422(11)70155- 7
- Szendroedi J, Phielix E, Roden M. 2012. The role of mitochondria in insulin resistance and type 2 diabetes mellitus. *Nature Reviews Endocrinology* 8:92–103. doi: 10.1038/nrendo.2011.138
- Thompson Legault J, Strittmatter L, Tardif J, Sharma R, Tremblay-Vaillancourt V, Aubut C, Boucher G, Clish CB, Cyr D, Daneault C, Waters PJ, Vachon L, Morin C, Laprise C, Rioux JD, Mootha VK, Des Rosiers C., Consortium LSFC., LSFC Consortium. 2015. A metabolic signature of mitochondrial dysfunction revealed through a monogenic form of leigh syndrome. *Cell Reports* 13:981–989. doi: 10.1016/j.celrep.2015.09.054
- Tibbetts AS, Appling DR. 2010. Compartmentalization of mammalian folate-mediated one-carbon metabolism. *Annual Review of Nutrition* 30:57–81. doi: 10.1146/annurev.nutr.012809.104810
- Tokuda K, Kida K, Marutani E, Crimi E, Bougaki M, Khatri A, Kimura H, Ichinose F. 2012. Inhaled hydrogen sulfide prevents endotoxin-induced systemic inflammation and improves survival by altering sulfide metabolism in mice. *Antioxidants & Redox Signaling* 17:11–21. doi: 10.1089/ars.2011.4363
- Townsend MK, Clish CB, Kraft P, Wu C, Souza AL, Deik AA, Tworoger SS, Wolpin BM. 2013. Reproducibility of metabolomic profiles among men and women in 2 large cohort studies. *Clinical Chemistry* 59:1657–1724. doi: 10.1373/clinchem.2012.199133
- Tufi R, Gandhi S, de Castro IP, Lehmann S, Angelova PR, Dinsdale D, Deas E, Plun-Favreau H, Nicotera P, Abramov AY, Willis AE, Mallucci GR, Loh SH, Martins LM. 2014. Enhancing nucleotide metabolism protects against mitochondrial dysfunction and neurodegeneration in a PINK1 model of parkinson's disease. *Nature Cell Biology* 16:157–166. doi: 10.1038/ncb2901
- Tyynismaa H, Carroll CJ, Raimundo N, Ahola-Erkkila¨ S, Wenz T, Ruhanen H, Guse K, Hemminki A, Peltola-Mjøsund KE, Tulkki V, Oresic M, Moraes CT, Pietila¨ inen K, Hovatta I, Suomalainen A. 2010. Mitochondrial myopathy induces a starvation-like response. *Human Molecular Genetics* 19:3948–3958. doi: 10.1093/hmg/ ddq310
- Ugalde C, Vogel R, Huijbens R, Van Den Heuvel B, Smeitink J, Nijtmans L. 2004. Human mitochondrial complex I assembles through the combination of evolutionary conserved modules: A framework to interpret complex I deficiencies. *Human Molecular Genetics* 13:2461–2472. doi: 10.1093/hmg/ddh262
- Vafai SB, Mootha VK. 2012. Mitochondrial disorders as windows into an ancient organelle. *Nature* 491:374–383. doi: 10.1038/nature11707
- Wang X, Ryu D, Houtkooper RH, Auwerx J. 2015. Antibiotic use and abuse: A threat to mitochondria and chloroplasts with impact on research, health, and environment. *BioEssays* 37:1045–1053. doi: 10.1002/bies. 201500071
- Williamson DH, Lund P, Krebs HA. 1967. The redox state of free nicotinamide-adenine dinucleotide in the cytoplasm and mitochondria of rat liver. *The Biochemical Journal* 103:514–527 . doi: 10.1042/bj1030514
- Xu Q, Vu H, Liu L, Wang TC, Schaefer WH. 2011. Metabolic profiles show specific mitochondrial toxicities in vitro in myotube cells. *Journal of Biomolecular NMR* 49:207–219. doi: 10.1007/s10858-011-9482-8
- Ye J, Mancuso A, Tong X, Ward PS, Fan J, Rabinowitz JD, Thompson CB. 2012. Pyruvate kinase M2 promotes de novo serine synthesis to sustain mtorc1 activity and cell proliferation. *Proceedings of the National Academy of Sciences of the United States of America* 109:6904–6909. doi: 10.1073/pnas.1204176109
- Yoshida T, Kikuchi G. 1973. Majors pathways of serine and glycine catabolism in various organs of the rat and cock. *Journal of Biochemistry* 73:1013–1022.
- Zhang Z, Tsukikawa M, Peng M, Polyak E, Nakamaru-Ogiso E, Ostrovsky J, McCormack S, Place E, Clarke C, Reiner G, McCormick E, Rappaport E, Haas R, Baur JA, Falk MJ. 2013. Primary respiratory chain disease causes tissue-specific dysregulation of the global transcriptome and nutrient-sensing signaling network. *Plos ONE* 8: e69282. doi: 10.1371/journal.pone.0069282