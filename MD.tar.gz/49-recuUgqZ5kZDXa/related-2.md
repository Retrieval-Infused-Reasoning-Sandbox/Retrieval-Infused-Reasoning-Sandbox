## [EXTENSIONS OF LIPSCHITZ MAPPINGS INTO A HILBERT SPACE](#page--1-0)

1 2 William B. Johnson and Joram Lindenstrauss

#### INTRODUCTION

In this note we consider the following extension problem for Lipschitz functions: Given a metric space X and n = 2, 3, 4, ... ' estimate the smallest constant L = L(X, n) so that every ~pping f from every n-element subset of X into *t 2* extends to a mapping f from X into *<sup>t</sup> 2* with

$$\|\mathbf{\tilde{f}}\|_{\ell ip} \leq L \|\mathbf{f}\|_{\ell ip}$$
.

(Here ll&lltip is the Lipschitz constant of the function g.) A classical result of Kirszbraun's [14, p. 48] states that L(t2, n) = 1 for all n, but it is easy to see that L(X, n) ~ ~ as n ~ ~ for many metric spaces X.

Marcus and Pisier [10] initiated the study of L(X, n) for X = Lp. (For brevity, we will use hereafter the notation L(p, n) for L(Lp(O,l), n).) They prove that for each 1 < p < 2 there is a constant C(p) so that for n = 2, 3, 4, , , ,

$$L(p, n) \le C(p) (Log n)^{1/p} - 1/2$$
.

The main result of this note is a verification of their conjecture that for some constant C and all n = 2, 3, 4, , , ,

$$L(X, n) \leq C(Log n)^{1/2}$$

for all metric spaces X. While our proof is completely different from that of Marcus and Pisier, there is a common theme: Probabilistic techniques developed for linear theory are combiaed with Kirszbraun's theorem to yield extension theorems.

The main tool for proving Theorem 1 is a simply stated elementary geometric lemma, which we now describe: Given n points in Euclidean space, what

© 1984 American Mathematical Society 0271-4132/84 \$1.00 + *\$25* per page

<sup>1</sup>  Supported in part by NSF MCS-7903042.

<sup>2</sup>  Supported in part by NSF MCS-8102714.

is the smallest k = k(n) so that these points can be moved into k-dimensional Euclidean space via a transformation which expands or contracts all pairwise distances by a factor of at most 1 + e? The answer, that k ~ C(e) Log n, is a simple consequence of the isoperimetric inequality for the n-sphere in the form studied in [2].

It seems likely that the Marcus-Pisier result and Theorem 1 give the right order of growth for L(p, n). While we cannot verify this, in Theorem 3 we get the estimate

$$L(p, n) \ge \delta \left(\frac{\text{Log } n}{\text{Log Log } n}\right)^{1/p - 1/2} \quad (1 \le p < 2)$$

for some absolute constant 6 > 0. (Throughout this paper we use the convention that Log X denotes the maximum of 1 and the natural logarithm of x.) This of course gives a lower estimate of

$$\delta \left( \frac{\text{Log n}}{\text{Log Log n}} \right)^{1/2}$$

for L(~, n). That our approach cannot give a lower bound of 6(Log n)l/p - l/2 for L(p, n) is shown by Theorem 2, which is an extension theorem for mappings into *e2* whose domains are e-separated.

The minimal notation we use is introduced as needed. Here we note only that By(y, e) (respectively, by(y, e)) is the closed (respectively, open) ball in Y about y of radius e. If y = 0, we use By(e) and by(e), and we drop the subscript Y when there is no ambiguity. S(Y) is the unit sphere of the normed space Y. For isomorphic normed spaces X and Y, we let

$$d(X,Y) = \inf ||T|| ||T^{-1}||,$$

where the inf is over all invertible linear operators from X onto Y. Given a bounded Banach space valued function f on a set K, we set

$$\|f\|_{\infty} = \sup_{\mathbf{x} \in K} \|f(\mathbf{x})\|.$$

# 1. THE EXTENSION THEOREMS

We begin with the geometrical lemma mentioned in the introduction.

LEMMA 1. For each 1 > ~ <sup>&</sup>gt;0 there is a constant K = K(~) <sup>&</sup>gt;0 so that if <sup>n</sup>Act <sup>2</sup> , A= n for some n = 2, 3, ••. , then there is a mapping onto a subset of e~ (k \_ [K log n]) which satisfies f from A

$$\|\mathbf{f}\|_{\ell i p} \|\mathbf{f}^{-1}\|_{\ell i p} \le \frac{1+\tau}{1-\tau}$$
.

PROOF. The proof will show that if one chooses at random a rank k orthogonal <sup>n</sup>projection on *<sup>t</sup> <sup>2</sup> ,* then, with positive probability (which can be made arbitrarily close to one by adjusting k), the projection restricted to A will satisfy the condition on f. To make this precise, we let Q be the projection onto the first k coordinates of l~ and let cr be normalized Haar <sup>n</sup>measure on O(n), the orthogonal group on *<sup>t</sup> 2•* Then the random variable

$$f: (0(n), \sigma) \rightarrow L(\ell_2^n)$$

defined by

$$f(u) = U * QU$$

determines the notion of "random rank k projection." The applications of Levy's inequality in the first few self-contained pages of [2] make it easy to check that f(u) has the desired property. For the convenience of the reader,

we follow the notation of [2). Let I I 1•1 II denote the usual Euclidean norm on In and for 1 ~ k ~ n and x E In set

$$r(x) = r_k(x) = \sqrt{n} \begin{pmatrix} k \\ \Sigma \\ i = 1 \end{pmatrix}^{2}$$

which is equal to

vn IIIQxlll

fur our eventual choice of k which satisfies [K log n]. Thus r(•) is a semi-norm on

$$r(x) \leq \sqrt{n} ||x||| \qquad (x \in \ell_2^n).$$

(In [2], r(•) is assumed to be a norm, but inasmuch as the left estimate a! I !xi I I ~ r(x) in formula (2.5) of [2] is not needed in the present situation, it is okay that r(•) is only a semi-norm.)

Setting

$$B = \left\{ \frac{x - y}{|||x - y|||} : x, y \in A; x \neq y \right\} \subset S^{n-1},$$

we want to select U E O(n) so that for some constant M,

$$M(1-\tau) \leq r(Ux) \leq M(1+\tau) \quad (x \in B)$$

Let Mr be the median of r(•) n-1 on S , so that

$$\mu_{n-1}[x \in S^{n-1} : r(x) \ge M_r] \ge 1/2$$

and

$$\mu_{n-1}[x \in S^{n-1} : r(x) \le M_r] \le 1/2$$

n-1 where ~n-l is normalized rotationally invariant measure on S • n-1 We have from page 58 of [2] that for each y E S and *<sup>e</sup>*> 0,

$$\sigma[U \in O(n) : M_r - \sqrt{n} \epsilon \leq r(Uy) \leq M_r + \sqrt{n} \epsilon] \geq 1 - 4 \exp\left(\frac{-n\epsilon^2}{2}\right).$$

Hence

(1.1) 
$$\sigma[U \in O(n) : M_r - \sqrt{n} \epsilon \le r(Uy)) \le M_r + \sqrt{n} \epsilon \text{ for all } y \in B] \ge$$

$$\ge 1 - 2n(n+1) \exp \left(\frac{-n\epsilon^2}{2}\right).$$

By Lemma 1.7 of [2], there is a constant

$$C \le 4$$
  $\sum_{m=1}^{\infty}$   $(m+1) e^{-m^2/2}$ 

so that

(1.2) 
$$\left| \int\limits_{S_{n-1}} r(x) \ d\mu_{n-1}(x) - M_r \right| < C \ .$$

We now repeat a known argument for estimating *I* r(x) ~n-l(x) which uses only Khintchine's inequality. 8n-l

For 1 ::: k ::: n we have:

$$Av \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= Av \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= Av \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= Av \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= \sqrt{k} \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= \sqrt{k} \int_{1}^{\infty} \frac{1}{i} = 1$$

$$= \sqrt{k} \int_{1}^{\infty} \frac{1}{i} = 1$$
by the rotational invariance of  $\mu_{n-1}$ 

Setting

$$\alpha_n = \int_{S^{n-1}} |\langle x, \delta_1 \rangle| d\mu_{n-1}(x)$$
,

we have from Khintchine <sup>1</sup> s inequality that for each 1 ~ k ~ n,

$$\sqrt{nk} \alpha_n \le \int_{S^{n-1}} r_k(x) d\mu_{n-1}(x) \le \sqrt{2nk} \alpha_n$$

(l:e plugged in the exact constant of *VZ* in Khintchine's inequality calculated in [5] and [13], but of course any constant would serve as well.) Since obviously r (x) = y-n we conclude that for 1 ~ k ~ n n ,

(1.3) 
$$\sqrt{k/} \leq \int_{S^{n-1}} r_k(x) d\mu_{n-1}(x) \leq \sqrt{k}.$$

Specializing now to the case k that [K log n], we have from (1.2) and (1.3)

$$\sqrt{k/3} \leq M_r$$

at least for K log n sufficiently large. Thus if we define

$$\varepsilon = \tau \sqrt{k/3n}$$

we get from (1.1) that

$$\sigma [U \in O(n) : (1 - \tau)M_{r} \le r(Uy) \le (1 + \tau)M_{r} \text{ for all } y \in B]$$

$$\ge 1 - 2n(n + 1) \exp \left(-\frac{\tau^{2} k}{18}\right)$$

$$\ge 1 - 2n(n + 1) \exp \left(-\frac{\tau^{2} k \log n}{18}\right)$$

which is positive if, say,

$$K \ge (10/\tau)^2.$$

It is easily seen that the estimate K log n in Lemma 1 cannot be improved. Indeed, in a ball of radius 2 in e~ there are at most 4k vectors {xi} so that llxi - xj II 0:: 1 for every i *{<* j (see the proof of Lemma 3 below). Hence for 't" sufficiently small there is no map F which maps an <sup>k</sup>orthonormal set with more than 4 vectors into a k-dimensional subspace of *e2* with

$$\|\mathbf{F}\|_{\ell_{\mathbf{ip}}} \|\mathbf{F}^{-1}\|_{\ell_{\mathbf{ip}}} \leq \frac{1+\tau}{1-\tau}$$

We can now verify the conjecture of Marcus and Pisier [~0].

THEOREM 1. Sup  $(\log n)^{-1/2}L(\infty, n) < \infty$ . In other words: there is a  $n = 2, 3, \ldots$  constant K so that for all metric spaces X and all finite subsets M of X (card M = n, say) every function f from M into  $\ell_2$  has a Lipschitz extension f:  $X \rightarrow \ell_2$  which satisfies

$$\|\mathbf{f}\|_{\ell \mathbf{ip}} \leq \kappa \sqrt{\log n} \|\mathbf{f}\|_{\ell \mathbf{ip}}.$$

PROOF. Given X, M  $\subset$  X with card M = n, and f : M  $\rightarrow$   $\ell_2$ , set A = f [M]. We apply Lemma 1 with  $\tau$  = 1/2 to get a one-to-one function  $g^{-1}$  from A onto a subset  $g^{-1}[A]$  of  $\ell_2^k$  (where  $k \leq K \log n$ ) which satisfies

$$\|g^{-1}\|_{\ell ip} \le 1; \|g\|_{\ell ip} \le 3.$$

By Kirszbraun's theorem, we can extend g to a function  $\overset{\sim}{g}:\ell_2^k \to \ell_2$  in such a way that

$$\|\hat{g}\|_{\ell_{ip}} \leq 3$$
.

Let I :  $\ell_2^k \to \ell_\infty^k$  denote the formal identity map, so that

$$\|\mathbf{I}\| = 1$$
,  $\|\mathbf{I}^{-1}\| = \sqrt{k}$ .

Then

$$h = Ig^{-1}f$$
,  $h : M \rightarrow \ell_{\infty}^{k}$ 

has Lipschitz norm at most  $\|f\|_{\ell ip}$ , so by the non-linear Hahn-Banach theorem (see, e.g., p. 48 of [14]), h can be extended to a mapping

$$\hat{h}: X \to \ell_{\infty}^{k}$$

which satisfies

$$\|\hat{h}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le \|f\|_{\ell_{\mathbf{i}\mathbf{p}}}$$
.

Then

$$\int_{f}^{\infty} \int_{g}^{\infty} I^{-1} \int_{h}^{\infty} \int_{f}^{\infty} \cdot X + \ell_{2}$$

is an extension of f and satisfies

$$\|\mathbf{f}\|_{\ell \mathbf{i} \mathbf{p}} \le 3 \sqrt{\mathbf{k}} \|\mathbf{f}\|_{\ell \mathbf{i} \mathbf{p}} \le 3K \sqrt{\log n} \|\mathbf{f}\|_{\ell \mathbf{i} \mathbf{p}}.$$

Next we outline our approach to the problem of obtaining a lower bound for  $L(\infty,n)$ . Take for f the inclusion mapping from an  $\epsilon$ -net for  $S^{N-1}$  into  $\ell_2^N$ , and consider  $\ell_2^N$  isometrically embedded into  $L_\infty$ . A Lipschitz extension of f to a mapping  $\tilde{f}: L_\infty \to \ell_2$  should act like the identity  $\ell_2^N$ , so the techniques of [8] should yield a linear projection from  $L_\infty$  onto  $\ell_2^N$  whose norm is of order  $\|f\|_{\ell ip}$ . Since  $\ell_2^N$  is complemented in  $L_\infty$  only of order  $\sqrt{N}$  and there are  $\epsilon$ -nets for  $S^{N-1}$  of cardinality  $n \equiv [4/\epsilon]^N$ , we should get that

$$L(\infty,n) \ge \sqrt{N} \ge \delta \left(\frac{Log \ n}{-Log \ \epsilon}\right)^{1/2}$$
.

In Theorem 2 we make this approach work when  $\epsilon$  is of order  $N^{-2}$ , so we get

$$L(\infty,n) \geq \delta! \left(\frac{\text{Log } n}{\text{Log Log } n}\right)^{1/2}$$
.

That the difficulties we incur with the outlined approach for larger values of  $\epsilon$  are not purely technical is the gist of the following extension result.

(\*)THEOREM 2. Suppose that X is a metric space,  $A \subseteq X$ ,  $f: A \to \ell_2$  is Lipschitz and  $d(x,y) \ge \varepsilon > 0$  for all  $x \ne y \in A$ . Then there is an extension  $\widetilde{f}: X \to \ell_2$  of f so that

$$\|\mathbf{f}\|_{\ell_{\mathbf{ip}}} \leq \frac{6D}{\varepsilon} \|\mathbf{f}\|_{\ell_{\mathbf{ip}}}$$
,

where D is the diameter of A.

PROOF. We can assume by translating f that there is a point  $0 \in A$  so that f (0) = 0. Set  $B = A \sim \{0\}$  and define

F: 
$$A \to \ell_1^B$$
 by

F(b) = 
$$\begin{cases} \delta_b, & b \neq 0 \\ 0, & b = 0 \end{cases}$$

G:  $\ell_1^B \to \ell_2$ 

Define

by

$$G(\sum_{b \in B} \alpha_b \delta_b) = \sum_{b \in B} \alpha_b f (b) .$$

<sup>(\*)</sup> See the appendix for a generalization of Theorem 2 proved by Yoav Benyamini.

Then

$$\|G\| \le D \|f\|_{\ell_{\mathbf{ip}}}$$
, and  $\|F\|_{\ell_{\mathbf{ip}}} \le 2/\epsilon$ .

A weakened form of Grothendieck's inequality (see section 2.6 in [9]) yields that G (as any bounded linear operator from an  $L_1$  space into a Hilbert space) factors through an  $\ell_\infty(\mathcal{H})$  space:

$$G = H J, ||J|| = 1, ||H|| \le 3 ||G||,$$

$$J: \ell_1^B \to \ell_\infty(\mathcal{H}), H: \ell_\infty(\mathcal{H}) \to \ell_2.$$

By the non-linear Hahn-Banach Theorem the mapping JF has an extension

$$E: X \to \ell_{\infty}(X)$$
 which satisfies

$$\|\mathbf{E}\|_{\ell ip} \leq \|\mathbf{J} \mathbf{F}\|_{\ell ip} \leq 2/\epsilon$$
.

Then f = H E extends f and  $||f|| \le \frac{6D}{\varepsilon} ||f||_{\ell_{1}p}$ , as desired.

For the proof of Theorem 3, we need three well known facts which we state as lemmas.

LEMMA 2. Suppose that Y, X are normed spaces and  $f: S(Y) \to X$  is Lipschitz with f(0) = 0. Then the positively homogeneous extension of f, defined for  $y \in Y$  by

$$\tilde{f}$$
 (y) =  $\|y\| f(\frac{y}{\|y\|})$ , (y \neq 0);  $\tilde{f}$  (0) = 0

#### is Lipschitz and

$$\|\mathbf{f}\|_{\ell \mathbf{ip}} \leq 2 \|\mathbf{f}\|_{\ell \mathbf{ip}} + \|\mathbf{f}\|_{\infty}.$$

PROOF. Given  $y_1$ ,  $y_2 \in Y$  with  $0 < \|y_1\| \le \|y_2\|$ ,

$$\begin{split} \|\widetilde{\mathbf{f}}(\mathbf{y}_{1}) - \widetilde{\mathbf{f}}(\mathbf{y}_{2})\| &\leq \| \| \|\mathbf{y}_{1}\| \| \mathbf{f} \left( \frac{\mathbf{y}_{1}}{\|\mathbf{y}_{1}\|} \right) - \|\mathbf{y}_{2}\| \| \mathbf{f} \left( \frac{\mathbf{y}_{1}}{\|\mathbf{y}_{1}\|} \right) \| \| \| \| \| \| \| \| \| \| \| \| \| \| \| \| \| \|$$

$$\leq \|f\|_{\infty} \|y_{1} - y_{2}\| + \|f\|_{\ell \text{ip}} \left[ \left( \frac{\|y_{2}\|}{\|y_{1}\|} - 1 \right) \|y_{1}\| + \|y_{1} - y_{2}\| \right]$$

$$\leq \left(\|f\|_{\infty} + 2\|f\|_{\ell ip}\right) \|y_1 - y_2\|.$$

LEMMA 3. If y is an n-dimensional Banach space and 0 < e, then S(Y) admits an e-net of cardinality at most (1 + 4/e)n.

PROOF. Let M be a subset of S(Y) maximal with respect to "1/x-yll ::: e for all X# y E M".

Then the sets

b(y, 
$$\varepsilon/2$$
)  $\cap$  S(Y), (y  $\in$  M)

are pairwise disjoint hence so are the sets

$$b(y, \varepsilon/4), (y \in M).$$

Since these last sets are all contained in b(l + e/4), we have that

card M • vol 
$$b(\epsilon/4) \le vol b(1 + \epsilon/4)$$

so that

card 
$$M \le \left[\frac{4}{\epsilon} (1 + \epsilon/4)\right]^n$$
.

LEMMA 4. There is a constant o > 0 so that for each 1 ~ p < 2 and each N = 1, 2, ••• ' L <sup>p</sup> contains a subspace E such that

$$d(E, \ell_2^N) \leq 2$$

and every projection from L onto E has norm at least p 0 N 1/p - 1/2 •

PROOF. Given a finite dimensional Banach space X and 1 ~ p < ~. let

$$\gamma_{p}(x) = \inf \{ \|T\| \|S\| : T : X \to L_{p}, S:L_{p} \to X, S:T = I_{X} \}$$

So y~(X) is the projection constant of X, hence by [4], [12]

$$\gamma_1(\ell_2^N) = \gamma_\infty(\ell_2^N) = \sqrt{2n/\pi}$$

This gives the p 1 case.

For 1 < p < 2 we reduce to the case p = 1 by using Example 3.1 of [2), which asserts that there is a constant C < .. so that for 1 :::: p < 2 *l* CN contains a subspace E with d(E, l~):::: 2. Since, obviously, P

$$d(\ell_p^{CN}, \ell_1^{CN}) \leq (CN)^{1-1/p}$$

we get that if E is K-complemented in then

$$\pi^{-1/2} (2n)^{1/2} = \Upsilon_1(\ell_2^N) \le d(E, \ell_2^N) d(\ell_p^{CN}, \ell_1^{CN}) K$$

$$\le 2 (CN)^{1 - 1/p} K.$$

The next piece of background information we need for Theorem 3 is a linearization result which is an easy consequence of the results in [8].

PROPOSITION 1. Suppose X c Y and Z are Banach spaces, f : Y ~ z is Lipschitz, and U: x~ Z is\_bounded, linear. Then there is a linear operator G : Z\* ~ Y\* so that II Gil :::: II fll •. and "J.P --

$$\|R_2 G - U*\| \le \|f_{X} - U\|_{\ell_{ip}}$$

where R2 is the natural restriction map from Y\* onto X\*.

REMARK. Note that if Z is reflexive, the mapping F = G\*ly IIFII :::: lltlllip and IIFix- ull :::: llflx- ulllip' Y ~ Z satisfies

PROOF. We first recall some notation from [8). If Y is a Banach space, Y# *II* denotes the Banach space of all scalar valued Lipschitz functions y from Y for which /(O) = 0, with the norm 11/llli . There is an obvious isometric \* # p inclusion from Y into Y . For a Lipschitz mapping f : Y ~ Z, Z a normed space, we can define a linear mapping

$$f^{\#}: Z^{*} \to Y^{\#}$$
 by  $f^{\#}z^{*} = z^{*}f$ .

Given Banach spaces X c Y, Theorem 2 of [8] asserts that there are norm one linear projections

$$P_{Y}: Y^{\#} \rightarrow Y^{*}, \quad P_{X}: X^{\#} \rightarrow X^{*}$$

so that

$$P_X R_1 = R_2 P_Y$$

where *<sup>I</sup>*# R1 is the restriction mapping from Y onto X • Thus if X c Y, f, u, Z are as in the hypothesis of Proposition 1, the linear mapping <sup>P</sup>*i <sup>1</sup>*satisfies y

$$\|P_{Y} f^{\#}\| \le \|f\|_{\ell_{1D}}, R_{2} P_{Y} f^{\#} = P_{X} R_{1} f^{\#}.$$

Since U: X~ Z is linear,

$$U^* = P_X U^{\#}$$

X

so

$$\|R_{2} P_{Y} f^{\#} - U^{*}\| = \|P_{X}(R_{1}f^{\#} - U^{\#})\|$$

$$\leq \|R_{1} f^{\#} - U^{\#}\| = \sup_{z^{*} \in S(Z^{*})} \|R_{1} f^{\#} z^{*} - U^{\#} z^{*}\|$$

$$z^{*} \in S(Z^{*})$$

$$= \sup_{z^{*} \in S(Z^{*})} \|(z^{*} f)|_{X} - z^{*} U\| \leq \|f|_{X} - U\|_{\ell_{1}p}.$$

The final lemma we use in the proof of Theorem 3 is a smoothing result for homogeneous Lipschitz functions.

LEMMA 5. Suppose X c Y and Z are Banach spaces with dim X = k < ~. F: Y ~ <sup>Z</sup>is Lipschitz with F positively homogeneous (i.e. F(Ay) = A F(y) for A~ 0, y E Y) and U: x~ Z is linear. Then there is a positively homogeneous Lipschitz mapping

$$\tilde{F}: Y \to Z$$
 which satisfies

$$(1) \quad \|\widetilde{\mathbf{F}}_{|\mathbf{X}} - \mathbf{U}\|_{\ell_{\mathbf{1P}}} \leq (8k + 2) \quad \|\mathbf{F}_{|\mathbf{S}(\mathbf{X})} - \mathbf{U}_{|\mathbf{S}(\mathbf{X})}\|_{\infty}$$

(2) 
$$\|\tilde{\mathbf{F}}\|_{\ell \mathbf{ip}} \leq 4 \|\mathbf{F}\|_{\ell \mathbf{ip}}$$
.

PROOF. For y E S(Y) define

$$\hat{F}y = \int_{B_{\mathbf{Y}}(1)} F(y+x) d\mu(x)$$

X where ~(·) is Haar measure on X (~IRk) normalized so that

$$\mu(B_{X}(1)) = 1$$

For y1, y2 E S(Y) we have

$$\|\hat{\mathbf{f}}\mathbf{y}_{1} - \hat{\mathbf{f}}\mathbf{y}_{2}\| \le \int_{\mathbf{B}_{X}(1)} \|\mathbf{F}(\mathbf{y}_{1} + \mathbf{x}) - \mathbf{F}(\mathbf{y}_{2} + \mathbf{x})\| d\mu(\mathbf{x})$$
  
 $\le \|\mathbf{F}\|_{\ell \mathbf{1} \mathbf{p}} \|\mathbf{y}_{1} - \mathbf{y}_{2}\|$ 

so

$$\|\hat{\mathbf{f}}\|_{\ell ip} \leq \|\mathbf{f}\|_{\ell ip}$$

For x1 , x2 E S(X) with /lx1 - x211 = o > 0 we have, since U is linear, that

$$\|(\hat{F} - U)x_1 - (\hat{F} - U)x_2\| =$$

$$\|\int_{B_X(1)} F(x_1 + x) d\mu(x) - \int_{B_X(1)} U(x_1 + x) d\mu(x) - \int_{B_X(1)} F(x_2 + x) d\mu(x) +$$

$$\int_{B_X(1)} U(x_2 + x) d\mu(x)\| \le$$

$$\le \int_{B_X(1)} F(x_1 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) \le \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x) d\mu(x) = \int_{B_X(1)} F(x_2 + x$$

$$\leq \sup_{\mathbf{x} \in B_{\mathbf{X}}(2)} \| \mathbf{F} \mathbf{x} - \mathbf{U} \mathbf{x} \| \mu [\mathbf{B}_{\mathbf{X}}(\mathbf{x}_{1}; 1) \Delta \mathbf{B}_{\mathbf{X}}(\mathbf{x}_{2}; 1)]$$

$$= 2 \sup_{\mathbf{x} \in B_{\mathbf{X}}(\mathbf{1})} \| \mathbf{F}\mathbf{x} - \mathbf{U}\mathbf{x} \| \ \mu \ [\mathbf{B}_{\mathbf{X}}(\mathbf{x}_{\mathbf{1}}; \ \mathbf{1}) \ \Delta \ \mathbf{B}_{\mathbf{X}}(\mathbf{x}_{\mathbf{2}}; \ \mathbf{1})]$$
 since F is positively homogeneous

Since

$$B_{X}(x_{1}; 1) \land B_{X}(x_{2}; 1) \subset [B_{X}(x_{1}; 1) \sim B_{X}(x_{1}; 1-\delta)] \cup [B_{X}(x_{2}; 1) \sim B_{X}(x_{2}; 1-\delta)]$$

we have if o ::: 1 that

$$\mu[B_{\chi}(x_2; 1) \land B_{\chi}(x_2; 1)] \le 2[1 - (1-\delta)^k]$$

$$\le 2 k \delta$$

and hence for all x1 , x2 E S(X) that

$$\|(\hat{F} - U) \times_1 - (\hat{F} - U) \times_2\| \le 4k \|F_{|S(X)} - U_{|S(X)}\| \|x_1 - x_2\|$$

whence

$$\|\hat{\mathbf{f}}\|_{S(X)} - \mathbf{U}\|_{S(X)}\|_{\ell_{\mathbf{ip}}} \le 4k \|\mathbf{F}\|_{S(X)} - \mathbf{U}\|_{S(X)}\|_{\infty}.$$

Finally, note that the positive homogeniety of F implies that

$$\|\hat{\mathbf{f}}\|_{\infty} \le 2 \|\mathbf{F}\|_{\ell ip} \quad \text{and} \quad \|\hat{\mathbf{f}}\|_{S(X)} - \mathbf{U}_{S(X)}\|_{\infty} \le 2 \|\mathbf{F}\|_{S(X)} - \mathbf{U}_{S(X)}\|_{\infty}.$$

It now follows from Lemma 2 that the positively homogeneous extension  $\tilde{F}$  of  $\tilde{F}$  satisfies the conclusions of Lemma 5.

THEOREM 3. There is a constant  $\tau > 0$  so that for all  $n = 2, 3, 4, \ldots$  and all  $1 \le p < 2$ ,

$$L(p,n) \geq \tau \left(\frac{\text{Log } n}{\text{Log Log } n}\right)^{1/p - 1/2}.$$

REMARK. Since  $L(\infty,n) \ge L(1,n)$ , we get the lower estimate for  $L(\infty,n)$  mentioned in the introduction.

PROOF. Given p and n, for a certain value of N = N(n) to be specified later choose a subspace E of L with d(E,  $\ell_2^N$ )  $\leq$  2 and E only  $\delta$  N  $^{1/p}$  -  $^{1/2}$ -complemented in L (Lemma 4). For a value  $\epsilon$  =  $\epsilon$ (n) > 0 to be specified later, let A be a minimal  $\epsilon$ -net of S(E), so, by Lemma 3,

card 
$$A \leq (1 + 4/\epsilon)^{N}$$
.

One relation among n, N,  $\epsilon$  we need is

(1.4) 
$$(1 + 4/\epsilon)^{N} + 1 \leq n.$$

Let  $f:A\cup\{0\}\to E$  be the identify map. Since  $d(E,\ell_2^N)\le 2$ , we can by Lemma 2 get a positively homogeneous extension  $\tilde{f}:L_D\to E$  of f so that

$$\|\tilde{f}\|_{\ell ip} \le 6 L(p,n)$$
.

Since  $\tilde{f}(a) = f(a) = a$  for  $a \in A$  and A is an  $\epsilon$ -net for S(E), we get that for  $x \in S(E)$ ,

$$\|\mathbf{f}(\mathbf{x}) - \mathbf{x}\| \le (6 L(\mathbf{p}, \mathbf{n}) + 1) \varepsilon.$$

Therefore, from Lemma 5 we get a Lipschitz mapping  $\hat{f}: L_p \to E$  which satisfies

$$\|\hat{\mathbf{f}}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le 24 \ L(\mathbf{p},\mathbf{n})$$

(1.5) 
$$\|\hat{f}_{|E} - I_{E}\| \le (8N + 2)(6 L(p,n) + 1)\epsilon.$$

Note that if

$$(1.6) (8N + 2)(6 L(p,n) + 1)\varepsilon \le 1/2.$$

(1.5) implies that there is a linear projection from  $L_p$  onto E with norm at most  $48 \ L(p,n)$ , so we can conclude that

$$L(p,n) > \delta/48 N^{1/p} - 1/2$$

Finally, we just need to observe that (1.4) and (1.6) are satisfied (at least for sufficiently large n) if we set

$$\varepsilon = \text{Log}^{-2} \text{ n}, \quad N = \frac{\text{Log n}}{2 \text{ Log Log n}}.$$

#### 2. OPEN PROBLEMS.

Besides the obvious question left open by the preceding discussion (i.e. whether the estimate for  $L(\infty,n)$  given in Theorem 1 is indeed the best possible), there are several other problems which arise naturally in the present context. We mention here only some of them.

PROBLEM 1. Is it true that for  $1 , every subset X of L (0,1), and every Lipschitz map f from X into <math>\ell_2^k$  there is an extension f of f from L (0,1) into  $\ell_2^k$  with

(2.1) 
$$\|\tilde{f}\|_{\ell ip} \le C(p) \|f\|_{\ell ip} k^{1/p} - 1/2$$

### where C(p) depends only on p?

A positive answer to problem 1 combined with Lemma 1 above will of course provide an alternative proof to the result of Marcus and Pisier [10] mentioned in the introduction. The linear version of problem 1 (where X is a subspace and f a linear operator) is known to be true (cf. [7] and [3]).

PROBLEM 2. What happens in the Marcus-Pisier theorem if  $2 ? Is the Lipschitz analogue of Maurey's extension theorem [11] (cf. also [3]) true? In other words, is it true that for <math>2 there is a c(p) such that for every Lipschitz map f from a subset X of L<sub>p</sub>(0,1) into <math>\ell_2$  there is a Lipschitz extension f from L<sub>p</sub>(0,1) into  $\ell_2$  with

$$\|\tilde{\mathbf{f}}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le c(\mathbf{p}) \|\mathbf{f}\|_{\ell_{\mathbf{i}\mathbf{p}}}$$
?

PROBLEM 3. What are the analogues of Lemma 1 in the setting of Banach spaces different from Hilbert spaces? The most interesting special case seems to be concerning the spaces  $\ell_{\infty}^n$ . It is well known that every finite metric space  $X = \{x_i\}_{i=1}^n$  embeds isometrically into  $\ell_{\infty}^n$  (the point  $x_i$  is mapped to the n-tuple  $\{d(x_1, x_i), d(x_2, x_i), \ldots, d(x_n, x_i)\}$  in  $\ell_{\infty}^n$ ). Hence in view of Lemma 1 it is quite natural to ask the following. Does there exist for all  $\epsilon > 0$  (or alternatively for some  $\epsilon > 0$ ) a constant  $K(\epsilon)$  so that for every metric space X with cardinality n there is a Banach space Y with dim  $Y \leq K(\epsilon) \log n$  and a map f from X into Y so that

A weaker version of Problem 3 is

PROBLEM 4. It is true that for every metric space X with cardinality n there is a subset  $\tilde{X}$  in  $\ell_2$  and a Lipschitz map F from X onto  $\tilde{X}$  so that (2.2)  $\|F\|_{\ell \text{ip}} \|F^{-1}\|_{\ell \text{ip}} \leq K \sqrt{\log n}$ 

for some absolute constant K?

Since for every Banach space Y with dim Y = k we have  $d(Y, \ell_2^k) \le \sqrt{k}$  (cf. [6]) it is clear that a positive answer to problem 3 implies a positive answer to problem 4. V. Milman pointed out to us that it follows easily from an inequality of Enflo (cf. [1]) that (2.2), if true, gives the best possible estimate. (In the notation of [1], observe that the "m-cube"

$$\mathbf{x}_{\theta} = (\theta_1, \theta_2, \dots, \theta_m) (\theta \in \{-1, 1\}^m)$$

in  $\ell_1^{\rm m}$  has all "diagonals" of length 2m and all "edges" of length 2, so that if F is any Lipschitz mapping from these  $2^{\rm m}$  points in  $\ell_1^{\rm m}$  into a Hilbert space, the corollary in [1] implies that

$$\|F\|_{\ell ip} \|F^{-1}\|_{\ell ip} \ge m^{1/2}$$
.)

#### 3. APPENDIX.

After this note was written, Yoav Benyamini discovered that Theorem 2 remains valid if  $\ell_2$  is replaced with any Banach space. He kindly allowed us to reproduce here his proof. The main lemma Benyamini uses is:

LEMMA 6. Let  $\Gamma$  be an indexing set and let  $\{e_{\gamma}^{\}}_{\gamma} \in \Gamma$  be the unit vector basis for  $c_{0}(\Gamma)$ . Set

$$A = \{\alpha \in_{\gamma} : 0 \le \alpha \le 1; \gamma \in \Gamma\}$$

$$B = \overline{\text{conv }} A \text{ (= positive part of } B_{\ell_1}(\Gamma)\text{)}.$$

Then

- (i) there is IIGIIlip ~2 a retraction G from *e .. <n* onto B which satisfies
- (ii) there is a mappin~ H from *l* co (r) .into A which satisfies IIHIIlip ~ 4 and He = e for all *<sup>y</sup>*Er. *y y*

+ PROOF. Since the mapping x ~ x is a. contractive retraction from lco(r) onto its positive cone, lco(r)+; to prove (i) it is enough to define G only on *l* (r)+. co + For y E lco(f) , let

$$g(y) = \inf \{t : ||(y - te)^{+}||_{1} \le 1\}$$

where e E lco(r) is the function identically equal to one and 1/·11 1 is the usual norm in <sup>t</sup> <sup>1</sup> (r). Clearly the inf is actually a minimum and 0 ~ g(y) ~ IIYIIco. Note that

$$|g(y) - g(z)| \leq ||y-z||_{\infty}$$
.

Indeed, assume that g(y) ~ g(z). Then

$$y - [g(z) + ||y-z||_{m} e] \le y - g(z)e + z - y \le z - g(z)e$$

and hence

$$\|(y-[g(z) + \|y-z\|_{\infty}]e)^{+}\|_{1} \le 1;$$

that is

$$g(y) \leq g(z) + ||y-z||_{\infty}.$$

<sup>+</sup>Now set for y E eco(r)

$$G(y) = (y - g(y)e)^{+}.$$

To prove (ii), it is enough, in view of (i), to define H on B with IIHIB"eip ~ 2. For y E B, y = {y(y)}y E r· defined Hy by

$$Hy(\gamma) = (2y(\gamma) - 1)^{+}.$$

For  $y \in B$ , there is at most one  $\gamma \in \Gamma$  for which  $y(\gamma) > \frac{1}{2}$ , hence  $HB \subset A$ . Evidently  $He_{\gamma} = e_{\gamma}$  for  $\gamma \in \Gamma$  and  $\|H_{B}\|_{\ell ip} \leq 2$ .

THEOREM 2 (Y. Benyamini). Suppose that X is a metric space, Y is a subset of X with  $d(x,y) \ge \epsilon > 0$  for all  $x \ne y \in Y$ , Z is a Banach space, and  $f: Y \rightarrow Z$  is Lipschitz. Then there is an extension  $f: X \rightarrow Z$  of f so that

$$\|\hat{\mathbf{f}}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le (4\mathbf{p}/\epsilon)\|\mathbf{f}\|_{\ell_{\mathbf{i}\mathbf{p}}}$$

where D is the diameter of Y.

PROOF. Represent

$$Y = \{0\} \cup \{y_{\gamma} : \gamma \in \Gamma\}$$

and assume, by translating f, that f(0) = 0. We can factor f through the subset  $C = \{0\} \cup \{e_{\gamma} : \gamma \in \Gamma\}$  of  $\ell_{\infty}(\Gamma)$  by defining  $g : Y \to C$ ,  $h : C \to Z$  by

$$g(y_{\gamma}) = e_{\gamma}, g(0) = 0$$
  
 $h(e_{\gamma}) = f(y_{\gamma}), h(0) = 0.$ 

Evidently,

$$\|\mathbf{g}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le 1/\epsilon$$
,  $\|\mathbf{h}\|_{\ell_{\mathbf{i}\mathbf{p}}} \le \mathbf{D}\|\mathbf{f}\|_{\ell_{\mathbf{i}\mathbf{p}}}$ .

By the non-linear Hahn-Banach theorem, g has an extension to a function  $\tilde{g}: X \to \ell_{\infty}(\Gamma)$  with  $\|\tilde{g}\|_{\ell i p} = \|g\|_{\ell i p}$ , so to complete the proof, it suffices to extend h to a function  $\tilde{h}: B \to Z$  with  $\|\tilde{h}\|_{\ell i p} = \|h\|_{\ell i p}$  and apply Lemma 6(ii).

Define for  $0 \le t \le 1$  and  $\gamma \in \Gamma$ 

$$h(te_{\gamma}) = th(e_{\gamma}).$$

If  $1 \ge t \ge s \ge 0$  and  $\gamma \ne \Delta \in \Gamma$  then

$$\begin{split} \| \overset{\sim}{h} (t e_{\gamma}) &- \overset{\sim}{h} (s e_{\Delta}) \| \leq (t-s) \| h(e_{\gamma}) \| + s \| h(e_{\Delta}) - h(e_{\gamma}) \| \\ &\leq (t-s) \| h \|_{\ell i p} + s \| h \|_{\ell i p} = \| h \|_{\ell i p} \| t e_{\gamma} - s e_{\Delta} \|_{\infty}, \end{split}$$

so 
$$\|\hat{\mathbf{h}}\|_{\ell \text{ip}} = \|\mathbf{h}\|_{\ell \text{ip}}$$
.

#### REFERENCES

- 1. P. Enflo, On the non-existence of uniform homeomorphisms between L spaces, Arkiv for Matematik 8 (1969), 195-197.
- 2. T. Figiel, J. Lindenstrauss and V. Milman, The dimension of almost spherical sections of convex bodies, Acta. Math. 139 (1977), 53-94.
- 3. T. Figiel and N. Tomczak-Jaegermann, Projections onto Hilbertian subspaces of Banach spaces, Israel J. Math 33 (1979), 155-171.
- 4. D. J. H. Garling and Y. Gordon, Relations between some constants associated with finite-dimensional Banach spaces, Israel J. Math 9 (1971), 346-361.
- 5. U. Haagerup, The best constant in the Khintchine inequality, Studia Math 70 (1982), 231-283.
- F. John, Extremum problems with inequalities as subsidiary conditions, <u>Courant anniversary volume</u>, Interscience N.Y. (1948), 187-204.
- 7. D. Lewis, Finite dimensional subspaces of  $L_p$ , Studia Math. <u>63</u> (1978), 207-212.
- 8. J. Lindenstrauss, On non-linear projections in Banach spaces, Mich. Math. J. 11 (1964), 263-287.
- 9. J. Lindenstrauss and L. Tzafriri, Classical Banach spaces Vol. I sequence spaces, Ergebnisse n. 92, Springer Verlag, 1977.
- 10. M. B. Marcus and G. Pisier, Characterizations of almost surely continuous p-stable random Fourier series and strongly stationary processes, to appear.
- B. Maurey, Un theoreme de prolongment, C. R. Acad. Paris <u>279</u> (1974), 329-332.
- 12. D. Rutovitz, some parameters associated with finite dimensional Banach spaces, J. London Math. Soc. 40 (1965), 241-255.
- 13. S. J. Szarek, On the best constant in the Khintchine inequality, Studia Math. 58 (1978), 197-208.
- 14. J. H. Wells and L. R. Williams, Embeddings and Extensions in Analysis, Ergebnisse n. <u>84</u> Springer Verlag 1975.

William B. Johnson The Ohio State University and Texas A & M University

Joram Lindenstrauss The Hebrew University of Jerusalem, Texas A & M University, and The Ohio State University