![](_page_0_Picture_0.jpeg)

# **Nearest-Neighbor-Preserving Embeddings**

PIOTR INDYK

*MIT*

AND

ASSAF NAOR

*Microsoft Research*

Abstract. In this article we introduce the notion of nearest-neighbor-preserving embeddings. These are randomized embeddings between two metric spaces which preserve the (approximate) nearestneighbors. We give two examples of such embeddings for Euclidean metrics with low "intrinsic" dimension. Combining the embeddings with known data structures yields the best-known approximate nearest-neighbor data structures for such metrics.

Categories and Subject Descriptors: F.2.2 [**Analysis of Algorithms and Problem Complexity**]: Nonnumerical Algorithms and Problems

General Terms: Algorithms, Theory

Additional Key Words and Phrases: Nearest neighbor, dimensionality reduction, embeddings, doubling spaces

### **ACM Reference Format:**

Indyk, P., and Naor, A. 2007. Nearest-neighbor-preserving embeddings. ACM Trans. Algor. 3, 3, Article 31 (August 2007), 12 pages. DOI = 10.1145/1273340.1273347 http://doi.acm.org/10.1145/ 1273340.1273347

# 1*. Introduction*

The nearest-neighbor problem is defined as follows: Given a set *X* of points in R*<sup>d</sup>* , build a data structure which, given any *q* ∈ R*<sup>d</sup>* , quickly reports the point in *X* that is (approximately) closest to *q*. This problem and its approximate versions are some of the central problems in computational geometry.

The first author was supported in part by NSF ITR Grant CCR-0220280, a David and Lucille Packard Fellowship, and an Alfred P. Sloan Fellowship.

Authors' addresses: P. Indyk, Department of Electrical Engineering and Computer Science, Massachusetts Institute of Technology, 77 Massachusetts Avenue, Cambridge, MA 02139-4307; A. Naor (current address), Courant Institute of Mathematical Sciences, New York University, 251 Mercer Street, New York, NY 10012, e-mail: naor@cims.nyu.edu.

Permission to make digital or hard copies of part or all of this work for personal or classroom use is granted without fee provided that copies are not made or distributed for profit or direct commercial advantage and that copies show this notice on the first page or initial screen of a display along with the full citation. Copyrights for components of this work owned by others than ACM must be honored. Abstracting with credit is permitted. To copy otherwise, to republish, to post on servers, to redistribute to lists, or to use any component of this work in other works requires prior specific permission and/or a fee. Permissions may be requested from Publications Dept., ACM, Inc., 2 Penn Plaza, Suite 701, New York, NY 10121-0701 USA, fax +1 (212) 869-0481, or permissions@acm.org.

<sup>C</sup> 2007 ACM 1549-6325/2007/08-ART31 \$5.00 DOI 10.1145/1273340.1273347 http://doi.acm.org/ 10.1145/1273340.1273347

Since the late 1990's, it has become apparent that designing efficient approximate nearest-neighbor algorithms, at least for high-dimensional data, is closely related to the task of designing low-distortion embeddings. A bi-Lipschitz embedding between two metric spaces  $(X, d_X)$  and  $(X', d'_{X'})$  is a mapping  $f: X \to X'$  such that for some scaling factor C > 0, for every  $p, q \in X$  we have  $Cd_X(p, q) \le d'_{X'}(f(p), f(q)) \le DCd_X(p, q)$ , where the parameter  $D \ge 1$  called the distortion of f. Of particular importance, in the context of approximate nearest-neighbors, are low-distortion embeddings that map  $X \subseteq \mathbb{R}^d$  into  $\mathbb{R}^k$ , where k is much smaller than d. For example, a well-known theorem of Johnson and Lindenstrauss [1984] guarantees that for any set  $X \subseteq \mathbb{R}^d$ , there is a  $(1 + \varepsilon)$ -distortion embedding of  $(X, \| \cdot \|_2)$  into  $(\mathbb{R}^k, \| \cdot \|_2)$  for  $k = O(\log |X|/\varepsilon^2)$ . This embedding and its variants have been utilized, for example, in Indyk and Motwani [1998] and Kushilevitz et al. [1998] to give efficient approximate nearest-neighbor algorithms in high-dimensional spaces.

More recently (e.g., in Indyk [2000]), it has been realized that the approximate nearest-neighbor problem requires embedding properties that are somewhat different from the preceding definition. One (obvious) difference is that the embedding must be *oblivious* to X, that is, well-defined over the whole space  $\mathbb{R}^d$ , not just the input data points X. This is because, in general, a query point  $q \in \mathbb{R}^d$  does not belong to X. The aformentioned Johnson-Lindenstrauss lemma indeed satisfies this (stronger) property. The second difference is that the embedding does not need to preserve *all* interpoint distances. Instead, it suffices that the embedding f is randomized, and satisfies the following definition.

Definition 1.1. Let  $(Y, d_Y)$ ,  $(Z, d_Z)$  be metric spaces and  $X \subseteq Y$ . We say that a distribution over mappings  $f: Y \to Z$  is a nearest-neighbor-preserving embedding (or NN-preserving) with distortion  $D \ge 1$  and probability of correctness<sup>2</sup>  $P \in [0,1]$  if for every  $c \ge 1$  and any  $q \in Y$ , with probability at least P, if  $x \in X$  is such that f(x) is a c-approximate nearest-neighbor of f(q) in f(X) (i.e.,  $d(f(q), f(x)) \le c \cdot d(f(q), f(X))$ ), then x is a  $D \cdot c$ -approximate nearest-neighbor of q in X.

This notion is the appropriate generalization of oblivious embeddings à la Johnson and Lindenstrauss: We want f to be defined on the entire space of possible query points Y, and we require much less than a bi-Lipschitz condition. Clearly, the Johnson-Lindenstrauss theorem is an example of an NN-preserving embedding. Another example of such a mapping is a (weak) dimensionality reduction in  $\ell_1$ -norm, given in Indyk [2000]. It maps  $(\mathbb{R}^d, \|\cdot\|_1)$  into  $(\mathbb{R}^k, \|\cdot\|_1)$ , where k is much smaller than d, and guarantees that, for any pair of points, the probability that the distance between the pair gets contracted is "very small", while the probability of the distance being expanded by a is at most 1/2. It is easy to see that such mapping is a-NN-preserving. At the same time, the standard dimensionality reduction in  $\ell_1$  (that preserves all distances) is probably impossible [Brinkman and Charikar 2003; Lee and

<sup>&</sup>lt;sup>1</sup>If we consider the approximate *near*-neighbor problem, that is, the decision version of the approximate nearest-neighbor, then the constraints that an embedding needs to satisfy are even weaker. Also, it is known [Indyk and Motwani 1998; Har-Peled 2001] that the approximate nearest-neighbor can be reduced to its decision version. However, such reductions are nontrivial and introduce certain overhead in the query time and space. Thus, it is beneficial that the embedding preserves the approximate nearest-neighbor, not just the near neighbor.

<sup>&</sup>lt;sup>2</sup>Whenever P is not specified, it is assumed to be equal to 1/2.

Naor 2004]. Thus, the definition of NN-preserving embeddings allows us to overcome the impossibility results for the stronger notion of bi-Lipschitz embeddings, while being sufficient for the purpose of nearest-neighbor and related problems.

In this article, we initiate a systematic study of NN-preserving embeddings into low-dimensional spaces. In particular, we prove that such embeddings exist for the following subsets X of the Euclidean space ( $\mathbb{R}^d$ ,  $\|\cdot\|_2$ ):

(1) Doubling sets. The doubling constant of X, denoted  $\lambda_X$ , is the smallest integer  $\lambda$  such that for any  $p \in X$  and r > 0, the ball B(p, r) (in X) can be covered by at most  $\lambda$  balls of radius r/2 centered at points in X. It is also convenient to define the doubling dimension of X to be  $\log \lambda_X$  (this terminology is used in Gupta et al. [2003]). See Clarkson [2005] for a survey of notions of dimension which are relevant to nearest-neighbor search.

We give, for any  $\varepsilon > 0$ ,  $\delta \in (0, 1/2]$ , a randomized mapping  $f : \mathbb{R}^d \to \mathbb{R}^k$  that is  $(1+\varepsilon)$ -NN-preserving for X, with probability of correctness  $1-\delta$ , where

$$k = O\left(\frac{\log(1/\varepsilon)}{\varepsilon^2} \cdot \log(1/\delta) \cdot \log \lambda_X\right).$$

(2) Sets with small aspect ratio and small  $\gamma$ -dimension. Consider sets X of diameter 1. The aspect ratio of X,  $\Delta$ , is the inverse of the smallest interpoint distance in X. The  $\gamma$ -dimension of X, which is a natural notion motivated by the theory of Gaussian processes, is defined in Section 2. Here we just state that  $\gamma(X) = O(\sqrt{\log \lambda_X})$  for all X.

We give, for any  $\varepsilon > 0$ , a randomized mapping  $f : \mathbb{R}^d \to \mathbb{R}^k$  that is  $(1+\varepsilon)$ -NN-preserving for X, where  $k = O(\Delta^2 \gamma^2 / \varepsilon^2)$ .

Although quadratic dependence of the dimension on  $\Delta$  might seem excessive, there exist natural high-dimensional datasets with (effectively) small aspect ratios. For example, in the MNIST dataset (investigated, e.g., in Andoni et al. [2005]), for all but 2% of points, the distances to nearest neighbors lie in the range [0.19, 0.72].

The preceding two results are not completely disjoint. This is because for metrics with constant aspect ratio, the  $\gamma$ -dimension and doubling dimension coincide up to constant factors. However, this is not the case for  $\Delta = \omega(1)$ .

Our investigation here is related to the following open problem in metric geometry: Is it true that doubling subsets of  $\ell_2$  embed bi-Lipschitzly into low-dimensional Euclidean space? (see Section 4 for a precise formulation). This question is of great theoretical interest, but it is also clear that a positive answer to it will have algorithmic applications. Our result shows that for certain purposes such as nearest-neighbor search, a weaker notion of embedding suffices and provably exists. It is worth noting that while our nearest-neighbor-preserving mapping is linear, a bi-Lipschitz embedding of a doubling Euclidean metric into a low-dimensional Euclidean space cannot be in general linear (this is discussed in Section 4).

*Algorithmic Implications*. Our NN-preserving embeddings naturally have immediate applications to efficient approximate nearest-neighbor problems.

Our first application combines NN-preserving embeddings with efficient  $(1+\varepsilon)$ -approximate nearest-neighbor data structures in Euclidean space  $(\mathbb{R}^k, \|\cdot\|_2)$  [Har-Peled 2001; Arya and Malamatos 2002], which use  $O(|X|/\varepsilon^k)$  space and have  $O(k \log(|X|/\varepsilon))$  query time (recall that we guarantee  $k = O(\log \lambda_X \log(1/\varepsilon)/\varepsilon^2)$ ,

and that we need to add O(dk) to the query time to account for the time needed to embed the query point). This results in a very efficient  $(1+\varepsilon)$ -approximate nearest-neighbor data structure. For comparison, the data structure of Krauthgamer and Lee [2004], which works for *general* metrics, suffers from query time exponential in  $\log \lambda_X$ . For the case of subsets of  $(\mathbb{R}^d, \| \cdot \|_2)$  (which we consider here), their data structure can be made faster [Krauthgamer and Lee, personal communication] by using the fast approximate nearest-neighbor algorithm of Indyk and Motwani [1998] and Kushilevitz et al. [1998] as a subroutine. In particular, the query time becomes roughly  $O(dk+k\cdot\log\Delta)$  and the space  $O(|X|/\varepsilon^k)$ . However, unlike in our case, the query time of their algorithm depends on the aspect ratio  $\Delta$ . Since for any X we have that  $\lambda_X \leq |X|$ , it follows that our algorithm always uses space  $|X|^{O([\log(1/\varepsilon)/\varepsilon]^2)}$  and has query time  $O(d\log|X|\log(1/\varepsilon)/\varepsilon^2)$ . Thus, our algorithm almost matches the bounds of the algorithm of Indyk and Motwani [1998], while being more general.

Our second application involves approximate nearest-neighbor where the dataset consists of objects that are more complex than points. Specifically, we consider an arbitrary set X containing n sets  $\{S_1 \dots S_n\}$ , where  $S_i \subset \mathbb{R}^d$ ,  $i=1\dots n$ . Let  $\lambda = \max_{i=1\dots n} \lambda_{S_i}$ . If we set  $\delta = \frac{1}{2n}$ , it follows that for any point  $q \in \mathbb{R}^d$ , a random mapping  $G: \mathbb{R}^d \to \mathbb{R}^k$ ,  $k = O(\log \lambda \cdot \log n \cdot \log(1/\varepsilon)/\varepsilon^2)$  preserves a  $(1+\epsilon)$ -nearest-neighbor of q in  $\bigcup_{i=1}^n S_i$  with probability at least 1/2. Therefore, if we find a  $(1+\epsilon)$ -approximate nearest-neighbor of G(q) in  $\{G(S_1) \dots G(S_n)\}$ , then with probability 1/2 it is also a  $(1+O(\epsilon))$ -approximate nearest-neighbor of q in  $\{S_1 \dots S_n\}$ . This corollary provides a strong generalization of a result of Magen [2002], who showed this to be the case where the  $S_i's$  are affine spaces (although our bound is weaker by a factor of  $\log(1/\epsilon)$ ).

Our embedding-based approach to designing approximate nearest-neighbor algorithms has the following benefits:

- —Simplicity Preservation: Our data structure is as simple as the data structure we use as a subroutine.
- —*Modularity*: Any potential future improvements to algorithms for the approximate nearest-neighbor problem in  $\ell_2^k$  will, when combined with our embedding, automatically yield a better bound for the same problem in  $\ell_2$  metrics with low doubling constant.

Although in this article we focused on embeddings into  $\ell_2$ , it is interesting to design NN-preserving embeddings into any space which supports fast approximate nearest-neighbor search, for example, low-dimensional  $\ell_{\infty}$  [Indyk 1998].

#### 2. Basic Concepts

In this section we introduce the basic concepts used in this article. In particular, we define the doubling constant, the parameter  $E_X$ , and the  $\gamma$ -dimension. We also point out the relations between these parameters.

Doubling constant. Let  $(X, d_X)$  be a metric space. In what follows,  $B_X(x, r)$  denotes the ball in X of radius r centered at  $x \in X$ , namely,  $B_X(x, r) = \{y \in X : d_X(x, y) < r\}$ . The doubling constant of X (see Heinonen [2001]), denoted  $\lambda_X$ , is the least integer  $\lambda \ge 1$  such that for every  $x \in X$  and x > 0, there is  $x \in X$  with  $|x| \le 1$  such that

$$B_X(x, 2r) \subseteq \bigcup_{s \in S} B_X(s, r).$$

The parameter  $E_X$ . Fix an integer N and denote by  $\langle \cdot, \cdot \rangle$  the standard inner product in  $\mathbb{R}^N$ . In what follows,  $g = (g_1, \dots, g_N)$  is a standard Gaussian vector in  $\mathbb{R}^N$  (i.e., a vector with independent coordinates which are standard Gaussian random variables). Given  $X \subseteq \ell_2^N$ , we denote

$$E_X = \mathbb{E}\sup_{x \in X} |\langle x, g \rangle| = \mathbb{E}\sup_{(x_1, \dots, x_N) \in X} \sum_{i=1}^N x_i g_i.$$
 (1)

We observe that the parameter  $E_X$  of a given bounded set  $X \subseteq \ell_2^d$  can be estimated very efficiently, that is, in time O(d|X|). This follows directly from the definition of  $E_X$ , and the fact that for every t>0,  $\Pr[|\sup_{x\in X}|\langle g,x\rangle|-E_X|>t]\leq 2e^{-t^2/(4\max_{x\in X}\|x\|_2^2)}$  (this deviation inequality is a consequence of the fact that the mapping  $g\mapsto\sup_{x\in X}|\langle g,x\rangle|$  is Lipschitz with constant  $\max_{x\in X}\|x\|_2$ , and the Gaussian isoperimetric inequality; see Ledoux and Talagrand [1991]). In addition, even if X is large, for example, has size exponential in d,  $E_X$  can often be computed in time polynomial in d [Barvinok 1997; Barvinok and Samorodnitsky 2001, 2004]. For example, this is the case where X is a set of all matchings in a given graph G, and each matching is represented by a characteristic vector of its edge set.

Doubling constant vs. the parameter  $E_X$ . We observe that for every bounded  $X \subseteq \ell_2^N$ 

$$E_X = O(\operatorname{diam}(X)\sqrt{\log \lambda_X}). \tag{2}$$

Indeed, an inequality of Dudley (see Ledoux and Talagrand [1991]) states that

$$E_X \le 24 \int_0^{\operatorname{diam}(X)} \sqrt{\log N(X, \varepsilon)} \, d\varepsilon,$$

where  $N(X, \varepsilon)$  are the *entropy numbers* of X, namely, the minimal number of balls of radius  $\varepsilon$  required to cover X. The doubling condition implies that for every  $\varepsilon > 0$ , we have that  $N(X, \varepsilon \operatorname{diam}(X)) \leq (2/\varepsilon)^{\log_2 \lambda_X}$ , so

$$E_X \le 24 \operatorname{diam}(X) \sqrt{\log_2 \lambda_X} \int_0^1 \sqrt{\log_2(2/\varepsilon)} \, d\varepsilon \le 80 \operatorname{diam}(X) \sqrt{\log_2 \lambda_X}.$$

Another way to prove Eq. (2) is as follows. Let  $\mathcal{B}(X)$  be the set of all Borel probability measures on X. The celebrated Majorizing Measure theorem of Talagrand [1987] states that

$$E_X = \Theta\left(\inf_{\mu \in \mathcal{B}(X)} \sup_{x \in X} \int_0^\infty \sqrt{\log\left(\frac{1}{\mu(B_X(x,\varepsilon))}\right)} d\varepsilon\right). \tag{3}$$

A theorem of [Konyagin and Vol'berg 1987; Heinonen 2001] states that if X is a complete metric space, there exists a Borel measure  $\mu$  on X such that for every  $x \in X$  and r > 0,  $\mu(B_X(x, 2r)) \le \lambda_X^2 \mu(B_X(x, r))$ . Now we just plug  $\mu$  into (3) and obtain (2).

 $\gamma$ -dimension. The righthand-side of (3) makes sense in arbitrary metric spaces, not just in subsets of  $\ell_2$ . In fact, another equivalent formulation of (1) is based on

Talagrand's  $\gamma_2$  functional, defined as follows. Given a metric space  $(X, d_X)$ , set

$$\gamma_2(X) = \inf \sup_{x \in X} \sum_{s=0}^{\infty} 2^{s/2} d_X(x, A_s),$$
(4)

where the infimum is taken over all choices of subsets  $A_s \subseteq X$  with  $|A_s| \le 2^{2^s}$ . Talagrand's "generic chaining" version of the Majorizing Measure theorem [Talagrand 2001, 1996] states that for every  $X \subseteq \ell_2$ ,  $E_X = \Theta(\gamma_2(X))$  (we refer to Guédon and Zvavitch [2003] for a related characterization). The parameter  $\gamma_2(X)$  can be defined for arbitrary metric spaces  $(X, d_X)$  and it is straightforward to check that in general,  $\gamma_2(X) = O(\operatorname{diam}(X)\sqrt{\log \lambda_X})$ . Thus, it is natural to define the  $\gamma$ -dimension of X to be

$$\gamma \dim(X) \equiv \left[\frac{\gamma_2(X)}{\operatorname{diam}(X)}\right]^2.$$

## 3. The Case of Euclidean Spaces with Low $\gamma$ -Dimension

We introduce the following useful modification of the notion of a bi-Lipschitz embedding. We then use this notion to give NN-preserving embeddings of  $\ell_2$  submetrics, with bounded aspect ratio and  $\gamma$ -dimension, into low-dimensional  $\ell_2$ .

Definition 3.1 (Bi-Lipschitz Embeddings with Resolution). Let  $(X, d_X)$ ,  $(Y, d_Y)$  be metric spaces, and  $\delta$ , D > 0. A mapping  $f: X \to Y$  is said to be D bi-Lipschitz with resolution  $\delta$  if there is a (scaling factor) C > 0 such that

$$\forall a, b \in X, d_X(a, b) > \delta \Longrightarrow Cd_X(a, b) \le d_Y(f(a), f(b)) \le CDd_X(a, b).$$

In what follows  $S^{d-1}$  denotes the unit Euclidean sphere centered at the origin. We will use the following theorem, which is due to Gordon [1988].

THEOREM 3.2 [Gordon 1988]. Fix  $X \subseteq S^{d-1}$  and  $\varepsilon \in (0, 1)$ . Then there exists an integer  $k = O(\frac{E_X^2}{\varepsilon^2})$  and a linear mapping  $T : \mathbb{R}^d \to \mathbb{R}^k$  such that for every  $x \in X$ .

$$1 - \varepsilon \le ||Tx||_2 \le 1 + \varepsilon$$
.

Remark 3.1. Since the proof of the preceding theorem uses a probabilistic method (specifically, Gordon [1988] proved that if  $\Gamma$  is a  $k \times d$  matrix whose coordinates are independent and identically distributed standard Gaussian random variables then  $T = \frac{1}{\sqrt{k}}\Gamma$  will satisfy the assertion of Theorem 3.2 with high probability; see also Schechtman [1989]), it also follows that there exists a randomized embedding that satisfy the thesis of the aforementioned theorem with probability 1/2. Recently, Klartag and Mendelson [] showed that the same result holds true if the entries of  $\Gamma = (\gamma_{ij})$  are only assumed to be independent and identically distributed, and have mean 0 variance 1, and sub-Gaussian tail bounds, namely,  $\Pr[|\gamma_{ij}| > u] \le K e^{-\delta u^2}$  for every u > 0 and some constants K,  $\delta > 0$ . In this case the implied constants may depend on K,  $\delta$ . A particular case of interest is when  $\Gamma$  is a random  $\pm 1$  matrix, just like in Achlioptas's variant [Achlioptas 2003] of the Johnson-Lindenstrauss lemma [Johnson and Lindenstrauss 1984], we obtain "database-friendly" versions of Theorem 4.1.

It should be pointed out here that although several papers [Frank and Maehara 1988; Dasgupta and Gupta 2003; Indyk and Motwani 1999; Achlioptas 2003] obtained alternative proofs of the Johnson-Lindenstrauss lemma using different types of random matrices, it turns out that all that matters is that the entries are independent and identically distributed sub-Gaussian random variables (to see this, just note that when  $\delta=0$ , the set  $\widetilde{X}$  contains at most  $|X|^2$  points, and for any n-point subset Z of  $\mathbb{R}^d$ ,  $E_Z=O(\sqrt{\log n})$ ). Here is a simple proof of this fact using an elementary large-deviation argument. Let g be a standard Gaussian random variable, that is, its density is  $\frac{1}{\sqrt{2\pi}}e^{-x^2/2}$ . In what follows, g will always be assumed independent of all other random variables that appear in the proof. The only properties of g that we will need is that for all  $t \in \mathbb{R}$  we have  $\mathbb{E}e^{tg}=e^{t^2/2}$  and for all  $t \in (0,1/2)$  we have  $\mathbb{E}e^{tg^2}=\frac{1}{\sqrt{1-2t}}$ .

Now, let X be a symmetric random variable (i.e., X and -X have the same distribution) such that  $\mathbb{E}X^2=1$ . Assume that X is sub-Gaussian, namely, that  $\mathbb{E}e^{uX} \leq e^{cu^2}$  for all  $u \in \mathbb{R}$  and some constant c>0 (note that this condition on the moment-generating function easily follows from sub-Gaussian tail bounds). Fix a unit vector  $a=(a_1,\ldots,a_n)\in S^{n-1}$ . Let  $X_1,\ldots,X_n$  be independent and identically distributed copies of X and denote  $U=\sum_{j=1}^n a_j X_j$ . Then  $\mathbb{E}U^2=1$ , and for every  $0 \leq t \leq \frac{1}{8c}$  we have

$$\mathbb{E}e^{tU^2} = \mathbb{E}_U \mathbb{E}_g e^{\sqrt{2t}gU} = \mathbb{E}_g \left( \prod_{j=1}^n \mathbb{E}_X e^{\sqrt{2t}a_j gX} \right) \le E_g \left[ \prod_{j=1}^n e^{2cta_j^2 g^2} \right]$$
$$= \mathbb{E}_g e^{2ctg^2} = \frac{1}{\sqrt{1 - 4ct}} \le \sqrt{2}. \tag{5}$$

Therefore, using Eq. (5) we see that for every  $-\frac{1}{8c} \le t \le \frac{1}{8c}$  we have

$$\mathbb{E}e^{tU^{2}} = \sum_{m=0}^{\infty} \frac{t^{m} \mathbb{E}U^{2m}}{m!} \le 1 + t + \sum_{m=2}^{\infty} \frac{(8c|t|)^{m} \left(\frac{1}{8c}\right)^{m} \mathbb{E}U^{2m}}{m!}$$

$$\le 1 + t + (8ct)^{2} \sum_{m=2}^{\infty} \frac{\left(\frac{1}{8c}\right)^{m} \mathbb{E}U^{2m}}{m!} \le 1 + t + (8ct)^{2} \mathbb{E}e^{U^{2}/(8c)}$$

$$\le 1 + t + 100c^{2}t^{2} \le e^{t + 100c^{2}t^{2}}.$$
(6)

Hence, if  $U_1, \ldots, U_k$  are independent and identically distributed copies of U, then for every  $0 < \varepsilon \le 25c$  we can apply (6) with  $t = \frac{\varepsilon}{200c^2}$  to get

$$\Pr\left[\frac{1}{k}\sum_{i=1}^{k}U_{i}^{2} \geq 1 + \varepsilon\right] \leq e^{-k(1+\varepsilon)t} \left(\mathbb{E}e^{tU^{2}}\right)^{k} \leq e^{-k(1+\varepsilon)t + kt + 100kc^{2}t^{2}} = e^{-k\varepsilon^{2}/(400c^{2})}$$

and

$$\Pr\left[-\frac{1}{k}\sum_{i=1}^{k}U_{i}^{2} \geq -1 + \varepsilon\right] \leq e^{k(1-\varepsilon)t} \left(\mathbb{E}e^{-tU^{2}}\right)^{k}$$

$$\leq e^{k(1-\varepsilon)t - kt + 100kc^{2}t^{2}} = e^{-k\varepsilon^{2}/(400c^{2})}.$$

In summary, we proved that for every  $0 < \varepsilon < 25c$ , we have

$$\Pr\left[\left|\frac{1}{k}\sum_{i=1}^{k}U_i^2-1\right| \geq \varepsilon\right] \leq 2e^{-k\varepsilon^2/(400c^2)}.$$

Another way to phrase this inequality is that if  $\{X_{ij}: i=1,\ldots,k\ j=1,\ldots,n\}$  are independent and identically distributed copies of X, and we consider the  $k\times n$  random matrix  $A:=\frac{1}{\sqrt{k}}(X_{ij})$ , then for every  $x\in\mathbb{R}^n$  we have

$$\Pr\left[\left|\|Ax\|_{2}^{2}-\|x\|_{2}^{2}\right| \geq \varepsilon \|x\|_{2}^{2}\right] \leq 2e^{-k\varepsilon^{2}/(400c^{2})}.$$

An application of the union bound shows that this concentration inequality implies the Johnson-Lindenstrauss dimensionality reduction result for arbitrary random matrices with sub-Gaussian independent and identically distributed entries.

A simple corollary of Theorem 3.2 is the following.

THEOREM 3.3. Fix  $\varepsilon$ ,  $\delta > 0$  and a set  $X \subseteq \mathbb{R}^d$ . Then there exists an integer  $k = O(\frac{E_X^2}{\delta^2 \varepsilon^2})$  such that X embeds  $1 + \varepsilon$  bi-Lipschitzly in  $\mathbb{R}^k$  with resolution  $\delta$ . Moreover, the embedding extends to a linear mapping defined on all of  $\mathbb{R}^d$ .

PROOF. Consider the set  $\widetilde{X} = \{\frac{x-y}{\|x-y\|_2} : x, y \in X, \|x-y\|_2 \ge \delta\}$ . Then

$$E_{\widetilde{X}} = \mathbb{E}\left(\sup\left\{\frac{|\langle x-y,g\rangle|}{\|x-y\|_2}: x, y \in X \|x-y\|_2 \ge \delta\right\}\right)$$
  
$$\leq \frac{1}{\delta} \mathbb{E}\sup_{x,y \in X} |\langle x-y,g\rangle| \leq \frac{2}{\delta} E_X.$$

So the required result is a consequence of Theorem 3.2 applied to  $\widetilde{X}$ .  $\square$ 

*Remark* 3.2. We can make Theorem 3.3 scale invariant by normalizing by diam(X), in which case we get a  $1 + \varepsilon$  bi-Lipschitz embedding with resolution  $\delta \operatorname{diam}(X)$ , where  $k = O(\frac{\gamma \operatorname{dim}(X)}{\delta^2 \varepsilon^2})$ .

Remark 3.3. Let  $\{e_j\}_{j=1}^\infty$  be the standard basis of  $\ell_2$ . Fix  $\varepsilon$ ,  $\delta \in (0, 1/2)$ , an integer n, and set  $m = \lceil n^{1/\delta^2} \rceil$ . Consider the set  $X = \{e_1, \ldots, e_n, \delta e_{n+1}, \ldots, \delta e_{n+m}\}$ . Then  $E_X = \Theta(\sqrt{\log n} + \delta \sqrt{\log m}) = \Theta(\sqrt{\log n})$ . Let  $f: X \to \mathbb{R}^k$  be a (not necessarily linear)  $1 + \varepsilon$  bi-Lipschitz embedding with resolution  $\delta$  (which is thus a  $1 + \varepsilon$  bi-Lipschitz embedding, since the minimal distance in X is  $\delta \sqrt{2}$ ). By a result of Alon [2003] (see also Matoušek [2002]), we deduce that  $k = \Omega(\frac{\log m}{\varepsilon^2 \log(1/\varepsilon)}) = \Omega(\frac{E_X^2}{\delta^2 \varepsilon^2 \log(1/\varepsilon)})$ . Thus the value of k in Theorem 3.3 is nearly optimal.

## 4. The Case of Euclidean Doubling Spaces

We recall some facts about random Gaussian matrices. Let  $a \in S^{n-1}$  be a unit vector and let  $\{g_{ij}: 1 \le i \le k, 1 \le j \le n\}$  be independent and identically distributed standard Gaussian random variables. Denoting  $G = \frac{1}{\sqrt{k}}(g_{ij})$ , by standard arguments

(see Durrett [1996]) the random variable  $||Ga||_2^2$  has distribution whose density is

$$\frac{1}{2^{k/2}\Gamma(k/2)} \cdot x^{\frac{k}{2}-1} e^{-x/2}, \quad x > 0.$$

By simple computation it follows that for D > 0,

$$\Pr[\|Ga\|_2 - 1| \ge D] \le e^{-kD^2/8} \quad \text{and} \quad \Pr[\|Ga\|_2 \le 1/D] \le \left(\frac{3}{D}\right)^k.$$
 (7)

The main result of this section is the following theorem.

THEOREM 4.1. For  $X \subseteq \mathbb{R}^d$ ,  $\varepsilon \in (0, 1)$ , and  $\delta \in (0, 1/2)$  there exists  $k = O(\frac{\log(2/\varepsilon)}{\varepsilon^2} \cdot \log(1/\delta) \cdot \log \lambda_X)$  such that for every  $x_0 \in X$  with probability at least  $1 - \delta$ :

- (1)  $d(Gx_0, G(X \setminus \{x_0\})) \le (1 + \varepsilon)d(x_0, X \setminus \{x_0\});$  and
- (2) Every  $x \in X$  with  $||x_0 x||_2 > (1 + 2\varepsilon)d(x_0, X \setminus \{x_0\})$  satisfies  $||Gx_0 Gx|| > (1 + \varepsilon)d(x_0, X \setminus \{x_0\})$ .

The following lemma can be proved using the methods of Gordon [1988] and Schechtman [to appear; 1989], but the doubling assumption allows us to give a simple direct proof.

LEMMA 4.2. Let  $X \subseteq B(0, 1)$  be a subset of the n-dimensional Euclidean unit ball. Then there exist universal constants c, C > 0 such that for  $k \ge C \log \lambda_X + 1$  and D > 1,

$$\Pr[\exists x \in X, \|Gx\|_2 \ge D] \le e^{-ckD^2}.$$

PROOF. Without loss of generality  $0 \in X$ . We construct subsets  $I_0, I_1, I_2, \ldots \subseteq X$  as follows. Set  $I_0 = \{0\}$ . Inductively, for every  $t \in I_j$ , there is a minimal  $S_t \subseteq X$  with  $|S_t| \le \lambda_X$  such that  $B(t, 2^{-j}) \cap X \subseteq \bigcup_{s \in S_t} B(s, 2^{-j-1}) \cap X$ . We define  $I_{j+1} = \bigcup_{t \in I_s} S_t$ .

For  $x \in X$  there is a sequence  $\{0 = t_0(x), t_1(x), t_2(x), \dots\} \subseteq X$  such that for all j, we have  $t_{j+1}(x) \in S_{t_j(x)}$ , and  $x = \sum_{j=0}^{\infty} [t_{j+1}(x) - t_j(x)]$ . Now, using the fact that  $||t_{j+1}(x) - t_j(x)||_2 \le 2^{-j+1}$ , we get

$$\Pr[\exists x \in X, \ \|Gx\|_{2} \ge D] \le \Pr\left[\exists x \in X \ \exists j \ge 0, \ \|G[t_{j+1}(x) - t_{j}(x)]\|_{2} \ge \frac{D}{3} \left(\frac{3}{2}\right)^{-j}\right] \\
\le \sum_{j=0}^{\infty} \Pr\left[\exists t \in I_{j} \ \exists s \in S_{t}, \ \|G(t-s)\|_{2} \ge \frac{D}{6} \left(\frac{4}{3}\right)^{j} \|t-s\|_{2}\right] \\
\le \sum_{j=0}^{\infty} \lambda_{X}^{2j} e^{-\frac{kD^{2}}{400}(4/3)^{2j}} \le e^{-ckD^{2}},$$

provided that  $k \geq C \log \lambda_X + 1$  and using the first estimate in Eq. (7).

PROOF OF THEOREM 4.1. Without loss of generality  $x_0 = 0$  and  $d(x_0, X \setminus \{x_0\}) = 1$ . If  $y \in X$  satisfies  $||y||_2 = 1$ , then by (7) we get that  $\Pr[||Gy||_2 \ge 1 + \varepsilon] \le e^{-k\varepsilon^2/8}$ . Thus for  $k \ge C \log(1/\delta)/\varepsilon^2$  we get

$$\Pr[d(Gx_0, G(X \setminus \{x_0\})) > (1+\varepsilon)d(x_0, X \setminus \{x_0\})] < \delta/2.$$

Define  $r_{-1} = 0$ ,  $r_0 = 1$ ,  $r_i = 1 + 2\varepsilon + \varepsilon(i - 1)/4$ , and consider the annuli  $X_i = X \cap [B(0, r_i) \setminus B(0, r_{i-1})]$ .

Fix an integer  $i \geq 1$ , and use the doubling condition to find  $S \subseteq X_i$  such that  $X_i \subseteq \bigcup_{s \in S} B(s, \varepsilon/4)$  and  $|S| \leq \lambda_X^{\log_2(16r_i/\varepsilon)}$ . Then by Lemma 4.2,

$$\Pr\left[\exists s \in S \,\exists x \in B(s, \varepsilon/4) \cap X_i, \|Gs - Gx\|_2 \ge \frac{\varepsilon\sqrt{i}}{4}\right]$$

$$\le \lambda_x^{\log_2(16r_i/\varepsilon)} \cdot e^{-cki} \le e^{-c'ki}. \tag{8}$$

On the other hand, fix  $s \in S$ . If  $||Gs||_2 < 1 + \varepsilon + \frac{\varepsilon\sqrt{i}}{4}$  then there exists a universal constant C > 0 such that

$$\frac{\|Gs\|_2}{\|s\|_2} \le \frac{1+\varepsilon + \frac{\varepsilon\sqrt{i}}{4}}{1+2\varepsilon + \frac{\varepsilon(i-2)}{4}} \le \begin{cases} 1-\varepsilon/4 & i \le 1/\varepsilon^2 \\ C/\sqrt{i} & i > 1/\varepsilon^2. \end{cases}$$

Hence, by (7)

$$\Pr\left[\exists s \in S \ \|Gs\|_{2} \ge 1 + \varepsilon + \frac{\varepsilon\sqrt{i}}{4}\right] \le \begin{cases} \lambda_{X}^{\log_{2}(16r_{i}/\varepsilon)} e^{-c''k\varepsilon^{2}} & i \le 1/\varepsilon^{2} \\ \lambda_{X}^{\log_{2}(16r_{i}/\varepsilon)} \cdot (3C/\sqrt{i})^{k} & i > 1/\varepsilon^{2} \end{cases}$$

$$\le \begin{cases} e^{-c'''k\varepsilon^{2}} & i \le 1/\varepsilon^{2} \\ i^{-c'''k} & i > 1/\varepsilon^{2}, \end{cases}$$
(9)

provided,  $k \ge C \frac{\log(2/\varepsilon)}{\varepsilon^2} \cdot \log \lambda_X$  for a large enough constant C. Now, from Eqs. (8) and (9) we see that there exists a constant  $\widetilde{c}$  such that

$$\Pr[\forall x \in X_i, \ \|Gx\|_2 > 1 + \varepsilon] \ge \begin{cases} 1 - 2e^{-\widetilde{c}k\varepsilon^2} & i \le 1/\varepsilon^2 \\ 1 - 2i^{-\widetilde{c}k} & i > 1/\varepsilon^2. \end{cases}$$

Hence,

$$\Pr\left[\exists x \in X, \|x\|_{2} > 1 + 2\varepsilon \wedge \|Gx\|_{2} < 1 + \varepsilon\right] \leq \sum_{i=1}^{\infty} \Pr\left[\exists x \in X_{i}, \|Gx\|_{2} < 1 + \varepsilon\right]$$
$$\leq \frac{2}{\varepsilon^{2}} e^{-\widetilde{c}k\varepsilon^{2}} + 2\sum_{i>1/\varepsilon^{2}} i^{-\widetilde{c}k} < \delta/2$$

for large enough k. This completes the proof of Theorem 4.1.  $\square$ 

Remark 4.1. Since  $\gamma \dim(X) = O(\log \lambda_X)$ , Theorem 4.1 sheds some light on the following problem (which is folklore, but was apparently first stated explicitly in print in Lang and Plaut [2001]): Is it true that any subset  $X \subseteq \ell_2$  embeds into  $\ell_2^{d(\lambda_X)}$  with distortion  $D(\lambda_X)$ , where  $d(\lambda_X)$ ,  $D(\lambda_X)$  depend only on the doubling constant of X. Ideally,  $d(\lambda_X)$  should be  $O(\log \lambda_X)$ , but no bound depending only on  $\lambda_X$  is known. Moreover, the analogous result in  $\ell_1$  is known to be false (see Lee et al. [to appear] for a stronger negative result in  $\ell_1$ ). The following example shows that more work needs to be done towards solving this problem positively (if at all possible. In fact, we believe that this problem has a negative answer): Linear mappings cannot yield the required embedding without a positive lower bound on

the resolution. Specifically, we claim that for every D > 1, there are arbitrarily large n-point subsets  $X_n$  of  $\ell_2$  which are doubling with constant 6 such that if there exists a linear mapping  $T: \ell_2 \to \mathbb{R}^d$  which is D-bi-Lipschitz on  $X_n$ , then  $d \ge \frac{\log n}{\log D}$  (observe that by the Johnson-Lindenstrauss lemma any n point subset of  $\ell_2$  embeds with distortion D via a linear mapping into  $\ell_2^k$ , with  $k = O(\frac{\log n}{\log D})$ ).

To see this, fix D > 1 and an integer d. Let  $\mathcal{N}$  be a 1/(4D) net in  $S^{d-1}$ . Write  $n+1 = |\mathcal{N}|$  and  $\mathcal{N} = \{x_1, \ldots, x_n\} \cup \{0\}$ . Define  $X = \{2^{-j}x_j\}_{j=1}^n$ . Whenever  $1 \le i < j \le n$  we have that

$$2^{-i} - 2^{-j} \le ||2^{-i}x_i - 2^{-j}x_i||_2 \le 2^{-i} + 2^{-j} \le 3(2^{-i} - 2^{-j}),$$

so X is embeddable into the real line with distortion 3. In particular, X is doubling with constant at most 6. However, X cannot be embedded into low dimensions using a linear mapping. Indeed, assume that  $T: \mathbb{R}^d \to \mathbb{R}^k$  is a linear mapping such that for every  $x, y \in X$ ,  $\|x - y\|_2 \le \|Tx - Ty\|_2 \le D\|x - y\|_2$ . Then for every  $i, \|Tx_i\|_2 = 2^i \|T(2^{-i}x_i) - T(0)\|_2 \in [1, D]$ . Take  $x \in S^{d-1}$  for which  $\|Tx\|_2 = \|T\| = \max_{y \in S^{d-1}} \|Ty\|_2$ . There is  $1 \le i \le n$  such that  $\|x - x_i\|_2 \le 1/(4D) \le 1/2$ . Then  $\|T\| = \|Tx\|_2 \le \|Tx_i\|_2 + \|T(x - x_i)\|_2 \le D + \|T\| \cdot \|x - x_i\|_2 \le D + \frac{1}{2}\|T\|$ . Thus  $\|T\| \le 2D$ . Now, for every  $y \in S^{d-1}$  there is  $1 \le j \le n$  for which  $\|y - x_j\|_2 \le 1/(4D)$ . It follows that  $\|Ty\|_2 \ge \|Tx_j\|_2 - \|T(y - x_j)\|_2 \ge 1 - \|T\|/(4D) \ge 1/2$ . This implies that T is invertible, so necessarily  $k \ge d$ . This proves our claim, since by standard volume estimates  $|X| \le (12D)^d$ .

ACKNOWLEDGMENTS. The authors would like to thank Mihai Badoiu, Robert Krauthgamer, James R. Lee, and Vitali Milman for discussions during the initial phase of this work.

#### REFERENCES

ACHLIOPTAS, D. 2003. Database-Friendly random projections: Johnson-Lindenstrauss with binary coins. J. Comput. Syst. Sci. 66, 4, 671–687.

ALON, N. 2003. Problems and results in extremal combinatorics. I. Discrete Math. 273, 1–3, 31–53.

Andoni, A., Datar, M., Immorlica, N., Indyk, P., and Mirrokni, V. 2005. Locality-Sensitive hashing scheme based on stable distributions. In *Nearest-Neighbor Methods for Learning and Vision: Theory and Practice*. MIT Press, Cambridge, MA.

ARYA, S., AND MALAMATOS, T. 2002. Linear-Size approximate voronoi diagrams. *Proceedings of the ACM-SIAM Symposium on Discrete Algorithms*, 147–155.

BARVINOK, A. 1997. Approximate counting via random optimization. *Random Struct. Alg. 11*, 2, 187–198.

BARVINOK, A., AND SAMORODNITSKY, A. 2001. The distance approach to approximate combinatorial counting. *Geom. Funct. Anal.* 11, 5, 871–899.

BARVINOK, A., AND SAMORODNITSKY, A. 2004. Random weighting, asymptotic counting, and inverse isoperimetry. Preprint.

BRINKMAN, B., AND CHARIKAR, M. 2003. On the impossibility of dimension reduction in  $l_1$ . In *Proceedings of the 44th Annual IEEE Symposium on Foundations of Computer Science*.

CLARKSON, K. 2005. Nearest-Neighbor searching and metric space dimensions. In Nearest-Neighbor Methods for Learning and Vision: Theory and Practice. MIT Press, Cambridge, MA.

DASGUPTA, S., AND GUPTA, A. 2003. An elementary proof of a theorem of Johnson and Lindenstrauss. *Random Struct. Alg.* 22, 1, 60–65.

DURRETT, R. 1996. Probability: Theory and Examples, 2nd ed. Duxbury Press, Belmont, CA.

FRANKL, P., AND MAEHARA, H. 1988. The Johnson-Lindenstrauss lemma and the sphericity of some graphs. *J. Combin. Theory Ser. B* 44, 3, 355–362.

GORDON, Y. 1988. On Milman's inequality and random subspaces which escape through a mesh in  $\mathbb{R}^n$ . In Geometric Aspects of Functional Analysis. Lecture Notes in Math., vol. 1317. Springer, Berlin, 84–106.

- GUEDON, O., AND ZVAVITCH, A. 2003. Supremum of a process in terms of trees. In *Geometric Aspects of Functional Analysis*. Lecture Notes in Math., vol. 1807. Springer, Berlin, 136–147.
- GUPTA, A., KRAUTHGAMER, R., AND LEE, J. R. 2003. Bounded geometries, fractals, and low-distortion embeddings. In *Annual Symposium on Foundations of Computer Science*.
- HAR-PELED, S. 2001. A replacement for voronoi diagrams of near linear size. In *Annual Symposium on Foundations of Computer Science*.
- HEINONEN, J. 2001. *Lectures on Analysis on Metric Spaces*. Universitext. Springer, New York.
- INDYK, P. 1998. On approximate nearest neighbors in non-Euclidean spaces. In *Proceedings of the Symposium on Foundations of Computer Science*. 148–155.
- INDYK, P. 2000. Stable distributions, pseudorandom generators, embeddings and data stream computation. In *Annual Symposium on Foundations of Computer Science*.
- INDYK, P., AND MOTWANI, R. 1998. Approximate nearest neighbor: Towards removing the curse of dimensionality. In *Proceedings of the Symposium on Theory of Computing*.
- INDYK, P., AND MOTWANI, R. 1999. Approximate nearest neighbors: Towards removing the curse of dimensionality. In *Proceedings of the Annual ACM Symposium on Theory of Computing (STOC'98)* (Dallas, TX). ACM, New York, 604–613.
- JOHNSON, W. B., AND LINDENSTRAUSS, J. 1984. Extensions of Lipschitz mappings into a Hilbert space. In *Proceedings of the Conference in Modern Analysis and Probability* (New Haven, Conn., 1982). American Mathematics Society Providence, RI, 189–206.
- KLARTAG, B., AND MENDELSON, S. Empirical processes and random projections. *J. Funct. Anal.* To appear.
- KONYAGIN, S. V., AND VOLL BERG, A. L. 1987. On measures with the doubling condition. *Izv. Akad. Nauk SSSR Ser. Mat. 51*, 3, 666–675.
- KRAUTHGAMER, R., AND LEE, J. R. 2004. Navigating nets: Simple algorithms for proximity search. In *Proceedings of the ACM-SIAM Symposium on Discrete Algorithms*.
- KUSHILEVITZ, E., OSTROVSKY, R., AND RABANI, Y. 1998. Efficient search for approximate nearest neighbor in high dimensional spaces. In *Proceedings of the 30th ACM Symposium on Theory of Computing*. 614–623.
- LANG, U., AND PLAUT, C. 2001. Bilipschitz embeddings of metric spaces into space forms. *Geom. Dedicata 87*, 1–3, 285–307.
- LEDOUX, M., AND TALAGRAND, M. 1991. Probability in Banach spaces. Ergebnisse der Mathematik und ihrer Grenzgebiete (3) [Results in Mathematics and Related Areas (3)], vol. 23. Springer, Berlin. Isoperimetry and processes.
- LEE, J. R., MENDEL, M., AND NAOR, A. Metric structures in *L*1: Dimension, snowflakes, and average distortion. *Euro. J. Combin*. To appear.
- LEE, J. R., AND NAOR, A. 2004. Embedding the diamond graph in *L <sup>p</sup>* and dimension reduction in *L*1. *Geom. Funct. Anal. 14*, 4, 745–747.
- MAGEN, A. 2002. Dimensionality reductions that preserve volumes and distance to affine spaces, and their algorithmic applications. In *Proceedings of the 6th International Workshop on Randomization and Approximation Techniques (RANDOM)*.
- MATOUSEK ˇ , J. 2002. *Lectures on Discrete Geometry*. Graduate Texts in Mathematics, vol. 212. Springer, New York.
- SCHECHTMAN, G. Two observations regarding embedding subsets of Euclidean spaces in normed spaces. *Adv. Math.* To appear.
- SCHECHTMAN, G. 1989. A remark concerning the dependence on in Dvoretzky's theorem. In *Geometric Aspects of Functional Analysis (1987–88)*. Lecture Notes in Math., vol. 1376. Springer, Berlin, 274–277.
- TALAGRAND, M. 2001. Majorizing measures without measures. *Ann. Probab. 29*, 1, 411–417.
- TALAGRAND, M. 1996. Majorizing measures: The generic chaining. *Ann. Probab. 24*, 3, 1049–1103.
- TALAGRAND, M. 1987. Regularity of Gaussian processes. *Acta Math. 159*, 1-2, 99–149.

RECEIVED JULY 2005; REVISED AUGUST 2006; ACCEPTED AUGUST 2006