<span id="page-0-0"></span>![](_page_0_Picture_1.jpeg)

# **A Unified PTAS for Prize Collecting TSP and Steiner Tree Problem in Doubling Metrics**

T.-H. HUBERT CHAN, University of Hong Kong, Hong Kong HAOTIAN JIANG, University of Washington, USA SHAOFENG H.-C. JIANG, Weizmann Institute of Science, Israel

We present a unified (randomized) polynomial-time approximation scheme (PTAS) for the prize collecting traveling salesman problem (PCTSP) and the prize collecting Steiner tree problem (PCSTP) in doubling metrics. Given a metric space and a penalty function on a subset of points known as terminals, a solution is a subgraph on points in the metric space whose cost is the weight of its edges plus the penalty due to terminals not covered by the subgraph. Under our unified framework, the solution subgraph needs to be Eulerian for PCTSP, while it needs to be a tree for PCSTP. Before our work, even a QPTAS for the problems in doubling metrics is not known.

Our unified PTAS is based on the previous dynamic programming frameworks proposed in Talwar (STOC 2004) and Bartal, Gottlieb, Krauthgamer (STOC 2012). However, since it is unknown which part of the optimal cost is due to edge lengths and which part is due to penalties of uncovered terminals, we need to develop new techniques to apply previous divide-and-conquer strategies and sparse instance decompositions.

CCS Concepts: • **Theory of computation** → **Routing and network design problems**;

Additional Key Words and Phrases: Doubling dimension, prize collecting, traveling salesman problem, Steiner tree problem, polynomial time approximation scheme

## **ACM Reference format:**

T.-H. Hubert Chan, Haotian Jiang, and Shaofeng H.-C. Jiang. 2020. A Unified PTAS for Prize Collecting TSP and Steiner Tree Problem in Doubling Metrics. *ACM Trans. Algorithms* 16, 2, Article 24 (March 2020), 23 pages. <https://doi.org/10.1145/3378571>

# **1 INTRODUCTION**

We study prize collecting versions of two important optimization problems: the prize collecting traveling salesman problem (PCTSP) and the prize collecting Steiner tree problem (PCSTP). In both problems, we are given a metric space and a set of points called *terminals* and a non-negative penalty function on the terminals. A solution for either problem is a connected subgraph with

The conference version of the article appeared in ESA 2018.

This work was partially supported by the Hong Kong RGC under the grant 17217716.

This research was done when the author was studying at Tsinghua University.

Authors' addresses: T.-H. Hubert Chan, University of Hong Kong, Department of Computer Science, Hong Kong; email: hubert@cs.hku.hk; H. Jiang, University of Washington, Paul G. Allen School of Computer Science and Engineering, Seattle, Washington; email: jhtdavid@cs.washington.edu; S. H.-C. Jiang, Weizmann Institute of Science, Faculty of Mathematics and Computer Science, Rehovot, Israel; email: shaofeng.jiang@weizmann.ac.il.

Permission to make digital or hard copies of all or part of this work for personal or classroom use is granted without fee provided that copies are not made or distributed for profit or commercial advantage and that copies bear this notice and the full citation on the first page. Copyrights for components of this work owned by others than the author(s) must be honored. Abstracting with credit is permitted. To copy otherwise, or republish, to post on servers or to redistribute to lists, requires prior specific permission and/or a fee. Request permissions from [permissions@acm.org.](mailto:permissions@acm.org)

© 2020 Copyright held by the owner/author(s). Publication rights licensed to ACM.

1549-6325/2020/03-ART24 \$15.00

<https://doi.org/10.1145/3378571>

24:2 T.-H. Hubert Chan et al.

vertex set from the metric. In addition, it needs to be a Eulerian1(multi-)graph for PCTSP and a tree for PCSTP. The cost of a solution is the sum of the weights of edges in the solution plus the sum of penalties due to terminals not visited by the solution.

**Prize Collecting Problems in General Metrics.** The prize collecting setting was first considered by Balas [\[5\]](#page-22-0), who proposed the prize collecting TSP. However, the version that Balas considered is actually more general, in the sense that each terminal is also associated with a reward, and the goal is to find a tour that minimizes the tour length plus the penalties and collects at least a certain amount of rewards. The setting that we consider was suggested by Bienstock et al. [\[9\]](#page-22-0), and they used LP rounding to give a 2.5-approximation algorithm for the PCTSP and a 3-approximation for the PCSTP. Later on, a unified primal-dual approach for several network design problems was proposed [\[18\]](#page-22-0); this approach improves the approximation ratios for both PCTSP and PCSTP to 2 in general metrics. The 2-approximation had remained the state-of-the-art for more than a decade, until Archer et al. [\[2\]](#page-22-0) finally broke the 2 barrier for both problems via a unified approach. Subsequently, in a note [\[17\]](#page-22-0), Goemans combined their argument with other algorithms and gave a 1.915-approximation for the PCTSP, which is the state-of-the-art.

**Prize Collecting Problems in Bounded Dimensional Euclidean Spaces.** PCTSP and PCSTP are APX-hard in general metrics, because even the special cases with infinite penalties, the TSP and the Steiner tree problem, are APX-hard. Although the seminal result by Arora [\[3\]](#page-22-0) showed that both TSP and STP have PTAS's in bounded dimensional Euclidean spaces, the prize collecting setting was not discussed. However, we do believe that their approach may be directly applied to get PTAS's for the prize collecting versions of both problems, with a slight modification to the dynamic programming algorithms. Later, A PTAS for the Steiner Forest Problem (which generalizes the STP) was discovered by Borradaile et al. [\[10\]](#page-22-0). Based on this result, Bateni et al. [\[8\]](#page-22-0) studied the Prize Collecting Steiner Forest Problem and gave a PTAS for the special case when the penalties are multiplicative, but this does not readily imply a PTAS for the PCTSP or the PCSTP.

**Prize Collecting Problems in Special Graphs.** Planar graphs are an important class of graphs. Both problems are considered in planar graphs, and a unified PTAS is presented by Bateni et al. [\[7\]](#page-22-0) for PCTSP and PCSTP. Moreover, they noted that both problems are solvable in polynomial time in bounded treewidth graphs, and their PTAS relies on a reduction to the bounded treewidth cases. They also showed that the Prize Collecting Steiner Forest Problem, which is a generalization of the PCSTP, is significantly harder, and it is APX-hard in planar graphs and Euclidean instances. As for the minor forbidden graphs, which generalizes planar graphs, Demaine et al. [\[15\]](#page-22-0) proposed PTAS's for various optimization problems such as TSP. However, the PTAS's for prize collecting problems, to the best of our knowledge, are unknown.

**Generalizing Euclidean Dimension.** Going beyond Euclidean spaces, doubling dimension [\[4,](#page-22-0) [14,](#page-22-0) [19\]](#page-22-0) is a popular notion of dimensionality. It captures the bounded local growth of Euclidean spaces and does not require any specific Euclidean properties such as vector representation or dot product. A metric space has doubling dimension at most *k*, if every ball can be covered by at most 2*<sup>k</sup>* balls of half the radius. This notion generalizes the Euclidean dimension in that every subset of <sup>R</sup>*<sup>d</sup>* equipped with -<sup>2</sup> has doubling dimension *O*(*d*). Although doubling metrics are more general than Euclidean spaces, recent results show that many optimization problems have similar approximation guarantees for both spaces: there exist PTAS's for the TSP [\[6\]](#page-22-0), a certain version of the TSP with neighborhoods [\[12\]](#page-22-0), and the Steiner forest problem [\[11\]](#page-22-0), in doubling metrics.

**Our Contributions.** In this article, we extend this line of research and give a unified PTAS framework for both PCTSP and PCSTP. We use PCX when the description applies to either problem. Our main result is Theorem [1.1.](#page-2-0)

<sup>1</sup>An undirected connected multi-graph is Eulerian if every vertex has even degree.

<span id="page-2-0"></span>![](_page_2_Picture_2.jpeg)

Fig. 1. Example instance for  $PC^{X}$ .

THEOREM 1.1. For any  $0 < \epsilon < 1$ , there exists an algorithm that, for any  $PC^X$  instance with n terminal points in a metric space with doubling dimension at most k, runs in time

$$n^{O(1)^{O(k)}} \cdot \exp\left(\sqrt{\log n} \cdot O\left(\frac{k}{\epsilon}\right)^{O(k)}\right)$$

and returns a solution that is a  $(1 + \epsilon)$ -approximation with positive constant probability.

**Technical Issues.** As a first trial, one might try to adapt the sparsity framework used in previous PTAS's for the TSP and Steiner forest problems [6, 11, 12] in doubling metrics. The framework typically uses a polynomial-time estimator H on any ball B, which gives a constant approximation for  $PC^X$  on some appropriately defined sub-instance around B. Intuitively, the estimator works because the local behavior of a (nearly) optimal solution can be well estimated by looking at the sub-instance locally. In particular, the following properties are needed in this framework:

- If H(*B*) is large, then the optimal solution for the sub-instance induced on *B* is large; moreover, any (nearly) optimal solution for the global instance would have a large part of its cost due to *B*.
- If H(*B*) is small, then for any (nearly) optimal solution *F* for the global instance, the cost of *F* contributed by the sub-instance due to *B* should be small.

While the first property is somehow straightforward, the following example shows that the second property is non-trivial to achieve in  $PC^X$ .

**Example Instance: Figure 1.** The example is defined on the real line. The terminals are grouped into two clusters. The left cluster contains 2m terminals, and the right cluster contains m terminals. Within each cluster, the distance between adjacent terminals is 1. The two clusters are at distance l apart. The penalty for each terminal is t. The parameters are chosen such that  $l \gg mt$  and  $t \gg m$ . Observe that for  $PC^X$ , the optimal solution is to visit all the terminals in the left cluster with total edge weights O(m) and incur the penalty mt for the terminals in the right cluster. The reason is that it will be too costly to add an edge to connect terminals from different clusters, and it is better to visit the cluster with more terminals and suffer the penalty for the cluster with fewer terminals. **Local Estimator Fails on the Example Instance.** Suppose the estimator is applied around a ball B centered at some terminal in the right cluster with radius r. Then, any constant-approximate solution for the sub-instance needs to connect all  $\Theta(r)$  terminals in the ball, since the penalty for any single terminal is too large. This costs  $\Theta(r)$ . However, in the optimal solution, no terminal in the right cluster is visited and all penalties are taken, which has cost  $\Omega(tr)$ . Hence, the estimator fails to serve as an upper bound for the contribution by ball B to the cost of an optimal solution.

The conclusion is that the optimal solution of a local sub-instance can differ a lot from how an optimal global solution behaves for that sub-instance.

24:4 T.-H. Hubert Chan et al.

**Our Insight: Trading between Weight and Penalty.** Our example in Figure [1](#page-2-0) shows that the points a local optimal solution visits in a sub-instance can be very different from the points in the sub-instance visited by a global optimal solution. Our intuition is that the optimal cost of a sub-instance should reflect part of the cost in a global optimal solution due to the sub-instance. In other words, if a sub-instance has large optimal cost, then any global solution either (1) has a large weight within the sub-instance, or (2) suffers a large penalty due to unvisited terminals in the sub-instance. This insight leads to the following key ingredients of our solution. Indeed, similar observations have been made in Reference [\[7\]](#page-22-0), which gave PTAS's for prize-collecting problems in planar graphs.

**Inferring Local Behavior from Estimator.** In Lemma [3.2,](#page-9-0) we show that the value returned by the local estimator (which consists of both the weight and the penalty) on a ball *B* gives an upper bound on the weight*w*(*F* |*<sup>B</sup>* ) of any (near) optimal solution *F* inside ball *B*. We emphasize that this estimator is an upper bound for the *weight w*(*F* |*<sup>B</sup>* ) *only* and is *not* an upper bound for both the weight and penalty of the optimal solution inside the ball. In the example in Figure [1,](#page-2-0) a global optimal solution does not visit the right cluster at all, and hence, the local estimator on the right cluster does give an upper bound on the *weight* part of the global solution due to the right cluster. This turns out to be sufficient, because the sparsity of a solution is defined with respect to only the weight part (and not the penalty part).

Hence, the local estimator can be used in the sparsity decomposition framework [\[6,](#page-22-0) [11,](#page-22-0) [12\]](#page-22-0) to identify a *critical* instance *W*<sup>1</sup> (i.e., the local estimator reaches some threshold, but still not too large) around some ball *B*. Since the instance *W*<sup>1</sup> is sparse enough, an approximate solution *F*<sup>1</sup> can be obtained by the dynamic program framework. Then, one can recursively solve for an approximate solution *F*<sup>2</sup> for the remaining instance*W*2. However, we need to carefully define *W*<sup>2</sup> and combine the solutions *F*<sup>1</sup> and *F*2, because, as we remarked before, even if the approximate algorithm returns *F*<sup>1</sup> for the instance*W*1, a near optimal global solution might not visit any terminals in *W*1.

**Adaptive Recursion.** In all previous applications of the sparsity decomposition framework, after a critical ball *B* around some center *u* is identified, the original instance is decomposed into sub-instances *W*<sup>1</sup> and *W*<sup>2</sup> that can be solved independently.

An issue in applying this framework is that after obtaining solutions *F*<sup>1</sup> and *F*<sup>2</sup> for the sub-instances, in the case that *F*<sup>1</sup> and *F*<sup>2</sup> are far away from each other as in our example in Figure [1](#page-2-0) where it is too costly to connect them directly, it is not clear immediately which of *F*<sup>1</sup> and *F*<sup>2</sup> should be the weight part of the global solution and which would become the penalty part.

We use a novel idea of the adaptive recursion, in which *W*<sup>2</sup> depends on the solution *F*<sup>1</sup> returned for *W*1. The high-level idea is that in defining the instance *W*2, we add an extra terminal point at*u*, which becomes a representative for solution *F*1. The penalty of*u* in*W*<sup>2</sup> is the sum of the penalties of terminals in *W*<sup>1</sup> minus the cost *c*(*F*1) of solution *F*1. After a solution *F*<sup>2</sup> for *W*<sup>2</sup> is returned, if *F*<sup>2</sup> does not visit the terminal *u*, then edges in *F*<sup>1</sup> are discarded, otherwise the edges in *F*<sup>1</sup> and *F*<sup>2</sup> are combined to return a global solution.

We can see that in either case, the sum *c*(*F*1) + *c*(*F*2) of the costs of the two solutions reflects the cost of the global solution. In the first case, *F*<sup>2</sup> does not visit *u* and hence,*c*(*F*2) contains the penalty due to *u*, which is the penalties of unvisited terminals in *W*<sup>1</sup> minus *c*(*F*1). Therefore, when *c*(*F*1) is added back, the sum simply contains the original penalties of unvisited terminals in *W*1.

In the second case, *F*<sup>2</sup> does visit *u* and does not incur a penalty due to *u*. Therefore, *c*(*F*1) + *c*(*F*2) does reflect the cost of the global solution after combining *F*<sup>1</sup> and *F*2.

**Revisiting the Sparsity Structural Lemma.** Many PTAS's in the literature for TSP-like problems in doubling metrics rely on the sparsity structural lemma [\[6,](#page-22-0) Lemma 3.1]. Intuitively, it says that if a solution is sparse, then there exists a *structurally light* solution that is (1 + *ϵ* )-approximate (see Theorem [5.8\)](#page-15-0). Hence, one can restrict the search space to structurally light solutions, which can be explored by a dynamic programming algorithm. Because of the significance of this lemma, we believe that it is worthwhile to give it a more formal inspection, and in particular, resolve some significant technical issues as follows:

**Issue with Conditioning on the Randomness of Hierarchical Decomposition.** Given a hierarchical decomposition and a solution *T* , the first step is to reroute the solution such that every cluster is only visited through some designated points known as *portals*. The randomness in the hierarchical decomposition is used to argue that the expected increase in cost to make the solution portal-respecting is small.

However, typically the randomness in the hierarchical decomposition is still needed in subsequent arguments. Hence, if one analyzes the portal-respecting procedure as a conceptually separate step, then subsequent uses of the randomness of the hierarchical decomposition need to condition on the event that the portal-respecting step does not increase the cost too much. Moreover, edges added in the portal-respecting step are actually random objects depending on the hierarchical decomposition, and hence, will in fact cross some clusters with probability 1. Unfortunately, even in the original paper by Talwar [\[21\]](#page-22-0) on the QPTAS for TSP in doubling metrics, these issues were not addressed properly.

**Issues with Patching Procedure.** A patching procedure is typically used to reduce the number of times a cluster is crossed. In the literature, after reducing the number of crossings, the triangle inequality is used to implicitly add some shortcutting edges outside the cluster. However, it is never argued whether these new shortcutting edges are still portal-respecting. It is plausible that making them portal-respecting might introduce new crossings.

From the above discussion, it is evident that one should consider the portal-respecting step and the patching procedure together, because they both rely on the randomness of the hierarchical decomposition. To make our arguments formal, we need a more precise notation to describe portals, and in Section [5,](#page-13-0) we actually revisit the whole randomized hierarchical decomposition to make all relevant definitions precise. In Theorem [5.8,](#page-15-0) we analyze the portal-respecting step and the patching procedure together through a sophisticated accounting argument so the patching cost is eventually charged back to the original solution (as opposed to stopping at the transformed portal-respecting solution).

Moreover, we give a unified patching lemma that works for both PCTSP and PCSTP. Even though our proofs use similar ideas as previous works, the charging argument is significantly different. Specifically, our argument does not rely on the small MST lemma [\[21,](#page-22-0) Lemma 6], which was also used in Reference [\[6\]](#page-22-0).

**Paper Organization.** Section [2](#page-5-0) gives the formal notation and describes the outline of the sparsity decomposition framework to solve PCX. Section [3](#page-8-0) gives the properties of the local sparsity estimator. Section [4](#page-10-0) gives the technical details of the sparsity decomposition and shows that approximate solutions in sub-instances can be combined to give a good approximation to the global instance. Section [5](#page-13-0) revisits the hierarchical decomposition and sparse instance frameworks for <span id="page-5-0"></span>24:6 T.-H. Hubert Chan et al.

TSP-like problems in doubling metrics; the notation is more involved than previous works, and readers who are already familiar with the literature might choose to skip it during the first read. Section 6 gives the details of the dynamic program for sparse instances and the analysis of its running time.

#### 2 PRELIMINARIES

We consider a metric space M=(X,d) (see References [16, 20] for more details on metric spaces), where we refer to an element  $x \in X$  as a point or a vertex. For  $x \in X$  and  $\rho \ge 0$ , a ball  $B(x,\rho)$  is the set  $\{y \in X \mid d(x,y) \le \rho\}$ . The diameter Diam(Z) of a set  $Z \subseteq X$  is the maximum distance between points in Z. For  $S,T \subset X$ , we denote  $d(S,T) := \min\{d(x,y) : x \in S, y \in T\}$ , and for  $u \in X$ ,  $d(u,T) := d(\{u\},T)$ . Given a positive integer m, we denote  $[m] := \{1,2,\ldots,m\}$ .

A set  $S \subseteq X$  is a  $\rho$ -packing, if any two distinct points in S are at a distance more than  $\rho$  away from each other. A set S is a  $\rho$ -cover for  $Z \subseteq X$ , if for any  $z \in Z$ , there exists  $x \in S$  such that  $d(x, z) \leq \rho$ . A set S is a  $\rho$ -net for Z, if S is a  $\rho$ -packing and a  $\rho$ -cover for Z. We assume the access to an oracle that takes a series of balls  $\{B_i\}_i$  where each  $B_i$  is identified by the center and radius, and returns a point  $x \in X$  such that  $\forall i, x \notin B_i$ . A greedy algorithm can construct a  $\rho$ -net efficiently given the access to this oracle.

We consider metric spaces with *doubling dimension* [4, 19] at most k; this means that for all  $x \in X$ , for all  $\rho > 0$ , every ball  $B(x, 2\rho)$  can be covered by the union of at most  $2^k$  balls of the form  $B(z, \rho)$ , where  $z \in X$ . The following fact captures a standard property of doubling metrics:

FACT 2.1 (PACKING IN DOUBLING METRICS [19]). Suppose in a metric space with doubling dimension at most k, a  $\rho$ -packing S has diameter at most R. Then,  $|S| \leq (\frac{2R}{\rho})^k$ .

**Edges.** An edge<sup>3</sup> e is an unordered pair  $e = \{x, y\} \in \binom{X}{2}$  whose weight w(e) = d(x, y) is induced by the metric space (X, d). Given a set F of edges, its vertex set  $V(F) := \bigcup_{e \in F} e \subset X$  is the vertices covered (or *visited*) by the edges in F. If  $T \subset X$  is a set of vertices, then we use the shorthand  $T \setminus F := T \setminus V(F)$  to denote the vertices in T that are not covered by F.

**Problem Definition.** We give a unifying framework for the prize collecting traveling salesman problem (PC<sup>TSP</sup>) and the prize collecting Steiner tree problem (PC<sup>STP</sup>), and we use PC<sup>X</sup> when the description applies to both problems. An instance  $W = (T, \pi)$  of PC<sup>X</sup> consists of a set  $T \subset X$  of *terminals* (where |W| := |T| = n) and a penalty function  $\pi : T \to \mathbb{R}_+$ . The goal is to find a (multi-)set  $F \subset \binom{X}{2}$  of edges with minimum  $\operatorname{cost}^4 c_W(F) := w(F) + \pi(T \setminus F)$ , such that the following additional conditions are satisfied for each specific problem:

- For PC<sup>TSP</sup>, the edges in the multi-set F form a circuit on V(F); for |V(F)| = 1, F contains only a single self-loop (with zero weight).
- For PC<sup>STP</sup>, the edges F form a connected graph on V(F), where we also allow the degenerate case when F is a singleton containing a self-loop (of weight zero). The vertices in  $V(F) \setminus T$  are known as *Steiner* points.

**Simplifying Assumptions and Rescaling Instance.** Fix some constant  $\epsilon > 0$ . Since we consider asymptotic running time to obtain  $(1 + \epsilon)$ -approximation for PC<sup>X</sup>, we consider sufficiently large  $n > \frac{1}{\epsilon}$ . Since F can contain a self-loop, an optimal solution covers at least one terminal u. Moreover, there is some terminal v (which could be the same as u) such that the solution covers v and does

<sup>&</sup>lt;sup>2</sup>Such an oracle is trivial to construct for finite metric spaces. It may also be efficiently constructed for many special infinite metric spaces, such as bounded dimensional Euclidean spaces.

 $<sup>^3</sup>$ To have a complete description, we also need the notion of self-loop, which is simply a singleton  $\{x\}$ .

<sup>&</sup>lt;sup>4</sup>When the context is clear, we drop the subscript in  $c_W(\cdot)$ .

<span id="page-6-0"></span>not cover any terminal v' with d(u, v') > d(u, v). Since we aim for polynomial time algorithms, we can afford to enumerate the  $O(n^2)$  choices for u and v.

For some choice of u and v, suppose R:=d(u,v). Then, R is a lower bound on the cost of an optimal solution. Moreover, the optimal solution F has weight w(F) at most nR, and hence, we do not need to consider points at distances larger than nR from u. Since F contains at most 2n edges (because of Steiner points in  $PC^{STP}$ ), if we consider an  $\frac{\epsilon R}{32n^2}$ -net S for X and replace every point in F with its closest net-point in S, then the cost increases by at most  $\epsilon$  · OPT. Hence, after rescaling, we can assume that inter-point distance is at least 1 and we consider distances up to  $O(\frac{n^3}{\epsilon}) = \text{poly}(n)$ . By the packing property of doubling dimension (Fact 2.1), we can hence assume  $|X| \leq O(\frac{n}{\epsilon})^{O(k)} \leq O(n)^{O(k)}$ , where the last inequality is by the assumption that  $n > \frac{1}{\epsilon}$ .

**Hierarchical Nets.** As in Reference [6], we consider some parameter  $s = (\log n)^{\frac{c}{k}} \ge 4$ , where 0 < c < 1 is a universal constant that is sufficiently small (as required in Lemma 6.2 such that the term  $O(\log n)^{O(s)^k} = o(n)$ ). Rescale and reduce the instance as in the above paragraph so the minimum intra-point distance is 1, and the whole instance has diameter  $D := \operatorname{poly}(n)$ . Set  $L := O(\log_s D) = O(\log_s n) = O(\frac{k \log n}{\log \log n})$ . A greedy algorithm can construct  $N_L \subseteq N_{L-1} \subseteq \cdots \subseteq N_1 \subseteq N_0 = N_{-1} = \cdots = X$  such that for each i,  $N_i$  is an  $s^i$ -net for  $N_{i-1}$ , where we say distance scale  $s^i$  is of height i. Note that  $|N_L| = 1$ .

**Net-Respecting Solution.** As defined in Reference [6], a graph F is net-respecting with respect to  $\{N_i\}_{i\in[L]}$  and  $\epsilon>0$  if for every edge  $\{x,y\}$  in F, both x and y belong to  $N_i$ , where  $s^i\leq \epsilon\cdot d(x,y)< s^{i+1}$ . By Reference [6, Lemma 1.6], any graph F may be converted to a net-respecting F' visiting all points that F visits, and  $w(F')\leq (1+O(\epsilon))\cdot w(F)$ . We restate it as follows:

Lemma 2.1 (Lemma 1.6 of [6]). Given  $0 < \epsilon < 1$ , every subset of edges F may be converted to a subset of edges F' such that every edge of F' is net-respecting, F' visits every point that F visits, and  $w(F') \le (1 + 16\epsilon) \cdot w(F)$ .

Given an instance W of a problem, let OPT(W) be an optimal solution; when the context is clear, we also use OPT(W) to denote the cost c(OPT(W)), which includes both its weight and the incurred penalty; similarly,  $OPT^{nr}(W)$  refers to an optimal net-respecting solution.

#### 2.1 Overview

We achieve a PTAS for PC<sup>X</sup> by a unified framework, which is based on the framework of sparse instance decomposition as in References [6, 11, 12].

**Sparse Solution [6].** Given an edge set F and a subset  $S \subseteq X$ ,  $F|_S := \{e \in F : e \subseteq S\}$  is the edges in F totally contained in S. An edge set F is called q-sparse, if for all  $i \in [L]$  and all  $u \in N_i$ ,  $w(F|_{B(u,3s^i)}) \le q \cdot s^i$ .

**Sparsity Structural Property.** (Revisited in Theorem 5.8) An important technical lemma [6, Lemma 3.1] in this framework states that if a (net-respecting) solution F is sparse, then with constant probability, there is some  $(1 + \epsilon)$ -approximate solution  $\widehat{F}$  that is *structurally light* with respect to some randomized *hierarchical decomposition* (see Section 5.1). Then, a bottom-up dynamic program (given in Section 6) based on the hierarchical decomposition searches for the best solution with the lightness structural property in polynomial time.

Remark 2.1. We observe that this technical lemma is used crucially in all previous works on PTAS's for TSP variants in doubling metrics. Hence, we believe that its proof should be verified rigorously. In Section 1, we outlined the technical issue in the original proof [6], and this issue actually appeared as far BACK as in the first paper on TSP for doubling metrics [21]. In Section 5, we give a detailed description to complete the proof of this important lemma.

<span id="page-7-0"></span>24:8 T.-H. Hubert Chan et al.

**Generic Algorithm.** We describe a generic framework that applies to  $PC^X$ . Similar framework is also used in [6, 11, 12] to obtain PTAS's for TSP related problems. Given an instance W, we describe the recursive algorithm ALG(W) as follows. This description is mostly the same with that in [11], except that the decomposition in Step 4 is more involved.

- **1. Base Case.** If |W| = n is smaller than some constant threshold, solve the problem by brute force, recalling that  $|X| \le O(\frac{n}{\epsilon})^{O(k)}$ .
- **2. Sparse Instance.** Construct the hierarchical nets  $\{N_i\}_{i \leq L}$ . If for all  $i \in [L]$ , for all  $u \in N_i$ ,  $H_u^{(i)}(W)$  is at most  $q_0 \cdot s^i$ , for some appropriate threshold  $q_0$ , call the subroutine  $\mathsf{DP}(W)$  to return a solution, and terminate.
- **3. Identify Critical Instance.** Otherwise, let i be the smallest height such that there exists  $u \in N_i$  with *critical*  $H_u^{(i)}(W) > q_0 \cdot s^i$ ; in this case, choose  $u \in N_i$  such that  $H_u^{(i)}(W)$  is maximized.
- **4. Divide and Conquer.** Define a sub-instance  $W_1$  from around the critical instance (possibly using randomness). Loosely speaking,  $W_1$  is a sparse enough sub-instance induced in the region around u at distance scale  $s^i$ . Since it is sparse enough, we apply the dynamic programming algorithm (defined in Section 6) on  $W_1$  and get solution  $F_1$ .

We define an appropriate sub-instance  $W_2$  with the information of  $F_1$ . Intuitively,  $W_2$  captures the remaining sub-problem not included in  $W_1$ . We emphasize that as opposed to previous work [6, 11, 12],  $W_2$  can depend on  $F_1$  (through the choice of the penalty function). Moreover, we ensure that any solution  $F_2$  of  $W_2$  can be extended to  $F_2 \leftrightarrow_u F_1$  as a solution for W, and the following holds:

$$c_W(F_2 \leftrightarrow_u F_1) \le c_{W_1}(F_1) + c_{W_2}(F_2).$$
 (1)

We solve  $W_2$  recursively and suppose the solution is  $F_2$ . We note that  $H_u^{(i)}(W_2) \le q_0 \cdot s^i$ , and hence the recursion will terminate. The detailed algorithm for defining  $W_1$  and  $W_2$  can be found in Figure 3.

Moreover, the following property holds:

$$\mathbf{E}[\mathsf{OPT}(W_1)] \le \frac{1}{1 - \epsilon} \cdot (\mathsf{OPT}^{nr}(W) - \mathbf{E}[\mathsf{OPT}^{nr}(W_2)]),\tag{2}$$

where the expectation is over the randomness of the decomposition.

We return  $F := F_2 \leftrightarrow_u F_1$  as a solution to W.

Fig. 2. Algorithm Outline.

**Sparsity Heuristic.** As in References [6, 11, 12], we estimate the local sparsity of an optimal net-respecting solution with a heuristic. For  $i \in [L]$  and  $u \in N_i$ , given an instance W, the heuristic  $H_u^{(i)}(W)$  is supposed to estimate the sparsity of an optimal net-respecting solution in the ball  $B' := B(u, O(s^i))$ . We shall see in Section 3 that the heuristic actually gives a constant approximation to some appropriately defined sub-instance W' in the ball B'.

**Divide and Conquer.** Once we have a sparsity estimator, the original instance can be decomposed into sparse sub-instances whose approximate solutions can be found efficiently. As we shall see, the partial solutions are combined with the following extension operator. The algorithm outline is described in Figure 2.

Definition 2.2 (Solution Extension). Given two partial solutions F and F' of edges, we define the extension of F with F' at point u as  $F \leftarrow_u F' := \begin{cases} F \cup F', & \text{if } u \in V(F) \cap V(F'); \\ F, & \text{otherwise.} \end{cases}$ 

**Analysis of Approximation Ratio.** We follow the inductive proof as in Reference [6] to show that with constant probability (where the randomness comes from DP), ALG(W) in Figure 2 returns

<span id="page-8-0"></span>a solution with expected length at most  $\frac{1+\epsilon}{1-\epsilon} \cdot \mathsf{OPT}^{nr}(W)$ , where expectation is over the randomness of decomposition into sparse instances in Step 4.

As we shall see, in ALG(W), the subroutine DP is called at most poly(n) times (either explicitly in the recursion or in the heuristic  $H^{(i)}$ ). Hence, with constant probability, all solutions returned by all instances of DP have appropriate approximation guarantees.

Suppose  $F_1$  and  $F_2$  are solutions returned by  $DP(W_1)$  and  $ALG(W_2)$ , respectively. We use  $c_i$  as a shorthand for  $c_{W_i}$ , for i=1,2, and c as a shorthand for  $c_W$ . Since we assume that  $W_1$  is sparse enough and DP behaves correctly,  $c_1(F_1) \leq (1+\epsilon) \cdot OPT(W_1)$ . In Step 4, Equation (2) guarantees that  $E[OPT(W_1)] \leq \frac{1}{1-\epsilon} \cdot (OPT^{nr}(W) - E[OPT^{nr}(W_2)])$ . These combined imply that

$$\mathbf{E}[c_1(F_1)] \le \frac{1+\epsilon}{1-\epsilon} \cdot (\mathsf{OPT}^{nr}(W) - \mathbf{E}[\mathsf{OPT}^{nr}(W_2)]). \tag{1}$$

However, the induction hypothesis states that  $\mathbf{E}[c_2(F_2)|W_2] \leq \frac{1+\epsilon}{1-\epsilon} \cdot \mathsf{OPT}^{nr}(W_2)$ . Combining with Equation (1),

$$\mathbf{E}[c_1(F_1) + c_2(F_2)] \le \frac{1+\epsilon}{1-\epsilon} \cdot \mathsf{OPT}^{nr}(W). \tag{2}$$

Finally, by Equation (1),  $c(F_2 \leftrightarrow_u F_1) \le c_1(F_1) + c_2(F_2)$ . Hence, it follows that

$$\mathbf{E}[\mathsf{ALG}(W)] \leq \mathbf{E}[c_1(F_1) + c_2(F_2)] \leq \frac{1+\epsilon}{1-\epsilon} \cdot \mathsf{OPT}^{nr}(W) = (1+O(\epsilon)) \cdot \mathsf{OPT}(W),$$

achieving the desired ratio, where the last inequality is by Equation (2).

**Analysis of Running Time.** As mentioned above, if  $H_u^{(i)}(W)$  is found to be critical, then in the decomposed sub-instances  $W_1$  and  $W_2$ ,  $H_u^{(i)}(W_2)$  should be small. Hence, it follows that there will be at most  $|X| \cdot L = \text{poly}(n)$  recursive calls to ALG. Therefore, as far as obtaining polynomial running times, it suffices to analyze the running time of the dynamic program DP. The details are in Section 6.

#### 3 SPARSITY ESTIMATOR FOR PCX

Recall that in the framework outlined in Section 2, given an instance W of  $PC^X$ , we wish to estimate the weight of  $OPT^{nr}(W)|_{B(u,3s^i)}$  with some heuristic  $H_u^{(i)}(W)$ . We consider a more general sub-instance associated with the ball  $B(u,ts^i)$  for  $t \ge 1$ .

**Auxiliary Sub-instance.** Given an instance  $W = (T, \pi)$ ,  $i \in [L]$ ,  $u \in N_i$ , and  $t \ge 1$ , the sub-instance  $W_u^{(i,t)}$  is characterized by terminal set  $T \cap B(u,ts^i)$ , equipped with penalties given by the same  $\pi$ . Using the classical (deterministic) 2-approximation algorithms by Goemans and Williamson for  $PC^X$  [18], we obtain a 2-approximation and then make it net-respecting (i.e., via Lemma 2.1) to produce solution  $F_u^{(i,t)}$ , which has  $\cot c(F_u^{(i,t)}) \le 2(1 + O(\epsilon)) \cdot OPT(W_u^{(i,t)})$ .

**Defining the Heuristic.** The heuristic is defined as  $H_u^{(i)}(W) := c(F_u^{(i,4)})$ .

To show that the heuristic gives a good upper bound on the local sparsity of an optimal net-respecting solution, we need the following structural result in Proposition 3.1 [11, Lemma 3.2] on the existence of long chain in well-separated terminals in a Steiner tree. As we shall see, the corresponding argument for the case PC<sup>TSP</sup> is trivial.

Given an edge set F, a *chain* in F is specified by a sequence of points  $(p_1, p_2, \ldots, p_l)$  such that there is an edge  $\{p_i, p_{i+1}\}$  in F between adjacent points, and the degree of an internal point  $p_i$  (where  $2 \le i \le l-1$ ) in F is exactly 2.

PROPOSITION 3.1 (Well-Separated Terminals Contains A Long Chain). Suppose S and T are sets in a metric space with doubling dimension at most k such that  $Diam(S \cup T) \leq D$ , and  $d(S,T) \geq \tau D$ , where  $0 < \tau < 1$ . Suppose F is an optimal net-respecting Steiner tree covering the terminals in

<span id="page-9-0"></span> $S \cup T$ . Then, there is a chain in F with weight at least  $\frac{\tau^2}{4096k^2} \cdot D$  such that any internal point in the chain is a Steiner point.

LEMMA 3.2 (LOCAL SPARSITY ESTIMATOR). Let F be an optimal net-respecting solution for an instance W of  $PC^X$ . Then, for any  $i \in [L]$ ,  $u \in N_i$  and  $t \ge 1$ , we have

$$w(F|_{B(u,ts^i)}) \leq c(F_u^{(i,t+1)}) + O\left(\frac{skt}{\epsilon}\right)^{O(k)} \cdot s^i.$$

PROOF. We follow the proof strategy in Reference [11, Lemma 3.3], except that now a feasible solution needs not visit all terminals and can incur penalties instead. We denote  $B := B(u, ts^i)$  and  $\widehat{B} := B(u, (t+1)s^i)$ .

Given an optimal net-respecting solution F for instance W of  $PC^X$ , we shall construct another net-respecting solution in the following steps:

- (1) Remove edges in  $F|_B$ .
- (2) Add edges  $F_u^{(i,t+1)}$  corresponding to some approximate solution to the instance  $W_u^{(i,t+1)}$  restricted to the ball  $\widehat{B}$ .
- (3) Let  $\eta := \Theta(\frac{\epsilon}{(t+1)k^2})$ , where the constant in Theta depends on Proposition 3.1. Let j be the integer such that  $s^j \le \max\{1, \Theta(\frac{\epsilon}{(t+1)k^2}) \cdot s^i\} < s^{j+1}$ .

Add edges in a minimum spanning tree H of  $N_j \cap B(u, (t+2)s^i)$  and edges to connect H to  $F_u^{(i,t+1)}$ .

Convert each added edge into a net-respecting path if necessary (i.e., using Lemma 2.1). Observe that the weight of edges added in this step is  $O(\frac{stk}{\epsilon})^{O(k)} \cdot s^i$ .

(4) So far, we have accounted for every terminal inside  $\widehat{B}$ , which is either visited or charged with its penalty according to  $c(F_u^{(i,t+1)})$ . We will give a more detailed description to ensure that the terminals outside  $\widehat{B}$  that are covered by F will still be covered by the new solution. For  $PC^{TSP}$ , we will show that this step can be achieved by increasing the weight by at most  $O(\frac{stk}{\epsilon})^{O(k)} \cdot s^i$ ; for  $PC^{STP}$ , this can be achieved by replacing some edges without increasing the weight.

Hence, after the claim in Step 4 is proved, the optimality of F implies the result. **Ensuring Terminals Outside**  $\widehat{B}$  **are accounted for.** We achieve this by considering the following steps:

- (1) Consider a connected component C in  $F \setminus (F|_B)$ . Recall that the goal is to make sure that all terminals outside  $\widehat{B}$  that are visited by C will also be visited in the new solution.
- (2) Pick some x in  $C \cap B$ . If no such x exists, this implies that we have the trivial situation  $F|_B = \emptyset$ . Let  $\widehat{C} \subseteq C$  be the maximal connected component containing x that is contained within  $\widehat{B}$ . Define  $S := \widehat{C} \cap B$  (which contains x) and  $T := \{y \in \widehat{C} \cap \widehat{B} : \exists v \notin \widehat{B}, \{y, v\} \in F\}$ , which corresponds to the points that are connected to the outside  $\widehat{B}$ , which is the set of vertices in  $\widehat{C}$  that are directed connected by F to some point outside  $\widehat{B}$ . Again, the case that  $T = \emptyset$  is trivial.

Case (a): There exists  $y \in T$ ,  $d(u, y) \le (t + \frac{1}{2})s^i$ . In this case, this implies there is some  $v \notin \widehat{B}$  such that  $\{y, v\} \in F$  and  $d(y, v) \ge \frac{s^i}{2}$ . Since F is net-respecting, this implies that  $y \in N_j$  and hence, the component  $\widehat{C}$  (and also C) is already connected to H.

Case (b): For all  $y \in T$ ,  $d(u, y) > (t + \frac{1}{2})s^i$ . We next show that there is a long chain contained in  $\widehat{C}$ . For PC<sup>TSP</sup>, this is trivial, because we know that T contains only y, and  $\widehat{C}$  is a chain from a = x to b = y of length at least  $d(x, y) \ge \frac{s^i}{2}$ .

ACM Transactions on Algorithms, Vol. 16, No. 2, Article 24. Publication date: March 2020.

<span id="page-10-0"></span>For PC<sup>STP</sup>, by the optimality of F, it follows that  $\widehat{C}$  is an optimal net-respecting Steiner tree covering vertices in  $S \cup T$ . Hence, using Proposition 3.1,  $\widehat{C}$  contains some chain from a to b with length at least  $4\eta s^i$  (where the constant in the Theta in the definition of  $\eta$  is chosen such that this holds).

Once we have found this chain from a to b, we remove the edges in this chain. Hence, we can use this extra weight to connect a and b to their corresponding closest points in  $N_j$  via a net-respecting path; observe that for  $PC^{TSP}$ , it suffices to connect only b = y to its closest point in  $N_j$ .

Finally, observe that for PC<sup>TSP</sup>, it is possible to carry out the above procedures such that all vertices with odd degrees are in the minimum spanning tree H. Therefore, extra edges are added to ensure that the degree of every vertex is even to ensure the existence of a Euler circuit. This has extra cost at most  $w(H) \le O(\frac{stk}{\epsilon})^{O(k)} \cdot s^i$ . This completes the proof.

COROLLARY 3.3 (THRESHOLD FOR CRITICAL INSTANCE). Suppose F is an optimal net-respecting solution for an instance W of  $PC^X$ , and  $q \ge \Theta(\frac{sk}{\epsilon})^{\Theta(k)}$ . If for all  $i \in [L]$  and  $u \in N_i$ ,  $H_u^{(i)}(W) \le qs^i$ , then F is 2q-sparse.

#### 4 DECOMPOSITION INTO SPARSE INSTANCES

In Section 3, we define a heuristic  $H_u^{(i)}(W)$  to detect a critical instance around some point  $u \in N_i$  at distance scale  $s^i$ . We next describe how the instance W of  $PC^X$  can be decomposed into  $W_1$  and  $W_2$  such that Equations (1) and (2) in Section 2.1 are satisfied.

**Decomposing a Critical Instance.** We define a threshold  $q_0 := \Theta(\frac{sk}{\epsilon})^{\Theta(k)}$  according to Corollary 3.3. As stated in Section 2.1, a critical instance is detected by the heuristic when a smallest  $i \in [L]$  is found for which there exists some  $u \in N_i$  such that  $H_u^{(i)}(W) = c(F_u^{(i,4)}) > q_0 s^i$ , recalling that  $F_u^{(i,t)}$  was defined in Section 3 as a constant approximate net-respecting solution for an auxiliary instance. Moreover, in this case,  $u \in N_i$  is chosen to maximize  $H_u^{(i)}(W)$ . To achieve a running time with an  $\exp(O(1)^{k \log(k)})$  dependence on the doubling dimension k, we also apply the technique in Reference [12] to choose the cutting radius carefully.

Claim 4.1 (Choosing Radius of Cutting Ball). Denote  $T(\lambda) := c(F_u^{(i,4+2\lambda)})$ . Then, there exists  $0 \le \lambda < k$  such that  $T(\lambda + 1) \le 30k \cdot T(\lambda)$ .

PROOF. A similar proof is found in Reference [11], and we adapt the proof to include penalties of unvisited terminals. Suppose the contrary is true. Then, it follows that  $\mathsf{T}(k) > (30k)^k \cdot \mathsf{T}(0)$ . We shall obtain a contradiction by showing that there is a solution for the instance  $W_u^{(i,4+2k)}$  corresponding to  $\mathsf{T}(k) = c(F_u^{(i,4+2k)})$  with small weight. Define  $N_i'$  to be the set of points in  $N_i$  that cover  $B(u,(2k+5)s^i)$ .

We construct an edge set F that is a solution to the instance  $W_u^{(i,4+2k)}$ . For each  $v \in N_i'$ , we include the edges in the solution  $F_v^{(i,4)}$ , whose cost includes the edge weights and the penalties of unvisited terminals. By the choice of u, the sum of the costs of these partial solutions is at most  $|N_i'| \cdot T(0)$ .

We next stitch these solutions together by adding extra edges of total weight at most  $2 \cdot 2(2k + 5) \cdot |N_i'| \cdot s^i$ ; for PC<sup>TSP</sup>, we make sure that the degree of every vertex is even to form a Euler tour. Hence, the resulting solution F has cost  $c(F) \le 4(2k + 5)|N_i'| \cdot s^i + |N_i'| \cdot \mathsf{T}(0) \le (15k)^k \cdot \mathsf{T}(0)$ . Therefore, we have an upper bound for the heuristic  $\mathsf{T}(k) \le 2(1 + \Theta(\epsilon)) \cdot w(F) \le (30)^k \cdot \mathsf{T}(0)$ , which gives us the desired contradiction.

Lemma 4.1 (Combining Solutions of Sub-Instances). Suppose instance  $W_1$  is defined with cost function  $c_1$  and instance  $W_2$  is defined with respect to  $F_1$  of  $W_1$  as in Figure 3. Furthermore, suppose  $\widehat{F}_2$  is a solution to instance  $W_2$ , whose cost function is denoted as  $c_2$ . Then, we have the following:

<span id="page-11-0"></span>24:12 T.-H. Hubert Chan et al.

**Cutting Ball and Sub-Instances.** Let u be the center of the critical instance (see Figure 2). Suppose  $\lambda \geq 0$  is picked as in Claim 4.1, and sample  $h \in [0, \frac{1}{2}]$  uniformly at random. Define  $B := B(u, (4+2\lambda+h)s^i)$ . The original instance  $W = (T, \pi)$  is decomposed into instances  $W_1$  and  $W_2$  as follows:

- For  $W_1 = (T_1, \pi_1)$ , the terminal set is  $T_1 := (B \cap T) \cup \{u\}$ , where for  $v \neq u$   $\pi_1(v) := \pi(v)$  and  $\pi_1(u) := +\infty$ . We denote the cost function associated with  $W_1$  by  $c_1$ .
- Suppose  $F_1$  is the (random) solution for instance  $W_1$  (that covers u) returned by the dynamic program for sparse instances in Section 5. Then, instance  $W_2 = (T_2, \pi_2)$  is defined with respect to  $F_1$ . The terminal set is  $T_2 := (T \setminus B) \cup \{u\}$ . For  $v \in T_2 \setminus \{u\}$ ,  $\pi_2(v) := \pi(v)$  is the same; however,  $\pi_2(u) := \pi(T \cap B) c_1(F_1) = \pi(T \cap B \cap F_1) w(F_1)$ .

Observe that the instance  $W_2$  depends on  $F_1$  through the choice of the penalty for u.

Fig. 3. Algorithm for Defining Subinstances.

- (i) Suppose  $\widehat{F}_1$  is any solution to  $W_1$  that contains u, and let  $F := \widehat{F}_2 \leftrightarrow_u \widehat{F}_1$ . If  $\widehat{F}_2$  covers u, then  $F = \widehat{F}_2 \cup \widehat{F}_1$  is a solution to W with cost  $c(F) \leq c_1(\widehat{F}_1) + c_2(\widehat{F}_2)$ ; if  $F_2$  does not cover u, then  $F = \widehat{F}_2$  is a solution to W with cost  $c(F) \leq c_1(F_1) + c_2(\widehat{F}_2)$ . This implies (1) in Section 2.1.
- (ii) The sub-instance  $W_2$  does not have a critical instance with height less than i, and  $H_u^{(i)}(W_2) = 0$ .
- (iii)  $H_{u}^{(i)}(W_{1}) \leq O(s)^{O(k)} \cdot q_{0} \cdot s^{i}$ .

PROOF. For the first statement, Definition 2.2 ensures that F is connected; for  $PC^{TSP}$ , it suffices to observe that the union of two intersecting tours is also a tour. Hence, F is a feasible solution for the instance W of  $PC^X$ .

We next give an upper bound on c(F) by pessimistically considering the case that  $\widehat{F}_2$  does not cover any terminal in  $B \cap T$ .

For the case that  $\widehat{F}_2$  covers u, we have  $F = \widehat{F}_2 \cup \widehat{F}_1$  and we have  $c(F) = w(\widehat{F}_1) + w(\widehat{F}_2) + \pi(T \setminus F) \le w(\widehat{F}_1) + \pi(T_1 \setminus \widehat{F}_1) + w(\widehat{F}_2) + \pi((T \setminus B) \setminus \widehat{F}_2) \le c_1(\widehat{F}_1) + c_2(\widehat{F}_2)$ .

For the case that  $\widehat{F}_2$  does not cover u, we have  $F = \widehat{F}_2$ , and  $c(F) = w(\widehat{F}_2) + \pi(T \setminus \widehat{F}_2) \le w(\widehat{F}_2) + \pi((T \setminus B) \setminus \widehat{F}_2) + \pi(T \cap B) \le w(\widehat{F}_2) + \pi((T \setminus B) \setminus \widehat{F}_2) + \pi_2(u) + c_1(F_1) = c_2(F_2) + c_1(F_1)$ .

The second statement follows from the choice of *i*. Moreover,  $H_u^{(i)}(W_2) = 0$ , because in instance  $W_2$  the only terminal in B is  $u_1$ , which can be covered by a self-loop of weight 0.

For the third statement, we use the fact that there is no critical instance at height i - 1 to show that there is a solution to  $W_1$  with small cost.

Moreover, we consider the solutions corresponding to  $\mathsf{H}_v^{(i-1)}(W)$ , over  $v \in N_{i-1} \cap B(u, 5s^i)$ . The cost is  $O(s)^{O(k)} \cdot q_0 \cdot s^i$ .

To stitch these partial solutions together, we add extra edges with weights at most  $|N_{i-1}| \cdot O(s^i)$ . Hence, the total cost for the solution to (any sub-instance of)  $W_1$  is at most  $O(s)^{O(k)} \cdot q_0 \cdot s^i$ .

Lemma 4.2 (Combining Costs of Sub-Instances). Suppose F is an optimal net-respecting solution for instance W of  $PC^X$ . Then, for any realization of the decomposed sub-instances  $W_1$  and  $W_2$  as described in Figure 4.1, there exist (not necessarily net-respecting) solution  $\widehat{F}_1$  for  $W_1$  and net-respecting solution  $\widehat{F}_2$  for  $W_2$  such that  $(1 - \epsilon) \cdot \mathbf{E}[c_1(\widehat{F}_1)] + \mathbf{E}[c_2(\widehat{F}_2)] \le c_W(F)$ , where the expectation is over the randomness to generate  $W_1$  and  $W_2$ . Recall that the randomness to generate  $W_1$  and  $W_2$  involves the random ball B and the randomness used in the dynamic program to generate  $F_1$  to produce instance  $F_2$  and its cost function  $F_2$ .

PROOF. Recall that the random ball  $B = B(u, (4 + 2\lambda + h) \cdot s^i)$  for random  $h \in [0, \frac{1}{2}]$ , and denote  $\overline{B} := B(u, (4+2\lambda+1) \cdot s^i)$ , which is deterministic. For the trivial case  $V(F) \cap \overline{B} = \emptyset$ , we choose  $\widehat{F}_1 := F_1$  (which is the solution used to define  $W_2$  and  $c_2$ ) and  $\widehat{F}_2 := F$ . In this case, we have  $c_1(\widehat{F}_1) + c_2(\widehat{F}_1)$  $c_2(\widehat{F}_2) = c_1(F_1) + (\pi(T \cap B) - c_1(F_1)) + \pi((T \setminus B) \setminus F) + w(F) = c(F).$ 

For the rest of the proof, we can assume that  $V(F) \cap \overline{B}$  is non-empty. Moreover, the solution  $\widehat{F}_2$ we are going to construct will always include u.

Denote  $\widehat{V}_1 := \{x \in B \mid \exists y \notin B, \{x, y\} \in F\}.$ 

We start by including  $F|_B$  in  $\widehat{F}_1$  and including the remaining edges of F in  $\widehat{F}_2$ . Then, we will add extra edges such that (i) in each of  $\widehat{F}_1$  and  $\widehat{F}_2$ , the vertices covered form a connected component and include  $\widehat{V}_1$ ; (ii)  $\widehat{F}_2$  visits u; and (iii) for PC<sup>TSP</sup>, every vertex has even degree.

Hence, all the terminals in  $V(F) \cap B$  are visited by  $\widehat{F}_1$  and all terminals in  $V(F) \setminus B$  are visited by  $F_2$ . If we can show that these extra edges have expected total weight at most  $\epsilon \cdot \mathbf{E}[c_1(F_1)]$ , then the lemma follows.

Define N to be the subset of  $N_i$  that covers the points in  $\overline{B}$ , where  $s^j < \delta s^i \le s^{j+1}$  and  $\delta =$  $\Theta(\frac{\epsilon}{k})$ . We include edges of a minimum spanning tree H of N in each of  $\widehat{F}_1$  and  $\widehat{F}_2$ , and make it net-respecting (using Lemma 2.1); for  $PC^{TSP}$ , each edge in H can be included a constant number of times to ensure that the degree of every vertex is even. Furthermore, since  $V(F) \cap \overline{B}$  is nonempty, even when  $V(F) \cap B$  is empty, it just takes one net-respecting path of length at most  $2\delta s^i$ to connect  $\widehat{F}_2$  to H. The sum of the weights of edges added from H is at most  $|N| \cdot O(k) \cdot s^i \le 1$  $O(\frac{ks}{s})^{O(k)} \cdot s^i$ .

**Connecting Crossing Points.** Recall that  $\widehat{V}_1 := \{x \in B \mid \exists y \notin B, \{x,y\} \in F\}$ . To ensure the connectivity of both  $\widehat{F}_1$  and  $\widehat{F}_2$ , we add extra edges to ensure that in each of  $\widehat{F}_1$  and  $\widehat{F}_2$ , each point in  $\widehat{V}_1$  is connected to some point in N, which is connected by edges in H.

Note that if such a point  $x \in \widehat{V}_1$  is incident to some edge in F with weight at least  $\frac{S^1}{4}$ , then the netrespecting property of F implies that x is already in N. Otherwise, we need to connect x to some point in N with a net-respecting path of length at most  $2\delta s^i$ ; observe that this happens because some edge  $\{x,y\}$  in F is cut by B, which happens with probability at most  $O(\frac{d(x,y)}{s^i})$ . Hence, each edge  $\{x,y\} \in F|_{\overline{B}}$  has an expected contribution of  $\delta s^i \cdot O(\frac{d(x,y)}{s^i}) = O(\delta) \cdot d(x,y)$ .

Charging the Extra Costs to  $\widehat{F}_1$ . Apart from using edges in F, the extra edges come from a constant number of copies of the minimum spanning tree H, and other edges with cost  $O(\delta)$ .  $w(F|_{\overline{B}})$ . We charge these extra costs to  $c_1(F_1)$ .

Observe that the heuristic  $c(F_u^{(i,4)}) > q_0 \cdot s^i$  and  $\widehat{F}_1$  is a solution for  $W_u^{(i,4+2\lambda+h)}$ . Therefore, by the definition of  $\mathsf{H}^{(i)}_u(W)$ , we have  $c_1(F_1) \geq \frac{1}{2(1+\Theta(\epsilon))} \cdot c(F_u^{(i,4)}) \geq \frac{q_0}{8} \cdot s^i$ , by choosing large enough  $q_0$ . Therefore, the sum of weights of edges from H is at most  $O(\frac{ks}{\epsilon})^{O(k)} \cdot s^i \leq \frac{\epsilon}{2} \cdot c_1(F_1)$ .

We next give an upper bound on  $w(F|_{\overline{B}})$ , which is at most  $c(F_u^{(i,4+2(\lambda+1))}) + O(\frac{sk}{\epsilon})^{O(k)} \cdot s^i$ , by Lemma 3.2. By the choice of  $\lambda$ , we have  $c(F_u^{(i,4+2(\lambda+1))}) \leq 30k \cdot c(F_u^{(i,4+2\lambda)})$ . Moreover, since  $\widehat{F}_1$  is also a solution for  $W_u^{(i,4+2\lambda)}$ ,  $c(F_u^{(i,4+2\lambda)}) \leq 2(1+\Theta(\epsilon)) \cdot c_1(\widehat{F}_1)$ . Hence, we

can conclude that  $w(F|_{\overline{B}}) \leq O(k) \cdot c_1(\widehat{F}_1)$ .

Hence, by choosing small enough  $\delta = \Theta(\frac{\epsilon}{k})$ , we can conclude that the extra edges has expected weight at most  $O(\delta) \cdot w(F|_{\overline{B}}) \leq \frac{\epsilon}{2} \cdot c_1(\widehat{F}_1)$ .

Therefore, we have shown that  $\mathbf{E}[c_1(\widehat{F}_1)] + \mathbf{E}[c_2(\widehat{F}_2)] \le c(F) + \epsilon \cdot c_1(\widehat{F}_1)$ , where the right-hand side is a random variable. Taking expectation on both sides and rearranging gives the required result.

<span id="page-13-0"></span>24:14 T.-H. Hubert Chan et al.

# 5 REVISITING HIERARCHICAL DECOMPOSITION AND SPARSE INSTANCE FRAMEWORKS FOR TSP-LIKE PROBLEMS

In this section, we revisit the randomized hierarchical framework that is used in all known PTAS's (and QPTAS's) for TSP-like problems in doubling metrics [6, 11, 12, 21]. As mentioned in Section 1 and Remark 2.1, in the original paper [21], the randomness in the underlying hierarchical decomposition is first used to bound the increase in the cost of a solution to achieve some *portal-respecting property*. However, conditioned on the portal-respecting property, some more careful arguments should be required for the conditional randomness of the hierarchical decomposition.

Since this random hierarchical framework is widely used in subsequent works, we think it is worthwhile to revisit the framework and resolve any previous technical issues. In particular, in Section 5.1, we give a more precise definition and notation for cluster portals in a hierarchical decomposition. As a result of the modified definition of portals, in Section 5.2, we also revisit the analysis of the sparsity framework [6] that was used to achieve the first PTAS for TSP on doubling metrics. Even though we use similar concepts in the modified framework, some arguments are quite different from previous proofs. In particular, below are highlights of the changes made in the modified framework:

- We make use of a net tree to define portals with respect to a hierarchical decomposition. As a result, we also need to modify the notion of (m, r)-lightness for a solution.
- As opposed to previous approaches [6, 21], when a solution uses too many active portals for a cluster, our patching argument does not rely on the small MST lemma [21, Lemma 6].
- After a given solution is modified to observe the portal-respecting property, any newly added edges actually depend on the randomness of the hierarchical decomposition. Hence, to use the randomness of the decomposition again, we give a new charging argument that, loosely speaking, maps a newly added edge back to an original edge that created it.

#### 5.1 Randomized Hierarchical Decomposition Framework

Net Tree. Recall that given a metric space, we consider a sequence of hierarchical nets  $\{N_i\}_i$  as defined in Section 2. We define a *net tree* with respect to the hierarchical nets  $\{N_i\}_i$  in a way similar to Reference [13]; for notational convenience, we assume that for all  $i \leq 0$ ,  $N_i = X$ . For each height i and each  $u \in N_i$ , there is some node (u,i) in the net tree; for notational convenience, for i < 0, (u,i) := (u,0). The metric d can naturally be extended to nodes. Denote  $\widehat{N}_i := \{(u,i) \mid u \in N_i\}$ , and the tree has node set  $\widehat{X} := \bigcup_i \widehat{N}_i$ . Notice THAT we use "point" to refer to an element in X and "node" to refer to an element in  $\widehat{X}$ . Observe that  $N_L$  contains only one point  $r \in X$ , and the corresponding node (r,L) is the root of the net tree. The edges of the tree are defined by a parent function Par, mapping a non-root node to its parent. For i < L and  $u \in N_i$ , define Par(u,i) := (v,i+1), where  $v \in N_{i+1}$  is the closest point in  $N_{i+1}$  to u (breaking ties arbitrarily). For a point  $u \in X$ , define  $Anc_j(u) \in \widehat{N}_j$  be the height-j ancestor of (u,0). In this section, we assume an underlying net tree is constructed.

**Subgraph on Nodes.** Observe that a multi-graph  $\widehat{G}$  with vertex set in  $\widehat{X}$  naturally induces a multi-graph G with vertex set in X. Every edge  $\{(u,i),(v,j)\}$  in  $\widehat{G}$  induces an edge  $\{u,v\}$  in G if  $u\neq v$ . Recall that we consider multi-graphs, because the solution for PC<sup>TSP</sup> needs to be Eulerian.

We use the following decompositions as mentioned in References [6, 11, 12].

Definition 5.1 (Single-scale Decomposition [1]). At height i, an arbitrary ordering  $\pi_i$  is imposed on the net  $N_i$ . Each net-point  $u \in N_i$  corresponds to a cluster center and samples random  $h_u$  from a truncated exponential distribution  $\operatorname{Exp}_i$  having density function  $t \mapsto \frac{\chi}{\chi-1} \cdot \frac{\ln \chi}{s^i} \cdot e^{-\frac{t \ln \chi}{s^i}}$  for  $t \in [0, s^i]$ , where  $\chi = O(1)^k$ . Then, the cluster at u has random radius  $r_u := s^i + h_u$ .

The clusters induced by  $N_i$  and the random radii form a decomposition  $\Pi_i$ , where a point  $p \in V$  belongs to the cluster with center  $u \in N_i$  such that u is the first point in  $\pi_i$  to satisfy  $p \in B(u, r_u)$ . We say that the partition  $\Pi_i$  cuts a set P if P is not totally contained within a single cluster.

The results in Reference [1] imply that the probability that a set P is cut by  $\Pi_i$  is at most  $\frac{\beta \cdot \text{Diam}(P)}{s^i}$ , where  $\beta = O(k)$ .

Definition 5.2 (Hierarchical Decomposition). Given a configuration of random radii for  $\{N_i\}_{i\in[L]}$ , decompositions  $\{\Pi_i\}_{i\in[L]}$  are induced as in Definition 5.1. At the top height L-1, the whole space is partitioned by  $\Pi_{L-1}$  to form height-(L-1) clusters. Inductively, each cluster at height i+1 is partitioned by  $\Pi_i$  to form height-i clusters, until height 0 is reached. Observe that a cluster has  $K:=O(s)^k$  child clusters. Hence, a set P is cut at height i iff the set P is cut by some partition  $\Pi_j$  such that  $j\geq i$ ; this happens with probability at most  $\sum_{j\geq i}\frac{\beta\cdot \mathrm{Diam}(P)}{s^i}=\frac{O(k)\cdot \mathrm{Diam}(P)}{s^i}$ .

**Portals.** We define portals with respect to some hierarchical decomposition. For a height-i cluster C, define its portals as  $\{\operatorname{Anc}_j(u)\mid u\in C\}$ , where j satisfies  $s^j\leq\Theta(\frac{\epsilon}{kL})\cdot s^i< s^{j+1}$ . Observe that the same node in  $\widehat{X}$  could be a portal for several clusters of the same height. However, we emphasize that a portal p is naturally associated with some cluster that it is assigned. Hence, whenever we talk about a portal p, we implicitly mean that "p is a portal of some cluster C of height i" and say that p is a height-i portal for short. We use  $\widehat{P}_i$  to denote the set of height-i portals and denote  $\widehat{P}:=\cup_i\widehat{P}_i$ .

Since a height-*i* cluster has diameter  $O(s^i)$ , by packing property, each cluster has at most  $m := O(\frac{kLs}{\epsilon})^k$  portals.

Solutions on Portals. Observe that a multi-graph G with vertex  $\widehat{P}$  naturally induces a multi-graph with vertex set  $\widehat{X}$  (and a multi-graph with vertex set X) in the natural way. For a terminal  $t \in X$ , a multi-graph G solution on  $\widehat{P}$  visits t only iff G covers (t,i) for some i.

**Portal-respecting Solution.** Our algorithm works with solutions with vertex set  $\widehat{P}$ . A multi-graph F with vertex set in  $\widehat{P}$  is called portal-respecting with respect to some hierarchical decomposition if for any edge  $e = \{u, v\}$  in F, where u is a portal of height-j cluster C and v is a portal of height-j' cluster C' with  $j \geq j'$ , it holds that

- If j = j', then C and C' have the same parent cluster;
- If j > j', then j = j' + 1 and C' is a child cluster of C.

**Active Portals.** Suppose F is portal-respecting (with respect to some hierarchical decomposition). Consider a portal p of a height-i cluster C that is visited by F. We say that p is an *active* portal if p is connected (in F) to a height-i portal of a sibling of C, or a height-(i + 1) portal of a parent cluster of C.

(m, r)-Light Solution. A (multi-)graph F is called (m, r)-light if it is portal-respecting for a hierarchical decomposition in which each cluster has at most m portals and each cluster has at most r active portals.

*Remark 5.1.* Almost all previous works consider a solution as a subgraph with vertex set in the original metric space X. However, such solutions in the previous frameworks are implicitly induced by ones with portals  $\widehat{P}$  as the vertex set.

We have a unified notion of (m, r)-lightness that is the same for both PC<sup>TSP</sup> and PC<sup>STP</sup>. We next describe additional properties for a PC<sup>TSP</sup> solution that justify why our lightness notion does not count the number of times a tour visits a cluster.

**Additional Structure for PC**<sup>TSP</sup>. We consider additional properties of a portal-respecting solution, which is Eulerian.

<span id="page-15-0"></span>24:16 T.-H. Hubert Chan et al.

Definition 5.3 (Crossing Portal Pair). A portal-respecting Eulerian tour crosses a cluster C through the (ordered) portal pair (p,q) (where p and q can be the same) if the node immediately preceding p and the node immediately succeeding q are portals of the parent or a sibling of C, and all the nodes (if any) visited from p to q are portals of (not necessarily proper) descendant clusters of C.

A portal-respecting Eulerian tour is economical if for every cluster C and every ordered portal pair (p, q), the tour crosses C through (p, q) at most once.

Definition 5.4 (Scratch and Removal). A portal-respecting Eulerian tour scratches a cluster C at portal p if the two nodes x and y that immediately go before and after p are both portals of the parent or a sibling of C. Hence, a scratch is a special case of crossing cluster C through (p, p).

Observe that the edge  $\{x, y\}$  is portal-respecting. Hence, if the portal p is visited in another part of the tour, the scratch at portal p of cluster C can be removed by using the shortcut  $\{x, y\}$  without increasing the length of the tour.

LEMMA 5.5 (ECONOMICAL TOUR). A portal-respecting Eulerian tour can be modified to be economical without increasing its length and still visit the same set of terminals.

PROOF. Suppose the tour crosses some cluster C through the ordered pair (p, q) at least twice:  $E_1, p, P_1, q, E_2, p, P_2, q, E_3$ , where the E's and P's represent sequences of visited edges. Moreover, the nodes visited by the P's are all portals of the descendant clusters of C.

Consider an alternative tour:  $E_1$ , p,  $P_1$ , q,  $\widehat{P_2}$ , p,  $\widehat{E_2}$ , q,  $E_3$ , where  $\widehat{S}$  for an edge sequence S denotes the reverse of S. Then, observe that  $E_1$ , p,  $P_1$ , q,  $\widehat{P_2}$ , p,  $\widehat{E_2}$  induces only one crossing of C through (p,p). Moreover, the scratch of C at q induced by  $\widehat{E_2}$ , q,  $E_3$  can be removed as in Definition 5.4, since q is visited in  $E_1$ , p,  $P_1$ , q,  $\widehat{P_2}$ , p,  $\widehat{E_2}$ .

Hence, we have replaced two crossings of C at (p,q) by one crossing of C at (p,p). Notice that the above argument holds even in the case where p=q. Moreover, the number of edges in the tour is reduced by one due to the removal of the scratch of C at q so the procedure can only be carried out a finite number of times. Using this argument repeatedly gives the result of the lemma.  $\Box$ 

#### 5.2 Sparsity Structural Lemma

We revisit the sparsity structural lemma in Reference [6, Lemma 3.1]. On a high level, the lemma says that given a net-respecting q-sparse solution T and an appropriate hierarchical decomposition, there exists an (m, r)-light solution with appropriate parameters m and r, whose length does not increase too much.

**Property of Hierarchical Decomposition.** Recall that in the hierarchical decomposition, for each i and  $u \in N_i$ , a random radius  $h_u^{(i)}$  is sampled from a truncated exponential distribution, and we define a random ball  $B(u, r_u^{(i)})$ , where  $r_u^{(i)} := s^i + h$ . Let  $A_u^{(i)}$  be the event that  $B(u, r_u^{(i)})$  cuts at most  $O(q \cdot k)$  edges in T with length at most  $s^i$ . The desired property of the hierarchical decomposition is the event  $\mathcal A$  that all  $A_u^{(i)}$  happen simultaneously, for all i and  $u \in N_i$ .

Proposition 5.6 ([6]). For any  $S \subset X$ ,

$$\Pr[S \text{ is cut by a height-} j \text{ cluster} \mid \mathcal{A}] \leq O(k) \cdot \frac{\mathsf{Diam}(S)}{\mathfrak{s}^j}.$$

Proposition 5.7 ([6]). For any i and  $u \in N_i$ ,  $\Pr[A_u^{(i)}] \ge \frac{1}{2}$ .

Theorem 5.8 (Sparse Structural Property). Suppose T is an optimal net-respecting solution with points in X, AND is q-sparse. Given any hierarchical decomposition, there is a way to transform

<span id="page-16-0"></span>T into an (m,r)-light solution T' on portals  $\widehat{P}$  that visits the same terminals as T, with  $m:=O(\frac{kLs}{\epsilon})^k$ ,  $r:=q\cdot\Theta(1)^k+\Theta(\frac{s}{\epsilon})^k$ , such that

$$\Pr[w(T') \le (1 + O(\epsilon)) \cdot w(T) \mid \mathcal{A}] \ge \frac{1}{4},$$

where the randomness comes from the hierarchical decomposition.

Furthermore, if T is Eulerian, then so is T'.

PROOF. Suppose some hierarchical decomposition is fixed.

#### **Part I: Defining Portal-respecting** T''**.** Set $T'' = \emptyset$ initially.

Examine each edge  $e : \{u, v\}$  in T. Let i be the largest height that e is cut, and let  $C_u$  and  $C_v$  be the (unique) height-i clusters that u and v lie in. Define h(e) := i. Include the path

$$((u, 0) = Anc_0(u), Anc_1(u), \dots, Anc_i(u), Anc_i(v), \dots, Anc_1(v), Anc_0(v) = (v, 0))$$

in T'', where j satisfies  $s^j \leq \Theta(\frac{\epsilon}{kL}) \cdot s^i < s^{j+1}$ . Observe that every node in this path is an active portal, and we say these portals are activated by e. It is immediate that T'' is portal-respecting. Moreover, if T is Eulerian, then T'' is Eulerian as well.

For an active portal p, let f(p) be any edge in T that activates p.

LEMMA 5.9. 
$$E[w(T'') \mid \mathcal{A}] \leq (1 + \epsilon) \cdot w(T)$$
.

**PROOF.** It is sufficient to show that for each edge  $e := \{u, v\}$  in T, the weight of the path

$$P_e := ((u, 0) = Anc_0(u), Anc_1(u), \dots, Anc_i(u), Anc_i(v), \dots, Anc_1(v), Anc_0(v) = (v, 0))$$

is at most  $(1 + \epsilon) \cdot w(e)$  in expectation, given  $\mathcal{A}$ , where  $s^j \leq \Theta(\frac{\epsilon}{kT}) \cdot s^i < s^{j+1}$  and i := h(e).

Fix  $e := \{u, v\}$  in T. Let i := h(e) and j defined as in the construction. Observe that for any l,  $d(u, \mathsf{Anc}_l(u)) \le O(s^l)$ . So, the weight of the path from u to  $\mathsf{Anc}_j(u)$  is at most  $O(\frac{\epsilon}{kL}) \cdot s^i$ , and so is that from v to  $\mathsf{Anc}_j(v)$ . By triangle inequality,  $d(\mathsf{Anc}_j(u), \mathsf{Anc}_j(v)) \le d(u, v) + O(\frac{\epsilon}{kL}) \cdot s^i$ .

Therefore, the additional cost

$$\left(\sum_{e' \in P_e} w(e')\right) - d(u, v) \le O\left(\frac{\epsilon}{kL}\right) \cdot s^i.$$

This cost occurs only if height i is the largest height at which e is cut and it is of probability at most  $O(k) \cdot \frac{w(e)}{s^i}$ , by Proposition 5.6. Summing this over all i, this cost is at most

$$\sum_{i \in [L]} O\left(\frac{\epsilon}{kL}\right) \cdot s^i \cdot O(k) \cdot \frac{w(e)}{s^i} \le \epsilon \cdot w(e),$$

in expectation, conditioning on  $\mathcal{A}$ . This completes the proof of Lemma 5.9.

**Part II:** (m, r)-light T'. We shall define T' from T'' so T' is (m, r)-light. Examine each cluster C from higher height to lower height. Let r' be the number of active portals of C.

- If  $r' \le r$ , then we do nothing and proceed to the next cluster.
- Otherwise, r' > r. Apply the following patching procedure in Lemma 5.10 to C:

LEMMA 5.10 (PATCHING LEMMA). As defined above, T'' is a portal respecting solution. Suppose C is a height-i cluster with active portal set R. Recall that by definition, an active portal is connected by an edge to a portal of the parent or a sibling cluster of C; let  $\widehat{R}$  be the set of such portals that portals in R connect to. Let  $E(R,\widehat{R})$  be the edge set between R and  $\widehat{R}$ . Then, T'' can be modified such that the following holds:

<span id="page-17-0"></span>24:18 T.-H. Hubert Chan et al.

- (1) The modified solution is still portal-respecting.
- (2) The number of active portals for any cluster is not increased.
- (3) There is at most one active portal of C.
- (4) The resulting solution has cost increased by at most  $O(w(E(R, \widehat{R}))) + O(|R|) \cdot s^i$ .

PROOF. Let R be the active portal set of C. Observe that all portals in  $\widehat{R}$  are height-i or height-(i+1) portals.

- (1) Pick any  $u \in R$ .
- (2) Remove edges between  $R \setminus \{u\}$  and  $\widehat{R}$ .
- (3) Patching inside. Consider the subgraph G' of the original T'' induced on the portals of C and C's descendant clusters. This graph may also be viewed as the "inside" C part of T'', after removing edges from R to  $\widehat{R}$ . Then, there exist at most O(|R|) edges each of length  $O(s^i)$ , adding which makes G' a connected (also Eulerian in the case of  $PC^{TSP}$ ) graph. Include these edges to T''.
- (4) Patching outside. For each active portal  $a \in R$ , consider the set of points  $R_a \subseteq \widehat{R}$  that are connected to a before Step 2 (where the edges are removed). Denote the removed edges between  $R_a$  and a as  $E_a$ . We add a minimum spanning tree on  $R_a$  and then connect it to u; observe that the edges  $E_a$  together with the edge  $\{a, u\}$  is a connected subgraph covering  $R_a$  and u. Hence, the additional cost is at most  $O(E_a + s^i)$ .

If the original graph T is Eulerian, then we can add some edges to make the resulting graph Eulerian as well. Notice that in either case, the additional cost for patching the crossing edges of a is bounded by  $O(E_a + s^i)$ .

We note that the resultant solution is still portal respecting. This is because we are only deleting and adding edges between portals of sibling clusters or those of child and parent clusters that are, by definition, still portal respecting. Hence, item 1 follows. Items 2-4 follow from the above procedure as well. This completes the proof of Lemma 5.10.

LEMMA 5.11. Suppose T' is the solution obtained after applying the patching procedure to all appropriate clusters. Then,  $E[w(T') - w(T'') \mid \mathcal{A}] \leq \epsilon \cdot w(T)$ .

PROOF. Observe that the weight increase of T' from T'' is due to the patching. Consider a height-i cluster C to which the patching is applied. Then, just before the patching, C has r' > r active portals. By Lemma 5.10, the increase of weight is at most  $O(w(E(R,\widehat{R}))) + O(r') \cdot s^i$ . We charge this cost to the active portals. For each active portal a, let  $R_a \subseteq \widehat{R}$  be the portals in R that are connected to a and  $E_a$  be the edges between  $R_a$  and a. Then, the portal a is charged with cost  $O(w(E_a)) + O(s^i)$ .

We first give an upper bound for  $w(E_a)$ . Observe that each node in  $R_a$  is a height i or i+1 portal and, by packing property, there are at most  $O(s)^k \cdot m$  such portals. Since each edge in  $E_a$  is of length at most  $O(s^{i+1})$ , it follows that this part of the cost is at most  $O(s)^k \cdot m \cdot s^{i+1}$  for all clusters with a being an active portal. The bound also dominates the second term  $O(s^i)$ .

Hence, a height-*i* portal takes charge at most  $O(s)^k \cdot O(m) \cdot s^{i+1}$ .

**Charging Argument.** We shall ultimately charge the cost to the original solution T. Observe that a height-i portal is charged only if it belongs to some cluster that is patched, so it is sufficient to charge to T whenever some cluster is patched.

Suppose C is a cluster of height-i that is patched, and R is the set of active portals before patching, where |R| > r. We shall somehow charge the cost received by its portals to T. By Lemma 5.10, the patching procedure does not introduce new active portals. Hence, all active portals come from T'' (actually, all nodes in T'' are active by construction). Let  $R_j := \{p \in R \mid h(f(p)) = j\}$ , recalling that

П

h(e) is defined to be the largest height at which some edge e in T is cut, and f(p) is some edge in T that caused the portal p to be added in Part I to produce T''.

Then, 
$$\{R_j\}_j$$
 is a partition of  $R$ . Also, it is immediate that  $|R_j| = 0$  if  $j < i$ .

LEMMA 5.12. If  $\mathcal{A}$  happens, then  $|R_i| \leq O(1)^k \cdot q + O(\frac{s}{\epsilon})^k$ , for any j.

PROOF. Let  $E_j := \{f(p) \mid p \in R_j\}$ . We further partition  $R_j$  into  $R_j^{(long)} := \{p \in R_j \mid w(f(p)) > s^j\}$  and  $R_j^{(short)} := \{p \in R_j \mid w(f(p)) \leq s^j\}$ .

**Portals activated by long edges.** Consider an edge  $e \in E_j$  such that  $w(e) > s^j$ . Because T is net-respecting, both endpoints of e are in  $N_{j'}$  for  $s^{j'} \le e \cdot s^j < s^{j'+1}$ . This implies that all active portals that e activates correspond to some points in  $N_{j'}$ .

Observing that  $j \ge i$ , by the packing property, there are at most  $O(\frac{s}{\epsilon})^k$  such portals in the height-i cluster C. Therefore,  $|R_i^{(long)}| \le O(\frac{s}{\epsilon})^k$ .

**Portals activated by short edges.** Consider an edge e in  $E_j$  such that  $w(e) \leq s^j$ . By definition, e is cut at height j but is not cut at height-(j+1). So each such cut must be contributed by height-j clusters. Notice that at least one endpoint of e is within distance  $2s^i$  to cluster C. By the definition of short edges, the other endpoint of e is also within a distance of  $2s^i + s^j$  from C. Since  $j \geq i$ , it follows that each cluster that cuts some short edges in  $R_j^{(\text{short})}$  is within distance  $4s^j$  of the center of C. By the packing property, there are at most  $O(1)^k$  number of such clusters. By event  $\mathcal{A}$ , each such cluster contributes at most  $O(q \cdot k)$  cut of edges. Since each edge can only activate at most one portal in one cluster (in Part I), we have

$$|R_i^{(\text{short})}| \le O(1)^k \cdot O(q \cdot k) \le O(1)^k \cdot q.$$

Combining the two cases completes the proof of Lemma 5.12.

Let  $j' := \log_s(\Theta(1)^k \cdot mL)$ . We charge the costs taken by R to all  $R_j$ 's for  $j \ge i + j'$  evenly. By Lemma 5.12 and  $|R| > r \ge 2j' \cdot (\Theta(1)^k \cdot q + \Theta(\frac{s}{\epsilon})^k)$ , we conclude that  $|R_{\ge i+j'}| \ge \frac{|R|}{2}$ .

Hence, each portal in  $R_{\geq i+j'}$  still takes  $O(s)^k \cdot O(m) \cdot s^{i+1}$ , with a slightly larger hidden constant. Then, we further charge this cost for each  $p \in R_{\geq i+j'}$  to f(p).

**Expected Charge.** Finally, we use the randomness of hierarchical decomposition to bound the expected cost.

Consider some e in T. Observe that e is charged only from a portal of height at most h(e) - j'. By definition, the number of portals from each height that are activated by e is at most 2.

Therefore, e takes cost

$$\sum_{j \le h(e) - j'} O(s)^k \cdot m \cdot s^j \le O(s)^k \cdot m \cdot s^{h(e) - j'}.$$

However, by definition, e takes this charge only if it is cut at height h(e), and this is with probability at most  $O(k) \cdot \frac{w(e)}{s^{h(e)}}$ . Therefore, by summing the contribution for all L possible values of h(e), the expected charge that e takes conditioned on  $\mathcal A$  is at most

$$O(mL) \cdot O(s)^k \cdot w(e) \cdot s^{-j'} \le \epsilon \cdot w(e).$$

This completes the proof of Lemma 5.11.

**Constant Probability Bound.** Combining Lemma 5.9 and Lemma 5.11, we have  $E[w(T') \mid \mathcal{A}] \le (1 + \epsilon) \cdot w(T)$ . Observe that the optimality of T implies that  $w(T') \ge \frac{1}{1+\epsilon} \cdot w(T)$ . We let  $\mathcal{B}$  to be the event that  $w(T') \le w(T)$ .

If  $\Pr[\mathcal{B} \mid \mathcal{A}] \ge 1/2$ , then we are done. Otherwise, we have

$$\Pr[\mathcal{B} \mid \mathcal{A}](1-\epsilon)w(T) + \Pr[\mathcal{B}^c \mid \mathcal{A}]E[w(T') \mid \mathcal{A} \cap \mathcal{B}^c] \le (1+\epsilon)w(T).$$

<span id="page-19-0"></span>24:20 T.-H. Hubert Chan et al.

It follows that

$$E[w(T') \mid \mathcal{A} \cap \mathcal{B}^c] \leq (1 + 4\epsilon)w(T).$$

By Markov's Inequality, we have

$$\Pr[w(T') - w(T) > 8\epsilon \cdot w(T) \mid \mathcal{A} \cap \mathcal{B}^c] \le \frac{1}{2}.$$

Then, we can bound the following probability as

$$\begin{aligned} & \Pr[w(T') - w(T) > 8\epsilon \cdot w(T) \mid \mathcal{A}] \\ & = \Pr[\mathcal{B} \mid \mathcal{A}] + \Pr[\mathcal{B}^c \mid \mathcal{A}] \Pr[w(T') > (1 + 8\epsilon) \cdot w(T) \mid \mathcal{A} \cap \mathcal{B}^c] \\ & \leq \frac{3}{4}, \end{aligned}$$

where the last inequality follows, because  $\Pr[\mathcal{B} \mid \mathcal{A}] \leq \frac{1}{2}$ . This completes the proof of Theorem 5.8.

### 6 A PTAS FOR SPARSE PCX INSTANCES: DYNAMIC PROGRAM

Suppose the estimator in Section 3 returns a small enough value for an instance. Then, Corollary 3.3 implies that the instance has a q-sparse (nearly) optimal net-respecting solution, for  $q = \Theta(\frac{sk}{\epsilon})^{\Theta(k)}$ . By Theorem 5.8, to obtain  $1 + \epsilon$  approximation ratio, it suffices to search for (m, r)-light solutions for some appropriate  $m := O(\frac{kLs}{\epsilon})^k$  and  $r := q \cdot \Theta(1)^k + \Theta(\frac{s}{\epsilon})^k$ . We present a dynamic program algorithm to search for an optimal (m, r)-light solution.

Observe that Theorem 5.8 assumes that some good event  $\mathcal{A}$  related to the hierarchical decomposition happens. However, the event  $\mathcal{A}$  is defined with respect to the unknown optimal net-respecting solution. By Proposition 5.7, it is sufficient to sample a collection of  $O(\log n)$  random radii for each ball in the hierarchical decomposition. Then, with constant probability, there is a way for each ball to choose its radius from its collection to satisfy event  $\mathcal{A}$ .

The dynamic program searches for (m, r)-solutions with respect to all possible hierarchical decompositions obtained from choosing the radius for each ball from the collection of sampled radii. We show that this does not blow up the search space too much by first describing the information needed to identify each cluster at each height.

#### Information to Identify a Cluster.

- (1) Height *i* and cluster center  $u \in N_i$ . This has  $L \cdot O(n^k)$  combinations, recalling that  $|N_i| \le O(n^k)$ .
- (2) For each  $j \ge i$ , and  $v \in N_j$  such that  $d(u,v) \le O(s^j)$ , the random radius chosen by (v,j). Observe that the space around  $B(u,O(s^i))$  can be cut by net-points in the same or higher heights that are nearby with respect to their distance scales. As argued in Reference [6], the number of configurations that are relevant to (u,i) is at most  $O(\log n)^{L \cdot O(1)^k} = n^{O(1)^k}$ , where  $L = O(\log_s n)$  and  $s = (\log n)^{\frac{c}{k}}$ , for some sufficiently small universal constant  $0 < c \le 1$
- (3) For each j > i, which cluster at height j (specified by the cluster center  $v_j \in N_j$ ) contains the current cluster at height i. This has  $O(1)^{kL} = n^{O(\frac{k^2}{\log\log n})}$  combinations.

Since it is always possible to assign a direction to each edge of a tour, our algorithm for PC<sup>TSP</sup> works on a tour in which every edge is assigned a direction.

Let *m* and *r* be defined as in Theorem 5.8.

**Entries of DP.** A DP entry is identified as (C, R, P), where each field is explained as follows:

- <span id="page-20-0"></span>• C denotes a cluster.
- R denotes the subset of active portals (as defined in Section 5.1) of C with  $|R| \le r$ .
- $-\text{In PC}^{\mathsf{TSP}}$ , P is a set of  $distinct^5$  ordered pairs (p,q) of R (where we allow p=q), such that each portal in R appears in at least one pair in P. An ordered pair (p,q) in P means that the solution tour crosses cluster C through (p,q), in the sense of Definition 5.3.
  - -In PC<sup>STP</sup>, P is a partition of R, where each part U in P corresponds to a connected component in the solution restricted to C that connects to portals outside the cluster via the portals in U.

LEMMA 6.1 (Number of Entries). The number of entries (C, R, P) is at most  $n^{O(1)^k} \cdot O(m2^r)^r$ .

PROOF. As discussed earlier, the number of cluster C is at most  $n^{O(1)^k}$ . With a fixed C, R is chosen from m portals, and  $|R| \le r$ . Hence, the number of possibilities for R is at most  $\binom{m}{\le r} \le O(m)^r$ . Finally, P has at most  $2^{r^2}$  possibilities, in either  $PC^X$  problem.

Therefore, the number of entries is at most  $n^{O(1)^k} \cdot O(m2^r)^r$ .

**Invariant: Value of an Entry.** The value of an entry (C, R, P), defined as v(C, R, P), is the cost of the minimum cost graph F defined on portals of cluster C and its descendants, whose penalty is with respect to the terminals in C and (R, P) gives the connectivity requirements as follows:

- If  $R = \emptyset$ , then the value is the solution satisfying the same connectivity requirements as  $PC^X$  restricted to the sub-instance induced by C.
- Otherwise, we have:
  - —For PC<sup>TSP</sup>, F can be partitioned into directed paths, such that each pair  $(p,q) \in P$  corresponds to a directed path from p to q in F. The special case p = q corresponds to a directed cycle containing p, where a degenerate cycle just containing p with no edges is allowed.
  - -For PC<sup>STP</sup>, F is a forest, where two portals in R are in the same connected component *iff* they are in the same part in P.

**Evaluating a Subproblem.** Suppose E := (C, R, P) is an entry to be evaluated. If C is a height-0 cluster containing only one point, then it is the base case, and its value is easily computed.

Otherwise, enumerate all possible configurations for children clusters of C, denoted as  $I := \{(C_i, R_i, P_i)\}_{C_i \in \mathsf{Children}(C)}$ . Then, enumerate all graphs G between the portals in R and  $R_i$ 's such that each edge either connects (i) a node from R to one in  $R_i$ , (ii) two nodes from different  $R_i$ 's, or (iii) two nodes from R, where edges are directed for  $\mathsf{PC}^\mathsf{TSP}$ . Additional edges are added among nodes within each  $R_i$  to form an augmented graph  $\widehat{G}$  in the following way:

- For PC<sup>TSP</sup>, for each i and each pair  $(p,q) \in P_i$  such that  $p \neq q$ , add a directed edge (p,q) to  $\widehat{G}$ .
- For PC<sup>STP</sup>, for each i, for each part U in  $P_i$ , edges from an arbitrary spanning tree on U is added to  $\widehat{G}$ .

The following procedure checks whether the graph  $\widehat{G}$  is *consistent* with (R, P): **Consistency Checking.** It is consistent if all the following are true:

- (1) If  $R \neq \emptyset$ , then for every i, every portal in  $R_i$  is connected to some portal in R in  $\widehat{G}$ . Otherwise, all portals in  $\bigcup_i R_i$  are connected in  $\widehat{G}$ .
- (2) For PC<sup>TSP</sup>. If  $R = \emptyset$ , then the directed graph  $\widehat{G}$  is Eulerian, i.e., the in-degree of every node equals its out-degree.

<sup>&</sup>lt;sup>5</sup>The reason why considering distinct pairs is sufficient is explained in Lemma 5.5.

<span id="page-21-0"></span>24:22 T.-H. Hubert Chan et al.

Otherwise, we check that  $\widehat{G}$  can be partitioned into directed paths specified by the pairs in P, where each pair (p, q) corresponds to a directed path p from q in  $\widehat{G}$ . For p = q, this is a cycle containing p, where a degenerate cycle with an isolated p is allowed.

A brute force way is to consider all permutations of the edges in  $\widehat{G}$  and interleave the permutation with the pairs in P.

• For PC<sup>STP</sup>. If  $R \neq \emptyset$ , then  $\widehat{G}$  is a forest such that two portals in R are in the same connected component *iff* they are in the same part in P.

If they are consistent, then the configuration (I, G) is a *candidate* configuration for entry E = (C, R, P). The value for a candidate configuration shall be defined in the following, and this value is a *candidate* value for E. The final value for E is the minimum over all candidate values.

#### **Evaluating a Candidate Value:**

- If  $R = \emptyset$ , the candidate value is  $\min\{w(G) + \sum_{i:R_i \neq \emptyset} v(C_i, R_i, P_i) + \sum_{i:R_i = \emptyset} \pi(C_i), \min_{i:R_i = \emptyset} \{v(C_i, R_i, P_i) + \pi(C \setminus C_i)\}\}$ , where w(G) is the weight of edges in G.
- Otherwise, the candidate value is  $w(G) + \sum_{i:R_i \neq \emptyset} v(C_i, R_i, P_i) + \sum_{i:R_i = \emptyset} \pi(C_i)$ .

**Final Solution.** The final solution is corresponding to  $(C_L, \emptyset, \emptyset)$ , where  $C_L$  is the only height-L cluster. It is easy to check that the value defined in this way satisfies the invariant. Moreover, a solution may be constructed from the values of entries.

Lemma 6.2 (Running Time). The time complexity of the DP is 
$$n^{O(1)^k} \cdot \exp(\sqrt{\log n} \cdot O(\frac{k}{\epsilon})^{O(k)})$$
.

PROOF. Recall that the algorithm first enumerates an entry E := (C, R, P), and then enumerate possible configurations of child entries  $I := \{(C_i, R_i, P_i)\}$ , and a graph G on R and the  $R_i$ 's.

As in Lemma 6.1, the number of entries E is at most  $n^{O(1)^k} \cdot O(mr)^r$ . Suppose E is fixed, and suppose C is of height-i. We shall upper bound the number of child configurations I. Observe that there are at most  $O(s)^k$  child clusters. As noted in Reference [6], the child clusters have to be consistent with C on all heights at least i. Therefore, only radii on height-(i-1) are not fixed, and this implies the number of possible configurations of child clusters  $\{C_i\}_i$  is at most  $O(\log n)^{O(1)^k \cdot O(s)^k}$ . Hence, the number of I is at most  $O(\log n)^{O(s)^k} \cdot O(m2^r)^{r \cdot O(s)^k} \le O(m2^r)^{r \cdot O(s)^k}$ , where the choice of C in C in C is ensures that the term  $C(\log n)^{O(s)^k} = O(n)$ .

Since *G* has at most  $r \cdot O(s)^k$  vertices, and *G* is a simple directed graph, the number of *G* is at most  $2^{O(r) \cdot O(s)^k}$ .

For PC<sup>TSP</sup>, a brute force way to check consistency between  $\widehat{G}$  and (R, P) takes time at most

$$\left(O(r^2)\cdot O(s)^{O(k)}\right)!\cdot \binom{O(r^2)\cdot O(s)^{O(k)}}{2r} \leq O(rs)^{r^2\cdot O(s)^{O(k)}}.$$

In conclusion, the time complexity is  $n^{O(1)^k} \cdot O(mr)^{r^2 \cdot O(s)^{O(k)}}$ .

Plugging in m and r defined in Theorem 5.8 and the value of  $q_0$ , the time complexity is

$$n^{O(1)^k} \cdot O\left(\frac{skL}{\epsilon}\right)^{O(\frac{sk}{\epsilon})^{O(k)}} \leq n^{O(1)^k} \cdot \exp\left(\sqrt{\log n} \cdot O\left(\frac{k}{\epsilon}\right)^{O(k)}\right),$$

where the inequality holds due to the choice of a small enough c in  $s := (\log n)^{\frac{c}{k}}$ .

#### **REFERENCES**

 Ittai Abraham, Yair Bartal, and Ofer Neiman. 2006. Advances in metric embedding theory. In *Proceedings of the STOC*. ACM, 271–286.

- <span id="page-22-0"></span>[2] Aaron Archer, Mohammad Hossein Bateni, Mohammad Taghi Hajiaghayi, and Howard J. Karloff. 2011. Improved approximation algorithms for prize-collecting Steiner tree and TSP. *SIAM J. Comput.* 40, 2 (2011), 309–332.
- [3] Sanjeev Arora. 1998. Polynomial time approximation schemes for Euclidean traveling salesman and other geometric problems. *J. ACM* 45, 5 (1998), 753–782.
- [4] P. Assouad. 1983. Plongements lipschitziens dans **R***n*. *Bull. Soc. Math. France* 111, 4 (1983), 429–448. BSMFAA
- [5] Egon Balas. 1989. The prize collecting traveling salesman problem. *Networks* 19, 6 (1989), 621–636.
- [6] Yair Bartal, Lee-Ad Gottlieb, and Robert Krauthgamer. 2016. The traveling salesman problem: Low-dimensionality implies a polynomial time approximation scheme. *SIAM J. Comput.* 45, 4 (2016), 1563–1581.
- [7] Mohammad Hossein Bateni, Chandra Chekuri, Alina Ene, Mohammad Taghi Hajiaghayi, Nitish Korula, and Dániel Marx. 2011. Prize-collecting Steiner problems on planar graphs. In *Proceedings of the SODA*. SIAM, 1028–1049.
- [8] Mohammad Hossein Bateni and MohammadTaghi Hajiaghayi. 2012. Euclidean prize-collecting Steiner forest. *Algorithmica* 62, 3–4 (2012), 906–929.
- [9] Daniel Bienstock, Michel X. Goemans, David Simchi-Levi, and David Williamson. 1993. A note on the prize collecting traveling salesman problem. *Math. Prog.* 59, 1 (1993), 413–420.
- [10] Glencora Borradaile, Philip N. Klein, and Claire Mathieu. 2015. A polynomial-time approximation scheme for Euclidean Steiner forest. *ACM Trans. Algor.* 11, 3 (2015), 19:1–19:20.
- [11] T.-H. Hubert Chan, Shuguang Hu, and Shaofeng H.-C. Jiang. 2018. A PTAS for the Steiner forest problem in doubling metrics. *SIAM J. Comput.* 47, 4 (2018), 1705–1734.
- [12] T.-H. Hubert Chan and Shaofeng H.-C. Jiang. 2018. Reducing curse of dimensionality: Improved PTAS for TSP (with neighborhoods) in doubling metrics. *ACM Trans. Algor.* 14, 1 (2018), 9:1–9:18.
- [13] T.-H. Hubert Chan, Mingfei Li, Li Ning, and Shay Solomon. 2015. New doubling spanners: Better and simpler. *SIAM J. Comput.* 44, 1 (2015), 37–53.
- [14] Kenneth L. Clarkson. 1999. Nearest neighbor queries in metric spaces. *Disc. Computat. Geom.* 22, 1 (1999), 63–93.
- [15] Erik D. Demaine, Mohammad Taghi Hajiaghayi, and Ken-ichi Kawarabayashi. 2011. Contraction decomposition in h-minor-free graphs and algorithmic applications. In *Proceedings of the STOC*. ACM, 441–450.
- [16] M. M. Deza and M. Laurent. 1997. *Geometry of Cuts and Metrics*. Algorithms and Combinatorics, Vol. 15. Springer-Verlag, Berlin. xii+587 pages.
- [17] Michel X. Goemans. 2009. Combining approximation algorithms for the prize-collecting TSP. *CoRR* abs/0910.0553 (2009).
- [18] Michel X. Goemans and David P. Williamson. 1995. A general approximation technique for constrained forest problems. *SIAM J. Comput.* 24, 2 (1995), 296–317.
- [19] Anupam Gupta, Robert Krauthgamer, and James R. Lee. 2003. Bounded geometries, fractals, and low-distortion embeddings. In *Proceedings of the FOCS*. IEEE Computer Society, 534–543.
- [20] J. Matoušek. 2002. *Lectures on Discrete Geometry*. Graduate Texts in Mathematics, Vol. 212. Springer-Verlag, New York. xvi+481 pages.
- [21] Kunal Talwar. 2004. Bypassing the embedding: Algorithms for low dimensional metrics. In *Proceedings of the STOC*. ACM, 281–290.

Received October 2018; revised August 2019; accepted January 2020