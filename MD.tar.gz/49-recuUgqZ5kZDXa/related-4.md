# $(1+\varepsilon)$ -Approximation for Facility Location in Data Streams

Artur Czumaj\* Christiane Lammersen<sup>†</sup>

Morteza Monemizadeh<sup>‡</sup> Christian Sohler<sup>§</sup>

#### Abstract

We consider the *Euclidean facility location problem* with uniform opening cost. In this problem, we are given a set of n points  $P \subseteq \mathbb{R}^2$  and an opening cost  $f \in \mathbb{R}^+$ , and we want to find a set of facilities  $F \subseteq \mathbb{R}^2$  that minimizes

$$f \cdot |F| + \sum_{p \in P} \min_{q \in F} d(p, q)$$
,

where d(p,q) is the Euclidean distance between p and q. We obtain two main results:

• A  $(1 + \varepsilon)$ -approximation algorithm with running time

$$\mathcal{O}(n \log n (\log n \log \log n + (\log \log n)^8 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}))$$
,

which is  $\mathcal{O}(n \log^2 n \log \log n)$  for any constant  $\varepsilon$ .

The first (1 + ε)-approximation algorithm for the cost of the facility location problem for dynamic geometric data streams, i.e., when the stream consists of insert and delete operations of points from a discrete space {1,..., Δ}<sup>2</sup>. The streaming algorithm uses (log Δ) (1) space.

Our PTAS is significantly faster than any previously known  $(1+\varepsilon)$ -approximation algorithm for the problem, and is also relatively simple. Our algorithm for dynamic geometric data streams is the first  $(1+\varepsilon)$ -approximation algorithm for the cost of the facility location problem with polylogarithmic space, and it resolves an open problem in the streaming area.

Both algorithms are based on a novel and simple decomposition of an input point set P into small subsets  $P_i$ , such that:

- the cost of solving the facility location problem for each  $P_i$  is small (which means that for each  $P_i$  one needs to open only a small, polylogarithmic number of facilities),
- $\sum_i \mathsf{OPT}(P_i) \leq (1+\varepsilon) \cdot \mathsf{OPT}(P)$ , where for a point set P,  $\mathsf{OPT}(P)$  denotes the cost of an optimal solution for P.

The decomposition can be used directly to obtain the PTAS by splitting the point set in the subsets and efficiently solve the problem for each subset independently. By combining our partitioning with techniques to process dynamic data streams of sampling from the cells of the partition and estimating the cost from the sample, we obtain our data streaming algorithm.

#### 1 Introduction

The facility location problem is one of the most extensively studied problems in combinatorial optimization and operations research (see, e.g., [7, 9]). The goal is for a given set of customers to find an optimal placement of facilities that minimizes the cost of customer service. Opening a facility at a certain location incurs a certain cost called *opening cost*, and serving customers at other locations incurs another type of cost called *connection cost*. The goal is to minimize the sum of both costs. Typical examples of applications include placement of servers in a network or location planning for stores, restaurants, etc. The focus of this paper is on the (uniform) facility location problem on the plane. Formally, the problem is defined as follows:

DEFINITION 1.1. (EUCLIDEAN UNIFORM FACILITY LOCATION PROBLEM) Let  $P = \{p_1, \ldots, p_n\}$  be a set of n points in the Euclidean plane  $\mathbb{R}^2$  and let  $f \in \mathbb{R}^+$  be some fixed parameter (called opening cost). The (uniform) facility location problem is to find a set  $F \subseteq \mathbb{R}^2$  of points (called open facilities) that minimizes

(1.1) 
$$cost(P, F) = |F| \cdot f + \sum_{p \in P} d(p, F)$$
,

where  $d(p, F) = \min_{q \in F} d(p, q)$  is the Euclidean distance of p to the nearest open facility in F. (The first term on the right-hand side of (1.1) is called the opening cost and the second one is the connection cost.)

Given a point set  $P\subseteq\mathbb{R}^2$ , we denote the optimal cost of P by  $\mathsf{OPT}_P$ , and any set of optimal facilities by  $F_{\mathsf{OPT}_P}$  (or  $\mathsf{OPT}$  and  $F_{\mathsf{OPT}}$ , respectively, if P is clear from the context), i.e.,

$$\mathrm{OPT}_P \quad = \quad \min_{F \subset \mathbb{R}^2} \mathrm{COST}(P,F) = \mathrm{COST}(P,F_{\mathrm{OPT}_P}) \ .$$

We also consider the facility location problem for individual cells in  $\mathbb{R}^2$ . For any cell  $\mathfrak{c} \in \mathbb{R}^2$ , we define the cost of  $\mathfrak{c}$  as

<sup>\*</sup>Department of Computer Science and Centre for Discrete Mathematics and its Applications (DIMAP), University of Warwick, A.Czumaj@warwick.ac.uk. Research partially supported by the Centre for Discrete Mathematics and its Applications (DIMAP), and by EPSRC awards EP/D063191/1 and EP/G064679/1.

<sup>&</sup>lt;sup>†</sup>School of Computing Science, Simon Fraser University, clammers@cs.sfu.ca. Research partially supported by an Ebco Eppich and a PIMS Fellowship.

<sup>&</sup>lt;sup>‡</sup>Institute for Computer Science, University of Frankfurt, monemizadeh@em.uni-frankfurt.de. Supported in part by BMBF grant 06FY9097.

<sup>§</sup>Department of Computer Science, Technische Universität Dortmund, christian.sohler@tu-dortmund.de. This work has been supported by Deutsche Forschungsgemeinschaft (DFG) within the Collaborative Research Center SFB 876 "Providing Information by Resource-Constrained Analysis", project A2.

follows:

$$\mathrm{cost}(\mathfrak{c}) \quad = \quad \min_{F \subseteq \mathbb{R}^2} \left\{ \sum_{p \in P \cap \mathfrak{c}} d(p,F) + |F| \cdot f \right\} \ ,$$

where  $P \cap \mathfrak{c}$  denotes the set of all points in P that are contained in  $\mathfrak{c}$ .

We will also consider the contribution of any individual cell in  $\mathbb{R}^2$  for optimal facilities  $F_{\mathsf{OPT}_P}$ . Given a point set  $P\subseteq\mathbb{R}^2$  and a cell  $\mathfrak{c}\subseteq\mathbb{R}^2$ , for a fixed set of optimal facilities  $F_{\mathsf{OPT}_P}$ , let  $\mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c})$  be the connection cost in  $\mathsf{OPT}_P$  of all the points from P contained in  $\mathfrak{c}$  plus the opening cost in  $\mathsf{OPT}_P$  for the open facilities contained in  $\mathfrak{c}$ , i.e.,

$$\mathrm{COST}_{\mathsf{OPT}_P}(\mathfrak{c}) \ = \ \sum_{p \in P \cap \mathfrak{c}} d(p, F_{\mathsf{OPT}_P}) + |F_{\mathsf{OPT}_P} \cap \mathfrak{c}| \cdot f \ .$$

We will study the facility location problem both in the classical and in the streaming model of computation for dynamic geometric data streams. Since the problem is known to be NP-hard [20], we will focus on *approximation* algorithms. Furthermore, for the streaming model, given the structure of the problem (the output may be possibly of  $\Omega(|P|)$  size), we will only approximate the *cost* of the facility location problem. Our motivation to consider the cost is

- in a dynamic scenario, for example, when maintaining a wireless network among moving robots, it is helpful to verify whether the current solution has still acceptable cost, and
- the solution computed by the facility location problem can also be viewed as a clustering problem with a regularization term for the number of cluster, i.e., one pays for each additional cluster a cost of f and thus the cost of the facility location problem can be viewed as a structural property of the input data.
- **1.1 Our contribution.** The main new technical contribution of this paper is a novel and simple partitioning scheme that allows to compute a good approximate solution to the facility location problem by taking the union of solutions for the partitioned input. That is, we can efficiently find a partition  $\Lambda$  of  $[\Delta]^2$  such that  $\sum_{c \in \Lambda} \text{COST}(c) \leq (1+\varepsilon) \cdot \text{OPT}_P$ . Furthermore, the partition is designed to enable to very quickly compute almost optimal solutions for the cells  $c \in \Lambda$ . For that, we use the observation that if COST(c) is small, then an  $(1+\varepsilon)$ -approximation to COST(c) can be found very quickly via a reduction to the k-median problem.

Using our new partitioning scheme, we develop two algorithms:

• a  $(1 + \varepsilon)$ -approximation algorithm for the planar Euclidean facility location problem with uni-

- form cost running in time  $\mathcal{O}(n\log^2 n\log\log n + n\log n(\log\log n)^82^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)})$ , and
- a  $(1 + \varepsilon)$ -approximation algorithm for the *cost* of the facility location problem in *dynamic geometric data streams*, i.e., when the stream consists of insert and delete operations of points from the discrete space  $\{1,\ldots,\Delta\}^2$ , as introduced by Indyk [13]. The streaming algorithm uses  $(\frac{\log \Delta}{\varepsilon})^{\mathcal{O}(1)}$  space.

While polynomial-time approximation schemes for the planar Euclidean facility location problem with uniform cost have been known before [3, 17], our algorithm is arguably the simplest of those, and it is also significantly faster. No  $(1+\varepsilon)$ -approximation algorithm for the cost of the facility location problem in dynamic geometric data streams with polylogarithmic space has been known before, and the existence of a  $(1 + \varepsilon)$ -approximation algorithm with polylogarithmic space for this problem has been an open problem in the area of geometric streaming algorithms. The best approximation guarantee obtained in earlier works was constant [18]. Our streaming algorithm samples cells from the obtained partitioning scheme and approximates the cost by taking the average of the costs of the sample. The algorithm itself extends the ideas developed earlier in [1] and [14], with several new observations needed to overcome some technical obstacles caused by using these approaches to obtain a  $(1+\varepsilon)$ -approximation algorithm with polylogarithmic space. A byproduct of our work is an  $\mathcal{O}(n \log n \log \log n)$ -time algorithm that computes a constant-factor approximation for the facility location problem; the running time of this algorithm improves upon earlier constant-time approximation algorithms.

**1.2 Prior work.** The facility location problem has been extensively studied before in the combinatorial optimization and operations research. The problem is known to be NP-hard even in the geometric case. For general metrics, Hochbaum [12] gave the first non-trivial polynomialtime  $\mathcal{O}(\log n)$ -approximation algorithm and Shmoys, Tardos and Aardal [22] gave the first constant-factor approximation algorithm for arbitrary metric spaces; the approximation factor has since been improved several times and the currently best polynomial-time approximation algorithm due to Li [19] achieves a 1.488-approximation. On the negative side, Guha and Khuller [10] showed that there is no polynomial-time  $\alpha$ -approximation algorithm for  $\alpha < 1.463$ , unless  $\mathbf{NP} \subseteq \mathbf{DTIME}(n^{\mathcal{O}(\log \log n)})$ . The facility location problem has been also studied in the geometric setting. Arora, Raghavan, and Rao [3] gave the first PTAS for the geometric version of the problem, with a randomized algorithm achieving an  $(1 + \varepsilon)$ -approximation in  $\mathcal{O}(n^{1+\mathcal{O}(1/\varepsilon)} \log n)$ time. This has been later improved by Kolliopoulos and Rao [17], who designed an  $\mathcal{O}(n \log^8 n \, 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)})$ -time algorithm that outputs in expectation a  $(1+\varepsilon)$ -approximate solution  $^{1}$ .

Facility location has also been studied in the context of data streaming, initiated with work of Indyk [13], who gave a  $\operatorname{poly}(\log \Delta)$ -space streaming algorithm that approximates the optimal cost of the facility location problem within a factor of  $\mathcal{O}(\log^2 \Delta)$ . The best currently known streaming algorithm using  $\operatorname{poly}(\log \Delta)$  space is due to Lammersen and Sohler [18], which gives a  $\mathcal{O}(1)$ -approximation for this problem.

The facility location problem is closely related to the k-median problem. In geometric setting, Arora [2] gave the first PTAS, finding an  $(1+\varepsilon)$ -approximation in  $\mathcal{O}(n^{1+\mathcal{O}(1/\varepsilon)})$  time. The runtime was later improved in a series of papers, culminating with the running-time of  $\mathcal{O}(n+2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)}k^{\mathcal{O}(1)}\log^{\mathcal{O}(1)}n)$  by Har-Peled and Mazumdar [11] and  $\mathcal{O}(nk+2^{(k/\varepsilon)^{\mathcal{O}(1)}}\log^{k+2}n)$  by Chen [5].

### 2 Partitioning scheme

In this section we present a new partitioning scheme for the Euclidean uniform facility location problem. For simplicity of exposition, we assume a real number is always rounded up to the next integer number. Furthermore, we will assume that the input points are drawn from a grid of size  $\Delta$ , that is, from  $\{0,1,\ldots,\Delta\}^2$ . (While this may seem to be restrictive, this assumption can be made without loss of generality in most of the applications; see, e.g., Remark 3.1 below.) We assume that  $\Delta$  is a power of 2. For a number x, let  $[x] = \{0,1,\ldots,x\}$ , and so, any input point is in  $[\Delta]^2$ .

For any cell  $\mathfrak{c}$ , we denote the side length of  $\mathfrak{c}$  by  $\ell_{\mathfrak{c}}$  and the number of points inside  $\mathfrak{c}$  by  $n_{\mathfrak{c}}$ . For any cell  $\mathfrak{c}$  and any set P of points on the plane,  $P \cap \mathfrak{c}$  denotes the set of all points in P that are contained in  $\mathfrak{c}$ .

Randomly shifted nested grid partition. Our construction will assume that the input points are partitioned with respect to a nested grid dissection. To ensure appropriate properties of the input points, we will assume that the dissection is chosen at *random*. (This is somehow similar to the dissection used by Arora [2] in a PTAS for TSP and in related works.)

To define our dissection, we first place a nested grid set  $G_0,\ldots,G_i,\ldots,G_{\log\Delta+1}$  on the input cell  $[2\Delta]^2$  (which is twice the size of the original input cell) so that a cell  $\mathfrak c$  in a grid  $G_i$  has side length  $\ell_{\mathfrak c}=2^i$ . That is,  $G_{\log\Delta+1}$  has a single cell  $\mathfrak c$  with side length  $\ell_{\mathfrak c}=2\Delta$ , and any cell  $\mathfrak c$  in  $G_i$  is split into four sub-cells in  $G_{i-1}$ .

Next, we randomly shift the dissection. We choose a pair of integers  $a,b \in \{0,1,\ldots,\Delta\}$  independently and uniformly at random, and then move each point  $p \in P$  by

the vector (a, b).

We assume we have a unique numbering for cells in  $G_i$  so that when we refer to a cell  $\mathfrak{c} \in G_i$  we mean that this cell has a unique number  $\mathfrak{c}$  for  $1 \le \mathfrak{c} \le |G_i|$  according to this numbering. We call the four subcells of  $\mathfrak{c} \in G_i$ , which are in the grid  $G_{i-1}$ , the *children* of  $\mathfrak{c}$ , and  $\mathfrak{c}$  is the *parent* cell of each one of these four subcells.

Heavy and light cells. In our construction, we will need a deterministic factor  $\alpha=O(1)$  approximation algorithm for the cost facility location problem  $\mathbb A$ . The algorithm will be fixed throughout the entire construction. (In specific applications, as we will use it later in the paper, for our PTAS,  $\mathbb A$  will be the algorithm developed in this paper in Section 4, and for the streaming algorithm, we will assume that  $\mathbb A$  is an algorithm that computes the cost of an optimal solution of the facility location problem.)

For any cell  $\mathfrak c$  in a grid  $G_i,\ 0\leq i\leq \log\Delta+1$ , let us call  $\mathfrak c$  heavy if  $\mathbb A$  returns that the cost of  $\mathfrak c$  is greater than  $\alpha\aleph f$ ; otherwise we call  $\mathfrak c$  light. We will require that  $\aleph\geq c^*\cdot\left(\frac{\log\Delta+2}{\varepsilon}\right)^2$ , for a constant  $c^*$  defined later. Partition  $\Lambda$  of  $[2\Delta]^2$ . We define a hierarchical partition

**Partition A of**  $[2\Delta]^2$ . We define a hierarchical partition  $\Lambda$  of  $[2\Delta]^2$  into cells from a grid  $G_i$ ,  $0 \le i \le \log \Delta + 1$ , to be the set of all cells  $\mathfrak{c} \in \bigcup_{i=0}^{\log \Delta} G_i$  that are light and whose all ancestors are heavy. More formally, we use a recursive procedure  $Partition(\mathfrak{c})$ , which we initially call with  $\mathfrak{c}$  being the entire square  $[2\Delta]^2$ :

**Partition** ( $\mathfrak{c}$ )  $\triangleright$  *Recursively finds a nested partition of cell*  $\mathfrak{c}$ 

- Consider cell  $\mathfrak{c}$  with four children  $\mathfrak{c}_1, \mathfrak{c}_2, \mathfrak{c}_3, \mathfrak{c}_4$ .
- If cell c is heavy, then
  - recursively call Partition(c<sub>1</sub>), Partition(c<sub>2</sub>),
     Partition(c<sub>3</sub>), and Partition(c<sub>4</sub>),
  - return the union of the obtained partitions as the partition of c.
- Else, if c is light, then
  - return  $\{c\}$  itself as the partition of c.

The procedure above returns a partition  $\Lambda$  of  $[2\Delta]^2$  into a set of cells from grids  $G_i$ ,  $0 \le i \le \log \Delta + 1$ .

Now we present our main theorem describing key properties of our partition  $\Lambda$ .

THEOREM 2.1. (PARTITION THEOREM) Let  $\varrho \in (0,1)$  be any constant. Let P be any set of points in  $[\Delta]^2$  that is randomly shifted in  $[2\Delta]^2$ . Then there are constants  $c = c(\varrho), c^* = c^*(\varrho)$  such that if  $\aleph \geq c^* \cdot \left(\frac{\log \Delta + 2}{\varepsilon}\right)^2$  then partition  $\Lambda$  of  $[2\Delta]^2$  satisfies the following properties:

<sup>&</sup>lt;sup>1</sup>A preliminary version of that paper [16] claimed a faster running time, but this has been later retracted and corrected in [17].

- (1) for every cell  $\mathfrak{c} \in \Lambda$ ,  $COST(\mathfrak{c}) \leq \frac{c \cdot (\log \Delta + 2)^2}{\varepsilon^2} \cdot f$ ,
- (2)  $\sum_{\mathfrak{c}\in\mathbf{\Lambda}} \mathsf{COST}(\mathfrak{c}) \leq (1+\varepsilon) \cdot \mathsf{OPT}_P$  with probability at least  $1-\varrho$ .

The rest of this section is devoted to the proof of Theorem 2.1. We first introduce useful notation in Section 2.1, then we prove basic properties of our construction in Sections 2.2 and 2.3, and we finalize the proof in Section 2.4.

In the entire analysis below we assume that  $F_{\mathsf{OPT}_P}$  is a fixed optimal set of facilities, and with that,  $\mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c})$  is well defined for any cell  $\mathfrak{c}$ .

![](_page_3_Picture_5.jpeg)

Figure 1: (a) Partition of a cell  $\mathfrak c$  into a core and a frame, and (b) the buffer-net of  $\mathbb I_\mathfrak c$ .

**2.1 Frames, cores, and buffer-nets.** Let us fix  $\lambda = \frac{\varepsilon}{12\cdot(1+3/\varrho)\cdot(\log\Delta+2)}$ . A *core* of a cell c is the  $(1-2\lambda)\ell_c \times (1-2\lambda)\ell_c$  square whose center is at the center of c. A *frame* of a cell c is obtained from c by removing the core of c. See Figure 1.a. (In other words, a frame of c consists of all points in the plane contained in c that are at distance less than  $\lambda \cdot \ell_c$  from the boundary of c, and a core of c consists of all points in the plane contained in c that are at distance greater than or equal to  $\lambda \cdot \ell_c$  from the boundary of c.) For a cell c, let  $\mathbb{I}_c$  denote its core and  $\mathbb{B}_c$  denote its frame.

**Buffer-nets.** In our construction, we will frequently allow to open new facilities around either a core or a frame of a cell. Consider any cell  $\mathfrak c$  and its core  $\mathbb I_\mathfrak c$  and frame  $\mathbb B_\mathfrak c$ .  $\mathbb B_\mathfrak c$  may be seen as union of four stripes around  $\mathbb I_\mathfrak c$  of size  $(\lambda \cdot \ell_\mathfrak c) \times \ell_\mathfrak c$  each (cf. Figure 1.a). Place  $1/\lambda$  points in each stripe, by first partitioning each stripe into  $1/\lambda$  disjoint  $(\lambda \cdot \ell_\mathfrak c) \times (\lambda \cdot \ell_\mathfrak c)$  squares and then choosing the center of each square (cf. Figure 1.b). Call the obtained points the *buffernet* of  $\mathbb I_\mathfrak c$ . Note that each buffer-net of a core has  $4(\frac{1}{\lambda}-1)$  points.

A similar construction can be done for  $\mathbb{B}_{\mathfrak{c}}$ . Let us draw eight stripes of width  $\lambda \cdot \ell_{\mathfrak{c}}$  around the boundary of  $\mathbb{B}_{\mathfrak{c}}$ : four  $(\lambda \cdot \ell_{\mathfrak{c}}) \times ((1+2\lambda) \cdot \ell_{\mathfrak{c}})$  stripes outside  $\mathbb{B}_{\mathfrak{c}}$  and four  $(\lambda \cdot \ell_{\mathfrak{c}}) \times ((1-2\lambda) \cdot \ell_{\mathfrak{c}})$  stripes inside  $\mathbb{B}_{\mathfrak{c}}$  (see Figure 2.a). (We call the union of the stripes the *boundary* of  $\mathbb{B}_{\mathfrak{c}}$  and

![](_page_3_Picture_10.jpeg)

Figure 2: (a) Partition of a cell  $\mathfrak c$  into a core and a frame (Figure 1.a) with the boundary, that is, an extension of  $\mathbb B_{\mathfrak c}$  through the stripes of width  $\lambda \cdot \ell_{\mathfrak c}$  on the outside and inside of  $\mathbb B_{\mathfrak c}$ , and (b) the corresponding buffer-net of  $\mathbb B_{\mathfrak c}$ .

denote it by  $\mathbb{Q}_{\mathfrak{c}}$ .<sup>2</sup>) Then, we partition each stripe into disjoint  $(\lambda \cdot \ell_{\mathfrak{c}}) \times (\lambda \cdot \ell_{\mathfrak{c}})$  squares and place points in the center of each square (see Figure 2.b). The obtained points are called the *buffer-net* of  $\mathbb{B}_{\mathfrak{c}}$ . Note that each buffer-net of a frame has  $8(\frac{1}{\lambda}-1)$  points.

The following key properties of buffer-nets will be used in the paper.

CLAIM 2.1. (BUFFER-NET PROPERTY FOR CORES) For any cell  $\mathfrak{c}$ , any point  $p \in \mathbb{I}_{\mathfrak{c}}$ , and any point  $q \notin \mathfrak{c}$ , there is a point x in the buffer-net of  $\mathbb{I}_{\mathfrak{c}}$  such that

$$d(p,x) \leq d(p,q)$$
.

*Proof.* Let z be the minimum distance of p to the frame of  $\mathfrak c$ . Since the frame of  $\mathfrak c$  has a width of  $\lambda \ell_{\mathfrak c}$  and due to the construction of the buffer-net of  $\mathbb I_{\mathfrak c}$ , the distance of any point from the border of the frame of  $\mathfrak c$  to the closest point in the buffer-net of  $\mathbb I_{\mathfrak c}$  is at most  $\sqrt{2}\lambda\ell_{\mathfrak c}/2$ . Thus, by triangle inequality, the distance of p to its closest point x in the buffernet of  $\mathbb I_{\mathfrak c}$  is at most  $z+\sqrt{2}\lambda\ell_{\mathfrak c}/2< z+\lambda\ell_{\mathfrak c}$ . Since the frame of  $\mathfrak c$  has a width of  $\lambda\ell_{\mathfrak c}$ , the distance of p to the closest point  $q\notin\mathfrak c$  is at least  $z+\lambda\ell_{\mathfrak c}$ .

CLAIM 2.2. (BUFFER-NET PROPERTY FOR FRAMES) For any cell c, any point  $p \in \mathbb{B}_c$ , and any point q that is not contained in  $\mathbb{B}_c$  nor in the boundary of  $\mathbb{B}_c$ , there is a point x in the buffer-net of  $\mathbb{B}_c$  with  $d(p,x) \leq d(p,q)$ .

*Proof.* The proof is the same as that of Claim 2.1, with the only difference that  $p \in \mathbb{B}_c$  and q is a point that is not contained in  $\mathbb{B}_c$  nor in the boundary of  $\mathbb{B}_c$  and z is the minimum distance of p to the boundary of  $\mathbb{B}_c$ .

 $<sup>^2</sup>$ We will ignore any part of the boundary of  $\mathbb{B}_{\mathfrak{c}}$  that lies outside of the original square  $[2\Delta]^2$ .

**2.2 Bounding the cost of cells.** We will now prove three auxiliary lemmas bounding the cost of cores and frames.

LEMMA 2.1. For every cell c, we have

$$\mathit{COST}(\mathbb{I}_{\mathfrak{c}}) \leq \mathit{COST}_{\mathit{OPT}_P}(\mathfrak{c}) + \frac{4f}{\lambda} \ .$$

*Proof.* We will construct a feasible solution for  $\mathbb{I}_{\mathfrak{c}}$  with the cost upper bounded by  $\mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c}) + 4\left(\frac{1}{\lambda} - 1\right)f$ . For this purpose, we open a facility at every point in  $F_{\mathsf{OPT}_P} \cap \mathfrak{c}$ . Furthermore, we open facilities for every point in the buffer net of  $\mathbb{I}_{\mathfrak{c}}$ .

For every point  $p \in P \cap \mathbb{I}_{\mathsf{c}}$ , if its nearest open facility in  $F_{\mathsf{OPT}_P}$  is contained in  $\mathsf{c}$ , then we connect p to that facility. Otherwise, we connect p to the nearest point in the buffernet of  $\mathbb{I}_{\mathsf{c}}$ . Claim 2.1 ensures that in the latter case, the chosen point q from the buffer-net of  $\mathbb{I}_{\mathsf{c}}$  satisfies  $d(p,q) \leq d(p,F_{\mathsf{OPT}_P})$ .

We have constructed a feasible solution to the facility location for  $\mathbb{I}_{\mathbf{c}}$  whose cost is upper bounded by  $\sum_{p\in P\cap\mathbb{I}_{\mathbf{c}}}d(p,F_{\mathsf{OPT}_P})$  plus the cost of opening facilities in  $F_{\mathsf{OPT}_P}\cap\mathbf{c}$  plus the cost of opening some facilities in the buffernet of  $\mathbb{I}_{\mathbf{c}}$ . Since the number of points in the buffer-net of  $\mathbb{I}_{\mathbf{c}}$  is at most  $4\left(\frac{1}{\lambda}-1\right)$  and since

$$\begin{split} \mathrm{COST}_{\mathsf{OPT}_P}(\mathfrak{c}) & = \sum_{p \in P \cap \mathfrak{c}} d(p, F_{\mathsf{OPT}_P}) + |F_{\mathsf{OPT}_P} \cap \mathfrak{c}| \cdot f \\ & \geq \sum_{p \in P \cap \mathbb{I}_{\mathfrak{c}}} d(p, F_{\mathsf{OPT}_P}) + |F_{\mathsf{OPT}_P} \cap \mathfrak{c}| \cdot f \enspace, \end{split}$$

we obtain the following:

$$\begin{split} &\operatorname{COST}(\mathbb{I}_{\mathfrak{c}}) \\ &\leq \sum_{p \in P \cap \mathbb{I}_{\mathfrak{c}}} d(p, F_{\operatorname{OPT}_P}) + |F_{\operatorname{OPT}_P} \cap \mathfrak{c}| \cdot f + 4 \left(\frac{1}{\lambda} - 1\right) f \\ &\leq & \operatorname{COST}_{\operatorname{OPT}_P}(\mathfrak{c}) + 4 \left(\frac{1}{\lambda} - 1\right) f \ . \end{split}$$

LEMMA 2.2. For every cell c, we have

$$COST(\mathbb{B}_{\mathfrak{c}}) \leq COST_{OPT_{P}}(\mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}}) + \frac{8f}{\lambda}$$
,

and

$$\mathit{COST}(\mathfrak{c}) \leq \mathit{COST}_{\mathit{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) + \frac{8f}{\lambda}$$
 .

*Proof.* The proof is the same as that of Lemma 2.1, with the only difference in a different number of points in the buffernet of  $\mathbb{B}_{\mathfrak{c}}$ , which is now  $8\left(\frac{1}{\lambda}-1\right)$  (versus  $4\left(\frac{1}{\lambda}-1\right)$  in the proof of Lemma 2.1), and in the use of Claims 2.1 and 2.2 instead of solely relying on Claim 2.1.

LEMMA 2.3. For our partition  $\Lambda$ , the following bound holds:

$$\mathbf{E}\big[\sum_{\mathfrak{c}\in \mathbf{A}} \mathit{cost}_{\mathit{OPT}_P}(\mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}})\big] \leq 12\lambda(\log \Delta + 2) \cdot \mathit{OPT}_P \ ,$$

where the expectation is over the choice of the random choice of the shift of the dissection.

Proof. Let us take the nested grids  $G_0,G_1,\ldots,G_{\log\Delta+1}$ , and all cells in each  $G_i$ . For each cell, let us take its frame and let  $\mathfrak{W}_i$  be the union of frames and their boundaries for all cells in  $G_i$ . It is easy to see that the area of each  $\mathfrak{W}_i$  is at most  $12\lambda$  fraction of the total area (the area of all frames is at most  $4\lambda$  fraction of the total area and the area of all boundaries of the frames is at most  $8\lambda$  fraction of the total area). Hence, for any point  $p \in P \cup F_{\mathsf{OPT}_P}$ , the probability that  $p \in \mathfrak{W}_i$  is at most  $12\lambda$ . Indeed, for any  $single\ (1\times 1)$  cell  $\mathfrak{c} \in G_0$  in  $[2\Delta]^2$ ,  $\Pr[p \in \mathfrak{c}] \leq \frac{1}{(2\Delta)^2}$ . Furthermore, the number of single cells  $\mathfrak{c}$  that are in  $\mathfrak{W}_i$  is at most  $12\lambda \cdot (2\Delta)^2$ . Hence, we have  $\Pr[p \in \mathfrak{W}_i] \leq 12\lambda$ .

For every  $p \in P \cup F_{\mathsf{OPT}_P}$ , let us define val(p) as follows:

$$val(p) = \begin{cases} f & \text{if } p \in F_{\mathsf{OPT}_P} \\ d(p, F_{\mathsf{OPT}_P}) & \text{if } p \notin F_{\mathsf{OPT}_P} \end{cases},$$

Observe that  $\mathsf{OPT}_P = \sum_{p \in P \cup F_{\mathsf{OPT}_P}} val(p)$ . For every  $p \in P \cup F_{\mathsf{OPT}_P}$ , let  $X_p$  be the indicator random variable for the event  $p \in \bigcup_{\mathfrak{c} \in \Lambda} \mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}}$ , and let  $Y_p$  be the indicator random variable for the event  $p \in \bigcup_i \mathfrak{W}_i$ . Notice that  $\mathbf{E}[X_p] \leq \mathbf{E}[Y_p]$ .

Let us consider the *contribution* of a single point  $p \in P \cup F_{\mathsf{OPT}_P}$  to  $\mathbf{E} \big[ \sum_{\mathfrak{c} \in \Lambda} \mathsf{COST}_{\mathsf{OPT}_P} (\mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}}) \big]$ . If  $p \notin \bigcup_{\mathfrak{c} \in \Lambda} \mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}}$ , then the contribution is none; otherwise, the contribution is equal to val(p). Hence,

$$\begin{split} \mathbf{E}[\sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}_{\mathsf{OPT}_P}(\mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}})] \\ &= \sum_{p \in P \cup F_{\mathsf{OPT}_P}} \mathbf{E}[X_p] \cdot val(p) \\ &\leq \sum_{p \in P \cup F_{\mathsf{OPT}_P}} \mathbf{E}[Y_p] \cdot val(p) \\ &\leq \sum_{p \in P \cup F_{\mathsf{OPT}_P}} (12 \cdot \lambda \cdot (\log \Delta + 2)) \cdot val(p) \\ &= 12 \, \lambda \, (\log \Delta + 2) \cdot \mathsf{OPT}_P \ . \end{split}$$

**2.3** Bounding the size of  $\Lambda$ . Our next goal will be to estimate the two sums  $\sum_{c \in \Lambda} \mathsf{COST}(\mathbb{I}_c)$  and  $\sum_{c \in \Lambda} \mathsf{COST}(\mathbb{B}_c)$  in terms of  $\mathsf{OPT}_P$ . For that we first bound (in Lemma 2.4 below) the number of cells in the partition  $\Lambda$ , as a function of  $\mathsf{OPT}_P$  and f.

We begin with a simple claim that follows directly from the definition of light cells.

CLAIM 2.3. If the algorithm  $\mathbb{A}$  returns an  $\alpha$ -approximation of the cost of the facility location problem<sup>3</sup>, then for every

 $<sup>\</sup>overline{\ \ }^3$ That is, for any set X of points in the plane,  $\mathbb A$  computes a value  $\mathsf{COST}_\mathbb A(X)$  such that  $\mathsf{OPT}_X \leq \mathsf{COST}_\mathbb A(X) \leq \alpha \cdot \mathsf{OPT}_X$ .

light cell c and for every heavy cell  $c^*$ , we have  $COST(c) \leq CLAIM 2.7$ . For every cell  $c \in \Lambda$ ,  $\alpha \aleph f$  and  $COST(\mathfrak{c}^*) > \aleph f$ .

We call a cell 
$$\mathfrak{c}\in\bigcup_{i=0}^{\log\Delta+1}G_i$$
 loaded if 
$$\mathrm{COST}_{\mathsf{OPT}_P}(\mathfrak{c}\cup\mathbb{Q}_{\mathfrak{c}})\geq (\aleph-8/\lambda)f$$
.

CLAIM 2.4. If c is a heavy cell, then c is loaded.

*Proof.* If c is a heavy cell, then by Lemma 2.2,

$$\mathrm{COST}(\mathfrak{c}) \leq \mathrm{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) + \frac{8f}{\lambda} \enspace,$$

and by Claim 2.3, we obtain  $COST(c) > \aleph f$ . Hence

$$\mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) \geq \mathsf{COST}(\mathfrak{c}) - \frac{8 \cdot f}{\lambda} > \aleph f - \frac{8 \cdot f}{\lambda} \ . \quad \Box$$

We call a loaded cell  $\mathfrak{c}$  marked if either (i)  $\mathfrak{c} \in \Lambda$ , or (ii) if  $\mathfrak{c}$  has no ancestor in  $\Lambda$  and no descendant of  $\mathfrak{c}$  is loaded. We will now state some basic properties of marked cells.

CLAIM 2.5. All marked cells are disjoint.

*Proof.* Let  $\mathfrak{c}$  and  $\mathfrak{c}'$  be any two marked cells,  $\mathfrak{c} \neq \mathfrak{c}'$ . They are not disjoint only if one of them is an ancestor of another. If  $\mathfrak{c},\mathfrak{c}'\in\Lambda$ , then since  $\Lambda$  is a partition of  $[2\Delta]^2$ , we have  $\mathfrak{c}$ and  $\mathfrak{c}'$  disjoint. If none of  $\mathfrak{c}$ ,  $\mathfrak{c}'$  is in  $\Lambda$ , then since neither one of them can be an ancestor of another, again we have c and  $\mathfrak{c}'$  disjoint. Finally, if  $\mathfrak{c} \in \Lambda$  and  $\mathfrak{c}' \notin \Lambda$ , then the definition of  $\mathfrak{c}'$  being marked implies that  $\mathfrak{c}$  cannot be an ancestor of  $\mathfrak{c}'$ because  $\mathfrak{c} \in \Lambda$ , and  $\mathfrak{c}$  cannot be a descendant of  $\mathfrak{c}'$  because  $\mathfrak{c}$ is loaded.

We have also the following claim.

CLAIM 2.6. If c is a loaded cell and has no proper ancestor in  $\Lambda$ , then c has a marked descendant (which might be equal to  $\mathfrak{c}$ ).

*Proof.* Let c be a loaded cell that has no proper ancestor in  $\Lambda$ . Since  $\Lambda$  is a partition of the input space, it follows that c is either in  $\Lambda$  or it has a proper descendant in  $\Lambda$ . In the former case, c is loaded and in  $\Lambda$  and so it is marked. In the latter case, let  $\mathfrak{c}^*$  be the deepest descendant of  $\mathfrak{c}$  in  $\Lambda$  and let  $\mathfrak{c}'$  be the parent cell of  $\mathfrak{c}^*$ . Notice that by our choice of  $\mathfrak{c}'$  all subcells of  $\mathfrak{c}'$  must be in  $\Lambda$  (for otherwise  $\mathfrak{c}^*$  would not be the deepest descendant of  $\mathfrak{c}$  in  $\Lambda$ ). If one of these subcells is loaded it is also marked. Otherwise,  $\mathfrak{c}'$  has no loaded descendants and no ancestor in  $\Lambda$  and so it is marked. Hence, in all cases there is a marked descendant of c.

In our analysis, we will assign every cell  $\mathfrak{c} \in \Lambda$  to a marked cell  $\vartheta(\mathfrak{c})$  as follows. If  $\mathfrak{c} \in \Lambda$  is marked, then  $\vartheta(\mathfrak{c}) = \mathfrak{c}$ . Otherwise, let us consider the parent cell  $\mathfrak{c}^*$  of cell  $\mathfrak{c}$ . Since cell  $\mathfrak{c}^*$  is heavy by the definition of  $\Lambda$ , Claim 2.4 implies that  $\mathfrak{c}^*$  is loaded, and then Claim 2.6 ensures that  $\mathfrak{c}^*$  has a marked descendant. Let  $\mathfrak{c}'$  be any of the marked descendants of  $\mathfrak{c}^*$ ; we set  $\vartheta(\mathfrak{c}) = \mathfrak{c}'$ .

$$COST_{OPT_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) \leq COST_{OPT_P}(\vartheta(\mathfrak{c}) \cup \mathbb{Q}_{\vartheta(\mathfrak{c})})$$
.

*Proof.* Observe that if  $\mathfrak{c} \in \Lambda$  is loaded, then our construction ensures that  $\vartheta(\mathfrak{c}) = \mathfrak{c}$ , and hence

$$\mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) = \mathsf{COST}_{\mathsf{OPT}_P}(\vartheta(\mathfrak{c}) \cup \mathbb{Q}_{\vartheta(\mathfrak{c})})$$
.

Otherwise, if  $\mathfrak{c} \in \Lambda$  is not loaded, then  $COST_{OPT_{\mathcal{D}}}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) <$  $(\aleph - 8/\lambda)f$ , and since  $\vartheta(\mathfrak{c})$  is marked,

$$COST_{OPT_P}(\vartheta(\mathfrak{c}) \cup \mathbb{Q}_{\vartheta(\mathfrak{c})}) \geq (\aleph - 8/\lambda)f$$
,

from which the claim follows.

CLAIM 2.8. For every marked cell c, the number of cells  $\mathfrak{c}' \in \Lambda$  for which  $\vartheta(\mathfrak{c}') = \mathfrak{c}$ , is at most  $3(\log \Delta + 1) + 1$ .

*Proof.* If  $\mathfrak{c} = \vartheta(\mathfrak{c}')$ , then the parent of cell  $\mathfrak{c}'$  must be an ancestor of c (not necessarily a proper ancestor, that is, it is possible that  $\mathfrak{c}$  is the parent of  $\mathfrak{c}'$ ). Hence,  $\mathfrak{c}'$  is a child of an ancestor of c. Since there are at most  $\log \Delta + 2$  ancestors of c, and each of them (except the one at the most bottom level, in  $G_0$ ) has four children, there are at most  $4(\log \Delta + 1) + 1$ cells  $\mathfrak{c}'$  for which we may have  $\vartheta(\mathfrak{c}') = \mathfrak{c}$ . (We have term "1" to count the case when  $\mathfrak{c} \in G_0$ .) We can reduce this bound further by observing that no ancestor  $\mathfrak{c}^*$  of  $\mathfrak{c}$  will have  $\vartheta(\mathfrak{c}^*) = \mathfrak{c}$ , because all ancestors of  $\mathfrak{c}$  are loaded. Therefore, for every proper ancestor of c there are at most three children  $\mathfrak{c}'$  for which we may have  $\vartheta(\mathfrak{c}') = \mathfrak{c}$ , and hence the number of possible cells  $\mathfrak{c}'$  for which we may have  $\vartheta(\mathfrak{c}') = \mathfrak{c}$  is upper bounded by  $3(\log \Delta + 1) + 1$ .

CLAIM 2.9. For any set  $\mathcal{X}$  of disjoint cells in  $[2\Delta]^2$ ,  $\sum_{\mathfrak{c} \in \mathcal{X}} \mathit{COST}_{\mathit{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) \leq 5 \cdot \mathit{OPT}_P.$ 

*Proof.* This follows from the fact that every point  $p \in P$ appears in at most five terms in

$$\begin{split} \sum_{\mathfrak{c} \in \mathcal{X}} \mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) = \\ \sum_{\mathfrak{c} \in \mathcal{X}} \sum_{p \in P \cap (\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}})} (d(p, F_{\mathsf{OPT}_P}) + |F_{\mathsf{OPT}_P} \cap (\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}})|f) \ . \end{split}$$

Indeed, once if  $p \in \mathfrak{c}$ , and at most four times if p is in the left, the right, the top, and the bottom boundary of some cell c'.

With this, we are ready to prove the following upper bound on the number of cells in  $\Lambda$ .

**LEMMA 2.4.** 

$$|\mathbf{\Lambda}| \leq \frac{15 \cdot (\log \Delta + 2) \cdot \mathit{OPT}_P}{(\aleph - \frac{8}{\lambda}) \cdot f} \ .$$

Proof.

$$\begin{split} &15 \cdot (\log \Delta + 2) \cdot \mathsf{OPT}_P \\ & \geq \ \ 3 \cdot (\log \Delta + 2) \cdot \sum_{\mathfrak{c} \text{ is marked}} \mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) \\ & \geq \sum_{\mathfrak{c} \text{ is marked}} \mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c} \cup \mathbb{Q}_{\mathfrak{c}}) \cdot |\{\mathfrak{c}' \in \mathbf{\Lambda} : \vartheta(\mathfrak{c}') = \mathfrak{c}\}| \\ & \geq \sum_{\mathfrak{c} \text{ is marked}} ((\aleph - \frac{8}{\lambda}) \cdot f) \cdot |\{\mathfrak{c}' \in \mathbf{\Lambda} : \vartheta(\mathfrak{c}') = \mathfrak{c}\}| \\ & = \ \ (\aleph - \frac{8}{\lambda}) \cdot f \cdot |\mathbf{\Lambda}| \ \ , \end{split}$$

where the first inequality follows from Claims 2.5 and 2.9, the second one from Claim 2.8, the third one from the definition of loaded cells and the last identity follows from the fact that

$$\sum_{\mathfrak{c} ext{ is marked}} |\{\mathfrak{c}' \in \mathbf{\Lambda} : \vartheta(\mathfrak{c}') = \mathfrak{c}\}| = |\mathbf{\Lambda}| \enspace .$$

This yields the proof.

**2.4 Completing the proof of Partition Theorem 2.1.** Now we are ready to complete the proof of the Partition

Now we are ready to complete the proof of the Partition Theorem 2.1. We will first fix the constant  $\varrho$  for the probability bound, and then specify the values for  $\lambda$  and  $\aleph$ : we have

$$\lambda = \frac{\varepsilon}{12 \cdot (1 + 3/\varrho) \cdot (\log \Delta + 2)}$$

and we will require that

$$\aleph \ge \frac{732 \cdot (1 + 3/\varrho)^2 \cdot (\log \Delta + 2)^2}{\varepsilon^2}$$

Part (1) of the Partition Theorem 2.1 follows immediately from Claim 2.3 and from the fact that we have assumed that the algorithm  $\mathbb{A}$  used to define heavy and light cells is a constant-factor approximation algorithm for the cost facility location problem.

The proof of part (2) of the Partition Theorem 2.1 is split into two parts, one bounding  $\sum_{\mathfrak{c}\in\Lambda} \mathsf{COST}(\mathbb{I}_{\mathfrak{c}})$  and another one bounding  $\sum_{\mathfrak{c}\in\Lambda} \mathsf{COST}(\mathbb{B}_{\mathfrak{c}})$ .

In order to upper bound  $\sum_{c \in \Lambda} COST(\mathbb{I}_c)$ , we use Lemmas 2.1 and 2.4 to obtain the following:

$$\begin{split} \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}(\mathbb{I}_{\mathfrak{c}}) & \leq & \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \left( \mathsf{COST}_{\mathsf{OPT}_P}(\mathfrak{c}) + \frac{4f}{\lambda} \right) \\ & = & \mathsf{OPT}_P + |\mathbf{\Lambda}| \cdot \frac{4f}{\lambda} \\ & \leq & \mathsf{OPT}_P + \frac{60 \cdot (\log \Delta + 2)}{\lambda \aleph - 8} \cdot \mathsf{OPT}_P \enspace . \end{split}$$

Thus, our bounds for  $\lambda$  and  $\aleph$  yield the following:

$$(2.2) \qquad \sum_{\mathfrak{c} \in \mathbf{A}} \mathsf{COST}(\mathbb{I}_{\mathfrak{c}}) \quad \leq \quad \big(1 + \tfrac{\varepsilon}{1 + 3/\varrho}\big) \cdot \mathsf{OPT}_P \ .$$

Next, we upper bound  $\sum_{\mathfrak{c}\in \Lambda} \text{COST}(\mathbb{B}_{\mathfrak{c}}).$  We have the following:

$$\begin{split} \mathbf{E} \big[ \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}(\mathbb{B}_{\mathfrak{c}}) \big] & \leq & \mathbf{E} \big[ \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}_{\mathsf{OPT}_P} \big( \mathbb{B}_{\mathfrak{c}} \cup \mathbb{Q}_{\mathfrak{c}} \big) + \frac{8f}{\lambda} \big] \\ & \leq & 12\lambda (\log \Delta + 2) \cdot \mathsf{OPT}_P + \frac{8f|\mathbf{\Lambda}|}{\lambda} \ , \end{split}$$

where the first inequality follows from Lemma 2.2 and the second one follows from Lemma 2.3. Then, we observe that since  $\lambda = \frac{\varepsilon}{12(1+3/\varrho)(\log\Delta+2)}$ , we obtain  $12\,\lambda\,(\log\Delta+2)\cdot \mathsf{OPT}_P \leq \frac{\varepsilon}{1+3/\varrho}\cdot \mathsf{OPT}_P$ .

Further,  $|\mathbf{\Lambda}| \cdot \frac{4f}{\lambda} \leq \frac{\varepsilon}{1+3/\varrho} \cdot \mathsf{OPT}_P$  from our analysis above (inequality (2.2)), and hence  $\frac{8f|\mathbf{\Lambda}|}{\lambda} \leq \frac{2 \cdot \varepsilon}{1+3/\varrho} \cdot \mathsf{OPT}_P$ . This yields

$$\mathbf{E}\big[\sum_{\mathfrak{c}\in\mathbf{A}}\mathsf{COST}(\mathbb{B}_{\mathfrak{c}})\big] \leq \frac{3}{1+3/\varrho}\cdot\varepsilon\cdot\mathsf{OPT}_P\ .$$

Therefore, Markov inequality implies that with probability at least  $1-\varrho$  holds  $\sum_{\mathfrak{c}\in\mathbf{\Lambda}} \mathsf{COST}(\mathbb{B}_{\mathfrak{c}}) \leq \frac{1}{\varrho} \cdot \frac{3}{1+3/\varrho} \cdot \varepsilon \cdot \mathsf{OPT}_P$ , that is, with probability at least  $1-\varrho$  holds

$$(2.3) \qquad \sum_{\mathfrak{c} \in \Lambda} \mathsf{COST}(\mathbb{B}_{\mathfrak{c}}) \leq \frac{3}{\varrho + 3} \cdot \varepsilon \cdot \mathsf{OPT}_{P} \ .$$

Now the proof of part (2) of the Partition Theorem 2.1 follows directly from inequalities (2.2) and (2.3), and from the fact that for every cell  $\mathfrak c$  we have

$$COST(\mathfrak{c}) < COST(\mathbb{I}_{\mathfrak{c}}) + COST(\mathbb{B}_{\mathfrak{c}})$$
.

If we sum up these bounds, we obtain that with probability at least  $1-\varrho$  the following holds

$$\begin{split} \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}(\mathfrak{c}) & \leq & \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}(\mathbb{I}_{\mathfrak{c}}) + \sum_{\mathfrak{c} \in \mathbf{\Lambda}} \mathsf{COST}(\mathbb{B}_{\mathfrak{c}}) \\ & \leq & (1 + \frac{\varepsilon}{1 + 3/\varrho}) \cdot \mathsf{OPT}_P + \frac{3}{\varrho + 3} \varepsilon \cdot \mathsf{OPT}_P \\ & = & (1 + \varepsilon) \cdot \mathsf{OPT}_P \enspace . \end{split}$$

#### 3 Fast $(1 + \varepsilon)$ -approximation for facility location

With Theorem 2.1 at hand, we can deign our fast  $(1 + \varepsilon)$ -approximation for the facility location problem and show that it runs in  $\mathcal{O}(n \log n (\log \Delta \log \log n + (\log \log (n\Delta))^8))$  time (assuming that  $\varepsilon$  is an arbitrary constant).

In this section, to define heavy and light cells in the partitioning scheme, we will use as  $\mathbb{A}$  a deterministic  $\alpha$ -factor approximation algorithm for the facility location problem, as developed later in Section 4, in Theorem 4.1. This algorithm runs in time  $\mathcal{O}(n \log n \log \log n)$  and ensures that  $\alpha = \mathcal{O}(1)$ .

# PTAS(P)

- Find a partition  $\Lambda$  of  $[2\Delta]^2$  as promised in Theorem 2.1, using as  $\mathbb{A}$  the algorithm from Section 4.
- For each cell c ∈ Λ: Find a (1 + ε)-approximation for the facility location problem for c.
- Return the union of the obtained solutions

From now on, let |P| = n. We have three simple claims that describe properties of the algorithm.

CLAIM 3.1. Partition  $\Lambda$  of  $[2\Delta]^2$  can be found in  $\mathcal{O}(n \log \Delta \log n \log \log n)$  time.

*Proof.* To find the partition  $\Lambda$ , we have to go through the nested grid  $G_0, G_1, \ldots, G_{\log \Delta + 1}$  and check if the appropriated cells are heavy or not. This requires calls to the algorithm  $\mathbb{A}$ , where in each grid, we have to consider some set of cells with the total number of points being at most n. Hence, the total running time is  $(\log \Delta + 2) \times \mathcal{O}(n \log n \log \log n)$ , by Theorem 4.1.

Our next claim follows directly from an earlier PTAS for facility location due to Kolliopoulos and Rao [17]. (Let us recall that for any cell  $\mathfrak c$ , the number of points from P inside  $\mathfrak c$  is denoted by  $n_{\mathfrak c}$ .)

CLAIM 3.2. For any cell  $\mathfrak{c} \in \Lambda$  one can find a  $(1 + \varepsilon)$ -approximation for facility location for  $\mathfrak{c}$  in time

$$\mathcal{O}(n_{\mathfrak{c}}\log^8 n_{\mathfrak{c}}\log n2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)})$$
;

the algorithm is randomized and it errs with probability at most  $1/n^2$ .

*Proof.* The claims follows directly from the result due to Kolliopoulos and Rao [17] for the facility location problem that gives a randomized algorithm that "with high probability" finds a  $(1 + \varepsilon)$ -approximation for the facility location problem for  $\mathfrak{c}$  in time  $\mathcal{O}(n_{\mathfrak{c}} \cdot \log^8 n_{\mathfrak{c}} \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)})$ . However, since the error probability is proportional to the size of the input  $n_{\mathfrak{c}}$ , we have to repeat this algorithm  $\mathcal{O}(\log n)$  times and then choose the best solution, to ensure that the error probability is at most  $1/n^2$ .

Our next claim follows from (1) in Theorem 2.1 and from the runtime bounds for the k-median problem.

CLAIM 3.3. Let  $\mathfrak{c} \in \Lambda$  and suppose that  $\operatorname{COST}(\mathfrak{c}) \leq r \cdot f$  for some  $r \geq 2$ . Then, one can find a  $(1 + \varepsilon)$ -approximation for the facility location problem for  $\mathfrak{c}$  in time

$$\mathcal{O}(n_{\mathfrak{c}} \log n \log_{1+\varepsilon} r) + 2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)} (r \log n)^{\mathcal{O}(1)}$$
;

the algorithm is randomized and it errs with probability at most  $1/n^2$ .

*Proof.* Let us observe that our assumption about COST(c) ensures that there is always an optimal solution to the facility location problem for c that uses at most r facilities.

Our algorithm reduces the facility location problem to a sequence of k-median problems. Let  $\mathfrak D$  be the set of all integers of the form  $\lfloor (1+\varepsilon)^i \rfloor$  or  $\lceil (1+\varepsilon)^i \rceil$ , for  $i=0,1,\ldots,\lceil \log_{1+\varepsilon}r \rceil$ . (Notice that  $|\mathfrak D|=\mathcal O(\log_{1+\varepsilon}r)$ .)

We first find  $(1+\varepsilon)$ -approximations for the k-median problem for the values  $k\in\mathfrak{D}$ . For every  $k\in\mathfrak{D}$ , let  $Q_k$  be the set of k medians for the obtained approximation for the k-median problem; its cost is equal to  $\sum_{p\in P\cap\mathfrak{c}}d(p,Q_k)$ . Notice that if  $\mathrm{med}_k(\mathfrak{c})$  is the optimal cost of the k-median for  $\mathfrak{c}$ , that is,  $\mathrm{med}_k(\mathfrak{c})=\min_{X_k\subseteq\mathbb{R}^2:|X_k|=k}\sum_{p\in P\cap\mathfrak{c}}d(p,X_k)$ , then

$$\sum_{p \in P \cap \mathfrak{c}} d(p, Q_k) \le (1 + \varepsilon) \cdot \operatorname{med}_k(\mathfrak{c}) .$$

We compute

$$k^* = \arg\min_{k \in \mathfrak{D}} \{ \sum_{p \in P \cap \mathfrak{c}} d(p, Q_k) + k \cdot f \}$$

and return  $Q_{k^*}$  as a  $(1+\varepsilon)$ -approximation for the facility location problem for  $\mathfrak{c}$ .

Let us first show that if for every  $k \in \mathfrak{D}$ ,  $Q_k$  is a  $(1+\varepsilon)$ -approximation for the k-median problem for  $\mathfrak{c}$ , then the obtained solution  $Q_{k^*}$  is a  $(1+\varepsilon)$ -approximation for the facility location problem for  $\mathfrak{c}$ . Let  $F_{\mathsf{OPT}_P}(\mathfrak{c})$  be an optimal set of facilities for the cell  $\mathfrak{c}$ , that is,

$$\mathrm{COST}(\mathfrak{c}) = \sum_{p \in P \cap \mathfrak{c}} d(p, F_{\mathrm{OPT}_P}(\mathfrak{c})) + k_{\mathfrak{c}} \cdot f \ ,$$

with  $k_{\mathfrak{c}} = |F_{\mathsf{OPT}_P}(\mathfrak{c})|$ .

Observe that  $\operatorname{med}_{k_{\mathfrak{c}}}(\mathfrak{c}) = \sum_{p \in P \cap \mathfrak{c}} d(p, F_{\mathsf{OPT}_P}(\mathfrak{c}))$ . Let  $k^+$  be the smallest integer in  $\mathfrak D$  that is greater than or equal to  $k_{\mathfrak{c}}$ . We claim that

$$\sum_{p \in P \cap \mathfrak{c}} d(p,Q_{k^+}) + k^+ \cdot f \leq (1+\varepsilon) \cdot \mathrm{COST}(\mathfrak{c}) \enspace,$$

what would yield the claim.

Let us first observe that since the solutions to the k-median problem are non-increasing with k, we have  $\operatorname{med}_{k_r}(\mathfrak{c}) \geq \operatorname{med}_{k^+}(\mathfrak{c})$ , and hence

$$\sum_{p \in P \cap \mathfrak{c}} d(p,Q_{k^+}) \leq (1+\varepsilon) \sum_{p \in P \cap \mathfrak{c}} d(p,F_{\mathrm{OPT}_P}(\mathfrak{c})) \ .$$

Next, we note that our construction of  $\mathfrak D$  implies that  $k^+ \leq (1+\varepsilon)k_{\mathfrak c}$ . Therefore, if we combine these two claims, then we obtain:

$$\begin{split} & \sum_{p \in P \cap \mathfrak{c}} d(p, Q_{k^+}) + k^+ \cdot f \\ & \leq & (1 + \varepsilon) \sum_{p \in P \cap \mathfrak{c}} d(p, F_{\mathsf{OPT}_P}(\mathfrak{c})) + (1 + \varepsilon) \cdot k_{\mathfrak{c}} \cdot f \\ & = & (1 + \varepsilon) \cdot \mathsf{COST}(\mathfrak{c}) \enspace . \end{split}$$

Since by our choice of  $k^*$ :

$$\sum_{p \in P \cap c} d(p, Q_{k^*}) + k^* \cdot f \le \sum_{p \in P \cap c} d(p, Q_{k^+}) + k^+ \cdot f ,$$

this implies that  $Q_{k^*}$  is a  $(1 + \varepsilon)$ -approximation for the facility location problem for  $\mathfrak{c}$ .

Now, we analyze the running time of our algorithm. We run  $|\mathfrak{D}|$  times a  $(1+\varepsilon)$ -approximation algorithm for the k-median problem for an instance with  $n_{\mathfrak{c}}$  points,  $n_{\mathfrak{c}} = |P \cap \mathfrak{c}|$ . Har-Peled and Mazumdar [11] show how this problem can be solved in time  $\mathcal{O}(n_{\mathfrak{c}} + 2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)}k^{\mathcal{O}(1)}\log^{\mathcal{O}(1)}n_{\mathfrak{c}})$ . However, to achieve the required error probability at most  $1/n^2$ , we will repeat the algorithm by Har-Peled and Mazumdar [11]  $\mathcal{O}(\log n)$  number of times, and we will choose the best solution. Since in our case  $k \leq r$ , the total running time of the algorithm is bounded by

$$\mathcal{O}((n_{\mathfrak{c}} + 2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)}(r\log n)^{\mathcal{O}(1)}) \cdot \log n) \times |\mathfrak{D}|$$

as required.

With Claims 3.1–3.3 at hand, we are ready to prove our main theorem.

THEOREM 3.1. Algorithm PTAS(P) with probability at least  $\frac{2}{3}$  finds a  $(1 + \mathcal{O}(\varepsilon))$ -approximation for the facility location of P in time  $\mathcal{O}(n \cdot \log n \cdot \log \Delta \cdot \log \log n + n \cdot \log n \cdot (\log \log(n\Delta))^8 \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)})$ .

*Proof.* Theorem 2.1 and Claim 3.1 ensure that in time  $\mathcal{O}(n \log \Delta \log n \log \log n)$  one can find a partition  $\Lambda$  such that with probability at least  $\frac{3}{4}$ ,  $\Lambda$  satisfies properties (1) and (2) of Theorem 2.1.

Next, we consider the time needed to find feasible solutions for the facility location problem for all cells  $\mathfrak{c} \in \Lambda$ , whose cost is (with probability at least  $1-\frac{1}{n}$ ) upper bounded by  $(1+\varepsilon)\cdot \mathsf{COST}(\mathfrak{c})$  for all  $\mathfrak{c} \in \Lambda$ . We will use two alternative ways of doing this, using either Claim 3.2 or 3.3, depending on the size of  $P \cap \mathfrak{c}$ .

Let c be a positive constant such that the running time of the algorithm in Claim 3.3 is

$$\mathcal{O}(n_{\mathfrak{c}} \cdot \log n \cdot \log_{1+\varepsilon} r) + 2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)} (r \log n)^c$$
.

Let  $\zeta = 2^{\mathcal{O}((1+\log(1/\varepsilon))/\varepsilon)} \cdot (r\log n)^c$ . We define  $\Lambda_S$  to be the subset of cells  $\mathfrak{c} \in \Lambda$  with  $n_{\mathfrak{c}} \leq \zeta$  and  $\Lambda_L$  as the subset of cells  $\mathfrak{c} \in \Lambda$  with  $n_{\mathfrak{c}} > \zeta$  (notice that  $\Lambda_L = \Lambda \setminus \Lambda_S$ ).

For each cell  $\mathfrak{c} \in \Lambda_S$ , we will find  $(1+\varepsilon)$ -approximate solutions for the facility location problem using Claim 3.2, and for the cells  $\mathfrak{c} \in \Lambda_L$ , we will find  $(1+\varepsilon)$ -approximate solutions for the facility location problem using Claim 3.3. Since we perform at most n calls to the randomized algorithms in Claims 3.2 and 3.3, the probability that we will find  $(1+\varepsilon)$ -approximate solutions for the facility location

problem for *all* cells in  $\Lambda$  is at least 1-1/n. Therefore, by Theorem 2.1, the total cost of the union of the solutions to these facility location problems is (with probability at least  $\frac{3}{4} - \frac{1}{n}$ ) bounded by:

$$\begin{split} \sum_{\mathfrak{c} \in \mathbf{\Lambda}} (1+\varepsilon) \cdot \mathsf{COST}(\mathfrak{c}) & \leq & (1+\varepsilon)^2 \cdot \mathsf{OPT}_P \\ & \leq & (1+\mathcal{O}(\varepsilon)) \cdot \mathsf{OPT}_P \end{split}$$

Now, we must analyze the running time needed to approximate the cost of facility location for all cells in  $\Lambda$ . The running time of approximating the cost of facility location for the cells in  $\Lambda_S$  is by Claim 3.2 upper bounded by the following:

$$\sum_{\mathbf{c} \in \mathbf{\Lambda}_{S}} \mathcal{O}(n_{\mathbf{c}} \cdot \log^{8} n_{\mathbf{c}} \cdot \log n) \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}$$

$$\leq \sum_{\mathbf{c} \in \mathbf{\Lambda}_{S}} \mathcal{O}(n_{\mathbf{c}} \cdot \log^{8} \zeta \cdot \log n) \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}$$

$$\leq \mathcal{O}(n \cdot \log^{8} \zeta \cdot \log n) \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}.$$
(3.4)

The running time of approximating the cost of facility location for the cells in  $\Lambda_L$  is by Claim 3.3 upper bounded by

$$\sum_{\mathfrak{c}\in \mathbf{A}_{I}} \mathcal{O}(n_{\mathfrak{c}} \cdot \log n \cdot \log_{1+\varepsilon} r + \zeta) ,$$

with  $r = \mathcal{O}((\log \Delta)/\varepsilon)^2)$ .

Then, the definition of  $\Lambda_L$  implies that  $|\Lambda_L| \leq n/\zeta$  and hence, the running time is upper bounded by the following:

$$\sum_{\mathfrak{c} \in \mathbf{\Lambda}_{L}} \mathcal{O}\left(n_{\mathfrak{c}} \cdot \log n \cdot \log_{1+\varepsilon} r + \zeta\right)$$

$$= \mathcal{O}(n \cdot \log n \cdot \log_{1+\varepsilon} (\log \Delta/\varepsilon)) + \mathcal{O}(|\mathbf{\Lambda}_{L}| \cdot \zeta)$$

$$= \mathcal{O}(n \cdot \log n \cdot \log_{1+\varepsilon} (\log \Delta/\varepsilon)) .$$

Therefore, inequalities (3.4) and (3.5) imply that the running time of approximating the cost of facility location for all cells in  $\Lambda$  using Claims 3.2 and 3.3 is upper bounded by  $\mathcal{O}(n \cdot \log^8 \zeta \cdot \log n) \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)} + \mathcal{O}(n \cdot \log n \cdot \log_{1+\varepsilon}(\log \Delta/\varepsilon))$ , which is asymptotically equal to

$$\mathcal{O}(n \cdot \log n \cdot (\log \log(n\Delta))^8) \cdot 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}$$

what completes the proof.

REMARK 3.1. Theorem 3.1 has been presented in the framework convenient for our streaming algorithms and for some natural applications. However, one can extend Theorem 3.1 to the problem of facility location on the plane, where the input point set P and the set of facilities are allowed to be at any location in  $\mathbb{R}^2$  (not just in the grid  $[\Delta]^2$ ); see, e.g., [3, Section 3.2.3] and [17, Section 2], for more details of the reduction.

THEOREM 3.2. For any  $\varepsilon > 0$ , there is an algorithm that for any set of n points P in  $\mathbb{R}^2$  with probability at least  $\frac{2}{3}$  finds a  $(1 + \varepsilon)$ -approximation for the facility location of P in time

$$\mathcal{O}(n \log n (\log n \log \log n + (\log \log n)^8 2^{\mathcal{O}(\log(1/\varepsilon)/\varepsilon)}))$$
.

# 4 Fast constant-factor approximation algorithm for facility location

Our PTAS in Section 3 requires a fast constant-factor approximation algorithm for the uniform facility location problem. In this section we present such a fast  $(\mathcal{O}(n \log n \log \log n)$ -time) constant-factor approximation algorithm. The algorithm is a simple modification of an algorithm by Mettu and Plaxton [21] and its extensions in [4, 6].

Let  $P \subseteq \mathbb{R}^2$  be a set of n points in the plane. In this section, we will assume, without loss of generality, that the input is scaled such that f = 1. Hence, we have

$$\mathrm{COST}(P,F) = |F| + \sum_{p \in P} \min_{q \in F} d(p,q) \ .$$

The algorithm requires the following definitions of the  $(\ell_{\infty}\text{-})$  radius of a point. Let Q(q,m) be the square centered at q with side length 2m (i.e., Q(q,m) is the  $\ell_{\infty}$ -ball with radius m). Given  $q \in P$ , the radius of q, denoted by R(q), is the smallest value m such that

$$\sum_{p \in P \cap Q(q,m)} \min \bigcup_{i=1,2} \{|p^{(i)} - q^{(i)}| + m\} = f \ ,$$

where  $p^{(i)}$  and  $q^{(i)}$  refer to the i-th coordinate of p and q, respectively. In other words, the radius of q is the value R(q) such that the sum of distances of the points inside the square Q(q,m) to the boundary of Q(q,m) equals the opening cost f.

The discrete radius of  $q \in P$ , denoted by r(q), is the smallest value  $m=2^i, i \in \mathbb{Z}$ , such that there are at least 1/m points inside Q(q,m). The definition of radius is an adaptation of a similar definition in [21]. It had been extended to  $\ell_{\infty}$ -balls in [6]. The definition of discrete radius is similar to a definition in [4].

We first prove that the discrete radius approximates the radius of a point up to a constant factor. (A similar lemma for balls in metric spaces is in [4]. Our lemma is a simple adaption to our setting.)

LEMMA 4.1. Let  $q \in P$  be an arbitrary point. Then, we have

$$\frac{1}{2} \cdot R(q) \quad \leq \ r(q) \ < \quad 2 \cdot R(q) \ .$$

*Proof.* The first inequality follows from the fact that, inside a square of radius 2r(q), we have at least 1/r(q) points whose distance to the border is at least r(q). Hence,  $R(q) \leq 2r(q)$ .

By the definition of the discrete radius, we know that there are less than 2/r(q) points inside the square with center q and radius r(q)/2. Each of the points has a distance of at most r(q)/2 to the boundary of the square. Hence, R(q) > r(q)/2, which proves the second inequality.  $\square$ 

Thus, the discrete radius is a 4-approximation of the radius of a point.

Next, we can state the algorithm.

#### FACILITYLOCATION(P)

- For each point  $q \in P$  do
  - Compute the discrete radius r(q) of q
- Sort the discrete radii in non-decreasing order
- For each point q in this order do
  - If there is no open facility within distance at most 8r(q) then  $F=F\cup q$
- Return F

In the rest of this section, we first show that Algorithm FACILITYLOCATION(P) computes a  $\mathcal{O}(1)$ -approximation and then we address how it can be implemented in  $\mathcal{O}(n \log n \log \log n)$  time.

We observe that, for any  $q_1,q_2\in F$ , we have that the squares  $Q(q_1,4r(q_1))$  and  $Q(q_2,4r(q_2))$  are disjoint. This together with Lemma 4.1 implies that the squares  $Q(q_1,R(q_1))$  and  $Q(q_2,R(q_2))$  are disjoint for any  $q_1,q_2\in F$ .

We will show that, for any solution F computed by our algorithm,

$$\mathrm{COST}(P,F) = |F| + \sum_{p \in P} \min_{q \in F} d(p,q) \leq 17 \sum_{p \in P} R(p) \enspace .$$

Then, we will prove that the cost of an optimal solution is more than  $\sum_{p \in P} R(p)/16$ . This proves that the algorithm is a constant-approximation algorithm. Both proofs are similar to earlier proofs in [4] and based on the work in [21].

LEMMA 4.2. Let F be a set of facilities computed by Algorithm FACILITYLOCATION on input P. Then, we have

$$\mathit{COST}(P,F) \leq 17 \sum_{p \in P} R(p)$$
 .

*Proof.* A simple consequence of our algorithm is that any point  $p \in P$  has a distance of at most 8r(p) to the nearest open facility. Furthermore, by Lemma 4.1, we know that

$$r(P) < 2R(p)$$
.

Hence, any point  $p \in P$  has connection cost at most 16 R(p). To proceed, we need the following claim.

CLAIM 4.1. *Let* F *be a set of facilities computed by algorithm* FACILITYLOCATION*. Then, for any* q ∈ F*, we have*

$$\sum_{p \in P \cap Q(q, R(q))} R(p) \ge 1.$$

*Proof.* Let p ∈ P be an arbitrary point inside Q(q, R(q)), and let ` be its distance to the boundary of Q(q, R(q)). Then, the square Q(p, `) is completely contained in Q(q, R(q)). This implies that, for any point r ∈ P ∩Q(p, `), the distance to the boundary of Q(p, `) is at most as large as the distance to the boundary of Q(q, R(q)). This implies that R(p) ≥ `. This together with the definition of R(q) implies the claim.

We have already observed that, for any q1, q<sup>2</sup> ∈ F, the squares Q(q1, R(q1)) and Q(q2, R(q2)) are disjoint. Now, the above claim implies that |F| ≤ P <sup>p</sup>∈<sup>P</sup> R(p). Hence, the lemma follows. ut

Our next step is to prove that the cost of an optimal solution FOPT<sup>P</sup> is Ω(P <sup>p</sup>∈<sup>P</sup> R(p)).

LEMMA 4.3. *Let* F*OPT*<sup>P</sup> *be an optimal solution. Then, we have*

$$\mathit{COST}(P, F_{\mathit{OPT}_P}) > \sum_{p \in P} R(p)/16 \ .$$

*Proof.* We divide P into two subsets P<sup>A</sup> and PB. The subset P<sup>A</sup> contains all points p whose distance to FOPT<sup>P</sup> is at least r(p)/8. The subset P<sup>B</sup> contains the remaining points. For a facility q ∈ FOPT<sup>P</sup> , let PB(q) be the subset of points in P<sup>B</sup> for which q is the closest facility in FOPT<sup>P</sup> , breaking ties arbitrarily. The subset PB(q) contains point that are rather close to q with respect to their radius. This implies that for two point p, t ∈ PB(q) the squares must have a big intersection, which will be exploited for the following claim.

CLAIM 4.2. *Let* q ∈ F*OPT*<sup>P</sup> *be an arbitrary facility, and let* p, t ∈ PB(q)*. Then we have*

$$d(p,t) < r(p)/2$$
.

*Proof.* Let p, t be arbitrary points from PB(q). By the triangle inequality, we have d(p, t) ≤ d(p, q) + d(q, t). From the definition of PB(q) and p ∈ PB(q), we know that d(q, p) < r(p)/8. Thus, the claim follows if we can prove that d(q, t) ≤ 3r(p)/8.

Assume, for the purpose of contradiction, that d(q, t) > 3r(p)/8. Since t ∈ PB(q) we know that d(q, t) < r(t)/8. This, together with the previous inequality, implies r(t) > 3r(p). Since r(t) is a power of 2, we know that r(t) ≥ 4r(p) and so r(t)/4 ≥ r(p). Due to triangle inequality and the above arguments, we obtain

$$d(t,p) + r(p) \le d(t,q) + d(q,p) + r(p) < r(t)/2$$
.

Hence, the square Q(t, r(t)/2) contains the square Q(p, r(p)). This is a contradiction, because then the radius of t would be at most r(t)/2. ut

Let t be the point in PB(q) with biggest discrete radius, i.e., r(p) ≤ r(t) for any p ∈ PB(q). By the definition of the discrete radius, we know that

$$|Q(t,r(t)/2)| < 2/r(t)$$
.

Furthermore, due to Claim 4.2, all the points in PB(q) are contained in Q(t, r(t)/2). This implies that

$$\begin{array}{ll} 2 & > & |Q(t,r(t)/2)| \cdot r(t) \\ & \geq & \displaystyle \sum_{p \in P_B(q)} r(t) \\ & \geq & \displaystyle \sum_{p \in P_B(q)} r(p) \\ & \geq & \displaystyle \sum_{p \in P_B(q)} \frac{R(p)}{2} \ , \end{array}$$

where the last inequality follows from Lemma 4.1. Hence, we get,

$$|F_{\mathsf{OPT}_P}| \quad > \quad \sum_{q \in F_{\mathsf{OPT}_P}} \sum_{p \in P_B(q)} \frac{R(p)}{4} \ .$$

Since

ut

$$\sum_{p \in P_A} \min_{q \in F_{\mathsf{OPT}_P}} d(p,q) \ \geq \ \sum_{p \in P_A} \frac{R(p)}{16} \ ,$$

we obtain the following inequality,

$$\begin{split} \operatorname{COST}(P, F_{\operatorname{OPT}_P}) &= |F_{\operatorname{OPT}_P}| + \sum_{p \in P} \min_{q \in F_{\operatorname{OPT}_P}} d(p, q) \\ &> \sum_{p \in P_B} \frac{R(p)}{4} + \sum_{p \in P_A} \frac{R(p)}{16} \\ &\geq \sum_{p \in P} \frac{R(p)}{16} \ , \end{split}$$

which completes the proof of Lemma 4.3. ut

We conclude by Lemmas 4.1, 4.2, and 4.3 that Algorithm FACILITYLOCATION yields a constant approximation.

It remains to discuss how to implement the algorithm. For this purpose, we build a layered range tree the input point set P. Such a range tree can be build in O(n log n) time and can be used to answer orthogonal range counting queries in O(log n) time.

Now, observe that, for any p ∈ P, we have

$$1/2^{\lfloor \log n \rfloor} \le r(p) \le 1 .$$

Thus, there are only O(log n) possible values for r(p). We can use the range tree to compute the number of points inside a square of radius 1/2 i centered at p and use this to determine the radius of point p. We further observe that we can use binary search to speed up this process using only O(log log n) queries to the range tree.

Hence, computing the discrete radii of all the points in P requires O(n log n log log n) time. Afterwards, we sort the radii in non-decreasing order in O(n log n) time.

Next, we partition P into subsets P0, . . . , Pblog <sup>n</sup>c, where P<sup>i</sup> is the set of points whose radius is 1/2 i . For each Pi , we construct a dynamic 2D range tree, which supports queries in O(log n+k) time, where k is the number of points, and insertions and deletions in O(log n) time.

Then, we start with a point q ∈ P with smallest radius. We insert q into our set of facilities F and use the range trees to identify all points p with r(p) ≥ r(q) that contain q inside Q(p, 8r(p)). This can be done as follows. For each i with 1/2 <sup>i</sup> ≥ r(q) we use a range reporting query in the range tree for P<sup>i</sup> for the square with radius 8/2 i centered at q in the i-th range tree. By symmetry, this square contains all points p with r(p) = 1/2 <sup>i</sup> ≥ r(q) that contain q inside Q(p, 8r(p)). We delete these points from their corresponding range tree. Since each point is deleted at most once from a range tree, the time required for the deletions is O(n log n). It remains to analyze the time for the range reporting queries. Each range reporting query takes O(log n+k) time, where k is the number of reported points. However, the k can be charged to the deletions since every reported point will be deleted. Thus, in the following we may assume that each query takes O(log n) time.

Note that, for each facility q in P<sup>i</sup> that we put into F, at least all the points in Q(q, r(q)) will be deleted. Since, for any q <sup>0</sup> ∈ F\{q} the squares Q(q, r(q)) and Q(q 0 , r(q 0 )) do not overlap and the number of points in Q(q, r(q)) is at least 2 i , there are at most n/2 i facilities in F ∩ P<sup>i</sup> .

Thus, the overall running time is

$$\mathcal{O}(n \log n) + \sum_{i=0}^{\lfloor \log n \rfloor} \frac{n}{2^i} (i+1) \cdot \mathcal{O}(\log n) = \mathcal{O}(n \log n)$$
.

Hence, the total running time of the algorithm is O(n log n log log n).

Therefore, we can conclude the discussion in this section with the following theorem.

THEOREM 4.1. *Given a set* P ⊆ R <sup>2</sup> *of* n *points in plane, Algorithm* FACILITYLOCATION *computes a constant-factor approximation of the uniform facility location problem for* P *in* O(n log n log log n) *time.*

# 5 A streaming algorithm

In this section, we derive a (1 + ε)-approximation algorithm in the dynamic geometric streaming setting, where the items of the stream are insertions and deletions of points from [∆]<sup>2</sup> = {1, . . . , ∆} 2 , and where 1 > ε > 0 is an arbitrary fixed real. We will assume ∆ ≥ 4.

Let us fix a constant failure probability bound %, 0 < % < 1. Let ℵ <sup>∗</sup> be the minimal value for ℵ for which Partition Theorem 2.1 holds with the failure probability %/3; note that

$$\aleph^* = \Theta\left(\left(\frac{\log \Delta + 2}{\varepsilon}\right)^2\right)$$
.

Let κ = 2 · ℵ<sup>∗</sup> · f (and thus, Partition Theorem 2.1 will hold with the probability at least 1 − %/3 for any choice of the threshold defining heavy and light cells that is greater than or equal to κ/2, assuming the algorithm A used is an exact algorithm (and hence with α = 1)).

Our streaming algorithm will use the partitioning scheme as presented in Section 2, and in particular, Partition Theorem 2.1. For reasons that will become clear later, to distinguish between light and heavy cells we define a *random threshold* T as T = κ·rand, where rand is chosen uniformly at random from the interval [1, 2]. We use the threshold T to distinguish between *heavy* and *light* cells in the randomly shifted nested grid partition G0, G1, . . . , Glog ∆+1 (cf. Section 3). Any cell c with COST(c) > T will be called *heavy* and any cell with COST(c) ≤ T will be called *light*. <sup>4</sup> A light cell whose parent cell is heavy will be called a *maximal light* cell. (In our analysis, we will frequently use the fact that independently of the random choice of rand, if COST(c) ≤ κ/2 then c is light, and if COST(c) > 2κ then c is heavy.)

5.1 Focusing on δ-detectable cells. For a parameter δ, a maximal light cell c with parent cell c ∗ is called δ*-detectable* if

$$COST(\mathfrak{c}) \leq (1 - \delta)T$$
 and  $(1 + \delta)T \leq COST(\mathfrak{c}^*)$ .

Our first lemma proves that for sufficiently small δ, with constant probability the vast majority of the maximal light cells are δ-detectable and as the result, we can "ignore" the cost of maximal light cells that are not δ-detectable.

LEMMA 5.1. *Let* T *be chosen as stated above and let* % *be an arbitrary positive constant. If* δ = c · ε/ log ∆*, for an appropriate constant* c = c(%)*, then with probability at least* 1 − % *the following inequalities hold:*

$$\sum_{i=0}^{\log \Delta+1} \sum_{\delta ext{-detectable cell } \mathfrak{c}\in G_i} ext{cost}(\mathfrak{c}) \ \leq (1+arepsilon) \cdot ext{OPT}$$

<sup>4</sup>Let us notice that the definitions of heavy and light cells in this section are a small modification of the definitions from Section 3. The difference is twofold: firstly, the definition in Section 3 explicitly uses an approximation algorithm A, whereas here we have an exact bound for the cost of a cell; secondly, we use a slightly different threshold value. We notice however that our choice of κ ensures that κ = Θ(ℵ · f), and hence, it allows us to warrant that the Partition Theorem 2.1 is satisfied.

*and*

$$(1-\varepsilon) \cdot \mathit{OPT} \leq \sum_{i=0}^{\log \Delta + 1} \sum_{\delta \text{-detectable cell } \mathfrak{c} \in G_i} \mathit{COST}(\mathfrak{c}) \ .$$

*Proof.* The first bound (the upper bound) follows from the Partition Theorem 2.1 (where will set the failure probability to be equal to %/3) that ensures that with probability at least 1 − %/3 we have

$$\sum_{\text{maximal light cells } \mathfrak{c} \in \bigcup_i G_i} \mathrm{COST}(\mathfrak{c}) \leq (1+\varepsilon) \cdot \mathrm{OPT} \ \ .$$

Hence, with probability at least 1 − %/3 the following holds:

$$\begin{split} \sum_{i=0}^{\log \Delta+1} \sum_{\delta\text{-detectable cell } \mathfrak{c} \in G_i} \mathrm{COST}(\mathfrak{c}) \\ \leq \sum_{\text{maximal light cells } \mathfrak{c} \in \bigcup_{i=0}^{\log \Delta+1} G_i} \mathrm{COST}(\mathfrak{c}) \\ \leq (1+\varepsilon) \cdot \mathrm{OPT} \enspace . \end{split}$$

Now we proceed to the second inequality (the lower bound). We begin with basic definitions.

• We define Q to be the set of cells c in G0, . . . , Glog ∆+1 that would be maximal light if the threshold was chosen as κ/2. That is, a cell c is in Q if and only if

$$\mathtt{COST}(\mathfrak{c}) \leq \kappa/2 \ \mathrm{and} \ \mathtt{COST}(\mathfrak{c}^*) > \kappa/2 \ \ ,$$

where c ∗ is the parent cell of c.

• Let MQ be the set of all cells c in G0, . . . , Glog ∆+1 with COST(c) ≤ 2κ such that either c ∈ Q or c is an ancestor of a cell in Q.

We observe that only the cells in MQ can be maximal light (when the threshold T = κ · rand is chosen, as above). Indeed, firstly, any cell c that is maximal light with the threshold T must be light, and hence satisfy COST(c) ≤ T ≤ 2κ, and secondly, any such cell c is either in Q, or is an ancestor of a cell in Q.

Next, we have the following claim.

CLAIM 5.1. *With probability at least* 1 − %/3 *we have that*

$$\sum_{{\mathfrak c}\in MQ} {\it cost}({\mathfrak c}) = {\mathcal O}(\log \Delta) \cdot {\it opt}$$
 .

*Proof.* Let BQ be the set of cells from MQ \ Q that do not have a descendant in MQ \ Q. Observe that every cell c in BQ has κ/2 < COST(c) ≤ 2κ, and since no descendant of c has cost greater than κ/2, we conclude that all four children of c are in Q.

Therefore, since the cost of any cell is upper bounded by the sum of the costs of its children, we have

$$\sum_{\mathfrak{c} \in BQ} \mathrm{COST}(\mathfrak{c}) \leq \sum_{\mathfrak{c} \in Q} \mathrm{COST}(\mathfrak{c}) \ .$$

Next, we observe that every cell c in MQ \ Q is either in BQ or has a descendant in BQ. Also, every cell has at most log ∆ + 1 ancestors and every cell c ∈ MQ \ Q has κ/2 < COST(c) ≤ 2κ. Thus, we can conclude that

$$\begin{split} \sum_{\mathfrak{c} \in MQ \backslash Q} \mathsf{COST}(\mathfrak{c}) & \leq & \sum_{\mathfrak{c} \in BQ} (\log \Delta + 1) \cdot (4 \cdot \mathsf{COST}(\mathfrak{c})) \\ & \leq & 4 \cdot (\log \Delta + 1) \cdot \sum_{\mathfrak{c} \in Q} \mathsf{COST}(\mathfrak{c}) \ . \end{split}$$

Hence,

$$\begin{split} \sum_{\mathfrak{c} \in MQ} \mathsf{cost}(\mathfrak{c}) &= \sum_{\mathfrak{c} \in MQ \backslash Q} \mathsf{cost}(\mathfrak{c}) + \sum_{\mathfrak{c} \in Q} \mathsf{cost}(\mathfrak{c}) \\ &\leq \left( 4 \cdot (\log \Delta + 1) + 1 \right) \cdot \sum_{\mathfrak{c} \in Q} \mathsf{cost}(\mathfrak{c}) \enspace . \end{split}$$

Now, to conclude the proof of Claim 5.1, we observe that by taking maximal light cells for the threshold T = κ/2, Theorem 2.1 ensures that with probability at least 1−%/3 we get

$$\sum_{\mathfrak{c} \in Q} \mathrm{COST}(\mathfrak{c}) \leq (1+\varepsilon) \cdot \mathrm{OPT}$$
 .  $\qed$ 

We will use Claim 5.1 to conclude the proof of the lower bound in Lemma 5.1. Let us first assume that P <sup>c</sup>∈MQ COST(c) = O(log ∆·OPT), what by Claim 5.1 holds with probability at least 1 − %/3. As observed above, every maximal light cell c that is not δ-detectable must be in MQ. Notice that the definition of the set MQ has been done independently of the choice of rand in the definition of the threshold T, but the choice of rand is essential for being δdetectable.

By definition, if a cell c with parent cell c ∗ is not δdetectable, then we must have (1 − δ)T < COST(c) or COST(c ∗ ) < (1 + δ)T, and hence

$$\min\{|T - \mathsf{COST}(\mathfrak{c})|, |T - \mathsf{COST}(\mathfrak{c}^*)|\} \le \delta T .$$

Next, we characterize the values |T − COST(c)| and |T − COST(c ∗ )| with respect to the random choice of rand that defines T = κ·rand. Since we choose rand uniformly at random from [1, 2], the probability that |T − COST(c)| ≤ δT is at most 2δ, and so is the probability that |T − COST(c ∗ )| ≤ δT. Thus, in expectation at most an (4δ)-fraction of cells in MQ are not δ-detectable. Hence, by Markov's inequality and by our assumption that

$$\sum_{\mathfrak{c} \in MQ} \mathsf{COST}(\mathfrak{c}) = \mathcal{O}(\log \Delta \cdot \mathsf{OPT})$$
 ,

there is a constant c > 0 such that for every t > 0,

$$\begin{split} \mathbf{Pr} \big[ \sum_{\text{not } \delta\text{-detectable cell } \mathfrak{c} \in MQ} \mathrm{COST}(\mathfrak{c}) \geq t \big] & \leq & \frac{4\delta \sum_{\mathfrak{c} \in MQ} \mathrm{COST}(\mathfrak{c})}{t} \\ & \leq & \frac{c \cdot \delta \cdot \log \Delta \cdot \mathrm{OPT}}{t} \ . \end{split}$$

Hence, for a given  $\varrho>0$ , if we set  $\delta=\frac{\varepsilon\varrho}{3c\log\Delta}$ , then (by taking  $t=\varepsilon\cdot$  OPT in the bound above) we obtain that with probability at least  $1-\varrho/3$  it holds:

$$\sum_{\text{ not } \delta\text{-detectable cell } \mathfrak{c} \in MQ} \text{COST}(\mathfrak{c}) \quad \leq \quad \varepsilon \cdot \text{OPT } \ .$$

This implies that conditioned on the bound in Claim 5.1 that  $\sum_{\mathfrak{c}\in MQ} \mathsf{COST}(\mathfrak{c}) = \mathcal{O}(\log \Delta \cdot \mathsf{OPT})$ , we have with probability at least  $1-\varrho/3$  the following bound:

$$\begin{split} & \sum_{\delta \text{-detectable cell } \mathfrak{c} \in \bigcup_{i=0}^{\log \Delta + 1} G_i} \operatorname{COST}(\mathfrak{c}) \\ & \geq & \operatorname{OPT} - \sum_{\text{not } \delta \text{-detectable cell } \mathfrak{c} \in MQ} \operatorname{COST}(\mathfrak{c}) \\ & \geq & (1-\varepsilon) \cdot \operatorname{OPT} \enspace, \end{split}$$

where the first inequality follows from the fact that

$$\sum_{\mathfrak{c} \text{ is maximal light}} \mathsf{COST}(\mathfrak{c}) \geq \mathsf{OPT}$$

for every choice of T.

Now, we can conclude the analysis of the lower bound by combing this bound with Claim 5.1, to ensure that

$$\sum_{\mathfrak{c} \text{ is } \delta\text{-detectable cell}} \mathrm{COST}(\mathfrak{c}) \geq (1-\varepsilon) \cdot \mathrm{OPT}$$

with probability at least  $1 - \frac{2}{3}\varrho$ .

In summary, we have shown that

$$\sum_{\mathfrak{c} \text{ is } \delta\text{-detectable cell}} \mathrm{cost}(\mathfrak{c}) \leq (1+\varepsilon) \cdot \mathrm{OPT}$$

with probability at least  $1 - \varrho/3$ , and that

$$\sum_{\mathfrak{c} \text{ is } \delta\text{-detectable cell}} \mathrm{COST}(\mathfrak{c}) \geq (1-\varepsilon) \cdot \mathrm{OPT}$$

with probability at least  $1 - \frac{2}{3}\varrho$ . Thus, with probability at least  $1 - \varrho$ , it holds that

$$(1-\varepsilon) \cdot \mathsf{OPT} \leq \sum_{i=0}^{\log \Delta + 1} \sum_{\substack{\delta \text{-detectable cell } \mathfrak{c} \in G}} \mathsf{COST}(\mathfrak{c})$$

and

$$\sum_{i=0}^{\log \Delta + 1} \sum_{\delta \text{-detectable cell } \mathfrak{c} \in G_i} \mathrm{cost}(\mathfrak{c}) \ \leq (1+\varepsilon) \cdot \mathrm{OPT} \ ,$$

what completes the proof.

5.2 Sampling algorithm in streaming setting. In this section, we will implement a variant of the following sampling algorithm in the streaming setting. The algorithm receives a point set P and a sample size s as input, and it uses an  $\alpha$ -approximation algorithm Apx for optimal cost of facility location of P with  $\alpha = \mathcal{O}(1)$ . Although the algorithm below does not explicitly compute the partition of the input space as defined in the previous sections, it makes implicit use of it by only accepting  $\delta$ -detectable cells ( $\delta$ -detectable cells are a subset of  $\Lambda$ ).

Furthermore, for the analysis of the streaming algorithm we will also need a second variant of the algorithm that accepts every maximal light cell, i.e., every cell of  $\Lambda$ .

# FL-SAMPLING (P, s)

- For i = 0 to  $\log \Delta + 1$  do
  - Sample each cell from grid  $G_i$  with probability  $\frac{s}{\mathrm{Apx}}$  and let  $\mathfrak{S}_i$  be the resulting set
  - Let  $F_i = 0$
  - For each  $\delta$ -detectable (variant 2: maximal light) cell  $\mathfrak{c} \in \mathfrak{S}_{\mathfrak{i}}$  do
    - \* Determine a  $(1+\varepsilon)$ -approximation C of the facility location cost of  $P\cap \mathfrak{c}$
    - \* Let  $F_i = F_i + C$
- Return  $F = \frac{\mathrm{Apx}}{s} \cdot \sum_{i=0}^{\log \Delta + 1} F_i$

Before we start to explain the necessary modifications to implement this algorithm in the streaming model, we will analyze the quality of the sampling of FL-SAMPLING (P, s).

LEMMA 5.2. Let  $1 > \varrho > 0$  be a constant. Let  $0 < \varepsilon < 1$  and let  $c = c(\varrho)$  be an appropriate constant as guaranteed to exist by Lemma 5.1. If  $s \geq \frac{2\kappa \cdot \alpha}{\varrho \varepsilon^2} = O(\log^2 \Delta/(\varrho \varepsilon^4))$ ,  $\delta = c\varepsilon/\log \Delta$ , and if the sampling is done pairwise independently within grid  $G_i$  and fully independently for different grids, then with probability at least  $1 - \varrho$  the estimate returned by algorithm FL-SAMPLING (P, s) satisfies

$$|F - \mathsf{OPT}_P| \leq O(\varepsilon) \cdot \mathsf{OPT}_P$$
.

This holds for both variants of the algorithm.

*Proof.* By our choice of  $\delta$  with probability at least  $1-\varrho/2$  the partition satisfies Lemma 5.1. We will use Chebyshev's inequality. We enumerate the  $\delta$ -detectable cells from grid  $G_i$ . Let  $\mathfrak{c}_j$  be the j-th such cell in the enumeration. Let  $X_j$  be the indicator random variable for the event that  $\mathfrak{c}_j$  is sampled and let  $Y_j = X_j \cdot \mathsf{COST}(\mathfrak{c}_j)$ . Since every  $\delta$ -detectable cell is light, we observe that  $Y_j \leq 2\kappa$ . We can write

$$F_i = \frac{\mathrm{Apx}}{s} \sum_j Y_j \ ,$$

and

$$\mathbf{E}[F_i] = \sum_{\delta \text{-detectable cell } \mathfrak{c} \in G_i} \mathrm{COST}(\mathfrak{c}) \enspace ,$$

and

$$\mathbf{E}[F] = \mathbf{E}[\sum_{i=0}^{\log \Delta + 1} F_i] .$$

By Lemma 5.1 (or, for the second variant, by Theorem 2.1 and the fact that the maximal light cells form a partition of the input space) we also have

$$(5.6) (1 - \varepsilon) \cdot \mathsf{OPT}_P \le \mathbf{E}[F] \le (1 + \varepsilon) \cdot \mathsf{OPT}_P$$

with probability at least 1 − %/2. Furthermore, by pairwise independence of the Y<sup>j</sup>

$$\begin{aligned} \mathbf{Var}[F_i] & \leq & \mathbf{E}[F_i^2] \\ & = & \frac{\mathrm{Apx}^2}{s^2} \cdot \sum_j \mathbf{E}[Y_j^2] \\ & = & \frac{\mathrm{Apx}^2}{s^2} \cdot \sum_j \mathbf{E}[\mathsf{cost}(\mathfrak{c}_j)^2 \cdot X_j^2] \\ & = & \frac{\mathrm{Apx}^2}{s^2} \cdot \sum_j \mathbf{E}[\mathsf{cost}(\mathfrak{c}_j)^2 \cdot X_j] \\ & \leq & \frac{\mathrm{Apx}^2}{s^2} \cdot (2 \cdot \kappa) \cdot \sum_j \mathbf{E}[\mathsf{cost}(\mathfrak{c}_j) \cdot X_j] \\ & = & \frac{2 \cdot \mathrm{Apx}^2 \cdot \kappa}{s^2} \cdot \sum_j \left( \mathsf{cost}(\mathfrak{c}_j) \cdot \mathbf{E}[X_j] \right) \\ & = & \frac{2 \cdot \mathrm{Apx} \cdot \kappa}{s} \cdot \mathbf{E}[F_i] \end{aligned}$$

and by independence of sampling in different grids

$$\begin{split} \mathbf{Var}[F] &= \sum_{i=0}^{\log \Delta + 1} \mathbf{Var}[F_i] \\ &\leq \frac{2 \cdot \mathrm{Apx} \cdot \boldsymbol{\kappa}}{s} \cdot \sum_{i=0}^{\log \Delta + 1} \mathbf{E}[F_i] \\ &= \frac{2 \cdot \mathrm{Apx} \cdot \boldsymbol{\kappa}}{s} \cdot \mathbf{E}[F] \\ &\leq \frac{2 \cdot (\alpha \cdot \mathrm{OPT}_P) \cdot \boldsymbol{\kappa}}{s} \cdot (1 + \varepsilon) \cdot \mathrm{OPT}_P \\ &= \frac{2 \cdot (1 + \varepsilon) \cdot \alpha \cdot \mathrm{OPT}_P^2 \cdot \boldsymbol{\kappa}}{s} \;, \end{split}$$

where we use (5.6) in the last inequality. By Chebyshev's inequality and (5.6) we get,

$$\begin{split} &\mathbf{Pr}[|F - \mathsf{OPT}_P| > \varepsilon \cdot \mathsf{OPT}_P] \\ & \leq & \quad \mathbf{Pr}[|F - \mathbf{E}[F]| > 2 \cdot \varepsilon \cdot \mathsf{OPT}_P] \\ & \leq & \quad \frac{2 \cdot (1 + \varepsilon) \cdot \alpha \cdot \mathsf{OPT}_P^2 \cdot \kappa}{4 \cdot \varepsilon^2 \cdot s \cdot \mathsf{OPT}_P^2} \\ & \leq & \quad \varrho/2 \end{split}$$

for our choice of s. Hence, the lemma follows by the union bound. ut

In the streaming setting we will not be able to exactly determine whether a cell is δ-detectable or whether it is maximal light. However, we can make sure that we accept all δ-detectable cells and do not accept any cell that is not maximal light. The following corollary says that this is sufficient for the purpose of approximation.

COROLLARY 5.1. *If instead of accepting* δ*-detectable cells or maximal light cells, algorithm* FL-SAMPLING *accepts a set of cells which contains all* δ*-detectable cells and which is a subset of maximal light cells, then, under the same premise as in Lemma 5.2, with probability at least* 1 − 2% *the estimator returned by* FL-SAMPLING *satisfies*

$$|F - \mathsf{OPT}_P| \leq O(arepsilon) \cdot \mathsf{OPT}_P$$
 .

*Proof.* We have shown that the algorithm FL-SAMPLING computes a (1 + O(ε))-approximation if it accepts all maximal light cells and it computes one if the algorithm only accepts all δ-detectable cells. Let us call all maximal light sample cells L and all δ-detectable sample cells D; let the output value of the algorithm accepting all maximal light cells be F<sup>L</sup> and the output value of the algorithm accepting only all δdetectable cells be FD. If the algorithm accepts an arbitrary set of cells A with D ⊆ A ⊆ L, then it outputs a value F<sup>A</sup> with F<sup>D</sup> ≤ F<sup>A</sup> ≤ FL. The result follows by the union bound since (1 − O(ε))OPT<sup>P</sup> ≤ F<sup>D</sup> and F<sup>L</sup> ≤ (1 + O(ε))OPT<sup>P</sup> . ut

We now discuss the necessary modifications required to implement algorithm FL-SAMPLING in the streaming setting. We will only prove that the algorithm succeeds with probability at least 2/3. In order to improve this probability to 1 − %, one can use standard amplification techniques, i.e., run O(log 1/%) independent instances of the algorithm and return the median of the computed values. We will prove the following main theorem.

THEOREM 5.1. *Algorithm* FL-SAMPLING *can be implemented in the setting of dynamic geometric data streams. This streaming algorithm uses*(log ∆ log(1/%)/ε) <sup>O</sup>(1) *space and update time and returns in* (log ∆ log(1/%)/ε) O(1) · 2 O(log ∆ log(log ∆/ε)/ε) *time an estimator* F *that with probability at least* 1 − % *satisfies*

$$(1-\varepsilon)\cdot \mathsf{OPT}_P \leq F \leq (1+\varepsilon)\cdot \mathsf{OPT}_P$$
.

Since we do not know the value of Apx in advance, we will use one instance for any guess of cost 2 i · f, 0 ≤ i ≤ 2 log ∆. This requires O(log ∆) such instances, each of which will succeed with probability greater than or equal to 5/6. We will also maintain an instance of the O(1) approximation algorithm for the cost of the facility location problem by Lammersen and Sohler [18] with success probability at least 5/6. Using the result of this algorithm, we can decide afterwards, which instance of our main algorithm we will use. The probability that the O(1)-approximation algorithm returns a correct result and that this particular instance runs correctly is at least 2/3. Thus, in the following we may assume that we know Apx and we need to prove that there is an algorithm with success probability at least 5/6.

5.2.1 Sampling in dynamic data streams. Our next change is that we determine  $\mathfrak{S}_i$  to be the set of cells that are mapped to 1 by a pairwise independent hash function  $h_i$  with range  $1, \ldots, r = \lceil \mathrm{Apx}/s \rceil$ . Now that we have defined the set  $\mathfrak{S}_i$  implicitly, a critical point is that  $\mathfrak{S}_i$  can be very large and so we cannot store all points that are mapped to a cell in  $\mathfrak{S}_i$ .

This may be overcome by observing that in expectation  $\mathfrak{S}_i$  contains only a few maximal light cells, and so also only a few  $\delta$ -detectable cells. Indeed, since the parent of a maximal light cell in grid  $G_i$  is a heavy cell in grid  $G_{i+1}$ , the number of maximal light cells in grid  $G_i$  is bounded by four times the number of heavy cells in grid  $G_{i+1}$ . Now, we observe that the number of heavy cells in grid  $G_{i+1}$  is upper bounded by

$$\mathcal{O}(\mathsf{OPT}_P/T) = \mathcal{O}(\mathrm{Apx}/T)$$
 ,

where T is the random threshold chosen in our algorithm to define heavy cells. Hence, the expected number of maximal light cells in  $\mathfrak{S}_i$  is  $\mathcal{O}(s/T)$ .

In the following, it will be helpful to first assume that all cells are either  $\delta$ -detectable or empty. In the whole section we will assume  $\delta = c\varepsilon/\log \Delta$ , where  $c = c(\varrho) = c(1/200)$ is the constant from Lemma 5.2. We have seen that  $\mathfrak{S}_i$  in expectation contains only very few  $\delta$ -detectable cells. If we use a second pairwise independent hash function  $h'_i$  to map these cells to a random value in  $\{1, \ldots, t\}$  for sufficiently large  $t = \Omega(s^2/T^2)$ , then with high probability there will be no collision among them. Our two stage hashing scheme now induces substreams of the input stream. First of all, in grid  $G_i$  we will only consider points inside cells that map to 1 under  $h_i$  (subsampling stage). Then the second stage subdivides our subsampled stream into t substreams, each of which under our assumption will contain all points of at most one  $\delta$ -detectable cell. We may assume, without loss of generality, that our streams consist only of insertion since all operations we will use are linear and so an insertion followed by a deletion cancel out.

We will now explain how to drop our simplifying assumptions. If more than one cell is mapped to the same bucket, we will treat all points inside these cells as if they come from a single cell. We show that the points that are mapped there from cells other that our  $\delta$ -detectable cell only insignificantly changes the facility location of this cell. For this purpose we proceed as follows. Whenever a point inside

a cell  $\mathfrak c$  in  $\mathfrak S_i$  is encountered in the stream, we subtract the coordinates of the lower left corner of its cell to obtain a new point (vector) p' and then we pass this point to a substream  $h'_i(\mathfrak c)$ . For sufficiently large t each substream will contain points from at most one maximal light cell and some "noise points" mapped from other cells to it, which will be sufficiently small to approximate the cost of the maximal light cell with factor, say,  $(1+\delta/100)$ .

The scheme described above is a modification of an algorithm introduced by [1]. The idea to use random shifts in this context is from [14]. See also [15].

It remains to explain how to detect whether a substream contains a  $\delta$ -detectable cell. To do that, we determine the points inside the parent cell of each sample cell in  $\mathfrak{S}_i$  and we hash them to different substreams to ensure that with high probability no stream contains more than one heavy cell. We summarize the above discussion in the following algorithm.

# STREAMINGSAMPLECELL (i)

- Let  $r = \lceil \text{Apx}/s \rceil$  and  $t = c^* \left( \frac{s^4 \cdot \log^2 \Delta}{T^4 \cdot s^2} + \frac{s \log^2 \Delta}{sT} \right)$ .
- Choose two pairwise independent hash functions  $h_i: \{1, \ldots, |G_i|\} \to \{1, \ldots, r\}$  and  $h_i': \{1, \ldots, |G_i|\} \to \{1, \ldots, t\}.$
- For each point p in the stream do
  - $\diamond$  Determine cells  $\mathfrak{c}_1 \in G_i$  and  $\mathfrak{c}_2 \in G_{i+1}$  that contain p
  - $\diamond$  Let  $p = p c_1$ , where  $c_1$  is the lower left corner of  $\mathfrak{c}_1$
  - $\diamond$  Let  $p' = p c_2$ , where  $c_2$  is the lower left corner of  $\mathfrak{c}_2$
  - $\diamond$  If  $h_i(\mathfrak{c}_1) = 1$  then
    - \* Insert p into  $(\lceil T/f \rceil, \delta/100)$ -Coreset MED<sub>i,h';(c<sub>1</sub>)</sub>
  - $\diamond$  For each subcell  $\mathfrak{c}$  of  $\mathfrak{c}_2$  with  $h_i(\mathfrak{c}) = 1$  do
    - $\star$  Insert p' into  $(\lceil T/f \rceil, \delta/100)$ -Coreset MED<sub>i,h'</sub><sub>i,c</sub>(c)

We run algorithm STREAMINGSAMPLECELL(i) for each value of i in  $\{0,1,\ldots,\log\Delta+1\}$  to obtain estimates for all  $F_i$ . In algorithm STREAMINGSAMPLECELL we use the  $(k,\delta)$ -coreset data structures of [8] for the k-median problem maintained in the streaming fashion. Let P be a (possibly weighted) point set in  $[\Delta]^2$  in which  $w_p$  is the weight of a point  $p\in P$ . In the k-median problem we would like to find a set  $C\subseteq \mathbb{R}^2$  of k centers such that

$$\mathrm{COST}(P,C) = \sum_{p \in P} \min_{c \in C} w_p \cdot d(p,c)$$

is minimized. Then a coreset is defined as follows.

DEFINITION 5.1. ([11]) A weighted set  $S \subseteq \mathbb{R}^2$  is called a  $(k, \delta)$ -coreset for P if for any set  $C \subseteq \mathbb{R}^2$  with  $|C| \leq k$  we have

$$|cost(S,C) - cost(P,C)| \le \delta \cdot cost(P,C)$$
.

Observe that a  $(k, \delta)$ -coreset is also a  $(k', \delta)$ -coreset for any k' < k. In our paper we will use the  $(k, \delta)$ -coreset data structure from [8], whose properties are described in the following theorem.

Theorem 5.2. ([8]) Let  $P \subseteq [\Delta]^2$  be a point set given in the dynamic geometric data stream model. Let  $k \ge 1$ ,  $\delta > 0$ , and  $0 < \varrho < 1$ . There exists a randomized streaming algorithm that with probability  $1 - \varrho$  maintains  $a(k, \delta)$ -coreset of P using a space of  $(k \log \Delta \log(1/\varrho)/\delta)^{O(1)}$ . This streaming algorithm processes Insert(p) and Delete(p) operations in  $(k \log \Delta \log(1/\varrho)/\delta)^{O(1)}$  time.

For each  $i \in \{0,1,\ldots,\log\Delta+1\}$  and using  $\varrho=1/(200\log\Delta)$ , we maintain a  $(\lceil T/f\rceil,\delta/100)$ -coreset  $\mathrm{MED}_{i,j}^{\mathrm{light}}$  for each substream of the points mapped to j and another  $(\lceil T/f\rceil,\delta/100)$ -coreset  $\mathrm{MED}_{i,j}^{\mathrm{heavy}}$  to maintain the points mapped to the parent cell of a cell mapped to j. Thus, the coreset data structures are simultaneously correct with probability at least 99/100.

**5.3 Extraction algorithm and analysis.** We will now state the main properties of the maintained statistics. We will use  ${\tt COST}({\tt MED}^{{\tt light}}_{i,j})$  and  ${\tt COST}({\tt MED}^{{\tt heavy}}_{i,j})$  to refer to the cost of an optimal facility location solution of the coreset returned by the data structure.

LEMMA 5.3. Let  $\mathcal{C} = \{\mathfrak{c} \in \mathfrak{S}_i : \mathfrak{c} \text{ is } \delta\text{-detectable }\}$  and let  $\mathcal{L} = \{\mathfrak{c} \in \mathfrak{S}_i : \mathfrak{c} \text{ is maximal light}\}$ . If  $t \geq c^*(\frac{s^4 \cdot \log^2 \Delta}{T^4 \cdot \varepsilon^2} + \frac{s \cdot \log^2 \Delta}{\varepsilon T})$  for sufficiently large  $c^*$ , then with probability at least  $1/(200 \log \Delta)$  the following statements simultaneously hold:

- For every cells  $\mathfrak{c}_1, \mathfrak{c}_2 \in \mathcal{L}$  we have  $h_i'(\mathfrak{c}_1) \neq h_i'(\mathfrak{c}_2)$ .
- If  $\operatorname{COST}(\operatorname{MED}_{i,j}^{\operatorname{light}}) \leq (1 \delta/2) \cdot T$  and  $\operatorname{COST}(\operatorname{MED}_{i,j}^{\operatorname{heavy}}) \geq (1 + \delta/2) \cdot T$  then there is a cell  $\mathfrak{c} \in \mathcal{L}$  with  $h_i'(\mathfrak{c}) = j$ .
- $\begin{array}{l} \bullet \ \textit{For every cell} \ \mathfrak{c} \in \mathcal{L} \ \textit{we have} \ (1-\delta/100) \cdot \textit{COST}(\mathfrak{c}) \leq \\ \textit{COST}(\text{Med}_{i,j}^{\textit{light}}) \leq (1+\delta/100) \cdot \textit{COST}(\mathfrak{c}) + \frac{\delta}{50} \cdot T. \end{array}$
- For every parent cell  $\mathbf{c}'$  of a cell  $\mathbf{c} \in \mathcal{L} (1 \delta/100) \cdot \cos \tau(\mathbf{c}') \leq \cos \tau(\mathrm{Med}_{i,j}^{heavy}) \leq (1 + \delta/100) \cdot \cos \tau(\mathbf{c}') + \frac{\delta}{50} \cdot T$ .

Before we prove Lemma 5.3, we will show how to extract an approximation for the cost of the facility location problem from our statistics.

We will need the following procedure to approximate the cost of the facility location problem, if there is a promise that the cost is not too large. We compute  $(1+\delta/100)$ -approximation of the cost of the k-median problem from the coresets using the algorithm by Har-Peled and Mazumdar

[11] and add the term kf to obtain the corresponding facility location cost for each choice of  $k \in \{1, \dots, \lceil T/f \rceil\}$ . To obtain the cost of the facility location problem we finally choose the cost which is minimum of all facility location costs for all values of  $k \in \{1, \dots, \lceil T/f \rceil\}$ . This gives a  $(1+\delta/100)$ -approximation for the facility location cost.

Our next step will be to define the extraction algorithm. Given Lemma 5.3, the algorithm will check for entries in the hash tables such that the cost of  $\mathrm{MED}^{\mathrm{light}}_{i,j}$  is at most  $(1 - \delta/2)T$  and the cost of the corresponding MED<sub>i,j</sub> is at least  $(1 + \delta/2)T$ . Given the first and second item of Lemma 5.3, we know that every value extracted corresponds to a unique maximal light cell. Furthermore, by the third and fourth item in Lemma 5.3 and the fact that we compute a  $(1 + \delta/100)$ -approximation, we know that for every  $\delta$ detectable cell  $\mathfrak{c}$  with  $h_i(\mathfrak{c}) = 1$  we extract a value into  $F_i$ . Thus, our sample set satisfies the requirements of Corollary 5.1. The multiplicative and additive error in the costs of the cells is  $O(\varepsilon \cdot \mathsf{OPT}_P)$  with probability at least 99/100. Furthermore, with probability at least 99/100 Lemma 5.3 is true for all values of i. Then Corollary 5.1 is satisfied with probability at least  $1 - 2\varrho$ , where we use  $\varrho = 1/200$ . Hence, the corollary is satisfied with probability at least 99/100. The maintained coreset data structures work correctly with probability at least 99/100. Thus, by the union bound, the algorithm succeeds with probability at least 5/6 as required.

# STREAMINGREPORT (i)

- Let  $F_i = 0$
- For j = 1 to t do
  - $\diamond$  Let  $F_l$  be a  $(1 + \delta/100)$ -approximation for MED $_{i,j}^{\text{light}}$
  - $\diamond$  Let  $F_h$  be a  $(1+\delta/100)$ -approximation for MED $_{i,j}^{\mathrm{heavy}}$
- Return  $r \cdot F$

**5.4 Proof of Lemma 5.3.** We will prove our lemma in several steps. We start by defining  $COST^*(\mathfrak{c})$  of a cell  $\mathfrak{c}$  to be the cost of an optimal solution, where a single facility is opened in the middle of the cell for free (and where additional facilities may be opened at a cost of f=1). We call a cell big if it has  $COST^*(\mathfrak{c}) \geq \lambda T$ , for  $\lambda \leq \frac{\delta^2 T}{c' \cdot s \cdot \log \Delta}$  for an appropriate constant c'. We call a cell  $\mathfrak{c}$  important if it is either maximal light or big. A cell that is not important will be called *unimportant*.

Our first step in order to prove the lemma will be to show that no important cells collide under  $h'_i$ . This implies the first item of Lemma 5.3. In order to do so, we first have to prove a bound on the number of important cells that are in  $\mathfrak{S}_i$ . To

get this bound, we show the following.

CLAIM 5.2.

$$\sum_{\mathfrak{c} \in G_i ; \mathfrak{c} \ big} \mathit{cost}^*(\mathfrak{c}) = \mathcal{O}(\mathit{OPT}_P)$$
 .

*Proof.* For each big cell c, we open all facilities that are opened in an optimal solution in c and all of its neighboring cells. Furthermore, we open the free facility in the center of each big cell. The connection cost for every point will be at most that of an optimal solution. The cost for opening the facilities that are opened in an optimal solution is at most 9 times the opening cost of the optimal solution. Hence the claim follows.

The following corollary is immediate.

COROLLARY 5.2. The number of big cells in grid  $G_i$  is  $\mathcal{O}(\frac{OPT_P}{\lambda T})$ .

We also observe that the parent cell of every maximal light cell is heavy and so it is big. Since every such cell has at most four maximal light subcells, we obtain the following.

COROLLARY 5.3. The number of maximal light cells in grid  $G_i$  is  $\mathcal{O}(\frac{OPT_P}{\lambda T})$ .

This immediately implies the following claim.

COROLLARY 5.4. The number of important cells in grid  $G_i$  is  $\mathcal{O}(\frac{OPT_P}{\sqrt{T}})$ .

Now let us define  $\mathcal{I}$  to be the set important cells  $\mathfrak{c}$  in  $\mathfrak{S}_i$ .

CLAIM 5.3. There is a constant c such that

$$\Pr[|\mathcal{I}| \ge c \cdot \frac{s}{\lambda \log \Delta T}] \le \frac{1}{1000 \log \Delta}$$

*Proof.* We have  $\mathbf{E}[|\mathcal{I}|] = \mathcal{O}(\frac{\mathsf{OPT}_P}{\lambda T} \cdot \frac{s}{\mathsf{Apx}}) = \mathcal{O}(\frac{s}{\lambda T})$ . Then the claim follows from Markov's inequality.

Next we prove our first intermediate result which implies the first item of Lemma 5.3.

CLAIM 5.4. There is a constant c such that for  $t \ge \frac{cs^2}{\lambda^2 \log \Delta \cdot T^2}$  the following holds:

$$\mathbf{Pr}[\exists \mathfrak{c}_1,\mathfrak{c}_2 \in \mathcal{I} \text{ with } h_i'(\mathfrak{c}_1) = h_i'(\mathfrak{c}_2)] \leq rac{1}{500\log \Delta}$$
.

*Proof.* For a moment, let us assume that  $|\mathcal{I}| \leq c' \cdot \frac{s}{\lambda \log \Delta T}$  for some constant c' > 1. Then, by pairwise independence of  $h'_i$ , the probability that two fixed cells collide is 1/t. Taking the union bound over all pairs gives that with probability at most  $\frac{1}{t} \cdot \left(\frac{c's}{\lambda \log \Delta T}\right)^2$  there is a collision of maximal light cells. For  $t \geq \frac{cs^2}{\lambda^2 \log \Delta \cdot T^2}$  and  $c \geq 1000(c')^2$ , this probability is at most  $1/(1000\log \Delta)$ . Due to Claim 5.3, with probability at least  $1 - 1/(1000\log \Delta)$ , we have  $|\mathcal{I}| \leq c' \cdot \frac{s}{\lambda \log \Delta T}$ , which completes the proof.

It remains to analyze how the "noise" introduced by unimportant cells influences our result. Let us use  $\mathcal{U}$  to denote the unimportant cells in  $\mathfrak{S}_i$ .

CLAIM 5.5. There exists a constant c > 1 such that

$$\Pr[\sum_{\mathfrak{c} \in \mathcal{U}} cost^*(\mathfrak{c}) \ge c \log \Delta s] \le \frac{1}{1000 \log \Delta}$$

*Proof.* Using the same arguments as in the proof of Claim 5.2 we can show that

$$\sum_{\mathfrak{c} \in G_i : \mathfrak{c} ext{ unimportant}} \mathsf{cost}^*(\mathfrak{c}) = \mathcal{O}(\mathsf{OPT}_P) \ .$$

Since each cell is in  $\mathfrak{S}_{\mathfrak{i}}$  with probability 1/r, we get  $\mathbf{E}[\sum_{\mathfrak{c}\in\mathcal{U}}\mathsf{COST}^*(\mathfrak{c})] = \mathcal{O}(s)$ . Now, the claim follows by Markov's inequality.

CLAIM 5.6. There exist constants c', c'' such that for  $\lambda \leq \frac{\delta^2 T}{c' \cdot s \cdot \log \Delta}$  and  $t \geq \frac{c'' \cdot s \log \Delta}{\delta T}$  with probability at least  $1 - \frac{1}{500 \log \Delta}$  simultaneously for every  $j \in \{1, \dots, t\}$ , it holds:

$$\sum_{\mathfrak{c} \in U: h_i'(\mathfrak{c}) = j} \mathit{cost}^*(\mathfrak{c}) \quad \leq \quad \delta \cdot T/100 \ .$$

*Proof.* We condition on the fact that Claim 5.5 is satisfied. We will use Chebyshev's inequality for fixed j and then use the union bound. For a cell  $\mathfrak{c}$  let

$$X_{\mathfrak{c},j} = \begin{cases} \operatorname{COST}^*(\mathfrak{c}) & \text{ if } h_i'(\mathfrak{c}) = j, \\ 0 & \text{ otherwise.} \end{cases}$$

We have  $\mathbf{Var}[X_{\mathfrak{c},j}] \leq \frac{1}{t}(\mathsf{COST}^*(\mathfrak{c}))^2$ . Let us define

$$X_j = \sum_{\mathfrak{c} \in \mathcal{U}} X_{\mathfrak{c},j} .$$

We have

$$\mathbf{E}[X_j] \le \frac{cs \log \Delta}{t} \le \delta T/200 ,$$

for our choice of t and for c'' being a sufficiently large constant and where c is the constant from the previous claim. By pairwise independence,

$$\begin{aligned} \mathbf{Var}[X_j] &= \sum_{\mathfrak{c} \in \mathcal{U}} \mathbf{Var}[X_{\mathfrak{c}}] \\ &\leq \frac{1}{t} \cdot \sum_{\mathfrak{c} \in \mathcal{U}} (\mathsf{COST}^*(\mathfrak{c}))^2 \\ &\leq \frac{1}{t} \cdot \lambda \cdot T \cdot \Big( \sum_{\mathfrak{c} \in \mathcal{U}} (\mathsf{COST}^*(\mathfrak{c})) \Big) \\ &\leq c \cdot \lambda \cdot T \cdot s \ . \end{aligned}$$

where c is the constant from the previous claim. By Chebyshev's inequality we have

$$\begin{split} \mathbf{Pr}[|X_j - \mathbf{E}[X_j]| &\geq \delta \cdot T/200] &\leq & \frac{40000 \cdot \mathbf{Var}[X_j]}{\delta^2 \cdot T^2} \\ &\leq & \frac{40000 \cdot \lambda \cdot c \cdot s}{\delta^2 \cdot T \cdot t} \;. \end{split}$$

Thus, for large enough c' and  $\lambda \leq \frac{\delta^2 T}{c' \cdot s \cdot \log \Delta}$ , we get with probability at least  $1 - \frac{1}{1000 \log \Delta}$  for all j with  $1 \leq j \leq t$  that  $|X_j - \mathbf{E}[X_j]| < \delta T/200$ . Since Claim 5.5 is satisfied with probability  $1 - \frac{1}{1000 \log \Delta}$ , the claim follows.  $\square$ 

It remains to argue why the above claim implies the remaining items of Lemma 5.3. We have proved that the sum of COST\* of the unimportant cells mapped to a fixed bucket j is at most  $\delta T/100$ . This implies that any bucket to which no big cells is mapped has a COST $(Med_{i,j}^{\text{light}}) \leq (1+\delta/100) \cdot (\delta T/100+1) \leq \delta T/50$  and COST $(Med_{i,j}^{\text{heavy}}) \leq \delta T/50$ . Furthermore, for every important cell  $\mathfrak{c} \in \mathfrak{S}_i$  we get  $(1-\delta/100) \cdot \text{COST}(\mathfrak{c}) \leq \text{COST}(Med_{i,h_i'(\mathfrak{c})}^{\text{light}})$  and COST $(Med_{i,h_i'(\mathfrak{c})}^{\text{light}}) \leq (1+\delta/100) \cdot (\text{COST}(\mathfrak{c})+\delta T/100+1) \leq (1+\delta/100) \cdot \text{COST}(\mathfrak{c})+\delta T/50$ . The same bound holds for big cells  $\mathfrak{c}$  from  $G_{i+1}$  and COST $(Med_{i,h_i'(\mathfrak{c})}^{\text{heavy}})$ . This proves items three and four.

In order to prove the second item, let us assume that there is a bucket j that satisfies the second statement. The bounds above imply that there is also a cell  $\mathfrak c$  with  $h_i(\mathfrak c)=1$  and whose parent cell is heavy. Furthermore,  $\mathfrak c$  cannot be heavy and so it is maximal light, which proves the second item. Hence the lemma follows for  $t \geq c^*(\frac{s^4 \cdot \log^2 \Delta}{T^4 \cdot \varepsilon^2} + \frac{s \log^2 \Delta}{\varepsilon^T})$  for sufficiently large  $c^*$ .

#### References

- [1] A. Andoni, K. DoBa, P. Indyk, and D. Woodruff. Efficient sketches for earth-mover distances with applications. In *Proceedings of the 50th IEEE Symposium on Foundations of Computer Science (FOCS)*, pages 324–330, 2009.
- [2] S. Arora. Polynomial time approximation schemes for Euclidean traveling salesman and other geometric problems. *Journal of the ACM*, 45(5):753–782, 1998.
- [3] S. Arora, P. Raghavan, and S. Rao. Approximation schemes for Euclidean k-medians and related problems. In Proceedings of the 30th Annual ACM Symposium on Theory of Computing (STOC), pages 106–113, 1998.
- [4] M. Bădoiu, A. Czumaj, P. Indyk, and C. Sohler. Facility location in sublinear time. In *Proceedings of the 32nd Annual International Colloquium on Automata, Languages and Programming (ICALP)*, pages 866–877, 2005.
- [5] K. Chen. On coresets for k-median and k-means clustering in metric and Euclidean spaces and their applications. SIAM Journal on Computing, 39(3):923–947, 2009.

- [6] B. Degener, J. Gehweiler, and C. Lammersen. Kinetic facility location. *Algorithmica*, 57(3):562–584, July 2010.
- [7] Z. Drezner and H. W. Hamacher, editors. *Facility Location: Applications and Theory*. Springer Verlag, 2004.
- [8] G. Frahling and C. Sohler. Coresets in dynamic geometric data streams. In *Proceedings of the 37th Annual ACM Symposium on Theory of Computing (STOC)*, pages 209–217, 2005.
- [9] R. L. Francis and P. B. Mirchandani, editors. *Discrete Location Theory*. John Wiley and Sons, Inc., New York, 1990.
- [10] S. Guha and S. Khuller. Approximation algorithms for connected dominating sets. Algorithmica, 20(4):374–387, 1998.
- [11] S. Har-Peled and S. Mazumdar. On coresets for *k*-means and *k*-median clustering. In *Proceedings of the 36th Annual ACM Symposium on Theory of Computing (STOC)*, pages 291–300, 2004.
- [12] D. S. Hochbaum. Heuristics for the fixed cost median problem. *Mathematical Programming*, 22(1):148–162, 1982.
- [13] P. Indyk. Algorithms for dynamic geometric problems over data streams. In *Proceedings of the 36th Annual ACM Symposium on Theory of Computing (STOC)*, pages 373–380, 2004.
- [14] P. Indyk and D. P. Woodruff. Optimal approximations of the frequency moments of data streams. In *Proceedings of* the 37th Annual ACM Symposium on Theory of Computing (STOC), pages 202–208, 2005.
- [15] T.S. Jayram and D.P. Woodruff. The data stream space complexity of cascaded norms. In *Proceedings of the 50th IEEE Symposium on Foundations of Computer Science (FOCS)*, pages 765–774, 2009.
- [16] S. G. Kolliopoulos and S. Rao. A nearly linear-time approximation scheme for the Euclidean k-median problem. In Proceedings of the 7th Annual European Symposium on Algorithms (ESA), pages 378–389, 1999.
- [17] S. G. Kolliopoulos and S. Rao. A nearly linear-time approximation scheme for the Euclidean *k*-median problem. *SIAM Journal on Computing*, 37(3):757–782, 2007.
- [18] C. Lammersen and C. Sohler. Facility location in dynamic geometric data streams. In *Proceedings of the 16th Annual European Symposium on Algorithms (ESA)*, pages 660–671, 2008.
- [19] S. Li. A 1.488 approximation algorithm for the uncapacitated facility location problem. In *Proceedings of the 38th Annual International Colloquium on Automata, Languages and Pro*gramming (ICALP), pages 77–88, 2011.
- [20] N. Megiddo and K. J. Supowit. On the complexity of some common geometric location problems. *SIAM Journal on Computing*, 13(1):182–196, 1984.
- [21] R. R. Mettu and C. G. Plaxton. The online median problem. *SIAM Journal on Computing*, 32(3):816–832, 2003.
- [22] D. B. Shmoys, É. Tardos, and K. Aardal. Approximation algorithms for facility location problems. In *Proceedings of the 29th Annual ACM Symposium on Theory of Computing (STOC)*, pages 265–274, 1997.