![](_page_0_Picture_0.jpeg)

# Performance of Johnson-Lindenstrauss Transform for k-Means and k-Medians Clustering

Konstantin Makarychev Northwestern University Evanston, IL, United States konstantin@northwestern.edu

Yury Makarychev\* TTIC Chicago, IL, United States yury@ttic.edu Ilya Razenshteyn Microsoft Research Redmond Redmond, WA, United States ilyaraz@microsoft.com

#### **ABSTRACT**

Consider an instance of Euclidean k-means or k-medians clustering. We show that the cost of the optimal solution is preserved up to a factor of  $(1+\varepsilon)$  under a projection onto a random  $O(\log(k/\varepsilon)/\varepsilon^2)$ -dimensional subspace. Further, the cost of every clustering is preserved within  $(1+\varepsilon)$ . More generally, our result applies to any dimension reduction map satisfying a mild sub-Gaussian-tail condition. Our bound on the dimension is nearly optimal. Additionally, our result applies to Euclidean k-clustering with the distances raised to the p-th power for any constant p.

For k-means, our result resolves an open problem posed by Cohen, Elder, Musco, Musco, and Persu (STOC 2015); for k-medians, it answers a question raised by Kannan.

#### **CCS CONCEPTS**

Theory of computation → Facility location and clustering;
 Unsupervised learning and clustering;
 Theory of computation → Random projections and metric embeddings.

### **KEYWORDS**

clustering, Johnson-Lindenstrauss transform, dimension reduction, k-means, k-medians. Kirszbraun theorem

#### **ACM Reference Format:**

Konstantin Makarychev, Yury Makarychev, and Ilya Razenshteyn. 2019. Performance of Johnson–Lindenstrauss Transform for k-Means and k-Medians Clustering. In Proceedings of the 51st Annual ACM SIGACT Symposium on the Theory of Computing (STOC '19), June 23–26, 2019, Phoenix, AZ, USA. ACM, New York, NY, USA, 12 pages. https://doi.org/10.1145/3313276.3316350

#### 1 INTRODUCTION

The Euclidean k-clustering problem with the  $\ell_p$ -objective is defined as follows. Given a dataset  $X \subset \mathbb{R}^m$  of n points, the goal is to find a partition  $C = \{C_1, C_2, \dots, C_k\}$  of X into k parts (clusters) that

Permission to make digital or hard copies of all or part of this work for personal or classroom use is granted without fee provided that copies are not made or distributed for profit or commercial advantage and that copies bear this notice and the full citation on the first page. Copyrights for components of this work owned by others than ACM must be honored. Abstracting with credit is permitted. To copy otherwise, or republish, to post on servers or to redistribute to lists, requires prior specific permission and/or a fee. Request permissions from permissions@acm.org.

STOC '19, June 23–26, 2019, Phoenix, AZ, USA
© 2019 Association for Computing Machinery.
ACM ISBN 978-1-4503-6705-9/19/06...\$15.00
https://doi.org/10.1145/3313276.3316350

minimizes the following cost function:

$$\operatorname{cost}_p C = \sum_{i=1}^k \min_{u_i \in \mathbb{R}^m} \sum_{x \in C_i} \|x - u_i\|^p,$$

where  $\|\cdot\|$  from now on denotes the Euclidean ( $\ell_2$ ) norm, and the optimal points  $u_i$  are called *centers* of clusters  $C_i$ . This problem is a generalization of the k-median (p=1) and the k-means (p=2) clustering. Algorithms for k-clustering (especially the Lloyd's heuristic [Llo82] for k-means) are used in virtually every area of data science (see [Jai10] for a survey), for data compression, quantization, and transmission over noisy channels [Far90], and for hashing, sketching and similarity search [JDS11]. In this paper we study data-oblivious *dimension reduction* for k-clustering, which can be used to speed up clustering algorithms. This line of work has been initiated by Boutsidis, Zouzias, and Drineas [BZD10] and prior to this work, the best bounds were due to Cohen, Elder, Musco, Musco and Persu [CEM+15]. Before stating our results, let us briefly recall the notion of Euclidean dimension reduction (see [Nao18] for a broad overview of the area).

Dimension reduction. The cornerstone dimension reduction statement for the Euclidean distance is the Johnson–Lindenstrauss Lemma [JL84]. For positive reals  $p,q,\varepsilon$ , we write  $p\approx_{1+\varepsilon}q$  if  $\frac{1}{1+\varepsilon}\cdot p\leq q\leq (1+\varepsilon)\cdot p$ .

<span id="page-0-0"></span>Theorem 1.1 ([JL84]). There exists a family of random linear maps  $\pi_{m,d} \colon \mathbb{R}^m \to \mathbb{R}^d$  with the following properties. For every  $m \geq 1$ ,  $\varepsilon, \delta \in (0; 1/2)$  and all  $x \in \mathbb{R}^m$ , we have

$$\Pr_{\pi \sim \pi_{m,d}} (\|\pi x\| \approx_{1+\varepsilon} \|x\|) \ge 1 - \delta,$$

where 
$$d = O\left(\frac{\log(1/\delta)}{\varepsilon^2}\right)$$
.

A straightforward corollary is that one is able to embed any n-point subset of a Euclidean space into an  $O\left(\frac{\log n}{\varepsilon^2}\right)$ -dimensional space, while preserving all of the pairwise distances up to  $(1+\varepsilon)$ . This bound is known to be tight [Alo03, LN17]. The attractive feature of the dimension reduction procedure given by Theorem 1.1 is that it is data-oblivious i.e., the distribution over linear maps is independent of the set of points we apply it to.

There are several constructions of families of random maps  $\pi_{m,d}$  that satisfy Theorem 1.1: projections on a random subspace [JL84, DG03] and maps given by matrices with i.i.d. Gaussian and sub-Gaussian entries [IM98, Ach03, KM $^+$ 05]. All of these constructions satisfy a certain additional condition, which we will need later.

<span id="page-0-1"></span>Definition 1.2. A family of random linear maps  $\pi_{m,d}: \mathbb{R}^m \to \mathbb{R}^d$  is called sub-Gaussian-tailed if for every unit vector  $x \in \mathbb{R}^m$  and

 $<sup>^{\</sup>star}\text{Supported}$  by NSF CCF-1718820 and NSF Career CCF-1150062.

every t > 0, one has:

$$\Pr_{\pi \sim \pi_{m,d}}(\|\pi x\| \ge 1 + t) \le e^{-\Omega(t^2 d)}.$$

Our result. Consider an instance of Euclidean k-clustering. We show that its cost is preserved up to a factor of  $(1+\varepsilon)$  under dimension-reduction projection into an  $O(\log(k/\varepsilon)/\varepsilon^2)$ -dimensional space. Further, the cost of every clustering is preserved within a factor of  $(1+\varepsilon)$ . Our result applies to dimension reductions based on orthogonal and Gaussian projections and, more generally, any dimension reductions satisfying the sub-Gaussian-tail condition (in the sense of Definition 1.2). Our bound on the dimension is nearly optimal.

For k-means, our result resolves an open problem posed by Cohen, Elder, Musco, Musco, and Persu [CEM<sup>+</sup>15]. For a partition  $C = (C_1, C_2, \ldots, C_k)$  of  $X \subset \mathbb{R}^m$  and a linear map  $\pi \colon \mathbb{R}^m \to \mathbb{R}^d$ , we denote by  $\pi(C)$  the respective partition of the image of X under  $\pi$ . We now state our main result formally.

<span id="page-1-0"></span>THEOREM 1.3. Consider any family of random maps  $\pi_{m,d} : \mathbb{R}^m \to \mathbb{R}^d$  that satisfies Theorem 1.1 and is sub-Gaussian-tailed (satisfies Definition 1.2). Then for every  $m \ge 1$ ,  $\varepsilon, \delta \in (0; 1/4)$  and  $p \ge 1$ , the following holds. For every finite  $X \subset \mathbb{R}^m$  we have

$$\Pr_{\pi \sim \pi_{m,d}} \left( \operatorname{cost}_p C \approx_{1+\varepsilon} \operatorname{cost}_p \pi(C) \text{ for all partitions } C \right) \geq 1 - \delta,$$

where

<span id="page-1-1"></span>
$$d = O\left(\frac{p^4 \cdot \log \frac{k}{\varepsilon \delta}}{\varepsilon^2}\right). \tag{1}$$

In fact, we show that Theorem 1.3 holds under a slightly more general definition of a *standard* dimension reduction map (Definition 2.1), which is implied by sub-Gaussian tails.

Theorem 1.3 readily implies that if one solves the k-clustering problem after dimension reduction with approximation  $\lambda \geq 1$ , then the same solution yields approximation  $(1+O(\varepsilon))\cdot\lambda$  for the original instance. It is almost immediate to show the guarantee given by Theorem 1.3 for a *fixed* partition C, however the total number of partitions is exponential, and we cannot afford to take the union bound over them. In fact, the actual proof of Theorem 1.3 is much more delicate.

For k-means (p=2), the dimension bound  $O(\log n/\varepsilon^2)$  easily follows from the Johnson–Lindenstrauss lemma (Theorem 1.1) and the fact that one can express the cost function of k-means via pairwise distances. However, in many applications of clustering,  $k \ll n$ , in which case the bound we obtain is much stronger. For  $p \neq 2$ , even the weaker  $O(\log n)$  bound was not known before.

There are a number of dimension reduction maps that essentially satisfy Theorem 1.1, but not quite, since they depend on  $\varepsilon$  and  $\delta$ , while the family in Theorem 1.1 is parameterized by m and d only: most notably, sparse constructions [DKS10, KN14] as well as "fast" constructions based on subsampled randomized Fourier transform [AC06, AL09, KW11, AL13, NPW14]. For such cases the conclusion of Theorem 1.3 holds under a certain condition on the moments (see Definition 2.1).

Finally, let us note that the bound (1) is essentially optimal in the following two ways. First, if we want to preserve the cost of all the k-clusterings of a dataset, then one needs at least  $\Omega(\log k/\varepsilon^2)$  dimensions for *any* (possibly non-linear) dimension reduction map.

<span id="page-1-2"></span>

| Reference             | Dimension d                            | Distortion        |
|-----------------------|----------------------------------------|-------------------|
| Folklore              | $O(\log n/\varepsilon^2)$              | $1 + \varepsilon$ |
| [BZD10]               | $O(k/\varepsilon^2)$                   | $2 + \varepsilon$ |
| [CEM <sup>+</sup> 15] | $O(k/\varepsilon^2)$                   | $1 + \varepsilon$ |
| [CEM <sup>+</sup> 15] | $O(\log k/\varepsilon^2)$              | 9 + ε             |
| This work             | $O(\log(k/\varepsilon)/\varepsilon^2)$ | 1 + ε             |

Figure 1: Data-oblivious dimension reduction for k-means

Indeed, if we consider a dataset consisting of k+1 points, then preserving the cost of all k-clusterings is equivalent to preserving all the pairwise distances. The desired lower bound then follows from the main result of [LN17]. Second, if we use a Gaussian matrix for dimension reduction, and only care about preserving the *optimal* clustering, we still need  $\Omega(\log k/\varepsilon^2)$  dimensions. Indeed, consider a set of t pairs of points such that the distance within each pair except one is 1, the distance within the remaining one pair is  $1-C\varepsilon$ , where C is a large enough constant, and the pairs are very far apart from each other. Suppose that k=2t-1. Then the only approximately optimal clustering consists of the "special" pair and the remaining points as singletons. But if we reduce dimension using a Gaussian matrix to much fewer than  $\log k/\varepsilon^2$  dimensions, it is likely that some other pair will become noticeably closer than the special pair. This changes the optimal clustering showing the desired lower bound.

Related work. There is a large body of literature on dimension reduction for k-means (which corresponds to p=2). Within this line of work, there are two kinds of results: data-oblivious and data-dependent. Data-oblivious results provide guarantees qualitatively similar to our Theorem 1.3 and are summarized in Figure 1. Let us now give a brief overview.

As mentioned previously, the bound on the dimension  $O(\log n/\varepsilon^2)$  is a simple application of Theorem 1.1. The first bound independent of n was obtained by Boutsidis, Zouzias and Drineas [BZD10], who showed that  $O(k/\varepsilon^2)$  dimensions are enough for distortion  $2 + \varepsilon$ . The best bounds prior to the present work are due to Cohen, Elder, Musco, Musco and Persu [CEM<sup>+</sup>15]. They showed two incomparable bounds:  $O(k/\varepsilon^2)$  dimensions with distortion  $1 + \varepsilon$ , and  $O(\log k/\varepsilon^2)$  dimensions with distortion  $9 + \varepsilon$ . The  $9 + \varepsilon$  bound on the distortion follows from all pairwise distance between k optimal centers being approximately preserved. Our Theorem 1.3 improves upon both of the bounds shown in [CEM<sup>+</sup>15]: we get  $O(\log(k/\varepsilon)/\varepsilon^2)$  dimensions with distortion  $1 + \varepsilon$ , thus resolving an open problem posed in [CEM<sup>+</sup>15].

The literature on data-dependent dimension reduction for k-means is ample [DFK<sup>+</sup>99, Sar06, BDM09, BZD10, FSS13, BMI13, BZMD15, CEM<sup>+</sup>15] and we refer the reader to [CEM<sup>+</sup>15] for a comprehensive overview. Let us note that none of these results obtain dimension better than k.

For  $p \neq 2$ , even the log n bound was not known previously. The question of obtaining the log n bound for p = 1 (k-median) was explicitly posed recently by Kannan [Kan18].

A notion related to dimension reduction is that of a *coreset*, which is a small subsample of a dataset that approximately preserves the

cost of k-clustering. A good overview of this rich line of work appears in [SW18].

Independently of our work, Becchetti, Bury, Cohen-Addad, Grandoni and Schwiegelshohn [BBCA+19] obtained a result for k-means under dimension reduction. Their result applies only to k-means (p=2); their bound on the target dimension  $O\left(\frac{\log k + \log\log n}{\varepsilon^6} \cdot \log \frac{1}{\varepsilon}\right)$  is somewhat weaker than ours and depends on n.

#### 1.1 Proof Overview

As we discussed earlier, it is easy to show that for any fixed clustering  $C = (C_1, \ldots, C_k)$ , we have  $\cot_p(\pi C) \approx_{1+\varepsilon} \cot_p(C)$  w.h.p. In particular, for the optimal clustering  $C^*$ ,  $\cot_p(\pi C^*) \approx_{1+\varepsilon} \cot_p(C^*)$ , and, consequently, the cost of the optimal clustering for  $\pi X$  is upper bounded by the cost of the optimal clustering for X up to a factor of  $(1+\varepsilon)$  w.h.p. However, it is not at all obvious how to obtain a lower bound on the cost of the optimal solution for  $\pi X$  since there may exist a clustering  $\pi C'$  of  $\pi X$  which is better than  $\pi C^*$ . Note that we cannot use the union bound to prove Theorem 1.3 as the number of possible clusterings of X is exponential in n, but the dimension d does not depend on n.

In this section, we discuss the main ideas we use in the proof of Theorem 1.3. We show that with high probability the following two statements hold (a) for all C we have  $\mathrm{cost}_p(C) \leq (1+\varepsilon)\,\mathrm{cost}_p(\pi C)$  and (b) for all C we have  $\mathrm{cost}_p(\pi C) \leq (1+\varepsilon)\,\mathrm{cost}_p(C)$ . The proofs of these statements are similar. To simplify the exposition, we focus on the former inequality in this proof overview.

To illustrate our approach, first consider an easy case when X is embedded into a  $d=O(\log n/\varepsilon^2)$  dimensional space. In this case, all distances between points in X are approximately preserved w.h.p. That is,  $\|x'-x''\|\approx_{1+\varepsilon}\|\pi x'-\pi x''\|$  for all  $x',x''\in X$ . We prove that if all distances in X are approximately preserved then for every clustering  $C=(C_1,\ldots,C_k)$  we have  $\cot_p(C)\approx_{1+\varepsilon}\cot_p(\pi C)$ . In fact, we prove a slightly stronger statement: for every cluster  $C\subset X$  we have  $\cot_p(C)\approx_{1+\varepsilon}\cot_p(\pi C)$ . As we shall see in a moment, the proof is immediate for k-means but requires some work for k-median and other  $\ell_p$  objectives.

For the k-means objective (p = 2), we can use the following well known formula:

<span id="page-2-0"></span>
$$\cos t_2(C) = \frac{1}{|C|} \sum_{(x', x'') \in C \times C} ||x' - x''||^2,$$
 (2)

and, similarly,

<span id="page-2-1"></span>
$$\cos t_2(\pi C) = \frac{1}{|C|} \sum_{(x', x'') \in C \times C} \|\pi x' - \pi x''\|^2.$$
 (3)

Since each term  $\|x' - x''\|^2$  in (2) approximately equals the corresponding term  $\|\pi x' - \pi x''\|^2$  in (3), we have  $\cos t_2(C) \approx_{1+O(\varepsilon)} \cos t_2(\pi C)$ .

**One-point robust extension.** The above proof does not generalize to  $\ell_p$  objectives with  $p \neq 2$ . So our proof relies on the Kirszbraun theorem [Kir34].

THEOREM 1.4 (KIRSZBRAUN THEOREM). For every subset  $X \subset \mathbb{R}^d$  and L-Lipschitz map<sup>1</sup>  $\varphi: X \to \mathbb{R}^m$ , there exists an L-Lipschitz extension  $\widetilde{\varphi}$  of  $\varphi$  from X to the entire space  $\mathbb{R}^d$ .

Let  $Y=\pi(C)$ . Observe that the map  $\pi:C\to\mathbb{R}^d$  and inverse map  $\pi^{-1}:Y\to\mathbb{R}^m$  are  $(1+\varepsilon)$ -Lipschitz with high probability. Let u be the optimal center for cluster  $\pi C$ . Using the Kirszbraun theorem, we extend the map  $\pi^{-1}:Y\to\mathbb{R}^m$  to  $\widetilde{\varphi}:\mathbb{R}^d\to\mathbb{R}^m$  and then lift the optimal center u from  $\mathbb{R}^d$  to  $\mathbb{R}^m$  by letting  $v=\widetilde{\varphi}(u)$ . Then, for all  $y\in Y$  we have  $\|v-\pi^{-1}y\|\leq (1+\varepsilon)\|u-y\|$  or, equivalently, for all  $x\in C$  we have  $\|v-x\|\leq (1+\varepsilon)\|u-\pi x\|$ . We pick point v as the center for the cluster C and obtain the following bound:

$$\begin{split} \mathrm{cost}_p(C) & \leq \sum_{x \in C} \|x - v\|^p \leq \sum_{x \in C} (1 + \varepsilon)^p \|\pi x - u\|^p \\ & = (1 + \varepsilon)^p \, \mathrm{cost}_p(\pi C). \end{split}$$

We now return to the case when  $d = c_p \log(k/(\delta \varepsilon))/\varepsilon^2$  (where  $c_p$  only depends on p). Observe that when we reduce the dimension of X to d, while most pairwise distances in X are approximately preserved, some are distorted. The Kirszbraun theorem does not hold in this setting. We prove a robust 1-point extension theorem (Theorem 5.2).

Loosely speaking, this theorem states the following. Consider a finite set  $C \subset \mathbb{R}^d$  and map  $\varphi : C \to \mathbb{R}^m$ , satisfying the following condition  $(\star)$ :

 for every x ∈ C, the distance from x to all but a θ fraction of x' ∈ C is (1 + ε)-preserved under φ.

Then, for every point  $u \in \mathbb{R}^d$ , there exists a point  $v \in \mathbb{R}^m$  such that for all but  $\theta'$  fraction of points  $x \in C$ , we have  $||x - u|| \le (1 + \varepsilon') ||\varphi(x) - v||$  where  $\varepsilon' = O(\varepsilon)$  and  $\theta' = O(\theta/\varepsilon)$ .

**Worst cluster for each projection** Consider a random dimension reduction map  $\pi : \mathbb{R}^m \to \mathbb{R}^d$ . We prove that for every cluster C,

$$cost_p C \le (1 + \varepsilon') cost_p \pi(C) + \varepsilon'' cost_p C^*,$$
(4)

where  $\cos t_p C^*$  is the cost of the optimal k-means clustering. Here,  $\varepsilon'$  and  $\varepsilon''$  are some parameters (see (7) for details). For each realization of  $\pi$ , let us pick a subset  $C \subset X$  for which the gap between  $\cot_p(C)$  and  $\cot_p(\pi C)$  is the largest. We would like to use our new 1-point extension theorem to lift the optimal center of  $\pi C$  from  $\mathbb{R}^d$  to the original space  $\mathbb{R}^m$ . However, we cannot do this directly, since it may be the case that most pairwise distances in C are distorted.

**Everywhere sparse distortion graphs.** To deal with this problem, we define a distortion graph G for map  $\pi:X\to\mathbb{R}^m$ . The vertex set of G is X. Two points  $u,v\in X$  are joined by an edge in G if  $\pi$  distorts the distance between u and v by a factor of at least  $(1+\varepsilon)$ . We say that a subgraph H of G is  $\theta$  everywhere sparse if the degree of all vertices in H are upper bounded by  $\theta|V_H|$ . Observe that the probability that (u,v) is an edge in G is less than 1/poly(k) if  $d\gtrsim \log(k)/\varepsilon^2$ . Note that the distortion graphs for  $\pi$  and its inverse  $\pi^{-1}$  are the same.

We can now restate condition ( $\star$ ) of the 1-point extension theorem as follows: The distortion graph for the map  $\varphi$  is  $\theta$  everywhere sparse. Note, however, that the induced distortion graph G[C] for

<span id="page-2-2"></span> $<sup>^1</sup>$ Recall that  $\varphi$  is an L-Lipschitz map if for all  $x',x''\in X,$  we have  $\|\varphi(x')-\varphi(x'')\|\leq L\|x'-x''\|.$ 

maps  $\pi$  and  $\pi^{-1}$  is not necessarily  $\theta$ -everywhere sparse. Nevertheless, we show that it is possible to remove some outlier points from X to make the induced graph G[C] sparse. Specifically, we prove that there exists a random set B (which depends on  $\pi$ ) such that

- (a) the graph  $G[C \setminus B]$  is  $\theta$  everywhere sparse;
- (b)  $Pr(x \in B) \le \theta$  for all  $x \in B$ .

The proof of the existence of B is fairly simple for the special case when the size of cluster C is approximately n/k. Mark a point  $x \in X$  as an outlier if its degree in G is greater than  $\theta n/(2k)$  and let B be the set of all outliers. Observe that the degree of every vertex in  $C \setminus B$  is at most  $\theta n/(2k)$  and, thus, the maximum degree in the induced graph  $G[C \setminus B]$  is at most  $\theta n/(2k)$ .

The expected degree of a vertex in G is much smaller than  $\theta^2 n/k^2$ , since the probability that the distance between two given points is distorted is much less than  $\theta^2/k^2$  (if  $d \gtrsim \log(k/\theta)/\epsilon^2$ ). Hence,  $\Pr(x \in B) \ll \theta/k$  for any  $x \in X$  and, therefore, condition (b) is satisfied. Also, by linearity of expectation, the expected size of B is at most  $\theta n/k$ , and by Markov's inequality,  $|B| \ll n/k$  w.h.p. Thus,  $|C \setminus B| \ge n/(2k)$  w.h.p. and, consequently,  $G[C \setminus B]$  is a  $\theta$  everywhere sparse graph w.h.p. The proof for the general case when the size of the cluster C may be arbitrary is more involved (see Theorem 3.2). Roughly speaking, we reduce the general case to the case when  $|C| \approx n/k$  by introducing a carefully chosen measure  $\mu$  on X that we use as a proxy for the set sizes.

**Outliers.** We are now almost done. The distortion graph for the set  $C \setminus B$  is  $\theta$ -everywhere sparse. Thus, by the robust 1-point extension theorem applied to the set  $\pi(C \setminus B)$  and map  $\pi^{-1}$ , we can lift the optimal center of  $C \setminus B$  to the space  $\mathbb{R}^m$ . To finish the proof, it only remains to take care of two sets of outliers.

The first set is the set B. We slightly modify our data set. We move each outlier x to the optimal center of the cluster  $C^*(x)$  that the point x is assigned to in the optimal solution to k-means and then return x back to its cluster C. Since the probability that x is an outlier is very small, the cost of moving x is also small (see Theorem 3.4).

The second type of outliers are the points  $x \in C$  such that  $\|x-v\| > (1+\varepsilon)\|\pi x - u\|$ , where u is the optimal center of C and v is the optimal center lifted to  $\mathbb{R}^m$ . The fraction of such outliers among all points in C is at most  $\theta'$ . We charge the connection costs of these outliers (i.e., the costs of assigning outliers to the centers of their clusters) to the connection costs of other vertices.

This concludes the proof. In the rest of the paper, we give a detailed proof of Theorem 1.3.

#### 2 PRELIMINARIES

Let  $X\subset\mathbb{R}^d$  be an instance of Euclidean k-clustering with the  $\ell_p$  objective. We denote the optimal k-clustering of X by  $C^*=\{C_1^*,\ldots,C_k^*\}$  and its optimal centers by  $c_1^*,\ldots,c_k^*$ . Given a cluster  $S\subset X$ , let  $\cos_p S=\min_{c\in\mathbb{R}^d}\sum_{u\in\mathbb{R}^d}\|u-c\|^p$  be its cost. Given a clustering  $C=\{C_1,\ldots,C_k\}$ , let  $\cos_p C=\sum_{i=1}^k \cos_p C_i$  be its cost. In particular,  $\cos C^*$  is the cost of the optimal clustering of X. Given a map  $\pi$  and  $C=\{C_1,\ldots,C_k\}$ , denote by  $\pi(C)$  the clustering  $\pi(C_1),\ldots,\pi(C_k)$  of  $\pi(X)$ .

We denote the indicator of an event  $\mathcal{E}$  by  $\mathbf{1}_{\{\mathcal{E}\}}$  or  $\mathbf{1}_{\{\mathcal{E}\}}$ .

<span id="page-3-0"></span>Definition 2.1. Random map  $\pi : \mathbb{R}^m \to \mathbb{R}^d$  is an  $(\varepsilon, \delta)$ -random dimension reduction if

$$\frac{1}{1+\varepsilon} \|x - y\| \le \|\pi(x) - \pi(y)\| \le (1+\varepsilon)\|x - y\|$$

with probability at least  $1 - \delta$  for every  $x, y \in \mathbb{R}^m$ . Given  $p \in [1, \infty)$ , random map  $\pi$  is an  $(\varepsilon, \delta, \rho)$ -dimension reduction if it additionally satisfies the following property

<span id="page-3-2"></span>
$$\mathbb{E}\left[\mathbf{1}_{\{\|\pi(x) - \pi(y)\| > (1+\varepsilon)\|x - y\|\}} \left(\frac{\|\pi(x) - \pi(y)\|^p}{\|x - y\|^p} - (1+\varepsilon)^p\right)\right] \le \rho. \tag{5}$$

Given  $\varepsilon > 0$ , we say that a random dimension reduction  $\pi : \mathbb{R}^m \to \mathbb{R}^d$  is standard if it has parameters  $(\varepsilon, \delta, \rho)$  and  $\delta \leq \exp(-c\varepsilon^2 d)$ ,  $\rho \leq \exp(-c\varepsilon^2 d)$  when  $d > c'p/\varepsilon^2$  for some constants c, c' > 0.

DEFINITION 2.2. We say that  $\pi$  approximately preserves or  $(1+\varepsilon)$ -preserves the distance between x and y if  $\frac{1}{1+\varepsilon}\|x-y\| \leq \|\pi(x)-\pi(y)\| \leq (1+\varepsilon)\|x-y\|$ . Otherwise, we say that  $\pi$  distorts the distance between x and y. For brevity, we also say that (x,y) is  $(1+\varepsilon)$ -preserved in the former case and distorted in the latter case.

We define the distortion graph G=(X,E) for  $\pi$  as follows. Two points  $x,y\in X$  are connected with an edge if  $\pi$  distorts the distance between them. Note that when  $\pi$  is an  $(\varepsilon,\delta)$ -random dimension reduction, G is a random graph and  $\Pr((x,y)\in E)\leq \delta$  for every  $x,y\in X$ .

As we prove in Lemma C.1, every dimension reduction that (1) satisfies Theorem 1.1 and (2) is sub-Gaussian tailed is standard. We note that all dimension reduction constructions (satisfying Theorem 1.1) that we are aware of are sub-Gaussian tailed and thus standard. In particular, we prove in Claim C.2 that the Gaussian dimension reduction is sub-Gaussian tailed.

## 3 DIMENSION REDUCTION PRESERVES CLUSTER COSTS

In this section, we prove Theorem 1.3, the main result of this paper. The proof relies on Theorems 3.2 and 3.3, which we prove later in Sections 4 and 5. We note that Theorem 3.2 is a purely combinatorial theorem about random graphs, which does not deal with distances or embeddings. On the other hand, Theorem 3.3 is about a deterministic dimension reduction map  $\varphi$ , it states that  $\varphi$  approximately preserves the cost of a cluster C loosely speaking when the maximum degree in G[C] (the graph induced by C on the distortion graph) is much smaller than |C|.

#### 3.1 Theorems 3.2 and 3.3

We formally state Theorems 3.2 and 3.3.

Definition 3.1. A graph H = (V, E) is  $\theta$  everywhere-sparse if  $\deg u \leq \theta |V|$  for every  $u \in V$ . (We allow V to be empty.)

<span id="page-3-1"></span>Theorem 3.2. Consider a finite set X and a random graph H = (V, E), where V is a random subset of X and E is a random set of edges between vertices in V (we do not make any independence assumptions). Let  $\theta \in (0, 1/2)$ . Assume that  $\Pr((x, y) \in E) \leq \delta$  for every  $x, y \in X$ , where  $\delta \leq \theta^7/600$  (if  $x \notin V$  or  $y \notin V$ , then  $(x, y) \notin E$ ). Then there exists a random subset  $V' \subset V$  (V' is defined on the same probability space as H; in other words, it is jointly distributed with H) such that

• H[V'] is  $\theta$  everywhere-sparse,

•  $\Pr(u \in V \setminus V') \le \theta \text{ for all } u \in X.$ 

<span id="page-4-2"></span>THEOREM 3.3. Consider a finite multiset of points  $\tilde{C} \subset \mathbb{R}^{d'}$  and a map  $\varphi : \tilde{C} \to \mathbb{R}^{d''}$ . Assume that the distortion graph G for  $\tilde{C}$  is  $\theta$ -sparse. Then, for every  $p \geq 1$  and  $D = (1 + \varepsilon)^p (1 + 3^{p+2} \theta^{1/(p+1)})$ , we have

$$D^{-1} \operatorname{cost}_{p}(\tilde{C}) \leq \operatorname{cost}_{p}(\varphi(\tilde{C})) \leq D \operatorname{cost}_{p}(\tilde{C}).$$

## 3.2 Cluster costs are approximately preserved

Assume that  $C \subset X$  is a random subset/cluster of X; C may depend on the random projection  $\pi$ . We prove that  $\mathrm{cost}_p C$  is approximately equal  $\mathrm{cost}_p \pi(C)$  up to some multiplicative and additive errors with high probability.

<span id="page-4-1"></span>Theorem 3.4. Consider an instance X of Euclidean k-clustering with the  $\ell_p$ -objective. Let  $\pi$  be a  $(\varepsilon, \delta, \theta)$ -random dimension reduction, and C be a random subset/cluster of X (which may depend on  $\pi$ ). Assume that  $\delta \leq \min(\theta^7/600, \theta/k)$ . Denote the optimal clustering of X by  $C^*$ . Then

$$cost_p \pi(C) \le A \left( cost_p C + c_{\alpha \epsilon \theta} cost_p C^* \right)$$
(6)

$$cost_p C \le A \left( cost_p \pi(C) + c_{\alpha \in \theta} cost_p C^* \right) \tag{7}$$

with probability at least  $1 - \alpha - \binom{k}{2}\delta$ , where  $A = (1 + \varepsilon)^{3p-2}(1 + 3^{p+2}\theta^{1/(p+1)})$  and  $c_{\alpha \in \theta} = \frac{5(1+\varepsilon)^p\theta}{\alpha\varepsilon^{p-1}}$ .

PROOF. Let c be the optimal center for cluster C. Denote the clusters of  $C^*$  by  $C_1^*,\ldots,C_k^*$  and the optimal centers for  $C_1^*,\ldots,C_k^*$  by  $c_1^*,\ldots,c_k^*$ . Let  $c^*(x)=c_i^*$  if  $x\in C_i^*$ . Consider the event  $\mathcal E$  that all the distances between the centers  $c_i^*$  are  $(1+\varepsilon)$ -preserved. Note that  $\Pr(\mathcal E)\geq 1-\binom{k}{2}\mathcal S$ . We assume below that  $\mathcal E$  happens. Let  $C^\circ=\{x\in C:\pi \text{ approximately preserves distance between <math>x$  and each  $c_i^*\}$ . Note that

$$Pr(x \in C \setminus C^{\circ})$$

 $\leq$  Pr (distance between x and some  $c_i$  is distorted)  $\leq k\delta$ 

for all  $x \in X$ . We apply Theorem 3.2 to  $H = G[C^{\circ}]$  (the graph induced by  $C^{\circ}$  on the distortion graph G). We get a subset  $C' \subset C$  such that G[C'] is  $\theta$  everywhere-sparse and  $\Pr(x \in C^{\circ} \setminus C') \leq \theta$ . Observe that

 $\Pr\left(x \in C \setminus C'\right) \le \Pr\left(x \in C \setminus C^{\circ}\right) + \Pr\left(x \in C^{\circ} \setminus C'\right) \le \theta + k\delta \le 2\theta.$ 

Let

$$g(x) = \begin{cases} x, & \text{if } x \in C' \\ c^*(x), & \text{if } x \notin C'. \end{cases}$$

Consider multiset  $\widetilde{C}=g(C)$ . By construction, every point in  $\widetilde{C}$  is either in C' or equal to some  $c_i^*$ . Let  $\widetilde{c}$  be the optimal center for  $\widetilde{C}$ . Since G[C'] is  $\theta$  everywhere-sparse, the map  $\pi$  approximately preserves the distances from every  $x\in C'$  to at least a  $(1-\theta)$  fraction of the points in C' and to all  $c_i^*$ . Further, since  $\mathcal{E}$  happens, all distances between centers  $c_i^*$  are  $(1+\varepsilon)$ -preserved. Therefore, we can apply Theorem 3.3 to multiset  $\widetilde{C}$  and map  $\varphi=\pi$ . We get that

<span id="page-4-3"></span>
$$D^{-1} \operatorname{cost}_{p}(\widetilde{C}) \le \operatorname{cost}_{p}(\pi(\widetilde{C})) \le D \operatorname{cost}_{p}(\widetilde{C})$$
 (8)

for 
$$D = (1 + \varepsilon)^p (1 + 3^{p+2}\theta^{1/(p+1)})$$
. Note that

$$\operatorname{cost}_p C \leq \sum_{x \in C} \|x - \tilde{c}\|^p \quad \text{and} \quad \operatorname{cost}_p \widetilde{C} = \sum_{x \in C} \|g(x) - \tilde{c}\|^p,$$

since  $\tilde{c}$  is the optimal center for  $\widetilde{C}$ . Compare the summations in the upper bound for  $\operatorname{cost}_p C$  and the formula for  $\operatorname{cost}_p \widetilde{C}$  term by term. For  $x \in C'$ , g(x) = x and thus the terms in both summations are equal. For  $x \notin C'$ , the terms in the first and second summations are equal to  $||x - \tilde{c}||^p$  and  $||c^*(x) - \tilde{c}||^p$ , respectively. Therefore,

$$\operatorname{cost}_p C - (1+\varepsilon)^{p-1} \operatorname{cost}_p \widetilde{C} \leq \sum_{x \in C \setminus C'} \|x - \widetilde{c}\|^p - (1+\varepsilon)^{p-1} \|c^*(x) - \widetilde{c}\|^p.$$

Observe that  $||x-\tilde{c}|| \le ||x-c^*(x)|| + ||c^*(x)-\tilde{c}||$ . Applying Lemma A.1 with r=1, we get

$$||x - \tilde{c}||^p \le (1 + \varepsilon)^{p-1} ||c^*(x) - \tilde{c}||^p + \left(\frac{1 + \varepsilon}{\varepsilon}\right)^{p-1} ||x - c^*(x)||^p.$$

<span id="page-4-4"></span>Let 
$$\tau = \left(\frac{1+\varepsilon}{\varepsilon}\right)^{p-1}$$
. Then,

$$\operatorname{cost}_p C - (1+\varepsilon)^{p-1} \operatorname{cost}_p \widetilde{C} \le \tau \sum_{x \in C \setminus C'} \|x - c^*(x)\|^p.$$

<span id="page-4-0"></span>Similarly,

$$\begin{split} \cosh_p \tilde{C} - (1+\varepsilon)^{p-1} \cosh_p C &\leq \tau \sum_{x \in C \setminus C'} \|x - c^*(x)\|^p \\ \cosh_p \pi(C) - (1+\varepsilon)^{p-1} \cosh_p \pi(\tilde{C}) &\leq \tau \sum_{x \in C \setminus C'} \|\pi(x) - \pi(c^*(x))\|^p \\ \cosh_p \pi(\tilde{C}) - (1+\varepsilon)^{p-1} \cosh_p \pi(C) &\leq \tau \sum_{x \in C \setminus C'} \|\pi(x) - \pi(c^*(x))\|^p \end{split}$$

Combining these bounds with inequality (8), we obtain

$$cost_{p} \pi(C) \le A \left( cost_{p} C + \varepsilon^{1-p} \sum_{c \in X \setminus X'} R_{x} \right) \\
cost_{p} C \le A \left( cost_{p} \pi(C) + \varepsilon^{1-p} \sum_{c \in X \setminus X'} R_{x} \right)$$

where  $A = (1+\varepsilon)^{2(p-1)}D$  and  $R_x = ||x-c^*(x)||^p + ||\pi(c^*(x)) - \pi(x)||^p$ .

It remains to prove that

$$\varepsilon^{1-p} \sum_{x \in C \setminus C'} 1\{\mathcal{E}\} R_x \le c_{\alpha \in \theta} \operatorname{cost}_p C^*$$

with probability at least  $1 - \alpha$ . To this end, we show that

$$\mathbb{E}\left[1\left\{\mathcal{E}\right\}\sum_{x\in C\setminus C'}R_{x}\right]\leq 5(1+\varepsilon)^{p}\theta\cot_{p}C^{*}$$

and then use Markov's inequality. From property (5) in Definition 2.1 we get that for every  $x \in C$ ,

$$\mathbb{E}\left[\max(\|\pi(c^*(x)) - \pi(x)\|^p - (1+\varepsilon)^p \|c^*(x) - x\|^p, 0)\right] \\ \leq \theta \|c^*(x) - x\|^p.$$

STOC '19, June 23-26, 2019, Phoenix, AZ, USA

Therefore.

$$\begin{split} & \mathbb{E}\Big[\sum_{x \in C \setminus C'} \|\pi(c^*(x)) - \pi(x)\|^p\Big] \leq (1+\varepsilon)^p \mathbb{E}\Big[\sum_{x \in C \setminus C'} \|c^*(x) - x\|^p\Big] \\ & + \mathbb{E}\Big[\sum_{x \in C \setminus C'} \max(\|\pi(c^*(x)) - \pi(x)\|^p - (1+\varepsilon)^p \|c^*(x) - x\|^p, 0)\Big] \end{split}$$

Now, we bound the second term as

$$\sum_{x \in X} \mathbb{E} \left[ \max(\|\pi(c^*(x)) - \pi(x)\|^p - (1 + \varepsilon)^p \|c^*(x) - x\|^p, 0) \right]$$

$$\leq \sum_{x \in X} \theta \|c^*(x) - x\|^p = \theta \cot_p C^*$$

Thus,  $\mathbb{E}\left[\sum_{x \in C \setminus C'} \|\pi(c^*(x)) - \pi(x)\|^p\right] \le (1+\varepsilon)^p \mathbb{E}\left[\sum_{x \in C \setminus C'} \|c^*(x) - x\|^p\right] + \theta \cot_p C^*$ . We also have,

$$\mathbb{E}\left[\sum_{x\in C\setminus C'} \|x-c^*(x)\|^p\right] \le \sum_{x\in X} \Pr\left(x\in C\setminus C'\right) \|x-c^*(x)\|^p$$
$$\le 2\theta \sum_{x\in X} \|x-c^*(x)\|^p = 2\theta \cot_p C^*.$$

Therefore,

$$\mathbb{E}\left[1\left\{\mathcal{E}\right\} \sum_{x \in C \setminus C'} R_x\right]$$

$$\leq \mathbb{E}\left[\sum_{x \in C \setminus C'} \|\pi(c^*(x)) - \pi(x)\|^p + \|x - c^*(x)\|^p\right]$$

$$\leq 5(1 + \varepsilon)^p \theta \cot_p C^*.$$

By Markov's inequality,

$$\begin{split} \Pr \left( \mathbf{1} \left\{ \mathcal{E} \right\} \varepsilon^{1-p} \sum_{x \in C \setminus C'} R_x &\geq c_{\alpha \epsilon \theta} \cot_p C^* \right) \\ &\leq \varepsilon^{1-p} \cdot \frac{5(1+\varepsilon)^p \theta \cot_p C^*}{c_{\alpha \epsilon \theta} \cot_p C^*} = \alpha. \end{split}$$

We conclude that

$$\Pr((6) \text{ and } (7) \text{ hold}) \ge 1 - \alpha - \Pr(\mathcal{E}) \ge 1 - \alpha - \binom{k}{2} \delta.$$

### 3.3 Proof of main results

Now we prove the main results: Theorem 3.5, Theorem 3.6 and Theorem 1.3.

<span id="page-5-0"></span>Theorem 3.5. Let X be an instance of k-clustering with the  $\ell_p$ -objective. Let  $\varepsilon \in (0,1/4)$  (the distortion parameter) and  $\alpha \in (0,1)$  (the failure probability). Let  $\pi: \mathbb{R}^m \to \mathbb{R}^d$  be a standard random dimension-reduction map with

<span id="page-5-4"></span>
$$d = \frac{c(\log\frac{k}{\alpha} + p\log\frac{1}{\varepsilon} + p^2)}{\varepsilon^2}$$
 (9)

(where c only depends on the parameters of map  $\pi$  in Definition 2.1).

Konstantin Makarychev, Yury Makarychev, and Ilya Razenshteyn

With probability at least  $1 - \alpha$  the following event  $\mathcal{D}$  happens: for every clustering C of X inequalities (10) and (11) hold.

<span id="page-5-3"></span><span id="page-5-2"></span>
$$cost_p \, \pi(C) \le (1 + \varepsilon)^{3p} \, cost_p \, C \tag{10}$$

$$(1 - \varepsilon) \operatorname{cost}_{p} C \le (1 + \varepsilon)^{3p - 1} \operatorname{cost}_{p} \pi(C)$$
(11)

PROOF. Let  $\theta = \min(\varepsilon^{p+1}3^{(p+1)(p+2)}, \alpha\varepsilon^p/(10k(1+\varepsilon)^{4p-1})$ . We choose constant c in (9) so that the parameters  $(\varepsilon, \delta, \rho)$  of dimension reduction  $\pi$  satisfy  $\delta \leq \min(\theta^7/600, \theta/k)$ ,  $\binom{k}{2}\delta \leq \alpha/2$ , and  $\rho \leq \theta$  (we can do this, since  $\pi$  is a standard dimension reduction). By our choice of parameters,  $A \leq (1+\varepsilon)^{3p-1}$  and  $Ac_{\alpha\varepsilon\theta} \leq \varepsilon/k$  in the statement of Theorem 3.4.

To apply Theorem 3.4, we define a random cluster C. First, assume that event  $\mathcal{D}$  does not happen. Then there exists a clustering  $C_1, \ldots, C_k$  violating one of the inequalities (10) or (11). Thus, one of the following inequalities hold.

$$\sum_{i=1}^{k} \operatorname{cost}_{p} \pi(C_{i}) \ge A \left( \sum_{i=1}^{k} \operatorname{cost}_{p} C_{i} \right) + \varepsilon \operatorname{cost}_{p} C \tag{12}$$

$$\sum_{i=1}^{k} \operatorname{cost}_{p} C_{i} \ge A \left( \sum_{i=1}^{k} \operatorname{cost}_{p} \pi(C_{i}) \right) + \varepsilon \operatorname{cost}_{p} C$$
 (13)

Therefore, for some  $C_i$ , we have either (14) or (15).

$$cost_p \pi(C_i) \ge A cost_p C_i + \frac{\varepsilon}{k} cost_p C$$
(14)

<span id="page-5-6"></span><span id="page-5-5"></span>
$$cost_p C_i \ge A cost_p \pi(C_i) + \frac{\varepsilon}{k} cost_p \pi(C)$$
(15)

Let  $C = C_i$ . If  $\mathcal{D}$  happens, we let C be an arbitrary cluster (e.g., let C consist of a single point). Note that if  $\mathcal{D}$  does not happen then we have one of the following, since  $\cos t_p C^* \leq \cos t_p C$ .

$$cost_p \pi(C) \ge A cost_p C + \frac{\varepsilon}{k} cost_p C^*$$
(16)

<span id="page-5-8"></span><span id="page-5-7"></span>
$$cost_p C \ge A cost_p \pi(C) + \frac{\varepsilon}{k} cost_p \pi(C^*) \tag{17}$$

Applying Theorem 3.4, we get that the probability that one of the inequalities (16) or (17) holds is at most  $\alpha/2 + \binom{k}{2}\delta \leq \alpha$ . Thus  $\Pr(\mathcal{D}) \geq 1 - \alpha$ . The statement of the theorem follows.

As a corollary, we get the following formulation of the theorem.

<span id="page-5-1"></span>Theorem 3.6. Let X be an instance of k-clustering with the  $\ell_p$ -objective. Let  $\varepsilon \in (0,1/4)$  (the distortion parameter) and  $\alpha \in (0,1)$  (the failure probability). Let  $\pi: \mathbb{R}^m \to \mathbb{R}^d$  be a standard random dimension-reduction map with

$$d = \frac{c_p \log(k/(\epsilon \alpha))}{\epsilon^2}$$
 where  $c_p = O(p^4)$ .

Then with probability at least  $1 - \alpha$ :

 $(1-\varepsilon) \cot_p C \le \cot_p \pi(C) \le (1+\varepsilon) \cot_p C$  for every clustering C

Proof. We apply Theorem 3.5 with  $\varepsilon'=(1+\varepsilon)^{1/(3p)}-1=O(\varepsilon/p)$  and obtain the desired inequality.  $\Box$ 

Now we prove Theorem 1.3.

PROOF OF THEOREM 1.3. We apply Lemma C.1 to  $\pi_{m,d}$ . Since  $\pi_{m,d}$  satisfies the condition of Theorem 1.1 and is sub-Gaussian tailed, it is a standard dimension reduction. Applying Theorem 3.6, we get the desired result.

#### <span id="page-6-0"></span>4 EVERYWHERE-SPARSE SUBGRAPH

In this section, we prove Theorem 3.2. The main ingredient of the proof is Lemma 4.1, which we prove in Section 4.1.

#### <span id="page-6-2"></span>4.1 Main Combinatorial Lemma

<span id="page-6-1"></span>Lemma 4.1. Let X be a finite set and  $V \subset X$  be a random subset of X. Let  $\theta \in (0, 1/2)$ . Assume that  $\Pr(x \in V) \ge 2\theta$  for every x. Then there exist a random set  $R \subset V$  (defined on the same probability space as V) and a deterministic measure  $\mu$  on X such that

- (1)  $\mu(x) \geq \frac{1}{|V \setminus R|}$  for every  $x \in V \setminus R$  (always); (2)  $\Pr(x \in R) \leq \theta$  for every  $x \in X$ ; (3)  $\mu(X) = \sum_{X \in X} \mu(X) \leq \frac{\Pr(V \neq \varnothing)}{\theta^2}$ .

PROOF. We prove this lemma by induction on the size of the set X. If |X| = 0 i.e. X is empty, then properties 1–3 trivially hold. Assume that the statement holds for all sets X' of size |X'| < |X|and prove it for X.

Let  $l = \theta |X|$ . Define a (deterministic) set X' and a random subset  $V' \subset X'$  as follows:

$$X' = \{x : \Pr(x \in V \text{ and } |V| < l) \ge 2\theta\}$$
 (18)

$$V' = \begin{cases} V \cap X', & \text{if } |V| < l \\ \emptyset, & \text{otherwise} \end{cases}$$
 (19)

First, we prove that for some  $x_0 \in X$ ,  $\Pr(x_0 \in V \text{ and } |V| < l) \le \theta$ and, consequently, |X'| < |X|. To this end, we show that the average value of  $Pr(x \in V \text{ and } |V| < l)$  for  $x \in X$  is at most  $\theta$ :

$$\begin{split} &\frac{1}{|X|}\sum_{x\in X}\Pr(x\in V\text{ and }|V|< l)\\ &=\frac{1}{|X|}\sum_{x\in X}\mathbb{E}\big[\mathbf{1}\left\{x\in V\text{ and }|V|< l\right\}\big]\\ &=\frac{1}{|X|}\mathbb{E}\Big[\sum_{x\in X}\mathbf{1}\left\{x\in V\text{ and }|V|< l\right\}\Big]\\ &=\frac{1}{|X|}\mathbb{E}[|V|\cdot\mathbf{1}\left\{|V|< l\right\}]\leq \frac{l}{|X|}=\theta. \end{split}$$

Here we used that the random variable  $|V| \cdot \mathbf{1} \{|V| < l\}$  is always less than l.

Since |X'| < |X| and  $\Pr(x \in V') \ge 2\theta$  for every  $x \in X'$ , we can apply the induction hypothesis to X' and V'. By the inductive hypothesis, there exist a random set  $R' \subset X'$  and measure  $\mu'$  on X' satisfying properties 1–3 for the set X' and random subset V'. Define a measure  $\mu$  on X and random subset  $R \subset V$  as follows:

$$\mu(x) = \begin{cases} \mu'(x) + 1/l, & \text{if } x \in X' \\ 1/l, & \text{otherwise} \end{cases}$$

$$R = \begin{cases} R' \cup (V \setminus X'), & \text{if } |V| < l \\ R', & \text{otherwise} \end{cases}$$

$$(20)$$

$$R = \begin{cases} R' \cup (V \setminus X'), & \text{if } |V| < l \\ R', & \text{otherwise} \end{cases}$$
 (21)

We verify that R and  $\mu$  satisfy the desired conditions

Condition 1: for every  $x \in V \setminus R$ ,  $\mu(x) \ge 1/|V \setminus R|$  (always). Fix  $x \in V \setminus R$  and consider three cases. If  $x \in X'$  and |V| < l, we have  $V \setminus R = V' \setminus R'$  by (21). Thus,  $\mu(x) > \mu'(x) \ge \frac{1}{|V' \setminus R'|} =$  $\frac{1}{|V \setminus R|}$  by the induction hypothesis. If  $x \in X'$  and  $|V| \ge l$ , then  $\mu(x) \ge 1/l \ge 1/|V|$ . Note that  $V' = \emptyset$  (since  $|V| \ge l$ ). Hence,

$$R \stackrel{\text{by (21)}}{=} R' \subset V' = \varnothing$$
. In particular,  $1/|V| = 1/|V \setminus R|$  and thus  $\mu(x) \ge 1/|V \setminus R|$ .

Finally, if  $x \notin X'$ , then  $x \in V \setminus X' \subset R' \cup (V \setminus X')$  and  $x \notin R$ . Thus,  $R \neq R' \cup (V \setminus X')$ . From (21), we get that  $|V| \geq l$  and hence  $\mu(x) = 1/l \ge 1/|V|$ . Again, since  $|V| \ge l$ , we have  $\mu(x) \ge 1/|V| = 1/|V|$  $1/|V\setminus R|$ .

Condition 2:  $Pr(x \in R) \le 2\theta$ . If  $x \in X'$ , then  $Pr(x \in R) = Pr(x \in R)$ R')  $\leq 2\theta$  by the induction hypothesis. If  $x \notin X'$ , then

$$\Pr(x \in R) \stackrel{\text{by (21)}}{=} \Pr(x \in V \text{ and } |V| < l) \stackrel{\text{by (18)}}{\leq} 2\theta.$$

Condition 3:  $\mu(X) = \sum_{x \in X} \mu(x) \le \Pr(V \neq \emptyset)/\theta^2$ . By the inductive hypothesis, we have  $\mu'(X') \leq \Pr(V' \neq \emptyset)/\theta^2$ . Thus,

$$\mu(X) = \mu'(X') + \frac{|X|}{l} \le \frac{\Pr(V' \neq \varnothing)}{\theta^2} + \frac{1}{\theta}.$$

<span id="page-6-4"></span>To finish the proof, we need to show th

$$\frac{\Pr(V' \neq \varnothing)}{\theta^2} + \frac{1}{\theta} \leq \frac{\Pr(V \neq \varnothing)}{\theta^2},$$

or, equivalently,  $\Pr(V \neq \emptyset) - \Pr(V' \neq \emptyset) \geq \theta$ . Note that if  $|V| \geq l$ , then  $V \neq \emptyset$  and  $V' = \emptyset$ . Thus (since  $V' \subset V$ ),

$$\Pr(V \neq \varnothing) - \Pr(V' \neq \varnothing) = \Pr(V \neq \varnothing) \text{ and } V' = \varnothing) \ge \Pr(|V| \ge l).$$

Recall that for some  $x_0 \in X$ , we have  $\Pr(x_0 \in V \text{ and } |V| \leq l) \leq \theta$ . Since for all  $x \in X$ ,  $\Pr(x \in X) \ge 2\theta$ , we have

$$\Pr(|V| \ge l) \ge \Pr(x_0 \in V \text{ and } |V| \ge l)$$
  
  $\ge \Pr(x_0 \in V) - \Pr(x_0 \in V \text{ and } |V| \le l) \ge \theta.$ 

This completes the proof.

<span id="page-6-5"></span>COROLLARY 4.2. Let X be a finite set and  $V \subset X$  be a random subset of X. Let  $\theta \in (0, 1/2)$ . Then there exist a random set  $R \subset V$ and measure  $\mu$  on X such that

- (1)  $\mu(x) \ge \frac{1}{|V \setminus R|}$  for every  $x \in V \setminus R$  (always) (2)  $\Pr(x \in R) \le 2\theta$  for every  $x \in X$
- (3)  $\mu(X) = \sum_{x \in X} \mu(x) \le \frac{1}{2}$

PROOF. Let  $X' = \{x : \Pr(x \in V) \ge 2\theta\}$ . We apply the lemma to X' and then let

$$R = (R' \cup (X \setminus X')) \cap V.$$

<span id="page-6-3"></span>We will need the following observation.

<span id="page-6-6"></span>Observation 4.3. Let R be as in Corollary 4.2 and  $V_0 = V \setminus R$ . Then for every  $S \subset V_0$ , we have  $|S| \leq \mu(S)|V_0|$ .

PROOF. By Corollary 4.2,  $\mu(x) \ge 1/|V_0|$  for every  $x \in S$ . Therefore,  $\mu(S) \ge |S|/|V_0|$  and  $|S| \le \mu(S)|V_0|$ .

#### 4.2 Proof of Theorem 3.2

PROOF. Let  $\beta = \frac{\theta}{1+\theta}$  and  $\theta' = \theta/3$ . Applying Corollary 4.2 with parameter  $\theta'$ , we get a deterministic measure  $\mu$  on V and a random set  $R \subset V$ . Let  $V_0 = V \setminus R$ . Denote  $M = \mu(X) \le 1/\theta'^2$ . Consider the product measure  $\mu^{\otimes 2}$  on  $X \times X$ , defined by  $\mu^{\otimes 2}((x,y)) = \mu(x) \cdot \mu(y)$  for  $x,y \in X$ . Then  $\mu(X \times X) = M^2$ .

Since  $\Pr((x, y) \in E) \le \delta$  for every  $x, y \in X$ , we have  $\mathbb{E}\left[\mu^{\otimes 2}(E)\right] \le \delta M^2$ . By Markov's inequality,

$$\Pr\left(\mu^{\otimes 2}(E) \ge \beta^2\right) \le \frac{\delta M^2}{\beta^2} \le \theta/3.$$

If  $\mu^{\otimes 2}(E) \geq \beta^2$ , we let  $V' = \emptyset$ . In this case, H[V'] is empty and trivially  $\theta$ -sparse. We now consider the main case when  $\mu^{\otimes 2}(E) < \beta^2$ . We say that  $x \in X$  is bad if

<span id="page-7-2"></span>
$$\mu(\lbrace y \in V_0 : (x, y) \in E \rbrace) \ge \beta. \tag{22}$$

Denote the set of bad points by B (note that B is a random set). Observe that  $B \subset V$ , since if  $x \notin V$  then x is not connected to any y and thus  $\{y \in V_0 : (x, y) \in E\} = \emptyset$ . Define V' as

$$V' = V \setminus (R \cup B) = V_0 \setminus B$$
.

Let us verify that V' satisfies the desired properties. First, we check that H[V'] is  $\theta$  everywhere-sparse; that is,  $\deg_{H[V']} x \leq \theta |V'|$  for every  $x \in V'$ . That is,  $|\{y \in V' : (x,y) \in E\}| \leq \theta |V'|$ . To this end, we upper bound the measures and cardinalities of sets  $V_0 \cap B$  and  $\{y \in V' : (x,y) \in E\}$ . For every  $x \in B$ ,

$$\mu^{\otimes 2} \big( \left\{ (x,y) \in E \right\} \big) = \mu(x) \cdot \mu \big( \left\{ y \in V : (x,y) \in E \right\} \big) \ge$$
$$\ge \mu(x) \cdot \mu \big( \left\{ y \in V_0 : (x,y) \in E \right\} \big) \ge \mu(x) \cdot \beta.$$

Consequently,

$$\mu^{\otimes 2}(E) \geq \sum_{x \in B} \mu^{\otimes 2} \big( \left\{ (x, y) \in E \right\} \big) \geq \beta \mu(B)$$

and  $\mu(B) \le \mu^{\otimes 2}(E)/\beta < \beta$ . In particular,  $\mu(V_0 \cap B) \le \mu(B) \le \beta$ . Consider now  $x \in V'$ . Since  $x \notin B$ .

$$\mu(\{y \in V' : (x, y) \in E\}) \le \mu(\{y \in V_0 : (x, y) \in E\}) \le \beta.$$

By Observation 4.3,  $|\{y \in V' : (x, y) \in E\}| \le \beta |V_0|$  and  $|V_0 \cap B| \le \mu(V_0 \cap B)|V_0| \le \beta |V_0|$ . From the latter inequality, we get  $|V'| = |V_0 \setminus B| \ge (1 - \beta)|V_0|$ . We conclude that

$$|\{y \in V' : (x, y) \in E\}| \le \frac{\beta}{1 - \beta} |V'| = \theta |V'|,$$

as required.

To finish the proof, we need to show that  $\Pr(x \notin V \setminus V') \leq \theta$ . Note that x is in V but not in V only if one of the following events happens:

- **1.**  $\mu^{\otimes 2}(E) \ge \beta^2$ . As we showed above, the probability of this event is at most  $\theta/3$ .
- **2.**  $\mu^{\otimes 2}(E) < \beta^2$  and  $x \in R$ . By Corollary 4.2, the probability of this event is at most  $\theta' = \theta/3$ .
- **3.**  $\mu^{\otimes 2}(E) < \beta^2$  and  $x \in B$ . By Markov's inequality, the probability of this event is at most

$$\Pr\left(x \in B\right) \le \mathbb{E}\left[\mu\left(\left\{y \in V_0 : (x, y) \in E\right\}\right)\right]/\beta \le \delta M/\beta \le \theta/3,$$

here we used that for  $x \in B$ ,  $\mu(\{y \in V_0 : (x, y) \in E\})/\beta \ge 1$  see (22), and that  $\mathbb{E}[\mu(\{y \in V_0 : (x, y) \in E\})]$  is at most

$$\sum_{y \in X} \Pr\left((x, y) \in E\right) \mu(y) \le \sum_{y \in X} \delta \mu(y) = \delta M.$$

Thus, 
$$\Pr(x \in V \setminus V') \le \theta$$
.

#### <span id="page-7-1"></span>5 ONE POINT EXTENSION

Consider two sets of points X and Y in Euclidean space and a one-to-one map  $\varphi: X \to Y$ . Suppose that for every point x in X, the distances from x to all but a  $\theta$  fraction of x' in X do not increase under the map  $\varphi$ . In this section, we show that in this case, we have  $\mathrm{cost}_p(Y) \leq (1 + O(\theta^{1/(p+1)})) \, \mathrm{cost}_p(X)$ . We prove this statement (Lemma 5.3) using a robust version of the classic Kirszbraun Theorem (Theorem 5.2). To state our results, we need to define a distance expansion graph for the map  $\varphi$ . This definition is similar to the definition of the distortion graph.

DEFINITION 5.1 (DISTANCE EXPANSION GRAPH). Consider two finite metric spaces  $(X, d_X)$  and  $(Y, d_Y)$  and a map  $\varphi: X \to Y$ . Define the distance expansion graph for  $\varphi$  on elements of the space X as follows. A pair of vertices (x', x'') is an edge in the graph if and only if

$$d_Y(\varphi(x'), \varphi(x'')) > d_X(x', x'').$$

<span id="page-7-0"></span>Theorem 5.2 (Robust one point extension theorem for  $L_2$  spaces). Consider two finite (multi)sets of points  $X \subset \mathbb{R}^{d'}$  and  $Y \subset \mathbb{R}^{d''}$  and a map  $\varphi: X \to Y$ . Let G = (X, E) be the distance expansion graph for  $\varphi$  with respect to the Euclidean distance. Suppose that G is  $\theta$  everywhere-sparse. Then, for every  $u \in \mathbb{R}^{d'}$  and positive  $\varepsilon$ , there exists  $v \in \mathbb{R}^{d''}$  such that for all but possibly a  $\theta'(\varepsilon)$  fraction of points x in X we have

$$\|\varphi(x) - v\| \le (1+\varepsilon)\|x - u\|,$$

where  $\theta'(\varepsilon) = 2(1+\varepsilon)^2 \cdot \theta/\varepsilon$ .

First, we show how to derive the main result of this section (Lemma 5.3) from Theorem 5.2 and then prove Theorem 5.2 itself.

<span id="page-7-3"></span>Lemma 5.3. Consider two finite multisets of points  $X \subset \mathbb{R}^{d'}$  and  $Y \subset \mathbb{R}^{d''}$  and a one-to-one map  $\varphi: X \to Y$ . Let G = (X, E) be the distance expansion graph for  $\varphi$  with respect to the Euclidean distance. Suppose that G is  $\theta$  everywhere-sparse with  $\theta \leq 1/4^{p+1}$ . Then, for every  $p \geq 1$ , we have the following inequality on the cost of the clusters X and Y:

$$cost_p(X) \le (1 + 3^{p+2}\theta^{1/(p+1)}) cost_p(Y).$$

PROOF. Fix a parameter  $\varepsilon = \theta^{1/(p+1)} \le 1/4$ . Let  $u^*$  be the optimal center for the cluster X. By Theorem 5.2, there exists a point  $v^* \in \mathbb{R}^{d''}$  such that for all but possibly a  $\theta' = 2(1+\varepsilon)^2 \cdot \theta/\varepsilon$  fraction of points x in X we have

$$\|\varphi(x) - v^*\| \le (1 + \varepsilon)\|x - u^*\|.$$

Let  $\widetilde{X}$  be the set of points x for which the inequality above holds. Then,  $|\widetilde{X}| \ge (1 - \theta')|X|$ . Let us place the center of the cluster Y to  $v^*$ . This will give an upper bound on the cost  $cost_{\mathcal{D}}(Y)$ :

<span id="page-7-4"></span>
$$\operatorname{cost}_{p}(Y) \le \sum_{v \in V} \|y - v^*\|^{p} = \sum_{x \in V} \|\varphi(x) - v^*\|^{p}. \tag{23}$$

We now need to estimate the right hand side of (23). For  $x \in \widetilde{X}$ , we already have a bound:  $\|\varphi(x) - v^*\|^p \le (1 + \varepsilon)^p \|x - u^*\|^p$ . We use the following claim to bound  $\|\varphi(x) - v^*\|^p$  for  $x \in X \setminus \widetilde{X}$ .

<span id="page-8-1"></span>Claim 5.4. For all  $x \in X$ , we have

$$\|\varphi(x) - v^*\|^p \leq (1+\varepsilon)^p \|x - u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot \frac{2}{|X|} \sum_{x' \in \widetilde{X}} \|x' - u^*\|^p.$$

PROOF. Fix  $x \in X$ . Let  $I_X$  be the set of its non-neighbors in the distance expansion graph. I.e.,  $x' \in I_X$  if  $\|\varphi(x) - \varphi(x')\| \le \|x - x'\|$ . Since the distance expansion graph is  $\theta$  everywhere sparse, the set  $I_X$  contains at least  $(1 - \theta)|X|$  points and  $I_X \cap \widetilde{X}$  contains at least  $(1 - \theta - \varepsilon)|X|$  points. Consider an arbitrary  $x' \in I_X \cap \widetilde{X}$ . By the triangle inequality, we have

$$\|\varphi(x) - v^*\| \le \|\varphi(x) - \varphi(x')\| + \|\varphi(x') - v^*\|.$$

Now,  $\|\varphi(x) - \varphi(x')\| \le \|x - x'\|$  because  $x' \in I_x$  and  $\|\varphi(x') - v^*\| \le (1 + \varepsilon)\|x' - u^*\|$  because  $x' \in \widetilde{X}$ . Thus,

$$\|\varphi(x) - v^*\| \le \|x - x'\| + (1 + \varepsilon)\|x' - u^*\|.$$

Using the triangle inequality once again, we get

$$\|\varphi(x) - \upsilon^*\| \le (\|x - u^*\| + \|x' - u^*\|) + (1 + \varepsilon)\|x' - u^*\|$$
$$= \|x - u^*\| + (2 + \varepsilon)\|x' - u^*\|.$$

By Lemma A.1 applied to the inequality above,

$$\|\varphi(x) - \upsilon^*\|^p \le (1+\varepsilon)^p \|x - u^*\|^p + \left(\frac{1+\varepsilon}{\varepsilon}\right)^{p-1} (2+\varepsilon)^p \|x' - u^*\|^p$$

$$\le (1+\varepsilon)^p \|x - u^*\|^p + \frac{3^p}{c^{p-1}} \|x' - u^*\|^p, \tag{24}$$

here we used that  $(1 + \varepsilon)(2 + \varepsilon) < 3$  for  $\varepsilon \le 1/4$ .

We now average (24) over all  $x' \in I_X \cap \widetilde{X}$  and use the bound  $|I_X \cap \widetilde{X}| \ge (1 - \varepsilon - \theta)|X| \ge |X|/2$ :

$$\begin{split} \|\varphi(x)-v^*\|^p &\leq (1+\varepsilon)^p \|x-u^*\|^p + \\ &\frac{3^p}{\varepsilon^{p-1}} \frac{1}{|I_x \cap \widetilde{X}|} \sum_{x' \in I_x \cap \widetilde{X}} \|x'-u^*\|^p \\ &\leq (1+\varepsilon)^p \|x-u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot \frac{2}{|X|} \sum_{x' \in \widetilde{X}} \|x'-u^*\|^p. \end{split}$$

This concludes the proof of Claim 5.4.

We now split the right hand side of (23) into two sums:

$$cost_{p}(Y) \leq \sum_{x \in X} \|\varphi(x) - v^{*}\|^{p} 
= \sum_{x \in \widetilde{X}} \|\varphi(x) - v^{*}\|^{p} + \sum_{x \in X \setminus \widetilde{X}} \|\varphi(x) - v^{*}\|^{p}.$$
(25)

Write

$$\sum_{x \in \widetilde{X}} \|\varphi(x) - v^*\|^p \leq (1+\varepsilon)^p \sum_{x \in \widetilde{X}} \|x - u^*\|^p,$$

$$\begin{split} &\sum_{x \in X \setminus \widetilde{X}} \|\varphi(x) - \upsilon^*\|^p \\ &\leq (1 + \varepsilon)^p \sum_{x \in X \setminus \widetilde{X}} \|x - u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot \frac{2}{|X|} \sum_{\substack{x \in X \setminus \widetilde{X} \\ x' \in \widetilde{X}}} \|x' - u^*\|^p \\ &= (1 + \varepsilon)^p \sum_{x \in X \setminus \widetilde{X}} \|x - u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot \frac{2|X \setminus \widetilde{X}|}{|X|} \sum_{x' \in \widetilde{X}} \|x' - u^*\|^p \\ &\leq (1 + \varepsilon)^p \sum_{\substack{x \in X \setminus \widetilde{X} \\ x' \in \widetilde{X}}} \|x - u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot 2\theta' \sum_{\substack{x' \in \widetilde{X} \\ x' \in \widetilde{X}}} \|x' - u^*\|^p. \end{split}$$

Here we used that  $|X \setminus \overline{X}| \le \theta' |X|$ . We now have bounds for the both terms in the right hand side of inequality (25). We plug them in and obtain the following upper bound on  $\cos t_p(Y)$ :

$$\begin{aligned} \cosh_p(Y) &\leq (1+\varepsilon)^p \sum_{x \in X} \|x - u^*\|^p + \frac{3^p}{\varepsilon^{p-1}} \cdot 2\theta' \sum_{x' \in \widetilde{X}} \|x' - u^*\|^p \\ &\leq \left( (1+\varepsilon)^p + \frac{2\theta' \cdot 3^p}{\varepsilon^{p-1}} \right) \cosh_p(X). \end{aligned}$$

Observe that  $(1 + \varepsilon)^p \le 1 + p(1 + \varepsilon)^{p-1}\varepsilon < 1 + 3^p\varepsilon$  and

$$\frac{2\theta'\cdot 3^p}{\varepsilon^{p-1}} = \frac{4\theta(1+\varepsilon)^2\cdot 3^p}{\varepsilon^p} = 4(1+\varepsilon)^2\cdot 3^p\varepsilon \leq 7\cdot 3^p\varepsilon.$$

Therefore,

$$cost_p(Y) \le (1 + 3^{p+2}\varepsilon) cost_p(X).$$

#### 5.1 Proof of Theorem 5.2

<span id="page-8-0"></span>We prove Theorem 5.2 using a duality argument. Fix a positive  $\varepsilon$ ; and denote the size of X by n. Let  $\eta = (\theta'(\varepsilon)n)^{-1}$ . Consider the following convex polytope:

$$\Lambda_{\eta} = \{ \lambda \in \mathbb{R}^X : \sum_{x \in X} \lambda_x = 1; \lambda_{x'} \le \eta \text{ for all } x' \in X \}.$$

For every  $\lambda \in \Lambda_{\eta}$ ,  $u' \in \mathbb{R}^{d'}$ , and  $v' \in \mathbb{R}^{d''}$ , let

$$f(X, \lambda, u') = \sum_{x \in X} \lambda_x ||u' - x||^2, \text{ and}$$

$$f(\varphi(X), \lambda, v') = \sum_{x \in X} \lambda_x ||v' - \varphi(x)||^2.$$
(26)

<span id="page-8-3"></span>

That is,  $f(X, \lambda, u')$  is the cost of a single cluster X with a center in u' according to the weighted k-means objective. The weight of a point  $x \in X$  is  $\lambda_X$ . Similarly,  $f(\varphi(X), \lambda, v')$  is the cost of the cluster  $\varphi(X)$  with a center in v'. The optimal centers for clusters X and  $\varphi(X)$  are located at the centers of mass of X and  $\varphi(X)$  respectively. Thus, for a given  $\lambda \in \Lambda_\eta$ , X, and  $\varphi$ , the objective functions  $f(X, \lambda, u')$  and  $f(\varphi(X), \lambda, v')$  are minimized when  $u' = \sum_X \lambda_X x$  and  $v' = \sum_X \lambda_X \varphi(x)$ . Consequently (see Section B for details),

<span id="page-8-5"></span><span id="page-8-4"></span><span id="page-8-2"></span>
$$\min_{u' \in \mathbb{R}^{d'}} f(X, \lambda, u') = \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \|x' - x''\|^2; \text{ and } (27)$$

$$\min_{v' \in \mathbb{R}^{d''}} f(\varphi(X), \lambda, v') = \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \|\varphi(x') - \varphi(x'')\|^2, \quad (28)$$

where *P* is the set of all *unordered* pairs (x', x'') with  $x', x'' \in X$ .

STOC '19, June 23-26, 2019, Phoenix, AZ, USA

Let  $F(v', \lambda) = (1 + \varepsilon)^2 f(X, \lambda, u) - f(\varphi(X), \lambda, v')$ . Our goal is to show that

<span id="page-9-0"></span>
$$\max_{v' \in \mathbb{R}^{d''}} \min_{\lambda \in \Lambda_{\eta}} F(v', \lambda) \ge 0.$$
 (29)

<span id="page-9-3"></span>LEMMA 5.5. Inequality (29) holds

PROOF. Observe that functions  $f(X, \lambda, u)$  and  $f(\varphi(X), \lambda, v)$  are linear in  $\lambda$  for fixed u and v and convex in u and v respectively for a fixed  $\lambda$  (see (26)). Hence,  $v' \mapsto F(v', \lambda)$  is a concave function for every  $\lambda$ ; and  $\lambda \mapsto F(v', \lambda)$  is a linear function for every v'. Therefore, by the von Neumann minimax theorem, we have

$$\max_{\upsilon' \in \mathbb{R}^{d''}} \min_{\lambda \in \Lambda_{\eta}} F(\upsilon', \lambda) = \min_{\lambda \in \Lambda_{\eta}} \max_{\upsilon' \in \mathbb{R}^{d''}} F(\upsilon', \lambda).$$

Thus, it suffices to prove that  $\max_{v' \in \mathbb{R}^{d''}} F(v', \lambda) \geq 0$  for all  $\lambda \in \Lambda_n$ . Fix  $\lambda \in \Lambda_n$ . Then,

$$\begin{aligned} \max_{v' \in R^{d''}} F(v', \lambda) &= \max_{v' \in R^{d''}} (1 + \varepsilon)^2 f(X, \lambda, u) - f(\varphi(X), \lambda, v') \\ &= (1 + \varepsilon)^2 f(X, \lambda, u) - \min_{v' \in R^{d''}} f(\varphi(X), \lambda, v') \\ &\geq \min_{u' \in R^{d''}} (1 + \varepsilon)^2 f(X, \lambda, u') - \min_{v' \in R^{d''}} f(\varphi(X), \lambda, v'). \end{aligned}$$

Using formulae (27) and (28) for the minimum of the function f,

$$\begin{split} \max_{v' \in R^{d''}} F(v', \lambda) &\geq (1 + \varepsilon)^2 \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \|x' - x''\|^2 \\ &- \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \|\varphi(x') - \varphi(x'')\|^2 \\ &= \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \Big[ (1 + \varepsilon)^2 \|x' - x''\|^2 - \|\varphi(x') - \varphi(x'')\|^2 \Big]. \end{split}$$

We now split the sum on the right hand side into two parts: the sum over pairs  $(x', x'') \in E$  and pairs  $(x', x'') \notin E$ . Then, we upper bound each term in each of the sums. For  $(x', x'') \in E$ , we use a

$$(1+\varepsilon)^2 \|x'-x''\|^2 - \|\varphi(x')-\varphi(x'')\|^2 \ge -\|\varphi(x')-\varphi(x'')\|^2.$$

For  $(x', x'') \notin E$ , we have  $||x' - x''||^2 \ge ||\varphi(x') - \varphi(x'')||^2$  by the definition of the distance expansion graph, and hence

$$(1+\varepsilon)^2 \|x' - x''\|^2 - \|\varphi(x') - \varphi(x'')\|^2 \ge ((1+\varepsilon)^2 - 1) \|\varphi(x') - \varphi(x'')\|^2.$$

Denote  $\varepsilon' = (1 + \varepsilon)^2 - 1$ . We obtain the following bound:

$$\max_{v' \in R^{d''}} F(v', \lambda) \ge \varepsilon' \sum_{(x', x'') \in P \setminus E} \lambda_{x'} \lambda_{x''} \| \varphi(x')$$

$$- \varphi(x'') \|^{2} - \sum_{(x', x'') \in E} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^{2}$$

$$= \varepsilon' \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^{2}$$

$$- (1 + \varepsilon') \sum_{(x', x'') \in E} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^{2}.$$
(30)

We estimate the second sum using the following claim.

<span id="page-9-1"></span>CLAIM 5.6. For all  $x', x'' \in X$  and  $\lambda \in \Lambda_n$ , we have

$$\|\varphi(x')-\varphi(x'')\|^2 \leq 2\sum_{x\in X}\lambda_x\|\varphi(x)-\varphi(x')\|^2 + \lambda_x\|\varphi(x)-\varphi(x'')\|^2.$$

Konstantin Makarychev, Yury Makarychev, and Ilya Razenshteyn

Proof. The desired inequality is the convex combination of the relaxed triangle inequalities for squared Euclidean distances (see Corollary A.2):

$$\|\varphi(x') - \varphi(x'')\|^2 \le 2 \Big[ \|\varphi(x) - \varphi(x')\|^2 + \|\varphi(x) - \varphi(x'')\|^2 \Big]$$
 with weights  $\lambda_x$ . Note that  $\sum_{x \in X} \lambda_x = 1$  for each  $\lambda \in \Lambda_\eta$ .

$$\begin{split} & \sum_{(x', x'') \in E} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^2 \le \\ & 2 \sum_{(x', x'') \in E} \lambda_{x'} \lambda_{x''} \sum_{x \in X} \left( \lambda_x \| \varphi(x) - \varphi(x') \|^2 + \lambda_x \| \varphi(x) - \varphi(x'') \|^2 \right) \\ & = 2 \sum_{x, x' \in X} \left[ \sum_{x'': (x', x'') \in E} \lambda_{x''} \right] \lambda_x \lambda_{x'} \| \varphi(x) - \varphi(x') \|^2. \end{split}$$

Since the degree of every vertex x' in the distance expansion graph is at most  $\theta n$  and each  $\lambda_{x''} \leq \eta$ , we have  $\left[\sum_{x'':(x',x'')\in E} \lambda_{x''}\right] \leq \theta \eta n$ . Therefore,

$$\begin{split} \sum_{(x', \, x'') \in E} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^2 \\ & \leq 2 \theta \eta n \sum_{x, x' \in X} \lambda_x \lambda_{x'} \| \varphi(x) - \varphi(x') \|^2 \\ & = 4 \theta \eta n \sum_{(x', \, x'') \in P} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^2. \end{split}$$

Note that  $4\theta \eta n = 2\varepsilon/(1+\varepsilon)^2 < \varepsilon'/(1+\varepsilon')$ . We plug in the bound above in Equation (30) and obtain the desired inequality:

$$\begin{split} \max_{v' \in R^{d''}} F(v', \lambda) &\geq \varepsilon' \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^2 \\ &- \frac{(1 + \varepsilon') \cdot \varepsilon'}{1 + \varepsilon'} \sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \| \varphi(x') - \varphi(x'') \|^2 = 0. \end{split}$$

Let v be the point that maximizes the functional  $\min_{\lambda \in \Lambda_n} F(v, \lambda)$ . By Lemma 5.5,  $\min_{\lambda \in \Lambda_n} F(v, \lambda) \ge 0$  or, in other words,  $F(v, \lambda) \ge 0$ for all  $\lambda \in \Lambda_{\eta}$ . Consider the set  $S = \{x \in X : ||\varphi(x) - v|| >$  $(1 + \varepsilon) ||x - u||$ . If  $S = \emptyset$  then we are done. Otherwise, define a vector  $\lambda^*$  as follows

$$\lambda_x^* = \begin{cases} 1/|S|, & \text{if } x \in S\\ 0, & \text{otherwise} \end{cases}$$

<span id="page-9-2"></span>Note that  $(1 + \varepsilon)^2 ||x - u||^2 - ||\varphi(x) - v||^2$  is negative for all  $x \in S$ (by the definition of *S*). Hence,

$$F(v, \lambda^*) = \frac{1}{|S|} \sum_{x \in S} (1 + \varepsilon)^2 ||x - u||^2 - ||\varphi(x) - v||^2 < 0$$

and, consequently,  $\lambda^* \notin \Lambda_{\eta}$ . Therefore,  $1/|S| > \eta$  (otherwise,  $\lambda^*$ would belong to  $\Lambda_{\eta}$ ) and  $|S| < 1/\eta = \theta'(\varepsilon)n$ . This finishes the proof of Theorem 5.2 since for all  $x \notin S$ , we have  $\|\varphi(x) - v\| \le$ 

Proof of Theorem 3.3. Let  $X = \tilde{C}$  and  $Y = \varphi(\tilde{C})$ . We apply Lemma 5.3 to maps  $(1 + \varepsilon)\varphi$  and  $(1 + \varepsilon)\varphi^{-1}$  and get the desired

# A INEQUALITY FOR THE SUM OF *p*-TH POWERS

<span id="page-10-2"></span>LEMMA A.1. Let x and  $y_1, \ldots, y_r$  be non-negative real numbers, and  $\varepsilon > 0$ ,  $p \ge 1$ . Then

$$\left(x + \sum_{i=1}^r y_i\right)^p \le (1 + \varepsilon)^{p-1} x^p + \left(\frac{(1 + \varepsilon)r}{\varepsilon}\right)^{p-1} \sum_{i=1}^r y_i^p.$$

PROOF. Let  $t = \frac{1}{1+\varepsilon}$ . Write,

$$\left(x + \sum_{i=1}^{r} y_i\right)^p = \frac{1}{t^p} \left(tx + \sum_{i=1}^{r} \frac{1-t}{r} \left(\frac{r t y_i}{1-t}\right)\right)^p.$$

The expression in the parentheses on the right is a convex combination of numbers  $x, \frac{rty_1}{1-t}, \ldots, \frac{rty_r}{1-t}$  with coefficients  $t, \frac{1-t}{r}, \ldots, \frac{1-t}{r}$  (which add up to 1). Applying Jensen's inequality, we get

$$\frac{1}{t^p} \left( tx + \sum_{i=1}^r \frac{1-t}{r} \left( \frac{r \, t \, y_i}{1-t} \right) \right)^p \le \frac{tx^p}{t^p} + \frac{1-t}{r \, t^p} \sum_{i=1}^r \left( \frac{r \, t \, y_i}{1-t} \right)^p$$

$$= (1+\varepsilon)^{p-1} x^p + \left( \frac{(1+\varepsilon)r}{\varepsilon} \right)^{p-1} \sum_{i=1}^r y_i^p.$$

<span id="page-10-4"></span>Corollary A.2 (Relaxed triangle inequalities). For any vectors u,v,w and numbers  $\varepsilon>0,p\geq 1$ , we have

 $\|u-w\|^p \leq (1+\varepsilon)\|u-v\|^p + \left(\frac{(1+\varepsilon)}{\varepsilon}\right)^{p-1}\|v-w\|^p.$ 

2.

$$||u - w||^2 \le 2||u - v||^2 + 2||v - w||^2$$
.

PROOF. Using Lemma A.1, we get  $\|u-w\|^p \le (\|u-v\|+2\|v-w\|)^p \le (1+\varepsilon)\|u-v\|^p + \left(\frac{(1+\varepsilon)}{\varepsilon}\right)^{p-1}\|v-w\|^p$ . Item 2 is a special case of this inequality with  $\varepsilon=1$  and p=2.

# <span id="page-10-3"></span>B CLOSED-FORM EXPRESSION FOR THE COST OF A CLUSTER

In this section, we derive a well known formula (27) for computing the cost of a cluster with respect to the k-means objective. The optimal center of the cluster formed by points in set X with weights  $\lambda_X$  is located in the center of mass of X. Let a and b be i.i.d random variables such as  $\Pr(a = x) = \Pr(b = x) = \lambda_X$ . Then, the cost of the cluster X equals  $\mathbb{E}[(a - \mathbb{E}a)^2] = \operatorname{Var}[a]$  and

$$\sum_{(x', x'') \in P} \lambda_{x'} \lambda_{x''} \|x' - x''\|^2 = \frac{1}{2} \sum_{(x', x'') \in X \times X} \lambda_{x'} \lambda_{x''} \|x' - x''\|^2$$
$$= \frac{1}{2} \mathbb{E} \|a - b\|^2 = \mathbb{E} a^2 - (\mathbb{E} a)^2 = \text{Var}[a].$$

# C SUB-GAUSSIAN TAILED DIMENSION REDUCTION

In this section, first we prove that every sub-Gaussian tailed dimension reduction is standard. Then we show that the Gaussian dimension reduction is sub-Gaussian tailed. <span id="page-10-0"></span>LEMMA C.1. Let  $\varepsilon < 1/2$ . Assume that a family of random maps  $\pi_{m,d} : \mathbb{R}^m \to \mathbb{R}^d$  satisfies the condition of Theorem 1.1 and is sub-Gaussian tailed (satisfies Definition 1.2). Then  $\pi_{m,d}$  is a standard dimension reduction (see Definition 2.1).

PROOF. Denote the parameters of dimension reduction  $\pi_{m,d}$  by  $(\varepsilon, \delta, \rho)$ . Since  $\pi_{m,d}$  satisfies the condition of Theorem 1.1,  $\delta \le \exp(-c\varepsilon^2 d)$  for some c.

Let u be a unit vector in  $\mathbb{R}^m$  and  $\xi = ||\pi(u)|| - 1$ . Since  $\pi_{m,d}$  is sub-Gaussian tailed,  $\Pr(\xi > t) \le \exp(-ct^2d)$  for some c. We assume that  $d \ge c(p-1)/\varepsilon^2$ . We have,

$$\mathbb{E}\left[1\left\{\left\{\left\|\pi(u)\right\| > (1+\varepsilon)\|u\|\right\}\right\} \left(\frac{\|\pi(u)\|^p}{\|u\|^p} - (1+\varepsilon)^p\right)\right]$$

$$= \mathbb{E}\left[1\left\{\xi > \varepsilon\right\} \left((1+\xi)^p - (1+\varepsilon)^p\right)\right]$$

$$= \int_{\varepsilon}^{\infty} \left((1+t)^p - (1+\varepsilon)^p\right) d\Pr\left(\xi \le t\right)$$

$$= \int_{\varepsilon}^{\infty} p(1+t)^{p-1} \Pr\left(\xi > t\right) dt$$

$$\le \int_{\varepsilon}^{\infty} p(1+t)^{p-1} e^{-ct^2 d} dt$$

$$= \int_{\varepsilon}^{\infty} (p(1+t)^{p-1} e^{-ct^2 d/2}) e^{-ct^2 d/2} dt$$

By differentiating  $g(t)=p(1+t)^{p-1}e^{-ct^2d/2}$  by t, we get that g'(t) is decreasing when  $t(1+t)\geq \frac{p-1}{cd}$ . Since  $d\geq \frac{c(p-1)}{\varepsilon^2}$ , g(t) attains its maximum on  $[\varepsilon,\infty)$  when  $t=\varepsilon$ . We have

$$g(t) \leq p(1+\varepsilon)^{p-1} e^{-c\varepsilon^2 d/2} \leq e^{-(p-1)/\varepsilon^2 + \ln p + (p-1)\ln(1+\varepsilon)} \leq 1$$

(here, we used that  $\varepsilon \le 1/2$  and  $d \ge c(p-1)/\varepsilon^2$ . Therefore,

$$\begin{split} \mathbb{E}\left[\mathbf{1}\left\{\xi>\varepsilon\right\}\left((1+\xi)^p-(1+\varepsilon)^p\right)\right] &\leq \int_{\varepsilon}^{\infty}e^{-ct^2d/2}dt\\ &\leq \int_{\varepsilon}^{\infty}\frac{t}{\varepsilon}\,e^{-ct^2d/2}dt\\ &= \frac{1}{cd\varepsilon}\int_{\varepsilon^2/2}^{\infty}e^{-cds}ds = \frac{1}{cd\varepsilon}e^{-cd\varepsilon^2/2} < e^{-cd\varepsilon^2/2}. \end{split}$$

Consider a  $d \times m$  matrix G whose entries are i.i.d. Gaussian random variables  $\mathcal{N}(0, 1)$ . Matrix G defines a linear dimension reduction  $\pi(u) = \frac{Gu}{\sqrt{d}}$  [IM98].

<span id="page-10-1"></span>CLAIM C.2. The Gaussian dimension reduction  $\pi$  (defined above) is sub-Gaussian tailed.

PROOF. Let u be a unit vector in  $\mathbb{R}^m$ ,  $\xi = \|\pi(u)\| - 1$  and  $\eta = \sqrt{d}(\xi+1) = \sqrt{d}\|\pi(u)\|$ . Note that  $\eta^2$  has the  $\chi^2$ -distribution with d degrees of freedom. As was shown by Laurent and Massart [LM00, Lemma 1, Inequality (4.3)],  $\Pr\left(\eta^2 - d \ge 2\sqrt{d \cdot x} + 2x\right) \le e^{-x}$  for

1037

<span id="page-11-0"></span>any positive x. Plugging in  $x = t^2 d/2$  (where t > 0), we get

$$\begin{split} \Pr\left(\xi \geq t\right) &= \Pr\left(\left(\xi + 1\right)^2 \geq 1 + 2t + t^2\right) \\ &\leq \Pr\left(\left(\xi + 1\right)^2 - 1 \geq \sqrt{2}t + t^2\right) \\ &= \Pr\left(\eta^2 - d \geq 2\sqrt{dx} + 2x\right) \\ &\leq e^{-x} = e^{-t^2d/2}. \end{split}$$

#### **ACKNOWLEDGMENTS**

We thank Jerry Li and Jelani Nelson for useful discussions.

#### REFERENCES

<span id="page-11-17"></span>[AC06] Nir Ailon and Bernard Chazelle. Approximate nearest neighbors and the fast Johnson–Lindenstrauss transform. In Proceedings of the Symposium on Theory of Computing, pages 557–563, 2006.

- <span id="page-11-13"></span>[Ach03] Dimitris Achlioptas. Database-friendly random projections: Johnson– Lindenstrauss with binary coins. Journal of Computer and System Sciences, 66(4):671–687, 2003.
- <span id="page-11-18"></span>[AL09] Nir Ailon and Edo Liberty. Fast dimension reduction using Rademacher series on dual BCH codes. *Discrete & Computational Geometry*, 42(4):615, 2000
- <span id="page-11-20"></span>[AL13] Nir Ailon and Edo Liberty. An almost optimal unrestricted fast Johnson– Lindenstrauss transform. ACM Transactions on Algorithms (TALG), 9(3):21, 2013.
- <span id="page-11-9"></span>[Alo03] Noga Alon. Problems and results in extremal combinatorics-I. Discrete Mathematics, 273(1-3):31–53, 2003.
- <span id="page-11-30"></span>[BBCA+19] Luca Becchetti, Marc Bury, Vincent Cohen-Addad, Fabrizio Grandoni, and Chris Schwiegelshohn. Oblivious dimension reduction for k-means – beyond subspaces and the Johnson-Lindenstrauss lemma. In Proceedings of the Symposium on Theory of Computing, 2019.
- <span id="page-11-24"></span>[BDM09] Christos Boutsidis, Petros Drineas, and Michael W Mahoney. Unsupervised feature selection for the k-means clustering problem. In Advances in Neural Information Processing Systems, pages 153–161, 2009.
- <span id="page-11-26"></span>[BMI13] Christos Boutsidis and Malik Magdon-Ismail. Deterministic feature selection for k-means clustering. IEEE Transactions on Information Theory, 59(9):6099–6110, 2013.
- <span id="page-11-5"></span>[BZD10] Christos Boutsidis, Anastasios Zouzias, and Petros Drineas. Random projections for k-means clustering. In Advances in Neural Information Processing Systems, pages 298–306, 2010.
- <span id="page-11-27"></span>[BZMD15] Christos Boutsidis, Anastasios Zouzias, Michael W Mahoney, and Petros Drineas. Randomized dimensionality reduction for k-means clustering. IEEE Transactions on Information Theory, 61(2):1045–1062, 2015.
- <span id="page-11-6"></span>[CEM<sup>+</sup>15] Michael B Cohen, Sam Elder, Cameron Musco, Christopher Musco, and Madalina Persu. Dimensionality reduction for k-means clustering and low rank approximation. In Proceedings of the Symposium on Theory of Computing, pages 163–172, 2015.
- <span id="page-11-22"></span>[DFK+99] Petros Drineas, Alan M Frieze, Ravi Kannan, Santosh Vempala, and V Vinay. Clustering in large graphs and matrices. In Proceedings of the Symposium on Discrete Algorithms, pages 291–299, 1999.

<span id="page-11-11"></span>[DG03] Sanjoy Dasgupta and Anupam Gupta. An elementary proof of a theorem of Johnson and Lindenstrauss. Random Structures & Algorithms, 22(1):60– 65, 2003.

- <span id="page-11-15"></span>[DKS10] Anirban Dasgupta, Ravi Kumar, and Tamás Sarlós. A sparse Johnson– Lindenstrauss transform. In Proceedings of the Symposium on Theory of Computing, pages 341–350, 2010.
- <span id="page-11-3"></span>[Far90] Nariman Farvardin. A study of vector quantization for noisy channels. IEEE Transactions on Information Theory, 36(4):799-809, 1990.
- <span id="page-11-25"></span>[FSS13] Dan Feldman, Melanie Schmidt, and Christian Sohler. Turning big data into tiny data: Constant-size coresets for k-means, pca and projective clustering. In Proceedings of the Symposium on Discrete Algorithms, pages 1434–1453, 2013.
- <span id="page-11-12"></span>[IM98] Piotr Indyk and Rajeev Motwani. Approximate nearest neighbors: towards removing the curse of dimensionality. In Proceedings of the Symposium on Theory of Computing, pages 604–613, 1998.
- <span id="page-11-2"></span>[Jai10] Anil K Jain. Data clustering: 50 years beyond k-means. Pattern recognition letters, 31(8):651–666, 2010.
- <span id="page-11-4"></span>[JDS11] Herve Jegou, Matthijs Douze, and Cordelia Schmid. Product quantization for nearest neighbor search. IEEE Transactions on Pattern Analysis and Machine Intelligence, 33(1):117-128, 2011.
- <span id="page-11-8"></span>Machine Intelligence, 33(1):117–128, 2011.

  William Johnson and Joram Lindenstrauss. Extensions of Lipschitz mappings into a Hilbert space. In Conference in modern analysis and probability (New Haven, Connecticut, 1982), volume 26 of Contemporary Mathematics, pages 189–206. 1984.
- <span id="page-11-28"></span>[Kan18] Ravi Kannan. Intro and foundations of data science I. Tutorial at Simons Institute, 2018. Available at https://www.youtube.com/watch?v=9GMT3FnQTGM.
- <span id="page-11-31"></span>[Kir34] M Kirszbraun. Über die zusammenziehende und lipschitzsche transformationen. Fundamenta Mathematicae, 22(1):77–108, 1934.
- <span id="page-11-14"></span>[KM+05] B Klartag, Shahar Mendelson, et al. Empirical processes and random projections. Journal of Functional Analysis, 225(1):229, 2005.
- <span id="page-11-16"></span>[KN14] Daniel M Kane and Jelani Nelson. Sparser Johnson-Lindenstrauss transforms. Journal of the ACM, 61(1):4, 2014.
- <span id="page-11-19"></span>[KW11] Felix Krahmer and Rachel Ward. New and improved Johnson– Lindenstrauss embeddings via the restricted isometry property. SIAM Journal on Mathematical Analysis, 43(3):1269–1281, 2011.
- <span id="page-11-1"></span>[Llo82] Stuart Lloyd. Least squares quantization in PCM. IEEE Transactions on Information Theory, 28(2):129–137, 1982.
- <span id="page-11-32"></span>[LM00] Beatrice Laurent and Pascal Massart. Adaptive estimation of a quadratic functional by model selection. Annals of Statistics, pages 1302–1338, 2000.
- <span id="page-11-10"></span>[LN17] Kasper Green Larsen and Jelani Nelson. Optimality of the Johnson– Lindenstrauss lemma. In Symposium on Foundations of Computer Science, pages 633–638. IEEE, 2017.
- <span id="page-11-7"></span>[Nao18] Assaf Naor. Metric dimension reduction: A snapshot of the Ribe program. arXiv preprint arXiv:1809.02376, 2018.
- <span id="page-11-21"></span>[NPW14] Jelani Nelson, Eric Price, and Mary Wootters. New constructions of RIP matrices with fast multiplication and fewer rows. In Proceedings of the Symposium on Discrete Algorithms, pages 1515–1528, 2014.
- <span id="page-11-23"></span>[Sar06] Tamas Sarlos. Improved approximation algorithms for large matrices via random projections. In Proceedings of the Foundations of Computer Science, pages 143–152, 2006.
- <span id="page-11-29"></span>[SW18] Christian Sohler and David P Woodruff. Strong coresets for k-median and subspace approximation: Goodbye dimension. In Proceedings of the Foundations of Computer Science, pages 802–813, 2018.