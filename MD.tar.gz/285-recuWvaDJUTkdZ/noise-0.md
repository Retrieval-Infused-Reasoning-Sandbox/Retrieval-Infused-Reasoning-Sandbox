# On the Choice of the Action Function in the New Field Theory

B. HOFFMANN AND L. INFELD The Institute for Advanced Study, Princeton, New Jersey (Received January 4, 1937)

By the imposition of a regularity condition on the new field theory a new action function is found which is unique so far as the significant lower order terms of its expansion are concerned. The new action function leads to a theory in which the  $f_{kl}$  field is free from singularities, from which magnetic poles are automatically excluded, and in which the equations of motion can be deduced from the field equations without extra dynamical assumptions. When general relativity is taken into account the field of a particle is such that space-time is everywhere regular, and the theory leads to the identification of gravitational with electromagnetic mass.

### Introduction

HE new field theory initiated by Born<sup>1</sup> introduces in the classical equations of the electromagnetic field a characteristic length  $r_0$ representing the radius of the elementary particle through the relation

$$r_0 = (e/b)^{\frac{1}{2}},$$

where e is the elementary charge and b the fundamental field strength entering the Lagrangian function.

The considerations of Heisenberg, Euler, and Kockel<sup>2</sup> on the scattering of light by light according to the theory of the positron, and Heisenberg's recent theory of cosmic-ray showers<sup>3</sup> indicate the importance of the introduction of a characteristic length in the early stages of the theory, i.e., in classical physics.

The question is still open as to which of the many conceivable action functions is to be used in the new field theory. It was originally thought that the Lagrangian and corresponding Hamiltonian

$$\mathcal{L} = (1 + F - G^2)^{\frac{1}{2}}, \quad \mathcal{K} = (1 + P - Q^2)^{\frac{1}{2}}, \quad (0.1)$$

where

$$F = \frac{1}{2} f_{kl} f^{kl}, \quad P = \frac{1}{2} p_{kl} p^{*kl}, \tag{0.2}$$

and

$$G = \frac{1}{4} f_{kl} f^{*kl}, \quad O = \frac{1}{4} \phi_{kl} \phi^{*kl}, \quad (0.3)$$

was the simplest choice which would lead to a finite energy for an electric particle. This is,

<sup>3</sup> Heisenberg, Zeits. f. Physik 101, 533 (1936).

however, not the case. It is possible to find an infinite number4 of quite different action functions, each giving simple algebraic relations between the  $f_{kl}$  and  $p_{kl}$  fields and each leading to a finite energy for an electric particle. This lack of uniqueness is not the only objection to the action function used up to now. For this action function gives complete symmetry between the electric and magnetic fields so that to the solution representing an electrical particle corresponds an exactly similar solution for a magnetic particle. Another serious objection to the theory is that the equations of motion are not a consequence of the field equations alone but require the introduction of a special hypothesis whose meaning is obscure.5 This difficulty is connected with the existence of the singularity in the field of the elementary particle. Again, if the theory be treated within the framework of the general theory of relativity, the gravitational potentials are also not regular, with the result that spacetime itself is singular at the "center" of the elementary particle.6

In the present paper we impose as a fundamental condition the requirement that only those solutions have physical significance for which the  $f_{kl}$  functions are everywhere regular. This condition, which we later generalize for the gravitational case, forms a criterion for the choice of the action function, and we show that the action function to which we are actually led

<sup>&</sup>lt;sup>1</sup> Born, Proc. Roy. Soc. A143, 1410 (1934); Born and Infeld, Proc. Roy. Soc. A144, 425 (1934).

Heisenberg and Euler, Zeits. f. Physik 98, 714 (1936); Euler and Kockel, Naturwiss. 23, 246 (1935)

<sup>&</sup>lt;sup>4</sup> Infeld, Proc. Camb. Phil. Soc. 32, 127 (1936), 33, 70

<sup>(1937),</sup> hereinafter referred to, respectively, as I and II.

<sup>6</sup> Frenkel, Proc. Roy. Soc. A146, 933 (1934); Feenberg, Phys. Rev. 47, 148 (1935); Born, Proc. Indian Acad. Sci.

3, 8 (1936) and 3, 85 (1936); Pryce, Proc. Roy. Soc. A155, pp. 1622 (1926)

<sup>6</sup> See § 5 of this paper.

avoids, at least partially, the various difficulties discussed above. Our action function is unique so far as terms of the significant lower orders are concerned, it leads to a regular  $f_{kl}$  field for the fundamental electric particle, it rejects the possibility of isolated magnetic poles, and it allows the derivation of the Lorentz law without extra hypothesis. Further, it leads to a regular gravitational field for the fundamental electric particle, and it shows that its gravitational mass and electromagnetic mass are essentially the same, thus showing that gravitational mass cannot be negative, a result which does not follow from the usual general theory of relativity. Moreover, the present theory preserves the general scheme of the earlier theory with all its inherent advantages.

We divide the paper into two parts. The first part contains all of the work which can be treated within the framework of the special theory of relativity, while the second part discusses those aspects of the work in which the explicit use of the gravitational potentials of the general theory of relativity is essential.

## PART I

## §1. The action function

We assume  $^7$  that our action function T is a function of the two scalar invariants F, P defined by

$$F = \frac{1}{2} f_{kl} f^{kl} = B^2 - E^2;$$

$$P = \frac{1}{2} p^*_{kl} p^{*kl} = D^2 - H^2,$$
(1.1)

where the star denotes the dual tensor and, in the Galilean case,

$$\begin{cases} f^{*14}, f^{*24}, f^{*34} \rightarrow f_{23}, f_{31}, f_{12} \rightarrow \mathbf{B}, \\ f^{*23}, f^{*31}, f^{*12} \rightarrow f_{14}, f_{24}, f_{34} \rightarrow \mathbf{E}, \\ p^{*14}, p^{*24}, p^{*34} \rightarrow p_{23}, p_{31}, p_{12} \rightarrow \mathbf{H}, \\ p^{*23}, p^{*31}, p^{*12} \rightarrow p_{14}, p_{24}, p_{34} \rightarrow \mathbf{D}. \end{cases}$$
(1.2)

The  $f_{kl}$  and  $p_{kl}^*$  are the four-dimensional curls of potential vectors  $\varphi_k$ ,  $\psi_k$ , respectively, and must, therefore, satisfy the integrability

conditions

$$(\partial f^{*kl}/\partial x^l) = 0, \tag{1.3a}$$

$$(\partial p^{kl}/\partial x^l) = 0. \tag{1.3b}$$

We assume that the  $f_{kl}$  and  $p^{kl}$  are canonically conjugate with respect to the action function, and that  $f^{*kl}$  and  $p_{kl}^*$  are similarly conjugate. This means that

$$p^{kl} = (\partial T/\partial f_{kl}) = 2T_E f^{kl}, \qquad (1.4a)$$

$$f^{*kl} = (\partial T/\partial p_{kl}^*) = 2T_P p^{*kl},$$
 (1.4b)

where  $T_F$ ,  $T_P$  denote partial derivatives of T with respect to F and P, respectively. With this assumption of conjugacy the field equations obtained from the action principle

$$\delta \int T dx^1 dx^2 dx^3 dx^4 = 0 \tag{1.5}$$

by variation of the potentials  $\varphi_k$  and  $\psi_k$  are precisely the Eqs. (1.3a), (1.3b).

The Eqs. (1.4a), (1.4b) are twelve equations for determining the six quantities  $p_{kl}$ \* as functions of the six quantities  $f_{kl}$ , or vice versa. They will thus, in general, not be consistent. It is easy to see that if they are to be consistent we must have

$$4T_FT_P = 1.$$
 (1.6)

Also, if we multiply (1.4a), (1.4b), respectively, by  $f_{kl}$  and  $p_{kl}^*$  and add we get

$$T_F F + T_P P = 0.$$
 (1.7)

To satisfy (1.7) we take T to be a homogeneous function of F and P of degree zero. That is, we introduce

$$\epsilon = (-F/P)^{\frac{1}{2}} \tag{1.8}$$

and assume that T is a function of  $\epsilon$ . From (1.7), by applying (1.6), we now obtain

$$2T_F\epsilon = 1, \tag{1.9a}$$

$$2T_P\epsilon^{-1} = 1, \tag{1.9b}$$

where the signs are determined by the convention that the  $f_{kl}$  and  $p_{kl}$  fields shall always have the same direction, in which case  $2T_F$  and  $2T_P$  must always be positive.

From (1.9a), (1.9b) and (1.8) we have

$$T_{\epsilon} = -P$$
, or  $\epsilon^2 T_{\epsilon} = F$ , (1.10)

giving F as a function of P, or vice versa.

<sup>&</sup>lt;sup>7</sup>The general ideas underlying the variational method used in this paper will be found more fully developed in I and II.

![](_page_2_Figure_2.jpeg)

Fig. 1.  $E_x$  plotted against x for  $E_r = 1/(1+r^4)^{\frac{1}{2}}$ .

Having summarized the general theory of the variational principle we use, we must now find a specific form for the T function which will give a field theory free from the difficulties formulated in the introduction.

We regard the  $f_{kl}$  field as fundamental and the  $p_{kl}$  components as functions of the  $f_{kl}$  components in accordance with (1.10). Since P is thus a function of F we may write

$$p^{kl} = \lambda f^{kl}, \tag{1.11}$$

where  $\lambda$  depends on the scalar F only.

The field equations (1.3a), (1.3b) may now be written in the form

$$(\partial f^{*kl}/\partial x^l) = 0$$
,  $(\partial f^{kl}/\partial x^l) = 4\pi \rho^k$ , (1.12)

where  $\rho^k$  is the charge and current density vector and has the form,

$$4\pi \rho^k = -\left(\partial \log \lambda / \partial x^l\right) f^{kl}. \tag{1.13}$$

The Eqs. (1.12) are formally the same as those of the Lorentz theory. The difference lies in the fact that the  $\rho^k$  are functions of the  $f_{kl}$  field. The conservation law of the current density vector follows at once from (1.12) because of the antisymmetric character of  $f^{kl}$ :

$$4\pi(\partial \rho^k/\partial x^k) = (\partial^2 f^{kl}/\partial x^l \partial x^k) = 0.$$
 (1.14)

In a pure field theory the field equations must be well defined for every point of space-time since whenever the field equations are undefined extra conditions must be introduced to take the place of the defaulting equations in the singular domain.

We are thus led to the following regularity condition for the present case:

Only those solutions of (1.12) may have physical meaning for which the functions  $f_{kl}$  and their first derivatives exist everywhere.

We shall now show that this regularity condition restricts the possibilities for the action function T and allows us ultimately to determine the essential terms in its expansion uniquely, thus removing the arbitrariness in the choice of the action function which has hitherto existed.

In order to find the action function we must discuss the character of a spherically symmetric electrostatic solution. In the previous theory  $f_{kl}$ was not everywhere continuous, for in that theory we had for this case, in natural units,

$$D_r = 1/r^2$$
;  $E_r = 1/(1+r^4)^{\frac{1}{2}}$ ; (1.15)

thus  $E_x$  changes from (+1) to (-1) on passing through the "center" of the particle, r=0, as shown in Fig. 1. It is evident that any finite value for  $E_r$  at r=0 will lead to a discontinuity of this type. Therefore it is essential that in the spherically symmetric electrostatic case  $E_r$  shall vanish for r=0:

For 
$$r \rightarrow 0$$
;  $E_r \rightarrow 0 \sim r^n$ ;  $\epsilon \equiv E_r/D_r \rightarrow r^{2+n}$ ,  $n > 0$ . (1.16)

The condition (1.16), which is an expression of the regularity condition, concerns the behavior of the field as  $r\rightarrow 0$ . We impose the further condition that for large r the field shall become Maxwellian. This gives, by (1.10)

For 
$$r \to \infty$$
;  $D_r \to E_r \to r^{-2} \to 0$ ;  
 $\epsilon \to 1$ ;  $T_{\epsilon} \to 0$ ;  $T \to 0.9$  (1.17)

From (1.16) we have

For 
$$r \rightarrow 0$$
;  $P \rightarrow r^{-4}$ ;  $1/\epsilon \rightarrow r^{-(2+n)}$ ,  $n > 0$ .

Thus if  $T_{\epsilon}$  can be expanded in a power series in  $\epsilon$  it follows from (1.10) that the lowest term must contain  $(1/\epsilon)$ . We therefore assume

$$-P = T_{\epsilon} = -1/\epsilon + \alpha + \cdots, \qquad (1.18)$$

where  $\alpha$  is a constant. On integrating we find

$$T = k + \alpha \epsilon - \log \epsilon + \cdots, \qquad (1.19)$$

where k is a constant of integration.

<sup>&</sup>lt;sup>8</sup> Born, Infeld, reference 1, §6. <sup>9</sup> For this last see I, p. 132, § 6. This result can also be obtained from Eq. (3.7) of this paper since in the Maxwell case  $T_s^s$  is known to be zero.

The values of  $\alpha$  and k can be determined from the application of (1.17) to (1.18) and (1.19) if we neglect the higher order terms in  $\epsilon$ :

$$\alpha = 1, \quad k = -1.$$

Thus, if we consider only the lower order terms of the expansion of T we may take

$$T = \epsilon - \log \epsilon + 1. \tag{1.20}$$

This is the form we shall use for the action function in the present work. Although we have neglected expressions of order  $\epsilon^2$  in (1.19) we see that every field theory avoiding discontinuities must have essentially the same features as the one here formulated.<sup>10</sup>

From (1.10) and (1.20) we find, as the connection between F and P,

$$(-P/F)^{\frac{1}{2}} = 1 + P,$$
 (1.21)

$$-P/(1+P)^2 = F, (1.22)$$

and thus, because of (1.11),

$$f_{kl} = p_{kl}/(1+P),$$
 (1.23)

$$p_{kl} = \frac{-1 \pm (1 + 4F)^{\frac{1}{2}}}{2F} f_{kl}.$$
 (1.24)

The sign to be used in (1.24) is determined from the following considerations:

For F < 0 and  $f_{kl} \rightarrow 0$  we have

 $p_{kl} \rightarrow \infty$  if the minus sign is taken before the square root,

 $p_{kl} \rightarrow 0$  if the plus sign is taken before the square root.

For F>0 only the plus sign may be taken since only in this case will  $f_{kl}$  and  $p_{kl}$  have the same direction. For  $f_{kl}\rightarrow 0$  we always have  $p_{kl}\rightarrow 0$  in this case.

From (1.24), since  $p_{kl}$  is real, it is seen that the smallest value for F is given by

$$1+4F=0$$
, or  $F=-\frac{1}{4}$ . (1.25)

The Eq. (1.25) defines a surface, in general. If real charges exist, i.e., if (1.3b) breaks down at certain points, the minus sign must be taken inside the surface and the plus sign outside.

$$\mathfrak{IC} = \frac{1}{2} \log (1+P).$$

On the surface itself, of course, the square root vanishes. The existence of regions in which the minus sign has to be taken before the square root is directly connected with the existence of charges. The extrema for F exist whenever there are charged particles. This is a general consequence of the fact that F must be zero both at the center of the particle, where  $P \rightarrow \infty$ , and at large distances, where  $P \rightarrow 0$ .

# §2. The spherically symmetric electrostatic case

In the spherically symmetric electrostatic case we have  $\mathbf{B} = \mathbf{H} = 0$ , and the field equations take the form

$$\operatorname{curl} \mathbf{E} = 0, \tag{2.1}$$

$$\mathbf{div} \ \mathbf{D} = 0. \tag{2.2}$$

We have to replace  $\mathbf{D}$  in (2.2) by its value as a function of  $\mathbf{E}$ . Eqs. (1.23) and (1.24) give as the relation between the radial components of  $\mathbf{E}$  and  $\mathbf{D}$ ,

$$E_r = D_r / (1 + D_r^2), (2.3)$$

$$D_r = \frac{-1 \pm (1 - 4E_r^2)^{\frac{1}{2}}}{2E_r^2} E_r = \lambda E_r, \qquad (2.4)$$

where the minus sign must be used inside the sphere  $E_r = \frac{1}{2}$  and the plus sign outside.

Eqs. (2.1) are identically fulfilled since  $E_r$  is a function of r alone.

Eq. (2.2) can be written as

$$\operatorname{div} \mathbf{E} = -\frac{\partial \log \lambda}{\partial r} E_r = 4\pi \rho, \qquad (2.5)$$

where  $\rho$  is the free charge density, defined as a function of  $E_r$ . The solution of (2.5) is

$$E_r = r^2/(1+r^4),$$
 (2.6)

as we can easily deduce by inserting for  $D_r$  in (2.3) its value  $r^{-2}$ . Thus the field strength vanishes for r=0 as shown in Fig. 2, and its derivative of the first order exists everywhere. It has a maximum where r=1, exactly corresponding to the sphere given by  $(1+4F)^{\frac{1}{2}}=0$ . From (2.6) and (2.5) we find that the free charge density is given by

$$\rho = \frac{1}{\pi} \frac{r}{(1+r^4)^2}; \tag{2.7}$$

 $<sup>^{10}</sup>$  This case is exactly that of j=0 in II if we interchange the electric and magnetic fields. The Hamiltonian has the simple form

![](_page_4_Figure_2.jpeg)

Fig. 2.  $E_x$  plotted against x for  $E_r = r^2/(1+r^4)$ .

it vanishes for r=0 and decreases for large r like  $r^{-7}$ .

The total charge is defined by

$$e = \int \rho dv = 1/4\pi \int \operatorname{div} \mathbf{E} dv, \qquad (2.8)$$

and in the special case here considered it turns out that e=1 since we have used natural units.

The potential function  $\varphi(r)$  belonging to  $E_r$  can be at once calculated since

$$E_r = -d\varphi/dr. \tag{2.9}$$

This gives

$$\varphi(r) = \int_{r}^{\infty} \frac{r^{2}dr}{1+r^{4}} = \frac{\sqrt{2}}{8} \left\{ \log \frac{1+\sqrt{2}r+r^{2}}{1-\sqrt{2}r+r^{2}} - 2 \tan^{-1} \frac{\sqrt{2}r}{1-r^{2}} \right\}. \quad (2.10)$$

The potential is finite for r=0:

$$\varphi(0) = \sqrt{2}\pi/4. \tag{2.11}$$

The energy density is measured by  $T_4^4$  and the total energy is given by

$$W = \int T_4^4 dv$$

integrated over all space. Since the total energy in the spherically symmetric electrostatic case, independently of the choice of the action function, is  $\frac{2}{3}\varphi(0)$ , we have

$$W = 2\phi(0)/3 = \sqrt{2}\pi/6. \tag{2.12}$$

It can easily be shown that a magnetic solution of this kind does not exist. For both  $B_r$  and  $H_r$  are discontinuous at r=0 in the spherically

symmetric magnetostatic case and the regularity condition is thus not fulfilled.

# §3. The energy momentum tensor and the laws of motion

We go back now to the general case and calculate the energy-momentum tensor. For the sake of simplicity we shall use both the tensors  $f_{kl}$  and  $p_{kl}$ .

The field equations (1.3a), (1.3b) can be written in the form

$$\frac{\partial f_{lm}}{\partial x^k} + \frac{\partial f_{mk}}{\partial x^l} + \frac{\partial f_{kl}}{\partial x^m} = 0, \tag{3.1}$$

$$\frac{\partial p_{lm}^*}{\partial x^k} + \frac{\partial p_{mk}^*}{\partial x^l} + \frac{\partial p_{kl}^*}{\partial x^m} = 0.$$
 (3.2)

Multiplying (3.1) by  $\frac{1}{2}p^{lm}$ , (3.2) by  $\frac{1}{2}f^{*lm}$  and adding, we get

$$\frac{1}{2} \left[ p^{lm} \frac{\partial f_{lm}}{\partial x^{k}} + f^{*lm} \frac{\partial p^{*}_{lm}}{\partial x^{k}} \right] + \frac{1}{2} \frac{\partial}{\partial x^{l}} \left[ p^{lm} f_{mk} + f^{*lm} p^{*}_{mk} \right] = 0. \quad (3.3)$$

By (1.3a) and (1.3b) the terms in the first brackets are merely the derivative of T with respect to  $x^{i}$ . So if we introduce

$$T_k^l = \frac{1}{2} \{ T \delta_k^l + (p^{lm} f_{mk} + f^{*lm} p^{*}_{mk}) \},$$
 (3.4)

Eq. (3.3) becomes

$$\partial T_k{}^l/\partial x^l = 0. (3.5)$$

Thus  $T_k^l$  is the energy momentum tensor for the present theory. The  $\frac{1}{2}$  factor is inserted in order to obtain the Maxwellian expression for the limiting case. This is clearly seen in the case of  $T_4^1$ , for instance:

$$T_4{}^1 = E_y H_z - H_y E_z, (3.6)$$

which, for weak fields, goes over into the Maxwellian expression for the x component of the Poynting vector.

From (3.4) we find

$$T_s^s = 2T, \tag{3.7}$$

showing that our action function is half the trace of the energy momentum tensor.

It was shown by Feenberg<sup>5</sup> that in the earlier form of the new field theory the equations of

<sup>11</sup> II. §5.

motion are not consequences of the field equations but constitute an extra dynamical condition. We shall show now that in the present form of the theory, in the first approximation, the Lorentz equations of motion follow from the field equations without further assumption. The absence of singularities in the  $f_{kl}$  field is essential for this result.

One of the equations expressing the conservation of energy and momentum is

$$\frac{\partial T_{34}}{\partial t} = \frac{\partial T_{31}}{\partial x} + \frac{\partial T_{32}}{\partial y} + \frac{\partial T_{33}}{\partial z},\tag{3.8}$$

or, in space notation,

$$\partial S_z/\partial t + \text{div} \cdot Z = 0,$$
 (3.9)

where  $-S_z \sim T_{34}$ ,  $Z \sim T_{31}$ ,  $T_{32}$ ,  $T_{33}$ .

We may integrate (3 9) over some volume and transform the integral on the right-hand side into a surface integral. For simplicity we assume, though this is not essential, that  $S_z$ , Z are functions of  $f_{kl}$  and  $p_{kl}$  according to (3.4). We should exclude those points at which Z can become infinite, which can only occur where  $P \rightarrow \infty$ . We thus have, assuming for simplicity that only one such point is in question,

$$\frac{\partial}{\partial t} \int_{\Omega} S_z dv = \int_{\Sigma_z} Z_n d\sigma - \int_{\Sigma} Z_n d\sigma, \quad (3.10)$$

where  $\Sigma'$  is a small surface enclosing the space point at which  $P{\longrightarrow}\infty$ ,  $\Sigma$  is an arbitrary surface enclosing  $\Sigma'$ , and  $\Omega$  is the volume between  $\Sigma$  and  $\Sigma'$ .

Now it follows from (2.6) and the fact that  $D_r=1/r^2$ , that the  $p^{lm}f_{mk}$  and  $f^{*lm}p_{mk}^*$  terms in  $T_k{}^l$  will be at most of the order of 1. Further the part of  $T_k{}^l$  involving the action function T can only give a contribution to the surface integral over  $\Sigma'$  of the order of  $r^2 \log r$ . Thus in the limit when  $\Sigma'$  shrinks to a point the whole integral over  $\Sigma'$  vanishes, and we have left

$$\frac{\partial}{\partial t} \int_{\Omega} S_z dv = -\int_{\Sigma} Z_n d\sigma. \tag{3.11}$$

The vanishing of the integral

$$\int_{\Sigma'} Z_n d\sigma$$

in the limit, together with the similar vanishing of the corresponding integrals for the x and y directions, is here a consequence of the regularity condition and of the special form of the action function. But this vanishing constitutes the dynamical condition which leads to the Lorentz laws of motion<sup>12</sup> under the usual conditions concerning the possibility of separating the whole field into a spherically symmetric field and a weak uniform external field.

### PART II

### §4. Action function and field equations

The field equations of the general theory of relativity are of the form

$$R_{kl} - \frac{1}{2} g_{kl} R = -8\pi \gamma T_{kl}, \tag{4.1}$$

where  $R_{kl}$  is the Ricci tensor formed out of the metrical tensor  $g_{kl}$ , R its contraction,  $T_{kl}$  the material energy momentum tensor, and  $\gamma$  the relativistic gravitational constant. Though the precise form of  $T_{kl}$  is not specified by the general theory of relativity, its physical significance must definitely be that of an energy momentum tensor and we shall accordingly use here for  $T_{kl}$  the energy momentum tensor corresponding to the theory described in the first part of this paper.

Since, in the general theory of relativity, the  $g_{kl}$  may not be assumed to be Galilean, we must define the scalars F, P so as to show explicitly their dependence on the  $g_{kl}$ :

$$\begin{cases}
F = \frac{1}{2}g^{kl}g^{mn}f_{km}f_{ln}; & f_{km} = \left(\frac{\partial \varphi_m}{\partial x^k} - \frac{\partial \varphi_k}{\partial x^m}\right); \\
P = \frac{1}{2}g^{kl}g^{mn}p_{km}^*p_{ln}^*; & p^*_{km} = \left(\frac{\partial \psi_m}{\partial x^k} - \frac{\partial \psi_k}{\partial x^m}\right).
\end{cases} (4.2)$$

Further we shall need to know the relationship between a six-vector and its dual. The general formula leads to

(3.11) 
$$\begin{cases} f^{*23} = \frac{1}{\sqrt{(-g)}} f_{14}, \text{ etc.}; & f^{*14} = \frac{1}{\sqrt{(-g)}} f_{23}, \text{ etc.}; \\ f^{*}_{23} = -\sqrt{(-g)} f^{14}, \text{ etc.}; & f^{*}_{14} = -\sqrt{(-g)} f^{23}. \text{ etc.}, \end{cases}$$

with, of course, analogous relations holding for the p's.

<sup>&</sup>lt;sup>12</sup> Pryce, reference 5, §9.

The correct action principle for the general theory is

$$\delta \int \left(\frac{1}{8\pi\gamma}R - T(\epsilon)\right) \sqrt{(-g)} dx^1 dx^2 dx^3 dx^4 = 0, \quad (4.4)$$

where  $T(\epsilon)$  is the function defined in (1.20) and variation is with respect to  $g_{kl}$ ,  $\varphi_k$  and  $\psi_k$ , respectively.

The variation with respect to  $g_{kl}$  gives the conditions13

$$\sqrt{(-g)}\{(R_{kl}-\frac{1}{2}g_{kl}R)+8\pi\gamma T_{kl}\}=0,$$
 (4.5)

with 
$$T_{kl} = \frac{1}{2} g_{kl} T - \partial T / \partial g^{kl}$$
. (4.6)

This  $T_{kl}$  reduces to the  $T_{kl}$  of (3.4) in the flat case. Since T is homogeneous of degree zero in  $g_{kl}$ , as follows from (4.2), we have

$$g^{kl}\partial T/\partial g_{kl} \equiv 0. \tag{4.7}$$

Thus, on contracting (4.6) we find at once that

$$T_s^s = 2T, (4.8)$$

a result already obtained for the Galilean case in §3. Further, the variations with respect to  $\varphi_k$  and  $\psi_k$  give field equations equivalent to (4.2):

$$\frac{\partial}{\partial x^k} (p^{kl} \sqrt{(-g)}) = 0, \tag{4.9}$$

$$\frac{\partial}{\partial x^k} (f^{*kl} \sqrt{(-g)}) = 0, \tag{4.10}$$

where use has been made of the "constitutive" equations

$$p^{kl} = \partial T/\partial f_{kl}, \quad f^{*kl} = \partial T/\partial p_{kl}^*.$$
 (4.11)

### §5. The regularity condition

We have already seen that the condition of regularity of the field gives the restriction that in the spherically symmetric electrostatic case  $E_r = 0$  for r = 0.

In the general theory we apply the regularity condition not only to the  $f_{kl}$  field but also to the  $g_{kl}$  field. The regularity condition for the general theory is that:

Only those solutions of the field equations may have physical meaning for which space-time is everywhere regular and for which the  $f_{kl}$  and  $g_{kl}$ fields and those of their derivatives which enter the field equations and the conservation laws exist everywhere.

The most general spherically symmetric static line element may always be brought to the form

$$ds^{2} = e^{\nu}dt^{2} - e^{\lambda}dr^{2} - r^{2}(d\theta^{2} + \sin^{2}\theta d\varphi^{2}), \quad (5.1)$$

where  $\lambda$  and  $\nu$  are functions of r alone.

In the general theory of relativity the spherically symmetric solution of the purely gravitational field equations is given by the Schwarzschild line element

$$ds^2 = A dt^2 - A^{-1} dr^2 - r^2 (d\theta^2 + \sin^2\theta d\varphi^2), \quad (5.2)$$

$$A = 1 - 2m\gamma/r,\tag{5.3}$$

where  $(-2m\gamma)$  is a constant of integration, m having the significance of the gravitational mass of the body producing the field and  $\gamma$  being the gravitational constant. This line element has an essential singularity at r=0 and does not satisfy the regularity condition.

In the general relativity form of the original Born theory the requirement that there be no infinities in the  $g_{kl}$  forces the identification of gravitational with electromagnetic mass14 and leads to the line element (5.2) with

$$A = 1 - \frac{8\pi\gamma}{r} \int_0^r \{ (r^4 + 1)^{\frac{1}{2}} - r^2 \} dr.$$
 (5.4)

This line element approximates the Schwarzschild form for r greater than the electronic radius but avoids the infinities of that line element for r = 0. However, there is still a singularity at the pole. 15 For, when  $r\rightarrow 0$ , (5.4) gives

$$A \rightarrow (1 - 8\pi\gamma) = \beta$$
 (say)

so that (5.2) becomes

$$ds^2 \rightarrow \beta dt^2 - (1/\beta)dr^2 - r^2(d\theta^2 + \sin^2\theta d\varphi^2). \quad (5.5)$$

Thus the ratio of the circumference to the radius of a small circle having its center at the pole is, in

<sup>18</sup> It has been pointed out to us by H. P. Robertson that we use two different conventions in the variational process. For variations of  $f_{kl}$  etc. we assume  $\delta f_{kl} = -\delta f_{lk}$ , but for variations of  $g_{kl}$  we assume  $\delta g_{kl}$  to be independent of  $\delta g_{lk}$ . Since no confusion is likely to arise from this usage we employ the present convention in order to agree with previous work in this field.

<sup>&</sup>lt;sup>14</sup> Hoffmann, Phys. Rev. 47, 877 (1935). This paper includes a detailed discussion of the difficulties connected with the Schwarzschild line element and of the physical principles underlying the argument of this and the next section. For the sake of brevity much of this discussion is not repeated here.

15 This was kindly pointed out by Einstein and Rosen.

the limit,  $2\pi\beta$  and not  $2\pi$ . Therefore the pole is a conical point and not regular. No coordinate system can be introduced which will be nonsingular at r=0 and derivatives are actually undefined at this point.

Thus the regularity condition applied to (5.1) requires that

$$\underset{r \to 0}{\mathcal{L}}(e^{\lambda}) = 1 \tag{5.6}$$

and that certain derivatives shall exist. We shall consider this matter in more detail later.

## §6. The general spherically symmetric electrostatic case

The solution of the general spherically symmetric electrostatic case can be very largely reduced to that of the corresponding Galilean case treated in Part I because of a result we shall now prove.

The energy tensor (4.6) can be written as

$$T_{kl} = \frac{1}{2} g_{kl} T - \frac{\partial T}{\partial \epsilon} \frac{\partial \epsilon}{\partial g^{kl}}$$

$$= \frac{1}{2} g_{kl} T - \frac{1}{2} \frac{\partial T}{\partial \epsilon} \left\{ \frac{1}{(-FP)^{\frac{1}{2}}} g^{mn} f_{km} f_{lm} - \left( -\frac{F}{P^3} \right)^{\frac{1}{2}} g^{mn} p^*_{km} p^*_{ln} \right\}. \quad (6.1)$$

For the line element and coordinate system defined by (5.1) the only non-zero components of  $f_{kl}$  and  $p_{kl}$ \* are, in the present case,  $f_{14} = -f_{41}$  and  $p_{23}^* = -p_{32}^*$ , respectively. Thus, since  $g^{kl}$  vanishes if  $k \neq l$ , the tensors

$$F_{kl} = \varrho^{mn} f_{km} f_{ln}$$
 and  $P_{kl} = \varrho^{mn} \rho_{km} * \rho_{ln} *$  (6.2)

are easily seen to be such that

$$F_1^1 = F_4^4$$
;  $P_1^1 = P_4^4 (=0)$ . (6.3)

Since, further

$$g_1^1 = g_4^4 (=1),$$

it follows from (6.1) and (6.3) that

$$T_1^1 = T_4^4. (6.4)$$

Thus the field equations (4.5) imply that

$$\sqrt{(-g)}\left\{R_1^1 - \frac{1}{2}g_1^1R\right\} = \sqrt{(-g)}\left\{R_4^4 - \frac{1}{2}g_4^4R\right\}.$$
 (6.5)

These equations at once give<sup>16</sup>

$$\lambda' + \nu' = 0$$

and since  $e^{\lambda}$  and  $e^{\nu}$  must each approach unity as  $r \rightarrow \infty$ , we obtain the result that

$$\lambda + \nu = 0 \qquad (6.6)$$

or 
$$g_{11}g_{44} = 1/(g^{11}g^{44}) = -e^{\lambda + \nu} = -1.$$
 (6.7)

This result shows that the values of  $\sqrt{(-g)}$ , F, P, T, and  $T_k{}^l$ ,  $^{17}$  for the present case, take the same form as in the Galilean case for polar coordinates and we may thus use results obtained in Part I which are valid for the more general case considered here.

We have, therefore, at once,

$$p_{14} = D_r = 1/r^2$$
;  $f_{14} = E_r = r^2/(1+r^4)$  (1.15)

and it turns out that the only equations which remain to be satisfied are the (1-1) and (2-2) equations of the set (4.5). Without making use of (6.6) we may write these in the form

$$e^{-\lambda}(\nu'r+1)-1=-8\pi\gamma r^2T_1^1=-8\pi\gamma r^2T_4^4$$
, (6.8)

$$r^{2}e^{-\lambda}\left\{\frac{1}{2}\nu''-\frac{1}{4}\lambda'\nu'+\frac{1}{4}{\nu'}^{2}+(1/2r)(\nu'-\lambda')\right\}$$

$$=-8\pi\gamma r^2T_2^2$$
, (6.9)

these being the same as

$$e^{-\lambda - \nu} \frac{d}{dr} (re^{\nu}) - 1 = -8\pi \gamma r^2 T_4^4,$$
 (6.8a)

$$e^{-\lambda - \frac{1}{2}\nu} r \frac{d}{dr} \left\{ r \frac{d}{dr} (e^{\frac{1}{2}\nu}) \right\}$$

$$-e^{-\lambda}r^{2}\left\{\frac{1}{4}\lambda'\nu'+(1/2r)\lambda'\right\} = -8\pi\gamma r^{2}T_{2}^{2}. \quad (6.9a)$$

The values of the components  $T_4^4$ ,  $T_2^2$  may be calculated directly from (6.1) or from the value (3.4) of the first part, with the help of (6.7), (4.2), (4.3), (1.20) and (1.15). The values are found to be

$$T_4^4 = -\log\left(\frac{r^4}{1+r^4}\right),$$
 (6.10)

$$T_2^2 = -\log\left(\frac{r^4}{1+r^4}\right) - \frac{2}{1+r^4}.$$
 (6.11)

<sup>&</sup>lt;sup>16</sup> See the values of  $(R_1^1 - \frac{1}{2}g_1^1R)$  and  $(R_4^4 - \frac{1}{2}g_4^4R)$  given in Eddington, *Mathematical Theory of Relativity*, second edition, p. 104, Eqs. (46.9).

<sup>17</sup> This last can best be seen from (6.1) with the help of (4.2), (4.3) and the fact that only  $f_{14} = -f_{41}$ ,  $p_{14} = -p_{41}$ , and  $f_{22}^* = -f_{32}^*$ ,  $p_{23}^* = -p_{32}^*$  of the covariant components are different from zero in the present case.

If we use (6.7) to simplify the left-hand sides of (6.8), (6.9) we now obtain

$$e^{\nu}(\nu'r+1) - 1 = \frac{d}{dr}(e^{\nu}r) - 1 = -8\pi\gamma r^2 T_4^4$$

$$= 8\pi\gamma r^2 \log \frac{r^4}{1+r^4}, \quad (6.12)$$

$$r^{2}e^{\nu}(\nu'' + \nu'^{2} + \nu'/r) = -16\pi\gamma r^{2}T_{2}^{2}$$

$$= 16\pi\gamma r^{2} \left\{ \log\left(\frac{r^{4}}{1+r^{4}}\right) - \frac{2}{1+r^{4}} \right\}. \quad (6.13)$$

The solution of (6.12) is seen to be

$$e^{\nu} = 1 - \frac{k}{r} - \frac{8\pi\gamma}{r} \int_{0}^{r} r^{2} T_{4}^{2} dr$$

$$= 1 - \frac{k}{r} + \frac{8\pi\gamma}{r} \int_{0}^{r} r^{2} \log \frac{r^{4}}{1 + r^{4}} dr, \quad (6.14)$$

where k is a constant of integration corresponding to the  $(-2m\gamma)$  of the Schwarzschild line element (5.2), (5.3). The Eq. (6.13) is essentially the derivative of (6.12) with respect to r so that a solution of (6.12) whose appropriate derivatives exist will automatically be a solution also of (6.13).

The regularity condition shows that we must take k=0 in (6.14) since otherwise we shall have an essential singularity at r=0. But if k=0 we must regard the quantity  $4\pi\gamma \int_0^r r^2T_4^4dr$  as the gravitational mass causing the field at coordinate distance r from the pole. This quantity, however, is precisely

$$\gamma \iiint T_4^4 r^2 \sin \theta dr d\theta d\varphi \qquad (6.15)$$

taken over the sphere having its center at r=0 and coordinate radius r and is thus the measure, in gravitational units, of the total *electromagnetic* mass within this sphere. For r appreciably greater than the electronic radius this line element closely approximates the Schwarzschild

form. Thus the regularity condition shows that electromagnetic and gravitational mass are the same and it is seen that, as in the Newtonian theory, we now have the result that the attraction due to a uniform spherical shell of matter is zero at any point inside the shell. A further result of this identification of gravitational with electromagnetic mass is the fact that the gravitational mass (6.15) is necessarily positive, which was not the case in the Schwarzschild line element.

It remains to show that the regularity conditions are completely fulfilled by our solution

$$\begin{cases} ds^{2} = A dt^{2} - A^{-1} dr^{2} - r^{2} (d\theta^{2} + \sin^{2} \theta d\varphi^{2}), \\ A = 1 + \frac{8\pi\gamma}{r} \int_{0}^{r} r^{2} \log \frac{r^{4}}{1 + r^{4}} dr, \\ E_{r} = r^{2} / (1 + r^{4}). \end{cases}$$
(6.16)

In the limit  $r\rightarrow 0$  we have  $A\rightarrow 1$  so that we avoid a singularity of space-time at r=0. Also, since  $\gamma$  is very small, A will not change sign. Finally all the derivatives entering (6.8a), (6.9a) are seen to exist and the derivative of (6.8a) with respect to r, the only part of the divergence relations which involves further derivatives with respect to r, also exists. The regularity of the  $f_{kl}$  field was discussed in §2 and that discussion remains valid for the present case.

We have thus found a solution of the general spherically symmetric electrostatic case which fulfills the demands of the regularity condition and which carries over to gravitational theory the general ideas of the first part.

Since the  $g_{44}$  of (6.16) has the value unity at r=0 and at  $r=\infty$  it follows that its derivative must change sign. In the usual gravitational theory of general relativity the derivative of  $g_{44}$  is proportional to the gravitational force which would act on a test particle in the Newtonian approximation. In the present theory, then, it is interesting to note that although this force is an inverse square attraction for ordinary distances, it is actually a repulsion for very small r.