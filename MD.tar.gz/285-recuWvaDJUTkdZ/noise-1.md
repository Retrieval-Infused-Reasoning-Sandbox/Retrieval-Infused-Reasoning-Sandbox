# Born-Infeld-AdS black hole phase structure: Landau theory and free energy landscape approaches

Md Sabir Ali [ID](https://orcid.org/0000-0001-6670-7955) <sup>1</sup><sup>∗</sup> , Hasan El Moumni [ID](https://orcid.org/0000-0001-7408-0910) <sup>2</sup>† , Jamal Khalloufi [ID](https://orcid.org/0000-0002-4463-4203) <sup>2</sup>‡ , Karima Masmar [ID](https://orcid.org/0000-0001-5419-8516) <sup>3</sup>§¶

- <sup>1</sup> Department of Physical Sciences, Indian Institute of Science Education and Research Kolkata, Mohanpur, 741246, India.
- <sup>2</sup> LPTHE, Physics Department, Faculty of Sciences, Ibnou Zohr University, B.P 8106, Agadir, Morocco.
- <sup>3</sup> Laboratory of High Energy Physics and Condensed Matter, Faculty of Sciences Ain Chock, B.P 5366, HASSAN II University, Casablanca, Morocco.

#### Abstract

We start with a brief overview of the basic thermodynamic properties of the Born-Infeld metric in AdS spacetime. Using the concept of the enthalpy characterizing the total mass of the black hole, in our present paper, we probe the thermal phase transition structure, the dynamic and kinetic behavior of the Born-Infeld-AdS black hole. The emergence of the triple point behavior and the possible ruling out the reentrant phase transition, for a certain parametric value of the charge on the free energy landscape, we scrutinize the stochastic dynamics and the kinetic processes. We describe such processes during the black hole phase transitions in terms of the Landau functional and equivalently by the Fokker-Planck equation in the context of black hole chemistry.

Our analysis establishes a pertinent bridge between the thermal behavior among the different states of the Van-der-Waals-like fluids and the Born-Infeld-AdS black holes phases. To visualize the direct implications of the Landau functional of the usual Van-der-Waals-like fluids, we consistently employed the generic Landau formalism for the analysis of the black hole phase transitions of the Born-Infeld-AdS black holes. We find that such investigations are worthy of study in implementing the continuous phase

<sup>∗</sup>alimd.sabir3@gmail.com

<sup>†</sup>h.elmoumni@uiz.ac.ma (Corresponding author)

jamalkhalloufi@gmail.com

<sup>§</sup>karima.masmar@gmail.com

<sup>¶</sup>Authors are in alphabetical order.

transition behavior during the Hawking radiation. For more details, and in addition to the exploitation of the Landau functional, we introduce its convexity to determine its extreme points and the corresponding stable and unstable phases of the thermal black hole systems. We systematically study the behavior of the first-order and the second-order phases and look into details of their evolution during thermal transitions. Moreover, knowing that the thermal phase transitions are controlled through a stochastic process depending upon an order parameter, the dynamics during its phases are determined through the fluctuating macroscopic variables. We recall the dynamical Fokker-Planck equation to furnish the advancement of such a process in the Born-Infeld-AdS background. We mainly focus on the probability distribution of the triple point structure where the small, large, and pure thermal radiation coexist. The evolution of the initial probability indicates that there not only the initial small black hole to the final large black hole phase occurs, but also one has the equilibrium conditions established among the thermal radiations to the small black holes or the small black holes to thermal radiations and large black hole states. We also demonstrate the first passage time for the different black hole phase behaviors to determine their time scale. In addition to this, we also calculate the mean first passage time and its fluctuation using the Crank-Niclson method. Such a study has implications in the friction effects of the kinetic turnover of different black hole phases. The friction has a direct connection to the microscopic degrees of freedom. Therefore such investigation helps us to determine the interactions of the black hole micromolecules during kinetic phase transitions.

## Contents

| 1 | Introduction                                                                                                                                                                                       | 3              |
|---|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|
| 2 | Born-Infeld black hole in AdS spacetime                                                                                                                                                            | 5              |
| 3 | On Criticality of Born-Infeld-AdS black hole                                                                                                                                                       | 7              |
| 4 | Born-Infeld AdS black hole from the Landau theory point of view<br>4.1<br>A brief review of Landau theory formalism<br>4.2<br>Born-Infeld-AdS black hole thermodynamics through Landau formalism . | 11<br>11<br>12 |
| 5 | Fokker-Planck equation and its use to determine the probabilistic nature<br>on the free energy landscape                                                                                           | 30             |
| 6 | Kinetics:<br>First passage process                                                                                                                                                                 | 40             |
| A | Numerical resolution of Focker-Planck equation<br>A.1<br>Introduction .                                                                                                                            | 45<br>45       |

| A.2 | First Method |                                                                      | 45 |
|-----|--------------|----------------------------------------------------------------------|----|
|     | A.2.1        | Discretization                                                       | 47 |
|     | A.2.2        | Finite differences / Implicit method / Backward time-central space / |    |
|     |              | Crank-Niclson method                                                 | 47 |
| A.3 |              | Second Method                                                        | 48 |

### <span id="page-2-0"></span>1 Introduction

In theoretical high energy physics, the thermodynamics of black holes is a fascinating and promising research area in order to probe their quantum nature. It provides a possible route to develop the quantum gravitational theory when studied in the context of anti-de Sitter (AdS)/Conformal field theory (CFT). The discovery of the Hawking-Page phase transition between the AdS thermal bath and large Schwarzschild-AdS black holes triggered a flurry of thermodynamic activities in the last few decades. The black hole chemistry, i.e., the thermodynamics with a negative cosmological constant, made an open room to understand the different and new thermodynamics phenomena from the AdS/CFT perspectives. The gravitational viewpoint of the van der Waals (vdW) fluid, the reentrant phase transition of the multicomponent liquids, the thermal behavior of the triple points, the polymer phases, and the superfluidity have uplifted the status of thermodynamics of a wide range of AdS black holes. Among various solutions, the Born-Infeld black holes in AdS spacetime have been of great importance. The Born-Infeld gravity is a nonlinear generalization of the Maxwell electrodynamics calibrated by the Born-Infeld parameter. Such solutions are very important in order to probe the short-distance behavior of the electromagnetic field. From a general relativity viewpoint, we have the Born-Infeld black hole spacetime analytically when Einstein's field equations are solved. Asymptotically, the solution recovers the Reissner-Nordstr¨om black hole. In AdS spacetime in four dimensions, the solutions have some exotic thermodynamic behaviors. The reentrant phase transition behaviors which were uncommon in the study of the thermodynamics was first observed in the case of Born-Infeld AdS spacetime [\[1\]](#page-51-0) in four dimensions. Such phase transition was examined in the usual thermodynamic systems exhibiting the nicotine/water mixture [\[2\]](#page-51-1). The reentrant phase transition (RPT) is a thermodynamic phenomenon of multicomponent liquids when the thermal system goes through multiple phases for a monotonic variation of any of the thermodynamic variables, provided the initial and the final states of the system shows the same macroscopic behaviors. After its inception for the conventional thermodynamic system, the reentrant phase transition has been reported for a wide class of AdS black hole systems [\[3](#page-51-2)[–14\]](#page-52-0) apart from four-dimensional Born-Infeld AdS black holes. The Born-Infeld AdS black hole in dimensions greater than four does not show the reentrant phase transition [\[15\]](#page-52-1).

The thermal properties of AdS black holes spacetime has surpassed the core idea of black hole mechanics and landed into much richer physics that is probed through the critical points. During the small to large phase transitions the thermodynamic properties change which in turn has an effect on the dynamic and kinetic processes that indicate the evolution of thermal systems through any thermodynamic process. Such dynamical evolution is systematically analyzed through Landau's theory of free energy, denoted by L, sometimes called the Landau functional. The AdS black hole systems have a direct link to the boundary conformal field theory (CFT), the duality between thermal AdS black properties and the CFT is usually called the holographic duality, or the gauge/gravity duality or the AdS/CFT correspondence. During the phase transition, the system undergoes a non-equilibrium condition and the dynamic is determined through Landau theory. The Landau parameters separate out the thermal phase transition behavior mainly of the vdW type fluid or the charge AdS black holes. This way, the Landau functional has the local minimum and thereby mimics the second-order phase transition, whereas, for the first-order transition during various phases, it would correspond to a global minimum of the extended thermodynamic phases of the AdS black hole systems.

Recently, the idea comprising the free energy landscape has been introduced from the perspectives of connecting the thermodynamic properties, the dynamics, and the kinetic transition processes through a stochastic process `a la Fokker-Planck equation. In thermal statistical physics, the dynamical Fokker-Planck relation is employed to study the time profile of the probability density function for any generic observable. For black hole thermal systems, such notions were first explored in the context of the phase transition due to Hawking and Page and also for the massive gravity scenarios [\[16\]](#page-52-2). The concept of representing the off-shell Gibbs free energy as dependant on the order parameter (e.g., the horizon radius), was the crucial identification behind such studies. The investigations of the free energy landscape are still under improvement, though people studied it for a wide range of black holes in Einstein as well as in modified gravity theories in asymptotically AdS spacetime. Soon after the original work on the dynamics of Schwarzschild-AdS spacetime on the free energy landscape proposal was posed, the conceptualization was further extended to charged AdS black hole systems [\[17\]](#page-52-3), then to charge neutral Gauss-Bonnet gravity theories [\[18\]](#page-52-4), and its charged version in four dimensional spacetime [\[19\]](#page-52-5), in determining the dynamics of triple point for a six-dimensional electrically charged Guass-Bonnet-AdS systems [\[20\]](#page-52-6), the dark energy modified charged AdS systems [\[21\]](#page-52-7), to the black hole spacetime when there is a minimal coupling of general relativity to the nonlinear electromagnetic sources [\[22,](#page-52-8) [23\]](#page-52-9), and lately to the Euler-Heisenberg-AdS black holes [\[24\]](#page-52-10). An analysis of the dynamical evolution also considered the effects of the path integral and the instantons approaches [\[25\]](#page-52-11), while for others the free energy landscape is extended to include the non-Markovian effects [\[26,](#page-52-12)[27\]](#page-53-0). It has been applied to the rotating solution as well, e.g., see for similar analysis on Kerr-AdS black holes [\[28\]](#page-53-1). The free energy landscape problem was further explored by the generalized Fokker-Planck equation [\[29\]](#page-53-2). Recently, the topology on the grounds of the free energy landscape and the identification of a dominant route of the dynamic and kinetic process during the black hole phase alternation has been analyzed for the electrically charged AdS spacetime in Gauss-Bonne gravity [\[30\]](#page-53-3).

Born-Infeld electrodynamics was originally used to establish a finite energy density model for the electron in the 1930s [\[31\]](#page-53-4). Then, it has piqued an intense interest in recent years for a variety of reasons. ranging from its natural appearance in open superstrings and D-branes [\[32\]](#page-53-5), in loop calculations, to the low energy effective action of an open superstring [\[33,](#page-53-6) [34\]](#page-53-7). More recently the Born-Infeld electrodynamics has been introduced in the modification of the Einstein-Hilbert action and aroused a special emphasis [\[35](#page-53-8)[–39\]](#page-53-9) from different point of views [\[40–](#page-53-10)[50\]](#page-54-0).

In our study, we shall consider the thermal phase transition characteristics of the AdS black holes within the Born-Infeld gravitational framework, a natural generalization of the Maxwell electrodynamics in nonlinear theory. In our case, we shall study the free energy landscape of the Born-Infeld-AdS black holes using Landau theory as well as the Fokker-Planck equation. The Born-Infeld-AdS metric in four-dimensional spacetime shows the reentrant phase transition like the nicotine/water mixture as in the conventional thermal system. We shall investigate the dynamical evolution of the black holes during the thermal and also for the reentrant phase transitions. The Born-Infeld parameter has a crucial effect on the horizon size and the radius of the horizon behaves as the order parameter. The subsequent analysis for the dependence of Landau functional or the Gibbs free energy on horizon radius may serve as a one-dimensional curve.

The organizations of our paper are as follows. In Section 2, we review some of the basic notions of the Born-Infeld-AdS black holes regarding its solutions, and the thermodynamic quantities of physical interests. The next Section 3, is devoted to studying the critical points analysis and their limiting values. The formalism of the Landau functional is vividly described in Section 4 in order to probe the free energy dependence on the Born-Infeld parameter. In Section 5, the dynamic and kinetic processes of the thermal system during the changes of its phases are probed through the equation as proposed by Fokker and Planck. We summarize and conclude the final remarks in Section 6.

## <span id="page-4-0"></span>2 Born-Infeld black hole in AdS spacetime

The starting point is the action describing the four-dimensional general relativity where the Born-Infeld electrodynamics is considered [\[51\]](#page-54-1) :

$$S = \frac{1}{16\pi} \int d^4x \sqrt{-g} \left[ R - 2\Lambda + 4b^2 \left( 1 - \sqrt{1 + \frac{F_{\mu\nu}F^{\mu\nu}}{2b^2}} \right) \right], \tag{1}$$

in which R denotes the Ricci scalar curvature, Λ is the cosmological constant expressed as Λ = −3/l<sup>2</sup> , where l being the AdS radius and b stands for the Born-Infeld parameter having the dimension of mass and has a connection to the string tension α <sup>0</sup> as b = 1/ (2πα<sup>0</sup> ) [\[34\]](#page-53-7). The electromagnetic tensor field Fµν is given by Fµν = ∂µA<sup>ν</sup> − ∂νAµ, where A<sup>µ</sup> is the four potential. The four-dimensional static geometry with spherical symmetry has the ansatz

$$ds^{2} = -f(r)dt^{2} + \frac{dr^{2}}{f(r)} + r^{2}d\Omega^{2},$$
(2)

where,  $d\Omega$  is the line element on a unit 2-sphere and the blackening function f(r) is obtained to be [37,51,52]

$$f(r) = 1 + \frac{r^2}{l^2} - \frac{m}{r} + \frac{2b^2r^2}{3} \left( 1 - \sqrt{1 + \frac{16\pi^2Q^2}{b^2r^2}} \right) + \frac{64\pi^2Q^2}{3r^2} {}_2\mathcal{F}_1 \left[ \frac{1}{4}, \frac{1}{2}, \frac{5}{4}, -\frac{16\pi^2Q^2}{b^2r^2} \right], \quad (3)$$

with  $_2\mathcal{F}_1[a,b,c,d]$  is the hypergeometric function of the second kind, the black hole mass M can be expressed via the integration constant m as  $M = m/8\pi$ . The electric charge per unit volume  $\omega = 4\pi$  is denoted by Q. The only component with spherical symmetric distribution, we consider the following non-zero component of the four potential

$$A_t(r) = -\frac{4\pi Q}{r} {}_2\mathcal{F}_1\left[\frac{1}{4}, \frac{1}{2}, \frac{5}{4}, -\frac{16\pi^2 Q^2}{b^2 r^2}\right]. \tag{4}$$

The limiting case of the Reissner-Nordstrom (RN)-AdS black hole [53,54] can easily be found by taking the limit  $b \to \infty$  in the metric function and the gauge potential. The Hawking temperature of Born-Infeld AdS spacetime metric is expressed as

<span id="page-5-0"></span>
$$T = \frac{1}{4\pi} \left. \frac{\partial f(r)}{\partial r} \right|_{r=r_h} = \frac{1}{4\pi r_h} + \frac{3r_h}{4\pi l^2} + \frac{b^2 r_h}{2\pi} \left( 1 - \sqrt{1 + \frac{16\pi^2 Q^2}{b^2 r^2}} \right). \tag{5}$$

in which  $r_h$  is the event horizon radius, obtained as the largest positive real solution of the blackening function, f(r) = 0. The electric potential at spatial infinity relative to the event horizon reads as

$$\Phi = \frac{\partial M}{\partial Q} = \frac{4\pi Q}{r_h} {}_2\mathcal{F}_1 \left[ \frac{1}{4}, \frac{1}{2}, \frac{5}{4}, -\frac{16\pi^2 Q^2}{b^2 r_h^2} \right]. \tag{6}$$

The first law of thermodynamics associated with the Born-Infeld-AdS black hole, are obtained by defining its key ingredients, namely entropy S, pressure P, and the volume V [1]

$$S = \int \frac{1}{T} \frac{\partial M}{\partial r_h} dr_h = \frac{r_h^2}{4}, \quad P = -\frac{\Lambda}{8\pi}, \quad V = \frac{\partial M}{\partial P} = \frac{r_h^3}{4},$$

$$\mathcal{B} = \frac{\partial M}{\partial b} = \frac{br_h^3}{6\pi} \left( 1 - \sqrt{1 + \frac{16\pi^2 Q^2}{b^2 r^2}} \right) + \frac{4\pi Q^2}{3br_h} {}_2\mathcal{F}_1 \left[ \frac{1}{4}, \frac{1}{2}, \frac{5}{4}, -\frac{16\pi^2 Q^2}{b^2 r_h^2} \right],$$
(7)

the additional quantity  $\mathcal{B}$  is conjugate to b which is interpreted as the Born-Infeld vacuum polarization [1], so that the first law and the related Smarr formula take the forms

$$dM = TdS + \Phi dQ + VdP + \mathcal{B}db,$$
  

$$M = 2TS + \Phi Q - 2PV - \mathcal{B}b.$$
(8)

We should keep in mind that the thermodynamic quantities M, Q, S, and V are written per unit volume  $\omega$ .

#### <span id="page-6-0"></span>3 On Criticality of Born-Infeld-AdS black hole

Following [55], we look into the Born-Infeld-AdS black hole critical behavior, where the black hole charge is allowed to vary but the cosmological constant remains a constant parameter. The specific heat at a constant charge is expressed as

<span id="page-6-1"></span>
$$C_Q = T \left( \frac{\partial S}{\partial T} \right)_Q, \tag{9}$$

the stability/instability during the phase transition can be found by considering the sign (positive/negative) of this quantity.

<span id="page-6-2"></span>Note that Eq.(9) is also calculated with l and b taken as fixed. To unveil the thermal behavior of the Born-Infeld-AdS spacetime, we depict the variation of the temperature T and the specific heat  $C_Q$  as a function of the event horizon radius  $r_h$  within various values of the charge in Fig.1 and Fig.2 respectively. Obviously, one can notice that the behavior of

![](_page_6_Figure_5.jpeg)

Figure 1: Temperature T in terms of the event horizon radius  $r_h$  for different values of charge Q with l=1 and b=3.5.

the temperature is highly influenced by the black holes' charge for small  $r_h$ . So, for small  $r_h$  values, we can Taylor expand the Hawking temperature as

$$T = \frac{2b}{r_h} (Q_m - Q) + \frac{r_h (3 + 2b^2 l^2)}{4\pi l^2} - \frac{b^3 r_h^3}{16\pi^2 Q} + \mathcal{O}(r_h^4), \tag{10}$$

herein  $Q_m = \frac{1}{8\pi b}$  denotes the marginal charge. Besides, the large limit  $r_h$  is  $\frac{3r_h}{4\pi l^2}$  which is independent of the charge and which explains the linearly increasing behaviour of the temperature for the large  $r_h$  Depending on the value of Q, Born-Infeld-AdS black hole is identified as follow:

<span id="page-7-0"></span>![](_page_7_Figure_0.jpeg)

Figure 2: The specific heat capacity C<sup>Q</sup> in terms of the event horizon radius r<sup>h</sup> for different values of charge Q with l = 1 and b = 3.5.

• For Q < Qm, the black hole is 'Schwarzschild-like' (S-type). In the region of low

temperature, black holes do not exist, much like in the Schwarzschild solution. The largest (smallest) branch of the isocharge, as shown in Fig.1 is connected to the huge (small) black hole, which is locally stable (unstable), as illustrated by the positive (negative) values of specific heat at the constant charge in Fig. 2a. Indeed, in the situation of  $Q < Q_m$ , the extremal Born-Infeld-AdS black hole can be found and therefore any charged black hole does not persist. This finding may be understood as screening effects on the electric field caused by the existence of the parameter b, which makes the role of charge less significant.

- When  $Q \geq Q_m$ , black hole is 'Reissner-Nordstrom-like' (RN-type). Due to the temperature crossing over from zero with decreasing  $r_h$ , we get an extreme black hole.
- In  $Q_m \leq Q < Q_c$  situation, the system exhibits a phase transition behavior of first-order between a small black hole (SBH) and a large black hole (LBH) as one can notice from Fig.2b and Fig.2c.
- The situation  $Q = Q_c$ , associated with Fig.2d, a critical behavior appears and phase behavior is of a second-order that occurs between a SBH and a LBH.
- In the last case  $Q > Q_c$ , the black hole has a locally thermal stable phase for forever, and the heat capacity is positive everywhere as is revealed in Fig.2e.

We now proceed to find the values of the critical points associated with the second-order phase transition with respect to the Born-Infeld-AdS black hole discussed previously. With constant l and  $Q = Q_c$ , we have illustrated in Fig.1 that the critical points are determined through the inflection point as may be described by

<span id="page-8-0"></span>
$$\frac{\partial T}{\partial r_h}\Big|_{Q_c} = 0 \quad \text{and} \quad \frac{\partial^2 T}{\partial r_h^2}\Big|_{Q_c} = 0.$$
(11)

The criticality must have happened at the right branch of the  $T-r_h$  curve in the S-Type black hole and is thermally stable. Then, the formulas of Eqs.(11) are expressed by considering the temperature in Eq.(5) as follows

$$-2x^{2} + \left(1 + \frac{3}{2b^{2}l^{2}} - \frac{1}{2b^{2}r_{c}^{2}}\right)x + 1 = 0,$$

$$x^{4} - \frac{x^{2}}{2} + \frac{x}{4b^{2}r_{c}^{2}} - \frac{1}{2} = 0,$$
(12)

<span id="page-8-1"></span>in which, we have set

$$x = \left(1 + \frac{16\pi^2 Q_c^2}{b^2 r_c^4}\right)^{-1/2},\tag{13}$$

and  $r_c$  denotes the critical horizon radius. To ensure the positive definiteness of the values of the critical quantities, we impose the following constraint on x,

<span id="page-8-2"></span>
$$0 \le x \le 1. \tag{14}$$

By the help of Eqs.[\(12\)](#page-8-1), one can write the following cubic equation

$$x^3 + px + q = 0, (15)$$

where

$$p = -\frac{3}{2}, \quad q = \frac{1}{2} \left( 1 + \frac{3}{2b^2 l^2} \right).$$
 (16)

Moreover, because q is real valued and p is negative, the cubic equation presents one or three roots which are real in nature. The existence of such three roots is controlled by ∆ = 4p <sup>3</sup> + 27q <sup>2</sup> ≤ 0, hence

$$b \ge b_0 = \sqrt{\frac{3}{2} \left(1 + \sqrt{2}\right)} / l \approx 1.9029 / l,$$
 (17)

and their form is given by

$$x_k = \sqrt{2}\cos\left(\frac{1}{3}\arccos\left[-\frac{\sqrt{2}}{2}\left(1 + \frac{3}{2b^2l^2}\right)\right] - \frac{2\pi k}{3}\right), \quad k = 0, 1, 2.$$
 (18)

It is simple to prove that the third root x<sup>2</sup> violates the condition in Eq.[\(14\)](#page-8-2). Additionally, by computing the critical quantity for x1, we discover that r<sup>c</sup> persists in that branch of critical isocharge where it is locally unstable for the S-type black holes. [\[55\]](#page-54-5). Hence the only physical solution is x0. For b < b<sup>0</sup> case, one real root is given by

$$x_3 = -\sqrt{2}\cosh\left(\frac{1}{3}\operatorname{arccosh}\left[-\frac{\sqrt{2}}{2}\left(1 + \frac{3}{2b^2l^2}\right)\right]\right),\tag{19}$$

which breaks the rule obtained in Eq.[\(14\)](#page-8-2). Henceforth, the criticality of the Born-Infeld-AdS black holes can only be seen for b ≥ b0. The critical quantities are revealed as soon as x<sup>0</sup> is available

$$r_{c} = \sqrt{\frac{x_{0}}{2b^{2} (1 + x_{0}^{2} - 2x_{0}^{4})}},$$

$$Q_{c} = \frac{1}{8\pi b \sqrt{(1 + 3x_{0}^{2} - 4x_{0}^{6})}},$$

$$T_{c} = \frac{3 + 2b^{2}l^{2} (1 + x_{0} - 2x_{0}^{3})}{4\pi bl^{2}} \sqrt{\frac{x}{2(1 + x_{0}^{2} - 2x_{0}^{4})}}.$$
(20)

The critical charge Q<sup>c</sup> is larger than Q<sup>m</sup> where

$$b > b_1 = \sqrt{\frac{3}{2\left(\sqrt{6\sqrt{3} - 9} - 1\right)}}/l \approx 2.8870/l.$$
 (21)

Thus for b ≥ b1, the criticality is the mimicker of the RN-type black hole. On the contrary, for b<sup>0</sup> ≤ b ≤ b1, the criticality occurs at the right branch of (T − rh)<sup>Q</sup><sup>c</sup> curve of the S-type black hole.

<span id="page-10-2"></span>For large values of b, the Tayalor expansion of the critical quantities gives rise to

$$r_{c} = \frac{l}{\sqrt{6}} - \frac{7}{24\sqrt{6}b^{2}} + \mathcal{O}\left(\frac{1}{b^{4}}\right),$$

$$Q_{c} = \frac{l}{24\pi} - \frac{7}{576\pi lb^{2}} + \mathcal{O}\left(\frac{1}{b^{4}}\right),$$

$$T_{c} = \sqrt{\frac{2}{3\pi^{2}l^{2}}} - \frac{1}{12\pi\sqrt{6}b^{2}l^{3}} + \mathcal{O}\left(\frac{1}{b^{4}}\right).$$
(22)

As expected, the first terms in all the quantities of Eqs.[\(22\)](#page-10-2) reproduce the same critical behaviors as that of the RN-AdS black holes [\[54\]](#page-54-4).

# <span id="page-10-0"></span>4 Born-Infeld AdS black hole from the Landau theory point of view

#### <span id="page-10-1"></span>4.1 A brief review of Landau theory formalism

Landau estimated a system's free energy from a perspective that displays the non-analytical nature during the phase transition and ends up capturing a significant amount of the physics. The system is defined through a global minimum of Landau free energy L as a function of order parameter. The quantity L called sometimes the Landau functional which is related to the system's Gibbs free energy and has an energy dimension, but it is not the same as it [\[56,](#page-54-6) [57\]](#page-55-0).

Following [\[57\]](#page-55-0), the Landau free energy can be constructed for a general thermodynamical system as

$$L = \int F(X, T, P, Q) dX$$
 (23)

The thermodynamic system consisting of —temperature T, pressure P, and charge Q are treated as independent parameters, whereas the parameter X is regarded as an auxiliary variable. The function F (X, T, P, Q) represents various relationships that these four significant thermodynamic system parameters satisfy.

The equation of state (EOS) describing the thermal properties are expressed as P = f(V, T, Q), where V is the volume which is in canonical conjugation of P. Based on the EOS, we may create the functional dependence of F (X, T, P, Q) as

$$F(X,T,P,Q) = P - f(X,T,Q).$$
(24)

Now, one can assert that a particular thermodynamic equation describing the system's state under a particular set pertaining certain physical conditions takes the form F (X, T, P, Q) = 0. The system's preferred path is the one that causes its free energy to drop to its lowest value between many distinct paths that the system can take to attain equilibrium. We incorporate an auxiliary variable X which serves as an order parameter having a dimension of volume when system is heading towards the equilibrium in the isothermal, isobaric, and isocharge environments. We can discover certain actual physical thermodynamic system operations by the use of this parameter. Thus, when the functional L takes the least possible value, it is considered as the most realistic state in which the system is described, the relations F(X, T, P, Q) satisfied by the set  $\{X, T, P, Q\}$ :

$$\frac{dL}{dX} = F(X, T, P, Q) = 0 \Longrightarrow X = V, \tag{25}$$

The order parameter X can be viewed as a volume of the system as it approaches equilibrium or, less formally, as the volume of the system in a non-equilibrium state that does not meet the system's equation of state. Although the equilibrium thermodynamic volume V fulfills the system's equation of state and is the root of the function F(X, T, P, Q) = 0. Another benefit of creating the Landau free energy in this manner is that the convexity is connected to the thermal stability of the thermodynamical system

$$\delta \left( \frac{dL}{dX} \right) \Big|_{X=V} = -\frac{\partial f(V, T, Q)}{\partial V} \delta V, \tag{26}$$

from which, one can notice that the extreme point is comparable to a potential well when  $\partial f(V,T,Q)/\partial V<0$  and the corresponding state is stable, while the corresponding thermodynamic state is unstable when  $\partial f(V,T,Q)/\partial V>0$  and the extreme point is similar to a potential barrier. Hence, the  $\gamma$ -function is defined as

$$\gamma(V) = (3V)^{2/3} \frac{\partial L(X=V)}{\partial V},\tag{27}$$

which is negative when the black hole is stable and it is positive when the black hole is unstable. When  $\gamma(V) = 0$ , we are in presence of critical behavior. Moreover, we can interpret the zeros of  $\gamma(V)$  as the fixed points by analogy with dynamical systems.

# <span id="page-11-0"></span>4.2 Born-Infeld-AdS black hole thermodynamics through Landau formalism

To construct a phase transitions picture and classify their types, we have to probe the behavior of the thermodynamic potential associated with Born-Infeld-AdS black hole. In this sense, we recall the Gibbs free energy which is the thermodynamic potential computed from the Euclidean action with the proper boundary term in the canonical ensemble [53], for fixed temperature T, pressure P, and charge Q. By using the Legendre transformation,

one can derive the Gibbs free energy per unit volume ω as in [\[1\]](#page-51-0)

$$G(T, P, Q) = M - TS$$

$$= \frac{1}{48\pi r_h} \left[ 3r_h^2 - \frac{3r_h^4}{l^2} - 2b^2 \left( 1 - \sqrt{1 + \frac{16\pi^2 Q^2}{b^2 r_h^4}} \right) + 128\pi^2 Q^2 {}_2\mathcal{F}_1 \left[ \frac{1}{4}, \frac{1}{2}, \frac{5}{4}, -\frac{16\pi^2 Q^2}{b^2 r_h^2} \right] \right], \tag{28}$$

in which r<sup>h</sup> = rh(T, Q, P) and l = l(P). In the following, we shall assume the charge of the Born-Infeld-AdS black hole can vary, while the value of the pressure is fixed. Moreover, we shall take b = 3.5 > b1, thus the critical behavior will take place in the RN-type black hole.

Depending on the value of Q, the phase structure of the Born-Infeld-AdS Black hole is characterized as follows:

- For Q = 0.005 < Q0, we plot in Fig[.3](#page-17-0) the temperature as a function of horizon radius r<sup>h</sup> (Fig[.3a\)](#page-17-0), Gibbs free energy in therms of temperature (Fig[.3b\)](#page-17-0), Landau function L in terms of the parameter X for different temperatures (Fig[.3c\)](#page-17-0), Landau function L in terms of the black hole volume V (Fig[.3d\)](#page-17-0), γ-function in terms of the black hole volume V F(ig[.3e\)](#page-17-0) and on-shell Gibbs free energy G˜ versus the temperature (Fig[.3f\)](#page-17-0). We observe that the black hole behaves like Shwarzschild one revealing a Hawking-Page transition between the unstable small black holes phase and stable large black hole one at THP = 0.3065. The unstable phase corresponds to the local maximum of the Landau function (blue dot) whereas the stable phase corresponds to the local minimum (red dot). Moreover, we notice that the Landau function is a decreasing function in terms of the black hole volume when the system is stable (red curve) and it is an increasing function when the system is unstable (blue curve). Thus the γ function is negative in the large black holes phase and positive in the small black holes one. The zero of γ-function is associated with an unstable fixed point indicating that the temperature is (locally) minimal. We can interpret these results as the large black hole becoming larger and more stable when it gets hotter, whereas the small hole becomes smaller when it gets hotter because of evaporation. The pink region indicates the zone where the temperature is less than Hawking-Page one (pink curves) and only the thermal radiation phase is globally stable.
- Herein, all previous diagrams are reproduced but for Q = Q<sup>0</sup> = 0.00922 in Fig[.4.](#page-18-0) It's remarked that the temperature in terms of the horizon radius shows an inflection point that corresponds to a discontinuity in the first derivative of the Gibbs free energy and an inflection point in the Landau function (green curve). Thus, we have a new black hole phase called intermediate black holes which is an unstable phase like the unstable small black holes as we can see in Fig[.4c](#page-18-0) where this phase corresponds to a local maximum of Landau function. Moreover, we see in Fig[.4d](#page-18-0) that the landau function is increasing in terms of black hole volume which is a signature of the instability. We

see in Fig[.4e](#page-18-0) that γ-function has two fixed points, one is unstable which corresponds

to Hawking-Page-like and indicates that the temperature is minimal at this point, while the second fixed point is semi-stable and which separates two unstable phases (small and intermediate black holes) and corresponds to an inflection point in the behavior of the temperature. Finally, Fig[.4f](#page-18-0) reveals that the black hole is similar to AdS Schwarzschild black holes where only the thermal radiations and large black hole phases are globally stable.

#### • Now, the charge is set to Q = 0.01 in Fig[.5](#page-19-0)

We notice that the temperature curve as a function of the horizon radius presents two minimums (gray points), one is local (r<sup>h</sup> = 0.07) and the other is global (r<sup>h</sup> = 0.52). In addition, it has a local maximum at (r<sup>h</sup> = 0.18). These minima and maxima correspond to discontinuities in the first derivative of the Gibbs free energy and inflection points in the Landau function (magenta, orange, and black curves). Thus, we are in the presence of four black hole phases, two stable phases which are large and stable small black holes (dark red and orange points respectively), and two unstable phases which are unstable small and intermediate black holes (dark blue and green points respectively) as illustrated in Fig[.5c,](#page-19-0) where these phases correspond to local minimums and maximums of the Landau function. Moreover, we see in Fig[.5d](#page-19-0) that the landau function is decreasing in terms of black hole volume for the stable phases and it is increasing for unstable ones. In addition, one can observe in Fig[.5e](#page-19-0) that γ-function has three fixed points, one is unstable (right point) which separates the large black hole phase and the unstable intermediate black hole one which indicates that the temperature is minimal at this point, the second fixed point is stable (middle point) which disconnects the stable small black holes phase and the unstable intermediate black holes one and corresponds to the temperature maximum, while the third fixed is unstable (left point) which is the limit between the stable small black hole phase and unstable one, it indicates that the temperature has a local minimum at this point. Furthermore, we state that the stable black holes become larger when they get hotter whereas the unstable ones become smaller when they get hotter. Finally, we see in Fig[.5f,](#page-19-0) the black hole is similar to AdS Schwarzschild black holes where only the thermal radiations and large black hole phases are globally stable.

#### • The case of Q = 0.010026 is depicted in Fig[.6](#page-20-0)

At such a charge, the zeroth order phase transition occurs at the intersection point between the stable small black holes branch and the large black holes as depicted in Fig[.6b](#page-20-0) and which corresponds to an inflection point in Landau function in terms of the black hole volume (magenta curve). We illustrate such a phase transition that occurs at a constant temperature by the dashed magenta line in Fig[.6d](#page-20-0) and Fig[.6e.](#page-20-0) The zeroth order phase transition occurs between the unstable state (gray point) and the large black hole phase. We ought to mention that at this charge begins the appearance of first-order phase transition and reentrant phase transition those we shall see next case. Finally, we see in Fig[.6f,](#page-20-0) the black hole reminiscents the AdS Schwarzschild black holes as in previous cases.

• Going further in our construction of phase picture, we consider now the case of Q = 0.01009, in Fig[.7,](#page-21-0) in fact, we plot the temperature as a function of horizon radius r<sup>h</sup> (Fig[.7a\)](#page-21-0), Gibbs free energy in terms of temperature (Fig[.7b\)](#page-21-0), Landau function L versus X parameter within a variety of temperature (Fig[.7c\)](#page-21-0), Landau function L in terms of the black hole volume V Fig[.7d,](#page-21-0) γ-function in terms of the black hole volume V (Fig[.7e\)](#page-21-0) and on-shell Gibbs free energy-temperature G˜ − T diagram (Fig[.7f\)](#page-21-0).

In this case, we observe a reentrant phase transition LBH→SBH→LBH. Indeed, we notice in Fig[.7b](#page-21-0) that we have a zeroth order phase transition between large black holes and small black holes (following the magenta dashed line), this phase transition corresponds to a jump in Gibbs free energy. Moreover, we have a first-order phase transition between small black holes and large ones (purple dashed line) characterized by the swallowtail shape in Gibbs free energy curve. In Fig[.7d](#page-21-0) and Fig[.7e.](#page-21-0) Additionally, we remark that the large black hole (red curve) can jump to a small black hole (following the magenta dashed line) keeping the temperature constant then it can undergo a firstorder transition to a large black hole phase again. Finally, from Fig[.7f,](#page-21-0) and again the black hole mimics Schwarzschild-AdS black hole.

• Increasing the charge to reach Q = 0.010128 in Fig[.8](#page-22-0)

The system exhibits always a first-order phase transition between small black holes and large ones following the dashed purple line whereas the zeroth-order phase transition is carried out between two unstable points following the magenta line. From this electric charge, the zeroth order phase transition shall disappear as we will see next case. Therefore, the reentrant phase transition that characterized Born-Infeld-AdS black hole will disappear. Finally, we see in Fig[.8f](#page-22-0) that the situation remains the same.

• In Fig[.9,](#page-23-0) we reach Q = 0.0105

The key remark is that the zeroth order phase transition has disappeared and consequently there is no reentrant phase transition. The system processes just the first-order phase transition between small black holes and large ones, whereas there is always the Hawking-Page-like phase transition between the unstable small black holes and stable ones and consequently there is no black hole below T = 0.226. Finally, we see in Fig[.9f](#page-23-0) that we have two critical points. the first one corresponds to the Hawking-Page-like transition between thermal radiations and small black holes, while the second one is associated with the first-order phase transition between small and large black holes. Therefore, we have three globally stable phases: thermal radiations, small, and large black holes.

• The phase portrait corresponding to Q = Q<sup>m</sup> = 0.0113682 is depicted in Fig[.10](#page-24-0) Obviously, we are in a Reissner-Nordstrom-like situation, we have a first-order phase transition between small and large black holes (purple arrow) with an unstable intermediate phase.

- Fig[.11](#page-25-0) is associated with the case Q = Q<sup>c</sup> = 0.0136024 The panels unveil a critical behavior where (block dot) a second phase transition occurs between small and large black holes at exactly T = 0.265.
- The case related to Q = 0.0154 is illustrated in Fig[.12,](#page-26-0) where we have depicted just the temperature as a function of horizon radius r<sup>h</sup> (Fig[.12a\)](#page-26-0), Gibbs free energy-temperature diagram (Fig[.12b\)](#page-26-0), Landau function L in terms of the parameter X for different temperatures (Fig[.12c\)](#page-26-0), then in terms of the black hole volume V in Fig[.12d](#page-26-0) panel. The last panel is devoted to γ-function versus the black hole volume V (Fig[.12e\)](#page-26-0).

The phase diagram of the Born-Infeld-AdS black hole is depicted in Fig[.13.](#page-27-0) We have displayed in Fig[.13a](#page-27-0) the Q − V diagram where the flow represented by arrows indicates the temperature gradient. We clearly distinguish four different local phases: stable small black holes (SSBH), unstable small black holes (USBH), intermediate black holes (IBH), and large black holes (LBH), the gray zone represents the zone where the black hole cannot exist and which delimited by the extremal black hole case. The pink zone indicates the region where the thermal radiation is the globally stable phase, that is to say, it corresponds to temperatures below the Hawking-Page temperature. We notice that the locally stable black holes correspond to a right-oriented temperature gradient which means that the black hole becomes hotter when it gets larger, whereas, the locally unstable black holes correspond to a left-oriented temperature gradient traducing that the black hole becomes hotter when it gets smaller and consequently evaporates. For a more deep probing, in Fig[.13b,](#page-27-0) we illustrate the Hawking-Page transition temperature THP , the first order phase transition temperature T<sup>f</sup> and the zeroth order phase transition temperature T<sup>z</sup> as a function of electric charge Q. From such a panel, various remarks can be deduced, first the zeroth order phase transition temperature T<sup>z</sup> is always below the Hawking-Page transition temperature THP , which means that the zeroth order phase transition can not occur. Second, the first order phase transition can occur where Q > Qm. Further, in Fig[.13c,](#page-27-0) we establish the on-shell Gibbs free energytemperature T-electric charge Q diagram, and from which one can see that we are in the presence of three globally stable phases: large black holes, thermal radiations, and small black holes.

The phase diagram of the Born-Infeld-AdS black hole can be characterized by three electric charge values as follow

♦ For Q < Q<sup>t</sup> = 0.0103638, we have just two globally stable phases, thermal radiation, and a large black hole, then consequently there is only one possible phase transition which is the Hawking-Page phase transition. Therefore, there is neither first-order phase transition nor zeroth-order phase transition as it was shown in [\[55\]](#page-54-5). Indeed, in [\[55\]](#page-54-5), authors have shown that the reentrant phase transition occurs for 0.010026 < Q < 0.10128 but they had not proved that the intermediate black holes are globally stable for these values of electric charge. To conclude, for Q < Q<sup>t</sup> , the Born-Infeld-AdS black hole is Schwrazchild-like, there are only two globally stable phases that are connected by Hawking-Page phase transition. Moreover, there is no extremal (no vanishing temperature) which confirms the results of [\[58\]](#page-55-1).

- ♦ For Q<sup>t</sup> < Q < Q<sup>m</sup> = 0.0113682, we have three globally stable phases, thermal radiation (pink zone), small stable black hole (SSBH), and large black hole (LBH) with two possible critical points as we have shown in Fig[.9.](#page-23-0) Indeed, there are two possible phase transitions, the first one is between thermal radiations and small black holes, it's a Hawking-Page-like transition; the second one is the first order phase transition between small and large black holes like that is observed in Reissner-Nordstr¨om-AdS black holes [\[53\]](#page-54-3). Moreover, for Q = Q<sup>t</sup> , we have a triple point where thermal radiation, small, and large black holes coexist together.
- ♦ For Q<sup>m</sup> < Q < Q<sup>c</sup> = 0.0136024, the Born-Infeld-AdS black hole is similar to the Reissner-Nordstr¨om-AdS black hole case, and in such a situation we got two globally stable phases and a first-order phase transition between small and large black holes. Moreover, we could have an extremal state where the black hole becomes sufficiently small. Therefore, there is no thermal radiation phase, and the Hawking-Page-like transition disappears.
- ♦ For Q > Qc, there is only one globally stable phase which is the large black holes phase as in Reissner-Nordstr¨om-AdS black hole. Besides, for Q = Q<sup>c</sup> the black hole exhibits a second-order phase transition between small and large black holes.

Therefore, one concludes that the Born-Infeld-AdS black hole can unveil a triple point where the three globally stable phases can coexist. In Fig[.14](#page-28-0) we illustrate the temperature as a function of horizon radius r<sup>h</sup> (Fig[.14a\)](#page-28-0), Gibbs free energy in terms of temperature (Fig[.14b\)](#page-28-0), Landau function L in terms of the parameter X for different temperatures (Fig[.14c\)](#page-28-0), and in terms of the black hole volume V Fig[.14d,](#page-28-0) γ-function versus the black hole volume V (Fig[.14e\)](#page-28-0), and in the last panel (Fig[.14f\)](#page-28-0), the on-shell Gibbs free energy G˜ as a function of temperature.

<span id="page-17-0"></span>![](_page_17_Figure_0.jpeg)

Figure 3: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.005, l = 1, and b = 3.5.

<span id="page-18-0"></span>![](_page_18_Figure_0.jpeg)

Figure 4: (a) Temperature versus event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.00922, l = 1, and b = 3.5.

<span id="page-19-0"></span>![](_page_19_Figure_0.jpeg)

Figure 5: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.01, l = 1, and b = 3.5.

<span id="page-20-0"></span>![](_page_20_Figure_0.jpeg)

Figure 6: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.010026, l = 1, and b = 3.5.

<span id="page-21-0"></span>![](_page_21_Figure_0.jpeg)

Figure 7: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.01009, l = 1, and b = 3.5.

<span id="page-22-0"></span>![](_page_22_Figure_0.jpeg)

Figure 8: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.010128, l = 1, and b = 3.5.

<span id="page-23-0"></span>![](_page_23_Figure_0.jpeg)

Figure 9: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature and the pink region indicates where the thermal radiation phase is the global stable phase  $(T < T_{HP})$  with Q = 0.0105, l = 1, and b = 3.5.

<span id="page-24-0"></span>![](_page_24_Figure_0.jpeg)

Figure 10: (a) Temperature versus the event horizon radius rh. (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V . (e) γ-function in terms of the black hole volume V . (f ) On-shell Gibbs free energy G˜ as a function of temperature T. The arrows indicate the evolution of the temperature. The arrows indicate the evolution of the temperature with <sup>Q</sup> <sup>=</sup> <sup>Q</sup><sup>m</sup> = 0.0113682, <sup>l</sup> = 1, and <sup>b</sup> = 3.5. 25

<span id="page-25-0"></span>![](_page_25_Figure_0.jpeg)

Figure 11: (a) Temperature versus the event horizon radius rh. (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V . (e) γ-function in terms of the black hole volume V . (f ) On-shell Gibbs free energy G˜ as a function of temperature T. The arrows indicate the evolution of the temperature. The arrows indicate the evolution of the temperature with Q = Q<sup>c</sup> = 0.0136024, l = 1, and b = 3.5. 26

<span id="page-26-0"></span>![](_page_26_Figure_0.jpeg)

Figure 12: (a) Temperature versus the event horizon radius rh. (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V . (e) γ-function in terms of the black hole volume V . The arrows indicate the evolution of the temperature with Q = 0.015, l = 1, and b = 3.5.

<span id="page-27-0"></span>![](_page_27_Figure_0.jpeg)

Figure 13: (a) Q − V diagram of Born-Infeld-AdS black hole; the flow indicates the temperature gradient. (b) Critical temperatures as a function of electric charge. (c) On-shell Gibbs free energy as a function of temperature and electric charge. l = 1 and b = 3.5.

<span id="page-28-0"></span>![](_page_28_Figure_0.jpeg)

Figure 14: (a) Temperature versus the event horizon radius  $r_h$ . (b) Gibbs free energy-temperature diagram. (c) Landau function L in terms of the parameter X for different temperatures. (d) Landau function L in terms of the black hole volume V. (e)  $\gamma$ -function in terms of the black hole volume V. (f) On-shell Gibbs free energy  $\tilde{G}$  as a function of temperature T. The arrows indicate the evolution of the temperature. The arrows indicate the evolution of the temperature with  $Q = Q_t = 0.0103638$ , l = 1, and l = 3.5.

Fig.14 reveals that Hawking-Page phase transition temperature  $T_{HP}$  coincides with first-order phase temperature  $T_f$ , which means that Hawking-Page transition and first-order phase transition occur simultaneously. Therefore, we have an equilibrium between thermal radiations, small black holes, and large black holes.

Having constructed a complete phases transitions picture of the Born-Infeld-AdS black hole through the Landau formalism, we will turn our attention in the next section to a new thermodynamical tool lent from the dynamical systems context and which nowadays has been used extensively in the literature. Namely the Fokker-Planck equation.

# <span id="page-29-0"></span>5 Fokker-Planck equation and its use to determine the probabilistic nature on the free energy landscape

It was recently developed in [16] a new method for examining the dynamic process of phase transition on the free energy landscape, demonstrating that a black hole can escape from one phase to another due to thermal fluctuations. Then in [59], the authors investigated the criticality of RN-AdS black holes from the perspective of the free energy landscape, obtaining the probability distribution of states and the time distribution of the first passage kinetic process of black hole state switching. Within this perception, we will probe the Born-Infeld-AdS black hole phase structure via such a formalism.

As in [59] and for the sake of simplicity, the horizon radius  $r_h$  will be noted simply as r, thus the Gibbs free energy which is written in terms of the order parameter r will be noted G(r). In what follows and in order to unveil the evolutional response of the system under thermal fluctuation, we shall take the probability distribution of these evolving states over time to be a function of the order parameter r and the time t. Hence,  $\rho(r,t)$  stands for the probability distribution of the spacetime state in the ensemble.

The explicit Fokker-Planck equation for the probabilistic evolution on the free energy landscape is obtained to be [60,61]

<span id="page-29-1"></span>
$$\frac{\partial \rho(r,t)}{\partial t} = D \frac{\partial}{\partial r} \left[ e^{-\beta G(r)} \frac{\partial}{\partial r} \left[ e^{\beta G(r)} \rho(r,t) \right] \right], \tag{29}$$

in which  $\beta = 1/k_BT$  denotes the inverse temperature and  $D = k_BT/\zeta$  stands for the diffusion coefficient with  $k_B$  is the Boltzmann constant while  $\zeta$  called dissipation coefficient. For commodity and by preserving the generality, one will set  $k_B$  and  $\zeta$  equal to the unit in the rest of our analysis.

Depending on the considered question, two types of boundary conditions should be enforced at the computing domain's boundaries in order to solve the Fokker-Planck equation. For instance, at  $r = r_0$ , we provide the following boundary conditions

• A reflecting boundary condition:

$$\frac{\partial}{\partial r} \left[ e^{\beta G(r)} \rho(r, t) \right] \bigg|_{r=r_0} = 0. \tag{30}$$

• Then, an absorbing boundary condition:

$$\rho(r_0, t) = 0. \tag{31}$$

Within the canonical ensemble, we investigate the time evolution of the probability of state distribution. During the evolution phase, the reflecting border condition will maintain probability conservation and the initial condition is selected as Gaussian packet<sup>1</sup>

$$\rho(r,0) = \frac{1}{\sqrt{\pi a}} e^{-(r-r_i)^2/a^2}, \quad \text{with} \quad a \le 0.01.$$
 (32)

By taking the partial derivative  $\frac{\partial \rho(r,t)}{\partial t} = 0$  null in the Fokker-Planck equation, one can achieve the final stationary distribution as  $\rho(r,t_{\infty}) \propto \exp(-G(r)/T)$ . This is in accordance with the Boltzmann link between free energy and equilibrium probability distribution. In fact, as a result of the long-time evolution, the stationary distribution reaches the equilibrium probability. Therefore, the maximum of the final stationary distribution is then used to define the thermodynamic stable state [17].

We propose investigating the time-dependent characteristics of black hole probability distributions in extended phase space at various electrical charges and temperatures.

• For Q = 0.01009: In [55], authors affirmed that there is a reentrant phase transition between the small and large black hole, nevertheless, we shall show that there is no reentrant phase transition and only thermal radiations and large black holes phases are globally stable and most probable states. We plot <sup>2</sup> in Fig.15 the probability distribution  $\rho(r,t)$  governed by Fokker-Planck equation for different temperatures with Q = 0.01009, l = 1 and b = 3.5. For  $T = T_z = 0.2718$ ,

where it is supposed to occur a reentrant phase transition (zeroth order phase transition), we observe that the probability  $\rho(r,t)$  which is initially centered around the small black hole state,  $r_i = 0.0707$ , leaks quickly to thermal radiations state, r = 0, which is the only globally stable state where the probability is maximal. This result is another proof that there is no reentrant phase transition because  $\rho(r_l, t_\infty) < \rho(r_s, t_\infty) < \rho(r = 0, t_\infty)$ , where  $r_l = 0.6332$  and  $r_s = 0.0707$  are the large and the small black holes horizon radii respectively, and the thermal radiations is the most stable phase. Afterward, in the second line of the figure, we consider  $T = T_{HP} = 0.2783$ , which corresponds to the Hawking-Page transition, one can notice that the probability  $\rho(r,t)$  which is initially centered around the large black hole state,  $r_i = 0.7138$ , leaks quickly to thermal radiations state, i.e r = 0, then it comes back to form another peak around the large black hole state, and by the end, we have  $\rho(r = 0, t) = \rho(r_l, t)$  traducing the

<span id="page-30-0"></span><sup>&</sup>lt;sup>1</sup>In the numerical calculation processes, a Gaussian wave packet is a good approximation of the  $\delta$  distribution and it's extensively used.

<span id="page-30-1"></span> $<sup>^2</sup>y$ -axis is rescaled with a logarithmic scale such that  $y \longrightarrow 10^{50(y-1)} \left( y \longleftarrow \frac{\log(y)}{50} + 1 \right)$ 

coexistence of the large black hole and the thermal radiations where the probability is maximal. In the bottom panels where we have taken T = 0.2937, one can remark that the probability ρ(r, t) which is initially centered around the large black hole state, r<sup>i</sup> = 0.8448, leaks quickly to thermal radiations state (r = 0), then as t increases, the thermal radiations phase probability decreases wheres the large black holes phase probability increases forming a peak around r<sup>l</sup> . Therefore, the large black holes phase is the most probable and stable phase.

• For the charge value Q = Q<sup>t</sup> = 0.0103638, associated with Fig[.14](#page-28-0) in which we have shown the existence of a triple point, we suggest confirming this funding through the probability distribution. To this end, we depict in Fig[.16](#page-35-0) the probability distribution ρ(r, t) ruled by the Fokker-Planck equation for different temperatures with Q = Q<sup>t</sup> = 0.01009, l = 1 and b = 3.5. For T = 0.25,

It's remarked that the probability ρ(r, t) initially centered around the small black hole state, r<sup>i</sup> = 0.0805, leaks immediately to thermal radiation state, r = 0 associated with the only globally stable state where the probability is maximal. Indeed, ρ(rs, t∞) < ρ(r = 0, t∞), where r<sup>s</sup> = 0.0805 is the small black hole horizon radius, and then the thermal radiations is the most stable phase confirming our previous result that the thermal radiation is the only globally stable phase. Increasing the temperature to T = T<sup>t</sup> = 0.276, we notice that the probability ρ(r, t) which is initially centered around the large black hole state, r<sup>i</sup> = 0.6909, leaks quickly to thermal radiations state, r = 0, but after then it comes back to form two peaks around the small and the large black holes horizon radii. Thus, we are in presence of a triple point, i.e a location where the thermal radiations, small black holes, and large black holes coexist together. Indeed, ρ(rs, t∞) = ρ(r<sup>l</sup> , t∞) = ρ(r = 0, t∞) where r<sup>s</sup> = 0.1177 and r<sup>l</sup> = 0.6909, the three phases are equiprobable and globally stable. Now reaching T = 0.29, we see that the probability ρ(r, t) initially centered around the large black hole state, r<sup>i</sup> = 0.8172, leaks rapidly to thermal radiation and small black hole states forming the same shape as in triple point case, but after then ρ(r = 0, t) and ρ(rs, t) decrease with the time whereas ρ(r<sup>l</sup> , t) increases to reach its maximum. Therefore, ρ(r = 0, t∞) < ρ(rs, t∞) < ρ(r<sup>l</sup> , t∞) where r<sup>s</sup> = 0.1418 and r<sup>l</sup> = 0.8172, and the large black holes phase is the most probable state and then the only globally stable phase.

• Now, with Q = 0.0105 that corresponds to Fig[.9](#page-23-0) and where we have unveiled the existence of two critical points at such a value of charge, that is to say, two-phase transitions occur, the first one is between thermal radiation and small black holes phases which is a Hawking-Page-like transition, while the second one is a first-order phase transition between small and black holes phases. We illustrate in Fig[.17](#page-36-0) the probability distribution ρ(r, t) derived from the Fokker-Planck equation for different temperatures around thermal radiations-small black holes transition with Q = 0.0105, l = 1 and b = 3.5. For T = 0.227,

Such a figure reveals serval remarks, one can first notice that the probability ρ(r, t)

which initially centered around the small black hole state, r<sup>i</sup> = 0.0599, leaks fast to the thermal radiation state, r = 0, which is the only globally stable state where the probability is maximal. Indeed, ρ(rs, t∞) < ρ(r = 0, t∞), where r<sup>s</sup> = 0.0599, and then the thermal radiations is the most stable phase which confirms our previous result that the thermal radiation is the only globally stable phase. Second, for T = THP = 0.25708, which corresponds to the Hawking-Page-like transition between thermal radiation and small black holes phases, we see that the probability ρ(r, t) which is initially centered around the small black hole state, r<sup>i</sup> = 0.1034, leaks quickly to thermal radiations state, r = 0, then it comes back to form another peak around the small black hole state, and by the end, one achieves ρ(r = 0, t) = ρ(rs, t), at r<sup>s</sup> = 0.1034, and then the coexistence of the small black hole and the thermal radiations at the maximum of the probability. The third situation associated with T = 0.272 reveals that the probability ρ(r, t) which is initially centered around the small black hole state, r<sup>i</sup> = 0.1226, leaks quickly to thermal radiations state i.e r = 0, then as t increases, the thermal radiations phase probability decreases whereas the small black holes phase probability increases forming a maximal peak around rs. Therefore, the small black holes phase is the most probable and the most stable phase.

Within Fig[.18,](#page-37-0) we depict the probability distribution ρ(r, t) for different temperatures around small-large black holes transition with the same parameters as in Fig[.17.](#page-36-0)

For T = T<sup>f</sup> = 0.2753 corresponding to the first-order phase transition between small and large black holes phases, we observe that the probability ρ(r, t) which is initially centered around the large black hole state, r<sup>i</sup> = 0.6838, leaks rapidly to thermal radiations state, r = 0, then it comes back to form two peaks around the small and the large black holes horizon radii. Thus, we have a critical point where the small black hole and the large black hole coexist together. Indeed, ρ(rs, t∞) = ρ(r<sup>l</sup> , t∞) where r<sup>s</sup> = 0.1273 and r<sup>l</sup> = 0.6838, the two phases are both equiprobable and globally stable. Once the system reaches T = 0.29, we notice that the probability ρ(r, t) which is initially centered around the large black hole state, r<sup>i</sup> = 0.8177, leaks now quickly to thermal radiations and small black hole states forming the same shape as in critical point case, but after then ρ(rs, t) decreases with the time whereas ρ(r<sup>l</sup> , t) increases to reach its maximum. Therefore, ρ(rs, t∞) < ρ(r<sup>l</sup> , t∞) where r<sup>s</sup> = 0.1542 and r<sup>l</sup> = 0.8177, and the large black holes phase is the most probable state and then the only globally stable phase.

Now we focus on what happens in the triple point where we the coexistence of three globally stable phases: thermal radiation at r = 0, the small black hole at rs, and the large black hole at r<sup>l</sup> . To a clear illustration, we plot in Fig[.19](#page-38-0) the evolution of ρ(rk, t) [3](#page-32-0) when the initial Gaussian wave packet peaks at large or small black hole states.

We observe that the initially large valueρ(rl,s, t = 0) in each case rapidly decays to a stationary value, while the other two states (initially zero) grow toward this value.

<span id="page-32-0"></span><sup>3</sup> r<sup>k</sup> = 0, rs, r<sup>l</sup>

Henceforth, considering the first case shown Fig[.19a,](#page-38-0) the initial Gaussian wave packet ρ(r, t = 0) peaks at the large black hole phase with ρ(r<sup>l</sup> , t = 0) = 56.4189, while ρ(r = 0, t = 0) ' ρ(rs, t = 0) ' 0. As t increases ρ(r<sup>l</sup> , t) decreases (red curve), and ρ(r = 0, t) and ρ(rs, t) increase (blue and green curves respectively) as expected, with ρ(r = 0, t) < ρ(rs, t) because the initial state must surmount two barriers to reach thermal radiations state as we can see in Fig[.20.](#page-38-1) Indeed, we see in Fig[.20](#page-38-1) where we have displayed the Gibbs free energy via landscape at the triple point that we have three wells (blue, green, and red dots) with the same depth separated by two barriers (magenta and orange dots) and then a large black hole located at r<sup>l</sup> should surmount the two barriers to reach r = 0. The transition rate from the large to small black hole state is higher than the total rate from the small to the large black hole and thermal state states. Once t > 20, ρ(r = 0, t) = ρ(rs, t) = ρ(r<sup>l</sup> , t) = 0.4377 , where the final stationary state is achieved. During the evolution, we notice that ρ(rs, t) increases to a maximum of 0.7043 at t = 0.8544 and then decreases with time to its stationary value of 0.4377. This behavior occurs because the small black hole state can transit to both thermal radiation and large black hole states, while the system will stay longer at the small black hole and the thermal radiation states because the barrier between them is relatively small than the large black hole state. As the small black hole and thermal radiation states become more populated, they will transit back to the large black hole state. Because ρ(rs, t) and ρ(r = 0, t) can be greater than ρ(r<sup>l</sup> , t), we refer to this behavior as a strong oscillatory phenomenon [\[20\]](#page-52-6).

Considering second case shown Fig[.19b,](#page-38-0) the initial Gaussian wave packet ρ(r, t = 0) peaks at the small black hole phase with ρ(rs, t = 0) = 56.4189, while ρ(r = 0, t = 0) ' ρ(r<sup>l</sup> , t = 0) ' 0. As expected, ρ(rs, t = 0) decreases whereas ρ(r = 0, t = 0) and ρ(r<sup>l</sup> , t = 0) both increase. Once t > 20, ρ(r = 0, t) = ρ(rs, t) = ρ(r<sup>l</sup> , t) = 0.4377, where the final stationary state is achieved as in the previous case. During the evolution, we observe that the probability leaks from the small black hole state to both thermal radiations and large black hole states, with ρ(r = 0, t) increasing faster than ρ(r<sup>l</sup> , t) because of the lower barrier height shown in Fig[.20.](#page-38-1) Moreover, we see that ρ(r = 0, t) increases quickly to a maximum of 4.1097 at t = 0.0245 and then decreases with time to its stationary value of 0.4377. In addition, for t > 0.0205, we have ρ(r = 0, t) > ρ(rs, t) > ρ(r<sup>l</sup> , t), which means that ρ(r = 0, t) is dominant among the three probabilities, indicating that the system has a large probability of staying at the thermal radiations state. Since ρ(r = 0, t) dominates, we refer to this behavior (similar to that observed in the previous case) as a strong oscillatory phenomenon. During the evolution of ρ(r<sup>l</sup> , t), we observe that it increases to a maximum of 0.7043 at t = 0.8551 and then decreases with time to its stationary value of 0.4377. Since ρ(r<sup>l</sup> , t) is always smaller than ρ(rs, t), such a behavior is known as a weak oscillatory phenomenon [\[20\]](#page-52-6).

<span id="page-34-0"></span>![](_page_34_Figure_0.jpeg)

Figure 15: Probability distribution ρ(r, t) governed by Fokker-Planck equation for different temperatures with Q = 0.01009, l = 1 and b = 3.5.

<span id="page-35-0"></span>![](_page_35_Figure_0.jpeg)

Figure 16: Probability distribution ρ(r, t) governed by Fokker-Planck equation for different temperatures with Q = Q<sup>t</sup> = 0.0103638, l = 1 and b = 3.5.

<span id="page-36-0"></span>![](_page_36_Figure_0.jpeg)

Figure 17: Probability distribution ρ(r, t) governed by Fokker-Planck equation for different temperatures around thermal radiations-small black holes transition with Q = 0.0105, l = 1 and b = 3.5

<span id="page-37-0"></span>![](_page_37_Figure_0.jpeg)

Figure 18: Probability distribution ρ(r, t) governed by Fokker-Planck equation for different temperatures around small-large black holes transition with Q = 0.0105, l = 1 and b = 3.5

<span id="page-38-0"></span>![](_page_38_Figure_0.jpeg)

<span id="page-38-1"></span>Figure 19: Behaviors of the probability ρ(r, t) at the triple point, when the initial Gaussian wave packet is peaked at the (a) large and (b) small black hole states, with Q = Q<sup>t</sup> = 0.0103638, T = T<sup>t</sup> = 0.276, l = 1 and b = 3.5.

![](_page_38_Figure_2.jpeg)

Figure 20: Gibbs free energy via landscape at the triple point with Q = Q<sup>t</sup> = 0.0103638, T = T<sup>t</sup> = 0.276, l = 1 and b = 3.5.

#### <span id="page-39-0"></span>6 Kinetics: First passage process

In a triple point setting where thermal radiation, large, and small black hole states are coexisting, we will explore the kinetics of the first passage event from one black hole state to another. The time required for the black hole state to reach an unstable black hole phase, as represented by the free energy peak, is characterized as the first passage time. The mean first passage time denotes the average timescale for a stochastic event to occur for the first time [17]. From Fig.20, we have three cases: thermal radiations to the small black holes (case 1), small black holes to thermal radiations and large black holes (case 2), and large black holes to small black holes (case 3).

The distribution of first passage times is defined as  $F_p(t)$ , where  $\Sigma(t)$  is the probability that the state of the black hole hasn't performed a first passage by time t.  $F_p(t)$  and  $\Sigma(t)$  distributions are connected by

<span id="page-39-1"></span>
$$F_p(t) = -\mathcal{A}\frac{d\Sigma(t)}{dt},\tag{33}$$

herein,  $\mathcal{A}$  is nothing than a normalization constant such that  $\int_0^{+\infty} F_p(t)dt = 1$ . The definition of  $\Sigma(t)$  is the probability of a black hole being present in the system at time t [17]. Hence, we get

<span id="page-39-2"></span>
$$\Sigma_1(t) = \int_0^{r_1} \rho(r, t) dr, \tag{34}$$

<span id="page-39-3"></span>
$$\Sigma_2(t) = \int_{r_1}^{r_2} \rho(r, t) dr, \tag{35}$$

<span id="page-39-4"></span>
$$\Sigma_3(t) = \int_{r_2}^{+\infty} \rho(r, t) dr. \tag{36}$$

We apply reflective boundary conditions at r=0 and  $r=+\infty$  (sufficiently big r) and absorbing boundary conditions at  $r_1$  and  $r_2$  peaks. We assumed that the time required to transition from the intermediate transition state of the black hole to the large black hole state is substantially shorter than the first passage time. Furthermore, if a black hole state makes the first passage via thermal fluctuation, the black hole state exits the system. In this case, the probability distribution's normalization will not be kept.

Using Eqs.(33), (34), (35), (36) and the Fokker-Planck equation Eq.(29), one can express the first passage rate  $F_p(t)$  for the three cases as <sup>4</sup>

$$F_{p1}(t) = \mathcal{A}_1 \left( -\left. \frac{\partial \rho(r,t)}{\partial r} \right|_{r=r_1} + \frac{1}{T} \left. \rho(r,t) \frac{\partial G(r)}{\partial r} \right|_{r=0} \right), \tag{37}$$

$$F_{p2}(t) = \mathcal{A}_2 \left( -\left. \frac{\partial \rho(r,t)}{\partial r} \right|_{r=r_2} + \left. \frac{\partial \rho(r,t)}{\partial r} \right|_{r=r_1} \right), \tag{38}$$

<span id="page-39-5"></span><sup>&</sup>lt;sup>4</sup>We have used  $\lim_{r \to +\infty} \rho(r,t) = 0$ 

$$F_{p3}(t) = \mathcal{A}_3 \left. \frac{\partial \rho(r,t)}{\partial r} \right|_{r=r_2}.$$
 (39)

We may calculate the mean first passage time and its relative fluctuation using the time distributions. The average first passage time is given by

$$\langle t \rangle = \int_0^{+\infty} t F_p(t) dt, \tag{40}$$

while the relative fluctuation is obtained to be

$$\mathfrak{f} = \frac{\langle t^2 \rangle - \langle t \rangle^2}{\langle t \rangle^2}.\tag{41}$$

We suggest studying just the second and the third cases because the initial state in the first case coincides with the boundary r = 0, and we have the numerical instabilities<sup>5</sup>. The numerical results for  $F_{p2}(t)$  and  $F_{p3}(t)$  are plotted in Fig.21a. For each case, there is a single peak at  $t_2 = 0.0041$  and  $t_3 = 0.1986$ , which can be interpreted as the length of time at which the system remains in its initial state for each before first transiting to another state. For the second case (green curve), the system transits to other states (thermal radiation and large black hole) after a short time, whereas for the third case (red curve), the system remains in the large black hole state longer. The mean first passage time for the second case is  $\langle t_2 \rangle = 0.0856$  with a relative fluctuation  $\mathfrak{f}_2 = 2.3474$ , whereas, for the third case,  $\langle t_3 \rangle = 3.3835$  with a relative fluctuation  $\mathfrak{f}_3 = 1.9227$ .

In order to understand the behavior observed in Fig.19, we depict the two parts of  $F_{p2}(t)$  in Fig.21b where  $F_{p21}(t)$  (magenta curve) is the distribution of first passage time from small black hole to thermal radiation, and  $F_{p22}(t)$  (orange curve) is the distribution of first passage time from small black hole to the large black hole. Obviously, each distribution shows a single peak at  $t_{21} = t_2 = 0.0041$  and  $t_{22} = 0.1387$ . The mean first passage time for each situation is  $\langle t_{21} \rangle = 0.0612$  with a relative fluctuation  $\mathfrak{f}_{21} = 2.9721$ , and  $\langle t_{22} \rangle = 0.2550$  with a relative fluctuation  $\mathfrak{f}_{22} = 0.4081$ .

Moreover, we remark that  $\langle t_{21} \rangle < \langle t_{22} \rangle$ , which means that when the initial state peaks at the small black hole phase, the system transits suddenly to thermal radiations phase as we have seen in Fig.19b where  $\rho(r=0,t)$  increases very quickly and passes over  $\rho(r_s,t)$ , whereas  $\rho(r_l,t)$  increases slowly before to reach its maximum with  $\rho(r_l,t)$  is always smaller than  $\rho(r_s,t)$  because the transition to large black hole phase takes more time than the transition to thermal radiations which explains the weak oscillations observed in this case. Indeed, the barrier height between the small black hole and thermal radiation is smaller than that between small and large black holes. When the initial state peaks at the large black hole phase, the transition takes quite more time ( $\langle t_3 \rangle < \langle t_2 \rangle$ ) to transit to the small black hole phase, and after then the system can transit quickly to thermal radiations phase. Moreover, we see in Fig.21c that  $F_{p22}(t) \neq F_{p3}(t)$ , which means that the transition between

<span id="page-40-0"></span><sup>&</sup>lt;sup>5</sup>due to the limits of performance associated with our calculator and the smallness of the studied domain

<span id="page-41-0"></span>![](_page_41_Figure_0.jpeg)

Figure 21: (a) First passage time distribution for cases 2 and 3. (b) First and second parts of the first passage time for Fp2(t). (c) First passage time distribution for case 3 and the second part of the first passage time for Fp2(t).

small and large black holes is not symmetric with ht3i < ht22i. That is to say, a large black hole takes more time to transit to a small black hole even though the height of the barrier is the same. Nevertheless, the relative fluctuation of first passage time is very important in the transition from a large black hole to a small black hole (f<sup>3</sup> > f22), and that what could explain the strong oscillatory behavior observed in Fig[.19a.](#page-38-0)

## Conclusion

The connection of gravity, thermodynamics, and quantum field theory is an essential tool to probe the quantum nature of black holes. The thermodynamic analysis and the phase transition behavior during the black hole evaporation might be a crucial areas of investigation to determine the microscopic description of the black hole thermodynamics in particular, and the spacetime structure in general. One possible way to investigate such microscopic structure is probed through the dynamic and kinetic evolution of the black hole during the thermal phase transitions. This paper is devoted to inquiring into the small black hole and the large black hole phases as well as the reentrant phase transition for the Born-Infeld-AdS black holes from the perspectives of the free energy landscape via the Landau free energy formalism and the stochastic processes through a certain probability distribution using the Fokker-Planck equation.

We start with a brief discussion of the Born-Infeld-AdS black hole solutions, the related thermodynamic quantities, and their thermal properties. We then moved on to compute the critical points characterizing different black hole configurations during the phase transitions. We systematically analyze the profile of the heat capacity at a constant electric charge, Q, and study its stable and unstable branches. Depending upon the values of the charge parameter, we categorically discussed the phase transition behavior. For Q < Qm, Q<sup>m</sup> denotes some marginal charge expressed in terms of the Born-Infeld parameter, we have Schwarzschild-AdS-like behavior, whereas for Q ≥ Q<sup>m</sup> we have the characteristics behavior of the heat capacity mimicking that of the Reissner-Nordstr¨om-AdS black holes. The condition Q<sup>m</sup> ≤ Q < Qc, where Q<sup>c</sup> is the critical point, exhibits a first-order phase transition where a small-sized black hole transited into the large black holes. At the critical value Q = Q<sup>c</sup> of the charge parameter, a second-order phase transition occurred between the small and large black holes. For other values of the charge parameter greater than Qc, we observed that the black holes are locally stable, thereby indicating the positive heat capacity.

Next, we focused our attention to explore the thermal phase transition behavior of the Born-Infeld AdS black holes by considering a general prescription of the Landau-free energy functional of the VdW fluids. The Landau functional provides us with a phenomenological description of the VdW fluids when it undergoes a second-order phase transition. The analysis is quite interesting for our present analysis of the Born-Infeld AdS black holes, for that we have to take into account the parameter space {X, T, P, Q} describing the state of the system pertaining to a set of physical conditions to be imposed. Such an analysis actually leads us to connect the thermal behavior among the different states of the VdW-like fluids and the Born-Infeld AdS black holes phases. We computed for such purposes the convexity of the Landau functional to determine its extreme points and the corresponding stable and unstable phases of the thermal black hole systems. We plotted the temperature, T vs. the horizon radius, rh, the Gibbs free energy, G as a function of temperature, T, the Landau functional as a function of the state variable X as well as the volumes, V for different values of the charge parameter Q. As a further investigation of the thermal systems, we also plotted the on-shell Gibbs free energy G˜ as a function of the temperature. When the charge parameter Q = 0.005 < Q0, we have the small and large black hole phases. Note that Q<sup>0</sup> corresponds to the value of the charge parameter where the temperature profile where T − r<sup>h</sup> plot has an inflection point. Therefore, Q = 0.00922 = Q<sup>0</sup> indicated that the first derivative of the Gibbs free energy is discontinuous and thereby indicating a corresponding discontinuity of the Landau functional.

Additionally, the dynamics of the AdS black holes and their kinematical descriptions are well addressed through the thermal fluctuations of the system under study during their evolution process. Since the fluctuating variables need probability distribution during the thermal phase transitions they also need time dependence. Such a description is guided by the probability distribution of the spacetime state in the ensemble designated as ρ(r, t). The thermal phase transitions are mastered through a stochastic process and are a function of the order parameter and the dynamics during its phases are determined through the fluctuating macroscopic variables, the process during the whole evolution is probed by the Fokker-Planck equation. Since the small to large black hole phase transitions or the reentrant phase transition faced a sudden change in the size of the event horizon, and at the critical points the change become vanishing, we referred to the event horizon as an order parameter. We analyzed the stability and the black hole thermal phase transitions of the Born-Infeld-AdS spacetime through heat capacity and Gibbs free energy. Rather than confront the phase transitions during the dynamical evolution, the usual Gibbs free energy is raised to the status of the generalized off-shell Gibbs free energy as a function of the order parameter. Analytical solutions for the order parameter are not possible but a numerical analysis found its lower bound. Having the off-shell Gibbs free energy for different black hole configurations we depicted them for different values of the temperatures. In the next paragraph, we discuss in detail the time-dependent behaviors of the probability distribution function of the Born-Infeld-AdS black holes in the extended phase space for various charge and temperature values.

During the small-large black hole phases, the switching process becomes faster than it existed earlier and the final stationary states should be of Boltzmann type. Such parables of the small-large black hole phases existed in the literature for a wide variety of AdS black hole systems. However, for the AdS black holes in Born-Infeld gravity, the notions of the reentrant phase transitions and the leaking of the small to radiation or the large to radiation phases was an exciting investigation. However, in the process of the dynamical evolution, the charge parameter Q = 0.01009, we ruled out the possible existence of the reentrant phase transition behavior as claimed in the previous literature. The systems instead of going through a reentrant phase transition, it drained down to the pure thermal state and the large black hole phase reflecting the most probable states. At slightly larger values of Q = Q<sup>t</sup> = 0.0103638, the system co-existed as a triple point comprising of the small, large, and thermal phases as was confirmed by the probability distribution. Further slight increase in the charge value, the phase transitions were distilled into two distinct phases, namely, a Hawking-Page-like phase transition between small to radiation, and another first-order phase transition among the small and the large black holes. Lately, we determined the first passage time for the kinetic evolution of different black hole states, particularly for the triple point setup. We observed a finite peak in the distribution of the first passage time for three different cases, (1) pure thermal radiation to the small black hole, (2) small black hole pure thermal radiation and large black hole state, and (3) large black hole to small black hole phases. Such processes occur within a short interval of first passage time.

The study of the frictional effects on the kinetic and dynamics processes is a mustinvestigated research area that we demonstrated a little bit in our current work by calculating the mean first passage time and the corresponding fluctuations. The friction in a dynamical system is accounted for by the microscopic description, thereby speculating ideas about the macroscopic behavior of the AdS black holes (e.g., in terms of the order parameter). A future direction to this work might be worth studying the microscopic degrees of freedom and the interactions of the black hole molecules during the kinetic turnover.

## Acknowledgment

The research of M. S. A. is supported by the National Postdoctoral Fellowship of the Science and Engineering Research Board (SERB), Department of Science and Technology (DST), Government of India, File No., PDF/2021/003491.

### <span id="page-44-0"></span>A Numerical resolution of Focker-Planck equation

#### <span id="page-44-1"></span>A.1 Introduction

We propose two numerical schemes to resolve the Focker-Planck equation in the context of black hole thermodynamics where the temperature T is kept constant in Gibbs G(r) free energy is a function of radial parameter r. Our aim is to find out the probability distribution ρ(r, t). The first method we can use it with NDSolve function of Mathematica whereas the second needs an explicit implementation.

#### <span id="page-44-2"></span>A.2 First Method

The Focker-Planck equation reads

$$\frac{\partial \rho(r,t)}{\partial t} = D \frac{\partial}{\partial r} \left[ e^{-\beta G(r)} \frac{\partial}{\partial r} \left[ e^{\beta G(r)} \rho(r,t) \right] \right], \tag{42}$$

where D = T and  $\beta = 1/T$ . Then

<span id="page-45-0"></span>
$$\frac{\partial \rho(r,t)}{\partial t} = T \frac{\partial}{\partial r} \left[ e^{-\frac{G(r)}{T}} \frac{\partial}{\partial r} \left[ e^{\frac{G(r)}{T}} \rho(r,t) \right] \right]. \tag{43}$$

We put

$$\rho(r,t) = u(r,t)e^{-\frac{G(r)}{T}},\tag{44}$$

and we substitute it in Eq.43:

$$\frac{\partial}{\partial t} \left[ u(r,t)e^{-\frac{G(r)}{T}} \right] = T \frac{\partial}{\partial r} \left[ e^{-\frac{G(r)}{T}} \frac{\partial}{\partial r} \left[ e^{\frac{G(r)}{T}} u(r,t)e^{-\frac{G(r)}{T}} \right] \right]$$
(45)

$$\Longrightarrow e^{-\frac{G(r)}{T}} \frac{\partial u(r,t)}{\partial t} = T \frac{\partial}{\partial r} \left[ e^{-\frac{G(r)}{T}} \frac{\partial u(r,t)}{\partial r} \right]$$
(46)

<span id="page-45-2"></span>
$$\Longrightarrow \frac{\partial u(r,t)}{\partial t} = T \frac{\partial^2 u(r,t)}{\partial r^2} - \frac{\partial G(r)}{\partial r} \frac{\partial u(r,t)}{\partial r},\tag{47}$$

which is similar to the transport equation in one dimension:

$$\Longrightarrow \frac{\partial u(x,t)}{\partial t} = D \frac{\partial^2 u(x,t)}{\partial x^2} - v(x) \frac{\partial u(x,t)}{\partial x}.$$
 (48)

Reflecting boundaries condition reads:

<span id="page-45-1"></span>
$$\frac{\partial}{\partial r} \left[ e^{\frac{G(r)}{T}} \rho(r, t) \right] \bigg|_{Boundaries} = 0 \tag{49}$$

<span id="page-45-3"></span>
$$\Longrightarrow \frac{\partial u(r,t)}{\partial r} \bigg|_{Boundaries} = 0. \tag{50}$$

Using the boundaries condition Eq.49, the stationary solution  $(t \to +\infty)$  of Focker-Planck equation reads :

$$\frac{\partial \rho(r,t)}{\partial t} = 0 \Longrightarrow \rho(r) = Ce^{-\frac{G(r)}{T}},\tag{51}$$

where C is an integration constant. Then, the stationary solution  $(t \to +\infty)$  of Eq.(47) is

$$u(r) = C. (52)$$

The NDSolve function of Mathematica can resolve Eq. (47) with the initial condition

$$u(r,0) = \rho(r,0)e^{\frac{G(r)}{T}},$$
 (53)

and the boundaries condition Eq.(50).

We can implement this method explicitly using the numerical scheme below.

#### <span id="page-46-0"></span>A.2.1 Discretization

We put

$$\Delta x = x_{i+1} - x_i,$$
  $\Delta t = t_{j+1} - t_j,$  (54)

$$u(r_i, t_j) = u_i^j,$$
 
$$\frac{\partial G(r)}{\partial r} \bigg|_{r=r} = g_i,$$
 (55)

$$1 \le i \le N+1,$$
  $1 \le j \le M+1,$  (56)

# <span id="page-46-1"></span>A.2.2 Finite differences / Implicit method / Backward time-central space / Crank-Niclson method

 $Eq.(47) \Longrightarrow$ 

$$\frac{u_i^{j+1} - u_i^j}{\Delta t} = \frac{T}{2} \left( \frac{u_{i-1}^j - 2u_i^j + u_{i+1}^j}{\Delta x^2} + \frac{u_{i-1}^{j+1} - 2u_i^{j+1} + u_{i+1}^{j+1}}{\Delta x^2} \right) - \frac{g_i}{2} \left( \frac{u_{i+1}^j - u_{i-1}^j}{2\Delta x} + \frac{u_{i+1}^{j+1} - u_{i-1}^{j+1}}{2\Delta x} \right) \tag{57}$$

$$\implies -\left(\frac{T\Delta t}{\Delta x^2} + \frac{g_i \Delta t}{2\Delta x}\right) u_{i-1}^{j+1} + 2\left(1 + \frac{T\Delta t}{\Delta x^2}\right) u_i^{j+1} - \left(\frac{T\Delta t}{\Delta x^2} - \frac{g_i \Delta t}{2\Delta x}\right) u_{i+1}^{j+1} = \left(\frac{T\Delta t}{\Delta x^2} + \frac{g_i \Delta t}{2\Delta x}\right) u_{i-1}^{j} + 2\left(1 - \frac{T\Delta t}{\Delta x^2}\right) u_i^{j} + \left(\frac{T\Delta t}{\Delta x^2} - \frac{g_i \Delta t}{2\Delta x}\right) u_{i+1}^{j}. \tag{58}$$

We put

<span id="page-46-2"></span>
$$\frac{T\Delta t}{\Delta x^2} = a$$
 and  $b_i = \frac{g_i \Delta t}{2\Delta x}$ , (59)

then

$$-(a+b_i) u_{i-1}^{j+1} + 2(1+a) u_i^{j+1} - (a-b_i) u_{i+1}^{j+1} = (a+b_i) u_{i-1}^{j} + 2(1-a) u_i^{j} + (a-b_i) u_{i+1}^{j}.$$
(60)

For  $i = 1 : \text{Eq.}(50) \Longrightarrow$ 

<span id="page-46-3"></span>
$$\frac{u_2^{j+1} - u_1^{j+1}}{\Delta x} = 0 \implies -u_1^{j+1} + u_2^{j+1} = 0 \tag{61}$$

For i = N + 1: Eq.(50)  $\Longrightarrow$ 

<span id="page-46-4"></span>
$$\frac{u_{N+1}^{j+1} - u_N^{j+1}}{\Delta x} = 0 \implies -u_N^{j+1} + u_{N+1}^{j+1} = 0.$$
 (62)

Therefore, Eqs.(60),(61) and (62) read

$$Au^{j+1} = Bu^j \quad \Longrightarrow u^{j+1} = A^{-1}Bu^j, \tag{63}$$

with

$$A = \begin{pmatrix} -1 & 1 & 0 & \cdots & \cdots & \cdots & 0 \\ -(a+b_2) & 2(1+a) & -(a-b_2) & 0 & \cdots & \cdots & 0 \\ 0 & -(a+b_3) & 2(1+a) & -(a-b_3) & 0 & \cdots & 0 \\ \vdots & \ddots & \ddots & \ddots & \ddots & \ddots & \vdots \\ \vdots & \ddots & \ddots & \ddots & \ddots & \ddots & \vdots \\ 0 & \cdots & \cdots & 0 & -(a+b_N) & 2(1+a) & -(a-b_N) \\ 0 & \cdots & \cdots & \cdots & 0 & -1 & 1 \end{pmatrix},$$
(64)

$$B = \begin{pmatrix} 0 & 0 & 0 & \cdots & \cdots & \cdots & 0 \\ (a+b_2) & 2(1-a) & (a-b_2) & 0 & \cdots & \cdots & 0 \\ 0 & (a+b_3) & 2(1-a) & (a-b_3) & 0 & \cdots & 0 \\ \vdots & \ddots & \ddots & \ddots & \ddots & \ddots & \vdots \\ \vdots & \ddots & \ddots & \ddots & \ddots & \ddots & \vdots \\ 0 & \cdots & \cdots & 0 & (a+b_N) & 2(1-a) & (a-b_N) \\ 0 & \cdots & \cdots & \cdots & 0 & 0 & 0 \end{pmatrix}$$
 (65)

and

$$u^{j} = \begin{pmatrix} u_{1}^{j} \\ u_{2}^{j} \\ \vdots \\ \vdots \\ u_{N}^{j} \\ u_{N+1}^{j} \end{pmatrix}. \tag{66}$$

#### <span id="page-47-0"></span>A.3 Second Method

Following [62–64], we consider the general form of Focker-Planck equation

$$\frac{\partial u(x,t)}{\partial t} = \frac{1}{A(x)} \frac{\partial}{\partial x} \left[ B(x,t)u(x,t) + C(x,t) \frac{\partial u(x,t)}{\partial x} \right]. \tag{67}$$

Using this general form, the Focker-Planck equation in black hole thermodynamics can be read

$$\frac{\partial \rho(r,t)}{\partial t} = \frac{\partial}{\partial r} \left[ \frac{\partial G(r)}{\partial r} \rho(r,t) + T \frac{\partial \rho(r,t)}{\partial r} \right]. \tag{68}$$

We put

<span id="page-47-1"></span>
$$F(r,t) = \frac{\partial G(r)}{\partial r} \rho(r,t) + T \frac{\partial \rho(r,t)}{\partial r}, \tag{69}$$

then

<span id="page-48-0"></span>
$$\frac{\partial \rho(r,t)}{\partial t} = \frac{\partial F(r,t)}{\partial r}. (70)$$

We put

$$\Delta x = x_{i+1} - x_i, \qquad \Delta t = t_{j+1} - t_j, \tag{71}$$

$$\rho(r_i, t_j) = \rho_i^j, \qquad \frac{\partial G(r)}{\partial r} \bigg|_{r=r} = g_i, \qquad (72)$$

$$\omega_i = \Delta x \frac{g_{i+1/2}}{T}, \qquad \delta_i = \frac{1}{\omega_i} - \frac{1}{e^{\omega_i} - 1}, \qquad (73)$$

$$0 \le i \le N, \tag{74}$$

with  $x_{i+1/2} = (x_{i+1} + x_i)/2$ .

 $Eq.(70) \Longrightarrow$ 

<span id="page-48-1"></span>
$$\frac{\rho_i^{j+1} - \rho_i^j}{\Delta t} = \frac{F_{i+1/2}^{j+1} - F_{i-1/2}^{j+1}}{\Delta x}.$$
 (75)

 $Eq.(69) \Longrightarrow$ 

$$F_{i+1/2}^{j+1} = \left[ (1 - \delta_i) g_{i+1/2} + \frac{T}{\Delta x} \right] \rho_{i+1}^{j+1} - \left( \frac{T}{\Delta x} - \delta_i g_{i+1/2} \right) \rho_i^{j+1}$$
 (76)

$$\implies \rho_i^{j+1} - \rho_i^j = \frac{\Delta t}{\Delta x} \left\{ \left[ (1 - \delta_i) g_{i+1/2} + \frac{T}{\Delta x} \right] \rho_{i+1}^{j+1} - \left[ \frac{2T}{\Delta x} + (1 - \delta_{i-1}) g_{i-1/2} - \delta_i g_{i+1/2} \right] \rho_i^{j+1} + \left[ \frac{T}{\Delta x} - \delta_{i-1} g_{i-1/2} \right] \rho_{i-1}^{j+1} \right\}$$
(77)

$$\implies \rho_i^j = -\frac{\Delta t}{\Delta x} \left[ \frac{T}{\Delta x} - \delta_{i-1} g_{i-1/2} \right] \rho_{i-1}^{j+1}$$

$$+ \left\{ 1 + \frac{\Delta t}{\Delta x} \left[ \frac{2T}{\Delta x} + (1 - \delta_{i-1}) g_{i-1/2} - \delta_i g_{i+1/2} \right] \right\} \rho_i^{j+1}$$

$$- \frac{\Delta t}{\Delta x} \left[ (1 - \delta_i) g_{i+1/2} + \frac{T}{\Delta x} \right] \rho_{i+1}^{j+1}$$
 (78)

<span id="page-48-2"></span>
$$\Longrightarrow \rho_i^j = a_i \rho_{i-1}^{j+1} + b_i \rho_i^{j+1} + c_i \rho_{i+1}^{j+1}, \tag{79}$$

with

$$a_{i} = -\frac{\Delta t}{\Delta x} \left[ \frac{T}{\Delta x} - \delta_{i-1} g_{i-1/2} \right]$$

$$b_{i} = 1 + \frac{\Delta t}{\Delta x} \left[ \frac{2T}{\Delta x} + (1 - \delta_{i-1}) g_{i-1/2} - \delta_{i} g_{i+1/2} \right]$$

$$c_{i} = -\frac{\Delta t}{\Delta x} \left[ (1 - \delta_{i}) g_{i+1/2} + \frac{T}{\Delta x} \right].$$
(80)

Using Eq. (70), reflecting boundaries condition read

$$\left. \frac{\partial F(r,t)}{\partial r} \right|_{Boundaries} = 0. \tag{81}$$

For i = 0: Eq. $(75) \Longrightarrow$ 

$$\rho_0^j = \rho_0^{j+1} - \frac{\Delta t}{\Delta x} F_{1/2}^{j+1}, \tag{82}$$

because  $F_{-1/2}^{j+1} = 0$ . Then

$$\rho_0^j = \rho_0^{j+1} - \frac{\Delta t}{\Delta x} \left[ (1 - \delta_0) g_{1/2} + \frac{T}{\Delta x} \right] \rho_1^{j+1} + \frac{\Delta t}{\Delta x} \left( \frac{T}{\Delta x} - \delta_0 g_{1/2} \right) \rho_0^{j+1} \tag{83}$$

$$\Longrightarrow \rho_0^j = \left[1 + \frac{\Delta t}{\Delta x} \left(\frac{T}{\Delta x} - \delta_0 g_{1/2}\right)\right] \rho_0^{j+1} - \frac{\Delta t}{\Delta x} \left[(1 - \delta_0)g_{1/2} + \frac{T}{\Delta x}\right] \rho_1^{j+1} \tag{84}$$

<span id="page-49-0"></span>
$$\Longrightarrow \rho_0^j = b_0 \rho_0^{j+1} + a_0 \rho_1^{j+1}, \tag{85}$$

with

$$b_{0} = 1 + \frac{\Delta t}{\Delta x} \left( \frac{T}{\Delta x} - \delta_{0} g_{1/2} \right)$$

$$c_{0} = -\frac{\Delta t}{\Delta x} \left[ (1 - \delta_{0}) g_{1/2} + \frac{T}{\Delta x} \right].$$
(86)

For  $i = N : \text{Eq.}(75) \Longrightarrow$ 

$$\rho_N^j = \rho_N^{j+1} + \frac{\Delta t}{\Delta x} F_{N-1/2}^{j+1},\tag{87}$$

because  $F_{N+1/2}^{j+1} = 0$ . Then

$$\rho_N^j = \rho_N^{j+1} + \frac{\Delta t}{\Delta x} \left[ (1 - \delta_{N-1}) g_{N-1/2} + \frac{T}{\Delta x} \right] \rho_N^{j+1} - \frac{\Delta t}{\Delta x} \left( \frac{T}{\Delta x} - \delta_{N-1} g_{N-1/2} \right) \rho_{N-1}^{j+1}$$
(88)

$$\Longrightarrow \rho_{N}^{j} = -\left(\frac{T}{\Delta x} - \delta_{N-1}g_{N-1/2}\right)\rho_{N-1}^{j+1} + \left\{1 + \frac{\Delta t}{\Delta x}\left[\left(1 - \delta_{N-1}\right)g_{N-1/2} + \frac{T}{\Delta x}\right]\right\}\rho_{N}^{j+1} \quad (89)$$

<span id="page-49-1"></span>
$$\Longrightarrow \rho_N^j = a_N \rho_{N-1}^{j+1} + b_N \rho_N^{j+1}, \tag{90}$$

with

$$a_{N} = -\left(\frac{T}{\Delta x} - \delta_{N-1}g_{N-1/2}\right)$$

$$b_{N} = 1 + \frac{\Delta t}{\Delta x} \left[ \left(1 - \delta_{N-1}\right) g_{N-1/2} + \frac{T}{\Delta x} \right].$$
(91)

Therefore, Eqs.(79),(85) and (90) read

$$\rho^j = M\rho^{j+1} \quad \Longrightarrow \rho^{j+1} = M^{-1}\rho^j. \tag{92}$$

Hence

$$\rho^j = M^{-j}\rho^0. \tag{93}$$

with

$$M = \begin{pmatrix} b_0 & c_0 & 0 & \cdots & \cdots & \cdots & 0 \\ a_1 & b_1 & c_1 & 0 & \cdots & \cdots & 0 \\ 0 & a_2 & b_2 & c_2 & 0 & \cdots & 0 \\ \vdots & \ddots & \ddots & \ddots & \ddots & \vdots \\ \vdots & \ddots & \ddots & \ddots & \ddots & \vdots \\ 0 & \cdots & \cdots & 0 & a_{N-1} & b_{N-1} & c_{N-1} \\ 0 & \cdots & \cdots & 0 & a_N & b_N \end{pmatrix},$$
(94)

and

$$\rho^{j} = \begin{pmatrix} \rho_{0}^{j} \\ \rho_{1}^{j} \\ \vdots \\ \vdots \\ \rho_{N-1}^{j} \\ \rho_{N}^{j} \end{pmatrix} .$$
(95)

## References

- <span id="page-51-0"></span>[1] Sharmila Gunasekaran, Robert B. Mann, and David Kubiznak. Extended phase space thermodynamics for charged and rotating black holes and born-infeld vacuum polarization. JHEP, 11:110, 2012.
- <span id="page-51-1"></span>[2] T. Narayanan and A. Kumar. Reentrant phase transitions in multicomponent liquid mixtures. Physics Reports, 249(3):135, 1994.
- <span id="page-51-2"></span>[3] Natacha Altamirano, David Kubiznak, and Robert B. Mann. Reentrant phase transitions in rotating anti–de sitter black holes. Phys. Rev. D, 88(10):101502, 2013.
- [4] Natacha Altamirano, David Kubizˇn´ak, Robert B. Mann, and Zeinab Sherkatghanad. Kerr-ads analogue of triple point and solid/liquid/gas phase transition. Class. Quant. Grav., 31:042001, 2014.
- [5] Natacha Altamirano, David Kubiznak, Robert B. Mann, and Zeinab Sherkatghanad. Thermodynamics of rotating black holes and black rings: phase transitions and thermodynamic volume. Galaxies, 2:89–159, 2014.
- [6] David Kubiznak and Fil Simovic. Thermodynamics of horizons: de sitter black holes and reentrant phase transitions. Class. Quant. Grav., 33(24):245001, 2016.
- [7] Antonia M. Frassino, David Kubiznak, Robert B. Mann, and Fil Simovic. Multiple reentrant phase transitions and triple points in lovelock thermodynamics. JHEP, 09:080, 2014.
- [8] Shao-Wen Wei and Yu-Xiao Liu. Triple points and phase diagrams in the extended phase space of charged gauss-bonnet black holes in ads space. Phys. Rev. D, 90(4):044057, 2014.
- [9] Robie A. Hennigar, Wilson G. Brenna, and Robert B. Mann. p − v criticality in quasitopological gravity. JHEP, 07:077, 2015.
- [10] Zeinab Sherkatghanad, Behrouz Mirza, Zahra Mirzaiyan, and Seyed Ali Hosseini Mansoori. Critical behaviors and phase transitions of black holes in higher order gravities and extended phase spaces. Int. J. Mod. Phys. D, 26(03):1750017, 2016.
- [11] Robie A. Hennigar and Robert B. Mann. Reentrant phase transitions and van der waals behaviour for hairy black holes. Entropy, 17(12):8056–8072, 2015.
- [12] Yu-Meng Xu, Hui-Min Wang, Yu-Xiao Liu, and Shao-Wen Wei. Photon sphere and reentrant phase transition of charged born-infeld-ads black holes. Phys. Rev. D, 100(10):104044, 2019.
- [13] De-Cheng Zou, Ruihong Yue, and Ming Zhang. Reentrant phase transitions of higherdimensional ads black holes in drgt massive gravity. Eur. Phys. J. C, 77(4):256, 2017.

- <span id="page-52-0"></span>[14] David Kubiznak and Robert B. Mann. Black hole chemistry. Can. J. Phys., 93(9):999– 1002, 2015.
- <span id="page-52-1"></span>[15] De-Cheng Zou, Shao-Jun Zhang, and Bin Wang. Critical behavior of Born-Infeld AdS black holes in the extended phase space thermodynamics. Phys. Rev. D, 89(4):044002, 2014.
- <span id="page-52-2"></span>[16] Ran Li and Jin Wang. Thermodynamics and kinetics of Hawking-Page phase transition. Phys. Rev. D, 102(2):024085, 2020.
- <span id="page-52-3"></span>[17] Ran Li, Kun Zhang, and Jin Wang. Thermal dynamic phase transition of Reissner-Nordstr¨om Anti-de Sitter black holes on free energy landscape. JHEP, 10:090, 2020.
- <span id="page-52-4"></span>[18] Shao-Wen Wei, Yu-Xiao Liu, and Yong-Qiang Wang. Dynamic properties of thermodynamic phase transition for five-dimensional neutral Gauss-Bonnet AdS black hole on free energy landscape. Nucl. Phys. B, 976:115692, 2022.
- <span id="page-52-5"></span>[19] Ran Li and Jin Wang. Energy and entropy compensation, phase transition and kinetics of four dimensional charged Gauss-Bonnet Anti-de Sitter black holes on the underlying free energy landscape. Nucl. Phys. B, 976:115714, 2022.
- <span id="page-52-6"></span>[20] Shao-Wen Wei, Yong-Qiang Wang, Yu-Xiao Liu, and Robert B. Mann. Observing dynamic oscillatory behavior of triple points among black hole thermodynamic phase transitions. Sci. China Phys. Mech. Astron., 64(7):270411, 2021.
- <span id="page-52-7"></span>[21] Shan-Quan Lan, Jie-Xiong Mo, Gu-Qiang Li, and Xiao-Bao Xu. Effects of dark energy on dynamic phase transition of charged AdS black holes. Phys. Rev. D, 104(10):104032, 2021.
- <span id="page-52-8"></span>[22] A. Naveena Kumara, Shreyas Punacha, Kartheek Hegde, C. L. Ahmed Rizwan, K. M. Ajith, and Md Sabir Ali. Dynamics and kinetics of phase transition for regular AdS black holes in general relativity coupled to non-linear electrodynamics. 6 2021.
- <span id="page-52-9"></span>[23] Yun-Zhi Du, Huai-Fan Li, Fang Liu, and Li-Chun Zhang. Dynamic property of phase transition for non-linear charged anti-de Sitter black holes \*. Chin. Phys. C, 46(5):055104, 2022.
- <span id="page-52-10"></span>[24] Heng Dai, Zixu Zhao, and Shuhang Zhang. Thermodynamic phase transition of Euler-Heisenberg-AdS black hole on free energy landscape. 2 2022.
- <span id="page-52-11"></span>[25] Conghua Liu and Jin Wang. Path integral and instantons for the dynamical process and phase transition rate of reissner-nordstr¨om-ads black holes. Phys. Rev. D, 105(10):104024, 2022.
- <span id="page-52-12"></span>[26] Ran Li and Jin Wang. Kinetics of Hawking-Page phase transition with the non-Markovian effects. JHEP, 05:128, 2022.

- <span id="page-53-0"></span>[27] Ran Li and Jin Wang. Non-Markovian dynamics of black hole phase transition. Phys. Rev. D, 106(10):104039, 2022.
- <span id="page-53-1"></span>[28] Si-Jiang Yang, Run Zhou, Shao-Wen Wei, and Yu-Xiao Liu. Kinetics of a phase transition for a Kerr-AdS black hole on the free-energy landscape. Phys. Rev. D, 105(8):084030, 2022.
- <span id="page-53-2"></span>[29] Ran Li and Jin wang. Generalized free energy landscape of a black hole phase transition. Phys. Rev. D, 106(10):106015, 2022.
- <span id="page-53-3"></span>[30] Ran Li, Conghua Liu, Kun Zhang, and Jin Wang. Topology of the landscape and dominant kinetic path for the thermodynamic phase transition of the charged Gauss-Bonnet AdS black holes. 2 2023.
- <span id="page-53-4"></span>[31] M. Born and L. Infeld. Foundations of the new field theory. Proc. Roy. Soc. Lond. A, 144(852):425–451, 1934.
- <span id="page-53-5"></span>[32] R. G. Leigh. Dirac-Born-Infeld Action from Dirichlet Sigma Model. Mod. Phys. Lett. A, 4:2767, 1989.
- <span id="page-53-6"></span>[33] E. S. Fradkin and Arkady A. Tseytlin. Nonlinear Electrodynamics from Quantized Strings. Phys. Lett. B, 163:123–130, 1985.
- <span id="page-53-7"></span>[34] G W Gibbons. Aspects of Born-Infeld theory and string / M theory. AIP Conf. Proc., 589(1):324–350, 2001.
- <span id="page-53-8"></span>[35] S. Cecotti and S. Ferrara. SUPERSYMMETRIC BORN-INFELD LAGRANGIANS. Phys. Lett. B, 187:335–339, 1987.
- [36] Mauricio Cataldo and Alberto Garcia. Three dimensional black hole coupled to the Born-Infeld electrodynamics. Phys. Lett. B, 456:28–33, 1999.
- <span id="page-53-11"></span>[37] Sharmanthie Fernando and Don Krug. Charged black hole solutions in Einstein-Born-Infeld gravity with a cosmological constant. Gen. Rel. Grav., 35:129–137, 2003.
- [38] Adria Delhom, Gonzalo J. Olmo, and Emanuele Orazi. Ricci-Based Gravity theories and their impact on Maxwell and nonlinear electromagnetic models. JHEP, 11:149, 2019.
- <span id="page-53-9"></span>[39] Peng Wang, Houwen Wu, and Haitang Yang. Scalarized Einstein-Born-Infeld black holes. Phys. Rev. D, 103(10):104012, 2021.
- <span id="page-53-10"></span>[40] M. Novello, V. A. De Lorenci, J. M. Salim, and Renato Klippert. Geometrical aspects of light propagation in nonlinear electrodynamics. Phys. Rev. D, 61:045001, 2000.
- [41] Ricardo Garcia-Salcedo and Nora Breton. Born-Infeld cosmologies. Int. J. Mod. Phys. A, 15:4341–4354, 2000.

- [42] Jun Tao, Peng Wang, and Haitang Yang. Testing holographic conjectures of complexity with Born–Infeld black holes. Eur. Phys. J. C, 77(12):817, 2017.
- [43] Peng Wang, Houwen Wu, and Haitang Yang. Thermodynamics and Phase Transition of a Nonlinear Electrodynamics Black Hole in a Cavity. JHEP, 07:002, 2019.
- [44] Hongmei Jing, Benrong Mu, Jun Tao, and Peng Wang. Thermodynamic instability of 3D Einstein-Born-Infeld AdS black holes. Chin. Phys. C, 45(6):065103, 2021.
- [45] Shihao Bi, Minghao Du, Jun Tao, and Feiyu Yao. Joule-Thomson expansion of Born-Infeld AdS black holes. Chin. Phys. C, 45(2):025109, 2021.
- [46] Olivera Miskovic and Rodrigo Olea. Thermodynamics of Einstein-Born-Infeld black holes with negative cosmological constant. Phys. Rev. D, 77:124048, 2008.
- [47] Jose Beltr´an Jim´enez, Adri`a Delhom, Gonzalo J. Olmo, and Emanuele Orazi. Born-Infeld gravity: Constraints from light-by-light scattering and an effective field theory perspective. Phys. Lett. B, 820:136479, 2021.
- [48] Qingyu Gan, Guangzhou Guo, Peng Wang, and Houwen Wu. Strong cosmic censorship for a scalar field in a Born-Infeld–de Sitter black hole. Phys. Rev. D, 100(12):124009, 2019.
- [49] Kangkai Liang, Peng Wang, Houwen Wu, and Mingtao Yang. Phase structures and transitions of Born–Infeld black holes in a grand canonical ensemble. Eur. Phys. J. C, 80(3):187, 2020.
- <span id="page-54-0"></span>[50] Aoyun He, Jun Tao, Peng Wang, Yadong Xue, and Lingkai Zhang. Effects of Born–Infeld electrodynamics on black hole shadows. Eur. Phys. J. C, 82(8):683, 2022.
- <span id="page-54-1"></span>[51] Tanay Kr. Dey. Born-Infeld black holes in the presence of a cosmological constant. Phys. Lett. B, 595:484–490, 2004.
- <span id="page-54-2"></span>[52] Rong-Gen Cai, Da-Wei Pang, and Anzhong Wang. Born-Infeld black holes in (A)dS spaces. Phys. Rev. D, 70:124034, 2004.
- <span id="page-54-3"></span>[53] David Kubiznak and Robert B. Mann. P-V criticality of charged AdS black holes. JHEP, 07:033, 2012.
- <span id="page-54-4"></span>[54] Amin Dehyadegari, Ahmad Sheykhi, and Afshin Montakhab. Critical behavior and microscopic structure of charged AdS black holes via an alternative phase space. Phys. Lett. B, 768:235–240, 2017.
- <span id="page-54-5"></span>[55] Amin Dehyadegari and Ahmad Sheykhi. Reentrant phase transition of born-infeld-ads black holes. Phys. Rev. D, 98(2):024011, 2018.
- <span id="page-54-6"></span>[56] N. Goldenfeld. Lectures on Phase Transitions and the Renormalization Group. 1992.

- <span id="page-55-0"></span>[57] Zhen-Ming Xu, Bin Wu, and Wen-Li Yang. van der Waals fluid and charged AdS black hole in the Landau theory. Class. Quant. Grav., 38(20):205008, 2021.
- <span id="page-55-1"></span>[58] Yun Soo Myung, Yong-Wan Kim, and Young-Jai Park. Thermodynamics and phase transitions in the born-infeld-anti-de sitter black holes. Phys. Rev. D, 78:084002, Oct 2008.
- <span id="page-55-2"></span>[59] Ran Li, Kun Zhang, and Jin Wang. Thermal dynamic phase transition of reissnernordstr¨om anti-de sitter black holes on free energy landscape. Journal of High Energy Physics, 2020:1–25, 2020.
- <span id="page-55-3"></span>[60] Joseph D. Bryngelson and Peter G. Wolynes. Intermediates and barrier crossing in a random energy model (with applications to protein folding). The Journal of Physical Chemistry, 93(19):6902–6915, 1989.
- <span id="page-55-4"></span>[61] R. Zwanzig. Nonequilibrium Statistical Mechanics. Oxford University Press, 2001.
- <span id="page-55-5"></span>[62] J.S Chang and G Cooper. A practical difference scheme for fokker-planck equations. Journal of Computational Physics, 6(1):1–16, 1970.
- [63] V. Palleschi, F. Sarri, G. Marcozzi, and M.R. Torquati. Numerical solution of the fokker-planck equation: A fast and accurate algorithm. Physics Letters A, 146(7):378– 386, 1990.
- <span id="page-55-6"></span>[64] Muhammad Munir Butt. Numerical solution for fokker-planck equation using a twolevel scheme, 2020.