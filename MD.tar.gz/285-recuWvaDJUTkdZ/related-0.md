# Foundations of the New Field Theory.

By M. Born and L. INFELD,† Cambridge.

(Communicated by R. H. Fowler, F.R.S.—Received January 26, 1934.)

§ 1. Introduction.

§ 1. Introduction.

The relation of matter and the electromagnetic field can be interpreted from two opposite standpoints:—

The first which may be called the unitarian standpoint; assumes only one only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; assumes only one of the first which may be called the unitarian standpoint; as the first which may be called the unitarian standpoint; as the first which may be called the unitarian standpoint as the first which may be called the unitarian standpoint. Sidered as singularities of the field and mass is a derived notion to be expressed

Didered as singularities of the field and mass is a derived notion to be expressed by field energy (electromagnetic mass).

The second or dualistic standpoint takes field and particle as two essentially different agencies. The particles are the sources of the field, are acted on by the field but are not a part of the field; their characteristic property is inertial neasured by a specific constant, the mass.

At the present time nearly all physicists have adopted the dualistic view, which is supported by three facts.

1. The failure of any attempt to develop a unitarian theory.—Such attempts have been made with two essentially different tendencies: (a) The theories started by Heaviside, Searle and J. J. Thomson, and completed by Abraham, theoretz, and others, make geometrical assumptions about the "shape" and axinematic behaviour of the electron and distribution of charge density (rigid sinematic behaviour of the electron and distribution of charge density (rigid electron of Abraham, contracting electron of Lorentz); they break down because they are compelled to introduce cohesive forces of non-electromagnetic origin; (b) the theory of Mie§ formally avoids this difficulty by a generalization of Maxwell's equations making them non-linear; this attempt breaks down

feller Foundation for giving me the opportunity to work in Cambridge.

§ 'Ann. Physik,' vol. 37, p. 511 (1912); vol. 39, p. 1 (1912); vol. 40, p. 1 (1913). Also

Born, 'Göttinger Nachr,' p. 23 (1914).

<sup>‡</sup> This expression has nothing to do with "unitary" field theory due to Einstein, Weyl, Eddington, and others where the problem consists of uniting the theories of gravitational and electro-magnetic fields into a kind of non-Riemannian geometry. Specially some of Eddington's formulæ, developed in § 101 of his book "The Mathematical Theory of Relativity" (Cambridge), have a remarkable formal analogy to those of this paper, in spite of the entirely different physical interpretation.

because Mie's field equations have th e unacceptable property, th a t their solutions depend on th e ab so lu te value of th e potentials.

- *2. The result o f relativity theory*, th a t th e observed dependance of mass on velocity is in no w ay characteristic o f electrom agnetic m ass, b u t can be derived from th e tran sfo rm atio n law.
- 3. L ast, b u t n o t least, *the great success o f quantum, mechanics* which in its present form is essentially based on th e dualistic view. I t started from the consideration o f oscillators an d particles m oving in a Coulomb field; the m ethods developed in these cases have th e n been applied even to th e electrom agnetic field, th e F o u rier coefficients of w hich behave like **harmonic** oscillators.

B u t th ere are indications th a t th is q u an tu m electrodynam ics meets considerable difficulties an d is quite insufficient to explain several facts.

The difficulties are chiefly connected w ith th e fac t th a t th e self-energy of a p o in t charge is infinite, f The facts unexplained concern th e existence of elem en tary particles, th e co nstruction of th e nuclei, th e conversion of these particles in to o th er particles or in to photons, etc.

In all these cases th ere is sufficient evidence th a t th e present theory (formulate d b y D irac's w ave equation) holds as long as th e wave-lengths (of the M axwell or o f th e de Broglie waves) are long com pared w ith th e " radius of th e electron " e2/mc2, b u t breaks dow n for a field containing shorter waves. T he non-appearance o f P la n ck 's co n stan t in th is expression for the radius indicates th a t in th e first place th e electrom agnetic laws are to be modified; th e q u an tu m laws m ay th e n be a d a p te d to th e new field equations.

Considerations of th is so rt to g eth er w ith th e conviction of th e great philosophical superiority of th e U nitarian idea have led to th e recent attem pt^ to co n stru ct a new electrodynam ics, based on tw o ra th e r different lines of thought: a new th eo ry of th e electrom agnetic field an d a new m ethod of quantum m echanical treatm en t.

I t seems desirable to keep these tw o lines separate in th e fu rth er development. The purpose of th is pap er is to give a deeper foundation of th e new field equations on classical lines, w ith o u t touching th e question of the quantum th eory.

*%* **Bom , \* Nature,' vol. 132, p. 282 (1933); ' Proc. Roy. Soo.,' A, vol. 143, p. 410 (1934), ■cited here as I.**

**<sup>■</sup>f The attempt to avoid this difficulty by a new definition of electric force acting on a particle in a given field, made by Wentzel (' Z. Physik,' vol. 86, pp. 479, 636 (1933),vol. 87, p. 726 (1934)), is very ingenious, but rather artificial and leads to new difficulties.**

In the papers cited above, the new field theory has been introduced rath er cgmatically, by assuming th a t the Lagrangian underlying Maxwell's theory

$$L = \frac{1}{2} (H^2 - E^2) \tag{1.1}$$

(I and E are space-vectors of the electric and m agnetic field) has to be replaced lr the expression!

$$L = b^2 \left( \sqrt{1 + \frac{1}{b^2} (H^2 - E^2)} - 1 \right). \tag{1.2}$$

The obvious physical idea of this modification is th e following :—

The failure in the present theory m ay be expressed b y the statem ent th a t violates the *principle of finiteness* which postulates th a t a satisfactory theory lould avoid letting physical quantities become infinite. Applying this inciple to the velocity one is led to th e assum ption of an upper lim it of alocity c and to replace th e N ew tonian action function *\ mv2* of a free particle *y* the relativity expression me2 (1 — V l — Applying the same condition a the space itself one is lead to th e idea of closed space as introduced by linstein's cosmological theory. *%* Applying it to the electromagnetic field one i lead immediately to the assum ption of an upper lim it of th e field strength and to the modification of the action function (1.1) into (1.2).

This argum ent seems to be quite convincing. B ut we believe th a t a deeper oundation of such an im portant law is necessary, ju st as in E instein's mechanics he deeper foundation is provided by the postulate of relativity. Assuming hat the expression *me*2(1 —\ / 1 — *v2jc2)* has been found b y the idea of a velocity imit it is seen th a t it can be w ritten in the form

vhere

$$mc^{2} (1 - d\tau/dt),$$
 $c^{2} d\tau^{2} = c^{2} dt^{2} - dx^{2} - dy^{2} - dz^{2},$ 

tnd therefore it has the property th a t the tim e integral of is invariant for all transform ations for which *dx\** is invariant. This four-dimenlional group of transform ations is larger th an the three-dimensional group of transformations for which the tim e integral of the Newtonian function

is invariant.

$$\frac{1}{2}mv^2 = \frac{1}{2}m(ds/dt)^2$$
;  $ds^2 = dx^2 + dy^2 + dz^2$ ,

**t See Bom and Infeld, ' Nature,\* vol. 132, p. 1004 (1933).**

**t See Eddington, " The Expanding Universe," Cambridge, 1933.**

So we believe th a t we ought to search for a group of transformations for which th e new Lagrangian expression has an invariant space-time integral and which is larger th an th a t for th e old expression (1.1). This latter group is the known group of special relativ ity b u t not the group of general space-time transform ations, f Now it is very satisfying th a t the new Lagrangian belongs to this group of general relativ ity ; we shall show th a t it can be derived from th e postulate of general invariance w ith a few obvious additional assumptions. Therefore th e new field theory seems to be a consequence of this very general principle, and the old one n o t m ore th an a useful practical approximation, ju st in the same w ay as for th e m echanics of N ew ton and Einstein.

In this paper we develop th e whole theory from this general standpoint. W e shall be obliged to repeat some of th e formulae published in the previous paper. The connection w ith th e problem s of gravitation and of quantum theory will be treated later.

## § 2. *Postulate of Invariant Action.*

W e sta rt from th e general principle th a t all laws of nature have to be expressed b y equations covariant for all space-tim e transform ations. This, however, should n o t be tak en to m ean th a t the gravitational forces play an essential p a rt in th e constitution of th e physical world ; therefore we neglect the gravitational field so th a t there exist co-ordinate system s in which the metrical tensor *gkl* has the value assum ed in special relativity even in the centre of an electron. B u t we postulate th a t th e n atu ral laws are independent of the choice of the space-time co-ordinate system.

W e denote space-time co-ordinates by

$$x^1, x^2, x^3, x^4 = x, y, z, ct.$$

The differential *dxk* is, as usual, considered to be a contravariant vector. One can pull the indices up and down w ith help of the m etrical tensor which in any cartesian co-ordinate system (as used in special relativity) has the form.

$$(g_{kl}) = egin{pmatrix} -1 & 0 & 0 & 0 \ 0 & -1 & 0 & 0 \ 0 & 0 & -1 & 0 \ 0 & 0 & 0 & 1 \ \end{pmatrix} = (\delta_{kl}).$$

**f The adaptation of the function L (1.1) to the general relativity by multiplication wi** *• /* **—** *g* **is quite formal. Any expression can be made generally invariant in this way.** t is not the unit matrix, because of the different signs in the diagonal. Therebre we have to distinguish between covariant and contravariant tensors even a the co-ordinate systems of special relativity. In this case, however, the ule of pulling up and down of indices is very simple. This operation on the ndex 4 does not change the value of the tensor component, that on one of the ndices 1, 2, 3 changes only the sign.

We use the well-known convention that one has to sum over any index

on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 on 25 To obtain the laws of nature we use a variational principle of least action

$$\delta \int \mathcal{L} d\tau = 0, \qquad (d\tau = dx^1 dx^2 dx^3 dx^4).$$
 (2.2)

We postulate: the action integral has to be an invariant. We have to find

$$\mathscr{L} = \sqrt{|a_{kl}|}$$
;  $(|a_{kl}| = \text{determinant of } a_{kl})$ . (2.3)

$$a_{kl} = g_{kl} + f_{kl}; \quad g_{kl} = g_{lk}; \quad f_{kl} = -f_{lk}.$$
 (2.4)

We postulate: the action integral has to be an invariant. We have to find the form of  $\mathscr L$  satisfying this condition.

We consider a covariant tensor field  $a_{kl}$ ; we do not assume any symmetry improperty of  $a_{kl}$ . The question is to define  $\mathscr L$  to be such a function of  $a_{kl}$  in that (2.2) is invariant. The well-known answer is that  $\mathscr L$  must have the afform  $\mathscr L = \sqrt{|a_{kl}|}$ ;  $(|a_{kl}| = \text{determinant of } a_{kl})$ . (2.3)

If the field is determined by several tensors of the second order,  $\mathscr L$  can be any homogeneous function of the determinants of the covariant tensors of the order  $\frac{1}{2}$ .

Each arbitrary tensor  $a_{kl}$  can be split up into a symmetrical and antisymmetrical part:  $a_{kl} = g_{kl} + f_{kl}; \quad g_{kl} = g_{lk}; \quad f_{kl} = -f_{lk}.$ (2.4)

The simplest simultaneous description of the metrical and electromagnetic field is the introduction of one arbitrary (unsymmetrical) tensor  $a_{kl}$ ; we identify its symmetrical part  $g_{kl}$  with the metrical field, its antisymmetrical part with the electromagnetic field.  $\sharp$ 

† See Eddington, "The Mathematical Theory of Relativity," Cambridge, § 48 and 101 (1923).

The proof is simple: by a transformation with the Jacobian  $I = \frac{\partial (\bar{x}^1 \dots \bar{x}^4)}{\partial (x^1 \dots x^4)} d\tau$  is changed

into  $d\tau=1$   $d\tau$  and  $|a_{kl}|$  into  $|\tilde{a}_{kl}|=|a_{kl}|$   $|1^{-2}|$ ; for the  $dx^k$  are contravariant,  $a_{kl}$  covariant. ‡ This assumption has already been considered by Einstein, 'Berl. Ber.,' pp. 75/37 1923) and p. 414 (1925), from the standpoint of the affine field theory.

W e have th en three expressions which m ultiplied by *d r* are invariant

$$\sqrt{-|a_{kl}|} = \sqrt{-|g_{kl} + f_{kl}|}; \quad \sqrt{-|g_{kl}|}; \quad \sqrt{|f_{kl}|}, \quad (2.5)$$

where the m inus sign is added in order to get real values of th e square roots; for (2.1) shows th a t = — 1, therefore always *\gki\* < 0.

The sim plest assum ption for *££* is any linear function of (2.5):

$$\mathcal{L} = \sqrt{-|g_{kl} + f_{kl}|} + A\sqrt{-|g_{kl}|} + B\sqrt{|f_{kl}|}.$$
 (2.6)

B u t the last term can be om itted. F o r if is th e rotation of a potential vector, as we shall assume, its space-tim e integral can be changed into a surface integral and has no influence on th e variational equation of the field, f Therefore we can ta k e

$$B = 0. (2.7)$$

W e need another condition for th e determ ination of A. Its choice is obvious. In the lim iting case of th e cartesian co-ordinate system and of small values of *f kl, ££* has to give th e classical expression

$$\mathsf{L} = \frac{1}{4} f_{kl} f^{kl}. \tag{2.8}$$

W e now leave th e general co-ordinate system which has guided us to the expression (2.6) for *§£* and calculate in cartesian co-ordinates. Then we have w ith *gkl* = *8kl* (see (2.1) )

$$\begin{aligned} - \left| \delta_{kl} + f_{kl} \right| &= - \left| \begin{array}{cccc} -1 & f_{12} & f_{13} & f_{14} \\ f_{21} & -1 & f_{23} & f_{24} \\ f_{31} & f_{32} & -1 & f_{34} \\ f_{41} & f_{42} & f_{43} & 1 \end{array} \right| = 1 + (f_{23}^2 + f_{31}^2 + f_{12}^2 - f_{14}^2 - f_{24}^2 - f_{34}^2) \\ &- (f_{23}f_{14} + f_{31}f_{24} + f_{12}f_{34})^2 \\ &= 1 + (f_{23}^2 + f_{31}^2 + f_{12}^2 - f_{14}^2 - f_{24}^2 - f_{34}^2) - |f_{kl}|. \end{aligned}$$

F o r small values of *f kt* th e last determ inant can be neglected and (2.6) becomes equal to (2.8) only if

W e have therefore th e r e s u lt:—

The action function of th e electrom agnetic field is in general co-ordinates

$$\mathcal{L} = \sqrt{-|g_{kl} + f_{kl}|} - \sqrt{-|g_{kl}|}, \tag{2.10}$$

and in cartesian co-ordinates

$$L = \sqrt{1 + F - G^2} - 1, \tag{2.11}$$

A = — 1. (2-9)

**t See Eddington,** *loc. tit.,* **§ 101.**

$$\mathbf{F} = f_{23}^2 + f_{31}^2 + f_{12}^2 - f_{14}^2 - f_{24}^2 - f_{34}^2 \tag{2.12}$$

$$G = f_{23}f_{14} + f_{31}f_{24} + f_{12}f_{34}. (2.13)$$

Let us go back to th e expression for in a general co-ordinate system . W e denote as usual

**l&tl** *=9,*

and we develop th e determ inant *\gkX* + / \* i | into a power series in *f kl.* W e have then

| *9kl* + /fc l| *— 9* + ® ( ) 4" I /fcl|\*

The transform ation properties of | *gki* + *f ki* |, | and therefore also of <J) *(gkl, f kl)* are the same. They transform in th e same w ay as *g.* I f we write

$$g + \Phi + |f_{kl}| = g\left(1 + \frac{\Phi}{g} + \frac{|f_{kl}|}{g}\right),$$
 (2.14)

we see, th a t all expressions in the bracket on the right side of (2.14) are invariant. W e have calculated th eir value in a geodetic co-ordinate system and have fo u n d :

$$rac{\Phi}{g} = rac{1}{2} f_{kl} f^{kl} = \mathbf{F} = rac{1}{2} f_{kr} f_{ls} g^{lk} g^{sr}.$$

<E> *ig*is an invariant. W e have therefore in an arb itrary co-ordinate system :

$$|g_{kl} + f_{kl}| = g (1 + F - G^2)$$

$$\mathscr{L} = \sqrt{-g} (\sqrt{1 + F - G^2} - 1)$$
(2.15)

$$\mathbf{F} = \frac{1}{2} f_{kl} f^{kl}; \qquad \mathbf{G}^2 = \frac{|f_{kl}|}{-g} = \frac{(f_{23} f_{14} + f_{31} f_{24} + f_{12} f_{34})^2}{-g}. \tag{2.16}$$

Both F and G are invariant. W e shall bring G into such a form, th a t its invariance will be evident. For this purpose let us define an antisym m etrical tensor *j tklm* for any pair of indices, th a t isf

$$j^{sklm} = \left\{ egin{aligned} rac{1}{2\sqrt{-g}} & ext{if } sklm ext{ is an even permutation of 1, 2, 3, 4} \ rac{-1}{2\sqrt{-g}} & ext{if } sklm ext{ is an odd permutation of 1, 2, 3, 4} \ 0 & ext{ in any other case} \end{aligned} 
ight\}.$$
 (2.17)

We can write now G in the following form :

$$G = \frac{1}{4} j^{sklm} f_{sk} f_{lm}. \tag{2.18}$$

t **Einstein and Mayer, ' Berl. Ber.,' p. 3 (1932).**

From the last equation we can deduce the tensor character of  $j^{sklm}$ . We can also write G in the form

 $G = \frac{1}{4} f_{sk} f^{*sk}, \tag{2.19}$ 

where  $f^{*sk}$  is the dual tensor defined by

$$f^{*sk} = j^{sklm} f_{lm}, (2.20)$$

that is

$$f^{*23} = \frac{1}{\sqrt{-g}} f_{14}, \qquad f^{*31} = \frac{1}{\sqrt{-g}} f_{24}, \qquad f^{*12} = \frac{1}{\sqrt{-g}} f_{34}$$

$$f^{*14} = \frac{1}{\sqrt{-g}} f_{23}, \qquad f^{*24} = \frac{1}{\sqrt{-g}} f_{31}, \qquad f^{*34} = \frac{1}{\sqrt{-g}} f_{12}$$

$$(2.21)$$

or also

because

$$f^*_{sk} = j_{sklm} f^{lm}; \quad j_{sklm} = gj^{sklm} = g_{as}g_{bk}g_{cl}g_{dm}j^{abcd}.$$
 (2.23)

We shall need later the following formulæ:

$$f^{*kl}f^*_{kl} = -f^{kl}f_{kl} \tag{2.24}$$

$$j^{lsab}f_{ks}f_{ab} = f^{*ls}f_{ks} = G\delta_k^{\ l}$$
 (2.25)

$$f^{**ls} = -f^{ls}. (2.26)$$

(2.24)-(2.26) follow from the definition of  $f_{kl}^*$ ,  $f^{*kl}$  and G given above.

The function  $\mathcal{L}$  represented by (2.15) is the simplest Lagrangian satisfying the principle of general invariance. But it differs from that considered in I by the term  $G^2$ . This is of the fourth order in the  $f_{kl}$  and can, therefore, be neglected except in the immediate neighbourhood of singularities (i.e., electrons, see § 6). But the Lagrangian used in I can also be expressed in a general covariant form; for  $G^2$  is a determinant, namely,  $|f_{kl}|$ , therefore

$$\int (\sqrt{-|g_{kl}+f_{kl}|+|f_{kl}|}-\sqrt{-|g_{kl}|}) d\tau$$
 (2.27)

is also invariant; in cartesian co-ordinates it has exactly the form

$$\int (\sqrt{1+\mathbf{F}}-1) \, d\tau. \tag{2.28}$$

Which of these action principles is the right one can only be decided by their consequences. We take the expression given by (2.15) and can then easily

return to the other (2.27) or (2.28) by putting G = 0. In an y case th e solution of th e *statical* problem is identical for both action functions because one has G = 0 in this special case.

§ 3. *Action Principle, Field Equation and Conservation Law.*

We write (2.15) in the general form

$$\mathscr{L} = \sqrt{-g} \mathsf{L} = \sqrt{-g} \mathsf{L} (g_{kl}, \mathsf{F}, \mathsf{G}).$$

We shall see th a t all considerations hold if L is an invariant function of these arguments. As usual we assume the existence of a potential vector so th a t

$$f_{kl} = \frac{\partial \phi_l}{\partial x^k} - \frac{\partial \phi_k}{\partial x^l}.$$
 (3.1)

Then we have the identity

$$\frac{\partial f_{lm}}{\partial x^k} + \frac{\partial f_{mk}}{\partial x^l} + \frac{\partial f_{kl}}{\partial x^m} = 0, \tag{3.2}$$

which can with the help of (2.20) be w ritten :

$$\frac{\partial \sqrt{-g} f^{*kl}}{\partial x^l} = 0. \tag{3.2A}$$

We introduce a second kind of antisym m etrical field tensor *p ki,* which has to *f kt* a relation similar to th a t which, in Maxwell's theory of macrospic bodies, the dielectric displacement and m agnetic induction have to th e field strengths :

$$\sqrt{-g}p^{kl} = \frac{\partial \mathcal{L}}{\partial f_{kl}} = \sqrt{-g} \left( 2 \frac{\partial \mathbf{L}}{\partial \mathbf{F}} f^{kl} + \frac{\partial \mathbf{L}}{\partial \mathbf{G}} f^{*kl} \right) = \frac{(f^{kl} - \mathbf{G}f^{*kl})\sqrt{-g}}{\sqrt{1 + \mathbf{F} - \mathbf{G}^2}}. \quad (3.3)$$

The variation principle (2.2) gives the Eulerian equations

$$\frac{\partial \sqrt{-g} \ p^{kl}}{\partial x^l} = 0. \tag{3.4}$$

The equation (3.2) (or **(3.2a)** ) and (3.4) are the complete set of field equations. We prove the validity of the conservation law as in Maxwell's theory. Assuming a geodetic co-ordinate system, we m ultiply (3.2) by *p lm :*

$$p^{lm} \left( \frac{\partial f_{lm}}{\partial x^k} + \frac{\partial f_{mk}}{\partial x^l} + \frac{\partial f_{kl}}{\partial x^m} \right) = 0.$$
 (3.5)

In the second and third term we can take  $p^{lm}$  under the differentiation symbol because of (3.4); in the first term we use the definition (3.3) of  $p^{lm}$ :

$$2\frac{\partial}{\partial x^l}(p^{lm}f_{mk})+\frac{\partial L}{\partial f_{lm}}\frac{\partial f_{lm}}{\partial x^k}=0,$$

or

$$-2rac{\partial}{\partial x^l}(p^{ml}f_{mk})+2rac{\partial \mathsf{L}}{\partial x^k}=0.$$

If we introduce the tensor

$$\mathbf{T}_{k}^{l} = \mathbf{L} \delta_{k}^{l} - p^{ml} f_{mk}, \tag{3.6}$$

where

$$\delta_k^l = \left\{ \begin{array}{l} 1 \text{ if } k = l \\ 0 \text{ if } k \neq l \end{array} \right\},\tag{3.7}$$

we have

$$\frac{\partial \mathbf{T}_k^l}{\partial x^l} = 0. \tag{3.8}$$

In an arbitrary co-ordinate system we have

$$\frac{\partial \sqrt{-g} \, \mathbf{T}_k^{\ l}}{\partial x^l} - \frac{1}{2} \sqrt{-g} \mathbf{T}^{ab} \, \frac{\partial g_{ab}}{\partial x^k} = 0, \tag{3.9}$$

or, with the usual notation of covariant differentiation

$$\mathbf{T}^{l}_{k|l} = 0. \tag{3.9A}$$

It follows from (3.3) and (2.25) that we can write also  $T_k^l$  in the form

$$T_k^{\ l} = L \, \delta_k^{\ l} - \frac{f^{ml} f_{mk} - G^2 \delta_k^{\ l}}{\sqrt{1 + F - G^2}}. \tag{3.6A}$$

§ 4. Lagrangian and Hamiltonian.

 $\mathscr{L}$  can be considered as a function of  $g^{kl}$  and  $f_{kl}$ . We shall show that  $\frac{-2}{\sqrt{-g}} \frac{\partial \mathscr{L}}{\partial g^{kl}}$  is the energy-impulse tensor. We find

$$\frac{\partial \sqrt{-g}}{\partial g^{kl}} = -\frac{1}{2}\sqrt{-g}\,g_{kl} \tag{4.1}$$

$$\frac{\partial \mathbf{F}}{\partial a^{kl}} = g^{sr} f_{ks} f_{lr} \tag{4.2}$$

$$\frac{\partial G}{\partial g^{kl}} = \frac{1}{2} G g_{kl}. \tag{4.3}$$

Therefore

$$\begin{aligned}
-2\frac{\partial \mathscr{L}}{\partial g^{kl}} &= \sqrt{-g} \left\{ \mathsf{L} g_{kl} - 2 \left( \frac{\partial \mathsf{L}}{\partial \mathsf{F}} \frac{\partial \mathsf{F}}{\partial g^{kl}} + \frac{\partial \mathsf{L}}{\partial \mathsf{G}} \frac{\partial \mathsf{G}}{\partial g^{kl}} \right) \right\} \\
&= \sqrt{-g} \left\{ \mathsf{L} g_{kl} - \frac{f_{ks} f_{lr} g^{sr} - \mathsf{G}^2 g_{kl}}{\sqrt{1 + \mathsf{F} - \mathsf{G}^2}} \right\}.
\end{aligned} \tag{4.4}$$

It follows from (3.6A) and (3.6)

$$-2\frac{\partial \mathcal{L}}{\partial g^{kl}} = \sqrt{-g} \, \mathbf{T}_{kl} = \sqrt{-g} \, (\mathsf{L}g_{kl} - f_{ks}p_{lr}g^{sr}). \tag{4.5}$$

 $-2\frac{\partial \mathscr{L}}{\partial g^{kl}} = \sqrt{-g} \, \mathrm{T}_{kl} = \sqrt{-g} \, (\mathsf{L}g_{kl} - f_{ks}p_{lr}g^{sr}). \tag{4.5}$  Now it is very easy to generalize our action principle in such a way that it contains Einstein's gravitation laws; one has only to add to the action integral

The term  $\int R \sqrt{-g} d\tau$ , where R is the scalar of curvature. But we do not odiscuss problems connected with gravitation in this paper.

 $\mathscr{L}$  was regarded as a function of  $g^{kl}$  and  $f_{kl}$ . We can, however, express  $\mathscr{L}$ also as a function of  $g^{kl}$  and  $p_{kl}$ . It can be shown that it is possible to solve

$$\frac{1}{2}p^{*kl}p^*_{kl} = P, (4.6)$$

$$\frac{1}{4}p^{kl}p^*_{kl} = Q, (4.7)$$

The last equations as a function of  $g^{kl}$  and  $p_{kl}$ . It can be shown that it is possible to solve the equations  $p^{kl} = \frac{f^{kl} - Gf^{*kl}}{\sqrt{1 + F - G^2}}$ (3.3)  $p^{kl} = \frac{f^{kl} - Gf^{*kl}}{\sqrt{1 + F - G^2}}$ (4.6)  $\frac{1}{2}p^{*kl}p^*_{kl} = P,$ (4.6)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.7)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.7)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)  $\frac{1}{4}p^{kl}p^*_{kl} = Q,$ (4.8)

$$P = \frac{-F + G^2F + 4G^2}{1 + F - G^2} \tag{4.8}$$

$$Q = G. (4.9)$$

$$\frac{1 + F - G^2}{1 + G^2} = \frac{1 + Q^2}{1 + P - Q^2} \tag{4.8a}$$

$$G = Q. (4.9A)$$

We are now able to solve the equations (3.3). It follows from (3.3) and (2.26) that

$$p^{*ki} = \frac{f^{*kl} + Gf^{kl}}{\sqrt{1 + F - G^2}}.$$
 (3.3a)

Solving **(3.3)** and **(3.3a)** we obtain (taking into account **(4.8a) and (4.9a) )**

$$f^{kl} = \frac{p^{kl} + Qp^{*kl}}{\sqrt{1 + P - Q^2}}; \qquad f^{*kl} = \frac{p^{*kl} - Qp^{kl}}{\sqrt{1 + P - Q^2}}.$$
 (4.10)

The tensors *f kl* and *p kt* can now be treated completely symmetrically. Instead of the L agrangian L we can use in the principle of action the Hamiltonian function H :

$$\mathsf{H} = \mathsf{L} - \frac{1}{2} p^{kl} f_{kl},\tag{4.11}$$

where H has to be regarded as a function of *gkl* and From (4.8), (4.9), an d (4.10) it follows for H as a function of *gkl* and *:*

$$\mathcal{H} = H\sqrt{-g} = \sqrt{-g} (\sqrt{1 + P - Q^2} - 1),$$
 (4.12)

an d this can be expressed in th e form

$$\mathcal{H} = \sqrt{-|g_{kl} + p^*_{kl}|} - \sqrt{-|g_{kl}|}. \tag{4.12a}$$

The function H leads us to exactly the same equations of the field as the function L. W e see th a t the equations

$$p^*_{kl} = \frac{\partial \psi^*_l}{\partial x^k} - \frac{\partial \psi^*_k}{\partial x^l}$$
  $(\psi^*_k = \text{anti-potential-vector})$  (4.13)

$$\sqrt{-g}f^{*kl} = \frac{\partial \mathcal{H}}{\partial p^*_{kl}} \tag{4.14}$$

$$\frac{\partial \sqrt{-g} f^{*kl}}{\partial x^l} = 0, \tag{4.15}$$

**are entirely equivalent to the equations (3.4), (4.10), (3.2a).**

The energy-impulse tensor **(3.6a)** can also be expressed **with help** of H instead of L. One has

$$\mathbf{T}_{k}^{\ l} = \mathbf{H} \delta_{k}^{\ l} - f^{*ml} p^{*}_{mk} = (\mathbf{L} - \frac{1}{2} p^{ab} f_{ab}) \, \delta_{k}^{\ l} - f^{*ml} p^{*}_{mk}.$$
 (4.16)

The id en tity of this expression w ith (3.6) is evident,t if we appeal to the following form ula which can be deduced from (2.21), (2.22)

$$f^{*ml}p^*_{mk} = p^{ml}f_{mk} - \frac{1}{2}p^{ab}f_{ab}\delta_k^l$$
 (4.17)

**t In I it has been stated that the two expressions for** *T kl,* **obtained with help of L an H, are different***;* **this has turned out to be a mistake.**

Generally, from each equation containing *f kl,* one obtains another correct equation changing these quantities correspondingly into 4\*\*\*, *<sup>p</sup> \* \* *f\*M-*

§ 5. *Field Equations in Space-vector Form.*

We now introduce th e conventional units instead of th e n a tu ra l units. W e denote by B, E and D, E, th e space-vectors which characterize th e electromagnetic field in th e conventional units. We have in a cartesian co-ordinate system :

$$(x^1, x^2, x^3, x^4) \to (x, y, z, ct)$$
 (5.1)

$$(\phi_1, \phi_2, \phi_3, \phi_4) \rightarrow (\mathbf{A}, \phi) \tag{5.2}$$

$$\begin{pmatrix}
(f_{23}, f_{31}, f_{12} \to \mathbf{B} \\
f_{14}, f_{24}, f_{34}) \to \mathbf{E}
\end{pmatrix} (5.3)$$

$$\begin{pmatrix}
(p_{23}, p_{31}, p_{12} \to \mathbf{H} \\
p_{14}, p_{24}, p_{34}) \to \mathbf{D}
\end{pmatrix}.$$
(5.4)

The quotient of the field strength expressed in th e conventional units divided by th e field strength in the natu ral units m ay be denoted b y This constant of a dimension of a field strength m ay be called th e *absolute field* ; later we shall determine the value of *b,* which tu rn s out to be very great, *i.e.,* of th e order of m agnitude 1016 e.s.u.

We have

$$L = \sqrt{1 + F - G^2} - 1, \tag{2.11}$$

$$\mathbf{F} = \frac{1}{b^2} (\mathbf{B}^2 - \mathbf{E}^2); \qquad \mathbf{G} = \frac{1}{b^2} (\mathbf{B} \cdot \mathbf{E})$$
 (2.12a); (2.13a)

$$\mathbf{H} = b^{2} \frac{\partial \mathsf{L}}{\partial \mathsf{B}} = \frac{\mathsf{B} - \mathsf{GE}}{\sqrt{1 + \mathsf{F} - \mathsf{G}^{2}}},$$

$$\mathbf{D} = b^{2} \frac{\partial \mathsf{L}}{\partial \mathsf{E}} = \frac{\mathsf{E} - \mathsf{GB}}{\sqrt{1 + \mathsf{F} - \mathsf{G}^{2}}}.$$
(3.3a)

$$\mathbf{B} = \operatorname{rot} \mathbf{A} \; ; \qquad \mathbf{E} = -\frac{1}{c} \frac{\partial \mathbf{A}}{\partial t} - \operatorname{grad} \phi$$
 (3.1A)

$$\operatorname{rot} \mathbf{E} + \frac{1}{c} \frac{\partial \mathbf{B}}{\partial t} = 0 \; ; \quad \operatorname{div} \mathbf{B} = 0$$
 (3.2B)

$$\operatorname{rot} \mathbf{H} - \frac{1}{c} \frac{\partial \mathbf{D}}{\partial t} = 0 ; \quad \operatorname{div} \mathbf{D} = 0.$$
 (3.4A)

**Our field equations (3.2b) and (3.4a) are formally identical with Maxwell's equations for a substance which has a dielectric Constance and a susceptibility,** being certain functions of the field strength, b u t w ithout a spatial distribution of charge and current.

For the energy-impulse tensor we find :

$$\left(\frac{1}{4\pi} \mathbf{T}^{kl}\right) = \begin{bmatrix}
X_x & X_y & X_z & cG_x \\
Y_x & Y_y & Y_z & cG_y \\
Z_x & Z_y & Z_z & cG_z \\
\frac{1}{c} S_x & \frac{1}{c} S_y & \frac{1}{c} S_z & U
\end{bmatrix}$$
(3.6A)

$$\begin{aligned} 4\pi \mathbf{X}_{x} &= \mathbf{H}_{y} \mathbf{B}_{y} + \mathbf{H}_{z} \mathbf{B}_{z} - \mathbf{D}_{x} \mathbf{E}_{x} - b^{2} \mathbf{L} \\ 4\pi \mathbf{Y}_{x} &= 4\pi \mathbf{X}_{y} = -\mathbf{H}_{y} \mathbf{B}_{x} - \mathbf{D}_{x} \mathbf{E}_{y} \\ \frac{4\pi}{c} \mathbf{S}_{x} &= 4\pi c \mathbf{G}_{x} = \mathbf{D}_{y} \mathbf{B}_{z} - \mathbf{D}_{z} \mathbf{B}_{y} \\ 4\pi \mathbf{U} &= \mathbf{D}_{x} \mathbf{E}_{x} + \mathbf{D}_{y} \mathbf{E}_{y} + \mathbf{D}_{z} \mathbf{E}_{z} + b^{2} \mathbf{L} \end{aligned}$$
 (3.68)

One gets another set of expressions for these quantities by changing L, B, E, H, D into H, H, D, B, E.

The conservation laws are :

$$\frac{\partial \mathbf{X}_{x}}{\partial x} + \frac{\partial \mathbf{X}_{y}}{\partial y} + \frac{\partial \mathbf{X}_{z}}{\partial z} = -\frac{1}{c^{2}} \frac{\partial \mathbf{S}_{x}}{\partial t}$$

$$\frac{\partial \mathbf{S}_{x}}{\partial x} + \frac{\partial \mathbf{S}_{y}}{\partial y} + \frac{\partial \mathbf{S}_{z}}{\partial z} = -\frac{\partial \mathbf{U}}{\partial t}$$
(3.8A)

The function H is given by

$$H = \sqrt{1 + P - Q^2} - 1 \tag{4.12a}$$

$$P = \frac{1}{b^2} (D^2 - H^2); \qquad Q = \frac{1}{b^2} (D \cdot H).$$
 (4.6A); (4.7A)

Solving **(3.3a) we** obtain :

$$\mathbf{B} = b^{2} \frac{\partial \mathbf{H}}{\partial \mathbf{H}} = \frac{\mathbf{H} + \mathbf{Q}\mathbf{D}}{\sqrt{1 + \mathbf{P} - \mathbf{Q}^{2}}}$$

$$\mathbf{E} = b^{2} \frac{\partial \mathbf{H}}{\partial \mathbf{D}} = \frac{\mathbf{D} + \mathbf{Q}\mathbf{H}}{\sqrt{1 + \mathbf{P} - \mathbf{Q}^{2}}}$$
(3.10a)

# § 6. *Static Solution of the Field Equations.*

We consider (in the cartesian co-ordinate system ) the electrostatic case where B = H = 0 and all other field components are independent of *t.* Then the field equations reduce t o :

$$rot \mathbf{E} = 0 \tag{6.1}$$

$$\operatorname{div} \mathbf{D} = 0. \tag{6.2}$$

fe solve this equation for the case of central sym m etry. Then (6.2) is imply

*f* [\(r3D r\) = 0, \(6.3\)](#page-14-0) *dr*

<span id="page-14-0"></span>nd (6.3) has the solution

$$D_r = e/r^2. (6.4)$$

<span id="page-14-1"></span>n this case the field D is exactly th e same as in Maxwell's theory : the sources f D are point charges given b y th e surface integral

$$4\pi e = \int D_r d\sigma. \tag{6.5}$$

He equation (6.1) gives

$$\mathbf{E}_{r} = -\frac{d\phi}{dr} = -\phi'(r) \tag{6.6}$$

<span id="page-14-2"></span>**md from (3.3a)**

$$D_r = \frac{E_r}{\sqrt{1 - \frac{1}{b^2} E_r^2}} = -\frac{\phi'(r)}{\sqrt{1 - \frac{1}{b^2} \phi'^2}}.$$
 (6.7)

<span id="page-14-3"></span>The combination of (6.4) and (6.7) gives a differential equation for *<f> (r)* of the irst order, w ith the solution

$$\phi(r) = \frac{e}{r_0} f\left(\frac{r}{r_0}\right); f(x) = \int_x^\infty \frac{dy}{\sqrt{1+y^4}}; r_0 = \sqrt{\frac{e}{b}}.$$
 (6.8)

<span id="page-14-4"></span>*This is the elementary 'potential of a point charge e,* which has to replace Coulomb's la w ; the latter is an approxim ation for ^ 1, as is seen im mediately, b u t the new potential is finite everywhere.

W ith help of th e substitution *x —* ta n one obtains

$$f(x) = \frac{1}{2} \int_{\overline{\beta}(x)}^{\pi} \frac{d\beta}{\sqrt{1 - \frac{1}{2}\sin^2\beta}} = f(0) - \frac{1}{2} F\left(\frac{1}{\sqrt{2}}, \overline{\beta}\right),$$
 (6.9)

**where**

$$\overline{\beta} = 2 \arctan x,$$
 (6.10)

and F (&,p)is the Jacobian elliptic integral of the first kind for *k —* (tabulated in m any books)f 1 V 2 = sin J 7c

$$\mathbf{F}\left(\frac{1}{\sqrt{2}}, \overline{\beta}\right) = \int_0^{\overline{\beta}} \frac{d\beta}{\sqrt{1 - \frac{1}{2}\sin^2\beta}}.$$
 (6.11)

**t ^.0., Jahnfce-Emde, " Tables of functions " (Teubner 1933), p. 127.**

For 
$$x = 0$$
 one has  $f(0) = F\left(\frac{1}{\sqrt{2}}, \frac{1}{2}\pi\right) = 1,8541.$  (6.12)

The potential has its m axim um in the centre and its value is

$$\phi(0) = 1,8541 \, e/r_0. \tag{6.13}$$

![](_page_15_Figure_7.jpeg)

The function / *(x*)is plotted in fig. 1. I t has very similar properties to the function arc cot *x.* F or example, one has

$$\overline{\beta}$$
  $(1/x) = 2 \arctan 1/x = 2 (\frac{1}{2}\pi - \arctan x) = \pi - \overline{\beta}(x);$ 

on the other hand

$$\mathbf{F}\left(\frac{1}{\sqrt{2}}, \overline{\beta}\right) + \mathbf{F}\left(\frac{1}{\sqrt{2}}, \pi - \overline{\beta}\right) = \mathbf{F}\left(\frac{1}{\sqrt{2}}, \pi\right).$$

Cherefore one has

$$f(x) + f(1/x) = f(0).$$
 (6.14)

It is sufficient, therefore, to calculate f(x) from x = 0 to x = 1 or from  $\beta = 0$ to  $\beta = \frac{1}{2}\pi$ .

One sees, that the D field is infinite for r=0; E and  $\phi$ , however, are always One has inite.

(6.4)

$$D_r = e/r^2, (6.4)$$

$$E_r = \frac{e}{r_o^2 \sqrt{1 + (r/r_0)^4}}. (6.15)$$

 $E_r = \frac{e}{r_o^2 \sqrt{1 + (r/r_o)^4}}. \tag{6.15}$  The components  $E_x$ ,  $E_y$ ,  $E_z$  are finite at the centre, but have there a disjoint of the Field.

In the older theories, which we have called dualistic, because they considered natter and field as essentially different, the ideal would be to assume the particles to be point charges; this was impossible because of the infinite selfonergy. Therefore it was necessary to assume the electron having a finite sliameter and to make arbitrary assumptions about its inner structure, which dead to the difficulties pointed out in the introduction. In our theory these slifficulties do not appear. We have seen that the  $p_{kl}$  field (or D-field) has is singularity which corresponds to a point charge as the source of the field. D and E are identical only at large distances  $(r \gg r_0)$  from the point charge, but differ in its neighbourhood, and one can call their quotient (which is function of E) "dielectric constant" of the space. But we shall now show that inother interpretation is also possible which corresponds to the old idea of a spatial distribution of charge in the electron. It consists in taking div E Ginstead of div  $\mathbf{D}=0$ ) as definition of charge density  $\rho$ , which we propose to call "free charge density."

Let us now write our set of field equations in the following form:  $\frac{\partial \sqrt{-g} \ p^{kl}}{\partial x^{l}} = 0, \qquad (3.4)$   $\frac{\partial f_{kl}}{\partial x^{m}} + \frac{\partial f_{lm}}{\partial x^{k}} + \frac{\partial f_{mk}}{\partial x^{l}} = 0. \qquad \text{or} \qquad \partial \sqrt{-g} f^{*kl}$ 

$$\frac{\partial \sqrt{-g} \, p^{kl}}{\partial x^l} = 0,\tag{3.4}$$

$$\frac{\partial \sqrt{-g} p^{kl}}{\partial x^l} = 0,$$

$$\frac{\partial f_{kl}}{\partial x^m} + \frac{\partial f_{lm}}{\partial x^k} + \frac{\partial f_{mk}}{\partial x^l} = 0, \quad \text{or} \quad \frac{\partial \sqrt{-g} f^{*kl}}{\partial x^l} = 0.$$
(3.4)

 $p^{kl}$  is a given function of  $f^{kl}$  and if we put in (3.4) for  $p^{kl}$  the expression (3.3), in which L is not specified, we obtain:

$$\frac{\partial}{\partial x^{l}} \left\{ \left( 2 \frac{\partial \mathbf{L}}{\partial \mathbf{F}} f^{kl} + \frac{\partial \mathbf{L}}{\partial \mathbf{G}} f^{*kl} \right) \sqrt{-g} \right\} = 0. \tag{7.1}$$

We can now write the equation (7.1) in the form:

$$\frac{\partial \sqrt{-g} f^{kl}}{\partial x^l} = 4\pi \, \rho^k \, \sqrt{-g}, \tag{7.2}$$

where

$$-4\pi\rho^{k} = \frac{1}{2 \partial \mathsf{L}/\partial \mathbf{F}} \left\{ 2f^{kl} \frac{\partial}{\partial x^{l}} \left( \frac{\partial \mathsf{L}}{\partial \mathbf{F}} \right) + f^{*kl} \frac{\partial}{\partial x^{l}} \left( \frac{\partial \mathsf{L}}{\partial \mathbf{G}} \right) \right\}. \tag{7.3}$$

The equations (7.2) and (3.2) are form ally identical w ith the **equations of** the Lorentz theory. B ut the im portant difference consists in this, **that** p\* is *not* a given function of the space-tim e co-ordinates, b u t is a function of the unknown field strength. If we have a solution of our set of equations, we are able to find the density of the " free charge " or the " free current " with help of (7.2) or (7.3).

We see im m ediately th a t p7c satisfies th e conservation law :

$$\frac{\partial \sqrt{-g} \, \rho^k}{\partial x^k} = 0. \tag{7.4}$$

This follows from (7.2), th a t is from the antisym m etrical character o f / and can also be checked from (7.3).

In Lorentz's theory there exists the energy-impulse tensor of the electrom agnetic field, defined by

$$4 \pi S_k^{\ l} = \frac{1}{2} \delta_k^{\ l} F - f^{ls} f_{ks}, \tag{7.5}$$

b u t its divergence does not vanish, where the density of charge is not zero. Therefore to preserve the conservation principle in the Lorentz's theory it was necessary to introduce an energy-impulse tensor of m atter, MK, the meaning of which is obscure. The tensor M / had to fulfil the condition th a t the divergence of Sfcl -f- M / vanishes. This difficulty does not appear in our theory. W e do not need to introduce the m atter tensor Mfcl because the conservation laws are always satisfied by our energy-impulse tensor T /.

We shall, however, show th a t it is possible by introducing the free charges to bring our conservation law

$$T^k_{s|k} = 0$$

into the form used in the Lorentz theory, namely,

$$S^{k} = f^{sk} o_{ss} \tag{7.6}$$

The calculations are similar to those used in § 3. The simplest way is to choose a geodetic co-ordinate system. We have then :

$$\frac{\partial f^{kl}}{\partial x^l} = 4\pi \ \rho^k \tag{7.2A}$$

$$\frac{\partial f_{kl}}{\partial x^m} + \frac{\partial f_{lm}}{\partial x^k} + \frac{\partial f_{mk}}{\partial x^k} = 0.$$
 (3.2)

<span id="page-18-0"></span>Instiplying (3.2) by  $f^{kl}$  we find:

$$\frac{1}{2} \frac{\partial}{\partial x^s} (f_{kl} f^{kl}) - 2 \frac{\partial}{\partial x^l} (f^{lk} f_{sk}) = 2f_{sk} \frac{\partial f^{lk}}{\partial x^l}$$
 (7.7)

ad therefore

$$\frac{1}{4} \frac{\partial}{\partial x^s} (f_{kl} f^{kl}) - \frac{\partial}{\partial x^l} (f^{lk} f_{sk}) = f_{sk} \varrho^k, \tag{7.8}$$

$$\frac{\partial \mathbf{S}_{s}^{k}}{\partial x^{k}} = f_{sk} \, \mathbf{\rho}^{k}. \tag{7.9}$$

Coctoper Can derive the same of (7.5): ne can derive the same equation directly from the conservation formula \$\times\_{\text{.8}}\) writing it, in a geodetic co-ordinate system, in the form

$$\frac{\partial \mathbf{T}_s^k}{\partial x^k} = 0, \tag{3.8}$$

$$-4\pi\rho^{k} = \frac{1}{\sqrt{1 + \mathbf{F} - \mathbf{G}^{2}}} \left\{ f^{kl} \frac{\partial}{\partial x^{l}} \left( \frac{1}{\sqrt{1 + \mathbf{F} - \mathbf{G}^{2}}} \right) - f^{*kl} \frac{\partial}{\partial x^{l}} \left( \frac{1}{\sqrt{1 + \mathbf{F} - \mathbf{G}^{2}}} \right) \right\}. \tag{7.10}$$

$$(\rho_1, \, \rho_2, \, \rho_3, \, \rho_4) \rightarrow \left(\frac{\mathrm{I}}{c}, \, \rho\right),$$

We shall now apply the results here obtained to the case of the statical field. In this case **E** is always finite and has a non-vanishing divergence, which represents the free charge. We can, therefore, regard an electron either as a point charge, *i.e.*, as a source of the **D**  $(p_{kl})$  field, or as a continuous distribution of the space charge which is a source of the **E**  $(f_{kl})$  field. It can easily be shown that the whole charge is in both cases the same (as is to be expected). Both

 $\int \operatorname{div} \mathbf{D} \, dv$  and  $\int \operatorname{div} \mathbf{E} \, dv$ 

have the same value, i.e.,  $4\pi e$ . For the first integral it has been shown in § 6. For the second we have

$$E_r \sim \frac{e}{r^2}$$
 as  $r \to \infty$ ;

everywhere else  $E_r$  is finite. The discontinuity of  $E_x$ ,  $E_y$ ,  $E_z$  at the origin is also finite and gives no contribution to the integral. Therefore

$$\int \operatorname{div} \mathbf{E} \, dv = 4\pi \int \rho \, dv = 4\pi e.$$

Let us now calculate the distribution of the free charge in the statical case. We could calculate it from the equation (7.10A), but it is easier to do it from the equation

div 
$$\mathbf{E} = \frac{1}{r^2} \frac{d}{dr} (r^2 \mathbf{E}_r) = 4\pi \rho,$$
 (7.11)

where

$$E_r = \frac{e}{r_0^2} \frac{1}{\sqrt{1 + (r/r_0)^4}}.$$
 (6.15)

The result is

$$\rho = \frac{e}{2\pi r_0^3 \frac{r}{r_0} \left(1 + \left(\frac{r}{r_0}\right)^4\right)^{3/2}}.$$
 (7.12)

For  $r \gg r_0$ ,  $\rho \propto r^{-7}$ , therefore diminishing very rapidly as r increases. For  $r < r_0$ ,  $\rho \propto 1/r$ , therefore  $\rho \to \infty$ , but  $r^2 \rho \to 0$  for  $r \to 0$ . It is easy to verify that the space integral of  $\rho$  is equal to e. For one has, putting  $r/r_0 = \sqrt{\tan \phi}$ 

$$\int \! \rho \, dv = \frac{2e}{r_0^3} \! \int_0^\infty \frac{r^2 \, dr}{\frac{r}{r_0} \! \left(1 + \frac{r^4}{r_0^4}\right)^{3/2}} = e \int_0^{\pi/2} \cos \phi \, dy = e.$$

Our theory combines the two possible aspects of th e field ; tru e point charges ad free spatial densities are entirely equivalent. The question w hether the ae or the other picture of the electron is right has no meaning. This confirms lie idea which has proved so fruitful in quantum mechanics, th a t one as to be careful in applying notions from the macroscopic world to th e world of toms : it m ay happen th a t tw o notions contradictory in macroscopic use are iuite compatible in microphysics.

### § 8. *Lorentz's Equations of Point Motion and Mass.*

We consider once more th e problem of th e electron a t rest. We intend to alculate the mass and to determ ine the absolute field constant *b* in term s of bservable quantities. I t is convenient to use the space vector notation. The impulse-energy tensor is according to **(3.6b )**

$$\begin{array}{l} 0\pi\mathbf{X}_{x}=-\mathbf{D}_{x}\,\mathbf{E}_{x}-b^{2}\,\mathsf{L}=-\frac{\mathbf{E}_{x}^{2}}{\sqrt{1-1/b^{2}\mathbf{E}^{2}}}\\ &-b^{2}\Big(\sqrt{1-\frac{1}{b^{2}}\,\mathbf{E}^{2}}-1\Big)\\ 4\pi\mathbf{X}_{y}=-\mathbf{D}_{x}\,\mathbf{E}_{y}=-\frac{\mathbf{E}_{x}\,\mathbf{E}_{y}}{\sqrt{1-1/b^{2}\,\mathbf{E}^{2}}}\\ \mathbf{S}_{x}=\mathbf{S}_{y}=\mathbf{S}_{z}=0\\ 4\pi\mathbf{U}=\mathbf{D}\cdot\mathbf{E}+b^{2}\,\mathsf{L}=b^{2}\,\mathsf{H}=b^{2}\Big(\sqrt{1-\frac{1}{b^{2}}\,\mathbf{E}^{2}}-1\Big)\\ &+\frac{\mathbf{E}^{2}}{\sqrt{1-1/b^{2}\,\mathbf{E}^{2}}}=b^{2}\Big(\frac{1}{\sqrt{1-1/b^{2}\,\mathbf{E}^{2}}}-1\Big) \end{array}\right\}. \tag{3.6c}$$

*We* calculate the space integrals of these quantities. Obviously one has w ith *lv* = *dx dy d z :*

$$4\pi \int \mathbf{X}_{x} dv = 4\pi \int \mathbf{Y}_{y} dv = 4\pi \int \mathbf{Z}_{z} dv = -\frac{1}{3} \int \frac{\mathbf{E}^{2}}{\sqrt{1 - 1/b^{2} \mathbf{E}^{2}}} dv$$

$$-b^{2} \int \left(\sqrt{1 - \frac{1}{b^{2}} \mathbf{E}^{2}} - 1\right) dv \qquad (8.1)$$

$$\int \mathbf{X}_{y} dv = \int \mathbf{X}_{z} dv = \int \mathbf{Z}_{y} dv = 0. \qquad (8.2)$$

**Using (6.15) and** (6.8) we **find** :

$$\int X_x \, dv = b^2 \, (I_1 - I_2), \tag{8.3}$$

where

$$\begin{split} &\mathbf{I}_{1} = \int_{0}^{\infty} \left( 1 - \frac{x^{2}}{\sqrt{1 + x^{4}}} \right) x^{2} \, dx \\ &\mathbf{I}_{2} = \frac{1}{3} \int_{0}^{\infty} \frac{dx}{\sqrt{1 + x^{4}}} = \frac{1}{3} f\left( 0 \right) \end{split} \right). \end{split} \tag{8.4}$$

The in tegral I x can be tran sfo rm ed b y p a rtia l integ ratio n

$$I_1 = \frac{1}{3} \int_0^\infty \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) \frac{dx^3}{dx} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{1}{3} \left( 1 - \frac{x^2}{\sqrt{1+x^4}} \right) x^3 \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+x^4)^{3/2}} \right]_0^\infty + \frac{2}{3} \int_0^\infty \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+x^4)^{3/2}} \right]_0^\infty + \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+x^4)^{3/2}} \right]_0^\infty + \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+x^4)^{3/2}} \right]_0^\infty + \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+x^4)^{3/2}} \right]_0^\infty + \frac{x^4 dx}{(1+x^4)^{3/2}} dx = \left[ \frac{x^4 dx}{(1+$$

The first term vanishes ; th e second can be transform ed b y another partial integ ratio n :

$$\mathbf{I_1} = -\frac{1}{3} \int_0^\infty x \, \frac{d}{dx} \left( \frac{1}{\sqrt{1+x^4}} \right) dx = \frac{1}{3} \int_0^\infty \frac{dx}{\sqrt{1+x^4}} = \mathbf{I_2} = \frac{1}{3} f(0).$$

The result is th e so-called " theorem of L aue " t

$$\int X_x dv = \int Y_y dv = \int Z_z dv = 0.$$

In th e statical case an d in a co-ordinate system in w hich th e electron is at rest th e integrals of all com ponents of th e ten so r *T kl* vanish except th e total energy

$$E = \int U \, dv = \frac{b^2}{4\pi} \int H \, dv. \tag{8.5}$$

W e find from (3.6c), (6.15), an d (8.4)

$$\mathbf{E} = m_0 c^2 = \delta^2 r_0^3 (3\mathbf{I}_2 - \mathbf{I}_1) = \frac{e^2}{r_0} 2\mathbf{I}_1 = \frac{2}{3} \frac{e^2}{r_0} f(0) = 1 \cdot 2361 \frac{e^2}{r_0}.$$
 (8.6)

W e have obtained a *finite value of the energy or the mass of the electron* with a definite num erical factor. This relation enables us to com plete our theory concerning th e value of th e absolute field *b* in th e conventional runts. (8.6) gives th e *"* rad iu s " of th e electron expressed in term s of its charge and m ass :

$$r_0 = 1.2361 \frac{e^2}{m_0 c^2} = 2, 28 \times 10^{-13} \text{ cm}.$$
 (8.7)

an d

$$b = \frac{e}{r_0^2} = 9, 18 \cdot 10^{15} \text{ e.s.u.}$$
 (8.8)

The enorm ous m agnitude of th is field justifies th e application of the Maxwefif

**f Mie, ' Ann. Physik,' vol. 40, p. 1 (1913).**

quations in their classical form in all cases, except those where the inner tructure of the electron is concerned (field of the order b, distance or waveength of the order  $r_0$ ).

It can be shown that the motion of an elementary charge, on which an external field is acting, satisfies an equation which is an obvious generalization of the classical equation of Lorentz. To find this equation we shall use here a cartesian co-ordinate system.

We assume that the strength of the externation with the electron is very small compared with the We denote the proper field of the electron by  $p_{kl}^{(0)}$ ,  $f_{kl}^{(0)}$ , We assume that the strength of the external field in a region surrounding the electron is very small compared with the proper field of the point charge.

$$p_{kl}^{(0)}, f_{kl}^{(0)},$$
 (8.9)

Sand the external field by

$$p_{kl}^{(e)} = f_{kl}^{(e)};$$
 (8.10)

So we do not take into consideration the sources of the external field. So consideration, that  $p_{kl}^{(0)} \gg f_{kl}^{(e)}$ ;  $f_{kl}^{(0)} \gg f_{kl}^{(e)}$ 

(8.11)

inside the sphere surrounding the electron, it follows evidently that the real solution of the field equations cannot be very different from that obtained by adding the unperturbed proper field and the external field. We construct therefore a sphere  $S^{(0)}$  with its centre at the singularity of H and with a radius  $r^{(0)}$ , which is so small, that inside the sphere (8.11) is always satisfied. But the radius  $r^{(0)}$  of the sphere has to be great compared with the radius of the electron, so that we can assume the validity of Maxwell's equations on the surface of the sphere just as outside the sphere.

We make the further assumption that the acceleration (curvature of the world line) is not too large, *i.e.*, one can choose the radius in such a way that the field  $p_{kl}^{(0)}$  inside  $S^{(0)}$  is essentially identical with that of the charge e in uniform motion and can be derived from the formula of § 7 by a Lorentz transformation. Now we split the integral

$$\int H d\tau$$
 (8.12)

into a part corresponding to the sphere S(0) and the rest of space R. In S(0) we have

$$\begin{array}{l} \mathsf{H} = \sqrt{1 - \frac{1}{2} p_{kl} \, p^{kl}} - 1 \\ = \sqrt{1 - \frac{1}{2} p_{kl}^{(0)} \, p^{(0) \, kl} - p_{kl}^{(0)} f^{(e)kl} - \frac{1}{2} f_{kl}^{(e)} f^{(e)kl}} - 1 \\ \mathsf{Q} = 0 \end{array} \right\}. \quad (8.13)$$

Corresponding to **(8.11)** one can consider th e term s *f ki 0>f (e)kl* as **small** of the first order (compared w ith *f k i 0)f lom)>* th e term s *f ki e)f (e)kl* as small of the second order, and these la tte r will be neglected. Then we have by developing (8.13) and using **(4.14) :**

$$\mathsf{H} = \sqrt{1 - \frac{1}{2} p_{kl}^{(0)} p^{(0)kl}} - 1 - \frac{1}{2} f_{kl}^{(0)} f^{(e)kl}, \tag{8.14}$$

which holds inside the sphere S(0). W e can w rite (8.14) in another form :

H = H (0) — *%fki ° f (e)kl* H (0) = *Vl —* 1 J (8.15)

(8.15) differs from (8.14) only in th e term s of th e second order. But (8.15) holds n o t only inside b u t also outside th e sphere. F or in R th e equation (8.15) takes, according to our assum ptions ab o u t r (0), th e following form :

$$\begin{split} \mathsf{H} &= -\frac{1}{4} p_{kl}{}^{(0)} p^{(0)kl} - \frac{1}{2} f_{kl}{}^{(0)} f^{(e)kl} - \frac{1}{4} f_{kl}{}^{(e)} f^{(e)kl} \\ &= -\frac{1}{4} f_{kl}{}^{(0)} f^{(0)kl} - \frac{1}{2} f_{kl}{}^{(e)} f^{(0)kl} - \frac{1}{4} f_{kl}{}^{(e)} f^{(e)kl}. \end{split} \tag{8.16}$$

This is, however, th e know n expression for H in M axwell's theory ; (L = — H). Therefore (8.15) holds as well in the sphere S(0) as in R . One has

$$\int \mathbf{H} \, d\tau = \int \mathbf{H}^{(0)} \, d\tau - \frac{1}{2} \int f_{kl}^{(0)} \, f^{(e)kl} \, d\tau - \frac{1}{4} \int f_{kl}^{(e)} f^{(e)kl} \, d\tau. \tag{8.17}$$

W e introduce th e n otation

$$4\pi\Lambda = \int \mathsf{H}^{(0)} \, dv - \frac{1}{2} \int f_{kl}{}^{(0)} f^{(e)kl} \, dv - \frac{1}{4} \int f_{kl}{}^{(e)} f^{(e)kl} \, dv, \tag{8.18}$$

and have for th e action principle

$$\delta \int \Lambda dt = 0. \tag{8.19}$$

The integral

$$\int f_{kl}^{(e)} f^{(e)kl} \, d\tau \tag{8.20}$$

in (8.17) gives zero, because

$$\frac{\partial f^{(e)kl}}{\partial x^l} = 0 \; ; \quad (\rho_k^{(e)} = 0). \tag{8.21}$$

I f we bear in m ind th a t in th e co-ordinate system , where the point charge is at re s t,jH (0) *dv* is proportional to th e mass, we have :

$$\int \mathsf{H}^{(0)} \, dv = m_0 c^2 \int \sqrt{1 - \mathbf{v}^2/c^2} \, dv, \tag{8.22}$$

here v is the velocity of th e centre of th e electron. In th e second integral f (8.17) we have

**, <e> \_ \_** *11 dxk dxl* (8.23)

0r(O)W id by partial integration we find, using ■ . —- = 4rcpfc :

$$\frac{1}{2} \int f^{0kl} f_{kl}^{(e)} \, dv \, dt = -4\pi \int \phi_l^{(e)} \, \rho^l \, dv \, dt. \tag{8.24}$$

rhe additional surface integral over th e infinitely large surface can be om itted, because it gives no contribution to th e variation (8.19). The result i s :

$$\Lambda = m_0 c^2 \sqrt{1 - \mathbf{v}^2/c^2} - \int \phi_l^{(e)} \rho^l \ dv. \tag{8.25}$$

*We* can write (8.25) in the space-vector form :

$$\Lambda = m_0 c^2 \sqrt{1 - \mathbf{v}^2/c^2} - \int \phi^{(e)} \rho \, dv + \frac{1}{c} \int \mathbf{A} \mathbf{I} \, dv. \tag{8.25A}$$

**An electron behaves therefore like a mechanical systemf with the rest mass m0, acted on** by **the external field** *f ke(e).%*

**If the external potential is essentially constant in a region surrounding the electron considered, the diameter of which is large compared with r0, one gets instead of** (8.25):

$$\int \Lambda \, dt = \int m_0 c^2 \sqrt{1 - \mathbf{v}^2/e^2} + e \, (\phi^{(e)} - \mathbf{v} \, \mathbf{A}^{(e)}/c), \tag{8.26}$$

**and this is entirely equivalent to Lorentz's equations of motion. But our**

**t Born, 6 Ann. Physik/ vol. 28, p. 571 (1909); Pauli, " Relativitatstheorie," p. 642 (Teubner).**

**+ The method used in I for deriving the equation of motion is not correct. It started from the action principle in the form**

$$\delta \int \mathsf{L} \, d au = 0$$
 (instead  $\delta \int \mathsf{H} \, d au = 0$ );

**then in the development instead of the coefficients** *f ki***(°) the ^>^(°) appear, which become infinite at the centre of the electron. Therefore the transformation of the space integral is not allowed. In the first approximation we have**

*Pki — P k l^* **+** *Pkl^* **and** *not*

$$f_{kl} = f_{kl}^{(0)} + f_{kl}^{(e)}.$$

**The mistake in the former derivation is also shown by the wrong result for the mass (the numerical factor was half of that given here).**

formula (8.25) holds also for fields which are not constant. Any field can be split up in Fourier components or elementary waves; we may consider each of those separately, and choosing the Z-axis parallel to the propagation of the wave, we can assume that  $\phi_s^{(e)}$  is proportional to  $e^{2\pi i z/\lambda}$ . Then we see that this Fourier component gives a contribution to the integral (8.25) of the form (8.26), where  $\phi_s^{(e)}$  is now the amplitude of this component and e has to be replaced by an "effective" charge  $\bar{e}$ , given by

$$ar{e} = \int \, 
ho e^{2\pi i \, z/\lambda} dv.$$

Using the expression of  $\rho$  given by (7.12), and putting  $z = r \cos \vartheta$ ,

$$dv = r^2 \sin \vartheta \, d\vartheta \, d\phi \, dr,$$

one has

$$e = \frac{e}{{r_0}^3} \int_0^\infty \int_0^\pi \frac{r^2 \, dr}{\frac{r}{r_0} \Big(1 + \frac{r^4}{{r_0}^4}\Big)^{\!\!\!\!/ 2}} e^{\frac{2\pi i r}{\lambda} \cos\vartheta} \sin\vartheta \, d\vartheta \, .$$

The & integration can be performed, and one can write

$$\bar{e} = e\,g\left(\frac{2\pi r_0}{\lambda}\right); \quad g\left(x\right) = \frac{2}{x}\int_0^\infty \frac{\sin xy}{(1+y^4)^{3/2}}\,dy.$$

For waves long compared with  $r_0$  one has  $\bar{e} = e$ , because g(0) = 1. But for decreasing wave-lengths the effective charge diminishes, as the little table for g(x) shows:—

Table of g(x).

| æ.  | g (x). | x.   | g(x).            |
|-----|--------|------|------------------|
|     |        |      |                  |
| 0   | 1      | 1.25 | 0.796            |
| 0.1 | 0.988  | 1.50 | 0.730            |
| 0.2 | 0.984  | 1.75 | 0.659            |
| 0.3 | 0.968  | 2.00 | 0.588            |
| 0.4 | 0.959  | 2.25 | 0.526            |
| 0.5 | 0.949  | 2.50 | 0.457            |
| 0.6 | 0.929  | 3.00 | 0.347            |
| 0.7 | 0.917  | 3.50 | 0.252            |
| 0.8 | 0.901  | 4.00 | 0.186            |
| 0.9 | 0.880  | 5.00 | 0.094            |
| 1.0 | 0.856  |      | 2734 11370 12750 |

The decrease begins to become remarkable where  $x \sim 1$ , or  $\lambda \sim 2\pi r_0$ . For large x one has  $g(x) \approx 2/x^2$ .

<sup>†</sup> Calculated by Mr. Devonshire.

If we introduce the quantum energy corresponding to the w ave-length X }y E = *hcj'k,* then using (8.6) one has

$$x = \frac{2\pi r_0}{\lambda} = 1 \cdot 236 \frac{2\pi}{hc} \frac{E}{m_0 c^2} = \frac{1 \cdot 236}{137 \cdot 1} \frac{E}{m_0 c^2} = \frac{1}{111} \frac{E}{m_0 c^2}.$$

*x* — **1** corresponds to a quantum energy of about **100** *m Qc2 =* 5 . **107** e. volt. For energies larger th an this the interaction of electrons w ith other electrons (or light waves excited by those) should become smaller th an th a t calculated by the accepted theories. This consequence seems to be confirmed by the astonishingly high penetrating power of the cosmic ray s.f

### *Summary.*

The new field theory can be considered as a revival of the old idea of the electromagnetic origin of mass. The field equations can be derived from the postulate th a t there exists an **"** absolute field **"** *b* which is the n atu ral unit for all field components and the upper lim it of a purely electric field. From th e standpoint of relativity transform ations the theory can be founded on the assumption th a t the field is represented by a non-sym m etrical tensor *akl,* and th a t the Lagrangian is the square root of its d e te rm in an t; the sym m etrical part *gkl* of *akt* represents the m etric field, the antisym m etrical p a rt the electromagnetic field. The field equations have the form of Maxwell's equations for a polarizable medium for which the dielectric constant and the m agnetic susceptibility are special functions of the field components. The conservation laws of energy and m omentum can be derived. The static solution with spherical sym m etry corresponds to an electron w ith finite energy (or mass) ; the true charge can be considered as concentrated in a point, b u t it is also possible to introduce a free charge with a spatial distribution law. The motion of the electron in an external field obeys a law of the Lorentz type where the force is the integral of the product of the field and the free charge density. From this follows a decrease of the force for alternating fields of short wavelengths (of the order of the electronic radius), in agreement w ith the observations of the penetrating power of high frequency (cosmic) rays.

**f Bom, ' Nature,' vol. 133, p. 63 (1934).**