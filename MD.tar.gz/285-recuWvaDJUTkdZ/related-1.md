# Geometrical aspects of light propagation in nonlinear electrodynamics

M. Novello<sup>1\*</sup>, V. A. De Lorenci<sup>2†</sup>, J. M. Salim<sup>1</sup> and R. Klippert<sup>1,2</sup>

<sup>1</sup> Centro Brasileiro de Pesquisas Físicas Rua Dr. Xavier Sigaud 150, Urca 22290-180 Rio de Janeiro, RJ – Brazil <sup>2</sup> Instituto de Ciências – Escola Federal de Engenharia de Itajubá Av. BPS 1303 Pinheirinho, 37500-000 Itajubá, MG – Brazil (November 7, 2018)

# Abstract

We analyze the propagation of light in the context of nonlinear electrodynamics, as it occurs in modified QED vacua. We show that the corresponding characteristic equation can be described in terms of a modification of the effective geometry of the underlying spacetime structure. We present the general form for this effective geometry and exhibit some new consequences that result from such approach.

## PACS numbers: 12.20.Ds, 11.10.Wx, 41.20.Jb

### I. INTRODUCTION

## A. Introductory remarks

Modifications of light propagation in different vacua states has recently been a subject of interest. Such investigation shows that, under distinct non trivial vacua (related to several circumstances such as temperature effects, particular boundary conditions, quantum polarization, etc), the motion of light can be viewed as electromagnetic waves propagating through a classical dispersive medium. The medium induces modifications on the equations of motion, which are described in terms of nonlinearities of the field. In order to apply such a medium interpretation we consider modifications of electrodynamics due to virtual pair creation. In this case the effects can be simulated by an effective Lagrangian which depends only on the two gauge invariants F and G of the electromagnetic field [1,2].

One of the main achievements of such investigation is the understanding that, in such nonlinear framework, photons propagate along geodesics that are no more null in the actual Minkowski spacetime but in another effective geometry. Although the basic understanding of this fact — at least for the specific case of Born-Infeld electrodynamics — has been known for a long time [3], it has been scarcely noticed in the literature. Moreover, its consequences were not exploited any further. In particular, we emphasize the general application and the corresponding consequences of the method of the effective geometry outlined here.

The exam of the photon propagation beyond Maxwell electrodynamics has a rather diversified history: it has

been investigated in curved spacetime, as a consequence of non-minimal coupling of electrodynamics with gravity [4,5] and in nontrivial QED vacua, as an effective modification induced by quantum fluctuations [6,1,2]. As a consequence of this examination some unexpected results appear. Just to point one out, we mention the possibility of faster-than-light photons<sup>1</sup>.

The general approach of all these theories is based on a gauge invariant effective action, which takes into account modifications of Maxwell electrodynamics induced by different sorts of processes. Such a procedure is intended to deal with the quantum vacuum as if it were a classical medium. Another important consequence of such point of view is the possibility to interpret all such vacua modifications — with respect to the photon propagation — as an effective change of the spacetime metric properties. This result allows one to appeal to an analogy with the electromagnetic wave propagation in curved spacetime due to gravitational phenomena.

# B. Synopsis

In this paper we deal with light propagation in non-linear electrodynamics. The origin of such nonlinearity is not unique. It can be a consequence of modified QED vacua [7–9] or deal to nonlinear response of a dielectric medium. There are different ways to evaluate the characteristic surfaces of the wave propagation. However, there seems to be no better and elegant manner than the one proposed by Hadamard. We briefly review its main lines in Section II. Firstly, we deal only with one-

<sup>\*</sup>Electronic mail: novello@lafex.cbpf.br †Electronic mail: lorenci@cpd.efei.br

<sup>&</sup>lt;sup>1</sup>The meaning of such expression is that the wave discontinuities propagate along spacelike characteristic surfaces in the Minkowski background.

<span id="page-1-0"></span>parameter Lagrangians, which means that those theories depend only upon the gauge invariant F. In the subsequent section we generalize for the full dependence upon the two algebraic invariants of electrodynamics. We show an elegant property of such nonlinear theories: the electromagnetic wave propagation can be described as if the metric structure of the background were changed from its Minkowskian value into another effective metric, which depends on the dynamics of the background electromagnetic field. Thus, this equivalence property mimics the corresponding properties of the photon propagation in gravitational fields. Indeed, as we will show in Section III, photons described by nonlinear electrodynamics propagate as null geodesics in an effective metric that is distinct from the Minkowskian one. We show a remarkable consequence of such interpretation: the possibility of generating a compact domain in which photons are trapped by the nonlinear electromagnetic field. This suggests the possibility that an analogy with a gravitational black hole – which we should name electromagnetic black hole – could exist. Besides, we show that one can find a similar phenomenon inside a dielectric medium that responds nonlinearly to an external stimulus. In Section IV we analyze the light velocity dependence on the scale anomaly of the field. We show that there is not a deep interconnection between such scale anomaly and the phenomenon of birefringence. Finally, we end with some comments concerning the new effects that are to be expected for such nonlinear photons. Typical Riemannian calculations are presented in appendix A, in which it is shown that the standard geodesic assumption for photons also holds for the nonlinear case. Connections with Rainich-Wheeler formalism [10] are also provided in appendix B.

## C. Definitions and notations

We call the electromagnetic tensor  $F_{\mu\nu}$ , while its dual  $F_{\mu\nu}$  is

$$\overset{*}{F}_{\alpha\beta} \doteq \frac{1}{2} \eta_{\alpha\beta}{}^{\mu\nu} F_{\mu\nu}, \tag{1}$$

where  $\eta_{\alpha\beta\mu\nu}$  is the completely antisymmetric Levi-Civita tensor; the Minkowski metric tensor is represented by its standard form  $\eta^{\mu\nu}$ . The two invariants constructed with these tensors are defined as

$$F \doteq F^{\mu\nu} F_{\mu\nu},\tag{2}$$

$$G \doteq F^{\mu\nu} \stackrel{*}{F}_{\mu\nu}. \tag{3}$$

Once the modifications of the vacuum which will be dealt here do not break the gauge invariance of the theory, the general form of the modified Lagrangian for electrodynamics may be written as a functional of the above

invariants, that is,

$$L = L(F, G).$$

We denote by  $L_F$  and  $L_G$  the derivatives of the Lagrangian L with respect to the invariant F and G, respectively; and similarly for the higher order derivatives. We are particularly interested in the derivation of the characteristic surfaces which guide the propagation of the field discontinuities.

Let  $\Sigma$  be a surface of discontinuity for the electromagnetic field. Following Hadamard [11] we assume that the field itself is continuous when crossing  $\Sigma$ , while its first derivative presents a finite discontinuity. We accordingly set

$$[F_{\mu\nu}]_{\Sigma} = 0, \tag{4}$$

and

$$[\partial_{\lambda} F_{\mu\nu}]_{\Sigma} = f_{\mu\nu} k_{\lambda}, \tag{5}$$

in which the symbol

$$[J]_{\Sigma} \equiv \lim_{\delta \to 0^+} (J|_{\Sigma + \delta} - J|_{\Sigma - \delta})$$

represents the discontinuity of the arbitrary function J through the surface  $\Sigma$  characterized by the equation  $\Sigma(x^{\mu}) = constant$ . The tensor  $f_{\mu\nu}$  is called the discontinuity of the field, and

$$k_{\lambda} = \partial_{\lambda} \Sigma \tag{6}$$

is the propagation vector.

# II. THE METHOD OF THE EFFECTIVE GEOMETRY

# A. One-parameter Lagrangians

Our generic purpose in this paper is to investigate the effects of nonlinearities in the equation of evolution of electromagnetic waves. We will restrict the analysis in this section to the simple class of gauge invariant Lagrangians defined by

$$L = L(F). (7)$$

From the least action principle we obtain the field equation

$$\partial_{\mu} \left( L_F F^{\mu\nu} \right) = 0. \tag{8}$$

Applying conditions (4) and (5) for the discontinuity of the field equation (8) through  $\Sigma$  we obtain

$$L_F f^{\mu\nu} k_{\nu} + 2L_{FF} \xi F^{\mu\nu} k_{\nu} = 0, \tag{9}$$

where  $\xi$  is defined by

$$\xi \doteq F^{\alpha\beta} f_{\alpha\beta}. \tag{10}$$

<span id="page-2-0"></span>The consequence of such discontinuity in the cyclic identity is

$$f_{\mu\nu}k_{\lambda} + f_{\nu\lambda}k_{\mu} + f_{\lambda\mu}k_{\nu} = 0. \tag{11}$$

In order to obtain a scalar relation we contract this equation with  $k_{\alpha}\eta^{\alpha\lambda}F^{\mu\nu}$ , resulting

$$\xi k_{\nu} k_{\mu} \eta^{\mu\nu} + 2F^{\mu\nu} f_{\nu}{}^{\lambda} k_{\lambda} k_{\mu} = 0. \tag{12}$$

Let us consider the case in which  $\xi$  does not vanish<sup>2</sup>. From equations (9) and (12) we obtain the propagation equation for the field discontinuities as given by

$$(L_F \eta^{\mu\nu} - 4L_{FF} F^{\mu\alpha} F_{\alpha}{}^{\nu}) k_{\mu} k_{\nu} = 0.$$
 (13)

Expression (13) suggests that one can interpret the self-interaction of the background field  $F^{\mu\nu}$ , in what concerns the propagation of electromagnetic discontinuities (5), as if it had induced a modification on the spacetime metric  $\eta_{\mu\nu}$ , leading to the effective geometry

$$g_{\text{eff}}^{\mu\nu} = L_F \, \eta^{\mu\nu} - 4 \, L_{FF} \, F^{\mu}{}_{\alpha} \, F^{\alpha\nu}.$$
 (14)

A simple inspection of this equation shows that only in the particular case of linear Maxwell electrodynamics the discontinuity of the electromagnetic field propagates along null paths in the Minkowski background.

The general expression of the effective geometry can be equivalently written in terms of the vacuum expectation value (VEV) of the energy-momentum tensor, given by

$$T_{\mu\nu} \equiv \frac{2}{\sqrt{-\gamma}} \frac{\delta \Gamma}{\delta \gamma^{\mu\nu}},\tag{15}$$

where  $\Gamma$  is the effective action

$$\Gamma \doteq \int d^4x \sqrt{-\gamma} L, \tag{16}$$

and  $\gamma_{\mu\nu}$  is the Minkowski metric written in an arbitrary coordinate system;  $\gamma$  is the corresponding determinant. In the case of one-parameter Lagrangians, L = L(F), we obtain

$$T_{\mu\nu} = -4L_F F_{\mu}^{\ \alpha} F_{\alpha\nu} - L \eta_{\mu\nu}, \tag{17}$$

where we have chosen an Euclidean coordinate system in which  $\gamma_{\mu\nu}$  reduces to  $\eta_{\mu\nu}$ . In terms of this tensor the effective geometry (14) can be re-written as<sup>3</sup>

$$g^{\mu\nu} = \left(L_F + \frac{LL_{FF}}{L_F}\right)\eta^{\mu\nu} + \frac{L_{FF}}{L_F}T^{\mu\nu}.\tag{18}$$

We remark that, once the modified geometry along which the photon propagates depends upon the energy-momentum tensor distribution of the background electromagnetic field, it is tempting to search for an analogy with the corresponding behavior of photons in a gravitational field<sup>4</sup>. We will return to this question in Section III.

Therefore, the field discontinuities propagate along null geodesics<sup>5</sup> in an effective geometry which depends on the field energy distribution. Let us point out that, as it is explicitly shown from the above equation, the stress-energy distribution of the field is the true responsible for the deviation of the geometry, as felt by photons, from its Minkowskian form<sup>6</sup>.

In order to show (see Appendix A) that the photon path is actually a geodesic curve, it is necessary to know the inverse  $g^{\mu\nu}$  of the effective metric  $g_{\nu\lambda}$ , defined by

$$g^{\mu\nu} g_{\nu\lambda} = \delta^{\mu}_{\lambda}. \tag{19}$$

This calculation is simplified if we take into account the well known properties:

$$F^{\nu\lambda}_{\mu\nu}F^{\nu\lambda} = -\frac{1}{4}G\delta^{\lambda}_{\mu}, \qquad (20)$$

and

$${\stackrel{*}{F}}_{\mu\lambda} {\stackrel{*}{F}}^{\lambda\nu} - F_{\mu\lambda} F^{\lambda\nu} = \frac{1}{2} F \delta^{\nu}_{\mu}. \tag{21}$$

Thus the covariant form of the metric can be written in the form:

$$g_{\mu\nu} = a\,\eta_{\mu\nu} + b\,T_{\mu\nu},\tag{22}$$

in which a and b are given in terms of the Lagrangian and its corresponding derivatives by:

$$a = -b \left( \frac{L_F^2}{L_{FF}} + L + \frac{1}{2} T \right),$$
 (23)

and

<sup>&</sup>lt;sup>2</sup>For the case in which  $\xi=0$ , the quantity  $f_{\mu\nu}$  is a singular two-form. Following Lichnerowicz [12], it can be decomposed in terms of the propagating vector  $k_{\mu}$  and a spacelike vector  $a_{\mu}=a\,\epsilon_{\mu}$  orthogonal to  $k_{\mu}$ , in which  $\epsilon_{\mu}$  is the normalized polarization vector. Hence, we can write  $f_{\mu\nu}=k_{\mu}\,a_{\nu}-k_{\nu}\,a_{\mu}$  on  $\Sigma$ . From equation (9) it follows that  $f^{\mu\nu}k_{\nu}=0$ , and contracting (11) with  $\eta^{\lambda\rho}k_{\rho}$  yields  $f_{\mu\nu}\eta^{\alpha\beta}k_{\alpha}k_{\beta}=0$ . Therefore, such modes propagate along standard null geodesics in Minkowski spacetime.

 $<sup>^3</sup> For$  simplicity, we will denote the effective metric as  $g^{\mu\nu}$  instead of  $g_{\rm eff}^{\mu\nu}$  from now on.

<sup>&</sup>lt;sup>4</sup>Let us emphasize that it is no more than a simple analogy.

<sup>5</sup>The proof that such curve is in fact a geodesic line is given in Appendix A.

<sup>&</sup>lt;sup>6</sup>For  $T_{\mu\nu} = 0$ , the conformal modification in (18) clearly leaves the photon paths unchanged.

<span id="page-3-0"></span>
$$b = 16 \frac{L_{FF}}{L_F} \left[ \left( F^2 + G^2 \right) L_{FF}^2 - 16 \left( L_F + F L_{FF} \right)^2 \right]^{-1},$$
(24)

where  $T=T_{\alpha}^{\alpha}$  is the trace of the energy-momentum tensor.

#### B. Two parameter Lagrangians

In this section we will go one step further and deal with the general case in which the effective action depends upon both invariants, that is

$$L = L(F, G). \tag{25}$$

The equations of motion are

$$\partial_{\nu} \left( L_F F^{\mu\nu} + L_G F^{*\mu\nu} \right) = 0. \tag{26}$$

Our aim is to examine the propagation of the discontinuities in such case. Following the same procedure as presented in the previous section one gets

$$[L_F f^{\mu\nu} + 2A F^{\mu\nu} + 2B F^{\mu\nu}] k_{\nu} = 0, \tag{27}$$

and contracting this expression with  $F^{\alpha}{}_{\mu}k_{\alpha}$  and with  $F^{\alpha}{}_{\mu}k_{\alpha}$ , respectively, yields

$$\left[\xi L_F + \frac{1}{2} B G\right] \eta^{\mu\nu} k_{\mu} k_{\nu} - 2A F^{\nu}{}_{\alpha} F^{\alpha\mu} k_{\nu} k_{\mu} = 0 \quad (28)$$

and

$$\left[\zeta L_F - B F + \frac{1}{2} A G\right] \eta^{\mu\nu} k_{\mu} k_{\nu} - 2B F^{\nu}{}_{\alpha} F^{\alpha\mu} k_{\nu} k_{\mu} = 0.$$
(29)

In these expressions we have set

$$A \doteq 2 \left( \xi \, L_{FF} + \zeta \, L_{FG} \right),$$

$$B \doteq 2 \left( \xi L_{FG} + \zeta L_{GG} \right),$$

and  $\zeta$  is defined by

$$\zeta \doteq F^{\alpha\beta} f_{\alpha\beta}. \tag{30}$$

In order to simplify our equations it is worth defining the quantity  $\Omega \doteq \zeta/\xi$ . From equations (28) and (29) it follows

$$\Omega^2 \Omega_1 + \Omega \Omega_2 + \Omega_3 = 0, \tag{31}$$

with the quantities  $\Omega_i$ , i = 1, 2, 3 given by

$$\Omega_1 = -L_F L_{FG} + 2F L_{FG} L_{GG} 
+ G(L_{GG}^2 - L_{FG}^2),$$
(32)

$$\Omega_2 = (L_F + 2GL_{FG})(L_{GG} - L_{FF}) 
+ 2F(L_{FF}L_{GG} + L_{FC}^2),$$
(33)

$$\Omega_3 = L_F L_{FG} + 2F L_{FF} L_{FG} 
+ G(L_{FG}^2 - L_{FF}^2).$$
(34)

The quantity  $\Omega$  has two solutions and is given by the algebraic expression

$$\Omega_{\pm} = \frac{-\Omega_2 \pm \sqrt{\Delta}}{2\Omega_1},\tag{35}$$

where

$$\Delta \doteq (\Omega_2)^2 - 4\Omega_1\Omega_3.$$

Thus, in the general case we are concerned here, the photon paths are kinematically described by

$$g_{\pm}^{\mu\nu} k_{\mu} k_{\nu} = 0, \tag{36}$$

where the effective metrics  $g_{\pm}^{\mu\nu}$  are given by

$$g_{\pm}^{\mu\nu} = L_F \eta^{\mu\nu} - 4 \left[ (L_{FF} + \Omega_{\pm} L_{FG}) F^{\mu}{}_{\lambda} F^{\lambda\nu} + (L_{FG} + \Omega_{\pm} L_{GG}) F^{\mu}{}_{\lambda} F^{\lambda\nu} \right].$$
(37)

When the Lagrangian does not depend on the invariant G, expression (37) reduces to the form (14).

As we see, from equation (35), there will be two possible solutions for the paths of light, which are related to its different modes of polarization, indicating that birrefringence phenomena could be described here, in a general way, depending on the particular theory we shall consider.

The tensor of discontinuities, given by equation (5), can be decomposed as

$$f_{\alpha\beta} = a \left( p_{\alpha} k_{\beta} - p_{\beta} k_{\alpha} \right) \tag{38}$$

where a in the strength of the wavelet and  $p_{\alpha}$  represents the polarization vector, which is ortogonal to  $k_{\mu}$  and normalized to unity:

$$p^{\alpha}k_{\alpha} = 0 \tag{39}$$

$$p^{\alpha}p_{\alpha} = -1. \tag{40}$$

For a given wave vector  $k_{\mu}$  there will be two linearly independent polarization vectors  $p_{\mu}$ , which satisfy the above conditions. Introducing  $f_{\alpha\beta}$  in the field equations (27) we obtain the expression that describes the states of polarization, that is,

$$k^{2}p^{\mu} = -\frac{4}{L_{F}} \left[ L_{FF}F^{\mu\alpha}F^{\nu\beta} + L_{GG}F^{\mu\alpha}F^{\nu\beta} + L_{FG} \left( F^{\mu\alpha}F^{\nu\beta} + F^{\mu\alpha}F^{\nu\beta} \right) \right] k_{\alpha}k_{\beta}p_{\nu}.$$
(41)

<span id="page-4-0"></span>This equation must be solved using each solution of the wave vector coming from equation (36) when the effective metrics  $g_{\pm}^{\mu\nu}$  are used.

From the general expression of the energy-momentum tensor for an electromagnetic theory  $L=L(F,\,G)$  we have

$$T_{\mu\nu} = -4L_F F_{\mu}^{\ \alpha} F_{\alpha\nu} - (L - G L_G) \eta_{\mu\nu}. \tag{42}$$

The scale anomaly is given by the trace

$$T = 4 \left( -L + F L_F + G L_G \right). \tag{43}$$

We can then re-write the effective geometry in a more appealing form in terms of the energy momentum tensor, that is,

$$q^{\mu\nu} = \mathcal{M}_{+} \, \eta^{\mu\nu} + \mathcal{N}_{+} \, T^{\mu\nu}, \tag{44}$$

where the functions  $\mathcal{M}_{+}$  and  $\mathcal{N}_{+}$  are given by

$$\mathcal{M}_{\pm} = L_F + G \left( L_{FG} + \Omega_{\pm} L_{GG} \right) + \frac{1}{L_F} \left( L_{FF} + \Omega_{\pm} L_{FG} \right) \left( L - G L_G \right), \tag{45}$$

$$\mathcal{N}_{\pm} = \frac{1}{L_F} \left( L_{FF} + \Omega_{\pm} L_{FG} \right). \tag{46}$$

As a consequence of this, the Minkowskian norm of the propagation vector  $k_{\mu}$  reads

$$\eta^{\mu\nu}k_{\mu}\,k_{\nu} = -\frac{\mathcal{N}_{\pm}}{\mathcal{M}_{\pm}}T^{\mu\nu}k_{\mu}k_{\nu}.\tag{47}$$

# C. Exceptional Lagrangians

It seems worth noting that equation (37) contains a remarkable result: the velocities of the photon are, in general, doubled. There are some exceptional cases, however, for which the uniqueness of the path is guaranteed by the equations of motion [13,14]. Such uniqueness occurs for those dynamics described by Lagrangian L that satisfy the condition

$$\Delta = 0$$
.

The most known example of such uniqueness for the photon velocity in a nonlinear theory is the Born-Infeld electrodynamics. Let us pause for a while in order to make the following remark. In the case of the Born-Infeld theory all quantities  $\Omega_i$ , i=1,2,3 vanish identically. Hence, in this situation we cannot obtain the effective geometry from equation (37). In this very exceptional case we proceed as follows. Let us return to the original equation (28). Now, the Lagrangian for the Born-Infeld model is provided by the expression

$$L = \sqrt{b^4 + \frac{1}{2}b^2F - \frac{1}{16}G^2} - b^2.$$
 (48)

Substituting this form of L into equation (28) we obtain the unique characteristic equation

$$A \left[ \left( b^2 + \frac{1}{2} F \right) \eta^{\mu\nu} + F^{\mu}{}_{\lambda} F^{\lambda\nu} \right] k_{\mu} k_{\nu} = 0, \qquad (49)$$

thus yielding (for  $A \neq 0$ )

$$g^{\mu\nu} = (b^2 + \frac{1}{2} F) \eta^{\mu\nu} + F^{\mu}{}_{\lambda} F^{\lambda\nu}, \tag{50}$$

which does not show birefringence. This formula was obtained for the first time by Plebansky [3].

## III. SOME REMARKABLE CONSEQUENCES

#### A. Electromagnetic traps

The possibility of writing the characteristic equation for nonlinear electrodynamics in terms of an effective modification of the spacetime metric has some unexpected and wide-ranging consequences. One of these concerns to the existence of trapped photons in a compact domain. Such a configuration is made possible due to the nonlinearity of electrodynamics, and has a striking resemblance to gravitational black holes, although not presenting all properties of the latter.

We will concentrate here on a toy model, just to exhibit the possibility of new phenomena induced by the nonlinearities. The well known solution  $\eta^{\mu\nu}k_{\mu}k_{\nu}=0$ , that also appears in this case, will not be considered. Let us start with a static and spherically symmetric field for the case L=L(F). The source is an electric monopole located at the origin of the spherical coordinate system  $(t, r, \theta, \varphi)$ . We set for the non-zero components of the electromagnetic field the form

$$F_{tr} = E(r)$$
.

The equation of motion are easily solved, yielding

$$L_F E = \frac{Q}{r^2}. (51)$$

The corresponding effective geometry (14) is given by

$$g^{tt} = -g^{rr} = L_F - 4L_{FF}E^2, (52)$$

while the remaining non-zero components have values proportional to those of Minkowski geometry,

$$g^{\theta\theta} = -\frac{1}{r^2} L_F,\tag{53}$$

$$g^{\varphi\varphi} = -\frac{1}{r^2 \sin^2 \theta} L_F. \tag{54}$$

From equation (52) it follows that it is possible to envisage the existence of a region  $\mathcal{D}$  defined by some finite radius  $r = r_c$  such that  $g^{rr}(r_c)$  vanishes. The metric

component  $g^{tt}$  also vanishes at  $\mathcal{D}$ . Then, coordinates r and t interchange their roles when crossing  $\mathcal{D}$ , that is  $g^{tt}(r > r_c) > 0$ ,  $g^{rr}(r > r_c) < 0$ , and  $g^{tt}(r < r_c) < 0$ ,  $g^{rr}(r < r_c) > 0$ . Let us note, however, that the existence of such  $r_c$  implies that there is a further undesirable consequence concerning the value of the electric field. Indeed, equation (51) yields

$$r\frac{\partial r}{\partial E} = \frac{Q}{2L_F^2 E^2} g^{rr}.$$
 (55)

Thus it follows from this that, at  $\mathcal{D}$ , there is a possibility of the existence of a field barrier, that is a limitation of the domain of its existence due to the possibility of the inverse function r = r(E) to have an extremum. In order to avoid such limitation of the domain of definition for the electric field, the theory must be such that the second derivative vanishes at  $r_c$ , that is

$$\frac{\partial g^{rr}}{\partial E}|_{\mathcal{D}} = 0.$$

Besides, one must impose the supplementary condition

$$\frac{\partial^2 g^{rr}}{\partial E^2}|_{\mathcal{D}} \neq 0.$$

Thus, if the theory L = L(F) allows this kind of solution, then three typical properties of a trapped region appear:

- There exists a null surface  $\mathcal{D}$ , defined by  $r = r_c$  in the effective geometry.
- Coordinates t and r interchange their role when crossing  $\mathcal{D}$ .
- Light cones inside the region bounded by  $\mathcal{D}$  are directed towards the origin of the r-coordinate which plays the role, in this domain and only for photon propagation, of a time-like coordinate.

These theories should be further examined, since from what we have seen above, they may be the germ of the existence of the electromagnetic version of the gravitational black hole. Let us now turn our examination to a very similar situation inside material media.

# B. Wave propagation in nonlinear dielectric media

It is possible to describe the wave propagation, governed by Maxwell electrodynamics, inside a dielectric, in terms of a modification of the underlying spacetime geometry using the framework developed above. The electromagnetic field is represented by two antisymmetric tensors, the electromagnetic field  $F_{\mu\nu}$  and the polarization  $P_{\mu\nu}$ . These tensors are decomposed, in the standard way, into their corresponding electric and magnetic parts as seen by an observer which moves with velocity  $v_{\mu}$ . We can write:

$$F_{\mu\nu} = E_{\mu} \, v_{\nu} - E_{\nu} \, v_{\mu} + \eta^{\rho\sigma}_{\ \mu\nu} \, v_{\rho} \, H_{\sigma}, \tag{56}$$

$$P_{\mu\nu} = D_{\mu} \, v_{\nu} - D_{\nu} \, v_{\mu} + \eta^{\rho\sigma}_{\ \mu\nu} \, v_{\rho} \, B_{\sigma}. \tag{57}$$

Following Hadamard, we consider the discontinuities on the fields as given by

$$\begin{aligned}
\left[\nabla_{\lambda} E_{\mu}\right]_{\Sigma} &= k_{\lambda} e_{\mu}, \\
\left[\nabla_{\lambda} D_{\mu}\right]_{\Sigma} &= k_{\lambda} d_{\mu}, \\
\left[\nabla_{\lambda} H_{\mu}\right]_{\Sigma} &= k_{\lambda} h_{\mu}, \\
\left[\nabla_{\lambda} B_{\mu}\right]_{\Sigma} &= k_{\lambda} b_{\mu}.
\end{aligned} (58)$$

For the simplest linear case, in which we have

$$D_{\alpha} = \epsilon E_{\alpha},\tag{59}$$

$$B_{\alpha} = \frac{H_{\alpha}}{\mu},\tag{60}$$

it follows that

$$d_{\alpha} = \epsilon \, e_{\alpha},\tag{61}$$

$$b_{\alpha} = \frac{h_{\alpha}}{\mu}.\tag{62}$$

After a straightforward calculation one obtains

$$k_{\mu} k_{\nu} \left[ \gamma^{\mu\nu} + (\epsilon \mu - 1) v^{\mu} v^{\nu} \right] = 0.$$
 (63)

Let us generalize this situation for the nonlinear case. Maxwell equations are given by

$$\partial^{\nu} \stackrel{*}{F}_{\mu\nu} = 0, \tag{64}$$

$$\partial^{\nu} P_{\mu\nu} = 0. \tag{65}$$

For electrostatic fields inside isotropic dielectrics it follows that  $P^{\mu\nu}$  and  $F^{\mu\nu}$  are related by

$$P_{\mu\nu} = \epsilon(E)F_{\mu\nu}.\tag{66}$$

where  $\epsilon$  is the electric susceptibility. In the general case, for  $\epsilon = \epsilon(E)$  we simplify our calculation if we note that we can relate the equation of wave propagation to the previous analysis on vacuum polarization (7) by means of the identification

$$L_F \longrightarrow \epsilon,$$
 (67)

which implies

$$L_{FF} \longrightarrow -\frac{\epsilon'}{4E},$$
 (68)

in which  $\epsilon' \equiv d \epsilon/d E$ . Therefore, the simple class of effective Lagrangians (7) may be used as a convenient description of Maxwell theory inside isotropic nonlinear dielectric media; conversely, results obtained in the latter

<span id="page-6-0"></span>context can as well be similarly restated in the former one

In a nonlinear dielectric medium the polarization induced by an external electric field is described by expressing the scalar function  $\epsilon$  as a power series in terms of the field strength E:

$$\epsilon = \chi_1 + \chi_2 E + \chi_3 E^2 + \chi_4 E^3 + \dots$$
 (69)

where the constants  $\chi_n$  are known as the n-order nonlinear optical susceptibility. Note that we are using the standard convention [3] which relates  $\chi_n$  with the expansion of the polarization vector. For this case the effective geometry is given by

$$g^{\mu\nu} = \epsilon \,\eta^{\mu\nu} + \frac{\epsilon'}{E} F^{\mu}{}_{\alpha} F^{\alpha\nu}. \tag{70}$$

It can also be re-written in the form

$$g^{\mu\nu} = \epsilon \,\eta^{\mu\nu} - \frac{\epsilon'}{E} \left( E^{\mu} E^{\nu} - E^2 \,\delta_t^{\mu} \,\delta_t^{\nu} \right), \tag{71}$$

where  $E^2 \equiv -E_{\alpha} E^{\alpha} > 0$ . In other words,

$$g^{tt} = \epsilon + \epsilon' E \tag{72}$$

$$g^{ij} = -\epsilon \,\delta^{ij} - \frac{\epsilon'}{E} E^i E^j. \tag{73}$$

This shows that the discontinuities of the electromagnetic field inside a nonlinear dielectric medium propagates along null cones of an effective geometry which depends on the characteristics of the medium given by equation (70). It seems worth investigating under what conditions of the  $\epsilon$  dependence on E a kind of horizon barrier should appear for the photon inside a dielectric. We will return to this problem elsewhere.

## C. Photon path

From what we have learned above it follows that the equation of motion of the photon in a nonlinear regime is given by the variational principle

$$\delta \int ds = 0, \tag{74}$$

in which the fundamental length is constructed with the effective metric,  $ds^2 = g_{\mu\nu}\,dx^\mu\,dx^\nu$ . For the particular case which was examined in the previous section concerning the static and spherically symmetric configuration it becomes

$$\delta \int \left( g_{tt}\dot{t}^2 + g_{rr}\dot{r}^2 + g_{\theta\theta}\dot{\theta}^2 + g_{\varphi\varphi}\dot{\varphi}^2 \right) ds = 0, \quad (75)$$

in which a dot means derivative with respect to the fundamental length variable s. The equation for the angular variable  $\theta$  shows that we can choose conveniently the initial condition such that  $\theta$  remains constant. From an

analogy with the planetary motion we set  $\theta = \pi/2$ . The corresponding equations of the remaining variables are

$$r^2 \dot{\varphi} = h_o, \tag{76}$$

$$g_{tt} \,\dot{t} = E_o,\tag{77}$$

where  $h_o$  and  $E_o$  are constants of motion. It is rather convenient to obtain the equation for r by making use of the fact that we are dealing with a null curve, and set

$$g_{tt}\dot{t}^2 + g_{rr}\dot{r}^2 + g_{\varphi\varphi}\dot{\varphi}^2 = 0. \tag{78}$$

Thus, using the above equations for the evolution of  $t, \theta$  and  $\varphi$  we obtain:

$$\dot{r}^2 = E_o^2 - V(r), \tag{79}$$

in which the potential V(r) takes the form

$$V(r) = \frac{-E_o^2}{g_{tt}^2} + \frac{h_o^2}{g_{tt}r^2} + E_o^2.$$
 (80)

#### 1. Circular orbits

The above set of equations allows the possibility of the existence of circular orbits  $r = r_o = constant$  for the photon. In this case, it is sufficient for the value of the tt-component for the effective metric at the point  $r_o$  to take the value

$$g_{tt}(r_o) = \frac{1}{l^2} r_o^2,$$
 (81)

in which we have, for comparison with the planetary motion, defined the impact parameter  $l \doteq h_o/E_o$ . It is a rather simple and straightforward matter to show that such orbits are unstable, as one should suspect.

## IV. NON TRIVIAL VACUA

There have been some comments in the literature regarding a possible connection between the change of light velocity in modified vacua and the scale anomaly. The first one to speculate upon such a correlation was Shore [2], and Dittrich and Gies [1] disproved, using the sum over polarization states method, the existence of such correlation for the case of a general Lagrangian L(F,G).

Using the method of the effective geometry we are able to show that there is no deep correlation between the existence of the velocity shifts induced by the nonlinear quantum fluctuation and the scale anomaly. We will consider this problem in a general framework. In other words, let us analyze the photon velocity in an arbitrary case, without specifying a particular theory. From what we have learned above one could expect that the regime of nonlinearity induced by the modification of the electrodynamic vacuum to be the sufficient condition to modify the photon velocity. However, this is not true in general, as it can be seen below.

#### A. Conformal vacuum

An important example of modification of the action occurs for the case in which the quantity  $\mathcal{N}_{\pm}$  vanishes. In this case the net effect of this action on the photon velocity is indistinct from the one produced by the classical vacuum. Could this occur for the case in which  $T \neq 0$ ? This is answered by the following lemma.

**Lemma A** There exist nonlinear modifications of electrodynamics which present a non identically null anomaly such that the field discontinuities propagate along Minkowskian paths.

The proof is immediate. From equation (44), the general condition for such statement to hold is expressed by

$$L_{FF} + \Omega_{\pm} L_{FG} = 0. \tag{82}$$

Any nonlinear action which satisfies this condition is such that the photon propagation occurs in an effective geometry  $g^{\mu\nu}$ , which is conformal to the Minkowskian one. In this theory, the photon presents the same light-cone structure as it does in the linear Maxwell electrodynamics. The important point to consider here is that this situation occurs even in the presence of a non-vanishing scale anomaly.

Inserting  $\Omega_{\pm} = -L_{FF}/L_{FG}$  from (82) into equation (31) we obtain, after some algebra, the condition

$$\left(L_{FF}L_{GG} - L_{FG}^2\right) \left[L_F L_{FG} + G\left(L_{FF}L_{GG} - L_{FG}^2\right)\right] = 0.$$
(83)

It remains to show that the spectrum of common solutions of (82) and (83) does not imply T=0. This can be explicitly shown for the particular class of nonlinear Lagrangians given by

$$L = -\frac{1}{4}F + f(G), \tag{84}$$

for which  $L_{FF} = 0$  and  $L_{FG} = 0$ . The scale anomaly (43) for the class shown in (84) takes the form

$$T = 4\left(G\frac{\partial f}{\partial G} - f\right),\tag{85}$$

which vanishes only if f(G) is a linear function of G. Expression (35) yields  $\Omega_{+} = 0$  and  $\Omega_{-} = 1/(4G \partial^{2} f/\partial G^{2})$ , from which (45) gives  $\mathcal{M}_{\pm} = -1/4$  and  $\mathcal{M}_{\pm} = 0$ , respectively. The apparent singularity in (44) for  $\mathcal{M}_{\pm} = 0$  can be circumvented by carefully returning to the original expression (27), which reduces in this case to

$$f^{\mu\nu}k_{\nu} = \frac{2\chi}{G} F^{\mu\nu}k_{\nu}. \tag{86}$$

It follows that  $\eta^{\mu\nu}k_{\mu}k_{\nu}=0$ , thus adequately describing both solutions associated with (84).

#### B. Non-anomalous vacuum

There is no better way to demonstrate the independence of the concepts of light velocity modification and the anomaly than to consider the converse situation of Lemma A, for which there is no anomaly at all. This is provided by the following

**Lemma B** In the absence of scale anomaly the effective metric is not necessarily conformally flat.

Indeed, let us set

$$T = 0. (87)$$

From (43) it follows

$$L = F L_F + G L_G, (88)$$

which leads to

$$F L_{FF} + G L_{GF} = 0,$$
 (89)

and

$$GL_{GG} + FL_{FG} = 0.$$
 (90)

In order for the effective metric to be conformally flat the Lagrangian should obey, besides the above relations, the condition (82). Then, it is straightforward to show that Lagrangians satisfying all these requirements must satisfy the condition

$$L_{FF} = 0. (91)$$

Hence, when there is no anomaly, the unique case in which the effective geometry coincides with the Minkowski one is the linear Maxwell theory. This property allows us to conclude that in the framework of the effective action there is no need for a scale anomaly to induce light velocity shifts.

It remains to show that the spectrum of solutions of equation (87) does not necessarily reduce to the linear case. It is interesting to point out that not only one but a particular set of nonlinear Lagrangians can be obtained. Indeed, it is immediately shown that

$$L = G f(F/G) \tag{92}$$

satisfies equation (88) for arbitrary functions f(F/G).

#### C. Euler-Heisenberg vacuum

The effective action for electrodynamics due to one-loop quantum corrections was calculated by Heisenberg and Euler [15]. For the low-frequency limit  $\nu \ll m_e c^2/h$  the effective Lagrangian takes the form

$$L = -\frac{1}{4}F + \frac{\mu}{4}\left(F^2 + \frac{7}{4}G^2\right),\tag{93}$$

<span id="page-8-0"></span>with

$$\mu \doteq \frac{2}{45} \alpha^2 \left(\frac{\hbar}{m_e c}\right)^3 \frac{1}{m_e c^2},$$
 (94)

where  $\alpha$  is the fine-structure constant.

The trace of the corresponding modified energy-momentum tensor reads

$$T = \mu \left( F^2 + \frac{7}{4} G^2 \right). \tag{95}$$

The coefficients  $\mathcal{M}_{\pm}$  and  $\mathcal{N}_{\pm}$  of the associated metric tensor at the first order of approximation in  $\mu$  constant are:

$$\mathcal{M}_{-} = -\frac{1}{4} + \frac{\mu}{2}F\tag{96}$$

$$\mathcal{M}_{+} = -\frac{1}{7} + \frac{5\mu}{7}F\tag{97}$$

$$\mathcal{N}_{\pm} = -2\mu. \tag{98}$$

We note that only in the case where both invariants F and G vanish does the trace anomaly disappear. In this case the above coefficients become  $\mathcal{M}_{-}=-\frac{1}{4}$ ,  $\mathcal{M}_{+}=-\frac{1}{7}$  and  $\mathcal{N}_{\pm}=-2\mu$ .

The effective geometries yield

$$g_{-}^{\mu\nu} = \left(-\frac{1}{4} + \mu F\right) \eta^{\mu\nu} - 2 \mu T^{\mu\nu} \tag{99}$$

$$g_{+}^{\mu\nu} = \left(-\frac{1}{7} + \mu F\right) \eta^{\mu\nu} - 2 \mu T^{\mu\nu}. \tag{100}$$

This implies that there exist two paths of light, one for each polarization mode. In other words, birrefringence effects are present in Euler-Heisenberg electromagnetism, as it is well known in literature. From equation (47) we can write the associated expressions for the wave vector propagation:

$$k_{-}^{2} = -8 \,\mu \, T^{\mu\nu} k_{\mu} k_{\nu} \tag{101}$$

$$k_{\perp}^{2} = -14 \,\mu \, T^{\mu\nu} k_{\mu} k_{\nu}. \tag{102}$$

Taking the average over polarization modes we obtain the well known formula:

$$k^2 = -11 \,\mu \, T^{\mu\nu} k_\mu k_\nu. \tag{103}$$

### V. CONCLUSION

From what we have learned in this paper we can state that the propagation of discontinuities of electromagnetic field in a nonlinear regime (as it occurs, for instance, in dielectrics or in modified QED vacua) can be described in terms of an effective modification of the Minkowskian geometry of spacetime. Such interpretation is an immediate consequence of the analysis we presented here. We

would like to point out that it is not impossible to envisage the case in which the characteristic surfaces along which photons propagate, in nonlinear electrodynamics, could appear as space-like hypersurfaces in Minkowski spacetime. We will return to this question in a forthcoming paper.

This description also allows us to recognize a striking analogy between photon propagation in nonlinear electrodynamics and its behavior in an external gravitational field. For in both cases the geometry is modified by a nonlinear process. It is clear that such analogy can not be pushed very far, since in the gravitational case the modified geometry is observed by any kind of matter and energy (including gravitational energy — at least in the general relativity theory<sup>7</sup>) and in the electromagnetic case this modified geometry is observed only by the nonlinear photons. Moreover, we would like to stress that we proved the existence of Minkowski geodesics at nonvanishing scale anomaly and vice versa.

This analogy certainly deserves further examination, since it may provide for the existence of an electromagnetic analogue of the gravitational black hole, as was shown.

#### ACKNOWLEDGMENTS

We would like to thank the referees of the manuscript for their useful suggestions, which led us to improve this work. V. A. De Lorenci and R. Klippert are grateful to Dr. N. F. Svaiter for valuable discussions on non trivial QED vacua. This work was partially supported by Conselho Nacional de Desenvolvimento Científico e Tecnológico (CNPq) and Fundação de Amparo à Pesquisa do Estado do Rio de Janeiro (FAPERJ) of Brazil.

# APPENDIX A: THE EFFECTIVE NULL GEODESICS

The geometrical relevance of the effective geometry (14) goes beyond its immediate definition. Indeed, as follows it will be shown that the integral curves of the vector  $k_{\nu}$  (i.e., the photons trajectories) are in fact geodesics. In order to achieve this result it will be required an underlying Riemannian structure for the manifold associated with the effective geometry. In other words this implies a set of Levi-Civita connection coefficients  $\Gamma^{\alpha}{}_{\mu\nu} = \Gamma^{\alpha}{}_{\nu\mu}$ , by means of which there exists a covariant differential operator  $\nabla_{\lambda}$  (the covariant derivative) such that

<sup>&</sup>lt;sup>7</sup>For the recent proposal of NDL theory of gravity [16] this would not be the case.

<span id="page-9-0"></span>
$$\nabla_{\lambda}g^{\mu\nu} \equiv g^{\mu\nu}_{;\lambda} \equiv g^{\mu\nu}_{,\lambda} + \Gamma^{\mu}_{\sigma\lambda}g^{\sigma\nu} + \Gamma^{\nu}_{\sigma\lambda}g^{\sigma\mu} = 0.$$
(A1)

From (A1) it follows that the effective connection coefficients are completely determined from the effective geometry by the usual Christoffel formula.

Contracting (A1) with  $k_{\mu}k_{\nu}$  results

$$k_{\mu}k_{\nu}g^{\mu\nu}_{\lambda\lambda} = -2k_{\mu}k_{\nu}\Gamma^{\mu}_{\sigma\lambda}g^{\sigma\nu}.$$
 (A2)

Differentiating (36) we have

$$2k_{\mu,\lambda}k_{\nu}g^{\mu\nu} + k_{\mu}k_{\nu}g^{\mu\nu}_{,\lambda} = 0. \tag{A3}$$

Inserting (A2) for the last term on the left hand side of (A3) we obtain

$$g^{\mu\nu}k_{\mu;\lambda}k_{\nu} \equiv g^{\mu\nu} \left(k_{\mu,\lambda} - \Gamma^{\sigma}{}_{\mu\lambda}k_{\sigma}\right)k_{\nu} = 0. \tag{A4}$$

As the propagation vector  $k_{\mu} = \Sigma_{,\mu}$  is an exact gradient one can write  $k_{\mu;\lambda} = k_{\lambda;\mu}$ . With this identity and defining  $k^{\mu} \doteq g^{\mu\nu}k_{\nu}$  equation (A4) reads

$$k_{\mu:\lambda}k^{\lambda} = 0, \tag{A5}$$

which states that  $k_{\mu}$  is a geodesic vector. By remembering it is also a null vector (with respect to the effective geometry  $g^{\mu\nu}$ ), it follows that its integral curves are therefore null geodesics.

# APPENDIX B: GENERALIZATION OF THE RAINICH-WHEELER ALREADY UNIFIED PROGRAM

We show a remarkable property of the class of nonlinear theories which are free of anomaly. From the definition of  $T_{\mu\nu}$  in the case of two parameter Lagrangians we have

$$T_{\mu\nu} = -4L_F F_{\mu}^{\ \alpha} F_{\alpha\nu} - (L - G L_G) \eta_{\mu\nu}. \tag{B1}$$

In the linear case it follows that the square  $T_{\mu\alpha}T^{\alpha\nu}$  of this tensor is proportional to the identity matrix  $\delta^{\nu}_{\mu}$ . This square property was used by Rainich and Wheeler<sup>8</sup> to set a basis of an extension of the geometrization program beyond gravitational interaction, the so-called already unified program. It is important to remark that this property no longer holds for a general nonlinear Lagrangian. Indeed, a straightforward calculation gives

$$T_{\mu\alpha} T^{\alpha\nu} = m \, \delta^{\nu}_{\mu} + \frac{1}{2} \, T \, T^{\nu}_{\mu},$$
 (B2)

in which m is given by

$$m = L_F^2 (F^2 + G^2) - \frac{T^2}{16},$$
 (B3)

and the trace  $T \doteq T^{\alpha}_{\alpha}$  takes the value

$$T = 4 (F L_F + G L_G - L).$$
 (B4)

From expression (B2) it follows the interesting result that the *square* property remains valid for the class of theories which do not present scale anomaly.

We can thus state the Rainich-Wheeler conditions

$$R_{\mu\nu} R^{\nu\alpha} = \frac{1}{4} R_{\lambda\eta} R^{\lambda\eta} \delta^{\alpha}_{\mu}, \tag{B5a}$$

$$R = 0, (B5b)$$

where  $R \doteq R^{\alpha}_{\alpha}$  is the curvature Ricci scalar, and the assumption that

$$\left(R_{\mu\alpha;\beta} \eta^{\alpha\beta\rho\nu} R_{\rho}^{\mu}\right) \left(R_{\epsilon\lambda} R^{\epsilon\lambda}\right)^{-1} \tag{B5c}$$

is a gradient. It is straightforward to show that property (B5c) holds also for the nonlinear case.  $R_{\mu\nu}$  is the curvature Ricci tensor, which satisfies Einstein equations

$$R_{\mu\nu} - \frac{1}{2} R g_{\mu\nu} = -\kappa T_{\mu\nu},$$
 (B6)

where  $\kappa$  is Einstein's gravitational constant. Relations (B5) hold for a general nonlinear electromagnetic theory which does not present scale anomaly. If, in addition, the theory is such that  $L_F < 0$  (that is, if the energy density is positive definite), then

$$R_{tt} > 0. (B7)$$

Thus we conclude that Rainich-Wheeler conditions for the already unified program characterize both linear and nonlinear electromagnetic fields as the source of the given gravitational field.

- [1] W. Dittrich and H. Gies, Phys. Rev. **D** 58, 025004 (1998).
- [2] G. M. Shore, Nucl. Phys. B 460, 379 (1996).
- [3] J. Plebansky, in *Lectures on Nonlinear Electrodynamics*, (Ed. Nordita, Copenhagen, 1968).
- [4] I. T. Drummond and S. J. Hathrell, Phys. Rev. D 22, 343 (1980).
- [5] M. Novello and S. Jordan, Mod. Phys. Lett. 4 A, 1809 (1989).
- [6] J. L. Latorre, P. Pascual and R. Tarrach, Nucl. Phys. B 437, 60 (1995).
- [7] S. L. Adler, Ann. Phys. 67, 599 (1971).
- [8] K. Scharnhorst, Phys. Lett. B 236, 354 (1990).
- [9] G. Barton, Phys. Lett. **B 237**, 559 (1990).
- [10] J. A. Wheeler, *Geometrodynamics* (Academic Press, New York, 1962).

<sup>&</sup>lt;sup>8</sup>See for instance [17,10].

- <span id="page-10-0"></span>[11] Y. Choquet-Bruhat, C. De Witt-Morette, M. Dillard-Bleick, in Analysis, Manifolds and Physics, p. 455 (North-Holland Publishing, New York, 1977); see also J. Hadamard, in Le¸cons sur la propagation des ondes et les ´equations de l'hydrodynamique, (Ed. Hermann, Paris, 1903).
- [12] A. Lichnerowicz, Geometrie des groupes de transformations (Dunod, Paris, 1958).
- [13] G. Boillat, J. Math. Phys. 11, 941 (1970).
- [14] Z. Bialinicka-Birula and I. Bialinicki-Birula, Phys. Rev. D 2, 2341 (1970).
- [15] W. Heisenberg and H. Euler, Z. Phys. 98, 714 (1936); J. Schwinger, Phys. Rev. 82, 664 (1951).
- [16] M. Novello, V. A. De Lorenci and L. R. Freitas, Ann. Phys. 254, 83 (1997); M. Novello, V. A. De Lorenci, L. R. de Freitas and O. D. Aguiar, Phys. Letters A 254, 245-250 (1999).
- [17] J. A. Wheeler, Phys. Rev. 95, 511,(1955).