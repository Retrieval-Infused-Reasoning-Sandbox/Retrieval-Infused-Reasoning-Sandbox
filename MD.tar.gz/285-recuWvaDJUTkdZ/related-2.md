## Nonlinear electrodynamics with the maximum allowable symmetries

## B. P. Kosyakov

Russian Federal Nuclear Center–VNIIEF, Sarov, 607188 Nizhni˘ı Novgorod Region, Russia; Moscow Institute of Physics & Technology, Dolgoprudni˘ı, 141700 Moscow Region, Russia E-mail: kosyakov.boris@gmail.com

## Abstract

Recently Bandos, Lechner, Sorokin, and Townsend have discovered that Maxwell's electrodynamics can be generalized so that the resulting nonlinear theory preserves both conformal invariance and SO(2) duality-rotation invariance. Their result can be derived in a simpler way.

It has long been known that Maxwell's equations are invariant under both conformal transformations [\[1\]](#page-3-0), [\[2\]](#page-3-1) and Hodge duality rotations [\[3\]](#page-3-2). Is it possible to preserve these symmetries in nonlinear modifications of Maxwell's theory with Lagrangians of the form L = L(S,P)? Here, the arguments of L are the electromagnetic field invariants

<span id="page-0-3"></span>
$$S = \frac{1}{2} F_{\mu\nu} F^{\mu\nu} , \quad \mathcal{P} = \frac{1}{2} F_{\mu\nu} {}^*\!F^{\mu\nu} , \qquad (1)$$

the field strength Fµν is expressed in terms of vector potentials,

<span id="page-0-1"></span>
$$F_{\mu\nu} = \partial_{\mu}A_{\nu} - \partial_{\nu}A_{\mu} \,, \tag{2}$$

and the Hodge dual of Fµν is defined by

$$^*F^{\mu\nu} = \frac{1}{2} \,\epsilon^{\mu\nu\rho\sigma} F_{\rho\sigma} \,. \tag{3}$$

Recently Bandos, Lechner, Sorokin, and Townsend have demonstrated [\[4\]](#page-3-3) that such is the case. This is a profound result. Indeed, the analysis of this issue, apart from its cognitive significance, may show the utility in the low-energy effective theory to strings.

However, the line of reasoning in Ref. [\[4\]](#page-3-3) may seem somewhat meandering. Let us obtain the same result in a direct and simpler way.

We begin with the Bessel-Hagen criterion for conformal invariance [\[5\]](#page-3-4)

<span id="page-0-0"></span>
$$\Theta^{\mu}_{\ \mu} = 0, \qquad (4)$$

where Θµν is the symmetric stress-energy tensor of electromagnetic field. Equation [\(4\)](#page-0-0) can be cast [\[6\]](#page-3-5) as follows:

<span id="page-0-2"></span>
$$\mathcal{L}_{\mathcal{S}}\,\mathcal{S} + \mathcal{L}_{\mathcal{P}}\,\mathcal{P} = \mathcal{L}\,,\tag{5}$$

where L<sup>S</sup> = ∂L/∂S and L<sup>P</sup> = ∂L/∂P. We then notice that the Euler–Lagrange equations

$$\partial_{\mu}E^{\mu\nu} = 0, \qquad (6)$$

in which the excitation  $E_{\mu\nu}$  is defined by

<span id="page-1-0"></span>
$$E_{\mu\nu} = \frac{\partial \mathcal{L}}{\partial F^{\mu\nu}} = 2 \left( \mathcal{L}_{\mathcal{S}} F_{\mu\nu} + \mathcal{L}_{\mathcal{P}} * F_{\mu\nu} \right), \tag{7}$$

and the Bianchi identity

$$\partial_{\mu} F^{\mu\nu} = 0 \,, \tag{8}$$

which is a mere restatement of Eq. (2), are invariant under the general electric-magnetic duality rotation

<span id="page-1-1"></span>
$$E'_{\mu\nu} = E_{\mu\nu}\cos\theta + {}^*F_{\mu\nu}\sin\theta, \quad {}^*F'_{\mu\nu} = {}^*F_{\mu\nu}\cos\theta - E_{\mu\nu}\sin\theta.$$
 (9)

However, the constitutive equations

$$E^{\mu\nu} = E^{\mu\nu}(F, {}^*F) \,, \tag{10}$$

stemming from (7), are in general devoid of this invariance. The Gaillard–Zumino criterion [7] for invariance under the duality transformations (9) reads

<span id="page-1-2"></span>
$$^*E_{\mu\nu} E^{\mu\nu} = ^*F_{\mu\nu} F^{\mu\nu} . \tag{11}$$

We use Eq. (7) and the fact that  ${}^*F_{\mu\nu}\,{}^*F^{\mu\nu}=-F_{\mu\nu}\,F^{\mu\nu}$  to bring Eq. (11) to the form

<span id="page-1-3"></span>
$$4\left(\mathcal{L}_{\mathcal{S}}^{2}-\mathcal{L}_{\mathcal{P}}^{2}\right)\mathcal{P}-8\mathcal{L}_{\mathcal{S}}\mathcal{L}_{\mathcal{P}}\mathcal{S}=\mathcal{P}.$$
(12)

We multiply both parts of Eq. (12) by  $\mathcal{P}$  and combine the result with Eq. (5). After a simple algebra we obtain

$$4\left(S^2 + \mathcal{P}^2\right)\mathcal{L}_S^2 - 4\mathcal{L}^2 = \mathcal{P}^2, \tag{13}$$

or, equivalently,

<span id="page-1-4"></span>
$$4\left(\sqrt{S^2 + \mathcal{P}^2} \,\mathcal{L}_{\mathcal{S}} - \mathcal{L}\right) \left(\sqrt{S^2 + \mathcal{P}^2} \,\mathcal{L}_{\mathcal{S}} + \mathcal{L}\right) = \mathcal{P}^2. \tag{14}$$

To solve this nonlinear partial differential equation with  $\mathcal{L}$  as the unknown function, it is convenient to use

$$u = \sqrt{S^2 + P^2}, \quad v = S,$$
 (15)

rather than  $\mathcal{S}$  and  $\mathcal{P}$ . These u and v are independent variables everywhere except for the point  $\mathcal{P} = 0$  which is the only singular point of the Gaillard–Zumino condition (11). Therefore, we may safely express Eq. (14) in terms of u and v. The differentiation with respect to  $\mathcal{S}$  is

$$\frac{\partial}{\partial S} = \frac{v}{u} \frac{\partial}{\partial u} + \frac{\partial}{\partial v} \,. \tag{16}$$

Since Eq. (5) is nothing but Euler's homogeneous function theorem for homogeneous functions  $\mathcal{L}$  of degree 1, it makes sense to look for solutions of Eq. (14) in the form

<span id="page-1-5"></span>
$$\mathcal{L} = \alpha \, u + \beta \, v \,, \tag{17}$$

where  $\alpha$  and  $\beta$  are unknown constants. We substitute the ansatz (17) into Eq. (14), expressed in terms of u and v, to find

$$4(v^{2} - u^{2})(\alpha^{2} - \beta^{2}) = (u^{2} - v^{2}).$$
(18)

It follows that

$$\alpha = \pm \frac{1}{2} \sinh \gamma, \quad \beta = \pm \frac{1}{2} \cosh \gamma.$$
 (19)

The solution with  $\alpha = -\frac{1}{2}\sinh\gamma$ ,  $\beta = \frac{1}{2}\cosh\gamma$ ,  $\gamma > 0$  represents the Lagrangian which is unbounded from below, and should be discarded. Hence the desired set of Lagrangians, invariant under conformal group transformations and duality rotations (9), is given by the one-parameter family of functions

<span id="page-2-0"></span>
$$\mathcal{L}(\mathcal{S}, \mathcal{P}; \gamma) = -\frac{1}{2} \left( \mathcal{S} \cosh \gamma - \sqrt{\mathcal{S}^2 + \mathcal{P}^2} \sinh \gamma \right), \tag{20}$$

where the parameter  $\gamma$  runs from 0 to  $\infty$ , with  $\gamma = 0$  being attributed to the free Maxwell electrodynamics governed by the Larmor Lagrangian  $\mathcal{L}_{L} = -\frac{1}{2}\mathcal{S}$ .

By analogy with Eq. (1), we define

$$\Sigma = \frac{1}{2} E_{\mu\nu} E^{\mu\nu} , \quad \Pi = \frac{1}{2} E_{\mu\nu} E^{\mu\nu} . \tag{21}$$

The Gaillard–Zumino criterion (11) requires that  $\Pi = \mathcal{P}$ . As to the expression for  $\Sigma$  afforded by the Lagrangian (20), it is a straightforward matter to establish

$$-\frac{1}{2}\Sigma = -\frac{1}{2}\left[\left(\cosh\gamma - \frac{S}{\sqrt{S^2 + P^2}}\sinh\gamma\right)F - \frac{P}{\sqrt{S^2 + P^2}}\sinh\gamma^*F\right]^2$$
$$= -\frac{1}{2}\left(S\cosh 2\gamma - \sqrt{S^2 + P^2}\sinh 2\gamma\right) = \mathcal{L}(S, \mathcal{P}; 2\gamma), \tag{22}$$

and the inverse

$$-\frac{1}{2}\mathcal{S} = -\frac{1}{2}\left(\Sigma \cosh 2\gamma - \sqrt{\Sigma^2 + \Pi^2} \sinh 2\gamma\right) = \mathcal{L}(\Sigma, \Pi; 2\gamma). \tag{23}$$

It is thus seen that the Lagrangian formalism is best suited for a direct and simple derivation of Eq. (20). On the other hand, the Hamiltonian formalism employed in Ref. [4] may be a convenient framework for analyzing other important problems. To illustrate, we refer to the fact that the authors of Ref. [4] were fortunate to discover a one-parameter extension of the Born–Infeld theory from which Eq. (20) follows immediately in a certain limit. The Hamiltonian approach makes it clear that the nonlinear extension of the free Maxwell electrodynamics unvariant under conformal group transformations and duality rotations, embodied in Eq. (20), is unique. This approach is attractive for the treatment of exact solutions, specifically solutions of the plane wave type. Finally, the Hamiltonian approach is an appropriate starting point for exploring quantum properties of the system governed by the Lagrangian (20). It is therefore reasonable to invoke the Hamiltonian and Lagrangian approaches interchangeably.

I thank Paul Townsend for useful discussions.

## <span id="page-3-0"></span>References

- [1] H. Bateman. The conformal transformations of a space of four dimensions and their applications to geometrical optics. *Proc. London Math. Soc.* **7**, 70-89 (1909); The transformation of the electrodynamical equations. *Ibid.* **8**, 223-264 (1910).
- <span id="page-3-1"></span>[2] E. Cunningham. The principle of relativity in electrodynamics and an extension thereof. *Proc. London Math. Soc.* 8, 77-98 (1910).
- <span id="page-3-2"></span>[3] G. Y. Rainich. Electrodynamics in general relativity. *Trans. Amer. Math. Soc.* 27, 106-136 (1925).
- <span id="page-3-3"></span>[4] I. Bandos, K. Lechner, D. Sorokin, and P. Townsend. A non-linear duality-invariant conformal extension of Maxwell's equations. ArXiv: hep-th/2007.09092.
- <span id="page-3-4"></span>[5] E. Bessel-Hagen. Über die Erhaltungssätze der Elektrodynamik. Math. Ann. 84, 258-276 (1921).
- <span id="page-3-5"></span>[6] B. Kosyakov. Introduction to the Classical Theory of Particles and Fields (Springer, Heidelberg, 2007), Sec. 10.4.
- <span id="page-3-6"></span>[7] M. K. Gaillard and B. Zumino. Duality rotations for interacting fields. *Nucl. Phys.* B **193**, 221-244 (1981).