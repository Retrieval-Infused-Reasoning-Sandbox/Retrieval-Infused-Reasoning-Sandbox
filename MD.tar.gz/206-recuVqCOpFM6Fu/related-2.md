Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- <span id="page-0-0"></span>1. Home >
- 2. Archive for Rational Mechanics and Analysis
- 3. Article

# **BV Estimates in Optimal Transportation and Applications**

- Published: 07 September 2015
- Volume 219, pages 829-860, (2016)
- · Cite this article

![](_page_0_Picture_14.jpeg)

Archive for Rational Mechanics and Analysis Aims and scope Submit

manuscript

- Guido De Philippis<sup>1</sup>,
- <u>Alpár Richárd Mészáros<sup>2</sup></u>,
- Filippo Santambrogio 2 &
- •
- Bozhidar Velichkov<sup>3</sup>

### Show authors

- 481 Accesses •
- 35 Citations •
- 1 Altmetric •
- [Explore all metrics](file:///article/10.1007/s00205-015-0909-3/metrics)  •

# **Abstract**

In this paper we study the *BV* regularity for solutions of certain variational problems in Optimal Transportation. We prove that the Wasserstein projection of a measure with *BV* density on the set of measures with density bounded by a given *BV* function *f* is of bounded variation as well and we also provide a precise estimate of its *BV* norm. Of particular interest is the case *f* = 1, corresponding to a projection onto a set of densities with an *L* <sup>∞</sup> bound, where we prove that the total variation decreases by projection. This estimate and, in particular, its iterations have a natural application to some evolutionary PDEs as, for example, the ones describing a crowd motion. In fact, as an application of our results, we obtain *BV* estimates for solutions of some non-linear parabolic PDE by means of optimal transportation techniques. We also establish some properties of the Wasserstein projection which are interesting in their own right, and allow, for instance, for the proof of the uniqueness of such a projection in a very general framework.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs00205-015-0909-3) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs00205-015-0909-3)

### **Subscribe and save**

Springer+ from €37.37 /Month

Starting from 10 chapters or articles per month

- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

# **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s00205-015-0909-3                                                                                                        |
| 1432-0673                                                                                                                        |
| BV Estimates in Optimal Transportation and Applications                                                                          |
| 2015                                                                                                                             |
| 2015                                                                                                                             |
| Guido De Philippis, et al.                                                                                                       |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 63e04eff3b78c6141d39575aacfae95b36d29d13075bf6a1e3d5d817b09ae3a6566f2956fdfa5d4f8add6865aefaa2ffda106fde95238976f1b01c420be670f0 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

# **Similar content being viewed by others**

![](_page_2_Picture_9.jpeg)

# **[\\(L^p\\) bounds for boundary-to-boundary transport densities, and \](https://link.springer.com/10.1007/s00526-018-1474-z?fromPaywallRec=true) [\(W^{1,p}\\) bounds for the BV least gradient problem in 2D](https://link.springer.com/10.1007/s00526-018-1474-z?fromPaywallRec=true)**

Article 04 January 2019

![](_page_3_Figure_2.jpeg)

# **[Absolutely continuous and BV-curves in 1-Wasserstein spaces](https://link.springer.com/10.1007/s00526-023-02616-1?fromPaywallRec=true)**

Article Open access 05 December 2023

![](_page_3_Picture_5.jpeg)

### **[On Properties of the Generalized Wasserstein Distance](https://link.springer.com/10.1007/s00205-016-1026-7?fromPaywallRec=true)**

Article 08 July 2016

# **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Partial Differential Equations](file:///subjects/partial-differential-equations) •
- [Stochastic Partial Differential Equations](file:///subjects/stochastic-partial-differential-equations) •
- [Diffusion Processes and Stochastic Analysis on Manifolds](file:///subjects/diffusion-processes-and-stochastic-analysis-on-manifolds) •
- [Functional Analysis](file:///subjects/functional-analysis) •
- [Partial Differential Equations on Manifolds](file:///subjects/partial-differential-equations-on-manifolds) •
- [Calculus of Variations and Optimization](file:///subjects/calculus-of-variations-and-optimization) •

# **References**

Ambrosio L.: Movimenti minimizzanti. Rend. Accad. Naz. Sci. XL Mem. Mat. Sci. Fis. Nat. **113**, 191–246 (1995) 1.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1387558) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Movimenti%20minimizzanti&journal=Rend.%20Accad.%20Naz.%20Sci.%20XL%20Mem.%20Mat.%20Sci.%20Fis.%20Nat.&volume=113&pages=191-246&publication_year=1995&author=Ambrosio%2CL.)

- Ambrosio, L., Gigli, N., Savaré, G.: Gradient flows in metric spaces and in the space of probability measures, Lectures in Math., ETH Zürich, (2005) 2.
- Bouchitté G., Buttazzo G.: New lower semicontinuity results for nonconvex functionals defined on measures. Nonlinear Anal. **15**(7), 679–692 (1990) 3.

### [Article](https://doi.org/10.1016%2F0362-546X%2890%2990007-4) [MATH](http://www.emis.de/MATH-item?0736.49007) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1073958) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=New%20lower%20semicontinuity%20results%20for%20nonconvex%20functionals%20defined%20on%20measures.&journal=Nonlinear%20Anal.&doi=10.1016%2F0362-546X%2890%2990007-4&volume=15&issue=7&pages=679-692&publication_year=1990&author=Bouchitt%C3%A9%2CG.&author=Buttazzo%2CG.)

- Buttazzo, G.: Semicontinuity, Relaxation, and Integral Representation in the Calculus of Variations. Longman Scientific & Technical, Essex, 1989 4.
- Buttazzo, G., Santambrogio, F.: A model for the optimal planning of an urban area. SIAM J. Math. Anal. 37(2), 514–530 (2005) 5.
- Carlen, E., Craig, K.: Contraction of the proximal map and generalized convexity of the Moreau–Yosida regularization in the 2-Wasserstein metric. Math. Mech. Complex Syst. 1(1), 33–65 (2013) 6.
- Carlier, G., Santambrogio, F.: A variational model for urban planning with traffic congestion. ESAIM Control Optim. Calc. Var. 11(4), 595–613 (2005) 7.
- Caffarelli L. A.: The regularity of mappings with a convex potential. J. Am. Math. Soc. **5**(1), 99–104 (1992) 8.

### [Article](https://doi.org/10.1090%2FS0894-0347-1992-1124980-8) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1124980) [MATH](http://www.emis.de/MATH-item?0753.35031) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20regularity%20of%20mappings%20with%20a%20convex%20potential&journal=J.%20Am.%20Math.%20Soc.&doi=10.1090%2FS0894-0347-1992-1124980-8&volume=5&issue=1&pages=99-104&publication_year=1992&author=Caffarelli%20L.%2CA.)

- Caffarelli L. A. (1992) Boundary regularity of maps with convex potentials. Commun. Pure Appl. Math. 45(9): 1141–1151 9.
- Cannarsa, P., Sinestrari, C.: *Semiconcave Functions, Hamilton–Jacobi Equations, and Optimal Control*. Birkhäuser, Basel, 2004 10.

- Dal Maso, G.: An Introduction to Γ-Convergence. Birkhäuser, Basel, 1992 11.
- Figalli, A.: A note on the regularity of the free boundaries in the optimal partial transport problem. Rend. Circ. Mat. Palermo 58, 283–286 (2009) 12.
- Figalli, A.: The optimal partial transport problem. Arch. Rat. Mech. Anal. 195, 533– 560 (2010) 13.
- Gigli, N.: On the inverse implication of Brenier–McCann theorems and the structure of \({(\mathcal{P}\_{2}(M),W\_2)}\). Meth. Appl. Anal. 18(2), 127–158 (2011) 14.
- Lellmann, J., Lorenz, D.A., Schönlieb, C., Valkonen, T.: Imaging with Kantorovich– Rubinstein discrepancy. SIAM J. Imaging Sci. 7(4), 2833–2859 (2014) 15.
- Maury, B., Roudneff-Chupin, A., Santambrogio, F.: A macroscopic crowd motion model of gradient flow type. Math. Models Methods Appl. Sci. 20(10), 1787–1821 (2010) 16.
- Maury, B., Roudneff-Chupin, A., Santambrogio F.: Congestion-driven dendritic growth. Discr. Cont. Dyn. Syst. 34(4), 1575–1604 (2014) 17.
- McCann, R. J.: A convexity principle for interacting gases. Adv. Math. 128(1), 153– 159 (1997) 18.
- Milakis, E.: On the regularity of optimal sets in mass transfer problems. Commun. Partial Diff. Equ. 31(4–6), 817–826 (2006) 19.
- Mészáros, A.R., Santambrogio, F.: A diffusive model for macroscopic crowd motion with density constraints (preprint).<http://cvgmt.sns.it/paper/2644/> 20.
- Otto, F.: The geometry of dissipative evolution equations: the porous medium equation. Commun. PDE 26(1-2) 101–174 (2001) 21.
- Roudneff-Chupin, A.: Modélisation macroscopique de mouvements de foule, PhD Thesis, Université Paris-Sud. [http://www.math.u-psud.fr/~roudneff/Images/](http://www.math.u-psud.fr/~roudneff/Images/these_roudneff) [these\\_roudneff](http://www.math.u-psud.fr/~roudneff/Images/these_roudneff) (2011) 22.
- Santambrogio F.: Transport and concentration problems with interaction effects. J. Glob. Optim. **38**(1), 129–141 (2007) 23.

### [Article](https://link.springer.com/doi/10.1007/s10898-006-9087-z) [MATH](http://www.emis.de/MATH-item?1124.49034) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2316405) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Transport%20and%20concentration%20problems%20with%20interaction%20effects&journal=J.%20Glob.%20Optim.&doi=10.1007%2Fs10898-006-9087-z&volume=38&issue=1&pages=129-141&publication_year=2007&author=Santambrogio%2CF.)

- Santambrogio, F.: Optimal Transport for Applied Mathematicians. Birkäuser, New York, 2015 24.
- Villani, Cédric: Optimal Transport Old and New. Grundlehren der Mathematischen Wissenschaften [Fundamental Principles of Mathematical Sciences], 338. Springer, Berlin, 2009 25.
- Vázquez, J. L.: The Porous Medium Equation. Mathematical Theory. The Clarendon Press, Oxford University Press, Oxford, 2007 26.

### [Download references](https://citation-needed.springer.com/v2/references/10.1007/s00205-015-0909-3?format=refman&flavour=references)

# **Author information**

# **Authors and Affiliations**

<span id="page-6-1"></span>UMPA, CNRS and École Normale Supérieure de Lyon, 46, Allée d'Italie, 69364, Lyon Cedex 07, France 1.

Guido De Philippis

<span id="page-6-2"></span>Laboratoire de Mathématiques d'Orsay, Université Paris-Sud, 91405, Orsay Cedex, France 2.

Alpár Richárd Mészáros & Filippo Santambrogio

<span id="page-6-3"></span>Laboratoire LJK, Université J. Fourier, 51, rue des Mathématiques, 38041, Grenoble Cedex 9, France 3.

Bozhidar Velichkov

### Authors

<span id="page-6-0"></span>Guido De Philippis 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Guido%20De%20Philippis)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Guido%20De%20Philippis) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Guido%20De%20Philippis%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

#### <span id="page-7-0"></span>Alpár Richárd Mészáros 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Alp%C3%A1r%20Rich%C3%A1rd%20M%C3%A9sz%C3%A1ros)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Alp%C3%A1r%20Rich%C3%A1rd%20M%C3%A9sz%C3%A1ros) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Alp%C3%A1r%20Rich%C3%A1rd%20M%C3%A9sz%C3%A1ros%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-7-1"></span>Filippo Santambrogio 3.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Filippo%20Santambrogio)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Filippo%20Santambrogio) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Filippo%20Santambrogio%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-7-2"></span>Bozhidar Velichkov 4.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Bozhidar%20Velichkov)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Bozhidar%20Velichkov) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Bozhidar%20Velichkov%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

# **Corresponding author**

Correspondence to [Filippo Santambrogio](mailto:filippo.santambrogio@math.u-psud.fr).

# **Additional information**

Communicated by G. Dal Maso

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=BV%20Estimates%20in%20Optimal%20Transportation%20and%20Applications&author=Guido%20De%20Philippis%20et%20al&contentID=10.1007%2Fs00205-015-0909-3©right=Springer-Verlag%20Berlin%20Heidelberg&publication=0003-9527&publicationDate=2015-09-07&publisherName=SpringerNature&orderBeanReset=true)

# **About this article**

![](_page_7_Picture_16.jpeg)

# <span id="page-8-0"></span>**Cite this article**

De Philippis, G., Mészáros, A.R., Santambrogio, F. *et al.* BV Estimates in Optimal Transportation and Applications. *Arch Rational Mech Anal* **219**, 829–860 (2016). https:// doi.org/10.1007/s00205-015-0909-3

### [Download citation](https://citation-needed.springer.com/v2/references/10.1007/s00205-015-0909-3?format=refman&flavour=citation)

Received: 31 October 2014 •

Accepted: 02 July 2015 •

Published: 07 September 2015 •

Issue date: February 2016 •

DOI: https://doi.org/10.1007/s00205-015-0909-3 •

# **Keywords**

- [Weak Convergence](file:///search?query=Weak%20Convergence&facet-discipline=%22Physics%22) •
- [Lower Semicontinuity](file:///search?query=Lower%20Semicontinuity&facet-discipline=%22Physics%22) •
- [Optimal Transport](file:///search?query=Optimal%20Transport&facet-discipline=%22Physics%22) •
- [Porous Medium Equation](file:///search?query=Porous%20Medium%20Equation&facet-discipline=%22Physics%22) •
- [Density Constraint](file:///search?query=Density%20Constraint&facet-discipline=%22Physics%22) •

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs00205-015-0909-3)

# **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals

![](_page_9_Picture_0.jpeg)

## **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s00205-015-0909-3                                                                                                        |
| 1432-0673                                                                                                                        |
| BV Estimates in Optimal Transportation and Applications                                                                          |
| 2015                                                                                                                             |
| 2015                                                                                                                             |
| Guido De Philippis, et al.                                                                                                       |
| Archive for Rational Mechanics and Analysis                                                                                      |
| 63e04eff3b78c6141d39575aacfae95b36d29d13075bf6a1e3d5d817b09ae3a6566f2956fdfa5d4f8add6865aefaa2ffda106fde95238976f1b01c420be670f0 |
| Buy article PDF 39,95 €                                                                                                          |
|                                                                                                                                  |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

Advertisement

# <span id="page-9-0"></span>**Search**

| Search by keyword or author |  |  |  |
|-----------------------------|--|--|--|
|                             |  |  |  |
|                             |  |  |  |

Search

# <span id="page-10-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

# **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

# **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

# **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •

- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature