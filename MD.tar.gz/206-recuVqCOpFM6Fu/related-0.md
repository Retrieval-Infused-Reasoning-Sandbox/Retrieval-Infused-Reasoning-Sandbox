Skip to main content

Springer Nature Link

Log in

Menu

Find a journal Publish with us Track your research

Search

☐ Cart

- <span id="page-0-0"></span>1. Home >
- 2. Science China Mathematics >
- 3. Article

# $C^{\alpha}$ regularity of weak solutions of non-homogeneous ultraparabolic equations with drift terms

- Articles
- Published: 23 August 2023
- Volume 67, pages 23-44, (2024)
- · Cite this article

![](_page_0_Picture_15.jpeg)

Science China Mathematics Aims and scope Submit manuscript

- Wendong Wang 1 &
- Liqun Zhang<sup>2</sup>
- 179 Accesses
- 5 Citations

[Explore all metrics](file:///article/10.1007/s11425-021-2098-0/metrics)  •

# **Abstract**

We consider a class of non-homogeneous ultraparabolic differential equations with singular drift terms arising from some physical models, and prove that weak solutions are Hölder continuous, which are sharp in some sense and also generalize the well-known De Giorgi-Nash-Moser theory to degenerate parabolic equations satisfying the Hörmander hypoellipticity condition. The new ingredients are manifested in two aspects: on the one hand, for lower-order terms, we exploit a new Sobolev inequality suitable for the Moser iteration by improving the result of Pascucci and Polidoro (2004); on the other hand, we explore the G-function from an early idea of Kruzhkov (1964) and an approximate weak Poincaré inequality for non-negative weak sub-solutions to prove the Hölder regularity.

This is a preview of subscription content, [log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11425-021-2098-0) to check access.

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11425-021-2098-0)

### **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

# **Buy Now**

article

10.1007/s11425-021-2098-0

| 1869-1862                                                                                                                        |
|----------------------------------------------------------------------------------------------------------------------------------|
| Cα regularity of weak solutions of non-homogeneous ultraparabolic equations with drift terms                                     |
| 2023                                                                                                                             |
| 2023                                                                                                                             |
| Wendong Wang, Liqun Zhang                                                                                                        |
| Science China Mathematics                                                                                                        |
| 5f0712dd9f112be4d98e48d1a625a5db6224ff1cdc32996f64ecd3119d764844d8500afc1610adcde00436d45b63b2f6b7726d8a25e04272c83b0fda36c736e9 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

# **Similar content being viewed by others**

![](_page_2_Picture_5.jpeg)

# **[Optimal regularity for degenerate Kolmogorov equations in non](https://link.springer.com/10.1007/s00028-023-00916-9?fromPaywallRec=true)[divergence form with rough-in-time coefficients](https://link.springer.com/10.1007/s00028-023-00916-9?fromPaywallRec=true)**

Article Open access 26 October 2023

![](_page_2_Picture_8.jpeg)

# **[Regularity results for a class of nonlinear fractional Laplacian and](https://link.springer.com/10.1007/s00030-021-00693-9?fromPaywallRec=true) [singular problems](https://link.springer.com/10.1007/s00030-021-00693-9?fromPaywallRec=true)**

Article 10 April 2021

![](_page_3_Picture_2.jpeg)

# **[Regularity for parabolic equations with singular or degenerate](https://link.springer.com/10.1007/s00526-020-01876-5?fromPaywallRec=true) [coefficients](https://link.springer.com/10.1007/s00526-020-01876-5?fromPaywallRec=true)**

Article 24 January 2021

### **Explore related subjects**

Discover the latest articles, books and news in related subjects, suggested using machine learning.

- [Differential Equations](file:///subjects/differential-equations) •
- [Ordinary Differential Equations](file:///subjects/ordinary-differential-equations) •
- [Partial Differential Equations](file:///subjects/partial-differential-equations) •
- [Stochastic Partial Differential Equations](file:///subjects/stochastic-partial-differential-equations) •
- [Partial Differential Equations on Manifolds](file:///subjects/partial-differential-equations-on-manifolds) •
- [Calculus of Variations and Optimization](file:///subjects/calculus-of-variations-and-optimization) •

# **References**

Anceschi F, Polidoro S. A survey on the classical theory for Kolmogorov equation. Matematiche (Catania), 2020, 75: 221–258 1.

[MathSciNet](http://www.ams.org/mathscinet-getitem?mr=4069607) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20survey%20on%20the%20classical%20theory%20for%20Kolmogorov%20equation&journal=Matematiche%20%28Catania%29&volume=75&pages=221-258&publication_year=2020&author=Anceschi%2CF&author=Polidoro%2CS)

 Anceschi F, Polidoro S, Ragusa M A. Moser's estimates for degenerate Kolmogorov equations with non-negative divergence lower order coefficients. Nonlinear Anal, 2019, 189: 111568

Article MathSciNet Google Scholar

3. Anceschi F, Rebucci A. A note on the weak regularity theory for degenerate Kolmogorov equations. J Differential Equations, 2022, 341: 538–588

Article MathSciNet Google Scholar

 Angiuli L, Lorenzi L. On the estimates of the derivatives of solutions to nonautonomous Kolmogorov equations and their consequences. Riv Math Univ Parma (NS), 2016, 7: 421–471

MathSciNet Google Scholar

Bouchut F. Hypoelliptic regularity in kinetic equations. J Math Pures Appl (9), 2002,
81: 1135–1159

Article MathSciNet Google Scholar

 Bramanti M, Cerutti M C, Manfredini M. L<sup>p</sup> estimates for some ultraparabolic operators with discontinuous coefficients. J Math Anal Appl, 1996, 200: 332–354

Article MathSciNet Google Scholar

7. Cinti C, Pascucci A, Polidoro S. Pointwise estimates for a class of non-homogeneous Kolmogorov equations. Math Ann, 2008, 340: 237–264

Article MathSciNet Google Scholar

 Cinti C, Polidoro S. Pointwise local estimates and Gaussian upper bounds for a class of uniformly subelliptic ultraparabolic operators. J Math Anal Appl, 2008, 338: 946– 969

Article MathSciNet Google Scholar

9. De Giorgi E. Sulla differenziabilità e l'analiticità delle estremali degli integrali multipli regolari. Mem Accad Sci Torino Cl Sci Fis Mat Nat (3), 1957, 3: 25–43

MathSciNet Google Scholar

 Di Francesco M, Polidoro S. Schauder estimates, Harnack inequality and Gaussian lower bound for Kolmogorov-type operators in non-divergence form. Adv Difference Equ. 2006, 11: 1261–1320

MathSciNet Google Scholar

11. Farkas B, Lorenzi L. On a class of hypoelliptic operators with unbounded coefficients in  $\mathbb{R}^n$ . Commun Pure Appl Anal, 2009, 8: 1159–1201

Article MathSciNet Google Scholar

12. Folland G B. Subelliptic estimates and function spaces on nilpotent Lie groups. Ark Mat, 1975, 13: 161–207

Article MathSciNet Google Scholar

13. Golse F, Imbert C, Mouhot C, et al. Harnack inequality for kinetic Fokker-Planck equations with rough coefficients and application to the Landau equation. Ann Sc Norm Super Pisa Cl Sci (5), 2019, 5: 253–295

MathSciNet Google Scholar

14. Gu L K. Second-Order Parabolic Partial Differential Equations (in Chinese). Xiamen: Xiamen University Press, 2002

Google Scholar

- 15. Guerand J, Imbert C. Log-transform and the weak Harnack inequality for kinetic Fokker-Planck equations. J Inst Math Jussieu, 2023, in press
- 16. Guerand J, Mouhot C. Quantitative De Giorgi methods in kinetic theory. J Éc polytech Math, 2022, 9: 1159–1181

Article MathSciNet Google Scholar

Kruzhkov S N. A priori bounds for generalized solutions of second-order elliptic and parabolic equations (in Russian). Dokl Akad Nauk SSSR, 1963, 150: 748–751 17.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=151703) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20priori%20bounds%20for%20generalized%20solutions%20of%20second-order%20elliptic%20and%20parabolic%20equations%20%28in%20Russian%29&journal=Dokl%20Akad%20Nauk%20SSSR&volume=150&pages=748-751&publication_year=1963&author=Kruzhkov%2CS%20N)

Kruzhkov S N. A priori bounds and some properties of solutions of elliptic and parabolic equations. Mat Sb, 1964, 65: 522–570 18.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=171086) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20priori%20bounds%20and%20some%20properties%20of%20solutions%20of%20elliptic%20and%20parabolic%20equations&journal=Mat%20Sb&volume=65&pages=522-570&publication_year=1964&author=Kruzhkov%2CS%20N)

Kupcov L P. The fundamental solutions of a certain class of elliptic-parabolic second order equations. Differ Uravn, 1972, 8: 1649–1660 19.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=315290) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20fundamental%20solutions%20of%20a%20certain%20class%20of%20elliptic-parabolic%20second%20order%20equations&journal=Differ%20Uravn&volume=8&pages=1649-1660&publication_year=1972&author=Kupcov%2CL%20P)

Lanconelli E, Polidoro S. On a class of hypoelliptic evolution operaters. Rend Semin Mat Univ Politec Torino, 1994, 52: 29–63 20.

### [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20a%20class%20of%20hypoelliptic%20evolution%20operaters&journal=Rend%20Semin%20Mat%20Univ%20Politec%20Torino&volume=52&pages=29-63&publication_year=1994&author=Lanconelli%2CE&author=Polidoro%2CS)

Lorenzi L. Estimates of the derivatives for a class of parabolic degenerate operators with unbounded coefficients in ℝ <sup>N</sup>. Ann Sc Norm Super Pisa Cl Sci (5), 2005, 4: 255–293 21.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2163557) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Estimates%20of%20the%20derivatives%20for%20a%20class%20of%20parabolic%20degenerate%20operators%20with%20unbounded%20coefficients%20in%20%E2%84%9DN&journal=Ann%20Sc%20Norm%20Super%20Pisa%20Cl%20Sci%20%285%29&volume=4&pages=255-293&publication_year=2005&author=Lorenzi%2CL)

Lorenzi L. Schauder estimates for degenerate elliptic and parabolic problems with unbounded coefficients in ℝ <sup>N</sup>. Differential Integral Equations, 2005, 18: 531–566 22.

### [Article](https://doi.org/10.57262%2Fdie%2F1356060184) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2136978) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Schauder%20estimates%20for%20degenerate%20elliptic%20and%20parabolic%20problems%20with%20unbounded%20coefficients%20in%20%E2%84%9DN&journal=Differential%20Integral%20Equations&doi=10.57262%2Fdie%2F1356060184&volume=18&pages=531-566&publication_year=2005&author=Lorenzi%2CL)

Lunardi A. Schauder estimates for a class of degenerate elliptic and parabolic operators with unbounded coefficients in ℝ <sup>N</sup>. Ann Sc Norm Super Pisa Cl Sci (4), 1997, 24: 133–164 23.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1475774) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Schauder%20estimates%20for%20a%20class%20of%20degenerate%20elliptic%20and%20parabolic%20operators%20with%20unbounded%20coefficients%20in%20%E2%84%9DN&journal=Ann%20Sc%20Norm%20Super%20Pisa%20Cl%20Sci%20%284%29&volume=24&pages=133-164&publication_year=1997&author=Lunardi%2CA)

Manfredini M. The Dirichlet problem for a class of ultraparabolic equations. Adv Difference Equ, 1997, 2: 831–866 24.

### [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1751429) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Dirichlet%20problem%20for%20a%20class%20of%20ultraparabolic%20equations&journal=Adv%20Difference%20Equ&volume=2&pages=831-866&publication_year=1997&author=Manfredini%2CM)

Manfredini M, Polidoro S. Interior regularity for weak solutions of ultraparabolic equations in divergence form with discontinuous coefficients. Boll Unione Mat Ital, 1998, 1B: 651–675 25.

[MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1662349) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Interior%20regularity%20for%20weak%20solutions%20of%20ultraparabolic%20equations%20in%20divergence%20form%20with%20discontinuous%20coefficients&journal=Boll%20Unione%20Mat%20Ital&volume=1B&pages=651-675&publication_year=1998&author=Manfredini%2CM&author=Polidoro%2CS)

Moser J. On Harnack's theorem for elliptic differential equations. Comm Pure Appl Math, 1961, 14: 577–591 26.

[Article](https://doi.org/10.1002%2Fcpa.3160140329) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=159138) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=On%20Harnack%E2%80%99s%20theorem%20for%20elliptic%20differential%20equations&journal=Comm%20Pure%20Appl%20Math&doi=10.1002%2Fcpa.3160140329&volume=14&pages=577-591&publication_year=1961&author=Moser%2CJ)

Moser J. A Harnack inequality for parabolic differential equations. Comm Pure Appl Math, 1964, 17: 101–134 27.

[Article](https://doi.org/10.1002%2Fcpa.3160170106) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=159139) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20Harnack%20inequality%20for%20parabolic%20differential%20equations&journal=Comm%20Pure%20Appl%20Math&doi=10.1002%2Fcpa.3160170106&volume=17&pages=101-134&publication_year=1964&author=Moser%2CJ)

Mouhot C. De Giorgi-Nash-Moser and Hörmander theories: New interplays. In: Proceedings of the International Congress of Mathematicians—Rio de Janeiro 2018, vol. 3. Hackensack: World Scientific, 2018, 2467–2493 28.

[Google Scholar](http://scholar.google.com/scholar_lookup?&title=De%20Giorgi-Nash-Moser%20and%20H%C3%B6rmander%20theories%3A%20New%20interplays&pages=2467-2493&publication_year=2018&author=Mouhot%2CC)

Nash J. Continuity of solutions of parabolic and elliptic equations. Amer J Math, 1958, 80: 931–954 29.

[Article](https://doi.org/10.2307%2F2372841) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=100158) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Continuity%20of%20solutions%20of%20parabolic%20and%20elliptic%20equations&journal=Amer%20J%20Math&doi=10.2307%2F2372841&volume=80&pages=931-954&publication_year=1958&author=Nash%2CJ)

Pascucci A, Polidoro S. The Moser's iterative method for a class of ultraparabolic equations. Commun Contemp Math, 2004, 6: 395–417 30.

[Article](https://doi.org/10.1142%2FS0219199704001355) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=2068847) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Moser%E2%80%99s%20iterative%20method%20for%20a%20class%20of%20ultraparabolic%20equations&journal=Commun%20Contemp%20Math&doi=10.1142%2FS0219199704001355&volume=6&pages=395-417&publication_year=2004&author=Pascucci%2CA&author=Polidoro%2CS)

Polidoro S, Ragusa M A. Hölder regularity for solutions of ultraparabolic equations in divergence form. Potential Anal, 2001, 14: 341–350 31.

[Article](https://doi.org/10.1023%2FA%3A1011261019736) [MathSciNet](http://www.ams.org/mathscinet-getitem?mr=1825690) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=H%C3%B6lder%20regularity%20for%20solutions%20of%20ultraparabolic%20equations%20in%20divergence%20form&journal=Potential%20Anal&doi=10.1023%2FA%3A1011261019736&volume=14&pages=341-350&publication_year=2001&author=Polidoro%2CS&author=Ragusa%2CM%20A)

32. Wang W D, Zhang L Q. The Hölder continuity of a class of 3-dimension ultraparabolic equations. Acta Math Sci Ser B Engl Ed, 2009, 29: 527–538

MathSciNet Google Scholar

33. Wang W D, Zhang L Q. The  $C^{\alpha}$  regularity of a class of non-homogeneous ultraparabolic equations. Sci China Ser A, 2009, 52: 1589–1606

Article MathSciNet Google Scholar

34. Wang W D, Zhang L Q. The  $C^{\alpha}$  regularity of weak solutions of ultraparabolic equations. Discrete Contin Dyn Syst. 2011, 29: 1261–1275

Article MathSciNet Google Scholar

35. Xin Z P, Zhang L Q. On the global existence of solutions to the Prandtl's system. Adv Math, 2004, 181: 88–133

Article MathSciNet Google Scholar

- 36. Xin Z P, Zhang L Q, Zhao J N. Global well-posedness and regularity of weak solutions to the Prandtl's system. arXiv:2203.08988v2, 2022
- 37. Zhang L Q. The  $C^{\alpha}$  regularity of a class of ultraparabolic equations. Commun Contemp Math, 2011, 13: 375–387

Article MathSciNet Google Scholar

Download references

# **Acknowledgements**

Wendong Wang was supported by National Natural Science Foundation of China (Grant No. 12071054), National Support Program for Young Top-Notch Talents and Dalian High-Level Talent Innovation Project (Grant No. 2020RD09). Liqun Zhang was supported by National Natural Science Foundation of China (Grant Nos. 11471320, 11631008 and 12031012).

# **Author information**

### **Authors and Affiliations**

<span id="page-9-1"></span>School of Mathematical Sciences, Dalian University of Technology, Dalian, 116024, China 1.

Wendong Wang

<span id="page-9-3"></span>Institute of Mathematics, Academy of Mathematics and Systems Science, Chinese Academy of Sciences, Beijing, 100190, China 2.

Liqun Zhang

### Authors

<span id="page-9-0"></span>Wendong Wang 1.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Wendong%20Wang)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Wendong%20Wang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Wendong%20Wang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

<span id="page-9-2"></span>Liqun Zhang 2.

[View author publications](file:///search?sortBy=newestFirst&dc.creator=Liqun%20Zhang)

Search author on[:PubMed](https://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=search&term=Liqun%20Zhang) [Google Scholar](https://scholar.google.co.uk/scholar?as_q=&num=10&btnG=Search+Scholar&as_epq=&as_oq=&as_eq=&as_occt=any&as_sauthors=%22Liqun%20Zhang%22&as_publication=&as_ylo=&as_yhi=&as_allsubj=all&hl=en)

## **Corresponding author**

Correspondence to [Wendong Wang.](mailto:wendong@dlut.edu.cn)

# **Rights and permissions**

[Reprints and permissions](https://s100.copyright.com/AppDispatchServlet?title=C%CE%B1%20regularity%20of%20weak%20solutions%20of%20non-homogeneous%20ultraparabolic%20equations%20with%20drift%20terms&author=Wendong%20Wang%20et%20al&contentID=10.1007%2Fs11425-021-2098-0©right=Science%20China%20Press&publication=1674-7283&publicationDate=2023-08-23&publisherName=SpringerNature&orderBeanReset=true)

## About this article

![](_page_10_Picture_1.jpeg)

### <span id="page-10-0"></span>Cite this article

Wang, W., Zhang, L.  $C^{\alpha}$  regularity of weak solutions of non-homogeneous ultraparabolic equations with drift terms. *Sci. China Math.* **67**, 23–44 (2024). https://doi.org/10.1007/s11425-021-2098-0

### Download citation

• Received: 01 November 2021

• Accepted: 18 January 2023

• Published: 23 August 2023

• Issue date: January 2024

• DOI: https://doi.org/10.1007/s11425-021-2098-0

# Keywords

- ultraparabolic equations
- Moser iteration
- Poincaré inequality
- <u>C <sup>α</sup> regularity</u>

# MSC(2020)

- <u>35K70</u>
- 35H10
- 35B65

# **Access this article**

[Log in via an institution](file://wayf.springernature.com?redirect_uri=https%3A%2F%2Flink.springer.com%2Farticle%2F10.1007%2Fs11425-021-2098-0)

# **Subscribe and save**

Springer+ from €37.37 /Month

- Starting from 10 chapters or articles per month
- Access and download chapters and articles from more than 300k books and 2,500 journals
- Cancel anytime

**[View plans](https://link.springer.com/product/springer-plus)** 

### **Buy Now**

| article                                                                                                                          |
|----------------------------------------------------------------------------------------------------------------------------------|
| 10.1007/s11425-021-2098-0                                                                                                        |
| 1869-1862                                                                                                                        |
| Cα regularity of weak solutions of non-homogeneous ultraparabolic equations with drift terms                                     |
| 2023                                                                                                                             |
| 2023                                                                                                                             |
| Wendong Wang, Liqun Zhang                                                                                                        |
| Science China Mathematics                                                                                                        |
| 5f0712dd9f112be4d98e48d1a625a5db6224ff1cdc32996f64ecd3119d764844d8500afc1610adcde00436d45b63b2f6b7726d8a25e04272c83b0fda36c736e9 |
| Buy article PDF 39,95 €                                                                                                          |

Price includes VAT (China (P.R.))

Instant access to the full article PDF.

[Institutional subscriptions](https://www.springernature.com/gp/librarians/licensing/agc/journals) 

### Advertisement

# <span id="page-12-1"></span>**Search**

| Search by keyword or author |  |  |  |
|-----------------------------|--|--|--|
|                             |  |  |  |
|                             |  |  |  |

Search

# <span id="page-12-0"></span>**Navigation**

- [Find a journal](https://link.springer.com/journals/)  •
- [Publish with us](https://www.springernature.com/gp/authors) •
- [Track your research](https://link.springernature.com/home/) •

### **Discover content**

- [Journals A-Z](https://link.springer.com/journals/a/1) •
- [Books A-Z](https://link.springer.com/books/a/1) •

### **Publish with us**

- [Journal finder](https://link.springer.com/journals) •
- [Publish your research](https://www.springernature.com/gp/authors) •
- [Language editing](https://authorservices.springernature.com/go/sn/?utm_source=SNLinkfooter&utm_medium=Web&utm_campaign=SNReferral) •
- [Open access publishing](https://www.springernature.com/gp/open-science/about/the-fundamentals-of-open-access-and-open-research) •

### **Products and services**

- [Our products](https://www.springernature.com/gp/products) •
- [Librarians](https://www.springernature.com/gp/librarians) •
- [Societies](https://www.springernature.com/gp/societies) •
- [Partners and advertisers](https://www.springernature.com/gp/partners) •

### **Our brands**

- [Springer](https://www.springer.com/) •
- [Nature Portfolio](https://www.nature.com/) •
- [BMC](https://link.springer.com/brands/bmc) •
- [Palgrave Macmillan](https://www.palgrave.com/) •
- [Apress](https://www.apress.com/) •
- [Discover](https://link.springer.com/brands/discover) •
- Your privacy choices/Manage cookies •
- [Your US state privacy rights](https://www.springernature.com/gp/legal/ccpa) •
- [Accessibility statement](https://link.springer.com/accessibility) •
- [Terms and conditions](https://link.springer.com/termsandconditions) •
- [Privacy policy](https://link.springer.com/privacystatement) •
- [Help and support](https://support.springernature.com/en/support/home) •
- [Legal notice](https://link.springer.com/legal-notice) •
- [Cancel contracts here](https://support.springernature.com/en/support/solutions/articles/6000255911-subscription-cancellations) •

101.126.53.52

Not affiliated

[Springer Nature](https://www.springernature.com/)

© 2025 Springer Nature