![](_page_0_Picture_0.jpeg)

<span id="page-1-0"></span>![](_page_1_Picture_0.jpeg)

## Mathematical problems of boundary layer theory

O A Oleinik

© 1968 The London Mathematical Society

[Russian Mathematical Surveys,](file:///journal/0036-0279) [Volume 23,](file:///volume/0036-0279/23) [Number 3](file:///issue/0036-0279/23/3)

**Citation** O A Oleinik 1968 Russ. Math. Surv. **23** 1

**DOI** 10.1070/RM1968v023n03ABEH003781

## Abstract

The equations of boundary layer theory were derived by Prandtl in 1904. These equations are the basis of boundary layer theory, which has been intensively developed for more than half a century and is one of the important branches of contemporary hydromechanics. Boundary layer theory is the subject of numerous monographs (see [3], [4] and others), written in the USSR and abroad, and also of a large collection of articles setting out the results of theoretical and experimental investigations. In connection with engineering problems (in particular, the important problem of determining the resistance of a medium to a body moving in it), the most important methods are numerical methods for solving Prandtl's system. Problems of the approximate solution of systems of boundary layer equations were investigated by Kármán, Polhausen, Kochin, Dorodnitsyn, Loitsyanskii, and many others. The present paper deals with mathematical problems in boundary layer theory. One of these is the problem of conditions for which a solution of Prandtl's system exists. This mathematical problem is important, since in the boundary layer there may occur the so-called boundary layer separation, which leads to the appearance of singularities in the