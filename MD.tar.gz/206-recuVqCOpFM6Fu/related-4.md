# AN ENGQUIST-OSHER-TYPE SCHEME FOR CONSERVATION LAWS WITH DISCONTINUOUS FLUX ADAPTED TO FLUX CONNECTIONS\*

RAIMUND BÜRGER<sup>†</sup>, KENNETH H. KARLSEN<sup>‡</sup>, AND JOHN D. TOWERS<sup>§</sup>

**Abstract.** We consider scalar conservation laws with the spatially varying flux H(x)f(u) + (1 - H(x))g(u), where H(x) is the Heaviside function and f and g are smooth nonlinear functions. Adimurthi, Mishra, and Veerappa Gowda [J. Hyperbolic Differ. Equ., 2 (2005), pp. 783-837] pointed out that such a conservation law admits many  $L^1$  contraction semigroups, one for each so-called connection (A, B). Here we define entropy solutions of type (A, B) involving Kružkov-type entropy inequalities that can be adapted to any fixed connection (A, B). It is proved that these entropy inequalities imply the  $L^1$  contraction property for  $L^{\infty}$  solutions, in contrast to the "piecewise smooth" setting of Adimurthi, Mishra, and Veerappa Gowda. For a fixed connection, these entropy inequalities include a single adapted entropy of the type used by Audusse and Perthame [Proc. Roy. Soc. Edinburgh Sect. A, 135 (2005), pp. 253-265]. We prove convergence of a new difference scheme that approximates entropy solutions of type (A, B) for any connection (A, B) if a few parameters are varied. The scheme relies on a modification of the standard Engquist-Osher flux, is simple as no  $2 \times 2$  Riemann solver is involved, and is designed such that the steady-state solution connecting A to B is preserved. In contrast to most analyses of similar problems, our convergence proof is not based on the singular mapping or compensated compactness methods, but on standard spatial variation estimates away from the flux discontinuity. Some numerical examples are presented.

**Key words.** Engquist–Osher scheme, conservation law with discontinuous flux, flux connection, adapted entropy, entropy solution of type (A, B)

AMS subject classifications. 35L65, 65M06

**DOI.** 10.1137/07069314X

## 1. Introduction and preliminaries.

1.1. Scope of the paper. We are interested in the numerical approximation of solutions to the initial value problem

(1.1) 
$$u_t + \mathcal{F}(x, u)_x = 0 \quad \text{for } (x, t) \in \Pi_T := \mathbb{R} \times (0, T),$$
$$u(x, 0) = u_0(x) \quad \text{for } x \in \mathbb{R},$$
$$\mathcal{F}(x, u) := H(x)f(u) + (1 - H(x))g(u) = \begin{cases} f(u) & \text{for } x \ge 0, \\ g(u) & \text{for } x < 0, \end{cases}$$

where H(x) is the Heaviside function. Thus, the flux  $\mathcal{F}(x, u)$  of this conservation law has a spatial dependence that is discontinuous at x = 0 if the functions f and g are

<sup>\*</sup>Received by the editors May 29, 2007; accepted for publication (in revised form) January 15, 2009; published electronically April 22, 2009.

http://www.siam.org/journals/sinum/47-3/69314.html

<sup>&</sup>lt;sup>†</sup>CI<sup>2</sup>MA and Departamento de Ingeniería Matemática, Facultad de Ciencias Físicas y Matemáticas, Universidad de Concepción, Casilla 160-C, Concepción, Chile (rburger@ing-mat.udec. cl). Parts of this research were conducted while this author visited the Centre of Mathematics for Applications (CMA) at the University of Oslo, and he is grateful to OYIA for financial support. This author's research was supported by Fondecyt (Chile) projects 1090456 and 7060104 and Fondap in Applied Mathematics project 15000001.

<sup>&</sup>lt;sup>‡</sup>Centre of Mathematics for Applications (CMA), University of Oslo, P.O. Box 1053, Blindern, N-0316 Oslo, Norway (kennethk@math.uio.no). This author's research was supported by an Outstanding Young Investigators Award (OYIA) from the Research Council of Norway.

<sup>§</sup>MiraCosta College, Cardiff-by-the-Sea, CA 92007-1516 (john.towers@cox.net). This author's research was supported by Fondecyt project 7060104.

different. Because of their interesting features and the large number of applications in which these equations occur, conservation laws with discontinuous flux have seen a great deal of interest in recent years; see, e.g., [1, 2, 3, 4, 5, 6, 11, 12, 13, 14, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 32, 33, 34, 36, 37, 41, 43, 44].

In a series of papers [25, 26, 27, 43, 44], we developed a well-posedness theory for a class of equations with discontinuous flux and constructed simple scalar difference schemes that provably converge to entropy solutions as the discretization parameters tend to zero. The mathematical and numerical frameworks in [25, 26, 27, 43, 44] were then extended and applied to some applicative models; see, e.g., [11, 12, 13].

In the aforementioned papers, we proved the uniqueness of weak solutions satisfying a particular entropy condition, provided that the flux function satisfies a so-called crossing condition. Geometrically, in the context of (1.1), the crossing condition requires that either the graphs of g and f do not cross, or if they do, the graph of g lies above the graph of f to the left of any crossing point. In this work, we provide a Kruˇzkov-type entropy formulation [31] that does *not* require the crossing condition to ensure uniqueness.

Adimurthi, Mishra, and Veerappa Gowda [2] pointed out that (1.1) admits many L<sup>1</sup>-contractive semigroups of solutions, one for each so-called *connection* (A, B). A connection is a particular pair of solution values satisfying the Rankine–Hugoniot condition valid across x = 0, i.e., g(A) = f(B). We put forward a notion of *entropy solutions of type* (A, B) involving distinct Kruˇzkov-type entropy inequalities that can be adapted to any fixed connection (A, B). We prove that these entropy inequalities imply the L<sup>1</sup> contraction property. For a fixed connection, they include a single adapted entropy of the type recently used by Audusse and Perthame [4]. Our approach avoids the restrictive "piecewise smoothness" setting of [2]. Concerning the nomenclature, we emphasize that although the connection (A, B) per definition is, in fact, a singled-out stationary solution, an entropy solution "of type (A, B)" is, of course, in general a transient one, which is just "labeled" by (A, B) since these parameters play a role in the solution concept.

The main contribution of this paper is a scalar monotone difference scheme for which we prove convergence to entropy solutions of type (A, B) of (1.1). The scheme is simple in the sense that no 2×2 Riemann solver is required. It takes the form of an explicit conservative marching formula on a rectangular grid, where the numerical flux for all cells is the Engquist–Osher (EO) flux, with the exception of the cell interface that is associated with the flux discontinuity, and for which a specific interface flux is used. The interface flux, which is based on a novel modification of the EO flux, is designed to preserve certain steady-state solutions.

In [9, 11, 12, 13, 25, 43, 44], we used the EO flux to construct difference schemes for conservation laws (and degenerate parabolic equations) with flux discontinuities. However, our present approach differs significantly. In our earlier efforts, we considered conservation laws of the form <sup>w</sup>t <sup>+</sup> <sup>f</sup>(*γ*(x), w)x = 0, where *<sup>γ</sup>* is a vector of space-dependent, possibly discontinuous coefficients, and which was discretized on a spatial mesh that was staggered against that for the conserved quantity w. This allowed us to simply use the standard EO flux without any particular concern for the interfaces where the discontinuities of *γ* are located. In other words, we did not have an interface flux, as we do in the present situation. The staggered mesh approach has the advantage of simplicity and is suitable if there are no flux crossings, or where the flux satisfies the crossing condition (see (1.10) below). However, the more general setup of this paper requires a more explicit treatment of the interface, which motivates the new generalization (see (1.14) below) of the EO flux.

![](_page_2_Figure_3.jpeg)

Fig. 1.1. Various possibilities for fluxes f and g. The thick line represents  $u \mapsto g(u)$ , and the thin line represents  $u \mapsto f(u)$ .

1.2. Flux crossings, connections, and characteristic conditions. To put this work in the perspective of literature and alternate treatments but also to set the scene for the remaining parts of this paper, we need to precisely state the assumptions underlying (1.1) and introduce some definitions.

We assume that  $f, g \in \text{Lip}([0,1])$ , f(u) = g(u) = 0 for u = 0, 1, f has a single maximum at  $u_f^* \in [0,1]$ , and g has a single maximum at  $u_g^* \in [0,1]$ . The function f is strictly increasing on  $(0, u_f^*)$  and strictly decreasing on  $(u_f^*, 1)$ , and likewise, g is strictly increasing on  $(0, u_g^*)$  and strictly decreasing on  $(u_g^*, 1)$ . We assume that both f and g are genuinely nonlinear in the sense that

$$f$$
 and  $g$  are not linear on any nondegenerate interval.

Moreover, we assume that there is at most one point  $u_{\chi} \in (0,1)$ , where  $f(u_{\chi}) = g(u_{\chi})$ , and if there is such an intersection point  $u_{\chi}$ , then the graphs of f and g are assumed to intersect transversally at  $u_{\chi}$  (a flux crossing). Figure 1.1 shows various possible configurations of f and g. For the initial data, we assume that

(1.3) 
$$u_0 \in L^{\infty}(\mathbb{R}); u_0(x) \in [0, 1] \text{ for a.e. } x \in \mathbb{R}.$$

Fixing a time  $t \in (0,T)$ , we define  $u_{\pm} := u(0^{\pm},t)$ . As we will point out later, these left and right traces always exist due to (1.2). Any weak solution of (1.1) will satisfy the Rankine–Hugoniot condition

$$(1.4) g(u_{-}) = f(u_{+}).$$

It is well known that this condition is not sufficient to guarantee uniqueness, and so additional conditions for a jump across x=0 to be admissible are required. In [26, 27] we required, in addition, the following condition to hold.

DEFINITION 1.1 (weak characteristic condition). Assume that the pair  $(u_-, u_+)$  satisfies the Rankine-Hugoniot condition (1.4). Then  $(u_-, u_+)$  is said to satisfy the weak characteristic condition if

(1.5) 
$$\min \{0, g'(u_{-})\} \max \{0, f'(u_{+})\} = 0 \quad \text{if } u_{-} \neq u_{+}.$$

This condition requires that the characteristics lead backward toward the x-axis on at least one side of the jump, unless  $u_{-} = u_{+}$ . If  $u_{-} = u_{+}$ , there is no restriction on the characteristics.

Meanwhile, Adimurthi, Jaffré, and Veerappa Gowda [1] imposed the following stronger requirement.

DEFINITION 1.2 (strong characteristic condition). Assume that the pair  $(u_-, u_+)$  satisfies (1.4). We say that  $(u_-, u_+)$  satisfies the strong characteristic condition if

(1.6) 
$$\min\{0, g'(u_-)\} \max\{0, f'(u_+)\} = 0.$$

This condition always requires that the characteristics lead backward toward the x-axis on at least one side of the jump, including the case  $u_{-} = u_{+}$ .

Both entropy jump conditions, (1.5) and (1.6), result in an  $L^1$ -contractive semigroup of solutions. Subsequently, Adimurthi, Mishra, and Veerappa Gowda [2] discovered that there are other such  $L^1$ -contractive semigroups, each associated with a different entropy jump condition (see also [20]). Each semigroup is characterized by a so-called *connection*, denoted (A, B), which is defined as follows [2].

DEFINITION 1.3 (connection (A, B)). Assume that the functions f and g satisfy all assumptions stated so far. Then a pair of states (A, B) is called a connection if

(1.7) 
$$g(A) = f(B), u_q^* \le A \le 1, 0 \le B \le u_f^*.$$

Our statement of (1.7) has the inequalities reversed, when compared with the definition of a connection in [2], where the functions f and g each have a single minimum. We assume, instead, that f and g each have a single maximum. This condition is satisfied in previous work [11, 12, 13], so (1.7) allows us to compare results.

The entropy jump condition associated with such a connection may be stated as follows.

DEFINITION 1.4 ((A, B)-characteristic condition). If  $(u_-, u_+)$  satisfies (1.4) and (A, B) is a connection, then  $(u_-, u_+)$  is said to satisfy the (A, B)-characteristic condition if

(1.8) 
$$\min\{0, g'(u_{-})\}\max\{0, f'(u_{+})\} = 0 \quad \text{if } (u_{-}, u_{+}) \neq (A, B).$$

According to this definition, the characteristics must lead backward toward the x-axis on at least one side of the jump, unless  $u_{-} = A$  and  $u_{+} = B$ , in which case there is no restriction on the characteristics.

Before continuing, let us explain the distinguished states  $u_{\rm L}^{\#}$  and  $u_{\rm R}^{\#}$  appearing in Figure 1.1. We let  $\mathcal{I}$  be the set of inadmissible pairs of states:

(1.9) 
$$\mathcal{I} := \{ (u_-, u_+) \mid (1.4) \text{ holds, } (1.6) \text{ fails} \}.$$

In light of our assumptions on f and g (see Figure 1.1 again), we may define

$$u_{\mathrm{L}}^{\#} := \inf \left\{ u_{\mathrm{L}} \mid (u_{\mathrm{L}}, u_{\mathrm{R}}) \in \mathcal{I} \right\}, \quad u_{\mathrm{R}}^{\#} := \sup \left\{ u_{\mathrm{R}} \mid (u_{\mathrm{L}}, u_{\mathrm{R}}) \in \mathcal{I} \right\}.$$

Note that g'(u) < 0 on  $(u_L^\#, 1)$  and f'(u) > 0 on  $(0, u_R^\#)$ , and  $g(u_L^\#) = f(u_R^\#)$  and  $g'(u_L^\#)f'(u_R^\#) = 0$ . Observe that with the particular connection  $(A, B) = (u_L^\#, u_R^\#)$ , the (A, B)-characteristic condition (1.8) always enforces the strong characteristic condition (1.6). The easiest way to see this is by examining Figure 1.1.

Plots E and F of Figure 1.1 are the simplest in that no flux crossing (a point  $u_{\chi}$  where the graphs of f and g intersect transversally; see also (2.6) in section 2) occurs. Situations like this (no crossing) arise, for example, for a conservation law of the form  $u_t + (k(x)q(u))_x = 0$ , and k(x) has a jump. An application would be traffic flow on a road with discontinuously varying road surface conditions [8, 9, 35]. Although there are other valid connections, the one that is generally accepted as relevant is  $(A, B) = (u_L^\#, u_R^\#)$ . It is clear that the strong characteristic condition (1.6) is satisfied for solutions associated with this connection.

Among the four remaining plots, where flux crossings are present, plots B and D satisfy the so-called crossing condition [12, 27].

Definition 1.5 (crossing condition). Assume that the functions f and g satisfy all assumptions stated so far. We then say that they satisfy the crossing condition if

(1.10) for all 
$$u, v \in [0, 1]$$
:  $f(u) - g(u) < 0 < f(v) - g(v) \Longrightarrow u < v$ .

For both plots B and D,  $(A, B) = (u_{\chi}, u_{\chi})$  is a connection. Solutions associated with this connection satisfy the weak characteristic condition (1.5) but not necessarily the strong characteristic condition (1.6), an example being the constant solution  $u(x) \equiv u_{\chi}$ . Indeed, the only connection that enforces the strong condition is  $(A, B) = (u_{L}^{\#}, u_{R}^{\#})$ , and this is true for all flux configurations considered in this paper, not just those shown in plots B and D.

Remark 1.1. The characteristic conditions and the definition of a connection (A,B) are formulated here in max-min terminology and in terms of the maxima of the unimodal functions f and g, in part to establish the link with previous work. Alternatively, one could define these properties in terms of the six types of waves of the corresponding  $2 \times 2$  system; see Diehl [18]. For example, a pair  $(u_-, u_+)$ that satisfies (1.4) can be addressed as a wave; if  $g'(u_-) < 0$  and  $f'(u_+) > 0$ , we speak of an undercompressive wave, and  $g'(u_{-}) < 0$  and  $f'(u_{+}) = 0$  or  $g'(u_{-}) = 0$ and  $f'(u_+) > 0$  correspond to a marginally undercompressive wave. Overcompressive and marginally overcompressive waves (i.e., regular Lax and degenerate waves, respectively) are defined analogously. See Figure 1.2. Then the weak characteristic condition (Definition 1.1) is satisfied if in the case  $u_{-} \neq u_{+}$  ( $u_{-}, u_{+}$ ) is not an undercompressive wave, and the strong characteristic condition (Definition 1.2) is satisfied if  $(u_-, u_+)$  is not an undercompressive wave in any case. Furthermore, Definition 1.3 could be reformulated by defining an (A, B) wave to be a connection if it is an undercompressive or a marginally undercompressive wave, and a  $(u_-, u_+)$  wave satisfies the (A,B)-characteristic condition if it is either a connection or not an undercompressive wave (Definition 1.4). In that terminology, the set  $\mathcal{I}$  defined in (1.9) would be the set of all possible undercompressive waves. For our specific unimodal flux functions,  $(u_L^{\#}, u_R^{\#})$  is the unique marginally undercompressive wave.

1.3. Entropy solutions of type (A, B). In [11, 12, 13], we analyzed a clarifier-thickener (CT) model, which includes a space-dependent flux with several discontinuities, one of them being of the type of plots B and D, i.e., where the crossing condition

![](_page_5_Picture_3.jpeg)

Fig. 1.2. Six types of waves occurring at the interface. (a) undercompressive, (b) marginal undercompressive, (c) overcompressive, (d) marginal overcompressive, (e) regular Lax, (f) degenerate.

(1.10) is satisfied. The situation near the feed point of the CT model is similar to the model studied herein. If we assume that the fluxes of that model have one extremum each and we consider the location x=0 of that model locally, then the proper flux connection of that model should be given by  $(u_{\chi}, u_{\chi})$ . Having said this, we emphasize that the full CT model is not a special case of the problem studied herein.

Meanwhile, Adimurthi et al. [1, 2] (see also [28]) encountered the same configuration (plots B and D) in a model of two-phase flow in porous media. From the physics of the model, they concluded that the proper connection for that model is  $(A,B)=(u_{\rm L}^\#,u_{\rm R}^\#)$ . See [10] for details.

In the situation of plots A and C, the flux crossings violate the crossing condition, and thus, these flux configurations are not covered by the entropy solution theory of [27]. We conjectured in [27] that our inability to derive a uniqueness result for this configuration was most likely due to some missing entropy condition that we hoped to discover. It now appears that the missing entropy condition is the one that derives from the adapted entropy concept that we discuss below.

To state our concept of entropy solution, we need the following function, which is associated with a fixed connection (A, B) and jumps from A to B at x = 0:

(1.11) 
$$c^{AB}(x) := H(x)B + (1 - H(x))A = \begin{cases} A & \text{for } x \le 0, \\ B & \text{for } x > 0. \end{cases}$$

We use  $c^{AB}(x)$  to form the function  $u \mapsto |u - c^{AB}(x)|$ , which is an example of what Audusse and Perthame [4] call an adapted entropy. Now, we say that a function u is an entropy solution of type (A, B) of (1.1) provided it is a weak solution, it satisfies the Kružkov entropy condition to the left and right of x = 0, and, in addition, on  $\Pi_T$ 

it satisfies the following Kružkov-type entropy inequality:

$$(1.12) \quad \left|u-c^{AB}(x)\right|_t + \left(\operatorname{sgn}\left(u-c^{AB}(x)\right)\left(\mathcal{F}(x,u)-\mathcal{F}\left(x,c^{AB}(x)\right)\right)\right)_x \leq 0 \quad \text{in } \mathcal{D}'.$$

Condition (1.12) gives us the (A, B)-characteristic condition (1.8); cf. Lemma 3.2. For an in-depth discussion of entropy solutions of type (A, B), see section 2, while a formal definition is given in section 3.

Our solution concept is generally equivalent to that of Adimurthi, Mishra, and Veerappa Gowda [2] (see also [20]), with one important difference. We use (1.12) to capture the interface entropy condition, while [2] uses the entropy jump condition (3.6), which we *derive* from (1.12). The advantage of our approach is that we can prove the  $L^1$  stability without any additional regularity assumption, while in [2] the solution is required to be continuous except for a set of Lipschitz curves ("piecewise smooth"). This in turn enables us to rigorously prove convergence of our scheme.

1.4. Numerical schemes. To construct (approximate) entropy solutions of type (A, B), which is the main contribution of this paper, we propose a simple scalar upwind difference scheme based on a straightforward but novel modification of the EO flux. By modifying a few parameters, we can achieve that the scheme captures the solution associated with any connection (A, B). More precisely, our scheme is based on the standard scalar EO flux

(1.13) 
$$h^{EO}(u_{R}, u_{L}) = \frac{1}{2} (q(u_{R}) + q(u_{L})) - \frac{1}{2} \int_{u_{L}}^{u_{R}} |q'(w)| dw$$

(for the conservation law  $u_t + q(u)_x = 0$ ), and then, to accommodate the jump in the flux from g to f, we replace (1.13) by the interface flux

$$(1.14) \begin{array}{l} h^{AB}(u_{\mathrm{R}},u_{\mathrm{L}}) := \frac{1}{2} \left( \tilde{f}(u_{\mathrm{R}}) + \tilde{g}(u_{\mathrm{L}}) \right) - \frac{1}{2} \left[ \int_{B}^{u_{\mathrm{R}}} \left| \tilde{f}'(w) \right| \, dw - \int_{A}^{u_{\mathrm{L}}} \left| \tilde{g}'(w) \right| \, dw \right], \\ \tilde{f}(u) := \min \left\{ f(u), f(B) \right\}, \qquad \tilde{g}(u) = \min \left\{ g(u), g(A) \right\}. \end{array}$$

We prove that our scheme converges to the unique entropy solution of type (A, B). Adimurthi, Mishra, and Veerappa Gowda [2] also proposed a scheme for computing (A, B)-type entropy solutions, which differs from ours in that they use a Godunov-type interface flux, based on the solution of the full  $2 \times 2$  interface Riemann problem. In addition, they do not give a rigorous convergence proof. In fact, they have to postulate that the limit function of the numerical solution is piecewise smooth, and they need a delicate argument to prove that the left and right traces of the numerical solution along x=0 converge strongly [1]. Our approach avoids these difficulties. Their compactness proof relies on the singular mapping approach, which we avoid by deriving spatial variation estimates away from x=0.

1.5. Outline of this paper. The remainder of this paper is organized as follows. In section 2 we offer a series of remarks to shed some light on the notion of entropy solutions of type (A, B) and how it relates to existing literature, including partially adapted entropy solutions. In section 3 we state a precise definition of an entropy solution of type (A, B) and prove that this definition implies uniqueness of an entropy solution. In section 4 we present the difference scheme, specifically the interface flux that applies where the flux jumps from g to f, and we prove that the interface flux is monotone. In section 5 we continue with the analysis of the scheme, concluding with the main result, Theorem 5.1, which states that the scheme converges to the unique

entropy solution. In section 7 we make some remarks on the possibility of extending our results to more general flux functions. Finally, section 6 discusses a few numerical examples.

- 2. On entropy solutions of type (A, B) and partially adapted entropy solutions in the sense of Audusse and Perthame.
- **2.1.** Motivation of entropy inequalities. To facilitate the presentation below, we focus on the equation

$$(2.1) u_t + h\left(\gamma(x), u\right)_r = 0,$$

where the coefficient  $\gamma \in L^{\infty} \cap BV$  is piecewise smooth with a finite number of jump discontinuities located at  $\{\xi_m\}_{m=1}^M$  and  $(\gamma, u) \mapsto h(\gamma, u)$  is a regular function, satisfying conditions ensuring that the relevant solutions remain bounded whenever the initial data are bounded (see previous section for an example).

Note that (1.1) is an example of an equation of the form (2.1). To write the flux  $\mathcal{F}(x,u)$  as  $h(\gamma(x),u)$ , take  $\gamma(x)=H(x)$  and  $h(\gamma,u)=\gamma f(u)+(1-\gamma)g(u)$ .

To start the discussion, we go back to [26, 27], where we studied equations like (2.1) and defined a weak solution to be admissible if it satisfies the entropy condition

$$(2.2) \qquad |u-c|_t + (\operatorname{sgn}(u-c) \left(h(\gamma(x), u) - h(\gamma(x), c)\right))_x + \left\{\operatorname{sgn}(u-c) h\left(\gamma(x), c\right)_x\right\}\Big|_{x \neq \xi_m, m=1,\dots,M} - \sum_{m=1}^M |h\left(\gamma(\xi_m +), c\right) - h\left(\gamma(\xi_m -), c\right)| \leq 0 \quad \text{in } \mathcal{D} \text{ for all } c \in \mathbb{R}.$$

The weak characteristic condition (see Definition 1.1) can be derived from (2.2).

Let us briefly motivate (2.2). To this end, for  $\varepsilon, \delta > 0$ , let  $u^{\varepsilon,\delta}$  be a smooth solution to the parabolic equation

(2.3) 
$$u_t^{\varepsilon,\delta} + h\left(\gamma^{\delta}(x), u^{\varepsilon,\delta}\right)_x = \varepsilon u_{xx}^{\varepsilon,\delta},$$

where  $\gamma^{\delta}$  is a regularization (e.g., via convolution) of  $\gamma$ . The key point is to use a regularization that preserves the monotonicity of  $\gamma$  near the discontinuities.

In what follows, we refer to the process of smoothing the discontinuous coefficient and adding artificial viscosity as the "SVV (smoothing and vanishing viscosity) method." One can prove that

(2.4) 
$$\|u^{\varepsilon,\delta}\|_{L^{\infty}} \leq C$$
 for some constant  $C$  independent of  $\varepsilon, \delta$ ,

and, along a subsequence as  $\varepsilon, \delta \to 0$ , with  $\varepsilon/\delta = \mathcal{O}(1)$ ,

(2.5) 
$$u^{\varepsilon,\delta} \to u \text{ a.e. and in } L^p_{\text{loc}} \text{ for any } p < \infty,$$

where the limit u is a weak solution of (2.1). We refer to [23, 24] for proofs of these facts (which hold without a "piecewise smoothness" assumption on  $\gamma$ ). Multiplying (2.3) by  $\operatorname{sgn}(u^{\varepsilon,\delta}-c)$ , with  $c \in \mathbb{R}$  yields

$$\begin{split} \left| u^{\varepsilon,\delta} - c \right|_t + \left( \operatorname{sgn} \left( u^{\varepsilon,\delta} - c \right) \left( h \left( \gamma^\delta(x), u^{\varepsilon,\delta} \right) - h \left( \gamma^\delta(x), c \right) \right) \right)_x \\ + \operatorname{sgn} \left( u^{\varepsilon,\delta} - c \right) h \left( \gamma^\delta(x), c \right)_x \leq \varepsilon \left| u^{\varepsilon,\delta} - c \right|_{xx}. \end{split}$$

It is not difficult to see (cf., e.g., [13]) that if for each fixed  $c \in \mathbb{R}$ ,

(2.6) 
$$x \mapsto h_{\gamma}(\gamma(x), c)$$
 does not change sign across  $x = \xi_m, m = 1, \dots, M$ ,

(an example is provided by the multiplicative case  $h(\gamma, u) = \gamma h(u)$ ), then the limit u will satisfy the entropy condition (2.2). In other words, when (2.6) is satisfied, (2.2) picks out the solution constructed by the SVV method.

Before we attempt to motivate the inequality (1.12), let us point out a relation between (2.2) and (1.12); in the present context, (1.12) reads

$$(2.7) \qquad \left|u-c^{AB}(x)\right|_t + \left(\operatorname{sgn}\left(u-c^{AB}(x)\right)\left(h(\gamma(x),u)-h\left(\gamma(x),c^{AB}(x)\right)\right)\right)_x \leq 0.$$

Suppose the crossing condition (1.10) holds so that (2.2) and the theory in [27] applies. Let us fix a connection (A, B) for which the function  $c^{AB}(x)$ , which is a weak solution of  $h(\gamma(x), c^{AB}(x))_x = 0$ , satisfies (2.2). Let u = u(x, t) be an arbitrary entropy solution of (2.1) in the sense of (2.2). Then we simply need to repeat the proof in [27] of the  $L^1$  contraction property to conclude that u satisfies (2.7), i.e., whenever the theory in [27] applies and as long as the stationary weak solution  $c^{AB}(x)$  satisfies (2.2), an entropy solution in the sense of (2.2) is also an entropy solution of type (A, B); see also the examples in section 2.3.

To motivate (1.12), let us first assume that  $x \mapsto \gamma(x)$  is  $C^1$  for each fixed u and consider a  $C^1$  solution of (2.1). Then the chain rule yields

(2.8) 
$$|u - c(x)|_t + (\operatorname{sgn}(u - c(x)) (h(\gamma(x), u) - h(\gamma(x), c(x))))_x + \operatorname{sgn}(u - c(x)) h(\gamma(x), c(x))_x = 0$$

for any  $C^1$  function c(x). Now suppose c(x) is a solution of  $h(\gamma(x), c(x))_x = 0$ , i.e., c(x) is a stationary solution of (2.1). Put differently,  $c(x) = c_{\alpha}(x)$  satisfies

$$(2.9) h(\gamma(x), c_{\alpha}(x)) = \alpha$$

for some constant  $\alpha$ . In this case, (2.8) simplifies to

$$|u - c_{\alpha}(x)|_{t} + (\operatorname{sgn}(u - c_{\alpha}(x)))(h(\gamma(x), u) - h(\gamma(x), c_{\alpha}(x))))_{x} = 0.$$

When all the functions involved are nonsmooth, we replace this equality by

$$(2.10) \quad |u - c_{\alpha}(x)|_{t} + \left(\operatorname{sgn}\left(u - c_{\alpha}(x)\right)\left(h(\gamma(x), u) - h(\gamma(x), c_{\alpha}(x))\right)\right)_{x} \leq 0 \quad \text{in } \mathcal{D}'$$

for each  $c_{\alpha}(x)$  satisfying (2.9).

The standard Kružkov entropy formulation is applicable when  $\gamma(x)$  is Lipschitz continuous, in which case it incorporates the term  $\operatorname{sgn}(u-c)h(\gamma(x),c)_x$ ,  $c \in \mathbb{R}$ . This term does not make sense when  $\gamma(x)$  is discontinuous. The primary advantage with (2.10) is that this singular term does not appear.

2.2. Partially adapted entropy solutions and the SVV method. In certain situations, (2.1) is endowed with a sufficiently large class of stationary solutions  $c_{\alpha}(x)$  that can be utilized to prove uniqueness, even without knowing the traces of the solutions along the discontinuity points  $\{\xi_m\}_{m=1}^M$  of  $\gamma(x)$ . Indeed, in such situations, Audusse and Perthame [4] established the  $L^1$  contraction property of partially adapted entropy solutions, i.e., weak solutions satisfying the "partially adapted" entropy condition (2.10) (see also Baiti and Jenssen [6]). Recently, Chen, Even, and Klingenberg

[14] established an existence result for partially adapted entropy solutions via microscopic interacting particle systems, at least under certain conditions on the flux function (below we sketch a different proof of existence). The essential condition in [14] is that there exist numbers  $u_m, M_0 \in \mathbb{R}$  such that for  $x \in \mathbb{R} \setminus \{\xi_m\}_{m=1}^M$ , the mapping  $u \mapsto h(\gamma(x), u)$  is locally Lipschitz continuous, one-to-one from  $(-\infty, u_m]$  and  $[u_m, \infty)$  to  $[M_0, \infty)$  (or  $(-\infty, M_0]$ ), with  $h(\gamma(x), u_m) = M_0$ . A typical example covered by [14] is  $h(\gamma(x), u) = \gamma(x)u^2$ , but  $h(\gamma(x), u) = \gamma(x)u(1-u)$  is not covered (although uniqueness holds [4]).

We now embed the present work into the partially adapted entropy framework [4, 6, 14]. Whereas requiring (2.10) for a sufficiently large class of stationary solutions  $c_{\alpha}(x)$ , whenever this is meaningful, picks out the unique solution corresponding to the strong characteristic condition (cf. Definition 1.2), we are here interested in a Kružkov-type entropy formulation that can account for any (arbitrary but fixed) connection (A, B)—each one representing a specific "physical reality"—with a corresponding (A, B)-characteristic condition (cf. Definition 1.4). This has motivated the notion of entropy solutions of type (A, B) and (1.12) in particular.

As mentioned before, the weak and strong characteristic conditions can give rise to different solutions. More precisely, when (2.6) is violated, we no longer expect (at least not in general) (2.2) nor the notion of entropy solution of type (A, B) to single out SVV solutions. We elaborate on this statement in the next two subsections.

We will now sketch an argument revealing that SVV solutions will satisfy the "partially adapted" entropy condition

$$(2.11) |u - c_{\alpha}(x)|_{t} + (\operatorname{sgn}(u - c_{\alpha}(x)) (h(\gamma(x), u) - h(\gamma(x), c_{\alpha}(x))))_{x} \le 0,$$

for any admissible  $c_{\alpha}(x)$ , where we define  $c_{\alpha}(x)$  to be admissible if it satisfies the equation  $h(\gamma(x), c_{\alpha}(x)) = \alpha$  in the sense that

(2.12) 
$$\begin{cases} c_{\alpha}^{\delta} \to c_{\alpha} \text{ in } L_{\text{loc}}^{1} \text{ as } \delta \to 0, \\ \varepsilon \left( c_{\alpha}^{\delta} \right)_{xx} \to 0 \text{ in } L_{\text{loc}}^{1} \text{ as } \varepsilon, \delta \to 0, \end{cases}$$

where, for each  $\delta > 0$ ,  $c_{\alpha}^{\delta}(x)$  is a smooth function satisfying

(2.13) 
$$h\left(\gamma^{\delta}(x), c_{\alpha}^{\delta}(x)\right) = \alpha.$$

Taking (2.12) for granted for the moment, let us now show that an SVV solution u satisfies (2.11) for any admissible  $c_{\alpha}(x)$ . Using (2.13), let us rewrite (2.3) as

$$\left(2.14\right)\ \left(u^{\varepsilon,\delta}-c_{\alpha}^{\delta}\right)_{t}+\left(h\left(\gamma^{\delta}(x),u^{\varepsilon,\delta}\right)-h\left(\gamma^{\delta}(x),c_{\alpha}^{\delta}\right)\right)_{x}=\varepsilon\left(u^{\varepsilon,\delta}-c_{\alpha}^{\delta}\right)_{xx}+\varepsilon\left(c_{\alpha}^{\delta}\right)_{xx}.$$

Multiplying this with  $\operatorname{sgn}(u^{\varepsilon,\delta}-c_{\alpha}^{\delta})$  and applying the chain rule yields

$$(2.15) \qquad \begin{aligned} \left| u^{\varepsilon,\delta} - c_{\alpha}^{\delta} \right|_{t} + \left( \operatorname{sgn} \left( u^{\varepsilon,\delta} - c_{\alpha}^{\delta} \right) \left( h \left( \gamma^{\delta}(x), u^{\varepsilon,\delta} \right) - h \left( \gamma^{\delta}(x), c_{\alpha}^{\delta} \right) \right) \right)_{x} \\ & \leq \varepsilon \left| u^{\varepsilon,\delta} - c_{\alpha}^{\delta} \right|_{xx} + \left| \varepsilon \left( c_{\alpha}^{\delta} \right)_{xx} \right|. \end{aligned}$$

Finally, sending  $\varepsilon, \delta \to 0$  in (2.15), using (2.5) and (2.12) delivers (2.11).

In some situations one can verify that the stationary solutions  $c_{\alpha}(x)$  needed to ensure uniqueness of partially adapted entropy solutions, consult [4], are admissible in the sense of (2.12). The second condition in (2.12) might enforce a relation between  $\varepsilon$  and  $\delta$ , typically requiring  $\varepsilon \to 0$  (diffusion scale) somewhat faster than  $\delta \to 0$  (regularization scale); see examples below. In the situations just alluded to, the above simple arguments can be used to provide an existence result for partially adapted entropy solutions (existence was left open in [4], but see [14]).

2.3. Examples of equations for which (2.12) holds. Although it is not within the scope of this paper to identify conditions under which (2.12) holds (this is left for future work), let us provide two typical examples for which we can verify (2.12) directly. In these examples, the functions  $c_{\alpha}(x)$  identified by (2.12) coincide with the stationary solutions  $c_{\alpha}(x)$  required for the uniqueness proof in [4], thereby yielding existence of partially adapted entropy solutions in these examples.

To be consistent with the examples in [4, 14], we will consider flux functions g, f that have a minimum, instead of a maximum as we do in the rest of the paper. In the first example, we consider the multiplicative case (thus, no flux crossing) and take  $h(\gamma, u) = \gamma h(u)$  for  $h(u) = u^2/2$  and  $\gamma(x) \ge \gamma_0 > 0$ . Solving, with  $\alpha \ge 0$ ,

$$h(\gamma(x), c_{\alpha}(x)) = \alpha, \qquad h(\gamma^{\delta}(x), c_{\alpha}^{\delta}(x)) = \alpha,$$

we find two (corresponding) solutions of each equation:

$$c_{\alpha}^{\pm}(x) = \pm \sqrt{2\alpha/\gamma(x)}, \qquad c_{\alpha}^{\delta\pm}(x) = \pm \sqrt{2\alpha/\gamma^{\delta}(x)}.$$

Clearly,  $c_{\alpha}^{\delta\pm} \to c_{\alpha}^{\pm}$  in  $L_{\text{loc}}^1$  as  $\delta \to 0$ . Additionally,

$$\int_{\mathbb{R}} \left| \left( c_{\alpha}^{\delta \pm} \right)_{xx} \right| \, dx \le \frac{C}{\delta},$$

for some constant C depending on the total variation of  $\gamma$  but not on  $\delta$ , which follows, since  $\gamma$  is bounded away from zero and

$$\left| \left( \gamma^{\delta} \right)_x \right| \leq \frac{C}{\delta}, \qquad \int_{\mathbb{R}} \left| \left( \gamma^{\delta} \right)_{xx} \right| \, dx \leq \frac{C}{\delta}$$

for some constant C depending on the total variation of  $\gamma$  but not on  $\delta$ . Thus,

$$\int_{\mathbb{D}} \left| \varepsilon \left( c_{\alpha}^{\delta \pm} \right)_{xx} \right| \, dx \le C \frac{\varepsilon}{\delta} \to 0$$

if we assume that  $\varepsilon/\delta \to 0$  as  $\varepsilon, \delta \to 0$  (which is slightly stronger than the condition  $\varepsilon/\delta = \mathcal{O}(1)$  needed for (2.5) to hold [23]). Hence, we have verified (2.12).

In our second example, we take  $h(\gamma, u) = h(\gamma - u)$ , with  $h(u) = u^2/2$ . This example allows for flux crossing: indeed, for the flux crossing produced by  $\gamma(x) = H(-x)$ , the crossing condition (1.10) is satisfied. Then, for  $\alpha \geq 0$ ,

$$h\left(\gamma(x),c_{\alpha}(x)\right)=\alpha$$
 has two solutions  $c_{\alpha}^{\pm}(x)=\pm\sqrt{2\alpha}+\gamma(x),$ 

whereas

$$c_{\alpha}^{\delta\pm}(x) = \pm\sqrt{2\alpha} + \gamma^{\delta}(x)$$
 solve  $h\left(\gamma^{\delta}(x), c_{\alpha}^{\delta\pm}(x)\right) = \alpha$ .

Clearly, we can again verify (2.12), at least as long as  $\varepsilon/\delta \to 0$  as  $\varepsilon, \delta \to 0$ .

### 2.4. Some final remarks.

Remark 2.1. An alternative notion of admissibility is to require the solution  $c_{\alpha}(x)$  of  $h(\gamma(x), c_{\alpha}(x)) = \alpha$  to be obtainable as the strong  $L^1_{\text{loc}}$  limit as  $\varepsilon \to 0$  of smooth solutions  $c^{\varepsilon}_{\alpha}(x)$  to  $h(\gamma^{\varepsilon}(x), c^{\varepsilon}_{\alpha}(x)) - \varepsilon (c^{\varepsilon}_{\alpha})_x = \alpha$  (so that  $c^{\varepsilon}_{\alpha}(x)$  is a stationary solution of (2.3)). Then (2.14) simplifies to

$$(u^{\varepsilon} - c^{\varepsilon}_{\alpha})_t + (h(\gamma^{\varepsilon}(x), u^{\varepsilon}) - h(\gamma^{\varepsilon}(x), c^{\varepsilon}_{\alpha}))_x = \varepsilon (u^{\varepsilon} - c^{\varepsilon}_{\alpha})_{xx},$$

from which we can proceed as before to conclude that (2.11) holds. Observe that with this notion of admissibility, we are not operating with two different scales. It is left for future work to investigate whether this notion of admissibility yields a family of stationary solutions  $c_{\alpha}(x)$  that is large enough to ensure uniqueness [4].

Remark 2.2. When (2.6) is violated, we can no longer expect (2.2) nor the notion of entropy solution of type (A,B) to single out the SVV solutions (but we have sketched a proof that the notion of partial adapted entropy solutions is consistent with the SVV method). Examples of flux crossings for which (2.6) does not hold, also illustrated by our second example above, have already been discussed in the introduction; cf. plots B and D in Figure 1.1. For both plots,  $(u_{\chi}, u_{\chi})$  is a connection, and the corresponding  $c^{AB}(x) \equiv u_{\chi}$  clearly obeys (2.2). Solutions associated with this connection satisfy (2.2) and thus, also (2.7). On the other hand, they do not satisfy the partially adapted entropy condition (2.11). Indeed, the function  $c^{AB} \equiv u_{\chi}$  is not admissible in the sense of (2.12). The easiest way to be convinced about this fact is to calculate the constant  $u_{\chi}$  for our second example above and then observe that the functions  $c_{\alpha}^{\delta}(x)$  do not converge as  $\delta \to 0$  to this constant.

Remark 2.3. To further stress the importance of condition (2.6), let us consider the CT model analyzed in [12]. The flux

$$h\left(\gamma(x),u\right)=b(u)+\gamma(x)(u-u_\chi),\quad \gamma(x)=\begin{cases}q_{\rm L}<0 & for \ x<0,\\q_{\rm R}>0 & for \ x>0,\end{cases}$$

is a simplified version of the flux appearing in [12]. Here b(u) is the nonlinear batch flux density, and  $\gamma(x)(u-u_\chi)$  represents a diverging convective flow that has a spatial discontinuity at x=0. From the point of view of entropy theory and uniqueness, the situation is similar to plots B and D of Figure 1.1. Specifically, there is a single flux crossing at  $u=u_\chi$ , and, due to the shape of b(u), the crossing condition (1.10) is satisfied. The constant solution  $c_\alpha(x)=c_\alpha^\delta(x)=u_\chi$  is admissible, i.e., it satisfies  $h(\gamma(x),c_\alpha)=\alpha$ , with  $\alpha=b(u_\chi)$  in the sense of (2.12) and (2.13) for any smoothed version  $\gamma^\delta$  of  $\gamma$ . Thus, SVV solutions satisfy the partially adapted entropy condition (2.11) with  $c_\alpha(x)=u_\chi$ , i.e., they are entropy solutions of type (A,B), with  $(A,B)=(u_\chi,u_\chi)$ . Summarizing, from our previous arguments and the observations above, for this simplified CT model, the entropy solutions in the sense of (2.2) are the same as those defined by (1.12) with  $c^{AB}=u_\chi$ , and furthermore, they are SVV solutions. Although there is a flux crossing here, the special multiplicative way that the parameter  $\gamma$  enters the flux makes  $u_\chi$  admissible for the simplified CT model; indeed, because of this, condition (2.6) is satisfied here.

Remark 2.4. Although in the general flux crossing case entropy solutions in the sense of (2.2) cannot be constructed by the SVV method (2.3), they can be constructed by suitably designed scalar difference schemes; see, for example, [26, 27]. There is also another approach to constructing entropy solutions in the sense of (2.2), which was analyzed recently by Panov [40]. The idea is to replace (2.3) by a problem that regularizes the discontinuities in a slightly different way. For simplicity, let us assume that  $\gamma(x)$  is piecewise constant, so that  $h(\gamma(x),c)_x=0$ ,  $c\in\mathbb{R}$  for any  $x\notin\{\xi_m\}_{m=1}^M$ . Define  $\omega^\delta(x):=\frac{1}{\delta}\omega(x/\delta)$ , where  $\omega:\mathbb{R}\to\mathbb{R}$  is a smooth function with support in [-1,0] and  $\int_{\mathbb{R}}\omega(\xi)\,d\xi=1$ . Then form the regularized flux function

$$h^{\delta}(x,u) = \int_{\mathbb{R}} h(\gamma(x-y), u) \,\omega^{\delta}(y) \,dy,$$

which clearly is smooth in x for each fixed u. Additionally, as  $\delta \to 0$ ,

$$h^{\delta}(x,u) \to h(\gamma(x),u)$$
 in  $L^1_{loc}(\mathbb{R})$  for each fixed  $u$ .

Now let  $u^{\varepsilon,\delta}$  be a smooth solution of the equation

$$(2.16) u_t^{\varepsilon,\delta} + h^{\delta} \left( x, u^{\varepsilon,\delta} \right)_x = \varepsilon u_{xx}^{\varepsilon,\delta}.$$

Statements (2.4) and (2.5) continue to hold for (2.16). It remains to observe that the limit u of a converging sequence of solutions to (2.16) satisfies (2.2), independently of any flux crossing. However, this follows from the following property:

$$\begin{split} \left| h^{\delta}(x,c)_{x} \right| &\leq \left| h\left(\gamma(x),c\right)_{x} \right| \star \omega^{\delta} &\overset{\delta \to 0}{\longrightarrow} \left| h\left(\gamma(x),c\right)_{x} \right| \quad (in \ the \ sense \ of \ measures) \\ &= \sum_{m=1}^{M} \left| h\left(\gamma(\xi_{m}+),c\right) - h\left(\gamma(\xi_{m}-),c\right) \right|, \end{split}$$

which holds for any fixed  $c \in \mathbb{R}$ .

## 3. Entropy solutions of type (A, B) and uniqueness.

DEFINITION 3.1 (entropy solution of type (A, B)). Let (A, B) be a connection and  $c^{AB}: \mathbb{R} \to \mathbb{R}$  be the corresponding function defined by (1.11). A measurable function  $u: \Pi_T \to R$  is an entropy solution of type (A, B) of the initial value problem (1.1) if it satisfies the following conditions:

- (D.1)  $u \in L^{\infty}(\Pi_T); u(x,t) \in [0,1] \text{ for a.e. } (x,t) \in \Pi_T.$
- (D.2) For all test functions  $\phi \in \mathcal{D}(\mathbb{R} \times [0,T))$ ,

(3.1) 
$$\iint_{\Pi_x} \left( u\phi_t + \mathcal{F}(x, u)\phi_x \right) dx dt + \int_{\mathbb{R}} u_0(x)\phi(x, 0) dx = 0.$$

(D.3) For any test function  $0 \le \phi \in \mathcal{D}(\mathbb{R} \times [0,T))$  which vanishes for  $x \ge 0$ ,

(3.2) 
$$\iint_{\Pi_T} (|u - c|\phi_t + \operatorname{sgn}(u - c) (g(u) - g(c)) \phi_x) \, dx \, dt + \iint_{\mathbb{R}} |u_0 - c|\phi(x, 0) \, dx \ge 0 \quad \text{for all } c \in \mathbb{R},$$

and for any test function  $0 \le \phi \in \mathcal{D}(\mathbb{R} \times [0,T))$  which vanishes for  $x \le 0$ ,

(3.3) 
$$\iint_{\Pi_T} (|u - c|\phi_t + \operatorname{sgn}(u - c) (f(u) - f(c)) \phi_x) \, dx \, dt + \int_{\mathbb{R}} |u_0 - c|\phi(x, 0) \, dx \ge 0 \quad \text{for all } c \in \mathbb{R}.$$

(D.4) The following Kružkov-type entropy inequality holds for any test function  $0 \le \phi \in \mathcal{D}(\Pi_T)$ :

(3.4) 
$$\iint_{\Pi_T} \left\{ \left| u - c^{AB}(x) \right| \phi_t + \operatorname{sgn} \left( u - c^{AB}(x) \right) \left( \mathcal{F}(x, u) - \mathcal{F} \left( x, c^{AB}(x) \right) \right) \phi_x \right\} dx dt \ge 0.$$

A function  $u: \Pi_T \to \mathbb{R}$  satisfying conditions 3.1 and 3.1 is called a weak solution of the initial value problem (1.1).

Equation (3.1) is the weak formulation of the conservation law, and it implies the Rankine–Hugoniot condition (1.4). Conditions (3.2) and (3.3) guarantee that the solution is a Kružkov entropy solution of  $u_t + g(u)_x = 0$  in  $(-\infty, 0) \times [0, T)$  and of  $u_t + f(u)_x = 0$  in  $(0, \infty) \times [0, T)$ , respectively. Finally, inequality (3.4) ultimately gives us the (A, B)-characteristic condition (1.8); cf. (3.2) of Lemma 3.2 below.

LEMMA 3.1. Let u be an entropy solution of type (A, B) of (1.1). For a.e.  $t \in (0, T)$ , the function  $u(\cdot, t)$  has strong traces from the left and right at x = 0, i.e., the following limits exist for a.e.  $t \in (0, T)$ :

$$u(0^-,t) := \underset{x \uparrow 0}{\text{ess } \lim} u(x,t), \qquad u(0^+,t) := \underset{x \downarrow 0}{\text{ess } \lim} u(x,t).$$

Similarly, u has a strong trace at the initial hyperplane t = 0.

Proof. Condition (3.2) in Definition 3.1 guarantees that u is an entropy solution of the conservation law  $u_t + g(u)_x = 0$  in the domain  $(-\infty, 0) \times (0, T)$ . This observation, along with assumption (1.2) and a result in Panov [39] (see Vasseur [45] for a similar result, which however, asks for more regularity from the flux), ensure the existence of a strong trace from the left. The existence of a strong trace from the right follows in a similar way from (1.2) and (3.3). Finally, using Panov [38], the strong trace at the initial hyperplane t = 0 follows along the same lines (however, (1.2) is not needed for this result to hold; see [38]).

With the existence of strong traces guaranteed, it is possible to describe the behavior of solutions at x = 0 (where the interface is located).

LEMMA 3.2. Let  $u_{\pm} = u_{\pm}(t) = u(0^{\pm}, t)$ , where u is an entropy solution of type (A, B).

(J.1) The following Rankine–Hugoniot condition holds for a.e.  $t \in (0,T)$ :

(3.5) 
$$f(u_{+}(t)) = g(u_{-}(t)).$$

(J.2) The following entropy jump condition holds for a.e.  $t \in (0,T)$ : (3.6)  $\operatorname{sgn}(u_+(t) - B) \left( f(u_+(t)) - f(B) \right) - \operatorname{sgn}(u_-(t) - A) \left( g(u_-(t)) - g(A) \right) \leq 0.$ 

(J.3) For a.e.  $t \in (0,T)$ , the following characteristic condition is satisfied:

(3.7) 
$$\min\{0, g'(u_-(t))\} \max\{0, f'(u_+(t))\} = 0$$
 if  $(u_-(t), u_+(t)) \neq (A, B)$ .

Remark 3.1. Condition (3.7) is just the (A, B) characteristic condition (1.8). Reference [2] uses the entropy jump condition (3.6) as the defining entropy condition at the interface. We, instead, derive it from the Kružkov-type entropy inequality (3.4). The advantage of our approach is that we do not need the regularity assumption (that the solution is piecewise smooth) required in [2]. An additional benefit is that by the use of discrete versions of the entropy inequalities appearing in Definition 3.1, we are able to prove in a very straightforward manner that approximate solutions generated by our numerical scheme converge to entropy solutions.

Proof of Lemma 3.2. The Rankine–Hugoniot condition (3.5) is a consequence of the weak formulation (3.1), while the entropy jump condition (3.6) follows from (3.4). We omit the details of the proofs of these facts; they can be found (with slight modifications where necessary) in [27, Lemmas 2.4 and 2.6].

In what follows, we will suppress the dependence of the traces on t wherever there is no danger of confusion, i.e.,  $u_{\pm} := u_{\pm}(t)$ . To prove the characteristic condition

(3.7), it suffices to show that if  $(u_-, u_+) \neq (A, B)$ , then  $(u_-, u_+)$  cannot lie in  $\mathcal{I}$ , the inadmissible set defined by (1.9). First, by way of contradiction, suppose that

(3.8) 
$$g(u_{-}) = f(u_{+}) < g(A) = f(B), \text{ and } (u_{-}, u_{+}) \in \mathcal{I}.$$

From the entropy inequality (3.6), we have

$$(3.9) \qquad \operatorname{sgn}(u_{+} - B) \left( f(u_{+}) - f(B) \right) - \operatorname{sgn}(u_{-} - A) \left( g(u_{-}) - g(A) \right) \le 0.$$

At the same time, the conditions (3.8), along with the requirements (1.7) placed on the connection (A, B), mean that  $u_+ < B \le u_f^*$  and  $u_- > A \ge u_g^*$ . Using these relationships, we obtain from (3.9)  $(f(B) - f(u_+)) + (g(A) - g(u_-)) \le 0$ , which contradicts (3.8). Thus, (3.8) is impossible.

The proof of (3.7) will be complete if we can show that

(3.10) 
$$g(u_{-}) = f(u_{+}) > g(A) = f(B), \text{ and } (u_{-}, u_{+}) \in \mathcal{I}$$

is also impossible. From (3.10) and (1.7), we must have  $u_g^* \le u_- < A$  and  $B < u_+ \le u_f^*$ . Combining this with the entropy inequality (3.6) gives

$$(f(u_+) - f(B)) + (g(u_-) - g(A)) \le 0,$$

which contradicts (3.10) and completes the proof.

THEOREM 3.1 ( $L^1$  stability and uniqueness). Let u and v be two entropy solutions of type (A, B) in the sense of Definition 3.1 of the initial value problem (1.1) with initial data  $u_0, v_0 \in L^{\infty}(\mathbb{R}; [0, 1])$ . Denote by M the maximum of  $\max_{u \in [0, 1]} |f'(u)|$  and  $\max_{u \in [0, 1]} |g'(u)|$ . Then, for a.e.  $t \in (0, T)$ ,

(3.11) 
$$\int_{-r}^{r} |u(x,t) - v(x,t)| \ dx \le \int_{-r-Mt}^{r+Mt} |u_0(x) - v_0(x)| \ dx$$

In particular, there exists at most one entropy solution of type (A, B) of (1.1). Proof. Following [27], we can establish the inequality

$$(3.12) - \iint_{\Pi_T} (|u - v|\phi_t + \operatorname{sgn}(u - v) \left( \mathcal{F}(x, u) - \mathcal{F}(x, v) \right) \phi_x) dt dx \le E$$

for any  $0 \le \phi \in \mathcal{D}(\Pi_T)$ , where

$$E := \int_0^T \left[ \operatorname{sgn}(u - v) \left( \mathcal{F}(x, u) - \mathcal{F}(x, v) \right) \right]_{x=0-}^{x=0+} \phi(0, t) \, dt,$$

where the notation  $[\cdot]_{x=0^{-}}^{x=0^{+}}$  indicates the limit from the right minus the limit from the left at x=0. Recall that Lemma 3.1 ensures the existence of these limits. In what follows, we prove that  $E \leq 0$ . Taking this for granted, the  $L^1$  contraction property (3.11) is a standard consequence of (3.12).

For almost every  $t \in (0,T)$ , the contribution to E at the jump x=0 is

$$S := [\operatorname{sgn}(u - v) (\mathcal{F}(x, u) - \mathcal{F}(x, v))]_{x=0}^{x=0+}.$$

Let us fix  $t \in (0,T)$  and use the notation  $u_+(t) = u_+$ . Then

$$S = \operatorname{sgn}(u_{+} - v_{+}) \left( f(u_{+}) - f(v_{+}) \right) - \operatorname{sgn}(u_{-} - v_{-}) \left( g(u_{-}) - g(v_{-}) \right).$$

We now show that  $S \leq 0$ , which implies that  $E \leq 0$  holds since t is arbitrary.

If either  $(u_-, u_+) = (A, B)$  or  $(v_-, v_+) = (A, B)$ , then  $S \leq 0$  immediately follows from the entropy inequality (3.6). So, for the remainder of the proof, we will assume  $(u_-, u_+) \neq (A, B)$  and  $(v_-, v_+) \neq (A, B)$ .

Next, in the situation where  $u_{+}=v_{+}$  and  $u_{-}=v_{-}$ , it is clear that S=0. Suppose now that only one of  $u_+ = v_+$ ,  $u_- = v_-$  holds, say,  $u_+ = v_+$ . In that case,  $S = -\operatorname{sgn}(u_- - v_-)(g(u_-) - g(v_-)),$  and the quantity on the right vanishes due to the Rankine-Hugoniot condition. Now assume that  $u_+ \neq v_+, u_- \neq v_-$ . If  $\operatorname{sgn}(u_+ - v_+) =$  $\operatorname{sgn}(u_- - v_-)$ , another application of the Rankine-Hugoniot condition gives S = 0. So, let us assume that  $u_+ \neq v_+$ ,  $u_- \neq v_-$ , and  $\operatorname{sgn}(u_+ - v_+) \neq \operatorname{sgn}(u_- - v_-)$ . Without loss of generality, take  $u_- > v_-$ ,  $u_+ < v_+$ . Then the Rankine-Hugoniot condition gives two equivalent expressions for S:

$$S = 2 (g(v_{-}) - g(u_{-})) = 2 (f(v_{+}) - f(u_{+})).$$

Also, in view of (3.7), the characteristic condition holds for both u and v:

$$(3.13) \quad \min\{0, g'(u_-)\} \max\{0, f'(u_+)\} = 0, \quad \min\{0, g'(v_-)\} \max\{0, f'(v_+)\} = 0.$$

With the assumption that  $u_- > v_-$ ,  $u_+ < v_+$ , it is easy to check that either  $u_{+} \leq v_{-} < u_{-} \text{ or } v_{+} > u_{+} \geq v_{-} \text{ must hold.}$ 

Case I. Assume that  $u_+ \leq v_- < u_-$ . With  $u_+ < u_-$ , the Rankine-Hugoniot condition along with the characteristic condition (3.13) implies that either  $u_{+} \leq u_{\rm R}^{\#}$ and  $u_{-} \leq u_{\rm L}^{\#}$ , or  $u_{+} \geq u_{\rm R}^{\#}$  and  $u_{-} \geq u_{\rm L}^{\#}$ . If  $u_{+} \leq u_{\rm R}^{\#}$  and  $u_{-} \leq u_{\rm L}^{\#}$ , then g is increasing on  $(0, u_{-})$ . Since  $v_{-} < u_{-}$ , we have  $g(v_{-}) < g(u_{-})$ , which implies  $S \leq 0$ . If  $u_+ \geq u_{\rm R}^{\#}$  and  $u_- \geq u_{\rm L}^{\#}$ , then g is decreasing on  $(0, u_-)$ . Since  $v_+ > u_+$ , we have  $f(v_+) < f(u_+)$ , which again implies  $S \leq 0$ .

Case II. Assume that  $v_+ > u_+ \ge v_-$ . With  $v_- < v_+$ , the Rankine-Hugoniot

condition along with the characteristic condition (3.13) implies that either  $v_- \leq u_L^\#$  and  $v_+ \geq u_R^\#$ , or  $v_- \geq u_L^\#$  and  $v_+ \geq u_R^\#$ .

Case IIA. If  $v_- \leq u_L^\#$  and  $v_+ \geq u_R^\#$ , then g is increasing on  $(0, v_-)$  and f is increasing on  $(v_+, 1)$ . If  $u_+ \in [u_R^\#, v_+)$ , then  $f(u_+) > f(v_+)$ , implying that  $S \leq 0$ . If  $u_+ \in [0, u_R^\#]$ , then  $u_- \in [0, u_L^\#]$ . Since  $v_- < u_-$ , this means that also  $u_- \in [0, u_L^\#]$ ,

and so  $g(u_{-}) > g(v_{-})$ , implying that  $S \leq 0$ . Case IIB. If  $v_{-} \geq u_{\rm L}^{\#}$  and  $v_{+} \geq u_{\rm R}^{\#}$ , then we also have  $u_{-} \geq u_{\rm L}^{\#}$ . The characteristic condition (3.13) then requires  $u_{+} \geq u_{\rm R}^{\#}$ . We have  $u_{\rm R}^{\#} \leq u_{+} \leq v_{+}$ . Thus,  $f(u_{+}) \geq f(u_{+})$  again implying that  $S \leq 0$ .  $f(v_+)$ , again implying that  $S \leq 0$ .

Remark 3.2. The quantity S appearing in the proof of Theorem 3.1 is the negative of the quantity  $I_{AB}(u,v)$  of reference [2]. Indeed, in the case where the fluxes f and g cross in an undercompressive manner (plots B and D of Figure 1.1), we could have invoked Lemma 2.2 of [2] to establish that  $S \leq 0$ .

4. The numerical scheme. We discretize the spatial domain  $\mathbb R$  into the cells  $I_{j+1/2} := [x_j, x_{j+1}), x_j = j\Delta x, j \in \mathbb{Z}.$  The centers of these cells are  $x_{j+1/2} =$  $(j+1/2)\Delta x$ . The time interval (0,T) is discretized via  $t^n=n\Delta t$  for  $n=0,\ldots,N$ , where  $N = |T/\Delta t| + 1$ , which yields the time strips  $I^n := [t^n, t^{n+1}), n = 0, \dots, N-1$ . Here  $\Delta x > 0$  and  $\Delta t > 0$  denote the spatial and temporal discretization parameters, respectively. When sending  $\Delta \to 0$ , we will keep  $\lambda := \Delta t/\Delta x$  constant. Let  $\chi_{j+1/2}^n(x,t)$  be the characteristic function for  $R_{j+1/2}^n:=I_{j+1/2}\times I^n$ . We denote by  $U_i^n$  the finite-difference approximation of  $u(x_{j+1/2},t^n)$ . We discretize the initial data by cell averages:

$$U_j^0 := \frac{1}{\Delta x} \int_{I_{j+1/2}} u_0(x) \, dx.$$

We then define

(4.1) 
$$u^{\Delta}(x,t) := \sum_{n\geq 0} \sum_{j\in\mathbb{Z}} U_j^n \chi_{j+1/2}^n(x,t).$$

Our difference scheme is an explicit time-marching algorithm of the type

(4.2) 
$$U_{i}^{n+1} = U_{i}^{n} - \lambda \Delta_{+} \bar{\mathcal{F}}_{i-1/2}^{n},$$

where  $\Delta_{\pm}V_j := \pm (V_{j\pm 1} - V_j)$  are spatial difference operators and the numerical flux has the form

(4.3) 
$$\bar{\mathcal{F}}_{j-1/2}^{n} = \bar{\mathcal{F}}_{j-1/2}^{n} \left( U_{j}^{n}, U_{j-1}^{n} \right) = \begin{cases} \bar{g} \left( U_{j}^{n}, U_{j-1}^{n} \right) =: \bar{g}_{j-1/2}^{n} & \text{for } j < 0, \\ h \left( U_{0}^{n}, U_{-1}^{n} \right) =: h^{n} & \text{for } j = 0, \\ \bar{f} \left( U_{j}^{n}, U_{j-1}^{n} \right) =: \bar{f}_{j-1/2}^{n} & \text{for } j > 0. \end{cases}$$

For the numerical fluxes  $\bar{f}$  and  $\bar{g}$  that apply away from the interface, we use the EO flux [19]

(4.4) 
$$\bar{f}(v,u) = \frac{1}{2} (f(v) + f(u)) - \frac{1}{2} \int_{u}^{v} |f'(w)| \ dw,$$
$$\bar{g}(v,u) = \frac{1}{2} (g(v) + g(u)) - \frac{1}{2} \int_{u}^{v} |g'(w)| \ dw.$$

To define the interface flux  $h(U_0^n, U_{-1}^n)$ , we fix a time level, say, n and set  $u_L = U_{-1}^n$ ,  $u_R = U_0^n$ . For a scalar conservation law  $u_t + q(u)_x = 0$ , the EO flux is given by (1.13). If  $u_M$  is any conveniently selected value for u, we could write (1.13) as

$$h^{\rm EO}(u_{\rm R},u_{\rm L}) = \frac{1}{2} \left( q(u_{\rm R}) + q(u_{\rm L}) \right) - \frac{1}{2} \left[ \int_{u_{\rm M}}^{u_{\rm R}} |q'(w)| \ dw - \int_{u_{\rm M}}^{u_{\rm L}} |q'(w)| \ dw \right].$$

Now let (A, B) be a connection. We modify the EO numerical flux to capture the solution associated with this connection by generalizing this formula as follows:

$$h^{AB}(u_{R}, u_{L}) = \frac{1}{2} \left( \tilde{f}(u_{R}) + \tilde{g}(u_{L}) \right) - \frac{1}{2} \left[ \int_{B}^{u_{R}} \left| \tilde{f}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw \right],$$

$$(4.5) \quad \tilde{f}(u) := \min \left\{ f(u), f(B) \right\}, \quad \tilde{g}(u) = \min \left\{ g(u), g(A) \right\},$$

$$\tilde{f}'(u) := \int_{B}^{u_{L}} \left| \tilde{f}(u) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{L}} \left| \tilde{g}'(w) \right| dw - \int_{A}^{u_{$$

$$\tilde{f}'(u) := \begin{cases} 0 & \text{if } f(u) \ge f(B), \\ f'(u) & \text{if } f(u) < f(B), \end{cases} \quad \tilde{g}'(u) := \begin{cases} 0 & \text{if } g(u) \ge g(A), \\ g'(u) & \text{if } g(u) < g(A). \end{cases}$$

Formula (4.5) is at the core of this paper. In fact, taking  $h = h^{AB}$  in (4.3) defines the numerical flux for an entropy solution of type (A, B). We have defined an entire class of schemes, one for each connection (A, B). When it is necessary to emphasize the dependence on (A, B), we refer to the (A, B)-version of the scheme.

Note that since  $f, g \in \text{Lip}([0,1])$ , it is clear from (4.4) and (4.5) that each of the numerical fluxes is also Lipschitz continuous:  $\bar{f}, \bar{g}, h^{AB} \in \text{Lip}([0,1] \times [0,1])$ .

An essential aspect of our scheme (4.2) is that it preserves, in addition to the constants 0 and 1, the (discrete) steady-state solution connecting A to B.

LEMMA 4.1 (stationary solutions). The sequences  $v = \{v_j\}_{j \in \mathbb{Z}}$  defined by  $v_j := 0$  for all  $j \in \mathbb{Z}$ ,  $v_j := 1$  for all  $j \in \mathbb{Z}$ , or

(4.6) 
$$v_j := \begin{cases} A & \text{for } j < 0, \\ B & \text{for } j \ge 0, \end{cases} \text{ for all } j \in \mathbb{Z},$$

are all solutions of the scheme (4.2).

*Proof.* By using  $\tilde{f}$  and  $\tilde{g}$  (rather than f and g), we have  $h^{AB}(0,0)=0$  and  $h^{AB}(1,1)=0$  such that the scheme preserves the steady-state solutions v=0 and v=1. Moreover, since

(4.7) 
$$h^{AB}(B,A) = g(A) = f(B),$$

the scheme preserves the steady-state solution v connecting A to B; cf. (4.6). More precisely, recalling that  $U_j^{n+1}$  depends on the values at the three neighboring cells at the lower time level, we write the marching formula (4.2) as

(4.8) 
$$U_{i}^{n+1} = \Gamma_{j} \left( U_{j+1}^{n}, U_{j}^{n}, U_{j-1}^{n} \right).$$

Away from the interface, i.e.,  $j \neq 0, -1$ , it is clear that  $\Gamma_j(v_{j+1}, v_j, v_{j-1}) = v_j$ , since we are dealing with a standard three-point scheme in that case. Since

$$h^{AB}(v_0, v_{-1}) = h^{AB}(B, A) = g(A) = f(B),$$

we also have  $\Gamma_j(v_{j+1}, v_j, v_{j-1}) = v_j$  for j = 0, -1.

Remark 4.1. We can recast our scheme (4.2) into an equivalent form revealing the specific form of the numerical viscosity [42]. To this end, we organize (4.2) as

(4.9) 
$$\frac{U_j^{n+1} - U_j^n}{\Delta t} + D_0 \mathcal{F}(x_j, U_j^n) = \frac{\Delta x}{2\lambda} D_+ \left( Q_{j-1/2}^n D_- U_j^n \right),$$

where  $D_{\pm}V_j = \Delta_{\pm}V_j/\Delta x$ ,  $D_0V_j = (V_{j+1} - V_{j-1})/(2\Delta x)$  and the numerical viscosity coefficient  $Q_{j-1/2}^n$ . If we have  $\Delta_-U_j^n \neq 0$ , then this coefficient is given by

$$Q_{j-1/2}^{n} = \frac{\lambda}{\Delta_{-}U_{j}^{n}} \left( \mathcal{F}\left(x_{j-1}, U_{j-1}^{n}\right) + \mathcal{F}\left(x_{j}, U_{j}^{n}\right) - 2\bar{\mathcal{F}}_{j-1/2}^{n} \left(U_{j}^{n}, U_{j-1}^{n}\right) \right)$$

and takes the distinct form

$$Q_{j-1/2}^n = \begin{cases} \frac{\lambda}{U_j^n - U_{j-1}^n} \int_{U_{j-1}^n}^{U_j^n} |g'(w)| \ dw & \text{if } j < 0, \\ \\ \lambda \frac{g(U_{-1}^n) - \tilde{g}(U_{-1}^n) + f(U_0^n) - \tilde{f}(U_0^n)}{U_0^n - U_{-1}^n} \\ + \frac{\lambda}{U_0^n - U_{-1}^n} \left[ \int_B^{U_0^n} \left| \tilde{f}'(w) \right| \ dw - \int_A^{U_{-1}^n} |\tilde{g}'(w)| \ dw \right] \end{cases} \quad \text{if } j = 0,$$

$$\frac{\lambda}{U_j^n - U_{j-1}^n} \int_{U_{j-1}^n}^{U_j^n} |f'(w)| \ dw \qquad \text{if } j > 0.$$

Note that the viscosity at the interface  $Q_{-1/2}^n$  vanishes if  $U_{-1}^n = A$ ,  $U_0^n = B$ , i.e.,  $h^{AB}(B,A) = g(A) = f(B)$ . It is this lack of viscosity (along with the fact that g(A) = f(B)) that permits a steady jump from  $u_{-} = A$  to  $u_{+} = B$  at the interface.

Furthermore, considering the limit  $\Delta_- U_j^n \to 0$ , we may formally assign the finite values  $|g'(U_j^n)|$  and  $|f'(U_j^n)|$  to  $Q_{j-1/2}^n$  for  $\Delta_- U_j^n = 0$  and j < 0 and j > 0, respectively.

By inserting the function (4.6) into the viscous form (4.9), we now obtain an alternative way to easily see that this function is a steady-state solution.

In general, however, the quantity  $Q_{-1/2}^n$  will become unbounded as  $\Delta_- U_0^n \to 0$ . This aspect is relevant, for example, when we start from a globally constant initial datum  $u_0$  which is not an (A,B)-type entropy solution, but for which  $f(u_0)=g(u_0)$  holds. We then have that the difference  $D_0\mathcal{F}(x_j,U_j^n)$  in the left-hand side of (4.9) vanishes for all  $j\in\mathbb{Z}$ , but at the same time expect that the numerical solution leaves constancy. This is only possible if the right-hand side may take values differing from zero even if all increments  $D_-U_j^n$  are zero, i.e., if we admit that  $Q_{-1/2}^n$  becomes unbounded (but  $Q_{-1/2}^n\Delta_-U_0^n$  remains bounded as  $\Delta_-U_0^n\to 0$ ). Examples 1 and 2 in section 6 illustrate this case.

The numerical flux  $h^{AB}$  has the following important property.

LEMMA 4.2. If the pair (A, B) is a connection in the sense of Definition 1.3, then the flux  $h^{AB}$  defined by (4.5) is monotone, i.e.,  $u_R \mapsto h^{AB}(u_R, u_L)$  is nonincreasing for  $u_R \in [0, 1]$  and  $u_L \mapsto h^{AB}(u_R, u_L)$  is nondecreasing for  $u_L \in [0, 1]$ .

*Proof.* Since  $h^{AB} \in \text{Lip}([0,1] \times [0,1])$ , it suffices to check that  $\partial_{u_R} h^{AB}(u_R, u_L) \leq 0$  a.e. and that  $\partial_{u_L} h^{AB}(u_R, u_L) \geq 0$  a.e. However, the inequalities

$$(4.10) \frac{\partial h^{AB}}{\partial u_{\rm L}}(u_{\rm R}, u_{\rm L}) = \max\left\{0, \tilde{g}'(u_{\rm L})\right\} \ge 0, \quad \frac{\partial h^{AB}}{\partial u_{\rm R}}(u_{\rm R}, u_{\rm L}) = \min\left\{0, \tilde{f}'(u_{\rm R})\right\} \le 0$$

5. Analysis of the scheme and convergence. We now establish assorted stability properties of the finite difference scheme and prove that it converges to an entropy solution of type (A, B) as the grid size tends to zero. We suppress dependence on the connection (A, B) to simplify notation, but we emphasize that we are discussing an entire class of schemes, one for each connection (A, B). In addition to (1.3), for the convergence analysis—but not in the statement of the main result, Theorem 5.1—we assume  $u_0 \in BV(\mathbb{R})$ . Thanks to Theorem 3.1, there is no loss of generality in doing so. For simplicity, we assume, moreover, that  $u_0$  is compactly supported, which implies that all subsequent sums over j are finite. To obtain results in the general case, we can again use Theorem 3.1 (these details, however, will not be written out).

In what follows we will assume that the discretization parameters  $\Delta := (\Delta x, \Delta t)$  are chosen so that the following CFL condition holds:

(5.1) 
$$\lambda \max_{u \in [0,1]} |f'(u)| \le 1, \quad \lambda \max_{u \in [0,1]} |g'(u)| \le 1.$$

are readily verified from (4.5).

LEMMA 5.1. The computed solution  $U_j^n$  belongs to the interval [0,1]. Moreover, the difference scheme (4.2) is monotone.

*Proof.* We must show that  $U_j^{n+1}$  is nondecreasing with respect to each of the variables  $U_{j+1}^n$ ,  $U_j^n$ , and  $U_{j-1}^n$ . Since each of the numerical fluxes is a Lipschitz continuous function of its two arguments,  $U_j^{n+1}$  is also a Lipschitz continuous function of  $(U_{j+1}^n, U_j^n, U_{j-1}^n)$ , and so we can use partial derivatives, which exist a.e., for this analysis. For j > 0 or j < -1, the interface flux is not involved, and the calculation is standard. Let us focus on j = 0 for now. According to (4.3),

$$U_0^{n+1} = U_0^n - \lambda \left( \bar{f}(U_1^n, U_0^n) - h^{AB}(U_0^n, U_{-1}^n) \right).$$

The partial derivatives of  $U_0^{n+1}$  with respect to  $U_{-1}^n$  and  $U_1^n$  satisfy

$$\frac{\partial U_0^{n+1}}{\partial U_1^n} = -\lambda \frac{\partial \bar{f}}{\partial U_1^n}(U_1^n, U_0^n), \quad \frac{\partial U_0^{n+1}}{\partial U_{-1}^n} = \lambda \frac{\partial h^{AB}}{\partial U_{-1}^n}(U_0^n, U_{-1}^n).$$

The first of these partial derivatives is nonnegative; this is due to the monotonicity of the EO flux. The second partial derivative is nonnegative due to (4.10). For the partial derivative with respect to  $U_0^n$ , we use (4.10), (4.4) to compute

$$\begin{split} \frac{\partial U_0^{n+1}}{\partial U_0^n} &= 1 - \lambda \frac{\partial \bar{f}}{\partial U_0^n}(U_1^n, U_0^n) + \lambda \frac{\partial h^{AB}}{\partial U_0^n}(U_0^n, U_{-1}^n) \\ &= 1 - \lambda \max\left\{0, f'(U_0^n)\right\} + \lambda \min\left\{0, \tilde{f}'(U_0^n)\right\} \geq 1 - \lambda \left|f'(U_0^n)\right|. \end{split}$$

When j = -1, a similar calculation leads to the inequality

$$\frac{\partial U_{-1}^{n+1}}{\partial U_{-1}^n} \ge 1 - \lambda \left| g'(U_{-1}^n) \right|,$$

and the CFL condition again guarantees that the right side is nonnegative. Thus, if we have  $U_j^n \in [0,1]$  for all  $j \in \mathbb{Z}$  at the fixed time level  $t_n$ , the CFL condition (5.1) is satisfied, and it follows that  $U_j^{n+1}$  is a nondecreasing function of the conserved variables at the lower time level.

Now consider the initial data  $V_j^0 \equiv 0$ ,  $W_j^0 \equiv 1$ . As a result of Lemma 4.1, after one time step, we have  $V_j^1 \equiv 0$ ,  $W_j^1 \equiv 1$ . Now take any initial data  $U^0$  with  $U_j^0 \in [0,1]$  for all j. The CFL condition is satisfied, which guarantees monotonicity, and therefore,  $0 \leq V_j^1 \leq U_j^1 \leq W_j^1 \leq 1$  for all j. Continuing this way by induction, we obtain  $0 \leq V_i^n \leq U_j^n \leq W_j^n \leq 1$  for all j. This completes the proof.  $\square$ 

The following lemma provides a discrete time continuity estimate.

LEMMA 5.2. Let  $TV(u_0)$  denote the total variation of  $u_0$ . There exists a constant C, depending on  $TV(u_0)$ , but independent of  $\Delta$  and n, such that

$$\Delta x \sum_{j \in \mathbb{Z}} \left| U_j^{n+1} - U_j^n \right| \le \Delta x \sum_{j \in \mathbb{Z}} \left| U_j^1 - U_j^0 \right| \le C \Delta t.$$

*Proof.* Due to our assumptions about the initial data  $u_0(x)$  and our method of discretizing it to produce  $U_i^0$ , it is clear that

$$0 \le \Delta x \sum_{j \in \mathbb{Z}} U_j^0 \le \beta,$$

where  $\beta < \infty$ . Since the scheme is conservative and  $U_i^n \geq 0$ , we have

$$\Delta x \sum_{j \in \mathbb{Z}} \left| U_j^1 \right| = \Delta x \sum_{j \in \mathbb{Z}} U_j^1 = \Delta x \sum_{j \in \mathbb{Z}} U_j^0 \le \beta.$$

Continuing this way, it is clear that

$$\Delta x \sum_{j \in \mathbb{Z}} \left| U_j^n \right| \le \beta.$$

This  $L^1$  bound, along with the fact that the scheme is monotone and conservative, allows us to apply the Crandall–Tartar lemma [16]:

$$\sum_{j \in \mathbb{Z}} \left| U_j^{n+1} - U_j^n \right| \le \sum_{j \in \mathbb{Z}} \left| U_j^n - U_j^{n-1} \right|.$$

Applying this inequality repeatedly, we arrive at

$$\sum_{j\in\mathbb{Z}}\left|U_{j}^{n+1}-U_{j}^{n}\right|\leq\sum_{j\in\mathbb{Z}}\left|U_{j}^{1}-U_{j}^{0}\right|=\lambda\sum_{j\in\mathbb{Z}}\left|\Delta_{+}\bar{\mathcal{F}}_{j-1/2}^{0}\right|,$$

where we note that

$$\sum_{j \in \mathbb{Z}} \left| \Delta_{+} \bar{\mathcal{F}}_{j-1/2}^{0} \right| = \sum_{j < -1} \left| \Delta_{+} \bar{g}_{j-1/2}^{0} \right| + \left| \bar{f}_{1/2}^{0} - h^{0} \right| + \left| h^{0} - \bar{g}_{-3/2}^{0} \right| + \sum_{j > 1} \left| \Delta_{+} \bar{f}_{j-1/2}^{0} \right|.$$

It is straightforward to estimate

$$\sum_{j < -1} \left| \Delta_{+} \bar{g}_{j-1/2}^{0} \right| \leq 2 \max_{u \in [0,1]} |g'(u)| \operatorname{TV}(u_{0}), \quad \sum_{j > 1} \left| \Delta_{+} \bar{f}_{j-1/2}^{0} \right| \leq 2 \max_{u \in [0,1]} |f'(u)| \operatorname{TV}(u_{0}).$$

Combining these estimates with the observation that  $|\bar{f}_{1/2}^0 - h^0|$  and  $|h^0 - \bar{g}_{-3/2}^0|$  are bounded independently of the mesh size  $\Delta$ , completes the proof.

In order to establish compactness, we a need a spatial variation bound, which is provided by the following lemmas. Let  $V_a^b(z)$  denote the total variation of the function  $x \mapsto z(x)$  over the interval [a, b]. The following lemma is essentially Lemma 4.2 of [7], where a proof can be found.

LEMMA 5.3. Let  $\{\xi_1, \ldots, \xi_M\}$  be a finite set of real numbers. Suppose that  $U_j^n$  is generated by an algorithm which can be written in incremental form

$$(5.2) U_j^{n+1} = U_j^n + C_{j+1/2}^n \Delta_+ U_j^n - D_{j-1/2}^n \Delta_- U_j^n,$$

except at finitely many indices j such that  $|x_j - \xi_m| \le \rho \Delta x$  for some m = 1, ..., M, where  $\rho > 0$ . Assume that the incremental coefficients satisfy

(5.3) 
$$C_{j+1/2}^n \ge 0, \quad D_{j+1/2}^n \ge 0, \quad C_{j+1/2}^n + D_{j+1/2}^n \le 1.$$

Finally, assume that the approximations  $U_j^n$  satisfy a time-continuity estimate of the form given in Lemma 5.2. Then for any interval [a,b] such that  $\{\xi_1,\ldots,\xi_M\}\cap[a,b]=\emptyset$ , and any  $t\in[0,T]$ , we have a spatial variation bound of the form

(5.4) 
$$V_a^b\left(u^\Delta(\cdot,t)\right) \le C(a,b),$$

where C(a,b) is independent of  $\Delta$  and t for  $t \in [0,T]$ .

LEMMA 5.4. For any interval [a,b] such that  $0 \notin [a,b]$ , and any  $t \in [0,T]$ , we have a spatial variation bound of the form (5.4), where C(a,b) is independent of  $\Delta$  and t for  $t \in [0,T]$ .

*Proof.* Lemma 5.3 applies here if we can verify that away from the interface at x=0 (i.e., the interface flux  $h^n$  is not involved, or equivalently,  $j \neq -1, 0$ ), we can write the scheme in the incremental form (5.2) and that the inequalities (5.3) are satisfied. To this end, note that for  $j \neq -1, 0$ , the scheme has the form

(5.5) 
$$U_j^{n+1} = U_j^n - \lambda \Delta_{-\bar{p}} \left( U_{j+1}^n, U_j^n \right).$$

Here,  $\bar{p}$  denotes either  $\bar{f}$  or  $\bar{g}$ , depending on which side of the interface we are on. Similarly, we use the symbol p to denote the flux f or g. The scheme (5.5) can be written in the incremental form (5.2), with coefficients defined by

$$C^n_{j+1/2} = \lambda \frac{p(U^n_j) - \bar{p}(U^n_{j+1}, U^n_j)}{\Delta_+ U^n_j}, \quad D^n_{j-1/2} = \lambda \frac{p(U^n_j) - \bar{p}(U^n_j, U^n_{j-1})}{\Delta_- U^n_j}.$$

The inequalities (5.3) are satisfied due to the monotonicity of the numerical flux  $\bar{p}$  and the CFL condition (5.1).  $\Box$ 

If the interface flux is not involved, the discrete entropy inequalities

(5.6) 
$$\begin{aligned} |U_{j}^{n+1} - c| &\leq |U_{j}^{n} - c| - \lambda \Delta_{-} \bar{F}_{j+1/2}^{n} & \text{for } j \geq 1, \\ |U_{j}^{n+1} - c| &\leq |U_{j}^{n} - c| - \lambda \Delta_{-} \bar{G}_{j+1/2}^{n} & \text{for } j < -1 \end{aligned}$$

hold for any  $c \in \mathbb{R}$ . Here  $\bar{F}_{j+1/2}^n$  and  $\bar{G}_{j+1/2}^n$  are discrete entropy fluxes defined by

$$(5.7) \bar{Q}_{j+1/2}^n := \bar{q}\left(U_{j+1}^n \vee c, U_j^n \vee c\right) - \bar{q}\left(U_{j+1}^n \wedge c, U_j^n \wedge c\right),$$

where  $\bar{Q}$  denotes either  $\bar{F}$  or  $\bar{G}$  and correspondingly,  $\bar{q}$  denotes either  $\bar{f}$  or  $\bar{g}$ . The entropy inequalities (5.6) with the discrete entropy flux (5.7) can be found in [15]. We discretize the function  $c^{AB}(x)$  defined in (1.11) by

(5.8) 
$$c_j = \begin{cases} A & \text{for } j < 0, \\ B & \text{for } j \ge 0. \end{cases}$$

In addition to the two standard discrete entropy inequalities above, we have the following one, which is a sort of discrete adapted entropy inequality.

LEMMA 5.5. With  $c_j$  defined by (5.8), the following cell entropy inequality is satisfied by approximate solutions  $U_j^n$  generated by the scheme (4.2):

$$(5.9) |U_{j}^{n+1} - c_{j}| \le |U_{j}^{n} - c_{j}| - \lambda \Delta_{-} \mathcal{H}_{j+1/2}^{n},$$

where the numerical entropy flux  $\mathcal{H}_{j-1/2}^n$  is defined by

$$\begin{split} \mathcal{H}^{n}_{j-1/2} &= \mathcal{F}_{j-1/2} \left( U^{n}_{j} \vee c_{j}, U^{n}_{j-1} \vee c_{j-1} \right) - \mathcal{F}_{j-1/2} \left( U^{n}_{j} \wedge c_{j}, U^{n}_{j-1} \wedge c_{j-1} \right) \\ &= \begin{cases} \bar{g} \left( U^{n}_{j} \vee A, U^{n}_{j-1} \vee A \right) - \bar{g} \left( U^{n}_{j} \wedge A, U^{n}_{j-1} \wedge A \right) & \text{for } j < 0, \\ h \left( U^{n}_{0} \vee B, U^{n}_{-1} \vee A \right) - h \left( U^{n}_{0} \wedge B, U^{n}_{-1} \wedge A \right) & \text{for } j = 0, \\ \bar{f} \left( U^{n}_{j} \vee B, U^{n}_{j-1} \vee B \right) - \bar{f} \left( U^{n}_{j} \wedge B, U^{n}_{j-1} \wedge B \right) & \text{for } j > 0. \end{cases} \end{split}$$

*Proof.* We adapt the proof in [15] to the situation at hand. According to Lemma 5.1,  $\Gamma_j$ , cf. (4.8), is a nondecreasing function of each of its three arguments, implying

$$(5.10) U_j^{n+1} \vee \Gamma_j(c_{j+1}, c_j, c_{j-1}) \leq \Gamma_j \left( U_{j+1}^n \vee c_{j+1}, U_j^n \vee c_j, U_{j-1}^n \vee c_{j-1} \right),$$

$$(5.11) U_j^{n+1} \wedge \Gamma_j(c_{j+1}, c_j, c_{j-1}) \ge \Gamma_j \left( U_{j+1}^n \wedge c_{j+1}, U_j^n \wedge c_j, U_{j-1}^n \wedge c_{j-1} \right).$$

Subtracting (5.11) from (5.10) and using the identity  $\rho \vee \sigma - \rho \wedge \sigma = |\rho - \sigma|$  yields

$$(5.12) \qquad |U_{j}^{n+1} - \Gamma_{j}(c_{j+1}, c_{j}, c_{j-1})| \leq \Gamma_{j} \left( U_{j+1}^{n} \vee c_{j+1}, U_{j}^{n} \vee c_{j}, U_{j-1}^{n} \vee c_{j-1} \right) \\ - \Gamma_{j} \left( U_{j+1}^{n} \wedge c_{j+1}, U_{j}^{n} \wedge c_{j}, U_{j-1}^{n} \wedge c_{j-1} \right).$$

Lemma 4.1 implies that the left side of (5.12) simplifies to  $|U_j^{n+1} - c_j|$ . One can check from the definitions that the right side of (5.12) agrees with that of (5.9).

We can now state and prove our main theorem.

THEOREM 5.1 (convergence and existence). Suppose (1.2) and (1.3) hold. Let (A, B) be a connection, and  $u^{\Delta}$  be defined by (4.1) and the (A, B)-version of the scheme (4.2)–(4.5). Let  $\Delta \to 0$ , with  $\lambda = \Delta x/\Delta t$  constant and the CFL condition

(5.1) satisfied. Then there exists a function u such that  $u^{\Delta} \to u$  in  $L^1_{loc}(\Pi_T)$  and a.e. in  $\Pi_T$ . The limit function u is an entropy solution of type (A, B) of the conservation law (1.1). In particular, there exists a (unique) entropy solution of type (A, B) in the sense of Definition 3.1 to the initial value problem (1.1).

Proof. We prove this theorem under the assumption that  $u_0 \in BV(\mathbb{R})$ . The general case (1.3) then follows (as usual) from the  $L^1$  contraction property (Theorem 3.1). For our approximate solutions  $u^{\Delta}$ , we have an  $L^{\infty}$  bound (Lemma 5.1), a time continuity bound (Lemma 5.2), and a bound on the spatial variation in any interval [a, b] not containing the origin. By standard compactness results, for any fixed interval [a, b] not containing x = 0, there is a subsequence (which we do not bother to relabel) such that  $u^{\Delta}$  converges in  $L^1([a, b] \times [0, T])$ . Taking a countable set of intervals  $[a_i, b_i]$  such that  $\bigcup_i [a_i, b_i] = \mathbb{R} \setminus \{0\}$  and employing a standard diagonal process, we can extract a subsequence (which we again do not relabel) such that  $u^{\Delta}$  converges in  $L^1_{\text{loc}}(\Pi_T)$  and also a.e. in  $\Pi_T$  to some  $u \in L^{\infty}(\Pi_T)$ , with  $u(x, t) \in [0, 1]$  for a.e. (x, t). Thus, the limit u satisfies (3.1) of Definition 3.1.

Although not required from Definition 3.1, let us add that it follows from the time continuity estimate (5.2) that  $u \in C(0,T;L^1(\mathbb{R}))$ . Additionally, the initial data  $u_0$  is taken by u in the strong  $L^1_{loc}$  sense.

Our goal now is to show that the limit function u satisfies the remaining parts of Definition 3.1. The entropy inequalities (3.2) and (3.3) follow from standard Lax–Wendroff-type calculations applied to (5.6), since the discontinuity at x=0 is not involved. For the weak formulation (3.1), another Lax–Wendroff-type calculation will suffice. This time the jump at x=0 is involved, but the proof is only slightly more complicated; see the proof of Theorem 3.1 of [25].

We now turn our attention to the entropy inequality (3.4). Since, as pointed out above,  $u(t) \to u_0$  in  $L^1_{loc}(\mathbb{R})$  as  $t \to 0$ , it is sufficient to work with nonnegative test functions  $\phi$  from  $\mathcal{D}(\Pi_T)$  so that, in particular,  $\phi|_{t=0} \equiv 0$ . Set  $\phi_j^n = \phi(x_j, t^n)$ . Proceeding as in the proof of the Lax-Wendroff theorem, we move all of the terms in (5.9) to the left side of the inequality, multiply by  $\phi_j^n \Delta x$ , and sum over  $j \in \mathbb{Z}$ ,  $n \geq 0$ , and finally sum by parts to get

$$\Delta x \Delta t \sum_{j \in \mathbb{Z}} \sum_{n \ge 0} \left| U_j^{n+1} - c_j \right| \frac{\phi_j^{n+1} - \phi_j^n}{\Delta t} + \Delta x \Delta t \sum_{j \in \mathbb{Z}} \sum_{n \ge 0} \mathcal{H}_{j+1/2}^n \frac{\Delta_+ \phi_j^n}{\Delta x} \ge 0.$$

By the dominated convergence theorem, the first sum converges to

$$\iint_{\Pi_T} \left| u - c^{AB}(x) \right| \phi_t \, dx \, dt.$$

For the second sum, note that the interface flux is only involved on a set whose measure will approach zero when we let  $\Delta \to 0$ . Thus, we can ignore the interface contribution and consider separately the contribution for  $x_j$  to the left of the interface, where the discrete entropy flux will be

$$\bar{g}\left(U_{j}^{n}\vee A,U_{j-1}^{n}\vee A\right)-\bar{g}\left(U_{j}^{n}\wedge A,U_{j-1}^{n}\wedge A\right),$$

and the contribution for  $x_j$  to the right of the interface, where the discrete entropy flux will be

$$\bar{f}\left(U_{j}^{n}\vee B,U_{j-1}^{n}\vee B\right)-\bar{f}\left(U_{j}^{n}\wedge B,U_{j-1}^{n}\wedge B\right).$$

With this observation and the dominated convergence theorem, we find that the second sum converges to

$$\begin{split} \iint_{\Pi_{T} \cap \{x < 0\}} & \operatorname{sgn}(u - A) \left( g(u) - g(A) \right) \phi_{x} \, dx \, dt \\ & + \iint_{\Pi_{T} \cap \{x > 0\}} & \operatorname{sgn}(u - B) \left( f(u) - f(B) \right) \phi_{x} \, dx \, dt, \end{split}$$

and this quantity is equal to

$$\iint_{\Pi_T} \operatorname{sgn}\left(u - c^{AB}(x)\right) \left(\mathcal{F}(x, u) - \mathcal{F}\left(x, c^{AB}(x)\right)\right) \phi_x \, dx \, dt,$$

thus completing our verification of the entropy condition (3.4).

Finally, by Theorem 3.1, the entire computed sequence  $u^{\Delta}$  converges to u in  $L^1_{loc}(\Pi_T)$  and a.e. in  $\Pi_T$ .

**6. Numerical examples.** Combining all possible intersections of the functions f and g, all orderings of the extrema  $f(u_f^*)$  and  $g(u_g^*)$ , and all connections (A,B) with all initial data that are of interest would lead to a multitude of test cases. Our test cases correspond to fluxes that intersect as shown in plots A to D of Figure 1.1. Fluxes that intersect only at the endpoints u=0 and u=1 (according to plots E and F of Figure 1.1) are of particular interest in traffic modeling. Numerical examples for these cases with  $(A,B)=(u_{\rm L}^\#,u_{\rm R}^\#)$  are extensively presented in [7, 9], including error histories and second-order upgrades of the scheme. Connections other than  $(A,B)=(u_{\rm L}^\#,u_{\rm R}^\#)$  are also of interest in traffic modeling; we come back to this in a future paper.

We here limit ourselves to four cases, Examples 1 to 4, which are defined by the functions f and g, the connections (A,B), and the initial datum  $u_0$  specified in Table 6.1. In all cases,  $f(u_f^*) = g(u_g^*)$ , with  $u_f^* = 2/3$  and  $u_g^* = 1/3$  in Examples 1 and 2 and vice versa in Examples 3 and 4. Figure 6.1 displays the functions f and g and the connections (A,B) for these examples. Figures 6.2 and 6.3 show the numerical solution for Examples 1 and 2 and for Examples 3 and 4, respectively. These solutions have been obtained by the scheme described in section 4 with a spatial discretization of  $\Delta x = 1/40$  and  $\lambda = 1$ . In each of these examples, the solution is plotted at three different times, and we limit ourselves to displaying the zone near x = 0, which is of special interest. For Examples 1, 2, and 4, we also include a reference solution, obtained by the same method with  $\Delta x = 1/5000$ , while for Example 3, we include a second numerical solution with  $\Delta x = 1/200$ .

Examples 1 and 2 correspond to plots B or D of Figure 1.1. These are cases in which the crossing condition is satisfied. If we had chosen  $A = B = u_{\chi}$  in such a situation, then  $u^{\Delta} \equiv u_{\chi}$  would be the (stationary) solution evolving from  $u_0 \equiv u_{\chi}$ . However, by our choices  $A < u_{\chi} < B$  in Example 1 and  $B < u_{\chi} < A$  in Example

Table 6.1
Parameters of the numerical examples.

| Example # | f(u)         | g(u)         | A    | B    | $u_0$                |
|-----------|--------------|--------------|------|------|----------------------|
| 1         | $u^2(1-u)$   | $u(1-u)^2$   | 0.4  | 0.6  | $u_{\chi} = 0.5$     |
| 2         | $u^{2}(1-u)$ | $u(1-u)^{2}$ | 0.6  | 0.4  | $u_{\chi}^{2} = 0.5$ |
| 3         | $u(1-u)^2$   | $u^2(1-u)$   | 0.75 | 0.25 | $u_{\chi} = 0.5$     |
| 4         | $u(1-u)^2$   | $u^2(1-u)$   | 0.75 | 0.25 | H(-x)                |

![](_page_24_Figure_3.jpeg)

Fig. 6.1. The fluxes f(u) and g(u) and the connection (A, B) for (a) Example 1, (b) Example 2, and (c) Examples 3 and 4.

![](_page_24_Figure_5.jpeg)

FIG. 6.2. Examples 1 ((a)–(c)) and 2 ((d)–(f)). The open circles correspond to the numerical solution with  $\Delta x = 1/40$ . The solid line is a reference solution.

2,  $u_{\chi}$  is not an entropy solution of type (A, B); rather, the solution consists of a fan of waves emerging from (x = 0, t = 0) and on any finite interval containing x = 0, converges to a piecewise constant solution with a jump from A to B at x = 0.

Examples 3 and 4 correspond to situation A or C of Figure 1.1. The exact solution of the problem posed in Example 3 is  $u \equiv u_{\chi}$ . This can be readily verified from the jump conditions (3.5)–(3.7). However, for the initial datum  $u_0 \equiv u_{\chi}$ , the numerical solution is not  $u^{\Delta} \equiv u_{\chi}$ . In fact, Figures 6.3(a)–(c) show that for both discretizations,  $\Delta x = 1/40$  and  $\Delta x = 1/200$ , there are two solution values that differ from  $u_{\chi}$ . This behavior was qualitatively the same for all coarser and finer discretizations tested; exactly two solution values are different from 0.5, and after some time, for all values of  $\Delta x$ , the discrete solution picture was the same as that of Figure 6.3(c). The final height of the "spikes" did not depend on  $\Delta x$ .

The reason for this behavior is that although in light of (4.7), the scheme preserves the steady-state solution connecting A to B, in our case it does not preserve  $u_{\chi}$  as a

![](_page_25_Figure_3.jpeg)

Fig. 6.3. Examples 3 ((a)–(c)) and 4 ((d)–(f)). The open circles correspond to the numerical solution with  $\Delta x=1/40$ . The small dots in (a)–(c) show another numerical solution with  $\Delta x=1/200$ . The solid line in (d)–(f) is a reference solution.

steady state, since due to  $B < u_{\chi} < A$ , in this example we have that

$$h^{AB}(u_\chi,u_\chi) = f(u_\chi) - \frac{1}{2} \left[ \int_B^{u_\chi} \left| \tilde{f}'(w) \right| \, dw + \int_{u_\chi}^A \left| \tilde{g}'(w) \right| \, dw \right] < f(u_\chi) = g(u_\chi).$$

Finally, Example 4 is a case where again, on any finite interval containing x = 0, the scheme converges to a piecewise constant solution with a jump from A to B at x = 0.

7. Remarks on more general flux functions. Recently, Adimurthi, Mishra, and Veerappa Gowda [3] extended the notion of a connection (A,B) to the situation where the fluxes f and g may have any number of extrema and there may be any number of flux crossings. The (A,B) connection now becomes a vector instead of a scalar, and their notion of entropy solution is necessarily much more involved—they give a separate interface condition for each component of the connection vector. It would be of interest to extend the program of the present paper to the setup considered in [3], and we leave this for a future paper. It will probably be necessary to reformulate the corresponding characteristic conditions in a way that is independent of the extrema of the particular flux functions considered, for example, by appealing to the different wave types; see [18] and Remark 1.1.

Although our definition of entropy solution, and the numerical scheme presented herein, would necessarily become more complicated in the case of multiple flux crossings, one aspect of the analysis that would not become any harder is the proof of compactness. Let us explain this comment. The most difficult portion of the compactness analysis for conservation laws with discontinuous flux is due to lack of a global spatial variation bound—this is in marked contrast to the situation where there is no discontinuity in the flux. This has called for alternative techniques, such as the singular mapping approach [1, 12, 29, 41, 44] or compensated compactness [23, 24, 26].

The singular mapping approach, in particular, becomes increasingly unwieldy as the flux becomes more complicated. We recently discovered [7] that conservation laws with discontinuous flux satisfy local variation bounds that are sufficient for compactness, and we have adopted this approach in the present paper (Lemma 5.3). These local variation bounds can be obtained rather easily even for a very complicated flux. Finally, one more direction in which our approach could be extended is degenerate parabolic equations with discontinuous coefficients [13, 24, 25, 27]. This extension would be technical but fairly straightforward—we have concentrated on conservation laws mostly to avoid obscuring our main ideas.

**Acknowledgments.** We are grateful to Boris Andreianov, Stefan Diehl, Siddhartha Mishra, and Nils Henrik Risebro for interesting discussions.

#### REFERENCES

- ADIMURTHI, J. JAFFRÉ, AND G.D. VEERAPPA GOWDA, Godunov-type methods for conservation laws with a flux function discontinuous in space, SIAM J. Numer. Anal., 42 (2004), pp. 179– 208.
- ADIMURTHI, S. MISHRA, AND G.D. VEERAPPA GOWDA, Optimal entropy solutions for conservation laws with discontinuous flux functions, J. Hyperbolic Differ. Equ., 2 (2005), pp. 783–837.
- [3] ADIMURTHI, S. MISHRA, AND G.D. VEERAPPA GOWDA, Existence and stability of entropy solutions for a conservation law with discontinuous non-convex fluxes, Netw. Heterog. Media, 2 (2007), pp. 127–157.
- [4] E. AUDUSSE AND B. PERTHAME, Uniqueness for scalar conservation laws with discontinuous flux via adapted entropies, Proc. Roy. Soc. Edinburgh Sect. A, 135 (2005), pp. 253–265.
- [5] F. BACHMANN AND J. VOVELLE, Existence and uniqueness of entropy solution of scalar conservation laws with a flux function involving discontinuous coefficients, Comm. Partial Differential Equations, 31 (2006), pp. 371–395.
- [6] P. Baiti and H. Jenssen, Well-posedness for a class of  $2 \times 2$  conservation laws with  $L^{\infty}$  data, J. Differential Equations, 140 (1997), pp. 161–185.
- [7] R. BÜRGER, A. GARCÍA, K.H. KARLSEN, AND J.D. TOWERS, A family of schemes for kinematic flows with discontinuous flux, J. Engrg. Math., 60 (2008), pp. 387–425.
- [8] R. BÜRGER, A. GARCÍA, K.H. KARLSEN, AND J.D. TOWERS, Difference schemes, entropy solutions, and speedup impulse for an inhomogeneous kinematic traffic flow model, Netw. Heterog. Media, 3 (2008), pp. 1–41.
- [9] R. BÜRGER AND K.H. KARLSEN, On a diffusively corrected kinematic-wave traffic flow model with changing road surface conditions, Math. Models Methods Appl. Sci., 13 (2003), pp. 1767–1799.
- [10] R. BÜRGER, K.H. KARLSEN, S. MISHRA, AND J.D. TOWERS, On conservation laws with discontinuous flux, in Trends in Applications of Mathematics to Mechanics, Y. Wang and K. Hutter, eds., Shaker Verlag, Aachen, 2005, pp. 75–84.
- [11] R. BÜRGER, K.H. KARLSEN, N.H. RISEBRO, AND J.D. TOWERS, On a model for continuous sedimentation in vessels with discontinuously varying cross-sectional area, in Hyperbolic Problems: Theory, Numerics, Applications, T.Y. Hou and E. Tadmor, eds., Springer-Verlag, Berlin, 2003, pp. 397–406.
- [12] R. BÜRGER, K.H. KARLSEN, N.H. RISEBRO, AND J.D. TOWERS, Well-posedness in BV<sub>t</sub> and convergence of a difference scheme for continuous sedimentation in ideal clarifier-thickener units, Numer. Math., 97 (2004), pp. 25–65.
- [13] R. BÜRGER, K.H. KARLSEN, AND J.D. TOWERS, A model of continuous sedimentation of flocculated suspensions in clarifier-thickener units, SIAM J. Appl. Math., 65 (2005), pp. 882–940.
- [14] G.-Q. CHEN, N. EVEN, AND C. KLINGENBERG, Entropy solutions to conservation laws with discontinuous fluxes via microscopic interacting particle systems, in Stochastic Analysis and Partial Differential Equations, Contemp. Math. 429, Amer. Math. Soc., Providence, RI, 2007, pp. 63–76..
- [15] M.G. CRANDALL AND A. MAJDA, Monotone difference approximations for scalar conservation laws, Math. Comp., 34 (1980), pp. 1–21.
- [16] M.G. CRANDALL AND L. TARTAR, Some relations between nonexpansive and order preserving mappings, Proc. Amer. Math. Soc., 78 (1980), pp. 385–390.

- [17] S. Diehl, On scalar conservation laws with point source and discontinuous flux function, SIAM J. Math. Anal., 26 (1995), pp. 1425–1451.
- [18] S. Diehl, Scalar conservation laws with discontinuous flux function. I. The viscous profile condition, Comm. Math. Phys., 176 (1996), pp. 23–44.
- [19] B. Engquist and S. Osher, One-sided difference approximations for nonlinear conservation laws, Math. Comp., 36 (1981), pp. 321–351.
- [20] M. GARAVELLO, R. NATALINI, B. PICCOLI, AND A. TERRACINA, Conservation laws with discontinuous flux, Netw. Heterog. Media, 2 (2007), pp. 159–179.
- [21] T. GIMSE AND N.H. RISEBRO, Solution of the Cauchy problem for a conservation law with a discontinuous flux function, SIAM J. Math. Anal., 23 (1992), pp. 635–648.
- [22] J.M.-K. Hong, Part I: An Extension of the Riemann Problems and Glimm's Method to General Systems of Conservation Laws with Source Terms. Part II: A Total Variation Bound on the Conserved Quantities for a Generic Resonant Nonlinear Balance Laws, Ph.D. thesis, University of California, Davis, 2000.
- [23] K.H. KARLSEN, M. RASCLE, AND E. TADMOR, On the existence and compactness of a twodimensional resonant system of conservation laws, Commun. Math. Sci., 5 (2007), pp. 253– 265.
- [24] K.H. KARLSEN, N.H. RISEBRO, AND J.D. TOWERS, On a nonlinear degenerate parabolic transport-diffusion equation with a discontinuous coefficient, Electron. J. Differential Equations, 2002 (2002), pp. 1–23.
- [25] K.H. KARLSEN, N.H. RISEBRO, AND J.D. TOWERS, On an upwind difference scheme for degenerate parabolic convection-diffusion equations with a discontinuous coefficient, IMA J. Numer. Anal., 22 (2002), pp. 623-644.
- [26] K.H. KARLSEN AND J.D. TOWERS, Convergence of the Lax-Friedrichs scheme and stability for conservation laws with a discontinuous space-time dependent flux, Chinese Ann. Math. Ser. B, 25B (2004), pp. 287–318.
- [27] K.H. KARLSEN, N.H. RISEBRO, AND J.D. TOWERS, L<sup>1</sup> stability for entropy solutions of non-linear degenerate parabolic convection-diffusion equations with discontinuous coefficients, Skr. K. Nor. Vid. Selsk., 3 (2003), pp. 1–49.
- [28] E.F. KAASSCHIETER, Solving the Buckley-Leverett equation with gravity in a heterogeneous porous medium, Comput. Geosci., 3 (1999), pp. 23–48.
- [29] C. KLINGENBERG AND N.H. RISEBRO, Convex conservation laws with discontinuous coefficients, existence, uniqueness and asymptotic behavior, Comm. Partial Differential Equations, 20 (1995), pp. 1959–1990.
- [30] C. KLINGENBERG AND N.H. RISEBRO, Stability of a resonant system of conservation laws modeling polymer flow with gravitation, J. Differential Equations, 170 (2001), pp. 344–380.
- [31] S.N. KRUŽKOV, First order quasi-linear equations in several independent variables, Math. USSR Sb., 10 (1970), pp. 217–243.
- [32] L.W. Lin, B.J. Temple, and J.H. Wang, A comparison of convergence rates for Godunov's method and Glimm's method in resonant nonlinear systems of conservation laws, SIAM J. Numer. Anal., 32 (1995), pp. 824–840.
- [33] L.W. LIN, B. TEMPLE, AND J.H. WANG, Suppression of oscillations in Godunov's method for a resonant non-strictly hyperbolic system, SIAM J. Numer. Anal., 32 (1995), pp. 841–864.
- [34] W.K. LYONS, Conservation laws with sharp inhomogeneities, Quart. Appl. Math., 40 (1982/83), pp. 385–393.
- [35] S. MOCHON, An analysis of the traffic on highways with changing surface conditions, Math. Model., 9 (1987), pp. 1-11.
- [36] D.N. OSTROV, Viscosity solutions and convergence of monotone schemes for synthetic aperture radar shape-from-shading equations with discontinuous intensities, SIAM J. Appl. Math., 59 (1999), pp. 2060–2085.
- [37] D.N. OSTROV, Solutions of Hamilton-Jacobi equations and scalar conservation laws with discontinuous space-time dependence, J. Differential Equations, 182 (2002), pp. 51–77.
- [38] E.Y. Panov, Existence of strong traces for generalized solutions of multidimensional scalar conservation laws, J. Hyperbolic Differ. Equ., 2 (2005), pp. 885–908.
- [39] E.Y. PANOV, Existence of strong traces for quasi-solutions of multidimensional scalar conservation laws, J. Hyperbolic Differ. Equ., 4 (2007), pp. 729–770.
- [40] E.Y. Panov, Existence and strong pre-compactness properties for entropy solutions of a first-order quasilinear equation with discontinuous flux, Arch. Ration. Mech. Anal., to appear.
- [41] N. SEGUIN AND J. VOVELLE, Analysis and approximation of a scalar conservation law with a flux function with discontinuous coefficients, Math. Models Methods Appl. Sci., 13 (2003), pp. 221–257.

- [42] E. Tadmor, Numerical viscosity and the entropy condition for conservative difference schemes, Math. Comp., 43 (1984), pp. 369–381.
- [43] J.D. Towers, Convergence of a difference scheme for conservation laws with a discontinuous flux, SIAM J. Numer. Anal., 38 (2000), pp. 681–698.
- [44] J.D. Towers, A difference scheme for conservation laws with a discontinuous flux: The nonconvex case, SIAM J. Numer. Anal., 39 (2001), pp. 1197–1218.
- [45] A. Vasseur, Strong traces of multidimensional scalar conservation laws, Arch. Ration. Mech. Anal., 160 (2001), pp. 181–193.