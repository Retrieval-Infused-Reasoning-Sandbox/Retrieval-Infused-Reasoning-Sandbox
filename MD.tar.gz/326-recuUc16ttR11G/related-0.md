# Primary ciliary protein kinase A activity in the prefrontal cortex modulates stress in mice

Search for articles by this author

#### Highlights

Various animal stressors prolong neuronal primary cilia in the PFC

Removal of PFC excitatory neuron primary cilia suppresses animal stress

Corticosterone treatment triggers primary ciliary cAMP elevation in PFC neurons

Primary ciliary PKA activity suppression in PFC neurons reduces animal stress

#### Summary

Primary cilia are cellular antennae emanating from vertebrate cell surfaces to sense and transduce extracellular signals intracellularly to regulate cell behavior and function. However, their signal sensing and physiological functions in neocortical neurons remain largely unclear. Here, we show that, in response to various animal stressors, primary cilia in the mouse prefrontal cortex (PPC) exhibit consistent axonemal elongation. Selective removal of excitatory neuron primary cilia in the prefrontal but not sensory cortex leads to a reduction in animal stress sensing and response. Treatment with corticosterone, the major stress hormone, elicits an increase in primary ciliary cyclic adenosine 3',5'-monphosphate (cAMP) level in PFC excitatory neurons and a decrease in neuronal excitability dependent on primary cilia. Suppression of primary ciliary protein kinase A (PKA) activity in PFC excitatory neurons reduces animal stress. These results suggest that excitatory neurons in the PFC are involved in sensing and regulating animal stress via primary ciliary cAMP/PKA signaling.

#### Keywords

- 1. primary cilium
- animal stress
- 3- prefrontal cortex
- 4 excitatory neuron
- 5- corticosterone
- 6. PKA activity

#### Introduction

Animals endure many physical and social stressors in their lifetimes and evolve crucial mechanisms for coping with these stressors. The brain is one of the primary organs involved in perceiving and adapting to various stressors.

1.

de Kloet, E.R. - Joëls, M. - Holsboer, F.

Stress and the brain:: From adaptation to disease

Nat. Rev. Neurosci. 2005; 6:463-475

2.

McEwen, B.S.

Physiology and neurobiology of stress and adaptation: Central role of the brain

Physiol. Rev. 2007; 87:873-904

3.

Lupien, S.J. · McEwen, B.S. · Gunnar, M.R. ...

Effects of stress throughout the lifespan on the brain, behaviour and cognition

Nat. Rev. Neurosci. 2009: 10:434-445

......

4.

Joëls, M. · Baram, T.Z.

#### OPINION The neuro-symphony of stress

Nat. Rev. Neurosci. 2009; 10:459-466

A key effect of stress is the structural and functional remodeling of neural network, which can be a sign of successful adaptation. On the other hand, the persistence of the changes after stress has ended often reflects failed resilience and may contribute to depression or depressive-like behavior.

Even though stress has widespread effects throughout the brain, the neocortex, in particular the prefrontal cortex (PFC), and the amygdala have been suggested to be the two critical brain regions linked to stress sensing and adaptation.

5.

McEwen, B.S. · Nasca, C. · Gray, J.D.

#### Stress Effects on Neuronal Structure: Hippocampus, Amygdala, and Prefrontal Cortex

Neuropsychopharmacology, 2016; 41:3-23

6.

Colyn, L. · Venzala, E. · Marco, S. ...

Chronic social defeat stress induces sustained synaptic structural changes in the prefrontal cortex and amygdala

Behav. Brain Res. 2019; 373, 112079

7.

Lüthi, A. - Lüscher, C.

Pathological circuit function underlying addiction and anxiety disorders

Nat. Neurosci. 2014; 17:1635-1643

Numerous lines of evidence demonstrate the alterations in neural structures and functional communications of the PFC and the amygdala in animal stress and depression.

6.

Colyn, L. · Venzala, E. · Marco, S. ...

Chronic social defeat stress induces sustained synaptic structural changes in the prefrontal cortex and amygdala

Behav. Brain Res. 2019; 373, 112079

8

Arnsten, A.F.T.

Stress signalling pathways that impair prefrontal cortex structure and function

Nat. Rev. Neurosci. 2009; 10:410-422

9.

McEwen, B.S. · Morrison, J.H.

The Brain on Stress: Vulnerability and Plasticity of the Prefrontal Cortex over the Life Course

Neuron, 2013; 79:16-29

10.

Wang, M.H. · Perova, Z. · Arenkiel, B.R. ...

Synaptic Modifications in the Medial Prefrontal Cortex in Susceptibility and Resilience to Stress

J. Neurosci. 2014; 34:7485-7492

For example, synaptic loss in the PFC has been reported in postmortem studies of depressed subjects.

11.

Kang, H.J. · Voleti, B. · Hajszan, T. ...

Decreased expression of synapse-related genes and loss of synapses in major depressive disorder

Nat. Med. 2012; 18:1413-1417

12.

Martins-de-Souza, D. · Guest, P.C. · Harris, L.W. ...

Identification of proteomic signatures associated with depression and psychotic depression in post-mortem brains from major depression patients

Transl. Psychiatry. 2012; 2, e87

Animal models also provide further evidence on decreased spine density and dendrite complexity of PFC neurons upon chronic stress exposure.

13.

Moda-Sava, R.N. · Murdock, M.H. · Parekh, P.K. ...

Sustained rescue of prefrontal circuit dysfunction by antidepressantinduced spine formation

Science, 2019; 364:eaat8078

14.

Radley, J.J. · Rocher, A.B. · Miller, M. ...

Repeated stress induces dendritic spine loss in the rat medial prefrontal cortex

Comb Cortor analy theats and

careo, corona 2000; recgização

Physiologically, stress is associated with increased levels of corticosteroids (cortisol in humans or corticosterone [CORT] in rodents), the primary stress hormone, under the regulation of the hypothalamic-pituitary-adrenal (HPA) axis.

15.

Munck, A. · Guyre, P.M. · Holbrook, N.J.

Physiological Functions of Glucocorticoids in Stress and Their Relation to Pharmacological Actions

Endocr. Rev. 1984; 5:25-44

16

Keller, J. · Gomez, R. · Williams, G. ...

HPA axis in major depression: cortisol, clinical symptomatology and genetic variation predict cognition

Mol. Psychiatry, 2017; 22:527-536

Two corticosteroid receptors largely mediate the effects: the type I, high-affinity mineralocorticoid receptors (MRs), and the type II, low-affinity glucocorticoid receptors (GRs), both of which are members of the nuclear receptor family and primarily located in the cytoplasm.

17.

Mifsud, K.R. · Reul, J.M.H.M.

Mineralocorticoid and glucocorticoid receptor-mediated control of genomic responses to stress in the brain

Stress. 2018; 21:389-402

When activated by the lipophilic corticosteroids, they are translocated into the nucleus and act as transcription factors to regulate gene transcription, which is characterized by a slow onset and a prolonged duration. Notably, emerging evidence also suggests that membrane-associated corticosteroid receptors, including MRs and GRs, are activated by corticosteroid binding at the cell surface and trigger intracellular signaling cascades, such as G protein-coupled receptor (GPCR) and second messenger signaling.

18.

Groeneweg, F.L. · Karst, H. · de Kloet, E.R. ...

Rapid non-genomic effects of corticosteroids and their role in the central stress response

J. Endocrinol. 2011; 209:153-167.

However, it remains largely unclear how neurons in the brain sense the stress at the initial stage, as well as the critical downstream signaling pathway underlying the behavioral responses.

The primary cilium is a non-motile, antenna-like sensory organelle emanating from the surface of most vertebrate cell types, including neurons in the brain.

19.

Singla, V. · Reiter, J.F.

The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science. 2006; 313:629-633

20.

Louvi, A. · Grove, E.A.

Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron, 2011; 69:1046-1060

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

Primary cilia in the developing and mature brain

Neuron, 2014; 82:511-521

.

Dahl, H.A.

#### Fine Structure of Cilia in Rat Cerebral Cortex

Z. Zellforsch. Mikrosk. Anat. 1963; 60:369-386

23.

Goetz, S.C. · Anderson, K.V.

#### The primary cilium: a signalling centre during vertebrate development

Nat. Rev. Genet. 2010; 11:331-344

It consists of a microtubule-based axoneme extending from the mother centriole docking at the cell membrane (also called the basal body) and is surrounded by a lipid bilayer membrane that is continuous with, but compositionally distinct from, the plasma membrane of cell body.

24:

Satir, P. · Christensen, S.T.

#### Overview of structure and function of mammalian cilia

Annu. Rev. Physiol. 2007; 69:377-400

Distinct from motile cilia with nine microtubule doublets and a central microtubule doublet, the primary cilium usually harbors nine microtubule doublets only. Although it is typically small (a few µm in length and less than 1 µm in diameter), the primary cilium is enriched in membrane receptors, ion channels, and downstream effectors for signaling sensing and transduction, such as GPCRs, cyclic adenosine 3',5'monphosphate (cAMP), and protein kinase A (PKA).

19.

Singla, V. - Reiter, J.F.

The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science, 2006; 313:629-633

ġ.

Hilgendorf, K.I. · Johnson, C.T. · Jackson, P.K.

The primary cilium as a cellular receiver: organizing ciliary GPCR signaling

Curr. Opin. Cell Biol. 2016; 39:84-92

26.

Schmid, A. · Sutto, Z. · Nlend, M.C. ...

Soluble adenylyl cyclase is localized to cilia and contributes to ciliary beat frequency regulation via production of cAMP

J. Gen. Physiol. 2007; 130:99-109.

27.

Mick, D.U. · Rodrigues, R.B. · Leib, R.D. ...

Proteomics of Primary Cilia by Proximity Labeling

Dev. Cell. 2015; 35:497-512

28.

Siljee, J.E. · Wang, Y. · Bernard, A.A. ...

Subcellular localization of MC4R with ADCY3 at neuronal primary cilia underlies a common pathway for genetic predisposition to obesity

Nat. Genet. 2018; 50:180-185

20.

Truong, M.E. · Bilekova, S. · Choksi, S.P. ...

Vertebrate cells differentially interpret ciliary and extraciliary cAMP

Call anne so sense anné aso

```
Cent. 2021; 104; 2911; 2920.010
```

While the crucial roles of primary cilia in regulating early embryonic patterning and neural development have been established,

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

30.

Han, Y.G. · Spassky, N. · Romaguera-Ros, M. ...

#### Hedgehog signaling and primary cilia are required for the formation of adult neural stem cells

Nat. Neurosci. 2008; 11:277-284

31.

Liu, S. · Trupiano, M.X. · Simon, J. ...

# The essential role of primary cilia in cerebral cortical development and disorders

Curr. Top. Dev. Biol. 2021; 142:99-146

32.

Han, Y.G. - Alvarez-Buylla, A.

#### Role of primary cilia in brain development and cancer

Curr. Opin. Neurobiol. 2010; 20:58-67

their function in the mature brain, particularly the neocortex, remains poorly understood.

3.1

20.

Louvi, A. · Grove, E.A.

Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron. 2011; 69:1046-1060

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

The unique structural and signaling features of the primary cilium raise an intriguing possibility that it may participate in sensing animal stress and regulating stress-related behavioral responses. In this study, we found that excitatory neuron primary cilia in the mouse PFC, but not sensory cortex, sense and regulate animal stress via ciliary cAMP and PKA signaling.

#### Results

#### Animal stress prolongs neuronal primary cilia in PFC

To test the possibility that the primary cilium in the crucial brain regions senses animal stress, we adopted two commonly used mouse stress models, chronic restraint stress (CRS) and chronic social defeat stress (CSDS).

33-

Kim, K.S. · Han, P.L.

Optimization of chronic stress paradigms using anxiety- and depressionlike behavioral parameters

J. Neurosci. Res. 2006; 83:497-507

34

Yuan, Z. · Qi, Z. · Wang, R. ...

#### A corticoamygdalar pathway controls reward devaluation and depression using dynamic inhibition code

Neuron, 2023; 111:3837-3853.e5

35-

Berton, O. · McClung, C.A. · DiLeone, R.J. ...

## Essential role of BDNF in the mesolimbic dopamine pathway in social defeat stress

Science, 2006; 311:864-868

Under CRS, the C57BL/6J mice were subjected to similarly sized tubes to ensure that the animals can breathe normally without arbitrarily moving or rolling for 2 h per day for 14 consecutive days.

33 -

Kim, K.S. · Han, P.L.

#### Optimization of chronic stress paradigms using anxiety- and depressionlike behavioral parameters

J. Neurosci. Res. 2006; 83:497-507.

We then examined the morphology of neuronal primary cilia in the neocortex and the amygdala by staining with antibodies against adenylate cyclase 3 (AC3) (A and A, white), a well-characterized primary ciliary marker protein,

36.

Bishop, G.A. · Berbari, N.F. · Lewis, J. ...

#### Type III adenylyl cyclase localizes to primary cilia throughout the adult mouse brain

J. Comp. Neurol. 2007; 505:562-571

and neuronal nuclear antigen (NeuN) (A and A, green), a neuronal nuclei antigen.

Strikingly, the length of neuronal primary cilia in the PFC, but not in the primary somatosensory cortex (S1) or the amygdala, exhibited a significant increase upon CRS, compared with the control non-stressed condition (A-1F and B-S1G: ). We observed no

obvious change in the density or rate of ciliation between the CRS and control conditions (H and S1I). Notably, the primary ciliary length is often linked to ciliary signaling and function.

37-

Macarelli, V. - Leventea, E. - Merkle, F.T.

#### Regulation of the length of neuronal primary cilia and its potential effects on signalling

Trends Cell Biol. 2023; 33:979-990

These results suggest that neuronal primary cilia in the PFC respond to animal stress and become elongated in the axoneme.

![](_page_12_Picture_6.jpeg)

![](_page_13_Figure_0.jpeg)

Figure 1 Animal stress prolongs neuronal primary cilium length in the PFC

Video S1. 3D reconstruction of primary cilia in the mouse PFC, related to Figure 1

To further test this, we performed similar experiments with CSDS, in which the C57BL/6J mice were subjected to a daily 5-min direct contact with the aggressive Institute of Cancer Research (ICR) mice, followed by sensory contact for 10 consecutive days.

28.

Krishnan, V. · Han, M.H. · Graham, D.L. ...

Molecular adaptations underlying susceptibility and resistance to social defeat in brain reward regions

Cell. 2007; 131:391-404

Interestingly, we found that the CSDS condition caused a significant increase in neuronal primary ciliary length in the PFC, but not in the amygdala, compared with the non-stressed control condition (G-1L). Taken together, these results demonstrate that different animal stressors lead to consistent elongation of neuronal primary cilia in the PFC, a critical brain region linked to animal stress regulation.

#### Primary cilium loss reduces acute animal stress response

Having found that neuronal primary cilia in the PFC sense animal stress and become elongated, we next assessed their potential function in stress-related behaviors. To achieve this, we took advantage of the conditional mutant allele of Centrosomal Protein 83 (Cep83), which encodes an essential centrosomal protein for mother centriole distal appendage assembly and consequently primary cilium formation.

39.

Tanos, B.E. · Yang, H.J. · Soni, R. ...

#### Centriole distal appendages promote membrane docking, leading to cilia initiation

Genes Dev. 2013; 27:163-168

To avoid any early primary cilium-related developmental defect in neural progenitors,

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

31.

Liu, S. - Trupiano, M.X. - Simon, J. ...

# The essential role of primary cilia in cerebral cortical development and disorders

Curr. Top. Dev. Biol. 2021; 142:99-146

32.

Han, Y.G. - Alvarez-Buylla, A.

#### Role of primary cilia in brain development and cancer

Curr. Opin. Neurobiol. 2010; 20:58-67

40.

Shao, W. · Yang, J.J. · He, M. ...

#### Centrosome anchoring regulates progenitor properties and cortical formation

Nature. 2020; 580:106-112

we used the Nex-Cre mouse line, in which Cre recombinase is selectively expressed in

postmitotic excitatory neurons in the dorsal telencephalon.

41.

Goebbels, S. · Bormuth, I. · Bode, U. ...

#### Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice

Genesis, 2006; 44:611-621

The Nex-Cre; Cep83<sup>(I)/I</sup> conditional knockout (Cep83 cKO) mice were born in mendelian ratio, with no obvious difference in the body weight from the wild-type (WT) littermate control mice (A). As expected, the expression of CEP83 was largely eliminated in the Cep83 cKO neocortex (B). The size, neuronal number, or layer formation of the Cep83 cKO neocortex was similar to that of the WT control neocortex (C–S2K). These results suggest that selective removal of CEP83 in postmitotic excitatory neurons in the dorsal telencephalon does not cause any significant change in structural development and laminar organization of the neocortex.

We then examined the primary cilium formation in the WT and Cep83 cKO brains. Notably, we observed a drastic loss of neuronal primary cilia, revealed by the staining of AC3 and NeuN in the neocortical regions including the PFC and the S1, as well as the amygdala but not the thalamus (TH), with no Cre recombinase expression

41.

Goebbels, S. · Bormuth, I. · Bode, U. ...

#### Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice

Genesis. 2006; 44:611-621

in the Cep83 cKO brain compared with the WT control brain (A, 2B, L, and S2M). The loss of primary cilia in the Cep83 cKO neocortex was further confirmed with the staining of another primary ciliary marker protein, melanin-concentrating hormone receptor 1 (MCHR1) (A and S3B), as well as by the serial scanning electron microscopic analyses (C and S3D). The primary cilia in inhibitory interneurons of the neocortex, with no Cre recombinase expression, also appeared largely intact (E). Together, these results demonstrate that selective removal of CEP83 in the dorsal telencephalic excitatory neurons leads to an effective and specific loss of primary cilia.

![](_page_16_Figure_1.jpeg)

Figure 2 Neuronal primary ciliary loss suppresses acute animal stress response

We next subjected the WT and Cep83 cKO mice to various behavioral tests.

Interestingly, we found that in the open field test (OFT), the Cep83 cKO mice displayed a significantly higher frequency entering the center zone and a significantly longer duration of time spent in the center zone than the WT control mice (C-2E), indicative of a reduced level of anxiety or stress in the Cep83 cKO mice. We observed no obvious difference between the total locomotion distances exhibited by the WT and Cep83 cKO

mice (A), suggesting that the overall locomotion of the Cep83 cKO mice is normal.

Moreover, we found that the Cep83 cKO mice exhibited much longer time duration and locomotion distance in the light box than the WT control mice in the light-dark transition test (LDT) (F-2H). We observed no obvious difference in the three-chamber social test

42.

Guo, B.L. · Chen, J. · Chen, Q. ...

#### Anterior cingulate cortex dysfunction underlies social deficits in Shank3 mutant mice

Nat. Neurosci. 2019; 22:1223-1234

or the Morris water maze test.

43-

Vorhees, C.V. · Williams, M.T.

#### Morris water maze: procedures for assessing spatial and related forms of learning and memory

Nat. Protoc. 2006; 1:848-858

between the WT and Cep83 cKO mice (B-S4N), indicating that the Cep83 cKO mice exhibit a similar general sociability and interest in social novelty, as well as spatial learning and memory capability, to the WT mice. Notably, while the Cep83 cKO mice exhibited a reduced level of freezing in the fear conditioning test, compared with the WT mice (A-S5E, S5G, S5H, S5J, and S5K), they acquired fear memory (F, S5I, and S5L). The total locomotion distances by the WT and Cep83 cKO mice for every 10 min within a 2-h period of OFTs were comparable (M), further indicating that the overall locomotor activity of the Cep83 mutant mice is similar to that of the WT mice. Taken together, these results suggest that loss of excitatory neuron primary cilia in the dorsal telencephalon particularly leads to a decreased level of animal anxiety or stress.

To further assess the effect of primary ciliary loss on animal stress, we adopted two commonly used acute animal stress tests, the tail suspension test (TST) and the forced swim test (FST), which measure the animal's coping strategy for acute inescapable stress and thereby reflect acute animal stress response.

44.

Castagné, V. · Moser, P. · Roux, S. ...

Rodent models of depression: forced swim and tail suspension behavioral despair tests in rats and mice

Curr. Protoc. Neurosci. 2011;

After a period of vigorous activity during which the animal tries to escape, the animal displays a characteristic immobility indicative of depressive-like behavior and state. Notably, in both tests, we observed a significant reduction in the immobility time in the Cep83 cKO mice compared with the WT mice (I-2L), further suggesting that loss of excitatory neuron primary cilia in the dorsal telencephalon reduces acute animal stress response.

Importantly, to exclude the possibility that CEP83 may exert a non-primary ciliumrelated function in affecting animal stress, we took advantage of the conditional mutant mice of *Tau tubulin kinase 2* (*Ttbk2*), which encodes a protein kinase required for primary cilium formation and maintenance,

45-

Goetz, S.C. · Liem, K.F. · Anderson, K.V.

The Spinocerebellar Ataxia-Associated Gene Tau Tubulin Kinase 2 Controls the Initiation of Ciliogenesis

Cell. 2012; 151:847-858

and crossed these with the Nex-Cre mice to selectively delete Ttbk2 in postmitotic excitatory neurons in the dorsal telencephalon. As expected, we observed a drastic loss of neuronal primary cilia in the neocortex, but not in the thalamus, in the Nex-Cre; Ttbk2<sup>fl/fl</sup> cKO (Ttbk2 cKO) brain (A and S6B). Moreover, compared with the WT mice, the Ttbk2 cKO mice exhibited a significant reduction in immobility time in both TST and FST (C and S6D), indicating a decrease in acute animal stress response, similar to that in the Cep83 cKO mice (I-2L).

Taken together, these results show that loss of excitatory neuron primary cilia in the dorsal telencephalon via different molecular perturbations results in a consistently reduced level of animal acute stress response.

#### Primary ciliary loss suppresses chronic animal stress response

Exposure to acute stressors causes profound physiological changes, which may lead to long-term consequences in chronic animal stress response and a maladaptive behavioral outcome such as depressive-like behavior. 1.

de Kloet, E.R. - Joëls, M. - Holsboer, F.

#### Stress and the brain:: From adaptation to disease

Nat. Rev. Neurosci. 2005; 6:463-475

7.

Lüthi, A. · Lüscher, C.

#### Pathological circuit function underlying addiction and anxiety disorders

Nat. Neurosci. 2014; 17:1635-1643

46.

Krishnan, V. · Nestler, E.J.

#### The molecular neurobiology of depression

Nature. 2008; 455:894-902

We next assessed the function of dorsal telencephalic excitatory neuron primary cilia in regulating chronic animal stress response. The WT and Cep83 cKO mice were subjected to CSDS as described above, and their stress-induced behavioral responses were assessed by using the social interaction test (SIT), which measures the vulnerability of the animal to social defeat-induced social avoidance

47.

Blanchard, R.J. - McKittrick, C.R. - Blanchard, D.C.

#### Animal models of social stress: Effects on behavior and brain neurochemical systems

Physiol. Behav. 2001; 73:261-271

; FST; and the sucrose preference test (SPT), which measures anhedonia—a core depressive symptom Yuan, Z. · Qi, Z. · Wang, R. ...

#### A corticoamygdalar pathway controls reward devaluation and depression using dynamic inhibition code

Neuron. 2023; 111:3837-3853.e5

(A). As shown previously,

47.

Blanchard, R.J. - McKittrick, C.R. - Blanchard, D.C.

#### Animal models of social stress: Effects on behavior and brain neurochemical systems

Physiol. Behav. 2001; 73:261-271

the WT mice displayed a significant reduction in the duration in the social interaction zone upon CSDS treatment (B and 3C, left), indicating an increase in social defeatinduced social avoidance. Moreover, consistent with the stress and depressive-like phenotypes, the WT mice exhibited a significant increase in immobility time in the FST (D, left) and a significant decrease in the sucrose preference ratio (E, left). In sharp contrast, the Cep83 cKO mice showed no reduction in the duration in the interaction zone upon CSDS treatment (B and 3C, right). Furthermore, the Cep83 cKO mice exhibited no change in immobility time in the FST (D, right) or in the sucrose preference ratio (E, right). Together, these results suggest that loss of excitatory neuron primary cilia in the dorsal telencephalon suppresses animal chronic stress response or depressive-like behavior induced by CSDS.

![](_page_20_Picture_10.jpeg)

![](_page_20_Picture_11.jpeg)

![](_page_21_Figure_0.jpeg)

Figure 3 Neuronal primary ciliary loss reduces chronic animal stress response

To further test this, we subjected the WT and Cep83 cKO mice to CRS and examined their chronic stress responses (F). While the WT mice exhibited clear chronic stress responses or depressive-like phenotypes upon CRS treatment, including a significant increase in immobility time in the TST and FST and a significant decrease in the sucrose preference ratio (G-3I, left), the Cep83 cKO mice did not exhibit any obvious chronic stress response or depressive-like phenotype (G-3I, right). We observed no obvious change in the body weight of the WT and Cep83 cKO mice after CRS treatment (E). Notably, a similar loss of chronic stress response or depressive-like phenotype was also observed in the Ttbk2 cKO mice (F-S6I). Together, these results suggest that removal of excitatory neuron primary cilia in the dorsal telencephalon with different molecular perturbations suppresses animal chronic stress response and depressive-like behavior.

It has previously been shown that chronic stress leads to a loss of excitatory synapses in the PFC.

14.

Radley, J.J. · Rocher, A.B. · Miller, M. ...

### Repeated stress induces dendritic spine loss in the rat medial prefrontal cortex

Cereb. Cortex. 2006; 16:313-320

We thus examined excitatory synapse density in the PFC of the WT and Cep83 cKO mice in response to chronic stress. We stained for the well-established excitatory synapse marker PSD-95 (A-S7D). As expected, we observed a significant reduction in PSD-95 puncta density in the PFC of WT mice after CRS treatment (A and S7B, left). In contrast, no obvious change in PSD-95 puncta density was observed in the PFC of Cep83 cKO mice (A and S7B, right). Moreover, we found no obvious change in PSD-95 puncta density in the S1 of WT and Cep83 cKO mice after CRS treatment (C and S7D). Consistent with this, we found that CRS caused a significant decrease in the frequency, but not the amplitude, of miniature excitatory postsynaptic current (mEPSC) in layer 2/3 excitatory neurons of the PFC in the WT but not Cep83 cKO mice (E-S7G). No obvious change in the frequency or amplitude of mEPSC in layer 2/3 excitatory neurons in the S1 of the WT and Cep83 cKO mice was observed (H-S7J). Together, these results suggest that Cep83 deletion and primary cilium loss suppress the specific reduction in excitatory synapses in the PFC induced by chronic stress.

#### Primary ciliary loss disrupts CORT-induced stress response

CORT or cortisol is the main glucocorticoid hormone that is released in response to stress as a result of the activation of the HPA axis.

48.

Herman, J.P. · Cullinan, W.E.

#### Neurocircuitry of stress: Central control of the hypothalamo-pituitaryadrenocortical axis

Trends Neurosci, 1997; 20:78-84

Chronic administration of CORT is a well-validated pharmacological stressor that induces animal stress and depressive-like behavioral responses Zhao, Y. · Ma, R. · Shen, J. ...

A mouse model of depression induced by repeated corticosterone injections

Eur. J. Pharmacol. 2008; 581:113-120

50.

49.

Gourley, S.L. · Taylor, J.R.

Recapitulation and reversal of a persistent depression-like syndrome in rodents

Curr. Protoc. Neurosci. 2009;

(A). Indeed, compared with the saline control, chronic CORT administration for 21 days

Zhao, Y. · Ma, R. · Shen, J. ...

A mouse model of depression induced by repeated corticosterone injections

Eur. J. Pharmacol. 2008; 581:113-120

in the WT mice led to a significant increase in immobility time in both the TST and FST (B and 4C, left), indicating an augmented behavioral despair. It also caused a significant decrease in the sucrose preference ratio (D, left), suggesting the development of anhedonia. In contrast, chronic CORT administration failed to induce any significant change in immobility time in the TST or FST or the sucrose preference ratio in the Cep83 cKO mice (B-4D, right). No obvious change in the body weight of the WT and Cep83 cKO mice after chronic CORT treatment was observed (A). These results suggest that loss of excitatory neuron primary cilia in the dorsal telencephalon disrupts chronic CORT-induced animal stress response or depressive-like behavior. Notably, similar levels of CORT increase in the serum responding to acute restraint stress (ARS) were observed in the WT and Cep83 cKO mice (B), indicating primary cilium loss does not affect CORT release upon animal stress.

![](_page_24_Figure_0.jpeg)

![](_page_24_Figure_1.jpeg)

Figure 4 Neuronal primary ciliary loss impairs chronic corticosterone-induced stress response

Interestingly, we found that chronic CORT administration led to a significant increase in the primary ciliary length in the PFC but not in the S1 or the amygdala (E-4G and C-S8G), suggesting that the primary cilia in the PFC selectively sense and respond to the elevated level of CORT. Moreover, we observed that chronic CORT administration caused a significant reduction in the firing rate of layer 2/3 excitatory neurons in the PFC (A and 5B, black) but not in the S1 (H and S8I, black) of the WT mice, consistent with the previous findings of a reduced PFC excitatory neuron excitability under chronic stress or depression conditions and a relatively inconspicuous effect of CORT on neurons in other cortical areas. Yuen, E.Y. · Wei, J. · Liu, W.H. ...

#### Repeated Stress Causes Cognitive Impairment by Suppressing Glutamate Receptor Expression and Function in Prefrontal Cortex

Neuron, 2012; 73:962-977

52.

Holmes, S.E. · Scheinost, D. · Finnema, S.J. ...

# Lower synaptic density is associated with depression severity and network alterations

Nat. Commun. 2019; 10, 1529

In line with this decrease in neuronal excitability, we also observed a significant increase in the rheobase current and a concurrent decrease in input resistance and resting membrane potential (C-5E and J-S8L, black). In contrast, chronic CORT administration failed to cause any reduction in the firing rate or the excitability of layer 2/3 excitatory neurons in the PFC or the S1 of Cep83 cKO mice (A-5E and H-S8L, red). Together, these results suggest that selective removal of excitatory neuron primary cilia in the dorsal telencephalon impairs the reduction of PFC excitatory neuronal excitability in response to chronic CORT treatment. In other words, the excitatory neuron primary cilia in the PFC are capable of sensing elevated levels of CORT and affecting the alteration in neuronal excitability under chronic stress or depressive-like conditions.

![](_page_25_Figure_9.jpeg)

![](_page_26_Figure_0.jpeg)

Figure 5 Chronic corticosterone suppresses prefrontal excitatory neuron excitability relying on primary cilia

# PFC excitatory neuron primary cilia mediate stress sensing and response

To directly assess the role of PFC excitatory neuron primary cilia in sensing and regulating animal stress, we took advantage of the Cep83fl/fl mice and injected recombinant adeno-associated virus (rAAV) expressing enhanced green fluorescent protein (EGFP) and Cre recombinase (i.e., EGFP/Cre) or EGFP alone as a control under the excitatory neuron-specific Ca2+/calmodulin-dependent protein kinase IIa (CaMKIIa) promoter into the PFC locally (A). Compared with the control PFC expressing EGFP, we observed an effective loss of primary cilia in the PFC expressing EGFP/Cre (B, 6C, and A). Interestingly, compared with the control mice, the mice with a selective loss of excitatory neuron primary cilia in the PFC exhibited a significant decrease in immobility time in both the TST and FST (D and 6E), indicating a decrease in the level of animal stress sensing and behavioral response. Moreover, when subjected to CRS, the control mice showed a significant level of stress and depressive-like behavior, including an increase in immobility time in both the TST and FST, and a decrease in the sucrose preference ratio (F-6H, left). In contrast, the mice with a selective loss of excitatory neuron primary cilia in the PFC exhibited no obvious phenotype of stress or depressive-like behavior (F-6H, right). Selective loss of PFC primary cilia also diminished the chronic stress effect on synapse density in the PFC (B-S9E), whereas the CORT-level elevation in response to acute stress was unaffected (F). Notably, injection of rAAV-EGFP/Cre or rAAV-EGFP virus into the S1 or primary visual cortex (V1) did not cause any alteration in animal stress or depressive-like behavior (G-S9J). Together, these results suggest that excitatory neuron primary cilia in the PFC selectively mediate animal stress sensing and behavioral response regulation.

![](_page_27_Figure_1.jpeg)

Figure 6 PFC excitatory neuron primary cilia mediate stress sensing and response

# Primary ciliary PKA activity regulates stress sensing and response

Primary cilia are specialized organelles for cellular signaling, among which adenylyl cyclase activation to produce cAMP that modulates PKA activity is one of the primary signaling pathways.

26.

Schmid, A. · Sutto, Z. · Nlend, M.C. ...

Soluble adenylyl cyclase is localized to cilia and contributes to ciliary beat frequency regulation via production of cAMP

J. Gen. Physiol. 2007; 130:99-109

è

Truong, M.E. · Bilekova, S. · Choksi, S.P. ...

#### Vertebrate cells differentially interpret ciliary and extraciliary cAMP

Cell. 2021; 184:2911-2926.e18

To dissect the critical signaling underlying the primary ciliary sensing of animal stress, we examined primary ciliary cAMP level in PFC excitatory neurons in response to CORT. We used G-Flamp3 (A-S10C), a new cAMP-level indicator that evolved from G-Flamp1,

53-

Wang, L. · Wu, C.L. · Peng, W.L. ...

#### A high-performance genetically encoded fluorescent indicator for in vivo cAMP imaging

Nat. Commun. 2022; 13, 5363.

and fused it with a well-characterized primary cilium-specific protein ADP-ribosylation factor-like GTPase 13B (ARL13B) with a point mutation T35N to eliminate its activity (ARL13B(T35N))

54-

Revenkova, E. · Liu, Q. · Gusella, G.L. ...

#### The Joubert syndrome protein ARL13B binds tubulin to maintain uniform distribution of proteins along the ciliary membrane

J. Cell Sci. 2018; 131, jcs212324

to assess primary ciliary cAMP level in PFC excitatory neurons. Interestingly, we found that CORT treatment triggered a significant increase in cAMP level in the primary cilium of PFC excitatory neurons in culture (A, 7B, and D), indicating that the primary cilia of PFC excitatory neurons sense and respond to CORT with an elevated cAMP level. Notably, the rise of cAMP level occurred within a few minutes, indicative of a relatively fast, non-nucleus transcriptional action of CORT. To test this, we treated PFC excitatory neurons in culture with membrane impermeable bovine serum albumin-conjugated CORT (BSA-CORT)

# The stress hormone corticosterone conditions AMPAR surface trafficking and synaptic potentiation

Nat. Neurosci. 2008; 11:868-870

and found that BSA-CORT elicited a primary ciliary cAMP-level increase similar to that of CORT (E-StoG), suggesting that CORT is capable of triggering membrane-associated signaling in the primary cilia of PFC excitatory neurons.

![](_page_29_Figure_4.jpeg)

Figure 7 PFC excitatory neuron ciliary cAMP/PKA signal mediates animal stress sensing and behavioral response regulation

We next tested whether primary ciliary PKA activity is required for the function of PFC excitatory neurons in regulating animal stress sensing and behavioral response; we engineered rAAV expressing the well-characterized dominant-negative PKA (dnPKA)

56.

Edin, M.L. · Howe, A.K. · Juliano, R.L.

#### Inhibition of PKA blocks fibroblast migration in response to growth factors

Exp. Cell Res. 2001; 270:214-222

selectively targeted to the primary cilium by fusing it with ciliary targeting sequence ARL13B(T35N) (i.e., ARL13B(T35N)-dnPKA; ciliary-dnPKA) under CaMKIIa promoter, and we injected it into the PFC locally (C). As expected, ARL13B(T35N)-dnPKA tagged with hemagglutinin (HA) was preferentially localized in the primary cilia in the PFC (D). Notably, we found that, compared with the expression of EGFP as a control, the expression of primary ciliary-targeted dnPKA in PFC excitatory neurons led to a significant reduction in immobility time of the mice in both the TST and FST (E), indicating a decrease in animal acute stress response, similar to the loss of excitatory neuron primary cilia in the PFC (E and 6F). Moreover, we also observed a loss of CRSinduced chronic stress response and depressive-like behavior in these mice, including no change in immobility time in the TST or FST and no change in the sucrose preference ratio (F-7H, red), whereas the control mice exhibited a significant level of stress and depressive-like behavior, including an increase in immobility time in both the TST and FST and a decrease in the sucrose preference ratio (F-6H, black). Similar results were obtained using another well-characterized PKA-specific inhibitor, protein kinase inhibitor peptide (PKIa), but not its mutant form (PKIamut)

57.

Ma, L. · Day-Cooney, J. · Benavides, O.J. ...

#### Locomotion activates PKA through dopamine and adenosine in striatal neurons

Nature. 2022; 611:762-768

(H-S10M). Together, these results suggest that primary ciliary PKA activity in excitatory neurons of the PFC regulates animal stress sensing and depressive-like behavioral phenotypes; that is, excitatory neurons in the PFC sense animal stress and regulate stress-induced behavioral response via primary ciliary PKA activity.

#### Discussion

Primary cilia project from the surface of most vertebrate cell types and act as antennae surveying the extracellular milieu to detect and transmit signals into the cell and in turn regulate cellular behavior and function.

19.

Singla, V. · Reiter, J.F.

The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science. 2006; 313:629-633

23.

Goetz, S.C. · Anderson, K.V.

The primary cilium: a signalling centre during vertebrate development

Nat. Rev. Genet. 2010; 11:331-344

24.

Satir, P. · Christensen, S.T.

Overview of structure and function of mammalian cilia

Annu. Rev. Physiol. 2007; 69:377-400

25.

Hilgendorf, K.I. · Johnson, C.T. · Jackson, P.K.

The primary cilium as a cellular receiver: organizing ciliary GPCR signaling

Curr. Opin. Cell Biol. 2016; 39:84-92

while they are typically small, representing roughly one out of hundreds of the total surface of the cell, primary cilia are enriched in membrane receptors, signaling molecules, and transport machineries. Moreover, the base of primary cilia also serves as a diffusion barrier to selectively control molecular trafficking in and out of primary cilia, allowing for maximizing the local concentration of a plethora of signaling receptors and downstream effector molecules within primary cilia. Thus, the unique configuration of primary cilia enables high levels of signaling molecules and messengers to be elicited and maintained more effectively within the narrow compartment than in other subcellular compartments,

29.

Truong, M.E. · Bilekova, S. · Choksi, S.P. ...

#### Vertebrate cells differentially interpret ciliary and extraciliary cAMP

Cell. 2021; 184:2911-2926.e18

where diffusion over a large space could lead to a rapid loss of specific signaling. Indeed, abnormal formation or function of primary cilia contributes to a large group of disorders, including brain malformations, intellectual disabilities, epilepsy, and psychiatric disorders.

19.

Singla, V. · Reiter, J.F.

The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science. 2006; 313:629-633

20.

Louvi, A. · Grove, E.A.

Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron, 2011; 69:1046-1060

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

23.

Goetz, S.C. · Anderson, K.V.

#### The primary cilium: a signalling centre during vertebrate development

Nat. Rev. Genet. 2010; 11:331-344

58.

Nigg, E.A. - Raff, J.W.

#### Centrioles, Centrosomes, and Cilia in Health and Disease

Cell. 2009; 139:663-678

Notably, it was discovered more than 60 years ago that neurons in the neocortex commonly possess primary cilia

22.

Dahl, H.A.

#### Fine Structure of Cilia in Rat Cerebral Cortex

Z. Zellforsch. Mikrosk. Anat. 1963; 60:369-386

; yet, the precise signal sensing and physiological function of these primary cilia remain largely unknown.

20.

Louvi, A. · Grove, E.A.

#### Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron, 2011; 69:1046-1060

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

59-

Tereshko, L. · Turrigiano, G.G. · SenGupta, P.

#### Primary cilia in the postnatal brain: Subcellular compartments for organizing neuromodulatory signaling

Curr. Opin. Neurobiol. 2022; 74, 102533

In this study, we reveal that the primary cilia of excitatory neurons in the PFC preferentially sense various animal stressors and regulate acute and chronic stressinduced despair or depressive-like behavioral responses. Under the condition of real or perceived stress, the HPA axis is usually activated, leading to the secretion and elevated level of CORT,

60.

Liu, W.Z. · Zhang, W.H. · Zheng, Z.H. ...

#### Identification of a prefrontal cortex-to-amygdala pathway for chronic stress-induced anxiety

Nat. Commun. 2020; 11, 2221

which appears to be more prominent in the PFC than in the sensory areas in the neocortex. Interestingly, the primary cilia in the PFC preferentially and consistently become elongated in response to various chronic animal stressors and CORT treatment, indicating that these primary cilia are capable of sensing and responding to animal stress and elevated CORT.

It is worth noting that the primary cilia in the sensory cortex (e.g., S1) or the amygdala do not exhibit any obvious change under the same behavioral or pharmacological stress conditions. It is possible that the molecular compositions of primary cilia in distinct brain regions may be different. Lipophilic CORT typically acts through two types of nuclear family receptors, MRs and GRs, and facilitates their nuclear translocation and

in the manufacture and the contribution

на сиги гединасев дене станвстарион.

17.

Mifsud, K.R. - Reul, J.M.H.M.

Mineralocorticoid and glucocorticoid receptor-mediated control of genomic responses to stress in the brain

Stress. 2018; 21:389-402

This genomic action of CORT is typically slow (tens of minutes to hours) and prolonged (hours to days). Our data show that CORT treatment leads to an elevation of cAMP level in PFC excitatory neuron primary cilia within a few minutes, suggesting a relatively rapid, non-genomic mechanism. Consistent with this, we found that membrane impermeable BSA-CORT elicits a similar primary ciliary cAMP-level increase to CORT. Together, these results suggest that CORT is capable of triggering membrane-associated signaling. Emerging evidence suggests that CORT can trigger more rapid effects via non-genomic mechanisms, e.g., GPCRs and second messenger signaling.

61.

Karst, H. · den Boon, F.S. · Vervoort, N. ...

Non-genomic steroid signaling through the mineralocorticoid receptor: Involvement of a membrane-associated receptor?

Mol. Cell. Endocrinol. 2022; 541, 111501

It is likely that membrane-associated receptors, including MRs and GRs, are involved. While primary cilia are enriched with membrane receptors and signaling transduction molecules.

19.

Singla, V. · Reiter, J.F.

The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science, 2006; 313:629-633.

23.

Goetz, S.C. · Anderson, K.V.

#### The primary cilium: a signalling centre during vertebrate development

Nat. Rev. Genet. 2010; 11:331-344

the precise molecular basis of CORT sensing in PFC excitatory neuron primary cilia remains to be elucidated. On the other hand, we cannot rule out that genomic mechanisms of CORT may also be involved in chronic stress sensing and animal behavioral response, particularly at the late stages. A previous study showed that CORT treatment leads to transcriptional regulation of a large set of ciliary genes,

62.

Mifsud, K.R. · Kennedy, C.L.M. · Salatino, S. ...

#### Distinct regulation of hippocampal neuroplasticity and ciliary genes by corticosteroid receptors

Nat. Commun. 2021; 12:4737

further suggesting a link between animal stress and primary cilia.

Our findings that CORT treatment triggers cAMP-level elevation in the primary cilia of PFC neurons and that the primary ciliary PKA activity is essential for animal stress sensing and behavioral response point to the importance of primary ciliary localized receptors in signal sensing and transduction. Moreover, our data reveal the critical role of primary ciliary PKA activity in animal stress sensing and behavioral response regulation, consistent with previous studies implicating cAMP/PKA signaling in depression-related conditions.

63.

Fujita, M. - Richards, E.M. - Niciu, M.J. ...

#### cAMP signaling in brain is decreased in unmedicated depressed patients and increased by treatment with a selective serotonin reuptake inhibitor

Mol. Psychiatry, 2017; 22:754-759

Notably, it is possible that the cytosolic and ciliary cAMP/PKA signaling may convey different information related to animal stress sensing and behavioral response, as shown recently in mediating Hedgehog signaling.

29.

Truong, M.E. · Bilekova, S. · Choksi, S.P. ...

#### Vertebrate cells differentially interpret ciliary and extraciliary cAMP

Cell. 2021; 184:2911-2926.e18

The PFC has been previously linked to animal stress and depression.

8.

Arnsten, A.F.T.

# Stress signalling pathways that impair prefrontal cortex structure and function

Nat. Rev. Neurosci. 2009; 10:410-422

9.

McEwen, B.S. · Morrison, J.H.

# The Brain on Stress: Vulnerability and Plasticity of the Prefrontal Cortex over the Life Course

Neuron. 2013; 79:16-29

In particular, the reduction in neuronal excitability in the PFC has been shown to be associated with the development of depression or the depressive-like behavioral phenotype induced by chronic animal stressors,

51.

Yuen, E.Y. · Wei, J. · Liu, W.H. ...

#### Repeated Stress Causes Cognitive Impairment by Suppressing Glutamate Receptor Expression and Function in Prefrontal Cortex

Neuron. 2012; 73:962-977

52.

Holmes, S.E. · Scheinost, D. · Finnema, S.J. ...

Lower synaptic density is associated with depression severity and network alterations

Nat. Commun. 2019; 10, 1529

į

64.

Etkin, A. · Wager, T.D.

Functional neuroimaging of anxiety: A meta-analysis of emotional processing in PTSD, social anxiety disorder, and specific phobia

Am. J. Psychiatry. 2007; 164:1476-1488

whereas activation of PFC neurons is reported to induce an anti-depressive-like effect.

65.

Covington, H.E. · Lobo, M.K. · Maze, I. ...

#### Antidepressant Effect of Optogenetic Stimulation of the Medial Prefrontal Cortex

J. Neurosci. 2010; 30:16082-16090

We found that selective removal of excitatory neuron primary cilia in the PFC with different molecular manipulations (i.e., Cep83 and Ttbk2 cKO) suppresses animal stress sensing and acute and chronic behavioral responses, including depressive-like phenotypes. Moreover, loss of primary cilia also disrupts chronic stress-induced excitatory synapse loss and CORT-induced neuronal excitability reduction in the PFC preferentially. Cep83 encodes a centrosomal protein that is crucial for the assembly of mother centriole distal appendages necessary for centriole membrane dockage and primary cilium formation. On the other hand, Ttbk2 encodes a serine/threonine kinase that is the key regulator of the assembly and maintenance of primary cilia. These findings suggest that the effects on animal stress sensing and behavioral response depend on primary cilia but not on CEP83 or TTBK2 per se, which represent two highly different proteins with distinct functions. Moreover, these findings indicate that primary ciliary signaling and function affect neuronal excitability. Recent studies reveal the formation of synaptic structure between neuronal processes and primary cilia, as well as the proximity in spatial organization between primary cilia and neuronal synapses.

66.

Wu, J.Y. · Cho, S.J. · Descant, K. ...

Mapping of neuronal and glial primary cilia contactome and connectome in the human cerebral cortex

Neuron, 2024; 112:41-55.e3

67.

Sheu, S.H. · Upadhyayula, S. · Dupuy, V. ...

A serotonergic axon-cilium synapse drives nuclear signaling to alter chromatin accessibility

Cell. 2022; 185:3390-3407.e18

68.

Ott, C.M. · Torres, R. · Kuan, T.-S. ...

Nanometer-scale views of visual cortex reveal anatomical features of primary cilia poised to detect synaptic spillover

Preprint at bioRxiv. 2023;, 2023.10.31.564838

It would be interesting to explore the molecular and physiological bases as well as temporal dynamics of the regulation of neuronal excitability by primary cilia.

69.

Tereshko, L. - Gao, Y. - Cary, B.A. ...

Ciliary neuropeptidergic signaling dynamically regulates excitatory synapses in postnatal neocortical pyramidal neurons

eLife. 2021; 10, e65427

The functions of primary cilia in early embryonic development and neural progenitors have been well established.

31.

Liu, S. - Trupiano, M.X. - Simon, J. ...

The essential role of primary cilia in cerebral cortical development and

#### disorders

Curr. Top. Dev. Biol. 2021; 142:99-146

32.

Han, Y.G. - Alvarez-Buylla, A.

#### Role of primary cilia in brain development and cancer

Curr. Opin. Neurobiol. 2010; 20:58-67

70.

Huangfu, D.W. · Liu, A.M. · Rakeman, A.S. ...

#### Hedgehog signalling in the mouse requires intraflagellar transport proteins

Nature. 2003; 426:83-87

Nonetheless, primary cilia in the mature brain have long been considered evolutionary remnants of little consequence.

20.

Louvi, A. · Grove, E.A.

#### Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron. 2011; 69:1046-1060

21.

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

59-

Tereshko, L. · Turrigiano, G.G. · SenGupta, P.

Primary cilia in the postnatal brain: Subcellular compartments for organizing neuromodulatory signaling

Curr. Opin. Neurobiol. 2022; 74, 102533

Recent evidence, however, indicate that they play vital functions in various contexts, such as body weight regulation,

98.

Siljee, J.E. · Wang, Y. · Bernard, A.A. ...

Subcellular localization of MC4R with ADCY3 at neuronal primary cilia underlies a common pathway for genetic predisposition to obesity

Nat. Genet. 2018; 50:180-185

eireadian eloek,

71.

Tu, H.Q. - Li, S. - Xu, Y.L. ...

Rhythmic cilia changes support SCN neuron coherence in circadian clock

Science. 2023; 380:972-979

and serotonin signal transduction.

67.

Sheu, S.H. · Upadhyayula, S. · Dupuy, V. ...

A serotonergic axon-cilium synapse drives nuclear signaling to alter chromatin accessibility

Cell. 2022; 185:3390-3407.e18

Notably, these diverse functions involve primary cilia in distinct types of neurons in different brain regions. It is likely that primary cilia throughout the mature nervous system play additional important physiological functions. Our findings identify key roles of excitatory neuron primary cilia in the PPC in sensing and regulating animal stress and demonstrate that manipulating primary ciliary PKA activity affects acute and chronic stress responses.

#### Resource availability

#### Lead contact

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Song-Hai Shi (shisonghai@mail.tsinghua.edu.cn).

#### Materials availability

All plasmids, reagents, and transgenic mice used in this study are available from the .

#### Data and code availability

٠

Data reported in this paper will be shared by the upon request.

\*

This paper does not report any original code.

.

Any additional information required to reanalyze the data reported in this paper is available from the upon request.

#### Acknowledgments

This work was supported by STI2030-Major Projects (2021ZD0202300), National Natural Science Foundation of China (32021002), Beijing Outstanding Young Scientist Program (BJJWZYJH01201910003012), Beijing Municipal Science & Technology Commission (Z211100003321001 and Z221100003422011), Chinese Institute for Brain Research (Beijing), New Cornerstone Investigator Program and Tsinghua University Initiative Scientific Research Program.

#### Author contributions

J.Y., H.S., and S.-H.S. conceived the project; J.Y. performed the majority of the experiments and data analyses with support from Y.D., J. Li, L.L., and J.M.; J. Liu performed the electrophysiological recoding experiments; Y.P. performed the electron microscopy experiment; Y.D. engineered the virus with help from D.W. and X.H.; Y.D., I.V. and I. Li performed live-cell invaring experiments. I.W. and I.C. developed C.

оль, шисты реголисских сен инидиц сересиненов или листово четогорого-

Flamp3; J.Y. and S.-H.S. wrote the paper with input from all other authors.

#### Declaration of interests

The authors declare no competing interests.

#### STAR★Methods

#### Key resources table

| REAGENT or<br>RESOURCE | SOURCE         | IDENTIFIER                                 |
|------------------------|----------------|--------------------------------------------|
| Antibodies             |                |                                            |
| chicken anti-GFP       | Aves           | Cat #GFP-1020; RRID:<br>AB_10000240        |
| rat anti-CTIP2         | Abcam          | Cat #18465; RRID: <u>AB_2064130</u>        |
| rabbit anti-CUX1       | Santa Cruz     | Cat #SC-13024; RRID: AB_2261231            |
| rabbit anti-CEP83      | Sigma- Aldrich | Cat #HPA038161; RRID:<br>AB_10674547       |
| rabbit anti-AC3        | Abcam          | Cat #AB125093; RRID:<br><u>AB_10975307</u> |
| rabbit anti-MCHR1      | Invitrogen     | Cat #702618; RRID: <u>AB_2734816</u>       |
| rabbit anti-PSD-95     | Abcam          | Cat #AB18258; RRID: <u>AB_444362</u>       |
| mouse anti-PV          | Sigma          | Cat #P3088; RRID: <u>AB_477329</u>         |
| goat anti-SOM          | Santa Cruz     | Cat #SC-7819; RRID: AB_2302603             |
| mouse anti-NeuN        | Merk           | Cat #FCMAB317PE; RRID:<br>AB_10807694      |
| rat anti-HA            | Roche          | Cat #11864723001; RRID:<br>AB_390918       |
| Alexa Flour 488-       | Jackson Immuno | Cat #703-546-155; RRID:                    |

| chicken IgG                                   | Research                    | AB_2340376                            |
|-----------------------------------------------|-----------------------------|---------------------------------------|
| Alexa Flour 488-<br>donkey anti-rabbit<br>IgG | Thermo Fisher<br>Scientific | Cat #A-21206; RRID: <u>AB_141708</u>  |
| Alexa Flour 488-<br>donkey anti-mouse<br>IgG  | Thermo Fisher<br>Scientific | Cat #A-21202; RRID: <u>AB_141607</u>  |
| Alexa Fluor 555<br>donkey anti-rabbit<br>IgG  | Thermo Fisher<br>Scientific | Cat #A-21432; RRID: <u>AB_141788</u>  |
| Alexa Fluor 555<br>donkey anti-mouse<br>IgG   | Thermo Fisher<br>Scientific | Cat #A-31570; RRID: <u>AB_2536180</u> |
| Alexa Fluor 594<br>donkey anti-rat<br>IgG     | Thermo Fisher<br>Scientific | Cat #A-21209; RRID: <u>AB_2535795</u> |
| Alexa Fluor 647-<br>donkey anti-goat<br>IgG   | Thermo Fisher<br>Scientific | Cat #A-21447; RRID: <u>AB_141844</u>  |
| Bacterial and viru                            | is strains                  |                                       |
| DH5a Chemically<br>Competent Cell             | TSINGKE                     | Cat #TSC-C14                          |
| TransStbl3<br>Chemically<br>Competent Cell    | TransGen Biotech            | Cat #CD521-02                         |
| rAAV9-CaMKΠα-<br>EGFP-P2A-CRE-<br>WPRE-hGH pA | BrainVTA                    | Cat #PT-0198                          |
| rAAV9-CaMKΠα-<br>EGFP-WPRE-hGH<br>pA          | BrainVTA                    | Cat #PT-0290                          |
| -A 4320 (0-3497)                              |                             |                                       |

| ARL13B(T35N)-<br>dnPKA-HA-<br>WPRE-hGH                     | This study                                                    | N/A                                 |
|------------------------------------------------------------|---------------------------------------------------------------|-------------------------------------|
| rAAV9-CaMKIIa-<br>ARL13B(T35N)-<br>PKIa-HA-WPRE-<br>bGH    | This study                                                    | N/A                                 |
| rAAV9-CaMKIIa-<br>ARL13B(T35N)-<br>PKIamut-HA-<br>WPRE-hGH | This study                                                    | N/A                                 |
| Chemicals, peptio                                          | des, and recombinant p                                        | oroteins                            |
| DAPI                                                       | Invitrogen                                                    | Cat #D1306; RRID: <u>AB_2629482</u> |
| Corticosterone                                             | Abcam                                                         | Cat #ab143597                       |
| BSA-conjugated<br>Corticosterone                           | Alpha Diagnostic<br>International                             | Cat #CSTBSA-1                       |
| DMSO                                                       | Sigma- Aldrich                                                | Cat #D4540                          |
| Forskolin                                                  | MedChemExpress                                                | Cat #HY-15371                       |
| Experimental mo                                            | dels: Cell lines                                              |                                     |
| Human: HEK293T<br>cells                                    | American Type Culture<br>Collection                           | Cat #CRL-3216                       |
| Mouse: primary<br>prefrontal cortical<br>neuron culture    | This study                                                    | N/A                                 |
| Experimental mo                                            | dels: Organisms/strain                                        | ns                                  |
| Mouse:<br>C57BL/6JTshu                                     | Laboratory animal<br>resources center,<br>Tsinghua University | Labcode: Tshu                       |
|                                                            | Shao et al.                                                   |                                     |

|                              | Goebbels, S. · Bormuth, I. · Bode, U                                                                                                                                                                       |     |
|------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Mouse: Cep83 <sup>R/JI</sup> | Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice  Genesis. 2006; 44:611-621  Crossref  Scopus (403)  PubMed  Google Scholar                                             | N/A |
| Mouse: Ttbk::///l            | Kathryn V. Anderson<br>Lab                                                                                                                                                                                 | N/A |
| Mouse: Nex-Cre               | Goebbels et al.  41.  Goebbels, S. · Bormuth, I. · Bode, U  Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice  Genesis. 2006; 44:611-621  Crossref  Scopus (403)  PubMed | N/A |

|                                           | Google Scholar                                                                                                                                                  |                                                  |
|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------|
| Mouse:<br>Cep83 <sup>fl/fl</sup> ;Nex-Cre | This study                                                                                                                                                      | N/A                                              |
| Mouse:<br>Ttbka <sup>fl/fl</sup> ;Nex-Cre | This study                                                                                                                                                      | N/A                                              |
| Recombinant DN                            | A                                                                                                                                                               |                                                  |
| M7 pdnPKA-GFP                             | Addgene                                                                                                                                                         | Cat #102356                                      |
| pCAG-G-Flamp3                             | This study                                                                                                                                                      | N/A                                              |
| pCAG-<br>ARL13B(T35N)-G-<br>Flamp3        | This study                                                                                                                                                      | N/A                                              |
| Software and algo                         | orithms                                                                                                                                                         |                                                  |
| ZEN                                       | Zeiss                                                                                                                                                           | N/A                                              |
| FV31S-DT                                  | Olympus                                                                                                                                                         | N/A                                              |
| IMARIS                                    | Bitplane                                                                                                                                                        | v9.9.1                                           |
| Ethovision XT                             | Noldus                                                                                                                                                          | v11.5                                            |
| ImageJ                                    | Schneider et al.  72.  Schneider, C.A.  Rasband, W.S.  Eliceiri, K.W.  NIH Image to ImageJ: 25 years of image analysis  Nat. Methods. 2012; 9:671-675  Crossref | Software:<br>https://imagej.net/software/imagej/ |

|       | Scopus (47578)  PubMed  Google Scholar |    |
|-------|----------------------------------------|----|
| Prism | GraphPad                               | v7 |

<sup>\*</sup> Open table in a new tab

#### Experimental model and study participant details

#### Mice

The Cep83<sup>fl/fl</sup> and Nex-Cre mouse lines were generated as previously described 40.

Shao, W. · Yang, J.J. · He, M. ...

# Centrosome anchoring regulates progenitor properties and cortical formation

Nature. 2020; 580:106-112

41.

Goebbels, S. · Bormuth, I. · Bode, U. ...

# Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice

Genesis. 2006; 44:611-621

; The Ttbk2/1/fl mouse line

45-

Goetz, S.C. · Liem, K.F. · Anderson, K.V.

The Spinocerebellar Ataxia-Associated Gene Tau Tubulin Kinase 2 Controls the Initiation of Ciliogenesis was originally provided by Dr. Kathryn V. Anderson (Memorial Sloan Kettering Cancer Center, New York). The C57BL/6J mice and the ICR mice were obtained from Laboratory Animal Resource Center, Tsinghua University. Genotyping was carried out using standard PCR protocols. Both male and female mice were used unbiasedly in the non-behavioral analyses. For the behavioral analyses, male mice at 10–16 weeks of age were used by default unless specially noted. The mice were maintained in the facilities of Tsinghua University in a 12-hour light-dark cycle, and all animal experiments and procedures were approved by the Institutional Animal Care and Use Committee (IACUC).

#### Primary neuron cultures

Primary cultures of prefrontal neurons were isolated from a mixed-gender litter of ICR mice at postnatal day o (Po). Pups were anesthetized on ice and decapitate in ice-cold DPBS. Prefrontal cortex tissue was dissected into dissection medium (1 mM sodium pyruvate, 20 mM glucose, and 10 mM HEPES in HBSS) under stereo-microscope. Brain tissue was digested with dissociation medium (0.2 mg/mL Papain and 0.06 mg/mL DNase I in Neuronbasal-A) for 15 min under 37 °C, and washed 2 times with stop medium (HBSS with 10% FBS) and centrifugated for 5 min under 350 × g. Neurons were resuspended with culture medium (Neurobasal-A with B-27, Glutamax and 1% Penicillin-Streptomycin) and triturated gently by fire-polished glass Pasteur pipette. Neuron number was counted by hemocytometer and re-centrifuge for 5 min under 350 × g. The pellet was resuspended with adjusted volume of culture medium. Neurons were then plated on glass-bottom dishes (pre-coat with 0.1 mg/mL P-D-L and 0.06 mg/ml collagen overnight under 37 °C, wash 3 times with sterile water before use). About 2-3 hours after plating, 90% of the culture medium was refreshed to avoid floating cells. About 50% culture medium was refreshed every 2-3 days.

#### Method details

#### Brain Sectioning, Immunofluorescence, and Imaging

Mice were perfused intracardially with ice-cold phosphate-buffered saline (PBS, pH 7.4), followed by 4% paraformaldehyde (PFA) in PBS (pH 7.4). Brains were post-fixed with 4% PFA at 4 °C for about 6 hours, cryo-protected, and sectioned at 20, 60, or 100 μm using cryostat (CM3050S, Leica) or microtome (VT1200S, Leica) for immunofluorescence, as previously described.

# Centrosome anchoring regulates progenitor properties and cortical formation

Nature. 2020; 580:106-112

Primary antibodies are incubated in 4 °C for 12~16 hours and secondary antibodies are incubated in room temperature for 2~4 hours. Brain sections were mounted on glass slides, imaged using confocal microscopy (FV3000, Olympus) or slide scanner (Axio Z1, Zeiss). Cortical areas were identified based on the Allen Brain Atlas (<a href="http://mouse.brain-map.org/static/atlas">http://mouse.brain-map.org/static/atlas</a>). Images were analyzed by ZEN (Zeiss), FV31S-DT (Olympus), IMARIS (Bitplane) or ImageJ (<a href="imagej.net/software/imagej/">imagej.net/software/imagej/</a>). 3D reconstruction of primary cilia from brain section images was processed with IMARIS.

#### Serial Block-Face Scanning Electron Microscopy

Anesthetized mice were perfused with 15 mL preheated 0.15 M cacodylate buffer (pH 7.4) followed by 80 mL fixative solution (2% PFA, 1.25% glutaraldehyde, 2 mM CaCl2 in 0.08 M cacodylate buffer). Brains were dissected, post-fixed at 4 °C for 24 hours, and 1 mm tissue punches were extracted and fixed in fresh fixative solution for an additional 24-48 hours at 4 °C. Tissue blocks were washed three times with cacodylate buffer (0.15 M, 2 mM CaCl<sub>0</sub>), incubated in 2% osmium tetroxide for 1.5 hours, and treated with 2.5% potassium ferricyanide for 1.5 hours. After rinsing in cacodylate buffer, blocks were incubated in 0.8% thiocarbohydrazide at 58 °C for 45 minutes, rinsed in ddH2O, postfixed in 2% osmium tetroxide for 1.5 hours, and stained overnight at 4 °C in 1% uranyl acetate before incubation in a 50 °C water bath for 2 hours. Following rinses in ddH<sub>2</sub>O, blocks were treated with 0.02 M lead aspartate at 50 °C for 2 hours, dehydrated through graded ethanol and 100% propylene oxide, infiltrated with SPI 812 resin (sequentially in the ratios: 3:1, 1:1, and 1:3), embedded, cured at 60 °C for 72 hours, and prepared for imaging. The tissue block was trimmed into a 1500 × 1500 × 1000 μm<sup>3</sup> using a glass knife and adhered to an aluminum pin with super glue. A 45°-angled diamond knife (Trim 45, DiATOME) was employed to shape the block into a trapezoid with a 400 × 400 μm<sup>2</sup> top surface and 500 μm height, followed by additional trimming with a 90°angled diamond knife (Trim 90, DiATOME). The top surface was then precisely trimmed into a 400 × 300 × 200 µm3 volume using a glass knife and a right-angled diamond knife (Trim 90, DiATOME) before coating the specimen with platinum (EM ACE 600, Leica). Serial image acquisition was conducted using a backscatter electron (BSE) detector on a Carl Zeiss Gemini 300 scanning electron microscope. Images were captured at a resolution of 12000 × 10000 voxels, with an in-plane pixel size of 5 × 5 nm, a dwell time of 1.5 μsec, and a nominal cutting thickness of 50 nm.

#### Behavioral Analyses

Mice in normal feeding conditions were housed in 4-6 males per cage. For assessing anxiety and stress level, mice were subjected to a series of tests: the open field test (OFT), the light-dark transition test (LDT), the tail suspension test (TST), and the forced swim test (FST). In addition, other groups of mice were subjected to the three-chamber social test, the Morris water maze test, the locomotor activity test, and the fear conditioning test.

OFT: The open field arenas were made with white acrylic boxes ( $50 \times 50 \times 50 \times 50$  cm). Mice were habituated in the testing room for over 1 hour prior to the test. Mice were then individually placed in the middle of the arenas under red light for 10 minutes (2 hours for testing the spontaneous locomotor activity). Videos recorded from the top were analyzed using Noldus Ethovision XT (version 11.5, Noldus Interactive technologies) to measure the crossing number and the exploring time in the center zone ( $25 \times 25$  cm). The test was performed in the dark-phase of the animal circadian cycle.

LDT: Two equal-sized boxes made of white acrylics (20 × 20 × 25 cm) were connected with a rectangular transition gate (6 × 7 cm). The dark box was coated with black wallpaper and covered with a lid during testing. Mice were habituated in the testing room for over 1 hour and then placed in the middle of the light box with their heads to the opposite direction of the transition gate. Mice were allowed to explore for 10 minutes under dim light. Videos recorded from the top were analyzed using Noldus Ethovision XT to measure the transition frequency and the exploring time in the light box. The test was performed in the dark-phase of the animal circadian cycle.

TST: The tail suspension box was made of white acrylics ( $60 \times 11 \times 55$  cm) with four chambers ( $15 \times 11 \times 55$  cm) opening from the top and the front. A metal bar was placed on the top of the box across the four chambers. Mice were habituated in the room for over 1 hour before the test. During the test, mice in groups of four were hanged by fixing the tail on the mental bar with adhesion tapes for 6 minutes under dim light. Videos were analyzed by double-blinded operators to measure the immobility time during the  $2^{\rm nd}$  to  $6^{\rm th}$  minute. The test was performed in the light-phase of the animal circadian cycle.

FST: Plexiglass cylinders (20 cm in diameter and 30 cm in height) with the opening from top were filled with water to two-thirds of its capacity. Mice were habituated in the room for over 1 hour and then placed gently to the surface of the water to freely swim for 6 minutes under dim light. Videos were analyzed by double-blinded operators to measure the immobility time during the 2<sup>nd</sup> to 6<sup>th</sup> minute. Mice with abnormal swimming postures were excluded from the analysis. The test was performed in the light-phase of the animal circadian cycle.

Three-chamber social test: An open-top box made with acrylics ( $60 \times 40 \times 25$  cm) was divided into 3 adjacent chambers ( $40 \times 20 \times 25$  cm) with transition gates ( $10 \times 10$  cm). Two acrylic cylinder cages (11 cm in diameter and 21 cm in height) with transparent bars were placed at the opposite corners of the entire box (in the first and third chambers). Mice were habituated in the testing room for 1 hour prior to the test. During the test, mice were subjected to three serial testing phases in the following order: habituation, social preference, and social novelty. In the habituation phase, the cages in corners were both empty. In the social preference phase, one stranger male was placed to a random cage. In the social novelty phase, another stranger male was placed to the other cage. The testing mice were placed in the center of the middle chamber and allowed to explore for 10 minutes under red light in each test phase. Videos recorded from the top were analyzed using Noldus Ethovision XT to record the time spent in each chamber. The test was performed in the dark-phase of the animal circadian cycle.

Morris water maze test: An open-top cylinder tank (1.2 m in diameter and 0.4 m in height) was filled with water to about three quarters of its capacity. Titanium dioxide pigment was added to opacify the water and the water was heated to 26 ± 2 °C. Four different patterns of black & white graphics were placed on the top of the inner wall of the water tank in four quadrants as visual cues. During training, a plastic platform (10 cm in diameter and 25 cm in height) was placed in a fixed position of the tank (near the center of a certain quadrant). The surface of the water was kept 1-2 cm higher than the platform. Mice were individually released from the edge of one random quadrant and allowed to freely swim till finding the platform. If the mouse could not reach the platform in 5 minutes, the operator would guide the mouse to the platform. Animals were trained for four times from every quadrant edge in a random manner in each training day. Videos were analyzed using Noldus Ethovision XT to measure the latency to find the platform. After 5-day training, mice were tested for their spatial memory without the platform. Mice were released from the farthest edge to the original platform position and allowed to freely swim for 5 minutes. Videos were analyzed using Noldus Ethovision XT to measure the latency to the first arrival to the original platform position, the frequency to cross the platform zone (20 cm diameter cycle around the original platform position), the average distance to the center of the platform at each moment, and the time spent in the platform zone. The test was performed in the lightphase of the animal circadian cycle.

CRS: Mice were singly housed for 7 days for habituation. The 50 mL centrifuge tubes (NEST, 602052) were used as the restraint apparatus. Holes were made at the bottom and side of the tubes to ensure aeration. Mice were placed into the tubes with their head

towards to the pottom. Cotton pails were used to hit the residual space to hix mouse regs. Mice were then placed horizontally for 2 hours in the light phase of the animal circadian cycle. After 14-day restraint, mice were subjected to the following behavioral tests: TST, FST, and the sucrose preference test (SPT).

SPT: Mice were singly housed for over 1 week before the test. Plain or 1% sucrose water was equally supplied with modified 15 mL centrifugal tubes with mental nozzles. Mice were applied with two tubes in random direction for 2 days to habituate the sucrose water. In the testing day, mice were fasted for 24 hours and the liquid consumed in next 24 hours were recorded.

CSDS: Mice were individually housed for 7 days for habituation. Singly housed ICR male mice retired from the breeding cage were used as aggressors and housed in a special cage after screening for their aggressiveness. The cage was separated into two chambers by a transparent acrylic plate with holes to allow visual and olfactory information delivery. Experimental mice were placed with the aggressor mice for 5 minutes and then housed in the other chamber for the remaining time in a day. Mice were arranged to different aggressors each day for 10 days. The behavioral tests, including the social interaction test (SIT), FST, and SPT, were then conducted.

SIT: An acrylic cylinder cage (11 cm in diameter and 21 cm in height) with transparent bars was placed in the top middle of the open field arena. Experimental mice were placed to the center of the arena and allowed explore for 5 minutes. During a 10-minute interval, a naïve ICR male was placed in the social cage and experimental mice were placed in the arena again for another 5-minute exploration. Videos were analyzed using Noldus Ethovision XT to measure the time spent around the social cage.

Fear conditioning test: Mice were placed into environment A with particular odor, light and visual clues for 2 minutes at the start of training (day 1), then 6 trials contains 20 seconds tone coupling with foot shock at the last 2 seconds were performed with 40 seconds interval. After 24 hours (day 2), mice were placed into environment A for 5 minutes to assess their freezing behavior to the environment. In day 3, mice were placed into environment B with distinct odor, light and visual clues for 5 minutes. The same tone is giving during the 2<sup>nd</sup> and 4<sup>th</sup> minutes to evaluate the cue-associated fear memory. In day 8, mice were again placed into environment A for 5 minutes to measure their remote memory to the original context.

Chronic CORT administration: CORT (1.25 mg/mL) was dissolved in 40% propylene glycol in PBS. Fresh CORT solution was injected intraperitoneally in a volume of 200  $\mu$ L per 25 g body weight to reach a final dose of 20 mg/kg. Mice were injected saline (with 40% propylene glycol) or CORT for 21 days and then subjected to behavioral tests, including TST, FST, and SPT.

Serum CORT measurement: Mice from their home-cage or after a 2-hour restraint stress were anesthetized by isoflurane. About 5-20 µL blood was collected from the tail tip by a heparinized capillary tube and transferred to a microcentrifuge tube. After standing in room temperature for about 1 hour, serum was isolated by centrifugation at 3000 rpm for 10 minutes and kept in -20 °C. CORT concentration was measured by ELISA kit (Thermo Fisher, EIACORT) following the guideline.

#### Electrophysiology

Mice were anesthetized with 4% avertin and perfused with ice-cold cutting solution (120 mM choline chloride, 2.6 mM KCl, 26 mM NaHCO3, 1.25 mM NaH2PO4, 0.5 mM CaCl2, 7 mM MgCl2, 1.3 mM sodium ascorbate and 15 mM glucose, pre-bubbled with 95% oxygen/5% carbon dioxide). Brains were dissected and sectioned into 300 μm slices in ice-cold cutting solution bubbled with 95% oxygen/5% carbon dioxide using a vibratome (VT1200S, Leica Microsystems). Brain slices were then transferred to artificial cerebral spinal fluid (ACSF) solution (126 mM NaCl, 3 mM KCl, 26 mM NaHCO2, 1.2 mM NaH2PO4, 2.4 mM CaCl2, 1.3 mM MgCl2 and 10 mM glucose, saturated with 95% oxygen/5% carbon dioxide) in 32-34 °C to recovery for 30 min before recording. A pulled-glass pipette with 3-5 M $\Omega$  resistance with inner solution (120 mM potassium gluconate, 2 mM KCl, 2 mM MgCl2, 0.2 mM EGTA, 10 mM HEPES, 4 mM Na2ATP, 0.4 mM Na2GTP, 10 mM phosphocreatine-2K and 0.3% neurobiotin, pH 7.20-7.35, 290-295 mOsm/kg) was used to patch neurons. An infrared differential interference contrast (IR-DIC) microscope (Olympus) equipped with two waterimmersion lenses (10× and 60×) was used to target excitatory neurons in specific brain areas based on their pyramidal sharp and the major apical dendrite. Resting membrane potential was recorded under current clamp. For assessing electrophysiological features. current was injected from -100 pA (1 second) with 10 pA-step increase till triggering action potential (AP). Input resistance was calculated from the I/V curve. Rheobase current was the current to trigger first AP. For analyzing the firing rate, 0-600 pA currents (1 second) with 50-pA steps in 8-second intervals were injected into the neuron and the number of APs were recorded and analyzed. Data were recorded and analyzed using the Axon Multiclamp 700B amplifier and the pCLAMP10 software (Molecular Devices). For mEPSC recording, patch pipettes were filled with an Cs+-based inner solution (115 mM CsMeSO<sub>2</sub>, 20 mM CsCl, 10 mM HEPES, 2.5 mM MgCl<sub>2</sub>, 4 mM Na<sub>2</sub>ATP, 0.4 mM NaGTP, 10 mM Na-phosphocreatine, 0.6 mM EGTA, pH 7.20-7.35, 290-295 mOsm/kg). Neurons were held at -70 mV under voltage-clamp mode and 500 nM Tetrodotoxin (TTX) is added to the bath solution to block action potential. A 3minute recording was used to calculated the frequency and amplitude of mEPSC, and neurons with series resistance (Rs) over 30 pA are excluded. Data were filtered at 2 kHz

#### Primary Ciliary cAMP Level Measurement

For validating the efficiency of G-Flamp3 indicator, G-Flamp3 plasmid under CAG promoter was generated, and HEK293T cells were transfected by Lipofectamine 2000 (Invitrogen) and imaged under FV3000 (Olympus). To detect G-Flamp3 signal, laser excitation wavelength was set at 488 nm and detection wavelength was set to 500-540 nm. 0.05% DMSO or 60 µM Forskolin were treated on cells cultured with Fluorobrite DMEM (with 10 mM HEPES, pH 7.3) separately to obverse the response. For measuring primary ciliary cAMP level in prefrontal neurons, primary neurons were dissected from Po ICR mouse prefrontal cortex. At 6~7 days in vitro (DIV), neurons were transfected with Ciliary-G-Flamp3 plasmid (pCAG-ARL13B(T35N)-G-Flamp3) by Lipofectamine 2000 (Invitrogen). Live imaging of cAMP level was performed at DIV 8~10 under FV3000 (Olympus). Excitatory neurons are identified from primary culture by morphological features and spines. For time-lapse imaging, culture medium was switched to Fluoroborite DMEM (with 10 mM HEPES, pH 7.3) to reduce background. CORT or BSA-CORT was added during imaging at a final concentration of 2400 ng/mL. Forskolin (60 µM) was treated at the end to exclude any non-responding neurons.

#### Stereotaxic Virus Injection

Mice were anesthetized with isoflurane (4% for induction and 1% for maintenance) and placed into a stereotaxic apparatus. Anesthetized mice were injected subcutaneously with meloxicam (4 mg/kg) for postoperative care. Mouse skull was exposed and calibrated using bregma and lambda points. Small holes were drilled at designed position for injection. A microliter syringe (WPI) was used with microinjection pump to deliver viral solution at 40 nL/min. The syringe was withdrawn 5 minutes after injection, rAAV was injected into PFC at four sites to ensure the coverage (200 nL per site, bregma: anteroposterior (AP): 0.8 mm and 1.95 mm, mediolateral (ML): ± 0.3 mm and ± 0.25 mm, dorsoventral (DV): -1.8 mm and -2.0 mm). Mice were allowed to recover from the stereotaxic surgery for over 14 days before further analyses. The accuracy of rAAV injection was confirmed by histological analysis after behavioral tests. Mice injected at incorrect positions or with little expression signal were excluded from further analysis, rAAV9-CaMKIIa-EGFP-WPRE-hGH pA (described as rAAV-EGFP; PT-0290) and rAAV9-CaMKIIa-EGFP-P2A-CRE-WPRE-hGH pA (described as rAAV-EGFP/Cre; PT-0198) were purchased from BrainVTA. rAAV9-CaMKIIa-ARL13B(T35N)-dnPKA-HA-WPRE-hGH (described as rAAV-Ciliary-dnPKA), rAAV9-CaMKIIo-ARL13B(T35N)-PKIo-HA-WPRE-hGH (described as rAAV-Ciliary-PKIo), and rAAV9-CaMKIIa-ARL13B(T35N)-PKlumut-HA-WPRE-hGH (described as rAAV-Ciliary-PKIomut) were generated in our lab.

------, - -----------------------------

#### Quantification and statistical analysis

Mice subjected to the analyses were littermates and age-matched. Sample size was determined to be adequate based on the magnitude and consistency of measurable differences between groups. Statistical significance was determined using Chi-square, two-way ANOVA, two-sided non-parametric Mann-Whitney-Wilcoxon or Kolmogorov-Smirnov test, and the test results were given as exact values in the figures or figure legends. Statistical significance was defined as p < 0.05. Statistical tests were performed using Prism (version 7, GraphPad). Specifically, for calculating the p values of Kolmogorov-Smirnov tests on ciliary length distributions, N numbers were corrected to a fix value approximately equals to the average number of cilia within each region of interest to avoid overestimation by large data size. Effect sizes were calculated using the Pearson's r (the Chi-square), r (DFn, DFd) (two-way ANOVA), r (r 1 and r 2) (the Mann-Whitney-Wilcoxon test), or r (the Kolmogorov-Smirnov test). Values in the bar graphs indicate mean r SEM.

#### Supplemental information (2)

Document St. Figures St-Sto

Document S2. Article plus supplemental information

#### References

de Kloet, E.R. - Joëls, M. - Holsboer, F.

Stress and the brain:: From adaptation to disease

Nat. Rev. Neurosci. 2005; 6:463-475

McEwen, B.S.

Physiology and neurobiology of stress and adaptation: Central role of the brain

Physiol. Rev. 2007; 87:873-904

Lupien, S.J. · McEwen, B.S. · Gunnar, M.R. ...

Effects of stress throughout the lifespan on the brain, behaviour and cognition

Nat. Rev. Neurosci. 2009; 10:434-445

Joëls, M. · Baram, T.Z.

#### OPINION The neuro-symphony of stress

Nat. Rev. Neurosci. 2009; 10:459-466

McEwen, B.S. · Nasca, C. · Gray, J.D.

#### Stress Effects on Neuronal Structure: Hippocampus, Amygdala, and Prefrontal Cortex

Neuropsychopharmacology. 2016; 41:3-23

Colyn, L. · Venzala, E. · Marco, S. ...

#### Chronic social defeat stress induces sustained synaptic structural changes in the prefrontal cortex and amygdala

Behav. Brain Res. 2019; 373, 112079

Lüthi, A. · Lüscher, C.

#### Pathological circuit function underlying addiction and anxiety disorders

Nat. Neurosci. 2014; 17:1635-1643

Arnsten, A.F.T.

# Stress signalling pathways that impair prefrontal cortex structure and function

Nat. Rev. Neurosci. 2009; 10:410-422

McEwen, B.S. · Morrison, J.H.

# The Brain on Stress: Vulnerability and Plasticity of the Prefrontal Cortex over the Life Course

Neuron. 2013; 79:16-29

Wang, M.H. · Perova, Z. · Arenkiel, B.R. ...

#### Synaptic Modifications in the Medial Prefrontal Cortex in Susceptibility and Resilience to Stress

J. Neurosci. 2014; 34:7485-7492

Kang, H.J. · Voleti, B. · Hajszan, T. ...

Decreased expression of synapse-related genes and loss of synapses in major depressive disorder

Nat. Med. 2012; 18:1413-1417

Martins-de-Souza, D. · Guest, P.C. · Harris, L.W. ...

Identification of proteomic signatures associated with depression and psychotic depression in post-mortem brains from major depression patients

Transl. Psychiatry. 2012; 2, e87

Moda-Sava, R.N. · Murdock, M.H. · Parekh, P.K. ...

Sustained rescue of prefrontal circuit dysfunction by antidepressantinduced spine formation

Science, 2019; 364:eaat8078

Radley, J.J. · Rocher, A.B. · Miller, M. ...

Repeated stress induces dendritic spine loss in the rat medial prefrontal cortex

Cereb. Cortex. 2006; 16:313-320

Munck, A. · Guyre, P.M. · Holbrook, N.J.

Physiological Functions of Glucocorticoids in Stress and Their Relation to Pharmacological Actions

Endocr. Rev. 1984; 5:25-44

Keller, J. · Gomez, R. · Williams, G. ...

HPA axis in major depression: cortisol, clinical symptomatology and genetic variation predict cognition

Mol. Psychiatry, 2017; 22:527-536

Mifsud, K.R. - Reul, J.M.H.M.

Mineralocorticoid and glucocorticoid receptor-mediated control of

#### genomic responses to stress in the brain

Stress. 2018; 21:389-402

Groeneweg, F.L. · Karst, H. · de Kloet, E.R. ...

# Rapid non-genomic effects of corticosteroids and their role in the central stress response

J. Endocrinol. 2011; 209:153-167

Singla, V. · Reiter, J.F.

#### The primary cilium as the cell's antenna: Signaling at a sensory organelle

Science, 2006; 313:629-633

Louvi, A. · Grove, E.A.

#### Cilia in the CNS: The Quiet Organelle Claims Center Stage

Neuron. 2011; 69:1046-1060

Guemez-Gamboa, A. · Coufal, N.G. · Gleeson, J.G.

#### Primary cilia in the developing and mature brain

Neuron. 2014; 82:511-521

Dahl, H.A.

#### Fine Structure of Cilia in Rat Cerebral Cortex

Z. Zellforsch. Mikrosk. Anat. 1963; 60:369-386

Goetz, S.C. · Anderson, K.V.

#### The primary cilium: a signalling centre during vertebrate development

Nat. Rev. Genet. 2010; 11:331-344.

Satir, P. · Christensen, S.T.

#### Overview of structure and function of mammalian cilia

Annu. Rev. Physiol. 2007; 69:377-400

Hilgendorf, K.I. · Johnson, C.T. · Jackson, P.K.

The primary cilium as a cellular receiver: organizing ciliary GPCR signaling

Curr. Opin. Cell Biol. 2016; 39:84-92

Schmid, A. · Sutto, Z. · Nlend, M.C. ...

Soluble adenylyl cyclase is localized to cilia and contributes to ciliary beat frequency regulation via production of cAMP

J. Gen. Physiol. 2007; 130:99-109

Mick, D.U. · Rodrigues, R.B. · Leib, R.D. ...

Proteomics of Primary Cilia by Proximity Labeling

Dev. Cell. 2015; 35:497-512

Siljee, J.E. · Wang, Y. · Bernard, A.A. ...

Subcellular localization of MC4R with ADCY3 at neuronal primary cilia underlies a common pathway for genetic predisposition to obesity

Nat. Genet. 2018; 50:180-185

Truong, M.E. · Bilekova, S. · Choksi, S.P. ...

Vertebrate cells differentially interpret ciliary and extraciliary cAMP

Cell. 2021; 184:2911-2926.e18

Han, Y.G. - Spassky, N. - Romaguera-Ros, M. ...

Hedgehog signaling and primary cilia are required for the formation of adult neural stem cells

Nat. Neurosci. 2008; 11:277-284

Liu, S. - Trupiano, M.X. - Simon, J. ...

The essential role of primary cilia in cerebral cortical development and disorders

Curr. Top. Dev. Biol. 2021; 142:99-146

Han, Y.G. - Alvarez-Buylla, A.

Role of primary cilia in brain development and cancer

O--- O--- W---- Lt-I association (n

CBT. Opin. Neuroniot. 2010; 20:58-07

Kim, K.S. - Han, P.L.

Optimization of chronic stress paradigms using anxiety- and depressionlike behavioral parameters

J. Neurosci. Res. 2006; 83:497-507

Yuan, Z. · Qi, Z. · Wang, R. ...

A corticoamygdalar pathway controls reward devaluation and depression using dynamic inhibition code

Neuron. 2023; 111:3837-3853.e5

Berton, O. · McClung, C.A. · DiLeone, R.J. ...

Essential role of BDNF in the mesolimbic dopamine pathway in social defeat stress

Science. 2006; 311:864-868

Bishop, G.A. · Berbari, N.F. · Lewis, J. ...

Type III adenylyl cyclase localizes to primary cilia throughout the adult mouse brain

J. Comp. Neurol. 2007; 505:562-571

Macarelli, V. - Leventea, E. - Merkle, F.T.

Regulation of the length of neuronal primary cilia and its potential effects on signalling

Trends Cell Biol. 2023; 33:979-990

Krishnan, V. · Han, M.H. · Graham, D.L. ...

Molecular adaptations underlying susceptibility and resistance to social defeat in brain reward regions

Cell. 2007; 131:391-404

Tanos, B.E. · Yang, H.J. · Soni, R. ...

Centriole distal appendages promote membrane docking, leading to cilia initiation Genes Dev. 2013; 27:163-168

Shao, W. · Yang, J.J. · He, M. ...

Centrosome anchoring regulates progenitor properties and cortical formation

Nature. 2020; 580:106-112

Goebbels, S. · Bormuth, I. · Bode, U. ...

Genetic targeting of principal neurons in neocortex and hippocampus of NEX-Cre mice

Genesis, 2006; 44:611-621

Guo, B.L. · Chen, J. · Chen, Q. ...

Anterior cingulate cortex dysfunction underlies social deficits in Shank3 mutant mice

Nat. Neurosci. 2019; 22:1223-1234

Vorhees, C.V. · Williams, M.T.

Morris water maze: procedures for assessing spatial and related forms of learning and memory

Nat. Protoc. 2006; 1:848-858

Castagné, V. · Moser, P. · Roux, S. ...

Rodent models of depression: forced swim and tail suspension behavioral despair tests in rats and mice

Curr. Protoc. Neurosci. 2011;

Goetz, S.C. · Liem, K.F. · Anderson, K.V.

The Spinocerebellar Ataxia-Associated Gene Tau Tubulin Kinase 2 Controls the Initiation of Ciliogenesis

Cell. 2012; 151:847-858

Krishnan, V. · Nestler, E.J.

The molecular neurobiology of depression

Nature. 2008; 455:894-902

Blanchard, R.J. - McKittrick, C.R. - Blanchard, D.C.

Animal models of social stress: Effects on behavior and brain neurochemical systems

Physiol. Behav. 2001; 73:261-271

Herman, J.P. · Cullinan, W.E.

Neurocircuitry of stress: Central control of the hypothalamo-pituitaryadrenocortical axis

Trends Neurosci. 1997; 20:78-84

Zhao, Y. · Ma, R. · Shen, J. ...

A mouse model of depression induced by repeated corticosterone injections

Eur. J. Pharmacol. 2008; 581:113-120

Gourley, S.L. · Taylor, J.R.

Recapitulation and reversal of a persistent depression-like syndrome in rodents

Curr. Protoc. Neurosci. 2009;

Yuen, E.Y. · Wei, J. · Liu, W.H. ...